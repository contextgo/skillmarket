from __future__ import annotations

import asyncio
import json
from dataclasses import asdict, is_dataclass
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.runtime_models import ExecutableSearchPayload, SearchCapability
from liepin_skill.runtime.runtime_models import OrGroup, OrGroupSearchPlan
from liepin_skill.runtime.search_mode_adapter import build_executable_search_payload

if TYPE_CHECKING:
    from liepin_skill.browser.pages import CandidatePreview, SearchPage


def detect_search_capability(page_state: dict[str, bool]) -> SearchCapability:
    return SearchCapability(
        supports_compound_groups=bool(
            page_state.get("compound_toggle_visible") or page_state.get("compound_groups_visible")
        )
    )


def build_preview_queue_rows(
    *,
    job_id: str,
    plan_id: str,
    page_number: int,
    previews: Sequence[Mapping[str, Any] | CandidatePreview],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for position_in_page, preview in enumerate(previews, start=1):
        # Determine correct page number (from override if present, else default)
        actual_page = page_number
        if hasattr(preview, 'page_number_override'):
            actual_page = getattr(preview, 'page_number_override')
        elif isinstance(preview, Mapping) and 'page_number_override' in preview:
            actual_page = preview['page_number_override']

        preview_payload = _preview_payload_dict(preview)
        row = {
            "job_id": job_id,
            "plan_id": plan_id,
            "page_number": actual_page,
            "position_in_page": position_in_page,
            "preview_payload_json": json.dumps(preview_payload, ensure_ascii=False),
        }
        rows.append(row)
    return rows


def _preview_payload_dict(preview: Mapping[str, Any] | Any) -> dict[str, Any]:
    if isinstance(preview, Mapping):
        return dict(preview)
    if is_dataclass(preview):
        return asdict(preview)
    if hasattr(preview, "__dict__"):
        return {
            key: value
            for key, value in vars(preview).items()
            if not key.startswith("_")
        }
    raise TypeError("preview must be a mapping or dataclass-like object")


class _SearchPageLike(Protocol):
    async def fill_keyword_groups(self, keyword_groups: list[tuple[str, ...]] | list[list[str]]) -> Any:
        raise NotImplementedError

    async def fill_simple_keyword_query(self, query: str) -> Any:
        raise NotImplementedError

    async def submit_search(self) -> Any:
        raise NotImplementedError


class BrowserWorker:
    async def apply_search_payload(
        self,
        payload: ExecutableSearchPayload,
        search_page: _SearchPageLike,
    ) -> None:
        if payload.mode == "compound":
            keyword_groups = [tuple(group) for group in (payload.active_groups or ())]
            if not keyword_groups:
                raise ValueError("compound search payload must include at least one active keyword group")
            filled = await search_page.fill_keyword_groups(keyword_groups)
        elif payload.mode == "simple":
            query = (payload.simple_query or "").strip()
            if not query:
                raise ValueError("simple search payload must include a non-empty query")
            filled = await search_page.fill_simple_keyword_query(query)
            if not filled:
                # Fallback: retry with only the first term/group if the full query is rejected
                fallback_query = query.split()[0] if query.split() else query
                if fallback_query and fallback_query != query:
                    filled = await search_page.fill_simple_keyword_query(fallback_query)
        else:
            raise ValueError(f"Unsupported search payload mode: {payload.mode}")

        if not filled:
            raise RuntimeError(f"search page rejected {payload.mode} search criteria")

        await search_page.submit_search()

    def collect_previews_for_plan(
        self,
        *,
        db: RuntimeDatabase,
        runtime_root: Path,
        job_id: str,
        latest_plan: Mapping[str, Any],
    ) -> dict[str, Any]:
        return asyncio.run(
            self._collect_previews_for_plan_async(
                db=db,
                runtime_root=runtime_root,
                job_id=job_id,
                latest_plan=latest_plan,
            )
        )

    async def _collect_previews_for_plan_async(
        self,
        *,
        db: RuntimeDatabase,
        runtime_root: Path,
        job_id: str,
        latest_plan: Mapping[str, Any],
    ) -> dict[str, Any]:
        from liepin_skill.browser.pages import SearchPage
        from liepin_skill.browser.session import LiepinSession, SessionConfig
        from liepin_skill.runtime.runtime_config import read_liepin_credentials_from_env

        username, password = read_liepin_credentials_from_env()
        session = LiepinSession(
            SessionConfig(
                username=username,
                password=password,
                storage_path=str(runtime_root / "browser_storage"),
                headless=True,
            ),
            base_dir=runtime_root,
        )
        await session.start()
        try:
            # Refresh onto preview URL to clear residual search conditions before applying a plan.
            await session.page.goto("https://lpt.liepin.com/search#preview", wait_until="commit", timeout=15000)
            await asyncio.sleep(3)
            search_page = SearchPage(session.page)
            await search_page.open_search_page_from_nav()
            current_plan = db.get_latest_search_plan(job_id=job_id)
            if current_plan is None or current_plan["plan_id"] != latest_plan["plan_id"]:
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.stale_plan_skipped",
                    payload={
                        "requested_plan_id": latest_plan["plan_id"],
                        "latest_plan_id": current_plan["plan_id"] if current_plan else None,
                        "stage": "before_apply_payload",
                    },
                )
                return {"result_count": 0, "search_mode": "compound", "collected_preview_count": 0, "stale_plan_skipped": True}

            page_state = {
                "compound_toggle_visible": (
                    await session.page.locator("text=复合关键词").count() > 0
                    or await session.page.locator("text=包含全部关键词").count() > 0
                ),
                "compound_groups_visible": False,
            }
            capability = detect_search_capability(page_state)
            payload = build_executable_search_payload(
                self._to_or_group_search_plan(latest_plan["search_plan"]),
                capability,
            )
            if payload.current_city:
                keyword_groups = self._payload_keyword_groups(payload)
                filled = await search_page.fill_test_search_criteria(
                    city=payload.current_city[0],
                    keyword_groups=keyword_groups,
                )
                if filled.get("top_query"):
                    await search_page.submit_search()
                else:
                    # City filter rejected - fall through to keyword-only search
                    await self.apply_search_payload(payload, search_page)
            else:
                await self.apply_search_payload(payload, search_page)
            
            stats = await search_page.get_search_stats()

            fresh_plan = db.get_latest_search_plan(job_id=job_id)
            if fresh_plan is None or fresh_plan["plan_id"] != latest_plan["plan_id"]:
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.stale_plan_skipped",
                    payload={
                        "requested_plan_id": latest_plan["plan_id"],
                        "latest_plan_id": fresh_plan["plan_id"] if fresh_plan else None,
                        "stage": "after_search_before_record",
                        "result_count": stats.total_count,
                    },
                )
                return {"result_count": 0, "search_mode": payload.mode, "collected_preview_count": 0, "stale_plan_skipped": True}
            
            # REMOVED: Fast-path >200 skip — always collect full results.
            # Rationale: Even if result_count is large, we need to collect candidates
            # to enable preview_eval → communication pipeline. Tightening criteria
            # can take many iterations (光模块 PM still returns 990 even with filters).
            # The adaptive logic in orchestrator will still tighten when linked_count
            # exceeds the target, but we always collect a full page first.
            # if stats.total_count > 200:
            #     db.record_event(...)
            #     return {...}
            # // fall through to normal collection
            
            # ------------------------------------------------------------------
            # Single-page collection (serial design: one page at a time)
            # The orchestrator triggers the next page only after the current
            # page's full pipeline (preview_eval → detail_harvest →
            # detail_eval → communication) has drained.
            # ------------------------------------------------------------------
            max_page_collected = db.get_max_collected_page(
                job_id=job_id,
                plan_id=latest_plan["plan_id"],
            )
            current_page = max_page_collected + 1

            if current_page > 5:  # Hard safety limit
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.page_limit_reached",
                    payload={"max_page": 5, "plan_id": latest_plan["plan_id"]},
                )
                return {
                    "result_count": stats.total_count,
                    "search_mode": payload.mode,
                    "collected_preview_count": 0,
                    "page_limit_reached": True,
                }

            # Stale-plan guard before collecting
            fresh_plan = db.get_latest_search_plan(job_id=job_id)
            if fresh_plan is None or fresh_plan["plan_id"] != latest_plan["plan_id"]:
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.stale_plan_skipped",
                    payload={
                        "requested_plan_id": latest_plan["plan_id"],
                        "latest_plan_id": fresh_plan["plan_id"] if fresh_plan else None,
                        "stage": "page_collection_guard",
                        "page_number": current_page,
                    },
                )
                return {"result_count": stats.total_count, "search_mode": payload.mode, "collected_preview_count": 0, "stale_plan_skipped": True}

            db.record_event(
                job_id=job_id,
                event_type="browser_worker.page_started",
                payload={"plan_id": latest_plan["plan_id"], "page_number": current_page},
            )
            page_previews = await search_page.get_candidate_previews()

            rows = build_preview_queue_rows(
                job_id=job_id,
                plan_id=latest_plan["plan_id"],
                page_number=current_page,
                previews=page_previews,
            )
            for row in rows:
                preview_payload = json.loads(row["preview_payload_json"])
                db.insert_candidate_queue_row(
                    job_id=row["job_id"],
                    plan_id=row["plan_id"],
                    candidate_key=str(preview_payload.get("candidate_key") or preview_payload.get("name") or ""),
                    page_number=int(row["page_number"]),
                    position_in_page=int(row["position_in_page"]),
                    preview_payload_json=row["preview_payload_json"],
                )

            print(f"Collected {len(page_previews)} candidates from page {current_page}")
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.page_finished",
                payload={
                    "plan_id": latest_plan["plan_id"],
                    "page_number": current_page,
                    "page_preview_count": len(page_previews),
                },
            )

            return {
                "result_count": stats.total_count,
                "search_mode": payload.mode,
                "collected_preview_count": len(page_previews),
                "collected_page": current_page,
            }
        finally:
            await session.close()

    def _to_or_group_search_plan(self, search_plan_payload: Mapping[str, Any]) -> OrGroupSearchPlan:
        groups = tuple(
            OrGroup(
                group_index=int(group["group_index"]),
                concept=str(group["concept"]),
                terms=tuple(str(term) for term in group.get("terms", [])),
            )
            for group in search_plan_payload.get("groups", [])
        )
        return OrGroupSearchPlan(
            groups=groups,
            active_group_count=int(search_plan_payload.get("active_group_count", 0)),
            current_city=tuple(search_plan_payload.get("current_city", [])),
            expected_city=tuple(search_plan_payload.get("expected_city", [])),
            experience_filter=search_plan_payload.get("experience_filter"),
            optional_filters=search_plan_payload.get("optional_filters", {}),
        )

    def _payload_keyword_groups(self, payload: ExecutableSearchPayload) -> list[list[str]]:
        if payload.active_groups:
            return [list(group) for group in payload.active_groups]
        if payload.simple_query:
            return [[term for term in payload.simple_query.split() if term]]
        return []

    # ------------------------------------------------------------------
    # Session lifecycle helpers
    # ------------------------------------------------------------------

    async def _create_session(self, *, runtime_root: Path):
        from liepin_skill.browser.pages import SearchPage
        from liepin_skill.browser.session import LiepinSession, SessionConfig
        from liepin_skill.runtime.runtime_config import read_liepin_credentials_from_env

        username, password = read_liepin_credentials_from_env()
        session = LiepinSession(
            SessionConfig(
                username=username,
                password=password,
                storage_path=str(runtime_root / "browser_storage"),
                headless=True,
            ),
            base_dir=runtime_root,
        )
        await session.start()
        search_page = SearchPage(session.page)
        return session, search_page

    async def _navigate_to_search_results(
        self,
        *,
        search_page: Any,
        latest_plan: Mapping[str, Any],
        target_page: int,
    ) -> int:
        """Navigate to the search results for latest_plan and paginate to target_page.
        Returns the actual page we ended up on."""
        await search_page.open_search_page_from_nav()
        capability = detect_search_capability({"compound_toggle_visible": True})
        payload = build_executable_search_payload(
            self._to_or_group_search_plan(latest_plan["search_plan"]),
            capability,
        )
        await self.apply_search_payload(payload, search_page)

        current_page = 1
        while current_page < target_page:
            moved = await search_page.go_to_next_page()
            if not moved:
                break
            current_page += 1
        return current_page

    @staticmethod
    def _resolve_card_position(
        *,
        raw_position: int,
        target_page: int,
        cards: list[Any],
    ) -> int:
        """Convert a possibly-global ordinal to a 0-indexed position within the card list."""
        nominal_page_size = 20
        local_position = raw_position
        if raw_position > len(cards):
            local_position = raw_position - ((target_page - 1) * nominal_page_size)
        return local_position - 1

    @staticmethod
    async def _click_card_and_wait(
        search_page: Any,
        cards: list[Any],
        pos: int,
        wait_seconds: float = 3,
    ) -> None:
        """Click a candidate card and wait for the detail modal to appear."""
        page = search_page.page
        modal = page.locator(".ant-lpt-modal-wrap.resume-detail-modal-wrap, .resume-detail-modal-wrap").first
        print(f"[DEBUG] _click_card_and_wait: clicking card at pos={pos}")

        # Always try ESC once before clicking a new card to clear any stale modal.
        try:
            await page.keyboard.press("Escape")
            print(f"[DEBUG] _click_card_and_wait: pressed ESC to clear stale modal")
            await asyncio.sleep(0.5)
        except Exception:
            pass

        # If the modal is already visible, treat that as success and do not re-click the card.
        try:
            if await modal.is_visible(timeout=1000):
                print(f"[DEBUG] _click_card_and_wait: modal already visible, skipping click")
                return
        except Exception:
            pass

        await cards[pos].click(position={"x": 50, "y": 20})
        print(f"[DEBUG] _click_card_and_wait: card clicked, waiting for modal...")

        # Modal appearance is the success signal. Do not re-click if it's already open.
        try:
            await modal.wait_for(state="visible", timeout=int(wait_seconds * 1000))
            print(f"[DEBUG] _click_card_and_wait: modal visible confirmed")
            return
        except Exception as e:
            print(f"[DEBUG] _click_card_and_wait: modal wait error: {e}")
            await asyncio.sleep(wait_seconds)
            if await modal.count() > 0 and await modal.is_visible():
                print(f"[DEBUG] _click_card_and_wait: modal visible after sleep")
                return
            raise RuntimeError("Candidate detail modal did not appear after card click")

    @staticmethod
    async def _close_detail_modal(page: Any) -> None:
        """Close the candidate detail modal to return to the search results list."""
        print(f"[DEBUG] _close_detail_modal: attempting to close modal")
        try:
            close_btn = page.locator(".ant-lpt-modal-wrap .ant-modal-close, .resume-detail-modal-wrap .ant-modal-close, .ant-lpt-modal-wrap [aria-label='Close']").first
            if await close_btn.is_visible(timeout=2000):
                await close_btn.click()
                print(f"[DEBUG] _close_detail_modal: clicked close button")
                await asyncio.sleep(1)
            else:
                print(f"[DEBUG] _close_detail_modal: close button not visible, trying ESC")
        except Exception as e:
            print(f"[DEBUG] _close_detail_modal: close button error: {e}, trying ESC")
        
        # Fallback: press Escape
        try:
            await page.keyboard.press("Escape")
            print(f"[DEBUG] _close_detail_modal: pressed ESC (1st)")
            await asyncio.sleep(1)
            # Double ESC fix: press ESC again after 1 second to close any nested modal/overlay
            await page.keyboard.press("Escape")
            print(f"[DEBUG] _close_detail_modal: pressed ESC (2nd)")
            await asyncio.sleep(1)
        except Exception as e:
            print(f"[DEBUG] _close_detail_modal: ESC error: {e}")
            pass
        
        # Verify modal is closed
        modal = page.locator(".ant-lpt-modal-wrap.resume-detail-modal-wrap").first
        try:
            is_hidden = not await modal.is_visible(timeout=2000)
            print(f"[DEBUG] _close_detail_modal: modal hidden={is_hidden}")
        except Exception as e:
            print(f"[DEBUG] _close_detail_modal: could not verify modal state: {e}")

    @staticmethod
    async def _dismiss_communication_dialog(page: Any) -> None:
        """Dismiss any post-communication confirmation dialog."""
        try:
            ok_btn = page.locator("button:has-text('确 定'), button:has-text('确定'), button:has-text('OK'), button:has-text('Ok')").first
            if await ok_btn.is_visible(timeout=2000):
                await ok_btn.click()
                await asyncio.sleep(1)
        except Exception:
            pass

    async def _wait_for_detail_decision(
        self,
        *,
        db: RuntimeDatabase,
        queue_id: str,
        timeout_seconds: float = 30.0,
        poll_interval: float = 1.0,
    ) -> str:
        """Poll DB until resume-worker turns detail_harvested into pending_communication/completed.
        Returns the latest queue status.
        """
        deadline = asyncio.get_event_loop().time() + timeout_seconds
        last_status = "detail_harvested"
        while asyncio.get_event_loop().time() < deadline:
            row = db._get_candidate_queue_row(queue_id=queue_id)
            if row is None:
                return "missing"
            last_status = str(row.get("status") or "")
            if last_status in {"pending_communication", "completed", "failed"}:
                return last_status
            await asyncio.sleep(poll_interval)
        return last_status

    # ------------------------------------------------------------------
    # Detail harvest (lightweight: no session management)
    # ------------------------------------------------------------------

    async def _harvest_detail_with_session(
        self,
        *,
        db: RuntimeDatabase,
        job_id: str,
        queue_row: Mapping[str, Any],
        search_page: Any,
        session: Any,
    ) -> int:
        """Harvest detail for one candidate using an existing session.
        The modal is left OPEN after this method returns so that communication
        can happen in the same modal if needed."""
        from liepin_skill.browser.pages import CandidatePage
        import json

        try:
            target_page = int(queue_row.get("page_number", 1))
            raw_position = int(queue_row["position_in_page"])
            queue_id = queue_row["queue_id"]
            
            # Load preview name for comparison
            preview_payload = json.loads(queue_row.get("preview_payload_json", "{}"))
            preview_name = preview_payload.get("name", "Unknown")
            print(f"[DEBUG] _harvest_detail_with_session START: queue_id={queue_id[:8]}, preview_name={preview_name}, page={target_page}, pos={raw_position}")

            # 1. Click the candidate card
            cards = await search_page.get_candidate_card_locators()
            if not cards:
                await asyncio.sleep(2)
                cards = await search_page.get_candidate_card_locators()
                if not cards:
                    raise RuntimeError(f"No candidate cards found on page {target_page}")

            pos = self._resolve_card_position(
                raw_position=raw_position,
                target_page=target_page,
                cards=cards,
            )
            if pos < 0 or pos >= len(cards):
                raise RuntimeError(
                    f"Detail candidate index {raw_position} (local {pos+1}) out of range "
                    f"(found {len(cards)} cards on page {target_page})"
                )

            print(f"[DEBUG] Clicking card at index {pos}...")
            await self._click_card_and_wait(search_page, cards, pos, wait_seconds=3)
            print(f"[DEBUG] Card clicked, waiting for modal...")

            # 2. Wait for modal to appear and verify name
            modal = session.page.locator(".ant-lpt-modal-wrap.resume-detail-modal-wrap").first
            try:
                await modal.wait_for(state="visible", timeout=5000)
                print(f"[DEBUG] Modal visible")
            except Exception:
                raise RuntimeError("Detail modal did not appear after click")

            # Read modal name for verification
            try:
                modal_name_locator = modal.locator(".name, .candidate-name, [class*='name']").first
                await modal_name_locator.wait_for(state="visible", timeout=2000)
                modal_name = await modal_name_locator.text_content()
                modal_name = modal_name.strip() if modal_name else "Unknown"
                name_match = (preview_name == modal_name) or (preview_name.startswith(modal_name.split("（")[0]) if "（" in modal_name else False)
                print(f"[DEBUG] Modal name: '{modal_name}', preview name: '{preview_name}', match={name_match}")
                if not name_match:
                    print(f"[WARN] NAME MISMATCH! Preview='{preview_name}' vs Modal='{modal_name}'")
            except Exception as e:
                print(f"[DEBUG] Could not read modal name: {e}")
                modal_name = "Unknown"

            # 3. Harvest full info (modal is open)
            detail_page = CandidatePage(session.page)
            full_info = await detail_page.get_full_info()
            print(f"[DEBUG] Detail harvested successfully")

            # 4. Update DB — write to detail_payload_json, leave modal OPEN
            db.update_candidate_queue_payload(
                queue_id=queue_row["queue_id"],
                payload=full_info,
            )
            db.update_candidate_queue_status(
                queue_id=queue_row["queue_id"],
                status="detail_harvested",
            )
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.detail_harvested",
                payload={"queue_id": queue_row["queue_id"]},
            )
            print(f"[DEBUG] _harvest_detail_with_session DONE: queue_id={queue_id[:8]}")
            return 1

        except Exception as e:
            # Ensure modal is closed on error
            try:
                await session.page.keyboard.press("Escape")
                await asyncio.sleep(1)
            except Exception:
                pass
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.detail_error",
                payload={"queue_id": queue_row["queue_id"], "error": str(e)[:500]},
            )
            raise

    # ------------------------------------------------------------------
    # Communication (lightweight: uses existing open modal)
    # ------------------------------------------------------------------

    async def _execute_communication_with_session(
        self,
        *,
        db: RuntimeDatabase,
        job_id: str,
        queue_row: Mapping[str, Any],
        search_page: Any,
        session: Any,
    ) -> int:
        """Execute communication for one candidate using an existing session.
        Assumes the candidate's detail modal is already open."""
        import json
        job = db.get_job(job_id)
        if not job:
            raise RuntimeError(f"Job {job_id} not found")

        try:
            queue_id = queue_row["queue_id"]
            preview_payload = json.loads(queue_row.get("preview_payload_json", "{}"))
            preview_name = preview_payload.get("name", "Unknown")
            print(f"[DEBUG] _execute_communication_with_session START: queue_id={queue_id[:8]}, preview_name={preview_name}")

            # The detail modal should already be open (opened by harvest step or by us)
            # Verify modal is visible; if not, open it
            modal = session.page.locator(".ant-lpt-modal-wrap.resume-detail-modal-wrap").first
            if not await modal.is_visible(timeout=3000):
                # Modal not open — need to click the card first
                print(f"[DEBUG] Modal not visible, clicking card...")
                target_page = int(queue_row.get("page_number", 1))
                raw_position = int(queue_row["position_in_page"])
                cards = await search_page.get_candidate_card_locators()
                if not cards:
                    await asyncio.sleep(2)
                    cards = await search_page.get_candidate_card_locators()
                pos = self._resolve_card_position(
                    raw_position=raw_position,
                    target_page=target_page,
                    cards=cards,
                )
                if pos < 0 or pos >= len(cards):
                    raise RuntimeError(
                        f"Communication: candidate index {raw_position} out of range "
                        f"(found {len(cards)} cards)"
                    )
                await self._click_card_and_wait(search_page, cards, pos, wait_seconds=2)
                
                # Verify modal name after opening
                try:
                    await modal.wait_for(state="visible", timeout=3000)
                    modal_name_locator = modal.locator(".name, .candidate-name, [class*='name']").first
                    modal_name = await modal_name_locator.text_content()
                    modal_name = modal_name.strip() if modal_name else "Unknown"
                    print(f"[DEBUG] Modal opened, name: '{modal_name}', preview: '{preview_name}'")
                except Exception as e:
                    print(f"[DEBUG] Could not verify modal name: {e}")
            else:
                print(f"[DEBUG] Modal already visible")

            # Pre-locate modal close button for later use
            modal_close_btn = modal.locator(".ant-lpt-modal-close").first
            try:
                count = await modal_close_btn.count()
                if count > 0:
                    print(f"[DEBUG] Modal close button pre-located (.ant-lpt-modal-close)")
                else:
                    print(f"[DEBUG] WARNING: Close button not found in DOM")
            except Exception as e:
                print(f"[DEBUG] Could not locate close button: {e}")

            # Execute communication click inside the modal
            print(f"[DEBUG] Clicking action button...")
            success = await search_page.click_action_button(
                position_name=job.target_position_name,
                candidate_index=0,
            )
            print(f"[DEBUG] Action button result: success={success}")

            # Dismiss any post-communication dialog
            await self._dismiss_communication_dialog(session.page)

            # Close the detail modal to return to search results
            # Milestone 3 Fix: Use JavaScript click to bypass toast overlay
            print(f"[DEBUG] Closing modal...")
            if success:
                # For successful communication, use JS click on close button (bypasses toast)
                js_click_success = False
                try:
                    await modal_close_btn.evaluate("el => el.click()")
                    print(f"[DEBUG] Modal close button clicked via JavaScript")
                    js_click_success = True
                except Exception as e:
                    print(f"[DEBUG] JS click failed: {e}, will fallback to ESC")
                
                # Verify modal is closed
                await asyncio.sleep(1)
                modal_closed = not await modal.is_visible(timeout=2000)
                
                if not modal_closed:
                    # Fallback: wait for toast to auto-dismiss (10 seconds) then ESC
                    print(f"[DEBUG] Modal still visible after JS click, waiting for toast to dismiss...")
                    await asyncio.sleep(10)
                    await session.page.keyboard.press("Escape")
                    await asyncio.sleep(1)
                    modal_closed = not await modal.is_visible(timeout=2000)
                    print(f"[DEBUG] Modal closed after fallback: {modal_closed}")
                else:
                    print(f"[DEBUG] Modal closed successfully via JS click")
                
                print(f"[DEBUG] Modal closed: {modal_closed}")
            else:
                # For failed communication, use normal close (ESC)
                await self._close_detail_modal(session.page)
                await asyncio.sleep(1)
                modal_closed = not await modal.is_visible(timeout=2000)
                print(f"[DEBUG] Modal closed (failed comm): {modal_closed}")
            
            await asyncio.sleep(1)

            if success:
                db.update_candidate_queue_status(queue_id=queue_row["queue_id"], status="completed")
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.communication_success",
                    payload={"queue_id": queue_row["queue_id"]},
                )
                print(f"[DEBUG] _execute_communication_with_session DONE: queue_id={queue_id[:8]}, success={success}")
                return 1
            else:
                # Communication failed: mark as completed to release the claim and allow page turn.
                # The failure is already recorded as an event for audit.
                db.update_candidate_queue_status(queue_id=queue_row["queue_id"], status="completed")
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.communication_failed",
                    payload={"queue_id": queue_row["queue_id"], "reason": "click_action_button_failed_likely_overlay"},
                )
                print(f"[DEBUG] _execute_communication_with_session DONE: queue_id={queue_id[:8]}, failed")
                return 0
        except Exception as e:
            # Try to close modal on error to recover
            await self._close_detail_modal(session.page)
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.communication_error",
                payload={"queue_id": queue_row["queue_id"], "error": str(e)},
            )
            db.update_candidate_queue_status(queue_id=queue_row["queue_id"], status="failed")
            raise

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run_job(self, *, db: RuntimeDatabase, job_id: str, runtime_root: Path | str | None = None) -> int:
        """Main entry point. Creates a single browser session and processes
        all pending work (communication + detail harvest) page by page."""
        return asyncio.run(
            self._run_job_async(db=db, job_id=job_id, runtime_root=runtime_root)
        )

    async def _run_job_async(
        self,
        *,
        db: RuntimeDatabase,
        job_id: str,
        runtime_root: Path | str | None = None,
    ) -> int:
        if runtime_root is None:
            runtime_root = Path(__file__).resolve().parents[3] / "runtime"
        effective_runtime_root = Path(runtime_root)

        work_done = 0
        focused_page = db.get_next_pending_page_number(job_id=job_id)

        # If there is page-level pending work (detail / communication), use shared session
        if focused_page is not None:
            session, search_page = await self._create_session(runtime_root=effective_runtime_root)
            try:
                latest_plan = db.get_latest_search_plan(job_id=job_id)
                if not latest_plan:
                    db.record_event(job_id=job_id, event_type="browser_worker.waiting_for_plan")
                    return 0

                last_navigated_page = 0

                while focused_page is not None:
                    db.record_event(
                        job_id=job_id,
                        event_type="browser_worker.page_processing_started",
                        payload={"page_number": focused_page},
                    )

                    # Navigate to the correct page (only if we're not already there)
                    if int(focused_page) != last_navigated_page:
                        actual_page = await self._navigate_to_search_results(
                            search_page=search_page,
                            latest_plan=latest_plan,
                            target_page=int(focused_page),
                        )
                        last_navigated_page = actual_page

                    # --- Detail harvest + Block for Evaluation + Communication ---
                    page_pending_details = db.list_candidate_queue_rows(
                        job_id=job_id,
                        page_number=focused_page,
                        status="pending_detail_harvest",
                    )
                    if page_pending_details:
                        claimed = db.claim_candidate(
                            queue_id=page_pending_details[0]["queue_id"],
                            worker_name="browser-worker",
                            lease_seconds=120, # Higher lease for serial processing
                            status="pending_detail_harvest",
                        )
                        if claimed:
                            db.record_event(
                                job_id=job_id,
                                event_type="browser_worker.page_scoped_detail_claim",
                                payload={"page_number": focused_page, "queue_id": claimed["queue_id"]},
                            )
                            # 1. Open modal and harvest
                            await self._harvest_detail_with_session(
                                db=db,
                                job_id=job_id,
                                queue_row=claimed,
                                search_page=search_page,
                                session=session,
                            )
                            work_done += 1
                            
                            # 2. Block until Resume-worker makes a decision (Milestone 3 Core)
                            db.record_event(
                                job_id=job_id,
                                event_type="browser_worker.waiting_for_eval",
                                payload={"queue_id": claimed["queue_id"]},
                            )
                            decision_status = await self._wait_for_detail_decision(
                                db=db,
                                queue_id=claimed["queue_id"],
                                timeout_seconds=45.0, # Wait up to 45s for LLM
                            )
                            
                            # 3. If promoted to communication, execute immediately while modal is still open
                            if decision_status == "pending_communication":
                                comm_claimed = db.claim_candidate(
                                    queue_id=claimed["queue_id"],
                                    worker_name="browser-worker",
                                    lease_seconds=60,
                                    status="pending_communication",
                                )
                                if comm_claimed:
                                    db.record_event(
                                        job_id=job_id,
                                        event_type="browser_worker.executing_serial_communication",
                                        payload={"queue_id": claimed["queue_id"]},
                                    )
                                    await self._execute_communication_with_session(
                                        db=db,
                                        job_id=job_id,
                                        queue_row=comm_claimed,
                                        search_page=search_page,
                                        session=session,
                                    )
                                    work_done += 1
                            else:
                                # Skip or Timeout: close modal and move to next
                                await self._close_detail_modal(session.page)
                                await asyncio.sleep(1)
                                
                            continue

                    # --- Communication fallback (for candidates promoted outside the serial loop) ---
                    page_pending_comm = db.list_candidate_queue_rows(
                        job_id=job_id,
                        page_number=focused_page,
                        status="pending_communication",
                    )
                    if page_pending_comm:
                        claimed = db.claim_candidate(
                            queue_id=page_pending_comm[0]["queue_id"],
                            worker_name="browser-worker",
                            lease_seconds=60,
                            status="pending_communication",
                        )
                        if claimed:
                            db.record_event(
                                job_id=job_id,
                                event_type="browser_worker.page_scoped_communication_claim",
                                payload={"page_number": focused_page, "queue_id": claimed["queue_id"]},
                            )
                            work_done += await self._execute_communication_with_session(
                                db=db,
                                job_id=job_id,
                                queue_row=claimed,
                                search_page=search_page,
                                session=session,
                            )
                            continue

                    # --- No more work on this page ---
                    page_still_pending = db.page_has_pending_work(job_id=job_id, page_number=focused_page)
                    db.record_event(
                        job_id=job_id,
                        event_type="browser_worker.page_processing_finished",
                        payload={
                            "page_number": focused_page,
                            "page_still_pending": page_still_pending,
                            "work_done": work_done,
                        },
                    )

                    # New: signal page is safe for navigation (modal closed, back to list)
                    if not page_still_pending:
                        try:
                            # Ensure modal is closed before signaling
                            await self._close_detail_modal(session.page)
                            
                            # Direct visibility check for search list in browser
                            # Look for candidate card elements to confirm we're back on the list page
                            list_visible = await session.page.locator(
                                ".resumeCardWrap--FcnzW, .search-result-list, [class*='resumeCardWrap']"
                            ).first.is_visible(timeout=3000)
                            
                            if not list_visible:
                                raise RuntimeError("search list not visible after modal close")
                            
                            db.record_event(
                                job_id=job_id,
                                event_type="browser_worker.page_ready_for_navigation",
                                payload={"page_number": focused_page},
                            )
                            print(f"[BrowserWorker] Page {focused_page} ready for navigation")
                        except Exception as e:
                            print(f"[WARN] page_ready_for_navigation check failed: page={focused_page}, err={e}")

                    if page_still_pending:
                        # Safety sleep if we think there's still work but couldn't find/claim it
                        await asyncio.sleep(2)
                        break
                    focused_page = db.get_next_pending_page_number(job_id=job_id)

            finally:
                await session.close()

            if work_done > 0:
                return work_done

        # ------------------------------------------------------------------
        # Lower Priority: New search plan previews (standalone session)
        # ------------------------------------------------------------------
        # SAFETY CHECK: Do not start new search if there's ANY pending work in the queue.
        # This includes not just pending statuses, but also completed candidates waiting
        # for promotion (race condition fix: resume-worker may have cleared pending_preview_eval
        # but orchestrator hasn't promoted completed+open_detail to pending_detail_harvest yet).
        
        # Check 1: Standard pending statuses
        pending_total = db.count_candidate_queue_rows(
            job_id=job_id, 
            statuses=("pending_preview_eval", "pending_detail_harvest", "detail_harvested", "pending_communication", "claimed")
        )
        
        # Check 2: completed + open_detail waiting for promotion to pending_detail_harvest
        with db._connect() as conn:
            pending_promotion = conn.execute(
                """
                SELECT COUNT(*)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.status = 'completed'
                  AND EXISTS (
                      SELECT 1 FROM candidate_evaluations e
                      WHERE e.queue_id = q.queue_id
                        AND e.stage = 'preview'
                        AND e.decision = 'open_detail'
                  )
                  AND NOT EXISTS (
                      SELECT 1 FROM candidate_evaluations e2
                      WHERE e2.queue_id = q.queue_id
                        AND e2.stage = 'detail'
                  )
                """,
                (job_id,),
            ).fetchone()
        pending_promotion_count = int(pending_promotion[0]) if pending_promotion else 0
        
        # Check 3: detail_harvested waiting for resume-worker evaluation
        detail_harvested_count = db.count_candidate_queue_rows(
            job_id=job_id,
            statuses=("detail_harvested",),
        )
        
        total_pipeline_work = pending_total + pending_promotion_count + detail_harvested_count
        
        if total_pipeline_work > 0:
            db.record_event(
                job_id=job_id, 
                event_type="browser_worker.search_skipped_queue_not_empty",
                payload={
                    "pending_total": pending_total,
                    "pending_promotion_count": pending_promotion_count,
                    "detail_harvested_count": detail_harvested_count,
                    "total_pipeline_work": total_pipeline_work,
                }
            )
            return 0
            
        latest_plan = db.get_latest_search_plan(job_id=job_id)
        if latest_plan is None:
            db.record_event(job_id=job_id, event_type="browser_worker.waiting_for_plan")
            return 0

        # Check 4: Pipeline drain gate — do NOT collect a new page until the
        # previously collected page's full pipeline has drained.
        max_collected = db.get_max_collected_page(
            job_id=job_id,
            plan_id=latest_plan["plan_id"],
        )
        if max_collected > 0:
            if db.get_page_pipeline_complete(job_id=job_id, page_number=max_collected):
                # Previous page is fully drained — safe to collect the next page.
                # Fall through to collection below.
                pass
            else:
                db.record_event(
                    job_id=job_id,
                    event_type="browser_worker.collection_blocked_pipeline_incomplete",
                    payload={
                        "last_collected_page": max_collected,
                        "reason": "previous page pipeline not yet drained",
                    },
                )
                return 0
        elif db.count_candidate_queue_rows(job_id=job_id, plan_id=latest_plan["plan_id"]) > 0:
            # First page already collected (max_collected==0 but rows exist) —
            # this shouldn't happen, but guard against it.
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.queue_already_populated",
                payload={"plan_id": latest_plan["plan_id"]},
            )
            return 0

        try:
            collected = await self._collect_previews_for_plan_async(
                db=db,
                runtime_root=effective_runtime_root,
                job_id=job_id,
                latest_plan=latest_plan,
            )
        except Exception as exc:
            db.record_event(
                job_id=job_id,
                event_type="browser_worker.error",
                payload={"error": str(exc), "plan_id": latest_plan["plan_id"]},
            )
            raise

        db.record_event(
            job_id=job_id,
            event_type="browser_worker.previews_collected",
            payload={
                "plan_id": latest_plan["plan_id"],
                "page_number": int(collected.get("collected_page", 1)),
                "active_group_count": latest_plan["search_plan"].get("active_group_count", 0),
                "result_count": int(collected.get("result_count", 0)),
                "collected_preview_count": int(collected.get("collected_preview_count", 0)),
                "search_mode": collected.get("search_mode"),
            },
        )
        return int(collected.get("collected_preview_count", 0))
