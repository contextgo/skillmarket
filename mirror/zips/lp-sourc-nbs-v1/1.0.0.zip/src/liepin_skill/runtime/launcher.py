from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path


def _ensure_src_path() -> Path:
    launcher_path = Path(__file__).resolve()
    src_root = launcher_path.parents[2]
    src_root_str = str(src_root)
    if src_root_str not in sys.path:
        sys.path.insert(0, src_root_str)
    return launcher_path


LAUNCHER_SCRIPT_PATH = _ensure_src_path()

from liepin_skill.runtime.db import RuntimeDatabase  # noqa: E402
from liepin_skill.runtime.orchestrator import RuntimeOrchestrator  # noqa: E402
from liepin_skill.runtime.worker_browser import BrowserWorker  # noqa: E402
from liepin_skill.runtime.worker_jd import build_default_jd_worker  # noqa: E402
from liepin_skill.runtime.worker_resume import build_default_resume_worker  # noqa: E402


def _load_gateway_token() -> str | None:
    """Read gateway auth token from openclaw.json if available."""
    openclaw_cfg = Path.home() / ".openclaw" / "openclaw.json"
    if not openclaw_cfg.exists():
        return None
    try:
        with open(openclaw_cfg) as f:
            cfg = json.load(f)
        return cfg.get("gateway", {}).get("auth", {}).get("token")
    except Exception:
        return None


def _load_skill_env(skill_root: Path) -> dict[str, str]:
    """Load .env file from skill root directory."""
    env_path = skill_root / ".env"
    if not env_path.exists():
        return {}
    env_vars: dict[str, str] = {}
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            env_vars[key.strip()] = value.strip()
    return env_vars


ROLE_NAMES = ("orchestrator", "browser-worker", "jd-worker", "resume-worker")
TERMINAL_JOB_STATUSES = {
    "completed",
    "failed",
    "paused",
    "paused_auth_required",
    "failed_recoverable",
}
ROLE_POLL_INTERVAL_SECONDS = 1.0
ROLE_MAX_IDLE_SECONDS = 300.0


@dataclass(slots=True)
class RuntimeLauncher:
    runtime_root: Path
    python_bin: str

    @property
    def active_job_lock_path(self) -> Path:
        return Path(self.runtime_root) / "active_job.lock"

    def prepare_job(
        self,
        *,
        source_jd_path: str,
        target_position_name: str,
        target_link_count: int,
    ):
        runtime_root = Path(self.runtime_root)
        db = RuntimeDatabase(runtime_root / "state.db")
        db.initialize()
        job = db.create_job(
            source_jd_path=source_jd_path,
            target_position_name=target_position_name,
            target_link_count=target_link_count,
        )
        (runtime_root / "jobs" / job.job_id).mkdir(parents=True, exist_ok=True)
        return job

    def describe_launch_commands(self, *, job_id: str) -> list[list[str]]:
        launcher_script = str(LAUNCHER_SCRIPT_PATH)
        return [
            [self.python_bin, launcher_script, role, "--job-id", job_id]
            for role in ROLE_NAMES
        ]

    def launch_process_group(self, *, job_id: str) -> list[object]:
        logs_dir = Path(self.runtime_root) / "jobs" / job_id / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        processes: list[object] = []
        process_records: list[dict[str, object]] = []
        skill_root = Path(__file__).resolve().parents[3]
        skill_env = _load_skill_env(skill_root)
        gateway_token = _load_gateway_token()
        log_handles: list[object] = []

        try:
            for role, command in zip(ROLE_NAMES, self.describe_launch_commands(job_id=job_id), strict=True):
                stdout_path = logs_dir / f"{role}.stdout.log"
                stderr_path = logs_dir / f"{role}.stderr.log"
                stdout_handle = stdout_path.open("w", encoding="utf-8")
                stderr_handle = stderr_path.open("w", encoding="utf-8")
                try:
                    env = os.environ.copy()
                    env.update(skill_env)
                    env["PYTHONUNBUFFERED"] = "1"  # Force unbuffered output so logs appear in real-time
                    env["OPENCLAW_JOB_ID"] = job_id
                    if gateway_token:
                        env["GATEWAY_TOKEN"] = gateway_token
                    process = subprocess.Popen(command, stdout=stdout_handle, stderr=stderr_handle, env=env)
                except Exception:
                    stdout_handle.close()
                    stderr_handle.close()
                    raise
                log_handles.extend([stdout_handle, stderr_handle])
                processes.append(process)
                process_records.append(
                    {
                        "role": role,
                        "command": command,
                        "pid": getattr(process, "pid", None),
                        "stdout_log": str(stdout_path),
                        "stderr_log": str(stderr_path),
                    }
                )
        finally:
            for handle in log_handles:
                try:
                    handle.close()
                except Exception:
                    pass

        self.write_active_job_lock(job_id=job_id)

        manifest_path = logs_dir / "process_manifest.json"
        manifest_path.write_text(
            json.dumps(process_records, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return processes

    def write_active_job_lock(self, *, job_id: str) -> None:
        lock_path = self.active_job_lock_path
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path.write_text(job_id, encoding="utf-8")

    def read_active_job_lock(self) -> str | None:
        lock_path = self.active_job_lock_path
        if not lock_path.exists():
            return None
        return lock_path.read_text(encoding="utf-8").strip() or None

    def clear_active_job_lock(self) -> None:
        lock_path = self.active_job_lock_path
        if lock_path.exists():
            lock_path.unlink()

    def has_active_job_lock(self, *, job_id: str) -> bool:
        return self.read_active_job_lock() == job_id

    def can_start_new_job(self) -> bool:
        return self.read_active_job_lock() is None


def _run_role(role: str, job_id: str) -> int:
    if role not in ROLE_NAMES:
        raise ValueError(f"Unsupported role: {role}")

    runtime_root = _resolve_runtime_root()
    db = RuntimeDatabase(runtime_root / "state.db")
    db.initialize()

    if role == "jd-worker":
        # build_default_jd_worker().run_job(db=db, job_id=job_id)
        # return 0
        pass

    idle_deadline = time.monotonic() + ROLE_MAX_IDLE_SECONDS
    while True:
        job = db.get_job(job_id)
        if job is None:
            raise ValueError(f"Unknown job_id: {job_id}")
        job_status = job.status.value if hasattr(job.status, "value") else str(job.status)
        if job_status in TERMINAL_JOB_STATUSES:
            return 0

        did_work = False
        if role == "orchestrator":
            status = RuntimeOrchestrator(db=db).run_job(job_id=job_id)
            normalized_status = status.value if hasattr(status, "value") else str(status)
            did_work = normalized_status != "running"
            if normalized_status == "completed":
                lock_path = Path(runtime_root) / "active_job.lock"
                if lock_path.exists():
                    lock_path.unlink()
                return 0
        elif role == "jd-worker":
            latest_plan = db.get_latest_search_plan(job_id=job_id)
            if latest_plan is None:
                did_work = build_default_jd_worker().run_job(db=db, job_id=job_id, planning_mode="initial") is not None
            else:
                latest_request = db.get_latest_event(job_id=job_id, event_type_prefix="orchestrator.requested_new_plan")
                request_payload = latest_request["payload"] if latest_request is not None else {}
                requested_strategy = str(request_payload.get("strategy", "")).strip()
                source_plan_index = request_payload.get("source_plan_index")
                if requested_strategy in {"widen", "tighten"} and source_plan_index == latest_plan["plan_index"]:
                    did_work = build_default_jd_worker().run_job(
                        db=db,
                        job_id=job_id,
                        planning_mode=requested_strategy,
                    ) is not None
                else:
                    did_work = False
        elif role == "browser-worker":
            did_work = BrowserWorker().run_job(db=db, job_id=job_id, runtime_root=runtime_root) > 0
        elif role == "resume-worker":
            # Robustness: auto-restart on unhandled exceptions (up to 3 times)
            restart_count = 0
            max_restarts = 3
            while True:
                try:
                    did_work = build_default_resume_worker().run_job(db=db, job_id=job_id) is not None
                    break  # Success — exit restart loop
                except Exception as exc:
                    restart_count += 1
                    db.record_event(
                        job_id=job_id,
                        event_type=f"{role}.crash_and_restart",
                        payload={"restart_count": restart_count, "error": str(exc)[:500]},
                    )
                    print(f"[CRASH] {role} failed (attempt {restart_count}/{max_restarts}): {exc}")
                    if restart_count >= max_restarts:
                        print(f"[FATAL] {role} exhausted all {max_restarts} restart attempts, marking job failed")
                        db.update_job_status(job_id=job_id, status="failed_recoverable")
                        return 1
                    time.sleep(3)  # Brief cooldown before restart
        else:
            raise ValueError(f"Unsupported role: {role}")

        if did_work:
            idle_deadline = time.monotonic() + ROLE_MAX_IDLE_SECONDS
        elif role != "orchestrator" and time.monotonic() >= idle_deadline:
            db.record_event(
                job_id=job_id,
                event_type=f"{role}.idle_timeout",
                payload={"idle_seconds": ROLE_MAX_IDLE_SECONDS},
            )
            return 0

        time.sleep(ROLE_POLL_INTERVAL_SECONDS)


def _resolve_runtime_root() -> Path:
    launcher_path = Path(__file__).resolve()
    project_root = launcher_path.parents[3]
    return project_root / "runtime"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="liepin_skill.runtime.launcher")
    parser.add_argument("role", choices=ROLE_NAMES)
    parser.add_argument("--job-id", required=True)
    args = parser.parse_args(argv)
    return _run_role(args.role, args.job_id)


if __name__ == "__main__":
    raise SystemExit(main())
