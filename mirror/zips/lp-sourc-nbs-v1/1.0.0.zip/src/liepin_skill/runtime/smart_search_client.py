from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Protocol, TypedDict

from liepin_skill.runtime.llm_clients import ExternalClientError
from liepin_skill.runtime.runtime_config import (
    SMART_SEARCH_API_KEY_ENV,
    SMART_SEARCH_ENDPOINT_ENV,
    read_optional_env,
)


class SmartSearchEnrichment(TypedDict, total=False):
    aliases: list[str]
    industry_terms: list[str]


class SmartSearchClient(Protocol):
    def enrich(self, jd_text: str, seed_terms: list[str]) -> SmartSearchEnrichment:
        raise NotImplementedError


def build_smart_search_client_from_env(env: dict[str, str] | None = None) -> SmartSearchClient:
    source = env if env is not None else os.environ
    endpoint = read_optional_env(SMART_SEARCH_ENDPOINT_ENV, source)
    api_key = read_optional_env(SMART_SEARCH_API_KEY_ENV, source)
    if endpoint:
        return HttpSmartSearchClient(endpoint=endpoint, api_key=api_key)
    return DeterministicSmartSearchClient()


@dataclass(slots=True)
class DeterministicSmartSearchClient:
    def enrich(self, jd_text: str, seed_terms: list[str]) -> SmartSearchEnrichment:
        aliases = [term for term in seed_terms if term]
        lowered = jd_text.lower()
        industry_terms: list[str] = []
        if "semiconductor" in lowered or "芯片" in jd_text:
            industry_terms.extend(["semiconductor", "芯片"])
        if "sales" in lowered or "销售" in jd_text:
            aliases.extend(["sales", "销售"])
        deduped_aliases = _dedupe(aliases)[:6]
        deduped_industries = _dedupe(industry_terms)[:4]
        return {
            "aliases": deduped_aliases,
            "industry_terms": deduped_industries,
        }


@dataclass(slots=True)
class HttpSmartSearchClient:
    endpoint: str
    api_key: str | None = None
    timeout_seconds: int = 20

    def enrich(self, jd_text: str, seed_terms: list[str]) -> SmartSearchEnrichment:
        payload = json.dumps(
            {
                "jd_text": jd_text,
                "seed_terms": seed_terms,
            },
            ensure_ascii=False,
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        request = urllib.request.Request(
            self.endpoint,
            data=payload,
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                parsed = json.loads(response.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise ExternalClientError(f"Smart-search request failed: {exc}") from exc
        except json.JSONDecodeError as exc:
            raise ExternalClientError("Smart-search response was not valid JSON") from exc

        aliases = parsed.get("aliases", [])
        industry_terms = parsed.get("industry_terms", [])
        if not isinstance(aliases, list) or not isinstance(industry_terms, list):
            raise ExternalClientError("Smart-search payload must include list fields for aliases and industry_terms")
        return {
            "aliases": [value for value in aliases if isinstance(value, str)],
            "industry_terms": [value for value in industry_terms if isinstance(value, str)],
        }


def _dedupe(values: list[str]) -> list[str]:
    seen: list[str] = []
    for value in values:
        normalized = value.strip()
        if normalized and normalized not in seen:
            seen.append(normalized)
    return seen
