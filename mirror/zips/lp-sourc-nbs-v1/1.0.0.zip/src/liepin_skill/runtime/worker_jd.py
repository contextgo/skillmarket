from __future__ import annotations

import json
from dataclasses import dataclass
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.llm_clients import (
    JDPlanningPayload,
    PlanningClient,
    build_planning_client_from_env,
)
from liepin_skill.runtime.runtime_models import OrGroup, OrGroupSearchPlan


@dataclass(frozen=True, slots=True)
class JDWorkerOutput:
    jd_compact_profile: dict[str, Any]
    search_plan: OrGroupSearchPlan


class JDWorker:
    def __init__(
        self,
        *,
        planning_client: PlanningClient,
    ) -> None:
        self.planning_client = planning_client

    def build_initial_output(
        self,
        *,
        jd_text: str,
        planning_mode: str = "initial",
        previous_plan: dict[str, Any] | None = None,
    ) -> JDWorkerOutput:
        plan_payload = self.planning_client.build_plan(
            jd_text=jd_text,
            seed_profile={},
            enrichment={},
            planning_mode=planning_mode,
            previous_plan=previous_plan,
        )
        validated_plan = self._validate_plan_payload(plan_payload)
        return JDWorkerOutput(
            jd_compact_profile=dict(validated_plan["jd_compact_profile"]),
            search_plan=self._convert_search_plan(validated_plan["or_group_search_plan"]),
        )

    def _validate_plan_payload(self, payload: Any) -> JDPlanningPayload:
        validated_payload = self._require_mapping(payload, "planning payload")
        
        # Fallback if LLM didn't include jd_compact_profile (defensive)
        if "jd_compact_profile" not in validated_payload:
            print("[WARN] jd_compact_profile missing from LLM response, using minimal default")
            validated_payload["jd_compact_profile"] = {
                "target_role_summary": "",
                "must_have_signals": [],
                "preferred_signals": [],
                "hard_rejects": [],
                "city_expectation": [],
                "seniority_band": "",
            }
        
        compact_profile = self._require_mapping(
            self._require_field(validated_payload, "jd_compact_profile"),
            "jd_compact_profile",
        )
        plan_payload = self._require_mapping(
            self._require_field(validated_payload, "or_group_search_plan"),
            "or_group_search_plan",
        )
        return {
            "jd_compact_profile": {
                "target_role_summary": self._require_text(
                    self._require_field(compact_profile, "target_role_summary"),
                    "jd_compact_profile.target_role_summary",
                ),
                "must_have_signals": self._coerce_text_sequence(
                    compact_profile.get("must_have_signals", []),
                    "jd_compact_profile.must_have_signals",
                ),
                "preferred_signals": self._coerce_text_sequence(
                    compact_profile.get("preferred_signals", []),
                    "jd_compact_profile.preferred_signals",
                ),
                "hard_rejects": self._coerce_text_sequence(
                    compact_profile.get("hard_rejects", []),
                    "jd_compact_profile.hard_rejects",
                ),
                "city_expectation": self._coerce_text_sequence(
                    compact_profile.get("city_expectation", []),
                    "jd_compact_profile.city_expectation",
                ),
                "seniority_band": self._require_text(
                    compact_profile.get("seniority_band", "Not Specified"),
                    "jd_compact_profile.seniority_band",
                ),
            },
            "or_group_search_plan": self._validate_or_group_search_plan(plan_payload),
        }

    def _validate_or_group_search_plan(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        groups_value = self._require_field(payload, "groups")
        groups_sequence = self._require_sequence(groups_value, "or_group_search_plan.groups")
        groups: list[dict[str, Any]] = []
        for index, group_value in enumerate(groups_sequence):
            group = self._require_mapping(group_value, f"or_group_search_plan.groups[{index}]")
            concept_value = group.get("concept", group.get("dimension_name"))
            terms_value = group.get("terms", group.get("or_terms"))
            groups.append(
                {
                    "group_index": self._require_int(
                        self._require_field(group, "group_index"),
                        f"or_group_search_plan.groups[{index}].group_index",
                    ),
                    "concept": self._require_text(
                        concept_value,
                        f"or_group_search_plan.groups[{index}].concept",
                    ),
                    "terms": self._coerce_text_sequence(
                        terms_value,
                        f"or_group_search_plan.groups[{index}].terms",
                    ),
                }
            )

        return {
            "groups": groups,
            "active_group_count": self._require_int(
                payload.get("active_group_count", len(groups)),
                "or_group_search_plan.active_group_count",
            ),
            "current_city": self._coerce_text_sequence(
                payload.get("current_city", []),
                "or_group_search_plan.current_city",
            ),
            "expected_city": self._coerce_text_sequence(
                payload.get("expected_city", []),
                "or_group_search_plan.expected_city",
            ),
            "experience_filter": self._require_optional_text(
                payload.get("experience_filter"),
                "or_group_search_plan.experience_filter",
            ),
            "optional_filters": self._require_mapping(
                payload.get("optional_filters", {}),
                "or_group_search_plan.optional_filters",
            ),
        }

    def _convert_search_plan(self, payload: Mapping[str, Any]) -> OrGroupSearchPlan:
        groups = tuple(
            OrGroup(
                group_index=group["group_index"],
                concept=group["concept"],
                terms=tuple(group["terms"]),
            )
            for group in payload["groups"]
        )
        return OrGroupSearchPlan(
            groups=groups,
            active_group_count=payload["active_group_count"],
            current_city=tuple(payload.get("current_city", [])),
            expected_city=tuple(payload.get("expected_city", [])),
            experience_filter=payload.get("experience_filter"),
            optional_filters=payload.get("optional_filters", {}),
        )

    def _require_field(self, payload: Mapping[str, Any], field_name: str) -> Any:
        if field_name not in payload:
            raise KeyError(f"Missing required field: {field_name}")
        return payload[field_name]

    def _require_mapping(self, value: Any, field_name: str) -> Mapping[str, Any]:
        if not isinstance(value, Mapping):
            raise TypeError(f"{field_name} must be a mapping")
        return value

    def _require_sequence(self, value: Any, field_name: str) -> Sequence[Any]:
        if isinstance(value, str) or not isinstance(value, Sequence):
            raise TypeError(f"{field_name} must be a sequence, not {type(value).__name__}")
        return value

    def _coerce_text_sequence(self, value: Any, field_name: str) -> tuple[str, ...]:
        sequence = self._require_sequence(value, field_name)
        items: list[str] = []
        for index, item in enumerate(sequence):
            if not isinstance(item, str):
                raise TypeError(f"{field_name}[{index}] must be a string")
            items.append(item)
        return tuple(items)

    def _require_text(self, value: Any, field_name: str) -> str:
        if not isinstance(value, str):
            raise TypeError(f"{field_name} must be a string")
        return value

    def _require_optional_text(self, value: Any, field_name: str) -> str | None:
        if value is None:
            return None
        return self._require_text(value, field_name)

    def _require_int(self, value: Any, field_name: str) -> int:
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"{field_name} must be an integer")
        return value

    def run_job(self, *, db: RuntimeDatabase, job_id: str, planning_mode: str = "initial") -> JDWorkerOutput:
        job = db.get_job(job_id)
        if job is None:
            raise ValueError(f"Unknown job_id: {job_id}")

        jd_text = self._load_jd_text(Path(job.source_jd_path))
        previous_plan_record = db.get_latest_search_plan(job_id=job_id)
        previous_plan_payload = previous_plan_record["search_plan"] if previous_plan_record is not None else None
        output = self.build_initial_output(
            jd_text=jd_text,
            planning_mode=planning_mode,
            previous_plan=previous_plan_payload,
        )
        plan_payload = {
            "groups": [
                {
                    "group_index": group.group_index,
                    "concept": group.concept,
                    "terms": list(group.terms),
                }
                for group in output.search_plan.groups
            ],
            "active_group_count": output.search_plan.active_group_count,
            "current_city": list(output.search_plan.current_city),
            "expected_city": list(output.search_plan.expected_city),
            "experience_filter": output.search_plan.experience_filter,
            "optional_filters": dict(output.search_plan.optional_filters),
        }
        plan_id = db.insert_search_plan(
            job_id=job_id,
            jd_compact_profile=output.jd_compact_profile,
            search_plan=plan_payload,
        )
        db.record_event(
            job_id=job_id,
            event_type="jd_worker.plan_created",
            payload={
                "plan_id": plan_id,
                "active_group_count": output.search_plan.active_group_count,
                "planning_mode": planning_mode,
            },
        )
        return output

    def _load_jd_text(self, source_path: Path) -> str:
        raw_text = source_path.read_text(encoding="utf-8")
        if source_path.suffix.lower() == ".json":
            try:
                payload = json.loads(raw_text)
            except json.JSONDecodeError:
                return raw_text
            if isinstance(payload, Mapping):
                for key in ("position_scope", "jd_text", "description"):
                    value = payload.get(key)
                    if isinstance(value, str) and value.strip():
                        return value.strip()
            return raw_text
        return raw_text


def build_default_jd_worker() -> JDWorker:
    return JDWorker(
        planning_client=build_planning_client_from_env(),
    )
