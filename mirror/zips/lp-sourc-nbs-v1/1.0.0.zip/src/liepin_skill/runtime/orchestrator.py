from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.runtime_models import JobStatus


def should_request_new_plan(*, result_count: int, linked_count: int, search_change_count: int) -> bool:
    return classify_plan_adjustment(
        result_count=result_count,
        linked_count=linked_count,
        search_change_count=search_change_count,
    ) is not None


def classify_plan_adjustment(*, result_count: int, linked_count: int, search_change_count: int) -> str | None:
    if result_count > 200:
        return "tighten"
    return "widen"


@dataclass(slots=True)
class RuntimeOrchestrator:
    db: RuntimeDatabase

    def _promote_previews_to_detail_tasks(self, job_id: str) -> None:
        """Find completed preview evals that recommended open_detail and promote them to detail tasks.
        IMPORTANT: only promote for pages that have fully finished preview evaluation
        (i.e. no remaining pending_preview_eval rows on that page)."""
        with self.db._connect() as conn:
            rows = conn.execute(
                """
                SELECT q.queue_id
                FROM candidate_queue q
                JOIN candidate_evaluations e ON q.queue_id = e.queue_id
                WHERE q.job_id = ?
                  AND q.status = 'completed'
                  AND e.stage = 'preview'
                  AND e.decision = 'open_detail'
                  AND NOT EXISTS (
                      SELECT 1 FROM candidate_evaluations e2
                      WHERE e2.queue_id = q.queue_id AND e2.stage = 'detail'
                  )
                  AND NOT EXISTS (
                      SELECT 1 FROM candidate_queue q2
                      WHERE q2.job_id = q.job_id
                        AND q2.page_number = q.page_number
                        AND q2.status = 'pending_preview_eval'
                  )
                """,
                (job_id,),
            ).fetchall()

            for row in rows:
                queue_id = row[0]
                self.db.update_candidate_queue_status(queue_id=queue_id, status='pending_detail_harvest')
                self.db.record_event(
                    job_id=job_id,
                    event_type="orchestrator.promoted_to_detail",
                    payload={"queue_id": queue_id},
                )

    def _promote_link_decisions_to_communication_tasks(self, job_id: str) -> None:
        """Compatibility shim: communication promotion now happens directly in resume-worker after detail eval."""
        self.db.record_event(
            job_id=job_id,
            event_type="orchestrator.communication_promotion_noop",
            payload={"reason": "detail_link_promoted_directly_by_resume_worker"},
        )

    def _trigger_batch_preview_eval_if_needed(self, job_id: str) -> bool:
        """Check if there are newly collected previews that need batch evaluation.
        Returns True if a batch eval request was recorded."""
        latest_collected = self.db.get_latest_event(
            job_id=job_id, event_type_prefix="browser_worker.previews_collected"
        )
        latest_requested = self.db.get_latest_event(
            job_id=job_id, event_type_prefix="orchestrator.batch_preview_eval_requested"
        )
        latest_batch_done = self.db.get_latest_event(
            job_id=job_id, event_type_prefix="resume_worker.batch_preview_eval_done"
        )

        if not latest_collected:
            return False

        collected_time = latest_collected["created_at"]
        requested_time = latest_requested["created_at"] if latest_requested else None
        done_time = latest_batch_done["created_at"] if latest_batch_done else None

        page_number = (latest_collected.get("payload") or {}).get("page_number")
        if page_number is None:
            return False

        # Only request if this collected page has not yet been requested,
        # or if the request exists but no newer batch completion exists.
        needs_request = (
            requested_time is None
            or collected_time > requested_time
            or (done_time is None and collected_time >= requested_time)
            or (done_time is not None and requested_time is not None and requested_time > done_time)
        )

        if needs_request:
            self.db.record_event(
                job_id=job_id,
                event_type="orchestrator.batch_preview_eval_requested",
                payload={"page_number": page_number},
            )
            print(f"[Orchestrator] Batch preview eval requested for page {page_number}")
            return True
        return False

    def _count_unpromoted_open_detail(self, job_id: str) -> int:
        """Count candidates that have been evaluated as 'open_detail' in preview stage
        but have NOT yet been promoted to pending_detail_harvest.
        These are in 'completed' status with a pending promotion — the browser must wait."""
        with self.db._connect() as conn:
            row = conn.execute(
                """
                SELECT COUNT(*)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.status = 'completed'
                  AND EXISTS (
                      SELECT 1 FROM candidate_evaluations e
                      WHERE e.queue_id = q.queue_id
                        AND e.stage = 'preview'
                        AND e.decision = 'open_detail'
                  )
                  AND NOT EXISTS (
                      SELECT 1 FROM candidate_evaluations e2
                      WHERE e2.queue_id = q.queue_id
                        AND e2.stage = 'detail'
                  )
                """,
                (job_id,),
            ).fetchone()
        return int(row[0]) if row else 0

    def _count_pending_detail_harvest(self, job_id: str) -> int:
        """Count candidates currently in pending_detail_harvest status."""
        return self.db.count_candidate_queue_rows(
            job_id=job_id,
            statuses=("pending_detail_harvest",),
        )

    def run_job(self, *, job_id: str) -> JobStatus | str:
        job = self.db.get_job(job_id)
        if job is None:
            raise ValueError(f"Unknown job_id: {job_id}")

        if job.status != JobStatus.RUNNING:
            self.db.update_job_status(job_id=job_id, status=JobStatus.RUNNING)
            self.db.record_event(
                job_id=job_id,
                event_type="orchestrator.started",
                payload={"target_position_name": job.target_position_name},
            )

        latest_plan = self.db.get_latest_search_plan(job_id=job_id)
        if latest_plan is None:
            self.db.record_event(
                job_id=job_id,
                event_type="orchestrator.waiting_for_plan",
                payload={},
            )
            return JobStatus.RUNNING

        # 1. Check for target reached
        linked_count = self.db.count_candidate_evaluations(job_id=job_id, decision="link")
        if linked_count >= job.target_link_count:
            self.db.update_job_status(job_id=job_id, status=JobStatus.COMPLETED)
            self.db.record_event(
                job_id=job_id,
                event_type="orchestrator.completed",
                payload={"reason": "target_link_count_reached", "linked_count": linked_count},
            )
            return JobStatus.COMPLETED

        # 2. Trigger batch preview eval for newly collected pages
        self._trigger_batch_preview_eval_if_needed(job_id=job_id)

        # 3. Promote previews to details, preferring the earliest pending page
        next_pending_page = self.db.get_next_pending_page_number(job_id=job_id)
        if next_pending_page is not None:
            self.db.record_event(
                job_id=job_id,
                event_type="orchestrator.page_focus",
                payload={"page_number": next_pending_page},
            )
        self._promote_previews_to_detail_tasks(job_id=job_id)

        # 3. Promote link decisions to communications
        self._promote_link_decisions_to_communication_tasks(job_id=job_id)

        # 4. Check current queue status
        pending_candidate_count = self.db.count_candidate_queue_rows(
            job_id=job_id,
            statuses=("pending_preview_eval", "pending_detail_harvest", "detail_harvested", "pending_communication", "claimed"),
        )
        next_pending_page = self.db.get_next_pending_page_number(job_id=job_id)

        # 5. Adaptive Strategy:
        # - result_count > 200: tighten immediately, skip spending resume-worker resources on current pool
        # - result_count <= 200: finish current pool first, then widen if target still not reached
        latest_collected_event = self.db.get_latest_event(
            job_id=job_id,
            event_type_prefix="browser_worker.previews_collected",
        )
        if latest_collected_event:
            try:
                collected = latest_collected_event.get("payload") or {}
                collected_plan_id = str(collected.get("plan_id", ""))
                latest_plan_id = str(latest_plan["plan_id"])

                # Ensure we are looking at the result count for the CURRENT plan
                if collected_plan_id != latest_plan_id:
                    print(f"[DEBUG] Adaptive skip: plan_id mismatch {collected_plan_id} != {latest_plan_id}")
                    return JobStatus.RUNNING

                result_count = int(collected.get("result_count", 0))
                skipped_due_to_large_result = bool(collected.get("skipped_due_to_large_result", False))
                print(
                    f"[DEBUG] Adaptive check: result_count={result_count}, "
                    f"linked_count={linked_count}, plan_index={latest_plan['plan_index']}, "
                    f"skipped_due_to_large_result={skipped_due_to_large_result}"
                )

                adjustment = classify_plan_adjustment(
                    result_count=result_count,
                    linked_count=linked_count,
                    search_change_count=latest_plan["plan_index"],
                )
                print(f"[DEBUG] adjustment={adjustment}")

                if adjustment == "tighten" or skipped_due_to_large_result:
                    print("[DEBUG] Executing tighten strategy")
                    abandoned_count = self.db.abandon_pending_work(
                        job_id=job_id,
                        reason="tighten_without_draining_large_pool",
                    )
                    print(f"[DEBUG] abandoned_count={abandoned_count}")
                    self._request_replan(job_id, latest_plan, result_count, "tighten")
                    if abandoned_count > 0:
                        self.db.record_event(
                            job_id=job_id,
                            event_type="orchestrator.tighten_fast_path",
                            payload={"abandoned_pending_count": abandoned_count},
                        )
                elif adjustment == "widen":
                    # CRITICAL: Widen must wait for the ENTIRE serial pipeline to drain.
                    # The pipeline is: preview_eval → (promote) → detail_harvest →
                    #   detail_eval → (promote) → communication → done
                    # We must NOT widen until ALL candidates from this plan have been
                    # fully processed through the pipeline.

                    # Check 1: completed + open_detail pending promotion to detail_harvest
                    with self.db._connect() as conn:
                        pending_promotion = conn.execute(
                            """
                            SELECT COUNT(*)
                            FROM candidate_queue q
                            WHERE q.job_id = ?
                              AND q.status = 'completed'
                              AND EXISTS (
                                  SELECT 1 FROM candidate_evaluations e
                                  WHERE e.queue_id = q.queue_id
                                    AND e.stage = 'preview'
                                    AND e.decision = 'open_detail'
                              )
                              AND NOT EXISTS (
                                  SELECT 1 FROM candidate_evaluations e2
                                  WHERE e2.queue_id = q.queue_id
                                    AND e2.stage = 'detail'
                              )
                            """,
                            (job_id,),
                        ).fetchone()
                    pending_promotion_count = int(pending_promotion[0]) if pending_promotion else 0

                    # Check 2: completed + detail evaluated as 'link' pending communication
                    with self.db._connect() as conn:
                        pending_comm_promotion = conn.execute(
                            """
                            SELECT COUNT(*)
                            FROM candidate_queue q
                            WHERE q.job_id = ?
                              AND q.status = 'completed'
                              AND EXISTS (
                                  SELECT 1 FROM candidate_evaluations e
                                  WHERE e.queue_id = q.queue_id
                                    AND e.stage = 'detail'
                                    AND e.decision = 'link'
                              )
                            """,
                            (job_id,),
                        ).fetchone()
                    pending_comm_promotion_count = int(pending_comm_promotion[0]) if pending_comm_promotion else 0

                    # Also check detail_harvested (waiting for resume-worker to evaluate detail)
                    detail_harvested_count = self.db.count_candidate_queue_rows(
                        job_id=job_id,
                        statuses=("detail_harvested",),
                    )

                    # The pool is ONLY finished when ALL pipeline stages are empty:
                    # - No pending preview evals
                    # - No completed waiting for promotion to detail_harvest
                    # - No pending_detail_harvest
                    # - No detail_harvested
                    # - No completed waiting for communication promotion
                    # - No pending_communication
                    is_pool_finished = (
                        pending_candidate_count == 0
                        and next_pending_page is None
                        and pending_promotion_count == 0
                        and pending_comm_promotion_count == 0
                        and detail_harvested_count == 0
                    )
                    if is_pool_finished:
                        self._request_replan(job_id, latest_plan, result_count, "widen")
                    else:
                        reasons = []
                        if pending_candidate_count > 0:
                            reasons.append(f"pending_queue={pending_candidate_count}")
                        if next_pending_page is not None:
                            reasons.append(f"next_page={next_pending_page}")
                        if pending_promotion_count > 0:
                            reasons.append(f"pending_promotion={pending_promotion_count}")
                        if pending_comm_promotion_count > 0:
                            reasons.append(f"pending_comm_promotion={pending_comm_promotion_count}")
                        if detail_harvested_count > 0:
                            reasons.append(f"detail_harvested={detail_harvested_count}")
                        print(f"[DEBUG] Widen deferred: pipeline not drained ({', '.join(reasons)})")
            except Exception as e:
                print(f"[ERROR] Adaptive strategy failed: {e}")
                import traceback
                traceback.print_exc()

        # 6. Page-by-page collection: signal browser to collect next page when
        #    the current page's pipeline has fully drained and target not met.
        #    CRITICAL: Also wait for browser_worker.page_ready_for_navigation to ensure 
        #    modal is closed and we are back on the search list.
        max_collected = self.db.get_max_collected_page(
            job_id=job_id,
            plan_id=latest_plan["plan_id"],
        )
        if max_collected > 0 and max_collected < 5:
            # Check pipeline drain (database layer)
            pipeline_complete = self.db.get_page_pipeline_complete(job_id=job_id, page_number=max_collected)
            
            # Check page ready for navigation (browser layer - modal closed)
            ready_event = self.db.get_latest_event(
                job_id=job_id, 
                event_type_prefix="browser_worker.page_ready_for_navigation"
            )
            is_browser_ready = False
            if ready_event:
                try:
                    is_browser_ready = int(ready_event.get("payload", {}).get("page_number", 0)) == max_collected
                except:
                    is_browser_ready = False
            
            if pipeline_complete and is_browser_ready:
                self.db.record_event(
                    job_id=job_id,
                    event_type="orchestrator.collect_next_page",
                    payload={
                        "last_collected_page": max_collected,
                        "next_page": max_collected + 1,
                    },
                )
            elif pipeline_complete and not is_browser_ready:
                print(f"[DEBUG] Pipeline complete for page {max_collected}, but waiting for browser_worker.page_ready_for_navigation")

        next_pending_page = self.db.get_next_pending_page_number(job_id=job_id)
        self.db.record_event(
            job_id=job_id,
            event_type="orchestrator.plan_ready",
            payload={
                "plan_id": latest_plan["plan_id"],
                "plan_index": latest_plan["plan_index"],
                "next_pending_page": next_pending_page,
            },
        )

        return JobStatus.RUNNING

    def _request_replan(self, job_id: str, latest_plan: dict[str, Any], result_count: int, strategy: str) -> None:
        # Check if we already requested this specific adjustment for the current plan to avoid spamming
        last_request = self.db.get_latest_event(job_id=job_id, event_type_prefix="orchestrator.requested_new_plan")
        if last_request:
            payload = last_request["payload"]
            if payload.get("source_plan_index") == latest_plan["plan_index"] and payload.get("strategy") == strategy:
                return

        self.db.record_event(
            job_id=job_id,
            event_type="orchestrator.requested_new_plan",
            payload={
                "reason": "result_count_out_of_bounds",
                "count": result_count,
                "strategy": strategy,
                "source_plan_index": latest_plan["plan_index"],
            }
        )
        self.db.record_event(
            job_id=job_id,
            event_type=f"orchestrator.requested_plan_{strategy}",
            payload={
                "count": result_count,
                "source_plan_index": latest_plan["plan_index"],
            }
        )
