from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.launcher import RuntimeLauncher


def submit_job_from_criteria(
    launcher: RuntimeLauncher,
    criteria: Mapping[str, Any],
    source_jd_path: str,
    dry_run: bool = False,
) -> str:
    position_name = criteria.get("position_name") or criteria.get("target_position_name")
    if not position_name:
        raise ValueError("criteria must contain 'position_name' or 'target_position_name'")
    job = launcher.prepare_job(
        source_jd_path=source_jd_path,
        target_position_name=str(position_name),
        target_link_count=int(criteria["target_count"]),
    )
    runtime_root = Path(launcher.runtime_root)
    criteria_path = runtime_root / "jobs" / job.job_id / "jd_criteria.json"
    criteria_path.parent.mkdir(parents=True, exist_ok=True)
    criteria_path.write_text(
        json.dumps(dict(criteria), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    state_db_path = runtime_root / "state.db"
    if state_db_path.exists():
        RuntimeDatabase(state_db_path).update_job_source_jd_path(
            job_id=job.job_id,
            source_jd_path=str(criteria_path),
        )
    if not dry_run:
        launcher.launch_process_group(job_id=job.job_id)
    return job.job_id
