from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from types import MappingProxyType
from typing import Any, Literal, Mapping


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    RECOVERING = "recovering"
    FAILED = "failed"
    COMPLETED = "completed"
    PAUSED_AUTH_REQUIRED = "paused_auth_required"
    FAILED_RECOVERABLE = "failed_recoverable"

    @classmethod
    def from_db_value(cls, value: str) -> "JobStatus | str":
        try:
            return cls(value)
        except ValueError:
            return value


@dataclass(frozen=True, slots=True)
class RuntimeJob:
    job_id: str
    source_jd_path: str
    target_position_name: str
    target_link_count: int
    status: JobStatus | str
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class OrGroup:
    group_index: int
    concept: str
    terms: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "terms", tuple(self.terms))


@dataclass(frozen=True, slots=True)
class OrGroupSearchPlan:
    groups: tuple[OrGroup, ...]
    active_group_count: int
    current_city: tuple[str, ...]
    expected_city: tuple[str, ...]
    experience_filter: str | None
    optional_filters: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "groups", tuple(self.groups))
        object.__setattr__(self, "current_city", tuple(self.current_city))
        object.__setattr__(self, "expected_city", tuple(self.expected_city))
        object.__setattr__(self, "optional_filters", MappingProxyType(dict(self.optional_filters)))

        if self.active_group_count < 0:
            raise ValueError("active_group_count must be non-negative")
        if self.active_group_count > len(self.groups):
            object.__setattr__(self, "active_group_count", len(self.groups))


@dataclass(frozen=True, slots=True)
class SearchCapability:
    supports_compound_groups: bool


@dataclass(frozen=True, slots=True)
class ExecutableSearchPayload:
    mode: Literal["compound", "simple"]
    active_groups: tuple[tuple[str, ...], ...] | None
    simple_query: str | None
    current_city: tuple[str, ...]
    expected_city: tuple[str, ...]
    experience_filter: str | None
    optional_filters: Mapping[str, Any]
