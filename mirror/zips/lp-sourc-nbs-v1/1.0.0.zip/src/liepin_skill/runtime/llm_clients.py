from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, TypedDict

from liepin_skill.models import CandidateDecision
from liepin_skill.runtime.runtime_config import (
    JD_WORKER_LLM_API_KEY_ENV,
    JD_WORKER_LLM_BASE_URL_ENV,
    JD_WORKER_LLM_MODEL_ENV,
    RESUME_WORKER_LLM_API_KEY_ENV,
    RESUME_WORKER_LLM_BASE_URL_ENV,
    RESUME_WORKER_LLM_MODEL_ENV,
    read_optional_env,
)


class JDCompactProfilePayload(TypedDict):
    target_role_summary: str
    must_have_signals: list[str]
    preferred_signals: list[str]
    hard_rejects: list[str]
    city_expectation: list[str]
    seniority_band: str


class OrGroupPayload(TypedDict):
    group_index: int
    concept: str
    terms: list[str]


class OrGroupSearchPlanPayload(TypedDict):
    groups: list[OrGroupPayload]
    active_group_count: int
    current_city: list[str]
    expected_city: list[str]
    experience_filter: str | None
    optional_filters: dict[str, Any]


class JDPlanningPayload(TypedDict):
    jd_compact_profile: JDCompactProfilePayload
    or_group_search_plan: OrGroupSearchPlanPayload


class PlanningClient(Protocol):
    def build_plan(
        self,
        *,
        jd_text: str,
        seed_profile: dict[str, Any],
        enrichment: dict[str, Any],
        planning_mode: str = "initial",
        previous_plan: dict[str, Any] | None = None,
    ) -> JDPlanningPayload:
        raise NotImplementedError


class LightweightResumeClient(Protocol):
    def evaluate_preview(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        preview_payload: dict[str, Any],
    ) -> Any:
        raise NotImplementedError

    def evaluate_detail(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        detail_payload: dict[str, Any],
    ) -> Any:
        raise NotImplementedError

    def complete_batch_preview(
        self,
        *,
        jd_text: str,
        candidates_json: str,
        page_number: int,
    ) -> str:
        """Raw completion for batch preview evaluation. Returns JSON string."""
        raise NotImplementedError


class ExternalClientError(RuntimeError):
    """Raised when an external HTTP-backed helper fails."""


def build_planning_client_from_env(env: dict[str, str] | None = None) -> PlanningClient:
    source = env if env is not None else os.environ
    base_url = read_optional_env(JD_WORKER_LLM_BASE_URL_ENV, source)
    model = read_optional_env(JD_WORKER_LLM_MODEL_ENV, source)
    api_key = read_optional_env(JD_WORKER_LLM_API_KEY_ENV, source) or source.get("GATEWAY_TOKEN")
    if base_url and model and api_key:
        return OpenAICompatiblePlanningClient(
            base_url=base_url,
            api_key=api_key,
            model=model,
        )
    raise ExternalClientError(
        "Missing required LLM configuration for JD planning (base_url, model, or api_key). "
        "Deterministic fallback has been disabled."
    )


def build_resume_client_from_env(env: dict[str, str] | None = None) -> LightweightResumeClient | None:
    source = env if env is not None else os.environ
    base_url = read_optional_env(RESUME_WORKER_LLM_BASE_URL_ENV, source)
    model = read_optional_env(RESUME_WORKER_LLM_MODEL_ENV, source)
    api_key = read_optional_env(RESUME_WORKER_LLM_API_KEY_ENV, source) or source.get("GATEWAY_TOKEN")
    if base_url and model and api_key:
        return OpenAICompatibleResumeClient(
            base_url=base_url,
            api_key=api_key,
            model=model,
        )
    return None


@dataclass(slots=True)
class DeterministicPlanningClient:
    def build_plan(
        self,
        *,
        jd_text: str,
        seed_profile: dict[str, Any],
        enrichment: dict[str, Any],
        planning_mode: str = "initial",
        previous_plan: dict[str, Any] | None = None,
    ) -> JDPlanningPayload:
        city_expectation = _extract_city_expectation(jd_text)
        seniority_band = _extract_seniority_band(jd_text)
        base_terms = [term for term in _extract_terms_from_text(jd_text) if len(term) >= 2]
        groups = _build_groups(base_terms)
        while len(groups) < 5:
            index = len(groups) + 1
            groups.append(
                {
                    "group_index": index,
                    "concept": f"dimension_{index}",
                    "terms": [f"placeholder_{index}"],
                }
            )
        groups = groups[:5]

        return {
            "jd_compact_profile": {
                "target_role_summary": jd_text.strip().splitlines()[0][:120] or "Liepin sourcing target",
                "must_have_signals": base_terms[:5],
                "preferred_signals": base_terms[5:10],
                "hard_rejects": [],
                "city_expectation": city_expectation,
                "seniority_band": seniority_band,
            },
            "or_group_search_plan": {
                "groups": groups,
                "active_group_count": len(groups),
                "current_city": city_expectation,
                "expected_city": [],
                "experience_filter": None if seniority_band == "open" else seniority_band,
                "optional_filters": {
                    "current_industry": [],
                    "current_function": [],
                    "company": [],
                    "education": None,
                    "source": "deterministic_fallback",
                },
            },
        }


@dataclass(slots=True)
class OpenAICompatiblePlanningClient:
    base_url: str
    api_key: str
    model: str
    timeout_seconds: int = 120

    def build_plan(
        self,
        *,
        jd_text: str,
        seed_profile: dict[str, Any],
        enrichment: dict[str, Any],
        planning_mode: str = "initial",
        previous_plan: dict[str, Any] | None = None,
    ) -> JDPlanningPayload:
        user_payload = {
            "jd_text": jd_text,
            "planning_mode": planning_mode,
            "previous_plan": previous_plan,
            "generation_rules": {
                "group_count": 5,
                "group_relation": "AND",
                "intra_group_relation": "OR",
                "term_count_per_group": "4-8 preferred",
                "language": "中文为主，必要时保留英文/缩写",
                "must_include_english_term_in_each_group": True,
                "prioritize_dimensions": [
                    "industry",
                    "product",
                    "technical_skills",
                    "notable_companies",
                    "upstream_downstream_companies",
                    "target_persona",
                    "job_type"
                ],
                "notes": [
                    "优先使用简历常见写法，而非纯JD写法",
                    "可补充全称/缩写/别称/旧称/上下位词",
                    "hard_rejects保留但不要凭空编造",
                    "如果JD里没有明确城市或职级，不要猜测，留空即可"
                ]
            },
            "required_schema": {
                "jd_compact_profile": {
                    "target_role_summary": "str",
                    "must_have_signals": ["str"],
                    "preferred_signals": ["str"],
                    "hard_rejects": ["str"],
                    "city_expectation": ["str"],
                    "seniority_band": "str",
                },
                "or_group_search_plan": {
                    "groups": [
                        {
                            "group_index": "int",
                            "concept": "str (dimension name)",
                            "terms": ["str"]
                        }
                    ],
                    "active_group_count": "int (=5)",
                    "current_city": ["str"],
                    "expected_city": ["str"],
                    "experience_filter": "str|null",
                    "optional_filters": {}
                }
            },
            "json_example": {
                "or_group_search_plan": {
                    "groups": [
                        {"group_index": 1, "concept": "维度名称", "terms": ["term1", "term2", "term3"]},
                        {"group_index": 2, "concept": "维度名称", "terms": ["term1", "term2", "term3"]},
                        {"group_index": 3, "concept": "维度名称", "terms": ["term1", "term2", "term3"]},
                        {"group_index": 4, "concept": "维度名称", "terms": ["term1", "term2", "term3"]},
                        {"group_index": 5, "concept": "维度名称", "terms": ["term1", "term2", "term3"]}
                    ]
                }
            }
        }
        system_prompt = (
            "你是一个资深招聘检索策略专家。你的任务不是总结JD，而是把JD转成可用于人才搜寻的关键词检索条件。"
            "当 planning_mode=initial 时，直接生成第一版检索方案。"
            "当 planning_mode=widen 时，基于 previous_plan 放宽优化，提高召回率，但保持相关性。"
            "当 planning_mode=tighten 时，基于 previous_plan 收窄优化，提高精准度，删除宽泛噪音词。"
            "请直接生成恰好5组AND关系的检索维度，每组内部是OR关系，优先使用候选人真实简历中会出现的写法。"
            "每组聚焦单一维度，尽量避免跨维度复合关键词；不同组尽量不要重复。"
            "必须保留与现有运行时兼容的JSON结构，不要输出Markdown，不要输出解释。"
        )

        last_error: Exception | None = None
        for planning_attempt in range(1, 3):
            response_json = _post_chat_completion(
                base_url=self.base_url,
                api_key=self.api_key,
                model=self.model,
                timeout_seconds=self.timeout_seconds,
                system_prompt=system_prompt,
                user_payload=user_payload,
            )
            try:
                result = _extract_json_content(response_json)
                print(f"[DEBUG] Planning parse success on attempt {planning_attempt}")
                print(f"[DEBUG] LLM response keys: {result.keys() if isinstance(result, dict) else type(result)}")
                print(f"[DEBUG] jd_compact_profile present: {'jd_compact_profile' in result if isinstance(result, dict) else 'N/A'}")
                return result
            except ExternalClientError as exc:
                last_error = exc
                print(f"[WARN] Planning parse failed on attempt {planning_attempt}: {exc}")
                if planning_attempt >= 2:
                    raise
                time.sleep(1)

        raise ExternalClientError(f"Planning parse failed after retry: {last_error}")


@dataclass(slots=True)
class OpenAICompatibleResumeClient:
    base_url: str
    api_key: str
    model: str
    timeout_seconds: int = 20

    def evaluate_preview(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        preview_payload: dict[str, Any],
    ) -> Any:
        return self._evaluate(
            stage="preview",
            jd_compact_profile=jd_compact_profile,
            candidate_payload=preview_payload,
        )

    def evaluate_detail(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        detail_payload: dict[str, Any],
    ) -> Any:
        return self._evaluate(
            stage="detail",
            jd_compact_profile=jd_compact_profile,
            candidate_payload=detail_payload,
        )

    def _evaluate(
        self,
        *,
        stage: str,
        jd_compact_profile: dict[str, Any],
        candidate_payload: dict[str, Any],
    ) -> CandidateDecision:
        user_payload = {
            "stage": stage,
            "jd_compact_profile": jd_compact_profile,
            "candidate_payload": candidate_payload,
            "required_schema": {
                "action": "preview->open_detail|skip ; detail->link|skip",
                "reason": "str",
                "matched_signals": ["str"],
                "risk_flags": ["str"],
            },
        }
        # Retry with escalating prompt strictness (up to 3 attempts)
        system_prompts = [
            (
                "You evaluate one Liepin candidate at a time. "
                "For preview stage, action must be one of {open_detail, skip}. "
                "For detail stage, action must be one of {link, skip}. "
                "Return JSON only with a concise reason."
            ),
            (
                "You evaluate one Liepin candidate at a time. "
                "For preview stage, action must be one of {open_detail, skip}. "
                "For detail stage, action must be one of {link, skip}. "
                "You MUST return a valid JSON object. Do NOT return bare text. "
                "Format: {\"action\": \"skip\", \"reason\": \"...\"}"
            ),
            (
                "CRITICAL: Return ONLY valid JSON. No other text. "
                "For preview stage, action must be one of {open_detail, skip}. "
                "For detail stage, action must be one of {link, skip}. "
                "Required fields: action, reason, matched_signals, risk_flags. "
                "Example: {\"action\":\"skip\",\"reason\":\"insufficient experience\",\"matched_signals\":[],\"risk_flags\":[]}"
            ),
        ]
        last_exception: Exception | None = None
        for attempt, prompt in enumerate(system_prompts):
            try:
                response_json = _post_chat_completion(
                    base_url=self.base_url,
                    api_key=self.api_key,
                    model=self.model,
                    timeout_seconds=self.timeout_seconds,
                    system_prompt=prompt,
                    user_payload=user_payload,
                )
                return CandidateDecision.model_validate(_extract_json_content(response_json))
            except ExternalClientError as exc:
                last_exception = exc
                print(f"[WARN] LLM evaluate attempt {attempt + 1} failed: {exc}")
                time.sleep(1)
                continue

        # All LLM attempts failed — try to extract decision from raw text as last resort
        print("[WARN] All LLM evaluate attempts failed, attempting raw text extraction")
        try:
            # Re-issue one last call and try to salvage
            response_json = _post_chat_completion(
                base_url=self.base_url,
                api_key=self.api_key,
                model=self.model,
                timeout_seconds=self.timeout_seconds,
                system_prompt=system_prompts[-1],
                user_payload=user_payload,
            )
            raw = _get_message_content(response_json)
            decision = _extract_decision_from_raw(raw)
            if decision is not None:
                print(f"[FALLBACK] Extracted decision from raw text: {decision.get('action')}")
                return CandidateDecision.model_validate(decision)
        except Exception as exc:
            print(f"[WARN] Raw text extraction also failed: {exc}")

        # Ultimate fallback: skip the candidate
        print("[FALLBACK] LLM completely failed, defaulting to skip")
        return CandidateDecision(
            action="skip",
            reason=f"LLM evaluation failed after {len(system_prompts)} attempts + raw extraction; defaulting to skip. Last error: {last_exception}",
        )

    def complete(self, prompt: str) -> str:
        """Raw completion — sends a raw text prompt and returns the raw response string.
        Used by batch preview eval and other raw LLM calls."""
        return _post_raw_completion(
            base_url=self.base_url,
            api_key=self.api_key,
            model=self.model,
            timeout_seconds=self.timeout_seconds,
            prompt=prompt,
        )

    def complete_batch_preview(
        self,
        *,
        jd_text: str,
        candidates_json: str,
        page_number: int,
    ) -> str:
        """Raw completion for batch preview evaluation. Returns raw response text."""
        system_prompt = (
            "You are evaluating candidates for a Liepin job search. "
            "Given the job requirements and a list of candidate previews, "
            "decide for each candidate whether to \"open_detail\" or \"skip\". "
            "Return ONLY a valid JSON array. No other text."
        )
        user_payload = (
            f"## Job Requirements\n{jd_text}\n\n"
            f"## Candidates (Page {page_number})\n{candidates_json}\n\n"
            f"## Rules\n"
            f"1. If a candidate clearly matches the requirements → \"open_detail\"\n"
            f"2. If a candidate clearly doesn't match → \"skip\"\n"
            f"3. If unsure → \"open_detail\" (detail eval will make the final call)\n\n"
            f"## Output Format\n"
            f'Return ONLY a valid JSON array: [{{"queue_id": "...", "action": "open_detail"}}, ...]'
        )

        for attempt in range(3):
            try:
                response_json = _post_chat_completion(
                    base_url=self.base_url,
                    api_key=self.api_key,
                    model=self.model,
                    timeout_seconds=max(self.timeout_seconds, 60),  # longer timeout for batch
                    system_prompt=system_prompt,
                    user_payload=user_payload,
                )
                content = _get_message_content(response_json)
                # Validate JSON
                json.loads(content)
                return content
            except ExternalClientError as exc:
                print(f"[WARN] Batch preview LLM attempt {attempt + 1} failed: {exc}")
                if attempt < 2:
                    time.sleep(2 ** attempt)
                else:
                    raise
        raise RuntimeError("Batch preview LLM call failed after all retries")


def _extract_terms_from_text(jd_text: str) -> list[str]:
    candidates = re.split(r"[\s,，。；;:：/()（）\-]+", jd_text)
    terms: list[str] = []
    seen: set[str] = set()
    for raw in candidates:
        token = raw.strip()
        if len(token) < 2:
            continue
        if token in seen:
            continue
        seen.add(token)
        terms.append(token)
    return terms


def _extract_city_expectation(jd_text: str) -> list[str]:
    city_aliases = {
        "shanghai": "上海",
        "shenzhen": "深圳",
        "hangzhou": "杭州",
        "beijing": "北京",
        "suzhou": "苏州",
        "nanjing": "南京",
        "wuhan": "武汉",
        "chengdu": "成都",
        "guangzhou": "广州",
        "xiamen": "厦门",
    }
    lowered = jd_text.lower()
    result = [cn for token, cn in city_aliases.items() if token in lowered or cn in jd_text]
    return result[:3]


def _extract_seniority_band(jd_text: str) -> str:
    lowered = jd_text.lower()
    if any(token in lowered for token in ("director", "vp", "head of", "总监", "负责人")):
        return "senior"
    if any(token in lowered for token in ("manager", "lead", "主管", "经理")):
        return "mid"
    return "open"


def _merge_seed_terms(seed_profile: dict[str, Any], enrichment: dict[str, Any]) -> list[str]:
    seen: set[str] = set()
    merged: list[str] = []
    for source in (
        seed_profile.get("seed_terms", []),
        enrichment.get("core_terms", []),
        enrichment.get("aliases", []),
    ):
        for item in source:
            normalized = str(item).strip()
            if not normalized:
                continue
            lowered = normalized.lower()
            if lowered in seen:
                continue
            seen.add(lowered)
            merged.append(normalized)
    if not merged:
        merged.extend(["人才寻访", "技术项目经理", "光模块"])
    return merged[:12]


def _build_groups(terms: list[str]) -> list[OrGroupPayload]:
    groups: list[OrGroupPayload] = []
    chunk_size = 3
    for index in range(0, len(terms), chunk_size):
        chunk = terms[index:index + chunk_size]
        if not chunk:
            continue
        groups.append(
            {
                "group_index": len(groups),
                "concept": chunk[0],
                "terms": chunk,
            }
        )
    if not groups:
        groups.append({"group_index": 0, "concept": "默认", "terms": ["技术项目经理"]})
    return groups[:5]


def _post_raw_completion(
    *,
    base_url: str,
    api_key: str,
    model: str,
    timeout_seconds: int,
    prompt: str,
) -> str:
    """Send a raw text prompt and return the raw response string (no JSON parsing)."""
    auth_key = api_key.strip()
    if not auth_key:
        raise ExternalClientError("Raw completion API key was empty")

    url = f"{base_url.rstrip('/')}/chat/completions"
    body = json.dumps(
        {
            "model": model,
            "temperature": 0.2,
            "messages": [
                {"role": "user", "content": prompt},
            ],
        },
        ensure_ascii=False,
    ).encode("utf-8")

    max_retries = 2
    last_exception = None
    for attempt in range(1, max_retries + 1):
        request = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {auth_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
                resp = json.loads(response.read().decode("utf-8"))
                return _get_message_content(resp)
        except Exception as exc:
            last_exception = exc
            if attempt < max_retries:
                time.sleep(1)
                continue

    raise ExternalClientError(
        f"Raw completion failed after {max_retries} attempts. Last error: {last_exception}"
    )


def _post_chat_completion(
    *,
    base_url: str,
    api_key: str,
    model: str,
    timeout_seconds: int,
    system_prompt: str,
    user_payload: dict[str, Any],
) -> dict[str, Any]:
    auth_key = api_key.strip()
    if not auth_key:
        raise ExternalClientError("Chat completion API key was empty")

    url = f"{base_url.rstrip('/')}/chat/completions"
    body = json.dumps(
        {
            "model": model,
            "temperature": 0.2,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
            ],
        },
        ensure_ascii=False,
    ).encode("utf-8")
    
    max_retries = 3
    retry_delay_seconds = 2
    last_exception = None

    for attempt in range(1, max_retries + 1):
        request = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {auth_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            # For 4xx errors other than 429, don't retry (likely client error)
            if 400 <= exc.code < 500 and exc.code != 429:
                try:
                    body = exc.read().decode("utf-8", errors="replace")
                except Exception:
                    body = ""
                raise ExternalClientError(
                    f"Chat completion request failed (Non-retryable): HTTP {exc.code} {exc.reason}; body={body}"
                ) from exc
            last_exception = exc
        except (urllib.error.URLError, TimeoutError) as exc:
            last_exception = exc
        except json.JSONDecodeError as exc:
            raise ExternalClientError("Chat completion response was not valid JSON (Non-retryable)") from exc
        
        if attempt < max_retries:
            print(f"[WARN] Chat completion attempt {attempt} failed, retrying in {retry_delay_seconds}s... Error: {last_exception}")
            time.sleep(retry_delay_seconds)
            # Simple exponential-ish backoff
            retry_delay_seconds *= 2

    # If we reached here, all retries failed
    raise ExternalClientError(
        f"Chat completion failed after {max_retries} attempts. Last error: {last_exception}"
    )


def _extract_json_content(response_json: dict[str, Any]) -> dict[str, Any]:
    raw_content = _get_message_content(response_json)
    _persist_raw_llm_content(response_json, raw_content)

    cleaned = _normalize_llm_json_text(raw_content)

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        json_candidate = _extract_first_json_object(cleaned)
        if json_candidate is None:
            raise ExternalClientError("Chat completion content was not valid JSON")
        repaired_candidate = _repair_common_json_issues(json_candidate)
        try:
            parsed = json.loads(repaired_candidate)
        except json.JSONDecodeError as exc:
            raise ExternalClientError(f"Chat completion content was not valid JSON: {exc}") from exc

    if not isinstance(parsed, dict):
        raise ExternalClientError("Chat completion JSON content was not an object")
    return parsed


def _extract_decision_from_raw(content: str) -> dict[str, Any] | None:
    """Extract a decision dict from raw LLM text, handling non-JSON outputs.
    
    When the LLM returns bare text like "skip" instead of JSON, this function
    attempts to salvage a usable decision. Returns None if nothing can be parsed.
    """
    # 1. Try normal JSON extraction first
    try:
        return _extract_json_content({"choices": [{"message": {"content": content}}]})
    except Exception:
        pass

    # 2. Try to find JSON object in text
    cleaned = _normalize_llm_json_text(content)
    json_candidate = _extract_first_json_object(cleaned)
    if json_candidate is not None:
        try:
            repaired = _repair_common_json_issues(json_candidate)
            parsed = json.loads(repaired)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    # 3. Detect bare action keywords and construct minimal decision
    stripped = cleaned.strip().lower()
    for keyword in ("open_detail", "link", "skip"):
        if keyword in stripped:
            print(f"[WARN] LLM returned bare text '{keyword}', constructing minimal decision")
            return {"action": keyword, "reason": "LLM returned non-JSON; action inferred from keyword", "matched_signals": [], "risk_flags": []}

    return None


def _get_message_content(response_json: dict[str, Any]) -> str:
    try:
        content = response_json["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise ExternalClientError("Chat completion response did not include message content") from exc

    if isinstance(content, list):
        content = "".join(
            item.get("text", "")
            for item in content
            if isinstance(item, dict)
        )
    if not isinstance(content, str):
        raise ExternalClientError("Chat completion content was not a string")
    return content


def _persist_raw_llm_content(response_json: dict[str, Any], raw_content: str) -> None:
    print("[DEBUG] Raw LLM content start")
    print(raw_content)
    print("[DEBUG] Raw LLM content end")

    try:
        job_id = None
        try:
            job_id = response_json.get("_openclaw_job_id")
        except Exception:
            job_id = None
        if not job_id:
            job_id = os.environ.get("OPENCLAW_JOB_ID") or os.environ.get("JOB_ID")
        if not job_id:
            return
        runtime_root = Path(__file__).resolve().parents[2] / "runtime"
        log_dir = runtime_root / "jobs" / job_id / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        raw_path = log_dir / "jd-worker.raw-response.txt"
        raw_path.write_text(raw_content, encoding="utf-8")
    except Exception as exc:
        print(f"[WARN] Failed to persist raw LLM content: {exc}")


def _normalize_llm_json_text(content: str) -> str:
    cleaned = content.strip()
    cleaned = re.sub(r"<think>.*?</think>", "", cleaned, flags=re.DOTALL | re.IGNORECASE).strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned).strip()
    return cleaned


def _repair_common_json_issues(text: str) -> str:
    repaired = text.strip()
    repaired = re.sub(r",\s*([}\]])", r"\1", repaired)
    return repaired


def _extract_first_json_object(text: str) -> str | None:
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    in_string = False
    escape = False
    for index in range(start, len(text)):
        ch = text[index]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue

        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:index + 1]
    return None
