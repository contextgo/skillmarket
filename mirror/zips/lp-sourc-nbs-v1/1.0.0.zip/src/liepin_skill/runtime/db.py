from __future__ import annotations

import json
import sqlite3
import time
import uuid
from collections.abc import Sequence
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from liepin_skill.runtime.runtime_models import JobStatus, RuntimeJob


class RuntimeDatabase:
    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)

    def initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                PRAGMA foreign_keys = ON;

                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    source_jd_path TEXT NOT NULL,
                    target_position_name TEXT NOT NULL,
                    target_link_count INTEGER NOT NULL CHECK (target_link_count >= 0),
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (
                        status IN (
                            'pending',
                            'running',
                            'paused',
                            'recovering',
                            'failed',
                            'completed',
                            'paused_auth_required',
                            'failed_recoverable'
                        )
                    )
                );

                CREATE TABLE IF NOT EXISTS search_plans (
                    plan_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    plan_index INTEGER NOT NULL CHECK (plan_index >= 0),
                    jd_compact_profile_json TEXT NOT NULL DEFAULT '{}',
                    active_group_count INTEGER NOT NULL DEFAULT 0 CHECK (active_group_count >= 0),
                    current_city_json TEXT NOT NULL DEFAULT '[]',
                    expected_city_json TEXT NOT NULL DEFAULT '[]',
                    experience_filter TEXT,
                    optional_filters_json TEXT NOT NULL DEFAULT '{}',
                    plan_payload_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
                    UNIQUE (job_id, plan_index)
                );

                CREATE TABLE IF NOT EXISTS search_plan_groups (
                    group_id TEXT PRIMARY KEY,
                    plan_id TEXT NOT NULL,
                    group_index INTEGER NOT NULL CHECK (group_index >= 0),
                    concept TEXT NOT NULL DEFAULT '',
                    terms_json TEXT NOT NULL DEFAULT '[]',
                    is_active INTEGER NOT NULL DEFAULT 0 CHECK (is_active IN (0, 1)),
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (plan_id) REFERENCES search_plans(plan_id),
                    UNIQUE (plan_id, group_index)
                );

                CREATE TABLE IF NOT EXISTS candidate_queue (
                    queue_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    plan_id TEXT NOT NULL,
                    candidate_key TEXT,
                    page_number INTEGER NOT NULL CHECK (page_number >= 0),
                    position_in_page INTEGER NOT NULL CHECK (position_in_page >= 0),
                    preview_payload_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    claimed_by TEXT,
                    claimed_at TEXT,
                    lease_expires_at TEXT,
                    attempt_count INTEGER NOT NULL CHECK (attempt_count >= 0),
                    CHECK (status IN ('pending_preview_eval', 'pending_detail_harvest', 'detail_harvested', 'pending_communication', 'claimed', 'completed', 'failed', 'detail_failed')),
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
                    FOREIGN KEY (plan_id) REFERENCES search_plans(plan_id)
                );

                CREATE TABLE IF NOT EXISTS candidate_evaluations (
                    evaluation_id TEXT PRIMARY KEY,
                    queue_id TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    stage TEXT NOT NULL DEFAULT 'preview',
                    decision TEXT NOT NULL DEFAULT 'skip',
                    evaluation_payload_json TEXT NOT NULL DEFAULT '{}',
                    evaluated_at TEXT NOT NULL,
                    FOREIGN KEY (queue_id) REFERENCES candidate_queue(queue_id),
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
                );

                CREATE TABLE IF NOT EXISTS browser_actions (
                    action_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    action_name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
                );

                CREATE TABLE IF NOT EXISTS action_results (
                    result_id TEXT PRIMARY KEY,
                    action_id TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (action_id) REFERENCES browser_actions(action_id),
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
                );

                CREATE TABLE IF NOT EXISTS checkpoints (
                    checkpoint_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
                );

                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
                );
                """
            )
            self._ensure_column(conn, "search_plans", "jd_compact_profile_json", "TEXT NOT NULL DEFAULT '{}'")
            self._ensure_column(conn, "search_plans", "active_group_count", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column(conn, "search_plans", "current_city_json", "TEXT NOT NULL DEFAULT '[]'")
            self._ensure_column(conn, "search_plans", "expected_city_json", "TEXT NOT NULL DEFAULT '[]'")
            self._ensure_column(conn, "search_plans", "experience_filter", "TEXT")
            self._ensure_column(conn, "search_plans", "optional_filters_json", "TEXT NOT NULL DEFAULT '{}'")
            self._ensure_column(conn, "search_plans", "plan_payload_json", "TEXT NOT NULL DEFAULT '{}'")
            self._ensure_column(conn, "search_plan_groups", "concept", "TEXT NOT NULL DEFAULT ''")
            self._ensure_column(conn, "search_plan_groups", "terms_json", "TEXT NOT NULL DEFAULT '[]'")
            self._ensure_column(conn, "search_plan_groups", "is_active", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column(conn, "candidate_evaluations", "stage", "TEXT NOT NULL DEFAULT 'preview'")
            self._ensure_column(conn, "candidate_evaluations", "decision", "TEXT NOT NULL DEFAULT 'skip'")
            self._ensure_column(
                conn,
                "candidate_evaluations",
                "evaluation_payload_json",
                "TEXT NOT NULL DEFAULT '{}'",
            )

            # Batch preview eval: separate detail payload so preview data is never overwritten
            self._ensure_column(
                conn,
                "candidate_queue",
                "detail_payload_json",
                "TEXT DEFAULT NULL",
            )

    def list_tables(self) -> set[str]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT name
                FROM sqlite_master
                WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
                """
            ).fetchall()
        return {row[0] for row in rows}

    def create_job(
        self,
        *,
        source_jd_path: str,
        target_position_name: str,
        target_link_count: int,
    ) -> RuntimeJob:
        now = datetime.now(timezone.utc).isoformat()
        job = RuntimeJob(
            job_id=str(uuid.uuid4()),
            source_jd_path=source_jd_path,
            target_position_name=target_position_name,
            target_link_count=target_link_count,
            status=JobStatus.PENDING,
            created_at=datetime.fromisoformat(now),
            updated_at=datetime.fromisoformat(now),
        )

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO jobs (
                    job_id,
                    source_jd_path,
                    target_position_name,
                    target_link_count,
                    status,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    job.job_id,
                    job.source_jd_path,
                    job.target_position_name,
                    job.target_link_count,
                    job.status.value,
                    job.created_at.isoformat(),
                    job.updated_at.isoformat(),
                ),
            )

        return job

    def get_job(self, job_id: str) -> RuntimeJob | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    job_id,
                    source_jd_path,
                    target_position_name,
                    target_link_count,
                    status,
                    created_at,
                    updated_at
                FROM jobs
                WHERE job_id = ?
                """,
                (job_id,),
            ).fetchone()

        if row is None:
            return None

        return RuntimeJob(
            job_id=row[0],
            source_jd_path=row[1],
            target_position_name=row[2],
            target_link_count=row[3],
            status=JobStatus.from_db_value(row[4]),
            created_at=datetime.fromisoformat(row[5]),
            updated_at=datetime.fromisoformat(row[6]),
        )

    def update_job_status(self, *, job_id: str, status: JobStatus | str) -> None:
        normalized_status = status.value if isinstance(status, JobStatus) else str(status)
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE jobs
                SET status = ?, updated_at = ?
                WHERE job_id = ?
                """,
                (normalized_status, now, job_id),
            )

    def update_job_source_jd_path(self, *, job_id: str, source_jd_path: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE jobs
                SET source_jd_path = ?, updated_at = ?
                WHERE job_id = ?
                """,
                (source_jd_path, now, job_id),
            )

    def update_candidate_queue_payload(self, *, queue_id: str, payload: dict[str, Any]) -> None:
        """Write full detail payload to detail_payload_json column.
        Does NOT overwrite preview_payload_json — the original lightweight preview data is preserved."""
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE candidate_queue
                SET detail_payload_json = ?
                WHERE queue_id = ?
                """,
                (json.dumps(payload, ensure_ascii=False), queue_id),
            )

    def update_candidate_queue_status(self, *, queue_id: str, status: str) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE candidate_queue
                SET status = ?,
                    claimed_by = NULL,
                    claimed_at = NULL,
                    lease_expires_at = NULL
                WHERE queue_id = ?
                """,
                (status, queue_id),
            )

    def record_event(
        self,
        *,
        job_id: str,
        event_type: str,
        payload: dict[str, Any] | None = None,
    ) -> str:
        event_id = str(uuid.uuid4())
        event_value = f"{event_type}:{json.dumps(payload or {}, ensure_ascii=False)}"
        created_at = datetime.now(timezone.utc).isoformat()

        last_error: Exception | None = None
        for attempt in range(3):
            try:
                with self._connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO events (event_id, job_id, event_type, created_at)
                        VALUES (?, ?, ?, ?)
                        """,
                        (event_id, job_id, event_value, created_at),
                    )
                return event_id
            except sqlite3.OperationalError as exc:
                last_error = exc
                if "locked" not in str(exc).lower() or attempt == 2:
                    raise
                time.sleep(0.2 * (attempt + 1))

        if last_error is not None:
            raise last_error
        return event_id

    def get_latest_event(self, *, job_id: str, event_type_prefix: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT event_id, event_type, created_at
                FROM events
                WHERE job_id = ? AND event_type LIKE ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (job_id, f"{event_type_prefix}:%"),
            ).fetchone()
        if row is None:
            return None
        raw_event_type = str(row[1])
        payload: dict[str, Any] = {}
        if ":" in raw_event_type:
            _, payload_json = raw_event_type.split(":", 1)
            try:
                parsed = json.loads(payload_json)
                if isinstance(parsed, dict):
                    payload = parsed
            except Exception:
                payload = {}
        return {
            "event_id": row[0],
            "event_type": raw_event_type,
            "payload": payload,
            "created_at": row[2],
        }

    def insert_search_plan(
        self,
        *,
        job_id: str,
        jd_compact_profile: dict[str, Any],
        search_plan: dict[str, Any],
    ) -> str:
        existing_count = self.count_search_plans(job_id=job_id)
        plan_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO search_plans (
                    plan_id,
                    job_id,
                    plan_index,
                    jd_compact_profile_json,
                    active_group_count,
                    current_city_json,
                    expected_city_json,
                    experience_filter,
                    optional_filters_json,
                    plan_payload_json,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    plan_id,
                    job_id,
                    existing_count,
                    json.dumps(jd_compact_profile, ensure_ascii=False),
                    int(search_plan.get("active_group_count", 0)),
                    json.dumps(search_plan.get("current_city", []), ensure_ascii=False),
                    json.dumps(search_plan.get("expected_city", []), ensure_ascii=False),
                    search_plan.get("experience_filter"),
                    json.dumps(search_plan.get("optional_filters", {}), ensure_ascii=False),
                    json.dumps(search_plan, ensure_ascii=False),
                    now,
                ),
            )
            for group in search_plan.get("groups", []):
                conn.execute(
                    """
                    INSERT INTO search_plan_groups (
                        group_id,
                        plan_id,
                        group_index,
                        concept,
                        terms_json,
                        is_active,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        str(uuid.uuid4()),
                        plan_id,
                        int(group["group_index"]),
                        str(group["concept"]),
                        json.dumps(group.get("terms", []), ensure_ascii=False),
                        1 if int(group["group_index"]) <= int(search_plan.get("active_group_count", 0)) else 0,
                        now,
                    ),
                )
        return plan_id

    def count_search_plans(self, *, job_id: str) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) FROM search_plans WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        return int(row[0]) if row is not None else 0

    def get_latest_search_plan(self, *, job_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    plan_id,
                    plan_index,
                    jd_compact_profile_json,
                    plan_payload_json
                FROM search_plans
                WHERE job_id = ?
                ORDER BY plan_index DESC, created_at DESC
                LIMIT 1
                """,
                (job_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "plan_id": row[0],
            "plan_index": row[1],
            "jd_compact_profile": json.loads(row[2]),
            "search_plan": json.loads(row[3]),
        }

    def insert_candidate_evaluation(
        self,
        *,
        queue_id: str,
        job_id: str,
        stage: str,
        decision: str,
        evaluation_payload: dict[str, Any],
    ) -> str:
        evaluation_id = str(uuid.uuid4())
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO candidate_evaluations (
                    evaluation_id,
                    queue_id,
                    job_id,
                    stage,
                    decision,
                    evaluation_payload_json,
                    evaluated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    evaluation_id,
                    queue_id,
                    job_id,
                    stage,
                    decision,
                    json.dumps(evaluation_payload, ensure_ascii=False),
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
        return evaluation_id

    def list_candidate_queue_rows(
        self,
        *,
        job_id: str,
        page_number: int | None = None,
        status: str | None = None,
        statuses: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        params: list[Any] = [job_id]
        clauses = ["job_id = ?"]
        if page_number is not None:
            clauses.append("page_number = ?")
            params.append(page_number)
        if status is not None:
            clauses.append("status = ?")
            params.append(status)
        if statuses:
            placeholders = ", ".join("?" for _ in statuses)
            clauses.append(f"status IN ({placeholders})")
            params.extend(statuses)
        where_sql = " AND ".join(clauses)
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT
                    queue_id,
                    job_id,
                    plan_id,
                    candidate_key,
                    page_number,
                    position_in_page,
                    preview_payload_json,
                    detail_payload_json,
                    status,
                    claimed_by,
                    claimed_at,
                    lease_expires_at,
                    attempt_count
                FROM candidate_queue
                WHERE {where_sql}
                ORDER BY page_number ASC, position_in_page ASC, queue_id ASC
                """,
                params,
            ).fetchall()
        return [
            {
                "queue_id": row[0],
                "job_id": row[1],
                "plan_id": row[2],
                "candidate_key": row[3],
                "page_number": row[4],
                "position_in_page": row[5],
                "preview_payload_json": row[6],
                "detail_payload_json": row[7],
                "status": row[8],
                "claimed_by": row[9],
                "claimed_at": row[10],
                "lease_expires_at": row[11],
                "attempt_count": row[12],
            }
            for row in rows
        ]

    def get_page_numbers(self, *, job_id: str) -> list[int]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT DISTINCT page_number
                FROM candidate_queue
                WHERE job_id = ?
                ORDER BY page_number ASC
                """,
                (job_id,),
            ).fetchall()
        return [int(row[0]) for row in rows]

    def get_next_pending_page_number(self, *, job_id: str) -> int | None:
        with self._connect() as conn:
            # Milestone 3 Refinement:
            # Browser focus should ONLY be on pages with actionable browser tasks.
            row = conn.execute(
                """
                SELECT MIN(q.page_number)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.status IN ('pending_detail_harvest', 'detail_harvested', 'pending_communication')
                """,
                (job_id,),
            ).fetchone()
        if row is None or row[0] is None:
            return None
        return int(row[0])

    def get_next_resume_page_number(self, *, job_id: str) -> int | None:
        with self._connect() as conn:
            # Resume worker needs both preview evaluation and detail evaluation pages.
            row = conn.execute(
                """
                SELECT MIN(q.page_number)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND (
                    q.status IN ('pending_preview_eval', 'detail_harvested')
                    OR (
                      q.status = 'completed'
                      AND EXISTS (
                        SELECT 1
                        FROM candidate_evaluations e
                        WHERE e.queue_id = q.queue_id
                          AND e.stage = 'preview'
                          AND e.decision = 'open_detail'
                      )
                      AND NOT EXISTS (
                        SELECT 1
                        FROM candidate_evaluations e2
                        WHERE e2.queue_id = q.queue_id
                          AND e2.stage = 'detail'
                      )
                    )
                  )
                """,
                (job_id,),
            ).fetchone()
        if row is None or row[0] is None:
            return None
        return int(row[0])

    def page_has_pending_work(self, *, job_id: str, page_number: int) -> bool:
        with self._connect() as conn:
            # Browser-only actionable work.
            row = conn.execute(
                """
                SELECT 1
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.page_number = ?
                  AND q.status IN ('pending_detail_harvest', 'detail_harvested', 'pending_communication')
                LIMIT 1
                """,
                (job_id, page_number),
            ).fetchone()
        return row is not None

    def page_has_resume_work(self, *, job_id: str, page_number: int) -> bool:
        """Check whether there is pending resume-worker work for a page.
        
        Pipeline stages checked:
          - pending_preview_eval: awaiting preview evaluation
          - detail_harvested: awaiting detail evaluation
          - completed + preview open_detail: awaiting promotion to detail_harvest
          - completed + detail 'link': awaiting promotion to pending_communication (BUG FIX)
        """
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT 1
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.page_number = ?
                  AND (
                    q.status IN ('pending_preview_eval', 'detail_harvested')
                    OR (
                      q.status = 'completed'
                      AND (
                        -- Case 1: completed + preview open_detail awaiting promotion to detail_harvest
                        EXISTS (
                          SELECT 1
                          FROM candidate_evaluations e
                          WHERE e.queue_id = q.queue_id
                            AND e.stage = 'preview'
                            AND e.decision = 'open_detail'
                        )
                        AND NOT EXISTS (
                          SELECT 1
                          FROM candidate_evaluations e2
                          WHERE e2.queue_id = q.queue_id
                            AND e2.stage = 'detail'
                        )
                        OR
                        -- Case 2: completed + detail 'link' awaiting promotion to pending_communication (BUG FIX)
                        EXISTS (
                          SELECT 1
                          FROM candidate_evaluations e
                          WHERE e.queue_id = q.queue_id
                            AND e.stage = 'detail'
                            AND e.decision = 'link'
                        )
                      )
                    )
                  )
                LIMIT 1
                """,
                (job_id, page_number),
            ).fetchone()
        return row is not None

    def abandon_pending_work(self, *, job_id: str, reason: str, conn: sqlite3.Connection | None = None) -> int:
        should_close = False
        if conn is None:
            conn = self._connect()
            should_close = True
        
        try:
            cursor = conn.execute(
                """
                UPDATE candidate_queue
                SET status = 'failed',
                    claimed_by = NULL,
                    claimed_at = NULL,
                    lease_expires_at = NULL
                WHERE job_id = ?
                  AND status IN ('pending_preview_eval', 'pending_detail_harvest', 'detail_harvested', 'pending_communication', 'claimed')
                """,
                (job_id,),
            )
            count = cursor.rowcount
            # Note: We do NOT call self.record_event inside here if we are reusing a connection
            # because record_event always opens its own connection and might lock.
            # Instead, we just do the work and let the caller handle logging if needed,
            # or we do a direct insert if we have the connection.
            conn.execute(
                """
                INSERT INTO events (event_id, job_id, event_type, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    str(uuid.uuid4()),
                    job_id,
                    f"orchestrator.work_abandoned:{json.dumps({'count': count, 'reason': reason}, ensure_ascii=False)}",
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            return count
        finally:
            if should_close:
                conn.close()

    def count_candidate_queue_rows(
        self,
        *,
        job_id: str,
        statuses: Sequence[str] | None = None,
        plan_id: str | None = None,
    ) -> int:
        params: list[str] = [job_id]
        clauses = ["job_id = ?"]
        if plan_id:
            clauses.append("plan_id = ?")
            params.append(plan_id)
        if statuses:
            placeholders = ", ".join("?" for _ in statuses)
            clauses.append(f"status IN ({placeholders})")
            params.extend(statuses)
        where_sql = " AND ".join(clauses)
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT COUNT(*) FROM candidate_queue WHERE {where_sql}",
                params,
            ).fetchone()
        return int(row[0]) if row is not None else 0

    def count_candidate_evaluations(
        self,
        *,
        job_id: str,
        decision: str | None = None,
    ) -> int:
        params: list[str] = [job_id]
        decision_clause = ""
        if decision is not None:
            decision_clause = " AND decision = ?"
            params.append(decision)
        with self._connect() as conn:
            row = conn.execute(
                f"""
                SELECT COUNT(*)
                FROM candidate_evaluations
                WHERE job_id = ?
                {decision_clause}
                """,
                params,
            ).fetchone()
        return int(row[0]) if row is not None else 0

    def cancel_pending_work(self, *, job_id: str, reason: str = "superseded_by_new_plan") -> int:
        with self._connect() as conn:
            # Mark all pending rows as 'failed' to move them out of active queue
            cursor = conn.execute(
                """
                UPDATE candidate_queue
                SET status = 'failed'
                WHERE job_id = ?
                  AND status IN ('pending_preview_eval', 'pending_detail_harvest', 'detail_harvested', 'pending_communication', 'claimed')
                """,
                (job_id,),
            )
            count = cursor.rowcount
            if count > 0:
                conn.execute(
                    """
                    INSERT INTO events (event_id, job_id, event_type, created_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        str(uuid.uuid4()),
                        job_id,
                        f"db.pending_work_cancelled:{json.dumps({'count': count, 'reason': reason}, ensure_ascii=False)}",
                        datetime.now(timezone.utc).isoformat(),
                    ),
                )
        return count

    def insert_candidate_queue_row(
        self,
        *,
        queue_id: str | None = None,
        job_id: str,
        plan_id: str,
        candidate_key: str | None = None,
        page_number: int,
        position_in_page: int,
        preview_payload_json: str,
        status: str = "pending_preview_eval",
        claimed_by: str | None = None,
        claimed_at: datetime | None = None,
        lease_expires_at: datetime | None = None,
        attempt_count: int = 0,
    ) -> dict[str, Any]:
        queue_id = queue_id or str(uuid.uuid4())
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO candidate_queue (
                    queue_id,
                    job_id,
                    plan_id,
                    candidate_key,
                    page_number,
                    position_in_page,
                    preview_payload_json,
                    status,
                    claimed_by,
                    claimed_at,
                    lease_expires_at,
                    attempt_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    queue_id,
                    job_id,
                    plan_id,
                    candidate_key,
                    page_number,
                    position_in_page,
                    preview_payload_json,
                    status,
                    claimed_by,
                    claimed_at.isoformat() if claimed_at is not None else None,
                    lease_expires_at.isoformat() if lease_expires_at is not None else None,
                    attempt_count,
                ),
            )
        return self._get_candidate_queue_row(queue_id=queue_id)  # type: ignore[return-value]

    def claim_candidate(
        self,
        *,
        queue_id: str,
        worker_name: str,
        lease_seconds: int,
        status: str = 'pending_preview_eval'
    ) -> dict[str, Any] | None:
        now = datetime.now(timezone.utc)
        lease_expires_at = now + timedelta(seconds=lease_seconds)
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE candidate_queue
                SET status = 'claimed',
                    claimed_by = ?,
                    claimed_at = ?,
                    lease_expires_at = ?,
                    attempt_count = attempt_count + 1
                WHERE queue_id = ? AND status = ?
                """,
                (
                    worker_name,
                    now.isoformat(),
                    lease_expires_at.isoformat(),
                    queue_id,
                    status
                ),
            )

            if cursor.rowcount == 0:
                return None

        return self._get_candidate_queue_row(queue_id=queue_id)

    def reclaim_expired_candidate(self, *, queue_id: str) -> bool:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE candidate_queue
                SET status = 'pending_preview_eval',
                    claimed_by = NULL,
                    claimed_at = NULL,
                    lease_expires_at = NULL
                WHERE queue_id = ?
                  AND status = 'claimed'
                  AND lease_expires_at IS NOT NULL
                  AND lease_expires_at <= ?
                """,
                (queue_id, now),
            )
            return cursor.rowcount > 0

    def add_candidate_queue_row(
        self,
        *,
        job_id: str,
        candidate_id: str,
        queued_at: datetime | None = None,
    ) -> None:
        del queued_at
        plan_id = self._get_or_create_compat_plan_id(job_id=job_id)
        self.insert_candidate_queue_row(
            queue_id=candidate_id,
            job_id=job_id,
            plan_id=plan_id,
            candidate_key=candidate_id,
            page_number=0,
            position_in_page=0,
            preview_payload_json="{}",
            status="pending_preview_eval",
            claimed_by=None,
            claimed_at=None,
            lease_expires_at=None,
            attempt_count=0,
        )

    def claim_next_candidate(self, *, job_id: str, status: str = 'pending_preview_eval') -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT queue_id
                FROM candidate_queue
                WHERE job_id = ? AND status = ?
                ORDER BY page_number ASC, position_in_page ASC, queue_id ASC
                LIMIT 1
                """,
                (job_id, status),
            ).fetchone()

        if row is None:
            return None

        return self.claim_candidate(
            queue_id=row[0],
            worker_name="legacy-worker",
            lease_seconds=60,
            status=status,
        )
    def reclaim_stale_candidates(
        self,
        *,
        before: datetime,
        job_id: str | None = None,
    ) -> int:
        reclaimable_rows = self._list_expired_candidate_queue_rows(before=before, job_id=job_id)
        reclaimed_count = 0
        for row in reclaimable_rows:
            if self.reclaim_expired_candidate(queue_id=row["queue_id"]):
                reclaimed_count += 1
        return reclaimed_count

    # ------------------------------------------------------------------
    # Pending preview eval timeout recovery
    # ------------------------------------------------------------------
    def reclaim_stale_pending_previews(
        self,
        *,
        before: datetime,
        job_id: str | None = None,
        max_attempts: int = 5,
    ) -> int:
        """Increment attempt_count for pending_preview_eval that has been requested but not finished.
        Since we don't have updated_at, we use the requested event as the starting point."""
        with self._connect() as conn:
            # Join with events to find when the batch was first requested
            rows = conn.execute(
                """
                SELECT q.queue_id, q.attempt_count
                FROM candidate_queue q
                JOIN events e ON q.job_id = e.job_id
                WHERE q.job_id = ?
                  AND q.status = 'pending_preview_eval'
                  AND e.event_type LIKE 'orchestrator.batch_preview_eval_requested:%'
                  AND e.created_at <= ?
                GROUP BY q.queue_id
                """,
                (job_id, before.isoformat()),
            ).fetchall()

        recovered = 0
        for row in rows:
            queue_id, attempt_count = row[0], int(row[1] or 0)
            if attempt_count >= max_attempts:
                continue
            with self._connect() as conn:
                conn.execute(
                    "UPDATE candidate_queue SET attempt_count = attempt_count + 1 WHERE queue_id = ?",
                    (queue_id,),
                )
                recovered += 1
        return recovered

    def get_max_collected_page(self, *, job_id: str, plan_id: str) -> int:
        """Return the highest page_number collected for a given plan (0 = none collected yet)."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT COALESCE(MAX(page_number), 0)
                FROM candidate_queue
                WHERE job_id = ? AND plan_id = ?
                """,
                (job_id, plan_id),
            ).fetchone()
        return int(row[0]) if row else 0

    def get_page_pipeline_complete(self, *, job_id: str, page_number: int) -> bool:
        """Check whether the full pipeline for a given page has drained.

        Pipeline stages checked:
          - pending_preview_eval, pending_detail_harvest, detail_harvested,
            pending_communication, claimed  →  any present = not complete
          - completed + preview open_detail but NOT yet promoted to detail stage

        Returns True only when ALL stages are empty for the page.
        """
        with self._connect() as conn:
            # Stage 1: active pipeline statuses (preview/detail/communication not finished or claimed)
            row = conn.execute(
                """
                SELECT COUNT(*)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.page_number = ?
                  AND q.status IN (
                      'pending_preview_eval',
                      'pending_detail_harvest',
                      'detail_harvested',
                      'pending_communication',
                      'claimed'
                  )
                """,
                (job_id, page_number),
            ).fetchone()
            if row[0] > 0:
                return False

            # Stage 2: completed + preview open_detail awaiting promotion to detail_harvest
            row2 = conn.execute(
                """
                SELECT COUNT(*)
                FROM candidate_queue q
                WHERE q.job_id = ?
                  AND q.page_number = ?
                  AND q.status = 'completed'
                  AND EXISTS (
                      SELECT 1 FROM candidate_evaluations e
                      WHERE e.queue_id = q.queue_id
                        AND e.stage = 'preview'
                        AND e.decision = 'open_detail'
                  )
                  AND NOT EXISTS (
                      SELECT 1 FROM candidate_evaluations e2
                      WHERE e2.queue_id = q.queue_id
                        AND e2.stage = 'detail'
                  )
                """,
                (job_id, page_number),
            ).fetchone()
            if row2[0] > 0:
                return False

            # Stage 3: completed + detail link awaiting promotion to communication
            # Note: intentionally ignored for pagination gating to avoid blocking page turn by communication stage.
            return True

    def _get_candidate_queue_row(self, *, queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    queue_id,
                    job_id,
                    plan_id,
                    candidate_key,
                    page_number,
                    position_in_page,
                    preview_payload_json,
                    detail_payload_json,
                    status,
                    claimed_by,
                    claimed_at,
                    lease_expires_at,
                    attempt_count
                FROM candidate_queue
                WHERE queue_id = ?
                """,
                (queue_id,),
            ).fetchone()

        if row is None:
            return None

        return {
            "queue_id": row[0],
            "job_id": row[1],
            "plan_id": row[2],
            "candidate_key": row[3],
            "page_number": row[4],
            "position_in_page": row[5],
            "preview_payload_json": row[6],
            "detail_payload_json": row[7],
            "status": row[8],
            "claimed_by": row[9],
            "claimed_at": row[10],
            "lease_expires_at": row[11],
            "attempt_count": row[12],
        }

    def _list_expired_candidate_queue_rows(
        self,
        *,
        before: datetime,
        job_id: str | None = None,
    ) -> list[dict[str, Any]]:
        params: list[str] = [before.isoformat()]
        job_clause = ""
        if job_id is not None:
            job_clause = " AND job_id = ?"
            params.append(job_id)

        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT queue_id
                FROM candidate_queue
                WHERE status = 'claimed'
                  AND lease_expires_at IS NOT NULL
                  AND lease_expires_at <= ?
                  {job_clause}
                ORDER BY queue_id ASC
                """,
                params,
            ).fetchall()

        return [{"queue_id": row[0]} for row in rows]

    def _get_or_create_compat_plan_id(self, *, job_id: str) -> str:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT plan_id
                FROM search_plans
                WHERE job_id = ?
                ORDER BY plan_index ASC, plan_id ASC
                LIMIT 1
                """,
                (job_id,),
            ).fetchone()
            if row is not None:
                return row[0]

            plan_id = f"compat-plan-{job_id}"
            conn.execute(
                """
                INSERT INTO search_plans (plan_id, job_id, plan_index, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (plan_id, job_id, 0, datetime.now(timezone.utc).isoformat()),
            )
            return plan_id

    def _connect(self) -> sqlite3.Connection:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._db_path, timeout=30.0)
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA busy_timeout = 30000;")
        return conn

    def _ensure_column(
        self,
        conn: sqlite3.Connection,
        table_name: str,
        column_name: str,
        ddl: str,
    ) -> None:
        rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
        if any(row[1] == column_name for row in rows):
            return
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {ddl}")
