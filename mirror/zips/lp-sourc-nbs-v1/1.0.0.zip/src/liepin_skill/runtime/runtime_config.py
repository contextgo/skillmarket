from __future__ import annotations

import os
from collections.abc import Mapping

LIEPIN_USERNAME_ENV = "LIEPIN_USERNAME"
LIEPIN_PASSWORD_ENV = "LIEPIN_PASSWORD"

JD_WORKER_LLM_PROVIDER_ENV = "JD_WORKER_LLM_PROVIDER"
JD_WORKER_LLM_MODEL_ENV = "JD_WORKER_LLM_MODEL"
JD_WORKER_LLM_BASE_URL_ENV = "JD_WORKER_LLM_BASE_URL"
JD_WORKER_LLM_API_KEY_ENV = "JD_WORKER_LLM_API_KEY"
RESUME_WORKER_LLM_PROVIDER_ENV = "RESUME_WORKER_LLM_PROVIDER"
RESUME_WORKER_LLM_MODEL_ENV = "RESUME_WORKER_LLM_MODEL"
RESUME_WORKER_LLM_BASE_URL_ENV = "RESUME_WORKER_LLM_BASE_URL"
RESUME_WORKER_LLM_API_KEY_ENV = "RESUME_WORKER_LLM_API_KEY"
SMART_SEARCH_ENDPOINT_ENV = "SMART_SEARCH_ENDPOINT"
SMART_SEARCH_API_KEY_ENV = "SMART_SEARCH_API_KEY"


class MissingConfigurationError(ValueError):
    """Raised when required runtime configuration is missing."""


def read_liepin_credentials_from_env(
    env: Mapping[str, str] | None = None,
) -> tuple[str, str]:
    source = env if env is not None else os.environ
    username = source.get(LIEPIN_USERNAME_ENV, "").strip()
    password = source.get(LIEPIN_PASSWORD_ENV, "").strip()

    missing: list[str] = []
    if not username:
        missing.append(LIEPIN_USERNAME_ENV)
    if not password:
        missing.append(LIEPIN_PASSWORD_ENV)

    if missing:
        joined = ", ".join(missing)
        raise MissingConfigurationError(
            f"Missing required Liepin credentials: {joined}. "
            "Set them before running the login/session scripts."
        )

    return username, password


def required_subprocess_llm_env_vars() -> tuple[str, str, str, str]:
    return (
        JD_WORKER_LLM_PROVIDER_ENV,
        JD_WORKER_LLM_MODEL_ENV,
        RESUME_WORKER_LLM_PROVIDER_ENV,
        RESUME_WORKER_LLM_MODEL_ENV,
    )


def read_optional_env(
    env_name: str,
    env: Mapping[str, str] | None = None,
) -> str | None:
    source = env if env is not None else os.environ
    value = source.get(env_name)
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None
