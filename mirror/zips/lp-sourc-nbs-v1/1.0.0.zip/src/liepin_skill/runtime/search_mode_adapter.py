from __future__ import annotations

from collections.abc import Iterable
from types import MappingProxyType

from liepin_skill.runtime.runtime_models import (
    ExecutableSearchPayload,
    OrGroupSearchPlan,
    SearchCapability,
)


def build_executable_search_payload(
    plan: OrGroupSearchPlan,
    capability: SearchCapability,
) -> ExecutableSearchPayload:
    if capability.supports_compound_groups:
        active_groups = tuple(group.terms for group in plan.groups[: plan.active_group_count])
        return ExecutableSearchPayload(
            mode="compound",
            active_groups=active_groups,
            simple_query=None,
            current_city=plan.current_city,
            expected_city=plan.expected_city,
            experience_filter=plan.experience_filter,
            optional_filters=MappingProxyType(dict(plan.optional_filters)),
        )

    # Simple mode fallback: keep it loose to ensure results
    # Only use the first 2 groups max in simple search to avoid over-restriction
    active_limit = min(2, plan.active_group_count)
    simple_terms = _dedupe_terms(
        term
        for group in plan.groups[:active_limit]
        for term in group.terms
    )

    # Limit total query length to stay within browser search box constraints
    query_string = " ".join(simple_terms) if simple_terms else None
    if query_string and len(query_string) > 100:
        query_string = query_string[:100].rsplit(" ", 1)[0]

    return ExecutableSearchPayload(
        mode="simple",
        active_groups=None,
        simple_query=query_string,
        current_city=plan.current_city,
        expected_city=plan.expected_city,
        experience_filter=plan.experience_filter,
        optional_filters=MappingProxyType(dict(plan.optional_filters)),
    )


def _dedupe_terms(terms: Iterable[str]) -> list[str]:
    unique_terms: list[str] = []
    seen: set[str] = set()
    for term in terms:
        if term in seen:
            continue
        seen.add(term)
        unique_terms.append(term)
    return unique_terms
