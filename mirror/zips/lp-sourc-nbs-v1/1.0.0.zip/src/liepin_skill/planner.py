from dataclasses import dataclass

from liepin_skill.models import SourcingTask


def _freeze_keyword_groups(groups: list[list[str]] | tuple[tuple[str, ...], ...]) -> tuple[tuple[str, ...], ...]:
    return tuple(tuple(list(group)) for group in groups)


def _freeze_strings(values: list[str] | tuple[str, ...]) -> tuple[str, ...]:
    return tuple(values)


@dataclass(frozen=True)
class SearchPlan:
    keyword_groups: tuple[tuple[str, ...], ...]
    all_keyword_groups: tuple[tuple[str, ...], ...]
    current_city: tuple[str, ...]
    expected_city: tuple[str, ...]
    education: str | None
    experience: str | None
    job_title: tuple[str, ...]
    current_industry: tuple[str, ...]
    current_function: tuple[str, ...]
    company: tuple[str, ...]


class SearchPlanner:
    def build_initial_plan(self, task: SourcingTask) -> SearchPlan:
        req = task.search_requirements
        all_keyword_groups = _freeze_keyword_groups(req.keyword_groups)
        return SearchPlan(
            keyword_groups=_freeze_keyword_groups(all_keyword_groups[:3]),
            all_keyword_groups=all_keyword_groups,
            current_city=_freeze_strings(req.current_city),
            expected_city=_freeze_strings(req.expected_city),
            education=req.education,
            experience=req.experience,
            job_title=_freeze_strings(req.job_title),
            current_industry=_freeze_strings(req.current_industry),
            current_function=_freeze_strings(req.current_function),
            company=_freeze_strings(req.company),
        )

    def refine(self, plan: SearchPlan, result_count: int) -> SearchPlan:
        if result_count > 200 and len(plan.keyword_groups) < 5:
            next_group_index = len(plan.keyword_groups)
            if next_group_index >= len(plan.all_keyword_groups):
                return plan
            keyword_groups = _freeze_keyword_groups(plan.keyword_groups + (plan.all_keyword_groups[next_group_index],))
            return SearchPlan(
                keyword_groups=keyword_groups,
                all_keyword_groups=_freeze_keyword_groups(plan.all_keyword_groups),
                current_city=plan.current_city,
                expected_city=plan.expected_city,
                education=plan.education,
                experience=plan.experience,
                job_title=plan.job_title,
                current_industry=plan.current_industry,
                current_function=plan.current_function,
                company=plan.company,
            )
        if result_count == 0 and plan.company:
            return SearchPlan(
                keyword_groups=plan.keyword_groups,
                all_keyword_groups=_freeze_keyword_groups(plan.all_keyword_groups),
                current_city=plan.current_city,
                expected_city=plan.expected_city,
                education=plan.education,
                experience=plan.experience,
                job_title=plan.job_title,
                current_industry=plan.current_industry,
                current_function=plan.current_function,
                company=(),
            )
        if result_count == 0 and len(plan.keyword_groups) > 2:
            return SearchPlan(
                keyword_groups=_freeze_keyword_groups(plan.keyword_groups[:-1]),
                all_keyword_groups=_freeze_keyword_groups(plan.all_keyword_groups),
                current_city=plan.current_city,
                expected_city=plan.expected_city,
                education=plan.education,
                experience=plan.experience,
                job_title=plan.job_title,
                current_industry=plan.current_industry,
                current_function=plan.current_function,
                company=plan.company,
            )
        return plan
