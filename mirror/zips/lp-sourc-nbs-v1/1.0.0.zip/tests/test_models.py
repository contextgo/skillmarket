import json
from pathlib import Path

import pytest

from liepin_skill.models import CandidateDecision, Policy, SourcingTask, SearchRequirements


def test_project_has_required_entry_files():
    root = Path(__file__).resolve().parents[1]
    assert (root / "pyproject.toml").exists()
    assert (root / "README.md").exists()
    assert (root / "src" / "liepin_skill" / "__init__.py").exists()


def test_task_requires_keyword_groups_and_city():
    payload = {
        "target_job": {"display_name": "China Sales Director"},
        "search_requirements": {
            "keyword_groups": [["sales", "销售"]],
            "current_city": ["Shanghai"],
            "expected_city": [],
        },
        "policy": {
            "target_links": 50,
            "max_search_changes": 5,
            "ideal_result_min": 50,
            "ideal_result_max": 200,
        },
    }

    task = SourcingTask.model_validate(payload)

    assert task.search_requirements.keyword_groups
    assert task.search_requirements.current_city


def test_search_requirements_and_task_reject_missing_city_filters():
    payload = {
        "target_job": {"display_name": "China Sales Director"},
        "search_requirements": {
            "keyword_groups": [["sales", "sales director"]],
            "current_city": [],
            "expected_city": [],
        },
        "policy": {
            "target_links": 50,
            "max_search_changes": 5,
            "ideal_result_min": 50,
            "ideal_result_max": 200,
        },
    }

    with pytest.raises(ValueError):
        SourcingTask.model_validate(payload)

    with pytest.raises(ValueError):
        SearchRequirements.model_validate(payload["search_requirements"])


def test_candidate_decision_action_is_constrained():
    decision = CandidateDecision(action="link", reason="clear match")
    assert decision.action == "link"


def test_policy_rejects_negative_target_links():
    with pytest.raises(ValueError):
        Policy(target_links=-1)


def test_policy_rejects_negative_max_search_changes():
    with pytest.raises(ValueError):
        Policy(max_search_changes=-1)


def test_policy_rejects_negative_ideal_result_min():
    with pytest.raises(ValueError):
        Policy(ideal_result_min=-1)


def test_policy_rejects_negative_ideal_result_max():
    with pytest.raises(ValueError):
        Policy(ideal_result_max=-1)


def test_policy_rejects_inverted_result_range():
    with pytest.raises(ValueError):
        Policy(ideal_result_min=201, ideal_result_max=200)


def test_sample_task_fixture_validates_as_sourcing_task():
    root = Path(__file__).resolve().parents[1]
    fixture_path = root / "fixtures" / "tasks" / "sample_task.json"

    with fixture_path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)

    task = SourcingTask.model_validate(payload)

    assert task.target_job.display_name == "China Sales Director"
    assert task.search_requirements.current_city
    assert task.policy.target_links == 50
