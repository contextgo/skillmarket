import pytest

import liepin_skill
from liepin_skill.runtime.runtime_models import OrGroup, OrGroupSearchPlan, SearchCapability
from liepin_skill.runtime.search_mode_adapter import build_executable_search_payload


def make_plan() -> OrGroupSearchPlan:
    return OrGroupSearchPlan(
        groups=[
            OrGroup(group_index=1, concept="core_function", terms=("sales", "account sales")),
            OrGroup(group_index=2, concept="seniority", terms=("director", "head")),
            OrGroup(group_index=3, concept="industry", terms=("industrial", "manufacturing")),
        ],
        active_group_count=2,
        current_city=("Shanghai",),
        expected_city=(),
        experience_filter="5-10 years",
        optional_filters={},
    )


def test_package_root_import_is_safe_for_runtime_only_usage() -> None:
    assert liepin_skill.__version__ == "0.2.0"


def test_compound_mode_preserves_active_groups() -> None:
    payload = build_executable_search_payload(
        make_plan(),
        SearchCapability(supports_compound_groups=True),
    )

    assert payload.mode == "compound"
    assert payload.active_groups == (
        ("sales", "account sales"),
        ("director", "head"),
    )
    assert payload.simple_query is None


def test_simple_mode_builds_constrained_query() -> None:
    payload = build_executable_search_payload(
        make_plan(),
        SearchCapability(supports_compound_groups=False),
    )

    assert payload.mode == "simple"
    assert payload.simple_query == "sales account sales director head"


def test_simple_mode_deduplicates_repeated_terms() -> None:
    plan = OrGroupSearchPlan(
        groups=[
            OrGroup(group_index=1, concept="core_function", terms=("sales", "sales")),
            OrGroup(group_index=2, concept="seniority", terms=("director", "sales")),
        ],
        active_group_count=2,
        current_city=("Shanghai",),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )

    payload = build_executable_search_payload(
        plan,
        SearchCapability(supports_compound_groups=False),
    )

    assert payload.mode == "simple"
    assert payload.simple_query == "sales director"


def test_simple_mode_ignores_inactive_groups() -> None:
    plan = OrGroupSearchPlan(
        groups=[
            OrGroup(group_index=1, concept="core_function", terms=("sales", "account sales")),
            OrGroup(group_index=2, concept="seniority", terms=("director", "head")),
            OrGroup(group_index=3, concept="industry", terms=("industrial", "manufacturing")),
        ],
        active_group_count=1,
        current_city=("Shanghai",),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )

    payload = build_executable_search_payload(
        plan,
        SearchCapability(supports_compound_groups=False),
    )

    assert payload.simple_query == "sales account sales"


def test_plan_optional_filters_are_read_only() -> None:
    plan = OrGroupSearchPlan(
        groups=[OrGroup(group_index=1, concept="core_function", terms=("sales",))],
        active_group_count=1,
        current_city=("Shanghai",),
        expected_city=(),
        experience_filter=None,
        optional_filters={"source": "manual"},
    )

    with pytest.raises(TypeError):
        plan.optional_filters["source"] = "auto"


def test_payload_containers_are_read_only() -> None:
    payload = build_executable_search_payload(
        make_plan(),
        SearchCapability(supports_compound_groups=True),
    )

    assert isinstance(payload.active_groups, tuple)
    with pytest.raises(TypeError):
        payload.active_groups[0] += ("mutated",)
    with pytest.raises(TypeError):
        payload.optional_filters["source"] = "auto"
