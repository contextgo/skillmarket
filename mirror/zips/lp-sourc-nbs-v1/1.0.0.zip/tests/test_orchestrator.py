from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.orchestrator import (
    RuntimeOrchestrator,
    classify_plan_adjustment,
    should_request_new_plan,
)
from liepin_skill.runtime.runtime_models import JobStatus


def test_should_request_new_plan_when_pool_is_too_large() -> None:
    assert should_request_new_plan(
        result_count=350,
        linked_count=0,
        search_change_count=0,
    ) is True


def test_should_request_new_plan_when_pool_is_too_small_even_with_links() -> None:
    assert should_request_new_plan(
        result_count=40,
        linked_count=7,
        search_change_count=0,
    ) is True


def test_should_request_new_plan_suppresses_after_too_many_search_changes() -> None:
    assert should_request_new_plan(
        result_count=350,
        linked_count=0,
        search_change_count=5,
    ) is False


def test_should_request_new_plan_treats_threshold_edges_as_stable() -> None:
    # Under current logic, anything < 200 is a candidate for widening (after pool drain)
    # and > 200 is for tightening.
    assert should_request_new_plan(
        result_count=200,
        linked_count=0,
        search_change_count=0,
    ) is True


def test_classify_plan_adjustment_returns_widen_for_small_pool() -> None:
    assert classify_plan_adjustment(
        result_count=20,
        linked_count=0,
        search_change_count=0,
    ) == "widen"


def test_classify_plan_adjustment_returns_tighten_for_large_pool() -> None:
    assert classify_plan_adjustment(
        result_count=280,
        linked_count=0,
        search_change_count=0,
    ) == "tighten"


def test_runtime_orchestrator_marks_job_running_when_started(tmp_path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )

    status = RuntimeOrchestrator(db=db).run_job(job_id=job.job_id)

    assert status == JobStatus.RUNNING
    assert db.get_job(job.job_id).status == JobStatus.RUNNING


def test_runtime_orchestrator_completes_when_queue_is_drained_after_evaluations(tmp_path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )
    plan_id = db.insert_search_plan(
        job_id=job.job_id,
        jd_compact_profile={
            "target_role_summary": "robotics recruiter",
            "must_have_signals": ["headhunting"],
            "preferred_signals": [],
            "hard_rejects": [],
            "city_expectation": ["Shanghai"],
            "seniority_band": "5-10 years",
        },
        search_plan={
            "groups": [{"group_index": 1, "concept": "function", "terms": ["headhunting"]}],
            "active_group_count": 1,
            "current_city": ["Shanghai"],
            "expected_city": [],
            "experience_filter": "5-10 years",
            "optional_filters": {},
        },
    )
    queue_row = db.insert_candidate_queue_row(
        job_id=job.job_id,
        plan_id=plan_id,
        candidate_key="candidate-1",
        page_number=1,
        position_in_page=1,
        preview_payload_json='{"summary":"headhunting experience"}',
        status="claimed",
        claimed_by="resume-worker",
    )
    db.insert_candidate_evaluation(
        queue_id=queue_row["queue_id"],
        job_id=job.job_id,
        stage="preview",
        decision="skip",
        evaluation_payload={"action": "skip", "reason": "processed"},
    )
    db.update_candidate_queue_status(queue_id=queue_row["queue_id"], status="completed")

    status = RuntimeOrchestrator(db=db).run_job(job_id=job.job_id)

    assert status == JobStatus.COMPLETED
    assert db.get_job(job.job_id).status == JobStatus.COMPLETED
