from pathlib import Path

import pytest

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.worker_jd import JDWorker


class FakePlanningClient:
    def __init__(self):
        self.called = 0

    def build_plan(self, *, jd_text, seed_profile, enrichment, planning_mode="initial", previous_plan=None):
        self.called += 1
        return {
            "jd_compact_profile": {
                "target_role_summary": "summary",
                "must_have_signals": ["a"],
                "preferred_signals": ["b"],
                "hard_rejects": [],
                "city_expectation": [],
                "seniority_band": "open",
            },
            "or_group_search_plan": {
                "groups": [
                    {"group_index": 1, "concept": "c1", "terms": ["t1"]},
                    {"group_index": 2, "concept": "c2", "terms": ["t2"]},
                    {"group_index": 3, "concept": "c3", "terms": ["t3"]},
                    {"group_index": 4, "concept": "c4", "terms": ["t4"]},
                    {"group_index": 5, "concept": "c5", "terms": ["t5"]},
                ],
                "active_group_count": 5,
                "current_city": [],
                "expected_city": [],
                "experience_filter": None,
                "optional_filters": {},
            },
        }


def test_jd_worker_always_calls_planning_client_once() -> None:
    planning_client = FakePlanningClient()
    worker = JDWorker(planning_client=planning_client)
    worker.build_initial_output(jd_text="test")
    assert planning_client.called == 1


def test_jd_worker_accepts_dimension_name_and_or_terms_aliases() -> None:
    class AliasPlanningClient:
        def build_plan(self, *, jd_text, seed_profile, enrichment, planning_mode="initial", previous_plan=None):
            return {
                "jd_compact_profile": {
                    "target_role_summary": "summary",
                    "must_have_signals": ["a"],
                    "preferred_signals": ["b"],
                    "hard_rejects": [],
                    "city_expectation": [],
                    "seniority_band": "open",
                },
                "or_group_search_plan": {
                    "groups": [
                        {"group_index": 1, "dimension_name": "c1", "or_terms": ["t1"]},
                    ],
                    "active_group_count": 1,
                    "current_city": [],
                    "expected_city": [],
                    "experience_filter": None,
                    "optional_filters": {},
                },
            }

    worker = JDWorker(planning_client=AliasPlanningClient())
    output = worker.build_initial_output(jd_text="test")
    assert output.search_plan.groups[0].concept == "c1"
    assert list(output.search_plan.groups[0].terms) == ["t1"]


def test_jd_worker_rejects_malformed_planning_payload_sequences() -> None:
    class BadPlanningClient:
        def build_plan(self, *, jd_text, seed_profile, enrichment, planning_mode="initial", previous_plan=None):
            return {
                "jd_compact_profile": {},
                "or_group_search_plan": {"groups": "oops"},
            }

    worker = JDWorker(planning_client=BadPlanningClient())
    with pytest.raises((TypeError, KeyError)):
        worker.build_initial_output(jd_text="test")


def test_jd_worker_run_job_persists_search_plan(tmp_path: Path) -> None:
    jd_path = tmp_path / "jd.txt"
    jd_path.write_text("Need a semiconductor recruiting consultant in Shanghai", encoding="utf-8")
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path=str(jd_path),
        target_position_name="chip recruiter",
        target_link_count=10,
    )
    worker = JDWorker(planning_client=FakePlanningClient())

    worker.run_job(db=db, job_id=job.job_id)

    latest_plan = db.get_latest_search_plan(job_id=job.job_id)
    assert latest_plan is not None
    assert latest_plan["plan_index"] == 0
    assert latest_plan["search_plan"]["active_group_count"] == 5


def test_jd_worker_prefers_position_scope_from_json_input(tmp_path: Path) -> None:
    criteria_path = tmp_path / "jd_criteria.json"
    criteria_path.write_text(
        '{"position_scope":"Need a semiconductor recruiting consultant in Shanghai","target_count":10}',
        encoding="utf-8",
    )
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path=str(criteria_path),
        target_position_name="chip recruiter",
        target_link_count=10,
    )
    worker = JDWorker(planning_client=FakePlanningClient())

    output = worker.run_job(db=db, job_id=job.job_id)

    assert output.jd_compact_profile["target_role_summary"] == "summary"
