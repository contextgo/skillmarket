from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json

import pytest
from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.job_submit import submit_job_from_criteria
from liepin_skill.runtime.launcher import RuntimeLauncher


def test_launcher_creates_job_directory(tmp_path: Path) -> None:
    launcher = RuntimeLauncher(
        runtime_root=tmp_path / "runtime",
        python_bin="python",
    )

    job = launcher.prepare_job(
        source_jd_path=str(tmp_path / "jd.txt"),
        target_position_name="chip recruiter",
        target_link_count=10,
    )

    assert (tmp_path / "runtime" / "jobs" / job.job_id).exists()


def test_launcher_active_job_lock_round_trip(tmp_path: Path) -> None:
    launcher = RuntimeLauncher(
        runtime_root=tmp_path / "runtime",
        python_bin="python",
    )

    assert launcher.read_active_job_lock() is None

    launcher.write_active_job_lock(job_id="job-123")

    assert launcher.read_active_job_lock() == "job-123"
    assert launcher.can_start_new_job() is False

    launcher.clear_active_job_lock()

    assert launcher.read_active_job_lock() is None
    assert launcher.can_start_new_job() is True


def test_launcher_detects_matching_active_job_lock(tmp_path: Path) -> None:
    launcher = RuntimeLauncher(
        runtime_root=tmp_path / "runtime",
        python_bin="python",
    )

    launcher.write_active_job_lock(job_id="job-123")

    assert launcher.has_active_job_lock(job_id="job-123") is True
    assert launcher.has_active_job_lock(job_id="job-456") is False
    assert launcher.can_start_new_job() is False


def test_launcher_launch_process_group_uses_four_process_modules(
    tmp_path: Path,
    monkeypatch,
) -> None:
    launcher = RuntimeLauncher(
        runtime_root=tmp_path / "runtime",
        python_bin="python",
    )

    launched_commands: list[list[str]] = []
    handles = [
        SimpleNamespace(name="orchestrator"),
        SimpleNamespace(name="browser"),
        SimpleNamespace(name="jd"),
        SimpleNamespace(name="resume"),
    ]

    def fake_popen(command: list[str], **kwargs) -> object:
        launched_commands.append(command)
        return handles[len(launched_commands) - 1]

    import liepin_skill.runtime.launcher as launcher_module

    monkeypatch.setattr(launcher_module.subprocess, "Popen", fake_popen)

    returned_handles = launcher.launch_process_group(job_id="job-123")

    assert returned_handles == handles
    assert launched_commands == [
        [
            "python",
            str(Path(launcher_module.__file__).resolve()),
            "orchestrator",
            "--job-id",
            "job-123",
        ],
        [
            "python",
            str(Path(launcher_module.__file__).resolve()),
            "browser-worker",
            "--job-id",
            "job-123",
        ],
        [
            "python",
            str(Path(launcher_module.__file__).resolve()),
            "jd-worker",
            "--job-id",
            "job-123",
        ],
        [
            "python",
            str(Path(launcher_module.__file__).resolve()),
            "resume-worker",
            "--job-id",
            "job-123",
        ],
    ]
    log_dir = tmp_path / "runtime" / "jobs" / "job-123" / "logs"
    assert log_dir.exists()
    assert (log_dir / "orchestrator.stdout.log").exists()
    assert (log_dir / "resume-worker.stderr.log").exists()


def test_launcher_main_dispatches_role_without_working_import_path(monkeypatch) -> None:
    import liepin_skill.runtime.launcher as launcher_module

    seen: list[list[str]] = []

    def fake_run_role(role: str, job_id: str) -> int:
        seen.append([role, job_id])
        return 0

    monkeypatch.setattr(launcher_module, "_run_role", fake_run_role)

    exit_code = launcher_module.main(["browser-worker", "--job-id", "job-123"])

    assert exit_code == 0
    assert seen == [["browser-worker", "job-123"]]


def test_run_role_dispatches_to_concrete_runner(tmp_path: Path, monkeypatch) -> None:
    import liepin_skill.runtime.launcher as launcher_module
    from liepin_skill.runtime.runtime_models import JobStatus

    db_init_calls: list[str] = []
    runner_calls: list[tuple[str, str]] = []

    class FakeDatabase:
        def __init__(self, db_path: Path) -> None:
            self.db_path = db_path
            self.status = JobStatus.PENDING

        def initialize(self) -> None:
            db_init_calls.append(str(self.db_path))

        def get_job(self, job_id: str):
            return SimpleNamespace(job_id=job_id, status=self.status)

    class FakeOrchestrator:
        def __init__(self, *, db: object) -> None:
            self.db = db

        def run_job(self, *, job_id: str) -> None:
            runner_calls.append(("orchestrator", job_id))
            self.db.status = JobStatus.COMPLETED

    monkeypatch.setattr(launcher_module, "RuntimeDatabase", FakeDatabase)
    monkeypatch.setattr(launcher_module, "RuntimeOrchestrator", FakeOrchestrator)
    monkeypatch.setattr(
        launcher_module,
        "_resolve_runtime_root",
        lambda: tmp_path / "runtime",
    )

    exit_code = launcher_module._run_role("orchestrator", "job-123")

    assert exit_code == 0
    assert db_init_calls == [str(tmp_path / "runtime" / "state.db")]
    assert runner_calls == [("orchestrator", "job-123")]


def test_submit_job_from_criteria_prepares_and_launches_job(tmp_path: Path) -> None:
    calls: list[tuple[str, object]] = []

    class FakeLauncher:
        runtime_root = tmp_path / "runtime"

        def prepare_job(
            self,
            *,
            source_jd_path: str,
            target_position_name: str,
            target_link_count: int,
        ) -> object:
            calls.append(
                (
                    "prepare_job",
                    (source_jd_path, target_position_name, target_link_count),
                )
            )
            return SimpleNamespace(job_id="job-123")

        def launch_process_group(self, *, job_id: str) -> object:
            calls.append(("launch_process_group", job_id))
            return []

    launcher = FakeLauncher()

    job_id = submit_job_from_criteria(
        launcher=launcher,
        criteria={"position_name": "chip recruiter", "target_count": 12},
        source_jd_path=str(tmp_path / "jd.txt"),
    )

    assert job_id == "job-123"
    assert calls == [
        (
            "prepare_job",
            (str(tmp_path / "jd.txt"), "chip recruiter", 12),
        ),
        ("launch_process_group", "job-123"),
    ]


def test_submit_job_from_criteria_dry_run_skips_launch_process_group(
    tmp_path: Path,
) -> None:
    calls: list[tuple[str, object]] = []

    class FakeLauncher:
        runtime_root = tmp_path / "runtime"

        def prepare_job(
            self,
            *,
            source_jd_path: str,
            target_position_name: str,
            target_link_count: int,
        ) -> object:
            calls.append(
                (
                    "prepare_job",
                    (source_jd_path, target_position_name, target_link_count),
                )
            )
            return SimpleNamespace(job_id="job-123")

        def launch_process_group(self, *, job_id: str) -> object:
            calls.append(("launch_process_group", job_id))
            return []

    launcher = FakeLauncher()

    job_id = submit_job_from_criteria(
        launcher=launcher,
        criteria={"position_name": "chip recruiter", "target_count": 12},
        source_jd_path=str(tmp_path / "jd.txt"),
        dry_run=True,
    )

    assert job_id == "job-123"
    assert calls == [
        (
            "prepare_job",
            (str(tmp_path / "jd.txt"), "chip recruiter", 12),
        ),
    ]


def test_submit_job_from_criteria_materializes_json_for_worker_input(tmp_path: Path) -> None:
    launcher = RuntimeLauncher(
        runtime_root=tmp_path / "runtime",
        python_bin="python",
    )
    source_jd_path = tmp_path / "run_optical_module_pm.py"
    source_jd_path.write_text("print('compat facade')", encoding="utf-8")

    job_id = submit_job_from_criteria(
        launcher=launcher,
        criteria={
            "position_name": "optical module pm",
            "target_count": 10,
            "position_scope": "Need an optical module PM with PON experience",
        },
        source_jd_path=str(source_jd_path),
        dry_run=True,
    )

    criteria_file = tmp_path / "runtime" / "jobs" / job_id / "jd_criteria.json"
    stored_job = RuntimeDatabase(tmp_path / "runtime" / "state.db").get_job(job_id)

    assert criteria_file.exists()
    assert "position_scope" in criteria_file.read_text(encoding="utf-8")
    assert stored_job is not None
    assert stored_job.source_jd_path == str(criteria_file)


def test_jd_search_and_communicate_main_passes_dry_run_flag(tmp_path: Path) -> None:
    script_path = Path(__file__).resolve().parents[1] / "scripts" / "jd_search_and_communicate.py"
    spec = importlib.util.spec_from_file_location("jd_search_and_communicate", script_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    calls: list[tuple[str, object]] = []

    class FakeLauncher:
        def __init__(self, *, runtime_root: Path, python_bin: str) -> None:
            calls.append(("launcher_init", (runtime_root, python_bin)))

    def fake_submit_job_from_criteria(
        *,
        launcher: object,
        criteria: dict[str, object],
        source_jd_path: str,
        dry_run: bool = False,
    ) -> str:
        calls.append(
            (
                "submit_job_from_criteria",
                (launcher, criteria, source_jd_path, dry_run),
            )
        )
        return "job-123"

    original_launcher = module.RuntimeLauncher
    original_submit_job_from_criteria = module.submit_job_from_criteria
    try:
        module.RuntimeLauncher = FakeLauncher
        module.submit_job_from_criteria = fake_submit_job_from_criteria

        criteria_path = tmp_path / "criteria.json"
        criteria_path.write_text(
            json.dumps(
                {
                    "position_name": "chip recruiter",
                    "target_count": 12,
                    "position_scope": "Need a recruiter in Shanghai",
                }
            ),
            encoding="utf-8",
        )

        exit_code = module.main(["--dry-run", "--criteria-file", str(criteria_path)])
    finally:
        module.RuntimeLauncher = original_launcher
        module.submit_job_from_criteria = original_submit_job_from_criteria

    assert exit_code == 0
    assert calls[1][0] == "submit_job_from_criteria"
    assert calls[1][1][3] is True
    assert calls[1][1][1]["position_name"] == "chip recruiter"
    assert calls[1][1][2] == str(criteria_path)


def test_jd_search_and_communicate_main_requires_criteria_file(tmp_path: Path) -> None:
    script_path = Path(__file__).resolve().parents[1] / "scripts" / "jd_search_and_communicate.py"
    spec = importlib.util.spec_from_file_location("jd_search_and_communicate_missing", script_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    with pytest.raises(SystemExit) as exc_info:
        module.main([])

    assert exc_info.value.code == 2


def test_jd_search_and_communicate_main_accepts_utf8_bom_criteria_file(tmp_path: Path) -> None:
    script_path = Path(__file__).resolve().parents[1] / "scripts" / "jd_search_and_communicate.py"
    spec = importlib.util.spec_from_file_location("jd_search_and_communicate_bom", script_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    calls: list[tuple[str, object]] = []

    class FakeLauncher:
        def __init__(self, *, runtime_root: Path, python_bin: str) -> None:
            calls.append(("launcher_init", (runtime_root, python_bin)))

    def fake_submit_job_from_criteria(
        *,
        launcher: object,
        criteria: dict[str, object],
        source_jd_path: str,
        dry_run: bool = False,
    ) -> str:
        calls.append(
            (
                "submit_job_from_criteria",
                (launcher, criteria, source_jd_path, dry_run),
            )
        )
        return "job-456"

    criteria_path = tmp_path / "criteria-bom.json"
    criteria_path.write_text(
        json.dumps(
            {
                "position_name": "optical module pm",
                "target_count": 10,
                "position_scope": "懂技术的项目经理",
            }
        ),
        encoding="utf-8-sig",
    )

    original_launcher = module.RuntimeLauncher
    original_submit_job_from_criteria = module.submit_job_from_criteria
    try:
        module.RuntimeLauncher = FakeLauncher
        module.submit_job_from_criteria = fake_submit_job_from_criteria
        exit_code = module.main(["--dry-run", "--criteria-file", str(criteria_path)])
    finally:
        module.RuntimeLauncher = original_launcher
        module.submit_job_from_criteria = original_submit_job_from_criteria

    assert exit_code == 0
    assert calls[1][1][1]["position_name"] == "optical module pm"


def test_run_role_repeats_until_job_reaches_terminal_state(tmp_path: Path, monkeypatch) -> None:
    import liepin_skill.runtime.launcher as launcher_module
    from liepin_skill.runtime.runtime_models import JobStatus

    runner_calls: list[tuple[str, str]] = []

    class FakeDatabase:
        def __init__(self, db_path: Path) -> None:
            self.db_path = db_path
            self.status = JobStatus.PENDING

        def initialize(self) -> None:
            return None

        def get_job(self, job_id: str):
            return SimpleNamespace(job_id=job_id, status=self.status)

    fake_db = FakeDatabase(tmp_path / "runtime" / "state.db")

    class FakeOrchestrator:
        def __init__(self, *, db: object) -> None:
            self.db = db

        def run_job(self, *, job_id: str):
            runner_calls.append(("orchestrator", job_id))
            if len(runner_calls) == 1:
                self.db.status = JobStatus.RUNNING
                return JobStatus.RUNNING
            self.db.status = JobStatus.COMPLETED
            return JobStatus.COMPLETED

    monkeypatch.setattr(launcher_module, "RuntimeDatabase", lambda db_path: fake_db)
    monkeypatch.setattr(launcher_module, "RuntimeOrchestrator", FakeOrchestrator)
    monkeypatch.setattr(launcher_module.time, "sleep", lambda _: None)
    monkeypatch.setattr(
        launcher_module,
        "_resolve_runtime_root",
        lambda: tmp_path / "runtime",
    )

    exit_code = launcher_module._run_role("orchestrator", "job-123")

    assert exit_code == 0
    assert runner_calls == [
        ("orchestrator", "job-123"),
        ("orchestrator", "job-123"),
    ]
