import sqlite3
import sys
import types
from pathlib import Path
from datetime import datetime, timezone

import pytest

package = types.ModuleType("liepin_skill")
package.__path__ = [str(Path(__file__).resolve().parents[1] / "src" / "liepin_skill")]
previous_package = sys.modules.get("liepin_skill")
sys.modules["liepin_skill"] = package

from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.runtime_models import JobStatus

if previous_package is None:
    sys.modules.pop("liepin_skill", None)
else:
    sys.modules["liepin_skill"] = previous_package


def test_initialize_creates_required_tables(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()

    table_names = db.list_tables()

    assert {
        "jobs",
        "search_plans",
        "search_plan_groups",
        "candidate_queue",
        "candidate_evaluations",
        "browser_actions",
        "action_results",
        "checkpoints",
        "events",
    }.issubset(table_names)

    with sqlite3.connect(tmp_path / "state.db") as conn:
        rows = conn.execute("PRAGMA table_info(candidate_queue)").fetchall()

    column_names = {row[1] for row in rows}
    assert {
        "queue_id",
        "job_id",
        "plan_id",
        "candidate_key",
        "page_number",
        "position_in_page",
        "preview_payload_json",
        "status",
        "claimed_by",
        "claimed_at",
        "lease_expires_at",
        "attempt_count",
    }.issubset(column_names)


def test_create_job_persists_pending_job(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()

    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )

    stored = db.get_job(job.job_id)
    assert stored is not None
    assert stored == job


def test_create_job_rejects_negative_target_link_count(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()

    with pytest.raises(sqlite3.IntegrityError):
        db.create_job(
            source_jd_path="/tmp/jd.txt",
            target_position_name="robotics recruiter",
            target_link_count=-1,
        )


def test_search_plan_order_is_unique_per_job(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )

    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
                ("plan-2", job.job_id, 0, "2026-04-01T00:00:01+00:00"),
            )


def test_search_plan_group_order_is_unique_per_plan(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )

    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )
        conn.execute(
            "INSERT INTO search_plan_groups (group_id, plan_id, group_index, created_at) VALUES (?, ?, ?, ?)",
            ("group-1", "plan-1", 0, "2026-04-01T00:00:00+00:00"),
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO search_plan_groups (group_id, plan_id, group_index, created_at) VALUES (?, ?, ?, ?)",
                ("group-2", "plan-1", 0, "2026-04-01T00:00:01+00:00"),
            )


def test_get_job_preserves_unexpected_status_value(tmp_path: Path) -> None:
    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            """
            CREATE TABLE jobs (
                job_id TEXT PRIMARY KEY,
                source_jd_path TEXT NOT NULL,
                target_position_name TEXT NOT NULL,
                target_link_count INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "INSERT INTO jobs (job_id, source_jd_path, target_position_name, target_link_count, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "job-1",
                "/tmp/jd.txt",
                "robotics recruiter",
                15,
                "mystery_status",
                "2026-04-01T00:00:00+00:00",
                "2026-04-01T00:00:00+00:00",
            ),
        )

    db = RuntimeDatabase(tmp_path / "state.db")
    stored = db.get_job("job-1")
    assert stored is not None
    assert stored.status == "mystery_status"


def test_insert_candidate_queue_row_persists_preview_queue_shape(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )
    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )

    db.insert_candidate_queue_row(
        queue_id="queue-1",
        job_id=job.job_id,
        plan_id="plan-1",
        candidate_key="candidate-1",
        page_number=2,
        position_in_page=3,
        preview_payload_json='{"summary": "strong candidate"}',
    )

    with sqlite3.connect(tmp_path / "state.db") as conn:
        row = conn.execute(
            """
            SELECT
                queue_id,
                job_id,
                plan_id,
                candidate_key,
                page_number,
                position_in_page,
                preview_payload_json,
                status,
                claimed_by,
                claimed_at,
                lease_expires_at,
                attempt_count
            FROM candidate_queue
            WHERE queue_id = ?
            """,
            ("queue-1",),
        ).fetchone()

    assert row == (
        "queue-1",
        job.job_id,
        "plan-1",
        "candidate-1",
        2,
        3,
        '{"summary": "strong candidate"}',
        "pending_preview_eval",
        None,
        None,
        None,
        0,
    )


def test_insert_search_plan_and_get_latest_round_trip(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )

    plan_id = db.insert_search_plan(
        job_id=job.job_id,
        jd_compact_profile={
            "target_role_summary": "robotics recruiter",
            "must_have_signals": ["headhunting"],
            "preferred_signals": [],
            "hard_rejects": [],
            "city_expectation": ["Shanghai"],
            "seniority_band": "5-10 years",
        },
        search_plan={
            "groups": [{"group_index": 1, "concept": "function", "terms": ["headhunting"]}],
            "active_group_count": 1,
            "current_city": ["Shanghai"],
            "expected_city": [],
            "experience_filter": "5-10 years",
            "optional_filters": {},
        },
    )

    latest = db.get_latest_search_plan(job_id=job.job_id)

    assert latest is not None
    assert latest["plan_id"] == plan_id
    assert latest["jd_compact_profile"]["must_have_signals"] == ["headhunting"]
    assert latest["search_plan"]["groups"][0]["terms"] == ["headhunting"]


def test_claim_candidate_marks_row_and_sets_lease(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )
    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )

    db.insert_candidate_queue_row(
        queue_id="queue-1",
        job_id=job.job_id,
        plan_id="plan-1",
        candidate_key="candidate-1",
        page_number=2,
        position_in_page=3,
        preview_payload_json='{"summary": "strong candidate"}',
    )

    claimed = db.claim_candidate(
        queue_id="queue-1",
        worker_name="browser-worker-1",
        lease_seconds=60,
    )

    assert claimed is not None
    assert claimed["queue_id"] == "queue-1"
    assert claimed["status"] == "claimed"
    assert claimed["claimed_by"] == "browser-worker-1"
    assert claimed["attempt_count"] == 1
    assert claimed["lease_expires_at"] is not None

    with sqlite3.connect(tmp_path / "state.db") as conn:
        row = conn.execute(
            "SELECT status, claimed_by, claimed_at, lease_expires_at, attempt_count FROM candidate_queue WHERE queue_id = ?",
            ("queue-1",),
        ).fetchone()

    assert row[0] == "claimed"
    assert row[1] == "browser-worker-1"
    assert row[2] is not None
    assert row[3] is not None
    assert row[4] == 1


def test_claim_candidate_rejects_late_competing_update(tmp_path: Path, monkeypatch) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )
    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )

    db.insert_candidate_queue_row(
        queue_id="queue-1",
        job_id=job.job_id,
        plan_id="plan-1",
        candidate_key="candidate-1",
        page_number=2,
        position_in_page=3,
        preview_payload_json='{"summary": "strong candidate"}',
    )

    class _RacingConnection:
        def __init__(self, path: Path) -> None:
            self._conn = sqlite3.connect(path)
            self._update_seen = False

        def __enter__(self) -> "_RacingConnection":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            self._conn.close()

        def execute(self, sql: str, params=()):
            if "UPDATE candidate_queue" in sql and not self._update_seen:
                self._update_seen = True
                with sqlite3.connect(tmp_path / "state.db") as competing_conn:
                    competing_conn.execute(
                        """
                        UPDATE candidate_queue
                        SET status = 'claimed',
                            claimed_by = ?,
                            claimed_at = ?,
                            lease_expires_at = ?,
                            attempt_count = attempt_count + 1
                        WHERE queue_id = ?
                        """,
                        (
                            "browser-worker-2",
                            "2026-04-01T00:00:30+00:00",
                            "2026-04-01T00:01:30+00:00",
                            "queue-1",
                        ),
                    )

            return self._conn.execute(sql, params)

    monkeypatch.setattr(db, "_connect", lambda: _RacingConnection(tmp_path / "state.db"))

    claimed = db.claim_candidate(
        queue_id="queue-1",
        worker_name="browser-worker-1",
        lease_seconds=60,
    )

    assert claimed is None

    with sqlite3.connect(tmp_path / "state.db") as conn:
        row = conn.execute(
            "SELECT status, claimed_by, attempt_count FROM candidate_queue WHERE queue_id = ?",
            ("queue-1",),
        ).fetchone()

    assert row == ("claimed", "browser-worker-2", 1)


def test_reclaim_expired_candidate_resets_claim_state(tmp_path: Path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path="/tmp/jd.txt",
        target_position_name="robotics recruiter",
        target_link_count=15,
    )
    with sqlite3.connect(tmp_path / "state.db") as conn:
        conn.execute(
            "INSERT INTO search_plans (plan_id, job_id, plan_index, created_at) VALUES (?, ?, ?, ?)",
            ("plan-1", job.job_id, 0, "2026-04-01T00:00:00+00:00"),
        )

    db.insert_candidate_queue_row(
        queue_id="queue-1",
        job_id=job.job_id,
        plan_id="plan-1",
        candidate_key="candidate-1",
        page_number=2,
        position_in_page=3,
        preview_payload_json='{"summary": "strong candidate"}',
    )
    db.claim_candidate(
        queue_id="queue-1",
        worker_name="browser-worker-1",
        lease_seconds=0,
    )

    reclaimed = db.reclaim_expired_candidate(queue_id="queue-1")

    assert reclaimed is True

    with sqlite3.connect(tmp_path / "state.db") as conn:
        row = conn.execute(
            "SELECT status, claimed_by, claimed_at, lease_expires_at, attempt_count FROM candidate_queue WHERE queue_id = ?",
            ("queue-1",),
        ).fetchone()

    assert row == ("pending_preview_eval", None, None, None, 1)
