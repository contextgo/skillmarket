import json

import pytest

from liepin_skill.models import CandidateDecision
from liepin_skill.runtime.llm_clients import (
    DeterministicPlanningClient,
    ExternalClientError,
    OpenAICompatiblePlanningClient,
    OpenAICompatibleResumeClient,
    build_planning_client_from_env,
    build_resume_client_from_env,
)
from liepin_skill.runtime.smart_search_client import (
    DeterministicSmartSearchClient,
    HttpSmartSearchClient,
    build_smart_search_client_from_env,
)


class FakeHttpResponse:
    def __init__(self, payload: dict) -> None:
        self.payload = json.dumps(payload).encode("utf-8")

    def read(self) -> bytes:
        return self.payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def test_build_planning_client_from_env_falls_back_without_credentials() -> None:
    client = build_planning_client_from_env({})
    assert isinstance(client, DeterministicPlanningClient)


def test_build_resume_client_from_env_returns_none_without_credentials() -> None:
    assert build_resume_client_from_env({}) is None


def test_build_smart_search_client_from_env_falls_back_without_endpoint() -> None:
    client = build_smart_search_client_from_env({})
    assert isinstance(client, DeterministicSmartSearchClient)


def test_openai_compatible_planning_client_posts_and_parses(monkeypatch) -> None:
    def fake_urlopen(request, timeout: int):
        assert request.full_url == "https://llm.example.com/chat/completions"
        assert timeout == 120
        return FakeHttpResponse(
            {
                "choices": [
                    {
                        "message": {
                            "content": json.dumps(
                                {
                                    "jd_compact_profile": {
                                        "target_role_summary": "sales director",
                                        "must_have_signals": ["sales"],
                                        "preferred_signals": [],
                                        "hard_rejects": [],
                                        "city_expectation": ["上海"],
                                        "seniority_band": "5-10年",
                                    },
                                    "or_group_search_plan": {
                                        "groups": [
                                            {
                                                "group_index": 1,
                                                "concept": "function",
                                                "terms": ["sales", "销售"],
                                            }
                                        ],
                                        "active_group_count": 1,
                                        "current_city": ["上海"],
                                        "expected_city": [],
                                        "experience_filter": "5-10年",
                                        "optional_filters": {},
                                    },
                                },
                                ensure_ascii=False,
                            )
                        }
                    }
                ]
            }
        )

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatiblePlanningClient(
        base_url="https://llm.example.com",
        api_key="secret",
        model="gpt-x",
    )

    payload = client.build_plan(
        jd_text="sales director in Shanghai",
        seed_profile={"seed_terms": ["sales"]},
        enrichment={"aliases": ["销售"]},
    )

    assert payload["jd_compact_profile"]["target_role_summary"] == "sales director"
    assert payload["or_group_search_plan"]["groups"][0]["terms"] == ["sales", "销售"]


def test_openai_compatible_resume_client_returns_candidate_decision(monkeypatch) -> None:
    def fake_urlopen(request, timeout: int):
        assert request.full_url == "https://resume.example.com/chat/completions"
        assert timeout == 20
        return FakeHttpResponse(
            {
                "choices": [
                    {
                        "message": {
                            "content": json.dumps({"action": "link", "reason": "matched must-haves"})
                        }
                    }
                ]
            }
        )

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleResumeClient(
        base_url="https://resume.example.com",
        api_key="secret",
        model="mini",
    )

    decision = client.evaluate_preview(
        jd_compact_profile={"must_have_signals": ["sales"]},
        preview_payload={"summary": "sales leadership"},
    )

    assert isinstance(decision, CandidateDecision)
    assert decision.action == "link"


def test_http_smart_search_client_posts_and_validates(monkeypatch) -> None:
    def fake_urlopen(request, timeout: int):
        assert request.full_url == "https://search.example.com/enrich"
        assert timeout == 20
        return FakeHttpResponse(
            {
                "aliases": ["sales", "销售"],
                "industry_terms": ["industrial automation"],
            }
        )

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    client = HttpSmartSearchClient(endpoint="https://search.example.com/enrich", api_key="secret")

    payload = client.enrich("sales director", ["sales"])

    assert payload["aliases"] == ["sales", "销售"]
    assert payload["industry_terms"] == ["industrial automation"]


def test_http_smart_search_client_rejects_bad_payload(monkeypatch) -> None:
    def fake_urlopen(request, timeout: int):
        return FakeHttpResponse({"aliases": "bad", "industry_terms": []})

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    client = HttpSmartSearchClient(endpoint="https://search.example.com/enrich")

    with pytest.raises(ExternalClientError, match="aliases"):
        client.enrich("sales director", ["sales"])
