from liepin_skill.models import Policy, RunState


def test_should_stop_when_linked_count_reaches_target_links():
    state = RunState(linked_count=10)
    policy = Policy(target_links=10, max_search_changes=5)

    from liepin_skill.run_controller import should_stop

    assert should_stop(state, policy) is True


def test_should_stop_when_search_changes_reaches_max_search_changes():
    state = RunState(search_changes=5)
    policy = Policy(target_links=10, max_search_changes=5)

    from liepin_skill.run_controller import should_stop

    assert should_stop(state, policy) is True


def test_should_continue_when_below_both_limits():
    state = RunState(linked_count=9, search_changes=4)
    policy = Policy(target_links=10, max_search_changes=5)

    from liepin_skill.run_controller import should_stop

    assert should_stop(state, policy) is False
