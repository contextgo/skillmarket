import ast
import py_compile
from pathlib import Path

from liepin_skill.runtime.runtime_config import (
    JD_WORKER_LLM_MODEL_ENV,
    JD_WORKER_LLM_PROVIDER_ENV,
    LIEPIN_PASSWORD_ENV,
    LIEPIN_USERNAME_ENV,
    MissingConfigurationError,
    RESUME_WORKER_LLM_MODEL_ENV,
    RESUME_WORKER_LLM_PROVIDER_ENV,
    read_liepin_credentials_from_env,
    required_subprocess_llm_env_vars,
)


def test_read_liepin_credentials_from_env_returns_values() -> None:
    username, password = read_liepin_credentials_from_env(
        {
            LIEPIN_USERNAME_ENV: "demo-user",
            LIEPIN_PASSWORD_ENV: "demo-pass",
        }
    )

    assert username == "demo-user"
    assert password == "demo-pass"


def test_read_liepin_credentials_from_env_requires_both_values() -> None:
    try:
        read_liepin_credentials_from_env({})
    except MissingConfigurationError as exc:
        assert LIEPIN_USERNAME_ENV in str(exc)
        assert LIEPIN_PASSWORD_ENV in str(exc)
    else:
        raise AssertionError("expected missing credentials to raise MissingConfigurationError")


def test_required_subprocess_llm_env_vars_are_stable() -> None:
    assert required_subprocess_llm_env_vars() == (
        JD_WORKER_LLM_PROVIDER_ENV,
        JD_WORKER_LLM_MODEL_ENV,
        RESUME_WORKER_LLM_PROVIDER_ENV,
        RESUME_WORKER_LLM_MODEL_ENV,
    )


def test_login_and_save_session_script_compiles() -> None:
    script_path = Path(__file__).resolve().parents[1] / "scripts" / "login_and_save_session.py"
    py_compile.compile(str(script_path), doraise=True)


def test_session_scripts_delay_browser_imports_until_after_env_validation() -> None:
    scripts_dir = Path(__file__).resolve().parents[1] / "scripts"

    for script_name in ("login_hold_session.py", "session_persistence_probe.py"):
        tree = ast.parse((scripts_dir / script_name).read_text(encoding="utf-8-sig"))
        top_level_browser_imports: list[str] = []

        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and node.module:
                if node.module.startswith("playwright") or node.module.startswith("liepin_skill.browser"):
                    top_level_browser_imports.append(node.module)

        assert top_level_browser_imports == []
