import pytest

from liepin_skill.models import Policy, SearchRequirements, SourcingTask, TargetJob
from liepin_skill.planner import SearchPlanner


def make_task(
    keyword_groups: list[list[str]] | None = None,
    *,
    company: list[str] | None = None,
    current_function: list[str] | None = None,
    job_title: list[str] | None = None,
    expected_city: list[str] | None = None,
) -> SourcingTask:
    if keyword_groups is None:
        keyword_groups = [
            ["abb", "siemens"],
            ["motor", "motor"],
            ["automation", "automation"],
            ["sales", "business development"],
        ]

    return SourcingTask(
        target_job=TargetJob(display_name="China Sales Director"),
        search_requirements=SearchRequirements(
            keyword_groups=keyword_groups,
            current_city=["Shanghai"],
            expected_city=[] if expected_city is None else expected_city,
            education="Bachelor",
            experience="5-10 years",
            job_title=[] if job_title is None else job_title,
            current_industry=["Industrial Automation"],
            current_function=[] if current_function is None else current_function,
            company=[] if company is None else company,
        ),
        policy=Policy(),
    )


def test_planner_uses_at_most_three_groups_initially_and_preserves_all_groups():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())

    assert plan.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
    )
    assert plan.all_keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )
    assert plan.keyword_groups[0] is not plan.all_keyword_groups[0]


def test_planner_refine_adds_the_next_real_group_when_results_are_too_broad():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())

    refined = planner.refine(plan, result_count=300)

    assert refined.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )
    assert refined.all_keyword_groups == plan.all_keyword_groups


def test_planner_refine_keeps_existing_optional_filters_when_results_are_too_broad():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(
        make_task(
            company=["Acme Automation"],
            current_function=["Sales"],
            job_title=["Sales Director"],
            expected_city=["Beijing"],
        )
    )

    refined = planner.refine(plan, result_count=300)

    assert refined.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )
    assert refined.current_city == ("Shanghai",)
    assert refined.expected_city == ("Beijing",)
    assert refined.education == plan.education
    assert refined.experience == plan.experience
    assert refined.job_title == ("Sales Director",)
    assert refined.current_industry == ("Industrial Automation",)
    assert refined.current_function == ("Sales",)
    assert refined.company == ("Acme Automation",)


def test_planner_refine_clears_company_before_dropping_keyword_groups_when_results_are_zero():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task(company=["Acme Automation"]))

    refined = planner.refine(plan, result_count=0)

    assert refined.keyword_groups == plan.keyword_groups
    assert refined.current_city == plan.current_city
    assert refined.expected_city == plan.expected_city
    assert refined.education == plan.education
    assert refined.experience == plan.experience
    assert refined.job_title == plan.job_title
    assert refined.current_industry == plan.current_industry
    assert refined.current_function == plan.current_function
    assert refined.company == ()


def test_planner_refine_drops_last_active_group_when_no_company_and_more_than_two_groups_are_active():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task(job_title=["Sales Director"], current_function=["Sales"]))

    refined = planner.refine(plan, result_count=0)

    assert refined.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
    )
    assert refined.current_city == plan.current_city
    assert refined.expected_city == plan.expected_city
    assert refined.education == plan.education
    assert refined.experience == plan.experience
    assert refined.job_title == plan.job_title
    assert refined.current_industry == plan.current_industry
    assert refined.current_function == plan.current_function
    assert refined.company == ()


def test_planner_refine_is_noop_when_all_available_groups_are_already_active():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())
    plan = planner.refine(plan, result_count=300)

    assert planner.refine(plan, result_count=300) is plan


def test_planner_refine_is_noop_when_five_groups_are_already_active():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(
        make_task(
            keyword_groups=[
                ["abb", "siemens"],
                ["motor", "motor"],
                ["automation", "automation"],
                ["sales", "business development"],
                ["factory", "manufacturing"],
            ]
        )
    )
    plan = planner.refine(plan, result_count=300)
    plan = planner.refine(plan, result_count=300)

    assert planner.refine(plan, result_count=300) is plan


def test_planner_refine_is_noop_when_zero_results_and_only_two_groups_remain():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())
    plan = planner.refine(plan, result_count=0)

    assert planner.refine(plan, result_count=0) is plan


def test_plan_isolated_from_source_task_list_mutation():
    planner = SearchPlanner()
    task = make_task()

    plan = planner.build_initial_plan(task)

    task.search_requirements.current_city.append("Beijing")
    task.search_requirements.keyword_groups[0].append("extra")
    task.search_requirements.keyword_groups.append(["new", "group"])

    assert plan.current_city == ("Shanghai",)
    assert plan.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
    )
    assert plan.all_keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )


def test_mutating_all_keyword_groups_does_not_change_active_groups():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())

    with pytest.raises(TypeError):
        plan.all_keyword_groups[0] += ("mutated",)

    assert plan.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
    )
    assert plan.all_keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )


def test_refined_plan_does_not_share_keyword_group_lists_with_original():
    planner = SearchPlanner()
    plan = planner.build_initial_plan(make_task())

    refined = planner.refine(plan, result_count=300)

    assert refined.keyword_groups[0] is not plan.keyword_groups[0]
    with pytest.raises(TypeError):
        plan.keyword_groups[0] += ("mutated",)

    assert refined.keyword_groups == (
        ("abb", "siemens"),
        ("motor", "motor"),
        ("automation", "automation"),
        ("sales", "business development"),
    )
