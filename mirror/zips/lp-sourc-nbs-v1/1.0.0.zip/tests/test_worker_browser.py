from __future__ import annotations

import asyncio
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

from liepin_skill.runtime.runtime_models import ExecutableSearchPayload
from liepin_skill.runtime.worker_browser import (
    BrowserWorker,
    build_preview_queue_rows,
    detect_search_capability,
)

_PAGES_PATH = Path(__file__).resolve().parents[1] / "src" / "liepin_skill" / "browser" / "pages.py"
_PAGES_SPEC = importlib.util.spec_from_file_location("liepin_skill.browser.pages", _PAGES_PATH)
assert _PAGES_SPEC is not None and _PAGES_SPEC.loader is not None
_PAGES_MODULE = importlib.util.module_from_spec(_PAGES_SPEC)
sys.modules.setdefault("liepin_skill.browser.pages", _PAGES_MODULE)
_PAGES_SPEC.loader.exec_module(_PAGES_MODULE)
CandidatePreview = _PAGES_MODULE.CandidatePreview


def test_detect_search_capability_prefers_compound_mode() -> None:
    capability = detect_search_capability(
        {
            "compound_toggle_visible": True,
            "single_bar_visible": True,
        }
    )
    assert capability.supports_compound_groups is True


def test_build_preview_queue_rows_keeps_page_and_position() -> None:
    rows = build_preview_queue_rows(
        job_id="job-1",
        plan_id="plan-1",
        page_number=2,
        previews=[
            {"candidate_key": "c-1", "summary": "alpha"},
            {"candidate_key": "c-2", "summary": "beta"},
        ],
    )
    assert rows[0]["position_in_page"] == 1
    assert rows[1]["position_in_page"] == 2
    assert rows[0]["job_id"] == "job-1"
    assert rows[0]["plan_id"] == "plan-1"
    assert rows[0]["page_number"] == 2
    assert json.loads(rows[0]["preview_payload_json"]) == {"candidate_key": "c-1", "summary": "alpha"}
    assert json.loads(rows[1]["preview_payload_json"]) == {"candidate_key": "c-2", "summary": "beta"}
    assert "candidate_key" not in rows[0]
    assert "candidate_key" not in rows[1]


def test_build_preview_queue_rows_serializes_candidate_preview_dataclass() -> None:
    rows = build_preview_queue_rows(
        job_id="job-2",
        plan_id="plan-2",
        page_number=1,
        previews=[
            CandidatePreview(name="张三", title="Director", current_company="Acme"),
        ],
    )

    payload = json.loads(rows[0]["preview_payload_json"])
    assert payload["name"] == "张三"
    assert payload["title"] == "Director"
    assert payload["current_company"] == "Acme"


class _FakeSearchPage:
    def __init__(self, *, fill_result: bool = True) -> None:
        self.calls: list[tuple[str, object]] = []
        self.fill_result = fill_result
        self.submit_called = False

    async def fill_keyword_groups(self, keyword_groups: list[tuple[str, ...]] | list[list[str]]) -> None:
        self.calls.append(("fill_keyword_groups", keyword_groups))
        return self.fill_result

    async def fill_simple_keyword_query(self, query: str) -> None:
        self.calls.append(("fill_simple_keyword_query", query))
        return self.fill_result

    async def submit_search(self) -> None:
        self.calls.append(("submit_search", None))
        self.submit_called = True


def test_browser_worker_apply_search_payload_delegates_by_mode() -> None:
    worker = BrowserWorker()
    search_page = _FakeSearchPage()

    compound_payload = ExecutableSearchPayload(
        mode="compound",
        active_groups=(("sales", "account sales"),),
        simple_query=None,
        current_city=(),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )

    asyncio.run(worker.apply_search_payload(compound_payload, search_page))

    assert search_page.calls == [
        ("fill_keyword_groups", [("sales", "account sales")]),
        ("submit_search", None),
    ]


def test_browser_worker_apply_search_payload_simple_mode_success() -> None:
    worker = BrowserWorker()
    search_page = _FakeSearchPage()

    payload = ExecutableSearchPayload(
        mode="simple",
        active_groups=None,
        simple_query=" sales director ",
        current_city=(),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )

    asyncio.run(worker.apply_search_payload(payload, search_page))

    assert search_page.calls == [
        ("fill_simple_keyword_query", "sales director"),
        ("submit_search", None),
    ]


def test_browser_worker_apply_search_payload_rejects_empty_payloads() -> None:
    worker = BrowserWorker()

    simple_page = _FakeSearchPage()
    empty_simple_payload = ExecutableSearchPayload(
        mode="simple",
        active_groups=None,
        simple_query="   ",
        current_city=(),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )
    try:
        asyncio.run(worker.apply_search_payload(empty_simple_payload, simple_page))
    except ValueError as exc:
        assert "non-empty query" in str(exc)
    else:
        raise AssertionError("expected simple empty payload to fail")

    compound_page = _FakeSearchPage()
    empty_compound_payload = ExecutableSearchPayload(
        mode="compound",
        active_groups=(),
        simple_query=None,
        current_city=(),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )
    try:
        asyncio.run(worker.apply_search_payload(empty_compound_payload, compound_page))
    except ValueError as exc:
        assert "active keyword group" in str(exc)
    else:
        raise AssertionError("expected compound empty payload to fail")


def test_browser_worker_apply_search_payload_propagates_fill_failure() -> None:
    worker = BrowserWorker()
    search_page = _FakeSearchPage(fill_result=False)

    payload = ExecutableSearchPayload(
        mode="simple",
        active_groups=None,
        simple_query="sales",
        current_city=(),
        expected_city=(),
        experience_filter=None,
        optional_filters={},
    )

    try:
        asyncio.run(worker.apply_search_payload(payload, search_page))
    except RuntimeError as exc:
        assert "rejected simple search criteria" in str(exc)
    else:
        raise AssertionError("expected fill failure to raise RuntimeError")

    assert search_page.submit_called is False


def test_browser_worker_run_job_collects_previews_into_queue(tmp_path: Path) -> None:
    from liepin_skill.runtime.db import RuntimeDatabase

    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    job = db.create_job(
        source_jd_path=str(tmp_path / "jd.txt"),
        target_position_name="chip recruiter",
        target_link_count=5,
    )
    plan_id = db.insert_search_plan(
        job_id=job.job_id,
        jd_compact_profile={
            "target_role_summary": "chip recruiter",
            "must_have_signals": ["sales"],
            "preferred_signals": [],
            "hard_rejects": [],
            "city_expectation": ["Shanghai"],
            "seniority_band": "5-10 years",
        },
        search_plan={
            "groups": [{"group_index": 1, "concept": "function", "terms": ["sales"]}],
            "active_group_count": 1,
            "current_city": ["Shanghai"],
            "expected_city": [],
            "experience_filter": None,
            "optional_filters": {},
        },
    )

    class FakeBrowserWorker(BrowserWorker):
        async def _collect_previews_for_plan_async(self, *, db, runtime_root, job_id, latest_plan):
            assert job_id == job.job_id
            assert latest_plan["plan_id"] == plan_id
            # Simulate what the real implementation does: insert rows
            db.insert_candidate_queue_row(
                job_id=job_id,
                plan_id=plan_id,
                candidate_key="c-1",
                page_number=1,
                position_in_page=1,
                preview_payload_json='{"summary":"alpha"}',
            )
            db.insert_candidate_queue_row(
                job_id=job_id,
                plan_id=plan_id,
                candidate_key="c-2",
                page_number=1,
                position_in_page=2,
                preview_payload_json='{"summary":"beta"}',
            )
            return {
                "result_count": 42,
                "search_mode": "simple",
                "collected_preview_count": 2,
            }

    inserted_count = FakeBrowserWorker().run_job(
        db=db,
        job_id=job.job_id,
        runtime_root=tmp_path / "runtime",
    )

    assert inserted_count == 2
    with sqlite3.connect(tmp_path / "state.db") as conn:
        queue_count = conn.execute(
            "SELECT COUNT(*) FROM candidate_queue WHERE job_id = ?",
            (job.job_id,),
        ).fetchone()[0]

    assert queue_count == 2
