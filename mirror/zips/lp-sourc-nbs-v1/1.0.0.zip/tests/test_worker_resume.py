import pytest

from liepin_skill.models import CandidateDecision
from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.worker_resume import ResumeWorker


def test_resume_worker_evaluates_preview_then_detail_without_memory() -> None:
    worker = ResumeWorker()
    jd_profile = {
        "must_have_signals": ["headhunting", "robotics"],
        "preferred_signals": [],
        "hard_rejects": [],
    }

    preview_decision = worker.evaluate_preview(
        jd_compact_profile=jd_profile,
        preview_payload={"summary": "headhunting and robotics background"},
    )
    detail_decision = worker.evaluate_detail(
        jd_compact_profile=jd_profile,
        detail_payload={"work_history": "10 years headhunting for robotics clients"},
    )

    # Preview should be open_detail even if strong
    assert preview_decision.action == "open_detail"
    assert detail_decision.action == "link"


class FakeLightweightResumeClient:
    def __init__(self) -> None:
        self.preview_calls: list[tuple[dict, dict]] = []
        self.detail_calls: list[tuple[dict, dict]] = []

    def evaluate_preview(self, *, jd_compact_profile: dict, preview_payload: dict) -> dict:
        self.preview_calls.append((jd_compact_profile, preview_payload))
        # This will be downgraded to open_detail by ResumeWorker
        return {"action": "link", "reason": "lightweight preview"}

    def evaluate_detail(self, *, jd_compact_profile: dict, detail_payload: dict) -> dict:
        self.detail_calls.append((jd_compact_profile, detail_payload))
        return CandidateDecision(action="skip", reason="lightweight detail").model_dump()


class ExplodingFallbackEvaluator:
    def evaluate_preview(self, *, preview: dict, must_have_terms: list[str]) -> CandidateDecision:
        raise AssertionError("fallback evaluator should not be called for preview")

    def evaluate_detail(self, *, detail: dict, must_have_terms: list[str]) -> CandidateDecision:
        raise AssertionError("fallback evaluator should not be called for detail")


def test_resume_worker_uses_supplied_lightweight_client_before_fallback() -> None:
    lightweight_client = FakeLightweightResumeClient()
    worker = ResumeWorker(
        lightweight_resume_client=lightweight_client,
        evaluator=ExplodingFallbackEvaluator(),
    )

    jd_profile = {
        "must_have_signals": ["headhunting"],
        "preferred_signals": [],
        "hard_rejects": [],
    }

    preview_decision = worker.evaluate_preview(
        jd_compact_profile=jd_profile,
        preview_payload={"summary": "headhunting experience"},
    )
    detail_decision = worker.evaluate_detail(
        jd_compact_profile=jd_profile,
        detail_payload={"work_history": "headhunting and recruiting"},
    )

    # Note the downgrade from link -> open_detail
    assert preview_decision.action == "open_detail"
    assert "downgraded to open_detail" in preview_decision.reason
    assert "lightweight preview" in preview_decision.reason
    assert detail_decision.action == "skip"
    assert detail_decision.reason == "lightweight detail"


def test_resume_worker_stays_stateless_across_different_profiles() -> None:
    worker = ResumeWorker()

    first_decision = worker.evaluate_preview(
        jd_compact_profile={
            "must_have_signals": ["headhunting"],
            "preferred_signals": [],
            "hard_rejects": [],
        },
        preview_payload={"summary": "headhunting experience"},
    )
    second_decision = worker.evaluate_preview(
        jd_compact_profile={
            "must_have_signals": ["robotics"],
            "preferred_signals": [],
            "hard_rejects": [],
        },
        preview_payload={"summary": "headhunting experience"},
    )

    # Both should be open_detail or skip, never link
    assert first_decision.action in ("open_detail", "skip")
    assert second_decision.action in ("open_detail", "skip")


def test_resume_worker_run_job_claims_queue_and_persists_evaluation(tmp_path) -> None:
    db = RuntimeDatabase(tmp_path / "state.db")
    db.initialize()
    jd_path = tmp_path / "jd.txt"
    jd_path.write_text("robotics recruiter", encoding="utf-8")
    job = db.create_job(
        source_jd_path=str(jd_path),
        target_position_name="robotics recruiter",
        target_link_count=5,
    )
    plan_id = db.insert_search_plan(
        job_id=job.job_id,
        jd_compact_profile={
            "target_role_summary": "robotics recruiter",
            "must_have_signals": ["headhunting"],
            "preferred_signals": [],
            "hard_rejects": [],
            "city_expectation": ["Shanghai"],
            "seniority_band": "5-10 years",
        },
        search_plan={
            "groups": [{"group_index": 1, "concept": "function", "terms": ["headhunting"]}],
            "active_group_count": 1,
            "current_city": ["Shanghai"],
            "expected_city": [],
            "experience_filter": "5-10 years",
            "optional_filters": {},
        },
    )
    queue_row = db.insert_candidate_queue_row(
        job_id=job.job_id,
        plan_id=plan_id,
        candidate_key="candidate-1",
        page_number=1,
        position_in_page=1,
        preview_payload_json='{"summary":"headhunting experience"}',
    )
    worker = ResumeWorker()

    decision = worker.run_job(db=db, job_id=job.job_id)

    assert decision is not None
    # Preview stage run_job will return open_detail
    assert decision.action == "open_detail"

    # Verify row was processed (status changed from pending_preview_eval)
    final_rows = db.list_candidate_queue_rows(job_id=job.job_id, status="completed")
    assert len(final_rows) >= 1
