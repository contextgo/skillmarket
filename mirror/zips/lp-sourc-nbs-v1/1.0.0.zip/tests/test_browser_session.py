"""
Tests for Liepin Browser Modules

运行方式:
    python tests/test_browser_session.py
"""

from pathlib import Path
import sys

# 添加 src 到路径
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from liepin_skill.browser.session import SessionConfig
from liepin_skill.browser.pages import SearchStats, CandidatePreview


def test_session_config_default():
    """测试默认配置"""
    config = SessionConfig(
        username="test_user",
        password="test_pass",
    )
    
    assert config.username == "test_user"
    assert config.password == "test_pass"
    assert config.headless is True
    assert config.locale == "zh-CN"
    assert config.timezone_id == "Asia/Shanghai"
    assert config.login_url == "https://lpt.liepin.com/login"
    print("  ✅ test_session_config_default")


def test_session_config_storage_relative():
    """测试相对存储路径解析"""
    config = SessionConfig(
        username="test",
        password="test",
        storage_path="my_storage",
    )
    
    base_dir = Path("/tmp/test")
    resolved = config.resolve_storage_path(base_dir)
    
    assert resolved == Path("/tmp/test/my_storage")
    print("  ✅ test_session_config_storage_relative")


def test_session_config_storage_absolute():
    """测试绝对存储路径解析"""
    config = SessionConfig(
        username="test",
        password="test",
        storage_path="/absolute/path",
    )
    
    resolved = config.resolve_storage_path(Path("/ignored"))
    
    assert resolved == Path("/absolute/path")
    print("  ✅ test_session_config_storage_absolute")


def test_search_stats_default():
    """测试默认值"""
    stats = SearchStats()
    
    assert stats.total_count == 0
    assert stats.page_number == 1
    assert stats.total_pages == 1
    assert stats.candidates_on_page == 0
    print("  ✅ test_search_stats_default")


def test_candidate_preview_default():
    """测试默认值"""
    preview = CandidatePreview()
    
    assert preview.name is None
    assert preview.title is None
    assert preview.element_index == 0
    print("  ✅ test_candidate_preview_default")


def test_candidate_preview_with_values():
    """测试带值的创建"""
    preview = CandidatePreview(
        name="张三",
        title="高级软件工程师",
        current_company="某科技公司",
        element_index=5,
    )
    
    assert preview.name == "张三"
    assert preview.title == "高级软件工程师"
    assert preview.current_company == "某科技公司"
    assert preview.element_index == 5
    print("  ✅ test_candidate_preview_with_values")


def test_brightness_calculation():
    """测试亮度计算逻辑 (模拟)"""
    # 模拟列亮度数据
    col_brightness = [200, 180, 150, 50, 60, 170, 190]  # 第 3 列最暗
    pw = 3  # 拼图块宽度
    
    # 找最暗的连续 pw 列
    min_sum = float('inf')
    gap_x = 0
    
    for x in range(len(col_brightness) - pw + 1):
        brightness_sum = sum(col_brightness[x:x+pw])
        if brightness_sum < min_sum:
            min_sum = brightness_sum
            gap_x = x
    
    # 第 3 列开始的 3 列和最小：50+60+170=280
    # 第 2 列：150+50+60=260 (更小!)
    # 所以应该找到索引 2
    assert gap_x == 2, f"Expected gap_x=2, got {gap_x}"
    print("  ✅ test_brightness_calculation")


def test_edge_point_generation():
    """测试边缘点生成 (模拟)"""
    pw, ph = 20, 20
    margin = 5
    
    edge_points = []
    for x in range(margin, pw - margin):
        edge_points.append((x, margin))
        edge_points.append((x, ph - margin))
    for y in range(margin, ph - margin):
        edge_points.append((margin, y))
        edge_points.append((pw - margin, y))
    
    # 应该有 4 * (pw - 2*margin) 个点
    expected_count = 4 * (pw - 2 * margin)
    assert len(edge_points) == expected_count
    print("  ✅ test_edge_point_generation")


def main():
    print("=" * 60)
    print("🧪 Liepin Browser Module Tests")
    print("=" * 60)
    print()
    
    tests = [
        test_session_config_default,
        test_session_config_storage_relative,
        test_session_config_storage_absolute,
        test_search_stats_default,
        test_candidate_preview_default,
        test_candidate_preview_with_values,
        test_brightness_calculation,
        test_edge_point_generation,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"  ❌ {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ❌ {test.__name__}: {type(e).__name__}: {e}")
            failed += 1
    
    print()
    print("=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("✅ All tests passed!")
        return 0
    else:
        print("❌ Some tests failed!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
