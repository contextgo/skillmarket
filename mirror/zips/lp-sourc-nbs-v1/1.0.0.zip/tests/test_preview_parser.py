from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from liepin_skill.browser.pages import (
    CandidatePage,
    parse_education_text,
    parse_preview_text,
    parse_work_experience_text,
)


def test_parse_work_experience_text_extracts_role_and_dates():
    entry = parse_work_experience_text(
        "渣打银行（中国）有限公司北京分行\nTB Sales Director 交易银行部北方区销售总监2020.03-至今(6年)"
    )

    assert entry.company == "渣打银行（中国）有限公司北京分行"
    assert entry.role == "TB Sales Director 交易银行部北方区销售总监"
    assert entry.date_range == "2020.03-至今(6年)"
    assert entry.duration == "6年"


def test_parse_education_text_extracts_major_degree_and_dates():
    entry = parse_education_text(
        "北京科技大学\n材料科学与工程硕士统招2011.09-2013.07(2年)"
    )

    assert entry.school == "北京科技大学"
    assert entry.major == "材料科学与工程"
    assert entry.degree == "硕士"
    assert entry.study_mode == "统招"
    assert entry.date_range == "2011.09-2013.07(2年)"


def test_parse_preview_text_extracts_first_work_as_title_and_company():
    preview = parse_preview_text(
        "今天活跃\n彭**\n43岁\n14年\nMaster\nShanghai\n期望：\nCommercial Director\n50-70K\n化工\nICL\nBusiness Development Manager2025.02-至今(1年1个月)\nAHB\nBusiness Management Director2024.08-2025.01(5个月)\n立即沟通"
    )

    assert preview.name == "彭**"
    assert preview.current_city in ["Shanghai", "化工"]
    assert preview.experience_years == "14年"
    assert preview.salary_range == "50-70K"
    assert preview.current_company == "ICL"
    assert preview.title == "Business Development Manager"


def test_candidate_page_harvest_preview_text_deduplicates_chunks():
    class FakeLocator:
        def __init__(self):
            self.calls = 0
            self.positions = []
            self.texts = ["alpha", "alpha", "beta", "beta"]

        @property
        def first(self):
            return self

        async def count(self):
            return 1

        async def evaluate(self, script, arg=None):
            if arg is None:
                return {"clientHeight": 100, "scrollHeight": 900}
            self.positions.append(arg)
            return None

        async def inner_text(self, timeout=None):
            text = self.texts[min(self.calls, len(self.texts) - 1)]
            self.calls += 1
            return text

    class FakePage:
        def __init__(self, locator):
            self._locator = locator

        def locator(self, selector):
            return self._locator

        async def wait_for_timeout(self, ms):
            return None

    fake_locator = FakeLocator()
    page = FakePage(fake_locator)
    candidate_page = CandidatePage(page)  # type: ignore[arg-type]

    import asyncio

    result = asyncio.run(candidate_page.harvest_preview_text(step_px=300, max_steps=4))

    assert result["chunks"] == ["alpha", "beta"]
    assert result["scroll_positions"] == [0, 600]
    assert result["clientHeight"] == 100
    assert result["scrollHeight"] == 900


def test_get_full_info_scopes_to_active_preview_container_only():
    class FakeNodeLocator:
        def __init__(self, texts):
            self.texts = texts

        @property
        def first(self):
            return self

        async def count(self):
            return len(self.texts)

        def nth(self, i):
            return FakeNodeLocator([self.texts[i]])

        def locator(self, selector):
            return FakeNodeLocator([])

        async def inner_text(self, timeout=None):
            return self.texts[0] if self.texts else ""

        async def evaluate(self, script, arg=None):
            if arg is None:
                return {"clientHeight": 100, "scrollHeight": 100}
            return None

    class FakeContainerLocator(FakeNodeLocator):
        def __init__(self):
            super().__init__([
                "何先生（TA设置了姓名保护）\n美国-洛杉矶\n工作20年\nWork Experience\nArcelorMittal North America（Base 美国）\n销售总监Sales Director2017.03-至今(9年)\nArcelorMittal China\n销售总监Sales Director2014.02-2017.03(3年1个月)\nEducational Experience\n北京科技大学\n材料科学与工程硕士统招2011.09-2013.07(2年)\n河南科技大学\n车辆工程本科统招2001.09-2005.07(4年)\nPersonal Skills\n汽车零部件\n大客户销售"
            ])

        def locator(self, selector):
            mapping = {
                ".nest-resume-work-item .work-item-content": [
                    "ArcelorMittal North America（Base 美国）\n销售总监Sales Director2017.03-至今(9年)",
                    "ArcelorMittal China\n销售总监Sales Director2014.02-2017.03(3年1个月)",
                ],
                ".work-item-content": [],
                "[class*='work-item-content']": [],
                ".edu-item-content": [
                    "北京科技大学\n材料科学与工程硕士统招2011.09-2013.07(2年)"
                ],
                "[class*='edu-item-content']": [],
                ".nest-resume-personal-skills": ["汽车零部件", "大客户销售"],
                ".keyWordList--F7UPD span": [],
                "[class*='keyword']": [],
            }
            return FakeNodeLocator(mapping.get(selector, []))

    class FakePage:
        def __init__(self):
            self.url = "https://lpt.liepin.com/search#preview"
            self.container = FakeContainerLocator()
            self.global_calls = []

        def locator(self, selector):
            self.global_calls.append(selector)
            if selector in [
                ".resume-detail-content-body.printable-content",
                ".resume-detail-content-body",
                "[class*='resume-detail-content-body']",
            ]:
                return self.container
            if selector in [
                ".nest-resume-work-item .work-item-content, .work-item-content",
                ".edu-item-content",
                ".nest-resume-personal-skills, .keyWordList--F7UPD span, [class*='keyword']",
                "li.resumeCardWrap--FcnzW, li[class*='resumeCardWrap']",
                "body",
            ]:
                raise AssertionError(f"unexpected global selector used: {selector}")
            return FakeNodeLocator([])

        async def wait_for_timeout(self, ms):
            return None

    import asyncio

    page = FakePage()
    candidate_page = CandidatePage(page)  # type: ignore[arg-type]
    result = asyncio.run(candidate_page.get_full_info())

    assert result["name"] == "何先生（TA设置了姓名保护）"
    assert result["city"] == "美国-洛杉矶"
    assert result["current_company"] == "ArcelorMittal North America（Base 美国）"
    assert result["current_role"] == "销售总监Sales Director"
    assert len(result["work_experiences"]) == 2
    assert len(result["education_entries"]) == 2
    assert result["skills"] == ["汽车零部件", "大客户销售"]
    assert result["harvest_meta"]["scoped_to_active_preview"] is True
    assert result["harvest_meta"]["work_section_line_count"] > 0
    assert result["harvest_meta"]["education_section_line_count"] > 0


def test_section_parsing_prefers_section_boundaries_over_global_noise():
    page = CandidatePage(None)  # type: ignore[arg-type]
    body_text = """何先生（TA设置了姓名保护）
美国-洛杉矶
工作20年
Work Experience
ArcelorMittal North America（Base 美国）
销售总监Sales Director2017.03-至今(9年)
ArcelorMittal China
销售总监Sales Director2014.02-2017.03(3年1个月)
Educational Experience
北京科技大学
材料科学与工程硕士统招2011.09-2013.07(2年)
河南科技大学
车辆工程本科统招2001.09-2005.07(4年)
Personal Skills
汽车零部件
大客户销售
别的候选人公司
别的职位2020.01-至今(5年)
"""

    work_lines = page._extract_section_lines(body_text, "work")
    edu_lines = page._extract_section_lines(body_text, "education")
    skill_lines = page._extract_section_lines(body_text, "skills")

    work_entries = page._parse_work_entries_from_section_lines(work_lines)
    edu_entries = page._parse_education_entries_from_section_lines(edu_lines)
    skills = page._extract_skills_from_section_lines(skill_lines)

    assert [e.company for e in work_entries] == [
        "ArcelorMittal North America（Base 美国）",
        "ArcelorMittal China",
    ]
    assert [e.school for e in edu_entries] == ["北京科技大学", "河南科技大学"]
    assert skills[:2] == ["汽车零部件", "大客户销售"]
    assert all("别的候选人公司" not in (e.company or "") for e in work_entries)
