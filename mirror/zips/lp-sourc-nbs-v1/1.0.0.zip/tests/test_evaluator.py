from liepin_skill.evaluator import CandidateEvaluator


def test_evaluate_preview_links_when_evidence_is_obvious():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_preview(
        {
            "title": "Senior Sales Director",
            "summary": "Automotive sales leadership for enterprise accounts",
        },
        must_have_terms=["sales", "director"],
    )

    assert decision.action == "open_detail"


def test_evaluate_preview_opens_detail_when_evidence_is_inconclusive():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_preview(
        {
            "title": "Sales Manager",
            "summary": "Experience leading teams in a related field",
        },
        must_have_terms=["sales", "director"],
    )

    assert decision.action == "open_detail"


def test_evaluate_detail_skips_when_evidence_is_ambiguous():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_detail(
        {
            "title": "Operations Lead",
            "summary": "Leads cross-functional initiatives with no clear sales signal",
        },
        must_have_terms=["sales", "director"],
    )

    assert decision.action == "skip"


def test_evaluate_preview_opens_detail_when_a_single_must_have_term_matches():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_preview(
        {
            "title": "Sales Lead",
            "summary": "Owns revenue growth and enterprise accounts",
        },
        must_have_terms=["sales"],
    )

    assert decision.action == "open_detail"


def test_evaluate_preview_skips_substring_false_positives():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_preview(
        {
            "title": "Salesforce Directory Administrator",
            "summary": "Supports CRM operations and internal documentation",
        },
        must_have_terms=["sales", "director"],
    )

    assert decision.action == "skip"


def test_evaluate_preview_deduplicates_repeated_must_have_terms():
    evaluator = CandidateEvaluator()

    decision = evaluator.evaluate_preview(
        {
            "title": "Sales Manager",
            "summary": "Leads a team focused on growth",
        },
        must_have_terms=["sales", "sales", "director"],
    )

    assert decision.action == "open_detail"
