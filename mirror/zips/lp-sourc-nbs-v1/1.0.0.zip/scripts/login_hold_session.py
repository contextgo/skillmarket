﻿#!/usr/bin/env python3
"""Keep a headless persistent Liepin session alive using environment-provided credentials."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

LOGIN_URL = "https://lpt.liepin.com/login"
SKILL_ROOT = Path(__file__).resolve().parent.parent
USER_DATA_DIR = SKILL_ROOT / "liepin_chromium_profile"
SRC_ROOT = SKILL_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))
from liepin_skill.runtime.runtime_config import (  # noqa: E402
    MissingConfigurationError,
    read_liepin_credentials_from_env,
)


async def main() -> None:
    try:
        account, password = read_liepin_credentials_from_env()
    except MissingConfigurationError as exc:
        raise SystemExit(str(exc))

    from playwright.async_api import async_playwright
    from liepin_skill.browser.captcha import TencentCaptchaSolver
    from liepin_skill.browser.session_helpers import (
        get_browser_launch_args,
        validate_session_at_recommend,
    )

    async with async_playwright() as playwright:
        launch_args = get_browser_launch_args()
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=str(USER_DATA_DIR),
            headless=True,
            **launch_args,
        )

        page = context.pages[0] if context.pages else await context.new_page()

        await context.add_init_script(
            """
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
            Object.defineProperty(navigator, 'languages', { get: () => ['zh-CN', 'zh', 'en'] });
            """
        )

        await page.goto("https://lpt.liepin.com/recommend", wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(2000)

        if not await validate_session_at_recommend(page):
            print("Session not logged in. Starting login flow...")
            await page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(3000)

            password_login = page.locator("li:has-text('密码登录')")
            if await password_login.count() > 0:
                await password_login.click()
                await page.wait_for_timeout(1500)

            await page.locator(
                'input[placeholder*="用户名], input[placeholder*="手机号], input[placeholder*="邮箱"]'
            ).fill(account)
            await page.locator('input[type="password"]').fill(password)

            buttons = await page.locator("button").all()
            await buttons[-1].click()
            await page.wait_for_timeout(5000)

            solver = TencentCaptchaSolver(page)
            if any("turing.captcha.qcloud.com" in (frame.url or "") for frame in page.frames):
                solved = await solver.solve()
                if not solved:
                    raise RuntimeError("Captcha solve failed")
                await page.wait_for_timeout(3000)

        print(f"Current URL: {page.url}")

        from datetime import datetime

        timestamp = datetime.now().strftime("%H%M%S")
        screenshot_path = SKILL_ROOT / "screenshots" / f"hold_session_{timestamp}.png"
        await page.screenshot(path=str(screenshot_path), full_page=False, timeout=5000)
        print(f"Saved screenshot: {screenshot_path}")
        print("Persistent headless session is being held. Press Ctrl+C to exit.")

        try:
            while True:
                await asyncio.sleep(60)
        except KeyboardInterrupt:  # pragma: no cover - manual operator path
            print("Exiting session hold.")
        finally:
            await context.close()


if __name__ == "__main__":
    asyncio.run(main())

