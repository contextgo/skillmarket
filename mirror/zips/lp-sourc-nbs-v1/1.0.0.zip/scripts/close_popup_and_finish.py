#!/usr/bin/env python3
"""
关闭系统弹窗并完成"继续沟通"流程的剩余步骤
"""
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

def main():
    print("=== 关闭系统弹窗并完成流程 ===\n")
    
    with sync_playwright() as p:
        # 启动浏览器并加载session
        print("Step 1: 加载已保存的session...")
        
        # 查找storage_state文件
        skill_root = Path(__file__).parent.parent
        storage_state_file = skill_root / "browser_storage_fresh" / "storage_state.json"
        
        if not storage_state_file.exists():
            print(f"❌ 找不到session文件: {storage_state_file}")
            return False
        
        print(f"📦 加载session: {storage_state_file}")
        
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            storage_state=str(storage_state_file),
            locale="zh-CN",
            timezone_id="Asia/Shanghai",
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            viewport={"width": 1920, "height": 1080},
        )
        
        page = context.new_page()
        
        # 导航到推荐页
        print("🌐 导航到推荐页...")
        page.goto("https://lpt.liepin.com/recommend", wait_until="domcontentloaded")
        time.sleep(2)
        
        print("✅ Session加载成功\n")
        
        # 等待页面稳定
        time.sleep(2)
        
        # 截图看看当前状态
        print("Step 2: 截图当前状态...")
        screenshot_path = Path(__file__).parent.parent / "popup_before.png"
        page.screenshot(path=str(screenshot_path), full_page=True)
        print(f"✅ 截图已保存: {screenshot_path}\n")
        
        # 尝试找到并关闭系统弹窗
        print("Step 3: 查找并关闭系统弹窗...")
        popup_closed = False
        
        # 尝试多种可能的弹窗关闭按钮文本
        popup_button_texts = [
            "我知道了",
            "不再提醒",
            "知道了",
            "关闭",
            "确定"
        ]
        
        for button_text in popup_button_texts:
            try:
                # 查找包含该文本的按钮
                button = page.get_by_text(button_text, exact=False).first
                if button.is_visible(timeout=1000):
                    print(f"  找到弹窗按钮: {button_text}")
                    button.click(force=True)
                    popup_closed = True
                    print(f"✅ 已点击弹窗按钮: {button_text}\n")
                    time.sleep(1)
                    break
            except Exception as e:
                continue
        
        if not popup_closed:
            print("⚠️ 未找到系统弹窗按钮，可能已经关闭或不存在\n")
        
        # 截图看看弹窗是否已关闭
        print("Step 4: 截图确认弹窗状态...")
        screenshot_path = Path(__file__).parent.parent / "popup_after.png"
        page.screenshot(path=str(screenshot_path), full_page=True)
        print(f"✅ 截图已保存: {screenshot_path}\n")
        
        # 点击"确认"按钮
        print("Step 5: 点击'确认'按钮...")
        try:
            confirm_button = page.get_by_text("确认", exact=True).first
            if confirm_button.is_visible(timeout=2000):
                confirm_button.click(force=True)
                print("✅ 已点击'确认'按钮\n")
                time.sleep(1)
            else:
                print("⚠️ 未找到'确认'按钮\n")
        except Exception as e:
            print(f"⚠️ 点击'确认'按钮失败: {e}\n")
        
        # 关闭"我的沟通"侧边栏
        print("Step 6: 关闭'我的沟通'侧边栏...")
        try:
            # 查找关闭按钮（通常是一个X图标）
            close_button = page.locator('.ant-drawer-close').first
            if close_button.is_visible(timeout=2000):
                close_button.click(force=True)
                print("✅ 已关闭侧边栏\n")
                time.sleep(1)
            else:
                print("⚠️ 未找到侧边栏关闭按钮\n")
        except Exception as e:
            print(f"⚠️ 关闭侧边栏失败: {e}\n")
        
        # 最终截图
        print("Step 7: 最终截图...")
        screenshot_path = Path(__file__).parent.parent / "popup_final.png"
        page.screenshot(path=str(screenshot_path), full_page=True)
        print(f"✅ 截图已保存: {screenshot_path}\n")
        
        print("=== 流程完成 ===")
        print("请检查以下截图:")
        print(f"  - popup_before.png (执行前)")
        print(f"  - popup_after.png (关闭弹窗后)")
        print(f"  - popup_final.png (最终状态)")
        
        browser.close()
        return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
