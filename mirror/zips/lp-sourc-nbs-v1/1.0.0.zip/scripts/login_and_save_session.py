#!/usr/bin/env python3
"""Login to Liepin, persist the authenticated browser session, and capture a proof screenshot."""

from __future__ import annotations

import asyncio
import importlib.util
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SRC_ROOT = SKILL_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from liepin_skill.runtime.runtime_config import (  # noqa: E402
    MissingConfigurationError,
    read_liepin_credentials_from_env,
)


def _load_session_types() -> tuple[type, type]:
    session_path = SRC_ROOT / "liepin_skill" / "browser" / "session.py"
    spec = importlib.util.spec_from_file_location("liepin_browser_session", session_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load session module from {session_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.LiepinSession, module.SessionConfig


async def main() -> None:
    print("=" * 60)
    print("Liepin login session bootstrap")
    print("=" * 60)

    try:
        username, password = read_liepin_credentials_from_env()
    except MissingConfigurationError as exc:
        raise SystemExit(str(exc))

    liepin_session_cls, session_config_cls = _load_session_types()
    config = session_config_cls(
        username=username,
        password=password,
        headless=True,
        storage_path="runtime/browser_storage",
    )

    async with liepin_session_cls(config, base_dir=SKILL_ROOT) as session:
        print(f"Current URL: {session.page.url}")
        await asyncio.sleep(2)

        from datetime import datetime

        timestamp = datetime.now().strftime("%H%M%S")
        screenshot_path = SKILL_ROOT / "screenshots" / f"login_success_{timestamp}.png"
        await session.page.screenshot(
            path=str(screenshot_path),
            full_page=False,
            timeout=5000,
        )
        print(f"Saved screenshot: {screenshot_path}")

        try:
            title = await session.page.title()
            print(f"Page title: {title}")
        except Exception as exc:  # pragma: no cover - best-effort diagnostics
            print(f"Unable to read title: {exc}")

        try:
            text = await session.page.locator("body").inner_text(timeout=5000)
            indicators = [
                keyword
                for keyword in ("人才推荐", "搜索人才", "立即沟通", "推荐")
                if keyword in text
            ]
            print(f"Success indicators: {indicators}")
        except Exception as exc:  # pragma: no cover - best-effort diagnostics
            print(f"Unable to inspect page text: {exc}")

        print(f"Session stored under: {config.resolve_storage_path(SKILL_ROOT)}")


if __name__ == "__main__":
    asyncio.run(main())
