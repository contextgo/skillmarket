from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SRC_ROOT = SKILL_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from liepin_skill.runtime.launcher import RuntimeLauncher
from liepin_skill.runtime.job_submit import submit_job_from_criteria

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--criteria-file", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    criteria_file = Path(args.criteria_file).resolve()
    if not criteria_file.exists():
        print(f"Error: Criteria file not found: {criteria_file}")
        sys.exit(1)

    try:
        criteria = json.loads(criteria_file.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"Error parsing criteria file: {e}")
        sys.exit(1)

    launcher = RuntimeLauncher(
        runtime_root=SKILL_ROOT / "runtime",
        python_bin=sys.executable,
    )

    job_id = submit_job_from_criteria(
        launcher=launcher,
        criteria=criteria,
        source_jd_path=str(criteria_file),
        dry_run=args.dry_run,
    )

    print(f"Started Liepin runtime job: {job_id}")

if __name__ == "__main__":
    main()
