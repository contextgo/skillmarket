#!/usr/bin/env python3
"""Verify that the saved persistent Liepin profile can be reopened without losing login state."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
PROFILE_DIR = SKILL_ROOT / "liepin_chromium_profile"
SRC_ROOT = SKILL_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))
from liepin_skill.runtime.runtime_config import (  # noqa: E402
    MissingConfigurationError,
    read_liepin_credentials_from_env,
)

LOGIN_URL = "https://lpt.liepin.com/login"


async def open_context(playwright):
    from liepin_skill.browser.session_helpers import get_browser_launch_args

    launch_args = get_browser_launch_args()
    return await playwright.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE_DIR),
        headless=True,
        **launch_args,
    )


async def ensure_login(page, *, account: str, password: str) -> bool:
    from liepin_skill.browser.captcha import TencentCaptchaSolver
    from liepin_skill.browser.session_helpers import validate_session_at_recommend

    await page.goto("https://lpt.liepin.com/recommend", wait_until="domcontentloaded", timeout=30000)

    if await validate_session_at_recommend(page):
        print("LOGIN_BEFORE_RECHECK=already_valid")
        return True

    print("LOGIN_BEFORE_RECHECK=expired_or_missing")
    await page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=30000)
    await page.wait_for_timeout(3000)

    password_login = page.locator("li:has-text('密码登录')")
    if await password_login.count() > 0:
        await password_login.click()
        await page.wait_for_timeout(1500)

    await page.locator(
        'input[placeholder*="用户名"], input[placeholder*="手机号"], input[placeholder*="邮箱"]'
    ).fill(account)
    await page.locator('input[type="password"]').fill(password)

    buttons = await page.locator("button").all()
    await buttons[-1].click()
    await page.wait_for_timeout(5000)

    if any("turing.captcha.qcloud.com" in (frame.url or "") for frame in page.frames):
        solver = TencentCaptchaSolver(page)
        solved = await solver.solve()
        print(f"CAPTCHA_SOLVED={solved}")
        if not solved:
            return False
        await page.wait_for_timeout(3000)

    await page.goto("https://lpt.liepin.com/recommend", wait_until="domcontentloaded", timeout=30000)
    valid = await validate_session_at_recommend(page)
    print(f"LOGIN_AFTER_SOLVE_VALID={valid}")
    return valid


async def main() -> None:
    try:
        account, password = read_liepin_credentials_from_env()
    except MissingConfigurationError as exc:
        raise SystemExit(str(exc))

    from playwright.async_api import async_playwright
    from liepin_skill.browser.session_helpers import validate_session_at_recommend

    async with async_playwright() as playwright:
        context1 = await open_context(playwright)
        page1 = context1.pages[0] if context1.pages else await context1.new_page()
        phase1_valid = await ensure_login(page1, account=account, password=password)
        print(f"PHASE1_VALID={phase1_valid}")

        screenshot1 = SKILL_ROOT / "screenshots" / "session_probe_phase1.png"
        try:
            await page1.screenshot(path=str(screenshot1), full_page=False, timeout=5000)
        except Exception:
            pass

        await context1.close()
        print("PHASE1_CLOSED=graceful")
        await asyncio.sleep(2)

        context2 = await open_context(playwright)
        page2 = context2.pages[0] if context2.pages else await context2.new_page()
        await page2.goto("https://lpt.liepin.com/recommend", wait_until="domcontentloaded", timeout=30000)
        phase2_valid = await validate_session_at_recommend(page2)

        print(f"PHASE2_REOPEN_VALID={phase2_valid}")
        print(f"PHASE2_URL={page2.url}")

        try:
            body_text = await page2.locator("body").inner_text(timeout=5000)
            print("PHASE2_TEXT_HEAD=" + body_text[:1200].replace("\n", " | "))
        except Exception as exc:
            print(f"PHASE2_TEXT_ERR={exc}")

        screenshot2 = SKILL_ROOT / "screenshots" / "session_probe_phase2.png"
        try:
            await page2.screenshot(path=str(screenshot2), full_page=False, timeout=5000)
        except Exception:
            pass

        await context2.close()


if __name__ == "__main__":
    asyncio.run(main())

