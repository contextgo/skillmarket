#!/usr/bin/env python3
"""导出猎聘候选人列表为 CSV 文件"""

import sqlite3
import csv
import json
from pathlib import Path

def export_candidates_csv(job_id: str, output_path: str):
    """导出候选人列表到 CSV"""
    
    db_path = Path(__file__).parent / "runtime" / "state.db"
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # 查询候选人数据
    query = """
    SELECT 
      q.queue_id,
      q.page_number,
      q.position_in_page,
      q.candidate_key,
      q.status,
      preview_eval.decision as preview_decision,
      detail_eval.decision as detail_decision,
      preview_eval.evaluation_payload_json,
      detail_eval.evaluation_payload_json
    FROM candidate_queue q
    LEFT JOIN candidate_evaluations preview_eval 
      ON q.queue_id = preview_eval.queue_id 
      AND preview_eval.stage = 'preview'
    LEFT JOIN candidate_evaluations detail_eval 
      ON q.queue_id = detail_eval.queue_id 
      AND detail_eval.stage = 'detail'
    WHERE q.job_id = ?
    ORDER BY q.page_number, q.position_in_page
    """
    
    cursor.execute(query, (job_id,))
    rows = cursor.fetchall()
    
    # 写入 CSV
    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        
        # 表头
        writer.writerow([
            "序号", "候选人", "页码", "位置", "状态", 
            "Preview 决策", "Detail 决策", "Preview 理由", "Detail 理由"
        ])
        
        # 数据
        for row_idx, row in enumerate(rows, start=1):
            preview_payload = json.loads(row['evaluation_payload_json']) if row['evaluation_payload_json'] else {}
            detail_payload = json.loads(row['detail_eval_decision']) if row['detail_eval_decision'] else {}
            
            preview_reason = preview_payload.get('reason', '')
            detail_reason = detail_payload.get('reason', '') if detail_payload else ''
            
            writer.writerow([
                row_idx,
                row['candidate_key'] or 'N/A',
                row['page_number'],
                row['position_in_page'],
                row['status'],
                row['preview_decision'] or 'N/A',
                row['detail_decision'] or 'N/A',
                preview_reason,
                detail_reason
            ])
    
    conn.close()
    print(f"✓ 已导出 {len(rows)} 名候选人到 {output_path}")
    return output_path

if __name__ == "__main__":
    job_id = "028aac77-4f57-49b6-8e3f-0321a82f002d"
    output_path = Path(__file__).parent / f"candidates_{job_id[:8]}.csv"
    export_candidates_csv(job_id, str(output_path))
