# Liepin Agentic Sourcing

Liepin sourcing skill with a background runtime facade, browser automation helpers, and placeholder hooks for JD-planning and resume-evaluation LLM workers.

## Current runtime mode

`scripts/jd_search_and_communicate.py` is a compatibility facade. It submits one background runtime job, prints the `job_id`, and exits. The long-running workflow now lives under `src/liepin_skill/runtime/`.

## Required setup before use

Set these environment variables before running the login/session scripts:
- `LIEPIN_USERNAME`
- `LIEPIN_PASSWORD`

Set these placeholders before enabling the multiprocess runtime on OpenClaw:
- `JD_WORKER_LLM_PROVIDER`
- `JD_WORKER_LLM_MODEL`
- `RESUME_WORKER_LLM_PROVIDER`
- `RESUME_WORKER_LLM_MODEL`

This package is intentionally sanitized. It should not contain a real Liepin password or live LLM API credential.

## Main entrypoints

### 1. Bootstrap or refresh the saved Liepin session

```bash
/home/admin/.pyenv/shims/python3 scripts/login_and_save_session.py
```

This script reads `LIEPIN_USERNAME` and `LIEPIN_PASSWORD`, logs into Liepin if needed, and saves the persistent browser session under `liepin_chromium_profile/`.

### 2. Keep a headless session alive

```bash
/home/admin/.pyenv/shims/python3 scripts/login_hold_session.py
```

### 3. Verify the saved session can be reopened

```bash
/home/admin/.pyenv/shims/python3 scripts/session_persistence_probe.py
```

### 4. Submit a sourcing job

```bash
/home/admin/.pyenv/shims/python3 scripts/jd_search_and_communicate.py
```

Dry-run verification:

```bash
/home/admin/.pyenv/shims/python3 scripts/jd_search_and_communicate.py --dry-run
```

Expected dry-run behavior:
- prints a new `job_id`
- creates `runtime/state.db`
- creates `runtime/jobs/<job_id>/`
- exits without starting Playwright workers

## Runtime architecture

One job launches one process group:
- `orchestrator`
- `browser-worker`
- `jd-worker`
- `resume-worker`

The internal canonical search model is a 5-group OR search plan. Accounts without compound-search support use the fallback adapter in `src/liepin_skill/runtime/search_mode_adapter.py`.

## Notes for OpenClaw migration

- `jd-worker` uses placeholder interfaces only for expensive LLM planning and `smart-search` enrichment.
- `resume-worker` uses placeholder interfaces only for lightweight per-candidate evaluation.
- Real provider wiring should be added after migration to OpenClaw.

## Verification

Recommended local verification:

```bash
python -m pytest tests/test_runtime_db.py tests/test_search_mode_adapter.py tests/test_worker_jd.py tests/test_worker_resume.py tests/test_worker_browser.py tests/test_orchestrator.py tests/test_launcher.py tests/test_runtime_config.py tests/test_models.py tests/test_planner.py tests/test_evaluator.py tests/test_run_controller.py -v
```

## Important generated paths

- `runtime/` - job-scoped runtime state and checkpoints
- `liepin_chromium_profile/` - persistent browser profile
- `screenshots/` - optional operator diagnostics

These generated directories should not be committed to version control.
