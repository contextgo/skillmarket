# OpenClaw Setup Checklist

This checklist is for moving the sanitized Liepin skill package onto an OpenClaw host.

## 1. Runtime prerequisites

Install or verify:
- Python 3.11
- Playwright
- Chromium for Playwright

Recommended Python:

```bash
/home/admin/.pyenv/shims/python3
```

Install dependencies:

```bash
/home/admin/.pyenv/shims/python3 -m pip install -e ".[dev]"
/home/admin/.pyenv/shims/python3 -m playwright install chromium
```

## 2. Required environment variables

Provide Liepin employer credentials before using the login/session scripts:

```bash
export LIEPIN_USERNAME="<your_liepin_username>"
export LIEPIN_PASSWORD="<your_liepin_password>"
```

Provide subprocess LLM placeholders before enabling JD-worker and resume-worker model integrations:

```bash
export JD_WORKER_LLM_PROVIDER="<provider_name>"
export JD_WORKER_LLM_MODEL="<model_name>"
export RESUME_WORKER_LLM_PROVIDER="<provider_name>"
export RESUME_WORKER_LLM_MODEL="<model_name>"
```

These variables are placeholders only in the current package. The real provider wiring should be completed after migration to OpenClaw.

## 3. First-time session bootstrap

Run:

```bash
/home/admin/.pyenv/shims/python3 scripts/login_and_save_session.py
```

Expected outcome:
- the script logs into Liepin
- the persistent browser profile is created under `liepin_chromium_profile/`
- the authenticated session is saved for later reuse

## 4. Verify the session can be reopened

Run:

```bash
/home/admin/.pyenv/shims/python3 scripts/session_persistence_probe.py
```

Expected outcome:
- the script reopens the saved profile
- it confirms the session is still valid
- it exits without requiring a fresh login when the session is healthy

## 5. Submit a dry-run job before real sourcing

Run:

```bash
/home/admin/.pyenv/shims/python3 scripts/jd_search_and_communicate.py --dry-run
```

Expected outcome:
- prints a new `job_id`
- creates `runtime/state.db`
- creates `runtime/jobs/<job_id>/`
- exits without starting Playwright workers

## 6. Submit a real runtime job

Edit the example `JD_CRITERIA` block in:
- `scripts/jd_search_and_communicate.py`

Then run:

```bash
/home/admin/.pyenv/shims/python3 scripts/jd_search_and_communicate.py
```

Expected runtime behavior:
- submits one background job
- starts the runtime process group
- uses the compatibility facade to hand off to `src/liepin_skill/runtime/`

## 7. Runtime architecture on OpenClaw

Each job launches:
- `orchestrator`
- `browser-worker`
- `jd-worker`
- `resume-worker`

Important boundaries:
- only `browser-worker` should touch Playwright or the Liepin browser profile
- `jd-worker` owns JD planning and OR-group search-plan generation
- `resume-worker` evaluates one candidate at a time without shared resume memory

## 8. Canonical search model and fallback

The internal canonical search representation is always a 5-group OR search plan.

Execution behavior:
- if the account supports grouped compound search, the browser layer uses grouped mode
- if the account only has a single search bar, the browser layer falls back through `src/liepin_skill/runtime/search_mode_adapter.py`

## 9. Important generated paths

- `runtime/` - runtime state and job checkpoints
- `liepin_chromium_profile/` - persistent browser profile
- `screenshots/` - optional diagnostics

Do not commit these generated directories.

## 10. Common operator checks

If a login/session script fails immediately with a configuration error:
- verify `LIEPIN_USERNAME`
- verify `LIEPIN_PASSWORD`

If dry-run does not create runtime artifacts:
- verify the current working directory is the skill root
- verify Python can import `src/liepin_skill`

If real sourcing runs but the model workers are still placeholders:
- verify the four LLM environment variables are set
- then complete provider wiring in the OpenClaw environment
