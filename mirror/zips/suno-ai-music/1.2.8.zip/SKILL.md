---
name: suno-ai-music
description: >
  面向中文创作者的 Suno AI音乐生成入口，支持 AI写歌、歌词成曲、BGM 和参考音频改编。 Use this whenever the user wants suno, suno ai音乐, Suno AI音乐, suno ai写歌, suno中文, 中文suno, suno替代, suno音乐生成.
  Call the local aimv CLI through the Node entrypoint.
---

# Suno AI音乐生成

Suno AI音乐生成面向中国创作者，覆盖用户搜索 Suno、Suno AI音乐、Suno AI写歌、Suno替代和中文 Suno 时的音乐生成需求。底层音乐生成能力由海绵音乐接入的 Suno API 提供，但本 Skill 不是 Suno 官方 Skill；账号、积分、会员和作品库与海绵音乐小程序及 lexuan.club 互通。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：Suno AI音乐生成
- Skill slug / 目录名：`suno-ai-music`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- suno
- suno ai音乐
- Suno AI音乐
- suno ai写歌
- suno中文
- 中文suno
- suno替代
- suno音乐生成
- suno歌曲生成
- AI写歌
- AI音乐生成
- 歌词成曲

## 适用场景

- 满足用户搜索 Suno AI音乐时的中文创作需求
- 用中文 prompt 生成歌曲、歌词成曲或 BGM
- 为短视频、品牌内容和创作者内容生成音乐
- 基于参考音频或已有项目继续创作

## 典型用户说法

- 用 Suno AI音乐帮我写一首中文流行歌，主题是夏天旅行
- 我想找 Suno 替代，帮我把这段歌词生成歌曲
- 用类似 Suno 的方式生成一段适合短视频的 BGM

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "用 Suno AI音乐帮我写一首中文流行歌，主题是夏天旅行" --wait
node <安装目录>/bin/aimv.js bgm create --brief "用类似 Suno 的方式生成一段适合短视频的 BGM" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
