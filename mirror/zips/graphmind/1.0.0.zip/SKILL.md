---
name: graphmind
version: 2.0
description: Persistent knowledge graph engine for agents with structured memory, task orchestration, dependency tracking, and cross-skill state synchronization.
entry: scripts/graphmind.py
---

# 🧠 GraphMind 图谱大脑系统

GraphMind 是一个为 Agent 设计的结构化知识图谱引擎，用于统一管理记忆、任务、依赖关系与跨技能协作。

GraphMind is a structured knowledge graph engine for agents, designed to unify memory, tasks, dependencies, and cross-skill coordination.

---

## 🎯 核心定位 | Core Purpose

GraphMind 的目标不是单纯存储信息，而是构建一个：

GraphMind is not just a storage system, but a:

> **可计算的认知结构系统（Computable Cognitive System）**

它让 Agent 能够：

It enables agents to:

- 记住（Memory）
- 推理（Reasoning）
- 调度任务（Task orchestration）
- 管理依赖（Dependency management）
- 协调多个技能（Cross-skill coordination）

---

## 🧩 核心能力 | Core Capabilities

### 1️⃣ 结构化记忆 | Structured Memory

所有信息都以实体（Entity）形式存储。

All information is stored as entities.

```text
Entity = { id, type, properties, relations }