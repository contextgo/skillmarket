import json
import uuid
from pathlib import Path

DB_PATH = Path("memory/graphmind/graph.jsonl")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


# -------------------------
# IO Layer
# -------------------------

def load():
    if not DB_PATH.exists():
        return []
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def save(record):
    with open(DB_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


# -------------------------
# Core Engine
# -------------------------

def create_entity(entity_type, props):
    entity = {
        "id": f"{entity_type.lower()}_{uuid.uuid4().hex[:8]}",
        "type": entity_type,
        "properties": props
    }

    record = {"op": "create", "entity": entity}
    save(record)
    return entity


def relate(from_id, rel, to_id):
    record = {
        "op": "relate",
        "from": from_id,
        "rel": rel,
        "to": to_id
    }
    save(record)
    return record


def query(entity_type=None, where=None):
    data = load()
    results = []

    for r in data:
        if r["op"] != "create":
            continue

        e = r["entity"]

        if entity_type and e["type"] != entity_type:
            continue

        if where:
            match = True
            for k, v in where.items():
                if e["properties"].get(k) != v:
                    match = False
                    break
            if not match:
                continue

        results.append(e)

    return results


# -------------------------
# Simple inference
# -------------------------

def infer_blocking_tasks(task_id):
    data = load()
    blocked = []

    for r in data:
        if r["op"] == "relate" and r["rel"] == "depends_on" and r["to"] == task_id:
            blocked.append(r["from"])

    return blocked


# -------------------------
# CLI
# -------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd")

    c = sub.add_parser("create")
    c.add_argument("--type")
    c.add_argument("--props")

    r = sub.add_parser("relate")
    r.add_argument("--from")
    r.add_argument("--rel")
    r.add_argument("--to")

    q = sub.add_parser("query")
    q.add_argument("--type")
    q.add_argument("--where")

    args = parser.parse_args()

    if args.cmd == "create":
        print(create_entity(args.type, json.loads(args.props)))

    elif args.cmd == "relate":
        print(relate(args.from, args.rel, args.to))

    elif args.cmd == "query":
        where = json.loads(args.where) if args.where else None
        print(query(args.type, where))