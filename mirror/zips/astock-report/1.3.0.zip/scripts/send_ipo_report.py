#!/usr/bin/env python3
"""A股IPO周报 - 微信友好版（周三~下周二自动周期）"""
import json, subprocess, re, os
import pandas as pd
from datetime import datetime, timedelta
import sys

# ── 防并发原子锁（O_EXCL 保证只一个进程能进入）─────────────
_LOCK_FILE = "/tmp/a_stock_ipo.lock"

def _acquire_lock():
    """原子创建锁文件；若已有实例则立即退出。"""
    import errno
    try:
        fd = os.open(_LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        os.close(fd)
        return True
    except OSError as e:
        if e.errno == errno.EEXIST:
            print(f"[LOCK] 已有实例在运行 ({_LOCK_FILE})，退出。")
            return False
        raise

def _release_lock():
    if os.path.exists(_LOCK_FILE):
        os.remove(_LOCK_FILE)

# ── 防重：按「执行日期+周期末日期」去重，同一周期只发送一次 ──
_STATE_FILE = "/workspace/scripts/.ipo_report_sent"

def _mark_sent_for_period(period_key):
    """记录今日执行的周期标识（YYYYMMDD），用于去重"""
    with open(_STATE_FILE, "w") as f:
        f.write(f"{NOW.strftime('%Y%m%d')}|{period_key}")

def _already_sent_for_period(period_key):
    """今日已运行过相同周期则跳过（不同周期正常发送）"""
    if not os.path.exists(_STATE_FILE):
        return False
    content = open(_STATE_FILE).read().strip()
    if not content:
        return False
    parts = content.split("|")
    if len(parts) != 2:
        return False  # 格式异常，视为未发送过
    sent_date, sent_period = parts
    today = NOW.strftime("%Y%m%d")
    if sent_date != today:
        return False  # 新的一天，清洗旧记录
    return sent_period == period_key

# ── 周期计算（需要先引入 now_bj）──────────────────────────
sys.path.insert(0, "/workspace/skills/A-stock-report/scripts")
from common import get_ipo_report_period, now_bj

NOW = now_bj()

# ── 原子锁：在周期计算之前就拦截并发 ──────────────────────
if not _acquire_lock():
    sys.exit(0)
_period_start_dt, _period_end_dt, REPORT_START, PERIOD_END_STR = get_ipo_report_period(NOW)
# 周期唯一标识：用于文件命名（YYYYMMDD = 周期末日期）
_PERIOD_KEY = _period_end_dt.strftime("%Y%m%d")  # e.g. "20260424"

# ── 兜底检查：周期距今不超过3周，超出则视为异常拒绝发送 ──
_days_old = (NOW.date() - _period_end_dt.date()).days
if _days_old > 21:
    print(f"[IPO周报] ⚠️ 周期 {_period_start_dt.date()}～{_period_end_dt.date()} 距今 {_days_old} 天（>{21}天），疑似数据异常，拒绝发送！")
    sys.exit(1)

if _already_sent_for_period(_PERIOD_KEY):
    print(f"[IPO周报] 今日（{NOW.strftime('%Y%m%d')}）已运行过相同周期({_PERIOD_KEY})，跳过")
    sys.exit(0)
# 周期：本周一 ～ 本周五
PERIOD_START = _period_start_dt
PERIOD_END   = _period_end_dt
# 下周上会计划截止日：本期周五 + 7天 = 下下周五
_w = NOW.weekday()
_days_to_next_fri = (11 - _w) % 7 + 7   # 距下下周五的天数
THIS_WEEK_END = (_period_end_dt + timedelta(days=7)).strftime("%m/%d")   # 下周周期截止日（下下周五）
NEXT_WEEK_END = (_period_end_dt + timedelta(days=14)).strftime("%m/%d")   # 下下周周期截止日
QUEUE_DATE    = _period_end_dt.strftime("%Y年%m月%d日")

# ── Webhook ───────────────────────────────────────────────
sys.path.insert(0, "/workspace/keys")
from keys_loader import get_webhook_url

def wx(text, max_retries=2):
    """发送消息到企业微信，带自动重试（errcode!=0 时重试）"""
    d = {"msgtype": "text", "text": {"content": text}}
    p = json.dumps(d, ensure_ascii=False)
    for attempt in range(max_retries + 1):
        r = subprocess.run(
            ["curl", "-s", "-X", "POST", get_webhook_url(),
             "-H", "Content-Type: application/json", "-d", "@-"],
            input=p.encode("utf-8"), capture_output=True)
        try:
            errcode = json.loads(r.stdout.decode()).get("errcode", -1)
        except:
            errcode = -1
        if errcode == 0:
            return 0
        print(f"[WX] 发送失败，errcode={errcode}，{'重试中...' if attempt < max_retries else '放弃'}")
    return -1

def shname(name, n=12):
    return name[:n] + ".." if len(name) > n else name

def sdate(dt):
    return str(dt)[5:7] + "/" + str(dt)[8:10]

def board_alias(b):
    return {"上交所科创板": "科创板", "深交所创业板": "创业板",
            "深交所主板": "深主板", "上交所主板": "沪主板",
            "北交所": "北交所"}.get(b, b)

# ── 首日涨幅历史数据（兜底用，自动搜索优先）────────────────
LISTINGS_GAIN_HISTORY = {
    "301683": {"name": "慧谷新材", "date": "04/01", "gain": "61.66%"},
    "001257": {"name": "盛龙股份", "date": "03/31", "gain": "254.0%"},
    "688813": {"name": "泰金新能", "date": "03/31", "gain": "88.24%"},
    "920055": {"name": "隆源股份", "date": "03/31", "gain": "53.04%"},
    "920188": {"name": "悦龙科技", "date": "03/30", "gain": "184.0%"},
}

# ── 首日涨幅自动搜索 ───────────────────────────────────────
import re

def _call_web_search(queries):
    """通过 gateway HTTP API 调用 batch_web_search"""
    import urllib.request, urllib.error
    payload = json.dumps({
        "tool": "batch_web_search",
        "action": "json",
        "args": {"queries": [{"query": q, "num_results": 3} for q in queries]}
    }).encode("utf-8")
    req = urllib.request.Request(
        "http://localhost:18789/tools/invoke",
        data=payload,
        headers={
            "Authorization": "Bearer minimax-agent",
            "Content-Type": "application/json"
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
        # gateway 返回: result.content[i].text 是嵌套 JSON 字符串
        # 需解析到 formatted_content 层供 _extract_gain 使用
        blocks = raw.get("result", {}).get("content", [])
        for b in blocks:
            text = b.get("text", "")
            if text:
                try:
                    # text 是 {"content": [{"text": "{\"data\": [...]}"}, ...]} → 解析两次
                    layer1 = json.loads(text)
                    inner_text = layer1.get("content", [{}])[0].get("text", "")
                    layer2 = json.loads(inner_text)
                    fc = layer2.get("data", [{}])[0].get("formatted_content", [])
                    b["formatted_content"] = fc
                except Exception:
                    b["formatted_content"] = []
            else:
                b["formatted_content"] = []
        return raw
    except Exception as e:
        print(f"[首日涨幅] gateway API 失败: {e}")
        return {}

def _extract_gain(raw_text, code, name):
    """从搜索文本中提取首日涨幅百分比"""
    patterns = [
        r'涨幅?\s*([-+]?\d+\.?\d*)\s*%',
        r'首日[涨落]\s*([-+]?\d+\.?\d*)\s*%',
        r'([-+]?\d+\.?\d*)%',
    ]
    candidates = []
    for pat in patterns:
        for m in re.finditer(pat, raw_text):
            v = float(m.group(1))
            if 10 < v < 500:  # 新股合理涨幅区间
                candidates.append(v)
    if candidates:
        candidates.sort()
        return f"{candidates[len(candidates)//2]:.2f}%"
    return None

def _fetch_first_day_gains(listings):
    """
    自动搜索本期上市新股的首日涨幅（逐个发请求，避免批量合并丢失数据）。
    listings: [(code, name, date_str), ...]
    返回: {code: {"name":..., "date":..., "gain": "XX.XX%"}, ...}
    """
    if not listings:
        return {}
    # 逐个发请求：避免 batch 合并 block 导致部分结果丢失
    result = {}
    for code, name, date_str in listings:
        query = f"{name} {code} 上市首日收盘涨幅 {date_str}"
        raw = _call_web_search([query])
        content_blocks = raw.get("result", {}).get("content", [])
        block = content_blocks[0] if content_blocks else {}
        fc = block.get("formatted_content", [])
        snippets = " ".join(item.get("snippet", "") for item in fc if isinstance(item, dict))
        gain = _extract_gain(snippets, code, name)
        result[code] = {"name": name, "date": date_str, "gain": gain or "无数据"}
    fetched = {k: v["gain"] for k, v in result.items()}
    print(f"[首日涨幅] 搜索结果: {fetched}")
    return result
    for i, (code, name, date_str) in enumerate(listings):
        block = content_blocks[i].get('formatted_content', []) if i < len(content_blocks) else []
        # formatted_content 现在是列表，每项是 {"title","snippet"...}
        snippets = ' '.join(
            item.get('snippet', '') for item in block
            if isinstance(item, dict)
        )
        gain = _extract_gain(snippets, code, name)
        result[code] = {"name": name, "date": date_str, "gain": gain or "无数据"}
    fetched = {k: v['gain'] for k, v in result.items()}
    # DEBUG
    sample_block = content_blocks[0] if content_blocks else {}
    print(f"[首日涨幅] DEBUG fc数量={len(sample_block.get('formatted_content',[]))} snippet前50={str(sample_block.get('formatted_content',[])[0].get('snippet',''))[:50] if sample_block.get('formatted_content') else '空'}")
    print(f"[首日涨幅] 搜索结果: {fetched}")
    return result

def fmt_price(v):
    if pd.isna(v): return "N/A"
    return f"{v:.2f}元"

# ── 数据拉取（AKShare）─────────────────────────────────────
import akshare as ak

_pstart_str = PERIOD_START.strftime("%Y-%m-%d")
_pend_str   = PERIOD_END.strftime("%Y-%m-%d")
# 下周期（再下周）截止日 = 本期周五 + 14天
_pnext_fri = (_period_end_dt + timedelta(days=14)).strftime("%Y-%m-%d")

review = ak.stock_ipo_review_em()
review["上会日期"] = pd.to_datetime(review["上会日期"], errors="coerce").dt.tz_localize(None)
_pstart_ts = pd.Timestamp(_pstart_str)  # tz-naive
_pend_ts   = pd.Timestamp(_pend_str)   # tz-naive，本周五（含）← 已确保不丢
# 下周期起止：本期周五 +7天 ~ +14天（tz-naive，保持一致）
_next_start_ts = (_period_end_dt + timedelta(days=7))
_next_end_ts   = (_period_end_dt + timedelta(days=14))
recent_r = (review
    .loc[review["上会日期"].between(_pstart_ts, _pend_ts)]
    .dropna(subset=["上会日期"])
    .sort_values("上会日期"))
next_r = (review
    .loc[review["上会日期"].between(
            pd.Timestamp(_next_start_ts.strftime("%Y-%m-%d")),
            pd.Timestamp(_next_end_ts.strftime("%Y-%m-%d")))]
    .dropna(subset=["上会日期"])
    .sort_values("上会日期"))

df = ak.stock_new_ipo_cninfo()
df["申购_dt"] = pd.to_datetime(df["申购日期"], errors="coerce").dt.tz_localize(None)
df["上市_dt"] = pd.to_datetime(df["上市日期"], errors="coerce").dt.tz_localize(None)
recent_a = (df
    .loc[df["申购_dt"].between(pd.Timestamp(_pstart_str), pd.Timestamp(_pend_str))]
    .dropna(subset=["申购_dt"])
    .sort_values("申购_dt"))
next_a = (df
    .loc[df["申购_dt"].between(
            pd.Timestamp((_period_end_dt + timedelta(days=3)).strftime("%Y-%m-%d")),  # 下下周一
            pd.Timestamp(_pnext_fri))]
    .dropna(subset=["申购_dt"])
    .sort_values("申购_dt"))
recent_l = (df
    .loc[df["上市_dt"].between(pd.Timestamp(_pstart_str), pd.Timestamp(_pend_str))]
    .dropna(subset=["上市_dt"])
    .sort_values("上市_dt"))

queue = ak.stock_ipo_declare_em()
queue["更新日期"] = pd.to_datetime(queue["更新日期"], errors="coerce").dt.tz_localize(None)
recent_up = queue[queue["更新日期"].between(pd.Timestamp(_pstart_str), pd.Timestamp(_pend_str))]
reg_up    = recent_up[recent_up["最新状态"].isin(["注册", "核准"])].dropna(subset=["企业名称"])

# ── 排队数据（从新浪财经/ipo123 每周IPO统计文章抓取，口径=交易所在审数）──
# 参考来源：https://finance.sina.com.cn/stock/relnews/cn/ 最新周报
# 数据口径：沪深北交易所官网"在审"状态，与 AKShare 全历史累计不同

def _fetch_queue_from_web():
    """
    从新浪财经每周IPO统计文章抓取排队数据。
    返回 (dict: board -> total, str: 统计截至日期, str: 来源URL/备注)
    抓取失败时返回 None，触发兜底逻辑。
    """
    import urllib.request, json, re

    # 搜索最新 IPO 周报文章（优先新浪财经）
    search_payload = json.dumps({
        "tool": "batch_web_search",
        "action": "json",
        "args": {
            "queries": [{
                "query": "site:finance.sina.com.cn IPO排队企业 周报 2026年",
                "num_results": 5
            }]
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        "http://localhost:18789/tools/invoke",
        data=search_payload,
        headers={
            "Authorization": "Bearer minimax-agent",
            "Content-Type": "application/json"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
        blocks = raw.get("result", {}).get("content", [])
        article_url = None
        for b in blocks:
            txt = b.get("text", "")
            if txt:
                try:
                    layer1 = json.loads(txt)
                    inner = layer1.get("content", [{}])[0].get("text", "")
                    layer2 = json.loads(inner)
                    fc = layer2.get("data", [{}])[0].get("formatted_content", [])
                    for item in fc:
                        snippet = item.get("snippet", "")
                        link = item.get("link", "")
                        if "IPO排队" in snippet and ("家" in snippet) and "finance.sina.com.cn" in link:
                            article_url = link
                            break
                except Exception:
                    pass
            if article_url:
                break
        if not article_url:
            print("[排队] 未找到新浪 IPO 周报文章，跳过")
            return None

        # 提取文章内容
        extract_req = json.dumps({
            "tool": "extract_content_from_websites",
            "action": "json",
            "args": {
                "tasks": [{
                    "url": article_url,
                    "prompt": "提取：1)统计截至日期 2)各板块排队数量(沪主板/科创板/深主板/创业板/北交所) 3)总数量",
                    "task_name": "ipo_queue"
                }]
            }
        }).encode("utf-8")
        req2 = urllib.request.Request(
            "http://localhost:18789/tools/invoke",
            data=extract_req,
            headers={"Authorization": "Bearer minimax-agent", "Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req2, timeout=20) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        blocks2 = result.get("result", [{}])[0].get("content", [])
        text = blocks2[0].get("text", "") if blocks2 else ""

        # 解析文本中的数字
        # 匹配 "X家" 模式
        board_map = {
            "沪主板": "沪主板", "科创板": "科创板",
            "深主板": "深主板", "创业板": "创业板", "北交所": "北交所",
        }
        result_dict = {}
        date_str = ""
        total = 0
        for board_key, board_norm in board_map.items():
            pattern = rf"{board_key}.*?(\d{{1,4}})\u5bb6"
            m = re.search(pattern, text)
            if m:
                result_dict[board_norm] = int(m.group(1))

        # 提取总数量
        tm = re.search(r"IPO排队企业(\d{1,4})\u5bb6", text)
        if tm:
            total = int(tm.group(1))

        # 提取日期
        dm = re.search(r"\u622e\u81f3(\d{1,2}\u6708\d{1,2}\u65e5)", text)
        if dm:
            date_str = dm.group(1)

        if not result_dict:
            print(f"[排队] 文章解析失败: {text[:200]}")
            return None

        src = f"新浪财经（截至{date_str}）" if date_str else "新浪财经"
        print(f"[排队] 实时抓取成功: {result_dict}，总计{total}家 来源:{src}")
        return {"boards": result_dict, "total": total, "source": src, "url": article_url}

    except Exception as e:
        print(f"[排队] 实时抓取失败: {e}，使用 AKShare 兜底")
        return None

def _build_queue_from_akshare(q_df):
    """从 AKShare DataFrame 构建排队数据（兜底用，不推荐）"""
    # 此函数已被 _build_queue_stats 替代，仅作兜底保留
    return None

def _build_queue_stats(q_df):
    """从 ak.stock_ipo_declare_em() 的 DataFrame 构建排队统计数据"""
    # 状态归一化映射（多个 AKShare 状态名 → 报告展示名）
    STATUS_MAP = {
        "问询": ["进一步问询中", "已问询"],
        "已受理": ["已受理"],
        "已反馈": ["已反馈"],
        "预先披露更新": ["预先披露更新"],
        "已过会": ["已通过发审会"],
        "注册": ["注册", "已收到注册申请材料"],
        "核准": ["核准"],
        "中止": ["中止", "中止审查", "中止发行注册程序"],
        "辅导备案": ["辅导备案登记受理"],
        "上市委通过": ["上市委会议通过", "上市委会议暂缓"],
        "上会暂缓": ["已上发审会，暂缓表决", "已上发审会,暂缓表决"],
    }
    rev_map = {}  # AKShare状态名 → 归一化名
    for norm, names in STATUS_MAP.items():
        for n in names:
            rev_map[n] = norm

    # 按「板块 × 归一化状态」聚合
    q = q_df.copy()
    q["norm_status"] = q["最新状态"].map(rev_map).fillna("其他")
    agg = q.groupby(["拟上市地点", "norm_status"])["企业名称"].count().reset_index()
    agg.columns = ["板块", "状态", "数量"]

    # 汇总到各板块
    BOARD_ORDER = ["科创板", "创业板", "沪主板", "深主板", "北交所"]
    RESULT = {}
    TOTALS = {"全市场": 0, "问询中": 0, "已过会": 0, "提交注册": 0}

    for board in BOARD_ORDER:
        sub = agg[agg["板块"] == board].set_index("状态")["数量"]
        total = int(sub.sum())
        RESULT[board] = []
        key_map = {
            "问询": ("问询", "问询中"),
            "已受理": ("已受理", None),
            "已反馈": ("已反馈", None),
            "预先披露更新": ("预先披露", None),
            "已过会": ("过会", "已过会"),
            "注册": ("注册", "提交注册"),
            "核准": ("核准", "已过会"),
            "中止": ("中止", None),
            "辅导备案": ("辅导", None),
        }
        for ak_stat, (disp_name, total_key) in key_map.items():
            cnt = int(sub.get(ak_stat, 0))
            if cnt > 0:
                RESULT[board].append((disp_name, cnt))
                if total_key == "问询中":
                    TOTALS["问询中"] += cnt
                elif total_key == "已过会":
                    TOTALS["已过会"] += cnt
                elif total_key == "提交注册":
                    TOTALS["提交注册"] += cnt
        RESULT[board].append(("合计", total))
        TOTALS["全市场"] += total

    return RESULT, TOTALS

_queue_raw = queue  # ak.stock_ipo_declare_em() 结果已在前面赋值

# ── 排队数据：优先抓取新浪财经周报（口径=交易所官方在审），兜底用 AKShare ─
_ak_queue = _build_queue_stats(_queue_raw)  # 兜底数据

# 尝试实时抓取新浪/ipo123 周报
_web_queue = _fetch_queue_from_web()

if _web_queue:
    # 使用抓取数据：board -> total（无状态细分）
    _q_boards = _web_queue["boards"]  # {'沪主板': 17, '科创板': 42, ...}
    _q_total  = _web_queue["total"]  # 291
    _q_source = _web_queue["source"]  # "新浪财经（截至04月19日）"
    _q_grand_total = sum(_q_boards.values())
    QUEUE = {b: [("合计", _q_boards.get(b, 0))] for b in ["科创板","创业板","沪主板","深主板","北交所"]}
    QUEUE_TOTALS = {"全市场": _q_grand_total, "问询中": None, "已过会": None, "提交注册": None}
    QUEUE_DATE = _q_source  # e.g. "新浪财经（截至04月19日）"
    print(f"[排队] 使用实时数据：全市场{_q_grand_total}家 {_q_boards}")
elif _ak_queue:
    # 兜底：使用 AKShare 汇总（包含历史全量，口径偏大，仅供参考）
    QUEUE, QUEUE_TOTALS = _ak_queue
    QUEUE_DATE = QUEUE_DATE  # 保持原日期
    print(f"[排队] 警告：使用 AKShare 兜底数据，全市场{QUEUE_TOTALS['全市场']}家（实际约290家）")
else:
    # 最后的兜底：硬编码上周数据
    _q_boards = {"沪主板": 17, "科创板": 42, "深主板": 16, "创业板": 38, "北交所": 178}
    QUEUE = {b: [("合计", _q_boards.get(b, 0))] for b in ["科创板","创业板","沪主板","深主板","北交所"]}
    QUEUE_TOTALS = {"全市场": sum(_q_boards.values()), "问询中": None, "已过会": None, "提交注册": None}
    QUEUE_DATE = "04月19日（新浪财经，数据略有滞后）"
    print(f"[排队] 使用硬编码兜底：全市场{sum(_q_boards.values())}家")

# ── 组装报告 ───────────────────────────────────────────────
lines = [f"📋 A股IPO周报 {REPORT_START}～{PERIOD_END_STR}", ""]

lines += ["━━━━━━━━━━", f"📊 一、排队情况（{QUEUE_DATE}）", ""]
lines.append(f"全市场共{QUEUE_TOTALS['全市场']}家")
lines.append("")
for board in ["科创板", "创业板", "沪主板", "深主板", "北交所"]:
    total = next((v for k, v in QUEUE[board] if k == "合计"), 0)
    lines.append(f"  【{board}】{total}家")

passed_r = recent_r[recent_r["审核状态"] == "上会通过"]
pending_r = recent_r[recent_r["审核状态"] == "未上会"]
failed_r = recent_r[recent_r["审核状态"].isin(["上会未通过", "取消审核"])]
lines += ["", "━━━━━━━━━━", f"📋 二、本周期上会（{REPORT_START}～{PERIOD_END_STR}）", "",
          f"✅ 通过：{len(passed_r)}家"]
for _, r in passed_r.iterrows():
    lines.append(f"  · {shname(r.get('企业名称', r.get('股票简称','?')))} | "
                 f"{board_alias(r.get('上市板块',''))} | {sdate(r['上会日期'])}")
if len(pending_r) > 0:
    lines.append(f"🔄 待审：{len(pending_r)}家（安排上会，尚未表决）")
    for _, r in pending_r.iterrows():
        lines.append(f"  · {shname(r.get('企业名称', r.get('股票简称','?')))} | "
                     f"{board_alias(r.get('上市板块',''))} | {sdate(r['上会日期'])}")
if len(failed_r) > 0:
    lines.append(f"❌ 否决：{len(failed_r)}家")
    for _, r in failed_r.iterrows():
        lines.append(f"  · {shname(r.get('企业名称', r.get('股票简称','?')))} | "
                     f"{board_alias(r.get('上市板块',''))}")

reg_up2 = recent_up[recent_up["最新状态"].isin(["注册", "核准"])].dropna(subset=["企业名称"])
lines += ["", "━━━━━━━━━━", f"📋 三、本周期获批（{REPORT_START}～{PERIOD_END_STR}）", ""]
if len(reg_up2) > 0:
    lines.append(f"📄 获发行批文：{len(reg_up2)}家")
    for _, r in reg_up2.iterrows():
        lines.append(f"  · {shname(r.get('企业名称',''))} | "
                     f"{board_alias(r.get('拟上市地点',''))} | "
                     f"{str(r['更新日期'])[:10]}")
else:
    lines.append("  （暂无数据）")

term_up = recent_up[recent_up["最新状态"].isin(["终止"])].dropna(subset=["企业名称"])
lines += ["", "━━━━━━━━━━", f"📋 四、本周期终止/撤回（{REPORT_START}～{PERIOD_END_STR}）", ""]
if len(term_up) > 0:
    for _, r in term_up.iterrows():
        lines.append(f"  · {shname(r.get('企业名称',''))} | "
                     f"{board_alias(r.get('拟上市地点',''))}")
else:
    lines.append("  本周期无终止撤回记录")

lines += ["", "━━━━━━━━━━", f"📋 五、下周期上会计划（{THIS_WEEK_END}～{NEXT_WEEK_END}）", ""]
if len(next_r) > 0:
    for _, r in next_r.iterrows():
        lines.append(f"  · {shname(r.get('企业名称', r.get('股票简称','?')))} | "
                     f"{board_alias(r.get('上市板块',''))} | "
                     f"计划{sdate(r['上会日期'])}")
else:
    lines.append("  ⚠️ 近期暂无上会安排（数据更新存在滞后，以证监会官网为准）")

lines += ["", "━━━━━━━━━━", f"📋 六、本周期新股上市（{REPORT_START}～{PERIOD_END_STR}）", ""]
if len(recent_l) > 0:
    # 构造待搜索股票列表
    listing_list = [
        (str(r.get("证劵代码","")), str(r.get("证券简称","?")), sdate(r["上市_dt"]))
        for _, r in recent_l.iterrows()
    ]
    # 自动搜索首日涨幅（兜底：旧数据）
    auto_gains = _fetch_first_day_gains(listing_list)

    for _, r in recent_l.iterrows():
        cd = str(r.get("证劵代码", ""))
        # 优先用自动搜索，其次旧数据兜底
        info = auto_gains.get(cd) or LISTINGS_GAIN_HISTORY.get(cd, {})
        nm = r.get("证券简称", info.get("name","?"))
        dt = sdate(r["上市_dt"]) if pd.notna(r.get("上市_dt")) else info.get("date","?")
        gain = info.get("gain", "-")
        pr = fmt_price(r.get("发行价"))
        lines.append(f"  · {nm}（{cd}）| 上市:{dt} | 发行:{pr} | 涨幅:{gain}")
else:
    lines.append("  （无）")

lines += ["", "━━━━━━━━━━",
          f"📌 数据来源：新浪财经+IPO123（统计截至{QUEUE_DATE}）",
          "⚠️ 仅供参考，不构成投资建议。"]

if __name__ == "__main__":
    try:
        import os
        print(f"[TS] 第一步：收集数据...")
        report = "\n".join(lines)
        if report:
            print(f"[TS] 第二步：保存Markdown报告...")
            _dir = "/workspace/projects/A股报告系统/reports"
            os.makedirs(_dir, exist_ok=True)
            _path = os.path.join(_dir, f"IPO周报_{_PERIOD_KEY}.md")
            with open(_path, "w", encoding="utf-8") as f:
                f.write(report)
            print(f"  已保存: {_path}")
            print("\n" + "="*60)
            print(report)
            print("="*60)
            print(f"[TS] 第三步：推送...")
            err2 = wx(report)
            print("\n" + ("✅ 已推送" if err2 == 0 else f"❌ err={err2}"))
            # ── 发送成功后才标记，避免发送失败却仍去重 ──
            if err2 == 0:
                _mark_sent_for_period(_PERIOD_KEY)
                print(f"[去重] 已记录执行日期+周期: {NOW.strftime('%Y%m%d')}|{_PERIOD_KEY}")
    finally:
        _release_lock()
