---
name: tech-explorer
description: 技术趋势追踪超级技能。追踪 GitHub 月度热门项目、AI 领域顶级项目、Awesome 精选资源，生成趋势报告与深度研究。触发词："技术趋势"、"趋势追踪"、"trending"、"热门项目"、"AI 项目"、"awesome [主题]"、"技术探索"、"GitHub 趋势"、"推荐项目"、"find trending projects"、"what's hot on GitHub"、"explore [language/framework]".
---

# Tech Explorer — 技术趋势追踪

追踪 GitHub 技术趋势、挖掘 AI 顶级项目、搜索 Awesome 精选资源、生成深度研究报告。

## 能力概览

| 能力 | 说明 | 工具 |
|------|------|------|
| **Trending** | GitHub 真实 Trending Top 10（直接抓取 github.com/trending 页面） | `fetch_real_trending.py` |
| **OSS Insight** | OSS Insight 综合评分 Top 10（stars/forks/PRs/pushes 多维指标） | `fetch_github_trending.py` |
| **AI Top** | AI 领域活跃高星项目 Top 20（含活跃度过滤） | `fetch_top_starred.py` |
| **Awesome** | 按主题搜索 Awesome 列表并解析项目条目 | `fetch_awesome_list.py` |
| **HF Papers** | Hugging Face 每日热门论文 Top N（点赞排序） | `fetch_hf_papers.py` |
| **DeepWiki** | 对指定仓库生成深度研究报告 | `fetch_deepwiki.py` + 百度补充搜索 |

## 脚本路径

```
skills/tech-explorer/scripts/
├── fetch_real_trending.py      # 真实 GitHub Trending（直接抓取 trending 页面解析）
├── fetch_github_trending.py    # OSS Insight API 综合评分（GitHub Search API fallback）
├── fetch_top_starred.py        # 按 topic 查活跃高星项目（含僵尸项目过滤）
├── fetch_awesome_list.py       # 搜索并解析 Awesome 列表（sindresorhus 快速路径）
├── fetch_deepwiki.py           # DeepWiki 深度研究（含 JS 渲染检测）
├── fetch_hf_papers.py          # Hugging Face 热门论文（hf-mirror.com 镜像 API）
├── generate_excel_report.py    # 生成美化 Excel 报告（4 个 Sheet，openpyxl，手机端可读）
├── generate_hf_papers_excel.py # 单独生成 HF Papers Excel（独立使用时）
└── post_translate_excel.py     # 说明栏英文翻译后处理（extract → AI翻译 → apply）
```

---

## Workflow 1: 技术趋势报告（核心入口）

**触发词**: "趋势追踪"、"技术趋势"、"本月热门"、"trending"、"生成趋势报告"

### 步骤

1. **获取真实 GitHub Trending Top 10**：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_real_trending.py monthly 10
   ```
   支持参数：
   - 时间范围：`daily` / `weekly` / `monthly`（默认 monthly）
   - 数量：默认 10

   > 脚本直接抓取 `github.com/trending?since=monthly` 页面 HTML，解析真实 Trending 项目（含 stars、forks、月增 stars）。

2. **获取 OSS Insight 综合评分 Top 10**：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_github_trending.py "" monthly 10
   ```
   支持参数：
   - 语言过滤：`python3 ... python monthly 10`
   - 时间范围：`daily` / `weekly` / `monthly`（默认 monthly）
   - 数量：默认 10

   > 脚本走 OSS Insight API（TiDB），按 total_score 综合评分排序（含 stars/forks/PRs/pushes 多维指标）。
   > OSS Insight 不可用时自动 fallback 到 GitHub Search API。

3. **获取 AI 项目 Stars Top 20**：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_top_starred.py ai 20
   ```
   支持参数：
   - topic 过滤：`ai`（默认）、`machine-learning`、`deep-learning`、`llm` 等任意 GitHub topic
   - 数量：默认 20

4. **生成趋势报告 Excel**：
   先将步骤 1、2、3 的 JSON 输出分别保存为临时文件，然后调用：
   ```bash
   python3 skills/tech-explorer/scripts/generate_excel_report.py /tmp/real_trending.json /tmp/oss_insight.json /tmp/ai_top.json "clawDocument/草稿/tech-trends-{YYYY-MM}.xlsx"
   ```
   或直接用 openpyxl 内联生成（参考 `generate_excel_report.py` 中的样式定义）。

5. **获取 HF 热门论文 Top 10**：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_hf_papers.py 10 upvotes > /tmp/hf_papers.json
   ```
   支持参数：
   - 数量：默认 10（最大 100）
   - 排序：`upvotes`（默认）或 `date`
   - 代理：可选第3个参数传代理 URL

   > 脚本走 `hf-mirror.com` 镜像 API（国内可访问），获取每日热门论文（含点赞数、arXiv ID、GitHub 仓库、AI 摘要）。

6. **生成趋势报告 Excel**：
   先将步骤 1-5 的 JSON 输出分别保存为临时文件，然后调用：
   ```bash
   python3 skills/tech-explorer/scripts/generate_excel_report.py /tmp/real_trending.json /tmp/oss_insight.json /tmp/ai_top.json "clawDocument/草稿/tech-trends-{YYYY-MM}.xlsx" /tmp/hf_papers.json
   ```
   第5个参数（hf_papers.json）可选，不传则只生成3个 Sheet。

7. **翻译后处理**（说明栏英文→中文）：
   ```bash
   # Step 1: 提取所有英文说明单元格
   python3 skills/tech-explorer/scripts/post_translate_excel.py extract "clawDocument/草稿/tech-trends-{YYYY-MM}.xlsx"
   ```
   脚本输出 JSON，包含所有英文说明单元格的 sheet/row/col/text。
   AI 逐条翻译后，将翻译结果写入 JSON 文件：
   ```json
   {
     "translations": [
       {"sheet": "Trending Top 10", "row": 4, "col": 6, "text": "翻译后的中文"},
       ...
     ]
   }
   ```
   ```bash
   # Step 2: 写回翻译结果
   python3 skills/tech-explorer/scripts/post_translate_excel.py apply "clawDocument/草稿/tech-trends-{YYYY-MM}.xlsx" /tmp/translations.json
   ```

8. **更新 `Document Directory.xlsx`**

9. **直接发送 Excel 文件**（无需文字总结，减少 token 消耗）

### Excel 生成要求

- **四个 Sheet**：`Trending Top 10`（真实 GitHub Trending）、`OSS Insight (综合评分)`、`AI Top 20` 和 `HF Papers Top 10`（Hugging Face 热门论文）
- **字体**：微软雅黑 11-12pt（手机端可读）
- **样式**：
  - 标题行：深蓝底色 (#1F4E79)，白色粗体
  - 数据行：交替浅蓝底色 (#D6EAF8)
  - 项目名：蓝色超链接
  - Score：橙色粗体 (#D35400)
  - 边框：浅灰色细线 (#BDC3C7)
  - 行高：标题 32pt，表头 28pt，数据 34-36pt
- **列宽**：
  - Trending Sheet: # (5) | 项目 (35) | Stars (12) | 本月新增 (14) | 语言 (10) | 简介 (55)
  - OSS Insight Sheet: # (5) | 项目 (35) | Stars (12) | Score (14) | 语言 (10) | 简介 (50)
  - AI Top Sheet: # (5) | 项目 (40) | Stars (14) | 语言 (14) | 简介 (55)
  - HF Papers Sheet: # (5) | 论文标题 (45) | 点赞 (10) | arXiv ID (16) | GitHub (35) | AI 摘要 (55)
- **文件名**：`tech-trends-{YYYY-MM}.xlsx`

参考实现见 `memory/2026-04-08.md` 中的 Python 代码（openpyxl 美化示例）

---

## Workflow 2: Awesome 精选搜索

**触发词**: "awesome [主题]"、"搜索 awesome pdf"、"找 [领域] 最好的项目"、"精选列表"、"推荐 [领域] 开源项目"

### 步骤

1. **调用 Awesome 搜索脚本**：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_awesome_list.py [主题] 20
   ```
   脚本自动执行：
   - 在 GitHub 搜索 `awesome-{keyword}` 仓库（按 stars 排序）
   - 获取最佳匹配仓库的 README
   - 解析 README 中的项目条目（名称、链接、简介）

2. **呈现结果**：
   ```
   📋 Awesome [主题] 精选资源

   来源仓库: awesome-[主题] ⭐ xxx
   🔗 https://github.com/xxx/awesome-[主题]

   --- 精选项目 ---

   1. **项目名** — 简介
      🔗 https://...

   2. ...
   ```

3. 用户对某个项目感兴趣 → 转入 Workflow 3 (DeepWiki)

### Awesome 搜索兜底

如果脚本返回空结果（GitHub API 限流或网络问题），使用百度搜索兜底：
```bash
bash scripts/baidu-search.sh "awesome [主题] GitHub curated list" "" 10
```

---

## Workflow 3: DeepWiki 深度研究（按需触发）

**触发时机**: 用户从趋势报告或 Awesome 中选择了某个项目，说"深入了解"、"详细研究"、"研究一下 xxx"

### 步骤

1. **调用 DeepWiki 脚本**获取项目深度信息：
   ```bash
   python3 skills/tech-explorer/scripts/fetch_deepwiki.py "owner/repo"
   ```

2. **百度补充搜索**（丰富中文语境信息）：
   ```bash
   bash scripts/baidu-search.sh "[项目名] 技术架构 核心功能 使用场景" "" 5
   bash scripts/baidu-search.sh "[项目名] 快速上手 安装教程" "" 5
   ```

3. **合成研究报告**，使用下方模板，保存到 `clawDocument/草稿/`

4. **更新 `Document Directory.xlsx`**

5. **向用户发送报告摘要**（核心亮点 3-5 条），告知完整报告已保存

6. **提醒用户归档**：
   > 📁 研究报告已保存到 `clawDocument/草稿/`，是否移到：
   > - `待处理/` — 等待后续加工
   > - `专题研究/` — 作为研究资料长期保存

### 研究报告模板

```markdown
# {项目名} - 技术研究报告

**项目地址**: {github_url}
**Stars**: {stars} | **Language**: {language} | **License**: {license}
**研究时间**: {YYYY-MM-DD HH:MM:SS}
**数据来源**: DeepWiki + 百度千帆 AI Search

---

## 项目简介
{综合描述}

## 核心功能
{主要特性列表}

## 技术架构
{技术栈和架构信息}

## 适用场景
{应用场景和典型用例}

## 快速上手
{安装方法和基本使用示例}

## 学习资源
{官方文档、教程、社区链接}

---
*报告路径: clawDocument/草稿/tech-research-{项目名}-{timestamp}.md*
```

---

## 一句话自动化流程

**触发词**: "生成本月趋势报告"、"技术趋势追踪"

完整自动化链路：

1. 调用 `fetch_real_trending.py` → 真实 GitHub Trending Top 10
2. 调用 `fetch_github_trending.py` → OSS Insight 综合评分 Top 10
3. 调用 `fetch_top_starred.py` → AI Stars Top 20
4. 调用 `fetch_hf_papers.py` → HF 热门论文 Top 10
5. 用 openpyxl 生成美化 Excel（四个 Sheet）→ 存入 `clawDocument/草稿/`
6. 调用 `post_translate_excel.py extract` → 提取英文说明
7. AI 翻译英文说明为中文 → 生成 translations.json
8. 调用 `post_translate_excel.py apply` → 写回中文翻译
9. 更新 `Document Directory.xlsx`
10. 直接发送 Excel 文件给用户（不附带文字总结，节省 token）

## 文件管理规则

- 所有报告**先存入** `clawDocument/草稿/`
- 趋势报告文件名：`tech-trends-{YYYY-MM}.xlsx`
- 研究报告文件名：`tech-research-{项目名}-{YYYYMMDD-HHMMSS}.md`
- 保存后**必须更新** `Document Directory.xlsx`

## 注意事项

- **所有项目简介必须使用中文**：脚本获取的英文 description 需要在生成报告时翻译为中文，由 AI 在调用脚本后统一处理
- `fetch_real_trending.py` 直接抓取 `github.com/trending` 页面 HTML 并解析，数据最真实
- `fetch_github_trending.py` 走 OSS Insight API（综合评分数据），fallback 到 GitHub Search API
- `fetch_top_starred.py` 走 GitHub Search API，含活跃度过滤（6个月内有push、fork比例检查、排除archived）
- `fetch_awesome_list.py` 优先尝试 sindresorhus 等知名维护者的直接路径，再走 GitHub Search API + README 解析
- `fetch_deepwiki.py` 直连 deepwiki.com，含 JS 渲染检测（needs_browser 标记），内容为空时提示用 web_fetch/browser 重试
- 百度搜索 API Key 存储于 `clawDocument/个人资料/baidu-api.conf`
- 搜索结果以中文综合呈现，英文项目信息保留原文
- 若某数据源返回为空，用其他数据源补充，不报错中断
- **GitHub API 无认证限流 60 次/小时**，脚本间隔调用避免触发限流
