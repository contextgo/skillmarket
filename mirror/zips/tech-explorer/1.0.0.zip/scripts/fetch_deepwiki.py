#!/usr/bin/env python3
"""
Fetch DeepWiki content for a GitHub repository.
Includes content validation and fallback signaling for JS-rendered pages.

Usage: python3 fetch_deepwiki.py <owner/repo>
Example: python3 fetch_deepwiki.py microsoft/vscode
"""
import sys, json, requests
from bs4 import BeautifulSoup

def fetch_deepwiki(repo_path):
    """
    Fetch DeepWiki research content for a repository.
    
    Validates that actual content was extracted (not just empty JS shell).
    If content is empty, sets needs_browser=True to signal the caller
    should retry with a browser-based tool (web_fetch or browser).
    
    Args:
        repo_path: GitHub repo in format 'owner/repo'
    
    Returns:
        dict with title, summary, sections, and metadata
    """
    url = f"https://deepwiki.com/{repo_path}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=25)
        response.raise_for_status()
        
        html = response.text
        soup = BeautifulSoup(html, 'html.parser')
        
        # Check for JS-only shell (SPA indicators)
        # If the body has very little text but lots of script tags, it's likely JS-rendered
        body = soup.find('body')
        body_text = body.get_text(strip=True) if body else ""
        script_count = len(soup.find_all('script'))
        
        is_js_shell = len(body_text) < 200 and script_count > 5
        
        # Extract title
        title = soup.find('h1')
        title_text = title.text.strip() if title else repo_path
        
        # Extract main content sections
        sections = []
        for heading in soup.find_all(['h2', 'h3']):
            section_title = heading.text.strip()
            if not section_title:
                continue
                
            content_parts = []
            for sibling in heading.find_next_siblings():
                if sibling.name in ['h2', 'h3']:
                    break
                if sibling.name in ['p', 'ul', 'ol', 'pre', 'blockquote']:
                    text = sibling.get_text(strip=True)
                    if text:
                        content_parts.append(text)
            
            if content_parts:
                sections.append({
                    "title": section_title,
                    "content": "\n".join(content_parts[:5])  # limit per section
                })
        
        # Extract meta description as summary
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        summary = meta_desc['content'] if meta_desc and meta_desc.get('content') else ""
        
        # Determine if content extraction was successful
        has_content = len(sections) > 0 or len(summary) > 50
        needs_browser = is_js_shell or (not has_content and len(body_text) < 500)
        
        result = {
            "repo": repo_path,
            "url": url,
            "title": title_text,
            "summary": summary,
            "sections": sections[:10],  # top 10 sections
            "has_content": has_content,
            "needs_browser": needs_browser,
        }
        
        if needs_browser:
            result["hint"] = (
                "Content extraction returned minimal results. "
                "This page may require JS rendering. "
                "Retry with: web_fetch or browser tool on " + url
            )
        
        return result
        
    except requests.RequestException as e:
        return {
            "repo": repo_path,
            "url": url,
            "error": str(e),
            "has_content": False,
            "needs_browser": True,
            "hint": f"Request failed: {e}. Retry with web_fetch or browser tool."
        }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 fetch_deepwiki.py <owner/repo>")
        sys.exit(1)
    
    repo = sys.argv[1]
    result = fetch_deepwiki(repo)
    print(json.dumps(result, indent=2, ensure_ascii=False))
