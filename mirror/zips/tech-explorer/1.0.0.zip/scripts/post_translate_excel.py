#!/usr/bin/env python3
"""
Excel 说明栏英文翻译后处理工具
用法:
  提取模式: python3 post_translate_excel.py extract <excel_path>
    → 输出 JSON，包含所有需要翻译的英文单元格信息

  写回模式: python3 post_translate_excel.py apply <excel_path> <translations_json>
    → 将翻译结果写回 Excel 文件

提取模式输出格式:
  {
    "cells": [
      {"sheet": "Trending Top 10", "row": 4, "col": 6, "text": "A framework for..."},
      ...
    ]
  }

写回模式输入格式 (translations_json 文件):
  {
    "translations": [
      {"sheet": "Trending Top 10", "row": 4, "col": 6, "text": "一个用于...的框架"},
      ...
    ]
  }
"""

import sys
import json
import re
import os

try:
    from openpyxl import load_workbook
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip3 install openpyxl", file=sys.stderr)
    sys.exit(1)

# 每个 sheet 中"说明/简介/摘要"列的列号（1-indexed）
# 根据 generate_excel_report.py 的列定义
DESC_COLUMNS = {
    "Trending Top 10": 6,        # 简介
    "OSS Insight (综合评分)": 6,  # 简介
    "AI Top 20": 5,              # 简介
    "HF Papers Top 10": 6,      # AI 摘要
}


def is_english(text):
    """判断文本是否主要为英文（ASCII 字母占比 > 50%）"""
    if not text or not isinstance(text, str):
        return False
    text = text.strip()
    if not text:
        return False
    alpha_chars = sum(1 for c in text if c.isascii() and c.isalpha())
    total_chars = sum(1 for c in text if c.isalpha())
    if total_chars == 0:
        return False
    return (alpha_chars / total_chars) > 0.5


def extract(excel_path):
    """提取所有需要翻译的英文说明单元格"""
    wb = load_workbook(excel_path, data_only=True)
    cells = []

    for sheet_name, desc_col in DESC_COLUMNS.items():
        if sheet_name not in wb.sheetnames:
            continue
        ws = wb[sheet_name]
        # 数据从第4行开始（第1行标题，第2行副标题，第3行表头）
        for row in range(4, ws.max_row + 1):
            cell = ws.cell(row=row, column=desc_col)
            text = cell.value
            if text and is_english(str(text)):
                cells.append({
                    "sheet": sheet_name,
                    "row": row,
                    "col": desc_col,
                    "text": str(text)
                })

    result = {"cells": cells, "total": len(cells)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return cells


def apply_translations(excel_path, translations_json):
    """将翻译结果写回 Excel"""
    wb = load_workbook(excel_path)

    with open(translations_json, "r") as f:
        data = json.load(f)

    translations = data.get("translations", [])
    count = 0

    for item in translations:
        sheet_name = item["sheet"]
        row = item["row"]
        col = item["col"]
        text = item["text"]

        if sheet_name not in wb.sheetnames:
            print(f"WARNING: Sheet '{sheet_name}' not found, skipping", file=sys.stderr)
            continue

        ws = wb[sheet_name]
        ws.cell(row=row, column=col).value = text
        count += 1

    wb.save(excel_path)
    print(f"OK: Updated {count} cells in {excel_path}")


def main():
    if len(sys.argv) < 3:
        print(f"Usage:")
        print(f"  {sys.argv[0]} extract <excel_path>")
        print(f"  {sys.argv[0]} apply <excel_path> <translations.json>")
        sys.exit(1)

    mode = sys.argv[1]
    excel_path = sys.argv[2]

    if mode == "extract":
        extract(excel_path)
    elif mode == "apply":
        if len(sys.argv) < 4:
            print("ERROR: apply mode requires translations JSON path", file=sys.stderr)
            sys.exit(1)
        apply_translations(excel_path, sys.argv[3])
    else:
        print(f"ERROR: Unknown mode '{mode}'. Use 'extract' or 'apply'.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
