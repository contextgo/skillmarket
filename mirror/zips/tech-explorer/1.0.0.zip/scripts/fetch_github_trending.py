#!/usr/bin/env python3
"""
Fetch GitHub Trending projects via OSS Insight API (TiDB)
This API provides real trending data based on comprehensive metrics (stars, forks, PRs, pushes)

Usage: python3 fetch_github_trending.py [language] [since] [limit]
since: daily / weekly / monthly (default: monthly)
language: python / javascript / go / etc. (default: all languages)
"""
import sys, json, requests

def fetch_trending(language="", since="monthly", limit=10):
    """
    Fetch trending repos from OSS Insight API
    
    Args:
        language: programming language filter (empty = all)
        since: daily / weekly / monthly
        limit: max number of repos to return
    
    Returns:
        list of trending repos with comprehensive metrics
    """
    # Map since to OSS Insight API period
    period_map = {
        "daily": "past_day",
        "weekly": "past_week", 
        "monthly": "past_month"
    }
    period = period_map.get(since, "past_month")
    
    # Build API URL
    url = "https://api.ossinsight.io/v1/trends/repos"
    params = {"period": period, "limit": min(limit * 2, 100)}  # Request more to filter
    
    if language:
        params["language"] = language.capitalize()
    
    headers = {"User-Agent": "tech-explorer/1.0"}
    
    try:
        response = requests.get(url, params=params, headers=headers, timeout=20)
        response.raise_for_status()
        
        data = response.json()
        rows = data.get("data", {}).get("rows", [])
        
        repos = []
        for row in rows[:limit]:
            repos.append({
                "name": row.get("repo_name", ""),
                "url": f"https://github.com/{row.get('repo_name', '')}",
                "description": row.get("description", ""),
                "language": row.get("primary_language", "Unknown"),
                "stars": int(row.get("stars", 0)),
                "forks": int(row.get("forks", 0)),
                "pull_requests": int(row.get("pull_requests", 0) or 0),
                "pushes": int(row.get("pushes", 0) or 0),
                "total_score": float(row.get("total_score", 0)),
                "period": since
            })
        
        return repos
        
    except Exception as e:
        print(f"Error fetching from OSS Insight API: {e}", file=sys.stderr)
        # Fallback to GitHub Search API
        return fetch_trending_fallback(language, since, limit)

def fetch_trending_fallback(language="", since="monthly", limit=10):
    """
    Fallback: Use GitHub Search API when OSS Insight is unavailable
    Note: This returns high-star active projects, not true trending data
    """
    from datetime import datetime, timedelta, timezone
    
    config = {
        "daily":   {"days": 1,  "min_stars": 100},
        "weekly":  {"days": 7,  "min_stars": 500},
        "monthly": {"days": 30, "min_stars": 1000},
    }
    cfg = config.get(since, config["monthly"])
    date_cutoff = (datetime.now(timezone.utc) - timedelta(days=cfg["days"])).strftime("%Y-%m-%d")
    
    query = f"pushed:>{date_cutoff} stars:>={cfg['min_stars']}"
    if language:
        query += f" language:{language}"

    params = {"q": query, "sort": "stars", "order": "desc", "per_page": limit}
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "tech-explorer/1.0"}

    try:
        r = requests.get("https://api.github.com/search/repositories", params=params, headers=headers, timeout=15)
        r.raise_for_status()
        repos = []
        for item in r.json().get("items", [])[:limit]:
            repos.append({
                "name": item["full_name"],
                "url": item["html_url"],
                "description": item.get("description") or "",
                "language": item.get("language") or "Unknown",
                "stars": item.get("stargazers_count", 0),
                "forks": item.get("forks_count", 0),
                "pull_requests": 0,  # Not available in Search API
                "pushes": 0,  # Not available in Search API
                "total_score": 0,  # Not available in Search API
                "period": since,
                "source": "github_search_fallback"
            })
        return repos
    except Exception as e:
        print(f"Fallback also failed: {e}", file=sys.stderr)
        return []

if __name__ == "__main__":
    language = sys.argv[1] if len(sys.argv) > 1 else ""
    since    = sys.argv[2] if len(sys.argv) > 2 else "monthly"
    limit    = int(sys.argv[3]) if len(sys.argv) > 3 else 10
    
    result = fetch_trending(language, since, limit)
    print(json.dumps(result, indent=2, ensure_ascii=False))
