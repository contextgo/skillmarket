#!/usr/bin/env python3
"""
Fetch real GitHub Trending Top N
直接抓取 github.com/trending 页面，解析真实 Trending 项目

Usage: python3 fetch_real_trending.py [since] [limit]
since: daily / weekly / monthly (default: monthly)
limit: max number of repos (default: 10)
"""
import sys, json, re, requests

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; tech-explorer/1.0)",
    "Accept": "text/html,application/xhtml+xml",
}


def fetch_trending_page(since="monthly", limit=10):
    """直接抓取 GitHub Trending 页面并解析"""
    url = f"https://github.com/trending?since={since}"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=20)
        resp.raise_for_status()
        html = resp.text
    except Exception as e:
        print(f"Error fetching GitHub trending page: {e}", file=sys.stderr)
        return []

    return parse_trending_html(html, limit)


def parse_trending_html(html, limit=10):
    """从 GitHub Trending HTML 中提取仓库信息"""
    repos = []

    # 按 <article 分割，每个 article 是一个仓库
    articles = re.split(r'<article', html)

    for article in articles[1:]:  # 跳过 header
        if len(repos) >= limit:
            break

        # 提取 owner/repo：<h2> 内的 <a href="/owner/repo">
        m = re.search(r'<h2[^>]*>.*?href="/([a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+)"', article, re.DOTALL)
        if not m:
            continue
        full_name = m.group(1)

        # 提取描述：<p class="col-9 color-fg-muted ...">
        desc = ""
        desc_m = re.search(r'<p\s+class="col-9[^"]*"[^>]*>\s*(.*?)\s*</p>', article, re.DOTALL)
        if desc_m:
            desc = re.sub(r'<[^>]+>', '', desc_m.group(1)).strip()

        # 提取语言
        lang = "Unknown"
        lang_m = re.search(r'itemprop="programmingLanguage">([^<]+)', article)
        if lang_m:
            lang = lang_m.group(1).strip()

        # 提取 stars：<a href="/owner/repo/stargazers" ...> 32,276</a>
        stars = 0
        stars_m = re.search(r'href="/[^"]+/stargazers"[^>]*>.*?([\d,]+)\s*</a>', article, re.DOTALL)
        if stars_m:
            stars = int(stars_m.group(1).strip().replace(",", ""))

        # 提取 forks：<a href="/owner/repo/forks" ...> 4,172</a>
        forks = 0
        forks_m = re.search(r'href="/[^"]+/forks"[^>]*>.*?([\d,]+)\s*</a>', article, re.DOTALL)
        if forks_m:
            forks = int(forks_m.group(1).strip().replace(",", ""))

        # 提取本月新增 stars
        monthly_stars = 0
        ms_m = re.search(r'([\d,]+)\s*stars?\s*this\s*(?:month|week|day)', article, re.IGNORECASE)
        if ms_m:
            monthly_stars = int(ms_m.group(1).replace(",", ""))

        repos.append({
            "name": full_name,
            "url": f"https://github.com/{full_name}",
            "description": desc,
            "language": lang,
            "stars": stars,
            "forks": forks,
            "monthly_stars": monthly_stars,
            "source": "github_trending_page"
        })

    return repos[:limit]


if __name__ == "__main__":
    since = sys.argv[1] if len(sys.argv) > 1 else "monthly"
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 10

    result = fetch_trending_page(since, limit)
    print(json.dumps(result, indent=2, ensure_ascii=False))
