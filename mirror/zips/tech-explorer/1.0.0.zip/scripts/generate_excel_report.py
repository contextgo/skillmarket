#!/usr/bin/env python3
"""
生成美化的 GitHub 技术趋势追踪 Excel 报告
用法: python3 generate_excel_report.py <real_trending_json> <oss_insight_json> <ai_top_json> <output_path> [hf_papers_json]

real_trending_json: fetch_real_trending.py 的输出 JSON 文件 (真实 GitHub Trending)
oss_insight_json:   fetch_github_trending.py 的输出 JSON 文件 (OSS Insight 综合评分)
ai_top_json:        fetch_top_starred.py 的输出 JSON 文件 (AI 领域 Top 20)
output_path:        输出 Excel 文件路径
hf_papers_json:     (可选) fetch_hf_papers.py 的输出 JSON 文件 (HF 热门论文)
"""
import sys
import json
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

# Style constants
HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
HEADER_FONT = Font(name="Microsoft YaHei", size=12, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="Microsoft YaHei", size=14, bold=True, color="1F4E79")
SUBTITLE_FONT = Font(name="Microsoft YaHei", size=9, color="7F8C8D")
DATA_FONT = Font(name="Microsoft YaHei", size=11)
SCORE_FONT = Font(name="Microsoft YaHei", size=11, bold=True, color="D35400")
LINK_FONT = Font(name="Microsoft YaHei", size=11, color="2E86C1", underline="single")
RANK_FONT = Font(name="Microsoft YaHei", size=11, bold=True)
ALT_FILL = PatternFill(start_color="D6EAF8", end_color="D6EAF8", fill_type="solid")
THIN_BORDER = Border(
    left=Side(style="thin", color="BDC3C7"),
    right=Side(style="thin", color="BDC3C7"),
    top=Side(style="thin", color="BDC3C7"),
    bottom=Side(style="thin", color="BDC3C7")
)
WRAP = Alignment(horizontal="left", vertical="center", wrap_text=True)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)


def build_real_trending_sheet(ws, data):
    """Sheet 1: 真实 GitHub Trending Top N（直接抓取 trending 页面）"""
    ws.title = "Trending Top 10"
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    month = datetime.now().strftime("%Y年%-m月")

    # Title
    ws.merge_cells("A1:F1")
    ws["A1"] = f"🔥 GitHub Trending Top {len(data)} — {month}"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # Subtitle
    ws.merge_cells("A2:F2")
    ws["A2"] = f"数据来源: github.com/trending?since=monthly | 生成时间: {now}"
    ws["A2"].font = SUBTITLE_FONT
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # Headers
    headers = ["#", "项目", "⭐ Stars", "📈 本月新增", "语言", "简介"]
    widths = [5, 35, 12, 14, 10, 55]
    for ci, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=3, column=ci, value=h)
        c.font = HEADER_FONT; c.fill = HEADER_FILL; c.alignment = CENTER; c.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[3].height = 28

    # Data rows
    for i, item in enumerate(data):
        row = 4 + i
        ws.row_dimensions[row].height = 36
        fill = ALT_FILL if i % 2 == 1 else None
        name = item.get("name", item.get("full_name", ""))
        url = item.get("url", item.get("html_url", f"https://github.com/{name}"))
        stars = item.get("stars", item.get("stargazers_count", 0))
        monthly = item.get("monthly_stars", 0)
        lang = item.get("language", "—") or "—"
        desc = item.get("description", "") or ""

        cells = [
            (1, i+1, RANK_FONT, CENTER),
            (2, name, LINK_FONT, WRAP),
            (3, f"{stars:,}", DATA_FONT, CENTER),
            (4, f"+{monthly:,}" if monthly else "—", SCORE_FONT, CENTER),
            (5, lang, DATA_FONT, CENTER),
            (6, desc, DATA_FONT, WRAP),
        ]
        for ci, val, font, align in cells:
            c = ws.cell(row=row, column=ci, value=val)
            c.font = font; c.alignment = align; c.border = THIN_BORDER
            if fill: c.fill = fill
        ws.cell(row=row, column=2).hyperlink = url


def build_oss_insight_sheet(ws, data):
    """Sheet 2: OSS Insight API 综合评分"""
    ws.title = "OSS Insight (综合评分)"
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    month = datetime.now().strftime("%Y年%-m月")

    # Title
    ws.merge_cells("A1:F1")
    ws["A1"] = f"📊 OSS Insight 综合评分 Top {len(data)} — {month}"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # Subtitle
    ws.merge_cells("A2:F2")
    ws["A2"] = f"数据来源: OSS Insight API (TiDB 综合评分) | 生成时间: {now}"
    ws["A2"].font = SUBTITLE_FONT
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # Headers
    headers = ["#", "项目", "⭐ Stars", "🔥 Score", "语言", "简介"]
    widths = [5, 35, 12, 14, 10, 50]
    for ci, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=3, column=ci, value=h)
        c.font = HEADER_FONT; c.fill = HEADER_FILL; c.alignment = CENTER; c.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[3].height = 28

    # Data rows
    for i, item in enumerate(data):
        row = 4 + i
        ws.row_dimensions[row].height = 36
        fill = ALT_FILL if i % 2 == 1 else None
        name = item.get("name", item.get("full_name", ""))
        url = item.get("url", item.get("html_url", f"https://github.com/{name}"))
        stars = item.get("stars", item.get("stargazers_count", 0))
        score = item.get("total_score", 0)
        lang = item.get("language", "—") or "—"
        desc = item.get("description", "") or ""

        cells = [
            (1, i+1, RANK_FONT, CENTER),
            (2, name, LINK_FONT, WRAP),
            (3, f"{stars:,}", DATA_FONT, CENTER),
            (4, f"{int(score):,}", SCORE_FONT, CENTER),
            (5, lang, DATA_FONT, CENTER),
            (6, desc, DATA_FONT, WRAP),
        ]
        for ci, val, font, align in cells:
            c = ws.cell(row=row, column=ci, value=val)
            c.font = font; c.alignment = align; c.border = THIN_BORDER
            if fill: c.fill = fill
        ws.cell(row=row, column=2).hyperlink = url


def build_ai_sheet(ws, data):
    """Sheet 2: AI Top N"""
    ws.title = "AI Top 20"
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    month = datetime.now().strftime("%Y年%-m月")

    ws.merge_cells("A1:E1")
    ws["A1"] = f"🏆 AI 领域顶级项目 Top {len(data)} — {month}"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    ws.merge_cells("A2:E2")
    ws["A2"] = f"数据来源: GitHub Search API (含活跃度过滤) | 生成时间: {now}"
    ws["A2"].font = SUBTITLE_FONT
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    headers = ["#", "项目", "⭐ Stars", "语言", "简介"]
    widths = [5, 40, 14, 14, 55]
    for ci, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=3, column=ci, value=h)
        c.font = HEADER_FONT; c.fill = HEADER_FILL; c.alignment = CENTER; c.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[3].height = 28

    for i, item in enumerate(data):
        row = 4 + i
        ws.row_dimensions[row].height = 34
        fill = ALT_FILL if i % 2 == 1 else None
        name = item.get("name", item.get("full_name", ""))
        url = item.get("url", item.get("html_url", f"https://github.com/{name}"))
        stars = item.get("stars", item.get("stargazers_count", 0))
        lang = item.get("language", "—") or "—"
        desc = item.get("description", "") or ""

        cells = [
            (1, i+1, RANK_FONT, CENTER),
            (2, name, LINK_FONT, WRAP),
            (3, f"{stars:,}", DATA_FONT, CENTER),
            (4, lang, DATA_FONT, CENTER),
            (5, desc, DATA_FONT, WRAP),
        ]
        for ci, val, font, align in cells:
            c = ws.cell(row=row, column=ci, value=val)
            c.font = font; c.alignment = align; c.border = THIN_BORDER
            if fill: c.fill = fill
        ws.cell(row=row, column=2).hyperlink = url


def build_hf_papers_sheet(ws, data):
    """Sheet 4: HF Papers Top N（Hugging Face 热门论文）"""
    ws.title = "HF Papers Top 10"
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Title
    ws.merge_cells("A1:F1")
    ws["A1"] = f"🤗 Hugging Face Papers Top {len(data)} — {datetime.now().strftime('%Y-%m-%d')}"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 36

    # Subtitle
    ws.merge_cells("A2:F2")
    ws["A2"] = f"数据来源: Hugging Face Daily Papers API | 生成时间: {now}"
    ws["A2"].font = SUBTITLE_FONT
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # Headers
    headers = ["#", "论文标题", "⬆ 点赞", "arXiv ID", "GitHub", "AI 摘要"]
    widths = [5, 45, 10, 16, 35, 55]
    for ci, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=3, column=ci, value=h)
        c.font = HEADER_FONT; c.fill = HEADER_FILL; c.alignment = CENTER; c.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[3].height = 28

    # Data rows
    for i, paper in enumerate(data):
        row = 4 + i
        ws.row_dimensions[row].height = 50
        fill = ALT_FILL if i % 2 == 1 else None

        title = paper.get("title", "")
        upvotes = paper.get("upvotes", 0)
        arxiv_id = paper.get("id", "")
        github_repo = paper.get("githubRepo") or ""
        ai_summary = paper.get("ai_summary", "") or ""

        # Repo display name
        repo_display = github_repo.replace("https://github.com/", "") if github_repo else "—"

        cells = [
            (1, i+1, RANK_FONT, CENTER),
            (2, title, DATA_FONT, WRAP),
            (3, upvotes, SCORE_FONT, CENTER),
            (4, arxiv_id, LINK_FONT, CENTER),
            (5, repo_display, LINK_FONT if github_repo else DATA_FONT, WRAP),
            (6, ai_summary, DATA_FONT, WRAP),
        ]
        for ci, val, font, align in cells:
            c = ws.cell(row=row, column=ci, value=val)
            c.font = font; c.alignment = align; c.border = THIN_BORDER
            if fill: c.fill = fill

        # Hyperlinks
        if arxiv_id:
            ws.cell(row=row, column=4).hyperlink = f"https://arxiv.org/abs/{arxiv_id}"
        if github_repo:
            ws.cell(row=row, column=5).hyperlink = github_repo

    # Freeze panes
    ws.freeze_panes = "A4"


def main():
    if len(sys.argv) < 5:
        print(f"Usage: {sys.argv[0]} <real_trending.json> <oss_insight.json> <ai_top.json> <output.xlsx> [hf_papers.json]")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        real_trending = json.load(f)
    with open(sys.argv[2]) as f:
        oss_insight = json.load(f)
    with open(sys.argv[3]) as f:
        ai_top = json.load(f)

    hf_papers = None
    if len(sys.argv) >= 6 and sys.argv[5]:
        with open(sys.argv[5]) as f:
            hf_data = json.load(f)
            hf_papers = hf_data.get("papers", hf_data) if isinstance(hf_data, dict) else hf_data

    wb = openpyxl.Workbook()
    build_real_trending_sheet(wb.active, real_trending)
    build_oss_insight_sheet(wb.create_sheet(), oss_insight)
    build_ai_sheet(wb.create_sheet(), ai_top)

    if hf_papers:
        build_hf_papers_sheet(wb.create_sheet(), hf_papers)
        print(f"Saved (4 sheets, incl. HF Papers): {sys.argv[4]}")
    else:
        print(f"Saved (3 sheets): {sys.argv[4]}")

    wb.save(sys.argv[4])



if __name__ == "__main__":
    main()
