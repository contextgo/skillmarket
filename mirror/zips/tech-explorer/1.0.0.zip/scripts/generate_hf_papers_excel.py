#!/usr/bin/env python3
"""
Generate HF Papers Top 10 Excel report
Usage: python3 generate_hf_papers_excel.py [output_path]
  output_path: Excel file path (default: /tmp/hf-papers-top10.xlsx)
"""

import sys
import json
import os
from datetime import datetime

# Ensure openpyxl is available
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip3 install openpyxl", file=sys.stderr)
    sys.exit(1)

def create_hf_papers_sheet(wb, papers, sheet_name="HF Papers Top 10"):
    """Create a styled sheet for HF Papers Top 10"""
    ws = wb.active if wb.active.title == "Sheet" else wb.create_sheet(sheet_name)
    ws.title = sheet_name

    # Style definitions
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    header_font = Font(name="微软雅黑", size=12, bold=True, color="FFFFFF")
    alt_fill = PatternFill(start_color="D6EAF8", end_color="D6EAF8", fill_type="solid")
    link_font = Font(name="微软雅黑", size=11, color="2E86C1", underline="single")
    score_font = Font(name="微软雅黑", size=11, bold=True, color="D35400")
    normal_font = Font(name="微软雅黑", size=11)
    title_font = Font(name="微软雅黑", size=14, bold=True, color="1F4E79")
    border = Border(
        left=Side(style="thin", color="BDC3C7"),
        right=Side(style="thin", color="BDC3C7"),
        top=Side(style="thin", color="BDC3C7"),
        bottom=Side(style="thin", color="BDC3C7")
    )
    wrap_align = Alignment(wrap_text=True, vertical="center")
    center_align = Alignment(horizontal="center", vertical="center")

    # Title row
    ws.merge_cells("A1:F1")
    title_cell = ws["A1"]
    title_cell.value = f"🤗 Hugging Face Papers Top 10 — {datetime.now().strftime('%Y-%m-%d')}"
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 36

    # Header row
    headers = ["#", "论文标题", "⬆ 点赞", "arXiv ID", "GitHub", "AI 摘要"]
    col_widths = [5, 45, 10, 16, 35, 55]

    for col_idx, (header, width) in enumerate(zip(headers, col_widths), 1):
        cell = ws.cell(row=2, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center_align
        cell.border = border
        ws.column_dimensions[get_column_letter(col_idx)].width = width
    ws.row_dimensions[2].height = 30

    # Data rows
    for i, paper in enumerate(papers, 1):
        row = i + 2
        is_alt = i % 2 == 0

        # # column
        cell = ws.cell(row=row, column=1, value=i)
        cell.font = normal_font
        cell.alignment = center_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        # Title column
        cell = ws.cell(row=row, column=2, value=paper.get("title", ""))
        cell.font = normal_font
        cell.alignment = wrap_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        # Upvotes column
        cell = ws.cell(row=row, column=3, value=paper.get("upvotes", 0))
        cell.font = score_font
        cell.alignment = center_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        # arXiv ID column (with hyperlink)
        arxiv_id = paper.get("id", "")
        cell = ws.cell(row=row, column=4, value=arxiv_id)
        if arxiv_id:
            cell.hyperlink = f"https://arxiv.org/abs/{arxiv_id}"
        cell.font = link_font
        cell.alignment = center_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        # GitHub column
        github = paper.get("githubRepo") or ""
        if github:
            # Extract repo name from URL
            repo_name = github.replace("https://github.com/", "")
            cell = ws.cell(row=row, column=5, value=repo_name)
            cell.hyperlink = github
            cell.font = link_font
        else:
            cell = ws.cell(row=row, column=5, value="—")
            cell.font = normal_font
        cell.alignment = wrap_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        # AI Summary column
        ai_summary = paper.get("ai_summary", "") or ""
        cell = ws.cell(row=row, column=6, value=ai_summary)
        cell.font = normal_font
        cell.alignment = wrap_align
        cell.border = border
        if is_alt:
            cell.fill = alt_fill

        ws.row_dimensions[row].height = 50

    # Freeze panes
    ws.freeze_panes = "A3"

    return ws


def main():
    output_path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/hf-papers-top10.xlsx"
    json_path = sys.argv[2] if len(sys.argv) > 2 else None

    # Read papers data from stdin or file
    if json_path:
        with open(json_path, "r") as f:
            data = json.load(f)
    else:
        data = json.load(sys.stdin)

    papers = data.get("papers", [])
    if not papers:
        print("ERROR: No papers data found", file=sys.stderr)
        sys.exit(1)

    # Create workbook
    wb = Workbook()
    create_hf_papers_sheet(wb, papers)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    wb.save(output_path)
    print(f"OK: Saved {len(papers)} papers to {output_path}")


if __name__ == "__main__":
    main()
