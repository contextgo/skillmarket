#!/usr/bin/env python3
"""
Fetch trending papers from Hugging Face Papers API
Usage: python3 fetch_hf_papers.py [limit] [sort]
  limit: number of papers to fetch (default: 10, max: 100)
  sort: 'upvotes' or 'date' (default: upvotes)
"""

import sys
import json
import urllib.request
import urllib.error
from datetime import datetime

def fetch_hf_papers(limit=10, sort='upvotes', timeout=15, proxy=None):
    """
    Fetch trending papers from Hugging Face Papers API
    
    Args:
        limit: number of papers to return (default 10, max 100)
        sort: 'upvotes' or 'date' (default 'upvotes')
        timeout: request timeout in seconds
        proxy: optional proxy URL (e.g., 'http://proxy.example.com:8080')
    
    Returns:
        list of paper dicts with keys: id, title, summary, upvotes, authors, 
        publishedAt, githubRepo, projectPage, ai_summary
    """
    # Use HF mirror for China network accessibility
    url = f"https://hf-mirror.com/api/daily_papers?limit={limit}"
    
    # Setup proxy if provided
    if proxy:
        proxy_handler = urllib.request.ProxyHandler({'http': proxy, 'https': proxy})
        opener = urllib.request.build_opener(proxy_handler)
        urllib.request.install_opener(opener)
    
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (compatible; OpenClaw/1.0)')
        
        with urllib.request.urlopen(req, timeout=timeout) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        papers = []
        for item in data[:limit]:
            paper_data = item.get('paper', {})
            
            # Extract authors
            authors = []
            for author in paper_data.get('authors', []):
                if isinstance(author, dict):
                    authors.append(author.get('name', ''))
                else:
                    authors.append(str(author))
            
            paper = {
                'id': paper_data.get('id', ''),
                'title': paper_data.get('title', ''),
                'summary': paper_data.get('summary', ''),
                'upvotes': item.get('numUpvotes', paper_data.get('upvotes', 0)),
                'authors': authors,
                'publishedAt': paper_data.get('publishedAt', ''),
                'githubRepo': item.get('githubRepo') or paper_data.get('githubRepo'),
                'projectPage': item.get('projectPage') or paper_data.get('projectPage'),
                'ai_summary': item.get('ai_summary') or paper_data.get('ai_summary', '')
            }
            papers.append(paper)
        
        # Sort if requested
        if sort == 'upvotes':
            papers.sort(key=lambda x: x['upvotes'], reverse=True)
        elif sort == 'date':
            papers.sort(key=lambda x: x['publishedAt'], reverse=True)
        
        return papers
    
    except urllib.error.URLError as e:
        print(f"ERROR: Failed to connect to Hugging Face API: {e}", file=sys.stderr)
        print("HINT: Check network connectivity or configure a proxy", file=sys.stderr)
        return None
    except urllib.error.HTTPError as e:
        print(f"ERROR: HTTP {e.code} - {e.reason}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"ERROR: Failed to parse JSON response: {e}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"ERROR: Unexpected error: {e}", file=sys.stderr)
        return None

def main():
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    sort = sys.argv[2] if len(sys.argv) > 2 else 'upvotes'
    proxy = sys.argv[3] if len(sys.argv) > 3 else None
    
    # Validate inputs
    if limit < 1 or limit > 100:
        print("ERROR: limit must be between 1 and 100", file=sys.stderr)
        sys.exit(1)
    
    if sort not in ['upvotes', 'date']:
        print("ERROR: sort must be 'upvotes' or 'date'", file=sys.stderr)
        sys.exit(1)
    
    papers = fetch_hf_papers(limit=limit, sort=sort, proxy=proxy)
    
    if papers is None:
        sys.exit(1)
    
    # Output JSON
    result = {
        'papers': papers,
        'count': len(papers),
        'fetched_at': datetime.now().isoformat(),
        'sort': sort
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
