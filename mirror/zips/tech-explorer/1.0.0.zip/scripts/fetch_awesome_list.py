#!/usr/bin/env python3
"""
Search for Awesome lists on GitHub by keyword/category.
Strategy:
  1. Try sindresorhus/awesome-{keyword} first (official curated lists)
  2. Fallback: search GitHub for "awesome-{keyword}" repos
  3. Fetch the repo's README and extract curated project entries

Usage: python3 fetch_awesome_list.py <keyword> [limit]
Example: python3 fetch_awesome_list.py pdf 20
"""
import sys, json, re, requests

HEADERS = {"Accept": "application/vnd.github+json", "User-Agent": "tech-explorer/1.0"}
RAW_HEADERS = {"Accept": "application/vnd.github.raw", "User-Agent": "tech-explorer/1.0"}

CURATED_KEYWORDS = {"curated", "list", "awesome", "collection", "resources", "libraries"}

# Well-known awesome list maintainers (sindresorhus is the original creator)
KNOWN_OWNERS = ["sindresorhus", "vinta", "avelino", "ziadoz", "sorrycc"]

def try_known_repos(keyword):
    """
    Try well-known awesome list repos directly (no search API call needed).
    Returns repo info dict if found, None otherwise.
    """
    for owner in KNOWN_OWNERS:
        repo_name = f"{owner}/awesome-{keyword}"
        url = f"https://api.github.com/repos/{repo_name}"
        try:
            r = requests.get(url, headers=HEADERS, timeout=10)
            if r.status_code == 200:
                item = r.json()
                return {
                    "name": item["full_name"],
                    "url": item["html_url"],
                    "description": item.get("description") or "",
                    "stars": item.get("stargazers_count", 0),
                    "is_curated": True,
                    "source": "direct_match"
                }
        except:
            continue
    
    # Also try sindresorhus/awesome (the master list) for generic queries
    if keyword.lower() in ("all", "master", "list", "everything"):
        try:
            r = requests.get("https://api.github.com/repos/sindresorhus/awesome", headers=HEADERS, timeout=10)
            if r.status_code == 200:
                item = r.json()
                return {
                    "name": item["full_name"],
                    "url": item["html_url"],
                    "description": item.get("description") or "",
                    "stars": item.get("stargazers_count", 0),
                    "is_curated": True,
                    "source": "direct_match"
                }
        except:
            pass
    
    return None

def find_awesome_repo(keyword, max_candidates=10):
    """Search GitHub for awesome-{keyword} repos, prefer genuine curated lists."""
    query = f"awesome-{keyword} in:name"
    params = {"q": query, "sort": "stars", "order": "desc", "per_page": max_candidates}
    try:
        r = requests.get("https://api.github.com/search/repositories", params=params, headers=HEADERS, timeout=15)
        r.raise_for_status()
        results = []
        for item in r.json().get("items", []):
            desc = (item.get("description") or "").lower()
            is_curated = (
                any(kw in desc for kw in CURATED_KEYWORDS)
                or "awesome-list" in (item.get("topics") or [])
            )
            results.append({
                "name": item["full_name"],
                "url": item["html_url"],
                "description": item.get("description") or "",
                "stars": item.get("stargazers_count", 0),
                "is_curated": is_curated,
            })
        # Sort: curated lists first, then by stars
        results.sort(key=lambda x: (not x["is_curated"], -x["stars"]))
        return results
    except Exception as e:
        print(f"Error searching awesome repos: {e}", file=sys.stderr)
        return []

def fetch_readme(full_name):
    """Fetch the README content for a repo."""
    url = f"https://api.github.com/repos/{full_name}/readme"
    try:
        r = requests.get(url, headers=RAW_HEADERS, timeout=15)
        r.raise_for_status()
        return r.text
    except Exception as e:
        print(f"Error fetching README for {full_name}: {e}", file=sys.stderr)
        return ""

def parse_readme_entries(readme_text, limit=30):
    """Extract project entries from an Awesome list README."""
    entries = []
    pattern = re.compile(
        r'[-*]\s+\[([^\]]+)\]\((https?://[^\)]+)\)\s*[-–—:]*\s*(.*)',
        re.IGNORECASE
    )
    skip_urls = {'badge', 'contributing', 'license', 'awesome.re', '#contents', '#table-of-contents'}
    
    for line in readme_text.split('\n'):
        m = pattern.match(line.strip())
        if m:
            name, url, desc = m.group(1), m.group(2), m.group(3).strip()
            if any(skip in url.lower() for skip in skip_urls):
                continue
            entries.append({"name": name, "url": url, "description": desc})
            if len(entries) >= limit:
                break
    return entries

def main(keyword, limit=20):
    # Step 1: Try known repos first (fast path, no search API needed)
    direct_match = try_known_repos(keyword)
    
    if direct_match:
        readme = fetch_readme(direct_match["name"])
        if readme:
            entries = parse_readme_entries(readme, limit)
            if entries:
                return {
                    "keyword": keyword,
                    "source_repo": direct_match,
                    "candidate_repos": [],
                    "entries": entries,
                    "total_parsed": len(entries),
                    "match_type": "direct"
                }
    
    # Step 2: Search GitHub for awesome repos
    repos = find_awesome_repo(keyword)
    if not repos:
        return {"repos": [], "entries": [], "keyword": keyword, "match_type": "none"}

    # Step 3: Try repos in priority order until we get entries
    entries = []
    source = None
    for repo in repos:
        readme = fetch_readme(repo["name"])
        if readme:
            entries = parse_readme_entries(readme, limit)
            if entries:
                source = repo
                break
    
    if not source:
        source = repos[0] if repos else None

    return {
        "keyword": keyword,
        "source_repo": source,
        "candidate_repos": [r for r in repos if source and r["name"] != source["name"]][:4],
        "entries": entries,
        "total_parsed": len(entries),
        "match_type": "search"
    }

if __name__ == "__main__":
    keyword = sys.argv[1] if len(sys.argv) > 1 else "python"
    limit   = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    result  = main(keyword, limit)
    print(json.dumps(result, indent=2, ensure_ascii=False))
