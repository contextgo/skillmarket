#!/usr/bin/env python3
"""
Fetch top-starred GitHub repos filtered by topic, with activity filtering.
Filters out zombie projects (no recent pushes, low fork ratio).

Usage: python3 fetch_top_starred.py [topic] [limit]
Default: topic=ai, limit=20
"""
import sys, json, requests
from datetime import datetime, timedelta, timezone

def fetch_top_starred(topic="ai", limit=20):
    """
    Fetch top-starred repos by topic with activity filtering.
    
    Filters:
    - Must have been pushed within the last 180 days (6 months)
    - Must have at least 10 forks (filters out vanity/abandoned repos)
    - Sorted by stars descending
    
    Args:
        topic: GitHub topic tag (ai, machine-learning, llm, etc.)
        limit: max number of repos to return
    
    Returns:
        list of active top-starred repos
    """
    # Calculate 6-month cutoff for activity filter
    cutoff_date = (datetime.now(timezone.utc) - timedelta(days=180)).strftime("%Y-%m-%d")
    
    # Query: topic + pushed recently + minimum forks
    query = f"topic:{topic} pushed:>{cutoff_date} forks:>=10"
    
    # Request more than needed to account for filtering
    per_page = min(limit * 2, 100)
    params = {"q": query, "sort": "stars", "order": "desc", "per_page": per_page}
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "tech-explorer/1.0"}

    try:
        r = requests.get("https://api.github.com/search/repositories", params=params, headers=headers, timeout=15)
        r.raise_for_status()
        
        repos = []
        for item in r.json().get("items", []):
            if len(repos) >= limit:
                break
            
            stars = item.get("stargazers_count", 0)
            forks = item.get("forks_count", 0)
            
            # Additional quality checks
            # Skip repos with extremely low fork-to-star ratio (< 0.5%)
            # This filters out repos that got stars from hype but no real usage
            if stars > 1000 and forks > 0:
                fork_ratio = forks / stars
                if fork_ratio < 0.005:
                    continue
            
            # Skip archived repos
            if item.get("archived", False):
                continue
            
            repos.append({
                "name": item["full_name"],
                "url": item["html_url"],
                "description": item.get("description") or "",
                "language": item.get("language") or "Unknown",
                "stars": stars,
                "forks": forks,
                "topics": item.get("topics", [])[:5],
                "created_at": item.get("created_at", ""),
                "updated_at": item.get("updated_at", ""),
                "license": (item.get("license") or {}).get("spdx_id", "N/A"),
                "archived": item.get("archived", False),
                "open_issues": item.get("open_issues_count", 0)
            })
        
        return repos
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return []

if __name__ == "__main__":
    topic = sys.argv[1] if len(sys.argv) > 1 else "ai"
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    print(json.dumps(fetch_top_starred(topic, limit), indent=2, ensure_ascii=False))
