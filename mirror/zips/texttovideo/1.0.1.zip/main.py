from prompt_optimizer import optimize_prompt
from video_generator import generate_video

def run(user_input: str) -> dict:
    """
    OpenClaw 技能主入口
    """
    try:
        # Step 1: 优化提示词
        print(f"📝 收到请求：{user_input}")
        optimized = optimize_prompt(user_input)
        print(f"✨ 优化提示词：{optimized}")

        # Step 2: 生成视频
        print("🎬 视频生成中，约需 1~2 分钟...")
        video_url = generate_video(optimized)

        return {
            "success": True,
            "message": f"🎬 视频生成成功！\n\n📎 视频链接：{video_url}\n\n✨ 使用的提示词：\n{optimized}",
            "video_url": video_url,
            "optimized_prompt": optimized,
            "original_input": user_input
        }

    except TimeoutError:
        return {
            "success": False,
            "message": "⏰ 视频生成超时，请稍后重试"
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"❌ 生成失败：{str(e)}"
        }