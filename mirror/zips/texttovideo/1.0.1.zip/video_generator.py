# video_generator.py 即梦官方API适配版（直接替换旧文件）
import os
import time
import json
import requests
import hashlib
import hmac
from datetime import datetime, timezone

class JimengVideoGenerator:
    def __init__(self):
        # 从环境变量读取IAM密钥（你已经生成的那对！）
        self.access_key = os.getenv("VOLC_ACCESS_KEY_ID")
        self.secret_key = os.getenv("VOLC_SECRET_ACCESS_KEY")
        self.service = "cv"
        self.region = "cn-north-1"
        self.host = f"visual.{self.region}.volcengineapi.com"
        self.version = "2022-08-31"
        self.action = "SubmitVideoGenerationTask"

    def _sign(self, method, uri, query, body):
        """火山引擎API签名算法（官方标准，直接用）"""
        # 1. 构造规范请求
        content_sha256 = hashlib.sha256(body.encode("utf-8")).hexdigest()
        canonical_request = f"{method}\n{uri}\n{query}\nhost:{self.host}\n\ncontent-sha256:{content_sha256}\n\ncontent-sha256\n{content_sha256}"
        
        # 2. 构造待签名字符串
        now = datetime.now(timezone.utc)
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")
        credential_scope = f"{date_stamp}/{self.region}/{self.service}/request"
        string_to_sign = f"AWS4-HMAC-SHA256\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
        
        # 3. 计算签名
        signing_key = hmac.new(f"AWS4{self.secret_key}".encode(), date_stamp.encode(), hashlib.sha256).digest()
        signing_key = hmac.new(signing_key, self.region.encode(), hashlib.sha256).digest()
        signing_key = hmac.new(signing_key, self.service.encode(), hashlib.sha256).digest()
        signing_key = hmac.new(signing_key, b"request", hashlib.sha256).digest()
        signature = hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).hexdigest()
        
        # 4. 构造Authorization头
        auth_header = (
            f"AWS4-HMAC-SHA256 Credential={self.access_key}/{credential_scope}, "
            f"SignedHeaders=content-sha256;host, Signature={signature}"
        )
        return auth_header, amz_date, content_sha256

    def generate_video(self, prompt, duration=5, ratio="16:9"):
        """
        调用即梦3.0生成视频（适配720P/1080P/Pro版）
        :param prompt: 豆包优化好的提示词
        :param duration: 视频时长（秒，5/10）
        :param ratio: 画面比例（16:9/9:16/1:1）
        """
        try:
            # 1. 构造请求体（即梦3.0标准参数）
            uri = "/"
            query = f"Action={self.action}&Version={self.version}"
            body = json.dumps({
                "Prompt": prompt,
                "Duration": duration,
                "Ratio": ratio,
                "Resolution": "720p"  # 测试用720p，正式用"1080p"
            }, ensure_ascii=False)

            # 2. 签名
            auth_header, amz_date, content_sha256 = self._sign("POST", uri, query, body)

            # 3. 发送请求
            headers = {
                "Authorization": auth_header,
                "X-Amz-Date": amz_date,
                "Content-Type": "application/json",
                "Content-SHA256": content_sha256,
                "Host": self.host
            }

            # 提交生成任务
            task_resp = requests.post(
                f"https://{self.host}{uri}?{query}",
                headers=headers,
                data=body.encode("utf-8"),
                timeout=30
            )
            task_resp.raise_for_status()
            task_data = task_resp.json()
            task_id = task_data["Result"]["TaskId"]
            print(f"任务提交成功，任务ID：{task_id}")

            # 4. 轮询任务结果（异步处理，避免超时）
            for _ in range(40):  # 最多等待200秒
                time.sleep(5)
                # 调用查询任务API
                query_action = "GetVideoGenerationTask"
                query_uri = "/"
                query_str = f"Action={query_action}&Version={self.version}&TaskId={task_id}"
                query_body = ""
                query_auth, query_date, query_sha = self._sign("GET", query_uri, query_str, query_body)

                query_resp = requests.get(
                    f"https://{self.host}{query_uri}?{query_str}",
                    headers={
                        "Authorization": query_auth,
                        "X-Amz-Date": query_date,
                        "Content-SHA256": query_sha,
                        "Host": self.host
                    },
                    timeout=30
                )
                query_resp.raise_for_status()
                query_data = query_resp.json()
                status = query_data["Result"]["Status"]

                if status == "success":
                    video_url = query_data["Result"]["VideoUrl"]
                    return {"success": True, "video_url": video_url, "task_id": task_id}
                elif status == "failed":
                    return {"success": False, "error": "视频生成失败", "task_id": task_id}

            return {"success": False, "error": "生成超时", "task_id": task_id}

        except Exception as e:
            return {"success": False, "error": str(e)}

# 测试运行
if __name__ == "__main__":
    generator = JimengVideoGenerator()
    # 用豆包优化好的提示词测试
    res = generator.generate_video("A girl walking on the beach at sunset, 4K, cinematic, smooth motion")
    print(json.dumps(res, ensure_ascii=False, indent=2))