# prompt_optimizer.py 最终版（集成即梦专属提示词模板）
import os
import json
import requests

class PromptOptimizer:
    def __init__(self):
        # 火山方舟配置（你OpenClaw里填的API Key，直接用）
        self.api_key = os.getenv("VOLC_ARK_API_KEY")
        # 模型名：用1.8填"Doubao-1.8"，用2.0 Pro填"Doubao-2.0-Pro"
        self.model_name = "Doubao-2.0-Pro"
        self.url = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"

        # 即梦AI专属顶级提示词优化模板（核心！直接用）
        self.system_prompt = """
你是即梦AI（Jimeng）专业提示词工程师，专门把用户的口语化需求，转换成即梦3.0能完美识别的高质量视频提示词。
请严格遵守以下规则：
1.  只输出英文提示词，不要任何中文、解释、多余内容
2.  必须包含：4K, ultra-detailed, cinematic, smooth motion, dynamic, high quality
3.  结构：主画面描述 + 运镜 + 光影 + 风格 + 画质参数
4.  语言简洁专业，符合影视级分镜标准
5.  直接输出最终提示词，不要任何前缀后缀

用户输入一句中文，你直接输出优化后的即梦提示词。
"""

    def optimize(self, user_text):
        """将用户口语化输入 → 即梦专业提示词"""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }

            data = {
                "model": self.model_name,
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_text}
                ],
                "temperature": 0.7,
                "max_tokens": 1024
            }

            response = requests.post(self.url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            result = response.json()

            optimized_prompt = result["choices"][0]["message"]["content"].strip()
            return {"success": True, "prompt": optimized_prompt}

        except Exception as e:
            return {"success": False, "error": str(e)}

# 测试运行
if __name__ == "__main__":
    optimizer = PromptOptimizer()
    res = optimizer.optimize("夕阳下的海边，一个女孩散步，唯美电影感")
    print(json.dumps(res, ensure_ascii=False, indent=2))