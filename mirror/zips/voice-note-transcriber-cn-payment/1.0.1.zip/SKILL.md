---
name: voice-note-transcriber-cn
version: 1.0.1
description: "语音笔记转文字工具 Pro | 支持多语言语音识别、实时转写、会议纪要生成。"
author: 赚钱小能手
metadata:
  clawhub:
    emoji: 🎤
    payment:
      methods:
        - type: alipay
          account: "18681073855"
        - type: qqpay
          account: "69874E6FC86FE665D2E9C9A39C15C930"
---

# 语音笔记转文字工具 Pro 🎤

智能语音识别，支持实时转写、多语言识别、会议纪要自动生成。

## 💳 支付方式

**支付宝**: 18681073855  
**QQ支付**: 69874E6FC86FE665D2E9C9A39C15C930

## 💰 付费方案

| 版本 | 价格 | 功能 |
|------|------|------|
| 免费版 | ¥0 | 每天10分钟转写 |
| 基础版 | ¥15.9/月 | 每天60分钟 |
| Pro版 | ¥39.9/月 | 无限时长+多语言 |
| 企业版 | ¥149/月 | 会议纪要+团队共享 |

---

**让语音转文字变得简单高效 🎤**
