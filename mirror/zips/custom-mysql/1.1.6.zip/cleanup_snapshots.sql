-- cleanup_snapshots.sql
-- Retention policy for agent_config_files snapshots
-- Keeps only the last 30 days of snapshots per user

-- Add a retention_days column if it doesn't exist (for future flexibility)
ALTER TABLE IF EXISTS agent_config_files
    ADD COLUMN IF NOT EXISTS retention_days INT NOT NULL DEFAULT 30;

-- Create an event that purges old snapshots daily (if EVENT privileges exist)
-- Safe to run even if EVENT scheduler is off; just creates the event
DELIMITER //
CREATE EVENT IF NOT EXISTS purge_old_snapshots
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DELETE FROM agent_config_files
    WHERE snapshot_timestamp < NOW() - INTERVAL retention_days DAY;
END //
DELIMITER ;

-- Also create a manual purge stored procedure for environments without EVENT privilege
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_purge_snapshots(IN days_back INT)
BEGIN
    IF days_back IS NULL OR days_back < 1 THEN
        SET days_back = 30;
    END IF;
    DELETE FROM agent_config_files
    WHERE snapshot_timestamp < NOW() - INTERVAL days_back DAY;
    SELECT ROW_COUNT() AS rows_deleted;
END //
DELIMITER ;

-- Create a table of allowed snapshot paths (whitelist approach)
CREATE TABLE IF NOT EXISTS allowed_snapshot_paths (
    path_id INT AUTO_INCREMENT PRIMARY KEY,
    path_pattern VARCHAR(512) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pre-populate with safe default paths
INSERT IGNORE INTO allowed_snapshot_paths (path_pattern, description) VALUES
    ('/home/*/.openclaw/workspace/SOUL.md', 'Agent soul file'),
    ('/home/*/.openclaw/workspace/USER.md', 'User profile'),
    ('/home/*/.openclaw/workspace/IDENTITY.md', 'Agent identity'),
    ('/home/*/.openclaw/workspace/TOOLS.md', 'Agent tools config'),
    ('/home/*/.openclaw/workspace/MEMORY.md', 'Agent memory');
