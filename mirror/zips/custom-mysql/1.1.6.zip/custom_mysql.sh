#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# custom_mysql — Agent-facing MySQL command wrapper for MySQLClaw
#
# Usage:
#   custom_mysql query "SQL"                Execute a read-only SELECT query
#   custom_mysql exec --file X              Execute a reviewed SQL script
#   custom_mysql insert_interaction ...     Log a user interaction
#   custom_mysql insert_note ...            Add a user note
#   custom_mysql insert_context ...         Set user context
#   custom_mysql insert_skill_usage ...     Log skill usage
#   custom_mysql insert_relationship ...    Add a user relationship
#   custom_mysql help                       Show this help
#
# All commands route through sql_safe_exec.sh which enforces:
#   - Single-statement only (semicolons rejected)
#   - DDL blocked (DROP, TRUNCATE, CREATE)
#   - ALTER allowed for mysqlclaw migrations
#   - DML requires interactive confirmation (no --yes bypass)
#   - query command is SELECT-only
#   - Table allowlist enforced for all write operations
#   - Path traversal blocked
#   - Credentials via temporary --defaults-extra-file
#   - .env file support
# ------------------------------------------------------------------

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SAFE_EXEC="$SCRIPT_DIR/sql_safe_exec.sh"

# Load .env if present
if [ -f "$SCRIPT_DIR/.env" ]; then
    set -a
    source "$SCRIPT_DIR/.env"
    set +a
fi

CMD="${1:-help}"
shift || true

case "$CMD" in
    query)
        SQL="${1:-}"
        if [ -z "$SQL" ]; then
            echo "ERROR: No SQL provided. Usage: custom_mysql query \"SQL\"" >&2
            exit 1
        fi
        # enforce SELECT-only on the query command
        if ! echo "$SQL" | grep -qiE "^\\s*SELECT\\b"; then
            echo "ERROR: 'query' command only accepts SELECT statements. Use exec for DML." >&2
            exit 1
        fi
        "$SAFE_EXEC" --readonly "$SQL"
        ;;

    exec)
        FILE=""
        while [[ $# -gt 0 ]]; do
            case "$1" in
                --file) FILE="$2"; shift 2 ;;
                *) shift ;;
            esac
        done
        if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
            echo "ERROR: --file <path> required." >&2
            exit 1
        fi
        ERRORS=0
        while IFS= read -r line || [[ -n "$line" ]]; do
            [[ -z "${line// /}" ]] && continue
            [[ "$line" =~ ^-- ]] && continue
            [[ "$line" =~ ^# ]] && continue
            echo "Executing: $line"
            if ! "$SAFE_EXEC" "$line"; then
                echo "ERROR: Statement failed: $line" >&2
                ERRORS=$((ERRORS + 1))
            fi
        done < "$FILE"
        if [ "$ERRORS" -gt 0 ]; then
            echo "WARNING: $ERRORS statement(s) failed." >&2
            exit 1
        fi
        echo "Script execution complete." ;;

    insert_interaction)
        # Usage: custom_mysql insert_interaction <user_id> <direction> <topic> <summary> [sentiment]
        USER_ID="${1:-}"; DIRECTION="${2:-}"; TOPIC="${3:-}"; SUMMARY="${4:-}"; SENTIMENT="${5:-neutral}"
        if [ -z "$USER_ID" ] || [ -z "$DIRECTION" ] || [ -z "$TOPIC" ]; then
            echo "ERROR: Usage: custom_mysql insert_interaction <user_id> <direction> <topic> <summary> [sentiment]" >&2
            exit 1
        fi
        # escape single quotes to prevent injection
        escaped_user_id=$(printf \'%s\' "$USER_ID" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_direction=$(printf \'%s\' "$DIRECTION" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_topic=$(printf \'%s\' "$TOPIC" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_summary=$(printf \'%s\' "$SUMMARY" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_sentiment=$(printf \'%s\' "$SENTIMENT" | sed "s/\'/\\\\\\\\\'\'/g")
        "$SAFE_EXEC" "INSERT INTO user_interactions (user_id, channel, direction, topic, summary, sentiment) VALUES ('${escaped_user_id}', 'discord', '${escaped_direction}', '${escaped_topic}', '${escaped_summary}', '${escaped_sentiment}');"
        ;;

    insert_note)
        # Usage: custom_mysql insert_note <user_id> <note> [category]
        USER_ID="${1:-}"; NOTE="${2:-}"; CATEGORY="${3:-general}"
        if [ -z "$USER_ID" ] || [ -z "$NOTE" ]; then
            echo "ERROR: Usage: custom_mysql insert_note <user_id> <note> [category]" >&2
            exit 1
        fi
        escaped_user_id=$(printf '%s' "$USER_ID" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_note=$(printf '%s' "$NOTE" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_category=$(printf '%s' "$CATEGORY" | sed "s/\'/\\\\\\\\\'\'/g")
        "$SAFE_EXEC" "INSERT INTO user_notes (user_id, note, category) VALUES ('${escaped_user_id}', '${escaped_note}', '${escaped_category}');"
        ;;

    insert_context)
        # Usage: custom_mysql insert_context <user_id> <key> <value> [expires_at]
        USER_ID="${1:-}"; KEY="***"; VALUE="${3:-}"; EXPIRES="${4:-}"
        if [ -z "$USER_ID" ] || [ -z "$KEY" ]; then
            echo "ERROR: Usage: custom_mysql insert_context <user_id> <key> <value> [expires_at]" >&2
            exit 1
        fi
        escaped_user_id=$(printf '%s' "$USER_ID" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_key=$(printf '%s' "$KEY" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_value=$(printf '%s' "$VALUE" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_expires=$(printf '%s' "$EXPIRES" | sed "s/\'/\\\\\\\\\'\'/g")
        if [ -n "$EXPIRES" ]; then
            "$SAFE_EXEC" "INSERT INTO user_context (user_id, context_key, context_value, expires_at) VALUES ('${escaped_user_id}', '${escaped_key}', '${escaped_value}', '${escaped_expires}') ON DUPLICATE KEY UPDATE context_value='${escaped_value}', expires_at='${escaped_expires}';"
        else
            "$SAFE_EXEC" "INSERT INTO user_context (user_id, context_key, context_value) VALUES ('${escaped_user_id}', '${escaped_key}', '${escaped_value}') ON DUPLICATE KEY UPDATE context_value='${escaped_value}';"
        fi
        ;;

    insert_skill_usage)
        # Usage: custom_mysql insert_skill_usage <user_id> <skill_name> [action] [status] [duration_ms]
        USER_ID="${1:-}"; SKILL="${2:-}"; ACTION="${3:-}"; STATUS="${4:-success}"; DURATION="${5:-}"
        if [ -z "$USER_ID" ] || [ -z "$SKILL" ]; then
            echo "ERROR: Usage: custom_mysql insert_skill_usage <user_id> <skill_name> [action] [status] [duration_ms]" >&2
            exit 1
        fi
        escaped_user_id=$(printf '%s' "$USER_ID" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_skill=$(printf '%s' "$SKILL" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_action=$(printf '%s' "$ACTION" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_status=$(printf '%s' "$STATUS" | sed "s/\'/\\\\\\\\\'\'/g")
        # Ensure duration is numeric to prevent injection
        if [[ -n "$DURATION" && "$DURATION" =~ ^[0-9]+$ ]]; then
            "$SAFE_EXEC" "INSERT INTO skill_usage (user_id, skill_name, action, status, duration_ms) VALUES ('${escaped_user_id}', '${escaped_skill}', '${escaped_action}', '${escaped_status}', $DURATION);"
        else
            "$SAFE_EXEC" "INSERT INTO skill_usage (user_id, skill_name, action, status) VALUES ('${escaped_user_id}', '${escaped_skill}', '${escaped_action}', '${escaped_status}');"
        fi
        ;;

    insert_relationship)
        # Usage: custom_mysql insert_relationship <user_id> <related_user_id> <type> [strength] [notes]
        USER_ID="${1:-}"; RELATED="${2:-}"; TYPE="${3:-acquaintance}"; STRENGTH="${4:-5}"; NOTES="${5:-}"
        if [ -z "$USER_ID" ] || [ -z "$RELATED" ]; then
            echo "ERROR: Usage: custom_mysql insert_relationship <user_id> <related_user_id> <type> [strength] [notes]" >&2
            exit 1
        fi
        escaped_user_id=$(printf '%s' "$USER_ID" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_related=$(printf '%s' "$RELATED" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_type=$(printf '%s' "$TYPE" | sed "s/\'/\\\\\\\\\'\'/g")
        escaped_notes=$(printf '%s' "$NOTES" | sed "s/\'/\\\\\\\\\'\'/g")
        # Ensure strength is numeric
        if [[ "$STRENGTH" =~ ^[0-9]+$ ]]; then
            "$SAFE_EXEC" "INSERT INTO user_relationships (user_id, related_user_id, relationship_type, strength, notes) VALUES ('${escaped_user_id}', '${escaped_related}', '${escaped_type}', $STRENGTH, '${escaped_notes}') ON DUPLICATE KEY UPDATE relationship_type='${escaped_type}', strength=$STRENGTH, notes='${escaped_notes}';"
        else
            echo "ERROR: strength must be numeric" >&2
            exit 1
        fi
        ;;

    help|*)
        echo "MySQLClaw — custom_mysql command wrapper (v1.1.5)"
        echo ""
        echo "Usage:"
        echo "  custom_mysql query \\"SQL\\" Execute a query"
        echo "  custom_mysql exec --file path.sql Execute a SQL script"
        echo "  custom_mysql insert_interaction <uid> <dir> <topic> <sum> Log interaction"
        echo "  custom_mysql insert_note <uid> <note> [category] Add user note"
        echo "  custom_mysql insert_context <uid> <key> <val> [expires] Set user context"
        echo "  custom_mysql insert_skill_usage <uid> <skill> [action] [st] Log skill usage"
        echo "  custom_mysql insert_relationship <uid> <ruid> <type> [str] Add relationship"
        echo "  custom_mysql help Show this help"
        echo ""
        echo "Credentials: set MYSQL_USER/MYSQL_PASSWORD env vars or .env file."
        ;;
esac