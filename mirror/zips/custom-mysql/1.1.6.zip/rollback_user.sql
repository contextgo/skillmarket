-- SQL script to rollback a user's setup, resetting their data
-- This script expects the :user_id placeholder to be replaced before execution

-- Delete related data (order matters for foreign key constraints)
DELETE FROM user_personas WHERE user_id = ':user_id';
DELETE FROM user_media WHERE user_id = ':user_id';
DELETE FROM user_food_preferences WHERE user_id = ':user_id';
DELETE FROM user_attributes WHERE user_id = ':user_id';
DELETE FROM user_preferences WHERE user_id = ':user_id';
DELETE FROM agent_config_files WHERE user_id = ':user_id';
-- Note: We do NOT delete from `users` table, allowing the core user to remain