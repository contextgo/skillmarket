# Custom MySQL Skill

This skill allows interaction with a MySQL database. It is designed to be generic, using placeholders for sensitive connection details.

## Commands

### Execute SQL Query
Executes a raw SQL query against the configured database.

**Usage:**

```bash
custom_mysql query "YOUR_SQL_QUERY_HERE"
```

**Parameters:**

- `query`: The SQL query string to execute.

### Execute Script
Executes a SQL script from a file.

**Usage:**

```bash
custom_mysql execute_script --file /path/to/your/script.sql
```

**Parameters:**

- `--file`: Path to the SQL script file.

### Create User Tables
Initializes the database schema necessary for storing user profiles, preferences, and other general information.

**Usage:**

```bash
custom_mysql create_tables --sql-script-path /path/to/create_user_tables.sql
```

**Parameters:**

- `--sql-script-path`: The path to the SQL script containing the table definitions (e.g., `~/.openclaw/workspace/skills/custom_mysql/create_user_tables.sql`).

## Configuration (Environment Variables)

Before using this skill, you need to set the following environment variables:

- `MYSQL_DATABASE`: The name of the MySQL database.
- `MYSQL_USER`: The MySQL username.
- `MYSQL_PASSWORD`: The MySQL password.
- `MYSQL_HOST`: The MySQL host (e.g., localhost, 127.0.0.1). Defaults to 'localhost'.
- `MYSQL_PORT`: The MySQL port (e.g., 3306). Defaults to '3306'.

**Example setup (Linux/macOS):**

```bash
export MYSQL_DATABASE="your_db_name"
export MYSQL_USER="your_db_user"
export MYSQL_PASSWORD="your_db_password"
export MYSQL_HOST="your_db_host" # Optional, defaults to localhost
export MYSQL_PORT="3306"       # Optional, defaults to 3306
```

## Installation for New Users

To set up this custom MySQL skill in a new OpenClaw instance:

1.  **Copy the Skill:** Copy the entire `custom_mysql` directory (including `SKILL.md` and `create_user_tables.sql`) from your workspace to the new instance's `~/.openclaw/workspace/skills/` directory.
2.  **Set Environment Variables:** On the new instance, before running any commands that use this skill, set the required environment variables (`MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`, and optionally `MYSQL_HOST`, `MYSQL_PORT`).
    *   For persistent settings, add these `export` commands to your shell's profile file (e.g., `~/.bashrc`, `~/.zshrc`).
3.  **Initialize Database Schema:** Run the `create_tables` command, pointing to the `create_user_tables.sql` script:

    ```bash
    custom_mysql create_tables --sql-script-path ~/.openclaw/workspace/skills/custom_mysql/create_user_tables.sql
    ```
4.  **Run Commands:** You can now use the `custom_mysql query` and `custom_mysql execute_script` commands.

---

**Data Ingestion as Source of Truth:**

This skill is designed to be the central hub for user data. An agent using this skill would typically:

1.  **Parse Logs/Input:** Read user data from various sources (e.g., daily logs, direct messages, configuration files).
2.  **Format Data:** Structure the extracted information into a format suitable for database insertion (e.g., JSON, or directly into SQL statements).
3.  **Interact with Skill:** Use the `custom_mysql query` or `custom_mysql execute_script` commands to:
    *   Insert new user records into the `users` table.
    *   Update `user_preferences`, `user_attributes`, `user_media`, and `user_food_preferences` based on the parsed data.
    *   Ensure `last_interaction` is updated in the `users` table.

This approach makes the database the definitive source of truth for each user's profile, preferences, and history, allowing for consistent and personalized interactions.

**Note:** This skill assumes the `mysql` command-line client is installed and available in the PATH of the OpenClaw environment.
