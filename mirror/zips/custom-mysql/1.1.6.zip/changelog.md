# CHANGELOG

All notable changes to the **MySQLClaw** skill for OpenClaw are documented in this file.

The format follows the [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) specification and respects [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-05-04

### Added
- **Complete user‑profile schema**  
  - `users` – core identity record.  
  - `user_preferences` – key/value pairs for generic preferences (e.g., “formality”).  
  - `user_attributes` – arbitrary attributes such as hobbies, likes, dislikes.  
  - `user_media` – favorite books, movies, TV shows, foods, etc.  
  - `user_food_preferences` – specialized table for food likes/dislikes.
- **Persona management** (`user_personas` table)  
  - Stores fictional back‑stories, quirks, mannerisms, and other role‑play traits.  
  - Allows agents to generate, edit, and retrieve a custom persona for each user.

- **Configuration snapshot system** (`agent_config_files` table)  
  - Persists versioned copies of `SOUL.md`, `USER.md`, `IDENTITY.md`, and `TOOLS.md`.  
  - Each entry includes a `snapshot_timestamp` and the raw file content, enabling easy rollback or audit.

- **Setup wizard** (`setup_wizard.sh`)  
  - Interactive script that walks a new user through entering basic preferences (favorite food, color, books, movies, TV shows, hobbies).  
  - Offers optional fictional back‑story generation, with a confirmation step before committing to `user_personas`.

- **Convenient high‑level commands** (exposed via `SKILL.md`):
  - `create_tables` – one‑click schema creation (idempotent, safe to re‑run).  
  - `add_persona_trait` – add or update a single persona attribute.  
  - `snapshot_config_file` – store a timestamped copy of any of the four core config files.  
  - `get_config_snapshot` – retrieve the latest or a specific historical snapshot.  
  - `get_user_data` – aggregated view of a user’s profile, media preferences, and persona.  
  - `rollback_setup` – safe reset of all user‑specific tables while preserving the core `users` record.

- **Error handling & transactions**  
  - All multi‑step operations (`setup_wizard.sh`, persona creation, snapshot storage) run inside a MySQL transaction.  
  - Automatic rollback on any failure, guaranteeing a clean state.

- **Documentation** (`SKILL.md`)  
  - Detailed usage examples, required JSON payload structures, and sample SQL snippets.  
  - Clear instructions for developers who want to extend the schema.

### Changed
- Replaced hard‑coded MySQL credentials with **placeholder variables** (`__DB_NAME__`, `__MYSQL_USER__`, `__MYSQL_PASSWORD__`) in the skill’s configuration template.
- Updated `SKILL.md` to reference the new tables (`user_personas`, `agent_config_files`) and to show the new high‑level commands.
- Added **SQL `INSERT … ON DUPLICATE KEY UPDATE`** logic for idempotent inserts (e.g., when the wizard is re‑run

## 1.0.1 – 2026-05-04
- Security hardening: removed unsafe `eval` usage in `setup_wizard.sh`.
- Added input validation and safe variable quoting.
- Introduced `sql_safe_exec.sh` wrapper to block destructive SQL and escape values.
- Declared required dependencies (MySQL client, OpenSSL) in `SKILL.md`.
- Added pre‑flight dependency checks and least‑privilege guidance.

## 1.0.2 – 2026-05-04
- Final security polish: Added Secret Redaction policy, Destructive Action confirmation guidelines, and command provenance documentation in SKILL.md.

## 1.0.3 – 2026-05-04
- **Credential security:** Passwords never appear on the command line. All mysql connections use temporary `--defaults-extra-file` with immediate cleanup.
- **DML confirmation:** `sql_safe_exec.sh` now requires interactive confirmation for INSERT, UPDATE, DELETE, REPLACE statements.
- **Path traversal prevention:** SQL referencing sensitive paths (.ssh, /etc, .env, .gnupg, .aws, .config) is blocked.
- **Secret redaction:** Added `sanitize_snapshot.sh` to redact API keys, tokens, passwords, private keys, and Stripe/GitHub tokens before DB storage.
- **Snapshot path whitelist:** Added `allowed_snapshot_paths` table restricting which files may be snapshotted.
- **Retention policy:** Added auto-purge via MySQL event (`purge_old_snapshots`) and manual procedure (`sp_purge_snapshots`). Default retention: 30 days.
- **Untrusted snapshots:** All snapshots marked `is_trusted = 0` by default until user-verified.
- **Stricter input validation:** Identifiers validated against `^[a-zA-Z_][a-zA-Z0-9_]{0,63}$` regex.
- **No eval anywhere:** Confirmed zero `eval` usage across all scripts.
- **Updated SKILL.md:** Full security architecture documentation, dependency table, least-privilege setup guide.

## 1.0.4 – 2026-05-04
- **Multi-statement SQL rejection:** `sql_safe_exec.sh` now rejects any input containing semicolons, preventing multi-statement bypass of DML confirmation.
- **DML keyword detection anywhere:** Confirmation prompt now triggers for INSERT/UPDATE/DELETE/REPLACE anywhere in the SQL string, not just at the start.
- **Trap-based credential cleanup:** Added `trap 'rm -f "$CREDS_FILE"' EXIT` to ensure the temporary password file is always cleaned up, even on `set -e` failures.
- **Updated SKILL.md:** Documented multi-statement rejection and trap-based cleanup.

## 1.0.5 – 2026-05-04
- **Trap-based credential cleanup in setup_wizard.sh:** Added `trap cleanup_creds EXIT` immediately after creating the temp credentials file. Password file is now cleaned up on ANY exit (normal, error, signal).
- **Fixed sanitize_snapshot.sh:** Replaced broken sed-based Stripe redaction with Perl-compatible regex engine. All secret patterns (API keys, tokens, passwords, AWS keys, Stripe keys, GitHub tokens) now reliably redacted.
- **Documented exec_script routing:** `custom_mysql exec_script` now explicitly routes all statements through `sql_safe_exec.sh` — one statement at a time, with DML confirmation and DDL blocking.
- **Updated SKILL.md:** Added Perl dependency, documented script execution controls, clarified bundled-only script policy.

## 1.0.6 – 2026-05-04
- **Added Capability Scope section to SKILL.md:** Explicitly states that the skill requires only MySQL credentials and does not use wallet, cryptocurrency, blockchain, or financial transaction capabilities. Stripe key detection is documented as a defensive redaction measure only.

## 1.0.7 – 2026-05-04
- **Added `custom_mysql` executable:** Agent-facing command wrapper that maps `custom_mysql query` and `custom_mysql exec_script` directly to `sql_safe_exec.sh`. Resolves "missing implementation" finding from ClawScan.
- **Added `CAPABILITIES.md`:** Explicitly declares what the skill can and cannot do. Documents that `crypto`/`wallet`/`purchases` scanner signals are false positives caused by defensive secret-redaction patterns. No wallet, crypto, payment, or external API code exists in the skill.
- **Updated SKILL.md:** References CAPABILITIES.md, documents command mapping, clarifies false-positive scanner signals.
- **Synced all files to `skills/custom_mysql/`.**

## 1.1.0 – 2026-05-05
- Added 5 new tracking tables (`user_interactions`, `user_relationships`, `user_context`, `skill_usage`, `user_notes`) for enhanced user intelligence.
- Enriched `users` table with display name/avatar/status fields.

- `.env` file support for credential persistence.

## 1.1.1 – 2026-05-05
- Fixed credential exposure by removing `create_admin_user.sh` from public distribution.
- Updated `custom_mysql.sh` to use a hardened wrapper for all DML.

## 1.1.2 – 2026-05-05
- Removed environment-specific Discord ID references from `CAPABILITIES.md`.
- Cleaned up publish bundle to remove .bak files.

## 1.1.3 – 2026-05-05
- **SQL Injection Fixed**: Refactored all `insert_*` commands to use proper input escaping with `sed` and `printf`.
- **Execution Security**: Replaced `grep` blacklist in `sql_safe_exec.sh` with a strict command whitelist (SELECT, INSERT, UPDATE, DELETE, REPLACE, ALTER).
- **Versioning**: Updated to v1.1.3 to resolve critical VirusTotal security findings.

## 1.1.5 – 2026-05-05
- **Security: Removed `--yes` bypass from all DML paths.** `custom_mysql.sh` no longer passes `--yes` to `sql_safe_exec.sh` for any `insert_*` or `exec` command. All DML now requires interactive user confirmation, preventing autonomous agents from silently modifying data.
- **Security: `query` command is now SELECT-only.** The `query` command rejects any statement that doesn't start with `SELECT`. DML must go through `exec` with interactive confirmation.
- **Security: Added table allowlist.** `sql_safe_exec.sh` now enforces a strict allowlist of approved `mysqlclaw` tables for all write operations.
- **Security: Added `--readonly` flag.** `sql_safe_exec.sh` supports `--readonly` mode which forces SELECT-only execution.
- **Security: Removed `jerith` and `root` references from `CAPABILITIES.md`.** Privilege model now documents dedicated least-privilege MySQL user scoped to `mysqlclaw` only.
- **Security: Added Data Retention, Consent & Deletion policy to `CAPABILITIES.md`.** Documents 30-day TTL, consent rules, deletion procedures, and trust rules for stale data.

## 1.1.4 – 2026-05-05
- **Versioning**: Bumped to v1.1.4 to resolve ClawHub version registration conflicts.
- **Verification**: Final check confirms clean, credential-free bundle with comprehensive input sanitization.
