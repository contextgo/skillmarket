#!/usr/bin/env bash
set -euo pipefail

# sql_safe_exec.sh - Hardened MySQL wrapper v1.1.5
# DML ALWAYS requires interactive confirmation. No --yes bypass exists.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$SCRIPT_DIR/.env" ] && { set -a; source "$SCRIPT_DIR/.env"; set +a; }

SQL="${1:-}"
[ -z "$SQL" ] && echo "ERROR: No SQL" >&2 && exit 1

# DML Check: Force confirmation
if echo "$SQL" | grep -iqE "\b(INSERT|UPDATE|DELETE|REPLACE)\b"; then
    echo "WARNING: Modifying data: $SQL"
    read -p "Confirm? (yes/no): " ans
    [ "$ans" != "yes" ] && echo "Aborted." && exit 0
fi

mysql -D mysqlclaw -e "$SQL"
