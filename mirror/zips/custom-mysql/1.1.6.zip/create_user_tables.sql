-- SQL script to create user profile tables for the custom MySQL skill

-- Table for general user information
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(255) PRIMARY KEY,
    username VARCHAR(255) UNIQUE,
    display_name VARCHAR(255),
    avatar_url VARCHAR(512),
    status ENUM('active','inactive','banned') DEFAULT 'active',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_interaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table for user preferences
CREATE TABLE IF NOT EXISTS user_preferences (
    preference_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    preference_type VARCHAR(100) NOT NULL,
    preference_value TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preference (user_id, preference_type)
);

-- Table for structured attributes
CREATE TABLE IF NOT EXISTS user_attributes (
    attribute_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    attribute_type ENUM('like', 'dislike', 'hobby', 'interest') NOT NULL,
    attribute_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_attribute (user_id, attribute_type, attribute_name)
);

-- Table for media
CREATE TABLE IF NOT EXISTS user_media (
    media_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    media_type ENUM('TV Show', 'Movie', 'Book') NOT NULL,
    title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    rating INT,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_media (user_id, media_type, title)
);

-- Table for food
CREATE TABLE IF NOT EXISTS user_food_preferences (
    food_pref_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    food_item VARCHAR(255) NOT NULL,
    preference ENUM('likes', 'dislikes') NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_food (user_id, food_item)
);

-- Table for persona traits
CREATE TABLE IF NOT EXISTS user_personas (
    persona_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    persona_name VARCHAR(255) NOT NULL,
    trait_type VARCHAR(100) NOT NULL, -- e.g., 'mannerism', 'quirk', 'vibe'
    trait_value TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_persona_trait (user_id, persona_name, trait_type)
);

-- Table for agent config snapshots
CREATE TABLE IF NOT EXISTS agent_config_files (
    config_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    file_path VARCHAR(512) NOT NULL,
    content TEXT NOT NULL,
    sanitized TINYINT NOT NULL DEFAULT 0,
    retention_days INT NOT NULL DEFAULT 30,
    is_trusted TINYINT NOT NULL DEFAULT 0,
    snapshot_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_snapshot_ts (snapshot_timestamp),
    INDEX idx_snapshot_user (user_id)
);

-- Table for pre-made persona templates
CREATE TABLE IF NOT EXISTS persona_templates (
    template_id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    default_traits JSON NOT NULL -- Stores an array of {type, value} objects
);

-- ------------------------------------------------------------------
-- New Interaction & Social Tables (v1.1.0)
-- ------------------------------------------------------------------

-- Table for conversation/message logs
CREATE TABLE IF NOT EXISTS user_interactions (
    interaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    channel VARCHAR(50) NOT NULL DEFAULT 'discord',
    direction ENUM('inbound','outbound') NOT NULL,
    message_type ENUM('text','image','audio','video','file','other') DEFAULT 'text',
    topic VARCHAR(255),
    summary TEXT,
    sentiment ENUM('positive','neutral','negative','mixed') DEFAULT 'neutral',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_channel (channel),
    INDEX idx_created (created_at),
    INDEX idx_topic (topic),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for social graph between users
CREATE TABLE IF NOT EXISTS user_relationships (
    relationship_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    related_user_id VARCHAR(255) NOT NULL,
    relationship_type ENUM('friend','family','colleague','acquaintance','blocked','other') NOT NULL DEFAULT 'acquaintance',
    strength TINYINT DEFAULT 5 CHECK (strength BETWEEN 1 AND 10),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_relationship (user_id, related_user_id),
    INDEX idx_user (user_id),
    INDEX idx_related (related_user_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (related_user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for flexible user state
CREATE TABLE IF NOT EXISTS user_context (
    context_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    context_key VARCHAR(128) NOT NULL,
    context_value TEXT,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_key (user_id, context_key),
    INDEX idx_user (user_id),
    INDEX idx_key (context_key),
    INDEX idx_expires (expires_at),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for tracking skill usage
CREATE TABLE IF NOT EXISTS skill_usage (
    usage_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    skill_name VARCHAR(128) NOT NULL,
    action VARCHAR(128),
    status ENUM('success','failure','timeout','cancelled') DEFAULT 'success',
    duration_ms INT,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_skill (skill_name),
    INDEX idx_status (status),
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for free-form notes
CREATE TABLE IF NOT EXISTS user_notes (
    note_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    note TEXT NOT NULL,
    category ENUM('general','preference','behavior','event','reminder','other') DEFAULT 'general',
    is_pinned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_category (category),
    INDEX idx_pinned (is_pinned),
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------------
-- Security hardening additions (v1.1.0)
-- ------------------------------------------------------------------

-- Index for efficient purge queries
CREATE INDEX idx_snapshot_ts ON agent_config_files (snapshot_timestamp);
CREATE INDEX idx_snapshot_user ON agent_config_files (user_id);
