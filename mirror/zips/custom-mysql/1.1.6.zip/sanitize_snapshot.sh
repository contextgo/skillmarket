#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# sanitize_snapshot.sh – Redact secrets before DB storage (v1.0.5)
#
# Scans file content for common secret patterns and replaces them
# with [REDACTED] before the content is inserted into the database.
#
# Usage: sanitize_snapshot.sh <file_path>
# ------------------------------------------------------------------

FILE_PATH="$1"

if [ -z "$FILE_PATH" ] || [ ! -f "$FILE_PATH" ]; then
    echo "ERROR: File not found: $FILE_PATH" >&2
    exit 1
fi

CONTENT=$(cat "$FILE_PATH")

# Redact common secret patterns using perl for reliable regex
# (sed doesn't support \b or case-insensitive well across platforms)
CONTENT=$(echo "$CONTENT" | perl -pe '
    s/(API_KEY|api_key|API-KEY|ApiKey)\s*[:=]\s*[A-Za-z0-9_\-]{8,}/[REDACTED]/gi;
    s/(SECRET|secret|SECRET_KEY|secret_key)\s*[:=]\s*[A-Za-z0-9_\-]{8,}/[REDACTED]/gi;
    s/(TOKEN|access_token|auth_token|AUTH_TOKEN)\s*[:=]\s*[A-Za-z0-9_\-\.]{8,}/[REDACTED]/gi;
    s/(PASSWORD|password|passwd|PASSWD)\s*[:=]\s*\S+/"[REDACTED]"/gi;
    s/(PRIVATE_KEY|private_key|RSA_PRIVATE)\s*[:=]\s*-----BEGIN[^-]*-----.*?-----END[^-]*-----/[REDACTED]/gi;
    s/(AWS_ACCESS_KEY_ID|aws_access_key_id)\s*[:=]\s*[A-Z0-9]{20}/[REDACTED]/gi;
    s/(AWS_SECRET_ACCESS_KEY|aws_secret_access_key)\s*[:=]\s*[A-Za-z0-9\/+=]{40}/[REDACTED]/gi;
    s/sk_live_[A-Za-z0-9]{24,}/[REDACTED]/gi;
    s/(ghp_|github_pat_)[A-Za-z0-9_]{20,}/[REDACTED]/gi;
')

echo "$CONTENT"
