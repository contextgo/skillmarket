# paradoxfuzzle/custom-mysql

## Overview
Security-hardened MySQL profile storage with capability bounding for OpenClaw. Tracks interactions, relationships, context, skill usage, and notes for users via the `custom_mysql.sh` tool.

## Version
1.1.5 – 2026-05-05

## Capabilities
- MySQL read/write operations only (no external APIs, crypto, or wallets)
- Uses `.env` files for credentials
- All SQL routed through `sql_safe_exec.sh` for safety
- `query` command is SELECT-only
- DML requires interactive confirmation (no non-interactive bypass)
- Table allowlist enforced for all write operations

## Configuration
| Option          | Default       | Notes                                  |
|-----------------|---------------|----------------------------------------|
| `MYSQL_HOST`    | `localhost`   | MySQL server address                   |
| `MYSQL_USER`    | `mysqlclaw`   | Read/write account (least privilege)   |
| `MYSQL_PASSWORD`| *required*    | Store in `.env` or vault              |
| `MYSQL_PORT`    | `3306`        | Standard MySQL port                    |
| `DATABASE`      | `mysqlclaw`   | Target database                        |

## Installation
```bash
# Install ClawHub CLI if not installed
npm i -g clawhub

# Create .env file with credentials
cat > .env <<'EOF'
MYSQL_USER=mysqlclaw
MYSQL_PASSWORD=your_secure_password
MYSQL_HOST=localhost
MYSQL_PORT=3306
EOF'
chmod 600 .env

# Apply schema with setup wizard
cd ~/.openclaw/workspace/skills/clawhub/paradoxfuzzle/custom-mysql
./setup_wizard.sh
```

## Usage
```bash
# Query
custom_mysql.sh query "SELECT * FROM users LIMIT 5;"

# Execute script
custom_mysql.sh exec --file /path/to/scripts.sql

# Convenience commands:
custom_mysql.sh insert_interaction <uid> <dir> <topic> <summary> [sentiment]
custom_mysql.sh insert_context <uid> <key> <value> [expires_at]``
```

## Security
- Credentials stored in secure `.env` files (600 permissions)
- No dangerous SQL allowed via `sql_safe_exec.sh`
- `query` command is SELECT-only (no DML through query)
- DML (INSERT/UPDATE/DELETE/REPLACE) requires interactive user confirmation
- Table allowlist: only approved `mysqlclaw` tables can be written to
- Dedicated least-privilege MySQL user required (no root, no cross-database access)
- Data retention: 30-day default TTL on snapshots and interactions
- Full user data deletion supported across all tables
- Foreign key constraints prevent orphaned data

## Change Log
[v1.1.1] – 2026-05-05
- Security fix: Removed hardcoded credentials, fixed SQL injection, and added user tracking tables.
- Added more detailed changelog entries for v1.1.0.

[v1.1.0] – 2026-05-05
- Added 5 new tracking tables (`user_interactions`, `user_relationships`, ...)
- Enriched `users` table with display name/avatar/status fields
- DML requires interactive confirmation (no non-interactive bypass)
- `.env` file support for credential persistence

Visit https://clawhub.ai/paradoxfuzzle/custom-mysql for live updates.