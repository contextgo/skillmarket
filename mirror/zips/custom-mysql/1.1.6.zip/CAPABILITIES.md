# MySQLClaw — Capability Declarations

This document explicitly declares what MySQLClaw **can** and **cannot** do.
It is intended to resolve automated security scanner false positives.

---

## What MySQLClaw DOES

| Capability | Status | Notes |
|---|---|---|
| MySQL database operations | ✅ YES | SELECT, INSERT, UPDATE, DELETE on `mysqlclaw` schema |
| User profile storage | ✅ YES | Food prefs, media prefs, communication preferences |
| Persona management | ✅ YES | Agent personas, fictional backstories, traits |
| Config file snapshots | ✅ YES | SOUL.md, USER.md, IDENTITY.md, TOOLS.md, MEMORY.md |
| Secret redaction | ✅ YES | Defensive pattern-matching in `sanitize_snapshot.sh` |
| SQL safety wrapper | ✅ YES | Single-statement, DML confirmation, DDL blocked |
| Automatic retention/purge | ✅ YES | Configurable TTL on snapshot records |

## What MySQLClaw DOES NOT do

| Capability | Status | Notes |
|---|---|---|
| Wallet access | ❌ NO | No wallet code, no wallet API calls, no wallet interaction |
| Cryptocurrency | ❌ NO | No blockchain code, no crypto keys, no crypto operations |
| Purchases / payments | ❌ NO | No payment processor integration, no purchase capability |
| Stripe API calls | ❌ NO | Stripe key detection is **defensive redaction only** — `sanitize_snapshot.sh` strips `sk_live_*` patterns from text before DB storage. The skill never calls any Stripe endpoint. |
| AWS API calls | ❌ NO | AWS key detection is **defensive redaction only**. No AWS SDK, no AWS API calls. |
| GitHub API calls | ❌ NO | GitHub token detection is **defensive redaction only**. No GitHub API usage. |
| Network access | ❌ NO | Beyond localhost MySQL socket connection |
| File system writes | ❌ NO | Beyond reading config files for snapshots |
| External service calls | ❌ NO | No HTTP requests, no API calls to any external service |

## Why the scanner flags `crypto` / `wallet` / `purchases`

`sanitize_snapshot.sh` uses Perl-compatible regex to detect and redact secret patterns BEFORE storing content in the database. The patterns include:

- `sk_live_*` — Stripe secret keys
- `AKIA*` — AWS access key IDs
- `wJalrXU...` — AWS secret access keys
- `ghp_*` — GitHub personal access tokens
- Generic `API_KEY=*`, `TOKEN=*`, `PASSWORD=*`, `SECRET=*` patterns

**These are string-matching patterns only.** The skill contains no code that calls Stripe, AWS, GitHub, or any payment/wallet/blockchain service. It simply ensures that if a user accidentally includes a secret in a config file, that secret gets redacted before hitting the database.

This is the same approach as `git-secrets` or `truffleHog` — pattern-based detection without any actual service interaction.

## `custom_mysql` Command Mapping

| Documented Command | Implementation File | Wrapper |
|---|---|---|
| `custom_mysql query "SQL"` | `custom_mysql` (this dir) | → `sql_safe_exec.sh` |
| `custom_mysql exec_script --file X` | `custom_mysql` (this dir) | → `sql_safe_exec.sh` per statement |

Both commands route through `sql_safe_exec.sh` which enforces single-statement execution, DDL blocking, and DML confirmation.

## Credentials & Privilege Model

- Uses `MYSQL_USER` / `MYSQL_PASSWORD` environment variables only
- Password is NEVER passed on the command line (uses `--defaults-extra-file`)
- **Dedicated least-privilege MySQL user required** — must be scoped to `mysqlclaw` database only
- Recommended setup:
  ```sql
  CREATE USER 'mysqlclaw'@'localhost' IDENTIFIED BY '<strong-random-pw>';
  GRANT SELECT, INSERT, UPDATE, DELETE, ALTER ON mysqlclaw.* TO 'mysqlclaw'@'localhost';
  ```
- Root/admin accounts must NOT be used
- No access to any database other than `mysqlclaw`
- Table allowlist enforced in code for all write operations

## Data Retention, Consent & Deletion Policy

### Retention
- All user data tables have a configurable TTL (default: 30 days)
- `agent_config_files` snapshots: 30-day default TTL via `purge_old_snapshots` event
- `user_context` records: optional `expires_at` column for per-key expiry
- `user_interactions`: 30-day rolling window
- `user_notes`, `user_relationships`, `skill_usage`: retained until explicitly deleted

### Consent
- All profile data is stored only for the user who provided it
- `user_personas` and `user_attributes` data is treated as user-provided content
- Config file snapshots (`SOUL.md`, `USER.md`, etc.) are marked `is_trusted = 0` by default until user-verified
- No data is shared across users or external services

### Deletion
- Full user data deletion: `DELETE FROM <table> WHERE user_id = '<id>'` across all tables
- `cleanup_snapshots.sql` covers all snapshot and tracking tables
- Rollback procedure wipes all user-specific data while preserving schema
- No backups of user data outside the `mysqlclaw` database

### Trust Rules
- Stale data (>30 days) should be treated as potentially outdated
- Agents must verify critical facts with the user before acting on stored context
- Snapshots are historical records, not authoritative current truth
