#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# setup_wizard.sh – MySQLClaw Setup Wizard (v1.0.5)
#
# Security-hardened: no eval, password never on command line,
# trap-based credential cleanup, input validation, safe SQL execution
# ------------------------------------------------------------------

# 1. Dependency check
for cmd in mysql openssl; do
    if ! command -v "$cmd" &>/dev/null; then
        echo "ERROR: Required command '$cmd' not found in PATH."
        echo "Please install it before running this wizard."
        exit 1
    fi
done

echo "╔══════════════════════════════════════════╗"
echo "║   MySQLClaw Setup Wizard (v1.0.5)       ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 2. Strict identifier validation helper
validate_identifier() {
    local val="$1"
    local label="$2"
    if [[ ! "$val" =~ ^[a-zA-Z_][a-zA-Z0-9_]{0,63}$ ]]; then
        echo "ERROR: Invalid $label. Use 1-64 letters, numbers, underscores. Must start with a letter or underscore."
        return 1
    fi
    return 0
}

# 3. Collect credentials securely
read -p "Enter MySQL Host [localhost]: " RAW_HOST
MYSQL_HOST="${RAW_HOST:-localhost}"

read -p "Enter MySQL Port [3306]: " RAW_PORT
MYSQL_PORT="${RAW_PORT:-3306}"

read -p "Enter MySQL Username: " RAW_USER
validate_identifier "$RAW_USER" "username" || exit 1
MYSQL_USER="$RAW_USER"

# Use -s flag so password is not echoed to terminal
read -sp "Enter MySQL Password: " MYSQL_PASSWORD
echo ""
if [ -z "$MYSQL_PASSWORD" ]; then
    echo "ERROR: Password cannot be empty."
    exit 1
fi

read -p "Enter Target Database Name [mysqlclaw]: " RAW_DB
DB_NAME="${RAW_DB:-mysqlclaw}"
validate_identifier "$DB_NAME" "database name" || exit 1

# 4. Export credentials for the helper script
export MYSQL_USER MYSQL_PASSWORD MYSQL_HOST MYSQL_PORT

# 5. Build temporary credentials file (password never on cmd line)
CREDS_FILE=$(mktemp /tmp/.mysqlclaw_wiz_XXXXXX.cnf)
chmod 600 "$CREDS_FILE"
cat > "$CREDS_FILE" << CREDS_EOF
[client]
user=${MYSQL_USER}
password=${MYSQL_PASSWORD}
host=${MYSQL_HOST}
port=${MYSQL_PORT}
CREDS_EOF

# 6. Trap-based cleanup – runs on ANY exit (normal, error, signal)
cleanup_creds() {
    rm -f "$CREDS_FILE"
}
trap cleanup_creds EXIT

MYSQL_CMD="mysql --defaults-extra-file=$CREDS_FILE"

# 7. Test connection
echo ""
echo "Testing connection..."
if ! $MYSQL_CMD -e "SELECT 1;" &>/dev/null; then
    echo "ERROR: Could not connect to MySQL. Check your credentials."
    exit 1
fi
echo "Connection successful!"

# 8. Create database
echo "Creating database '$DB_NAME' if it doesn't exist..."
$MYSQL_CMD -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\`;"

# 9. Apply schema
echo "Applying schema from create_user_tables.sql..."
if [ -f "create_user_tables.sql" ]; then
    $MYSQL_CMD -D "$DB_NAME" < create_user_tables.sql
    echo "Schema applied."
else
    echo "WARNING: create_user_tables.sql not found in current directory."
fi

# 10. Apply retention/cleanup schema
echo "Applying retention policy schema..."
if [ -f "cleanup_snapshots.sql" ]; then
    $MYSQL_CMD -D "$DB_NAME" < cleanup_snapshots.sql
    echo "Retention policy applied."
fi

# 11. Verify new tables exist
echo "Verifying schema..."
TABLE_COUNT=$($MYSQL_CMD -D "$DB_NAME" -sN -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$DB_NAME';")
echo "Schema applied: $TABLE_COUNT tables in '$DB_NAME'"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   Setup complete! Database '$DB_NAME'    ║"
echo "║   is ready.                              ║"
echo "╚══════════════════════════════════════════╝"
