---
name: pdf-trip-summary
description: 批量处理打车行程单PDF文件，转换为Markdown并汇总成Excel表格。当用户需要处理打车行程单（如高德打车、滴滴、T3出行等行程单）时使用此skill。文件名通常包含"行程单"关键词。自动按时间排序、重置序号、计算总金额。
---

# 打车行程单汇总处理

本skill专门用于批量处理打车行程单PDF文件，将每个PDF转换为Markdown文件，并汇总所有行程记录生成Excel表格。

## 必要依赖

**需要配置 docling MCP**

本skill依赖 docling MCP 工具来转换PDF文件。如果调用失败，请引导用户配置：

### 配置方法

docling MCP 需要在 MCP 配置文件中添加：

```json
{
  "mcpServers": {
    "docling": {
      "command": "uvx",
      "args": ["docling-mcp"]
    }
  }
}
```

如果用户没有配置，提示：
1. 检查 MCP 配置文件位置（如 `~/.claude/mcp.json` 或项目级配置）
2. 添加 docling MCP 配置
3. 重启 Claude Code 或重新加载 MCP

**首次使用提示**：docling 需要下载模型文件，确保网络连接正常。

## 适用场景

专门用于打车行程单处理：
- 高德打车行程单
- 滴滴出行行程单
- T3出行行程单
- 如祺出行行程单
- 其他打车平台的行程单

**识别特征**：文件名通常包含"行程单"关键词，如：
- `【T3出行-90.44元-2个行程】高德打车电子行程单.pdf`
- `滴滴出行行程单.pdf`

**不适用场景**：
- 发票PDF（发票和行程单是不同类型的文档）
- 账单、收据等非行程单文档

## 工作流程

## 步骤0：获取姓名信息

**重要：如果用户未指定姓名，必须先询问**

在开始处理前，检查是否已知行程人姓名：
- 如果用户在请求中提到姓名 → 直接使用
- 如果未提到姓名 → 使用 question 工具询问用户

询问示例：
```
请提供行程人姓名，将用于Excel汇总表中的姓名列
```

将姓名作为参数传递给后续脚本处理。

### 步骤1：扫描PDF文件

使用glob工具扫描当前目录下的所有PDF文件：
```
*.pdf
```

确认文件是否为行程单（检查文件名是否包含"行程单"关键词）。

### 步骤2：批量转换PDF为Markdown

使用docling MCP将每个PDF文件转换为Markdown格式：

对每个PDF文件调用：
```
docling_convert_document_into_docling_document(source=<PDF路径>)
```

**错误处理**：
- 如果工具不存在 → 引导用户配置 docling MCP
- 如果网络超时 → 提示用户检查网络后重试
- 转换成功后会得到每个文档的 document_key

### 步骤3：导出Markdown内容

对每个转换后的文档，导出Markdown内容：
```
docling_export_docling_document_to_markdown(document_key=<key>)
```

### 步骤4：创建输出目录

创建用于存放输出文件的目录（建议命名为`excel`）：
```bash
mkdir excel
```

### 步骤5：保存Markdown文件

将每个文档的Markdown内容保存到输出目录：
- 文件命名：使用服务商名称（如 `T3出行.md`、`如祺出行.md`）
- 格式：`.md`

### 步骤6：汇总表格数据

使用 skill 目录下的脚本 `scripts/summarize_trips.py` 处理数据：

**脚本位置**：本skill已包含处理脚本，位于 `scripts/summarize_trips.py`

**脚本功能**：
1. 读取所有MD文件
2. 提取表格数据（序号、姓名、日期、城市、起点、终点、金额）
3. 按日期排序
4. 重置序号（从1开始）
5. 填充姓名列（使用步骤0获取的姓名）
6. 计算总金额
7. 生成Excel文件

### 步骤7：生成Excel文件

创建Excel汇总表，包含：
- 按时间排序的所有记录
- 重新生成的序号（从1开始）
- 最后一行显示合计和总金额（粗体样式）

## 字段处理规则

**字段顺序**：序号、姓名、日期、城市、起点、终点、金额

字段说明：
- **序号**：重新生成，从1开始
- **姓名**：必须在步骤0获取，填充到所有行
- **日期**：原PDF中的"上车时间"，保留完整值（YYYY-MM-DD HH:MM格式），仅字段名改为"日期"
- **城市**：保留原值
- **起点**：保留原值
- **终点**：保留原值
- **金额**：保留原值，最后一行汇总总金额

**通常删除**：服务商、车型、来源文件等元数据字段

如果用户要求不同的字段，灵活调整。

## 输出结构

最终输出目录应包含：
```
excel/
├── T3出行.md
├── 如祺出行.md
├── ...
└── 行程汇总表.xlsx
```

**注意**：处理脚本（summarize_trips.py）位于skill目录，不在输出目录。

## 常见问题处理

### docling MCP 未配置

如果调用 docling 工具时报错 `Unknown tool: docling_*`：

**引导用户配置**：
1. 说明需要配置 docling MCP
2. 提供配置示例（见上方"必要依赖"部分）
3. 告知配置文件位置
4. 提醒重启/重新加载 MCP

### PDF转换网络超时

```
ConnectTimeout: [WinError 10060]
```

提示用户：
1. 检查网络连接
2. 稍后重试

### Excel文件被占用

```
PermissionError: [Errno 13] Permission denied
```

解决方案：
1. 提示用户关闭Excel程序
2. 或生成新文件名（添加"_新"后缀）

### 表格数据提取失败

检查：
- Markdown表格格式是否正确
- 分隔符是否为 `|`
- 数据行是否跳过表头行（序号行）

## 用户交互要点

**步骤0必须执行**：如果用户未指定姓名，必须使用 question 工具询问。

在处理过程中向用户确认：
1. **姓名**：**必须询问**（如果用户未指定）
2. **输出目录名称**：默认 `excel`，可自定义
3. **是否需要汇总金额**：默认需要

## 完整示例流程

```bash
# 0. 获取姓名（如果未指定）
question: "请提供行程人姓名"
# 用户回答: "张三"

# 1. 扫描PDF
glob pattern="*.pdf"  # 找到13个行程单PDF

# 2. 批量转换（并行）
docling_convert_document_into_docling_document(source=pdf1)
docling_convert_document_into_docling_document(source=pdf2)
...

# 3. 导出Markdown（并行）
docling_export_docling_document_to_markdown(document_key=key1)
docling_export_docling_document_to_markdown(document_key=key2)
...

# 4. 创建目录
mkdir excel

# 5. 保存MD文件（并行）
write(filePath=excel/T3出行.md, content=markdown1)
write(filePath=excel/如祺出行.md, content=markdown2)
...

# 6. 运行汇总脚本（传递姓名参数）
python scripts/summarize_trips.py excel 张三

# 输出结果
- 13个MD文件
- 1个Excel汇总表
- 字段：序号、姓名、日期、城市、起点、终点、金额
- 19条行程记录
- 总金额：892.52元
```

## 注意事项

1. **并行处理**：转换和导出操作可以并行执行以提高效率
2. **进度跟踪**：使用 TodoWrite 跟踪处理进度
3. **MCP检查**：处理前确认 docling MCP 已配置，否则引导用户配置
4. **用户反馈**：处理完成后告知用户文件位置和统计信息