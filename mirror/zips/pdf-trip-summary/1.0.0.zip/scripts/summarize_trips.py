"""
打车行程单表格汇总脚本
用于从Markdown文件中提取行程单表格数据并生成Excel汇总表

依赖: pandas, openpyxl
"""

import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment


def extract_trip_data_from_markdown(md_dir: str) -> list:
    """
    从所有Markdown文件中提取行程单表格数据
    
    Args:
        md_dir: 存放Markdown文件的目录路径
        
    Returns:
        包含所有行程数据的列表
    """
    all_data = []
    
    md_files = [f for f in os.listdir(md_dir) if f.endswith('.md')]
    
    for md_file in md_files:
        filepath = os.path.join(md_dir, md_file)
        
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.split('\n')
        
        for line in lines:
            if '|' in line and not line.startswith('|---'):
                cells = [cell.strip() for cell in line.split('|')]
                cells = [c for c in cells if c]
                
                if len(cells) >= 8 and cells[0] != '序号':
                    try:
                        pickup_time = cells[3]
                        
                        amount_str = cells[-1]
                        amount = float(amount_str.replace('元', '').strip())
                        
                        row_data = {
                            '日期': pickup_time,
                            '城市': cells[4],
                            '起点': cells[5],
                            '终点': cells[6],
                            '金额': amount
                        }
                        all_data.append(row_data)
                    except (ValueError, IndexError):
                        continue
    
    return all_data


def create_summary_excel(data: list, traveler_name: str, output_file: str) -> tuple:
    """
    创建行程汇总Excel表格
    
    Args:
        data: 行程数据列表
        traveler_name: 行程人姓名
        output_file: Excel文件输出路径
        
    Returns:
        (记录数量, 总金额)
    """
    df = pd.DataFrame(data)
    
    df['日期_datetime'] = pd.to_datetime(df['日期'], format='%Y-%m-%d %H:%M')
    df = df.sort_values('日期_datetime')
    df = df.drop('日期_datetime', axis=1)
    
    df.insert(0, '序号', range(1, len(df) + 1))
    df.insert(1, '姓名', traveler_name)
    
    total_amount = df['金额'].sum()
    
    wb = Workbook()
    ws = wb.active
    ws.title = '行程汇总'
    
    headers = ['序号', '姓名', '日期', '城市', '起点', '终点', '金额']
    ws.append(headers)
    
    for idx, row in df.iterrows():
        ws.append([
            row['序号'],
            row['姓名'],
            row['日期'],
            row['城市'],
            row['起点'],
            row['终点'],
            row['金额']
        ])
    
    summary_row = len(df) + 2
    ws.cell(row=summary_row, column=1, value='合计')
    ws.cell(row=summary_row, column=7, value=total_amount)
    
    ws.cell(row=summary_row, column=1).font = Font(bold=True)
    ws.cell(row=summary_row, column=7).font = Font(bold=True)
    
    for row in ws.iter_rows(min_row=summary_row, max_row=summary_row):
        for cell in row:
            cell.alignment = Alignment(horizontal='center')
    
    wb.save(output_file)
    
    return len(df), total_amount


def main(md_dir: str = None, traveler_name: str = None):
    """
    主函数
    
    Args:
        md_dir: Markdown文件所在目录，默认为当前目录下的excel文件夹
        traveler_name: 行程人姓名，必须提供
    """
    if md_dir is None:
        md_dir = os.path.join(os.getcwd(), 'excel')
    
    if traveler_name is None:
        print("错误：必须提供行程人姓名")
        print("用法: python summarize_trips.py <目录> <姓名>")
        return
    
    all_data = extract_trip_data_from_markdown(md_dir)
    
    if not all_data:
        print("未找到任何行程数据")
        return
    
    output_file = os.path.join(md_dir, '行程汇总表.xlsx')
    count, total = create_summary_excel(all_data, traveler_name, output_file)
    
    print(f"成功生成Excel文件: {output_file}")
    print(f"行程人姓名: {traveler_name}")
    print(f"共汇总 {count} 条行程记录")
    print(f"总金额: {total:.2f} 元")


if __name__ == '__main__':
    import sys
    
    md_dir = sys.argv[1] if len(sys.argv) > 1 else None
    traveler_name = sys.argv[2] if len(sys.argv) > 2 else None
    
    main(md_dir, traveler_name)