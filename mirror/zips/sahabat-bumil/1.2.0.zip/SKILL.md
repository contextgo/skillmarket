# Sahabat Bumil - Indonesian Pregnancy Guide

> 🤰 **Panduan kehamilan untuk ibu hamil Indonesia - Nutrition, wellness, and support for Indonesian moms!**

---

## 📖 Overview

**Sahabat Bumil** adalah asisten kehamilan yang dirancang khusus untuk **ibu hamil Indonesia** dengan pemahaman konteks lokal, makanan Indonesia, tradisi, dan kebutuhan ibu hamil muda (young moms).

**Philosophy:**
> "Setiap kehamilan adalah perjalanan yang indah. Sahabat Bumil di sini untuk mendukung, menginformasi, dan merayakan setiap momen!"

---

## ✨ Features

### **🍎 Indonesian Nutrition Guide**
- **Safe Indonesian Foods** - Makanan Indonesia yang aman untuk hamil
- **Foods to Avoid** - Makanan yang harus dihindari (with local context)
- **Traditional Recipes** - Recipe Indonesia sehat untuk hamil
- **Warung Safety** - Tips makan di warung/restaurant
- **Young Mom Nutrition** - Nutrisi khusus untuk ibu hamil muda (age 22-30)

### **📅 Pregnancy Tracking**
- **Week-by-Week Development** - Perkembangan bayi per minggu
- **Trimester Milestones** - Milestone penting per trimester
- **Symptom Tracking** - Track symptoms umum
- **Baby Size Comparisons** - Ukuran bayi (buah analogi)

### **🏥 Health & Wellness**
- **Morning Sickness Tips** - Managing morning sickness
- **Safe Exercises** - Olahraga aman untuk hamil
- **Sleep Tips** - Tips tidur nyaman
- **Emotional Support** - Managing anxiety & mood swings

### **🛒 Preparation Guides**
- **Hospital Bag Checklist** - Tas rumah sakit
- **Baby Registry** - Perlengkapan bayi yang perlu
- **Nursery Prep** - Persiapan kamar bayi
- **Birth Plan** - Panduan birth plan

### **💰 Financial Planning** (Indonesia Context)
- **Cost Estimates** - Estimasi biaya melahirkan (Jakarta & major cities)
- **BPJS Coverage** - Panduan lengkap BPJS untuk hamil
- **Insurance Comparison** - BPJS vs Private insurance
- **Money-Saving Tips** - Tips hemat untuk persiapan bayi

### **🎓 Education**
- **Prenatal Classes** - Info kelas prenatal (online & offline)
- **Breastfeeding Guide** - Dasar-dasar menyusui
- **Newborn Care** - Perawatan bayi baru lahir
- **Postpartum Care** - Perawatan pasca melahirkan

---

## 🚀 Quick Start

### **Installation**

```bash
# Via ClawHub
openclaw skill install sahabat-bumil

# Or manual
git clone https://github.com/yourusername/sahabat-bumil.git ~/.openclaw/skills/sahabat-bumil
pip3 install -r ~/.openclaw/skills/sahabat-bumil/requirements.txt
```

### **Usage**

```bash
# Nutrition
/nutrition foods
/nutrition avoid
/nutrition recipes
/nutrition morning-sickness
/nutrition young-mom
/nutrition warung

# Pregnancy Info
/pregnancy week
/pregnancy trimester
/pregnancy baby-size

# Health
/health symptoms
/health weight
/health movements

# Preparation
/prep hospital-bag
/prep registry
/prep birth-plan

# Financial
/finance budget
/finance bpjs
/finance tips
```

---

## 📋 Commands

### **Nutrition Commands**

| Command | Description | Example |
|---------|-------------|---------|
| `/nutrition foods` | Safe Indonesian foods | `/nutrition foods` |
| `/nutrition avoid` | Foods to avoid | `/nutrition avoid` |
| `/nutrition recipes` | Indonesian recipes | `/nutrition recipes` |
| `/nutrition morning-sickness` | Morning sickness tips | `/nutrition morning-sickness` |
| `/nutrition young-mom` | Young mom nutrition | `/nutrition young-mom` |
| `/nutrition warung` | Eating outside guide | `/nutrition warung` |

### **Pregnancy Info**

| Command | Description | Example |
|---------|-------------|---------|
| `/pregnancy week` | Current week calculator | `/pregnancy week` |
| `/pregnancy trimester` | Trimester information | `/pregnancy trimester` |
| `/pregnancy baby-size` | Baby size this week | `/pregnancy baby-size` |

### **Health & Wellness**

| Command | Description | Example |
|---------|-------------|---------|
| `/health symptoms` | Common symptoms | `/health symptoms` |
| `/health weight` | Track weight | `/health weight 55kg` |
| `/health movements` | Baby movement tracking | `/health movements` |

### **Preparation**

| Command | Description | Example |
|---------|-------------|---------|
| `/prep hospital-bag` | Hospital bag checklist | `/prep hospital-bag` |
| `/prep registry` | Baby registry | `/prep registry` |
| `/prep birth-plan` | Birth plan guide | `/prep birth-plan` |

### **Financial (Indonesia)**

| Command | Description | Example |
|---------|-------------|---------|
| `/finance budget` | Cost estimates | `/finance budget mid` |
| `/finance bpjs` | BPJS coverage | `/finance bpjs` |
| `/finance tips` | Money-saving tips | `/finance tips` |

---

## 🎯 Example Outputs

### **Indonesian Foods**
```
/nutrition foods

🍎 Indonesian Foods Safe for Pregnancy:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌾 CARBOHYDRATES:
• Nasi putih/merah - Energy, B vitamins
• Kentang - Carbs, potassium, vitamin C
• Ubi jalar - Fiber, vitamin A, beta-carotene
• Jagung - Fiber, folate

🥚 PROTEINS:
• Ayam (well-cooked) - Lean protein, B vitamins
• Ikan (low mercury) - Omega-3, protein
• Telur (fully cooked) - Protein, choline
• Tempe - Protein, probiotics, iron ⭐
• Tahu - Protein, calcium

🥬 VEGETABLES:
• Bayam - Iron, folate, vitamin K
• Kangkung - Iron, vitamin A
• Wortel - Vitamin A, beta-carotene
• Brokoli - Folate, fiber, vitamin C

🍎 FRUITS:
• Pisang - Potassium, vitamin B6
• Pepaya (ripe) - Vitamin C, fiber ⚠️ Only RIPE!
• Jeruk - Vitamin C, folate
• Alpukat - Healthy fats, folate ⭐
```

### **Morning Sickness Tips**
```
/nutrition morning-sickness

🤢 Morning Sickness Management
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🍽️ EATING TIPS:
• Eat small, frequent meals (5-6x/day)
• Keep crackers by bed, eat before getting up
• Avoid empty stomach
• Choose bland, easy-to-digest foods

💧 HYDRATION:
• Sip water throughout the day
• Try ginger tea or ginger candies
• Ice chips or popsicles

🌿 NATURAL REMEDIES:
• Ginger (tea, candies, supplements)
• Peppermint tea
• Lemon water
• Vitamin B6 supplements (consult doctor)

⏰ WHEN TO SEE DOCTOR:
• Can't keep any food/fluids down
• Losing weight
• Signs of dehydration
• Vomiting blood
```

### **Hospital Bag Checklist**
```
/prep hospital-bag

🎒 Hospital Bag Checklist
━━━━━━━━━━━━━━━━━━━━━━━━━━

FOR MOM:
☐ ID & insurance cards
☐ BPJS card (if using)
☐ Comfortable clothes
☐ Nursing bras (2-3)
☐ Toiletries
☐ Phone charger
☐ Slippers
☐ Going-home outfit

FOR BABY:
☐ Onesies (2-3)
☐ Blankets
☐ Hat & socks
☐ Diapers (small pack)
☐ Car seat (installed!)

FOR PARTNER:
☐ Phone charger
☐ Snacks & water
☐ Change of clothes
☐ Camera
☐ Cash/cards

⏰ PACK BY: 32-34 weeks
```

### **BPJS Coverage**
```
/finance bpjs

🏥 BPJS Pregnancy Coverage
━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ COVERED SERVICES:
• Prenatal checkups (minimum 6x)
• Ultrasound (2x during pregnancy)
• Blood tests & lab work
• Iron & folic acid supplements
• Normal delivery
• Caesar if medically necessary
• Complications coverage
• Postpartum care (42 days)
• Newborn care (first 28 days)
• Immunizations (BCG, Polio, Hep B)

📋 REQUIREMENTS:
• Active BPJS membership
• Referral from Puskesmas
• KTP & KK copies
• Buku KIA

💰 COST: Rp 0 - 2M (mostly covered!)
```

---

## 🔧 Configuration

### **Optional Settings**

```bash
# Set location for hospital recommendations
export SAHABAT_BUMIL_LOCATION="jakarta"

# Set budget preference
export SAHABAT_BUMIL_BUDGET="mid"  # low, mid, high

# Set language preference
export SAHABAT_BUMIL_LANG="id"  # id or en
```

---

## 📊 Data Sources

| Data | Source | Update Frequency |
|------|--------|------------------|
| Nutrition Info | Indonesian Ministry of Health, ACOG | Static (reviewed annually) |
| Recipes | Traditional Indonesian cuisine | Static |
| Hospital Info | Public data, user contributions | Manual updates |
| BPJS Info | BPJS Kesehatan official | Manual updates |
| Cost Estimates | User contributions, surveys | Quarterly |

---

## ⚠️ Disclaimers

**IMPORTANT:**
- ⚠️ **I'm not a doctor** - Always consult your healthcare provider
- ⚠️ **Every pregnancy is different** - What works for others may not work for you
- ⚠️ **Medical emergencies** - Call your doctor or emergency services immediately
- ⚠️ **Cost estimates** - Actual costs may vary by hospital and location
- ⚠️ **BPJS info** - Policies may change, verify with BPJS directly

**Red Flags (Call Doctor Immediately):**
- 🚨 Severe bleeding
- 🚨 Severe abdominal pain
- 🚨 Decreased fetal movement
- 🚨 Severe headaches/vision changes
- 🚨 Signs of preterm labor
- 🚨 Water breaking early

---

## 📝 Changelog

### **v1.0.0** (2026-04-07)
- ✅ Initial release
- ✅ Indonesian nutrition guide
- ✅ Traditional recipes
- ✅ Morning sickness tips
- ✅ Young mom nutrition
- ✅ Warung safety guide
- ✅ Hospital bag checklist
- ✅ BPJS coverage guide
- ✅ Financial planning tools
- ✅ Pregnancy tracking

---

## 🤝 Support

- **Documentation:** https://github.com/yourusername/sahabat-bumil
- **Issues:** https://github.com/yourusername/sahabat-bumil/issues
- **Email:** dev.fajrizky@gmail.com
- **Community:** Indonesian Moms Facebook Group

---

## 📄 License

MIT License - See LICENSE file for details

---

## 👨💻 Author

**Bowo (Fajrizky)**
- GitHub: https://github.com/defzky
- Email: dev.fajrizky@gmail.com
- Location: Indonesia 🇮🇩

**Inspired by:** The journey of my wife's first pregnancy at age 22 in Jakarta

---

## 💕 Dedication

*Dedicated to all Indonesian moms, especially young mothers navigating their first pregnancy. You are stronger than you know!*

**"Setiap kehamilan adalah anugerah. Selamat menjalani perjalanan indah ini, Bunda! 🤰💕"**

---

## 🎯 Roadmap

### **v1.1.0** (Coming Soon)
- [ ] Jakarta hospital database (generalized to major cities)
- [ ] Prenatal class finder
- [ ] Contraction timer
- [ ] Kick counter

### **v1.2.0** (Future)
- [ ] Community features (mom forums)
- [ ] Expert Q&A (monthly sessions)
- [ ] Baby name generator (Indonesian names)
- [ ] Postpartum support resources

---

**Happy Pregnancy, Bunda! 🤰✨**
