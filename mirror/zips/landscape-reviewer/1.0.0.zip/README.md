# 🌿 景观设计审图助手 Skill / Landscape Drawing Review Skill

> **国内外双版本 · 中美欧三地规范 · 专业级景观施工图AI审查**
>
> **Bilingual (CN/EN) · China / US / EU Standards · Professional AI Landscape Plan Review**

---

## 📌 简介 / Overview

这是一款为景观设计总工打造的 **WorkBuddy Skill**，集成了18年景观审图经验与国内外主流规范体系，支持：

This is a **WorkBuddy Skill** built for senior landscape architects, integrating professional review experience and international standards across China, US, and EU.

| 版本 / Version | 适用地区 / Region | 核心规范 / Standards |
|--------------|----------------|-------------------|
| 🇨🇳 国内版 | 中国（China） | GB/CJJ/建标系列 |
| 🇺🇸 美国版 | 美国（US） | ADA / LEED / ASLA / USDA Zone / ASCE 7 |
| 🇪🇺 欧洲版 | 欧盟（EU） | Florence Convention / EU Green Deal / IFLA / BREEAM |

---

## ✨ 功能亮点 / Key Features

### 国内版输出 / China Version Output
- ✅ 审查总结（总体评价 + 项目概况）
- ✅ 问题清单（含规范引用 + 严重程度分级）
- ✅ 业务与体系提醒（终身责任 + 行业背景）
- ✅ 亮点与优化建议
- ✅ 签字建议（可签 / 暂缓 / 不可签 三级）
- ✅ 下一步行动项

### 国际版输出 / International Version Output
- ✅ Review Summary（综合风险评级）
- ✅ ADA Accessibility & Inclusivity Check
- ✅ Climate & Ecology Analysis（USDA Zone / SuDS / Biodiversity）
- ✅ Sustainability Assessment（LEED / BREEAM / EU Green Deal）
- ✅ Structured Issue List with Risk Levels
- ✅ Sign-Off Recommendation + Next Action Items
- ✅ AI Disclaimer（GDPR / CCPA compliant）

### 双标准对照模式 / Dual-Standard Mode
- 中美规范差异对照
- 欧洲与中国规范对照
- 同时满足双市场的设计建议

---

## 🗂️ 文件结构 / File Structure

```
landscape-drawing-review/
├── SKILL.md                  ← Skill主文件 / Main skill file
├── README.md                 ← 本文件 / This file
└── references/
    ├── standards.md          ← 规范索引（中国+美国+欧洲）/ Standards index (CN+US+EU)
    ├── checklist.md          ← 审查清单（含欧美国际版）/ Review checklists (incl. international)
    └── issues.md             ← 典型案例库（含欧美案例）/ Typical issue cases (incl. US/EU)
```

---

## 📦 安装方式 / Installation

### 方法一：下载zip一键安装 / Method 1: Install from zip

1. 下载 [landscape-drawing-review.zip](./landscape-drawing-review.zip)
2. 打开 **WorkBuddy** → 左侧边栏「专家」→ 右上角菜单（⋯）
3. 选择「**安装自定义Skill**」→ 选中下载的zip文件
4. 安装完成，在对话中提及「审图」「landscape review」等词即可触发

### 方法二：clone源码安装 / Method 2: Install from source

```bash
git clone https://github.com/YOUR_USERNAME/landscape-drawing-review.git ~/.workbuddy/skills/landscape-drawing-review
```

---

## 🚀 使用示例 / Usage Examples

### 中国项目（国内版）
```
帮我审查这套景观施工图（上传PDF/图片）
按7步法核查这个公园绿地施工图
这套图纸能签字吗？
```

### 美国项目（美国版）
```
Review this park pavilion design for ADA compliance, Chicago, USDA Zone 5b
Check this landscape plan against LEED BD+C requirements
Is this design accessible per ADA standards?
```

### 欧洲项目（欧洲版）
```
Check this urban renewal project against Florence Convention and EU Green Deal, Amsterdam
Review this park for EU accessibility requirements (EUAA 2025)
Assess biodiversity strategy against EU 2030 Biodiversity Strategy
```

### 双标准对照
```
按中美双标准审查这套图纸
Dual-standard review (China GB + US ADA) for this international project
```

---

## 📋 规范覆盖 / Standards Covered

<details>
<summary>🇨🇳 中国规范 / China Standards</summary>

- GB 55019 无障碍建设通用规范
- GB 55001/55002 结构安全规范
- CJJ 48 公园设计规范
- CJJ 75 城市道路绿化规划与设计规范
- GB 50420 城市绿地设计规范
- GB/T 51003 海绵城市建设评价标准
- DB 地方标准（北京/上海/深圳等）
- GB/T 47111-2026 公园城市建设评价指南

</details>

<details>
<summary>🇺🇸 美国规范 / US Standards</summary>

- ADA 2010 Standards（无障碍）
- PROWAG（公共通行权）
- LEED BD+C / O+M / ND
- ASLA Professional Practice Manual
- ASLA Climate Action Plan 2040
- USDA Plant Hardiness Zone Map
- ASCE 7（结构荷载）
- IBC 2021（建筑规范）
- IESNA RP-8（照明）
- NFPA 780（防雷）
- CPTED（犯罪预防设计）

</details>

<details>
<summary>🇪🇺 欧洲规范 / EU Standards</summary>

- European Landscape Convention (Florence Convention)
- IFLA Europe Common Training Framework (CTF)
- EU Green Deal / 2030 Biodiversity Strategy
- EU IAS Regulation (1143/2014)
- European Accessibility Act (EUAA) 2019/882
- BREEAM NC / Urban Masterplanning
- BS 5837（英国树木保护）
- FLL Guidelines（德国景观设计）
- CIE 115 / EN 13201（欧洲照明）

</details>

---

## ⚠️ 免责声明 / Disclaimer

**中国：** 本Skill输出仅供参考，不替代注册景观建筑师的职业判断和法律签字责任。景观设计总工签字意味着终身法律责任，使用者须独立核实所有输出内容。

**International:** This AI-assisted landscape analysis is provided for reference purposes only. It does not substitute for professional judgment by a licensed landscape architect (CLIA/IALA member). All design decisions must be reviewed and approved by a licensed professional in accordance with applicable state/national registration requirements.

---

## 🤝 贡献 / Contributing

欢迎提交PR改进规范内容、补充典型案例、修正错误！

Contributions welcome! Feel free to submit PRs to improve standards coverage, add typical cases, or fix errors.

1. Fork 本仓库
2. 创建分支：`git checkout -b feature/add-new-standards`
3. 提交：`git commit -m "Add: 新增XX规范"`
4. 推送：`git push origin feature/add-new-standards`
5. 创建Pull Request

---

## 📄 License

MIT License — 自由使用、修改、分发，保留原作者署名即可。

---

## 🌟 Star History

如果这个Skill对你有帮助，请给个 ⭐ Star！

If this Skill helps you, please give it a ⭐ Star!

---

*Built with ❤️ for landscape architects worldwide · 为全球景观建筑师而生*
