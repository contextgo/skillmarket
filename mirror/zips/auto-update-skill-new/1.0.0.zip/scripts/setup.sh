#!/bin/bash
# OpenClaw Auto-Updater Setup Script
# Sets up daily cron job for auto-updates

set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
UPDATE_SCRIPT="$SKILL_DIR/scripts/update.sh"
CRON_SCHEDULE="0 4 * * *"
CRON_CMD="cd $HOME/.openclaw/workspace && bash $UPDATE_SCRIPT"

echo "🔄 Setting up OpenClaw Auto-Updater..."

# Check if cron job already exists
if crontab -l 2>/dev/null | grep -q "openclaw-auto-updater"; then
    echo "⚠️ Auto-updater cron job already exists. Skipping setup."
else
    # Add cron job
    (crontab -l 2>/dev/null; echo "$CRON_SCHEDULE $CRON_CMD # openclaw-auto-updater") | crontab -
    echo "✅ Auto-updater cron job added successfully!"
fi

echo ""
echo "📋 Current cron jobs:"
crontab -l
