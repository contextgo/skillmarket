#!/bin/bash
# OpenClaw Auto-Updater Script（增强版）
# 优先用 skillhub upgrade 批量更新，失败回退到逐个双源更新
# 更新前自动备份，详细更新报告，支持凌晨静默更新+早间推送

set -e

WORKSPACE="$HOME/.openclaw/workspace"
LOCK_FILE="$WORKSPACE/skills/.skills_store_lock.json"
LOG_FILE="$WORKSPACE/AUTO_UPDATE_LOG.md"
UPDATE_NOTE="$WORKSPACE/.auto-update-note.txt"
BACKUP_DIR="$WORKSPACE/skills/.backups/$(date +%Y%m%d_%H%M%S)"
DATE=$(date "+%Y-%m-%d %H:%M:%S")

echo "🔄 Starting enhanced auto-update at $DATE" >> "$LOG_FILE"
mkdir -p "$BACKUP_DIR"

# ========== 初始化报告 ==========
REPORT="🔄 **Daily Auto-Update Complete ($DATE)**\n\n"
REPORT+="---\n\n"

# ========== 备份所有技能 ==========
echo "📦 Backing up all skills to $BACKUP_DIR" >> "$LOG_FILE"
for SLUG in $(jq -r '.skills | keys | .[]' "$LOCK_FILE" 2>/dev/null || echo ""); do
    if [ -d "$WORKSPACE/skills/$SLUG" ]; then
        cp -r "$WORKSPACE/skills/$SLUG" "$BACKUP_DIR/$SLUG.bak" 2>/dev/null || true
    fi
done

# ========== 尝试1：批量更新（优先） ==========
BULK_SUCCESS=0
echo "🚀 Trying bulk update with 'skillhub upgrade'" >> "$LOG_FILE"

if cd "$WORKSPACE" && skillhub upgrade 2>&1 | tee -a "$LOG_FILE"; then
    BULK_SUCCESS=1
    REPORT+="✅ **Bulk Update Successful**\n"
    REPORT+="   Command: skillhub upgrade\n\n"
else
    REPORT+="⚠️ **Bulk Update Failed**, falling back to per-skill update\n\n"
fi

# ========== 尝试2：逐个更新（如果批量失败） ==========
if [ $BULK_SUCCESS -eq 0 ]; then
    SKILLS=$(jq -r '.skills | keys | .[]' "$LOCK_FILE" 2>/dev/null || echo "")

    if [ -z "$SKILLS" ]; then
        REPORT+="⚠️ No skills found in .skills_store_lock.json\n"
    else
        TOTAL=$(echo "$SKILLS" | wc -l)
        SUCCESS=0
        FAILED=0
        SKIPPED=0

        REPORT+="📦 **Total Skills**: $TOTAL\n\n"

        for SLUG in $SKILLS; do
            echo "Processing skill: $SLUG" >> "$LOG_FILE"

            NAME=$(jq -r ".skills[\"$SLUG\"].name" "$LOCK_FILE" 2>/dev/null || echo "$SLUG")
            OLD_VERSION=$(jq -r ".skills[\"$SLUG\"].version" "$LOCK_FILE" 2>/dev/null || echo "unknown")
            OLD_SOURCE=$(jq -r ".skills[\"$SLUG\"].source" "$LOCK_FILE" 2>/dev/null || echo "unknown")
            OLD_ZIP_URL=$(jq -r ".skills[\"$SLUG\"].zip_url" "$LOCK_FILE" 2>/dev/null || echo "")

            UPDATE_SUCCESS=0
            USED_SOURCE=""
            ERROR_MSG=""

            # 尝试1：原源更新
            if [ -n "$OLD_ZIP_URL" ] && [ "$OLD_ZIP_URL" != "null" ]; then
                echo "  Trying original source: $OLD_SOURCE" >> "$LOG_FILE"
                if cd "$WORKSPACE" && skillhub install "$SLUG" --force 2>&1 | tee -a "$LOG_FILE"; then
                    UPDATE_SUCCESS=1
                    USED_SOURCE="$OLD_SOURCE"
                else
                    ERROR_MSG="Original source failed"
                fi
            fi

            # 尝试2：切换到 skillhub
            if [ $UPDATE_SUCCESS -eq 0 ]; then
                echo "  Falling back to skillhub" >> "$LOG_FILE"
                if cd "$WORKSPACE" && skillhub install "$SLUG" --force 2>&1 | tee -a "$LOG_FILE"; then
                    UPDATE_SUCCESS=1
                    USED_SOURCE="skillhub (fallback)"
                else
                    ERROR_MSG="Both sources failed"
                fi
            fi

            NEW_VERSION=$(jq -r ".skills[\"$SLUG\"].version" "$LOCK_FILE" 2>/dev/null || echo "unknown")
            NEW_SOURCE=$(jq -r ".skills[\"$SLUG\"].source" "$LOCK_FILE" 2>/dev/null || echo "unknown")

            CHANGELOG=""
            if [ -f "$WORKSPACE/skills/$SLUG/CHANGELOG.md" ]; then
                CHANGELOG=$(head -50 "$WORKSPACE/skills/$SLUG/CHANGELOG.md" | sed 's/^/    /')
            elif [ -f "$WORKSPACE/skills/$SLUG/SKILL.md" ]; then
                CHANGELOG=$(grep -A 20 "##" "$WORKSPACE/skills/$SLUG/SKILL.md" | head -30 | sed 's/^/    /')
            fi

            REPORT+="### 📌 $NAME ($SLUG)\n"
            if [ $UPDATE_SUCCESS -eq 1 ]; then
                SUCCESS=$((SUCCESS+1))
                if [ "$OLD_VERSION" != "$NEW_VERSION" ]; then
                    REPORT+="✅ **Updated**: $OLD_VERSION → $NEW_VERSION\n"
                    REPORT+="   Source: $USED_SOURCE\n"
                    if [ -n "$CHANGELOG" ]; then
                        REPORT+="   What's New:\n$CHANGELOG\n"
                    fi
                else
                    SKIPPED=$((SKIPPED+1))
                    REPORT+="⏭️ **Already Current**: $OLD_VERSION\n"
                fi
            else
                FAILED=$((FAILED+1))
                REPORT+="❌ **Failed**: $ERROR_MSG\n"
                REPORT+="   Tried: $OLD_SOURCE → skillhub\n"
            fi
            REPORT+="\n"
        done

        REPORT+="---\n\n"
        REPORT+="📊 **Summary**:\n"
        REPORT+="- Updated: $SUCCESS\n"
        REPORT+="- Already current: $SKIPPED\n"
        REPORT+="- Failed: $FAILED\n"
    fi
fi

REPORT+="\n- Backup: $BACKUP_DIR\n"

# ========== 保存报告用于早报推送 ==========
echo -e "$REPORT" > "$UPDATE_NOTE"

echo "✅ Enhanced auto-update completed at $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo -e "$REPORT" >> "$LOG_FILE"
echo "---" >> "$LOG_FILE"
