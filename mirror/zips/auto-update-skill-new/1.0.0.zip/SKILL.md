---
name: openclaw-auto-updater
description: "OpenClaw 专属自动更新技能，支持逐个技能双源更新（原源失败自动切换到 skillhub），更新前自动备份，详细更新报告（源信息、成功/失败、版本变化、功能说明），支持凌晨静默更新、早间推送报告，可灵活配置更新时间和推送时间。"
---

# OpenClaw Auto-Updater Skill

OpenClaw 专属自动更新技能，功能完善、安全可靠。

## 核心特性

1. **双源更新**：逐个技能更新，先试原源，失败自动切换到 skillhub
2. **更新前备份**：每次更新前自动备份当前技能到 `~/.openclaw/workspace/skills/.backups/`
3. **详细报告**：记录更新源、成功/失败、版本变化、功能说明（从 CHANGELOG.md/SKILL.md 读取）
4. **静默更新+早间推送**：凌晨1-6点更新不推送通知，早7点后通过早报一起推送
5. **灵活时间配置**：
   - 更新时间：通过 crontab 灵活设定（默认凌晨4点）
   - 推送时间：通过早报脚本灵活设定（默认早上8点）

## 安装

### 通过 skillhub 安装（推荐）

```bash
cd ~/.openclaw/workspace
skillhub install openclaw-auto-updater
```

### 手动安装

```bash
cd ~/.openclaw/workspace/skills
git clone https://github.com/your-username/openclaw-auto-updater.git
```

## 快速开始

运行 setup.sh 配置定时任务：

```bash
bash ~/.openclaw/workspace/skills/openclaw-auto-updater/scripts/setup.sh
```

默认配置：
- 每天凌晨4点：后台静默更新技能
- 每天早上8点：早报附带更新结果推送

## 手动使用

### 立即更新并生成报告

```bash
bash ~/.openclaw/workspace/skills/openclaw-auto-updater/scripts/update.sh
```

### 查看更新报告

报告保存在 `~/.openclaw/workspace/.auto-update-note.txt`（用于早报推送）和 `~/.openclaw/workspace/AUTO_UPDATE_LOG.md`（完整历史）。

## 定时任务配置

### 修改更新时间（执行时间）

编辑 crontab：

```bash
crontab -e
```

找到这一行，修改时间（例如改成凌晨3点）：

```
0 3 * * * cd /home/wangfeng/.openclaw/workspace && bash /home/wangfeng/.openclaw/workspace/skills/openclaw-auto-updater/scripts/update.sh # openclaw-auto-updater
```

**注意**：建议将更新时间设在凌晨1-6点之间，这段时间脚本会静默执行，不推送通知打扰休息。

### 修改推送时间（通知时间）

推送时间由你的早报脚本控制，修改早报脚本的 crontab 时间即可。

例如将早报时间改成早上7点：

```bash
crontab -e
```

找到早报脚本那一行，修改时间：

```
0 7 * * * /home/wangfeng/.openclaw/scripts/daily-morning-news.sh
```

### 禁用自动更新

```bash
crontab -l | grep -v "openclaw-auto-updater" | crontab -
```

## 早报推送集成

如果你有早报脚本，添加以下代码来集成更新报告：

```bash
UPDATE_NOTE="/home/wangfeng/.openclaw/workspace/.auto-update-note.txt"

if [ -f "$UPDATE_NOTE" ]; then
    CONTENT+="\n---\n"
    CONTENT+="$(cat "$UPDATE_NOTE")"
    rm "$UPDATE_NOTE"  # 发送后删除，避免重复推送
fi
```

## 文件结构

```
openclaw-auto-updater/
├── SKILL.md                    # 本文件
└── scripts/
    ├── setup.sh                # 配置定时任务
    └── update.sh               # 执行更新（增强版）
```

## 更新报告示例

```
🔄 **Daily Auto-Update Complete (2026-04-14 04:00:00)**

---

### 📌 Baidu Web Search (baidu-search)
✅ **Updated**: 1.0.0 → 1.1.0
   Source: skillhub
   What's New:
     ## 1.1.0
     - 支持百度搜索结果分类过滤
     - 添加搜索结果缓存机制

### 📌 Tavily Web Search (tavily-search)
⏭️ **Already Current**: 1.0.0

### 📌 Weather (weather)
❌ **Failed**: Both sources failed
   Tried: clawhub → skillhub

---

📊 **Summary**:
- Updated: 1
- Already current: 1
- Failed: 1
- Backup: /home/wangfeng/.openclaw/workspace/skills/.backups/20260414_040000
```

## 安全说明

1. 更新前自动备份所有技能，失败可手动回滚
2. 只从 skillhub 或原配置源下载，不执行任意代码
3. 更新结果只在早7点后推送，不打扰休息

## 故障排除

### 更新失败

1. 检查网络连接
2. 查看 `~/.openclaw/workspace/AUTO_UPDATE_LOG.md` 详细日志
3. 从备份目录手动回滚：`cp -r ~/.openclaw/workspace/skills/.backups/<timestamp>/<skill>.bak ~/.openclaw/workspace/skills/<skill>`

### 报告没有推送

1. 确认早报脚本已集成更新报告读取
2. 检查 `~/.openclaw/workspace/.auto-update-note.txt` 是否存在
3. 查看 `~/.openclaw/workspace/AUTO_UPDATE_LOG.md` 确认更新是否执行

## 许可证

MIT License
