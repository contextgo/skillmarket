# Stock Price Alert

股价异动实时提醒 — 对接行情接口、邮件通知与 Sonos 语音播报。

## 简介

Stock Price Alert 是一个 OpenClaw 自定义技能，帮助用户实时监控持仓股票的价格异动。当涨跌幅超过设定阈值时，自动通过邮件和 Sonos 扬声器语音播报发出提醒。

## 功能特性

- 📈 多标的批量行情轮询（Alpha Vantage / Tushare）
- ⚡ 涨跌幅阈值异动判定
- 📧 邮件异动提醒
- 🔊 Sonos 语音播报
- ⏱ 与 OpenClaw cron 集成，支持定时自动轮询

## 快速开始

1. 安装技能到 `skills/stock-price-alert/`
2. 配置 `config.json`（设置监控标的、阈值、通知渠道）
3. 设置 `STOCK_API_KEY` 环境变量
4. 运行 `bash scripts/fetch_quotes.sh` 测试行情获取
5. 配合 OpenClaw cron 设置定时轮询

## 详细文档

请参阅 [SKILL.md](SKILL.md) 获取完整文档。

## 许可证

本项目采用 CC BY-NC-SA 4.0 许可证。