#!/usr/bin/env bash
# fetch_quotes.sh — 批量获取股票最新报价
# 依赖: curl, jq
# 环境变量: STOCK_API_KEY, STOCK_API_PROVIDER (default: alphavantage), STOCK_SYMBOLS

set -euo pipefail

API_KEY="${STOCK_API_KEY:?STOCK_API_KEY is required}"
PROVIDER="${STOCK_API_PROVIDER:-alphavantage}"
SYMBOLS="${STOCK_SYMBOLS:-}"

# Load from config.json if no env override
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="${SCRIPT_DIR}/../config.json"

if [ -z "$SYMBOLS" ] && [ -f "$CONFIG" ]; then
  SYMBOLS=$(jq -r '.symbols | join(",")' "$CONFIG")
fi

if [ -z "$SYMBOLS" ]; then
  echo "[]" >&2
  exit 1
fi

result="["

IFS=',' read -ra SYM_ARRAY <<< "$SYMBOLS"
first=true

for sym in "${SYM_ARRAY[@]}"; do
  sym=$(echo "$sym" | xargs) # trim

  if [ "$PROVIDER" = "alphavantage" ]; then
    url="https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${sym}&apikey=${API_KEY}"
    raw=$(curl -sf "$url" 2>/dev/null || echo '{}')
    price=$(echo "$raw" | jq -r '.["Global Quote"]["05. price"] // empty')
    change_pct=$(echo "$raw" | jq -r '.["Global Quote"]["10. change percent"] // empty' | tr -d '%')
    ts=$(echo "$raw" | jq -r '.["Global Quote"]["07. latest trading day"] // empty')
  else
    # Placeholder for other providers
    echo "{\"error\":\"unsupported provider: $PROVIDER\"}" >&2
    continue
  fi

  if [ -n "$price" ]; then
    [ "$first" = true ] && first=false || result+=","
    result+="{\"symbol\":\"$sym\",\"price\":$price,\"change_pct\":${change_pct:-0},\"timestamp\":\"$ts\"}"
  fi

  # Rate limit: Alpha Vantage free tier = 5 calls/min
  if [ "${#SYM_ARRAY[@]}" -gt 5 ] && [ "$PROVIDER" = "alphavantage" ]; then
    sleep 12
  fi
done

result+="]"
echo "$result"