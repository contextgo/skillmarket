#!/usr/bin/env bash
# sonos_announce.sh — 通过 Sonos TTS 播报异动信息
# 依赖: sonos CLI (sonoscli)
# 用法: sonos_announce.sh --speaker "Office" --volume 25 --alerts '[...]'

set -euo pipefail

SPEAKER=""
VOLUME=""
ALERTS=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --speaker)  SPEAKER="$2"; shift 2 ;;
    --volume)   VOLUME="$2"; shift 2 ;;
    --alerts)   ALERTS="$2"; shift 2 ;;
    --text)     ALERTS="[{\"raw_text\":\"$2\"}]"; shift 2 ;;
    *) shift ;;
  esac
done

# Fallback to config.json
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="${SCRIPT_DIR}/../config.json"
if [ -z "$SPEAKER" ] && [ -f "$CONFIG" ]; then
  SPEAKER=$(jq -r '.sonos.speaker_name // empty' "$CONFIG")
  VOLUME=${VOLUME:-$(jq -r '.sonos.volume // 25' "$CONFIG")}
fi
SPEAKER="${SPEAKER:-Office}"
VOLUME="${VOLUME:-25}"

if [ -z "$ALERTS" ] || [ "$ALERTS" = "[]" ]; then
  echo "No alerts to announce." >&2
  exit 0
fi

# Build announcement text from alerts JSON
announce_text=$(echo "$ALERTS" | jq -r '
  if .[0].raw_text then .[0].raw_text
  else
    map(
      "\(.symbol) \(.direction) \(.change_pct)%，当前价格 \(.price) 美元"
    ) | join("。")
  end
')

echo "📢 Sonos announcement on '$SPEAKER' (vol $VOLUME): $announce_text"

# Set volume
sonos volume set "$VOLUME" --name "$SPEAKER" 2>/dev/null || true

# Use OpenClaw tts tool if available, otherwise try say/httpPlay
# Fallback: just print the message for the agent to use tts tool
echo "TTS_TEXT:$announce_text"