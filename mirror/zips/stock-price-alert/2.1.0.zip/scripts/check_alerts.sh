#!/usr/bin/env bash
# check_alerts.sh — 根据阈值筛选异动标的
# 输入: stdin JSON 数组 (fetch_quotes.sh 的输出)
# 环境变量: STOCK_THRESHOLD_PCT (default: 3.0)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="${SCRIPT_DIR}/../config.json"

THRESHOLD="${STOCK_THRESHOLD_PCT:-}"
if [ -z "$THRESHOLD" ] && [ -f "$CONFIG" ]; then
  THRESHOLD=$(jq -r '.threshold_pct // 3.0' "$CONFIG")
fi
THRESHOLD="${THRESHOLD:-3.0}"

input=$(cat)

echo "$input" | jq --arg th "$THRESHOLD" '
  map(select((.change_pct | tonumber) > ($th | tonumber) or (.change_pct | tonumber) < -(($th | tonumber))))
  | map(. + { direction: (if (.change_pct | tonumber) > 0 then "up" else "down" end) })
'