#!/usr/bin/env bash
# send_email.sh — 通过 SMTP 发送异动邮件
# 依赖: curl (for SMTP), 或由 agent 通过 Gmail 技能代发
# 用法: send_email.sh --alerts '[...]'

set -euo pipefail

ALERTS=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --alerts) ALERTS="$2"; shift 2 ;;
    *) shift ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="${SCRIPT_DIR}/../config.json"

RECIPIENTS=""
if [ -f "$CONFIG" ]; then
  RECIPIENTS=$(jq -r '.email.recipients | join(",")' "$CONFIG")
fi

if [ -z "$ALERTS" ] || [ "$ALERTS" = "[]" ]; then
  echo "No alerts to email." >&2
  exit 0
fi

# Build email body
subject="📊 股价异动提醒"
body=$(echo "$ALERTS" | jq -r '
  map(
    "• \(.symbol): \(.direction) \(.change_pct)%，现价 \(.price)"
  ) | join("\n")
')

echo "EMAIL_TO:$RECIPIENTS"
echo "EMAIL_SUBJECT:$subject"
echo "EMAIL_BODY:$body"

# Actual sending is delegated to the agent (Gmail skill / SMTP)
# The agent reads the above output and handles delivery.