---
name: stock-price-alert
description: 股价异动实时提醒 — 对接行情接口、邮件通知与 Sonos 语音播报
author: terrycarter1985
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["curl", "sonos"] },
        "install":
          [
            {
              "id": "go",
              "kind": "go",
              "module": "github.com/steipete/sonoscli/cmd/sonos@latest",
              "bins": ["sonos"],
              "label": "Install sonoscli (go)",
            },
          ],
      },
  }
---

# Stock Price Alert

实时监控股票价格异动，通过邮件和 Sonos 语音播报及时提醒。

## 使用场景

- 持仓股票出现涨跌幅超阈值时需要即时通知
- 盘中需要语音播报关键异动，避免错过交易窗口
- 希望通过 OpenClaw cron 定时轮询行情并自动告警

## 前置条件

1. **行情接口**：需配置 `STOCK_API_KEY` 环境变量（支持 Alpha Vantage / 聚宽等提供 REST 行情的服务）。默认使用 Alpha Vantage 的 `GLOBAL_QUOTE` 端点。
2. **邮件提醒**：需在 OpenClaw 配置中启用 SMTP 或使用 Gmail 技能发送邮件。
3. **Sonos 播报**：需网络内有可发现的 Sonos 扬声器，并安装 `sonos` CLI。
4. **cron 定时**：建议在交易时段设置每 1-5 分钟轮询一次。

## 配置

在技能目录下创建 `config.json`（或通过环境变量覆盖）：

```json
{
  "symbols": ["AAPL", "TSLA", "BABA"],
  "threshold_pct": 3.0,
  "api_provider": "alphavantage",
  "email": {
    "enabled": true,
    "recipients": ["user@example.com"]
  },
  "sonos": {
    "enabled": true,
    "speaker_name": "Office",
    "volume": 25
  },
  "poll_interval_sec": 120
}
```

| 字段 | 环境变量 | 说明 |
|------|---------|------|
| `symbols` | `STOCK_SYMBOLS` (逗号分隔) | 监控标的列表 |
| `threshold_pct` | `STOCK_THRESHOLD_PCT` | 涨跌幅阈值（百分比），默认 3.0 |
| `api_provider` | `STOCK_API_PROVIDER` | 行情源：`alphavantage`（默认）/ `tushare` |
| `email.enabled` | `STOCK_EMAIL_ENABLED` | 是否启用邮件提醒 |
| `email.recipients` | `STOCK_EMAIL_RECIPIENTS` | 收件人列表（逗号分隔） |
| `sonos.enabled` | `STOCK_SONOS_ENABLED` | 是否启用 Sonos 播报 |
| `sonos.speaker_name` | `STOCK_SONOS_SPEAKER` | Sonos 扬声器名称 |
| `sonos.volume` | `STOCK_SONOS_VOLUME` | 播报音量（0-100） |

## 工作流

### 1. 轮询行情

调用 `scripts/fetch_quotes.sh`，对 `config.json` 中每只标的请求最新报价，输出 JSON 数组：

```bash
bash scripts/fetch_quotes.sh
# → [{"symbol":"AAPL","price":182.52,"change_pct":3.4,"timestamp":"2026-05-07T03:40:00Z"}, ...]
```

### 2. 异动判定

调用 `scripts/check_alerts.sh`，将行情数据与阈值对比，筛选出超阈值标的：

```bash
bash scripts/check_alerts.sh <<< '[{"symbol":"AAPL","price":182.52,"change_pct":3.4}]'
# → [{"symbol":"AAPL","price":182.52,"change_pct":3.4,"direction":"up"}]
```

### 3. 派发提醒

- **邮件**：通过 Gmail 技能或 SMTP 发送异动摘要邮件。
- **Sonos 播报**：调用 `scripts/sonos_announce.sh`，将异动信息转为 TTS 并通过 Sonos 播放。

```bash
bash scripts/sonos_announce.sh --speaker "Office" --volume 25 \
  --text "AAPL 上涨 3.4%，当前价格 182.52 美元"
```

### 4. 典型 cron 配置

在 OpenClaw 中创建定时任务（交易时段每 2 分钟轮询）：

```
cron add --schedule "every 120s" --payload '{"kind":"agentTurn","message":"运行 stock-price-alert 技能，轮询行情并检查异动"}'
```

## 输入参数

通过 `config.json` 或环境变量传入（见上方配置表）。运行时也可临时指定标的：

```bash
STOCK_SYMBOLS="NVDA,AMD" bash scripts/fetch_quotes.sh
```

## 输出格式

所有脚本均输出 JSON，便于管道组合与 agent 解析。

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `scripts/fetch_quotes.sh` | 批量获取最新报价 |
| `scripts/check_alerts.sh` | 根据阈值筛选异动标的 |
| `scripts/sonos_announce.sh` | 通过 Sonos TTS 播报异动信息 |
| `scripts/send_email.sh` | 通过 SMTP 发送异动邮件 |

## 使用示例

**手动检查一次异动：**
```bash
cd ~/.openclaw/workspace/skills/stock-price-alert
quotes=$(bash scripts/fetch_quotes.sh)
alerts=$(bash scripts/check_alerts.sh <<< "$quotes")
if [ "$alerts" != "[]" ]; then
  bash scripts/sonos_announce.sh --speaker "Office" --alerts "$alerts"
  bash scripts/send_email.sh --alerts "$alerts"
fi
```

**通过 agent 自然语言触发：**
> "检查一下我的持仓有没有异动"

Agent 会调用对应脚本完成轮询 → 判定 → 通知全流程。

## 注意事项

- Alpha Vantage 免费版每分钟限 5 次请求，5 只以上标的建议加 `sleep 12` 或升级 API 套餐。
- Sonos TTS 依赖扬声器固件支持的 `httpPlay` 或第三方 TTS 代理；如不可用，可改用 OpenClaw `tts` 工具生成音频后推送。
- 非交易时段调用会返回上一个收盘价，不会触发误告警。

## 错误处理

| 错误 | 原因 | 处理 |
|------|------|------|
| `API limit reached` | 行情接口速率限制 | 降低轮询频率或升级套餐 |
| `no speaker found` | Sonos 扬声器不可达 | 检查网络或指定 `--ip` |
| `SMTP auth failed` | 邮件认证失败 | 检查邮箱凭据配置 |