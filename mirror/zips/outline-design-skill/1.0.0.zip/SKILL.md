---
name: outline-design-skill
description: >
  理解用户提供的素材，通过多轮问答生成场景化大纲，供mck-ppt-design-skill使用。
  支持高管汇报、内部共创、向下宣贯三个场景。
---

# 大纲设计 Skill (Outline Design Skill)

## 核心功能

1. **素材摄入**：读取并结构化用户提供的素材
2. **多轮问答**：5轮选择式问答，理解用户需求
3. **大纲生成**：生成场景化、内容详细的大纲

## 三场景支持

| 场景 | 用途 | 输出特点 |
| :-------- | :----- | :-------- |
| 高管汇报 | 向高管或投资人汇报 | 结论先行、数据支撑 |
| 内部共创 | 内部团队讨论 | 激发讨论、对齐假设 |
| 向下宣贯 | 向下属或执行层传达 | 执行导向、消除歧义 |

## 参考文件

- `skill-reference/问答策略.md` - 5轮问答策略
- `skill-reference/场景规则.md` - 场景规则
- `skill-reference/大纲格式.md` - 大纲格式规范
- `skill-reference/大纲模板.md` - 大纲模板（高管汇报场景）

## 使用方法

1. 提供素材文件
2. AI完成5轮问答
3. 生成Markdown格式大纲
4. 大纲可直接被第三方的mck-ppt-design-skill使用（https://github.com/likaku/Mck-ppt-design-skill）
