# Financial Goal Progress Tracker

## Overview

Tracks financial goal progress. This is a descriptive skill that provides frameworks and templates without executing real code.

## Safety
- No real code execution
- No external API calls
- No financial transactions
- Informational only

## Outputs
- Structured analysis
- Actionable recommendations
- Next steps checklist
