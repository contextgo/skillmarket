---
name: stock-comprehensive-analysis
description: '对A股股票进行多维度综合分析，涵盖主营亮点、基本面、技术面、资金面、估值、研报、风险和股性。当用户要求全面分析某只A股股票、了解其投资价值或风险时触发。Use when: "帮我分析XX股票", "全面了解XX公司", "XX股票值得投资吗". Calls tools: guessStockCode, stockBizHighlight, stockFunAnalysis, stockTechAnalysis, stockCapAnalysis, stockValuation, stockRepInsight, stockRiskWarning, stockFlexibility.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 综合股票分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

对用户指定的 A 股股票，按顺序调用多个 MCP 工具，从多维度生成完整的分析报告，包括：
- 主营业务与核心亮点
- 基本面（财务健康、盈利能力）
- 技术面（趋势、形态、信号）
- 资金面（主力动向、北向资金）
- 估值（PE/PB/PS 等横纵对比）
- 研报面（机构观点与评级统计）
- 风险扫雷（公司治理、财务风险）
- 股性分析（弹性、波动特征）

## 触发场景

- 用户问"帮我分析一下 XX 股票"
- 用户说"我想全面了解 XX 公司"
- 用户询问某支股票的投资价值或风险

## 执行步骤

### 第一步：解析股票代码

调用 `guessStockCode`，将用户输入的自然语言转换为标准股票代码与名称。

```json
调用工具: guessStockCode
参数: { "query": "<用户输入的股票名称或代码>" }
```

从返回结果中提取 `stockCode`（股票代码）和 `stockName`（股票名称），后续步骤均使用标准代码。

### 第二步：并行获取多维度数据

以下工具可**并行调用**以提升效率，`query` 参数均填入第一步得到的股票代码或名称：

| 工具名称 | 分析维度 |
|---|---|
| `stockBizHighlight` | 主营与亮点 |
| `stockFunAnalysis` | 基本面 |
| `stockTechAnalysis` | 技术面 |
| `stockCapAnalysis` | 资金面 |
| `stockValuation` | 估值面 |
| `stockRepInsight` | 研报面 |
| `stockRiskWarning` | 风险扫雷 |
| `stockFlexibility` | 股性分析 |

### 第三步：整合输出报告

1. **公司概况** —— 来自 `stockBizHighlight`
2. **基本面分析** —— 来自 `stockFunAnalysis`
3. **技术面分析** —— 来自 `stockTechAnalysis`
4. **资金面分析** —— 来自 `stockCapAnalysis`
5. **估值分析** —— 来自 `stockValuation`
6. **研报观点** —— 来自 `stockRepInsight`
7. **风险提示** —— 来自 `stockRiskWarning`
8. **股性特征** —— 来自 `stockFlexibility`
9. **综合结论** —— 综合以上内容，给出简短的投资参考意见，**不构成投资建议**

## 注意事项

- 若第一步未能解析出股票代码，请提示用户确认股票名称或提供准确代码。
- 各工具返回的 `data` 字段含有具体分析内容，`code` 为 0 表示成功。
- 最终结论须注明"以上内容仅供参考，不构成投资建议"。
