#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
无人机CAAC理论考试自测系统
基于03无人机CAAC理论考试题库2025修订版
"""

import random
import sys
import os
import re

# 尝试导入docx解析器
try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False


class ExamSystem:
    """无人机CAAC理论考试自测系统"""
    
    def __init__(self):
        self.question_bank_path = "/Users/xuwei/.copaw/workspaces/default/knowledge/03无人机CAAC理论考试题库2025修订版-633道题+答案(1).docx"
        self.questions = []
        self.selected_questions = []
        self.correct_count = 0
        self.incorrect_questions = []
        self.user_answers = []

    def load_question_bank(self):
        """加载题库"""
        if self.question_bank_path.endswith('.docx'):
            self.questions = self._parse_docx(self.question_bank_path)
        else:
            self.questions = self._parse_txt(self.question_bank_path)
        
        return len(self.questions)

    def _parse_docx(self, file_path):
        """解析DOCX格式题库"""
        if not HAS_DOCX:
            print("错误：需要安装 python-docx 库")
            print("请运行：pip install python-docx")
            return []
        
        questions = []
        doc = Document(file_path)
        
        i = 0
        paragraphs = [p.text.strip() for p in doc.paragraphs]
        
        while i < len(paragraphs):
            line = paragraphs[i]
            
            # 匹配题号开头 (如 "1." "2." 等)
            if re.match(r'^\d+\.', line):
                question_text = re.sub(r'^\d+\.\s*', '', line)
                options = []
                correct = None
                
                # 向后查找选项和答案
                j = i + 1
                while j < len(paragraphs):
                    next_line = paragraphs[j]
                    
                    # 匹配选项 (A、B、C、D)
                    opt_match = re.match(r'^([ABCD])[、\.．]\s*(.+)', next_line)
                    if opt_match:
                        options.append(f"{opt_match.group(1)}、{opt_match.group(2)}")
                        j += 1
                        continue
                    
                    # 匹配答案
                    ans_match = re.match(r'^答案[：:]\s*([ABCD])', next_line)
                    if ans_match:
                        correct = ans_match.group(1)
                        j += 1
                        continue
                    
                    # 遇到新题目，停止
                    if re.match(r'^\d+\.', next_line):
                        break
                    
                    # 跳过空行和题型标题
                    if not next_line or '单选题' in next_line or '多选题' in next_line:
                        j += 1
                        continue
                    
                    # 其他情况停止
                    break
                
                # 保存题目
                if question_text and len(options) >= 3:
                    questions.append({
                        "question": question_text,
                        "options": options,
                        "correct": correct
                    })
                
                i = j
            else:
                i += 1
        
        return questions

    def _parse_txt(self, file_path):
        """解析TXT格式题库"""
        questions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except UnicodeDecodeError:
            with open(file_path, 'r', encoding='gbk') as f:
                content = f.read()
        
        lines = content.strip().split("\n")
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            if line and re.match(r'^\d+\.', line):
                question_text = re.sub(r'^\d+\.\s*', '', line)
                options = []
                correct = None
                
                j = i + 1
                while j < len(lines):
                    next_line = lines[j].strip()
                    
                    opt_match = re.match(r'^([ABCD])[、\.．]\s*(.+)', next_line)
                    if opt_match:
                        options.append(f"{opt_match.group(1)}、{opt_match.group(2)}")
                        j += 1
                        continue
                    
                    ans_match = re.match(r'^答案[：:]\s*([ABCD])', next_line)
                    if ans_match:
                        correct = ans_match.group(1)
                        j += 1
                        continue
                    
                    if re.match(r'^\d+\.', next_line):
                        break
                    
                    j += 1
                
                if question_text and len(options) >= 3:
                    questions.append({
                        "question": question_text,
                        "options": options,
                        "correct": correct
                    })
                
                i = j
            else:
                i += 1
        
        return questions

    def select_random_questions(self, count=20):
        """随机选择题目"""
        if not self.questions:
            return None
        
        if len(self.questions) < count:
            count = len(self.questions)
        
        self.selected_questions = random.sample(self.questions, count)
        return self.selected_questions

    def process_user_answer(self, question_index, user_answer):
        """处理用户答案"""
        if question_index < 0 or question_index >= len(self.selected_questions):
            return False
        
        user_answer = user_answer.strip().upper()
        self.user_answers.append(user_answer)
        
        question = self.selected_questions[question_index]
        
        if question["correct"]:
            is_correct = user_answer == question["correct"]
            
            if is_correct:
                self.correct_count += 1
            else:
                self.incorrect_questions.append({
                    "question": question,
                    "user_answer": user_answer
                })
            
            return is_correct
        
        return None

    def get_result_summary(self):
        """获取结果统计"""
        total = len(self.selected_questions)
        correct = self.correct_count
        incorrect = total - correct
        percentage = round((correct / total) * 100, 1) if total > 0 else 0
        
        return {
            "total": total,
            "correct": correct,
            "incorrect": incorrect,
            "percentage": percentage
        }

    def get_incorrect_questions(self):
        """获取错题列表"""
        return self.incorrect_questions

    def reset(self):
        """重置考试状态"""
        self.selected_questions = []
        self.correct_count = 0
        self.incorrect_questions = []
        self.user_answers = []


def main():
    """主函数 - 用于测试"""
    exam = ExamSystem()
    
    print("=" * 50)
    print("   无人机CAAC理论考试自测系统")
    print("   基于2025修订版题库（633道题）")
    print("=" * 50)
    
    # 加载题库
    print("\n正在加载题库...")
    loaded_count = exam.load_question_bank()
    print(f"成功加载 {loaded_count} 道题目")
    
    # 统计有答案的题目
    with_answer = sum(1 for q in exam.questions if q["correct"])
    print(f"其中 {with_answer} 道题目有正确答案")
    
    # 测试随机选题
    print("\n随机抽取5道题目测试：")
    exam.select_random_questions(5)
    
    for i, q in enumerate(exam.selected_questions, 1):
        print(f"\n{i}. {q['question'][:50]}...")
        for opt in q['options']:
            print(f"   {opt}")
        print(f"   答案: {q['correct']}")


if __name__ == "__main__":
    main()