---
name: etf-analysis
description: '对指定ETF基金进行全面分析，涵盖基本信息、实时行情、技术面、基本面、业绩、底层资产、消息面及异动归因。当用户询问某ETF概况、是否值得买入或近期大涨大跌原因时触发。Use when: "分析沪深300ETF", "科创50ETF值得买吗", "这只ETF为什么大跌". Calls tools: guessFundCode, etfBasicInfo, etfLatestPrice, etfTechAnalysis, etfFunAnalysis, etfPerformance, etfUnderAssets, etfRelatedNews, etfPriceFluctReason.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# ETF 分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

围绕特定 ETF，提供以下维度分析：
- **基本信息**：规模、跟踪指数、费率、基金公司
- **实时行情**：最新价格、溢价折价率、成交量
- **技术面**：趋势信号、均线形态
- **基本面与估值**：跟踪指数估值水平、盈利情况
- **业绩数据**：近期收益率、同类排名
- **底层资产**：持仓构成、行业分布
- **消息面**：相关新闻与公告
- **异动归因**：价格波动原因解读

## 触发场景

- "帮我分析一下沪深300ETF"
- "科创50ETF值得买吗？"
- "XX ETF 最近为什么大跌？"
- "这只ETF的底层资产是什么？"

## 执行步骤

### 第一步：解析 ETF 代码

```json
调用工具: guessFundCode
参数: { "query": "<用户输入的ETF名称或代码>" }
```

### 第二步：综合 ETF 分析（并行调用）

```json
调用工具: etfBasicInfo
参数: { "query": "<ETF代码或名称>" }

调用工具: etfLatestPrice
参数: { "query": "<ETF代码或名称>" }

调用工具: etfTechAnalysis
参数: { "query": "<ETF代码或名称>" }

调用工具: etfFunAnalysis
参数: { "query": "<ETF代码或名称>" }

调用工具: etfPerformance
参数: { "query": "<ETF代码或名称>" }

调用工具: etfUnderAssets
参数: { "query": "<ETF代码或名称>" }

调用工具: etfRelatedNews
参数: { "query": "<ETF代码或名称>" }
```

### 第三步（按需）：异动归因

当用户询问 ETF 近期涨跌原因时：

```json
调用工具: etfPriceFluctReason
参数: {
  "query": "<ETF代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "3"
}
```

### 第四步：整合输出报告

| 章节 | 数据来源 |
|---|---|
| ETF 基本信息 | `etfBasicInfo` |
| 实时行情 | `etfLatestPrice` |
| 技术面分析 | `etfTechAnalysis` |
| 基本面与估值 | `etfFunAnalysis` |
| 业绩表现 | `etfPerformance` |
| 底层资产构成 | `etfUnderAssets` |
| 相关资讯 | `etfRelatedNews` |
| 异动归因（按需） | `etfPriceFluctReason` |

## 注意事项

- ETF 代码格式通常为 6 位数字，如 `510300`（沪深300ETF）。
- 场内 ETF 与场外联接基金代码不同，注意区分。
- 溢价率过高时买入场内 ETF 存在折价回归风险，需在结论中提示。
