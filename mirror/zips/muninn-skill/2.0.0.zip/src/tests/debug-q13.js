"use strict";
/**
 * Debug q13 - why is it pulling wrong memory?
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var index_js_1 = require("../storage/index.js");
function run() {
    return __awaiter(this, void 0, void 0, function () {
        var store, keyFacts, _i, keyFacts_1, fact, query, results;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log('🔍 Debugging q13\n');
                    store = new index_js_1.default('/tmp/debug-q13.db');
                    keyFacts = [
                        { content: 'Elev8Advisory is an AI-powered HR tool that helps small businesses create HR policies automatically', entities: ['Elev8Advisory'], salience: 0.8 },
                        { content: 'BrandForge is an AI-powered branding tool with $320 revenue', entities: ['BrandForge'], salience: 0.8 },
                        { content: 'Muninn is a memory system using SQLite storage and Nomic embeddings via Ollama, stores episodic/semantic/procedural memories', entities: ['Muninn'], salience: 0.8 },
                        { content: 'Current priority: Elev8Advisory first, then BrandForge (updated Feb 22)', entities: ['Elev8Advisory', 'BrandForge'], salience: 0.8 },
                        { content: 'The programme is scheduled to launch in Q3', entities: ['programme'], salience: 0.2 },
                    ];
                    _i = 0, keyFacts_1 = keyFacts;
                    _a.label = 1;
                case 1:
                    if (!(_i < keyFacts_1.length)) return [3 /*break*/, 4];
                    fact = keyFacts_1[_i];
                    return [4 /*yield*/, store.remember(fact.content, 'semantic', {
                            entities: fact.entities,
                            salience: fact.salience
                        })];
                case 2:
                    _a.sent();
                    _a.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4:
                    query = 'What projects is Phillip building and what are their current statuses?';
                    console.log("Query: \"".concat(query, "\"\n"));
                    return [4 /*yield*/, store.recall(query, { limit: 5 })];
                case 5:
                    results = _a.sent();
                    console.log('Top 5 results:');
                    results.forEach(function (r, i) {
                        console.log("".concat(i + 1, ". [sal: ").concat(r.salience, "] ").concat(r.content.slice(0, 80), "..."));
                    });
                    store.close();
                    return [2 /*return*/];
            }
        });
    });
}
run().catch(console.error);
