# Skill: better-memory

A structured, hierarchical, self-evolving memory management system for OpenClaw.

## Core Mechanism

1.  **L0 (SQL Pool):** Dynamic buffer for raw events (`error`, `experience`, `preference`).
2.  **L1 (Raw Facts):** Periodic extraction from L0 events into `memory/MEMORY.md`.
3.  **L2 (Paradigm/Workflows):** Periodic consolidation of multiple L1 entries.
4.  **L3 (Principles):** High-level abstraction of repeated L2 patterns.
5.  **Metabolism:** Automatic GC and conflict resolution based on limits.

## Configuration

Settings are managed in `config.json`:
- `distill_interval`: Seconds between SQL to L1 runs.
- `l1_limit`: Max entries for L1 section.
- `l2_limit`: Max entries for L2 section.
- `l3_limit`: Max entries for L3 section.

## Usage

Use `better-memory` to hook events:
- `log_event(type, content, context)`
- `run_distiller()` - Trigger manual L0 -> L1.
- `run_metabolism()` - Trigger internal consolidation.

## Automation

To enable automatic execution, schedule `runDistiller` and `runMetabolism` using OpenClaw's `cron` tool:

### Example Cron Setup (Daily)
Run the following commands to add the automated tasks:

```bash
# Add distillation job
openclaw cron add '{"name":"better-memory-distill","schedule":{"kind":"cron","expr":"0 0 * * *"},"payload":{"kind":"agentTurn","message":"better-memory.runDistiller()"}}'

# Add metabolism job
openclaw cron add '{"name":"better-memory-metabolism","schedule":{"kind":"cron","expr":"0 1 * * *"},"payload":{"kind":"agentTurn","message":"better-memory.runMetabolism()"}}'
```

## Heartbeat Setup

Alternatively, you can integrate tasks directly into your `HEARTBEAT.md` to run them during your regular check-ins:

```markdown
# Add this to your HEARTBEAT.md
# Run memory tasks
- better-memory.runDistiller()
- better-memory.runMetabolism()
```
