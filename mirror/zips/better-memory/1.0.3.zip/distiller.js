const { db } = require('./storage');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');

const memoryPath = path.resolve(__dirname, '../../memory/MEMORY.md');

function runDistiller() {
  db.all("SELECT * FROM L0_events WHERE status = 0", [], (err, rows) => {
    if (err || rows.length === 0) return;

    let content = rows.map(r => `[${r.event_type}] ${r.content} (${r.context})`).join('\n');
    
    // 抽象 L1 逻辑 (Placeholder for LLM call)
    let l1Entry = `\n# L1: 事实记忆\n- ${content}\n`;
    
    fs.appendFileSync(memoryPath, l1Entry);
    
    db.run("UPDATE L0_events SET status = 1 WHERE status = 0");
  });
}

module.exports = { runDistiller };
