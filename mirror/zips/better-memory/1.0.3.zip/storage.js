const sqlite3 = require('sqlite3').verbose();
const path = require('path');
// Use path.join to ensure database is created in the skill directory or a predictable location
const dbPath = path.join(__dirname, 'memory_stream.db');
const db = new sqlite3.Database(dbPath);

// Initialize table on load
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS L0_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT,
    content TEXT,
    context TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    status INTEGER DEFAULT 0
  )`);
});

function log_event(type, content, context) {
  db.run("INSERT INTO L0_events (event_type, content, context) VALUES (?, ?, ?)", [type, content, context], (err) => {
    if (err) console.error("Better-Memory Log Error:", err);
  });
}

module.exports = { log_event, db };
