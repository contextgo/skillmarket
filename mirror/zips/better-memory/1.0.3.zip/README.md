# Better-Memory

A structured, hierarchical, self-evolving memory management system for OpenClaw.

## Core Mechanism

1. **L0 (SQL Pool):** Dynamic buffer for raw events (`error`, `experience`, `preference`).
2. **L1 (Raw Facts):** Periodic extraction from L0 events into `memory/MEMORY.md`.
3. **L2 (Paradigm/Workflows):** Periodic consolidation of multiple L1 entries.
4. **L3 (Principles):** High-level abstraction of repeated L2 patterns.
5. **Metabolism:** Automatic GC and conflict resolution based on limits.

## Installation

1. Clone this repository into your OpenClaw workspace:
   `git clone https://github.com/fuuuuujichaos/better-memory.git`
2. Run `npm install` inside the directory.

## Configuration

Settings are managed in `config.json`:
- `distill_interval`: Seconds between SQL to L1 runs.
- `l1_limit`: Max entries for L1 section.
- `l2_limit`: Max entries for L2 section.
- `l3_limit`: Max entries for L3 section.
