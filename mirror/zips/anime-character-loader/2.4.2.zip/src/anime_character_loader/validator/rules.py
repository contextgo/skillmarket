"""Validation rules scaffold."""
