"""Validation components."""
