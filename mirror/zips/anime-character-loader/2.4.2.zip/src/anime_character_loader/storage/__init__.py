"""Storage and persistence helpers."""
