"""Jikan source adapter scaffold."""
