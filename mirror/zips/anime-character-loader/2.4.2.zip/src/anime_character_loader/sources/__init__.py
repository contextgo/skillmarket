"""External source integrations."""
