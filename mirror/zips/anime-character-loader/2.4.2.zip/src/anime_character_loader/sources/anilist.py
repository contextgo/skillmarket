"""AniList source adapter scaffold."""
