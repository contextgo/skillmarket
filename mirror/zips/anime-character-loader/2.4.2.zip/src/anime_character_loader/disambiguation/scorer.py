"""Disambiguation scorer scaffold."""
