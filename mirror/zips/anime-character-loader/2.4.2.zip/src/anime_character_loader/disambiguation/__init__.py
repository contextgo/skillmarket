"""Disambiguation components."""
