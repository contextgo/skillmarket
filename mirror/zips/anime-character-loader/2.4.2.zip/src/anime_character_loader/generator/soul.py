"""SOUL generator scaffold."""
