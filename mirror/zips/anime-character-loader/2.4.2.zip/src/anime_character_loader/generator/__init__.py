"""SOUL generation components."""
