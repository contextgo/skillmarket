---
name: api-contract
description: Web 接口契约，包含 DTO/VO 定义与异常处理。
---

# API Design Contract

<api_rules>
    <controller>
        <rule>使用 `@RestController` 和 `@RequestMapping`。</rule>
        <rule>
            HTTP Method 语义要准确：
            - GET: 查询
            - POST: 新增/复杂查询
            - PUT: 全量修改
            - DELETE: 删除
        </rule>
        <rule>如果之前的 Controller 接口中有使用 `@Log` 来标记日志，则需要模仿之前的进行添加；如果没有则无需添加。</rule>
    </controller>

    <response_format>
        <rule>
            所有接口必须返回统一包装类 `HttpResult<T>`。
            字段包含：`code` (int), `msg` (String), `data` (T)。
            需要查看 `HttpResult<T>` 实体中具体的成功和失败的方法来使用。
        </rule>
    </response_format>

    <exception_handling>
        <rule>
            禁止在 Controller 中 try-catch。
            异常统一抛出，由 `@RestControllerAdvice` 全局异常处理器捕获并转换输出。
        </rule>
    </exception_handling>
</api_rules>
