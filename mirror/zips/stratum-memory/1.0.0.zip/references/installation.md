# Stratum-Memory Installation Guide (v1.1)

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8 cores |
| RAM | 8GB | 16GB |
| Disk Space | 20GB free | 50GB free |

The installer auto-detects your specs and recommends Ollama or API mode.

---

## Embedding Backend Selection

| Backend | When to Use | How to Set Up |
|---------|-------------|---------------|
| Ollama (recommended) | 8GB+ RAM, 8+ CPU cores | `ollama serve` + `ollama pull nomic-embed-text` |
| OpenAI API | Low-end hardware | `set OPENAI_API_KEY=your-key` |

**Auto-detection**: `paths.py` automatically detects which backend to use.

---

## Step 1: Windows — Run install.bat

```powershell
# Run as Administrator
install.bat
```

The installer will:
1. Check system specs (CPU/RAM/disk)
2. Detect Ollama availability
3. If Ollama not found:
   - Good specs → ask to install Ollama or use API
   - Low specs → recommend API mode
4. Install Python dependencies
5. Build vector indices

---

## Step 2: WSL/Ubuntu

```bash
# 1. Install Ollama (if meeting requirements)
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull nomic-embed-text

# 2. Install Python dependencies
pip install faiss-cpu requests python-docx

# 3. Build indices
python scripts/build_index.py
```

---

## Step 3: API Mode Setup (if Ollama not used)

```powershell
# Windows
set OPENAI_API_KEY=your-key
set OPENAI_API_BASE=https://api.openai.com/v1
set EMBEDDING_MODEL=text-embedding-3-small
python scripts/build_index.py
```

```bash
# Linux/WSL
export OPENAI_API_KEY=your-key
export OPENAI_API_BASE=https://api.openai.com/v1
export EMBEDDING_MODEL=text-embedding-3-small
python scripts/build_index.py
```

---

## Step 4: Verify Installation

```bash
# Check system status
python scripts/system_status.py

# Test search
python scripts/vector_search.py search "test query"

# Check Decision Log
python scripts/decision_log.py check
```

---

## Cron Tasks

| Time | Task | Command |
|------|------|---------|
| 12:00 | Index health check | `python scripts/vector_search.py status` |
| 18:00 | Dual index rebuild | `python scripts/build_index.py` |
| 18:00 | Decision Log quota check | `python scripts/decision_log.py check` |
| 23:00 | L0 session archive | `python scripts/archive_sessions.py` |
| 23:00 | User operation log | `python scripts/user_oplog.py weekly/monthly` |

---

## Troubleshooting

**Q: Ollama connection fails?**
A: Use `http://127.0.0.1:11434` (not localhost — avoids IPv6 issues)

**Q: Index build is slow?**
A: Normal for CPU-only. ~1700 chunks takes 25-40 minutes.

**Q: Low-end system?**
A: Set `OPENAI_API_KEY` env var and use API mode instead.

**Q: How to switch between Ollama and API?**
A: Ollama running → uses Ollama automatically. Ollama not running → uses API if key is set.

**Q: Path configuration?**
A: No manual config needed. Scripts auto-detect workspace from openclaw.json.
