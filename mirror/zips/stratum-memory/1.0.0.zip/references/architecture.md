# Stratum-Memory Architecture (v1.1)

**4+1+1 Architecture: Four-Layer Memory + External Knowledge Base + Dual Vector Indices**

Version: 1.1
Date: 2026-04-27
Compatible: OpenClaw 2026.04.23+

---

## Overview

Stratum-Memory is designed specifically for OpenClaw AI assistants. It solves five core problems:

| Problem | Solution |
|---------|----------|
| Memory degrades over time | L0-L3 tiered storage |
| Context grows too long | Semantic search extracts |
| Decisions are forgotten | Decision Log real-time recording |
| Can't find historical info | Vector index sub-second search |
| New session starts from scratch | L3 permanent persona |

---

## Architecture: 4 + 1 + 1

```
┌──────────────────────────────────────────────────────┐
│              Stratum-Memory (4+1+1)                   │
├──────────────────────────────────────────────────────┤
│  4-Layer Memory Architecture (Storage)               │
│  ├── L0: Raw Session Archive  (200KB/file)           │
│  ├── L1: Decision Log Decision Records (100KB/file)           │
│  ├── L2: Scene Chunks        (200KB/chunk)           │
│  └── L3: User Persona        (50KB total)            │
├──────────────────────────────────────────────────────┤
│  User Operation Log (辅助系统)                        │
│  ├── memory/user_operation_logs/ (200KB/file, auto-split) │
│  ├── Weekly Decision Extraction                       │
│  └── Monthly Summary (Word Export)                   │
├──────────────────────────────────────────────────────┤
│  +1 External Knowledge Base                           │
│  └── knowledge-repo/  (products, policies, FAQ)       │
├──────────────────────────────────────────────────────┤
│  +1 Dual Vector Index (Search Engine)                │
│  ├── memory_index.faiss    (personal memory)          │
│  └── knowledge_index.faiss (business knowledge)       │
└──────────────────────────────────────────────────────┘
```

### Embedding Backend Selection

**Automatic detection** — the system selects based on your hardware:

| Backend | When Used | Requirements |
|---------|-----------|-------------|
| Ollama (default) | 8GB+ RAM, 8+ cores | Local, free, private |
| OpenAI API | Low-end systems or API preferred | API key + network |

---

## Four-Layer Memory Architecture

### L0 — Raw Session Layer
- **Role**: Complete preservation of daily conversations
- **Storage**: `memory/sessions/`
- **Quota**: 200KB per file, auto-split when exceeded
- **Naming**: `main-{date}-{time}-{session_id[:8]}-part{#}.md`
- **Timing**: Auto-archive daily at 23:00 via cron

### L1 — Decision Log Record Layer
- **Role**: Real-time recording of decisions, facts, preferences, numbers
- **Storage**: `memory/Decision Log-*.md`
- **Quota**: 100KB per file, auto-creates new file when full
- **Naming**: `Decision Log-YYYY-MM-DD-##.md` (## = sequence, 01 = latest)
- **Triggers**:
  - Corrections: "It's X, not Y"
  - Proper nouns: names, company/product names
  - Preferences: "I prefer X over Y"
  - Decisions: "Let's do X" / "Confirm using X"
  - Numbers: amounts, dates, ratios

### L2 — Scene Chunk Layer
- **Role**: Memory organized by project/scenario
- **Storage**: `memory/projects/`
- **Quota**: 200KB per chunk
- **Naming**: `{project}-{date}-{seq}.md`

### L3 — User Persona Layer
- **Role**: Long-term identity and preferences
- **Storage**: Workspace root
- **Quota**: 50KB total
- **Files**: `MEMORY.md`, `SOUL.md`, `USER.md`

---

## External Knowledge Base (+1)

- **Storage**: `knowledge-repo/` or `本盘knowledge-repo/`
- **Content**: Products, policies, FAQs, scripts, processes
- **Access**: Searched via vector index only
- **Update**: Manually maintained, indexed periodically

---

## Dual Vector Indices (+1)

### memory_index.faiss
- **Content**: MEMORY.md + all memory/ files
- **Use**: Finding decisions, preferences, context
- **Typical size**: 1500-2000 chunks

### knowledge_index.faiss
- **Content**: All files in knowledge-repo/
- **Use**: Product search, policy lookup
- **Typical size**: 200-500 chunks

---

## Path Auto-Detection

**All scripts auto-detect workspace from openclaw.json** — no manual path editing needed.

`scripts/paths.py` handles:
1. Reads `workspace` field from openclaw.json
2. Falls back to script-relative path
3. Detects Ollama availability
4. Selects appropriate embedding backend

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8 cores |
| RAM | 8GB | 16GB |
| Disk | 20GB free | 50GB free |

**Installer auto-detects specs and recommends Ollama vs API mode.**

---

## Technical Stack

- **Embedding**: Ollama `nomic-embed-text` (768d) OR OpenAI-compatible API
- **Vector DB**: FAISS CPU
- **Storage**: Pure local files
- **Compatibility**: OpenClaw 2026.04.23+
