---
name: stratum-memory
description: 地层记忆系统 — Stratum-Memory (4+1+1) 四层记忆 + 外挂知识库 + 双向量索引。适用于 OpenClaw 2026.04.23+ 版本。解决 AI 智能体长期运行后的记忆衰退、上下文膨胀、决策遗忘等核心问题。当需要安装记忆系统、新智能体初始化、恢复记忆能力、或需要向团队介绍记忆系统架构时触发。核心组件：L0原始对话存档 / L1 Decision Log决策记录 / L2场景分块 / L3用户画像 / knowledge-repo外部知识库 / memory_index + knowledge_index 双索引。支持 Ollama（推荐）或 OpenAI API 两种嵌入后端。
---

# Stratum-Memory (4+1+1)

**Four-Layer Memory + External Knowledge Base + Dual Vector Indices**

## System Overview

Stratum-Memory solves 5 core problems of long-running AI assistants:

| Problem | Solution |
|---------|----------|
| Memory degrades over time | L0-L3 tiered storage |
| Context grows too long | Semantic search, not full load |
| Decisions are forgotten | Decision Log real-time recording |
| Can't find historical info | Vector index sub-second search |
| New session starts from scratch | L3 permanent persona |

## Architecture: 4 + 1 + 1

```
4-Layer Memory (Storage)     +1 External KB      +1 Dual Index
├── L0: Raw Sessions         knowledge-repo/  →  memory_index.faiss
├── L1: Decision Log Records                              knowledge_index.faiss
├── L2: Scene Chunks
└── L3: User Persona
```

## Core Scripts

| Script | Purpose |
|--------|---------|
| `system_status.py` | View full system status (all layers + indices) |
| `build_index.py` | Build both vector indices |
| `vector_search.py` | Search dual indices |
| `decision_log.py` | Manage L1 Decision Log records |
| `scene_manager.py` | Manage L2 scene chunks |
| `persona_manager.py` | Manage L3 persona files |
| `archive_sessions.py` | Archive L0 sessions |
| `user_oplog.py` | User operation log with weekly/monthly summaries |

## System Requirements

| Item | Minimum | Recommended |
|------|---------|-------------|
| CPU | 4 cores | 8 cores |
| RAM | 8GB | 16GB |
| Disk | 20GB free | 50GB free |

## Embedding Backends

**Option 1: Ollama (Recommended)**
- Local, free, privacy-friendly
- Requires: Ollama running + `nomic-embed-text` model
- Better for: Low-volume, sensitive data

**Option 2: OpenAI API**
- Cloud-based, requires API key
- Set env vars: `OPENAI_API_KEY`, `OPENAI_API_BASE`, `EMBEDDING_MODEL`
- Better for: High-volume, low-end hardware

## Quick Commands

```bash
# View system status (all components)
python scripts/system_status.py

# Build indices (~30 min for 1700+ chunks)
python scripts/build_index.py

# Search
python scripts/vector_search.py search "汪继英贷款"

# Decision Log check
python scripts/decision_log.py check

## Detailed Documents

- **Architecture**: See `references/architecture.md`
- **Installation**: See `references/installation.md`
- **System Status**: See `scripts/system_status.py`

## Path Configuration

All scripts auto-detect workspace from `openclaw.json`. No manual path editing needed. The `scripts/paths.py` file handles:
1. Reading `workspace` from `openclaw.json`
2. Falling back to script-relative path
3. Selecting Ollama or API embedding backend automatically
