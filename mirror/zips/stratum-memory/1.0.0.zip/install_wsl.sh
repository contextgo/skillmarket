@echo off
REM Stratum-Memory WSL/Ubuntu Installer

echo ========================================
echo Stratum-Memory Installation (WSL/Ubuntu)
echo ========================================
echo.

REM Check Python
python3 --version >nul 2>&1
if [ $? -ne 0 ]; then
    echo [ERROR] Python3 not found. Please install Python 3.10+ first.
    echo   sudo apt update && sudo apt install python3 python3-pip
    exit 1
fi
echo [OK] Python3 found

REM Install Ollama
echo.
echo [INSTALL] Installing Ollama...
curl -fsSL https://ollama.ai/install.sh | sh
if [ $? -eq 0 ]; then
    echo [OK] Ollama installed
    echo [DOWNLOAD] Pulling embedding model...
    ollama pull nomic-embed-text
else
    echo [WARNING] Ollama installation may have failed. Check https://ollama.ai
fi

REM Install Python dependencies
echo.
echo [INSTALL] Installing Python dependencies...
pip3 install faiss-cpu requests python-docx
if [ $? -ne 0 ]; then
    echo [ERROR] pip install failed.
    exit 1
fi
echo [OK] Dependencies installed

REM Initialize directories
echo.
echo [SETUP] Creating directory structure...
mkdir -p memory/sessions memory/projects vector_store
echo [OK] Directories created

REM Build indices
echo.
echo [BUILD] Building vector indices...
echo This will take 25-40 minutes for ~1900 chunks.
python3 scripts/build_index.py

echo.
echo ========================================
echo Installation complete!
echo ========================================
echo.
echo Next steps:
echo 1. Edit scripts/paths.py to set your WORKSPACE path
echo 2. Set up cron tasks (see references/installation.md)
echo.
pause
