"""
Stratum-Memory: Build Vector Indices
Supports both Ollama and API-based embedding backends.
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import os
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths_config import (
    WORKSPACE, VECTOR_STORE, LAYER_MEMORY, LAYER_KNOWLEDGE,
    OLLAMA_URL, EMBED_MODEL, EMBEDDING_BACKEND
)

import json
import numpy as np
import faiss

os.makedirs(VECTOR_STORE, exist_ok=True)

# ============================================================
# Embedding backends
# ============================================================
def get_embedding_ollama(text):
    """Get embedding from Ollama."""
    import requests
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": text},
        timeout=60
    )
    response.raise_for_status()
    return np.array(response.json()["embedding"], dtype=np.float32)

def get_embedding_api(text):
    """Get embedding from OpenAI-compatible API (configurable)."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
    model = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")

    if not api_key:
        raise RuntimeError(
            "API mode selected but OPENAI_API_KEY is not set. "
            "Set it via: set OPENAI_API_KEY=your-key"
        )

    import requests
    response = requests.post(
        f"{api_base}/embeddings",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={"input": text, "model": model},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()
    return np.array(data["data"][0]["embedding"], dtype=np.float32)

def get_embedding(text):
    """Route to appropriate backend."""
    if EMBEDDING_BACKEND == "ollama":
        return get_embedding_ollama(text)
    else:
        return get_embedding_api(text)

# ============================================================
# Batch embeddings
# ============================================================
def get_embeddings_batch(texts, progress_callback=None):
    embeddings = []
    total = len(texts)
    for i, text in enumerate(texts):
        try:
            emb = get_embedding(text)
            embeddings.append(emb)
        except Exception as e:
            print(f"  Error embedding {i+1}: {e}", flush=True)
            # Use zero vector as fallback
            dim = 768 if EMBEDDING_BACKEND == "ollama" else 1536
            embeddings.append(np.zeros(dim, dtype=np.float32))
        if progress_callback:
            progress_callback(i + 1, total)
        elif (i + 1) % 50 == 0:
            print(f"  Embedded {i+1}/{total}", flush=True)
    return np.array(embeddings, dtype=np.float32)

# ============================================================
# Document scanning
# ============================================================
def scan_docs(sources, chunk_size=500):
    docs = []
    for source in sources:
        if not os.path.exists(source):
            print(f"[WARN] Source not found: {source}", flush=True)
            continue
        if os.path.isfile(source):
            docs.extend(scan_file(source, chunk_size))
        else:
            for root, dirs, files in os.walk(source):
                dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', '__pycache__']]
                for f in files:
                    if f.endswith(('.md', '.txt')):
                        path = os.path.join(root, f)
                        docs.extend(scan_file(path, chunk_size))
    return docs

def scan_file(path, chunk_size):
    docs = []
    try:
        with open(path, 'r', encoding='utf-8') as fp:
            content = fp.read()
    except:
        try:
            with open(path, 'r', encoding='gbk') as fp:
                content = fp.read()
        except:
            return docs
    rel_path = os.path.relpath(path, WORKSPACE)
    for i in range(0, len(content), chunk_size):
        chunk = content[i:i+chunk_size].strip()
        if chunk:
            docs.append({
                "path": path,
                "rel_path": rel_path,
                "chunk_idx": i // chunk_size,
                "content": chunk,
                "char_count": len(chunk)
            })
    return docs

# ============================================================
# Index building
# ============================================================
def build_index(layer):
    print(f"\n[INDEX] Building: {layer['name']}", flush=True)
    docs = scan_docs(layer["sources"])
    print(f"[INDEX] Found {len(docs)} chunks", flush=True)
    if not docs:
        print(f"[INDEX] No docs, skipping", flush=True)
        return 0
    texts = [d["content"] for d in docs]
    print(f"[INDEX] Generating embeddings ({EMBEDDING_BACKEND})...", flush=True)
    embeddings = get_embeddings_batch(texts)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    faiss.write_index(index, layer["index_file"])
    with open(layer["meta_file"], 'w', encoding='utf-8') as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)
    print(f"[INDEX] Done: {len(docs)} chunks, dim={dim}", flush=True)
    return len(docs)

def build_all():
    print("=" * 50, flush=True)
    print("Stratum-Memory - Dual Vector Index Build", flush=True)
    print(f"Backend: {EMBEDDING_BACKEND}", flush=True)
    print("=" * 50, flush=True)
    total = 0
    total += build_index(LAYER_MEMORY)
    total += build_index(LAYER_KNOWLEDGE)
    print(f"\n[DONE] Total: {total} chunks indexed", flush=True)

if __name__ == "__main__":
    build_all()
