"""
Stratum-Memory: Vector Search
Dual-layer semantic search with Ollama or API backend.
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import os
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths_config import (
    WORKSPACE, VECTOR_STORE, LAYER_MEMORY, LAYER_KNOWLEDGE,
    OLLAMA_URL, EMBED_MODEL, EMBEDDING_BACKEND
)

import json
import numpy as np
import faiss

def get_embedding(text):
    if EMBEDDING_BACKEND == "ollama":
        import requests
        response = requests.post(
            f"{OLLAMA_URL}/api/embeddings",
            json={"model": EMBED_MODEL, "prompt": text},
            timeout=60
        )
        response.raise_for_status()
        return np.array(response.json()["embedding"], dtype=np.float32)
    else:
        api_key = os.environ.get("OPENAI_API_KEY", "")
        api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
        model = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")
        import requests
        response = requests.post(
            f"{api_base}/embeddings",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"input": text, "model": model},
            timeout=30
        )
        response.raise_for_status()
        data = response.json()
        return np.array(data["data"][0]["embedding"], dtype=np.float32)

def search_layer(layer, query, top_k=5):
    if not os.path.exists(layer["index_file"]):
        return []
    index = faiss.read_index(layer["index_file"])
    with open(layer["meta_file"], 'r', encoding='utf-8') as f:
        docs = json.load(f)
    try:
        query_emb = get_embedding(query).reshape(1, -1)
    except Exception as e:
        print(f"Search error: {e}", flush=True)
        return []
    D, I = index.search(query_emb, min(top_k, len(docs)))
    results = []
    for distance, doc_idx in zip(D[0], I[0]):
        if doc_idx < len(docs):
            doc = docs[doc_idx]
            results.append({
                "distance": float(distance),
                "path": doc["path"],
                "rel_path": doc["rel_path"],
                "content": doc["content"]
            })
    return results

def search(query, top_k=5):
    print(f"\n[SEARCH] Query: {query}", flush=True)
    results = {"query": query, "memory": [], "knowledge": []}
    print(f"[SEARCH] Backend: {EMBEDDING_BACKEND}", flush=True)
    print("[SEARCH] Personal memory layer...", flush=True)
    results["memory"] = search_layer(LAYER_MEMORY, query, top_k)
    print(f"[SEARCH]   Found {len(results['memory'])} results", flush=True)
    print("[SEARCH] Business knowledge layer...", flush=True)
    results["knowledge"] = search_layer(LAYER_KNOWLEDGE, query, top_k)
    print(f"[SEARCH]   Found {len(results['knowledge'])} results", flush=True)

    out_path = os.path.join(VECTOR_STORE, 'search_results.txt')
    lines = [f"Query: {query}", f"Backend: {EMBEDDING_BACKEND}", f"Memory: {len(results['memory'])} results", f"Knowledge: {len(results['knowledge'])} results"]
    for r in results['memory']:
        lines.append(f"  [{r['distance']:.1f}] {r['rel_path']}")
        lines.append(f"    {r['content'][:150].replace(chr(10), ' ')}")
    for r in results['knowledge']:
        lines.append(f"  [{r['distance']:.1f}] {r['rel_path']}")
        lines.append(f"    {r['content'][:150].replace(chr(10), ' ')}")
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    for line in lines[:30]:
        print(line)
    print(f"\nFull results: {out_path}")
    return results

def status():
    print("Vector Index Status:", flush=True)
    for layer in [LAYER_MEMORY, LAYER_KNOWLEDGE]:
        idx_exists = os.path.exists(layer["index_file"])
        meta_exists = os.path.exists(layer["meta_file"])
        chunks = 0
        if meta_exists:
            with open(layer["meta_file"], 'r', encoding='utf-8') as f:
                chunks = len(json.load(f))
        print(f"  {layer['name']}: {'OK' if idx_exists else 'MISSING'} ({chunks} chunks)", flush=True)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: vector_search.py build|search <query>|status")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "build":
        from build_index import build_all
        build_all()
    elif cmd == "search":
        if len(sys.argv) < 3:
            print("Usage: vector_search.py search <query>")
            sys.exit(1)
        search(sys.argv[2])
    elif cmd == "status":
        status()
    else:
        print(f"Unknown: {cmd}")
