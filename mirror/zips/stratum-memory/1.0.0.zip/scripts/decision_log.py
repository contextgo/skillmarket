"""
Stratum-Memory: Decision Log Manager
Manages L1 Decision Log (decision records layer).
Auto-creates new files when quota exceeded.
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

import os
import json
import glob
from datetime import datetime

# Auto-detect paths relative to script location
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.path.dirname(SCRIPT_DIR)
MEMORY_DIR = os.path.join(WORKSPACE, "memory")
DECISION_LOG_QUOTA = 100 * 1024  # 100KB per decision log file

os.makedirs(MEMORY_DIR, exist_ok=True)

def get_latest_log():
    """Find the latest active decision log file (LOG-YYYY-MM-DD-01.md)"""
    pattern = os.path.join(MEMORY_DIR, "LOG-*-01.md")
    files = sorted(glob.glob(pattern), reverse=True)
    if files:
        return files[0]
    # No log exists, create new one for today
    today = datetime.now().strftime("%Y-%m-%d")
    return os.path.join(MEMORY_DIR, f"LOG-{today}-01.md")

def log_path_for_date(date_str, seq=1):
    """Get decision log path for a given date and sequence number."""
    return os.path.join(MEMORY_DIR, f"LOG-{date_str}-{seq:02d}.md")

def get_current_log_size():
    """Get size of current active decision log file."""
    log_file = get_latest_log()
    if os.path.exists(log_file):
        return os.path.getsize(log_file)
    return 0

def create_new_log(reason=""):
    """Create a new decision log file with incremented sequence."""
    today = datetime.now().strftime("%Y-%m-%d")
    # Find next sequence number
    seq = 1
    while os.path.exists(log_path_for_date(today, seq)):
        seq += 1
    new_log = log_path_for_date(today, seq)
    # Update sequence - shift 01 to 02, etc.
    old_log = get_latest_log()
    if old_log.endswith("-01.md"):
        base = old_log[:-7]
        os.rename(old_log, base + "-02.md")
    # Create new 01
    with open(new_log, 'w', encoding='utf-8') as f:
        f.write(f"# Decision Log {today} - part {seq:02d}\n\n")
    if reason:
        append_to_log(f"[AUTO] {reason}")
    return new_log

def append_to_log(entry):
    """Append an entry to the current decision log file."""
    log_file = get_latest_log()
    if get_current_log_size() >= DECISION_LOG_QUOTA:
        log_file = create_new_log(f"Quota exceeded, auto-split at {datetime.now().strftime('%H:%M:%S')}")
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(entry + "\n")
    return log_file

def add_log_entry(content, entry_type="record"):
    """Add a decision log entry with timestamp and type."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"### [{now}]\n- **[{entry_type}]**: {content}"
    log_file = append_to_log(entry)
    return log_file

def check_quota():
    """Check decision log quota status for all log files."""
    files = sorted(glob.glob(os.path.join(MEMORY_DIR, "LOG-*.md")))
    report = []
    for f in files:
        size = os.path.getsize(f)
        pct = size / DECISION_LOG_QUOTA * 100
        status = "OK" if pct < 80 else "WARNING" if pct < 100 else "OVERFLOW"
        report.append(f"  {os.path.basename(f)}: {size/1024:.1f}KB ({pct:.0f}%) [{status}]")
    return "\n".join(report)

def list_log_files():
    """List all decision log files."""
    files = sorted(glob.glob(os.path.join(MEMORY_DIR, "LOG-*.md")))
    return "\n".join([f"  {os.path.basename(f)} ({os.path.getsize(f)/1024:.1f}KB)" for f in files])

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Decision Log Manager - Usage:")
        print("  decision_log.py add <content>    Add entry")
        print("  decision_log.py check           Check quota")
        print("  decision_log.py list           List log files")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "add":
        content = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "No content"
        log_file = add_log_entry(content)
        print(f"Added to: {log_file}")
    elif cmd == "check":
        print("Decision Log Quota Status:")
        print(check_quota())
    elif cmd == "list":
        print("Decision Log Files:")
        print(list_log_files())
    else:
        print(f"Unknown command: {cmd}")
