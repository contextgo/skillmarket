"""
Stratum-Memory: User Operation Log Manager
Manages daily user operation logs with weekly and monthly summaries.
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

import os
import json
import glob
from datetime import datetime, timedelta

# Auto-detect paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.path.dirname(os.path.dirname(os.path.dirname(SCRIPT_DIR)))
OP_LOG_DIR = os.path.join(WORKSPACE, "memory", "user_operation_logs")
OP_LOG_QUOTA = 200 * 1024  # 200KB per file

os.makedirs(OP_LOG_DIR, exist_ok=True)

def get_today_date():
    return datetime.now().strftime("%Y-%m-%d")

def get_log_path(date_str=None, seq=1):
    """Get operation log path for a given date and sequence."""
    if date_str is None:
        date_str = get_today_date()
    return os.path.join(OP_LOG_DIR, f"user_oplog-{date_str}-{seq:02d}.md")

def get_latest_log():
    """Find the latest active operation log file."""
    pattern = os.path.join(OP_LOG_DIR, f"user_oplog-{get_today_date()}-*.md")
    files = sorted(glob.glob(pattern), reverse=True)
    if files:
        return files[0]
    return get_log_path(get_today_date(), 1)

def get_current_log_size():
    """Get size of current active log file."""
    log = get_latest_log()
    if os.path.exists(log):
        return os.path.getsize(log)
    return 0

def create_new_log(reason=""):
    """Create a new operation log file with incremented sequence."""
    today = get_today_date()
    seq = 1
    while os.path.exists(get_log_path(today, seq)):
        seq += 1
    new_log = get_log_path(today, seq)
    header = f"# 用户操作日志 {today} - 第{seq}部分\n\n"
    header += f"## 日期信息\n"
    header += f"- 日期: {today}\n"
    header += f"- 开始时间: {datetime.now().strftime('%H:%M:%S')}\n"
    header += f"- 序列号: {seq:02d}\n\n"
    header += "## 今日操作记录\n\n"
    with open(new_log, 'w', encoding='utf-8') as f:
        f.write(header)
    if reason:
        append_to_log(f"[自动新建] {reason}")
    return new_log

def append_to_log(entry):
    """Append an entry to the current operation log file."""
    log = get_latest_log()
    if get_current_log_size() >= OP_LOG_QUOTA:
        log = create_new_log(f"文件达到200KB配额，自动新建")
    with open(log, 'a', encoding='utf-8') as f:
        f.write(entry + "\n")
    return log

def add_operation(category, action, detail="", tags=None):
    """
    Add an operation log entry.
    Category: chat | file | task | decision | config | other
    Action: 操作动作描述
    Detail: 详细说明
    Tags: ["标签1", "标签2"]
    """
    now = datetime.now()
    entry = f"### [{now.strftime('%H:%M:%S')}] {category.upper()} - {action}\n"
    if detail:
        entry += f"- 详情: {detail}\n"
    if tags:
        entry += f"- 标签: {' / '.join(tags)}\n"
    append_to_log(entry)
    return True

def check_quota():
    """Check operation log quota status."""
    today = get_today_date()
    files = sorted(glob.glob(os.path.join(OP_LOG_DIR, f"user_oplog-{today}-*.md")))
    report = []
    total_size = 0
    for f in files:
        size = os.path.getsize(f)
        total_size += size
        pct = size / OP_LOG_QUOTA * 100
        status = "OK" if pct < 80 else "WARNING" if pct < 100 else "OVERFLOW"
        report.append(f"  {os.path.basename(f)}: {size/1024:.1f}KB ({pct:.0f}%) [{status}]")
    return "\n".join(report) if report else "  今日暂无操作日志"

def list_logs():
    """List all operation log files."""
    files = sorted(glob.glob(os.path.join(OP_LOG_DIR, "user_oplog-*.md")))
    return "\n".join([f"  {os.path.basename(f)} ({os.path.getsize(f)/1024:.1f}KB)" for f in files]) or "  暂无日志文件"

def get_logs_for_period(days=7):
    """Get all log files for the past N days."""
    today = datetime.now()
    logs = []
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        pattern = os.path.join(OP_LOG_DIR, f"user_oplog-{date}-*.md")
        logs.extend(sorted(glob.glob(pattern)))
    return logs

def extract_decisions_from_logs(logs):
    """Extract decision entries from logs."""
    decisions = []
    for log in logs:
        try:
            with open(log, 'r', encoding='utf-8') as f:
                content = f.read()
            lines = content.split('\n')
            in_decision = False
            for line in lines:
                if 'DECISION' in line.upper() or ('决策' in line and '###' in line):
                    in_decision = True
                    current = line + '\n'
                elif in_decision:
                    if line.startswith('### ') or (line.startswith('##') and '今日操作' not in line):
                        decisions.append(current)
                        in_decision = False
                    elif line.strip():
                        current += line + '\n'
            if in_decision:
                decisions.append(current)
        except:
            pass
    return decisions

def generate_weekly_summary():
    """Generate weekly decision summary."""
    logs = get_logs_for_period(7)
    if not logs:
        return "本周暂无操作日志"

    decisions = extract_decisions_from_logs(logs)
    today = get_today_date()
    week_start = (datetime.now() - timedelta(days=6)).strftime("%Y-%m-%d")

    summary = f"# 周决策汇总\n\n"
    summary += f"**周期**: {week_start} ~ {today}\n\n"
    summary += f"**日志文件数**: {len(logs)}\n"
    summary += f"**决策条目数**: {len(decisions)}\n\n"
    summary += "## 本周重要决策\n\n"
    if decisions:
        for i, d in enumerate(decisions, 1):
            summary += f"{i}. {d}\n"
    else:
        summary += "本周无决策记录。\n"
    return summary

def generate_monthly_summary():
    """Generate monthly summary."""
    logs = get_logs_for_period(30)
    if not logs:
        return "本月暂无操作日志"

    today = get_today_date()
    month_start = (datetime.now().replace(day=1)).strftime("%Y-%m-%d")

    # Count by category
    categories = {}
    decisions = []
    for log in logs:
        try:
            with open(log, 'r', encoding='utf-8') as f:
                content = f.read()
            for line in content.split('\n'):
                if '### [' in line:
                    for cat in ['CHAT', 'FILE', 'TASK', 'DECISION', 'CONFIG', 'OTHER']:
                        if cat in line.upper():
                            categories[cat] = categories.get(cat, 0) + 1
                            if cat == 'DECISION':
                                decisions.append(line)
        except:
            pass

    summary = f"# 月度汇总\n\n"
    summary += f"**周期**: {month_start} ~ {today}\n\n"
    summary += f"**日志文件数**: {len(logs)}\n"
    summary += f"**决策条目数**: {len(decisions)}\n\n"
    summary += "## 分类统计\n\n"
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        summary += f"- {cat}: {count}条\n"
    summary += "\n## 本月决策\n\n"
    if decisions:
        for i, d in enumerate(decisions[:20], 1):
            summary += f"{i}. {d}\n"
        if len(decisions) > 20:
            summary += f"\n... 还有{len(decisions)-20}条决策记录\n"
    else:
        summary += "本月无决策记录。\n"
    return summary

def generate_word_doc(logs, period="daily"):
    """Generate a Word document summary."""
    try:
        from docx import Document
        from docx.shared import Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("python-docx not installed. Use: pip install python-docx")
        return None

    doc = Document()
    now = datetime.now()

    if period == "daily":
        title = doc.add_heading(f'用户操作日志 - {now.strftime("%Y-%m-%d")}', 0)
        doc.add_paragraph(f"生成时间: {now.strftime('%H:%M:%S')}")
    elif period == "weekly":
        week_start = (datetime.now() - timedelta(days=6)).strftime("%Y-%m-%d")
        title = doc.add_heading(f'周决策汇总 - {week_start} ~ {now.strftime("%Y-%m-%d")}', 0)
    else:
        month_start = now.replace(day=1).strftime("%Y-%m-%d")
        title = doc.add_heading(f'月度汇总 - {month_start} ~ {now.strftime("%Y-%m-%d")}', 0)

    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading('操作记录', level=1)
    for log in logs:
        doc.add_paragraph(f"文件: {os.path.basename(log)}", style='Intense Quote')
        try:
            with open(log, 'r', encoding='utf-8') as f:
                content = f.read()
            for line in content.split('\n'):
                if line.strip():
                    if line.startswith('###'):
                        p = doc.add_paragraph(line)
                        p.runs[0].bold = True if 'DECISION' in line.upper() else False
                    elif line.startswith('-'):
                        doc.add_paragraph(line)
                    elif line.startswith('#'):
                        p = doc.add_paragraph(line)
                        p.runs[0].bold = True
        except Exception as e:
            doc.add_paragraph(f"[读取错误: {e}]")

    doc.add_heading('决策提取', level=1)
    decisions = extract_decisions_from_logs(logs)
    if decisions:
        for i, d in enumerate(decisions, 1):
            doc.add_paragraph(f"{i}. {d.strip()}")
    else:
        doc.add_paragraph("无决策记录。")

    return doc

def status():
    """Show operation log status."""
    print("User Operation Log Status:")
    print(f"  Log directory: {OP_LOG_DIR}")
    today = get_today_date()
    files = sorted(glob.glob(os.path.join(OP_LOG_DIR, f"user_oplog-{today}-*.md")))
    print(f"  Today's files: {len(files)}")
    print(f"  Quota status:")
    print(check_quota())

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("User Operation Log Manager")
        print("Usage:")
        print("  user_oplog.py add <category> <action> [detail]")
        print("  user_oplog.py status")
        print("  user_oplog.py list")
        print("  user_oplog.py check")
        print("  user_oplog.py weekly")
        print("  user_oplog.py monthly")
        print("  user_oplog.py word [daily|weekly|monthly]")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "add":
        category = sys.argv[2] if len(sys.argv) > 2 else "other"
        action = sys.argv[3] if len(sys.argv) > 3 else "未分类操作"
        detail = sys.argv[4] if len(sys.argv) > 4 else ""
        tags = [sys.argv[5]] if len(sys.argv) > 5 else []
        add_operation(category, action, detail, tags)
        print(f"Added: [{category}] {action}")
    elif cmd == "status":
        status()
    elif cmd == "list":
        print("All logs:")
        print(list_logs())
    elif cmd == "check":
        print("Daily quota:")
        print(check_quota())
    elif cmd == "weekly":
        print(generate_weekly_summary())
    elif cmd == "monthly":
        print(generate_monthly_summary())
    elif cmd == "word":
        period = sys.argv[2] if len(sys.argv) > 2 else "daily"
        days = 1 if period == "daily" else (7 if period == "weekly" else 30)
        logs = get_logs_for_period(days)
        doc = generate_word_doc(logs, period)
        if doc:
            out_path = os.path.join(OP_LOG_DIR, f"oplog-{period}-{get_today_date()}.docx")
            doc.save(out_path)
            print(f"Saved: {out_path}")
    else:
        print(f"Unknown command: {cmd}")
