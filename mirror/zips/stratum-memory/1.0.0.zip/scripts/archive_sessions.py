"""
L0 原始对话层 - 会话存档脚本
================================
从 OpenClaw 会话记录（JSONL）中提取对话，存档到 memory/sessions/
"""

import os
import json
from datetime import datetime

OPENCLAW_SESSIONS = r"F:\Cosmius\.openclaw\agents\main\sessions"
MEMORY_SESSIONS = r"H:\Cosmius\workspace\main\memory\sessions"
ARCHIVE_LOG = os.path.join(MEMORY_SESSIONS, "archive_log.json")

os.makedirs(MEMORY_SESSIONS, exist_ok=True)

def safe_ts(ts):
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            if 'T' in ts:
                # ISO format: '2026-04-25T20:03:57.721Z' or '2026-04-25T20:03:57.721+08:00'
                ts = ts.replace('Z', '+00:00')
                return datetime.fromisoformat(ts).astimezone()
            ts = int(ts)
        except:
            return None
    try:
        return datetime.fromtimestamp(ts / 1000)
    except:
        return None

def parse_jsonl(path):
    messages = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                messages.append(obj)
            except:
                continue
    return messages

def format_message(entry):
    """处理 JSONL entry，提取消息内容"""
    t = entry.get('type')

    if t == 'session':
        return None  # session start marker, skip

    if t == 'message':
        msg = entry.get('message', {})
        role = msg.get('role', 'unknown')
        content = msg.get('content', '')

        if isinstance(content, list):
            text_parts = []
            for part in content:
                if isinstance(part, dict):
                    if part.get('type') == 'text':
                        text_parts.append(part.get('text', ''))
                    elif part.get('type') == 'tool_use':
                        tool_name = part.get('name', 'tool')
                        args = part.get('args', '')
                        text_parts.append(f"[工具调用: {tool_name}]")
            content = '\n'.join(text_parts)
        elif not isinstance(content, str):
            content = str(content) if content else ''

        ts = safe_ts(entry.get('timestamp'))
        time_str = ts.strftime('%H:%M') if ts else ''

        if role == 'tool':
            return None  # skip tool responses
        return f"[{time_str} {role}] {content}"

    return None  # skip other entry types

def format_session(messages, session_id):
    first_ts = safe_ts(messages[0].get('timestamp')) if messages else None
    last_ts = safe_ts(messages[-1].get('timestamp')) if messages else None
    start_time = first_ts.strftime('%Y-%m-%d %H:%M') if first_ts else '未知'
    end_time = last_ts.strftime('%Y-%m-%d %H:%M') if last_ts else '未知'

    user_msgs = [m for m in messages if m.get('type') == 'message' and m.get('message', {}).get('role') == 'user']
    assistant_msgs = [m for m in messages if m.get('type') == 'message' and m.get('message', {}).get('role') == 'assistant']

    lines = [
        f"# 会话存档：{start_time}",
        f"",
        f"- **会话ID**: {session_id}",
        f"- **开始时间**: {start_time}",
        f"- **结束时间**: {end_time}",
        f"- **消息数**: {len(messages)}（用户: {len(user_msgs)}，助手: {len(assistant_msgs)}）",
        f"",
        f"---",
        f""
    ]

    for entry in messages:
        formatted = format_message(entry)
        if formatted and formatted.strip():
            lines.append(formatted)
            lines.append("")

    return '\n'.join(lines)

def load_log():
    if os.path.exists(ARCHIVE_LOG):
        with open(ARCHIVE_LOG, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_log(log):
    with open(ARCHIVE_LOG, 'w', encoding='utf-8') as f:
        json.dump(log, f, ensure_ascii=False, indent=2)

def archive_session(jsonl_path):
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0]
    basename = os.path.basename(jsonl_path)

    if basename.endswith('.lock'):
        return False, 'lock file'
    if '.reset.' in basename or '.deleted.' in basename:
        return False, 'reset/deleted'

    messages = parse_jsonl(jsonl_path)
    if not messages:
        return False, 'empty'

    first_ts = safe_ts(messages[0].get('timestamp'))
    session_date = first_ts.strftime('%Y-%m-%d') if first_ts else 'unknown'
    first_time = first_ts.strftime('%H%M') if first_ts else '0000'

    archive_name = f"main-{session_date}-{first_time}-{session_id[:8]}.md"
    archive_path = os.path.join(MEMORY_SESSIONS, archive_name)

    content = format_session(messages, session_id)
    with open(archive_path, 'w', encoding='utf-8') as f:
        f.write(content)

    return True, archive_path

def run():
    log = load_log()
    if not os.path.exists(OPENCLAW_SESSIONS):
        print(f"[L0] 会话目录不存在: {OPENCLAW_SESSIONS}")
        return 0, 0

    files = [f for f in os.listdir(OPENCLAW_SESSIONS) if f.endswith('.jsonl') and not f.endswith('.lock')]
    archived = 0
    skipped = 0

    for fname in files:
        fpath = os.path.join(OPENCLAW_SESSIONS, fname)
        session_id = fname.replace('.jsonl', '')

        if session_id in log:
            source_mtime = os.path.getmtime(fpath)
            if log[session_id].get('archived_at', 0) >= source_mtime:
                skipped += 1
                continue

        ok, result = archive_session(fpath)
        if ok:
            log[session_id] = {
                'archived_path': result,
                'archived_at': os.path.getmtime(fpath),
                'archived_at_dt': datetime.now().isoformat()
            }
            archived += 1

    save_log(log)
    return archived, skipped

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'list':
        log = load_log()
        print(f"[L0] 已存档: {len(log)} 个会话")
        print(f"[L0] 存档目录: {MEMORY_SESSIONS}")
        for sid, info in list(log.items())[-5:]:
            print(f"  {sid[:16]}... -> {os.path.basename(info['archived_path'])}")
    else:
        print(f"[L0] 存档脚本")
        print(f"源: {OPENCLAW_SESSIONS}")
        print(f"目标: {MEMORY_SESSIONS}")
        print()
        archived, skipped = run()
        print(f"完成: 新存档 {archived} 个，跳过 {skipped} 个")