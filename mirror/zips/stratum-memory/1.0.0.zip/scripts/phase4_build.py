# -*- coding: utf-8 -*-
"""
Phase 4: 记忆体检索 — 四层记忆统一向量索引构建脚本
====================================================
索引 L0/L1/L2/L3 所有记忆层

用法: python phase4_build.py
"""

from __future__ import print_function
import sys
import os
import re
import json
import time
import requests
import numpy as np
import faiss
from datetime import datetime

WORKSPACE = r"H:\Cosmius\workspace\main"
MEMORY_DIR = os.path.join(WORKSPACE, "memory")
VECTOR_STORE = os.path.join(WORKSPACE, "vector_store")
os.makedirs(VECTOR_STORE, exist_ok=True)

INDEX_DIM = 768
OLLAMA_URL = "http://127.0.0.1:11434/api/embeddings"

def get_embedding(text):
    """获取文本嵌入向量"""
    payload = {"model": "nomic-embed-text", "prompt": text}
    resp = requests.post(OLLAMA_URL, json=payload, timeout=60)
    resp.raise_for_status()
    return np.array(resp.json()["embedding"], dtype=np.float32)

def chunk_text(text, max_chars=400):
    """将长文本分割成块"""
    paragraphs = re.split(r'\n\n+', text)
    chunks = []
    current = ""
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) <= max_chars:
            current += para + "\n"
        else:
            if current.strip():
                chunks.append(current.strip())
            current = para + "\n"
    if current.strip():
        chunks.append(current.strip())
    return chunks

def collect_all_memory():
    """收集所有四层记忆内容"""
    all_items = []

    # === L3: 核心人格文件 ===
    l3_map = {
        "L3": [
            ("MEMORY.md", os.path.join(WORKSPACE, "MEMORY.md")),
            ("SOUL.md", os.path.join(WORKSPACE, "SOUL.md")),
            ("USER.md", os.path.join(WORKSPACE, "USER.md")),
        ]
    }
    for layer, files in l3_map.items():
        for name, path in files:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                if content.strip():
                    all_items.append({
                        "layer": layer,
                        "source": name,
                        "content": content,
                    })

    # === L1: Decision Log 文件 ===
    log_pattern = re.compile(r'^Decision Log-\d{4}-\d{2}-\d{2}-\d{2}\.md$')
    if os.path.exists(MEMORY_DIR):
        for fname in os.listdir(MEMORY_DIR):
            if not log_pattern.match(fname):
                continue
            path = os.path.join(MEMORY_DIR, fname)
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.strip():
                all_items.append({
                    "layer": "L1",
                    "source": fname,
                    "content": content,
                })

    # === L2: 场景分块 ===
    projects_dir = os.path.join(MEMORY_DIR, "projects")
    if os.path.exists(projects_dir):
        for proj in sorted(os.listdir(projects_dir)):
            proj_dir = os.path.join(projects_dir, proj)
            if not os.path.isdir(proj_dir):
                continue
            for fname in sorted(os.listdir(proj_dir)):
                if not fname.endswith('.md'):
                    continue
                path = os.path.join(proj_dir, fname)
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                if content.strip():
                    all_items.append({
                        "layer": "L2",
                        "source": "%s/%s" % (proj, fname),
                        "content": content,
                    })

    # === L0: 会话存档 ===
    sessions_dir = os.path.join(MEMORY_DIR, "sessions")
    if os.path.exists(sessions_dir):
        for fname in sorted(os.listdir(sessions_dir)):
            if not fname.endswith('.md'):
                continue
            path = os.path.join(sessions_dir, fname)
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.strip():
                all_items.append({
                    "layer": "L0",
                    "source": fname,
                    "content": content,
                })

    return all_items

def build():
    """构建四层记忆向量索引"""
    print("[Phase4] Building 4-layer memory index at %s" % datetime.now().strftime("%H:%M:%S"))

    # 1. 收集
    print("[1] Collecting all memory layers...")
    items = collect_all_memory()
    print("   Found %d source files" % len(items))

    # 2. 分块
    print("[2] Chunking text...")
    chunks = []
    for item in items:
        sub = chunk_text(item['content'])
        for s in sub:
            if len(s) < 20:
                continue
            chunks.append({
                "layer": item['layer'],
                "source": item['source'],
                "text": s,
                "preview": s[:80].replace('\n', ' '),
            })
    print("   Total chunks: %d" % len(chunks))

    if not chunks:
        print("[ERROR] No chunks to index!")
        return

    # 3. 嵌入
    print("[3] Getting embeddings (batch=5)...")
    embeddings = []
    for i, c in enumerate(chunks):
        try:
            emb = get_embedding(c['text'])
            embeddings.append(emb)
        except Exception as ex:
            print("   [WARN] Chunk %d failed: %s" % (i, ex))
            embeddings.append(np.zeros(INDEX_DIM, dtype=np.float32))
        if (i+1) % 5 == 0:
            print("   Embedded %d/%d" % (i+1, len(chunks)))
            sys.stdout.flush()

    print("   Embedding complete: %d vectors" % len(embeddings))

    # 4. 归一化
    emb_matrix = np.array(embeddings, dtype=np.float32)
    norms = np.linalg.norm(emb_matrix, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    emb_matrix = emb_matrix / norms

    # 5. 建立索引
    print("[4] Building FAISS index...")
    index = faiss.IndexFlatIP(INDEX_DIM)
    index.add(emb_matrix)
    print("   Index ntotal: %d" % index.ntotal)

    # 6. 保存
    index_path = os.path.join(VECTOR_STORE, "memory_4layer_index.faiss")
    faiss.write_index(index, index_path)
    print("   Index saved: %s" % index_path)

    # 7. 保存元数据
    layer_stats = {"L0": 0, "L1": 0, "L2": 0, "L3": 0}
    meta_chunks = []
    for c in chunks:
        layer_stats[c['layer']] = layer_stats.get(c['layer'], 0) + 1
        meta_chunks.append({
            "layer": c['layer'],
            "source": c['source'],
            "preview": c['preview'],
        })

    meta = {
        "last_build": datetime.now().isoformat(),
        "total_chunks": len(chunks),
        "layer_stats": layer_stats,
        "dim": INDEX_DIM,
        "model": "nomic-embed-text",
        "chunks": meta_chunks,
    }
    meta_path = os.path.join(VECTOR_STORE, "memory_4layer_meta.json")
    with open(meta_path, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print("   Meta saved: %s" % meta_path)

    print("\n[Phase4] Build complete!")
    print("  Total chunks: %d" % len(chunks))
    print("  Layer stats: %s" % layer_stats)
    print("  Index: %s (%.1f KB)" % (index_path, os.path.getsize(index_path)/1024))


if __name__ == "__main__":
    build()