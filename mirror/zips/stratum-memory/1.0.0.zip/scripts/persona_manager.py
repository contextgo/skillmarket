"""
L3 用户画像自我反省管理器
==========================
管理 MEMORY.md / SOUL.md / USER.md 的整理与归档

功能：
- 检查 L3 三文件总量是否超 Quota（50KB）
- 扫描过时信息（>30天未更新的条目）
- 将低价值条目归档到 persona-archive/
- 生成精简版 L3 文件

Quota: 三文件总计 50KB
触发整理：>30KB 或 手动触发
"""

import os
import re
from datetime import datetime

L3_FILES = {
    'MEMORY.md': r"H:\Cosmius\workspace\main\MEMORY.md",
    'SOUL.md': r"H:\Cosmius\workspace\main\SOUL.md",
    'USER.md': r"H:\Cosmius\workspace\main\USER.md",
}
ARCHIVE_DIR = r"H:\Cosmius\workspace\main\memory\persona-archive"
L3_QUOTA_KB = 50
L3_WARNING_KB = 30

def get_total_size():
    total = 0
    details = []
    for name, path in L3_FILES.items():
        size = os.path.getsize(path) / 1024
        total += size
        details.append((name, size))
    return total, details

def check_quota():
    total, details = get_total_size()
    print(f"[L3 Quota] Check time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"[L3 Quota] Total: {total:.1f}KB / {L3_QUOTA_KB}KB ({total/L3_QUOTA_KB*100:.0f}%)")
    for name, size in details:
        print(f"  - {name}: {size:.1f}KB ({size/L3_QUOTA_KB*100:.0f}%)")
    if total >= L3_QUOTA_KB:
        print(f"[L3 Quota] OVER QUOTA")
        return "OVER"
    elif total >= L3_WARNING_KB:
        print(f"[L3 Quota] WARNING: approaching limit")
        return "WARNING"
    else:
        print(f"[L3 Quota] OK")
        return "OK"

def archive_old_entries():
    print(f"[L3 Self-Reflect] Scanning for stale entries...")
    memory_path = L3_FILES['MEMORY.md']
    with open(memory_path, 'r', encoding='utf-8') as f:
        content = f.read()
    update_pattern = re.search(r'上次更新[：:](\d{4}-\d{2}-\d{2})', content)
    if update_pattern:
        last_update = update_pattern.group(1)
        print(f"[L3] MEMORY.md last updated: {last_update}")
        try:
            update_date = datetime.strptime(last_update, '%Y-%m-%d')
            days_ago = (datetime.now() - update_date).days
            print(f"[L3] {days_ago} days ago")
            if days_ago > 30:
                print(f"[L3] Entry is stale (>30 days), consider archiving")
        except:
            pass
    print(f"[L3 Self-Reflect] No entries auto-archived (manual review needed)")
    return []

def list_archive():
    if not os.path.exists(ARCHIVE_DIR):
        print("[L3 Archive] Directory does not exist")
        return
    files = sorted(os.listdir(ARCHIVE_DIR))
    if not files:
        print("[L3 Archive] No archived files")
        return
    print(f"[L3 Archive] {len(files)} files:")
    for f in files:
        path = os.path.join(ARCHIVE_DIR, f)
        size = os.path.getsize(path) / 1024
        print(f"  - {f}: {size:.1f}KB")

def generate_summary():
    total, details = get_total_size()
    status = "WARN" if total >= L3_WARNING_KB else "OK"
    archive_count = len(os.listdir(ARCHIVE_DIR)) if os.path.exists(ARCHIVE_DIR) else 0

    lines = []
    lines.append("=== L3 User Persona Status ===")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"Total: {total:.1f}KB / {L3_QUOTA_KB}KB ({total/L3_QUOTA_KB*100:.0f}%) [{status}]")
    for name, size in details:
        lines.append(f"  {name}: {size:.1f}KB ({size/L3_QUOTA_KB*100:.0f}%)")
    lines.append(f"Archive: {archive_count} files in persona-archive/")
    lines.append(f"Quota: {L3_QUOTA_KB}KB max, warn at {L3_WARNING_KB}KB")
    return '\n'.join(lines)

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: persona_manager.py check|archive|summary|list-archive")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "check":
        check_quota()
    elif cmd == "archive":
        archive_old_entries()
    elif cmd == "summary":
        print(generate_summary())
    elif cmd == "list-archive":
        list_archive()
    else:
        print(f"Unknown: {cmd}")