"""
Phase 4: 记忆体检索 — 四层记忆语义搜索
=========================================
对 4-layer memory 体系（L0/L1/L2/L3）建立统一向量索引

索引内容：
- L0: memory/sessions/ (会话存档)
- L1: memory/Decision Log-*.md (Decision Log文件)
- L2: memory/projects/*/ (场景分块)
- L3: MEMORY.md / SOUL.md / USER.md

用法：
  python memory_search.py build    # 重建索引
  python memory_search.py search <query>  # 搜索
  python memory_search.py status  # 查看索引状态
"""

import os
import re
import json
import faiss
import numpy as np
import requests
from datetime import datetime

# === 配置 ===
WORKSPACE = r"H:\Cosmius\workspace\main"
MEMORY_DIR = os.path.join(WORKSPACE, "memory")
VECTOR_STORE = os.path.join(WORKSPACE, "vector_store")
MEMORY_INDEX = os.path.join(VECTOR_STORE, "memory_4layer_index.faiss")
MEMORY_META = os.path.join(VECTOR_STORE, "memory_4layer_meta.json")

INDEX_DIM = 768  # nomic-embed-text dimension
OLLAMA_URL = "http://127.0.0.1:11434/api/embeddings"

LAYER_COLORS = {
    "L0": "原始对话",
    "L1": "Decision Log记录",
    "L2": "场景分块",
    "L3": "用户画像",
}

def get_embedding(text):
    """调用 Ollama 获取文本嵌入向量"""
    payload = {
        "model": "nomic-embed-text",
        "prompt": text
    }
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=60)
        resp.raise_for_status()
        return np.array(resp.json()["embedding"], dtype=np.float32)
    except Exception as e:
        print(f"[Embedding Error] {e}")
        return None

def collect_all_memory_chunks():
    """收集所有四层记忆的内容块"""
    chunks = []

    # === L3: 核心人格文件（最高优先级）===
    l3_files = {
        "MEMORY.md": os.path.join(WORKSPACE, "MEMORY.md"),
        "SOUL.md": os.path.join(WORKSPACE, "SOUL.md"),
        "USER.md": os.path.join(WORKSPACE, "USER.md"),
    }
    for name, path in l3_files.items():
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.strip():
                chunks.append({
                    "layer": "L3",
                    "source": name,
                    "content": content,
                    "size_kb": len(content.encode('utf-8')) / 1024
                })

    # === L1: Decision Log 文件 ===
    log_pattern = re.compile(r'^Decision Log-(\d{4}-\d{2}-\d{2})-(\d{2})\.md$')
    if os.path.exists(MEMORY_DIR):
        for fname in os.listdir(MEMORY_DIR):
            m = log_pattern.match(fname)
            if m:
                path = os.path.join(MEMORY_DIR, fname)
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                if content.strip():
                    chunks.append({
                        "layer": "L1",
                        "source": fname,
                        "content": content,
                        "size_kb": len(content.encode('utf-8')) / 1024
                    })

    # === L2: 场景分块 ===
    projects_dir = os.path.join(MEMORY_DIR, "projects")
    if os.path.exists(projects_dir):
        for proj in os.listdir(projects_dir):
            proj_dir = os.path.join(projects_dir, proj)
            if not os.path.isdir(proj_dir):
                continue
            for fname in os.listdir(proj_dir):
                if not fname.endswith('.md'):
                    continue
                path = os.path.join(proj_dir, fname)
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                if content.strip():
                    chunks.append({
                        "layer": "L2",
                        "source": f"{proj}/{fname}",
                        "content": content,
                        "size_kb": len(content.encode('utf-8')) / 1024
                    })

    # === L0: 会话存档 ===
    sessions_dir = os.path.join(MEMORY_DIR, "sessions")
    if os.path.exists(sessions_dir):
        for fname in sorted(os.listdir(sessions_dir)):
            if not fname.endswith('.md'):
                continue
            path = os.path.join(sessions_dir, fname)
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.strip():
                chunks.append({
                    "layer": "L0",
                    "source": fname,
                    "content": content,
                    "size_kb": len(content.encode('utf-8')) / 1024
                })

    return chunks

def chunk_text(text, max_chars=500):
    """将长文本分块，每块最多 max_chars 字符"""
    # 按段落分割
    paragraphs = re.split(r'\n\n+', text)
    chunks = []
    current = ""
    for para in paragraphs:
        if len(current) + len(para) <= max_chars:
            current += para + "\n"
        else:
            if current.strip():
                chunks.append(current.strip())
            current = para + "\n"
    if current.strip():
        chunks.append(current.strip())
    return chunks

def build_index():
    """构建四层记忆向量索引"""
    print(f"[Memory Search] Building 4-layer index at {datetime.now().strftime('%H:%M:%S')}")

    # 确保目录存在
    os.makedirs(VECTOR_STORE, exist_ok=True)

    # 收集所有内容块
    all_chunks = collect_all_memory_chunks()
    print(f"[Memory Search] Collected {len(all_chunks)} content blocks")

    # 按层统计
    layer_stats = {}
    for c in all_chunks:
        layer_stats[c['layer']] = layer_stats.get(c['layer'], 0) + 1

    print(f"[Memory Search] Layer stats: {layer_stats}")

    # 获取嵌入
    texts = []
    chunk_infos = []

    for item in all_chunks:
        sub_chunks = chunk_text(item['content'])
        for sc in sub_chunks:
            if len(sc) < 20:
                continue
            texts.append(sc)
            chunk_infos.append({
                "layer": item['layer'],
                "source": item['source'],
                "preview": sc[:100].replace('\n', ' '),
            })

    print(f"[Memory Search] {len(texts)} text chunks to embed")

    if not texts:
        print("[Memory Search] No text to index")
        return

    # 批量获取嵌入
    embeddings = []
    batch_size = 10
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i+batch_size]
        batch_embeddings = []
        for text in batch:
            emb = get_embedding(text)
            if emb is not None:
                batch_embeddings.append(emb)
            else:
                print(f"[Warning] Failed to embed chunk {i}")
                batch_embeddings.append(np.zeros(INDEX_DIM, dtype=np.float32))
        embeddings.extend(batch_embeddings)
        print(f"[Memory Search] Embedded {min(i+batch_size, len(texts))}/{len(texts)}")

    embeddings = np.array(embeddings, dtype=np.float32)
    # 归一化（L2 norm）
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    embeddings = embeddings / norms

    # 建立 FAISS 索引
    index = faiss.IndexFlatIP(embeddings.shape[1])  # Inner Product (cosine sim)
    index.add(embeddings)

    # 保存
    faiss.write_index(index, MEMORY_INDEX)
    print(f"[Memory Search] Index saved: {MEMORY_INDEX}")

    # 保存元数据
    meta = {
        "last_build": datetime.now().isoformat(),
        "total_chunks": len(texts),
        "layer_stats": layer_stats,
        "dim": INDEX_DIM,
        "model": "nomic-embed-text",
        "chunks": chunk_infos,
    }
    with open(MEMORY_META, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(f"[Memory Search] Meta saved: {MEMORY_META}")


def search(query, top_k=5):
    """搜索四层记忆"""
    if not os.path.exists(MEMORY_INDEX):
        print("[Memory Search] Index not found. Run 'build' first.")
        return

    # 加载索引
    index = faiss.read_index(MEMORY_INDEX)
    with open(MEMORY_META, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    # 获取查询向量
    q_emb = get_embedding(query)
    if q_emb is None:
        print("[Memory Search] Failed to get query embedding")
        return

    q_emb = q_emb.reshape(1, -1)
    q_emb = q_emb / np.linalg.norm(q_emb)

    # 搜索
    scores, indices = index.search(q_emb, min(top_k, index.ntotal))

    print(f"\n{'='*60}")
    print(f"记忆检索: {query}")
    print(f"{'='*60}")

    results_by_layer = {}
    for rank, (score, idx) in enumerate(zip(scores[0], indices[0]), 1):
        if idx < 0:
            continue
        info = meta['chunks'][idx]
        layer = info['layer']
        if layer not in results_by_layer:
            results_by_layer[layer] = []
        results_by_layer[layer].append((rank, score, info))

    # 按层分组输出
    for layer in ["L3", "L2", "L1", "L0"]:
        if layer not in results_by_layer:
            continue
        items = results_by_layer[layer]
        print(f"\n## {layer} {LAYER_COLORS.get(layer, '')}")
        print(f"来源：{items[0][2]['source']}")
        for rank, score, info in items[:2]:
            preview = info['preview'][:150]
            print(f"  [{rank}] (score={score:.3f}) {preview}...")


def status():
    """查看索引状态"""
    if not os.path.exists(MEMORY_INDEX):
        print("[Memory Search] Index not built yet")
        return

    index = faiss.read_index(MEMORY_INDEX)
    with open(MEMORY_META, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    print(f"[Memory Search] Status")
    print(f"  Index: {MEMORY_INDEX}")
    print(f"  Last build: {meta['last_build']}")
    print(f"  Total chunks: {meta['total_chunks']}")
    print(f"  Dimension: {meta['dim']}")
    print(f"  Model: {meta['model']}")
    print(f"  Layer stats: {meta['layer_stats']}")

    # 各层代表性文件
    layer_files = {}
    for chunk in meta['chunks']:
        layer = chunk['layer']
        if layer not in layer_files:
            layer_files[layer] = set()
        layer_files[layer].add(chunk['source'])

    print("\n  Layer sources:")
    for layer in ["L3", "L2", "L1", "L0"]:
        if layer in layer_files:
            print(f"    {layer}: {sorted(layer_files[layer])[:5]}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: memory_search.py build|search|status")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "build":
        build_index()

    elif cmd == "search":
        if len(sys.argv) < 3:
            print("Usage: memory_search.py search <query>")
            sys.exit(1)
        search(sys.argv[2])

    elif cmd == "status":
        status()

    else:
        print(f"Unknown: {cmd}")