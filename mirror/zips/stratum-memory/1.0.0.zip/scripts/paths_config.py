"""
Stratum-Memory: Path Configuration
Auto-detects workspace from openclaw.json, with API fallback for low-end machines.
"""

import os
import json
import glob

# ============================================================
# Step 1: Auto-detect OpenClaw workspace from openclaw.json
# ============================================================
def find_openclaw_json():
    """Search for openclaw.json in common locations."""
    search_paths = [
        # Local .openclaw
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", ".openclaw", "openclaw.json"),
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "..", ".openclaw", "openclaw.json"),
        # System .openclaw
        os.path.join(os.environ.get("USERPROFILE", "C:\\Users\\Administrator"), ".openclaw", "openclaw.json"),
        os.path.join(os.environ.get("APPDATA", "C:\\Users\\Administrator\\AppData\\Roaming"), "Cosmius", "openclaw", "openclaw.json"),
        # Portable Cosmius
        "H:\\Cosmius\\.openclaw\\openclaw.json",
        "G:\\Cosmius\\.openclaw\\openclaw.json",
        "F:\\Cosmius\\.openclaw\\openclaw.json",
    ]

    for path in search_paths:
        path = os.path.normpath(path)
        if os.path.exists(path):
            return path
    return None

def get_workspace_from_config():
    """Read workspace path from openclaw.json."""
    config_path = find_openclaw_json()
    if not config_path:
        return None

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        # Try agents.config.workspace first
        if "agents" in config and "config" in config["agents"]:
            ws = config["agents"]["config"].get("workspace")
            if ws and os.path.exists(ws):
                return ws

        # Try workspace from various config locations
        for key in ["workspace", "repo", "path"]:
            if key in config:
                ws = config[key]
                if isinstance(ws, str) and os.path.exists(ws):
                    return ws
    except Exception:
        pass

    return None

# ============================================================
# Step 2: Fallback workspace detection (relative to this file)
# ============================================================
def get_fallback_workspace():
    """Derive workspace from script location."""
    # scripts/stratum-memory/ -> stratum-memory/ -> skills/ -> workspace/
    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # stratum-memory/
    skills_dir = os.path.dirname(skill_dir)  # skills/
    return os.path.dirname(skills_dir)  # workspace/

# ============================================================
# Step 3: Determine embedding backend
# ============================================================
OLLAMA_URL = "http://127.0.0.1:11434"
EMBED_MODEL = "nomic-embed-text"

def check_ollama_available():
    """Check if Ollama is running and has the model."""
    try:
        import requests
        r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        if r.status_code == 200:
            models = r.json().get("models", [])
            model_names = [m.get("name", "") for m in models]
            has_model = any("nomic" in n.lower() for n in model_names)
            return True, has_model
    except:
        pass
    return False, False

def get_embedding_backend():
    """Determine which embedding backend to use."""
    ollama_ok, has_model = check_ollama_available()
    if ollama_ok and has_model:
        return "ollama"
    elif ollama_ok:
        return "ollama_no_model"  # Ollama running but missing model
    else:
        return "api"  # No Ollama, use API fallback

# ============================================================
# Step 4: Determine workspace
# ============================================================
WORKSPACE = get_workspace_from_config() or get_fallback_workspace()

# Derived paths
VECTOR_STORE = os.path.join(WORKSPACE, "vector_store")
MEMORY_DIR = os.path.join(WORKSPACE, "memory")
MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
MEMORY_PROJECTS = os.path.join(MEMORY_DIR, "projects")
KNOWLEDGE_REPO = os.path.join(WORKSPACE, "knowledge-repo")
os.makedirs(VECTOR_STORE, exist_ok=True)

# Embedding configuration
EMBEDDING_BACKEND = get_embedding_backend()

# Layer 1: Personal memory (L0/L1/L2/L3)
LAYER_MEMORY = {
    "name": "Personal Memory",
    "sources": [
        os.path.join(WORKSPACE, "MEMORY.md"),
        MEMORY_DIR,
    ],
    "index_file": os.path.join(VECTOR_STORE, "memory_index.faiss"),
    "meta_file": os.path.join(VECTOR_STORE, "memory_meta.json"),
}

# Layer 2: Business knowledge (external repo)
LAYER_KNOWLEDGE = {
    "name": "Business Knowledge",
    "sources": [KNOWLEDGE_REPO],
    "index_file": os.path.join(VECTOR_STORE, "knowledge_index.faiss"),
    "meta_file": os.path.join(VECTOR_STORE, "knowledge_meta.json"),
}
