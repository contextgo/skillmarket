"""
Stratum-Memory: System Status
Unified view of all memory system components.
Run: python scripts/system_status.py
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

import os
import json
import glob
import faiss

# Use paths.py for all configuration
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)
try:
    from paths_config import WORKSPACE, VECTOR_STORE, MEMORY_DIR, OLLAMA_URL, EMBEDDING_BACKEND
    print("[DEBUG] paths_config imported OK", flush=True)
except ImportError as e:
    print(f"[DEBUG] paths_config import failed: {e}", flush=True)
    # Fallback if paths_config.py is missing
    WORKSPACE = os.path.dirname(os.path.dirname(os.path.dirname(script_dir)))
    VECTOR_STORE = os.path.join(WORKSPACE, "vector_store")
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    OLLAMA_URL = "http://127.0.0.1:11434"
    EMBEDDING_BACKEND = "unknown"

def format_size(size_bytes):
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes/1024:.1f}KB"
    else:
        return f"{size_bytes/1024/1024:.1f}MB"

def check_embedding_backend():
    """Check which embedding backend is available."""
    print(f"\n[Embedding Backend]")
    print(f"  Backend: {EMBEDDING_BACKEND}")
    print(f"  Ollama URL: {OLLAMA_URL}")
    if EMBEDDING_BACKEND != "ollama":
        print(f"  Note: Set OPENAI_API_KEY and OPENAI_API_BASE env vars to use API mode")
    return True

def check_vector_indices():
    print("\n[Vector Index Status]")
    indices = [
        ("memory_index.faiss", "memory_meta.json", "Personal Memory Index"),
        ("knowledge_index.faiss", "knowledge_meta.json", "Business Knowledge Index"),
    ]
    total_chunks = 0
    for fname, mname, label in indices:
        fpath = os.path.join(VECTOR_STORE, fname)
        mpath = os.path.join(VECTOR_STORE, mname)
        if os.path.exists(fpath) and os.path.exists(mpath):
            try:
                idx = faiss.read_index(fpath)
                with open(mpath, 'r', encoding='utf-8') as f:
                    meta = json.load(f)
                chunks = len(meta)
                total_chunks += chunks
                print(f"  {label}: OK ({chunks} chunks)")
            except Exception as e:
                print(f"  {label}: ERROR ({e})")
        else:
            print(f"  {label}: MISSING")
    print(f"  Total: {total_chunks} chunks")

def check_memory_layers():
    print("\n[4-Layer Memory Status]")
    # L0
    sessions_dir = os.path.join(MEMORY_DIR, "sessions")
    l0_count = l0_size = 0
    if os.path.exists(sessions_dir):
        files = glob.glob(os.path.join(sessions_dir, "*.md"))
        l0_count = len(files)
        l0_size = sum(os.path.getsize(f) for f in files)
    print(f"  L0 Raw Sessions: {l0_count} files ({format_size(l0_size)})")
    # L1 Decision Log
    log_files = sorted(glob.glob(os.path.join(MEMORY_DIR, "Decision Log-*.md")))
    l1_size = sum(os.path.getsize(f) for f in log_files)
    print(f"  L1 Decision Log Records: {len(log_files)} files ({format_size(l1_size)})")
    # L2 projects
    projects_dir = os.path.join(MEMORY_DIR, "projects")
    l2_count = l2_size = 0
    if os.path.exists(projects_dir):
        for root, dirs, files in os.walk(projects_dir):
            md_files = [f for f in files if f.endswith('.md')]
            l2_count += len(md_files)
            l2_size += sum(os.path.getsize(os.path.join(root, f)) for f in md_files)
    print(f"  L2 Scene Chunks: {l2_count} files ({format_size(l2_size)})")
    # L3 persona
    l3_files = ["MEMORY.md", "SOUL.md", "USER.md"]
    l3_total = l3_count = 0
    for f in l3_files:
        fpath = os.path.join(WORKSPACE, f)
        if os.path.exists(fpath):
            l3_count += 1
            l3_total += os.path.getsize(fpath)
    print(f"  L3 User Persona: {l3_count}/3 files ({format_size(l3_total)})")

def check_knowledge_base():
    print("\n[External Knowledge Base]")
    kb_paths = [
        os.path.join(WORKSPACE, "knowledge-repo"),
        os.path.join(WORKSPACE, "本盘knowledge-repo"),
    ]
    total_files = total_size = 0
    for kb in kb_paths:
        if os.path.exists(kb):
            for root, dirs, files in os.walk(kb):
                dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', '__pycache__']]
                md_files = [f for f in files if f.endswith(('.md', '.txt'))]
                total_files += len(md_files)
                total_size += sum(os.path.getsize(os.path.join(root, f)) for f in md_files)
    if total_files > 0:
        print(f"  knowledge-repo: {total_files} files ({format_size(total_size)})")
    else:
        print(f"  knowledge-repo: Not found")

def check_cron_advice():
    print("\n[Recommended Cron Tasks]")
    tasks = [
        ("12:00", "Index health check", "python scripts/vector_search.py status"),
        ("18:00", "Dual index rebuild", "python scripts/build_index.py"),
        ("18:00", "Decision Log quota check", "python scripts/decision_log.py check"),
        ("23:00", "L0 session archive", "python scripts/archive_sessions.py"),
    ]
    for time, task, cmd in tasks:
        print(f"  {time} - {task}")

def main():
    print("=" * 50)
    print("Stratum-Memory System Status")
    print("=" * 50)
    print(f"Workspace: {WORKSPACE}")
    print(f"Embedding Backend: {EMBEDDING_BACKEND}")

    check_embedding_backend()
    check_vector_indices()
    check_memory_layers()
    check_knowledge_base()
    check_cron_advice()

    print("\n" + "=" * 50)
    print("Check complete")
    print("=" * 50)

if __name__ == "__main__":
    main()
