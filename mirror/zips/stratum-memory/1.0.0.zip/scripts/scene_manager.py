"""
L2 场景分块管理器
==================
管理 memory/projects/ 下的场景块

功能：
- 创建新场景
- 添加内容到场景块（自动Quota切换）
- 列出所有场景
- 检查容量状态

命名规范：
  {project}-{date}-{seq}.md
  例：wangjiying-loan-2026-04-11-01.md

Quota: 200KB/文件，超出自动创建 part2
"""

import os
import re
import json
from datetime import datetime

MEMORY_PROJECTS = r"H:\Cosmius\workspace\main\memory\projects"
SCENE_QUOTA_KB = 200

def list_scenes():
    """列出所有场景及其块"""
    if not os.path.exists(MEMORY_PROJECTS):
        print("[Scene] projects/ 目录不存在")
        return

    projects = sorted(os.listdir(MEMORY_PROJECTS))
    if not projects:
        print("[Scene] 暂无场景")
        return

    print(f"[Scene] 场景目录: {MEMORY_PROJECTS}\n")
    for proj in projects:
        proj_path = os.path.join(MEMORY_PROJECTS, proj)
        if not os.path.isdir(proj_path):
            continue

        blocks = [f for f in os.listdir(proj_path) if f.endswith('.md')]
        blocks.sort()

        total_size = 0
        for b in blocks:
            total_size += os.path.getsize(os.path.join(proj_path, b))

        print(f"  [{proj}] ({len(blocks)} blocks, {total_size/1024:.1f}KB)")

        for b in blocks[:5]:  # show first 5
            size = os.path.getsize(os.path.join(proj_path, b)) / 1024
            print(f"    - {b}: {size:.1f}KB")
        if len(blocks) > 5:
            print(f"    ... and {len(blocks)-5} more")


def find_latest_block(proj_dir):
    """找某场景最新块文件（序号最大的）"""
    pattern = re.compile(r"^.+-(\d{2})\.md$")
    candidates = []

    for f in os.listdir(proj_dir):
        if not f.endswith('.md'):
            continue
        m = pattern.search(f)
        if m:
            seq = int(m.group(1))
            path = os.path.join(proj_dir, f)
            size_kb = os.path.getsize(path) / 1024
            candidates.append((seq, f, path, size_kb))

    if not candidates:
        return None, None, 0

    candidates.sort(key=lambda x: x[0])
    return candidates[-1][1], candidates[-1][2], candidates[-1][3]  # fname, path, size_kb


def add_to_scene(project, content, date_override=None):
    """添加内容到场景块，自动处理Quota切换"""
    proj_dir = os.path.join(MEMORY_PROJECTS, project)
    if not os.path.exists(proj_dir):
        os.makedirs(proj_dir, exist_ok=True)

    date_str = datetime.now().strftime("%Y-%m-%d") if not date_override else date_override

    latest_fname, latest_path, current_size_kb = find_latest_block(proj_dir)

    if latest_path is None:
        # 新场景，创建第一个块
        new_path = os.path.join(proj_dir, f"{project}-{date_str}-01.md")
        with open(new_path, 'w', encoding='utf-8') as f:
            f.write(f"# 场景块：{project}\n")
            f.write(f"创建日期：{date_str}\n\n")
            f.write(content)
        return new_path, "new_scene"

    # 检查 quota
    if current_size_kb >= SCENE_QUOTA_KB:
        # 超出 quota，创建下一个序号
        m = re.match(r"^(.+)-(\d{2})\.md$", latest_fname)
        next_seq = int(m.group(2)) + 1 if m else 2
        new_path = os.path.join(proj_dir, f"{project}-{date_str}-{next_seq:02d}.md")
        with open(new_path, 'w', encoding='utf-8') as f:
            f.write(f"# 场景块：{project} (part {next_seq:02d})\n")
            f.write(f"创建日期：{date_str}\n\n")
            f.write(content)
        return new_path, f"new_part_{next_seq}"
    else:
        # 追加
        with open(latest_path, 'a', encoding='utf-8') as f:
            f.write(content)
        return latest_path, "append"


def check_quota_all():
    """检查所有场景的容量状态"""
    if not os.path.exists(MEMORY_PROJECTS):
        print("[Scene Quota] projects/ 不存在")
        return

    projects = sorted(os.listdir(MEMORY_PROJECTS))
    warnings = []

    for proj in projects:
        proj_path = os.path.join(MEMORY_PROJECTS, proj)
        if not os.path.isdir(proj_path):
            continue

        blocks = [f for f in os.listdir(proj_path) if f.endswith('.md')]
        if not blocks:
            continue

        latest_fname, latest_path, latest_size_kb = find_latest_block(proj_path)

        status = "OK"
        if latest_size_kb >= SCENE_QUOTA_KB:
            status = "OVERQUOTA"
            warnings.append(f"{proj}: latest block at {latest_size_kb:.1f}KB (>{SCENE_QUOTA_KB}KB)")
        elif latest_size_kb >= SCENE_QUOTA_KB * 0.8:
            status = "WARNING"

        print(f"[Scene Quota] {proj}: {latest_fname} = {latest_size_kb:.1f}KB/{SCENE_QUOTA_KB}KB [{status}]")

    if warnings:
        print(f"\n[WARNINGS] {len(warnings)} scenes need attention:")
        for w in warnings:
            print(f"  - {w}")
    else:
        print("\n[Scene Quota] All scenes OK")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("用法: scene_manager.py list|add|check [args]")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "list":
        list_scenes()

    elif cmd == "add":
        if len(sys.argv) < 4:
            print("用法: scene_manager.py add <project> <content>")
            sys.exit(1)
        project = sys.argv[2]
        content = sys.argv[3]
        path, action = add_to_scene(project, content)
        print(f"[Scene] {action} -> {os.path.basename(path)}")

    elif cmd == "check":
        check_quota_all()

    else:
        print(f"未知命令: {cmd}")