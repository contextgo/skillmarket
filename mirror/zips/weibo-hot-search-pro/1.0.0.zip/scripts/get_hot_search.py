#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微博热搜获取脚本
获取当前微博热搜榜前 N 条数据
"""

import json
import sys
import urllib.request
import urllib.error

# Windows 控制台 UTF-8 支持
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# 微博热搜 API（公开接口，无需登录）
WEIBO_HOT_SEARCH_URL = "https://weibo.com/ajax/side/hotSearch"

# 请求头，模拟浏览器
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": "https://weibo.com",
}


def get_hot_search(top_n: int = 10) -> list[dict]:
    """
    获取微博热搜榜
    
    Args:
        top_n: 获取前 N 条，默认 10 条
        
    Returns:
        热搜列表，每项包含 rank, title, hot_value, label
    """
    request = urllib.request.Request(
        WEIBO_HOT_SEARCH_URL,
        headers=HEADERS,
    )
    
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as e:
        print(f"网络请求失败: {e}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"JSON 解析失败: {e}", file=sys.stderr)
        sys.exit(1)
    
    if data.get("ok") != 1:
        print(f"接口返回错误: {data.get('msg', '未知错误')}", file=sys.stderr)
        sys.exit(1)
    
    hot_list = data.get("data", {}).get("realtime", [])
    
    results = []
    for item in hot_list[:top_n]:
        # 解析热搜条目
        rank = item.get("rank", 0)
        title = item.get("word", "")
        hot_value = item.get("num", 0)
        
        # 标签处理（word_scheme 可能是字符串或字典）
        word_scheme = item.get("word_scheme", {})
        if isinstance(word_scheme, dict):
            label = word_scheme.get("icon_desc", "")
        else:
            label = ""
        
        # 格式化热度值（万为单位）
        if hot_value >= 10000:
            hot_str = f"{hot_value / 10000:.1f}万"
        else:
            hot_str = str(hot_value)
        
        results.append({
            "rank": rank,
            "title": title,
            "hot_value": hot_str,
            "label": label,
        })
    
    return results


def format_output(hot_list: list[dict]) -> str:
    """
    格式化输出热搜列表
    
    Args:
        hot_list: 热搜列表
        
    Returns:
        格式化后的字符串
    """
    lines = ["📱 微博热搜榜", "=" * 30, ""]
    
    for i, item in enumerate(hot_list, 1):
        title = item["title"]
        hot = item["hot_value"]
        label = item["label"]
        
        # 标签处理（如：热、新、荐等）
        label_str = f"[{label}]" if label else ""
        
        # 前三名加特殊标识
        medal = ""
        if i == 1:
            medal = "🥇 "
        elif i == 2:
            medal = "🥈 "
        elif i == 3:
            medal = "🥉 "
        
        lines.append(f"{medal}{i}. {title} {label_str} 🔥{hot}")
    
    lines.append("")
    lines.append("=" * 30)
    lines.append(f"共 {len(hot_list)} 条热搜")
    
    return "\n".join(lines)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="获取微博热搜榜")
    parser.add_argument(
        "-n", "--top",
        type=int,
        default=10,
        help="获取前 N 条热搜，默认 10 条"
    )
    parser.add_argument(
        "-j", "--json",
        action="store_true",
        help="以 JSON 格式输出"
    )
    
    args = parser.parse_args()
    
    hot_list = get_hot_search(args.top)
    
    if args.json:
        print(json.dumps(hot_list, ensure_ascii=False, indent=2))
    else:
        print(format_output(hot_list))


if __name__ == "__main__":
    main()
