"""
tax-reminder 自学习模块

功能：
- 追踪省份二维码有效性（URL 是否可访问）
- 积累用户常问的省份和待办事项类型
- 检测政策变化（申报截止日期变动）
- 自动发现新的待办事项类型
"""

import json
from pathlib import Path
from datetime import datetime

LEARN_FILE = Path(__file__).parent.parent / "data" / "tax_reminder_learn.json"

DEFAULT_LEARN_DATA = {
    "version": 1,
    "skill_name": "tax-reminder",
    "last_success_date": None,
    "fail_streak": 0,
    "total_runs": 0,
    "total_success": 0,
    "total_failure": 0,
    "parameters": {
        # 用户常问省份（优先展示）
        "hot_provinces": ["上海市", "北京市", "广东省", "江苏省", "浙江省"],
        # 用户常问待办类型（优先展示）
        "hot_todo_types": ["增值税申报", "企业所得税申报", "个人所得税申报", "社保费申报"],
        # 申报截止日期变化追踪
        "deadline_changes": [],
    },
    "discoveries": [],
    "environment": {
        "last_policy_update": None,
        "qrcode_status": {},  # 省份 → "valid" / "expired" / "unknown"
        "supported_login_methods": ["微信扫码", "账号密码"],
    },
    "history": [],
}


def load_learn() -> dict:
    """加载经验文件"""
    if LEARN_FILE.exists():
        try:
            return json.loads(LEARN_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, Exception):
            pass
    LEARN_FILE.parent.mkdir(parents=True, exist_ok=True)
    return json.loads(json.dumps(DEFAULT_LEARN_DATA))


def save_learn(data: dict):
    """保存经验文件（历史只保留最近30条）"""
    if len(data.get("history", [])) > 30:
        data["history"] = data["history"][-30:]
    LEARN_FILE.parent.mkdir(parents=True, exist_ok=True)
    LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def record_success(data: dict, params_used: dict = None, env_info: dict = None):
    """记录成功执行"""
    data["last_success_date"] = datetime.now().strftime("%Y-%m-%d")
    data["fail_streak"] = 0
    data["total_runs"] = data.get("total_runs", 0) + 1
    data["total_success"] = data.get("total_success", 0) + 1
    if params_used:
        # 更新热门省份和待办类型排序
        province = params_used.get("province")
        if province:
            hot = data["parameters"].get("hot_provinces", [])
            if province in hot:
                hot.remove(province)
            hot.insert(0, province)
            data["parameters"]["hot_provinces"] = hot[:10]
        todo_type = params_used.get("todo_type")
        if todo_type:
            hot_types = data["parameters"].get("hot_todo_types", [])
            if todo_type in hot_types:
                hot_types.remove(todo_type)
            hot_types.insert(0, todo_type)
            data["parameters"]["hot_todo_types"] = hot_types[:10]
    if env_info:
        data["environment"].update(env_info)
    # 成功后将 discoveries 提升为正式参数
    for d in data.get("discoveries", []):
        category = d.get("category", "")
        keyword = d.get("keyword", "")
        if category == "todo_type" and keyword not in data["parameters"].get("hot_todo_types", []):
            data["parameters"]["hot_todo_types"].append(keyword)
        elif category == "login_method" and keyword not in data["environment"].get("supported_login_methods", []):
            data["environment"]["supported_login_methods"].append(keyword)
    data["discoveries"] = []
    save_learn(data)


def record_failure(data: dict, error: str = "", env_info: dict = None):
    """记录失败"""
    data["fail_streak"] = data.get("fail_streak", 0) + 1
    data["total_runs"] = data.get("total_runs", 0) + 1
    data["total_failure"] = data.get("total_failure", 0) + 1
    if env_info:
        data["environment"].update(env_info)
    entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "failure",
        "error": error,
    }
    data["history"].append(entry)
    # 连续失败3次，临时启用 discoveries
    if data["fail_streak"] >= 3 and data.get("discoveries"):
        _promote_discoveries(data)
    save_learn(data)


def _auto_discover(data: dict, user_query: str):
    """从用户提问中发现新的待办事项类型"""
    todo_type_markers = ["申报", "缴纳", "报送", "认证", "验旧", "采集", "备案", "清算", "审计"]
    for marker in todo_type_markers:
        if marker in user_query:
            # 提取用户查询中的待办类型短语
            import re
            match = re.search(rf'(\S+{marker}\S*)', user_query)
            if match:
                keyword = match.group(1)
                if keyword not in data["parameters"].get("hot_todo_types", []):
                    data.setdefault("discoveries", []).append({"category": "todo_type", "keyword": keyword})


def _promote_discoveries(data: dict):
    """将发现的模式临时加入搜索范围"""
    for d in data.get("discoveries", []):
        category = d.get("category", "")
        keyword = d.get("keyword", "")
        if category == "todo_type" and keyword not in data["parameters"].get("hot_todo_types", []):
            data["parameters"]["hot_todo_types"].append(keyword)


def record_qrcode_status(data: dict, province: str, status: str):
    """记录省份二维码状态"""
    data["environment"]["qrcode_status"][province] = {
        "status": status,  # "valid" / "expired" / "unknown"
        "date": datetime.now().strftime("%Y-%m-%d"),
    }
    save_learn(data)


def get_hot_provinces(data: dict) -> list:
    """获取热门省份列表（默认兜底）"""
    hot = data.get("parameters", {}).get("hot_provinces", DEFAULT_LEARN_DATA["parameters"]["hot_provinces"])
    # 确保默认省份都在列表中
    for p in DEFAULT_LEARN_DATA["parameters"]["hot_provinces"]:
        if p not in hot:
            hot.append(p)
    return hot


def get_hot_todo_types(data: dict) -> list:
    """获取热门待办类型列表"""
    hot = data.get("parameters", {}).get("hot_todo_types", DEFAULT_LEARN_DATA["parameters"]["hot_todo_types"])
    for t in DEFAULT_LEARN_DATA["parameters"]["hot_todo_types"]:
        if t not in hot:
            hot.append(t)
    return hot


def stats(data: dict = None) -> str:
    """输出学习统计"""
    if data is None:
        data = load_learn()
    lines = [
        f"📊 涉税提醒自学习统计",
        f"  总执行: {data.get('total_runs', 0)} 次",
        f"  成功: {data.get('total_success', 0)} 次",
        f"  失败: {data.get('total_failure', 0)} 次",
        f"  连续失败: {data.get('fail_streak', 0)} 次",
        f"  最后成功: {data.get('last_success_date', '无')}",
        f"  热门省份: {data.get('parameters', {}).get('hot_provinces', [])[:5]}",
        f"  热门待办: {data.get('parameters', {}).get('hot_todo_types', [])[:5]}",
        f"  二维码状态: {len(data.get('environment', {}).get('qrcode_status', {}))} 省份已记录",
        f"  待确认发现: {len(data.get('discoveries', []))}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    data = load_learn()
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--stats":
            print(stats(data))
        elif cmd == "--success":
            province = sys.argv[2] if len(sys.argv) > 2 else None
            todo_type = sys.argv[3] if len(sys.argv) > 3 else None
            record_success(data, params_used={"province": province, "todo_type": todo_type})
            print("✅ 已记录成功")
        elif cmd == "--failure":
            error = sys.argv[2] if len(sys.argv) > 2 else "未知错误"
            record_failure(data, error=error)
            print(f"❌ 已记录失败: {error}")
        elif cmd == "--qrcode":
            province = sys.argv[2] if len(sys.argv) > 2 else ""
            status = sys.argv[3] if len(sys.argv) > 3 else "unknown"
            record_qrcode_status(data, province, status)
            print(f"📱 已记录 {province} 二维码状态: {status}")
        elif cmd == "--reset":
            save_learn(json.loads(json.dumps(DEFAULT_LEARN_DATA)))
            print("🔄 已重置经验文件")
    else:
        print(stats(data))