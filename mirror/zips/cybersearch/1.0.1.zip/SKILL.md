---
name: CyberSearch
description: A client tool for CyberSearch API providing web search capabilities.
---

# CyberSearch Skill

## 概述

CyberSearch Skill 是基于清风AI搜索 API 的网页搜索客户端工具，提供网页搜索能力。该技能封装了 API 调用、结果解析和格式化，方便开发者快速集成搜索能力。

## 功能特性

- **网页搜索（Web Search）**：通用网页搜索，返回结构化搜索结果
- **结果格式化**：提供美观易读的文本格式输出
- **环境变量支持**：支持从 `.env` 文件加载 API 密钥和授权码

## 安装与配置

### 1. 环境要求
- Python 3.7+
- 依赖包：`requests`, `python-dotenv`

### 2. 安装依赖
```bash
pip install requests python-dotenv
```

### 3. 配置 API 密钥
在项目根目录创建 `.env` 文件，添加以下内容：
```env
QINGFENG_API_KEY=your_api_key_here
```

或者直接传入参数：
```python
from web_search import WebSearchClient
client = WebSearchClient(
    api_key="your_api_key_here"
)
```

**授权码获取**：授权码会自动通过接口动态获取，无需手动配置。

### 4. API 密钥获取
请访问 [清风AI搜索平台](https://www.qingfengyq.com) 获取 API 密钥。

## API 参考

### WebSearchClient 类

#### 初始化
```python
from web_search import WebSearchClient

# 方式1：使用 .env 文件中的配置（仅需 API Key）
client = WebSearchClient()

# 方式2：直接指定 API 密钥
client = WebSearchClient(
    api_key="your_api_key"
)

# 方式3：指定 .env 文件路径
client = WebSearchClient(env_path="path/to/.env")
```

初始化时会自动调用授权接口获取动态授权码。

#### 方法列表

##### search(query, count=10, freshness="noLimit")
执行网页搜索。

**参数：**
- `query` (str): 搜索查询字符串
- `count` (int): 返回结果数量，最大 10，默认 10
- `freshness` (str): 时间过滤选项，可选值：`"noLimit"`、`"day"`、`"week"`、`"month"`、`"year"`，默认 `"noLimit"`

**返回：**
- `Dict[str, Any]`: 原始 API 响应数据

**示例：**
```python
result = client.search("Python 教程", count=5, freshness="week")
```

##### format_results(results, query="")
格式化网页搜索结果。

**参数：**
- `results` (Dict[str, Any]): `search()` 返回的结果
- `query` (str): 搜索查询，用于显示

**返回：**
- `str`: 格式化的搜索结果文本

**示例：**
```python
raw_result = client.search("Python 教程")
formatted = client.format_results(raw_result, "Python 教程")
print(formatted)
```

## 使用示例

### 基础使用
```python
from web_search import WebSearchClient

# 初始化客户端
client = WebSearchClient()

# 网页搜索
result = client.search("Python 编程教程", count=5)
print(client.format_results(result, "Python 编程教程"))
```

### 命令行使用
该模块可直接作为命令行工具使用：
```bash
python scripts/web_search.py "王者荣耀世界 公测日期"
```

## 错误处理

### 常见错误
1. **未找到 API 密钥**：自动提示
   ```
   尊敬的用户，您的skill尚未绑定APIkey ,请输入APIkey进行绑定，如若没有，请前往清风引擎开发者平台注册申请 https://www.qingfengyq.com:9001
   ```
   - 需要在 `.env` 文件中配置 `QINGFENG_API_KEY`

2. **API 密钥错误（401 Unauthorized）**：自动提示
   ```
   尊敬的用户，您当前APIkey不存在，请重新确认后再绑定。
   ```
   - 检查 API 密钥是否正确，确保未过期且有效

3. **额度不足/未开通**（返回 502 Bad Gateway）：自动提示
   ```
   您当前skill 额度不足，请前往清风引擎开发者联系客户经理下单
   ```
   - 当前用户未开通该 Skill 或额度已用完，需要联系客户经理购买额度

4. **获取授权码失败**：会提示接口返回错误信息

5. **网络错误**：`requests.exceptions.RequestException`
   - 检查网络连接
   - 确认 API 端点可访问

6. **API 响应错误**：检查返回的 JSON 结构中的 `code` 字段

### 异常处理示例
```python
from web_search import WebSearchClient
import requests

try:
    client = WebSearchClient()
    result = client.search("测试查询")
    
    print(client.format_results(result, "测试查询"))
        
except ValueError as e:
    print(f"配置错误: {e}")
except requests.exceptions.RequestException as e:
    print(f"网络错误: {e}")
except Exception as e:
    print(f"未知错误: {e}")
```

## 响应格式

### 网页搜索响应结构
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "webPages": {
      "value": [
        {
          "name": "页面标题",
          "url": "https://example.com",
          "snippet": "页面摘要",
          "datePublished": "2023-01-01T00:00:00Z"
        }
      ]
    }
  }
}
```

## 注意事项

1. **速率限制**：请遵守清风AI搜索 API 的速率限制
2. **使用条款**：遵守清风AI搜索平台的使用条款和服务协议
3. **数据隐私**：不要使用该 API 搜索敏感或个人隐私信息
4. **结果准确性**：搜索结果是第三方内容，请自行验证信息的准确性
5. **费用说明**：使用 API 可能会产生费用，请查看清风AI搜索平台的定价信息

## 更新日志

### v1.0.0 (初始版本)
- 实现基本的网页搜索功能
- 提供结果格式化方法
- 支持环境变量配置
- 添加命令行接口

## 支持与反馈

如有问题或建议，请：
1. 查看 [清风AI搜索平台文档](https://www.qingfengyq.com/docs)
2. 提交 Issue 到项目仓库
3. 联系技术支持

---

*最后更新：2026-04-16*  
*兼容版本：CyberSearch.py v1.0.0*
