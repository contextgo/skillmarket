#!/usr/bin/env python3
"""
QingFeng Web Search Skill
清风网页搜索 Skill
"""

import os
import requests
from typing import List, Dict, Optional, Any
from dotenv import load_dotenv
import urllib3

class WebSearchClient:
    """清风网页搜索客户端"""
    
    def __init__(self, api_key: Optional[str] = None, env_path: Optional[str] = None):
        """
        初始化客户端
        :param api_key: API 密钥，如果不提供则从 .env 文件读取
        :param env_path: .env 文件路径，默认为 C:\\Users\\lenovo\\Desktop\\qingfeng-api\\.env
        """
        if api_key is None:
            if env_path is None:
                env_path = "C:\\Users\\lenovo\\Desktop\\qingfeng-api\\.env"
            load_dotenv(env_path)
            api_key = os.getenv("QINGFENG_API_KEY")
        
        if not api_key:
            raise ValueError("QINGFENG_API_KEY not found. Please check your .env file.")
        
        self.api_key = api_key.strip()
        self.base_url = "https://www.qingfengyq.com/api/v1/third-party/skill-tools/other"
        self.auth_url = "https://www.qingfengyq.com/api/v1/third-party/skill-auth/issue"
        self.skill_id = "skill-web-search"
        self.tool_ids = ["skill-tool-web-search"]
        
        # 请求获取授权码
        self.skill_auth_code = self._get_auth_code()
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "X-Skill-Auth-Code": self.skill_auth_code,
            "Content-Type": "application/json"
        }
    
    def _get_auth_code(self) -> str:
        """
        请求接口获取授权码
        :return: 授权码
        """
        payload = {
            "skill_id": self.skill_id,
            "tool_ids": self.tool_ids
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        response = requests.post(self.auth_url, json=payload, headers=headers)
        response.raise_for_status()
        result = response.json()
        
        if "data" not in result or "auth_code" not in result["data"]:
            raise ValueError("获取授权码失败，接口返回格式不正确")
        
        return result["data"]["auth_code"]
    
    def search(self, 
               query: str, 
               count: int = 10, 
               freshness: str = "noLimit") -> Dict[str, Any]:
        """
        执行网页搜索
        :param query: 搜索查询
        :param count: 结果数量，最大 10，默认 10
        :param freshness: 时间过滤 noLimit/day/week/month/year，默认 noLimit
        :return: 搜索结果
        """
        url = f"{self.base_url}/skill-tool-web-search"
        payload = {
            "query": query,
            "count": count,
            "freshness": freshness,
            "summary": True
        }
        
        response = requests.post(url, json=payload, headers=self.headers)
        # 502 Bad Gateway 视为额度不足
        if response.status_code == 502:
            raise PermissionError("当前用户未开通该Skill")
        response.raise_for_status()
        return response.json()
    
    def format_results(self, results: Dict[str, Any], query: str = "") -> str:
        """
        格式化搜索结果为可读文本
        :param results: API 返回结果
        :param query: 搜索查询
        :return: 格式化文本
        """
        if not results or "data" not in results:
            return f"搜索失败: {results}"
        
        data = results["data"]
        if not data or "webPages" not in data:
            import json
            output = []
            output.append("未能识别返回结构，完整响应:")
            output.append(json.dumps(results, indent=2, ensure_ascii=False))
            return "\n".join(output)
        
        output = []
        output.append(f"搜索结果: {query}")
        output.append(f"(服务端已按相关性排序)")
        output.append("")
        
        items = data["webPages"]["value"]
        for i, item in enumerate(items, 1):
            title = item.get("name", "无标题")
            url = item.get("url", "无链接")
            snippet = item.get("snippet", "")
            output.append(f"{i}. **{title}**")
            output.append(f"   链接: {url}")
            if snippet:
                output.append(f"   摘要: {snippet[:150]}...")
            output.append("")
        
        return "\n".join(output)

if __name__ == "__main__":
    # 测试
    import sys
    import codecs
    import requests
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer)
    
    try:
        if len(sys.argv) > 1:
            query = " ".join(sys.argv[1:])
        else:
            # 默认测试
            query = "王者荣耀世界 公测日期"
        
        client = WebSearchClient()
        result = client.search(query)
        print(f"网页搜索: {query}")
        print(client.format_results(result, query))
    except ValueError as e:
        if "QINGFENG_API_KEY not found" in str(e):
            print("\n尊敬的用户，您的skill尚未绑定APIkey ,请输入APIkey进行绑定，如若没有，请前往清风引擎开发者平台注册申请：https://www.qingfengyq.com/login")
        else:
            print(f"\n获取授权码失败: {str(e)}")
    except PermissionError as e:
        if "当前用户未开通该Skill" in str(e):
            print("\n您当前skill 额度不足，请前往清风引擎开发者联系客户经理下单")
        else:
            raise
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            print("\n尊敬的用户，您当前APIkey不存在，请重新确认后再绑定。")
        elif e.response.status_code == 502:
            print("\n您当前skill 额度不足，请前往清风引擎开发者联系客户经理下单")
        else:
            raise
