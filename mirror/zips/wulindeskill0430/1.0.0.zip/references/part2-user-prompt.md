请严格遵循系统提示中的所有设计规范，将以下文档内容转换为完整的单文件 HTML 演示文稿。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【固定品牌值（已写死，无需替换）】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- 全局主色 --blue：#0154BC
- 辅色 --blue-light：#90D0FD
- 竖条色 --blue-bar：#00B0F0（仅用于背景图中的装饰，不在 CSS 中额外使用）
- BTN 字体色：#0154BC

Logo 规范（按页面类型区分）：
- 标题页：使用白色透明版 Logo 图片
  路径：{SKILL_DIR}/assets/images/logo-white-transparent.png
  定位：absolute，底部水平居中（bottom: 40px; left: 50%; transform: translateX(-50%)），高度 60px
- 章节页：使用白色透明版 Logo 图片
  路径：{SKILL_DIR}/assets/images/logo-white-transparent.png
  定位：absolute，右下角（bottom: 28px; right: 36px），高度 52px
- 结束页：使用白色透明版 Logo 图片
  路径：{SKILL_DIR}/assets/images/logo-white-transparent.png
  定位：absolute，左右居中靠底部（bottom: 48px; left: 50%; transform: translateX(-50%)），高度 56px
- 正文页：**不添加额外 Logo**（背景图content-bg.png 左上角已包含 BTN Logo）
- 目录页：使用白色透明版 Logo 图片（放在左侧品牌面板内左上角）
  路径：{SKILL_DIR}/assets/images/logo-white-transparent.png
  定位：.toc-logo-area 容器内 absolute（top: 28px; left: 32px），高度 36px
- 封面 .org-tag：集团物流部

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【转换规则】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 自动拆分：根据文档标题层级（一级标题→章节分隔页，二级标题→内容页标题，三级及以下→卡片/列表内容）

2. 幻灯片数量：根据文档章节自动判断
   - 固定页面：封面(1) + 目录(1) + 致谢页(1) = 3张
   - 动态页面：每个章节 = 1张章节分隔页 + N张内容页（根据该章节下的二级、三级标题数量自动计算）
   - 公式：总数量 = 3 + Σ(1 + 该章节内容页数量)
   - 不设固定上限，内容决定数量

3. 必须包含的固定幻灯片：
   - 第 1 张：封面（s-cover），.org-tag 显示"集团物流部"，.display 显示文档主标题
     背景：全幅背景图（background: url('{SKILL_DIR}/assets/images/cover-bg.png') center center / cover no-repeat）
     标题和副标题为白色，文字阴影增强可读性
     Logo：白色透明版，底部水平居中（bottom: 40px; left: 50%; transform: translateX(-50%)）
   - 第 2 张：目录（s-toc），**左右分栏布局**
     左侧：品牌蓝渐变面板（.toc-left-panel），含白色透明版 Logo、.toc-brand-tag、大标题"目录 CONTENTS"、副标题、装饰线
     右侧：浅蓝白渐变面板（.toc-right-panel），含 .toc-section-title + .toc-grid 目录列表
     .toc-grid 内每项用 .toc-item（渐变圆角序号 + 标题/副标题），带 .toc-animate 交错入场动画
   - 章节开头：章节分隔页（s-chapter），含章节编号大字装饰
     背景：纯蓝 #0154BC 实心填充
     文字全部白色
     Logo：白色透明版，右侧中部
   - 内容页：正文页（s-content）
     使用去水印背景图（content-bg.png）cover 居中填充
     背景图已包含：顶栏蓝条、底栏蓝条、左上角 BTN Logo
     内容区通过 padding 安全区域避让这些保留元素（不额外添加 .side-bar / .top-bar / Logo）
     **不添加**额外的蓝色版 Logo img 标签
   - 最后一张：致谢页（s-thanks）
     背景与封面一致，使用标题页背景图（cover 填充居中）
     "Thanks" 白色大字
     Logo：白色透明版，**左右居中 + 靠底部**
       路径：{SKILL_DIR}/assets/images/logo-white-transparent.png
       定位：absolute，水平居中（bottom: 48px; left: 50%; transform: translateX(-50%)），高度 56px

4. 组件选型逻辑：
   - 并列概念（2~4个） → .cards.cols-N
   - 并列分类（5~8个，强调图标） → .waste-grid
   - 流程/步骤 → .two-col + .step-list
   - 数据/指标 → .stat-row
   - 对比（好/坏、前/后、优/劣） → .contrast-grid
   - 注意事项/风险 → .attention-list（带 emoji 图标）
   - 引用/金句 → .quote-block
   - 总结回顾 → .summary-grid

5. Logo 必须按页面类型使用对应版本的图片（白色透明版 vs 蓝色版），不得混用

6. 所有交互功能必须实现：导航栏、键盘翻页（←→及F全屏）、拖拽排序、删除、撤回、重置、localStorage持久化

7. 必须输出完整可运行的 HTML 文件，不得省略任何 CSS 或 JS

8. 每张内容幻灯片必须包含：
   - .section-label 章节标签（如 "Chapter 01"）
   - 背景图安全区域 padding（确保文字不与背景图装饰重叠）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【文档内容如下】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

（将用户的文档内容粘贴到此处）
