# 模板参考源码（金标准）

> 本文件包含完整的 31 张幻灯片 HTML 参考源码，供 AI 学习 BTN 品牌风格使用。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>精益·AI+ 交流会</title>
<style>
  :root {
    --bg: #eef1f6;
    --fg: #1a1a1c;
    --fg2: #3c3c41;
    --fg3: #5a5a60;
    --blue: #0060c7;
    --blue-hover: #0068d6;
    --accent: #28a745;
    --accent2: #e08800;
    --accent3: #9b44cc;
    --border: rgba(0,0,0,0.12);
    --border-light: rgba(0,0,0,0.07);
    --card-bg: rgba(255,255,255,0.97);
    --ease: cubic-bezier(0.25, 0.1, 0.25, 1);
    --ease-out: cubic-bezier(0, 0, 0.2, 1);
    /* 动态渐变变量 */
    --mouse-x: 50%;
    --mouse-y: 50%;
  }

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--fg);
    overflow: hidden;
    height: 100vh;
    width: 100vw;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-size: 18px;
    font-weight: 500;
  }

  /* ── Scrollable helper ── */
  .slide-inner {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    scrollbar-width: none;
    padding: 56px 0;
  }
  .slide-inner::-webkit-scrollbar { display: none; }

  /* ── Slide Deck ── */
  .deck { width: 100%; height: 100vh; position: relative; }

  .slide {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity .7s var(--ease-out);
  }
  .slide.active {
    opacity: 1;
    pointer-events: all;
  }

  .slide-content {
    max-width: 980px;
    margin: 0 auto;
    padding: 0 80px;
    width: 100%;
  }

  .slide-content.wide {
    max-width: 1200px;
  }

  .slide-content.narrow {
    max-width: 680px;
  }

  /* ── Typography ── */
  .display {
    font-size: clamp(48px, 8vw, 96px);
    font-weight: 700;
    letter-spacing: -0.03em;
    line-height: 1.05;
    color: var(--fg);
  }

  .headline {
    font-size: clamp(28px, 4vw, 48px);
    font-weight: 600;
    letter-spacing: -0.02em;
    line-height: 1.1;
    color: var(--fg);
  }

  .subhead {
    font-size: clamp(20px, 2.5vw, 26px);
    font-weight: 500;
    line-height: 1.4;
    color: var(--fg2);
    letter-spacing: -0.01em;
  }

  .label {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg2);
    margin-bottom: 12px;
  }

  .body-text {
    font-size: 20px;
    font-weight: 500;
    line-height: 1.55;
    color: var(--fg2);
    letter-spacing: -0.01em;
  }

  .caption {
    font-size: 15px;
    font-weight: 500;
    color: var(--fg3);
    letter-spacing: 0;
    line-height: 1.4;
  }

  /* ── Links / CTA ── */
  a {
    color: var(--blue);
    text-decoration: none;
    font-size: 20px;
    font-weight: 500;
    letter-spacing: -0.01em;
  }
  a:hover { color: var(--blue-hover); }

  /* ── Blue accent ── */
  .blue { color: var(--blue); }
  .muted { color: var(--fg2); }

  /* ────────────────────────────────────────────────
     SLIDES
  ──────────────────────────────────────────────── */

  /* Cover */
  .s-cover {
    background: linear-gradient(135deg, #f0f4ff 0%, #e8f0fe 50%, #f5f7fa 100%);
  }
  .s-cover .slide-content {
    text-align: center;
    padding-top: 80px;
  }

  .s-cover .org-tag {
    font-size: clamp(48px, 8vw, 96px);
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: var(--blue);
    margin-bottom: 16px;
    font-weight: 700;
  }

  .s-cover .display {
    background: linear-gradient(135deg, #1d1d1f 40%, #555 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .s-cover .subhead {
    margin-top: 16px;
    font-size: 22px;
    font-weight: 500;
    color: var(--fg2);
  }

  /* Contents */
  .toc-grid {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 36px;
  }

  .toc-item {
    display: flex;
    align-items: center;
    gap: 28px;
    padding: 22px 36px;
    background: #f8f9fc;
    border: 2px solid rgba(0,0,0,0.12);
    border-radius: 14px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
    cursor: default;
  }
  .toc-item:hover {
    box-shadow: 0 8px 30px rgba(255,149,0,0.22), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-3px) scale(1.01);
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.6);
  }

  .toc-num {
    font-size: 32px;
    font-weight: 700;
    color: var(--blue);
    line-height: 1;
    min-width: 48px;
    opacity: 0.75;
    flex-shrink: 0;
  }

  .toc-text {
    font-size: 22px;
    font-weight: 600;
    line-height: 1.3;
    color: var(--fg);
  }

  .toc-sub {
    font-size: 17px;
    color: var(--fg2);
    margin-top: 4px;
    line-height: 1.5;
  }

  /* Chapter divider */
  .s-chapter {
    background: linear-gradient(135deg, #f0f4ff 0%, #fafafa 100%);
  }
  .s-chapter .slide-content {
    padding-top: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    height: 100vh;
  }
  .chap-eyebrow {
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--blue);
    margin-bottom: 14px;
  }
  .chap-num {
    position: absolute;
    right: 80px;
    top: 50%;
    transform: translateY(-50%);
    font-size: clamp(200px, 25vw, 380px);
    font-weight: 800;
    color: rgba(0,113,227,0.05);
    letter-spacing: -0.05em;
    line-height: 1;
    pointer-events: none;
    user-select: none;
  }

  /* Content slide */
  .s-content .slide-inner {
    display: flex;
    align-items: center;
  }

  .slide-divider {
    width: 40px;
    height: 1px;
    background: rgba(0,0,0,0.12);
    margin: 20px 0;
  }

  /* Cards grid */
  .cards {
    display: grid;
    gap: 12px;
    margin-top: 32px;
  }
  .cards.cols-2 { grid-template-columns: 1fr 1fr; }
  .cards.cols-3 { grid-template-columns: 1fr 1fr 1fr; }
  .cards.cols-4 { grid-template-columns: 1fr 1fr 1fr 1fr; }

  .card {
    padding: 32px 36px;
    background: #f8f9fc;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 18px;
    box-shadow: 0 2px 16px rgba(0,0,0,0.09);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .card:hover {
    box-shadow: 0 10px 35px rgba(255,149,0,0.25), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-4px) scale(1.015);
    background: linear-gradient(140deg, #fff9ed 0%, #fff0d8 35%, #ffeecf 65%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.65);
  }

  .card-title {
    font-size: 24px;
    font-weight: 700;
    color: var(--fg);
    margin-bottom: 12px;
    letter-spacing: -0.01em;
  }

  .card-body {
    font-size: 18px;
    font-weight: 500;
    line-height: 1.6;
    color: var(--fg);
  }

  .card-icon {
    font-size: 36px;
    margin-bottom: 18px;
    display: block;
  }

  .card-tag {
    display: inline-block;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    padding: 4px 12px;
    border-radius: 20px;
    background: rgba(0,113,227,0.12);
    color: var(--blue);
    margin-bottom: 14px;
  }

  /* Waste grid */
  .waste-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin-top: 32px;
  }

  .waste-card {
    padding: 30px 24px;
    background: #f8f9fc;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 18px;
    text-align: center;
    box-shadow: 0 2px 16px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .waste-card:hover {
    box-shadow: 0 10px 32px rgba(255,149,0,0.24), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-4px) scale(1.018);
    background: linear-gradient(140deg, #fff9ed 0%, #fff0d8 35%, #ffeecf 65%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.65);
  }

  .waste-icon { font-size: 36px; margin-bottom: 14px; }

  .waste-name {
    font-size: 20px;
    font-weight: 700;
    color: var(--fg);
    margin-bottom: 8px;
  }

  .waste-desc {
    font-size: 16px;
    font-weight: 500;
    color: var(--fg);
    line-height: 1.6;
  }

  /* Two column */
  .two-col {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 32px;
  }

  .col-head {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg2);
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid rgba(0,0,0,0.06);
  }

  .step-list { margin-top: 0; }
  .step {
    display: flex;
    gap: 18px;
    padding: 16px 0;
    border-bottom: 1px solid rgba(0,0,0,0.04);
  }
  .step:last-child { border-bottom: none; }
  .step-num {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 1px solid var(--fg3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 600;
    color: var(--fg2);
    flex-shrink: 0;
  }
  .step-title { font-size: 18px; font-weight: 600; color: var(--fg); margin-bottom: 4px; }
  .step-desc { font-size: 16px; font-weight: 500; color: var(--fg2); line-height: 1.55; }

  /* Challenge grid */
  .challenge-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 32px;
  }

  .challenge-card {
    padding: 30px 34px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 18px;
    background: #f8f9fc;
    box-shadow: 0 2px 16px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .challenge-card:hover {
    box-shadow: 0 10px 32px rgba(255,149,0,0.24), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-4px) scale(1.015);
    background: linear-gradient(140deg, #fff9ed 0%, #fff0d8 35%, #ffeecf 65%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.65);
  }

  .challenge-label {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg2);
    margin-bottom: 12px;
  }

  .challenge-title {
    font-size: 22px;
    font-weight: 700;
    color: var(--fg);
    margin-bottom: 14px;
  }

  .challenge-row {
    font-size: 17px;
    font-weight: 500;
    line-height: 1.65;
    margin-bottom: 6px;
    color: var(--fg);
  }

  .challenge-row strong { color: var(--fg); }

  /* Stats */
  .stat-row {
    display: flex;
    gap: 12px;
    margin-top: 32px;
  }

  .stat {
    flex: 1;
    padding: 24px 20px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 16px;
    text-align: center;
    background: #f8f9fc;
    box-shadow: 0 2px 16px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .stat:hover {
    box-shadow: 0 10px 32px rgba(255,149,0,0.24), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-4px) scale(1.018);
    background: linear-gradient(140deg, #fff9ed 0%, #fff0d8 35%, #ffeecf 65%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.65);
  }

  .stat-num {
    font-size: clamp(36px, 4vw, 52px);
    font-weight: 700;
    letter-spacing: -0.03em;
    background: linear-gradient(135deg, #1a1a1c, #0060c7);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
  }

  .stat-label {
    font-size: 16px;
    font-weight: 500;
    color: var(--fg2);
    margin-top: 6px;
    line-height: 1.4;
  }

  /* Quote */
  .quote-block {
    margin-top: 28px;
    padding: 18px 22px;
    border-left: 3px solid var(--blue);
    font-size: 18px;
    font-weight: 500;
    line-height: 1.7;
    color: var(--fg2);
    font-style: italic;
    background: rgba(0,96,199,0.06);
    border-radius: 0 12px 12px 0;
    transition: background .35s var(--ease), border-left-color .35s var(--ease), transform .35s var(--ease), box-shadow .35s var(--ease);
  }
  .quote-block:hover {
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    border-left-color: rgba(255,149,0,0.9);
    transform: translateX(4px);
    box-shadow: 0 6px 20px rgba(255,149,0,0.2);
  }

  /* Principles */
  .principle {
    padding: 22px 26px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 16px;
    margin-top: 12px;
    background: #f8f9fc;
    box-shadow: 0 2px 14px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .principle:hover {
    box-shadow: 0 8px 30px rgba(255,149,0,0.22), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-3px) scale(1.01);
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.6);
  }

  .principle-label {
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg2);
    margin-bottom: 8px;
  }

  .principle-title {
    font-size: 20px;
    font-weight: 700;
    color: var(--fg);
    margin-bottom: 10px;
  }

  .eg-bad, .eg-good {
    padding: 12px 16px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 500;
    line-height: 1.6;
    margin-top: 8px;
  }

  .eg-bad {
    background: rgba(220,40,30,0.12);
    border: 2px solid rgba(220,40,30,0.45);
    color: #b52020;
  }

  .eg-good {
    background: rgba(30,140,60,0.12);
    border: 2px solid rgba(30,140,60,0.45);
    color: #1a7a38;
  }

  /* Example blocks */
  .example-block {
    padding: 20px 24px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 16px;
    margin-top: 12px;
    background: #f8f9fc;
    box-shadow: 0 2px 14px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .example-block:hover {
    box-shadow: 0 8px 28px rgba(255,149,0,0.2), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-3px) scale(1.01);
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.6);
  }

  /* Tags */
  .tag-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 12px;
  }

  .tag {
    padding: 5px 14px;
    border-radius: 20px;
    font-size: 15px;
    font-weight: 500;
    border: 1px solid rgba(0,0,0,0.2);
    color: var(--fg);
    background: rgba(0,0,0,0.06);
    letter-spacing: -0.01em;
  }

  /* Attention list */
  .attention-list { margin-top: 32px; }

  .att-item {
    display: flex;
    gap: 20px;
    padding: 20px 16px;
    border-bottom: 1px solid rgba(0,0,0,0.04);
    align-items: flex-start;
    border-radius: 12px;
    transition: background .35s var(--ease), transform .35s var(--ease), box-shadow .35s var(--ease);
  }
  .att-item:hover {
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    transform: translateX(4px);
    box-shadow: inset 3px 0 0 rgba(255,149,0,0.7), 0 4px 12px rgba(255,149,0,0.15);
  }
  .att-item:first-child { padding-top: 0; }
  .att-item:last-child { border-bottom: none; }

  .att-icon { font-size: 26px; flex-shrink: 0; margin-top: 2px; }
  .att-title { font-size: 20px; font-weight: 700; color: var(--fg); margin-bottom: 5px; }
  .att-body { font-size: 16px; font-weight: 500; color: var(--fg); line-height: 1.6; }

  /* Two-column contrast (误区 vs 正确) */
  .contrast-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 32px;
  }

  .contrast-card {
    padding: 24px 28px;
    border-radius: 16px;
    border: 2px solid rgba(0,0,0,0.15);
    box-shadow: 0 2px 14px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), filter .35s var(--ease);
  }
  .contrast-card:hover {
    box-shadow: 0 8px 26px rgba(255,149,0,0.10), 0 2px 8px rgba(0,0,0,0.06);
    transform: translateY(-3px) scale(1.012);
    filter: brightness(1.025) saturate(1.05);
  }

  .contrast-card.wrong {
    background: rgba(220,40,30,0.12);
    border-color: rgba(220,40,30,0.4);
  }

  .contrast-card.right {
    background: rgba(30,140,60,0.12);
    border-color: rgba(30,140,60,0.4);
  }

  .contrast-label {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.05em;
    margin-bottom: 14px;
  }
  .contrast-card.wrong .contrast-label { color: #b52020; }
  .contrast-card.right .contrast-label { color: #1a7a38; }

  .contrast-item {
    font-size: 16px;
    font-weight: 500;
    color: var(--fg);
    line-height: 1.6;
    margin-bottom: 8px;
    padding-left: 14px;
    position: relative;
  }
  .contrast-card.wrong .contrast-item::before { content: '—'; position: absolute; left: 0; color: #b52020; }
  .contrast-card.right .contrast-item::before { content: '✓'; position: absolute; left: 0; color: #1a7a38; }

  /* Summary grid */
  .summary-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 36px;
  }

  .summary-card {
    padding: 24px 28px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 16px;
    background: #f8f9fc;
    box-shadow: 0 2px 14px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .summary-card:hover {
    box-shadow: 0 10px 32px rgba(255,149,0,0.24), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-4px) scale(1.015);
    background: linear-gradient(140deg, #fff9ed 0%, #fff0d8 35%, #ffeecf 65%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.65);
  }

  .s-num {
    font-size: 15px;
    font-weight: 700;
    color: var(--blue);
    letter-spacing: 0.05em;
    margin-bottom: 8px;
  }

  .s-title {
    font-size: 20px;
    font-weight: 700;
    color: var(--fg);
    margin-bottom: 8px;
  }

  .s-body {
    font-size: 16px;
    font-weight: 500;
    color: var(--fg);
    line-height: 1.6;
  }

  /* Thanks */
  .s-thanks {
    background: linear-gradient(135deg, #f0f4ff 0%, #e8f0fe 50%, #f5f7fa 100%);
  }
  .s-thanks .slide-content {
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  .thanks-word {
    font-size: clamp(72px, 12vw, 140px);
    font-weight: 700;
    letter-spacing: -0.04em;
    background: linear-gradient(135deg, #1d1d1f 30%, #555 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
  }

  .thanks-sub {
    margin-top: 20px;
    font-size: 18px;
    font-weight: 500;
    color: var(--fg2);
    letter-spacing: 0.05em;
  }

  /* Info block */
  .info-block {
    margin-top: 20px;
    padding: 18px 22px;
    border: 2px solid rgba(0,0,0,0.15);
    border-radius: 12px;
    font-size: 17px;
    font-weight: 500;
    line-height: 1.65;
    color: var(--fg);
    background: #f8f9fc;
    box-shadow: 0 2px 14px rgba(0,0,0,0.08);
    transition: box-shadow .35s var(--ease), transform .35s var(--ease), background .35s var(--ease), border-color .35s var(--ease);
  }
  .info-block:hover {
    box-shadow: 0 8px 28px rgba(255,149,0,0.2), 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-3px) scale(1.01);
    background: linear-gradient(135deg, #fff9ed 0%, #fff0d8 30%, #ffeecf 70%, #fff7e0 100%);
    border-color: rgba(255,149,0,0.6);
  }

  .info-block strong { color: var(--fg); }

  /* Section label */
  .section-label {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--blue);
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .section-label::before {
    content: '';
    width: 16px;
    height: 1px;
    background: var(--blue);
  }

  /* ── Nav ── */
  .nav {
    position: fixed;
    bottom: 20px;
    right: 20px;
    left: auto;
    transform: none;
    z-index: 100;
  }

  .nav-normal {
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding: 8px 16px;
    border-radius: 30px;
    border: 1px solid rgba(0,0,0,0.08);
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  }

  .nav button {
    background: none;
    border: none;
    color: var(--fg);
    cursor: pointer;
    font-size: 14px;
    padding: 4px 8px;
    border-radius: 6px;
    transition: background .2s, opacity .2s;
    opacity: 0.6;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .nav button:hover { background: rgba(0,0,0,0.06); opacity: 1; }
  .nav button:disabled { opacity: 0.2; cursor: default; }

  .slide-counter {
    font-size: 14px;
    font-weight: 600;
    color: var(--fg2);
    min-width: 55px;
    text-align: center;
    letter-spacing: 0.5px;
  }

  .dots {
    display: flex;
    align-items: center;
    gap: 3px;
    max-width: 80px;
    overflow: hidden;
  }

  .dot {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: var(--fg3);
    cursor: pointer;
    transition: background .2s, transform .2s;
    flex-shrink: 0;
  }
  .dot.active { background: var(--blue); transform: scale(1.2); }

  .nav-divider {
    width: 1px;
    height: 16px;
    background: rgba(0,0,0,0.1);
    margin: 0 2px;
    flex-shrink: 0;
  }

  .nav-minimal {
    display: flex;
    align-items: center;
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding: 6px 12px;
    border-radius: 20px;
    border: 1px solid rgba(0,0,0,0.08);
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  }

  /* Progress */
  .progress {
    position: fixed;
    top: 0; left: 0;
    height: 3.9px;
    background: var(--blue);
    transition: width .5s var(--ease-out);
    z-index: 200;
    border-radius: 0 2px 2px 0;
  }

  /* Settings Button */
  .settings-btn {
    position: fixed;
    top: 20px;
    right: 20px;
    width: 32px;
    height: 32px;
    border: none;
    background: rgba(255,255,255,0.8);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background .2s, transform .2s, opacity .3s;
    border: 1px solid rgba(0,0,0,0.08);
  }
  .settings-btn:hover {
    background: rgba(255,255,255,0.95);
    transform: rotate(30deg);
  }
  .settings-btn.hidden {
    opacity: 0;
    pointer-events: none;
  }

  /* Settings Panel */
  .settings-panel {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 600px;
    max-width: 90vw;
    max-height: 80vh;
    background: rgba(255,255,255,0.98);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    flex-direction: column;
  }

  .settings-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.4);
    z-index: 999;
  }

  .settings-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    border-bottom: 1px solid rgba(0,0,0,0.08);
    font-weight: 600;
    color: var(--fg);
  }

  .settings-close {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 4px;
    opacity: 0.6;
    transition: opacity .2s;
  }
  .settings-close:hover { opacity: 1; }

  .settings-content {
    padding: 16px;
    overflow-y: auto;
    flex: 1;
    position: relative;
  }
  .settings-content::after {
    content: '拖动到底部将自动滚动';
    position: sticky;
    bottom: 0;
    left: 0;
    right: 0;
    text-align: center;
    font-size: 11px;
    color: var(--fg3);
    padding: 8px;
    background: linear-gradient(transparent, rgba(255,255,255,0.9));
    pointer-events: none;
    opacity: 0;
    transition: opacity .3s;
  }
  .settings-content.scroll-hint::after {
    opacity: 1;
  }

  .sortable-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 14px;
    background: #f8f8f8;
    border-radius: 10px;
    margin-bottom: 6px;
    cursor: grab;
    transition: background .2s, transform .2s, box-shadow .2s, opacity .2s;
    user-select: none;
    position: relative;
  }
  .sortable-item:hover {
    background: #f0f0f0;
  }
  .sortable-item.dragging {
    background: #d4e5ff;
    box-shadow: 0 6px 20px rgba(0,113,227,0.25);
    transform: scale(1.03);
    z-index: 1000;
    opacity: 0.9;
    cursor: grabbing;
  }
  .sortable-item.dragover {
    background: #e8f0ff;
    border-top: 3px solid var(--blue);
    margin-top: -3px;
  }
  .sortable-item.dragover::before {
    content: '';
    position: absolute;
    top: -3px;
    left: 0;
    right: 0;
    height: 3px;
    background: var(--blue);
    border-radius: 2px;
  }

  .sortable-handle {
    color: var(--fg3);
    font-size: 14px;
    cursor: grab;
  }

  .sortable-num {
    font-size: 12px;
    font-weight: 600;
    color: var(--blue);
    min-width: 28px;
  }

  .sortable-title {
    flex: 1;
    font-size: 14px;
    color: var(--fg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Global Logo on every slide - 三行布局，BTN 大小固定，下面两行缩小对齐 */
  .slide-logo {
    position: fixed;
    top: 18px;
    left: 24px;
    z-index: 100;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 1px;
    text-decoration: none;
    user-select: none;
  }
  /* 第一行：BTN 大字，固定大小 */
  .slide-logo-text {
    font-size: 30px;
    font-weight: 900;
    letter-spacing: 1px;
    color: #0057B8;
    -webkit-text-fill-color: #0057B8;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    line-height: 1;
    white-space: nowrap;
  }
  /* 第二行：贝泰妮集团 中文，缩小字号，两端对齐 BTN 宽度 */
  .slide-logo-sub {
    display: flex;
    justify-content: space-between;
    width: 100%;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: -0.5px;
    color: #1a1a1a;
    -webkit-text-fill-color: #1a1a1a;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'PingFang SC', sans-serif;
    line-height: 1;
    margin-top: 2px;
  }
  /* 第三行：BOTANEE GROUP 英文，缩小字号，两端对齐 BTN 宽度 */
  .slide-logo-en {
    display: flex;
    justify-content: space-between;
    width: 100%;
    font-size: 7.5px;
    font-weight: 500;
    letter-spacing: -0.3px;
    color: #1a1a1a;
    text-transform: uppercase;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif;
    opacity: 0.85;
    line-height: 1;
    margin-top: 2px;
  }

  /* TOC grid border removed (flex layout) */

  /* ── Animations ── */
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(18px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* 逐字出现动画 */
  @keyframes charFadeIn {
    from { opacity: 0; transform: translateY(12px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .quote-text-row .char {
    display: inline-block;
    opacity: 0;
  }
  .slide.active .quote-text-row .char {
    animation: charFadeIn 0.5s var(--ease-out) forwards;
  }
  /* 逐字延迟 - 第一行 */
  .slide.active .quote-text-row:first-of-type .char:nth-child(1) { animation-delay: 0.15s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(2) { animation-delay: 0.25s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(3) { animation-delay: 0.35s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(4) { animation-delay: 0.45s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(5) { animation-delay: 0.55s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(6) { animation-delay: 0.65s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(7) { animation-delay: 0.75s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(8) { animation-delay: 0.85s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(9) { animation-delay: 0.95s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(10) { animation-delay: 1.05s; }
  .slide.active .quote-text-row:first-of-type .char:nth-child(11) { animation-delay: 1.15s; }
  /* 逐字延迟 - 第二行（从第一行结束后开始） */
  .slide.active .quote-text-row:last-of-type .char:nth-child(1) { animation-delay: 1.4s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(2) { animation-delay: 1.5s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(3) { animation-delay: 1.6s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(4) { animation-delay: 1.7s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(5) { animation-delay: 1.8s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(6) { animation-delay: 1.9s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(7) { animation-delay: 2.0s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(8) { animation-delay: 2.1s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(9) { animation-delay: 2.2s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(10) { animation-delay: 2.3s; }
  .slide.active .quote-text-row:last-of-type .char:nth-child(11) { animation-delay: 2.4s; }

  /* 目录项依次出现动画 - 使用 nth-child 选择器 */
  .toc-animate {
    opacity: 0;
    transform: translateY(20px);
  }
  .slide.active .toc-grid .toc-animate {
    animation: fadeUp .6s var(--ease-out) forwards;
  }
  .slide.active .toc-grid .toc-animate:nth-child(1) { animation-delay: 0.3s; }
  .slide.active .toc-grid .toc-animate:nth-child(2) { animation-delay: 0.8s; }
  .slide.active .toc-grid .toc-animate:nth-child(3) { animation-delay: 1.3s; }
  .slide.active .toc-grid .toc-animate:nth-child(4) { animation-delay: 1.8s; }

  .slide.active .display,
  .slide.active .headline,
  .slide.active .subhead,
  .slide.active .section-label,
  .slide.active .label,
  .slide.active .org-tag,
  .slide.active .chap-eyebrow,
  .slide.active .toc-grid,
  .slide.active .cards,
  .slide.active .waste-grid,
  .slide.active .two-col,
  .slide.active .challenge-grid,
  .slide.active .stat-row,
  .slide.active .attention-list,
  .slide.active .contrast-grid,
  .slide.active .summary-grid,
  .slide.active .slide-divider {
    animation: fadeUp .8s var(--ease-out) both;
  }

  .slide.active .headline { animation-delay: .05s; }
  .slide.active .subhead { animation-delay: .12s; }
  .slide.active .section-label { animation-delay: .04s; }
  .slide.active .label { animation-delay: .04s; }
  .slide.active .toc-grid,
  .slide.active .cards,
  .slide.active .waste-grid,
  .slide.active .two-col,
  .slide.active .challenge-grid,
  .slide.active .stat-row,
  .slide.active .attention-list,
  .slide.active .contrast-grid,
  .slide.active .summary-grid { animation-delay: .15s; }

  /* ── Responsive ── */
  @media (max-width: 768px) {
    .slide-content { padding: 0 28px; }
    .slide-logo-en { display: none; }
    .cards.cols-2, .cards.cols-3, .cards.cols-4,
    .waste-grid, .challenge-grid,
    .two-col, .summary-grid, .contrast-grid {
      grid-template-columns: 1fr;
    }
    .stat-row { flex-direction: column; }
    .chap-num { display: none; }
  }
</style>
</head>
<body>


<div class="progress" id="progress"></div>

<!-- Logo on every slide -->
<div class="slide-logo">
  <div class="slide-logo-text">BTN</div>
  <div class="slide-logo-sub"><span>贝</span><span>泰</span><span>妮</span><span>集</span><span>团</span></div>
  <div class="slide-logo-en"><span>BOTANEE</span><span>GROUP</span></div>
</div>

<div class="deck" id="deck">

  <!-- ══ Slide 1 Cover ══ -->
  <div class="slide s-cover active" data-index="0">
    <div class="slide-content" style="padding-top:0;padding-left:48px">
      <div class="org-tag">集团物流部</div>
      <div class="display">精益<span class="blue">·</span>AI<span style="color:var(--fg2)">+</span> 交流会</div>
      <div class="subhead" style="margin-top:18px">精益管理 × 人工智能 &nbsp;·&nbsp; 融合共创</div>
    </div>
  </div>

  <!-- ══ Slide 2 目录 ══ -->
  <div class="slide s-content" data-index="1">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="label">CONTENTS</div>
        <div class="headline">分享内容</div>
        <div class="toc-grid">
          <div class="toc-item toc-animate">
            <div class="toc-num">01</div>
            <div>
              <div class="toc-text">精益理念</div>
              <div class="toc-sub">核心概念与消除浪费</div>
            </div>
          </div>
          <div class="toc-item toc-animate">
            <div class="toc-num">02</div>
            <div>
              <div class="toc-text">当精益与 AI 碰撞</div>
              <div class="toc-sub">个人与组织准备 · 挑战应对</div>
            </div>
          </div>
          <div class="toc-item toc-animate">
            <div class="toc-num">03</div>
            <div>
              <div class="toc-text">常见 AI 使用技巧</div>
              <div class="toc-sub">提示词七原则 · 进阶实战</div>
            </div>
          </div>
          <div class="toc-item toc-animate">
            <div class="toc-num">04</div>
            <div>
              <div class="toc-text">使用 AI 时的注意事项</div>
              <div class="toc-sub">安全 · 合规 · 边界意识</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 3 精益简介 ══ -->
  <div class="slide s-content" data-index="2">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 01</div>
        <div class="headline">精益简介</div>
        <div class="slide-divider"></div>
        <div class="cards cols-2" style="margin-bottom:0">
          <div class="card">
            <div class="card-tag">是什么</div>
            <div class="card-title">什么是精益？</div>
            <div class="card-body">源于丰田生产方式，核心在于<strong style="color:var(--fg)">消除浪费、持续改进、追求卓越</strong>。不仅关注流程优化，更是一种以客户为中心、追求价值最大化的管理文化。</div>
          </div>
          <div class="card">
            <div class="card-tag">为什么</div>
            <div class="card-title">为何要精益？</div>
            <div class="card-body" style="display:flex;flex-direction:column;gap:6px">
              <div class="tag-list" style="margin-top:0">
                <span class="tag">提升效率</span>
                <span class="tag">降低成本</span>
              </div>
              <div class="tag-list">
                <span class="tag">增强质量</span>
                <span class="tag">促进创新</span>
              </div>
            </div>
          </div>
        </div>
        <div class="card" style="margin-top:12px">
          <div class="card-tag">为何申报</div>
          <div class="card-title">为何立项？</div>
          <div class="card-body">精益杜绝的不仅是物质浪费，更包括时间、信息、技能乃至<strong style="color:var(--fg)">创意</strong>上的未充分利用。经过讨论可推广到更多环节，创造更大价值。</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 4 七种浪费 ══ -->
  <div class="slide s-content" data-index="3">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 01</div>
        <div class="headline">七种浪费</div>
        <div class="subhead" style="margin-top:6px">精益强调识别并消除物流中的七大浪费</div>
        <div class="waste-grid">
          <div class="waste-card">
            <div class="waste-icon">📦</div>
            <div class="waste-name">过量生产</div>
            <div class="waste-desc">提前备货过多、库存积压</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">⏳</div>
            <div class="waste-name">等待</div>
            <div class="waste-desc">作业等待、设备空转</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">🚚</div>
            <div class="waste-name">搬运</div>
            <div class="waste-desc">多余路径、重复装卸</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">🗄️</div>
            <div class="waste-name">库存过剩</div>
            <div class="waste-desc">过多库存占用空间与资金</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">🚶</div>
            <div class="waste-name">动作浪费</div>
            <div class="waste-desc">员工走动多、重复操作</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">⚙️</div>
            <div class="waste-name">过度加工</div>
            <div class="waste-desc">包装过度、不必要流程</div>
          </div>
          <div class="waste-card">
            <div class="waste-icon">❌</div>
            <div class="waste-name">缺陷</div>
            <div class="waste-desc">错发、漏发、包装破损</div>
          </div>
          <div class="waste-card" style="border-color:rgba(0,113,227,0.2);">
            <div class="waste-icon">🎯</div>
            <div class="waste-name">优化目标</div>
            <div class="waste-desc" style="color:var(--blue)">流程观察 → 数据收集 → 逐步优化</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 5 精益落地三要素 ══ -->
  <div class="slide s-content" data-index="4">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 01</div>
        <div class="headline">精益落地三要素</div>
        <div class="cards cols-3" style="margin-top:32px;align-items:stretch">
          <div class="card" style="position:relative;overflow:hidden;display:flex;flex-direction:column">
            <!-- 背景装饰大字 -->
            <div style="position:absolute;right:-10px;bottom:-18px;font-size:110px;opacity:0.04;font-weight:900;line-height:1;pointer-events:none;user-select:none">01</div>
            <div class="card-icon">💡</div>
            <div class="card-tag">01</div>
            <div class="card-title">打破固有观念</div>
            <div class="card-body" style="flex:1">以最少投入获得最多产出，消除非增值环节，实现资源高效利用。打破"事情就是这样做的"固化思维。</div>
            <div class="tag-list" style="margin-top:auto;padding-top:16px">
              <span class="tag">消除浪费</span>
              <span class="tag">高效利用</span>
              <span class="tag">思维突破</span>
            </div>
          </div>
          <div class="card" style="position:relative;overflow:hidden;display:flex;flex-direction:column">
            <div style="position:absolute;right:-10px;bottom:-18px;font-size:110px;opacity:0.04;font-weight:900;line-height:1;pointer-events:none;user-select:none">02</div>
            <div class="card-icon">🔄</div>
            <div class="card-tag">02</div>
            <div class="card-title">改变作业习惯</div>
            <div class="card-body" style="flex:1">学习其他行业或同行的作业方式，突破现场固有思维，持续改善每一个作业环节。</div>
            <div class="tag-list" style="margin-top:auto;padding-top:16px">
              <span class="tag">补货流程</span>
              <span class="tag">拣货流程</span>
              <span class="tag">组装流程</span>
              <span class="tag">退货流程</span>
            </div>
          </div>
          <div class="card" style="position:relative;overflow:hidden;display:flex;flex-direction:column">
            <div style="position:absolute;right:-10px;bottom:-18px;font-size:110px;opacity:0.04;font-weight:900;line-height:1;pointer-events:none;user-select:none">03</div>
            <div class="card-icon">⚙️</div>
            <div class="card-tag">03</div>
            <div class="card-title">整合优化流程</div>
            <div class="card-body" style="flex:1">深度思考当前流程是否合理，是否还有更完善的方案——更便捷 / 更少投入 / 更高产出。</div>
            <div class="tag-list" style="margin-top:auto;padding-top:16px">
              <span class="tag">更便捷</span>
              <span class="tag">更少投入</span>
              <span class="tag">更高产出</span>
            </div>
          </div>
        </div>
        <!-- 底部连接线示意 -->
        <div style="display:flex;align-items:center;justify-content:center;margin-top:28px;gap:0">
          <div style="display:flex;align-items:center;gap:6px;padding:10px 22px;background:#fff;border-radius:30px;border:1px solid rgba(0,113,227,0.15);box-shadow:0 2px 10px rgba(0,0,0,0.05)">
            <span style="font-size:13px;color:var(--blue);font-weight:600">精益落地</span>
            <span style="color:var(--fg3);font-size:13px">=</span>
            <span style="font-size:13px;color:var(--fg2)">观念革新</span>
            <span style="color:var(--fg3);font-size:13px">+</span>
            <span style="font-size:13px;color:var(--fg2)">行为改变</span>
            <span style="color:var(--fg3);font-size:13px">+</span>
            <span style="font-size:13px;color:var(--fg2)">流程优化</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 6 Chapter 2 ══ -->
  <div class="slide s-chapter" data-index="5">
    <div class="chap-num">02</div>
    <div class="slide-content" style="position:relative;z-index:1">
      <div class="chap-eyebrow">Chapter 02</div>
      <div class="display">当精益与<br>AI 碰撞</div>
      <div class="subhead" style="margin-top:18px;max-width:600px">个人与组织的准备 · 实践挑战 · 自动化 · 工作流</div>
    </div>
  </div>

  <!-- ══ Slide 7 个人与组织准备 ══ -->
  <div class="slide s-content" data-index="6">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 02</div>
        <div class="headline">个人与组织的准备</div>
        <div class="two-col">
          <div>
            <div class="col-head">个人准备</div>
            <div class="step-list">
              <div class="step">
                <div class="step-num">1</div>
                <div>
                  <div class="step-title">持续学习</div>
                  <div class="step-desc">掌握提示词工程、智能体应用等 AI 技能，提升数字素养。</div>
                </div>
              </div>
              <div class="step">
                <div class="step-num">2</div>
                <div>
                  <div class="step-title">培养软实力</div>
                  <div class="step-desc">发展创造力、批判性思维与情感智慧，构建 AI 难以替代的核心优势。</div>
                </div>
              </div>
              <div class="step">
                <div class="step-num">3</div>
                <div>
                  <div class="step-title">拥抱变化</div>
                  <div class="step-desc">保持开放心态，积极适应新技术带来的工作方式变革。</div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="col-head">组织准备</div>
            <div class="step-list">
              <div class="step">
                <div class="step-num">1</div>
                <div>
                  <div class="step-title">制定 AI 战略</div>
                  <div class="step-desc">明确 AI 定位与目标，制定清晰的实施路线图，引领数字化转型。</div>
                </div>
              </div>
              <div class="step">
                <div class="step-num">2</div>
                <div>
                  <div class="step-title">投资员工培训</div>
                  <div class="step-desc">提供 AI 技能赋能培训，帮助员工适应人机协作的新工作模式。</div>
                </div>
              </div>
              <div class="step">
                <div class="step-num">3</div>
                <div>
                  <div class="step-title">营造创新文化</div>
                  <div class="step-desc">鼓励尝试 AI 工具，建立容错机制，激发全员创新活力。</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="info-block" style="margin-top:20px">
          <strong>核心目标：</strong>通过个人能力升级与组织机制优化，构建人机协同的未来竞争力。
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 8 实践挑战 ══ -->
  <div class="slide s-content" data-index="7">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 02</div>
        <div class="headline">实践挑战与应对策略</div>
        <div class="challenge-grid">
          <div class="challenge-card">
            <div class="challenge-label">挑战</div>
            <div class="challenge-title">🔒 数据安全与隐私</div>
            <div class="challenge-row"><strong>挑战：</strong>AI 训练涉及大量敏感数据，存在泄露风险。</div>
            <div class="challenge-row" style="margin-top:8px"><strong>策略：</strong>采用私有化部署、数据脱敏及严格访问控制。</div>
          </div>
          <div class="challenge-card">
            <div class="challenge-label">挑战</div>
            <div class="challenge-title">💰 模型选择与成本</div>
            <div class="challenge-row"><strong>挑战：</strong>模型众多选择难，训练推理成本高昂。</div>
            <div class="challenge-row" style="margin-top:8px"><strong>策略：</strong>按需选型，利用开源模型和云服务降本增效。</div>
          </div>
          <div class="challenge-card">
            <div class="challenge-label">挑战</div>
            <div class="challenge-title">🎓 员工技能转型</div>
            <div class="challenge-row"><strong>挑战：</strong>缺乏 AI 技能，存在抵触情绪。</div>
            <div class="challenge-row" style="margin-top:8px"><strong>策略：</strong>开展技能培训，组建专家团队，鼓励工具试用。</div>
          </div>
          <div class="challenge-card">
            <div class="challenge-label">挑战</div>
            <div class="challenge-title">⚖️ 伦理与合规风险</div>
            <div class="challenge-row"><strong>挑战：</strong>决策偏见、版权及合规隐患。</div>
            <div class="challenge-row" style="margin-top:8px"><strong>策略：</strong>建立伦理审查机制，确保符合法规与价值观。</div>
          </div>
        </div>
        <div class="quote-block">AI 落地是一场持久战，唯有正视挑战、科学应对，方能行稳致远。</div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 9 自动化工作流 ══ -->
  <div class="slide s-content" data-index="8">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 02</div>
        <div class="headline">自动化工作流与智能助手</div>
        <div class="cards cols-3" style="margin-bottom:0">
          <div class="card">
            <div class="card-icon">🤖</div>
            <div class="card-title">应用场景</div>
            <div class="card-body">利用 AI 智能体自动完成周报生成、会议纪要整理、数据分析报告及客户跟进提醒等重复性工作。</div>
          </div>
          <div class="card">
            <div class="card-icon">✨</div>
            <div class="card-title">核心价值</div>
            <div class="card-body">AI 自动汇总数据生成初稿，员工只需审核调整，专注于高价值的创造性工作。</div>
          </div>
          <div class="card">
            <div class="card-icon">📈</div>
            <div class="card-title">实施效果</div>
            <div class="card-body">行政与运营人员重复性工作时间减少，整体工作效率大幅提升。</div>
          </div>
        </div>
        <div class="stat-row">
          <div class="stat">
            <div class="stat-num">50%</div>
            <div class="stat-label">重复性工作时间减少</div>
          </div>
          <div class="stat">
            <div class="stat-num">30%</div>
            <div class="stat-label">整体工作效率提升</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 10 Chapter 3 ══ -->
  <div class="slide s-chapter" data-index="9">
    <div class="chap-num">03</div>
    <div class="slide-content" style="position:relative;z-index:1">
      <div class="chap-eyebrow">Chapter 03</div>
      <div class="display">常见 AI<br>使用技巧</div>
      <div class="subhead" style="margin-top:18px;max-width:480px">提示词工程 · 七大原则 · 进阶实战</div>
    </div>
  </div>

  <!-- ══ Slide 11 提示词关键作用 ══ -->
  <div class="slide s-content" data-index="10">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 03</div>
        <div class="headline">提示词的关键作用</div>
        <div class="cards cols-3" style="margin-top:32px">
          <div class="card">
            <div class="card-icon">🗣️</div>
            <div class="card-title">派活式沟通</div>
            <div class="card-body">跟 AI 说话就如同和同事沟通，只有把要求清晰说明，才能避免出错。就像在仓库安排工作，明确任务内容和标准，同事才能准确完成。</div>
          </div>
          <div class="card">
            <div class="card-icon">😕</div>
            <div class="card-title">模糊提示的痛点</div>
            <div class="card-body">当给 AI 一个模糊的提示，如"帮我写个总结"，往往导致返工半天。AI 不明确具体需求，输出内容可能偏离预期。</div>
          </div>
          <div class="card">
            <div class="card-icon">✅</div>
            <div class="card-title">清晰提示的效果</div>
            <div class="card-body">给出清晰提示，如"帮我写退货处理总结，含质检标准、库存更新2部分"，AI 就能一次到位地生成符合要求的内容。</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 12 原则一 ══ -->
  <div class="slide s-content" data-index="11">
    <div class="slide-inner">
      <div class="slide-content narrow">
        <div class="section-label">原则一</div>
        <div class="headline">清晰明确 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Clarity</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">使用精确、具体的语言描述需求，避免模糊和歧义，引导 AI 产出预期结果。</div>
        <div class="principle">
          <div class="principle-label">❌ 反面案例</div>
          <div class="eg-bad">"帮我写一篇关于 AI 优化库位布局的分析。"<br><span class="caption" style="color:#ff8a80;opacity:0.7">（主题、篇幅、侧重点、需求均不明确）</span></div>
        </div>
        <div class="principle">
          <div class="principle-label">✅ 正面案例</div>
          <div class="eg-good">"请写一篇 800 字关于物流仓库使用 AI 技术分析电商拣货库位布局的分析，目前仓库采取地堆库位，8 列 × 24 个库位，拣货方式 S/U 字型……"</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 13 原则二 ══ -->
  <div class="slide s-content" data-index="12">
    <div class="slide-inner">
      <div class="slide-content narrow">
        <div class="section-label">原则二</div>
        <div class="headline">提供上下文 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Context</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">提供必要的背景信息、目标受众和具体要求，帮助 AI 理解任务背景，产出更精准的结果。</div>
        <div class="principle">
          <div class="principle-label">❌ 缺乏上下文</div>
          <div class="eg-bad">"帮我准备一份关于 AI 的演讲材料。"<br><span class="caption" style="color:#ff8a80;opacity:0.7">（受众、时长、重点均未知）</span></div>
        </div>
        <div class="principle">
          <div class="principle-label">✅ 充足上下文</div>
          <div class="eg-good">"本周将组织一场精益 AI 交流会，面向物流部全体员工……请帮我准备一份 15 分钟的演讲材料，重点讲提示词技巧，配合实际仓库场景举例。"</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 14 原则三 ══ -->
  <div class="slide s-content" data-index="13">
    <div class="slide-inner">
      <div class="slide-content narrow">
        <div class="section-label">原则三</div>
        <div class="headline">角色扮演 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Role-Playing</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">为 AI 指定特定角色，使其以专业身份或视角思考问题，产出更具针对性的内容。</div>
        <div class="principle">
          <div class="principle-label">❌ 无角色设定</div>
          <div class="eg-bad">"帮我分析一下我们仓库的拣货效率问题。"</div>
        </div>
        <div class="principle">
          <div class="principle-label">✅ 指定角色</div>
          <div class="eg-good">"假设你是一位拥有 10 年经验的物流精益专家，请分析以下仓库的拣货流程数据，并给出基于精益原则的优化建议……"</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 15 原则四 ══ -->
  <div class="slide s-content" data-index="14">
    <div class="slide-inner">
      <div class="slide-content narrow">
        <div class="section-label">原则四</div>
        <div class="headline">迭代优化 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Iteration</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">将复杂任务分解为小步骤，逐步完善 AI 输出，而不是期望一次性获得完美结果。</div>
        <div class="step-list" style="margin-top:24px">
          <div class="step">
            <div class="step-num">1</div>
            <div>
              <div class="step-title">初稿生成</div>
              <div class="step-desc">先获取一个大致方向的输出，不要求完美。</div>
            </div>
          </div>
          <div class="step">
            <div class="step-num">2</div>
            <div>
              <div class="step-title">评估反馈</div>
              <div class="step-desc">分析哪些部分符合预期，哪些需要改进，针对性指出。</div>
            </div>
          </div>
          <div class="step">
            <div class="step-num">3</div>
            <div>
              <div class="step-title">精细调整</div>
              <div class="step-desc">通过追加指令，逐步优化细节，直至满足需求。</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 16 原则五 ══ -->
  <div class="slide s-content" data-index="15">
    <div class="slide-inner">
      <div class="slide-content" style="max-width:1060px">
        <div class="section-label">原则五</div>
        <div class="headline">格式控制 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Format Control</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">明确指定 AI 输出的格式、结构和长度，确保内容符合使用场景。</div>

        <!-- 两栏：左边正反案例，右边输出结果 -->
        <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:16px;margin-top:20px;align-items:stretch">

          <!-- 左栏：仅两个 principle 块，撑满网格行高 -->
          <div style="display:flex;flex-direction:column;gap:10px">
            <div class="principle" style="margin-top:0;flex:1">
              <div class="principle-label">❌ 无格式要求</div>
              <div class="eg-bad">"帮我对比一下 iPhone 17、Huawei Mate80 和 Xiaomi 17 这三款手机。"<br><span class="caption" style="color:#ff8a80;opacity:0.7">（可能得到冗长段落，难以快速对比）</span></div>
            </div>
            <div class="principle" style="margin-top:0;flex:1">
              <div class="principle-label">✅ 明确格式</div>
              <div class="eg-good">"请以<strong>表格形式</strong>对比 iPhone 17、Huawei Mate80、Xiaomi 17，包含处理器、屏幕规格、电池容量、起售价四行，每格不超过 15 字。"</div>
            </div>
          </div>

          <!-- 右栏：AI输出结果展示 -->
          <div style="background:#fff;border:1px solid rgba(0,0,0,0.07);border-radius:16px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,0.06);display:flex;flex-direction:column">
            <!-- 手机图片区 -->
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;background:linear-gradient(135deg,#f0f4ff,#eef2fb);padding:18px 16px 10px;gap:8px;border-bottom:1px solid rgba(0,0,0,0.05)">
              <!-- iPhone 17 真机图 -->
              <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
                <img src="https://pngimg.com/d/iphone17_PNG29.png" alt="iPhone 17" style="height:88px;width:auto;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(0,0,0,0.18))" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"/>
                <svg width="44" height="88" viewBox="0 0 44 88" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none">
                  <defs>
                    <linearGradient id="ip17body" x1="0" y1="0" x2="44" y2="88" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#2c2c2e"/>
                      <stop offset="100%" stop-color="#1a1a1c"/>
                    </linearGradient>
                    <linearGradient id="ip17screen" x1="0" y1="0" x2="36" y2="78" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#1e2b4a"/>
                      <stop offset="100%" stop-color="#0f1729"/>
                    </linearGradient>
                    <linearGradient id="ip17shine" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stop-color="white" stop-opacity="0.08"/>
                      <stop offset="50%" stop-color="white" stop-opacity="0.03"/>
                      <stop offset="100%" stop-color="white" stop-opacity="0"/>
                    </linearGradient>
                  </defs>
                  <rect x="1" y="1" width="42" height="86" rx="10" fill="url(#ip17body)" stroke="#3a3a3c" stroke-width="1.2"/>
                  <rect x="3.5" y="4" width="37" height="80" rx="8" fill="url(#ip17screen)"/>
                  <rect x="3.5" y="4" width="37" height="80" rx="8" fill="url(#ip17shine)"/>
                  <rect x="14" y="6" width="16" height="5.5" rx="2.75" fill="#0d0d0d"/>
                  <circle cx="26.5" cy="8.75" r="1.3" fill="#1c1c1e"/>
                  <rect x="6" y="18" width="28" height="1.2" rx="0.6" fill="#4a6fa5" opacity="0.6"/>
                  <rect x="6" y="22" width="20" height="1.2" rx="0.6" fill="#3a5a8a" opacity="0.45"/>
                  <rect x="6" y="26" width="24" height="1.2" rx="0.6" fill="#3a5a8a" opacity="0.45"/>
                  <rect x="5" y="55" width="15" height="15" rx="5" fill="#111" stroke="#2a2a2a" stroke-width="0.8"/>
                  <circle cx="10.5" cy="60.5" r="3.2" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="0.7"/>
                  <circle cx="10.5" cy="60.5" r="1.8" fill="#050505"/>
                  <circle cx="10.5" cy="60.5" r="0.6" fill="#333"/>
                  <circle cx="16" cy="60.5" r="3.2" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="0.7"/>
                  <circle cx="16" cy="60.5" r="1.8" fill="#050505"/>
                  <circle cx="10.5" cy="66" r="3.2" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="0.7"/>
                  <circle cx="10.5" cy="66" r="1.8" fill="#050505"/>
                  <circle cx="16.5" cy="66" r="2" fill="#2a2a2a" stroke="#3a3a3a" stroke-width="0.5"/>
                  <rect x="43" y="25" width="2" height="11" rx="1" fill="#3a3a3c"/>
                  <rect x="-1" y="22" width="2" height="9" rx="1" fill="#3a3a3c"/>
                  <rect x="-1" y="34" width="2" height="9" rx="1" fill="#3a3a3c"/>
                </svg>
                <div style="font-size:11px;font-weight:600;color:#1d1d1f;text-align:center">iPhone 17</div>
              </div>
              <!-- Huawei Mate 70 精细渲染 -->
              <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
                <svg width="44" height="88" viewBox="0 0 44 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="hw70body" x1="0" y1="0" x2="44" y2="88" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#1a1a1a"/>
                      <stop offset="40%" stop-color="#141414"/>
                      <stop offset="100%" stop-color="#0d0d0d"/>
                    </linearGradient>
                    <linearGradient id="hw70screen" x1="0" y1="0" x2="37" y2="80" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#1e2b3a"/>
                      <stop offset="100%" stop-color="#0c1520"/>
                    </linearGradient>
                    <linearGradient id="hw70camBg" x1="0" y1="0" x2="1" y2="1" gradientUnits="objectBoundingBox">
                      <stop offset="0%" stop-color="#2a2a2a"/>
                      <stop offset="100%" stop-color="#111"/>
                    </linearGradient>
                    <linearGradient id="hw70edge" x1="0" y1="0" x2="0" y2="1" gradientUnits="objectBoundingBox">
                      <stop offset="0%" stop-color="#3a3a3a"/>
                      <stop offset="100%" stop-color="#1a1a1a"/>
                    </linearGradient>
                    <radialGradient id="hw70lens" cx="50%" cy="40%" r="50%">
                      <stop offset="0%" stop-color="#3a4a5a"/>
                      <stop offset="60%" stop-color="#1a2030"/>
                      <stop offset="100%" stop-color="#050a10"/>
                    </radialGradient>
                    <radialGradient id="hw70lensShine" cx="30%" cy="25%" r="50%">
                      <stop offset="0%" stop-color="white" stop-opacity="0.4"/>
                      <stop offset="100%" stop-color="white" stop-opacity="0"/>
                    </radialGradient>
                  </defs>
                  <!-- 机身 -->
                  <rect x="1" y="1" width="42" height="86" rx="10" fill="url(#hw70body)" stroke="#2a2a2a" stroke-width="1.2"/>
                  <!-- 侧边光泽 -->
                  <rect x="1" y="1" width="42" height="86" rx="10" fill="none" stroke="url(#hw70edge)" stroke-width="0.8" opacity="0.5"/>
                  <!-- 屏幕 -->
                  <rect x="3.5" y="4" width="37" height="80" rx="8" fill="url(#hw70screen)"/>
                  <!-- 屏幕微光 -->
                  <rect x="3.5" y="4" width="15" height="80" rx="8" fill="white" opacity="0.015"/>
                  <!-- 打孔屏 -->
                  <circle cx="22" cy="9.5" r="3.2" fill="#080808"/>
                  <circle cx="22" cy="9.5" r="2" fill="#050505"/>
                  <!-- 屏幕内容 -->
                  <rect x="6" y="18" width="28" height="1.2" rx="0.6" fill="#4d7ea8" opacity="0.7"/>
                  <rect x="6" y="22.5" width="18" height="1.2" rx="0.6" fill="#3a6a95" opacity="0.5"/>
                  <rect x="6" y="27" width="23" height="1.2" rx="0.6" fill="#3a6a95" opacity="0.5"/>
                  <!-- 徕卡四摄模组 - 圆形大模组 -->
                  <rect x="5.5" y="44" width="20" height="24" rx="6" fill="#0d0d0d" stroke="#252525" stroke-width="0.8"/>
                  <!-- 徕卡logo条 -->
                  <rect x="7" y="45.5" width="17" height="2" rx="1" fill="#1e1e1e"/>
                  <rect x="8" y="46" width="6" height="1" rx="0.5" fill="#c8a050" opacity="0.7"/>
                  <!-- 左上主摄 -->
                  <circle cx="11.5" cy="53" r="4" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="11.5" cy="53" r="2.8" fill="url(#hw70lens)"/>
                  <circle cx="11.5" cy="53" r="2.8" fill="url(#hw70lensShine)"/>
                  <circle cx="11.5" cy="53" r="1.2" fill="#020408"/>
                  <!-- 右上超广角 -->
                  <circle cx="19.5" cy="53" r="3.5" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="19.5" cy="53" r="2.4" fill="url(#hw70lens)"/>
                  <circle cx="19.5" cy="53" r="1" fill="#020408"/>
                  <!-- 左下长焦 -->
                  <circle cx="11.5" cy="61" r="3.5" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="11.5" cy="61" r="2.4" fill="url(#hw70lens)"/>
                  <circle cx="11.5" cy="61" r="1" fill="#020408"/>
                  <!-- 右下 ToF/闪光 -->
                  <circle cx="19.5" cy="61" r="2.2" fill="#0d0d0d" stroke="#252525" stroke-width="0.6"/>
                  <circle cx="19.5" cy="61" r="1" fill="#c8a050" opacity="0.6"/>
                  <!-- 侧键 -->
                  <rect x="43" y="25" width="2" height="11" rx="1" fill="#252525"/>
                  <rect x="-1" y="22" width="2" height="9" rx="1" fill="#252525"/>
                  <rect x="-1" y="34" width="2" height="9" rx="1" fill="#252525"/>
                </svg>
                <div style="font-size:11px;font-weight:600;color:#1d1d1f;text-align:center">Huawei Mate80</div>
              </div>
              <!-- Xiaomi 15 精细渲染 -->
              <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
                <svg width="44" height="88" viewBox="0 0 44 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="mi15body" x1="0" y1="0" x2="44" y2="88" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#f8f8f8"/>
                      <stop offset="40%" stop-color="#e8e8e8"/>
                      <stop offset="100%" stop-color="#d0d0d0"/>
                    </linearGradient>
                    <linearGradient id="mi15screen" x1="0" y1="0" x2="37" y2="80" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#1e2b3a"/>
                      <stop offset="100%" stop-color="#0c1520"/>
                    </linearGradient>
                    <radialGradient id="mi15lens" cx="50%" cy="40%" r="50%">
                      <stop offset="0%" stop-color="#3a4a5a"/>
                      <stop offset="60%" stop-color="#1a2030"/>
                      <stop offset="100%" stop-color="#050a10"/>
                    </radialGradient>
                    <radialGradient id="mi15shine" cx="30%" cy="25%" r="50%">
                      <stop offset="0%" stop-color="white" stop-opacity="0.4"/>
                      <stop offset="100%" stop-color="white" stop-opacity="0"/>
                    </radialGradient>
                    <radialGradient id="mi15camModule" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stop-color="#2a2a2a"/>
                      <stop offset="100%" stop-color="#101010"/>
                    </radialGradient>
                    <linearGradient id="mi15edge" x1="0" y1="0" x2="0" y2="1" gradientUnits="objectBoundingBox">
                      <stop offset="0%" stop-color="#c0c0c0"/>
                      <stop offset="100%" stop-color="#909090"/>
                    </linearGradient>
                  </defs>
                  <!-- 机身 白色 -->
                  <rect x="1" y="1" width="42" height="86" rx="10" fill="url(#mi15body)" stroke="url(#mi15edge)" stroke-width="1.2"/>
                  <!-- 屏幕 -->
                  <rect x="3.5" y="4" width="37" height="80" rx="8" fill="url(#mi15screen)"/>
                  <rect x="3.5" y="4" width="14" height="80" rx="8" fill="white" opacity="0.02"/>
                  <!-- 打孔 -->
                  <circle cx="22" cy="9.5" r="3.2" fill="#060606"/>
                  <circle cx="22" cy="9.5" r="2" fill="#030303"/>
                  <!-- 屏幕内容 -->
                  <rect x="6" y="18" width="28" height="1.2" rx="0.6" fill="#5a8abf" opacity="0.65"/>
                  <rect x="6" y="22.5" width="19" height="1.2" rx="0.6" fill="#4a7aaf" opacity="0.5"/>
                  <rect x="6" y="27" width="22" height="1.2" rx="0.6" fill="#4a7aaf" opacity="0.5"/>
                  <!-- 小米徕卡三摄 - 大圆形模组 -->
                  <circle cx="14" cy="58" r="12" fill="url(#mi15camModule)" stroke="#1e1e1e" stroke-width="0.8"/>
                  <circle cx="14" cy="58" r="11" fill="none" stroke="#2a2a2a" stroke-width="0.4" opacity="0.5"/>
                  <!-- 主摄 左上 -->
                  <circle cx="10" cy="54" r="4.5" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="10" cy="54" r="3.2" fill="url(#mi15lens)"/>
                  <circle cx="10" cy="54" r="3.2" fill="url(#mi15shine)"/>
                  <circle cx="10" cy="54" r="1.4" fill="#020408"/>
                  <!-- 长焦 右上 -->
                  <circle cx="18" cy="54" r="3.8" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="18" cy="54" r="2.6" fill="url(#mi15lens)"/>
                  <circle cx="18" cy="54" r="1.1" fill="#020408"/>
                  <!-- 超广 下方 -->
                  <circle cx="14" cy="62" r="3.8" fill="#0a0a0a" stroke="#2a2a2a" stroke-width="0.7"/>
                  <circle cx="14" cy="62" r="2.6" fill="url(#mi15lens)"/>
                  <circle cx="14" cy="62" r="1.1" fill="#020408"/>
                  <!-- 闪光灯 -->
                  <circle cx="21" cy="62" r="1.8" fill="#d0c060" opacity="0.7" stroke="#b0a050" stroke-width="0.4"/>
                  <!-- 小米logo 底部 -->
                  <rect x="17" y="72" width="10" height="1.5" rx="0.75" fill="#ccc" opacity="0.4"/>
                  <!-- 侧键 银色 -->
                  <rect x="43" y="25" width="2" height="11" rx="1" fill="#a0a0a0"/>
                  <rect x="-1" y="22" width="2" height="9" rx="1" fill="#a0a0a0"/>
                  <rect x="-1" y="34" width="2" height="9" rx="1" fill="#a0a0a0"/>
                </svg>
                <div style="font-size:11px;font-weight:600;color:#1d1d1f;text-align:center">Xiaomi 17</div>
              </div>
            </div>

            <!-- 表格区 -->
            <div style="padding:0;flex:1;display:flex;flex-direction:column">
              <div style="padding:8px 16px;font-size:11px;font-weight:600;color:var(--blue);letter-spacing:0.05em;border-bottom:1px solid rgba(0,0,0,0.05);background:rgba(0,113,227,0.04)">
                ✅ AI 输出结果 · 案例：旗舰手机参数对比（表格格式）
              </div>
              <table style="width:100%;border-collapse:collapse;font-size:13px;flex:1">
                <thead>
                  <tr style="background:rgba(0,113,227,0.07)">
                    <th style="padding:9px 14px;text-align:left;font-weight:600;color:var(--fg2);font-size:12px;border-bottom:1px solid rgba(0,0,0,0.06)">维度</th>
                    <th style="padding:9px 14px;text-align:center;font-weight:600;color:var(--fg);font-size:12px;border-bottom:1px solid rgba(0,0,0,0.06)">iPhone 17</th>
                    <th style="padding:9px 14px;text-align:center;font-weight:600;color:var(--fg);font-size:12px;border-bottom:1px solid rgba(0,0,0,0.06)">Huawei Mate80</th>
                    <th style="padding:9px 14px;text-align:center;font-weight:600;color:var(--fg);font-size:12px;border-bottom:1px solid rgba(0,0,0,0.06)">Xiaomi 17</th>
                  </tr>
                </thead>
                <tbody>
                  <tr style="border-bottom:1px solid rgba(0,0,0,0.04)">
                    <td style="padding:8px 14px;color:var(--fg2);font-size:12px">处理器</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">A19（3nm）</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">麒麟 9020</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">骁龙 8 Gen4</td>
                  </tr>
                  <tr style="border-bottom:1px solid rgba(0,0,0,0.04);background:rgba(0,0,0,0.015)">
                    <td style="padding:8px 14px;color:var(--fg2);font-size:12px">屏幕规格</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">6.3″ OLED / 60Hz</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">6.75″ OLED / 120Hz</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">6.4″ OLED / 120Hz</td>
                  </tr>
                  <tr style="border-bottom:1px solid rgba(0,0,0,0.04)">
                    <td style="padding:8px 14px;color:var(--fg2);font-size:12px">电池容量</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">3692 mAh</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">6000 mAh</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--fg)">6000 mAh</td>
                  </tr>
                  <tr>
                    <td style="padding:8px 14px;color:var(--fg2);font-size:12px">起售价格</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--blue);font-weight:600">¥5999</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--blue);font-weight:600">¥5499</td>
                    <td style="padding:8px 14px;text-align:center;color:var(--blue);font-weight:600">¥4499</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
        <!-- 标签行：独立于两栏网格之外 -->
        <div class="tag-list" style="margin-top:12px">
          <span class="tag">表格</span><span class="tag">列表</span><span class="tag">分点</span>
          <span class="tag">JSON</span><span class="tag">Markdown</span><span class="tag">指定字数</span>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 17 原则六 ══ -->
  <div class="slide s-content" data-index="16">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">原则六</div>
        <div class="headline">约束与限制 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Constraints</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">明确告知 AI 哪些内容不需要，哪些是禁止的，缩小输出范围。</div>
        <div class="cards cols-3" style="margin-top:28px">
          <div class="card">
            <div class="card-icon">🚫</div>
            <div class="card-title">排除无关内容</div>
            <div class="card-body">告诉 AI"不需要历史背景介绍"，直接聚焦核心问题。</div>
          </div>
          <div class="card">
            <div class="card-icon">🎯</div>
            <div class="card-title">指定重点范围</div>
            <div class="card-body">只分析近三个月数据，不考虑节假日特殊情况。</div>
          </div>
          <div class="card">
            <div class="card-icon">📏</div>
            <div class="card-title">限制输出规模</div>
            <div class="card-body">给出不超过 5 条建议，每条控制在 50 字以内。</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 18 原则七 ══ -->
  <div class="slide s-content" data-index="17">
    <div class="slide-inner">
      <div class="slide-content narrow">
        <div class="section-label">原则七</div>
        <div class="headline">示例驱动 &nbsp;<span class="muted" style="font-size:28px;font-weight:400">Few-Shot</span></div>
        <div class="slide-divider"></div>
        <div class="subhead">提供 1-3 个示例，让 AI 学习你期望的输出风格和格式，效果远优于纯文字描述。</div>
        <div class="principle" style="margin-top:24px">
          <div class="principle-label">❌ 无示例</div>
          <div class="eg-bad">"帮我写几条库存预警通知。"<br><span class="caption" style="color:#ff8a80;opacity:0.7">（AI 不清楚语气、格式、信息完整度）</span></div>
        </div>
        <div class="principle">
          <div class="principle-label">✅ 提供示例</div>
          <div class="eg-good">"请按以下格式生成库存预警：<br>【预警】SKU:A001 当前库存80件，低于安全库存100件，请及时补货。<br>现在为 SKU:B002（当前50件/安全线120件）生成一条。"</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 19 Chapter 4 ══ -->
  <div class="slide s-chapter" data-index="18">
    <div class="chap-num">04</div>
    <div class="slide-content" style="position:relative;z-index:1">
      <div class="chap-eyebrow">Chapter 04</div>
      <div class="display">使用 AI 时的<br>注意事项</div>
      <div class="subhead" style="margin-top:18px;max-width:600px">数据安全 · 信息核验 · 合规使用 · 边界 · 意识</div>
    </div>
  </div>

  <!-- ══ Slide 20 注意事项 ══ -->
  <div class="slide s-content" data-index="19">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 04</div>
        <div class="headline">核心注意事项</div>
        <div class="attention-list">
          <div class="att-item">
            <div class="att-icon">🔐</div>
            <div>
              <div class="att-title">保护数据安全与隐私</div>
              <div class="att-body">禁止将客户个人信息、公司核心数据、未公开的财务信息等敏感数据输入公共 AI 工具。涉及敏感业务，优先使用公司内部部署的 AI 系统。</div>
            </div>
          </div>
          <div class="att-item">
            <div class="att-icon">🔍</div>
            <div>
              <div class="att-title">核验 AI 输出内容</div>
              <div class="att-body">AI 可能产生"幻觉"（虚构事实）。重要数据、专业判断、法律条款等必须人工核实，不可直接用于决策。</div>
            </div>
          </div>
          <div class="att-item">
            <div class="att-icon">⚖️</div>
            <div>
              <div class="att-title">遵守法规与公司合规要求</div>
              <div class="att-body">AI 生成内容仍需遵守版权法、商业道德和公司规定。不得使用 AI 生成虚假信息、误导性内容或侵权材料。</div>
            </div>
          </div>
          <div class="att-item">
            <div class="att-icon">🧠</div>
            <div>
              <div class="att-title">保持人工判断与主导</div>
              <div class="att-body">AI 是辅助工具，最终决策权在人。培养"用 AI 但不依赖 AI"的工作习惯，保持独立思考能力。</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 21 常见误区 ══ -->
  <div class="slide s-content" data-index="20">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 04</div>
        <div class="headline">常见误区与正确姿势</div>
        <div class="contrast-grid">
          <div class="contrast-card wrong">
            <div class="contrast-label">❌ 常见误区</div>
            <div class="contrast-item">把 AI 当百科全书，不加核实直接引用</div>
            <div class="contrast-item">期望 AI 一次生成完美内容，不愿迭代</div>
            <div class="contrast-item">输入公司保密数据到公共平台</div>
            <div class="contrast-item">AI 说什么就信什么，丧失独立判断</div>
            <div class="contrast-item">把所有工作都甩给 AI，自己不参与</div>
          </div>
          <div class="contrast-card right">
            <div class="contrast-label">✅ 正确姿势</div>
            <div class="contrast-item">用 AI 生成草稿，人工核实重要信息</div>
            <div class="contrast-item">先明确需求，再逐步迭代优化</div>
            <div class="contrast-item">敏感数据脱敏后再使用，或用内网 AI</div>
            <div class="contrast-item">带着批判性思维审视 AI 输出</div>
            <div class="contrast-item">人机协作，AI 提效，人来决策</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 22 物流 AI 应用场景 ══ -->
  <div class="slide s-content" data-index="21">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 02 · 延伸</div>
        <div class="headline">物流 AI 应用场景</div>
        <div class="cards cols-3" style="margin-top:32px">
          <div class="card">
            <div class="card-icon">📊</div>
            <div class="card-title">物流指标分析</div>
            <div class="card-body">利用 AI 分析出入库数据、拣货效率、退货率等指标，自动生成分析报告，辅助管理决策。</div>
          </div>
          <div class="card">
            <div class="card-icon">📝</div>
            <div class="card-title">提示词辅助作业</div>
            <div class="card-body">通过精准提示词协助起草 SOP、流程说明、培训材料，大幅降低文档制作时间。</div>
          </div>
          <div class="card">
            <div class="card-icon">🔄</div>
            <div class="card-title">精益优化辅助</div>
            <div class="card-body">输入现场流程描述，让 AI 识别潜在浪费点，生成初步优化建议，再由团队结合实际判断。</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 23 AI 工具一览 ══ -->
  <div class="slide s-content" data-index="22">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">工具推荐</div>
        <div class="headline">常用 AI 工具一览</div>
        <div class="cards cols-2" style="margin-top:32px">
          <div class="card">
            <div class="card-title">💬 对话类 AI</div>
            <div class="card-body" style="margin-top:10px">
              <div class="tag-list" style="margin-top:0">
                <span class="tag">ChatGPT</span><span class="tag">文心一言</span>
                <span class="tag">通义千问</span><span class="tag">豆包</span>
                <span class="tag">Kimi</span><span class="tag">Claude</span>
              </div>
              <div class="caption" style="margin-top:10px">文本生成 · 问答 · 总结 · 翻译</div>
            </div>
          </div>
          <div class="card">
            <div class="card-title">🛠️ 效率工具类</div>
            <div class="card-body" style="margin-top:10px">
              <div class="tag-list" style="margin-top:0">
                <span class="tag">Notion AI</span><span class="tag">飞书 AI</span>
                <span class="tag">Copilot</span><span class="tag">WPS AI</span>
              </div>
              <div class="caption" style="margin-top:10px">文档整理 · 会议纪要 · 数据分析</div>
            </div>
          </div>
          <div class="card">
            <div class="card-title">🎨 图像/多媒体类</div>
            <div class="card-body" style="margin-top:10px">
              <div class="tag-list" style="margin-top:0">
                <span class="tag">Midjourney</span><span class="tag">即梦 AI</span><span class="tag">Sora</span>
              </div>
              <div class="caption" style="margin-top:10px">图片生成 · 创意设计</div>
            </div>
          </div>
          <div class="card">
            <div class="card-title">⚡ 智能体/自动化</div>
            <div class="card-body" style="margin-top:10px">
              <div class="tag-list" style="margin-top:0">
                <span class="tag">Coze</span><span class="tag">Dify</span>
                <span class="tag">AutoGPT</span><span class="tag">n8n</span>
              </div>
              <div class="caption" style="margin-top:10px">工作流自动化 · 多步骤任务</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 24 进阶技巧 ══ -->
  <div class="slide s-content" data-index="23">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 03 · 进阶</div>
        <div class="headline">提示词进阶技巧</div>
        <div class="cards cols-2" style="margin-top:32px">
          <div class="card">
            <div class="card-icon">🔗</div>
            <div class="card-title">链式思考 (Chain of Thought)</div>
            <div class="card-body">引导 AI"一步一步思考"，适合逻辑推理和复杂分析任务。<br><br><span class="caption" style="color:var(--blue)">例："请一步步分析这次退货异常的根本原因……"</span></div>
          </div>
          <div class="card">
            <div class="card-icon">🎭</div>
            <div class="card-title">多视角审视</div>
            <div class="card-body">让 AI 从不同角色或立场分析同一问题，获取更全面的洞察。<br><br><span class="caption" style="color:var(--blue)">例："分别从仓管员、采购员、财务的角度看这个库存问题……"</span></div>
          </div>
          <div class="card">
            <div class="card-icon">📋</div>
            <div class="card-title">模板复用</div>
            <div class="card-body">将有效的提示词保存为模板，复用于类似场景，持续积累提示词资产。</div>
          </div>
          <div class="card">
            <div class="card-icon">🔄</div>
            <div class="card-title">反向验证</div>
            <div class="card-body">让 AI 检查自己的回答，找出可能的错误或遗漏，提升输出可靠性。<br><br><span class="caption" style="color:var(--blue)">例："请检查你上面的分析，有没有逻辑漏洞？"</span></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 25 实战示例 ══ -->
  <div class="slide s-content" data-index="24">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 03 · 实战</div>
        <div class="headline">物流场景提示词实战</div>
        <div class="example-block">
          <div class="principle-label" style="margin-bottom:10px">场景 1 · 库存分析</div>
          <div class="eg-good">"你是一位物流数据分析师。以下是本月 SKU A001-A050 的库存数据（[表格]）。请识别：①库存周转低于3次的 SKU；②近14天无出库记录的滞销品；③建议清仓或补货的优先级排序。输出格式：表格，含 SKU 编号、当前库存、建议操作、理由。"</div>
        </div>
        <div class="example-block" style="margin-top:12px">
          <div class="principle-label" style="margin-bottom:10px">场景 2 · SOP 起草</div>
          <div class="eg-good">"请帮我起草一份《仓库退货收货操作规范》，包含：收货核验流程（3步）、质检标准（外观+功能）、系统录入要求、异常处理升级流程。语言简洁，适合一线员工阅读，全文不超过600字，使用分点格式。"</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 26 精益+AI ══ -->
  <div class="slide s-content" data-index="25">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">精益 × AI</div>
        <div class="headline">双螺旋驱动</div>
        <div class="subhead" style="margin-top:8px">精益思维提供方向，AI 能力提供速度</div>
        <div class="two-col" style="margin-top:28px">
          <div>
            <div class="col-head">精益思维 → 方向</div>
            <div class="step-list">
              <div class="step">
                <div class="step-num">→</div>
                <div><div class="step-title">识别价值流</div><div class="step-desc">确定哪些环节真正为客户创造价值。</div></div>
              </div>
              <div class="step">
                <div class="step-num">→</div>
                <div><div class="step-title">找到浪费点</div><div class="step-desc">七种浪费分析，锁定优化目标。</div></div>
              </div>
              <div class="step">
                <div class="step-num">→</div>
                <div><div class="step-title">持续改善</div><div class="step-desc">PDCA 循环，小步快跑，持续迭代。</div></div>
              </div>
            </div>
          </div>
          <div>
            <div class="col-head">AI 能力 → 速度</div>
            <div class="step-list">
              <div class="step">
                <div class="step-num">⚡</div>
                <div><div class="step-title">快速数据分析</div><div class="step-desc">秒级完成数据整理、模式识别和报告生成。</div></div>
              </div>
              <div class="step">
                <div class="step-num">⚡</div>
                <div><div class="step-title">知识加速</div><div class="step-desc">调用海量行业知识，快速形成优化方案。</div></div>
              </div>
              <div class="step">
                <div class="step-num">⚡</div>
                <div><div class="step-title">自动化执行</div><div class="step-desc">重复性任务自动化，释放人力专注创新。</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 27 AI 现状 ══ -->
  <div class="slide s-content" data-index="26">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">AI 现状</div>
        <div class="headline">2026 · AI 已成为核心生产力工具</div>
        <div class="cards cols-3" style="margin-top:8px">
          <div class="card">
            <div class="card-title">🌐 无处不在</div>
            <div class="card-body">AI 已深度融入工作、生活各个场景，从内容创作到数据分析，从客服到物流调度，全面渗透。</div>
          </div>
          <div class="card">
            <div class="card-title">🚀 能力爆发</div>
            <div class="card-body">大模型能力持续迭代，多模态、推理、代码、分析等能力全面跃升，重塑各行业工作流程。</div>
          </div>
          <div class="card">
            <div class="card-title">🏆 能力分水岭</div>
            <div class="card-body">掌握 AI 使用技能的人与不掌握的人，在效率与创造力上的差距正在快速拉大。</div>
          </div>
        </div>
        <div class="stat-row">
          <div class="stat">
            <div class="stat-num">10×</div>
            <div class="stat-label">善用 AI 者的效率倍增潜力</div>
          </div>
          <div class="stat">
            <div class="stat-num">2026</div>
            <div class="stat-label">AI 能力全面落地关键年</div>
          </div>
          <div class="stat">
            <div class="stat-num">NOW</div>
            <div class="stat-label">最好的入手时机就是现在</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 27-1 新增哲理页 ══ -->
  <div class="slide s-content" data-index="27">
    <div class="slide-inner" style="display:flex;align-items:center;justify-content:center">
      <div class="slide-content" style="text-align:center;max-width:900px">
        <div class="section-label">Philosophy</div>
        <div style="margin-top:32px">
          <div class="quote-text-row" style="margin-bottom:16px">
            <span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">A</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">I</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">可</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">以</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">模</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">拟</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">千</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">万</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">种</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">可</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;color:var(--fg);letter-spacing:-0.02em">能</span>
          </div>
          <div class="quote-text-row" style="color:var(--blue)">
            <span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">但</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">模</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">拟</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">不</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">了</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">鲜</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">活</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">的</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">生</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">命</span><span class="char" style="font-size:clamp(36px, 5vw, 56px);font-weight:700;line-height:1.4;letter-spacing:-0.02em">力</span>
          </div>
        </div>
        <div style="margin-top:56px;padding-top:32px;border-top:1px solid rgba(0,0,0,0.06)">
          <div style="font-size:15px;color:var(--fg2);line-height:1.7;max-width:560px;margin:0 auto">
            技术是翅膀，但让世界运转的，始终是人的热情、创造与爱。
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 28 需支持工作 ══ -->
  <div class="slide s-content" data-index="28">
    <div class="slide-inner">
      <div class="slide-content">
        <div class="section-label">Chapter 03 · 需支持工作</div>
        <div class="headline">近期需 AI 支持的工作方向</div>
        <div class="cards cols-2" style="margin-top:32px">
          <div class="card">
            <div class="card-icon">📊</div>
            <div class="card-title">物流指标分析</div>
            <div class="card-body">借助 AI 对仓库核心 KPI 进行自动化分析与可视化呈现，提升数据洞察效率，辅助管理层快速决策。</div>
          </div>
          <div class="card">
            <div class="card-icon">✍️</div>
            <div class="card-title">提示词工程建设</div>
            <div class="card-body">整理并沉淀物流场景下的高质量提示词模板库，让团队能快速复用，降低 AI 使用门槛，提升整体产出质量。</div>
          </div>
        </div>
        <div class="info-block" style="margin-top:20px">
          欢迎大家提出更多需要 AI 辅助的工作场景，共同探索<strong> 精益 × AI </strong>的更多可能。
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 29 总结 ══ -->
  <div class="slide s-content" data-index="29">
    <div class="slide-inner" style="display:flex;align-items:center;justify-content:center">
      <div class="slide-content">
        <div class="section-label">Conclusion</div>
        <div class="headline">总结：拥抱 AI，共创未来</div>
        <div class="summary-grid">
          <div class="summary-card">
            <div class="s-num">01</div>
            <div class="s-title">🔑 核心生产力工具</div>
            <div class="s-body">2026 年，AI 不再是未来的概念，而是重塑工作与生活的核心驱动力。</div>
          </div>
          <div class="summary-card">
            <div class="s-num">02</div>
            <div class="s-title">🎯 掌握 AI 技能至关重要</div>
            <div class="s-body">提示词工程、智能体应用等成为必备技能，决定个人和企业的竞争力。</div>
          </div>
          <div class="summary-card">
            <div class="s-num">03</div>
            <div class="s-title">⚡ 积极实践，应对挑战</div>
            <div class="s-body">企业应积极探索 AI 应用，同时关注数据安全、伦理合规等问题。</div>
          </div>
          <div class="summary-card">
            <div class="s-num">04</div>
            <div class="s-title">🤝 未来属于人机协作</div>
            <div class="s-body">拥抱变化，与 AI 共生，共同创造更高效、更美好的未来。</div>
          </div>
        </div>
        <div class="quote-block" style="margin-top:24px;text-align:center;border-left:none;border-top:1px solid rgba(255,255,255,0.08);padding-top:20px">
          " 让我们携手共进，以技术为翼，开启智能新纪元 "
        </div>
      </div>
    </div>
  </div>

  <!-- ══ Slide 30 Thanks ══ -->
  <div class="slide s-thanks" data-index="30">
    <div class="slide-content">
      <div class="thanks-word">Thanks</div>
      <div class="thanks-sub">感谢聆听 &nbsp;·&nbsp; 集团物流部 &nbsp;精益·AI+ 交流会</div>
    </div>
  </div>

</div><!-- /deck -->

<div class="nav">
  <div class="nav-normal">
    <button id="btnFirst" onclick="goTo(0)" title="第一页">&#171;</button>
    <button id="btnPrev" onclick="changeSlide(-1)" title="上一页">&#8592;</button>
    <div class="dots" id="dots"></div>
    <span class="slide-counter" id="counter">01 / 31</span>
    <button id="btnNext" onclick="changeSlide(1)" title="下一页">&#8594;</button>
    <button id="btnLast" onclick="goTo(total - 1)" title="最后一页">&#187;</button>
    <div class="nav-divider"></div>
    <button id="btnFullscreen" onclick="toggleFullscreen()" title="全屏">&#9974;</button>
  </div>
  <div class="nav-minimal" style="display:none">
    <span class="slide-counter" id="counterMinimal">01 / 31</span>
  </div>
</div>

<!-- Settings Button -->
<button class="settings-btn" onclick="toggleSettings()">&#9881;</button>

<!-- Settings Panel -->
<div class="settings-panel" id="settingsPanel" style="display:none">
  <div class="settings-header">
    <span>页面排序</span>
    <div style="display:flex;align-items:center;gap:8px">
      <button onclick="undoDelete()" title="恢复最近一次删除的页面" style="background:none;border:1px solid rgba(255,59,48,0.35);border-radius:6px;font-size:12px;color:#ff3b30;padding:3px 10px;cursor:pointer;transition:background .2s" onmouseover="this.style.background='rgba(255,59,48,0.06)'" onmouseout="this.style.background='none'">撤回删除</button>
      <button onclick="resetOrder()" title="恢复默认顺序（清除所有排序与删除记录）" style="background:none;border:1px solid rgba(0,0,0,0.12);border-radius:6px;font-size:12px;color:#6e6e73;padding:3px 10px;cursor:pointer;transition:background .2s" onmouseover="this.style.background='rgba(0,0,0,0.05)'" onmouseout="this.style.background='none'">重置顺序</button>
      <button class="settings-close" onclick="toggleSettings()">&#10006;</button>
    </div>
  </div>
  <div class="settings-content" id="sortableList"></div>
</div>
<div class="settings-overlay" id="settingsOverlay" style="display:none" onclick="toggleSettings()"></div>

<script>
  // ── localStorage 持久化排序 & 删除 ──────────────────
  const STORAGE_KEY        = 'lean_ai_slide_order';
  const DELETED_KEY        = 'lean_ai_slide_deleted';   // 已删 sid 数组（有序栈）
  const DELETED_CACHE_KEY  = 'lean_ai_slide_deleted_cache'; // 被删 slide 的 outerHTML 存档

  // 给每个 slide 打上稳定 ID（按原始顺序）
  Array.from(document.querySelectorAll('.slide')).forEach((s, i) => {
    if (!s.dataset.sid) s.dataset.sid = String(i);
  });

  // ── 删除相关 ──────────────────────────────────────
  // 初始化时先把被删的 slide 从 deck 里摘出来并缓存
  function applyDeleted() {
    try {
      const deleted = JSON.parse(localStorage.getItem(DELETED_KEY)) || [];
      if (!deleted.length) return;
      const deck = document.getElementById('deck');
      const cache = JSON.parse(localStorage.getItem(DELETED_CACHE_KEY)) || {};
      deleted.forEach(sid => {
        const el = deck.querySelector(`.slide[data-sid="${sid}"]`);
        if (el) {
          cache[sid] = el.outerHTML;   // 存 HTML 快照
          el.remove();
        }
      });
      localStorage.setItem(DELETED_CACHE_KEY, JSON.stringify(cache));
    } catch(e) {}
  }

  // 删除单张 slide（by sid）
  function deleteSlide(sid) {
    const idx = slides.findIndex(s => s.dataset.sid === sid);
    if (idx === -1) return;

    // 1. 存快照
    const cache = JSON.parse(localStorage.getItem(DELETED_CACHE_KEY)) || {};
    cache[sid] = slides[idx].outerHTML;
    localStorage.setItem(DELETED_CACHE_KEY, JSON.stringify(cache));

    // 2. 更新已删列表
    const deleted = JSON.parse(localStorage.getItem(DELETED_KEY)) || [];
    if (!deleted.includes(sid)) deleted.push(sid);
    localStorage.setItem(DELETED_KEY, JSON.stringify(deleted));

    // 3. 从 DOM & slides 数组中移除
    slides[idx].remove();
    slides.splice(idx, 1);
    total = slides.length;

    // 4. 修正 current
    if (current >= slides.length) current = slides.length - 1;
    if (current < 0) current = 0;
    if (slides.length > 0) {
      slides.forEach(s => s.classList.remove('active'));
      slides[current].classList.add('active');
    }

    // 5. 保存顺序 & 刷新 UI
    saveOrder();
    updateUI();
    renderSortableList();
  }

  // 撤回最近一次删除
  function undoDelete() {
    try {
      const deleted = JSON.parse(localStorage.getItem(DELETED_KEY)) || [];
      if (!deleted.length) {
        // 无可恢复项：短暂高亮按钮提示
        const btn = document.querySelector('[onclick*="undoDelete"]') || document.querySelector('button[title*="撤回"]');
        if (btn) { btn.style.opacity = '0.3'; setTimeout(() => { btn.style.opacity = '1'; }, 600); }
        return;
      }

      const sid = deleted.pop();   // 取最近一条
      localStorage.setItem(DELETED_KEY, JSON.stringify(deleted));

      const cache = JSON.parse(localStorage.getItem(DELETED_CACHE_KEY)) || {};
      const html = cache[sid];
      if (!html) { console.warn('undoDelete: snapshot missing for sid', sid); return; }

      // 从 HTML 字符串重建 DOM 节点
      const tmp = document.createElement('div');
      tmp.innerHTML = html;
      const el = tmp.firstElementChild;

      // 找到该 sid 在保存的顺序中应插入的位置
      const order = JSON.parse(localStorage.getItem(STORAGE_KEY)) || slides.map(s => s.dataset.sid);
      const orderIdx = order.indexOf(sid);

      const deck = document.getElementById('deck');
      if (orderIdx === -1 || orderIdx >= slides.length) {
        // 找不到位置，直接加到末尾
        deck.appendChild(el);
        slides.push(el);
      } else {
        // 在 slides[orderIdx] 之前插入（若 orderIdx > slides.length 则追加）
        const refSlide = slides[Math.min(orderIdx, slides.length - 1)];
        deck.insertBefore(el, refSlide);
        slides.splice(Math.min(orderIdx, slides.length), 0, el);
      }

      total = slides.length;
      // 清理快照
      delete cache[sid];
      localStorage.setItem(DELETED_CACHE_KEY, JSON.stringify(cache));

      // 更新 current，跳到恢复的页面
      current = slides.indexOf(el);
      slides.forEach(s => s.classList.remove('active'));
      slides[current].classList.add('active');

      saveOrder();
      updateUI();
      renderSortableList();
    } catch(e) { console.error('undoDelete error', e); }
  }

  // ── 排序相关 ──────────────────────────────────────
  // 保存当前顺序到 localStorage
  function saveOrder() {
    const order = slides.map(s => s.dataset.sid);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(order));
  }

  // 从 localStorage 恢复顺序
  function restoreOrder() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (!saved || !Array.isArray(saved)) return false;
      const deck = document.getElementById('deck');
      const allSlides = Array.from(deck.querySelectorAll('.slide'));
      const map = {};
      allSlides.forEach(s => { map[s.dataset.sid] = s; });
      // 只保留当前存在的 slide
      const valid = saved.filter(id => map[id]);
      // 数量不符时不拦截（因为已删 slide 不在 deck 里）
      valid.forEach(id => deck.appendChild(map[id]));
      return true;
    } catch(e) { return false; }
  }

  // 重置为默认顺序（清除排序 + 删除记录）
  function resetOrder() {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(DELETED_KEY);
    localStorage.removeItem(DELETED_CACHE_KEY);
    location.reload();
  }

  // ── 初始化时先应用删除，再恢复排序 ──────────────────
  applyDeleted();
  restoreOrder();

  // slides 必须是真实数组，NodeList 不能 splice
  let slides = Array.from(document.querySelectorAll('.slide'));
  let total = slides.length;
  let current = 0;
  const visibleDots = 9;
  const halfDots = Math.floor(visibleDots / 2);

  // 生成圆点
  const dotsEl = document.getElementById('dots');
  function createDots() {
    dotsEl.innerHTML = '';
    const start = Math.max(0, current - halfDots);
    const end = Math.min(total, start + visibleDots);
    
    // 如果不够9个，调整起始位置
    const adjustedStart = Math.max(0, Math.min(start, total - visibleDots));
    const adjustedEnd = Math.min(total, adjustedStart + visibleDots);
    
    for (let i = adjustedStart; i < adjustedEnd; i++) {
      const d = document.createElement('div');
      d.className = 'dot' + (i === current ? ' active' : '');
      d.onclick = () => goTo(i);
      dotsEl.appendChild(d);
    }
  }

  function goTo(idx) {
    if (idx < 0 || idx >= slides.length) return;
    slides[current].classList.remove('active');
    current = idx;
    slides[current].classList.add('active');
    updateUI();
  }

  function changeSlide(dir) { goTo(current + dir); }

  function updateUI() {
    total = slides.length;
    const n = String(current + 1).padStart(2, '0');
    const t = String(total).padStart(2, '0');
    document.getElementById('counter').textContent = n + ' / ' + t;
    document.getElementById('counterMinimal').textContent = n + ' / ' + t;
    document.getElementById('btnPrev').disabled = current === 0;
    document.getElementById('btnNext').disabled = current === total - 1;
    document.getElementById('btnFirst').disabled = current === 0;
    document.getElementById('btnLast').disabled = current === total - 1;
    document.getElementById('progress').style.width = ((current + 1) / total * 100) + '%';
    createDots();
  }

  // Settings panel
  function toggleSettings() {
    const panel = document.getElementById('settingsPanel');
    const overlay = document.getElementById('settingsOverlay');
    if (panel.style.display === 'none') {
      panel.style.display = 'flex';
      overlay.style.display = 'block';
      renderSortableList();
    } else {
      panel.style.display = 'none';
      overlay.style.display = 'none';
    }
  }

  function getSlideTitle(slide, index) {
    const headline = slide.querySelector('.headline, .display, .chap-eyebrow, .thanks-word');
    if (headline) return headline.textContent.trim().substring(0, 40);
    const label = slide.querySelector('.label, .section-label, .org-tag');
    if (label) return label.textContent.trim();
    return `第 ${index + 1} 页`;
  }

  function renderSortableList() {
    const list = document.getElementById('sortableList');
    list.innerHTML = '';
    slides.forEach((slide, index) => {
      const sid = slide.dataset.sid;
      const item = document.createElement('div');
      item.className = 'sortable-item';
      item.dataset.slideIndex = index;
      item.dataset.sid = sid;

      const handle = document.createElement('span');
      handle.className = 'sortable-handle';
      handle.innerHTML = '&#9776;';

      const num = document.createElement('span');
      num.className = 'sortable-num';
      num.textContent = String(index + 1).padStart(2, '0');

      const title = document.createElement('span');
      title.className = 'sortable-title';
      title.style.flex = '1';
      title.textContent = getSlideTitle(slide, index);

      const delBtn = document.createElement('button');
      delBtn.className = 'sortable-del-btn';
      delBtn.dataset.sid = sid;
      delBtn.title = '删除此页面（可撤回）';
      delBtn.innerHTML = '&#10005;';
      delBtn.style.cssText = 'background:none;border:none;cursor:pointer;color:#ff3b30;opacity:0.45;font-size:15px;padding:4px 10px;border-radius:6px;line-height:1;transition:opacity .2s,background .2s;flex-shrink:0';
      delBtn.addEventListener('mouseenter', function() { this.style.opacity='1'; this.style.background='rgba(255,59,48,0.1)'; });
      delBtn.addEventListener('mouseleave', function() { this.style.opacity='0.45'; this.style.background='none'; });
      delBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        deleteSlide(this.dataset.sid);
      });

      item.appendChild(handle);
      item.appendChild(num);
      item.appendChild(title);
      item.appendChild(delBtn);
      list.appendChild(item);
    });
  }

  // ── 拖拽排序（鼠标跟随 ghost 方案） ──────────────────
  let drag = null;

  // mousedown 绑定到 sortableList（在 toggleSettings 之后才存在，用事件委托）
  document.addEventListener('mousedown', function(e) {
    const handle = e.target.closest('.sortable-handle');
    if (!handle) return;
    const item = handle.closest('.sortable-item');
    if (!item) return;

    e.preventDefault();
    e.stopPropagation();

    const list = document.getElementById('sortableList');
    const items = Array.from(list.querySelectorAll('.sortable-item'));
    const fromIndex = items.indexOf(item);
    const rect = item.getBoundingClientRect();

    // 创建幽灵元素跟随鼠标
    const ghost = item.cloneNode(true);
    ghost.id = '__drag_ghost__';
    ghost.style.cssText = [
      'position:fixed',
      'left:' + rect.left + 'px',
      'top:' + rect.top + 'px',
      'width:' + rect.width + 'px',
      'height:' + rect.height + 'px',
      'opacity:0.88',
      'background:#d4e5ff',
      'box-shadow:0 8px 24px rgba(0,113,227,0.3)',
      'border-radius:10px',
      'z-index:99999',
      'pointer-events:none',
      'transform:scale(1.03)',
      'transition:none',
      'margin:0'
    ].join(';');
    document.body.appendChild(ghost);

    // 插入位置指示线
    const indicator = document.createElement('div');
    indicator.id = '__drag_indicator__';
    indicator.style.cssText = 'height:3px;background:#0071e3;border-radius:2px;margin:0 0;pointer-events:none;display:none;';

    item.style.opacity = '0.25';

    drag = {
      item, ghost, indicator, list,
      fromIndex,
      toIndex: fromIndex,
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top
    };
    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'grabbing';
  });

  document.addEventListener('mousemove', function(e) {
    if (!drag) return;

    // 更新 ghost 位置
    drag.ghost.style.left = (e.clientX - drag.offsetX) + 'px';
    drag.ghost.style.top  = (e.clientY - drag.offsetY) + 'px';

    const items = Array.from(drag.list.querySelectorAll('.sortable-item'));

    // 移除旧指示线
    if (drag.indicator.parentNode) drag.indicator.parentNode.removeChild(drag.indicator);

    // 确定插入位置
    let insertBeforeItem = null;
    let toIndex = items.length;
    for (let i = 0; i < items.length; i++) {
      if (items[i] === drag.item) continue;
      const r = items[i].getBoundingClientRect();
      if (e.clientY < r.top + r.height / 2) {
        insertBeforeItem = items[i];
        toIndex = i;
        break;
      }
    }
    drag.toIndex = toIndex;

    // 插入指示线
    if (insertBeforeItem) {
      drag.list.insertBefore(drag.indicator, insertBeforeItem);
    } else {
      drag.list.appendChild(drag.indicator);
    }
    drag.indicator.style.display = 'block';

    // 自动滚动
    const lr = drag.list.getBoundingClientRect();
    if (e.clientY > lr.bottom - 60) drag.list.scrollTop += 14;
    else if (e.clientY < lr.top + 60) drag.list.scrollTop -= 14;
  });

  document.addEventListener('mouseup', function(e) {
    if (!drag) return;

    // 清理 DOM 辅助元素
    if (drag.ghost.parentNode) drag.ghost.parentNode.removeChild(drag.ghost);
    if (drag.indicator.parentNode) drag.indicator.parentNode.removeChild(drag.indicator);
    drag.item.style.opacity = '';
    document.body.style.userSelect = '';
    document.body.style.cursor = '';

    let fromIndex = drag.fromIndex;
    let toIndex = drag.toIndex;
    drag = null;

    // toIndex 是"插到第 toIndex 个 item 之前"，换算到 splice 目标下标
    // 移走 fromIndex 后，如果 toIndex > fromIndex，实际位置需 -1
    if (toIndex > fromIndex) toIndex -= 1;
    if (toIndex === fromIndex) return;

    // 重排 slides 数组
    const [moved] = slides.splice(fromIndex, 1);
    slides.splice(toIndex, 0, moved);

    // 重建 deck DOM
    const deck = document.getElementById('deck');
    deck.innerHTML = '';
    slides.forEach((s, i) => {
      s.dataset.index = i;
      deck.appendChild(s);
    });

    // 修正 current 指针
    if (current === fromIndex) {
      current = toIndex;
    } else if (fromIndex < current && current <= toIndex) {
      current--;
    } else if (toIndex <= current && current < fromIndex) {
      current++;
    }
    current = Math.max(0, Math.min(current, slides.length - 1));
    slides[current].classList.add('active');

    updateUI();
    renderSortableList();
    saveOrder();  // 持久化排序到 localStorage
  });
  // ── 拖拽排序结束 ──────────────────────────────────

  document.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === ' ') { e.preventDefault(); changeSlide(1); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); changeSlide(-1); }
  });


  let touchStartX = 0;
  document.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  document.addEventListener('touchend', e => {
    if (Math.abs(e.changedTouches[0].clientX - touchStartX) > 50) changeSlide(e.changedTouches[0].clientX - touchStartX < 0 ? 1 : -1);
  }, { passive: true });

  // Mouse wheel navigation (throttled)
  let wheelLocked = false;
  document.addEventListener('wheel', e => {
    // 在设置面板内部允许正常滚动
    if (e.target.closest('.settings-panel')) return;
    e.preventDefault();
    if (wheelLocked) return;
    wheelLocked = true;
    changeSlide(e.deltaY > 0 ? 1 : -1);
    setTimeout(() => { wheelLocked = false; }, 600);
  }, { passive: false });

  // Fullscreen toggle
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  }

  // Update fullscreen button icon and nav visibility
  document.addEventListener('fullscreenchange', () => {
    const btn = document.getElementById('btnFullscreen');
    const navNormal = document.querySelector('.nav-normal');
    const navMinimal = document.querySelector('.nav-minimal');
    const settingsBtn = document.querySelector('.settings-btn');
    const isFullscreen = !!document.fullscreenElement;

    btn.innerHTML = isFullscreen ? '&#10006;' : '&#9974;';
    btn.title = isFullscreen ? '退出全屏' : '全屏';

    // Toggle nav visibility
    navNormal.style.display = isFullscreen ? 'none' : 'flex';
    navMinimal.style.display = isFullscreen ? 'flex' : 'none';

    // Hide settings button in fullscreen
    if (isFullscreen) {
      settingsBtn.classList.add('hidden');
    } else {
      settingsBtn.classList.remove('hidden');
    }
  });

  updateUI();

  // Sync logo width to BTN rendered width
  (function syncLogoWidth() {
    const logo = document.querySelector('.slide-logo');
    const btnText = logo.querySelector('.slide-logo-text');
    const w = btnText.getBoundingClientRect().width;
    logo.style.width = w + 'px';
  })();
</script>
</body>
</html>

```
