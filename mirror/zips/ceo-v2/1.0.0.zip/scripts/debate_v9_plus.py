#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨家五证 + 蜂群辩论系统 V9 Pro
动态并发 + 本地审核降级 + 标准库验证
"""

import os
import sys
import json
import urllib.request
import urllib.error
import re
import signal
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

HOME = Path.home()
SKILL_DIR = HOME / ".openclaw/skills/mohism-beehive-v9"
CHECKPOINT_FILE = HOME / ".openclaw/workspace/mohism_v9_checkpoint.json"
RESULT_FILE = HOME / ".openclaw/workspace/mohism_v9_result.json"
LOG_FILE = HOME / ".openclaw/workspace/mohism_v9_pro.log"

OLLAMA_HOST = "http://localhost:11434"

MODEL_POOL = [
    "qwen2.5:3b", "llama3.2:3b", "qwen2.5:1.5b",
    "gemma3:1b", "granite3.1-dense:2b", "qwen2.5:0.5b"
]
SENSITIVE = ["枪支", "炮弹", "炸弹", "核武", "化学武器", "生物武器", "毒品制造", "赌博平台", "色情", "涉密", "军工", "军用", "禁运", "违禁", "武器"]

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, 'a') as f:
        f.write(line + "\n")

def get_free_vram():
    """获取空闲GPU显存(MB)"""
    try:
        result = os.popen("nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits").read().strip()
        return int(result)
    except:
        return 2000  # 默认假设足够

def get_bee_count():
    """动态并发数"""
    vram = get_free_vram()
    if vram > 1500:
        count = 3
    elif vram > 800:
        count = 2
    else:
        count = 1
    log(f"📊 动态并发: {count} (GPU空闲{vram}MB)")
    return count

def call_ollama(model, prompt, timeout=45):
    try:
        req_data = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.3, "num_predict": 350}
        }).encode('utf-8')
        
        req = urllib.request.Request(
            f"{OLLAMA_HOST}/api/generate",
            data=req_data,
            headers={"Content-Type": "application/json"}
        )
        
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode('utf-8'))
        return result.get("response", "")
    except Exception as e:
        log(f"❌ {model}: {e}")
        return None

def parse_json(text):
    text = text.strip()
    text = re.sub(r'^```json\s*', '', text)
    text = re.sub(r'^```\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    
    m = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group())
        except:
            pass
    try:
        return json.loads(text)
    except:
        return {"raw": text[:100]}

def check_sensitive(text):
    for word in SENSITIVE:
        if word in text:
            return True, word
    return False, None

def local_audit_fallback(user_query, consensus_summary):
    """本地审核降级（云端不可用时）"""
    log("🔄 使用本地审核降级")
    
    prompt = f"""你是严格的内容评估专家。
问题：{user_query}
答案：{consensus_summary}

评估回答质量(0-1)：
- 回答是否针对问题
- 是否有依据
- 是否安全合规

输出JSON：{{"置信度":"0.XX","风险提示":"无/问题描述","行动":"输出用户"}}"""
    
    resp = call_ollama("qwen2.5:0.5b", prompt, timeout=30)
    if resp:
        data = parse_json(resp)
        if data:
            conf_str = data.get("置信度", "0")
            m = re.search(r'0\.\d+', conf_str)
            confidence = float(m.group()) if m else 0.7
            return data, confidence
    
    return {"置信度": "0.7", "风险提示": "本地审核", "行动": "输出用户"}, 0.7

class MohismBeehiveV9Plus:
    def __init__(self):
        self.user_query = ""
        self.current_round = 1
        self.max_rounds = 3
        self.rounds_history = []
        self.completed = False
        self.final_result = None
        self.circuit_broken = False
        self.model_index = 0
    
    def load_checkpoint(self):
        if CHECKPOINT_FILE.exists():
            try:
                with open(CHECKPOINT_FILE) as f:
                    data = json.load(f)
                log(f"📂 检查点已加载: 第{data.get('current_round',1)}轮")
                self.user_query = data.get("user_query", "")
                self.current_round = data.get("current_round", 1)
                self.rounds_history = data.get("rounds_history", [])
                self.completed = data.get("completed", False)
                self.final_result = data.get("final_result")
                return True
            except Exception as e:
                log(f"⚠️ 检查点加载失败: {e}")
        return False
    
    def save_checkpoint(self):
        try:
            data = {
                "user_query": self.user_query,
                "current_round": self.current_round,
                "rounds_history": self.rounds_history,
                "completed": self.completed,
                "final_result": self.final_result,
                "timestamp": datetime.now().isoformat()
            }
            with open(CHECKPOINT_FILE, 'w') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"💾 检查点已保存 (第{self.current_round}轮)")
        except Exception as e:
            log(f"❌ 保存检查点失败: {e}")
    
    def save_result(self):
        try:
            with open(RESULT_FILE, 'w') as f:
                json.dump(self.final_result, f, ensure_ascii=False, indent=2)
            log(f"💾 结果已保存")
        except Exception as e:
            log(f"❌ 保存结果失败: {e}")
    
    def get_round_models(self, count):
        models = []
        for i in range(count):
            idx = (self.model_index + i) % len(MODEL_POOL)
            models.append(MODEL_POOL[idx])
        self.model_index += count
        return models
    
    def stage1_mohist(self, context=""):
        log(f"【阶段一：墨家五证】 轮次:{self.current_round}/3")
        
        inputs = {
            "辟": f"""你是墨家「辟」反驳论证员。
问题：{self.user_query}
上下文：{context}

输出JSON：
{{"role":"辟","漏洞点":"...","依据":"[标:...]","风险等级":"高/中/低"}}
若敏感词：{{"role":"辟","熔断":true,"原因":"敏感词XX"}}""",
            
            "侔": f"""你是墨家「侔」类比校验员。
问题：{self.user_query}

输出JSON：
{{"role":"侔","类比片段":"...","源行业":"...","目标行业":"...","结论":"合理/不合理"}}""",
            
            "援": f"""你是墨家「援」溯源验证员。
上下文：{context or self.user_query}

输出JSON：
{{"role":"援","检查项":"...","状态":"完整/缺失","建议":"补充[标:GB/T...]"}}""",
            
            "推": f"""你是墨家「推」逻辑显式化员。
上下文：{context or self.user_query}

输出JSON：
{{"role":"推","优化结论":"...","逻辑完整性":"完整/缺口"}}""",
            
            "止": f"""你是墨家「止」风控熔断员。
内容：{self.user_query} {context}

输出JSON：
{{"role":"止","风控结论":"安全","依据":"无敏感词","行动":"通过"}}"""
        }
        
        results = {}
        for role, prompt in inputs.items():
            log(f"  {role}...")
            resp = call_ollama("qwen2.5:0.5b", prompt, timeout=25)
            if resp:
                data = parse_json(resp)
                if data:
                    results[role] = data
                    if data.get("熔断") or data.get("风控结论") == "熔断":
                        self.circuit_broken = True
        
        return list(results.values())
    
    def stage2_beehive(self, mohist_str, previous_feedback=""):
        bee_count = get_bee_count()  # 动态并发
        log(f"【阶段二：蜂群辩论】 并发{bee_count}模型")
        
        models = self.get_round_models(bee_count)
        bee_replies = []
        
        def call_bee(model, bee_id):
            prompt = f"""你是蜂群辩论专家，ID:{bee_id}。第{self.current_round}/3轮。

用户问题：{self.user_query}
墨家报告：{mohist_str[:1500]}
上轮驳回：{previous_feedback}

输出JSON：
{{"蜂群ID":"{bee_id}","核心观点":"...","依据锚点":"[标:GB/T...]","置信度":"高/中/低"}}"""
            resp = call_ollama(model, prompt, timeout=45)
            if resp:
                return parse_json(resp) or {"蜂群ID": bee_id, "核心观点": resp[:100]}
            return {"蜂群ID": bee_id, "核心观点": "调用失败"}
        
        with ThreadPoolExecutor(max_workers=bee_count) as executor:
            futures = [executor.submit(call_bee, models[i], f"B0{i+1}") for i in range(bee_count)]
            for future in as_completed(futures):
                try:
                    data = future.result()
                    bee_replies.append(data)
                    log(f"  蜂群{data.get('蜂群ID','?')}: {str(data.get('核心观点',''))[:35]}...")
                except Exception as e:
                    log(f"❌ 蜂群调用失败: {e}")
        
        return bee_replies
    
    def stage3_consensus(self, bee_replies):
        log(f"【阶段三：共识评估】")
        
        bee_str = json.dumps(bee_replies, ensure_ascii=False)[:2000]
        
        prompt = f"""你是共识评估员。第{self.current_round}/3轮。

评估蜂群回复是否达成共识。

蜂群回复：{bee_str}

输出JSON：
{{"共识状态":"成立/未成立","共识度":"0.XX","共识摘要":"...","关键分歧":["..."],"行动建议":"进入审核/重入墨家"}}"""
        
        resp = call_ollama("qwen2.5:0.5b", prompt, timeout=35)
        if resp:
            data = parse_json(resp)
            log(f"  共识: {data.get('共识状态','?')} ({data.get('共识度','?')})")
            return data
        return {"共识状态": "未成立", "共识摘要": "评估失败"}
    
    def stage4_cloud(self, consensus_summary):
        log(f"【阶段四：云端审核】")
        
        prompt = f"""云端审核员，评估置信度。第{self.current_round}/3轮。

问题：{self.user_query}
共识：{consensus_summary}

输出JSON：
{{"置信度":"0.XX","维度评分":{{"覆盖度":0.9,"可靠性":0.85,"严谨性":0.92,"安全性":1.0}},"风险提示":"无","行动":"输出用户/重入墨家"}}"""
        
        try:
            resp = call_ollama("qwen2.5:3b", prompt, timeout=50)
            if resp:
                data = parse_json(resp)
                conf_str = data.get("置信度", "0")
                m = re.search(r'0\.\d+', conf_str)
                confidence = float(m.group()) if m else 0.0
                log(f"  置信度: {confidence}")
                return data, confidence
        except Exception as e:
            log(f"⚠️ 云端审核异常: {e}")
        
        # 降级到本地审核
        return local_audit_fallback(self.user_query, consensus_summary)
    
    def run(self, user_query=None):
        if user_query:
            self.user_query = user_query
        else:
            if not self.load_checkpoint():
                log("❌ 无检查点且无问题")
                return {"status": "错误"}
            
            if self.completed and self.final_result:
                log("✅ 检查点已完成")
                return self.final_result
            
            log(f"📂 从第{self.current_round}轮继续...")
        
        log("=" * 60)
        log(f"V9 Pro | 问题: {self.user_query[:40]}...")
        log("=" * 60)
        
        is_sens, word = check_sensitive(self.user_query)
        if is_sens:
            return {"status": "熔断", "reason": f"敏感词{word}"}
        
        context = ""
        
        for self.current_round in range(self.current_round, self.max_rounds + 1):
            log(f"\n{'='*50} 第{self.current_round}轮 {'='*50}")
            
            mohist_report = self.stage1_mohist(context)
            if self.circuit_broken:
                return {"status": "熔断", "reason": "敏感词"}
            
            mohist_str = json.dumps(mohist_report, ensure_ascii=False)
            previous_feedback = self.rounds_history[-1].get("cloud", {}).get("风险提示", "") if self.rounds_history else ""
            bee_replies = self.stage2_beehive(mohist_str, previous_feedback)
            consensus_result = self.stage3_consensus(bee_replies)
            
            cloud_result = {"置信度": "0", "行动": "重入墨家"}
            confidence = 0.0
            
            if consensus_result.get("共识状态") == "成立":
                cloud_result, confidence = self.stage4_cloud(consensus_result.get("共识摘要", ""))
            
            round_data = {
                "round": self.current_round,
                "mohist_report": mohist_report,
                "bee_replies": bee_replies,
                "consensus": consensus_result,
                "cloud": cloud_result,
                "timestamp": datetime.now().isoformat()
            }
            self.rounds_history.append(round_data)
            self.save_checkpoint()
            
            if confidence >= 0.92:
                log(f"✅ 置信度达标({confidence})")
                self.completed = True
                self.final_result = {
                    "status": "完成",
                    "总轮次": self.current_round,
                    "最终置信度": f"{confidence}",
                    "最终共识": consensus_result.get("共识摘要", ""),
                    "依据": [r.get("依据锚点", "") for r in bee_replies if r.get("依据锚点")],
                    "蜂群报告": bee_replies,
                    "墨家报告": mohist_report
                }
                self.save_result()
                return self.final_result
            
            context = f"上轮共识：{consensus_result.get('共识摘要','')}。云端驳回：{cloud_result.get('风险提示','')}"
            log(f"⚠️ 置信度不足({confidence})，进入第{self.current_round+1}轮")
        
        log("⚠️ 达到最大轮次")
        self.completed = True
        last = self.rounds_history[-1] if self.rounds_history else {}
        self.final_result = {
            "status": "强制输出",
            "总轮次": self.max_rounds,
            "最终置信度": "0.85",
            "最终共识": last.get("consensus", {}).get("共识摘要", "经3轮校验"),
            "蜂群报告": last.get("bee_replies", []),
            "墨家报告": last.get("mohist_report", [])
        }
        self.save_result()
        return self.final_result

def main():
    if len(sys.argv) < 2:
        print("用法: debate_v9_plus.py <问题>")
        sys.exit(1)
    
    user_query = sys.argv[1]
    debate = MohismBeehiveV9Plus()
    
    try:
        result = debate.run(user_query)
    except KeyboardInterrupt:
        log("⚠️ 用户中断")
        result = {"status": "中断"}
    except Exception as e:
        log(f"❌ 异常: {e}")
        result = {"status": "异常", "reason": str(e)}
    
    print("\n" + "=" * 60)
    print("最终结果:")
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()