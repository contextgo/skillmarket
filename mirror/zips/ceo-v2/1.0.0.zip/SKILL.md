name: mohism-beehive-v9
description: 墨家五证+蜂群辩论V9断点续跑版。SIGKILL后可续跑，状态持久化，三轮置信度收敛。
metadata:
  openclaw:
    emoji: 🔄
invoke:
  type: python_function
  module: mohism-beehive-v9.scripts.main
  function: run
capabilities:
- name: execute
  description: mohism-beehive-v9执行
  parameters: []
