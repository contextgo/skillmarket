#!/usr/bin/env python3
"""Sage Router - Dynamic provider discovery and routing"""
import argparse, ipaddress, json, logging, math, os, re, shutil, socket, subprocess, threading, time, urllib.error, urllib.parse, urllib.request, uuid
from dataclasses import dataclass
from enum import Enum, auto
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, List

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("router")
SAGE_ROUTER_HOME = os.path.expanduser(os.environ.get('SAGE_ROUTER_HOME', '~/.openclaw'))
OPENCLAW_CONFIG = os.environ.get('SAGE_ROUTER_OPENCLAW_CONFIG', os.path.join(SAGE_ROUTER_HOME, 'openclaw.json'))
OPENCLAW_DOTENV = os.environ.get('SAGE_ROUTER_OPENCLAW_DOTENV', os.path.join(SAGE_ROUTER_HOME, '.env'))
PROVIDER_PROFILES_PATH = os.path.join(os.path.dirname(__file__), 'provider-profiles.json')
ROUTER_PROFILES_PATH = os.path.join(os.path.dirname(__file__), 'router-profiles.json')
OPENCLAW_GATEWAY_HELPER = os.path.join(os.path.dirname(__file__), 'openclaw_gateway_agent.mjs')
SELF_PROVIDER_NAMES = {'smart-router', 'sage-router'}
LOCAL_STRICT_PROXY_PROVIDER_NAMES = {'dario', 'openai-codex', 'grok-sso'}
LOCAL_STRICT_PROXY_API_TYPES = {'openclaw-gateway', 'openai-codex-responses'}
LOCAL_STRICT_DECENTRALIZED_PROVIDER_NAMES = {'darkbloom'}
SHOW_MODEL_PREFIX = True  # Show provider/model at start of response by default


def load_env_file(path):
    try:
        with open(path) as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                key = key.strip()
                if not key or key in os.environ:
                    continue
                value = value.strip()
                if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
                    value = value[1:-1]
                os.environ[key] = value
    except FileNotFoundError:
        return
    except Exception as e:
        logger.debug(f'Failed to load env file {path}: {e}')


load_env_file(OPENCLAW_DOTENV)
load_env_file(os.path.join(os.path.dirname(__file__), '.env'))

# Backward compat: fall back to SMART_ROUTER_* env vars if SAGE_ROUTER_* not set
import re as _re
_env_compat_done = set()
for _key in list(os.environ):
    if _key.startswith('SMART_ROUTER_') and _key not in os.environ:
        pass  # can't happen, but guard
for _key in list(os.environ):
    if _key.startswith('SMART_ROUTER_'):
        _new_key = _key.replace('SMART_ROUTER_', 'SAGE_ROUTER_', 1)
        if _new_key not in os.environ:
            os.environ[_new_key] = os.environ[_key]
DARIO_PROVIDER_NAME = os.environ.get('SAGE_ROUTER_DARIO_PROVIDER_NAME', 'dario')
DARIO_LOCAL_BASE_URL = os.environ.get('SAGE_ROUTER_DARIO_BASE_URL', 'http://127.0.0.1:3456')
DARIO_LOCAL_API_KEY = os.environ.get('SAGE_ROUTER_DARIO_API_KEY', 'dario')
DARIO_SERVICE_NAME = os.environ.get('SAGE_ROUTER_DARIO_SERVICE', 'dario.service')
DARIO_AUTOSTART = os.environ.get('SAGE_ROUTER_DARIO_AUTOSTART', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
DARIO_PROCESS = None
OPENCLAW_GATEWAY_BASE_URL = os.environ.get('SAGE_ROUTER_OPENCLAW_GATEWAY_URL', 'ws://127.0.0.1:18789')
# Auth-profile-based gateway providers: defined after DEFAULT constants below
DISABLED_PROVIDERS = {
    name.strip() for name in os.environ.get('SAGE_ROUTER_DISABLED_PROVIDERS', '').split(',')
    if name.strip()
}
DISABLED_MODELS = {
    name.strip() for name in os.environ.get('SAGE_ROUTER_DISABLED_MODELS', '').split(',')
    if name.strip()
}
OLLAMA_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_OLLAMA_TIMEOUT_SECONDS', '120'))
OLLAMA_ALLOW_THINK_FALSE_RETRY = os.environ.get('SAGE_ROUTER_OLLAMA_ALLOW_THINK_FALSE_RETRY', '').strip().lower() in {'1', 'true', 'yes', 'on'}
OPENAI_COMPAT_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_OPENAI_TIMEOUT_SECONDS', '35'))
ANTHROPIC_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_ANTHROPIC_TIMEOUT_SECONDS', '35'))
GOOGLE_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_GOOGLE_TIMEOUT_SECONDS', '35'))
OPENCLAW_GATEWAY_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_OPENCLAW_TIMEOUT_SECONDS', '20'))
OPENCLAW_GATEWAY_CODE_TIMEOUT_SECONDS = int(os.environ.get('SAGE_ROUTER_OPENCLAW_CODE_TIMEOUT_SECONDS', '45'))
OPENCLAW_GATEWAY_AGENT_ID = os.environ.get('SAGE_ROUTER_OPENCLAW_AGENT_ID', 'main')
REACHABILITY_TIMEOUT_SECONDS = float(os.environ.get('SAGE_ROUTER_REACHABILITY_TIMEOUT_SECONDS', '0.5'))
REACHABILITY_TTL_SECONDS = int(os.environ.get('SAGE_ROUTER_REACHABILITY_TTL_SECONDS', '120'))
OLLAMA_MODEL_REFRESH_TTL_SECONDS = int(os.environ.get('SAGE_ROUTER_OLLAMA_MODEL_REFRESH_TTL_SECONDS', '300'))
HEALTH_SCORE_TTL_SECONDS = int(os.environ.get('SAGE_ROUTER_HEALTH_SCORE_TTL_SECONDS', '60'))
RATE_LIMIT_COOLDOWN_BASE_SECONDS = int(os.environ.get('SAGE_ROUTER_RATE_LIMIT_COOLDOWN_BASE_SECONDS', '120'))
FAILURE_COOLDOWN_BASE_SECONDS = int(os.environ.get('SAGE_ROUTER_FAILURE_COOLDOWN_BASE_SECONDS', '180'))
CONSECUTIVE_FAILURE_COOLDOWN_THRESHOLD = int(os.environ.get('SAGE_ROUTER_CONSECUTIVE_FAILURE_COOLDOWN_THRESHOLD', '2'))
MODEL_MISSING_COOLDOWN_SECONDS = int(os.environ.get('SAGE_ROUTER_MODEL_MISSING_COOLDOWN_SECONDS', '1800'))
EMPTY_OUTPUT_COOLDOWN_SECONDS = int(os.environ.get('SAGE_ROUTER_EMPTY_OUTPUT_COOLDOWN_SECONDS', '600'))
PROVIDER_HEALTH_CACHE = {}
LATENCY_STATS_PATH = os.path.expanduser(os.environ.get('SAGE_ROUTER_LATENCY_STATS_PATH', '~/.cache/sage-router/latency-stats.json'))
ROUTE_EVENTS_PATH = os.path.expanduser(os.environ.get('SAGE_ROUTER_ROUTE_EVENTS_PATH', '~/.cache/sage-router/route-events.jsonl'))
ANALYTICS_TOKEN = os.environ.get('SAGE_ROUTER_ANALYTICS_TOKEN', '').strip()
ANALYTICS_EVENT_LIMIT = int(os.environ.get('SAGE_ROUTER_ANALYTICS_EVENT_LIMIT', '10000'))
FIRESTORE_PROJECT_ID = os.environ.get('SAGE_ROUTER_FIRESTORE_PROJECT_ID') or os.environ.get('GOOGLE_CLOUD_PROJECT') or os.environ.get('GCP_PROJECT')
FIRESTORE_DATABASE = os.environ.get('SAGE_ROUTER_FIRESTORE_DATABASE', '(default)')
FIRESTORE_ROUTE_EVENTS_COLLECTION = os.environ.get('SAGE_ROUTER_FIRESTORE_ROUTE_EVENTS_COLLECTION', 'sage_router_route_events')
FIRESTORE_ENABLED = os.environ.get('SAGE_ROUTER_FIRESTORE_ENABLED', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
SUPABASE_URL = (os.environ.get('SAGE_ROUTER_SUPABASE_URL') or os.environ.get('PUBLIC_SUPABASE_URL') or os.environ.get('SUPABASE_URL') or '').rstrip('/')
SUPABASE_ANON_KEY = os.environ.get('SAGE_ROUTER_SUPABASE_ANON_KEY') or os.environ.get('AOPS_SUPABASE_ANON_KEY') or os.environ.get('SUPABASE_ANON_KEY') or ''
SUPABASE_SERVICE_ROLE_KEY = os.environ.get('SAGE_ROUTER_SUPABASE_SERVICE_ROLE_KEY') or os.environ.get('SUPABASE_SERVICE_ROLE') or os.environ.get('SUPABASE_SERVICE_ROLE_KEY') or ''
SUPABASE_ROUTE_EVENTS_TABLE = os.environ.get('SAGE_ROUTER_SUPABASE_ROUTE_EVENTS_TABLE', 'sage_router_route_events')
SUPABASE_ANALYTICS_SNAPSHOTS_TABLE = os.environ.get('SAGE_ROUTER_SUPABASE_ANALYTICS_SNAPSHOTS_TABLE', 'sage_router_analytics_snapshots')
SUPABASE_MIRROR_ENABLED = os.environ.get('SAGE_ROUTER_SUPABASE_MIRROR_ENABLED', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
SUPABASE_AUTH_ENABLED = os.environ.get('SAGE_ROUTER_SUPABASE_AUTH_ENABLED', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
CORS_ORIGIN = os.environ.get('SAGE_ROUTER_CORS_ORIGIN', '*')
CORS_ORIGINS = [o.strip() for o in CORS_ORIGIN.split(',') if o.strip()]
LATENCY_EWMA_ALPHA = float(os.environ.get('SAGE_ROUTER_LATENCY_EWMA_ALPHA', '0.35'))
GENERAL_EMPIRICAL_EXPLORATION_BONUS = float(os.environ.get('SAGE_ROUTER_GENERAL_EXPLORATION_BONUS', '20'))
GENERAL_EMPIRICAL_SUCCESS_EXPLORATION_CAP = float(os.environ.get('SAGE_ROUTER_GENERAL_SUCCESS_EXPLORATION_CAP', '8'))
GENERAL_EMPIRICAL_LATENCY_BONUS_CAP = float(os.environ.get('SAGE_ROUTER_GENERAL_LATENCY_BONUS_CAP', '18'))
GENERAL_EMPIRICAL_LATENCY_PIVOT_MS = float(os.environ.get('SAGE_ROUTER_GENERAL_LATENCY_PIVOT_MS', '2500'))
GENERAL_EMPIRICAL_FAILURE_PENALTY = float(os.environ.get('SAGE_ROUTER_GENERAL_FAILURE_PENALTY', '4'))
DEFAULT_OPENAI_CODEX_MODELS = ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-pro', 'gpt-5.4-mini', 'gpt-5.3-codex', 'gpt-5.3-codex-spark', 'gpt-5.2-codex', 'gpt-5.1-codex-max', 'gpt-5.1-codex-mini', 'gpt-5.1']
DEFAULT_NGC_MODELS = ['nemotron-tts', 'canary-asr', 'nemo-tts', 'nemo-asr', 'nvidia/tts', 'nvidia/asr']
DEFAULT_ANTHROPIC_MODELS = ['claude-opus-4-6', 'claude-opus-4-5', 'claude-opus-4-1', 'claude-opus-4-0', 'claude-sonnet-4-6', 'claude-sonnet-4-5', 'claude-sonnet-4-0', 'claude-haiku-4-5', 'claude-3-7-sonnet-latest', 'claude-3-5-sonnet-latest']
DEFAULT_DARKBLOOM_MODELS = ['mlx-community/gemma-4-26b-a4b-it-8bit', 'qwen3.5-27b-claude-opus-8bit', 'mlx-community/Trinity-Mini-8bit', 'mlx-community/Qwen3.5-122B-A10B-8bit', 'mlx-community/MiniMax-M2.5-8bit']


def extract_http_error(exc: Exception) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        try:
            body = exc.read().decode('utf-8', errors='replace').strip()
        except Exception:
            body = ''
        detail = f"HTTP {exc.code} {exc.reason}"
        return f"{detail} | {body[:300]}" if body else detail
    return str(exc)


# Auth-profile-based gateway providers: auto-created when matching profile exists
# Maps auth profile provider name -> (api_type, default_models, default_meta)
GATEWAY_PROVIDER_PROFILES = {
    'openai-codex': ('openclaw-gateway', DEFAULT_OPENAI_CODEX_MODELS, {'reasoning': True, 'contextWindow': 256000, 'maxTokens': 128000, 'input': ['text']}),
    'nvidia-ngc': ('https://api.ngc.nvidia.com', DEFAULT_NGC_MODELS, {'reasoning': False, 'contextWindow': 16384, 'maxTokens': 4096, 'input': ['text', 'audio'], 'output': ['text', 'audio']}),
    'anthropic': ('anthropic-messages', DEFAULT_ANTHROPIC_MODELS, {'reasoning': True, 'contextWindow': 1000000, 'maxTokens': 64000, 'input': ['text']}),
    'openai': ('openai-completions', ['gpt-5.4', 'gpt-5.4-mini', 'gpt-4o', 'gpt-4o-mini'], {'reasoning': False, 'contextWindow': 128000, 'maxTokens': 16384, 'input': ['text']}),
    'google': ('google-generative-language', ['gemini-3-flash-preview', 'gemini-2.5-pro', 'gemini-2.5-flash'], {'reasoning': False, 'contextWindow': 1000000, 'maxTokens': 65536, 'input': ['text', 'image']}),
    'xai': ('openai-completions', ['grok-3', 'grok-3-mini', 'grok-2'], {'reasoning': False, 'contextWindow': 128000, 'maxTokens': 16384, 'input': ['text']}),
    'zai': ('openai-completions', ['z1-ultra', 'z1-pro', 'z1-mini'], {'reasoning': True, 'contextWindow': 256000, 'maxTokens': 65536, 'input': ['text']}),
    'darkbloom': ('openai-completions', DEFAULT_DARKBLOOM_MODELS, {'reasoning': False, 'contextWindow': 131072, 'maxTokens': 16384, 'input': ['text']}),
    'github-copilot': ('openclaw-gateway', ['gpt-5.4', 'gpt-5.4-mini', 'claude-sonnet-4-5', 'gemini-2.5-pro'], {'reasoning': True, 'contextWindow': 256000, 'maxTokens': 128000, 'input': ['text']}),
    'bedrock': ('openclaw-gateway', ['anthropic.claude-sonnet-4-5', 'anthropic.claude-haiku-4-5', 'amazon.nova-pro', 'amazon.nova-lite', 'meta.llama4-405b'], {'reasoning': True, 'contextWindow': 200000, 'maxTokens': 64000, 'input': ['text']}),
    'azure-openai': ('openclaw-gateway', ['gpt-5.4', 'gpt-5.4-mini', 'gpt-4o', 'gpt-4o-mini'], {'reasoning': False, 'contextWindow': 128000, 'maxTokens': 16384, 'input': ['text']}),
}
MAX_PROVIDER_ATTEMPTS = int(os.environ.get('SAGE_ROUTER_MAX_PROVIDER_ATTEMPTS', '8'))
OPENROUTER_FREE_ONLY = os.environ.get('SAGE_ROUTER_OPENROUTER_FREE_ONLY', '0').strip().lower() in {'1', 'true', 'yes', 'on'}
INTENT_CLASSIFIER_ENABLED = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_ENABLED', '0').strip().lower() in {'1', 'true', 'yes', 'on'}
INTENT_CLASSIFIER_PROVIDER = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_PROVIDER', 'ollama')
INTENT_CLASSIFIER_BASE_URL = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_BASE_URL', 'http://127.0.0.1:11434')
INTENT_CLASSIFIER_API_KEY = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_API_KEY', os.environ.get('LLAMACPP_API_KEY', 'local'))
INTENT_CLASSIFIER_MODEL = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_MODEL', 'qwen2.5:0.5b-instruct')
INTENT_CLASSIFIER_TIMEOUT_SECONDS = float(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_TIMEOUT_SECONDS', '3'))
INTENT_CLASSIFIER_MIN_CONFIDENCE = float(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_MIN_CONFIDENCE', '0.65'))
INTENT_CLASSIFIER_MAX_PROMPT_CHARS = int(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_MAX_PROMPT_CHARS', '4000'))
INTENT_CLASSIFIER_ONLY_IF_HEURISTIC_BELOW = int(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_ONLY_IF_HEURISTIC_BELOW', '2'))
# The intent model must never sit on the request path.  Keep routing heuristic-first,
# and let the optional classifier warm a tiny cache for later similar turns only.
INTENT_CLASSIFIER_ASYNC = os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_ASYNC', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
INTENT_CLASSIFIER_CACHE_TTL_SECONDS = int(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_CACHE_TTL_SECONDS', '86400'))
INTENT_CLASSIFIER_CACHE_MAX = int(os.environ.get('SAGE_ROUTER_INTENT_CLASSIFIER_CACHE_MAX', '512'))
INTENT_CLASSIFIER_CACHE = {}
INTENT_CLASSIFIER_CACHE_LOCK = threading.Lock()
LATENCY_STATS_LOCK = threading.Lock()
OLLAMA_MODEL_CACHE = {}
OLLAMA_CLOUD_CATALOG_CACHE = {'checked_at': 0, 'models': []}
OLLAMA_CLOUD_CATALOG_TTL_SECONDS = int(os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_CATALOG_TTL_SECONDS', '21600'))
OLLAMA_CLOUD_CATALOG_URL = os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_CATALOG_URL', 'https://ollama.com/search?c=cloud')
OLLAMA_CLOUD_CATALOG_MAX_LIBRARIES = int(os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_CATALOG_MAX_LIBRARIES', '200'))
OLLAMA_CLOUD_CATALOG_MAX_PAGES = int(os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_CATALOG_MAX_PAGES', '8'))
OLLAMA_CLOUD_CATALOG_ENABLED = os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_CATALOG_ENABLED', '1').strip().lower() in {'1', 'true', 'yes', 'on'}
LOCAL_OLLAMA_CLOUD_AUTH_BLOCKS = {}
MODEL_HEALTH_CACHE = {}
TEMP_MODEL_BLOCKS = {}
LAST_ROUTE_DEBUG = {
    'updated_at': None,
    'request_id': None,
    'intent': None,
    'complexity': None,
    'thinking': None,
    'routeMode': None,
    'requirements': {},
    'estimatedTokens': 0,
    'json': False,
    'chain': [],
    'scores': [],
    'rejections': [],
    'selected': None,
    'attempts': [],
    'streaming': None,
    'status': None,
    'error': None,
    'totalElapsedMs': None,
}
BACKGROUND_REFRESH_STARTED = False
def canonical_provider_env_key(name: str):
    return (name or '').strip().lower().replace('-', '_')


def load_ollama_manifest_bindings(kind: str):
    prefix = f'SAGE_ROUTER_OLLAMA_MANIFEST_{kind}__'
    bindings = {}
    for key, value in os.environ.items():
        if key.startswith(prefix) and value.strip():
            provider_name = canonical_provider_env_key(key[len(prefix):])
            if provider_name:
                bindings[provider_name] = value.strip()
    return bindings


OLLAMA_MANIFEST_URLS = load_ollama_manifest_bindings('URL')
OLLAMA_MANIFEST_FILES = load_ollama_manifest_bindings('FILE')

INTENT_API_SCORES = {
    'CODE': {'ollama': 60, 'openai-completions': 58, 'anthropic-messages': 48, 'google-generative-language': 44},
    'ANALYSIS': {'ollama': 66, 'anthropic-messages': 58, 'openai-completions': 54, 'google-generative-language': 52},
    'CREATIVE': {'anthropic-messages': 60, 'google-generative-language': 59, 'openai-completions': 55, 'ollama': 50},
    'REALTIME': {'google-generative-language': 60, 'openai-completions': 60, 'anthropic-messages': 54, 'ollama': 48},
    'GENERAL': {'anthropic-messages': 58, 'google-generative-language': 57, 'openai-completions': 56, 'ollama': 50},
}

INTENT_MODEL_HINTS = {
    'CODE': ['coder', 'opus', 'sonnet', 'codex', 'gpt-5', 'deepseek', 'qwen', 'kimi', 'glm', 'gptoss'],
    'ANALYSIS': ['opus', 'sonnet', 'gpt-5', 'o3', 'qwen', 'kimi', 'minimax', 'glm'],
    'CREATIVE': ['opus', 'sonnet', 'minimax', 'kimi', 'gpt-5', 'qwen'],
    'REALTIME': ['gpt-4o', 'gpt-5', 'sonnet', 'kimi', 'qwen', 'glm'],
    'GENERAL': ['sonnet', 'gpt-4o', 'gpt-5', 'kimi', 'minimax', 'qwen', 'glm', 'opus'],
}

COMPLEX_MODEL_HINTS = ['opus', 'sonnet', 'gpt-5', 'o3', 'glm', 'qwen', 'kimi', 'deepseek']
LIGHTWEIGHT_MODEL_HINTS = ['mini', 'small', 'haiku']
OLLAMA_FAMILY_HINTS = {
    'qwen': {'bonus': 9, 'intents': {'CODE', 'ANALYSIS', 'GENERAL'}},
    'kimi': {'bonus': 8, 'intents': {'CODE', 'GENERAL', 'CREATIVE', 'REALTIME'}},
    'kimi-k2': {'bonus': 9, 'intents': {'CODE', 'GENERAL', 'CREATIVE', 'REALTIME', 'ANALYSIS'}},
    'glm': {'bonus': 11, 'intents': {'CODE', 'ANALYSIS', 'GENERAL', 'REALTIME'}},
    'minimax': {'bonus': 6, 'intents': {'CREATIVE', 'GENERAL'}},
    'deepseek': {'bonus': 10, 'intents': {'CODE', 'ANALYSIS'}},
    'llama': {'bonus': 5, 'intents': {'GENERAL', 'CREATIVE'}},
    'gptoss': {'bonus': 7, 'intents': {'CODE', 'GENERAL', 'ANALYSIS'}},
    'qwen3moe': {'bonus': 8, 'intents': {'CODE', 'GENERAL'}},
    'qwen35moe': {'bonus': 9, 'intents': {'CODE', 'ANALYSIS', 'GENERAL'}},
}


OLLAMA_TOOL_MODEL_HINTS = [
    'qwen3', 'qwen2.5', 'qwen2', 'kimi', 'minimax', 'glm-5', 'glm-4',
    'gpt-oss', 'llama3.1', 'llama3.2', 'llama3.3', 'mistral', 'mixtral', 'nemotron'
]
OLLAMA_NON_TOOL_MODEL_HINTS = ['embed', 'embedding', 'ocr', 'vision', '-vl', ':vl', 'whisper', 'tts']
NVIDIA_TOOL_MODEL_HINTS = [
    'nemotron', 'llama', 'qwen', 'deepseek', 'mistral', 'mixtral', 'gpt-oss', 'glm', 'kimi'
]
NVIDIA_NON_TOOL_MODEL_HINTS = [
    'tts', 'asr', 'canary', 'nemo-tts', 'nemo-asr', 'embed', 'embedding', 'rerank', 'ocr', 'vision', '-vl', ':vl', 'whisper'
]

ANALYSIS_SIGNAL_TERMS = [
    'analyze', 'analysis', 'evaluate', 'assess', 'compare', 'tradeoff', 'trade-off',
    'why', 'how should', 'how can', 'what should', 'should we', 'can we', 'could we',
    'root cause', 'diagnose', 'strategy', 'recommend', 'recommendation', 'decide',
    'risk', 'failure mode', 'implication', 'forecast', 'predict', 'prioritize',
    'optimize', 'improve', 'smarter', 'heuristic', 'architecture', 'routing',
    'user experience', 'discord-public', 'public channel',
]
ANALYSIS_QUALITY_MODEL_HINTS = [
    'opus', 'sonnet', 'gpt-5.5', 'gpt-5.4', 'gpt-5.3', 'gpt-5', 'o3',
    'gemini-2.5-pro', 'gemini-3-pro', 'qwen3.5', 'qwen3:32b', 'qwen3:30b',
    'kimi-k2', 'minimax-m2.7', 'glm-5', 'deepseek-v4',
]
WEAK_ANALYSIS_MODEL_HINTS = [
    'mini', 'small', 'haiku', 'flash', 'flash-lite', 'lite', 'nano', 'tiny',
    '0.5b', '1b', '3b', '7b', '8b', '12b', '14b', '16b',
]

# Known NON-chat families - dynamically extended from /api/tags.
# A family is non-chat if it matches these patterns or is explicitly listed.
NON_CHAT_FAMILY_PATTERNS = ['embed', 'bert', 'clip', 'vl', 'vision', 'ocr', 'asr', 'whisper', 'tts', 'sd', 'rerank']
NON_CHAT_MODEL_HINTS = [
    'embed', 'embedding', 'rerank', 'bge-', 'nomic-embed', 'whisper', 'tts', 'sdxl', 'stable-diffusion',
    '-vl', ':vl', 'vision', 'ocr', 'asr', 'transcribe', 'glm-ocr'
]

# Ollama model families that are NOT text-chat capable.
# Seed list - dynamically extended by background_refresh_detect_families().
NON_CHAT_OLLAMA_FAMILIES = {
    'nomic-bert',   # embedding
    'glmocr',      # OCR vision
    'qwen3vl',     # vision-language
    'llava',       # vision-language
    'clip',        # image embedding
    'bakllava',    # vision-language
    'moondream',   # vision-language
    'minicpm-v',   # vision-language
    'llama-vision',# vision-language
}

class Intent(Enum):
    CODE = auto(); ANALYSIS = auto(); CREATIVE = auto(); REALTIME = auto(); GENERAL = auto()
class Complexity(Enum):
    SIMPLE = auto(); MEDIUM = auto(); COMPLEX = auto()
class ThinkingLevel(Enum):
    LOW = 'low'; MEDIUM = 'medium'; HIGH = 'high'

@dataclass
class Provider:
    name: str; api_type: str; base_url: str; api_key: str; models: List[str]; reasoning_models: set[str] | None = None; model_meta: dict[str, dict[str, Any]] | None = None


def dedupe_keep_order(items):
    seen = set()
    ordered = []
    for item in items:
        if not item or item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return ordered


def merge_provider(providers, provider):
    existing = providers.get(provider.name)
    if not existing:
        providers[provider.name] = provider
        return
    merged_meta = dict(existing.model_meta or {})
    merged_meta.update(provider.model_meta or {})
    providers[provider.name] = Provider(
        provider.name,
        provider.api_type or existing.api_type,
        provider.base_url or existing.base_url,
        provider.api_key or existing.api_key,
        dedupe_keep_order((existing.models or []) + (provider.models or [])),
        set(existing.reasoning_models or set()) | set(provider.reasoning_models or set()),
        merged_meta,
    )

def resolve_config_value(value):
    if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
        return os.environ.get(value[2:-1], '')
    return value


def is_self_provider(name, base_url):
    if name in SELF_PROVIDER_NAMES:
        return True
    parsed = urllib.parse.urlparse(base_url or '')
    return parsed.hostname in {'127.0.0.1', 'localhost'} and parsed.port == 8788


def is_local_dario_endpoint(base_url):
    parsed = urllib.parse.urlparse(base_url or '')
    return parsed.hostname in {'127.0.0.1', 'localhost'} and parsed.port == 3456


def is_lan_or_tailnet_endpoint(base_url):
    """True when the provider endpoint itself is local/LAN/Tailnet.

    Used by route=local-first, which is intentionally local-strict: no
    Internet API endpoints, even if they are otherwise healthy and cheap.
    Allows loopback, RFC1918/private LAN, link-local, IPv6 ULA, and
    Tailscale/CGNAT 100.64.0.0/10 addresses. Bare hostnames and .local/.lan
    names are treated as local network names.
    """
    parsed = urllib.parse.urlparse(base_url or '')
    host = (parsed.hostname or '').strip().lower().rstrip('.')
    if not host:
        return False
    if host in {'localhost'}:
        return True
    if '.' not in host and ':' not in host:
        return True
    if host.endswith(('.local', '.lan', '.home', '.tailnet')):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    tailscale_cgnat = ip.version == 4 and ip in ipaddress.ip_network('100.64.0.0/10')
    return bool(ip.is_loopback or ip.is_private or ip.is_link_local or tailscale_cgnat)


def provider_allowed_in_local_first(provider):
    if provider.name in LOCAL_STRICT_DECENTRALIZED_PROVIDER_NAMES:
        return True
    if provider.name in LOCAL_STRICT_PROXY_PROVIDER_NAMES:
        return False
    if provider.api_type in LOCAL_STRICT_PROXY_API_TYPES:
        return False
    return is_lan_or_tailnet_endpoint(provider.base_url)


def local_first_rejection_reason(provider):
    if provider.name in LOCAL_STRICT_PROXY_PROVIDER_NAMES or provider.api_type in LOCAL_STRICT_PROXY_API_TYPES:
        return 'excluded by local-first (known cloud/SSO proxy provider)'
    return 'excluded by local-first (endpoint is not LAN/Tailnet/local)'


def should_route_anthropic_to_dario(name, api_type, base_url):
    host = (urllib.parse.urlparse(base_url or '').hostname or '').lower()
    if name == DARIO_PROVIDER_NAME or is_local_dario_endpoint(base_url):
        return False
    if name == 'anthropic':
        return True
    return api_type == 'anthropic-messages' and ('anthropic.com' in host or host == 'api.anthropic.com')


def dario_endpoint_ready(timeout=0.5):
    parsed = urllib.parse.urlparse(DARIO_LOCAL_BASE_URL or '')
    host = parsed.hostname or '127.0.0.1'
    port = parsed.port or 3456
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def ensure_dario_proxy_ready():
    """Ensure the Dario Anthropic-compatible proxy is reachable.

    On systemd hosts this preserves the old user-service behavior. In Docker or
    other non-systemd runtimes, it can autostart the bundled `dario proxy`
    binary when SAGE_ROUTER_DARIO_AUTOSTART is truthy.
    """
    global DARIO_PROCESS
    if dario_endpoint_ready():
        return True
    try:
        if shutil.which('systemctl'):
            active = subprocess.run(
                ['systemctl', '--user', 'is-active', '--quiet', DARIO_SERVICE_NAME],
                check=False,
                capture_output=True,
                timeout=5,
            )
            if active.returncode == 0 and dario_endpoint_ready(timeout=1.0):
                return True
            if shutil.which('dario'):
                start = subprocess.run(
                    ['systemctl', '--user', 'start', DARIO_SERVICE_NAME],
                    check=False,
                    capture_output=True,
                    timeout=10,
                )
                if start.returncode == 0:
                    for _ in range(20):
                        if dario_endpoint_ready(timeout=0.5):
                            logger.info(f'Started {DARIO_SERVICE_NAME} for Anthropic compatibility')
                            return True
                        time.sleep(0.25)
                else:
                    detail = (start.stderr or start.stdout or b'').decode('utf-8', errors='replace').strip()
                    logger.warning(f'Failed to start {DARIO_SERVICE_NAME}: {detail[:300]}')

        if not DARIO_AUTOSTART:
            logger.warning('Dario autostart disabled and proxy is not reachable')
            return False
        if not shutil.which('dario'):
            logger.warning('Anthropic provider detected but dario is not installed on PATH')
            return False
        if DARIO_PROCESS is not None and DARIO_PROCESS.poll() is None:
            return dario_endpoint_ready(timeout=1.0)
        parsed = urllib.parse.urlparse(DARIO_LOCAL_BASE_URL or '')
        host = parsed.hostname or '127.0.0.1'
        port = str(parsed.port or 3456)
        cmd = ['dario', 'proxy', '--host', host, '--port', port]
        DARIO_PROCESS = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        for _ in range(40):
            if dario_endpoint_ready(timeout=0.5):
                logger.info(f'Started bundled Dario proxy at {DARIO_LOCAL_BASE_URL}')
                return True
            if DARIO_PROCESS.poll() is not None:
                break
            time.sleep(0.25)
        logger.warning('Dario proxy autostart did not become reachable')
        return False
    except Exception as e:
        logger.warning(f'Failed to ensure Dario proxy readiness: {e}')
        return False



def openai_chat_completions_url(base_url):
    base = (base_url or '').rstrip('/')
    host = (urllib.parse.urlparse(base).hostname or '').lower()
    if 'githubcopilot.com' in host:
        return base + '/chat/completions'
    if base.endswith('/v1') or base.endswith('/api/v1'):
        return base + '/chat/completions'
    return base + '/v1/chat/completions'


def add_openai_compat_headers(hdrs, provider_name=''):
    if (provider_name or '').strip().lower() == 'github-copilot':
        hdrs.setdefault('User-Agent', 'GitHubCopilotChat/0.35.0')
        hdrs.setdefault('Editor-Version', 'vscode/1.107.0')
        hdrs.setdefault('Editor-Plugin-Version', 'copilot-chat/0.35.0')
        hdrs.setdefault('Copilot-Integration-Id', 'vscode-chat')
    return hdrs

def infer_api_type(name, cfg, base_url):
    api_type = cfg.get('api')
    if api_type:
        # Normalize google-generative-ai -> google-generative-language (OpenClaw schema enum)
        if api_type == 'google-generative-ai':
            return 'google-generative-language'
        return api_type
    host = (urllib.parse.urlparse(base_url or '').hostname or '').lower()
    if 'generativelanguage.googleapis.com' in host or name == 'google':
        return 'google-generative-language'
    if 'x.ai' in host or name == 'xai':
        return 'openai-completions'
    return 'openai-completions'


def discover_anthropic_models():
    """Discover available Anthropic models via the Dario proxy's /v1/models endpoint."""
    try:
        url = DARIO_LOCAL_BASE_URL.rstrip('/') + '/v1/models'
        hdrs = {'x-api-key': DARIO_LOCAL_API_KEY, 'anthropic-version': '2023-06-01'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=10) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if models:
            logger.info(f'Discovered {len(models)} Anthropic models via Dario: {models}')
            return models
    except Exception as e:
        logger.debug(f'Dario model discovery failed: {extract_http_error(e)}')
    return None


def discover_google_models(base_url, api_key):
    if not base_url or not api_key:
        return []
    try:
        # Google API requires ?key= query param on /v1beta/models endpoint
        base = base_url.rstrip('/')
        if not base.endswith('/v1beta') and not base.endswith('/v1'):
            base += '/v1beta'
        url = f'{base}/models?key={api_key}'
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=GOOGLE_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = []
        for entry in payload.get('models', []):
            methods = entry.get('supportedGenerationMethods') or []
            if 'generateContent' not in methods and 'streamGenerateContent' not in methods:
                continue
            model_name = entry.get('name', '')
            if model_name.startswith('models/'):
                model_name = model_name.split('/', 1)[1]
            if model_name:
                models.append(model_name)
        if models:
            logger.info(f'Discovered {len(models)} Google models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.warning(f"Google model discovery {base_url}: {extract_http_error(e)}")
        return []


def discover_openai_models(base_url, api_key):
    """Discover available OpenAI models via /v1/models endpoint."""
    if not base_url or not api_key:
        return []
    try:
        url = base_url.rstrip('/') + '/v1/models'
        hdrs = {'Authorization': f'Bearer {api_key}'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        # Filter to chat completion models only
        chat_models = [m for m in models if any(x in m.lower() for x in ['gpt', 'chat', 'o1', 'o3'])]
        if chat_models:
            logger.info(f'Discovered {len(chat_models)} OpenAI chat models via API')
        return dedupe_keep_order(chat_models)
    except Exception as e:
        logger.debug(f"OpenAI model discovery {base_url}: {extract_http_error(e)}")
        return []



def discover_darkbloom_models(base_url, api_key):
    """Discover Darkbloom models via OpenAI-compatible /v1/models.

    Darkbloom model IDs are mostly MLX community names, so do not apply the
    OpenAI-specific GPT/chat/o-series filter used for api.openai.com.
    """
    if not base_url or not api_key:
        return []
    try:
        root = base_url.rstrip('/')
        url = root + '/v1/models'
        hdrs = {'Authorization': f'Bearer {api_key}'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if models:
            logger.info(f'Discovered {len(models)} Darkbloom models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.debug(f"Darkbloom model discovery {base_url}: {extract_http_error(e)}")
        return []

def discover_openrouter_models(base_url, api_key):
    """Discover OpenRouter models, optionally constrained to :free IDs."""
    if not base_url or not api_key:
        return []
    try:
        root = base_url.rstrip('/')
        if root.endswith('/v1'):
            root = root[:-3]
        url = root.rstrip('/') + '/v1/models'
        hdrs = {'Authorization': f'Bearer {api_key}'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if OPENROUTER_FREE_ONLY:
            models = [m for m in models if str(m).endswith(':free')]
        if models:
            suffix = ' free' if OPENROUTER_FREE_ONLY else ''
            logger.info(f'Discovered {len(models)} OpenRouter{suffix} models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.debug(f"OpenRouter model discovery {base_url}: {extract_http_error(e)}")
        return []


def discover_github_copilot_models(base_url, api_key):
    """Discover available GitHub Copilot models via /v1/models endpoint."""
    if not base_url or not api_key:
        return []
    try:
        url = base_url.rstrip('/') + '/v1/models'
        hdrs = {'Authorization': f'Bearer {api_key}'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if models:
            logger.info(f'Discovered {len(models)} GitHub Copilot models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.debug(f"GitHub Copilot model discovery {base_url}: {extract_http_error(e)}")
        return []


def discover_openclaw_gateway_models(base_url, gateway_token=None):
    """Discover available OpenClaw Gateway models via /v1/models endpoint."""
    if not base_url:
        return []
    try:
        url = base_url.rstrip('/') + '/v1/models'
        req = urllib.request.Request(url)
        # Add auth if token available
        if gateway_token:
            req.add_header('Authorization', f'Bearer {gateway_token}')
        with urllib.request.urlopen(req, timeout=5) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if models:
            logger.info(f'Discovered {len(models)} OpenClaw Gateway models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.debug(f"OpenClaw Gateway model discovery {base_url}: {extract_http_error(e)}")
        return []


def discover_xai_models(base_url, api_key):
    """Discover available xAI Grok models via /v1/models endpoint (API-key mode)."""
    if not base_url or not api_key:
        return []
    try:
        url = base_url.rstrip('/') + '/v1/models'
        hdrs = {'Authorization': f'Bearer {api_key}'}
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        models = [m.get('id', '') for m in payload.get('data', []) if m.get('id')]
        if models:
            logger.info(f'Discovered {len(models)} xAI Grok models via API')
        return dedupe_keep_order(models)
    except Exception as e:
        logger.debug(f"xAI model discovery {base_url}: {extract_http_error(e)}")
        return []


def discover_hermes_core_providers():
    """Discover all providers from Hermes Agent core config (~/.hermes/config.yaml and auth.json)."""
    providers = {}
    try:
        config_path = os.path.expanduser("~/.hermes/config.yaml")
        auth_path = os.path.expanduser("~/.hermes/auth.json")
        
        # Read Hermes config
        if os.path.exists(config_path):
            import yaml
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            model_config = config.get('model', {})
            providers['hermes-active'] = {
                'default': model_config.get('default'),
                'provider': model_config.get('provider'),
                'baseUrl': model_config.get('base_url'),
                'source': 'hermes-config'
            }
        
        # Read Hermes auth providers
        if os.path.exists(auth_path):
            with open(auth_path, 'r') as f:
                auth = json.load(f)
            auth_providers = auth.get('providers', {})
            for provider_name, provider_data in auth_providers.items():
                providers[f'hermes-{provider_name}'] = {
                    'authMode': provider_data.get('auth_mode'),
                    'lastRefresh': provider_data.get('last_refresh'),
                    'hasIdToken': bool(provider_data.get('tokens', {}).get('id_token')),
                    'hasAccessToken': bool(provider_data.get('tokens', {}).get('access_token')),
                    'source': 'hermes-auth'
                }
        
        logger.info(f"Discovered {len(providers)} providers from Hermes core")
    except Exception as e:
        logger.debug(f"Hermes core provider discovery failed: {e}")
    return providers


def discover_openclaw_agent_auth_providers():
    """Discover OAuth providers from OpenClaw agent auth-profiles.json."""
    providers = {}
    try:
        # Try main agent first
        auth_path = os.path.expanduser('~/.openclaw/agents/main/agent/auth-profiles.json')
        if not os.path.exists(auth_path):
            # Fallback to checking other agents
            agents_dir = os.path.expanduser('~/.openclaw/agents')
            if os.path.exists(agents_dir):
                for agent in os.listdir(agents_dir):
                    candidate = os.path.join(agents_dir, agent, 'agent', 'auth-profiles.json')
                    if os.path.exists(candidate):
                        auth_path = candidate
                        break
        
        if not os.path.exists(auth_path):
            return providers
        
        with open(auth_path) as f:
            auth = json.load(f)
        
        profiles = auth.get('profiles', {})
        now_ms = time.time() * 1000
        
        for profile_name, profile in profiles.items():
            if profile.get('type') != 'oauth':
                continue
            
            provider_name = profile.get('provider', profile_name.split(':')[0])
            access_token = profile.get('access', '')
            refresh_token = profile.get('refresh', '')
            expires = profile.get('expires', 0)
            
            # Check if expired
            is_valid = expires and (expires - now_ms) > 0
            
            providers[f'openclaw-{profile_name}'] = {
                'provider': provider_name,
                'profile': profile_name,
                'hasAccessToken': bool(access_token),
                'hasRefreshToken': bool(refresh_token),
                'expires': expires,
                'isExpired': not is_valid,
                'source': 'openclaw-agent-auth'
            }
            
            # Also store tokens for gateway to use
            if access_token:
                # Store in a format sage-router can use
                if provider_name not in providers:
                    providers[provider_name] = {
                        'accessToken': access_token,
                        'refreshToken': refresh_token,
                        'expires': expires,
                        'source': 'openclaw-agent-auth',
                        'profile': profile_name
                    }
        
        logger.info(f"Discovered {len(providers)} providers from OpenClaw agent auth")
    except Exception as e:
        logger.debug(f"OpenClaw agent auth discovery failed: {e}")
    
    return providers



def discover_openclaw_cli_providers(timeout_seconds=15):
    """Discover providers using 'openclaw models list --all' CLI with caching."""
    cache_key = 'openclaw_cli_providers'
    cache_ttl = 60  # Cache for 60 seconds
    
    # Check cache
    now = time.time()
    if hasattr(discover_openclaw_cli_providers, '_cache'):
        cached_data, cached_time = discover_openclaw_cli_providers._cache
        if now - cached_time < cache_ttl:
            return cached_data
    
    providers = {}
    try:
        result = subprocess.run(
            ['openclaw', 'models', 'list', '--all'],
            capture_output=True,
            text=True,
            timeout=timeout_seconds
        )
        if result.returncode == 0:
            # Parse the output - assume it's JSON or table format
            output = result.stdout.strip()
            if output.startswith('{'):
                # JSON output
                providers = json.loads(output)
            else:
                # Parse table/text output
                providers = {'raw': output[:5000]}  # Limit size
            logger.info(f"Discovered providers via openclaw CLI")
    except subprocess.TimeoutExpired:
        logger.warning("openclaw CLI timed out - using cached/config data")
    except Exception as e:
        logger.debug(f"openclaw CLI discovery failed: {e}")
    
    # Cache result even if empty (to avoid hammering)
    discover_openclaw_cli_providers._cache = (providers, now)
    return providers


def discover_hermes_cli_providers(timeout_seconds=10):
    """Discover providers using 'hermes' CLI with caching."""
    cache_key = 'hermes_cli_providers'
    cache_ttl = 60  # Cache for 60 seconds
    
    # Check cache
    now = time.time()
    if hasattr(discover_hermes_cli_providers, '_cache'):
        cached_data, cached_time = discover_hermes_cli_providers._cache
        if now - cached_time < cache_ttl:
            return cached_data
    
    providers = {}
    try:
        # Try hermes status --json if available
        result = subprocess.run(
            ['hermes', 'status', '--json'],
            capture_output=True,
            text=True,
            timeout=timeout_seconds
        )
        if result.returncode == 0 and result.stdout.strip():
            try:
                status = json.loads(result.stdout)
                providers['hermes-status'] = status
            except json.JSONDecodeError:
                providers['hermes-status'] = {'raw': result.stdout[:2000]}
        else:
            # Fallback: try hermes model --json
            result2 = subprocess.run(
                ['hermes', 'model', '--json'],
                capture_output=True,
                text=True,
                timeout=timeout_seconds
            )
            if result2.returncode == 0 and result2.stdout.strip():
                try:
                    model_info = json.loads(result2.stdout)
                    providers['hermes-model'] = model_info
                except json.JSONDecodeError:
                    providers['hermes-model'] = {'raw': result2.stdout[:2000]}
        logger.info(f"Discovered providers via Hermes CLI")
    except subprocess.TimeoutExpired:
        logger.warning("Hermes CLI timed out - using cached/config data")
    except Exception as e:
        logger.debug(f"Hermes CLI discovery failed: {e}")
    
    # Cache result even if empty
    discover_hermes_cli_providers._cache = (providers, now)
    return providers


def discover_openclaw_core_providers():
    """Discover all providers and models from OpenClaw core config (~/.openclaw/openclaw.json)."""
    providers = {}
    try:
        config_path = os.path.expanduser("~/.openclaw/openclaw.json")
        if not os.path.exists(config_path):
            return providers
        with open(config_path, 'r') as f:
            config = json.load(f)
        models_config = config.get('models', {})
        providers_config = models_config.get('providers', {})
        for provider_name, provider_cfg in providers_config.items():
            models = []
            raw_models = provider_cfg.get('models', [])
            if isinstance(raw_models, list):
                for m in raw_models:
                    if isinstance(m, dict) and m.get('id'):
                        models.append({
                            'id': m.get('id'),
                            'name': m.get('name', m.get('id')),
                            'reasoning': m.get('reasoning', False),
                            'contextWindow': m.get('contextWindow'),
                            'maxTokens': m.get('maxTokens'),
                            'input': m.get('input', ['text']),
                            'cost': m.get('cost', {})
                        })
            providers[provider_name] = {
                'baseUrl': provider_cfg.get('baseUrl'),
                'api': provider_cfg.get('api', 'openai-completions'),
                'models': models
            }
        logger.info(f"Discovered {len(providers)} providers from OpenClaw core config")
    except Exception as e:
        logger.debug(f"OpenClaw core provider discovery failed: {e}")
    return providers


def fetch_github_providers_manifest(repo_owner, repo_name, path_in_repo="providers.json", timeout_seconds=10):
    """Fetch provider manifest from GitHub repo source code."""
    try:
        url = f"https://raw.githubusercontent.com/{repo_owner}/{repo_name}/main/{path_in_repo}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            return json.loads(resp.read())
    except Exception as e:
        logger.debug(f"GitHub fetch failed for {repo_owner}/{repo_name}: {e}")
        return None


def discover_openclaw_github_manifests():
    """Discover OpenClaw providers from GitHub source manifests."""
    manifests = {}
    
    # Try to fetch from OpenClaw GitHub repo
    manifest = fetch_github_providers_manifest("openclaw", "openclaw", "providers.json")
    if manifest:
        manifests['openclaw-github'] = manifest
    
    # Fallback: known OpenClaw provider patterns from source analysis
    manifests['openclaw-supported'] = {
        "source": "GitHub source analysis",
        "url": "https://github.com/openclaw/openclaw",
        "providers": [
            {"name": "anthropic", "api": "anthropic-messages", "models": ["claude-opus", "claude-sonnet", "claude-haiku"]},
            {"name": "openai", "api": "openai-completions", "models": ["gpt-5.4", "gpt-4o", "gpt-4o-mini"]},
            {"name": "google", "api": "google-generative-ai", "models": ["gemini-3-pro", "gemini-3-flash", "gemini-2.5-pro", "gemini-2.5-flash"]},
            {"name": "haimaker", "api": "openai-completions", "models": ["qwen3-coder", "llama-3.3-70b"]},
            {"name": "minimax", "api": "openai-completions", "models": ["minimax-m2.5", "minimax-m2.7"]},
            {"name": "moonshot", "api": "openai-completions", "models": ["kimi-k2", "kimi-k2.5", "kimi-k2.6"]},
            {"name": "ollama", "api": "ollama", "models": ["dynamic-local"]},
            {"name": "openrouter", "api": "openai-completions", "models": ["200+ models"]},
            {"name": "xiaomi", "api": "openai-completions", "models": ["mimo-v2-pro"]},
            {"name": "zai", "api": "openai-completions", "models": ["glm-5", "glm-5-turbo", "glm-5.1", "glm-5v-turbo"], "subscriptionPlans": {
                "lite": {"price": "$6/month", "quarterly": "$27/quarter"},
                "pro": {"price": "$30/month", "quarterly": "$81/quarter"},
                "max": {"price": "$72/month", "quarterly": "$216/quarter"}
            }, "apiPricing": {
                "glm-5": {"input": "$1.00/1M", "output": "$3.20/1M"},
                "glm-5-turbo": {"input": "$1.20/1M", "output": "$4.00/1M", "cacheRead": "$0.24/1M"}
            }},
            {"name": "alibaba-qwen", "api": "openai-completions", "models": ["qwen-max", "qwen-plus", "qwen-flash", "qwen-turbo", "qwen2.5-72b", "qwen2.5-coder", "qwen3-vl-flash"], "subscriptionPlans": {
                "codingLite": {"price": "$10/month", "requests": "18,000/month"},
                "codingPro": {"price": "$50/month", "requests": "90,000/month"},
                "freeTier": {"tokens": "1M", "valid": "90 days"}
            }, "apiPricing": {
                "qwen-max": {"input": "$1.60/1M", "output": "$6.40/1M"},
                "qwen-plus": {"input": "$0.40/1M", "output": "$1.20/1M"},
                "qwen-flash": {"input": "$0.022-0.173/1M", "output": "$0.216-1.721/1M"},
                "qwen-turbo": {"input": "$0.05/1M", "output": "$0.20-0.40/1M"}
            }},
            {"name": "bedrock", "api": "openai-completions", "models": ["claude", "nova", "llama"]},
            {"name": "deepseek", "api": "openai-completions", "models": ["deepseek-chat", "deepseek-reasoner"]},
            {"name": "github-copilot", "api": "openai-completions", "models": ["gpt-4o-copilot", "claude-sonnet-copilot"]},
            {"name": "groq", "api": "openai-completions", "models": ["llama", "mixtral"]},
            {"name": "together", "api": "openai-completions", "models": ["various open source"]},
            {"name": "fireworks", "api": "openai-completions", "models": ["various open source"]},
            {"name": "huggingface", "api": "openai-completions", "models": ["inference endpoints"]},
            {"name": "perplexity", "api": "openai-completions", "models": ["sonar"]},
            {"name": "mistral", "api": "openai-completions", "models": ["mistral-large", "mistral-medium"]},
            {"name": "nvidia", "api": "openai-completions", "models": ["nemotron"]},
        ],
        "notes": "OpenClaw supports any OpenAI-compatible endpoint. Dynamic model discovery via /v1/models where available."
    }
    
    return manifests


def discover_hermes_github_manifests():
    """Discover Hermes Agent providers from GitHub source manifests."""
    manifests = {}
    
    # Try to fetch from Hermes GitHub repo
    manifest = fetch_github_providers_manifest("NousResearch", "hermes-agent", "providers.json")
    if manifest:
        manifests['hermes-github'] = manifest
    
    # Fallback: known Hermes provider patterns from source analysis
    manifests['hermes-supported'] = {
        "source": "GitHub source analysis",
        "url": "https://github.com/NousResearch/hermes-agent",
        "providers": [
            {"name": "nous-portal", "api": "openai-completions"},
            {"name": "openrouter", "api": "openai-completions", "models": "200+"},
            {"name": "nvidia-nim", "api": "openai-completions", "models": ["nemotron"]},
            {"name": "xiaomi", "api": "openai-completions", "models": ["mimo-v2-pro"]},
            {"name": "zai", "api": "openai-completions", "models": ["glm-5"]},
            {"name": "kimi", "api": "openai-completions", "models": ["kimi-k2"]},
            {"name": "minimax", "api": "openai-completions", "models": ["minimax-m2"]},
            {"name": "huggingface", "api": "openai-completions"},
            {"name": "openai", "api": "openai-completions"},
            {"name": "anthropic", "api": "anthropic-messages"},
            {"name": "google", "api": "google-generative-ai"},
            {"name": "xai", "api": "openai-completions"},
            {"name": "openclaw-gateway", "api": "openclaw-gateway"},
        ],
        "notes": "Hermes supports any OpenAI-compatible endpoint. Uses hermes model command to switch."
    }
    
    return manifests


def configured_model_id(model):
    if isinstance(model, str):
        return model
    if isinstance(model, dict):
        return model.get('id')
    return None


def fetch_text_url(url, timeout=10):
    req = urllib.request.Request(url, headers={'User-Agent': 'sage-router/ollama-cloud-discovery', 'Accept': 'text/html,application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', errors='replace')


def ollama_cloud_catalog_models(force=False):
    """Discover Ollama Cloud catalog models from ollama.com.

    The public cloud search page is currently server-rendered HTML.  We parse
    library links from /search?c=cloud, then parse each library page for cloud
    tag links such as /library/qwen3.5:cloud or /library/gemma4:31b-cloud.
    """
    if not OLLAMA_CLOUD_CATALOG_ENABLED:
        return []
    now = time.time()
    if not force and OLLAMA_CLOUD_CATALOG_CACHE.get('models') and now - OLLAMA_CLOUD_CATALOG_CACHE.get('checked_at', 0) < OLLAMA_CLOUD_CATALOG_TTL_SECONDS:
        return list(OLLAMA_CLOUD_CATALOG_CACHE.get('models') or [])
    try:
        libraries = []
        parsed_catalog_url = urllib.parse.urlparse(OLLAMA_CLOUD_CATALOG_URL)
        base_query = urllib.parse.parse_qs(parsed_catalog_url.query)
        for page in range(1, max(1, OLLAMA_CLOUD_CATALOG_MAX_PAGES) + 1):
            query = {k: v[:] for k, v in base_query.items()}
            if page > 1:
                query['p'] = [str(page)]
            page_url = urllib.parse.urlunparse(parsed_catalog_url._replace(query=urllib.parse.urlencode(query, doseq=True)))
            search_html = fetch_text_url(page_url, timeout=12)
            before_count = len(libraries)
            for match in _re.finditer(r'href=["\']/library/([a-zA-Z0-9_.-]+)["\']', search_html):
                name = match.group(1).strip()
                if name and name not in libraries:
                    libraries.append(name)
                    if len(libraries) >= max(1, OLLAMA_CLOUD_CATALOG_MAX_LIBRARIES):
                        break
            if len(libraries) >= max(1, OLLAMA_CLOUD_CATALOG_MAX_LIBRARIES):
                break
            # Stop after the first page that contributes no new library links.
            if page > 1 and len(libraries) == before_count:
                break
        libraries = libraries[:max(1, OLLAMA_CLOUD_CATALOG_MAX_LIBRARIES)]
        models = []
        for name in libraries:
            try:
                lib_html = fetch_text_url(f'https://ollama.com/library/{urllib.parse.quote(name)}', timeout=12)
            except Exception as e:
                logger.debug(f'Ollama cloud library fetch failed for {name}: {extract_http_error(e)}')
                models.append(f'{name}:cloud')
                continue
            tags = []
            escaped = _re.escape(name)
            for tag in _re.findall(r'href=["\']/library/' + escaped + r':([^"\']+)["\']', lib_html):
                tag = urllib.parse.unquote(tag).strip()
                if tag and ('cloud' in tag.lower()) and tag not in tags:
                    tags.append(tag)
            if not tags and 'cloud' in lib_html.lower():
                tags = ['cloud']
            for tag in tags:
                models.append(f'{name}:{tag}')
        models = dedupe_keep_order(m for m in models if m and is_cloud_ollama_model(m))
        if models:
            OLLAMA_CLOUD_CATALOG_CACHE.update({'checked_at': now, 'models': models})
            logger.info(f'Discovered {len(models)} Ollama Cloud catalog models')
            return models
    except Exception as e:
        logger.warning(f'Ollama cloud catalog discovery failed: {extract_http_error(e)}')
    return list(OLLAMA_CLOUD_CATALOG_CACHE.get('models') or [])


def ollama_cloud_model_meta(model: str):
    model_l = (model or '').lower()
    meta = {
        'reasoning': any(x in model_l for x in ['deepseek', 'qwen', 'glm', 'nemotron', 'minimax', 'kimi', 'gemini', 'gemma']),
        'contextWindow': 256000,
        'maxTokens': 128000,
        'input': ['text'],
        'servable': True,
        'supportsChat': True,
        'supportsStreaming': True,
        'supportsTools': not any(x in model_l for x in NON_CHAT_MODEL_HINTS),
        'supportsJson': True,
        'manifestReason': 'ollama-cloud-catalog',
    }
    if is_multimodal_model(model) or any(x in model_l for x in ['gemini', 'gemma4', 'qwen3.5', 'kimi-k2.5', 'kimi-k2.6', 'ministral', 'devstral']):
        meta['input'] = ['text', 'image']
        meta['supportsVision'] = True
    return meta


def discover_provider_models(name, cfg, base_url, api_key, api_type):
    raw_models = cfg.get('models', [])
    configured = [mid for mid in (configured_model_id(m) for m in raw_models) if mid] if isinstance(raw_models, list) else []
    # For providers with API discovery, merge configured + discovered
    discovered = []
    if api_type in ('google-generative-language', 'google-generative-ai'):
        discovered = discover_google_models(base_url, api_key)
    elif api_type == 'openai-completions':
        # Try OpenAI-style discovery for openai, github-copilot, xai, etc.
        if name == 'openrouter' or 'openrouter.ai' in (base_url or '').lower():
            discovered = discover_openrouter_models(base_url, api_key)
            if OPENROUTER_FREE_ONLY:
                configured = [m for m in configured if str(m).endswith(':free')]
        elif name == 'darkbloom' or 'api.darkbloom.dev' in (base_url or '').lower():
            discovered = discover_darkbloom_models(base_url, api_key)
        elif name == 'xai' or 'x.ai' in (base_url or '').lower():
            discovered = discover_xai_models(base_url, api_key)
        else:
            discovered = discover_openai_models(base_url, api_key)
    elif api_type == 'openclaw-gateway':
        # For OpenClaw Gateway, try to discover models
        discovered = discover_openclaw_gateway_models(base_url, api_key)
    elif api_type == 'ollama':
        discovered = ollama_cloud_catalog_models()
    if discovered:
        # Configured models first (stable), then any discovered models not already listed
        return dedupe_keep_order(configured + discovered)
    if configured:
        return dedupe_keep_order(configured)
    return []


def discover_reasoning_models(cfg):
    reasoning_models = set()
    raw_models = cfg.get('models', [])
    for model in raw_models if isinstance(raw_models, list) else []:
        if not isinstance(model, dict):
            continue
        model_id = model.get('id')
        if model_id and model.get('reasoning'):
            reasoning_models.add(model_id)
    return reasoning_models


def discover_model_meta(cfg):
    meta = {}
    raw_models = cfg.get('models', [])
    for model in raw_models if isinstance(raw_models, list) else []:
        if isinstance(model, str):
            meta[model] = {}
            continue
        if not isinstance(model, dict):
            continue
        model_id = model.get('id')
        if not model_id:
            continue
        entry = {
            'reasoning': bool(model.get('reasoning')),
            'contextWindow': model.get('contextWindow'),
            'maxTokens': model.get('maxTokens'),
            'input': model.get('input') or [],
        }
        for key in (
            'preferred', 'resident', 'family', 'families', 'servable', 'manifestReason',
            'supportsChat', 'supportsJson', 'supportsTools', 'supportsStreaming'
        ):
            if key in model:
                entry[key] = model.get(key)
        meta[model_id] = entry
    return meta


def grok_sso_proxy_health_url(base_url):
    parsed = urllib.parse.urlparse(base_url or '')
    if not parsed.scheme or not parsed.netloc:
        return ''
    path = parsed.path or ''
    if path.endswith('/v1'):
        path = path[:-3]
    elif path.endswith('/v1/'):
        path = path[:-4]
    path = path.rstrip('/')
    return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, (path or '') + '/health', '', '', ''))


def grok_sso_proxy_ready(base_url):
    health_url = grok_sso_proxy_health_url(base_url)
    if not health_url:
        return False, 'missing health URL'
    try:
        req = urllib.request.Request(health_url)
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            payload = json.load(resp)
        if payload.get('ready'):
            return True, None
        reason = payload.get('missingRequiredCookies') or payload.get('notes') or 'proxy not ready'
        return False, reason
    except Exception as e:
        return False, str(e)


def load_router_profile_overlays(existing_providers):
    providers = {}
    try:
        with open(PROVIDER_PROFILES_PATH) as f:
            profiles = json.load(f)
    except FileNotFoundError:
        return providers
    except Exception as e:
        logger.warning(f'Failed to load provider profile overlays: {e}')
        return providers

    requested = [item.strip() for item in os.environ.get('SAGE_ROUTER_PROFILE_OVERLAYS', 'grok-sso,darkbloom').split(',') if item.strip()]
    for name in requested:
        cfg = profiles.get(name)
        if not isinstance(cfg, dict):
            continue
        base_url = resolve_config_value(cfg.get('baseUrl', '') or '')
        api_key = resolve_config_value(cfg.get('apiKey', '') or '')
        api_type = infer_api_type(name, cfg, base_url)
        models = discover_provider_models(name, cfg, base_url, api_key, api_type)
        if not models:
            continue
        if name == 'grok-sso' and not base_url:
            continue
        if name == 'grok-sso':
            ready, reason = grok_sso_proxy_ready(base_url)
            if not ready:
                logger.info(f'Skipped grok-sso overlay because local proxy is not ready: {reason}')
            continue
        reasoning_models = discover_reasoning_models(cfg)
        model_meta = discover_model_meta(cfg)
        providers[name] = Provider(name, api_type, base_url, api_key, models, reasoning_models, model_meta)
        logger.info(f'Loaded router profile overlay provider {name} ({api_type}) with {len(models)} models')
    return providers


def normalize_route_mode(raw):
    value = str(raw or 'balanced').strip().lower()
    aliases = {'deep': 'best', 'thorough': 'best', 'local-strict': 'local-first'}
    value = aliases.get(value, value)
    return value if value in {'fast', 'balanced', 'best', 'local-first', 'realtime'} else 'balanced'


def _content_blocks(payload):
    blocks = []
    if not isinstance(payload, dict):
        return blocks
    for msg in payload.get('messages') or []:
        if isinstance(msg, dict):
            content = msg.get('content')
            if isinstance(content, list):
                blocks.extend([b for b in content if isinstance(b, dict)])
            elif isinstance(content, dict):
                blocks.append(content)
    return blocks


def _payload_text(payload):
    if not isinstance(payload, dict):
        return ''
    return ' '.join(normalize_content((m or {}).get('content', '')) for m in payload.get('messages') or [] if isinstance(m, dict))


def payload_document_signal(payload):
    text = _payload_text(payload).lower()
    blocks = _content_blocks(payload)
    filenames = ' '.join(str(b.get(k, '')) for b in blocks for k in ('filename', 'fileName', 'name', 'path', 'filePath', 'mime_type', 'mimeType', 'media_type', 'mediaType')).lower()
    haystack = f'{text} {filenames}'
    doc_markers = [
        '.pdf', 'application/pdf', '<file ', '<media:', 'media attached', 'external_untrusted_content',
        'document', 'report', 'informe', 'conclusiones', 'findings', 'clinical information',
        'translate', 'summarize', 'extract', 'parse', 'ocr', 'mri', 'rm columna', 'resonancia',
    ]
    return any(marker in haystack for marker in doc_markers) or len(text) > 4000


def payload_vision_signal(payload):
    blocks = _content_blocks(payload)
    for block in blocks:
        btype = str(block.get('type') or '').lower()
        mime = str(block.get('mime_type') or block.get('mimeType') or block.get('media_type') or block.get('mediaType') or '').lower()
        if btype in {'image', 'image_url', 'input_image'} or mime.startswith('image/'):
            return True
    return False


def payload_quality_sensitive_signal(payload):
    if not isinstance(payload, dict):
        return False
    needles = ('discord-public', 'public channel', 'group chat', 'telegram', 'whatsapp', 'production', 'external')
    try:
        haystack = json.dumps({k: payload.get(k) for k in ('metadata', 'channel', 'surface', 'source', 'chat_type', 'messages')}, default=str)[:12000].lower()
    except Exception:
        haystack = str(payload)[:12000].lower()
    return any(n in haystack for n in needles)

def normalize_requirements(payload, thinking_level=ThinkingLevel.MEDIUM):
    req = payload.get('requirements') if isinstance(payload, dict) else None
    if not isinstance(req, dict):
        req = {}
    # Tool definitions are often attached by OpenClaw even for ordinary chat.
    # For auto tool_choice, keep tools as a soft capability preference rather
    # than a hard requirement so plain chat can still route broadly. If the
    # client explicitly requires tools or forces a concrete tool choice, route
    # only to providers/models that support valid tool calls.
    tool_choice = payload.get('tool_choice')
    forced_tool_choice = bool(tool_choice and tool_choice not in ('auto', 'none'))
    has_tools = forced_tool_choice
    # Check for explicit reasoning requirements. Thinking levels are routing
    # hints; they should not make a forced provider unusable unless the client
    # explicitly requires reasoning-capable models.
    raw_reasoning = payload.get('reasoning')
    explicit_reasoning = bool(payload.get('requiresReasoning') or req.get('reasoning'))
    if isinstance(raw_reasoning, dict):
        effort = str(raw_reasoning.get('effort') or raw_reasoning.get('level') or '').lower()
        explicit_reasoning = explicit_reasoning or effort in {'high', 'max', 'deep'}
    elif isinstance(raw_reasoning, str):
        explicit_reasoning = explicit_reasoning or raw_reasoning.lower() in {'high', 'max', 'deep'}
    elif isinstance(raw_reasoning, bool):
        explicit_reasoning = explicit_reasoning or raw_reasoning
    requires_reasoning = explicit_reasoning
    explicit_streaming = bool(req.get('streaming') or payload.get('requiresStreaming'))
    requested_stream = bool(payload.get('stream'))
    document_signal = bool(req.get('document') or payload.get('requiresDocumentParsing') or payload_document_signal(payload))
    vision_signal = bool(req.get('vision') or payload.get('requiresVision') or payload_vision_signal(payload))
    return {
        'reasoning': bool(req.get('reasoning') or payload.get('requiresReasoning') or requires_reasoning),
        'json': bool(req.get('json') or payload.get('requiresJson')),
        'tools': bool(req.get('tools') or payload.get('requiresTools') or has_tools),
        'preferTools': bool(payload.get('tools') and not (req.get('tools') or payload.get('requiresTools') or has_tools)),
        'longContext': bool(req.get('longContext') or payload.get('requiresLongContext') or document_signal),
        'document': document_signal,
        'vision': vision_signal,
        'streaming': bool(explicit_streaming or (requested_stream and not has_tools)),
        'qualitySensitive': bool(req.get('qualitySensitive') or payload.get('requiresQuality') or payload_quality_sensitive_signal(payload)),
        'frontierOrReasoningTools': bool(req.get('frontierOrReasoningTools') or payload.get('requiresFrontierOrReasoningTools')),
        'suppressToolCallContent': bool(req.get('suppressToolCallContent') or payload.get('suppressToolCallContent') or payload.get('suppressIntermediateToolText')),
    }


def is_truthy(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on', 'debug', 'route'}


def normalize_debug_mode(payload):
    if not isinstance(payload, dict):
        return False
    debug = payload.get('debug')
    if isinstance(debug, dict):
        if is_truthy(debug.get('route')) or is_truthy(debug.get('routing')):
            return True
    return is_truthy(debug) or is_truthy(payload.get('routeDebug')) or is_truthy(payload.get('debugRoute'))


def estimate_prompt_tokens(messages):
    text = ' '.join((msg.get('content') or '') for msg in messages or [])
    return max(1, int(len(text) / 4))


def model_context_window(provider, model):
    meta = (provider.model_meta or {}).get(model, {})
    return int(meta.get('contextWindow') or 0)


def model_disabled_reason(provider_name, model):
    if not DISABLED_MODELS:
        return None
    model_s = str(model or '')
    provider_s = str(provider_name or '')
    candidates = {model_s}
    if provider_s:
        candidates.add(f'{provider_s}/{model_s}')
        if provider_s.startswith('nvidia') or provider_s.endswith('-nim') or provider_s == 'nim':
            candidates.add(f'nvidia/{model_s}')
    for disabled in DISABLED_MODELS:
        if disabled in candidates:
            return 'disabled by SAGE_ROUTER_DISABLED_MODELS'
        # Accept provider aliases such as nvidia/openai/gpt-oss-120b for a
        # nvidia-nim provider whose actual model id is openai/gpt-oss-120b.
        if '/' in disabled and disabled.endswith('/' + model_s):
            return 'disabled by SAGE_ROUTER_DISABLED_MODELS'
    return None


def active_temp_model_block(provider_name, model):
    key = f'{provider_name}/{model}'
    blocked = TEMP_MODEL_BLOCKS.get(key)
    if not blocked:
        return None
    if float(blocked.get('until', 0) or 0) <= time.time():
        TEMP_MODEL_BLOCKS.pop(key, None)
        return None
    return blocked


def invalidate_model_health_cache(provider_name, model):
    suffix = f':{provider_name}/{model}'
    for key in list(MODEL_HEALTH_CACHE.keys()):
        if key.endswith(suffix):
            MODEL_HEALTH_CACHE.pop(key, None)



def set_temp_model_block(provider_name, model, seconds, reason):
    if seconds <= 0:
        return
    TEMP_MODEL_BLOCKS[f'{provider_name}/{model}'] = {
        'until': time.time() + seconds,
        'reason': reason,
    }
    invalidate_model_health_cache(provider_name, model)



def clear_temp_model_block(provider_name, model):
    TEMP_MODEL_BLOCKS.pop(f'{provider_name}/{model}', None)
    invalidate_model_health_cache(provider_name, model)



def model_is_servable(provider, model):
    if model_disabled_reason(provider.name, model):
        return False
    if active_temp_model_block(provider.name, model):
        return False
    if local_ollama_cloud_auth_blocked(provider, model):
        return False
    # Hosted Ollama Cloud models are servable through the remote Ollama API even
    # when they are not present in the local /api/tags installed-model list.
    if provider and provider.api_type == 'ollama' and is_cloud_ollama_model(model) and not is_local_ollama_provider(provider):
        return True
    meta = (provider.model_meta or {}).get(model, {})
    return bool(meta.get('servable', True))


def is_chat_capable_model(provider, model):
    model_l = (model or '').lower()
    if provider.api_type == 'ollama':
        # 1) Static name-pattern check (fast, catches most cases)
        if any(hint in model_l for hint in NON_CHAT_MODEL_HINTS):
            return False
        # 2) Dynamic family check from discovered metadata
        meta = (provider.model_meta or {}).get(model, {})
        family = (meta.get('family') or '').lower()
        families = [f.lower() for f in (meta.get('families') or []) if f]
        all_families = set(families) | {family} - {''}
        if all_families & NON_CHAT_OLLAMA_FAMILIES:
            return False
    return True


def provider_supports_reasoning(provider, model):
    if provider.api_type == 'ollama':
        return False
    if provider.api_type in ('openclaw-gateway', 'openai-codex-responses'):
        return True
    if provider.api_type == 'anthropic-messages':
        return model.startswith('claude-') or model.startswith('claude')
    reasoning_models = provider.reasoning_models or set()
    return model in reasoning_models


def is_cloud_ollama_model(model: str):
    model_l = (model or '').strip().lower()
    if ':' not in model_l:
        return False
    tag = model_l.rsplit(':', 1)[1]
    return tag == 'cloud' or tag.endswith('-cloud') or tag.endswith('_cloud')


def is_local_ollama_provider(provider):
    if not provider or provider.api_type != 'ollama':
        return False
    host = (urllib.parse.urlparse(provider.base_url or '').hostname or '').lower()
    return host in {'127.0.0.1', 'localhost', '::1'}


def is_local_cloud_ollama_model(provider, model: str):
    return is_local_ollama_provider(provider) and is_cloud_ollama_model(model)


def local_ollama_cloud_auth_blocked(provider, model: str):
    if not is_local_cloud_ollama_model(provider, model):
        return False
    key = provider.name
    until = float(LOCAL_OLLAMA_CLOUD_AUTH_BLOCKS.get(key, 0) or 0)
    if until <= time.time():
        LOCAL_OLLAMA_CLOUD_AUTH_BLOCKS.pop(key, None)
        return False
    return True


def set_local_ollama_cloud_auth_block(provider_name, seconds=300):
    if not provider_name:
        return
    LOCAL_OLLAMA_CLOUD_AUTH_BLOCKS[provider_name] = time.time() + max(30, int(seconds))
    MODEL_HEALTH_CACHE.clear()


def probe_local_ollama_cloud_auth(provider, model: str):
    if not is_local_cloud_ollama_model(provider, model) or local_ollama_cloud_auth_blocked(provider, model):
        return
    if os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_AUTH_PREFLIGHT', '1').strip().lower() not in {'1', 'true', 'yes', 'on'}:
        return
    url = provider.base_url.rstrip('/') + '/api/chat'
    payload = {'model': model, 'messages': [{'role': 'user', 'content': 'ping'}], 'stream': False, 'options': {'num_predict': 1}}
    headers = {'Content-Type': 'application/json'}
    if provider.api_key:
        headers['Authorization'] = f'Bearer {provider.api_key}'
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers)
        with urllib.request.urlopen(req, timeout=min(8, OLLAMA_TIMEOUT_SECONDS)) as resp:
            resp.read(256)
    except Exception as e:
        err = extract_http_error(e)
        if 'HTTP 401' in err:
            set_local_ollama_cloud_auth_block(provider.name, seconds=int(os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_AUTH_COOLDOWN_SECONDS', '3600')))
            logger.warning(f'Ollama Cloud auth preflight failed for local provider {provider.name}; suppressing local :cloud routing temporarily')

# Detect if a model supports vision/multimodal based on name patterns
VISION_MODEL_PATTERNS = ['vl', 'vision', 'qwen-vl', 'qwen_vl', 'llava', 'bakllava', 'moondream', 'minicpm-v', 'llama-vision', 'glm-4v', 'gpt-4o', 'gpt-4-turbo', 'claude-3-opus', 'claude-3-sonnet', 'claude-3.5', 'gemini-pro-vision', 'gemini-1.5', 'gpt-5.4', 'gpt-5.5']
OCR_MODEL_PATTERNS = ['ocr', 'paddleocr', 'trocr']

def is_multimodal_model(model: str) -> bool:
    model_l = (model or '').strip().lower()
    # Check exact matches first
    for pattern in VISION_MODEL_PATTERNS:
        pattern_l = pattern.lower()
        if model_l == pattern_l or model_l.startswith(pattern_l + '/') or f'-{pattern_l}' in model_l or f'_{pattern_l}' in model_l:
            return True
    # Check suffix patterns (e.g., model-name-vl)
    if any(model_l.endswith(suffix) for suffix in (':vl', '-vl', '_vl', '-vision', ':vision')):
        return True
    return False



def looks_like_visible_tool_call(text: str) -> bool:
    """Detect tool-call-shaped text that a non-tool model leaked visibly.

    OpenClaw expects actual OpenAI-compatible tool_calls, not prose/code blocks
    containing `tool_code` or `message(action=...)`. When a provider returns this
    while tools were offered, treat the attempt as failed so routing can fall
    through to a model with real tool-call support instead of posting the leak.
    Keep this intentionally narrow to avoid rejecting legitimate discussion of
    code samples.
    """
    raw = str(text or '').strip()
    if not raw:
        return False
    lowered = raw.lower()
    if 'tool_code' in lowered or '<tool_call' in lowered or '</tool_call>' in lowered:
        return True
    if re.search(r'(?m)^\s*(?:functions\.)?message\s*\(\s*action\s*=', raw):
        return True
    if re.search(r'(?m)^\s*(?:functions\.)?(?:exec|browser|web_fetch|web_search|read|pdf)\s*\(', raw):
        return True
    if re.search(r'(?m)^\s*```(?:tool_code|tool|json)?\s*\n\s*\{\s*["\'](?:tool|name)["\']', raw, re.IGNORECASE):
        return True
    return False


def reject_visible_tool_call_leak(payload, text: str, tool_calls) -> str:
    if not (payload or {}).get('tools') or tool_calls:
        return ''
    if looks_like_visible_tool_call(text):
        return 'provider leaked tool call as visible text instead of structured tool_calls'
    return ''

def sanitize_visible_output(text: str):
    raw = text or ''
    if not raw:
        return ''
    cleaned = _re.sub(r'<think>.*?</think>\s*', '', raw, flags=_re.IGNORECASE | _re.DOTALL)
    if cleaned == raw and '</think>' in raw.lower():
        cleaned = _re.split(r'</think>', raw, flags=_re.IGNORECASE)[-1]
    cleaned = _re.sub(r'</?think>', '', cleaned, flags=_re.IGNORECASE)
    cleaned = cleaned.strip()
    return cleaned or raw.strip()


def is_ocr_model(model: str) -> bool:
    model_l = (model or '').strip().lower()
    for pattern in OCR_MODEL_PATTERNS:
        if pattern in model_l:
            return True
    return False

def normalize_tool_calls(tool_calls):
    normalized = []
    logger.debug(f"normalize_tool_calls input: {tool_calls}")
    for idx, tool_call in enumerate(tool_calls or []):
        if not isinstance(tool_call, dict):
            logger.debug(f"Skipping non-dict tool_call: {tool_call}")
            continue
        function = tool_call.get('function') if isinstance(tool_call.get('function'), dict) else {}
        name = function.get('name') or tool_call.get('name') or f'tool_{idx + 1}'
        arguments = function.get('arguments') if 'arguments' in function else tool_call.get('arguments', {})
        # Ollama expects arguments as an object, not a JSON string
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except Exception as e:
                logger.debug(f"Failed to parse arguments JSON: {e}")
                arguments = {}
        normalized.append({
            'id': tool_call.get('id') or f'call_{uuid.uuid4().hex[:24]}',
            'type': 'function',
            'function': {
                'name': name,
                'arguments': arguments if isinstance(arguments, dict) else {},
            },
        })
        logger.debug(f"Normalized tool call: name={name}, arguments={arguments}")
    logger.debug(f"normalize_tool_calls output: {normalized}")
    return normalized


def openai_tool_calls(tool_calls):
    """Return OpenAI-compatible tool_calls with function.arguments as JSON strings.

    Internally Sage Router normalizes tool arguments as dicts because Ollama
    expects objects. OpenAI-compatible clients, including OpenClaw tool
    validators, expect function.arguments to be a JSON object string. Returning
    raw arrays/objects can cause empty/invalid tool invocation payloads.
    """
    converted = []
    for tool_call in normalize_tool_calls(tool_calls):
        function = tool_call.get('function') or {}
        arguments = function.get('arguments')
        if isinstance(arguments, str):
            try:
                parsed = json.loads(arguments) if arguments else {}
            except Exception:
                parsed = {}
        else:
            parsed = arguments if isinstance(arguments, dict) else {}
        converted.append({
            'id': tool_call.get('id') or f'call_{uuid.uuid4().hex[:24]}',
            'type': 'function',
            'function': {
                'name': function.get('name') or 'tool',
                'arguments': json.dumps(parsed, separators=(',', ':')),
            },
        })
    return converted


def build_router_metadata(provider_name, model, request_id=''):
    return {
        'provider': provider_name,
        'model': model,
        'request_id': request_id,
    }


def maybe_prefix_debug_text(content, metadata, debug_mode=False, allow_prefix=True):
    text = sanitize_visible_output(content or '')
    if debug_mode and allow_prefix and text:
        text = f"[sage-router {metadata.get('provider')}/{metadata.get('model')}]\n{text}"
    return text


def build_openai_completion(provider_name, model, request_id, content='', tool_calls=None, finish_reason=None, usage=None, debug_mode=False, allow_debug_prefix=True, suppress_tool_call_content=False):
    metadata = build_router_metadata(provider_name, model, request_id)
    normalized_tool_calls = openai_tool_calls(tool_calls)
    if suppress_tool_call_content and normalized_tool_calls:
        content = ''
    content_text = maybe_prefix_debug_text(content, metadata, debug_mode=debug_mode, allow_prefix=allow_debug_prefix and not normalized_tool_calls)
    if SHOW_MODEL_PREFIX and content_text and not normalized_tool_calls:
        content_text = '[' + provider_name + '/' + model + '] ' + content_text
    message = {'role': 'assistant', 'content': content_text}
    if normalized_tool_calls:
        message['tool_calls'] = normalized_tool_calls
    resolved_finish_reason = finish_reason or ('tool_calls' if normalized_tool_calls else 'stop')
    response = {
        'id': f'chatcmpl-{int(time.time())}',
        'object': 'chat.completion',
        'created': int(time.time()),
        'model': f'{provider_name}/{model}',
        'choices': [{
            'index': 0,
            'message': message,
            'finish_reason': resolved_finish_reason,
        }],
        'usage': usage or {'prompt_tokens': 0, 'completion_tokens': 0},
    }
    if debug_mode:
        response['sage_router'] = metadata
    return response



def openai_completion_has_visible_output(result):
    if not isinstance(result, dict):
        return False
    choices = result.get('choices') or []
    if not choices:
        return False
    message = (choices[0] or {}).get('message') or {}
    content = message.get('content')
    has_text = bool(str(content or '').strip())
    has_tools = bool(message.get('tool_calls'))
    return has_text or has_tools


def build_openai_proxy_payload(payload, model, stream=False, supports_reasoning=False, thinking=ThinkingLevel.MEDIUM):
    allowed_keys = [
        'messages', 'tools', 'tool_choice', 'parallel_tool_calls', 'response_format',
        'temperature', 'top_p', 'frequency_penalty', 'presence_penalty',
        'stop', 'n', 'user', 'seed', 'stream_options', 'max_tokens',
        'max_completion_tokens', 'modalities', 'audio', 'metadata'
    ]
    proxied = {'model': model, 'stream': bool(stream)}
    for key in allowed_keys:
        if key in payload:
            proxied[key] = payload.get(key)
    if supports_reasoning:
        proxied['reasoning'] = payload.get('reasoning') or {'effort': thinking.value}
    return proxied


def openai_messages_to_ollama(messages):
    converted = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        item = {
            'role': msg.get('role', 'user'),
            'content': normalize_content(msg.get('content', '')),
        }
        tool_calls = normalize_tool_calls(msg.get('tool_calls'))
        if tool_calls:
            item['tool_calls'] = tool_calls
        if msg.get('tool_call_id'):
            item['tool_call_id'] = msg.get('tool_call_id')
        converted.append(item)
    return converted


def build_ollama_payload(model, payload, thinking=ThinkingLevel.MEDIUM, stream=False):
    ollama_payload = {
        'model': model,
        'messages': openai_messages_to_ollama(payload.get('messages', [])),
        'stream': bool(stream),
    }
    if payload.get('tools'):
        ollama_payload['tools'] = payload.get('tools')
    if thinking == ThinkingLevel.LOW:
        ollama_payload['options'] = {'num_predict': 1024}
    elif thinking == ThinkingLevel.HIGH:
        ollama_payload['options'] = {'num_predict': 4096}
    return ollama_payload


def openai_tools_to_anthropic(tools):
    converted = []
    for tool in tools or []:
        if not isinstance(tool, dict) or tool.get('type') != 'function':
            continue
        fn = tool.get('function') or {}
        converted.append({
            'name': fn.get('name'),
            'description': fn.get('description', ''),
            'input_schema': fn.get('parameters') or {'type': 'object', 'properties': {}},
        })
    return [tool for tool in converted if tool.get('name')]


def openai_messages_to_anthropic(messages):
    system_text = []
    converted = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        role = msg.get('role', 'user')
        content = normalize_content(msg.get('content', ''))
        if role == 'system':
            if content:
                system_text.append(content)
            continue
        if role == 'tool':
            block = {'type': 'tool_result', 'tool_use_id': msg.get('tool_call_id') or f'toolu_{uuid.uuid4().hex[:16]}', 'content': content}
            converted.append({'role': 'user', 'content': [block]})
            continue
        blocks = []
        if content:
            blocks.append({'type': 'text', 'text': content})
        for tool_call in normalize_tool_calls(msg.get('tool_calls')):
            raw_arguments = tool_call['function'].get('arguments')
            if isinstance(raw_arguments, dict):
                tool_input = raw_arguments
            else:
                try:
                    tool_input = json.loads(raw_arguments) if raw_arguments else {}
                except Exception:
                    tool_input = {'raw_arguments': raw_arguments}
            blocks.append({'type': 'tool_use', 'id': tool_call['id'], 'name': tool_call['function']['name'], 'input': tool_input})
        converted.append({'role': 'assistant' if role == 'assistant' else 'user', 'content': blocks or [{'type': 'text', 'text': ''}]})
    return '\n'.join(system_text).strip(), converted or [{'role': 'user', 'content': [{'type': 'text', 'text': 'Hello'}]}]


def parse_anthropic_response(body):
    content_blocks = body.get('content', []) or []
    text_parts = []
    tool_calls = []
    for block in content_blocks:
        if not isinstance(block, dict):
            continue
        if block.get('type') == 'text':
            text_parts.append(str(block.get('text', '')))
        elif block.get('type') == 'tool_use':
            tool_calls.append({
                'id': block.get('id') or f'call_{uuid.uuid4().hex[:24]}',
                'type': 'function',
                'function': {
                    'name': block.get('name') or 'tool',
                    'arguments': json.dumps(block.get('input') or {}, separators=(',', ':')),
                },
            })
    return sanitize_visible_output(''.join(text_parts)), normalize_tool_calls(tool_calls), body.get('stop_reason'), {
        'prompt_tokens': ((body.get('usage') or {}).get('input_tokens') or 0),
        'completion_tokens': ((body.get('usage') or {}).get('output_tokens') or 0),
    }



def ollama_model_default_tools_support(model: str):
    model_l = (model or '').strip().lower()
    if not model_l or any(hint in model_l for hint in OLLAMA_NON_TOOL_MODEL_HINTS):
        return False
    # Ollama Cloud exposes native tool calling for many hosted chat families.
    # Local Ollama support is model-template dependent, so keep the default
    # conservative unless the model is a known tool-capable family.
    return any(hint in model_l for hint in OLLAMA_TOOL_MODEL_HINTS)


def is_nvidia_provider(provider):
    name_l = (provider.name or '').strip().lower()
    host_l = (urllib.parse.urlparse(provider.base_url or '').hostname or '').lower()
    return any(hint in name_l for hint in ('nvidia', 'nim', 'ngc')) or 'nvidia.com' in host_l


def nvidia_model_default_tools_support(model: str):
    model_l = (model or '').strip().lower()
    if not model_l or any(hint in model_l for hint in NVIDIA_NON_TOOL_MODEL_HINTS):
        return False
    # Observed NVIDIA NIM chat models can leak OpenAI tool schemas as visible
    # assistant text when tools are present, which is especially bad in public
    # Discord channels.  Only allow NIM tool calling when a model is explicitly
    # marked with tools=true in model_meta; the default must be conservative.
    return False

def provider_default_tools_support(provider):
    if provider.api_type == 'anthropic-messages':
        return True
    if provider.api_type == 'ollama':
        return None
    if provider.api_type == 'openai-codex-responses':
        return True
    if provider.api_type == 'openclaw-gateway':
        return True
    if provider.api_type == 'openai-completions' and is_nvidia_provider(provider):
        return None
    if provider.api_type == 'openai-completions' and provider.name in {'openai', 'openai-codex', 'github-copilot'}:
        return True
    return False


def model_capabilities(provider, model):
    meta = (provider.model_meta or {}).get(model, {})
    default_chat = is_chat_capable_model(provider, model)
    default_json = provider.api_type in {'openai-completions', 'openclaw-gateway', 'anthropic-messages', 'google-generative-language', 'openai-codex-responses'}
    provider_tools_default = provider_default_tools_support(provider)
    if provider_tools_default is None and provider.api_type == 'ollama':
        default_tools = ollama_model_default_tools_support(model)
    elif provider_tools_default is None and is_nvidia_provider(provider):
        default_tools = nvidia_model_default_tools_support(model)
    else:
        default_tools = provider_tools_default
    default_streaming = provider.api_type in {'openai-completions', 'ollama', 'google-generative-language', 'openai-codex-responses'}
    return {
        'chat': bool(meta.get('supportsChat', default_chat)),
        'servable': model_is_servable(provider, model),
        'preferred': bool(meta.get('preferred', False)),
        'resident': bool(meta.get('resident', False)),
        'reasoning': provider_supports_reasoning(provider, model),
        'json': bool(meta.get('supportsJson', default_json)),
        'tools': bool(meta.get('supportsTools', default_tools)),
        'streaming': bool(meta.get('supportsStreaming', default_streaming)),
        'vision': bool(meta.get('supportsVision') or ('image' in (meta.get('input') or [])) or is_multimodal_model(model)),
        # Document parsing here means extracted-text document work. Native binary PDF ingestion
        # is still handled by OpenClaw/pdf tooling before it reaches this router.
        'document': bool(meta.get('supportsDocument') or meta.get('supportsFiles') or default_chat),
        'ocr': bool(meta.get('supportsOcr') or is_ocr_model(model)),
        'longContext': model_context_window(provider, model),
        'manifestReason': meta.get('manifestReason'),
    }


def model_meets_requirements(provider, model, requirements, estimated_tokens):
    caps = model_capabilities(provider, model)
    if not caps['servable']:
        return False, 'not servable on host'
    allow_providers = requirements.get('allowProviders') or []
    deny_providers = requirements.get('denyProviders') or []
    allow_models = requirements.get('allowModels') or []
    deny_models = requirements.get('denyModels') or []
    if allow_providers and provider.name not in allow_providers:
        return False, 'provider not allowed by profile'
    if deny_providers and provider.name in deny_providers:
        return False, 'provider denied by profile'
    model_key = f'{provider.name}/{model}'
    if allow_models and not (_match_any_pattern(model, allow_models) or _match_any_pattern(model_key, allow_models)):
        return False, 'model not allowed by profile'
    if deny_models and (_match_any_pattern(model, deny_models) or _match_any_pattern(model_key, deny_models)):
        return False, 'model denied by profile'
    if requirements.get('frontierLargeOnly') and not model_is_frontier_large(model):
        return False, 'requires frontier large model'
    min_params = requirements.get('minParamsB')
    if min_params is not None:
        try:
            if estimate_model_params_b(model) < float(min_params):
                return False, f'requires >= {min_params}B params'
        except Exception:
            return False, 'invalid minParamsB profile requirement'
    if requirements.get('reasoning') and not caps['reasoning']:
        return False, 'requires reasoning'
    if requirements.get('longContext'):
        ctx = caps['longContext']
        if ctx and ctx < max(64000, estimated_tokens * 2):
            return False, f'context window too small ({ctx})'
    if requirements.get('json') and not caps['json']:
        return False, 'json unsupported'
    if requirements.get('tools') and not caps['tools']:
        return False, 'tools unsupported'
    if requirements.get('frontierOrReasoningTools') and not (model_is_frontier_large(model) or (caps['reasoning'] and caps['tools'])):
        return False, 'requires frontier large model or reasoning+tools'
    if requirements.get('vision') and not caps['vision']:
        return False, 'vision unsupported'
    if requirements.get('document') and not caps['document']:
        return False, 'document parsing unsupported'
    if requirements.get('streaming') and not caps['streaming']:
        return False, 'streaming unsupported'
    return True, None

def load_openclaw_providers():
    providers = {}
    try:
        with open(OPENCLAW_CONFIG) as f:
            config = json.load(f)
        for name, cfg in config.get('models', {}).get('providers', {}).items():
            base_url = resolve_config_value(cfg.get('baseUrl', '') or '')
            if is_self_provider(name, base_url):
                continue
            if name in DISABLED_PROVIDERS:
                logger.info(f'Skipping disabled provider {name} during discovery')
                continue
            api_key = resolve_config_value(cfg.get('apiKey', '') or '')
            api_type = infer_api_type(name, cfg, base_url)
            models = discover_provider_models(name, cfg, base_url, api_key, api_type)
            reasoning_models = discover_reasoning_models(cfg)
            model_meta = discover_model_meta(cfg)
            if api_type == 'ollama':
                cloud_models = [m for m in (models or []) if is_cloud_ollama_model(m)]
                if cloud_models:
                    model_meta = {**{m: ollama_cloud_model_meta(m) for m in cloud_models}, **(model_meta or {})}
                    reasoning_models = set(reasoning_models or set()) | {m for m in cloud_models if model_meta.get(m, {}).get('reasoning')}

            if should_route_anthropic_to_dario(name, api_type, base_url):
                ensure_dario_proxy_ready()
                merge_provider(providers, Provider(
                    DARIO_PROVIDER_NAME,
                    'anthropic-messages',
                    DARIO_LOCAL_BASE_URL,
                    DARIO_LOCAL_API_KEY,
                    dedupe_keep_order(models or DEFAULT_ANTHROPIC_MODELS),
                    set(models or DEFAULT_ANTHROPIC_MODELS),
                    {m: {'reasoning': True, 'contextWindow': 1000000, 'maxTokens': 64000, 'input': ['text']} for m in dedupe_keep_order(models or DEFAULT_ANTHROPIC_MODELS)},
                ))
                logger.info(f'Normalized provider {name} -> {DARIO_PROVIDER_NAME} via local Dario proxy')
                continue

            # Inject OAuth token for openai-codex-responses from OpenClaw agent auth
            if name == 'openai-codex' and api_type == 'openai-codex-responses' and not api_key:
                import time
                auth_path = os.path.expanduser('~/.openclaw/agents/main/agent/auth-profiles.json')
                try:
                    with open(auth_path) as af:
                        auth = json.load(af)
                    now_ms = time.time() * 1000
                    for pname, prof in auth.get('profiles', {}).items():
                        if prof.get('provider') == 'openai-codex' and prof.get('type') == 'oauth':
                            if not prof.get('expires') or prof.get('expires', 0) > now_ms:
                                api_key = prof.get('access', '')
                                if api_key:
                                    logger.info(f'Injected OAuth token for openai-codex from {pname}')
                                    break
                except Exception:
                    pass
            
            # Add multimodal metadata for GPT-5.4/5.5 which support vision
            multimodal_models = {'gpt-5.5', 'gpt-5.4', 'gpt-5.4-pro', 'gpt-5.4-mini'}
            extra_meta = {m: {'input': ['text', 'image'], 'supportsVision': True} for m in multimodal_models if m in (models or [])}
            if extra_meta:
                model_meta = {**(model_meta or {}), **extra_meta}
            
            merge_provider(providers, Provider(
                name,
                api_type,
                base_url,
                api_key,
                models,
                reasoning_models,
                model_meta,
            ))

        auth_profiles = config.get('auth', {}).get('profiles', {})
        agent_defaults = config.get('agents', {}).get('defaults', {})        
        # Auto-discover gateway-backed providers from auth profiles
        # For each auth profile that matches a known gateway provider, create a provider
        for profile_name, profile in auth_profiles.items():
            if not isinstance(profile, dict):
                continue
            provider_name = profile.get('provider', profile_name.split(':')[0])
            if provider_name in DISABLED_PROVIDERS:
                logger.info(f'Skipping disabled gateway provider {provider_name} during discovery')
                continue
            # Skip if already configured as a regular provider (e.g. ollama, anthropic via Dario)
            if provider_name in providers and provider_name not in GATEWAY_PROVIDER_PROFILES:
                continue
            # Skip ollama - it's always direct, not gateway-backed
            if provider_name == 'ollama':
                continue
            gw_spec = GATEWAY_PROVIDER_PROFILES.get(provider_name)
            if not gw_spec:
                continue
            api_type, default_models, default_meta = gw_spec
            # Don't add if already exists (e.g. anthropic already routed via Dario)
            if provider_name in providers:
                continue
            # Determine models and base URL based on provider type
            gw_models = list(default_models)
            if api_type == 'anthropic-messages':
                # Anthropic - route via Dario
                ensure_dario_proxy_ready()
                gw_models = discover_anthropic_models() or default_models
                merge_provider(providers, Provider(
                    provider_name,
                    'anthropic-messages',
                    DARIO_LOCAL_BASE_URL,
                    DARIO_LOCAL_API_KEY,
                    dedupe_keep_order(gw_models),
                    set(gw_models),
                    {m: dict(default_meta) for m in gw_models},
                ))
                logger.info(f'Auto-created gateway provider {provider_name} (anthropic-messages) with {len(gw_models)} models via Dario')
            elif api_type == 'google-generative-language':
                # Google - direct API if key available, otherwise gateway
                api_key = resolve_config_value(config.get('auth', {}).get('profiles', {}).get(f'{provider_name}:default', {}).get('apiKey', ''))
                if not api_key:
                    # Use gateway as fallback
                    merge_provider(providers, Provider(
                        provider_name,
                        'openclaw-gateway',
                        OPENCLAW_GATEWAY_BASE_URL,
                        '',
                        dedupe_keep_order(gw_models),
                        set(gw_models),
                        {m: dict(default_meta) for m in gw_models},
                    ))
                    logger.info(f'Auto-created gateway provider {provider_name} (google via gateway) with {len(gw_models)} models')
                # If key exists, it would have been loaded as a regular provider
            else:
                # Other providers (xai, zai, openai) - route via gateway
                merge_provider(providers, Provider(
                    provider_name,
                    'openclaw-gateway',
                    OPENCLAW_GATEWAY_BASE_URL,
                    '',
                    dedupe_keep_order(gw_models),
                    set(gw_models),
                    {m: dict(default_meta) for m in gw_models},
                ))
                logger.info(f'Auto-created gateway provider {provider_name} ({api_type}) with {len(gw_models)} models via gateway')

        for name, provider in load_router_profile_overlays(providers).items():
            merge_provider(providers, provider)

        logger.info(f"Loaded {len(providers)} configured providers: {list(providers.keys())}")
    except Exception as e:
        logger.error(f"Config load failed: {e}")
        providers['ollama'] = Provider('ollama', 'ollama', 'http://127.0.0.1:11434', '', ['qwen3.5:cloud', 'kimi-k2.5:cloud'], set(), {'qwen3.5:cloud': {'reasoning': False, 'contextWindow': 256000, 'maxTokens': 128000, 'input': ['text']}, 'kimi-k2.5:cloud': {'reasoning': False, 'contextWindow': 256000, 'maxTokens': 128000, 'input': ['text']}})
        # Even without a local OpenClaw config (e.g. public Cloud Run demo),
        # explicitly requested profile overlays should still be able to replace
        # the fallback local Ollama provider.
        for name, provider in load_router_profile_overlays(providers).items():
            merge_provider(providers, provider)
    return providers

PROVIDERS = load_openclaw_providers()


def normalize_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                block_type = block.get('type')
                if block_type == 'text':
                    parts.append(str(block.get('text', '')))
                elif block_type in {'image', 'image_url', 'input_image'}:
                    parts.append('[image attached]')
                elif block_type in {'document', 'file', 'input_file'}:
                    name = block.get('filename') or block.get('fileName') or block.get('name') or block.get('path') or block.get('filePath') or 'file'
                    mime = block.get('mime_type') or block.get('mimeType') or block.get('media_type') or block.get('mediaType') or ''
                    parts.append(f'[document attached: {name} {mime}]')
                elif 'content' in block:
                    parts.append(normalize_content(block.get('content')))
        return ' '.join(part for part in parts if part).strip()
    if isinstance(content, dict):
        if 'text' in content:
            return str(content.get('text', ''))
        if 'content' in content:
            return normalize_content(content.get('content'))
    return '' if content is None else str(content)


def normalize_messages(messages):
    normalized = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        normalized.append({
            'role': msg.get('role', 'user'),
            'content': normalize_content(msg.get('content', '')),
        })
    return normalized


def _safe_document_path(path_value):
    path = os.path.abspath(os.path.expanduser(str(path_value or '').strip()))
    allowed_roots = [
        os.path.abspath(os.path.expanduser('~/.openclaw/media/inbound')),
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')),
    ]
    if not any(path == root or path.startswith(root + os.sep) for root in allowed_roots):
        return ''
    if not os.path.isfile(path):
        return ''
    return path


def extract_document_paths_from_content(content):
    paths = []
    if isinstance(content, list):
        for block in content:
            if not isinstance(block, dict):
                continue
            for key in ('path', 'filePath', 'filename', 'fileName'):
                candidate = block.get(key)
                safe = _safe_document_path(candidate) if candidate else ''
                if safe:
                    paths.append(safe)
    text = normalize_content(content)
    for match in re.findall(r'(/[^\s\]\)\}<>"\']+\.(?:pdf|txt|md))', text, flags=re.IGNORECASE):
        safe = _safe_document_path(match)
        if safe:
            paths.append(safe)
    return dedupe_keep_order(paths)


def extract_document_text(path, max_chars=30000):
    try:
        lower = path.lower()
        if lower.endswith('.pdf') and shutil.which('pdftotext'):
            proc = subprocess.run(['pdftotext', '-layout', '-nopgbrk', path, '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
            if proc.returncode == 0 and proc.stdout.strip():
                return proc.stdout[:max_chars]
            logger.warning(f'pdftotext failed for {path}: {proc.stderr[:180]}')
        if lower.endswith(('.txt', '.md')):
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read(max_chars)
    except Exception as e:
        logger.warning(f'document extraction failed for {path}: {e}')
    return ''


def enrich_document_messages(messages, max_chars_per_doc=30000):
    enriched = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        base = normalize_content(msg.get('content', ''))
        additions = []
        for path in extract_document_paths_from_content(msg.get('content', '')):
            text = extract_document_text(path, max_chars=max_chars_per_doc)
            if text.strip():
                additions.append(f'\n\n[Extracted text from {os.path.basename(path)}]\n{text.strip()}')
            else:
                additions.append(f'\n\n[Document attached but text extraction failed: {os.path.basename(path)}]')
        enriched.append({'role': msg.get('role', 'user'), 'content': (base + ''.join(additions)).strip()})
    return enriched


def load_latency_stats():
    try:
        with open(LATENCY_STATS_PATH) as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except FileNotFoundError:
        pass
    except Exception as e:
        logger.warning(f'Latency stats load failed: {e}')
    return {'version': 1, 'intents': {}}


LATENCY_STATS = load_latency_stats()


def save_latency_stats():
    try:
        os.makedirs(os.path.dirname(LATENCY_STATS_PATH), exist_ok=True)
        tmp_path = LATENCY_STATS_PATH + '.tmp'
        with open(tmp_path, 'w') as f:
            json.dump(LATENCY_STATS, f, indent=2, sort_keys=True)
        os.replace(tmp_path, LATENCY_STATS_PATH)
    except Exception as e:
        logger.warning(f'Latency stats save failed: {e}')


def sanitize_route_event(event):
    """Keep analytics useful while explicitly excluding prompt/user content and credentials."""
    allowed = {
        'request_id', 'ts', 'status', 'intent', 'complexity', 'thinking', 'routeMode',
        'estimatedTokens', 'json', 'stream', 'requirements', 'selected', 'attempts',
        'totalElapsedMs', 'chain', 'error'
    }
    clean = {k: v for k, v in dict(event or {}).items() if k in allowed}
    clean.setdefault('ts', int(time.time()))
    return clean


def append_route_event(event):
    """Persist one structured routing event locally, then mirror durable telemetry async."""
    try:
        os.makedirs(os.path.dirname(ROUTE_EVENTS_PATH), exist_ok=True)
        event = sanitize_route_event(event)
        with open(ROUTE_EVENTS_PATH, 'a') as f:
            f.write(json.dumps(event, sort_keys=True, separators=(',', ':')) + '\n')
    except Exception as e:
        logger.debug(f'Route event append failed: {e}')
        event = sanitize_route_event(event)
    mirror_route_event_async(event)


def read_recent_route_events(limit=None):
    """Read recent structured route events without retaining prompts or message bodies."""
    limit = int(limit or ANALYTICS_EVENT_LIMIT)
    events = []
    try:
        with open(ROUTE_EVENTS_PATH) as f:
            lines = f.readlines()[-limit:]
        for line in lines:
            try:
                event = json.loads(line)
                if isinstance(event, dict):
                    events.append(sanitize_route_event(event))
            except Exception:
                continue
    except FileNotFoundError:
        pass
    except Exception as e:
        logger.debug(f'Route events read failed: {e}')
    return events


def metadata_access_token():
    try:
        req = urllib.request.Request(
            'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',
            headers={'Metadata-Flavor': 'Google'},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
        return payload.get('access_token') or ''
    except Exception as e:
        logger.debug(f'GCP metadata token unavailable: {e}')
        return ''


def firestore_value(value):
    if value is None:
        return {'nullValue': None}
    if isinstance(value, bool):
        return {'booleanValue': value}
    if isinstance(value, int) and not isinstance(value, bool):
        return {'integerValue': str(value)}
    if isinstance(value, float):
        return {'doubleValue': value}
    if isinstance(value, list):
        return {'arrayValue': {'values': [firestore_value(v) for v in value]}}
    if isinstance(value, dict):
        return {'mapValue': {'fields': {str(k): firestore_value(v) for k, v in value.items()}}}
    return {'stringValue': str(value)}


def firestore_plain(value):
    if not isinstance(value, dict):
        return None
    if 'stringValue' in value:
        return value.get('stringValue')
    if 'integerValue' in value:
        try:
            return int(value.get('integerValue'))
        except Exception:
            return value.get('integerValue')
    if 'doubleValue' in value:
        return float(value.get('doubleValue'))
    if 'booleanValue' in value:
        return bool(value.get('booleanValue'))
    if 'nullValue' in value:
        return None
    if 'arrayValue' in value:
        return [firestore_plain(v) for v in (value.get('arrayValue') or {}).get('values', [])]
    if 'mapValue' in value:
        return {k: firestore_plain(v) for k, v in ((value.get('mapValue') or {}).get('fields') or {}).items()}
    return None


def write_firestore_route_event(event):
    if not (FIRESTORE_ENABLED and FIRESTORE_PROJECT_ID):
        return False
    token = metadata_access_token()
    if not token:
        return False
    event = sanitize_route_event(event)
    doc_id = urllib.parse.quote(str(event.get('request_id') or uuid.uuid4().hex), safe='')
    database = urllib.parse.quote(FIRESTORE_DATABASE, safe='')
    coll = urllib.parse.quote(FIRESTORE_ROUTE_EVENTS_COLLECTION, safe='')
    url = f'https://firestore.googleapis.com/v1/projects/{FIRESTORE_PROJECT_ID}/databases/{database}/documents/{coll}/{doc_id}'
    body = json.dumps({'fields': {k: firestore_value(v) for k, v in event.items()}}).encode('utf-8')
    req = urllib.request.Request(url, data=body, method='PATCH', headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    })
    with urllib.request.urlopen(req, timeout=8) as resp:
        resp.read(256)
    return True


def read_firestore_route_events(window_seconds=7 * 24 * 3600, limit=None):
    if not (FIRESTORE_ENABLED and FIRESTORE_PROJECT_ID):
        return []
    token = metadata_access_token()
    if not token:
        return []
    limit = int(limit or ANALYTICS_EVENT_LIMIT)
    since = int(time.time()) - int(window_seconds or 0) if window_seconds else 0
    database = urllib.parse.quote(FIRESTORE_DATABASE, safe='')
    url = f'https://firestore.googleapis.com/v1/projects/{FIRESTORE_PROJECT_ID}/databases/{database}/documents:runQuery'
    query = {
        'structuredQuery': {
            'from': [{'collectionId': FIRESTORE_ROUTE_EVENTS_COLLECTION}],
            'where': {'fieldFilter': {'field': {'fieldPath': 'ts'}, 'op': 'GREATER_THAN_OR_EQUAL', 'value': {'integerValue': str(since)}}},
            'orderBy': [{'field': {'fieldPath': 'ts'}, 'direction': 'DESCENDING'}],
            'limit': limit,
        }
    }
    req = urllib.request.Request(url, data=json.dumps(query).encode('utf-8'), headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
        events = []
        for row in payload if isinstance(payload, list) else []:
            fields = ((row.get('document') or {}).get('fields') or {})
            event = {k: firestore_plain(v) for k, v in fields.items()}
            if event:
                events.append(sanitize_route_event(event))
        return list(reversed(events))
    except Exception as e:
        logger.debug(f'Firestore analytics read failed: {extract_http_error(e)}')
        return []


def supabase_request(path, method='GET', body=None, service=False, extra_headers=None, timeout=8):
    key = SUPABASE_SERVICE_ROLE_KEY if service else SUPABASE_ANON_KEY
    if not (SUPABASE_URL and key):
        return None
    headers = {'apikey': key, 'Authorization': f'Bearer {key}'}
    if body is not None:
        headers['Content-Type'] = 'application/json'
        headers['Prefer'] = 'resolution=merge-duplicates,return=minimal'
    if extra_headers:
        headers.update(extra_headers)
    data = json.dumps(body).encode('utf-8') if body is not None else None
    req = urllib.request.Request(SUPABASE_URL.rstrip('/') + path, data=data, method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    if not raw:
        return None
    try:
        return json.loads(raw.decode('utf-8'))
    except Exception:
        return raw.decode('utf-8', errors='replace')


def write_supabase_route_event(event):
    if not (SUPABASE_MIRROR_ENABLED and SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY):
        return False
    event = sanitize_route_event(event)
    selected = event.get('selected') or {}
    row = {
        'request_id': str(event.get('request_id') or uuid.uuid4().hex),
        'event_ts': int(event.get('ts') or time.time()),
        'status': event.get('status'),
        'intent': event.get('intent'),
        'complexity': event.get('complexity'),
        'thinking': event.get('thinking'),
        'route_mode': event.get('routeMode'),
        'estimated_tokens': event.get('estimatedTokens'),
        'selected_provider': selected.get('provider'),
        'selected_model': selected.get('model'),
        'total_elapsed_ms': event.get('totalElapsedMs'),
        'attempt_count': len(event.get('attempts') or []),
        'event': event,
    }
    supabase_request(f'/rest/v1/{SUPABASE_ROUTE_EVENTS_TABLE}', method='POST', body=row, service=True)
    return True


def write_supabase_analytics_snapshot(snapshot):
    if not (SUPABASE_MIRROR_ENABLED and SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY):
        return False
    row = {
        'snapshot_id': f"{int(snapshot.get('generatedAt') or time.time())}-{int(snapshot.get('windowSeconds') or 0)}",
        'generated_at_epoch': int(snapshot.get('generatedAt') or time.time()),
        'window_seconds': int(snapshot.get('windowSeconds') or 0),
        'events_analyzed': int(snapshot.get('eventsAnalyzed') or 0),
        'snapshot': snapshot,
    }
    supabase_request(f'/rest/v1/{SUPABASE_ANALYTICS_SNAPSHOTS_TABLE}', method='POST', body=row, service=True)
    return True


def read_supabase_route_events(window_seconds=7 * 24 * 3600, limit=None):
    if not (SUPABASE_MIRROR_ENABLED and SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY):
        return []
    since = int(time.time()) - int(window_seconds or 0) if window_seconds else 0
    limit = int(limit or ANALYTICS_EVENT_LIMIT)
    path = f'/rest/v1/{SUPABASE_ROUTE_EVENTS_TABLE}?select=event&event_ts=gte.{since}&order=event_ts.desc&limit={limit}'
    try:
        rows = supabase_request(path, service=True, timeout=10) or []
        events = [sanitize_route_event((r or {}).get('event') or {}) for r in rows if isinstance(r, dict)]
        return list(reversed([e for e in events if e]))
    except Exception as e:
        logger.debug(f'Supabase analytics read failed: {extract_http_error(e)}')
        return []


def mirror_route_event_async(event):
    def worker():
        try:
            write_firestore_route_event(event)
        except Exception as e:
            logger.debug(f'Firestore route event mirror failed: {extract_http_error(e)}')
        try:
            write_supabase_route_event(event)
        except Exception as e:
            logger.debug(f'Supabase route event mirror failed: {extract_http_error(e)}')
    threading.Thread(target=worker, daemon=True).start()


def mirror_analytics_snapshot_async(snapshot):
    def worker():
        try:
            write_supabase_analytics_snapshot(snapshot)
        except Exception as e:
            logger.debug(f'Supabase analytics snapshot mirror failed: {extract_http_error(e)}')
    threading.Thread(target=worker, daemon=True).start()


def percentile(values, pct):
    if not values:
        return None
    values = sorted(float(v) for v in values)
    if len(values) == 1:
        return round(values[0], 2)
    pos = (len(values) - 1) * pct
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return round(values[int(pos)], 2)
    return round(values[lo] + (values[hi] - values[lo]) * (pos - lo), 2)


def build_analytics_snapshot(window_seconds=7 * 24 * 3600, event_limit=None):
    """Build provider/model performance analytics for the paid observability layer."""
    now = int(time.time())
    since = now - int(window_seconds or 0) if window_seconds else 0
    durable_events = read_firestore_route_events(window_seconds, event_limit)
    source = 'firestore' if durable_events else 'local'
    if not durable_events:
        durable_events = read_supabase_route_events(window_seconds, event_limit)
        source = 'supabase' if durable_events else 'local'
    events = durable_events or [e for e in read_recent_route_events(event_limit) if int(e.get('ts', 0) or 0) >= since]
    provider_rows = {}
    model_rows = {}
    intent_rows = {}

    def row_for(table, key):
        row = table.setdefault(key, {
            'requests': 0,
            'successes': 0,
            'failures': 0,
            'attempts': 0,
            'attemptFailures': 0,
            'latencies': [],
            'lastSeenAt': 0,
        })
        return row

    for event in events:
        event = sanitize_route_event(event)
        status_ok = event.get('status') == 'ok'
        selected = event.get('selected') or {}
        attempts = event.get('attempts') or []
        intent = str(event.get('intent') or 'UNKNOWN')
        total_ms = event.get('totalElapsedMs')
        intent_row = row_for(intent_rows, intent)
        intent_row['requests'] += 1
        intent_row['successes' if status_ok else 'failures'] += 1
        if isinstance(total_ms, (int, float)):
            intent_row['latencies'].append(float(total_ms))
        intent_row['lastSeenAt'] = max(intent_row['lastSeenAt'], int(event.get('ts', 0) or 0))

        if selected:
            provider = selected.get('provider') or 'unknown'
            model = selected.get('model') or 'unknown'
            for table, key in ((provider_rows, provider), (model_rows, f'{provider}/{model}')):
                row = row_for(table, key)
                row['requests'] += 1
                row['successes' if status_ok else 'failures'] += 1
                if isinstance(total_ms, (int, float)):
                    row['latencies'].append(float(total_ms))
                row['lastSeenAt'] = max(row['lastSeenAt'], int(event.get('ts', 0) or 0))

        for attempt in attempts:
            provider = attempt.get('provider') or 'unknown'
            model = attempt.get('model') or 'unknown'
            ok = bool(attempt.get('ok'))
            elapsed = attempt.get('elapsedMs')
            for table, key in ((provider_rows, provider), (model_rows, f'{provider}/{model}')):
                row = row_for(table, key)
                row['attempts'] += 1
                if not ok:
                    row['attemptFailures'] += 1
                if isinstance(elapsed, (int, float)):
                    row['latencies'].append(float(elapsed))

    for intent, providers in (LATENCY_STATS.get('intents') or {}).items():
        for provider, models in (providers or {}).items():
            for model, stat in (models or {}).items():
                key = f'{provider}/{model}'
                for table, row_key in ((provider_rows, provider), (model_rows, key)):
                    row = row_for(table, row_key)
                    successes = int(stat.get('successes', 0) or 0)
                    failures = int(stat.get('failures', 0) or 0)
                    if row['requests'] == 0:
                        row['successes'] += successes
                        row['failures'] += failures
                        row['requests'] += successes + failures
                    ewma = stat.get('latency_ewma_ms')
                    if isinstance(ewma, (int, float)):
                        row['latencies'].append(float(ewma))
                    row['lastSeenAt'] = max(row['lastSeenAt'], int(stat.get('updated_at', 0) or 0))

    def finalize(table):
        out = []
        for key, row in table.items():
            requests = int(row['requests'])
            successes = int(row['successes'])
            failures = int(row['failures'])
            attempts = int(row['attempts'])
            attempt_failures = int(row['attemptFailures'])
            lats = row.pop('latencies', [])
            success_rate = (successes / requests) if requests else None
            attempt_failure_rate = (attempt_failures / attempts) if attempts else None
            out.append({
                'id': key,
                'requests': requests,
                'successes': successes,
                'failures': failures,
                'successRate': round(success_rate, 4) if success_rate is not None else None,
                'attempts': attempts,
                'attemptFailureRate': round(attempt_failure_rate, 4) if attempt_failure_rate is not None else None,
                'p50Ms': percentile(lats, 0.50),
                'p95Ms': percentile(lats, 0.95),
                'avgMs': round(sum(lats) / len(lats), 2) if lats else None,
                'lastSeenAt': row.get('lastSeenAt') or None,
            })
        return sorted(out, key=lambda x: (-(x.get('successRate') or 0), x.get('p50Ms') or 999999, -x.get('requests', 0)))

    models = finalize(model_rows)
    providers = finalize(provider_rows)
    intents = finalize(intent_rows)
    best_fast = [m for m in models if m.get('successRate') is not None and m.get('p50Ms') is not None][:10]
    most_reliable = sorted(models, key=lambda x: (-(x.get('successRate') or 0), -(x.get('requests') or 0), x.get('p95Ms') or 999999))[:10]
    degraded = sorted([m for m in models if (m.get('attemptFailureRate') or 0) > 0 or (m.get('successRate') is not None and m.get('successRate') < 0.95)], key=lambda x: (-(x.get('attemptFailureRate') or 0), x.get('successRate') or 0))[:10]

    snapshot = {
        'version': 2,
        'generatedAt': now,
        'windowSeconds': int(window_seconds or 0),
        'eventsAnalyzed': len(events),
        'source': source,
        'privacy': {
            'promptsStored': False,
            'messageBodiesStored': False,
            'containsProviderCredentials': False,
        },
        'providers': providers,
        'models': models,
        'intents': intents,
        'recommendations': {
            'fastestModels': best_fast,
            'mostReliableModels': most_reliable,
            'degradedModels': degraded,
        },
    }
    mirror_analytics_snapshot_async(snapshot)
    return snapshot


def supabase_user_for_bearer(token):
    if not (SUPABASE_AUTH_ENABLED and SUPABASE_URL and SUPABASE_ANON_KEY and token):
        return None
    try:
        req = urllib.request.Request(SUPABASE_URL.rstrip('/') + '/auth/v1/user', headers={
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': f'Bearer {token}',
        })
        with urllib.request.urlopen(req, timeout=6) as resp:
            user = json.loads(resp.read().decode('utf-8'))
        return user if isinstance(user, dict) and user.get('id') else None
    except Exception as e:
        logger.debug(f'Supabase auth validation failed: {extract_http_error(e)}')
        return None


def analytics_authorized(handler):
    auth = handler.headers.get('Authorization') or ''
    bearer = auth[7:].strip() if auth.lower().startswith('bearer ') else ''
    if ANALYTICS_TOKEN and bearer == ANALYTICS_TOKEN:
        return True
    if supabase_user_for_bearer(bearer):
        return True
    return not ANALYTICS_TOKEN and not SUPABASE_AUTH_ENABLED


def get_latency_stat(intent_name, provider_name, model):
    return (((LATENCY_STATS.get('intents') or {}).get(intent_name) or {}).get(provider_name) or {}).get(model)


def get_intent_provider_stats(intent_name, provider_name):
    return (((LATENCY_STATS.get('intents') or {}).get(intent_name) or {}).get(provider_name) or {})


def get_health_stat(intent_name, provider_name, model):
    return get_latency_stat(intent_name, provider_name, model) or get_latency_stat('GENERAL', provider_name, model) or {}


def record_latency_outcome(intent_name, provider_name, model, elapsed_seconds, ok, error_text=''):
    elapsed_ms = max(1.0, float(elapsed_seconds) * 1000.0)
    now = int(time.time())
    error_meta = parse_error_meta(error_text)
    with LATENCY_STATS_LOCK:
        intents = LATENCY_STATS.setdefault('intents', {})
        intent_stats = intents.setdefault(intent_name, {})
        provider_stats = intent_stats.setdefault(provider_name, {})
        stat = provider_stats.setdefault(model, {
            'successes': 0,
            'failures': 0,
            'consecutive_failures': 0,
            'rate_limit_hits': 0,
            'timeout_hits': 0,
            'empty_output_hits': 0,
            'cooldown_until': 0,
            'latency_ewma_ms': elapsed_ms,
            'last_latency_ms': elapsed_ms,
            'updated_at': now,
        })

        stat['last_latency_ms'] = elapsed_ms
        stat['updated_at'] = now
        if ok:
            stat['successes'] = int(stat.get('successes', 0)) + 1
            stat['consecutive_failures'] = 0
            stat['cooldown_until'] = 0
            stat['timeout_hits'] = 0
            stat['empty_output_hits'] = 0
            stat['last_success_at'] = now
            previous = float(stat.get('latency_ewma_ms', elapsed_ms) or elapsed_ms)
            stat['latency_ewma_ms'] = round((LATENCY_EWMA_ALPHA * elapsed_ms) + ((1.0 - LATENCY_EWMA_ALPHA) * previous), 2)
            clear_temp_model_block(provider_name, model)
        else:
            stat['failures'] = int(stat.get('failures', 0)) + 1
            stat['consecutive_failures'] = int(stat.get('consecutive_failures', 0)) + 1
            cooldown_until = float(stat.get('cooldown_until', 0) or 0)
            if error_meta['rate_limited']:
                stat['rate_limit_hits'] = int(stat.get('rate_limit_hits', 0)) + 1
                cooldown_until = max(cooldown_until, now + min(1800, RATE_LIMIT_COOLDOWN_BASE_SECONDS * (2 ** max(0, stat['rate_limit_hits'] - 1))))
            if error_meta['timeout']:
                stat['timeout_hits'] = int(stat.get('timeout_hits', 0)) + 1
                if stat['consecutive_failures'] >= CONSECUTIVE_FAILURE_COOLDOWN_THRESHOLD:
                    timeout_backoff = min(1800, FAILURE_COOLDOWN_BASE_SECONDS * (2 ** max(0, stat['timeout_hits'] - 1)))
                    cooldown_until = max(cooldown_until, now + timeout_backoff)
                    set_temp_model_block(provider_name, model, timeout_backoff, 'timeout')
            if error_meta['empty_output']:
                stat['empty_output_hits'] = int(stat.get('empty_output_hits', 0)) + 1
                empty_backoff = min(1800, EMPTY_OUTPUT_COOLDOWN_SECONDS * max(1, stat['empty_output_hits']))
                cooldown_until = max(cooldown_until, now + empty_backoff)
                set_temp_model_block(provider_name, model, empty_backoff, 'empty_output')
            if error_meta['model_missing']:
                cooldown_until = max(cooldown_until, now + MODEL_MISSING_COOLDOWN_SECONDS)
                set_temp_model_block(provider_name, model, MODEL_MISSING_COOLDOWN_SECONDS, 'model_missing')
            if stat['consecutive_failures'] >= CONSECUTIVE_FAILURE_COOLDOWN_THRESHOLD and cooldown_until <= now:
                generic_backoff = min(1800, FAILURE_COOLDOWN_BASE_SECONDS * max(1, stat['consecutive_failures'] - CONSECUTIVE_FAILURE_COOLDOWN_THRESHOLD + 1))
                cooldown_until = now + generic_backoff
                set_temp_model_block(provider_name, model, generic_backoff, 'repeated_failures')
            stat['cooldown_until'] = cooldown_until

        save_latency_stats()
        invalidate_model_health_cache(provider_name, model)


def general_empirical_adjustment(provider, model):
    provider_name = provider.name
    stat = get_latency_stat('GENERAL', provider_name, model)
    provider_stats = get_intent_provider_stats('GENERAL', provider_name)
    if not stat:
        if provider.api_type in ('openclaw-gateway', 'openai-codex-responses'):
            return -4.0, 'cold-gateway'
        if provider_stats:
            return -2.0, 'provider-known,cold-model'
        return GENERAL_EMPIRICAL_EXPLORATION_BONUS, 'cold'

    successes = int(stat.get('successes', 0))
    failures = int(stat.get('failures', 0))
    samples = successes + failures
    exploration = GENERAL_EMPIRICAL_EXPLORATION_BONUS / math.sqrt(samples + 1)

    if successes <= 0:
        penalty = GENERAL_EMPIRICAL_FAILURE_PENALTY * failures
        return exploration - penalty, f'explore={exploration:.2f},fail={penalty:.2f}'

    latency_ewma_ms = float(stat.get('latency_ewma_ms', GENERAL_EMPIRICAL_LATENCY_PIVOT_MS) or GENERAL_EMPIRICAL_LATENCY_PIVOT_MS)
    exploration = min(exploration, GENERAL_EMPIRICAL_SUCCESS_EXPLORATION_CAP)
    speed_bonus = (GENERAL_EMPIRICAL_LATENCY_PIVOT_MS - latency_ewma_ms) / 250.0
    speed_bonus = max(-GENERAL_EMPIRICAL_LATENCY_BONUS_CAP, min(GENERAL_EMPIRICAL_LATENCY_BONUS_CAP, speed_bonus))
    penalty = GENERAL_EMPIRICAL_FAILURE_PENALTY * failures
    total = speed_bonus + exploration - penalty
    return total, f'ewma_ms={latency_ewma_ms:.0f},explore={exploration:.2f},fail={penalty:.2f}'



def route_latency_target_ms(route_mode: str, complexity: Complexity, thinking: ThinkingLevel):
    base = {
        'fast': 9000,
        'balanced': 14000,
        'best': 24000,
        'local-first': 11000,
        'realtime': 5000,
    }.get(route_mode, 14000)
    if complexity == Complexity.SIMPLE:
        base -= 2000
    elif complexity == Complexity.COMPLEX:
        base += 6000
    if thinking == ThinkingLevel.HIGH:
        base += 4000
    elif thinking == ThinkingLevel.LOW:
        base -= 1500
    return max(6000, min(45000, base))



def empirical_route_adjustment(provider, model, intent_name: str, route_mode: str, complexity: Complexity, thinking: ThinkingLevel):
    stat = get_health_stat(intent_name, provider.name, model)
    provider_stats = get_intent_provider_stats(intent_name, provider.name) or get_intent_provider_stats('GENERAL', provider.name)
    successes = int(stat.get('successes', 0))
    failures = int(stat.get('failures', 0))
    samples = successes + failures

    if samples <= 0:
        if route_mode == 'best':
            return 0.0, 'cold:best-mode'
        if provider.api_type == 'ollama':
            penalty = 6.0 if route_mode == 'balanced' else 4.0
        elif provider.api_type == 'google-generative-language':
            penalty = 10.0 if route_mode == 'balanced' else 12.0
        else:
            penalty = 18.0 if route_mode == 'balanced' else 22.0
        if provider_stats:
            penalty -= 2.0
        return -penalty, f'cold:penalty={penalty:.1f}'

    if successes <= 0:
        penalty = min(30.0, 12.0 + (failures * 3.5))
        if provider.api_type != 'ollama' and route_mode != 'best':
            penalty += 4.0
        if route_mode == 'best':
            penalty *= 0.7
        return -penalty, f'no-success:failures={failures}'

    target_ms = route_latency_target_ms(route_mode, complexity, thinking)
    ewma_ms = float(stat.get('latency_ewma_ms', target_ms) or target_ms)
    delta_seconds = (target_ms - ewma_ms) / 1000.0
    if delta_seconds >= 0:
        latency_adjustment = min(14.0, delta_seconds * 0.9)
    else:
        multiplier = 1.6 if route_mode in {'fast', 'local-first', 'realtime'} else 1.15 if route_mode == 'balanced' else 0.65
        latency_adjustment = -min(30.0, abs(delta_seconds) * multiplier)

    confidence_bonus = min(8.0, math.log2(successes + 1) * 2.0)
    failure_penalty = min(12.0, failures * 0.45)
    total = latency_adjustment + confidence_bonus - failure_penalty
    return total, f'ewma_ms={ewma_ms:.0f},target_ms={target_ms},succ={successes},fail={failures}'



def ollama_family_bonus(model: str, intent: Intent):
    model_l = (model or '').lower()
    best = 0
    for family, meta in OLLAMA_FAMILY_HINTS.items():
        if family in model_l and intent.name in meta['intents']:
            best = max(best, int(meta['bonus']))
    return best


def build_openclaw_gateway_prompt(messages):
    system_parts = []
    conversation_parts = []
    for msg in messages or []:
        role = msg.get('role', 'user')
        content = (msg.get('content') or '').strip()
        if not content:
            continue
        if role in ('system', 'developer'):
            system_parts.append(content)
            continue
        sender = 'Assistant' if role == 'assistant' else 'Tool' if role == 'tool' else 'User'
        conversation_parts.append(f'{sender}: {content}')

    sections = []
    if system_parts:
        sections.append('System instructions:\n' + '\n\n'.join(system_parts))
    if conversation_parts:
        sections.append('Conversation so far:\n' + '\n'.join(conversation_parts))
    sections.append('Reply as the assistant to the latest user message.')
    return '\n\n'.join(section for section in sections if section).strip()


def fetch_ollama_manifest(provider: Provider):
    manifest_file = OLLAMA_MANIFEST_FILES.get(canonical_provider_env_key(provider.name), '')
    if manifest_file:
        try:
            with open(os.path.expanduser(manifest_file)) as f:
                payload = json.load(f)
            if isinstance(payload, dict) and isinstance(payload.get('models'), list):
                return payload, 'file'
        except Exception as e:
            logger.warning(f"Ollama manifest file {provider.name}: {e}")

    manifest_url = OLLAMA_MANIFEST_URLS.get(canonical_provider_env_key(provider.name), '')
    if manifest_url:
        try:
            req = urllib.request.Request(manifest_url, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_SECONDS) as resp:
                payload = json.loads(resp.read())
            if isinstance(payload, dict) and isinstance(payload.get('models'), list):
                return payload, 'url'
        except Exception as e:
            logger.warning(f"Ollama manifest fetch {provider.name}: {extract_http_error(e)}")
    return None, None


def ollama_manifest_model_id(entry):
    if not isinstance(entry, dict):
        return ''
    return (entry.get('id') or entry.get('model') or entry.get('name') or '').strip()


def apply_ollama_manifest(provider: Provider, manifest):
    models = []
    meta = dict(provider.model_meta or {})
    servable_only = []
    for entry in manifest.get('models', []) or []:
        model_id = ollama_manifest_model_id(entry)
        if not model_id:
            continue
        servable = bool(entry.get('servable', True))
        models.append(model_id)
        meta[model_id] = {
            'reasoning': bool(entry.get('reasoning', False)),
            'contextWindow': entry.get('contextWindow'),
            'maxTokens': entry.get('maxTokens'),
            'input': entry.get('input') or ['text'],
            'servable': servable,
            'preferred': bool(entry.get('preferred', False)),
            'resident': bool(entry.get('resident', False)),
            'manifestReason': entry.get('reason'),
            'supportsChat': entry.get('supportsChat', True),
            'supportsTools': entry.get('supportsTools'),
            'supportsJson': entry.get('supportsJson'),
            'supportsStreaming': entry.get('supportsStreaming', True),
        }
        if servable:
            servable_only.append(model_id)
    provider.model_meta = meta
    provider.models = dedupe_keep_order(servable_only or models or provider.models or [])
    return provider.models


def fetch_ollama_models(provider: Provider):
    now = time.time()
    cached = OLLAMA_MODEL_CACHE.get(provider.name)
    if cached and now - cached['checked_at'] < OLLAMA_MODEL_REFRESH_TTL_SECONDS:
        return cached['models']

    manifest, manifest_source = fetch_ollama_manifest(provider)
    manifest_models = []
    if manifest:
        manifest_models = apply_ollama_manifest(provider, manifest)
    catalog_models = ollama_cloud_catalog_models()
    if catalog_models:
        meta = dict(provider.model_meta or {})
        for model_name in catalog_models:
            meta.setdefault(model_name, ollama_cloud_model_meta(model_name))
        provider.model_meta = meta

    tag_models = []
    try:
        url = provider.base_url.rstrip('/') + '/api/tags'
        req = urllib.request.Request(url, headers={'Content-Type': 'application/json'})
        if provider.api_key:
            req.add_header('Authorization', f'Bearer {provider.api_key}')
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read())
        for model in payload.get('models', []) or []:
            model_name = (model.get('name') or model.get('model') or '').strip()
            if model_name:
                tag_models.append(model_name)
                meta = dict(provider.model_meta or {})
                details = model.get('details', {}) if isinstance(model.get('details'), dict) else {}
                existing = dict(meta.get(model_name) or {})
                existing.update({
                    'reasoning': bool(existing.get('reasoning', False)),
                    'contextWindow': existing.get('contextWindow') or details.get('context_length'),
                    'maxTokens': existing.get('maxTokens'),
                    'input': existing.get('input') or ['text'],
                    'servable': bool(existing.get('servable', True)),
                    'preferred': bool(existing.get('preferred', False)),
                    'resident': bool(existing.get('resident', False)),
                    'manifestReason': existing.get('manifestReason'),
                    'family': details.get('family', existing.get('family', '')),
                    'families': details.get('families') or existing.get('families') or [],
                })
                meta[model_name] = existing
                provider.model_meta = meta
    except Exception as e:
        logger.warning(f"Ollama model discovery {provider.name}: {extract_http_error(e)}")
    tag_models = dedupe_keep_order(tag_models)
    first_local_cloud = next((m for m in tag_models if is_local_cloud_ollama_model(provider, m)), None)
    if first_local_cloud:
        probe_local_ollama_cloud_auth(provider, first_local_cloud)
    known_models = dedupe_keep_order((provider.models or []) + manifest_models + catalog_models + tag_models)
    if known_models:
        provider.models = known_models
    source = 'tags'
    if manifest_models and tag_models:
        source = f'manifest:{manifest_source}+tags'
    elif manifest_models:
        source = f'manifest:{manifest_source}'
    # Cache installed/tagged models separately from configured/manifest-known models.
    OLLAMA_MODEL_CACHE[provider.name] = {'checked_at': now, 'models': tag_models, 'known_models': known_models, 'source': source}
    return tag_models


def parse_error_meta(error_text: str):
    raw = (error_text or '').lower()
    return {
        'rate_limited': 'http 429' in raw or 'rate limit' in raw or 'too many requests' in raw,
        'timeout': 'timed out' in raw or 'timeout' in raw,
        'model_missing': ('model' in raw and 'not found' in raw) or 'no such model' in raw,
        'empty_output': 'empty content' in raw or 'thinking-only output' in raw or 'empty visible content' in raw,
    }


def model_health_snapshot(provider: Provider, model: str, intent_name: str = 'GENERAL'):
    now = time.time()
    cache_key = f'{intent_name}:{provider.name}/{model}'
    cached = MODEL_HEALTH_CACHE.get(cache_key)
    if cached and now - cached['checked_at'] < HEALTH_SCORE_TTL_SECONDS:
        return cached
    stat = get_health_stat(intent_name, provider.name, model)
    successes = int(stat.get('successes', 0))
    failures = int(stat.get('failures', 0))
    consecutive_failures = int(stat.get('consecutive_failures', 0))
    rate_limit_hits = int(stat.get('rate_limit_hits', 0))
    timeout_hits = int(stat.get('timeout_hits', 0))
    empty_output_hits = int(stat.get('empty_output_hits', 0))
    cooldown_until = float(stat.get('cooldown_until', 0) or 0)
    last_success_at = stat.get('last_success_at')
    reachable = provider_endpoint_reachable(provider)
    temp_block = active_temp_model_block(provider.name, model)
    models_present = True
    if provider.api_type == 'ollama':
        live_models = fetch_ollama_models(provider)
        if is_cloud_ollama_model(model) and not is_local_ollama_provider(provider):
            models_present = model in (provider.models or [])
        else:
            models_present = (model in live_models) if live_models else (model in (provider.models or []))
    if temp_block:
        models_present = False
        cooldown_until = max(cooldown_until, float(temp_block.get('until', 0) or 0))
    latency_ewma_ms = float(stat.get('latency_ewma_ms', GENERAL_EMPIRICAL_LATENCY_PIVOT_MS) or GENERAL_EMPIRICAL_LATENCY_PIVOT_MS)
    score = 100.0
    if not reachable:
        score -= 60
    if not models_present:
        score -= 45
    score -= min(35, consecutive_failures * 8)
    score -= min(30, failures * 2)
    score -= min(30, rate_limit_hits * 10)
    score -= min(20, timeout_hits * 6)
    score -= min(15, empty_output_hits * 5)
    score += max(-20, min(20, (GENERAL_EMPIRICAL_LATENCY_PIVOT_MS - latency_ewma_ms) / 200.0))
    if cooldown_until > now:
        score -= 50
    if provider.api_type == 'ollama':
        score += 8
    meta = (provider.model_meta or {}).get(model, {})
    if meta.get('preferred'):
        score += 8
    if meta.get('resident'):
        score += 6
    health = {
        'checked_at': now,
        'reachable': reachable,
        'models_present': models_present,
        'temporarily_blocked': bool(temp_block),
        'temporary_block_reason': (temp_block or {}).get('reason'),
        'latency_ewma_ms': latency_ewma_ms,
        'successes': successes,
        'failures': failures,
        'consecutive_failures': consecutive_failures,
        'rate_limit_hits': rate_limit_hits,
        'timeout_hits': timeout_hits,
        'empty_output_hits': empty_output_hits,
        'cooldown_until': cooldown_until,
        'last_success_at': last_success_at,
        'score': round(score, 2),
    }
    MODEL_HEALTH_CACHE[cache_key] = health
    return health


def provider_endpoint_reachable(provider: Provider) -> bool:
    now = time.time()
    cached = PROVIDER_HEALTH_CACHE.get(provider.name)
    if cached and now - cached['checked_at'] < REACHABILITY_TTL_SECONDS:
        return cached['reachable']

    reachable = False
    try:
        parsed = urllib.parse.urlparse(provider.base_url)
        host = parsed.hostname
        port = parsed.port
        if not host:
            reachable = False
        else:
            if port is None:
                port = 443 if parsed.scheme == 'https' else 80
            with socket.create_connection((host, port), timeout=REACHABILITY_TIMEOUT_SECONDS):
                reachable = True
    except Exception:
        reachable = False

    PROVIDER_HEALTH_CACHE[provider.name] = {'reachable': reachable, 'checked_at': now}
    return reachable


def available_provider_names():
    return [
        name for name, provider in PROVIDERS.items()
        if name not in DISABLED_PROVIDERS and provider.models and provider_endpoint_reachable(provider)
    ]


# Patterns of models to auto-pull when discovered on any Ollama instance.
# Set via env: SAGE_ROUTER_OLLAMA_AUTO_PULL_PATTERNS=comma,separated,patterns
OLLAMA_AUTO_PULL_PATTERNS = [
    p.strip() for p in os.environ.get('SAGE_ROUTER_OLLAMA_AUTO_PULL_PATTERNS', ':cloud').split(',')
    if p.strip()
]
# How often to check for new models to pull (seconds)
OLLAMA_AUTO_PULL_INTERVAL_SECONDS = int(os.environ.get('SAGE_ROUTER_OLLAMA_AUTO_PULL_INTERVAL_SECONDS', '3600'))


def ollama_pattern_matches(pattern: str, model: str):
    pattern = (pattern or '').strip().lower()
    model_l = (model or '').strip().lower()
    if not pattern:
        return False
    if pattern in {'*', 'all'}:
        return True
    if pattern.endswith('*') and model_l.startswith(pattern[:-1]):
        return True
    if pattern.startswith('*') and model_l.endswith(pattern[1:]):
        return True
    return pattern in model_l


def ollama_model_auto_pull_compatible(provider: Provider, model: str):
    if not model or not model_is_servable(provider, model):
        return False
    if not is_chat_capable_model(provider, model):
        return False
    caps = model_capabilities(provider, model)
    return bool(caps.get('chat') and caps.get('streaming', True))


def ollama_auto_pull_new_models():
    """Pull missing compatible Ollama models that match configured patterns.

    Sources are merged from config, manifests, and live /api/tags.  This lets a
    fresh Umbrel Ollama app with zero local tags still pull configured/known
    compatible models instead of being invisible to routing.
    """
    now = time.time()
    last_pull_check_key = '_last_auto_pull_check'
    if now - OLLAMA_MODEL_CACHE.get(last_pull_check_key, 0) < OLLAMA_AUTO_PULL_INTERVAL_SECONDS:
        return
    OLLAMA_MODEL_CACHE[last_pull_check_key] = now

    if not OLLAMA_AUTO_PULL_PATTERNS:
        return

    for provider in PROVIDERS.values():
        if provider.api_type != 'ollama' or provider.name in DISABLED_PROVIDERS:
            continue
        manifest, _ = fetch_ollama_manifest(provider)
        manifest_models = []
        if manifest:
            manifest_models = [ollama_manifest_model_id(m) for m in manifest.get('models', []) or []]

        cache = OLLAMA_MODEL_CACHE.get(provider.name, {})
        available = set(fetch_ollama_models(provider))
        all_known = dedupe_keep_order((provider.models or []) + cache.get('known_models', []) + manifest_models)
        matching = []
        for model in all_known:
            if model in available:
                continue
            if not ollama_model_auto_pull_compatible(provider, model):
                continue
            if any(ollama_pattern_matches(pattern, model) for pattern in OLLAMA_AUTO_PULL_PATTERNS):
                matching.append(model)

        for model in dedupe_keep_order(matching):
            logger.info(f'Auto-pulling missing compatible Ollama model: {model} (provider={provider.name}, patterns={OLLAMA_AUTO_PULL_PATTERNS})')
            try:
                pull_url = provider.base_url.rstrip('/') + '/api/pull'
                data = json.dumps({'name': model, 'stream': False}).encode()
                req = urllib.request.Request(pull_url, data=data, headers={'Content-Type': 'application/json'})
                if provider.api_key:
                    req.add_header('Authorization', f'Bearer {provider.api_key}')
                with urllib.request.urlopen(req, timeout=600) as resp:
                    result = json.loads(resp.read())
                logger.info(f'Auto-pull complete: {model} -> {result.get("status", "ok")}')
                OLLAMA_MODEL_CACHE.pop(provider.name, None)
                fetch_ollama_models(provider)
                MODEL_HEALTH_CACHE.clear()
            except Exception as e:
                logger.warning(f'Auto-pull failed for {model}: {extract_http_error(e)}')


def background_refresh_detect_families():
    """Scan all Ollama providers' /api/tags for new model families.
    - Auto-register chat families into OLLAMA_FAMILY_HINTS with a default bonus.
    - Auto-register non-chat families into NON_CHAT_OLLAMA_FAMILIES.
    - Log newly discovered families for visibility.
    """
    new_chat = []
    new_nonchat = []
    for provider in PROVIDERS.values():
        if provider.api_type != 'ollama':
            continue
        meta = provider.model_meta or {}
        for model_name, info in meta.items():
            family = (info.get('family') or '').strip().lower()
            families = info.get('families') or []
            all_families = set()
            if family:
                all_families.add(family)
            for f in (families if isinstance(families, list) else []):
                if f and isinstance(f, str):
                    all_families.add(f.strip().lower())
            for fam in all_families:
                # Check if non-chat
                is_nonchat = any(pat in fam for pat in NON_CHAT_FAMILY_PATTERNS) or fam in NON_CHAT_OLLAMA_FAMILIES
                if is_nonchat:
                    if fam not in NON_CHAT_OLLAMA_FAMILIES:
                        NON_CHAT_OLLAMA_FAMILIES.add(fam)
                        new_nonchat.append(fam)
                else:
                    # Check if chat family is known
                    known = False
                    for hint_key in OLLAMA_FAMILY_HINTS:
                        if fam.startswith(hint_key) or hint_key.startswith(fam):
                            known = True
                            break
                    if not known and fam not in OLLAMA_FAMILY_HINTS:
                        # Auto-register new chat family with conservative defaults
                        OLLAMA_FAMILY_HINTS[fam] = {'bonus': 5, 'intents': {'GENERAL', 'CODE'}}
                        new_chat.append(fam)
    if new_chat:
        logger.info(f'Auto-registered new chat families: {new_chat}')
    if new_nonchat:
        logger.info(f'Auto-registered new non-chat families: {new_nonchat}')


def background_refresh_loop():
    while True:
        try:
            for provider in PROVIDERS.values():
                if provider.api_type == 'ollama':
                    fetch_ollama_models(provider)
                for model in dedupe_keep_order(provider.models or []):
                    model_health_snapshot(provider, model, 'GENERAL')
            background_refresh_detect_families()
            ollama_auto_pull_new_models()
        except Exception as e:
            logger.warning(f'Background refresh failed: {e}')
        time.sleep(max(30, min(OLLAMA_MODEL_REFRESH_TTL_SECONDS, HEALTH_SCORE_TTL_SECONDS)))


def ensure_background_refresh_started():
    global BACKGROUND_REFRESH_STARTED
    if BACKGROUND_REFRESH_STARTED:
        return
    thread = threading.Thread(target=background_refresh_loop, name='sage-router-refresh', daemon=True)
    thread.start()
    BACKGROUND_REFRESH_STARTED = True


def reasoning_capabilities_summary():
    summary = {}
    for name, provider in PROVIDERS.items():
        if name in DISABLED_PROVIDERS:
            continue
        summary[name] = {
            'api': provider.api_type,
            'reachable': provider_endpoint_reachable(provider),
            'models': [
                {
                    'id': model,
                    'capabilities': model_capabilities(provider, model),
                    'health': model_health_snapshot(provider, model, 'GENERAL'),
                }
                for model in dedupe_keep_order(provider.models or [])
            ],
        }
    return summary


def classify_intent_with_local_model(text):
    """Optional tiny local/GPU model classifier for ambiguous routing.

    Enabled with SAGE_ROUTER_INTENT_CLASSIFIER_ENABLED=1. Providers:
    - ollama: POST /api/chat
    - llamacpp/openai-compatible: POST /v1/chat/completions
    """
    if not INTENT_CLASSIFIER_ENABLED:
        return None, {}, {'enabled': False}
    provider = (INTENT_CLASSIFIER_PROVIDER or 'ollama').strip().lower()
    # Small local classifiers are most valuable on vague requests. Keep the
    # prompt deliberately label-only because tiny Qwen/llama.cpp models are
    # more reliable at one-token classification than strict JSON.
    prompt = (
        'Classify this request for AI model routing.\n'
        'Reply with exactly one label and no extra text.\n'
        'Labels: GENERAL, CODE, ANALYSIS, CREATIVE, REALTIME.\n'
        'Use CODE for programming/debugging/implementation.\n'
        'Use REALTIME for current/latest/weather/price/news/time-sensitive facts.\n'
        'Use CREATIVE for writing/story/brainstorm/design ideation.\n'
        'Use ANALYSIS for compare/review/research/explain/why/how reasoning.\n'
        'Use GENERAL for ordinary chat or unclear requests.\n'
        'Examples:\n'
        'Fix this Python bug => CODE\n'
        'Weather today in Paris? => REALTIME\n'
        'Write a sci-fi story => CREATIVE\n'
        'Compare A vs B => ANALYSIS\n'
        f'Request: {text[:INTENT_CLASSIFIER_MAX_PROMPT_CHARS]}\n'
        'Label:'
    )
    started = time.time()
    try:
        if provider == 'ollama':
            payload = {
                'model': INTENT_CLASSIFIER_MODEL,
                'messages': [{'role': 'user', 'content': prompt}],
                'stream': False,
                'options': {'num_predict': 8, 'temperature': 0, 'num_ctx': 1024},
            }
            req = urllib.request.Request(
                INTENT_CLASSIFIER_BASE_URL.rstrip('/') + '/api/chat',
                data=json.dumps(payload).encode(),
                headers={'Content-Type': 'application/json'},
            )
            with urllib.request.urlopen(req, timeout=INTENT_CLASSIFIER_TIMEOUT_SECONDS) as resp:
                body = json.loads(resp.read())
            raw = (body.get('message') or {}).get('content') or ''
        elif provider in {'llamacpp', 'llama.cpp', 'openai-compatible', 'openai_compatible'}:
            payload = {
                'model': INTENT_CLASSIFIER_MODEL,
                'messages': [{'role': 'system', 'content': 'Reply with exactly one routing label.'}, {'role': 'user', 'content': prompt}],
                'stream': False,
                'max_tokens': 8,
                'temperature': 0,
            }
            headers = {'Content-Type': 'application/json'}
            if INTENT_CLASSIFIER_API_KEY:
                headers['Authorization'] = f'Bearer {INTENT_CLASSIFIER_API_KEY}'
            req = urllib.request.Request(
                openai_chat_completions_url(INTENT_CLASSIFIER_BASE_URL),
                data=json.dumps(payload).encode(),
                headers=headers,
            )
            with urllib.request.urlopen(req, timeout=INTENT_CLASSIFIER_TIMEOUT_SECONDS) as resp:
                body = json.loads(resp.read())
            raw = (((body.get('choices') or [{}])[0].get('message') or {}).get('content') or '')
        else:
            return None, {}, {'enabled': True, 'used': False, 'error': f'unsupported provider {provider}'}

        cleaned = raw.strip()
        if cleaned.startswith('```'):
            cleaned = _re.sub(r'^```(?:json)?\s*', '', cleaned, flags=_re.IGNORECASE).strip()
            cleaned = _re.sub(r'\s*```$', '', cleaned).strip()
        parsed = None
        intent_name = ''
        confidence = 0.9
        m = _re.search(r'\{.*\}', cleaned, flags=_re.DOTALL)
        if m:
            try:
                parsed = json.loads(m.group(0))
                intent_name = str(parsed.get('intent') or '').strip().upper()
                confidence = float(parsed.get('confidence') or confidence)
            except Exception:
                parsed = None
        if not intent_name:
            label_match = _re.search(r'\b(GENERAL|CODE|ANALYSIS|CREATIVE|REALTIME)\b', cleaned.upper())
            if label_match:
                intent_name = label_match.group(1)
        if intent_name in Intent.__members__ and confidence >= INTENT_CLASSIFIER_MIN_CONFIDENCE:
            scores = {i: 0 for i in Intent}
            scores[Intent[intent_name]] = max(1, int(confidence * 10))
            return Intent[intent_name], scores, {
                'enabled': True,
                'used': True,
                'provider': provider,
                'baseUrl': INTENT_CLASSIFIER_BASE_URL,
                'model': INTENT_CLASSIFIER_MODEL,
                'confidence': confidence,
                'elapsedMs': round((time.time() - started) * 1000.0, 2),
                'raw': parsed if parsed is not None else cleaned,
            }
        return None, {}, {'enabled': True, 'used': False, 'provider': provider, 'model': INTENT_CLASSIFIER_MODEL, 'confidence': confidence, 'intent': intent_name, 'elapsedMs': round((time.time() - started) * 1000.0, 2), 'raw': cleaned[:200], 'error': 'low confidence or invalid intent'}
    except Exception as e:
        return None, {}, {'enabled': True, 'used': False, 'provider': provider, 'model': INTENT_CLASSIFIER_MODEL, 'elapsedMs': round((time.time() - started) * 1000.0, 2), 'error': extract_http_error(e)}


def analysis_signal_score(text):
    tl = (text or '').lower()
    score = 0
    for kw in ANALYSIS_SIGNAL_TERMS:
        if kw in tl:
            score += 2 if ' ' in kw or '-' in kw else 1
    if '?' in tl and any(prefix in tl for prefix in ('can we', 'could we', 'should we', 'would it', 'do we', 'how ', 'why ', 'what would', 'what should')):
        score += 2
    if len(tl.split()) >= 40 and any(x in tl for x in ('because', 'but', 'however', 'tradeoff', 'risk', 'if ', 'when ')):
        score += 2
    return score


def heuristic_intent_scores(text):
    tl = text.lower(); scores = {i:0 for i in Intent}
    for kw in ['write','code','debug','fix','refactor','implement','function','bug','test','.py','.js']:
        if kw in tl: scores[Intent.CODE] += 1
    if '```' in text: scores[Intent.CODE] += 3
    for kw in ['analyze','explain','compare','research','why','how does','review','translate','summarize','summary','extract','parse','pdf','document','report','informe','conclusion','findings','medical report','mri','resonancia']:
        if kw in tl: scores[Intent.ANALYSIS] += 1
    scores[Intent.ANALYSIS] += analysis_signal_score(text)
    for kw in ['create','brainstorm','imagine','design','story']:
        if kw in tl: scores[Intent.CREATIVE] += 2
    for kw in ['now','today','current','latest','price','weather']:
        if kw in tl: scores[Intent.REALTIME] += 2
    return scores


def normalized_intent_pattern(text):
    """Collapse a request into a stable cache key for similar routing intent.

    Keep signal words, but strip volatile values so "fix foo.py line 41" and
    "fix bar.ts line 98" reuse the same classifier hint.
    """
    t = (text or '').lower()[:INTENT_CLASSIFIER_MAX_PROMPT_CHARS]
    t = _re.sub(r'```.*?```', ' <codeblock> ', t, flags=_re.DOTALL)
    t = _re.sub(r'`[^`]*`', ' <inline> ', t)
    t = _re.sub(r'https?://\S+', ' <url> ', t)
    t = _re.sub(r'(?<!\w)[~/./-]*[\w.-]+/(?:[\w./-]+)', ' <path> ', t)
    t = _re.sub(r'\b[\w.-]+\.(py|js|ts|tsx|jsx|json|md|yml|yaml|sh|sql|html|css)\b', ' <file> ', t)
    t = _re.sub(r'\b[0-9a-f]{7,40}\b', ' <hash> ', t)
    t = _re.sub(r'\b\d+(?:\.\d+)?\b', ' <num> ', t)
    t = _re.sub(r'[^a-z0-9_<>{}:+#./-]+', ' ', t)
    return _re.sub(r'\s+', ' ', t).strip()[:512]


def _intent_cache_get(pattern):
    if not pattern:
        return None
    now = time.time()
    with INTENT_CLASSIFIER_CACHE_LOCK:
        item = INTENT_CLASSIFIER_CACHE.get(pattern)
        if not item:
            return None
        if now - item.get('ts', 0) > INTENT_CLASSIFIER_CACHE_TTL_SECONDS:
            INTENT_CLASSIFIER_CACHE.pop(pattern, None)
            return None
        return dict(item)


def _intent_cache_put(pattern, intent, scores, meta):
    if not pattern or intent is None:
        return
    with INTENT_CLASSIFIER_CACHE_LOCK:
        if len(INTENT_CLASSIFIER_CACHE) >= INTENT_CLASSIFIER_CACHE_MAX:
            oldest = min(INTENT_CLASSIFIER_CACHE, key=lambda k: INTENT_CLASSIFIER_CACHE[k].get('ts', 0), default=None)
            if oldest:
                INTENT_CLASSIFIER_CACHE.pop(oldest, None)
        INTENT_CLASSIFIER_CACHE[pattern] = {
            'ts': time.time(),
            'intent': intent.name,
            'scores': {k.name: v for k, v in (scores or {}).items()},
            'meta': dict(meta or {}),
        }


def _warm_intent_cache_async(text, pattern, heuristic_winner, heuristic_score):
    def worker():
        model_intent, model_scores, model_meta = classify_intent_with_local_model(text)
        if model_intent is None:
            return
        if heuristic_score >= 2 and heuristic_winner != model_intent:
            return
        _intent_cache_put(pattern, model_intent, model_scores, model_meta)

    thread = threading.Thread(target=worker, name='sage-router-intent-cache', daemon=True)
    thread.start()


def classify_intent(text):
    heuristic_scores = heuristic_intent_scores(text)
    heuristic_winner = max(heuristic_scores, key=heuristic_scores.get)
    heuristic_score = heuristic_scores.get(heuristic_winner, 0)
    heuristic_intent = heuristic_winner if heuristic_score > 0 else Intent.GENERAL

    # Default path: deterministic heuristics only. This avoids adding a model
    # round trip before the real response starts.
    if not INTENT_CLASSIFIER_ENABLED:
        LAST_ROUTE_DEBUG['intentClassifier'] = {'enabled': False, 'used': False}
        return heuristic_intent, heuristic_scores

    pattern = normalized_intent_pattern(text)
    cached = _intent_cache_get(pattern)
    if cached and heuristic_score < INTENT_CLASSIFIER_ONLY_IF_HEURISTIC_BELOW:
        intent_name = cached.get('intent')
        if intent_name in Intent.__members__:
            scores = {i: 0 for i in Intent}
            for k, v in (cached.get('scores') or {}).items():
                if k in Intent.__members__:
                    scores[Intent[k]] = v
            meta = dict(cached.get('meta') or {})
            meta.update({'enabled': True, 'used': True, 'source': 'cache', 'pattern': pattern})
            LAST_ROUTE_DEBUG['intentClassifier'] = meta
            return Intent[intent_name], scores

    meta = {
        'enabled': True,
        'used': False,
        'source': 'heuristic',
        'heuristicIntent': heuristic_intent.name,
        'heuristicScore': heuristic_score,
        'threshold': INTENT_CLASSIFIER_ONLY_IF_HEURISTIC_BELOW,
        'pattern': pattern,
    }
    if heuristic_score >= INTENT_CLASSIFIER_ONLY_IF_HEURISTIC_BELOW:
        meta['skippedByHeuristic'] = True
    elif INTENT_CLASSIFIER_ASYNC:
        meta['asyncWarmupQueued'] = True
        _warm_intent_cache_async(text, pattern, heuristic_winner, heuristic_score)
    else:
        # Synchronous mode remains available for explicit tests, but should not
        # be enabled in normal operation.
        model_intent, model_scores, model_meta = classify_intent_with_local_model(text)
        if model_intent is not None:
            _intent_cache_put(pattern, model_intent, model_scores, model_meta)
        meta.update(model_meta or {})

    LAST_ROUTE_DEBUG['intentClassifier'] = meta
    return heuristic_intent, heuristic_scores

def estimate_complexity(text):
    w = len(text.split())
    analysis_score = analysis_signal_score(text)
    if w > 200 or analysis_score >= 6 or (analysis_score >= 4 and w >= 35):
        return Complexity.COMPLEX
    if w < 30 and analysis_score < 3:
        return Complexity.SIMPLE
    return Complexity.MEDIUM

def pick_model(prov, prefer=None):
    if not prov.models: return ''
    if prefer:
        for wanted in prefer:
            for m in prov.models:
                if m == wanted or wanted in m:
                    return m
    return prov.models[0]


def normalize_thinking(raw):
    if isinstance(raw, dict):
        raw = raw.get('effort') or raw.get('level') or raw.get('thinking')
    if raw is None:
        return ThinkingLevel.MEDIUM
    value = str(raw).strip().lower()
    if value in {'low', 'minimal'}:
        return ThinkingLevel.LOW
    if value in {'high', 'max', 'deep'}:
        return ThinkingLevel.HIGH
    return ThinkingLevel.MEDIUM


def thinking_max_tokens(level: ThinkingLevel):
    if level == ThinkingLevel.LOW:
        return 4096
    if level == ThinkingLevel.HIGH:
        return 12288
    return 8192


def model_quality_tier(model):
    model_l = (model or '').lower()
    if any(h in model_l for h in WEAK_ANALYSIS_MODEL_HINTS) and not any(h in model_l for h in ('opus', 'sonnet', '-pro', ' pro')):
        return 'weak'
    if any(h in model_l for h in ANALYSIS_QUALITY_MODEL_HINTS):
        return 'strong'
    return 'medium'


ROUTER_PROFILE_CACHE = {'mtime': None, 'profiles': {}}


def load_router_profiles():
    try:
        st = os.stat(ROUTER_PROFILES_PATH)
        if ROUTER_PROFILE_CACHE.get('mtime') == st.st_mtime:
            return ROUTER_PROFILE_CACHE.get('profiles') or {}
        with open(ROUTER_PROFILES_PATH) as f:
            data = json.load(f)
        profiles = data.get('profiles', data) if isinstance(data, dict) else {}
        if not isinstance(profiles, dict):
            profiles = {}
        ROUTER_PROFILE_CACHE.update({'mtime': st.st_mtime, 'profiles': profiles})
        return profiles
    except FileNotFoundError:
        ROUTER_PROFILE_CACHE.update({'mtime': None, 'profiles': {}})
        return {}
    except Exception as e:
        logger.warning(f'Failed to load router profiles: {e}')
        return ROUTER_PROFILE_CACHE.get('profiles') or {}


def resolve_router_profile_name(payload):
    if not isinstance(payload, dict):
        return None
    for key in ('profile', 'routerProfile', 'sageRouterProfile'):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    model = str(payload.get('model') or '').strip()
    if model.startswith('sage-router/'):
        name = model.split('/', 1)[1]
        if name and name != 'auto':
            return name
    elif model and '/' not in model and model not in PROVIDERS:
        return model
    return None


def apply_router_profile(payload):
    if not isinstance(payload, dict):
        return None
    profile_name = resolve_router_profile_name(payload)
    if not profile_name:
        return None
    profile = load_router_profiles().get(profile_name)
    if not isinstance(profile, dict):
        return None
    if profile.get('route'):
        payload['route'] = profile.get('route')
    if profile.get('thinking'):
        payload['thinking'] = {'effort': str(profile.get('thinking'))}
    req = payload.get('requirements')
    if not isinstance(req, dict):
        req = {}
    for key in ('qualitySensitive', 'reasoning', 'tools', 'preferTools', 'json', 'vision', 'document', 'longContext', 'frontierOrReasoningTools', 'suppressToolCallContent'):
        if key in profile:
            req[key] = bool(profile.get(key))
    if profile.get('suppressIntermediateToolText'):
        req['suppressToolCallContent'] = True
    if profile.get('requiresQuality'):
        payload['requiresQuality'] = True
        req['qualitySensitive'] = True
    if profile.get('requiresReasoning'):
        payload['requiresReasoning'] = True
        req['reasoning'] = True
    if profile.get('requiresTools'):
        payload['requiresTools'] = True
        req['tools'] = True
    if profile.get('frontierLargeOnly'):
        req['frontierLargeOnly'] = True
    if profile.get('frontierOrReasoningTools'):
        req['frontierOrReasoningTools'] = True
    if profile.get('minParamsB') is not None:
        req['minParamsB'] = profile.get('minParamsB')
    for key in ('allowModels', 'denyModels', 'allowProviders', 'denyProviders'):
        if profile.get(key):
            req[key] = profile.get(key)
    payload['requirements'] = req
    if str(payload.get('model') or '').strip() in {profile_name, f'sage-router/{profile_name}'}:
        payload['model'] = 'sage-router/auto'
    return profile_name


def _match_any_pattern(value, patterns):
    if not patterns:
        return False
    value_l = str(value or '').lower()
    import fnmatch
    return any(fnmatch.fnmatch(value_l, str(p).lower()) or str(p).lower() in value_l for p in patterns)


def estimate_model_params_b(model):
    model_l = (model or '').lower()
    import re
    nums = [float(x) for x in re.findall(r'(?<![a-z0-9])(\d+(?:\.\d+)?)\s*b(?![a-z])', model_l)]
    if nums:
        return max(nums)
    if any(h in model_l for h in ('405b', 'llama4-405b')):
        return 405
    if any(h in model_l for h in ('340b', 'nemotron-4-340b')):
        return 340
    if any(h in model_l for h in ('gpt-5', 'gpt-4.5', 'claude-opus', 'claude-sonnet-4', 'gemini-3', 'gemini-2.5-pro', 'hunter-alpha', 'healer-alpha', 'kimi-k2', 'glm-5', 'z1-ultra')):
        return 999
    return 0


FRONTIER_LARGE_MODEL_HINTS = (
    'gpt-5', 'gpt-4.5', 'claude-opus', 'claude-sonnet-4', 'claude-4',
    'gemini-3', 'gemini-2.5-pro', 'gemini-pro',
    'llama-3.1-405b', 'llama4-405b', '405b', '340b',
    'nemotron-4-340b', 'hunter-alpha', 'healer-alpha',
    'kimi-k2', 'kimi-k2.5', 'glm-5', 'z1-ultra',
)


def model_is_frontier_large(model):
    model_l = (model or '').lower()
    return any(hint in model_l for hint in FRONTIER_LARGE_MODEL_HINTS)


def payload_discord_public_signal(payload):
    if not isinstance(payload, dict):
        return False
    model = str(payload.get('model') or '').strip().lower()
    if model in {'discord-public', 'sage-router/discord-public', 'frontier-public', 'sage-router/frontier-public'}:
        return True
    try:
        haystack = json.dumps({k: payload.get(k) for k in ('metadata', 'agent', 'agentId', 'sessionKey', 'source', 'messages')}, default=str)[:16000].lower()
    except Exception:
        haystack = str(payload)[:16000].lower()
    return 'discord-public' in haystack


def apply_discord_public_route_profile(payload):
    """Force public Discord traffic onto quality-first routing.

    Public channels are user-visible product surfaces, so cheap/mini/local-small
    models are not acceptable defaults.  This profile requires either a known
    frontier/large model, or a model that supports both reasoning and tools,
    then runs with high thinking and best route mode.
    """
    if not payload_discord_public_signal(payload):
        return False
    payload['thinking'] = {'effort': 'high'}
    payload['route'] = 'best'
    req = payload.get('requirements')
    if not isinstance(req, dict):
        req = {}
    req.update({
        'qualitySensitive': True,
        'reasoning': True,
        'frontierOrReasoningTools': True,
        'suppressToolCallContent': True,
    })
    payload['requirements'] = req
    payload['requiresQuality'] = True
    payload['requiresReasoning'] = True
    return True


def score_provider_model(provider, model, intent, complexity, thinking=ThinkingLevel.MEDIUM, route_mode='balanced', estimated_tokens=0, debug_scores=None, requirements=None):
    requirements = requirements or {}
    intent_key = intent.name
    api_score = INTENT_API_SCORES.get(intent_key, {}).get(provider.api_type, 40)
    model_l = model.lower()
    provider_l = provider.name.lower()
    score = api_score
    contributions = [('api_base', round(api_score, 2))]

    for idx, hint in enumerate(INTENT_MODEL_HINTS.get(intent_key, [])):
        if hint in model_l:
            bonus = max(1, 12 - idx)
            score += bonus
            contributions.append((f'intent_hint:{hint}', round(bonus, 2)))

    ctx_window = model_context_window(provider, model)
    if estimated_tokens and ctx_window and ctx_window < estimated_tokens * 1.2:
        score -= 20
        contributions.append(('context_window_penalty', -20))
    elif estimated_tokens and ctx_window and ctx_window >= max(64000, estimated_tokens * 2):
        score += 6
        contributions.append(('long_context_bonus', 6))

    if provider.api_type == 'anthropic-messages' and intent in (Intent.CODE, Intent.ANALYSIS, Intent.GENERAL):
        score += 4
        contributions.append(('anthropic_reasoning_bias', 4))
    # openclaw-gateway is recursive (routes through this router), so it gets
    # a fixed low base score - only used as a fallback, never preferred.
    if provider.api_type in ('openclaw-gateway', 'openai-codex-responses'):
        score = min(score, 40)
        contributions.append(('openclaw_gateway_recursive_cap', min(0, 40 - score)))
    # OpenAI-compat / non-recursive external APIs keep their score as-is.
    # The openclaw-gateway penalty below handles the rest.
    if provider.api_type in ('openclaw-gateway', 'openai-codex-responses'):
        score -= 4
        contributions.append(('openclaw_gateway_penalty', -4))

    if intent == Intent.CODE:
        if provider.name == 'openai-codex' or model_l.startswith('gpt-') or 'codex' in model_l:
            score += 14
            contributions.append(('user_pref_code_gpt', 14))
            if complexity == Complexity.COMPLEX:
                score += 8
                contributions.append(('complex_code_gpt_bonus', 8))
        elif provider.api_type == 'anthropic-messages':
            score -= 10
            contributions.append(('user_pref_code_non_gpt_penalty', -10))
            if complexity == Complexity.COMPLEX and 'opus' in model_l:
                score += 18
                contributions.append(('complex_code_dario_opus_bonus', 18))
            elif complexity != Complexity.COMPLEX and 'sonnet' in model_l:
                score += 14
                contributions.append(('simple_code_dario_sonnet_bonus', 14))
            elif 'haiku' in model_l:
                score -= 8
                contributions.append(('code_dario_haiku_penalty', -8))
        elif provider.api_type == 'ollama':
            if 'glm-5.1' in model_l or model_l.startswith('glm-5:') or model_l == 'glm-5' or 'glm-5:cloud' in model_l:
                score += 18
                contributions.append(('user_pref_code_glm_bonus', 18))
                if complexity == Complexity.COMPLEX:
                    score += 8
                    contributions.append(('complex_code_glm_bonus', 8))
            elif 'kimi' in model_l:
                score += 6
                contributions.append(('user_pref_code_kimi_fallback', 6))
                if complexity == Complexity.COMPLEX:
                    score -= 4
                    contributions.append(('complex_code_kimi_penalty', -4))
            else:
                score -= 8
                contributions.append(('user_pref_code_other_ollama_penalty', -8))

    if intent == Intent.ANALYSIS:
        tier = model_quality_tier(model)
        if provider.api_type == 'ollama':
            score += 18
            contributions.append(('user_pref_analysis_ollama', 18))
        elif provider.name == 'openai-codex' or provider.api_type == 'openclaw-gateway':
            score -= 10
            contributions.append(('user_pref_analysis_not_gpt', -10))
        if tier == 'strong':
            score += 24
            contributions.append(('analysis_strong_model_bonus', 24))
        elif tier == 'weak':
            score -= 32
            contributions.append(('analysis_weak_model_penalty', -32))
        if complexity == Complexity.COMPLEX and tier != 'strong':
            score -= 16
            contributions.append(('complex_analysis_non_strong_penalty', -16))
        if requirements.get('qualitySensitive') and tier == 'strong':
            score += 12
            contributions.append(('quality_sensitive_strong_bonus', 12))
        elif requirements.get('qualitySensitive') and tier == 'weak':
            score -= 18
            contributions.append(('quality_sensitive_weak_penalty', -18))
    if complexity == Complexity.COMPLEX and any(hint in model_l for hint in COMPLEX_MODEL_HINTS):
        score += 5
        contributions.append(('complex_model_bonus', 5))
    if complexity == Complexity.COMPLEX and any(hint in model_l for hint in LIGHTWEIGHT_MODEL_HINTS):
        score -= 8
        contributions.append(('lightweight_complex_penalty', -8))
    if complexity == Complexity.SIMPLE and any(hint in model_l for hint in LIGHTWEIGHT_MODEL_HINTS):
        score += 2
        contributions.append(('lightweight_simple_bonus', 2))
    if requirements.get('qualitySensitive') and any(hint in model_l for hint in LIGHTWEIGHT_MODEL_HINTS):
        score -= 12
        contributions.append(('quality_sensitive_lightweight_penalty', -12))
    if requirements.get('frontierOrReasoningTools'):
        if model_is_frontier_large(model):
            score += 100
            contributions.append(('discord_public_frontier_large_bonus', 100))
        elif model_capabilities(provider, model).get('reasoning') and model_capabilities(provider, model).get('tools'):
            score += 70
            contributions.append(('discord_public_reasoning_tools_bonus', 70))
        else:
            score -= 120
            contributions.append(('discord_public_low_capability_penalty', -120))
    if requirements.get('frontierLargeOnly') and model_is_frontier_large(model):
        score += 120
        contributions.append(('profile_frontier_large_only_bonus', 120))
    if requirements.get('minParamsB') is not None:
        try:
            params_b = estimate_model_params_b(model)
            if params_b >= float(requirements.get('minParamsB')):
                bonus = min(80, params_b / 8)
                score += bonus
                contributions.append(('profile_min_params_bonus', round(bonus, 2)))
        except Exception:
            pass
    if is_nvidia_provider(provider) and (requirements.get('preferTools') or requirements.get('tools')):
        score -= 45
        contributions.append(('nvidia_tool_schema_leak_penalty', -45))
    if is_nvidia_provider(provider) and requirements.get('qualitySensitive'):
        score -= 25
        contributions.append(('quality_sensitive_nvidia_penalty', -25))
    if intent == Intent.GENERAL and provider.api_type == 'ollama':
        score -= 1
        contributions.append(('general_ollama_penalty', -1))
    if intent == Intent.GENERAL and provider.api_type == 'anthropic-messages':
        if 'haiku' in model_l:
            score += 34
            contributions.append(('general_dario_haiku_bonus', 34))
        elif 'sonnet' in model_l or 'opus' in model_l:
            score -= 6
            contributions.append(('general_dario_non_haiku_penalty', -6))
    if provider.api_type == 'ollama':
        family_bonus = ollama_family_bonus(model, intent)
        if family_bonus:
            score += family_bonus
            contributions.append(('ollama_family_bonus', family_bonus))
        if intent == Intent.CODE and ('glm-5.1' in model_l or model_l.startswith('glm-5:') or model_l == 'glm-5' or 'glm-5:cloud' in model_l):
            score += 8
            contributions.append(('glm5_code_preference', 8))
        elif intent == Intent.CODE and 'kimi' in model_l:
            score += 3
            contributions.append(('kimi_code_fallback_bonus', 3))
        elif intent == Intent.CODE and ('qwen' in model_l or 'deepseek' in model_l):
            score -= 4
            contributions.append(('glm_beats_qwen_deepseek_for_code', -4))

    if route_mode == 'fast':
        if provider.api_type == 'ollama':
            score += 6
            contributions.append(('route_mode_fast_ollama_bonus', 6))
        if provider.api_type in {'anthropic-messages', 'openclaw-gateway'}:
            score -= 3
            contributions.append(('route_mode_fast_remote_penalty', -3))
    elif route_mode == 'realtime':
        # Realtime: prioritize speed above all else, minimal latency
        if provider.api_type == 'ollama':
            score += 15
            contributions.append(('route_mode_realtime_ollama_bonus', 15))
        if 'flash' in model_l or 'turbo' in model_l or 'mini' in model_l:
            score += 8
            contributions.append(('route_mode_realtime_speed_hint', 8))
        if provider.api_type in {'anthropic-messages', 'openclaw-gateway'}:
            score -= 8
            contributions.append(('route_mode_realtime_remote_penalty', -8))
    elif route_mode == 'best':
        if provider.api_type in {'anthropic-messages', 'openclaw-gateway'}:
            score += 5
            contributions.append(('route_mode_best_frontier_bonus', 5))
    elif route_mode == 'local-first':
        if provider.api_type == 'ollama':
            score += 12
            contributions.append(('route_mode_local_first_ollama_bonus', 12))
        else:
            score -= 4
            contributions.append(('route_mode_local_first_remote_penalty', -4))

    if thinking == ThinkingLevel.HIGH:
        if any(hint in model_l for hint in COMPLEX_MODEL_HINTS):
            score += 6
            contributions.append(('thinking_high_complex_bonus', 6))
        if any(hint in model_l for hint in LIGHTWEIGHT_MODEL_HINTS):
            score -= 10
            contributions.append(('thinking_high_light_penalty', -10))
        if provider.api_type in {'anthropic-messages', 'openai-completions', 'openclaw-gateway'}:
            score += 3
            contributions.append(('thinking_high_reasoning_bias', 3))
    elif thinking == ThinkingLevel.LOW:
        if any(hint in model_l for hint in LIGHTWEIGHT_MODEL_HINTS):
            score += 6
            contributions.append(('thinking_low_light_bonus', 6))
        if any(hint in model_l for hint in COMPLEX_MODEL_HINTS):
            score -= 4
            contributions.append(('thinking_low_complex_penalty', -4))
        if provider.api_type in ('openclaw-gateway', 'openai-codex-responses'):
            score -= 6
            contributions.append(('thinking_low_gateway_penalty', -6))
        if provider.api_type == 'ollama':
            score += 2
            contributions.append(('thinking_low_ollama_bonus', 2))

    if requirements.get('document'):
        if provider.api_type == 'google-generative-language':
            score += 55
            contributions.append(('document_google_bonus', 55))
        elif provider.api_type in {'openai-completions', 'anthropic-messages'}:
            score += 30
            contributions.append(('document_frontier_bonus', 30))
        elif provider.api_type == 'ollama':
            score -= 35
            contributions.append(('document_ollama_penalty', -35))
        if any(h in model_l for h in ('gemini', 'gpt-5', 'gpt-4o', 'opus', 'sonnet', 'qwen', 'kimi', 'minimax')):
            score += 10
            contributions.append(('document_model_hint_bonus', 10))
        if is_nvidia_provider(provider):
            score -= 25
            contributions.append(('document_nvidia_penalty', -25))
        if any(h in model_l for h in ('nano', 'tiny', 'tts', 'asr', 'embed', 'clip', 'nemotron', '1b', '3b', '7b')):
            score -= 35
            contributions.append(('document_weak_model_penalty', -35))

    health = model_health_snapshot(provider, model, intent.name)
    health_delta = max(-60, min(40, (health.get('score', 0) - 50) * 0.6))
    score += health_delta
    contributions.append(('health_score_delta', round(health_delta, 2)))
    if provider.api_type == 'ollama' and health.get('models_present'):
        score += 5
        contributions.append(('ollama_present_bonus', 5))
    if health.get('cooldown_until', 0) > time.time():
        score -= 100
        contributions.append(('cooldown_penalty', -100))

    empirical_bonus, empirical_note = empirical_route_adjustment(provider, model, intent.name, route_mode, complexity, thinking)
    score += empirical_bonus
    contributions.append((f'route_empirical:{empirical_note}', round(empirical_bonus, 2)))

    if intent == Intent.GENERAL:
        score = 50 + ((score - 50) * 0.35)
        contributions.append(('general_blend', 'applied'))
        general_bonus, general_note = general_empirical_adjustment(provider, model)
        score += general_bonus
        contributions.append((f'empirical:{general_note}', round(general_bonus, 2)))
        logger.debug(f"[scoring] GENERAL {provider.name}/{model}: route_empirical={empirical_bonus:.2f} ({empirical_note}), empirical={general_bonus:.2f} ({general_note}), health={health.get('score', 0):.2f}, final={score:.2f}")

    final_score = round(score, 2)
    if debug_scores is not None:
        debug_scores.append({'provider': provider.name, 'model': model, 'score': final_score, 'health': health, 'contributions': contributions})
    return final_score


def payload_tools_soft_preference(requirements):
    return bool((requirements or {}).get('preferTools'))

def select_model(intent, complexity, thinking=ThinkingLevel.MEDIUM, route_mode='balanced', requirements=None, estimated_tokens=0):
    """Score ALL models across ALL providers globally, then rank.

    Previous behavior picked the best model per provider first, then
    merged. This v3.1 approach scores every (provider, model) pair
    independently and takes the top N globally, which gives small but
    high-quality providers a fair shot against large model pools."""
    all_candidates = []
    debug_scores = []
    rejections = []
    requirements = requirements or {}
    for pn, provider in PROVIDERS.items():
        if pn in DISABLED_PROVIDERS:
            continue
        if provider.api_type == 'ollama':
            fetch_ollama_models(provider)
        if route_mode == 'local-first' and not provider_allowed_in_local_first(provider):
            rejections.append({'provider': pn, 'model': '*', 'reason': local_first_rejection_reason(provider)})
            continue
        if not provider.models or not provider_endpoint_reachable(provider):
            continue
        for model in dedupe_keep_order(provider.models):
            disabled_reason = model_disabled_reason(provider.name, model)
            if disabled_reason:
                rejections.append({'provider': pn, 'model': model, 'reason': disabled_reason})
                continue
            if route_mode == 'local-first' and provider.api_type == 'ollama' and is_cloud_ollama_model(model):
                rejections.append({'provider': pn, 'model': model, 'reason': 'excluded by local-first (:cloud model)'})
                continue
            if not is_chat_capable_model(provider, model):
                rejections.append({'provider': pn, 'model': model, 'reason': 'not chat-capable'})
                continue
            ok_req, reason = model_meets_requirements(provider, model, requirements, estimated_tokens)
            if not ok_req:
                rejections.append({'provider': pn, 'model': model, 'reason': reason})
                continue
            score = score_provider_model(provider, model, intent, complexity, thinking, route_mode, estimated_tokens, debug_scores, requirements)
            if payload_tools_soft_preference(requirements) and model_capabilities(provider, model).get('tools'):
                bonus = 30 if intent in (Intent.ANALYSIS, Intent.CODE) or complexity == Complexity.COMPLEX or requirements.get('qualitySensitive') else 55
                if model_quality_tier(model) == 'weak' and (intent == Intent.ANALYSIS or complexity == Complexity.COMPLEX or requirements.get('qualitySensitive')):
                    bonus -= 20
                score += bonus
                if debug_scores is not None:
                    for entry in reversed(debug_scores):
                        if entry.get('provider') == provider.name and entry.get('model') == model:
                            entry['score'] = round(score, 2)
                            entry.setdefault('contributions', []).append(('tools_soft_preference_bonus', bonus))
                            break
            scored = (score, pn, model)
            all_candidates.append(scored)

    all_candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [(pn, model) for _, pn, model in all_candidates[:MAX_PROVIDER_ATTEMPTS]], sorted(debug_scores, key=lambda item: item['score'], reverse=True), rejections

def call_ollama(base_url, model, messages, api_key='', thinking=ThinkingLevel.MEDIUM):
    url = base_url.rstrip('/') + '/api/chat'
    payload = {"model": model, "messages": messages, "stream": False}
    if thinking == ThinkingLevel.LOW:
        payload["options"] = {"num_predict": 1024}
    elif thinking == ThinkingLevel.HIGH:
        payload["options"] = {"num_predict": 4096}

    hdrs = {'Content-Type': 'application/json'}
    if api_key:
        hdrs['Authorization'] = f'Bearer {api_key}'

    def _post_chat(chat_payload):
        data = json.dumps(chat_payload).encode()
        req = urllib.request.Request(url, data=data, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_SECONDS) as resp:
            return json.loads(resp.read())

    try:
        body = _post_chat(payload)
        message = body.get('message', {}) or {}
        content = message.get('content', '') or ''
        thinking_text = message.get('thinking', '') or ''
        content = sanitize_visible_output(content)
        if content:
            return True, content
        # Some Ollama thinking-capable models can spend the whole budget in
        # message.thinking and return empty content with done_reason=length.
        # Do not silently disable thinking by default. If the operator wants
        # the old recovery behavior, allow it explicitly via env.
        if thinking_text and OLLAMA_ALLOW_THINK_FALSE_RETRY:
            retry_payload = dict(payload)
            retry_payload['think'] = False
            retry_body = _post_chat(retry_payload)
            retry_message = retry_body.get('message', {}) or {}
            retry_content = sanitize_visible_output(retry_message.get('content', '') or '')
            if retry_content:
                logger.info(f"Ollama {base_url} {model}: recovered empty-content thinking response with opt-in think=false retry")
                return True, retry_content
        if thinking_text:
            err = 'Ollama returned thinking-only output with empty visible content'
            logger.warning(f"Ollama {base_url} {model}: {err}")
            return False, err
        err = 'Ollama returned empty content'
        logger.warning(f"Ollama {base_url} {model}: {err}")
        return False, err
    except Exception as e:
        err = extract_http_error(e)
        if 'timed out' in err.lower() and OLLAMA_ALLOW_THINK_FALSE_RETRY:
            try:
                retry_payload = dict(payload)
                retry_payload['think'] = False
                retry_body = _post_chat(retry_payload)
                retry_message = retry_body.get('message', {}) or {}
                retry_content = sanitize_visible_output(retry_message.get('content', '') or '')
                if retry_content:
                    logger.info(f"Ollama {base_url} {model}: recovered timed-out response with opt-in think=false retry")
                    return True, retry_content
            except Exception as retry_err:
                err = extract_http_error(retry_err)
        logger.warning(f"Ollama {base_url} {model}: {err}")
        return False, err

def call_openai_compat(base_url, model, messages, api_key='', provider_name='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, want_json=False):
    url = openai_chat_completions_url(base_url)
    payload = {"model": model, "messages": messages, "max_tokens": thinking_max_tokens(thinking)}
    if supports_reasoning:
        payload["reasoning"] = {"effort": thinking.value}
    if want_json:
        payload["response_format"] = {"type": "json_object"}
    try:
        data = json.dumps(payload).encode()
        hdrs = {'Content-Type': 'application/json'}
        add_openai_compat_headers(hdrs, provider_name)
        if api_key:
            hdrs['Authorization'] = f'Bearer {api_key}'
        req = urllib.request.Request(url, data=data, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            body = json.loads(resp.read())
        text = sanitize_visible_output(body.get('choices', [{}])[0].get('message', {}).get('content', '') or '')
        if text:
            return True, text
        err = 'OpenAI-compatible provider returned empty content'
        logger.warning(f"OpenAI-compat {provider_name or base_url} {model}: {err}")
        return False, err
    except Exception as e:
        logger.warning(f"OpenAI-compat {provider_name or base_url} {model}: {extract_http_error(e)}")
        return False, extract_http_error(e)


def call_openclaw_gateway(model, messages, provider_name='openai-codex', thinking=ThinkingLevel.MEDIUM, want_json=False, timeout_seconds=None):
    if not os.path.exists(OPENCLAW_GATEWAY_HELPER):
        return False, f'Missing OpenClaw gateway helper: {OPENCLAW_GATEWAY_HELPER}'

    effective_timeout = int(timeout_seconds or OPENCLAW_GATEWAY_TIMEOUT_SECONDS)
    payload = {
        'agentId': OPENCLAW_GATEWAY_AGENT_ID,
        'provider': provider_name,
        'model': model,
        'message': build_openclaw_gateway_prompt(messages),
        'timeoutMs': effective_timeout * 1000,
        'thinking': thinking.value,
        'responseFormat': 'json' if want_json else 'text',
    }

    try:
        proc = subprocess.run(
            ['node', OPENCLAW_GATEWAY_HELPER],
            input=json.dumps(payload),
            capture_output=True,
            text=True,
            timeout=effective_timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        logger.warning(f'OpenClaw gateway {provider_name} {model}: timed out after {effective_timeout}s')
        return False, f'OpenClaw gateway timeout after {effective_timeout}s'
    except Exception as e:
        logger.warning(f'OpenClaw gateway {provider_name} {model}: {e}')
        return False, str(e)

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or '').strip()
        logger.warning(f'OpenClaw gateway {provider_name} {model}: {detail[:500]}')
        return False, detail or f'OpenClaw gateway exited with code {proc.returncode}'

    try:
        result = json.loads(proc.stdout or '{}')
    except Exception:
        return False, (proc.stdout or proc.stderr or 'Invalid OpenClaw gateway response').strip()

    text = sanitize_visible_output(result.get('text', ''))
    if text:
        return True, text
    return False, json.dumps(result)



def call_codex_responses(base_url, model, messages, api_key='', provider_name='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, want_json=False):
    """Call OpenAI Codex Responses API at chatgpt.com/backend-api/codex/responses"""
    url = base_url.rstrip('/') + '/responses'
    
    # Build instructions and input from messages
    instructions = "You are a helpful assistant."
    input_msgs = []
    for msg in messages:
        role = msg.get('role', 'user')
        content = msg.get('content', '')
        if role == 'system':
            instructions = content if isinstance(content, str) else str(content)
        else:
            input_msgs.append({"role": role, "content": content})
    
    payload = {
        "model": model,
        "instructions": instructions,
        "input": input_msgs or [{"role": "user", "content": ""}],
        "store": False,
        "stream": True,
    }
    
    # Add reasoning effort if supported
    if supports_reasoning and thinking == ThinkingLevel.HIGH:
        payload["reasoning"] = {"effort": "high"}
    
    try:
        data = json.dumps(payload).encode()
        hdrs = {'Content-Type': 'application/json'}
        if api_key:
            hdrs['Authorization'] = f'Bearer {api_key}'
        req = urllib.request.Request(url, data=data, headers=hdrs)
        
        # Handle streaming response
        full_text = []
        event_type = None
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            for line in resp:
                line = line.decode().strip()
                if line.startswith('event: '):
                    event_type = line[6:].strip()
                elif line.startswith('data: ') and event_type == 'response.output_text.delta':
                    try:
                        delta_data = json.loads(line[6:])
                        if delta_data.get('type') == 'response.output_text.delta':
                            full_text.append(delta_data.get('delta', ''))
                    except Exception:
                        pass
                elif line == 'data: [DONE]':
                    break
                elif line.startswith('event: ') and not line.startswith('event: data'):
                    continue
        
        text = sanitize_visible_output(''.join(full_text))
        if text:
            return True, text
        return False, 'Empty Codex response'
    except Exception as e:
        logger.warning(f"Codex responses {provider_name or base_url} {model}: {extract_http_error(e)}")
        return False, extract_http_error(e)



def call_codex_completion(base_url, model, payload, api_key='', provider_name='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, debug_mode=False, request_id=''):
    """Call OpenAI Codex Responses API with streaming SSE support"""
    url = base_url.rstrip('/') + '/responses'
    
    messages = payload.get('messages', [])
    instructions = "You are a helpful assistant."
    input_msgs = []
    for msg in messages:
        role = msg.get('role', 'user')
        content = msg.get('content', '')
        if role == 'system':
            instructions = content if isinstance(content, str) else str(content)
        else:
            input_msgs.append({"role": role, "content": content})
    
    req_payload = {
        "model": model,
        "instructions": instructions,
        "input": input_msgs or [{"role": "user", "content": ""}],
        "store": False,
        "stream": True,
    }
    
    if supports_reasoning and thinking == ThinkingLevel.HIGH:
        req_payload["reasoning"] = {"effort": "high"}
    
    try:
        data = json.dumps(req_payload).encode()
        hdrs = {'Content-Type': 'application/json'}
        if api_key:
            hdrs['Authorization'] = f'Bearer {api_key}'
        
        req = urllib.request.Request(url, data=data, headers=hdrs)
        
        full_text = []
        event_type = None
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            for line in resp:
                line = line.decode().strip()
                if line.startswith('event: '):
                    event_type = line[6:].strip()
                elif line.startswith('data: ') and event_type == 'response.output_text.delta':
                    try:
                        delta_data = json.loads(line[6:])
                        if delta_data.get('type') == 'response.output_text.delta':
                            full_text.append(delta_data.get('delta', ''))
                    except Exception:
                        pass
                elif line == 'data: [DONE]':
                    break
        
        text = sanitize_visible_output(''.join(full_text))
        if text:
            return True, build_openai_completion(
                provider_name or 'openai-codex', model, request_id, text, [],
                'stop', {'prompt_tokens': 0, 'completion_tokens': 0},
                debug_mode=debug_mode
            )
        return False, 'Empty Codex response'
    except Exception as e:
        return False, extract_http_error(e)



def call_anthropic(base_url, model, messages, api_key='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, want_json=False):
    url = base_url.rstrip('/') + '/v1/messages'
    system_text = ''
    api_msgs = []
    for msg in messages:
        r, c = msg.get('role', 'user'), msg.get('content', '')
        if r == 'system':
            system_text += c + '\n'
        elif r in ('user', 'assistant'):
            api_msgs.append({"role": r, "content": c})
        else:
            label = r.upper() if isinstance(r, str) else 'MESSAGE'
            wrapped = f'[{label}]\n{c}'.strip() if c else f'[{label}]'
            api_msgs.append({"role": "user", "content": wrapped})
    if api_msgs and api_msgs[0].get('role') != 'user':
        api_msgs.insert(0, {"role": "user", "content": "Hello"})
    if not api_msgs:
        api_msgs = [{"role": "user", "content": "Hello"}]
    payload = {"model": model, "max_tokens": thinking_max_tokens(thinking), "messages": api_msgs}
    if supports_reasoning and thinking == ThinkingLevel.HIGH:
        payload["thinking"] = {"type": "enabled", "budget_tokens": 4096}
    if want_json:
        api_msgs.append({"role": "user", "content": "Return valid JSON only."})
    if system_text.strip():
        payload["system"] = system_text.strip()
    try:
        data = json.dumps(payload).encode()
        hdrs = {'Content-Type': 'application/json', 'anthropic-version': '2023-06-01'}
        if api_key:
            hdrs['x-api-key'] = api_key
        req = urllib.request.Request(url, data=data, headers=hdrs)
        with urllib.request.urlopen(req, timeout=ANTHROPIC_TIMEOUT_SECONDS) as resp:
            blocks = json.loads(resp.read()).get('content', [])
        text = sanitize_visible_output(''.join(b.get('text', '') for b in blocks if isinstance(b, dict) and b.get('type') == 'text'))
        if text:
            return True, text
        err = 'Anthropic returned empty content'
        logger.warning(f"Anthropic {base_url} {model}: {err}")
        return False, err
    except Exception as e:
        logger.warning(f"Anthropic {base_url} {model}: {extract_http_error(e)}")
        return False, extract_http_error(e)


def call_google(base_url, model, messages, api_key='', thinking=ThinkingLevel.MEDIUM, want_json=False):
    # Ensure base_url has /v1beta for Google API
    if 'generativelanguage.googleapis.com' in base_url and '/v1beta' not in base_url:
        base_url = base_url.rstrip('/') + '/v1beta'
    url = base_url.rstrip('/') + f'/models/{urllib.parse.quote(model, safe="")}:generateContent'
    system_text = ''
    contents = []
    for msg in messages:
        role = msg.get('role', 'user')
        content = msg.get('content', '')
        if not content:
            continue
        if role in ('system', 'developer'):
            system_text += content + '\n'
            continue
        if role == 'assistant':
            gemini_role = 'model'
            text = content
        elif role == 'user':
            gemini_role = 'user'
            text = content
        else:
            label = role.upper() if isinstance(role, str) else 'MESSAGE'
            gemini_role = 'user'
            text = f'[{label}]\n{content}'.strip()
        part = {'text': text}
        if contents and contents[-1].get('role') == gemini_role:
            contents[-1].setdefault('parts', []).append(part)
        else:
            contents.append({'role': gemini_role, 'parts': [part]})

    if contents and contents[0].get('role') != 'user':
        contents.insert(0, {'role': 'user', 'parts': [{'text': 'Hello'}]})
    if not contents:
        contents = [{'role': 'user', 'parts': [{'text': 'Hello'}]}]

    payload = {
        'contents': contents,
        'generationConfig': {'maxOutputTokens': thinking_max_tokens(thinking)},
    }
    if want_json:
        payload['generationConfig']['responseMimeType'] = 'application/json'
    if system_text.strip():
        payload['systemInstruction'] = {'parts': [{'text': system_text.strip()}]}

    try:
        data = json.dumps(payload).encode()
        hdrs = {'Content-Type': 'application/json'}
        if api_key:
            hdrs['x-goog-api-key'] = api_key
        req = urllib.request.Request(url, data=data, headers=hdrs)
        with urllib.request.urlopen(req, timeout=GOOGLE_TIMEOUT_SECONDS) as resp:
            result = json.loads(resp.read())
        parts = result.get('candidates', [{}])[0].get('content', {}).get('parts', [])
        text = sanitize_visible_output(''.join(part.get('text', '') for part in parts if isinstance(part, dict)))
        return (True, text) if text else (False, json.dumps(result)[:500])
    except Exception as e:
        logger.warning(f"Google {base_url} {model}: {extract_http_error(e)}")
        return False, extract_http_error(e)


def call_openai_compat_completion(base_url, model, payload, api_key='', provider_name='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, debug_mode=False, request_id=''):
    url = openai_chat_completions_url(base_url)
    proxied = build_openai_proxy_payload(payload, model, stream=False, supports_reasoning=supports_reasoning, thinking=thinking)
    logger.info(f"[openai-compat] Sending to {provider_name} with tools: {bool(proxied.get('tools'))}")
    try:
        data = json.dumps(proxied).encode()
        hdrs = {'Content-Type': 'application/json'}
        add_openai_compat_headers(hdrs, provider_name)
        if api_key:
            hdrs['Authorization'] = f'Bearer {api_key}'
        req = urllib.request.Request(url, data=data, headers=hdrs)
        with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
            body = json.loads(resp.read())
        choice = (body.get('choices') or [{}])[0]
        message = choice.get('message') or {}
        text = sanitize_visible_output(message.get('content', '') or '')
        raw_tool_calls = message.get('tool_calls')
        logger.info(f"[openai-compat] Response tool_calls: {raw_tool_calls}")
        tool_calls = normalize_tool_calls(raw_tool_calls)
        leak_reason = reject_visible_tool_call_leak(payload, text, tool_calls)
        if leak_reason:
            logger.warning(f"OpenAI-compat {provider_name or base_url} {model}: {leak_reason}")
            return False, leak_reason
        finish_reason = choice.get('finish_reason') or ('tool_calls' if tool_calls else 'stop')
        return True, build_openai_completion(provider_name, model, request_id, text, tool_calls, finish_reason, body.get('usage'), debug_mode=debug_mode, allow_debug_prefix=payload.get('response_format', {}).get('type') != 'json_object', suppress_tool_call_content=bool((payload.get('requirements') or {}).get('suppressToolCallContent') or payload.get('suppressToolCallContent') or payload.get('suppressIntermediateToolText')))
    except Exception as e:
        err = extract_http_error(e)
        logger.warning(f"OpenAI-compat {provider_name or base_url} {model}: {err}")
        return False, err


def call_ollama_completion(base_url, model, payload, api_key='', thinking=ThinkingLevel.MEDIUM, provider_name='ollama', debug_mode=False, request_id=''):
    url = base_url.rstrip('/') + '/api/chat'
    hdrs = {'Content-Type': 'application/json'}
    if api_key:
        hdrs['Authorization'] = f'Bearer {api_key}'
    try:
        body_payload = build_ollama_payload(model, payload, thinking=thinking, stream=False)
        logger.info(f"[ollama] Sending request to {url} with {len(body_payload.get('tools', []))} tools")
        req = urllib.request.Request(url, data=json.dumps(body_payload).encode(), headers=hdrs)
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_SECONDS) as resp:
            body = json.loads(resp.read())
        message = body.get('message', {}) or {}
        text = sanitize_visible_output(message.get('content', '') or '')
        raw_tool_calls = message.get('tool_calls')
        logger.info(f"[ollama] Response tool_calls: {raw_tool_calls}")
        tool_calls = normalize_tool_calls(raw_tool_calls)
        leak_reason = reject_visible_tool_call_leak(payload, text, tool_calls)
        if leak_reason:
            logger.warning(f"Ollama {base_url} {model}: {leak_reason}")
            return False, leak_reason
        finish_reason = 'tool_calls' if tool_calls else (body.get('done_reason') or 'stop')
        return True, build_openai_completion(provider_name, model, request_id, text, tool_calls, finish_reason, {'prompt_tokens': 0, 'completion_tokens': 0}, debug_mode=debug_mode, allow_debug_prefix=payload.get('response_format', {}).get('type') != 'json_object', suppress_tool_call_content=bool((payload.get('requirements') or {}).get('suppressToolCallContent') or payload.get('suppressToolCallContent') or payload.get('suppressIntermediateToolText')))
    except Exception as e:
        err = extract_http_error(e)
        if is_cloud_ollama_model(model) and 'HTTP 401' in err:
            prov = PROVIDERS.get(provider_name)
            if prov and is_local_ollama_provider(prov):
                set_local_ollama_cloud_auth_block(provider_name, seconds=int(os.environ.get('SAGE_ROUTER_OLLAMA_CLOUD_AUTH_COOLDOWN_SECONDS', '3600')))
                logger.warning(f"Ollama Cloud auth unavailable for local provider {provider_name}; suppressing local :cloud routing temporarily")
        logger.warning(f"Ollama {base_url} {model}: {err}")
        return False, err


def call_ollama_ocr(base_url, model, payload, request_id):
    url = base_url.rstrip("/") + "/api/generate"
    messages = payload.get("messages", [])
    prompt = "Extract all text from this image."
    images = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            if content.startswith("http"):
                import base64
                try:
                    img_data = urllib.request.urlopen(content, timeout=30).read()
                    images.append(base64.b64encode(img_data).decode())
                except: pass
            else:
                prompt = content
        elif isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text":
                        prompt = item.get("text", prompt)
                    elif item.get("type") == "image_url":
                        img_url = item.get("image_url", {}).get("url", "")
                        if img_url.startswith("http"):
                            import base64
                            try:
                                img_data = urllib.request.urlopen(img_url, timeout=30).read()
                                images.append(base64.b64encode(img_data).decode())
                            except: pass
    req_payload = {"model": model, "prompt": prompt, "images": images if images else None, "stream": False}
    try:
        data = json.dumps(req_payload).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = json.loads(resp.read())
        text = sanitize_visible_output(body.get("response", ""))
        if text:
            return True, build_openai_completion("ollama", model, request_id, text, [], "stop", {"prompt_tokens": 0, "completion_tokens": 0})
        return False, "Empty OCR response"
    except Exception as e:
        return False, extract_http_error(e)


def call_ngc(base_url, model, payload, api_key='', request_id=''):
    url = openai_chat_completions_url(base_url)
    messages = payload.get('messages', [])
    headers = {'Content-Type': 'application/json', 'Authorization': f'Bearer {api_key}'}
    req_payload = {'model': model, 'messages': messages, 'max_tokens': 4096}
    try:
        data = json.dumps(req_payload).encode()
        req = urllib.request.Request(url, data=data, headers=headers)
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = json.loads(resp.read())
        text = body.get('choices', [{}])[0].get('message', {}).get('content', '')
        if text:
            return True, build_openai_completion('nvidia-ngc', model, request_id, text, [], 'stop', {'prompt_tokens': 0, 'completion_tokens': 0})
        return False, 'Empty NGC response'
    except Exception as e:
        return False, extract_http_error(e)


def call_anthropic_completion(base_url, model, payload, api_key='', thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, debug_mode=False, request_id='', provider_name='anthropic'):
    url = base_url.rstrip('/') + '/v1/messages'
    system_text, api_msgs = openai_messages_to_anthropic(payload.get('messages', []))
    request_payload = {'model': model, 'max_tokens': thinking_max_tokens(thinking), 'messages': api_msgs}
    tools = openai_tools_to_anthropic(payload.get('tools'))
    if tools:
        request_payload['tools'] = tools
        tool_choice = payload.get('tool_choice')
        if isinstance(tool_choice, dict) and tool_choice.get('type') == 'function':
            request_payload['tool_choice'] = {'type': 'tool', 'name': ((tool_choice.get('function') or {}).get('name'))}
        elif tool_choice == 'required':
            request_payload['tool_choice'] = {'type': 'any'}
    if supports_reasoning and thinking == ThinkingLevel.HIGH:
        request_payload['thinking'] = {'type': 'enabled', 'budget_tokens': 4096}
    if payload.get('response_format', {}).get('type') == 'json_object':
        api_msgs.append({'role': 'user', 'content': [{'type': 'text', 'text': 'Return valid JSON only.'}]})
    if system_text:
        request_payload['system'] = system_text
    try:
        hdrs = {'Content-Type': 'application/json', 'anthropic-version': '2023-06-01'}
        if api_key:
            hdrs['x-api-key'] = api_key
        req = urllib.request.Request(url, data=json.dumps(request_payload).encode(), headers=hdrs)
        with urllib.request.urlopen(req, timeout=ANTHROPIC_TIMEOUT_SECONDS) as resp:
            body = json.loads(resp.read())
        text, tool_calls, stop_reason, usage = parse_anthropic_response(body)
        finish_reason = 'tool_calls' if tool_calls or stop_reason == 'tool_use' else 'stop'
        return True, build_openai_completion(provider_name, model, request_id, text, tool_calls, finish_reason, usage, debug_mode=debug_mode, allow_debug_prefix=payload.get('response_format', {}).get('type') != 'json_object', suppress_tool_call_content=bool((payload.get('requirements') or {}).get('suppressToolCallContent') or payload.get('suppressToolCallContent') or payload.get('suppressIntermediateToolText')))
    except Exception as e:
        err = extract_http_error(e)
        logger.warning(f"Anthropic {base_url} {model}: {err}")
        return False, err


def call_google_completion(base_url, model, payload, api_key='', thinking=ThinkingLevel.MEDIUM, debug_mode=False, request_id=''):
    ok, text = call_google(base_url, model, payload.get('messages', []), api_key=api_key, thinking=thinking, want_json=payload.get('response_format', {}).get('type') == 'json_object')
    if not ok:
        return False, text
    return True, build_openai_completion('google', model, request_id, text, [], 'stop', {'prompt_tokens': 0, 'completion_tokens': 0}, debug_mode=debug_mode, allow_debug_prefix=payload.get('response_format', {}).get('type') != 'json_object', suppress_tool_call_content=bool((payload.get('requirements') or {}).get('suppressToolCallContent') or payload.get('suppressToolCallContent') or payload.get('suppressIntermediateToolText')))


def stream_openai_compat_to_client(self, provider, model, payload, request_id, thinking=ThinkingLevel.MEDIUM, supports_reasoning=False, debug_mode=False):
    url = openai_chat_completions_url(provider.base_url)
    proxied = build_openai_proxy_payload(payload, model, stream=True, supports_reasoning=supports_reasoning, thinking=thinking)
    hdrs = {'Content-Type': 'application/json'}
    add_openai_compat_headers(hdrs, provider.name)
    if provider.api_key:
        hdrs['Authorization'] = f'Bearer {provider.api_key}'
    req = urllib.request.Request(url, data=json.dumps(proxied).encode(), headers=hdrs)
    with urllib.request.urlopen(req, timeout=OPENAI_COMPAT_TIMEOUT_SECONDS) as resp:
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-cache')
        for key, value in self.routing_headers({'model': f'{provider.name}/{model}'}, request_id).items():
            if value:
                self.send_header(key, str(value))
        self.end_headers()
        if debug_mode and not payload.get('tools') and payload.get('response_format', {}).get('type') != 'json_object':
            debug_chunk = json.dumps({
                'id': f'chatcmpl-{int(time.time())}',
                'object': 'chat.completion.chunk',
                'created': int(time.time()),
                'model': f'{provider.name}/{model}',
                'choices': [{'index': 0, 'delta': {'role': 'assistant', 'content': f'[sage-router {provider.name}/{model}]\n'}, 'finish_reason': None}],
            })
            self.wfile.write(f'data: {debug_chunk}\n\n'.encode())
            self.wfile.flush()
        while True:
            line = resp.readline()
            if not line:
                break
            self.wfile.write(line)
            self.wfile.flush()
    return True


def stream_ollama_to_client(self, provider, model, payload, request_id, thinking=ThinkingLevel.MEDIUM, debug_mode=False):
    url = provider.base_url.rstrip('/') + '/api/chat'
    hdrs = {'Content-Type': 'application/json'}
    if provider.api_key:
        hdrs['Authorization'] = f'Bearer {provider.api_key}'
    req = urllib.request.Request(url, data=json.dumps(build_ollama_payload(model, payload, thinking=thinking, stream=True)).encode(), headers=hdrs)
    chat_id = f'chatcmpl-{int(time.time())}'
    router_model = f'{provider.name}/{model}'
    sent_role = False
    with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_SECONDS) as resp:
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-cache')
        for key, value in self.routing_headers({'model': router_model}, request_id).items():
            if value:
                self.send_header(key, str(value))
        self.end_headers()
        if debug_mode and not payload.get('tools') and payload.get('response_format', {}).get('type') != 'json_object':
            debug_chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()), 'model': router_model, 'choices': [{'index': 0, 'delta': {'role': 'assistant', 'content': f'[sage-router {provider.name}/{model}]\n'}, 'finish_reason': None}]})
            self.wfile.write(f'data: {debug_chunk}\n\n'.encode())
            self.wfile.flush()
            sent_role = True
        while True:
            raw = resp.readline()
            if not raw:
                break
            line = raw.decode('utf-8', errors='replace').strip()
            if not line:
                continue
            body = json.loads(line)
            message = body.get('message', {}) or {}
            content = sanitize_visible_output(message.get('content', '') or '')
            tool_calls = normalize_tool_calls(message.get('tool_calls'))
            if content:
                delta = {'content': content}
                if not sent_role:
                    delta['role'] = 'assistant'
                    sent_role = True
                chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()), 'model': router_model, 'choices': [{'index': 0, 'delta': delta, 'finish_reason': None}]})
                self.wfile.write(f'data: {chunk}\n\n'.encode())
                self.wfile.flush()
            if tool_calls:
                delta = {'tool_calls': tool_calls}
                if not sent_role:
                    delta['role'] = 'assistant'
                    sent_role = True
                chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()), 'model': router_model, 'choices': [{'index': 0, 'delta': delta, 'finish_reason': None}]})
                self.wfile.write(f'data: {chunk}\n\n'.encode())
                self.wfile.flush()
            if body.get('done'):
                finish_reason = 'tool_calls' if tool_calls else (body.get('done_reason') or 'stop')
                done_chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()), 'model': router_model, 'choices': [{'index': 0, 'delta': {}, 'finish_reason': finish_reason}]})
                self.wfile.write(f'data: {done_chunk}\n\n'.encode())
                self.wfile.write(b'data: [DONE]\n\n')
                self.wfile.flush()
                break
    return True


def stream_google_to_client(self, provider, model, payload, request_id, thinking=ThinkingLevel.MEDIUM, debug_mode=False):
    """Stream Google Generative AI responses via SSE."""
    base_url = provider.base_url
    # Ensure base_url has /v1beta for Google API
    if 'generativelanguage.googleapis.com' in base_url and '/v1beta' not in base_url:
        base_url = base_url.rstrip('/') + '/v1beta'
    
    # Build URL with API key as query param (required for streaming)
    api_key_param = f"?key={urllib.parse.quote(provider.api_key)}" if provider.api_key else ""
    url = base_url.rstrip('/') + f'/models/{urllib.parse.quote(model, safe="")}:streamGenerateContent' + api_key_param
    
    # Build Google payload from OpenAI messages
    system_text = ''
    contents = []
    for msg in payload.get('messages', []):
        role = msg.get('role', 'user')
        content = msg.get('content', '')
        if not content:
            continue
        if role in ('system', 'developer'):
            system_text += content + '\n'
            continue
        if role == 'assistant':
            gemini_role = 'model'
        else:
            gemini_role = 'user'
        part = {'text': content}
        if contents and contents[-1].get('role') == gemini_role:
            contents[-1].setdefault('parts', []).append(part)
        else:
            contents.append({'role': gemini_role, 'parts': [part]})
    
    if contents and contents[0].get('role') != 'user':
        contents.insert(0, {'role': 'user', 'parts': [{'text': 'Hello'}]})
    if not contents:
        contents = [{'role': 'user', 'parts': [{'text': 'Hello'}]}]
    
    google_payload = {
        'contents': contents,
        'generationConfig': {'maxOutputTokens': thinking_max_tokens(thinking)},
    }
    if system_text.strip():
        google_payload['systemInstruction'] = {'parts': [{'text': system_text.strip()}]}
    
    # API key is in URL query param for streaming
    req = urllib.request.Request(url, data=json.dumps(google_payload).encode(), headers={'Content-Type': 'application/json'})
    chat_id = f'chatcmpl-{int(time.time())}'
    router_model = f'{provider.name}/{model}'
    
    with urllib.request.urlopen(req, timeout=GOOGLE_TIMEOUT_SECONDS) as resp:
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-cache')
        for key, value in self.routing_headers({'model': router_model}, request_id).items():
            if value:
                self.send_header(key, str(value))
        self.end_headers()
        
        if debug_mode:
            debug_chunk = json.dumps({
                'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()),
                'model': router_model,
                'choices': [{'index': 0, 'delta': {'role': 'assistant', 'content': f'[sage-router {provider.name}/{model}]\n'}, 'finish_reason': None}],
            })
            self.wfile.write(f'data: {debug_chunk}\n\n'.encode())
            self.wfile.flush()
        
        sent_role = False
        for line in resp:
            if not line:
                continue
            line_str = line.decode('utf-8', errors='replace').strip()
            if not line_str:
                continue
            try:
                chunk = json.loads(line_str)
                candidates = chunk.get('candidates', [])
                if candidates:
                    content_parts = candidates[0].get('content', {}).get('parts', [])
                    text = ''.join(p.get('text', '') for p in content_parts if p.get('text'))
                    if text:
                        delta = {'content': text}
                        if not sent_role:
                            delta['role'] = 'assistant'
                            sent_role = True
                        sse_chunk = json.dumps({
                            'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()),
                            'model': router_model,
                            'choices': [{'index': 0, 'delta': delta, 'finish_reason': None}],
                        })
                        self.wfile.write(f'data: {sse_chunk}\n\n'.encode())
                        self.wfile.flush()
                    
                    finish_reason_str = candidates[0].get('finishReason')
                    if finish_reason_str:
                        done_chunk = json.dumps({
                            'id': chat_id, 'object': 'chat.completion.chunk', 'created': int(time.time()),
                            'model': router_model,
                            'choices': [{'index': 0, 'delta': {}, 'finish_reason': 'stop'}],
                        })
                        self.wfile.write(f'data: {done_chunk}\n\n'.encode())
                        self.wfile.write(b'data: [DONE]\n\n')
                        self.wfile.flush()
                        break
            except json.JSONDecodeError:
                continue
    return True


def write_openai_completion_as_sse(self, result, request_id):
    chat_id = result.get('id') or f'chatcmpl-{int(time.time())}'
    model = result.get('model') or 'sage-router/auto'
    created = int(result.get('created') or time.time())
    choice = (result.get('choices') or [{}])[0] or {}
    message = choice.get('message') or {}
    content = message.get('content') or ''
    tool_calls = message.get('tool_calls') or []
    self.send_response(200)
    self.send_header('Content-Type', 'text/event-stream')
    self.send_header('Cache-Control', 'no-cache')
    for key, value in self.routing_headers(result, request_id).items():
        if value:
            self.send_header(key, str(value))
    self.end_headers()
    if content:
        chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': created, 'model': model, 'choices': [{'index': 0, 'delta': {'role': 'assistant', 'content': content}, 'finish_reason': None}]})
        self.wfile.write(f'data: {chunk}\n\n'.encode())
    if tool_calls:
        chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': created, 'model': model, 'choices': [{'index': 0, 'delta': {'role': 'assistant', 'tool_calls': tool_calls}, 'finish_reason': None}]})
        self.wfile.write(f'data: {chunk}\n\n'.encode())
    finish_reason = 'tool_calls' if tool_calls else (choice.get('finish_reason') or 'stop')
    done_chunk = json.dumps({'id': chat_id, 'object': 'chat.completion.chunk', 'created': created, 'model': model, 'choices': [{'index': 0, 'delta': {}, 'finish_reason': finish_reason}]})
    self.wfile.write(f'data: {done_chunk}\n\n'.encode())
    self.wfile.write(b'data: [DONE]\n\n')
    self.wfile.flush()

def handle_openai_chat_completions(self, payload, request_id, started, force_realtime=False):
    message_count = len(payload.get('messages', []) or [])
    router_profile = apply_router_profile(payload)
    discord_public_profile = apply_discord_public_route_profile(payload)
    thinking = normalize_thinking(payload.get('thinking') or payload.get('reasoning'))
    route_mode = normalize_route_mode(payload.get('route'))
    if force_realtime:
        route_mode = 'realtime'
        thinking = ThinkingLevel.LOW  # Force low thinking for speed
    requirements = normalize_requirements(payload, thinking)
    want_json = str(payload.get('responseFormat') or '').lower() == 'json' or payload.get('response_format', {}).get('type') == 'json_object'
    client_wants_stream = bool(payload.get('stream', False))
    # Buffer provider responses and synthesize SSE for client streaming. This preserves fallback/empty-output detection even when OpenClaw streams with tools.
    want_stream = False
    debug_mode = normalize_debug_mode(payload)
    logger.info(f"[{request_id}] Incoming /v1/chat/completions with {message_count} messages, thinking={thinking.value}, route={route_mode}, json={want_json}, requirements={requirements}, routerProfile={router_profile}, discordPublicProfile={discord_public_profile}, debug={debug_mode}")

    # Parse provider from model field (e.g., "openai-codex/gpt-5.5")
    _fp = payload.get('provider')
    _rm = payload.get('model')
    if '/' in str(_rm):
        _parts = str(_rm).split('/', 1)
        _pp = _parts[0]
        if not _fp and _pp in PROVIDERS and _pp not in DISABLED_PROVIDERS:
            _fp = _pp
        _rm = _parts[1]
    normalized_messages, intent, complexity, estimated_tokens, chain = prepare_route(
        payload.get('messages', []),
        request_id=request_id,
        thinking=thinking,
        route_mode=route_mode,
        requirements=requirements,
        want_json=want_json,
        streaming_mode='native-pass-through' if want_stream else 'disabled',
        force_provider=_fp,
        requested_model=_rm,
    )

    provider_payload = payload
    # For document/text extraction requests, send provider-compatible text instead of raw
    # attachment blocks. Native image/vision requests keep the original multimodal payload.
    if requirements.get('document') and not requirements.get('vision'):
        provider_payload = dict(payload)
        provider_payload['messages'] = enrich_document_messages(payload.get('messages', []))

    attempts = []
    overall_started = time.time()
    for pn, model in chain:
        if pn in DISABLED_PROVIDERS or pn not in PROVIDERS:
            continue
        prov = PROVIDERS[pn]
        if model_disabled_reason(pn, model):
            continue
        supports_reasoning = provider_supports_reasoning(prov, model)
        attempt_payload = provider_payload
        if provider_payload.get('tools') and not model_capabilities(prov, model).get('tools'):
            attempt_payload = dict(provider_payload)
            attempt_payload.pop('tools', None)
            attempt_payload.pop('tool_choice', None)
        logger.info(f"[{request_id}] Trying {pn}/{model} (api={prov.api_type}, reasoning={supports_reasoning}, stream={want_stream}, tools={bool(attempt_payload.get('tools'))})")
        started_attempt = time.time()
        ok = False
        result = None
        error_detail = None
        try:
            if prov.api_type == 'openai-completions':
                if want_stream:
                    stream_openai_compat_to_client(self, prov, model, attempt_payload, request_id, thinking=thinking, supports_reasoning=supports_reasoning, debug_mode=debug_mode)
                    ok = True
                else:
                    ok, result = call_openai_compat_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, provider_name=pn, thinking=thinking, supports_reasoning=supports_reasoning, debug_mode=debug_mode, request_id=request_id)
                    if not ok:
                        error_detail = result
            elif prov.api_type == 'ollama':
                if is_ocr_model(model):
                    ok, result = call_ollama_ocr(prov.base_url, model, attempt_payload, request_id)
                    if not ok:
                        error_detail = result
                elif want_stream:
                    stream_ollama_to_client(self, prov, model, attempt_payload, request_id, thinking=thinking, debug_mode=debug_mode)
                    ok = True
                else:
                    ok, result = call_ollama_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, thinking=thinking, provider_name=pn, debug_mode=debug_mode, request_id=request_id)
                    if not ok:
                        error_detail = result
            elif prov.api_type == 'anthropic-messages':
                if want_stream:
                    error_detail = 'streaming passthrough not implemented for anthropic bridge'
                else:
                    ok, result = call_anthropic_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, thinking=thinking, supports_reasoning=supports_reasoning, debug_mode=debug_mode, request_id=request_id, provider_name=pn)
                    if not ok:
                        error_detail = result
            elif prov.api_type == 'google-generative-language':
                if want_stream:
                    stream_google_to_client(self, prov, model, attempt_payload, request_id, thinking=thinking, debug_mode=debug_mode)
                    ok = True
                else:
                    ok, result = call_google_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, thinking=thinking, debug_mode=debug_mode, request_id=request_id)
                    if not ok:
                        error_detail = result
            elif prov.api_type == 'openai-codex-responses':
                if want_stream:
                    error_detail = 'streaming not implemented for Codex responses'
                else:
                    ok, result = call_codex_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, provider_name=pn, thinking=thinking, supports_reasoning=supports_reasoning, debug_mode=debug_mode, request_id=request_id)
                    if not ok:
                        error_detail = result
            elif prov.api_type == 'openclaw-gateway':
                if want_stream or attempt_payload.get('tools'):
                    error_detail = 'streaming/tool passthrough unsupported for openclaw gateway bridge'
                else:
                    ok_text, text = call_openclaw_gateway(model, attempt_payload.get('messages', []), pn, thinking, want_json)
                    ok = ok_text
                    if ok:
                        result = build_openai_completion(pn, model, request_id, text, [], 'stop', {'prompt_tokens': 0, 'completion_tokens': 0}, debug_mode=debug_mode, allow_debug_prefix=not want_json)
                    else:
                        error_detail = text
            else:
                if want_stream:
                    error_detail = f'streaming passthrough unsupported for {prov.api_type}'
                else:
                    ok, result = call_openai_compat_completion(prov.base_url, model, attempt_payload, api_key=prov.api_key, provider_name=pn, thinking=thinking, supports_reasoning=supports_reasoning, debug_mode=debug_mode, request_id=request_id)
                    if not ok:
                        error_detail = result
        except Exception as e:
            error_detail = extract_http_error(e)
            logger.warning(f"[{request_id}] Streaming/advanced call failed for {pn}/{model}: {error_detail}")
            ok = False

        if ok and not want_stream and not openai_completion_has_visible_output(result):
            ok = False
            error_detail = 'empty visible content'
        elapsed = time.time() - started_attempt
        record_latency_outcome(intent.name, pn, model, elapsed, ok, '' if ok else error_detail or '')
        attempts.append({'provider': pn, 'model': model, 'ok': ok, 'elapsedMs': round(elapsed * 1000.0, 2), 'detail': '' if ok else str(error_detail or '')[:240]})
        LAST_ROUTE_DEBUG['attempts'] = attempts[-12:]
        if ok:
            total_elapsed = time.time() - overall_started
            LAST_ROUTE_DEBUG.update({'selected': {'provider': pn, 'model': model}, 'status': 'ok', 'error': None, 'totalElapsedMs': round(total_elapsed * 1000.0, 2)})
            append_route_event({'request_id': request_id, 'status': 'ok', 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'estimatedTokens': estimated_tokens, 'json': want_json, 'stream': bool(want_stream), 'requirements': requirements, 'selected': {'provider': pn, 'model': model}, 'attempts': attempts[-12:], 'totalElapsedMs': round(total_elapsed * 1000.0, 2), 'chain': [{'provider': cp, 'model': cm} for cp, cm in chain[:MAX_PROVIDER_ATTEMPTS]]})
            logger.info(f"[{request_id}] OK: {pn}/{model} (provider={elapsed:.2f}s, total={total_elapsed:.2f}s, stream={want_stream})")
            if client_wants_stream:
                write_openai_completion_as_sse(self, result, request_id)
                return
            self.write_json(200, result, extra_headers=self.routing_headers(result, request_id))
            logger.info(f"[{request_id}] Responded in {time.time() - started:.2f}s")
            return
        logger.warning(f"[{request_id}] Failed {pn}/{model} after {elapsed:.2f}s")

    total_elapsed = time.time() - overall_started
    LAST_ROUTE_DEBUG.update({'selected': None, 'attempts': attempts[-12:], 'status': 'failed', 'error': 'All providers failed', 'totalElapsedMs': round(total_elapsed * 1000.0, 2)})
    append_route_event({'request_id': request_id, 'status': 'failed', 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'estimatedTokens': estimated_tokens, 'json': want_json, 'stream': bool(want_stream), 'requirements': requirements, 'selected': None, 'attempts': attempts[-12:], 'totalElapsedMs': round(total_elapsed * 1000.0, 2), 'chain': [{'provider': cp, 'model': cm} for cp, cm in chain[:MAX_PROVIDER_ATTEMPTS]], 'error': 'All providers failed'})
    self.write_json(503, {'error': 'All providers failed', 'request_id': request_id, 'attempts': attempts, 'choices': [{'message': {'content': 'Error: No providers available'}}]}, extra_headers={'X-Sage-Router-Request-Id': request_id})

def google_to_openai_messages(payload):
    """Convert Google Generative AI request format to OpenAI messages format."""
    messages = []
    system_instruction = payload.get('systemInstruction', {})
    if system_instruction:
        sys_parts = system_instruction.get('parts', [])
        sys_text = ' '.join(p.get('text', '') for p in sys_parts if isinstance(p, dict))
        if sys_text.strip():
            messages.append({'role': 'system', 'content': sys_text.strip()})
    for content in payload.get('contents', []):
        role = content.get('role', 'user')
        parts = content.get('parts', [])
        text_parts = [p.get('text', '') for p in parts if isinstance(p, dict) and p.get('text')]
        combined = '\n'.join(text_parts)
        if combined.strip():
            oai_role = 'assistant' if role == 'model' else 'user'
            messages.append({'role': oai_role, 'content': combined})
    return messages or [{'role': 'user', 'content': 'Hello'}]


def openai_to_google_response(result, request_model):
    """Convert OpenAI chat completion response to Google Generative AI format."""
    content = result.get('choices', [{}])[0].get('message', {}).get('content', '') or ''
    model = result.get('model', request_model or 'sage-router/auto')
    usage = result.get('usage', {})
    return {
        'candidates': [{
            'content': {
                'parts': [{'text': content}],
                'role': 'model'
            },
            'finishReason': 'STOP',
            'index': 0
        }],
        'modelVersion': model,
        'usageMetadata': {
            'promptTokenCount': usage.get('prompt_tokens', 0),
            'candidatesTokenCount': usage.get('completion_tokens', 0),
            'totalTokenCount': usage.get('prompt_tokens', 0) + usage.get('completion_tokens', 0)
        }
    }


def prepare_route(messages, request_id='req-unknown', thinking=ThinkingLevel.MEDIUM, route_mode='balanced', requirements=None, want_json=False, streaming_mode=None, force_provider=None, requested_model=None):
    normalized_messages = normalize_messages(messages)
    estimated_tokens = estimate_prompt_tokens(normalized_messages)
    user_text = latest_user_text(normalized_messages)
    intent, _ = classify_intent(user_text)
    complexity = estimate_complexity(user_text)
    requirements = requirements or {}
    logger.info(f"[{request_id}] Intent: {intent.name}, Complexity: {complexity.name}, Thinking: {thinking.value}, Route: {route_mode}, JSON: {want_json}, EstTokens: {estimated_tokens}, ForceProvider: {force_provider or 'none'}")
    
    # If provider forced, build chain with only that provider's models
    if force_provider and force_provider in PROVIDERS and force_provider not in DISABLED_PROVIDERS:
        prov = PROVIDERS[force_provider]
        if route_mode == 'local-first' and not provider_allowed_in_local_first(prov):
            rejections = [{'provider': force_provider, 'model': requested_model or '*', 'reason': local_first_rejection_reason(prov)}]
            LAST_ROUTE_DEBUG.update({'updated_at': int(time.time()), 'request_id': request_id, 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'requirements': requirements, 'estimatedTokens': estimated_tokens, 'json': want_json, 'chain': [], 'scores': [], 'rejections': rejections[:30], 'selected': None, 'attempts': [], 'streaming': streaming_mode or ('buffered-wrapper' if requirements.get('streaming') else 'disabled'), 'status': 'routing', 'error': 'forced provider rejected by local-first', 'totalElapsedMs': None, 'forcedProvider': force_provider})
            return normalized_messages, intent, complexity, estimated_tokens, []
        if prov.api_type == 'ollama':
            fetch_ollama_models(prov)
        if prov.models and provider_endpoint_reachable(prov):
            # Build chain, prioritizing the requested model if specified
            all_models = dedupe_keep_order(prov.models)
            if requested_model and requested_model not in all_models:
                # For Google and other API providers, allow any model name (passthrough)
                if prov.api_type in ('google-generative-language', 'google-generative-ai'):
                    chain = [(force_provider, requested_model)]
                    logger.info(f"[{request_id}] Chain (Google passthrough): {chain}")
                    LAST_ROUTE_DEBUG.update({'updated_at': int(time.time()), 'request_id': request_id, 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'requirements': requirements, 'estimatedTokens': estimated_tokens, 'json': want_json, 'chain': chain, 'scores': [{'provider': force_provider, 'model': requested_model, 'score': 100}], 'rejections': [], 'selected': None, 'attempts': [], 'streaming': streaming_mode or ('buffered-wrapper' if requirements.get('streaming') else 'disabled'), 'status': 'routing', 'error': None, 'totalElapsedMs': None, 'forcedProvider': force_provider, 'passthrough': True})
                    return normalized_messages, intent, complexity, estimated_tokens, chain
                # Otherwise prepend requested model if not in list
                all_models = [requested_model] + all_models
            elif requested_model and requested_model in all_models:
                # Move requested model to front if it exists
                all_models = [requested_model] + [m for m in all_models if m != requested_model]
            filtered_models = []
            forced_rejections = []
            for model in all_models:
                disabled_reason = model_disabled_reason(prov.name, model)
                if disabled_reason:
                    forced_rejections.append({'provider': force_provider, 'model': model, 'reason': disabled_reason})
                    continue
                if route_mode == 'local-first' and prov.api_type == 'ollama' and is_cloud_ollama_model(model):
                    forced_rejections.append({'provider': force_provider, 'model': model, 'reason': 'excluded by local-first (:cloud model)'})
                    continue
                if not is_chat_capable_model(prov, model):
                    forced_rejections.append({'provider': force_provider, 'model': model, 'reason': 'not chat-capable'})
                    continue
                ok_req, reason = model_meets_requirements(prov, model, requirements, estimated_tokens)
                if not ok_req:
                    forced_rejections.append({'provider': force_provider, 'model': model, 'reason': reason})
                    continue
                filtered_models.append(model)
            chain = [(force_provider, model) for model in filtered_models[:MAX_PROVIDER_ATTEMPTS]]
            score_debug = [{'provider': force_provider, 'model': model, 'score': 100} for _, model in chain]
            rejections = forced_rejections
            logger.info(f"[{request_id}] Chain (forced): {chain}")
            LAST_ROUTE_DEBUG.update({'updated_at': int(time.time()), 'request_id': request_id, 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'requirements': requirements, 'estimatedTokens': estimated_tokens, 'json': want_json, 'chain': chain, 'scores': score_debug, 'rejections': rejections[:30], 'selected': None, 'attempts': [], 'streaming': streaming_mode or ('buffered-wrapper' if requirements.get('streaming') else 'disabled'), 'status': 'routing', 'error': None, 'totalElapsedMs': None, 'forcedProvider': force_provider})
            return normalized_messages, intent, complexity, estimated_tokens, chain
    
    chain, score_debug, rejections = select_model(intent, complexity, thinking, route_mode, requirements, estimated_tokens)
    LAST_ROUTE_DEBUG.update({'updated_at': int(time.time()), 'request_id': request_id, 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'requirements': requirements, 'estimatedTokens': estimated_tokens, 'json': want_json, 'chain': chain, 'scores': score_debug[:12], 'rejections': rejections[:30], 'selected': None, 'attempts': [], 'streaming': streaming_mode or ('buffered-wrapper' if requirements.get('streaming') else 'disabled'), 'status': 'routing', 'error': None, 'totalElapsedMs': None})
    logger.info(f"[{request_id}] Chain: {chain} (no mid-stream switching; each candidate tried sequentially until one succeeds)")
    return normalized_messages, intent, complexity, estimated_tokens, chain


def handle_google_generate(self, body, request_id, started, model_name, want_stream=False):
    """Handle Google Generative AI /v1beta/models/{model}:generateContent requests."""
    try:
        payload = json.loads(body or b'{}')
        messages = google_to_openai_messages(payload)
        gen_config = payload.get('generationConfig', {})
        want_json = gen_config.get('responseMimeType') == 'application/json'
        thinking = normalize_thinking(payload.get('thinking'))
        route_mode = normalize_route_mode(payload.get('route'))
        requirements = normalize_requirements(payload, thinking)

        logger.info(f'[{request_id}] Google compat {model_name} with {len(messages)} messages, stream={want_stream}')
        result = route_request(messages, request_id=request_id, thinking=thinking, route_mode=route_mode, requirements=requirements, want_json=want_json)

        is_error = isinstance(result, dict) and result.get('error')
        if is_error:
            self.write_json(503, {
                'error': {
                    'code': 503,
                    'message': result.get('error', 'Internal error'),
                    'status': 'UNAVAILABLE'
                }
            }, extra_headers=self.routing_headers(result, request_id))
        elif want_stream:
            content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            model = result.get('model', model_name or 'sage-router/auto')
            # Google streaming format - SSE with chunked candidates
            sse_body = ''
            # Initial chunk with metadata
            chunk = json.dumps({'candidates': [{'content': {'parts': [{'text': content}], 'role': 'model'}, 'finishReason': 'STOP', 'index': 0}], 'modelVersion': model})
            sse_body += f'data: {chunk}\n\n'
            sse_body += 'data: [DONE]\n\n'
            sse_bytes = sse_body.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Content-Length', str(len(sse_bytes)))
            for key, value in self.routing_headers(result, request_id).items():
                if value:
                    self.send_header(key, str(value))
            self.end_headers()
            self.wfile.write(sse_bytes)
            self.wfile.flush()
        else:
            google_resp = openai_to_google_response(result, model_name)
            self.write_json(200, google_resp, extra_headers=self.routing_headers(result, request_id))
        logger.info(f'[{request_id}] Google compat responded in {time.time() - started:.2f}s')
    except Exception as e:
        logger.exception(f'[{request_id}] Google compat request failed')
        self.write_json(500, {
            'error': {'code': 500, 'message': str(e), 'status': 'INTERNAL'}
        }, extra_headers={'X-Sage-Router-Request-Id': request_id})


    for msg in reversed(messages or []):
        if msg.get('role') == 'user' and msg.get('content'):
            return msg.get('content', '')
    return messages[-1].get('content', '') if messages else ''


def latest_user_text(messages):
    for msg in reversed(messages or []):
        if msg.get('role') == 'user' and msg.get('content'):
            return msg.get('content', '')
    return messages[-1].get('content', '') if messages else ''


def route_request(messages, request_id='req-unknown', thinking=ThinkingLevel.MEDIUM, route_mode='balanced', requirements=None, want_json=False):
    requirements = requirements or {}
    normalized_messages, intent, complexity, estimated_tokens, chain = prepare_route(
        messages,
        request_id=request_id,
        thinking=thinking,
        route_mode=route_mode,
        requirements=requirements,
        want_json=want_json,
        streaming_mode='buffered-wrapper' if requirements.get('streaming') else 'disabled',
    )
    overall_started = time.time()
    attempts = []
    for pn, model in chain:
        if pn in DISABLED_PROVIDERS:
            continue
        if pn not in PROVIDERS:
            continue
        prov = PROVIDERS[pn]
        supports_reasoning = provider_supports_reasoning(prov, model)
        logger.info(f"[{request_id}] Trying {pn}/{model} (api={prov.api_type}, reasoning={supports_reasoning})")
        started = time.time()
        if prov.api_type == 'ollama':
            ok, text = call_ollama(prov.base_url, model, normalized_messages, prov.api_key, thinking)
        elif prov.api_type == 'openclaw-gateway':
            gateway_timeout = OPENCLAW_GATEWAY_CODE_TIMEOUT_SECONDS if intent == Intent.CODE else OPENCLAW_GATEWAY_TIMEOUT_SECONDS
            ok, text = call_openclaw_gateway(model, normalized_messages, pn, thinking, want_json, gateway_timeout)
        elif prov.api_type == 'anthropic-messages':
            ok, text = call_anthropic(prov.base_url, model, normalized_messages, prov.api_key, thinking, supports_reasoning, want_json)
        elif prov.api_type == 'google-generative-language':
            ok, text = call_google(prov.base_url, model, normalized_messages, prov.api_key, thinking, want_json)
        else:
            ok, text = call_openai_compat(prov.base_url, model, normalized_messages, prov.api_key, pn, thinking, supports_reasoning, want_json)
        elapsed = time.time() - started
        record_latency_outcome(intent.name, pn, model, elapsed, ok, '' if ok else text)
        attempts.append({'provider': pn, 'model': model, 'ok': ok, 'elapsedMs': round(elapsed * 1000.0, 2), 'detail': '' if ok else str(text)[:240]})
        LAST_ROUTE_DEBUG['attempts'] = attempts[-12:]
        if ok:
            total_elapsed = time.time() - overall_started
            logger.info(f"[{request_id}] OK: {pn}/{model} ({len(text)} chars, provider={elapsed:.2f}s, total={total_elapsed:.2f}s)")
            LAST_ROUTE_DEBUG.update({'selected': {'provider': pn, 'model': model}, 'status': 'ok', 'error': None, 'totalElapsedMs': round(total_elapsed * 1000.0, 2)})
            append_route_event({'request_id': request_id, 'status': 'ok', 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'estimatedTokens': estimated_tokens, 'json': want_json, 'stream': False, 'requirements': requirements, 'selected': {'provider': pn, 'model': model}, 'attempts': attempts[-12:], 'totalElapsedMs': round(total_elapsed * 1000.0, 2), 'chain': [{'provider': cp, 'model': cm} for cp, cm in chain[:MAX_PROVIDER_ATTEMPTS]]})
            return {"id": f"chatcmpl-{int(time.time())}", "object": "chat.completion", "created": int(time.time()), "model": f"{pn}/{model}", "choices": [{"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 0, "completion_tokens": 0}}
        logger.warning(f"[{request_id}] Failed {pn}/{model} after {elapsed:.2f}s")
    total_elapsed = time.time() - overall_started
    logger.error(f"[{request_id}] All providers failed after {total_elapsed:.2f}s")
    LAST_ROUTE_DEBUG.update({'selected': None, 'attempts': attempts[-12:], 'status': 'failed', 'error': 'All providers failed', 'totalElapsedMs': round(total_elapsed * 1000.0, 2)})
    append_route_event({'request_id': request_id, 'status': 'failed', 'intent': intent.name, 'complexity': complexity.name, 'thinking': thinking.value, 'routeMode': route_mode, 'estimatedTokens': estimated_tokens, 'json': want_json, 'stream': False, 'requirements': requirements, 'selected': None, 'attempts': attempts[-12:], 'totalElapsedMs': round(total_elapsed * 1000.0, 2), 'chain': [{'provider': cp, 'model': cm} for cp, cm in chain[:MAX_PROVIDER_ATTEMPTS]], 'error': 'All providers failed'})
    return {"error": "All providers failed", "request_id": request_id, "attempts": attempts, "choices": [{"message": {"content": "Error: No providers available"}}]}

def openai_to_anthropic_response(openai_resp, request_model=None):
    """Translate an OpenAI chat completion response to Anthropic Messages API format."""
    choice = (openai_resp.get('choices') or [{}])[0]
    content_text = choice.get('message', {}).get('content', '') or ''
    finish_reason = choice.get('finish_reason', 'stop')
    model = openai_resp.get('model', request_model or 'sage-router/auto')
    usage = openai_resp.get('usage', {})
    return {
        'id': f'msg_{uuid.uuid4().hex[:24]}',
        'type': 'message',
        'role': 'assistant',
        'content': [{'type': 'text', 'text': content_text}],
        'model': model,
        'stop_reason': 'end_turn' if finish_reason == 'stop' else finish_reason,
        'stop_sequence': None,
        'usage': {
            'input_tokens': usage.get('prompt_tokens', 0),
            'output_tokens': usage.get('completion_tokens', 0),
        },
    }


def anthropic_to_openai_request(anthropic_payload):
    """Translate an Anthropic Messages API request to OpenAI chat completions format."""
    messages = []
    # Anthropic system is a top-level field, not a message
    system_text = anthropic_payload.get('system', '')
    if isinstance(system_text, list):
        # Anthropic system can be a list of content blocks
        system_text = ' '.join(b.get('text', '') for b in system_text if isinstance(b, dict) and b.get('type') == 'text')
    if system_text:
        messages.append({'role': 'system', 'content': system_text})
    for msg in (anthropic_payload.get('messages') or []):
        role = msg.get('role', 'user')
        content = msg.get('content', '')
        # Anthropic content can be a list of content blocks
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict):
                    if block.get('type') == 'text':
                        parts.append(str(block.get('text', '')))
                    elif block.get('type') == 'tool_use':
                        parts.append(f'[Tool Use: {block.get("name", "unknown")}] {json.dumps(block.get("input", {}))}')
                    elif block.get('type') == 'tool_result':
                        result_content = block.get('content', '')
                        if isinstance(result_content, list):
                            result_content = ' '.join(b.get('text', '') for b in result_content if isinstance(b, dict) and b.get('type') == 'text')
                        parts.append(f'[Tool Result: {block.get("tool_use_id", "?")}] {result_content}')
                    elif block.get('type') == 'image' and block.get('source', {}).get('type') == 'base64':
                        parts.append('[Image attached]')
                elif isinstance(block, str):
                    parts.append(block)
            content = '\n'.join(parts)
        if role in ('user', 'assistant', 'system'):
            messages.append({'role': role, 'content': content})
        else:
            messages.append({'role': 'user', 'content': f'[{role.upper()}] {content}'})
    # Ensure first message is user or system
    if messages and messages[0]['role'] not in ('system', 'user'):
        messages.insert(0, {'role': 'user', 'content': 'Hello'})
    if not messages:
        messages = [{'role': 'user', 'content': 'Hello'}]
    return {
        'model': anthropic_payload.get('model', 'sage-router/auto'),
        'messages': messages,
        'max_tokens': anthropic_payload.get('max_tokens', 4096),
        'stream': False,
        'temperature': anthropic_payload.get('temperature', 1.0),
        'route': anthropic_payload.get('route'),
        'thinking': anthropic_payload.get('thinking'),
        'reasoning': anthropic_payload.get('reasoning'),
        'requirements': anthropic_payload.get('requirements'),
    }


def handle_anthropic_messages(self, body, request_id, started):
    """Handle POST /v1/messages - Anthropic Messages API compatibility.
    Translates request to OpenAI format, routes, translates response back."""
    try:
        anthropic_payload = json.loads(body or b'{}')
        request_model = anthropic_payload.get('model', 'sage-router/auto')
        want_stream = anthropic_payload.get('stream', False)
        openai_payload = anthropic_to_openai_request(anthropic_payload)
        message_count = len(openai_payload.get('messages', []))
        thinking = normalize_thinking(openai_payload.get('thinking') or openai_payload.get('reasoning'))
        router_profile = apply_router_profile(openai_payload)
        discord_public_profile = apply_discord_public_route_profile(openai_payload)
        thinking = normalize_thinking(openai_payload.get('thinking') or openai_payload.get('reasoning'))
        route_mode = normalize_route_mode(openai_payload.get('route'))
        requirements = normalize_requirements(openai_payload, thinking)
        want_json = False
        logger.info(f"[{request_id}] Incoming /v1/messages (Anthropic compat) with {message_count} messages, model={request_model}, thinking={thinking.value}, route={route_mode}, stream={want_stream}")
        result = route_request(openai_payload.get('messages', []), request_id=request_id, thinking=thinking, route_mode=route_mode, requirements=requirements, want_json=want_json)
        if isinstance(result, dict) and result.get('error'):
            # Error response - translate to Anthropic error format
            self.write_json(503, {
                'type': 'error',
                'error': {'type': 'api_error', 'message': result.get('error', 'Internal error')}
            }, extra_headers=self.routing_headers(result, request_id))
        elif want_stream:
            # Anthropic SSE streaming format
            content_text = result.get('choices', [{}])[0].get('message', {}).get('content', '') or ''
            model = result.get('model', request_model or 'sage-router/auto')
            msg_id = f'msg_{uuid.uuid4().hex[:24]}'
            usage = result.get('usage', {})
            sse_events = []
            # message_start
            sse_events.append(f'event: message_start\ndata: {json.dumps({"type":"message_start","message":{"id":msg_id,"type":"message","role":"assistant","content":[],"model":model,"stop_reason":None,"stop_sequence":None,"usage":{"input_tokens":usage.get("prompt_tokens",0),"output_tokens":0}}})}')
            # content_block_start
            sse_events.append(f'event: content_block_start\ndata: {json.dumps({"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}})}')
            # content_block_delta (send full text as one chunk for simplicity)
            sse_events.append(f'event: content_block_delta\ndata: {json.dumps({"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":content_text}})}')
            # content_block_stop
            sse_events.append(f'event: content_block_stop\ndata: {json.dumps({"type":"content_block_stop","index":0})}')
            # message_delta
            sse_events.append(f'event: message_delta\ndata: {json.dumps({"type":"message_delta","delta":{"stop_reason":"end_turn","stop_sequence":None},"usage":{"output_tokens":usage.get("completion_tokens",len(content_text)//4)}})}')
            # message_stop
            sse_events.append(f'event: message_stop\ndata: {json.dumps({"type":"message_stop"})}')
            sse_body = '\n\n'.join(sse_events) + '\n\n'
            sse_bytes = sse_body.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Content-Length', str(len(sse_bytes)))
            for key, value in self.routing_headers(result, request_id).items():
                if value:
                    self.send_header(key, str(value))
            self.end_headers()
            self.wfile.write(sse_bytes)
            self.wfile.flush()
        else:
            # Non-streaming - translate to Anthropic response format
            anthropic_resp = openai_to_anthropic_response(result, request_model)
            self.write_json(200, anthropic_resp, extra_headers=self.routing_headers(result, request_id))
        logger.info(f'[{request_id}] Anthropic compat responded in {time.time() - started:.2f}s')
    except Exception as e:
        logger.exception(f'[{request_id}] Anthropic compat request failed')
        self.write_json(500, {
            'type': 'error',
            'error': {'type': 'api_error', 'message': str(e)}
        }, extra_headers={'X-Sage-Router-Request-Id': request_id})


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        logger.info("%s - %s", self.address_string(), fmt % a)

    def routing_headers(self, payload=None, request_id=''):
        payload = payload or {}
        headers = {}
        model = payload.get('model') or ''
        if model:
            headers['X-Sage-Router-Model'] = model
            if '/' in model:
                provider, model_name = model.split('/', 1)
                headers['X-Sage-Router-Provider'] = provider
                headers['X-Sage-Router-Model-Name'] = model_name
        if request_id:
            headers['X-Sage-Router-Request-Id'] = request_id
        if LAST_ROUTE_DEBUG.get('intent'):
            headers['X-Sage-Router-Intent'] = LAST_ROUTE_DEBUG.get('intent')
        if LAST_ROUTE_DEBUG.get('routeMode'):
            headers['X-Sage-Router-Route-Mode'] = LAST_ROUTE_DEBUG.get('routeMode')
        return headers

    def send_cors_headers(self):
        origin = self.headers.get('Origin') or ''
        allow_origin = '*'
        if CORS_ORIGINS and '*' not in CORS_ORIGINS:
            allow_origin = origin if origin in CORS_ORIGINS else CORS_ORIGINS[0]
        self.send_header('Access-Control-Allow-Origin', allow_origin)
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Vary', 'Origin')

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()

    def write_json(self, status_code, payload, extra_headers=None):
        body = json.dumps(payload).encode()
        try:
            self.send_response(status_code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.send_cors_headers()
            for key, value in (extra_headers or {}).items():
                if value:
                    self.send_header(key, str(value))
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            logger.warning("Client disconnected before response could be written")

    def do_GET(self):
        if self.path in ('', '/'):
            self.write_json(200, {
                "name": "Sage Router",
                "status": "ok",
                "description": "Local-first AI model router with OpenAI, Anthropic, Ollama, NVIDIA NIM, and agent-harness compatible endpoints.",
                "endpoints": {
                    "health": "/health",
                    "models": "/v1/models",
                    "chatCompletions": "/v1/chat/completions",
                    "anthropicMessages": "/v1/messages",
                    "googleGenerateContent": "/v1beta/models/{model}:generateContent",
                    "discovery": "/discovery",
                    "analytics": "/analytics?days=7"
                },
                "docs": "https://sagerouter.dev",
                "source": "https://github.com/earlvanze/sage-router"
            })
        elif self.path == '/health':
            self.write_json(200, {
                "status": "ok",
                "providers": available_provider_names(),
                "configured": list(PROVIDERS.keys()),
                "disabled": sorted(DISABLED_PROVIDERS),
                "disabledModels": sorted(DISABLED_MODELS),
                "thinking": {
                    "default": ThinkingLevel.MEDIUM.value,
                    "accepted": [level.value for level in ThinkingLevel],
                    "routeModes": ["fast", "balanced", "deep", "best", "local-first", "local-strict", "realtime"],
                },
                "requirements": {
                    "supportedKeys": ["reasoning", "json", "tools", "longContext", "document", "vision", "streaming"]
                },
                "intentClassifier": {
                    "enabled": INTENT_CLASSIFIER_ENABLED,
                    "provider": INTENT_CLASSIFIER_PROVIDER,
                    "baseUrl": INTENT_CLASSIFIER_BASE_URL,
                    "model": INTENT_CLASSIFIER_MODEL,
                    "timeoutSeconds": INTENT_CLASSIFIER_TIMEOUT_SECONDS,
                    "minConfidence": INTENT_CLASSIFIER_MIN_CONFIDENCE,
                },
                "dario": {
                    "baseUrl": DARIO_LOCAL_BASE_URL,
                    "autostart": DARIO_AUTOSTART,
                    "reachable": dario_endpoint_ready(timeout=0.1),
                    "bundled": bool(shutil.which('dario')),
                },
                "manifests": {
                    name: {
                        "url": OLLAMA_MANIFEST_URLS.get(canonical_provider_env_key(name), ''),
                        "file": OLLAMA_MANIFEST_FILES.get(canonical_provider_env_key(name), ''),
                        "cache": OLLAMA_MODEL_CACHE.get(name, {})
                    }
                    for name, provider in PROVIDERS.items()
                    if provider.api_type == 'ollama'
                },
                "reasoningCapabilities": reasoning_capabilities_summary(),
                "lastRoute": LAST_ROUTE_DEBUG,
                "blocks": {key: {"until": info["until"], "reason": info["reason"]} for key, info in TEMP_MODEL_BLOCKS.items()},
            })
        elif self.path.startswith('/analytics'):
            if not analytics_authorized(self):
                self.write_json(401, {'error': 'unauthorized'})
                return
            parsed = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(parsed.query)
            days = float((qs.get('days') or ['7'])[0] or 7)
            limit = int((qs.get('limit') or [ANALYTICS_EVENT_LIMIT])[0] or ANALYTICS_EVENT_LIMIT)
            self.write_json(200, build_analytics_snapshot(days * 24 * 3600, limit))
        elif self.path == '/admin/clear-blocks':
            count = len(TEMP_MODEL_BLOCKS)
            TEMP_MODEL_BLOCKS.clear()
            MODEL_HEALTH_CACHE.clear()
            self.write_json(200, {"cleared": count, "status": "ok"})
        elif self.path == '/admin/blocks':
            self.write_json(200, {
                "blocks": {key: {"until": info["until"], "reason": info["reason"], "expiresInSeconds": max(0, info["until"] - time.time())} for key, info in TEMP_MODEL_BLOCKS.items()},
                "count": len(TEMP_MODEL_BLOCKS)
            })
        elif self.path == '/discovery':
            # Return discovered providers from GitHub manifests, CLI, and fallbacks
            openclaw_github = discover_openclaw_github_manifests()
            hermes_github = discover_hermes_github_manifests()
            openclaw_cli = discover_openclaw_cli_providers(timeout_seconds=12)
            hermes_cli = discover_hermes_cli_providers(timeout_seconds=8)
            openclaw_file = discover_openclaw_core_providers()
            hermes_file = discover_hermes_core_providers()
            openclaw_agent_auth = discover_openclaw_agent_auth_providers()
            self.write_json(200, {
                "openclaw": {
                    "github": {
                        "source": "openclaw/openclaw repo",
                        "manifests": openclaw_github,
                        "count": len(openclaw_github)
                    },
                    "cli": {
                        "command": "openclaw models list --all",
                        "providers": openclaw_cli,
                        "count": len(openclaw_cli) if isinstance(openclaw_cli, dict) else 0
                    },
                    "config": {
                        "source": "~/.openclaw/openclaw.json",
                        "providers": openclaw_file,
                        "count": len(openclaw_file)
                    }
                },
                "hermes": {
                    "github": {
                        "source": "NousResearch/hermes-agent repo",
                        "manifests": hermes_github,
                        "count": len(hermes_github)
                    },
                    "cli": {
                        "command": "hermes status --json",
                        "providers": hermes_cli,
                        "count": len(hermes_cli) if isinstance(hermes_cli, dict) else 0
                    },
                    "config": {
                        "source": "~/.hermes/config.yaml + auth.json",
                        "providers": hermes_file,
                        "count": len(hermes_file)
                    }
                },
                "totalProviders": len(openclaw_file) + len(hermes_file)
            })
        elif self.path.startswith('/v1beta/models') or self.path.startswith('/v1/models'):
            # Google Generative AI models listing endpoint
            models_data = []
            for name, prov in PROVIDERS.items():
                for m in prov.models:
                    models_data.append({
                        'name': f'models/{m}',
                        'displayName': m,
                        'supportedGenerationMethods': ['generateContent', 'streamGenerateContent'],
                    })
            self.write_json(200, {'models': models_data})
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path in ['/v1/chat/completions', '/chat/completions']:
            body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
            request_id = uuid.uuid4().hex[:8]
            started = time.time()
            try:
                payload = json.loads(body or b'{}')
                handle_openai_chat_completions(self, payload, request_id, started)
            except Exception as e:
                logger.exception(f"[{request_id}] Request handling failed")
                self.write_json(500, {"error": str(e)}, extra_headers={'X-Sage-Router-Request-Id': request_id})
        elif self.path in ['/v1/messages', '/messages']:
            body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
            request_id = uuid.uuid4().hex[:8]
            started = time.time()
            handle_anthropic_messages(self, body, request_id, started)
        elif self.path in ['/v1/realtime', '/realtime']:
            # Ultra-low-latency realtime endpoint with aggressive streaming
            body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
            request_id = uuid.uuid4().hex[:8]
            started = time.time()
            try:
                payload = json.loads(body or b'{}')
                # Force realtime route mode and streaming
                payload['route'] = 'realtime'
                payload['stream'] = True
                handle_openai_chat_completions(self, payload, request_id, started, force_realtime=True)
            except Exception as e:
                logger.exception(f"[{request_id}] Realtime request failed")
                self.write_json(500, {"error": str(e)}, extra_headers={'X-Sage-Router-Request-Id': request_id})
        elif ':generateContent' in self.path or ':streamGenerateContent' in self.path:
            # Google Generative AI compat: /v1beta/models/{model}:generateContent
            import re
            match = re.match(r'.*/models/([^:]+):(generateContent|streamGenerateContent)', self.path)
            if match:
                body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
                request_id = uuid.uuid4().hex[:8]
                started = time.time()
                model_name = match.group(1)
                want_stream = match.group(2) == 'streamGenerateContent'
                handle_google_generate(self, body, request_id, started, model_name, want_stream)
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=8788); args = parser.parse_args()
    ensure_background_refresh_started()
    server = ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    logger.info(f"Router on :{args.port} | configured={list(PROVIDERS.keys())} | disabled={sorted(DISABLED_PROVIDERS)} disabledModels={sorted(DISABLED_MODELS)}")
    server.serve_forever()
