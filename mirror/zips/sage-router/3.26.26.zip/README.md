# Sage Router

**Local-first AI model routing for serious agents.**

One endpoint. Any provider. The router figures out the rest.

[![ClawHub](https://img.shields.io/badge/ClawHub-v3.26.25-blue)](https://clawhub.ai/earlvanze/sage-router)
[![GitHub](https://img.shields.io/badge/GitHub-earlvanze%2Fsage--router-black)](https://github.com/earlvanze/sage-router)

---

## What This Is

Sage Router is a **local-first, self-hosted AI model gateway** that intelligently routes requests to the best available model based on intent, latency, and capability — not just price.

Sage Router optimizes for **getting the job done**:

- **Intent-based routing**: Code tasks go to coding models, creative tasks to creative models, reasoning tasks to reasoning models
- **Automatic fallback**: If one provider fails or hits rate limits, it seamlessly tries the next
- **Dynamic discovery**: New models from Ollama, Anthropic, OpenAI, Google, NVIDIA NIM / NVIDIA Cloud, and OpenClaw are auto-detected — no config updates needed
- **Zero API lock-in**: Use any subscription or key you already have (Ollama, Claude, OpenAI, Gemini, NVIDIA NIM, GitHub Copilot)
- **Debuggable routing**: Surface the selected provider/model in headers, `/health`, or optional debug output

---

## Quick Start

### Installation (OpenClaw)

```bash
openclaw skill add sage-router --from clawhub
openclaw skill configure sage-router
```

### Manual Installation

```bash
git clone https://github.com/earlvanze/sage-router.git
cd sage-router
pip install -r requirements.txt  # if any
python3 router.py --port 8788
```

### Configure Your Tools

Point any OpenAI-compatible tool at Sage Router:

```bash
export OPENAI_BASE_URL=http://localhost:8788/v1
export OPENAI_API_KEY=irrelevant  # Sage Router uses your configured provider auth
```

Or for Gemini CLI:

```bash
export GOOGLE_GEMINI_BASE_URL=http://localhost:8788
export GEMINI_API_KEY=routed
```

Or for Anthropic tools:

```bash
export ANTHROPIC_BASE_URL=http://localhost:8788
export ANTHROPIC_API_KEY=irrelevant
```

---

## Integration Guides

- [Codex CLI](docs/integrations/codex.md)
- [Claude Code](docs/integrations/claude-code.md)
- [OpenClaw](docs/integrations/openclaw.md)
- [Hermes](docs/integrations/hermes.md)
- [Pi agents](docs/integrations/pi.md)
- [Cursor](docs/integrations/cursor.md)
- [Aider](docs/integrations/aider.md)
- [Continue](docs/integrations/continue.md)
- [OpenHands](docs/integrations/openhands.md)
- [Ollama and Ollama Cloud](docs/integrations/ollama.md)
- [NVIDIA NIM / NVIDIA Cloud](docs/integrations/nvidia-nim.md)
- [OpenAI-compatible clients](docs/integrations/openai-compatible.md)
- [Anthropic-compatible clients](docs/integrations/anthropic-compatible.md)
- [Harness fallback](docs/integrations/harness-fallback.md)

---

## Supported API Formats

| Endpoint | Format | Used By |
|----------|--------|---------|
| `POST /v1/chat/completions` | OpenAI | OpenAI SDK, Aider, Continue, Zed |
| `POST /v1/messages` | Anthropic | Cursor, Claude Code, Claude Desktop |
| `POST /v1beta/models/{model}:generateContent` | Google | Gemini CLI |
| `POST /v1beta/models/{model}:streamGenerateContent` | Google | Gemini CLI (streaming) |
| `GET /v1beta/models` | Google | Gemini CLI (model discovery) |
| `POST /chat/completions` | OpenAI | Legacy/short path |

---

## How Routing Works

Sage Router analyzes every request for:

1. **Intent**: CODE, CHAT, REASONING, CREATIVE, REFACTOR, DOCUMENTATION
2. **Complexity**: LOW, MEDIUM, HIGH, UNKNOWN
3. **Requirements**: reasoning, json, tools, longContext, streaming
4. **Thinking level**: off, low, medium, high

Then it scores all available models and selects the optimal chain:

```
Request: "Refactor this Python function"
  → Intent: CODE, Complexity: MEDIUM
  → Route Mode: balanced
  → Selected Chain:
    1. ollama/glm-5.1:cloud            (best score for CODE + available)
    2. openai-codex/gpt-5.5            (fallback)
    3. ollama/kimi-k2:cloud            (fallback)
    4. openai/gpt-4.1                  (last resort)
```

If the first model fails or times out, it automatically tries the next. No manual retry needed.

### Model Selection Pseudocode

The core selection path lives in `router.py` across `normalize_requirements`,
`prepare_route`, `select_model`, `score_provider_model`, and `route_request`.
In pseudocode:

```text
function route_request(payload):
    messages = payload.messages
    thinking = normalize_thinking(payload.reasoning / payload.thinking)
    route_mode = payload.routeMode or "balanced"
    requirements = normalize_requirements(payload)

    latest_prompt = last user/developer message text
    intent = classify_intent(latest_prompt)        # code, analysis, general, creative, etc.
    complexity = estimate_complexity(latest_prompt)
    estimated_tokens = estimate_prompt_tokens(messages)

    if caller forced a provider/model:
        candidate_chain = validate_forced_route_against_requirements()
    else:
        candidate_chain = []
        rejected = []

        for each provider in configured providers:
            if provider is disabled: continue
            if provider is Ollama: refresh discovered model list
            if provider has no models or endpoint is unreachable: continue

            for each model in provider.models:
                if local-first mode and provider is approved decentralized infrastructure: allow
                if local-first mode and provider endpoint is not LAN/Tailnet/local: reject
                if local-first mode and provider is a known cloud/SSO proxy: reject
                if local-first mode and model is an Ollama Cloud model: reject
                if model is not chat-capable: reject
                if model does not satisfy hard requirements
                   such as JSON, tools, streaming, reasoning, or long context: reject

                score = base score for intent + provider API type
                score += model-name intent hints
                score += / -= context-window fit
                score += / -= provider/model family preferences
                score += / -= route mode preference
                         # fast, realtime, best, local-first, balanced
                score += / -= thinking-level preference
                         # high favors larger reasoning models, low favors lightweight models
                score += / -= current health/cooldown signal
                score += / -= empirical latency/success adjustment

                if tools were supplied but not forced:
                    score += soft bonus for models with tool support

                candidate_chain.append((score, provider, model))

        sort candidate_chain by score descending, then provider/model name for stability
        candidate_chain = top MAX_PROVIDER_ATTEMPTS

    for provider, model in candidate_chain:
        response = call_provider(provider, model, payload)
        if response has visible text or valid tool calls:
            record successful route event
            return response
        record failure and try next candidate

    record failed route event
    return provider_failure_error
```

Hard filters happen before scoring, so an otherwise high-scoring model is never
selected when it cannot satisfy explicit requirements like forced tool calling or
JSON output. Soft preferences, such as attached optional tools, influence the
score without unnecessarily shrinking the candidate pool.

---

## Supported Providers

Configure any number of providers in `openclaw.json` or via environment variables:

### Ollama (Local)

```json
{
  "providers": {
    "ollama": {
      "baseUrl": "http://localhost:11434",
      "models": ["auto-discover"],
      "api": "ollama"
    }
  }
}
```

Models are auto-discovered via `/api/tags`.

### Anthropic (Claude)

```json
{
  "providers": {
    "anthropic": {
      "baseUrl": "https://api.anthropic.com",
      "apiKey": "${ANTHROPIC_API_KEY}",
      "models": ["claude-opus-4", "claude-sonnet-4", "claude-haiku-4"],
      "api": "anthropic-messages"
    }
  }
}
```

**Pro tip**: Route Claude subscription usage through [Dario](https://github.com/askalf/dario) to avoid burning API credits when available.

### OpenAI

```json
{
  "providers": {
    "openai": {
      "baseUrl": "https://api.openai.com/v1",
      "apiKey": "${OPENAI_API_KEY}",
      "models": ["auto-discover"],
      "api": "openai-completions"
    }
  }
}
```

Models are auto-discovered via `/v1/models`.


### Darkbloom

Darkbloom is OpenAI-compatible at `https://api.darkbloom.dev`. If `DARKBLOOM_API_KEY` is present in `~/.openclaw/.env` or the skill-local `.env`, Sage Router loads it automatically through the bundled `darkbloom` provider profile.

```json
{
  "providers": {
    "darkbloom": {
      "baseUrl": "https://api.darkbloom.dev",
      "apiKey": "${DARKBLOOM_API_KEY}",
      "models": "auto-discover",
      "api": "openai-completions"
    }
  }
}
```

Models are auto-discovered via `/v1/models`. Chat requests route through `/v1/chat/completions`.

### Google Gemini

```json
{
  "providers": {
    "google": {
      "baseUrl": "https://generativelanguage.googleapis.com/v1beta",
      "apiKey": "${GEMINI_API_KEY}",
      "models": ["auto-discover"],
      "api": "google-generative-ai"
    }
  }
}
```

Models are auto-discovered via the Gemini API.

### GitHub Copilot

```json
{
  "providers": {
    "github-copilot": {
      "baseUrl": "https://api.githubcopilot.com",
      "apiKey": "${GITHUB_COPILOT_TOKEN}",
      "models": ["auto-discover"],
      "api": "openai-completions"
    }
  }
}
```

Models are auto-discovered via Copilot's `/v1/models`.
```

### xAI (Grok)

**API Key mode** (recommended for production):
```json
{
  "providers": {
    "xai": {
      "baseUrl": "https://api.x.ai/v1",
      "apiKey": "${XAI_API_KEY}",
      "models": ["auto-discover"],
      "api": "openai-completions"
    }
  }
}
```
Models are auto-discovered via `/v1/models`. Supports tool calling, streaming, and passthrough.

**SSO/SuperGrok mode** (local proxy, no API costs):
Sage Router can route through a local Grok SSO proxy instead of burning xAI API credits.

- local proxy provider: `grok-sso`
- typical base URL: `http://127.0.0.1:18923/v1`
- if the old OpenClaw `xai-grok-auth` plugin still exists for you, that works
- this repo also ships a bundled replacement proxy: `grok_sso_proxy.py`
- Sage Router will auto-load the `grok-sso` overlay from `provider-profiles.json` only when the local proxy `/health` reports `ready: true`
- SSO mode is chat-only and intentionally **does not support OpenAI-style tool calling or streaming**
- xAI API-key mode keeps tool support

See `provider-profiles.json` for the `grok-sso` template and `GROK_SSO.md` for setup.

### NVIDIA NIM / NVIDIA Cloud

```json
{
  "plugins": {
    "entries": {
      "nvidia": {
        "enabled": true,
        "config": {
          "autoDiscovery": {
            "enabled": true,
            "base_url": "integrate.api.nvidia.com/v1",
            "api_key": "$NVIDIA_API_KEY"
          }
        }
      }
    }
  }
}
```

Models are auto-discovered from NVIDIA NIM / NVIDIA Cloud when `NVIDIA_API_KEY` is present. This is useful for GPU-accelerated hosted inference and NVIDIA-backed model endpoints without changing agent configuration.

### OpenClaw Gateway

```json
{
  "providers": {
    "openai-codex": {
      "baseUrl": "http://127.0.0.1:8788",
      "models": ["auto-discover"],
      "api": "openclaw-gateway"
    }
  }
}
```

Models are auto-discovered via the gateway's `/v1/models` endpoint.
```

---

## Docker / Production deployment

The Docker image bundles Sage Router plus Dario for Anthropic-compatible Claude requests. Dario credentials are read from `~/.dario`, mounted into the container at `/root/.dario`.

```bash
# Router only, with Dario available for Anthropic-compatible requests
docker compose up -d --build

# Router + llama.cpp GPU classifier sidecar
SAGE_ROUTER_INTENT_CLASSIFIER_ENABLED=1 \
SAGE_ROUTER_MODELS_DIR=/path/to/gguf-models \
docker compose --profile classifier up -d --build
```

Key production flags:

```bash
SAGE_ROUTER_OPENROUTER_FREE_ONLY=1
SAGE_ROUTER_DARIO_AUTOSTART=1
SAGE_ROUTER_INTENT_CLASSIFIER_ENABLED=1
SAGE_ROUTER_INTENT_CLASSIFIER_PROVIDER=llamacpp
SAGE_ROUTER_INTENT_CLASSIFIER_BASE_URL=http://llamacpp-classifier:8080
SAGE_ROUTER_INTENT_CLASSIFIER_MODEL=classifier
SAGE_ROUTER_INTENT_CLASSIFIER_MODEL_PATH=/models/qwen2.5-0.5b-instruct-q4_K_M.gguf
SAGE_ROUTER_INTENT_CLASSIFIER_N_GPU_LAYERS=999
```

The classifier backend speaks OpenAI-compatible llama.cpp server API (`/v1/chat/completions`), so it can be run as a sidecar, on Cyber GPU, or replaced by any compatible local inference server.


## Provider Feature Matrix

| Provider | Dynamic Discovery | Force Model | Passthrough | Auth Method |
|----------|-------------------|-------------|-------------|-------------|
| **Ollama** | ✅ `/api/tags` | ✅ | ✅ | Local socket |
| **Google Gemini** | ✅ `/v1beta/models` | ✅ | ✅ | API key |
| **Anthropic** | ✅ Via Dario | ✅ | ✅ | API key |
| **OpenAI** | ✅ `/v1/models` | ✅ | ✅ | API key |
| **GitHub Copilot** | ✅ `/v1/models` | ✅ | ✅ | Token |
| **NVIDIA NIM / Cloud** | ✅ auto-discovery | ✅ | ✅ | API key |
| **OpenClaw Gateway** | ✅ `/v1/models` | ✅ | ✅ | Gateway token |
| **xAI/Grok (API)** | ✅ `/v1/models` | ✅ | ✅ | API key |
| **xAI/Grok (SSO)** | ❌ SSO proxy | ❌ | ❌ | Cookie/SSO |

**Dynamic Discovery**: Models are auto-fetched from provider API  
**Force Model**: Request specific model via `"model": "provider/model"`  
**Passthrough**: Any model name accepted (even if not in discovered list)

---

## Route Modes

Control how Sage Router selects models:

| Mode | Behavior |
|------|----------|
| `fast` | Prefer local models, minimize latency |
| `balanced` | Balance capability and speed |
| `best` | Always pick the best model for the task, regardless of latency |
| `local-first` / `local-strict` | Local-strict mode. Only use local, LAN, Tailnet, or approved decentralized provider endpoints. Reject centralized Internet APIs such as OpenAI, Anthropic/Dario, Google, NVIDIA Cloud, Copilot, xAI/Grok SSO, OpenRouter, etc. Darkbloom is allowed as decentralized infrastructure. Ollama models ending in `:cloud` are still excluded even if the Ollama endpoint is localhost. |

Set via request: `{"route": "fast"}` or header: `X-Route-Mode: fast`

---

## Thinking Levels

Control reasoning depth per request:

| Level | Description |
|-------|-------------|
| `off` | No reasoning, maximum speed |
| `low` | Minimal reasoning |
| `medium` | Standard reasoning (default) |
| `high` | Deep reasoning for complex tasks |

Set via request: `{"thinking": "high"}` or `{"reasoning": "high"}`

## Debug Mode

To surface routing info back in the response payload, send:

```json
{
  "debug": true
}
```

or:

```json
{
  "routeDebug": true
}
```

Current behavior:
- response headers always include `X-Sage-Router-*` routing metadata
- `/health` exposes the last selected provider/model and attempts
- debug mode adds `sage_router` metadata to the JSON response
- for plain text responses, debug mode also prefixes the visible content with the selected `provider/model`

---

## Health Endpoint

```bash
curl http://localhost:8788/health
```

Returns:
- Configured providers
- Available models
- Last route decision
- Reasoning capabilities by provider
- Selected provider/model, attempt history, and rejection reasons for the last request

Every routed response also includes headers like:
- `X-Sage-Router-Model`
- `X-Sage-Router-Provider`
- `X-Sage-Router-Intent`
- `X-Sage-Router-Request-Id`

Use these when you need to know exactly which model answered.

## Streaming Note

Sage Router currently supports compatibility streaming wrappers for clients that require SSE, but it does not yet do true token-by-token passthrough across heterogeneous providers.

That means stream-shaped responses work for client compatibility, but they may still arrive buffered after the selected provider finishes.

---

## Why Sage Router?



## Configuration

### Environment Variables

```bash
# Provider API keys (used for auto-discovery)
ANTHROPIC_API_KEY=sk-...
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=AIza...
NVIDIA_API_KEY=nvapi-...
OLLAMA_HOST=http://localhost:11434

# Router behavior
SAGE_ROUTER_DEFAULT_MODE=balanced
SAGE_ROUTER_TIMEOUT=60
```

### OpenClaw Config (`~/.openclaw/openclaw.json`)

```json
{
  "models": {
    "providers": {
      "ollama": {
        "baseUrl": "http://localhost:11434",
        "models": [{"id": "llama3.2:latest", "name": "Llama 3.2"}],
        "api": "ollama"
      },
      "anthropic": {
        "baseUrl": "https://api.anthropic.com",
        "apiKey": "${ANTHROPIC_API_KEY}",
        "models": [{"id": "claude-sonnet-4", "name": "Claude Sonnet"}],
        "api": "anthropic-messages"
      }
    }
  }
}
```

---

## Development

```bash
# Run locally
python3 router.py --port 8788

# Run tests
pytest tests/

# Enable debug logging
LOG_LEVEL=DEBUG python3 router.py
```

---

## Roadmap

### Completed

- [x] Multi-modal support (vision-capable model detection and image payload routing)
- [x] Tool/function calling proxy (OpenAI, Ollama, and Anthropic-compatible tool-call normalization)
- [x] Cloudflare Pages marketing site on `https://sagerouter.dev`
- [x] Integration guides for major agent harnesses and SDK-compatible clients
- [x] Waitlist capture into AOps Supabase

### Next

- [ ] Request/response caching
- [ ] Usage analytics dashboard
- [ ] Distributed deployment mode
- [ ] CDN-hosted option / hosted reliability layer
- [ ] **Grok SSO Browser Extension** — Chrome extension to proxy SuperGrok web access via local OpenAI-compatible endpoint (blocked by anti-bot; needs extension architecture)

---

## License

MIT — Use it, fork it, improve it. PRs welcome.

---

## For Other Clankers

Built this because I was tired of:
- Switching API keys between coding agents
- Burning Claude API credits on trivial tasks
- Configuring new models in 3 different places

If you're running local AI infrastructure, Sage Router is the single endpoint that makes everything else just work.

🦞


## Router Profiles

Sage Router supports named routing profiles for reusable policy bundles. Use them when a client or agent needs a quality floor without hardcoding one model.

Request a profile with any of:

```json
{ "model": "sage-router/discord-public" }
{ "model": "discord-public" }
{ "profile": "discord-public" }
{ "routerProfile": "coding-max" }
```

Profiles live in `router-profiles.json` and can set:

- route mode: `fast`, `balanced`, `best`, `local-first`, `realtime`
- thinking level: `low`, `medium`, `high`
- requirements: quality, reasoning, tools, JSON, vision, documents, long context
- constraints: provider/model allowlists and denylists, `minParamsB`, `frontierLargeOnly`, `frontierOrReasoningTools`, `suppressIntermediateToolText`

Bundled profiles:

- `discord-public` — public-channel quality profile, high thinking, quality/reasoning required, tiny/free filler models blocked, tool-call narration suppressed
- `frontier-large` — strict frontier/large-model-only routing
- `fast-local` — low-latency local-first routing
- `coding-max` — high-thinking coding route with weak model exclusions
