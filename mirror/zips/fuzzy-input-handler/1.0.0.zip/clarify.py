"""
Fuzzy Input Handler - 模糊输入澄清模块 (Python)

使用示例:
    from clarify import analyze_ambiguity, clarify, confirm_context
    
    # 分析歧义
    result = analyze_ambiguity("把那个文件发给我")
    
    # 生成澄清回复
    clarification = clarify(
        input_text="把那个文件发给我",
        ambiguities=result,
        context={"recent_items": ["报告.docx", "数据.xlsx"]}
    )
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
from datetime import datetime, timedelta


class AmbiguityType(Enum):
    """歧义类型枚举"""
    ENTITY = "entity"
    ACTION = "action"
    QUANTITY = "quantity"
    TIME = "time"
    LOCATION = "location"
    REFERENCE = "reference"
    MULTI_INTENT = "multi_intent"
    MISSING_PARAM = "missing_param"


@dataclass
class AmbiguityIssue:
    """歧义问题"""
    type: AmbiguityType
    description: str
    examples: List[str] = field(default_factory=list)


@dataclass
class AmbiguityResult:
    """歧义分析结果"""
    has_issues: bool
    issues: List[AmbiguityIssue]
    confidence: float
    types: List[str] = field(default_factory=list)


@dataclass
class ClarificationOption:
    """澄清选项"""
    id: int
    label: str
    value: Any = None
    action: str = ""
    primary: bool = False


@dataclass
class ClarificationQuestion:
    """澄清问题"""
    id: int
    question: str
    example: str
    required: bool = True


@dataclass
class ClarificationResult:
    """澄清结果"""
    type: str
    message: str
    options: Optional[List[ClarificationOption]] = None
    questions: Optional[List[ClarificationQuestion]] = None
    allow_free_text: bool = True
    hint: str = ""
    allow_partial: bool = False
    sequential: bool = False


@dataclass
class ConfirmationResult:
    """确认结果"""
    resolved: bool
    value: Any = None
    action: str = ""
    need_more_info: bool = False
    free_text: str = ""
    context: Dict[str, Any] = field(default_factory=dict)


# ============ 核心函数 ============

def analyze_ambiguity(input_text: str, context: Dict[str, Any] = None) -> AmbiguityResult:
    """
    分析输入中的歧义类型
    
    Args:
        input_text: 用户输入文本
        context: 上下文信息
        
    Returns:
        AmbiguityResult: 歧义分析结果
    """
    context = context or {}
    issues = []
    
    # 检测模糊指代
    vague_refs = ['这个', '那个', '这里', '那里', '它', '他', '她']
    found_refs = [ref for ref in vague_refs if ref in input_text]
    if found_refs:
        issues.append(AmbiguityIssue(
            type=AmbiguityType.REFERENCE,
            description='包含模糊指代词',
            examples=found_refs
        ))
    
    # 检测模糊时间
    vague_time = ['稍后', '过会儿', '明天', '最近', '之前', '之后', '昨天', '今天']
    found_time = [t for t in vague_time if t in input_text]
    if found_time:
        issues.append(AmbiguityIssue(
            type=AmbiguityType.TIME,
            description='时间表述不够具体',
            examples=found_time
        ))
    
    # 检测模糊数量
    vague_qty = ['一些', '几个', '一点', '很多', '全部']
    found_qty = [q for q in vague_qty if q in input_text]
    if found_qty:
        issues.append(AmbiguityIssue(
            type=AmbiguityType.QUANTITY,
            description='数量不明确',
            examples=found_qty
        ))
    
    # 检测模糊动作
    vague_action = ['处理', '弄一下', '搞一下', '看看', '弄']
    found_action = [a for a in vague_action if a in input_text]
    if found_action:
        issues.append(AmbiguityIssue(
            type=AmbiguityType.ACTION,
            description='操作意图不够明确',
            examples=found_action
        ))
    
    # 检测可能的多意图
    verbs = ['查', '找', '发', '写', '做', '订', '买', '删', '改', '处理']
    found_verbs = [v for v in verbs if v in input_text]
    if len(found_verbs) >= 2:
        issues.append(AmbiguityIssue(
            type=AmbiguityType.MULTI_INTENT,
            description='可能包含多个意图',
            examples=found_verbs
        ))
    
    # 检测地点缺失（针对天气、餐厅等场景）
    if '天气' in input_text and not context.get('city'):
        city_pattern = r'([\u4e00-\u9fa5]{2,7}(?:市|县|区|镇))'
        if not re.search(city_pattern, input_text):
            issues.append(AmbiguityIssue(
                type=AmbiguityType.LOCATION,
                description='缺少地点信息',
                examples=['城市', '地区']
            ))
    
    confidence = max(0, 1 - len(issues) * 0.2)
    
    return AmbiguityResult(
        has_issues=len(issues) > 0,
        issues=issues,
        confidence=confidence,
        types=[issue.type.value for issue in issues]
    )


def clarify(
    input_text: str,
    ambiguities: AmbiguityResult,
    context: Dict[str, Any] = None,
    options: Dict[str, Any] = None
) -> ClarificationResult:
    """
    生成澄清回复
    
    Args:
        input_text: 用户输入文本
        ambiguities: 歧义分析结果
        context: 上下文信息
        options: 配置选项
        
    Returns:
        ClarificationResult: 澄清结果
    """
    context = context or {}
    options = options or {}
    
    strategies = {
        AmbiguityType.REFERENCE.value: lambda: _generate_reference_clarification(input_text, context),
        AmbiguityType.TIME.value: lambda: _generate_time_clarification(input_text, context),
        AmbiguityType.QUANTITY.value: lambda: _generate_quantity_clarification(input_text, context),
        AmbiguityType.ACTION.value: lambda: _generate_action_clarification(input_text, context),
        AmbiguityType.MULTI_INTENT.value: lambda: _generate_multi_intent_clarification(input_text, context),
        AmbiguityType.ENTITY.value: lambda: _generate_entity_clarification(input_text, context),
        AmbiguityType.MISSING_PARAM.value: lambda: _generate_param_clarification(input_text, context),
        AmbiguityType.LOCATION.value: lambda: _generate_location_clarification(input_text, context),
    }
    
    primary_issue = ambiguities.issues[0] if ambiguities.issues else None
    strategy = strategies.get(primary_issue.type.value if primary_issue else None, 
                              lambda: _generate_action_clarification(input_text, context))
    
    return strategy()


def confirm_context(user_reply: str, clarification_context: Dict[str, Any]) -> ConfirmationResult:
    """
    确认上下文（用户回复后调用）
    
    Args:
        user_reply: 用户回复
        clarification_context: 澄清上下文
        
    Returns:
        ConfirmationResult: 确认结果
    """
    clarification_type = clarification_context.get('type')
    options = clarification_context.get('options')
    questions = clarification_context.get('questions')
    
    # 数字选择
    num_match = re.match(r'^(\d+)[\.\、\)]?\s*', user_reply)
    if num_match and options:
        selected_id = int(num_match.group(1))
        selected = next((o for o in options if o.get('id') == selected_id), None)
        if selected:
            return ConfirmationResult(
                resolved=True,
                value=selected.get('value') or selected.get('label'),
                action=selected.get('action') or selected.get('value'),
                context={**clarification_context, 'selected': selected}
            )
    
    # 确认词
    confirm_words = ['是', '确认', '对的', '没错', '好', 'yes', 'ok']
    if any(w in user_reply.lower() for w in confirm_words):
        return ConfirmationResult(
            resolved=True,
            value='confirmed',
            context=clarification_context
        )
    
    # 否定词
    deny_words = ['不是', '不对', '否', 'no', '错了']
    if any(w in user_reply for w in deny_words):
        return ConfirmationResult(
            resolved=False,
            need_more_info=True,
            context=clarification_context
        )
    
    # 自由文本
    return ConfirmationResult(
        resolved=False,
        free_text=user_reply,
        context=clarification_context
    )


# ============ 内部函数 ============

def _generate_reference_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成指代澄清"""
    candidates = context.get('recent_items', ['选项A', '选项B', '选项C'])
    match = re.search(r'(这个|那个|它)', input_text)
    ref_word = match.group(1) if match else '它'
    
    return ClarificationResult(
        type='REFERENCE',
        message=f'您提到的"{ref_word}"是指以下哪一个？',
        options=[
            ClarificationOption(id=i+1, label=item, action=f'select:{item}')
            for i, item in enumerate(candidates)
        ],
        allow_free_text=True,
        hint='也可以直接描述您指的是什么'
    )


def _generate_time_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成时间澄清"""
    now = datetime.now()
    tomorrow = now + timedelta(days=1)
    
    return ClarificationResult(
        type='TIME',
        message='请确认具体时间：',
        options=[
            ClarificationOption(id=1, label=f'今天 ({_format_date(now)})', value=now),
            ClarificationOption(id=2, label=f'明天 ({_format_date(tomorrow)})', value=tomorrow),
            ClarificationOption(id=3, label='本周内', value='this_week'),
            ClarificationOption(id=4, label='自定义时间', value='custom'),
        ],
        allow_free_text=True,
        hint='例如："周五下午3点"、"5月1日"、"10分钟后"'
    )


def _generate_quantity_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成数量澄清"""
    return ClarificationResult(
        type='QUANTITY',
        message='请确认数量：',
        options=[
            ClarificationOption(id=1, label='1个', value=1),
            ClarificationOption(id=2, label='3个', value=3),
            ClarificationOption(id=3, label='5个', value=5),
            ClarificationOption(id=4, label='全部', value='all'),
            ClarificationOption(id=5, label='自定义', value='custom'),
        ],
        allow_free_text=True,
        hint='直接输入数字或描述，如"前10个"'
    )


def _generate_action_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成动作澄清"""
    guessed = _guess_intent(input_text, context)
    
    return ClarificationResult(
        type='ACTION',
        message=f'您是想「{guessed["description"]}」吗？',
        options=[
            ClarificationOption(id=1, label='是的，没错', value='confirm', primary=True),
            ClarificationOption(id=2, label=guessed['alternative1'], value='alt1'),
            ClarificationOption(id=3, label=guessed['alternative2'], value='alt2'),
            ClarificationOption(id=4, label='都不是，我详细说明', value='explain'),
        ],
        allow_free_text=True,
        hint='请描述您具体想做什么'
    )


def _generate_multi_intent_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成多意图澄清"""
    intents = _extract_intents(input_text)
    
    return ClarificationResult(
        type='MULTI_INTENT',
        message='我检测到您可能有多个需求，我们一个一个来处理：',
        options=[
            ClarificationOption(id=i+1, label=f"{i+1}. {intent['description']}", value=intent['action'])
            for i, intent in enumerate(intents)
        ],
        allow_free_text=True,
        hint='回复数字选择先处理哪个，或告诉我优先级',
        sequential=True
    )


def _generate_entity_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成实体澄清"""
    entity_type = _detect_entity_type(input_text)
    key = f'recent_{entity_type}s'
    candidates = context.get(key, [])
    
    options = [
        ClarificationOption(id=i+1, label=item, value=item)
        for i, item in enumerate(candidates)
    ] if candidates else [ClarificationOption(id=1, label='我详细描述', value='describe')]
    
    return ClarificationResult(
        type='ENTITY',
        message=f'请确认您指的是哪个{entity_type}：',
        options=options,
        allow_free_text=True,
        hint=f'请提供更具体的{entity_type}信息'
    )


def _generate_param_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成参数缺失澄清"""
    required_params = context.get('required_params', [])
    
    return ClarificationResult(
        type='MISSING_PARAM',
        message='为了完成您的请求，我还需要以下信息：',
        questions=[
            ClarificationQuestion(
                id=i+1,
                question=param.get('question'),
                example=param.get('example'),
                required=param.get('required', True)
            )
            for i, param in enumerate(required_params)
        ],
        allow_partial=True,
        hint='可以逐一回答，或一次性提供所有信息'
    )


def _generate_location_clarification(input_text: str, context: Dict[str, Any]) -> ClarificationResult:
    """生成地点澄清"""
    recent_cities = context.get('recent_cities', ['北京', '上海', '广州', '深圳'])
    
    return ClarificationResult(
        type='LOCATION',
        message='📍 请确认地点：',
        options=[
            ClarificationOption(id=i+1, label=city, value=city)
            for i, city in enumerate(recent_cities)
        ],
        allow_free_text=True,
        hint='直接输入城市名，如"杭州"、"成都"'
    )


# ============ 辅助函数 ============

def _format_date(date: datetime) -> str:
    """格式化日期"""
    return f"{date.month}月{date.day}日"


def _guess_intent(input_text: str, context: Dict[str, Any]) -> Dict[str, str]:
    """猜测用户意图"""
    if '文件' in input_text or '文档' in input_text:
        return {
            'description': '查找/处理文件',
            'alternative1': '创建新文件',
            'alternative2': '删除文件'
        }
    if '数据' in input_text:
        return {
            'description': '分析/处理数据',
            'alternative1': '导出数据',
            'alternative2': '导入数据'
        }
    if '天气' in input_text:
        return {
            'description': '查询天气信息',
            'alternative1': '查看未来预报',
            'alternative2': '设置天气提醒'
        }
    return {
        'description': '执行相关操作',
        'alternative1': '查看信息',
        'alternative2': '修改设置'
    }


def _extract_intents(input_text: str) -> List[Dict[str, str]]:
    """提取多个意图"""
    intents = []
    if '查' in input_text:
        intents.append({'description': '查询信息', 'action': 'query'})
    if '发' in input_text:
        intents.append({'description': '发送/分享', 'action': 'send'})
    if '写' in input_text:
        intents.append({'description': '创建/编写', 'action': 'create'})
    if '订' in input_text:
        intents.append({'description': '预订/订购', 'action': 'book'})
    if '找' in input_text:
        intents.append({'description': '查找/搜索', 'action': 'search'})
    
    return intents if intents else [{'description': '执行操作', 'action': 'do'}]


def _detect_entity_type(input_text: str) -> str:
    """检测实体类型"""
    if '文件' in input_text:
        return '文件'
    if '人' in input_text or '用户' in input_text:
        return '人'
    if '项目' in input_text:
        return '项目'
    if '任务' in input_text:
        return '任务'
    return '对象'


# ============ 使用示例 ============

if __name__ == '__main__':
    # 测试示例
    test_inputs = [
        "查下昨天的天气",
        "把那个文件发给我",
        "帮我处理一下数据",
        "明天提醒我开会"
    ]
    
    for text in test_inputs:
        print(f"\n{'='*50}")
        print(f"输入: {text}")
        
        result = analyze_ambiguity(text)
        print(f"歧义检测: {result.has_issues}")
        print(f"置信度: {result.confidence}")
        
        if result.has_issues:
            for issue in result.issues:
                print(f"  - {issue.type.value}: {issue.description}")
            
            clarification = clarify(text, result, {
                'recent_items': ['报告.docx', '数据.xlsx'],
                'recent_cities': ['北京', '上海', '广州']
            })
            print(f"\n澄清消息:\n{clarification.message}")
