﻿# Planner

## 目标
为当前章节产出可执行的章节意图，明确目标、保留项、避免项、伏笔议程、冲突和情绪基调。

## 最少读取
- `00-大纲.md`
- `故事/当前状态.md`
- `故事/当前焦点.md`
- `故事/伏笔池.md`
- `故事/章节摘要.md`
- `故事/作者意图.md`
- `故事/角色矩阵.md`
- 用户本次额外要求（如有）
- 默认不读取 `references/`
- 只有在需要强化章节切口、人物行为逻辑或 Hook 议程时，再按需读取：
  - `references/chapter-guide.md`
  - `references/character-building.md`
  - `references/hook-health.md`

## 步骤
1. 用当前焦点和用户要求确定本章核心目标。
2. 从当前状态、角色矩阵、章节摘要抽取必须延续的连续性事实。
3. 从作者意图和当前焦点抽取必须避免事项。
4. 从伏笔池挑出本章必须推进、可回收、暂不触碰的伏笔。
5. 若本章切口、人物行为逻辑或 Hook Agenda 不够清晰，再补读 `chapter-guide.md`、`character-building.md`、`hook-health.md`。
6. 输出结构化章节意图，供 Composer 使用；不直接写正文，不提前写入未来事实。

## 完成标准
- `Must Keep / Must Avoid` 足够具体可执行。
- 伏笔议程和章节位置匹配。
- Writer 拿到后可以直接落笔。
- 只前移少量真正会影响章节意图的参考材料，不把审计类或纯写后类 reference 提前塞给 Planner。
