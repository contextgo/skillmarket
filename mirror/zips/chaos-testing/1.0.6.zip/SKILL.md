---
version: "2.0.0"
name: Simianarmy
description: "Inject random failures into cloud infrastructure to test resilience. Use when validating fault tolerance, stress-testing services, or simulating outages."
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
---

# Simianarmy — Chaos Testing Toolkit

A multi-purpose utility tool for managing chaos testing experiments, failure injection records, and resilience testing data. Log test runs, track configurations, manage entries, and export results — all from the command line.

## Commands

| Command | Description |
|---------|-------------|
| `chaos-testing run <args>` | Execute and log the main chaos test function |
| `chaos-testing config <args>` | View or update configuration settings |
| `chaos-testing status <args>` | Show current system status |
| `chaos-testing init <args>` | Initialize the data directory and workspace |
| `chaos-testing list <args>` | List all recorded entries from the data log |
| `chaos-testing add <entry>` | Add a new timestamped entry to the data log |
| `chaos-testing remove <entry>` | Remove an entry from the log |
| `chaos-testing search <term>` | Search entries by keyword (case-insensitive) |
| `chaos-testing export <args>` | Export all data log contents to stdout |
| `chaos-testing info <args>` | Show version and data directory info |
| `chaos-testing help` | Show available commands |
| `chaos-testing version` | Show version number |

Each command logs its invocation to `history.log` for full activity tracking.

## Data Storage

- **Default location:** `~/.local/share/chaos-testing/`
- Override with the `CHAOS_TESTING_DIR` environment variable, or it falls back to `$XDG_DATA_HOME/chaos-testing`
- Main data file: `data.log` — stores timestamped entries (one per line)
- Activity log: `history.log` — records every command invocation with timestamp
- Configuration: `config.json` (referenced by the `config` command)
- All data is stored locally — no external APIs or network calls

## Requirements

- bash 4+ (uses `set -euo pipefail`)
- Standard Unix utilities (`date`, `wc`, `grep`, `cat`)
- No external dependencies or API keys required

## When to Use

1. **Chaos experiment tracking** — Record and review failure injection tests across your infrastructure with timestamped entries.
2. **Resilience test management** — Maintain a structured log of which services were tested, what failures were simulated, and the outcomes observed.
3. **Post-incident learning** — After an outage, add entries documenting what went wrong and search historical tests to see if the failure mode was previously covered.
4. **Team collaboration on chaos engineering** — Export test data for sharing with SRE or platform teams, and use search to quickly find past experiments.
5. **Environment initialization and status checks** — Use `init` to set up new testing workspaces and `status` to verify readiness before running experiments.

## Examples

```bash
# Initialize the chaos testing workspace
chaos-testing init

# Add a chaos experiment entry
chaos-testing add "killed redis-primary pod in staging cluster"

# Add another experiment with more detail
chaos-testing add "network partition between zone-a and zone-b for 60s"

# List all recorded experiments
chaos-testing list

# Search for Redis-related tests
chaos-testing search redis

# Run a chaos test function
chaos-testing run "cpu-stress on worker-node-03"

# Check current status
chaos-testing status

# View configuration
chaos-testing config

# Export all test data
chaos-testing export

# Show version and data directory
chaos-testing info
```

## Configuration

Set `CHAOS_TESTING_DIR` environment variable to change the data directory:

```bash
export CHAOS_TESTING_DIR="/path/to/custom/chaos-data"
```

Default: `~/.local/share/chaos-testing/`

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
