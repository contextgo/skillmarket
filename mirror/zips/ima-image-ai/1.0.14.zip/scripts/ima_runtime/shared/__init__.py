"""Shared runtime helpers."""

