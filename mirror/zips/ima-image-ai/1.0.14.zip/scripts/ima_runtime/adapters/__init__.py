"""CLI presentation helpers."""

