"""Capability namespace."""

