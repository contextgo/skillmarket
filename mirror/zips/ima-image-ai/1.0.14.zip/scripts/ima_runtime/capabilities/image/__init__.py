"""Image capability package."""

