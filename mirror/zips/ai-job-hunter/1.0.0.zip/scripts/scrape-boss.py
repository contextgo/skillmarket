#!/usr/bin/env python3
"""
BOSS直聘岗位抓取脚本
====================

BOSS直聘有严格反爬，需要先登录保存cookie，再用API抓取。
跨平台支持：macOS / Windows / Linux

依赖：
  pip3 install undetected-chromedriver selenium

首次使用（登录保存cookie）：
  macOS/Linux:  python3 scrape-boss.py --login
  Windows:      python scrape-boss.py --login
  → 弹出浏览器 → 手动登录 → cookie自动保存

后续抓取（使用已保存cookie）：
  python3 scrape-boss.py --keyword "教学督导" --city "北京"
  python3 scrape-boss.py --keyword "感统教研" --city "北京" --pages 3

注意：
  - BOSS直聘薪资字段在服务端被隐藏，API返回的salaryDesc为空字符串
  - 职位描述使用CSS混淆反爬，无法直接提取
  - cookie可能过期，过期后需重新 --login
  - Windows用户如遇问题，确保Chrome已安装且为默认浏览器
"""

import json
import time
import argparse
import os
import sys
import platform
from urllib.parse import quote

try:
    import undetected_chromedriver as uc
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.by import By
except ImportError:
    print("❌ 请先安装BOSS直聘依赖：pip3 install undetected-chromedriver selenium")
    print("   或运行：python3 scripts/check-env.py")
    print("   ℹ️  如果不需要抓取BOSS直聘，可以跳过此依赖")
    sys.exit(1)


# ============ 跨平台路径处理 ============

def get_script_dir():
    """获取脚本所在目录（兼容Windows）"""
    return os.path.dirname(os.path.abspath(__file__))


def get_cookie_path():
    """获取cookie文件路径"""
    return os.path.join(get_script_dir(), "boss_cookies.json")


# ============ 城市代码映射 ============

CITY_CODES = {
    "北京": "101010100", "上海": "101020100", "广州": "101280100",
    "深圳": "101280600", "杭州": "101210100", "成都": "101270100",
    "南京": "101190100", "武汉": "101200100", "西安": "101110100",
    "重庆": "101040100", "天津": "101030100", "苏州": "101190400",
    "长沙": "101250100", "郑州": "101180100", "东莞": "101281600",
    "沈阳": "101070100", "青岛": "101120200", "合肥": "101220100",
    "佛山": "101280800", "昆明": "101290100", "大连": "101070200",
    "福州": "101230100", "厦门": "101230200", "哈尔滨": "101050100",
    "济南": "101120100", "南宁": "101300100", "长春": "101060100",
    "石家庄": "101090100", "贵阳": "101260100", "南昌": "101240100",
    "太原": "101100100", "兰州": "101160100", "银川": "101170100",
}


def is_windows():
    return platform.system() == "Windows"


# ============ 浏览器管理 ============

def create_driver(headless=False, minimized=True):
    """创建undetected Chrome实例（跨平台）"""
    options = uc.ChromeOptions()

    if is_windows():
        # Windows特定配置
        if minimized:
            options.add_argument("--window-position=-32000,-32000")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--lang=zh-CN")
        options.add_argument("--window-size=1920,1080")
        # Windows上避免权限问题
        options.add_argument("--disable-dev-shm-usage")
    else:
        # macOS / Linux
        if minimized:
            # 将窗口移出屏幕（替代最小化，更隐蔽）
            options.add_argument("--window-position=-2400,-2400")
        if headless:
            options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--lang=zh-CN")

    try:
        driver = uc.Chrome(options=options)
        return driver
    except Exception as e:
        print(f"❌ Chrome启动失败：{e}")
        if is_windows():
            print("💡 Windows提示：")
            print("   1. 确保已安装Chrome浏览器")
            print("   2. 如果Chrome安装在非默认路径，可能需要手动指定")
            print("   3. 尝试以管理员权限运行")
        else:
            print("💡 macOS/Linux提示：")
            print("   1. 确保已安装Chrome或Chromium")
            print("   2. macOS: brew install --cask google-chrome")
            print("   3. Ubuntu: sudo apt install google-chrome-stable")
        sys.exit(1)


def save_cookies(driver):
    """保存cookie到文件"""
    cookies = driver.get_cookies()
    cookie_path = get_cookie_path()
    with open(cookie_path, "w", encoding="utf-8") as f:
        json.dump(cookies, f, ensure_ascii=False, indent=2)
    print(f"✅ Cookie已保存到 {cookie_path}（{len(cookies)}条）")


def load_cookies(driver):
    """从文件加载cookie"""
    cookie_path = get_cookie_path()
    if not os.path.exists(cookie_path):
        print("❌ Cookie文件不存在，请先运行 --login")
        return False

    with open(cookie_path, "r", encoding="utf-8") as f:
        cookies = json.load(f)

    # 先访问BOSS直聘以设置域名
    driver.get("https://www.zhipin.com")
    time.sleep(2)

    loaded = 0
    for cookie in cookies:
        try:
            # 移除可能导致问题的字段
            for key in ["sameSite", "httpOnly", "secure", "expiry", "storeId"]:
                cookie.pop(key, None)
            driver.add_cookie(cookie)
            loaded += 1
        except Exception:
            pass

    print(f"✅ 已加载 {loaded}/{len(cookies)} 条cookie")
    return loaded > 0


# ============ 登录 ============

def login():
    """首次登录，弹出浏览器让用户手动登录"""
    print("=" * 50)
    print("  BOSS直聘登录")
    print("=" * 50)
    print()
    print("🌐 正在打开浏览器，请在浏览器中完成登录...")
    print("   1. 扫码或输入手机号登录")
    print("   2. 登录成功后，回到终端按回车")
    print()

    driver = create_driver(headless=False, minimized=False)
    driver.get("https://www.zhipin.com/web/user/?ka=header-login")

    # 等待用户操作
    if is_windows():
        print("⏳ 登录完成后请按回车键继续...")
    else:
        print("⏳ 登录完成后请按回车键继续...")
    input()

    # 验证登录状态
    driver.get("https://www.zhipin.com")
    time.sleep(3)
    page_source = driver.page_source

    if "我的" in page_source or "nav-figure" in page_source or "user-info" in page_source:
        save_cookies(driver)
        print("✅ 登录成功！后续抓取无需再次登录。")
    else:
        print("⚠️ 未检测到登录状态，请重试 --login")

    driver.quit()


# ============ 抓取 ============

def search_jobs(keyword, city="北京", pages=2):
    """使用API抓取岗位列表"""
    city_code = CITY_CODES.get(city, "101010100")
    all_jobs = []

    print(f"🔍 BOSS直聘搜索：{keyword} | 城市：{city} | 页数：{pages}")

    # 使用headed模式但窗口移出屏幕（避免被反爬检测）
    driver = create_driver(headless=False, minimized=True)

    # 加载cookie
    if not load_cookies(driver):
        driver.quit()
        return []

    for page in range(1, pages + 1):
        # 使用BOSS直聘内部API
        api_url = (
            f"https://www.zhipin.com/wapi/zpgeek/search/joblist.json?"
            f"scene=1&query={quote(keyword)}&city={city_code}"
            f"&experience=&payType=&partTime=&degree=&industry=&scale="
            f"&stage=&position=&salary=&multiBusinessDistrict=&multiSubway="
            f"&page={page}&pageSize=30"
        )

        driver.get(api_url)
        time.sleep(3)

        try:
            # 尝试解析JSON响应
            body_text = driver.find_element(By.TAG_NAME, "pre").text
            data = json.loads(body_text)

            if data.get("code") == 0:
                job_list = data.get("zpData", {}).get("jobList", [])
                print(f"  📄 第{page}页：获取 {len(job_list)} 条岗位")

                for job in job_list:
                    job_info = {
                        "id": f"boss-{job.get('encryptJobId', '')}",
                        "title": job.get("jobName", ""),
                        "company": job.get("brandName", ""),
                        "salary": job.get("salaryDesc", ""),  # 通常为空
                        "location": (job.get("cityName", "") or "") + (job.get("areaDistrict", "") or ""),
                        "experience": job.get("jobExperience", ""),
                        "education": job.get("jobDegree", ""),
                        "source": "BOSS直聘",
                        "source_url": f"https://www.zhipin.com/job_detail/{job.get('encryptJobId', '')}.html",
                        "skills": job.get("skillTags", []),
                        "company_size": job.get("brandScaleName", ""),
                        "industry": job.get("brandIndustryName", ""),
                        "benefits": job.get("welfareList", []),
                        "job_desc": "",
                        "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
                    }
                    all_jobs.append(job_info)
            else:
                msg = data.get("message", "未知")
                print(f"  ⚠️ 第{page}页API返回错误：{msg}")
                if "login" in msg.lower() or "安全" in msg:
                    print("  💡 Cookie可能已过期，请重新运行 --login")
                    break

        except Exception as e:
            print(f"  ❌ 第{page}页解析失败：{e}")

            # 回退方案：从搜索结果页HTML提取
            try:
                search_url = f"https://www.zhipin.com/web/geek/job?query={quote(keyword)}&city={city_code}&page={page}"
                driver.get(search_url)
                time.sleep(3)
                jobs_from_page = driver.execute_script("""
                    var cards = document.querySelectorAll('.job-card-wrapper');
                    var results = [];
                    cards.forEach(function(card) {
                        var title = card.querySelector('.job-name')?.innerText || '';
                        var company = card.querySelector('.company-name a')?.innerText || '';
                        var area = card.querySelector('.job-area')?.innerText || '';
                        var salary = card.querySelector('.salary')?.innerText || '';
                        var tags = card.querySelectorAll('.tag-list li');
                        var tagList = [];
                        tags.forEach(function(t) { tagList.push(t.innerText); });
                        results.push({
                            title: title, company: company,
                            salary: salary, location: area, skills: tagList
                        });
                    });
                    return results;
                """)
                if jobs_from_page:
                    print(f"  📄 第{page}页（HTML回退）：获取 {len(jobs_from_page)} 条岗位")
                    for j in jobs_from_page:
                        j.update({
                            "id": f"boss-html-{len(all_jobs)}",
                            "source": "BOSS直聘",
                            "experience": "", "education": "",
                            "source_url": "", "company_size": "",
                            "industry": "", "benefits": [],
                            "job_desc": "",
                            "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
                        })
                        all_jobs.append(j)
            except Exception as e2:
                print(f"  ❌ HTML回退也失败：{e2}")

        time.sleep(2)  # 礼貌延迟

    driver.quit()

    # 保存结果
    output_dir = get_script_dir()
    output_file = os.path.join(output_dir, f"boss-{keyword}-{city}.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(all_jobs, f, ensure_ascii=False, indent=2)
    print(f"\n✅ 共获取 {len(all_jobs)} 条岗位，保存至 {output_file}")

    return all_jobs


# ============ 主入口 ============

def main():
    parser = argparse.ArgumentParser(description="BOSS直聘岗位抓取工具")
    parser.add_argument("--login", action="store_true", help="首次登录，保存cookie")
    parser.add_argument("--keyword", type=str, help="搜索关键词")
    parser.add_argument("--city", type=str, default="北京", help="城市（默认北京）")
    parser.add_argument("--pages", type=int, default=2, help="抓取页数（默认2页）")
    args = parser.parse_args()

    if args.login:
        login()
    elif args.keyword:
        search_jobs(args.keyword, args.city, args.pages)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
