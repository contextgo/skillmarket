#!/usr/bin/env python3
"""
猎聘网/智联招聘岗位抓取脚本
============================

使用 web_fetch 或 requests 直接抓取，无需浏览器，无需登录。
跨平台支持：macOS / Windows / Linux

依赖：
  pip3 install requests beautifulsoup4

使用方式：
  # 猎聘抓取
  python3 scrape-liepin-zhaopin.py --platform liepin --keyword "教学督导" --city "北京"

  # 智联招聘抓取
  python3 scrape-liepin-zhaopin.py --platform zhaopin --keyword "教学督导" --city "北京"

  # 指定页数
  python3 scrape-liepin-zhaopin.py --platform liepin --keyword "课程研发" --city "北京" --pages 3

  # 输出为JSON
  python3 scrape-liepin-zhaopin.py --platform liepin --keyword "感统教研" --city "北京" --output jobs.json
"""

import json
import time
import argparse
import os
import re
import sys
from urllib.parse import quote

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("❌ 请先安装依赖：pip3 install requests beautifulsoup4")
    print("   或运行：python3 scripts/check-env.py")
    sys.exit(1)


# ============ 城市代码映射 ============

LIEPIN_CITY_CODES = {
    "北京": "bj", "上海": "sh", "广州": "gz", "深圳": "sz",
    "杭州": "hz", "成都": "cd", "南京": "nj", "武汉": "wh",
    "西安": "xa", "重庆": "cq", "天津": "tj", "苏州": "sz2",
    "长沙": "cs", "郑州": "zz", "东莞": "dg", "沈阳": "sy",
    "青岛": "qd", "合肥": "hf", "佛山": "fs", "昆明": "km",
    "大连": "dl", "福州": "fz", "厦门": "xm", "哈尔滨": "heb",
    "济南": "jn", "温州": "wz", "南宁": "nn", "长春": "cc",
    "泉州": "qz", "石家庄": "sjz", "贵阳": "gy", "南昌": "nc",
    "金华": "jh", "常州": "cz", "惠州": "hz2", "嘉兴": "jx",
    "徐州": "xz", "南通": "nt", "太原": "ty", "保定": "bd",
    "珠海": "zh", "中山": "zs", "兰州": "lz", "台州": "tz",
    "烟台": "yt", "银川": "yc", "汕头": "st", "湖州": "huz",
    "潍坊": "wf", "洛阳": "ly",
}

ZHAOPIN_CITY_CODES = {
    "北京": "530", "上海": "538", "广州": "763", "深圳": "765",
    "杭州": "653", "成都": "801", "南京": "635", "武汉": "736",
    "西安": "854", "重庆": "854", "天津": "531", "苏州": "636",
    "长沙": "749", "郑州": "719", "东莞": "768", "沈阳": "565",
    "青岛": "609", "合肥": "571", "佛山": "769", "昆明": "782",
    "大连": "588", "福州": "681", "厦门": "682", "哈尔滨": "586",
    "济南": "613", "温州": "667", "南宁": "770", "长春": "591",
    "石家庄": "548", "贵阳": "785", "南昌": "660", "兰州": "807",
    "太原": "563", "珠海": "775", "中山": "771",
}


# ============ HTTP请求工具 ============

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}


def fetch_page(url, encoding="utf-8"):
    """获取页面HTML"""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.encoding = encoding
        return resp.text
    except requests.RequestException as e:
        print(f"  ❌ 请求失败：{e}")
        return None


# ============ 猎聘抓取 ============

def scrape_liepin(keyword, city="北京", pages=2):
    """抓取猎聘网岗位列表"""
    city_code = LIEPIN_CITY_CODES.get(city, "bj")
    all_jobs = []

    print(f"🔍 猎聘搜索：{keyword} | 城市：{city} | 页数：{pages}")

    for page in range(1, pages + 1):
        url = f"https://www.liepin.com/city-{city_code}/zp{quote(keyword)}/?currentPage={page}"
        html = fetch_page(url)
        if not html:
            continue

        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select("div.job-detail-wrap") or soup.select("div.so-job-item") or soup.select("[class*='job-card']")

        if not cards:
            # 尝试更宽松的选择器
            cards = soup.find_all("div", class_=re.compile(r"job.*card|job.*item|job.*detail", re.I))

        page_count = 0
        for card in cards:
            try:
                job = _parse_liepin_card(card)
                if job and job.get("title"):
                    all_jobs.append(job)
                    page_count += 1
            except Exception:
                continue

        print(f"  📄 第{page}页：获取 {page_count} 条岗位")
        time.sleep(1.5)  # 礼貌延迟

    return all_jobs


def _parse_liepin_card(card):
    """解析猎聘单个岗位卡片"""
    def get_text(selector):
        el = card.select_one(selector)
        return el.get_text(strip=True) if el else ""

    def get_attr(selector, attr):
        el = card.select_one(selector)
        return el.get(attr, "") if el else ""

    title = get_text(".job-title") or get_text("h3") or get_text("[class*='title']")
    company = get_text(".company-name") or get_text("[class*='company-name']") or get_text(".employer-name")
    salary = get_text(".job-salary") or get_text("[class*='salary']")
    area = get_text(".job-area") or get_text("[class*='area']") or get_text("[class*='district']")
    edu = get_text("[class*='edu']") or get_text("[class*='degree']")
    exp = get_text("[class*='experience']") or get_text("[class*='year']")

    # 从标签列表提取
    tags = [t.get_text(strip=True) for t in card.select(".tag-list li, [class*='tag'] li, [class*='label'] span")]

    # 链接
    link = get_attr("a[href*='job']", "href") or get_attr("a", "href")
    if link and not link.startswith("http"):
        link = "https://www.liepin.com" + link

    return {
        "id": f"lp-{hash(title+company) % 10000:04d}",
        "title": title,
        "company": company,
        "salary": salary,
        "location": area,
        "experience": exp,
        "education": edu,
        "source": "猎聘",
        "source_url": link,
        "skills": tags,
        "company_size": "",
        "industry": "",
        "benefits": "",
        "job_desc": "",
        "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
    }


# ============ 智联招聘抓取 ============

def scrape_zhaopin(keyword, city="北京", pages=2):
    """抓取智联招聘岗位列表"""
    city_code = ZHAOPIN_CITY_CODES.get(city, "530")
    all_jobs = []

    print(f"🔍 智联搜索：{keyword} | 城市：{city} | 页数：{pages}")

    for page in range(1, pages + 1):
        url = f"https://sou.zhaopin.com/?jl={city_code}&kw={quote(keyword)}&p={page}"
        html = fetch_page(url)
        if not html:
            continue

        soup = BeautifulSoup(html, "html.parser")

        # 智联招聘的岗位卡片
        cards = soup.select("div.joblist-box__item") or soup.select("div.positionlist__item") or soup.select("[class*='job-item']")

        if not cards:
            cards = soup.find_all("div", class_=re.compile(r"job.*item|position.*item", re.I))

        page_count = 0
        for card in cards:
            try:
                job = _parse_zhaopin_card(card)
                if job and job.get("title"):
                    all_jobs.append(job)
                    page_count += 1
            except Exception:
                continue

        print(f"  📄 第{page}页：获取 {page_count} 条岗位")
        time.sleep(1.5)

    return all_jobs


def _parse_zhaopin_card(card):
    """解析智联单个岗位卡片"""
    def get_text(selector):
        el = card.select_one(selector)
        return el.get_text(strip=True) if el else ""

    def get_attr(selector, attr):
        el = card.select_one(selector)
        return el.get(attr, "") if el else ""

    title = get_text("[class*='title']") or get_text("a span")
    company = get_text("[class*='company'] a") or get_text("[class*='company-name']")
    salary = get_text("[class*='salary']") or get_text("[class*='pay']")
    area = get_text("[class*='area']") or get_text("[class*='location']")
    edu = get_text("[class*='edu']") or get_text("[class*='degree']")
    exp = get_text("[class*='exp']") or get_text("[class*='experience']")

    tags = [t.get_text(strip=True) for t in card.select("[class*='tag'] span, [class*='label'] li")]

    link = get_attr("a[href*='jobs']", "href") or get_attr("a", "href")
    if link and not link.startswith("http"):
        link = "https://www.zhaopin.com" + link

    return {
        "id": f"zl-{hash(title+company) % 10000:04d}",
        "title": title,
        "company": company,
        "salary": salary,
        "location": area,
        "experience": exp,
        "education": edu,
        "source": "智联招聘",
        "source_url": link,
        "skills": tags,
        "company_size": "",
        "industry": "",
        "benefits": "",
        "job_desc": "",
        "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
    }


# ============ 主入口 ============

def main():
    parser = argparse.ArgumentParser(description="猎聘网/智联招聘岗位抓取工具")
    parser.add_argument("--platform", choices=["liepin", "zhaopin"], required=True, help="平台选择")
    parser.add_argument("--keyword", type=str, required=True, help="搜索关键词")
    parser.add_argument("--city", type=str, default="北京", help="城市（默认北京）")
    parser.add_argument("--pages", type=int, default=2, help="抓取页数（默认2页）")
    parser.add_argument("--output", type=str, help="输出JSON文件路径")
    args = parser.parse_args()

    if args.platform == "liepin":
        jobs = scrape_liepin(args.keyword, args.city, args.pages)
    else:
        jobs = scrape_zhaopin(args.keyword, args.city, args.pages)

    print(f"\n✅ 共获取 {len(jobs)} 条岗位")

    if args.output and jobs:
        output_path = args.output
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(jobs, f, ensure_ascii=False, indent=2)
        print(f"📁 已保存至 {output_path}")
    elif jobs:
        # 默认保存到脚本同级目录
        output_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(output_dir, f"{args.platform}-{args.keyword}-{args.city}.json")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(jobs, f, ensure_ascii=False, indent=2)
        print(f"📁 已保存至 {output_path}")

    return jobs


if __name__ == "__main__":
    main()
