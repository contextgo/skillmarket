#!/usr/bin/env python3
"""
社交平台+搜索引擎招聘信息抓取脚本
==================================

抓取小红书/知乎/脉脉的招聘帖和公司评价，以及事业单位/编制/人才引进信息。
跨平台支持：macOS / Windows / Linux

依赖：
  pip3 install requests beautifulsoup4

使用方式：
  # 小红书搜索
  python3 scrape-social.py --platform xiaohongshu --keyword "特教 招聘 北京"

  # 知乎搜索
  python3 scrape-social.py --platform zhihu --keyword "儿童康复 招聘"

  # 脉脉搜索（公司评价）
  python3 scrape-social.py --platform maimai --keyword "XX公司 薪资"

  # 事业单位/编制搜索
  python3 scrape-social.py --platform gov --keyword "特殊教育 事业单位 北京"

  # 人才引进搜索
  python3 scrape-social.py --platform talent --keyword "北京 人才引进 心理学"

  # 高校人才网直接抓取
  python3 scrape-social.py --platform gaoxiao --keyword "特殊教育"

注意：
  - 社交平台信息来自搜索引擎索引，非平台直连
  - 信息质量取决于搜索结果，建议作为辅助信息源
  - 事业单位信息可能有时效性，注意发布日期
"""

import json
import time
import argparse
import os
import sys
import re

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("❌ 请先安装依赖：pip3 install requests beautifulsoup4")
    print("   或运行：python3 scripts/check-env.py")
    sys.exit(1)


# ============ 通用工具 ============

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}


def fetch_page(url, encoding="utf-8"):
    """获取页面HTML"""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.encoding = encoding
        return resp.text
    except requests.RequestException as e:
        print(f"  ❌ 请求失败：{e}")
        return None


def clean_text(text):
    """清理文本：去除多余空白"""
    if not text:
        return ""
    return re.sub(r'\s+', ' ', text).strip()


# ============ 小红书 ============

def scrape_xiaohongshu(keyword):
    """通过搜索引擎抓取小红书招聘相关帖子"""
    print(f"🔍 小红书搜索：{keyword}")
    results = []

    # 通过Bing搜索小红书内容（比Google更容易抓取）
    search_url = f"https://www.bing.com/search?q=site%3Axiaohongshu.com+{keyword}"
    html = fetch_page(search_url)
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    # Bing搜索结果
    for item in soup.select(".b_algo"):
        try:
            title_el = item.select_one("h2 a")
            snippet_el = item.select_one(".b_caption p")

            if not title_el:
                continue

            title = clean_text(title_el.get_text())
            url = title_el.get("href", "")
            snippet = clean_text(snippet_el.get_text()) if snippet_el else ""

            if "xiaohongshu.com" not in url:
                continue

            results.append({
                "id": f"xhs-{len(results):04d}",
                "title": title,
                "content": snippet,
                "source": "小红书",
                "source_url": url,
                "type": "招聘/评价",
                "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            continue

    print(f"  📄 获取 {len(results)} 条小红书帖子")
    return results


# ============ 知乎 ============

def scrape_zhihu(keyword):
    """通过搜索引擎抓取知乎招聘/评价帖子"""
    print(f"🔍 知乎搜索：{keyword}")
    results = []

    search_url = f"https://www.bing.com/search?q=site%3Azhihu.com+{keyword}"
    html = fetch_page(search_url)
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    for item in soup.select(".b_algo"):
        try:
            title_el = item.select_one("h2 a")
            snippet_el = item.select_one(".b_caption p")

            if not title_el:
                continue

            title = clean_text(title_el.get_text())
            url = title_el.get("href", "")
            snippet = clean_text(snippet_el.get_text()) if snippet_el else ""

            if "zhihu.com" not in url:
                continue

            results.append({
                "id": f"zh-{len(results):04d}",
                "title": title,
                "content": snippet,
                "source": "知乎",
                "source_url": url,
                "type": "招聘/评价",
                "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            continue

    print(f"  📄 获取 {len(results)} 条知乎帖子")
    return results


# ============ 脉脉 ============

def scrape_maimai(keyword):
    """通过搜索引擎抓取脉脉公司评价"""
    print(f"🔍 脉脉搜索：{keyword}")
    results = []

    search_url = f"https://www.bing.com/search?q=site%3Amaimai.cn+{keyword}"
    html = fetch_page(search_url)
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    for item in soup.select(".b_algo"):
        try:
            title_el = item.select_one("h2 a")
            snippet_el = item.select_one(".b_caption p")

            if not title_el:
                continue

            title = clean_text(title_el.get_text())
            url = title_el.get("href", "")
            snippet = clean_text(snippet_el.get_text()) if snippet_el else ""

            if "maimai.cn" not in url:
                continue

            results.append({
                "id": f"mm-{len(results):04d}",
                "title": title,
                "content": snippet,
                "source": "脉脉",
                "source_url": url,
                "type": "公司评价/薪资",
                "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            continue

    print(f"  📄 获取 {len(results)} 条脉脉帖子")
    return results


# ============ 事业单位/编制 ============

def scrape_gov(keyword):
    """搜索事业单位/编制招聘信息"""
    print(f"🔍 事业单位搜索：{keyword}")
    results = []

    # 搜索引擎方式
    search_url = f"https://www.bing.com/search?q={keyword}+招聘+事业单位+编制"
    html = fetch_page(search_url)
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    for item in soup.select(".b_algo"):
        try:
            title_el = item.select_one("h2 a")
            snippet_el = item.select_one(".b_caption p")

            if not title_el:
                continue

            title = clean_text(title_el.get_text())
            url = title_el.get("href", "")
            snippet = clean_text(snippet_el.get_text()) if snippet_el else ""

            # 过滤明显无关结果
            irrelevant = ["淘宝", "京东", "拼多多", "下载", "游戏"]
            if any(word in title for word in irrelevant):
                continue

            results.append({
                "id": f"gov-{len(results):04d}",
                "title": title,
                "content": snippet,
                "source": "政府/事业单位",
                "source_url": url,
                "type": "事业单位/编制",
                "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            continue

    print(f"  📄 获取 {len(results)} 条事业单位信息")
    return results


# ============ 人才引进 ============

def scrape_talent(keyword):
    """搜索人才引进政策信息"""
    print(f"🔍 人才引进搜索：{keyword}")
    results = []

    search_url = f"https://www.bing.com/search?q={keyword}+人才引进+政策"
    html = fetch_page(search_url)
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    for item in soup.select(".b_algo"):
        try:
            title_el = item.select_one("h2 a")
            snippet_el = item.select_one(".b_caption p")

            if not title_el:
                continue

            title = clean_text(title_el.get_text())
            url = title_el.get("href", "")
            snippet = clean_text(snippet_el.get_text()) if snippet_el else ""

            irrelevant = ["淘宝", "京东", "拼多多", "下载", "游戏"]
            if any(word in title for word in irrelevant):
                continue

            results.append({
                "id": f"talent-{len(results):04d}",
                "title": title,
                "content": snippet,
                "source": "人才引进",
                "source_url": url,
                "type": "人才引进/政策",
                "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            continue

    print(f"  📄 获取 {len(results)} 条人才引进信息")
    return results


# ============ 高校人才网 ============

def scrape_gaoxiao(keyword):
    """直接抓取高校人才网"""
    print(f"🔍 高校人才网搜索：{keyword}")
    results = []

    search_url = f"https://www.gaoxiaojob.com/search/index.html?keyword={keyword}"
    html = fetch_page(search_url, encoding="utf-8")
    if not html:
        # 回退到搜索引擎
        search_url = f"https://www.bing.com/search?q=site%3Agaoxiaojob.com+{keyword}"
        html = fetch_page(search_url)
        if not html:
            return results

        soup = BeautifulSoup(html, "html.parser")
        for item in soup.select(".b_algo"):
            try:
                title_el = item.select_one("h2 a")
                snippet_el = item.select_one(".b_caption p")
                if not title_el:
                    continue
                title = clean_text(title_el.get_text())
                url = title_el.get("href", "")
                snippet = clean_text(snippet_el.get_text()) if snippet_el else ""
                results.append({
                    "id": f"gx-{len(results):04d}",
                    "title": title,
                    "content": snippet,
                    "source": "高校人才网",
                    "source_url": url,
                    "type": "事业单位/高校",
                    "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
                })
            except Exception:
                continue
    else:
        # 直接解析高校人才网页面
        soup = BeautifulSoup(html, "html.parser")
        for item in soup.select(".search-result-item, .job-item, [class*='result']"):
            try:
                title_el = item.select_one("a")
                snippet_el = item.select_one("p, .desc, [class*='summary']")
                if not title_el:
                    continue
                title = clean_text(title_el.get_text())
                url = title_el.get("href", "")
                if url and not url.startswith("http"):
                    url = "https://www.gaoxiaojob.com" + url
                snippet = clean_text(snippet_el.get_text()) if snippet_el else ""
                results.append({
                    "id": f"gx-{len(results):04d}",
                    "title": title,
                    "content": snippet,
                    "source": "高校人才网",
                    "source_url": url,
                    "type": "事业单位/高校",
                    "crawl_time": time.strftime("%Y-%m-%d %H:%M"),
                })
            except Exception:
                continue

    print(f"  📄 获取 {len(results)} 条高校人才网信息")
    return results


# ============ 主入口 ============

PLATFORMS = {
    "xiaohongshu": ("小红书", scrape_xiaohongshu),
    "zhihu": ("知乎", scrape_zhihu),
    "maimai": ("脉脉", scrape_maimai),
    "gov": ("事业单位", scrape_gov),
    "talent": ("人才引进", scrape_talent),
    "gaoxiao": ("高校人才网", scrape_gaoxiao),
}


def main():
    parser = argparse.ArgumentParser(description="社交平台+搜索引擎招聘信息抓取")
    parser.add_argument("--platform",
                       choices=list(PLATFORMS.keys()),
                       required=True,
                       help="平台选择")
    parser.add_argument("--keyword", type=str, required=True, help="搜索关键词")
    parser.add_argument("--output", type=str, help="输出JSON文件路径")
    args = parser.parse_args()

    _, scrape_func = PLATFORMS[args.platform]
    results = scrape_func(args.keyword)

    print(f"\n✅ 共获取 {len(results)} 条信息")

    if args.output and results:
        output_path = args.output
    elif results:
        output_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(output_dir, f"{args.platform}-{args.keyword}.json")
    else:
        return

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"📁 已保存至 {output_path}")


if __name__ == "__main__":
    main()
