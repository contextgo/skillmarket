#!/usr/bin/env python3
"""
环境依赖检查与自动安装脚本
============================

用途：检查本skill所需的所有依赖是否已安装，缺失的自动安装。
      在skill首次使用前由Agent自动调用。

跨平台支持：macOS / Windows / Linux

使用方式：
  python3 check-env.py          # 检查并自动安装缺失依赖
  python3 check-env.py --check  # 仅检查，不安装
"""

import sys
import subprocess
import platform
import importlib
import os

# ============ 依赖定义 ============

# Python包依赖（pip安装）
PIP_DEPS = [
    ("requests", "requests"),
    ("beautifulsoup4", "bs4"),
]

# BOSS直聘专用依赖（仅在用户需要BOSS抓取时安装）
BOSS_DEPS = [
    ("undetected-chromedriver", "undetected_chromedriver"),
    ("selenium", "selenium"),
]

# Node.js依赖（npm安装，用于部分抓取脚本）
NPM_DEPS = []  # 当前无npm依赖，预留


def is_windows():
    return platform.system() == "Windows"


def run_cmd(cmd, check=True):
    """执行命令，返回stdout"""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=check,
            shell=is_windows()
        )
        return result.returncode == 0, result.stdout.strip()
    except subprocess.CalledProcessError:
        return False, ""
    except FileNotFoundError:
        return False, f"Command not found: {cmd}"


def check_python_version():
    """检查Python版本 >= 3.8"""
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        return True, f"Python {version.major}.{version.minor}.{version.micro} ✅"
    return False, f"Python {version.major}.{version.minor}.{version.micro} ❌ (需要 >= 3.8)"


def check_pip_package(pip_name, import_name):
    """检查单个pip包是否已安装"""
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        return False


def install_pip_package(pip_name):
    """安装pip包"""
    cmd = [sys.executable, "-m", "pip", "install", pip_name, "--quiet"]
    if is_windows():
        cmd_str = f'"{sys.executable}" -m pip install {pip_name} --quiet'
        ok, _ = run_cmd(cmd_str)
    else:
        ok, _ = run_cmd(cmd)
    return ok


def check_chrome():
    """检查Chrome/Chromium浏览器是否安装"""
    if is_windows():
        chrome_paths = [
            os.path.join(os.environ.get("PROGRAMFILES", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
        ]
        for p in chrome_paths:
            if os.path.exists(p):
                return True, f"Chrome found: {p}"
        return False, "Chrome not found"
    else:
        # macOS / Linux
        ok, path = run_cmd(["which", "google-chrome"] if not is_windows() else "where chrome")
        if ok:
            return True, f"Chrome found: {path}"
        ok, path = run_cmd(["which", "chromium"] if not is_windows() else "where chromium")
        if ok:
            return True, f"Chromium found: {path}"
        # macOS default location
        chrome_mac = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(chrome_mac):
            return True, f"Chrome found: {chrome_mac}"
        return False, "Chrome/Chromium not found"


def main():
    """主检查流程"""
    install_mode = "--check" not in sys.argv

    print("=" * 50)
    print("  AI Job Hunter — 环境依赖检查")
    print("=" * 50)
    print()

    all_ok = True

    # 1. Python版本
    ok, msg = check_python_version()
    print(f"  Python版本: {msg}")
    if not ok:
        all_ok = False
        print("  ❌ 请安装 Python 3.8+")
    print()

    # 2. 基础pip包
    print("  基础依赖（猎聘/智联/社交平台/搜索抓取）：")
    missing_basic = []
    for pip_name, import_name in PIP_DEPS:
        installed = check_pip_package(pip_name, import_name)
        status = "✅" if installed else "❌ 未安装"
        print(f"    {pip_name}: {status}")
        if not installed:
            missing_basic.append(pip_name)

    if missing_basic and install_mode:
        print(f"\n  正在自动安装基础依赖：{', '.join(missing_basic)}")
        for pkg in missing_basic:
            ok = install_pip_package(pkg)
            status = "✅" if ok else "❌"
            print(f"    {pkg}: {status}")
            if not ok:
                all_ok = False
    elif missing_basic and not install_mode:
        all_ok = False
        print(f"\n  ⚠️ 缺失依赖：{', '.join(missing_basic)}")
        print(f"  运行 python3 check-env.py 自动安装")
    print()

    # 3. BOSS直聘专用依赖（可选）
    print("  BOSS直聘依赖（可选，仅抓取BOSS时需要）：")
    missing_boss = []
    for pip_name, import_name in BOSS_DEPS:
        installed = check_pip_package(pip_name, import_name)
        status = "✅" if installed else "❌ 未安装（可选）"
        print(f"    {pip_name}: {status}")
        if not installed:
            missing_boss.append(pip_name)

    if missing_boss and install_mode:
        print(f"\n  是否安装BOSS直聘依赖？[y/N] ", end="")
        try:
            answer = input().strip().lower()
        except EOFError:
            answer = "n"
        if answer == "y":
            for pkg in missing_boss:
                ok = install_pip_package(pkg)
                status = "✅" if ok else "❌"
                print(f"    {pkg}: {status}")
    print()

    # 4. Chrome浏览器（BOSS抓取需要）
    if not missing_boss or install_mode:
        ok, msg = check_chrome()
        chrome_status = f"✅ {msg}" if ok else f"⚠️ {msg}（仅BOSS抓取需要）"
        print(f"  Chrome浏览器: {chrome_status}")
        if not ok and not missing_boss:
            print("  💡 如需抓取BOSS直聘，请先安装Chrome浏览器")
    print()

    # 5. Node.js（预留）
    ok, version = run_cmd(["node", "--version"] if not is_windows() else "node --version")
    print(f"  Node.js: {'✅ ' + version if ok else '⚠️ 未安装（当前无影响）'}")
    print()

    # 汇总
    print("=" * 50)
    if all_ok:
        print("  ✅ 基础环境就绪！")
        if missing_boss:
            print("  ℹ️  BOSS直聘抓取需要额外依赖，运行 check-env.py 按提示安装")
    else:
        print("  ❌ 部分依赖缺失，请运行: python3 check-env.py")
    print("=" * 50)

    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
