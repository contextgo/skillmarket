# Available Skills

## bill-manager

账单整理归类 skill

**使用方式：**
- 录入账单：直接粘贴账单文字
- 查询账单：说「查账单」
- 账单统计：说「账单统计」

详细文档：[skills/bill-manager.md](skills/bill-manager.md)
