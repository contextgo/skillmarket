---
name: ai-research-ideation
description: "This skill should be used when users want help with AI/ML research ideation, including: exploring research ideas, conducting Socratic dialogue about ideas, reviewing papers for inspiration, designing experiments, writing research papers, or discussing cross-disciplinary AI applications. It provides curated system prompts and user prompt templates for researchers to collaborate with AI on developing research ideas, reviewing literature, designing experiments, and writing papers."
---

# AI Research Ideation Skill

帮助研究者与 AI 高效协作进行科研创意开发、文献分析、实验设计和论文写作的技能集合。

## 技能概览

本技能包含 6 大类共 18 个科研协作 prompt，覆盖科研 idea 开发的完整生命周期：

| 类别 | 数量 | 用途 |
|------|------|------|
| Idea 探讨类 | 4 | 与 AI 深度讨论、打磨研究想法 |
| 文献驱动类 | 3 | 从论文中挖掘新方向 |
| 批判性评审类 | 3 | 模拟审稿人预审 idea |
| 实验设计类 | 3 | 规划实验方案和基线 |
| 跨学科融合类 | 3 | AI for Science 方向探索 |
| 科研写作辅助类 | 2 | 构建论文引言和贡献点 |

## 使用方式

当用户提供一个科研相关任务时，从 references/ 目录中找到对应的 prompt 文件，将其中的 System Prompt 和 User Prompt 模板呈现给用户。

### 快速选择指南

**用户想做什么？**

1. **探索一个模糊的 idea** → `idea-discussion/zh/01-深度-Idea-探索对话.md`
2. **用苏格拉底法挖掘 idea 深层逻辑** → `idea-discussion/zh/02-苏格拉底式科研对话.md`
3. **压力测试 idea 找致命弱点** → `idea-discussion/zh/03-Idea-压力测试.md`
4. **找领域空白和潜在方向** → `idea-discussion/zh/04-研究空白发现器.md`
5. **从一篇论文启发新 idea** → `literature-driven/zh/01-从论文到新-Idea.md`
6. **综合多篇论文找交叉点** → `literature-driven/zh/02-多论文综合创意生成.md`
7. **预测领域发展趋势** → `literature-driven/zh/03-研究趋势外推.md`
8. **模拟顶会审稿** → `critical-review/zh/01-顶会审稿人模拟.md`
9. **对抗性挑战假设** → `critical-review/zh/02-对抗性假设挑战者.md`
10. **审计隐含假设** → `critical-review/zh/03-假设审计员.md`
11. **设计完整实验方案** → `experiment-design/zh/01-实验蓝图设计.md`
12. **设计消融实验** → `experiment-design/zh/02-消融实验设计专家.md`
13. **选择和对比基线** → `experiment-design/zh/03-基线方法选择助手.md`
14. **探索 AI for Science 方向** → `interdisciplinary/zh/01-AI for Science 创意生成器.md`
15. **跨领域知识迁移** → `interdisciplinary/zh/02-跨领域知识桥接.md`
16. **物理信息机器学习** → `interdisciplinary/zh/03-物理与机器学习融合.md`
17. **写论文引言** → `writing-assistance/zh/01-论文引言结构师.md`
18. **提炼贡献点** → `writing-assistance/zh/02-贡献点提炼助手.md`

## Prompt 文件结构

每个 prompt 文件包含：

1. **概述** - 何时使用，适用阶段
2. **系统提示词 (System Prompt)** - AI 的角色定义和行为准则，直接复制到 AI 对话框的系统指令栏
3. **用户提示词模板 (User Prompt Template)** - 带占位符的用户输入模板
4. **示例对话** - 展示预期输出格式
5. **使用技巧** - 最大化效果的实践建议
6. **标签** - 便于检索

## 英文版

references/ 目录下同时包含英文原版 prompt，位于各分类根目录（如 `idea-discussion/01-deep-idea-exploration.md`），中文版本位于 `zh/` 子目录（如 `idea-discussion/zh/01-深度-Idea-探索对话.md`）。

## 协作流程建议

根据 idea 成熟度推荐工作流：

**早期阶段（想法模糊）**
1. 使用 `01-深度-Idea-探索对话` 结构化模糊直觉
2. 使用 `02-苏格拉底式科研对话` 深入挖掘
3. 使用 `04-研究空白发现器` 定位机会

**中期阶段（想法成型）**
4. 使用 `01-从论文到新-Idea` 或 `02-多论文综合创意生成` 验证创新性
5. 使用 `03-Idea-压力测试` 或 `01-顶会审稿人模拟` 找弱点

**实施阶段（准备实验）**
6. 使用 `01-实验蓝图设计` 规划实验
7. 使用 `02-消融实验设计专家` 完善消融
8. 使用 `03-基线方法选择助手` 选择对比方法

**写作阶段**
9. 使用 `01-论文引言结构师` 构建引言
10. 使用 `02-贡献点提炼助手` 精炼贡献
