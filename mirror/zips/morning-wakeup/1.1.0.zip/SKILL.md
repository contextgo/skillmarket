---
name: morning-wakeup
description: Morning wake-up automation that fetches today's weather and matches a Sonos playback preset. Use when setting up daily alarm routines, weather-driven music wake-ups, or scheduling morning Sonos automation.
metadata:
  {
    "openclaw":
      {
        "emoji": "🌅",
        "requires": { "bins": ["sonos"] },
        "install":
          [
            {
              "id": "go",
              "kind": "go",
              "module": "github.com/steipete/sonoscli/cmd/sonos@latest",
              "bins": ["sonos"],
              "label": "Install sonoscli (go)",
            },
          ],
      },
  }
---

# Morning Wake-Up

Automated morning routine: fetch the day's weather, pick a matching Sonos preset, and start playback.

## When to Use

✅ **USE this skill when:**

- "Set up my morning wake-up routine"
- "Schedule a weather-based alarm"
- "Play morning music based on the weather"
- "Create a daily wake-up automation"

❌ **DON'T use this skill when:**

- Manual Sonos control (use sonoscli directly)
- One-off weather queries (use weather skill)
- Non-morning automation scenarios

## How It Works

1. **Fetch weather** for the configured location via Open-Meteo API (no API key needed).
2. **Classify weather** into a category: `sunny`, `cloudy`, `rainy`, `snowy`, `stormy`.
3. **Match a Sonos preset** from the configured preset map (weather category → Sonos favorite name).
4. **Play the preset** on the target speaker at the configured volume.

## Configuration

All configuration lives in `references/presets.json`:

```json
{
  "location": "Shanghai",
  "speaker": "Bedroom",
  "volume": 12,
  "presets": {
    "sunny": "Morning Sunshine Playlist",
    "cloudy": "Chill Morning Acoustic",
    "rainy": "Rainy Day Jazz",
    "snowy": "Cozy Winter Morning",
    "stormy": "Calm Piano"
  },
  "fallback_preset": "Chill Morning Acoustic",
  "schedule": "0 7 * * *"
}
```

| Field | Description |
|---|---|
| `location` | City name or "lat,lon" for weather lookup |
| `speaker` | Sonos speaker name |
| `volume` | Start volume (0-100) |
| `presets` | Weather category → Sonos favorite name |
| `fallback_preset` | Used when weather doesn't match any category |
| `schedule` | Cron expression for the daily run (default: 7:00 AM) |

## Commands

### Run the wake-up routine now

```bash
bun run scripts/wakeup.ts
```

### Dry run (show what would happen without playing)

```bash
bun run scripts/wakeup.ts --dry-run
```

### Set up the daily cron schedule

```bash
bun run scripts/wakeup.ts --install-cron
```

### Remove the daily cron schedule

```bash
bun run scripts/wakeup.ts --remove-cron
```

## Weather Classification

Weather codes from Open-Meteo are mapped as follows:

| Category | WMO Codes | Description |
|---|---|---|
| `sunny` | 0, 1 | Clear / mainly clear |
| `cloudy` | 2, 3, 45, 48 | Partly cloudy / overcast / fog |
| `rainy` | 51–67, 80–82 | Drizzle / rain |
| `snowy` | 71–77, 85–86 | Snow |
| `stormy` | 95–99 | Thunderstorm |

## Scheduling with OpenClaw Cron

When `--install-cron` is used, the skill creates a cron job via the OpenClaw cron tool:

```json
{
  "schedule": { "kind": "cron", "expr": "0 7 * * *" },
  "payload": { "kind": "agentTurn", "message": "Run the morning wake-up routine using the morning-wakeup skill." },
  "sessionTarget": "isolated"
}
```

## Troubleshooting

- **"Location not found"**: Verify the city name in `presets.json`; use "lat,lon" format if needed.
- **Sonos not found**: Run `sonos discover` and confirm the speaker name matches.
- **Preset not found**: Verify the Sonos favorite name with `sonos favorites list`.
- **No sound**: Check volume setting and that the speaker is not grouped with a paused coordinator.