// morning-wakeup: fetch weather, match Sonos preset, play.
// Usage: bun run scripts/wakeup.ts [--dry-run] [--install-cron] [--remove-cron]

import { execFileSync } from "child_process";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";

// --- Weather helpers (inline, same API as weather skill) ---

const WMO_CODES: Record<number, string> = {
  0: "Clear sky",
  1: "Mainly clear",
  2: "Partly cloudy",
  3: "Overcast",
  45: "Fog",
  48: "Depositing rime fog",
  51: "Light drizzle",
  53: "Moderate drizzle",
  55: "Dense drizzle",
  56: "Light freezing drizzle",
  57: "Dense freezing drizzle",
  61: "Slight rain",
  63: "Moderate rain",
  65: "Heavy rain",
  66: "Light freezing rain",
  67: "Heavy freezing rain",
  71: "Slight snow fall",
  73: "Moderate snow fall",
  75: "Heavy snow fall",
  77: "Snow grains",
  80: "Slight rain showers",
  81: "Moderate rain showers",
  82: "Violent rain showers",
  85: "Slight snow showers",
  86: "Heavy snow showers",
  95: "Thunderstorm",
  96: "Thunderstorm with slight hail",
  99: "Thunderstorm with heavy hail",
};

type WeatherCategory = "sunny" | "cloudy" | "rainy" | "snowy" | "stormy";

function classifyWeather(code: number): WeatherCategory {
  if (code <= 1) return "sunny";
  if (code <= 48) return "cloudy";
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "rainy";
  if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return "snowy";
  if (code >= 95) return "stormy";
  return "cloudy"; // default fallback
}

interface GeoResult {
  name: string;
  latitude: number;
  longitude: number;
  country: string;
}

const FETCH_TIMEOUT_MS = 10_000;

async function geocode(location: string): Promise<GeoResult> {
  const latLonMatch = location.match(/^(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)$/);
  if (latLonMatch) {
    return {
      name: location,
      latitude: parseFloat(latLonMatch[1]),
      longitude: parseFloat(latLonMatch[2]),
      country: "Unknown",
    };
  }

  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`;
  const res = await fetch(url, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`Geocoding API error: ${res.status}`);
  const data = (await res.json()) as any;
  if (!data.results?.length) throw new Error(`Location not found: "${location}"`);
  const r = data.results[0];
  return { name: r.name, latitude: r.latitude, longitude: r.longitude, country: r.country };
}

async function fetchWeatherCode(lat: number, lon: number): Promise<number> {
  const params = new URLSearchParams({
    latitude: lat.toString(),
    longitude: lon.toString(),
    daily: "weather_code",
    timezone: "auto",
    forecast_days: "1",
  });
  const url = `https://api.open-meteo.com/v1/forecast?${params}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`Weather API error: ${res.status}`);
  const data = (await res.json()) as any;
  return data.daily.weather_code[0] ?? 0;
}

// --- Preset config ---

interface PresetConfig {
  location: string;
  speaker: string;
  volume: number;
  presets: Record<WeatherCategory, string>;
  fallback_preset: string;
  schedule: string;
}

const WEATHER_CATEGORIES: WeatherCategory[] = ["sunny", "cloudy", "rainy", "snowy", "stormy"];

function loadConfig(): PresetConfig {
  const configPath = resolve(dirname(new URL(import.meta.url).pathname), "..", "references", "presets.json");
  const config = JSON.parse(readFileSync(configPath, "utf-8")) as PresetConfig;

  if (!config.location) throw new Error("Config missing required field: location");
  if (!config.speaker) throw new Error("Config missing required field: speaker");
  if (typeof config.volume !== "number" || config.volume < 0 || config.volume > 100) {
    throw new Error(`Config volume must be 0-100, got: ${config.volume}`);
  }
  if (!config.fallback_preset) throw new Error("Config missing required field: fallback_preset");

  for (const cat of WEATHER_CATEGORIES) {
    if (!config.presets[cat]) {
      console.warn(`⚠️  No preset for category "${cat}" — will use fallback.`);
    }
  }

  return config;
}

// --- Sonos helpers ---

const SONOS_CMD_TIMEOUT_MS = 15000;

function sonos(subcommand: string, args: string[] = []): string {
  try {
    return execFileSync("sonos", [subcommand, ...args], {
      encoding: "utf-8",
      timeout: SONOS_CMD_TIMEOUT_MS,
    }).trim();
  } catch (err: any) {
    throw new Error(`Sonos command failed: sonos ${subcommand} ${args.join(" ")} — ${err.message}`);
  }
}

// --- Main routine ---

async function wakeup(dryRun: boolean) {
  const config = loadConfig();

  // 1. Fetch weather
  const geo = await geocode(config.location);
  const weatherCode = await fetchWeatherCode(geo.latitude, geo.longitude);
  const category = classifyWeather(weatherCode);
  const description = WMO_CODES[weatherCode] || "Unknown";

  console.log(`📍 Location : ${geo.name}, ${geo.country}`);
  console.log(`🌤  Weather  : ${description} (code ${weatherCode})`);
  console.log(`🏷  Category : ${category}`);

  // 2. Match preset
  const presetName = config.presets[category] || config.fallback_preset;
  console.log(`🎵 Preset   : ${presetName}`);

  if (dryRun) {
    console.log("⏩ Dry run — skipping playback.");
    return;
  }

  // 3. Set volume
  console.log(`🔊 Setting volume to ${config.volume} on "${config.speaker}"…`);
  sonos("volume", ["set", String(config.volume), "--name", config.speaker]);

  // 4. Play preset from favorites
  console.log(`▶️  Playing "${presetName}" on "${config.speaker}"…`);
  sonos("favorites", ["open", presetName, "--name", config.speaker]);

  console.log("✅ Morning wake-up complete!");
}

// --- CLI entry ---

const args = process.argv.slice(2);

if (args.includes("--install-cron") || args.includes("--remove-cron")) {
  const config = loadConfig();
  const action = args.includes("--install-cron") ? "install" : "remove";
  const schedule = config.schedule || "0 7 * * *";

  if (action === "install") {
    console.log(`⏰ To set up the daily cron, use the OpenClaw cron tool:`);
    console.log(JSON.stringify({
      schedule: { kind: "cron", expr: schedule },
      payload: {
        kind: "agentTurn",
        message: "Run the morning wake-up routine using the morning-wakeup skill.",
      },
      sessionTarget: "isolated",
      name: "morning-wakeup",
    }, null, 2));
  } else {
    console.log("⏰ To remove the cron, delete the 'morning-wakeup' cron job via the OpenClaw cron tool.");
  }
  process.exit(0);
}

const dryRun = args.includes("--dry-run");

wakeup(dryRun).catch((err) => {
  console.error(`❌ ${err.message}`);
  process.exit(1);
});