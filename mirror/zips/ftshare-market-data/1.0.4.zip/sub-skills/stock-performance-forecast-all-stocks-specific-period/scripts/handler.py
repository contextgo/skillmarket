#!/usr/bin/env python3
"""查询指定报告期所有股票业绩预告（分页）"""
import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
SAFE_URLOPENER = urllib.request.build_opener()

BASE_URL = "https://market.ft.tech"

def safe_urlopen(req_or_url):
    if isinstance(req_or_url, urllib.request.Request):
        url = req_or_url.full_url
    else:
        url = str(req_or_url)
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.netloc != "market.ft.tech":
        print(f"Invalid URL for safe_urlopen: {url}", file=sys.stderr)
        sys.exit(1)
    return SAFE_URLOPENER.open(req_or_url)

VALID_REPORT_TYPES = ["q1", "q2", "q3", "annual"]


def main():
    parser = argparse.ArgumentParser(description="查询指定报告期全市场业绩预告（分页）")
    parser.add_argument("--year", type=int, required=True, help="报告所属年度，如 2025")
    parser.add_argument("--report-type", required=True, choices=VALID_REPORT_TYPES,
                        help="报告期类型：q1（一季报）/ q2（中报）/ q3（三季报）/ annual（年报）")
    parser.add_argument("--page", type=int, default=1, help="页码，从 1 开始（默认 1）")
    parser.add_argument("--page-size", type=int, default=20, help="每页记录数（默认 20）")
    args = parser.parse_args()

    params = {
        "year": args.year,
        "report_type": args.report_type,
        "page": args.page,
        "page_size": args.page_size,
    }
    url = f"{BASE_URL}/data/api/v1/market/data/finance/stock-performance-forecast?" + urllib.parse.urlencode(params)

    try:
        with safe_urlopen(url) as resp:
            data = json.loads(resp.read().decode())
        print(json.dumps(data, ensure_ascii=False, indent=2))
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"HTTP {e.code}: {body}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
