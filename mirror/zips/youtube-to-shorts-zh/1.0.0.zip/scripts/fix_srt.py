#!/usr/bin/env python3
"""
fix_srt.py — 修复 YouTube 自动字幕的滚动式时间戳重叠问题

背景：
    YouTube 自动生成的 SRT 字幕使用"滚动式"设计：相邻字幕的时间段大量重叠，
    目的是让字幕看起来像连续滚动的文字。这种格式在直接用于视频烧录时，
    会导致屏幕上同时出现 2-3 行字幕，极大影响可读性。

修复策略：
    1. 解析全部字幕条目
    2. 对每条字幕：若其结束时间 > 下一条的开始时间，
       则将结束时间裁剪为「下一条开始时间 - GAP_MS」
    3. 确保每条字幕的最短显示时间不低于 MIN_DURATION_MS（但不超过下一条的开始时间）
    4. 丢弃时长为 0 或负数的空条目

使用方法：
    python fix_srt.py input.srt output.srt

    # 原地修复（覆盖原文件）：
    python fix_srt.py clip.zh.srt clip.zh.srt
"""

import re
import sys
from pathlib import Path

GAP_MS = 80            # 相邻字幕之间的最小间隔（毫秒）
MIN_DURATION_MS = 800  # 单条字幕的最短显示时间（毫秒）


def ts_to_ms(ts: str) -> int:
    """'HH:MM:SS,mmm' → 毫秒整数"""
    h, m, rest = ts.split(":")
    s, ms = rest.split(",")
    return int(h) * 3_600_000 + int(m) * 60_000 + int(s) * 1_000 + int(ms)


def ms_to_ts(ms: int) -> str:
    """毫秒整数 → 'HH:MM:SS,mmm'"""
    ms = max(0, ms)
    h = ms // 3_600_000; ms %= 3_600_000
    m = ms // 60_000;    ms %= 60_000
    s = ms // 1_000;     ms %= 1_000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def parse_srt(text: str):
    """解析 SRT 文本，返回 [(index, start_ms, end_ms, content_str), ...] 列表"""
    blocks = re.split(r"\n{2,}", text.strip())
    entries = []
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 2:
            continue
        try:
            idx = int(lines[0].strip())
        except ValueError:
            continue
        m = re.match(
            r"(\d{2}:\d{2}:\d{2},\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2},\d{3})",
            lines[1]
        )
        if not m:
            continue
        start_ms = ts_to_ms(m.group(1))
        end_ms   = ts_to_ms(m.group(2))
        content  = "\n".join(lines[2:]).strip()
        entries.append([idx, start_ms, end_ms, content])
    return entries


def fix_overlaps(entries):
    """
    消除重叠：对每条字幕，若其结束时间超过下一条的开始时间，
    裁剪结束时间并保证最短显示时长。返回修复后的列表（已重新编号）。
    """
    result = []
    for i, (idx, start, end, text) in enumerate(entries):
        if i + 1 < len(entries):
            next_start = entries[i + 1][1]
            hard_limit = next_start - GAP_MS   # 绝对不能超过这个时间
        else:
            hard_limit = end  # 最后一条，不限制

        # 先裁剪掉与下一条的重叠
        end = min(end, hard_limit)

        # 尝试保证最短显示时长，但不能突破 hard_limit
        if i + 1 < len(entries):
            end = max(end, min(start + MIN_DURATION_MS, hard_limit))
        else:
            end = max(end, start + MIN_DURATION_MS)

        if end - start <= 0:
            continue  # 时长为零，跳过

        result.append((idx, start, end, text))

    # 重新编号（从 1 开始）
    return [(i + 1, s, e, t) for i, (_, s, e, t) in enumerate(result)]


def write_srt(entries, path: Path):
    """将条目列表写入 SRT 文件"""
    lines = []
    for idx, start, end, text in entries:
        lines.append(str(idx))
        lines.append(f"{ms_to_ts(start)} --> {ms_to_ts(end)}")
        lines.append(text)
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main():
    if len(sys.argv) < 3:
        print("用法: python fix_srt.py input.srt output.srt")
        sys.exit(1)

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])

    if not src.exists():
        print(f"错误：找不到文件 {src}", file=sys.stderr)
        sys.exit(1)

    text = src.read_text(encoding="utf-8")
    entries = parse_srt(text)

    overlaps = sum(
        1 for i in range(len(entries) - 1)
        if entries[i][2] > entries[i + 1][1]
    )
    print(f"  原始条目: {len(entries)}  重叠: {overlaps}")

    fixed = fix_overlaps(entries)
    print(f"  修复后条目: {len(fixed)}")

    write_srt(fixed, dst)
    print(f"  已写入: {dst}")


if __name__ == "__main__":
    main()
