#!/usr/bin/env python3
"""
burn_subtitles.py — Burn a Chinese SRT into an MP4 clip using ffmpeg subtitles filter.

Optionally overlays a bold title in the first second of the video
(centered, font size 48, 3px white outline, black fill).

Usage:
    python burn_subtitles.py <input.mp4> <subtitles.srt> <output.mp4> \\
        [--title "视频标题"] [--font /path/to/font.ttf]

Arguments:
    input.mp4        — source clip (no hard subtitles yet)
    subtitles.srt    — Chinese SRT file to burn in
    output.mp4       — output path for the hard-subbed clip
    --title TEXT     — (optional) title text shown in the first second
    --font  PATH     — (optional) font file for both subtitles and title overlay
                       default: searches for ZITI.ttf in common locations,
                       then falls back to the system default

Notes:
  • The subtitle style uses white text, black border (2px), font size 22,
    positioned in the lower third so it doesn't collide with the title.
  • When --title is supplied, a drawtext filter paints the title centred
    at the top of the frame for the first 1.2 seconds.
  • Paths with spaces or special characters are handled safely via
    ffmpeg filter escaping.
"""

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


# ── font discovery ────────────────────────────────────────────────────────────

FALLBACK_FONT_PATHS = [
    # workspace-specific path mentioned in the skill
    "/Users/slashui/Documents/code/cut_youtube/youtube/ZITI.ttf",
    # common CJK fonts on macOS
    "/System/Library/Fonts/PingFang.ttc",
    "/Library/Fonts/Arial Unicode MS.ttf",
    # common CJK fonts on Linux
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
]


def find_font(user_font: str | None) -> str | None:
    if user_font:
        p = Path(user_font)
        if p.exists():
            return str(p)
        print(f"Warning: specified font not found: {user_font}", file=sys.stderr)

    for path in FALLBACK_FONT_PATHS:
        if Path(path).exists():
            return path

    return None  # ffmpeg will use its built-in default


# ── ffmpeg filter escaping ────────────────────────────────────────────────────

def escape_filter_path(path: str) -> str:
    """Escape a file path for use inside an ffmpeg filter string."""
    # ffmpeg filtergraph uses ':' as separator and '\' as escape
    path = path.replace("\\", "\\\\")
    path = path.replace("'", "\\'")
    path = path.replace(":", "\\:")
    return path


def escape_drawtext_text(text: str) -> str:
    """Escape text for the drawtext filter value."""
    text = text.replace("\\", "\\\\")
    text = text.replace("'", "\\'")
    text = text.replace(":", "\\:")
    return text


# ── subtitle style ────────────────────────────────────────────────────────────

def build_subtitle_style(font_path: str | None) -> str:
    """Return an ASS override style string for the subtitles filter."""
    style_parts = [
        "FontSize=22",
        "PrimaryColour=&H00FFFFFF",   # white text
        "OutlineColour=&H00000000",   # black outline
        "Outline=2",
        "Shadow=0",
        "Bold=0",
        "Alignment=2",               # bottom-center
        "MarginV=30",
    ]
    if font_path:
        fname = Path(font_path).stem
        style_parts.insert(0, f"FontName={fname}")
    return ",".join(style_parts)


# ── filter graph builder ──────────────────────────────────────────────────────

def build_filter(
    srt_path: Path,
    font_path: str | None,
    title: str | None,
) -> str:
    """Construct the ffmpeg -vf filter string."""
    esc_srt = escape_filter_path(str(srt_path))
    style = build_subtitle_style(font_path)

    if font_path:
        sub_filter = (
            f"subtitles='{esc_srt}'"
            f":force_style='{style}'"
            f":fontsdir='{escape_filter_path(str(Path(font_path).parent))}'"
        )
    else:
        sub_filter = f"subtitles='{esc_srt}':force_style='{style}'"

    if not title:
        return sub_filter

    # Title overlay: shown for first 1.2 seconds, centred at top
    esc_title = escape_drawtext_text(title)
    font_arg = f":fontfile='{escape_filter_path(font_path)}'" if font_path else ""
    title_filter = (
        f"drawtext=text='{esc_title}'"
        f"{font_arg}"
        f":fontsize=48"
        f":fontcolor=black"
        f":borderw=3"
        f":bordercolor=white"
        f":x=(w-text_w)/2"
        f":y=60"
        f":enable='between(t,0,1.2)'"
    )

    return f"{sub_filter},{title_filter}"


# ── core ─────────────────────────────────────────────────────────────────────

def burn(
    input_path: Path,
    srt_path: Path,
    output_path: Path,
    title: str | None = None,
    font_path: str | None = None,
) -> None:
    if not shutil.which("ffmpeg"):
        print("Error: ffmpeg not found in PATH.", file=sys.stderr)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    vf = build_filter(srt_path, font_path, title)

    cmd = [
        "ffmpeg", "-y",
        "-i", str(input_path),
        "-vf", vf,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "18",
        "-c:a", "copy",
        "-movflags", "+faststart",
        str(output_path),
    ]

    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"Error: ffmpeg exited with code {result.returncode}", file=sys.stderr)
        sys.exit(result.returncode)

    print(f"Hard-subbed clip written: {output_path}")


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Burn Chinese SRT subtitles into an MP4 clip."
    )
    parser.add_argument("input", help="Source MP4 clip")
    parser.add_argument("subtitles", help="Chinese SRT file")
    parser.add_argument("output", help="Output MP4 path")
    parser.add_argument("--title", default=None, help="Title text for first-second overlay")
    parser.add_argument("--font", default=None, help="Path to .ttf/.ttc font file")

    args = parser.parse_args()

    input_path = Path(args.input)
    srt_path = Path(args.subtitles)
    output_path = Path(args.output)

    for p, label in [(input_path, "input"), (srt_path, "subtitles")]:
        if not p.exists():
            print(f"Error: {label} file not found: {p}", file=sys.stderr)
            sys.exit(1)

    font_path = find_font(args.font)
    if font_path:
        print(f"Using font: {font_path}")
    else:
        print("Warning: no CJK font found; ffmpeg will use its default font.")

    burn(input_path, srt_path, output_path, title=args.title, font_path=font_path)


if __name__ == "__main__":
    main()
