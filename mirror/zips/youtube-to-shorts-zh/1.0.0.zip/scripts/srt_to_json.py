#!/usr/bin/env python3
"""
srt_to_json.py — Parse an SRT subtitle file into a JSON array of cue records.

Each record contains:
  - index        : int   — cue number (1-based)
  - start        : str   — start timestamp string "HH:MM:SS,mmm"
  - end          : str   — end timestamp string "HH:MM:SS,mmm"
  - start_sec    : float — start time in seconds
  - end_sec      : float — end time in seconds
  - duration_sec : float — cue duration in seconds
  - text         : str   — subtitle text (newlines replaced with space)

Usage:
    python srt_to_json.py input.srt [output.json]

If output.json is omitted, the result is printed to stdout.
"""

import json
import re
import sys
from pathlib import Path


def ts_to_seconds(ts: str) -> float:
    """Convert SRT timestamp 'HH:MM:SS,mmm' to float seconds."""
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    h, m, s = int(parts[0]), int(parts[1]), float(parts[2])
    return h * 3600 + m * 60 + s


def parse_srt(srt_text: str) -> list[dict]:
    """Parse SRT text and return a list of cue dicts."""
    # Normalise line endings
    text = srt_text.replace("\r\n", "\n").replace("\r", "\n").strip()

    # Split on blank lines between cues
    blocks = re.split(r"\n{2,}", text)

    cues = []
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 3:
            continue

        # First line: cue index
        try:
            index = int(lines[0].strip())
        except ValueError:
            continue

        # Second line: timestamps
        ts_match = re.match(
            r"(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})",
            lines[1].strip(),
        )
        if not ts_match:
            continue

        start_ts = ts_match.group(1).replace(".", ",")
        end_ts = ts_match.group(2).replace(".", ",")
        start_sec = ts_to_seconds(start_ts)
        end_sec = ts_to_seconds(end_ts)

        # Remaining lines: text (strip HTML-like tags)
        raw_text = " ".join(lines[2:])
        clean_text = re.sub(r"<[^>]+>", "", raw_text).strip()

        cues.append(
            {
                "index": index,
                "start": start_ts,
                "end": end_ts,
                "start_sec": round(start_sec, 3),
                "end_sec": round(end_sec, 3),
                "duration_sec": round(end_sec - start_sec, 3),
                "text": clean_text,
            }
        )

    return cues


def main():
    if len(sys.argv) < 2:
        print("Usage: srt_to_json.py <input.srt> [output.json]", file=sys.stderr)
        sys.exit(1)

    srt_path = Path(sys.argv[1])
    if not srt_path.exists():
        print(f"Error: file not found: {srt_path}", file=sys.stderr)
        sys.exit(1)

    srt_text = srt_path.read_text(encoding="utf-8", errors="replace")
    cues = parse_srt(srt_text)

    output = json.dumps(cues, ensure_ascii=False, indent=2)

    if len(sys.argv) >= 3:
        out_path = Path(sys.argv[2])
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output, encoding="utf-8")
        print(f"Written {len(cues)} cues to {out_path}")
    else:
        print(output)


if __name__ == "__main__":
    main()
