#!/usr/bin/env python3
"""
clip_video.py — Create a re-encoded MP4 clip for an exact time range.

Uses ffmpeg with -ss / -to for frame-accurate cutting and re-encodes
with H.264 + AAC so the result is a self-contained, seek-friendly file.

Usage:
    python clip_video.py <input.mp4> <start> <end> <output.mp4> [--fast]

Arguments:
    input.mp4   — source video file
    start       — start time: seconds (float) OR "HH:MM:SS" OR "HH:MM:SS,mmm"
    end         — end time:   seconds (float) OR "HH:MM:SS" OR "HH:MM:SS,mmm"
    output.mp4  — path to write the clip
    --fast      — (optional) use stream-copy instead of re-encoding;
                  faster but may have imprecise start/end frames

Examples:
    python clip_video.py interview.mp4 142.5 307.0 clips/01-clip/clip.mp4
    python clip_video.py interview.mp4 00:02:22,500 00:05:07,000 clips/01-clip/clip.mp4
"""

import re
import shutil
import subprocess
import sys
from pathlib import Path


# ── helpers ──────────────────────────────────────────────────────────────────

def parse_time(value: str) -> float:
    """Accept seconds (float string) or HH:MM:SS[,.]mmm and return float seconds."""
    value = value.strip()
    # plain number
    try:
        return float(value)
    except ValueError:
        pass
    # HH:MM:SS or HH:MM:SS,mmm / HH:MM:SS.mmm
    m = re.match(r"(\d+):(\d{2}):(\d{2})([,\.](\d+))?$", value)
    if m:
        h, mn, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
        ms = int(m.group(5) or 0)
        # normalise ms to 3 digits
        if m.group(5):
            raw = m.group(5)
            ms = int(raw) * (10 ** (3 - len(raw))) if len(raw) < 3 else int(raw[:3])
        return h * 3600 + mn * 60 + s + ms / 1000
    raise ValueError(f"Cannot parse time value: {value!r}")


def seconds_to_ffmpeg(sec: float) -> str:
    """Format seconds as HH:MM:SS.mmm for ffmpeg -ss / -to."""
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}"


# ── core ─────────────────────────────────────────────────────────────────────

def clip_video(
    input_path: Path,
    start_sec: float,
    end_sec: float,
    output_path: Path,
    fast: bool = False,
) -> None:
    """Run ffmpeg to cut and (optionally) re-encode the clip."""
    if not shutil.which("ffmpeg"):
        print("Error: ffmpeg not found in PATH. Please install ffmpeg.", file=sys.stderr)
        sys.exit(1)

    if start_sec >= end_sec:
        print(f"Error: start ({start_sec}s) must be before end ({end_sec}s).", file=sys.stderr)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    ss = seconds_to_ffmpeg(start_sec)
    to = seconds_to_ffmpeg(end_sec)

    if fast:
        # Stream-copy: very fast, slightly imprecise cuts
        cmd = [
            "ffmpeg", "-y",
            "-ss", ss,
            "-to", to,
            "-i", str(input_path),
            "-c", "copy",
            str(output_path),
        ]
    else:
        # Re-encode: frame-accurate, produces clean keyframes at boundaries
        cmd = [
            "ffmpeg", "-y",
            "-ss", ss,
            "-to", to,
            "-i", str(input_path),
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "18",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
            str(output_path),
        ]

    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=False)
    if result.returncode != 0:
        print(f"Error: ffmpeg exited with code {result.returncode}", file=sys.stderr)
        sys.exit(result.returncode)

    duration = end_sec - start_sec
    print(f"Clip written: {output_path}  ({duration:.1f}s)")


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 5:
        print(
            "Usage: clip_video.py <input.mp4> <start> <end> <output.mp4> [--fast]",
            file=sys.stderr,
        )
        sys.exit(1)

    input_path = Path(sys.argv[1])
    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    try:
        start_sec = parse_time(sys.argv[2])
        end_sec = parse_time(sys.argv[3])
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    output_path = Path(sys.argv[4])
    fast = "--fast" in sys.argv[5:]

    clip_video(input_path, start_sec, end_sec, output_path, fast=fast)


if __name__ == "__main__":
    main()
