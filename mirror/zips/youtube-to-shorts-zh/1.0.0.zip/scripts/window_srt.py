#!/usr/bin/env python3
"""
window_srt.py — Extract the subtitle cues that overlap a clip window and
re-zero the timestamps so the output SRT starts at 00:00:00,000.

Usage:
    python window_srt.py <input.srt> <start_sec> <end_sec> [output.srt]

Arguments:
    input.srt   — source SRT file (full-length video subtitles)
    start_sec   — clip start time in seconds (float)
    end_sec     — clip end time in seconds (float)
    output.srt  — (optional) path to write the windowed SRT;
                  if omitted, prints to stdout

A cue is included if it overlaps the window [start_sec, end_sec].
Timestamps in the output are shifted so that start_sec maps to 00:00:00,000.
"""

import re
import sys
from pathlib import Path


# ── timestamp helpers ────────────────────────────────────────────────────────

def ts_to_seconds(ts: str) -> float:
    ts = ts.strip().replace(",", ".")
    h, m, s = ts.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)


def seconds_to_ts(sec: float) -> str:
    sec = max(0.0, sec)
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60
    ms = round((s - int(s)) * 1000)
    s = int(s)
    # handle millisecond overflow
    if ms >= 1000:
        ms -= 1000
        s += 1
    if s >= 60:
        s -= 60
        m += 1
    if m >= 60:
        m -= 60
        h += 1
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# ── SRT parser ───────────────────────────────────────────────────────────────

def parse_srt(text: str):
    """Yield (index, start_sec, end_sec, start_ts, end_ts, text_lines) tuples."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    blocks = re.split(r"\n{2,}", text)
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 3:
            continue
        try:
            idx = int(lines[0].strip())
        except ValueError:
            continue
        ts_match = re.match(
            r"(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})",
            lines[1].strip(),
        )
        if not ts_match:
            continue
        start_ts = ts_match.group(1).replace(".", ",")
        end_ts = ts_match.group(2).replace(".", ",")
        yield (
            idx,
            ts_to_seconds(start_ts),
            ts_to_seconds(end_ts),
            start_ts,
            end_ts,
            lines[2:],
        )


# ── main ─────────────────────────────────────────────────────────────────────

def window_srt(srt_text: str, win_start: float, win_end: float) -> str:
    """Return an SRT string containing only cues that overlap [win_start, win_end],
    with timestamps shifted so win_start → 00:00:00,000."""
    output_cues = []
    new_index = 1

    for idx, start_sec, end_sec, _s_ts, _e_ts, text_lines in parse_srt(srt_text):
        # include cue if it overlaps the window at all
        if end_sec <= win_start or start_sec >= win_end:
            continue

        # clamp to window boundaries
        new_start = max(start_sec, win_start) - win_start
        new_end = min(end_sec, win_end) - win_start

        cue_text = "\n".join(text_lines)
        output_cues.append(
            f"{new_index}\n"
            f"{seconds_to_ts(new_start)} --> {seconds_to_ts(new_end)}\n"
            f"{cue_text}"
        )
        new_index += 1

    return "\n\n".join(output_cues) + "\n"


def main():
    if len(sys.argv) < 4:
        print(
            "Usage: window_srt.py <input.srt> <start_sec> <end_sec> [output.srt]",
            file=sys.stderr,
        )
        sys.exit(1)

    srt_path = Path(sys.argv[1])
    if not srt_path.exists():
        print(f"Error: file not found: {srt_path}", file=sys.stderr)
        sys.exit(1)

    try:
        win_start = float(sys.argv[2])
        win_end = float(sys.argv[3])
    except ValueError:
        print("Error: start_sec and end_sec must be numbers.", file=sys.stderr)
        sys.exit(1)

    if win_start >= win_end:
        print("Error: start_sec must be less than end_sec.", file=sys.stderr)
        sys.exit(1)

    srt_text = srt_path.read_text(encoding="utf-8", errors="replace")
    result = window_srt(srt_text, win_start, win_end)

    if len(sys.argv) >= 5:
        out_path = Path(sys.argv[4])
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(result, encoding="utf-8")
        print(f"Written windowed SRT ({new_count(result)} cues) to {out_path}")
    else:
        sys.stdout.write(result)


def new_count(srt: str) -> int:
    return len(re.findall(r"^\d+$", srt, re.MULTILINE))


if __name__ == "__main__":
    main()
