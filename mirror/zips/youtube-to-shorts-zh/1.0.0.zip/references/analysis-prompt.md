# Analysis Prompts — Transcript Analysis for Short Clip Selection

This file contains the default prompts used during transcript analysis.
Use **Stage 1** first to identify candidate clips, then **Stage 2** to
format the candidate list for user review.

---

## Stage 1 — Candidate Identification

Use this prompt after converting the SRT to JSON with `srt_to_json.py`.
Pass the full JSON transcript as context.

```
You are a short-video editor specialising in Chinese social media content.

Below is the full English transcript of a YouTube interview or talk,
formatted as a JSON array where each cue has:
  index, start, end, start_sec, end_sec, duration_sec, text

Your task is to identify the strongest candidate segments for
standalone short clips (20 seconds – 3 minutes each).

SELECTION CRITERIA
------------------
Favour segments that are:
- self-contained: the viewer needs no prior context to understand the point
- informative, opinionated, or counterintuitive
- emotionally resonant: motivating, surprising, or quotable
- anchored by a strong first sentence that works as a hook

Reject segments that are:
- mostly greeting, filler, or sponsor read
- dependent on visuals not visible in a 9:16 crop
- long digressions or meta-commentary about the show itself
- fragments without a complete thought

CLIP PROPERTIES
---------------
For each candidate, prefer:
- Duration: 20 seconds to 3 minutes
- One clear idea per clip
- Opening hook within the first 3 seconds
- Clean ending: the speaker finishes the thought before the clip ends

For a 1-hour interview, aim for 10–15 candidates.
Do not be overly conservative — more options are better at this stage.

When a promising moment needs a few extra seconds of context at the
start or end, extend the boundaries. Do not cut off mid-sentence.

OUTPUT FORMAT
-------------
Return a JSON array. Each element must have:
{
  "id":          "<zero-padded sequence, e.g. '01'>",
  "start":       "<HH:MM:SS,mmm>",
  "end":         "<HH:MM:SS,mmm>",
  "start_sec":   <float>,
  "end_sec":     <float>,
  "duration_sec": <float>,
  "title":       "<short Chinese working title, ≤ 20 chars>",
  "summary":     "<exactly two English sentences: what this clip is about and why it works as a short>",
  "status":      "candidate"
}

TRANSCRIPT
----------
[INSERT TRANSCRIPT JSON HERE]
```

---

## Stage 2 — User Review Formatting

Use this prompt after Stage 1 to produce a human-readable candidate list
for the user to review and select clips from.

```
You are formatting a candidate clip list for user review.

Below is the JSON array of clip candidates from a YouTube interview.
Present each clip in a clean, easy-to-scan format so the user can
decide which clips to export.

FORMAT EACH CLIP AS:
--------------------
**[ID] — [Title]**
⏱ [start] → [end]  ([duration_sec]s)
[summary sentence 1]
[summary sentence 2]

After listing all candidates, add a brief note:
"Reply with the clip IDs you'd like to export (e.g. 01, 03, 05),
or say 'export all' to process every candidate."

CANDIDATES
----------
[INSERT STAGE 1 JSON OUTPUT HERE]
```

---

## Stage 3 — Translation Review (optional)

Use this prompt when you want to QA-check the Chinese SRT before burning.

```
You are a Chinese subtitle editor for short-form video.

Below is a pair of subtitle files for a short clip:
1. The original English SRT (source)
2. The Chinese SRT translation (to review)

Check the Chinese translation for:
- Accuracy: does the meaning match the English faithfully?
- Naturalness: does it read like natural spoken Mandarin?
- Length: are lines concise enough for short-video pacing (≤ 18 characters per cue ideally)?
- Timing: note any timestamp mismatches (do not fix timestamps yourself)
- Named entities: are names, numbers, and product names preserved?

Return a list of issues (if any) in the format:
  Cue [index]: [issue description] → Suggested fix: [suggested Chinese text]

If the translation looks good, say "Translation approved."

ENGLISH SRT
-----------
[INSERT ENGLISH SRT HERE]

CHINESE SRT
-----------
[INSERT CHINESE SRT HERE]
```

---

## Usage Notes

- In Stage 1, replace `[INSERT TRANSCRIPT JSON HERE]` with the full output
  of `srt_to_json.py`. For very long videos (> 2 hours), consider splitting
  the transcript into 30-minute windows and running Stage 1 on each window.

- In Stage 2, replace `[INSERT STAGE 1 JSON OUTPUT HERE]` with the JSON
  array returned by Stage 1.

- After the user selects clips, update `status` in `selected_clips.json`
  from `"candidate"` to `"selected"` or `"rejected"` as appropriate.

- Stage 3 is optional but recommended when subtitle quality matters,
  especially for technical or domain-specific content.
