# Clip Schema — selected_clips.json

This document defines the JSON schema for `selected_clips.json`, which stores
all candidate clip decisions produced during transcript analysis.

---

## Top-level structure

```json
{
  "source_video": "work/<video-slug>/source/original.mp4",
  "source_srt":   "work/<video-slug>/source/original.en.srt",
  "analyzed_at":  "2024-03-30T14:22:00Z",
  "clips": [ ... ]
}
```

| Field          | Type   | Required | Description                                      |
|----------------|--------|----------|--------------------------------------------------|
| `source_video` | string | yes      | Relative path to the source .mp4 file            |
| `source_srt`   | string | yes      | Relative path to the English .srt file           |
| `analyzed_at`  | string | no       | ISO-8601 datetime when analysis was run          |
| `clips`        | array  | yes      | Array of clip candidate objects (see below)      |

---

## Clip candidate object

Each element of the `clips` array describes one candidate segment.

```json
{
  "id":          "01",
  "start":       "00:02:22,500",
  "end":         "00:05:07,000",
  "start_sec":   142.5,
  "end_sec":     307.0,
  "duration_sec": 164.5,
  "title":       "为什么大多数创业公司死于增长太快",
  "summary":     "Two-sentence English summary of what the clip is about.",
  "status":      "candidate",
  "export_slug": "why-startups-die-from-growing-too-fast"
}
```

### Field reference

| Field          | Type   | Required | Description                                                                 |
|----------------|--------|----------|-----------------------------------------------------------------------------|
| `id`           | string | yes      | Zero-padded sequence number, e.g. `"01"`, `"02"`. Must be unique.          |
| `start`        | string | yes      | Start timestamp in SRT format `HH:MM:SS,mmm`                               |
| `end`          | string | yes      | End timestamp in SRT format `HH:MM:SS,mmm`                                 |
| `start_sec`    | number | yes      | Start time in seconds (float, 3 decimal places)                             |
| `end_sec`      | number | yes      | End time in seconds (float, 3 decimal places)                               |
| `duration_sec` | number | yes      | `end_sec - start_sec` (computed, 1 decimal place is fine)                   |
| `title`        | string | yes      | Short working title (Chinese preferred, ≤ 20 chars for on-screen use)      |
| `summary`      | string | yes      | Exactly two English sentences describing the clip's content and appeal      |
| `status`       | string | yes      | One of: `"candidate"` · `"selected"` · `"rejected"`                        |
| `export_slug`  | string | no       | ASCII kebab-case slug used as the clip folder name, e.g. `01-<export_slug>`|

---

## Status values

| Value       | Meaning                                                              |
|-------------|----------------------------------------------------------------------|
| `candidate` | Identified during analysis; awaiting user review                     |
| `selected`  | User approved for export                                             |
| `rejected`  | User declined, or AI self-filtered before presenting to user         |

---

## Minimal valid example

```json
{
  "source_video": "work/interview-2024/source/original.mp4",
  "source_srt":   "work/interview-2024/source/original.en.srt",
  "clips": [
    {
      "id": "01",
      "start": "00:02:22,500",
      "end": "00:05:07,000",
      "start_sec": 142.5,
      "end_sec": 307.0,
      "duration_sec": 164.5,
      "title": "为什么增长太快会杀死创业公司",
      "summary": "The speaker explains that premature scaling is the single most common cause of startup death. He argues that founders confuse activity with progress and spend cash before validating the core hypothesis.",
      "status": "candidate"
    },
    {
      "id": "02",
      "start": "00:18:45,000",
      "end": "00:21:10,200",
      "start_sec": 1125.0,
      "end_sec": 1270.2,
      "duration_sec": 145.2,
      "title": "真正的产品市场契合什么感觉",
      "summary": "The host pushes back on the idea that product-market fit is obvious, and the guest gives a vivid physical description: you feel it like a pull, not a push. He recalls the exact week Airbnb crossed the threshold.",
      "status": "candidate",
      "export_slug": "what-product-market-fit-actually-feels-like"
    }
  ]
}
```

---

## Notes for Claude

- Always write `selected_clips.json` to `work/<video-slug>/analysis/selected_clips.json`.
- Set `status` to `"candidate"` for all entries when first writing the file.
  Update to `"selected"` or `"rejected"` only after the user reviews.
- The `export_slug` is used to name the per-clip folder: `clips/<id>-<export_slug>/`.
  If omitted, use a slugified version of the title.
- `start_sec` and `end_sec` must match the `start` and `end` timestamp strings exactly.
  Use `srt_to_json.py` output as the authoritative source for precise second values.
