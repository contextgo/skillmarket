---
name: http-request
description: HTTP 请求技能，发起 GET/POST 请求并返回响应结果。
---

# HTTP Request

## 概述
发送 HTTP 请求到指定 URL，支持 GET/POST 方法和自定义 headers。

## 参数说明
* `--url` 必需，目标 URL 地址
* `--method` 请求方法，支持 GET/POST，默认 GET
* `--data` POST 请求的数据，JSON 格式字符串

## 快速开始
```bash
python scripts/http-client.py --url "https://api.example.com/data" --method GET
```

## 输出示例
返回 JSON 格式的响应内容。
