import sys
import json
import argparse
import urllib.request


def main():
    parser = argparse.ArgumentParser(description="HTTP 请求工具")
    parser.add_argument("--url", type=str, required=True, help="目标 URL")
    parser.add_argument("--method", type=str, default="GET", help="请求方法")
    parser.add_argument("--data", type=str, default=None, help="POST 数据")

    if "--url" not in sys.argv and not sys.stdin.isatty():
        try:
            payload = json.load(sys.stdin)
            args = parser.parse_args([])
            args.url = payload.get("url", "")
            args.method = payload.get("method", "GET").upper()
            args.data = payload.get("data")
        except:
            args = parser.parse_args()
    else:
        args = parser.parse_args()

    if not args.url:
        print(json.dumps({"error": "url is required"}))
        return

    try:
        method = args.method.upper()
        headers = {"Accept": "application/json"}

        if method == "POST" and args.data:
            data_bytes = args.data.encode("utf-8")
            headers["Content-Type"] = "application/json"
        else:
            data_bytes = None

        req = urllib.request.Request(args.url, data=data_bytes, headers=headers, method=method)

        with urllib.request.urlopen(req, timeout=30) as response:
            body = response.read().decode("utf-8")
            try:
                result = json.loads(body)
            except:
                result = {"raw": body}

            print(json.dumps({
                "status_code": response.status,
                "body": result
            }))
    except Exception as e:
        print(json.dumps({"error": str(e)}))


if __name__ == "__main__":
    main()
