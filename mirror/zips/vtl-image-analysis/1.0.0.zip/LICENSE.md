Creative Commons Attribution 4.0 International (CC BY 4.0)

Copyright (c) 2025-2026 Russell Parrish — https://artistinfluencer.com

You are free to:
  Share — copy and redistribute the material in any medium or format
  Adapt — remix, transform, and build upon the material for any purpose,
           even commercially.

Under the following terms:
  Attribution — You must give appropriate credit to Russell Parrish
                (https://artistinfluencer.com), provide a link to this
                license, and indicate if changes were made. You may do
                so in any reasonable manner, but not in any way that
                suggests the licensor endorses you or your use.

No additional restrictions — You may not apply legal terms or
technological measures that legally restrict others from doing anything
the license permits.

Full license text: https://creativecommons.org/licenses/by/4.0/

Visual Thinking Lens (VTL) Framework:
https://github.com/rusparrish/Visual-Thinking-Lens
