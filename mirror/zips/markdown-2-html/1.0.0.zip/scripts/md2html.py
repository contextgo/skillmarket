#!/usr/bin/env python3
"""
Markdown to HTML Converter
将 Markdown 文件转换为精美的 HTML 网页，支持代码语法高亮
"""

import argparse
import sys
import re
from pathlib import Path

# 尝试导入 markdown 库，如果没有则使用简单实现
try:
    import markdown
    HAS_MARKDOWN = True
except ImportError:
    HAS_MARKDOWN = False


# 语法高亮规则
SYNTAX_PATTERNS = {
    'bash': [
        (r'\b(npx|npm|yarn|pip|python|node|git|cd|ls|mkdir|rm|cp|mv|echo|cat|curl|wget|sudo)\b', 'keyword'),
        (r'(--[\w-]+)', 'flag'),
        (r'(-[\w])', 'flag-short'),
        (r'(#.*$)', 'comment'),
        (r'(".*?"|\'.*?\')', 'string'),
        (r'(https?://[^\s]+)', 'url'),
    ],
    'python': [
        (r'\b(def|class|if|elif|else|for|while|try|except|finally|with|import|from|as|return|yield|lambda|and|or|not|in|is|None|True|False|print|len|range|open)\b', 'keyword'),
        (r'(#.*$)', 'comment'),
        (r'(""".*?"""|\'\'\'.*?\'\'\')', 'docstring'),
        (r'(".*?"|\'.*?\')', 'string'),
        (r'\b(\d+\.?\d*)\b', 'number'),
        (r'\b([A-Z][a-zA-Z0-9_]*)\b', 'class'),
        (r'\b([a-z_][a-zA-Z0-9_]*)\s*(?=\()', 'function'),
    ],
    'javascript': [
        (r'\b(const|let|var|function|return|if|else|for|while|try|catch|finally|class|extends|import|export|from|async|await|new|this|typeof|instanceof|null|undefined|true|false)\b', 'keyword'),
        (r'(//.*$)', 'comment'),
        (r'(/\*.*?\*/)', 'comment-block'),
        (r'(".*?"|\'.*?\'|`.*?`)', 'string'),
        (r'\b(\d+\.?\d*)\b', 'number'),
        (r'\b([a-z_][a-zA-Z0-9_]*)\s*(?=\()', 'function'),
    ],
    'json': [
        (r'\b(true|false|null)\b', 'keyword'),
        (r'(".*?")\s*:', 'key'),
        (r'(".*?")', 'string'),
        (r'\b(\d+\.?\d*)\b', 'number'),
    ],
    'html': [
        (r'(&lt;/?[\w-]+)', 'tag'),
        (r'([\w-]+)(?==)', 'attr-name'),
        (r'(".*?")', 'string'),
        (r'(&lt;!--.*?--&gt;)', 'comment'),
    ],
    'css': [
        (r'([\w-]+)\s*(?={)', 'selector'),
        (r'([\w-]+)(?=:)', 'property'),
        (r'(:\s*)([^;]+)', 'value'),
        (r'(/\*.*?\*/)', 'comment'),
        (r'(@media|@import|@keyframes|@font-face)\b', 'at-rule'),
    ],
}


def highlight_code(code: str, lang: str = '') -> str:
    """为代码添加语法高亮"""
    lang = lang.lower() if lang else ''
    
    # 如果没有匹配的语言规则，返回原始代码（仅做 HTML 转义）
    if lang not in SYNTAX_PATTERNS:
        return code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    
    patterns = SYNTAX_PATTERNS[lang]
    result = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    
    # 按顺序应用高亮规则
    for pattern, token_type in patterns:
        def replacer(match):
            content = match.group(0)
            return f'<span class="token-{token_type}">{content}</span>'
        result = re.sub(pattern, replacer, result, flags=re.MULTILINE)
    
    return result


def simple_markdown_to_html(text: str) -> str:
    """简单的 Markdown 到 HTML 转换器（备用方案）"""
    html = text
    
    # 先处理代码块（避免内容被转义）
    code_blocks = []
    def code_block_extractor(match):
        lang = match.group(1) or ''
        code = match.group(2)
        code_blocks.append((lang, code))
        return f'\x00CODEBLOCK{len(code_blocks)-1}\x00'
    
    html = re.sub(r'```(\w+)?\n(.*?)```', code_block_extractor, html, flags=re.DOTALL)
    
    # 转义 HTML 特殊字符（代码块外）
    html = html.replace('&', '&amp;')
    html = html.replace('<', '&lt;')
    html = html.replace('>', '&gt;')
    
    # 行内代码 (`code`)
    inline_codes = []
    def inline_code_extractor(match):
        code = match.group(1)
        inline_codes.append(code)
        return f'\x00INLINECODE{len(inline_codes)-1}\x00'
    
    html = re.sub(r'`([^`]+)`', inline_code_extractor, html)
    
    # 标题 (# ## ### #### ##### ######)
    html = re.sub(r'^###### (.+)$', r'<h6>\1</h6>', html, flags=re.MULTILINE)
    html = re.sub(r'^##### (.+)$', r'<h5>\1</h5>', html, flags=re.MULTILINE)
    html = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
    html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
    html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
    html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
    
    # 粗体 (**text** 或 __text__)
    html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
    html = re.sub(r'__(.+?)__', r'<strong>\1</strong>', html)
    
    # 斜体 (*text* 或 _text_)
    html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
    html = re.sub(r'_(.+?)_', r'<em>\1</em>', html)
    
    # 删除线 (~~text~~)
    html = re.sub(r'~~(.+?)~~', r'<del>\1</del>', html)
    
    # 链接 ([text](url))
    html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
    
    # 图片 (![alt](url))
    html = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src="\2" alt="\1">', html)
    
    # 无序列表 (- item 或 * item)
    def unordered_list_replacer(match):
        items = match.group(0).strip().split('\n')
        list_items = ''.join(f'<li>{item[2:].strip()}</li>' for item in items if item.strip())
        return f'<ul>{list_items}</ul>'
    
    html = re.sub(r'(^- .+\n?)+', unordered_list_replacer, html, flags=re.MULTILINE)
    html = re.sub(r'(^\* .+\n?)+', unordered_list_replacer, html, flags=re.MULTILINE)
    
    # 有序列表 (1. item)
    def ordered_list_replacer(match):
        items = match.group(0).strip().split('\n')
        list_items = ''.join(f'<li>{re.sub(r"^\d+\.\s*", "", item)}</li>' for item in items if item.strip())
        return f'<ol>{list_items}</ol>'
    
    html = re.sub(r'(^\d+\. .+\n?)+', ordered_list_replacer, html, flags=re.MULTILINE)
    
    # 引用 (> text)
    def blockquote_replacer(match):
        lines = match.group(0).strip().split('\n')
        content = ' '.join(line[2:].strip() if line.startswith('> ') else line.strip() for line in lines)
        return f'<blockquote>{content}</blockquote>'
    
    html = re.sub(r'(^> .+\n?)+', blockquote_replacer, html, flags=re.MULTILINE)
    
    # 水平线 (--- 或 *** 或 ___)
    html = re.sub(r'^(---|\*\*\*|___)\s*$', r'<hr>', html, flags=re.MULTILINE)
    
    # 恢复代码块（带语法高亮）
    for i, (lang, code) in enumerate(code_blocks):
        highlighted = highlight_code(code, lang)
        lang_class = f' language-{lang}' if lang else ''
        lang_label = f'<div class="code-lang">{lang}</div>' if lang else ''
        html = html.replace(f'\x00CODEBLOCK{i}\x00', 
                          f'<div class="code-block-wrapper">{lang_label}<pre><code class="code-block{lang_class}">{highlighted}</code></pre></div>')
    
    # 恢复行内代码
    for i, code in enumerate(inline_codes):
        html = html.replace(f'\x00INLINECODE{i}\x00', f'<code class="inline-code">{code}</code>')
    
    # 段落处理
    paragraphs = html.split('\n\n')
    new_paragraphs = []
    for p in paragraphs:
        p = p.strip()
        if p and not p.startswith('<') and not p.endswith('>'):
            p = f'<p>{p}</p>'
        new_paragraphs.append(p)
    html = '\n\n'.join(new_paragraphs)
    
    return html


def convert_markdown_to_html(md_content: str, title: str = "Markdown Document") -> str:
    """将 Markdown 内容转换为完整的 HTML 页面"""
    
    if HAS_MARKDOWN:
        # 使用 markdown 库进行转换
        md = markdown.Markdown(extensions=['fenced_code', 'tables', 'toc'])
        body_html = md.convert(md_content)
    else:
        # 使用简单实现
        body_html = simple_markdown_to_html(md_content)
    
    # 构建完整的 HTML 页面
    html_template = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        :root {{
            --bg-color: #ffffff;
            --text-color: #333333;
            --heading-color: #2c3e50;
            --link-color: #3498db;
            --link-hover: #2980b9;
            --code-bg: #f8f9fa;
            --code-block-bg: #f4f6f8;
            --blockquote-bg: #f9f9f9;
            --blockquote-border: #ddd;
            --border-color: #e0e0e0;
            
            /* 语法高亮色 - 亮色模式 */
            --token-keyword: #d73a49;
            --token-string: #032f62;
            --token-comment: #6a737d;
            --token-number: #005cc5;
            --token-function: #6f42c1;
            --token-class: #22863a;
            --token-flag: #e36209;
            --token-url: #0366d6;
            --token-tag: #22863a;
            --token-attr: #6f42c1;
        }}
        
        @media (prefers-color-scheme: dark) {{
            :root {{
                --bg-color: #0d1117;
                --text-color: #c9d1d9;
                --heading-color: #e6edf3;
                --link-color: #58a6ff;
                --link-hover: #79c0ff;
                --code-bg: #161b22;
                --code-block-bg: #161b22;
                --blockquote-bg: #161b22;
                --blockquote-border: #30363d;
                --border-color: #30363d;
                
                /* 语法高亮色 - 暗黑模式 */
                --token-keyword: #ff7b72;
                --token-string: #a5d6ff;
                --token-comment: #8b949e;
                --token-number: #79c0ff;
                --token-function: #d2a8ff;
                --token-class: #7ee787;
                --token-flag: #ffa657;
                --token-url: #58a6ff;
                --token-tag: #7ee787;
                --token-attr: #d2a8ff;
            }}
        }}
        
        * {{
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.8;
            color: var(--text-color);
            background-color: var(--bg-color);
            max-width: 850px;
            margin: 0 auto;
            padding: 40px 24px;
            transition: background-color 0.3s, color 0.3s;
        }}
        
        h1, h2, h3, h4, h5, h6 {{
            color: var(--heading-color);
            margin-top: 1.8em;
            margin-bottom: 0.6em;
            font-weight: 600;
            line-height: 1.3;
        }}
        
        h1 {{ font-size: 2.2em; border-bottom: 2px solid var(--border-color); padding-bottom: 0.3em; margin-top: 0; }}
        h2 {{ font-size: 1.7em; border-bottom: 1px solid var(--border-color); padding-bottom: 0.2em; }}
        h3 {{ font-size: 1.4em; }}
        h4 {{ font-size: 1.2em; }}
        h5 {{ font-size: 1.1em; }}
        h6 {{ font-size: 1em; }}
        
        p {{
            margin: 1em 0;
        }}
        
        a {{
            color: var(--link-color);
            text-decoration: none;
            transition: color 0.2s;
        }}
        
        a:hover {{
            color: var(--link-hover);
            text-decoration: underline;
        }}
        
        /* 行内代码样式 */
        .inline-code {{
            background-color: var(--code-bg);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: "JetBrains Mono", "Fira Code", "SF Mono", Monaco, "Cascadia Code", Consolas, monospace;
            font-size: 0.88em;
            color: var(--token-keyword);
            border: 1px solid var(--border-color);
        }}
        
        /* 代码块容器 */
        .code-block-wrapper {{
            margin: 1.2em 0;
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            background-color: var(--code-block-bg);
        }}
        
        /* 语言标签 */
        .code-lang {{
            background-color: var(--border-color);
            color: var(--text-color);
            padding: 4px 12px;
            font-size: 0.75em;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border-color);
        }}
        
        /* 代码块样式 */
        pre {{
            margin: 0;
            padding: 16px 20px;
            overflow-x: auto;
            background-color: transparent;
        }}
        
        .code-block {{
            font-family: "JetBrains Mono", "Fira Code", "SF Mono", Monaco, "Cascadia Code", Consolas, monospace;
            font-size: 0.9em;
            line-height: 1.6;
            background: none;
            padding: 0;
            border: none;
            display: block;
        }}
        
        /* 语法高亮 */
        .token-keyword {{ color: var(--token-keyword); font-weight: 600; }}
        .token-string {{ color: var(--token-string); }}
        .token-comment, .token-comment-block {{ color: var(--token-comment); font-style: italic; }}
        .token-number {{ color: var(--token-number); }}
        .token-function {{ color: var(--token-function); }}
        .token-class {{ color: var(--token-class); }}
        .token-flag, .token-flag-short {{ color: var(--token-flag); }}
        .token-url {{ color: var(--token-url); text-decoration: underline; }}
        .token-key {{ color: var(--token-attr); }}
        .token-tag {{ color: var(--token-tag); }}
        .token-attr-name {{ color: var(--token-attr); }}
        .token-value {{ color: var(--token-string); }}
        .token-selector {{ color: var(--token-class); }}
        .token-property {{ color: var(--token-keyword); }}
        .token-at-rule {{ color: var(--token-flag); }}
        .token-docstring {{ color: var(--token-comment); }}
        
        blockquote {{
            background-color: var(--blockquote-bg);
            border-left: 4px solid var(--blockquote-border);
            margin: 1em 0;
            padding: 1em 1.5em;
            font-style: italic;
            border-radius: 0 4px 4px 0;
        }}
        
        blockquote p {{
            margin: 0;
        }}
        
        ul, ol {{
            margin: 1em 0;
            padding-left: 2em;
        }}
        
        li {{
            margin: 0.4em 0;
        }}
        
        img {{
            max-width: 100%;
            height: auto;
            border-radius: 6px;
            margin: 1em 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        hr {{
            border: none;
            border-top: 2px solid var(--border-color);
            margin: 2em 0;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 1em 0;
            border-radius: 6px;
            overflow: hidden;
        }}
        
        th, td {{
            border: 1px solid var(--border-color);
            padding: 10px 14px;
            text-align: left;
        }}
        
        th {{
            background-color: var(--code-bg);
            font-weight: 600;
        }}
        
        tr:nth-child(even) {{
            background-color: var(--blockquote-bg);
        }}
        
        @media (max-width: 600px) {{
            body {{
                padding: 24px 16px;
            }}
            
            h1 {{ font-size: 1.8em; }}
            h2 {{ font-size: 1.5em; }}
            h3 {{ font-size: 1.25em; }}
            
            pre {{
                padding: 12px 16px;
            }}
            
            .code-block {{
                font-size: 0.85em;
            }}
        }}
        
        /* 平滑滚动 */
        html {{
            scroll-behavior: smooth;
        }}
        
        /* 选中文字样式 */
        ::selection {{
            background-color: var(--link-color);
            color: white;
        }}
    </style>
</head>
<body>
{body_html}
</body>
</html>'''
    
    return html_template


def main():
    parser = argparse.ArgumentParser(description='Convert Markdown to HTML with syntax highlighting')
    parser.add_argument('input', help='Input Markdown file path')
    parser.add_argument('-o', '--output', help='Output HTML file path (optional)')
    parser.add_argument('-t', '--title', default='Markdown Document', help='HTML page title')
    
    args = parser.parse_args()
    
    # 读取 Markdown 文件
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)
    
    md_content = input_path.read_text(encoding='utf-8')
    
    # 如果没有指定标题，使用文件名
    title = args.title
    if title == 'Markdown Document':
        title = input_path.stem
    
    # 转换
    html_content = convert_markdown_to_html(md_content, title)
    
    # 确定输出路径
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = input_path.with_suffix('.html')
    
    # 写入文件
    output_path.write_text(html_content, encoding='utf-8')
    print(f"✅ Converted: {input_path} -> {output_path}")


if __name__ == '__main__':
    main()
