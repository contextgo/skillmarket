---
name: stock_announcement
description: Daily stock portfolio analysis with Gmail report delivery and Sonos TTS announcement
version: 1.1.0
tags: ['finance', 'stocks', 'gmail', 'sonos', 'daily-report']
metadata:
  openclaw:
    requires:
      bins: ["sonos"]
    install:
      - id: pip-deps
        kind: pip
        packages: ["yfinance", "pandas", "google-auth", "google-auth-oauthlib", "google-api-python-client", "gTTS", "python-dotenv"]
        label: "Install Python dependencies"
---

# Stock Announcement

Daily stock portfolio analysis that generates an HTML email report via Gmail and announces performance on Sonos speakers.

## Setup

1. Configure Gmail OAuth credentials in `config/credentials.json` and `config/token.json`
2. Set environment variables:
   - `SONOS_SPEAKER` — Sonos speaker name (default: `Living Room`)
   - `RECIPIENT_EMAIL` — report recipient email
   - `GMAIL_TOKEN_PATH` — absolute path to `token.json` (optional, defaults to `config/token.json` in workspace)
   - `GMAIL_CREDENTIALS_PATH` — absolute path to `credentials.json` (optional)

## Usage

```bash
python3 scripts/daily_stock_announcement.py
```

## What's Fixed in 1.1.0

- **Gmail**: Uses absolute token path with auto-refresh and retry with exponential backoff
- **Sonos**: Replaces non-existent `sonos say` command with gTTS audio generation + `sonos play`
- **Reliability**: Structured logging, timeout handling, non-zero exit on partial failure