---
name: cn-math-calculator
version: "1.3.0"
description: "数学表达式安全计算器。支持四则运算、科学函数、常量、单位换算。纯Python标准库，无需API Key。"
scope: "calculator, math, unit conversion"
---

# cn-math-calculator

数学表达式计算器。支持基本运算、科学计算。

## 功能

- 四则运算 + - * / ^(幂) %(取模)
- 科学函数：sin, cos, tan, log, sqrt, abs
- 常量：pi, e
- 表达式安全求值（不使用eval）
- 纯本地处理，无需API

## 使用方法

```bash
python3 scripts/math_calculator.py "2+3*4"
python3 scripts/math_calculator.py "sqrt(144)"
python3 scripts/math_calculator.py "sin(pi/2)"
```

## 示例

输入：`2+3*4` → 输出：`结果: 14.0`
