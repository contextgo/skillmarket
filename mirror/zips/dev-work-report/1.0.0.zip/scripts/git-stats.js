#!/usr/bin/env node

/**
 * Git Statistics Collector
 *
 * Collect commit statistics from a local git repository,
 * separating business code from resource files.
 *
 * Usage:
 *   node git-stats.js --repo <path> --author <name> --since <date> --until <date> [--resource-patterns <patterns>]
 *
 * Output: JSON with commit stats, business code changes, and resource file changes.
 */

const { execSync } = require('child_process');
const path = require('path');

// Default patterns for resource/non-business files
const DEFAULT_RESOURCE_PATTERNS = [
  'skills/',
  'assets/',
  'vendor/',
  'node_modules/',
  '.codebuddy/',
];

const DEFAULT_RESOURCE_EXTENSIONS = [
  '.md',
  '.txt',
  '.png',
  '.svg',
  '.ico',
  '.jpg',
  '.jpeg',
  '.gif',
  '.woff',
  '.woff2',
  '.ttf',
  '.eot',
];

function parseArgs() {
  const args = process.argv.slice(2);
  const parsed = {};

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--repo') parsed.repo = args[++i];
    else if (args[i] === '--author') parsed.author = args[++i];
    else if (args[i] === '--since') parsed.since = args[++i];
    else if (args[i] === '--until') parsed.until = args[++i];
    else if (args[i] === '--resource-patterns') parsed.resourcePatterns = args[++i].split(',');
    else if (args[i] === '--branch') parsed.branch = args[++i];
    else if (args[i] === '--weekly') parsed.weekly = true;
    else if (args[i] === '--week-start') parsed.weekStart = args[++i]; // 0=Sun, 1=Mon, 2=Tue, ...
  }

  if (!parsed.repo || !parsed.author || !parsed.since || !parsed.until) {
    console.error('Usage: node git-stats.js --repo <path> --author <name> --since <date> --until <date>');
    console.error('Options:');
    console.error('  --branch <name>           Branch name (default: current branch)');
    console.error('  --resource-patterns <p>   Comma-separated resource path patterns');
    console.error('  --weekly                  Include weekly breakdown');
    console.error('  --week-start <day>        Week start day: 0=Sun..6=Sat (default: 2=Tue)');
    process.exit(1);
  }

  return parsed;
}

function exec(cmd, cwd) {
  try {
    return execSync(cmd, { cwd, encoding: 'utf-8', maxBuffer: 50 * 1024 * 1024 });
  } catch (e) {
    return '';
  }
}

function getCommitList(repo, author, since, until, branch) {
  const branchArg = branch ? ` ${branch}` : '';
  const cmd = `git log --author="${author}" --since="${since}" --until="${until}" --format="%H|%ai|%s"${branchArg}`;
  const output = exec(cmd, repo);

  if (!output.trim()) return [];

  return output.trim().split('\n').map((line) => {
    const [hash, date, ...msgParts] = line.split('|');
    return {
      hash: hash.trim(),
      date: date.trim(),
      message: msgParts.join('|').trim(),
    };
  });
}

function getNumstat(repo, author, since, until, branch) {
  const branchArg = branch ? ` ${branch}` : '';
  const cmd = `git log --author="${author}" --since="${since}" --until="${until}" --numstat --pretty="COMMIT:%H|%ai|%s"${branchArg}`;
  const output = exec(cmd, repo);

  if (!output.trim()) return [];

  const commits = [];
  let current = null;

  for (const line of output.split('\n')) {
    if (line.startsWith('COMMIT:')) {
      if (current) commits.push(current);
      const [hash, date, ...msgParts] = line.slice(7).split('|');
      current = {
        hash: hash.trim(),
        date: date.trim(),
        message: msgParts.join('|').trim(),
        files: [],
      };
    } else if (current && line.trim()) {
      const parts = line.split('\t');
      if (parts.length >= 3) {
        const add = parts[0] === '-' ? 0 : parseInt(parts[0], 10);
        const del = parts[1] === '-' ? 0 : parseInt(parts[1], 10);
        current.files.push({ add, del, path: parts[2] });
      }
    }
  }

  if (current) commits.push(current);
  return commits;
}

function isResourceFile(filePath, resourcePatterns) {
  const patterns = resourcePatterns || DEFAULT_RESOURCE_PATTERNS;
  const ext = path.extname(filePath).toLowerCase();

  // Check path patterns
  for (const pattern of patterns) {
    if (filePath.includes(pattern)) return true;
  }

  // Check if it's in a skills-like directory and has a resource extension
  if (DEFAULT_RESOURCE_EXTENSIONS.includes(ext)) {
    for (const pattern of patterns) {
      if (filePath.includes(pattern)) return true;
    }
  }

  return false;
}

function classifyFiles(commits, resourcePatterns) {
  const business = { add: 0, del: 0, files: new Set() };
  const resource = { add: 0, del: 0, files: new Set() };

  for (const commit of commits) {
    for (const file of commit.files) {
      if (isResourceFile(file.path, resourcePatterns)) {
        resource.add += file.add;
        resource.del += file.del;
        resource.files.add(file.path);
      } else {
        business.add += file.add;
        business.del += file.del;
        business.files.add(file.path);
      }
    }
  }

  return {
    business: { insertions: business.add, deletions: business.del, files: business.files.size },
    resource: { insertions: resource.add, deletions: resource.del, files: resource.files.size },
    total: {
      insertions: business.add + resource.add,
      deletions: business.del + resource.del,
      files: business.files.size + resource.files.size,
    },
  };
}

function getWeekNumber(dateStr, weekStartDay) {
  const date = new Date(dateStr);
  const start = weekStartDay || 2; // Default: Tuesday

  // Adjust to week start
  const dayOfWeek = date.getDay();
  const diff = (dayOfWeek - start + 7) % 7;
  const weekStart = new Date(date);
  weekStart.setDate(date.getDate() - diff);
  weekStart.setHours(0, 0, 0, 0);

  return weekStart.toISOString().slice(0, 10);
}

function buildWeeklyBreakdown(commits, weekStartDay) {
  const weeks = {};

  for (const commit of commits) {
    const weekKey = getWeekNumber(commit.date, weekStartDay);
    if (!weeks[weekKey]) {
      weeks[weekKey] = { commits: [], fileStats: { add: 0, del: 0, files: new Set() } };
    }
    weeks[weekKey].commits.push({
      hash: commit.hash,
      date: commit.date,
      message: commit.message,
    });
    for (const file of commit.files) {
      weeks[weekKey].fileStats.add += file.add;
      weeks[weekKey].fileStats.del += file.del;
      weeks[weekKey].fileStats.files.add(file.path);
    }
  }

  // Convert Sets to counts and sort by week
  return Object.entries(weeks)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([weekStart, data]) => {
      const startDate = new Date(weekStart);
      const endDate = new Date(startDate);
      endDate.setDate(startDate.getDate() + 6);

      return {
        weekStart,
        weekEnd: endDate.toISOString().slice(0, 10),
        commitCount: data.commits.length,
        commits: data.commits,
        stats: {
          insertions: data.fileStats.add,
          deletions: data.fileStats.del,
          files: data.fileStats.files.size,
        },
      };
    });
}

function main() {
  const args = parseArgs();
  const weekStartDay = args.weekStart ? parseInt(args.weekStart, 10) : 2;

  const commits = getNumstat(args.repo, args.author, args.since, args.until, args.branch);
  const stats = classifyFiles(commits, args.resourcePatterns);
  const repoName = path.basename(args.repo);

  const result = {
    repo: repoName,
    repoPath: args.repo,
    author: args.author,
    period: { since: args.since, until: args.until },
    commitCount: commits.length,
    ...stats,
  };

  if (args.weekly) {
    result.weekly = buildWeeklyBreakdown(commits, weekStartDay);
  }

  console.log(JSON.stringify(result, null, 2));
}

main();
