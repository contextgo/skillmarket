# Work Report Template

This is the canonical template for generating work reports. Replace all `{{placeholder}}` values with actual data.

---

```markdown
# 工作报告

> **姓名**：{{author}}
> **角色**：{{role}}
> **项目**：{{project_names}}
> **统计周期**：{{period_start}} — {{period_end}}（约 {{weeks_count}} 周）
> **周期划分**：{{week_cycle_description}}
> **提交统计**：{{repo1_name}} {{repo1_commits}} commits / {{repo2_name}} {{repo2_commits}} commits，共 {{total_commits}} 个有效提交
> **业务代码变更**：+{{biz_insertions}} / -{{biz_deletions}} 行（{{biz_files}} 个文件）
> **资源文件变更**：+{{res_insertions}} / -{{res_deletions}} 行（{{res_files}} 个文件，{{res_description}}）
> **总计变更**：+{{total_insertions}} / -{{total_deletions}} 行，{{total_files}} 个文件
>
> **仓库地址**：
> - {{repo1_label}}：[{{repo1_url_display}}]({{repo1_url}})
> - {{repo2_label}}：[{{repo2_url_display}}]({{repo2_url}})

---

## 整体工作概览

作为{{role_short}}，主导完成了以下功能模块：

1. **{{module_name}}**：{{status}}。{{description}}
2. ...

---

## 累计数据统计

| 维度 | 数量 |
|------|------|
| 参与周期 | {{weeks_count}} 周（{{period_start}} ~ {{period_end}}） |
| {{repo1_name}} 提交数 | {{repo1_commits}} 个有效 commit |
| {{repo2_name}} 提交数 | {{repo2_commits}} 个有效 commit |
| 业务代码变更 | {{repo1_name}} +{{r1_biz_add}} / -{{r1_biz_del}} 行（{{r1_biz_files}} 文件）；{{repo2_name}} +{{r2_biz_add}} / -{{r2_biz_del}} 行（{{r2_biz_files}} 文件） |
| 资源文件变更 | {{resource_change_detail}} |
| 业务代码合计 | +{{biz_insertions}} / -{{biz_deletions}} 行，{{biz_files}} 个文件 |
| 涉及模块 | {{module_list}} |
| 技术设计文档 | {{doc_count}} 篇 |

---

## TAPD 任务追踪

> 以下数据来源于 TAPD 项目 [{{project_name}}（workspace: {{workspace_id}}）](https://tapd.woa.com/tapd_fe/{{workspace_id}}/story/list)，仅列出 {{author}} 负责/参与的需求与缺陷。

### 迭代总览

| 迭代 | 周期 | 状态 |
|------|------|------|
| {{iteration_name}} | {{iteration_start}} ~ {{iteration_end}} | {{iteration_status_icon}} {{iteration_status}} |

### 任务统计

| 维度 | 数量 |
|------|------|
| 负责需求总数 | {{story_total}} 个（{{story_status_breakdown}}） |
| 负责缺陷总数 | {{bug_owner_total}} 个（{{bug_owner_status_breakdown}}） |
| 开发修复缺陷 | {{bug_dev_total}} 个（{{bug_dev_status_breakdown}}） |
| 跨迭代参与 | {{iteration_range}} |

### 需求（Story）— 我负责的（共 {{story_total}} 个）

| 需求 | 迭代 | 状态 | 优先级 | TAPD 链接 |
|------|------|------|--------|-----------|
| {{story_name}} | {{story_iteration}} | {{story_status_icon}} {{story_status}} | {{story_priority}} | [详情](https://tapd.woa.com/tapd_fe/{{workspace_id}}/story/detail/{{story_id}}) |

### 缺陷（Bug）— 共 {{bug_total}} 个

| 缺陷 | 迭代 | 角色 | 状态 | 优先级 | TAPD 链接 |
|------|------|------|------|--------|-----------|
| {{bug_title}} | {{bug_iteration}} | {{bug_role}} | {{bug_status_icon}} {{bug_status}} | {{bug_priority}} | [详情](https://tapd.woa.com/tapd_fe/{{workspace_id}}/bug/detail/{{bug_id}}) |

---

## 每周详细产出

### Week {{n}}（{{week_start}} ~ {{week_end}}）：{{week_title}}

| 项目 | 产出内容 |
|------|----------|
| {{repo_name}} | {{deliverable_description}} |

**本周贡献价值**：
- {{contribution_point_1}}
- {{contribution_point_2}}

---

## 核心产出物

### 代码模块

| 模块 | 关键文件 | 行数 | 说明 |
|------|---------|------|------|
| {{module_name}} | `{{file_name}}` | ~{{lines}} 行 | {{module_description}} |

### 技术设计文档

| 文档 | 内容 | 链接 |
|------|------|------|
| {{doc_title}} | {{doc_description}} | {{doc_filename}} |

---

## 项目经验价值

### 可复用的技术资产

| 资产 | 在项目中的形态 | 复用价值 |
|------|---------------|----------|
| {{asset_name}} | {{asset_form}} | {{asset_value}} |

### 工程能力沉淀

| 经验领域 | 具体收获 | 团队受益 |
|---------|---------|---------|
| {{domain}} | {{learning}} | {{team_benefit}} |

---

## 产品思考

### 1. {{thinking_title}}

{{thinking_content}}

---

## 简洁概要（群发版）

> This section provides a concise summary suitable for sharing in group chats or messaging apps.
> Wrap the content in a code block (```) so it can be copied directly without formatting issues.

\```
{{project_name}} 项目工作汇报（{{period_start}} — {{period_end}}，约 {{weeks_count}} 周）——{{author}}

角色：{{role}}
提交：{{total_commits}} commits（{{repo1_name}} {{repo1_commits}} + {{repo2_name}} {{repo2_commits}}），业务代码+{{biz_insertions}} / -{{biz_deletions}} 行
跨迭代：{{iteration_range}}（{{iteration_count}} 个迭代）
TAPD：{{story_total}}个需求（{{story_status_summary}}）

已完成：
1. {{completed_module_1}} — {{completed_desc_1}}
2. {{completed_module_2}} — {{completed_desc_2}}
...

进行中/ 待安排：
1. {{inprogress_module_1}} — {{inprogress_desc_1}}
2. {{inprogress_module_2}} — {{inprogress_desc_2}}
...
\```
```

---

## Template Usage Notes

### Status Icon Mapping

| Status (Chinese) | Icon |
|-------------------|------|
| 已完成 / 已关闭 | ✅ |
| 实现中 / 处理中 | 🟡 |
| 待开发 / 进行中 | 🔵 |
| 新建 | 🔴 |
| 规划中 | 📋 |

### Bug Role Classification

- **负责人**: The bug's `current_owner` matches the author
- **开发修复**: The bug's `de` (developer) or `fixer` matches the author, but `current_owner` does not

### Week Title Generation

Derive the week title from the most significant commits of that week. Look for:
1. New feature modules introduced
2. Major refactoring or optimization work
3. Bug fix campaigns
4. Infrastructure or tooling work

Format: `{{primary_focus}} + {{secondary_focus}}` (e.g., "Automation 初版 + SkillHub 接入 + Claw 加固")

### Contribution Value Writing Guidelines

For each week's contribution value section:
1. Highlight the **most impactful** deliverable first
2. Explain **why** it matters, not just **what** was done
3. Use specific metrics when available (line counts, component counts, performance numbers)
4. Connect technical work to user/business value
5. Keep to 2-4 bullet points per week

### Sections That Are Optional

The following sections should only be included for longer reports (>= 3 weeks) or when explicitly requested:
- 项目经验价值 (Project Experience & Value)
- 产品思考 (Product Thinking)
- 核心产出物 (Core Deliverables) — can be simplified for short reports

### Resource File Classification Patterns

Common patterns for identifying resource/non-business files:

| Pattern | Category | Example |
|---------|----------|---------|
| `skills/` | Skill packages | `skills/featured/tapd/SKILL.md` |
| `assets/` | Static assets | `assets/icons/logo.png` |
| `vendor/` | Vendored deps | `vendor/lib/parser.js` |
| `*.md` (in skill dirs) | Skill docs | `skills/ugit-mcp/SKILL.md` |
| `package-lock.json` | Lock files | `package-lock.json` |
| `*.png`, `*.svg`, `*.ico` | Images | `icon.png` |
