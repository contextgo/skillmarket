---
name: project-memory
description: >-
  管理项目根目录下 .memory/ 文件夹中的结构化记忆文件，支持三个操作：
  /memory.bootstrap（新对话开始时读取 project.md + context.md + decisions.md，输出项目现状摘要）；
  /memory.summarize（将当前对话压缩为 Goal / Decisions / Context / Open Questions / Next Actions 结构化摘要）；
  /memory.update（将摘要写入对应记忆文件，decisions.md 追加带精确日期的决策条目）。
  还支持：初始化 .memory/ 目录结构；从 Cursor agent-transcripts 的 .jsonl 文件系统时间戳中提取对话开始/结束时间（精确到分钟）。
  当用户说 /memory.bootstrap、/memory.summarize、/memory.update，或提到"记忆"、"恢复上下文"、"上下文太长"、"更新记忆"、"对话时间"时触发。
---

# Project Memory — 项目记忆管理

三个操作，覆盖"压缩 → 写入 → 恢复"完整闭环。

## 目录结构

项目根目录下固定使用：

```
.memory/
├── project.md      # 全局认知（每次对话必读）
├── context.md      # 当前阶段上下文（每次对话必读，< 200 行）
├── decisions.md    # 关键决策（必须单独存，决策丢失 = 项目失败）
├── tasks.md        # 待办 & 进度
├── glossary.md     # 概念 / 术语表
└── logs/
    └── YYYY-MM-DD.md   # 每日原材料（AI 不主动读）
```

---

## 操作 1：`/memory.summarize` — 压缩当前对话

**触发时机**：对话快达到上下文上限、或阶段性工作完成时。

执行步骤：

1. 阅读本次对话（或用户指定的对话片段）
2. 按以下模板输出结构化摘要，**不要输出废话、情绪、过程讨论**：

```markdown
## Goal（当前目标）
- 

## Decisions（关键决策）
- 

## Context（重要上下文）
- 技术关键点：
- 约束与边界：

## Open Questions（未解决问题）
- 

## Next Actions（下一步）
- [ ] 
```

3. 输出后告知用户："摘要已生成，可运行 `/memory.update` 写入文件。"

---

## 操作 2：`/memory.update` — 写入记忆文件

**触发时机**：`/memory.summarize` 完成后，或用户明确要求保存进度时。

执行步骤：

1. **读取现有文件**（如存在）：`.memory/project.md`、`.memory/context.md`、`.memory/decisions.md`
2. 按规则更新（不重复已有内容，只追加或修改差异部分）：

| 文件 | 更新条件 | 写入内容 |
|------|---------|---------|
| `project.md` | 有全局架构/技术栈变化 | 覆盖或追加对应章节 |
| `context.md` | 当前阶段有进展 | **替换**为最新状态，保持 < 200 行 |
| `decisions.md` | 有新的明确决策 | 追加，带日期 |
| `tasks.md` | 任务状态变化 | 更新对应条目 |
| `logs/YYYY-MM-DD.md` | 每次都写 | 追加本次摘要原文 |

3. 直接用工具写入/编辑文件，完成后输出变更列表。

**写入原则**：
- `context.md` 是核心，永远 < 200 行
- 只存：架构、决策、约束；不存：过程讨论、情绪、无关推导
- 保持文件结构稳定，使用固定标题

---

## 操作 3：`/memory.bootstrap` — 新对话恢复上下文

**触发时机**：每次新开对话的第一句话，或用户要求"恢复上下文"时。

执行步骤：

1. 依次读取（**必须按顺序**，缺失的文件跳过）：
   - `.memory/project.md`
   - `.memory/context.md`
   - `.memory/decisions.md`
   - `.memory/tasks.md`（可选）

2. 按以下格式输出上下文摘要：

```markdown
## 项目现状
[项目在做什么，1-3句]

## 当前技术方案
[核心架构与关键技术选型]

## 已确定约束
- 

## 近期决策
- [日期] 决策内容

## 建议下一步
- [ ] 
```

3. 输出后进入正常对话，无需再重复读文件。

---

## 初始化：首次创建记忆文件

如果 `.memory/` 目录不存在，执行初始化：

1. 创建目录结构（含 `logs/` 子目录）
2. 使用以下模板创建基础文件：

**project.md 模板**：
```markdown
# 项目概述

## 目标
- 

## 核心能力
- 

## 技术栈
- 

## 关键约束
- 
```

**context.md 模板**：
```markdown
# 当前阶段

## 正在做
- 

## 关键问题
- 

## 阶段目标
- 

_最后更新：YYYY-MM-DD_
```

**decisions.md 模板**：
```markdown
# 关键决策记录

| 日期 | 决策 | 原因 | 影响 |
|------|------|------|------|
|  |  |  |  |
```

---

## 注意事项

- AI 每次对话只读 `project.md` + `context.md`，`logs/` 是原材料不主动读
- `context.md` 超过 200 行时必须压缩，删除过时内容
- 决策必须有日期，方便追溯
- 文件路径始终相对于**项目根目录**

## 对话时间戳获取（精确到分钟）

Cursor 将每次对话存为 `.jsonl` 文件，**文件内部无时间字段**，但 Windows 文件系统时间戳可精确到秒。

**文件位置**：
```
C:\Users\<用户名>\.cursor\projects\<项目ID>\agent-transcripts\<会话UUID>\<会话UUID>.jsonl
```

**获取命令**（PowerShell）：
```powershell
Get-ChildItem "$env:USERPROFILE\.cursor\projects" -Recurse -Filter "*.jsonl" |
  Where-Object { $_.Directory.Name -eq $_.BaseName } |
  Select-Object BaseName,
    @{N="开始";E={$_.CreationTime.ToString("MM-dd HH:mm")}},
    @{N="结束";E={$_.LastWriteTime.ToString("MM-dd HH:mm")}} |
  Sort-Object 开始
```

**字段含义**：
- `CreationTime` → 对话**开始**时间
- `LastWriteTime` → 对话**最后一条消息**时间
- 两者之差 = 本次对话持续时长

**写入 decisions.md 时的日期格式**：统一使用 `YYYY-MM-DD`（精确到天已足够决策追溯）。
