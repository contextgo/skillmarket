# Pro 模块（进阶提效）

## 高收益动作
- 30 秒定位法：文件名 -> 符号 -> 调用链
- 可回滚重构：每步可运行、可测试、可回退
- 性能优化：先测量，再优化，再复测

## 指标
- Time to Locate
- First Fix Rate
- Mean Verify Time
- Rework Ratio

适用：复杂改造、性能优化、长期提效体系建设。
