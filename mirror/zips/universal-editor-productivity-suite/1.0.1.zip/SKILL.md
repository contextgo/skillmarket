---
name: universal-editor-productivity-suite
description: Unified editor-agnostic productivity suite for mainstream code editors. Use when users want practical workflows to improve coding speed, navigation, debugging, AI collaboration, and team delivery efficiency.
---

# Universal Editor Productivity Suite

## Slug
`universal-editor-productivity-suite`

## 使用方式
这是统一入口（单一 slug）。按场景读取对应模块，不需要全部一次性加载。

## 模块索引（按场景）
- 日常编码提效：`lite.md`
- 团队协作与评审：`team.md`
- 高阶优化与长期能力建设：`pro.md`
- 高效排障：`debug.md`
- AI 协作编码：`ai.md`
- 需求澄清与任务切分：`requirements.md`
- 搜索定位与重构安全：`navigation-refactor.md`
- 测试策略与回归验证：`testing-regression.md`
- Git/PR/发布流程：`git-release.md`
- 环境故障与性能卡顿应急：`environment-rescue.md`
- 多任务并行与时间管理：`parallel-planning.md`
- 跨团队沟通模板：`communication.md`
- 高频编程场景剧本：`scenario-playbooks.md`
- 提效指标与持续改进：`metrics-improvement.md`

## 全局硬规则
1. 未经用户明确同意，不生成本地文件。
2. 修改后必须提供最短验证路径。
3. 连续 3 次无效尝试必须切换策略并说明原因。
4. 结论必须绑定证据（文件/命令/结果）。
5. 优先做高价值动作：定位 -> 小改 -> 验证 -> 总结。
