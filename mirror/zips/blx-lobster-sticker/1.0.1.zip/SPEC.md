# blx-lobster-sticker 技能规范

## 概述

**名称：** blx-lobster-sticker  
**描述：** OpenClaw专属小龙虾🦞（crayfish）主题表情包技能。由白灵汐（BLX）创作。生成统一风格的卡通小龙虾LINE贴纸表情包，共约100+种情绪和物品表情，适用于对话机器人、客服AI、聊天助手等场景。

**基础角色：** 可爱卡通风的小龙虾（crayfish），红色外壳、大眼睛、白色厚边框LINE贴纸风格，粉红色腮红，kawaii chibi比例。

## 风格规范

- **角色：** 红色卡通小龙虾，大眼睛圆圆的
- **风格：** LINE贴纸风格，厚白色边框（3-4px）
- **表情：** kawaii chibi，头大身小，圆形为主
- **背景：** 白色透明背景
- **色调：** 红色主色（龙虾）、粉色腮红、深红点缀
- **尺寸：** 512x512px 输出

## 情绪表情（核心集）

| 编号 | 情绪 | 触发关键词 | 文件名 |
|------|------|-----------|--------|
| 001 | 开心 | 开心、高兴、快乐、太棒了 | 001_happy.png |
| 002 | 难过 | 难过、伤心、哭、失落 | 002_sad.png |
| 003 | 生气 | 生气、愤怒、气死了 | 003_angry.png |
| 004 | 惊讶 | 哇、震惊、惊讶、意外 | 004_surprised.png |
| 005 | 得意 | 得意、骄傲、太牛了 | 005_smug.png |
| 006 | 害羞 | 害羞、脸红、不好意思 | 006_shy.png |
| 007 | 尴尬 | 尴尬、不好意思、囧 | 007_embarrassed.png |
| 008 | 困倦 | 困、累了、想睡觉 | 008_sleepy.png |
| 009 | 感动 | 感动、暖心、谢谢 | 009_touched.png |
| 010 | 爱意 | 爱、喜欢、么么哒 | 010_love.png |
| 011 | 酷帅 | 酷、帅、牛、厉害 | 011_cool.png |
| 012 | 疑惑 | 困惑、疑问、什么鬼 | 012_confused.png |
| 013 | 惊恐 | 惊恐、害怕、吓人 | 013_scared.png |
| 014 | 委屈 | 委屈、快哭了、伤心 | 014_pitiful.png |
| 015 | 无语 | 无语、无话可说 | 015_speechless.png |
| 016 | 奸笑 | 奸笑、阴险、坏笑 | 016_evil.png |
| 017 | 调侃 | 调侃、调皮、犯贱 | 017_mischief.png |
| 018 | 社会 | 社会、社会人 | 018_social.png |
| 019 | 吃瓜 | 吃瓜、看戏、围观 | 019_melon.png |
| 020 | 发怒 | 发怒、怒火中烧 | 020_rage.png |
| 021 | 撇嘴 | 撇嘴、不屑 | 021_dismissive.png |
| 022 | 微笑 | 微笑、淡淡笑 | 022_smile.png |
| 023 | 呆住 | 呆住、发呆、懵 | 023_blank.png |
| 024 | 抓狂 | 抓狂、发疯 | 024_crazy.png |
| 025 | 偷笑 | 偷笑、窃笑 | 025_sneer.png |
| 026 | 白眼 | 白眼、翻白眼 | 026_eyeroll.png |
| 027 | 憨笑 | 憨笑、傻笑 | 027_silly_smile.png |
| 028 | 悠闲 | 悠闲、惬意 | 028_relaxed.png |
| 029 | 叹气 | 叹气、叹息 | 029_sigh.png |
| 030 | 咒骂 | 咒骂、粗口 | 030_curse.png |
| 031 | 骷髅 | 骷髅、死 | 031_skull.png |
| 032 | 再见 | 再见、拜拜 | 032_goodbye.png |
| 033 | 擦汗 | 擦汗、汗 | 033_wipesweat.png |
| 034 | 鼓掌 | 鼓掌、拍手 | 034_applause.png |
| 035 | 鄙视 | 鄙视、看不起 | 035_despise.png |
| 036 | 亲亲 | 亲亲、飞吻 | 036_kiss.png |
| 037 | 可怜 | 可怜、怜悯 | 037_pity.png |
| 038 | 生病 | 生病、不舒服 | 038_sick.png |
| 039 | 脸红 | 脸红、害羞红 | 039_blush.png |
| 040 | 恐惧 | 恐惧、害怕 | 040_fear.png |
| 041 | 失望 | 失望、失落 | 041_disappointed.png |
| 042 | 愤怒 | 怒火、气炸 | 042_fury.png |
| 043 | 得意笑 | 得意笑、胜利笑 | 043_victory.png |
| 044 | 加油 | 加油、鼓励 | 044_cheer.png |
| 045 | 耶 | 耶、欢呼 | 045_yay.png |
| 046 | OK | OK、好的、行 | 046_ok.png |
| 047 | 拳头 | 拳头、握拳 | 047_fist.png |
| 048 | 拥抱 | 拥抱、抱抱 | 048_hug.png |
| 049 | 心碎 | 心碎、悲伤心 | 049_broken_heart.png |
| 050 | 强 | 强、厉害 | 050_strong.png |

## 物品表情

| 编号 | 物品 | 文件名 |
|------|------|--------|
| P01 | 爱心 | P01_heart.png |
| P02 | 蛋糕 | P02_cake.png |
| P03 | 咖啡 | P03_coffee.png |
| P04 | 啤酒 | P04_beer.png |
| P05 | 玫瑰 | P05_rose.png |
| P06 | 月亮 | P06_moon.png |
| P07 | 太阳 | P07_sun.png |
| P08 | 星星 | P08_star.png |
| P09 | 炸弹 | P09_bomb.png |
| P10 | 便便 | P10_poop.png |
| P11 | 猪头 | P11_pig.png |
| P12 | 骷髅 | P12_skull.png |
| P13 | 烟花 | P13_fireworks.png |
| P14 | 红包 | P14_redpacket.png |
| P15 | 礼物 | P15_gift.png |
| P16 | 蛋糕庆祝 | P16_celebrate.png |
| P17 | 啤酒干杯 | P17_toast.png |
| P18 | 凋谢花 | P18_wilted.png |
| P19 | 合十 | P19_prayer.png |
| P20 | 握手 | P20_handshake.png |

## 使用方式

当用户请求表情包时，使用 `image` 工具读取对应图片发送给用户。

**微信（WeChat）环境**：使用 `assets_wx/` 目录下的 JPG 文件
**其他环境**：使用 `assets/` 目录下的 PNG 文件

| 环境 | 路径 | 格式 | 大小 |
|------|------|------|------|
| 微信 | `assets_wx/[文件名].jpg` | JPG | ~30KB |
| 其他 | `assets/[文件名].png` | PNG | ~245KB |

## 更新日志

- v1.0.0 (2026-04-01): 初始版本，核心30+表情开发中
