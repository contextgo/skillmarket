---
name: mano-cua
description: Computer use for GUI automation tasks via VLA models. Use when the user describes a task in natural language that requires visual screen interaction and no API or CLI exists for the target app.
homepage: https://github.com/Mininglamp-AI/mano-skill
metadata: {"openclaw": {"emoji": "🖥️", "install": [{"id": "brew", "kind": "brew", "formula":"Mininglamp-AI/tap/mano-cua", "bins":["mano-cua"],"label": "Install mano-cua (brew)"}]}}
---

# mano-cua

Desktop GUI automation driven by natural language. Captures screenshots, sends them to a cloud-based hybrid vision model, and executes the returned actions on the local machine — click, type, scroll, drag, and more.

## Requirements

- A system with a **graphical desktop** (macOS / Windows / Linux)
- `mano-cua` binary installed

### Installation

**macOS / Linux (Homebrew):**

```bash
brew install Mininglamp-AI/tap/mano-cua
```

**Windows:**

Download the latest `mano-cua-windows.zip` from [GitHub Releases](https://github.com/Mininglamp-AI/mano-skill/releases), extract it, and add the folder to your `PATH`.

## Usage

```bash
# Run a task (cloud mode, default)
mano-cua run "your task description"

# Run with options
mano-cua run "task" --minimize --max-steps 10

# Run in local mode (on-device inference, macOS Apple Silicon only)
mano-cua run "task" --local

# Stop the current running task
mano-cua stop
```

Run `mano-cua --help` or `mano-cua <command> --help` for full flags and options.

> **Note:** Only one task can run at a time per device. If you need to start a new task, first stop the current one with `mano-cua stop`.

## Local Mode

Runs [Mano-P](https://huggingface.co/Mininglamp-2718/Mano-P) entirely on-device via MLX. No data leaves the machine. Requires macOS with Apple Silicon (M1+).

**Setup:**

```bash
mano-cua check
mano-cua install-sdk
mano-cua install-model
```

**Run:**

```bash
mano-cua run "Open Safari and search for Python" --local
mano-cua run "在搜索框中输入hello" --local --url "https://www.baidu.com" --minimize --max-steps 15
```

## Examples

```bash
# Cloud mode (default — no setup needed)
mano-cua run "Open WeChat and tell FTY that the meeting is postponed"
mano-cua run "Search for AI news in Xiaohongshu and show the first post" --minimize --max-steps 20

# Local mode
mano-cua run "Compare the flight price tiers" --local --url "https://www.flightaware.com/"

# Stop the current task (use before starting a new one)
mano-cua stop
```

## How It Works

The current screenshot is captured and sent to the cloud at each step. A hybrid vision solution decides the next action:

- **Mano model** — handles straightforward, lightweight tasks with rapid output.
- **Claude CUA model** — handles complex tasks requiring deeper reasoning.

The system automatically selects the appropriate model based on task complexity.

In **local mode (`--local`)**, a local Mano-P model runs on-device via MLX. No network calls for inference.

## Supported Interactions

click · type · hotkey · scroll · drag · mouse move · screenshot · wait · app launch · url direction

## Status Panel

A small UI panel is displayed on the top-right corner of the screen to track and manage the current session status.

## Data, Privacy & Safety

- **What is sent:** Screenshots of the primary display and the task description are sent to `mano.mininglamp.com` — these are the minimal inputs required for the vision model to determine the next action.
- **What is NOT sent:** No local files, clipboard content, or system credentials are read or transmitted. All network calls are in a single module ([`task_model.py`](https://github.com/Mininglamp-AI/mano-skill/blob/main/visual/model/task_model.py)) for easy review.
- **Local mode:** All inference runs on-device using [Mano-P](https://github.com/Mininglamp-AI/Mano-P) ([model weights](https://huggingface.co/Mininglamp-2718/Mano-P)). No data leaves the machine.
- **Authentication:** No API key or credentials are required. The client identifies itself with a locally generated device ID (`~/.myapp_device_id`) — no secrets are embedded in the binary.
- **Supply chain:** The full client is [open source](https://github.com/Mininglamp-AI/mano-skill). The Homebrew formula builds directly from this public source, ensuring the installed binary is fully auditable.
- **User control:** Users can stop any session at any time via the UI panel or `mano-cua stop`.

## Important Notes

- **Do not use the mouse or keyboard during the task.** Manual input while mano-cua is running may cause unexpected behavior.
- **Multiple displays:** only the primary display is used. All mouse movements, clicks, and screenshots are restricted to that display.

## Platform Support

macOS is the preferred and most tested platform. Adaptations for Windows and Linux are not yet fully completed — minor issues are expected.
