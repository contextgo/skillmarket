---
source_id: card-001
source_type: arxiv
data_level: full_text_available
url: https://arxiv.org/pdf/2110.10381v1.pdf
---

## 来源信息
- 标题: Medical Knowledge-Guided Deep Curriculum Learning for Elbow Fracture Diagnosis from X-Ray Images
- arXiv ID: 2110.10381v1
- 数据级别: 全文可获取

## 提取状态
- ⏳ 待提取: 需下载PDF并运行提取脚本
- 获取命令: python3 scripts/extract-from-pdf.py card-001 "https://arxiv.org/pdf/2110.10381v1.pdf"
