# 赛博跑者 (Cyber Runner)

> 你的AI跑步教练，让数据驱动你的每一步

## 简介

**赛博跑者** 是一款基于AI的跑步训练分析工具，专注于帮助跑者深度挖掘训练数据、评估运动能力、制定科学训练计划。

### 核心定位
- **数据同步枢纽**：无缝对接 Intervals.icu 平台
- **智能分析引擎**：自动识别训练类型、解析配速心率数据
- **能力评估专家**：基于CS-D'模型预测你的最佳成绩
- **训练顾问**：提供个性化的配速和心率区间建议

---

## 核心能力

### 1. Intervals.icu 数据同步

支持双向同步训练数据：
- **上传**：将训练计划导出到 Intervals.icu
- **下载**：获取历史训练记录进行分析

#### API配置
```markdown
# 在 references/intervals_api.md 查看完整API文档
```

### 2. 训练数据智能分析

#### 训练类型识别
自动识别以下训练类型：
- **EASY** - 低强度有氧跑
- **LSD** - 长距离慢跑
- **TEMPO** - 节奏跑
- **INTERVAL** - 间歇训练
- **VO2MAX** - 最大摄氧量训练
- **RECOVERY** - 恢复跑
- **LONG** - 长跑
- **RACE** - 比赛

#### 配速分析
- 实时配速追踪
- 配速区间分布
- 配速趋势分析
- 间歇配速稳定性评估

#### 心率分析
- 心率区间分布
- 心率恢复曲线
- 有氧/无氧阈值识别

### 3. 能力评估与预测

#### CS-D' 临界配速模型
基于临界速度(CS)和D'储备距离理论，计算：
- 临界配速 (Critical Speed)
- D'储备 (D' Reserve)
- 各距离预测成绩：
  - 5K、10K、半马、全马
  - 自定义距离

#### 配速区间计算
自动生成五区间配速体系：
- Z1: 轻松跑 (E)
- Z2: 马配速 (M)
- Z3: 节奏阈 (T)
- Z4: 阈值以上 (A)
- Z5: VO2Max (I)

### 4. 个性化训练建议

根据能力评估结果和训练历史，提供：
- 训练强度建议
- 间歇训练配速目标
- 恢复时间计算
- 训练负荷评估

---

## 快速开始

### 环境要求
```
Python 3.8+
requests
pandas
numpy
```

### 基础使用

```python
from scripts.training_classifier import TrainingClassifier
from scripts.cs_d_calculator import CSDCalculator

# 初始化分析器
classifier = TrainingClassifier()

# 分析训练类型
result = classifier.analyze(
    pace_data=[...],      # 配速序列
    heart_rate_data=[...], # 心率序列
    duration=1800         # 时长(秒)
)

# 计算CS-D'
calculator = CSDCalculator()
cs_result = calculator.calculate(
    distances=[5000, 10000],  # 已完成距离
    times=[1200, 2520]        # 对应时间
)

print(f"临界配速: {cs_result['critical_speed']:.2f} m/s")
print(f"5K预测: {cs_result['predictions']['5k']}")
```

### Intervals.icu 同步

```python
from intervals_sync import IntervalsClient

client = IntervalsClient(api_key="your-api-key")

# 下载训练数据
activities = client.get_activities(start_date="2024-01-01")

# 分析训练
for activity in activities:
    analysis = classifier.analyze_activity(activity)
```

---

## 使用场景

| 场景 | 功能 | 产出 |
|------|------|------|
| 训练复盘 | 周/月训练数据分析 | 训练总结报告 |
| 能力评估 | CS-D'模型计算 | 预测成绩表 |
| 计划制定 | Intervals同步 | 训练日历 |
| 间歇分析 | 间歇段落识别 | 配速稳定性评分 |
| 赛前预测 | 历史数据分析 | 分段配速策略 |

---

## 文件结构

```
赛博跑者/
├── SKILL.md                    # 本文件
├── references/
│   ├── intervals_api.md        # Intervals.icu API文档
│   ├── training_types.md       # 训练类型识别方法
│   ├── cs_d_prime.md           # CS-D'计算原理
│   └── pace_zones.md           # 配速区间定义
├── scripts/
│   ├── training_classifier.py  # 训练类型分类器
│   ├── rest_interval_detector.py # 休息段过滤
│   └── cs_d_calculator.py      # CS-D'计算器
└── examples/
    ├── example_analysis.md     # 分析案例
    └── example_report.md       # 报告模板
```

---

## 注意事项

1. **数据精度**：分析结果依赖GPS和心率设备精度
2. **首次使用**：建议至少输入3次不同距离的比赛数据以获得准确的CS值
3. **个人差异**：CS-D'模型是估算工具，实际表现受多种因素影响
4. **隐私保护**：所有数据处理在本地完成，不会上传到第三方服务器

---

## 适用跑者

- 🏃‍♂️ 有一定跑步基础（跑步1年以上）
- 📊 注重训练数据分析和科学训练
- 🏆 有明确的成绩目标（5K/10K/半马/全马）
- 📱 使用Garmin/Apple Watch/Polar等设备记录训练

---

*让数据照亮你的跑道，用科学武装你的每一步。*
