# 训练类型识别方法

## 概述

训练类型识别是赛博跑者的核心能力之一。通过分析配速、心率、时长等数据特征，自动识别训练类型。

## 训练类型定义

### 1. EASY (轻松跑)
- **配速**: Z1-Z2 区间
- **心率**: 最大心率的 60-70%
- **时长**: 20-90 分钟
- **特征**: 低强度、持续稳定

### 2. LSD (长距离慢跑)
- **配速**: Z2 区间下限
- **心率**: 最大心率的 65-75%
- **时长**: >90 分钟
- **特征**: 长时长、低强度、构建有氧基础

### 3. TEMPO (节奏跑)
- **配速**: Z3-Z4 区间
- **心率**: 最大心率的 80-88%
- **时长**: 20-60 分钟
- **特征**: 稳定配速、接近乳酸阈值

### 4. INTERVAL (间歇训练)
- **配速**: Z4-Z5 区间
- **心率**: 最大心率的 88-95%
- **时长**: 间歇单元 1-5 分钟
- **特征**: 高强度+恢复循环

### 5. VO2MAX (最大摄氧量训练)
- **配速**: Z5 区间
- **心率**: 最大心率的 95%+
- **时长**: 间歇单元 1-3 分钟
- **特征**: 极高强度、时间短

### 6. RECOVERY (恢复跑)
- **配速**: Z1 区间
- **心率**: 最大心率的 55-65%
- **时长**: <30 分钟
- **特征**: 极低强度、主动恢复

### 7. LONG (长跑)
- **配速**: Z2 区间
- **心率**: 最大心率的 70-80%
- **时长**: >2 小时
- **特征**: 长距离、能量系统建设

### 8. RACE (比赛)
- **配速**: 全力输出
- **心率**: 接近/达到最大
- **特征**: 单一努力级别

## 识别算法

### 特征提取

```python
def extract_features(activity_data):
    features = {
        # 配速特征
        'avg_pace': calculate_avg_pace(activity_data),
        'pace_variance': calculate_pace_variance(activity_data),
        'pace_stability': calculate_pace_stability(activity_data),
        
        # 心率特征
        'avg_hr': calculate_avg_hr(activity_data),
        'hr_zones': calculate_hr_zone_distribution(activity_data),
        'hr_recovery_rate': calculate_hr_recovery(activity_data),
        
        # 结构特征
        'duration': activity_data['duration'],
        'interval_count': detect_intervals(activity_data),
        'rest_periods': detect_rest_periods(activity_data),
        
        # 强度特征
        'intensity_score': calculate_intensity(activity_data),
        'training_load': estimate_training_load(activity_data)
    }
    return features
```

### 分类决策树

```
输入: 活动数据
      │
      ▼
┌─────────────────┐
│ 检测间歇模式?   │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
   是        否
    │         │
    ▼         ▼
间歇训练  检测强度级别
    │         │
    ▼    ┌────┴────┐
高强度?  │         │
    │    │ 低    中    高
   是    │  │    │     │
    │    │  ▼    ▼     ▼
    │  恢复 节奏  阈值/长距离
    ▼    │    │     │
VO2MAX   └────┴─────┘
         │
         ▼
    识别结果 + 置信度
```

### 间歇检测算法

```python
def detect_intervals(pace_data, threshold=0.15):
    """
    检测间歇训练模式
    
    参数:
        pace_data: 配速序列(标准化)
        threshold: 判定阈值(默认15%波动)
    
    返回:
        intervals: 检测到的间歇段落列表
    """
    intervals = []
    in_work = False
    work_start = 0
    
    for i, pace in enumerate(pace_data):
        if not in_work and pace > threshold:
            # 开始工作段
            in_work = True
            work_start = i
        elif in_work and pace < threshold:
            # 结束工作段
            in_work = False
            intervals.append({
                'start': work_start,
                'end': i,
                'duration': i - work_start,
                'avg_pace': np.mean(pace_data[work_start:i])
            })
    
    return intervals
```

### 休息段过滤

```python
def filter_rest_periods(pace_data, hr_data, rest_threshold=0.5):
    """
    过滤静止/休息段落
    
    检测逻辑:
    1. 配速接近0 (暂停)
    2. 长时间低配速 (>30s)
    3. 运动模式中断
    """
    filtered_pace = []
    filtered_hr = []
    
    for i in range(len(pace_data)):
        pace = pace_data[i]
        hr = hr_data[i]
        
        # 静止判定
        if pace < 0.5 and hr < 100:
            continue  # 跳过静止段
        
        # 长休息判定 (>30秒低强度)
        if pace < 1.0:
            duration = 1
            while i + duration < len(pace_data) and pace_data[i + duration] < 1.0:
                duration += 1
            if duration > 30:
                continue
        
        filtered_pace.append(pace)
        filtered_hr.append(hr)
    
    return filtered_pace, filtered_hr
```

## 置信度评估

```python
def calculate_confidence(features, predicted_type):
    """
    计算分类置信度
    
    基于:
    - 特征与训练类型的匹配度
    - 数据完整性
    - 识别模式清晰度
    """
    base_score = 0.8
    
    # 数据完整性调整
    if features['missing_data_ratio'] > 0.1:
        base_score -= 0.2
    
    # 模式清晰度调整
    if features['interval_count'] > 0:
        # 间歇训练特征明显
        if predicted_type in ['INTERVAL', 'VO2MAX']:
            base_score += 0.15
    
    # 时长合理性调整
    expected_duration = TRAINING_TYPE_DURATIONS.get(predicted_type)
    if expected_duration:
        ratio = features['duration'] / expected_duration
        if 0.8 < ratio < 1.2:
            base_score += 0.1
    
    return min(max(base_score, 0), 1)
```

## 训练类型特征库

| 类型 | 配速变异系数 | 心率区间分布 | 间歇循环 |
|------|-------------|-------------|---------|
| EASY | <0.05 | Z1+Z2 > 90% | 无 |
| LSD | <0.08 | Z2 > 80% | 无 |
| TEMPO | <0.10 | Z3+Z4 > 70% | 无 |
| INTERVAL | >0.30 | Z4+Z5 > 60% | 3-10次 |
| VO2MAX | >0.40 | Z5 > 40% | 4-8次 |
| RECOVERY | <0.03 | Z1 > 80% | 无 |
| LONG | <0.10 | Z2 > 75% | 无 |
| RACE | <0.15 | 分布均匀 | 无 |
