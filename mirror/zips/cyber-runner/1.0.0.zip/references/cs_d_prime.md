# CS-D' 临界配速计算方法

## 理论基础

### 什么是 CS-D' 模型？

**CS-D' (Critical Speed - D Prime)** 是运动生理学中用于评估有氧能力的经典模型，最初由 Morton (1985) 提出。

### 核心概念

1. **Critical Speed (CS)** - 临界配速
   - 可以长时间维持的最大配速
   - 理论上可持续 30-60 分钟
   - 代表有氧系统的最大可持续功率

2. **D' (D Prime)** - 储备距离
   - 以高于 CS 的配速冲刺时消耗的"能量储备"
   - 相当于无氧能力储备
   - 会在高强度运动中消耗，在低强度中恢复

### 数学模型

```
距离 = CS × 时间 + D'
```

转换为时间预测：
```
时间 = (距离 - D') / CS
```

## 计算方法

### 线性回归法

使用多组不同距离的最佳成绩进行线性回归：

```python
import numpy as np
from scipy import stats

def calculate_cs_d_prime(records):
    """
    计算临界配速和D'
    
    参数:
        records: 列表，包含多组 (距离_米, 时间_秒) 元组
                建议至少3组，覆盖不同距离
    
    返回:
        dict: {
            'cs': 临界配速 (m/s),
            'd_prime': 储备距离 (m),
            'r_squared': 决定系数,
            'predictions': 各距离预测成绩
        }
    """
    distances = np.array([r[0] for r in records])
    times = np.array([r[1] for r in records])
    
    # 线性回归: 时间 = (1/CS) × 距离 - D'/CS
    # 转换为: 时间 = a × 距离 + b
    slope, intercept, r_value, p_value, std_err = stats.linregress(
        distances, times
    )
    
    # 反推 CS 和 D'
    cs = 1.0 / slope  # m/s
    d_prime = -intercept / slope  # m
    
    return {
        'cs': cs,
        'd_prime': d_prime,
        'r_squared': r_value ** 2,
        'standard_error': std_err,
        'p_value': p_value
    }
```

### 示例数据

```python
# 小南的近期成绩
records = [
    (5000, 1200),    # 5K: 20:00
    (10000, 2520),   # 10K: 42:00
    (21097.5, 5580), # 半马: 1:33:00
]

result = calculate_cs_d_prime(records)
# result = {
#     'cs': 3.85,      # 临界配速 3.85 m/s
#     'd_prime': 156,  # D' 储备 156 米
#     'r_squared': 0.99
# }
```

### 距离预测

```python
def predict_performance(cs, d_prime, target_distance):
    """
    预测目标距离成绩
    
    公式: 时间 = (距离 - D') / CS
    """
    time_seconds = (target_distance - d_prime) / cs
    
    # 转换为 mm:ss 或 hh:mm:ss 格式
    minutes, seconds = divmod(int(time_seconds), 60)
    if time_seconds > 3600:
        hours, minutes = divmod(minutes, 60)
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"

# 预测成绩
predictions = {
    '5K': predict_performance(3.85, 156, 5000),
    '10K': predict_performance(3.85, 156, 10000),
    'Half Marathon': predict_performance(3.85, 156, 21097.5),
    'Marathon': predict_performance(3.85, 156, 42195),
}
```

## 简化估算法

如果没有多组数据，可使用单次成绩估算：

### 基于最大心率估算

```python
def estimate_cs_from_hr_max(vo2max_pace, hr_max=185):
    """
    基于最大摄氧量配速估算 CS
    
    经验公式: CS ≈ VO2max配速 × 0.85 ~ 0.90
    """
    return vo2max_pace * 0.87

def estimate_d_prime_from_sprint(sprint_distance, sprint_time):
    """
    基于短距离冲刺估算 D'
    
    公式推导: D' = 距离 - CS × 时间
    """
    # 需要先估算 CS
    # 假设 CS 约为 1500m 配速的 0.95
    cs_estimate = 1500 / (sprint_time * 0.95)  # 简化估算
    d_prime = sprint_distance - cs_estimate * sprint_time
    return max(d_prime, 50)  # 最小值保护
```

## 配速区间计算

基于 CS 和 D' 计算训练配速区间：

```python
def calculate_pace_zones(cs, d_prime):
    """
    计算5区配速体系
    
    基于 CS 和 D' 储备设定区间
    """
    zones = {
        'Z1 - Easy': {
            'pace_range': (0.70, 0.82),  # CS 的百分比
            'description': '轻松跑，恢复和有氧基础'
        },
        'Z2 - Marathon': {
            'pace_range': (0.82, 0.92),
            'description': '马拉松配速，节奏控制'
        },
        'Z3 - Threshold': {
            'pace_range': (0.92, 1.00),
            'description': '乳酸阈值，维持 CS'
        },
        'Z4 - VO2Max': {
            'pace_range': (1.00, 1.10),
            'description': 'VO2Max 区间，消耗 D\''
        },
        'Z5 - Anaerobic': {
            'pace_range': (1.10, 1.20),
            'description': '无氧区间，最大 D\' 消耗'
        }
    }
    
    result = {}
    for zone_name, zone_info in zones.items():
        min_pace = cs * zone_info['pace_range'][0]
        max_pace = cs * zone_info['pace_range'][1]
        result[zone_name] = {
            'min_pace': f"{1000/max_pace:.2f} min/km",
            'max_pace': f"{1000/min_pace:.2f} min/km",
            'm_s': (min_pace, max_pace),
            'description': zone_info['description']
        }
    
    return result
```

## 精度验证

### R² 值评估

| R² 范围 | 模型质量 | 建议 |
|---------|---------|------|
| > 0.99 | 优秀 | 预测可靠 |
| 0.95-0.99 | 良好 | 预测可用 |
| 0.90-0.95 | 一般 | 参考使用 |
| < 0.90 | 较差 | 增加数据点 |

### 数据质量要求

1. **距离覆盖**: 建议包含 5K 以上和 10K 以下的至少各一个成绩
2. **成绩质量**: 使用真实最好成绩或近年最佳
3. **数据量**: 至少 3 组数据，5+ 组更佳
4. **一致性**: 同等条件下的成绩（如相似训练周期）

## 局限性

1. 模型假设配速恒定，实际比赛会有波动
2. 不考虑环境影响（天气、赛道）
3. 不考虑疲劳累积（连续比赛）
4. 不适用于间歇型运动模式

## 参考资料

- Morton, R.H. (1985). A new modelling approach to the prediction of critical speed. *Journal of Sports Sciences*.
- Ferguson, C. et al. (2000). Critical power test for ramp pattern exercise. *European Journal of Applied Physiology*.
