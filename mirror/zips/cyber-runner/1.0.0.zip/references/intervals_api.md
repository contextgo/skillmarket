# Intervals.icu API 文档

## 概述

Intervals.icu 是一个专业的跑步训练数据分析平台，提供开放的 API 接口支持数据同步。

## 认证方式

### API Key 获取
1. 登录 [Intervals.icu](https://intervals.icu)
2. 进入 Settings → API
3. 生成新的 API Key

### 认证头
```http
Authorization: Bearer YOUR_API_KEY
```

## 核心接口

### 1. 获取活动列表

**端点**: `GET /api/v1/athlete/{athlete_id}/activities`

**参数**:
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| oldest | ISO8601 | 否 | 开始日期 |
| newest | ISO8601 | 否 | 结束日期 |
| limit | int | 否 | 返回数量(默认100) |

**响应示例**:
```json
{
  "activities": [
    {
      "id": "abc123",
      "type": "Run",
      "date": "2024-01-15T08:30:00Z",
      "title": "Morning Run",
      "distance": 5000,
      "moving_time": 1500,
      "average_speed": 3.33,
      "average_heartrate": 145,
      "max_heartrate": 168,
      "total_elevation_gain": 50
    }
  ]
}
```

### 2. 获取活动详情

**端点**: `GET /api/v1/activity/{activity_id}`

**响应包含**:
- 详细配速数据
- 分段心率数据
- GPS轨迹
- 训练负载(CTL, ATL, TSB)

### 3. 上传训练计划

**端点**: `POST /api/v1/athlete/{athlete_id}/planned`

**请求体**:
```json
{
  "name": "Interval Training",
  "description": "6x800m at 5K pace",
  "type": "workout",
  "date": "2024-01-20",
  "intervals": [
    {
      "name": "Warm Up",
      "type": "active",
      "duration": 300
    },
    {
      "name": "Interval",
      "type": "active",
      "duration": 180,
      "pace": 4.0
    }
  ]
}
```

### 4. 获取分析数据

**端点**: `GET /api/v1/athlete/{athlete_id}/analysis`

**参数**:
- `date_range`: 分析时间段
- `metrics`: 需要计算的指标列表

## Python SDK 使用

```python
import requests

class IntervalsClient:
    BASE_URL = "https://intervals.icu/api/v1"
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}"
        })
    
    def get_activities(self, athlete_id: str, **kwargs):
        """获取活动列表"""
        params = {k: v for k, v in kwargs.items() if v}
        response = self.session.get(
            f"{self.BASE_URL}/athlete/{athlete_id}/activities",
            params=params
        )
        response.raise_for_status()
        return response.json()
    
    def get_activity_detail(self, activity_id: str):
        """获取活动详情"""
        response = self.session.get(
            f"{self.BASE_URL}/activity/{activity_id}"
        )
        response.raise_for_status()
        return response.json()
    
    def upload_workout(self, athlete_id: str, workout: dict):
        """上传训练计划"""
        response = self.session.post(
            f"{self.BASE_URL}/athlete/{athlete_id}/planned",
            json=workout
        )
        response.raise_for_status()
        return response.json()
```

## 速率限制

- **请求频率**: 每分钟最多 60 次
- **每日配额**: 10,000 次
- **批量操作**: 建议使用分页，每页不超过 100 条

## 错误处理

| 状态码 | 说明 | 处理建议 |
|--------|------|----------|
| 401 | 认证失败 | 检查API Key |
| 403 | 权限不足 | 确认账户权限 |
| 429 | 请求超限 | 降低请求频率 |
| 500 | 服务器错误 | 重试或联系支持 |

## 数据字段说明

### 活动类型 (type)
- `Run` - 跑步
- `Race` - 比赛
- `Workout` - 训练
- `Long` - 长跑
- `Recovery` - 恢复跑

### 配速单位
- Intervals.icu 使用 **m/s** (米/秒)
- 转换: `km/h = m/s × 3.6`
- 转换: `min/km = 1000 / m/s / 60`

### 心率区间
- 百分比基于个人最大心率 (HRmax)
- 可通过 `220 - 年龄` 估算
