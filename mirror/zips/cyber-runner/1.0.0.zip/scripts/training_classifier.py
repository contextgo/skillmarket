"""
训练类型分类器

基于配速、心率、时长等数据特征，自动识别训练类型
"""

import numpy as np
from typing import Dict, List, Tuple, Optional


class TrainingClassifier:
    """训练类型分类器"""
    
    # 训练类型定义
    TRAINING_TYPES = {
        'EASY': {
            'pace_cv_range': (0, 0.05),
            'hr_zone_range': (60, 70),
            'duration_range': (20, 90)
        },
        'LSD': {
            'pace_cv_range': (0, 0.08),
            'hr_zone_range': (65, 75),
            'duration_range': (90, 300)
        },
        'TEMPO': {
            'pace_cv_range': (0, 0.10),
            'hr_zone_range': (80, 88),
            'duration_range': (20, 60)
        },
        'INTERVAL': {
            'pace_cv_range': (0.20, 0.50),
            'hr_zone_range': (88, 95),
            'duration_range': (30, 120),
            'interval_pattern': True
        },
        'VO2MAX': {
            'pace_cv_range': (0.30, 0.60),
            'hr_zone_range': (90, 98),
            'duration_range': (15, 45),
            'interval_pattern': True
        },
        'RECOVERY': {
            'pace_cv_range': (0, 0.03),
            'hr_zone_range': (55, 65),
            'duration_range': (10, 30)
        },
        'LONG': {
            'pace_cv_range': (0, 0.10),
            'hr_zone_range': (70, 80),
            'duration_range': (120, 360)
        },
        'RACE': {
            'pace_cv_range': (0, 0.15),
            'hr_zone_range': (85, 100),
            'duration_range': (15, 300),
            'effort_level': 'maximal'
        }
    }
    
    def __init__(self):
        self.feature_cache = {}
    
    def analyze(self, pace_data: List[float], heart_rate_data: List[float], 
                duration: int, hr_max: int = 185) -> Dict:
        """
        分析训练数据并识别训练类型
        
        Args:
            pace_data: 配速序列 (m/s)
            heart_rate_data: 心率序列 (bpm)
            duration: 总时长 (秒)
            hr_max: 最大心率 (bpm)
        
        Returns:
            dict: 分析结果，包含训练类型和特征
        """
        features = self._extract_features(pace_data, heart_rate_data, duration, hr_max)
        training_type = self._classify(features)
        confidence = self._calculate_confidence(features, training_type)
        
        return {
            'type': training_type,
            'confidence': confidence,
            'features': features,
            'pace_zones': self._calculate_pace_zones(features),
            'hr_zones': self._calculate_hr_zones(features, hr_max)
        }
    
    def _extract_features(self, pace_data: List[float], 
                         heart_rate_data: List[float],
                         duration: int, hr_max: int) -> Dict:
        """提取训练特征"""
        pace_array = np.array(pace_data)
        hr_array = np.array(heart_rate_data)
        
        # 过滤静止/休息段落
        pace_filtered, hr_filtered = self._filter_rest_periods(pace_array, hr_array)
        
        # 配速特征
        avg_pace = np.mean(pace_filtered) if len(pace_filtered) > 0 else 0
        pace_std = np.std(pace_filtered) if len(pace_filtered) > 0 else 0
        pace_cv = pace_std / avg_pace if avg_pace > 0 else 0
        
        # 心率特征
        avg_hr = np.mean(hr_filtered) if len(hr_filtered) > 0 else 0
        hr_percentage = (avg_hr / hr_max) * 100 if hr_max > 0 else 0
        
        # 间歇检测
        intervals = self._detect_intervals(pace_filtered)
        
        return {
            'avg_pace': avg_pace,
            'pace_cv': pace_cv,
            'pace_stability': 1 - min(pace_cv, 1),
            'avg_hr': avg_hr,
            'hr_percentage': hr_percentage,
            'duration': duration,
            'interval_count': len(intervals),
            'intervals': intervals,
            'filtered_pace_count': len(pace_filtered),
            'original_pace_count': len(pace_array),
            'rest_filter_ratio': len(pace_filtered) / len(pace_array) if len(pace_array) > 0 else 1
        }
    
    def _filter_rest_periods(self, pace_data: np.ndarray, 
                            hr_data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """过滤静止/休息段落"""
        if len(pace_data) == 0:
            return pace_data, hr_data
        
        pace_filtered = []
        hr_filtered = []
        
        rest_threshold = 0.5  # m/s (接近静止)
        hr_rest_threshold = 100  # bpm
        
        for i in range(len(pace_data)):
            pace = pace_data[i]
            hr = hr_data[i] if i < len(hr_data) else 0
            
            # 静止判定
            if pace < rest_threshold and hr < hr_rest_threshold:
                continue
            
            # 长休息判定
            if pace < 1.0:
                duration = 1
                while i + duration < len(pace_data) and pace_data[i + duration] < 1.0:
                    duration += 1
                if duration > 30:  # 超过30秒的低强度
                    continue
            
            pace_filtered.append(pace)
            hr_filtered.append(hr)
        
        return np.array(pace_filtered), np.array(hr_filtered)
    
    def _detect_intervals(self, pace_data: np.ndarray, 
                         threshold: float = 0.15) -> List[Dict]:
        """检测间歇训练模式"""
        if len(pace_data) < 10:
            return []
        
        # 计算配速阈值
        median_pace = np.median(pace_data)
        high_threshold = median_pace * (1 + threshold)
        low_threshold = median_pace * (1 - threshold)
        
        intervals = []
        in_work = False
        work_start = 0
        
        for i, pace in enumerate(pace_data):
            if not in_work and pace > high_threshold:
                in_work = True
                work_start = i
            elif in_work and pace < low_threshold:
                in_work = False
                interval_duration = i - work_start
                if interval_duration >= 10:  # 至少10秒
                    intervals.append({
                        'start': work_start,
                        'end': i,
                        'duration': interval_duration,
                        'avg_pace': np.mean(pace_data[work_start:i]),
                        'pace_ratio': np.mean(pace_data[work_start:i]) / median_pace
                    })
        
        return intervals
    
    def _classify(self, features: Dict) -> str:
        """基于特征分类训练类型"""
        
        # 间歇训练优先检测
        if features['interval_count'] >= 3:
            avg_intensity = np.mean([i['pace_ratio'] for i in features['intervals']])
            if avg_intensity > 1.15:
                return 'VO2MAX'
            return 'INTERVAL'
        
        # 基于心率和配速变异系数分类
        hr_pct = features['hr_percentage']
        pace_cv = features['pace_cv']
        duration = features['duration'] / 60  # 转换为分钟
        
        # 恢复跑判定
        if duration < 30 and hr_pct < 65:
            return 'RECOVERY'
        
        # 轻松跑判定
        if hr_pct < 72 and pace_cv < 0.05:
            if duration > 90:
                return 'LSD'
            return 'EASY'
        
        # 长跑判定
        if duration > 120 and hr_pct < 82:
            return 'LONG'
        
        # 节奏跑判定
        if 78 <= hr_pct <= 88 and pace_cv < 0.12:
            return 'TEMPO'
        
        # 比赛判定
        if hr_pct > 88:
            return 'RACE'
        
        # 默认返回EASY
        return 'EASY'
    
    def _calculate_confidence(self, features: Dict, training_type: str) -> float:
        """计算分类置信度"""
        base_score = 0.7
        
        # 间歇特征明显度
        if features['interval_count'] > 0:
            if training_type in ['INTERVAL', 'VO2MAX']:
                base_score += 0.15
        
        # 配速稳定性
        if training_type in ['EASY', 'LSD', 'TEMPO']:
            if features['pace_cv'] < 0.05:
                base_score += 0.1
        
        # 数据完整性
        if features['rest_filter_ratio'] > 0.9:
            base_score += 0.05
        
        return min(max(base_score, 0), 1)
    
    def _calculate_pace_zones(self, features: Dict) -> Dict:
        """计算配速区间分布"""
        avg_pace = features['avg_pace']
        return {
            'average': avg_pace,
            'min_km': 1000 / avg_pace if avg_pace > 0 else 0,
            'km_h': avg_pace * 3.6 if avg_pace > 0 else 0
        }
    
    def _calculate_hr_zones(self, features: Dict, hr_max: int) -> Dict:
        """计算心率区间"""
        avg_hr = features['avg_hr']
        hr_pct = features['hr_percentage']
        
        zone = 1
        if hr_pct >= 88:
            zone = 4 if hr_pct < 95 else 5
        elif hr_pct >= 80:
            zone = 3
        elif hr_pct >= 70:
            zone = 2
        
        return {
            'average': avg_hr,
            'percentage': hr_pct,
            'zone': zone,
            'max_hr': hr_max
        }


# 使用示例
if __name__ == '__main__':
    classifier = TrainingClassifier()
    
    # 模拟间歇训练数据
    pace_data = [3.5] * 300  # 热身
    for _ in range(6):
        pace_data.extend([4.5] * 180)  # 间歇
        pace_data.extend([3.0] * 90)   # 恢复
    
    hr_data = [130] * 300
    for _ in range(6):
        hr_data.extend([170] * 180)
        hr_data.extend([145] * 90)
    
    result = classifier.analyze(
        pace_data=pace_data,
        heart_rate_data=hr_data,
        duration=1800,
        hr_max=190
    )
    
    print(f"训练类型: {result['type']}")
    print(f"置信度: {result['confidence']:.1%}")
    print(f"间歇次数: {result['features']['interval_count']}")
