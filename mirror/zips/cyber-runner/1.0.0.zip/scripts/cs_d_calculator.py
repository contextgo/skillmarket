"""
CS-D' 临界配速计算器

基于运动生理学模型评估跑者有氧能力
"""

import numpy as np
from scipy import stats
from typing import List, Tuple, Dict, Optional


class CSDCalculator:
    """CS-D' 临界配速计算器"""
    
    def __init__(self):
        self.last_result = None
        self.records_history = []
    
    def calculate(self, records: List[Tuple[float, float]], 
                  validate: bool = True) -> Dict:
        """
        计算临界配速和D'储备
        
        Args:
            records: 列表，每项为 (距离_米, 时间_秒) 元组
                   建议至少3组数据，覆盖不同距离
            validate: 是否验证数据质量
        
        Returns:
            dict: 计算结果
        """
        if len(records) < 2:
            raise ValueError("至少需要2组数据进行计算")
        
        # 转换为numpy数组
        distances = np.array([r[0] for r in records])
        times = np.array([r[1] for r in records])
        
        # 线性回归: 时间 = (1/CS) × 距离 - D'/CS
        # 转换为: 时间 = slope × 距离 + intercept
        slope, intercept, r_value, p_value, std_err = stats.linregress(
            distances, times
        )
        
        # 计算CS和D'
        cs = 1.0 / slope if slope > 0 else 0  # m/s
        d_prime = -intercept / slope if slope != 0 else 0  # m
        
        # 质量评估
        r_squared = r_value ** 2
        quality = self._assess_quality(r_squared, len(records))
        
        # 预测各距离成绩
        predictions = self._predict_performances(cs, d_prime)
        
        # 计算配速区间
        pace_zones = self._calculate_zones(cs)
        
        result = {
            'cs': cs,
            'd_prime': d_prime,
            'r_squared': r_squared,
            'p_value': p_value,
            'standard_error': std_err,
            'quality': quality,
            'predictions': predictions,
            'pace_zones': pace_zones,
            'records_used': records
        }
        
        self.last_result = result
        self.records_history.append(result)
        
        return result
    
    def estimate_from_single(self, distance: float, time: float,
                            estimate_type: str = '5k_equivalent') -> Dict:
        """
        从单次成绩估算CS和D'
        
        Args:
            distance: 距离 (米)
            time: 时间 (秒)
            estimate_type: 估算方法
                - '5k_equivalent': 基于5K当量
                - 'hr_max': 基于最大心率
                - 'age': 基于年龄估算VO2max
        
        Returns:
            dict: 估算结果
        """
        # 经验公式估算CS
        # CS 通常约为 5K 配速的 0.90-0.95
        
        pace_5k = time / distance * 1000  # min/km
        
        if estimate_type == '5k_equivalent':
            # CS 约为 5K 配速的 92%
            cs = (1000 / pace_5k) / 60 * 0.92  # m/s
            
        elif estimate_type == 'age':
            # 基于年龄估算最大心率，再估算VO2max配速
            # 简化估算，假设 CS = VO2max配速 × 0.87
            vo2max_pace = (1000 / pace_5k) / 60  # m/s
            cs = vo2max_pace * 0.87
        else:
            cs = (1000 / pace_5k) / 60 * 0.92
        
        # 估算 D'
        # 经验公式: D' 约为 150-200m
        # 基于比赛距离估算
        if distance >= 42195:
            d_prime = 180  # 全马
        elif distance >= 21097:
            d_prime = 170  # 半马
        elif distance >= 10000:
            d_prime = 160  # 10K
        else:
            d_prime = 150  # 5K及以下
        
        result = {
            'cs': cs,
            'd_prime': d_prime,
            'estimated': True,
            'estimate_type': estimate_type,
            'confidence': 'low',
            'predictions': self._predict_performances(cs, d_prime),
            'pace_zones': self._calculate_zones(cs)
        }
        
        return result
    
    def update_d_prime(self, sprint_distance: float, sprint_time: float) -> Optional[Dict]:
        """
        用冲刺成绩更新D'估算
        
        Args:
            sprint_distance: 冲刺距离 (米)，如 400m
            sprint_time: 冲刺时间 (秒)
        
        Returns:
            dict: 更新后的结果，或None
        """
        if not self.last_result:
            return None
        
        cs = self.last_result['cs']
        
        # D' = 距离 - CS × 时间
        d_prime_new = sprint_distance - cs * sprint_time
        
        # 合理性检查
        if d_prime_new < 50 or d_prime_new > 400:
            d_prime_new = max(50, min(400, d_prime_new))
        
        # 更新结果
        self.last_result['d_prime'] = d_prime_new
        self.last_result['predictions'] = self._predict_performances(cs, d_prime_new)
        self.last_result['pace_zones'] = self._calculate_zones(cs)
        
        return self.last_result
    
    def predict_race_pace(self, cs: float, d_prime: float,
                          target_distance: float) -> Dict:
        """
        预测目标距离的配速策略
        
        Args:
            cs: 临界配速 (m/s)
            d_prime: D'储备 (m)
            target_distance: 目标距离 (米)
        
        Returns:
            dict: 配速策略建议
        """
        # 理论完成时间
        theoretical_time = (target_distance - d_prime) / cs
        
        # 各段配速建议
        # 前半程: 使用略低于CS的配速
        # 后半程: 根据D'消耗情况调整
        
        strategies = {
            'even_pacing': {
                'pace': cs,
                'time': theoretical_time,
                'description': '匀速策略，全程维持CS配速'
            },
            'negative_split': {
                'first_half': cs * 0.98,
                'second_half': cs * 1.02,
                'time': theoretical_time * 0.99,
                'description': '负分段，后半程略快'
            },
            'positive_split': {
                'first_half': cs * 1.02,
                'second_half': cs * 0.98,
                'time': theoretical_time * 1.01,
                'description': '正分段，前半程略快'
            }
        }
        
        return {
            'target_distance': target_distance,
            'theoretical_time': theoretical_time,
            'strategies': strategies,
            'recommended': 'negative_split' if target_distance >= 21097 else 'even_pacing'
        }
    
    def _assess_quality(self, r_squared: float, n_records: int) -> str:
        """评估模型质量"""
        if r_squared > 0.99 and n_records >= 3:
            return 'excellent'
        elif r_squared > 0.95 and n_records >= 3:
            return 'good'
        elif r_squared > 0.90:
            return 'fair'
        else:
            return 'poor'
    
    def _predict_performances(self, cs: float, d_prime: float) -> Dict:
        """预测各距离成绩"""
        distances = {
            '1K': 1000,
            '3K': 3000,
            '5K': 5000,
            '10K': 10000,
            'Half Marathon': 21097.5,
            'Marathon': 42195
        }
        
        predictions = {}
        for name, distance in distances.items():
            time_seconds = (distance - d_prime) / cs
            
            # 转换为可读格式
            minutes = int(time_seconds // 60)
            seconds = int(time_seconds % 60)
            pace_min_km = 1000 / cs / 60
            
            predictions[name] = {
                'time_seconds': time_seconds,
                'time_formatted': f"{minutes}:{seconds:02d}",
                'pace': f"{int(pace_min_km)}:{int((pace_min_km % 1) * 60):02d}",
                'speed_kmh': round(cs * 3.6, 1)
            }
        
        return predictions
    
    def _calculate_zones(self, cs: float, hr_max: int = 185) -> Dict:
        """计算配速区间"""
        zones = [
            ('Z1', 'Easy', 0.70, 0.82, 0.60, 0.70),
            ('Z2', 'Marathon', 0.82, 0.92, 0.70, 0.80),
            ('Z3', 'Threshold', 0.92, 1.00, 0.80, 0.88),
            ('Z4', 'VO2Max', 1.00, 1.10, 0.88, 0.95),
            ('Z5', 'Anaerobic', 1.10, 1.20, 0.95, 1.00)
        ]
        
        result = {}
        for zone_id, name, cs_min, cs_max, hr_min_pct, hr_max_pct in zones:
            pace_min = cs * cs_min
            pace_max = cs * cs_max
            
            pace_min_km = 1000 / pace_max
            pace_max_km = 1000 / pace_min
            
            result[f"{zone_id}_{name}"] = {
                'pace_range': f"{int(pace_min_km)}:{int((pace_min_km % 1) * 60):02d} - {int(pace_max_km)}:{int((pace_max_km % 1) * 60):02d}",
                'pace_m_s': f"{pace_min:.2f} - {pace_max:.2f}",
                'hr_range': f"{int(hr_max * hr_min_pct)} - {int(hr_max * hr_max_pct)}"
            }
        
        return result
    
    def format_report(self, result: Dict) -> str:
        """生成格式化报告"""
        cs_kmh = result['cs'] * 3.6
        cs_pace = 1000 / result['cs'] / 60
        
        report = f"""
╔══════════════════════════════════════════════════════════════╗
║                    CS-D' 能力评估报告                         ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  📊 临界配速 (Critical Speed)                                ║
║     {result['cs']:.2f} m/s  ({cs_kmh:.1f} km/h)                       ║
║     配速: {int(cs_pace)}:{int((cs_pace % 1) * 60):02d} /km                                  ║
║                                                              ║
║  💪 D' 储备 (Anaerobic Reserve)                              ║
║     {result['d_prime']:.0f} m                                          ║
║                                                              ║
║  📈 模型质量: {result['quality'].upper():8}                              ║
║     R² = {result['r_squared']:.4f}                                   ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  🏃 预测成绩                                                 ║
╠══════════════════════════════════════════════════════════════╣"""
        
        for distance, pred in result['predictions'].items():
            report += f"\n║     {distance:15}  {pred['time_formatted']:>10}   配速 {pred['pace']} /km  ║"
        
        report += """
╠══════════════════════════════════════════════════════════════╣
║  🎯 训练配速区间                                             ║
╠══════════════════════════════════════════════════════════════╣"""
        
        for zone, info in result['pace_zones'].items():
            report += f"\n║     {zone:15}  {info['pace_range']:>20} /km  ║"
        
        report += """
╚══════════════════════════════════════════════════════════════╝
"""
        return report


# 使用示例
if __name__ == '__main__':
    calculator = CSDCalculator()
    
    # 小南的近期成绩
    records = [
        (5000, 1200),      # 5K: 20:00
        (10000, 2520),     # 10K: 42:00
        (21097.5, 5580),   # 半马: 1:33:00
    ]
    
    result = calculator.calculate(records)
    print(calculator.format_report(result))
    
    # 预测5K @ 17:00 目标
    cs_target = 1000 / 17 * 60  # 约 3.53 m/s
    d_prime_target = 156  # 保持当前D'
    
    predictions = calculator._predict_performances(cs_target, d_prime_target)
    print(f"\n🎯 达成 5K:17:00 后的预测:")
    for dist, pred in predictions.items():
        print(f"   {dist}: {pred['time_formatted']}")
