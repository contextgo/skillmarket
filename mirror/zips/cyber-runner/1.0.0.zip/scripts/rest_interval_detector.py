"""
休息段检测与过滤算法

自动识别并过滤GPS数据中的静止、暂停等非运动段落
"""

import numpy as np
from typing import List, Tuple, Dict


class RestIntervalDetector:
    """休息段检测器"""
    
    def __init__(self, config: Dict = None):
        """
        初始化检测器
        
        Args:
            config: 配置参数
        """
        self.config = config or self._default_config()
    
    def _default_config(self) -> Dict:
        """默认配置"""
        return {
            # 静止判定阈值
            'still_pace_threshold': 0.5,      # m/s
            'still_hr_threshold': 100,         # bpm
            
            # 长休息判定
            'long_rest_duration': 30,          # 秒
            'long_rest_pace': 1.0,             # m/s
            
            # 短暂停顿判定
            'pause_duration': 5,               # 秒
            'pause_pace_drop': 0.7,            # 配速下降比例
            
            # 平滑窗口
            'smooth_window': 5,                # 数据点
            
            # 最小有效运动距离
            'min_motion_distance': 10,          # 米
        }
    
    def detect(self, pace_data: List[float], 
               hr_data: List[float],
               distance_data: List[float] = None) -> Dict:
        """
        检测休息段落
        
        Args:
            pace_data: 配速序列 (m/s)
            hr_data: 心率序列 (bpm)
            distance_data: 距离序列 (m)
        
        Returns:
            dict: 检测结果
        """
        pace_array = np.array(pace_data)
        hr_array = np.array(hr_data)
        
        # 平滑处理
        pace_smooth = self._smooth(pace_array, self.config['smooth_window'])
        
        # 检测各类休息段落
        still_segments = self._detect_still_segments(pace_smooth, hr_array)
        long_rest_segments = self._detect_long_rest(pace_smooth)
        pause_segments = self._detect_pauses(pace_array)
        
        # 合并休息段落
        all_rest_segments = self._merge_segments(
            still_segments, long_rest_segments, pause_segments
        )
        
        # 过滤并返回有效数据
        valid_indices = self._get_valid_indices(
            len(pace_data), all_rest_segments
        )
        
        return {
            'still_segments': still_segments,
            'long_rest_segments': long_rest_segments,
            'pause_segments': pause_segments,
            'all_rest_segments': all_rest_segments,
            'valid_indices': valid_indices,
            'rest_ratio': 1 - len(valid_indices) / len(pace_data) if len(pace_data) > 0 else 0
        }
    
    def filter(self, pace_data: List[float],
               hr_data: List[float],
               distance_data: List[float] = None) -> Tuple[List[float], List[float], List[float]]:
        """
        过滤休息段落
        
        Returns:
            tuple: (过滤后的配速, 心率, 距离)
        """
        detection = self.detect(pace_data, hr_data, distance_data)
        valid_indices = detection['valid_indices']
        
        pace_filtered = [pace_data[i] for i in valid_indices]
        hr_filtered = [hr_data[i] for i in valid_indices]
        
        if distance_data:
            distance_filtered = [distance_data[i] for i in valid_indices]
            return pace_filtered, hr_filtered, distance_filtered
        
        return pace_filtered, hr_filtered, None
    
    def _smooth(self, data: np.ndarray, window: int) -> np.ndarray:
        """移动平均平滑"""
        if len(data) < window:
            return data
        
        smoothed = np.convolve(data, np.ones(window)/window, mode='same')
        return smoothed
    
    def _detect_still_segments(self, pace_data: np.ndarray,
                               hr_data: np.ndarray) -> List[Dict]:
        """检测静止段落"""
        segments = []
        in_still = False
        start_idx = 0
        
        for i in range(len(pace_data)):
            is_still = (pace_data[i] < self.config['still_pace_threshold'] and 
                       (i >= len(hr_data) or hr_data[i] < self.config['still_hr_threshold']))
            
            if is_still and not in_still:
                in_still = True
                start_idx = i
            elif not is_still and in_still:
                in_still = False
                segments.append({
                    'type': 'still',
                    'start': start_idx,
                    'end': i,
                    'duration': i - start_idx
                })
        
        # 检查末尾
        if in_still:
            segments.append({
                'type': 'still',
                'start': start_idx,
                'end': len(pace_data),
                'duration': len(pace_data) - start_idx
            })
        
        return segments
    
    def _detect_long_rest(self, pace_data: np.ndarray) -> List[Dict]:
        """检测长休息段落"""
        segments = []
        i = 0
        
        while i < len(pace_data):
            if pace_data[i] < self.config['long_rest_pace']:
                # 寻找休息段结束
                start = i
                duration = 0
                while i < len(pace_data) and pace_data[i] < self.config['long_rest_pace']:
                    i += 1
                    duration += 1
                
                if duration >= self.config['long_rest_duration']:
                    segments.append({
                        'type': 'long_rest',
                        'start': start,
                        'end': i,
                        'duration': duration
                    })
            i += 1
        
        return segments
    
    def _detect_pauses(self, pace_data: np.ndarray) -> List[Dict]:
        """检测短暂停顿"""
        segments = []
        i = 0
        
        while i < len(pace_data) - 1:
            # 检测配速骤降
            if i > 0 and i < len(pace_data) - 1:
                pace_prev = pace_data[i - 1]
                pace_curr = pace_data[i]
                pace_next = pace_data[i + 1] if i + 1 < len(pace_data) else 0
                
                if (pace_prev > pace_curr * 1.5 and 
                    pace_next > pace_curr * 1.5 and
                    pace_curr < self.config['pause_pace_drop'] * pace_prev):
                    
                    # 寻找停顿持续范围
                    start = i
                    while i < len(pace_data) and pace_data[i] < pace_prev * self.config['pause_pace_drop']:
                        i += 1
                    
                    duration = i - start
                    if duration >= self.config['pause_duration']:
                        segments.append({
                            'type': 'pause',
                            'start': start,
                            'end': i,
                            'duration': duration
                        })
                    continue
            i += 1
        
        return segments
    
    def _merge_segments(self, *segment_lists: List[List[Dict]]) -> List[Dict]:
        """合并多类休息段落"""
        all_segments = []
        for segments in segment_lists:
            all_segments.extend(segments)
        
        if not all_segments:
            return []
        
        # 按起始位置排序
        all_segments.sort(key=lambda x: x['start'])
        
        # 合并重叠段落
        merged = [all_segments[0]]
        for seg in all_segments[1:]:
            last = merged[-1]
            if seg['start'] <= last['end']:
                # 重叠，合并
                last['end'] = max(last['end'], seg['end'])
                last['duration'] = last['end'] - last['start']
            else:
                merged.append(seg)
        
        return merged
    
    def _get_valid_indices(self, data_length: int, 
                           rest_segments: List[Dict]) -> List[int]:
        """获取有效数据索引"""
        rest_ranges = [(s['start'], s['end']) for s in rest_segments]
        
        valid_indices = []
        for i in range(data_length):
            is_rest = any(start <= i < end for start, end in rest_ranges)
            if not is_rest:
                valid_indices.append(i)
        
        return valid_indices
    
    def summarize(self, detection_result: Dict) -> str:
        """生成检测摘要"""
        total_rest = sum(s['duration'] for s in detection_result['all_rest_segments'])
        
        summary = f"""休息段检测摘要:
- 总休息段数: {len(detection_result['all_rest_segments'])}
- 总休息时长: {total_rest} 秒 ({total_rest/60:.1f} 分钟)
- 休息比例: {detection_result['rest_ratio']:.1%}

详细分类:
- 静止段: {len(detection_result['still_segments'])} 段
- 长休息: {len(detection_result['long_rest_segments'])} 段
- 短暂停顿: {len(detection_result['pause_segments'])} 段
"""
        return summary


# 使用示例
if __name__ == '__main__':
    detector = RestIntervalDetector()
    
    # 模拟数据
    pace_data = [3.5] * 100
    pace_data.extend([0.2] * 50)   # 静止等红绿灯
    pace_data.extend([3.5] * 100)
    pace_data.extend([0.3] * 30)   # 长休息
    pace_data.extend([3.6] * 150)
    
    hr_data = [140] * 100
    hr_data.extend([95] * 50)     # 静止时心率下降
    hr_data.extend([142] * 100)
    hr_data.extend([100] * 30)
    hr_data.extend([145] * 150)
    
    result = detector.detect(pace_data, hr_data)
    print(detector.summarize(result))
    
    # 过滤数据
    pace_f, hr_f, _ = detector.filter(pace_data, hr_data)
    print(f"\n过滤后数据点数: {len(pace_f)} (原始: {len(pace_data)})")
