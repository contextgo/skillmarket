---
name: index-analysis
description: '对A股宽基或行业指数进行分析，涵盖实时行情、历史走势、区间表现、技术面及估值面，支持多指数对比。当用户询问指数涨跌、估值高低或技术形态时触发。Use when: "沪深300今年涨了多少", "创业板估值高吗", "对比沪深300和中证1000走势". Calls tools: idxRealTimeQuote, idxHistoryQuote, idxRangeQuote, idxTechAnalysis, idxValAnalysis.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 指数分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

针对宽基指数（沪深300、中证500、创业板指等）或行业指数，提供：
- **实时行情**：最新点位、涨跌幅、成交额
- **历史行情**：指定日期范围内的历史走势与资金变化
- **区间行情**：特定区间的涨跌汇总与分析
- **技术面分析**：趋势形态、支撑阻力位、技术信号
- **估值面分析**：PE/PB 历史百分位、估值高低判断

支持在一次调用中分析**多个指数**并进行横向对比。

## 触发场景

- "沪深300今年涨了多少？"
- "创业板指现在估值高吗？"
- "帮我对比一下沪深300和中证1000的走势"
- "中证500技术面怎么样？"

## 执行步骤

### 场景 A：实时行情

```json
调用工具: idxRealTimeQuote
参数: { "query": "沪深300、中证500" }
```

### 场景 B：历史走势

```json
调用工具: idxHistoryQuote
参数: {
  "query": "<指数名称，可含多个>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}
```

### 场景 C：区间行情汇总

```json
调用工具: idxRangeQuote
参数: {
  "query": "<指数名称，可含多个>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}
```

### 场景 D：技术 + 估值综合分析（并行调用）

```json
调用工具: idxTechAnalysis
参数: { "query": "<指数名称>" }

调用工具: idxValAnalysis
参数: { "query": "<指数名称>" }
```

### 场景 E：完整指数分析报告

并行调用所有五个工具，整合输出：实时行情 → 区间表现 → 技术面 → 估值面 → 综合研判

## 常用指数名称参考

| 指数名称 | 代码 | 说明 |
|---|---|---|
| 沪深300 | 000300 | 沪深两市龙头蓝筹 |
| 中证500 | 000905 | 中盘成长 |
| 中证1000 | 000852 | 小盘股 |
| 创业板指 | 399006 | 创业板核心 |
| 科创50 | 000688 | 科创板核心 |
| 上证指数 | 000001 | 沪市综合 |

## 注意事项

- `query` 参数为自然语言，可直接写"沪深300"、"创业板指"等通用名称。
- 估值百分位 < 20% 通常被认为处于历史低估区域，> 80% 则为高估区域。
