# -*- coding: utf-8 -*-
"""
未来7天逐3小时天气预报旅游解读
用法: python3 travel_weather.py --city 北京
      python3 travel_weather.py --city_id 101010100
      python3 travel_weather.py --city 北京 --date 2026-04-20
      python3 travel_weather.py --city 北京 --date 2026-04-20 --hour 14
"""

import sys
import os
import json
import argparse
import urllib.request
import urllib.error
import ssl
from datetime import datetime

# 导入城市数据
sys.path.insert(0, os.path.dirname(__file__))
from cities import CITY_DB

# 忽略自签名证书
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# 合法的3小时时间点
VALID_HOURS = [2, 5, 8, 11, 14, 17, 20, 23]


# ──────────────────────────────────────────────
# 城市模糊匹配
# ──────────────────────────────────────────────
def find_city(query):
    """模糊匹配城市，返回 (city_name, city_id) 或 None"""
    query = query.strip()
    # 1. 精确匹配
    if query in CITY_DB:
        return query, CITY_DB[query]
    # 2. 正向模糊：用户输入包含在城市名中（如"杭"→"杭州"）
    candidates = [(name, cid) for name, cid in CITY_DB.items() if query in name]
    if candidates:
        candidates.sort(key=lambda x: len(x[0]))
        return candidates[0]
    # 3. 反向模糊：城市名包含在用户输入中
    candidates = [(name, cid) for name, cid in CITY_DB.items() if name in query]
    if candidates:
        candidates.sort(key=lambda x: len(x[0]), reverse=True)
        return candidates[0]
    return None


def find_city_by_id(city_id):
    """通过ID反向查找城市名称"""
    city_id = city_id.strip()
    for name, cid in CITY_DB.items():
        if cid == city_id:
            return name
    return None


# ──────────────────────────────────────────────
# 数据获取
# ──────────────────────────────────────────────
BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/kg3hour"

def fetch_travel_data(city_id):
    """获取旅游解读数据"""
    url = "{}/{}tour.json".format(BASE_URL, city_id)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=15, context=_SSL_CTX) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        raise RuntimeError("数据获取失败 (HTTP {})：城市ID {} 暂无旅游解读数据".format(e.code, city_id))
    except Exception as e:
        raise RuntimeError("网络请求失败：{}".format(e))


# ──────────────────────────────────────────────
# 时间辅助
# ──────────────────────────────────────────────
def find_nearest_hour(target_hour):
    """找到最近的合法3小时时间点"""
    return min(VALID_HOURS, key=lambda h: abs(h - target_hour))


def get_day_label(date_str, today_str):
    """获取日期友好标签"""
    try:
        d = datetime.strptime(date_str[:10], "%Y-%m-%d")
        t = datetime.strptime(today_str[:10], "%Y-%m-%d")
        diff = (d - t).days
        weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        wd = weekdays[d.weekday()]
        if diff == 0:
            return "今天（{}）".format(wd)
        elif diff == 1:
            return "明天（{}）".format(wd)
        elif diff == 2:
            return "后天（{}）".format(wd)
        elif diff > 0:
            return "{}（{}）".format(d.strftime('%m月%d日'), wd)
        else:
            return d.strftime('%m月%d日')
    except Exception:
        return date_str[:10]


def get_period_label(hour):
    """获取时段友好标签"""
    if 0 <= hour < 3:
        return "深夜"
    elif 3 <= hour < 6:
        return "凌晨"
    elif 6 <= hour < 9:
        return "清晨"
    elif 9 <= hour < 12:
        return "上午"
    elif 12 <= hour < 15:
        return "午间"
    elif 15 <= hour < 18:
        return "下午"
    elif 18 <= hour < 21:
        return "傍晚"
    else:
        return "晚间"


def filter_records(records, target_date=None, target_hour=None):
    """按日期和时间过滤数据"""
    if not records or not isinstance(records, list):
        return records or []

    filtered = records
    if target_date:
        filtered = [r for r in filtered if r.get("date", "")[:10] == target_date]
    if target_hour is not None:
        nearest = find_nearest_hour(target_hour)
        filtered = [r for r in filtered if r.get("hour") == nearest]
    return filtered


# ──────────────────────────────────────────────
# 输出格式化
# ──────────────────────────────────────────────
def format_output(city_name, records, target_date=None, target_hour=None):
    """格式化旅游解读输出"""
    lines = []
    today = datetime.now().strftime("%Y-%m-%d")

    lines.append("")
    lines.append("=" * 60)
    lines.append("  🏞️  {} · 未来7天旅游气象深度解读".format(city_name))
    lines.append("  🕐 生成时间：{}".format(datetime.now().strftime('%Y-%m-%d %H:%M')))
    if target_date:
        lines.append("  📅 查询日期：{}".format(target_date))
    if target_hour is not None:
        nearest = find_nearest_hour(target_hour)
        lines.append("  ⏰ 查询时间：{}:00 附近（匹配到 {:02d}:00）".format(target_hour, nearest))
    lines.append("=" * 60)
    lines.append("")

    if not records:
        lines.append("⚠️  未获取到有效数据，请稍后重试")
        return "\n".join(lines)

    # 按日期分组
    grouped = {}
    date_order = []
    for rec in records:
        date_key = rec.get("date", "")[:10]
        if not date_key:
            continue
        if date_key not in grouped:
            grouped[date_key] = []
            date_order.append(date_key)
        grouped[date_key].append(rec)

    for date_key in date_order[:7]:
        day_label = get_day_label(date_key, today)
        slots = grouped[date_key]

        lines.append("📅  {}  [{}]".format(day_label, date_key))
        lines.append("━" * 60)

        for rec in slots:
            hour = rec.get("hour", 0)
            try:
                hour = int(hour)
            except (TypeError, ValueError):
                hour = 0
            period = get_period_label(hour)
            word = (rec.get("word") or "").strip()
            content = (rec.get("content") or "").strip()

            lines.append("")
            lines.append("  ⏰ {:02d}:00  {}".format(hour, period))
            lines.append("  {}".format("─" * 50))

            if word:
                lines.append("  💡 核心评估：{}".format(word))

            if content:
                lines.append("")
                for para_line in content.split("\n"):
                    para_line = para_line.strip()
                    if para_line:
                        lines.append("  {}".format(para_line))
                    else:
                        lines.append("")

        lines.append("")
        lines.append("━" * 60)
        lines.append("")

    lines.append("=" * 60)
    lines.append("  以上为完整旅游气象深度解读，祝您旅途愉快！✈️")
    lines.append("=" * 60)
    lines.append("")

    return "\n".join(lines)


# ──────────────────────────────────────────────
# 主入口
# ──────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="未来7天逐3小时天气旅游解读")
    parser.add_argument("--city", type=str, help="城市名称（支持模糊匹配）", default="")
    parser.add_argument("--city_id", type=str, help="城市ID（如 101010100）", default="")
    parser.add_argument("--date", type=str, help="查询日期 YYYY-MM-DD（可选）", default="")
    parser.add_argument("--hour", type=int, help="查询时间 0-23，自动匹配最近时段（可选）", default=None)
    args = parser.parse_args()

    city_id = ""
    city_name = ""

    if args.city_id:
        city_id = args.city_id.strip()
        city_name = find_city_by_id(city_id)
        if not city_name:
            city_name = "城市{}".format(city_id)
    elif args.city:
        match = find_city(args.city)
        if match is None:
            print("❌ 未找到城市「{}」，请尝试更精确的城市名称".format(args.city))
            print("提示：支持全国3200+城市及部分国际城市")
            sys.exit(1)
        city_name, city_id = match
    else:
        print("请提供城市参数，例如：")
        print("  python3 travel_weather.py --city 北京")
        print("  python3 travel_weather.py --city_id 101010100")
        print("  python3 travel_weather.py --city 北京 --date 2026-04-20")
        print("  python3 travel_weather.py --city 北京 --date 2026-04-20 --hour 14")
        sys.exit(1)

    print("🔍 正在获取 {}（{}）的旅游天气解读数据…".format(city_name, city_id))

    try:
        records = fetch_travel_data(city_id)
    except RuntimeError as e:
        print("❌ {}".format(e))
        sys.exit(1)

    if not isinstance(records, list):
        print("❌ 数据格式异常，请稍后重试")
        sys.exit(1)

    # 过滤数据
    filtered = filter_records(records, args.date if args.date else None, args.hour)
    output = format_output(city_name, filtered, args.date if args.date else None, args.hour)
    print(output)


if __name__ == "__main__":
    main()
