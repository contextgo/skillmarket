# Agent Communication Hub

> 多 AI 智能体实时通信与任务协同中间件

[![TypeScript](https://img.shields.io/badge/TypeScript-5.4+-3178C6?logo=typescript)](https://www.typescriptlang.org/)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?logo=python)](https://www.python.org/)
[![MCP](https://img.shields.io/badge/MCP-2025--03--26-FF6B35)](https://modelcontextprotocol.io/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

让两个或多个独立 AI 智能体之间实现**实时双向通信**和**任务协同**。

基于 MCP (Model Context Protocol) + stdio 模式，消息本地持久化。

---

## 架构

```
┌──────────────┐         ┌──────────────────────┐         ┌──────────────┐
│   Agent A    │  SSE    │  Agent Communication  │  SSE    │   Agent B    │
│  (Hermes)    │◄───────►│        Hub            │◄───────►│  (WorkBuddy) │
│              │  MCP    │    (stdio)           │  MCP    │              │
└──────┬───────┘◄───────►│                      │◄───────►└──────┬───────┘
       │                  └──────────┬───────────┘               │
  hub_client.py              SQLite DB                   client_sdk
  (Python httpx)            (WAL 模式)                  (TypeScript)
```

### 三层协议

| 层 | 协议 | 用途 |
|----|------|------|
| **MCP 工具层** | stdio JSON-RPC | 结构化操作（发消息、分配任务、查状态） |
| **SSE 推送层** | Server-Sent Events | 实时事件通知（新消息、新任务、上线/离线） |

### 为什么用 MCP 协议

MCP 是 AI Agent 的标准通信协议。Agent 可以像调用本地工具一样调用 Hub 的功能——无需额外的 SDK 学习成本，LLM 天然理解 MCP 工具的 schema。

### 为什么用 Stateless 模式

Hub 使用 MCP SDK 的 Stateless 模式：每个请求创建独立的 Server + Transport 实例，DB 和 SSE 管理器作为模块级单例共享。支持多个 Agent 客户端同时连接。

## 快速开始

### 前置要求

- **Node.js** 18+ （Hub 服务器）
- **Python** 3.9+ （客户端脚本）
- **httpx** Python 包（Hermes 侧客户端，`pip install httpx`）

### 1. 部署 Hub

Hub 服务器已内置，通过 stdio 模式直接启动（无需单独部署服务器）。
配置见下方「接入 Agent」章节。

### 2. 接入 Agent

#### MCP stdio 配置（推荐，LLM 原生支持）

在 Agent 的 MCP 配置文件中添加 Hub 为 stdio 服务器，提供 `HUB_KEY` 进行认证：

```json
{
  "mcpServers": {
    "agent-comm-hub": {
      "command": "node",
      "args": ["<hub-install-path>/stdio.js"],
      "env": {
        "HUB_KEY": "your-connection-key"
      }
    }
  }
}
```

包内仅包含 MCP 工具定义与文档，运行时服务器需从已审查的源码部署。

## 文件结构

### MCP 工具

**消息与任务协同（6 个）**：

| 工具 | 参数 | 说明 |
|------|------|------|
| `send_message` | `from`, `to`, `content`, `type?`, `metadata?` | 发送即时消息 |
| `assign_task` | `from`, `to`, `description`, `context?`, `priority?` | 分配 AI 任务 |
| `update_task_status` | `task_id`, `agent_id`, `status`, `result?`, `progress?` | 汇报任务进度 |
| `get_task_status` | `task_id` | 查询任务状态 |
| `broadcast_message` | `from`, `agent_ids`, `content`, `metadata?` | 广播消息 |
| `get_online_agents` | — | 查询在线 Agent |

**消费水位线（3 个，v1.1 新增）**：

| 工具 | 参数 | 说明 |
|------|------|------|
| `acknowledge_message` | `message_id`, `agent_id` | 标记消息为已处理 |
| `mark_consumed` | `agent_id`, `resource`, `action`, `resource_type?`, `notes?` | 记录资源已处理（防重复） |
| `check_consumed` | `agent_id`, `resource` | 查询资源是否已处理 |

> 所有工具内置错误处理：try-catch + 3 次指数退避重试（100ms → 200ms → 400ms）。`check_consumed` 查询失败时降级返回 `consumed=false`。

## 任务状态机

```
assign_task → pending → in_progress → completed
                            └──→ failed
```

- `pending`：任务已创建，等待接收方拾取
- `in_progress`：接收方正在执行（可多次更新进度）
- `completed`：任务完成
- `failed`：任务执行失败

## 安全配置

| 配置项 | 说明 |
|--------|------|
| `HUB_KEY` | stdio 模式连接密钥，所有 Agent 接入必须提供，用于身份认证与消息完整性校验 |
| 4 级权限模型 | authenticated → member → group_manager → full，逐级授权 |

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `HUB_KEY` | — | 连接密钥（必填） |
| `DB_PATH` | ./comm_hub.db | SQLite 数据库路径 |
| `LOG_LEVEL` | INFO | 日志级别 |

## 踩坑经验

### MCP 协议

1. **必须用 Stateless 模式** — Stateful 模式只允许一个 Client 初始化，多 Agent 场景直接崩
2. **ESM 兼容** — 不能 `require()`，用 `import()` 动态导入

### Python

3. **UTF-8 块读取** — `resp.read(1)` 逐字节会截断多字节字符，必须 `read(4096)`
4. **SSE 长连接保活** — 处理好超时和重连逻辑（指数退避）

### 系统集成

7. **MCP ≠ SSE** — MCP 是工具调用通道（Agent→Hub），SSE 是推送通道（Hub→Agent），两者独立
8. **离线补发** — 消息/任务存 SQLite，上线后 SSE 自动批量推送

## 技术栈

| 组件 | 技术 |
|------|------|
| Hub 服务器 | TypeScript + Express + MCP SDK + better-sqlite3 |
| TS 客户端 SDK | TypeScript + EventSource + fetch |
| Python 客户端 | Python 3.9+ 标准库（零依赖） |

## 许可证

[MIT](LICENSE)

## 致谢

- [Model Context Protocol](https://modelcontextprotocol.io/) — AI Agent 标准通信协议
- [better-sqlite3](https://github.com/WiseLibs/better-sqlite3) — 同步 SQLite 绑定
- [httpx](https://www.python-httpx.org/) — 现代 Python HTTP 客户端
