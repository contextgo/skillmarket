# 快速入门

## 初始化工程
创建一个空的`Spring Boot`工程, 以`mysql`作为默认数据库进行演示。

## 添加依赖
引入`Spring Boot Starter`父工程：
```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>spring-boot-latest-version</version>
    <relativePath/>
</parent>
```

引入`magic-api-spring-boot-starter`依赖：
```xml
<dependency>
    <groupId>org.ssssssss</groupId>
    <artifactId>magic-api-spring-boot-starter</artifactId>
    <version>magic-api-lastest-version</version>
</dependency>
```

## 配置
`application.yml`
```yaml
server:
  port: 9999
magic-api:
  web: /magic/web
  resource:
    location: D:/data/magic-api

spring:
  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3306/magic-api-test?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF-8
    username: root
    password: test
```

## 访问api管理界面
启动项目之后，访问`http://localhost:9999/magic/web` 即可看到Web页面

## 三分钟写出查询接口
**1. 创建分组**
点击创建分组按钮后，输入分组信息，点击创建。

**2. 新建接口**
右键分组，点击新建接口。在编辑器输入内容后，填写接口名称和及其路径。

```javascript
var sql = """
select * from test_data
"""
return db.select(sql)
```

`ctrl+s`保存后，即可访问接口。

**3.访问接口**
```
> curl http://localhost:9999/test/test
```
