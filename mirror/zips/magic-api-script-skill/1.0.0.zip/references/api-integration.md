# Java调用接口

## 调用接口
```java
@Autowired
MagicAPIService service;
Map<String, Object> params = new HashMap<>();
// 注入变量信息
params.put("id", 123);
// 内部调用接口不包含code以及message信息，同时也不走拦截器。
Object value = service.execute("GET", "/hello", params);
// 内部调用接口包含code以及message信息，同时也不走拦截器。
// Object value = service.call("GET", "/hello", params);
```

## 调用函数
```java
@Autowired
MagicAPIService service;

Map<String, Object> params = new HashMap<>();
// 注入变量信息
params.put("a", 1);
params.put("b", 1);
// 调用函数
Object value = service.invoke("/test/add", params);
```

## 保存资源
```java
@Autowired
MagicResourceService service;
// 保存分组信息
service.saveGroup(group);
// 保存接口（ApiInfo）、函数（FunctionInfo）、数据源（DataSourceInfo）
service.saveFile(apiInfo);
```

## 删除资源
```java
@Autowired
MagicResourceService service;
// 删除分组或文件
service.delete(id);
```

## 资源列表
```java
@Autowired
MagicResourceService service;
// 获取分组下的所有文件
service.listFiles(groupId);
// 获取接口（api）、函数（function）、数据源（datasource）列表
service.files(type);
// 获取接口（api）、函数（function）、数据源（datasource）树结构
service.tree(type);
// 获取全部资源的树结构
service.tree();
```

## 其它API

除了以上列举的`API`以外 `MagicAPIService`还有：

```java
/**
 * 上传
 */
boolean upload(InputStream inputStream, String mode) throws IOException;

/**
 * 下载
 */
void download(String groupId, List<SelectedResource> resources, OutputStream os) throws IOException;

/**
 * 推送
 */
JsonBean<?> push(String target, String secretKey, String mode, List<SelectedResource> resources);

/**
 * 处理刷新通知
 */
boolean processNotify(MagicNotify magicNotify);
```

`MagicResourceService` 还有以下方法：

```java
/**
 * 刷新缓存
 */
void refresh();

/**
 * 移动
 * @param src     源ID
 * @param groupId 目标分组
 */
boolean move(String src, String groupId);

/**
 * 复制分组
 * @param src    源ID
 * @param target 目标分组
 */
String copyGroup(String src, String target);

/**
 * 获取文件详情
 */
<T extends MagicEntity> T file(String id);

/**
 * 获取分组详情
 */
Group getGroup(String id);

/**
 * 获取完整分组路径
 */
String getGroupPath(String groupId);

/**
 * 获取完整分组名称
 */
String getGroupName(String groupId);
```
