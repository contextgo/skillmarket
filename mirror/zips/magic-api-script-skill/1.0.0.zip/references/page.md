# 分页查询

## 自动分页
`db.page`可从形如`xxx?page=1&size=10`的url中获取分页参数。

```javascript
// 自动从请求参数中获取页码(默认为page)、页大小(默认为size)
return db.page("""
    select * from sys_user
""")
```

## 手动分页
可手动传入分页参数。

```javascript
return db.page("""
    select * from sys_user
""", 10, 20) // 跳过前20条查10条(limit, offset)
```

## 自定义分页参数
可根据需要在自己的项目中，调整以下分页参数。

```yaml
magic-api:
  page:
    size: size # 页大小的请求参数名称 缺省时为size
    page: page # 页码的请求参数名称 缺省时为page
    default-page: 1 # 自定义默认首页 缺省时为1
    default-size: 10 # 自定义为默认页大小 缺省时为10
```
