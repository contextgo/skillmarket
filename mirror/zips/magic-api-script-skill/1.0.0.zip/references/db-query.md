# 数据库查询

db模块是默认引入的模块，无需import。

## select
- 入参：`sql`:`String`
- 返回值：`List<Map<String,Object>>`
- 函数说明：查询`List`结果

```javascript
return db.select('select * from sys_user');
```

## selectInt
- 入参：`sql`:`String`
- 返回值：`Integer`
- 函数说明：查询`int`结果

```javascript
// 需要保证结果返回一行一列
return db.selectInt('select count(*) from sys_user');
```

## selectOne
- 入参：`sql`:`String`
- 返回值：`Map<String,Object>`
- 函数说明：查询单个对象

```javascript
return db.selectOne('select * from sys_user limit 1');
```

## selectValue
- 入参：`sql`:`String`
- 返回值：`Object`
- 函数说明：查询单个值

```javascript
//需要保证结果返回一行一列
return db.selectValue('select user_name from sys_user limit 1');
```

## page
- 入参：`sql`:`String`
- 入参：`limit` : `long` 可省略
- 入参：`offset` : `long` 可省略
- 返回值：`Object` 默认返回为Object，如果自定义了分页结果，则返回自定义结果
- 函数说明：分页查询

```javascript
return db.page('select * from sys_user');
```

## 列名转换
- normal 列名保持原样
- camel 列名使用驼峰命名
- pascal 列名使用帕斯卡命名
- upper 列名保持全大写
- lower 列名保持全小写

```javascript
return db.camel().select('select * from sys_user');
```
