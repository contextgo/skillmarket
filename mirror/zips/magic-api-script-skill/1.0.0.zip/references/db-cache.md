# 缓存操作

## cache
- 入参：`cacheName`:`String`
- 入参：`ttl`:`long` 缓存有效期，单位毫秒，可省略，默认为配置的值
- 返回值：`db` //返回当前实例，即可以链式调用
- 函数说明：使用缓存

```javascript
// 使用缓存名为user的查询
return db.cache('user').select('select * from sys_user');
```

## deleteCache
- 入参：`cacheName`:`String`
- 返回值：`db` //返回当前实例，即可以链式调用
- 函数说明：删除名为`cacheName`的缓存

```javascript
// 删除名为user的缓存
db.deleteCache('user');
```
