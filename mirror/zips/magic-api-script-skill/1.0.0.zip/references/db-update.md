# 数据库增删改

## update
- 入参：`sql`:`String`
- 返回值：`Integer`
- 函数说明：执行增删改操作

```javascript
return db.update('delete from sys_user');
```

## insert
- 入参：`sql`：`String`
- 入参：`id`：`String`，主键列，可空，如无特殊情况不需要传入
- 返回值: `Object`

```javascript
return db.insert("insert into sys_user(username,password) values('admin','admin)");
```

## call
- 入参：`sql`: `String`
- 返回值：`Map<String,Object>`
- 函数说明：调用存储过程

```javascript
// 入参格式： #{参数名}
// 出参格式： @{参数名, java.sql.Types的类型字符串}
// 出入参格式：@{参数名(值、变量、表达式), java.sql.Types的类型字符串}
var cs1 = body.cs1;
var cs2 = body.cs2;
return db.call("""
    call test(#{cs1}, @{height(cs2), INTEGER}, @{v_area, VARCHAR})
""")
// 返回：{height: 10, v_area: "16.85"}
```

## batchUpdate
- 入参：`sql`：`String`
- 入参：`batchArgs`：`List<Object[]>`数据，占位符和数组下标对应
- 返回值: `int`

```javascript
return db.batchUpdate("""
    update sys_dict set is_del = ? where is_del = ?
""", [
    ["1", "0"].toArray()
])
```
