# Class扩展方法

## newInstance
- 入参：`values`:`Object` 可变参数，构造函数的参数
- 返回值：`Object`
- 函数说明：将`Class`实例化

```javascript
import 'java.text.SimpleDateFormat' as SimpleDateFormat;
return SimpleDateFormat.newInstance('yyyy-MM-dd HH:mm:ss');
//其实可以简写成 new SimpleDateFormat('yyyy-MM-dd HH:mm:ss'); //这是一个语法糖
```

## 获取类名称
支持以下方法
- `getName` - 获取完整类名
- `getSimpleName` - 获取简单类名
- `getCanonicalName` - 获取规范类名

```javascript
import 'java.text.SimpleDateFormat' as SimpleDateFormat;
println(SimpleDateFormat.getName());        // java.text.SimpleDateFormat
println(SimpleDateFormat.getSimpleName());  // SimpleDateFormat
println(SimpleDateFormat.getCanonicalName()); // java.text.SimpleDateFormat
```
