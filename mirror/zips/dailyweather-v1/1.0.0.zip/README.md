# 🌤️ 每日天气推送

一个简洁可靠的 OpenClaw 技能，每日定时推送天气信息到你的聊天应用。

**功能特点**：
- 🌍 支持中国任意城市（经纬度定位）
- ⏰ 可自定义推送时间
- 📱 多平台推送（微信/企业微信/QQ/Telegram/Discord）
- 🌦️ 数据来自彩云天气 API，精准可靠
- 🔒 安全配置管理（API Token 加密存储）

---

## 📦 安装

```bash
# 从 SkillHub 安装（发布后）
openclaw skills install daily-weather-push

# 或从本地文件安装
openclaw skills install ./daily-weather-push-v1.0.0.tar.gz
```

---

## ⚠️ 【重要】首次配置必读

**安装后，首次运行前，你必须完成以下 4 项核心配置，否则任务将无法推送！**

### 配置清单

| 配置项 | 说明 | 如何获取 |
|--------|------|----------|
| **彩云天气 API Token** | 访问彩云天气开放平台注册并获取 | https://caiyunapp.com |
| **城市经纬度** (lng/lat) | 使用地图工具查找城市的经度和纬度 | 见下方"如何获取经纬度" |
| **城市名称** (city) | 用于消息显示的友好名称 | 如"深圳"、"北京" |
| **推送时间** (push_time) | cron 表达式，定义每天推送的时刻 | 如 `30 7 * * *` 表示 7:30 |
| **推送渠道和目标** | 至少选择一种渠道并填写对应的 target/account | 见下方"配置推送渠道" |

### 配置命令示例

```bash
# 1️⃣ 设置彩云天气 API Token（必填）
openclaw config set skills.daily-weather-push.caiyun_api_token "你的彩云API_TOKEN"

# 2️⃣ 设置城市经纬度（必填）
openclaw config set skills.daily-weather-push.lng "116.4074"      # 经度（示例：北京）
openclaw config set skills.daily-weather-push.lat "39.9042"      # 纬度（示例：北京）

# 3️⃣ 设置城市名称（必填）
openclaw config set skills.daily-weather-push.city "北京"

# 4️⃣ 设置推送时间（必填）
openclaw config set skills.daily-weather-push.push_time "30 7 * * *"  # 每天 7:30

# 5️⃣ 配置推送渠道（至少选一种）

## 微信推送
openclaw config set skills.daily-weather-push.push_to_weixin true
openclaw config set skills.daily-weather-push.weixin_target "your_wechat_user_id@im.wechat"
openclaw config set skills.daily-weather-push.weixin_account "your_wechat_account_id"

## 企业微信推送
# openclaw config set skills.daily-weather-push.push_to_wecom true
# openclaw config set skills.daily-weather-push.wecom_target "你的企业微信用户ID"
# openclaw config set skills.daily-weather-push.wecom_account "账号ID"

## QQ 推送
# openclaw config set skills.daily-weather-push.push_to_qq true
# openclaw config set skills.daily-weather-push.qq_target "QQ用户ID"
# openclaw config set skills.daily-weather-push.qq_account "账号ID"

## Telegram 推送
# openclaw config set skills.daily-weather-push.push_to_telegram true
# openclaw config set skills.daily-weather-push.telegram_target "CHAT_ID"
# openclaw config set skills.daily-weather-push.telegram_account "BOT_TOKEN"

## Discord 推送
# openclaw config set skills.daily-weather-push.push_to_discord true
# openclaw config set skills.daily-weather-push.discord_target "CHANNEL_ID"
# openclaw config set skills.daily-weather-push.discord_account "BOT_TOKEN"
```

---

## 🔧 如何获取城市经纬度？

你需要使用地图服务来查找你关心城市的**经度 (lng)** 和**纬度 (lat)**。注意必须是 **GCJ02 坐标系（火星坐标，百度地图用的）**。

### 推荐方法（百度地图）

1. 打开 [百度地图](https://map.baidu.com/)
2. 搜索你的城市（如"深圳市"）
3. 在地图上右键点击你想推送的地区中心点，选择"复制坐标"
4. 你会得到类似 `22.5431,114.0579`（先纬度后经度），调换顺序即可：
   - `lng = 116.4074`（经度，示例：北京）
   - `lat = 39.9042`（纬度，示例：北京）

### 备用方法（高德/腾讯地图）

使用在线坐标拾取工具，确保选择"GCJ02"格式输出。

---

## ⏰ 配置定时任务

安装完后还需要在系统的 crontab 中添加任务，让 OpenClaw 定时调用这个技能：

```bash
crontab -e
```

添加一行（注意修改 PATH 以包含 openclaw 命令位置）：

```bash
PATH=/usr/local/bin:/usr/bin:/bin
# 时间请与 push_time 配置保持一致
30 7 * * * /usr/bin/python3 /root/.openclaw/skills/daily-weather-push/main.py
```

**解释**：
- `30 7 * * *` 表示每天 7:30 执行（要和 `push_time` 一致）
- `/usr/bin/python3` 是 Python 路径
- `/root/.openclaw/skills/daily-weather-push/main.py` 是技能安装后的路径

> 💡 如果安装到其他目录，请相应调整主程序路径。

---

## 📖 完整配置项参考

| 配置键 | 类型 | 必填 | 默认 | 说明 |
|--------|------|------|------|------|
| `caiyun_api_token` | string | ✅ | - | 彩云天气 API Token（从 https://caiyunapp.com 获取） |
| `lng` | number | ✅ | - | 经度（GCJ02 坐标系，范围 70~140） |
| `lat` | number | ✅ | - | 纬度（GCJ02 坐标系，范围 15~55） |
| `city` | string | ✅ | - | 城市名称（用于消息标题） |
| `push_time` | string | ✅ | `30 7 * * *` | cron 表达式，定义每日推送时刻 |
| `push_to_weixin` | boolean | ❌ | `false` | 是否启用微信推送 |
| `push_to_wecom` | boolean | ❌ | `false` | 是否启用企业微信推送 |
| `push_to_qq` | boolean | ❌ | `false` | 是否启用 QQ 推送 |
| `push_to_telegram` | boolean | ❌ | `false` | 是否启用 Telegram 推送 |
| `push_to_discord` | boolean | ❌ | `false` | 是否启用 Discord 推送 |
| `weixin_target` | string | 条件性 | - | 微信用户 ID（格式：`your_wechat_user_id@im.wechat`），`push_to_weixin=true` 时必填 |
| `weixin_account` | string | 条件性 | - | 微信账号 ID，`push_to_weixin=true` 时必填 |
| `wecom_target` | string | 条件性 | - | 企业微信用户/部门 ID，`push_to_wecom=true` 时必填 |
| `wecom_account` | string | 条件性 | - | 企业微信账号 ID，`push_to_wecom=true` 时必填 |
| `qq_target` | string | 条件性 | - | QQ 用户 ID，`push_to_qq=true` 时必填 |
| `qq_account` | string | 条件性 | - | QQ 账号 ID，`push_to_qq=true` 时必填 |
| `telegram_target` | string | 条件性 | - | Telegram chat ID，`push_to_telegram=true` 时必填 |
| `telegram_account` | string | 条件性 | - | Telegram bot token，`push_to_telegram=true` 时必填 |
| `discord_target` | string | 条件性 | - | Discord channel ID，`push_to_discord=true` 时必填 |
| `discord_account` | string | 条件性 | - | Discord bot token，`push_to_discord=true` 时必填 |
| `marker_dir` | string | ❌ | `/var/lib/openclaw-skills` | 幂等标记存储目录，一般不需要修改 |

---

## 🐛 故障排查

### 技能运行但无推送

1. 检查 crontab 是否配置正确：`crontab -l`
2. 查看系统日志：`grep CRON /var/log/syslog | tail -20`
3. 确认 `push_time` 和 crontab 的时间一致
4. 检查幂等标记文件：`ls /var/lib/openclaw-skills/sent-daily-weather-push.*`

### 推送失败（日志中有错误）

- **API 错误**：检查 `caiyun_api_token` 是否正确、是否过期
- **配置缺失**：确认必填配置已设置：`openclaw config get skills.daily-weather-push`
- **渠道错误**：检查 `weixin_target`、`weixin_account` 等格式是否正确
- **网络问题**：确认服务器可访问外网（彩云 API）

### 配置不生效

运行以下命令查看当前所有配置：
```bash
openclaw config get skills.daily-weather-push
```

如需重置某个配置：
```bash
openclaw config unset skills.daily-weather-push.caiyun_api_token
```

---

## 📄 许可证

MIT

---

## 🤝 贡献

欢迎提交 Issue 和 PR！
