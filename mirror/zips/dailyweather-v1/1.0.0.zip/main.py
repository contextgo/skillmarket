#!/usr/bin/env python3
"""
Daily Weather Push - SkillHub Standard Version

A clean, reusable skill that pushes daily weather updates to configured channels.
No shared_lib dependency. Self-contained.
"""
import json
import logging
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional

import requests

# ============================
# Configuration & Constants
# ============================

logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

API_BASE = "https://api.caiyunapp.com/v2.6"
REQUEST_TIMEOUT = 15
CACHE_TTL = 600  # 10 minutes

# ============================
# Configuration Loader
# ============================

def load_config() -> Dict[str, Any]:
    """
    Load configuration from environment variables or OpenClaw config store.
    Priority: env vars > openclaw config > defaults
    """
    # Try to import OpenClaw config helper if available
    try:
        from openclaw.config import get as oc_get
        get = lambda k, default=None: oc_get(f"skills.daily-weather-push.{k}", default) or os.getenv(k.upper())
    except ImportError:
        get = lambda k, default=None: os.getenv(k.upper(), default)

    config = {
        "caiyun_api_token": get("caiyun_api_token"),
        "lng": float(get("lng", "0") or 0),
        "lat": float(get("lat", "0") or 0),
        "city": get("city", ""),
        "push_to_weixin": get("push_to_weixin", "false").lower() == "true",
        "push_to_wecom": get("push_to_wecom", "false").lower() == "true",
        "push_to_qq": get("push_to_qq", "false").lower() == "true",
        "push_to_telegram": get("push_to_telegram", "false").lower() == "true",
        "push_to_discord": get("push_to_discord", "false").lower() == "true",
        "weixin_target": get("weixin_target"),
        "weixin_account": get("weixin_account"),
        "wecom_target": get("wecom_target"),
        "wecom_account": get("wecom_account"),
        "qq_target": get("qq_target"),
        "qq_account": get("qq_account"),
        "telegram_target": get("telegram_target"),
        "telegram_account": get("telegram_account"),
        "discord_target": get("discord_target"),
        "discord_account": get("discord_account"),
    }
    return config

# ============================
# API Functions
# ============================

def caiyun_request(endpoint: str, api_token: str, params: Optional[Dict] = None) -> Dict:
    """Make a request to Caiyun Weather API."""
    url = f"{API_BASE}/{api_token}/{endpoint}"
    resp = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    return resp.json()

def get_realtime_weather(api_token: str, lng: float, lat: float) -> Dict:
    """Fetch realtime weather data."""
    endpoint = f"{lng},{lat}/realtime?lang=zh_CN&unit=metric:v2"
    data = caiyun_request(endpoint, api_token)
    return data["result"]["realtime"]

def get_hourly_weather(api_token: str, lng: float, lat: float) -> Dict:
    """Fetch hourly forecast for temperature range."""
    endpoint = f"{lng},{lat}/hourly?hourlysteps=24&lang=zh_CN&unit=metric:v2"
    data = caiyun_request(endpoint, api_token)
    return data["result"]["hourly"]

# ============================
# Message Formatting
# ============================

def format_weather_message(realtime: Dict, hourly: Dict, city: str, today_str: str) -> str:
    """Format weather data into a human-readable message."""
    now = datetime.now()

    current_temp = f"{realtime['temperature']:.1f}°C"
    skycon = realtime.get("skycon", "")
    wind_speed = realtime["wind"]["speed"]
    wind_dir = realtime["wind"]["direction"]
    wind = f"{wind_speed:.1f} 公里/小时 {degrees_to_direction(wind_dir)}"
    aqi = realtime["air_quality"]["aqi"]["chn"]
    humidity = f"{realtime['humidity'] * 100:.0f}%"
    apparent = f"{realtime['apparent_temperature']:.1f}°C"
    precip = f"{realtime['precipitation']['local']['intensity']:.1f} 毫米/小时"
    prob_raw = realtime["precipitation"]["local"].get("probability", 0)
    prob_display = prob_raw * 100 if prob_raw <= 1 else prob_raw
    prec_prob = f"{prob_display:.2f}%"

    # Temperature range from hourly
    temps = [t["value"] for t in hourly.get("temperature", []) if today_str in t["datetime"]]
    temp_range_str = ""
    if temps:
        min_t, max_t = int(min(temps)), int(max(temps))
        temp_range_str = f" / {min_t}~{max_t}°C"

    # Weather icon mapping
    weather_icons = {
        "CLEAR_DAY": "☀️", "CLEAR_NIGHT": "🌙",
        "PARTLY_CLOUDY_DAY": "⛅", "PARTLY_CLOUDY_NIGHT": "☁️",
        "CLOUDY": "☁️", "LIGHT_RAIN": "🌧️", "MODERATE_RAIN": "🌧️",
        "HEAVY_RAIN": "⛈️", "STORM_RAIN": "⛈️", "FOG": "🌫️", "SNOW": "❄️"
    }
    icon = weather_icons.get(skycon, "🌡️")

    lines = [
        f"{icon} {city}今日天气 ({today_str})",
        "",
        "",
        "【今日概况】",
        f"🌡️ 温度：{current_temp}{temp_range_str}",
        f"☁️ 天气：{skycon_to_text(skycon)}",
        f"🌬️ 风向：{wind}",
        "",
        "",
        "【实时数据】",
        f"🌫️ 空气质量：AQI {aqi}",
        f"💧 湿度：{humidity}",
        f"🌧️ 降雨量：{precip}",
        f"📊 降雨概率：{prec_prob}",
        f"🌡️ 体感：{apparent}",
        "",
        "",
        f"⏰ 数据时间：{now.strftime('%Y-%m-%d %H:%M')}",
        f"📢 数据来源：彩云天气"
    ]
    return "\n".join(lines)

def skycon_to_text(skycon: str) -> str:
    """Convert skycon code to Chinese text."""
    mapping = {
        "CLEAR_DAY": "晴", "CLEAR_NIGHT": "晴朗夜间",
        "PARTLY_CLOUDY_DAY": "多云", "PARTLY_CLOUDY_NIGHT": "多云夜间",
        "CLOUDY": "阴", "LIGHT_RAIN": "小雨", "MODERATE_RAIN": "中雨",
        "HEAVY_RAIN": "大雨", "STORM_RAIN": "暴雨", "FOG": "雾", "SNOW": "雪"
    }
    return mapping.get(skycon, skycon)

def degrees_to_direction(degrees: float) -> str:
    """Convert wind degrees to compass direction."""
    directions = ["北", "东北", "东", "东南", "南", "西南", "西", "西北"]
    idx = round(degrees / 45) % 8
    return directions[idx]

# ============================
# Channel Senders
# ============================

def send_to_channel(channel: str, target: str, account: str, message: str, image_path: Optional[str] = None) -> bool:
    """Send message to a configured channel via OpenClaw CLI."""
    # This is a simplified version - in production you'd use proper OpenClaw API
    # For now, we assume openclaw CLI is in PATH
    import subprocess
    cmd = [
        "openclaw", "message", "send",
        "--channel", channel,
        "--target", target,
        "-m", message
    ]
    if account:
        cmd.extend(["--account", account])
    if image_path:
        cmd.extend(["--media", image_path])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            logger.info(f"Successfully sent to {channel}")
            return True
        else:
            logger.error(f"Failed to send to {channel}: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"Exception sending to {channel}: {e}")
        return False

# ============================
# Main Entry Point
# ============================

def run() -> Dict[str, Any]:
    """Main entry point for the skill."""
    logger.info("Starting daily-weather-push")

    config = load_config()
    today_str = datetime.now().strftime("%Y-%m-%d")
    marker_dir = config.get("marker_dir", "/var/lib/openclaw-skills")
    sent_marker = os.path.join(marker_dir, f"sent-daily-weather-push.{today_str}")

    # Idempotency check
    if os.path.exists(sent_marker):
        logger.info("Already sent today, skipping")
        print(json.dumps({"status": "skipped", "reason": "already sent today"}))
        return {"status": "skipped", "reason": "already sent today"}

    # Validate required config
    required = ["caiyun_api_token", "lng", "lat", "city"]
    missing = [k for k in required if not config.get(k)]
    if missing:
        logger.error(f"Missing required config: {missing}")
        sys.exit(1)

    # Validate at least one channel enabled with proper credentials
    channels_enabled = []
    if config.get("push_to_weixin") and config.get("weixin_target") and config.get("weixin_account"):
        channels_enabled.append(("weixin", "weixin_target", "weixin_account"))
    if config.get("push_to_wecom") and config.get("wecom_target") and config.get("wecom_account"):
        channels_enabled.append(("wecom", "wecom_target", "wecom_account"))
    if config.get("push_to_qq") and config.get("qq_target") and config.get("qq_account"):
        channels_enabled.append(("qq", "qq_target", "qq_account"))
    if config.get("push_to_telegram") and config.get("telegram_target") and config.get("telegram_account"):
        channels_enabled.append(("telegram", "telegram_target", "telegram_account"))
    if config.get("push_to_discord") and config.get("discord_target") and config.get("discord_account"):
        channels_enabled.append(("discord", "discord_target", "discord_account"))

    if not channels_enabled:
        logger.warning("No push channel enabled or configured, skipping push")
        print(json.dumps({"status": "skipped", "reason": "no channel configured"}))
        return {"status": "skipped", "reason": "no channel configured"}

    # Fetch weather data
    try:
        logger.info("Fetching weather data...")
        realtime = get_realtime_weather(config["caiyun_api_token"], config["lng"], config["lat"])
        hourly = get_hourly_weather(config["caiyun_api_token"], config["lng"], config["lat"])
    except Exception as e:
        logger.error(f"Failed to fetch weather: {e}")
        sys.exit(1)

    # Format message
    message = format_weather_message(realtime, hourly, config["city"], today_str)

    # Send to all enabled channels
    success_count = 0
    for channel, target_key, account_key in channels_enabled:
        target = config[target_key]
        account = config[account_key]
        logger.info(f"Sending to {channel}...")
        if send_to_channel(channel, target, account, message):
            success_count += 1

    # Create idempotency marker
    try:
        os.makedirs(marker_dir, exist_ok=True)
        with open(sent_marker, "w") as f:
            f.write(datetime.now().isoformat())
    except OSError as e:
        logger.warning(f"Could not write marker: {e}")

    result = {
        "status": "success",
        "city": config["city"],
        "temperature": f"{realtime['temperature']:.1f}°C",
        "aqi": realtime["air_quality"]["aqi"]["chn"],
        "date": today_str,
        "channels_sent": success_count,
        "channels_total": len(channels_enabled)
    }
    print(json.dumps(result, ensure_ascii=False))
    logger.info("Completed")
    return result

if __name__ == "__main__":
    run()
