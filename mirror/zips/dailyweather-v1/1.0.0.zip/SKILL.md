# 🌤️ Daily Weather Push Skill

## Overview

A reliable daily weather notification skill for OpenClaw that sends weather updates to your preferred chat platform at a scheduled time each day.

**Type**: Scheduled Notification Skill
**Platform**: OpenClaw
**Language**: Python 3.8+
**Dependencies**: requests (>=2.28.0)

---

## Features

- ✅ **Accurate Weather Data**: Powered by Caiyun Weather API (彩云天气)
- ✅ **Flexible Scheduling**: Custom cron expressions for push time
- ✅ **Multi-Channel Support**: WeChat, WeCom, QQ, Telegram, Discord
- ✅ **Reliable Execution**: Idempotent design, safe retries, and error handling
- ✅ **Easy Configuration**: Simple JSON schema-based config

---

## Quick Start

### 1. Install the Skill

```bash
# From SkillHub (once published)
openclaw skills install daily-weather-push

# Or from local directory
cd daily-weather-push
openclaw skills install .
```

### 2. Configure the Skill

Before first run, complete these required configurations:

```bash
# Required: Get Caiyun API token from https://caiyunapp.com
openclaw config set skills.daily-weather-push.caiyun_api_token "your_token"

# Required: Set your city coordinates (use Google Maps or Baidu Maps to find lng/lat)
openclaw config set skills.daily-weather-push.lng "116.4074"
openclaw config set skills.daily-weather-push.lat "39.9042"
openclaw config set skills.daily-weather-push.city "北京"

# Required: Set push schedule (cron format)
openclaw config set skills.daily-weather-push.push_time "30 7 * * *"  # 7:30 AM daily

# Required: Choose your push channel and set target/account
openclaw config set skills.daily-weather-push.push_to_weixin true
openclaw config set skills.dailt-weather-push.weixin_target "your_wechat_user_id@im.wechat"
openclaw config set skills.daily-weather-push.weixin_account "your_account_id"
```

### 3. Add to Crontab

```bash
crontab -e
```

Add (adjust path if needed):

```bash
PATH=/usr/local/bin:/usr/bin:/bin
30 7 * * * /usr/bin/python3 /root/.openclaw/skills/daily-weather-push/main.py
```

### 4. Test It

Manually run once to verify:

```bash
/usr/bin/python3 /root/.openclaw/skills/daily-weather-push/main.py
```

You should see:
```
[INFO] 微信推送成功
{"city": "...", "temperature": "...", ...}
```

---

## Configuration Schema

See `config.schema.json` for full schema. Here are key fields:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `caiyun_api_token` | string | ✅ | Caiyun Weather API token. Get from https://caiyunapp.com |
| `lng` | number | ✅ | Longitude (Baidu coordinate, GCJ02) |
| `lat` | number | ✅ | Latitude (Baidu coordinate, GCJ02) |
| `city` | string | ✅ | City name for display |
| `push_time` | string | ✅ | Cron expression (e.g., "30 7 * * *") |
| `push_to_weixin` | boolean | ❌ | Enable WeChat push (default: false) |
| `push_to_wecom` | boolean | ❌ | Enable WeCom push (default: false) |
| `push_to_qq` | boolean | ❌ | Enable QQ push (default: false) |
| `push_to_telegram` | boolean | ❌ | Enable Telegram push (default: false) |
| `push_to_discord` | boolean | ❌ | Enable Discord push (default: false) |
| `weixin_target` | string | conditional | WeChat user ID (format: `your_wechat_user_id@im.wechat`) |
| `weixin_account` | string | conditional | WeChat account ID |
| *(similar for other channels)* | | | |

---

## Output Format

On success, the skill outputs JSON to stdout:

```json
{
  "status": "success",
  "city": "北京",
  "temperature": "25.5°C",
  "aqi": 26,
  "date": "2026-04-08"
}
```

On skip (already sent today):

```json
{
  "status": "skipped",
  "reason": "already sent today"
}
```

---

## Troubleshooting

### "caiyun_api_token not set"
→ Set `caiyun_api_token` in config.

### "weixin_target not set"
→ Set `weixin_target` and `weixin_account` if `push_to_weixin` is true.

### Push not arriving
1. Verify channel is enabled and configured
2. Check `/var/lib/openclaw-skills/` for sent marker
3. Review logs: `tail -f /var/log/syslog | grep CRON`

---

## License

MIT

---

## Credits

- Weather data: [彩云天气](https://caiyunapp.com/)
- Framework: OpenClaw
