# 🍄 body-shape-manager 开发计划

## 开发阶段

### Phase 1：目录结构搭建
- [x] 创建 skill 根目录 `body-shape-manager/`
- [x] 创建子目录 `references/`、`scripts/`、`memory/`
- [x] 创建空白的 `SKILL.md` 框架
- [x] 创建 `TODO.md` 本文件

**产出**：完整的目录骨架

---

### Phase 2：数据基础层
- [x] 创建 `references/user_profile.json` 用户档案模板
- [x] 创建 `references/food_database.json` 常见食物营养数据库（~60种食物）
- [x] 创建 `references/nutrition_guide.md` 营养学知识参考文档

**产出**：数据基础层，用户档案模板、食物营养数据库

---

### Phase 3：核心计算模块
- [x] 开发 `scripts/nutrition_calculator.py`
  - BMR 计算（Mifflin-St Jeor 公式）
  - TDEE 计算（活动系数映射）
  - 每日目标热量计算（增肌/减脂/维持）
  - 营养素分配计算（蛋白质/碳水/脂肪）
  - 目标分段拆解算法（根据当前体重和目标体重自动拆阶段）

**产出**：核心计算逻辑，可独立测试

---

### Phase 4：用户引导模块
- [x] 开发 `scripts/init_profile.py`
  - 一轮问卷设计（6个问题，一次性问完）
  - 问题选项大白话化
  - 调用 nutrition_calculator 计算个人数据
  - 保存到 `references/user_profile.json`

**产出**：首次用户引导流程，可独立运行测试

---

### Phase 5：饮食记录模块
- [x] 开发 `scripts/diet_logger.py`
  - 读取/写入每日饮食日志 `memory/YYYY-MM-DD.md`
  - 按餐次记录（早餐/午餐/晚餐/加餐）
  - 累计汇总计算（热量、三大营养素）
  - 模糊食物搜索与匹配
  - 数据库没有的食物 → AI 根据常识自动估算
  - 生成实时智能建议

**产出**：饮食日志读写功能

---

### Phase 6：SKILL.md 主流程
- [x] 编写完整的 `SKILL.md`
  - 触发关键词定义
  - 主流程逻辑编排
  - 调用各模块的顺序
  - 文字记录流程
  - AI 估算联动流程
  - 输出格式模板

**产出**：完整的 SKILL.md，可投入使用

---

### Phase 7：测试与优化
- [x] 端到端测试：完整走一遍首次引导 → 记录餐食 → 查看汇总
- [x] 边界 case 处理（数据库没有的食物 → AI 估算）
- [x] 文档完善（SKILL.md、TODO.md）

---

## 里程碑

| 阶段 | 内容 | 状态 |
|------|------|------|
| Phase 1 | 目录结构 | ✅ 完成 |
| Phase 2 | 数据基础层 | ✅ 完成 |
| Phase 3 | 核心计算模块 | ✅ 完成 |
| Phase 4 | 用户引导模块 | ✅ 完成 |
| Phase 5 | 饮食记录模块 | ✅ 完成 |
| Phase 6 | SKILL.md 主流程 | ✅ 完成 |
| Phase 7 | 测试与优化 | ✅ 完成 |

---

## 最终目录结构

```
body-shape-manager/
├── SKILL.md (6018 bytes) - 主技能说明文档
├── TODO.md - 开发进度追踪
├── references/
│   ├── user_profile.json - 用户档案
│   ├── food_database.json - 食物营养数据库（~60种食物）
│   └── nutrition_guide.md - 营养学参考
├── scripts/
│   ├── init_profile.py - 用户引导问卷模块
│   ├── nutrition_calculator.py - 核心计算模块
│   └── diet_logger.py - 饮食日志模块
└── memory/
    └── YYYY-MM-DD.md - 每日饮食日志
```

---

## 测试记录

### 2026-04-01 Phase 3 测试
- ✅ BMR/TDEE 计算正常
- ✅ 营养素分配正确
- ✅ 目标分段拆解（70kg→65kg 单阶段，80kg→65kg 两阶段）

### 2026-04-01 Phase 4 测试
- ✅ 问卷流程正常
- ✅ 各问题解析正确
- ✅ 与 nutrition_calculator 联动

### 2026-04-01 Phase 5 测试
- ✅ 食物模糊搜索
- ✅ 多餐次记录
- ✅ 日志读写
- ✅ 智能建议生成
- ✅ 数据库无食物时 AI 估算

### 2026-04-01 Phase 6-7 完成
- ✅ SKILL.md 完整主流程编写
- ✅ 端到端完整测试通过
