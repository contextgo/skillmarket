#!/usr/bin/env python3
"""
init_profile.py - 用户引导模块
body-shape-manager
首次使用引导，一轮问卷搞定所有信息
"""

import json
from pathlib import Path
from datetime import datetime

# ============ 路径配置 ============
SKILL_DIR = Path(__file__).parent.parent
USER_PROFILE_PATH = SKILL_DIR / "references" / "user_profile.json"

# ============ 常量定义 ============
ACTIVITY_OPTIONS = {
    "A": {"key": "sedentary", "label": "几乎不运动，上班坐着为主"},
    "B": {"key": "lightly_active", "label": "偶尔散散步或轻度活动"},
    "C": {"key": "moderately_active", "label": "每周运动 2-3 次（跑步、健身等）"},
    "D": {"key": "very_active", "label": "每周运动 4-5 次，运动量比较大"},
    "E": {"key": "extra_active", "label": "每天都在运动，健身爱好者"},
}

GOAL_OPTIONS = {
    "A": {"key": "cut", "label": "减肥（减少脂肪）"},
    "B": {"key": "bulk", "label": "增肌（增加肌肉）"},
    "C": {"key": "maintain", "label": "维持现状，保持健康"},
}

# ============ 问卷模板 ============
QUESTIONNAIRE = """
🍄 欢迎使用形体管理助手！

在开始之前，我需要了解一些关于你的基本信息。请依次回答以下问题：

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣ 你的身高和体重是多少？
   输入示例：175cm / 70kg

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2️⃣ 你的年龄是？
   输入数字，例如：28

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3️⃣ 你的性别是？
   A. 男
   B. 女

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

4️⃣ 你平时运动多吗？
   A. 几乎不运动，上班坐着为主
   B. 偶尔散散步或轻度活动
   C. 每周运动 2-3 次（跑步、健身等）
   D. 每周运动 4-5 次，运动量比较大
   E. 每天都在运动，健身爱好者

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

5️⃣ 你现在的目标是什么？
   A. 减肥（减少脂肪）
   B. 增肌（增加肌肉）
   C. 维持现状，保持健康

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

6️⃣ 你的目标体重是多少？（单位：kg）
   直接输入数字，例如：65
   如果想维持现状或不确定，可以输入当前体重

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# ============ 解析用户输入 ============
def parse_height_weight(input_str: str) -> dict:
    """
    解析身高体重输入
    支持格式："175cm / 70kg", "175 / 70", "175,70"
    """
    # 清理字符串
    s = input_str.replace(" ", "").replace("cm", "").replace("kg", "").replace(",", "/")
    parts = s.split("/")
    
    if len(parts) != 2:
        raise ValueError("格式错误，请按格式输入：身高cm / 体重kg")
    
    try:
        height = float(parts[0])
        weight = float(parts[1])
    except ValueError:
        raise ValueError("请输入有效的数字")
    
    if height < 100 or height > 250:
        raise ValueError("身高应该在 100-250cm 之间")
    if weight < 30 or weight > 300:
        raise ValueError("体重应该在 30-300kg 之间")
    
    return {"height_cm": height, "weight_kg": weight}


def parse_gender(input_str: str) -> str:
    """解析性别输入"""
    s = input_str.strip().upper()
    if s == "A" or s == "男":
        return "male"
    elif s == "B" or s == "女":
        return "female"
    raise ValueError("请输入 A(男) 或 B(女)")


def parse_activity(input_str: str) -> str:
    """解析运动量选择"""
    s = input_str.strip().upper()
    if s in ACTIVITY_OPTIONS:
        return ACTIVITY_OPTIONS[s]["key"]
    for key, opt in ACTIVITY_OPTIONS.items():
        if input_str.strip() in opt["label"]:
            return opt["key"]
    raise ValueError("请输入 A/B/C/D/E 中的一个")


def parse_goal(input_str: str) -> str:
    """解析目标选择"""
    s = input_str.strip().upper()
    if s in GOAL_OPTIONS:
        return GOAL_OPTIONS[s]["key"]
    for key, opt in GOAL_OPTIONS.items():
        if input_str.strip() in opt["label"]:
            return opt["key"]
    raise ValueError("请输入 A/B/C 中的一个")


def parse_target_weight(input_str: str) -> float:
    """解析目标体重"""
    try:
        weight = float(input_str.strip())
        if weight < 30 or weight > 300:
            raise ValueError("目标体重应该在 30-300kg 之间")
        return weight
    except ValueError:
        raise ValueError("请输入有效的数字（单位：kg）")


# ============ 创建用户档案 ============
def create_user_profile(answers: dict) -> dict:
    """
    根据问卷答案创建用户档案
    """
    profile = {
        "created_at": datetime.now().strftime("%Y-%m-%d"),
        "basic_info": {
            "height_cm": answers["height_cm"],
            "weight_kg": answers["weight_kg"],
            "age": answers["age"],
            "gender": answers["gender"],
            "activity_level": answers["activity_level"],
        },
        "goal": {
            "type": answers["goal"],
            "target_weight_kg": answers["target_weight_kg"],
        },
        "exercise": {
            "today_burned_kcal": 0,
            "last_updated": datetime.now().strftime("%Y-%m-%d"),
        },
        "calculated": None,  # 待计算后填充
    }
    
    return profile


# ============ 保存用户档案 ============
def save_profile(profile: dict) -> bool:
    """
    保存用户档案到文件
    """
    try:
        with open(USER_PROFILE_PATH, "w", encoding="utf-8") as f:
            json.dump(profile, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"保存失败: {e}")
        return False


# ============ 加载现有档案 ============
def load_profile() -> dict:
    """加载现有用户档案"""
    if not USER_PROFILE_PATH.exists():
        return None
    with open(USER_PROFILE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


# ============ 检查是否已初始化 ============
def is_profile_initialized() -> bool:
    """检查用户档案是否已初始化"""
    profile = load_profile()
    return profile is not None and profile.get("calculated") is not None


# ============ 获取引导问卷文本 ============
def get_questionnaire_text() -> str:
    """获取问卷文本"""
    return QUESTIONNAIRE


# ============ 处理用户回答（主入口） ============
def process_answer(question_num: int, user_input: str, answers: dict = None) -> dict:
    """
    处理用户在某个问题上的回答
    返回: {"success": True/False, "message": str, "next_question": int, "answers": dict}
    """
    if answers is None:
        answers = {}
    
    try:
        if question_num == 1:
            # 解析身高体重
            parsed = parse_height_weight(user_input)
            answers["height_cm"] = parsed["height_cm"]
            answers["weight_kg"] = parsed["weight_kg"]
            return {
                "success": True,
                "message": f"好的，身高 {parsed['height_cm']}cm，体重 {parsed['weight_kg']}kg ✅",
                "next_question": 2,
                "answers": answers,
            }
        
        elif question_num == 2:
            # 解析年龄
            try:
                age = int(user_input.strip())
                if age < 10 or age > 100:
                    raise ValueError("年龄应该在 10-100 之间")
                answers["age"] = age
            except ValueError as e:
                return {"success": False, "message": str(e), "next_question": 2, "answers": answers}
            
            return {
                "success": True,
                "message": f"好的，年龄 {age} 岁 ✅",
                "next_question": 3,
                "answers": answers,
            }
        
        elif question_num == 3:
            # 解析性别
            answers["gender"] = parse_gender(user_input)
            gender_text = "男" if answers["gender"] == "male" else "女"
            return {
                "success": True,
                "message": f"好的，性别 {gender_text} ✅",
                "next_question": 4,
                "answers": answers,
            }
        
        elif question_num == 4:
            # 解析运动量
            answers["activity_level"] = parse_activity(user_input)
            return {
                "success": True,
                "message": f"好的，已记录你的运动情况 ✅",
                "next_question": 5,
                "answers": answers,
            }
        
        elif question_num == 5:
            # 解析目标
            answers["goal"] = parse_goal(user_input)
            goal_text = {"cut": "减脂", "bulk": "增肌", "maintain": "维持"}.get(answers["goal"], "")
            return {
                "success": True,
                "message": f"好的，目标：{goal_text} ✅",
                "next_question": 6,
                "answers": answers,
            }
        
        elif question_num == 6:
            # 解析目标体重
            answers["target_weight_kg"] = parse_target_weight(user_input)
            return {
                "success": True,
                "message": f"好的，目标体重 {answers['target_weight_kg']}kg ✅",
                "next_question": None,  # 问卷结束
                "answers": answers,
            }
        
        else:
            return {
                "success": False,
                "message": "未知问题编号",
                "next_question": None,
                "answers": answers,
            }
    
    except ValueError as e:
        return {
            "success": False,
            "message": f"格式错误：{str(e)}，请重新输入",
            "next_question": question_num,  # 留在当前问题
            "answers": answers,
        }


# ============ 完整问卷流程 ============
def run_full_questionnaire() -> dict:
    """
    运行完整问卷流程（命令行版本）
    返回用户档案
    """
    print(QUESTIONNAIRE)
    
    answers = {}
    
    # Q1: 身高体重
    print("\n📝 Q1: 你的身高和体重是多少？")
    while True:
        user_input = input("> ")
        result = process_answer(1, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # Q2: 年龄
    print("\n📝 Q2: 你的年龄是？")
    while True:
        user_input = input("> ")
        result = process_answer(2, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # Q3: 性别
    print("\n📝 Q3: 你的性别是？")
    while True:
        user_input = input("> ")
        result = process_answer(3, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # Q4: 运动量
    print("\n📝 Q4: 你平时运动多吗？")
    while True:
        user_input = input("> ")
        result = process_answer(4, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # Q5: 目标
    print("\n📝 Q5: 你现在的目标是什么？")
    while True:
        user_input = input("> ")
        result = process_answer(5, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # Q6: 目标体重
    print("\n📝 Q6: 你的目标体重是多少？（单位：kg）")
    while True:
        user_input = input("> ")
        result = process_answer(6, user_input, answers)
        print(result["message"])
        if result["success"]:
            answers = result["answers"]
            break
        print("请重新输入...")
    
    # 创建档案
    profile = create_user_profile(answers)
    
    print("\n" + "=" * 40)
    print("🎉 问卷完成！正在保存...")
    
    if save_profile(profile):
        print("✅ 用户档案已保存")
    else:
        print("❌ 保存失败")
    
    return profile


# ============ CLI 入口 ============
if __name__ == "__main__":
    # 检查是否已初始化
    if is_profile_initialized():
        print("用户档案已存在，无需重新初始化")
        profile = load_profile()
        print(json.dumps(profile, ensure_ascii=False, indent=2))
    else:
        profile = run_full_questionnaire()
        
        # 触发计算
        print("\n正在计算营养指标...")
        from nutrition_calculator import calculate_all, format_profile_summary, update_user_profile
        
        calculated = calculate_all(profile)
        profile["calculated"] = calculated
        update_user_profile(calculated)
        
        print("\n" + format_profile_summary(profile))
