#!/usr/bin/env python3
"""
nutrition_calculator.py - 核心营养计算模块
body-shape-manager

更新日志 (2026-04-01):
- 活动系数调整: very_active 1.725→1.55 (更符合每周4-5次运动的实际情况)
- 增肌盈余调整: +400→+250 (精益增肌标准)
- 脂肪计算调整: 热量占比→0.9g/kg体重 (更科学)
"""

import json
import math
from pathlib import Path

# ============ 路径配置 ============
SKILL_DIR = Path(__file__).parent.parent
USER_PROFILE_PATH = SKILL_DIR / "references" / "user_profile.json"

# ============ 活动系数映射 ============
# 参考: Harris-Benedict, Mifflin-St Jeor 等标准公式
# 修正: very_active 从 1.725 调整为 1.55，更适合每周4-5次运动
ACTIVITY_COEFFICIENTS = {
    "sedentary": 1.2,           # A: 几乎不运动，上班坐着为主
    "lightly_active": 1.375,    # B: 偶尔散步或轻度活动
    "moderately_active": 1.55,  # C: 每周2-3次运动
    "very_active": 1.55,        # D: 每周4-5次运动 (原1.725偏高,调整为1.55)
    "extra_active": 1.9,        # E: 每天高强度运动，健身爱好者
}

# ============ BMR 计算 (Mifflin-St Jeor) ============
def calculate_bmr(weight_kg: float, height_cm: float, age: int, gender: str) -> float:
    """
    计算基础代谢率 (Mifflin-St Jeor 公式，最常用标准)
    男性: BMR = 88.362 + (13.397 × 体重kg) + (4.799 × 身高cm) - (5.677 × 年龄)
    女性: BMR = 447.593 + (9.247 × 体重kg) + (3.098 × 身高cm) - (4.330 × 年龄)
    """
    if gender == "male":
        bmr = 88.362 + (13.397 * weight_kg) + (4.799 * height_cm) - (5.677 * age)
    else:
        bmr = 447.593 + (9.247 * weight_kg) + (3.098 * height_cm) - (4.330 * age)
    return round(bmr, 1)


def calculate_tdee(bmr: float, activity_level: str) -> float:
    """
    计算每日总热量消耗
    TDEE = BMR × 活动系数
    """
    coefficient = ACTIVITY_COEFFICIENTS.get(activity_level, 1.55)
    return round(bmr * coefficient, 1)


# ============ 目标热量计算 ============
def calculate_daily_target(tdee: float, goal_type: str) -> float:
    """
    计算每日目标热量
    - 减脂(cut): TDEE - 500 ~ 750 (保守取500)
    - 增肌(bulk): TDEE + 250 ~ 350 (精益增肌取300，更新为250)
    - 维持(maintain): TDEE
    """
    if goal_type == "cut":
        return round(tdee - 500, 1)  # 保守减脂，避免代谢受损
    elif goal_type == "bulk":
        return round(tdee + 250, 1)  # 精益增肌，避免过多脂肪堆积
    else:  # maintain
        return round(tdee, 1)


# ============ 营养素分配计算 (差异化算法 v2) ============
def calculate_macros(daily_calorie_target: float, goal_type: str, current_weight_kg: float, target_weight_kg: float = None) -> dict:
    """
    根据目标类型差异化计算营养素分配
    
    运动营养学原则:
    1. 蛋白质: 减脂>增肌>维持 (减脂期热量 deficit 下需优先保护肌肉)
    2. 脂肪: 最低健康限0.6g/kg，减脂期取下限，增肌/维持取中等
    3. 碳水: 剩余热量自然填充，增肌期高、减脂期低
    
    参数标准 (基于当前体重):
    | 目标   | 蛋白质    | 脂肪      | 碳水       |
    |--------|-----------|-----------|------------|
    | 减脂   | 2.2g/kg   | 0.7g/kg   | 剩余热量   |
    | 增肌   | 1.8g/kg   | 0.9g/kg   | 剩余热量   |
    | 维持   | 1.6g/kg   | 0.8g/kg   | 剩余热量   |
    """
    if target_weight_kg is None:
        target_weight_kg = current_weight_kg
    
    # ===== 蛋白质 (根据目标差异化) =====
    if goal_type == "cut":
        protein_multiplier = 2.2  # 减脂期:最高蛋白防肌肉流失
    elif goal_type == "bulk":
        protein_multiplier = 1.8  # 增肌期:中高蛋白(热量盈余时合成效率高)
    else:  # maintain
        protein_multiplier = 1.6  # 维持期:基础蛋白需求
    
    protein_g = round(protein_multiplier * current_weight_kg, 1)
    protein_calories = protein_g * 4

    # ===== 脂肪 (最低健康限 + 目标调整) =====
    if goal_type == "cut":
        fat_multiplier = 0.7  # 减脂:0.7g/kg (最低健康限，省热量给碳水维持训练)
    elif goal_type == "bulk":
        fat_multiplier = 0.9  # 增肌:0.9g/kg (支持睾酮合成)
    else:  # maintain
        fat_multiplier = 0.8  # 维持:0.8g/kg (平衡)
    
    fat_g = round(fat_multiplier * current_weight_kg, 1)
    fat_calories = fat_g * 9

    # ===== 碳水 (剩余热量自然分配) =====
    carbs_calories = daily_calorie_target - protein_calories - fat_calories
    carbs_g = round(carbs_calories / 4, 1)

    return {
        "protein_g": protein_g,
        "protein_calories": protein_calories,
        "carbs_g": carbs_g,
        "carbs_calories": carbs_calories,
        "fat_g": fat_g,
        "fat_calories": fat_calories,
    }


# ============ 目标分段拆解算法 ============
def calculate_goal_stages(current_weight: float, target_weight: float, goal_type: str) -> list:
    """
    根据目标体重差自动拆解分段计划
    规则：
    - 每周健康减重上限: 0.5kg (减脂) / 0.25kg (增肌，偏保守)
    - 每阶段目标差值 > 5kg 时，自动拆分
    """
    if goal_type == "maintain":
        return [{
            "stage": 1,
            "start_weight": current_weight,
            "end_weight": target_weight,
            "change_kg": 0,
            "weekly_rate_kg": 0,
            "estimated_weeks": 0,
        }]

    # 确定方向和速度
    weight_diff = abs(current_weight - target_weight)
    if goal_type == "cut":
        max_weekly_rate = 0.5  # 健康减重
        stage_threshold = 5.0
    else:  # bulk 增肌
        max_weekly_rate = 0.25  # 保守增肌速度，避免过多脂肪
        stage_threshold = 8.0

    # 估算总周数
    total_weeks = round(weight_diff / max_weekly_rate, 1)

    # 判断是否需要分段
    stages = []
    if weight_diff <= stage_threshold:
        stages.append({
            "stage": 1,
            "start_weight": current_weight,
            "end_weight": target_weight,
            "change_kg": round(weight_diff, 1),
            "weekly_rate_kg": max_weekly_rate,
            "estimated_weeks": total_weeks,
        })
    else:
        # 需要分段
        mid_weight = (current_weight + target_weight) / 2
        stage1_weeks = round(abs(mid_weight - current_weight) / max_weekly_rate, 1)
        stage2_weeks = round(abs(target_weight - mid_weight) / max_weekly_rate, 1)
        
        stages.append({
            "stage": 1,
            "start_weight": current_weight,
            "end_weight": round(mid_weight, 1),
            "change_kg": round(abs(mid_weight - current_weight), 1),
            "weekly_rate_kg": max_weekly_rate,
            "estimated_weeks": stage1_weeks,
        })
        stages.append({
            "stage": 2,
            "start_weight": round(mid_weight, 1),
            "end_weight": target_weight,
            "change_kg": round(abs(target_weight - mid_weight), 1),
            "weekly_rate_kg": max_weekly_rate,
            "estimated_weeks": stage2_weeks,
        })

    return stages


# ============ 综合计算函数 ============
def calculate_all(user_data: dict) -> dict:
    """
    综合计算所有营养指标
    输入用户数据，返回完整计算结果
    """
    basic = user_data["basic_info"]
    goal = user_data["goal"]

    # 基础计算
    bmr = calculate_bmr(
        weight_kg=basic["weight_kg"],
        height_cm=basic["height_cm"],
        age=basic["age"],
        gender=basic["gender"]
    )
    tdee = calculate_tdee(bmr, basic["activity_level"])
    
    # 目标计算
    target_weight = goal.get("target_weight_kg", basic["weight_kg"])
    daily_target = calculate_daily_target(tdee, goal["type"])
    
    # 营养素分配 (传入当前体重和目标体重)
    macros = calculate_macros(daily_target, goal["type"], basic["weight_kg"], target_weight)
    
    # 目标分段
    stages = calculate_goal_stages(basic["weight_kg"], target_weight, goal["type"])

    return {
        "bmr": bmr,
        "tdee": tdee,
        "daily_calorie_target": daily_target,
        "protein_g": macros["protein_g"],
        "carbs_g": macros["carbs_g"],
        "fat_g": macros["fat_g"],
        "goal_stages": stages,
    }


# ============ 用户档案更新 ============
def update_user_profile(calculated_data: dict) -> dict:
    """
    将计算结果更新到用户档案
    """
    if not USER_PROFILE_PATH.exists():
        return {"error": "用户档案不存在"}
    
    with open(USER_PROFILE_PATH, "r", encoding="utf-8") as f:
        profile = json.load(f)
    
    # 更新 calculated 字段
    profile["calculated"] = {
        "bmr": calculated_data["bmr"],
        "tdee": calculated_data["tdee"],
        "daily_calorie_target": calculated_data["daily_calorie_target"],
        "protein_g": calculated_data["protein_g"],
        "carbs_g": calculated_data["carbs_g"],
        "fat_g": calculated_data["fat_g"],
        "goal_stages": calculated_data["goal_stages"],
    }
    
    # 保存
    with open(USER_PROFILE_PATH, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    
    return profile


# ============ 格式化输出 ============
def format_profile_summary(profile: dict) -> str:
    """
    格式化用户档案摘要，用于展示
    """
    basic = profile["basic_info"]
    goal = profile["goal"]
    calc = profile["calculated"]
    
    goal_names = {"cut": "减脂", "bulk": "增肌", "maintain": "维持"}
    activity_names = {
        "sedentary": "几乎不运动",
        "lightly_active": "偶尔散步",
        "moderately_active": "每周2-3次运动",
        "very_active": "每周4-5次运动",
        "extra_active": "每天运动",
    }
    
    # 基础信息
    lines = [
        "=" * 40,
        "🍄 形体管理 - 个人档案",
        "=" * 40,
        "",
        "📋 基础信息",
        f"  身高: {basic['height_cm']}cm",
        f"  体重: {basic['weight_kg']}kg",
        f"  年龄: {basic['age']}岁",
        f"  性别: {'男' if basic['gender'] == 'male' else '女'}",
        f"  活动水平: {activity_names.get(basic['activity_level'], '未知')}",
        "",
        "🎯 目标",
        f"  类型: {goal_names.get(goal['type'], '未知')}",
        f"  目标体重: {goal.get('target_weight_kg', basic['weight_kg'])}kg",
        "",
        "📊 计算结果",
        f"  基础代谢(BMR): {calc['bmr']} kcal",
        f"  每日总消耗(TDEE): {calc['tdee']} kcal",
        f"  每日目标热量: {calc['daily_calorie_target']} kcal",
        "",
        "🥩 每日营养素目标",
        f"  蛋白质: {calc['protein_g']}g",
        f"  碳水: {calc['carbs_g']}g",
        f"  脂肪: {calc['fat_g']}g",
    ]
    
    # 目标分段
    if calc.get("goal_stages"):
        lines.append("")
        lines.append("📅 目标分段计划")
        for stage in calc["goal_stages"]:
            lines.append(f"  第{stage['stage']}阶段: {stage['start_weight']}kg → {stage['end_weight']}kg")
            lines.append(f"    变化: {stage['change_kg']}kg | 每周: {stage['weekly_rate_kg']}kg | 预计: {stage['estimated_weeks']}周")
            if stage.get("note"):
                lines.append(f"    ({stage['note']})")
    
    lines.append("=" * 40)
    
    return "\n".join(lines)


# ============ CLI 测试 ============
if __name__ == "__main__":
    # 示例调用
    from init_profile import is_profile_initialized
    
    if not is_profile_initialized():
        print("⚠️ 请先通过 init_profile.py 完成用户初始化")
    else:
        from diet_logger import load_today_log, format_log_summary
        log = load_today_log()
        print(format_log_summary(log))
