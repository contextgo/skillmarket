#!/usr/bin/env python3
"""
diet_logger.py - 饮食记录模块
body-shape-manager
日志读写、按餐次记录、累计汇总、智能建议
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Optional

# ============ 路径配置 ============
SKILL_DIR = Path(__file__).parent.parent
MEMORY_DIR = SKILL_DIR / "memory"
FOOD_DB_PATH = SKILL_DIR / "references" / "food_database.json"
USER_PROFILE_PATH = SKILL_DIR / "references" / "user_profile.json"

# ============ 餐次定义 ============
MEAL_TYPES = {
    "早餐": "breakfast",
    "午餐": "lunch", 
    "晚餐": "dinner",
    "加餐": "snack",
}

MEAL_ORDER = ["breakfast", "lunch", "dinner", "snack"]
MEAL_DISPLAY = {v: k for k, v in MEAL_TYPES.items()}

# ============ 加载数据 ============
def load_food_database() -> dict:
    """加载食物数据库"""
    with open(FOOD_DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def load_user_profile() -> dict:
    """加载用户档案"""
    with open(USER_PROFILE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


# ============ 食物查询 ============
def search_food(query: str, food_db: dict = None) -> list:
    """
    搜索食物
    返回匹配的列表，每项包含名称和营养信息
    """
    if food_db is None:
        food_db = load_food_database()
    
    results = []
    query_lower = query.lower()
    
    for category, foods in food_db["categories"].items():
        for name, nutrition in foods.items():
            if query_lower in name.lower():
                results.append({
                    "name": name,
                    "category": category,
                    "calories": nutrition["calories"],
                    "protein": nutrition["protein"],
                    "carbs": nutrition["carbs"],
                    "fat": nutrition["fat"],
                })
    
    return results


def get_food_nutrition(food_name: str, portion_g: float, food_db: dict = None) -> dict:
    """
    获取食物营养信息（按份量计算）
    返回每100g的营养 × 份量
    支持模糊匹配
    """
    if food_db is None:
        food_db = load_food_database()
    
    # 精确匹配
    for category, foods in food_db["categories"].items():
        if food_name in foods:
            nutrition = foods[food_name]
            factor = portion_g / 100.0
            return {
                "name": food_name,
                "portion_g": portion_g,
                "calories": round(nutrition["calories"] * factor, 1),
                "protein": round(nutrition["protein"] * factor, 1),
                "carbs": round(nutrition["carbs"] * factor, 1),
                "fat": round(nutrition["fat"] * factor, 1),
            }
    
    # 模糊匹配：搜索最接近的食物
    results = search_food(food_name, food_db)
    if results:
        best_match = results[0]
        nutrition = None
        for category, foods in food_db["categories"].items():
            if best_match["name"] in foods:
                nutrition = foods[best_match["name"]]
                break
        if nutrition:
            factor = portion_g / 100.0
            return {
                "name": best_match["name"],
                "portion_g": portion_g,
                "calories": round(nutrition["calories"] * factor, 1),
                "protein": round(nutrition["protein"] * factor, 1),
                "carbs": round(nutrition["carbs"] * factor, 1),
                "fat": round(nutrition["fat"] * factor, 1),
            }
    
    return None


def parse_food_input(user_input: str) -> list:
    """
    解析用户输入的食物记录
    支持格式：
    - "米饭 200g"
    - "米饭200g"
    - "米饭(200g)"
    - "鸡胸肉 150g"
    返回: [{"name": "xxx", "portion_g": xxx}, ...]
    """
    # 匹配 食物名 + 数字 + g
    pattern = r'([^\d\s]+?)\s*(\d+(?:\.\d+)?)\s*g?'
    
    matches = re.findall(pattern, user_input)
    results = []
    
    for name, amount in matches:
        name = name.strip().replace("(", "").replace(")", "")
        try:
            portion = float(amount)
            if portion > 0 and portion < 5000:  # 合理范围
                results.append({"name": name, "portion_g": portion})
        except ValueError:
            continue
    
    return results


# ============ 日志文件操作 ============
def get_today_log_path() -> Path:
    """获取今日日志文件路径"""
    today = datetime.now().strftime("%Y-%m-%d")
    return MEMORY_DIR / f"{today}.md"


def load_today_log() -> dict:
    """
    加载今日饮食日志
    返回数据结构
    """
    log_path = get_today_log_path()
    
    if not log_path.exists():
        return create_empty_log()
    
    # 简单解析markdown日志
    with open(log_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    return parse_log_content(content)


def create_empty_log() -> dict:
    """创建空日志结构"""
    return {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "meals": {
            "breakfast": [],
            "lunch": [],
            "dinner": [],
            "snack": [],
        },
        "totals": {
            "calories": 0,
            "protein": 0,
            "carbs": 0,
            "fat": 0,
        }
    }


def parse_log_content(content: str) -> dict:
    """
    解析日志文件内容
    支持表格格式: | 食物 | 份量 | 热量 | 蛋白质 | 碳水 | 脂肪 |
    """
    log = create_empty_log()
    
    if not content.strip():
        return log
    
    # 尝试解析各餐次
    current_meal = None
    lines = content.split("\n")
    
    for line in lines:
        line = line.strip()
        
        # 检测餐次标题
        for meal_display, meal_key in MEAL_TYPES.items():
            if f"## {meal_display}" in line:
                current_meal = meal_key
                break
        
        # 解析表格食物行: | 食物 | 份量 | 热量 | 蛋白质 | 碳水 | 脂肪 |
        if current_meal and line.startswith("|"):
            # 跳过表头和分隔符
            if "热量" in line or "------" in line:
                continue
            
            # 解析表格行
            parts = [p.strip() for p in line.split("|")]
            # parts: ['', '食物', '份量', '热量', '蛋白质', '碳水', '脂肪', '']
            if len(parts) >= 7:
                try:
                    name = parts[1]
                    portion_str = parts[2].replace("g", "")
                    cal_str = parts[3].replace("kcal", "")
                    protein_str = parts[4].replace("g", "")
                    carbs_str = parts[5].replace("g", "")
                    fat_str = parts[6].replace("g", "")
                    
                    # 跳过标题行
                    if name == "食物" or not portion_str:
                        continue
                    
                    # 处理 None 值
                    ai_estimated = (cal_str == "None")
                    
                    food_entry = {
                        "name": name,
                        "portion_g": float(portion_str),
                        "calories": None if ai_estimated else float(cal_str),
                        "protein": None if protein_str == "None" else float(protein_str),
                        "carbs": None if carbs_str == "None" else float(carbs_str),
                        "fat": None if fat_str == "None" else float(fat_str),
                        "ai_estimated": ai_estimated,
                    }
                    log["meals"][current_meal].append(food_entry)
                except (ValueError, IndexError):
                    continue
    
    # 重新计算总量
    log["totals"] = calculate_totals(log)
    
    return log


def calculate_totals(log: dict) -> dict:
    """计算日志中的营养总量，忽略ai_estimated的占位项"""
    totals = {"calories": 0, "protein": 0, "carbs": 0, "fat": 0}
    
    for meal_key, foods in log["meals"].items():
        for food in foods:
            # 跳过待AI估算的占位项
            if food.get("ai_estimated"):
                continue
            totals["calories"] += food.get("calories", 0) or 0
            totals["protein"] += food.get("protein", 0) or 0
            totals["carbs"] += food.get("carbs", 0) or 0
            totals["fat"] += food.get("fat", 0) or 0
    
    # 保留1位小数
    for key in totals:
        totals[key] = round(totals[key], 1)
    
    return totals


# ============ 保存日志 ============
def save_log(log: dict) -> bool:
    """保存日志到文件"""
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    
    log_path = get_today_log_path()
    content = format_log_content(log)
    
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(content)
    
    return True


def format_log_content(log: dict) -> str:
    """
    格式化日志内容为markdown
    """
    lines = [
        f"# 🍄 饮食日志 - {log['date']}",
        "",
        "## 📊 累计汇总",
        "| 指标 | 今日摄入 | 目标 | 进度 |",
        "|------|----------|------|------|",
    ]
    
    # 获取目标
    try:
        profile = load_user_profile()
        targets = profile.get("calculated", {})
        target_cal = targets.get("daily_calorie_target", 0)
        target_protein = targets.get("protein_g", 0)
        target_carbs = targets.get("carbs_g", 0)
        target_fat = targets.get("fat_g", 0)
    except:
        target_cal = target_protein = target_carbs = target_fat = 0
    
    # 计算进度百分比
    def progress_bar(current, target):
        if target <= 0:
            return "N/A"
        pct = min(100, current / target * 100)
        bar_len = 10
        filled = int(bar_len * pct / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        return f"{bar} {pct:.0f}%"
    
    lines.append(f"| 热量 | {log['totals']['calories']} kcal | {target_cal} kcal | {progress_bar(log['totals']['calories'], target_cal)} |")
    lines.append(f"| 蛋白质 | {log['totals']['protein']}g | {target_protein}g | {progress_bar(log['totals']['protein'], target_protein)} |")
    lines.append(f"| 碳水 | {log['totals']['carbs']}g | {target_carbs}g | {progress_bar(log['totals']['carbs'], target_carbs)} |")
    lines.append(f"| 脂肪 | {log['totals']['fat']}g | {target_fat}g | {progress_bar(log['totals']['fat'], target_fat)} |")
    lines.append("")
    
    # 各餐次
    for meal_key in MEAL_ORDER:
        meal_display = MEAL_DISPLAY.get(meal_key, meal_key)
        foods = log["meals"].get(meal_key, [])
        
        lines.append(f"## {meal_display}")
        
        if not foods:
            lines.append("_（未记录）_")
        else:
            lines.append("| 食物 | 份量 | 热量 | 蛋白质 | 碳水 | 脂肪 |")
            lines.append("|------|------|------|--------|------|------|")
            
            for food in foods:
                lines.append(f"| {food['name']} | {food['portion_g']}g | {food['calories']}kcal | {food['protein']}g | {food['carbs']}g | {food['fat']}g |")
        
        lines.append("")
    
    return "\n".join(lines)


# ============ 添加食物记录 ============
def add_food_entry(meal_type: str, food_name: str, portion_g: float) -> dict:
    """
    添加食物记录
    返回: 成功信息 + 更新后的日志
    """
    # 获取营养信息
    food_db = load_food_database()
    nutrition = get_food_nutrition(food_name, portion_g, food_db)
    if nutrition is None:
        # 数据库没有，标记为待AI估算
        nutrition = {
            "name": food_name,
            "portion_g": portion_g,
            "calories": None,  # AI将根据常识估算
            "protein": None,
            "carbs": None,
            "fat": None,
            "ai_estimated": True
        }
    
    # 加载/创建日志
    log = load_today_log()
    
    # 转换餐次
    if meal_type in MEAL_TYPES:
        meal_key = MEAL_TYPES[meal_type]
    else:
        # 尝试模糊匹配
        meal_key = None
        for display, key in MEAL_TYPES.items():
            if display in meal_type or key in meal_type:
                meal_key = key
                break
        
        if meal_key is None:
            return {
                "success": False,
                "message": f"未识别餐次「{meal_type}」，请输入：早餐/午餐/晚餐/加餐",
                "log": None,
            }
    
    # 添加记录
    log["meals"][meal_key].append(nutrition)
    
    # 重新计算总量
    log["totals"] = calculate_totals(log)
    
    # 保存
    save_log(log)
    
    # 格式化营养值显示
    if nutrition.get("ai_estimated"):
        cal_display = "待AI估算"
    else:
        cal_display = f"{nutrition['calories']}kcal"
    
    return {
        "success": True,
        "message": f"已记录「{nutrition['name']}」{nutrition['portion_g']}g → {cal_display}",
        "nutrition": nutrition,
        "log": log,
    }


# ============ 智能建议 ============
def generate_advice(log: dict) -> str:
    """
    根据今日饮食记录生成智能建议
    """
    try:
        profile = load_user_profile()
        if not profile.get("calculated"):
            return "⚠️ 请先完成用户档案初始化，再使用饮食建议功能"
    except:
        return "⚠️ 请先完成用户档案初始化，再使用饮食建议功能"
    
    goal = profile.get("goal", {})
    goal_type = goal.get("type", "maintain")
    targets = profile.get("calculated", {})
    
    target_cal = targets.get("daily_calorie_target", 2000)
    target_protein = targets.get("protein_g", 150)
    target_carbs = targets.get("carbs_g", 200)
    target_fat = targets.get("fat_g", 65)
    
    totals = log["totals"]
    cal_diff = totals["calories"] - target_cal
    protein_diff = totals["protein"] - target_protein
    carbs_diff = totals["carbs"] - target_carbs
    fat_diff = totals["fat"] - target_fat
    
    advices = []
    
    if goal_type == "cut":
        # 减脂建议
        if cal_diff > 300:
            advices.append(f"⚠️ 热量超标 {abs(cal_diff):.0f}kcal，注意控制！")
        elif cal_diff < -500:
            advices.append(f"⚠️ 热量缺口过大({abs(cal_diff):.0f}kcal)，可能影响代谢")
        
        if protein_diff < -20:
            advices.append(f"🥩 蛋白质还差 {abs(protein_diff):.0f}g，建议加餐补充")
        
        if carbs_diff > 100:
            advices.append(f"🍚 碳水摄入较多，建议减少主食")
        
        if fat_diff > 15:
            advices.append(f"🫙 脂肪摄入偏高，注意控制油脂")
    
    elif goal_type == "bulk":
        # 增肌建议
        if cal_diff < -300:
            advices.append(f"⚠️ 热量缺口 {abs(cal_diff):.0f}kcal，增肌需要热量盈余！")
        
        if protein_diff < -20:
            advices.append(f"🥩 蛋白质还差 {abs(protein_diff):.0f}g，肌肉生长需要蛋白")
        
        if carbs_diff < -50:
            advices.append(f"🍚 碳水不足，建议加餐补充能量支持训练")
    
    else:
        # 维持建议
        if abs(cal_diff) > 500:
            advices.append(f"⚠️ 热量偏离目标较多({cal_diff:+.0f}kcal)，注意均衡")
    
    if not advices:
        advices.append("✅ 今天饮食控制得不错，继续保持！")
    
    return "\n".join(advices)


def format_log_summary(log: dict) -> str:
    """
    格式化日志摘要（简短版，用于即时反馈）
    """
    try:
        profile = load_user_profile()
        targets = profile.get("calculated", {})
        target_cal = targets.get("daily_calorie_target", 0)
    except:
        target_cal = 0
    
    totals = log["totals"]
    remaining = target_cal - totals["calories"]
    
    lines = [
        f"📊 今日汇总 ({log['date']})",
        f"  热量: {totals['calories']} / {target_cal} kcal",
        f"  剩余: {remaining:.0f} kcal",
        f"  蛋白质: {totals['protein']}g | 碳水: {totals['carbs']}g | 脂肪: {totals['fat']}g",
    ]
    
    # 各餐次简要
    for meal_key in MEAL_ORDER:
        foods = log["meals"].get(meal_key, [])
        if foods:
            meal_cal = sum((f.get("calories") or 0) for f in foods)
            meal_display = MEAL_DISPLAY.get(meal_key, meal_key)
            food_names = "、".join([f["name"] for f in foods[:3]])
            if len(foods) > 3:
                food_names += f"（+{len(foods)-3}种）"
            lines.append(f"  {meal_display}: {food_names} ({meal_cal}kcal)")
    
    return "\n".join(lines)


# ============ CLI 测试 ============
if __name__ == "__main__":
    print("🔧 diet_logger.py - 饮食记录模块测试")
    print()
    
    # 测试食物搜索
    print("=== 测试食物搜索 ===")
    results = search_food("鸡胸")
    print(f"搜索「鸡胸」: {len(results)} 个结果")
    for r in results[:3]:
        print(f"  - {r['name']}: {r['calories']}kcal/100g")
    
    # 测试解析输入
    print("\n=== 测试输入解析 ===")
    tests = ["米饭 200g", "鸡胸肉150g", "西兰花 100g, 番茄 50g"]
    for t in tests:
        parsed = parse_food_input(t)
        print(f"「{t}」 -> {parsed}")
    
    # 测试添加食物
    print("\n=== 测试添加食物 ===")
    result = add_food_entry("午餐", "鸡胸肉", 150)
    print(f"添加结果: {result['message']}")
    
    # 显示日志摘要
    log = load_today_log()
    print("\n" + format_log_summary(log))
    
    # 生成建议
    print("\n=== 智能建议 ===")
    print(generate_advice(log))
