#!/usr/bin/env python3
"""
Test Case Generator — Generate test cases from requirements spec

Usage:
    gen_test_cases.py --spec <requirements.md> --output <dir> [--coverage-level standard]

Coverage levels:
    minimal   — Normal paths + critical exceptions only
    standard  — Normal + boundary + main exceptions (default)
    thorough  — All paths + compatibility + performance

Output: Individual test case markdown files in the output directory.
"""

import argparse
import re
import json
from datetime import datetime, timezone
from pathlib import Path


def extract_requirements(content: str) -> list[dict]:
    """Extract FR requirements from spec."""
    requirements = []
    req_pattern = re.compile(r"^###\s+(FR-\d+)[：:\s—-]*(.*)", re.MULTILINE)
    parts = req_pattern.split(content)

    for i in range(1, len(parts), 3):
        if i + 2 < len(parts):
            req_id = parts[i].strip()
            title = parts[i + 1].strip()
            body = parts[i + 2].strip()

            # Extract acceptance criteria
            ac_lines = []
            in_ac = False
            for line in body.split("\n"):
                if re.match(r"验收标准|Acceptance Criteria", line):
                    in_ac = True
                    continue
                if in_ac and line.startswith("###"):
                    break
                if in_ac and line.strip():
                    ac_lines.append(line.strip())

            # Extract priority
            pri_match = re.search(r"优先级[：:]*\s*(P[012])|Priority[：:]*\s*(P[012])", body, re.IGNORECASE)
            priority = pri_match.group(1) or pri_match.group(2) if pri_match else "P1"

            # Detect scenario type
            has_when = bool(re.search(r"\bwhen\b", body, re.IGNORECASE))
            has_if = bool(re.search(r"\bif\b.*\bshall\b", body, re.IGNORECASE))
            has_while = bool(re.search(r"\bwhile\b", body, re.IGNORECASE))

            requirements.append({
                "id": req_id,
                "title": title,
                "body": body,
                "acceptanceCriteria": ac_lines,
                "priority": priority,
                "hasWhen": has_when,
                "hasIf": has_if,
                "hasWhile": has_while,
            })

    return requirements


def generate_test_cases(requirement: dict, coverage_level: str) -> list[dict]:
    """Generate test cases for a single requirement."""
    cases = []
    tc_counter = [0]

    def next_tc_id():
        tc_counter[0] += 1
        return f"TC-{requirement['id'].replace('FR-', '')}{tc_counter[0]:02d}"

    # 1. Normal path (from When...shall criteria)
    for i, ac in enumerate(requirement["acceptanceCriteria"]):
        if re.search(r"\bwhen\b.*\bshall\b", ac, re.IGNORECASE):
            cases.append({
                "id": next_tc_id(),
                "title": f"{requirement['title']} — 正常流程 {i + 1}",
                "reqId": requirement["id"],
                "priority": requirement["priority"],
                "type": "功能",
                "acceptanceCriteria": ac,
                "category": "normal",
            })

    # 2. Exception path (from If...shall criteria)
    for i, ac in enumerate(requirement["acceptanceCriteria"]):
        if re.search(r"\bif\b.*\bshall\b", ac, re.IGNORECASE):
            cases.append({
                "id": next_tc_id(),
                "title": f"{requirement['title']} — 异常处理 {i + 1}",
                "reqId": requirement["id"],
                "priority": requirement["priority"],
                "type": "异常",
                "acceptanceCriteria": ac,
                "category": "exception",
            })

    # 3. Boundary cases (standard+)
    if coverage_level in ("standard", "thorough"):
        # Generate boundary cases based on common patterns
        boundary_patterns = [
            ("空列表/空输入", "空值", "When input is empty, the system shall handle gracefully"),
            ("最大值/超长输入", "边界", "When input exceeds maximum, the system shall truncate or reject"),
            ("特殊字符输入", "边界", "When input contains special characters, the system shall sanitize"),
        ]
        for desc, tc_type, ac in boundary_patterns:
            cases.append({
                "id": next_tc_id(),
                "title": f"{requirement['title']} — {desc}",
                "reqId": requirement["id"],
                "priority": "P1",
                "type": tc_type,
                "acceptanceCriteria": ac,
                "category": "boundary",
            })

    # 4. Compatibility & Performance (thorough only)
    if coverage_level == "thorough":
        cases.append({
            "id": next_tc_id(),
            "title": f"{requirement['title']} — 兼容性测试",
            "reqId": requirement["id"],
            "priority": "P2",
            "type": "兼容性",
            "acceptanceCriteria": "Feature works on iOS and Android, WeChat >= 7.0",
            "category": "compatibility",
        })
        cases.append({
            "id": next_tc_id(),
            "title": f"{requirement['title']} — 性能测试",
            "reqId": requirement["id"],
            "priority": "P2",
            "type": "性能",
            "acceptanceCriteria": "Operation completes within performance budget",
            "category": "performance",
        })

    # Ensure at least one test case per requirement
    if not cases:
        cases.append({
            "id": next_tc_id(),
            "title": f"{requirement['title']} — 基本验证",
            "reqId": requirement["id"],
            "priority": requirement["priority"],
            "type": "功能",
            "acceptanceCriteria": requirement["acceptanceCriteria"][0] if requirement["acceptanceCriteria"] else "Feature works as described",
            "category": "normal",
        })

    return cases


def format_test_case_md(tc: dict) -> str:
    """Format a test case as markdown."""
    return f"""# {tc['id']}: {tc['title']}

**关联需求:** {tc['reqId']}
**优先级:** {tc['priority']}
**类型:** {tc['type']}

## 前置条件
1. [根据需求补充]

## 测试步骤
1. [根据验收标准编写步骤]

## 预期结果
- {tc['acceptanceCriteria']}

## 测试数据
- [参考 tests/test-data/ 中的数据集]
"""


def main():
    parser = argparse.ArgumentParser(description="Generate test cases from requirements spec")
    parser.add_argument("--spec", required=True, help="Path to requirements.md")
    parser.add_argument("--output", required=True, help="Output directory for test case files")
    parser.add_argument("--coverage-level", default="standard",
                       choices=["minimal", "standard", "thorough"],
                       help="Coverage level (default: standard)")
    args = parser.parse_args()

    spec_path = Path(args.spec)
    output_dir = Path(args.output)

    if not spec_path.exists():
        print(f"[ERROR] Spec file not found: {spec_path}")
        raise SystemExit(1)

    output_dir.mkdir(parents=True, exist_ok=True)

    content = spec_path.read_text(encoding="utf-8")
    requirements = extract_requirements(content)

    if not requirements:
        print("[ERROR] No requirements found in spec")
        raise SystemExit(1)

    all_cases = []
    for req in requirements:
        cases = generate_test_cases(req, args.coverage_level)
        all_cases.extend(cases)

        # Write individual test case file
        for tc in cases:
            tc_file = output_dir / f"{tc['id'].lower()}.md"
            tc_file.write_text(format_test_case_md(tc), encoding="utf-8")

    # Write summary
    summary = {
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "specFile": str(spec_path),
        "coverageLevel": args.coverage_level,
        "requirementCount": len(requirements),
        "testCaseCount": len(all_cases),
        "byType": {},
        "byPriority": {},
    }

    for tc in all_cases:
        summary["byType"][tc["type"]] = summary["byType"].get(tc["type"], 0) + 1
        summary["byPriority"][tc["priority"]] = summary["byPriority"].get(tc["priority"], 0) + 1

    summary_file = output_dir / "_summary.json"
    summary_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"[OK] Generated {len(all_cases)} test cases from {len(requirements)} requirements")
    print(f"     Coverage level: {args.coverage_level}")
    print(f"     By type: {summary['byType']}")
    print(f"     By priority: {summary['byPriority']}")
    print(f"     Output: {output_dir}")


if __name__ == "__main__":
    main()
