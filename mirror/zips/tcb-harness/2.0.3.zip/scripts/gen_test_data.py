#!/usr/bin/env python3
"""
Test Data Generator — Generate mock test data from spec and data model

Usage:
    gen_test_data.py --spec <requirements.md> --output <dir> [--count 10]

Reads data model from design/service/data-model.md if available,
otherwise infers from requirements. Generates JSON mock data
for CloudBase NoSQL collections.
"""

import argparse
import json
import re
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any


def generate_id(prefix: str = "", index: int = 0) -> str:
    """Generate a deterministic mock ID."""
    raw = f"{prefix}_{index}_{datetime.now(timezone.utc).strftime('%Y%m%d')}"
    return hashlib.md5(raw.encode()).hexdigest()[:12]


def generate_mock_value(field_type: str, field_name: str, index: int = 0) -> Any:
    """Generate a mock value based on field type."""
    field_lower = field_name.lower()

    # Semantic inference from field name
    if "openid" in field_lower:
        return f"test_openid_{index:03d}"
    if "phone" in field_lower or "mobile" in field_lower:
        return f"138{index:08d}"
    if "email" in field_lower:
        return f"user{index}@test.com"
    if "nickname" in field_lower or "name" in field_lower:
        names = ["张三", "李四", "王五", "赵六", "测试用户"]
        return names[index % len(names)]
    if "avatar" in field_lower or "image" in field_lower or "pic" in field_lower:
        return f"cloud://test-env.xxx/{field_name}_{index}.png"
    if "price" in field_lower or "amount" in field_lower or "fee" in field_lower:
        return round(10 + (index * 37.7) % 990, 2)
    if "status" in field_lower:
        return ["created", "paid", "shipped", "completed"][index % 4]
    if "url" in field_lower or "link" in field_lower:
        return f"https://example.com/{field_name}/{index}"
    if "id" in field_lower and field_lower.endswith("id"):
        return f"{field_lower}_{index:03d}"

    # Type-based generation
    type_map = {
        "string": f"mock_{field_name}_{index}",
        "number": round(10 + index * 3.14, 2),
        "integer": index * 10 + 1,
        "boolean": index % 2 == 0,
        "date": (datetime.now(timezone.utc) - timedelta(days=index)).isoformat(),
        "array": [],
        "object": {},
    }

    return type_map.get(field_type.lower(), f"mock_{field_name}_{index}")


def parse_data_model(content: str) -> list[dict]:
    """Parse data model markdown into collection schemas."""
    collections = []
    # Match ## collection_name or ### collection_name
    coll_pattern = re.compile(r"^#{2,3}\s+(\w+)\s*(?:集合|collection)?", re.MULTILINE)
    parts = coll_pattern.split(content)

    for i in range(1, len(parts), 3):
        if i + 1 < len(parts):
            coll_name = parts[i].strip()
            body = parts[i + 1].strip() if i + 1 < len(parts) else ""

            # Parse fields from table
            fields = []
            for line in body.split("\n"):
                # Match markdown table rows: | field | type | ... |
                cells = [c.strip() for c in line.split("|") if c.strip()]
                if len(cells) >= 2 and cells[0] not in ("字段", "Field", "---"):
                    fields.append({
                        "name": cells[0],
                        "type": cells[1],
                        "required": "是" in cells[2] if len(cells) > 2 else True,
                    })

            collections.append({
                "name": coll_name,
                "fields": fields,
            })

    return collections


def infer_collections_from_requirements(content: str) -> list[dict]:
    """Infer basic collections from requirements when data model is not available."""
    collections = []

    # Common patterns in mini program requirements
    if re.search(r"用户|登录|个人|user|login|profile", content, re.IGNORECASE):
        collections.append({
            "name": "users",
            "fields": [
                {"name": "_id", "type": "string", "required": True},
                {"name": "openid", "type": "string", "required": True},
                {"name": "nickname", "type": "string", "required": False},
                {"name": "phone", "type": "string", "required": False},
                {"name": "avatar", "type": "string", "required": False},
                {"name": "createdAt", "type": "date", "required": True},
            ],
        })

    if re.search(r"订单|购买|支付|order|purchase|pay", content, re.IGNORECASE):
        collections.append({
            "name": "orders",
            "fields": [
                {"name": "_id", "type": "string", "required": True},
                {"name": "openid", "type": "string", "required": True},
                {"name": "items", "type": "array", "required": True},
                {"name": "totalAmount", "type": "number", "required": True},
                {"name": "status", "type": "string", "required": True},
                {"name": "createdAt", "type": "date", "required": True},
            ],
        })

    if re.search(r"商品|产品|product|goods|item", content, re.IGNORECASE):
        collections.append({
            "name": "products",
            "fields": [
                {"name": "_id", "type": "string", "required": True},
                {"name": "name", "type": "string", "required": True},
                {"name": "price", "type": "number", "required": True},
                {"name": "image", "type": "string", "required": False},
                {"name": "stock", "type": "integer", "required": True},
                {"name": "status", "type": "string", "required": True},
            ],
        })

    if not collections:
        # Default: generic data collection
        collections.append({
            "name": "records",
            "fields": [
                {"name": "_id", "type": "string", "required": True},
                {"name": "openid", "type": "string", "required": True},
                {"name": "data", "type": "object", "required": True},
                {"name": "createdAt", "type": "date", "required": True},
            ],
        })

    return collections


def generate_collection_data(collection: dict, count: int) -> list[dict]:
    """Generate mock data for a collection."""
    records = []
    for i in range(count):
        record = {}
        for field in collection["fields"]:
            if field["name"] == "_id":
                record["_id"] = generate_id(collection["name"], i)
            else:
                record[field["name"]] = generate_mock_value(field["type"], field["name"], i)
        records.append(record)
    return records


def generate_edge_cases(collection: dict) -> dict:
    """Generate edge case data for a collection."""
    edge_cases = {}

    # Empty values
    empty_record = {"_id": "edge_empty"}
    for field in collection["fields"]:
        if field["name"] != "_id":
            empty_record[field["name"]] = ""
    edge_cases["empty_values"] = empty_record

    # Extreme values
    extreme_record = {"_id": "edge_extreme"}
    for field in collection["fields"]:
        if field["name"] != "_id":
            if field["type"] == "string":
                extreme_record[field["name"]] = "A" * 1000  # Very long string
            elif field["type"] in ("number", "integer"):
                extreme_record[field["name"]] = 999999999
            elif field["type"] == "boolean":
                extreme_record[field["name"]] = True
            else:
                extreme_record[field["name"]] = None
    edge_cases["extreme_values"] = extreme_record

    # Special characters
    special_record = {"_id": "edge_special"}
    for field in collection["fields"]:
        if field["name"] != "_id" and field["type"] == "string":
            special_record[field["name"]] = "<script>alert('xss')</script> & \"quotes\" 'apostrophes'"
    edge_cases["special_characters"] = special_record

    return edge_cases


def main():
    parser = argparse.ArgumentParser(description="Generate mock test data for CloudBase NoSQL")
    parser.add_argument("--spec", required=True, help="Path to requirements.md")
    parser.add_argument("--output", required=True, help="Output directory for test data files")
    parser.add_argument("--count", type=int, default=10, help="Number of records per collection (default: 10)")
    args = parser.parse_args()

    spec_path = Path(args.spec)
    output_dir = Path(args.output)

    if not spec_path.exists():
        print(f"[ERROR] Spec file not found: {spec_path}")
        raise SystemExit(1)

    output_dir.mkdir(parents=True, exist_ok=True)

    content = spec_path.read_text(encoding="utf-8")

    # Try to read data model from design/service/data-model.md
    project_dir = spec_path.parent.parent.parent  # specs/xxx/ → project root
    data_model_path = project_dir / "design" / "service" / "data-model.md"

    if data_model_path.exists():
        dm_content = data_model_path.read_text(encoding="utf-8")
        collections = parse_data_model(dm_content)
        print(f"[OK] Loaded data model from {data_model_path}")
    else:
        collections = infer_collections_from_requirements(content)
        print(f"[OK] Inferred collections from requirements")

    # Generate data
    all_data = {}
    for coll in collections:
        records = generate_collection_data(coll, args.count)
        edge_cases = generate_edge_cases(coll)
        all_data[coll["name"]] = records

        # Write edge cases separately
        edge_file = output_dir / f"{coll['name']}_edge_cases.json"
        edge_file.write_text(json.dumps(edge_cases, indent=2, ensure_ascii=False), encoding="utf-8")

    # Add metadata
    all_data["_meta"] = {
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "specFile": str(spec_path),
        "recordCount": args.count,
        "collectionCount": len(collections),
        "collections": [c["name"] for c in collections],
    }

    # Write main mock data file
    output_file = output_dir / "mock-db.json"
    output_file.write_text(json.dumps(all_data, indent=2, ensure_ascii=False), encoding="utf-8")

    # Write mock users separately (commonly needed)
    if "users" in all_data:
        users_file = output_dir / "mock-users.json"
        users_data = {
            "users": all_data["users"],
            "_meta": all_data["_meta"],
        }
        users_file.write_text(json.dumps(users_data, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"[OK] Generated test data for {len(collections)} collection(s)")
    print(f"     Collections: {[c['name'] for c in collections]}")
    print(f"     Records per collection: {args.count}")
    print(f"     Edge cases: {len(collections)} file(s)")
    print(f"     Output: {output_dir}")


if __name__ == "__main__":
    main()
