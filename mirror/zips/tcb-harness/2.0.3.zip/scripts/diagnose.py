#!/usr/bin/env python3
"""
Diagnose — Troubleshoot CloudBase and Tencent Cloud environments

Usage:
    diagnose.py status [--envId <envId>]        Check overall environment health
    diagnose.py auth                            Check login status
    diagnose.py fn [--envId <envId>]            List cloud functions and status
    diagnose.py db [--envId <envId>]            List database collections
    diagnose.py logs [--envId <envId>] <fn>      Get function logs (last 100 lines)
    diagnose.py log-search [--envId <envId>] [--kw <keyword>] [--start <startTime>] [--end <endTime>] [--limit <n>]
                                                 Search function logs with filters
    diagnose.py trace [--envId <envId>] <traceId>
                                                 Query trace by Trace ID (from tracing-guide)
    diagnose.py debug [--envId <envId>] <traceId>
                                                 Combine logs + trace for a Trace ID (root cause analysis)
    diagnose.py hosting [--envId <envId>]       Check static hosting status
    diagnose.py domain [--envId <envId>]        Check domain binding
    diagnose.py login [--apiKeyId <id> --apiKey <key>]  Login with credentials
    diagnose.py browser <task>                  Open browser for manual tasks
    diagnose.py all [--envId <envId>]           Full diagnostics report

Exit codes: 0=healthy, 1=issues found, 2=error
"""

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone

try:
    from playwright.sync_api import sync_playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False


def run(cmd: list, capture=True) -> tuple[int, str, str]:
    """Run a command, return (code, stdout, stderr)."""
    try:
        r = subprocess.run(cmd, capture_output=capture, text=True, timeout=30)
        return r.returncode, r.stdout or "", r.stderr or ""
    except subprocess.TimeoutExpired:
        return 2, "", "Command timed out after 30s"
    except FileNotFoundError:
        return 127, "", f"Command not found: {cmd[0]}"
    except Exception as e:
        return 2, "", str(e)


def check_tcb():
    """Check if tcb CLI is available."""
    code, out, err = run(["tcb", "--version"])
    if code == 0:
        return out.strip()
    return None


def cmd_status(env_id: str) -> int:
    """Overall environment health check."""
    print("\n🔍 CloudBase Environment Health Check")
    print("=" * 50)

    # 1. tcb availability
    version = check_tcb()
    if not version:
        print("❌ tcb CLI not found. Run: npm install -g @cloudbase/cli")
        return 2
    print(f"✅ tcb CLI: {version}")

    # 2. Login status
    print("\n📋 Auth Status")
    code, out, _ = run(["tcb", "login", "--json"])
    # login check is non-interactive, check config instead
    code2, out2, _ = run(["tcb", "config", "list"])
    if code2 == 0 and out2:
        print(f"✅ Config loaded")
    else:
        print("⚠️  Run: tcb login --apiKeyId <id> --apiKey <key>")

    # 3. Env list
    print("\n📋 Environments")
    code, out, err = run(["tcb", "env", "list", "--json"])
    if code == 0:
        try:
            envs = json.loads(out)
            if isinstance(envs, list):
                for e in envs:
                    name = e.get("Name", e.get("EnvId", "?"))
                    status = e.get("Status", "?")
                    print(f"  {'✅' if status == 'Active' else '⚠️'} {name} — {status}")
            elif isinstance(envs, dict):
                # Some versions return {data: [...]}
                data = envs.get("data", envs)
                if isinstance(data, list):
                    for e in data:
                        name = e.get("Name", e.get("EnvId", "?"))
                        status = e.get("Status", "?")
                        print(f"  {'✅' if status == 'Active' else '⚠️'} {name} — {status}")
        except json.JSONDecodeError:
            print(f"  Response: {out[:200]}")
    else:
        print(f"❌ Failed to list envs: {err}")

    # 4. Env detail
    if env_id:
        print(f"\n📋 Details for env: {env_id}")
        code, out, err = run(["tcb", "env", "list", "--json"])
        if code == 0:
            try:
                envs = json.loads(out)
                target = None
                for e in (envs if isinstance(envs, list) else envs.get("data", [])):
                    if e.get("EnvId") == env_id or e.get("Name") == env_id:
                        target = e
                        break
                if target:
                    for k, v in target.items():
                        print(f"  {k}: {v}")
                else:
                    print(f"  ⚠️  Env '{env_id}' not found in list")
            except json.JSONDecodeError:
                pass
    return 0


def cmd_auth() -> int:
    """Check authentication status."""
    print("\n🔐 Authentication Status")
    print("=" * 50)

    # Try tcb whoami equivalent
    code, out, err = run(["tcb", "user", "--json"])
    if code == 0:
        print(f"✅ Logged in")
        print(out)
    else:
        # Fallback: check config file
        code2, out2, _ = run(["tcb", "config", "list"])
        if code2 == 0:
            print("✅ Config exists")
            print(out2[:500])
        else:
            print("❌ Not logged in")
            print("   Run: tcb login --apiKeyId <id> --apiKey <key>")
            return 1

    return 0


def cmd_fn(env_id: str) -> int:
    """List cloud functions."""
    print(f"\n☁️  Cloud Functions — env: {env_id or 'default'}")
    print("=" * 50)
    cmd = ["tcb", "fn", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd + ["--json"])
    if code == 0:
        try:
            fns = json.loads(out)
            if isinstance(fns, list):
                print(f"  Found {len(fns)} function(s):")
                for f in fns:
                    name = f.get("FunctionName", "?")
                    status = f.get("Status", "?")
                    runtime = f.get("Runtime", "?")
                    mod = f.get("ModifiedTime", "?")
                    print(f"  {'✅' if status == 'Active' else '⚠️'} {name} | {runtime} | {mod}")
            else:
                print(out[:500])
        except json.JSONDecodeError:
            print(out[:500])
    else:
        print(f"❌ {err}")
        return 1
    return 0


def cmd_db(env_id: str) -> int:
    """List database collections."""
    print(f"\n🗄️  Database Collections — env: {env_id or 'default'}")
    print("=" * 50)
    cmd = ["tcb", "db", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd + ["--json"])
    if code == 0:
        try:
            collections = json.loads(out)
            if isinstance(collections, list):
                print(f"  Found {len(collections)} collection(s):")
                for c in collections:
                    name = c.get("CollectionName", c.get("Name", "?"))
                    count = c.get("Count", "?")
                    print(f"  📄 {name} ({count} docs)")
            else:
                print(out[:500])
        except json.JSONDecodeError:
            print(out[:500])
    else:
        print(f"❌ {err}")
        return 1
    return 0


def cmd_logs(env_id: str, fn_name: str) -> int:
    """Get function logs (last 100 lines)."""
    if not fn_name:
        print("❌ Function name required. Usage: diagnose.py logs <function-name>")
        return 2
    print(f"\n📜 Logs for function: {fn_name}")
    print("=" * 50)
    cmd = ["tcb", "logs", fn_name]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd)
    if code == 0:
        print(out[:2000] if out else "(no logs)")
    else:
        print(f"❌ {err}")
        return 1
    return 0


def cmd_log_search(env_id: str, keyword: str, start_time: str, end_time: str, limit: int) -> int:
    """Search function logs with filters via tcb CLI + jq fallback."""
    print(f"\n🔎 Log Search — keyword: {keyword or '*'}, env: {env_id or 'default'}")
    print("=" * 50)

    # Try tcb log search (newer CLI versions)
    cmd = ["tcb", "logs", "search"]
    if env_id:
        cmd.extend(["--envId", env_id])
    if keyword:
        cmd.extend(["--keyword", keyword])
    if start_time:
        cmd.extend(["--startTime", start_time])
    if end_time:
        cmd.extend(["--endTime", end_time])
    if limit:
        cmd.extend(["--limit", str(limit)])

    code, out, err = run(cmd)
    if code == 0:
        print(out[:3000] if out else "(no logs found)")
        return 0

    # Fallback: use tcb logs + grep
    print(f"⚠️  tcb logs search not available, using basic logs + grep filter")
    if not keyword:
        print("❌ --kw <keyword> required for fallback search")
        return 2

    # Get recent logs from all functions and filter
    code2, out2, _ = run(["tcb", "fn", "list", "--json"])
    if code2 != 0:
        print(f"❌ Cannot list functions: {out2}")
        return 1

    try:
        fns = json.loads(out2)
        fn_list = fns if isinstance(fns, list) else fns.get("data", [])
    except json.JSONDecodeError:
        print(f"❌ Cannot parse function list")
        return 1

    matches = []
    for fn in fn_list:
        fn_name = fn.get("FunctionName") or fn.get("Name")
        if not fn_name:
            continue
        code3, out3, _ = run(["tcb", "logs", fn_name])
        if code3 == 0 and out3 and keyword.lower() in out3.lower():
            for line in out3.splitlines():
                if keyword.lower() in line.lower():
                    matches.append(f"[{fn_name}] {line}")

    if matches:
        print(f"\nFound {len(matches)} log line(s):\n")
        for m in matches[:limit or 50]:
            print(m)
    else:
        print("(no matching logs found)")

    return 0


def cmd_trace(env_id: str, trace_id: str) -> int:
    """Query trace by Trace ID. Requires trace-collector cloud function deployed."""
    if not trace_id:
        print("❌ Trace ID required. Usage: diagnose.py trace <traceId>")
        return 2

    print(f"\n🔍 Trace Query — {trace_id}")
    print("=" * 50)

    # Validate Trace ID format (32 hex chars)
    clean = trace_id.strip().upper()
    if len(clean) != 32 or not all(c in '0123456789ABCDEF' for c in clean):
        print(f"⚠️  Trace ID '{trace_id}' doesn't look like a standard 32-char hex ID")
        print("   Expected format: 0000XXXXXXXXXXXXXXXXXXXXXXXXXXXX (EagleEye compatible)")

    # Call trace-collector cloud function (deployed by tracing-guide)
    # falls back to querying CLS directly via tcb cls
    print("\n📡 Fetching trace from trace-collector...")
    code, out, err = run([
        "tcb", "fn", "invoke", "trace-collector",
        "--envId", env_id or "",
        "--params", json.dumps({"action": "query", "traceId": trace_id})
    ])

    if code == 0 and out:
        try:
            result = json.loads(out)
            if result.get("code") == 0:
                spans = result.get("data", {}).get("spans", [])
                if not spans:
                    print("⚠️  No spans found for this Trace ID")
                else:
                    _render_trace_tree(trace_id, spans)
                return 0
            else:
                print(f"⚠️  trace-collector returned: {result.get('message', out[:200])}")
        except json.JSONDecodeError:
            pass

    # Fallback: try CLS log search
    print("\n📡 Falling back to CLS log search...")
    return _query_trace_from_cls(env_id, trace_id)


def _query_trace_from_cls(env_id: str, trace_id: str) -> int:
    """Query trace spans from CLS logs by Trace ID."""
    code, out, err = run([
        "tcb", "cls", "search",
        "--envId", env_id or "",
        "--query", f"traceId:{trace_id}",
        "--limit", "100"
    ])

    if code != 0 or not out:
        print("❌ No trace data found in CLS or tcb cls not available")
        print("   Hints:")
        print("   1. Deploy trace-collector cloud function (see tracing-guide.md)")
        print("   2. Or check CLS console: https://console.cloud.tencent.com/cls")
        return 1

    try:
        logs = json.loads(out) if isinstance(out, str) else out
        if isinstance(logs, dict):
            logs = logs.get("data", logs.get("results", []))

        spans = []
        for entry in (logs if isinstance(logs, list) else []):
            content = entry if isinstance(entry, dict) else {"message": str(entry)}
            msg = content.get("message", "")
            try:
                obj = json.loads(msg) if isinstance(msg, str) else msg
                if isinstance(obj, dict) and obj.get("type") in ("span", "event"):
                    spans.append(obj)
            except (json.JSONDecodeError, TypeError):
                continue

        if spans:
            _render_trace_tree(trace_id, spans)
        else:
            print("⚠️  CLS logs found but no span records for this trace")
            print(f"   Raw sample: {str(logs[:1])[:300]}")
    except Exception as e:
        print(f"⚠️  Error parsing CLS response: {e}")
        print(f"   Raw: {str(out)[:500]}")

    return 0


def _render_trace_tree(trace_id: str, spans: list):
    """Render trace spans as an ASCII call tree."""
    print(f"\n{'='*50}")
    print(f"Trace ID: {trace_id}")
    print(f"Total spans: {len(spans)}")
    print(f"{'='*50}")

    # Build parent→children map
    span_map = {s.get("spanId", s.get("id")): s for s in spans}
    children_map = {}
    roots = []

    for s in spans:
        pid = s.get("parentSpanId", "") or s.get("parentId", "")
        sid = s.get("spanId", s.get("id"))
        if pid and pid in span_map:
            children_map.setdefault(pid, []).append(s)
        else:
            roots.append(s)

    def dur_ms(s):
        d = s.get("duration", 0)
        return d / 1000 if d > 1000 else d

    def dur_unit(s):
        d = s.get("duration", 0)
        return "ms" if d <= 100000 else "μs"

    def render(node, depth=0):
        sid = node.get("spanId", node.get("id", "?"))
        svc = node.get("service", "unknown")
        op = node.get("operation", node.get("event", ""))
        status = node.get("status", 0)
        icon = ["✅", "⚠️", "❌"][status] if status in (0, 1, 2) else "·"
        dur = dur_ms(node)
        unit = dur_unit(node)
        print(f"{'  ' * depth}{icon} {svc}.{op}  {dur:.2f}{unit}  [span:{sid[:8]}]")
        for child in sorted(children_map.get(sid, []), key=lambda x: x.get("startTime", "")):
            render(child, depth + 1)

    for root in sorted(roots, key=lambda x: x.get("startTime", "")):
        render(root)

    # Summary by service
    from collections import defaultdict
    svc_stats = defaultdict(lambda: {"count": 0, "total_us": 0})
    for s in spans:
        svc = s.get("service", "unknown")
        svc_stats[svc]["count"] += 1
        svc_stats[svc]["total_us"] += s.get("duration", 0)

    print(f"\n{'─'*50}")
    print(f"Service breakdown:")
    print(f"{'─'*50}")
    for svc, stats in sorted(svc_stats.items(), key=lambda x: -x[1]["total_us"]):
        avg = stats["total_us"] / max(stats["count"], 1)
        print(f"  {svc:<30} {stats['count']:>4} calls  avg {avg/1000:.2f}ms")


def cmd_debug(env_id: str, trace_id: str) -> int:
    """Root-cause analysis: fetch trace tree + all related logs for a Trace ID."""
    if not trace_id:
        print("❌ Trace ID required. Usage: diagnose.py debug <traceId>")
        return 2

    print(f"\n🕵️  Debug Session — Trace ID: {trace_id}")
    print("=" * 60)

    # Step 1: Get trace tree
    print("\n[1/3] Fetching trace tree...")
    r1 = cmd_trace(env_id, trace_id)

    # Step 2: Search all related logs
    print("\n[2/3] Searching related logs...")
    code, out, err = run([
        "tcb", "logs", "search",
        "--envId", env_id or "",
        "--keyword", trace_id,
        "--limit", "200"
    ])

    if code == 0 and out:
        print(out[:2000])
    else:
        # Fallback grep approach
        print("⚠️  tcb logs search not available, grepping basic logs...")
        code2, fns_out, _ = run(["tcb", "fn", "list", "--json"])
        if code2 == 0:
            try:
                fns = json.loads(fns_out)
                fn_list = fns if isinstance(fns, list) else fns.get("data", [])
                for fn in (fn_list or [])[:10]:
                    fn_name = fn.get("FunctionName", fn.get("Name", ""))
                    if fn_name:
                        code3, log_out, _ = run(["tcb", "logs", fn_name])
                        if code3 == 0:
                            for line in log_out.splitlines():
                                if trace_id in line:
                                    print(f"[{fn_name}] {line}")
            except json.JSONDecodeError:
                pass

    # Step 3: CLS deep dive
    print("\n[3/3] CLS deep search...")
    code, out, err = run([
        "tcb", "cls", "search",
        "--envId", env_id or "",
        "--query", f"traceId:{trace_id}",
        "--limit", "500"
    ])
    if code == 0 and out:
        try:
            logs = json.loads(out) if isinstance(out, str) else out
            entries = logs if isinstance(logs, list) else logs.get("data", logs.get("results", []))
            print(f"\nFound {len(entries)} CLS log entries for this trace:\n")
            for e in (entries or [])[:20]:
                msg = e.get("message", "") if isinstance(e, dict) else str(e)
                ts = e.get("timestamp", "") if isinstance(e, dict) else ""
                print(f"  {ts}  {msg[:150]}")
        except (json.JSONDecodeError, TypeError):
            print(str(out)[:500])
    else:
        print("⚠️  tcb cls search not available (may need CLS configured)")
        print("   Enable at: https://console.cloud.tencent.com/cls")

    print(f"\n{'='*60}")
    print(f"Debug session complete for: {trace_id}")
    print("\nNext steps:")
    print("  1. Identify the failing span (❌ or ⚠️ icon)")
    print("  2. Check the service logs above for error messages")
    print("  3. Cross-reference with API contract in design/backend/")
    print("  4. For slow spans: check DB queries or external HTTP calls")

    return 0


def cmd_hosting(env_id: str) -> int:
    """Check static hosting status."""
    print(f"\n🌐 Static Hosting Status — env: {env_id or 'default'}")
    print("=" * 50)
    cmd = ["tcb", "hosting", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd)
    if code == 0:
        print(out[:1000] if out else "(empty)")
    else:
        print(f"❌ {err}")
        return 1
    return 0


def cmd_domain(env_id: str) -> int:
    """Check domain binding status."""
    print(f"\n🌐 Domain Binding — env: {env_id or 'default'}")
    print("=" * 50)
    cmd = ["tcb", "domains", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd)
    if code == 0:
        print(out[:1000] if out else "(no domains configured)")
    else:
        print(f"⚠️  {err}")
        print("   Tip: Add domain at https://console.cloud.tencent.com/tcb/hosting/domain")

    print("\n📋 Common CloudBase domains (auto):")
    if env_id:
        auto = f"https://{env_id.replace('-', '')}.cloud.tcbbase.com"
        print(f"   Auto domain: {auto}")
        print(f"   Bind at: https://console.cloud.tencent.com/tcb/hosting/domain")
    return 0


def cmd_login(api_key_id: str, api_key: str) -> int:
    """Login with credentials."""
    if not api_key_id or not api_key:
        print("❌ --apiKeyId and --apiKey required")
        print("   Usage: diagnose.py login --apiKeyId <id> --apiKey <key>")
        return 2
    print(f"\n🔐 Logging in as {api_key_id[:8]}...")
    code, out, err = run(["tcb", "login", "--apiKeyId", api_key_id, "--apiKey", api_key])
    if code == 0:
        print("✅ Login successful")
    else:
        print(f"❌ Login failed: {err}")
        return 1
    return 0


def cmd_browser(task: str) -> int:
    """Open browser for manual tasks."""
    TASKS = {
        "domain": "https://console.cloud.tencent.com/tcb/hosting/domain",
        "whitelist": "https://mp.weixin.qq.com/wxamp/devprofile/get_profile?token=164093043&lang=zh_CN",
        "apikey": "https://console.cloud.tencent.com/cam/capi",
        "env": "https://console.cloud.tencent.com/tcb/env",
        "fn": "https://console.cloud.tencent.com/tcb/functions",
        "db": "https://console.cloud.tencent.com/tcb/database",
        "storage": "https://console.cloud.tencent.com/tcb/storage",
        "cloudrun": "https://console.cloud.tencent.com/tcb/cloudrun",
        "cls": "https://console.cloud.tencent.com/cls",
        "monitor": "https://console.cloud.tencent.com/monitor",
        "tracing": "https://console.cloud.tencent.com/apm",
    }

    if not task:
        print("Available browser tasks:")
        for k, v in TASKS.items():
            print(f"  {k:12} → {v}")
        return 0

    url = TASKS.get(task.lower())
    if not url:
        print(f"Unknown task: {task}")
        print("Available:", list(TASKS.keys()))
        return 2

    print(f"🌐 Opening: {url}")

    if HAS_PLAYWRIGHT:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"✅ Page loaded: {page.title()}")
            screenshot = f"/tmp/diagnose-{task}-{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
            page.screenshot(path=screenshot)
            print(f"📸 Screenshot saved: {screenshot}")
            browser.close()
    else:
        import subprocess
        import os
        browser = os.environ.get("BROWSER", "chromium")
        try:
            subprocess.run(
                ["playwright", "open", "--browser", "chromium", url],
                capture_output=True, text=True, timeout=30
            )
        except Exception:
            # Fallback: just print URL
            print(f"⚠️  Playwright not available. Open manually:")
            print(f"   {url}")
    return 0


def cmd_all(env_id: str) -> int:
    """Full diagnostic report."""
    print("\n🔬 Full Diagnostics Report")
    print("=" * 60)
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    issues = 0

    r = cmd_status(env_id)
    if r != 0:
        issues += r

    if env_id:
        r = cmd_fn(env_id)
        if r != 0:
            issues += 1

        r = cmd_db(env_id)
        if r != 0:
            issues += 1

        r = cmd_hosting(env_id)
        if r != 0:
            issues += 1

        r = cmd_domain(env_id)
        if r != 0:
            issues += 1

    print("\n" + "=" * 60)
    if issues == 0:
        print("✅ All checks passed")
    else:
        print(f"⚠️  {issues} issue(s) found")
    return 1 if issues else 0


# ─── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="CloudBase Diagnose Tool")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_status = sub.add_parser("status", help="Environment health check")
    p_status.add_argument("--envId", help="Specific envId")

    p_auth = sub.add_parser("auth", help="Check authentication")

    p_fn = sub.add_parser("fn", help="List cloud functions")
    p_fn.add_argument("--envId", help="Environment ID")

    p_db = sub.add_parser("db", help="List database collections")
    p_db.add_argument("--envId", help="Environment ID")

    p_logs = sub.add_parser("logs", help="Get function logs (last 100 lines)")
    p_logs.add_argument("--envId", help="Environment ID")
    p_logs.add_argument("fn", nargs="?", help="Function name")

    p_log_search = sub.add_parser("log-search", help="Search function logs with filters")
    p_log_search.add_argument("--envId", help="Environment ID")
    p_log_search.add_argument("--kw", dest="keyword", help="Keyword to search")
    p_log_search.add_argument("--start", dest="startTime", help="Start time (ISO or -1h/-30m)")
    p_log_search.add_argument("--end", dest="endTime", help="End time (ISO or -1h)")
    p_log_search.add_argument("--limit", type=int, default=100, help="Max log lines (default 100)")

    p_trace = sub.add_parser("trace", help="Query trace by Trace ID")
    p_trace.add_argument("--envId", help="Environment ID")
    p_trace.add_argument("traceId", nargs="?", help="32-char EagleEye-compatible Trace ID")

    p_debug = sub.add_parser("debug", help="Root-cause analysis: trace + logs for a Trace ID")
    p_debug.add_argument("--envId", help="Environment ID")
    p_debug.add_argument("traceId", nargs="?", help="32-char EagleEye-compatible Trace ID")

    p_hosting = sub.add_parser("hosting", help="Check static hosting")
    p_hosting.add_argument("--envId", help="Environment ID")

    p_domain = sub.add_parser("domain", help="Check domain binding")
    p_domain.add_argument("--envId", help="Environment ID")

    p_login = sub.add_parser("login", help="Login with API credentials")
    p_login.add_argument("--apiKeyId", required=True, help="API Key ID")
    p_login.add_argument("--apiKey", required=True, help="API Key Secret")

    p_browser = sub.add_parser("browser", help="Open browser for manual tasks")
    p_browser.add_argument("task", nargs="?", help="Task: domain|whitelist|apikey|env|fn|db|storage|cloudrun|cls|monitor|tracing")

    p_all = sub.add_parser("all", help="Full diagnostics")
    p_all.add_argument("--envId", help="Environment ID")

    args = parser.parse_args()

    dispatch = {
        "status": lambda: cmd_status(args.envId),
        "auth": cmd_auth,
        "fn": lambda: cmd_fn(args.envId),
        "db": lambda: cmd_db(args.envId),
        "logs": lambda: cmd_logs(args.envId, args.fn),
        "log-search": lambda: cmd_log_search(args.envId, args.keyword, args.startTime, args.endTime, args.limit),
        "trace": lambda: cmd_trace(args.envId, args.traceId),
        "debug": lambda: cmd_debug(args.envId, args.traceId),
        "hosting": lambda: cmd_hosting(args.envId),
        "domain": lambda: cmd_domain(args.envId),
        "login": lambda: cmd_login(args.apiKeyId, args.apiKey),
        "browser": lambda: cmd_browser(args.task),
        "all": lambda: cmd_all(args.envId),
    }

    sys.exit(dispatch[args.cmd]())


if __name__ == "__main__":
    main()
