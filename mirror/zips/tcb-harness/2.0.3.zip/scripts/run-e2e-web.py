#!/usr/bin/env python3
"""
run-e2e-web.py — Playwright E2E test runner for Web projects

Usage:
    run-e2e-web.py                    Interactive mode: detect project and offer choices
    run-e2e-web.py --init             Initialize Playwright in current Web project
    run-e2e-web.py --check            Check Playwright setup / browser installation
    run-e2e-web.py --serve <port>     Start dev server (default 3000)
    run-e2e-web.py --open             Open Web app in browser (Playwright screenshot check)
    run-e2e-web.py --test             Run all E2E tests (headless)
    run-e2e-web.py --test --headed    Run with visible browser
    run-e2e-web.py --test --debug     Run with Playwright Inspector debug
    run-e2e-web.py --test --ui       Run with Playwright UI mode
    run-e2e-web.py --test --grep <pat>   Run tests matching <pat>
    run-e2e-web.py --report           Generate / open HTML report
    run-e2e-web.py --codegen <url>    Launch Playwright codegen for recording
    run-e2e-web.py --screenshot <url> <out.png>  Take screenshot of URL

Options:
    --project <path>      Project root (default: auto-detect from config.json or CWD)
    --browser <browser>   chromium | firefox | webkit (default: chromium)
    --viewport           Desktop | Mobile | Custom (default: Desktop)
    --base-url <url>     Override base URL for tests
    --timeout <ms>        Test timeout in ms (default: 30000)

Exit codes: 0=all pass, 1=some fail, 2=error / setup issue
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.parse


def run(cmd: list, cwd=None, capture=True, timeout=120) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=capture, text=True, cwd=cwd or os.getcwd(), timeout=timeout)
        return r.returncode, r.stdout or "", r.stderr or ""
    except subprocess.TimeoutExpired:
        return 2, "", "Command timed out"
    except FileNotFoundError:
        return 127, "", f"Command not found: {cmd[0]}"
    except Exception as e:
        return 2, "", str(e)


def detect_project() -> str | None:
    """Detect if current directory is a tcb-harness Web project."""
    # Check for harness config
    for name in [".harness/config.json", "config.json"]:
        if os.path.exists(name):
            try:
                cfg = json.loads(open(name).read())
                if cfg.get("platform") in ("web", "hybrid", "official-account", "mobile"):
                    return os.path.dirname(name) or "."
            except (json.JSONDecodeError, FileNotFoundError):
                pass
    # Check for package.json with tdesign-react or react project
    if os.path.exists("package.json"):
        try:
            pkg = json.loads(open("package.json").read())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if any(k in deps for k in ["react", "@tencent/tdesign-react", "tdesign-react"]):
                return "."
        except (json.JSONDecodeError, FileNotFoundError):
            pass
    return None


def check_playwright_setup(project: str) -> bool:
    """Check if Playwright is installed in project."""
    try:
        code, out, _ = run(["npx", "playwright", "--version"], cwd=project)
        if code == 0:
            print(f"✅ Playwright: {out.strip()}")
            return True
    except Exception:
        pass

    # Check node_modules
    if os.path.exists(os.path.join(project, "node_modules/@playwright/test")):
        return True
    return False


def check_browsers(project: str) -> bool:
    """Check if browsers are installed."""
    code, out, err = run(["npx", "playwright", "list-browsers"], cwd=project)
    if code == 0:
        print(f"✅ Browsers: {out.strip()}")
        return True
    return False


def cmd_check(project: str) -> int:
    """Check Playwright setup status."""
    print(f"\n🔍 Playwright E2E Check — project: {project}")
    print("=" * 50)

    status = 0

    # Node / npx
    code, out, _ = run(["node", "--version"])
    if code == 0:
        print(f"✅ Node.js: {out.strip()}")
    else:
        print("❌ Node.js not found")
        status = 2

    # npx playwright
    code, out, _ = run(["npx", "--version"])
    if code == 0:
        print(f"✅ npm/npx: {out.strip()}")
    else:
        print("❌ npm/npx not found")
        status = 2

    # Playwright
    if check_playwright_setup(project):
        print("✅ @playwright/test installed")
    else:
        print("⚠️  @playwright/test not installed")
        print("   Run: run-e2e-web.py --init")

    # Browsers
    code, out, err = run(["npx", "playwright", "install", "--dry-run"], cwd=project)
    if code == 0:
        print(f"✅ Browsers ready")
    else:
        print(f"⚠️  Browsers may need installation: {err.strip()[:100]}")
        print(f"   Run: npx playwright install chromium --with-deps")

    # Check playwright.config.ts
    pcfg = os.path.join(project, "playwright.config.ts")
    if os.path.exists(pcfg):
        print(f"✅ playwright.config.ts found")
    else:
        print(f"⚠️  playwright.config.ts not found (tests will use defaults)")

    # Check tests/e2e/web/
    e2e_dir = os.path.join(project, "tests/e2e/web")
    if os.path.exists(e2e_dir):
        spec_files = [f for f in os.listdir(e2e_dir) if f.endswith(".spec.ts") or f.endswith(".spec.js")]
        print(f"✅ E2E tests found: {len(spec_files)} spec(s)")
        for f in spec_files[:5]:
            print(f"   - {f}")
    else:
        print(f"⚠️  tests/e2e/web/ not found")

    return status


def cmd_init(project: str, force: bool = False) -> int:
    """Initialize Playwright in a Web project."""
    print(f"\n🚀 Initializing Playwright E2E — project: {project}")
    print("=" * 50)

    os.makedirs(os.path.join(project, "tests/e2e/web"), exist_ok=True)
    os.makedirs(os.path.join(project, "tests/e2e/reports"), exist_ok=True)
    os.makedirs(os.path.join(project, "tests/e2e/screenshots"), exist_ok=True)
    os.makedirs(os.path.join(project, "tests/e2e/screenshots/diff"), exist_ok=True)

    # Create playwright.config.ts
    pcfg = os.path.join(project, "playwright.config.ts")
    if os.path.exists(pcfg) and not force:
        print(f"⚠️  playwright.config.ts already exists (use --force to overwrite)")
    else:
        config = PLAYWRIGHT_CONFIG_TEMPLATE
        with open(pcfg, "w") as f:
            f.write(config)
        print(f"✅ playwright.config.ts created")

    # Create example spec
    example_spec = os.path.join(project, "tests/e2e/web/example.spec.ts")
    if not os.path.exists(example_spec):
        with open(example_spec, "w") as f:
            f.write(EXAMPLE_SPEC)
        print(f"✅ example.spec.ts created")

    # Install Playwright
    print("\n📦 Installing @playwright/test...")
    code, out, err = run(
        ["npm", "install", "-D", "@playwright/test"],
        cwd=project,
        timeout=120
    )
    if code != 0:
        print(f"❌ npm install failed: {err}")
        return 1
    print(f"✅ @playwright/test installed")

    # Install browsers
    print("\n🌐 Installing Chromium browser...")
    code, out, err = run(
        ["npx", "playwright", "install", "chromium"],
        cwd=project,
        timeout=300
    )
    if code != 0:
        print(f"⚠️  Browser install had issues: {err[:200]}")
    else:
        print(f"✅ Chromium installed")

    # Install deps
    print("\n📦 Installing system dependencies...")
    code, _, _ = run(
        ["npx", "playwright", "install-deps", "chromium"],
        cwd=project,
        timeout=120
    )

    print(f"\n✅ Playwright E2E ready!")
    print(f"   Run tests:  python3 scripts/run-e2e-web.py --test")
    print(f"   Record:      python3 scripts/run-e2e-web.py --codegen http://localhost:3000")
    print(f"   Screenshot:  python3 scripts/run-e2e-web.py --screenshot http://localhost:3000 screenshot.png")
    return 0


def cmd_test(project: str, browser: str, viewport: str, base_url: str,
             headed: bool, debug: bool, ui_mode: bool, grep: str, timeout: int) -> int:
    """Run Playwright E2E tests."""
    print(f"\n🧪 Running Web E2E Tests — project: {project}")
    print("=" * 50)

    if not check_playwright_setup(project):
        print("❌ Playwright not initialized. Run: run-e2e-web.py --init")
        return 2

    # Build playwright test command
    cmd = ["npx", "playwright", "test"]

    # Options
    if headed:
        cmd.append("--headed")
    if debug:
        cmd.extend(["--debug"])
    if ui_mode:
        cmd.append("--ui")
    if grep:
        cmd.extend(["--grep", grep])

    # Project/browsers
    if browser != "chromium":
        cmd.extend(["--project", browser])

    # Timeout
    if timeout != 30000:
        cmd.extend([f"--timeout={timeout}"])

    # Base URL env
    if base_url:
        env = os.environ.copy()
        env["WEB_BASE_URL"] = base_url

    print(f"CMD: {' '.join(cmd)}")
    code, out, err = run(cmd, cwd=project, timeout=600)

    # Print output
    if out:
        print(out[-3000:])
    if err:
        print(err[-1000:])

    if code == 0:
        print(f"\n✅ All E2E tests passed")
    else:
        print(f"\n❌ E2E tests failed (exit {code})")
        # Open report hint
        if os.path.exists(os.path.join(project, "tests/e2e/reports")):
            print(f"   Report: open tests/e2e/reports/index.html")

    return code


def cmd_report(project: str) -> int:
    """Open HTML report."""
    report_path = os.path.join(project, "tests/e2e/reports/index.html")
    if os.path.exists(report_path):
        print(f"📊 Opening report: {report_path}")
        run(["open" if sys.platform == "darwin" else "xdg-open", report_path])
    else:
        print(f"❌ Report not found: {report_path}")
        return 1
    return 0


def cmd_codegen(project: str, url: str) -> int:
    """Launch Playwright codegen."""
    print(f"\n🎬 Launching Playwright Codegen — target: {url}")
    print("=" * 50)
    cmd = ["npx", "playwright", "codegen", url, "--target=typescript"]
    if sys.stdout.isatty():
        cmd.append("--output")
        cmd.append(os.path.join(project, "tests/e2e/web/recorded.spec.ts"))
    print(f"CMD: {' '.join(cmd)}")
    code, out, err = run(cmd, cwd=project, timeout=0)
    return code


def cmd_screenshot(project: str, url: str, out_path: str, viewport: str) -> int:
    """Take screenshot of URL."""
    print(f"\n📸 Screenshot — {url} → {out_path}")

    # Determine device/viewport
    viewport_map = {
        "desktop": {"width": 1920, "height": 1080},
        "mobile": {"width": 390, "height": 844},
        "tablet": {"width": 768, "height": 1024},
    }
    vp = viewport_map.get(viewport.lower(), viewport_map["desktop"])

    code, out, err = run([
        "npx", "playwright", "screenshot",
        "--viewport-size", f"{vp['width']},{vp['height']}",
        url, out_path
    ], cwd=project, timeout=60)

    if code == 0:
        print(f"✅ Screenshot saved: {out_path}")
    else:
        print(f"❌ Screenshot failed: {err}")
        return 1
    return 0


def cmd_open(project: str, base_url: str, browser: str, action: str = "screenshot") -> int:
    """Open Web app in browser and take verification screenshot."""
    if not base_url:
        base_url = os.environ.get("WEB_BASE_URL", "http://localhost:3000")

    print(f"\n🌐 Opening Web app: {base_url}")
    print("=" * 50)

    ss_path = f"/tmp/openclaw-e2e-check-{int(os.times().elapsed * 1000)}.png"
    code, out, err = run([
        "npx", "playwright", "screenshot",
        "--full-page",
        base_url, ss_path
    ], cwd=project, timeout=60)

    if code == 0:
        print(f"✅ Screenshot: {ss_path}")
        print(f"   Title check passed — app is accessible")
    else:
        print(f"⚠️  Could not open {base_url}")
        print(f"   Hints:")
        print(f"   1. Start dev server: run-e2e-web.py --serve")
        print(f"   2. Or set base URL: run-e2e-web.py --base-url https://your-app.tcloud.com")
    return code


def cmd_serve(project: str, port: int) -> int:
    """Start dev server for Web app."""
    print(f"\n🚀 Starting dev server on port {port}...")
    print(f"   Project: {project}")
    print(f"   Press Ctrl+C to stop\n")

    # Detect package manager
    if os.path.exists(os.path.join(project, "pnpm-lock.yaml")):
        cmd = ["pnpm", "dev"]
    elif os.path.exists(os.path.join(project, "yarn.lock")):
        cmd = ["yarn", "dev"]
    else:
        cmd = ["npm", "run", "dev"]

    # Check if dev script exists
    try:
        pkg = json.loads(open(os.path.join(project, "package.json")).read())
        scripts = pkg.get("scripts", {})
        if "dev" not in scripts:
            print(f"⚠️  No 'dev' script in package.json")
            print(f"   Available: {list(scripts.keys())}")
            return 1
    except (json.JSONDecodeError, FileNotFoundError):
        print(f"❌ Cannot read package.json")
        return 1

    # Run in background
    print(f"CMD: {' '.join(cmd)} (port {port})")
    p = subprocess.Popen(cmd, cwd=project, text=True)
    try:
        p.wait()
    except KeyboardInterrupt:
        p.terminate()
        print("\n✅ Server stopped")
    return 0


# ─── Templates ────────────────────────────────────────────────────────────────

PLAYWRIGHT_CONFIG_TEMPLATE = '''import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/e2e/web",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ["html", { outputFolder: "tests/e2e/reports" }],
    ["list"],
  ],

  use: {
    baseURL: process.env.WEB_BASE_URL || "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },

  projects: [
    // Desktop Chromium
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    // Mobile Chrome
    {
      name: "mobile-chrome",
      use: { ...devices["Pixel 5"] },
    },
    // iOS Safari
    {
      name: "mobile-safari",
      use: { ...devices["iPhone 12"] },
    },
  ],

  webServer: process.env.CI
    ? undefined
    : {
        command: "npm run dev",
        url: "http://localhost:3000",
        reuseExistingServer: !process.env.CI,
        timeout: 120 * 1000,
      },
});
'''

EXAMPLE_SPEC = '''import { test, expect } from "@playwright/test";

/**
 * E2E 测试示例 — Web 项目
 *
 * 运行方式:
 *   npx playwright test                        # 全部测试
 *   npx playwright test --headed               # 可见浏览器
 *   npx playwright test --grep "登录"          # 运行匹配的测试
 *   npx playwright test --ui                  # Playwright UI 模式
 *
 * 报告查看:
 *   npx playwright show-report
 */

test.describe("首页", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/");
  });

  test("页面正确加载", async ({ page }) => {
    // 验证页面标题或主内容
    await expect(page).toHaveTitle(/.*/);
  });

  test("顶部导航可见", async ({ page }) => {
    const nav = page.locator("nav, .header, [class*='nav']").first();
    await expect(nav).toBeVisible();
  });
});

test.describe("用户认证", () => {
  test("登录成功", async ({ page }) => {
    await page.goto("/login");

    await page.getByPlaceholder("邮箱").fill("test@example.com");
    await page.getByPlaceholder("密码").fill("password123");
    await page.getByRole("button", { name: "登录" }).click();

    // 验证跳转到首页
    await expect(page).toHaveURL("/");
    await expect(page.getByText("个人中心")).toBeVisible();
  });

  test("登录失败", async ({ page }) => {
    await page.goto("/login");

    await page.getByPlaceholder("邮箱").fill("wrong@example.com");
    await page.getByPlaceholder("密码").fill("wrongpass");
    await page.getByRole("button", { name: "登录" }).click();

    // 验证错误提示
    await expect(page.getByText("登录失败")).toBeVisible();
  });
});
'''


# ─── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Web E2E Playwright Runner")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_check = sub.add_parser("check", help="Check Playwright setup")
    p_check.add_argument("--project", default=".")

    p_init = sub.add_parser("init", help="Initialize Playwright in project")
    p_init.add_argument("--project", default=".")
    p_init.add_argument("--force", action="store_true", help="Force overwrite existing config")

    p_test = sub.add_parser("test", help="Run E2E tests")
    p_test.add_argument("--project", default=".")
    p_test.add_argument("--browser", default="chromium", choices=["chromium", "firefox", "webkit"])
    p_test.add_argument("--viewport", default="desktop", choices=["desktop", "mobile", "tablet"])
    p_test.add_argument("--base-url", dest="baseUrl", help="Override base URL")
    p_test.add_argument("--headed", action="store_true", help="Run with visible browser")
    p_test.add_argument("--debug", action="store_true", help="Debug with Playwright Inspector")
    p_test.add_argument("--ui", action="store_true", help="Playwright UI mode")
    p_test.add_argument("--grep", help="Run tests matching pattern")
    p_test.add_argument("--timeout", type=int, default=30000, help="Timeout in ms")

    p_report = sub.add_parser("report", help="Open HTML report")
    p_report.add_argument("--project", default=".")

    p_codegen = sub.add_parser("codegen", help="Launch Playwright codegen")
    p_codegen.add_argument("--project", default=".")
    p_codegen.add_argument("url", nargs="?", default="http://localhost:3000", help="Target URL")

    p_screenshot = sub.add_parser("screenshot", help="Take screenshot")
    p_screenshot.add_argument("--project", default=".")
    p_screenshot.add_argument("url", help="URL to screenshot")
    p_screenshot.add_argument("out", help="Output file path")
    p_screenshot.add_argument("--viewport", default="desktop", choices=["desktop", "mobile", "tablet"])

    p_open = sub.add_parser("open", help="Open app in browser (verify accessible)")
    p_open.add_argument("--project", default=".")
    p_open.add_argument("--base-url", dest="baseUrl", help="Base URL")
    p_open.add_argument("--browser", default="chromium")

    p_serve = sub.add_parser("serve", help="Start dev server")
    p_serve.add_argument("--project", default=".")
    p_serve.add_argument("--port", type=int, default=3000)

    args = parser.parse_args()

    project = args.project
    if project == ".":
        detected = detect_project()
        if detected:
            project = detected
            print(f"🔍 Auto-detected Web project: {project}")
        else:
            print(f"⚠️  Not a recognized Web project. Using CWD.")

    dispatch = {
        "check": lambda: cmd_check(project),
        "init": lambda: cmd_init(project, args.force),
        "test": lambda: cmd_test(project, args.browser, args.viewport, args.baseUrl or "",
                                  args.headed, args.debug, args.ui, args.grep or "", args.timeout),
        "report": lambda: cmd_report(project),
        "codegen": lambda: cmd_codegen(project, args.url),
        "screenshot": lambda: cmd_screenshot(project, args.url, args.out, args.viewport),
        "open": lambda: cmd_open(project, args.baseUrl or "", args.browser),
        "serve": lambda: cmd_serve(project, args.port),
    }

    sys.exit(dispatch[args.cmd]())


if __name__ == "__main__":
    main()
