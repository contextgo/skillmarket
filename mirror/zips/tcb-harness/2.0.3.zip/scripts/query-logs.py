#!/usr/bin/env python3
"""
query-logs.py — Advanced CloudBase log querying with filtering and formatting

Usage:
    query-logs.py --envId <envId> --fn <fn>                      Basic logs
    query-logs.py --envId <envId> --fn <fn> --kw <keyword>       Filter by keyword
    query-logs.py --envId <envId> --fn <fn> --since <duration>   Recent logs (e.g. -1h, -30m)
    query-logs.py --envId <envId> --fn <fn> --err                Error logs only
    query-logs.py --envId <envId> --fn <fn> --trace <traceId>    Logs matching Trace ID
    query-logs.py --envId <envId> --fn <fn> --json               Raw JSON output
    query-logs.py --envId <envId> --fn <fn> --analyze            Summary analysis
    query-logs.py --envId <envId> --list-fns                     List functions then exit
    query-logs.py --envId <envId> --tail --fn <fn>               Tail logs (watch mode)

Requirements:
    - tcb CLI installed and authenticated
    - Optional: jq for JSON pretty-printing
"""

import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import time


SEP = "-" * 60


def run(cmd: list, capture=True, timeout=60) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=capture, text=True, timeout=timeout)
        return r.returncode, r.stdout or "", r.stderr or ""
    except subprocess.TimeoutExpired:
        return 2, "", "Command timed out"
    except FileNotFoundError:
        return 127, "", f"Command not found: {cmd[0]}"
    except Exception as e:
        return 2, "", str(e)


def parse_duration(s: str) -> datetime.datetime:
    """Parse duration like -1h, -30m, -15m ago, return datetime."""
    s = s.strip().lstrip("-")
    now = datetime.datetime.now(datetime.timezone.utc)
    if s.endswith("h"):
        delta = datetime.timedelta(hours=int(s[:-1]))
    elif s.endswith("m"):
        delta = datetime.timedelta(minutes=int(s[:-1]))
    elif s.endswith("s"):
        delta = datetime.timedelta(seconds=int(s[:-1]))
    elif s.endswith("d"):
        delta = datetime.timedelta(days=int(s[:-1]))
    else:
        delta = datetime.timedelta(hours=1)
    return now - delta


def detect_log_format(line: str) -> str:
    """Detect if a log line is plain text, JSON, or TCB structured."""
    stripped = line.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            json.loads(stripped)
            return "json"
        except (json.JSONDecodeError, ValueError):
            pass
    if re.match(r"^\d{4}-\d{2}-\d{2}", stripped):
        return "timestamped"
    return "plain"


def parse_tcb_log_line(line: str) -> dict:
    """Parse a single TCB-structured log line into components."""
    result = {"raw": line, "ts": "", "level": "", "fn": "", "msg": ""}
    stripped = line.strip()

    # Try JSON first
    if stripped.startswith("{"):
        try:
            obj = json.loads(stripped)
            result["ts"] = obj.get("timestamp", "")
            result["level"] = obj.get("level", obj.get("severity", ""))
            result["msg"] = obj.get("message", obj.get("msg", str(obj)))
            result["json"] = obj
            return result
        except (json.JSONDecodeError, ValueError):
            pass

    # Try timestamp prefix: 2026-05-02T12:00:00.000Z  [INFO]  [fn-name] message
    ts_match = re.match(
        r"^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[.\d]*Z?)\s*\[(\w+)\]\s*(?:\[([^\]]+)\])?\s*(.*)",
        stripped
    )
    if ts_match:
        result["ts"] = ts_match.group(1)
        result["level"] = ts_match.group(2)
        result["fn"] = ts_match.group(3) or ""
        result["msg"] = ts_match.group(4)
        return result

    # Level prefix: [ERROR] message or ERROR: message
    level_match = re.match(r"^\[(ERROR|WARN|WARNING|INFO|DEBUG)\]\s*(.*)", stripped, re.IGNORECASE)
    if level_match:
        result["level"] = level_match.group(1).upper()
        result["msg"] = level_match.group(2)
        return result

    result["msg"] = stripped
    return result


def format_log_line(parsed: dict, color: bool = True) -> str:
    """Format a parsed log line with optional color."""
    RESET = "\033[0m" if color else ""
    RED = "\033[31m" if color else ""
    YELLOW = "\033[33m" if color else ""
    GREEN = "\033[32m" if color else ""
    DIM = "\033[2m" if color else ""

    ts = parsed.get("ts", "")
    level = parsed.get("level", "")
    fn = parsed.get("fn", "")
    msg = parsed.get("msg", parsed.get("raw", ""))

    # Color by level
    if level in ("ERROR", "ERR", "FATAL", "EX"):
        level_str = RED + "[" + level + "]" + RESET
    elif level in ("WARN", "WARNING", "WN"):
        level_str = YELLOW + "[" + level + "]" + RESET
    elif level in ("INFO", "DEBUG"):
        level_str = GREEN + "[" + level + "]" + RESET
    else:
        level_str = DIM + "[" + level + "]" + RESET if level else ""

    fn_str = DIM + "[" + fn + "]" + RESET if fn else ""
    ts_str = DIM + ts + " " if ts else ""

    return ts_str + level_str + fn_str + " " + msg


def level_rank(level: str) -> int:
    """Rank log level for filtering."""
    l = level.upper()
    if l in ("FATAL", "ERROR", "ERR", "EX"):
        return 3
    if l in ("WARN", "WARNING", "WN"):
        return 2
    if l in ("INFO"):
        return 1
    return 0


def cmd_list_functions(env_id: str) -> int:
    """List all cloud functions and exit."""
    print("\n" + SEP)
    label = f"Functions in env: {env_id or 'default'}"
    print(label)
    print(SEP)
    cmd = ["tcb", "fn", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, err = run(cmd + ["--json"])
    if code != 0:
        print(f"FAIL: {err}")
        return 1
    try:
        fns = json.loads(out)
        fn_list = fns if isinstance(fns, list) else fns.get("data", [])
        for fn in fn_list:
            name = fn.get("FunctionName", fn.get("Name", "?"))
            status = fn.get("Status", "?")
            runtime = fn.get("Runtime", "?")
            icon = "OK" if status == "Active" else "??"
            print(f"  [{icon}] {name:<35} {runtime:<12} {status}")
        print(f"\n  Total: {len(fn_list)} function(s)")
    except json.JSONDecodeError:
        print(out[:500])
    return 0


def cmd_query_logs(
    env_id: str, fn: str, keyword: str, since: str, err_only: bool,
    trace_id: str, json_out: bool, analyze: bool, tail: bool,
    limit: int, start_time: str, end_time: str
) -> int:
    """Query and display logs."""
    if not fn and not since:
        print("FAIL: --fn <function-name> or --since <duration> required")
        return 2

    start_ts = ""
    if since:
        dt = parse_duration(since)
        start_ts = dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    if start_time:
        start_ts = start_time

    if fn:
        return _query_fn_logs(env_id, fn, keyword, err_only, trace_id, json_out,
                              analyze, tail, limit, start_ts)

    return _grep_all_functions(env_id, keyword, trace_id, err_only, json_out, limit)


def _query_fn_logs(env_id: str, fn: str, keyword: str, err_only: bool,
                    trace_id: str, json_out: bool, analyze: bool, tail: bool,
                    limit: int, start_ts: str) -> int:
    """Query logs from a specific function."""
    if tail:
        return _tail_logs(env_id, fn, keyword, trace_id, json_out)

    cmd = ["tcb", "logs", fn]
    if env_id:
        cmd.extend(["--envId", env_id])
    if start_ts:
        cmd.extend(["--startTime", start_ts])
    cmd.extend(["--limit", str(limit)])

    code, out, err = run(cmd)
    if code != 0:
        print(f"FAIL: {err}")
        return 1

    raw_lines = out.splitlines() if out else []

    if trace_id:
        raw_lines = [l for l in raw_lines if trace_id in l]
        if not raw_lines:
            print(f"WARN: No logs found with trace ID: {trace_id}")
            return 1

    if err_only:
        filtered = []
        for l in raw_lines:
            p = parse_tcb_log_line(l)
            if level_rank(p["level"]) >= 2:
                filtered.append(l)
            elif "error" in l.lower() or "exception" in l.lower() or "fail" in l.lower():
                filtered.append(l)
        raw_lines = filtered
        if not raw_lines:
            print(f"WARN: No error logs found for {fn}")
            return 0

    if keyword:
        raw_lines = [l for l in raw_lines if keyword.lower() in l.lower()]
        if not raw_lines:
            print(f"WARN: No logs matching '{keyword}'")
            return 1

    if json_out:
        for line in raw_lines[:limit]:
            p = parse_tcb_log_line(line)
            if "json" in p:
                print(json.dumps(p["json"]))
            else:
                print(json.dumps(p))
        return 0

    if analyze:
        return _analyze_logs(fn, raw_lines)

    # Default: pretty print
    print(f"\nLogs for [{fn}] (showing {len(raw_lines)} lines)\n")
    for line in raw_lines[:limit]:
        p = parse_tcb_log_line(line)
        print(format_log_line(p))
    print(f"\n  Total: {len(raw_lines)} log line(s)")
    return 0


def _grep_all_functions(env_id: str, keyword: str, trace_id: str,
                        err_only: bool, json_out: bool, limit: int) -> int:
    """Search across all functions."""
    cmd = ["tcb", "fn", "list"]
    if env_id:
        cmd.extend(["--envId", env_id])
    code, out, _ = run(cmd + ["--json"])
    if code != 0:
        print(f"FAIL: Cannot list functions: {out}")
        return 1
    try:
        fns = json.loads(out)
        fn_list = fns if isinstance(fns, list) else fns.get("data", [])
    except json.JSONDecodeError:
        print("FAIL: Cannot parse function list")
        return 1

    matches = []
    for fn_entry in fn_list:
        fn_name = fn_entry.get("FunctionName", fn_entry.get("Name", ""))
        if not fn_name:
            continue

        code2, log_out, _ = run(["tcb", "logs", fn_name])
        if code2 != 0:
            continue

        for line in log_out.splitlines():
            if trace_id and trace_id not in line:
                continue
            if keyword and keyword.lower() not in line.lower():
                continue
            if err_only and level_rank(parse_tcb_log_line(line)["level"]) < 2:
                if "error" not in line.lower() and "exception" not in line.lower():
                    continue
            matches.append(f"[{fn_name}] {line}")

    if json_out:
        for m in matches[:limit]:
            print(json.dumps({"message": m}))
    else:
        if matches:
            print(f"\nFound {len(matches)} matching log line(s):\n")
            for m in matches[:limit]:
                p = parse_tcb_log_line(m)
                print(format_log_line(p))
        else:
            print("WARN: No matching logs found")
            return 1
    return 0


def _analyze_logs(fn: str, lines: list) -> int:
    """Analyze log patterns and produce summary."""
    print(f"\nLog Analysis — [{fn}]")
    print(SEP)
    print(f"  Total log lines : {len(lines)}")
    print(SEP)

    error_lines = []
    warn_lines = []
    info_lines = []
    trace_spans = []

    for line in lines:
        p = parse_tcb_log_line(line)
        rank = level_rank(p["level"])
        if rank >= 3:
            error_lines.append(p)
        elif rank == 2:
            warn_lines.append(p)
        elif rank == 1:
            info_lines.append(p)

        if p.get("json"):
            obj = p["json"]
            if isinstance(obj, dict) and obj.get("type") == "span":
                trace_spans.append(obj)

    print(f"  ERROR / FATAL  : {len(error_lines)}")
    print(f"  WARN           : {len(warn_lines)}")
    print(f"  INFO           : {len(info_lines)}")
    print(f"  Trace spans    : {len(trace_spans)}")

    if error_lines:
        print(SEP)
        print(f"  ERROR lines ({len(error_lines)}):\n")
        for p in error_lines[:10]:
            print(f"    {format_log_line(p)}")
        if len(error_lines) > 10:
            print(f"    ... and {len(error_lines) - 10} more")

    if warn_lines:
        print(SEP)
        print(f"  WARN lines ({len(warn_lines)}):\n")
        for p in warn_lines[:5]:
            print(f"    {format_log_line(p)}")
        if len(warn_lines) > 5:
            print(f"    ... and {len(warn_lines) - 5} more")

    if trace_spans:
        print(SEP)
        print(f"  Trace spans found ({len(trace_spans)}):\n")
        from collections import defaultdict
        svc_dur = defaultdict(lambda: {"count": 0, "total_us": 0})
        for span in trace_spans:
            svc = span.get("service", "unknown")
            svc_dur[svc]["count"] += 1
            svc_dur[svc]["total_us"] += span.get("duration", 0)
        for svc, stats in sorted(svc_dur.items(), key=lambda x: -x[1]["total_us"]):
            avg = stats["total_us"] / max(stats["count"], 1)
            print(f"    {svc:<30} {stats['count']:>4} spans  avg {avg/1000:.2f}ms")

    print(SEP)
    return 1 if error_lines else 0


def _tail_logs(env_id: str, fn: str, keyword: str, trace_id: str, json_out: bool):
    """Tail logs in watch mode."""
    print(f"Tailing logs for [{fn}] — Ctrl+C to stop\n")
    seen = set()
    while True:
        cmd = ["tcb", "logs", fn]
        if env_id:
            cmd.extend(["--envId", env_id])
        code, out, err = run(cmd, timeout=30)
        if code == 0 and out:
            for line in out.splitlines():
                h = hash(line)
                if h in seen:
                    continue
                seen.add(h)
                if trace_id and trace_id not in line:
                    continue
                if keyword and keyword.lower() not in line.lower():
                    continue
                p = parse_tcb_log_line(line)
                print(format_log_line(p))
        time.sleep(5)


# ─── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Advanced CloudBase log querying",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  query-logs.py --envId my-env --fn create-order --since -1h\n"
            "  query-logs.py --envId my-env --fn create-order --err\n"
            "  query-logs.py --envId my-env --trace 0000ABC123DEF456789012345678901234567\n"
            "  query-logs.py --envId my-env --fn create-order --analyze\n"
            "  query-logs.py --envId my-env --fn create-order --json | jq '.level'\n"
            "  query-logs.py --envId my-env --fn create-order --tail\n"
        ),
    )
    parser.add_argument("--envId", help="TCB Environment ID")
    parser.add_argument("--fn", dest="fn", help="Function name")
    parser.add_argument("--kw", dest="keyword", help="Keyword filter")
    parser.add_argument("--since", help="Time window (e.g. -1h, -30m, -1d)")
    parser.add_argument("--start", dest="startTime", help="Start time (ISO8601)")
    parser.add_argument("--end", dest="endTime", help="End time (ISO8601)")
    parser.add_argument("--err", action="store_true", help="Show errors and warnings only")
    parser.add_argument("--trace", dest="traceId", help="Filter by Trace ID (32-char hex)")
    parser.add_argument("--json", action="store_true", help="Raw JSON output")
    parser.add_argument("--analyze", action="store_true", help="Analyze log patterns")
    parser.add_argument("--tail", action="store_true", help="Tail logs in watch mode")
    parser.add_argument("--limit", type=int, default=200, help="Max log lines (default 200)")
    parser.add_argument("--list-fns", dest="listFns", action="store_true",
                        help="List functions and exit")

    args = parser.parse_args()

    if args.listFns:
        sys.exit(cmd_list_functions(args.envId))

    if not args.fn and not args.since and not args.traceId:
        print("FAIL: --fn, --since, or --trace required (or use --list-fns to see functions)")
        sys.exit(2)

    sys.exit(cmd_query_logs(
        env_id=args.envId or "",
        fn=args.fn or "",
        keyword=args.keyword or "",
        since=args.since or "",
        err_only=args.err,
        trace_id=args.traceId or "",
        json_out=args.json,
        analyze=args.analyze,
        tail=args.tail,
        limit=args.limit,
        start_time=args.startTime or "",
        end_time=args.endTime or "",
    ))


if __name__ == "__main__":
    main()
