# Project Management — 项目管理规范

## 目录

1. [项目初始化](#项目初始化)
2. [多项目隔离](#多项目隔离)
3. [状态追踪](#状态追踪)
4. [资产管理](#资产管理)
5. [Git 规范](#git-规范)

---

## 项目初始化

### 初始化流程

1. 运行 `scripts/init_project.py --name <project-name>`
2. 填写项目配置（交互式）：
   - CloudBase 环境 ID (envId)
   - 小程序 AppID
   - 项目描述
3. 生成标准目录结构
4. 初始化 Git 仓库

### config.json 格式

```json
// .harness/config.json
{
  "name": "my-mini-program",
  "description": "一个电商小程序",
  "cloudbase": {
    "envId": "prod-xxxxx",
    "devEnvId": "dev-xxxxx"
  },
  "wechat": {
    "appid": "wx1234567890abcdef"
  },
  "created": "2026-04-28T11:00:00Z",
  "lastUpdated": "2026-04-28T11:00:00Z"
}
```

---

## 多项目隔离

## 多项目隔离

### 隔离原则

1. **目录隔离** — 每个项目独立目录，互不嵌套
2. **环境隔离** — 不同项目使用不同 CloudBase 环境
3. **状态隔离** — 每个项目独立的 `.harness/state.json`
4. **代码隔离** — 独立 Git 仓库

### 目录结构

```
~/.openclaw/
├── projects/           # 所有项目根目录（独立于 workspace git 仓库）
│   └── {project-name}/
│       ├── .harness/  # 项目配置、状态、部署历史
│       ├── specs/     # 需求文档
│       ├── design/    # 设计文档
│       ├── src/       # 源码
│       ├── cloud/     # 云函数
│       └── tests/     # 测试
├── skills/            # 所有 skill 目录（由 clawhub/skillhub 管理）
│   └── tcb-harness/   # 本 skill
├── .harness/
│   └── current        # 当前活跃项目名称
└── workspace/         # AI 配置仓库（.git 独立，不含项目源码）
    ├── AGENTS.md
    ├── SOUL.md
    └── ...
```

**脚本路径推导：**
- `SKILL_DIR = ~/.openclaw/skills/tcb-harness`
- `WORKSPACE = ~/.openclaw`（`SKILL_DIR.parent.parent`）
- `PROJECTS_DIR = ~/.openclaw/projects`
- `HARNESS_DIR = ~/.openclaw/.harness`
- `CURRENT_FILE = ~/.openclaw/.harness/current`

### 项目上下文切换

每个项目独立目录，但需要持久化"当前活跃项目"以便脚本默认操作。

**切换当前项目：**

```bash
# 切换到指定项目
python3 scripts/init_project.py switch <project-name>

# 查看当前项目
python3 scripts/init_project.py switch

# 清除当前项目
python3 scripts/init_project.py switch --clear
```

**当前项目文件：** `~/.openclaw/workspace/.harness/current`

**脚本自动读取逻辑：**
- 有 `--name <project>` → 使用指定项目
- 无 `--name` → 读取 `.harness/current` 作为当前项目
- 两者都没有 → 报错并提示运行 `switch`

**已支持自动读取的脚本：**
- `project_status.py`
- `init_project.py` 各子命令

处理多个项目时：

1. 先确认当前操作的项目名称
2. 读取该项目的 `.harness/state.json`
3. 在项目目录下执行操作
4. 切换项目时重新读取新项目状态

---

## 状态追踪

### state.json 格式

```json
{
  "phase": "coding",
  "status": "in_progress",
  "currentSpec": "v2-features",
  "tasks": {
    "total": 12,
    "completed": 5,
    "inProgress": 2,
    "blocked": 0
  },
  "lastActivity": {
    "action": "coding",
    "task": "implement-order-service",
    "timestamp": "2026-04-28T11:30:00Z"
  },
  "phaseHistory": [
    { "phase": "init", "completedAt": "2026-04-25T10:00:00Z" },
    { "phase": "spec", "completedAt": "2026-04-26T14:00:00Z" },
    { "phase": "design", "completedAt": "2026-04-27T16:00:00Z" }
  ],
  "blockers": []
}
```

### 状态查询

```bash
python3 scripts/project_status.py --name <project-name>
```

输出：

```
📋 项目: shop-miniapp
📌 阶段: coding (进行中)
📄 当前 Spec: v2-features
✅ 任务进度: 5/12 (42%)
🔄 进行中: implement-order-service, create-product-component
⚠️  阻塞: 无
📅 里程碑: init ✓ → spec ✓ → design ✓ → coding ◉ → testing ○ → deploy ○
```

### 状态更新时机

| 事件 | 更新内容 |
|------|---------|
| 阶段完成 | phase + phaseHistory |
| 任务开始/完成 | tasks 计数 + lastActivity |
| 遇到阻塞 | blockers + status |
| 每次操作 | lastActivity.timestamp |

---

## 资产管理

### 产出清单

| 阶段 | 产出 | 位置 |
|------|------|------|
| Spec | requirements.md, design.md, tasks.md | specs/{spec-name}/ |
| Design | UI/Service/Frontend 设计文档 | design/{domain}/ |
| Coding | 源代码 + 云函数 | src/, cloud/ |
| Testing | 测试用例 + 数据 + 报告 | tests/ |
| Deploy | 部署配置 + 版本记录 | .harness/ |

### 版本关联

每次部署记录：

```json
// .harness/deploy-history.json
[
  {
    "version": "1.0.0",
    "deployedAt": "2026-04-28T15:00:00Z",
    "spec": "v2-features@abc123",
    "commitHash": "def456",
    "testReport": "tests/reports/test-report-20260428.md",
    "status": "released",
    "cloudFunctionVersions": {
      "create-order": "v3",
      "pay-callback": "v2"
    }
  }
]
```

---

## Git 规范

### 提交规范

```
<type>(<scope>): <subject>

<body>
```

**Type:**

| Type | 说明 |
|------|------|
| feat | 新功能 |
| fix | Bug 修复 |
| test | 测试相关 |
| design | 设计文档 |
| spec | 需求文档 |
| refactor | 重构 |
| chore | 构建/配置 |

**Scope:** 页面/模块名，如 `order`, `home`, `cloud-functions`

**示例:**
```
feat(order): implement order creation service

- Add order service with CloudBase integration
- Add order model with validation
- Add unit tests for createOrder

Closes: tasks.md item 3
Spec: specs/v2-features/requirements.md FR-01
```

### 分支策略

| 分支 | 用途 | 命名 |
|------|------|------|
| main | 生产分支 | main |
| develop | 开发分支 | develop |
| feature | 功能分支 | feature/{task-name} |
| hotfix | 紧急修复 | hotfix/{issue-name} |

### 关键提交节点

- Spec 确认后 → 提交 `spec(spec-name): confirmed requirements`
- Design 确认后 → 提交 `design(spec-name): confirmed design`
- TDD 每个绿灯 → 提交 `feat(module): pass TC-xxx`
- 阶段完成 → 提交 `chore: complete {phase} phase`
