# Service Design Guide — 服务设计规范

## 目录

1. [API 契约设计](#api-契约设计)
2. [数据模型设计](#数据模型设计)
3. [CloudBase 服务规划](#cloudbase-服务规划)
4. [安全规则设计](#安全规则设计)
5. [产出规范](#产出规范)

---

## API 契约设计

### 云函数接口规范

每个云函数遵循统一契约：

```typescript
// 请求格式
interface CloudRequest {
  action?: string        // 操作类型（可选，用于同函数多操作）
  [key: string]: any     // 业务参数
}

// 响应格式
interface CloudResponse<T = any> {
  code: number           // 0=成功, 400=参数错误, 401=未授权, 500=服务错误
  message: string        // 人类可读的消息
  data?: T               // 业务数据
  requestId?: string     // 请求追踪 ID
}
```

### 设计原则

1. **一个云函数一个职责** — `create-order` 只创建订单，不处理支付
2. **后端校验不信任前端** — 所有数据校验在云函数内完成
3. **OPENID 由后端获取** — 通过 `cloud.getWXContext()` 获取，不从前端传入
4. **幂等设计** — 关键操作（支付、创建）需支持幂等

### API 文档模板

```markdown
## create-order

创建订单

**云函数:** `cloud/create-order`

### 请求

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| items | Item[] | 是 | 商品列表 |
| items[].productId | string | 是 | 商品 ID |
| items[].quantity | number | 是 | 数量 (≥1) |
| couponId | string | 否 | 优惠券 ID |

### 响应

**成功 (code: 0)**
\```json
{
  "code": 0,
  "data": {
    "orderId": "o_abc123",
    "totalAmount": 199.8,
    "discountAmount": 10,
    "payAmount": 189.8
  }
}
\```

**参数错误 (code: 400)**
\```json
{
  "code": 400,
  "message": "Items list cannot be empty"
}
\```

### 前置条件
- 用户已登录（自动获取 OPENID）

### 副作用
- 在 orders 集合新增记录
- 在 order_items 集合新增记录
- 扣减优惠券（如使用）
```

---

## 数据模型设计

### NoSQL 集合设计

#### 设计原则

1. **按访问模式设计** — 根据查询场景决定文档结构，而非实体关系
2. **嵌套 vs 引用** — 一对多且总是一起读取 → 嵌入；独立访问 → 引用
3. **冗余换性能** — 小程序场景读多写少，适度冗余减少 JOIN
4. **分页友好** — 大列表使用分页查询，设计合适的索引和排序字段

#### 集合文档模板

```markdown
## orders 集合

### Schema

| 字段 | 类型 | 必填 | 索引 | 说明 |
|------|------|------|------|------|
| _id | string | 自动 | 主键 | |
| openid | string | 是 | 是 | 用户标识 |
| items | OrderItem[] | 是 | 否 | 订单商品（嵌入） |
| totalAmount | number | 是 | 否 | 总金额 |
| status | enum | 是 | 是 | created/paid/shipped/completed/cancelled |
| createdAt | date | 是 | 是（降序） | 创建时间 |
| updatedAt | date | 是 | 否 | 更新时间 |

### 索引设计

```json
{
  "indexes": [
    { "keys": { "openid": 1, "createdAt": -1 }, "name": "openid_created" },
    { "keys": { "status": 1 }, "name": "status" }
  ]
}
```

### 访问模式

| 查询场景 | 条件 | 排序 | 频率 |
|---------|------|------|------|
| 我的订单列表 | openid=当前用户 | createdAt desc | 高 |
| 待处理订单 | status=created | createdAt asc | 中 |
| 订单详情 | _id=订单ID | — | 高 |

### 数据量预估

- 日增量: ~1000 条
- 单文档大小: ~1KB
- 半年总量: ~180K 条
```

---

## CloudBase 服务规划

### 服务选型

| 需求 | CloudBase 服务 | 配置 |
|------|---------------|------|
| 用户数据存储 | NoSQL 数据库 | 按集合划分 |
| 关系型查询 | MySQL 数据库 | 适合报表/统计场景 |
| 文件存储 | 云存储 | 图片/文件上传 |
| 后端逻辑 | 云函数 | 按职责拆分 |
| 长时任务 | CloudRun | 适合 >20s 的任务 |
| 定时任务 | 云函数定时触发 | cron 配置 |
| 消息推送 | 订阅消息 | 模板 ID 配置 |

### 云函数清单模板

```markdown
## 云函数清单

| 函数名 | 职责 | 运行时 | 超时 | 触发方式 |
|--------|------|--------|------|---------|
| create-order | 创建订单 | Node.js 16 | 5s | HTTP |
| pay-callback | 支付回调 | Node.js 16 | 10s | HTTP |
| daily-stats | 每日统计 | Node.js 16 | 20s | 定时 (0 2 * * *) |
```

---

## 安全规则设计

### NoSQL 安全规则

```json
{
  "read": true,
  "write": "doc.openid == auth.openid"
}
```

### 规则模板

```markdown
## 安全规则

### orders 集合

| 操作 | 规则 | 说明 |
|------|------|------|
| 读 | `doc.openid == auth.openid` | 只能读自己的订单 |
| 写 | `doc.openid == auth.openid` | 只能写自己的订单 |
| 创建 | `auth.openid != null` | 已登录可创建 |

### products 集合

| 操作 | 规则 | 说明 |
|------|------|------|
| 读 | `true` | 公开可读 |
| 写 | `auth.openid in get('database.admins').admins` | 仅管理员可写 |
```

### 安全审查清单

- [ ] 非公开集合有 openid 校验
- [ ] 管理类操作有权限校验
- [ ] 云函数内再次校验权限（不依赖前端）
- [ ] 敏感字段未暴露给前端（密码、密钥等）
- [ ] 批量操作有速率限制

---

## 产出规范

所有服务设计产出保存在 `design/service/` 目录：

```
design/service/
├── api-contract.md       # API 契约文档
├── data-model.md         # 数据模型设计
├── security-rules.md     # 安全规则配置
├── cloud-functions.md    # 云函数清单和配置
└── migration.md          # 数据迁移方案（如有）
```
