# 公众号前端设计指南

> 适用平台：微信公众平台（订阅号/服务号/企业微信）

---

## 平台特点

| 维度 | 公众号（OA） | 小程序（MP） |
|------|-------------|-------------|
| 运行容器 | 微信内置浏览器（WebView） | 微信原生视图 |
| 认证方式 | OAuth 2.0（snsapi_userinfo / snsapi_base） | OPENID 静默授权 |
| SDK | 微信 JSSDK（`wx` 对象） | 小程序 API（`wx` 对象） |
| 部署目标 | CloudBase 静态托管（H5） | 微信服务器 + CloudBase 后台 |
| 用户感知 | 打开网页，体验接近原生 | 独立 App 体验 |
| 分享能力 | 分享到好友/朋友圈（自定义文案+图标） | 转发卡片 |
| 推送消息 | 模板消息（下发） | 订阅消息 |

---

## 技术栈

- **框架**：React 18 + Vite + TypeScript
- **UI**：TDesign React（TDesign 组件库）
- **样式**：Tailwind CSS
- **路由**：React Router v6
- **状态**：Zustand
- **数据请求**：TanStack Query
- **微信 SDK**：微信 JSSDK 1.6.0
- **云端**：CloudBase Web SDK（`@cloudbase/js-sdk`）

---

## 目录结构

```
src/
├── App.jsx                      # 根组件（路由配置）
├── main.js                      # 入口
├── styles/
│   └── global.css               # 全局样式 + Tailwind
├── utils/
│   └── wxJSSDK.js               # 微信 JSSDK 初始化封装
├── pages/
│   └── home/
│       └── HomePage.jsx
├── components/                   # 业务组件
├── services/
│   ├── cloud.js                  # CloudBase 云函数调用封装
│   └── auth.js                   # OAuth 登录 + Token 管理
└── hooks/
    └── useWxJSSDK.js             # JSSDK 初始化 Hook
```

---

## 认证流程（OAuth 2.0）

```
用户访问网页
    ↓
检查本地存储的 OpenID / UnionID
    ↓（无 Token）
重定向到微信授权页面
    ↓
微信回调 → 获取 code
    ↓
后端云函数用 code 换 UnionID/OpenID + session_key
    ↓
后端返回业务 Token 给前端
    ↓
前端存储 Token，后续请求带 Token 调用云函数
```

**注意**：
- 服务号必须配置授权回调域名（JS 安全域名）
- `snsapi_base` 仅获取 OpenID（静默，无弹窗）
- `snsapi_userinfo` 获取用户信息（需用户手动同意）
- 换 Token 的逻辑必须在**后端云函数**中完成，禁止将 AppSecret 暴露在前端

---

## JSSDK 使用规范

### 初始化（每个页面都要做）

```js
// pages/HomePage.jsx
import { initJSSDK, getCurrentUrl } from '@/utils/wxJSSDK'
import cloud from '@/services/cloud'

async function fetchJSSDKConfig() {
  const url = getCurrentUrl()
  const res = await cloud.callFunction('getJSSDKConfig', { url })
  return res
}

useEffect(() => {
  initJSSDK(await fetchJSSDKConfig())
}, [])
```

### 常见 JSSDK 调用

```js
// 自定义分享给好友
wx.updateAppMessageShareData({
  title: '分享标题',
  desc: '分享描述',
  link: window.location.href,
  imgUrl: 'https://example.com/share.png',
})

// 获取地理位置
wx.getLocation({
  type: 'gcj02',
  success(res) { console.log(res.latitude, res.longitude) }
})
```

---

## 与小程序的关键区别

| 场景 | 公众号 | 小程序 |
|------|--------|--------|
| 获取用户手机号 | 通过后端云函数 + 微信解密 | `button open-type="getPhoneNumber"` |
| 支付 | 公众号支付（H5 支付）| 小程序支付 |
| 跳转小程序 | `wx.miniProgram.navigateTo({ appId, path })` | — |
| 页面间通信 | URL 参数 / localStorage | App 实例 / globalData |
| 扫码 | `wx.scanQRCode` | `wx.scanCode` |
| 分享朋友圈 | 只能通过 H5 页面分享卡片 | 不能直接分享到朋友圈 |

---

## 坑点汇总

1. **签名 URL**：必须是调用 JSSDK 页面的完整 URL，hash 路由需去掉 `#` 及后面部分
2. **IOS vs Android**：JSSDK 在两个平台的 `ready` 时机不同，禁止在 `ready` 外部调用 API
3. **缓存问题**：微信内置浏览器会缓存页面，JSSDK 签名失效后需重新初始化
4. **调试**：JSSDK `debug: true` 会在控制台输出具体哪个 API 不可用
5. **jsapi_ticket**：有效期 7200 秒，需要后端缓存并全局刷新
6. **公众平台后台**：必须添加 JS 安全域名（需 HTTPS）
