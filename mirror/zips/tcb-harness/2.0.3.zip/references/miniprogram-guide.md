# Mini Program Guide — 小程序专项设计

## 技术选型

| 技术 | 选型 | 说明 |
|------|------|------|
| 组件库 | **TDesign Miniprogram** | 腾讯官方小程序组件库，覆盖 50+ 基础组件 |
| 框架 | 原生小程序 / Taro / uni-app | 复杂项目优先选 Taro |
| 语言 | TypeScript | 强类型，推荐开启 |
| CSS | WXSS + Design Tokens | 使用 TDesign 主题变量 |

### TDesign Miniprogram 接入

```bash
npm install tdesign-miniprogram
├── app.json                     # 全局配置
├── app.wxss                     # 全局样式
├── pages/                       # 页面
│   ├── home/
│   │   ├── index.js
│   │   ├── index.json
│   │   ├── index.wxml
│   │   └── index.wxss
│   └── ...
├── components/                   # 组件
│   ├── common/                  # 通用组件
│   │   ├── loading/
│   │   ├── empty-state/
│   │   └── search-bar/
│   └── business/                # 业务组件
│       ├── order-card/
│       └── product-grid/
├── services/                    # 服务层
│   ├── user.js
│   ├── order.js
│   └── product.js
├── models/                      # 数据模型
│   ├── user.js
│   └── order.js
├── utils/                       # 工具
│   ├── format.js
│   ├── cloud.js                 # CloudBase 初始化
│   └── request.js               # 云函数调用封装
└── config.js                    # 环境配置
```

### project.config.json 必填项

```json
{
  "compileType": "miniprogram",
  "libVersion": "3.3.4",
  "appid": "${appid}",
  "setting": {
    "useCompilerPlugins": ["typescript"],
    "lazyCodeLoading": "requiredComponents"
  }
}
```

---

## 页面设计

### 页面配置 (app.json)

```json
{
  "pages": [
    "pages/home/index",
    "pages/order-list/index",
    "pages/order-detail/index",
    "pages/profile/index"
  ],
  "window": {
    "navigationBarBackgroundColor": "#ffffff",
    "navigationBarTitleText": "",
    "navigationBarTextStyle": "black",
    "backgroundColor": "#f6f6f6"
  },
  "tabBar": {
    "color": "#999999",
    "selectedColor": "#07C160",
    "backgroundColor": "#ffffff",
    "list": [
      { "pagePath": "pages/home/index", "text": "首页", "iconPath": "images/tab-home.png", "selectedIconPath": "images/tab-home-active.png" },
      { "pagePath": "pages/order-list/index", "text": "订单", "iconPath": "images/tab-order.png", "selectedIconPath": "images/tab-order-active.png" },
      { "pagePath": "pages/profile/index", "text": "我的", "iconPath": "images/tab-profile.png", "selectedIconPath": "images/tab-profile-active.png" }
    ]
  }
}
```

### 页面生命周期

```javascript
Page({
  data: { /* 页面状态 */ },

  onLoad(query) {
    // 页面加载时调用，可获取页面参数
    this.loadData(query)
  },

  onShow() {
    // 页面显示时调用，适合刷新数据
  },

  onReady() {
    // 页面初次渲染完成
  },

  onHide() {
    // 页面隐藏
  },

  onUnload() {
    // 页面卸载
  },

  onPullDownRefresh() {
    // 下拉刷新
    await this.loadData()
    wx.stopPullDownRefresh()
  },

  onReachBottom() {
    // 上拉加载
    this.loadMore()
  }
})
```

---

## 组件规范

### Component 构造

```javascript
Component({
  options: {
    styleIsolation: 'isolated',    // 样式隔离
    multipleSlots: true,           // 多 slot
    pureDataPattern: /^_/          // 以 _ 开头的 data 为纯粹数据
  },

  properties: {
    title: { type: String, value: '' },
    loading: { type: Boolean, value: false }
  },

  data: {
    // 组件内部状态
  },

  methods: {
    onTap() {
      this.triggerEvent('action', { value: this.data.title })
    }
  }
})
```

### 组件引用

```json
// page.json
{
  "usingComponents": {
    "empty-state": "/components/common/empty-state/index",
    "order-card": "/components/business/order-card/index"
  }
}
```

---

## 路由与导航

### 页面栈操作

| API | 行为 | 页面栈 |
|-----|------|--------|
| `wx.navigateTo` | 新开页面 | +1（可返回） |
| `wx.redirectTo` | 替换当前页 | =（不可返回） |
| `wx.switchTab` | 切换 TabBar | 清除非 TabBar 栈 |
| `wx.reLaunch` | 重新加载 | =0（全清除） |
| `wx.navigateBack` | 返回 | -1 |

### 页面栈深度管理

最大深度 10 层。超过时：
- 列表→详情→表单→预览等长链路使用 `redirectTo` 替换 `navigateTo`
- 在 `app.json` 的 `maxRuntimeQueueSize` 限制队列

### 路由传参

```javascript
// A 页面跳转到 B 页面
wx.navigateTo({
  url: '/pages/order-detail/index?id=123&status=paid'
})

// B 页面 onLoad 获取
onLoad(query) {
  const { id, status } = query
}
```

---

## 分包加载

### 分包原则

| 分包类型 | 条件 | 好处 |
|---------|------|------|
| 普通分包 | 按业务模块划分 | 减少主包体积 |
| 独立分包 | 无需加载主包即可访问 | 可独立上线 |
| 分包预加载 | TabBar 页面预下载 | 提升体验 |

### 配置示例

```json
{
  "subPackages": [
    {
      "root": "package-order",
      "name": "order",
      "pages": [
        "pages/confirm/index",
        "pages/pay-result/index"
      ]
    },
    {
      "root": "package-admin",
      "name": "admin",
      "independent": true,
      "pages": [
        "pages/dashboard/index"
      ]
    }
  ],
  "preloadRule": {
    "pages/home/index": {
      "network": "wifi",
      "packages": ["package-order"]
    }
  }
}
```

### 体积限制

- 主包 ≤ 2MB
- 单个分包 ≤ 2MB
- 总体积 ≤ 16MB

---

## 微信特性集成

### 订阅消息

```javascript
// 请求订阅
async function requestSubscribeMessage(templateId) {
  return new Promise((resolve, reject) => {
    wx.requestSubscribeMessage({
      tmplIds: [templateId],
      success(res) {
        resolve(res)
      },
      fail(err) {
        reject(err)
      }
    })
  })
}

// 在需要时调用
async function onOrderCreate() {
  try {
    await requestSubscribeMessage('your-template-id')
    // 发送订阅消息
    await cloud.callFunction({ name: 'send-subscribed-msg' })
  } catch (e) {
    // 用户拒绝或出错，继续流程
  }
}
```

### 分享

```javascript
// 页面中定义 onShareAppMessage
onShareAppMessage(res) {
  if (res.from === 'button') {
    // 来自页面内转发按钮
  }
  return {
    title: '推荐一个好物',
    path: '/pages/product-detail/index?id=' + this.data.productId,
    imageUrl: '/images/share-product.png'
  }
}

// 开启分享到朋友圈
onShareTimeline() {
  return {
    title: '推荐一个好物',
    query: 'id=' + this.data.productId,
    imageUrl: '/images/share-product.png'
  }
}
```

### 支付

```javascript
async function createPayment(orderId, totalAmount) {
  // 1. 向后台请求支付参数
  const { payInfo } = await cloud.callFunction({
    name: 'create-payment',
    data: { orderId, totalAmount }
  })

  // 2. 调起微信支付
  return new Promise((resolve, reject) => {
    wx.requestPayment({
      ...payInfo,
      success() {
        resolve({ status: 'success' })
      },
      fail(err) {
        reject(err) // user cancel / error
      }
    })
  })
}
```
