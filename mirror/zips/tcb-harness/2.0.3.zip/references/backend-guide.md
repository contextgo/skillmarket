# Backend Guide — 后台专项设计

## 目录

1. [架构选择](#架构选择)
2. [云函数开发](#云函数开发)
3. [云托管开发](#云托管开发)
4. [定时任务](#定时任务)
5. [后台部署配置](#后台部署配置)

---

## 架构选择

### 云函数 vs 云托管

| 维度 | 云函数 | 云托管 |
|------|--------|--------|
| 适用场景 | 事件驱动、调用量不稳定 | 常驻服务、长时间运行、需要 Docker |
| 冷启动 | 有（~100-500ms） | 无（始终运行） |
| 超时 | ≤20s（可配置） | 无限制 |
| 并发 | 按调用计费 | 常驻实例 |
| 部署方式 | 代码包 | Docker 镜像 |

**选择原则：**
- HTTP 触发、短时任务 → 云函数
- WebSocket、长连接、复杂进程 → 云托管
- >20s 的任务 → 云托管

---

## 云函数开发

### 目录结构

```
cloud/
├── create-order/
│   ├── index.js           # 云函数入口
│   ├── package.json       # 依赖（可选）
│   └── node_modules/      # 依赖（可选）
├── pay-callback/
│   └── index.js
└── daily-stats/
    └── index.js
```

### 标准云函数模板

```javascript
// cloud/create-order/index.js
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()

exports.main = async (event, context) => {
  // 获取调用信息（小程序端已登录时自动注入 OPENID）
  const { OPENID, APPID, UNIONID } = cloud.getWXContext()

  // event 包含前端传入的参数
  const { items, couponId } = event

  // ---- 输入校验 ----
  if (!items || !Array.isArray(items) || items.length === 0) {
    return { code: 400, message: 'Items list cannot be empty' }
  }

  // ---- 业务逻辑 ----
  try {
    const totalAmount = items.reduce((sum, i) => sum + i.quantity * i.price, 0)
    const result = await db.collection('orders').add({
      data: {
        openid: OPENID,
        items,
        couponId: couponId || null,
        totalAmount,
        status: 'created',
        createdAt: db.serverDate()
      }
    })

    return {
      code: 0,
      data: {
        orderId: result._id,
        totalAmount
      }
    }
  } catch (err) {
    console.error('createOrder error:', err)
    return { code: 500, message: 'Internal error' }
  }
}
```

### 前端调用

```javascript
// 小程序端
const res = await wx.cloud.callFunction({
  name: 'create-order',
  data: { items: [{ productId: 'p1', quantity: 2, price: 100 }] }
})
if (res.result.code === 0) {
  console.log('Order created:', res.result.data.orderId)
} else {
  wx.showToast({ title: res.result.message, icon: 'error' })
}

// Web 端
const res = await cloud.callFunction({
  name: 'create-order',
  data: { items: [...] }
})
```

### 云函数超时配置

```javascript
// 可在 cloudbaserc.json 中配置
{
  "functions": [
    {
      "name": "daily-stats",
      "timeout": 300,      // 5 分钟
      "memorySize": 256    // MB
    }
  ]
}
```

---

## 云托管开发

### Dockerfile 示例

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

EXPOSE 8080

ENV PORT=8080

CMD ["node", "server.js"]
```

### 服务入口

```javascript
// server.js
const express = require('express')
const cloud = require('@cloudbase/node-sdk')

const app = express()
const tcb = cloud.init()

app.use(express.json())

// 健康检查
app.get('/health', (req, res) => {
  res.json({ status: 'ok' })
})

// 统一错误处理
app.use((err, req, res, next) => {
  console.error('Server error:', err)
  res.status(500).json({ code: 500, message: 'Internal error' })
})

const PORT = process.env.PORT || 8080
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
```

### 云托管部署配置

```json
// cloudbaserc.json
{
  "envId": "prod-env-id",
  "serviceVars": {
    "NODE_ENV": "production"
  },
  "services": {
    "my-api": {
      "framework": "express",
      "entry": "cloud/my-api",
      "dockerFile": "cloud/my-api/Dockerfile",
      "localPath": "./cloud/my-api",
      "instanceType": "PRO"
    }
  }
}
```

---

## 定时任务

### 云函数定时触发

```json
// cloudbaserc.json
{
  "triggers": [
    {
      "name": "daily-stats-trigger",
      "type": "timer",
      "config": "0 0 2 * * *"   // 每天凌晨 2 点
    }
  ]
}
```

### 云函数内判断触发类型

```javascript
exports.main = async (event, context) => {
  // 定时触发时 event.triggerType === 'timer'
  if (event.triggerType === 'timer') {
    // 执行定时统计任务
    return await runDailyStats()
  }

  // 正常 HTTP 触发
  const { action } = event
  switch (action) {
    case 'get-stats': return await getStats(event)
    default: return { code: 400, message: 'Unknown action' }
  }
}
```

---

## 后台部署配置

部署后台时，必须在 `deploy-config.json` 中填写以下详细配置：

### 完整配置模板

```json
// .harness/deploy-config.json
{
  "envId": "prod-env-id",
  "platform": "hybrid",
  "frontend": {
    "miniprogram": {
      "appid": "wx1234567890abcdef",
      "version": "1.0.0",
      "uploadDesc": "v1.0.0 production release"
    },
    "web": {
      "staticHosting": {
        "enabled": true,
        "path": "./dist",
        "config": {
          "replacePublicPath": true
        }
      }
    }
  },
  "backend": {
    "cloudFunctions": [
      {
        "name": "create-order",
        "version": "v2",
        "timeout": 5,
        "memorySize": 256,
        "envVars": {
          "COUPON_ENABLED": "true"
        },
        "triggers": [],
        "status": "deployed"
      },
      {
        "name": "pay-callback",
        "version": "v3",
        "timeout": 10,
        "memorySize": 512,
        "envVars": {},
        "triggers": [
          { "name": "pay-wechat", "type": "http" }
        ],
        "status": "deployed"
      },
      {
        "name": "daily-stats",
        "version": "v1",
        "timeout": 300,
        "memorySize": 256,
        "envVars": {},
        "triggers": [
          { "name": "daily", "type": "timer", "config": "0 0 2 * * *" }
        ],
        "status": "deployed"
      }
    ],
    "cloudRun": [
      {
        "name": "api-service",
        "version": "v1.0.0",
        "image": "ccr.ccs.tencentyun.com/myapp/api-service:v1.0.0",
        "instanceType": "PRO",
        "instanceCount": 2,
        "port": 8080,
        "envVars": {
          "NODE_ENV": "production",
          "LOG_LEVEL": "info"
        },
        "status": "deployed"
      }
    ],
    "database": {
      "noSql": {
        "collections": [
          { "name": "orders", "indexes": [{ "keys": { "openid": 1, "createdAt": -1 } }] },
          { "name": "products", "indexes": [] }
        ]
      },
      "mysql": {
        "enabled": false,
        "tables": []
      }
    },
    "securityRules": {
      "orders": { "read": "doc.openid == auth.openid", "write": "doc.openid == auth.openid" },
      "products": { "read": true, "write": "auth.openid in get('database.admins').admins" }
    }
  },
  "knowledgeBase": {
    "enabled": false,
    "collection": "knowledge_items",
    "functions": ["knowledge"],
    "categories": [
      { "id": "requirement", "name": "需求知识" },
      { "id": "design", "name": "设计知识" },
      { "id": "code", "name": "代码知识" },
      { "id": "operation", "name": "运营知识" },
      { "id": "team", "name": "团队知识" }
    ],
    "securityRules": {
      "read": "doc.status == 'published' || doc.author == auth.openid",
      "write": "doc.author == auth.openid"
    }
  },
  "tracing": {
    "enabled": true,
    "sampled": true,
    "sampleRate": 1.0,
    "collector": { "type": "mongodb", "collection": "traces" }
  }
}
  "deployOrder": [
    "cloudFunctions",
    "cloudRun",
    "database",
    "securityRules",
    "frontend"
  ]
}
```

### 配置校验规则

| 字段 | 规则 |
|------|------|
| `envId` | 必填，与 CloudBase 环境一致 |
| `backend.cloudFunctions` | 至少列出所有云函数，含版本/配置 |
| `backend.cloudRun` | 如使用云托管，必须列出实例规格/副本数 |
| `backend.database.noSql.collections` | 必须列出所有集合名和索引 |
| `backend.securityRules` | 必须为每个集合配置安全规则 |
| `deployOrder` | 必须按顺序列出部署依赖链 |

### 部署流程

```bash
# 1. 部署云函数
for fn in cloudFunctions; do
  npx mcporter call cloudbase.manageFunctions action=deploy name=$fn envId=xxx
done

# 2. 部署云托管
for svc in cloudRun; do
  npx mcporter call cloudbase.cloudRun.deploy name=$svc envId=xxx
done

# 3. 配置数据库集合和索引
npx mcporter call cloudbase.database.createCollection name=orders envId=xxx

# 4. 配置安全规则
npx mcporter call cloudbase.database.setSecurityRule collection=orders rules=xxx

# 5. 部署前端（按平台）
```
