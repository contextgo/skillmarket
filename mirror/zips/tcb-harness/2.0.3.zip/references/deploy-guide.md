# Deploy Guide — 部署发布指南

## 目录

1. [部署流程总览](#部署流程总览)
2. [部署配置规范](#部署配置规范)
3. [小程序部署](#小程序部署)
4. [Web 部署](#web-部署)
5. [后台部署](#后台部署)
6. [混合项目部署](#混合项目部署)
7. [回滚与灰度](#回滚与灰度)

---

## 部署流程总览

```
代码就绪 (tests pass)
    │
    ├─→ 部署后台
    │     ├─→ 云函数部署（按依赖顺序）
    │     ├─→ 云托管部署（如有）
    │     ├─→ 数据库集合创建 + 索引配置
    │     └─→ 安全规则配置
    │
    ├─→ 部署前端
    │     ├─→ 小程序: 构建 → 预览 → 上传
    │     └─→ Web: 构建 → 上传静态资源
    │
    └─→ 验证 → 更新 deploy-history.json
```

### 部署顺序规则

**必须先部署后台，再部署前端。** 前端依赖后台 API，后台未就绪时前端无法正常工作。

| 顺序 | 步骤 | 原因 |
|------|------|------|
| 1 | 云函数/云托管 | 后台服务必须先就绪 |
| 2 | 数据库集合 + 索引 | 云函数依赖数据库 schema |
| 3 | 安全规则 | 确保数据访问权限正确 |
| 4 | 前端小程序 | 依赖后台 API |
| 5 | 前端 Web | 依赖后台 API |

---

## 部署配置规范

### deploy-config.json 规范

每个项目必须在 `.harness/deploy-config.json` 中维护完整的部署配置。**这是部署的 source of truth。**

### 配置校验

部署前运行 `scripts/validate_deploy_config.py`（如果存在）校验配置完整性。不通过时禁止部署。

### 配置模板

```json
// .harness/deploy-config.json
{
  "version": "1.0.0",
  "lastDeployed": "2026-04-28T12:00:00Z",
  "envId": "prod-env-id",
  "platform": "mp | web | hybrid",
  "frontend": { /* 见下方各平台配置 */ },
  "backend": { /* 见下方后台配置 */ },
  "deployOrder": ["backend", "frontend"],
  "dependencies": {
    "envId": "dev-env-id",
    "note": "开发环境用于预发验证"
  }
}
```

---

## 小程序部署

### 步骤 1: 构建

```bash
cd projects/{project-name}/src/miniprogram

# 安装依赖
npm install

# 构建 npm（如使用 npm 包）
# 微信开发者工具 → 工具 → 构建 npm
# 或 CLI:
npx miniprogram-ci build-npm \
  --pp ./src \
  --pkp ./.harness/private.key \
  --appid {appid}
```

### 步骤 2: 预览

```bash
npx miniprogram-ci preview \
  --pp ./src \
  --pkp ./.harness/private.key \
  --appid {appid} \
  --desc "preview: {commit message}" \
  --qrcode-format image \
  --qrcode-output ./preview-qrcode.png
```

**预览验证清单：**
- [ ] 首页正常加载
- [ ] 登录流程正常（获取 OPENID）
- [ ] 关键页面可导航
- [ ] 数据读写正常
- [ ] 无控制台报错

### 步骤 3: 上传

```bash
npx miniprogram-ci upload \
  --pp ./src \
  --pkp ./.harness/private.key \
  --appid {appid} \
  --version {semver} \
  --desc "{changelog summary}"
```

### 配置产出

```json
// deploy-config.json 中小程序配置
"frontend": {
  "miniprogram": {
    "appid": "wx1234567890abcdef",
    "srcPath": "./src/miniprogram",
    "build": {
      "npmInstall": true,
      "npmBuild": true
    },
    "preview": {
      "qrcodeOutput": "./preview-qrcode.png",
      "verified": false
    },
    "upload": {
      "version": "1.0.0",
      "desc": "v1.0.0 production release",
      "committed": false
    },
    "config": {
      "mainPackageSize": "1.8MB",
      "totalSize": "4.2MB"
    }
  }
}
```

---

## Web 部署

### 步骤 1: 构建

```bash
cd projects/{project-name}/src/web

npm install
npm run build
```

### 步骤 2: 上传到 CloudBase 静态托管

```bash
# 通过 MCP 上传
npx mcporter call cloudbase.hosting.upload \
  localPath=./dist \
  remotePath=/ \
  envId={envId}

# 或通过 CLI
npx tccli cloudbase bucket upload \
  --envId {envId} \
  --localPath ./dist \
  --remotePath /
```

### 步骤 3: 配置域名（可选）

```bash
npx mcporter call cloudbase.hosting.bindCustomDomain \
  domain=your-domain.com \
  envId={envId}
```

### 配置产出

```json
// deploy-config.json 中 Web 配置
"frontend": {
  "web": {
    "srcPath": "./src/web",
    "buildCommand": "npm run build",
    "outputPath": "./dist",
    "staticHosting": {
      "enabled": true,
      "envId": "prod-env-id",
      "domain": "https://your-app.cloud.tcbbase.com",
      "customDomain": "your-domain.com",
      "cdn": true
    },
    "buildVerified": false,
    "deployedAt": null
  }
}
```

---

## 后台部署

### 步骤 1: 云函数部署

```bash
# 部署单个云函数
npx mcporter call cloudbase.manageFunctions \
  action=deploy \
  functionName=create-order \
  envId={envId}

# 部署所有云函数（按顺序）
for fn in create-order pay-callback daily-stats; do
  echo "Deploying $fn..."
  npx mcporter call cloudbase.manageFunctions action=deploy functionName=$fn envId={envId}
done
```

### 步骤 2: 云托管部署（如有）

```bash
npx mcporter call cloudbase.cloudRun.deploy \
  serviceName=api-service \
  envId={envId} \
  imageUrl={imageUrl} \
  instanceType=PRO \
  instanceCount=2
```

### 步骤 3: 数据库集合配置

```bash
# 创建集合
npx mcporter call cloudbase.database.createCollection \
  collectionName=orders \
  envId={envId}

# 创建索引
npx mcporter call cloudbase.database.createIndex \
  collectionName=orders \
  keys='{"openid":1,"createdAt":-1}' \
  envId={envId}
```

### 步骤 4: 安全规则配置

```bash
npx mcporter call cloudbase.database.setSecurityRule \
  collection=orders \
  rules='{"read":"doc.openid == auth.openid","write":"doc.openid == auth.openid"}' \
  envId={envId}
```

### 配置产出

```json
// deploy-config.json 中后台配置
"backend": {
  "envId": "prod-env-id",
  "cloudFunctions": [
    {
      "name": "create-order",
      "version": "v2",
      "srcPath": "./cloud/create-order",
      "timeout": 5,
      "memorySize": 256,
      "envVars": {
        "COUPON_ENABLED": "true"
      },
      "triggers": [],
      "status": "deployed",
      "deployedAt": "2026-04-28T12:00:00Z",
      "lastVersion": "v2"
    }
  ],
  "cloudRun": [],
  "database": {
    "noSql": {
      "collections": [
        {
          "name": "orders",
          "indexes": [
            { "keys": { "openid": 1, "createdAt": -1 }, "name": "openid_created" },
            { "keys": { "status": 1 }, "name": "status" }
          ]
        },
        {
          "name": "products",
          "indexes": []
        }
      ]
    },
    "mysql": {
      "enabled": false,
      "tables": []
    }
  },
  "securityRules": {
    "orders": { "read": "doc.openid == auth.openid", "write": "doc.openid == auth.openid" },
    "products": { "read": true, "write": "auth.openid in get('database.admins').admins" }
  },
  "tracing": {
    "enabled": true,
    "sampled": true,
    "sampleRate": 1.0,
    "collector": {
      "type": "mongodb",
      "collection": "traces",
      "envId": "prod-env-id"
    },
    "middleware": {
      "path": "./cloud/middleware/trace.js",
      "autoInject": true,
      "functions": ["create-order", "pay-callback", "trace-collector"]
    },
    "storage": {
      "retentionDays": 7,
      "aggregationInterval": "1h"
    },
    "alerts": [
      { "name": "p99-latency", "metric": "p99", "threshold": 5000, "unit": "ms", "window": "5m" },
      { "name": "error-rate", "metric": "error_rate", "threshold": 1, "unit": "%", "window": "2m" }
    ]
  }
}
```

---

## 混合项目部署

### 部署策略

Hybrid 项目同时包含小程序、Web 和共享后台。部署顺序：

```
1. 共享后台（云函数/云托管）
     ↓
2. 数据库 + 安全规则
     ↓
3. 小程序前端（独立验证）
     ↓
4. Web 前端（独立验证）
     ↓
5. 更新 deploy-config.json
```

### 混合配置示例

```json
// deploy-config.json — hybrid 项目
{
  "platform": "hybrid",
  "envId": "prod-env-id",
  "frontend": {
    "miniprogram": { /* 小程序配置 */ },
    "web": { /* Web 配置 */ }
  },
  "backend": {
    "cloudFunctions": [
      { "name": "create-order", "status": "deployed" },
      { "name": "get-openid", "status": "deployed" }
    ],
    "shared": true,
    "note": "两端共用同一套云函数"
  },
  "deployOrder": ["backend", "frontend.miniprogram", "frontend.web"],
  "verification": {
    "miniprogram": false,
    "web": false
  }
}
```

### 两端验证清单

| 平台 | 验证 URL | 通过标准 |
|------|---------|---------|
| 小程序 | 预览二维码 | 全部功能可操作 |
| Web | 访问域名 | 全部功能可操作 |

---

## 回滚与灰度

### 小程序回滚

微信公众平台 → 版本管理 → 回退到上一版本

### 云函数回滚

```bash
# 获取版本列表
npx mcporter call cloudbase.manageFunctions \
  action=listVersions \
  functionName=create-order \
  envId={envId}

# 回滚到指定版本
npx mcporter call cloudbase.manageFunctions \
  action=rollback \
  functionName=create-order \
  version=v1 \
  envId={envId}
```

### 灰度发布

**小程序灰度（微信平台控制）：**
- 微信公众平台 → 版本管理 → 灰度发布
- 建议节奏：5% → 20% → 50% → 100%

**云函数灰度：**
```bash
# 使用别名实现灰度
npx mcporter call cloudbase.manageFunctions \
  action=updateAlias \
  functionName=create-order \
  alias=prod \
  versionWeights='{"v3": 10, "v2": 90}' \
  envId={envId}
```

### 监控指标

| 指标 | 告警阈值 | 处理 |
|------|---------|------|
| 云函数错误率 | > 1% | 暂停灰度 / 回滚 |
| 云函数平均耗时 | > 2s | 检查性能 |
| 小程序启动耗时 | > 3s | 检查资源加载 |
| HTTP 5xx 错误 | > 0.1% | 回滚 |

### deploy-history.json 记录

每次部署后追加记录：

```json
// .harness/deploy-history.json
[
  {
    "version": "1.0.0",
    "deployedAt": "2026-04-28T15:00:00Z",
    "deployer": "agent",
    "spec": "v1-features@abc123",
    "commitHash": "def456",
    "platform": "hybrid",
    "frontend": {
      "miniprogram": { "version": "1.0.0", "status": "released" },
      "web": { "version": "1.0.0", "status": "released" }
    },
    "backend": {
      "cloudFunctions": {
        "create-order": "v2",
        "pay-callback": "v3"
      },
      "cloudRun": {}
    },
    "testReport": "tests/reports/test-report-20260428.md",
    "verification": { "miniprogram": true, "web": true },
    "status": "stable",
    "rollbacks": []
  }
]
```

---

## HTTP 访问服务故障排查

### 概述

Web 前端通过云函数提供的数据时，需要 HTTP 访问服务将云函数暴露为公开 API。

**API 地址格式对比：**

| 类型 | URL 格式 | 适用场景 | 可用性 |
|------|---------|---------|------|
| 内网域名 | `https://{envId}.service.cloudbase.cn/{function}` | 腾讯云内网（已废弃） | ⚠️ 可能 DNS 失效 |
| HTTP 服务 | `https://{envId}-{envIdSuffix}.ap-shanghai.app.tcloudbase.com/{function}` | 公共访问 | ✅ 推荐 |
| 静态托管 | `https://{envId}-{suffix}.tcloudbaseapp.com/` | 前端页面 | ✅ 正常 |

> 注意：`service.cloudbase.cn` 在某些 VPS/网络环境下 DNS 会 NXDOMAIN，此时只能通过 HTTP 访问服务的公共域名访问。

### 检查 HTTP 访问服务状态

```bash
# 查看所有已创建的服务路径
tcb service list --env-id {envId}

# 查看全局开关状态（输出含 "current status: Enabled/Disabled"）
printf '\n' | tcb service switch --env-id {envId}
```

### 创建云函数的 HTTP 服务路径

```bash
# 为每个云函数创建 HTTP 服务访问路径
tcb service create \
  --service-path "{function-name}" \
  --function "{function-name}" \
  --env-id {envId}

# 批量创建示例（bash）
for fn in auth article-crud skill-crud evaluation-crud section-crud notification-crud user-crud search file-upload wechat-sync; do
  tcb service create --service-path "$fn" --function "$fn" --env-id {envId}
done
```

### 启用/停用 HTTP 访问服务（CLI）

```python
# -*- coding: utf-8 -*-
# 通过 PTY 自动切换 HTTP 访问服务状态
import subprocess, os, time, pty, fcntl, sys

def toggle_http_service(env_id, target='enable'):
    """target: 'enable' 或 'disable'"""
    master_fd, slave_fd = pty.openpty()
    proc = subprocess.Popen(
        ['tcb', 'service', 'switch', '--env-id', env_id],
        stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
        preexec_fn=os.setsid
    )
    fcntl.fcntl(master_fd, fcntl.F_SETFL, fcntl.fcntl(master_fd, fcntl.F_GETFL) | os.O_NONBLOCK)
    
    def flush(timeout=3):
        start = time.time()
        while time.time() - start < timeout:
            try:
                ch = os.read(master_fd, 4096)
                if ch: sys.stdout.write(ch.decode('utf-8', errors='replace'))
            except OSError:
                time.sleep(0.05); continue
    
    time.sleep(3)
    flush(2)
    
    # 上下键选择，Enter 确认
    if target == 'disable':
        os.write(master_fd, b'\x1b[B')  # down arrow
        time.sleep(0.4)
    else:
        os.write(master_fd, b'\x1b[A')  # up arrow (to Enable)
        time.sleep(0.4)
    os.write(master_fd, b'\r')  # enter
    time.sleep(5)
    flush(3)
    
    os.close(master_fd); os.close(slave_fd); proc.terminate()
    print('Done')

# 使用
toggle_http_service('cloud1-2gavd8kj8a1ce021', 'enable')
```

### 浏览器验证方法

**通过 browser tool 测试 API：**
```javascript
// 在 browser profile=user 下执行
(async () => {
  const r = await fetch('https://{envId}-{suffix}.ap-shanghai.app.tcloudbase.com/section-crud', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({action: 'list'})
  });
  const text = await r.text();
  return r.status + ' ' + text.substring(0, 200);
})()
```

**预期成功响应：** `200 {"code":0,"message":"success","data":{...}}`

**失败响应（GATEWAY_ROUTE_DISABLED）：** `403 {"code":"GATEWAY_ROUTE_DISABLED",...}` → 需要在控制台重新切换开关

### 手动在控制台启用（无法通过 CLI 时）

1. 打开 [腾讯云控制台 - HTTP访问服务](https://console.cloud.tencent.com/cloudbase/service/gateway)
2. 登录后找到顶部**全局启用/停用开关**
3. 先**关闭**等待 15 秒，再**打开**
4. 刷新确认状态变为"已启用"

### 前端 API 地址替换

当前端需要切换 API 域名时，批量替换（示例）：

```bash
cd src/web/src

# 替换为 HTTP 服务公共域名（推荐）
sed -i 's|https://{envId}\.service\.cloudbase\.cn|https://{envId}-{suffix}.ap-shanghai.app.tcloudbase.com|g' \
  $(find . -name "*.tsx" -o -name "*.ts")

# 构建并部署
cd ../
npm run build
tcb hosting deploy dist/web --env-id {envId}
```

### 故障诊断流程

```
前端 fetch 失败
    │
    ├─→ 检查网络: curl -v "https://{envId}-{suffix}.ap-shanghai.app.tcloudbase.com/{fn}"
    │       ├─ 200: API 正常，前端代码问题
    │       ├─ 403 GATEWAY_ROUTE_DISABLED: HTTP 访问服务未启用/路由未就绪
    │       └─ DNS/连接失败: 网络问题
    │
    ├─→ 检查 service.cloudbase.cn: nslookup {envId}.service.cloudbase.cn
    │       ├─ NXDOMAIN: service.cloudbase.cn DNS 失效，必须用 HTTP 服务公共域名
    │       └─ 有 IP: 检查是否能连接
    │
    ├─→ 通过 browser tool (profile=user) 测试
    │       └─ 微信浏览器环境测试，结果更真实
    │
    └─→ 云函数直接调用验证: tcb fn invoke {fn} --params '{...}' --env-id {envId}
            ├─ 成功: 云函数正常，问题是 API 网关
            └─ 失败: 云函数本身有问题
```

### 快速验证脚本

```bash
#!/bin/bash
# verify-api.sh — 验证 CloudBase API 可用性
ENV_ID="cloud1-2gavd8kj8a1ce021"
SUFFIX="1306178265"

# 检查静态托管
STATIC_CODE=$(curl -s -o /dev/null -w "%{http_code}" "https://${ENV_ID}-${SUFFIX}.tcloudbaseapp.com/" 2>/dev/null)
echo "Static hosting: $STATIC_CODE"

# 检查 HTTP 访问服务
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
  "https://${ENV_ID}-${SUFFIX}.ap-shanghai.app.tcloudbase.com/section-crud" \
  -X POST -H "Content-Type: application/json" -d '{"action":"list"}' 2>/dev/null)
echo "HTTP service: $HTTP_CODE"

# 检查 service.cloudbase.cn
SERVICE_DNS=$(nslookup ${ENV_ID}.service.cloudbase.cn 2>/dev/null | grep -c "NXDOMAIN" || echo "0")
echo "service.cloudbase.cn DNS: $([ "$SERVICE_DNS" = "1" ] && echo 'BROKEN (NXDOMAIN)' || echo 'OK')"

# 直接调用云函数验证功能
tcb fn invoke section-crud --params '{"action":"list"}' --env-id $ENV_ID 2>/dev/null | \
  grep -o '"code":[^,}]*' | head -1
```
