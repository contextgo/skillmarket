# Knowledge Base Guide — 知识库管理

## 目录

1. [概述](#概述)
2. [知识库设计](#知识库设计)
3. [数据模型](#数据模型)
4. [CloudBase 集成](#cloudbase-集成)
5. [检索能力](#检索能力)
6. [权限管理](#权限管理)
7. [部署配置](#部署配置)

---

## 概述

### 什么是知识库

在 TCB Harness 项目中，知识库用于存储、管理和检索项目全生命周期中产生的结构化和非结构化知识，包括：

| 类型 | 内容 | 存储 |
|------|------|------|
| 需求知识 | 需求文档、业务规则、领域概念 | NoSQL 文档 |
| 设计知识 | 架构决策、设计模式、技术选型 | NoSQL 文档 |
| 代码知识 | 组件说明、API 文档、最佳实践 | NoSQL + 云存储 |
| 运营知识 | 部署记录、告警处理手册、运维 SOP | NoSQL 文档 |
| 用户数据 | 用户资料、行为日志（业务数据） | NoSQL / MySQL |

### 知识库 vs 项目资产管理

| 维度 | 知识库 | 项目资产管理 |
|------|--------|------------|
| 内容 | 知识、经验、决策记录 | 代码、文档、产出物 |
| 组织 | 按知识点/标签/分类 | 按项目/阶段/文件 |
| 检索 | 语义检索、关键词搜索 | 文件路径查找 |
| 生命周期 | 持续积累、版本化 | 随项目产生 |

---

## 知识库设计

### 核心实体

```
KnowledgeItem (知识条目)
  ├── id: string              // 唯一 ID
  ├── title: string            // 标题
  ├── content: string         // 正文（Markdown / JSON）
  ├── category: Category      // 分类
  ├── tags: string[]          // 标签
  ├── status: enum             // draft / published / archived
  ├── author: string          // 作者 OPENID
  ├── createdAt: Date
  ├── updatedAt: Date
  └── metadata: object         // 元数据（可扩展）

Category (分类)
  ├── id: string
  ├── name: string
  ├── parentId?: string        // 父分类（支持多级）
  ├── sortOrder: number
  └── icon?: string

KnowledgeTag (标签)
  ├── name: string
  ├── color?: string
  └── count: number            // 引用次数
```

### 分类体系

```
知识库
├── 需求知识
│   ├── 业务概念
│   ├── 需求文档
│   └── 领域模型
├── 设计知识
│   ├── 架构设计
│   ├── 数据模型
│   └── 接口设计
├── 代码知识
│   ├── 组件库
│   ├── API 文档
│   └── 最佳实践
├── 运营知识
│   ├── 部署手册
│   ├── 告警处理
│   └── 运维 SOP
└── 团队知识
    ├── 团队规范
    └── 会议记录
```

---

## 数据模型

### 知识条目集合 (knowledge_items)

```json
{
  "name": "knowledge_items",
  "indexes": [
    { "keys": { "category": 1 }, "name": "idx_category" },
    { "keys": { "status": 1, "createdAt": -1 }, "name": "idx_status_time" },
    { "keys": { "author": 1, "createdAt": -1 }, "name": "idx_author" }
  ]
}
```

### 文档 Schema

```javascript
// models/knowledge-item.js

const VALID_STATUSES = ['draft', 'published', 'archived']
const VALID_CATEGORIES = [
  'requirement', 'design', 'code', 'operation', 'team',
  'requirement/concept', 'requirement/doc', 'requirement/domain',
  'design/architecture', 'design/data', 'design/api',
  'code/component', 'code/api', 'code/practice',
  'operation/deploy', 'operation/alert', 'operation/sop',
  'team/standard', 'team/meeting'
]

function validateKnowledgeItem(data) {
  const errors = []

  if (!data.title || data.title.trim().length < 2) {
    errors.push('title must be at least 2 characters')
  }
  if (!data.content || data.content.trim().length < 10) {
    errors.push('content must be at least 10 characters')
  }
  if (!VALID_CATEGORIES.includes(data.category)) {
    errors.push(`category must be one of: ${VALID_CATEGORIES.join(', ')}`)
  }
  if (data.status && !VALID_STATUSES.includes(data.status)) {
    errors.push(`status must be one of: ${VALID_STATUSES.join(', ')}`)
  }

  return { valid: errors.length === 0, errors }
}
```

---

## CloudBase 集成

### 知识库云函数

```javascript
// cloud/knowledge/index.js
const cloud = require('wx-server-sdk')
const { withTrace } = require('../middleware/trace')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const COLLECTION = 'knowledge_items'

/**
 * 创建知识条目
 */
async function create(event, context) {
  const { OPENID } = cloud.getWXContext()
  const { title, content, category, tags, metadata } = event

  // Validation
  if (!title || title.trim().length < 2) {
    return { code: 400, message: 'Title too short' }
  }

  const result = await db.collection(COLLECTION).add({
    data: {
      title: title.trim(),
      content,
      category,
      tags: tags || [],
      status: 'published',
      author: OPENID,
      metadata: metadata || {},
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })

  return { code: 0, data: { id: result._id } }
}

/**
 * 查询知识列表（支持分页 + 过滤）
 */
async function list(event) {
  const { category, tag, status, page = 0, pageSize = 20, keyword } = event

  let query = db.collection(COLLECTION).where({ status: 'published' })

  if (category) {
    query = query.where({ category })
  }
  if (tag) {
    query = query.where({ tags: db.RegExp({ regexp: tag }) })
  }
  if (keyword) {
    // 标题和内容模糊搜索
    query = query.where({
      title: db.RegExp({ regexp: keyword, options: 'i' })
    })
  }

  const res = await query
    .orderBy('createdAt', 'desc')
    .skip(page * pageSize)
    .limit(pageSize)
    .field({ content: false })  // 列表不返回正文
    .get()

  return {
    code: 0,
    data: {
      items: res.data,
      total: res.data.length,
      hasMore: res.data.length === pageSize
    }
  }
}

/**
 * 获取知识详情
 */
async function get(event) {
  const { id } = event
  const res = await db.collection(COLLECTION).doc(id).get()
  if (!res.data) {
    return { code: 404, message: 'Knowledge item not found' }
  }
  return { code: 0, data: res.data }
}

/**
 * 更新知识条目（仅作者可编辑）
 */
async function update(event, context) {
  const { OPENID } = cloud.getWXContext()
  const { id, title, content, category, tags, status, metadata } = event

  const doc = db.collection(COLLECTION).doc(id)
  const existing = await doc.get()

  if (!existing.data) {
    return { code: 404, message: 'Not found' }
  }
  if (existing.data.author !== OPENID) {
    return { code: 403, message: 'Not authorized' }
  }

  const updateData = { updatedAt: db.serverDate() }
  if (title !== undefined) updateData.title = title.trim()
  if (content !== undefined) updateData.content = content
  if (category !== undefined) updateData.category = category
  if (tags !== undefined) updateData.tags = tags
  if (status !== undefined) updateData.status = status
  if (metadata !== undefined) updateData.metadata = metadata

  await doc.update({ data: updateData })
  return { code: 0, data: { updated: true } }
}

/**
 * 删除知识条目（仅作者可删除）
 */
async function remove(event, context) {
  const { OPENID } = cloud.getWXContext()
  const { id } = event

  const doc = db.collection(COLLECTION).doc(id)
  const existing = await doc.get()

  if (!existing.data) {
    return { code: 404, message: 'Not found' }
  }
  if (existing.data.author !== OPENID) {
    return { code: 403, message: 'Not authorized' }
  }

  await doc.remove()
  return { code: 0, data: { deleted: true } }
}

exports.main = async function(event, context) {
  const { action } = event

  const handlers = { create, list, get, update, remove }
  const handler = handlers[action]

  if (!handler) {
    return { code: 400, message: `Unknown action: ${action}` }
  }

  return await handler(event, context)
}
```

---

## 检索能力

### 全文搜索

```javascript
/**
 * 搜索知识库
 * 支持: 标题/内容关键词、分类过滤、标签过滤、排序
 */
async function search(event) {
  const { keyword, category, tags, page = 0, pageSize = 20 } = event

  let query = db.collection(COLLECTION).where({
    status: 'published',
    $or: [
      { title: db.RegExp({ regexp: keyword, options: 'i' }) },
      { content: db.RegExp({ regexp: keyword, options: 'i' }) },
      { tags: db.RegExp({ regexp: keyword, options: 'i' }) }
    ]
  })

  if (category) {
    query = query.where({ category })
  }

  const res = await query
    .orderBy('updatedAt', 'desc')
    .skip(page * pageSize)
    .limit(pageSize)
    .get()

  return {
    code: 0,
    data: {
      items: res.data,
      hasMore: res.data.length === pageSize
    }
  }
}
```

### 标签聚合

```javascript
/**
 * 获取标签列表（按引用次数排序）
 */
async function getTags() {
  const res = await db.collection(COLLECTION)
    .aggregate()
    .unwind('$tags')
    .group({ _id: '$tags', count: { $sum: 1 } })
    .sort({ count: -1 })
    .limit(50)
    .end()

  return {
    code: 0,
    data: res.data.map(t => ({ name: t._id, count: t.count }))
  }
}
```

### 相关推荐

```javascript
/**
 * 基于标签的相关知识推荐
 */
async function getRelated(event) {
  const { id, limit = 5 } = event

  const item = await db.collection(COLLECTION).doc(id).get()
  if (!item.data) return { code: 0, data: [] }

  const tags = item.data.tags || []
  if (tags.length === 0) return { code: 0, data: [] }

  const res = await db.collection(COLLECTION)
    .where({
      status: 'published',
      _id: db.command.neq(id),
      tags: db.command.in(tags)
    })
    .limit(limit)
    .field({ content: false })
    .get()

  return { code: 0, data: res.data }
}
```

---

## 权限管理

### 安全规则

```javascript
// knowledge_items 安全规则
{
  "read": "doc.status == 'published' || doc.author == auth.openid",
  "create": "auth.openid != null",
  "update": "doc.author == auth.openid",
  "delete": "doc.author == auth.openid"
}
```

### 权限矩阵

| 操作 | 游客 | 注册用户 | 管理员 |
|------|------|---------|--------|
| 搜索/浏览公开知识 | ✅ | ✅ | ✅ |
| 查看个人草稿 | ❌ | ✅ (本人) | ✅ |
| 创建知识 | ❌ | ✅ | ✅ |
| 编辑自己的知识 | ❌ | ✅ (本人) | ✅ |
| 删除自己的知识 | ❌ | ✅ (本人) | ✅ |
| 管理他人知识 | ❌ | ❌ | ✅ |

---

## 部署配置

### deploy-config.json 中知识库配置

```json
// .harness/deploy-config.json
{
  "knowledgeBase": {
    "enabled": true,
    "collection": "knowledge_items",
    "searchEnabled": true,
    "indexes": [
      { "name": "idx_category", "keys": { "category": 1 } },
      { "name": "idx_author", "keys": { "author": 1, "createdAt": -1 } },
      { "name": "idx_status_time", "keys": { "status": 1, "createdAt": -1 } }
    ],
    "functions": [
      {
        "name": "knowledge",
        "version": "v1",
        "status": "deployed"
      }
    ],
    "securityRules": {
      "read": "doc.status == 'published' || doc.author == auth.openid",
      "write": "doc.author == auth.openid"
    },
    "categories": [
      { "id": "requirement", "name": "需求知识", "icon": "📋" },
      { "id": "design", "name": "设计知识", "icon": "🎨" },
      { "id": "code", "name": "代码知识", "icon": "💻" },
      { "id": "operation", "name": "运营知识", "icon": "🛠️" },
      { "id": "team", "name": "团队知识", "icon": "👥" }
    ],
    "retentionDays": 365
  }
}
```

### 知识库初始化检查清单

- [ ] `knowledge` 云函数已部署
- [ ] `knowledge_items` 集合已创建
- [ ] 索引已配置
- [ ] 安全规则已配置
- [ ] 分类数据已初始化
