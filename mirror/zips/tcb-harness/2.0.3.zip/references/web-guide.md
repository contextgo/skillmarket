# Web Guide — Web 前端专项设计

## 目录

1. [项目结构](#项目结构)
2. [框架选择](#框架选择)
3. [CloudBase Web SDK 集成](#cloudbase-web-sdk-集成)
4. [路由设计](#路由设计)
5. [状态管理](#状态管理)
6. [部署配置](#部署配置)

---

## 项目结构

### 标准目录（Vite/React 为例）

```
src/web/
├── public/
│   └── index.html
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── pages/                    # 页面
│   │   ├── Home/
│   │   │   └── index.jsx
│   │   └── Profile/
│   │       └── index.jsx
│   ├── components/                # 组件
│   │   ├── common/               # 通用
│   │   │   ├── Button/
│   │   │   └── Loading/
│   │   └── business/             # 业务
│   │       └── OrderCard/
│   ├── services/                 # API 调用
│   │   ├── auth.js
│   │   ├── order.js
│   │   └── product.js
│   ├── store/                     # 状态管理
│   │   └── index.js
│   ├── router/                    # 路由
│   │   └── index.jsx
│   ├── styles/                    # 样式
│   │   └── global.css
│   └── utils/                     # 工具
│       ├── cloud.js              # CloudBase 初始化
│       └── request.js            # 请求封装
├── .env                           # 环境变量
├── .env.production
├── vite.config.js
└── package.json
```

### 环境配置

```bash
# .env.development
VITE_CLOUDBASE_ENV=dev-env-id
VITE_API_BASE=https://api.example.com

# .env.production
VITE_CLOUDBASE_ENV=prod-env-id
VITE_API_BASE=https://api.example.com
```

---

## 技术选型

| 技术 | 选型 | 说明 |
|------|------|------|
| 组件库 | **TDesign React** | 腾讯官方企业级 React 组件库 |
| 框架 | React 18 + Vite + TypeScript | 强类型，生态丰富 |
| 语言 | **TypeScript** | 严格模式，必开 |
| 状态管理 | Zustand / React Query | 轻量 + 服务端状态 |
| 路由 | React Router 6 | 标准 SPA 路由 |
| CSS | **Tailwind CSS** + PostCSS | 原子化 CSS，快速构建 |

### TDesign React + Tailwind CSS 接入

```bash
npm install tdesign-react
npm install tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

---

## CloudBase Web SDK 集成

### 安装

```bash
npm install @cloudbase/js-sdk
```

### 初始化

```javascript
// src/utils/cloud.js
import cloudbase from '@cloudbase/js-sdk'

const app = cloudbase.init({
  env: import.meta.env.VITE_CLOUDBASE_ENV,
  appSign: 'your-app-sign'   // 如果开启了 appSign
})

export const auth = app.auth({ persistence: 'local' })
export const db = app.database()
export default app
```

### 认证（Web）

```javascript
// 匿名登录
async function anonymousLogin() {
  const {anonymousCode} = await auth.signInAnonymously()
  console.log('anonymous code:', anonymousCode)
}

// 邮箱密码登录
async function emailLogin(email, password) {
  const {user} = await auth.signInWithEmailAndPassword(email, password)
  return user
}

// 获取当前用户
async function getCurrentUser() {
  const {user} = await auth.getAuthState()
  return user
}

// 登出
async function logout() {
  await auth.signOut()
}
```

### 数据库操作

```javascript
import { db } from '@/utils/cloud'

// 查询
async function getOrders(openid) {
  const res = await db.collection('orders')
    .where({ openid })
    .orderBy('createdAt', 'desc')
    .limit(20)
    .get()
  return res.data
}

// 新增
async function createOrder(items) {
  return await db.collection('orders').add({
    data: { items, status: 'created', createdAt: new Date() }
  })
}

// 更新
async function updateOrder(orderId, data) {
  return await db.collection('orders').doc(orderId).update({
    data: { ...data, updatedAt: new Date() }
  })
}
```

---

## 路由设计

### React Router（React 为例）

```jsx
// src/router/index.jsx
import { createBrowserRouter } from 'react-router-dom'
import { getAuthState } from '@/utils/cloud'

// 路由守卫
function requireAuth({ children }) {
  const [user, setUser] = useState(null)
  useEffect(() => {
    getAuthState().then(u => {
      if (!u) navigate('/login')
      setUser(u)
    })
  }, [])
  return user ? children : <Loading />
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: '/orders', element: <OrderList /> },
      { path: '/orders/:id', element: <OrderDetail /> },
      { path: '/profile', element: <Profile /> }
    ]
  },
  { path: '/login', element: <Login /> },
  { path: '/register', element: <Register /> }
])
```

---

## 状态管理

### 轻量方案（Zustand）

```javascript
// src/store/useOrderStore.js
import { create } from 'zustand'

export const useOrderStore = create((set, get) => ({
  orders: [],
  loading: false,
  hasMore: true,
  page: 0,

  setOrders: (orders) => set({ orders }),
  addOrders: (newOrders) => set(state => ({ orders: [...state.orders, ...newOrders] })),
  setLoading: (loading) => set({ loading }),
  setHasMore: (hasMore) => set({ hasMore }),
  incrementPage: () => set(state => ({ page: state.page + 1 })),
  reset: () => set({ orders: [], page: 0, hasMore: true })
}))
```

### 服务端状态（React Query）

```javascript
// src/services/order.js
import { useQuery, useMutation } from '@tanstack/react-query'
import { getOrders, createOrder } from './api'

export function useOrders() {
  return useQuery({
    queryKey: ['orders'],
    queryFn: getOrders,
    staleTime: 5 * 60 * 1000
  })
}

export function useCreateOrder() {
  return useMutation({
    mutationFn: createOrder,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries(['orders'])
    }
  })
}
```

---

## 部署配置

### Vite 构建

```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  base: './',
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  build: {
    outDir: 'dist',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          tdesign: ['tdesign-react'],
          cloudbase: ['@cloudbase/js-sdk']
        }
      }
    }
  }
})
```

### 部署到 CloudBase 静态托管

1. 构建：`npm run build`
2. 输出目录：`dist/`
3. 通过 CloudBase MCP 或控制台上传

### 环境变量注入

```javascript
// 在 HTML 中引用
<script>
  window.__ENV__ = {
    CLOUDBASE_ENV: import.meta.env.VITE_CLOUDBASE_ENV
  }
</script>
```
