# Testing Design Guide — 测试设计指南

## 目录

1. [测试策略总览](#测试策略总览)
2. [用例生成](#用例生成)
3. [数据构造](#数据构造)
4. [测试执行](#测试执行)
5. [测试评估](#测试评估)
6. [测试报告](#测试报告)

---

## 测试策略总览

### 测试金字塔

```
           ╱  E2E  ╲           少量，关键路径
          ╱─────────╲          miniprogram-automator
         ╱ Integration ╲       适量，API + DB 联调
        ╱─────────────────╲    CloudBase 本地模拟
       ╱     Unit Tests     ╲  大量，纯逻辑验证
      ╱─────────────────────────╲ jest / miniprogram-simulate
```

### 覆盖策略

| 层级 | 覆盖目标 | 工具 | 运行频率 |
|------|---------|------|---------|
| Unit | Services, Models, Utils 逻辑 | jest + miniprogram-simulate | 每次提交 |
| Integration | 云函数 + 数据库联调 | CloudBase 本地模拟 | 合入主分支时 |
| E2E | 关键用户流程 | miniprogram-automator | 发版前 |

---

## 用例生成

### 生成策略

从 `requirements.md` 的验收标准自动推导测试用例：

**映射规则：**

| 验收标准类型 | 测试用例类型 | 示例 |
|-------------|-------------|------|
| When...shall (正常) | 正向功能测试 | 用户点击提交 → 订单创建成功 |
| If...shall (异常) | 异常处理测试 | 网络断开 → 缓存+重试提示 |
| While...shall (状态) | 状态验证测试 | 已登录 → 显示个性化内容 |
| 边界值 (隐含) | 边界测试 | 分页最后一页 / 空列表 |

### 用例模板

```markdown
# TC-{id}: {用例标题}

**关联需求:** FR-{xx}
**优先级:** P0 / P1 / P2
**类型:** 功能 / 边界 / 异常 / 兼容性 / 性能

## 前置条件
1. 用户已登录
2. 购物车有商品

## 测试步骤
1. 进入购物车页面
2. 点击"结算"按钮
3. 确认订单信息
4. 点击"提交订单"

## 预期结果
- 页面跳转到订单详情
- 订单状态为"created"
- 购物车已清空
- 数据库 orders 集合新增一条记录

## 测试数据
- 用户: {openid: "test_user_001"}
- 商品: [{productId: "p001", quantity: 2, price: 99.9}]
```

### 用例分类矩阵

```
           │ 正常路径 │ 边界条件 │ 异常场景
───────────┼─────────┼─────────┼────────
功能测试    │   ✓     │   ✓     │   ✓
权限测试    │   ✓     │         │   ✓
性能测试    │         │   ✓     │
兼容性测试  │   ✓     │         │
```

### 自动生成命令

```bash
python3 scripts/gen_test_cases.py \
  --spec specs/{spec-name}/requirements.md \
  --output tests/test-cases/ \
  --coverage-level standard
```

**coverage-level 选项：**
- `minimal` — 仅正常路径 + 关键异常
- `standard` — 正常 + 边界 + 主要异常（默认）
- `thorough` — 全部路径 + 兼容性 + 性能

---

## 数据构造

### 数据类型

| 数据类型 | 用途 | 来源 |
|---------|------|------|
| Mock DB 数据 | 替代 CloudBase NoSQL 集合 | `gen_test_data.py` 生成 |
| Mock 用户 | 模拟不同角色/状态的用户 | 手动定义 + 生成 |
| Mock 云函数响应 | 模拟云函数返回值 | 从 API 契约生成 |
| 场景数据 | 特定业务场景的完整数据链 | 手动编排 |

### CloudBase Mock 策略

**单元测试 — 完全 Mock：**

```javascript
// tests/unit/services/order.test.js
const mockDb = {
  collection: jest.fn().mockReturnValue({
    add: jest.fn().mockResolvedValue({ _id: 'mock_order_id' }),
    where: jest.fn().mockReturnValue({
      get: jest.fn().mockResolvedValue({ data: [] })
    })
  })
}

// Mock wx.cloud
global.wx = {
  cloud: { database: () => mockDb },
  showToast: jest.fn(),
  navigateTo: jest.fn()
}
```

**集成测试 — CloudBase 本地模拟：**

```javascript
// tests/integration/services/order.test.js
// 使用 @cloudbase/node-sdk + 本地模拟器
const tcb = require('@cloudbase/node-sdk')
const app = tcb.init({ env: 'test-env', ... })
```

### 数据构造规则

```bash
python3 scripts/gen_test_data.py \
  --spec specs/{spec-name}/requirements.md \
  --output tests/test-data/ \
  --count 10
```

**生成逻辑：**

1. 从 `data-model.md`（设计阶段产出）读取集合 schema
2. 为每个集合生成 N 条符合 schema 的测试数据
3. 生成特殊数据：空值、极长字符串、特殊字符、超出范围的数值
4. 生成关联数据：用户 → 订单 → 订单项 的外键关联
5. 输出为 JSON 文件，可直接导入 CloudBase 或用于 Mock

### 输出格式

```json
// tests/test-data/mock-db.json
{
  "users": [
    { "_id": "u001", "openid": "test_openid_001", "nickname": "测试用户A", "phone": "13800138001" },
    { "_id": "u002", "openid": "test_openid_002", "nickname": "测试用户B", "phone": "" }
  ],
  "orders": [
    { "_id": "o001", "openid": "test_openid_001", "items": [...], "totalAmount": 199.8, "status": "created" }
  ],
  "_meta": {
    "generatedAt": "2026-04-28T11:00:00Z",
    "specVersion": "requirements.md@abc123",
    "collectionCount": 2,
    "recordCount": { "users": 2, "orders": 1 }
  }
}
```

---

## 测试执行

### Unit Tests

```bash
# 运行所有单元测试
npx jest tests/unit/ --coverage

# 运行特定模块
npx jest tests/unit/services/order.test.js

# 监听模式（TDD 开发时使用）
npx jest tests/unit/ --watch
```

**miniprogram-simulate 使用：**

```javascript
const simulate = require('miniprogram-simulate')
const component = simulate.render(require('../../../src/components/common/empty-state/index'))

test('empty-state renders title', () => {
  component.setData({ title: '暂无数据' })
  expect(component.querySelector('.empty-state__title').dom.textContent).toBe('暂无数据')
})
```

### Integration Tests

```bash
# 启动 CloudBase 本地模拟
npx tcb-framework local --port 9000

# 运行集成测试
CLOUDBASE_ENV=test-env npx jest tests/integration/
```

### E2E Tests

```javascript
// tests/e2e/flows/order-flow.test.js
const automator = require('miniprogram-automator')

describe('Order Flow', () => {
  let miniProgram

  beforeAll(async () => {
    miniProgram = await automator.launch({ cliPath: '/Applications/wechatwebdevtools.app/Contents/MacOS/cli', projectPath: '/path/to/project' })
  })

  test('create order from cart', async () => {
    const page = await miniProgram.reLaunch('/pages/cart/cart')
    await page.waitFor(1000)

    const checkoutBtn = await page.$('.cart__checkout-btn')
    await checkoutBtn.tap()

    const confirmPage = await miniProgram.currentPage()
    const submitBtn = await confirmPage.$('.order-confirm__submit')
    await submitBtn.tap()

    await page.waitFor(2000)
    const detailPage = await miniProgram.currentPage()
    expect(detailPage.path).toContain('/pages/order-detail/')
  })

  afterAll(async () => {
    await miniProgram.close()
  })
})
```

### 测试执行流水线

```
单元测试 (jest)
    │ pass?
    ↓
集成测试 (CloudBase 本地)
    │ pass?
    ↓
E2E 测试 (miniprogram-automator)
    │ pass?
    ↓
生成测试报告
```

---

## 测试评估

### 评估维度

| 维度 | 计算方式 | 达标线 |
|------|---------|--------|
| **需求覆盖率** | (有测试的验收标准数 / 总验收标准数) × 100% | ≥ 80% |
| **用例通过率** | (通过的用例数 / 执行的用例数) × 100% | 100% (P0), ≥ 95% (P1) |
| **代码覆盖率** | jest --coverage 输出 | ≥ 70% (行), ≥ 80% (分支-核心模块) |
| **缺陷密度** | 发现的缺陷数 / 千行代码 | ≤ 5 |
| **风险评估** | 未覆盖的高优先级需求数 | 0 |

### 风险等级

| 等级 | 条件 | 处理 |
|------|------|------|
| 🟢 低 | 所有 P0/P1 通过 + 覆盖率达标 | 可发布 |
| 🟡 中 | P0 通过 + P1 有少量失败 + 覆盖率接近达标 | 需评估后决定 |
| 🔴 高 | P0 有失败 或 覆盖率严重不足 | 禁止发布，必须修复 |

---

## 测试报告

### 报告模板

```markdown
# 测试报告 — {project-name} v{version}

**测试日期:** {date}
**测试环境:** CloudBase env-{id} / 微信开发者工具 v{version}

## 1. 执行概览

| 指标 | 值 | 达标 |
|------|-----|------|
| 需求覆盖率 | 85% | ✅ ≥80% |
| 用例通过率 | 97% (58/60) | ✅ P0 100%, P1 95% |
| 代码行覆盖率 | 73% | ✅ ≥70% |
| 缺陷密度 | 2.1/KLOC | ✅ ≤5 |

## 2. 测试用例执行结果

| 用例 ID | 标题 | 优先级 | 结果 |
|---------|------|--------|------|
| TC-001 | 创建订单-正常流程 | P0 | ✅ PASS |
| TC-002 | 创建订单-空商品列表 | P0 | ✅ PASS |
| TC-015 | 分页加载-最后一页 | P1 | ❌ FAIL |
| ... | ... | ... | ... |

## 3. 缺陷列表

| 缺陷 ID | 关联用例 | 严重度 | 描述 | 状态 |
|---------|---------|--------|------|------|
| BUG-001 | TC-015 | P1 | 分页最后一页返回空而非空状态提示 | Open |

## 4. 风险评估

**风险等级:** 🟡 中

**未覆盖项:**
- FR-08 订阅消息功能（需真机测试，暂无环境）

**建议:**
1. 修复 BUG-001 后重新执行 TC-015
2. FR-08 在真机预览阶段补充验证
3. 可考虑灰度发布

## 5. 覆盖率详情

{附 jest coverage summary 或截图}
```

### 报告生成

```bash
# 运行测试 + 自动生成报告
npx jest tests/ --coverage --json --outputFile=tests/results/jest-result.json
python3 scripts/gen_test_report.py \
  --jest-result tests/results/jest-result.json \
  --spec specs/{spec-name}/requirements.md \
  --output tests/reports/test-report-$(date +%Y%m%d).md
```
