# UI Design Guide — UI 设计规范

## 目录

1. [设计系统](#设计系统)
2. [设计令牌](#设计令牌)
3. [微信设计指南](#微信设计指南)
4. [组件规范](#组件规范)
5. [交互模式](#交互模式)
6. [配色方案](#配色方案)
7. [产出规范](#产出规范)

---

## 设计系统

### 设计原则

1. **微信原生优先** — 遵循微信设计指南，不刻意差异化
2. **一致性** — 相同交互模式用相同组件
3. **可及性** — 文字对比度 ≥ 4.5:1，触控区域 ≥ 44rpx
4. **性能意识** — 避免大量动画，首屏内容优先

### 设计系统产出

在 `design/ui/` 目录下维护：

```
design/ui/
├── design-system.md      # 本文件的内容，设计系统定义
├── color-palette.md      # 配色方案
├── typography.md         # 字体规范
├── spacing.md            # 间距规范
└── wireframes/           # 页面线框图/原型描述
    ├── home.md
    ├── list.md
    └── detail.md
```

---

## 设计令牌

### 颜色令牌

```css
/* 品牌色 */
--color-primary: #07C160;        /* 微信绿 — 默认主色 */
--color-primary-light: #38DA7C;
--color-primary-dark: #06AD56;

/* 功能色 */
--color-success: #07C160;
--color-warning: #FAAD14;
--color-error: #FA5151;
--color-info: #10AEFF;

/* 中性色 */
--color-text-primary: #191919;
--color-text-secondary: #666666;
--color-text-placeholder: #B2B2B2;
--color-text-inverse: #FFFFFF;

--color-bg-page: #F6F6F6;
--color-bg-card: #FFFFFF;
--color-bg-mask: rgba(0, 0, 0, 0.5);

--color-border: #E5E5E5;
--color-divider: #F0F0F0;
```

### 间距令牌

```
--spacing-xs:  8rpx
--spacing-sm:  16rpx
--spacing-md:  24rpx
--spacing-lg:  32rpx
--spacing-xl:  48rpx
--spacing-xxl: 64rpx
```

### 字体令牌

```
--font-size-xs:  20rpx    /* 辅助文字 */
--font-size-sm:  24rpx    /* 次要文字 */
--font-size-md:  28rpx    /* 正文 */
--font-size-lg:  32rpx    /* 小标题 */
--font-size-xl:  36rpx    /* 标题 */
--font-size-xxl: 44rpx    /* 大标题 */

--font-weight-normal: 400
--font-weight-medium: 500
--font-weight-bold: 700

--line-height-tight: 1.2
--line-height-normal: 1.5
--line-height-relaxed: 1.8
```

### 圆角令牌

```
--radius-sm: 4rpx
--radius-md: 8rpx
--radius-lg: 16rpx
--radius-xl: 24rpx
--radius-round: 50%
```

---

## 微信设计指南

### 必须遵循

- 使用微信提供的标准导航栏（不自定义，除非有强需求）
- TabBar 图标 81×81px，选中/未选两态
- 操作按钮放在页面底部安全区
- 下拉刷新使用微信原生下拉刷新
- 分享使用微信标准分享面板

### 安全区域

```
状态栏: ~88rpx (iPhone X 及以上)
导航栏: ~88rpx
TabBar: ~98rpx (含安全区 ~134rpx)
底部安全区: ~68rpx (iPhone X 及以上)
```

### 页面布局

```
┌────────────────────────┐
│      状态栏 (系统)       │
├────────────────────────┤
│      导航栏             │ ← 可自定义标题
├────────────────────────┤
│                        │
│                        │
│     内容区域            │ ← 可滚动
│                        │
│                        │
├────────────────────────┤
│     底部操作栏 (可选)    │ ← 固定底部
├────────────────────────┤
│     TabBar (可选)       │
├────────────────────────┤
│     安全区              │
└────────────────────────┘
```

---

## 组件规范

### 基础组件

| 组件 | 规范 | 变体 |
|------|------|------|
| Button | 高度 88rpx, 圆角 radius-lg | primary/secondary/ghost/text, size: lg/md/sm |
| Input | 高度 80rpx, 底部边框 | text/number/textarea, clearable |
| Cell | 高度 auto, min 96rpx | arrow/switch/input, group with title |
| Card | 圆角 radius-lg, 阴影 | elevated/flat/outline |
| Empty | 居中图标+文字+操作 | empty/error/no-network/search |
| Loading | 居中 spinner | page/section/inline |
| Tag | 圆角 radius-round | primary/success/warning/error |
| Modal | 底部弹出/居中 | confirm/alert/action-sheet |
| Toast | 居中, 自动消失 | success/error/loading/text |

### 业务组件

业务组件放在 `components/business/`：

- 命名: `{domain}-{name}` — `order-card`, `product-grid`, `user-avatar`
- 每个 component 独立目录: `order-card/index.js|wxml|wxss|json`
- 通过 properties 传入数据，通过 events 向上通信

---

## 交互模式

### 页面跳转

| 操作 | API | 说明 |
|------|-----|------|
| 新开页面 | `wx.navigateTo` | 可返回，压栈 |
| 替换页面 | `wx.redirectTo` | 不可返回当前页 |
| 返回 | `wx.navigateBack` | 弹栈 |
| Tab 切换 | `wx.switchTab` | 切换 TabBar 页面 |
| 重启 | `wx.reLaunch` | 清空页面栈 |

### 反馈模式

| 场景 | 组件 | 持续时间 |
|------|------|---------|
| 操作成功 | Toast (success) | 1.5s |
| 操作失败 | Toast (error) + 重试入口 | 2s |
| 加载中 | Loading (section/page) | 数据返回后消失 |
| 确认操作 | Modal (confirm) | 用户操作 |
| 表单校验 | Input 下方红色提示 | 修正后消失 |

### 列表交互

- 下拉刷新: `onPullDownRefresh`
- 上拉加载: `onReachBottom` + 分页
- 空状态: 自定义 empty component
- 骨架屏: 首次加载时显示

---

## 配色方案

### 确定配色流程

1. **确定品牌色** — 与用户确认主色调
2. **生成色阶** — 从品牌色生成 light/default/dark 三档
3. **选择功能色** — 成功/警告/错误/信息
4. **定义中性色** — 文字/背景/边框的灰度系列
5. **验证对比度** — 文字与背景对比度 ≥ 4.5:1

### 常见配色方案

**商务风:**
- Primary: #1A73E8 (蓝)
- 适合: 工具类、效率类小程序

**生活风:**
- Primary: #07C160 (微信绿)
- 适合: 社交、生活服务类

**活泼风:**
- Primary: #FF6B35 (橙)
- 适合: 电商、内容消费类

**极简风:**
- Primary: #191919 (黑)
- 适合: 高端、品牌展示类

### 产出文件

```markdown
# design/ui/color-palette.md

## 品牌色
| 名称 | HEX | 用途 |
|------|-----|------|
| Primary | #07C160 | 主按钮、选中态 |
| Primary Light | #38DA7C | 悬停态 |
| ... | ... | ... |
```

---

## 产出规范

### 线框图格式

使用 Markdown 描述 + ASCII 布局图：

```markdown
# 首页线框

## 布局
┌─────────────────────────┐
│  🔍 搜索栏               │
├─────────────────────────┤
│  ┌─────┐ ┌─────┐ ┌────┐ │
│  │ 分类1 │ │ 分类2 │ │分类3│ │
│  └─────┘ └─────┘ └────┘ │
├─────────────────────────┤
│  Banner 轮播             │
│  [  图1  ] [  图2  ]    │
├─────────────────────────┤
│  热门推荐                │
│  ┌──────┐  ┌──────┐    │
│  │ 商品1 │  │ 商品2 │    │
│  └──────┘  └──────┘    │
└─────────────────────────┘
│  🏠    📋    👤         │
│  首页   订单   我的      │
```

### 组件清单

每个页面的线框图后附组件清单：

| 区域 | 组件 | 来源 | 属性 |
|------|------|------|------|
| 搜索栏 | search-bar | common | placeholder="搜索商品" |
| 分类 | category-grid | business | items=[] |
| Banner | swiper | 原生 | autoplay, interval=3000 |
