# Tracing Guide — 链路追踪指南

## 目录

1. [概述](#概述)
2. [Trace ID 体系](#trace-id-体系)
3. [前端 Trace 注入](#前端-trace-注入)
4. [云函数 Trace 中间件](#云函数-trace-中间件)
5. [日志规范](#日志规范)
6. [Trace 存储与分析](#trace-存储与分析)
7. [监控告警配置](#监控告警配置)
8. [部署配置](#部署-config)

---

## 概述

### 什么是链路追踪

在分布式系统中，一个用户请求可能经过：

```
小程序 → 云函数A → 云函数B → 数据库
              ↘ 云函数C → 云存储
```

链路追踪为每次请求生成全局唯一的 **Trace ID**，贯穿所有调用节点，记录每个环节的耗时、状态和关键事件。

### 与鹰眼的关系

腾讯云鹰眼（EagleEye）是微信侧链路追踪的标准实现。本 skill 采用与鹰眼兼容的 Trace ID 格式和 Header 约定，确保与微信内部系统互通。

### 追踪数据模型

```typescript
interface TraceSpan {
  traceId: string          // 全局链路 ID（鹰眼格式）
  spanId: string           // 当前节点 ID（16 进制）
  parentSpanId?: string    // 父节点 ID
  serviceName: string      // 当前服务名
  operationName: string    // 操作名称
  startTime: number        // 开始时间（微秒）
  duration: number         // 耗时（微秒）
  status: 0 | 1 | 2       // 0=成功, 1=业务异常, 2=系统异常
  tags: Record<string, string>   // 业务标签
  logs: TraceLog[]         // 关键事件
}

interface TraceLog {
  timestamp: number
  event: string
  payload?: any
}
```

---

## Trace ID 体系

### 鹰眼 Trace ID 格式

鹰眼 Trace ID = `32 位十六进制字符串`，格式如下：

```
{城市代号(4)}{时间戳(13)}{序列号(9)}{采样标志(1)}{进程ID(5)}
```

| 字段 | 长度 | 说明 |
|------|------|------|
| 城市代号 | 4 位 | 区域标识 |
| 时间戳 | 13 位 | Unix 毫秒时间戳 |
| 序列号 | 9 位 | 递增序号 |
| 采样标志 | 1 位 | 0=采样, 1=未采样 |
| 进程 ID | 5 位 | 进程唯一标识 |

### 本地 Trace ID 生成

```javascript
// utils/tracing.js

/**
 * 生成鹰眼兼容的 Trace ID
 */
function generateTraceId() {
  const cityCode = '0000'                        // 默认城市代码
  const timestamp = Date.now().toString(16).padStart(13, '0')  // 13位毫秒时间戳
  const seq = (++_seq % 0x1FFFFFFFF).toString(16).padStart(9, '0')  // 9位序列
  const sampled = '0'                           // 采样标志
  const pid = (process.pid % 0xFFFFF).toString(16).padStart(5, '0')  // 5位PID
  return (cityCode + timestamp + seq + sampled + pid).toUpperCase()
}

let _seq = Math.floor(Math.random() * 0x1FFFFFFF)
```

### Trace Context Header

| Header 名称 | 说明 | 格式 |
|------------|------|------|
| `X-Trace-ID` | 全局 Trace ID | 32 位十六进制字符串 |
| `X-Parent-Span-ID` | 父 Span ID | 16 位十六进制字符串 |
| `X-Trace-Sampled` | 是否采样 | `0`=采样, `1`=未采样 |

---

## 前端 Trace 注入

### 小程序端

```javascript
// utils/cloud.js — CloudBase 初始化时注入 Trace

const TRACE_HEADER = 'X-Trace-ID'
let _traceId = null

/**
 * 获取当前 Trace ID（若无则生成）
 */
export function getTraceId() {
  if (!_traceId) {
    _traceId = generateTraceId()
  }
  return _traceId
}

/**
 * 初始化云函数调用（注入 Trace Header）
 */
export async function tracedCloudCall(name, data) {
  const traceId = getTraceId()
  const spanId = generateSpanId()

  return wx.cloud.callFunction({
    name,
    data: {
      ...data,
      // 通过 _debug 字段传递 Trace（微信侧会识别）
      _traceContext: {
        traceId,
        spanId,
        parentSpanId: data._parentSpanId || ''
      }
    }
  })
}

/**
 * 生成 16 位 Span ID
 */
function generateSpanId() {
  return Math.floor(Math.random() * 0xFFFFFFFFFFFFFF)
    .toString(16).padStart(12, '0').toUpperCase()
}
```

### Web 端

```javascript
// src/utils/trace.js
import { cloudbase } from './cloud'

const TRACE_HEADER = 'x-trace-id'
let _traceId = null

export function getTraceId() {
  if (!_traceId) {
    // 优先从 URL 参数继承（SSR 场景）
    const params = new URLSearchParams(window.location.search)
    _traceId = params.get(TRACE_HEADER) || generateTraceId()
  }
  return _traceId
}

export function withTraceHeaders(headers = {}) {
  return {
    ...headers,
    [TRACE_HEADER]: getTraceId()
  }
}

export function generateTraceId() {
  const ts = Date.now().toString(16).padStart(13, '0')
  const seq = Math.floor(Math.random() * 0x1FFFFFFF).toString(16).padStart(9, '0')
  const pid = Math.floor(Math.random() * 0xFFFFF).toString(16).padStart(5, '0')
  return ('0000' + ts + seq + '0' + pid).toUpperCase()
}
```

---

## 云函数 Trace 中间件

### 基础 Trace 中间件

```javascript
// cloud/middleware/trace.js

const HEADER_TRACE = 'x-trace-id'
const HEADER_PARENT = 'x-parent-span-id'
const HEADER_SPAN = 'x-span-id'
const HEADER_SAMPLED = 'x-trace-sampled'

function generateSpanId() {
  return Math.floor(Math.random() * 0xFFFFFFFFFFFFFF)
    .toString(16).padStart(12, '0').toUpperCase()
}

function parseContext(event) {
  const headers = event.headers || {}
  const traceContext = event._traceContext || {}

  return {
    traceId: traceContext.traceId || headers[HEADER_TRACE] || generateTraceId(),
    parentSpanId: traceContext.parentSpanId || headers[HEADER_PARENT] || '',
    spanId: generateSpanId(),
    sampled: traceContext.sampled !== undefined ? traceContext.sampled : '0'
  }
}

/**
 * Trace 中间件 — 包装云函数
 * 用法: exports.main = withTrace(handler)
 */
function withTrace(handler) {
  return async function tracedHandler(event, context) {
    const tc = parseContext(event)
    const startTime = Date.now() * 1000  // 微秒

    // 注入到 context 供业务代码使用
    context.trace = tc
    context.traceId = tc.traceId

    try {
      const result = await handler(event, context)
      const duration = Date.now() * 1000 - startTime

      logSpan(tc, 'completed', duration, 0)
      return result
    } catch (err) {
      const duration = Date.now() * 1000 - startTime
      const status = err.isBizError ? 1 : 2
      logSpan(tc, `error:${err.message}`, duration, status)
      throw err
    }
  }
}

function logSpan(tc, event, duration, status) {
  // 输出结构化日志（供日志系统采集）
  console.log(JSON.stringify({
    type: 'span',
    traceId: tc.traceId,
    spanId: tc.spanId,
    parentSpanId: tc.parentSpanId,
    service: process.env.FUNCTION_NAME || 'unknown',
    operation: 'cloud-function',
    event,
    duration,
    status,
    timestamp: new Date().toISOString()
  }))
}

module.exports = { withTrace, generateSpanId }
```

### 使用示例

```javascript
// cloud/create-order/index.js
const cloud = require('wx-server-sdk')
const { withTrace } = require('../middleware/trace')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()

const handler = async function(event, context) {
  const traceId = context.traceId  // 可直接使用
  console.log('Processing order, traceId:', traceId)

  // 业务逻辑...
  const { OPENID } = cloud.getWXContext()
  const { items } = event

  if (!items || items.length === 0) {
    const err = new Error('Items cannot be empty')
    err.isBizError = true
    throw err
  }

  const result = await db.collection('orders').add({
    data: { openid: OPENID, items, traceId }  // 记录 Trace ID 到订单
  })

  return { code: 0, data: { orderId: result._id } }
}

// 包裹 handler 实现自动追踪
exports.main = withTrace(handler)
```

### 级联调用（调用其他云函数）

```javascript
// cloud/middleware/trace.js 扩展

async function tracedCall(name, data, context) {
  const tc = context.trace
  const spanId = generateSpanId()

  const childData = {
    ...data,
    _traceContext: {
      traceId: tc.traceId,
      parentSpanId: tc.spanId,  // 当前 span 作为父 span
      spanId,
      sampled: tc.sampled
    }
  }

  const start = Date.now()
  try {
    const result = await cloud.callFunction({ name, data: childData })
    logSpan({
      ...tc,
      spanId,
      parentSpanId: tc.spanId
    }, `call:${name}`, Date.now() - start, 0)
    return result
  } catch (err) {
    logSpan({
      ...tc,
      spanId,
      parentSpanId: tc.spanId
    }, `call:${name}:error:${err.message}`, Date.now() - start, 2)
    throw err
  }
}
```

---

## 日志规范

### 结构化日志格式

所有云函数必须输出 JSON 格式的结构化日志：

```json
{
  "type": "span | event | error",
  "traceId": "0000ABC123DEF456789012345678901234567",
  "spanId": "ABC123456789",
  "parentSpanId": "DEF123456789",
  "service": "create-order",
  "operation": "cloud-function | db-query | http-call",
  "event": "db.insert | http.request",
  "duration": 15432,
  "status": 0,
  "tags": {
    "env": "prod",
    "user": "oXXXXXX",
    "orderId": "o123456"
  },
  "timestamp": "2026-04-28T12:00:00.000Z"
}
```

### 日志级别使用规范

| 级别 | 使用场景 |
|------|---------|
| `console.log` (span/event) | 正常流程关键节点 |
| `console.warn` | 业务异常（预期内的错误） |
| `console.error` | 系统异常（预期外的错误） |

### 敏感信息脱敏

```javascript
function sanitizeTags(tags) {
  const sensitiveKeys = ['password', 'token', 'phone', 'idcard', 'openid']
  const sanitized = { ...tags }
  for (const key of sensitiveKeys) {
    if (sanitized[key]) {
      sanitized[key] = mask(sanitized[key])
    }
  }
  return sanitized
}

function mask(value) {
  if (typeof value !== 'string') return value
  if (value.length <= 4) return '****'
  return value.slice(0, 2) + '****' + value.slice(-2)
}
```

---

## Trace 存储与分析

### 存储方案

| 方案 | 适用场景 | 说明 |
|------|---------|------|
| **CloudBase 日志 + 离线分析** | 轻量级 | 日志写入 CLS，Python 脚本离线分析 |
| **Elasticsearch** | 中型项目 | 自建 ES 集群存储，Kibana 可视化 |
| **腾讯云日志服务 (CLS) + EA** | 生产环境 | 对接鹰眼，支持实时分析 |
| **MongoDB** | 快速验证 | 直接写入 MongoDB 集合 |

### 推荐：MongoDB 本地存储

```javascript
// cloud/trace-collector/index.js — 专门接收 Trace 数据的云函数

const { withTrace } = require('../middleware/trace')
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const COLLECTION = 'traces'

const handler = async function(event, context) {
  const { spans } = event

  if (!Array.isArray(spans) || spans.length === 0) {
    return { code: 0, count: 0 }
  }

  const records = spans.map(span => ({
    traceId: span.traceId,
    spanId: span.spanId,
    parentSpanId: span.parentSpanId || '',
    service: span.service,
    operation: span.operation,
    duration: span.duration,
    status: span.status,
    tags: sanitizeTags(span.tags || {}),
    logs: span.logs || [],
    timestamp: span.timestamp || new Date().toISOString(),
    receivedAt: new Date()
  }))

  await db.collection(COLLECTION).add({ data: records })

  return { code: 0, count: records.length }
}

exports.main = withTrace(handler)
```

### Trace 分析脚本

```python
# scripts/analyze_trace.py
"""分析 Trace 数据，生成调用链和性能报告"""

import argparse
import json
from collections import defaultdict
from pathlib import Path

def load_traces(traces_file: str) -> list:
    """从 JSON Lines 文件加载 Trace"""
    traces = defaultdict(list)
    with open(traces_file) as f:
        for line in f:
            span = json.loads(line)
            if span.get('type') == 'span':
                traces[span['traceId']].append(span)
    return traces

def build_call_tree(spans: list) -> dict:
    """构建调用树"""
    span_map = {s['spanId']: s for s in spans}
    roots = []

    for span in spans:
        if not span.get('parentSpanId') or span['parentSpanId'] not in span_map:
            roots.append(span)

    return {'roots': roots, 'spans': span_map}

def render_call_tree(trace_id: str, tree: dict, depth=0):
    """渲染调用树为文本"""
    lines = []
    for root in tree['roots']:
        lines.extend(_render_span(root, tree['spans'], depth))
    return '\n'.join(lines)

def _render_span(span: dict, span_map: dict, depth: int) -> list:
    indent = '  ' * depth
    duration_ms = span['duration'] / 1000
    status_icon = ['✓', '⚠', '✗'][span.get('status', 0)]
    lines = [f"{indent}{status_icon} {span['service']}.{span['operation']} {duration_ms:.2f}ms"]

    # 找子节点
    children = [s for s in span_map.values() if s.get('parentSpanId') == span['spanId']]
    for child in sorted(children, key=lambda s: s['timestamp'] or ''):
        lines.extend(_render_span(child, span_map, depth + 1))

    return lines

def generate_report(trace_id: str, spans: list) -> str:
    """生成单条 Trace 的报告"""
    total_duration = max(s['duration'] for s in spans if s.get('timestamp'))
    services = defaultdict(lambda: {'count': 0, 'total_duration': 0})

    for span in spans:
        svc = span['service']
        services[svc]['count'] += 1
        services[svc]['total_duration'] += span['duration']

    lines = [
        f"# Trace Report — {trace_id}",
        f"",
        f"## 概览",
        f"- 总耗时: {total_duration / 1000:.2f}ms",
        f"- 服务节点: {len(spans)}",
        f"- 服务种类: {len(services)}",
        f"",
        f"## 服务统计",
        f"| 服务 | 调用次数 | 总耗时 | 平均耗时 |",
        f"|------|-----------|--------|----------|",
    ]

    for svc, stats in sorted(services.items(), key=lambda x: -x[1]['total_duration']):
        avg = stats['total_duration'] / max(stats['count'], 1)
        lines.append(f"| {svc} | {stats['count']} | {stats['total_duration']/1000:.2f}ms | {avg/1000:.2f}ms |")

    lines.extend(["", "## 调用链", "```", render_call_tree(trace_id, build_call_tree(spans)), "```"])
    return '\n'.join(lines)

def main():
    parser = argparse.ArgumentParser(description="Analyze trace data")
    parser.add_argument("--trace-id", help="Specific trace ID to analyze")
    parser.add_argument("--traces-file", required=True, help="Path to traces JSONL file")
    parser.add_argument("--output", help="Output report file")
    args = parser.parse_args()

    traces = load_traces(args.traces_file)

    if args.trace_id:
        if args.trace_id in traces:
            report = generate_report(args.trace_id, traces[args.trace_id])
            if args.output:
                Path(args.output).write_text(report)
            print(report)
        else:
            print(f"Trace {args.trace_id} not found")
    else:
        # 汇总统计
        print(f"Total traces: {len(traces)}")
        # 找耗时最长的 Top 10
        top = sorted(traces.items(), key=lambda x: max(s[0]['duration'] for s in x[1]))[-10:]
        print("\nTop 10 slowest traces:")
        for tid, spans in reversed(top):
            max_dur = max(s['duration'] for s in spans) / 1000
            print(f"  {tid[:32]} — {max_dur:.2f}ms, {len(spans)} spans")

if __name__ == '__main__':
    main()
```

**使用方式：**
```bash
# 从 MongoDB 导出 traces
python3 scripts/analyze_trace.py \
  --traces-file traces.jsonl \
  --trace-id 0000ABC123DEF456789012345678901234567 \
  --output trace-report.md
```

---

## 监控告警配置

### 核心监控指标

| 指标 | 告警阈值 | 持续时间 |
|------|---------|---------|
| P99 响应耗时 | > 5000ms | 5 分钟 |
| 错误率 | > 1% | 2 分钟 |
| Trace 丢失率 | > 10% | 5 分钟 |
| 慢查询占比 | > 5% | 5 分钟 |

### 配置告警

```json
// deploy-config.json 告警配置
"monitoring": {
  "enabled": true,
  "alertChannels": ["webhook", "email"],
  "rules": [
    {
      "name": "p99-latency-high",
      "metric": "trace.p99.duration",
      "threshold": 5000,
      "operator": ">",
      "window": "5m",
      "severity": "warning"
    },
    {
      "name": "error-rate-critical",
      "metric": "trace.error_rate",
      "threshold": 1,
      "operator": ">",
      "window": "2m",
      "severity": "critical"
    }
  ]
}
```

---

## 部署 Config

在 `deploy-config.json` 中新增 tracing 配置：

```json
// .harness/deploy-config.json
{
  "tracing": {
    "enabled": true,
    "sampled": true,
    "sampleRate": 1.0,
    "collector": {
      "type": "mongodb",
      "collection": "traces",
      "envId": "prod-env-id"
    },
    "middleware": {
      "path": "./cloud/middleware/trace.js",
      "autoInject": true
    },
    "storage": {
      "type": "mongodb | elasticsearch | cls",
      "retentionDays": 7,
      "aggregationInterval": "1h"
    },
    "alerts": [
      {
        "name": "slow-trace",
        "threshold": 3000,
        "unit": "ms",
        "window": "5m"
      }
    ]
  }
}
```

### 部署检查清单

- [ ] `cloud/middleware/trace.js` 已部署到所有云函数目录
- [ ] 所有云函数入口已用 `withTrace()` 包裹
- [ ] Trace collector 云函数已部署
- [ ] `deploy-config.json` tracing 配置已填写
- [ ] 日志分析脚本可用
- [ ] 告警规则已配置
