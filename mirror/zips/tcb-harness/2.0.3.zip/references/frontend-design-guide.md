# Frontend Design Guide — 跨平台前端架构参考

> 本文档为小程序和 Web 前端提供共用的架构原则和模式。平台特定细节分别见 `miniprogram-guide.md` 和 `web-guide.md`。

## 目录

1. [通用架构原则](#通用架构原则)
2. [服务层设计](#服务层设计)
3. [数据模型层](#数据模型层)
4. [状态管理模式](#状态管理模式)
5. [错误处理](#错误处理)
6. [性能优化](#性能优化)

---

## 通用架构原则

### 分层架构（两端通用）

```
View (Page/Component)
    ↓ 事件触发
Service Layer (业务逻辑 + API 调用)
    ↓ 数据转换
Model Layer (数据校验 + 类型定义)
    ↓ 持久化
CloudBase API / wx.cloud / @cloudbase/js-sdk
```

### 依赖规则

- **View** → Service, Model, Utils
- **Service** → Model, Utils，**禁止**直接依赖 View
- **Model** → Utils，**禁止**依赖 Service、View
- **Utils** → **禁止**依赖业务层

---

## 服务层设计

### 原则

1. 一个服务文件对应一个业务域（如 `order.js`、`user.js`）
2. 服务层封装所有 CloudBase API 调用
3. 统一错误处理，不在服务层显示 UI 反馈

### 服务模板

```javascript
// services/order.js (小程序版)
// services/orderService.js (Web版，导出为ESM)

const cloud = require('wx-server-sdk')  // 小程序端用 wx.cloud
// 或 Web 端: import { db } from '@/utils/cloud'

const COLLECTION = 'orders'

/**
 * 获取订单列表
 * @param {object} params - { page, status, openid }
 * @returns {Promise<{orders: Order[], hasMore: boolean}>}
 */
export async function getOrderList({ page = 0, status, openid }) {
  const PAGE_SIZE = 20
  const query = db.collection(COLLECTION)

  if (status) {
    query.where({ status, openid })
  } else {
    query.where({ openid })
  }

  const res = await query
    .orderBy('createdAt', 'desc')
    .skip(page * PAGE_SIZE)
    .limit(PAGE_SIZE)
    .get()

  return {
    orders: res.data,
    hasMore: res.data.length === PAGE_SIZE
  }
}

/**
 * 创建订单
 * @param {OrderInput} input
 * @returns {Promise<{orderId: string, totalAmount: number}>}
 */
export async function createOrder(input) {
  // Validation
  if (!input.items || input.items.length === 0) {
    throw new ServiceError('Items cannot be empty', 400)
  }

  const totalAmount = input.items.reduce((sum, i) => sum + i.quantity * i.price, 0)

  const res = await db.collection(COLLECTION).add({
    data: {
      ...input,
      totalAmount,
      status: 'created',
      createdAt: db.serverDate()
    }
  })

  return { orderId: res.id, totalAmount }
}

/**
 * ServiceError — 业务异常
 */
export class ServiceError extends Error {
  constructor(message, code = 500) {
    super(message)
    this.code = code
    this.name = 'ServiceError'
  }
}
```

---

## 数据模型层

### 小程序 Model

```javascript
// models/order.js
const VALID_STATUSES = ['created', 'paid', 'shipped', 'completed', 'cancelled']

function validateOrder(data) {
  const errors = []

  if (!data.items || !Array.isArray(data.items) || data.items.length === 0) {
    errors.push('items must be a non-empty array')
  }

  if (data.totalAmount !== undefined && data.totalAmount < 0) {
    errors.push('totalAmount must be non-negative')
  }

  if (data.status && !VALID_STATUSES.includes(data.status)) {
    errors.push(`status must be one of: ${VALID_STATUSES.join(', ')}`)
  }

  return { valid: errors.length === 0, errors }
}

function toDisplayOrder(order) {
  return {
    id: order._id,
    items: order.items,
    totalAmount: order.totalAmount,
    status: order.status,
    statusText: STATUS_TEXT[order.status] || order.status,
    createdAt: formatDate(order.createdAt)
  }
}

const STATUS_TEXT = {
  created: '待支付',
  paid: '已支付',
  shipped: '已发货',
  completed: '已完成',
  cancelled: '已取消'
}
```

### Web Model（TypeScript 风格）

```typescript
// models/order.ts
interface OrderItem {
  productId: string
  name: string
  price: number
  quantity: number
}

interface Order {
  _id: string
  openid: string
  items: OrderItem[]
  totalAmount: number
  status: OrderStatus
  createdAt: Date
  updatedAt?: Date
}

type OrderStatus = 'created' | 'paid' | 'shipped' | 'completed' | 'cancelled'

function validateOrder(input: Partial<Order>): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  if (!input.items?.length) errors.push('items required')
  if (input.totalAmount !== undefined && input.totalAmount < 0) errors.push('invalid totalAmount')
  return { valid: errors.length === 0, errors }
}
```

---

## 状态管理模式

### 页面状态管理原则

| 原则 | 说明 |
|------|------|
| 页面自治 | 每个页面的状态由自己管理，不污染全局 |
| 按需提升 | 仅当跨页面共享状态时才提升到 Store |
| 不可变更新 | 状态更新用展开符，不直接修改 |

### 小程序状态

```javascript
Page({
  data: {
    // 列表状态
    orders: [],
    page: 0,
    hasMore: true,
    loading: false,
    // UI 状态
    activeTab: 'all',
    showEmpty: false,
    // 错误状态
    error: null
  }
})
```

### Web 状态（React/Zustand 示例）

```javascript
// store/useOrderStore.js
import { create } from 'zustand'

export const useOrderStore = create((set, get) => ({
  orders: [],
  page: 0,
  hasMore: true,
  loading: false,
  error: null,

  setOrders: (orders) => set({ orders }),
  appendOrders: (newOrders) => set(s => ({ orders: [...s.orders, ...newOrders] })),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  incrementPage: () => set(s => ({ page: s.page + 1 })),
  reset: () => set({ orders: [], page: 0, hasMore: true, error: null })
}))
```

---

## 错误处理

### 分层错误处理策略

```
UI 层 — 显示用户友好的错误提示
Service 层 — 抛出 ServiceError，统一错误码
API 层 — 处理网络错误、超时、权限错误
```

### 小程序错误处理

```javascript
// utils/request.js — 云函数调用封装
export async function callFunction(name, data) {
  try {
    const res = await wx.cloud.callFunction({
      name,
      data
    })
    if (res.result.code !== 0) {
      throw new ServiceError(res.result.message, res.result.code)
    }
    return res.result.data
  } catch (err) {
    if (err.name === 'ServiceError') {
      throw err  // 业务异常，上层处理
    }
    // 网络异常
    throw new ServiceError('网络异常，请检查网络连接', -1)
  }
}

// Page 中处理
async function onSubmit() {
  try {
    await callFunction('create-order', this.data.form)
    wx.showToast({ title: '提交成功' })
    wx.navigateBack()
  } catch (err) {
    wx.showModal({
      title: '提交失败',
      content: err.message,
      showCancel: false
    })
  }
}
```

---

## 性能优化

### 两端通用原则

| 优化点 | 小程序 | Web |
|--------|--------|------|
| 列表懒加载 | `scroll-view` + `lower-threshold` | IntersectionObserver / React Query |
| 图片优化 | 云存储 CDN + 合适尺寸 | WebP 格式 + CDN |
| 缓存策略 | `wx.setStorageSync` + TTL | localStorage / Service Worker |
| 依赖分包 | subPackages | Code Splitting (Vite/Rspack) |

### 小程序列表优化

```javascript
onReachBottom() {
  if (this.data.loading || !this.data.hasMore) return
  this.setData({ loading: true })
  this.loadOrders().finally(() => this.setData({ loading: false }))
}
```

### Web 列表优化

```javascript
// React Query 自动分页
const { data, fetchNextPage, hasNextPage } = useInfiniteQuery({
  queryKey: ['orders'],
  queryFn: ({ pageParam = 0 }) => fetchOrders(pageParam),
  getNextPageParam: (lastPage, pages) => lastPage.hasMore ? pages.length : undefined
})
```
