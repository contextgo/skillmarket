# Mobile Guide — 移动端 Web 专项设计

## 目录

1. [技术选型](#技术选型)
2. [项目结构](#项目结构)
3. [TDesign Mobile 接入](#tdesign-mobile-接入)
4. [路由与导航](#路由与导航)
5. [状态管理](#状态管理)
6. [部署配置](#部署配置)

---

## 技术选型

| 技术 | 选型 | 说明 |
|------|------|------|
| 组件库 | **TDesign Mobile React** | 腾讯官方移动端 React 组件库 |
| 框架 | React 18 + Vite | SPA 模式，类小程序体验 |
| 语言 | TypeScript | 强类型，必开 |
| 适配方案 | PostCSS + viewport 适配 | TDesign 默认方案 |
| 状态管理 | Zustand | 轻量，适合移动端 |
| 路由 | React Router 6 | 标准路由 |
| 离线 | Service Worker | PWA 支持（可选） |

**适用场景：** 移动端 H5 页面、移动端 WebApp、与小程序并存的移动端体验

---

## 项目结构

```
src/mobile/
├── public/
│   └── index.html
├── src/
│   ├── main.tsx
│   ├── App.tsx
│   ├── pages/                    # 页面
│   │   ├── Home/
│   │   │   └── index.tsx
│   │   └── Profile/
│   │       └── index.tsx
│   ├── components/              # 组件
│   │   ├── common/              # 通用
│   │   │   ├── Header/
│   │   │   └── TabBar/
│   │   └── business/            # 业务
│   │       └── ProductCard/
│   ├── services/                # API 调用
│   │   └── api.ts
│   ├── store/                   # 状态管理
│   │   └── useAppStore.ts
│   ├── hooks/                   # 自定义 Hooks
│   │   ├── useTrace.ts
│   │   └── useCloudDB.ts
│   ├── styles/                  # 样式
│   │   └── global.css
│   └── utils/                   # 工具
│       └── cloud.ts
├── .env
├── vite.config.ts
└── package.json
```

---

## TDesign Mobile 接入

### 安装

```bash
npm install tdesign-mobile-react
```

### 主题配置

```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  css: {
    preprocessorOptions: {
      less: {
        modifyVars: {
          // TDesign 主题变量定制
          '@brand-color': '#07C160',
          '@page-bg-color': '#f6f6f6',
        }
      }
    }
  }
})
```

### 初始化

```tsx
// src/main.tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import { ConfigProvider } from 'tdesign-mobile-react'
import 'tdesign-mobile-react/dist/style.css'
import './styles/global.css'

ReactDOM.createRoot(document.getElementById('app')!).render(
  <ConfigProvider theme={{ theme: 'primary' }}>
    <App />
  </ConfigProvider>
)
```

### 常用组件

| 组件 | 说明 |
|------|------|
| `Button` | 移动端按钮，支持多种尺寸/状态 |
| `Input` | 输入框，适配移动端键盘 |
| `Popup` | 底部弹出层，移动端主力交互 |
| `SwipeCell` | 滑动操作（删除/收藏等） |
| `Steps` | 步骤条，订单流程等场景 |
| `Skeleton` | 骨架屏，首屏加载 |
| `PullDownRefresh` | 下拉刷新 |
| `Tabs` | 标签页切换 |
| `Empty` | 空状态占位 |

### 移动端专用组件

```tsx
// pages/order-list/index.tsx
import { PullDownRefresh, List, Empty, Button } from 'tdesign-mobile-react'

function OrderList() {
  const [refreshing, setRefreshing] = useState(false)

  return (
    <PullDownRefresh
      value={refreshing}
      onRefresh={async () => {
        await loadOrders()
        setRefreshing(false)
      }}
    >
      <List>
        {orders.map(order => (
          <List.Item key={order._id}>
            <OrderCard order={order} />
          </List.Item>
        ))}
      </List>
    </PullDownRefresh>
  )
}
```

---

## 路由与导航

### 路由配置

```tsx
// src/router/index.tsx
import { createBrowserRouter } from 'react-router-dom'

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: '/product/:id', element: <ProductDetail /> },
      { path: '/order/:id', element: <OrderDetail /> },
    ]
  },
  {
    path: '/login',
    element: <Login />
  }
])
```

### 移动端导航栏

```tsx
// components/common/Header/index.tsx
import { NavBar } from 'tdesign-mobile-react'

function Header({ title, fixed, leftIcon }) {
  return (
    <NavBar
      title={title}
      fixed={fixed}
      leftIcon={leftIcon}
      onLeftClick={() => history.back()}
    />
  )
}
```

---

## 状态管理

### Zustand Store

```typescript
// store/useOrderStore.ts
import { create } from 'zustand'

interface OrderState {
  orders: Order[]
  loading: boolean
  setOrders: (orders: Order[]) => void
  appendOrders: (orders: Order[]) => void
  setLoading: (loading: boolean) => void
  reset: () => void
}

export const useOrderStore = create<OrderState>((set) => ({
  orders: [],
  loading: false,
  setOrders: (orders) => set({ orders }),
  appendOrders: (newOrders) => set(s => ({ orders: [...s.orders, ...newOrders] })),
  setLoading: (loading) => set({ loading }),
  reset: () => set({ orders: [], loading: false })
}))
```

---

## 部署配置

### 移动端 Web 部署配置

```json
// deploy-config.json 中移动端配置
"frontend": {
  "mobile": {
    "srcPath": "./src/mobile",
    "buildCommand": "npm run build",
    "outputPath": "./dist",
    "buildVerified": false,
    "deployedAt": null,
    "staticHosting": {
      "enabled": true,
      "envId": "prod-env-id",
      "domain": null,
      "customDomain": null,
      "cdn": true
    },
    "pwa": {
      "enabled": false,
      "manifest": "/manifest.json"
    }
  }
}
```

### 构建产出

```bash
npm run build
# 输出到 dist/ 目录
# 通过 CloudBase 静态托管部署
```

---

## 与小程序/ Web 的对比

| 维度 | 移动端 H5 | 小程序 | PC Web |
|------|----------|--------|--------|
| 入口 | 浏览器/扫码 | 微信内入口 | 浏览器 |
| 组件库 | TDesign Mobile | TDesign Miniprogram | TDesign React |
| 路由 | BrowserRouter | 微信路由 | BrowserRouter |
| 分享 | 浏览器分享 API | 微信分享 API | 浏览器分享 API |
| 登录 | 跳转登录页 | 静默 OPENID | 跳转登录页 |
| 部署 | 静态托管 | 微信审核 | 静态托管 |
