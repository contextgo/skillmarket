/**
 * 微信 JSSDK 初始化工具
 *
 * 使用方式：
 *   1. 前端调用后端云函数获取签名（signature）
 *   2. 调用 initJSSDK(config) 完成初始化
 *   3. 调用 wx.miniProgram.navigateBack() 等 JSSDK API
 *
 * 所需后端接口：GET /getJSSDKConfig?url=当前页面URL
 *   返回：{ appId, timestamp, nonceStr, signature }
 *
 * 踩坑：
 *   - 签名 URL 必须是当前页面的完整 URL（不含 # 及其后面部分）
 *   - 公众平台后台需配置 JS 安全域名
 *   - 每年需重新生成 jsapi_ticket
 */

let wxReady = false
let wxError = false

/**
 * @param {object} config - JSSDK 配置参数
 * @param {string} config.appId - 公众号 AppID
 * @param {number} config.timestamp - 时间戳
 * @param {string} config.nonceStr - 随机字符串
 * @param {string} config.signature - 签名
 * @param {string[]} [config.jsApiList] - 需要使用的 JS API 列表
 * @returns {Promise<void>}
 */
export async function initJSSDK({ appId, timestamp, nonceStr, signature, jsApiList = [] }) {
  return new Promise((resolve, reject) => {
    if (!window.wx) {
      console.warn('[wxJSSDK] wx.js 未加载，请引入 https://res.wx.qq.com/open/js/jweixin-1.6.0.js')
      reject(new Error('wx 未定义'))
      return
    }

    wx.config({
      debug: false,
      appId,
      timestamp,
      nonceStr,
      signature,
      jsApiList: [
        'checkJsApi',
        'updateAppMessageShareData',
        'updateTimelineShareData',
        'onMenuShareWeibo',
        'hideMenuItems',
        'showMenuItems',
        'hideAllNonBaseMenuItem',
        'showAllNonBaseMenuItem',
        'chooseImage',
        'previewImage',
        'uploadImage',
        'downloadImage',
        'getNetworkType',
        'openLocation',
        'getLocation',
        'openProductSpecificView',
        'addCard',
        'chooseCard',
        'openCard',
        ...jsApiList,
      ],
    })

    wx.ready(() => {
      wxReady = true
      console.log('[wxJSSDK] 初始化成功')
      resolve()
    })

    wx.error((res) => {
      wxError = true
      console.error('[wxJSSDK] 初始化失败', res)
      reject(new Error(res.errMsg || 'JSSDK 初始化失败'))
    })
  })
}

/**
 * 获取当前页面完整 URL（用于签名）
 */
export function getCurrentUrl() {
  return window.location.href.split('#')[0]
}

export { wxReady, wxError }
