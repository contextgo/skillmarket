import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'

function Home() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">公众号应用</h1>
        <p className="text-gray-600 mb-6">基于 CloudBase 的微信公众号 H5 应用</p>
        <button
          className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          onClick={() => {
            if (window.wx) {
              window.wx.miniProgram.navigateBack()
            } else {
              alert('请在微信内置浏览器中打开')
            }
          }}
        >
          返回公众号
        </button>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
    </BrowserRouter>
  )
}
