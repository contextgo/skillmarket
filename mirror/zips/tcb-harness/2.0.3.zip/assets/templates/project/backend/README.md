# Backend (云函数) Project Template

## 目录结构

```
backend/
└── cloud/
    ├── create-order/
    │   ├── index.js            # 云函数入口
    │   └── package.json
    ├── get-user/
    │   ├── index.js
    │   └── package.json
    ├── search/
    │   ├── index.js
    │   └── package.json
    └── _middleware/
        └── trace.js           # 链路追踪中间件
```

## 技术栈

- **运行时:** Node.js 18
- **框架:** wx-server-sdk / tcb-node-sdk
- **中间件:** 自定义 trace 中间件（鹰眼兼容）

## 云函数规范

- 每个云函数独立目录
- `index.js` 导出 `main` 函数
- 环境变量: `SCF_NAMESPACE`, `TCB_REGION`
- 超时: 默认 3s，最长 20s

## 中间件

`withTrace()` 中间件自动：
- 解析 / 注入 Trace ID
- 生成 Span ID
- 输出 JSON 结构化日志

## 本地测试

```bash
# 使用 CloudBase CLI
tcb fn invoke create-order --envId <envId>

# 本地模拟
npx tcb-framework local
```