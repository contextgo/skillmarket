# Mini Program Project Template

## 目录结构

```
miniprogram/
├── cloud/                    # 云函数（可选）
├── src/
│   ├── app.js                 # 应用入口
│   ├── app.json               # 应用配置
│   ├── app.wxss               # 全局样式
│   ├── pages/
│   │   └── index/
│   │       ├── index.js
│   │       ├── index.wxml
│   │       ├── index.wxss
│   │       └── index.json
│   ├── components/            # 组件
│   ├── services/              # 业务服务
│   ├── models/                # 数据模型
│   └── utils/                 # 工具函数
├── test/                      # 测试
├── project.config.json
├── package.json
└── README.md
```

## 技术栈

- **框架:** 微信小程序原生 + TDesign Miniprogram
- **样式:** WXSS + 设计系统变量
- **云开发:** wx.cloud / tcb-node-sdk
- **测试:** Midscene.js

## 使用方法

1. 复制到项目 `src/miniprogram/` 目录
2. 修改 `project.config.json` 中的 appid
3. 运行 `npm install`
4. 使用微信开发者工具导入

## 快速初始化

```bash
# 使用 tcb-harness
python3 scripts/init_project.py --name <project> --platform mp --appid <appid>
```