# Web Project Template

## 目录结构

```
web/
├── src/
│   ├── App.jsx                 # React 根组件
│   ├── main.jsx               # 入口
│   ├── pages/                 # 页面
│   ├── components/            # 组件
│   ├── services/             # 业务服务
│   ├── models/                # 数据模型
│   └── styles/                # 样式
│       └── global.css
├── dist/                      # 构建输出
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── tailwind.config.js
└── postcss.config.js
```

## 技术栈

- **框架:** React 18 + TypeScript
- **UI:** TDesign React
- **样式:** Tailwind CSS
- **构建:** Vite
- **云开发:** @cloudbase/js-sdk
- **测试:** Playwright

## 使用方法

```bash
cd web
npm install
npm run dev    # 开发
npm run build  # 构建
```

## 快速初始化

```bash
python3 scripts/init_project.py --name <project> --platform web --appid <appid>
```