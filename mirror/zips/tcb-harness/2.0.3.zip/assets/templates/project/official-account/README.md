# Official Account (公众号) H5 Project Template

## 目录结构

```
official-account/
├── src/
│   ├── App.jsx                 # React 根组件
│   ├── main.jsx               # 入口
│   ├── pages/                 # 页面
│   ├── components/            # 组件
│   ├── utils/
│   │   └── wxJSSDK.js        # 微信 JSSDK 封装
│   └── styles/
│       └── global.css
├── dist/                      # 构建输出
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── tailwind.config.js
└── postcss.config.js
```

## 技术栈

- **框架:** React 18 + TypeScript
- **UI:** TDesign React
- **样式:** Tailwind CSS
- **构建:** Vite
- **微信:** JSSDK + OAuth 2.0

## JSSDK 配置流程

1. 公众平台 → 设置与开发 → 公众号设置 → 功能设置
2. JS接口安全域名配置
3. 同在公众平台设置网页授权域名
4. 后台提供 signature 接口

## 使用方法

```bash
cd official-account
npm install
npm run dev    # 开发
npm run build  # 构建（需配置环境变量）
```

## 环境变量

```
VITE_APPID=wx1234567890
VITE_API_BASE=https://your-env.tcloudbase.com
```