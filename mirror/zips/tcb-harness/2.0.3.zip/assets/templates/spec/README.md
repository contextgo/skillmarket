# Spec Templates

本目录存放需求文档和技术方案模板，配合 `references/spec-guide.md` 使用。

## 模板文件

```
spec/
├── requirements.md.tpl     # 需求文档模板（EARS 格式）
├── design.md.tpl           # 技术方案模板
├── tasks.md.tpl            # 任务分解模板
└── review.md.tpl           # 评审记录模板
```

## 使用方法

1. 复制模板到 `specs/<spec-name>/`
2. 按 EARS 格式填写需求
3. 使用 `validate_spec.py` 校验
4. 评审通过后进入设计阶段

## 相关工具

- `scripts/validate_spec.py` — 校验需求文档质量
- `scripts/gen_test_cases.py` — 从需求生成测试用例
- `scripts/gen_test_data.py` — 生成 Mock 测试数据