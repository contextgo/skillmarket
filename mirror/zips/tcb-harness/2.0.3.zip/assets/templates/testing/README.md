# Testing Templates

本目录存放测试相关模板，配合 `references/testing-guide.md` 和 `references/automation-guide.md` 使用。

## 目录结构

```
testing/
├── unit/
│   └── template/
├── integration/
│   └── template/
├── e2e/
│   ├── miniprogram/          # Midscene.js 模板
│   │   └── template/
│   └── web/                  # Playwright 模板
│       └── template/
├── test-data/
│   └── template/
└── reports/
    └── template/
```

## 测试工具

| 层级 | 工具 | 配置 |
|------|------|------|
| Unit | Jest | jest.config.ts |
| Integration | Jest + SuperTest | - |
| 小程序 E2E | Midscene.js | midscene.config.ts |
| Web E2E | Playwright | playwright.config.ts |

## 快速生成

```bash
# 生成测试用例
python3 scripts/gen_test_cases.py --spec specs/<name>/requirements.md --output tests/

# 生成测试数据
python3 scripts/gen_test_data.py --spec specs/<name>/requirements.md --output tests/test-data/
```

## CI/CD 集成

参考 `references/automation-guide.md` 中的 GitHub Actions 配置。