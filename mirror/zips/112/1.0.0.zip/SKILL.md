---
name: we-tools
description: 微医常用工具集，用于活动信息查询、短链接生成、用户Token生成、短信验证码查询、问诊订单查询和Kano文件上传。使用场景：(1) 查询活动管理员、链接等信息；(2) 生成短链接便于分享；(3) 生成用户认证Token；(4) 查询短信验证码；(5) 查询问诊订单详情；(6) 上传文件到Kano CDN获取访问链接；(7) 替换已有CDN资源文件。当用户提到活动信息、活动管理员、短链接、URL缩短、用户Token、短信验证码、问诊订单、上传文件、上传图片、Kano上传、CDN上传等关键词时使用此技能。
---

# we-tools

微医常用工具集，提供活动信息查询、短链接生成、用户Token生成、短信验证码查询、问诊订单查询和 Kano 文件上传功能。

## 脚本位置

本 skill 包含一个 Python 脚本，调用时需使用绝对路径：

**脚本位置**: `<skill-path>/scripts/we_tools.py`

> 注意：`<skill-path>` 是 skill 的根目录，当 skill 被加载时会显示在 "Skill Path" 信息中。

## 功能概览

| 功能 | 工具 | 详细文档 |
|------|------|----------|
| 活动查询 | Python 脚本 | `references/activity.md` |
| 短链接生成 | Python 脚本 | `references/shorturl.md` |
| 获取用户 Token | `wecli` | `references/user-token.md` |
| 获取短信验证码 | `wecli` | `references/sms.md` |
| 查询问诊订单 | `wecli` | `references/consult.md` |
| Kano 文件上传/替换/查询 | `wecli` | `references/kano.md` |

## 功能路由

根据用户的意图，读取对应的功能文档获取完整的命令参数、示例和注意事项：

- 用户提到 **活动、活动管理员、活动链接、活动查询** → 读取 `references/activity.md`
- 用户提到 **短链接、URL缩短、生成短链** → 读取 `references/shorturl.md`
- 用户提到 **Token、用户Token、获取Token、登录凭证** → 读取 `references/user-token.md`
- 用户提到 **验证码、短信、短信验证码** → 读取 `references/sms.md`
- 用户提到 **问诊订单、订单详情、订单查询** → 读取 `references/consult.md`
- 用户提到 **上传、上传文件、上传图片、Kano、CDN上传、替换文件、kanoId** → 读取 `references/kano.md`

> 当识别到用户意图后，先读取对应的 reference 文件，再根据文档中的命令格式执行操作。

## 全局注意事项

1. **wecli 依赖**: 部分功能（Token、短信、问诊、Kano）依赖 `wecli` 命令行工具，确保环境已安装
2. **脚本路径**: Python 脚本功能（活动、短链接）必须使用 `<skill-path>/scripts/we_tools.py` 的绝对路径调用
3. **输出规范**: 每个功能的输出格式已在各 reference 文档中定义，严格按照规范格式化输出
