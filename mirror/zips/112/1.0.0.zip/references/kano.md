# Kano 文件管理

上传文件到 Kano CDN、替换已有 CDN 资源、查询文件 CDN 地址。默认自动 TinyPNG 压缩图片。

> 本功能使用 `wecli` 命令行工具，无需调用脚本。

## 命令详解

### 文件上传

```bash
wecli uploadFile <file> [--type <file_type>] [--no-compress]
```

**参数说明：**
- `file`: 本地文件路径（必需）
- `--type`: 文件类型（可选，自动识别）
  - `img`: 图片（jpg/jpeg/png/gif/svg）
  - `doc`: 文档（html/xml/js/css/json/ts/md/csv/key/txt/jar/pdf/doc/docx/ppt/pptx/xls/xlsx/sketch）
  - `video`: 视频（avi/mp4/wav/wma）
  - `pkg`: 压缩包（zip/rar）
  - `audio`: 音频（mp3/amr/aud/ogg）
  - `font`: 字体（otf/ttc/ttf/eot/woff）
- `--no-compress`: 禁用 TinyPNG 压缩（默认开启，仅对图片类型生效）

**示例：**

```bash
# 上传图片（自动压缩）
wecli uploadFile ./logo.png

# 上传文档
wecli uploadFile ./readme.pdf

# 禁用压缩
wecli uploadFile ./photo.jpg --no-compress
```

### 文件替换

```bash
wecli uploadFile <file> --kano-id <kano_id> [--no-compress]
```

**参数说明：**
- `file`: 本地新文件路径（必需）
- `--kano-id`: 已有资源的 kanoId（必需）
- `--no-compress`: 禁用 TinyPNG 压缩（默认开启，仅对图片类型生效）

**示例：**

```bash
# 替换已有图片
wecli uploadFile ./new-logo.png --kano-id abc123xyz
```

### 文件查询

```bash
wecli uploadFile info <kanoId>
```

**参数说明：**
- `kanoId`: Kano 文件 ID（必需）

**示例：**

```bash
wecli uploadFile info abc123xyz
```

## 工作流程

### 上传流程

1. 用户提供本地文件路径
2. 系统调用 `wecli uploadFile` 命令
3. wecli 自动识别文件类型
4. 如果是图片类型，默认调用 TinyPNG API 压缩
5. 生成 MD5 签名并上传到 Kano CDN
6. 返回 kanoId 和 CDN 访问地址

### 替换流程

1. 用户提供新文件路径和目标 kanoId
2. 系统调用 `wecli uploadFile --kano-id` 命令
3. wecli 替换目标资源（CDN 地址不变，内容更新）

## API 参考

**上传端点**: `POST https://kano-control.guahao.cn/uploadfile`

**替换端点**: `POST https://kano-control.guahao.cn/modifyfile`

**CDN 访问**: `https://kano.guahao.com/{kanoId}`

**签名算法**: `MD5("bizCode={bizCode}&kanoFileId={kanoId}&orginFileName={filename}{signKey}")`

**文件类型与 bizCode 映射**:

| 文件类型 | bizCode | signKey |
|----------|---------|---------|
| img (图片) | `kano-we-picture-upload` | `cc99ca0e55344cb3ad7facce5114499d` |
| audio (音频) | `kano-we-picture-node-audio` | `cc99ca0e55344cb3ad7facce5114499d` |
| pkg (压缩包) | `kano-we-picture-compress-pkg-upload` | `cc99ca0e55344cb3ad7facce5114499d` |
| video (视频) | `kano-we-picture-video` | `cc99ca0e55344cb3ad7facce5114499d` |
| doc (文档) | `we-picture-node-other-file` | `cc99ca0e55344cb3ad7facce5114499d` |
| font (字体) | `we-picture-node-font` | `cc99ca0e55344cb3ad7facce5114499d` |

**文件大小限制**:
- 默认最大 **50MB**
- GIF 图片额外限制：不超过 **3MB**

## 输出规范

### 上传输出

```
✅ 文件上传成功！

📁 文件信息:
   文件名: {filename}
   文件类型: {fileType} ({typeLabel})
   文件大小: {fileSize}

🔗 CDN 访问地址:
   {cdnUrl}

📋 kanoId: {kanoId}
```

> 如果触发了 TinyPNG 压缩（仅图片类型），额外显示压缩信息：

```
🗜️  TinyPNG 压缩:
   原始大小: {originalSize}
   压缩后: {compressedSize}
   节省: {percentage}%
```

## 常见场景

### 上传图片到 CDN

**用户**: "帮我把这张图片上传到 Kano"

**执行步骤**:
1. 确认文件路径
2. 调用 `wecli uploadFile` 命令上传
3. 返回 CDN 访问地址和 kanoId

### 替换 CDN 上的文件

**用户**: "帮我替换 kanoId 为 abc123xyz 的图片"

**执行步骤**:
1. 确认新文件路径和 kanoId
2. 调用 `wecli uploadFile --kano-id abc123xyz` 命令替换
3. 返回更新确认

### 获取 CDN 链接

**用户**: "kanoId abc123xyz 的 CDN 地址是什么？"

**执行步骤**:
1. 调用 `wecli uploadFile info abc123xyz` 命令查询
2. 返回 CDN 访问地址

## 注意事项

1. **文件类型识别**: wecli 根据文件扩展名自动识别类型，如果扩展名不在支持列表中，上传会失败
2. **签名一致性**: Kano 上传和替换使用相同的 signKey，但替换接口的签名需要额外包含 kanoFileId
3. **替换不可逆**: 文件替换后原文件内容无法恢复，CDN 地址保持不变
4. **GIF 限制**: 由于 Kano 对帧数过多的 GIF 处理有缺陷，GIF 文件不能超过 3MB
5. **CDN 缓存**: 替换文件后，CDN 可能有缓存延迟，如需立即生效可加时间戳参数：`https://kano.guahao.com/{kanoId}?t=1234567890`
6. **TinyPNG 压缩**: `wecli uploadFile` 默认对图片类型（jpg/jpeg/png/gif/svg）自动使用 TinyPNG 压缩，可使用 `--no-compress` 禁用。压缩使用 we-picture 项目的 API Key，多个 Key 随机分配
