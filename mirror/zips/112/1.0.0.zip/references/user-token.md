# 用户 Token 获取

免去手工打开 Network 网络抓包的过程，直接在命令行获取微医内部某环境 User 的合法认证 Access Token 供联调使用。

> 本功能使用 `wecli` 命令行工具，无需调用脚本。

## 命令详解

```bash
# [推荐] 通过手机号直接寻找该用户并生成 Token
wecli user token --mobile 17857570520

# 根据具体的传统 user-id 生成
wecli user token --user-id 34243412

# 可选：指定 source-id (默认 27) 或是 token 被要求的标准类型
wecli user token --mobile 13625816211 --source-id 27
```

**参数说明：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--user-id` | string | 无 | 用户登录 ID（如果已知的话，与 mobile 二选一输入） |
| `--mobile` | string | 无 | 对方手机号。设置后框架将智能拉取全网用户列表 DOM 定位 ID 再换取 Token |
| `--source-id` | string | 27 | 生成 Token 时的客户端 / 来源模拟 ID |
| `--token-type` | string | bearer | Token 的签发类型 |

## 常见场景

### 获取用户 Token

**用户**: "帮我获取手机号 17857570520 的用户 Token"

**执行步骤**:
1. 调用 `wecli user token --mobile 17857570520` 命令
2. 展示生成的 Access Token
