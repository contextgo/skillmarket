# 短链接生成

将长 URL 转换为短链接，便于分享和传播。

## 命令详解

```bash
python <skill-path>/scripts/we_tools.py shorturl <url>
```

**参数说明：**
- `url`: 原始 URL（必需）

**示例：**

```bash
python /path/to/we-tools/scripts/we_tools.py shorturl "https://www.example.com/very/long/path?param1=value1&param2=value2"
```

**输出格式：**

```
✅ 短链接生成成功！

原始链接: https://www.example.com/very/long/path?param1=value1&param2=value2
短链接: https://s.example.com/abc123
```

## 工作流程

1. 用户提供原始 URL
2. 系统调用短链接服务 API
3. 返回生成的短链接

## API 参考

**端点**: `GET https://codereview.wedoctort.com/api/common/getShortUrl.json`

**请求参数**:
```
category=perm
expiredTime=0
targetUrl=<encoded_url>
```

## 输出规范

生成短链接后，按照以下格式展示：

```
✅ 短链接生成成功！

原始链接: {original_url}
短链接: {short_url}
```

## 常见场景

### 生成分享链接

**用户**: "帮我生成一个短链接：https://example.com/long/path"

**执行步骤**:
1. 调用 `shorturl` 命令
2. 展示生成的短链接

## 注意事项

1. **有效期**: 生成的短链接为永久有效链接，无过期时间
2. **协议支持**: 支持 HTTP/HTTPS 协议
3. **URL 编码**: 特殊字符和中文会自动进行 URL 编码处理
4. **错误处理**: 如果 URL 无效，会返回明确的错误提示
