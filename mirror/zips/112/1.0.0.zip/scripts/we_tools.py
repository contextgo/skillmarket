#!/usr/bin/env python3
"""
wedoctor 工具集
用于活动查询和短链接生成
"""

import argparse
import json
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime


def format_date(date_value):
    """格式化日期，支持字符串和时间戳"""
    if not date_value:
        return ''
    
    # 如果是数字（时间戳）
    if isinstance(date_value, (int, float)):
        try:
            # 毫秒时间戳
            if date_value > 10000000000:
                dt = datetime.fromtimestamp(date_value / 1000)
            # 秒时间戳
            else:
                dt = datetime.fromtimestamp(date_value)
            return dt.strftime('%Y-%m-%d')
        except:
            return str(date_value)
    
    # 如果是字符串
    if isinstance(date_value, str):
        try:
            # 尝试分割 ISO 格式的日期字符串（如：2024-03-18T10:30:00）
            if 'T' in date_value:
                return date_value.split('T')[0]
            # 已经是 YYYY-MM-DD 格式
            return date_value
        except:
            return date_value
    
    return str(date_value)



def post(url: str, data: dict, headers: dict = None) -> dict:
    """发送 POST 请求"""
    if headers is None:
        headers = {'Content-Type': 'application/json'}
    
    req = urllib.request.Request(
        url,
        data=json.dumps(data).encode('utf-8'),
        headers=headers,
        method='POST'
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raise Exception(f"API请求失败: {e.code} - {e.reason}")
    except Exception as e:
        raise Exception(f"请求错误: {str(e)}")


def get(url: str, params: dict = None) -> dict:
    """发送 GET 请求"""
    if params:
        query_string = urllib.parse.urlencode(params)
        url = f"{url}?{query_string}"
    
    req = urllib.request.Request(url)
    
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raise Exception(f"API请求失败: {e.code} - {e.reason}")
    except Exception as e:
        raise Exception(f"请求错误: {str(e)}")


# ==================== 活动查询 ====================

PORTAL_API = "https://portal-gops.wedoctort.com/json/activity/list"


def query_activity(business_type: int, activity_id: int = None, name: str = None) -> list:
    """查询单个业务类型的活动"""
    params = {
        "status": None,
        "pageNo": 1,
        "pageSize": 20,
        "noAuth": True,
        "businessType": business_type
    }
    
    if activity_id:
        params["id"] = activity_id
    if name:
        params["name"] = name
    
    result = post(PORTAL_API, params)
    
    if result.get('code') != '0' or not result.get('data'):
        return []
    
    results = result['data'].get('results', [])
    
    return [
        {
            "name": item.get('name'),
            "manager": item.get('activityManager'),
            "url": item.get('accessUrl'),
            "created": format_date(item.get('gmtCreated')),
            "modified": format_date(item.get('gmtModified')),
            "modifier": item.get('userName')
        }
        for item in results
    ]


def get_activity(activity_id: int = None, name: str = None) -> list:
    """获取活动信息（支持多种业务类型）"""
    # 尝试不同的业务类型
    business_types = [0, 5, 6, 7, 8]
    
    for business_type in business_types:
        activities = query_activity(business_type, activity_id, name)
        if activities:
            return activities
    
    return []


# ==================== 短链接生成 ====================

SHORT_URL_API = "https://codereview.wedoctort.com/api/common/getShortUrl.json"


def create_short_url(url: str) -> str:
    """生成短链接"""
    params = {
        "category": "perm",
        "expiredTime": 0,
        "targetUrl": urllib.parse.quote(url, safe='')
    }
    
    result = get(SHORT_URL_API, params)
    
    if result.get('data'):
        return result['data']
    
    raise Exception("生成短链接失败")


# ==================== 命令行接口 ====================

def cmd_activity(activity_id: int = None, name: str = None):
    """查询活动信息"""
    try:
        if not activity_id and not name:
            print("错误: 请提供活动 ID 或名称")
            return
        
        activities = get_activity(activity_id, name)
        
        if not activities:
            print("未找到活动信息，请检查活动 ID 或名称是否正确")
            return
        
        print(f"找到 {len(activities)} 个活动：\n")
        
        for activity in activities:
            print(f"📌 {activity['name']}")
            print(f"   活动管理员: {activity['manager']}")
            print(f"   活动链接: {activity['url']}")
            print(f"   创建时间: {activity['created']}")
            print(f"   最后修改: {activity['modified']} by {activity['modifier']}")
            print()
            
    except Exception as e:
        print(f"错误: {str(e)}")


def cmd_short_url(url: str):
    """生成短链接"""
    try:
        short_url = create_short_url(url)
        
        print("✅ 短链接生成成功！\n")
        print(f"原始链接: {url}")
        print(f"短链接: {short_url}")
        
    except Exception as e:
        print(f"错误: {str(e)}")


def main():
    parser = argparse.ArgumentParser(description='wedoctor 工具集')
    subparsers = parser.add_subparsers(dest='command', help='命令')
    
    # 活动查询命令
    activity_parser = subparsers.add_parser('activity', help='查询活动信息')
    activity_parser.add_argument('--id', type=int, help='活动 ID')
    activity_parser.add_argument('--name', help='活动名称（支持模糊查询）')
    
    # 短链接命令
    shorturl_parser = subparsers.add_parser('shorturl', help='生成短链接')
    shorturl_parser.add_argument('url', help='原始 URL')
    
    args = parser.parse_args()
    
    if args.command == 'activity':
        cmd_activity(args.id, args.name)
    elif args.command == 'shorturl':
        cmd_short_url(args.url)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
