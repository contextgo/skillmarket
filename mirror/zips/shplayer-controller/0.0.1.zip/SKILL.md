---
name: shplayer-controller
description: 控制搜狐影音播放器 (SHPlayer)，需使用 7.3.1.0 及以上版本的搜狐影音。当用户提到播放视频、快进快退、调整倍速、切换字幕、截图、弹幕、搜索视频、管理壁纸等功能时触发。通过 mcporter 调用 SHPlayer MCP Server。
---

# shplayer-controller

## 前置要求

- 安装 **搜狐影音 7.3.1.0 及以上版本**（低于此版本不支持 MCP Server）
- 启动搜狐影音后，MCP Server 自动监听 `https://localhost.tv.sohu.com:7981/mcp`

## 快速开始

通过 mcporter 调用 `SHPlayer MCP Server`：

```bash
mcporter call --server "SHPlayer MCP Server" --tool <工具名> <参数>
```

## 播放控制

### 播放视频
```bash
# 本地视频
mcporter call --server "SHPlayer MCP Server" --tool play_media source_type=local file_path="C:\Videos\demo.mp4"

# 搜狐在线视频
mcporter call --server "SHPlayer MCP Server" --tool play_media source_type=online video_id="<video_id>"

# 网盘视频（百度/阿里/115）
mcporter call --server "SHPlayer MCP Server" --tool play_media source_type=baidu_drive video_id="<video_id>"
```

### 播放状态控制
```bash
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=play
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=pause
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=previous   # 上一个
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=next       # 下一个
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=restart    # 从头播放
```

### 弹幕开关
```bash
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=enable_danmaku
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=disable_danmaku
```

### 自动跳过片头片尾
```bash
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=enable_auto_skip
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=disable_auto_skip
```

### 无痕模式
```bash
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=enable_incognito
mcporter call --server "SHPlayer MCP Server" --tool control_playback action=disable_incognito
```

## 进度与倍速

### 进度跳转
```bash
# 跳转到第10分钟（600秒）
mcporter call --server "SHPlayer MCP Server" --tool adjust_playback action=seek value=600

# 快进30秒
mcporter call --server "SHPlayer MCP Server" --tool adjust_playback action=seek value=+30

# 快退30秒
mcporter call --server "SHPlayer MCP Server" --tool adjust_playback action=seek value=-30
```

### 倍速播放
```bash
# 支持 0.5, 0.8, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0
mcporter call --server "SHPlayer MCP Server" --tool adjust_playback action=speed value=1.5
mcporter call --server "SHPlayer MCP Server" --tool adjust_playback action=speed value=2.0
```

## 字幕管理

```bash
# 列出字幕
mcporter call --server "SHPlayer MCP Server" --tool manage_subtitle action=list

# 切换字幕（用 list 返回的 subtitle_id）
mcporter call --server "SHPlayer MCP Server" --tool manage_subtitle action=select subtitle_id=1

# 隐藏字幕
mcporter call --server "SHPlayer MCP Server" --tool manage_subtitle action=select subtitle_id=-1
```

## 画面调整

### 旋转/翻转
```bash
mcporter call --server "SHPlayer MCP Server" --tool transform_video action=cw9   # 顺时针90°
mcporter call --server "SHPlayer MCP Server" --tool transform_video action=ccw9  # 逆时针90°
mcporter call --server "SHPlayer MCP Server" --tool transform_video action=flip_h # 水平翻转
mcporter call --server "SHPlayer MCP Server" --tool transform_video action=flip_v # 垂直翻转
mcporter call --server "SHPlayer MCP Server" --tool transform_video action=reset  # 重置
```

### 截图
```bash
mcporter call --server "SHPlayer MCP Server" --tool take_snapshot
```

## 视频搜索

```bash
# 搜索搜狐在线视频
mcporter call --server "SHPlayer MCP Server" --tool search_media action=search keyword="电视剧" source_filter=online

# 搜索本地视频
mcporter call --server "SHPlayer MCP Server" --tool search_media action=search keyword="demo" source_filter=local

# 列出本地目录
mcporter call --server "SHPlayer MCP Server" --tool search_media action=list directory_path="D:\Videos" source_filter=local
```

## 观看历史

```bash
mcporter call --server "SHPlayer MCP Server" --tool query_user_history limit=10
```

## 页面导航

```bash
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=history      # 播放历史
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=favorites     # 我的收藏
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=downloads     # 下载管理
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=movie         # 电影频道
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=tv            # 电视剧频道
mcporter call --server "SHPlayer MCP Server" --tool navigate_to_page page=feed          # 关注流
```

## 动态壁纸

```bash
# 启动壁纸（恢复之前设置的）
mcporter call --server "SHPlayer MCP Server" --tool manage_wallpaper action=start

# 打开壁纸管理界面
mcporter call --server "SHPlayer MCP Server" --tool manage_wallpaper action=open_main

# 将本地视频设为壁纸
mcporter call --server "SHPlayer MCP Server" --tool manage_wallpaper action=set file_path="D:\Videos\bg.mp4"
```

## 系统设置

```bash
# 切换皮肤
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=change_skin skin_name=black
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=change_skin skin_name=white

# 自启开关
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=enable_auto_start
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=disable_auto_start

# 清理缓存
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=clear_cache

# 设为默认播放器
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=set_as_default

# 打开设置界面
mcporter call --server "SHPlayer MCP Server" --tool configure_system action=open_settings_panel
```

## 外部工具

```bash
mcporter call --server "SHPlayer MCP Server" --tool launch_external_tool tool=image_viewer     # 启动搜狐看图
mcporter call --server "SHPlayer MCP Server" --tool launch_external_tool tool=broadcaster_plus # 启动直播+
mcporter call --server "SHPlayer MCP Server" --tool launch_external_tool tool=file_location   # 打开视频所在文件夹
```

## MCP Server 信息

- **名称**: `SHPlayer MCP Server`
- **地址**: `https://localhost.tv.sohu.com:7981/mcp`

详细工具 schema 参见 [references/api_reference.md](references/api_reference.md)。
