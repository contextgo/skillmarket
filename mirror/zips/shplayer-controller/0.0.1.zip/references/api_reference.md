# shplayer-controller API Reference

完整工具 Schema 来自 `SHPlayer MCP Server` (`https://localhost.tv.sohu.com:7981/mcp`)。

## 前置要求

- 安装 **搜狐影音 7.3.1.0 及以上版本**（低于此版本不支持 MCP Server）
- 启动搜狐影音后，MCP Server 自动监听 `https://localhost.tv.sohu.com:7981/mcp`

---

## play_media

播放选定的视频资源。支持本地文件、搜狐在线视频及已绑定的网盘文件。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `source_type` | string | ✅ | 资源来源：`local` / `online` / `baidu_drive` / `aliyun_drive` / `115_drive` |
| `video_id` | string | 条件 | 在线/网盘视频的 ID（source_type 为 online/drive 时必填） |
| `file_path` | string | 条件 | 本地文件绝对路径（source_type=local 时使用） |

---

## control_playback

综合控制视频播放状态。

| 参数 | 枚举值 | 说明 |
|------|--------|------|
| `action` | `play`, `pause`, `previous`, `next`, `restart` | 基础播放控制 |
| `action` | `enable_danmaku`, `disable_danmaku` | 弹幕开关 |
| `action` | `enable_auto_skip`, `disable_auto_skip` | 自动跳过片头片尾 |
| `action` | `enable_incognito`, `disable_incognito` | 无痕模式 |

---

## adjust_playback

调整视频的播放进度或播放倍速。

| 参数 | 值 | 说明 |
|------|---|------|
| `action=seek` | 数字（秒） | 绝对跳转，如 `600`=10分钟处 |
| `action=seek` | `+30` / `-30` | 相对快进/快退 |
| `action=speed` | `0.5`, `0.8`, `1.0`, `1.25`, `1.5`, `2.0`, `2.5`, `3.0` | 倍速值 |

---

## search_media

在本地、在线库及已绑定的网盘（百度/阿里/115）中搜索视频。

| 参数 | 类型 | 说明 |
|------|------|------|
| `action` | string | `search`（搜索）或 `list`（列目录） |
| `keyword` | string | 搜索关键词（action=search 时） |
| `directory_path` | string | 目录路径（action=list 时） |
| `source_filter` | string | 范围：`local` / `online` / `baidu_drive` / `aliyun_drive` / `115_drive` |

> ⚠️ 注意：搜索结果中的 `video_id` 仅用于后续 `play_media` 调用，无需向用户展示。

---

## query_user_history

查询用户的观看历史记录。

| 参数 | 类型 | 说明 |
|------|------|------|
| `limit` | number | 返回数量上限，最大 20，默认为 10 |

> ⚠️ 注意：结果中的 `video_id` 仅用于 `play_media` 调用，无需向用户展示。

---

## manage_subtitle

管理视频字幕。

| 参数 | 值 | 说明 |
|------|---|------|
| `action=list` | — | 获取当前视频所有字幕列表 |
| `action=select` | subtitle_id | 切换字幕（用 list 返回的 subtitle_id），`-1`=隐藏字幕 |

---

## transform_video

调整视频画面方向。

| action | 说明 |
|--------|------|
| `reset` | 重置 |
| `cw9` | 顺时针90° |
| `ccw9` | 逆时针90° |
| `flip_h` | 水平翻转/镜像 |
| `flip_v` | 垂直翻转 |

---

## take_snapshot

截取当前视频帧（无参数）。

---

## manage_wallpaper

管理动态壁纸功能。

| action | 说明 |
|--------|------|
| `start` | 启动动态壁纸（恢复之前设置的） |
| `open_main` | 打开动态壁纸管理界面 |
| `set` | 将本地视频设为桌面动态壁纸（需配合 `file_path`） |

---

## navigate_to_page

跳转至软件的特定功能页面。

| page | 目标 |
|------|------|
| `history` | 播放历史界面 |
| `favorites` | 我的收藏 |
| `following` | 我的关注列表 |
| `downloads` | 下载管理 |
| `creations` | 我的作品/投稿管理 |
| `video_library` | 私人云播（网盘/局域网） |
| `movie` | 电影频道 |
| `tv` | 电视剧频道 |
| `feed` | 关注流 |

---

## configure_system

系统级维护与设置。

| action | 说明 |
|--------|------|
| `change_skin` | 切换皮肤（需配合 `skin_name`：`black` / `white` / `new_year`） |
| `enable_auto_start` | 开启开机自启 |
| `disable_auto_start` | 关闭开机自启 |
| `clear_cache` | 清理临时文件 |
| `set_as_default` | 设为系统默认播放器 |
| `open_settings_panel` | 打开设置界面 |

---

## launch_external_tool

启动与搜狐影音关联的外部软件。

| tool | 说明 |
|------|------|
| `image_viewer` | 启动"搜狐看图"软件 |
| `broadcaster_plus` | 启动"搜狐视频直播+"软件 |
| `file_location` | 在资源管理器中打开当前视频所在文件夹 |

---

## 调用方式

所有工具均通过 mcporter 调用：

```bash
mcporter call --server "SHPlayer MCP Server" --tool <tool_name> <参数>
```

参数使用 `key=value` 格式，多个参数用空格分隔。
