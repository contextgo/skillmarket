#!/usr/bin/env python3
"""
新建微信公众号草稿
将文章标题、HTML 正文、封面图 media_id 等信息提交到草稿箱。

用法:
    # 从命令行参数
    python add_draft.py --title "标题" --content "正文 HTML" --thumb_media_id "封面 media_id"
    
    # 从文件读取 HTML 内容
    python add_draft.py --title "标题" --content_file article.html --thumb_media_id "封面 media_id"
    
    # 从 JSON 文件读取所有参数
    python add_draft.py --json_file draft_data.json
    
    # 带可选参数
    python add_draft.py --title "标题" --content_file article.html --thumb_media_id "xxx" --author "作者" --digest "摘要"
"""

import sys
import json
import argparse
import os

# 导入工具模块
from utils import (
    get_access_token, 
    http_post_json, 
    check_wechat_error,
    require_response_field,
    log_info, 
    log_warning, 
    log_error
)


def add_draft(access_token, article_data):
    """调用微信 API 新增草稿"""
    url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={access_token}"
    
    log_info("创建草稿...")
    response = http_post_json(url, {"articles": [article_data]})
    
    if not check_wechat_error(response, "创建草稿"):
        sys.exit(1)

    return require_response_field(response, "media_id", "创建草稿")


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="新建微信公众号草稿",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python add_draft.py --title "标题" --content "HTML" --thumb_media_id "xxx"
  python add_draft.py --title "标题" --content_file article.html --thumb_media_id "xxx"
  python add_draft.py --json_file draft_data.json
        """
    )
    
    # 互斥组：--content 和 --content_file
    content_group = parser.add_mutually_exclusive_group()
    content_group.add_argument(
        "--content", 
        type=str, 
        help="正文 HTML 内容（字符串）"
    )
    content_group.add_argument(
        "--content_file", 
        type=str, 
        help="正文 HTML 文件路径（从文件读取）"
    )
    
    parser.add_argument(
        "--title", 
        type=str, 
        help="文章标题（不超过 32 字）"
    )
    parser.add_argument(
        "--thumb_media_id", 
        type=str, 
        help="封面图 media_id"
    )
    parser.add_argument(
        "--author", 
        type=str, 
        default="", 
        help="作者（不超过 16 字，可选）"
    )
    parser.add_argument(
        "--digest", 
        type=str, 
        default="", 
        help="摘要（不超过 128 字，可选）"
    )
    parser.add_argument(
        "--content_source_url", 
        type=str, 
        default="", 
        help="原文链接（可选）"
    )
    parser.add_argument(
        "--json_file", 
        type=str, 
        help="从 JSON 文件读取所有参数（可选）"
    )
    parser.add_argument(
        "--need_open_comment", 
        type=int, 
        default=0, 
        help="是否打开评论：0=关闭，1=打开（默认 0）"
    )
    parser.add_argument(
        "--only_fans_can_comment", 
        type=int, 
        default=0, 
        help="是否仅粉丝可评论：0=所有人，1=仅粉丝（默认 0）"
    )
    
    return parser.parse_args()


def load_from_json_file(json_path):
    """从 JSON 文件加载参数"""
    if not os.path.exists(json_path):
        log_error(f"JSON 文件不存在：{json_path}")
        sys.exit(1)
    
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        log_error(f"JSON 格式错误：{e}")
        sys.exit(1)


def read_text_file(file_path, label):
    """读取 UTF-8 文本文件。"""
    if not os.path.exists(file_path):
        log_error(f"{label}不存在：{file_path}")
        sys.exit(1)

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        log_error(f"读取{label}失败：{e}")
        sys.exit(1)


def build_input_data(args):
    """根据参数模式构建统一的输入数据。"""
    if args.json_file:
        data = load_from_json_file(args.json_file)
        if data.get("content_file") and not data.get("content"):
            data["content"] = read_text_file(data["content_file"], "内容文件")
        return data

    if not args.content and not args.content_file:
        log_error("命令行模式需要提供 --content 或 --content_file")
        sys.exit(1)

    content = args.content
    if args.content_file:
        content = read_text_file(args.content_file, "内容文件")
        log_info(f"从文件读取内容：{args.content_file}")

    return {
        "title": args.title,
        "content": content,
        "thumb_media_id": args.thumb_media_id,
        "author": args.author,
        "digest": args.digest,
        "content_source_url": args.content_source_url,
        "need_open_comment": args.need_open_comment,
        "only_fans_can_comment": args.only_fans_can_comment,
    }


def main():
    args = parse_args()

    data = build_input_data(args)
    title = data.get("title", "")
    content = data.get("content", "")
    thumb_media_id = data.get("thumb_media_id", "")
    author = data.get("author", "")
    digest = data.get("digest", "")
    content_source_url = data.get("content_source_url", "")
    need_open_comment = data.get("need_open_comment", 0)
    only_fans_can_comment = data.get("only_fans_can_comment", 0)
    
    # 验证必填字段
    if not title:
        log_error("缺少必填参数：title")
        sys.exit(1)
    if not content:
        log_error("缺少必填参数：content")
        sys.exit(1)
    if not thumb_media_id:
        log_error("缺少必填参数：thumb_media_id")
        sys.exit(1)
    
    # 验证字段长度
    if len(title) > 32:
        log_warning(f"标题超过 32 字限制（当前{len(title)}字），将被截断")
        title = title[:32]
    
    if author and len(author) > 16:
        log_warning(f"作者超过 16 字限制（当前{len(author)}字），将被截断")
        author = author[:16]
    
    if digest and len(digest) > 128:
        log_warning(f"摘要超过 128 字限制（当前{len(digest)}字），将被截断")
        digest = digest[:128]
    
    # 构建文章数据
    article_data = {
        "title": title,
        "content": content,
        "thumb_media_id": thumb_media_id,
    }
    
    # 可选字段
    if author:
        article_data["author"] = author
    if digest:
        article_data["digest"] = digest
    if content_source_url:
        article_data["content_source_url"] = content_source_url
    
    # 评论设置
    article_data["need_open_comment"] = int(need_open_comment)
    article_data["only_fans_can_comment"] = int(only_fans_can_comment)
    
    # 获取 Token 并创建草稿
    access_token = get_access_token()
    media_id = add_draft(access_token, article_data)
    
    # 输出结果
    result = {
        "media_id": media_id,
        "title": title,
        "message": "草稿创建成功，可在公众号后台草稿箱中查看"
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
