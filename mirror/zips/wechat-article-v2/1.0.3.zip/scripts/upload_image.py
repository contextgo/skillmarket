#!/usr/bin/env python3
"""
上传图片到微信服务器
支持两种模式：
  1. 上传正文图片（--content）：返回图片 URL
  2. 上传封面图（--thumb）：返回永久 media_id
  3. 批量上传（--files）：一次上传多张图片

用法:
    # 单张上传
    python upload_image.py --content <图片路径>
    python upload_image.py --thumb <图片路径>
    
    # 批量上传（正文图片）
    python upload_image.py --files image1.jpg image2.jpg image3.jpg --content
    
    # 输出 JSON 格式
    python upload_image.py --content <图片路径> --json
"""

import sys
import json
import os

# 导入工具模块
from utils import (
    get_access_token, 
    http_post_multipart, 
    check_wechat_error,
    require_response_field,
    log_info, 
    log_error
)


def upload_content_image(access_token, image_path):
    """上传发表内容中的图片（正文图片），返回图片 URL"""
    url = f"https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={access_token}"
    
    log_info(f"上传正文图片：{os.path.basename(image_path)}")
    response = http_post_multipart(url, image_path)
    
    if not check_wechat_error(response, "上传正文图片"):
        sys.exit(1)

    return require_response_field(response, "url", "上传正文图片")


def upload_thumb_image(access_token, image_path):
    """上传永久素材图片（封面图），返回 media_id"""
    url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={access_token}&type=image"
    
    log_info(f"上传封面图：{os.path.basename(image_path)}")
    response = http_post_multipart(url, image_path)
    
    if not check_wechat_error(response, "上传封面图"):
        sys.exit(1)

    media_id = require_response_field(response, "media_id", "上传封面图")
    return media_id, response.get("url", "")


def main():
    args = sys.argv[1:]
    output_json = "--json" in args
    args = [a for a in args if a != "--json"]
    
    # 检查模式
    if len(args) < 1:
        log_error("用法：python upload_image.py --content <图片路径>")
        log_error("      python upload_image.py --thumb <图片路径>")
        log_error("      python upload_image.py --files image1.jpg image2.jpg --content")
        sys.exit(1)
    
    # 获取 Token
    access_token = get_access_token()
    
    # 批量上传模式
    if "--files" in args:
        try:
            idx = args.index("--files")
        except ValueError:
            log_error("--files 需要指定图片路径")
            sys.exit(1)
        
        # 收集所有图片路径（直到遇到下一个--参数）
        image_paths = []
        i = idx + 1
        while i < len(args) and not args[i].startswith("--"):
            image_paths.append(args[i])
            i += 1
        
        # 确定模式
        mode = "--content"
        if "--thumb" in args[idx:]:
            mode = "--thumb"
        
        if not image_paths:
            log_error("--files 需要至少指定一个图片路径")
            sys.exit(1)
        
        log_info(f"批量上传 {len(image_paths)} 张图片（模式：{mode}）")
        
        results = []
        for image_path in image_paths:
            if not os.path.exists(image_path):
                log_error(f"文件不存在：{image_path}")
                continue
            
            try:
                if mode == "--content":
                    url = upload_content_image(access_token, image_path)
                    results.append({
                        "file": image_path,
                        "url": url
                    })
                    log_info(f"✓ {os.path.basename(image_path)}: {url}")
                elif mode == "--thumb":
                    # 批量模式下只处理第一张为封面图
                    media_id, url = upload_thumb_image(access_token, image_path)
                    results.append({
                        "file": image_path,
                        "media_id": media_id,
                        "url": url
                    })
                    log_info(f"✓ {os.path.basename(image_path)}: media_id={media_id}")
                    # 封面图只上传一张
                    break
            except SystemExit:
                log_error(f"上传失败：{image_path}")
                continue
        
        # 输出结果
        if output_json:
            print(json.dumps({"results": results}, ensure_ascii=False, indent=2))
        else:
            print(f"\n[SUCCESS] 批量上传完成，成功 {len(results)}/{len(image_paths)} 张")
        
        return
    
    # 单张上传模式
    mode = args[0]
    image_path = args[1] if len(args) > 1 else None
    
    if not image_path:
        log_error(f"缺少图片路径")
        log_error("用法：python upload_image.py --content <图片路径>")
        log_error("      python upload_image.py --thumb <图片路径>")
        sys.exit(1)
    
    if mode == "--content":
        url = upload_content_image(access_token, image_path)
        if output_json:
            print(json.dumps({"url": url}, ensure_ascii=False, indent=2))
        else:
            print(url)
    
    elif mode == "--thumb":
        media_id, url = upload_thumb_image(access_token, image_path)
        if output_json:
            print(json.dumps({"media_id": media_id, "url": url}, ensure_ascii=False, indent=2))
        else:
            print(media_id)
    
    else:
        log_error(f"未知模式：{mode}，请使用 --content 或 --thumb")
        sys.exit(1)


if __name__ == "__main__":
    main()
