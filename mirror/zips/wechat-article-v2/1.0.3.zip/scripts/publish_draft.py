#!/usr/bin/env python3
"""
发布微信公众号草稿
将已创建的草稿提交发布。发布是异步操作，可轮询查询发布状态。

用法:
    python publish_draft.py --media_id "草稿 media_id"
    python publish_draft.py --media_id "草稿 media_id" --poll    # 发布并轮询状态
    python publish_draft.py --check --publish_id "发布 ID"       # 查询发布状态
"""

import sys
import json
import time
import argparse

# 导入工具模块
from utils import (
    get_access_token, 
    http_post_json, 
    check_wechat_error,
    require_response_field,
    log_info, 
    log_warning, 
    log_error
)


def submit_publish(access_token, media_id):
    """提交发布"""
    url = f"https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token={access_token}"
    
    log_info("提交发布请求...")
    response = http_post_json(url, {"media_id": media_id})
    
    if not check_wechat_error(response, "提交发布"):
        sys.exit(1)

    return require_response_field(response, "publish_id", "提交发布")


def check_publish_status(access_token, publish_id):
    """查询发布状态"""
    url = f"https://api.weixin.qq.com/cgi-bin/freepublish/get?access_token={access_token}"
    
    response = http_post_json(url, {"publish_id": publish_id})
    return response


def poll_publish_status(access_token, publish_id, max_attempts=10, interval=5):
    """轮询发布状态直到完成"""
    log_info(f"开始轮询发布状态（最多{max_attempts}次，间隔{interval}秒）...")
    
    for i in range(max_attempts):
        log_info(f"第 {i+1}/{max_attempts} 次查询...")
        status = check_publish_status(access_token, publish_id)
        
        if not status:
            log_warning(f"查询失败，继续...")
            time.sleep(interval)
            continue
        
        publish_status = status.get("publish_status", "")
        
        if publish_status == 0:
            # 发布成功
            log_info("✓ 发布成功！")
            return status
        elif publish_status == 1:
            # 发布中
            log_info(f"发布中...")
            time.sleep(interval)
        elif publish_status == 2:
            # 发布失败
            fail_idx = status.get("fail_idx", [])
            log_error(f"发布失败，失败文章索引：{fail_idx}")
            sys.exit(1)
        else:
            log_warning(f"未知状态：{publish_status}")
            time.sleep(interval)
    
    log_error("轮询超时，请手动检查发布状态")
    return None


def main():
    parser = argparse.ArgumentParser(description="发布微信公众号草稿")
    parser.add_argument("--media_id", type=str, help="草稿 media_id")
    parser.add_argument("--poll", action="store_true", help="发布并轮询状态")
    parser.add_argument("--check", action="store_true", help="查询发布状态")
    parser.add_argument("--publish_id", type=str, help="发布 ID（与--check 一起使用）")
    
    args = parser.parse_args()
    
    # 查询发布状态模式
    if args.check:
        if not args.publish_id:
            log_error("查询状态需要 --publish_id 参数")
            sys.exit(1)
        
        access_token = get_access_token()
        status = check_publish_status(access_token, args.publish_id)
        if status:
            print(json.dumps(status, ensure_ascii=False, indent=2))
        return
    
    # 发布模式
    if not args.media_id:
        log_error("缺少必填参数：--media_id")
        log_error("用法：python publish_draft.py --media_id <草稿 media_id>")
        sys.exit(1)
    
    access_token = get_access_token()
    publish_id = submit_publish(access_token, args.media_id)
    
    result = {
        "publish_id": publish_id,
        "media_id": args.media_id,
        "message": "发布请求已提交" + ("，正在轮询状态..." if args.poll else "")
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
    if args.poll:
        result = poll_publish_status(access_token, publish_id)
        if result:
            print("\n发布结果：")
            print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
