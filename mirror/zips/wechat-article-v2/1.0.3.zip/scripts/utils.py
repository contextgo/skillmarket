#!/usr/bin/env python3
"""
微信公众号工具模块
提供通用的工具函数，避免代码重复
"""

import json
import os
import sys
import time
import urllib.error
import urllib.request

# 脚本目录（用于定位同级文件）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Token 缓存文件（放在脚本同级目录）
TOKEN_CACHE_FILE = os.path.join(SCRIPT_DIR, ".token_cache.json")
TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token"
TOKEN_REFRESH_BUFFER_SECONDS = 300
DEFAULT_TOKEN_EXPIRES_IN = 7200


def log_info(message):
    """INFO 日志：完全禁用"""
    pass


def log_warning(message):
    """输出 WARNING 级别日志"""
    print(f"[WARNING] {message}", file=sys.stderr)


def log_error(message):
    """输出 ERROR 级别日志"""
    print(f"[ERROR] {message}", file=sys.stderr)


def get_required_env(name):
    """读取必需环境变量，缺失时直接退出。"""
    value = os.environ.get(name, "").strip()
    if value:
        return value
    log_error(f"环境变量 {name} 未设置")
    sys.exit(1)


def load_cached_token(cache_file=TOKEN_CACHE_FILE):
    """从缓存文件加载 token，若仍有效则返回缓存字典。"""
    if not os.path.exists(cache_file):
        return None

    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            cache = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log_warning(f"读取缓存失败：{e}，重新获取")
        return None

    expires_at = cache.get("expires_at", 0)
    access_token = cache.get("access_token")
    if access_token and expires_at > time.time() + TOKEN_REFRESH_BUFFER_SECONDS:
        return cache
    return None


def save_token_cache(access_token, expires_in=DEFAULT_TOKEN_EXPIRES_IN, cache_file=TOKEN_CACHE_FILE):
    """保存 token 到缓存文件。"""
    now = time.time()
    cache = {
        "access_token": access_token,
        "expires_in": expires_in,
        "expires_at": now + expires_in,
        "created_at": now,
    }
    try:
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except OSError as e:
        log_warning(f"无法写入缓存文件：{e}")

    return cache


def fetch_access_token():
    """直接从微信服务器获取 access_token。"""
    appid = get_required_env("APPID")
    secret = get_required_env("APPSECRET")
    url = f"{TOKEN_URL}?appid={appid}&secret={secret}&grant_type=client_credential"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        log_error(f"网络请求失败：{e}")
        sys.exit(1)
    except json.JSONDecodeError:
        log_error("响应不是有效的 JSON")
        sys.exit(1)

    access_token = data.get("access_token")
    if not access_token:
        errcode = data.get("errcode", "unknown")
        errmsg = data.get("errmsg", "unknown")
        log_error(f"获取 token 失败 [{errcode}]: {errmsg}")
        sys.exit(1)

    expires_in = data.get("expires_in", DEFAULT_TOKEN_EXPIRES_IN)
    return access_token, expires_in


def get_access_token():
    """
    获取微信公众号 Access Token（带缓存）。

    缓存策略：
    - 缓存到脚本同级目录的 .token_cache.json
    - 有效期 7200 秒，提前 300 秒刷新
    - 避免频繁调用微信 API

    Returns:
        str: access_token
    """
    cached = load_cached_token()
    if cached:
        return cached["access_token"]

    access_token, expires_in = fetch_access_token()
    save_token_cache(access_token, expires_in)
    return access_token


def http_post_json(url, data, timeout=30):
    """
    发送 HTTP POST 请求（JSON 格式）
    
    Args:
        url: 请求 URL
        data: Python dict，将被转换为 JSON
        timeout: 超时时间（秒）
    
    Returns:
        dict: 响应 JSON 数据
    
    Raises:
        SystemExit: 请求失败时退出
    """
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json; charset=utf-8")
    
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        log_error(f"HTTP 请求失败：{e}")
        sys.exit(1)
    except json.JSONDecodeError:
        log_error("响应不是有效的 JSON")
        sys.exit(1)


def http_post_multipart(url, file_path, file_field="media", timeout=30):
    """
    发送 HTTP POST 请求（multipart/form-data，用于文件上传）
    
    Args:
        url: 请求 URL
        file_path: 文件路径
        file_field: 表单字段名（默认"media"）
        timeout: 超时时间（秒）
    
    Returns:
        dict: 响应 JSON 数据
    
    Raises:
        SystemExit: 请求失败时退出
    """
    if not os.path.exists(file_path):
        log_error(f"文件不存在：{file_path}")
        sys.exit(1)
    
    filename = os.path.basename(file_path)
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
    
    with open(file_path, "rb") as f:
        file_data = f.read()
    
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\n'
        f"Content-Type: application/octet-stream\r\n\r\n"
    ).encode("utf-8") + file_data + f"\r\n--{boundary}--\r\n".encode("utf-8")
    
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        log_error(f"上传失败：{e}")
        sys.exit(1)


def check_wechat_error(response, operation="操作"):
    """
    检查微信 API 响应是否包含错误
    
    Args:
        response: 微信 API 返回的 JSON dict
        operation: 操作描述（用于错误信息）
    
    Returns:
        bool: 是否成功（True=成功，False=失败）
    """
    if "errcode" in response and response.get("errcode", 0) != 0:
        errcode = response.get("errcode", "unknown")
        errmsg = response.get("errmsg", "unknown")
        log_error(f"{operation}失败 [{errcode}]: {errmsg}")
        return False
    return True


def require_response_field(response, field_name, operation="操作"):
    """确保微信响应中包含指定字段，缺失时直接退出。"""
    if field_name not in response:
        log_error(f"{operation}失败：未返回 {field_name}")
        sys.exit(1)
    return response[field_name]
