---
name: spraay
description: >
  Payment infrastructure for AI agents. Batch crypto payments, x402 micropayment gateway,
  agent-to-agent USDC settlement, multi-chain payroll, Bitcoin PSBT transactions, and robot
  task commissioning via RTP. Supports 13+ blockchains including Base, Ethereum, Solana,
  Bitcoin, Stacks, Arbitrum, Polygon, BNB Chain, and more. Use this skill whenever the user
  wants to send crypto to multiple recipients, pay a team or DAO contributors, process
  payroll on-chain, call paid API endpoints via x402, commission a robot task, build
  agent payment workflows, or interact with the Spraay protocol in any way. Also use when
  the user mentions batch payments, mass transfers, airdrop distribution, multi-send,
  token distribution, crypto payroll, x402 gateway, agent payments, or robot task protocol.
version: 1.0.0
metadata:
  openclaw:
    requires:
      env:
        - SPRAAY_GATEWAY_URL
      bins:
        - curl
      optionalEnv:
        - SPRAAY_API_KEY
    primaryEnv: SPRAAY_GATEWAY_URL
    emoji: "💧"
    homepage: https://spraay.app
    tags:
      - payments
      - crypto
      - defi
      - batch
      - x402
      - agents
      - payroll
      - bitcoin
      - multi-chain
      - robot-tasks
---

# 💧 Spraay — Payment Infrastructure for AI Agents

Spraay is the payment layer for autonomous AI agents. It enables batch crypto payments across 13+ chains, x402 micropayment gateway access (76+ paid endpoints), agent-to-agent USDC settlement, on-chain payroll, Bitcoin PSBT batch transactions, and robot task commissioning via the Robot Task Protocol (RTP).

## Quick Setup

```bash
# Set the gateway URL (default public gateway)
export SPRAAY_GATEWAY_URL="https://gateway.spraay.app"

# Optional: set API key for authenticated access
export SPRAAY_API_KEY="your-key-here"
```

No wallet setup required for gateway calls — the x402 protocol handles payment negotiation automatically via USDC on Base.

## Core Capabilities

### 1. Batch Payments (Smart Contract)

Send ETH or ERC-20 tokens to up to 200 recipients in a single transaction. Available on Base, Ethereum, Arbitrum, Polygon, BNB Chain, Avalanche, Unichain, Plasma, BOB, Solana, Bittensor, and Stacks.

**Base contract:** `0x1646452F98E36A3c9Cfc3eDD8868221E207B5eEC`

**When to use:** User wants to pay multiple people at once, distribute tokens, run payroll, airdrop, or split payments.

```bash
# Example: batch payment via gateway
curl -X POST "$SPRAAY_GATEWAY_URL/api/payments/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "chain": "base",
    "token": "USDC",
    "recipients": [
      {"address": "0xAAA...", "amount": "100"},
      {"address": "0xBBB...", "amount": "50"},
      {"address": "0xCCC...", "amount": "75"}
    ]
  }'
```

Refer to `references/batch-payments.md` for full contract ABI, CSV import format, supported chains, and error handling.

### 2. x402 Gateway (76+ Paid Endpoints)

The Spraay x402 gateway at `gateway.spraay.app` exposes 76+ endpoints across 16 categories. Agents pay per-request in USDC via the x402 protocol — no API keys, no subscriptions, just micropayments.

**Categories and pricing:**

| Category | Endpoints | Price Range |
|----------|-----------|-------------|
| AI Inference (OpenRouter + BlockRun) | 93 models | $0.01–0.05 |
| RPC (7 chains via Alchemy) | 7 | $0.001–0.005 |
| Search & RAG (Tavily) | 3 | $0.005–0.01 |
| Communication (Email, SMS, XMTP) | 6 | $0.005–0.01 |
| IPFS Storage (Pinata) | 3 | $0.005–0.01 |
| GPU/Compute (Replicate) | 4 | $0.01–0.05 |
| Oracle/Price Feeds | 4 | $0.001–0.005 |
| Identity/KYC | 3 | $0.01 |
| Escrow | 3 | $0.05–0.25 |
| Bridge (Cross-chain) | 3 | $0.05–0.25 |
| Payroll | 3 | $0.05–0.25 |
| Compliance | 3 | $0.005 |
| Wallet Provisioning | 2 | $0.01 |
| Data/Analytics | 3 | $0.001–0.005 |
| Robot Tasks (RTP) | 8 | $0.01–0.05 |
| Bitcoin (PSBT) | 6 | $0.001–0.02 |

**When to use:** Agent needs to call any paid API — AI inference, blockchain RPC, search, email, IPFS, or any infrastructure endpoint — and wants to pay per-call instead of managing API keys.

```bash
# Example: AI inference via x402
curl -X POST "$SPRAAY_GATEWAY_URL/api/ai/chat" \
  -H "Content-Type: application/json" \
  -H "X-402-Payment: <usdc-payment-header>" \
  -d '{"model": "claude-sonnet-4-20250514", "prompt": "Summarize this document"}'
```

Refer to `references/x402-gateway.md` for the full endpoint catalog, payment header format, and Bazaar discovery integration.

### 3. Bitcoin Batch Payments (PSBT)

Non-custodial Bitcoin batch payments using Partially Signed Bitcoin Transactions (PSBTs). Built on bitcoinjs-lib with Mempool.space API for fee estimation and broadcast.

**Endpoints:** batch-prepare ($0.02), batch-broadcast ($0.01), fee-estimate, utxos, balance, validate ($0.001 each)

**When to use:** User wants to send BTC to multiple recipients in a single transaction, or needs Bitcoin fee estimation and UTXO management.

```bash
# Prepare a Bitcoin batch transaction
curl -X POST "$SPRAAY_GATEWAY_URL/api/bitcoin/batch-prepare" \
  -H "Content-Type: application/json" \
  -d '{
    "recipients": [
      {"address": "bc1q...", "amount": 50000},
      {"address": "bc1q...", "amount": 25000}
    ],
    "feeRate": 10,
    "changeAddress": "bc1q..."
  }'
```

Refer to `references/bitcoin-psbt.md` for PSBT workflow, UTXO selection, and fee strategies.

### 4. Robot Task Protocol (RTP)

Open standard for AI agents to discover, commission, and pay physical robots for real-world tasks via x402 USDC micropayments. Built for the DePIN + AI agent intersection.

**Endpoints:** discover ($0.01), commission ($0.05), status ($0.005), cancel ($0.01), complete ($0.01), capabilities ($0.005), register ($0.02), heartbeat ($0.005)

**When to use:** Agent needs to hire a physical robot for a task — delivery, inspection, manipulation, sensing — and pay for it programmatically.

```bash
# Discover available robots
curl "$SPRAAY_GATEWAY_URL/api/rtp/discover?capability=delivery&location=37.7749,-122.4194"

# Commission a task
curl -X POST "$SPRAAY_GATEWAY_URL/api/rtp/commission" \
  -H "Content-Type: application/json" \
  -d '{
    "robotId": "robot-001",
    "task": "deliver_package",
    "params": {"destination": "123 Main St", "weight_kg": 2.5},
    "maxBudgetUSDC": "5.00"
  }'
```

Refer to `references/rtp-protocol.md` for the full RTP specification, device registration, and capability schemas.

### 5. Agent-to-Agent Payments

Spraay enables structured payments between autonomous agents — escrow, milestone-based releases, and batch settlement. Combined with x402, agents can transact without human intervention.

**When to use:** Multi-agent workflows where agents need to pay each other for completed tasks, hold funds in escrow, or settle batch payments between collaborators.

```bash
# Escrow: create a payment held until task completion
curl -X POST "$SPRAAY_GATEWAY_URL/api/escrow/create" \
  -H "Content-Type: application/json" \
  -d '{
    "payer": "0xAgent1...",
    "payee": "0xAgent2...",
    "amount": "10",
    "token": "USDC",
    "releaseCondition": "task_complete"
  }'
```

## MCP Server

Spraay also has a published MCP server with 66 tools for deeper integration:
- **Smithery:** `@plagtech/spraay-x402-mcp`
- **Official MCP Registry:** `io.github.plagtech/spraay-x402-mcp`

Use the MCP server when you need programmatic access to all Spraay capabilities from an MCP-compatible agent (Claude, Cursor, etc.).

## Supported Chains

| # | Chain | Type | Status |
|---|-------|------|--------|
| 1 | Base | EVM | ✅ Live |
| 2 | Ethereum | EVM | ✅ Live |
| 3 | Arbitrum | EVM | ✅ Live |
| 4 | Polygon | EVM | ✅ Live |
| 5 | BNB Chain | EVM | ✅ Live |
| 6 | Avalanche | EVM | ✅ Live |
| 7 | Unichain | EVM | ✅ Live |
| 8 | Plasma | EVM | ✅ Live |
| 9 | BOB | EVM | ✅ Live |
| 10 | Solana | SVM | ✅ Live |
| 11 | Bittensor | Substrate | ✅ Live |
| 12 | Stacks | Clarity | ✅ Live |
| 13 | Bitcoin | UTXO | ✅ Live |

## Revenue Model

- **Batch payments:** 0.3% protocol fee per transaction
- **Gateway endpoints:** per-request x402 micropayments (prices above)
- All fees settle to `0xAd62f03C7514bb8c51f1eA70C2b75C37404695c8`

## Links

- **Gateway:** https://gateway.spraay.app
- **Docs:** https://docs.spraay.app
- **GitHub:** https://github.com/plagtech
- **MCP:** `@plagtech/spraay-x402-mcp`
- **Twitter:** [@Spraay_app](https://x.com/Spraay_app)
- **Farcaster:** [@plag](https://warpcast.com/plag)
