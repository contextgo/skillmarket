#!/bin/bash
# spraay.sh — Main Spraay gateway interaction script for OpenClaw agents
# Usage: spraay.sh <command> [args...]

GATEWAY_URL="${SPRAAY_GATEWAY_URL:-https://gateway.spraay.app}"

case "$1" in
  # Batch payment
  batch)
    CHAIN="${2:-base}"
    TOKEN="${3:-USDC}"
    RECIPIENTS_JSON="$4"
    curl -s -X POST "$GATEWAY_URL/api/payments/batch" \
      -H "Content-Type: application/json" \
      -d "{\"chain\":\"$CHAIN\",\"token\":\"$TOKEN\",\"recipients\":$RECIPIENTS_JSON}"
    ;;

  # AI inference
  ai)
    MODEL="${2:-claude-sonnet-4-20250514}"
    PROMPT="$3"
    curl -s -X POST "$GATEWAY_URL/api/ai/chat" \
      -H "Content-Type: application/json" \
      -d "{\"model\":\"$MODEL\",\"prompt\":\"$PROMPT\"}"
    ;;

  # RPC call
  rpc)
    CHAIN="${2:-base}"
    METHOD="$3"
    PARAMS="${4:-[]}"
    curl -s -X POST "$GATEWAY_URL/api/rpc/$CHAIN" \
      -H "Content-Type: application/json" \
      -d "{\"method\":\"$METHOD\",\"params\":$PARAMS}"
    ;;

  # Search
  search)
    QUERY="$2"
    curl -s -X POST "$GATEWAY_URL/api/search/web" \
      -H "Content-Type: application/json" \
      -d "{\"query\":\"$QUERY\"}"
    ;;

  # Send email
  email)
    TO="$2"
    SUBJECT="$3"
    BODY="$4"
    curl -s -X POST "$GATEWAY_URL/api/email/send" \
      -H "Content-Type: application/json" \
      -d "{\"to\":\"$TO\",\"subject\":\"$SUBJECT\",\"body\":\"$BODY\"}"
    ;;

  # IPFS pin
  ipfs-pin)
    FILE_PATH="$2"
    curl -s -X POST "$GATEWAY_URL/api/ipfs/pin" \
      -H "Content-Type: application/json" \
      -d "{\"file\":\"$(base64 -w0 "$FILE_PATH")\"}"
    ;;

  # Price oracle
  price)
    PAIR="${2:-ETH-USD}"
    curl -s "$GATEWAY_URL/api/oracle/price/$PAIR"
    ;;

  # Gas oracle
  gas)
    CHAIN="${2:-base}"
    curl -s "$GATEWAY_URL/api/oracle/gas/$CHAIN"
    ;;

  # RTP: discover robots
  rtp-discover)
    CAPABILITY="${2:-delivery}"
    LOCATION="${3:-37.7749,-122.4194}"
    curl -s "$GATEWAY_URL/api/rtp/discover?capability=$CAPABILITY&location=$LOCATION"
    ;;

  # RTP: commission task
  rtp-commission)
    ROBOT_ID="$2"
    TASK="$3"
    PARAMS_JSON="$4"
    MAX_BUDGET="${5:-5.00}"
    curl -s -X POST "$GATEWAY_URL/api/rtp/commission" \
      -H "Content-Type: application/json" \
      -d "{\"robotId\":\"$ROBOT_ID\",\"task\":\"$TASK\",\"params\":$PARAMS_JSON,\"maxBudgetUSDC\":\"$MAX_BUDGET\"}"
    ;;

  # RTP: task status
  rtp-status)
    TASK_ID="$2"
    curl -s "$GATEWAY_URL/api/rtp/status/$TASK_ID"
    ;;

  # Bitcoin: prepare batch
  btc-prepare)
    RECIPIENTS_JSON="$2"
    FEE_RATE="${3:-10}"
    CHANGE_ADDR="$4"
    curl -s -X POST "$GATEWAY_URL/api/bitcoin/batch-prepare" \
      -H "Content-Type: application/json" \
      -d "{\"recipients\":$RECIPIENTS_JSON,\"feeRate\":$FEE_RATE,\"changeAddress\":\"$CHANGE_ADDR\"}"
    ;;

  # Bitcoin: broadcast
  btc-broadcast)
    SIGNED_PSBT="$2"
    curl -s -X POST "$GATEWAY_URL/api/bitcoin/batch-broadcast" \
      -H "Content-Type: application/json" \
      -d "{\"signedPsbt\":\"$SIGNED_PSBT\"}"
    ;;

  # Bitcoin: fee estimate
  btc-fees)
    curl -s "$GATEWAY_URL/api/bitcoin/fee-estimate"
    ;;

  # Escrow: create
  escrow)
    PAYER="$2"
    PAYEE="$3"
    AMOUNT="$4"
    curl -s -X POST "$GATEWAY_URL/api/escrow/create" \
      -H "Content-Type: application/json" \
      -d "{\"payer\":\"$PAYER\",\"payee\":\"$PAYEE\",\"amount\":\"$AMOUNT\",\"token\":\"USDC\"}"
    ;;

  # Catalog: list all endpoints
  catalog)
    curl -s "$GATEWAY_URL/api/bazaar/catalog"
    ;;

  # Help
  *)
    echo "💧 Spraay — Payment Infrastructure for AI Agents"
    echo ""
    echo "Usage: spraay.sh <command> [args...]"
    echo ""
    echo "Payment Commands:"
    echo "  batch <chain> <token> <recipients_json>  — Batch crypto payment"
    echo "  escrow <payer> <payee> <amount>           — Create escrow"
    echo ""
    echo "Bitcoin Commands:"
    echo "  btc-prepare <recipients_json> <feeRate> <changeAddr>  — Prepare PSBT"
    echo "  btc-broadcast <signed_psbt>                           — Broadcast signed tx"
    echo "  btc-fees                                              — Current fee estimates"
    echo ""
    echo "Gateway Commands:"
    echo "  ai <model> <prompt>        — AI inference"
    echo "  search <query>             — Web search"
    echo "  email <to> <subj> <body>   — Send email"
    echo "  rpc <chain> <method>       — RPC call"
    echo "  price <pair>               — Price oracle"
    echo "  gas <chain>                — Gas oracle"
    echo "  ipfs-pin <file>            — Pin to IPFS"
    echo "  catalog                    — List all endpoints"
    echo ""
    echo "Robot Task Protocol:"
    echo "  rtp-discover <capability> <lat,lng>          — Find robots"
    echo "  rtp-commission <robotId> <task> <params_json> — Hire a robot"
    echo "  rtp-status <taskId>                          — Check task status"
    echo ""
    echo "Environment:"
    echo "  SPRAAY_GATEWAY_URL  — Gateway URL (default: https://gateway.spraay.app)"
    echo ""
    echo "Docs: https://docs.spraay.app"
    echo "GitHub: https://github.com/plagtech"
    ;;
esac
