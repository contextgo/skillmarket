# Batch Payments Reference

## Smart Contract Architecture

Spraay uses a single `batchTransfer` function that accepts arrays of recipients and amounts. The contract is deployed identically across all EVM chains.

**Base Mainnet Contract:** `0x1646452F98E36A3c9Cfc3eDD8868221E207B5eEC`

### Function Signatures

```solidity
// Batch ETH transfer
function batchTransferETH(
    address[] calldata recipients,
    uint256[] calldata amounts
) external payable;

// Batch ERC-20 transfer
function batchTransferERC20(
    address token,
    address[] calldata recipients,
    uint256[] calldata amounts
) external;
```

### Protocol Fee

A 0.3% fee is collected on every batch transaction and sent to the protocol fee recipient. The fee is calculated as:

```
fee = totalAmount * 30 / 10000
```

### Limits

- Maximum 200 recipients per transaction
- Minimum 2 recipients (use a standard transfer for single sends)
- Arrays must be equal length (recipients.length == amounts.length)

## CSV Import Format

For large distributions, prepare a CSV file:

```csv
address,amount
0xAAA...,100
0xBBB...,50.5
0xCCC...,75
```

Rules:
- Header row required: `address,amount`
- Amounts in human-readable units (not wei)
- No empty rows
- Addresses must be checksummed or lowercase

## Gateway Batch Endpoint

```
POST /api/payments/batch
```

**Request Body:**
```json
{
  "chain": "base",
  "token": "USDC",
  "recipients": [
    {"address": "0x...", "amount": "100"},
    {"address": "0x...", "amount": "50"}
  ],
  "csv": "optional base64-encoded CSV as alternative to recipients array"
}
```

**Response:**
```json
{
  "txHash": "0x...",
  "totalAmount": "150",
  "fee": "0.45",
  "recipientCount": 2,
  "chain": "base",
  "status": "confirmed"
}
```

## Supported Chains & Contracts

| Chain | Contract Address | Explorer |
|-------|-----------------|----------|
| Base | `0x1646452F98E36A3c9Cfc3eDD8868221E207B5eEC` | basescan.org |
| Ethereum | Same deployer pattern | etherscan.io |
| Arbitrum | Same deployer pattern | arbiscan.io |
| Polygon | Same deployer pattern | polygonscan.com |
| BNB Chain | Same deployer pattern | bscscan.com |
| Avalanche | Same deployer pattern | snowtrace.io |
| Unichain | Same deployer pattern | uniscan.xyz |

### Solana

Solana uses a TypeScript SDK (no smart contract). Batch transfers use `SystemProgram.transfer` for SOL and `Token.createTransferInstruction` for SPL tokens, bundled into a single transaction.

### Stacks

Stacks uses a Clarity smart contract (`spraay-batch.clar`) deployed at:
- **Testnet:** `ST7431QK2YMPP3SQYJXZ3GTB6MJVGF07N2EV9R1F.spraay-batch`

### Bitcoin

Bitcoin uses PSBT-based batch payments. See `bitcoin-psbt.md` for details.

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| `INSUFFICIENT_FUNDS` | Sender balance < total + fee + gas | Top up wallet |
| `ARRAY_LENGTH_MISMATCH` | recipients.length != amounts.length | Fix input arrays |
| `TOO_MANY_RECIPIENTS` | > 200 recipients | Split into multiple batches |
| `INVALID_TOKEN` | Token address not recognized | Check token contract address |
| `APPROVAL_REQUIRED` | ERC-20 not approved for contract | Call `approve()` first |
| `GAS_ESTIMATION_FAILED` | Transaction will revert | Check all addresses are valid |
