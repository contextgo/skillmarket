# x402 Gateway Reference

## How x402 Works

The x402 protocol enables HTTP-native micropayments. When an agent calls a paid endpoint:

1. Agent sends request to `gateway.spraay.app`
2. Gateway responds with `402 Payment Required` + payment details
3. Agent's x402 client constructs a USDC payment on Base
4. Agent resends request with `X-402-Payment` header containing the signed payment
5. Gateway verifies payment, executes the request, returns the result

**Payment chain:** Base (Chain ID 8453)
**Payment token:** USDC (`0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`)
**Facilitator:** Coinbase CDP

All payments settle to: `0xAd62f03C7514bb8c51f1eA70C2b75C37404695c8`

## Bazaar Discovery

All gateway routes are registered with Bazaar for agent discovery. Agents can query:

```
GET /api/bazaar/catalog
```

Returns the full endpoint catalog with pricing, descriptions, and x402 payment requirements.

## Endpoint Catalog by Category

### Category 1: AI Inference
93 models via OpenRouter + BlockRun (43 BlockRun + 50 OpenRouter), plus 4 smart routing profiles.

```
POST /api/ai/chat              — $0.01-0.05 per request
POST /api/ai/complete           — $0.01-0.05 per request
GET  /api/ai/models             — $0.001
POST /api/ai/embeddings         — $0.005
```

### Category 2: RPC (7 chains via Alchemy)
```
POST /api/rpc/base              — $0.001
POST /api/rpc/ethereum          — $0.001
POST /api/rpc/arbitrum          — $0.001
POST /api/rpc/polygon           — $0.001
POST /api/rpc/bnb               — $0.001
POST /api/rpc/avalanche         — $0.001
POST /api/rpc/unichain          — $0.001
```

### Category 3: Search & RAG (Tavily)
```
POST /api/search/web            — $0.005
POST /api/search/context        — $0.01
POST /api/search/extract        — $0.005
```

### Category 4: Communication
```
POST /api/email/send            — $0.005 (AgentMail)
GET  /api/email/inbox           — $0.005
POST /api/sms/send              — $0.01 (simulated)
POST /api/xmtp/send             — $0.005 (live on Fly.io)
GET  /api/xmtp/messages         — $0.005
POST /api/xmtp/subscribe        — $0.005
```

### Category 5: IPFS Storage (Pinata)
```
POST /api/ipfs/pin              — $0.01
GET  /api/ipfs/get/:cid         — $0.005
DELETE /api/ipfs/unpin/:cid     — $0.005
```

### Category 6: GPU/Compute (Replicate)
```
POST /api/compute/run           — $0.01-0.05
GET  /api/compute/status/:id    — $0.005
POST /api/compute/image         — $0.02
POST /api/compute/transcribe    — $0.02
```

### Category 7: Oracle/Price Feeds
```
GET  /api/oracle/price/:pair    — $0.001
GET  /api/oracle/gas/:chain     — $0.001
GET  /api/oracle/historical     — $0.005
GET  /api/oracle/pairs          — $0.001
```

### Category 8: Identity/KYC
```
POST /api/identity/verify       — $0.01
GET  /api/identity/status/:id   — $0.01
POST /api/identity/attestation  — $0.01
```

### Category 9: Escrow
```
POST /api/escrow/create         — $0.05
POST /api/escrow/release        — $0.10
GET  /api/escrow/status/:id     — $0.05
```

### Category 10: Bridge (Cross-chain)
```
POST /api/bridge/quote          — $0.05
POST /api/bridge/execute        — $0.25
GET  /api/bridge/status/:id     — $0.05
```

### Category 11: Payroll
```
POST /api/payroll/create        — $0.10
POST /api/payroll/execute       — $0.25
GET  /api/payroll/schedule/:id  — $0.05
```

### Category 12: Compliance
```
POST /api/compliance/screen     — $0.005
POST /api/compliance/report     — $0.005
GET  /api/compliance/status/:id — $0.005
```

### Category 13: Wallet Provisioning
```
POST /api/wallet/create         — $0.01
GET  /api/wallet/balance/:addr  — $0.01
```

### Category 14: Data/Analytics
```
GET  /api/data/token/:symbol    — $0.001
GET  /api/data/portfolio/:addr  — $0.005
GET  /api/data/transactions     — $0.005
```

### Category 15: Robot Tasks (RTP)
```
GET  /api/rtp/discover          — $0.01
POST /api/rtp/commission        — $0.05
GET  /api/rtp/status/:taskId    — $0.005
POST /api/rtp/cancel/:taskId    — $0.01
POST /api/rtp/complete/:taskId  — $0.01
GET  /api/rtp/capabilities      — $0.005
POST /api/rtp/register          — $0.02
POST /api/rtp/heartbeat         — $0.005
```

### Category 16: Bitcoin (PSBT)
```
POST /api/bitcoin/batch-prepare   — $0.02
POST /api/bitcoin/batch-broadcast — $0.01
GET  /api/bitcoin/fee-estimate    — $0.001
GET  /api/bitcoin/utxos/:addr     — $0.001
GET  /api/bitcoin/balance/:addr   — $0.001
GET  /api/bitcoin/validate/:addr  — $0.001
```

## Gateway Architecture

- **Runtime:** TypeScript/Express on Railway
- **Payment facilitator:** Coinbase CDP
- **Route pattern:** Named exported handler functions wired via `app.get()`/`app.post()` in `index.ts`
- **Environment variables:** `ALCHEMY_API_KEY`, `AGENTMAIL_API_KEY`, `PINATA_API_KEY`, `PINATA_API_SECRET`
- **Live integrations:** XMTP (Fly.io), RPC (Alchemy, 7 chains), Email (AgentMail), IPFS (Pinata)
- **AI providers:** OpenRouter (50 models) + BlockRun (43 models + 4 smart routing profiles)

## Error Responses

```json
{
  "error": "PAYMENT_REQUIRED",
  "status": 402,
  "paymentDetails": {
    "amount": "0.01",
    "token": "USDC",
    "chain": "base",
    "recipient": "0xAd62f03C7514bb8c51f1eA70C2b75C37404695c8"
  }
}
```

Common errors:
- `402` — Payment required (standard x402 flow)
- `400` — Invalid request parameters
- `404` — Endpoint not found
- `429` — Rate limited
- `500` — Upstream service error
