# Robot Task Protocol (RTP) Reference

## Overview

The Robot Task Protocol (RTP) is an open standard for AI agents to discover, commission, and pay physical robots for real-world tasks via x402 USDC micropayments. It bridges the gap between digital AI agents and physical-world execution.

**Open-source repos (all under `plagtech/`):**
- `rtp-spec` — Protocol specification
- `rtp-sdk` — TypeScript SDK + `rtp-device` CLI
- `rtp-python-sdk` — Python SDK (PyPI: `spraay-rtp`)
- `rtp-pi-demo` — Raspberry Pi 4 + SG90 servo demo
- `rtp-xmtp-mesh` — XMTP-based robot mesh networking
- `awesome-rtp` — Curated resource list

## Protocol Flow

```
1. DISCOVER  — Agent queries available robots by capability + location
2. NEGOTIATE — Agent reviews robot capabilities, pricing, availability
3. COMMISSION — Agent sends task with parameters + USDC payment
4. EXECUTE   — Robot performs the physical task
5. VERIFY    — Robot reports completion with proof (photo, sensor data)
6. SETTLE    — Payment released from escrow to robot operator
```

## Gateway Endpoints

### Discover Robots
```
GET /api/rtp/discover — $0.01
```

Query parameters:
- `capability` — Task type (delivery, inspection, manipulation, sensing)
- `location` — Lat,lng coordinates
- `radius` — Search radius in meters (default: 5000)
- `minRating` — Minimum trust score (0-100)

**Response:**
```json
{
  "robots": [
    {
      "id": "robot-001",
      "name": "DeliveryBot Alpha",
      "capabilities": ["delivery", "transport"],
      "location": {"lat": 37.7749, "lng": -122.4194},
      "pricePerTask": "2.50",
      "rating": 95,
      "status": "available"
    }
  ]
}
```

### Commission Task
```
POST /api/rtp/commission — $0.05
```

**Request:**
```json
{
  "robotId": "robot-001",
  "task": "deliver_package",
  "params": {
    "destination": "123 Main St, San Francisco, CA",
    "weight_kg": 2.5,
    "priority": "standard"
  },
  "maxBudgetUSDC": "5.00",
  "callbackUrl": "https://agent.example.com/webhook/task-complete"
}
```

### Check Task Status
```
GET /api/rtp/status/:taskId — $0.005
```

Returns current task state: `pending`, `accepted`, `in_progress`, `completed`, `failed`, `cancelled`.

### Robot Registration
```
POST /api/rtp/register — $0.02
```

Used by robot operators to register devices on the network.

**Request:**
```json
{
  "name": "My Servo Bot",
  "capabilities": ["manipulation", "sensing"],
  "location": {"lat": 37.7749, "lng": -122.4194},
  "pricePerTask": "1.00",
  "hardwareSpec": {
    "platform": "raspberry-pi-4",
    "actuators": ["SG90-servo"],
    "sensors": ["camera", "temperature"]
  },
  "walletAddress": "0x..."
}
```

### Robot Heartbeat
```
POST /api/rtp/heartbeat — $0.005
```

Robots send periodic heartbeats to maintain availability status.

## Capability Schema

Standard capability types:
- `delivery` — Transport objects between locations
- `inspection` — Visual/sensor inspection of locations or objects
- `manipulation` — Physical interaction with objects (pick, place, actuate)
- `sensing` — Environmental data collection (temperature, humidity, air quality)
- `patrol` — Route-based monitoring
- `cleaning` — Surface cleaning operations

## Competitive Context

- **peaq** — DePIN L1 infrastructure (complementary, potential integration partner)
- **Auki** — Spatial coordination protocol (complementary, handles spatial awareness)
- RTP is the **payment and task coordination** layer — works alongside these

## Base Batches 2026 Robotics Track

RTP is being submitted to Base Batches 2026 Robotics Track (run by Virtuals Protocol):
- ~$50K prize pool
- 30 Unitree G1 humanoids available
- Demo: Raspberry Pi 4 + SG90 servo controlled via x402 micropayments

## rtp-device CLI

```bash
# Install
npm install -g @spraay/rtp-sdk

# Register a device
rtp-device register --name "My Bot" --capability manipulation

# Start heartbeat
rtp-device heartbeat --interval 30s

# TODO: rtp-device init wizard (pending documentation completion)
```
