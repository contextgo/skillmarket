# Bitcoin PSBT Batch Payments Reference

## Overview

Spraay Bitcoin batch payments use Partially Signed Bitcoin Transactions (PSBTs) for non-custodial multi-recipient transfers. The workflow separates transaction construction from signing, keeping private keys on the client side.

## PSBT Workflow

```
1. Client calls /api/bitcoin/batch-prepare with recipients + fee rate
2. Gateway constructs PSBT (selects UTXOs, builds outputs, calculates change)
3. Client receives unsigned PSBT (base64)
4. Client signs PSBT locally with their private key
5. Client calls /api/bitcoin/batch-broadcast with signed PSBT
6. Gateway broadcasts to Bitcoin network via Mempool.space API
```

## Endpoints

### Prepare Batch Transaction
```
POST /api/bitcoin/batch-prepare — $0.02
```

**Request:**
```json
{
  "recipients": [
    {"address": "bc1q...", "amount": 50000},
    {"address": "bc1q...", "amount": 25000}
  ],
  "feeRate": 10,
  "changeAddress": "bc1q...",
  "senderAddress": "bc1q..."
}
```

- `amount` is in satoshis
- `feeRate` is in sat/vByte (use fee-estimate endpoint to get current rates)
- `changeAddress` receives leftover funds after outputs + fee

**Response:**
```json
{
  "psbt": "cHNidP8B...",
  "fee": 2340,
  "totalInput": 77340,
  "totalOutput": 75000,
  "inputCount": 2,
  "outputCount": 3
}
```

### Broadcast Signed Transaction
```
POST /api/bitcoin/batch-broadcast — $0.01
```

**Request:**
```json
{
  "signedPsbt": "cHNidP8B..."
}
```

**Response:**
```json
{
  "txid": "abc123...",
  "status": "broadcast",
  "explorer": "https://mempool.space/tx/abc123..."
}
```

### Fee Estimate
```
GET /api/bitcoin/fee-estimate — $0.001
```

**Response:**
```json
{
  "fastestFee": 25,
  "halfHourFee": 15,
  "hourFee": 10,
  "economyFee": 5,
  "minimumFee": 1
}
```

### Get UTXOs
```
GET /api/bitcoin/utxos/:address — $0.001
```

Returns unspent transaction outputs for UTXO selection.

### Get Balance
```
GET /api/bitcoin/balance/:address — $0.001
```

Returns confirmed and unconfirmed balance in satoshis.

### Validate Address
```
GET /api/bitcoin/validate/:address — $0.001
```

Validates Bitcoin address format (legacy, SegWit, Taproot).

## Technical Stack

- **bitcoinjs-lib** for PSBT construction and parsing
- **Mempool.space API** for fee estimation, UTXO queries, and broadcast
- Non-custodial: gateway never holds private keys
- Supports all address types: P2PKH (1...), P2SH (3...), Bech32 (bc1q...), Bech32m/Taproot (bc1p...)

## UTXO Selection Strategy

The gateway uses a coin selection algorithm that:
1. Sorts UTXOs by value (largest first)
2. Selects UTXOs until total input >= total output + estimated fee
3. Calculates change output if remainder > dust threshold (546 sats)
4. Re-estimates fee with final input/output count

## Planned: Bells Coin (Chain #14)

Same UTXO architecture will be extended to Bells coin as the next chain deployment.
