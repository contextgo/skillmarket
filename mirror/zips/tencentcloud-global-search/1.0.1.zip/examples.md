# Tencent Cloud Query Skill - Usage Examples

基于 Tencent Cloud Query Skill 的完整使用示例，展示如何按照 Step 1-7 的流程进行腾讯云产品信息查询和对比分析。

Complete usage examples based on Tencent Cloud Query Skill, demonstrating how to query and compare Tencent Cloud product information following the Step 1-7 process.

---

## Example 1: 查询单个产品完整信息 (CVM)

**User:** "帮我详细了解一下腾讯云服务器CVM"

**Agent Action Flow:**

### Step 1: Identify the Product (识别产品)
- 用户查询关键词 (User Query Keywords): "腾讯云服务器", "CVM"
- 匹配产品 (Matched Product): 云服务器 CVM (Cloud Virtual Machine)
- 产品代码 (Product Code): cvm

### Step 2: Construct Search Queries (构建搜索查询)
- 中国站 (China Site): "CVM 云服务器 site:cloud.tencent.com"
- 文档 (Documentation): "CVM 实例规格 计费 site:cloud.tencent.com/document"

### Step 3: Retrieve Product Homepage Information (获取产品首页信息)
- 访问 (Visit): `https://cloud.tencent.com/product/cvm`
- 提取首页核心信息 (Extract Homepage Core Info):
  - **Slogan**: "稳定、安全、弹性、高性能的云端计算服务"
  - **核心卖点 (Core Selling Points)**: 稳定可靠、安全防护、弹性扩展、丰富规格
  - **主要功能模块 (Main Function Modules)**: 实例、镜像、云硬盘、网络、安全组
  - **应用场景 (Use Cases)**: 网站应用、企业应用、游戏、AI训练

### Step 4: Search Official Documentation (搜索官方文档)
按照文档架构检索各模块信息:
- 产品简介: `https://cloud.tencent.com/document/product/213`
- 计费说明: `https://cloud.tencent.com/document/product/213/2179`
- 实例规格: `https://cloud.tencent.com/document/product/213/11518`
- 快速入门: `https://cloud.tencent.com/document/product/213/2936`

### Step 5: Extract Key Information from Documentation (从文档提取关键信息)
提取各维度详细信息:
- 产品概述: 虚拟化技术、多种实例规格族
- 计费: 包年包月、按量计费、竞价实例
- 功能: 弹性伸缩、自动快照、云监控
- 操作: 实例创建、连接、管理、退还

### Step 6: Integrate and Synthesize Information (整合和综合信息)
融合首页信息和文档信息:
- 首页卖点 + 文档技术细节
- 验证价格信息一致性
- 补充技术架构说明

### Step 7: Present Results (呈现结果)

```markdown
# 云服务器 CVM - Cloud Virtual Machine

> 稳定、安全、弹性、高性能的云端计算服务，满足多样性业务需求

---

## 一、产品概述 (Product Overview)

### 1.1 产品简介
**产品定位**: 腾讯云最基础的云计算服务，提供可弹性伸缩的计算能力

**核心价值主张**: 稳定、安全、弹性、高性能，实时满足多样性业务需求

**产品描述**: 云服务器CVM是一种稳定可靠、弹性可伸缩的云计算服务。您可以根据业务需要随时创建、释放、升级或降级实例，实现计算资源的灵活管理。

### 1.2 产品架构
**架构概览**: 采用虚拟化技术，将物理服务器资源池化，按需分配给用户的实例

**核心组件**:
- **实例 (Instance)**: 虚拟计算环境，包含CPU、内存、操作系统
- **镜像 (Image)**: 实例运行环境的模板，包含操作系统和预装软件
- **云硬盘 (Cloud Block Storage)**: 高可用、高可靠的弹性块存储
- **网络 (Network)**: VPC、子网、安全组、弹性公网IP

### 1.3 功能特性

**首页核心卖点**:
- 稳定可靠，99.95%的服务可用性
- 安全防护，多层安全防护机制
- 弹性扩展，支持随时调整配置
- 丰富规格，满足各类场景需求

**详细功能列表**:
| 功能模块 | 功能描述 | 信息来源 |
|---------|---------|---------|
| 弹性计算 | 支持随时升级/降配实例配置 | 首页+文档 |
| 弹性伸缩 | 根据负载自动调整实例数量 | 文档 |
| 镜像市场 | 丰富的预装环境镜像 | 首页 |
| 快照备份 | 自动/手动快照，支持快速回滚 | 文档 |
| 安全组 | 虚拟防火墙，控制网络访问 | 文档 |
| 云监控 | 全方位监控告警 | 文档 |

### 1.4 产品系列/版本
| 版本/系列 | 适用场景 | 主要特性 |
|----------|---------|---------|
| 标准型 | 通用场景 | 性价比高，适合大多数应用 |
| 计算型 | 高性能计算 | CPU密集型，高CPU内存比 |
| 内存型 | 内存数据库 | 大内存，适合缓存、数据库 |
| GPU型 | AI/图形渲染 | NVIDIA GPU加速 |
| 高IO型 | 大数据处理 | 高磁盘IO性能 |

### 1.5 应用场景
- **网站应用**: 搭建Web服务器、应用服务器
- **企业应用**: ERP、CRM、OA等企业管理系统
- **游戏服务**: 游戏服务器、对战平台
- **AI训练**: 机器学习模型训练、推理

---

## 二、产品计费 (Product Pricing)

### 2.1 计费项 (Billable Items)
| 计费组件 (Component) | 计费说明 (Description) |
|---------------------|----------------------|
| 实例 (Instance) | 按CPU和内存配置计费 |
| 系统盘 (System Disk) | 随实例计费的存储 |
| 数据盘 (Data Disk) | 独立计费的云硬盘 |
| 公网带宽 (Public Bandwidth) | 按带宽或流量计费 |
| 快照 (Snapshot) | 按快照占用存储空间计费 |

### 2.2 计费方式 (Billing Methods)
| 计费方式 (Method) | 说明 (Description) | 适用场景 (Scenario) |
|------------------|-------------------|-------------------|
| 包年包月 (Subscription) | 预付费，价格优惠 | 长期稳定业务 |
| 按量计费 (Pay-as-you-go) | 后付费，按秒计费 | 短期、突发业务 |
| 竞价实例 (Spot Instance) | 价格最低，可能被回收 | 容错性高的任务 |

### 2.3 价格参考 (Pricing Reference)
- **起步价格**: 约0.06元/小时起（按量计费）
- **免费额度**: 新用户可享受部分免费试用
- **计费计算器**: https://buy.cloud.tencent.com/price/cvm

---

## 三、快速入门 (Quick Start)

### 3.1 使用限制 (Usage Limits)
| 限制项 (Limit Item) | 限制值 (Limit Value) |
|--------------------|---------------------|
| 单个地域实例数 | 根据配额调整 |
| 公网IP绑定 | 与实例一一对应 |
| 安全组规则 | 默认100条 |

### 3.2 入门步骤 (Getting Started Steps)
1. 选择地域和可用区
2. 选择实例规格和镜像
3. 配置存储和网络
4. 设置安全组
5. 创建并连接实例

---

## 四、操作指南 (Operation Guide)

### 4.1 实例管理 (Instance Management)
| 操作 (Operation) | 说明 (Description) |
|-----------------|-------------------|
| 创建 (Create) | 通过控制台或API创建实例 |
| 开机/关机 (Start/Stop) | 控制实例运行状态 |
| 重启 (Restart) | 软重启或强制重启 |
| 退还 (Return) | 彻底删除实例，数据清除 |

### 4.2 配置管理 (Configuration Management)
- **调整配置**: 支持在线和离线变更配置
- **重装系统**: 可更换操作系统
- **扩容磁盘**: 在线扩容数据盘

---

## 五、开发参考 (Development Reference)

### 5.1 API概览
- **认证方式**: SecretId + SecretKey
- **请求地址**: cvm.tencentcloudapi.com

### 5.2 SDK支持
| 语言 | SDK下载 |
|-----|---------|
| Java | https://github.com/TencentCloud/tencentcloud-sdk-java |
| Python | https://github.com/TencentCloud/tencentcloud-sdk-python |
| Go | https://github.com/TencentCloud/tencentcloud-sdk-go |
| Node.js | https://github.com/TencentCloud/tencentcloud-sdk-nodejs |

---

## 六、相关资源 (Related Resources)

### 文档链接 (Documentation Links)
- [产品首页](https://cloud.tencent.com/product/cvm)
- [帮助文档](https://cloud.tencent.com/document/product/213)
- [API参考](https://cloud.tencent.com/document/api/213/15688)
- [定价详情](https://buy.cloud.tencent.com/price/cvm)

### 相关产品 (Related Products)
- **VPC**: 私有网络，隔离的网络环境
- **CLB**: 负载均衡，流量分发
- **COS**: 对象存储，数据持久化存储
```

---

## Example 2: 产品对比分析 (TDSQL-C vs TDSQL)

**User:** "TDSQL-C和TDSQL分布式版有什么区别？"

**Agent Action Flow:**

### Step 1: Identify Products (识别产品)
- 产品1: 云原生数据库 TDSQL-C (TDSQL-C)
- 产品2: 分布式数据库 TDSQL (TDSQL)

### Step 2-3: 分别获取两个产品的首页信息
- TDSQL-C: `https://cloud.tencent.com/product/tdsqlc`
- TDSQL: `https://cloud.tencent.com/product/tdsql`

### Step 4-5: 分别检索两个产品的文档信息
- 架构文档
- 计费说明
- 功能特性
- 适用场景

### Step 6: Integrate and Compare (整合和对比)
对比维度:
- 架构差异 (云原生集中式 vs 分布式)
- 扩展方式 (垂直扩展 vs 水平扩展)
- 适用场景 (中小型应用 vs 大规模分布式)
- 价格差异

### Step 7: Present Comparison Results (呈现对比结果)

```markdown
# TDSQL-C vs TDSQL - 对比分析

## 一、核心差异对比

| 对比维度 | TDSQL-C | TDSQL |
|---------|---------|-------|
| **产品定位** | 云原生关系型数据库 | 金融级分布式数据库 |
| **核心架构** | 计算存储分离，共享存储 | 分布式架构，数据分片 |
| **扩展方式** | 垂直扩展 + 只读节点 | 水平扩展（自动分片） |
| **数据分布** | 集中式存储 | 分布式存储 |
| **最大节点数** | 1主15从 | 百级节点 |
| **弹性速度** | 秒级 | 分钟级 |
| **分布式事务** | 不支持 | 原生支持 |

## 二、功能特性对比

| 功能 | TDSQL-C | TDSQL |
|-----|---------|-------|
| MySQL兼容性 | 100% | 100% |
| PostgreSQL兼容性 | 支持 | 支持 |
| 读写分离 | 自动 | 透明 |
| 自动备份 | 支持 | 支持 |
| 数据分片 | 不支持 | 支持 |
| 全局事务 | 不支持 | 支持 |

## 三、适用场景建议

**选择 TDSQL-C:**
- 需要高性能、高可用的云原生数据库
- 数据量在TB级别，单库存储足够
- 需要秒级弹性扩缩容
- 从传统MySQL升级

**选择 TDSQL:**
- 数据量达到PB级，需要水平扩展
- 超高并发交易场景（如金融、支付）
- 需要分布式事务支持
- 金融级高可用要求

## 四、价格对比

| 产品 | 起步价格 | 价格特点 |
|-----|---------|---------|
| TDSQL-C | 约150元/月 | 按实际使用计费 |
| TDSQL | 按节点计费 | 根据分片数量计费 |

## 五、选型建议

1. **从传统MySQL迁移**: 优先选择 TDSQL-C，平滑升级
2. **解决单机瓶颈**: 选择 TDSQL，支持水平扩展
3. **金融级应用**: TDSQL 提供金融级高可用
4. **成本敏感**: TDSQL-C 按需计费更灵活

> **注意**: TDSQL-C适合大多数互联网应用，TDSQL适合大规模分布式场景。
```

---

## Example 3: 查询产品计费详情 (COS)

**User:** "COS对象存储是怎么收费的？"

**Agent Action Flow:**

### Step 1: Identify Product (识别产品)
- 产品: 对象存储 COS (Cloud Object Storage)
- 产品代码: cos

### Step 2-3: Get Homepage Info (获取首页信息)
- 访问: `https://cloud.tencent.com/product/cos`
- 提取: 产品定位、核心功能、定价入口

### Step 4: Search Pricing Documentation (搜索计费文档)
- 计费说明: `https://cloud.tencent.com/document/product/436/16871`
- 价格详情: `https://buy.cloud.tencent.com/price/cos`

### Step 5: Extract Pricing Information (提取计费信息)
- 计费项: 存储费用、请求费用、流量费用、数据处理费
- 计费方式: 按量计费、资源包
- 存储类型: 标准存储、低频存储、归档存储、深度归档

### Step 6: Integrate Information (整合信息)
- 首页功能亮点 + 文档详细计费规则
- 验证价格一致性

### Step 7: Present Results (呈现结果)

```markdown
# 对象存储 COS - Cloud Object Storage

## 产品计费详解

### 计费项组成
| 计费项 | 说明 | 计费方式 |
|-------|------|---------|
| **存储费用** | 按实际存储量计费 | 按量计费/资源包 |
| **请求费用** | PUT/GET等API请求 | 按量计费 |
| **流量费用** | 外网流出流量 | 按量计费/流量包 |
| **数据处理** | 图片处理、视频转码等 | 按量计费 |

### 存储类型价格对比
| 存储类型 | 适用场景 | 单价(元/GB/月) |
|---------|---------|---------------|
| **标准存储** | 频繁访问 | ~0.118 |
| **低频存储** | 月均访问1-2次 | ~0.08 |
| **归档存储** | 很少访问 | ~0.033 |
| **深度归档** | 几乎不访问 | ~0.015 |

### 计费方式选择建议
- **按量计费**: 业务波动大，难以预测用量
- **资源包**: 业务稳定，可预估用量，更优惠

### 成本优化建议
1. 根据访问频率选择合适的存储类型
2. 使用生命周期规则自动转换存储类型
3. 购买资源包享受折扣
4. 使用CDN加速减少回源流量

### 价格计算器
[COS价格计算器](https://buy.cloud.tencent.com/price/cos)
```

---

## Example 4: 查询API开发参考 (创建CVM实例)

**User:** "创建CVM实例的API需要哪些参数？"

**Agent Action Flow:**

### Step 1: Identify Query Type (识别查询类型)
- 产品: CVM
- 信息类型: API参数 / 开发参考

### Step 2-4: Search API Documentation (搜索API文档)
- API概览: `https://cloud.tencent.com/document/api/213/15688`
- RunInstances API: `https://cloud.tencent.com/document/api/213/15730`

### Step 5: Extract API Information (提取API信息)
- API名称: RunInstances
- 请求方式: HTTP POST
- 必需参数 vs 可选参数
- 参数约束和示例

### Step 7: Present API Reference (呈现API参考)

```markdown
# CVM RunInstances API - 创建实例

## API概览
- **Action**: RunInstances
- **版本**: 2017-03-12
- **协议**: HTTPS
- **请求地址**: cvm.tencentcloudapi.com

## 必需参数 (Required Parameters)

| 参数名 | 类型 | 说明 |
|-------|------|------|
| **Region** | String | 地域，如 ap-guangzhou |
| **InstanceChargeType** | String | 计费模式，如 POSTPAID_BY_HOUR |
| **InstanceType** | String | 实例机型，如 S5.LARGE8 |
| **ImageId** | String | 镜像ID |
| **SystemDisk** | Object | 系统盘配置 |
| **VirtualPrivateCloud** | Object | VPC网络配置 |

## 常用可选参数 (Optional Parameters)

| 参数名 | 类型 | 默认值 | 说明 |
|-------|------|-------|------|
| **InstanceName** | String | 未命名 | 实例名称 |
| **InstanceCount** | Integer | 1 | 购买实例数量 |
| **InternetAccessible** | Object | - | 公网带宽配置 |
| **LoginSettings** | Object | - | 登录设置 |
| **SecurityGroupIds** | Array | - | 安全组ID列表 |
| **UserData** | String | - | 自定义数据 |

## 请求示例

```bash
# TCCLI 命令行工具
tccli cvm RunInstances \
  --Region ap-guangzhou \
  --InstanceChargeType POSTPAID_BY_HOUR \
  --InstanceType S5.LARGE8 \
  --ImageId img-xxxxxxxx \
  --SystemDisk.DiskType CLOUD_PREMIUM \
  --SystemDisk.DiskSize 50 \
  --VirtualPrivateCloud.VpcId vpc-xxxxxxxx \
  --VirtualPrivateCloud.SubnetId subnet-xxxxxxxx \
  --InstanceCount 1
```

```python
# Python SDK
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.cvm.v20170312 import cvm_client, models

# 请替换为您的实际SecretId和SecretKey
cred = credential.Credential("<your-secret-id>", "<your-secret-key>")
httpProfile = HttpProfile()
httpProfile.endpoint = "cvm.tencentcloudapi.com"
clientProfile = ClientProfile()
clientProfile.httpProfile = httpProfile
client = cvm_client.CvmClient(cred, "ap-guangzhou", clientProfile)

req = models.RunInstancesRequest()
params = {
    "InstanceChargeType": "POSTPAID_BY_HOUR",
    "InstanceType": "S5.LARGE8",
    "ImageId": "img-xxxxxxxx",
    "SystemDisk": {
        "DiskType": "CLOUD_PREMIUM",
        "DiskSize": 50
    },
    "VirtualPrivateCloud": {
        "VpcId": "vpc-xxxxxxxx",
        "SubnetId": "subnet-xxxxxxxx"
    }
}
req.from_json_string(str(params))
resp = client.RunInstances(req)
print(resp.to_json_string())
```

## 返回示例
```json
{
  "Response": {
    "InstanceIdSet": ["ins-xxxxxxxx"],
    "RequestId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
  }
}
```

## 错误码
| 错误码 | 说明 |
|-------|------|
| InvalidRegion.NotFound | 指定的地域不存在 |
| InvalidInstanceType.NotFound | 指定的实例类型不存在 |
| InvalidImageId.NotFound | 指定的镜像不存在 |
| InvalidVpc.NotFound | 指定的VPC不存在 |

## 相关API
- [DescribeInstances](https://cloud.tencent.com/document/api/213/15728) - 查询实例列表
- [StartInstances](https://cloud.tencent.com/document/api/213/15735) - 启动实例
- [TerminateInstances](https://cloud.tencent.com/document/api/213/15736) - 退还实例

## 参考文档
- [API概览](https://cloud.tencent.com/document/api/213/15688)
- [SDK中心](https://cloud.tencent.com/document/sdk)
- [开发者指南](https://cloud.tencent.com/document/product/213/492)
```

---

## Example 5: 多产品综合选型建议

**User:** "我想搭建一个电商网站，需要数据库、存储和服务器，有什么推荐？"

**Agent Action Flow:**

### Step 1: Analyze Requirements (分析需求)
- **场景**: 电商网站
- **需求**: 计算资源(CVM) + 数据库 + 文件存储
- **隐含需求**: 高可用、弹性扩展、安全防护

### Step 2-6: Query Multiple Products (查询多个产品)
分别查询并分析:
1. CVM - 应用服务器
2. TDSQL-C - 数据库
3. COS - 图片/文件存储
4. CLB - 负载均衡
5. CDN - 静态资源加速

### Step 7: Present Integrated Solution (呈现综合方案)

```markdown
# 电商网站架构方案推荐

## 一、产品选型组合

| 层级 | 推荐产品 | 说明 |
|-----|---------|------|
| **接入层** | CDN + CLB | 全球加速 + 负载均衡 |
| **应用层** | CVM/TKE | 部署Web应用，支持弹性伸缩 |
| **数据层** | TDSQL-C | 高可用数据库，支持读写分离 |
| **存储层** | COS | 存储商品图片、用户上传文件 |
| **缓存层** | Redis | 热点数据缓存，加速访问 |
| **安全** | WAF + 主机安全 | Web防护 + 服务器安全 |

## 二、各产品配置建议

### 1. 云服务器 CVM
- **规格**: 4核8GB起步，根据流量调整
- **数量**: 至少2台，跨可用区部署
- **计费**: 包年包月（长期稳定）
- **镜像**: CentOS/Ubuntu + Nginx

### 2. 数据库 TDSQL-C
- **版本**: MySQL 8.0
- **规格**: 4核16GB起步
- **架构**: 1主2从，自动读写分离
- **备份**: 开启自动备份，保留7天

### 3. 对象存储 COS
- **存储类型**: 标准存储（频繁访问）
- **CDN加速**: 开启，提升图片加载速度
- **图片处理**: 开启数据万象，自动生成缩略图

### 4. 负载均衡 CLB
- **类型**: 应用型负载均衡（七层）
- **协议**: HTTPS（配置SSL证书）
- **健康检查**: 开启，自动剔除异常节点

## 三、架构优势

1. **高可用**: 跨可用区部署，单点故障自动切换
2. **弹性扩展**: 支持自动伸缩，应对大促流量
3. **成本优化**: 按实际使用量付费，无闲置资源
4. **安全防护**: 多层安全防护，保障业务安全

## 四、预估成本（月度）

| 产品 | 配置 | 预估费用 |
|-----|------|---------|
| CVM | 2台 × 4核8GB | ~300元 |
| TDSQL-C | 4核16GB + 存储 | ~600元 |
| COS | 500GB存储 + 流量 | ~150元 |
| CLB | 按流量计费 | ~80元 |
| CDN | 1TB流量 | ~120元 |
| **合计** | - | **~1250元/月** |

> 注: 实际费用根据业务流量和配置调整，新用户可享受免费试用和折扣。

## 五、部署步骤

1. **创建VPC网络**，规划子网
2. **创建TDSQL-C**数据库，初始化数据
3. **创建CVM实例**，部署应用代码
4. **配置CLB**，添加后端服务器
5. **开通COS**，配置CDN加速
6. **配置WAF**，添加防护规则
7. **配置监控告警**，确保服务稳定

## 六、相关文档
- [CVM快速入门](https://cloud.tencent.com/document/product/213/2936)
- [TDSQL-C最佳实践](https://cloud.tencent.com/document/product/1003/53417)
- [电商解决方案](https://cloud.tencent.com/solution/ecommerce)
```

---

## 使用建议 (Usage Recommendations)

1. **单产品查询 (Single Product Query)**: 按照 Step 1-7 完整流程，获取全面的产品信息
2. **产品对比 (Product Comparison)**: 使用对比模板，突出核心差异，帮助用户决策
3. **方案推荐 (Solution Recommendation)**: 结合业务场景，提供多产品组合方案
4. **信息时效 (Information Timeliness)**: 价格信息变化较快，建议引导用户查看官网实时价格
5. **补充链接 (Supplementary Links)**: 始终提供官方文档链接，方便用户获取最新信息
