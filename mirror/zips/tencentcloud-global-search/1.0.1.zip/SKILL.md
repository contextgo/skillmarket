---
name: tencentcloud-global-search
description: Query Tencent Cloud product information, documentation, parameters, features, and pricing from official sources without login. Use when the user asks about Tencent Cloud products (CVM, TDSQL, COS, CLB, etc.), needs product documentation, wants to compare product specifications, or needs help finding specific product parameters and features.
---

# 腾讯云产品查询 (Tencent Cloud Product Query)

This skill helps users find detailed information about Tencent Cloud products by searching official documentation and product pages without requiring login.

## When to Use / 使用场景

- User asks about specific Tencent Cloud products (CVM, TDSQL, COS, CLB, etc.) / 用户询问特定的腾讯云产品（CVM、TDSQL、COS、CLB等）
- User needs product documentation or API references / 用户需要产品文档或API参考
- User wants to compare product specifications or pricing / 用户想要比较产品规格或价格
- User needs help finding specific product parameters or features / 用户需要帮助查找特定的产品参数或功能
- User mentions "Tencent Cloud" or "腾讯云" and needs product information / 用户提到"腾讯云"并需要产品信息

---

## Step 1: Identify the Product (识别产品)

从全面的产品目录中确定用户询问的是哪个腾讯云产品：

### 1.1 识别用户查询中的产品关键词 / Identify Product Keywords from User Query

分析用户问题，提取以下信息 / Analyze user questions and extract the following information:
- **产品名称 (Product Name)**: 用户提到的具体产品名（如 CVM、TDSQL、COS）/ Specific product names mentioned by the user (e.g., CVM, TDSQL, COS)
- **产品类别 (Product Category)**: 用户可能提到的产品类别（如计算、数据库、存储）/ Product categories mentioned (e.g., Compute, Database, Storage)
- **功能需求 (Functional Requirements)**: 用户想要实现的功能（如搭建网站、数据备份、负载均衡）/ Functions the user wants to implement (e.g., build websites, data backup, load balancing)
- **使用场景 (Use Cases)**: 用户的业务场景（如电商、游戏、金融）/ User's business scenarios (e.g., e-commerce, gaming, finance)

### 1.2 使用产品别名对照表 / Product Alias Reference Table

如果用户使用非标准名称，参考以下别名映射 / If users use non-standard names, refer to the following alias mapping:

| 用户可能说的 (User May Say) | 对应产品 (Product) | 英文名 (English Name) |
|---------------------------|-------------------|----------------------|
| 云服务器、虚拟机、VM、云主机 (Cloud Server, VM, Cloud Host) | CVM | Cloud Virtual Machine |
| 对象存储、云盘、云存储 (Object Storage, Cloud Disk) | COS | Cloud Object Storage |
| 负载均衡、CLB (Load Balancer) | CLB | Cloud Load Balancer |
| 数据库、MySQL、PostgreSQL (Database) | TDSQL-C / TDSQL | Tencent Distributed SQL |
| Redis、缓存 (Redis, Cache) | TCR | Tencent Cloud Redis |
| 大模型、混元、Hunyuan (Large Model) | 腾讯混元大模型 | Tencent Hunyuan |
| 容器、K8s、Kubernetes (Container, K8s) | TKE | Tencent Kubernetes Engine |
| 函数计算、SCF (Function Compute) | 云函数 SCF | Serverless Cloud Function |
| 安全中心、云镜 (Security Center) | 主机安全 | Cloud Workload Protection |
| WAF、防火墙 (Firewall) | Web应用防火墙 | Web Application Firewall |
| CDN、加速 (CDN, Acceleration) | CDN | Content Delivery Network |
| VPC、私有网络 (VPC, Private Network) | 私有网络 VPC | Virtual Private Cloud |
| 大数据、数仓 (Big Data, Data Warehouse) | CDW | Cloud Data Warehouse |
| 消息队列、Kafka (Message Queue) | CKafka | Cloud Kafka |

### 1.3 确定目标产品 / Identify Target Product

从产品目录中找到最匹配的产品，记录 / Find the best matching product from the catalog and record:
- **产品中文名 (Chinese Name)**: 产品的中文名称
- **产品英文名 (English Name)**: 产品的英文名称
- **产品类别 (Category)**: 产品所属类别
- **产品代码 (Product Code)**: 用于构造URL的产品代码

---

## 📦 腾讯云全产品目录 (Tencent Cloud Full Product Catalog)

### 🖥️ 一、计算 (Compute)

#### 弹性计算 (Elastic Compute)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云服务器 CVM | Cloud Virtual Machine | 稳定、安全、弹性、高性能的云端计算服务 / Stable, secure, elastic, high-performance cloud computing service |
| 轻量应用服务器 Lighthouse | Lighthouse | 简单易用的云服务器，快速构建轻量级应用 / Simple and easy-to-use cloud server for rapid lightweight application development |
| GPU 云服务器 | GPU Cloud Server | 基于GPU应用的计算服务，满足AI、图形处理需求 / GPU-based computing service for AI and graphics processing |
| 裸金属云服务器 CBM | Cloud Bare Metal | 云端专用的高性能物理服务器租赁服务 / Dedicated high-performance physical server rental service in the cloud |
| 专用宿主机 CDH | CVM Dedicated Host | 独享物理服务器资源的云服务 / Cloud service with exclusive physical server resources |
| 弹性伸缩 AS | Auto Scaling | 根据业务需求自动调整CVM计算资源 / Automatically adjust CVM computing resources based on business needs |

#### 容器与Serverless (Containers & Serverless)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 容器服务 TKE | Tencent Kubernetes Engine | 基于原生Kubernetes的容器编排服务 / Container orchestration service based on native Kubernetes |
| 容器镜像服务 TCR | Tencent Container Registry | 安全可靠的容器镜像托管分发服务 / Secure and reliable container image hosting and distribution service |
| 云函数 SCF | Serverless Cloud Function | 无服务器的事件驱动型计算服务 / Serverless event-driven computing service |
| 高性能应用服务 HAI | Hyper Application Inventor | 面向AI和科学计算的GPU应用服务 / GPU application service for AI and scientific computing |

---

### 💾 二、存储 (Storage)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 对象存储 COS | Cloud Object Storage | 海量、安全、低成本的云存储服务 / Massive, secure, low-cost cloud storage service |
| 云硬盘 CBS | Cloud Block Storage | 高可用、高可靠的弹性块存储服务 / Highly available and reliable elastic block storage service |
| 文件存储 CFS | Cloud File Storage | 可扩展的共享文件存储服务 / Scalable shared file storage service |
| 归档存储 CAS | Cloud Archive Storage | 低成本、高可靠的云端归档存储 / Low-cost, highly reliable cloud archive storage |
| 数据万象 CI | Cloud Infinite | 提供图片、视频、文档等数据的处理服务 / Provides image, video, and document processing services |

---

### 🌐 三、网络与CDN (Networking & CDN)

#### 云上网络 (Cloud Networking)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 私有网络 VPC | Virtual Private Cloud | 隔离的虚拟网络环境 / Isolated virtual network environment |
| 负载均衡 CLB | Cloud Load Balancer | 流量分发服务，支持四层和七层 / Traffic distribution service supporting Layer 4 and Layer 7 |
| 弹性公网IP EIP | Elastic IP | 可独立购买和持有的公网IP地址 / Public IP address that can be purchased and held independently |
| NAT网关 | NAT Gateway | 安全的网络地址转换服务 / Secure network address translation service |
| VPN连接 | VPN Connection | 加密通道连接企业数据中心和腾讯云 / Encrypted connection between enterprise data centers and Tencent Cloud |

#### CDN与加速 (CDN & Acceleration)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 内容分发网络 CDN | Content Delivery Network | 全球加速节点，提升访问速度 / Global acceleration nodes to improve access speed |
| 全站加速网络 ECDN | Enterprise Content Delivery Network | 动静态内容一站式加速 / One-stop acceleration for dynamic and static content |
| 全球应用加速 GAAP | Global Application Acceleration Platform | 全球网络加速服务 / Global network acceleration service |

---

### 🗄️ 四、数据库 (Database)

#### 关系型数据库 (Relational Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云原生数据库 TDSQL-C | TDSQL-C | 高性能高可用的云原生数据库，兼容MySQL/PostgreSQL / High-performance, highly available cloud-native database compatible with MySQL/PostgreSQL |
| 分布式数据库 TDSQL | TDSQL | 金融级分布式数据库，支持MySQL和PostgreSQL / Financial-grade distributed database supporting MySQL and PostgreSQL |
| 云数据库 MySQL | TencentDB for MySQL | 稳定可靠的托管MySQL服务 / Stable and reliable managed MySQL service |
| 云数据库 PostgreSQL | TencentDB for PostgreSQL | 企业级PostgreSQL托管服务 / Enterprise-grade managed PostgreSQL service |
| 云数据库 SQL Server | TencentDB for SQL Server | 企业级SQL Server托管服务 / Enterprise-grade managed SQL Server service |

#### NoSQL数据库 (NoSQL Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云数据库 Redis | TencentDB for Redis | 兼容Redis协议的内存数据库 / In-memory database compatible with Redis protocol |
| 云数据库 MongoDB | TencentDB for MongoDB | 兼容MongoDB协议的文档数据库 / Document database compatible with MongoDB protocol |
| 云数据库 TcaplusDB | TcaplusDB | 腾讯自研的分布式NoSQL数据库 / Tencent self-developed distributed NoSQL database |
| 时序数据库 CTSDB | Cloud Time Series Database | 分布式可扩展时序数据库 / Distributed scalable time-series database |

#### 数据库工具 (Database Tools)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 数据库传输服务 DTS | Data Transmission Service | 支持多种数据库间的数据迁移和同步 / Supports data migration and synchronization between multiple databases |
| 数据库智能管家 DBbrain | DBbrain | 数据库性能优化和故障诊断工具 / Database performance optimization and troubleshooting tool |

---

### 🛡️ 五、安全 (Security)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 主机安全 CWPP | Cloud Workload Protection | 服务器安全防护和威胁检测 / Server security protection and threat detection |
| Web应用防火墙 WAF | Web Application Firewall | Web应用安全防护 / Web application security protection |
| DDoS防护 | Anti-DDoS | 大流量DDoS攻击防护 / Large traffic DDoS attack protection |
| 云防火墙 CFW | Cloud Firewall | 云环境下的访问控制和流量审计 / Access control and traffic auditing in cloud environment |
| 数据安全中心 DSP | Data Security Protection | 数据安全治理和防护平台 / Data security governance and protection platform |
| 密钥管理系统 KMS | Key Management Service | 密钥安全管理服务 / Key security management service |
| SSL证书 | SSL Certificate | 提供HTTPS加密协议访问 / Provides HTTPS encrypted protocol access |

---

### 🤖 六、人工智能与机器学习 (AI & Machine Learning)

#### 大模型与平台 (Large Models & Platforms)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 腾讯混元大模型 | Tencent Hunyuan | 腾讯全链路自研的通用与多模态大模型 / Tencent's full-stack self-developed general and multimodal large model |
| 腾讯云TI平台 TI-ONE | TI-ONE | 一站式机器学习生态服务平台 / One-stop machine learning ecosystem service platform |
| 腾讯云智能体开发平台 | Agent Development Platform | 基于大模型的智能体构建平台 / Large model-based intelligent agent development platform |

#### 视觉AI (Vision AI)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 人脸识别 | Face Recognition | 人脸检测、分析、识别与搜索服务 / Face detection, analysis, recognition and search service |
| 文字识别 OCR | Optical Character Recognition | 图片文字识别服务 / Image text recognition service |
| 图像理解 | Image Understanding | 图像识别、搜索、标签等能力 / Image recognition, search, tagging and other capabilities |
| 腾讯混元生图 | AI Art | 大模型图像生成及编辑服务 / Large model image generation and editing service |

#### 语音AI (Speech AI)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 语音识别 ASR | Automatic Speech Recognition | 语音转文字服务 / Speech-to-text service |
| 语音合成 TTS | Text to Speech | 高拟真度语音合成服务 / High-fidelity speech synthesis service |

#### NLP与内容安全 (NLP & Content Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| NLP技术 | Natural Language Processing | 自然语言处理能力 / Natural language processing capabilities |
| 机器翻译 TMT | Text Machine Translation | 多语言机器翻译服务 / Multilingual machine translation service |
| 文本内容安全 TMS | Text Moderation System | 文本内容审核服务 / Text content moderation service |
| 图片内容安全 IMS | Image Moderation System | 图片内容审核服务 / Image content moderation service |

---

### 📊 七、大数据与数据治理 (Big Data & Data Governance)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 弹性MapReduce EMR | Elastic MapReduce | 云端Hadoop和Spark服务 / Cloud-based Hadoop and Spark service |
| 云数据仓库 CDW | Cloud Data Warehouse | PB级云端数据仓库 / PB-level cloud data warehouse |
| 流计算 Oceanus | Oceanus | 基于Apache Flink的实时计算服务 / Real-time computing service based on Apache Flink |
| 数据开发治理平台 WeData | WeData | 全链路数据开发治理平台 / Full-link data development and governance platform |
| 数据湖计算 DLC | Data Lake Compute | 无服务器数据湖分析服务 / Serverless data lake analytics service |

---

### 🔄 八、中间件与消息队列 (Middleware & Message Queue)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 消息队列 CKafka | Cloud Kafka | 分布式高吞吐消息队列 / Distributed high-throughput message queue |
| 消息队列 RocketMQ | Cloud RocketMQ | 金融级消息队列服务 / Financial-grade message queue service |
| 消息队列 RabbitMQ | Cloud RabbitMQ | 开源RabbitMQ托管服务 / Open-source RabbitMQ managed service |
| API网关 APIGW | API Gateway | API发布、管理和调用服务 / API publishing, management and calling service |
| 微服务平台 TSF | Tencent Service Framework | 企业级微服务管理平台 / Enterprise-level microservices management platform |

---

### 📱 九、音视频与通信 (Audio/Video & Communication)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 实时音视频 TRTC | Tencent Real-Time Communication | 低延时、高质量的实时音视频服务 / Low-latency, high-quality real-time audio and video service |
| 云直播 CSS | Cloud Streaming Services | 稳定快速的直播接入和分发服务 / Stable and fast live streaming access and distribution service |
| 云点播 VOD | Video on Demand | 音视频存储、转码、播放一体化服务 / Integrated audio and video storage, transcoding and playback service |
| 即时通信 IM | Instant Messaging | 即时通讯能力云服务 / Instant messaging capability cloud service |
| 短信 SMS | Short Message Service | 验证码、通知、营销短信服务 / Verification code, notification and marketing SMS service |

---

### 🛠️ 十、开发与运维 (DevOps)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 腾讯云可观测平台 | Observability Platform | 一站式云产品指标监控告警平台 / One-stop cloud product metrics monitoring and alerting platform |
| 云监控 CM | Cloud Monitor | 云资源可视化监控和告警 / Cloud resource visualization monitoring and alerting |
| 腾讯云命令行工具 TCCLI | Tencent Cloud CLI | 管理腾讯云资源的统一工具 / Unified tool for managing Tencent Cloud resources |
| 基础设施即代码 IaC | Infrastructure as Code | 安全高效管理腾讯云资源的IaC产品 / IaC product for secure and efficient management of Tencent Cloud resources |
| Coding 研发管理平台 | Coding | 一站式DevOps研发管理平台 / One-stop DevOps R&D management platform |

---

## Step 2: Construct Search Queries (构建搜索查询)

根据目标区域构建针对性的搜索查询 / Build targeted search queries based on the target region:

### 2.1 区域选择 (Region Selection)

腾讯云主要提供中国站服务 / Tencent Cloud primarily provides China site services:

| 站点 (Site) | 域名 (Domain) | 适用场景 (Applicable Scenario) |
|------------|--------------|------------------------------|
| **中国站 (China)** | `https://cloud.tencent.com/` | 中国大陆用户，中文文档，人民币计费 / Mainland China users, Chinese documentation, CNY billing |
| **国际站 (International)** | `https://www.tencentcloud.com/` | 海外用户，多语言文档，美元计费 / International users, multilingual documentation, USD billing |

### 2.2 搜索查询格式 (Search Query Formats)

#### 中国站查询格式 (China Site Query Format)
```
Format: "[产品名] [信息类型] site:cloud.tencent.com"
Format: "[Product Name] [Info Type] site:cloud.tencent.com"

Examples:
- "CVM 计费 site:cloud.tencent.com" / "CVM pricing site:cloud.tencent.com"
- "TDSQL 规格 site:cloud.tencent.com" / "TDSQL specifications site:cloud.tencent.com"
- "COS 功能 site:cloud.tencent.com" / "COS features site:cloud.tencent.com"
- "CLB 参数 site:cloud.tencent.com" / "CLB parameters site:cloud.tencent.com"
- "混元大模型 文档 site:cloud.tencent.com" / "Hunyuan documentation site:cloud.tencent.com"
```

#### 国际站查询格式 (International Site Query Format)
```
Format: "tencent cloud [product-name] [information-type] site:tencentcloud.com"

Examples:
- "tencent cloud CVM pricing site:tencentcloud.com"
- "tencent cloud TDSQL specifications site:tencentcloud.com"
- "tencent cloud COS features site:tencentcloud.com"
```

---

## Step 3: Retrieve Product Homepage Information (获取产品首页信息)

首先访问产品官网首页，获取产品的核心营销信息、功能亮点和架构概览 / First visit the product homepage to obtain core marketing information, feature highlights, and architecture overview:

### 3.1 产品首页 URL 构造 (Product Homepage URL Construction)

| 站点 (Site) | 产品首页 URL 模式 (URL Pattern) | 示例 (Example) |
|------------|-------------------------------|---------------|
| **中国站 (China)** | `https://cloud.tencent.com/product/[product-code]` | `https://cloud.tencent.com/product/cvm` |
| **国际站 (International)** | `https://www.tencentcloud.com/products/[product-code]` | `https://www.tencentcloud.com/products/cvm` |

### 3.2 产品首页信息提取清单 (Product Homepage Information Extraction Checklist)

访问产品首页后，提取以下关键信息 / After visiting the product homepage, extract the following key information:

#### 3.2.1 产品核心信息 (Core Product Info)
- **产品 Slogan/标语 (Product Slogan)**: 首页主标题，一句话描述产品核心价值 / Main title on homepage, one-sentence description of core product value
- **产品定位 (Product Positioning)**: 产品类别和主要用途 / Product category and main purpose
- **核心卖点 (Core Selling Points)**: 首页突出展示的 3-5 个主要优势 / 3-5 main advantages highlighted on the homepage

#### 3.2.2 功能特性 (Feature Highlights)
- **功能模块卡片 (Feature Module Cards)**: 首页展示的功能模块（通常以图标+标题+描述形式）/ Feature modules displayed on homepage (usually in icon + title + description format)
- **特性对比 (Feature Comparison)**: 与竞品或自建方案的对比优势 / Comparison advantages over competitors or self-built solutions
- **应用场景图标 (Use Case Icons)**: 支持的主要应用场景 / Main supported application scenarios

#### 3.2.3 产品架构 (Architecture)
- **架构图 (Architecture Diagram)**: 产品技术架构示意图 / Product technical architecture diagram
- **核心组件 (Core Components)**: 产品包含的主要组件或服务 / Main components or services included in the product
- **工作流程 (Workflow)**: 产品使用流程图 / Product usage workflow diagram

#### 3.2.4 客户案例与认证 (Social Proof)
- **客户 Logo (Customer Logos)**: 使用该产品的知名企业 / Well-known enterprises using the product
- **行业覆盖 (Industry Coverage)**: 支持的主要行业 / Main supported industries
- **认证标识 (Certification Badges)**: 安全合规认证标志 / Security compliance certification marks

#### 3.2.5 入门与定价入口 (CTA & Pricing)
- **免费试用 (Free Trial)**: 是否有免费试用入口 / Whether free trial entry is available
- **定价链接 (Pricing Link)**: 定价页面的直接链接 / Direct link to pricing page
- **文档入口 (Documentation Entry)**: 帮助文档的快速链接 / Quick link to help documentation

---

## Step 4: Search Official Documentation (搜索官方文档)

在获取产品首页信息后，结合以下官方文档来源进行深度信息检索 / After obtaining product homepage information, combine with the following official documentation sources for in-depth information retrieval:

### 4.1 文档中心域名对照 (Documentation Center Domain Comparison)

| 资源类型 (Resource Type) | 中国站 (China Site) | 国际站 (International Site) |
|-------------------------|-------------------|---------------------------|
| **文档中心 (Documentation Center)** | `https://cloud.tencent.com/document/product/` | `https://www.tencentcloud.com/document/product/` |
| **API中心 (API Center)** | `https://cloud.tencent.com/document/api/` | `https://www.tencentcloud.com/document/api/` |
| **SDK中心 (SDK Center)** | `https://cloud.tencent.com/document/sdk/` | `https://www.tencentcloud.com/document/sdk/` |

### 4.2 产品概述文档来源 (Product Overview Documentation Sources)

| Source Type | URL Pattern | Content Type |
|-------------|-------------|--------------|
| **产品简介 (Product Introduction)** | `/document/product/[product-id]/[product-id].md` | Product introduction / 产品介绍 |
| **产品优势 (Product Advantages)** | `/document/product/[product-id]/advantages.md` | Product advantages / 产品优势 |
| **应用场景 (Use Cases)** | `/document/product/[product-id]/scenarios.md` | Use cases / 应用场景 |
| **产品功能 (Product Features)** | `/document/product/[product-id]/features.md` | Features overview / 功能概览 |

### 4.3 产品计费文档来源 (Product Pricing Documentation Sources)

| Source Type | URL Pattern | Content Type |
|-------------|-------------|--------------|
| **计费概述 (Billing Overview)** | `/document/product/[product-id]/billing.md` | Billing overview / 计费概览 |
| **购买指南 (Purchase Guide)** | `/document/product/[product-id]/purchase.md` | Purchase guide / 购买指南 |
| **价格总览 (Pricing Overview)** | `https://buy.cloud.tencent.com/price/` | Pricing calculator / 价格计算器 |

### 4.4 操作指南文档来源 (Operation Guide Documentation Sources)

| Source Type | URL Pattern | Content Type |
|-------------|-------------|--------------|
| **快速入门 (Quick Start)** | `/document/product/[product-id]/quickstart.md` | Quick start guide / 快速入门指南 |
| **操作指南 (Operation Guide)** | `/document/product/[product-id]/operation/` | Operation guides / 操作指南 |
| **最佳实践 (Best Practices)** | `/document/product/[product-id]/best-practices.md` | Best practices / 最佳实践 |

### 4.5 API参考文档来源 (API Reference Documentation Sources)

| Source Type | URL Pattern | Content Type |
|-------------|-------------|--------------|
| **API概览 (API Overview)** | `/document/api/[product-id]/[version]/overview.md` | API overview / API概览 |
| **API列表 (API List)** | `/document/api/[product-id]/[version]/api-list.md` | API list / API列表 |
| **SDK下载 (SDK Download)** | `/document/sdk/` | SDK downloads / SDK下载 |

---

## Step 5: Extract Key Information from Documentation (从文档提取关键信息)

基于腾讯云标准文档架构，从以下文档章节提取和组织信息 / Based on Tencent Cloud standard documentation architecture, extract and organize information from the following document sections:

### 5.1 产品概述 (Product Overview)
- **产品简介 (Product Introduction)**: 产品定义和核心价值主张 / Product definition and core value proposition
- **产品架构 (Product Architecture)**: 技术架构和组件关系 / Technical architecture and component relationships
- **功能特性 (Features & Capabilities)**: 主要功能模块和特性 / Main functional modules and features
- **应用场景 (Use Cases)**: 典型应用案例 / Typical application cases
- **产品优势 (Product Advantages)**: 与竞品对比的优势 / Advantages compared to competitors

### 5.2 产品计费 (Product Pricing)
- **计费模式 (Billing Models)**: 包年包月、按量计费等 / Subscription, pay-as-you-go, etc.
- **计费项 (Billable Items)**: 各组件的计费说明 / Billing description for each component
- **价格详情 (Pricing Details)**: 不同规格的价格 / Prices for different specifications
- **免费额度 (Free Tier)**: 免费试用和额度 / Free trial and quotas
- **购买指南 (Purchase Guide)**: 购买流程和注意事项 / Purchase process and notes

### 5.3 快速入门 (Quick Start)
- **使用限制 (Usage Limits)**: 配额和限制说明 / Quotas and limitation descriptions
- **准备工作 (Prerequisites)**: 前置条件和环境准备 / Prerequisites and environment preparation
- **创建步骤 (Creation Steps)**: 快速创建流程 / Quick creation process
- **连接方式 (Connection Methods)**: 如何连接和使用 / How to connect and use

### 5.4 操作指南 (Operation Guide)
- **实例管理 (Instance Management)**: 创建、启动、停止、释放 / Create, start, stop, release
- **配置管理 (Configuration Management)**: 参数设置和修改 / Parameter settings and modifications
- **监控告警 (Monitoring & Alerting)**: 监控指标和告警设置 / Monitoring metrics and alert settings
- **备份恢复 (Backup & Recovery)**: 备份策略和恢复操作 / Backup policies and recovery operations

### 5.5 开发参考 (Development Reference)
- **API说明 (API Documentation)**: API调用方式和认证 / API calling methods and authentication
- **SDK支持 (SDK Support)**: 各语言SDK下载和使用 / SDK download and usage for various languages
- **CLI工具 (CLI Tools)**: 命令行工具使用 / Command line tool usage
- **错误码 (Error Codes)**: 常见错误和解决方法 / Common errors and solutions

---

## Step 6: Integrate and Synthesize Information (整合和综合信息)

综合产品首页信息 (Step 3) 和官方文档信息 (Step 5)，进行信息融合和交叉验证 / Integrate product homepage information (Step 3) and official documentation information (Step 5), perform information fusion and cross-verification:

### 6.1 信息融合策略 (Information Integration Strategy)

| 信息类型 (Info Type) | 产品首页 (Homepage) | 官方文档 (Documentation) | 融合方式 (Integration Method) |
|---------------------|-------------------|------------------------|------------------------------|
| **产品定位 (Product Positioning)** | 营销角度 / Marketing perspective | 技术角度 / Technical perspective | 以文档为准，首页补充亮点 / Use documentation as standard, supplement with homepage highlights |
| **功能特性 (Features)** | 核心功能 / Core features | 详细功能 / Detailed features | 合并去重，文档补充细节 / Merge and deduplicate, supplement details from documentation |
| **应用场景 (Use Cases)** | 主要场景 / Main scenarios | 详细场景 / Detailed scenarios | 整合为完整场景列表 / Integrate into complete scenario list |
| **定价信息 (Pricing)** | 定价入口 / Pricing entry | 详细计费 / Detailed billing | 以文档详细计费为准 / Use detailed billing from documentation |
| **技术参数 (Technical Parameters)** | 关键指标 / Key metrics | 完整参数 / Complete parameters | 以文档完整参数为准 / Use complete parameters from documentation |

### 6.2 冲突解决原则 (Conflict Resolution Principles)

当产品首页与文档信息冲突时 / When product homepage conflicts with documentation information:
1. **技术参数冲突 (Technical Parameter Conflict)**: 以官方文档为准 / Use official documentation as standard
2. **功能描述冲突 (Feature Description Conflict)**: 以文档为准，首页可能简化 / Use documentation as standard, homepage may be simplified
3. **定价信息冲突 (Pricing Conflict)**: 以定价页面为准，注意时效性 / Use pricing page as standard, note timeliness
4. **版本信息冲突 (Version Conflict)**: 以文档为准 / Use documentation as standard

---

## Step 7: Present Results (呈现结果)

基于 Step 3 和 Step 5 提取的信息，按照以下综合结构格式化输出 / Based on information extracted from Step 3 and Step 5, format output according to the following comprehensive structure:

```markdown
# [产品名称 / Product Name] - [产品英文名 / English Name]

> [一句话产品描述 / One-line product description]

---

## 一、产品概述 (Product Overview)

### 1.1 产品简介 (Product Introduction)
**产品定位 (Product Positioning)**: [来自首页的产品定位 + 来自文档的技术定义] / [Product positioning from homepage + technical definition from documentation]

**核心价值主张 (Core Value Proposition)**: [首页主标语/Slogan] / [Main slogan from homepage]

**产品描述 (Product Description)**: [来自文档的详细产品描述] / [Detailed product description from documentation]

### 1.2 功能特性 (Features & Capabilities)
**首页核心卖点 (Homepage Core Selling Points)**:
- [卖点1 / Selling Point 1]
- [卖点2 / Selling Point 2]
- [卖点3 / Selling Point 3]

**详细功能列表 (Detailed Feature List)**:
| 功能模块 (Feature Module) | 功能描述 (Description) | 信息来源 (Source) |
|--------------------------|----------------------|------------------|
| [功能1 / Feature 1] | [描述 / Description] | 首页/文档 (Homepage/Doc) |
| [功能2 / Feature 2] | [描述 / Description] | 首页/文档 (Homepage/Doc) |

### 1.3 应用场景 (Use Cases)
- **[场景1 / Scenario 1]**: [描述 / Description]
- **[场景2 / Scenario 2]**: [描述 / Description]

---

## 二、产品计费 (Product Pricing)

### 2.1 计费项 (Billable Items)
| 计费组件 (Component) | 计费说明 (Description) |
|---------------------|----------------------|
| [组件1 / Component 1] | [说明 / Description] |
| [组件2 / Component 2] | [说明 / Description] |

### 2.2 计费方式 (Billing Methods)
| 计费方式 (Method) | 说明 (Description) | 适用场景 (Scenario) |
|------------------|-------------------|-------------------|
| 包年包月 (Subscription) | [说明 / Description] | [场景 / Scenario] |
| 按量付费 (Pay-as-you-go) | [说明 / Description] | [场景 / Scenario] |

### 2.3 价格参考 (Pricing Reference)
- **起步价格 (Starting Price)**: [价格 / Price]
- **免费额度 (Free Tier)**: [是/否/详情 / Yes/No/Details]
- **计费计算器 (Price Calculator)**: [链接 / Link]

---

## 三、快速入门 (Quick Start)

### 3.1 使用限制 (Usage Limits)
| 限制项 (Limit Item) | 限制值 (Limit Value) |
|--------------------|---------------------|
| [限制1 / Limit 1] | [值 / Value] |

### 3.2 入门步骤 (Getting Started Steps)
1. [步骤1 / Step 1]
2. [步骤2 / Step 2]
3. [步骤3 / Step 3]

---

## 四、操作指南 (Operation Guide)

### 4.1 资源管理 (Resource Management)
| 操作 (Operation) | 说明 (Description) |
|-----------------|-------------------|
| 创建 (Create) | [说明 / Description] |
| 启动/停止 (Start/Stop) | [说明 / Description] |
| 释放 (Release) | [说明 / Description] |

---

## 五、开发参考 (Development Reference)

### 5.1 API概览 (API Overview)
- **认证方式 (Authentication)**: [SecretId/SecretKey]
- **请求地址 (Endpoint)**: [Endpoint URL]

### 5.2 SDK支持 (SDK Support)
| 语言 (Language) | SDK下载 (Download) |
|----------------|-------------------|
| Java | [链接 / Link] |
| Python | [链接 / Link] |
| Go | [链接 / Link] |

---

## 六、相关资源 (Related Resources)

### 文档链接 (Documentation Links)
- [产品首页 (Product Homepage)](url)
- [帮助文档 (Documentation)](url)
- [API参考 (API Reference)](url)
- [定价详情 (Pricing Details)](url)

### 相关产品 (Related Products)
- [产品1 / Product 1]: [关系说明 / Relationship description]
- [产品2 / Product 2]: [关系说明 / Relationship description]
```

---

## Tips for Better Results (获取更好结果的建议)

1. **使用英文产品名 (Use English Product Names)**: 在搜索API文档时使用英文产品名效果更好 / Better results when searching API documentation using English product names
2. **包含"文档"或"API" (Include "Documentation" or "API")**: 用于获取技术细节 / Use for obtaining technical details
3. **包含"计费"或"价格" (Include "Billing" or "Price")**: 用于获取成本信息 / Use for obtaining cost information
4. **检查多个来源 (Check Multiple Sources)**: 产品页面、文档和API参考 / Product pages, documentation, and API references
5. **注意地域可用性 (Note Regional Availability)**: 某些功能因地域而异 / Some features vary by region

## Limitations (限制)

- 无法访问需要登录的内部或认证文档 / Cannot access internal or authenticated documents requiring login
- 价格可能不反映实时变化 / Prices may not reflect real-time changes
- 某些企业特定功能可能未公开记录 / Some enterprise-specific features may not be publicly documented
- API速率限制和配额不总是公开可用 / API rate limits and quotas are not always publicly available
