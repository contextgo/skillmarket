#!/usr/bin/env python3
"""
股票数据采集模块
封装 akshare 数据源，提供重试机制和错误处理
"""

import json
import time
import logging
from typing import Optional, Dict, List, Any
from datetime import datetime, timedelta

try:
    import akshare as ak
    import pandas as pd
    AKSHARE_AVAILABLE = True
except ImportError:
    AKSHARE_AVAILABLE = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_DELAY = 2


def retry_on_failure(func):
    """重试装饰器"""
    def wrapper(*args, **kwargs):
        for attempt in range(MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.warning(f"{func.__name__} 第{attempt+1}次尝试失败: {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                else:
                    logger.error(f"{func.__name__} 全部重试失败")
                    return None
    return wrapper


@retry_on_failure
def get_realtime_quote(stock_code: str) -> Optional[Dict[str, Any]]:
    """
    获取实时行情
    Args:
        stock_code: 股票代码 (如 '000001' 或 '000001.SZ')
    Returns:
        包含实时行情的字典
    """
    if not AKSHARE_AVAILABLE:
        return _mock_realtime_quote(stock_code)
    
    # 标准化股票代码
    code = normalize_code(stock_code)
    
    try:
        df = ak.stock_zh_a_spot_em()
        row = df[df['代码'] == stock_code]
        if row.empty:
            logger.warning(f"未找到股票 {stock_code}")
            return None
        
        r = row.iloc[0]
        return {
            "stock_code": stock_code,
            "name": r.get('名称', ''),
            "current_price": float(r.get('最新价', 0)) if pd.notna(r.get('最新价')) else None,
            "change_pct": float(r.get('涨跌幅', 0)) if pd.notna(r.get('涨跌幅')) else 0,
            "volume": float(r.get('成交量', 0)) if pd.notna(r.get('成交量')) else 0,
            "amount": float(r.get('成交额', 0)) if pd.notna(r.get('成交额')) else 0,
            "high": float(r.get('最高', 0)) if pd.notna(r.get('最高')) else None,
            "low": float(r.get('最低', 0)) if pd.notna(r.get('最低')) else None,
            "open": float(r.get('今开', 0)) if pd.notna(r.get('今开')) else None,
            "prev_close": float(r.get('昨收', 0)) if pd.notna(r.get('昨收')) else None,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"获取实时行情失败 {stock_code}: {e}")
        return _mock_realtime_quote(stock_code)


@retry_on_failure
def get_historical_data(stock_code: str, days: int = 60) -> Optional[pd.DataFrame]:
    """
    获取历史K线数据
    Args:
        stock_code: 股票代码
        days: 获取天数
    Returns:
        DataFrame，包含 date, open, high, low, close, volume
    """
    if not AKSHARE_AVAILABLE:
        return _mock_historical_data(stock_code, days)
    
    code = normalize_code(stock_code)
    end_date = datetime.now().strftime('%Y%m%d')
    start_date = (datetime.now() - timedelta(days=days*2)).strftime('%Y%m%d')
    
    try:
        df = ak.stock_zh_a_hist(symbol=stock_code, period="daily", 
                                 start_date=start_date, end_date=end_date, adjust="qfq")
        df = df[['日期', '开盘', '最高', '最低', '收盘', '成交量']].copy()
        df.columns = ['date', 'open', 'high', 'low', 'close', 'volume']
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').tail(days)
        return df
    except Exception as e:
        logger.error(f"获取历史数据失败 {stock_code}: {e}")
        return _mock_historical_data(stock_code, days)


@retry_on_failure
def get_financial_data(stock_code: str) -> Optional[Dict[str, Any]]:
    """
    获取基本面数据 (PE/PB/ROE/营收/净利润/毛利率/负债率/股息率)
    """
    if not AKSHARE_AVAILABLE:
        return _mock_financial_data(stock_code)
    
    result = {}
    
    # 获取主要财务指标
    try:
        df = ak.stock_individual_info_em(symbol=stock_code)
        info = {row['item']: row['value'] for _, row in df.iterrows()}
        result['industry'] = info.get('行业', '')
    except Exception as e:
        logger.warning(f"获取行业信息失败 {stock_code}: {e}")
        result['industry'] = ''
    
    # 获取估值数据
    try:
        df = ak.stock_a_indicator_lg(symbol=stock_code)
        if not df.empty:
            latest = df.iloc[-1]
            result['pe'] = float(latest.get('市盈率(TTM)', 0)) if pd.notna(latest.get('市盈率(TTM)')) else None
            result['pb'] = float(latest.get('市净率(MRQ)', 0)) if pd.notna(latest.get('市净率(MRQ)')) else None
            result['roe'] = float(latest.get('净资产收益率(ROE)', 0)) if pd.notna(latest.get('净资产收益率(ROE)')) else None
            result['gross_margin'] = float(latest.get('销售毛利率', 0)) if pd.notna(latest.get('销售毛利率')) else None
            result['debt_ratio'] = float(latest.get('资产负债率', 0)) if pd.notna(latest.get('资产负债率')) else None
    except Exception as e:
        logger.warning(f"获取估值数据失败 {stock_code}: {e}")
    
    # 获取利润表数据 (营收/净利润增长)
    try:
        df = ak.stock_financial_analysis_indicator(symbol=stock_code, start_year=str(datetime.now().year-3))
        if not df.empty:
            latest = df.iloc[-1]
            result['revenue_growth'] = float(latest.get('营业总收入增长率', 0)) if pd.notna(latest.get('营业总收入增长率')) else None
            result['profit_growth'] = float(latest.get('净利润增长率', 0)) if pd.notna(latest.get('净利润增长率')) else None
    except Exception as e:
        logger.warning(f"获取增长数据失败 {stock_code}: {e}")
    
    # 获取股息率
    try:
        df = ak.stock_dividend_detail(symbol=stock_code)
        if not df.empty and '分红' in df.columns:
            last_dividend = df.iloc[-1]
            # 简化处理，实际应计算股息率
            result['dividend_yield'] = None  # 需要结合股价计算
    except Exception as e:
        logger.warning(f"获取股息数据失败 {stock_code}: {e}")
    
    return result


@retry_on_failure
def get_market_cap(stock_code: str) -> Optional[Dict[str, Any]]:
    """获取市值数据"""
    if not AKSHARE_AVAILABLE:
        return {"total_market_cap": 50000000000, "float_market_cap": 45000000000}
    
    try:
        df = ak.stock_a_indicator_lg(symbol=stock_code)
        if not df.empty:
            latest = df.iloc[-1]
            return {
                "total_market_cap": float(latest.get('总市值', 0)) if pd.notna(latest.get('总市值')) else None,
                "float_market_cap": float(latest.get('流通市值', 0)) if pd.notna(latest.get('流通市值')) else None
            }
    except Exception as e:
        logger.warning(f"获取市值失败 {stock_code}: {e}")
    return {"total_market_cap": None, "float_market_cap": None}


@retry_on_failure
def get_north_money(stock_code: str) -> Optional[float]:
    """获取北向资金持股数据"""
    if not AKSHARE_AVAILABLE:
        return _mock_financial_data(stock_code).get('north_money', 1000000000)
    
    try:
        # 沪深港通持股
        df = ak.stock_hsgt_north_hold_stock_em(symbol="北向资金")
        row = df[df['代码'] == stock_code]
        if not row.empty:
            return float(row.iloc[0].get('持股数量', 0))
    except Exception as e:
        logger.warning(f"获取北向资金失败 {stock_code}: {e}")
    return None


def get_listing_date(stock_code: str) -> Optional[str]:
    """获取上市日期"""
    if not AKSHARE_AVAILABLE:
        return (datetime.now() - timedelta(days=365*5)).strftime('%Y-%m-%d')
    
    try:
        df = ak.stock_individual_info_em(symbol=stock_code)
        for _, row in df.iterrows():
            if row['item'] == '上市时间':
                return row['value']
    except Exception as e:
        logger.warning(f"获取上市日期失败 {stock_code}: {e}")
    return None


def refresh_pool_data(stock_codes: List[str]) -> List[Dict[str, Any]]:
    """
    批量刷新股票池数据
    Args:
        stock_codes: 股票代码列表
    Returns:
        更新后的股票数据列表
    """
    results = []
    for code in stock_codes:
        try:
            quote = get_realtime_quote(code)
            if quote:
                quote.update(get_financial_data(code) or {})
                quote.update(get_market_cap(code) or {})
                quote['north_money'] = get_north_money(code)
                results.append(quote)
        except Exception as e:
            logger.error(f"刷新股票 {code} 失败: {e}")
        time.sleep(0.3)  # 避免请求过快
    return results


def normalize_code(code: str) -> str:
    """标准化股票代码"""
    code = code.strip().upper()
    if not code.endswith(('.SH', '.SZ', '.BJ')):
        if code.startswith('6'):
            code = f"{code}.SH"
        elif code.startswith(('0', '3')):
            code = f"{code}.SZ"
        elif code.startswith('8') or code.startswith('4'):
            code = f"{code}.BJ"
    return code


# Mock 数据用于无网络/无akshare环境
def _mock_realtime_quote(stock_code: str) -> Dict[str, Any]:
    return {
        "stock_code": stock_code,
        "name": f"股票{stock_code}",
        "current_price": 10.5,
        "change_pct": 1.2,
        "volume": 50000000,
        "amount": 525000000,
        "high": 10.8,
        "low": 10.2,
        "open": 10.3,
        "prev_close": 10.37,
        "timestamp": datetime.now().isoformat()
    }


def _mock_historical_data(stock_code: str, days: int) -> pd.DataFrame:
    dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
    import numpy as np
    np.random.seed(hash(stock_code) % 2**32)
    base = 10.0
    prices = base + np.cumsum(np.random.randn(days) * 0.2)
    return pd.DataFrame({
        'date': dates,
        'open': prices + np.random.randn(days) * 0.1,
        'high': prices + np.abs(np.random.randn(days) * 0.2),
        'low': prices - np.abs(np.random.randn(days) * 0.2),
        'close': prices,
        'volume': np.random.randint(1000000, 10000000, days)
    })


def _mock_financial_data(stock_code: str) -> Dict[str, Any]:
    return {
        "industry": "银行",
        "pe": 8.5,
        "pb": 0.9,
        "roe": 12.5,
        "revenue_growth": 5.2,
        "profit_growth": 3.8,
        "gross_margin": 45.0,
        "debt_ratio": 88.5,
        "dividend_yield": 3.5,
        "north_money": 1000000000
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        code = sys.argv[1]
        print(json.dumps(get_realtime_quote(code), ensure_ascii=False, indent=2))
    else:
        # 测试数据采集
        print("测试实时行情:")
        print(json.dumps(get_realtime_quote("000001"), ensure_ascii=False, indent=2))
