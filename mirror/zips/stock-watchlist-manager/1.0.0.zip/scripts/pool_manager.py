#!/usr/bin/env python3
"""
股票池管理器核心模块
基于 SQLite 的四级池 CRUD 操作与数据持久化
"""

import json
import sqlite3
import logging
from datetime import datetime
from typing import Optional, Dict, List, Any
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DEFAULT_DB_PATH = "./data/stock_pools.db"


class StockPoolManager:
    """股票池管理器"""
    
    def __init__(self, db_path: str = DEFAULT_DB_PATH):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self):
        """初始化数据库表"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stocks (
                stock_code TEXT PRIMARY KEY,
                stock_name TEXT NOT NULL,
                pool_level INTEGER DEFAULT 1,
                industry TEXT DEFAULT '',
                -- 行情
                current_price REAL,
                change_pct REAL,
                volume REAL,
                amount REAL,
                high_60d REAL,
                low_60d REAL,
                -- 市值
                total_market_cap REAL,
                float_market_cap REAL,
                -- 基本面
                pe REAL,
                pb REAL,
                roe REAL,
                revenue_growth REAL,
                profit_growth REAL,
                gross_margin REAL,
                debt_ratio REAL,
                dividend_yield REAL,
                -- 资金
                north_money REAL,
                -- 持仓 (四级池)
                plan_buy_price REAL,
                plan_buy_qty INTEGER,
                actual_buy_price REAL,
                cost_basis REAL,
                current_holding INTEGER,
                floating_pnl REAL,
                -- 风控
                stop_loss REAL,
                buy_point REAL,
                target1 REAL,
                target2 REAL,
                -- 仓位建议
                position_suggestion REAL,
                -- 分析
                technical_pattern TEXT,
                catalyst_event TEXT,
                risk_warning TEXT,
                -- 备注
                entry_reason TEXT,
                attention_level INTEGER DEFAULT 3,
                institution_rating TEXT,
                valuation_range TEXT,
                safety_margin_price REAL,
                -- 状态
                status TEXT DEFAULT 'active',
                elimination_reason TEXT,
                update_date TEXT,
                created_date TEXT
            )
        ''')
        
        # 创建索引
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_pool_level ON stocks(pool_level)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_status ON stocks(status)')
        
        conn.commit()
        conn.close()
        logger.info(f"数据库初始化完成: {self.db_path}")
    
    def _get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def add_stock(self, pool_level: int, stock_data: Dict[str, Any], 
                  reason: str = None) -> Dict[str, Any]:
        """
        添加股票到指定池
        Args:
            pool_level: 池等级 (1-4)
            stock_data: 股票数据字典
            reason: 入选理由
        Returns:
            操作结果
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # 检查是否已存在
        cursor.execute("SELECT stock_code FROM stocks WHERE stock_code = ?", 
                      (stock_data['stock_code'],))
        exists = cursor.fetchone()
        
        if exists:
            # 已存在，更新池级别
            cursor.execute('''
                UPDATE stocks SET 
                    pool_level = ?, 
                    status = 'active',
                    elimination_reason = NULL,
                    update_date = ?
                WHERE stock_code = ?
            ''', (pool_level, now, stock_data['stock_code']))
            msg = f"股票 {stock_data['stock_code']} 已存在，更新到池{pool_level}"
        else:
            # 新增
            cursor.execute('''
                INSERT INTO stocks (
                    stock_code, stock_name, pool_level, industry, entry_reason,
                    current_price, change_pct, volume, total_market_cap,
                    pe, pb, roe, revenue_growth, profit_growth, gross_margin,
                    debt_ratio, dividend_yield, north_money,
                    status, update_date, created_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                stock_data.get('stock_code'),
                stock_data.get('stock_name', ''),
                pool_level,
                stock_data.get('industry', ''),
                reason or stock_data.get('entry_reason', ''),
                stock_data.get('current_price'),
                stock_data.get('change_pct'),
                stock_data.get('volume'),
                stock_data.get('total_market_cap'),
                stock_data.get('pe'),
                stock_data.get('pb'),
                stock_data.get('roe'),
                stock_data.get('revenue_growth'),
                stock_data.get('profit_growth'),
                stock_data.get('gross_margin'),
                stock_data.get('debt_ratio'),
                stock_data.get('dividend_yield'),
                stock_data.get('north_money'),
                'active',
                now,
                now
            ))
            msg = f"股票 {stock_data['stock_code']} 已添加到池{pool_level}"
        
        conn.commit()
        conn.close()
        
        return {"status": "success", "message": msg, "stock_code": stock_data['stock_code']}
    
    def remove_stock(self, stock_code: str, elimination_reason: str = None) -> Dict[str, Any]:
        """
        移除股票 (标记为已淘汰)
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        reason = elimination_reason or "手动移除"
        
        cursor.execute('''
            UPDATE stocks SET 
                status = 'eliminated',
                elimination_reason = ?,
                update_date = ?
            WHERE stock_code = ?
        ''', (reason, now, stock_code))
        
        affected = cursor.rowcount
        conn.commit()
        conn.close()
        
        if affected > 0:
            return {"status": "success", "message": f"股票 {stock_code} 已移除", "reason": reason}
        else:
            return {"status": "error", "message": f"股票 {stock_code} 不存在"}
    
    def update_stock(self, stock_code: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新股票信息
        """
        if not updates:
            return {"status": "error", "message": "无更新内容"}
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        updates['update_date'] = now
        
        # 构建更新语句
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [stock_code]
        
        cursor.execute(f'UPDATE stocks SET {set_clause} WHERE stock_code = ?', values)
        
        affected = cursor.rowcount
        conn.commit()
        conn.close()
        
        if affected > 0:
            return {"status": "success", "message": f"股票 {stock_code} 已更新", "updates": updates}
        else:
            return {"status": "error", "message": f"股票 {stock_code} 不存在"}
    
    def move_stock(self, stock_code: str, to_pool: int,
                   additional_updates: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        移动股票到其他池
        Args:
            stock_code: 股票代码
            to_pool: 目标池等级
            additional_updates: 额外更新字段
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # 获取当前池
        cursor.execute("SELECT pool_level FROM stocks WHERE stock_code = ?", (stock_code,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {"status": "error", "message": f"股票 {stock_code} 不存在"}
        
        from_pool = row[0]
        
        # 更新池级别
        updates = {'pool_level': to_pool, 'update_date': now, 'status': 'active', 'elimination_reason': None}
        if additional_updates:
            updates.update(additional_updates)
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [stock_code]
        
        cursor.execute(f'UPDATE stocks SET {set_clause} WHERE stock_code = ?', values)
        conn.commit()
        conn.close()
        
        return {
            "status": "success",
            "message": f"股票 {stock_code} 从池{from_pool}移动到池{to_pool}",
            "from_pool": from_pool,
            "to_pool": to_pool
        }
    
    def query_pool(self, pool_level: int, include_eliminated: bool = False) -> List[Dict[str, Any]]:
        """
        查询指定池的所有股票
        """
        conn = self._get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        if include_eliminated:
            cursor.execute("SELECT * FROM stocks WHERE pool_level = ? ORDER BY update_date DESC", (pool_level,))
        else:
            cursor.execute("SELECT * FROM stocks WHERE pool_level = ? AND status = 'active' ORDER BY update_date DESC", (pool_level,))
        
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
    
    def query_stock(self, stock_code: str) -> Optional[Dict[str, Any]]:
        """查询单只股票详情"""
        conn = self._get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM stocks WHERE stock_code = ?", (stock_code,))
        row = cursor.fetchone()
        conn.close()
        
        return dict(row) if row else None
    
    def get_all_pools(self) -> Dict[int, List[Dict[str, Any]]]:
        """获取所有池的股票"""
        result = {}
        for level in range(1, 5):
            result[level] = self.query_pool(level)
        return result
    
    def get_pool_stats(self) -> Dict[str, Any]:
        """获取各池统计"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        stats = {}
        for level in range(1, 5):
            cursor.execute('''
                SELECT COUNT(*) as count FROM stocks 
                WHERE pool_level = ? AND status = 'active'
            ''', (level,))
            stats[f"pool_{level}_count"] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM stocks WHERE status = 'eliminated'")
        stats["eliminated_count"] = cursor.fetchone()[0]
        
        conn.close()
        return stats
    
    def record_operation(self, stock_code: str, operation: str, details: Dict[str, Any]) -> Dict[str, Any]:
        """
        记录操作历史
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stock_code TEXT,
                operation TEXT,
                details TEXT,
                created_at TEXT
            )
        ''')
        
        cursor.execute('''
            INSERT INTO operations (stock_code, operation, details, created_at)
            VALUES (?, ?, ?, ?)
        ''', (stock_code, operation, json.dumps(details, ensure_ascii=False), now))
        
        conn.commit()
        conn.close()
        
        return {"status": "success", "message": f"操作已记录: {operation}"}


if __name__ == "__main__":
    import sys
    
    manager = StockPoolManager()
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "query":
            pool = int(sys.argv[2]) if len(sys.argv) > 2 else 1
            print(json.dumps(manager.query_pool(pool), ensure_ascii=False, indent=2))
        
        elif cmd == "stats":
            print(json.dumps(manager.get_pool_stats(), ensure_ascii=False, indent=2))
        
        elif cmd == "all":
            print(json.dumps(manager.get_all_pools(), ensure_ascii=False, indent=2))
    else:
        # 测试
        print("测试添加股票:")
        print(json.dumps(manager.add_stock(1, {
            "stock_code": "000001",
            "stock_name": "平安银行",
            "industry": "银行",
            "total_market_cap": 250000000000,
            "pe": 5.2,
            "pb": 0.7
        }, reason="银行龙头，低估值"), ensure_ascii=False, indent=2))
        
        print("\n查询池1:")
        print(json.dumps(manager.query_pool(1), ensure_ascii=False, indent=2))
        
        print("\n统计:")
        print(json.dumps(manager.get_pool_stats(), ensure_ascii=False, indent=2))
