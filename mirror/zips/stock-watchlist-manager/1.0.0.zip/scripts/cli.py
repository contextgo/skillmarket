#!/usr/bin/env python3
"""
股票池管理命令行入口
将自然语言指令映射为具体操作，输出JSON结果供智能体解析
"""

import json
import argparse
import logging
from typing import Dict, Any, Optional

from pool_manager import StockPoolManager
from data_fetcher import get_realtime_quote, get_financial_data, refresh_pool_data
from screener import StockScreener
from alerter import StockAlerter
from review import StockReviewer

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def cmd_add(args, manager: StockPoolManager) -> Dict[str, Any]:
    """添加股票到池"""
    # 获取股票数据
    stock_data = {
        "stock_code": args.code,
        "stock_name": args.name or args.code
    }
    
    # 如果指定了刷新数据
    if args.refresh:
        quote = get_realtime_quote(args.code)
        if quote:
            stock_data.update(quote)
        
        financial = get_financial_data(args.code)
        if financial:
            stock_data.update(financial)
    
    return manager.add_stock(args.pool, stock_data, reason=args.reason)


def cmd_remove(args, manager: StockPoolManager) -> Dict[str, Any]:
    """移除股票"""
    return manager.remove_stock(args.code, elimination_reason=args.reason)


def cmd_move(args, manager: StockPoolManager) -> Dict[str, Any]:
    """移动股票到其他池"""
    updates = {}
    
    # 处理额外参数
    if args.buy_point:
        updates['buy_point'] = float(args.buy_point)
    if args.stop_loss:
        updates['stop_loss'] = float(args.stop_loss)
    if args.target1:
        updates['target1'] = float(args.target1)
    if args.target2:
        updates['target2'] = float(args.target2)
    if args.plan_price:
        updates['plan_buy_price'] = float(args.plan_price)
    if args.plan_qty:
        updates['plan_buy_qty'] = int(args.plan_qty)
    if args.position:
        updates['position_suggestion'] = float(args.position)
    if args.technical:
        updates['technical_pattern'] = args.technical
    if args.catalyst:
        updates['catalyst_event'] = args.catalyst
    
    return manager.move_stock(args.code, args.to, additional_updates=updates if updates else None)


def cmd_update(args, manager: StockPoolManager) -> Dict[str, Any]:
    """更新股票信息"""
    updates = {}
    
    # 解析更新字段
    if args.price:
        updates['current_price'] = float(args.price)
    if args.change:
        updates['change_pct'] = float(args.change)
    if args.pe:
        updates['pe'] = float(args.pe)
    if args.roe:
        updates['roe'] = float(args.roe)
    if args.stop_loss:
        updates['stop_loss'] = float(args.stop_loss)
    if args.buy_point:
        updates['buy_point'] = float(args.buy_point)
    if args.target1:
        updates['target1'] = float(args.target1)
    if args.target2:
        updates['target2'] = float(args.target2)
    if args.cost:
        updates['cost_basis'] = float(args.cost)
    if args.holding:
        updates['current_holding'] = int(args.holding)
    if args.attention:
        updates['attention_level'] = int(args.attention)
    if args.notes:
        updates['entry_reason'] = args.notes
    
    return manager.update_stock(args.code, updates)


def cmd_query(args, manager: StockPoolManager) -> Dict[str, Any]:
    """查询池"""
    if args.code:
        # 查询单只股票
        stock = manager.query_stock(args.code)
        if stock:
            return {"status": "success", "stock": stock}
        else:
            return {"status": "error", "message": f"股票 {args.code} 不存在"}
    else:
        # 查询池
        include_eliminated = getattr(args, 'include_eliminated', False)
        stocks = manager.query_pool(args.pool, include_eliminated=include_eliminated)
        return {
            "status": "success",
            "pool_level": args.pool,
            "count": len(stocks),
            "stocks": stocks
        }


def cmd_list(args, manager: StockPoolManager) -> Dict[str, Any]:
    """列出所有池"""
    all_pools = manager.get_all_pools()
    stats = manager.get_pool_stats()
    
    return {
        "status": "success",
        "stats": stats,
        "pools": {f"pool_{k}": [{"code": s['stock_code'], "name": s.get('stock_name', '')} for s in v] 
                  for k, v in all_pools.items()}
    }


def cmd_record_operation(args, manager: StockPoolManager) -> Dict[str, Any]:
    """记录操作"""
    details = {}
    if args.operation_type:
        details['operation_type'] = args.operation_type
    if args.price:
        details['price'] = float(args.price)
    if args.quantity:
        details['quantity'] = int(args.quantity)
    if args.amount:
        details['amount'] = float(args.amount)
    if args.notes:
        details['notes'] = args.notes
    
    return manager.record_operation(args.code, args.operation, details)


def cmd_refresh(args, manager: StockPoolManager) -> Dict[str, Any]:
    """刷新池数据"""
    if args.pool:
        stocks = manager.query_pool(args.pool)
    else:
        all_pools = manager.get_all_pools()
        stocks = []
        for pool_stocks in all_pools.values():
            stocks.extend(pool_stocks)
    
    if not stocks:
        return {"status": "success", "message": "池为空，无需刷新"}
    
    codes = [s['stock_code'] for s in stocks]
    logger.info(f"刷新 {len(codes)} 只股票数据...")
    
    refreshed = refresh_pool_data(codes)
    
    # 更新数据库
    updated_count = 0
    for data in refreshed:
        code = data.get('stock_code')
        updates = {k: v for k, v in data.items() 
                  if k in ['current_price', 'change_pct', 'volume', 'amount',
                          'pe', 'pb', 'roe', 'north_money', 'total_market_cap']}
        if updates:
            manager.update_stock(code, updates)
            updated_count += 1
    
    return {
        "status": "success",
        "total_stocks": len(codes),
        "refreshed": len(refreshed),
        "updated": updated_count
    }


def cmd_screening(args, manager: StockPoolManager) -> Dict[str, Any]:
    """筛选检查"""
    screener = StockScreener(manager)
    
    if args.code:
        # 检查单只股票
        if args.pool == 1:
            result = screener.check_pool1_criteria(args.code)
        elif args.pool == 2:
            data = get_financial_data(args.code) or {}
            data['stock_code'] = args.code
            result = screener.check_pool2_criteria(data)
        else:
            return {"status": "error", "message": "仅支持池1和池2的筛选检查"}
        return {"status": "success", "result": result}
    else:
        # 执行池维护
        result = screener.run_pool_maintenance()
        return {"status": "success", "result": result}


def cmd_alerts(args, manager: StockPoolManager) -> Dict[str, Any]:
    """预警检查"""
    alerter = StockAlerter(manager)
    
    if args.code:
        # 检查单只股票
        stock = manager.query_stock(args.code)
        if not stock:
            return {"status": "error", "message": f"股票 {args.code} 不存在"}
        
        alerts = alerter.check_stock(stock)
        return {
            "status": "success",
            "stock_code": args.code,
            "alerts": [a.to_dict() for a in alerts]
        }
    else:
        # 全量预警
        levels = [3, 4] if not args.pool else [args.pool]
        results = alerter.run_all_alerts(pool_levels=levels)
        
        if args.format == 'markdown':
            return {
                "status": "success",
                "format": "markdown",
                "content": alerter.format_alerts_markdown(results)
            }
        
        return results


def cmd_review(args, manager: StockPoolManager) -> Dict[str, Any]:
    """复盘报告"""
    reviewer = StockReviewer(manager)
    
    if args.type == 'daily':
        report = reviewer.generate_daily_report()
    elif args.type == 'weekly':
        report = reviewer.generate_weekly_report()
    elif args.type == 'monthly':
        report = reviewer.generate_monthly_report()
    else:
        return {"status": "error", "message": f"不支持的报告类型: {args.type}"}
    
    if args.format == 'markdown':
        return {
            "status": "success",
            "format": "markdown",
            "report_type": args.type,
            "content": reviewer.format_report_markdown(report)
        }
    
    return {"status": "success", "report": report}


def cmd_maintenance(args, manager: StockPoolManager) -> Dict[str, Any]:
    """执行维护"""
    screener = StockScreener(manager)
    result = screener.run_pool_maintenance()
    return {"status": "success", "result": result}


def main():
    parser = argparse.ArgumentParser(description='股票池管理器')
    subparsers = parser.add_subparsers(dest='command', help='子命令')
    
    # add: 添加股票
    parser_add = subparsers.add_parser('add', help='添加股票到池')
    parser_add.add_argument('--pool', type=int, required=True, choices=[1, 2, 3, 4], help='目标池')
    parser_add.add_argument('--code', required=True, help='股票代码')
    parser_add.add_argument('--name', help='股票名称')
    parser_add.add_argument('--reason', help='入选理由')
    parser_add.add_argument('--refresh', action='store_true', help='获取实时数据')
    
    # remove: 移除股票
    parser_remove = subparsers.add_parser('remove', help='移除股票')
    parser_remove.add_argument('--code', required=True, help='股票代码')
    parser_remove.add_argument('--reason', help='移除原因')
    
    # move: 移动股票
    parser_move = subparsers.add_parser('move', help='移动股票到其他池')
    parser_move.add_argument('--code', required=True, help='股票代码')
    parser_move.add_argument('--to', type=int, required=True, choices=[1, 2, 3, 4], help='目标池')
    parser_move.add_argument('--buy-point', help='理想买点')
    parser_move.add_argument('--stop-loss', help='止损位')
    parser_move.add_argument('--target1', help='第一目标位')
    parser_move.add_argument('--target2', help='第二目标位')
    parser_move.add_argument('--plan-price', help='计划买入价')
    parser_move.add_argument('--plan-qty', help='计划买入量')
    parser_move.add_argument('--position', help='仓位建议(%%)')
    parser_move.add_argument('--technical', help='技术形态')
    parser_move.add_argument('--catalyst', help='催化剂事件')
    
    # update: 更新股票
    parser_update = subparsers.add_parser('update', help='更新股票信息')
    parser_update.add_argument('--code', required=True, help='股票代码')
    parser_update.add_argument('--price', help='当前价格')
    parser_update.add_argument('--change', help='涨跌幅')
    parser_update.add_argument('--pe', help='市盈率')
    parser_update.add_argument('--roe', help='ROE')
    parser_update.add_argument('--stop-loss', help='止损位')
    parser_update.add_argument('--buy-point', help='理想买点')
    parser_update.add_argument('--target1', help='第一目标位')
    parser_update.add_argument('--target2', help='第二目标位')
    parser_update.add_argument('--cost', help='持仓成本')
    parser_update.add_argument('--holding', type=int, help='持仓数量')
    parser_update.add_argument('--attention', type=int, help='关注等级(1-5)')
    parser_update.add_argument('--notes', help='备注')
    
    # query: 查询
    parser_query = subparsers.add_parser('query', help='查询池')
    parser_query.add_argument('--pool', type=int, choices=[1, 2, 3, 4], help='池等级')
    parser_query.add_argument('--code', help='股票代码')
    parser_query.add_argument('--include-eliminated', action='store_true', help='包含已淘汰')
    
    # list: 列出所有池
    parser_list = subparsers.add_parser('list', help='列出所有池')
    
    # record: 记录操作
    parser_record = subparsers.add_parser('record', help='记录操作')
    parser_record.add_argument('--code', required=True, help='股票代码')
    parser_record.add_argument('--operation', required=True, help='操作类型(买入/卖出/调仓)')
    parser_record.add_argument('--operation-type', help='操作细分')
    parser_record.add_argument('--price', help='成交价格')
    parser_record.add_argument('--quantity', type=int, help='成交数量')
    parser_record.add_argument('--amount', help='成交金额')
    parser_record.add_argument('--notes', help='备注')
    
    # refresh: 刷新数据
    parser_refresh = subparsers.add_parser('refresh', help='刷新池数据')
    parser_refresh.add_argument('--pool', type=int, choices=[1, 2, 3, 4], help='指定池')
    
    # screening: 筛选检查
    parser_screening = subparsers.add_parser('screening', help='筛选检查')
    parser_screening.add_argument('--pool', type=int, choices=[1, 2], help='池等级')
    parser_screening.add_argument('--code', help='股票代码')
    
    # alerts: 预警检查
    parser_alerts = subparsers.add_parser('alerts', help='预警检查')
    parser_alerts.add_argument('--code', help='股票代码')
    parser_alerts.add_argument('--pool', type=int, choices=[3, 4], help='池等级')
    parser_alerts.add_argument('--format', choices=['json', 'markdown'], default='json', help='输出格式')
    
    # review: 复盘报告
    parser_review = subparsers.add_parser('review', help='复盘报告')
    parser_review.add_argument('--type', choices=['daily', 'weekly', 'monthly'], 
                               default='daily', help='报告类型')
    parser_review.add_argument('--format', choices=['json', 'markdown'], default='json', help='输出格式')
    
    # maintenance: 维护
    parser_maintenance = subparsers.add_parser('maintenance', help='执行池维护')
    
    # 解析参数
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # 初始化管理器
    db_path = getattr(args, 'db_path', './data/stock_pools.db')
    manager = StockPoolManager(db_path)
    
    # 执行命令
    cmd_handlers = {
        'add': cmd_add,
        'remove': cmd_remove,
        'move': cmd_move,
        'update': cmd_update,
        'query': cmd_query,
        'list': cmd_list,
        'record': cmd_record,
        'refresh': cmd_refresh,
        'screening': cmd_screening,
        'alerts': cmd_alerts,
        'review': cmd_review,
        'maintenance': cmd_maintenance
    }
    
    handler = cmd_handlers.get(args.command)
    if handler:
        try:
            result = handler(args, manager)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except Exception as e:
            logger.error(f"执行失败: {e}")
            print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
    else:
        print(json.dumps({"status": "error", "message": f"未知命令: {args.command}"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
