#!/usr/bin/env python3
"""
盘后复盘分析模块
生成日/周/月复盘报告
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

import pandas as pd

from pool_manager import StockPoolManager
from data_fetcher import get_realtime_quote, get_historical_data, refresh_pool_data
from alerter import StockAlerter

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class PerformanceCalculator:
    """绩效计算器"""
    
    def __init__(self, pool_manager: StockPoolManager):
        self.pool_manager = pool_manager
    
    def calculate_stock_return(self, stock: Dict[str, Any], days: int = 30) -> Dict[str, Any]:
        """
        计算单只股票收益率
        """
        code = stock['stock_code']
        hist = get_historical_data(code, days=days + 5)
        
        if hist is None or len(hist) < 2:
            return {"stock_code": code, "error": "数据不足"}
        
        # 计算收益率
        start_price = hist.iloc[0]['close']
        end_price = hist.iloc[-1]['close']
        period_return = (end_price - start_price) / start_price * 100
        
        # 计算波动率
        returns = hist['close'].pct_change().dropna()
        volatility = returns.std() * 100 * (252 ** 0.5)  # 年化波动率
        
        # 计算最大回撤
        rolling_max = hist['close'].cummax()
        drawdown = (hist['close'] - rolling_max) / rolling_max * 100
        max_drawdown = drawdown.min()
        
        return {
            "stock_code": code,
            "stock_name": stock.get('stock_name', ''),
            "period": f"{days}D",
            "start_price": start_price,
            "end_price": end_price,
            "period_return": period_return,
            "volatility": volatility,
            "max_drawdown": max_drawdown,
            "current_price": stock.get('current_price', end_price)
        }
    
    def calculate_pool_performance(self, pool_level: int, days: int = 30) -> Dict[str, Any]:
        """
        计算池整体表现
        """
        stocks = self.pool_manager.query_pool(pool_level)
        
        if not stocks:
            return {"pool_level": pool_level, "stock_count": 0, "returns": []}
        
        returns = []
        for stock in stocks:
            # 获取最新行情
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                stock.update(quote)
            
            # 计算收益
            ret = self.calculate_stock_return(stock, days)
            returns.append(ret)
        
        # 过滤成功计算的
        valid_returns = [r for r in returns if 'error' not in r]
        
        if not valid_returns:
            return {"pool_level": pool_level, "stock_count": len(stocks), "returns": []}
        
        # 汇总统计
        period_returns = [r['period_return'] for r in valid_returns]
        avg_return = sum(period_returns) / len(period_returns)
        
        # 胜率
        win_count = sum(1 for r in period_returns if r > 0)
        win_rate = win_count / len(period_returns) * 100
        
        # 盈亏比
        gains = [r for r in period_returns if r > 0]
        losses = [abs(r) for r in period_returns if r < 0]
        profit_loss_ratio = sum(gains) / sum(losses) if losses else 0
        
        # 最大回撤
        max_drawdowns = [r['max_drawdown'] for r in valid_returns]
        avg_max_drawdown = sum(max_drawdowns) / len(max_drawdowns)
        
        return {
            "pool_level": pool_level,
            "stock_count": len(stocks),
            "analyzed_count": len(valid_returns),
            "avg_return": avg_return,
            "win_rate": win_rate,
            "profit_loss_ratio": profit_loss_ratio,
            "avg_max_drawdown": avg_max_drawdown,
            "returns": valid_returns
        }
    
    def calculate_vs_benchmark(self, pool_level: int, benchmark: str = "000001.SH",
                                days: int = 30) -> Dict[str, Any]:
        """
        计算与大盘对比
        """
        pool_perf = self.calculate_pool_performance(pool_level, days)
        
        # 获取基准收益
        bench_hist = get_historical_data(benchmark, days=days + 5)
        if bench_hist is not None and len(bench_hist) >= 2:
            bench_start = bench_hist.iloc[0]['close']
            bench_end = bench_hist.iloc[-1]['close']
            bench_return = (bench_end - bench_start) / bench_start * 100
            
            # 超额收益
            excess_return = pool_perf.get('avg_return', 0) - bench_return
            
            pool_perf['benchmark'] = benchmark
            pool_perf['benchmark_return'] = bench_return
            pool_perf['excess_return'] = excess_return
        
        return pool_perf


class StockReviewer:
    """盘后复盘分析器"""
    
    def __init__(self, pool_manager: StockPoolManager = None):
        self.pool_manager = pool_manager or StockPoolManager()
        self.perf_calc = PerformanceCalculator(self.pool_manager)
        self.alerter = StockAlerter(self.pool_manager)
    
    def analyze_technical_pattern(self, stock: Dict[str, Any]) -> Dict[str, Any]:
        """
        分析技术形态
        """
        code = stock['stock_code']
        hist = get_historical_data(code, days=60)
        
        if hist is None or len(hist) < 20:
            return {"stock_code": code, "pattern": "数据不足"}
        
        current_price = hist.iloc[-1]['close']
        ma5 = hist['close'].tail(5).mean()
        ma20 = hist['close'].tail(20).mean()
        ma60 = hist['close'].tail(60).mean() if len(hist) >= 60 else None
        
        # 最近高低点
        high_20d = hist.tail(20)['high'].max()
        low_20d = hist.tail(20)['low'].min()
        
        # 趋势判断
        if current_price > ma20 > ma60 if ma60 else current_price > ma20:
            trend = "上升趋势"
        elif current_price < ma20 < ma60 if ma60 else current_price < ma20:
            trend = "下降趋势"
        else:
            trend = "震荡整理"
        
        # 形态识别
        patterns = []
        
        # 均线多头
        if ma5 > ma20 > (ma60 if ma60 else ma20):
            patterns.append("均线多头排列")
        
        # 突破新高
        if current_price >= hist.tail(60)['high'].max():
            patterns.append("突破60日新高")
        
        # 放量上涨
        avg_volume = hist.tail(20)['volume'].mean()
        last_volume = hist.iloc[-1]['volume']
        if last_volume > avg_volume * 1.5 and current_price > hist.iloc[-2]['close']:
            patterns.append("放量上涨")
        
        # 金叉/死叉
        if len(hist) >= 5:
            ma5_series = hist['close'].rolling(5).mean()
            ma20_series = hist['close'].rolling(20).mean()
            if ma5_series.iloc[-2] < ma20_series.iloc[-2] and ma5_series.iloc[-1] > ma20_series.iloc[-1]:
                patterns.append("MA5上穿MA20(金叉)")
            elif ma5_series.iloc[-2] > ma20_series.iloc[-2] and ma5_series.iloc[-1] < ma20_series.iloc[-1]:
                patterns.append("MA5下穿MA20(死叉)")
        
        return {
            "stock_code": code,
            "stock_name": stock.get('stock_name', ''),
            "current_price": current_price,
            "ma5": ma5,
            "ma20": ma20,
            "ma60": ma60,
            "high_20d": high_20d,
            "low_20d": low_20d,
            "trend": trend,
            "patterns": patterns
        }
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """
        生成每日复盘报告
        """
        logger.info("生成日度复盘报告...")
        
        report = {
            "report_type": "daily",
            "generated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "date": datetime.now().strftime('%Y-%m-%d'),
            "pool_summary": {},
            "pool3_analysis": [],
            "pool4_positions": [],
            "alerts_summary": {},
            "tomorrow_focus": []
        }
        
        # 1. 池统计
        for level in range(1, 5):
            stocks = self.pool_manager.query_pool(level)
            report["pool_summary"][f"pool_{level}_count"] = len(stocks)
        
        # 2. 三级池技术分析
        pool3_stocks = self.pool_manager.query_pool(3)
        for stock in pool3_stocks[:5]:  # 最多5只
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                stock.update(quote)
            analysis = self.analyze_technical_pattern(stock)
            report["pool3_analysis"].append(analysis)
        
        # 3. 四级池持仓检查
        pool4_stocks = self.pool_manager.query_pool(4)
        for stock in pool4_stocks:
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                stock.update(quote)
                # 计算浮动盈亏
                if stock.get('cost_basis') and stock.get('current_price'):
                    stock['floating_pnl'] = (stock['current_price'] - stock['cost_basis']) * stock.get('current_holding', 0)
                    stock['floating_pnl_pct'] = (stock['current_price'] - stock['cost_basis']) / stock['cost_basis'] * 100
            report["pool4_positions"].append(stock)
        
        # 4. 预警汇总
        alert_results = self.alerter.run_all_alerts([3, 4])
        report["alerts_summary"] = {
            "total_alerts": alert_results['alerts_found'],
            "by_pool": alert_results['by_level']
        }
        
        # 5. 次日关注
        report["tomorrow_focus"] = self._generate_tomorrow_focus(pool3_stocks, alert_results)
        
        return report
    
    def generate_weekly_report(self) -> Dict[str, Any]:
        """
        生成每周复盘报告
        """
        logger.info("生成周度复盘报告...")
        
        report = {
            "report_type": "weekly",
            "generated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "week_start": (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d'),
            "week_end": datetime.now().strftime('%Y-%m-%d'),
            "pool_performance": {},
            "screening_candidates": [],
            "elimination_check": [],
            "pool_changes": {}
        }
        
        # 1. 各池周收益
        for level in range(1, 5):
            perf = self.perf_calc.calculate_pool_performance(level, days=7)
            report["pool_performance"][f"pool_{level}"] = perf
        
        # 2. 池1升级候选
        from screener import StockScreener
        screener = StockScreener(self.pool_manager)
        pool1_stocks = self.pool_manager.query_pool(1)
        candidates = screener.get_promotion_candidates(pool1_stocks)
        report["screening_candidates"] = candidates[:5]
        
        # 3. 淘汰检查
        elim_results = screener.run_pool_maintenance()
        report["elimination_check"] = elim_results
        
        # 4. 池变动统计
        report["pool_changes"] = {
            "new_additions": 0,  # 需要比较历史
            "promotions": 0,
            "demotions": 0,
            "eliminations": len(elim_results.get('eliminated', []))
        }
        
        return report
    
    def generate_monthly_report(self) -> Dict[str, Any]:
        """
        生成每月复盘报告
        """
        logger.info("生成月度复盘报告...")
        
        report = {
            "report_type": "monthly",
            "generated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "month": datetime.now().strftime('%Y-%m'),
            "performance_analysis": {},
            "vs_benchmark": {},
            "strategy_recommendations": []
        }
        
        # 1. 月度绩效分析
        for level in range(1, 5):
            perf = self.perf_calc.calculate_pool_performance(level, days=30)
            report["performance_analysis"][f"pool_{level}"] = perf
        
        # 2. vs 大盘对比
        for level in [2, 3, 4]:  # 只对比重点池
            vs = self.perf_calc.calculate_vs_benchmark(level, days=30)
            report["vs_benchmark"][f"pool_{level}"] = vs
        
        # 3. 策略优化建议
        report["strategy_recommendations"] = self._generate_strategy_recommendations(report)
        
        return report
    
    def _generate_tomorrow_focus(self, pool3_stocks: List, alert_results: Dict) -> List[Dict]:
        """生成次日关注要点"""
        focus = []
        
        # 有预警的股票
        alert_codes = [a['stock_code'] for a in alert_results.get('alerts', [])]
        for stock in pool3_stocks:
            if stock['stock_code'] in alert_codes:
                focus.append({
                    "stock_code": stock['stock_code'],
                    "stock_name": stock.get('stock_name', ''),
                    "reason": "触发预警，需重点关注"
                })
        
        return focus[:5]
    
    def _generate_strategy_recommendations(self, report: Dict) -> List[str]:
        """生成策略优化建议"""
        recommendations = []
        
        perf = report.get('performance_analysis', {})
        
        # 分析各池表现
        for pool_name, data in perf.items():
            if data.get('win_rate', 0) < 50:
                recommendations.append(f"{pool_name}胜率偏低，建议审视选股标准")
            
            if data.get('avg_max_drawdown', 0) < -15:
                recommendations.append(f"{pool_name}平均回撤较大，建议收紧止损规则")
        
        # 检查是否需要调整池容量
        for i in range(1, 5):
            count = perf.get(f'pool_{i}', {}).get('stock_count', 0)
            # 添加基于容量的建议
        
        return recommendations
    
    def format_report_markdown(self, report: Dict) -> str:
        """
        格式化报告为Markdown
        """
        lines = [
            f"# {report['report_type'].capitalize()} 复盘报告",
            f"- 生成时间: {report['generated_at']}",
            ""
        ]
        
        if report['report_type'] == 'daily':
            lines.extend(self._format_daily_report(report))
        elif report['report_type'] == 'weekly':
            lines.extend(self._format_weekly_report(report))
        elif report['report_type'] == 'monthly':
            lines.extend(self._format_monthly_report(report))
        
        return "\n".join(lines)
    
    def _format_daily_report(self, report: Dict) -> List[str]:
        """格式化日报"""
        lines = []
        
        # 池统计
        lines.append("## 池统计")
        lines.append("| 池 | 股票数 |")
        lines.append("|---|-------|")
        for key, count in report.get('pool_summary', {}).items():
            pool_name = key.replace('pool_', '池').replace('_count', '')
            lines.append(f"| {pool_name} | {count} |")
        lines.append("")
        
        # 三级池分析
        if report.get('pool3_analysis'):
            lines.append("## 三级池技术分析")
            for item in report['pool3_analysis']:
                lines.append(f"### {item.get('stock_name', '')}({item['stock_code']})")
                lines.append(f"- 趋势: {item.get('trend', 'N/A')}")
                lines.append(f"- 当前价: {item.get('current_price', 0):.2f}")
                lines.append(f"- MA5: {item.get('ma5', 0):.2f}, MA20: {item.get('ma20', 0):.2f}")
                lines.append(f"- 形态: {', '.join(item.get('patterns', [])) or '无明显特征'}")
                lines.append("")
        
        # 四级池持仓
        if report.get('pool4_positions'):
            lines.append("## 四级池持仓")
            lines.append("| 股票 | 现价 | 成本 | 浮动盈亏 | 盈亏% |")
            lines.append("|------|------|------|---------|-------|")
            for stock in report['pool4_positions']:
                lines.append(f"| {stock.get('stock_name', '')}({stock['stock_code']}) | "
                           f"{stock.get('current_price', 0):.2f} | {stock.get('cost_basis', 0):.2f} | "
                           f"{stock.get('floating_pnl', 0):.2f} | {stock.get('floating_pnl_pct', 0):.2f}% |")
            lines.append("")
        
        # 预警汇总
        if report.get('alerts_summary', {}).get('total_alerts', 0) > 0:
            lines.append("## 预警汇总")
            lines.append(f"- 预警总数: {report['alerts_summary']['total_alerts']}")
            for pool, count in report['alerts_summary'].get('by_pool', {}).items():
                lines.append(f"- {pool}: {count}条")
            lines.append("")
        
        return lines
    
    def _format_weekly_report(self, report: Dict) -> List[str]:
        """格式化周报"""
        lines = []
        
        # 绩效汇总
        lines.append("## 周收益表现")
        for pool, perf in report.get('pool_performance', {}).items():
            count = perf.get('stock_count', 0)
            avg_ret = perf.get('avg_return', 0)
            win_rate = perf.get('win_rate', 0)
            lines.append(f"- {pool}: {count}只, 平均收益{avg_ret:.2f}%, 胜率{win_rate:.1f}%")
        lines.append("")
        
        # 升级候选
        if report.get('screening_candidates'):
            lines.append("## 升级候选")
            lines.append("| 股票 | ROE | 毛利率 | 营收增长 | 评分 |")
            lines.append("|------|-----|-------|---------|------|")
            for cand in report['screening_candidates']:
                lines.append(f"| {cand.get('stock_name', '')}({cand['stock_code']}) | "
                           f"{cand.get('roe', 0):.1f}% | {cand.get('gross_margin', 0):.1f}% | "
                           f"{cand.get('revenue_growth', 0):.1f}% | {cand.get('promotion_score', 0):.1f} |")
            lines.append("")
        
        # 淘汰检查
        elim = report.get('elimination_check', {})
        if elim.get('eliminated'):
            lines.append("## 淘汰股票")
            for item in elim['eliminated']:
                lines.append(f"- {item['stock_name']}({item['stock_code']}): {item['reason']['message']}")
            lines.append("")
        
        return lines
    
    def _format_monthly_report(self, report: Dict) -> List[str]:
        """格式化月报"""
        lines = []
        
        # 绩效分析
        lines.append("## 月度绩效")
        lines.append("| 池 | 股票数 | 平均收益 | 胜率 | 盈亏比 | 最大回撤 |")
        lines.append("|---|-------|---------|-----|------|---------|")
        for pool, perf in report.get('performance_analysis', {}).items():
            lines.append(f"| {pool} | {perf.get('stock_count', 0)} | "
                        f"{perf.get('avg_return', 0):.2f}% | {perf.get('win_rate', 0):.1f}% | "
                        f"{perf.get('profit_loss_ratio', 0):.2f} | {perf.get('avg_max_drawdown', 0):.2f}% |")
        lines.append("")
        
        # vs 大盘
        lines.append("## vs 大盘对比")
        for pool, vs in report.get('vs_benchmark', {}).items():
            bench_ret = vs.get('benchmark_return', 0)
            excess = vs.get('excess_return', 0)
            status = "跑赢" if excess > 0 else "跑输"
            lines.append(f"- {pool}: 基准{bench_ret:.2f}%, 超额收益{excess:.2f}% ({status})")
        lines.append("")
        
        # 策略建议
        if report.get('strategy_recommendations'):
            lines.append("## 策略优化建议")
            for rec in report['strategy_recommendations']:
                lines.append(f"- {rec}")
            lines.append("")
        
        return lines


if __name__ == "__main__":
    import sys
    
    reviewer = StockReviewer()
    
    if len(sys.argv) > 1:
        report_type = sys.argv[1]
        
        if report_type == "daily":
            report = reviewer.generate_daily_report()
        elif report_type == "weekly":
            report = reviewer.generate_weekly_report()
        elif report_type == "monthly":
            report = reviewer.generate_monthly_report()
        else:
            print("Usage: python review.py [daily|weekly|monthly]")
            sys.exit(1)
        
        print(json.dumps(report, ensure_ascii=False, indent=2))
        
        # 输出Markdown
        print("\n" + "="*50)
        print(reviewer.format_report_markdown(report))
    else:
        # 测试日报
        print("生成日度复盘报告...")
        report = reviewer.generate_daily_report()
        print(json.dumps(report, ensure_ascii=False, indent=2))
