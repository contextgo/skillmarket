#!/usr/bin/env python3
"""
股票筛选器模块
实现四级池自动筛选逻辑与强制淘汰机制
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

from data_fetcher import (
    get_realtime_quote, get_financial_data, get_market_cap, 
    get_historical_data, get_listing_date, refresh_pool_data
)
from pool_manager import StockPoolManager

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ============ 筛选阈值配置 ============

SCREENING_RULES = {
    "pool_1": {
        "no_st": True,  # 不能是ST/*ST
        "min_market_cap": 50 * 1e8,  # 50亿
        "min_listing_years": 3
    },
    "pool_2": {
        "min_roe": 10,  # 近3年ROE均值 > 10%
        "gross_margin_trend": "stable_or_up",  # 毛利率稳定或提升
        "max_debt_ratio": 60  # 负债率 < 60%
    },
    "pool_3": {
        # 无自动强逻辑，依赖用户/分析报告输入
    },
    "pool_4": {
        # 依赖用户输入交易计划
    }
}

ELIMINATION_RULES = {
    "profit_warning": {
        "threshold": -50,  # 净利润同比下滑 > 50%
        "check_field": "profit_growth",
        "require_confirmation": True
    },
    "regulatory_risk": {
        "keywords": ["立案调查", "违法违规", "控制人被调查", "处罚"],
        "check_source": "news"
    },
    "technical_break": {
        "check_fields": ["stop_loss", "low_60d"]
    },
    "liquidity_dry": {
        "threshold": 5000 * 1e4,  # 连续5日日均成交额 < 5000万
        "days": 5
    }
}


class StockScreener:
    """股票筛选器"""
    
    def __init__(self, pool_manager: StockPoolManager = None):
        self.pool_manager = pool_manager or StockPoolManager()
    
    def check_st_status(self, stock_code: str) -> Tuple[bool, str]:
        """
        检查是否为ST/*ST股票
        Returns: (is_normal, message)
        """
        try:
            # 通过实时行情检查
            quote = get_realtime_quote(stock_code)
            if quote and quote.get('name'):
                name = quote['name']
                if 'ST' in name or '*ST' in name or 'S*ST' in name:
                    return False, f"ST股票: {name}"
            return True, "正常"
        except Exception as e:
            logger.warning(f"检查ST状态失败 {stock_code}: {e}")
            return True, "检查失败，假设正常"
    
    def check_market_cap(self, stock_code: str, threshold: float = 50e8) -> Tuple[bool, str]:
        """
        检查市值是否满足门槛
        """
        try:
            cap_data = get_market_cap(stock_code)
            if cap_data and cap_data.get('total_market_cap'):
                cap = cap_data['total_market_cap']
                if cap >= threshold:
                    return True, f"市值{cap/1e8:.2f}亿，满足>=50亿"
                else:
                    return False, f"市值{cap/1e8:.2f}亿，不满足>=50亿"
            return False, "市值数据获取失败"
        except Exception as e:
            logger.warning(f"检查市值失败 {stock_code}: {e}")
            return False, f"检查失败: {e}"
    
    def check_listing_age(self, stock_code: str, years: int = 3) -> Tuple[bool, str]:
        """
        检查上市年限
        """
        try:
            listing_date = get_listing_date(stock_code)
            if listing_date:
                from dateutil.parser import parse
                listed = parse(listing_date)
                age_years = (datetime.now() - listed).days / 365.25
                if age_years >= years:
                    return True, f"上市{age_years:.1f}年，满足>={years}年"
                else:
                    return False, f"上市{age_years:.1f}年，不满足>={years}年"
            return False, "上市日期获取失败"
        except Exception as e:
            logger.warning(f"检查上市年限失败 {stock_code}: {e}")
            return True, "检查失败，假设满足"
    
    def check_roe(self, stock_data: Dict[str, Any], threshold: float = 10) -> Tuple[bool, str]:
        """
        检查ROE是否满足要求
        """
        roe = stock_data.get('roe')
        if roe is None:
            return False, "ROE数据缺失"
        
        if roe >= threshold:
            return True, f"ROE={roe:.2f}%，满足>={threshold}%"
        else:
            return False, f"ROE={roe:.2f}%，不满足>={threshold}%"
    
    def check_gross_margin_trend(self, stock_data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        检查毛利率趋势 (稳定或提升)
        """
        gross_margin = stock_data.get('gross_margin')
        if gross_margin is None:
            return False, "毛利率数据缺失"
        
        # 简化：实际应比较多年趋势
        if gross_margin >= 20:  # 简化判断
            return True, f"毛利率={gross_margin:.2f}%，满足"
        else:
            return False, f"毛利率={gross_margin:.2f}%，偏低"
    
    def check_debt_ratio(self, stock_data: Dict[str, Any], threshold: float = 60) -> Tuple[bool, str]:
        """
        检查负债率
        """
        debt_ratio = stock_data.get('debt_ratio')
        if debt_ratio is None:
            return False, "负债率数据缺失"
        
        if debt_ratio < threshold:
            return True, f"负债率={debt_ratio:.2f}%，满足<{threshold}%"
        else:
            return False, f"负债率={debt_ratio:.2f}%，偏高"
    
    def check_pool1_criteria(self, stock_code: str) -> Dict[str, Any]:
        """
        检查一级池入选标准
        Returns: {"passed": bool, "checks": {...}, "can_add": bool}
        """
        checks = {}
        
        # 检查1: 非ST
        is_normal, msg = self.check_st_status(stock_code)
        checks['st_check'] = {"passed": is_normal, "message": msg}
        
        # 检查2: 市值门槛
        passed, msg = self.check_market_cap(stock_code)
        checks['market_cap_check'] = {"passed": passed, "message": msg}
        
        # 检查3: 上市年限
        passed, msg = self.check_listing_age(stock_code)
        checks['listing_age_check'] = {"passed": passed, "message": msg}
        
        all_passed = all(c.get('passed', False) for c in checks.values())
        
        return {
            "stock_code": stock_code,
            "passed": all_passed,
            "checks": checks
        }
    
    def check_pool2_criteria(self, stock_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        检查二级池入选标准
        """
        checks = {}
        
        # ROE检查
        passed, msg = self.check_roe(stock_data)
        checks['roe_check'] = {"passed": passed, "message": msg}
        
        # 毛利率检查
        passed, msg = self.check_gross_margin_trend(stock_data)
        checks['gross_margin_check'] = {"passed": passed, "message": msg}
        
        # 负债率检查
        passed, msg = self.check_debt_ratio(stock_data)
        checks['debt_ratio_check'] = {"passed": passed, "message": msg}
        
        all_passed = all(c.get('passed', False) for c in checks.values())
        
        return {
            "stock_code": stock_data.get('stock_code'),
            "passed": all_passed,
            "checks": checks
        }
    
    def get_promotion_candidates(self, pool1_stocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        从一级池筛选可升级到二级池的候选股票
        获取完整数据后检查二级池标准
        """
        candidates = []
        
        for stock in pool1_stocks:
            code = stock['stock_code']
            logger.info(f"检查 {code} 是否满足二级池标准...")
            
            # 获取完整数据
            full_data = get_financial_data(code)
            if full_data:
                full_data['stock_code'] = code
                full_data['stock_name'] = stock.get('stock_name', '')
                
                # 检查二级池标准
                result = self.check_pool2_criteria(full_data)
                if result['passed']:
                    full_data['promotion_score'] = self._calculate_promotion_score(full_data)
                    candidates.append(full_data)
        
        # 按评分排序
        candidates.sort(key=lambda x: x.get('promotion_score', 0), reverse=True)
        
        return candidates[:10]  # 最多返回10只
    
    def _calculate_promotion_score(self, stock_data: Dict[str, Any]) -> float:
        """计算升级评分"""
        score = 0.0
        
        # ROE加分
        roe = stock_data.get('roe', 0)
        if roe:
            score += min(roe, 30)  # 封顶30分
        
        # 毛利率加分
        gm = stock_data.get('gross_margin', 0)
        if gm:
            score += min(gm / 2, 20)  # 封顶20分
        
        # 营收增长加分
        rev_growth = stock_data.get('revenue_growth', 0)
        if rev_growth:
            score += min(rev_growth, 15)  # 封顶15分
        
        # 净利润增长加分
        profit_growth = stock_data.get('profit_growth', 0)
        if profit_growth:
            score += min(profit_growth, 15)  # 封顶15分
        
        # 北向资金加分
        north = stock_data.get('north_money', 0)
        if north and north > 0:
            score += min(north / 1e8, 20)  # 封顶20分
        
        return score
    
    def check_elimination_rules(self, stock: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        检查强制淘汰规则
        Returns: 需要淘汰的原因列表
        """
        elimination_reasons = []
        code = stock['stock_code']
        
        # 1. 业绩变脸检查
        profit_growth = stock.get('profit_growth')
        if profit_growth and profit_growth < ELIMINATION_RULES['profit_warning']['threshold']:
            elimination_reasons.append({
                "type": "profit_warning",
                "message": f"净利润同比下滑{abs(profit_growth):.1f}%",
                "require_confirmation": True
            })
        
        # 2. 监管风险检查 (简化，实际应查询新闻)
        # 需要新闻API，此处仅做占位
        
        # 3. 技术破位检查
        current_price = stock.get('current_price')
        stop_loss = stock.get('stop_loss')
        low_60d = stock.get('low_60d')
        
        if current_price and stop_loss and current_price <= stop_loss:
            elimination_reasons.append({
                "type": "technical_break",
                "message": f"价格{current_price}跌破止损位{stop_loss}",
                "require_confirmation": False
            })
        
        if current_price and low_60d and current_price <= low_60d:
            elimination_reasons.append({
                "type": "technical_break",
                "message": f"价格{current_price}跌破60日最低{low_60d}",
                "require_confirmation": False
            })
        
        # 4. 流动性枯竭检查
        amount = stock.get('amount', 0)
        if amount and amount < ELIMINATION_RULES['liquidity_dry']['threshold']:
            elimination_reasons.append({
                "type": "liquidity_dry",
                "message": f"成交额{amount/1e4:.0f}万，低于5000万",
                "require_confirmation": False
            })
        
        return elimination_reasons
    
    def run_pool_maintenance(self) -> Dict[str, Any]:
        """
        执行池维护：检查所有在池股票的淘汰条件
        """
        logger.info("开始执行池维护...")
        
        results = {
            "checked": 0,
            "eliminated": [],
            "warnings": [],
            "confirmations_needed": []
        }
        
        for level in range(1, 5):
            stocks = self.pool_manager.query_pool(level)
            for stock in stocks:
                results["checked"] += 1
                
                # 获取最新行情
                quote = get_realtime_quote(stock['stock_code'])
                if quote:
                    stock.update(quote)
                
                # 检查淘汰规则
                elimination_reasons = self.check_elimination_rules(stock)
                
                for reason in elimination_reasons:
                    if reason.get('require_confirmation'):
                        results["confirmations_needed"].append({
                            "stock_code": stock['stock_code'],
                            "stock_name": stock.get('stock_name', ''),
                            "reason": reason,
                            "pool_level": level
                        })
                    else:
                        # 自动淘汰
                        self.pool_manager.remove_stock(
                            stock['stock_code'], 
                            elimination_reason=f"[{reason['type']}] {reason['message']}"
                        )
                        results["eliminated"].append({
                            "stock_code": stock['stock_code'],
                            "stock_name": stock.get('stock_name', ''),
                            "reason": reason,
                            "pool_level": level
                        })
        
        logger.info(f"池维护完成: 检查{results['checked']}只，淘汰{len(results['eliminated'])}只")
        return results


if __name__ == "__main__":
    import sys
    
    screener = StockScreener()
    
    if len(sys.argv) > 1:
        code = sys.argv[1]
        
        if sys.argv[2] == "pool1":
            result = screener.check_pool1_criteria(code)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        
        elif sys.argv[2] == "pool2":
            data = get_financial_data(code)
            data['stock_code'] = code
            result = screener.check_pool2_criteria(data)
            print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("测试一级池筛选:")
        result = screener.check_pool1_criteria("000001")
        print(json.dumps(result, ensure_ascii=False, indent=2))
