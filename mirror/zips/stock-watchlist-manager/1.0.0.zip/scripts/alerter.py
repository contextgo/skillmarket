#!/usr/bin/env python3
"""
股票预警监控模块
实时检查止损位/买点/目标位，输出带emoji的预警信息
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

from pool_manager import StockPoolManager
from data_fetcher import get_realtime_quote, refresh_pool_data

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# 预警颜色标记规则
COLOR_RULES = {
    "red": [  # 🔴 红色预警
        {"condition": "price_below_stop_loss", "message": "价格 < 止损位"},
        {"condition": "pe_above_80", "message": "PE > 80"},
        {"condition": "debt_ratio_above_70", "message": "负债率 > 70%"}
    ],
    "yellow": [  # 🟡 黄色预警
        {"condition": "price_near_target", "message": "价格接近目标位"},
        {"condition": "pe_50_80", "message": "PE 50-80"}
    ],
    "green": [  # 🟢 绿色信号
        {"condition": "price_below_buy_point", "message": "价格 ≤ 理想买点"},
        {"condition": "roe_above_20", "message": "ROE > 20%"}
    ],
    "blue": [  # 🔵 正常状态
        {"condition": "normal", "message": "正常持有/跟踪"}
    ]
}


class Alert:
    """预警数据类"""
    def __init__(self, stock_code: str, stock_name: str, alert_type: str,
                 alert_level: str, message: str, current_price: float = None,
                 threshold: float = None, details: Dict[str, Any] = None):
        self.stock_code = stock_code
        self.stock_name = stock_name
        self.alert_type = alert_type  # stop_loss/buy_signal/target_reached/elimination
        self.alert_level = alert_level  # red/yellow/green/blue
        self.message = message
        self.current_price = current_price
        self.threshold = threshold
        self.details = details or {}
        self.timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "stock_code": self.stock_code,
            "stock_name": self.stock_name,
            "alert_type": self.alert_type,
            "alert_level": self.alert_level,
            "message": self.message,
            "current_price": self.current_price,
            "threshold": self.threshold,
            "timestamp": self.timestamp,
            "details": self.details
        }
    
    def format_markdown(self) -> str:
        """格式化输出带emoji的Markdown"""
        emoji_map = {
            "red": "🔴",
            "yellow": "🟡", 
            "green": "🟢",
            "blue": "🔵"
        }
        emoji = emoji_map.get(self.alert_level, "⚪")
        
        lines = [
            f"{emoji} **[{self.alert_type.upper()}]** {self.stock_name}({self.stock_code})",
            f"   - 预警信息: {self.message}"
        ]
        
        if self.current_price:
            lines.append(f"   - 当前价格: {self.current_price:.2f}")
        if self.threshold:
            lines.append(f"   - 设定值: {self.threshold:.2f}")
        
        lines.append(f"   - 时间: {self.timestamp}")
        
        return "\n".join(lines)


class StockAlerter:
    """股票预警监控器"""
    
    def __init__(self, pool_manager: StockPoolManager = None):
        self.pool_manager = pool_manager or StockPoolManager()
        self.alerts: List[Alert] = []
    
    def check_stop_loss(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查止损位
        触发条件: 价格 ≤ 止损位
        """
        current_price = stock.get('current_price')
        stop_loss = stock.get('stop_loss')
        
        if not stop_loss:
            return None
        
        # 获取实时价格
        if not current_price:
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                current_price = quote.get('current_price')
        
        if current_price and stop_loss and current_price <= stop_loss:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="stop_loss",
                alert_level="red",
                message=f"价格{current_price:.2f} ≤ 止损位{stop_loss:.2f}，触发止损！",
                current_price=current_price,
                threshold=stop_loss,
                details={"stop_loss": stop_loss, "distance_pct": (current_price - stop_loss) / stop_loss * 100}
            )
        
        return None
    
    def check_buy_signal(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查买点信号
        触发条件: 价格 ≤ 理想买点
        """
        current_price = stock.get('current_price')
        buy_point = stock.get('buy_point')
        
        if not buy_point:
            return None
        
        if not current_price:
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                current_price = quote.get('current_price')
        
        if current_price and buy_point and current_price <= buy_point:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="buy_signal",
                alert_level="green",
                message=f"价格{current_price:.2f} ≤ 理想买点{buy_point:.2f}，买入信号！",
                current_price=current_price,
                threshold=buy_point,
                details={"buy_point": buy_point, "discount_pct": (buy_point - current_price) / buy_point * 100}
            )
        
        return None
    
    def check_target_reached(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查目标位
        触发条件: 价格 ≥ 第一目标位
        """
        current_price = stock.get('current_price')
        target1 = stock.get('target1')
        
        if not target1:
            return None
        
        if not current_price:
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                current_price = quote.get('current_price')
        
        if current_price and target1 and current_price >= target1:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="target_reached",
                alert_level="yellow",
                message=f"价格{current_price:.2f} ≥ 第一目标位{target1:.2f}，观察是否减持！",
                current_price=current_price,
                threshold=target1,
                details={"target1": target1, "profit_pct": (current_price - stock.get('cost_basis', current_price)) / stock.get('cost_basis', current_price) * 100}
            )
        
        return None
    
    def check_second_target(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查第二目标位
        触发条件: 价格 ≥ 第二目标位
        """
        current_price = stock.get('current_price')
        target2 = stock.get('target2')
        
        if not target2:
            return None
        
        if not current_price:
            quote = get_realtime_quote(stock['stock_code'])
            if quote:
                current_price = quote.get('current_price')
        
        if current_price and target2 and current_price >= target2:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="second_target",
                alert_level="yellow",
                message=f"价格{current_price:.2f} ≥ 第二目标位{target2:.2f}，建议减仓！",
                current_price=current_price,
                threshold=target2,
                details={"target2": target2}
            )
        
        return None
    
    def check_high_pe(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查高PE风险
        触发条件: PE > 80
        """
        pe = stock.get('pe')
        
        if pe and pe > 80:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="high_pe",
                alert_level="red",
                message=f"PE={pe:.2f} > 80，估值偏高风险！",
                current_price=stock.get('current_price'),
                threshold=80,
                details={"pe": pe}
            )
        
        return None
    
    def check_high_debt(self, stock: Dict[str, Any]) -> Optional[Alert]:
        """
        检查高负债率风险
        触发条件: 负债率 > 70%
        """
        debt_ratio = stock.get('debt_ratio')
        
        if debt_ratio and debt_ratio > 70:
            return Alert(
                stock_code=stock['stock_code'],
                stock_name=stock.get('stock_name', ''),
                alert_type="high_debt",
                alert_level="red",
                message=f"负债率={debt_ratio:.2f}% > 70%，债务风险！",
                current_price=stock.get('current_price'),
                threshold=70,
                details={"debt_ratio": debt_ratio}
            )
        
        return None
    
    def check_stock(self, stock: Dict[str, Any]) -> List[Alert]:
        """
        检查单只股票的所有预警条件
        """
        alerts = []
        
        # 获取实时价格
        quote = get_realtime_quote(stock['stock_code'])
        if quote:
            stock.update(quote)
        
        # 检查各项条件
        check_funcs = [
            self.check_stop_loss,
            self.check_buy_signal,
            self.check_target_reached,
            self.check_second_target,
            self.check_high_pe,
            self.check_high_debt
        ]
        
        for check_func in check_funcs:
            try:
                alert = check_func(stock)
                if alert:
                    alerts.append(alert)
            except Exception as e:
                logger.warning(f"检查 {stock['stock_code']} {check_func.__name__} 失败: {e}")
        
        return alerts
    
    def run_all_alerts(self, pool_levels: List[int] = [3, 4]) -> Dict[str, Any]:
        """
        运行所有预警检查
        Args:
            pool_levels: 检查哪些池 (默认3和4)
        """
        self.alerts = []
        results = {
            "total_checked": 0,
            "alerts_found": 0,
            "by_level": {},
            "alerts": []
        }
        
        for level in pool_levels:
            stocks = self.pool_manager.query_pool(level)
            level_alerts = []
            
            for stock in stocks:
                results["total_checked"] += 1
                stock_alerts = self.check_stock(stock)
                level_alerts.extend(stock_alerts)
                self.alerts.extend(stock_alerts)
            
            results["by_level"][f"pool_{level}"] = len(level_alerts)
        
        results["alerts_found"] = len(self.alerts)
        results["alerts"] = [a.to_dict() for a in self.alerts]
        
        logger.info(f"预警检查完成: 检查{results['total_checked']}只，发现{results['alerts_found']}条预警")
        
        return results
    
    def format_alerts_markdown(self, results: Dict[str, Any] = None) -> str:
        """
        格式化预警报告为Markdown
        """
        if results is None:
            results = {
                "alerts_found": len(self.alerts),
                "alerts": [a.to_dict() for a in self.alerts]
            }
        
        if not self.alerts:
            return "🔵 **[正常]** 当前无预警信号"
        
        lines = [
            f"# 预警报告",
            f"- 检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"- 预警数量: {results['alerts_found']}",
            ""
        ]
        
        # 按级别分组
        by_level = {"red": [], "yellow": [], "green": [], "blue": []}
        for alert in self.alerts:
            by_level[alert.alert_level].append(alert)
        
        # 按优先级输出
        for level in ["red", "yellow", "green", "blue"]:
            alerts = by_level[level]
            if alerts:
                lines.append(f"## {level.upper()} 级别预警 ({len(alerts)}条)")
                for alert in alerts:
                    lines.append(alert.format_markdown())
                    lines.append("")
        
        return "\n".join(lines)
    
    def get_stop_loss_triggered(self) -> List[Dict[str, Any]]:
        """
        获取已触发止损的股票
        """
        triggered = []
        for alert in self.alerts:
            if alert.alert_type == "stop_loss":
                triggered.append(alert.to_dict())
        return triggered


if __name__ == "__main__":
    import sys
    
    alerter = StockAlerter()
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "run":
            results = alerter.run_all_alerts([3, 4])
            print(json.dumps(results, ensure_ascii=False, indent=2))
        elif sys.argv[1] == "format":
            alerter.run_all_alerts([3, 4])
            print(alerter.format_alerts_markdown())
    else:
        # 测试
        print("运行预警检查...")
        results = alerter.run_all_alerts([3, 4])
        print(f"\n发现 {results['alerts_found']} 条预警")
        print(alerter.format_alerts_markdown())
