# 股票数据模型定义

## 目录
1. [概览](#概览)
2. [数据库Schema](#数据库schema)
3. [四级池数据模型](#四级池数据模型)
4. [字段说明](#字段说明)

## 概览

系统采用 SQLite 数据库存储四级股票池数据，确保数据持久化和跨会话一致性。

## 数据库Schema

```sql
CREATE TABLE stocks (
    stock_code TEXT PRIMARY KEY,           -- 股票代码 (唯一键)
    stock_name TEXT NOT NULL,               -- 股票名称
    
    -- 池级别
    pool_level INTEGER DEFAULT 1,           -- 1=海选池, 2=关注池, 3=核心池, 4=交易池
    
    -- 基础信息
    industry TEXT DEFAULT '',               -- 所属行业
    listing_date TEXT,                      -- 上市日期
    
    -- ========== 行情数据 ==========
    current_price REAL,                     -- 当前价格
    change_pct REAL,                        -- 涨跌幅(%)
    volume REAL,                            -- 成交量
    amount REAL,                            -- 成交额
    high_60d REAL,                          -- 60日最高
    low_60d REAL,                           -- 60日最低
    
    -- ========== 市值数据 ==========
    total_market_cap REAL,                  -- 总市值(元)
    float_market_cap REAL,                  -- 流通市值(元)
    
    -- ========== 基本面数据 ==========
    pe REAL,                                -- 市盈率(TTM)
    pb REAL,                                -- 市净率(MRQ)
    roe REAL,                               -- 净资产收益率(%)
    revenue_growth REAL,                    -- 营收增长率(%)
    profit_growth REAL,                     -- 净利润增长率(%)
    gross_margin REAL,                      -- 毛利率(%)
    debt_ratio REAL,                        -- 资产负债率(%)
    dividend_yield REAL,                    -- 股息率(%)
    
    -- ========== 资金面数据 ==========
    north_money REAL,                       -- 北向资金持股(股)
    
    -- ========== 交易池专属字段 ==========
    plan_buy_price REAL,                   -- 计划买入价
    plan_buy_qty INTEGER,                  -- 计划买入量
    actual_buy_price REAL,                -- 实际买入价
    cost_basis REAL,                      -- 持仓成本
    current_holding INTEGER,               -- 当前持仓
    floating_pnl REAL,                    -- 浮动盈亏
    
    -- ========== 风控参数 ==========
    stop_loss REAL,                        -- 止损位
    buy_point REAL,                        -- 理想买点
    target1 REAL,                         -- 第一目标位
    target2 REAL,                         -- 第二目标位
    
    -- ========== 分析字段 ==========
    position_suggestion REAL,              -- 仓位建议(%)
    technical_pattern TEXT,                -- 技术形态
    catalyst_event TEXT,                   -- 催化剂事件
    risk_warning TEXT,                    -- 风险提示
    institution_rating TEXT,               -- 机构评级
    valuation_range TEXT,                  -- 估值区间
    safety_margin_price REAL,             -- 安全边际价格
    
    -- ========== 状态管理 ==========
    attention_level INTEGER DEFAULT 3,    -- 关注等级(1-5)
    entry_reason TEXT,                     -- 入选理由
    status TEXT DEFAULT 'active',         -- active=活跃, eliminated=已淘汰
    elimination_reason TEXT,              -- 淘汰原因
    update_date TEXT,                      -- 更新时间
    created_date TEXT                      -- 创建时间
);

-- 索引
CREATE INDEX idx_pool_level ON stocks(pool_level);
CREATE INDEX idx_status ON stocks(status);

-- 操作记录表
CREATE TABLE operations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stock_code TEXT,
    operation TEXT,
    details TEXT,
    created_at TEXT
);
```

## 四级池数据模型

### 一级池：海选池 (Pool Level 1)

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| stock_code | TEXT | 是 | 股票代码 |
| stock_name | TEXT | 是 | 股票名称 |
| pool_level | INTEGER | 是 | 固定为1 |
| industry | TEXT | 否 | 所属行业 |
| total_market_cap | REAL | 是 | 总市值(需>=50亿) |
| pe | REAL | 否 | 市盈率 |
| pb | REAL | 否 | 市净率 |
| change_pct | REAL | 否 | 近期涨跌幅 |
| entry_reason | TEXT | 是 | 入选理由 |
| status | TEXT | 是 | 默认active |

**维护规模**: 50-100只

### 二级池：关注池 (Pool Level 2)

包含一级池所有字段，加上:

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| roe | REAL | 是 | 近3年ROE均值(需>10%) |
| revenue_growth | REAL | 否 | 营收增长率 |
| profit_growth | REAL | 否 | 净利润增长率 |
| gross_margin | REAL | 是 | 毛利率(需稳定或提升) |
| debt_ratio | REAL | 是 | 负债率(需<60%) |
| dividend_yield | REAL | 否 | 股息率 |
| institution_rating | TEXT | 否 | 机构评级 |
| north_money | REAL | 否 | 北向资金持股 |
| technical_pattern | TEXT | 否 | 技术形态 |
| attention_level | INTEGER | 否 | 关注等级(1-5) |

**维护规模**: 20-30只

### 三级池：核心池 (Pool Level 3)

包含二级池所有字段，加上:

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| current_price | REAL | 是 | 当前价格 |
| valuation_range | TEXT | 否 | 估值区间描述 |
| safety_margin_price | REAL | 否 | 安全边际价格 |
| buy_point | REAL | 是 | 理想买点 |
| target1 | REAL | 是 | 第一目标位 |
| target2 | REAL | 否 | 第二目标位 |
| stop_loss | REAL | 是 | 止损位 |
| position_suggestion | REAL | 否 | 仓位建议(%) |
| catalyst_event | TEXT | 否 | 催化剂事件 |
| risk_warning | TEXT | 否 | 风险提示 |

**维护规模**: 10-15只

### 四级池：交易池 (Pool Level 4)

包含三级池所有字段，加上:

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| plan_buy_price | REAL | 是 | 计划买入价 |
| plan_buy_qty | INTEGER | 是 | 计划买入量 |
| actual_buy_price | REAL | 否 | 实际买入价 |
| cost_basis | REAL | 是 | 持仓成本 |
| current_holding | INTEGER | 是 | 当前持仓数量 |
| floating_pnl | REAL | 否 | 浮动盈亏(自动计算) |

**维护规模**: 3-5只

## 字段说明

### 行情数据

| 字段 | 数据来源 | 更新频率 | 说明 |
|------|---------|---------|------|
| current_price | akshare | 实时 | 最新成交价 |
| change_pct | akshare | 实时 | 涨跌幅百分比 |
| volume | akshare | 实时 | 成交量(股) |
| amount | akshare | 实时 | 成交额(元) |
| high_60d | 计算 | 日频 | 近60日最高价 |
| low_60d | 计算 | 日频 | 近60日最低价 |

### 基本面数据

| 字段 | 数据来源 | 更新频率 | 说明 |
|------|---------|---------|------|
| pe | akshare | 日频 | 市盈率TTM |
| pb | akshare | 日频 | 市净率MRQ |
| roe | akshare | 季频 | 净资产收益率 |
| revenue_growth | akshare | 季频 | 营收同比增长率 |
| profit_growth | akshare | 季频 | 净利润同比增长率 |
| gross_margin | akshare | 季频 | 销售毛利率 |
| debt_ratio | akshare | 季频 | 资产负债率 |
| dividend_yield | akshare | 年频 | 股息率 |

### 风控参数计算

```
安全边际价格 = 合理估值 × 0.7

止损位 = 买入价 × (1 - 止损比例)
       = 买入价 × 0.93  (默认止损7%)

理想买点 = 合理估值 × 0.85

第一目标位 = 合理估值 × 1.1

第二目标位 = 合理估值 × 1.2
```

### 状态流转

```
[新增] → 一级池 → 二级池 → 三级池 → 四级池 → [持仓]
                ↓         ↓         ↓         ↓
            [淘汰]     [淘汰]     [淘汰]     [止损/止盈]
```

状态枚举值:
- `active`: 活跃跟踪
- `eliminated`: 已淘汰(记录原因)

### 淘汰原因枚举

| 原因 | 说明 |
|------|------|
| [profit_warning] 净利润同比下滑XX% | 业绩变脸 |
| [regulatory_risk] XX | 监管风险 |
| [technical_break] 价格跌破止损位 | 技术破位 |
| [liquidity_dry] 成交额低于5000万 | 流动性枯竭 |
| manual_removal | 手动移除 |
