# 筛选规则详解

## 目录
1. [概览](#概览)
2. [一级池筛选标准](#一级池筛选标准)
3. [二级池筛选标准](#二级池筛选标准)
4. [强制淘汰机制](#强制淘汰机制)
5. [升级路径](#升级路径)

## 概览

筛选系统采用"宽进严出"原则：
- 入池标准相对宽松，确保不遗漏潜在标的
- 淘汰机制严格执行风控底线

## 一级池筛选标准

### 必须满足条件 (全部通过)

| 条件 | 阈值 | 说明 |
|------|------|------|
| 非ST/*ST | - | 不能是特别处理股票 |
| 总市值 | >= 50亿 | 确保流动性 |
| 上市年限 | > 3年 | 规避次新股风险 |

### 筛选逻辑

```python
def check_pool1_criteria(stock_code: str) -> dict:
    checks = {
        'st_check': check_st_status(stock_code),
        'market_cap_check': check_market_cap(stock_code, 50e8),
        'listing_age_check': check_listing_age(stock_code, 3)
    }
    return all(c['passed'] for c in checks.values())
```

### ST/*ST检测

```python
def check_st_status(stock_code: str) -> (bool, str):
    quote = get_realtime_quote(stock_code)
    name = quote.get('name', '')
    
    st_keywords = ['ST', '*ST', 'S*ST', 'SST']
    for kw in st_keywords:
        if kw in name:
            return False, f"ST股票: {name}"
    
    return True, "正常"
```

### 市值计算

```python
def check_market_cap(stock_code: str, threshold: float = 50e8) -> (bool, str):
    cap_data = get_market_cap(stock_code)
    total_market_cap = cap_data.get('total_market_cap', 0)
    
    # 过滤无效值
    if not total_market_cap or total_market_cap <= 0:
        return False, "市值数据无效"
    
    passed = total_market_cap >= threshold
    return passed, f"市值{total_market_cap/1e8:.2f}亿"
```

### 上市年限计算

```python
from dateutil.parser import parse
from datetime import datetime

def check_listing_age(stock_code: str, years: int = 3) -> (bool, str):
    listing_date = get_listing_date(stock_code)
    
    # 解析日期
    if isinstance(listing_date, str):
        listed = parse(listing_date)
    else:
        listed = listing_date
    
    # 计算年限
    age_days = (datetime.now() - listed).days
    age_years = age_days / 365.25
    
    passed = age_years >= years
    return passed, f"上市{age_years:.1f}年"
```

## 二级池筛选标准

### 必须满足条件 (全部通过)

| 条件 | 阈值 | 说明 |
|------|------|------|
| ROE均值 | > 10% | 近3年ROE均值，体现盈利能力 |
| 毛利率 | 稳定或提升 | 体现竞争优势 |
| 负债率 | < 60% | 财务杠杆风险控制 |

### 筛选逻辑

```python
def check_pool2_criteria(stock_data: dict) -> dict:
    checks = {
        'roe_check': check_roe(stock_data, 10),
        'gross_margin_check': check_gross_margin_trend(stock_data),
        'debt_ratio_check': check_debt_ratio(stock_data, 60)
    }
    return {
        'passed': all(c['passed'] for c in checks.values()),
        'checks': checks
    }
```

### ROE检查

```python
def check_roe(stock_data: dict, threshold: float = 10) -> (bool, str):
    roe = stock_data.get('roe')
    
    # ROE必须存在且为正
    if roe is None or roe <= 0:
        return False, "ROE数据缺失或为负"
    
    passed = roe >= threshold
    return passed, f"ROE={roe:.2f}%"
```

### 毛利率趋势判断

```python
def check_gross_margin_trend(stock_data: dict) -> (bool, str):
    gross_margin = stock_data.get('gross_margin')
    
    if gross_margin is None:
        return False, "毛利率数据缺失"
    
    # 简化判断：毛利率>=20%视为有竞争力
    if gross_margin >= 20:
        return True, f"毛利率={gross_margin:.2f}%，具备竞争力"
    else:
        return False, f"毛利率={gross_margin:.2f}%，偏低"
    
    # 完整逻辑应比较多年趋势:
    # current = stock_data.get('gross_margin_current')
    # previous = stock_data.get('gross_margin_previous')
    # trend = "stable" if abs(current - previous) < 5 else \
    #         "up" if current > previous else "down"
    # return trend != "down", f"毛利率趋势{trend}"
```

### 负债率检查

```python
def check_debt_ratio(stock_data: dict, threshold: float = 60) -> (bool, str):
    debt_ratio = stock_data.get('debt_ratio')
    
    if debt_ratio is None:
        return False, "负债率数据缺失"
    
    passed = debt_ratio < threshold
    return passed, f"负债率={debt_ratio:.2f}%"
```

## 强制淘汰机制

### 触发条件 (任一满足即淘汰)

| 规则 | 条件 | 是否需要确认 |
|------|------|-------------|
| 业绩变脸 | 净利润同比下滑>50% | 是(需用户确认) |
| 监管风险 | 出现特定关键词 | 否 |
| 技术破位 | 跌破止损位或60日最低 | 否 |
| 流动性枯竭 | 连续5日均成交额<5000万 | 否 |

### 淘汰逻辑

```python
def check_elimination_rules(stock: dict) -> list:
    reasons = []
    
    # 1. 业绩变脸
    profit_growth = stock.get('profit_growth')
    if profit_growth and profit_growth < -50:
        reasons.append({
            'type': 'profit_warning',
            'message': f'净利润同比下滑{abs(profit_growth):.1f}%',
            'require_confirmation': True
        })
    
    # 2. 监管风险 (需要新闻API)
    # news = fetch_news(stock['stock_code'])
    # for keyword in ['立案调查', '违法违规', '控制人被调查']:
    #     if keyword in news:
    #         reasons.append({'type': 'regulatory_risk', ...})
    
    # 3. 技术破位
    current_price = stock.get('current_price')
    stop_loss = stock.get('stop_loss')
    low_60d = stock.get('low_60d')
    
    if current_price and stop_loss and current_price <= stop_loss:
        reasons.append({
            'type': 'technical_break',
            'message': f'价格{current_price}跌破止损位{stop_loss}',
            'require_confirmation': False
        })
    
    if current_price and low_60d and current_price <= low_60d:
        reasons.append({
            'type': 'technical_break',
            'message': f'价格{current_price}跌破60日最低{low_60d}',
            'require_confirmation': False
        })
    
    # 4. 流动性枯竭
    amount = stock.get('amount', 0)
    if amount and amount < 5000 * 1e4:  # 5000万
        reasons.append({
            'type': 'liquidity_dry',
            'message': f'成交额{amount/1e4:.0f}万，低于5000万',
            'require_confirmation': False
        })
    
    return reasons
```

### 淘汰处理流程

```
检查淘汰规则
    │
    ├─── 需要确认 ───→ 记录到待确认列表，输出预警
    │
    └─── 无需确认 ───→ 直接移除，更新状态为"eliminated"
```

## 升级路径

### 一级池 → 二级池

1. 从一级池获取候选股票列表
2. 获取每只股票的完整基本面数据
3. 执行二级池筛选标准检查
4. 计算升级评分
5. 按评分排序，取TOP N

### 升级评分公式

```
总分 = ROE得分 + 毛利率得分 + 增长得分 + 资金得分

ROE得分 = min(ROE, 30)           # 封顶30分
毛利率得分 = min(毛利率/2, 20)   # 封顶20分
营收增长得分 = min(营收增长率, 15)  # 封顶15分
净利润增长得分 = min(净利润增长率, 15)  # 封顶15分
北向资金得分 = min(北向资金/亿, 20)  # 封顶20分
```

### 池容量控制

| 池 | 建议容量 | 硬上限 |
|----|---------|--------|
| 一级池 | 50-100 | 150 |
| 二级池 | 20-30 | 50 |
| 三级池 | 10-15 | 20 |
| 四级池 | 3-5 | 10 |

当池容量超过硬上限时，触发淘汰流程，优先淘汰评分最低的股票。
