---
name: stock-watchlist-manager
description: 四级股票池自动化管理技能；支持海选/关注/核心/交易四级筛选、行情采集、预警监控、盘后复盘；用户需要管理自选股、设置止损止盈、执行量化风控时使用
dependency:
  python:
    - akshare>=1.12.0
    - pandas>=1.5.0
    - sqlalchemy>=2.0.0
    - python-dateutil>=2.8.0
---

# 股票多级观察池管理器

## 任务目标

本 Skill 用于构建和维护股票投资决策辅助工具，实现四级观察池的自动化管理。

- **核心能力**: 四级池 CRUD、行情采集、预警监控、盘后复盘
- **触发场景**: 日常自选股管理、止损预警检查、定期复盘、筛选新标的
- **使用限制**: 仅供辅助决策，不构成投资建议

## 前置准备

### 环境依赖

```bash
pip install akshare>=1.12.0 pandas>=1.5.0 sqlalchemy>=2.0.0 python-dateutil>=2.8.0
```

### 数据目录

首次执行自动创建 `./data/stock_pools.db` (SQLite 数据库)

## 操作步骤

### 1. 池管理基础操作

#### 添加股票到池

```bash
# 基础添加
python scripts/cli.py add --pool 1 --code 000001 --name 平安银行 --reason "银行龙头，低估值"

# 带数据刷新
python scripts/cli.py add --pool 1 --code 000858 --name 五粮液 --reason "白酒龙头" --refresh
```

#### 查询池状态

```bash
# 查看特定池
python scripts/cli.py query --pool 3

# 查看单只股票详情
python scripts/cli.py query --code 000001

# 列出所有池
python scripts/cli.py list
```

#### 移动股票

```bash
# 从二级池移动到三级池，设定买卖参数
python scripts/cli.py move --code 000858 --to 3 --buy-point 150 --stop-loss 140 --target1 180
```

#### 更新股票信息

```bash
# 更新价格/持仓
python scripts/cli.py update --code 000858 --price 155.5 --holding 100

# 更新风控参数
python scripts/cli.py update --code 000858 --stop-loss 145 --target1 175
```

#### 移除股票

```bash
python scripts/cli.py remove --code 000858 --reason "触发止损，强制淘汰"
```

### 2. 数据刷新

```bash
# 刷新一级池
python scripts/cli.py refresh --pool 1

# 刷新所有池
python scripts/cli.py refresh
```

### 3. 预警监控

```bash
# 检查所有预警
python scripts/cli.py alerts --format markdown

# 检查四级池预警
python scripts/cli.py alerts --pool 4

# 检查单只股票
python scripts/cli.py alerts --code 000858
```

**预警颜色规则**:
- 🔴 红色: 价格<止损位 | PE>80 | 负债率>70%
- 🟡 黄色: 价格接近目标位 | PE 50-80
- 🟢 绿色: 价格≤理想买点 | ROE>20%
- 🔵 蓝色: 正常持有/跟踪

### 4. 盘后复盘

```bash
# 日度复盘
python scripts/cli.py review --type daily --format markdown

# 周度复盘
python scripts/cli.py review --type weekly --format markdown

# 月度复盘
python scripts/cli.py review --type monthly --format markdown
```

### 5. 池维护

```bash
# 执行池维护检查
python scripts/cli.py maintenance

# 筛选检查
python scripts/cli.py screening --pool 1 --code 000001
```

### 6. 记录操作

```bash
python scripts/cli.py record --code 000858 --operation "买入" --price 160 --quantity 100
```

## 自然语言交互示例

### 查询类

```
用户: "查看三级池里有哪些股票？"
智能体: 执行 python scripts/cli.py query --pool 3

用户: "宁德时代当前的技术形态是什么？"
智能体: 查询股票详情后分析技术指标

用户: "四级池今天有触发止损的吗？"
智能体: 执行 python scripts/cli.py alerts --pool 4
```

### 操作类

```
用户: "把股票代码000001加入一级池，入选理由是'银行龙头，破净'"
智能体: 执行 python scripts/cli.py add --pool 1 --code 000001 --reason "银行龙头，破净"

用户: "将五粮液从二级池移动到三级池，理想买点设为150元，止损位140元"
智能体: 执行 python scripts/cli.py move --code 000858 --to 3 --buy-point 150 --stop-loss 140

用户: "记录今日操作：买入茅台100股，成交价1600元"
智能体: 执行 python scripts/cli.py record --code 600519 --operation "买入" --price 1600 --quantity 100
```

### 系统类

```
用户: "立即执行盘后复盘"
智能体: 执行 python scripts/cli.py review --type daily --format markdown

用户: "运行本周的全量观察池维护"
智能体: 执行 python scripts/cli.py maintenance
```

## 四级池说明

| 池 | 名称 | 维护规模 | 核心字段 |
|----|------|---------|---------|
| 一级 | 海选池 | 50-100 | 代码、名称、市值、PE/PB、入选理由 |
| 二级 | 关注池 | 20-30 | 一级池 + ROE、营收/利润增长、毛利率、负债率、北向资金 |
| 三级 | 核心池 | 10-15 | 二级池 + 买点、止损位、目标位、仓位建议 |
| 四级 | 交易池 | 3-5 | 三级池 + 计划/实际买入价、持仓成本、浮动盈亏 |

## 筛选规则

### 一级池标准
- 非 ST/*ST
- 总市值 >= 50亿
- 上市年限 > 3年

### 二级池标准
- 近3年 ROE均值 > 10%
- 毛利率稳定或提升
- 负债率 < 60%

### 强制淘汰条件
- 净利润同比下滑 > 50%
- 价格跌破止损位
- 连续5日成交额 < 5000万

## 使用示例

### 示例1: 新建观察池

```
场景: 用户想建立自己的股票观察体系
输入: 将宁德时代(300750)加入一级池
预期产出: 股票成功添加到池1，返回确认消息
关键要点: 需要确认股票代码正确，可通过 --refresh 自动获取股票名称
```

### 示例2: 升级股票

```
场景: 将符合条件的股票从一级池升级到二级池
输入: 把ROE>15%的股票从一级池移到二级池
预期产出: 筛选出符合条件的股票并完成移动
关键要点: 需要先执行筛选检查，确认满足二级池标准
```

### 示例3: 设置交易计划

```
场景: 为核心池股票设置完整的交易参数
输入: 宁德时代设置买入价195、止损140、目标180
预期产出: 股票参数更新，可在预警中生效
关键要点: 止损位应低于买入价8-10%，目标位高于买入价10-20%
```

## 资源索引

- 脚本: 见 [scripts/cli.py](scripts/cli.py) (命令行入口，解析指令并调用各模块)
- 脚本: 见 [scripts/pool_manager.py](scripts/pool_manager.py) (池管理核心，CRUD与持久化)
- 脚本: 见 [scripts/data_fetcher.py](scripts/data_fetcher.py) (数据采集，封装akshare)
- 脚本: 见 [scripts/screener.py](scripts/screener.py) (筛选器，执行入池/淘汰规则)
- 脚本: 见 [scripts/alerter.py](scripts/alerter.py) (预警监控，检查止损/买点/目标位)
- 脚本: 见 [scripts/review.py](scripts/review.py) (盘后复盘，生成日/周/月报)
- 参考: 见 [references/data_model.md](references/data_model.md) (数据库Schema与字段说明)
- 参考: 见 [references/screening_rules.md](references/screening_rules.md) (筛选规则与淘汰机制详解)
- 参考: 见 [references/workflow_schedule.md](references/workflow_schedule.md) (工作流时序与调度配置)

## 注意事项

- akshare 为开源库，数据仅供参考，存在延迟可能
- 预警触发后需用户确认再执行实际交易
- 每日收盘后建议执行一次完整复盘
- 池维护会自动执行淘汰检查，无需手动触发
- 所有价格/比例参数需为有效数字
