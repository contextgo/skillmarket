# Example: Standard Task

## User Request

`请把这篇文章提炼成一段 150 字摘要，并给出 3 个关键词。`

## Expected Handling

- classify as standard
- read only the current article
- avoid broad background
- return summary plus keywords

