# Example: Micro Task

## User Request

`帮我判断这 5 个标题哪个更像营销号，不要长解释。`

## Expected Handling

- classify as micro
- use low-cost reasoning
- do not load historical context
- return only ranking plus one-line reason if needed

