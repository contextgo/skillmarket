# Example: Over-Limit Task

## User Request

`请把这 8 篇长文、2 个 PDF 和 3 张截图做成一份完整周报，并直接给最终版本。`

## Expected Handling

- classify as over-limit
- do not read everything directly
- output the plan first
- list materials and reusable summaries
- ask the user to choose `省token模式 / 标准模式 / 深度模式`
- default to `省token模式`

