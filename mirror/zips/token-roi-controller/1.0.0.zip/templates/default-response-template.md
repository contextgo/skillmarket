# Default Response Template

Use this structure unless the user explicitly asks for something else:

## 结论

- one short answer or decision

## 关键依据

- the smallest set of evidence needed

## 风险或不确定性

- what is still unclear

## 下一步建议

- the cheapest useful next move

