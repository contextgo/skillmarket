# Over-Limit Plan Template

当任务预计超限时，先输出：

## 任务目标

- the exact outcome the user wants

## 需要读取的材料

- list only the materials that appear necessary

## 可复用的已有摘要

- existing summaries, caches, or structured notes

## 拆分步骤

1. indexing
2. triage
3. selective deep read
4. synthesis

## 预计成本

- classify as deep or over-limit
- state the likely cost driver

## 是否需要确认继续

- ask the user to choose `省token模式 / 标准模式 / 深度模式`

