# Long Document Processing

## Required Flow

For long articles, PDFs, videos with transcripts, screenshots, or notebooks, use this order:

1. assign `ArticleID`
2. record source, title, and link
3. generate a compact index
4. write a short summary
5. extract keywords and core claims
6. decide whether deeper reading is justified
7. deepen only selected sections
8. store structured output for reuse

## Do Not Do This By Default

- do not send the full document plus historical chat in one request
- do not attach appendices unless they directly affect the answer
- do not merge many retrieval results before a usefulness check
- do not OCR every image if a caption or existing summary already answers the question

## High-Value Signals

Deeper reading is justified only when a section provides one of these:

- direct evidence for the user question
- unique data that is not already summarized
- contradiction with other sources
- final citation material needed for reporting

