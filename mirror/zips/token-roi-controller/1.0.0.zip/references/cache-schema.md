# Cache Schema

## Required Identifier

Every reusable material item should have a unique `ArticleID`.

Recommended pattern:

```text
source-shortname_yyyymmdd_slug
```

## Reusable Fields

If these fields already exist, do not re-run full parsing:

- `ArticleID`
- `title`
- `source`
- `url`
- `summary`
- `keywords`
- `core_claims`
- `citations`
- `deep_read_conclusion`

## Reuse Policy

1. For daily reporting, read only the structured record first.
2. For weekly reporting, aggregate daily structured records first.
3. Only go back to raw material when a citation or contradiction needs verification.
4. If multiple summaries exist, prefer the newest validated structured record.

