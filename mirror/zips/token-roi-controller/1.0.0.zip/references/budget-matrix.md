# Budget Matrix

## Budget Ladder

Use this matrix to map task type to budget, read scope, and model tier.

| Task class | Typical work | Budget target | Read scope | Preferred tier |
| --- | --- | --- | --- | --- |
| Micro | 分类, 去重, 标题判断, 单句改写 | `<= 2` credits | current snippet only | low-cost |
| Standard | 单篇提炼, 普通写作, 简单整理 | `<= 10` credits | one article or one slice | mid-cost |
| Deep | 多文档对比, 周报, 长报告 | `<= 25` credits | indexed slices only | mid-cost plus high-tier only where justified |
| Over-limit | 大量材料, 多轮工具, 长报告 plus full parsing | `> 25` credits | no direct full read | plan first |

## Decision Rules

1. If the task can be completed from a short excerpt, never escalate read scope.
2. If the task needs more than three long materials, treat it as deep or over-limit immediately.
3. If output is a report, proposal, or synthesis, check whether structured summaries already exist before reading raw material.
4. If the system cannot reliably measure credits, treat the ladder as a policy threshold rather than a literal billing guarantee.

