# Changelog

## v1.0.0

- initial public release of `token-roi-controller`
- added budget ladder, model routing, long-document triage, cache rules, and over-limit protection
- added validation and packaging scripts for GitHub, SkillHub, and ClawHub distribution
