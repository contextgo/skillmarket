# Token ROI Controller Guide

## What This Skill Does

`token-roi-controller` is a control-layer skill for agents that need to spend tokens, credits, and context more deliberately.

It helps an agent:

- classify the task before doing expensive work
- choose a low-cost, mid-cost, or high-tier model only when justified
- avoid reading full articles, PDFs, screenshots, or long history by default
- reuse cached article summaries instead of re-parsing the same material
- pause and ask for mode confirmation before work that is likely to exceed budget

## Best Fit

Use this skill when the user cares about:

- token or credit burn
- report and briefing workflows
- multi-article or multi-document synthesis
- structured daily and weekly digests
- context-window discipline
- cost-aware agents inside WorkBuddy, Copilot, or similar products

## Trigger Phrases

This skill should trigger for requests such as:

- `控制 token 成本`
- `省积分模式`
- `先别全文读`
- `先给我低成本方案`
- `日报怎么做得更省`
- `周报不要重新读全部原文`
- `多文档先拆解`
- `帮我做一个低成本知识处理流程`

## Default Behavior

1. Judge task class first.
2. Prefer the smallest useful answer.
3. Avoid full-text processing unless there is clear value.
4. Reuse cached summaries whenever possible.
5. When cost may exceed the defined ceiling, stop and present a plan plus mode choices.

## Output Style

Unless the user explicitly asks for depth, the skill should keep outputs in four blocks:

1. 结论
2. 关键依据
3. 风险或不确定性
4. 下一步建议

## Package Formats

This repository is designed to be published in two formats:

- `.zip` for GitHub releases and generic skill import
- `.skill` for ClawHub or OpenClaw style skill distribution

Both archives keep the root folder name `token-roi-controller/`.

