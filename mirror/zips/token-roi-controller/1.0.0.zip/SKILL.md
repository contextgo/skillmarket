---
name: token-roi-controller
description: Use when the user wants strict control over token, credit, or context spend before the agent reads long materials, combines multiple sources, or produces large reports. Classify work into micro, standard, deep, or over-limit tasks; route model tier accordingly; prefer indexing and cached summaries over full-text reading; and default to token-saving mode unless the user explicitly approves deeper processing.
---

# Token ROI Controller

## Purpose

Use this skill as a token and credit governor for agent workflows.

Core instruction:

`You are a highly ROI-conscious agent. Before doing any substantial work, classify the task by scope, cost, and material load. Default to token-saving mode. Do not read full long documents, combine large context bundles, or use high-tier reasoning unless the task clearly justifies that cost.`

中文原则：

`你是一个极度重视 token 投入产出比的智能体。收到任务后，先判断复杂度、预算、模型路由和材料读取范围。默认使用省 token 模式。未经必要性证明，不得全文读取、不做高阶模型推理、不进行长报告级处理。`

Read [budget-matrix.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/references/budget-matrix.md) first when the task involves multiple materials, reports, or budget-sensitive execution.

Read [long-document-processing.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/references/long-document-processing.md) when the task touches articles, PDFs, screenshots, or other long inputs.

Read [cache-schema.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/references/cache-schema.md) when summaries, ArticleID, or structured report storage are relevant.

## When To Use This Skill

Use this skill when the user asks for:

- token, credit, or积分控制
- low-cost news, research, or information workflows
- daily or weekly reports
- multi-document comparison
- article triage before deep reading
- large requests that should be decomposed before execution
- a default `省token模式`

Typical trigger phrases include:

- `先省 token`
- `先不要读全文`
- `帮我控制积分`
- `先做低成本版本`
- `日报怎么省着做`
- `周报不要重读原文`
- `多篇材料先拆开`
- `超过预算先停下来`

## When Not To Use This Skill

Do not slow down simple and tiny tasks that are already obviously cheap, such as:

- single-sentence rewriting
- one short classification
- one-line translation
- tiny command explanations
- short summaries of already-short text

If the task is already small and clear, act directly with the smallest useful answer.

## Task Entry Judgment

Classify every request into exactly one of these classes before doing substantial work.

### 1. Micro Task

Typical scope:

- 分类
- 去重
- 短摘要
- 标题判断
- 单句改写

Rules:

- budget target: `<= 2` credits
- prefer low-cost models
- avoid loading historical context unless required
- return only the smallest useful answer

### 2. Standard Task

Typical scope:

- 单篇文章提炼
- 普通文案写作
- 表格整理
- 简单方案输出

Rules:

- budget target: `<= 10` credits
- prefer mid-cost models
- read only the current article or current task slice
- avoid adding optional background

### 3. Deep Task

Typical scope:

- 多文档对比
- 学术论证
- 长报告
- 周报或月报

Rules:

- budget target: `<= 25` credits
- decompose before execution
- never process all full text in one shot
- decide what deserves deep reading after indexing and triage

### 4. Over-Limit Task

If expected cost is above `25` credits, or the task has obvious signs of runaway material load, do not continue directly.

You must pause and output:

1. 任务目标
2. 需要读取的材料
3. 可复用的已有摘要
4. 拆分步骤
5. 预计成本
6. 是否需要用户确认继续

Then use [over-limit-plan-template.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/templates/over-limit-plan-template.md).

## Model Routing Rules

Use capability tiers, not named vendor models, unless the runtime already names them.

- `Low-cost model`
  - classification
  - deduplication
  - short summary
  - keyword extraction
  - initial material triage
- `Mid-cost model`
  - Chinese organization
  - normal writing
  - teaching design
  - first-draft public writing
- `High-tier model`
  - complex reasoning
  - academic argument
  - final synthesis
- `Vision model`
  - only when images, screenshots, or table images must be read

`auto-pro` or equivalent highest-cost autopilot must not be the default. Use it only when the task clearly qualifies as a deep task and the extra reasoning is justified.

## Long-Document Processing Rules

Never put full text, full history, many knowledge-base results, and appendices into the same request by default.

For long articles, PDFs, or long reports, follow this exact order:

1. build a document index
2. extract title, summary, keywords, and core claims
3. decide whether the document is worth deeper reading
4. deeply process only high-value sections
5. keep only necessary evidence in the final report
6. treat appendices as separate material, not as default reasoning context

Use [long-document-processing.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/references/long-document-processing.md) if the material load is non-trivial.

## Daily Brief Rules

Daily reports must not default to full-text reading.

Follow this order:

1. collect candidate items
2. deduplicate
3. generate a `100`-character summary for each
4. decide what is worth deeper reading
5. deeply process only top `3-5` items
6. save structured results
7. make the noon summary from structured results only, not by re-reading original material

## Weekly Report Rules

Weekly reports must read only the structured daily results for the current week.

Do not re-read all source articles.

If citation is needed, look up the relevant entry by `ArticleID`.

## Cache Rules

Every article, PDF, or public-link item must get a unique `ArticleID`.

If the system already has these fields, do not re-run full parsing:

- 标题
- 来源
- 链接
- 摘要
- 关键词
- 核心观点
- 引用信息
- 深读结论

Use [cache-schema.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/references/cache-schema.md) when a workflow stores or reuses structured results.

## Output Control

Unless the user explicitly asks otherwise, return only:

1. 结论
2. 关键依据
3. 风险或不确定性
4. 下一步建议

Do not add long background sections by default.

Use [default-response-template.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/templates/default-response-template.md) for the preferred response shape.

## Over-Limit Protection

If any of the following is true, remind the user or automatically downgrade depth:

- the task may exceed `25` credits
- multiple model tiers would be needed
- more than `3` long documents would be read
- image, video, or PDF full-text processing would be needed
- a PDF, long report, or weekly report would be generated
- the same task would require many tool turns

Required handling:

1. output a plan first
2. ask the user to choose `省token模式 / 标准模式 / 深度模式`
3. default to `省token模式`

Use [mode-choice-template.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/templates/mode-choice-template.md) when prompting for the choice.

## Execution Style

The default delivery order is:

1. classify the task
2. decide whether full reading is necessary
3. reuse cache if possible
4. pick the lowest justified model tier
5. answer with the minimal useful structure

If the user never asks for depth, stay concise.

If the user asks for a large output but the material cost is unclear, pause and use the over-limit template before proceeding.

## Examples

See:

- [example-micro-task.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/examples/example-micro-task.md)
- [example-standard-task.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/examples/example-standard-task.md)
- [example-over-limit-task.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/examples/example-over-limit-task.md)

