#!/usr/bin/env python3
"""Validate the token-roi-controller skill package."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


REQUIRED_DIRS = ["references", "templates", "examples", "tests", "scripts"]
REQUIRED_FILES = [
    ".gitignore",
    "CHANGELOG.md",
    "GUIDE.md",
    "LICENSE",
    "README.md",
    "SKILL.md",
    "VERSION",
    "references/budget-matrix.md",
    "references/long-document-processing.md",
    "references/cache-schema.md",
    "templates/default-response-template.md",
    "templates/mode-choice-template.md",
    "templates/over-limit-plan-template.md",
    "examples/example-micro-task.md",
    "examples/example-standard-task.md",
    "examples/example-over-limit-task.md",
    "tests/sample_inputs.md",
    "tests/pre_publish_checklist.md",
    "scripts/validate_skill.py",
    "scripts/package_skill.py",
]

SKILL_SECTIONS = [
    "## Purpose",
    "## When To Use This Skill",
    "## When Not To Use This Skill",
    "## Task Entry Judgment",
    "## Model Routing Rules",
    "## Long-Document Processing Rules",
    "## Daily Brief Rules",
    "## Weekly Report Rules",
    "## Cache Rules",
    "## Output Control",
    "## Over-Limit Protection",
]

TEXT_SUFFIXES = {".md", ".py", ".txt", ".json", ".yaml", ".yml"}
FRONTMATTER_KEY_RE = re.compile(r"^[a-z][a-z0-9_-]*:\s*.+$")
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


def parse_frontmatter(skill_file: Path) -> tuple[dict[str, str], list[str]]:
    errors: list[str] = []
    lines = skill_file.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        return {}, ["SKILL.md is missing YAML frontmatter."]

    closing_index = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            closing_index = index
            break
    if closing_index is None:
        return {}, ["SKILL.md frontmatter is not closed with '---'."]

    data: dict[str, str] = {}
    for line in lines[1:closing_index]:
        if not FRONTMATTER_KEY_RE.match(line):
            errors.append(f"Invalid frontmatter line: {line}")
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()

    allowed_keys = {"name", "description"}
    missing = allowed_keys - set(data)
    extra = set(data) - allowed_keys
    if missing:
        errors.append(f"Frontmatter missing required keys: {', '.join(sorted(missing))}")
    if extra:
        errors.append(f"Frontmatter contains unsupported keys: {', '.join(sorted(extra))}")
    return data, errors


def iter_text_files(root: Path):
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in {"SKILL.md", "README.md"}:
            yield path


def validate_skill_root(root: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not root.is_dir():
        return [f"Skill root is not a directory: {root}"], warnings

    for required_dir in REQUIRED_DIRS:
        if not (root / required_dir).is_dir():
            errors.append(f"Missing required directory: {required_dir}")

    for required_file in REQUIRED_FILES:
        if not (root / required_file).is_file():
            errors.append(f"Missing required file: {required_file}")

    skill_file = root / "SKILL.md"
    if skill_file.is_file():
        frontmatter, fm_errors = parse_frontmatter(skill_file)
        errors.extend(fm_errors)
        if frontmatter.get("name") != root.name:
            errors.append("Frontmatter name must match the folder name.")
        skill_text = skill_file.read_text(encoding="utf-8")
        for section in SKILL_SECTIONS:
            if section not in skill_text:
                errors.append(f"SKILL.md is missing required section: {section}")
        if "省token模式" not in skill_text:
            errors.append("SKILL.md must include the default `省token模式` rule.")

    version_file = root / "VERSION"
    if version_file.is_file():
        version = version_file.read_text(encoding="utf-8").strip()
        if not SEMVER_RE.fullmatch(version):
            errors.append("VERSION must use semver like 1.0.0.")

    for path in iter_text_files(root):
        text = path.read_text(encoding="utf-8")
        if "\t" in text:
            warnings.append(f"Tab character found in {path.relative_to(root)}")

    return errors, warnings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate the token-roi-controller skill package.")
    parser.add_argument("root", nargs="?", default=".", help="Path to the skill root")
    args = parser.parse_args(argv)

    root = Path(args.root).resolve()
    errors, warnings = validate_skill_root(root)

    print(f"Validating skill root: {root}")
    for item in warnings:
        print(f"[WARN] {item}")
    if errors:
        for item in errors:
            print(f"[FAIL] {item}")
        return 1
    print("[OK] Skill package validation passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
