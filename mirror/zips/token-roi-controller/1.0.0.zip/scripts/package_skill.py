#!/usr/bin/env python3
"""Package the token-roi-controller skill as .zip and .skill archives."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
WORKSPACE_ROOT = SKILL_ROOT.parent

if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import validate_skill  # noqa: E402


EXCLUDED_DIR_NAMES = {"__pycache__", "__MACOSX", ".git"}
EXCLUDED_FILE_NAMES = {".DS_Store"}
EXCLUDED_SUFFIXES = {".pyc"}
SKILLHUB_BLOCKLIST = {".gitignore", "LICENSE", "VERSION"}


def should_include(path: Path, channel: str) -> bool:
    if set(path.parts) & EXCLUDED_DIR_NAMES:
        return False
    if path.name in EXCLUDED_FILE_NAMES:
        return False
    if path.suffix in EXCLUDED_SUFFIXES:
        return False
    if channel == "skillhub" and path.name in SKILLHUB_BLOCKLIST:
        return False
    return True


def read_version() -> str:
    version = (SKILL_ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if not version:
        raise ValueError("VERSION file is empty.")
    return version


def build_archive(output_path: Path, channel: str) -> None:
    if output_path.exists():
        output_path.unlink()

    with ZipFile(output_path, "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(SKILL_ROOT.rglob("*")):
            if path.is_dir() or not should_include(path, channel):
                continue
            arcname = Path(SKILL_ROOT.name) / path.relative_to(SKILL_ROOT)
            archive.write(path, arcname.as_posix())


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Package token-roi-controller for standard or SkillHub-compatible upload."
    )
    parser.add_argument(
        "--channel",
        choices=["standard", "skillhub"],
        default="standard",
        help="Packaging profile. 'skillhub' excludes .gitignore, LICENSE, VERSION from archives.",
    )
    args = parser.parse_args()

    errors, warnings = validate_skill.validate_skill_root(SKILL_ROOT)
    print(f"Packaging skill from: {SKILL_ROOT}")
    print(f"Packaging profile: {args.channel}")
    for item in warnings:
        print(f"[WARN] {item}")
    if errors:
        print("[FAIL] Validation failed. Packaging aborted.")
        for item in errors:
            print(f"  - {item}")
        return 1

    version = read_version()
    version_tag = f"v{version}"

    outputs = [
        WORKSPACE_ROOT / f"{SKILL_ROOT.name}-{version_tag}.zip",
        WORKSPACE_ROOT / f"{SKILL_ROOT.name}-{version_tag}.skill",
        WORKSPACE_ROOT / f"{SKILL_ROOT.name}.zip",
        WORKSPACE_ROOT / f"{SKILL_ROOT.name}.skill",
    ]

    for output_path in outputs:
        if args.channel == "standard":
            build_archive(output_path, args.channel)
            continue

        if output_path.suffix == ".zip":
            skillhub_name = output_path.stem + "-skillhub.zip"
            build_archive(output_path.with_name(skillhub_name), args.channel)
            continue

        if output_path.suffix == ".skill":
            skillhub_name = output_path.stem + "-skillhub.skill"
            build_archive(output_path.with_name(skillhub_name), args.channel)
            continue

    print("[OK] Archives created:")
    if args.channel == "standard":
        for output_path in outputs:
            print(f"  - {output_path}")
    else:
        for output_path in outputs:
            if output_path.suffix == ".zip":
                print(f"  - {output_path.with_name(output_path.stem + '-skillhub.zip')}")
            if output_path.suffix == ".skill":
                print(f"  - {output_path.with_name(output_path.stem + '-skillhub.skill')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
