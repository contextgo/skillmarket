# token-roi-controller

A publishable token-governance skill for WorkBuddy, agent copilots, OpenClaw, QClaw, Codex-style environments, and other systems where token, credit, and context cost must be controlled before execution expands.

Keep agent work cheap by default, escalate only when value is proven.

## Current Version

- Current version: `v1.0.0`
- Skill file: [SKILL.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/SKILL.md)
- Public guide: [GUIDE.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/GUIDE.md)
- Change history: [CHANGELOG.md](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/CHANGELOG.md)
- License: [LICENSE](/Volumes/AlfredLi-1T/GPT_CodeX/token-roi-controller/LICENSE)

## What This Skill Solves

Many agent workflows overspend for predictable reasons:

- they read full text before checking whether the task deserves it
- they combine too much context into one request
- they redo parsing even when structured summaries already exist
- they use expensive models for triage work
- they jump into large reports before budget and scope are confirmed

`token-roi-controller` adds a discipline layer before any of that happens.

## Highlights

- classifies each task as micro, standard, deep, or over-limit
- maps each task class to a target credit budget
- routes low-cost work away from high-tier models
- enforces staged long-document handling instead of default full reading
- protects daily and weekly reporting workflows from redundant re-reading
- standardizes cache reuse with `ArticleID`
- forces an explicit pause before work that may exceed the defined ceiling

## Best Fit

Use this skill when the user wants:

- lower token or credit burn
- cheaper daily news or research briefings
- structured weekly reports that reuse prior summaries
- cautious multi-document synthesis
- a default `省token模式`

## Package Contents

- `SKILL.md`
- `README.md`
- `GUIDE.md`
- `CHANGELOG.md`
- `LICENSE`
- `VERSION`
- `references/`
- `templates/`
- `examples/`
- `tests/`
- `scripts/`

## Repository Structure

```text
token-roi-controller/
├── .gitignore
├── CHANGELOG.md
├── GUIDE.md
├── LICENSE
├── README.md
├── SKILL.md
├── VERSION
├── examples/
├── references/
├── scripts/
├── templates/
└── tests/
```

## GitHub About

Suggested repository description:

```text
A token ROI control skill for agent systems. Classifies task cost, limits full-text reads, reuses cached summaries, and forces over-budget work into a confirmation-first flow.
```

Suggested topics:

```text
agent-skill
skillhub
clawhub
token-optimization
context-engineering
workflow-control
knowledge-automation
reporting
prompt-engineering
ai-agents
```

## How To Validate

```bash
python3 scripts/validate_skill.py .
```

## How To Package

```bash
python3 scripts/package_skill.py
```

This creates four archives in the workspace root:

- `token-roi-controller-v1.0.0.zip`
- `token-roi-controller-v1.0.0.skill`
- `token-roi-controller.zip`
- `token-roi-controller.skill`

For SkillHub-compatible archives (exclude `.gitignore`, `LICENSE`, `VERSION`):

```bash
python3 scripts/package_skill.py --channel skillhub
```

This creates:

- `token-roi-controller-v1.0.0-skillhub.zip`
- `token-roi-controller-v1.0.0-skillhub.skill`
- `token-roi-controller-skillhub.zip`
- `token-roi-controller-skillhub.skill`

## How To Publish To SkillHub Or ClawHub

Suggested flow:

1. Run `python3 scripts/validate_skill.py .`
2. Confirm every item in `tests/pre_publish_checklist.md`
3. Generate `.zip` and `.skill`
4. Check that the archive keeps the root folder `token-roi-controller/`
5. Fill the SkillHub or ClawHub listing with the repository description, tags, and short pitch
6. For SkillHub, upload `token-roi-controller-v1.0.0-skillhub.zip`
7. For ClawHub, upload `token-roi-controller-v1.0.0.skill` or `token-roi-controller.skill`
8. State clearly in the listing that this skill defaults to token-saving mode and does not require full-text reading by default

## Safety Position

This skill is designed to reduce cost, not to bypass safety.

It should not be used to:

- read private materials without explicit permission
- force OCR or full parsing of all uploads by default
- hide over-budget work from the user
- claim a precise token or credit cost that the runtime cannot actually measure
