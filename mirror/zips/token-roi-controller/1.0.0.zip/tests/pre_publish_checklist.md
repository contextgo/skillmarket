# Pre-Publish Checklist

Use this before publishing to GitHub, SkillHub, or ClawHub.

- [ ] `SKILL.md` frontmatter contains only `name` and `description`
- [ ] `VERSION` uses semver
- [ ] `README.md`, `GUIDE.md`, and `CHANGELOG.md` exist
- [ ] `references/`, `templates/`, `examples/`, `tests/`, and `scripts/` exist
- [ ] validation script passes
- [ ] packaging script creates both `.zip` and `.skill`
- [ ] `python3 scripts/package_skill.py --channel skillhub` creates SkillHub-compatible archives
- [ ] archive keeps the root folder `token-roi-controller/`
- [ ] examples reflect micro, standard, and over-limit handling
- [ ] default output structure is present
- [ ] over-limit choice block defaults to `省token模式`
