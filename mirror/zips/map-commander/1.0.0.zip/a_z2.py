# 腾讯地图技能快速参考

## 技能选择指南

| 需求类型 | 推荐技能 | 需要Key |
|----------|----------|---------|
| 网页/小程序地图展示 | tencentmap-jsapi-gl-skill | TMAP_JSAPI_KEY |
| 地址→坐标 | tencentmap-webservice-skill | TMAP_WEBSERVICE_KEY |
| 坐标→地址 | tencentmap-webservice-skill | TMAP_WEBSERVICE_KEY |
| 搜索地点/POI | tencentmap-webservice-skill / tencentmap-lbs-skill | TMAP_WEBSERVICE_KEY |
| 路线规划 | tencentmap-webservice-skill / tencentmap-lbs-skill | TMAP_WEBSERVICE_KEY |
| 热力图/轨迹图 | tencentmap-jsapi-gl-skill | TMAP_JSAPI_KEY |
| 距离矩阵 | tencentmap-webservice-skill | TMAP_WEBSERVICE_KEY |
| 天气查询 | tencentmap-webservice-skill | TMAP_WEBSERVICE_KEY |
| GPS坐标转换 | tencentmap-webservice-skill | TMAP_WEBSERVICE_KEY |
| 旅游规划 | tencentmap-lbs-skill | TMAP_WEBSERVICE_KEY |

## 常用场景对话模板

### 地图开发
- "帮我做一个显示门店分布的地图"
- "在地图上标注这些坐标点"
- "做一个热力图展示人流密度"
- "实现地图上的轨迹动画"

### 地址处理
- "把这些地址转成经纬度坐标"
- "把GPS坐标转成国测局坐标"
- "从文本里提取地址信息"

### 位置搜索
- "搜索附近的加油站"
- "查找北京市朝阳区附近的火锅店"
- "搜索两地点之间的POI"

### 路径规划
- "规划从A到B的骑行路线"
- "计算驾车距离和预计时间"
- "生成多点的路径规划"

### 综合分析
- "分析这个区域的人口热力分布"
- "帮我规划一条北京两日游路线"
- "计算配送范围内的覆盖情况"
