# -*- coding: utf-8 -*-
"""
腾讯地图 API 签名生成工具
使用方法:
    from signature import create_signed_url
    url = create_signed_url("/ws/geocoder/v1", {"address": "北京", "key": "YOUR_KEY"}, "YOUR_SECRET")
"""
import hashlib
import os

# 从环境变量读取 Secret Key
def get_secret_key():
    """获取 Secret Key"""
    sk = os.environ.get('TMAP_SECRET_KEY', '')
    if not sk:
        raise ValueError("请先配置环境变量 TMAP_SECRET_KEY")
    return sk

def create_signature(path, params, secret_key):
    """
    生成腾讯地图 API 签名
    
    Args:
        path: 请求路径，如 "/ws/geocoder/v1"
        params: 参数字典（不含sig）
        secret_key: Secret Key
    
    Returns:
        签名字符串
    """
    # 1. 参数按名称升序排序
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    # 2. 拼接：请求路径 + "?" + 排序后参数 + SK
    param_str = "&".join([f"{k}={v}" for k, v in sorted_params])
    sign_str = f"{path}?{param_str}{secret_key}"
    # 3. MD5
    return hashlib.md5(sign_str.encode('utf-8')).hexdigest()

def create_signed_url(base_url, path, params):
    """
    创建带签名的完整请求URL
    
    Args:
        base_url: API基础URL，如 "https://apis.map.qq.com"
        path: 请求路径，如 "/ws/geocoder/v1"
        params: 参数字典（不含sig）
    
    Returns:
        带签名的完整URL
    """
    secret_key = get_secret_key()
    sig = create_signature(path, params, secret_key)
    params['sig'] = sig
    query_string = "&".join([f"{k}={v}" for k, v in params.items()])
    return f"{base_url}{path}?{query_string}"

def add_signature(path, params):
    """
    为参数字典添加签名
    
    Args:
        path: 请求路径
        params: 参数字典（会被修改，添加sig）
    
    Returns:
        添加了sig的参数字典
    """
    secret_key = get_secret_key()
    sig = create_signature(path, params, secret_key)
    params['sig'] = sig
    return params

if __name__ == "__main__":
    # 测试
    api_key = os.environ.get('TMAP_WEBSERVICE_KEY', '')
    secret_key = os.environ.get('TMAP_SECRET_KEY', '')
    
    if not api_key or not secret_key:
        print("Error: Please set TMAP_WEBSERVICE_KEY and TMAP_SECRET_KEY")
    else:
        params = {
            "address": "沈阳曙光大厦",
            "region": "沈阳",
            "key": api_key,
            "output": "json"
        }
        
        sig = create_signature("/ws/geocoder/v1", params, secret_key)
        print(f"Generated signature: {sig}")
