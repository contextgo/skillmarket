# -*- coding: utf-8 -*-
"""Map Commander - Fun Skills"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import os
import random
import hashlib
import requests
import json
from urllib.parse import quote

# ==================== 配置 ====================
API_KEY = os.environ.get('TMAP_WEBSERVICE_KEY', '')
SECRET_KEY = os.environ.get('TMAP_SECRET_KEY', '')
BASE_URL = 'https://apis.map.qq.com'

# ==================== 签名工具 ====================
def create_signature(path, params, secret_key):
    """生成签名"""
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    param_str = "&".join([f"{k}={v}" for k, v in sorted_params])
    sign_str = f"{path}?{param_str}{secret_key}"
    return hashlib.md5(sign_str.encode('utf-8')).hexdigest()

def add_signature(path, params):
    """添加签名"""
    if not SECRET_KEY:
        raise ValueError("请先配置 TMAP_SECRET_KEY 环境变量")
    sig = create_signature(path, params, SECRET_KEY)
    params['sig'] = sig
    return params

def api_request(path, params):
    """发送API请求"""
    params['key'] = API_KEY
    params['output'] = 'json'
    add_signature(path, params)
    url = f"{BASE_URL}{path}"
    response = requests.get(url, params=params)
    return response.json()

# ==================== 地理编码 ====================
def geocode(address, region=''):
    """地址转坐标"""
    params = {'address': address}
    if region:
        params['region'] = region
    result = api_request('/ws/geocoder/v1', params)
    if result.get('status') == 0:
        return result['result']['location']
    return None

def reverse_geocode(lat, lng):
    """坐标转地址"""
    params = {'location': f"{lat},{lng}"}
    result = api_request('/ws/geocoder/v1', params)
    if result.get('status') == 0:
        return result['result']
    return None

# ==================== POI搜索 ====================
def poi_search(keyword, lat=None, lng=None, radius=2000, city=None, filter_key=''):
    """POI搜索"""
    params = {'keyword': keyword}
    if lat and lng:
        params['boundary'] = f"nearby({lat},{lng},{radius})"
    elif city:
        params['boundary'] = f"region({city},0)"
    if filter_key:
        params['filter'] = f"category={filter_key}"
    params['orderby'] = 'Distance'
    
    result = api_request('/ws/place/v1/search', params)
    if result.get('status') == 0:
        return result.get('data', [])
    return []

# ==================== 路线规划 ====================
def direction_driving(from_lat, from_lng, to_lat, to_lng, policy='LEAST_TIME'):
    """驾车路线规划"""
    params = {
        'from': f"{from_lat},{from_lng}",
        'to': f"{to_lat},{to_lng}",
        'policy': policy
    }
    result = api_request('/ws/direction/v1/driving', params)
    if result.get('status') == 0:
        return result['result']['routes'][0]
    return None

def direction_walking(from_lat, from_lng, to_lat, to_lng):
    """步行路线规划"""
    params = {
        'from': f"{from_lat},{from_lng}",
        'to': f"{to_lat},{to_lng}"
    }
    result = api_request('/ws/direction/v1/walking', params)
    if result.get('status') == 0:
        return result['result']['routes'][0]
    return None

# ==================== 美食雷达 ====================
def 美食雷达(lat, lng, radius=3000, exclude_chains=True):
    """
    美食雷达 - 分析周边美食分布
    """
    print("\n" + "=" * 60)
    print("🍽️  美食雷达启动...")
    print("=" * 60)
    
    # 获取周边美食
    print(f"\n📍 扫描范围：半径 {radius} 米")
    
    # 分类搜索
    categories = {
        '🍲 中餐': '中餐',
        '🍜 面馆': '面馆',
        '🍖 烧烤': '烧烤',
        '🍲 火锅': '火锅',
        '🍣 日料': '日料',
        '🍕 西餐': '西餐',
        '🍰 甜品': '甜品',
        '🍵 咖啡': '咖啡'
    }
    
    results = {}
    for name, keyword in categories.items():
        places = poi_search(keyword, lat, lng, radius)
        # 排除连锁店
        if exclude_chains:
            places = [p for p in places if '店' not in p.get('title', '') or 
                     not any(chain in p.get('title', '') for chain in ['肯德基', '麦当劳', '华莱士', '德克士'])]
        results[name] = places[:3]  # 每类最多3个
    
    # 打印分析结果
    print("\n📊 美食分布统计：")
    for cat, places in results.items():
        count = len(poi_search(cat.split(' ')[1], lat, lng, radius))
        print(f"  {cat}: {count} 家")
    
    # 随机推荐
    all_places = []
    for places in results.values():
        all_places.extend(places)
    
    if all_places:
        # 按距离排序后随机选一个
        random_pick = random.choice(all_places[:20])
        print("\n🎲 随机推荐：")
        print(f"  📌 {random_pick['title']}")
        print(f"  📍 {random_pick.get('address', '地址未知')}")
        if random_pick.get('tel'):
            print(f"  📞 {random_pick['tel']}")
        print(f"  🏷️  {random_pick.get('category', '美食')}")
    
    return results

# ==================== 约会神器 ====================
def 约会神器(location1_name, location2_name=''):
    """
    约会神器 - 找中间位置和约会地点
    """
    print("\n" + "=" * 60)
    print("💑 约会神器启动...")
    print("=" * 60)
    
    # 获取位置1坐标
    loc1 = geocode(location1_name)
    if not loc1:
        print(f"❌ 未找到位置：{location1_name}")
        return
    
    print(f"\n📍 位置1：{location1_name}")
    print(f"   坐标：({loc1['lat']:.6f}, {loc1['lng']:.6f})")
    
    if location2_name:
        loc2 = geocode(location2_name)
        if not loc2:
            print(f"❌ 未找到位置：{location2_name}")
            return
        
        print(f"\n📍 位置2：{location2_name}")
        print(f"   坐标：({loc2['lat']:.6f}, {loc2['lng']:.6f})")
        
        # 计算中间位置
        mid_lat = (loc1['lat'] + loc2['lat']) / 2
        mid_lng = (loc1['lng'] + loc2['lng']) / 2
        print(f"\n🎯 中间位置建议：")
        print(f"   坐标：({mid_lat:.6f}, {mid_lng:.6f})")
    else:
        mid_lat, mid_lng = loc1['lat'], loc1['lng']
    
    # 在中间位置附近搜索约会地点
    print(f"\n🔍 搜索附近约会地点...")
    
    # 餐厅
    restaurants = poi_search('餐厅', mid_lat, mid_lng, 1000)
    if restaurants:
        print(f"\n🍽️  推荐餐厅（{len(restaurants)}家）：")
        for i, r in enumerate(restaurants[:3], 1):
            print(f"  {i}. {r['title']}")
            print(f"     {r.get('address', '')[:30]}...")
    
    # 咖啡厅
    cafes = poi_search('咖啡', mid_lat, mid_lng, 1000)
    if cafes:
        print(f"\n☕ 推荐咖啡厅（{len(cafes)}家）：")
        for i, c in enumerate(cafes[:3], 1):
            print(f"  {i}. {c['title']}")
    
    # 电影院
    cinemas = poi_search('电影院', mid_lat, mid_lng, 2000)
    if cinemas:
        print(f"\n🎬 附近电影院（{len(cinemas)}家）：")
        for i, c in enumerate(cinemas[:2], 1):
            print(f"  {i}. {c['title']}")
    
    # 生成约会路线
    if restaurants and cafes:
        route = direction_driving(mid_lat, mid_lng, restaurants[0]['location']['lat'], restaurants[0]['location']['lng'])
        if route:
            print(f"\n📍 建议约会路线：")
            print(f"  1️⃣ 先到 {restaurants[0]['title']} 吃饭")
            print(f"     距离：{route.get('distance', 0)/1000:.1f}km")
            print(f"  2️⃣ 然后去 {cafes[0]['title']} 喝咖啡聊天")
            print(f"\n💡 小贴士：记得提前预约哦！")
    
    return mid_lat, mid_lng

# ==================== 跑步路线 ====================
def 跑步路线(start_point, distance_km=5):
    """
    跑步路线 - 生成跑步路线
    """
    print("\n" + "=" * 60)
    print("🏃 跑步路线生成器...")
    print("=" * 60)
    
    # 获取起点坐标
    start = geocode(start_point)
    if not start:
        print(f"❌ 未找到位置：{start_point}")
        return
    
    print(f"\n📍 起点：{start_point}")
    print(f"   目标距离：{distance_km} 公里")
    
    # 搜索附近公园/绿道
    print(f"\n🔍 搜索附近的公园...")
    parks = poi_search('公园', start['lat'], start['lng'], 3000)
    
    if parks:
        print(f"\n🌳 发现 {len(parks)} 个公园：")
        for i, p in enumerate(parks[:3], 1):
            print(f"  {i}. {p['title']}")
            print(f"     {p.get('address', '')[:30]}...")
    
    # 生成简单的折返跑路线
    # 向某个方向走2.5km，再折返
    route_distance = distance_km * 1000 / 2  # 单程距离
    
    # 使用步行路线模拟
    end_lat = start['lat'] + 0.01  # 简单估算
    end_lng = start['lng'] + 0.01
    
    print(f"\n🏃 推荐跑步路线：")
    print(f"  📍 起点：{start_point}")
    print(f"  📏 距离：{distance_km} 公里")
    print(f"  🔄 路线：折返跑（向外 {distance_km/2}km → 折返）")
    
    # 估算用时和卡路里
    time_min = distance_km / 10 * 60  # 按10km/h计算
    calories = distance_km * 60  # 每公里约60卡
    
    print(f"  ⏱️ 预计用时：{time_min:.0f} 分钟")
    print(f"  🔥 燃烧卡路里：约 {calories:.0f} 大卡")
    
    print(f"\n💡 跑步小贴士：")
    print(f"  • 跑前热身5分钟，跑后拉伸5分钟")
    print(f"  • 保持均匀呼吸，以能说话为宜")
    print(f"  • 及时补充水分")
    
    return {'start': start, 'distance': distance_km, 'time': time_min, 'calories': calories}

# ==================== 搬家参谋 ====================
def 搬家参谋(address):
    """
    搬家参谋 - 分析周边配套
    """
    print("\n" + "=" * 60)
    print("🏠 搬家参谋启动...")
    print("=" * 60)
    
    # 获取位置坐标
    location = geocode(address)
    if not location:
        print(f"❌ 未找到位置：{address}")
        return
    
    print(f"\n📍 分析位置：{address}")
    print(f"   坐标：({location['lat']:.6f}, {location['lng']:.6f})")
    
    # 获取地址详情
    address_info = reverse_geocode(location['lat'], location['lng'])
    if address_info:
        comp = address_info.get('address_components', {})
        print(f"\n🏙️ 所属区域：")
        print(f"  省：{comp.get('province', '-')}")
        print(f"  市：{comp.get('city', '-')}")
        print(f"  区：{comp.get('district', '-')}")
    
    # 分析各项配套
    categories = [
        ('🏪 超市/便利店', '超市'),
        ('🏥 医院/药店', '医院'),
        ('🏫 学校/教育', '学校'),
        ('🚇 地铁站', '地铁站'),
        ('🅿️ 停车场', '停车场'),
        ('🍽️ 餐饮', '餐厅'),
        ('🏋️ 健身房', '健身房'),
        ('🎬 电影院', '电影院'),
        ('🌳 公园', '公园'),
        ('🛒 商场', '商场'),
    ]
    
    print(f"\n📊 周边配套分析（半径1公里）：")
    scores = {}
    
    for name, keyword in categories:
        places = poi_search(keyword, location['lat'], location['lng'], 1000)
        count = len(places)
        # 评分（根据数量）
        if count >= 10:
            score = "⭐⭐⭐⭐⭐"
        elif count >= 5:
            score = "⭐⭐⭐⭐"
        elif count >= 3:
            score = "⭐⭐⭐"
        elif count >= 1:
            score = "⭐⭐"
        else:
            score = "⭐"
            count = "很少"
        
        scores[keyword] = count
        print(f"  {name}：{count} 家 {score}")
        
        if places and count <= 3:
            print(f"      └ {places[0]['title']}")
    
    # 综合评分
    total_score = sum([
        min(scores.get('超市', 0), 5) * 2,
        min(scores.get('医院', 0), 5) * 1.5,
        min(scores.get('学校', 0), 5) * 1.5,
        min(scores.get('地铁站', 0), 5) * 2,
        min(scores.get('餐饮', 0), 5) * 1,
        min(scores.get('公园', 0), 5) * 1,
    ])
    max_score = 10 * 2 + 10 * 1.5 + 10 * 1.5 + 10 * 2 + 10 * 1 + 10 * 1
    final_score = (total_score / max_score) * 100
    
    print(f"\n🏆 综合宜居指数：{final_score:.0f}/100")
    
    if final_score >= 80:
        print(f"  🎉 非常适合居住！周边配套齐全")
    elif final_score >= 60:
        print(f"  👍 生活便利度良好")
    elif final_score >= 40:
        print(f"  🤔 生活便利度一般，建议实地考察")
    else:
        print(f"  ⚠️ 周边配套较少，可能需要依赖交通工具")
    
    print(f"\n💡 搬家建议：")
    print(f"  • 确认小区周边噪音情况")
    print(f"  • 检查网络信号和宽带安装条件")
    print(f"  • 了解周边治安状况")
    
    return {'location': location, 'scores': scores, 'final_score': final_score}

# ==================== 随机探险 ====================
def 随机探险(location_name):
    """
    随机探险 - 随机推荐有趣的地方
    """
    print("\n" + "=" * 60)
    print("🎲 随机探险启动...")
    print("=" * 60)
    
    # 获取位置坐标
    location = geocode(location_name)
    if not location:
        print(f"❌ 未找到位置：{location_name}")
        return
    
    print(f"\n📍 当前位置：{location_name}")
    
    # 随机选择探索类型
    exploration_types = [
        ('🎨 展览/艺术', '展览馆'),
        ('📚 书香', '书店'),
        ('🏛️ 历史', '博物馆'),
        ('🌳 自然', '公园'),
        ('🎮 娱乐', '游戏厅'),
        ('☕ 文艺', '咖啡馆'),
        ('🍺 夜生活', '酒吧'),
        ('🛍️ 购物', '集市'),
    ]
    
    chosen_type, keyword = random.choice(exploration_types)
    print(f"\n🎯 今日探索主题：{chosen_type}")
    
    # 搜索附近
    places = poi_search(keyword, location['lat'], location['lng'], 5000)
    
    if places:
        # 随机选一个
        discovery = random.choice(places[:20])
        print(f"\n🎉 随机发现：")
        print(f"  📌 {discovery['title']}")
        print(f"  📍 {discovery.get('address', '地址未知')}")
        if discovery.get('tel'):
            print(f"  📞 {discovery['tel']}")
        
        # 计算距离
        dis_lat = discovery['location']['lat']
        dis_lng = discovery['location']['lng']
        route = direction_driving(location['lat'], location['lng'], dis_lat, dis_lng)
        if route:
            print(f"  📏 距离：{route['distance']/1000:.1f} 公里")
            print(f"  ⏱️ 驾车：约 {route['duration']/60:.0f} 分钟")
        
        print(f"\n💡 探险小贴士：")
        print(f"  • 说走就走，说不定有惊喜！")
        print(f"  • 记得拍照打卡")
        
        return discovery
    else:
        print(f"\n😢 附近没找到 {keyword}，换个地方试试？")
        return None

# ==================== 主程序 ====================
if __name__ == "__main__":
    import sys
    
    if not API_KEY or not SECRET_KEY:
        print("❌ 请先配置环境变量：")
        print("   set TMAP_WEBSERVICE_KEY=你的Key")
        print("   set TMAP_SECRET_KEY=你的Secret")
        sys.exit(1)
    
    if len(sys.argv) < 2:
        print("\n" + "=" * 60)
        print("🗺️  地图指挥官 - 趣味技能集")
        print("=" * 60)
        print("\n用法：python map_fun.py <功能> [参数]")
        print("\n可用功能：")
        print("  美食雷达 <位置> [半径米]     - 分析周边美食")
        print("  约会神器 <位置1> [位置2]      - 找约会地点")
        print("  跑步路线 <起点> [距离公里]   - 生成跑步路线")
        print("  搬家参谋 <地址>              - 分析宜居指数")
        print("  随机探险 <位置>              - 随机探索有趣的地方")
        print("\n示例：")
        print("  python map_fun.py 美食雷达 深圳科技园 3000")
        print("  python map_fun.py 约会神器 深圳 世界之窗")
        print("  python map_fun.py 搬家参谋 深圳南山")
        sys.exit(0)
    
    command = sys.argv[1]
    
    if command == "美食雷达":
        location = sys.argv[2] if len(sys.argv) > 2 else "深圳"
        radius = int(sys.argv[3]) if len(sys.argv) > 3 else 3000
        loc = geocode(location)
        if loc:
            美食雷达(loc['lat'], loc['lng'], radius)
    
    elif command == "约会神器":
        loc1 = sys.argv[2] if len(sys.argv) > 2 else "深圳"
        loc2 = sys.argv[3] if len(sys.argv) > 3 else ""
        约会神器(loc1, loc2)
    
    elif command == "跑步路线":
        location = sys.argv[2] if len(sys.argv) > 2 else "深圳"
        distance = float(sys.argv[3]) if len(sys.argv) > 3 else 5
        跑步路线(location, distance)
    
    elif command == "搬家参谋":
        address = sys.argv[2] if len(sys.argv) > 2 else "深圳南山"
        搬家参谋(address)
    
    elif command == "随机探险":
        location = sys.argv[2] if len(sys.argv) > 2 else "深圳"
        随机探险(location)
    
    else:
        print(f"❌ 未知命令：{command}")
