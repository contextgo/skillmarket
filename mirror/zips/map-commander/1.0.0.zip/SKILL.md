---
name: 地图指挥官
description: |
  腾讯地图统一协作入口。当用户需要使用腾讯地图相关功能时，本技能作为统一入口，
  自动识别需求类型并协调以下官方子技能：
  - tencentmap-jsapi-gl-skill：Web端地图应用开发（地图展示、覆盖物、可视化）
  - tencentmap-webservice-skill：WebService API（地理编码、POI搜索、路线规划、天气）
  - tencentmap-lbs-skill：位置服务LBS（POI搜索、路径规划、轨迹可视化）
  
  适用场景：
  - 地图应用开发（网页、小程序、App）
  - 位置数据分析与可视化
  - 地址/坐标转换与地理编码
  - 路径规划和导航
  - 周边搜索和POI查询
  - 地理围栏和区域分析
  - 轨迹数据和旅游规划
  
  触发词：腾讯地图、地图开发、位置服务、LBS、POI搜索、路径规划、地理编码、坐标转换
---

# 腾讯地图统一协作技能

本技能作为腾讯地图生态的统一入口，根据用户需求自动选择合适的子技能协调工作。

## 子技能体系

### 1. tencentmap-jsapi-gl-skill（前端地图开发）

**定位**：Web端地图应用开发

**核心能力**：
- 基础地图展示（2D/3D）
- 地图控件和交互
- 覆盖物：点标记、文本标记、矢量图形
- 信息窗体和弹窗
- 点聚合和热力图
- 轨迹展示和动画
- 数据可视化（弧线图、散点图、区域图等）
- 个性化地图样式
- 几何计算（距离、面积）
- 三维模型展示（GLTF/3DTiles）

**适用场景**：
- "做一个地图页面"
- "在地图上标注这些地点"
- "实现热力图可视化"
- "添加地图交互功能"
- Web应用、小程序中的地图组件

**需要Key**：`TMAP_JSAPI_KEY`

---

### 2. tencentmap-webservice-skill（WebService API）

**定位**：后端/服务端数据接口

**核心能力**：
- 地理编码（地址→坐标）
- 逆地理编码（坐标→地址）
- POI搜索（关键词、周边、范围）
- 关键词输入提示
- 路线规划（驾车、步行、骑行、电动车、公交）
- 距离矩阵计算
- 天气查询
- IP定位
- 智能地址解析
- 坐标系转换（GPS↔国测局）
- 行政区划查询

**适用场景**：
- "把地址转成坐标"
- "搜索附近的餐厅"
- "计算两地之间的距离"
- "查询某地的天气"
- "把GPS坐标转成国测局坐标"
- 后端服务集成

**需要Key**：`TMAP_WEBSERVICE_KEY`

---

### 3. tencentmap-lbs-skill（位置服务LBS）

**定位**：高级位置服务封装

**核心能力**：
- POI搜索增强
- 路径规划增强
- 旅游规划
- 周边搜索
- 轨迹数据处理
- 地图数据可视化

**适用场景**：
- 复杂的POI查询需求
- 旅游路线规划
- 轨迹数据分析
- LBS应用开发

**需要Key**：`TMAP_WEBSERVICE_KEY`

---

## 决策流程

当用户提出腾讯地图相关需求时，按以下流程选择合适的子技能：

```
用户需求
    │
    ├─► 需要前端展示/可视化？
    │       └─► 加载 tencentmap-jsapi-gl-skill
    │
    ├─► 需要后端数据接口？
    │       ├─► 地理编码/逆编码 → tencentmap-webservice-skill
    │       ├─► POI搜索/周边查询 → tencentmap-webservice-skill / tencentmap-lbs-skill
    │       ├─► 路线规划 → tencentmap-webservice-skill / tencentmap-lbs-skill
    │       ├─► 天气/距离矩阵 → tencentmap-webservice-skill
    │       └─► 轨迹/旅游规划 → tencentmap-lbs-skill
    │
    └─► 需要多种能力组合？
            └─► 按需加载多个子技能，协调工作
```

## Key配置

当加载子技能时，需要注意Key的配置：

| 子技能 | 需要的Key | 说明 |
|--------|----------|------|
| tencentmap-jsapi-gl-skill | `TMAP_JSAPI_KEY` | JS API专用Key |
| tencentmap-webservice-skill | `TMAP_WEBSERVICE_KEY` | WebService专用Key |
| tencentmap-lbs-skill | `TMAP_WEBSERVICE_KEY` | 与WebService共用 |

### 签名配置（正式Key必需）

如果 Key 开启了签名校验（SN校验），需要额外配置 Secret Key：

```bash
# Windows
setx TMAP_SECRET_KEY "你的SecretKey"

# 或 PowerShell
[Environment]::SetEnvironmentVariable('TMAP_SECRET_KEY', '你的SecretKey', 'User')
```

**签名算法**（已内置在 `z3/signature.dat`）：
1. 参数按名称升序排序
2. 拼接：`请求路径 + "?" + 排序后参数 + SecretKey`
3. 对拼接字符串计算 MD5

### 环境变量完整配置

```bash
TMAP_JSAPI_KEY=你的JSAPI Key
TMAP_WEBSERVICE_KEY=你的WebService Key
TMAP_SECRET_KEY=你的Secret Key（如果开启了签名校验）
```

正式环境请到 [腾讯位置服务控制台](https://lbs.qq.com/dev/console/key/manage) 申请正式Key。

## 使用示例

### 示例1：地图可视化
```
用户：帮我做一个地图页面，显示全国各城市的销售数据
分析：需要前端展示 + 数据可视化
行动：加载 tencentmap-jsapi-gl-skill，使用热力图/散点图展示销售数据
```

### 示例2：地址处理
```
用户：把Excel里的地址批量转成坐标
分析：需要后端数据处理
行动：加载 tencentmap-webservice-skill，批量调用地理编码API
```

### 示例3：路径规划
```
用户：帮我规划从深圳到广州的自驾路线，显示途经景点
分析：需要路线规划 + POI搜索
行动：加载 tencentmap-webservice-skill 进行路线规划，
      加载 tencentmap-jsapi-gl-skill 在地图上展示路线和景点标记
```

### 示例4：周边分析
```
用户：分析我店铺周围1公里有多少竞品
分析：需要周边POI搜索 + 数据分析
行动：加载 tencentmap-webservice-skill 搜索周边竞品，
      整理分析结果呈现给用户
```

## 趣味技能

「地图指挥官」内置了5个有趣的技能，让地图不只是工具：

### 1. 🍽️ 美食雷达
**触发词**：`美食雷达`、`附近有什么好吃的`、`帮我找找美食`

**功能**：
- 分析周边各类美食分布
- 随机推荐宝藏小店
- 支持筛选：中餐/火锅/烧烤/日料/西餐/甜品/咖啡

**示例**：
```
用户：美食雷达 深圳科技园 3000米
用户：附近有什么好吃的，不要快餐
```

---

### 2. 💑 约会神器
**触发词**：`约会`、`找个约会地点`、`帮我安排约会`

**功能**：
- 智能找中间位置
- 推荐餐厅+咖啡厅+电影院组合
- 生成约会路线图

**示例**：
```
用户：约会神器 我在深圳 她在广州
用户：帮我找个适合约会的地方
```

---

### 3. 🏃 跑步路线
**触发词**：`跑步`、`生成跑步路线`、`帮我规划跑步`

**功能**：
- 搜索附近公园/绿道
- 生成折返或环形跑步路线
- 估算用时和卡路里

**示例**：
```
用户：生成一条5公里的跑步路线
用户：附近哪里适合跑步
```

---

### 4. 🏠 搬家参谋
**触发词**：`搬家`、`分析这里适不适合住`、`宜居指数`

**功能**：
- 分析周边配套（超市/医院/学校/地铁等）
- 计算综合宜居指数
- 给出搬家建议

**示例**：
```
用户：帮我分析一下这个小区
用户：这里适合居住吗
```

---

### 5. 🎲 随机探险
**触发词**：`随机`、`探险`、`随便逛逛`、`带我探索`

**功能**：
- 随机推荐有趣的地方
- 生成说走就走的半日游路线
- 每天不一样的惊喜

**示例**：
```
用户：随机带我去个好玩的地方
用户：附近有什么有趣的地方
```

---

## 协作原则

1. **单一职责**：每个子技能做好自己的事，不越界
2. **按需加载**：只加载需要的子技能，避免资源浪费
3. **Key统一管理**：确认所需的Key已配置
4. **结果整合**：多技能协作时，整合各技能的结果统一呈现

## 参考文档

- 腾讯位置服务官网：https://lbs.qq.com/
- API文档中心：https://lbs.qq.com/service/
- 控制台（申请Key）：https://lbs.qq.com/dev/console/key/manage
