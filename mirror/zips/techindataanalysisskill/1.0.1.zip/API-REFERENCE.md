# 工作台多维分析服务 — 接口说明文档

> **服务地址**：`http://10.11.201.58:62392/`
> **认证方式**：所有请求 Header 中携带 `apikey: <access_token>` 和 `Content-Type: application/json; charset=utf-8`
> **⚠️ `<access_token>` 必须通过 SKILL.md 中定义的「🔑 API Key 认证流程」获取，禁止硬编码或使用空值**

---

## 目录

1. [数据集元数据接口](#1-数据集元数据接口)
2. [明细查询 `/query/detail`](#2-明细查询-querydetail)
3. [统计聚合 `/query/stat`](#3-统计聚合-querystat)
4. [同比环比 `/query/calc`](#4-同比环比-querycalc)
5. [列级聚合 `/query/column-calc`](#5-列级聚合-querycolumn-calc)
6. [穿透下钻与导出](#6-穿透下钻与导出)
7. [数据集选择原则](#7-数据集选择原则)
8. [regional_industry 使用规范](#8-regional_industry-使用规范)
9. [FilterCondition 操作符](#9-filtercondition-操作符)

---

## 1. 数据集元数据接口

### 列出所有数据集

```
GET /api/v1/datasets?page=1&page_size=20
```

支持 `search=关键词` 参数按名称搜索数据集。

### 查看数据集详情

```
GET /api/v1/datasets/{dataset_id}
```

### 获取数据集字段列表

```
GET /api/v1/datasets/{dataset_id}/fields
```

### 获取枚举字段可选值

```
GET /api/v1/datasets/{dataset_id}/fields/{field_name}/enums?tree=true
```

支持级联过滤（例如先选省份再获取城市列表）：

```
GET /api/v1/datasets/{dataset_id}/fields/city_name/enums
    ?parent_field=province_name&parent_value=广东省
```

---

## 2. 明细查询 `/query/detail`

**接口**：`POST /api/v1/query/detail`  
**适用场景**：获取企业名单、具体企业列表、行级明细数据

### 请求参数

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `fields` | string[] | ✅ | 返回的字段列表（越少越快） |
| `filters` | FilterCondition[] | 否 | 筛选条件，见 §9 |
| `sorts` | SortCondition[] | 否 | 排序，`{"field": "xxx", "order": "asc/desc"}` |
| `page` | PageParam | ✅ | `{"page": 1, "page_size": 20}`，建议 page_size ≤ 50 |

### 响应结构

```json
{
  "total": 12345,
  "rows": [
    { "enterprise_name": "...", "province_name": "广东省", ... }
  ],
  "elapsed_ms": 123.4
}
```

---

## 3. 统计聚合 `/query/stat`

**接口**：`POST /api/v1/query/stat`  
**适用场景**：各省/市/区企业数量、按产业分布、TOP N 排行、占比分析

### 请求参数

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `group_by` | string[] | 否 | 分组字段列表 |
| `metrics` | MetricConfig[] | ✅ | 聚合指标配置，见下表 |
| `filters` | FilterCondition[] | 否 | 筛选条件 |
| `sorts` | SortCondition[] | 否 | 排序（可用 alias 名排序） |
| `page` | PageParam | ✅ | 分页参数 |

### MetricConfig 字段说明

| 字段 | 说明 |
|------|------|
| `field` | 参与聚合的字段名 |
| `agg` | 聚合函数：`count` / `sum` / `avg` / `min` / `max` / `count_distinct` |
| `alias` | 输出列别名（可用于 sorts 中的 field 值） |

### 响应结构

```json
{
  "total": 34,
  "rows": [
    { "province_name": "广东省", "企业数量": 15234 },
    { "province_name": "北京市", "企业数量": 9876 }
  ],
  "elapsed_ms": 456.7
}
```

---

## 4. 同比环比 `/query/calc`

**接口**：`POST /api/v1/query/calc`  
**适用场景**：同比（年度对比）/ 环比（月度对比）增速、增长率分析

### 请求参数

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `time_field` | string | ✅ | 时间维度字段名 |
| `metrics` | MetricConfig[] | ✅ | 聚合指标配置（同 §3） |
| `group_by` | string[] | 否 | 分组字段 |
| `filters` | FilterCondition[] | 否 | 筛选条件 |
| `calc_type` | string | ✅ | `yoy`（同比）或 `mom`（月环比） |

### calc_type 说明

| 值 | 说明 |
|----|------|
| `yoy` | Year-over-Year 同比，对比同期上一年数据 |
| `mom` | Month-over-Month 月环比，对比上月数据 |

---

## 5. 列级聚合 `/query/column-calc`

**接口**：`POST /api/v1/query/column-calc`  
**适用场景**：对某个数值字段计算总和、平均值、最大值、最小值、计数

### 请求参数

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `columns` | ColumnCalcConfig[] | ✅ | 列聚合配置，见下表 |
| `filters` | FilterCondition[] | 否 | 筛选条件 |

### ColumnCalcConfig 字段说明

| 字段 | 说明 |
|------|------|
| `field` | 字段名 |
| `calc_type` | 聚合类型：`sum` / `avg` / `max` / `min` / `count` |

### 响应结构

```json
{
  "dataset_id": "enterprise_rating_score",
  "results": [
    { "field": "enterprise_rating_score", "calc_type": "sum",   "value": 497123456.78 },
    { "field": "enterprise_rating_score", "calc_type": "avg",   "value": 85.6 },
    { "field": "enterprise_rating_score", "calc_type": "max",   "value": 99.9 },
    { "field": "enterprise_rating_score", "calc_type": "min",   "value": 10.2 },
    { "field": "enterprise_rating_score", "calc_type": "count", "value": 5800000 }
  ],
  "elapsed_ms": 2345.6
}
```

---

## 6. 穿透下钻与导出

### 6.1 统计行穿透到明细

**接口**：`POST /api/v1/export/drill`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `drill_field` | string | ✅ | 下钻维度字段名 |
| `drill_value` | string | ✅ | 下钻维度值 |
| `fields` | string[] | ✅ | 返回字段列表 |
| `filters` | FilterCondition[] | 否 | 附加筛选条件 |
| `sorts` | SortCondition[] | 否 | 排序 |
| `page` | PageParam | ✅ | 分页参数 |

### 6.2 单行详情（全字段）

**接口**：`POST /api/v1/export/row-detail`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `row_id_field` | string | ✅ | 主键字段名，如 `enterprise_id` |
| `row_id_value` | string | ✅ | 主键值 |

### 6.3 行数预估

**接口**：`POST /api/v1/export/estimate`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `filters` | FilterCondition[] | 否 | 筛选条件 |

### 6.4 Excel / CSV 导出

**接口**：`POST /api/v1/export/excel` 或 `POST /api/v1/export/csv`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dataset_id` | string | ✅ | 数据集 ID |
| `fields` | string[] | ✅ | 导出字段列表 |
| `filters` | FilterCondition[] | 否 | 筛选条件 |
| `max_rows` | int | 否 | 最大导出行数 |

---

## 7. 数据集选择原则

| 业务场景 | 推荐 dataset_id | 说明 |
|----------|----------------|------|
| 企业基础信息 / 招商线索初筛 | `enterprise_profile` | 企业基础画像 |
| 企业综合实力评估（规模、成长、科创、风险） | `enterprise_rating_score` | 企业综合评分 |
| 区域产业盘点 / 赛道热度分析 | `regional_industry` | **必须**使用此数据集 |
| 企业迁移流向分析（迁入迁出、跨区域变更） | `enterprise_migration` | 企业迁移分析 |
| 集团关联与控股链路分析 | `enterprise_group` | 企业集团关系 |
| 企业人才结构与高层次人才分析 | `enterprise_talent` | 企业人才信息 |
| 企业技术能力 / IP 资产（企业视角） | `enterprise_ip_detail` | 知识产权明细 |
| 专利分析（专利视角） | `patent_profile` / `patent_exercise` | 专利画像 / 行权事件 |
| 企业供应链上下游关系分析 | `enterprise_supply` | 企业供应链分析 |
| 上市公司财务指标与三大报表 | `listed_financial` | 上市财务数据 |
| 上市公司公告事件追踪 | `listed_announcements` | 上市公告事件 |
| 上市公司主营业务收入结构 | `listed_main_business` | 主营业务收入 |
| 产业集群竞争力评估（产业级） | `industry_cluster` | 产业集群竞争力指数 |
| 投融资活跃度 / 资本流向分析 | `investment_event` | 投融资事件分析 |

> **不确定时**：先调用 `GET /api/v1/datasets?search=关键词` 搜索；  
> 若问题同时涉及「企业 + 区域/产业 + 资本/专利」，采用**主数据集 + 辅助数据集**组合查询。

---

## 8. regional_industry 使用规范

> ⚠️ **当查询某地区某产业链的企业分布情况时，必须使用 `regional_industry` 数据集并遵守以下规范。**

### 8.1 产业链筛选字段

- **必须使用 `industry_chain_name` 字段**进行筛选，不要用 `enterprise_name` 模糊匹配
- 正确写法：`{"field": "industry_chain_name", "op": "like", "value": "%人工智能%"}`

### 8.2 预定义指标字段（必须使用）

`regional_industry` 提供了专用统计字段，**不要**用 `count(enterprise_name)` 代替：

| 预定义字段 | 说明 |
|------------|------|
| `metric_enterprise_count` | 企业数量 |
| `metric_listed_count` | 上市企业数量 |
| `metric_unicorn_count` | 独角兽企业数量 |
| `metric_specialized_count` | 专精特新企业数量 |
| `metric_hightech_count` | 国家高新技术企业数量 |

### 8.3 常见支持的产业链

通过 `GET /api/v1/datasets/regional_industry/fields/industry_chain_name/enums` 可查询完整列表，常见产业链包括：

人工智能、半导体与集成电路、新能源、智能网联汽车、机器人、生物医药、高端医疗器械、网络与通信、软件与信息服务、智能传感器、智能终端、超高清视频显示、低空经济与空天 等

---

## 9. FilterCondition 操作符

| 操作符 | 说明 | value 类型 |
|--------|------|-----------|
| `=` | 等于 | 单个值（string / number） |
| `!=` | 不等于 | 单个值 |
| `in` | 包含（多值 OR） | 数组，如 `["广州市", "深圳市"]` |
| `between` | 区间（时间或数值） | 二元数组，如 `["2026-01-01", "2026-03-31"]` |
| `like` | 模糊匹配（`%` 通配） | 字符串，如 `"%科技%"` |
| `is_null` | 为空 | 无需 value |
| `is_not_null` | 不为空 | 无需 value |

**常用组合写法示例：**

- **广东省内（不含深圳）**：
  ```json
  [
    { "field": "province_name", "op": "=",  "value": "广东省" },
    { "field": "city_name",     "op": "!=", "value": "深圳市" }
  ]
  ```

- **多城市**：
  ```json
  { "field": "city_name", "op": "in", "value": ["广州市", "深圳市", "东莞市"] }
  ```

- **时间区间**：
  ```json
  { "field": "establish_date", "op": "between", "value": ["2026-01-01", "2026-03-31"] }
  ```

---
