# 工作台多维分析服务 — 示例文档

> 以下示例均使用默认 Token。实际调用前请从配置文件读取 `access_token`。  
> **服务地址**：`http://10.11.201.58:62306/`

---

## 目录

1. [认证头示例](#1-认证头示例)
2. [元数据查询示例](#2-元数据查询示例)
3. [明细查询示例](#3-明细查询示例)
4. [统计聚合示例](#4-统计聚合示例)
5. [同比环比示例](#5-同比环比示例)
6. [列级聚合示例](#6-列级聚合示例)
7. [穿透下钻与导出示例](#7-穿透下钻与导出示例)
8. [regional_industry 专项示例](#8-regional_industry-专项示例)
9. [PowerShell 调用示例](#9-powershell-调用示例)

---

## 1. 认证头示例

所有请求需在 Header 中携带：

```bash
-H "Authorization: Bearer wbt_f0a5aee67cf10cf0e1b426c5a90bbc9eafae75a5b10030e3d6aaba59"
-H "Content-Type: application/json; charset=utf-8"
```

> **PowerShell 注意事项**：使用 `Invoke-WebRequest` 代替 `Invoke-RestMethod`，并手动用 UTF-8 解码响应，避免中文乱码（详见 §9）。

---

## 2. 元数据查询示例

### 列出所有数据集

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets?page=1&page_size=20" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 搜索特定数据集

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets?search=企业&page=1&page_size=10" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 获取数据集字段列表

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets/enterprise_rating_score/fields" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 获取枚举字段可选值（省份列表）

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets/enterprise_rating_score/fields/province_name/enums?tree=true" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 级联获取枚举值（广东省下的城市列表）

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets/enterprise_rating_score/fields/city_name/enums?parent_field=province_name&parent_value=%E5%B9%BF%E4%B8%9C%E7%9C%81" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

---

## 3. 明细查询示例

### 场景：查询广东省存续企业名单（按评分降序）

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "fields": [
    "enterprise_name",
    "province_name",
    "city_name",
    "registration_status",
    "enterprise_size",
    "enterprise_rating_score"
  ],
  "filters": [
    { "field": "province_name",      "op": "=", "value": "广东省" },
    { "field": "registration_status","op": "=", "value": "存续"   }
  ],
  "sorts": [
    { "field": "enterprise_rating_score", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/query/detail" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","fields":["enterprise_name","province_name","city_name","registration_status","enterprise_size","enterprise_rating_score"],"filters":[{"field":"province_name","op":"=","value":"广东省"},{"field":"registration_status","op":"=","value":"存续"}],"sorts":[{"field":"enterprise_rating_score","order":"desc"}],"page":{"page":1,"page_size":20}}'
```

---

## 4. 统计聚合示例

### 场景1：各省企业数量排行

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "group_by": ["province_name"],
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数量" }
  ],
  "filters": [],
  "sorts": [
    { "field": "企业数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 50 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/query/stat" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","group_by":["province_name"],"metrics":[{"field":"enterprise_name","agg":"count","alias":"企业数量"}],"filters":[],"sorts":[{"field":"企业数量","order":"desc"}],"page":{"page":1,"page_size":50}}'
```

### 场景2：深圳市各区企业数量（TOP 10）

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "group_by": ["district_name"],
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数量" }
  ],
  "filters": [
    { "field": "city_name", "op": "=", "value": "深圳市" }
  ],
  "sorts": [
    { "field": "企业数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 10 }
}
```

---

## 5. 同比环比示例

### 场景：广东省与北京市企业数量同比增速

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "time_field": "rating_date",
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数" }
  ],
  "group_by": ["province_name"],
  "filters": [
    { "field": "province_name", "op": "in", "value": ["广东省", "北京市"] }
  ],
  "calc_type": "yoy"
}
```

**curl 命令：**
```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/query/calc" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","time_field":"rating_date","metrics":[{"field":"enterprise_name","agg":"count","alias":"企业数"}],"group_by":["province_name"],"filters":[{"field":"province_name","op":"in","value":["广东省","北京市"]}],"calc_type":"yoy"}'
```

---

## 6. 列级聚合示例

### 场景：广东省企业评分的总和/均值/最大最小值

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "columns": [
    { "field": "enterprise_rating_score", "calc_type": "sum"   },
    { "field": "enterprise_rating_score", "calc_type": "avg"   },
    { "field": "enterprise_rating_score", "calc_type": "max"   },
    { "field": "enterprise_rating_score", "calc_type": "min"   },
    { "field": "enterprise_rating_score", "calc_type": "count" }
  ],
  "filters": [
    { "field": "province_name", "op": "=", "value": "广东省" }
  ]
}
```

**curl 命令：**
```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/query/column-calc" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","columns":[{"field":"enterprise_rating_score","calc_type":"sum"},{"field":"enterprise_rating_score","calc_type":"avg"},{"field":"enterprise_rating_score","calc_type":"max"},{"field":"enterprise_rating_score","calc_type":"min"},{"field":"enterprise_rating_score","calc_type":"count"}],"filters":[{"field":"province_name","op":"=","value":"广东省"}]}'
```

---

## 7. 穿透下钻与导出示例

### 7.1 统计行穿透到明细

**场景：广东省企业明细（下钻）**

```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/export/drill" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","drill_field":"province_name","drill_value":"广东省","fields":["enterprise_name","city_name","district_name","enterprise_rating_score","registration_status"],"filters":[],"sorts":[{"field":"enterprise_rating_score","order":"desc"}],"page":{"page":1,"page_size":20}}'
```

### 7.2 单行详情

**场景：查询 ENT000001 企业全字段**

```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/export/row-detail" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","row_id_field":"enterprise_id","row_id_value":"ENT000001"}'
```

### 7.3 行数预估

```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/export/estimate" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","filters":[{"field":"province_name","op":"=","value":"广东省"}]}'
```

### 7.4 Excel 导出

```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/export/excel" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","fields":["enterprise_name","province_name","city_name","enterprise_rating_score"],"filters":[{"field":"province_name","op":"=","value":"广东省"},{"field":"city_name","op":"=","value":"深圳市"}],"max_rows":100}'
```

### 7.5 CSV 导出

```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/export/csv" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","fields":["enterprise_name","province_name","city_name","enterprise_rating_score"],"filters":[{"field":"province_name","op":"=","value":"北京市"}],"max_rows":50}'
```

---

## 8. regional_industry 专项示例

### 场景：深圳市人工智能企业按区县分布

**请求体：**
```json
{
  "dataset_id": "regional_industry",
  "group_by": ["province_name", "city_name", "district_name"],
  "metrics": [
    { "field": "metric_enterprise_count", "agg": "count", "alias": "企业数量"     },
    { "field": "metric_listed_count",     "agg": "count", "alias": "上市企业数量" },
    { "field": "metric_unicorn_count",    "agg": "count", "alias": "独角兽企业数量"}
  ],
  "filters": [
    { "field": "city_name",          "op": "=",    "value": "深圳市"     },
    { "field": "industry_chain_name","op": "like", "value": "%人工智能%" }
  ],
  "sorts": [],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://10.11.201.58:62306/api/v1/query/stat" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"regional_industry","group_by":["province_name","city_name","district_name"],"metrics":[{"field":"metric_enterprise_count","agg":"count","alias":"企业数量"},{"field":"metric_listed_count","agg":"count","alias":"上市企业数量"},{"field":"metric_unicorn_count","agg":"count","alias":"独角兽企业数量"}],"filters":[{"field":"city_name","op":"=","value":"深圳市"},{"field":"industry_chain_name","op":"like","value":"%人工智能%"}],"sorts":[],"page":{"page":1,"page_size":20}}'
```

### 查询支持的产业链枚举值

```bash
curl -s -X GET \
  "http://10.11.201.58:62306/api/v1/datasets/regional_industry/fields/industry_chain_name/enums" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

---

## 9. PowerShell 调用示例

> ⚠️ PowerShell 中必须使用 `Invoke-WebRequest` + 手动 UTF-8 解码，不要直接读 `$resp.Content`（会被 PowerShell 默认 GBK 编码损坏中文）。
>
> **核心要点**：通过 `RawContentStream` 创建 `StreamReader(UTF8)` 读取原始字节流，彻底绕过 PowerShell 的默认编码。

### 基础 GET 请求模板

```powershell
$headers = @{
    "Authorization" = "Bearer <access_token>"
    "Content-Type"  = "application/json; charset=utf-8"
}

$resp = Invoke-WebRequest -Uri "http://10.11.201.58:62306/api/v1/datasets?page=1&page_size=20" -Method Get -Headers $headers
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$data = $jsonText | ConvertFrom-Json
$data
```

### POST 请求模板

```powershell
$headers = @{
    "Authorization" = "Bearer <access_token>"
    "Content-Type"  = "application/json; charset=utf-8"
}

$bodyObj = @{
    dataset_id = "enterprise_rating_score"
    # ... 其他参数
}
$bodyBytes = [System.Text.Encoding]::UTF8.GetBytes(($bodyObj | ConvertTo-Json -Depth 10))

$resp = Invoke-WebRequest -Uri "http://10.11.201.58:62306/api/v1/query/stat" -Method Post -Headers $headers -Body $bodyBytes
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$data = $jsonText | ConvertFrom-Json
$data
```

### 完整示例：深圳市人工智能区县分布（PowerShell）

```powershell
$headers = @{
    "Authorization" = "Bearer wbt_f0a5aee67cf10cf0e1b426c5a90bbc9eafae75a5b10030e3d6aaba59"
    "Content-Type"  = "application/json; charset=utf-8"
}

$body = @'
{
  "dataset_id": "regional_industry",
  "group_by": ["province_name", "city_name", "district_name"],
  "metrics": [
    {"field": "metric_enterprise_count", "agg": "count", "alias": "企业数量"},
    {"field": "metric_listed_count",     "agg": "count", "alias": "上市企业数量"},
    {"field": "metric_unicorn_count",    "agg": "count", "alias": "独角兽企业数量"}
  ],
  "filters": [
    {"field": "city_name",           "op": "=",    "value": "深圳市"},
    {"field": "industry_chain_name", "op": "like", "value": "%人工智能%"}
  ],
  "sorts": [],
  "page": {"page": 1, "page_size": 20}
}
'@

$bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
$resp = Invoke-WebRequest -Uri "http://10.11.201.58:62306/api/v1/query/stat" -Method Post -Headers $headers -Body $bodyBytes
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$jsonText | ConvertFrom-Json | ConvertTo-Json -Depth 10
```

---
