# 工作台多维分析服务 — 示例文档

> 以下示例中的 `<access_token>` 为占位符，实际调用前请通过认证流程获取有效的 API Key。  
> **服务地址**：`http://172.25.246.14:62392/`

---

## 目录

1. [认证头示例](#1-认证头示例)
2. [元数据查询示例](#2-元数据查询示例)
3. [明细查询示例](#3-明细查询示例)
4. [统计聚合示例](#4-统计聚合示例)
5. [同比环比示例](#5-同比环比示例)
6. [列级聚合示例](#6-列级聚合示例)
7. [穿透下钻与导出示例](#7-穿透下钻与导出示例)
8. [regional_industry 专项示例](#8-regional_industry-专项示例)
9. [专利数据集专项示例](#9-专利数据集专项示例)
10. [PowerShell 调用示例](#10-powershell-调用示例)

---

## 1. 认证头示例

所有请求需在 Header 中携带：

```bash
-H "apikey: <access_token>"
-H "Content-Type: application/json; charset=utf-8"
```

> **⚠️ 安全提醒**：`<access_token>` 必须替换为用户自己的 API Key，切勿在示例或代码中硬编码真实 Token。
>
> **PowerShell 注意事项**：使用 `Invoke-WebRequest` 代替 `Invoke-RestMethod`，并手动用 UTF-8 解码响应，避免中文乱码（详见 §9）。

---

## 2. 元数据查询示例

### 列出所有数据集

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets?page=1&page_size=20" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 搜索特定数据集

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets?search=企业&page=1&page_size=10" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 获取数据集字段列表

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets/enterprise_rating_score/fields" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 获取枚举字段可选值（省份列表）

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets/enterprise_rating_score/fields/province_name/enums?tree=true" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

### 级联获取枚举值（广东省下的城市列表）

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets/enterprise_rating_score/fields/city_name/enums?parent_field=province_name&parent_value=%E5%B9%BF%E4%B8%9C%E7%9C%81" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

---

## 3. 明细查询示例

### 场景：查询广东省存续企业名单（按评分降序）

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "fields": [
    "enterprise_name",
    "province_name",
    "city_name",
    "registration_status",
    "enterprise_size",
    "enterprise_rating_score"
  ],
  "filters": [
    { "field": "province_name",      "op": "=", "value": "广东省" },
    { "field": "registration_status","op": "=", "value": "存续"   }
  ],
  "sorts": [
    { "field": "enterprise_rating_score", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/detail" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","fields":["enterprise_name","province_name","city_name","registration_status","enterprise_size","enterprise_rating_score"],"filters":[{"field":"province_name","op":"=","value":"广东省"},{"field":"registration_status","op":"=","value":"存续"}],"sorts":[{"field":"enterprise_rating_score","order":"desc"}],"page":{"page":1,"page_size":20}}'
```

---

## 4. 统计聚合示例

### 场景1：各省企业数量排行

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "group_by": ["province_name"],
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数量" }
  ],
  "filters": [],
  "sorts": [
    { "field": "企业数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 50 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/stat" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","group_by":["province_name"],"metrics":[{"field":"enterprise_name","agg":"count","alias":"企业数量"}],"filters":[],"sorts":[{"field":"企业数量","order":"desc"}],"page":{"page":1,"page_size":50}}'
```

### 场景2：深圳市各区企业数量（TOP 10）

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "group_by": ["district_name"],
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数量" }
  ],
  "filters": [
    { "field": "city_name", "op": "=", "value": "深圳市" }
  ],
  "sorts": [
    { "field": "企业数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 10 }
}
```

---

## 5. 同比环比示例

### 场景：广东省与北京市企业数量同比增速

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "time_field": "rating_date",
  "metrics": [
    { "field": "enterprise_name", "agg": "count", "alias": "企业数" }
  ],
  "group_by": ["province_name"],
  "filters": [
    { "field": "province_name", "op": "in", "value": ["广东省", "北京市"] }
  ],
  "calc_type": "yoy"
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/calc" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","time_field":"rating_date","metrics":[{"field":"enterprise_name","agg":"count","alias":"企业数"}],"group_by":["province_name"],"filters":[{"field":"province_name","op":"in","value":["广东省","北京市"]}],"calc_type":"yoy"}'
```

---

## 6. 列级聚合示例

### 场景：广东省企业评分的总和/均值/最大最小值

**请求体：**
```json
{
  "dataset_id": "enterprise_rating_score",
  "columns": [
    { "field": "enterprise_rating_score", "calc_type": "sum"   },
    { "field": "enterprise_rating_score", "calc_type": "avg"   },
    { "field": "enterprise_rating_score", "calc_type": "max"   },
    { "field": "enterprise_rating_score", "calc_type": "min"   },
    { "field": "enterprise_rating_score", "calc_type": "count" }
  ],
  "filters": [
    { "field": "province_name", "op": "=", "value": "广东省" }
  ]
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/column-calc" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"enterprise_rating_score","columns":[{"field":"enterprise_rating_score","calc_type":"sum"},{"field":"enterprise_rating_score","calc_type":"avg"},{"field":"enterprise_rating_score","calc_type":"max"},{"field":"enterprise_rating_score","calc_type":"min"},{"field":"enterprise_rating_score","calc_type":"count"}],"filters":[{"field":"province_name","op":"=","value":"广东省"}]}'
```

---

## 8. regional_industry 专项示例

### 场景：深圳市人工智能企业按区县分布

**请求体：**
```json
{
  "dataset_id": "regional_industry",
  "group_by": ["province_name", "city_name", "district_name"],
  "metrics": [
    { "field": "metric_enterprise_count", "agg": "count", "alias": "企业数量"     },
    { "field": "metric_listed_count",     "agg": "count", "alias": "上市企业数量" },
    { "field": "metric_unicorn_count",    "agg": "count", "alias": "独角兽企业数量"}
  ],
  "filters": [
    { "field": "city_name",          "op": "=",    "value": "深圳市"     },
    { "field": "industry_chain_name","op": "like", "value": "%人工智能%" }
  ],
  "sorts": [],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/stat" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"regional_industry","group_by":["province_name","city_name","district_name"],"metrics":[{"field":"metric_enterprise_count","agg":"count","alias":"企业数量"},{"field":"metric_listed_count","agg":"count","alias":"上市企业数量"},{"field":"metric_unicorn_count","agg":"count","alias":"独角兽企业数量"}],"filters":[{"field":"city_name","op":"=","value":"深圳市"},{"field":"industry_chain_name","op":"like","value":"%人工智能%"}],"sorts":[],"page":{"page":1,"page_size":20}}'
```

### 查询支持的产业链枚举值

```bash
curl -s -X GET \
  "http://172.25.246.14:62392/api/v1/datasets/regional_industry/fields/industry_chain_name/enums" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

---

## 9. 专利数据集专项示例

> ⚠️ **核心规则**：使用专利数据集时，涉及专利权人名称/类型/区域归属的查询，**必须使用 `first_patentee_*`（第一专利权人）字段**，不要使用 `first_original_applicant_*`（申请人）字段。
>
> 适用数据集：`ds_51980066`（区域产业专利分析）、`ds_750bc795`（专利基础画像）

### 场景1：按第一专利权人所在城市统计专利数量

**请求体：**
```json
{
  "dataset_id": "ds_51980066",
  "group_by": ["first_patentee_city"],
  "metrics": [
    { "field": "patent_id", "agg": "count", "alias": "专利数量" }
  ],
  "filters": [
    { "field": "first_patentee_province", "op": "=", "value": "广东省" },
    { "field": "industry_chain_name",     "op": "=", "value": "人工智能" }
  ],
  "sorts": [
    { "field": "专利数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/stat" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"ds_51980066","group_by":["first_patentee_city"],"metrics":[{"field":"patent_id","agg":"count","alias":"专利数量"}],"filters":[{"field":"first_patentee_province","op":"=","value":"广东省"},{"field":"industry_chain_name","op":"=","value":"人工智能"}],"sorts":[{"field":"专利数量","order":"desc"}],"page":{"page":1,"page_size":20}}'
```

### 场景2：查询某企业（第一专利权人）的专利明细

**请求体：**
```json
{
  "dataset_id": "ds_51980066",
  "fields": [
    "patent_title",
    "patent_type_name",
    "application_number",
    "application_date",
    "first_patentee_name",
    "patent_value"
  ],
  "filters": [
    { "field": "first_patentee_name", "op": "like", "value": "%华为%" }
  ],
  "page": { "page": 1, "page_size": 20 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/detail" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"ds_51980066","fields":["patent_title","patent_type_name","application_number","application_date","first_patentee_name","patent_value"],"filters":[{"field":"first_patentee_name","op":"like","value":"%华为%"}],"page":{"page":1,"page_size":20}}'
```

### 场景3：按第一专利权人统计 TOP N（专利数量排行）

**请求体：**
```json
{
  "dataset_id": "ds_750bc795",
  "group_by": ["first_patentee_name"],
  "metrics": [
    { "field": "patent_id", "agg": "count", "alias": "专利数量" }
  ],
  "filters": [
    { "field": "first_patentee_city", "op": "=", "value": "深圳市" },
    { "field": "patent_type_name",     "op": "=", "value": "发明专利" }
  ],
  "sorts": [
    { "field": "专利数量", "order": "desc" }
  ],
  "page": { "page": 1, "page_size": 10 }
}
```

**curl 命令：**
```bash
curl -s -X POST "http://172.25.246.14:62392/api/v1/query/stat" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"dataset_id":"ds_750bc795","group_by":["first_patentee_name"],"metrics":[{"field":"patent_id","agg":"count","alias":"专利数量"}],"filters":[{"field":"first_patentee_city","op":"=","value":"深圳市"},{"field":"patent_type_name","op":"=","value":"发明专利"}],"sorts":[{"field":"专利数量","order":"desc"}],"page":{"page":1,"page_size":10}}'
```

---

## 10. PowerShell 调用示例

> ⚠️ PowerShell 中必须使用 `Invoke-WebRequest` + 手动 UTF-8 解码，不要直接读 `$resp.Content`（会被 PowerShell 默认 GBK 编码损坏中文）。
>
> **核心要点**：通过 `RawContentStream` 创建 `StreamReader(UTF8)` 读取原始字节流，彻底绕过 PowerShell 的默认编码。

### 基础 GET 请求模板

```powershell
$headers = @{
    "apikey" = "<access_token>"
    "Content-Type"  = "application/json; charset=utf-8"
}

$resp = Invoke-WebRequest -Uri "http://172.25.246.14:62392/api/v1/datasets?page=1&page_size=20" -Method Get -Headers $headers
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$data = $jsonText | ConvertFrom-Json
$data
```

### POST 请求模板

```powershell
$headers = @{
    "apikey" = "<access_token>"
    "Content-Type"  = "application/json; charset=utf-8"
}

$bodyObj = @{
    dataset_id = "enterprise_rating_score"
    # ... 其他参数
}
$bodyBytes = [System.Text.Encoding]::UTF8.GetBytes(($bodyObj | ConvertTo-Json -Depth 10))

$resp = Invoke-WebRequest -Uri "http://172.25.246.14:62392/api/v1/query/stat" -Method Post -Headers $headers -Body $bodyBytes
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$data = $jsonText | ConvertFrom-Json
$data
```

### 完整示例：深圳市人工智能区县分布（PowerShell）

```powershell
$headers = @{
    "apikey" = "<access_token>"
    "Content-Type"  = "application/json; charset=utf-8"
}

$body = @'
{
  "dataset_id": "regional_industry",
  "group_by": ["province_name", "city_name", "district_name"],
  "metrics": [
    {"field": "metric_enterprise_count", "agg": "count", "alias": "企业数量"},
    {"field": "metric_listed_count",     "agg": "count", "alias": "上市企业数量"},
    {"field": "metric_unicorn_count",    "agg": "count", "alias": "独角兽企业数量"}
  ],
  "filters": [
    {"field": "city_name",           "op": "=",    "value": "深圳市"},
    {"field": "industry_chain_name", "op": "like", "value": "%人工智能%"}
  ],
  "sorts": [],
  "page": {"page": 1, "page_size": 20}
}
'@

$bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
$resp = Invoke-WebRequest -Uri "http://172.25.246.14:62392/api/v1/query/stat" -Method Post -Headers $headers -Body $bodyBytes
$sr = [System.IO.StreamReader]::new($resp.RawContentStream, [System.Text.Encoding]::UTF8)
$jsonText = $sr.ReadToEnd()
$sr.Close()
$jsonText | ConvertFrom-Json | ConvertTo-Json -Depth 10
```

---
