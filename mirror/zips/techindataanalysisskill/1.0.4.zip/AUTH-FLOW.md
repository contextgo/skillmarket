# 🔑 API Key 认证流程

**【强制规则】每次 skill 被加载后，在执行任何数据查询之前，必须先完成 API Key 认证。**

---

## 认证流程概览

```
skill 被加载
    ↓
1. 检查记忆中是否已保存用户的 API Key
    ↓
   ┌─ 已保存 → 直接使用，跳到「验证 Key」
   │
   └─ 未保存 ↓
2. 向用户索要 API Key（引导用户去多维分析 2.0 平台获取）
    ↓
3. 用户发送 API Key → 保存到记忆中
    ↓
4. 验证 Key 有效性（调用一个轻量接口）
    ↓
   ┌─ 验证成功 → 继续执行用户的查询请求
   │
   └─ 验证失败 → 提示用户 Key 无效，要求重新提供
```

---

## Step 1: 检查是否已有 API Key

AI 助手在执行查询前，先读取工作记忆文件，查找是否已保存 `techin_api_key`。

**查找位置：** 工作记忆文件（`MEMORY.md` 或 `{skill_base_dir}/config.json`）

**已保存的判断标准：** 记忆中存在 `techin_api_key` 字段且值非空。

---

## Step 2: 向用户索要 API Key（仅在未保存时）

如果记忆中没有找到 API Key，助手**必须主动引导用户**获取并提交 Key，**不能跳过此步骤直接使用硬编码的 token 或空 token 调用接口**。

**引导话术（必须包含以下要点）：**

> 要使用多维分析数据查询功能，需要先配置你的 API Key。
>
> 📌 **获取方式：**
> 登录「多维分析 2.0」平台 → 点击个人头像 → 进入「消息中心」→ 复制你的 API Key
>
> 拿到 Key 后直接发给我就行，我会帮你保存好，以后不用重复操作。

**注意事项：**
- 不要在引导话术中出现示例 Key 或假 Key
- 用户发送 Key 后，进入 Step 3
- 如果用户问"什么是 API Key"或"去哪里拿"，再次耐心引导

---

## Step 3: 保存 API Key 到记忆

用户发送 API Key 后，助手**必须**将 Key 保存到工作记忆中，确保跨会话可用。

**保存方式（二选一，优先方式一）：**

- **方式一（推荐）**：写入 `{skill_base_dir}/config.json`，格式为 `{"access_token": "用户提供的Key"}`
- **方式二**：写入工作记忆 `MEMORY.md`，追加条目 `techin_api_key: 用户提供的Key`

**保存确认话术：**

> ✅ API Key 已保存成功，后续会话无需重复输入。让我来验证一下 Key 是否有效……

---

## Step 4: 验证 Key 有效性

保存后，助手**必须**发起一次轻量级 API 调用来验证 Key 是否有效。

**验证接口：**
```bash
curl -s "http://172.25.246.14:62392/api/v1/datasets?page=1&page_size=1" \
  -H "apikey: <access_token>" \
  -H "Content-Type: application/json; charset=utf-8"
```

**判断标准：**
- HTTP 200 且返回正常 JSON → Key 有效，继续执行用户请求
- HTTP 401/403 → Key 无效或已过期，提示用户：
  > ❌ API Key 无效或已过期，请重新登录多维分析 2.0 平台获取新的 Key。
- 网络超时/连接失败 → 提示服务暂时不可用，请稍后重试

---

## Token 获取优先级

| 优先级 | 来源 | 说明 |
|--------|------|------|
| 1 | `{skill_base_dir}/config.json` 中的 `access_token` | 通过交互流程保存的 |
| 2 | 工作记忆中的 `techin_api_key` | 备用存储 |

如果所有来源都没有有效的 Key，走 Step 2 的索要流程。

---

## 认证方式

所有请求 Header 中必须携带：

```
apikey: <access_token>
Content-Type: application/json; charset=utf-8
```

> ⚠️ `<access_token>` 必须是用户通过上述认证流程提供的有效 Key，**禁止使用空值或硬编码的默认值**。
