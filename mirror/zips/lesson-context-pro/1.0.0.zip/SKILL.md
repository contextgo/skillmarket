---
name: "lesson-context-pro"
description: "根据教师上传的图片/课件/教材页面，自动生成完整的小学英语课堂情境方案（含4个HTML互动游戏），采用现实场景互动设计（仓库整理、超市购物等）+ 圆润可爱视觉风格。当用户上传教材图片、课件截图、或请求'创设教学情境''生成课堂游戏''设计互动关卡'时调用。"
---

# 🎓 Lesson Context Pro - 现实场景互动游戏版（4关卡）

## 概述

这是一个增强版的教学情境生成 Skill，完美融合：
1. **📚 教学情境设计**：完整的教案、4个递进式关卡、教学法
2. **🎮 现实场景互动**：仓库整理、超市购物、厨房烹饪等真实任务场景
3. **🎨 Round & Cute 视觉风格**：圆润可爱、色彩丰富、童趣十足的前端设计
4. **📊 错误记录系统**：每个关卡都记录错误次数和扣分机制
5. **🏆 评价等级系统**：根据表现给出差异化评级

### 核心价值

| 维度 | 原版 | 本版本 |
|------|------|--------|
| **关卡数量** | 3关 | **4关（新增复习巩固）** |
| **视觉风格** | 专业级 Production | **Round & Cute 圆润可爱** |
| **场景设计** | 抽象界面 | **现实场景（仓库/超市/厨房等）** |
| **互动方式** | 简单点击 | **任务驱动的场景互动** |
| **字体选择** | Fredoka+Nunito | **Fredoka One + Quicksand（更圆润）** |
| **配色方案** | 大胆高饱和 | **马卡龙色系 + 柔和渐变** |
| **形状风格** | 直角/小圆角 | **大圆角 + 胶囊形 + 圆形** |
| **动画效果** | 弹性微交互 | **Q弹果冻效果 + 跳跃动画** |
| **错误记录** | 无 | **✅ 完整的错误追踪+扣分+评级** |

---

## 使用场景

当以下情况发生时，**必须立即调用此 Skill**：

1. ✅ 用户上传了教材图片、课件截图、主题图片
2. ✅ 用户说"帮我创设一个情境""生成课堂游戏""制作互动课件"
3. ✅ 用户提到"小学英语""三年级""教学设计""4个游戏"等关键词
4. ✅ 用户希望生成 HTML 格式的教学游戏
5. ✅ 用户要求"可爱风格""圆润风格""卡通风格"
6. ✅ 用户需要高质量视觉效果的教学游戏（公开课/示范课）

---

## 执行流程（7步法）

### 第一步：图片内容分析 🔍

#### 1.1 视觉元素识别
```
- 主要场景（餐厅、厨房、超市、学校等）
- 人物角色（厨师、老师、学生、卡通形象等）
- 物品道具（食物、文具、玩具等）
- 色彩风格（明亮、温馨、活泼等）
```

#### 1.2 文字信息提取
```
核心词汇（5-8个）:
  - 中文含义
  - 英文单词
  - 配图/emoji

拓展词汇（3-5个）:
  - 相关联的词汇

句型结构（2-3个）:
  - 核心对话
  - 关键表达方式
  - Chant/Rap句型
```

#### 1.3 输出分析报告示例
```markdown
## 📸 图片分析报告

**识别到的内容:**
- 页面来源: 人教版 PEP 英语 P44
- 单元主题: Unit 5 - My Healthy Plate
- 核心词汇: soup, rice, fruit, meat, vegetables (+ water, milk, juice)
- 核心句型: "This is my healthy plate." / "I have..." / "We are healthy."
- 情感基调: 健康、积极、生活化、欢快
- 目标年级: 小学三年级
```

---

### 第二步：情境主线设计 🎭

基于图片分析，创建有故事性、任务感的情境。

#### 2.1 设计原则
```
✅ 真实贴近生活（8-9岁学生熟悉的场景：超市、仓库、厨房、餐厅等）
✅ 有趣有吸引力（融入魔法、冒险、闯关、奖励）
✅ 有明确目标（通过英语学习完成任务）
✅ 贯穿全课（延伸到导入→新授→练习→巩固→复习→总结）
✅ 语言融合自然（目标词汇和句型融入任务）
✅ 场景沉浸感（让学生感觉自己真的在仓库整理、超市购物、厨房做饭）
```

#### 2.2 🌟 现实场景题库（核心！）

**场景设计原则：每个关卡都是一个真实的任务场景！**

| 场景类型 | 情境示例 | 适合词汇 | 互动形式 |
|----------|----------|----------|----------|
| 📦 **仓库整理** | 帮管理员整理货物、找物品 | 食物/文具/玩具 | 拖拽分类、寻找匹配 |
| 🛒 **超市购物** | 根据清单购物、收银结账 | 食物/日用品 | 点击收集、清单核对 |
| 🍳 **厨房烹饪** | 按菜谱准备食材、做菜 | 食物/厨具 | 拖拽食材、步骤排序 |
| 🍽️ **餐厅点餐** | 服务员点餐、顾客选菜 | 食物/饮料 | 菜单选择、对话模拟 |
| 🌾 **农场采摘** | 采摘蔬菜水果、装箱 | 蔬果/动物 | 点击收集、分类装箱 |
| 🎒 **书包整理** | 整理书包、准备上学 | 文具/书本 | 拖拽分类、清单核对 |
| 🏥 **看病买药** | 描述症状、买药 | 身体部位/药品 | 对话选择、物品匹配 |
| 🎪 **游乐园** | 买票、玩项目 | 数字/项目名 | 排队选择、任务完成 |
| 📚 **图书馆** | 借书、还书、找书 | 书本类型 | 分类检索、搜索匹配 |
| 🏠 **家务劳动** | 打扫房间、洗衣服 | 家具/清洁用品 | 拖拽整理、步骤排序 |

#### 2.3 场景化关卡设计模板

每个关卡都应该有：
```
1. 角色设定：玩家是谁？（仓库管理员、小厨师、超市收银员...）
2. 任务目标：要完成什么？（整理仓库、准备晚餐、完成购物清单...）
3. 场景描述：在哪里？周围有什么？
4. 语言融入：在这个场景中自然使用英语
5. 成功反馈：完成任务后的成就感
```

**示例 - 仓库整理场景：**
```markdown
## 📦 场景：帮仓库管理员整理货物

**角色:** 你是小小仓库管理员
**任务:** 货物到了！请把食材分类放到正确的货架上
**场景描述:** 
  - 面前有4个货架：Grains（谷物）、Protein（蛋白质）、Vegetables（蔬菜）、Fruits（水果）
  - 传送带上不断送来各种食材
  - 需要把每个食材拖到正确的货架

**语言融入:**
  - "Put the rice in the grains shelf!"
  - "Where does the meat go?"
  - "This is the vegetables section!"

**成功反馈:** 
  - 货架被填满时亮起绿灯
  - 播放"货物整理完成"的庆祝动画
  - 获得"金牌管理员"徽章
```

#### 2.4 4关卡递进式设计矩阵（场景版）⭐

| 关卡 | 名称 | 现实场景 | 对应环节 | 难度 | 游戏类型 | 认知层次 | 错误处理 |
|------|------|----------|----------|------|----------|----------|----------|
| 1 | 词汇认知 | 🏭 食材仓库 | 导入+新授 | ★☆☆ | 场景点击识别 | Remember | 错误扣分+记录 |
| 2 | 分类整理 | 📦 仓库整理 | 练习+巩固 | ★★☆ | 拖拽分类入架 | Understand | 错误扣分+记录 |
| 3 | 任务执行 | 🛒 超市购物 | 综合运用 | ★★★ | 清单任务完成 | Apply/Create | 操作错误扣分 |
| 4 | 复习巩固 | 🏆 店长考核 | 总结+复习 | ★★☆ | 综合场景测试 | Evaluate | 错误扣分+最终评级 |

#### 2.5 关卡场景连贯性要求
```
关卡1（认识食材） → 关卡2（整理分类） → 关卡3（实际应用） → 关卡4（能力考核）
     ↓                   ↓                    ↓                    ↓
   认识货物             整理仓库              完成购物任务          店长综合考核
```

每个关卡之间要有情节过渡，形成完整的故事线。
例如：
- 关卡1结束："你认识了很多食材，仓库管理员请你帮忙整理！"
- 关卡2结束："仓库整理好了，今天超市有特价活动，去购物吧！"
- 关卡3结束："购物任务完成！店长要考核你的能力！"
- 关卡4结束："恭喜你通过考核，成为金牌店员！"

---

### 第三步：🎨 ROUND & CUTE 风格设计规范（关键！）

这是本版本的**核心特色**！

#### 3.1 🎨 Design Philosophy（设计理念）

```
Purpose（目的）: 小学低年级英语教学游戏 - 要可爱！要吸引孩子！
Tone（基调）: 
  - Round & Cute（圆润可爱）
  - Playful & Bouncy（活泼弹跳）
  - Warm & Friendly（温暖友好）
  
Differentiation（差异化）: 
  什么是让人难忘的 ONE THING？
  → 一切都是圆圆的！按钮是圆的、卡片是圆的、动画是弹跳的！
  → 像糖果一样甜美的马卡龙色系！
  → 像果冻一样Q弹的交互动画！
```

#### 3.2 🎨 Typography（字体系统）

**推荐字体组合（Google Fonts）：**

##### 方案A：超圆润组合（强烈推荐 ⭐⭐⭐⭐⭐）
```css
/* Display Font（标题/强调）- 超圆润 */
@import url('https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap');

/* Body Font（正文/UI）- 圆润友好 */
@import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap');

/* 使用 */
h1, h2, .game-title { font-family: 'Fredoka One', cursive; }
body, p, .instruction { font-family: 'Quicksand', sans-serif; }
```

##### 方案B：趣味气泡组合
```css
@import url('https://fonts.googleapis.com/css2?family=Bubblegum+Sans&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap');

h1, h2 { font-family: 'Bubblegum Sans', cursive; }
body { font-family: 'Nunito', sans-serif; }
```

**禁止使用的字体：**
```
❌ Inter, Roboto, Arial, system-ui（太生硬）
❌ Space Grotesk（太技术感）
❌ 任何尖锐/棱角的字体
```

#### 3.3 🎨 Color Palette - 马卡龙色系（Macaron Colors）

**主色调方案（温暖甜美）：**
```css
:root {
    /* 主色 - 糖果粉 */
    --color-primary: #FF6B9D;          /* 粉红 */
    --color-primary-light: #FFB8D0;    /* 浅粉 */
    --color-primary-dark: #E84A7F;     /* 深粉 */
    
    /* 辅助色 - 奶油黄 */
    --color-secondary: #FFD93D;         /* 明黄 */
    --color-secondary-light: #FFE566;   /* 浅黄 */
    
    /* 功能色 - 薄荷绿 */
    --color-success: #6BCB77;           /* 成功绿 */
    --color-success-light: #A8E6CF;     /* 浅绿 */
    
    /* 警告色 - 天空蓝 */
    --color-info: #4D96FF;              /* 信息蓝 */
    --color-info-light: #A8C8FF;        /* 浅蓝 */
    
    /* 错误色 - 珊瑚橙 */
    --color-error: #FF6B6B;             /* 错误红 */
    --color-error-light: #FFB3B3;       /* 浅红 */
    
    /* 中性色 - 云朵白 */
    --color-bg: #FFF9F5;                /* 暖白背景 */
    --color-surface: #FFFFFF;           /* 纯白卡片 */
    --color-text: #2D3436;              /* 深灰文字 */
    --color-text-muted: #95A5A6;        /* 浅灰文字 */
}
```

**渐变背景方案：**
```css
body {
    background: 
        /* 多层柔和径向渐变 */
        radial-gradient(at 20% 30%, rgba(255,107,157,0.15) 0px, transparent 50%),
        radial-gradient(at 80% 70%, rgba(255,217,61,0.12) 0px, transparent 50%),
        radial-gradient(at 50% 90%, rgba(107,203,119,0.10) 0px, transparent 50%),
        radial-gradient(at 90% 20%, rgba(77,150,255,0.08) 0px, transparent 50%),
        /* 主背景渐变 */
        linear-gradient(135deg, #FFF9F5 0%, #FFE8F0 50%, #F0FFF4 100%);
}
```

**禁止使用：**
```
❌ 紫色渐变 (#667eea → #764ba2) - 太成人化
❌ 黑暗模式配色 - 不适合小学生
❌ 高对比度冷色调 - 太严肃
❌ 默认 Bootstrap/Tailwind 配色 - 无特色
```

#### 3.4 🎨 Shape System（形状系统 - 一切都要圆！）

**圆角规范：**
```css
:root {
    /* 超大圆角 - 用于主要容器 */
    --radius-xl: 40px;
    --radius-xxl: 50px;
    
    /* 大圆角 - 用于卡片 */
    --radius-lg: 28px;
    
    /* 中圆角 - 用于按钮 */
    --radius-md: 20px;
    
    /* 小圆角 - 用于标签 */
    --radius-sm: 14px;
    
    /* 完全圆形 - 用于头像/图标 */
    --radius-full: 9999px;
    
    /* 胶囊形 - 用于按钮/标签 */
    --radius-pill: 9999px;
}

/* 实际应用 */
.game-container {
    border-radius: var(--radius-xxl);  /* 50px 超圆 */
}

.card {
    border-radius: var(--radius-lg);   /* 28px 大圆 */
}

.btn {
    border-radius: var(--radius-pill); /* 胶囊形 */
}

.tag {
    border-radius: var(--radius-pill); /* 胶囊形 */
}
```

**形状特点：**
```
✅ 按钮：胶囊形（border-radius: 9999px）
✅ 卡片：大圆角（28-40px）
✅ 图标容器：完全圆形
✅ 进度条：胶囊形
✅ 徽章/标签：椭圆形或胶囊形
✅ 输入框：大圆角（20px）
✅ 图片：超大圆角或圆形
```

#### 3.5 🎨 Motion & Animation（动画系统 - Q弹果冻风）

**核心原则：**
```
✅ 所有动画都要有弹性（bounce/spring效果）
✅ 使用 cubic-bezier(0.68, -0.55, 0.265, 1.55) - 果冻曲线
✅ 元素像糖果一样跳跃入场
✅ 悬停时轻微放大+旋转（不超过5度）
✅ 成功时庆祝跳动（scale + rotate 组合）
✅ 错误时左右摇晃（像摇头一样）
```

##### A. Page Load Animation（页面加载 - 糖果掉落）
```css
/* Staggered Candy Drop（交错糖果掉落） */
.game-container > * {
    opacity: 0;
    transform: translateY(-30px) scale(0.8);
    animation: candyDrop 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards;
}

.game-container > *:nth-child(1) { animation-delay: 0.05s; }
.game-container > *:nth-child(2) { animation-delay: 0.1s; }
.game-container > *:nth-child(3) { animation-delay: 0.15s; }

@keyframes candyDrop {
    0% {
        opacity: 0;
        transform: translateY(-30px) scale(0.8);
    }
    60% {
        transform: translateY(5px) scale(1.05);
    }
    100% {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}
```

##### B. Micro-interactions（微交互 - Q弹悬停）
```css
/* Hover States with Bounce（弹跳悬停） */
.food-card {
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

.food-card:hover {
    transform: translateY(-10px) scale(1.08) rotate(-3deg);
    box-shadow: 
        0 20px 40px rgba(255,107,157,0.25),
        0 0 0 6px rgba(255,107,157,0.15);
}
```

##### C. Success Feedback（成功反馈 - 庆祝跳跃）
```css
.correct-answer {
    animation: celebrateBounce 0.7s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

@keyframes celebrateBounce {
    0% { transform: scale(1); }
    25% { transform: scale(1.25) rotate(-8deg); }
    50% { transform: scale(1.15) rotate(8deg); }
    75% { transform: scale(1.2) rotate(-4deg); }
    100% { transform: scale(1) rotate(0); }
}
```

##### D. Error Feedback（错误反馈 - 可爱摇头）
```css
.wrong-answer {
    animation: cuteShake 0.6s ease;
}

@keyframes cuteShake {
    0%, 100% { transform: translateX(0) rotate(0); }
    15% { transform: translateX(-12px) rotate(-5deg); }
    30% { transform: translateX(10px) rotate(4deg); }
    45% { transform: translateX(-8px) rotate(-3deg); }
    60% { transform: translateX(6px) rotate(2deg); }
    75% { transform: translateX(-4px) rotate(-1deg); }
}
```

##### E. Floating Animation（漂浮动画 - 轻柔飘动）
```css
@keyframes gentleFloat {
    0%, 100% { transform: translateY(0) rotate(-2deg); }
    50% { transform: translateY(-15px) rotate(2deg); }
}

.trophy, .medal, .mascot {
    animation: gentleFloat 3s ease-in-out infinite;
}
```

##### F. Pulse Animation（心跳脉冲 - 吸引注意）
```css
@keyframes heartbeatPulse {
    0%, 100% { transform: scale(1); }
    14% { transform: scale(1.15); }
    28% { transform: scale(1); }
    42% { transform: scale(1.1); }
    70% { transform: scale(1); }
}

.btn-primary:hover::after,
.highlight-element {
    animation: heartbeatPulse 2s infinite;
}
```

#### 3.6 🎨 Component Styling（组件样式规范）

##### Button（按钮 - 胶囊糖果）
```css
.btn-primary {
    font-family: var(--font-display);
    font-weight: 700;
    font-size: 18px;
    padding: 18px 42px;
    border: none;
    border-radius: var(--radius-pill);  /* 胶囊形 */
    background: linear-gradient(135deg, var(--color-primary), var(--color-primary-dark));
    color: white;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    box-shadow: 
        0 8px 24px rgba(255,107,157,0.35),
        inset 0 3px 0 rgba(255,255,255,0.25),
        inset 0 -3px 0 rgba(0,0,0,0.1);
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    text-shadow: 0 2px 4px rgba(0,0,0,0.15);
}

.btn-primary:hover {
    transform: translateY(-6px) scale(1.06);
    box-shadow: 
        0 16px 36px rgba(255,107,157,0.45),
        inset 0 3px 0 rgba(255,255,255,0.25),
        inset 0 -3px 0 rgba(0,0,0,0.1);
}

.btn-primary:active {
    transform: translateY(-2px) scale(0.98);
}
```

##### Card（卡片 - 软糖质感）
```css
.card {
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    padding: 28px;
    border: 3px solid transparent;
    position: relative;
    overflow: hidden;
    box-shadow: 
        0 8px 30px rgba(0,0,0,0.08),
        0 2px 8px rgba(0,0,0,0.04);
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, 
        var(--color-primary), 
        var(--color-secondary), 
        var(--color-success)
    );
    border-radius: var(--radius-lg) var(--radius-lg) 0 0;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.card:hover {
    transform: translateY(-10px) scale(1.03) rotate(-1deg);
    box-shadow: 
        0 20px 50px rgba(0,0,0,0.12),
        0 0 0 4px rgba(255,107,157,0.12);
}

.card:hover::before {
    opacity: 1;
}
```

##### Input/Input Field（输入框 - 云朵状）
```css
.input-field {
    width: 100%;
    padding: 18px 28px;
    font-size: 18px;
    font-family: var(--font-body);
    font-weight: 600;
    border: 3px solid #E8E8E8;
    border-radius: var(--radius-md);
    background: linear-gradient(135deg, #FFFFFF, #FAFAFA);
    outline: none;
    transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    box-shadow: inset 0 2px 8px rgba(0,0,0,0.04);
}

.input-field:focus {
    border-color: var(--color-primary);
    box-shadow: 
        0 0 0 6px rgba(255,107,157,0.15),
        inset 0 2px 8px rgba(0,0,0,0.04),
        0 8px 24px rgba(255,107,157,0.15);
    transform: translateY(-3px);
}
```

##### Progress Bar（进度条 - 彩虹糖果条）
```css
.progress-bar-container {
    width: 100%;
    height: 20px;
    background: #F0F0F0;
    border-radius: var(--radius-pill);
    overflow: hidden;
    box-shadow: inset 0 3px 8px rgba(0,0,0,0.1);
}

.progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, 
        var(--color-primary), 
        var(--color-secondary), 
        var(--color-success),
        var(--color-info)
    );
    border-radius: var(--radius-pill);
    transition: width 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    position: relative;
    overflow: hidden;
}

.progress-bar-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, 
        transparent, 
        rgba(255,255,255,0.5), 
        transparent
    );
    animation: shimmerMove 2s infinite;
}

@keyframes shimmerMove {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}
```

#### 3.7 🎨 Decorative Elements（装饰元素）

##### A. Cloud Shapes（云朵装饰）
```css
.cloud-decoration {
    position: absolute;
    background: rgba(255,255,255,0.7);
    border-radius: 100px;
    filter: blur(2px);
}

.cloud-1 {
    width: 120px;
    height: 50px;
    top: -20px;
    right: 10%;
}

.cloud-2 {
    width: 80px;
    height: 35px;
    bottom: 20px;
    left: 5%;
}
```

##### B. Star Sprinkles（星星撒点）
```css
.star-sparkle {
    position: absolute;
    font-size: 20px;
    animation: twinkle 2s ease-in-out infinite;
    pointer-events: none;
}

@keyframes twinkle {
    0%, 100% { opacity: 0.3; transform: scale(0.8) rotate(0deg); }
    50% { opacity: 1; transform: scale(1.2) rotate(180deg); }
}
```

##### C. Confetti Style（彩纸 - 更多彩更可爱）
```javascript
function createConfetti() {
    const colors = [
        '#FF6B9D', '#FFD93D', '#6BCB77', '#4D96FF',
        '#FF9F43', '#EE5A6F', '#A29BFE', '#FD79A8'
    ];
    const shapes = ['circle', 'star', 'heart'];
    // ... 创建150片彩纸
}
```

#### 3.8 🎨 Background Details（背景细节）

**多层渐变 + 柔和光晕：**
```css
body {
    background: 
        /* 柔和光晕层 */
        radial-gradient(at 20% 30%, rgba(255,107,157,0.12) 0px, transparent 50%),
        radial-gradient(at 80% 70%, rgba(255,217,61,0.10) 0px, transparent 50%),
        radial-gradient(at 50% 90%, rgba(107,203,119,0.08) 0px, transparent 50%),
        radial-gradient(at 90% 20%, rgba(77,150,255,0.06) 0px, transparent 50%),
        /* 主背景 */
        linear-gradient(135deg, #FFF9F5 0%, #FFE8F0 50%, #F0FFF4 100%);
}
```

**可选：波点图案叠加（增加童趣）：**
```css
.pattern-dots {
    background-image: radial-gradient(circle, rgba(255,107,157,0.08) 2px, transparent 2px);
    background-size: 32px 32px;
}
```

---

### 第四步：4个递进式关卡详细设计 🎮

#### 关卡模板结构

```markdown
### 🎮 关卡 N：[名称]

**基本信息:**
- 对应环节: [导入/新授/练习/巩固/复习]
- 预计时长: [X分钟]
- 难度等级: [★~★★★]

**游戏机制:**
- 游戏类型: [点击/拖拽/填空/匹配/创作/综合]
- 操作方式: [鼠标/触屏/键盘]
- 交互反馈: [正确音效/错误提示/进度显示/星级评分]

**错误处理:**
- 错误扣分: [X] 分/次
- 错误上限: [无限制/最多X次]
- 错误反馈: [文字提示/动画提示/声音提示]
- 最终评级: [根据错误率分级]

**任务描述（情境化语言）:**

**语言要求:**
- 必须使用词汇: [...]
- 必须使用句型: [...]
- 输出形式: [口语/书面/两者结合]

**通关条件:**
- [具体完成标准]

**差异化支持:**
- 学困生: [...]
- 中等生: [...]
- 优等生: [...]
```

#### 4.1 关卡1：词汇认知（Remember 层次）

**场景化示例：🏭 食材仓库找货**
- 场景描述：你是仓库管理员，面前有多个货架堆满食材
- 任务：系统提示"Find the soup!"，你在仓库中找到正确的食材箱子
- 错误扣15分，显示错误次数
- 完成后显示准确率和评级

**场景设计要点：**
```
✅ 背景：仓库货架/储物柜/传送带等元素
✅ 角色：仓库管理员/帮工
✅ 交互：点击仓库中的物品箱子
✅ 反馈：正确时箱子打开显示内容，错误时箱子摇晃
✅ 语言融入："Welcome to the food warehouse!" / "Can you find the rice?"
```

#### 4.2 关卡2：分类配对（Understand/Application 层次）

**场景化示例：📦 仓库整理货物**
- 场景描述：新货到了！需要把食材分类放到正确的货架上
- 任务：拖拽食材箱子到对应的分类区域（谷物区/蛋白质区/蔬菜区/水果区）
- 错误扣15分，实时统计
- 完成后显示评级

**场景设计要点：**
```
✅ 背景：仓库分区货架，每个区域有标签
✅ 角色：仓库理货员
✅ 交互：拖拽物品到货架区域（带碰撞检测防重叠）
✅ 反馈：正确时箱子飞到货架上并亮起绿灯，错误时箱子弹回
✅ 语言融入："Put the rice in the Grains section!" / "Meat goes to Protein!"
```

#### 4.3 关卡3：任务执行（Apply/Create 层次）⭐

**场景化示例：🛒 超市购物清单**
- 场景描述：你来到超市，手里有一份购物清单
- 任务：根据清单在超市中找到所有需要的食材，完成购物
- 操作失误扣10分
- 自由度高，学生按自己的理解完成任务

**场景设计要点：**
```
✅ 背景：超市场景，有货架、购物车、收银台等元素
✅ 角色：购物者/小顾客
✅ 交互：从货架拖拽食材到购物车，完成清单
✅ 反馈：每找到一个食材打勾✓，完成清单后收银台结算
✅ 语言融入："Shopping list: soup, rice, fruit..." / "Add to cart!"
✅ 场景元素：价格标签、购物车图标、收银台
```

**备选场景：🍳 厨房准备晚餐**
```
✅ 背景：厨房台面，有锅碗瓢盆
✅ 角色：小厨师
✅ 任务：根据菜谱准备健康餐
✅ 语言融入："First, add the vegetables..." / "Now, put some rice"
```

#### 4.4 关卡4：复习巩固（Evaluate 层次）⭐ 新增！

**场景化示例：🏆 店长考核**
- 场景描述：你是新员工，店长要进行综合考核
- 任务：完成多种考核题目（听力/词汇/分类/句型）
- 包含完整的错误追踪和最终总评
- 考核通过后获得"金牌店员"证书

**设计要点：**
- 综合前3关的所有知识点
- 游戏形式：选择题/填空题/听音选词/句子排序/场景匹配
- 场景包装成"考核"形式，增强沉浸感
- 可以是：快速问答 / 听力挑战 / 场景任务 / 综合测评

**场景化示例：**
```markdown
### 🎮 关卡4：金牌店员考核

**场景包装:** 店长考核室，墙上挂着考核题目
**题目类型（场景化）:**
1. 📦 仓库找货（看图选词）- 5题 - "Find the right item!"
2. 🛒 购物清单（听音选图）- 3题 - "Listen and choose!"
3. 📋 货架整理（句子排序）- 2题 - "Put in order!"
4. ✅ 质量检查（判断正误）- 2题 - "Check if correct!"

**场景元素:**
- 考核计时器
- 成绩单面板
- 店长头像（给予鼓励）
- 通过后颁发证书动画

**计分规则:**
- 每题20分，满分120分
- 答错不扣分（鼓励尝试）
- 显示答题时间和准确率

**最终评级:**
- ⭐⭐⭐ 金牌店员（≥100分）- 颁发证书
- ⭐⭐ 资深店员（≥80分）
- ⭐ 见习店员（≥60分）
- 💪 继续努力（<60分）

**语言融入:**
- "Welcome to the final assessment!"
- "You're doing great!"
- "Congratulations! You're now a Gold Member!"
```

---

### 第五步：创建 HTML 游戏文件 💻

#### 5.1 文件命名规则
```
level1-[theme]-[action].html
level2-[theme]-[action].html  
level3-[theme]-[action].html
level4-[theme]-review.html        ← 新增！复习关卡

示例:
level1-food-search.html
level2-plate-match.html
level3-my-creation.html
level4-final-challenge.html       ← 新增！
```

#### 5.2 文件结构模板

**必须包含的元素：**
1. ✅ Google Fonts（Fredoka One + Quicksand）
2. ✅ CSS Variables（马卡龙色系）
3. ✅ Round & Cute 组件样式
4. ✅ Q弹动画系统
5. ✅ 错误记录变量和函数
6. ✅ 评级计算函数
7. ✅ Web Audio API 音效
8. ✅ 响应式布局
9. ✅ 触屏支持
10. ✅ 完成界面（含评级徽章）

#### 5.3 错误记录系统实现模板

```javascript
// 全局变量
let errorCount = 0;
let totalScore = 0;
const baseScore = 100;
const errorPenalty = 15;

// 错误处理函数
function handleError() {
    errorCount++;
    totalScore = Math.max(0, totalScore - errorPenalty);
    
    // 更新UI
    document.getElementById('errorCount').textContent = errorCount;
    document.getElementById('totalScore').textContent = totalScore;
    
    // 播放错误音效和动画
    playSound('wrong');
    showFeedback('error', `❌ 第 ${errorCount} 次错误`);
}

// 评级计算函数
function getRating(errorRate) {
    if (errorRate <= 0.2) return { text: '⭐⭐⭐ 完美', class: 'rating-perfect' };
    if (errorRate <= 0.4) return { text: '⭐⭐ 很棒', class: 'rating-great' };
    if (errorRate <= 0.6) return { text: '⭐ 不错', class: 'rating-good' };
    return { text: '💪 加油', class: 'rating-keep-going' };
}
```

---

### 第六步：输出完整方案 📋

#### 6.1 输出格式

```markdown
# [情境名称] —— 完整课堂情境方案（Round & Cute 版）

## 🎯 情境概述
[2-3段话]

## 🗺️ 情境主线地图（4关卡）
[时间线]

## 🎮 互动关卡详情
[4个关卡的详细说明]

## 🔢 错误记录与评价体系
[统一的错误处理规则和评级标准]

## 🎨 Round & Cute 设计亮点
- 字体: Fredoka One + Quicksand
- 配色: 马卡龙色系
- 形状: 超大圆角 + 胶囊形
- 动画: Q弹果冻效果
- 特色: [独特的视觉处理]

## 💾 已创建文件
[4个HTML文件的列表和路径]

## 📋 教师使用指南
[详细的课堂使用建议]
```

#### 6.2 必须告知用户的信息

在完成所有任务后，**必须在最终回复中明确告知**:

```markdown
## ✅ 任务完成！

已为您创建 **4个** Round & Cute 风格的互动游戏：

1. **[file1.html]** - 关卡1：[description]
2. **[file2.html]** - 关卡2：[description]
3. **[file3.html]** - 关卡3：[description]
4. **[file4.html]** - 关卡4：[description] ⭐新增复习巩固

**文件路径:** `[absolute/path/to/files]`

**🎨 本次设计的视觉特色（Round & Cute）：**
- 📝 字体: Fredoka One（标题）+ Quicksand（正文）- 超圆润
- 🎨 配色: 马卡龙色系（糖果粉+奶油黄+薄荷绿）
- 🟤 形状: 超大圆角（40-50px）+ 胶囊形按钮
- ✨ 动画: Q弹果冻效果 + 糖果掉落入场
- 🍬 氛围: 温暖甜美，像糖果屋一样吸引孩子

祝您上课顺利！如需调整，随时告诉我！😊
```

---

## ⚠️ 关键注意事项

### 1. MUST USE Realistic Interactive Scenarios（必须使用真实场景互动游戏）

**场景化设计优先原则：**
```
✅ 每个关卡都是真实任务场景（仓库整理、超市购物、厨房做饭等）
✅ 学生有明确角色（仓库管理员、购物者、小厨师等）
✅ 场景中有真实的道具和元素（货架、购物车、收银台等）
✅ 语言自然融入场景（不是在真空中学习英语，而是在完成任务中使用英语）
✅ 完成任务有成就感（整理好仓库、完成购物清单、通过考核等）
```

**绝对禁止：**
```
❌ 纯抽象的点击选择界面（没有场景包装）
❌ 脱离实际的虚拟练习（学生不知道为什么要做这个）
❌ 没有故事线的孤立关卡（关卡通关后没有成就感）
❌ 缺乏场景元素的单调页面（只有按钮和文字）
```

### 2. MUST USE Round & Cute Aesthetics（必须使用圆润可爱美学）

**绝对禁止：**
```
❌ 尖锐的直角矩形（用大圆角替代）
❌ 冷色调高对比度配色（用暖色马卡龙替代）
❌ 生硬的线性动画（用弹性缓动曲线替代）
❌ 棱角分明的字体（用圆润字体替代）
❌ 苍白单调的背景（用彩色渐变替代）
```

**必须做到：**
```
✅ 一切都是圆的（按钮、卡片、图标、输入框）
✅ 色彩像糖果一样甜美（粉、黄、绿、蓝的马卡龙色）
✅ 动画像果冻一样Q弹（cubic-bezier 弹跳曲线）
✅ 整体氛围像童话世界（温暖、友好、安全）
✅ 孩子看到就想点击（吸引力优先）
✅ 场景元素也要圆润可爱（圆角货架、圆形货架标签等）
```

### 3. 4关卡完整性

**必须创建4个HTML文件：**
```
level1-*.html  → 词汇认知（Remember）- 场景化找货
level2-*.html  → 分类整理（Understand）- 场景化分类
level3-*.html  → 任务执行（Create）- 场景化任务
level4-*.html  → 复习巩固（Evaluate）⭐必选- 场景化考核
```

**关卡4的特殊性：**
- 是综合性的复习关卡
- 应包含多种题型（选择/判断/排序/听力）
- 给出最终的总体评价
- 可以包含所有知识点的回顾
- 包装成场景（考核/比赛/挑战等）

### 3. 错误记录系统（所有关卡统一）

**每个关卡都必须包含：**
```
✅ errorCount 变量
✅ handleError() 函数
✅ 扣分机制（baseScore - errorPenalty）
✅ 错误次数显示UI
✅ getRating() 评级函数
✅ 完成界面的评级徽章
```

### 4. Match Complexity to Vision

**如果视觉方向是 Round & Cute：**
  → 代码要体现"圆润可爱"
  → 颜色要丰富但不刺眼
  → 动画要多但要流畅
  → 元素大小要适合儿童操作（触屏友好）

### 5. Performance Considerations

```
✅ 优先使用 CSS Animations（性能更好）
✅ 合理控制动画数量（不要太多同时运行）
✅ 图片使用 emoji 或 SVG（不依赖外部资源）
✅ 字体使用 Google Fonts（CDN加速）
⚠️ 移动端简化动画效果（保持流畅）
```

### 6. Accessibility（无障碍）

```
✅ 语义化 HTML 标签
✅ 足够的颜色对比度（WCAG AA 标准）
✅ 键盘可访问（Tab 键导航）
✅ ARIA 标签（动态内容更新时）
✅ Focus states（清晰的焦点指示器）
✅ 大尺寸触摸目标（最小 48x48px）
```

---

## 🔄 与原版的对比

| 能力维度 | 原版 lesson-context-pro | 本版本 Round & Cute |
|---------|-------------------------|---------------------|
| **关卡数量** | 3关 | **4关（+复习巩固）** |
| **视觉风格** | Production-grade 专业级 | **Round & Cute 圆润可爱** |
| **目标用户** | 公开课/比赛 | **小学低年级日常课堂** |
| **字体风格** | Fredoka+Nunito | **Fredoka One+Quicksand（更圆润）** |
| **配色方案** | 大胆高饱和 | **马卡龙色系（柔和甜美）** |
| **形状风格** | 中等圆角 | **超大圆角+胶囊形** |
| **动画风格** | 弹性微交互 | **Q弹果冻+糖果掉落** |
| **错误记录** | ❌ 无 | **✅ 完整的追踪+扣分+评级** |
| **整体印象** | 专业精致 | **可爱有趣、孩子喜欢** |

---

## 📝 使用示例

### 用户输入:
> 请帮我根据这张人教版英语教材图片（Unit 5 My Healthy Plate）生成课堂情境和互动游戏。要求4个关卡，风格要圆润可爱，最好有现实场景。

### AI 执行流程:

1. **分析图片** → 提取词汇、句型、主题
2. **设计情境** -> "小小店员成长记"故事线（4关卡场景版）
3. **规划4个关卡（场景化）**:
   - 关卡1：🏭 食材仓库找货（词汇认知）- 仓库场景
   - 关卡2：📦 仓库整理货物（分类配对）- 仓库分区货架
   - 关卡3：🛒 超市购物清单（任务执行）- 超市场景
   - 关卡4：🏆 金牌店员考核（复习巩固）- 考核场景
4. **应用 Round & Cute Design**:
   - 字体：Fredoka One + Quicksand
   - 配色：糖果粉 #FF6B9D + 奶油黄 #FFD93D + 薄荷绿 #6BCB77
   - 形状：50px 超大圆角 + 胶囊形按钮
   - 动画：果冻弹跳曲线 + 糖果掉落入场
   - 场景元素：融入仓库货架、超市购物车等现实元素
5. **添加错误记录**: 每关都有 errorCount + 扣分 + 评级
6. **创建4个HTML文件**: level1 ~ level4
7. **输出方案**: 完整的使用指南

### 最终输出:
```
✅ 已创建 4 个现实场景互动游戏（Round & Cute 风格）:
  - level1-food-search.html (🏭 食材仓库找货)
  - level2-plate-match.html (📦 仓库整理货物)
  - level3-my-creation.html (🛒 超市购物清单)
  - level4-final-challenge.html (🏆 金牌店员考核) ⭐

🎮 场景特色:
  - 关卡1：仓库货架场景，扮演管理员找货
  - 关卡2：仓库分区货架，拖拽分类整理
  - 关卡3：超市场景，按清单完成购物任务
  - 关卡4：店长考核室，综合能力测评

🎨 视觉特色:
  - 字体: Fredoka One + Quicksand（超圆润）
  - 配色: 马卡龙色系（糖果粉/奶油黄/薄荷绿）
  - 形状: 超大圆角 + 胶囊形
  - 动影: Q弹果冻 + 糖果掉落
  - 氛围: 温暖甜美童话世界
```

---

*Created with ❤️ using lesson-context-pro skill*
*Integrating pedagogical excellence with Round & Cute design for young learners*
