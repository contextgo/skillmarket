import os
import json
import requests
from datetime import datetime
from bs4 import BeautifulSoup
import schedule
import time
from dotenv import load_dotenv

load_dotenv()

GOVERNMENT_SOURCES = {
    "国家发改委": "https://www.ndrc.gov.cn",
    "国家能源局": "https://www.nea.gov.cn",
    "国家数据局": "https://www.samr.gov.cn",
    "工信部": "https://www.miit.gov.cn",
    "科技部": "https://www.most.gov.cn",
    "四川省科技厅": "https://kjt.sc.gov.cn",
    "四川省经信厅": "https://jxw.sc.gov.cn",
    "四川省发改委": "https://fgw.sc.gov.cn"
}

KEYWORDS = [
    "人工智能",
    "智能制造",
    "工业智能",
    "工业互联网",
    "产业互联网",
    "具身智能",
    "AI",
    "数字经济",
    "数字化转型",
    "智能工厂"
]

def fetch_page_content(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.encoding = response.apparent_encoding
        return response.text
    except Exception as e:
        print(f"获取页面 {url} 失败: {e}")
        return None

def parse_ndrc_page(html):
    results = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        news_list = soup.find_all('div', class_='list-item')
        for item in news_list[:10]:
            title_tag = item.find('a')
            if title_tag:
                title = title_tag.get_text(strip=True)
                link = "https://www.ndrc.gov.cn" + title_tag['href'] if title_tag.get('href') else ""
                date_tag = item.find('span', class_='time')
                date = date_tag.get_text(strip=True) if date_tag else ""
                results.append({"title": title, "link": link, "date": date})
    except Exception as e:
        print(f"解析国家发改委页面失败: {e}")
    return results

def parse_miit_page(html):
    results = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        news_list = soup.find_all('li', class_='news-item')
        for item in news_list[:10]:
            title_tag = item.find('a')
            if title_tag:
                title = title_tag.get_text(strip=True)
                link = "https://www.miit.gov.cn" + title_tag['href'] if title_tag.get('href') else ""
                date_tag = item.find('span', class_='date')
                date = date_tag.get_text(strip=True) if date_tag else ""
                results.append({"title": title, "link": link, "date": date})
    except Exception as e:
        print(f"解析工信部页面失败: {e}")
    return results

def parse_generic_page(html, base_url):
    results = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        links = soup.find_all('a')
        for link in links[:20]:
            title = link.get_text(strip=True)
            href = link.get('href', '')
            if href and len(title) > 5:
                if not href.startswith('http'):
                    href = base_url + href
                results.append({"title": title, "link": href, "date": ""})
    except Exception as e:
        print(f"解析通用页面失败: {e}")
    return results

def collect_policy_info():
    all_results = {}
    
    for source_name, url in GOVERNMENT_SOURCES.items():
        print(f"正在收集 {source_name} 的信息...")
        html = fetch_page_content(url)
        if html:
            if source_name == "国家发改委":
                items = parse_ndrc_page(html)
            elif source_name == "工信部":
                items = parse_miit_page(html)
            else:
                items = parse_generic_page(html, url)
            
            filtered_items = []
            for item in items:
                title_lower = item['title'].lower()
                for keyword in KEYWORDS:
                    if keyword.lower() in title_lower:
                        filtered_items.append(item)
                        break
            
            if filtered_items:
                all_results[source_name] = filtered_items
            print(f"  找到 {len(filtered_items)} 条相关信息")
    
    return all_results

def generate_report(policy_data):
    today = datetime.now().strftime("%Y年%m月%d日")
    report_lines = [
        "=" * 60,
        f"          智数洞察情报雷达 - 政策日报",
        f"                    {today}",
        "=" * 60,
        ""
    ]
    
    total_count = 0
    for source, items in policy_data.items():
        if items:
            report_lines.append(f"【{source}】")
            report_lines.append("-" * 40)
            for idx, item in enumerate(items, 1):
                report_lines.append(f"{idx}. {item['title']}")
                if item['date']:
                    report_lines.append(f"   发布日期: {item['date']}")
                report_lines.append(f"   链接: {item['link']}")
                report_lines.append("")
            total_count += len(items)
    
    report_lines.append("=" * 60)
    report_lines.append(f"总计发现 {total_count} 条相关政策信息")
    report_lines.append("=" * 60)
    
    report_content = "\n".join(report_lines)
    
    report_dir = os.path.join(os.getcwd(), "reports")
    os.makedirs(report_dir, exist_ok=True)
    report_filename = f"policy_report_{datetime.now().strftime('%Y%m%d')}.txt"
    report_path = os.path.join(report_dir, report_filename)
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    print(f"报告已生成: {report_path}")
    return report_path, report_content

def send_to_wechat(content, file_path=None):
    wechat_webhook = os.getenv('WECHAT_WEBHOOK_URL')
    if not wechat_webhook:
        print("未配置微信Webhook地址")
        return False
    
    try:
        payload = {
            "msgtype": "text",
            "text": {
                "content": content[:2000] if len(content) > 2000 else content
            }
        }
        
        response = requests.post(wechat_webhook, json=payload)
        if response.status_code == 200:
            print("微信消息发送成功")
            return True
        else:
            print(f"微信消息发送失败: {response.text}")
            return False
    except Exception as e:
        print(f"发送微信消息异常: {e}")
        return False

def on_scheduled_run():
    print("=" * 60)
    print("智数洞察情报雷达开始执行...")
    print(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    policy_data = collect_policy_info()
    
    if policy_data:
        report_path, report_content = generate_report(policy_data)
        send_to_wechat(report_content)
    else:
        print("未找到相关政策信息")
        send_to_wechat("今日未发现相关政策信息")

def register(registry):
    registry.register_capability("collect_policy", collect_policy_info)
    registry.register_capability("generate_report", generate_report)
    registry.register_capability("send_to_wechat", send_to_wechat)
    registry.register_hook("schedule", on_scheduled_run)
    print("智数洞察情报雷达技能已注册")

def activate():
    print("智数洞察情报雷达技能已激活")

def deactivate():
    print("智数洞察情报雷达技能已停用")

if __name__ == "__main__":
    on_scheduled_run()
