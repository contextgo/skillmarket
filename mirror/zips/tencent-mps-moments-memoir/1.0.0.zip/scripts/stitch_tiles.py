#!/usr/bin/env python3
import argparse
import glob
import os
from PIL import Image


def main():
    parser = argparse.ArgumentParser(description='Stitch tiled PNG screenshots vertically into one long image.')
    parser.add_argument('--tiles-dir', required=True, help='Directory containing tile_*.png files')
    parser.add_argument('--output', required=True, help='Output PNG path')
    args = parser.parse_args()

    pattern = os.path.join(args.tiles_dir, 'tile_*.png')
    files = sorted(glob.glob(pattern))
    if not files:
        raise SystemExit(f'No tiles found: {pattern}')

    images = [Image.open(p) for p in files]
    width = images[0].width
    if any(im.width != width for im in images):
        raise SystemExit('Tile widths are not consistent, abort.')

    total_height = sum(im.height for im in images)
    canvas = Image.new('RGB', (width, total_height), 'white')

    y = 0
    for im in images:
        canvas.paste(im, (0, y))
        y += im.height

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    canvas.save(args.output, 'PNG')
    print(f'stitched tiles={len(files)} size={canvas.width}x{canvas.height} output={args.output}')


if __name__ == '__main__':
    main()
