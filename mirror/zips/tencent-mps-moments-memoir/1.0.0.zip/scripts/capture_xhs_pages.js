#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

function getArg(name, defaultValue) {
  const i = process.argv.indexOf(`--${name}`);
  if (i !== -1 && process.argv[i + 1]) return process.argv[i + 1];
  return defaultValue;
}

async function main() {
  const htmlPath = getArg('html', null);
  const outDir = getArg('out-dir', null);
  const dpr = Number(getArg('dpr', '2'));

  if (!htmlPath || !outDir) {
    console.error('Usage: node capture_xhs_pages.js --html <path/to/xhs_pages.html> --out-dir <dir> [--dpr 2]');
    process.exit(1);
  }

  const resolvedHtml = path.resolve(htmlPath);
  if (!fs.existsSync(resolvedHtml)) {
    console.error(`HTML file not found: ${resolvedHtml}`);
    process.exit(1);
  }

  fs.mkdirSync(outDir, { recursive: true });

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  try {
    const page = await browser.newPage();
    // Each page is 1080x1440; set viewport with DPR for crisp output
    await page.setViewport({ width: 1080, height: 1440, deviceScaleFactor: dpr });

    await page.goto('file://' + resolvedHtml, { waitUntil: 'networkidle0', timeout: 60000 });

    // Wait for fonts
    await page.evaluate(() => document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve());
    await new Promise((r) => setTimeout(r, 500));

    // Count pages by looking for elements with id="page1", "page2", etc.
    const totalPages = await page.evaluate(() => {
      let count = 0;
      while (document.getElementById(`page${count + 1}`)) count++;
      return count;
    });

    if (totalPages === 0) {
      console.error('No pages found (looking for id="page1", "page2", ...)');
      process.exit(1);
    }

    console.log(`Found ${totalPages} pages, capturing at DPR=${dpr}...`);

    for (let i = 1; i <= totalPages; i++) {
      const el = await page.$(`#page${i}`);
      if (!el) {
        console.error(`Page ${i} not found, skipping`);
        continue;
      }
      const outFile = path.join(outDir, `xhs_${String(i).padStart(2, '0')}.png`);
      await el.screenshot({ path: outFile, type: 'png' });
      console.log(`Saved: ${outFile} (page ${i}/${totalPages})`);
    }

    // Write meta
    const meta = {
      htmlPath: resolvedHtml,
      totalPages,
      dpr,
      pageWidth: 1080,
      pageHeight: 1440,
      outputPixelWidth: 1080 * dpr,
      outputPixelHeight: 1440 * dpr,
    };
    fs.writeFileSync(path.join(outDir, 'meta.json'), JSON.stringify(meta, null, 2));
    console.log('meta:', JSON.stringify(meta));
    console.log(`All ${totalPages} pages captured!`);
  } finally {
    await browser.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
