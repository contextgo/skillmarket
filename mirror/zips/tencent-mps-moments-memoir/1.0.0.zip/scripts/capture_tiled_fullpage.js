#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

function getArg(name, defaultValue) {
  const i = process.argv.indexOf(`--${name}`);
  if (i !== -1 && process.argv[i + 1]) return process.argv[i + 1];
  return defaultValue;
}

async function main() {
  const url = getArg('url', null);
  const outDir = getArg('out-dir', null);
  const width = Number(getArg('width', '1080'));
  const viewportHeight = Number(getArg('viewport-height', '1200'));
  const tileHeight = Number(getArg('tile-height', '1400'));
  const dpr = Number(getArg('dpr', '2'));

  if (!url || !outDir) {
    console.error('Usage: node capture_tiled_fullpage.js --url <http(s)://...|file://...> --out-dir <dir> [--width 1080] [--viewport-height 1200] [--tile-height 1400] [--dpr 2]');
    process.exit(1);
  }

  fs.mkdirSync(outDir, { recursive: true });
  const browser = await puppeteer.launch({ headless: 'new' });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width, height: viewportHeight, deviceScaleFactor: dpr });
    await page.goto(url, { waitUntil: 'networkidle0', timeout: 120000 });
    await page.evaluate(() => document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve());
    await new Promise((r) => setTimeout(r, 1200));

    await page.evaluate(() => {
      document.querySelectorAll('.reveal').forEach((el) => el.classList.add('visible'));
      const hint = document.querySelector('.scroll-hint');
      if (hint) hint.remove();
      window.scrollTo(0, 0);
    });

    await page.addStyleTag({
      content: `
        *, *::before, *::after {
          animation: none !important;
          transition: none !important;
        }
        .reveal {
          opacity: 1 !important;
          transform: none !important;
        }
        .cover {
          min-height: auto !important;
          height: auto !important;
          overflow: hidden !important;
          padding-top: 4rem !important;
          padding-bottom: 4rem !important;
        }
        .cover::before {
          display: none !important;
        }
        .scroll-hint { display: none !important; }
        .map-dot-pulse {
          animation: none !important;
          opacity: 0.6 !important;
        }
      `,
    });

    await new Promise((r) => setTimeout(r, 300));

    const metrics = await page.evaluate(() => {
      const doc = document.documentElement;
      const body = document.body;
      const cssHeight = Math.max(doc.scrollHeight, body.scrollHeight, doc.offsetHeight, body.offsetHeight);
      const cssWidth = Math.max(doc.clientWidth, body.clientWidth);
      return { cssWidth, cssHeight };
    });

    const clipWidth = Math.min(width, Math.floor(metrics.cssWidth));
    const totalHeight = Math.floor(metrics.cssHeight);

    let index = 0;
    for (let y = 0; y < totalHeight; y += tileHeight) {
      const currentHeight = Math.min(tileHeight, totalHeight - y);
      const tileName = `tile_${String(index).padStart(3, '0')}.png`;
      const tilePath = path.join(outDir, tileName);

      await page.screenshot({
        path: tilePath,
        type: 'png',
        captureBeyondViewport: true,
        clip: {
          x: 0,
          y,
          width: clipWidth,
          height: currentHeight,
        },
      });

      console.log(`saved ${tileName} @ y=${y} h=${currentHeight}`);
      index += 1;
    }

    const meta = {
      url,
      cssWidth: clipWidth,
      cssHeight: totalHeight,
      viewportHeight,
      tileHeight,
      tileCount: index,
      dpr,
      outputPixelWidth: clipWidth * dpr,
      outputPixelHeight: totalHeight * dpr,
    };

    fs.writeFileSync(path.join(outDir, 'meta.json'), JSON.stringify(meta, null, 2));
    console.log('meta:', JSON.stringify(meta));
  } finally {
    await browser.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
