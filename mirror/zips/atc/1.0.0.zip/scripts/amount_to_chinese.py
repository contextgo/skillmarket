#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿拉伯数字转中文金额大写
支持整数、小数、负数转换
"""

import sys
import re


def amount_to_chinese(amount):
    """
    将阿拉伯数字转换为中文金额大写格式

    参数:
        amount: 数字，可以是字符串、整数或浮点数

    返回:
        str: 中文金额大写，如 "壹万贰仟叁佰肆拾伍元陆角柒分"

    异常:
        ValueError: 当输入不是有效数字时抛出
    """
    # 数字到中文的映射
    digit_map = {
        '0': '零',
        '1': '壹',
        '2': '贰',
        '3': '叁',
        '4': '肆',
        '5': '伍',
        '6': '陆',
        '7': '柒',
        '8': '捌',
        '9': '玖'
    }
    
    # 单位映射
    unit_map = ['', '拾', '佰', '仟']
    large_unit_map = ['', '万', '亿']
    
    # 小数单位
    decimal_unit_map = ['角', '分']
    
    # 处理输入
    if isinstance(amount, (int, float)):
        amount_str = str(amount)
    else:
        amount_str = amount.strip()
    
    # 验证输入格式
    if not re.match(r'^-?\d+\.?\d*$', amount_str):
        raise ValueError(f"无效的数字格式: {amount}")
    
    # 处理负数
    is_negative = amount_str.startswith('-')
    if is_negative:
        amount_str = amount_str[1:]
    
    # 分割整数和小数部分
    if '.' in amount_str:
        integer_part, decimal_part = amount_str.split('.')
    else:
        integer_part = amount_str
        decimal_part = ''
    
    # 补全小数部分到两位
    decimal_part = decimal_part.ljust(2, '0')[:2]
    
    # 处理整数部分
    chinese_integer = ''
    if integer_part == '0':
        chinese_integer = '零'
    else:
        # 从右到左每4位一组
        groups = []
        for i in range(len(integer_part), 0, -4):
            groups.insert(0, integer_part[max(0, i-4):i])
        
        for i, group in enumerate(groups):
            group_str = ''
            need_zero = False
            
            for j, digit in enumerate(group):
                if digit == '0':
                    need_zero = True
                else:
                    if need_zero:
                        group_str += '零'
                        need_zero = False
                    group_str += digit_map[digit] + unit_map[len(group) - 1 - j]
            
            if group_str:
                chinese_integer += group_str + large_unit_map[len(groups) - 1 - i]
    
    # 处理小数部分
    chinese_decimal = ''
    for i, digit in enumerate(decimal_part):
        if digit != '0':
            chinese_decimal += digit_map[digit] + decimal_unit_map[i]
    
    # 组合结果
    result = ''
    if is_negative:
        result += '负'
    
    result += chinese_integer + '元'
    
    if chinese_decimal:
        result += chinese_decimal
    else:
        result += '整'
    
    return result


def main():
    """命令行入口"""
    if len(sys.argv) < 2:
        print("使用方法: python amount_to_chinese.py <数字>")
        print("示例: python amount_to_chinese.py 12345.67")
        sys.exit(1)
    
    amount_input = sys.argv[1]
    
    try:
        result = amount_to_chinese(amount_input)
        print(result)
    except ValueError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
