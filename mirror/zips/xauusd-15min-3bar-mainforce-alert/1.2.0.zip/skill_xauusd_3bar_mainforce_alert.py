# -*- coding: utf-8 -*-
"""
OpenClaw 可发布 Skill
名称：伦敦金15分钟·3连主力进场强信号提醒
功能：XAUUSD 15分钟周期，连续出现3根主力进场信号柱时触发高可信提醒
支持：微信、QQ、飞书、钉钉 消息推送
"""

import requests
from datetime import datetime

metadata = {
    "name": "xauusd_15min_3bar_mainforce_alert",
    "display_name": "伦敦金15分钟·3连主力进场强信号提醒",
    "author": "用户",
    "version": "1.2.0",
    "category": "金融行情",
    "description": "XAUUSD伦敦金15分钟周期，仅当连续3根K线出现主力进场信号时才提醒，支持微信/QQ/飞书/钉钉推送",
    "tags": ["黄金","伦敦金","XAUUSD","主力清洗","主力进场","15分钟","三连信号","高胜率","盯盘提醒"],
    "parameters": []
}

signal_history = [False, False, False]

def fetch_15min_klines():
    try:
        url = "https://api.quotable.io/api/v1/klines"
        params = {
            "symbol": "XAUUSD",
            "tf": "15min",
            "count": 10
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception:
        return []

def is_main_force_bar(k0, k1, k2):
    try:
        cond1 = k0["close"] > k0["open"]
        cond2 = k0["volume"] > k1["volume"] * 1.3
        cond3 = k1["low"] < k2["low"]
        cond4 = k0["close"] > k1["high"]
        return cond1 and cond2 and cond3 and cond4
    except Exception:
        return False

def send_alert(message):
    try:
        webhook_urls = [
            # 微信
            # "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=你的key",
            # QQ
            # "https://qun.qq.com/webhook?q=xxx&token=xxx",
            # 飞书
            # "https://open.feishu.cn/open-apis/bot/v2/hook/你的hook",
            # 钉钉
            # "https://oapi.dingtalk.com/robot/send?access_token=你的token"
        ]

        payload = {
            "msgtype": "text",
            "text": {"content": message}
        }

        for url in webhook_urls:
            if url.strip():
                requests.post(url, json=payload, timeout=6)
    except Exception:
        pass

def run():
    global signal_history
    klines = fetch_15min_klines()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if len(klines) < 5:
        return f"[{now}] 获取K线数据不足，无法判断主力信号"

    k0 = klines[-1]
    k1 = klines[-2]
    k2 = klines[-3]
    k3 = klines[-4]
    k4 = klines[-5]

    bar1 = is_main_force_bar(k0, k1, k2)
    bar2 = is_main_force_bar(k1, k2, k3)
    bar3 = is_main_force_bar(k2, k3, k4)

    signal_history = [bar3, bar2, bar1]
    three_in_row = bar1 and bar2 and bar3

    output = [
        "=" * 50,
        "📈 XAUUSD 伦敦金 15分钟 · 主力清洗监控",
        f"时间：{now}",
        f"连续主力进场柱：{sum(signal_history)} / 3",
        "=" * 50
    ]

    if three_in_row:
        alert_msg = (
            "🔔 高可信主力进场提醒\n"
            "品种：XAUUSD 伦敦金\n"
            "周期：15分钟\n"
            "信号：连续3根主力进场红柱出现\n"
            "建议：关注做多机会"
        )
        output.append("\n" + alert_msg)
        send_alert(alert_msg)

    return "\n".join(output)