---
version: "2.0.0"
name: BMI Calculator
description: "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━. Use when you need bmi calculator capabilities. Triggers on: bmi calculator."
  BMI计算器。BMI计算、理想体重、健康计划、体重追踪、儿童BMI、结果解读。BMI calculator with ideal weight, health plan. BMI、体重、健康。
author: BytesAgain
---
# BMI Calculator

BMI计算器。BMI计算、理想体重、健康计划、体重追踪、儿童BMI、结果解读。BMI calculator with ideal weight, health plan. BMI、体重、健康。

## 核心特点

🎯 **精准** — 针对具体场景定制化输出
📋 **全面** — 多个命令覆盖完整工作流
🇨🇳 **本土化** — 完全适配中文用户习惯

## 命令列表

| 命令 | 功能 |
|------|------|
| `calculate` | calculate |
| `ideal` | ideal |
| `plan` | plan |
| `track` | track |
| `child` | child |
| `interpret` | interpret |

---
*BMI Calculator by BytesAgain*
---
💬 Feedback & Feature Requests: https://bytesagain.com/feedback
Powered by BytesAgain | bytesagain.com

## Commands

- `calculate` — height <cm> --weight <kg>
- `classify` — Classify
- `ideal-weight` — height <cm>

## Examples

```bash
# Show help
bmi-calculator help

# Run
bmi-calculator run
```

- Run `bmi-calculator help` for commands
- No API keys needed

