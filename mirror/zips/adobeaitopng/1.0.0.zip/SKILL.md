---
name: ai-to-png
description: Convert Adobe Illustrator (.ai) files to PNG with single-file or batch processing, DPI control, transparent background output, and multi-backend fallback through Inkscape, Ghostscript, and pdf2image. Use when users need to export AI assets without Illustrator, batch-convert design source files, or prepare PNG assets for web, PPT, and operations workflows.
description_zh: "将 Adobe Illustrator（.ai）文件转换为 PNG，支持单文件/批量处理、DPI 控制、透明背景输出与多后端自动回退"
description_en: "Convert Adobe Illustrator (.ai) files to PNG with batch support, DPI control, transparent background, and backend fallback"
version: 1.0.0
---

# ai-to-png

`ai-to-png` 是一个面向设计资产处理场景的 Skill，用于把 Adobe Illustrator `.ai` 文件转换成可直接交付的 PNG 图片。它适合设计师、前端开发者、运营同学和内容团队在没有 Adobe Illustrator 的环境下提取素材、批量导出资源或整理历史设计资产。

## When to Use

当用户出现以下需求时应触发此 Skill：需要把 `.ai` 文件导出为 PNG、需要批量转换设计源文件、需要为 Web/PPT/运营素材生成透明背景位图、当前设备没有安装 Adobe Illustrator 但仍需要提取 AI 资源。

## Core Capabilities

这个 Skill 的核心能力是三层后端回退。优先使用 Inkscape 处理标准 `.ai` 文件；若 Inkscape 不可用或转换失败，则回退到 Ghostscript；若仍失败，再回退到 `pdf2image` 配合 Poppler 的兜底方案。除多后端回退外，它还应支持单文件和目录批量处理、自定义 DPI、透明背景 PNG 输出，以及对失败文件进行逐项报错说明。

## Expected Inputs and Outputs

输入通常是单个 `.ai` 文件路径，或者包含多个 `.ai` 文件的目录路径。输出是写入目标目录的 PNG 文件。推荐支持以下参数：输入路径、输出目录、DPI、是否透明背景、是否递归扫描目录、是否允许覆盖同名文件。

## Recommended Workflow

1. 先校验输入路径存在，且单文件模式下仅接受 `.ai` 后缀。
2. 收集待转换文件列表；若是目录模式，只处理 `.ai` 文件。
3. 检查环境中可用的转换后端，顺序为 Inkscape、Ghostscript、pdf2image。
4. 对每个文件按优先级依次尝试转换，成功即停止继续回退。
5. 将 PNG 写入用户指定目录，并输出成功数、失败数、失败原因和实际使用的后端。
6. 如果所有后端都不可用，明确提示用户查看 `references/installation.md` 补齐依赖。

## Bundled Resources

推荐随 Skill 一并提供以下资源：

- `scripts/ai_to_png.py`：核心转换脚本
- `references/installation.md`：环境依赖与安装说明
- `assets/`：可选的输出示例或图标资源

## Usage Notes

推荐的命令调用方式如下，具体参数名可与脚本实现保持一致：

```bash
python scripts/ai_to_png.py --input ./designs/demo.ai --output-dir ./out --dpi 144 --transparent
python scripts/ai_to_png.py --input ./designs --output-dir ./out --dpi 96 --recursive
```

如果用户没有安装任何后端，应优先引导其安装 Inkscape；如果需要更强兼容性，可补装 Ghostscript；如果需要使用 `pdf2image`，还需确保 Poppler 可用。

## Guardrails

这个 Skill 只应读取用户明确指定的 `.ai` 文件或目录，只应把结果写入用户指定的输出目录，不应访问无关路径，也不需要发起任何网络请求。若存在覆盖同名文件的风险，应由脚本参数显式控制或在执行前提醒用户。

## Limitations

这个 Skill 的目标是“导出可用 PNG”，而不是完全替代 Illustrator 的渲染能力。对于渐变网格、复杂混合模式、多描边、多填充、印刷级色彩管理、特殊字体依赖等内容，不同后端可能出现近似渲染或兼容偏差。遇到复杂文件时，应提示用户先简化图层、展开外观，或转换为更兼容的中间格式后再尝试。

## Reliability and Safety

根据现有审计结论，这个 Skill 的预期实现不存在阻断级风险，且功能边界清晰。建议在安装文档中明确虚拟环境使用方式，并在脚本中继续保持以下安全习惯：使用 `subprocess.run([...])` 而非 `shell=True`、限制文件后缀、规范化输入输出路径、为外部命令设置超时。

## Submission Checklist

提交前建议确认以下事项：`description` 已覆盖触发词和适用场景；脚本参数与文档示例一致；安装说明覆盖 Windows、macOS、Linux；图标、版本号和输出示意已准备齐全；若市场要求元数据文件，则同步维护 `skill.json`。
