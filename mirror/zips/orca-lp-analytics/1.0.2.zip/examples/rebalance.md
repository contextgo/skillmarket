# Rebalance an Orca Whirlpool Position

Check if a position is out of range. If so, close it and re-open a new position centered on the current price.

> **Playbook**: [Rebalance](../SKILL.md#rebalance) — break-even math vs APR (see [Position Viability](../SKILL.md#position-viability-minimum-economic-size)) before recommending rebalance frequency.

## Full Example

```typescript
import { Connection, Keypair, PublicKey } from "@solana/web3.js";
import { Wallet } from "@coral-xyz/anchor";
import {
  WhirlpoolContext,
  buildWhirlpoolClient,
  ORCA_WHIRLPOOL_PROGRAM_ID,
  PDAUtil,
  PriceMath,
  increaseLiquidityQuoteByInputTokenUsingPriceDeviation,
  decreaseLiquidityQuoteByLiquidityWithParams,
  TokenExtensionUtil,
} from "@orca-so/whirlpools-sdk";
import { Percentage, DecimalUtil } from "@orca-so/common-sdk";
import Decimal from "decimal.js";
import * as fs from "fs";

// --- Configuration ---
const RPC_URL = process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com";
const KEYPAIR_PATH = process.env.KEYPAIR_PATH || `${process.env.HOME}/.config/solana/id.json`;

// Position to rebalance (the NFT mint address)
const POSITION_MINT = new PublicKey("YOUR_POSITION_MINT_ADDRESS");

// New range width (+/- percent around current price)
const RANGE_PERCENT = 5;

// Slippage tolerance
const SLIPPAGE = Percentage.fromFraction(1, 100); // 1%

async function main() {
  // 1. Initialize
  const connection = new Connection(RPC_URL, "confirmed");
  const secretKey = JSON.parse(fs.readFileSync(KEYPAIR_PATH, "utf-8"));
  const keypair = Keypair.fromSecretKey(Uint8Array.from(secretKey));
  const wallet = new Wallet(keypair);
  const ctx = WhirlpoolContext.from(connection, wallet);
  const client = buildWhirlpoolClient(ctx);

  // 2. Load position and its parent whirlpool
  const positionPda = PDAUtil.getPosition(ORCA_WHIRLPOOL_PROGRAM_ID, POSITION_MINT);
  const position = await client.getPosition(positionPda.publicKey);
  const positionData = position.getData();

  const whirlpool = await client.getPool(positionData.whirlpool);
  const whirlpoolData = whirlpool.getData();

  // getParsedAccountInfo returns Buffer | ParsedAccountData on .data — use the parsed branch.
  const mintAInfo = await connection.getParsedAccountInfo(whirlpoolData.tokenMintA);
  const mintBInfo = await connection.getParsedAccountInfo(whirlpoolData.tokenMintB);
  const tokenADecimals = (mintAInfo.value?.data as any)?.parsed?.info?.decimals ?? 9;
  const tokenBDecimals = (mintBInfo.value?.data as any)?.parsed?.info?.decimals ?? 6;

  const tickSpacing = whirlpoolData.tickSpacing;

  // 3. Check if position is in range
  const currentTick = whirlpoolData.tickCurrentIndex;
  const lowerTick = positionData.tickLowerIndex;
  const upperTick = positionData.tickUpperIndex;
  const inRange = currentTick >= lowerTick && currentTick < upperTick;

  const currentPrice = PriceMath.sqrtPriceX64ToPrice(
    whirlpoolData.sqrtPrice,
    tokenADecimals,
    tokenBDecimals,
  );

  console.log(`Current price: $${currentPrice.toFixed(4)}`);
  console.log(`Current tick: ${currentTick}`);
  console.log(`Position range: [${lowerTick}, ${upperTick}]`);
  console.log(`Status: ${inRange ? "IN RANGE" : "OUT OF RANGE"}`);

  if (inRange) {
    // Calculate how centered the position is
    const rangeWidth = upperTick - lowerTick;
    const distFromLower = currentTick - lowerTick;
    const centeredness = Math.min(distFromLower, rangeWidth - distFromLower) / (rangeWidth / 2) * 100;

    console.log(`Centeredness: ${centeredness.toFixed(1)}%`);

    if (centeredness > 20) {
      console.log("Position is well-centered. No rebalance needed.");
      return;
    }

    console.log("Position is near the edge. Proceeding with rebalance...");
  } else {
    console.log("Position is out of range. Proceeding with rebalance...");
  }

  // 4. Remove all liquidity from the old position
  console.log("\n--- Step 1: Remove liquidity ---");

  const tokenExtCtx = await TokenExtensionUtil.buildTokenExtensionContextForPool(
    ctx.fetcher, whirlpoolData.tokenMintA, whirlpoolData.tokenMintB,
  );

  const removeQuote = decreaseLiquidityQuoteByLiquidityWithParams({
    liquidity: positionData.liquidity,
    slippageTolerance: SLIPPAGE,
    sqrtPrice: whirlpoolData.sqrtPrice,
    tickCurrentIndex: whirlpoolData.tickCurrentIndex,
    tickLowerIndex: positionData.tickLowerIndex,
    tickUpperIndex: positionData.tickUpperIndex,
    tokenExtensionCtx: tokenExtCtx,
  });

  const withdrawnA = DecimalUtil.fromBN(removeQuote.tokenMinA, tokenADecimals);
  const withdrawnB = DecimalUtil.fromBN(removeQuote.tokenMinB, tokenBDecimals);
  console.log(`Withdrawing: ~${withdrawnA.toFixed(4)} token A + ~${withdrawnB.toFixed(4)} token B`);

  const removeTx = await position.decreaseLiquidity(removeQuote);
  await removeTx.buildAndExecute();
  console.log("Liquidity removed.");

  // 5. Collect any accrued fees (pass true to update fees first)
  console.log("\n--- Step 2: Collect fees ---");

  const collectTx = await position.collectFees(true);
  await collectTx.buildAndExecute();
  console.log("Fees collected.");

  // Collect rewards if any (returns TransactionBuilder[])
  const rewardTxs = await position.collectRewards(undefined, true);
  for (const rtx of rewardTxs) {
    await rtx.buildAndExecute();
  }
  if (rewardTxs.length > 0) console.log("Rewards collected.");

  // 6. Close old position (via whirlpool, not position)
  console.log("\n--- Step 3: Close old position ---");

  const closeTxs = await whirlpool.closePosition(
    positionPda.publicKey,
    SLIPPAGE,
  );
  for (const ctxn of closeTxs) {
    await ctxn.buildAndExecute();
  }
  console.log(`Old position ${POSITION_MINT.toBase58().slice(0, 8)}... closed.`);

  // 7. Calculate new tick range centered on current price
  console.log("\n--- Step 4: Open new position ---");

  const currentPriceNum = currentPrice.toNumber();
  const newPriceLower = new Decimal(currentPriceNum * (1 - RANGE_PERCENT / 100));
  const newPriceUpper = new Decimal(currentPriceNum * (1 + RANGE_PERCENT / 100));

  // Use SDK price-to-tick conversion (handles decimal adjustment correctly)
  const rawTickLower = PriceMath.priceToTickIndex(newPriceLower, tokenADecimals, tokenBDecimals);
  const rawTickUpper = PriceMath.priceToTickIndex(newPriceUpper, tokenADecimals, tokenBDecimals);

  // Align to tick spacing
  const newTickLower = Math.floor(rawTickLower / tickSpacing) * tickSpacing;
  const newTickUpper = Math.ceil(rawTickUpper / tickSpacing) * tickSpacing;

  const actualPriceLower = PriceMath.tickIndexToPrice(newTickLower, tokenADecimals, tokenBDecimals);
  const actualPriceUpper = PriceMath.tickIndexToPrice(newTickUpper, tokenADecimals, tokenBDecimals);

  console.log(`New tick range: [${newTickLower}, ${newTickUpper}]`);
  console.log(`New price range: $${actualPriceLower.toFixed(4)} - $${actualPriceUpper.toFixed(4)}`);

  // 8. Re-deposit withdrawn tokens into new position
  // Refresh pool data after close (price may have moved)
  await whirlpool.refreshData();

  const depositAmount = DecimalUtil.fromBN(removeQuote.tokenEstA, tokenADecimals);
  // Use PriceDeviation (NOT PriceSlippage) so the quote includes correctly-matched
  // minSqrtPrice/maxSqrtPrice bounds around the CURRENT pool price, not the position
  // range. Using wrong bounds causes PriceSlippageOutOfBounds (0x17b5).
  const depositQuote = increaseLiquidityQuoteByInputTokenUsingPriceDeviation(
    whirlpoolData.tokenMintA,
    depositAmount,
    newTickLower,
    newTickUpper,
    SLIPPAGE,
    whirlpool,
    tokenExtCtx,
  );

  const depositA = DecimalUtil.fromBN(depositQuote.tokenEstA, tokenADecimals);
  const depositB = DecimalUtil.fromBN(depositQuote.tokenEstB, tokenBDecimals);

  console.log(`Depositing: ~${depositA.toFixed(4)} token A + ~${depositB.toFixed(4)} token B`);

  // 9. Open new position — quote already contains matched sqrt price bounds
  const { positionMint, tx } = await whirlpool.openPositionWithMetadata(
    newTickLower,
    newTickUpper,
    depositQuote,
  );

  const txId = await tx.buildAndExecute();

  console.log(`\n=== Rebalance Complete ===`);
  console.log(`New position mint: ${positionMint.toBase58()}`);
  console.log(`Transaction: https://solscan.io/tx/${txId}`);
  console.log(`\nUpdate your position tracking with the new mint address.`);
}

main().catch(console.error);
```

## How It Works

1. **Load the existing position** and its parent Whirlpool from on-chain data.
2. **Check if the position is in range.** If the current tick is within the position's tick bounds, also check centeredness -- if the position is near an edge (<20% centered), it may still be worth rebalancing proactively.
3. **Remove all liquidity** from the old position. This returns both tokens to the wallet.
4. **Collect accrued fees and rewards** before closing.
5. **Close the old position** to reclaim the rent-exempt SOL and burn the position NFT.
6. **Calculate a new tick range** centered on the current price with the configured range width.
7. **Re-deposit the withdrawn tokens** into a new position at the updated range.

## Important Notes

- The new position gets a **new mint address**. Update any monitoring or tracking systems.
- There is a brief window between removing and re-depositing where your tokens are not earning fees.
- If the price moves significantly between the remove and open steps, the deposit quote may need more of one token than was withdrawn. The script uses the withdrawn token A amount as the basis, and the SDK calculates the matching token B.
- For automated rebalancing, wrap this in a monitoring loop that checks position centeredness every 60 seconds.

## Output

> **Requires dependencies and keypair** (same as open-position):
> - `npm install @orca-so/whirlpools-sdk @orca-so/common-sdk @solana/web3.js @coral-xyz/anchor`
> - `KEYPAIR_PATH` and `SOLANA_RPC_URL`
>
> This example closes an existing position and opens a new one at the current price. It submits multiple on-chain transactions.

Expected output (with keypair):
```
Checking position 7hYz...9pLm
Current price: $83.18 | Position range: $79.02 - $87.34
Status: IN RANGE ✓

--- OR if out of range: ---

Current price: $91.50 | Position range: $79.02 - $87.34
Status: OUT OF RANGE ✗ — Rebalancing...

Step 1: Removing liquidity from old position...
  Withdrew: 0.95 SOL + 78.50 USDC
Step 2: Collecting fees...
  Fees: 0.003 SOL + 0.25 USDC
Step 3: Closing old position...
  ✓ Position 7hYz...9pLm closed
Step 4: Opening new position at current price ±5%...
  New range: $86.93 - $96.08
  ✓ Position 9kLm...3xQr opened
```
