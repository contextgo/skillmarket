﻿# 更新日志

## 2026-05-02 安全收紧

回应 ClawHub 社区对 lotto-agent 的安全风险评估，对通知配置链路进行收紧：

- 移除 `webhook` provider：`config/notifications.json`、`scripts/push_message.py`、`scripts/main.py`、`scripts/natural_language.py`、`README.md`、`SKILL.md` 中所有 webhook 相关代码、字段、CLI 参数、自然语言意图与文档全部删除，切断任意 HTTP 外发链路。
- 固定 OpenClaw 命令：`scripts/push_message.py` 在进程启动时通过 `shutil.which("openclaw")` 解析一次可执行路径，不再读取 `notifications.json` 中的 `providers.openclaw_cli.command`。已废弃 `--command` CLI 参数及 `configure_notification` 的 `command` / `webhook_url` 入参，避免通过修改命令路径触发 RCE。
- 收紧 `update_config`：`scripts/update_config.py` 的 `ALLOWED_FILES` 移除 `notifications`，通用配置入口不再能修改 `config/notifications.json`。通知配置只能通过 `configure_notification` / `bind_notification_target` / `enable_notification` 走带二次确认的专用流程修改。
- 老配置兼容：`notification_config()` 加载时会丢弃残留的 `webhook` provider 和 `openclaw_cli.command` 字段，并把无效 provider 降级为 `dry_run`，下次写盘时自动清理，不阻塞已有部署。
- README 与 SKILL 增加 “安全边界” 段落，明确 lotto-agent 不支持任意 webhook 外发、不允许配置自定义消息发送命令，主动推送出口仅剩 `openclaw message send` 和 `host_payload`。

## 2026-05-02

### 数据目录

- 默认数据库目录改为 OpenClaw workspace 下的独立数据目录：

  ```text
  ~/.openclaw/workspace/lotto-agent-data/lottery.db
  ```

- `LOTTO_AGENT_DATA_DIR` 仍然保留为高级覆盖项，适合服务器部署或自定义数据盘。
- 数据库从 skill 包目录中移出，更新 skill 时可以直接覆盖代码目录，不影响历史选号、开奖、兑奖、自动任务和调度日志。
- `status` 健康检查会返回实际 `data_dir` 和 `db_path`，并在目录不可写时给出权限修复引导。
- README 和 SKILL 说明已同步更新，明确 Windows、Linux、macOS 都使用同一套 `~/.openclaw/workspace/lotto-agent-data` 逻辑。

### 自动化调度

- cron 唤醒间隔调整为每 30 分钟一次。
- `draw_check_prize_window.retry_minutes` 从 10 分钟调整为 30 分钟。
- 开奖后自动兑奖的 `run_key` 改为 30 分钟粒度，避免半小时 cron 下重复执行或错过窗口。
- cron 安装逻辑会生成新的 `*/30 * * * *` 任务，并继续保留 `LOTTO_AGENT_DATA_DIR` 注入能力。
- 增强 `create_automation` 的业务参数持久化：即使调用方把 `count`、`multiple`、`budget`、`play_type` 等参数放在顶层而不是 `payload` 内，也会自动合并进 `payload_json`，避免“用户说 5 注 2 倍，但任务只保存 1 注”的问题。

### 通用消息推送

- 移除平台写死逻辑，不再使用 `wechat_text`、`wechat_self` 等微信专属字段。
- 新增通用通知 provider：
  - `dry_run`
  - `host_payload`
  - `openclaw_cli`
- `push_message` 不再只返回“伪成功 payload”。如果通知未启用、配置不完整或目标未绑定，会返回 `requires_configuration` / `requires_binding`。
- `openclaw_cli` 会调用 OpenClaw 统一出站能力：

  ```bash
  openclaw message send --channel <channel> --target <chat_id> --message <content>
  ```

- 多账号场景支持 `account_id`，发送时会追加：

  ```bash
  --account <account_id>
  ```

### OpenClaw 路由字段

- 通知路由统一使用 OpenClaw 入站消息字段：
  - `channel`
  - `chat_id`
  - `account_id`
- `chat_id` 对应 OpenClaw CLI 发送时的 `--target`。
- `account_id` 对应 OpenClaw CLI 发送时的 `--account`。
- `target` 仍作为旧字段兼容，但文档和新代码优先使用 `chat_id`。
- `notifications.json` 新增：

  ```json
  {
    "chat_id": "",
    "account_id": ""
  }
  ```

### 通知目标绑定

- 新增通知目标绑定能力：
  - `bind_notification_target`
  - `list_notification_targets`
  - `notification_status`
- 支持自然语言：
  - “绑定当前窗口”
  - “确认绑定当前通知目标”
  - “查看通知目标”
- 默认通知目标使用通用别名 `self`，不绑定任何具体平台。
- 用户确认前不会开启主动消息推送，也不会把未确认目标当作可发送目标。

### 谁创建，跟谁走

- 自动任务创建时，如果本次调用传入当前会话路由，会保存任务级 `payload.delivery` 快照：

  ```json
  {
    "delivery": {
      "channel": "<当前channel>",
      "chat_id": "<当前chat_id>",
      "account_id": "<当前account_id>"
    }
  }
  ```

- cron 执行任务并推送时，优先使用任务自己的 `payload.delivery`。
- 老任务或未带 delivery 的任务，才 fallback 到 `notification_recipient` 对应的默认绑定目标。
- 这保证了：
  - 在微信创建的任务后续发回微信。
  - 在 QQ 创建的任务后续发回 QQ。
  - 后续重新绑定默认目标不会改变旧任务的投递位置。

### 自动化引导

- 用户第一次生成已购买号码或确认购买后，会引导配置：
  - 自动兑奖任务
  - cron 唤醒器
  - 消息推送通道
- 创建自动任务时，如果 cron 未安装，会提示“确认开启自动化”。
- 创建自动任务时，如果没有可用通知目标，会提示绑定通知目标或传入当前会话路由。

### 命名与文档

- skill 命名统一为小写 `lotto-agent`。
- README 和 SKILL 已同步为通用消息宿主描述，不再把微信作为默认运行环境。
- 文档中的真实平台 ID 示例已移除，统一使用 `<channel>`、`<chat_id>`、`<account_id>` 占位符。

### 验证

- 已通过脚本编译检查：

  ```bash
  python -m compileall -f scripts
  ```

- 已用临时数据库验证：
  - 外部数据目录可创建数据库。
  - 自动任务会写入 `payload.delivery`。
  - `push_message` 会优先使用任务级 delivery 路由。
  - `chat_id` / `account_id` 能正确进入推送 payload。
