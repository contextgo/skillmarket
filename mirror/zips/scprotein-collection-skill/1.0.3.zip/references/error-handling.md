# 错误码与处理指南

## 错误响应格式

API 调用失败时，返回 JSON 中包含 `Error` 字段：

```json
{
    "Response": {
        "Error": {
            "Code": "ResourceNotFound.ApplicationNotExist",
            "Message": "The application does not exist."
        },
        "RequestId": "ed93f3cb-xxxx"
    }
}
```

**判断规则：** `Response.Error` 字段存在 → 调用失败。

---

## 认证错误处理（重要）

### 认证错误码

| 错误码 | 说明 | 处理方式 |
|--------|------|----------|
| `AuthFailure` | 认证失败 | **提示用户检查认证配置** |
| `AuthFailure.InvalidSecretId` | SecretId 非法 | **提示用户检查认证配置** |
| `AuthFailure.SecretIdNotFound` | SecretId 不存在 | **提示用户检查认证配置** |
| `AuthFailure.SignatureExpire` | 签名过期 | **提示用户检查认证配置** |
| `AuthFailure.SignatureFailure` | 签名错误（SecretKey 错误） | **提示用户检查认证配置** |
| `AuthFailure.UnauthorizedOperation` | 未授权 | **提示用户检查认证配置** |

### 认证错误常见信息

| 错误信息 | 触发条件 |
|----------|----------|
| `secretId is invalid` | SecretId 格式错误或不存在 |
| `signature mismatch` | SecretKey 错误导致签名不匹配 |
| `credentials could not be validated` | 认证信息无效或已过期 |

### 处理方式

> 检测到上述任一认证错误时，Agent 应提示用户在 Lighthouse 实例上检查或重新配置 tccli 认证：
>
> ```
> ⚠️ tccli 认证失败（错误码：<具体错误码>）。
>
> 请在 Lighthouse 实例上检查或重新配置认证：
>   1. 查看当前配置：tccli configure list
>   2. 重新配置：tccli configure
>   3. 获取 API 密钥：https://console.cloud.tencent.com/cam/capi
> ```

---

## 业务错误码

### 资源不存在类

| 错误码 | 说明 | Agent 应答建议 |
|--------|------|---------------|
| `ResourceNotFound.ApplicationNotExist` | 应用不存在 | "应用ID不存在。可用 `DescribeApplications` 查看可用应用。" |
| `ResourceNotFound.ApplicationVersionNotExist` | 应用版本不存在 | "应用版本不存在，请确认版本ID或使用最新版本。" |
| `ResourceNotFound.EnvironmentNotExist` | 环境不存在 | "环境ID不存在。可用 `DescribeEnvironments` 查看可用环境。" |
| `ResourceNotFound.ProjectNotExist` | 项目不存在 | "项目ID不存在。可用 `DescribeProjects` 查看项目列表。" |
| `ResourceNotFound.RunGroupNotExist` | 任务批次不存在 | "任务批次ID不存在，请检查ID是否正确。" |
| `ResourceNotFound.RunNotExist` | 任务不存在 | "任务UUID不存在，请检查是否正确。" |
| `ResourceNotFound.TableNotExist` | 表格不存在 | "表格ID不存在。" |
| `ResourceNotFound.TableRowNotExist` | 表格行不存在 | "指定的表格行不存在。" |
| `ResourceNotFound.CosBucketNotExist` | COS存储桶不存在 | "COS存储桶不存在，请检查路径。" |
| `ResourceNotFound.CosObjectNotExist` | COS对象不存在 | "COS文件不存在，请检查路径。" |

### 参数错误类

| 错误码 | 说明 | Agent 应答建议 |
|--------|------|---------------|
| `InvalidParameterValue.InvalidBase64Encode` | Base64编码错误 | "输入数据的Base64编码有误。空输入请使用 `e30K`。" |
| `InvalidParameterValue.InvalidInputJsonFormat` | 输入JSON格式错误 | "输入参数JSON格式有误，请检查JSON语法。" |
| `InvalidParameterValue.InvalidInputPlaceholder` | 输入占位符错误 | "输入参数中的占位符有误。" |
| `InvalidParameterValue.EnvironmentNotAvailable` | 环境不可用 | "该环境当前不可用。请用 `DescribeEnvironments` 查看可用环境。" |
| `InvalidParameterValue.DuplicateName` | 名称重复 | "任务名称已存在，请使用其他名称。" |
| `InvalidParameterValue.InvalidName` | 名称格式错误 | "任务名称格式不正确，请检查是否包含特殊字符。" |
| `InvalidParameterValue.InvalidDescription` | 描述格式错误 | "描述内容格式有误。" |
| `InvalidParameterValue.InvalidCosKey` | COS路径错误 | "COS路径格式有误。" |
| `InvalidParameterValue.InvalidCsvFormat` | CSV格式错误 | "CSV文件格式有误，请检查文件。" |
| `InvalidParameterValue.InvalidRunOption` | 运行选项错误 | "WDL运行选项格式有误，请参考 RunOption 结构。" |
| `InvalidParameterValue.InvalidEmailFormat` | 邮箱格式错误 | "通知邮箱格式不正确。" |
| `InvalidParameterValue.InvalidTimeoutMinutes` | 超时时间无效 | "超时通知时间需在5-2880分钟之间。" |
| `InvalidParameterValue.EntrypointNotSet` | 入口文件未指定 | "工作流入口文件未指定。" |
| `InvalidParameterValue.UnsupportedTableDataType` | 表格数据类型不支持 | "表格中包含不支持的数据类型。" |
| `InvalidParameterValue.TableDataTypeLengthMismatch` | 表格数据类型长度不匹配 | "表格数据列数与类型定义不匹配。" |

### 操作失败类

| 错误码 | 说明 | Agent 应答建议 |
|--------|------|---------------|
| `FailedOperation` | 操作失败（通用） | "操作失败，请稍后重试。" |
| `FailedOperation.RetryLimitExceeded` | 重试次数超限 | "该任务重试次数已达上限。" |
| `FailedOperation.StatusNotSupported` | 当前状态不支持该操作 | "当前任务状态不支持此操作。" |
| `FailedOperation.VersionNotReleased` | 应用版本未发布 | "该应用版本尚未发布。" |
| `FailedOperation.DuplicateTableHeader` | 表格表头重复 | "表格存在重复的列名。" |
| `FailedOperation.EmptyTableHeader` | 表格表头为空 | "表格表头不能为空。" |
| `FailedOperation.InvalidTableHeader` | 表格表头错误 | "表格表头格式有误。" |
| `FailedOperation.InvalidTableLength` | 表格行数错误 | "表格行数不正确。" |
| `FailedOperation.TableDataTypeMismatch` | 表格数据类型不匹配 | "表格数据与定义的类型不匹配。" |
| `FailedOperation.EmailCountLimitExceeded` | 邮件数量超限 | "通知邮件地址数量超过限制。" |
| `OperationDenied` | 操作被拒绝 | "没有权限执行此操作，请检查账户权限。" |

---

## 公共错误码

| 错误码 | 说明 | Agent 应答建议 |
|--------|------|---------------|
| `InvalidParameter` | 参数错误 | "参数格式有误，请检查命令参数。" |
| `InvalidParameterValue` | 参数值错误 | "参数值不正确，请参考API文档。" |
| `MissingParameter` | 缺少参数 | "缺少必要参数，请补充。" |
| `RequestLimitExceeded` | 频率超限 | "API调用频率超限（20次/秒），请等待后重试。" |
| `ResourceNotFound` | 资源不存在 | "请求的资源不存在。" |
| `InternalError` | 内部错误 | "服务内部错误，请稍后重试。如持续出现请联系支持。" |
| `UnsupportedRegion` | 不支持的地域 | "不支持该地域。支持：ap-beijing, ap-guangzhou, ap-shanghai。" |

---

## 错误处理策略

### 1. 认证错误 → 提示用户自行处理

检测到 `AuthFailure` 或相关认证错误时：

```
1. 向用户展示具体的错误码和错误信息
2. 提示用户在 Lighthouse 实例上检查/重新配置 tccli 认证
3. 用户确认配置完成后重试原操作
```

### 2. 可重试的错误

以下错误建议等待后自动重试：

- `RequestLimitExceeded` — 等待 2 秒后重试
- `InternalError` — 等待 5 秒后重试
- 网络超时 — 等待 3 秒后重试

### 3. 需要用户介入的错误

以下错误需要用户确认或修改参数：

- `ResourceNotFound.*` — 引导用户查询正确的资源ID
- `InvalidParameterValue.*` — 提示参数格式要求

### 4. Agent 错误处理流程

```
1. 执行 tccli omics 命令
2. 解析返回 JSON
3. 检查是否存在 Response.Error
   ├─ 有 Error:
   │   ├─ AuthFailure.* → 提示用户在 Lighthouse 上检查/重新配置 tccli 认证
   │   ├─ 可重试错误 → 等待后重试（最多 2 次）
   │   └─ 不可重试 → 根据错误码给出友好提示和建议
   └─ 无 Error:
       └─ 提取业务数据，格式化展示给用户
```
