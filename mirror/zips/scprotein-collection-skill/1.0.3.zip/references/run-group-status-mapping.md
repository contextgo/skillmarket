# 任务批次运行状态映射规则

> 本文件定义了调用 **`DescribeRunGroups`** 后，解读和展示任务批次状态的标准规则。
> **所有涉及返回任务批次状态的 SKILL 操作均须遵循本文件。**

**数据来源**：以下所有状态取值均来自 `DescribeRunGroups` API 的返回结果（`IRunGroup[]`）。

---

## 1. 判定流程（3 步）

### Step 1：按应用类型从 DescribeRunGroups 响应中取字段

| 应用类型 | 响应中的取值路径 | 枚举类型 | 说明 |
|---------|-----------------|---------|------|
| WDL | `RunGroup.Status` | GroupStatusEnum | 批次组级状态 |
| Nextflow | `RunGroup.RunStatusCounts[0].Status` | RunResultStatusEnum / RunStatusEnum | 单次 Run 级状态 |

> `RunGroup` 即 `DescribeRunGroups` 返回数组中的单个元素。

**禁止将两者视为可互换字段。**

### Step 2：优先检查分析中子状态

若 `RunGroup.RunStatusCounts[0].Status` 属于 **RunAnalysisStatusEnum**（无论 WDL 还是 NF）→ 直接显示 **"分析中"**，跳过后续映射。

这是最高优先级判定。即使 WDL 批次 `RunGroup.Status === 'RUNNING_ERROR'`（部分子任务失败），只要还有子任务在分析阶段，文本仍显示"分析中"。

### Step 3：否则按 getGroupStatusText 映射

若未命中 RunAnalysisStatusEnum，则根据 Step 1 从 `DescribeRunGroups` 响应中取到的枚举值查下表获取中文展示文本。

## 2. 状态映射表

> 每行均标注了该枚举值在 **`DescribeRunGroups` 响应体中的具体字段路径**。

| 枚举值 | 中文文本 | DescribeRunGroups 响应字段路径 | 适用 |
|-------|---------|-------------------------------|-----|
| `INITIALIZED` | 初始化 | `RunGroup.Status` (GroupStatusEnum.Initialized) | WDL |
| `SUBMITTED` | 已提交 | `RunGroup.Status` (GroupStatusEnum.Submitted) | WDL |
| `SUBMIT_ERROR` | 已提交 | `RunGroup.Status` (GroupStatusEnum.SubmitError) | WDL（⚠️ 非"提交错误"）|
| `RUNNING` | 分析中 | `RunGroup.Status` (GroupStatusEnum.Running) | WDL |
| `RUNNING_ERROR` | 分析中 | `RunGroup.Status` (GroupStatusEnum.RunningError) | WDL |
| `COMPLETE` | 已完成 | `RunGroup.Status` (GroupStatusEnum.Complete) | **WDL "已完成"的来源** |
| `COMPLETE_ERROR` | 已失败 | `RunGroup.Status` (GroupStatusEnum.CompleteError) | **WDL "已失败"的唯一来源** |
| `ERROR` | 错误 | `RunGroup.Status` (GroupStatusEnum.Error) | WDL |
| `SUCCESS` | 已完成 | `RunGroup.RunStatusCounts[0].Status` (RunResultStatusEnum.Success) | **NF "已完成"的来源** |
| `EXECUTOR_ERROR` | 已失败 | `RunGroup.RunStatusCounts[0].Status` (RunResultStatusEnum.ExecutorError) | **NF "已失败"的唯一来源** |
| `CANCELED` | 已终止 | `RunGroup.RunStatusCounts[0].Status` (RunResultStatusEnum.Canceled) | **仅 NF 可直达此文本** |

## 3. 终态判断

判断一个批次是否处于终态（可重跑）：

```text
🟦 WDL 终态: RunGroup.Status ∈ [COMPLETE, COMPLETE_ERROR, ERROR]
🟪 NF 终态:  RunGroup.RunStatusCounts[0].Status ∈ [SUCCESS, EXECUTOR_ERROR, CANCELED]
```

非终态（仍在运行中，不允许重跑）：WDL 为 `[SUBMITTED, RUNNING, RUNNING_ERROR]`

## 4. 关键陷阱（违反即判定为错误）

| # | 规则 | 说明 |
|---|------|------|
| 1 | **禁止旧状态名** | 不得使用 Succeeded / Failed / Aborted / Pending，必须使用 DescribeRunGroups 返回的原始枚举值 |
| 2 | **禁止中文反向判定** | 不得写 `if (text === '已失败')`，必须用枚举值判定 |
| 3 | **SUBMIT_ERROR ≠ "提交错误"** | 实际映射为"已提交"；真正的提交失败在 Run 级（`GetRunStatus` 返回 `ApiSubmitError`） |
| 4 | **RUNNING_ERROR ≠ "失败"** | 实际映射为"分析中"，表示部分失败但仍有在跑的 |
| 5 | **WDL 无 CANCELED** | `RunGroup.Status`（GroupStatusEnum）不含 Canceled 值。WDL 批次终止后 Status 为 COMPLETE_ERROR("已失败")；识别主动终止需调 `DescribeRuns` 下钻子任务检查 Canceled |
| 6 | **字段不可互换** | 不得把 `RunGroup.Status` 和 `RunGroup.RunStatusCounts[0].Status` 混用 |

## 5. 展示示例

**正确：**
> "最近 5 个任务：✅ 已完成 3（run-aaa COMPLETE, run-bbb SUCCESS） | ❌ 已失败 1（run-ccc COMPLETE_ERROR） | 🔄 分析中 1（run-ddd RUNNING）"

**错误（禁止）：**
> - ❌ "✅ 成功 3 | ❌ 失败 1 | 🔄 运行中 1"
> - ❌ "run-xxx 的状态是 Succeeded"
