# 腾讯云组学平台 API 完整参考

> **本文档是 SKILL.md 指定的唯一 API 参数查阅源。** Agent 在构造任何 `tccli omics` 命令前，**必须**加载本文档并定位到对应 API 章节，严格按照文档中的参数定义构造命令。禁止凭记忆或猜测编造参数。

本文档包含组学平台 20 个核心 API 的完整定义：**请求参数、返回参数、数据结构、错误码和 tccli 调用示例。**

**接口请求域名：** `omics.tencentcloudapi.com`
**API 版本：** `2022-11-28`
**频率限制：** 每个接口 20 次/秒（维度：API + Region + 子账号）
**支持地域：** `ap-beijing`, `ap-guangzhou`, `ap-shanghai`

**参数构造规则（CRITICAL）：**

1. **只使用本文档中列出的参数名**，禁止编造、猜测或使用不存在的参数
2. **所有标记 ✅ 的必选参数必须传递**，缺少任何一个必选参数则**禁止执行**，必须引导用户补充
3. **用户提供的可选参数必须传入**，即使该参数标记为 ❌（非必选），只要用户明确提供了值，就必须将其传入接口
4. **参数类型和格式必须与本文档一致**（String 用引号，Array 用 JSON 数组，Object 用 JSON 字符串）

**复合参数格式速查：**

| 参数                    | JSON 格式                                                                                                  |
| ----------------------- | ---------------------------------------------------------------------------------------------------------- |
| **Option**（RunOption） | `'{"FailureMode":"NoNewCalls","UseCallCache":true,"UseErrorOnHold":true}'`                                 |
| **NFOption**            | `'{"Config":"","Profile":"standard","Report":true,"Resume":false,"NFVersion":"23.10.0"}'`                  |
| **GitSource**           | `'{"GitHttpPath":"https://xxx.git","Branch":"master"}'`                                                    |
| **Filters**             | `'[{"Name":"Status","Values":["Running","Pending"]}]'`                                                     |
| **InputBase64**         | JSON → base64 编码。空输入用 `e30K`（即 `{}` 的 base64）。与 InputCosUri 二选一                            |
| **Array 参数**          | JSON 数组字符串：`'["value1", "value2"]'`（适用于 RunUuids / TableRowUuids / VolumeIds / DataType / Keys） |

> **Filter 规则：** 同一 Filter 内多个 Values 是 **OR** 关系；多个 Filter 之间是 **AND** 关系。

**InputBase64 编码方法：**

```bash
# 空输入
--InputBase64 "e30K"

# 编码自定义输入
echo -n '{"sample_id":"S001","ref_genome":"hg38"}' | base64
# → eyJzYW1wbGVfaWQiOiJTMDAxIiwicmVmX2dlbm9tZSI6ImhnMzgifQ==
--InputBase64 "eyJzYW1wbGVfaWQiOiJTMDAxIiwicmVmX2dlbm9tZSI6ImhnMzgifQ=="
```

---

## 任务投递接口

### 1. RunApplication — 运行应用

投递 WDL 或 Nextflow 应用任务（单例或批量）。WDL 应用使用 Option 参数，Nextflow 应用使用 NFOption 参数。

**默认任务批次名称：** 未指定 Name 时自动生成 `<ApplicationName>_<YYYYMMDDHHmmss>`。

#### 请求参数

| 参数                       | 必选 | 类型            | 说明                                                                                                                                  |
| -------------------------- | ---- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Region                     | ✅   | String          | 地域：ap-beijing / ap-guangzhou / ap-shanghai                                                                                         |
| ApplicationId              | ✅   | String          | 应用 ID                                                                                                                               |
| Name                       | ✅   | String          | 任务批次名称                                                                                                                          |
| EnvironmentId              | ✅   | String          | 投递环境 ID                                                                                                                           |
| ProjectId                  | ❌   | String          | 项目 ID，不填使用默认项目                                                                                                             |
| Description                | ❌   | String          | 任务批次描述                                                                                                                          |
| InputCosUri                | ❌   | String          | 任务输入 COS 地址（与 InputBase64 二选一）                                                                                            |
| InputBase64                | ✅   | String          | 任务输入 JSON 的 base64 编码。来源：GetInputTemplateFile 的 Content 经 base64 编码，或用户自定义 JSON 经 base64 编码。空输入用 `e30K` |
| TableId                    | ❌   | String          | 批量投递表格 ID，不填表示单例投递                                                                                                     |
| TableRowUuids.N            | ❌   | Array of String | 批量投递表格行 UUID，不填表示全部行                                                                                                   |
| CacheClearDelay            | ❌   | Integer         | 缓存清理时间（小时），0 或不填表示不清理                                                                                              |
| ApplicationVersionId       | ❌   | String          | 应用版本 ID，不填使用最新版                                                                                                           |
| Option                     | ❌   | RunOption       | WDL 运行选项                                                                                                                          |
| NFOption                   | ❌   | NFOption        | Nextflow 运行选项                                                                                                                     |
| WorkDir                    | ❌   | String          | 工作目录，仅 Nextflow 支持                                                                                                            |
| AccessMode                 | ❌   | String          | 访问模式：PRIVATE（默认）/ PUBLIC                                                                                                     |
| VolumeIds.N                | ❌   | Array of String | 缓存卷 ID 列表，仅 Nextflow 支持                                                                                                      |
| ResultNotification         | ❌   | Boolean         | 是否开启结果通知                                                                                                                      |
| TimeoutNotification        | ❌   | Boolean         | 是否开启超时通知                                                                                                                      |
| TimeoutNotificationMinutes | ❌   | Integer         | 超时通知时间（5-2880 分钟）                                                                                                           |
| EmailForNotification.N     | ❌   | Array of String | 通知邮件地址列表                                                                                                                      |

#### 返回参数

| 参数       | 类型   | 说明        |
| ---------- | ------ | ----------- |
| RunGroupId | String | 任务批次 ID |
| RequestId  | String | 请求唯一 ID |

#### 错误码

| 错误码                                        | 说明               |
| --------------------------------------------- | ------------------ |
| AuthFailure                                   | 认证失败           |
| FailedOperation.EmailCountLimitExceeded       | 通知邮件数量超限   |
| FailedOperation.VersionNotReleased            | 应用版本未发布     |
| InvalidParameterValue.DuplicateName           | 任务名称重复       |
| InvalidParameterValue.EntrypointNotSet        | 入口文件未指定     |
| InvalidParameterValue.EnvironmentNotAvailable | 环境不可用         |
| InvalidParameterValue.InvalidBase64Encode     | Base64 编码错误    |
| InvalidParameterValue.InvalidInputJsonFormat  | 输入 JSON 格式错误 |
| ResourceNotFound.ApplicationNotExist          | 应用不存在         |
| ResourceNotFound.EnvironmentNotExist          | 环境不存在         |
| ResourceNotFound.ProjectNotExist              | 项目不存在         |
| ResourceNotFound.TableNotExist                | 表格不存在         |
| ResourceNotFound.TableRowNotExist             | 表格行不存在       |

#### tccli 示例

```bash
# 单例投递
tccli omics RunApplication \
  --region ap-guangzhou \
  --ApplicationId "app-sweet-cerulean-frog-569111" \
  --Name "WGS_Sample001" \
  --EnvironmentId "env-05d0g0w2" \
  --InputBase64 "e30K" \
  --Option '{"FailureMode":"NoNewCalls","UseCallCache":true,"UseErrorOnHold":true}'

# 批量投递
tccli omics RunApplication \
  --region ap-guangzhou \
  --ApplicationId "app-xxx" \
  --Name "Batch_RNA_seq" \
  --EnvironmentId "env-xxx" \
  --InputBase64 "e30K" \
  --TableId "tab-rapid-silver-gerbil-971422" \
  --TableRowUuids '["df909e9b-...", "3c5f7840-..."]'
```

---

### 2. ImportTableFile — 导入表格文件

导入批量投递所需的表格数据文件。

#### 请求参数

| 参数        | 必选 | 类型            | 说明                      |
| ----------- | ---- | --------------- | ------------------------- |
| Region      | ✅   | String          | 地域                      |
| ProjectId   | ✅   | String          | 项目 ID                   |
| Name        | ✅   | String          | 表格名称                  |
| CosUri      | ✅   | String          | COS 上的 CSV/TSV 文件地址 |
| DataType.N  | ✅   | Array of String | 各列数据类型              |
| Description | ❌   | String          | 表格描述                  |

**支持的数据类型：** `Int`, `Float`, `String`, `File`, `Boolean`, `Array[Int]`, `Array[Float]`, `Array[String]`, `Array[File]`, `Array[Boolean]`

#### 返回参数

| 参数      | 类型   | 说明          |
| --------- | ------ | ------------- |
| TableId   | String | 导入的表格 ID |
| RequestId | String | 请求 ID       |

#### tccli 示例

```bash
tccli omics ImportTableFile \
  --region ap-guangzhou \
  --ProjectId "prj-xxx" \
  --Name "WGS_Samples" \
  --CosUri "cos://bucket/data/samples.csv" \
  --DataType '["String","File","File","Int"]' \
  --Description "WGS 样本输入表格"
```

---

## 任务管理接口

### 4. DescribeRunGroups — 查询任务批次列表

查询任务批次列表。不指定项目 ID 时，将查询默认项目的任务运行批次。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| ProjectId | ❌   | String          | 项目 ID                     |
| Limit     | ❌   | Integer         | 返回数量，默认 10，最大 100 |
| Offset    | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N | ❌   | Array of Filter | 过滤器                      |

**支持的 Filters：**

| Filter Name     | 说明                       |
| --------------- | -------------------------- |
| `Name`          | 按任务名称过滤             |
| `RunGroupId`    | 按批次 ID 过滤             |
| `Status`        | 按状态过滤                 |
| `ApplicationId` | 按应用 ID 过滤             |
| `Type`          | 按类型过滤（WDL/NEXTFLOW） |

#### 返回参数

| 参数       | 类型              | 说明           |
| ---------- | ----------------- | -------------- |
| TotalCount | Integer           | 符合条件的总数 |
| RunGroups  | Array of RunGroup | 任务批次列表   |
| RequestId  | String            | 请求 ID        |

#### tccli 示例

```bash
# 查询最近 10 个任务
tccli omics DescribeRunGroups --region ap-guangzhou --Limit 10

# 按批次ID查询
tccli omics DescribeRunGroups --region ap-guangzhou \
  --Filters '[{"Name":"RunGroupId","Values":["run-ashamed-turquoise-rooster-131773"]}]'

# 查询运行中的任务
tccli omics DescribeRunGroups --region ap-guangzhou \
  --Filters '[{"Name":"Status","Values":["Running"]}]'
```

---

### 5. DescribeRuns — 查询任务列表

查询任务批次中的任务列表，支持按批次 ID、状态等过滤。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| ProjectId | ❌   | String          | 项目 ID                     |
| Limit     | ❌   | Integer         | 返回数量，默认 10，最大 100 |
| Offset    | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N | ❌   | Array of Filter | 过滤器                      |

**支持的 Filters：**

| Filter Name     | 说明                 |
| --------------- | -------------------- |
| `RunGroupId`    | 按批次 ID 过滤       |
| `Status`        | 按状态过滤           |
| `RunUuid`       | 按任务 UUID 过滤     |
| `ApplicationId` | 按应用 ID 过滤       |
| `UserDefinedId` | 按用户自定义 ID 过滤 |

#### 返回参数

| 参数       | 类型         | 说明           |
| ---------- | ------------ | -------------- |
| TotalCount | Integer      | 符合条件的总数 |
| Runs       | Array of Run | 任务列表       |
| RequestId  | String       | 请求 ID        |

#### tccli 示例

```bash
# 查询某批次下的所有任务
tccli omics DescribeRuns --region ap-guangzhou \
  --Filters '[{"Name":"RunGroupId","Values":["run-ashamed-turquoise-rooster-131773"]}]'

# 查询某批次下失败的任务
tccli omics DescribeRuns --region ap-guangzhou \
  --Filters '[{"Name":"RunGroupId","Values":["run-xxx"]},{"Name":"Status","Values":["Failed"]}]'
```

---

### 6. GetRunStatus — 查询任务详情

查询单个任务的详细状态，返回作业元数据。

#### 请求参数

| 参数      | 必选 | 类型   | 说明      |
| --------- | ---- | ------ | --------- |
| Region    | ✅   | String | 地域      |
| RunUuid   | ✅   | String | 任务 UUID |
| ProjectId | ❌   | String | 项目 ID   |

#### 返回参数

| 参数      | 类型        | 说明           |
| --------- | ----------- | -------------- |
| Metadata  | RunMetadata | 任务运行元数据 |
| RequestId | String      | 请求 ID        |

#### tccli 示例

```bash
tccli omics GetRunStatus \
  --region ap-guangzhou \
  --RunUuid "fe92382a-9028-4e0f-8d12-fb11d9ad058c"
```

---

### 7. GetRunCalls — 查询作业详情

查询某个任务的子作业层级信息。需先通过 GetRunStatus 获取顶层 RunId。

#### 请求参数

| 参数      | 必选 | 类型   | 说明                                                                    |
| --------- | ---- | ------ | ----------------------------------------------------------------------- |
| Region    | ✅   | String | 地域                                                                    |
| RunUuid   | ✅   | String | 任务 UUID                                                               |
| Path      | ✅   | String | 作业路径。`/` 表示顶层；使用 Workflow/Scatter 类型作业的 RunId 查子层级 |
| ProjectId | ❌   | String | 项目 ID                                                                 |

#### 返回参数

| 参数      | 类型                 | 说明       |
| --------- | -------------------- | ---------- |
| Calls     | Array of RunMetadata | 子作业列表 |
| RequestId | String               | 请求 ID    |

#### 查询策略

1. `GetRunStatus` → 获取顶层 Metadata（检查 RunType 和 RunId）
2. 若 RunType 为 Workflow/Scatter → `GetRunCalls` (Path="/") → 获取一级子作业
3. 子作业中若有 Workflow/Scatter → `GetRunCalls` (Path=该作业的 RunId) → 递归查询

#### tccli 示例

```bash
# 查询顶层作业
tccli omics GetRunCalls \
  --region ap-guangzhou \
  --RunUuid "fe92382a-9028-4e0f-8d12-fb11d9ad058c" \
  --Path "/"

# 查询子层级
tccli omics GetRunCalls \
  --region ap-guangzhou \
  --RunUuid "fe92382a-xxx" \
  --Path "main_workflow"
```

---

### 8. RetryRuns — 重试失败任务

支持三种重试模式。

#### 请求参数

| 参数       | 必选 | 类型            | 说明                                                                        |
| ---------- | ---- | --------------- | --------------------------------------------------------------------------- |
| Region     | ✅   | String          | 地域                                                                        |
| ProjectId  | ✅   | String          | 项目 ID                                                                     |
| RunGroupId | ❌   | String          | 任务批次 ID（模式一/三）                                                    |
| RunUuids.N | ❌   | Array of String | 要重试的任务 UUID 列表（模式二/三），通过 DescribeRuns 查询子任务的 RunUuid |
| WDLOption  | ❌   | RunOption       | WDL 运行选项覆盖                                                            |
| NFOption   | ❌   | NFOption        | Nextflow 运行选项覆盖                                                       |

**三种重试模式：**

1. 仅传 `RunGroupId` → 重试整个批次
2. 仅传 `RunUuids` → 重试单个/多个任务
3. 同时传 `RunGroupId` + `RunUuids` → 重试批次中的特定任务

#### 返回参数

| 参数       | 类型   | 说明                |
| ---------- | ------ | ------------------- |
| RunGroupId | String | 新创建的任务批次 ID |
| RequestId  | String | 请求 ID             |

#### tccli 示例

```bash
# 重试整个批次
tccli omics RetryRuns --region ap-guangzhou \
  --ProjectId "prj-xxx" --RunGroupId "run-xxx"

# 重试指定任务
tccli omics RetryRuns --region ap-guangzhou \
  --ProjectId "prj-xxx" --RunUuids '["uuid1", "uuid2"]'

# 重试批次中的特定任务
tccli omics RetryRuns --region ap-guangzhou \
  --ProjectId "prj-xxx" --RunGroupId "run-xxx" \
  --RunUuids '["uuid1", "uuid2"]'
```

---

### 9. TerminateRunGroup — 终止任务批次

#### 请求参数

| 参数       | 必选 | 类型   | 说明        |
| ---------- | ---- | ------ | ----------- |
| Region     | ✅   | String | 地域        |
| RunGroupId | ✅   | String | 任务批次 ID |
| ProjectId  | ❌   | String | 项目 ID     |

#### 返回参数

| 参数      | 类型   | 说明    |
| --------- | ------ | ------- |
| RequestId | String | 请求 ID |

#### tccli 示例

```bash
tccli omics TerminateRunGroup \
  --region ap-guangzhou \
  --RunGroupId "run-xxx"
```

---

### 10. DescribeTables — 查询表格列表

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| ProjectId | ✅   | String          | 项目 ID                     |
| Limit     | ❌   | Integer         | 返回数量，默认 10，最大 100 |
| Offset    | ❌   | Integer         | 偏移量                      |
| Filters.N | ❌   | Array of Filter | 过滤器（Name, TableId）     |

#### 返回参数

| 参数       | 类型           | 说明     |
| ---------- | -------------- | -------- |
| TotalCount | Integer        | 总数     |
| Tables     | Array of Table | 表格列表 |
| RequestId  | String         | 请求 ID  |

#### tccli 示例

```bash
tccli omics DescribeTables --region ap-guangzhou --ProjectId "prj-xxx" --Limit 20
```

---

### 11. DescribeTablesRows — 查询表格行数据

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| ProjectId | ✅   | String          | 项目 ID                     |
| TableId   | ✅   | String          | 表格 ID                     |
| Limit     | ❌   | Integer         | 返回数量，默认 10，最大 100 |
| Offset    | ❌   | Integer         | 偏移量                      |
| Filters.N | ❌   | Array of Filter | 过滤器（Tr, TableRowUuid）  |

**支持的 Filters：**

| Filter Name    | 说明           |
| -------------- | -------------- |
| `Tr`           | 按行内容搜索   |
| `TableRowUuid` | 按行 UUID 过滤 |

#### 返回参数

| 参数       | 类型              | 说明       |
| ---------- | ----------------- | ---------- |
| TotalCount | Integer           | 总行数     |
| Rows       | Array of TableRow | 表格行数据 |
| RequestId  | String            | 请求 ID    |

#### tccli 示例

```bash
tccli omics DescribeTablesRows \
  --region ap-guangzhou \
  --ProjectId "prj-xxx" \
  --TableId "tab-xxx" \
  --Limit 10
```

---

## 资源查询接口

### 13. DescribeApplications — 查询项目应用列表

查询指定项目下的应用列表，支持按名称、ID、类型等过滤。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| ProjectId | ✅   | String          | 项目 ID                     |
| Limit     | ❌   | Integer         | 返回数量，默认 20，最大 100 |
| Offset    | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N | ❌   | Array of Filter | 过滤器                      |
| OrderBy   | ❌   | String          | 排序字段（如 SortOrder）    |

**支持的 Filters：**

| Filter Name     | 说明                             |
| --------------- | -------------------------------- |
| `Name`          | 按应用名称过滤                   |
| `ApplicationId` | 按应用 ID 过滤                   |
| `HasRun`        | 按是否有运行记录过滤             |
| `CreatorId`     | 按创建人 ID 过滤                 |
| `Type`          | 按应用类型过滤（WDL / NEXTFLOW） |

#### 返回参数

| 参数         | 类型                 | 说明         |
| ------------ | -------------------- | ------------ |
| TotalCount   | Integer              | 应用列表总数 |
| Applications | Array of Application | 应用列表     |
| RequestId    | String               | 请求 ID      |

#### tccli 示例

```bash
# 查询项目下的应用
tccli omics DescribeApplications --region ap-guangzhou \
  --ProjectId "prj-xxx" --Limit 20

# 按名称过滤
tccli omics DescribeApplications --region ap-guangzhou \
  --ProjectId "prj-xxx" \
  --Filters '[{"Name":"Name","Values":["WGS"]}]'

# 按类型过滤
tccli omics DescribeApplications --region ap-guangzhou \
  --ProjectId "prj-xxx" \
  --Filters '[{"Name":"Type","Values":["WDL"]}]'
```

---

### 14. DescribeApplicationVersions — 查询应用版本列表

查询指定应用的可运行版本列表。在运行 WDL 应用前，可让用户选择具体版本进行运行。

#### 请求参数

| 参数          | 必选 | 类型    | 说明                        |
| ------------- | ---- | ------- | --------------------------- |
| Region        | ✅   | String  | 地域                        |
| ProjectId     | ✅   | String  | 项目 ID                     |
| ApplicationId | ✅   | String  | 应用 ID                     |
| Limit         | ❌   | Integer | 返回数量，默认 20，最大 100 |
| Offset        | ❌   | Integer | 偏移量，默认 0              |

#### 返回参数

| 参数                | 类型                        | 说明         |
| ------------------- | --------------------------- | ------------ |
| TotalCount          | Integer                     | 应用版本总数 |
| ApplicationVersions | Array of ApplicationVersion | 应用版本列表 |
| RequestId           | String                      | 请求 ID      |

#### tccli 示例

```bash
# 查询应用的所有版本
tccli omics DescribeApplicationVersions --region ap-guangzhou \
  --ProjectId "prj-xxx" --ApplicationId "app-xxx"

# 分页查询
tccli omics DescribeApplicationVersions --region ap-guangzhou \
  --ProjectId "prj-xxx" --ApplicationId "app-xxx" --Offset 0 --Limit 10
```

---

### 15. DescribeProjects — 查询项目列表

查询组学平台下的项目列表。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| Limit     | ❌   | Integer         | 返回数量，默认 20，最大 100 |
| Offset    | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N | ❌   | Array of Filter | 过滤器                      |

**支持的 Filters：**

| Filter Name | 说明           |
| ----------- | -------------- |
| `Name`      | 按项目名称过滤 |
| `ProjectId` | 按项目 ID 过滤 |
| `Region`    | 按地域过滤     |

#### 返回参数

| 参数       | 类型             | 说明     |
| ---------- | ---------------- | -------- |
| TotalCount | Integer          | 项目总数 |
| Projects   | Array of Project | 项目列表 |
| RequestId  | String           | 请求 ID  |

#### tccli 示例

```bash
# 查询所有项目
tccli omics DescribeProjects --region ap-guangzhou --Limit 20

# 按项目ID查询
tccli omics DescribeProjects --region ap-guangzhou \
  --Filters '[{"Name":"ProjectId","Values":["prj-xxx"]}]'

# 按名称过滤
tccli omics DescribeProjects --region ap-guangzhou \
  --Filters '[{"Name":"Name","Values":["WGS项目"]}]'
```

---

### 16. DescribeEnvironments — 查询环境列表

查询项目运行可选环境列表。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                        |
| --------- | ---- | --------------- | --------------------------- |
| Region    | ✅   | String          | 地域                        |
| Limit     | ❌   | Integer         | 返回数量，默认 20，最大 100 |
| Offset    | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N | ❌   | Array of Filter | 过滤器                      |

**支持的 Filters：**

| Filter Name     | 说明           |
| --------------- | -------------- |
| `EnvironmentId` | 按环境 ID 过滤 |
| `Name`          | 按环境名称过滤 |
| `Status`        | 按环境状态过滤 |

#### 返回参数

| 参数         | 类型                 | 说明         |
| ------------ | -------------------- | ------------ |
| TotalCount   | Integer              | 环境总数     |
| Environments | Array of Environment | 环境详情列表 |
| RequestId    | String               | 请求 ID      |

#### tccli 示例

```bash
# 查询所有环境
tccli omics DescribeEnvironments --region ap-guangzhou --Limit 20

# 按环境ID查询
tccli omics DescribeEnvironments --region ap-guangzhou \
  --Filters '[{"Name":"EnvironmentId","Values":["env-xxx"]}]'

# 查询运行中的环境
tccli omics DescribeEnvironments --region ap-guangzhou \
  --Filters '[{"Name":"Status","Values":["RUNNING"]}]'
```

---

### 17. DescribeInputTemplates — 查询运行参数模板列表

查询指定应用的运行参数模板列表。在运行应用前，查询全部的模板列表，待用户自行选择。

#### 请求参数

| 参数                 | 必选 | 类型            | 说明                        |
| -------------------- | ---- | --------------- | --------------------------- |
| Region               | ✅   | String          | 地域                        |
| ApplicationId        | ✅   | String          | 应用 ID                     |
| ProjectId            | ❌   | String          | 项目 ID                     |
| ApplicationVersionId | ❌   | String          | 应用版本 ID                 |
| Limit                | ❌   | Integer         | 返回数量，默认 20，最大 100 |
| Offset               | ❌   | Integer         | 偏移量，默认 0              |
| Filters.N            | ❌   | Array of Filter | 过滤器                      |

**支持的 Filters：**

| Filter Name       | 说明           |
| ----------------- | -------------- |
| `Name`            | 按模板名称过滤 |
| `InputTemplateId` | 按模板 ID 过滤 |

#### 返回参数

| 参数           | 类型                   | 说明             |
| -------------- | ---------------------- | ---------------- |
| TotalCount     | Integer                | 模板总数         |
| InputTemplates | Array of InputTemplate | 运行参数模板列表 |
| RequestId      | String                 | 请求 ID          |

#### tccli 示例

```bash
# 查询应用的参数模板
tccli omics DescribeInputTemplates --region ap-guangzhou \
  --ApplicationId "app-xxx"

# 指定应用版本查询
tccli omics DescribeInputTemplates --region ap-guangzhou \
  --ApplicationId "app-xxx" --ApplicationVersionId "appv-xxx"

# 按模板名称过滤
tccli omics DescribeInputTemplates --region ap-guangzhou \
  --ApplicationId "app-xxx" \
  --Filters '[{"Name":"Name","Values":["default"]}]'
```

---

### 18. GetInputTemplateFile — 查询运行参数模板内容

获取指定运行参数模板的文件内容或下载链接。

#### 请求参数

| 参数                 | 必选 | 类型   | 说明            |
| -------------------- | ---- | ------ | --------------- |
| Region               | ✅   | String | 地域            |
| InputTemplateId      | ✅   | String | 运行参数模板 ID |
| ProjectId            | ❌   | String | 项目 ID         |
| ApplicationId        | ❌   | String | 应用 ID         |
| ApplicationVersionId | ❌   | String | 应用版本 ID     |

#### 返回参数

| 参数         | 类型   | 说明                              |
| ------------ | ------ | --------------------------------- |
| CosSignedUrl | String | COS 预签名下载链接（可能为 null） |
| Content      | String | 模板内容（可能为 null）           |
| RequestId    | String | 请求 ID                           |

#### tccli 示例

```bash
# 获取参数模板内容
tccli omics GetInputTemplateFile --region ap-guangzhou \
  --InputTemplateId "inputtpl-xxx"

# 指定应用和版本
tccli omics GetInputTemplateFile --region ap-guangzhou \
  --InputTemplateId "inputtpl-xxx" \
  --ApplicationId "app-xxx" \
  --ApplicationVersionId "appv-xxx"
```

---

## 应用管理接口

### 19. ImportCommonApplication — 导入公共应用

将公共应用导入到指定项目中。需先通过 DescribePublicApplications 查询公共应用列表获取 CommonAppUuid。

#### 请求参数

| 参数             | 必选 | 类型    | 说明                             |
| ---------------- | ---- | ------- | -------------------------------- |
| Region           | ✅   | String  | 地域                             |
| CommonAppUuid    | ✅   | String  | 公共应用 UUID                    |
| CommonAppNewName | ✅   | String  | 导入后的应用名称（重命名）       |
| ProjectId        | ✅   | String  | 项目 ID                          |
| Type             | ✅   | String  | 公共应用类型：WDL / NEXTFLOW     |
| NextflowVersion  | ✅   | String  | Nextflow 引擎版本（如 v24.04.3） |
| Internal         | ❌   | Boolean | 是否内部应用                     |

#### 返回参数

| 参数          | 类型   | 说明            |
| ------------- | ------ | --------------- |
| ApplicationId | String | 导入后的应用 ID |
| RequestId     | String | 请求 ID         |

#### tccli 示例

```bash
# 导入 Nextflow 公共应用
tccli omics ImportCommonApplication --region ap-guangzhou \
  --CommonAppUuid "0de1b4ae-1543-4882-8bae-b5ee87968bc5" \
  --CommonAppNewName "scBERT_test_1" \
  --ProjectId "prj-xxx" \
  --Type "NEXTFLOW" \
  --NextflowVersion "v24.04.3"

# 导入 WDL 公共应用
tccli omics ImportCommonApplication --region ap-guangzhou \
  --CommonAppUuid "common-app-uuid-xxx" \
  --CommonAppNewName "My_WGS_Pipeline" \
  --ProjectId "prj-xxx" \
  --Type "WDL" \
  --NextflowVersion ""
```

---

### 20. DescribePublicApplications — 查询公共应用列表

查询组学平台可导入的公共应用列表。用于在 ImportCommonApplication 前获取可用的公共应用及其 UUID。

公共应用有三种类型（通过返回的 `AppGroupType` 区分）：

- **STANDALONE_APP** — 独立应用，可直接导入
- **APP_COLLECTION** — 合集，包含多个子应用，需传 `ParentAppId` 查询子应用
- **SUB_APP** — 子应用，属于某个合集，可直接导入

#### 请求参数

| 参数        | 必选 | 类型            | 说明                                                |
| ----------- | ---- | --------------- | --------------------------------------------------- |
| Region      | ✅   | String          | 地域                                                |
| ParentAppId | ❌   | String          | 父应用 ID，查询合集（APP_COLLECTION）的子应用时传入 |
| Limit       | ❌   | Integer         | 返回数量，默认 20，最大 100                         |
| Offset      | ❌   | Integer         | 偏移量，默认 0                                      |
| Filters.N   | ❌   | Array of Filter | 过滤器                                              |

**支持的 Filters：**

| Filter Name | 说明                             |
| ----------- | -------------------------------- |
| `Name`      | 按应用名称过滤                   |
| `Type`      | 按应用类型过滤（WDL / NEXTFLOW） |

#### 返回参数

| 参数         | 类型                       | 说明         |
| ------------ | -------------------------- | ------------ |
| TotalCount   | Integer                    | 公共应用总数 |
| Applications | Array of PublicApplication | 公共应用列表 |
| RequestId    | String                     | 请求 ID      |

**PublicApplication 关键字段：**

| 字段          | 类型            | 说明                                                                                      |
| ------------- | --------------- | ----------------------------------------------------------------------------------------- |
| AppId         | String          | 公共应用 ID（合集类型时，作为 `ParentAppId` 传入查询子应用）                              |
| CommonAppUuid | String          | 公共应用 UUID（供 ImportCommonApplication 使用）                                          |
| Name          | String          | 应用名称                                                                                  |
| Type          | String          | 应用类型（WDL / NEXTFLOW）                                                                |
| AppGroupType  | String          | 应用分组类型：`STANDALONE_APP`（独立应用）/ `APP_COLLECTION`（合集）/ `SUB_APP`（子应用） |
| AppTags       | Array of AppTag | 应用标签分类列表                                                                          |

**AppTag 结构：**

| 字段    | 类型   | 说明                                                 |
| ------- | ------ | ---------------------------------------------------- |
| TagId   | String | 标签 ID                                              |
| TagName | String | 标签名称（如"基因组学"、"转录组学"等，用于应用分类） |

#### 查询策略

1. **查询顶层公共应用**（不传 ParentAppId）→ 返回独立应用和合集
2. **遇到 APP_COLLECTION 合集** → 用该应用的 `AppId` 作为 `--ParentAppId` 再次调用 → 返回其子应用（SUB_APP）
3. **按标签分类展示** → 用 AppTags 中的 TagName 对应用进行分类展示

#### tccli 示例

```bash
# 查询所有公共应用（顶层）
tccli omics DescribePublicApplications --region ap-guangzhou --Limit 999

# 按类型过滤
tccli omics DescribePublicApplications --region ap-guangzhou \
  --AppType 'WDL'

# 按名称过滤
tccli omics DescribePublicApplications --region ap-guangzhou \
  --Filters '[{"Name":"Name","Values":["scBERT"]}]'

# 查询某个合集的子应用
tccli omics DescribePublicApplications --region ap-guangzhou \
  --ParentAppId "app-collection-xxx"
```

---

## 结果返回接口

### 12. GetRunMetadataFile — 获取任务详情文件

获取任务执行产生的日志和报告文件的 COS 预签名下载链接。

#### 请求参数

| 参数      | 必选 | 类型            | 说明                                |
| --------- | ---- | --------------- | ----------------------------------- |
| Region    | ✅   | String          | 地域                                |
| RunUuid   | ✅   | String          | 任务 UUID                           |
| ProjectId | ❌   | String          | 项目 ID                             |
| Key       | ❌   | String          | 获取指定文件名（与 Keys 二选一）    |
| Keys.N    | ❌   | Array of String | 批量获取文件名列表（与 Key 二选一） |

**可获取的文件：**

| 文件名                    | 说明              | 条件                      |
| ------------------------- | ----------------- | ------------------------- |
| `nextflow.log`            | Nextflow 运行日志 | 默认支持                  |
| `execution_report.html`   | 执行报告          | 需 NFOption.Report = true |
| `execution_timeline.html` | 执行时间线        | 需 NFOption.Report = true |
| `execution_trace.txt`     | 执行追踪          | 需 NFOption.Report = true |
| `pipeline_dag.html`       | 流水线 DAG 图     | 需 NFOption.Report = true |

#### 返回参数

| 参数          | 类型            | 说明                                   |
| ------------- | --------------- | -------------------------------------- |
| CosSignedUrl  | String          | 预签名下载链接（1 分钟有效，Key 模式） |
| CosSignedUrls | Array of String | 批量预签名链接（Keys 模式）            |
| RequestId     | String          | 请求 ID                                |

> **注意：** 预签名链接仅 **1 分钟内有效**，需及时使用。

#### tccli 示例

```bash
# 获取默认文件
tccli omics GetRunMetadataFile \
  --region ap-guangzhou \
  --RunUuid "fe92382a-9028-4e0f-8d12-fb11d9ad058c"

# 获取指定文件
tccli omics GetRunMetadataFile \
  --region ap-guangzhou \
  --RunUuid "fe92382a-xxx" \
  --Key "execution_report.html"

# 批量获取
tccli omics GetRunMetadataFile \
  --region ap-guangzhou \
  --RunUuid "fe92382a-xxx" \
  --Keys '["nextflow.log", "execution_report.html", "execution_timeline.html"]'
```

---

## 数据结构参考

### RunGroup（任务批次）

| 字段               | 类型                    | 说明                 |
| ------------------ | ----------------------- | -------------------- |
| RunGroupId         | String                  | 任务批次 ID          |
| ProjectId          | String                  | 项目 ID              |
| ProjectName        | String                  | 项目名称             |
| ApplicationId      | String                  | 应用 ID              |
| ApplicationName    | String                  | 应用名称             |
| ApplicationType    | String                  | 应用类型             |
| ApplicationVersion | String                  | 应用版本             |
| AccessMode         | String                  | 访问模式             |
| EnvironmentId      | String                  | 环境 ID              |
| EnvironmentName    | String                  | 环境名称             |
| TableId            | String                  | 关联表格 ID          |
| Name               | String                  | 任务名称             |
| Description        | String                  | 描述                 |
| Status             | String                  | 状态                 |
| Type               | String                  | 类型（WDL/NEXTFLOW） |
| WorkDir            | String                  | 工作目录             |
| Input              | String                  | 输入 JSON            |
| InputType          | String                  | 输入类型             |
| InputCosUri        | String                  | 输入 COS 地址        |
| InputTemplateId    | String                  | 输入模板 ID          |
| Option             | RunOption               | WDL 运行选项         |
| NFOption           | NFOption                | Nextflow 运行选项    |
| Volumes            | Array of VolumeInfo     | 缓存卷信息           |
| TotalRun           | Integer                 | 任务总数             |
| RunStatusCounts    | Array of RunStatusCount | 各状态计数           |
| ExecutionTime      | ExecutionTime           | 执行时间             |
| ErrorMessage       | String                  | 错误信息             |
| Notification       | Boolean                 | 是否开启通知         |
| CreateTime         | Timestamp               | 创建时间             |
| UpdateTime         | Timestamp               | 更新时间             |
| Creator            | String                  | 创建者               |
| CreatorId          | String                  | 创建者 ID            |
| ResultNotify       | Boolean                 | 结果通知             |

### Run（任务）

| 字段          | 类型          | 说明            |
| ------------- | ------------- | --------------- |
| RunUuid       | String        | 任务 UUID       |
| ProjectId     | String        | 项目 ID         |
| ApplicationId | String        | 应用 ID         |
| RunGroupId    | String        | 所属批次 ID     |
| EnvironmentId | String        | 环境 ID         |
| UserDefinedId | String        | 用户自定义 ID   |
| TableId       | String        | 关联表格 ID     |
| TableRowUuid  | String        | 关联表格行 UUID |
| Status        | String        | 状态            |
| Input         | String        | 输入 JSON       |
| ExecutionTime | ExecutionTime | 执行时间        |
| Cache         | CacheInfo     | 缓存信息        |
| ErrorMessage  | String        | 错误信息        |
| CreateTime    | Timestamp     | 创建时间        |
| UpdateTime    | Timestamp     | 更新时间        |

### RunMetadata（作业元数据）

| 字段         | 类型      | 说明                                   |
| ------------ | --------- | -------------------------------------- |
| RunType      | String    | 类型：Workflow / Call / Scatter        |
| RunId        | String    | 作业标识（可用于 GetRunCalls 的 Path） |
| ParentId     | String    | 父作业 ID                              |
| JobId        | String    | 任务 ID                                |
| CallName     | String    | 作业名称                               |
| ScatterIndex | Integer   | 散列索引（非散列为 -1）                |
| Input        | String    | 输入 JSON                              |
| Output       | String    | 输出 JSON                              |
| Status       | String    | 状态                                   |
| ErrorMessage | String    | 错误信息                               |
| StartTime    | Timestamp | 开始时间                               |
| SubmitTime   | Timestamp | 提交时间                               |
| EndTime      | Timestamp | 结束时间                               |
| Command      | String    | 执行命令                               |
| Runtime      | String    | 运行时配置                             |
| Preprocess   | String    | 预处理信息                             |
| PostProcess  | String    | 后处理信息                             |
| CallCached   | Boolean   | 是否缓存命中                           |
| WorkDir      | String    | 工作目录                               |
| Stdout       | String    | 标准输出路径                           |
| Stderr       | String    | 标准错误路径                           |
| Meta         | String    | 元信息                                 |

### Table（表格）

| 字段        | 类型                 | 说明      |
| ----------- | -------------------- | --------- |
| TableId     | String               | 表格 ID   |
| ProjectId   | String               | 项目 ID   |
| Name        | String               | 表格名称  |
| Description | String               | 描述      |
| Columns     | Array of TableColumn | 列定义    |
| CreateTime  | Timestamp            | 创建时间  |
| Creator     | String               | 创建者    |
| CreatorId   | String               | 创建者 ID |

### TableColumn（表格列）

| 字段     | 类型   | 说明     |
| -------- | ------ | -------- |
| Header   | String | 列名     |
| DataType | String | 数据类型 |

### TableRow（表格行）

| 字段         | 类型            | 说明               |
| ------------ | --------------- | ------------------ |
| TableRowUuid | String          | 行 UUID            |
| Content      | Array of String | 行数据（按列顺序） |

### RunOption（WDL 运行选项）

| 字段                    | 类型    | 必选 | 说明                                         |
| ----------------------- | ------- | ---- | -------------------------------------------- |
| FailureMode             | String  | ✅   | 失败模式：ContinueWhilePossible / NoNewCalls |
| UseCallCache            | Boolean | ✅   | 是否使用缓存                                 |
| UseErrorOnHold          | Boolean | ✅   | 是否错误挂起                                 |
| FinalWorkflowOutputsDir | String  | ❌   | 输出归档 COS 路径                            |
| UseRelativeOutputPaths  | Boolean | ❌   | 是否使用相对路径                             |

### NFOption（Nextflow 运行选项）

| 字段      | 类型    | 说明                                                                                           |
| --------- | ------- | ---------------------------------------------------------------------------------------------- |
| Config    | String  | Config 配置内容                                                                                |
| Profile   | String  | Profile                                                                                        |
| Report    | Boolean | Report 开关（开启后可获取 execution_report 等文件）                                            |
| Resume    | Boolean | Resume 开关                                                                                    |
| NFVersion | String  | **必填**。Nextflow 引擎版本，取自 DescribeApplications 返回的 `RunConstraints.NextflowVersion`。**注意：若版本号带有前缀 `v`（如 `v23.10.0`），需去掉 `v`，填入 `23.10.0`** |
| LaunchDir | String  | 启动路径                                                                                       |

### GitInfo（Git 仓库信息）

| 字段        | 类型   | 说明          |
| ----------- | ------ | ------------- |
| GitHttpPath | String | Git HTTP 地址 |
| Branch      | String | 分支名        |

### ExecutionTime（执行时间）

| 字段       | 类型      | 说明     |
| ---------- | --------- | -------- |
| SubmitTime | Timestamp | 提交时间 |
| StartTime  | Timestamp | 开始时间 |
| EndTime    | Timestamp | 结束时间 |

### CacheInfo（缓存信息）

| 字段            | 类型    | 说明                 |
| --------------- | ------- | -------------------- |
| CacheClearDelay | Integer | 缓存清理延迟（小时） |
| CacheHitCount   | Integer | 缓存命中次数         |
| CacheHitSize    | Integer | 缓存命中大小（字节） |

### RunStatusCount（状态计数）

| 字段   | 类型    | 说明           |
| ------ | ------- | -------------- |
| Status | String  | 状态名         |
| Count  | Integer | 该状态的任务数 |

### Filter（过滤器）

| 字段   | 类型            | 说明                  |
| ------ | --------------- | --------------------- |
| Name   | String          | 过滤字段名            |
| Values | Array of String | 过滤值列表（OR 关系） |

### Application（应用）

| 字段           | 类型                        | 说明                                                                           |
| -------------- | --------------------------- | ------------------------------------------------------------------------------ |
| ApplicationId  | String                      | 应用 ID                                                                        |
| ProjectId      | String                      | 项目 ID                                                                        |
| Name           | String                      | 应用名称                                                                       |
| Description    | String                      | 描述                                                                           |
| Type           | String                      | 应用类型（WDL / NEXTFLOW）                                                     |
| Entrypoint     | String                      | 代码入口文件                                                                   |
| CreateTime     | Timestamp                   | 创建时间                                                                       |
| UpdateTime     | Timestamp                   | 更新时间                                                                       |
| Creator        | String                      | 创建者                                                                         |
| CreatorId      | String                      | 创建者 ID                                                                      |
| VersionCount   | Integer                     | 版本数量                                                                       |
| Versions       | Array of ApplicationVersion | 版本列表                                                                       |
| GitSource      | GitInfo                     | Git 仓库信息                                                                   |
| CosSource      | CosFileInfo                 | COS 文件信息                                                                   |
| SortOrder      | Integer                     | 排序顺序                                                                       |
| RunConstraints | RunConstraints              | 运行约束（含 NextflowVersion，NF 应用运行时必须取此值作为 NFOption.NFVersion） |

### ApplicationVersion（应用版本）

| 字段                 | 类型        | 说明         |
| -------------------- | ----------- | ------------ |
| ApplicationVersionId | String      | 版本 ID      |
| Type                 | String      | 版本类型     |
| Name                 | String      | 发布名称     |
| Description          | String      | 发布描述     |
| Entrypoint           | String      | 入口文件     |
| CreateTime           | Timestamp   | 创建时间     |
| CreatorName          | String      | 创建者名称   |
| CreatorId            | String      | 创建者 ID    |
| GitSource            | GitInfo     | Git 仓库信息 |
| CosSource            | CosFileInfo | COS 文件信息 |

### Project（项目）

| 字段        | 类型      | 说明         |
| ----------- | --------- | ------------ |
| ProjectId   | String    | 项目 ID      |
| Name        | String    | 项目名称     |
| Description | String    | 描述         |
| Region      | String    | 地域         |
| CreateTime  | Timestamp | 创建时间     |
| UpdateTime  | Timestamp | 更新时间     |
| Creator     | String    | 创建者       |
| IsDefault   | Boolean   | 是否默认项目 |

### Environment（环境）

| 字段             | 类型        | 说明                  |
| ---------------- | ----------- | --------------------- |
| EnvironmentId    | String      | 环境 ID               |
| Name             | String      | 环境名称              |
| Description      | String      | 描述                  |
| Status           | String      | 状态（如 RUNNING）    |
| Region           | String      | 地域                  |
| Type             | String      | 类型（如 KUBERNETES） |
| CreationTime     | Timestamp   | 创建时间              |
| ResourceIds      | ResourceIds | 关联资源 ID 集合      |
| Available        | Boolean     | 是否可用              |
| IsDefault        | Boolean     | 是否默认环境          |
| IsManaged        | Boolean     | 是否托管环境          |
| Message          | String      | 状态消息              |
| LastWorkflowUuid | String      | 最近一次工作流 UUID   |

### InputTemplate（运行参数模板）

| 字段                 | 类型   | 说明            |
| -------------------- | ------ | --------------- |
| InputTemplateId      | String | 参数模板 ID     |
| Uuid                 | String | 唯一 ID         |
| ProjectId            | String | 关联项目 ID     |
| ApplicationId        | String | 关联应用 ID     |
| ApplicationVersionId | String | 关联应用版本 ID |
| Name                 | String | 模板名称        |
| Description          | String | 描述            |
| Creator              | String | 创建者          |
| CreatorId            | String | 创建者 ID       |

### CosFileInfo（COS 文件信息）

| 字段   | 类型   | 说明         |
| ------ | ------ | ------------ |
| Bucket | String | 存储桶       |
| Uri    | String | COS 文件地址 |
| Region | String | 地域         |

### RunConstraints（运行约束）

| 字段            | 类型   | 说明                                                           |
| --------------- | ------ | -------------------------------------------------------------- |
| NextflowVersion | String | Nextflow 引擎版本（NF 应用运行时作为 NFOption.NFVersion 传入，需去掉版本号前缀 `v`） |
