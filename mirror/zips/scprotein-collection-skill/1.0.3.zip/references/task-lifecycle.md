# 任务生命周期与状态机

## 任务层级结构

组学平台采用两层任务结构：

```
RunGroup（任务批次）
├── Run 1（子任务）
├── Run 2（子任务）
├── Run 3（子任务）
└── ...
```

- **RunGroup**：一次投递产生的任务批次，包含一个或多个 Run
- **Run**：具体的单个分析任务执行

## 状态定义

### RunGroup 状态

| 状态 | 说明 | 是否终态 |
|------|------|---------|
| `Pending` | 等待调度 | ❌ |
| `Running` | 运行中（至少有一个 Run 在运行） | ❌ |
| `Succeeded` | 全部 Run 成功完成 | ✅ |
| `Failed` | 存在 Run 失败 | ✅ |
| `Aborted` | 被用户终止 | ✅ |

### Run 状态

| 状态 | 说明 | 是否终态 |
|------|------|---------|
| `Pending` | 等待调度 | ❌ |
| `Running` | 正在执行 | ❌ |
| `Succeeded` | 执行成功 | ✅ |
| `Failed` | 执行失败 | ✅ |
| `Aborted` | 被终止 | ✅ |

## 状态转换图

```
                  ┌──────────┐
                  │ Pending  │
                  └────┬─────┘
                       │
                       ▼
                  ┌──────────┐     用户终止
                  │ Running  │────────────→ ┌──────────┐
                  └────┬─────┘              │ Aborted  │
                       │                    └──────────┘
              ┌────────┴────────┐
              ▼                 ▼
        ┌──────────┐     ┌──────────┐
        │Succeeded │     │  Failed  │
        └──────────┘     └────┬─────┘
                               │
                               │ 重试 (RetryRuns)
                               ▼
                          ┌──────────┐
                          │ Pending  │ (新的重试周期)
                          └──────────┘
```

## 状态查询方法

### 查询批次状态

```bash
tccli omics DescribeRunGroups \
  --region ap-guangzhou \
  --Filters '[{"Name":"RunGroupId","Values":["run-xxx"]}]'
```

返回中的 `RunStatusCounts` 字段提供各状态计数：

```json
"RunStatusCounts": [
    {"Status": "Running", "Count": 2},
    {"Status": "Succeeded", "Count": 3},
    {"Status": "Failed", "Count": 1}
]
```

### 查询子任务状态

```bash
tccli omics DescribeRuns \
  --region ap-guangzhou \
  --RunGroupId "run-xxx"
```

## 执行时间

每个 RunGroup 和 Run 都有 `ExecutionTime` 字段：

| 时间点 | 字段 | 说明 |
|--------|------|------|
| 提交时间 | `SubmitTime` | 任务提交到平台的时间 |
| 开始时间 | `StartTime` | 实际开始执行的时间 |
| 结束时间 | `EndTime` | 执行完成的时间 |

## 长任务处理策略

组学分析任务通常耗时数分钟到数天。Agent 应采用以下策略：

1. **投递后立即返回** — 不要等待任务完成
2. **异步查询** — 引导用户随时查询状态
3. **状态播报** — 展示各状态子任务的计数
4. **失败处理** — 提供重试和错误排查建议

### 推荐交互模式

```
用户："帮我投递一个 WGS 分析"
Agent：[执行 RunApplication] → "任务已投递！批次ID: run-xxx。
       分析通常需要 30 分钟到数小时，你可以随时问我查看进度。"

用户："查看 run-xxx 的状态"
Agent：[执行 DescribeRunGroups] → "任务 run-xxx 状态：
       总 5 个子任务 | ✅已完成 3 | 🔄运行中 1 | ⏳等待中 1"

用户："结果出来了吗？"
Agent：[执行 DescribeRunGroups] → 检查状态
       如果 Succeeded → [执行 GetRunMetadataFile] → 返回结果链接
       如果 Running → "任务还在运行中，预计还需要一些时间。"
```

## 可执行的操作（按状态）

| 当前状态 | 可查询 | 可终止 | 可重试 | 可获取结果 |
|----------|--------|--------|--------|-----------|
| Pending | ✅ | ✅ | ❌ | ❌ |
| Running | ✅ | ✅ | ❌ | ❌ |
| Succeeded | ✅ | ❌ | ❌ | ✅ |
| Failed | ✅ | ❌ | ✅ | ❌ |
| Aborted | ✅ | ❌ | ❌ | ❌ |
