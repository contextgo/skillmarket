#!/usr/bin/env bash
# tccli_runner.sh — 腾讯云组学平台 tccli omics 命令生成与执行工具
# 用法: bash tccli_runner.sh <API名称> <region> [--参数名 值 ...]
#
# 示例:
#   bash tccli_runner.sh DescribeRunGroups ap-guangzhou --Limit 10
#   bash tccli_runner.sh RunApplication ap-guangzhou --ApplicationId "app-xxx" --Name "test" --EnvironmentId "env-xxx" --InputBase64 "e30K"
#   bash tccli_runner.sh DescribeRunGroups ap-guangzhou --Filters '[{"Name":"Status","Values":["Running"]}]'

set -euo pipefail

# ============================================================
# 允许的 API 白名单（仅限 omics 产品）
# ============================================================
ALLOWED_APIS=(
  "RunApplication"
  "ImportTableFile"
  "DescribeRunGroups"
  "DescribeRuns"
  "GetRunStatus"
  "GetRunCalls"
  "RetryRuns"
  "TerminateRunGroup"
  "DescribeTables"
  "DescribeTablesRows"
  "GetRunMetadataFile"
  "DescribeApplicationVersions"
  "DescribeInputTemplates"
  "DescribeApplications"
  "DescribeProjects"
  "GetInputTemplateFile"
  "ImportCommonApplication"
  "DescribeEnvironments"
  "DescribePublicApplications"
)

# 支持的地域
ALLOWED_REGIONS=("ap-beijing" "ap-guangzhou" "ap-shanghai")

# ============================================================
# 参数校验
# ============================================================
if [ $# -lt 2 ]; then
  echo "❌ 用法: bash tccli_runner.sh <API名称> <region> [--参数名 值 ...]"
  echo ""
  echo "允许的 API: ${ALLOWED_APIS[*]}"
  echo "支持的地域: ${ALLOWED_REGIONS[*]}"
  exit 1
fi

API_NAME="$1"
REGION="$2"
shift 2

# 校验 API 名称
api_valid=false
for api in "${ALLOWED_APIS[@]}"; do
  if [ "$api" = "$API_NAME" ]; then
    api_valid=true
    break
  fi
done

if [ "$api_valid" = false ]; then
  echo "❌ 不允许的 API: $API_NAME"
  echo "允许的 API: ${ALLOWED_APIS[*]}"
  exit 1
fi

# 校验地域
region_valid=false
for r in "${ALLOWED_REGIONS[@]}"; do
  if [ "$r" = "$REGION" ]; then
    region_valid=true
    break
  fi
done

if [ "$region_valid" = false ]; then
  echo "❌ 不支持的地域: $REGION"
  echo "支持的地域: ${ALLOWED_REGIONS[*]}"
  exit 1
fi

# ============================================================
# 检查 tccli 是否可用
# ============================================================
if ! command -v tccli &>/dev/null; then
  echo "❌ tccli 未安装。请先安装: pip install tccli"
  echo "然后配置认证: tccli configure"
  exit 1
fi

# ============================================================
# 收集用户传入的参数键名（用于必选参数校验）
# ============================================================
declare -a USER_ARGS=("$@")
declare -a USER_PARAM_KEYS=()

idx=0
while [ $idx -lt ${#USER_ARGS[@]} ]; do
  arg="${USER_ARGS[$idx]}"
  if [[ "$arg" == --* ]]; then
    # 提取参数键名（去掉 -- 前缀）
    key="${arg#--}"
    USER_PARAM_KEYS+=("$key")
    idx=$((idx + 2))  # 跳过值
  else
    idx=$((idx + 1))
  fi
done

# ============================================================
# 各 API 必选参数定义及描述
# ============================================================
get_required_params() {
  local api="$1"
  case "$api" in
    RunApplication)
      echo "ApplicationId:应用ID(如 app-xxx)|EnvironmentId:投递环境ID(如 env-xxx)|InputBase64:任务输入base64编码(空输入用e30K,可通过encode_input.sh生成)"
      ;;
    ImportTableFile)
      echo "ProjectId:项目ID(如 prj-xxx)|Name:表格名称|CosUri:COS上的CSV/TSV文件地址|DataType:各列数据类型(JSON数组,如[\"String\",\"File\"])"
      ;;
    DescribeRunGroups)
      # 无额外必选参数（region 已校验）
      echo ""
      ;;
    DescribeRuns)
      # 无额外必选参数
      echo ""
      ;;
    GetRunStatus)
      echo "RunUuid:任务UUID"
      ;;
    GetRunCalls)
      echo "RunUuid:任务UUID|Path:作业路径(/表示顶层,或使用Workflow/Scatter类型作业的RunId)"
      ;;
    RetryRuns)
      # ProjectId 必选，RunGroupId 或 RunUuids 至少提供一个（特殊校验见下方）
      echo "ProjectId:项目ID(如 prj-xxx)"
      ;;
    TerminateRunGroup)
      echo "RunGroupId:任务批次ID(如 run-xxx)"
      ;;
    DescribeTables)
      echo "ProjectId:项目ID(如 prj-xxx)"
      ;;
    DescribeTablesRows)
      echo "ProjectId:项目ID(如 prj-xxx)|TableId:表格ID(如 tab-xxx)"
      ;;
    GetRunMetadataFile)
      echo "RunUuid:任务UUID"
      ;;
    DescribeApplicationVersions)
      echo "ProjectId:项目ID(如 prj-xxx)|ApplicationId:应用ID(如 app-xxx)"
      ;;
    DescribeInputTemplates)
      echo "ApplicationId:应用ID(如 app-xxx)"
      ;;
    DescribeApplications)
      echo "ProjectId:项目ID(如 prj-xxx)"
      ;;
    DescribeProjects)
      # 无额外必选参数
      echo ""
      ;;
    GetInputTemplateFile)
      echo "InputTemplateId:运行参数模板ID"
      ;;
    ImportCommonApplication)
      echo "CommonAppUuid:公共应用UUID|CommonAppNewName:导入后应用名称|ProjectId:项目ID(如 prj-xxx)|Type:应用类型(WDL或NEXTFLOW)|NextflowVersion:Nextflow版本(如 v24.04.3)"
      ;;
    DescribeEnvironments)
      # 无额外必选参数
      echo ""
      ;;
    DescribePublicApplications)
      # 无额外必选参数
      echo ""
      ;;
    *)
      echo ""
      ;;
  esac
}

# 检查某个参数键是否已提供
has_param() {
  local target="$1"
  for k in "${USER_PARAM_KEYS[@]}"; do
    # 支持 .N 后缀的数组参数（如 DataType.0, DataType.1 匹配 DataType）
    if [ "$k" = "$target" ] || [[ "$k" == "${target}."* ]]; then
      return 0
    fi
  done
  return 1
}

# ============================================================
# 必选参数校验
# ============================================================
REQUIRED_SPEC=$(get_required_params "$API_NAME")
MISSING_PARAMS=()

if [ -n "$REQUIRED_SPEC" ]; then
  IFS='|' read -ra PARAM_ENTRIES <<< "$REQUIRED_SPEC"
  for entry in "${PARAM_ENTRIES[@]}"; do
    IFS=':' read -r param_name param_desc <<< "$entry"
    if ! has_param "$param_name"; then
      MISSING_PARAMS+=("  --$param_name  ($param_desc)")
    fi
  done
fi

# RetryRuns 特殊校验：RunGroupId 或 RunUuids 至少提供一个
if [ "$API_NAME" = "RetryRuns" ]; then
  if ! has_param "RunGroupId" && ! has_param "RunUuids"; then
    MISSING_PARAMS+=("  --RunGroupId (任务批次ID) 或 --RunUuids (任务UUID列表JSON数组)")
    MISSING_PARAMS+=("  ⤷ 三种模式: ①仅RunGroupId→重试整个批次 ②仅RunUuids→重试指定任务 ③两者都传→重试批次中的特定任务")
  fi
fi

if [ ${#MISSING_PARAMS[@]} -gt 0 ]; then
  echo "❌ $API_NAME 缺少必选参数，无法执行。请提供以下参数："
  echo ""
  for mp in "${MISSING_PARAMS[@]}"; do
    echo "$mp"
  done
  echo ""
  echo "用法: bash tccli_runner.sh $API_NAME <region> [--参数名 值 ...]"
  exit 1
fi

# ============================================================
# RunApplication: 自动生成默认 Name（如未提供）
# 逻辑: <ApplicationId>_<YYYYMMDDHHmmss>，默认前缀 Task
# ============================================================
if [ "$API_NAME" = "RunApplication" ] && ! has_param "Name"; then
  # 从参数中提取 ApplicationId 作为名称前缀
  APP_NAME_PREFIX="Task"
  idx=0
  while [ $idx -lt ${#USER_ARGS[@]} ]; do
    if [ "${USER_ARGS[$idx]}" = "--ApplicationId" ] && [ $((idx + 1)) -lt ${#USER_ARGS[@]} ]; then
      APP_NAME_PREFIX="${USER_ARGS[$((idx + 1))]}"
      break
    fi
    idx=$((idx + 1))
  done
  GENERATED_NAME="${APP_NAME_PREFIX}_$(date '+%Y%m%d%H%M%S')"
  # 注入到参数列表中
  USER_ARGS+=("--Name" "$GENERATED_NAME")
  echo "📝 自动生成任务批次名称: $GENERATED_NAME"
fi

# ============================================================
# 构建并执行命令
# ============================================================
CMD=(tccli omics "$API_NAME" --region "$REGION")

# 追加参数（使用 USER_ARGS，包含可能自动注入的 Name）
idx=0
while [ $idx -lt ${#USER_ARGS[@]} ]; do
  arg="${USER_ARGS[$idx]}"
  case "$arg" in
    --*)
      if [ $((idx + 1)) -ge ${#USER_ARGS[@]} ]; then
        echo "❌ 参数 $arg 缺少值"
        exit 1
      fi
      CMD+=("$arg" "${USER_ARGS[$((idx + 1))]}")
      idx=$((idx + 2))
      ;;
    *)
      echo "❌ 无法识别的参数: $arg（参数必须以 -- 开头）"
      exit 1
      ;;
  esac
done

# 打印将要执行的命令（方便调试）
echo "🚀 执行命令:"
echo "  ${CMD[*]}"
echo "---"

# 执行并捕获输出
OUTPUT=$("${CMD[@]}" 2>&1) || {
  EXIT_CODE=$?
  echo "❌ 命令执行失败 (exit code: $EXIT_CODE)"
  echo "$OUTPUT"
  exit $EXIT_CODE
}

# ============================================================
# 解析响应
# ============================================================
# 检查是否为有效 JSON
if echo "$OUTPUT" | python3 -c "import sys,json; json.load(sys.stdin)" 2>/dev/null; then
  # 检查是否存在错误
  HAS_ERROR=$(echo "$OUTPUT" | python3 -c "
import sys, json
data = json.load(sys.stdin)
resp = data.get('Response', {})
if 'Error' in resp:
    err = resp['Error']
    print(f\"❌ API 错误 [{err.get('Code','')}]: {err.get('Message','')}\")
    sys.exit(1)
else:
    print('OK')
" 2>&1) || {
    echo "$HAS_ERROR"
    echo ""
    echo "原始响应:"
    echo "$OUTPUT" | python3 -m json.tool 2>/dev/null || echo "$OUTPUT"
    exit 1
  }
  # 格式化输出
  echo "$OUTPUT" | python3 -m json.tool 2>/dev/null || echo "$OUTPUT"
else
  # 非 JSON 输出（可能是错误信息）
  echo "$OUTPUT"
fi
