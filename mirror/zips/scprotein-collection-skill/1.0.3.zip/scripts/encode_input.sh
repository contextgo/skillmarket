#!/usr/bin/env bash
# encode_input.sh — 将 JSON 输入编码为 InputBase64 参数值
#
# 用法:
#   bash encode_input.sh                          # 空输入，输出 e30K
#   bash encode_input.sh '{"key":"value"}'        # 编码 JSON 字符串
#   bash encode_input.sh /path/to/input.json      # 编码 JSON 文件
#
# 典型调用链:
#   1. GetInputTemplateFile 获取 Content
#   2. bash encode_input.sh '<Content值>' → 输出 base64 字符串
#   3. 将输出作为 RunApplication 的 --InputBase64 参数
#
# 输出: 可直接用于 --InputBase64 参数的 base64 编码字符串

set -euo pipefail

if [ $# -eq 0 ]; then
  # 空输入 → {} 的 base64
  echo "e30K"
  exit 0
fi

INPUT="$1"

# 判断是文件还是 JSON 字符串
if [ -f "$INPUT" ]; then
  # 文件模式：验证 JSON 有效性后编码
  if ! python3 -c "import json; json.load(open('$INPUT'))" 2>/dev/null; then
    echo "❌ 文件 $INPUT 不是有效的 JSON 格式" >&2
    exit 1
  fi
  base64 < "$INPUT" | tr -d '\n'
else
  # 字符串模式：验证 JSON 有效性后编码
  if ! echo "$INPUT" | python3 -c "import sys,json; json.load(sys.stdin)" 2>/dev/null; then
    echo "❌ 输入不是有效的 JSON 格式" >&2
    exit 1
  fi
  echo -n "$INPUT" | base64 | tr -d '\n'
fi

echo ""
