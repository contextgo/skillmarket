# Drucker Perspectives v1.0.0

**Copyright © 2024-2026 alvingoo (https://github.com/alvingoo).** Licensed under MIT. See [LICENSE](LICENSE).

**Version**: 1.0.0 · **License**: MIT · **Author**: [alvingoo](https://github.com/alvingoo/drucker-perspectives)

> 彼得·德鲁克思维框架 AI Skill。基于 Karpathy LLM Wiki 方法论，从11本核心著作蒸馏而成。

## 目录结构

```
drucker-perspectives/
├── SKILL.md           # 德鲁克视角 Skill（直接加载到 Claude Code）
├── README.md          # 使用说明
├── CLAUDE.md          # 本文件
├── LICENSE            # MIT License
└── wiki/              # Wiki 知识网络
    ├── index.md       # 内容索引
    ├── SCHEMA.md      # 格式规范
    ├── concepts/      # 10个核心概念
    ├── books/         # 11本著作索引
    ├── comparisons/   # 6个心智模型对比
    └── queries/       # 用户问答归档
```

## 触发条件

当用户提到以下关键词时激活德鲁克视角：
- 德鲁克视角 / 德鲁克会怎么看 / 德鲁克模式 / 经营之道

## 快速使用

将 `SKILL.md` 内容复制到 Claude Code 对话中直接加载。

## 核心概念（10个）

1. 有效性 (Effectiveness)
2. 贡献思维 (Contribution)
3. 成果在外部 (Results Outside)
4. 人的长处 (Strengths)
5. 知识工作者 (Knowledge Worker)
6. 经营之道 (Theory of Business)
7. 有效决策 (Decision Making)
8. 掌握时间 (Time Management)
9. 要事优先 (Prioritization)
10. 创新 (Innovation)

## 著作来源（11本）

| 著作 | 年份 |
|------|------|
| 《公司的概念》 | 1946 |
| 《管理的实践》 | 1954 |
| 《成果管理》 | 1964 |
| 《卓有成效的管理者》 | 1967 |
| 《旁观者》 | 1978 |
| 《动荡时代的管理》 | 1980 |
| 《创新与企业家精神》 | 1985 |
| 《管理前沿》 | 1986 |
| 《非营利组织的管理》 | 1990 |
| 《巨变时代的管理》 | 1995 |
| 《21世纪的管理挑战》 | 1999 |
