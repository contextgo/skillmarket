# [[uconcept of corporation]]
