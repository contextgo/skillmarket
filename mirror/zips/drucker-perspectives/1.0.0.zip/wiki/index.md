# Drucker Perspectives Wiki v1.0.0

**Copyright © 2024-2026 alvingoo (https://github.com/alvingoo).** Licensed under MIT.

> 基于 [[Karpathy LLM Wiki]] 方法论构建
> 三层结构：Raw → Wiki → Output
> 11本核心著作 • 10个核心概念 • 6种心智模型

---

## 核心概念网络

| 概念 | 定义 | 关键问题 |
|------|------|----------|
| [[effectiveness\|有效性]] | 做正确的事，而非正确地做事 | 这是正确的事吗？ |
| [[contribution\|贡献思维]] | 不问想要什么，问应贡献什么 | 组织因你而不同？ |
| [[results-outside\|成果在外部]] | 企业的目的是创造顾客 | 客户是谁？价值何在？ |
| [[strengths\|人的长处]] | 让长处有效，短处无关 | 此人长处是什么？ |
| [[knowledge-worker\|知识工作者]] | 需要自主权，自定任务 | 任务是什么？ |
| [[theory-of-business\|经营之道]] | 组织创造价值的根本假设 | 经营之道还成立吗？ |
| [[decision-making\|有效决策]] | 从见解开始，需要反对意见 | 经常性还是偶发？ |
| [[time-management\|掌握时间]] | 时间是最稀有资源 | 时间花在哪？ |
| [[prioritization\|要事优先]] | 集中精力于少数重要领域 | 什么是真正重要的？ |
| [[innovation\|创新]] | 改变资源产出，七来源系统化 | 变化中蕴含什么机遇？ |

---

## 心智模型对比

- [[effectiveness-vs-efficiency\|有效性 vs 效率]]
- [[contribution-vs-desire\|贡献 vs 愿望]]
- [[results-outside-vs-activity\|成果外部 vs 活动]]
- [[strengths-vs-weaknesses\|长处 vs 短处]]
- [[knowledge-worker-productivity\|知识工作者生产率]]
- [[ordinary-people-extraordinary\|平凡人做不平凡事]]

---

## 核心著作

### 经典（9本）
- [[practice-of-management\|管理的实践]] (1954)
- [[effective-executive\|卓有成效的管理者]] (1967)
- [[innovation-entrepreneurship\|创新与企业家精神]] (1985)
- [[challenges-21st-century\|21世纪的管理挑战]] (1999)
- [[concept-of-corporation\|公司的概念]] (1946)
- [[managing-for-results\|成果管理]] (1964)
- [[managing-nonprofit\|非营利组织的管理]] (1990)
- [[managing-turbulent-times\|动荡时代的管理]] (1980)
- [[adventures-bystander\|旁观者]] (1978)

### 晚年思想（2本）
- [[managing-great-change\|巨变时代的管理]] (1995)
- [[managing-frontier\|管理前沿]] (1986)

---

## 查询记录

参见 [[queries]] 目录

---

## 更新日志

参见 [[log|log.md]]

---

*[[SCHEMA|格式规范]] • 基于[[Karpathy LLM Wiki]]方法论*
