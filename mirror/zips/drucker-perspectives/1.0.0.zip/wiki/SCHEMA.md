# Wiki Schema v1.0.0 — 格式规范

**Copyright © 2024-2026 alvingoo (https://github.com/alvingoo).** Licensed under MIT.

> 本文件定义 Drucker Perspectives Wiki 的结构约定和工作流规则。
> 任何 LLM 维护此 wiki 时，必须遵循此 Schema。

---

## 目录结构

```
drucker-perspectives/
├── SKILL.md          # 主 Skill 文件
├── README.md         # 使用说明
└── wiki/
    ├── index.md     # 内容索引
    ├── SCHEMA.md    # 本文件
    ├── log.md       # 更新日志
    ├── concepts/    # 概念页
    ├── books/       # 著作页
    ├── comparisons/ # 对比页
    └── queries/    # 查询记录
```

## 概念页格式

每个概念页必须包含以下区块（按顺序）：

```markdown
# 概念名（英文名）

> 一句话核心洞见

## 定义
## 关键问题
## 著作来源
## 与其他概念的关系  # 使用双链 [[slug|显示名]]
## 概念演进          # 时间线表格
## 常见错误
## 关键引用          # 引用格式：> "原文" \n> ——《书名》第X章
```

**可选区块**：如果概念有独特的结构化内容（如"决策五要素"、"时间三步骤"），在"与其他概念的关系"之前插入。

## 双链约定

- 格式：`[[slug|显示名]]`
- slug 必须与文件名一致（不含 .md）
- 显示名可以与 slug 不同（如 `[[knowledge-worker|知识工作者]]`）
- 在"与其他概念的关系"区块中，每个链接必须附带一句说明关系的话

## Ingest 工作流

当新增一本著作到 raw/ 时：

1. **读取**：使用 epub-reader 工具提取 TOC + 关键章节
2. **搜索**：对每个已有概念搜索关键词
3. **更新概念页**：在"著作来源"中添加新条目，在"概念演进"中添加新行
4. **创建/更新著作页**：在 books/ 中添加新文件
5. **更新 index.md**：添加著作条目
6. **更新 log.md**：追加 ingest 记录

## Query 归档

当产生有价值的问答时：

1. 在 `queries/` 中创建或追加到日期文件
2. 格式：`## Q: 问题 \n**A:** 德鲁克式回答摘要 \n**涉及概念:** [[concept]]`
3. 更新 log.md

## Lint 规则

定期检查：
- 所有双链的目标文件是否存在
- index.md 是否与实际文件一致
- 是否有概念缺少"概念演进"表
- 是否有孤儿页面（无入链）
- 是否有矛盾（不同页面对同一事件的描述冲突）

## 命名规则

- 概念页：英文短横线命名（kebab-case），如 `decision-making.md`
- 著作页：英文短横线命名，如 `effective-executive.md`
- 对比页：概念A-vs-概念B，如 `effectiveness-vs-efficiency.md`
- 查询页：日期命名，如 `2026-04-19.md`
