# Changelog

**Copyright © 2024-2026 alvingoo (https://github.com/alvingoo).** Licensed under MIT. See [LICENSE](LICENSE).

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] - 2026-04-22

### Added
- **SKILL.md**: 主 Skill 文件，包含德鲁克思维框架完整定义
- **README.md**: 使用说明和部署指南
- **wiki/**: Wiki 知识网络
  - **concepts/**: 10个核心概念页
  - **books/**: 11本著作索引页
  - **comparisons/**: 6个心智模型对比页
  - **queries/**: 用户问答归档
  - **index.md**: Wiki 内容索引
  - **SCHEMA.md**: 格式规范

### 核心概念
1. 有效性 (Effectiveness)
2. 贡献思维 (Contribution)
3. 成果在外部 (Results Outside)
4. 人的长处 (Strengths)
5. 知识工作者 (Knowledge Worker)
6. 经营之道 (Theory of Business)
7. 有效决策 (Decision Making)
8. 掌握时间 (Time Management)
9. 要事优先 (Prioritization)
10. 创新 (Innovation)

### 蒸馏方法
- 基于 Karpathy LLM Wiki 方法论
- Raw → Wiki → Output 三层蒸馏
- 11本核心著作可追溯
