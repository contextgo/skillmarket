# Bili Md API 参考文档

本文档提供 Bili Md skill 所使用工具的详细 API 参考。

## yt-dlp

用于从哔哩哔哩下载视频和音频。

### 基本用法

```bash
yt-dlp [OPTIONS] URL
```

### 常用选项

| 选项 | 说明 |
|------|------|
| `--get-title` | 仅获取视频标题 |
| `--list-formats` | 列出所有可用格式 |
| `-f FORMAT` | 指定下载格式 |
| `-o TEMPLATE` | 输出文件名模板 |
| `--add-header NAME:VALUE` | 添加自定义 HTTP 头 |
| `--no-warnings` | 禁用警告信息 |

### 格式选择

B站音频格式选择优先级：
1. 首先尝试 `30280`（如果可用）
2. 回退到 `bestaudio[ext=m4a]/bestaudio`
3. 最终回退到 `bestaudio`

### Cookie 认证

B站需要认证才能下载，使用以下方式：

```bash
yt-dlp --add-header "Cookie: <cookie_string>" \
       --add-header "User-Agent: Mozilla/5.0 ..." \
       --add-header "Referer: https://www.bilibili.com" \
       -f "bestaudio[ext=m4a]/bestaudio" \
       -o "%(title)s.%(ext)s" \
       "<URL>"
```

### 输出模板变量

| 变量 | 说明 |
|------|------|
| `%(title)s` | 视频标题 |
| `%(ext)s` | 文件扩展名 |
| `%(id)s` | 视频 ID |
| `%(uploader)s` | 上传者名称 |

---

## Coli ASR

离线语音识别工具，使用 sensevoice 模型。

### 基本用法

```bash
coli asr <audio_file> [OPTIONS]
```

### 常用选项

| 选项 | 说明 |
|------|------|
| `--model MODEL` | 指定使用的模型（如 sensevoice） |
| `--language LANG` | 指定语言（可选，默认自动检测） |

### 环境变量

| 变量 | 说明 |
|------|------|
| `NODE_TLS_REJECT_UNAUTHORIZED=0` | 禁用 TLS 证书验证（仅在模型下载出现问题时使用） |

### 长音频处理

对于超过 15 分钟的音频，建议先分段：

```bash
# 使用 ffmpeg 分段
ffmpeg -i "input.m4a" -f segment -segment_time 600 -c copy "part_%03d.m4a"

# 分别转录每个分段
coli asr "part_000.m4a" --model sensevoice
coli asr "part_001.m4a" --model sensevoice
# ... 合并结果
```

### 模型管理

- 首次使用时自动下载模型（约 155 MB）
- 模型存储位置：`~/.coli/models/`
- 手动下载失败时可手动解压：`cd ~/.coli/models/ && tar -xjf *.tar.bz2`

---

## ffmpeg

音频处理工具，用于格式转换和分段。

### 音频信息查看

```bash
ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 <file>
```

### 音频分段

```bash
ffmpeg -i <input.m4a> -f segment -segment_time <seconds> -c copy <output_pattern>
```

参数说明：
- `-segment_time`：每个分段时长（秒）
- `-c copy`：直接复制流，不重新编码

### Windows 上的 ffmpeg

如果 ffmpeg 不在系统 PATH 中，可通过以下方式定位：

```python
winget_pkg_dir = os.path.expanduser(r"~\AppData\Local\Microsoft\WinGet\Packages")
# 查找 Gyan.FFmpeg 包中的 ffmpeg.exe
```

---

## 常见错误处理

### HTTP 412 错误

**问题**：B站返回 `HTTP Error 412: Precondition Failed`

**解决方案**：
1. 通过浏览器获取最新的 cookies
2. 使用 `--add-header Cookie:` 方式传递
3. 添加完整的 User-Agent 和 Referer 头

### SSL 证书错误

**问题**：下载模型时出现 SSL 证书验证失败

**解决方案**：
```bash
NODE_TLS_REJECT_UNAUTHORIZED=0 coli asr <file> --model sensevoice
```

### 内存不足错误

**问题**：长视频转录时内存不足

**解决方案**：
1. 使用 ffmpeg 将音频分成 10 分钟的分段
2. 分别转录每个分段
3. 合并转录结果

### 找不到 ffmpeg

**问题**：系统提示找不到 ffmpeg

**解决方案**：
1. 确认 ffmpeg 已安装并在 PATH 中
2. 或设置 `FFMPEG_BIN` 环境变量指向 ffmpeg 目录

---

## 文件名清理

视频标题可能包含特殊字符，下载前需要清理：

```python
safe_title = "".join(c for c in title if c not in r'\/:*?"<>|').strip()
```

需要移除的字符：`\ / : * ? " < > |`
