#!/usr/bin/env python3
"""
bili_to_md.py - 下载B站视频音频、转录为文字、总结保存为MD文件

用法:
    python bili_to_md.py <bilibili_url> [output_dir]

参数:
    bilibili_url  - B站视频URL（如 https://www.bilibili.com/video/BV1xxx...）
    output_dir    - 输出目录（可选，默认为当前目录）

依赖:
    - yt-dlp (pip install yt-dlp)
    - coli CLI (npm install -g @marswave/coli)
    - ffmpeg (需在PATH中，或通过FFMPEG_BIN环境变量指定)

环境变量:
    FFMPEG_BIN    - ffmpeg可执行文件所在目录路径（可选）
    SEGMENT_TIME  - 音频分段时长秒数（默认300，即5分钟）
"""

import sys
import os
import subprocess
import glob

# ── 1. 参数处理 ────────────────────────────────────────────────────────────────
if len(sys.argv) < 2:
    print("Usage: python bili_to_md.py <bilibili_url> [output_dir]")
    sys.exit(1)

url = sys.argv[1]
output_dir = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
os.makedirs(output_dir, exist_ok=True)

# ── 2. ffmpeg路径设置 ──────────────────────────────────────────────────────────
FFMPEG_BIN = os.environ.get("FFMPEG_BIN", "")
if not FFMPEG_BIN:
    winget_pkg_dir = os.path.expanduser(r"~\AppData\Local\Microsoft\WinGet\Packages")
    if os.path.isdir(winget_pkg_dir):
        for pkg in os.listdir(winget_pkg_dir):
            if pkg.startswith("Gyan.FFmpeg"):
                candidate = os.path.join(winget_pkg_dir, pkg)
                for root, dirs, files in os.walk(candidate):
                    if "ffmpeg.exe" in files:
                        FFMPEG_BIN = root
                        break
                if FFMPEG_BIN:
                    break

if FFMPEG_BIN:
    os.environ["PATH"] = FFMPEG_BIN + os.pathsep + os.environ.get("PATH", "")
    print(f"[ffmpeg] Using: {FFMPEG_BIN}")
else:
    print("[ffmpeg] Not found in WinGet, assuming it's in system PATH")

# ── 3. 获取视频标题 ────────────────────────────────────────────────────────────
print(f"\n[Step 1/4] Getting video title from: {url}")
result = subprocess.run(
    [sys.executable, "-m", "yt_dlp", "--get-title", url],
    capture_output=True,
    text=True,
    encoding="utf-8",
)
title = (
    result.stdout.strip().splitlines()[-1]
    if result.stdout.strip()
    else "bilibili_video"
)
safe_title = "".join(c for c in title if c not in r'\/:*?"<>|').strip()
print(f"[Step 1/4] Title: {safe_title}")

# ── 4. 下载音频 ────────────────────────────────────────────────────────────────
print(f"\n[Step 2/4] Downloading audio...")
audio_file = os.path.join(output_dir, f"{safe_title}.m4a")

fmt_result = subprocess.run(
    [sys.executable, "-m", "yt_dlp", "--list-formats", url],
    capture_output=True,
    text=True,
    encoding="utf-8",
)

audio_format_id = None
for line in fmt_result.stdout.splitlines():
    if "m4a" in line and "audio only" in line:
        parts = line.split()
        if parts:
            audio_format_id = parts[0]

download_cmd = [sys.executable, "-m", "yt_dlp"]
if audio_format_id:
    download_cmd += ["-f", audio_format_id]
else:
    download_cmd += ["-f", "bestaudio[ext=m4a]/bestaudio"]
download_cmd += ["-o", audio_file, url]

dl_result = subprocess.run(
    download_cmd, capture_output=True, text=True, encoding="utf-8"
)
if dl_result.returncode != 0:
    print("[ERROR] Download failed:")
    print(dl_result.stderr)
    sys.exit(1)

if not os.path.exists(audio_file):
    for f in os.listdir(output_dir):
        if f.startswith(safe_title[:20]) and f.endswith(
            (".m4a", ".mp3", ".webm", ".ogg")
        ):
            audio_file = os.path.join(output_dir, f)
            break

file_size_mb = os.path.getsize(audio_file) // (1024 * 1024)
print(f"[Step 2/4] Audio saved: {audio_file} ({file_size_mb} MB)")

# ── 5. 语音转文字 (Coli ASR) ──────────────────────────────────────────────────
print(f"\n[Step 3/4] Transcribing audio with Coli ASR (sensevoice)...")

# 对于长视频(>15分钟)，分段处理避免内存不足
SEGMENT_TIME = int(os.environ.get("SEGMENT_TIME", "300"))  # 默认5分钟

# 检查音频时长
probe_result = subprocess.run(
    [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        audio_file,
    ],
    capture_output=True,
    text=True,
)
try:
    duration = float(probe_result.stdout.strip())
    duration_min = duration / 60
    print(f"[Coli ASR] Audio duration: {duration_min:.1f} minutes")
except:
    duration_min = 0
    print("[Coli ASR] Could not determine duration, will try direct transcription")

transcript_text = ""

if duration_min > 15:
    # 长视频：分段处理
    print(f"[Coli ASR] Long video detected, splitting into {SEGMENT_TIME}s segments...")
    segment_pattern = os.path.join(output_dir, "segment_%03d.m4a")
    split_cmd = [
        "ffmpeg",
        "-i",
        audio_file,
        "-f",
        "segment",
        "-segment_time",
        str(SEGMENT_TIME),
        "-c",
        "copy",
        segment_pattern,
        "-y",
    ]
    subprocess.run(split_cmd, capture_output=True)

    segments = sorted(glob.glob(os.path.join(output_dir, "segment_*.m4a")))
    print(f"[Coli ASR] Created {len(segments)} segments")

    for i, seg in enumerate(segments):
        print(f"[Coli ASR] Transcribing segment {i + 1}/{len(segments)}...")
        env = os.environ.copy()
        env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
        result = subprocess.run(
            ["coli", "asr", seg, "--model", "sensevoice"],
            capture_output=True,
            text=True,
            env=env,
        )
        transcript_text += result.stdout.strip() + "\n"

    # 清理分段文件
    for seg in segments:
        os.remove(seg)
    print("[Coli ASR] Segment files cleaned up")
else:
    # 短视频：直接处理
    print("[Coli ASR] Transcribing directly...")
    env = os.environ.copy()
    env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
    result = subprocess.run(
        ["coli", "asr", audio_file, "--model", "sensevoice"],
        capture_output=True,
        text=True,
        env=env,
    )
    transcript_text = result.stdout.strip()

print(f"[Step 3/4] Transcription done: {len(transcript_text)} characters")

# ── 6. 保存转录文本 ────────────────────────────────────────────────────────────
transcript_file = os.path.join(output_dir, f"{safe_title}_transcript.txt")
with open(transcript_file, "w", encoding="utf-8") as f:
    f.write(transcript_text)
print(f"[Step 3/4] Raw transcript saved: {transcript_file}")

# ── 7. 输出关键信息供AI整理 ───────────────────────────────────────────────────
print(f"\n[Step 4/4] All done! Summary for AI:")
print(f"  Title       : {title}")
print(f"  Audio file  : {audio_file}")
print(f"  Transcript  : {transcript_file}")
print(f"  Output dir  : {output_dir}")
print(f"\n{'=' * 60}")
print("TRANSCRIPT_CONTENT_START")
print(transcript_text)
print("TRANSCRIPT_CONTENT_END")
print(f"{'=' * 60}")
print(f"SAFE_TITLE={safe_title}")
print(f"OUTPUT_DIR={output_dir}")

# ── 8. 清理临时文件 ────────────────────────────────────────────────────────────
print(f"\n[Cleanup] Removing temporary files...")
if os.path.exists(audio_file):
    os.remove(audio_file)
    print(f"[Cleanup] Deleted: {audio_file}")
if os.path.exists(transcript_file):
    os.remove(transcript_file)
    print(f"[Cleanup] Deleted: {transcript_file}")

# 清理可能残留的分段文件（使用 os.listdir 而不是 glob，避免 Windows 路径编码问题）
for f in os.listdir(output_dir):
    if f.startswith("segment_") and f.endswith(".m4a"):
        seg_path = os.path.join(output_dir, f)
        os.remove(seg_path)
        print(f"[Cleanup] Deleted: {seg_path}")

print("[Cleanup] Done! Only the Markdown file remains.")
