#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅设备方案对比工具
支持不同材质、规格、配置的方案对比分析
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class Tier(Enum):
    HIGH = "high"
    MID = "mid"
    LOW = "low"


@dataclass
class MaterialOption:
    """材质方案"""
    name: str
    price: float
    lifespan: int  # 设计寿命（年）
    maintenance_cost: float  # 年维护成本占比
    maintenance_interval: int  # 维护周期（年）
    appearance: int  # 美观度 1-5星
    durability: int  # 耐久性 1-5星
    applicable_scene: str  # 适用场景


@dataclass
class ComparisonResult:
    """对比结果"""
    initial_cost: float
    lifespan: int
    annual_cost: float
    total_maintenance: float
    aesthetics: int
    durability: int
    applicable_scene: str
    advantages: List[str]
    disadvantages: List[str]


class SchemeComparator:
    """方案对比器"""
    
    def __init__(self):
        # 预设材质方案库
        self.material_library = {
            # 滑梯材质方案
            "滑梯": {
                "304不锈钢": MaterialOption(
                    name="304不锈钢方案",
                    price=1.0,
                    lifespan=15,
                    maintenance_cost=0.03,
                    maintenance_interval=3,
                    appearance=5,
                    durability=5,
                    applicable_scene="长期运营景区、高端项目"
                ),
                "201不锈钢": MaterialOption(
                    name="201不锈钢方案",
                    price=0.7,
                    lifespan=10,
                    maintenance_cost=0.05,
                    maintenance_interval=2,
                    appearance=4,
                    durability=4,
                    applicable_scene="中期投资项目"
                ),
                "热镀锌": MaterialOption(
                    name="热镀锌方案",
                    price=0.5,
                    lifespan=8,
                    maintenance_cost=0.06,
                    maintenance_interval=2,
                    appearance=3,
                    durability=3,
                    applicable_scene="经济型项目、预算有限"
                ),
                "玻璃钢": MaterialOption(
                    name="玻璃钢方案",
                    price=0.6,
                    lifespan=8,
                    maintenance_cost=0.05,
                    maintenance_interval=2,
                    appearance=4,
                    durability=3,
                    applicable_scene="造型要求高的项目"
                ),
            },
            # 攀爬架材质方案
            "攀爬架": {
                "304不锈钢": MaterialOption(
                    name="304不锈钢方案",
                    price=1.0,
                    lifespan=15,
                    maintenance_cost=0.02,
                    maintenance_interval=4,
                    appearance=5,
                    durability=5,
                    applicable_scene="高端项目、潮湿环境"
                ),
                "热镀锌": MaterialOption(
                    name="热镀锌方案",
                    price=0.55,
                    lifespan=10,
                    maintenance_cost=0.05,
                    maintenance_interval=2,
                    appearance=3,
                    durability=4,
                    applicable_scene="一般户外项目"
                ),
                "铝合金": MaterialOption(
                    name="铝合金方案",
                    price=0.85,
                    lifespan=12,
                    maintenance_cost=0.02,
                    maintenance_interval=3,
                    appearance=4,
                    durability=4,
                    applicable_scene="轻量化需求项目"
                ),
            },
            # 观景台材质方案
            "观景台": {
                "三层夹胶玻璃": MaterialOption(
                    name="三层夹胶玻璃方案",
                    price=1.0,
                    lifespan=20,
                    maintenance_cost=0.02,
                    maintenance_interval=3,
                    appearance=5,
                    durability=5,
                    applicable_scene="高空观景台、玻璃桥"
                ),
                "双层夹胶玻璃": MaterialOption(
                    name="双层夹胶玻璃方案",
                    price=0.7,
                    lifespan=15,
                    maintenance_cost=0.03,
                    maintenance_interval=2,
                    appearance=4,
                    durability=4,
                    applicable_scene="普通观景台"
                ),
                "钢化玻璃+格栅": MaterialOption(
                    name="钢化玻璃+格栅方案",
                    price=0.5,
                    lifespan=12,
                    maintenance_cost=0.04,
                    maintenance_interval=2,
                    appearance=3,
                    durability=3,
                    applicable_scene="经济型观景"
                ),
            },
        }
    
    def calculate_annual_cost(self, option: MaterialOption, base_price: float) -> Dict:
        """计算年均成本"""
        initial = base_price * option.price
        lifespan = option.lifespan
        
        # 计算维护总成本
        maintenance_periods = lifespan // option.maintenance_interval
        maintenance_total = initial * option.maintenance_cost * maintenance_periods
        
        # 计算年均成本
        annual_cost = (initial + maintenance_total) / lifespan
        
        return {
            "initial_cost": initial,
            "lifespan": lifespan,
            "maintenance_total": maintenance_total,
            "annual_cost": annual_cost,
            "total_cost": initial + maintenance_total,
        }
    
    def compare_schemes(
        self,
        device_type: str,
        base_price: float,
        scheme_names: List[str]
    ) -> Dict:
        """对比多个方案"""
        if device_type not in self.material_library:
            return {"error": f"未支持的设备类型: {device_type}"}
        
        library = self.material_library[device_type]
        results = {}
        
        for scheme_name in scheme_names:
            if scheme_name not in library:
                continue
            
            option = library[scheme_name]
            calc_result = self.calculate_annual_cost(option, base_price)
            
            # 生成优缺点
            advantages = []
            disadvantages = []
            
            if option.durability >= 4:
                advantages.append("耐久性好，使用寿命长")
            if option.maintenance_cost < 0.04:
                advantages.append("维护成本低")
            if option.appearance >= 4:
                advantages.append("外观美观，提升档次")
            if option.price <= 0.6:
                advantages.append("初始投资成本低")
            
            if option.maintenance_cost >= 0.05:
                disadvantages.append("维护成本相对较高")
            if option.price >= 0.9:
                disadvantages.append("初始投资较高")
            if option.lifespan < 10:
                disadvantages.append("设计寿命相对较短")
            
            results[scheme_name] = {
                "option": option,
                "calculation": calc_result,
                "advantages": advantages,
                "disadvantages": disadvantages,
            }
        
        # 找出最优方案
        if results:
            best_scheme = min(
                results.keys(),
                key=lambda x: results[x]["calculation"]["annual_cost"]
            )
        else:
            best_scheme = None
        
        return {
            "device_type": device_type,
            "base_price": base_price,
            "schemes": results,
            "best_scheme": best_scheme,
        }
    
    def generate_comparison_report(
        self,
        device_type: str,
        base_price: float,
        scheme_names: List[str],
        device_name: str = ""
    ) -> str:
        """生成方案对比报告"""
        comparison = self.compare_schemes(device_type, base_price, scheme_names)
        
        if "error" in comparison:
            return f"❌ 错误: {comparison['error']}"
        
        report = f"""📊 **方案对比分析报告**

---

## 【对比项目】
- **设备类型**：{device_name or device_type}
- **基础价格**：{base_price:.0f}元
- **对比方案**：{len(scheme_names)}个

---

## 【方案对比表】

| 对比项 | {' | '.join([comparison['schemes'][s]['option'].name for s in scheme_names])} |
|:---|{':---:' * len(scheme_names)}|
"""
        
        # 添加对比数据
        for scheme_name in scheme_names:
            if scheme_name not in comparison['schemes']:
                continue
        
        scheme_data = comparison['schemes']
        
        # 初始造价
        report += "| 初始造价 | " + " | ".join([
            f"{scheme_data[s]['calculation']['initial_cost']:.0f}元" if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 设计寿命
        report += "| 设计寿命 | " + " | ".join([
            f"{scheme_data[s]['option'].lifespan}年" if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 年均成本
        report += "| 年均成本 | " + " | ".join([
            f"{scheme_data[s]['calculation']['annual_cost']:.0f}元/年" if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 维护总成本
        report += "| 维护总成本 | " + " | ".join([
            f"{scheme_data[s]['calculation']['maintenance_total']:.0f}元" if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 总费用（寿命周期）
        report += "| 生命周期总费用 | " + " | ".join([
            f"{scheme_data[s]['calculation']['total_cost']:.0f}元" if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 美观度
        report += "| 美观度 | " + " | ".join([
            f"⭐" * scheme_data[s]['option'].appearance if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 耐久性
        report += "| 耐久性 | " + " | ".join([
            f"⭐" * scheme_data[s]['option'].durability if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        # 适用场景
        report += "| 适用场景 | " + " | ".join([
            scheme_data[s]['option'].applicable_scene if s in scheme_data else "-"
            for s in scheme_names
        ]) + " |\n"
        
        report += "\n---\n\n## 【推荐方案】\n\n"
        
        # 最优方案推荐
        if comparison['best_scheme']:
            best = comparison['schemes'][comparison['best_scheme']]
            report += f"**🏆 最优性价比方案：{best['option'].name}**\n\n"
            report += f"- 初始投资：{best['calculation']['initial_cost']:.0f}元\n"
            report += f"- 设计寿命：{best['option'].lifespan}年\n"
            report += f"- 年均成本：{best['calculation']['annual_cost']:.0f}元/年\n"
            report += f"- 适用场景：{best['option'].applicable_scene}\n"
        
        report += "\n---\n\n## 【各方案优缺点】\n\n"
        
        for scheme_name in scheme_names:
            if scheme_name not in scheme_data:
                continue
            scheme = scheme_data[scheme_name]
            report += f"### {scheme['option'].name}\n\n"
            
            if scheme['advantages']:
                report += "**优点：**\n"
                for adv in scheme['advantages']:
                    report += f"- ✅ {adv}\n"
                report += "\n"
            
            if scheme['disadvantages']:
                report += "**缺点：**\n"
                for dis in scheme['disadvantages']:
                    report += f"- ⚠️ {dis}\n"
                report += "\n"
        
        report += """---

## 【选择建议】

| 需求类型 | 推荐方案 | 理由 |
|:---|:---|:---|
| 长期运营(5年以上) | 304不锈钢 | 耐久性最佳，年均成本最低 |
| 中期投资(3-5年) | 201不锈钢 | 性价比平衡 |
| 短期项目/预算有限 | 热镀锌/经济方案 | 初始投入小 |
| 高端定位/地标项目 | 304不锈钢/三层夹胶玻璃 | 品质感强 |
| 潮湿/海边环境 | 304不锈钢 | 耐腐蚀性最佳 |

---

*本对比基于行业经验和标准参数，实际选择请结合具体项目情况*
"""
        
        return report


class VendorComparator:
    """厂家比价器"""
    
    def __init__(self):
        self.warranty_mapping = {
            "1年": 0.8,
            "2年": 1.0,
            "3年": 1.1,
            "5年": 1.2,
        }
    
    def compare_vendors(self, vendors: List[Dict]) -> Dict:
        """
        对比多家供应商报价
        
        Args:
            vendors: [{"name": "厂家A", "price": 80000, "material": "304不锈钢", 
                      "warranty": "3年", "delivery": "30天", "shipping": "含"}]
        """
        if len(vendors) < 2:
            return {"error": "至少需要2家供应商进行对比"}
        
        results = []
        
        for vendor in vendors:
            score = 100
            
            # 价格得分（越低越好）
            price_factor = 1 + (vendor.get("price", 0) / 100000)
            price_score = 100 / price_factor
            
            # 质保得分
            warranty_years = vendor.get("warranty", "2年")
            warranty_factor = self.warranty_mapping.get(warranty_years, 1.0)
            warranty_score = warranty_factor * 20
            
            # 材质得分（简单估算）
            material = vendor.get("material", "")
            if "304" in material:
                material_score = 30
            elif "201" in material:
                material_score = 25
            elif "镀锌" in material:
                material_score = 20
            else:
                material_score = 15
            
            # 综合得分
            total_score = price_score * 0.5 + warranty_score * 0.25 + material_score * 0.25
            
            results.append({
                "name": vendor["name"],
                "price": vendor["price"],
                "material": material,
                "warranty": warranty_years,
                "delivery": vendor.get("delivery", ""),
                "shipping": vendor.get("shipping", ""),
                "price_score": price_score,
                "warranty_score": warranty_score,
                "material_score": material_score,
                "total_score": total_score,
            })
        
        # 排序
        results.sort(key=lambda x: x["total_score"], reverse=True)
        
        # 找出最优
        best = results[0] if results else None
        
        return {
            "vendors": results,
            "best_vendor": best["name"] if best else None,
            "best_reason": self._get_best_reason(best) if best else "",
        }
    
    def _get_best_reason(self, vendor: Dict) -> str:
        """获取最优原因"""
        reasons = []
        
        if vendor:
            # 找最低价
            min_price = min(v.get("price", 0) for v in [vendor])
            if vendor["price"] == min_price:
                reasons.append("价格最优")
            
            # 找最高分
            if vendor.get("total_score", 0) >= 85:
                reasons.append("综合得分最高")
            
            # 质保优势
            if "5年" in vendor.get("warranty", ""):
                reasons.append("质保期限最长")
            
            # 材质优势
            if "304" in vendor.get("material", ""):
                reasons.append("材质最优")
        
        return "、".join(reasons) if reasons else "综合最优"
    
    def generate_vendor_report(self, vendors: List[Dict]) -> str:
        """生成厂家比价报告"""
        comparison = self.compare_vendors(vendors)
        
        if "error" in comparison:
            return f"❌ 错误: {comparison['error']}"
        
        report = """📋 **厂家报价对比报告**

---

## 【对比总览】

| 供应商 | 报价 | 材质 | 质保 | 交货期 | 运费 | 综合得分 |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
"""
        
        for vendor in comparison["vendors"]:
            medal = "🥇" if vendor == comparison["vendors"][0] else (
                "🥈" if vendor == comparison["vendors"][1] else "🥉"
            ) if len(comparison["vendors"]) > 2 else ""
            
            report += f"| {medal} {vendor['name']} | {vendor['price']/10000:.1f}万 | {vendor['material']} | {vendor['warranty']} | {vendor['delivery']} | {vendor['shipping']} | {vendor['total_score']:.1f}分 |\n"
        
        report += "\n---\n\n## 【分项对比】\n\n"
        
        report += "| 对比项 | "
        report += " | ".join([v["name"] for v in comparison["vendors"]]) + " |\n"
        report += "|:---|" + ":---:" * len(comparison["vendors"]) + "|\n"
        
        # 价格对比
        report += "| 报价(万) | " + " | ".join([f"{v['price']/10000:.1f}" for v in comparison["vendors"]]) + " |\n"
        
        # 质保对比
        report += "| 质保期 | " + " | ".join([v["warranty"] for v in comparison["vendors"]]) + " |\n"
        
        # 交货期对比
        report += "| 交货期 | " + " | ".join([v["delivery"] for v in comparison["vendors"]]) + " |\n"
        
        # 运费对比
        report += "| 运费 | " + " | ".join([v["shipping"] for v in comparison["vendors"]]) + " |\n"
        
        # 价格得分
        report += "| 价格得分 | " + " | ".join([f"{v['price_score']:.1f}" for v in comparison["vendors"]]) + " |\n"
        
        # 质保得分
        report += "| 质保得分 | " + " | ".join([f"{v['warranty_score']:.1f}" for v in comparison["vendors"]]) + " |\n"
        
        # 材质得分
        report += "| 材质得分 | " + " | ".join([f"{v['material_score']:.1f}" for v in comparison["vendors"]]) + " |\n"
        
        report += "\n---\n\n"
        
        # 综合推荐
        if comparison["best_vendor"]:
            report += f"## 【综合推荐】\n\n"
            report += f"**🏆 推荐供应商：{comparison['best_vendor']}**\n\n"
            report += f"**推荐理由：** {comparison['best_reason']}\n\n"
        
        report += """---

## 【选择建议】

1. **追求品质**：选择综合得分最高、质保最长的供应商
2. **追求低价**：选择报价最低的供应商（注意对比材质和质保）
3. **综合平衡**：选择价格和品质平衡的供应商
4. **长期合作**：建议实地考察后确定，建立长期合作关系

---

⚠️ **注意事项**
- 本对比仅供参考，实际选择请综合考虑
- 建议要求供应商提供样品或参观案例
- 签订合同前明确各项条款和违约责任
"""
        
        return report


# ============================================================
# 主函数示例
# ============================================================
if __name__ == "__main__":
    # 示例1：材质方案对比
    print("=" * 60)
    print("示例1：滑梯材质方案对比")
    print("=" * 60)
    
    comparator = SchemeComparator()
    report = comparator.generate_comparison_report(
        device_type="滑梯",
        base_price=120000,  # 基础价格12万
        scheme_names=["304不锈钢", "201不锈钢", "热镀锌"],
        device_name="不锈钢组合滑梯"
    )
    print(report)
    
    # 示例2：厂家比价
    print("\n" + "=" * 60)
    print("示例2：厂家报价对比")
    print("=" * 60)
    
    vendor_comparator = VendorComparator()
    vendors = [
        {"name": "厂家A", "price": 80000, "material": "304不锈钢", "warranty": "3年", "delivery": "30天", "shipping": "含"},
        {"name": "厂家B", "price": 75000, "material": "201不锈钢", "warranty": "2年", "delivery": "25天", "shipping": "到付"},
        {"name": "厂家C", "price": 90000, "material": "304不锈钢", "warranty": "5年", "delivery": "45天", "shipping": "含"},
    ]
    vendor_report = vendor_comparator.generate_vendor_report(vendors)
    print(vendor_report)
