#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅设备报告导出模板
生成Excel多Sheet报告
"""

from typing import Dict, List, Optional
from datetime import datetime


class ReportExporter:
    """报告导出器"""
    
    def __init__(self):
        self.report_date = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    def generate_excel_template(self) -> Dict:
        """生成Excel模板结构"""
        return {
            "sheets": [
                {
                    "name": "总览",
                    "headers": ["项目", "内容"],
                    "data": []
                },
                {
                    "name": "三档对比",
                    "headers": ["档位", "材质配置", "总价", "与高档差价"],
                    "data": []
                },
                {
                    "name": "分项明细",
                    "headers": ["项目", "金额", "占比", "说明"],
                    "data": []
                },
                {
                    "name": "批量汇总",
                    "headers": ["序号", "设备名称", "规格参数", "高档", "中档", "经济"],
                    "data": []
                },
                {
                    "name": "材质配置",
                    "headers": ["档位", "主体材质", "表面处理", "电气配置", "安全设施"],
                    "data": []
                },
                {
                    "name": "性价比分析",
                    "headers": ["方案", "初始成本", "设计寿命", "年均成本", "维护成本"],
                    "data": []
                },
                {
                    "name": "注意事项",
                    "headers": ["类别", "说明"],
                    "data": []
                }
            ]
        }
    
    def populate_overview_sheet(
        self,
        sheet: Dict,
        device_name: str,
        device_type: str,
        specs: str,
        material: str,
        tier_prices: Dict
    ):
        """填充总览Sheet"""
        sheet["data"] = [
            ["设备名称", device_name],
            ["设备类型", device_type],
            ["规格参数", specs],
            ["材质配置", material],
            ["", ""],
            ["【三档造价汇总】", ""],
            ["高档方案", tier_prices.get("high", {}).get("formatted", "-")],
            ["中档方案", tier_prices.get("mid", {}).get("formatted", "-")],
            ["经济方案", tier_prices.get("low", {}).get("formatted", "-")],
            ["", ""],
            ["【推荐档位】", "中档方案（性价比最优）"],
            ["报告生成时间", self.report_date],
            ["有效期", "30天"],
        ]
    
    def populate_three_tier_sheet(
        self,
        sheet: Dict,
        tier_data: List[Dict]
    ):
        """填充三档对比Sheet"""
        sheet["data"] = [
            ["档位", "材质配置", "总造价", "与高档差价", "适用场景"],
        ]
        
        tier_config = {
            "high": ("高档", "优质材质全套配置", "长期高端项目"),
            "mid": ("中档", "标准配置性价比最优", "大多数投资项目"),
            "low": ("经济", "基础材质预算友好", "短期/预算有限项目"),
        }
        
        base_price = None
        for tier in ["high", "mid", "low"]:
            if tier in tier_data and tier_data[tier]:
                if base_price is None:
                    base_price = tier_data[tier].get("price", 0)
                diff = tier_data[tier].get("price", 0) - base_price
                name, config, scene = tier_config.get(tier, (tier, "", ""))
                sheet["data"].append([
                    f"{name}",
                    config,
                    tier_data[tier].get("formatted", "-"),
                    f"{diff/10000:.1f}万" if diff else "基准",
                    scene
                ])
    
    def populate_breakdown_sheet(
        self,
        sheet: Dict,
        breakdown_data: Dict,
        selected_tier: str = "mid"
    ):
        """填充分项明细Sheet"""
        sheet["data"] = [
            ["项目", "金额", "占比", "说明"],
        ]
        
        for key, value in breakdown_data.items():
            if key.startswith("_") or not isinstance(value, dict):
                continue
            sheet["data"].append([
                key,
                value.get("formatted", "-"),
                f"{value.get('ratio', 0):.0f}%",
                value.get("description", "")
            ])
        
        # 添加合计行
        if "_total" in breakdown_data:
            total = breakdown_data["_total"]
            sheet["data"].append([
                "合计",
                total.get("formatted", "-"),
                "100%",
                ""
            ])
    
    def populate_batch_summary_sheet(
        self,
        sheet: Dict,
        batch_data: Dict
    ):
        """填充批量汇总Sheet"""
        sheet["data"] = [
            ["序号", "设备名称", "规格参数", "高档", "中档", "经济"],
        ]
        
        for item in batch_data.get("items", []):
            sheet["data"].append([
                item.get("index", ""),
                item.get("name", ""),
                f"{item.get('quantity', 0)}{item.get('unit', '')}",
                item.get("prices", {}).get("high", "-"),
                item.get("prices", {}).get("mid", "-"),
                item.get("prices", {}).get("low", "-"),
            ])
        
        # 添加汇总行
        summary = batch_data.get("summary", {})
        sheet["data"].append([
            "",
            "【汇总】",
            "",
            summary.get("high", {}).get("formatted", "-"),
            summary.get("mid", {}).get("formatted", "-"),
            summary.get("low", {}).get("formatted", "-"),
        ])
    
    def populate_material_config_sheet(
        self,
        sheet: Dict,
        tier: str = "mid"
    ):
        """填充材质配置Sheet"""
        configs = {
            "high": {
                "主体材质": "304不锈钢（食品级）",
                "表面处理": "氟碳喷涂/电泳处理",
                "电气配置": "变频控制+智能保护+彩灯",
                "安全设施": "高强度护栏+防撞垫+安全网",
            },
            "mid": {
                "主体材质": "镀锌管+不锈钢滑道面",
                "表面处理": "聚酯粉末喷涂",
                "电气配置": "常规控制+基本照明",
                "安全设施": "标准护栏+防护垫",
            },
            "low": {
                "主体材质": "热镀锌钢管全套",
                "表面处理": "普通防锈漆",
                "电气配置": "简单开关控制",
                "安全设施": "基础护栏",
            }
        }
        
        config = configs.get(tier, configs["mid"])
        sheet["data"] = [
            ["档位", "主体材质", "表面处理", "电气配置", "安全设施"],
            ["高档", configs["high"]["主体材质"], configs["high"]["表面处理"], 
             configs["high"]["电气配置"], configs["high"]["安全设施"]],
            ["中档", configs["mid"]["主体材质"], configs["mid"]["表面处理"],
             configs["mid"]["电气配置"], configs["mid"]["安全设施"]],
            ["经济", configs["low"]["主体材质"], configs["low"]["表面处理"],
             configs["low"]["电气配置"], configs["low"]["安全设施"]],
        ]
    
    def populate_analysis_sheet(
        self,
        sheet: Dict,
        analysis_data: Dict
    ):
        """填充性价比分析Sheet"""
        sheet["data"] = [
            ["方案", "初始成本", "设计寿命(年)", "年均成本", "维护成本占比", "综合评价"],
        ]
        
        for scheme in analysis_data.get("schemes", []):
            sheet["data"].append([
                scheme.get("name", ""),
                scheme.get("initial_cost", ""),
                scheme.get("lifespan", ""),
                scheme.get("annual_cost", ""),
                scheme.get("maintenance_ratio", ""),
                scheme.get("evaluation", ""),
            ])
    
    def populate_notes_sheet(self, sheet: Dict):
        """填充注意事项Sheet"""
        sheet["data"] = [
            ["类别", "说明"],
            ["", "【本估算包含费用】"],
            ["主体材料", "主要结构材料（钢管、型钢、玻璃等）"],
            ["辅助材料", "配件、紧固件、连接件、密封件"],
            ["加工制造", "切割、焊接、组装、成型等加工费"],
            ["表面处理", "喷涂、镀锌、抛光、电泳等处理"],
            ["电气系统", "电机、控制柜、线缆、照明灯具"],
            ["安全设施", "护栏、防护网、软垫、安全标识"],
            ["检测认证", "第三方检测、特检院验收"],
            ["", ""],
            ["", "【本估算不含费用】"],
            ["运输费用", "按运输距离另计"],
            ["安装费用", "现场安装人工费另计"],
            ["基础工程", "土建、混凝土基础另计"],
            ["配套设施", "护栏围网等按需另计"],
            ["税费", "按国家政策另行计算"],
            ["", ""],
            ["", "【重要提示】"],
            ["有效期", "本估算有效期为30天"],
            ["价格波动", "原材料价格波动会影响最终报价"],
            ["锁定价格", "建议在有效期内锁定价格或签订合同"],
            ["生产周期", "大型设备需预留30-90天生产周期"],
            ["以确认准", "实际报价以厂家确认为准"],
            ["多方询价", "建议多方询价对比后再做决策"],
        ]
    
    def generate_full_report(
        self,
        device_info: Dict,
        tier_prices: Dict,
        breakdown_data: Dict,
        batch_data: Optional[Dict] = None,
        analysis_data: Optional[Dict] = None
    ) -> Dict:
        """生成完整报告"""
        template = self.generate_excel_template()
        
        # 填充各Sheet
        for sheet in template["sheets"]:
            if sheet["name"] == "总览":
                self.populate_overview_sheet(
                    sheet,
                    device_info.get("name", ""),
                    device_info.get("type", ""),
                    device_info.get("specs", ""),
                    device_info.get("material", ""),
                    tier_prices
                )
            elif sheet["name"] == "三档对比":
                self.populate_three_tier_sheet(sheet, tier_prices)
            elif sheet["name"] == "分项明细":
                self.populate_breakdown_sheet(sheet, breakdown_data)
            elif sheet["name"] == "批量汇总" and batch_data:
                self.populate_batch_summary_sheet(sheet, batch_data)
            elif sheet["name"] == "材质配置":
                self.populate_material_config_sheet(sheet)
            elif sheet["name"] == "性价比分析" and analysis_data:
                self.populate_analysis_sheet(sheet, analysis_data)
            elif sheet["name"] == "注意事项":
                self.populate_notes_sheet(sheet)
        
        return template
    
    def export_to_csv_format(self, report: Dict) -> str:
        """导出为CSV格式（用于演示）"""
        csv_output = ""
        
        for sheet in report["sheets"]:
            csv_output += f"\n=== {sheet['name']} ===\n"
            
            # 写入表头
            if sheet["headers"]:
                csv_output += ",".join(str(h) for h in sheet["headers"]) + "\n"
            
            # 写入数据
            for row in sheet["data"]:
                csv_output += ",".join(str(cell) for cell in row) + "\n"
        
        return csv_output


class MarkdownReportGenerator:
    """Markdown报告生成器"""
    
    def __init__(self):
        self.report_date = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    def generate_markdown_report(
        self,
        device_info: Dict,
        tier_prices: Dict,
        breakdown_data: Dict,
        recommendations: Optional[List[str]] = None
    ) -> str:
        """生成Markdown格式报告"""
        
        report = f"""# 🎢 游乐文旅造价通 - 造价估算报告

---

## 一、设备信息

| 项目 | 内容 |
|:---|:---|
| 设备名称 | {device_info.get('name', '-')} |
| 设备类型 | {device_info.get('type', '-')} |
| 规格参数 | {device_info.get('specs', '-')} |
| 材质配置 | {device_info.get('material', '-')} |
| 估算时间 | {self.report_date} |
| 有效期 | 30天 |

---

## 二、三档造价对比

| 档位 | 材质配置 | 总造价 | 与高档差价 | 推荐指数 |
|:---:|:---|:---:|:---:|:---:|
| 🥇 高档 | 304不锈钢全套配置 | {tier_prices.get('high', {}).get('formatted', '-')} | 基准 | ⭐⭐⭐⭐ |
| 🥈 中档 | 镀锌管+不锈钢面 | {tier_prices.get('mid', {}).get('formatted', '-')} | {tier_prices.get('mid', {}).get('diff', '-')} | ⭐⭐⭐⭐⭐ |
| 🥉 经济 | 热镀锌管全套 | {tier_prices.get('low', {}).get('formatted', '-')} | {tier_prices.get('low', {}).get('diff', '-')} | ⭐⭐⭐ |

---

## 三、中档方案分项明细（推荐方案）

| 项目 | 金额 | 占比 | 明细说明 |
|:---|:---:|:---:|:---|
"""
        
        for key, value in breakdown_data.items():
            if key.startswith("_") or not isinstance(value, dict):
                continue
            report += f"| {key} | {value.get('formatted', '-')} | {value.get('ratio', 0):.0f}% | {value.get('description', '')} |\n"
        
        if "_total" in breakdown_data:
            total = breakdown_data["_total"]
            report += f"| **合计** | **{total.get('formatted', '-')}** | **100%** | - |\n"
        
        report += """
---

## 四、推荐建议

"""
        
        recommendations = recommendations or [
            "✅ **性价比最优**：中档方案（年均成本最低）",
            "✅ **追求品质**：高档方案（外观耐久最佳）",
            "⚠️ **经济方案**：适合短期项目或预算紧张的情况",
        ]
        
        for rec in recommendations:
            report += f"- {rec}\n"
        
        report += """
---

## 五、注意事项

### 5.1 本估算包含费用

- ✅ 设备主体费用
- ✅ 辅助材料和配件
- ✅ 加工制造费用
- ✅ 表面处理费用
- ✅ 电气系统（选配）
- ✅ 安全设施
- ✅ 第三方检测认证

### 5.2 本估算不含费用

- ❌ 运输费用（按距离另计）
- ❌ 安装费用（现场安装费）
- ❌ 基础工程（土建、混凝土基础）
- ❌ 配套设施（护栏围网等按需另计）
- ❌ 税费（按政策另行计算）

### 5.3 重要提示

> ⚠️ **本估算有效期为30天**，原材料价格波动会影响最终报价，建议在有效期内锁定价格或签订合同。

---

## 六、报告说明

| 项目 | 说明 |
|:---|:---|
| 数据来源 | 行业调研数据及厂家报价参考 |
| 计算方式 | 基于标准配置和常规规格计算 |
| 实际报价 | 以厂家正式报价为准 |
| 建议操作 | 多方询价对比，综合评估后决策 |

---

*本报告由游乐文旅造价通自动生成*
*生成时间：{self.report_date}*
"""
        
        return report


# ============================================================
# 主函数示例
# ============================================================
if __name__ == "__main__":
    # 示例：生成完整报告
    print("=" * 60)
    print("示例：生成造价估算报告")
    print("=" * 60)
    
    # 设备信息
    device_info = {
        "name": "不锈钢组合滑梯",
        "type": "无动力设备",
        "specs": "高度3.5m，长度12m，面积45㎡",
        "material": "304不锈钢"
    }
    
    # 三档价格
    tier_prices = {
        "high": {"formatted": "9.3万", "price": 93000, "diff": "基准"},
        "mid": {"formatted": "7.2万", "price": 72000, "diff": "-2.1万"},
        "low": {"formatted": "5.8万", "price": 58000, "diff": "-3.5万"},
    }
    
    # 分项明细
    breakdown_data = {
        "主体材料": {"formatted": "2.6万", "ratio": 36, "description": "304不锈钢管材"},
        "辅助材料": {"formatted": "0.7万", "ratio": 10, "description": "紧固件、连接件"},
        "加工制造": {"formatted": "1.6万", "ratio": 22, "description": "焊接、组装"},
        "表面处理": {"formatted": "0.3万", "ratio": 4, "description": "抛光、喷涂"},
        "电气系统": {"formatted": "1.0万", "ratio": 14, "description": "照明、控制"},
        "安全设施": {"formatted": "0.5万", "ratio": 7, "description": "护栏、防护"},
        "检测认证": {"formatted": "0.3万", "ratio": 4, "description": "第三方检测"},
        "其他预留": {"formatted": "0.2万", "ratio": 3, "description": "包装、运输"},
        "_total": {"formatted": "7.2万", "ratio": 100}
    }
    
    # 生成Markdown报告
    generator = MarkdownReportGenerator()
    report = generator.generate_markdown_report(
        device_info, tier_prices, breakdown_data
    )
    print(report)
    
    # 生成Excel模板结构
    print("\n" + "=" * 60)
    print("Excel模板结构预览")
    print("=" * 60)
    
    exporter = ReportExporter()
    excel_template = exporter.generate_full_report(
        device_info, tier_prices, breakdown_data
    )
    
    for sheet in excel_template["sheets"]:
        print(f"\n【{sheet['name']}】")
        if sheet["headers"]:
            print("表头:", sheet["headers"])
        print(f"数据行数: {len(sheet['data'])}")
