#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅设备造价计算器
支持多种设备类型的三档价格计算和分项明细输出
"""

import json
from typing import Dict, List, Optional, Tuple

# ============================================================
# 基础单价库（元/单位）
# ============================================================
BASE_PRICES = {
    # 无动力设备 - 滑梯系列
    "不锈钢滑梯_单道": {"unit": "米", "high": 1500, "mid": 1000, "low": 600},
    "不锈钢滑梯_螺旋": {"unit": "米", "high": 2000, "mid": 1300, "low": 800},
    "不锈钢滑梯_组合": {"unit": "米", "high": 2500, "mid": 1500, "low": 900},
    "镀锌滑梯_单道": {"unit": "米", "high": 800, "mid": 550, "low": 350},
    "镀锌滑梯_组合": {"unit": "米", "high": 1000, "mid": 700, "low": 450},
    "塑料滑梯": {"unit": "米", "high": 500, "mid": 300, "low": 180},
    
    # 无动力设备 - 攀爬系列
    "不锈钢攀爬架": {"unit": "平米", "high": 1000, "mid": 700, "low": 450},
    "镀锌攀爬架": {"unit": "平米", "high": 700, "mid": 450, "low": 280},
    "绳网攀爬架": {"unit": "平米", "high": 600, "mid": 350, "low": 220},
    "组合攀爬设备": {"unit": "平米", "high": 1200, "mid": 850, "low": 550},
    "拓展设备": {"unit": "平米", "high": 1500, "mid": 1000, "low": 650},
    
    # 无动力设备 - 摇荡系列
    "不锈钢秋千": {"unit": "组", "high": 5000, "mid": 3000, "low": 1800},
    "镀锌秋千": {"unit": "组", "high": 2500, "mid": 1500, "low": 900},
    "鸟巢秋千": {"unit": "组", "high": 6000, "mid": 3800, "low": 2500},
    "摇马": {"unit": "台", "high": 1200, "mid": 650, "low": 380},
    "转椅": {"unit": "台", "high": 2500, "mid": 1500, "low": 800},
    
    # 无动力设备 - 组合设备
    "大型组合滑梯": {"unit": "平米", "high": 1200, "mid": 700, "low": 450},
    "儿童综合乐园": {"unit": "平米", "high": 1000, "mid": 500, "low": 350},
    "冒险主题组合": {"unit": "平米", "high": 1500, "mid": 850, "low": 550},
    
    # 玻璃水滑类
    "玻璃水滑道": {"unit": "米", "high": 4800, "mid": 3900, "low": 3200},
    "玻璃旱滑道": {"unit": "米", "high": 3500, "mid": 2750, "low": 2200},
    "玻璃观景台": {"unit": "平米", "high": 2500, "mid": 1750, "low": 1300},
    "玻璃栈道": {"unit": "平米", "high": 3500, "mid": 2500, "low": 1900},
    "玻璃桥": {"unit": "平米", "high": 3000, "mid": 2250, "low": 1700},
    "高空秋千": {"unit": "套", "high": 15000, "mid": 10000, "low": 7500},
    "步步惊心": {"unit": "米", "high": 8000, "mid": 5500, "low": 4200},
    
    # 机械设备
    "小型过山车": {"unit": "套", "high": 1500000, "mid": 1200000, "low": 900000},
    "中型过山车": {"unit": "套", "high": 3000000, "mid": 2200000, "low": 1600000},
    "大型过山车": {"unit": "套", "high": 5000000, "mid": 4000000, "low": 3000000},
    "小型摩天轮": {"unit": "套", "high": 1000000, "mid": 750000, "low": 550000},
    "中型摩天轮": {"unit": "套", "high": 2000000, "mid": 1500000, "low": 1100000},
    "大型摩天轮": {"unit": "套", "high": 3000000, "mid": 2500000, "low": 2000000},
    "旋转木马": {"unit": "套", "high": 500000, "mid": 350000, "low": 200000},
    "海盗船": {"unit": "套", "high": 800000, "mid": 550000, "low": 350000},
    "大摆锤": {"unit": "套", "high": 1000000, "mid": 700000, "low": 450000},
    "碰碰车": {"unit": "套", "high": 80000, "mid": 55000, "low": 35000},
    
    # 花灯灯饰
    "大型座灯": {"unit": "个", "high": 8000, "mid": 4500, "low": 2800},
    "中型挂灯": {"unit": "个", "high": 3500, "mid": 2000, "low": 1200},
    "小型灯笼": {"unit": "个", "high": 600, "mid": 350, "low": 200},
    "LED光雕造型": {"unit": "组", "high": 12000, "mid": 7500, "low": 5000},
    "LED灯光隧道": {"unit": "米", "high": 8000, "mid": 4500, "low": 3000},
    "灯光长廊": {"unit": "米", "high": 4500, "mid": 2750, "low": 1800},
    
    # 网红打卡
    "天空之镜": {"unit": "平米", "high": 2800, "mid": 1850, "low": 1200},
    "网红吊椅": {"unit": "套", "high": 7000, "mid": 4000, "low": 2500},
    "网红桥_晃动": {"unit": "平米", "high": 5000, "mid": 3400, "low": 2400},
    "网红桥_玻璃": {"unit": "平米", "high": 6000, "mid": 3750, "low": 2800},
    "互动装置": {"unit": "套", "high": 20000, "mid": 9000, "low": 5000},
    "网红雕塑": {"unit": "组", "high": 20000, "mid": 10000, "low": 5000},
    
    # 萌宠乐园
    "小型动物笼舍": {"unit": "平米", "high": 1200, "mid": 700, "low": 450},
    "萌宠互动区": {"unit": "平米", "high": 900, "mid": 500, "low": 320},
    "萌宠景观配套": {"unit": "平米", "high": 400, "mid": 220, "low": 140},
}

# ============================================================
# 分项明细占比配置（8维度）
# ============================================================
BREAKDOWN_RATIOS = {
    "high": {
        "主体材料": 0.40,
        "辅助材料": 0.10,
        "加工制造": 0.18,
        "表面处理": 0.08,
        "电气系统": 0.10,
        "安全设施": 0.06,
        "检测认证": 0.04,
        "其他预留": 0.04,
    },
    "mid": {
        "主体材料": 0.38,
        "辅助材料": 0.10,
        "加工制造": 0.18,
        "表面处理": 0.06,
        "电气系统": 0.12,
        "安全设施": 0.06,
        "检测认证": 0.05,
        "其他预留": 0.05,
    },
    "low": {
        "主体材料": 0.42,
        "辅助材料": 0.10,
        "加工制造": 0.20,
        "表面处理": 0.04,
        "电气系统": 0.10,
        "安全设施": 0.06,
        "检测认证": 0.04,
        "其他预留": 0.04,
    }
}

# ============================================================
# 分项明细说明
# ============================================================
BREAKDOWN_DESCRIPTIONS = {
    "主体材料": "主要结构材料（钢管、型钢、玻璃等）",
    "辅助材料": "配件、紧固件、连接件、密封件",
    "加工制造": "切割、焊接、组装、成型等加工费",
    "表面处理": "喷涂、镀锌、抛光、电泳等处理",
    "电气系统": "电机、控制柜、线缆、照明灯具",
    "安全设施": "护栏、防护网、软垫、安全标识",
    "检测认证": "第三方检测、特检院验收",
    "其他预留": "包装、运输、保险、杂费预留",
}


def format_currency(amount: float) -> str:
    """格式化货币显示"""
    if amount >= 10000:
        return f"{amount/10000:.1f}万"
    else:
        return f"{amount:.0f}元"


def calculate_three_tier_price(
    device_type: str,
    quantity: float,
    params: Optional[Dict] = None
) -> Dict:
    """
    计算三档价格
    
    Args:
        device_type: 设备类型
        quantity: 数量
        params: 额外参数（如材质系数调整等）
    
    Returns:
        包含三档价格的字典
    """
    if device_type not in BASE_PRICES:
        return {"error": f"未找到设备类型: {device_type}"}
    
    base = BASE_PRICES[device_type]
    
    # 计算三档总价
    prices = {
        "high": base["high"] * quantity,
        "mid": base["mid"] * quantity,
        "low": base["low"] * quantity,
    }
    
    result = {
        "device_type": device_type,
        "unit": base["unit"],
        "quantity": quantity,
        "tier_prices": {
            "high": {
                "name": "高档",
                "emoji": "🥇",
                "price": prices["high"],
                "formatted": format_currency(prices["high"]),
            },
            "mid": {
                "name": "中档",
                "emoji": "🥈",
                "price": prices["mid"],
                "formatted": format_currency(prices["mid"]),
            },
            "low": {
                "name": "经济",
                "emoji": "🥉",
                "price": prices["low"],
                "formatted": format_currency(prices["low"]),
            },
        },
        "difference": {
            "mid_vs_high": prices["mid"] - prices["high"],
            "low_vs_high": prices["low"] - prices["high"],
        }
    }
    
    return result


def calculate_breakdown(
    total_price: float,
    tier: str = "mid"
) -> Dict:
    """
    计算分项明细
    
    Args:
        total_price: 总价
        tier: 档位 (high/mid/low)
    
    Returns:
        分项明细字典
    """
    if tier not in BREAKDOWN_RATIOS:
        tier = "mid"
    
    ratios = BREAKDOWN_RATIOS[tier]
    breakdown = {}
    total = 0
    
    for item, ratio in ratios.items():
        amount = total_price * ratio
        breakdown[item] = {
            "amount": amount,
            "formatted": format_currency(amount),
            "ratio": ratio * 100,
            "description": BREAKDOWN_DESCRIPTIONS.get(item, ""),
        }
        total += amount
    
    # 调整确保总和为100%
    breakdown["_total"] = {
        "amount": total,
        "formatted": format_currency(total),
        "ratio": 100,
    }
    
    return breakdown


def generate_cost_estimate(
    device_type: str,
    device_name: str,
    specs: str,
    material: str,
    quantity: float
) -> str:
    """
    生成完整的造价估算报告
    
    Returns:
        Markdown格式的估算报告
    """
    # 计算三档价格
    prices = calculate_three_tier_price(device_type, quantity)
    
    if "error" in prices:
        return f"❌ 错误: {prices['error']}"
    
    # 计算分项明细（基于中档推荐）
    breakdown = calculate_breakdown(prices["tier_prices"]["mid"]["price"], "mid")
    
    # 生成报告
    report = f"""🎢 **游乐文旅造价通**

---

## 【设备信息】
- **名称**：{device_name}
- **类型**：{get_device_category(device_type)}
- **规格**：{specs}
- **材质**：{material}
- **数量**：{quantity}{prices['unit']}

---

## 💰 三档造价对比

| 档位 | 价格 | 与高档差价 |
|:---:|:---:|:---:|
| {prices['tier_prices']['high']['emoji']} {prices['tier_prices']['high']['name']} | {prices['tier_prices']['high']['formatted']} | 基准 |
| {prices['tier_prices']['mid']['emoji']} {prices['tier_prices']['mid']['name']} | {prices['tier_prices']['mid']['formatted']} | {format_currency(prices['difference']['mid_vs_high'])} |
| {prices['tier_prices']['low']['emoji']} {prices['tier_prices']['low']['name']} | {prices['tier_prices']['low']['formatted']} | {format_currency(prices['difference']['low_vs_high'])} |

---

## 📊 中档方案分项明细（推荐）

| 项目 | 金额 | 占比 | 说明 |
|:---|:---:|:---:|:---|
"""
    
    for item, details in breakdown.items():
        if item.startswith("_"):
            continue
        report += f"| {item} | {details['formatted']} | {details['ratio']:.0f}% | {details['description']} |\n"
    
    report += f"| **合计** | **{breakdown['_total']['formatted']}** | **100%** | |\n"
    
    report += f"""
---

## 【推荐建议】

- ✅ **性价比最优**：中档方案（年均成本最低，综合性价比最佳）
- ✅ **追求品质**：高档方案（外观耐久最佳，适合高端定位项目）
- ⚠️ **经济方案**：适合短期项目或预算紧张的情况

---

## ⚠️ 注意事项

**【本估算包含】**
- 设备主体费用
- 辅助材料和配件
- 加工制造费用
- 表面处理费用
- 电气系统（选配）
- 安全设施
- 第三方检测认证

**【本估算不含】**
- ❌ 运输费用（按距离另计）
- ❌ 安装费用（现场安装费）
- ❌ 基础工程（土建、混凝土基础）
- ❌ 配套设施（护栏围网等按需另计）
- ❌ 税费（按政策另行计算）

**【有效期】**
- 本估算有效期为 **30天**
- 原材料价格波动会影响最终报价
- 建议在有效期内锁定价格或签订合同
"""
    
    return report


def get_device_category(device_type: str) -> str:
    """获取设备所属类别"""
    categories = {
        "滑梯": "无动力设备",
        "攀爬": "无动力设备",
        "秋千": "无动力设备",
        "摇马": "无动力设备",
        "转椅": "无动力设备",
        "组合": "无动力设备",
        "拓展": "无动力设备",
        "玻璃水滑": "玻璃水滑",
        "玻璃旱滑": "玻璃水滑",
        "玻璃观景台": "玻璃水滑",
        "玻璃栈道": "玻璃水滑",
        "玻璃桥": "玻璃水滑",
        "高空秋千": "玻璃水滑",
        "步步惊心": "玻璃水滑",
        "过山车": "机械设备",
        "摩天轮": "机械设备",
        "旋转木马": "机械设备",
        "海盗船": "机械设备",
        "大摆锤": "机械设备",
        "碰碰车": "机械设备",
        "座灯": "花灯灯饰",
        "挂灯": "花灯灯饰",
        "灯笼": "花灯灯饰",
        "LED": "花灯灯饰",
        "灯光": "花灯灯饰",
        "天空之镜": "网红打卡",
        "网红": "网红打卡",
        "互动装置": "网红打卡",
        "动物笼舍": "萌宠乐园",
        "互动区": "萌宠乐园",
    }
    
    for keyword, category in categories.items():
        if keyword in device_type:
            return category
    return "其他设备"


def batch_calculate(items: List[Dict]) -> Dict:
    """
    批量计算多个设备
    
    Args:
        items: 设备列表 [{"name": "不锈钢滑梯", "type": "不锈钢滑梯_组合", "quantity": 12}]
    
    Returns:
        批量计算结果
    """
    results = []
    summary = {"high": 0, "mid": 0, "low": 0}
    
    for idx, item in enumerate(items, 1):
        prices = calculate_three_tier_price(item["type"], item["quantity"])
        if "error" not in prices:
            result = {
                "index": idx,
                "name": item.get("name", item["type"]),
                "unit": prices["unit"],
                "quantity": item["quantity"],
                "prices": {
                    "high": prices["tier_prices"]["high"]["formatted"],
                    "mid": prices["tier_prices"]["mid"]["formatted"],
                    "low": prices["tier_prices"]["low"]["formatted"],
                },
                "raw_prices": {
                    "high": prices["tier_prices"]["high"]["price"],
                    "mid": prices["tier_prices"]["mid"]["price"],
                    "low": prices["tier_prices"]["low"]["price"],
                }
            }
            results.append(result)
            summary["high"] += prices["tier_prices"]["high"]["price"]
            summary["mid"] += prices["tier_prices"]["mid"]["price"]
            summary["low"] += prices["tier_prices"]["low"]["price"]
    
    return {
        "items": results,
        "summary": {
            "high": {"total": summary["high"], "formatted": format_currency(summary["high"])},
            "mid": {"total": summary["mid"], "formatted": format_currency(summary["mid"])},
            "low": {"total": summary["low"], "formatted": format_currency(summary["low"])},
        },
        "savings": {
            "mid_savings_rate": ((summary["high"] - summary["mid"]) / summary["high"] * 100) if summary["high"] else 0,
            "low_savings_rate": ((summary["high"] - summary["low"]) / summary["high"] * 100) if summary["high"] else 0,
        }
    }


# ============================================================
# 主函数示例
# ============================================================
if __name__ == "__main__":
    # 示例1：单项设备造价估算
    print("=" * 60)
    print("示例1：不锈钢组合滑梯造价估算")
    print("=" * 60)
    report = generate_cost_estimate(
        device_type="不锈钢滑梯_组合",
        device_name="不锈钢组合滑梯",
        specs="高度3.5m，长度12m，面积45㎡",
        material="304不锈钢",
        quantity=12
    )
    print(report)
    
    # 示例2：批量估算
    print("\n" + "=" * 60)
    print("示例2：批量设备造价估算")
    print("=" * 60)
    items = [
        {"name": "不锈钢滑梯", "type": "不锈钢滑梯_组合", "quantity": 12},
        {"name": "不锈钢秋千", "type": "不锈钢秋千", "quantity": 3},
        {"name": "镀锌攀爬架", "type": "镀锌攀爬架", "quantity": 20},
    ]
    batch_result = batch_calculate(items)
    print(f"共 {len(batch_result['items'])} 项设备")
    print(f"高档总计：{batch_result['summary']['high']['formatted']}")
    print(f"中档总计：{batch_result['summary']['mid']['formatted']}")
    print(f"经济总计：{batch_result['summary']['low']['formatted']}")
    print(f"中档节省比例：{batch_result['savings']['mid_savings_rate']:.1f}%")
