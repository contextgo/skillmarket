#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 设备选型推荐
功能：根据项目场景和预算推荐合适的游乐设备配置
"""

import json
from typing import Dict, List, Optional


# 设备配置推荐数据库
EQUIPMENT_RECOMMENDATIONS = {
    "社区配套": {
        "适用场景": "住宅小区、社区广场、幼儿园",
        "目标客群": "3-8岁儿童",
        "推荐设备": [
            {"名称": "小型滑梯", "规格": "3-5米", "单价": "3000-5000元", "数量建议": "1-2套"},
            {"名称": "秋千", "规格": "单座/双座", "单价": "2000-3500元", "数量建议": "2-4个"},
            {"名称": "摇马", "规格": "标准款", "单价": "600-1200元", "数量建议": "3-5个"},
            {"名称": "沙池", "规格": "10-20㎡", "单价": "5000-10000元", "数量建议": "1个"},
            {"名称": "攀爬架", "规格": "小型", "单价": "5000-15000元", "数量建议": "1套"}
        ],
        "预算区间": "5-15万元",
        "核心特点": "占地小、投资低、维护简便"
    },
    "公园景区配套": {
        "适用场景": "城市公园、景区入口、旅游配套",
        "目标客群": "3-12岁儿童及家庭",
        "推荐设备": [
            {"名称": "组合滑梯", "规格": "6-10米", "单价": "5-15万元", "数量建议": "1套"},
            {"名称": "大型爬网", "规格": "含多层结构", "单价": "8-20万元", "数量建议": "1套"},
            {"名称": "丛林穿越", "规格": "50-100米", "单价": "8-18万元", "数量建议": "1条"},
            {"名称": "沙水互动", "规格": "20-30㎡", "单价": "3-8万元", "数量建议": "1套"},
            {"名称": "跷跷板组合", "规格": "多人款", "单价": "5000-10000元", "数量建议": "2-3组"}
        ],
        "预算区间": "30-80万元",
        "核心特点": "兼顾安全与趣味，适合家庭亲子"
    },
    "景区核心项目": {
        "适用场景": "景区核心体验区、独立售票",
        "目标客群": "全年龄段",
        "推荐设备": [
            {"名称": "彩虹滑道", "规格": "100-200米", "单价": "15-35万元", "数量建议": "1条"},
            {"名称": "丛林穿越", "规格": "100-200米", "单价": "15-30万元", "数量建议": "1条"},
            {"名称": "高空滑索", "规格": "100-300米", "单价": "25-45万元", "数量建议": "1条"},
            {"名称": "天空步道", "规格": "含观景平台", "单价": "20-35万元", "数量建议": "1套"},
            {"名称": "蹦蹦云", "规格": "30-50㎡", "单价": "5-10万元", "数量建议": "1套"}
        ],
        "预算区间": "80-200万元",
        "核心特点": "强引流、高客单价、网红属性强"
    },
    "主题乐园": {
        "适用场景": "独立运营的主题乐园、田园综合体",
        "目标客群": "全年龄段家庭客群",
        "推荐设备": [
            {"名称": "大型组合滑梯", "规格": "定制主题", "单价": "30-60万元", "数量建议": "1-2套"},
            {"名称": "丛林探险区", "规格": "含多路线", "单价": "40-80万元", "数量建议": "1区"},
            {"名称": "无动力过山车", "规格": "含轨道", "单价": "50-100万元", "数量建议": "1套"},
            {"名称": "亲子农场区", "规格": "无动力+互动", "单价": "20-40万元", "数量建议": "1区"},
            {"名称": "网红打卡区", "规格": "多项目组合", "单价": "30-50万元", "数量建议": "1区"}
        ],
        "预算区间": "150-500万元",
        "核心特点": "全品类、高体验、收益多元化"
    },
    "研学基地": {
        "适用场景": "学校研学、亲子农庄、科普教育基地",
        "目标客群": "6-14岁儿童及教育团体",
        "推荐设备": [
            {"名称": "丛林穿越", "规格": "安全系数高", "单价": "15-30万元", "数量建议": "1条"},
            {"名称": "挑战探险区", "规格": "拓展训练类", "单价": "10-25万元", "数量建议": "1区"},
            {"名称": "自然认知区", "规格": "科普+互动", "单价": "8-15万元", "数量建议": "1区"},
            {"名称": "农事体验区", "规格": "DIY+采摘", "单价": "5-10万元", "数量建议": "1区"},
            {"名称": "安全攀爬区", "规格": "室内外结合", "单价": "10-20万元", "数量建议": "1区"}
        ],
        "预算区间": "50-150万元",
        "核心特点": "教育属性强、安全标准高、互动体验丰富"
    }
}

# 年龄段适配设备
AGE_APPROPRIATE = {
    "0-3岁": {
        "适合设备": ["婴儿摇椅", "软体爬行区", "小型沙池", "戏水池"],
        "不建议": ["高空项目", "复杂攀爬", "电动设备"],
        "安全要点": "地面软垫厚度≥30mm，家长陪同"
    },
    "3-6岁": {
        "适合设备": ["小型滑梯", "摇马", "秋千", "钻洞", "小型爬网"],
        "不建议": ["高度超过3米的项目", "高速滑动设备"],
        "安全要点": "设备高度≤2米，地面软垫完善"
    },
    "6-12岁": {
        "适合设备": ["组合滑梯", "中型爬网", "丛林穿越", "跷跷板", "旋转设备"],
        "不建议": ["成人高空滑索", "高速竞技设备"],
        "安全要点": "有成人监护更好，可尝试挑战性项目"
    },
    "12岁以上": {
        "适合设备": ["丛林穿越", "高空滑索", "天空步道", "蹦极", "攀岩"],
        "不建议": ["过于简单的幼童设备"],
        "安全要点": "需专业安全培训，配备防护装备"
    }
}


def recommend_equipment(
    project_type: str,
    budget: float,
    area: float,
    target_age: Optional[str] = None,
    theme: Optional[str] = None
) -> Dict:
    """
    推荐设备配置方案
    
    Args:
        project_type: 项目类型
        budget: 预算金额
        area: 场地面积
        target_age: 目标年龄段
        theme: 主题风格
    
    Returns:
        设备推荐方案
    """
    recommendation = {
        "项目类型": project_type,
        "预算": f"{budget/10000:.1f}万元",
        "场地面积": f"{area}平方米",
        "目标年龄段": target_age or "全年龄段",
        "主题风格": theme or "标准",
        "一、推荐配置": {},
        "二、配置说明": {},
        "三、选购建议": []
    }
    
    # 查找匹配的推荐
    match = EQUIPMENT_RECOMMENDATIONS.get(project_type)
    if not match:
        # 模糊匹配
        for key, rec in EQUIPMENT_RECOMMENDATIONS.items():
            if project_type in key or key in project_type:
                match = rec
                break
    
    if match:
        recommendation["一、推荐配置"]["适用场景"] = match["适用场景"]
        recommendation["一、推荐配置"]["推荐设备"] = match["推荐设备"]
        recommendation["一、推荐配置"]["预算区间"] = match["预算区间"]
        recommendation["一、推荐配置"]["核心特点"] = match["核心特点"]
    else:
        # 默认推荐
        recommendation["一、推荐配置"]["推荐设备"] = _default_recommendation(budget)
        recommendation["一、推荐配置"]["说明"] = "基于预算的通用推荐"
    
    # 预算分析
    budget_range = _parse_budget_range(budget)
    recommendation["二、配置说明"]["预算分析"] = budget_range
    
    # 年龄适配分析
    if target_age:
        age_info = AGE_APPROPRIATE.get(target_age, {})
        recommendation["二、配置说明"]["年龄适配"] = age_info
    
    # 选购建议
    recommendation["三、选购建议"] = _generate_purchase_suggestions(
        project_type, 
        budget, 
        theme
    )
    
    return recommendation


def _parse_budget_range(budget: float) -> Dict:
    """解析预算区间"""
    if budget < 150000:
        level = "基础型"
        analysis = "适合社区配套，以小型设备为主"
    elif budget < 500000:
        level = "标准型"
        analysis = "适合景区配套，可配置1-2套中型设备"
    elif budget < 1500000:
        level = "完善型"
        analysis = "适合景区核心项目，可配置网红引流设备"
    else:
        level = "高端型"
        analysis = "适合主题乐园，全品类高端配置"
    
    return {
        "预算等级": level,
        "预算分析": analysis
    }


def _default_recommendation(budget: float) -> List[Dict]:
    """默认推荐"""
    if budget < 100000:
        return [
            {"名称": "小型滑梯", "数量建议": "1套", "参考价": "3000-5000元"},
            {"名称": "秋千", "数量建议": "2个", "参考价": "2000-3500元/个"},
            {"名称": "摇马", "数量建议": "3个", "参考价": "600-1200元/个"}
        ]
    elif budget < 500000:
        return [
            {"名称": "组合滑梯", "数量建议": "1套", "参考价": "5-15万元"},
            {"名称": "爬网组合", "数量建议": "1套", "参考价": "3-8万元"},
            {"名称": "沙池", "数量建议": "1个", "参考价": "1-3万元"}
        ]
    else:
        return [
            {"名称": "大型组合设备", "数量建议": "1-2套", "参考价": "20-50万元"},
            {"名称": "丛林穿越", "数量建议": "1条", "参考价": "15-30万元"},
            {"名称": "网红引流设备", "数量建议": "1套", "参考价": "10-20万元"}
        ]


def _generate_purchase_suggestions(
    project_type: str,
    budget: float,
    theme: Optional[str]
) -> List[str]:
    """生成选购建议"""
    suggestions = []
    
    # 安全认证
    suggestions.append("优先选择通过GB 6675安全认证的设备")
    
    # 材质选择
    if "景区" in project_type or "乐园" in project_type:
        suggestions.append("户外设备建议选用304不锈钢或进口防腐木材质")
    
    # 定制vs标准
    if theme:
        suggestions.append("主题定制可提升差异化竞争力，但成本增加15%-40%")
    else:
        suggestions.append("标准设备性价比更高，适合追求快速回本的投资者")
    
    # 采购策略
    suggestions.append("建议选择提供安装售后一体化服务的厂家")
    suggestions.append("整园打包采购可争取5%-15%的折扣")
    
    # 后期维护
    suggestions.append("选择耐用材质可降低年维护成本(建议占比3%-5%)")
    suggestions.append("签订维保合同，明确配件供应和响应时限")
    
    return suggestions


def compare_equipment_by_price(
    equipment_type: str,
    specs: List[str] = None
) -> Dict:
    """
    同类设备价格对比
    
    Args:
        equipment_type: 设备类型
        specs: 规格列表
    
    Returns:
        价格对比分析
    """
    # 简化实现，实际应用中应连接数据库
    comparison = {
        "设备类型": equipment_type,
        "价格对比": []
    }
    
    base_specs = specs or ["基础款", "标准款", "高端款"]
    
    for spec in base_specs:
        if "基础" in spec:
            comparison["价格对比"].append({
                "规格": spec,
                "价格区间": "偏低",
                "特点": "性价比高，适合预算有限",
                "适用": "短期项目或社区配套"
            })
        elif "标准" in spec:
            comparison["价格对比"].append({
                "规格": spec,
                "价格区间": "中等",
                "特点": "综合性价比最优",
                "适用": "大多数景区项目"
            })
        else:
            comparison["价格对比"].append({
                "规格": spec,
                "价格区间": "较高",
                "特点": "品质高、寿命长",
                "适用": "高端项目或长期运营"
            })
    
    comparison["选购建议"] = {
        "短期项目": "选择基础款，控制初期投入",
        "长期项目": "选择标准或高端款，降低长期维护成本",
        "高端定位": "选择高端款，提升品牌溢价能力"
    }
    
    return comparison


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 3:
        print("=" * 50)
        print("游乐文旅造价通 - 设备选型推荐")
        print("=" * 50)
        print("\n用法:")
        print("  python equipment_selector.py <项目类型> <预算>")
        print("\n示例:")
        print("  python equipment_selector.py 公园景区配套 500000")
        print("\n项目类型:")
        for pt in EQUIPMENT_RECOMMENDATIONS.keys():
            print(f"  - {pt}")
        return
    
    project_type = sys.argv[1]
    budget = float(sys.argv[2])
    
    result = recommend_equipment(project_type, budget, 1000)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
