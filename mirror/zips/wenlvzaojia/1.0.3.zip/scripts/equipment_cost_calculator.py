#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 设备造价计算器
功能：计算各类游乐设备的采购、安装、维护成本
"""

import json
from typing import Dict, List, Optional

# 设备基础价格数据库 (单位: 元)
EQUIPMENT_BASE_PRICES = {
    # 小型设备
    "秋千": {"普通": 2000, "标准": 3500, "高端": 5500},
    "摇马": {"普通": 600, "标准": 1200, "高端": 2000},
    "跷跷板": {"普通": 1800, "标准": 3000, "高端": 4500},
    "转椅": {"普通": 2500, "标准": 4000, "高端": 6000},
    "滑梯(5米内)": {"普通": 3000, "标准": 5000, "高端": 8000},
    "沙池": {"普通": 5000, "标准": 10000, "高端": 20000},
    "钻洞": {"普通": 2500, "标准": 4500, "高端": 7000},
    
    # 中型设备
    "组合滑梯(6-10米)": {"普通": 30000, "标准": 80000, "高端": 150000},
    "爬网组合": {"普通": 20000, "标准": 50000, "高端": 100000},
    "攀爬架": {"普通": 15000, "标准": 40000, "高端": 80000},
    "海盗船": {"普通": 9000, "标准": 15000, "高端": 25000},
    "旋转自行车": {"普通": 3500, "标准": 5500, "高端": 8000},
    
    # 大型设备
    "彩虹滑道(100米)": {"普通": 100000, "标准": 200000, "高端": 400000},
    "丛林穿越(穿戴式,每米)": {"普通": 600, "标准": 900, "高端": 1200},
    "丛林穿越(无穿戴式,每米)": {"普通": 800, "标准": 1200, "高端": 1600},
    "高空滑索": {"普通": 150000, "标准": 250000, "高端": 350000},
    "天空步道": {"普通": 120000, "标准": 200000, "高端": 300000},
    "大型组合爬网": {"普通": 200000, "标准": 350000, "高端": 500000},
    "丛林魔网(每平米)": {"普通": 400, "标准": 700, "高端": 1250},
    "轨道爬山车(每米)": {"普通": 800, "标准": 1500, "高端": 2500},
}

# 材质价格系数
MATERIAL_MULTIPLIERS = {
    "普通塑料": 1.0,
    "工程塑料": 1.3,
    "镀锌钢材": 1.2,
    "304不锈钢": 1.8,
    "316L不锈钢": 2.2,
    "国产防腐木": 1.1,
    "进口防腐木": 1.5,
}

# 地区价格系数
REGION_MULTIPLIERS = {
    "一线城市": 1.3,
    "二线城市": 1.1,
    "三线城市": 1.0,
    "县城/乡镇": 0.85,
    "偏远地区": 0.9,
}


def calculate_equipment_cost(
    equipment_type: str,
    quantity: int = 1,
    material: str = "镀锌钢材",
    region: str = "二线城市",
    custom_specs: Optional[Dict] = None
) -> Dict:
    """
    计算游乐设备成本
    
    Args:
        equipment_type: 设备类型
        quantity: 数量/规格
        material: 材质
        region: 地区
        custom_specs: 自定义规格参数
    
    Returns:
        成本明细字典
    """
    result = {
        "设备名称": equipment_type,
        "数量/规格": quantity,
        "材质": material,
        "地区": region,
        "成本明细": {},
        "总计": 0
    }
    
    # 基础价格
    base_price = EQUIPMENT_BASE_PRICES.get(equipment_type, {})
    if not base_price:
        result["错误"] = f"未找到设备类型: {equipment_type}"
        return result
    
    # 获取对应档次价格(默认标准)
    if custom_specs and "档次" in custom_specs:
        level = custom_specs["档次"]
    else:
        level = "标准"
    
    unit_price = base_price.get(level, base_price.get("标准", 0))
    result["成本明细"]["设备单价"] = unit_price
    
    # 材质系数
    material_mult = MATERIAL_MULTIPLIERS.get(material, 1.0)
    result["成本明细"]["材质系数"] = material_mult
    result["成本明细"]["材质加价"] = unit_price * (material_mult - 1)
    
    # 地区系数
    region_mult = REGION_MULTIPLIERS.get(region, 1.0)
    result["成本明细"]["地区系数"] = region_mult
    
    # 设备总价
    equipment_total = unit_price * quantity * material_mult * region_mult
    result["成本明细"]["设备采购价"] = equipment_total
    
    # 安装费用 (设备价的10-15%)
    if custom_specs and "安装难度" in custom_specs:
        if custom_specs["安装难度"] == "高":
            install_rate = 0.18
        elif custom_specs["安装难度"] == "低":
            install_rate = 0.10
        else:
            install_rate = 0.15
    else:
        install_rate = 0.15
    install_cost = equipment_total * install_rate
    result["成本明细"]["安装费用"] = install_cost
    result["成本明细"]["安装费率"] = install_rate
    
    # 运输费用 (设备价的3-5%)
    transport_cost = equipment_total * 0.04
    result["成本明细"]["运输费用"] = transport_cost
    
    # 设计费用 (如需定制)
    design_cost = 0
    if custom_specs and custom_specs.get("定制", False):
        design_cost = equipment_total * 0.08
        result["成本明细"]["定制设计费"] = design_cost
    
    # 年度维护费用 (设备价的3-5%)
    annual_maintenance = equipment_total * 0.04
    result["成本明细"]["年度维护费(估算)"] = annual_maintenance
    
    # 总计
    result["总计"] = equipment_total + install_cost + transport_cost + design_cost
    
    # 五年总成本估算
    result["五年总成本"] = result["总计"] + annual_maintenance * 5
    
    return result


def calculate_land_cost(area: float, region: str = "二线城市", lease_years: int = 10) -> Dict:
    """
    计算场地租金成本
    
    Args:
        area: 场地面积(平方米)
        region: 地区
        lease_years: 租期(年)
    
    Returns:
        场地成本明细
    """
    # 月租金标准(元/平方米)
    rent_rates = {
        "一线城市": 80,
        "二线城市": 60,
        "三线城市": 45,
        "县城/乡镇": 35,
        "偏远地区": 25,
    }
    
    monthly_rent = area * rent_rates.get(region, 60)
    annual_rent = monthly_rent * 12
    
    return {
        "场地面积": f"{area}平方米",
        "地区": region,
        "月租金": monthly_rent,
        "年租金": annual_rent,
        f"{lease_years}年租金": annual_rent * lease_years,
        "租金占预算比例参考": "10%-20%"
    }


def calculate_subsidary_cost(area: float) -> Dict:
    """
    计算配套设施成本
    
    Args:
        area: 场地面积(平方米)
    
    Returns:
        配套设施成本明细
    """
    # 安全防护类 (围栏、防护垫)
    safety_cost = area * 100
    
    # 运营服务类 (闸机、售票处等)
    operation_cost = 15000 + area * 20
    
    # 体验提升类 (休息区、座椅等)
    experience_cost = 8000 + area * 30
    
    # 基础保障类 (水电、监控)
    infrastructure_cost = 20000 + area * 50
    
    total = safety_cost + operation_cost + experience_cost + infrastructure_cost
    
    return {
        "场地面积": f"{area}平方米",
        "安全防护类": safety_cost,
        "运营服务类": operation_cost,
        "体验提升类": experience_cost,
        "基础保障类": infrastructure_cost,
        "配套设施总计": total,
        "占总预算比例参考": "15%-25%"
    }


def generate_full_budget(
    project_scale: str,
    area: float,
    region: str = "二线城市",
    equipment_list: Optional[List[Dict]] = None
) -> Dict:
    """
    生成完整项目预算
    
    Args:
        project_scale: 项目规模 ("小型"/"中型"/"大型")
        area: 场地面积(平方米)
        region: 地区
        equipment_list: 设备清单
    
    Returns:
        完整预算报告
    """
    budget = {
        "项目规模": project_scale,
        "场地面积": f"{area}平方米",
        "地区": region,
        "预算构成": {},
        "总计": 0
    }
    
    # 根据规模估算设备配置
    if project_scale == "小型":
        base_budget_ratio = {"设备": 0.50, "场地": 0.15, "配套": 0.20, "预备金": 0.15}
    elif project_scale == "中型":
        base_budget_ratio = {"设备": 0.55, "场地": 0.12, "配套": 0.18, "预备金": 0.15}
    else:  # 大型
        base_budget_ratio = {"设备": 0.60, "场地": 0.10, "配套": 0.15, "预备金": 0.15}
    
    # 场地成本
    land_cost = calculate_land_cost(area, region)
    budget["预算构成"]["场地租金(10年)"] = land_cost[f"{10}年租金"]
    
    # 设备成本
    equipment_cost = 0
    if equipment_list:
        for eq in equipment_list:
            cost = calculate_equipment_cost(
                eq.get("type"),
                eq.get("quantity", 1),
                eq.get("material", "镀锌钢材"),
                region,
                eq.get("specs")
            )
            equipment_cost += cost.get("总计", 0)
    else:
        # 根据规模和面积估算
        if project_scale == "小型":
            equipment_cost = area * 500
        elif project_scale == "中型":
            equipment_cost = area * 800
        else:
            equipment_cost = area * 1200
    budget["预算构成"]["设备采购安装"] = equipment_cost
    
    # 配套设施
    subsidiary_cost = calculate_subsidary_cost(area)
    budget["预算构成"]["配套设施"] = subsidiary_cost["配套设施总计"]
    
    # 规划设计费 (设备价的5-10%)
    design_fee = equipment_cost * 0.08
    budget["预算构成"]["规划设计费"] = design_fee
    
    # 预备金
   预备金 = equipment_cost * 0.15
    budget["预算构成"]["运营预备金"] = 预备金
    
    # 总计
    budget["总计"] = sum(budget["预算构成"].values())
    
    # 回本周期估算
    if project_scale == "小型":
        annual_revenue = equipment_cost * 0.8
        budget["预估回本周期"] = "8-12个月"
    elif project_scale == "中型":
        annual_revenue = equipment_cost * 0.7
        budget["预估回本周期"] = "12-18个月"
    else:
        annual_revenue = equipment_cost * 0.6
        budget["预估回本周期"] = "18-24个月"
    
    # 成本占比分析
    budget["成本占比分析"] = {
        k: f"{v/budget['总计']*100:.1f}%" 
        for k, v in budget["预算构成"].items()
    }
    
    return budget


def main():
    """主函数 - 命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("=" * 50)
        print("游乐文旅造价通 - 设备造价计算器")
        print("=" * 50)
        print("\n用法:")
        print("  python equipment_cost_calculator.py <设备类型> [数量]")
        print("\n示例:")
        print("  python equipment_cost_calculator.py 秋千 5")
        print("  python equipment_cost_calculator.py 组合滑梯(6-10米) 2")
        print("\n支持的设备类型:")
        for eq in list(EQUIPMENT_BASE_PRICES.keys())[:10]:
            print(f"  - {eq}")
        print("  ...(更多设备请查看脚本)")
        return
    
    equipment_type = sys.argv[1]
    quantity = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    
    result = calculate_equipment_cost(equipment_type, quantity)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
