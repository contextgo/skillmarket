#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 文旅项目预算生成器
功能：根据项目参数自动生成完整的项目预算方案
"""

import json
from datetime import datetime
from typing import Dict, List, Optional


# 项目类型配置
PROJECT_TYPES = {
    "社区游乐场": {
        "面积范围": "100-500平方米",
        "投资区间": "10-50万元",
        "设备配置": ["小型滑梯", "秋千", "沙池", "摇马"],
        "回本周期": "8-12个月"
    },
    "景区配套游乐区": {
        "面积范围": "500-2000平方米",
        "投资区间": "50-150万元",
        "设备配置": ["组合滑梯", "攀爬架", "丛林穿越", "彩虹滑道"],
        "回本周期": "12-18个月"
    },
    "主题游乐乐园": {
        "面积范围": "2000-10000平方米",
        "投资区间": "150-500万元",
        "设备配置": ["大型组合设备", "无动力过山车", "丛林探险", "亲子农场"],
        "回本周期": "18-24个月"
    },
    "大型综合文旅项目": {
        "面积范围": "10000平方米以上",
        "投资区间": "500万元以上",
        "设备配置": ["全品类定制设备", "水上游乐", "室内场馆", "演艺设施"],
        "回本周期": "2-4年"
    }
}

# 地区经济系数
REGION_COEFFICIENTS = {
    "一线城市": {"成本系数": 1.3, "客流量系数": 1.5, "客单价系数": 1.4},
    "二线城市": {"成本系数": 1.1, "客流量系数": 1.2, "客单价系数": 1.2},
    "三线城市": {"成本系数": 1.0, "客流量系数": 1.0, "客单价系数": 1.0},
    "县城/乡镇": {"成本系数": 0.85, "客流量系数": 0.7, "客单价系数": 0.8},
    "偏远地区": {"成本系数": 0.9, "客流量系数": 0.5, "客单价系数": 0.7}
}


def generate_budget_plan(
    project_name: str,
    project_type: str,
    area: float,
    region: str,
    theme: Optional[str] = None,
    custom_requirements: Optional[Dict] = None
) -> Dict:
    """
    生成完整的项目预算方案
    
    Args:
        project_name: 项目名称
        project_type: 项目类型
        area: 场地面积(平方米)
        region: 地区
        theme: 主题风格
        custom_requirements: 自定义需求
    
    Returns:
        完整预算方案
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    coeff = REGION_COEFFICIENTS.get(region, REGION_COEFFICIENTS["三线城市"])
    
    budget = {
        "报告生成时间": timestamp,
        "项目基本信息": {
            "项目名称": project_name,
            "项目类型": project_type,
            "场地面积": f"{area}平方米",
            "地区": region,
            "主题风格": theme or "标准配置"
        },
        "一、投资预算明细": {},
        "二、收入预测": {},
        "三、投资回报分析": {},
        "四、风险提示": []
    }
    
    # ==================== 投资预算明细 ====================
    
    # 1. 设备采购安装 (占比最高)
    base_equipment_cost = area * _get_equipment_unit_price(project_type)
    equipment_cost = base_equipment_cost * coeff["成本系数"]
    
    # 主题定制加价
    theme_premium = 0
    if theme and theme != "标准配置":
        theme_premium = equipment_cost * 0.15
        budget["一、投资预算明细"]["主题定制费"] = theme_premium
    
    budget["一、投资预算明细"]["核心设备采购安装"] = equipment_cost + theme_premium
    budget["一、投资预算明细"]["设备占比"] = "50%-60%"
    
    # 2. 场地基础与安全铺设
    land_preparation = area * 80 * coeff["成本系数"]
    safety_flooring = area * 100
    budget["一、投资预算明细"]["场地平整与基础"] = land_preparation
    budget["一、投资预算明细"]["安全防护地垫"] = safety_flooring
    budget["一、投资预算明细"]["场地费用小计"] = land_preparation + safety_flooring
    budget["一、投资预算明细"]["场地占比"] = "15%-25%"
    
    # 3. 配套设施
    facility_cost = area * 50 + 30000
    budget["一、投资预算明细"]["配套设施"] = facility_cost
    budget["一、投资预算明细"]["配套占比"] = "10%-15%"
    
    # 4. 规划设计费
    design_fee = equipment_cost * 0.08
    budget["一、投资预算明细"]["规划设计费"] = design_fee
    
    # 5. 安装运输
    install_transport = equipment_cost * 0.12
    budget["一、投资预算明细"]["安装运输费"] = install_transport
    
    # 6. 合规检测
    compliance_fee = equipment_cost * 0.03
    budget["一、投资预算明细"]["合规检测费"] = compliance_fee
    
    # 7. 运营预备金
    total_investment = (
        equipment_cost + theme_premium +
        land_preparation + safety_flooring +
        facility_cost + design_fee +
        install_transport + compliance_fee
    )
    operating_reserve = total_investment * 0.10
    budget["一、投资预算明细"]["运营预备金"] = operating_reserve
    
    # 预算总计
    budget["一、投资预算明细"]["项目总投资"] = total_investment + operating_reserve
    budget["一、投资预算明细"]["单位面积投资"] = f"{(total_investment + operating_reserve)/area:.0f}元/平方米"
    
    # ==================== 收入预测 ====================
    
    # 日均客流量估算
    base_daily_visitors = _estimate_daily_visitors(project_type, area)
    daily_visitors = base_daily_visitors * coeff["客流量系数"]
    
    # 客单价
    base_ticket_price = _get_ticket_price(project_type)
    ticket_price = base_ticket_price * coeff["客单价系数"]
    
    # 年营业收入
    annual_visitors = daily_visitors * 300  # 假设年运营300天
    annual_revenue = annual_visitors * ticket_price
    
    # 其他收入 (餐饮、零售、二消)
    other_revenue = annual_revenue * 0.3
    
    budget["二、收入预测"]["日均客流量"] = f"{daily_visitors:.0f}人次"
    budget["二、收入预测"]["客单价"] = f"{ticket_price:.0f}元/人"
    budget["二、收入预测"]["年门票收入"] = annual_revenue
    budget["二、收入预测"]["年其他收入"] = other_revenue
    budget["二、收入预测"]["年营业收入合计"] = annual_revenue + other_revenue
    
    # ==================== 投资回报分析 ====================
    
    # 年运营成本
    annual_operating_cost = (
        area * 20 * 12 +  # 场地维护
        annual_visitors * 5 +  # 人员成本
        total_investment * 0.05  # 设备维护
    )
    
    annual_profit = (annual_revenue + other_revenue) - annual_operating_cost
    roi = (annual_profit / (total_investment + operating_reserve)) * 100
    
    # 回本周期
    payback_months = (total_investment + operating_reserve) / (annual_profit / 12) if annual_profit > 0 else "待评估"
    
    budget["三、投资回报分析"]["年运营成本"] = annual_operating_cost
    budget["三、投资回报分析"]["年净利润"] = annual_profit
    budget["三、投资回报分析"]["投资回报率(ROI)"] = f"{roi:.1f}%"
    budget["三、投资回报分析"]["预估回本周期"] = payback_months if isinstance(payback_months, str) else f"{payback_months:.0f}个月"
    budget["三、投资回报分析"]["参考回本周期"] = PROJECT_TYPES.get(project_type, {}).get("回本周期", "待评估")
    
    # ==================== 风险提示 ====================
    
    budget["四、风险提示"] = [
        "淡旺季客流差异可能导致实际收入波动",
        "设备安全维护需定期进行，确保合规运营",
        "天气因素对户外游乐项目影响较大",
        "建议预留足够的流动资金应对初期运营",
        "需关注当地文旅政策变化"
    ]
    
    return budget


def _get_equipment_unit_price(project_type: str) -> float:
    """获取设备单位价格"""
    unit_prices = {
        "社区游乐场": 500,
        "景区配套游乐区": 800,
        "主题游乐乐园": 1200,
        "大型综合文旅项目": 2000
    }
    return unit_prices.get(project_type, 800)


def _estimate_daily_visitors(project_type: str, area: float) -> int:
    """估算日均客流量"""
    base_visitors = {
        "社区游乐场": 100,
        "景区配套游乐区": 300,
        "主题游乐乐园": 500,
        "大型综合文旅项目": 1000
    }
    return int(base_visitors.get(project_type, 200) * (area / 1000))


def _get_ticket_price(project_type: str) -> float:
    """获取参考门票价格"""
    prices = {
        "社区游乐场": 30,
        "景区配套游乐区": 50,
        "主题游乐乐园": 80,
        "大型综合文旅项目": 120
    }
    return prices.get(project_type, 50)


def generate_comparison_report(
    project_name: str,
    area: float,
    region: str,
    scale_options: List[str] = None
) -> Dict:
    """
    生成多方案对比报告
    
    Args:
        project_name: 项目名称
        area: 场地面积
        region: 地区
        scale_options: 规模选项列表
    
    Returns:
        对比报告
    """
    if scale_options is None:
        scale_options = ["小型", "中型", "大型"]
    
    comparison = {
        "项目名称": project_name,
        "场地面积": f"{area}平方米",
        "地区": region,
        "方案对比": {}
    }
    
    for scale in scale_options:
        budget = generate_budget_plan(
            project_name=f"{project_name}-{scale}方案",
            project_type=_scale_to_type(scale),
            area=area,
            region=region
        )
        
        comparison["方案对比"][scale] = {
            "总投资": budget["一、投资预算明细"]["项目总投资"],
            "年营业收入": budget["二、收入预测"]["年营业收入合计"],
            "年净利润": budget["三、投资回报分析"]["年净利润"],
            "回本周期": budget["三、投资回报分析"]["预估回本周期"],
            "ROI": budget["三、投资回报分析"]["投资回报率(ROI)"]
        }
    
    # 推荐建议
    total_investments = [v["总投资"] for v in comparison["方案对比"].values()]
    avg_investment = sum(total_investments) / len(total_investments)
    
    comparison["推荐建议"] = {
        "初创/谨慎型": "小型方案，风险最低，适合试水",
        "稳健型": "中型方案，平衡投资与收益",
        "进取型": "大型方案，适合有实力的投资者"
    }
    
    return comparison


def _scale_to_type(scale: str) -> str:
    """规模转换为项目类型"""
    mapping = {
        "小型": "社区游乐场",
        "中型": "景区配套游乐区",
        "大型": "主题游乐乐园"
    }
    return mapping.get(scale, "景区配套游乐区")


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 4:
        print("=" * 50)
        print("文旅项目预算生成器")
        print("=" * 50)
        print("\n用法:")
        print("  python budget_generator.py <项目名称> <项目类型> <面积> <地区>")
        print("\n示例:")
        print('  python budget_generator.py "欢乐星球乐园" "景区配套游乐区" 1500 "二线城市"')
        print("\n项目类型:")
        for pt in PROJECT_TYPES.keys():
            print(f"  - {pt}")
        return
    
    project_name = sys.argv[1]
    project_type = sys.argv[2]
    area = float(sys.argv[3])
    region = sys.argv[4]
    
    result = generate_budget_plan(project_name, project_type, area, region)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
