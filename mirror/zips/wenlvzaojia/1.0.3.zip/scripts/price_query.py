#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 设备价格数据库查询
功能：查询各类游乐设备的参考价格和市场行情
"""

import json
from typing import Dict, List, Optional


# 游乐设备完整价格数据库
EQUIPMENT_PRICE_DATABASE = {
    "无动力游乐设备": {
        "秋千": {
            "普通款": {"价格": "2000-3000元/套", "适用": "社区、幼儿园"},
            "标准款": {"价格": "3500-5000元/套", "适用": "公园、景区"},
            "高端款": {"价格": "5500-8000元/套", "适用": "主题乐园"}
        },
        "摇马": {
            "普通款": {"价格": "600-900元/个", "适用": "社区配套"},
            "标准款": {"价格": "1200-1800元/个", "适用": "公园广场"},
            "高端款": {"价格": "2000-3000元/个", "适用": "商业综合体"}
        },
        "跷跷板": {
            "普通款": {"价格": "1800-2500元/套", "适用": "社区配套"},
            "标准款": {"价格": "3000-4000元/套", "适用": "公园景区"},
            "高端款": {"价格": "4500-6000元/套", "适用": "主题乐园"}
        },
        "滑梯(小型5米内)": {
            "塑料款": {"价格": "3000-5000元/套", "适用": "幼儿园、社区"},
            "不锈钢款": {"价格": "5000-8000元/套", "适用": "公园、景区"},
            "高端定制": {"价格": "8000-15000元/套", "适用": "主题乐园"}
        },
        "组合滑梯(中型6-10米)": {
            "标准配置": {"价格": "3-8万元/套", "适用": "景区、公园"},
            "主题定制": {"价格": "8-15万元/套", "适用": "主题乐园"},
            "非标大型": {"价格": "15-30万元/套", "适用": "大型文旅项目"}
        },
        "爬网组合": {
            "标准爬网": {"价格": "2-5万元/套", "适用": "公园、社区"},
            "主题爬网": {"价格": "5-10万元/套", "适用": "景区配套"},
            "大型组合": {"价格": "10-20万元/套", "适用": "主题乐园"}
        },
        "沙池": {
            "普通沙池": {"价格": "5000-10000元", "适用": "社区配套"},
            "主题沙池": {"价格": "10000-20000元", "适用": "景区公园"},
            "互动沙池": {"价格": "20000-50000元", "适用": "高端乐园"}
        },
        "钻洞滑梯": {
            "标准款": {"价格": "3500-5000元/件", "适用": "公园广场"},
            "主题款": {"价格": "6000-10000元/件", "适用": "景区配套"},
            "大型组合": {"价格": "15000-30000元/件", "适用": "主题乐园"}
        },
        "跷跷板(多人)": {
            "四人款": {"价格": "5000-8000元/套", "适用": "公园配套"},
            "六人款": {"价格": "8000-12000元/套", "适用": "景区配套"},
            "轮胎款": {"价格": "10000-30000元/套", "适用": "户外探险"}
        }
    },
    "户外拓展设备": {
        "丛林穿越(穿戴式)": {
            "基础款(30米)": {"价格": "2-5万元", "单价": "600-1200元/米"},
            "标准款(100米)": {"价格": "8-15万元", "单价": "800-1500元/米"},
            "高端款(200米)": {"价格": "15-30万元", "单价": "1000-2000元/米"}
        },
        "丛林穿越(无穿戴式)": {
            "基础款(50米)": {"价格": "4-8万元", "单价": "800-1200元/米"},
            "标准款(100米)": {"价格": "10-18万元", "单价": "1000-1800元/米"},
            "高端款(200米)": {"价格": "20-35万元", "单价": "1200-2500元/米"}
        },
        "丛林魔网": {
            "基础款(50㎡)": {"价格": "2-5万元", "单价": "400-1000元/㎡"},
            "标准款(100㎡)": {"价格": "5-10万元", "单价": "500-1000元/㎡"},
            "高端款(200㎡)": {"价格": "15-25万元", "单价": "750-1250元/㎡"}
        },
        "高空绳网": {
            "标准款": {"价格": "800-3000元/㎡", "适用": "景区配套"},
            "进口款": {"价格": "1500-5000元/㎡", "适用": "高端乐园"}
        }
    },
    "网红引流设备": {
        "彩虹滑道": {
            "100米款": {"价格": "10-20万元", "适用": "景区引流"},
            "200米款": {"价格": "20-35万元", "适用": "主题乐园"},
            "300米款": {"价格": "30-50万元", "适用": "大型文旅项目"}
        },
        "高空滑索": {
            "短程款(100米内)": {"价格": "15-25万元", "适用": "景区配套"},
            "标准款(100-300米)": {"价格": "25-40万元", "适用": "景区核心项目"},
            "超长款(300米以上)": {"价格": "40-60万元", "适用": "地标性项目"}
        },
        "天空步道": {
            "标准款": {"价格": "12-20万元", "适用": "景区配套"},
            "高端款": {"价格": "20-35万元", "适用": "主题乐园"},
            "定制款": {"价格": "35-60万元", "适用": "网红打卡项目"}
        },
        "悬崖秋千": {
            "四座款": {"价格": "8-15万元", "适用": "景区引流"},
            "六座款": {"价格": "12-20万元", "适用": "核心体验项目"}
        },
        "蹦蹦云": {
            "小型款": {"价格": "3-8万元", "适用": "亲子乐园"},
            "中型款": {"价格": "8-15万元", "适用": "景区配套"},
            "大型款": {"价格": "15-30万元", "适用": "主题乐园"}
        }
    },
    "场地配套设施": {
        "EPDM安全地垫": {
            "标准型(13mm)": {"价格": "80-120元/㎡", "含": "材料+施工"},
            "加厚型(20mm)": {"价格": "120-180元/㎡", "含": "材料+施工"},
            "高端型(25mm+)": {"价格": "180-250元/㎡", "含": "材料+施工"}
        },
        "围栏护栏": {
            "普通款": {"价格": "80-150元/米", "材质": "镀锌钢"},
            "标准款": {"价格": "150-250元/米", "材质": "304不锈钢"},
            "高端款": {"价格": "250-400元/米", "材质": "316不锈钢"}
        },
        "休息亭/遮阳棚": {
            "简易款": {"价格": "5000-10000元", "适用": "基础配套"},
            "标准款": {"价格": "10000-25000元", "适用": "景区配套"},
            "景观款": {"价格": "25000-50000元", "适用": "主题乐园"}
        }
    }
}


# 材质价格说明
MATERIAL_PRICE_GUIDE = {
    "304不锈钢": {
        "特性": "耐腐蚀、强度高、环保",
        "适用": "户外游乐设备主体结构",
        "价格系数": "比普通钢材贵80%-100%"
    },
    "316L不锈钢": {
        "特性": "顶级耐腐蚀、海洋级耐盐雾",
        "适用": "海滨、高海拔等特殊环境",
        "价格系数": "比304不锈钢贵25%-40%"
    },
    "进口防腐木": {
        "特性": "天然环保、防腐等级C4以上",
        "适用": "亲近自然风格的主题乐园",
        "价格系数": "比国产防腐木贵30%-50%"
    },
    "工程塑料": {
        "特性": "色彩丰富、耐磨、安全",
        "适用": "儿童滑梯、装饰件",
        "价格系数": "比普通塑料贵30%-50%"
    }
}


def query_equipment_price(
    category: Optional[str] = None,
    equipment_name: Optional[str] = None
) -> Dict:
    """
    查询设备价格信息
    
    Args:
        category: 设备类别
        equipment_name: 设备名称
    
    Returns:
        价格信息
    """
    result = {"查询结果": {}}
    
    if category and category in EQUIPMENT_PRICE_DATABASE:
        result["查询结果"][category] = EQUIPMENT_PRICE_DATABASE[category]
    elif category == "all" or (not category and not equipment_name):
        result["查询结果"] = EQUIPMENT_PRICE_DATABASE
    else:
        # 模糊搜索
        for cat, items in EQUIPMENT_PRICE_DATABASE.items():
            for name, details in items.items():
                if equipment_name and equipment_name.lower() in name.lower():
                    if cat not in result["查询结果"]:
                        result["查询结果"][cat] = {}
                    result["查询结果"][cat][name] = details
    
    result["说明"] = "价格为参考价，实际成交价受采购量、定制程度、地区等因素影响"
    result["市场行情"] = get_market_trends()
    
    return result


def get_market_trends() -> Dict:
    """获取市场行情信息"""
    return {
        "2024-2026年趋势": {
            "整体涨幅": "5%-10%/年",
            "原材料成本": "稳中有升",
            "定制化需求": "增长明显",
            "网红设备": "热度持续"
        },
        "价格影响因素": [
            "设备规格和材质",
            "定制化程度",
            "采购批量",
            "项目地区",
            "安装施工难度",
            "品牌和厂家"
        ],
        "砍价技巧": [
            "多厂家比价",
            "整园打包采购可享折扣",
            "淡季采购价格更优",
            "选择含安装售后的厂家"
        ]
    }


def query_material_guide(material: Optional[str] = None) -> Dict:
    """
    查询材质价格指南
    
    Args:
        material: 材质名称
    
    Returns:
        材质说明
    """
    if material and material in MATERIAL_PRICE_GUIDE:
        return MATERIAL_PRICE_GUIDE[material]
    return MATERIAL_PRICE_GUIDE


def generate_price_report(equipment_list: List[Dict]) -> Dict:
    """
    生成采购价格报告
    
    Args:
        equipment_list: 设备清单 [{"name": "xxx", "quantity": 1, "spec": "标准款"}]
    
    Returns:
        价格汇总报告
    """
    report = {
        "设备清单": equipment_list,
        "价格汇总": {
            "小计": 0,
            "运输估算": 0,
            "安装估算": 0,
            "总计": 0
        },
        "议价建议": []
    }
    
    for item in equipment_list:
        name = item.get("name")
        quantity = item.get("quantity", 1)
        spec = item.get("spec", "标准款")
        
        # 查找价格
        price = _find_price(name, spec)
        if price:
            subtotal = price["单件价格"] * quantity
            report["价格汇总"]["小计"] += subtotal
        else:
            subtotal = 0
    
    # 运输费估算 (小计的3-5%)
    report["价格汇总"]["运输估算"] = report["价格汇总"]["小计"] * 0.04
    
    # 安装费估算 (小计的10-15%)
    report["价格汇总"]["安装估算"] = report["价格汇总"]["小计"] * 0.12
    
    # 总计
    report["价格汇总"]["总计"] = sum([
        report["价格汇总"]["小计"],
        report["价格汇总"]["运输估算"],
        report["价格汇总"]["安装估算"]
    ])
    
    # 议价建议
    report["议价建议"] = [
        "批量采购可争取5%-15%的折扣",
        "选择有安装售后服务的厂家可降低隐性成本",
        "签订合同前明确运输和安装费用",
        "要求提供设备合格证和安全检测报告"
    ]
    
    return report


def _find_price(name: str, spec: str) -> Optional[Dict]:
    """查找设备价格"""
    name_lower = name.lower()
    for category, items in EQUIPMENT_PRICE_DATABASE.items():
        for eq_name, details in items.items():
            if name_lower in eq_name.lower() or eq_name.lower() in name_lower:
                for grade, info in details.items():
                    if spec in grade or grade in spec:
                        # 提取价格数值
                        price_str = info.get("价格", "0")
                        try:
                            price_range = price_str.replace("万元", "0000").replace("元", "")
                            if "-" in price_range:
                                parts = price_range.split("-")
                                price = (float(parts[0]) + float(parts[1])) / 2
                            else:
                                price = float(price_range)
                            return {
                                "设备名": eq_name,
                                "规格": grade,
                                "单价说明": info.get("价格"),
                                "单件价格": price
                            }
                        except:
                            pass
    return None


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("=" * 50)
        print("游乐文旅造价通 - 设备价格查询")
        print("=" * 50)
        print("\n用法:")
        print("  python price_query.py <设备名称>")
        print("  python price_query.py --category <类别>")
        print("  python price_query.py --all")
        print("\n设备类别:")
        for cat in EQUIPMENT_PRICE_DATABASE.keys():
            print(f"  - {cat}")
        print("\n示例:")
        print("  python price_query.py 滑梯")
        print("  python price_query.py --category 网红引流设备")
        return
    
    if sys.argv[1] == "--all":
        result = query_equipment_price("all")
    elif sys.argv[1] == "--category":
        category = sys.argv[2] if len(sys.argv) > 2 else ""
        result = query_equipment_price(category)
    else:
        result = query_equipment_price(equipment_name=sys.argv[1])
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
