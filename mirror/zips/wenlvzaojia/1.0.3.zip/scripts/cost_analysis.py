#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 项目成本分析报告
功能：分析游乐项目成本结构，识别优化空间
"""

import json
from datetime import datetime
from typing import Dict, List, Optional


# 行业标准成本占比
INDUSTRY_STANDARDS = {
    "小型项目(10-30万)": {
        "设备采购": "45%-55%",
        "场地基础": "15%-20%",
        "配套设施": "15%-20%",
        "规划设计": "5%-8%",
        "安装运输": "8%-12%",
        "预备金": "8%-12%"
    },
    "中型项目(50-150万)": {
        "设备采购": "50%-60%",
        "场地基础": "12%-18%",
        "配套设施": "12%-18%",
        "规划设计": "5%-8%",
        "安装运输": "8%-10%",
        "预备金": "8%-12%"
    },
    "大型项目(150万以上)": {
        "设备采购": "55%-65%",
        "场地基础": "10%-15%",
        "配套设施": "10%-15%",
        "规划设计": "5%-8%",
        "安装运输": "6%-8%",
        "预备金": "8%-12%"
    }
}


def analyze_cost_structure(
    project_name: str,
    total_investment: float,
    cost_breakdown: Dict[str, float],
    region: str = "二线城市"
) -> Dict:
    """
    分析项目成本结构
    
    Args:
        project_name: 项目名称
        total_investment: 总投资额
        cost_breakdown: 成本明细 {"设备": xxx, "场地": xxx, ...}
        region: 地区
    
    Returns:
        成本分析报告
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    analysis = {
        "报告生成时间": timestamp,
        "项目名称": project_name,
        "总投资额": total_investment,
        "地区": region,
        "一、成本结构分析": {},
        "二、与行业标准对比": {},
        "三、优化建议": {},
        "四、风险提示": []
    }
    
    # 计算各项占比
    cost_percentages = {}
    for item, amount in cost_breakdown.items():
        pct = (amount / total_investment) * 100
        cost_percentages[item] = {
            "金额": amount,
            "占比": f"{pct:.1f}%",
            "占比值": pct
        }
    analysis["一、成本结构分析"]["各项成本明细"] = cost_percentages
    
    # 排序显示(从高到低)
    sorted_costs = sorted(cost_percentages.items(), key=lambda x: x[1]["占比值"], reverse=True)
    analysis["一、成本结构分析"]["成本排序(从高到低)"] = [
        {"项目": item, "占比": data["占比"], "金额": data["金额"]}
        for item, data in sorted_costs
    ]
    
    # 确定项目规模
    if total_investment < 300000:
        scale = "小型项目(10-30万)"
    elif total_investment < 1500000:
        scale = "中型项目(50-150万)"
    else:
        scale = "大型项目(150万以上)"
    
    # 与行业标准对比
    standards = INDUSTRY_STANDARDS[scale]
    comparison = {}
    optimization_points = []
    
    for category, pct_data in cost_percentages.items():
        actual_pct = pct_data["占比值"]
        expected_range = standards.get(category, "待定")
        
        # 解析预期范围
        if "-" in str(expected_range):
            parts = expected_range.replace("%", "").split("-")
            try:
                min_expected = float(parts[0])
                max_expected = float(parts[1])
                deviation = actual_pct - (min_expected + max_expected) / 2
                
                if actual_pct < min_expected:
                    status = "偏低 ↓"
                    suggestion = f"建议增加该部分投入，确保项目质量"
                elif actual_pct > max_expected:
                    status = "偏高 ↑"
                    suggestion = f"存在优化空间，可适当控制成本"
                else:
                    status = "正常 ✓"
                    suggestion = "处于合理区间"
                
                comparison[category] = {
                    "实际占比": f"{actual_pct:.1f}%",
                    "行业标准": expected_range,
                    "状态": status,
                    "偏离程度": f"{abs(deviation):.1f}%"
                }
                
                if status != "正常 ✓":
                    optimization_points.append({
                        "类别": category,
                        "现状": status,
                        "建议": suggestion
                    })
                    
            except:
                comparison[category] = {
                    "实际占比": f"{actual_pct:.1f}%",
                    "行业标准": expected_range,
                    "状态": "待评估"
                }
    
    analysis["二、与行业标准对比"]["对比明细"] = comparison
    analysis["二、与行业标准对比"]["项目规模"] = scale
    
    # 优化建议
    suggestions = _generate_optimization_suggestions(
        cost_percentages, 
        optimization_points,
        total_investment
    )
    analysis["三、优化建议"] = suggestions
    
    # 风险提示
    analysis["四、风险提示"] = _identify_risks(cost_percentages, total_investment, region)
    
    return analysis


def _generate_optimization_suggestions(
    cost_percentages: Dict,
    optimization_points: List,
    total_investment: float
) -> Dict:
    """生成优化建议"""
    suggestions = {
        "综合评估": "",
        "重点优化项": [],
        "具体措施": []
    }
    
    # 设备占比分析
    equipment_pct = cost_percentages.get("设备采购", {}).get("占比值", 50)
    
    if equipment_pct < 40:
        suggestions["综合评估"] = "设备投入偏低，可能影响项目吸引力和安全性"
        suggestions["重点优化项"].append("建议增加核心引流设备的投入")
    elif equipment_pct > 70:
        suggestions["综合评估"] = "设备投入占比过高，需优化其他环节"
        suggestions["重点优化项"].append("可考虑标准化设备降低定制成本")
        suggestions["重点优化项"].append("选择性价比更高的材质方案")
    else:
        suggestions["综合评估"] = "成本结构基本合理，可进一步精细化管控"
    
    # 场地投入分析
    site_pct = cost_percentages.get("场地基础", {}).get("占比值", 15)
    if site_pct > 25:
        suggestions["具体措施"].append({
            "领域": "场地建设",
            "建议": "优化场地设计，减少不必要的地形改造"
        })
    
    # 预备金分析
    reserve_pct = cost_percentages.get("预备金", {}).get("占比值", 10)
    if reserve_pct < 8:
        suggestions["具体措施"].append({
            "领域": "风险缓冲",
            "建议": "建议预留至少10%的运营预备金应对不可预见情况"
        })
    
    # 通用优化措施
    suggestions["具体措施"].extend([
        {
            "领域": "采购策略",
            "建议": "选择整园打包采购，争取5%-15%的批量折扣"
        },
        {
            "领域": "设计方案",
            "建议": "前期做好规划设计，避免后期返工造成浪费"
        },
        {
            "领域": "施工协调",
            "建议": "合理安排工期，减少因延误导致的额外成本"
        },
        {
            "领域": "维护规划",
            "建议": "选择耐用材质，降低长期维护成本"
        }
    ])
    
    return suggestions


def _identify_risks(
    cost_percentages: Dict,
    total_investment: float,
    region: str
) -> List[str]:
    """识别成本风险"""
    risks = []
    
    # 设备相关风险
    equipment_pct = cost_percentages.get("设备采购", {}).get("占比值", 50)
    if equipment_pct > 65:
        risks.append("设备投入过高，若客流不及预期，回本周期将显著延长")
    
    # 场地相关风险
    site_pct = cost_percentages.get("场地基础", {}).get("占比值", 15)
    if site_pct > 25:
        risks.append("场地改造成本偏高，需关注地形复杂度的隐性成本")
    
    # 预备金风险
    reserve_pct = cost_percentages.get("预备金", {}).get("占比值", 10)
    if reserve_pct < 8:
        risks.append("预备金不足，可能影响项目应对突发情况的能力")
    
    # 地区风险
    if region in ["一线城市", "偏远地区"]:
        risks.append(f"{region}项目需考虑特殊成本因素（地价/运输）")
    
    # 规模风险
    if total_investment < 100000:
        risks.append("投资规模较小，建议聚焦核心设备，确保引流效果")
    elif total_investment > 5000000:
        risks.append("投资规模较大，需充分论证市场容量和客流量预期")
    
    # 通用风险
    risks.extend([
        "淡旺季客流差异可能导致收入波动",
        "政策变化可能影响项目审批和运营",
        "设备安全维护需持续投入"
    ])
    
    return risks


def generate_roi_sensitivity_analysis(
    total_investment: float,
    annual_revenue: float,
    annual_operating_cost: float
) -> Dict:
    """
    生成投资回报敏感性分析
    
    Args:
        total_investment: 总投资
        annual_revenue: 年营业收入
        annual_operating_cost: 年运营成本
    
    Returns:
        敏感性分析报告
    """
    base_profit = annual_revenue - annual_operating_cost
    base_roi = (base_profit / total_investment) * 100
    base_payback = total_investment / (base_profit / 12) if base_profit > 0 else float('inf')
    
    # 敏感性场景
    scenarios = []
    
    # 收入变化
    for change in [-20, -10, 0, 10, 20]:
        new_revenue = annual_revenue * (1 + change/100)
        new_profit = new_revenue - annual_operating_cost
        new_roi = (new_profit / total_investment) * 100
        new_payback = total_investment / (new_profit / 12) if new_profit > 0 else float('inf')
        
        scenarios.append({
            "场景": f"收入{change:+d}%",
            "年营业收入": f"{new_revenue/10000:.1f}万元",
            "年净利润": f"{new_profit/10000:.1f}万元",
            "ROI": f"{new_roi:.1f}%",
            "回本周期": f"{new_payback:.0f}个月" if new_payback < 120 else "超过10年"
        })
    
    # 成本变化
    for change in [-10, -5, 0, 5, 10]:
        new_cost = annual_operating_cost * (1 + change/100)
        new_profit = annual_revenue - new_cost
        new_roi = (new_profit / total_investment) * 100
        new_payback = total_investment / (new_profit / 12) if new_profit > 0 else float('inf')
        
        scenarios.append({
            "场景": f"成本{change:+d}%",
            "年营业收入": f"{annual_revenue/10000:.1f}万元",
            "年净利润": f"{new_profit/10000:.1f}万元",
            "ROI": f"{new_roi:.1f}%",
            "回本周期": f"{new_payback:.0f}个月" if new_payback < 120 else "超过10年"
        })
    
    return {
        "基准数据": {
            "总投资": f"{total_investment/10000:.1f}万元",
            "年营业收入": f"{annual_revenue/10000:.1f}万元",
            "年运营成本": f"{annual_operating_cost/10000:.1f}万元",
            "基准ROI": f"{base_roi:.1f}%",
            "基准回本周期": f"{base_payback:.0f}个月"
        },
        "敏感性分析场景": scenarios,
        "关键发现": _find_key_insights(base_profit, base_payback)
    }


def _find_key_insights(base_profit: float, base_payback: float) -> List[str]:
    """发现关键洞察"""
    insights = []
    
    if base_profit <= 0:
        insights.append("当前模式下项目处于亏损状态，需调整收入或成本结构")
        insights.append("建议降低投资规模或提高客单价")
    elif base_payback > 36:
        insights.append(f"回本周期较长({base_payback:.0f}个月)，需充分评估市场风险")
        insights.append("建议通过差异化运营提升客流量和复购率")
    elif base_payback > 24:
        insights.append("回本周期处于中等水平，有优化空间")
        insights.append("可通过控制运营成本提升利润空间")
    else:
        insights.append(f"回本周期较短({base_payback:.0f}个月)，投资风险较低")
        insights.append("可考虑扩大投资规模以获取更高收益")
    
    return insights


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 3:
        print("=" * 50)
        print("游乐文旅造价通 - 成本分析报告")
        print("=" * 50)
        print("\n用法:")
        print("  python cost_analysis.py <项目名称> <总投资额> <设备费> <场地费> ...")
        print("\n示例:")
        print("  python cost_analysis.py 我的乐园 800000 450000 120000 80000 50000 100000")
        return
    
    project_name = sys.argv[1]
    total = float(sys.argv[2])
    
    # 解析成本明细
    cost_labels = ["设备采购", "场地基础", "配套设施", "规划设计", "安装运输", "预备金"]
    cost_breakdown = {}
    for i, label in enumerate(cost_labels):
        if i + 3 < len(sys.argv):
            cost_breakdown[label] = float(sys.argv[i + 3])
    
    result = analyze_cost_structure(project_name, total, cost_breakdown)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
