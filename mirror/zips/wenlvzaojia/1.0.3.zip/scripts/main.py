#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 主程序入口
整合所有功能模块，提供统一的命令行接口
"""

import sys
import json
from typing import Dict, List

# 导入各功能模块
try:
    from equipment_cost_calculator import (
        calculate_equipment_cost,
        calculate_land_cost,
        calculate_subsidary_cost,
        generate_full_budget
    )
    from budget_generator import (
        generate_budget_plan,
        generate_comparison_report
    )
    from price_query import (
        query_equipment_price,
        query_material_guide,
        generate_price_report
    )
    from cost_analysis import (
        analyze_cost_structure,
        generate_roi_sensitivity_analysis
    )
    from equipment_selector import (
        recommend_equipment,
        compare_equipment_by_price
    )
    from project_estimate import (
        generate_project_estimate,
        generate_estimate_from_template
    )
    MODULES_LOADED = True
except ImportError as e:
    MODULES_LOADED = False
    print(f"警告: 部分模块加载失败 - {e}")


# 功能菜单定义
FUNCTIONS = {
    "1": {
        "name": "设备造价计算",
        "description": "计算游乐设备的采购、安装、维护成本",
        "script": "equipment_cost_calculator.py",
        "usage": "python main.py calc <设备类型> [数量]"
    },
    "2": {
        "name": "项目预算生成",
        "description": "根据项目参数生成完整预算方案",
        "script": "budget_generator.py",
        "usage": "python main.py budget <项目名称> <项目类型> <面积> <地区>"
    },
    "3": {
        "name": "价格数据库查询",
        "description": "查询游乐设备参考价格和市场行情",
        "script": "price_query.py",
        "usage": "python main.py price [设备名称]"
    },
    "4": {
        "name": "成本结构分析",
        "description": "分析项目成本结构，识别优化空间",
        "script": "cost_analysis.py",
        "usage": "python main.py analyze <项目名称> <总投资> <设备费> <场地费> ..."
    },
    "5": {
        "name": "设备选型推荐",
        "description": "根据场景和预算推荐设备配置方案",
        "script": "equipment_selector.py",
        "usage": "python main.py recommend <项目类型> <预算>"
    },
    "6": {
        "name": "项目概算书生成",
        "description": "生成专业的游乐文旅项目工程概算书",
        "script": "project_estimate.py",
        "usage": "python main.py estimate <项目名称> <规模> <面积> [地点]"
    }
}


def print_banner():
    """打印横幅"""
    banner = """
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║     🎢  游乐文旅造价通  🎢                                ║
║                                                           ║
║     专业游乐设备和文旅项目造价预算解决方案                 ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
"""
    print(banner)


def print_menu():
    """打印功能菜单"""
    print("\n📋 功能菜单:\n")
    print("  " + "─" * 50)
    for key, func in FUNCTIONS.items():
        print(f"  {key}. {func['name']}")
        print(f"     └─ {func['description']}")
        print()
    print("  " + "─" * 50)
    print("\n  7. 快速预算评估 (输入项目基本信息即可获得预算)")
    print("  8. 设备清单询价 (输入设备清单获取价格汇总)")
    print("  9. 导出完整报告 (生成PDF格式的完整概算书)")
    print("\n  0. 帮助信息")
    print("  Q. 退出程序")


def print_help():
    """打印帮助信息"""
    help_text = """
╔═══════════════════════════════════════════════════════════╗
║                        使用帮助                            ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  【基础命令】                                              ║
║                                                           ║
║  python main.py calc <设备类型> [数量]                      ║
║    计算设备成本                                           ║
║    示例: python main.py calc 秋千 5                        ║
║                                                           ║
║  python main.py budget <名称> <类型> <面积> <地区>          ║
║    生成项目预算                                           ║
║    示例: python main.py budget "乐园" "景区配套" 1500 "二线城市" ║
║                                                           ║
║  python main.py price [设备名]                             ║
║    查询设备价格                                           ║
║    示例: python main.py price 滑梯                        ║
║                                                           ║
║  python main.py recommend <类型> <预算>                    ║
║    推荐设备配置                                           ║
║    示例: python main.py recommend 公园景区配套 500000     ║
║                                                           ║
║  【项目类型参考】                                          ║
║                                                           ║
║  • 社区配套     - 住宅小区、社区广场、幼儿园               ║
║  • 公园景区配套 - 城市公园、景区入口                        ║
║  • 景区核心项目 - 景区核心体验区、独立售票                  ║
║  • 主题乐园     - 独立运营的主题乐园                       ║
║  • 研学基地     - 学校研学、亲子农庄                       ║
║                                                           ║
║  【项目规模参考】                                          ║
║                                                           ║
║  • 小型 (10-30万)   - 面积100-500㎡                        ║
║  • 中型 (50-150万)  - 面积500-2000㎡                       ║
║  • 大型 (150万+)    - 面积2000㎡以上                       ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
"""
    print(help_text)


def interactive_mode():
    """交互式模式"""
    print_banner()
    
    while True:
        print_menu()
        choice = input("\n请选择功能 (输入数字或命令): ").strip()
        
        if choice == 'Q' or choice == 'q' or choice == '退出':
            print("\n感谢使用游乐文旅造价通！再见！👋\n")
            break
        
        elif choice == '0':
            print_help()
        
        elif choice == '7':
            _quick_budget_assessment()
        
        elif choice == '8':
            _equipment_inquiry()
        
        elif choice == '9':
            _export_full_report()
        
        elif choice in FUNCTIONS:
            func = FUNCTIONS[choice]
            print(f"\n📌 {func['name']}")
            print(f"   用法: {func['usage']}")
            print(f"   示例: {func['usage'].replace('main.py', 'scripts/' + func['script'])}")
        
        else:
            # 尝试解析为快捷命令
            _handle_command(choice)


def _quick_budget_assessment():
    """快速预算评估"""
    print("\n" + "=" * 50)
    print("⚡ 快速预算评估")
    print("=" * 50)
    
    print("\n请回答以下问题 (直接回车使用默认值):\n")
    
    project_name = input("  项目名称: ").strip() or "待定项目"
    
    print("\n  项目类型:")
    print("    1. 社区配套    2. 公园景区配套")
    print("    3. 景区核心项目  4. 主题乐园    5. 研学基地")
    type_choice = input("  请选择 (1-5): ").strip() or "2"
    type_map = {"1": "社区配套", "2": "公园景区配套", "3": "景区核心项目", "4": "主题乐园", "5": "研学基地"}
    project_type = type_map.get(type_choice, "公园景区配套")
    
    area = float(input("  场地面积 (平方米): ").strip() or "1000")
    
    print("\n  地区:")
    print("    1. 一线城市  2. 二线城市  3. 三线城市  4. 县城/乡镇")
    region_choice = input("  请选择 (1-4): ").strip() or "2"
    region_map = {"1": "一线城市", "2": "二线城市", "3": "三线城市", "4": "县城/乡镇"}
    region = region_map.get(region_choice, "二线城市")
    
    # 生成预算
    if MODULES_LOADED:
        result = generate_full_budget(project_type, area, region)
        print("\n" + "=" * 50)
        print("📊 预算评估结果")
        print("=" * 50)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # 简化评估
        unit_price = {"社区配套": 500, "公园景区配套": 800, "景区核心项目": 1200, "主题乐园": 2000, "研学基地": 700}
        estimate = area * unit_price.get(project_type, 800)
        print(f"\n💰 预估总投资: {estimate/10000:.1f}万元")


def _equipment_inquiry():
    """设备清单询价"""
    print("\n" + "=" * 50)
    print("📋 设备清单询价")
    print("=" * 50)
    print("\n请输入设备清单 (一行一个，输入 'done' 结束):\n")
    
    equipment_list = []
    while True:
        line = input("  设备: ").strip()
        if line.lower() == 'done':
            break
        if line:
            parts = line.split()
            if len(parts) >= 2:
                equipment_list.append({
                    "name": parts[0],
                    "quantity": int(parts[1]) if len(parts) > 1 else 1,
                    "spec": parts[2] if len(parts) > 2 else "标准款"
                })
    
    if equipment_list and MODULES_LOADED:
        result = generate_price_report(equipment_list)
        print("\n" + "=" * 50)
        print("💰 价格汇总报告")
        print("=" * 50)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif equipment_list:
        print("\n📝 设备清单已记录，等待完整报价...")


def _export_full_report():
    """导出完整报告"""
    print("\n" + "=" * 50)
    print("📄 导出完整报告")
    print("=" * 50)
    print("\n请输入项目信息:\n")
    
    project_name = input("  项目名称: ").strip() or "游乐项目"
    scale = input("  项目规模 (小型/中型/大型): ").strip() or "中型"
    area = float(input("  场地面积 (平方米): ").strip() or "1000")
    location = input("  项目地点: ").strip() or "待定"
    
    if MODULES_LOADED:
        result = generate_estimate_from_template(project_name, scale, area, location)
        print("\n" + "=" * 50)
        print("📊 项目概算书")
        print("=" * 50)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("\n⚠️ 报告生成功能需要完整模块支持")


def _handle_command(cmd: str):
    """处理命令行输入"""
    parts = cmd.split()
    if not parts:
        return
    
    command = parts[0].lower()
    args = parts[1:]
    
    if command in ['calc', 'cost']:
        if args:
            equipment = args[0]
            quantity = int(args[1]) if len(args) > 1 else 1
            result = calculate_equipment_cost(equipment, quantity)
            print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command in ['budget', 'bud']:
        if len(args) >= 3:
            name, ptype, area = args[0], args[1], float(args[2])
            region = args[3] if len(args) > 3 else "二线城市"
            result = generate_budget_plan(name, ptype, area, region)
            print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command in ['price', 'query']:
        keyword = args[0] if args else None
        result = query_equipment_price(equipment_name=keyword)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command in ['recommend', 'rec']:
        if len(args) >= 2:
            ptype, budget = args[0], float(args[1])
            result = recommend_equipment(ptype, budget, 1000)
            print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command in ['estimate', 'est']:
        if len(args) >= 3:
            name, scale, area = args[0], args[1], float(args[2])
            location = args[3] if len(args) > 3 else "待定"
            result = generate_estimate_from_template(name, scale, area, location)
            print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"\n⚠️ 未知命令: {command}")
        print("   输入 '0' 查看帮助信息")


def main():
    """主函数"""
    if len(sys.argv) > 1:
        # 命令行模式
        command = ' '.join(sys.argv[1:])
        _handle_command(command)
    else:
        # 交互模式
        interactive_mode()


if __name__ == "__main__":
    main()
