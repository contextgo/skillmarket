#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游乐文旅造价通 - 项目概算书生成器
功能：生成专业的游乐文旅项目工程概算书
"""

import json
from datetime import datetime
from typing import Dict, List, Optional


def generate_project_estimate(
    project_name: str,
    location: str,
    total_area: float,
    project_type: str,
    development_period: str,
    equipment_list: List[Dict],
    infrastructure_items: List[Dict],
    other_items: List[Dict] = None
) -> Dict:
    """
    生成完整项目概算书
    
    Args:
        project_name: 项目名称
        location: 项目地点
        total_area: 总面积(平方米)
        project_type: 项目类型
        development_period: 建设周期
        equipment_list: 设备清单 [{"名称": "", "规格": "", "数量": 1, "单价": 0}]
        infrastructure_items: 基础设施清单 [{"名称": "", "规格": "", "数量": 1, "单价": 0}]
        other_items: 其他费用清单
    
    Returns:
        完整概算书
    """
    timestamp = datetime.now().strftime("%Y-%m-%d")
    
    estimate = {
        "封面信息": {
            "项目名称": project_name,
            "项目地点": location,
            "概算日期": timestamp,
            "项目类型": project_type,
            "建设周期": development_period
        },
        "一、工程概况": _generate_project_overview(
            project_name, location, total_area, project_type, development_period
        ),
        "二、概算编制依据": _get_estimation_basis(),
        "三、投资估算汇总": {},
        "四、分项工程概算": {},
        "五、资金使用计划": {},
        "六、经济效益分析": {},
        "七、风险评估": [],
        "八、概算说明": []
    }
    
    # 计算分项工程概算
    equipment_cost = sum([item.get("数量", 1) * item.get("单价", 0) for item in equipment_list])
    infrastructure_cost = sum([item.get("数量", 1) * item.get("单价", 0) for item in infrastructure_items])
    other_cost = sum([item.get("数量", 1) * item.get("单价", 0) for item in (other_items or [])])
    
    # 安装费用 (设备价的12-15%)
    install_cost = equipment_cost * 0.13
    
    # 设计费用
    design_cost = (equipment_cost + install_cost) * 0.08
    
    # 预备金 (总价的10%)
    subtotal = equipment_cost + install_cost + infrastructure_cost + design_cost + other_cost
    reserve_fund = subtotal * 0.10
    
    # 总计
    total_investment = subtotal + reserve_fund
    
    # 分项工程概算
    estimate["四、分项工程概算"]["1.游乐设备采购"] = {
        "序号": 1,
        "工程内容": "游乐设备采购及安装",
        "计量单位": "批",
        "数量": 1,
        "单价": equipment_cost + install_cost,
        "合价": equipment_cost + install_cost,
        "占总投资比例": f"{(equipment_cost + install_cost) / total_investment * 100:.1f}%",
        "设备清单": equipment_list
    }
    
    estimate["四、分项工程概算"]["2.基础设施工程"] = {
        "序号": 2,
        "工程内容": "场地平整、道路、排水、绿化等",
        "计量单位": "批",
        "数量": 1,
        "单价": infrastructure_cost,
        "合价": infrastructure_cost,
        "占总投资比例": f"{infrastructure_cost / total_investment * 100:.1f}%",
        "项目清单": infrastructure_items
    }
    
    estimate["四、分项工程概算"]["3.其他费用"] = {
        "序号": 3,
        "工程内容": "规划设计费、其他杂费",
        "计量单位": "批",
        "数量": 1,
        "单价": design_cost + other_cost,
        "合价": design_cost + other_cost,
        "占总投资比例": f"{(design_cost + other_cost) / total_investment * 100:.1f}%"
    }
    
    # 投资估算汇总
    estimate["三、投资估算汇总"] = {
        "设备采购安装": {
            "金额": equipment_cost + install_cost,
            "占比": f"{(equipment_cost + install_cost) / total_investment * 100:.1f}%"
        },
        "基础设施工程": {
            "金额": infrastructure_cost,
            "占比": f"{infrastructure_cost / total_investment * 100:.1f}%"
        },
        "规划设计及其他": {
            "金额": design_cost + other_cost,
            "占比": f"{(design_cost + other_cost) / total_investment * 100:.1f}%"
        },
        "小计": {
            "金额": subtotal,
            "占比": "90%"
        },
        "预备金(10%)": {
            "金额": reserve_fund,
            "占比": "10%"
        },
        "工程总投资": {
            "大写": _number_to_chinese(total_investment),
            "小写": total_investment,
            "单位面积投资": f"{total_investment / total_area:.0f}元/㎡"
        }
    }
    
    # 资金使用计划
    estimate["五、资金使用计划"] = _generate_funding_schedule(
        total_investment, development_period
    )
    
    # 经济效益分析
    estimate["六、经济效益分析"] = _generate_economic_analysis(
        total_investment, project_type, total_area
    )
    
    # 风险评估
    estimate["七、风险评估"] = _assess_risks(project_type, location)
    
    # 概算说明
    estimate["八、概算说明"] = _get_estimation_notes()
    
    return estimate


def _generate_project_overview(
    project_name: str,
    location: str,
    total_area: float,
    project_type: str,
    development_period: str
) -> Dict:
    """生成工程概况"""
    return {
        "项目名称": project_name,
        "建设地点": location,
        "总用地面积": f"{total_area}平方米 ({total_area/666.7:.2f}亩)",
        "项目类型": project_type,
        "主要建设内容": [
            "无动力游乐设备区",
            "户外拓展体验区",
            "配套设施及服务区",
            "景观绿化及安全防护"
        ],
        "建设工期": development_period,
        "目标客群": _get_target_audience(project_type)
    }


def _get_target_audience(project_type: str) -> str:
    """获取目标客群"""
    audiences = {
        "社区配套": "3-8岁儿童及家长",
        "公园景区配套": "3-12岁儿童及家庭",
        "景区核心项目": "全年龄段游客",
        "主题乐园": "全年龄段家庭客群",
        "研学基地": "6-14岁儿童及教育团体"
    }
    return audiences.get(project_type, "全年龄段")


def _get_estimation_basis() -> List[str]:
    """获取概算编制依据"""
    return [
        "《建设工程工程量清单计价规范》(GB50500-2013)",
        "《游乐设施安全规范》(GB8408-2018)",
        "《儿童游乐设施安全标准》(GB6675-2014)",
        "《无动力类游乐设施技术规范》(GB/T 34272-2017)",
        "当地建设工程造价信息及市场行情",
        "类似项目投资案例及经验数据",
        "设备厂家报价及询价资料"
    ]


def _generate_funding_schedule(
    total_investment: float,
    development_period: str
) -> Dict:
    """生成资金使用计划"""
    # 简化：按建设周期平均分配
    schedule = {
        "第一阶段(前期准备)": {
            "内容": "规划设计、场地平整、基础施工",
            "投资比例": "25%",
            "金额": total_investment * 0.25
        },
        "第二阶段(主体建设)": {
            "内容": "设备采购、安装调试",
            "投资比例": "50%",
            "金额": total_investment * 0.50
        },
        "第三阶段(收尾完善)": {
            "内容": "配套设施、景观绿化、试运营",
            "投资比例": "25%",
            "金额": total_investment * 0.25
        }
    }
    return schedule


def _generate_economic_analysis(
    total_investment: float,
    project_type: str,
    area: float
) -> Dict:
    """生成经济效益分析"""
    # 估算参数
    if "社区" in project_type:
        daily_visitors = 150
        ticket_price = 30
    elif "景区" in project_type:
        daily_visitors = 400
        ticket_price = 50
    elif "主题" in project_type or "乐园" in project_type:
        daily_visitors = 800
        ticket_price = 80
    else:
        daily_visitors = 300
        ticket_price = 40
    
    annual_visitors = daily_visitors * 300
    annual_revenue = annual_visitors * ticket_price
    other_revenue = annual_revenue * 0.25  # 二消收入
    total_annual_revenue = annual_revenue + other_revenue
    
    annual_operating_cost = total_investment * 0.15
    annual_profit = total_annual_revenue - annual_operating_cost
    
    payback_months = (total_investment / annual_profit * 12) if annual_profit > 0 else 0
    roi = (annual_profit / total_investment) * 100
    
    return {
        "一、基础数据": {
            "项目总投资": f"{total_investment/10000:.2f}万元",
            "设计客流量": f"{daily_visitors}人次/日",
            "年运营天数": "300天",
            "参考门票价": f"{ticket_price}元/人"
        },
        "二、收入预测": {
            "年门票收入": f"{annual_revenue/10000:.2f}万元",
            "年二消收入": f"{other_revenue/10000:.2f}万元",
            "年营业收入合计": f"{total_annual_revenue/10000:.2f}万元"
        },
        "三、成本估算": {
            "年运营成本": f"{annual_operating_cost/10000:.2f}万元",
            "成本构成": "人员、水电、维护、营销等"
        },
        "四、效益指标": {
            "年净利润": f"{annual_profit/10000:.2f}万元",
            "投资回报率(ROI)": f"{roi:.1f}%",
            "投资回收期": f"{payback_months:.0f}个月",
            "投资利润率": f"{(annual_profit/total_investment)*100:.1f}%"
        }
    }


def _assess_risks(project_type: str, location: str) -> List[Dict]:
    """评估项目风险"""
    risks = [
        {
            "风险类别": "市场风险",
            "风险描述": "客流不及预期",
            "影响程度": "中等",
            "应对措施": "加强营销推广，开发团体客源"
        },
        {
            "风险类别": "运营风险",
            "风险描述": "设备故障或安全事故",
            "影响程度": "高",
            "应对措施": "定期维护检修，完善安全管理制度"
        },
        {
            "风险类别": "季节风险",
            "风险描述": "淡旺季客流差异",
            "影响程度": "中等",
            "应对措施": "开发室内项目，丰富四季运营内容"
        },
        {
            "风险类别": "政策风险",
            "风险描述": "行业政策变化",
            "影响程度": "低",
            "应对措施": "关注政策动态，合规经营"
        }
    ]
    
    if "偏远" in location or "乡镇" in location:
        risks.append({
            "风险类别": "选址风险",
            "风险描述": "交通不便影响客流",
            "影响程度": "中等",
            "应对措施": "加强交通指引，开发自驾游市场"
        })
    
    return risks


def _get_estimation_notes() -> List[str]:
    """获取概算编制说明"""
    return [
        "本概算为投资估算性质，实际投资以施工图预算为准",
        "设备价格参考市场行情，实际采购价以招标文件为准",
        "场地地质条件未做详细勘察，基础费用需进一步核实",
        "运营收入预测基于类似项目经验，实际收入受多种因素影响",
        "预备金用于应对不可预见情况，建议按本概算执行",
        "建议在项目实施过程中做好成本控制，定期进行投资分析"
    ]


def _number_to_chinese(num: float) -> str:
    """数字转中文大写(简化版)"""
    if num >= 100000000:
        return f"{num/100000000:.2f}亿元"
    elif num >= 10000:
        return f"{num/10000:.2f}万元"
    else:
        return f"{num:.2f}元"


def generate_estimate_from_template(
    project_name: str,
    project_scale: str,
    area: float,
    location: str
) -> Dict:
    """
    从模板快速生成概算书
    
    Args:
        project_name: 项目名称
        project_scale: 项目规模 ("小型"/"中型"/"大型")
        area: 场地面积
        location: 项目地点
    
    Returns:
        概算书
    """
    # 模板数据
    templates = {
        "小型": {
            "项目类型": "社区游乐场",
            "设备配置": [
                {"名称": "小型组合滑梯", "规格": "5米内", "数量": 1, "单价": 15000},
                {"名称": "秋千组合", "规格": "双座", "数量": 2, "单价": 3000},
                {"名称": "摇马", "规格": "标准款", "数量": 4, "单价": 1000},
                {"名称": "沙池", "规格": "15㎡", "数量": 1, "单价": 20000}
            ],
            "基础设施": [
                {"名称": "场地平整", "规格": "-", "数量": area, "单价": 30},
                {"名称": "安全地垫", "规格": "13mm", "数量": area, "单价": 100},
                {"名称": "围栏护栏", "规格": "普通", "数量": 100, "单价": 100}
            ]
        },
        "中型": {
            "项目类型": "景区配套游乐区",
            "设备配置": [
                {"名称": "组合滑梯", "规格": "8-10米", "数量": 1, "单价": 80000},
                {"名称": "大型爬网", "规格": "含多层", "数量": 1, "单价": 60000},
                {"名称": "丛林穿越", "规格": "80米", "数量": 1, "单价": 120000},
                {"名称": "沙水互动区", "规格": "25㎡", "数量": 1, "单价": 50000}
            ],
            "基础设施": [
                {"名称": "场地平整", "规格": "-", "数量": area, "单价": 50},
                {"名称": "EPDM地垫", "规格": "15mm", "数量": area, "单价": 120},
                {"名称": "景观绿化", "规格": "-", "数量": area * 0.3, "单价": 80},
                {"名称": "水电配套", "规格": "-", "数量": 1, "单价": 50000}
            ]
        },
        "大型": {
            "项目类型": "主题游乐乐园",
            "设备配置": [
                {"名称": "大型主题滑梯", "规格": "定制", "数量": 1, "单价": 300000},
                {"名称": "丛林探险区", "规格": "含多路线", "数量": 1, "单价": 400000},
                {"名称": "彩虹滑道", "规格": "150米", "数量": 1, "单价": 200000},
                {"名称": "高空滑索", "规格": "200米", "数量": 1, "单价": 250000}
            ],
            "基础设施": [
                {"名称": "场地综合整治", "规格": "-", "数量": area, "单价": 80},
                {"名称": "高端地垫系统", "规格": "20mm", "数量": area, "单价": 150},
                {"名称": "景观小品", "规格": "-", "数量": 1, "单价": 100000},
                {"名称": "智能监控系统", "规格": "-", "数量": 1, "单价": 80000}
            ]
        }
    }
    
    template = templates.get(project_scale, templates["中型"])
    
    return generate_project_estimate(
        project_name=project_name,
        location=location,
        total_area=area,
        project_type=template["项目类型"],
        development_period="6-12个月",
        equipment_list=template["设备配置"],
        infrastructure_items=template["基础设施"]
    )


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 4:
        print("=" * 50)
        print("游乐文旅造价通 - 项目概算书生成器")
        print("=" * 50)
        print("\n用法:")
        print("  python project_estimate.py <项目名称> <规模> <面积> <地点>")
        print("\n示例:")
        print('  python project_estimate.py "欢乐星球" 小型 1000 "杭州西湖区"')
        print("\n规模选项: 小型 / 中型 / 大型")
        return
    
    project_name = sys.argv[1]
    scale = sys.argv[2]
    area = float(sys.argv[3])
    location = sys.argv[4] if len(sys.argv) > 4 else "待定"
    
    result = generate_estimate_from_template(project_name, scale, area, location)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
