# Feedback 反馈组件

## Alert

| 属性          | 说明                    | 类型                               | 默认值  |
| ------------- | ----------------------- | ---------------------------------- | ------- |
| `title`       | 标题                    | `string`                           | —       |
| `type`        | 类型                    | `success / warning / info / error` | `info`  |
| `description` | 描述                    | `string`                           | —       |
| `closable`    | 可关闭                  | `boolean`                          | `false` |
| `close-text`  | 关闭文字                | `string`                           | —       |
| `show-icon`   | 显示图标                | `boolean`                          | `true`  |
| `effect`      | 主题                    | `light / dark`                     | `light` |
| `icon`        | 自定义图标              | `string / Component`               | —       |
| `small`       | 小型模式（🔧 内部扩展） | `boolean`                          | `false` |

| 事件    | 说明   |
| ------- | ------ |
| `close` | 关闭时 |

| 插槽      | 说明     |
| --------- | -------- |
| `default` | 描述内容 |
| `title`   | 标题内容 |

```vue
<template>
  <el-alert title="成功提示" type="success" show-icon />
  <el-alert
    title="警告提示"
    type="warning"
    description="详细描述"
    show-icon
    closable
  />
</template>
```

---

## Dialog

| 属性                    | 说明         | 类型                 | 默认值  |
| ----------------------- | ------------ | -------------------- | ------- | --- |
| `v-model`               | 显隐         | `boolean`            | —       |
| `title`                 | 标题         | `string`             | —       |
| `width`                 | 宽度         | `string / number`    | —       |
| `height`                | 高度         | `string / number`    | —       |
| `fullscreen`            | 全屏         | `boolean`            | `false` |
| `top`                   | 上边距       | `string`             | —       |
| `modal`                 | 遮罩         | `boolean`            | `true`  |
| `append-to-body`        | 插入 body    | `boolean`            | `false` |
| `lock-scroll`           | 锁定滚动     | `boolean`            | `true`  |
| `custom-class`          | 自定义类名   | `string`             | —       |
| `open-delay`            | 打开延迟     | `number`             | `0`     |
| `close-delay`           | 关闭延迟     | `number`             | `0`     |
| `close-on-click-modal`  | 点击遮罩关闭 | `boolean`            | `true`  |
| `close-on-press-escape` | ESC 关闭     | `boolean`            | `true`  |
| `show-close`            | 显示关闭按钮 | `boolean`            | `true`  |
| `before-close`          | 关闭前钩子   | `function`           | —       |
| `draggable`             | 可拖拽       | `boolean`            | `false` |
| `destroy-on-close`      | 关闭销毁     | `boolean`            | `false` |
| `z-index`               | 层级         | `number`             | —       |
| `modalClass`            | 遮罩类名     | `string`             | —       |
| `trapFocus`             | 焦点陷阱     | `boolean`            | `false` | ⚠️  |
| `type`                  | 类型         | `string`             | —       | 🔧  |
| `icon`                  | 图标         | `string / Component` | —       | 🔧  |
| `autoSize`              | 自动尺寸     | `boolean`            | `false` | 🔧  |
| `close-icon`            | 关闭图标     | `string / Component` | —       | 🔧  |

| 事件               | 说明         |
| ------------------ | ------------ |
| `open`             | 打开         |
| `opened`           | 打开后       |
| `close`            | 关闭         |
| `closed`           | 关闭后       |
| `open-auto-focus`  | 打开自动聚焦 |
| `close-auto-focus` | 关闭自动聚焦 |

| 插槽      | 说明              |
| --------- | ----------------- |
| `default` | 内容              |
| `header`  | 头部              |
| `footer`  | 底部              |
| `title`   | 标题（header 内） |

```vue
<template>
  <el-dialog v-model="visible" title="标题" width="500px">
    内容
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary">确认</el-button>
    </template>
  </el-dialog>
</template>
```

---

## Drawer

| 属性                    | 说明         | 类型                    | 默认值  |
| ----------------------- | ------------ | ----------------------- | ------- | --- |
| `v-model`               | 显隐         | `boolean`               | —       |
| `title`                 | 标题         | `string`                | —       |
| `size`                  | 尺寸         | `string / number`       | `30%`   |
| `direction`             | 方向         | `rtl / ltr / ttb / btt` | `rtl`   |
| `modal`                 | 遮罩         | `boolean`               | `true`  |
| `modalFade`             | 遮罩淡入淡出 | `boolean`               | `true`  | 🔧  |
| `append-to-body`        | 插入 body    | `boolean`               | `false` |
| `lock-scroll`           | 锁定滚动     | `boolean`               | `true`  |
| `custom-class`          | 自定义类名   | `string`                | —       |
| `open-delay`            | 打开延迟     | `number`                | `0`     |
| `close-delay`           | 关闭延迟     | `number`                | `0`     |
| `close-on-click-modal`  | 点击遮罩关闭 | `boolean`               | `true`  |
| `close-on-press-escape` | ESC 关闭     | `boolean`               | `true`  |
| `show-close`            | 显示关闭按钮 | `boolean`               | `true`  |
| `before-close`          | 关闭前钩子   | `function`              | —       |
| `destroy-on-close`      | 关闭销毁     | `boolean`               | `false` |
| `z-index`               | 层级         | `number`                | —       |
| `with-header`           | 显示头部     | `boolean`               | `true`  | 🔧  |
| `close-icon`            | 关闭图标     | `string / Component`    | —       | 🔧  |

| 事件               | 说明         |
| ------------------ | ------------ |
| `open`             | 打开         |
| `opened`           | 打开后       |
| `close`            | 关闭         |
| `closed`           | 关闭后       |
| `open-auto-focus`  | 打开自动聚焦 |
| `close-auto-focus` | 关闭自动聚焦 |

| 插槽      | 说明              |
| --------- | ----------------- |
| `default` | 内容              |
| `header`  | 头部              |
| `footer`  | 底部              |
| `title`   | 标题（header 内） |

```vue
<template>
  <el-drawer v-model="visible" title="标题" size="50%"> 内容 </el-drawer>
</template>
```

---

## Tooltip

| 属性                          | 说明          | 类型                                  | 默认值           |
| ----------------------------- | ------------- | ------------------------------------- | ---------------- | --- |
| `content`                     | 内容          | `string`                              | —                |
| `raw-content`                 | 原始 HTML     | `boolean`                             | `false`          |
| `placement`                   | 位置          | `string`                              | `bottom`         |
| `visible` / `v-model:visible` | 显隐          | `boolean`                             | —                |
| `disabled`                    | 禁用          | `boolean`                             | `false`          |
| `offset`                      | 偏移          | `number`                              | `12`             |
| `transition`                  | 过渡动画      | `string`                              | `fade-in-linear` |
| `popper-class`                | 弹出类名      | `string`                              | —                |
| `popper-options`              | popper 配置   | `object`                              | —                |
| `show-after`                  | 显示延迟      | `number`                              | `0`              |
| `hide-after`                  | 隐藏延迟      | `number`                              | `200`            |
| `auto-close`                  | 自动关闭      | `number`                              | `0`              |
| `show-arrow`                  | 显示箭头      | `boolean`                             | `true`           |
| `persistent`                  | 持久化        | `boolean`                             | `true`           |
| `trigger`                     | 触发方式      | `hover / click / focus / contextmenu` | `hover`          |
| `virtual-triggering`          | 虚拟触发      | `boolean`                             | `false`          |
| `virtual-ref`                 | 虚拟引用      | `HTMLElement`                         | —                |
| `teleported`                  | 是否 teleport | `boolean`                             | `true`           |
| `aria-label`                  | 无障碍标签    | `string`                              | —                |
| `enterable`                   | 鼠标可进入    | `boolean`                             | `true`           |
| `type`                        | 类型          | `string`                              | —                | 🔧  |
| `icon`                        | 图标          | `string / Component`                  | —                | 🔧  |

| 事件          | 说明   |
| ------------- | ------ |
| `show`        | 显示   |
| `hide`        | 隐藏   |
| `before-show` | 显示前 |
| `before-hide` | 隐藏前 |

| 插槽      | 说明       |
| --------- | ---------- |
| `default` | 触发内容   |
| `content` | 自定义内容 |

```vue
<template>
  <el-tooltip content="提示内容" placement="top">
    <el-button>悬浮提示</el-button>
  </el-tooltip>
</template>
```

---

## Popover

| 属性                          | 说明          | 类型                                  | 默认值           |
| ----------------------------- | ------------- | ------------------------------------- | ---------------- |
| `content`                     | 内容          | `string`                              | —                |
| `title`                       | 标题          | `string`                              | —                |
| `width`                       | 宽度          | `string / number`                     | `200`            |
| `placement`                   | 位置          | `string`                              | `bottom`         |
| `disabled`                    | 禁用          | `boolean`                             | `false`          |
| `offset`                      | 偏移          | `number`                              | —                |
| `trigger`                     | 触发方式      | `click / focus / hover / contextmenu` | `hover`          |
| `visible` / `v-model:visible` | 显隐          | `boolean`                             | —                |
| `show-arrow`                  | 显示箭头      | `boolean`                             | `true`           |
| `popper-class`                | 弹出类名      | `string`                              | —                |
| `popper-style`                | 弹出样式      | `object`                              | —                |
| `show-after`                  | 显示延迟      | `number`                              | `0`              |
| `hide-after`                  | 隐藏延迟      | `number`                              | `200`            |
| `auto-close`                  | 自动关闭      | `number`                              | `0`              |
| `persistent`                  | 持久化        | `boolean`                             | `true`           |
| `teleported`                  | 是否 teleport | `boolean`                             | `true`           |
| `transition`                  | 过渡动画      | `string`                              | `fade-in-linear` |
| `virtual-triggering`          | 虚拟触发      | `boolean`                             | `false`          |
| `virtual-ref`                 | 虚拟引用      | `HTMLElement`                         | —                |
| `tabindex`                    | tabindex      | `number / string`                     | —                |

| 事件           | 说明   |
| -------------- | ------ |
| `before-enter` | 进入前 |
| `before-leave` | 离开前 |
| `after-enter`  | 进入后 |
| `after-leave`  | 离开后 |

| 插槽        | 说明                   |
| ----------- | ---------------------- |
| `default`   | 触发内容               |
| `reference` | 触发内容（同 default） |

```vue
<template>
  <el-popover title="标题" content="内容" placement="top">
    <template #reference>
      <el-button>点击弹出</el-button>
    </template>
  </el-popover>
</template>
```

---

## Popconfirm

| 属性                  | 说明          | 类型                 | 默认值                            |
| --------------------- | ------------- | -------------------- | --------------------------------- | --- |
| `title`               | 标题          | `string`             | —                                 |
| `confirm-button-text` | 确认按钮文字  | `string`             | —                                 |
| `cancel-button-text`  | 取消按钮文字  | `string`             | —                                 |
| `confirm-button-type` | 确认按钮类型  | `string`             | `primary`                         |
| `cancel-button-type`  | 取消按钮类型  | `string`             | `''`                              |
| `icon`                | 图标          | `string / Component` | `'icon-base-error-circle-filled'` |
| `hide-icon`           | 隐藏图标      | `boolean`            | `false`                           |
| `hide-after`          | 隐藏延迟      | `number`             | `200`                             |
| `teleported`          | 是否 teleport | `boolean`            | `true`                            |
| `persistent`          | 持久化        | `boolean`            | `true`                            |
| `width`               | 宽度          | `string / number`    | `200`                             |
| `onConfirm`           | 确认回调      | `function`           | —                                 | 🔄  |
| `onCancel`            | 取消回调      | `function`           | —                                 | 🔄  |

| 事件 | 说明 |
| ---- | ---- |

**回调函数（非事件）**：通过 `onConfirm` / `onCancel` 属性传入回调处理确认/取消

| 插槽        | 说明                                                |
| ----------- | --------------------------------------------------- |
| `reference` | 触发内容                                            |
| `footer`    | 自定义操作区（带 `confirm` 和 `cancel` 作用域参数） |

```vue
<template>
  <el-popconfirm title="确定删除吗？" :onConfirm="handleDelete">
    <template #reference>
      <el-button type="danger">删除</el-button>
    </template>
  </el-popconfirm>
</template>
```

---

## Notice

🔧 自定义组件，详细文档见 `notice.md`。

```vue
<template>
  <el-notice v-model:expand="isExpand" :data="noticeList" persistence />
</template>
```
