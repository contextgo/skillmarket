# 表单场景

表单页是后台系统最常见的页面类型之一。本文档覆盖表单的结构搭建、控件组合、校验规则、复杂表单拆分等完整实践。

---

## 基础表单结构

```vue
<script setup lang="ts">
import type { FormInstance, FormRules } from '@hgj/element-plus'

const formRef = ref<FormInstance>()

const form = reactive({
  name: '',
  type: '',
  status: 'active',
})

const rules: FormRules = {
  name: [
    { required: true, message: '名称必填', trigger: 'blur' },
    { max: 50, message: '最多50个字符', trigger: 'blur' },
  ],
  type: [{ required: true, message: '类型必填', trigger: 'change' }],
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  await api.create(form)
  ElMessage.success('提交成功')
}

function handleReset() {
  formRef.value?.resetFields()
}
</script>

<template>
  <el-card-form>
    <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" placeholder="请输入名称" />
      </el-form-item>

      <el-form-item label="类型" prop="type">
        <el-select v-model="form.type" placeholder="请选择">
          <el-option label="类型A" value="A" />
          <el-option label="类型B" value="B" />
        </el-select>
      </el-form-item>

      <el-form-item label="状态" prop="status">
        <el-radio-group v-model="form.status">
          <el-radio label="active">启用</el-radio>
          <el-radio label="inactive">禁用</el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="handleSubmit">提交</el-button>
        <el-button @click="handleReset">重置</el-button>
      </el-form-item>
    </el-form>
  </el-card-form>
</template>
```

---

## 常用控件组合

### 文本输入

```vue
<el-form-item label="名称" prop="name">
  <el-input v-model="form.name" placeholder="请输入" clearable />
</el-form-item>
```

### 选择器

```vue
<el-form-item label="类型" prop="type">
  <el-select v-model="form.type" placeholder="请选择" clearable>
    <el-option label="类型A" value="A" />
    <el-option label="类型B" value="B" />
  </el-select>
</el-form-item>
```

### 多选

```vue
<el-form-item label="权限" prop="permissions">
  <el-checkbox-group v-model="form.permissions">
    <el-checkbox label="read">读</el-checkbox>
    <el-checkbox label="write">写</el-checkbox>
  </el-checkbox-group>
</el-form-item>
```

### 日期范围

```vue
<el-form-item label="日期" prop="dateRange">
  <el-date-picker v-model="form.dateRange" type="daterange" />
</el-form-item>
```

### 数字输入

```vue
<el-form-item label="数量" prop="count">
  <el-input-number v-model="form.count" :min="0" :max="100" />
</el-form-item>
```

### 开关

```vue
<el-form-item label="启用" prop="enabled">
  <el-switch v-model="form.enabled" />
</el-form-item>
```

---

## 校验规则

### 常用规则速查

```ts
const rules: FormRules = {
  // 必填
  name: [{ required: true, message: '名称必填', trigger: 'blur' }],

  // 长度限制
  name: [
    { required: true, message: '名称必填', trigger: 'blur' },
    { min: 2, max: 50, message: '长度2-50字符', trigger: 'blur' },
  ],

  // 正则校验
  phone: [
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式错误', trigger: 'blur' },
  ],

  // 自定义校验器
  amount: [
    {
      validator: (rule, value, callback) => {
        if (value <= 0) callback(new Error('金额必须大于0'))
        else callback()
      },
      trigger: 'blur',
    },
  ],

  // 异步校验
  email: [
    {
      asyncValidator: async (rule, value) => {
        const exists = await api.checkEmail(value)
        if (exists) throw new Error('邮箱已存在')
      },
      trigger: 'blur',
    },
  ],
}
```

### 联动校验

当 A 字段的值影响 B 字段的校验规则时，在 A 的 change 事件中手动触发 B 的校验：

```vue
<script setup>
function handleTypeChange() {
  formRef.value?.validateField('subType')
}
</script>

<template>
  <el-form-item label="主类型" prop="type">
    <el-select v-model="form.type" @change="handleTypeChange">
      <el-option label="A" value="A" />
      <el-option label="B" value="B" />
    </el-select>
  </el-form-item>
  <el-form-item label="子类型" prop="subType">
    <el-select v-model="form.subType">
      <el-option
        v-for="item in subTypeOptions"
        :key="item.value"
        :label="item.label"
        :value="item.value"
      />
    </el-select>
  </el-form-item>
</template>
```

---

## 复杂表单拆分

当表单字段较多时，拆分为多个 `el-card-form` 区块：

```vue
<template>
  <el-card-form>
    <h3>基本信息</h3>
    <el-form :model="form" :rules="rules">
      <!-- 基础字段 -->
    </el-form>
  </el-card-form>

  <el-card-form>
    <h3>扩展配置</h3>
    <el-form :model="form" :rules="rules">
      <!-- 扩展字段 -->
    </el-form>
  </el-card-form>
</template>
```

**要点**：

- 每个区块可独立设置 `label-width`
- 提交时统一校验所有 `el-form` 实例
- 重置时逐个调用 `resetFields()`

---

## 动态表单

根据条件动态增删表单项：

```vue
<script setup>
const dynamicFields = ref([{ key: Date.now(), value: '' }])

function addField() {
  dynamicFields.value.push({ key: Date.now(), value: '' })
}

function removeField(index) {
  dynamicFields.value.splice(index, 1)
}
</script>

<template>
  <el-form :model="form">
    <div v-for="(field, index) in dynamicFields" :key="field.key">
      <el-form-item :label="`字段${index + 1}`">
        <el-input v-model="field.value" />
        <el-button type="danger" link @click="removeField(index)"
          >删除</el-button
        >
      </el-form-item>
    </div>
    <el-button type="primary" link @click="addField">添加字段</el-button>
  </el-form>
</template>
```

---

## 表单与弹窗组合

弹窗内嵌表单是常见模式。使用 `dialog-wrapper` 实现 Promise 式调用：

```vue
<!-- MyFormDialog.vue -->
<script setup>
const props = defineProps({ initialData: Object })
const emits = defineEmits(['resolve', 'reject'])

const formRef = ref()
const form = reactive({ ...props.initialData })
const rules = { name: [{ required: true, message: '必填' }] }

async function handleConfirm() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  emits('resolve', { ...form })
}
</script>

<template>
  <el-dialog
    :model-value="true"
    title="编辑"
    @close="emits('reject', { reason: 'cancel' })"
  >
    <el-form ref="formRef" :model="form" :rules="rules">
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="emits('reject', { reason: 'cancel' })">取消</el-button>
      <el-button type="primary" @click="handleConfirm">确认</el-button>
    </template>
  </el-dialog>
</template>
```

调用方：

```ts
import { openDialog } from '@hgj/element-plus'
import MyFormDialog from './MyFormDialog.vue'

async function handleEdit() {
  try {
    const result = await openDialog(MyFormDialog, { initialData: { name: '' } })
    await api.update(result)
    ElMessage.success('更新成功')
  } catch {
    // 用户取消
  }
}
```
