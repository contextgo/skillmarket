# 页签导航场景

页签用于在同一视图内切换不同内容区域或管理动态业务页签。

---

## 业务页签（TabsPro）

适用于一级菜单下的动态业务页签，支持溢出替换和程序化增删。

### 基础用法

```vue
<script setup>
const activeTab = ref('all')
const tabs = ref([
  { label: '全部', name: 'all', closable: false },
  { label: '待审批', name: 'pending', closable: true },
  { label: '已审批', name: 'approved', closable: true },
])

function handleAddTab() {
  tabsProRef.value?.addTab({ label: '新页签', name: Date.now() })
}

function handleRemoveTab(name) {
  tabsProRef.value?.removeTab(name)
}
</script>

<template>
  <el-tabs-pro
    ref="tabsProRef"
    v-model="activeTab"
    v-model:tabs="tabs"
    @tab-remove="handleRemoveTab"
  />
</template>
```

### 属性

| 名称                      | 说明                   | 类型              | 默认值 |
| ------------------------- | ---------------------- | ----------------- | ------ |
| `v-model` / `model-value` | 当前激活页签的 `name`  | `string / number` | —      |
| `v-model:tabs` / `tabs`   | 页签数据数组           | `TabsProItem[]`   | `[]`   |
| `min-item-width`          | 单个页签最小宽度（px） | `number`          | `80`   |
| `max-item-width`          | 单个页签最大宽度（px） | `number`          | `220`  |

### TabsProItem 结构

```ts
interface TabsProItem {
  label: string
  name: string | number
  closable?: boolean // 默认 true
  disabled?: boolean // 默认 false
}
```

### 事件

| 名称          | 说明         | 回调参数       |
| ------------- | ------------ | -------------- |
| `change`      | 激活页签变化 | `(name, tab)`  |
| `tab-click`   | 点击页签     | `(tab, event)` |
| `tab-remove`  | 删除页签     | `(name, tab)`  |
| `tabs-change` | 页签数组变化 | `(tabs)`       |

### 实例方法

```ts
// 新增页签；若 name 已存在则更新并移动到可视区最后
addTab(tab: TabsProItem, options?): TabsProItem

// 删除指定页签
removeTab(name: string | number): boolean

// 激活指定页签；若该页签在 ... 中会移动到可视区最后
setActive(name: string | number): boolean

// 获取当前页签列表
getTabs(): TabsProItem[]

// 容器宽度变化后手动刷新布局
refresh(): void
```

### 溢出替换算法

当宽度不足时，组件展示 `前 N-1 个可视页签 + 最后一个页签`，中间剩余页签进入 `...`。点击 `...` 内的页签后，会与当前可视区最后一个页签交换位置。

---

## 内容切换（Tabs）

适用于同一页面内的固定内容分区切换。

```vue
<template>
  <el-tabs v-model="activeTab">
    <el-tab-pane label="基本信息" name="basic">...</el-tab-pane>
    <el-tab-pane label="操作日志" name="log">...</el-tab-pane>
    <el-tab-pane label="权限配置" name="permission">...</el-tab-pane>
  </el-tabs>
</template>
```

### Tabs 常用属性

| 属性           | 说明                       | 类型                          | 默认值             |
| -------------- | -------------------------- | ----------------------------- | ------------------ |
| `v-model`      | 绑定值（选中 tab 的 name） | `string / number`             | 第一个 tab 的 name |
| `type`         | 页签类型                   | `'' / 'card' / 'border-card'` | `''`               |
| `tab-position` | 页签位置                   | `top / right / bottom / left` | `top`              |
| `stretch`      | 页签宽度是否自撑开         | `boolean`                     | `false`            |
| `closable`     | 页签是否可关闭             | `boolean`                     | `false`            |
| `addable`      | 页签是否可增加             | `boolean`                     | `false`            |

### TabPane 常用属性

| 属性       | 说明         | 类型              |
| ---------- | ------------ | ----------------- |
| `label`    | 页签标题     | `string`          |
| `name`     | 页签名       | `string / number` |
| `disabled` | 是否禁用     | `boolean`         |
| `closable` | 是否可关闭   | `boolean`         |
| `lazy`     | 是否延迟渲染 | `boolean`         |

---

## 选择建议

| 场景                                 | 推荐组件                                     |
| ------------------------------------ | -------------------------------------------- |
| 一级菜单下的动态业务页签（可增删）   | **TabsPro**                                  |
| 同一页面内的内容分区切换（固定页签） | Tabs                                         |
| 需要卡片样式页签                     | Tabs（`type="card"` / `type="border-card"`） |
| 需要侧边页签                         | Tabs（`tab-position="left"`）                |
