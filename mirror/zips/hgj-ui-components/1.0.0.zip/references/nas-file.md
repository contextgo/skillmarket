# NasFile

**注册名**：`ElNasFile`（方法导出）| **使用**：`import { NasFile } from '@hgj/element-plus'`

NAS 文件操作工具，用于生成下载/预览地址并完成文件操作。

---

## 前置配置

必须通过 `ElConfigProvider` 传入 `nas.env`：

```vue
<template>
  <el-config-provider :nas="{ env: 'dev' }">
    <App />
  </el-config-provider>
</template>
```

`env` 可选值：`dev` / `beta` / `prod`

## 方法

| 方法名           | 说明                       | 签名                                                 |
| ---------------- | -------------------------- | ---------------------------------------------------- |
| `getDownloadUrl` | 获取文件代理下载地址       | `(nasKey: string) => string`                         |
| `getPreviewUrl`  | 获取文件预览地址           | `(nasKey: string) => string`                         |
| `preview`        | 直接打开文件预览页         | `(nasKey: string, ...args) => WindowProxy \| null`   |
| `getRealAddress` | 获取文件真实地址           | `(nasKey: string, options?) => Promise<string>`      |
| `fetch`          | 获取文件二进制内容及元信息 | `(nasKey: string, options?) => Promise<FetchedFile>` |
| `download`       | 下载文件                   | `(nasKey: string, options?) => Promise<void>`        |
| `downloadBlob`   | 下载 Blob 为文件           | `(blob: Blob, fileName: string) => void`             |

## DownloadFileOptions

| 属性             | 说明                             | 类型              | 默认值  |
| ---------------- | -------------------------------- | ----------------- | ------- |
| `downloadMethod` | 下载方式：`url` 或 `blob`        | `'url' \| 'blob'` | `'url'` |
| `fileName`       | 手动指定下载文件名               | `string`          | —       |
| `target`         | `url` 模式下透传给 `window.open` | `string`          | —       |
| `features`       | `url` 模式下透传给 `window.open` | `string`          | —       |
