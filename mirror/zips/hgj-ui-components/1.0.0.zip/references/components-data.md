# Data 数据展示组件

## Table / TableColumn

### Table 属性

| 属性                      | 说明             | 类型                      | 默认值  |
| ------------------------- | ---------------- | ------------------------- | ------- |
| `data`                    | 数据             | `array`                   | `[]`    |
| `height`                  | 高度             | `string / number`         | —       |
| `max-height`              | 最大高度         | `string / number`         | —       |
| `stripe`                  | 斑马纹           | `boolean`                 | `false` |
| `border`                  | 边框             | `boolean`                 | `false` |
| `size`                    | 尺寸             | `large / default / small` | —       |
| `fit`                     | 列宽自适应       | `boolean`                 | `true`  |
| `show-header`             | 显示表头         | `boolean`                 | `true`  |
| `highlight-current-row`   | 高亮当前行       | `boolean`                 | `false` |
| `current-row-key`         | 当前行 key       | `string / number`         | —       |
| `row-class-name`          | 行类名           | `string / function`       | —       |
| `row-style`               | 行样式           | `object / function`       | —       |
| `cell-class-name`         | 单元格类名       | `string / function`       | —       |
| `cell-style`              | 单元格样式       | `object / function`       | —       |
| `header-row-class-name`   | 表头行类名       | `string / function`       | —       |
| `header-row-style`        | 表头行样式       | `object / function`       | —       |
| `header-cell-class-name`  | 表头单元格类名   | `string / function`       | —       |
| `header-cell-style`       | 表头单元格样式   | `object / function`       | —       |
| `row-key`                 | 行 key           | `string / function`       | —       |
| `empty-text`              | 空数据文本       | `string`                  | —       |
| `default-expand-all`      | 默认展开全部     | `boolean`                 | `false` |
| `expand-row-keys`         | 展开行 keys      | `array`                   | —       |
| `default-sort`            | 默认排序         | `object`                  | —       |
| `tooltip-effect`          | tooltip 主题     | `string`                  | `dark`  |
| `show-summary`            | 显示合计         | `boolean`                 | `false` |
| `sum-text`                | 合计文本         | `string`                  | —       |
| `summary-method`          | 合计方法         | `function`                | —       |
| `span-method`             | 合并单元格方法   | `function`                | —       |
| `select-on-indeterminate` | 全选时选中子节点 | `boolean`                 | `true`  |
| `indent`                  | 树表缩进         | `number`                  | `16`    |
| `lazy`                    | 懒加载           | `boolean`                 | `false` |
| `load`                    | 加载方法         | `function`                | —       |
| `tree-props`              | 树表配置         | `object`                  | —       |
| `table-layout`            | 表格布局         | `auto / fixed`            | `fixed` |
| `scrollbar-always-on`     | 滚动条常显       | `boolean`                 | `false` |
| `show-overflow-tooltip`   | 溢出 tooltip     | `boolean / object`        | —       |
| `flexible`                | 主容器宽度自适应 | `boolean`                 | `false` |

### Table 事件

| 事件                 | 说明           |
| -------------------- | -------------- |
| `select`             | 勾选           |
| `select-all`         | 全选           |
| `selection-change`   | 选择变化       |
| `cell-mouse-enter`   | 鼠标移入单元格 |
| `cell-mouse-leave`   | 鼠标移出单元格 |
| `cell-click`         | 点击单元格     |
| `cell-dblclick`      | 双击单元格     |
| `cell-contextmenu`   | 右键单元格     |
| `row-click`          | 点击行         |
| `row-contextmenu`    | 右键行         |
| `row-dblclick`       | 双击行         |
| `header-click`       | 点击表头       |
| `header-contextmenu` | 右键表头       |
| `sort-change`        | 排序变化       |
| `filter-change`      | 筛选变化       |
| `current-change`     | 当前行变化     |
| `header-dragend`     | 拖拽表头结束   |
| `expand-change`      | 展开行变化     |

### Table 方法

| 方法                 | 说明         |
| -------------------- | ------------ |
| `clearSelection`     | 清空选择     |
| `toggleRowSelection` | 切换行选择   |
| `toggleAllSelection` | 切换全选     |
| `toggleRowExpansion` | 切换行展开   |
| `setCurrentRow`      | 设置当前行   |
| `clearSort`          | 清空排序     |
| `clearFilter`        | 清空筛选     |
| `doLayout`           | 重新布局     |
| `sort`               | 排序         |
| `scrollTo`           | 滚动         |
| `setScrollTop`       | 设置纵向滚动 |
| `setScrollLeft`      | 设置横向滚动 |
| `columns`            | 获取列       |

### TableColumn 属性

| 属性                    | 说明         | 类型                         | 默认值  |
| ----------------------- | ------------ | ---------------------------- | ------- |
| `type`                  | 类型         | `selection / index / expand` | —       |
| `index`                 | 序号         | `number / function`          | —       |
| `label`                 | 标题         | `string`                     | —       |
| `column-key`            | 列 key       | `string`                     | —       |
| `prop`                  | 字段名       | `string`                     | —       |
| `width`                 | 宽度         | `string / number`            | —       |
| `min-width`             | 最小宽度     | `string / number`            | —       |
| `fixed`                 | 固定         | `left / right`               | —       |
| `render-header`         | 自定义表头   | `function`                   | —       |
| `sortable`              | 可排序       | `boolean / string`           | `false` |
| `sort-method`           | 排序方法     | `function`                   | —       |
| `sort-by`               | 排序字段     | `string / array / function`  | —       |
| `sort-orders`           | 排序顺序     | `array`                      | —       |
| `resizable`             | 可调整列宽   | `boolean`                    | `true`  |
| `formatter`             | 格式化       | `function`                   | —       |
| `show-overflow-tooltip` | 溢出 tooltip | `boolean / object`           | —       |
| `align`                 | 对齐         | `left / center / right`      | `left`  |
| `header-align`          | 表头对齐     | `left / center / right`      | —       |
| `class-name`            | 类名         | `string`                     | —       |
| `label-class-name`      | 表头类名     | `string`                     | —       |
| `selectable`            | 可选         | `function`                   | —       |
| `reserve-selection`     | 保留选择     | `boolean`                    | `false` |
| `filters`               | 筛选选项     | `array`                      | —       |
| `filter-placement`      | 筛选菜单位置 | `string`                     | —       |
| `filter-multiple`       | 多选筛选     | `boolean`                    | `true`  |
| `filter-method`         | 筛选方法     | `function`                   | —       |
| `filtered-value`        | 筛选值       | `array`                      | —       |

```vue
<template>
  <el-table :data="tableData" row-key="id" style="width: 100%">
    <el-table-column type="selection" width="55" />
    <el-table-column prop="name" label="名称" />
    <el-table-column prop="status" label="状态" />
    <el-table-column prop="amount" label="金额" align="right" />
  </el-table>
</template>
```

---

## XTable

🔧 自定义组件，详细文档见 `x-table.md`。

简要说明：完全自研的配置驱动表格，内置虚拟滚动、行编辑、树形数据、拖拽排序等高级能力。

```vue
<template>
  <el-x-table :columns="columns" :data="data" row-key="id" />
</template>
```

---

## Pagination

| 属性                   | 说明                                  | 类型       | 默认值                                   |
| ---------------------- | ------------------------------------- | ---------- | ---------------------------------------- |
| `v-model:current-page` | 当前页                                | `number`   | `1`                                      |
| `v-model:page-size`    | 每页条数                              | `number`   | `10`                                     |
| `page-sizes`           | 每页条数选项                          | `number[]` | `[10, 20, 30, 40, 50, 100]`              |
| `total`                | 总条数                                | `number`   | —                                        |
| `pager-count`          | 页码按钮数                            | `number`   | `7`                                      |
| `layout`               | 布局                                  | `string`   | `'prev, pager, next, jumper, ->, total'` |
| `disabled`             | 禁用                                  | `boolean`  | `false`                                  |
| `hide-on-single-page`  | 单页隐藏                              | `boolean`  | `false`                                  |
| `small`                | 小型                                  | `boolean`  | `false`                                  |
| `bordered`             | 带边框（🔧 内部扩展，开源版无此属性） | `boolean`  | `true`                                   |
| `prevText`             | 上一页文字                            | `string`   | —                                        |
| `nextText`             | 下一页文字                            | `string`   | —                                        |
| `popperClass`          | 弹出层类名                            | `string`   | —                                        |

| 事件             | 说明         |
| ---------------- | ------------ |
| `size-change`    | 每页条数变化 |
| `current-change` | 当前页变化   |
| `prev-click`     | 上一页       |
| `next-click`     | 下一页       |

```vue
<template>
  <el-pagination
    v-model:current-page="page"
    v-model:page-size="pageSize"
    :total="total"
    :page-sizes="[10, 20, 50, 100]"
    layout="total, sizes, prev, pager, next, jumper"
  />
</template>
```

---

## Skeleton / SkeletonItem

| 属性       | 说明     | 类型      | 默认值  |
| ---------- | -------- | --------- | ------- |
| `animated` | 动画     | `boolean` | `false` |
| `count`    | 渲染数量 | `number`  | `1`     |
| `rows`     | 行数     | `number`  | `3`     |
| `throttle` | 延迟加载 | `number`  | `0`     |

```vue
<template>
  <el-skeleton :rows="5" animated />
  <el-skeleton-item variant="image" />
</template>
```

---

## Empty

| 属性          | 说明     | 类型     |
| ------------- | -------- | -------- |
| `image`       | 图片地址 | `string` |
| `image-size`  | 图片大小 | `number` |
| `description` | 描述     | `string` |

```vue
<template>
  <el-empty description="暂无数据" />
</template>
```

---

## Result

| 属性        | 说明     | 类型                               |
| ----------- | -------- | ---------------------------------- |
| `title`     | 标题     | `string`                           |
| `sub-title` | 副标题   | `string`                           |
| `icon`      | 图标类型 | `success / warning / info / error` |

| 插槽        | 说明         |
| ----------- | ------------ |
| `icon`      | 自定义图标   |
| `title`     | 自定义标题   |
| `sub-title` | 自定义副标题 |
| `extra`     | 底部额外内容 |

```vue
<template>
  <el-result icon="success" title="提交成功" sub-title="请等待审核">
    <template #extra>
      <el-button type="primary">返回</el-button>
    </template>
  </el-result>
</template>
```

---

## Descriptions / DescriptionsItem

### Descriptions 属性

| 属性        | 说明     | 类型                      | 默认值       |
| ----------- | -------- | ------------------------- | ------------ |
| `border`    | 边框     | `boolean`                 | `false`      |
| `column`    | 列数     | `number`                  | `3`          |
| `direction` | 排列方向 | `vertical / horizontal`   | `horizontal` |
| `size`      | 尺寸     | `large / default / small` | —            |
| `title`     | 标题     | `string`                  | —            |
| `extra`     | 操作区   | `string`                  | —            |

### DescriptionsItem 属性

| 属性               | 说明     | 类型                    |
| ------------------ | -------- | ----------------------- |
| `label`            | 标签     | `string`                |
| `span`             | 列数     | `number`                |
| `width`            | 宽度     | `string / number`       |
| `min-width`        | 最小宽度 | `string / number`       |
| `align`            | 对齐     | `left / center / right` |
| `label-align`      | 标签对齐 | `left / center / right` |
| `class-name`       | 类名     | `string`                |
| `label-class-name` | 标签类名 | `string`                |

```vue
<template>
  <el-descriptions title="用户信息" :column="2" border>
    <el-descriptions-item label="用户名">admin</el-descriptions-item>
    <el-descriptions-item label="手机号">13800000000</el-descriptions-item>
  </el-descriptions>
</template>
```

---

## Avatar

| 属性      | 说明       | 类型                                         | 默认值   |
| --------- | ---------- | -------------------------------------------- | -------- |
| `icon`    | 图标       | `string / Component`                         | —        |
| `size`    | 尺寸       | `number / large / default / small`           | —        |
| `shape`   | 形状       | `circle / square`                            | `circle` |
| `src`     | 图片源     | `string`                                     | —        |
| `src-set` | 响应式图片 | `string`                                     | —        |
| `alt`     | 替代文本   | `string`                                     | —        |
| `fit`     | 适应方式   | `fill / contain / cover / none / scale-down` | `cover`  |

| 插槽      | 说明       |
| --------- | ---------- |
| `default` | 自定义内容 |

```vue
<template>
  <el-avatar :size="50" :src="avatarUrl" />
  <el-avatar icon="UserFilled" />
</template>
```

---

## Badge

| 属性     | 说明                                  | 类型                                          | 默认值   |
| -------- | ------------------------------------- | --------------------------------------------- | -------- |
| `value`  | 值                                    | `string / number`                             | —        |
| `max`    | 最大值                                | `number`                                      | `99`     |
| `is-dot` | 小圆点                                | `boolean`                                     | `false`  |
| `hidden` | 隐藏                                  | `boolean`                                     | `false`  |
| `type`   | 类型                                  | `primary / success / warning / danger / info` | `danger` |
| `small`  | 小型（🔧 内部扩展）                   | `boolean`                                     | `false`  |
| `round`  | 圆角（🔧 内部扩展，开源版默认 false） | `boolean`                                     | `true`   |

```vue
<template>
  <el-badge :value="12">
    <el-button>消息</el-button>
  </el-badge>
  <el-badge is-dot>
    <el-button>通知</el-button>
  </el-badge>
</template>
```

---

## Collapse / CollapseItem

### Collapse 属性

| 属性        | 说明       | 类型                                    | 默认值  |
| ----------- | ---------- | --------------------------------------- | ------- |
| `v-model`   | 绑定值     | `string / number / string[] / number[]` | —       |
| `accordion` | 手风琴模式 | `boolean`                               | `false` |

### Collapse 事件

| 事件     | 说明   |
| -------- | ------ |
| `change` | 值改变 |

### CollapseItem 属性

| 属性       | 说明 | 类型              | 默认值  |
| ---------- | ---- | ----------------- | ------- |
| `name`     | 名称 | `string / number` | —       |
| `title`    | 标题 | `string`          | —       |
| `disabled` | 禁用 | `boolean`         | `false` |

```vue
<template>
  <el-collapse v-model="activeNames">
    <el-collapse-item title="标题1" name="1">内容1</el-collapse-item>
    <el-collapse-item title="标题2" name="2">内容2</el-collapse-item>
  </el-collapse>
</template>
```

---

## Card

| 属性         | 说明      | 类型                     | 默认值   |
| ------------ | --------- | ------------------------ | -------- |
| `header`     | 标题      | `string`                 | —        |
| `body-style` | body 样式 | `object`                 | —        |
| `shadow`     | 阴影      | `always / hover / never` | `always` |

| 插槽      | 说明     |
| --------- | -------- |
| `header`  | 头部内容 |
| `default` | 主体内容 |
| `footer`  | 底部内容 |

```vue
<template>
  <el-card shadow="hover">
    <template #header>
      <span>卡片标题</span>
    </template>
    卡片内容
  </el-card>
</template>
```

---

## Carousel / CarouselItem

### Carousel 属性

| 属性                 | 说明           | 类型                     | 默认值       |
| -------------------- | -------------- | ------------------------ | ------------ |
| `initial-index`      | 初始索引       | `number`                 | `0`          |
| `indicator`          | 是否显示指示器 | `boolean`                | `true`       |
| `height`             | 高度           | `string`                 | —            |
| `trigger`            | 触发方式       | `hover / click`          | `hover`      |
| `autoplay`           | 自动播放       | `boolean`                | `true`       |
| `interval`           | 间隔           | `number`                 | `3000`       |
| `indicator-position` | 指示器位置     | `outside / none`         | —            |
| `arrow`              | 切换箭头       | `always / hover / never` | `hover`      |
| `type`               | 类型           | `card`                   | —            |
| `loop`               | 循环           | `boolean`                | `true`       |
| `direction`          | 方向           | `horizontal / vertical`  | `horizontal` |
| `pause-on-hover`     | 悬停暂停       | `boolean`                | `true`       |

### Carousel 事件

| 事件     | 说明   |
| -------- | ------ |
| `change` | 切换时 |

### CarouselItem 属性

| 属性    | 说明 | 类型              |
| ------- | ---- | ----------------- |
| `name`  | 名称 | `string / number` |
| `label` | 标签 | `string / number` |

```vue
<template>
  <el-carousel height="200px">
    <el-carousel-item v-for="item in 4" :key="item">
      <h3>{{ item }}</h3>
    </el-carousel-item>
  </el-carousel>
</template>
```

---

## Progress

| 属性             | 说明       | 类型                            | 默认值  |
| ---------------- | ---------- | ------------------------------- | ------- |
| `percentage`     | 百分比     | `number`                        | `0`     |
| `type`           | 类型       | `line / circle / dashboard`     | `line`  |
| `status`         | 状态       | `success / exception / warning` | —       |
| `stroke-width`   | 宽度       | `number`                        | `6`     |
| `text-inside`    | 文字在内部 | `boolean`                       | `false` |
| `color`          | 颜色       | `string / function / array`     | —       |
| `width`          | 环形宽度   | `number`                        | `160`   |
| `show-text`      | 显示文字   | `boolean`                       | `true`  |
| `stroke-linecap` | 端点形状   | `butt / round / square`         | `round` |
| `format`         | 文字格式化 | `function`                      | —       |
| `indeterminate`  | 不确定状态 | `boolean`                       | `false` |
| `duration`       | 动画时长   | `number`                        | `3`     |

```vue
<template>
  <el-progress :percentage="50" />
  <el-progress type="circle" :percentage="75" />
</template>
```

---

## Timeline / TimelineItem

### TimelineItem 属性

| 属性             | 说明       | 类型                                          | 默认值   |
| ---------------- | ---------- | --------------------------------------------- | -------- |
| `timestamp`      | 时间戳     | `string`                                      | —        |
| `hide-timestamp` | 隐藏时间戳 | `boolean`                                     | `false`  |
| `center`         | 垂直居中   | `boolean`                                     | `false`  |
| `placement`      | 位置       | `top / bottom`                                | `bottom` |
| `type`           | 节点类型   | `primary / success / warning / danger / info` | —        |
| `color`          | 颜色       | `string`                                      | —        |
| `size`           | 尺寸       | `normal / large`                              | `normal` |
| `icon`           | 图标       | `string / Component`                          | —        |
| `hollow`         | 空心       | `boolean`                                     | `false`  |

```vue
<template>
  <el-timeline>
    <el-timeline-item timestamp="2024-01-01" type="primary">
      事件1
    </el-timeline-item>
    <el-timeline-item timestamp="2024-01-02"> 事件2 </el-timeline-item>
  </el-timeline>
</template>
```

---

## Transfer

| 属性                    | 说明           | 类型                        | 默认值     |
| ----------------------- | -------------- | --------------------------- | ---------- |
| `v-model`               | 绑定值         | `string[] / number[]`       | `[]`       |
| `data`                  | 数据源         | `TransferData[]`            | `[]`       |
| `filterable`            | 可搜索         | `boolean`                   | `false`    |
| `filter-placeholder`    | 搜索占位       | `string`                    | —          |
| `filter-method`         | 搜索方法       | `function`                  | —          |
| `target-order`          | 目标排序       | `original / push / unshift` | `original` |
| `titles`                | 标题           | `string[]`                  | —          |
| `button-texts`          | 按钮文字       | `string[]`                  | —          |
| `render-content`        | 自定义渲染     | `function`                  | —          |
| `format`                | 格式           | `object`                    | —          |
| `props`                 | 配置           | `object`                    | —          |
| `left-default-checked`  | 左侧默认选中   | `string[] / number[]`       | `[]`       |
| `right-default-checked` | 右侧默认选中   | `string[] / number[]`       | `[]`       |
| `validate-event`        | 切换时触发校验 | `boolean`                   | `true`     |

| 事件                 | 说明         |
| -------------------- | ------------ |
| `change`             | 值改变       |
| `left-check-change`  | 左侧选择变化 |
| `right-check-change` | 右侧选择变化 |

| 插槽           | 说明       |
| -------------- | ---------- |
| `default`      | 自定义内容 |
| `left-footer`  | 左侧底部   |
| `right-footer` | 右侧底部   |

```vue
<template>
  <el-transfer v-model="value" :data="data" filterable />
</template>
```

---

## Tree

| 属性                    | 说明                 | 类型                 | 默认值  |
| ----------------------- | -------------------- | -------------------- | ------- | --- |
| `data`                  | 数据                 | `object[]`           | `[]`    |
| `empty-text`            | 空数据文本           | `string`             | —       |
| `node-key`              | 节点 key             | `string`             | —       |
| `props`                 | 配置                 | `object`             | —       |
| `render-after-expand`   | 展开后渲染子节点     | `boolean`            | `true`  |
| `load`                  | 加载方法             | `function`           | —       |
| `render-content`        | 自定义渲染           | `function`           | —       |
| `highlight-current`     | 高亮当前             | `boolean`            | `false` |
| `default-expand-all`    | 默认展开全部         | `boolean`            | `false` |
| `expand-on-click-node`  | 点击节点展开         | `boolean`            | `true`  |
| `check-on-click-node`   | 点击节点选中         | `boolean`            | `false` |
| `auto-expand-parent`    | 展开时父节点自动展开 | `boolean`            | `true`  |
| `default-expanded-keys` | 默认展开 keys        | `array`              | `[]`    |
| `show-checkbox`         | 显示复选框           | `boolean`            | `false` |
| `check-strictly`        | 严格模式             | `boolean`            | `false` |
| `default-checked-keys`  | 默认选中 keys        | `array`              | `[]`    |
| `current-node-key`      | 当前节点 key         | `string / number`    | —       |
| `filter-node-method`    | 过滤方法             | `function`           | —       |
| `accordion`             | 手风琴模式           | `boolean`            | `false` |
| `indent`                | 缩进                 | `number`             | `18`    |
| `icon`                  | 图标                 | `string / Component` | —       | 🔧  |
| `lazy`                  | 懒加载               | `boolean`            | `false` |
| `draggable`             | 可拖拽               | `boolean`            | `false` |
| `allow-drag`            | 允许拖拽             | `function`           | —       |
| `allow-drop`            | 允许放置             | `function`           | —       |

| 事件               | 说明         |
| ------------------ | ------------ |
| `node-click`       | 节点点击     |
| `node-contextmenu` | 节点右键     |
| `check-change`     | 选中变化     |
| `check`            | 点击复选框   |
| `current-change`   | 当前节点变化 |
| `node-expand`      | 节点展开     |
| `node-collapse`    | 节点折叠     |
| `node-drag-start`  | 拖拽开始     |
| `node-drag-enter`  | 拖拽进入     |
| `node-drag-leave`  | 拖拽离开     |
| `node-drag-over`   | 拖拽经过     |
| `node-drag-end`    | 拖拽结束     |
| `node-drop`        | 放置         |

| 方法                  | 说明          |
| --------------------- | ------------- |
| `filter`              | 过滤          |
| `updateKeyChildren`   | 更新子节点    |
| `getCheckedNodes`     | 获取选中节点  |
| `getCheckedKeys`      | 获取选中 keys |
| `setCheckedNodes`     | 设置选中节点  |
| `setCheckedKeys`      | 设置选中 keys |
| `setChecked`          | 设置选中      |
| `getHalfCheckedNodes` | 获取半选节点  |
| `getHalfCheckedKeys`  | 获取半选 keys |
| `getCurrentKey`       | 获取当前 key  |
| `getCurrentNode`      | 获取当前节点  |
| `setCurrentKey`       | 设置当前 key  |
| `setCurrentNode`      | 设置当前节点  |
| `getNode`             | 获取节点      |
| `remove`              | 移除          |
| `append`              | 追加          |
| `insertBefore`        | 前置插入      |
| `insertAfter`         | 后置插入      |

```vue
<template>
  <el-tree :data="treeData" node-key="id" default-expand-all />
</template>
```

---

## Statistic / Countdown

### Statistic 属性

| 属性                | 说明         | 类型                      | 默认值 |
| ------------------- | ------------ | ------------------------- | ------ |
| `value`             | 数值         | `number / string`         | —      |
| `title`             | 标题         | `string`                  | —      |
| `precision`         | 精度         | `number`                  | `0`    |
| `group-separator`   | 千分位分隔符 | `string`                  | `,`    |
| `prefix`            | 前缀         | `string`                  | —      |
| `suffix`            | 后缀         | `string`                  | —      |
| `value-style`       | 数值样式     | `object`                  | —      |
| `size`              | 尺寸         | `large / default / small` | —      |
| `formatter`         | 格式化函数   | `function`                | —      |
| `decimal-separator` | 小数分隔符   | `string`                  | `.`    |
| `format`            | 格式化       | `string`                  | —      |

### Countdown 属性

| 属性          | 说明     | 类型             | 默认值       |
| ------------- | -------- | ---------------- | ------------ |
| `value`       | 目标时间 | `number / Dayjs` | —            |
| `format`      | 格式     | `string`         | `'HH:mm:ss'` |
| `prefix`      | 前缀     | `string`         | —            |
| `suffix`      | 后缀     | `string`         | —            |
| `title`       | 标题     | `string`         | —            |
| `value-style` | 数值样式 | `object`         | —            |

| 事件     | 说明       |
| -------- | ---------- |
| `change` | 值改变     |
| `finish` | 倒计时结束 |

```vue
<template>
  <el-statistic :value="268500" title="年度销售额" />
  <el-countdown :value="deadline" />
</template>
```

---

## NumberFlow / NumberFlowGroup

🔧 自定义组件，详细文档见 `number-flow.md`。

```vue
<template>
  <el-number-flow :value="value" prefix="¥" />
</template>
```

---

## TreeV2

虚拟化树，适用于大量节点场景。

### 属性

| 属性                  | 说明                     | 类型                                       | 默认值                                                                        |
| --------------------- | ------------------------ | ------------------------------------------ | ----------------------------------------------------------------------------- |
| `data`                | 树数据                   | `TreeData`                                 | `[]`                                                                          |
| `height`              | 可视区域高度             | `number`                                   | `200`                                                                         |
| `emptyText`           | 空数据提示               | `string`                                   | —                                                                             |
| `props`               | 节点字段映射             | `{ children?, label?, value?, disabled? }` | `{ children: 'children', label: 'label', value: 'id', disabled: 'disabled' }` |
| `highlightCurrent`    | 高亮当前节点             | `boolean`                                  | `false`                                                                       |
| `showCheckbox`        | 显示复选框               | `boolean`                                  | `false`                                                                       |
| `checkStrictly`       | 严格模式（不关联父子）   | `boolean`                                  | `false`                                                                       |
| `defaultCheckedKeys`  | 默认选中 keys            | `TreeKey[]`                                | `[]`                                                                          |
| `defaultExpandedKeys` | 默认展开 keys            | `TreeKey[]`                                | `[]`                                                                          |
| `currentNodeKey`      | 当前节点 key             | `TreeKey`                                  | —                                                                             |
| `expandOnClickNode`   | 点击节点展开             | `boolean`                                  | `true`                                                                        |
| `checkOnClickNode`    | 点击节点选中             | `boolean`                                  | `false`                                                                       |
| `accordion`           | 手风琴模式               | `boolean`                                  | `false`                                                                       |
| `indent`              | 缩进(px)                 | `number`                                   | `16`                                                                          |
| `icon`                | 自定义图标               | `string / Component`                       | —                                                                             |
| `filterMethod`        | 过滤方法                 | `(query, nodeData) => boolean`             | —                                                                             |
| `perfMode`            | 性能模式（内存换流畅度） | `boolean`                                  | `true`                                                                        |

### 事件

| 事件               | 说明           | 回调参数              |
| ------------------ | -------------- | --------------------- |
| `node-click`       | 节点点击       | `(data, node, event)` |
| `node-expand`      | 节点展开       | `(data, node)`        |
| `node-collapse`    | 节点折叠       | `(data, node)`        |
| `current-change`   | 当前节点变化   | `(data, node)`        |
| `check`            | 复选框状态变化 | `(data, checkedInfo)` |
| `check-change`     | 选中状态变化   | `(data, checked)`     |
| `node-contextmenu` | 节点右键       | `(event, data, node)` |

```vue
<template>
  <el-tree-v2 :data="treeData" :height="400" />
</template>
```

---

## ListV2 / DynamicSizeList / FixedSizeList

虚拟化列表组件。`ElListV2` 为通用封装，通过 `sized` 控制固定/动态高度；`ElFixedSizeList` / `ElDynamicSizeList` 为底层虚拟列表组件。

### ElListV2 属性

| 属性                 | 说明                       | 类型                    | 默认值     |
| -------------------- | -------------------------- | ----------------------- | ---------- |
| `data`               | 列表数据                   | `any[]`                 | `[]`       |
| `height`             | 容器高度                   | `string / number`       | **必填**   |
| `width`              | 容器宽度（水平列表时必填） | `string / number`       | —          |
| `sized`              | 固定高度模式               | `boolean`               | `true`     |
| `itemSize`           | 固定高度模式下每项高度     | `number`                | `50`       |
| `estimatedItemSize`  | 动态高度模式下估算高度     | `number`                | —          |
| `layout`             | 布局方向                   | `vertical / horizontal` | `vertical` |
| `gap`                | 项间距(px)                 | `number`                | `0`        |
| `buffer`             | 前后缓冲项数               | `number`                | `2`        |
| `keyField`           | 数据唯一标识字段           | `string`                | `'id'`     |
| `initScrollOffset`   | 初始滚动位置               | `number`                | `0`        |
| `scrollbarAlwaysOn`  | 滚动条常显                 | `boolean`               | `false`    |
| `virtualizerOptions` | 虚拟化器配置               | `object`                | `{}`       |

### ElListV2 事件

| 事件            | 说明   | 回调参数                                             |
| --------------- | ------ | ---------------------------------------------------- |
| `item-rendered` | 项渲染 | `(bufferStart, bufferEnd, visibleStart, visibleEnd)` |
| `scroll`        | 滚动   | `(offset)`                                           |

### ElListV2 方法

| 方法              | 说明                       | 参数                              |
| ----------------- | -------------------------- | --------------------------------- |
| `scrollToIndex`   | 滚动到指定索引             | `(index, { align?, behavior? })`  |
| `scrollToOffset`  | 滚动到指定偏移             | `(offset, { align?, behavior? })` |
| `scrollBy`        | 滚动指定增量               | `(delta, options?)`               |
| `measure`         | 重新测量（动态高度时有用） | —                                 |
| `getVirtualItems` | 获取当前虚拟项             | —                                 |
| `getTotalSize`    | 获取总尺寸                 | —                                 |

### 插槽

| 插槽      | 说明       | 作用域参数        |
| --------- | ---------- | ----------------- |
| `default` | 列表项内容 | `{ index, data }` |

```vue
<template>
  <el-list-v2 :data="list" :height="400">
    <template #default="{ item, index }">
      <div>{{ item.name }}</div>
    </template>
  </el-list-v2>
</template>
```

### 三者区别

| 组件                | 适用场景                    | 高度模式                           |
| ------------------- | --------------------------- | ---------------------------------- |
| `ElListV2`          | 通用场景，通过 `sized` 切换 | 固定/动态均可                      |
| `ElFixedSizeList`   | 所有项高度相同              | 固定高度                           |
| `ElDynamicSizeList` | 项高度不一致                | 动态高度，需传入 `itemSize` 为函数 |

---

## Tour / TourStep

引导 toured。

| 属性                       | 说明     | 类型                 | 默认值    |
| -------------------------- | -------- | -------------------- | --------- |
| `v-model`                  | 显隐     | `boolean`            | `false`   |
| `current`                  | 当前步骤 | `number`             | `0`       |
| `show-arrow`               | 显示箭头 | `boolean`            | `true`    |
| `placement`                | 位置     | `string`             | `bottom`  |
| `content-style`            | 内容样式 | `object`             | —         |
| `mask`                     | 遮罩     | `boolean / object`   | `true`    |
| `type`                     | 类型     | `default / primary`  | `default` |
| `show-close`               | 显示关闭 | `boolean`            | `true`    |
| `close-icon`               | 关闭图标 | `string / Component` | `Close`   |
| `z-index`                  | 层级     | `number`             | `2001`    |
| `scroll-into-view-options` | 滚动配置 | `boolean / object`   | `true`    |

| 事件     | 说明     |
| -------- | -------- |
| `change` | 步骤变化 |
| `close`  | 关闭     |
| `finish` | 完成     |

### TourStep 属性

| 属性                | 说明           | 类型                              |
| ------------------- | -------------- | --------------------------------- |
| `target`            | 目标元素       | `string / HTMLElement / function` |
| `title`             | 标题           | `string`                          |
| `description`       | 描述           | `string`                          |
| `show-arrow`        | 显示箭头       | `boolean`                         |
| `placement`         | 位置           | `string`                          |
| `content-style`     | 内容样式       | `object`                          |
| `mask`              | 遮罩           | `boolean / object`                |
| `type`              | 类型           | `string`                          |
| `next-button-props` | 下一步按钮配置 | `object`                          |
| `prev-button-props` | 上一步按钮配置 | `object`                          |

```vue
<template>
  <el-tour v-model="showTour">
    <el-tour-step target="#step1" title="步骤1" description="这是第一步" />
    <el-tour-step target="#step2" title="步骤2" description="这是第二步" />
  </el-tour>
</template>
```
