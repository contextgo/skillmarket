# TabsPro

**注册名**：`ElTabsPro` | **模板标签**：`el-tabs-pro`

完全自研的业务页签组件，适用于一级菜单下的动态业务页签场景。

---

## 属性

| 名称                      | 说明                            | 类型              | 默认值 |
| ------------------------- | ------------------------------- | ----------------- | ------ |
| `v-model` / `model-value` | 当前激活页签的 `name`           | `string / number` | —      |
| `v-model:tabs` / `tabs`   | 页签数据数组                    | `TabsProItem[]`   | `[]`   |
| `min-item-width`          | 单个页签最小宽度（px）          | `number`          | `80`   |
| `max-item-width`          | 单个页签最大宽度（px）          | `number`          | `220`  |
| `overflow-trigger-width`  | `...` 触发区宽度（px）          | `number`          | `32`   |
| `overflow-show-delay`     | hover 打开 `...` 面板延迟（ms） | `number`          | `200`  |

## TabsProItem 结构

```ts
interface TabsProItem {
  label: string
  name: string | number
  closable?: boolean // 默认 true
  disabled?: boolean // 默认 false
}
```

## 事件

| 名称          | 说明         | 回调参数       |
| ------------- | ------------ | -------------- |
| `change`      | 激活页签变化 | `(name, tab)`  |
| `tab-click`   | 点击页签     | `(tab, event)` |
| `tab-remove`  | 删除页签     | `(name, tab)`  |
| `tabs-change` | 页签数组变化 | `(tabs)`       |

## 实例方法

```ts
// 新增页签；若 name 已存在则更新并移动到可视区最后
addTab(tab: TabsProItem, options?): TabsProItem

// 删除指定页签
removeTab(name: string | number): boolean

// 激活指定页签；若该页签在 ... 中会移动到可视区最后
setActive(name: string | number): boolean

// 获取当前页签列表
getTabs(): TabsProItem[]

// 容器宽度变化后手动刷新布局
refresh(): void
```

## 溢出替换算法

当宽度不足时，组件展示 `前 N-1 个可视页签 + 最后一个页签`，中间剩余页签进入 `...`。点击 `...` 内的页签后，会与当前可视区最后一个页签交换位置。

## 与 ElTabs 的选择建议

| 场景                                 | 推荐组件    |
| ------------------------------------ | ----------- |
| 一级菜单下的动态业务页签（可增删）   | **TabsPro** |
| 同一页面内的内容分区切换（固定页签） | ElTabs      |
