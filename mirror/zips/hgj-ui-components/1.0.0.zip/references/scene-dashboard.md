# 看板/仪表盘场景

看板/仪表盘用于展示关键业务指标，通常由统计卡片、图表、数据列表等组成。

---

## 统计卡片

使用 `el-row` + `el-col` + `el-card` 搭建统计指标网格：

```vue
<template>
  <el-row :gutter="16">
    <el-col :span="6">
      <el-card>
        <div class="stat-title">总订单数</div>
        <el-number-flow
          :value="stats.orderCount"
          :format="{ notation: 'compact' }"
        />
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">今日收入</div>
        <el-number-flow-group>
          <el-number-flow :value="stats.revenue" prefix="¥" />
        </el-number-flow-group>
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">用户数</div>
        <el-statistic :value="stats.users" />
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">待处理</div>
        <el-countdown :value="deadline" />
      </el-card>
    </el-col>
  </el-row>
</template>
```

---

## NumberFlow 数字流动画

用于以平滑动画展示数字变化，支持复杂时序和联动。

### 基础用法

```vue
<template>
  <el-number-flow :value="value" prefix="¥" suffix="元" />
</template>
```

### 属性

| 名称                        | 说明                                       | 类型                                   | 默认值     |
| --------------------------- | ------------------------------------------ | -------------------------------------- | ---------- |
| `value`                     | 当前显示的数值                             | `number / string`                      | `0`        |
| `format`                    | 数字格式化配置，透传给 `Intl.NumberFormat` | `Intl.NumberFormatOptions`             | `{}`       |
| `prefix` / `suffix`         | 数字内容前缀/后缀                          | `string`                               | —          |
| `trend`                     | 数值增减趋势                               | `number / (oldValue, value) => number` | 随差值计算 |
| `animated`                  | 是否启用动画                               | `boolean`                              | `true`     |
| `color`                     | 自定义数字颜色                             | `string`                               | —          |
| `font-size`                 | 自定义字体大小                             | `number / string`                      | —          |
| `respect-motion-preference` | 是否尊重用户「减少动效」偏好               | `boolean`                              | `true`     |

### NumberFlowGroup

用于让多个 `ElNumberFlow` 在同一次更新中同步开始与结束动画：

```vue
<template>
  <el-number-flow-group>
    <el-number-flow :value="value1" />
    <el-number-flow :value="value2" />
  </el-number-flow-group>
</template>
```

### 事件

| 名称               | 说明               |
| ------------------ | ------------------ |
| `animationsstart`  | 数字动画开始时     |
| `animationsfinish` | 数字动画全部结束时 |

---

## Statistic 统计数值

用于展示静态数值，不支持动画：

```vue
<template>
  <el-statistic :value="268500" title="年度销售额">
    <template #suffix>
      <el-icon><ArrowUp /></el-icon>
      <span>12%</span>
    </template>
  </el-statistic>
</template>
```

### 属性

| 属性                | 说明         | 类型              |
| ------------------- | ------------ | ----------------- |
| `value`             | 数值         | `number / string` |
| `title`             | 标题         | `string`          |
| `precision`         | 小数位数     | `number`          |
| `group-separator`   | 千分位分隔符 | `string`          |
| `prefix` / `suffix` | 前缀/后缀    | `string`          |

---

## Countdown 倒计时

```vue
<template>
  <el-countdown :value="deadline" format="HH:mm:ss" />
</template>
```

| 属性                | 说明      | 类型             |
| ------------------- | --------- | ---------------- |
| `value`             | 目标时间  | `number / Dayjs` |
| `format`            | 格式      | `string`         |
| `prefix` / `suffix` | 前缀/后缀 | `string`         |

---

## 进度展示

```vue
<template>
  <!-- 线性进度条 -->
  <el-progress :percentage="50" />
  <el-progress :percentage="100" status="success" />
  <el-progress :percentage="80" status="warning" />
  <el-progress :percentage="30" status="exception" />

  <!-- 环形进度条 -->
  <el-progress type="circle" :percentage="75" />

  <!-- 仪表盘进度条 -->
  <el-progress type="dashboard" :percentage="80" />
</template>
```

| 属性           | 说明               | 类型                            | 默认值  |
| -------------- | ------------------ | ------------------------------- | ------- |
| `percentage`   | 百分比（必填）     | `number`                        | `0`     |
| `type`         | 进度条类型         | `line / circle / dashboard`     | `line`  |
| `status`       | 状态               | `success / exception / warning` | —       |
| `stroke-width` | 进度条宽度         | `number`                        | `6`     |
| `text-inside`  | 文字显示在进度条内 | `boolean`                       | `false` |
| `color`        | 进度条颜色         | `string / function / array`     | `''`    |
| `show-text`    | 显示文字           | `boolean`                       | `true`  |

---

## 结果页

用于展示操作结果：

```vue
<template>
  <el-result
    icon="success"
    title="提交成功"
    sub-title="您的申请已提交，请等待审核"
  >
    <template #extra>
      <el-button type="primary">返回首页</el-button>
      <el-button>查看详情</el-button>
    </template>
  </el-result>
</template>
```

| 属性        | 说明     | 类型                               |
| ----------- | -------- | ---------------------------------- |
| `title`     | 标题     | `string`                           |
| `sub-title` | 副标题   | `string`                           |
| `icon`      | 图标类型 | `success / warning / info / error` |
