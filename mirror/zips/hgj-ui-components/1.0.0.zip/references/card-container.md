# CardContainer

**注册名**：`ElCardContainer` / `ElCardList` / `ElCardForm` / `ElCardCustom`

用于在列表页、详情页中纵向编排多个卡片区域。

---

## 快捷组件

| 组件                | 说明           | 默认间距         | 适用场景                 |
| ------------------- | -------------- | ---------------- | ------------------------ |
| `el-card-list`      | 列表页卡片容器 | `16px`           | 一级页面、筛选页、列表页 |
| `el-card-form`      | 表单页卡片容器 | `20px`           | 详情页、编辑页、配置页   |
| `el-card-custom`    | 自定义卡片容器 | `32px`           | 特殊间距需求             |
| `el-card-container` | 基础容器       | 通过 `type` 控制 | 动态切换场景             |

## 使用建议

1. 页面骨架先用 `el-container` 系列搭建，内容区再用 `el-card-list` 或 `el-card-form` 组织
2. `el-card-list` 适合一级页面、筛选页、列表页等高频页面
3. `el-card-form` 适合详情页、编辑页、配置页等内容更聚合的场景
4. `el-card-custom` 仅在设计稿明确要求特殊节奏时使用，可通过 `gap` 调整
5. 直接子元素不强制必须是 `el-card`，但推荐保持同类内容块

## 属性

| 属性   | 说明                       | 类型              | 可选值                 | 默认值   |
| ------ | -------------------------- | ----------------- | ---------------------- | -------- |
| `type` | 容器类型                   | `string`          | `list / form / custom` | `custom` |
| `gap`  | 容器间距，仅 `custom` 生效 | `string / number` | —                      | `32px`   |
