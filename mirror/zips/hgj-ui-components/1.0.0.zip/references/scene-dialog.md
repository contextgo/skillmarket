# 弹层场景

弹层（Dialog / Drawer）用于在当前页面上方展示额外内容，适用于表单提交、信息确认、详情展示等场景。

---

## Dialog 基础用法

适用于需要用户聚焦处理的模态场景：

```vue
<script setup>
const visible = ref(false)
const form = reactive({ name: '' })

async function handleConfirm() {
  await api.create(form)
  visible.value = false
  ElMessage.success('创建成功')
}
</script>

<template>
  <el-button @click="visible = true">新建</el-button>

  <el-dialog v-model="visible" title="新建" width="500px">
    <el-form :model="form">
      <el-form-item label="名称">
        <el-input v-model="form.name" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="handleConfirm">确认</el-button>
    </template>
  </el-dialog>
</template>
```

### Dialog 常用属性

| 属性                    | 说明           | 常用值                   |
| ----------------------- | -------------- | ------------------------ |
| `v-model`               | 显隐控制       | `boolean`                |
| `title`                 | 标题           | `string`                 |
| `width`                 | 宽度           | `string`（如 `'500px'`） |
| `fullscreen`            | 全屏           | `boolean`                |
| `close-on-click-modal`  | 点击遮罩关闭   | `boolean`                |
| `close-on-press-escape` | 按 ESC 关闭    | `boolean`                |
| `destroy-on-close`      | 关闭时销毁内容 | `boolean`                |
| `draggable`             | 可拖拽         | `boolean`                |

---

## Drawer 基础用法

适用于需要从侧边滑出的非模态或半模态场景，如详情展示、设置面板：

```vue
<script setup>
const drawerVisible = ref(false)
</script>

<template>
  <el-button @click="drawerVisible = true">查看详情</el-button>

  <el-drawer v-model="drawerVisible" title="详情" size="50%">
    <el-descriptions :column="1">
      <el-descriptions-item label="名称">{{
        detail.name
      }}</el-descriptions-item>
      <el-descriptions-item label="状态">
        <el-tag :type="detail.status === 'active' ? 'success' : 'danger'">{{
          detail.status
        }}</el-tag>
      </el-descriptions-item>
    </el-descriptions>
  </el-drawer>
</template>
```

### Drawer 常用属性

| 属性          | 说明     | 常用值                          |
| ------------- | -------- | ------------------------------- |
| `v-model`     | 显隐控制 | `boolean`                       |
| `title`       | 标题     | `string`                        |
| `size`        | 宽度     | `string / number`               |
| `direction`   | 弹出方向 | `'rtl' / 'ltr' / 'ttb' / 'btt'` |
| `with-header` | 显示头部 | `boolean`                       |
| `modal`       | 显示遮罩 | `boolean`                       |

---

## DialogWrapper（Promise 式弹窗）

适用于需要返回值、异步确认、多处复用的弹窗场景。

### 全局挂载

在 App.vue 或 Layout 组件中挂载：

```vue
<template>
  <div>
    <router-view />
    <el-dialog-wrapper />
  </div>
</template>
```

### 弹窗组件规范

弹窗组件需抛出 `resolve` 和 `reject` 事件：

```vue
<!-- MyFormDialog.vue -->
<script setup>
const props = defineProps({ initialData: Object })
const emits = defineEmits(['resolve', 'reject'])

const form = reactive({ ...props.initialData })

async function handleConfirm() {
  const result = await api.create(form)
  emits('resolve', result)
}
</script>

<template>
  <el-dialog
    :model-value="true"
    title="新建"
    @close="emits('reject', { reason: 'cancel' })"
  >
    <el-form :model="form">
      <el-form-item label="名称">
        <el-input v-model="form.name" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="emits('reject', { reason: 'cancel' })">取消</el-button>
      <el-button type="primary" @click="handleConfirm">确认</el-button>
    </template>
  </el-dialog>
</template>
```

### 调用方式

```ts
import { openDialog } from '@hgj/element-plus'
import MyFormDialog from './MyFormDialog.vue'

async function handleCreate() {
  try {
    const result = await openDialog(MyFormDialog, {
      initialData: { name: '' },
    })
    ElMessage.success('创建成功')
    loadData() // 刷新列表
  } catch {
    // 用户取消
  }
}
```

### API

| 函数            | 说明                   | 签名                                                          |
| --------------- | ---------------------- | ------------------------------------------------------------- |
| `openDialog`    | 打开弹窗，返回 Promise | `<C>(component: C, props?: PropsType<C>) => Promise<unknown>` |
| `resolveDialog` | 确认关闭弹窗           | `(id: symbol, result: unknown) => void`                       |
| `rejectDialog`  | 取消关闭弹窗           | `(id: symbol, error: unknown) => void`                        |
| `unmountDialog` | 卸载弹窗 DOM           | `(id: symbol) => void`                                        |

---

## 选择建议

| 场景                       | 推荐方案                | 理由                       |
| -------------------------- | ----------------------- | -------------------------- |
| 简单确认/提示，无需返回值  | `el-dialog` + `v-model` | 直接控制，代码最少         |
| 表单提交，需要返回值和校验 | **DialogWrapper**       | Promise 式，调用方等待结果 |
| 异步流程，需要等待用户操作 | **DialogWrapper**       | `await` 阻塞，流程清晰     |
| 多处复用的弹窗组件         | **DialogWrapper**       | 组件化 + 统一调用方式      |
| 详情展示、设置面板         | `el-drawer`             | 侧边滑出，不中断当前上下文 |
| 需要大面积编辑的表单       | `el-drawer`             | 宽度可调，适合复杂表单     |
