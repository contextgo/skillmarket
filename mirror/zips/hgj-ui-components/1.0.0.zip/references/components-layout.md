# Layout 布局组件

## Row / Col

### Row 属性

| 属性      | 说明           | 类型                                                                 | 默认值  |
| --------- | -------------- | -------------------------------------------------------------------- | ------- |
| `gutter`  | 栅格间隔       | `number`                                                             | `0`     |
| `justify` | 水平排列       | `start / center / end / space-between / space-around / space-evenly` | `start` |
| `align`   | 垂直排列       | `top / middle / bottom`                                              | `top`   |
| `tag`     | 自定义元素标签 | `string`                                                             | `div`   |

### Col 属性

| 属性     | 说明           | 类型                        |
| -------- | -------------- | --------------------------- |
| `span`   | 占据栏数       | `number`（1-24）            |
| `offset` | 左侧偏移       | `number`                    |
| `push`   | 向右移动       | `number`                    |
| `pull`   | 向左移动       | `number`                    |
| `xs`     | `<768px`       | `number / { span, offset }` |
| `sm`     | `≥768px`       | `number / { span, offset }` |
| `md`     | `≥992px`       | `number / { span, offset }` |
| `lg`     | `≥1200px`      | `number / { span, offset }` |
| `xl`     | `≥1920px`      | `number / { span, offset }` |
| `tag`    | 自定义元素标签 | `string`                    |

```vue
<template>
  <el-row :gutter="16">
    <el-col :span="6">
      <el-card>卡片1</el-card>
    </el-col>
    <el-col :span="6">
      <el-card>卡片2</el-card>
    </el-col>
    <el-col :span="6">
      <el-card>卡片3</el-card>
    </el-col>
    <el-col :span="6">
      <el-card>卡片4</el-card>
    </el-col>
  </el-row>

  <el-row :gutter="16">
    <el-col :xs="24" :sm="12" :md="8" :lg="6">
      <el-card>响应式</el-card>
    </el-col>
  </el-row>
</template>
```

---

## Container / Aside / Header / Main / Footer

### Container 属性

| 属性        | 说明     | 类型                    | 默认值                                                                     |
| ----------- | -------- | ----------------------- | -------------------------------------------------------------------------- |
| `direction` | 排列方向 | `horizontal / vertical` | 子元素中有 `el-header` 或 `el-footer` 时为 `vertical`，否则为 `horizontal` |

### Aside 属性

| 属性    | 说明 | 类型     | 默认值 |
| ------- | ---- | -------- | ------ |
| `width` | 宽度 | `string` | —      |

### Header 属性

| 属性     | 说明 | 类型     | 默认值 |
| -------- | ---- | -------- | ------ |
| `height` | 高度 | `string` | —      |

### Footer 属性

| 属性     | 说明 | 类型     | 默认值 |
| -------- | ---- | -------- | ------ |
| `height` | 高度 | `string` | —      |

```vue
<template>
  <el-container>
    <el-aside width="200px">
      <el-menu>
        <el-menu-item index="1">首页</el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header>头部</el-header>
      <el-main>主体内容</el-main>
      <el-footer>底部</el-footer>
    </el-container>
  </el-container>
</template>
```

---

## CardContainer / CardList / CardForm / CardCustom

🔧 自定义组件，详细文档见 `card-container.md`。

| 组件                | 说明           | 默认间距         | 适用场景                 |
| ------------------- | -------------- | ---------------- | ------------------------ |
| `el-card-list`      | 列表页卡片容器 | `16px`           | 一级页面、筛选页、列表页 |
| `el-card-form`      | 表单页卡片容器 | `20px`           | 详情页、编辑页、配置页   |
| `el-card-custom`    | 自定义卡片容器 | `32px`           | 特殊间距需求             |
| `el-card-container` | 基础容器       | 通过 `type` 控制 | 动态切换场景             |

### 属性

| 属性   | 说明                       | 类型              | 可选值                 | 默认值   |
| ------ | -------------------------- | ----------------- | ---------------------- | -------- |
| `type` | 容器类型                   | `string`          | `list / form / custom` | `custom` |
| `gap`  | 容器间距，仅 `custom` 生效 | `string / number` | —                      | `32px`   |

```vue
<template>
  <el-card-list>
    <el-card>筛选表单</el-card>
    <el-card>数据表格</el-card>
  </el-card-list>

  <el-card-form>
    <el-form>表单内容</el-form>
  </el-card-form>
</template>
```
