# Form 表单组件

## Input / HighlightInput

### Input 属性

| 属性              | 说明                   | 类型                                  | 默认值  |
| ----------------- | ---------------------- | ------------------------------------- | ------- |
| `v-model`         | 绑定值                 | `string / number / null / undefined`  | —       |
| `type`            | 类型                   | `text / textarea / password / ...`    | `text`  |
| `maxlength`       | 最大长度               | `string / number`                     | —       |
| `minlength`       | 最小长度               | `string / number`                     | —       |
| `show-word-limit` | 显示字数统计           | `boolean`                             | `false` |
| `placeholder`     | 占位文本               | `string`                              | —       |
| `clearable`       | 可清空                 | `boolean`                             | `false` |
| `show-password`   | 密码可见切换           | `boolean`                             | `false` |
| `disabled`        | 禁用                   | `boolean`                             | `false` |
| `size`            | 尺寸                   | `large / default / small`             | —       |
| `prefix-icon`     | 头部图标               | `string / Component`                  | —       |
| `suffix-icon`     | 尾部图标               | `string / Component`                  | —       |
| `autosize`        | 自适应高度（textarea） | `boolean / { minRows, maxRows }`      | `false` |
| `formatter`       | 格式化函数             | `function`                            | —       |
| `parser`          | 解析函数               | `function`                            | —       |
| `inline`          | 行内模式               | `boolean`                             | `false` |
| `resize`          | textarea 可调整        | `none / both / horizontal / vertical` | —       |
| `autocomplete`    | 自动补全               | `string`                              | —       |
| `form`            | 所属 form              | `string`                              | —       |
| `readonly`        | 只读                   | `boolean`                             | `false` |
| `label`           | 标签                   | `string`                              | —       |
| `tabindex`        | tabindex               | `string / number`                     | `0`     |
| `inputStyle`      | 输入框样式             | `object`                              | —       |
| `containerRole`   | 容器 role              | `string`                              | —       |
| `validate-event`  | 输入时触发校验         | `boolean`                             | `true`  |

### Input 事件

| 事件     | 说明             |
| -------- | ---------------- |
| `blur`   | 失焦             |
| `focus`  | 聚焦             |
| `change` | 值改变（失焦后） |
| `input`  | 值改变（实时）   |
| `clear`  | 清空             |

### Input 插槽

| 插槽      | 说明           |
| --------- | -------------- |
| `prefix`  | 输入框头部内容 |
| `suffix`  | 输入框尾部内容 |
| `prepend` | 输入框前置内容 |
| `append`  | 输入框后置内容 |

### Input 实例方法

| 方法             | 说明               |
| ---------------- | ------------------ |
| `focus`          | 聚焦               |
| `blur`           | 失焦               |
| `select`         | 选中文字           |
| `clear`          | 清空               |
| `resizeTextarea` | 调整 textarea 高度 |

```vue
<template>
  <el-input v-model="value" placeholder="请输入" clearable />
  <el-input v-model="value" type="textarea" :autosize="{ minRows: 4 }" />
  <el-input v-model="value" show-password />
  <el-input v-model="value">
    <template #prepend>https://</template>
    <template #append>.com</template>
  </el-input>
</template>
```

### HighlightInput

🔧 自定义组件，详细文档见 `highlight-input.md`。

继承 `ElInput` 全部能力，叠加文本高亮显示功能。

```vue
<template>
  <el-highlight-input v-model="value" />
</template>
```

---

## InputNumber

| 属性                | 说明             | 类型                        | 默认值      |
| ------------------- | ---------------- | --------------------------- | ----------- |
| `v-model`           | 绑定值           | `number`                    | —           |
| `min`               | 最小值           | `number`                    | `-Infinity` |
| `max`               | 最大值           | `number`                    | `Infinity`  |
| `step`              | 步进             | `number`                    | `1`         |
| `step-strictly`     | 只能输入步进倍数 | `boolean`                   | `false`     |
| `precision`         | 精度             | `number`                    | —           |
| `size`              | 尺寸             | `large / default / small`   | —           |
| `disabled`          | 禁用             | `boolean`                   | `false`     |
| `controls`          | 控制按钮         | `boolean`                   | `true`      |
| `controls-position` | 控制按钮位置     | `'' / 'right'`              | —           |
| `placeholder`       | 占位文本         | `string`                    | —           |
| `id`                | 原生 id          | `string`                    | —           |
| `name`              | 原生 name        | `string`                    | —           |
| `label`             | 标签             | `string`                    | —           |
| `value-on-clear`    | 清空时的值       | `number / null / min / max` | `null`      |

```vue
<template>
  <el-input-number v-model="num" :min="0" :max="100" />
  <el-input-number v-model="num" :precision="2" :step="0.1" />
</template>
```

---

## InputTag

输入标签组件，输入后按回车生成标签。

| 属性                  | 说明             | 类型                                          | 默认值  |
| --------------------- | ---------------- | --------------------------------------------- | ------- |
| `v-model`             | 绑定值           | `string[]`                                    | `[]`    |
| `trigger`             | 触发方式         | `Enter / Space`                               | `Enter` |
| `max`                 | 最大标签数       | `number`                                      | —       |
| `tag-type`            | 标签类型         | `primary / success / info / warning / danger` | `info`  |
| `tagEffect`           | 标签主题         | `dark / light / plain`                        | —       |
| `effect`              | 主题             | `dark / light / plain`                        | —       |
| `size`                | 尺寸             | `large / default / small`                     | —       |
| `clearable`           | 可清空           | `boolean`                                     | `false` |
| `disabled`            | 禁用             | `boolean`                                     | `false` |
| `readonly`            | 只读             | `boolean`                                     | `false` |
| `placeholder`         | 占位文本         | `string`                                      | —       |
| `draggable`           | 可拖拽           | `boolean`                                     | `false` |
| `delimiter`           | 分隔符           | `string`                                      | —       |
| `autofocus`           | 自动聚焦         | `boolean`                                     | `false` |
| `saveOnBlur`          | 失焦时保存       | `boolean`                                     | `true`  |
| `collapseTags`        | 折叠标签         | `boolean`                                     | `false` |
| `collapseTagsTooltip` | 折叠标签 tooltip | `boolean`                                     | `false` |
| `maxCollapseTags`     | 最大折叠标签数   | `number`                                      | `1`     |

```vue
<template>
  <el-input-tag v-model="tags" placeholder="请输入标签" />
</template>
```

---

## Autocomplete

带输入建议的输入框。

| 属性                    | 说明                     | 类型              | 默认值         |
| ----------------------- | ------------------------ | ----------------- | -------------- |
| `v-model`               | 绑定值                   | `string / number` | —              |
| `placeholder`           | 占位文本                 | `string`          | —              |
| `fetch-suggestions`     | 获取建议方法             | `Function`        | —              |
| `inline`                | 行内模式                 | `boolean`         | `false`        |
| `hideLoading`           | 隐藏加载状态             | `boolean`         | `false`        |
| `label`                 | 标签                     | `string`          | —              |
| `teleported`            | 是否 teleport            | `boolean`         | `true`         |
| `trigger-on-focus`      | 聚焦时触发               | `boolean`         | `true`         |
| `value-key`             | 建议对象中用于显示的键名 | `string`          | `value`        |
| `debounce`              | 防抖延迟                 | `number`          | `300`          |
| `placement`             | 菜单弹出位置             | `string`          | `bottom-start` |
| `highlight-first-item`  | 默认高亮第一项           | `boolean`         | `false`        |
| `fit-input-width`       | 下拉框宽度与输入框相同   | `boolean`         | `false`        |
| `select-when-unmatched` | 未匹配时是否选中输入值   | `boolean`         | `false`        |

| 事件     | 说明       |
| -------- | ---------- |
| `select` | 选中建议项 |

```vue
<template>
  <el-autocomplete
    v-model="value"
    :fetch-suggestions="querySearch"
    placeholder="请输入"
    @select="handleSelect"
  />
</template>
```

---

## Switch

| 属性             | 说明             | 类型                        | 默认值  |
| ---------------- | ---------------- | --------------------------- | ------- |
| `v-model`        | 绑定值           | `boolean / string / number` | —       |
| `disabled`       | 禁用             | `boolean`                   | `false` |
| `loading`        | 加载中           | `boolean`                   | `false` |
| `size`           | 尺寸             | `large / default / small`   | —       |
| `width`          | 宽度             | `number / string`           | —       |
| `inline-prompt`  | 文字显示在开关内 | `boolean`                   | `false` |
| `active-icon`    | 打开时图标       | `string / Component`        | —       |
| `inactive-icon`  | 关闭时图标       | `string / Component`        | —       |
| `active-text`    | 打开时文字       | `string`                    | —       |
| `inactive-text`  | 关闭时文字       | `string`                    | —       |
| `active-value`   | 打开时值         | `boolean / string / number` | `true`  |
| `inactive-value` | 关闭时值         | `boolean / string / number` | `false` |
| `beforeChange`   | 切换前拦截       | `function`                  | —       |
| `name`           | 原生 name        | `string`                    | —       |
| `id`             | 原生 id          | `string`                    | —       |
| `tabindex`       | tabindex         | `string / number`           | —       |
| `validate-event` | 切换时触发校验   | `boolean`                   | `true`  |

| 事件     | 说明   |
| -------- | ------ |
| `change` | 值改变 |

```vue
<template>
  <el-switch v-model="value" />
  <el-switch v-model="value" active-text="开" inactive-text="关" />
</template>
```

---

## Radio / RadioButton / RadioGroup

### Radio 属性

| 属性       | 说明                      | 类型                        | 默认值  |
| ---------- | ------------------------- | --------------------------- | ------- |
| `v-model`  | 绑定值（配合 RadioGroup） | `string / number / boolean` | —       |
| `label`    | 单选框值                  | `string / number / boolean` | —       |
| `disabled` | 禁用                      | `boolean`                   | `false` |
| `border`   | 边框                      | `boolean`                   | `false` |
| `size`     | 尺寸                      | `large / default / small`   | —       |
| `name`     | 原生 name                 | `string`                    | —       |

### RadioGroup 属性

| 属性             | 说明               | 类型                        | 默认值  |
| ---------------- | ------------------ | --------------------------- | ------- |
| `v-model`        | 绑定值             | `string / number / boolean` | —       |
| `size`           | 尺寸               | `large / default / small`   | —       |
| `disabled`       | 禁用               | `boolean`                   | `false` |
| `text-color`     | 按钮激活时文字颜色 | `string`                    | —       |
| `fill`           | 按钮激活时背景色   | `string`                    | —       |
| `validate-event` | 切换时触发校验     | `boolean`                   | `true`  |

| 事件     | 说明   |
| -------- | ------ |
| `change` | 值改变 |

```vue
<template>
  <el-radio-group v-model="radio">
    <el-radio label="1">选项1</el-radio>
    <el-radio label="2">选项2</el-radio>
  </el-radio-group>

  <el-radio-group v-model="radio">
    <el-radio-button label="1">选项1</el-radio-button>
    <el-radio-button label="2">选项2</el-radio-button>
  </el-radio-group>
</template>
```

---

## Checkbox / CheckboxGroup / CheckboxButton

### Checkbox 属性

| 属性             | 说明           | 类型                                 | 默认值  |
| ---------------- | -------------- | ------------------------------------ | ------- |
| `v-model`        | 绑定值         | `string / number / boolean`          | —       |
| `label`          | 选中值         | `string / number / boolean / object` | —       |
| `true-label`     | 选中时值       | `string / number`                    | —       |
| `false-label`    | 未选中时值     | `string / number`                    | —       |
| `disabled`       | 禁用           | `boolean`                            | `false` |
| `border`         | 边框           | `boolean`                            | `false` |
| `size`           | 尺寸           | `large / default / small`            | —       |
| `checked`        | 初始选中       | `boolean`                            | —       |
| `indeterminate`  | 半选状态       | `boolean`                            | `false` |
| `validate-event` | 切换时触发校验 | `boolean`                            | `true`  |

### CheckboxGroup 属性

| 属性             | 说明               | 类型                      | 默认值  |
| ---------------- | ------------------ | ------------------------- | ------- |
| `v-model`        | 绑定值             | `string[] / number[]`     | `[]`    |
| `size`           | 尺寸               | `large / default / small` | —       |
| `disabled`       | 禁用               | `boolean`                 | `false` |
| `min`            | 最小可选数         | `number`                  | —       |
| `max`            | 最大可选数         | `number`                  | —       |
| `id`             | 原生 id            | `string`                  | —       |
| `label`          | 标签               | `string`                  | —       |
| `fill`           | 按钮激活时背景色   | `string`                  | —       |
| `text-color`     | 按钮激活时文字颜色 | `string`                  | —       |
| `tag`            | 渲染标签           | `string`                  | `div`   |
| `vertical`       | 垂直排列           | `boolean`                 | `false` |
| `validate-event` | 切换时触发校验     | `boolean`                 | `true`  |

| 事件     | 说明   |
| -------- | ------ |
| `change` | 值改变 |

```vue
<template>
  <el-checkbox-group v-model="checked">
    <el-checkbox label="1">选项1</el-checkbox>
    <el-checkbox label="2">选项2</el-checkbox>
  </el-checkbox-group>

  <el-checkbox-group v-model="checked">
    <el-checkbox-button label="1">选项1</el-checkbox-button>
    <el-checkbox-button label="2">选项2</el-checkbox-button>
  </el-checkbox-group>

  <el-checkbox v-model="checked" indeterminate>半选</el-checkbox>
</template>
```

---

## Select / Option / OptionGroup / SelectV2

### Select 属性

| 属性                    | 说明                      | 类型                                                       | 默认值         |
| ----------------------- | ------------------------- | ---------------------------------------------------------- | -------------- | --- |
| `v-model`               | 绑定值                    | `string / number / boolean / object / string[] / number[]` | —              |
| `multiple`              | 多选                      | `boolean`                                                  | `false`        |
| `disabled`              | 禁用                      | `boolean`                                                  | `false`        |
| `value-key`             | 作为 value 唯一标识的键名 | `string`                                                   | `value`        |
| `size`                  | 尺寸                      | `large / default / small`                                  | —              |
| `clearable`             | 可清空                    | `boolean`                                                  | `false`        |
| `collapse-tags`         | 多选时折叠标签            | `boolean`                                                  | `false`        |
| `collapse-tags-tooltip` | 折叠标签显示 tooltip      | `boolean`                                                  | `false`        |
| `multiple-limit`        | 多选限制                  | `number`                                                   | `0`（无限制）  |
| `name`                  | 原生 name                 | `string`                                                   | —              |
| `placeholder`           | 占位文本                  | `string`                                                   | —              |
| `filterable`            | 可搜索                    | `boolean`                                                  | `false`        |
| `allow-create`          | 允许创建                  | `boolean`                                                  | `false`        |
| `remote`                | 远程搜索                  | `boolean`                                                  | `false`        |
| `remote-method`         | 远程搜索方法              | `function`                                                 | —              |
| `loading`               | 加载中                    | `boolean`                                                  | `false`        |
| `loading-text`          | 加载文本                  | `string`                                                   | —              |
| `no-match-text`         | 无匹配文本                | `string`                                                   | —              |
| `no-data-text`          | 无数据文本                | `string`                                                   | —              |
| `popper-class`          | 下拉框类名                | `string`                                                   | —              |
| `reserve-keyword`       | 多选时保留搜索词          | `boolean`                                                  | `false`        |
| `default-first-option`  | 默认选中第一项            | `boolean`                                                  | `false`        |
| `popper-options`        | popper.js 参数            | `object`                                                   | —              |
| `automatic-dropdown`    | 自动弹出                  | `boolean`                                                  | `false`        |
| `fit-input-width`       | 下拉框宽度与输入框相同    | `boolean`                                                  | `false`        |
| `suffix-icon`           | 后缀图标                  | `string / Component`                                       | `ArrowUp`      |
| `suffix-transition`     | 后缀图标动画              | `boolean`                                                  | `true`         |
| `tag-type`              | 标签类型                  | `primary / success / info / warning / danger`              | `info`         |
| `validate-event`        | 切换时触发校验            | `boolean`                                                  | `true`         |
| `placement`             | 菜单位置                  | `string`                                                   | `bottom-start` |
| `fallback-placements`   | 回退位置                  | `string[]`                                                 | —              |
| `max-collapse-tags`     | 最大折叠标签数            | `number`                                                   | `1`            |
| `teleported`            | 是否 teleport             | `boolean`                                                  | `true`         |
| `persistent`            | 下拉框不销毁              | `boolean`                                                  | `true`         |
| `clear-icon`            | 清空图标                  | `string / Component`                                       | `CircleClose`  |
| `scrollbar-always-on`   | 滚动条常显                | `boolean`                                                  | `false`        |
| `inline`                | 行内模式                  | `boolean`                                                  | —              | 🔧  |
| `reserve-keyword`       | 多选时保留搜索词          | `boolean`                                                  | `true`         | ⚠️  |
| `show-extra`            | 显示额外操作区            | `boolean`                                                  | `false`        | 🔧  |

### Select 事件

| 事件             | 说明         |
| ---------------- | ------------ | --- |
| `change`         | 值改变       |
| `visible-change` | 下拉框显隐   |
| `remove-tag`     | 移除标签     |
| `clear`          | 清空         |
| `blur`           | 失焦         |
| `focus`          | 聚焦         |
| `extra-click`    | 点击额外操作 | 🔧  |

### Option 属性

| 属性       | 说明     | 类型                                 | 默认值  |
| ---------- | -------- | ------------------------------------ | ------- |
| `value`    | 选项值   | `string / number / boolean / object` | —       |
| `label`    | 选项标签 | `string / number`                    | —       |
| `disabled` | 禁用     | `boolean`                            | `false` |

### OptionGroup 属性

| 属性       | 说明     | 类型      | 默认值  |
| ---------- | -------- | --------- | ------- |
| `label`    | 分组标签 | `string`  | —       |
| `disabled` | 禁用     | `boolean` | `false` |

```vue
<template>
  <el-select v-model="value" placeholder="请选择" clearable>
    <el-option label="选项1" value="1" />
    <el-option label="选项2" value="2" />
  </el-select>

  <el-select v-model="value" multiple collapse-tags>
    <el-option-group label="分组1">
      <el-option label="选项1" value="1" />
    </el-option-group>
  </el-select>
</template>
```

### SelectV2

虚拟化选择器，适用于选项数量巨大的场景。

```vue
<template>
  <el-select-v2
    v-model="value"
    :options="options"
    placeholder="请选择"
    clearable
  />
</template>
```

---

## DatePicker

| 属性                | 说明           | 类型                                                                                     | 默认值  |
| ------------------- | -------------- | ---------------------------------------------------------------------------------------- | ------- |
| `v-model`           | 绑定值         | `Date / [Date, Date] / string / [string, string]`                                        | —       |
| `type`              | 显示类型       | `year / month / date / dates / datetime / week / datetimerange / daterange / monthrange` | `date`  |
| `format`            | 显示格式       | `string`                                                                                 | —       |
| `value-format`      | 绑定值格式     | `string`                                                                                 | —       |
| `placeholder`       | 占位文本       | `string`                                                                                 | —       |
| `start-placeholder` | 开始占位文本   | `string`                                                                                 | —       |
| `end-placeholder`   | 结束占位文本   | `string`                                                                                 | —       |
| `disabled`          | 禁用           | `boolean`                                                                                | `false` |
| `clearable`         | 可清空         | `boolean`                                                                                | `true`  |
| `size`              | 尺寸           | `large / default / small`                                                                | —       |
| `readonly`          | 只读           | `boolean`                                                                                | `false` |
| `editable`          | 可输入         | `boolean`                                                                                | `true`  |
| `popper-class`      | 下拉框类名     | `string`                                                                                 | —       |
| `range-separator`   | 分隔符         | `string`                                                                                 | `'-'`   |
| `default-value`     | 默认显示日期   | `Date`                                                                                   | —       |
| `default-time`      | 默认时间       | `Date / [Date, Date]`                                                                    | —       |
| `unlink-panels`     | 取消联动       | `boolean`                                                                                | `false` |
| `prefix-icon`       | 头部图标       | `string / Component`                                                                     | —       |
| `clear-icon`        | 清空图标       | `string / Component`                                                                     | —       |
| `validate-event`    | 切换时触发校验 | `boolean`                                                                                | `true`  |
| `teleported`        | 是否 teleport  | `boolean`                                                                                | `true`  |

| 事件              | 说明           |
| ----------------- | -------------- |
| `change`          | 值改变         |
| `blur`            | 失焦           |
| `focus`           | 聚焦           |
| `calendar-change` | 日期范围变化时 |
| `panel-change`    | 面板变化时     |
| `visible-change`  | 下拉框显隐     |

```vue
<template>
  <el-date-picker v-model="date" type="date" placeholder="选择日期" />
  <el-date-picker v-model="dateRange" type="daterange" />
  <el-date-picker v-model="dateTime" type="datetime" />
</template>
```

---

## TimePicker / TimeSelect

### TimePicker 属性

| 属性                | 说明           | 类型                                              | 默认值       |
| ------------------- | -------------- | ------------------------------------------------- | ------------ |
| `v-model`           | 绑定值         | `Date / [Date, Date] / string / [string, string]` | —            |
| `is-range`          | 范围选择       | `boolean`                                         | `false`      |
| `placeholder`       | 占位文本       | `string`                                          | —            |
| `start-placeholder` | 开始占位       | `string`                                          | —            |
| `end-placeholder`   | 结束占位       | `string`                                          | —            |
| `disabled`          | 禁用           | `boolean`                                         | `false`      |
| `clearable`         | 可清空         | `boolean`                                         | `true`       |
| `size`              | 尺寸           | `large / default / small`                         | —            |
| `format`            | 显示格式       | `string`                                          | `'HH:mm:ss'` |
| `value-format`      | 绑定值格式     | `string`                                          | —            |
| `arrow-control`     | 箭头选择       | `boolean`                                         | `false`      |
| `popper-class`      | 下拉框类名     | `string`                                          | —            |
| `range-separator`   | 分隔符         | `string`                                          | `'-'`        |
| `default-value`     | 默认时间       | `Date`                                            | —            |
| `prefix-icon`       | 头部图标       | `string / Component`                              | —            |
| `clear-icon`        | 清空图标       | `string / Component`                              | —            |
| `validate-event`    | 切换时触发校验 | `boolean`                                         | `true`       |
| `teleported`        | 是否 teleport  | `boolean`                                         | `true`       |

### TimeSelect 属性

| 属性          | 说明     | 类型                      | 默认值    |
| ------------- | -------- | ------------------------- | --------- |
| `v-model`     | 绑定值   | `string`                  | —         |
| `disabled`    | 禁用     | `boolean`                 | `false`   |
| `editable`    | 可输入   | `boolean`                 | `true`    |
| `clearable`   | 可清空   | `boolean`                 | `true`    |
| `size`        | 尺寸     | `large / default / small` | —         |
| `placeholder` | 占位文本 | `string`                  | —         |
| `start`       | 开始时间 | `string`                  | `'09:00'` |
| `end`         | 结束时间 | `string`                  | `'18:00'` |
| `step`        | 间隔时间 | `string`                  | `'00:30'` |
| `min-time`    | 最早时间 | `string`                  | —         |
| `max-time`    | 最晚时间 | `string`                  | —         |
| `prefix-icon` | 头部图标 | `string / Component`      | —         |
| `clear-icon`  | 清空图标 | `string / Component`      | —         |

```vue
<template>
  <el-time-picker v-model="time" placeholder="选择时间" />
  <el-time-select v-model="time" start="08:00" step="00:15" end="20:00" />
</template>
```

---

## Cascader

级联选择器。

| 属性                | 说明           | 类型                                    | 默认值  |
| ------------------- | -------------- | --------------------------------------- | ------- |
| `v-model`           | 绑定值         | `string / number / string[] / number[]` | —       |
| `options`           | 选项数据源     | `object[]`                              | —       |
| `props`             | 配置选项       | `object`                                | —       |
| `size`              | 尺寸           | `large / default / small`               | —       |
| `placeholder`       | 占位文本       | `string`                                | —       |
| `disabled`          | 禁用           | `boolean`                               | `false` |
| `clearable`         | 可清空         | `boolean`                               | `false` |
| `show-all-levels`   | 显示完整路径   | `boolean`                               | `true`  |
| `collapse-tags`     | 折叠标签       | `boolean`                               | `false` |
| `separator`         | 分隔符         | `string`                                | `' / '` |
| `filterable`        | 可搜索         | `boolean`                               | `false` |
| `filter-method`     | 自定义搜索     | `function`                              | —       |
| `debounce`          | 防抖延迟       | `number`                                | `300`   |
| `before-filter`     | 搜索前钩子     | `function`                              | —       |
| `popper-class`      | 下拉框类名     | `string`                                | —       |
| `teleported`        | 是否 teleport  | `boolean`                               | `true`  |
| `tag-type`          | 标签类型       | `string`                                | `info`  |
| `validate-event`    | 切换时触发校验 | `boolean`                               | `true`  |
| `max-collapse-tags` | 最大折叠标签数 | `number`                                | `1`     |
| `empty-values`      | 空值定义       | `array`                                 | —       |
| `value-on-clear`    | 清空时值       | `string / number / boolean / function`  | —       |

| 事件             | 说明         |
| ---------------- | ------------ |
| `change`         | 值改变       |
| `expand-change`  | 展开节点变化 |
| `blur`           | 失焦         |
| `focus`          | 聚焦         |
| `visible-change` | 下拉框显隐   |
| `remove-tag`     | 移除标签     |

```vue
<template>
  <el-cascader
    v-model="value"
    :options="options"
    :props="{ value: 'id', label: 'name', children: 'children' }"
  />
</template>
```

---

## TreeSelect

树形选择器。

| 属性                  | 说明             | 类型                                    | 默认值  |
| --------------------- | ---------------- | --------------------------------------- | ------- |
| `v-model`             | 绑定值           | `string / number / string[] / number[]` | —       |
| `data`                | 树形数据         | `object[]`                              | `[]`    |
| `props`               | 配置选项         | `object`                                | —       |
| `multiple`            | 多选             | `boolean`                               | `false` |
| `disabled`            | 禁用             | `boolean`                               | `false` |
| `clearable`           | 可清空           | `boolean`                               | `false` |
| `collapse-tags`       | 折叠标签         | `boolean`                               | `false` |
| `placeholder`         | 占位文本         | `string`                                | —       |
| `filterable`          | 可搜索           | `boolean`                               | `false` |
| `filter-method`       | 自定义搜索       | `function`                              | —       |
| `render-after-expand` | 展开后渲染子节点 | `boolean`                               | `true`  |
| `check-strictly`      | 父子节点不关联   | `boolean`                               | `false` |
| `check-on-click-node` | 点击节点选中     | `boolean`                               | `false` |
| `popper-class`        | 下拉框类名       | `string`                                | —       |
| `teleported`          | 是否 teleport    | `boolean`                               | `true`  |

| 事件             | 说明       |
| ---------------- | ---------- |
| `change`         | 值改变     |
| `visible-change` | 下拉框显隐 |
| `remove-tag`     | 移除标签   |
| `clear`          | 清空       |

```vue
<template>
  <el-tree-select v-model="value" :data="treeData" />
</template>
```

---

## Upload

| 属性                | 说明           | 类型                            | 默认值   |
| ------------------- | -------------- | ------------------------------- | -------- |
| `v-model:file-list` | 文件列表       | `UploadUserFile[]`              | `[]`     |
| `action`            | 上传地址       | `string`                        | `'#'`    |
| `headers`           | 请求头         | `object`                        | —        |
| `method`            | 请求方法       | `string`                        | `'post'` |
| `multiple`          | 多选           | `boolean`                       | `false`  |
| `data`              | 额外参数       | `object`                        | —        |
| `type`              | 上传类型       | `string`                        | —        |
| `name`              | 文件字段名     | `string`                        | `'file'` |
| `with-credentials`  | 携带 cookie    | `boolean`                       | `false`  |
| `show-file-list`    | 显示文件列表   | `boolean`                       | `true`   |
| `drag`              | 拖拽上传       | `boolean`                       | `false`  |
| `accept`            | 接受文件类型   | `string`                        | —        |
| `before-upload`     | 上传前钩子     | `function`                      | —        |
| `on-remove`         | 移除时钩子     | `function`                      | —        |
| `on-success`        | 成功时钩子     | `function`                      | —        |
| `on-error`          | 失败时钩子     | `function`                      | —        |
| `on-progress`       | 进度钩子       | `function`                      | —        |
| `on-change`         | 状态改变钩子   | `function`                      | —        |
| `on-exceed`         | 超出限制钩子   | `function`                      | —        |
| `before-remove`     | 移除前钩子     | `function`                      | —        |
| `list-type`         | 列表类型       | `text / picture / picture-card` | `text`   |
| `auto-upload`       | 自动上传       | `boolean`                       | `true`   |
| `file-list`         | 文件列表       | `UploadUserFile[]`              | `[]`     |
| `http-request`      | 自定义上传     | `function`                      | —        |
| `disabled`          | 禁用           | `boolean`                       | `false`  |
| `limit`             | 最大允许上传数 | `number`                        | —        |

| 插槽      | 说明         |
| --------- | ------------ |
| `trigger` | 触发文件选择 |
| `tip`     | 提示文字     |
| `file`    | 文件列表内容 |

```vue
<template>
  <el-upload
    v-model:file-list="fileList"
    action="/api/upload"
    :on-success="handleSuccess"
  >
    <el-button type="primary">点击上传</el-button>
  </el-upload>
</template>
```

---

## ColorPicker

| 属性             | 说明           | 类型                      | 默认值  |
| ---------------- | -------------- | ------------------------- | ------- |
| `v-model`        | 绑定值         | `string`                  | —       |
| `disabled`       | 禁用           | `boolean`                 | `false` |
| `size`           | 尺寸           | `large / default / small` | —       |
| `show-alpha`     | 透明度         | `boolean`                 | `false` |
| `color-format`   | 颜色格式       | `hsl / hsv / hex / rgb`   | —       |
| `popper-class`   | 下拉框类名     | `string`                  | —       |
| `predefine`      | 预定义颜色     | `string[]`                | `[]`    |
| `validate-event` | 切换时触发校验 | `boolean`                 | `true`  |
| `tabindex`       | tabindex       | `number`                  | `0`     |
| `label`          | 标签           | `string`                  | —       |
| `id`             | 原生 id        | `string`                  | —       |

| 事件            | 说明         |
| --------------- | ------------ |
| `change`        | 值改变       |
| `active-change` | 颜色实时改变 |

```vue
<template>
  <el-color-picker v-model="color" />
  <el-color-picker v-model="color" show-alpha />
</template>
```

---

## Slider

| 属性                  | 说明           | 类型                        | 默认值  |
| --------------------- | -------------- | --------------------------- | ------- |
| `v-model`             | 绑定值         | `number / [number, number]` | `0`     |
| `min`                 | 最小值         | `number`                    | `0`     |
| `max`                 | 最大值         | `number`                    | `100`   |
| `disabled`            | 禁用           | `boolean`                   | `false` |
| `step`                | 步进           | `number`                    | `1`     |
| `show-input`          | 显示输入框     | `boolean`                   | `false` |
| `show-input-controls` | 输入框控制按钮 | `boolean`                   | `true`  |
| `size`                | 尺寸           | `large / default / small`   | —       |
| `input-size`          | 输入框尺寸     | `large / default / small`   | —       |
| `show-stops`          | 显示间断点     | `boolean`                   | `false` |
| `show-tooltip`        | 显示 tooltip   | `boolean`                   | `true`  |
| `format-tooltip`      | tooltip 格式化 | `function`                  | —       |
| `range`               | 范围选择       | `boolean`                   | `false` |
| `vertical`            | 垂直模式       | `boolean`                   | `false` |
| `height`              | 垂直模式高度   | `string`                    | —       |
| `debounce`            | 防抖延迟       | `number`                    | `300`   |
| `label`               | 无障碍标签     | `string`                    | —       |
| `tooltip-class`       | tooltip 类名   | `string`                    | —       |
| `marks`               | 标记           | `object`                    | —       |
| `range-start-label`   | 范围开始标签   | `string`                    | —       |
| `range-end-label`     | 范围结束标签   | `string`                    | —       |
| `format-value-text`   | 值格式化函数   | `function`                  | —       |
| `placement`           | tooltip 位置   | `string`                    | `top`   |
| `validate-event`      | 切换时触发校验 | `boolean`                   | `true`  |

| 事件     | 说明       |
| -------- | ---------- |
| `change` | 值改变     |
| `input`  | 值实时改变 |

```vue
<template>
  <el-slider v-model="value" />
  <el-slider v-model="range" range />
</template>
```

---

## Rate

| 属性                  | 说明           | 类型                                          | 默认值                                                               |
| --------------------- | -------------- | --------------------------------------------- | -------------------------------------------------------------------- |
| `v-model`             | 绑定值         | `number`                                      | `0`                                                                  |
| `max`                 | 最大分值       | `number`                                      | `5`                                                                  |
| `disabled`            | 禁用           | `boolean`                                     | `false`                                                              |
| `allow-half`          | 允许半选       | `boolean`                                     | `false`                                                              |
| `low-threshold`       | 低分界限       | `number`                                      | `2`                                                                  |
| `high-threshold`      | 高分界限       | `number`                                      | `4`                                                                  |
| `colors`              | 图标颜色       | `string / string[]`                           | `['', '', '']`                                                       |
| `void-color`          | 未选中颜色     | `string`                                      | —                                                                    |
| `disabled-void-color` | 禁用未选中颜色 | `string`                                      | —                                                                    |
| `icons`               | 图标           | `string / string[] / Component / Component[]` | `['StarFilled', 'StarFilled', 'StarFilled']`                         |
| `void-icon`           | 未选中图标     | `string / Component`                          | `Star`                                                               |
| `disabled-void-icon`  | 禁用未选中图标 | `string / Component`                          | `StarFilled`                                                         |
| `show-text`           | 显示文字       | `boolean`                                     | `false`                                                              |
| `show-score`          | 显示分数       | `boolean`                                     | `false`                                                              |
| `text-color`          | 文字颜色       | `string`                                      | —                                                                    |
| `texts`               | 文字数组       | `string[]`                                    | `['Extremely bad', 'Disappointed', 'Fair', 'Satisfied', 'Surprise']` |
| `score-template`      | 分数模板       | `string`                                      | `{value}`                                                            |
| `size`                | 尺寸           | `large / default / small`                     | —                                                                    |

| 事件     | 说明   |
| -------- | ------ |
| `change` | 值改变 |

```vue
<template>
  <el-rate v-model="rate" />
  <el-rate v-model="rate" allow-half show-score />
</template>
```

---

## Form / FormItem

### Form 属性

| 属性                      | 说明               | 类型                      | 默认值  |
| ------------------------- | ------------------ | ------------------------- | ------- | --- |
| `model`                   | 表单数据           | `object`                  | —       |
| `rules`                   | 校验规则           | `FormRules`               | —       |
| `inline`                  | 行内表单           | `boolean`                 | —       | ⚠️  |
| `label-position`          | 标签位置           | `left / right / top`      | `right` |
| `label-width`             | 标签宽度           | `string / number`         | —       |
| `label-suffix`            | 标签后缀           | `string`                  | —       |
| `hide-required-asterisk`  | 隐藏必填星号       | `boolean`                 | `false` |
| `show-message`            | 显示校验信息       | `boolean`                 | `true`  |
| `inline-message`          | 行内显示校验信息   | `boolean`                 | `false` |
| `status-icon`             | 显示状态图标       | `boolean`                 | `false` |
| `validate-on-rule-change` | 规则变化时校验     | `boolean`                 | `true`  |
| `size`                    | 尺寸               | `large / default / small` | —       |
| `disabled`                | 禁用所有组件       | `boolean`                 | `false` |
| `scroll-to-error`         | 校验失败滚动到错误 | `boolean`                 | `false` |
| `text`                    | 纯文本模式         | `boolean`                 | —       |

### Form 方法

| 方法            | 说明           | 参数                      |
| --------------- | -------------- | ------------------------- |
| `validate`      | 对整个表单校验 | `callback` 或返回 Promise |
| `validateField` | 对指定字段校验 | `props, callback`         |
| `resetFields`   | 重置所有字段   | `props`                   |
| `scrollToField` | 滚动到指定字段 | `prop`                    |
| `clearValidate` | 清除校验       | `props`                   |

### Form 事件

| 事件       | 说明                 |
| ---------- | -------------------- |
| `validate` | 任一表单项校验后触发 |

### FormItem 属性

| 属性              | 说明             | 类型                                      | 默认值 |
| ----------------- | ---------------- | ----------------------------------------- | ------ | --- |
| `prop`            | 字段名           | `string`                                  | —      |
| `label`           | 标签             | `string`                                  | —      |
| `label-width`     | 标签宽度         | `string / number`                         | —      |
| `required`        | 必填             | `boolean`                                 | —      |
| `rules`           | 校验规则         | `FormItemRule / FormItemRule[]`           | —      |
| `error`           | 错误信息         | `string`                                  | —      |
| `show-message`    | 显示校验信息     | `boolean`                                 | `true` |
| `inline-message`  | 行内显示校验信息 | `string / boolean`                        | `''`   |
| `size`            | 尺寸             | `large / default / small`                 | —      |
| `for`             | 原生 for         | `string`                                  | —      |
| `validate-status` | 校验状态         | `'' / 'error' / 'validating' / 'success'` | —      |
| `inline`          | 行内模式         | `boolean`                                 | —      | ⚠️  |
| `text`            | 纯文本模式       | `boolean`                                 | —      |
| `fixed-right`     | 右侧固定         | `boolean`                                 | —      |

```vue
<template>
  <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
    <el-form-item label="名称" prop="name">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="handleSubmit">提交</el-button>
      <el-button @click="formRef?.resetFields()">重置</el-button>
    </el-form-item>
  </el-form>
</template>
```
