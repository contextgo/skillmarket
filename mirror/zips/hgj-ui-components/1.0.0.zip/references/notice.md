# Notice

**注册名**：`ElNotice` | **模板标签**：`el-notice`

通知公告组件，用于页面顶部展示重要通知信息。

---

## 属性

| 名称              | 说明               | 类型           | 默认值                                |
| ----------------- | ------------------ | -------------- | ------------------------------------- |
| `data`            | 公告数据源         | `NoticeData[]` | `[]`                                  |
| `v-model:expand`  | 是否展开           | `boolean`      | `true`                                |
| `collapsedHeight` | 折叠时的高度（px） | `number`       | `20`                                  |
| `interval`        | 轮播滚动间隔（ms） | `number`       | `5000`                                |
| `storageKey`      | 本地存储键名       | `string`       | `'hep-notice-storage-collapsedState'` |
| `persistence`     | 是否启用持久化     | `boolean`      | `true`                                |

## 事件

| 名称          | 说明           | 回调参数        |
| ------------- | -------------- | --------------- |
| `indexChange` | 轮播公告切换时 | `index: number` |

## NoticeData 结构

```ts
type NoticeData = {
  content: string
  type?: 'new' | 'important' | 'normal'
  dangerouslyUseHTMLString?: boolean
}
```

## 插槽

| 名称      | 说明                               |
| --------- | ---------------------------------- |
| `default` | 自定义公告内容                     |
| `icon`    | 自定义左侧图标（默认显示声音图标） |

## 行为特性

- 展开状态：显示所有公告
- 折叠状态：自动轮播显示单条公告
- 持久化：默认开启，通过 `localStorage` 记住用户的折叠/展开状态
- 支持 HTML 内容（通过 `dangerouslyUseHTMLString`）
