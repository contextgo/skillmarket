# 方法型反馈 API

以下方法需通过函数调用方式使用，**非模板组件**。适用于消息提示、确认弹窗、全局通知和加载状态等交互场景。

```ts
import {
  ElMessage,
  ElMessageBox,
  ElNotification,
  ElLoading,
} from '@hgj/element-plus'
```

---

## ElMessage 消息提示

轻量级全局消息，自动消失，不打断用户操作。

### 调用方式

| 调用形式       | 签名                                                            |
| -------------- | --------------------------------------------------------------- |
| 字符串快捷调用 | `ElMessage(message: string \| VNode)`                           |
| 配置对象调用   | `ElMessage(options: MessageOptions)`                            |
| 类型快捷方法   | `ElMessage.success / warning / info / error(options \| string)` |
| 关闭全部       | `ElMessage.closeAll(type?: MessageType)`                        |

### 配置参数

| 参数                       | 说明                            | 类型                               | 默认值          |
| -------------------------- | ------------------------------- | ---------------------------------- | --------------- |
| `message`                  | 消息内容                        | `string / VNode / (() => VNode)`   | —               |
| `type`                     | 类型                            | `success / warning / info / error` | `info`          |
| `duration`                 | 显示时长(ms)，设为 0 不自动关闭 | `number`                           | `3000`          |
| `showClose`                | 显示关闭按钮                    | `boolean`                          | `false`         |
| `center`                   | 内容居中                        | `boolean`                          | `false`         |
| `icon`                     | 自定义图标                      | `string / Component`               | —               |
| `customClass`              | 自定义类名                      | `string`                           | `''`            |
| `offset`                   | 距离窗口顶部的偏移(px)          | `number`                           | `60`            |
| `zIndex`                   | 层级                            | `number`                           | `0`             |
| `grouping`                 | 相同消息合并计数                | `boolean`                          | `false`         |
| `repeatNum`                | 重复次数（grouping 时自动累加） | `number`                           | `1`             |
| `dangerouslyUseHTMLString` | message 是否作为 HTML 渲染      | `boolean`                          | `false`         |
| `appendTo`                 | 挂载节点                        | `HTMLElement / string`             | `document.body` |
| `onClose`                  | 关闭回调                        | `() => void`                       | —               |

### 返回值

`MessageHandler` 对象，包含 `close()` 方法用于手动关闭。

### 示例

```ts
// 最简调用
ElMessage('操作成功')

// 类型调用
ElMessage.success('保存成功')
ElMessage.warning('请检查输入')
ElMessage.error('删除失败')
ElMessage.info('这是一条提示')

// 配置对象
ElMessage({
  message: '提交中...',
  type: 'info',
  duration: 0,
  showClose: true,
})

// 手动关闭
const msg = ElMessage.loading('加载中')
setTimeout(() => msg.close(), 2000)

// 关闭所有消息
ElMessage.closeAll()
ElMessage.closeAll('error')
```

---

## ElMessageBox 消息弹窗

模态对话框，用于需要用户确认或输入的场景，阻塞式交互。

### 调用方式

所有调用均返回 `Promise<MessageBoxData>`。

| 方法                                              | 说明         | 默认行为                        |
| ------------------------------------------------- | ------------ | ------------------------------- |
| `ElMessageBox(options)`                           | 通用弹窗     | 根据配置决定按钮                |
| `ElMessageBox.alert(message, title?, options?)`   | 警告弹窗     | 仅确认按钮，点击遮罩/ESC 不关闭 |
| `ElMessageBox.confirm(message, title?, options?)` | 确认弹窗     | 确认+取消按钮                   |
| `ElMessageBox.prompt(message, title?, options?)`  | 输入弹窗     | 确认+取消按钮，带输入框         |
| `ElMessageBox.close()`                            | 关闭当前弹窗 | —                               |

`message` 和 `title` 参数可省略，直接传入 `options` 对象。

### 配置参数

| 参数                        | 说明                   | 类型                               | 默认值                            |
| --------------------------- | ---------------------- | ---------------------------------- | --------------------------------- |
| `message`                   | 内容                   | `string / VNode`                   | —                                 |
| `title`                     | 标题                   | `string`                           | —                                 |
| `type`                      | 图标类型               | `success / warning / info / error` | —                                 |
| `icon`                      | 自定义图标             | `string / Component`               | —                                 |
| `customClass`               | 自定义类名             | `string`                           | —                                 |
| `customStyle`               | 自定义内联样式         | `CSSProperties`                    | —                                 |
| `center`                    | 内容居中               | `boolean`                          | `false`                           |
| `draggable`                 | 可拖拽                 | `boolean`                          | `false`                           |
| `showClose`                 | 显示关闭按钮           | `boolean`                          | `true`                            |
| `showConfirmButton`         | 显示确认按钮           | `boolean`                          | `true`                            |
| `showCancelButton`          | 显示取消按钮           | `boolean`                          | `false`（confirm/prompt 为 true） |
| `confirmButtonText`         | 确认按钮文字           | `string`                           | —                                 |
| `cancelButtonText`          | 取消按钮文字           | `string`                           | —                                 |
| `confirmButtonClass`        | 确认按钮类名           | `string`                           | —                                 |
| `cancelButtonClass`         | 取消按钮类名           | `string`                           | —                                 |
| `confirmButtonDisabled`     | 禁用确认按钮           | `boolean`                          | `false`                           |
| `confirmButtonLoading`      | 确认按钮加载状态       | `boolean`                          | `false`                           |
| `cancelButtonLoading`       | 取消按钮加载状态       | `boolean`                          | `false`                           |
| `roundButton`               | 圆角按钮               | `boolean`                          | `false`                           |
| `buttonSize`                | 按钮尺寸               | `large / default / small`          | —                                 |
| `closeOnClickModal`         | 点击遮罩关闭           | `boolean`                          | `true`（alert 为 false）          |
| `closeOnPressEscape`        | ESC 关闭               | `boolean`                          | `true`（alert 为 false）          |
| `closeOnHashChange`         | 路由变化关闭           | `boolean`                          | `true`                            |
| `lockScroll`                | 锁定滚动               | `boolean`                          | `true`                            |
| `distinguishCancelAndClose` | 区分取消与关闭         | `boolean`                          | `false`                           |
| `dangerouslyUseHTMLString`  | message 作为 HTML      | `boolean`                          | `false`                           |
| `autofocus`                 | 打开时自动聚焦         | `boolean`                          | `true`                            |
| `beforeClose`               | 关闭前钩子             | `(action, instance, done) => void` | —                                 |
| `callback`                  | 回调方式（非 Promise） | `(action, instance) => void`       | —                                 |

#### 输入框相关（prompt 专用）

| 参数                | 说明                                | 类型                          | 默认值                    |
| ------------------- | ----------------------------------- | ----------------------------- | ------------------------- |
| `showInput`         | 显示输入框                          | `boolean`                     | `false`（prompt 为 true） |
| `inputValue`        | 输入框默认值                        | `string`                      | —                         |
| `inputPlaceholder`  | 占位符                              | `string`                      | —                         |
| `inputType`         | 输入类型                            | `string`                      | `'text'`                  |
| `inputPattern`      | 校验正则                            | `RegExp`                      | —                         |
| `inputValidator`    | 校验函数，返回 boolean 或错误字符串 | `(value) => boolean / string` | —                         |
| `inputErrorMessage` | 校验失败提示                        | `string`                      | —                         |

### 返回值与 Action

| Action      | 触发场景                                                                      |
| ----------- | ----------------------------------------------------------------------------- |
| `'confirm'` | 点击确认按钮                                                                  |
| `'cancel'`  | 点击取消按钮（含关闭按钮，当 `distinguishCancelAndClose` 为 false 时）        |
| `'close'`   | 点击关闭按钮或遮罩/ESC（仅当 `distinguishCancelAndClose` 为 true 时单独区分） |

- `alert/confirm` 的 Promise resolve 值为 `Action` 字符串。
- `prompt` 的 Promise resolve 值为 `{ value: string, action: Action }`。
- 用户取消/关闭时，Promise 会被 reject，reason 为 `'cancel'` 或 `'close'`。

### 示例

```ts
// Alert
await ElMessageBox.alert('这是一段内容', '标题', {
  confirmButtonText: '确定',
  type: 'warning',
})

// Confirm
await ElMessageBox.confirm('确定删除该记录吗？', '提示', {
  confirmButtonText: '确定',
  cancelButtonText: '取消',
  type: 'warning',
})
// 用户点击取消/关闭会抛出错误，需 try-catch 或 catch()

// Prompt
const { value } = await ElMessageBox.prompt('请输入备注', '提示', {
  inputValidator: (val) => val.length > 0 || '备注不能为空',
  inputErrorMessage: '备注不能为空',
})
console.log('输入内容:', value)

// 使用 beforeClose 防止误关闭
await ElMessageBox.confirm('确定退出吗？', {
  beforeClose: (action, instance, done) => {
    if (action === 'confirm') {
      instance.confirmButtonLoading = true
      api.logout().then(() => {
        instance.confirmButtonLoading = false
        done()
      })
    } else {
      done()
    }
  },
})

// 快捷调用
await ElMessageBox.confirm('确认删除？')
await ElMessageBox.alert('系统提示')
```

---

## ElNotification 通知

右上角/其他角落弹出的全局通知卡片，可配置操作按钮。

### 调用方式

| 调用形式       | 签名                                                                 |
| -------------- | -------------------------------------------------------------------- |
| 字符串快捷调用 | `ElNotification(message: string \| VNode)`                           |
| 配置对象调用   | `ElNotification(options: NotificationOptions)`                       |
| 类型快捷方法   | `ElNotification.success / warning / error / info(options \| string)` |
| 关闭全部       | `ElNotification.closeAll()`                                          |

### 配置参数

| 参数                       | 说明                       | 类型                                                | 默认值          |
| -------------------------- | -------------------------- | --------------------------------------------------- | --------------- |
| `title`                    | 标题                       | `string`                                            | `''`            |
| `message`                  | 内容                       | `string / VNode`                                    | —               |
| `type`                     | 类型                       | `success / warning / info / error`                  | —               |
| `icon`                     | 自定义图标                 | `string / Component`                                | —               |
| `duration`                 | 显示时长(ms)，0 不自动关闭 | `number`                                            | `4500`          |
| `position`                 | 位置                       | `top-right / top-left / bottom-right / bottom-left` | `top-right`     |
| `offset`                   | 偏移(px)                   | `number`                                            | `0`             |
| `showClose`                | 显示关闭按钮               | `boolean`                                           | `true`          |
| `customClass`              | 自定义类名                 | `string`                                            | `''`            |
| `zIndex`                   | 层级                       | `number`                                            | `0`             |
| `dangerouslyUseHTMLString` | message 作为 HTML          | `boolean`                                           | `false`         |
| `appendTo`                 | 挂载节点                   | `HTMLElement / string`                              | `document.body` |
| `showBtn`                  | 显示操作按钮               | `boolean`                                           | `false`         |
| `btnText`                  | 按钮文字                   | `string`                                            | —               |
| `limitMessage`             | 限制消息长度               | `boolean`                                           | `true`          |
| `onClose`                  | 关闭回调                   | `() => void`                                        | —               |
| `onClick`                  | 点击回调                   | `() => void`                                        | —               |
| `onClickBtn`               | 点击按钮回调               | `() => void`                                        | —               |

### 返回值

`NotificationHandle` 对象，包含 `close()` 方法用于手动关闭。

### 示例

```ts
// 最简调用
ElNotification('操作成功')

// 类型调用
ElNotification.success({ title: '成功', message: '数据已保存' })
ElNotification.error({ title: '错误', message: '请求失败，请重试' })

// 带操作按钮
ElNotification({
  title: '系统通知',
  message: '您有一条新消息',
  showBtn: true,
  btnText: '查看详情',
  onClickBtn: () => router.push('/message'),
})

// 手动关闭
const notify = ElNotification.info({ title: '提示', duration: 0 })
setTimeout(() => notify.close(), 5000)

// 关闭所有通知
ElNotification.closeAll()
```

---

## ElLoading 加载

全屏或局部区域的加载遮罩。

### 调用方式

`ElLoading(options)` 返回 `LoadingInstance`，通过 `instance.close()` 关闭。

### 配置参数

| 参数          | 说明                               | 类型                   | 默认值                      |
| ------------- | ---------------------------------- | ---------------------- | --------------------------- |
| `target`      | 挂载目标                           | `HTMLElement / string` | `document.body`             |
| `fullscreen`  | 全屏遮罩                           | `boolean`              | `true`（target 为 body 时） |
| `body`        | 追加到 body（即使 target 非 body） | `boolean`              | `false`                     |
| `lock`        | 锁定滚动（fullscreen 时有效）      | `boolean`              | `false`                     |
| `text`        | 加载文字                           | `string`               | `''`                        |
| `spinner`     | 是否显示旋转图标                   | `boolean / string`     | `false`                     |
| `background`  | 遮罩背景色                         | `string`               | `''`                        |
| `svg`         | 自定义 SVG 图标                    | `string`               | `''`                        |
| `svgViewBox`  | SVG viewBox                        | `string`               | `''`                        |
| `customClass` | 自定义类名                         | `string`               | `''`                        |
| `visible`     | 初始可见                           | `boolean`              | `true`                      |
| `beforeClose` | 关闭前拦截                         | `() => boolean`        | —                           |
| `closed`      | 关闭后回调                         | `() => void`           | —                           |

### 返回值

`LoadingInstance` 对象：

| 属性/方法       | 说明             |
| --------------- | ---------------- |
| `close()`       | 关闭 loading     |
| `setText(text)` | 动态更新加载文字 |
| `visible`       | 可见状态（ref）  |
| `$el`           | 加载 DOM 元素    |

### 示例

```ts
// 全屏 loading
const loading = ElLoading.service({ text: '加载中...' })
api.fetchData().then(() => loading.close())

// 局部 loading
const loading = ElLoading.service({
  target: document.querySelector('.table-wrapper'),
  fullscreen: false,
  text: '数据加载中',
})

// 动态更新文字
const loading = ElLoading.service({ text: '上传中 0%' })
// ... 上传进度变化时
loading.setText('上传中 50%')

// 指令方式（模板中）
// <div v-loading="loading" element-loading-text="加载中...">
```

---

## 使用场景对比

| 场景                 | 推荐 API               | 说明                 |
| -------------------- | ---------------------- | -------------------- |
| 操作成功/失败轻提示  | `ElMessage`            | 不打断用户，自动消失 |
| 需要用户确认的操作   | `ElMessageBox.confirm` | 阻塞式，必须响应     |
| 需要用户输入内容     | `ElMessageBox.prompt`  | 带输入框的确认弹窗   |
| 纯信息展示需用户知晓 | `ElMessageBox.alert`   | 仅确认按钮，用于警告 |
| 异步操作全局通知     | `ElNotification`       | 角落弹出，可配置按钮 |
| 数据加载等待         | `ElLoading`            | 遮罩阻止操作         |
