# TextEllipsis

**注册名**：`ElTextEllipsis` | **模板标签**：`el-text-ellipsis`

文本省略组件，支持 Tooltip 提示和展开/收起两种溢出处理方式。

---

## 属性

| 名称       | 说明                                                    | 类型               | 默认值  |
| ---------- | ------------------------------------------------------- | ------------------ | ------- |
| `max-rows` | 最大显示行数                                            | `number`           | `1`     |
| `tooltip`  | 溢出时是否 tooltip 显示，也可传对象自定义 tooltip props | `boolean / object` | `true`  |
| `expand`   | 溢出时点击文案展开/收起（优先级大于 tooltip）           | `boolean`          | `false` |

## 插槽

| 名称      | 说明                |
| --------- | ------------------- |
| `default` | 文本内容            |
| `tooltip` | 自定义 tooltip 内容 |

## 两种模式

- **Tooltip 模式**（默认）：溢出时通过 `ElTooltip` 显示完整内容
- **展开/收起模式**：设置 `expand: true` 后点击切换展开状态，最多显示 100 行
