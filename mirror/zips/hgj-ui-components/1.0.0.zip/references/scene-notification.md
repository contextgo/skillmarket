# 通知公告场景

通知公告用于向用户传达系统状态、重要消息和操作反馈。

---

## Notice 通知公告

用于页面顶部展示重要通知信息，支持轮播、折叠和持久化。

### 基础用法

```vue
<template>
  <el-notice
    v-model:expand="isExpand"
    :data="noticeList"
    :interval="5000"
    persistence
  />
</template>

<script setup>
const isExpand = ref(true)
const noticeList = ref([
  { content: '系统将于今晚 12:00 进行维护', type: 'important' },
  { content: '新版本已发布，请查看更新日志', type: 'new' },
  { content: '日常运营通知', type: 'normal' },
])
</script>
```

### 属性

| 名称              | 说明               | 类型           | 默认值                                |
| ----------------- | ------------------ | -------------- | ------------------------------------- |
| `data`            | 公告数据源         | `NoticeData[]` | `[]`                                  |
| `v-model:expand`  | 是否展开           | `boolean`      | `true`                                |
| `collapsedHeight` | 折叠时的高度（px） | `number`       | `20`                                  |
| `interval`        | 轮播滚动间隔（ms） | `number`       | `5000`                                |
| `storageKey`      | 本地存储键名       | `string`       | `'hep-notice-storage-collapsedState'` |
| `persistence`     | 是否启用持久化     | `boolean`      | `true`                                |

### 事件

| 名称          | 说明           | 回调参数        |
| ------------- | -------------- | --------------- |
| `indexChange` | 轮播公告切换时 | `index: number` |

### NoticeData 结构

```ts
type NoticeData = {
  content: string
  type?: 'new' | 'important' | 'normal'
  dangerouslyUseHTMLString?: boolean
}
```

### 行为特性

- **展开状态**：显示所有公告
- **折叠状态**：自动轮播显示单条公告
- **持久化**：默认开启，通过 `localStorage` 记住用户的折叠/展开状态
- **支持 HTML 内容**：通过 `dangerouslyUseHTMLString`

---

## Alert 警告提示

用于页面内的静态警告提示：

```vue
<template>
  <el-alert title="成功提示" type="success" show-icon />
  <el-alert title="消息提示" type="info" show-icon />
  <el-alert title="警告提示" type="warning" show-icon />
  <el-alert title="错误提示" type="error" show-icon />

  <!-- 可关闭 -->
  <el-alert title="可关闭的提示" type="info" closable />

  <!-- 带描述 -->
  <el-alert
    title="带描述的提示"
    type="info"
    description="这是一段详细的描述文字"
  />
</template>
```

### 属性

| 属性          | 说明         | 类型                               | 默认值  |
| ------------- | ------------ | ---------------------------------- | ------- |
| `title`       | 标题         | `string`                           | —       |
| `type`        | 类型         | `success / warning / info / error` | `info`  |
| `description` | 描述文字     | `string`                           | —       |
| `closable`    | 是否可关闭   | `boolean`                          | `true`  |
| `show-icon`   | 是否显示图标 | `boolean`                          | `false` |
| `center`      | 文字居中     | `boolean`                          | `false` |
| `effect`      | 主题样式     | `light / dark`                     | `light` |

---

## Message 消息提示

轻量级的全局消息提示，从顶部弹出：

```ts
ElMessage.success('操作成功')
ElMessage.warning('警告信息')
ElMessage.info('提示信息')
ElMessage.error('错误信息')

// 自定义配置
ElMessage({
  message: '这是一条消息',
  type: 'success',
  duration: 3000,
  showClose: true,
})
```

---

## MessageBox 弹框

用于确认对话框或提示输入：

```ts
// 确认框
await ElMessageBox.confirm('确定删除该数据？', '提示', {
  confirmButtonText: '确定',
  cancelButtonText: '取消',
  type: 'warning',
})

// 提示框
await ElMessageBox.alert('这是一条消息', '标题', {
  confirmButtonText: '确定',
})

// 输入框
const { value } = await ElMessageBox.prompt('请输入备注', '提示', {
  confirmButtonText: '确定',
  cancelButtonText: '取消',
})
```

---

## Notification 通知

从右上角弹出的通知消息：

```ts
ElNotification.success({
  title: '成功',
  message: '这是一条成功的通知',
  duration: 3000,
})

ElNotification.warning({ title: '警告', message: '这是一条警告通知' })
ElNotification.info({ title: '消息', message: '这是一条消息通知' })
ElNotification.error({ title: '错误', message: '这是一条错误通知' })
```

---

## 选择建议

| 场景                    | 推荐组件         |
| ----------------------- | ---------------- |
| 页面顶部长期公告        | **Notice**       |
| 页面内静态警告          | **Alert**        |
| 操作成功/失败反馈       | **Message**      |
| 需要用户确认的删除/提交 | **MessageBox**   |
| 复杂消息通知（带标题）  | **Notification** |
