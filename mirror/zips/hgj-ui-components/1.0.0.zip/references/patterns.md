# 业务页面模式

hgj-ui-components 组件库在业务项目中的典型页面组合方式。各模式的详细实现代码与跨组件组合用法见对应的场景文档。

---

## 列表页（CRUD）

**典型骨架**：

```
el-card-list
  ├─ 筛选表单（el-form + 输入控件）
  ├─ 操作按钮区
  ├─ el-x-table（远程排序/筛选 + 分页）
  └─ el-pagination
```

**要点**：

- 使用 `el-card-list`（16px 间距）作为外层容器
- XTable 使用 `sorter-mode="remote"` + `filter-mode="remote"`，由业务层统一请求
- 排序/筛选变化时重置页码
- 分页状态由外部 `el-pagination` 维护
- 固定列（选择/操作）连续排列在左侧/右侧

**详细实现**：见 `scene-table.md`

---

## 表单页

**典型骨架**：

```
el-card-form
  └─ el-form（含校验规则）
       └─ 表单组件（el-input、el-select、el-date-picker 等）
  └─ 底部操作区（提交/取消/重置）
```

**要点**：

- 使用 `el-card-form`（20px 间距）作为外层容器
- 复杂表单可拆分为多个 `el-card-form` 区块，每个区块一个标题
- 使用 `FormRules` 定义校验规则
- 提交前调用 `formRef.validate()`
- 重置使用 `formRef.resetFields()`

**详细实现**：见 `scene-form.md`

---

## 详情页

**典型骨架**：

```
el-card-form
  ├─ el-descriptions（只读信息展示，:column="2"）
  ├─ el-divider
  └─ 扩展信息区块
```

**要点**：

- 使用 `el-card-form` 保持与表单页一致的视觉节奏
- `el-descriptions` 是展示只读信息的首选组件
- `:column="2"` 控制每行显示几列
- `border` 属性添加边框样式

---

## 弹窗表单

| 场景                       | 推荐方案                | 说明                        |
| -------------------------- | ----------------------- | --------------------------- |
| 简单确认/提示              | `el-dialog` + `v-model` | 直接控制显隐                |
| 表单提交，需要返回值       | **DialogWrapper**       | `openDialog` 返回 Promise   |
| 异步流程，需要等待用户操作 | **DialogWrapper**       | `await openDialog` 阻塞等待 |
| 多处复用的弹窗组件         | **DialogWrapper**       | 组件化 + Promise 式调用     |

**详细实现**：见 `scene-dialog.md`

---

## 审批/工单中心

**典型组合**：选择 + 展开行 + 批量操作 + 远程模式

**要点**：

- XTable 组合：选择 + 展开行 + 批量操作 + 远程模式
- 展开行内使用 `el-descriptions` 展示详情
- 批量操作按钮放在卡片 header 区域

**详细实现**：见 `scene-table.md`

---

## 看板/仪表盘

**典型骨架**：

```
el-row :gutter="16"
  ├─ el-col :span="6"
  │   └─ el-card
  │        └─ el-number-flow / el-statistic / el-countdown
  └─ ...
```

**要点**：

- 使用 `el-row` + `el-col` 搭建网格布局
- `el-number-flow` 用于带动画的数值展示
- `el-statistic` 用于静态数值展示
- `el-countdown` 用于倒计时场景

**详细实现**：见 `scene-dashboard.md`

---

## 通知公告

**典型用法**：

```
el-notice
  ├─ 展开状态：显示所有公告
  └─ 折叠状态：自动轮播显示单条公告
```

**要点**：

- 默认启用持久化，通过 `localStorage` 记住折叠/展开状态
- 支持 HTML 内容（通过 `dangerouslyUseHTMLString`）

**详细实现**：见 `scene-notification.md`

---

## 页签导航

| 场景                                 | 推荐组件    |
| ------------------------------------ | ----------- |
| 一级菜单下的动态业务页签（可增删）   | **TabsPro** |
| 同一页面内的内容分区切换（固定页签） | Tabs        |

**详细实现**：见 `scene-navigation.md`
