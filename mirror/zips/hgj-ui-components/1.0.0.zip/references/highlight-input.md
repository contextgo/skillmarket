# HighlightInput

**注册名**：`ElHighlightInput` | **模板标签**：`el-highlight-input`

继承 `ElInput` 全部能力，叠加文本高亮显示功能。

---

## 扩展属性

| 名称              | 说明                                                  | 类型              | 默认值                         |
| ----------------- | ----------------------------------------------------- | ----------------- | ------------------------------ |
| `highlight`       | 高亮匹配规则。字符串按正则源码处理，自动补全 `g` 标记 | `RegExp / string` | `[^\u0000-\u007F]`（非 ASCII） |
| `highlight-color` | 高亮背景色                                            | `string`          | 主题 `warning light-1`         |
| `class-name`      | 透传给内部 `ElInput` 根节点的额外 class               | `string`          | —                              |

## 继承能力

- 单行 / `textarea` 模式切换
- `clearable`、`show-word-limit`、`formatter`、`parser`
- `prepend`、`append`、`prefix`、`suffix` 插槽
- `focus`、`blur`、`select`、`clear`、`resizeTextarea` 实例方法
- `input` / `textarea` / `ref` — 原生元素引用
- `textareaStyle` / `autosize` — textarea 样式与自适应配置

## 注意事项

- 高亮层是与真实输入框同步滚动和尺寸的镜像层，不影响原生输入行为
- 高亮内容先做 HTML 转义，再插入高亮标记，不会直接渲染原始输入内容
