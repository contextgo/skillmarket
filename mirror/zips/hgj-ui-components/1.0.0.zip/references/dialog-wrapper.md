# DialogWrapper

**注册名**：`ElDialogWrapper` | **模板标签**：`el-dialog-wrapper`

Promise 式弹窗管理组件，适用于需要返回值或异步确认的弹窗场景。

---

## 核心用法

**步骤 1**：在全局布局中挂载 `ElDialogWrapper`（通常在 App.vue 或 Layout 组件中）：

```vue
<template>
  <div>
    <router-view />
    <el-dialog-wrapper />
  </div>
</template>
```

**步骤 2**：弹窗组件需抛出 `resolve` 和 `reject` 事件：

```vue
<script setup>
const props = defineProps({ msg: { type: String, default: '' } })
const emits = defineEmits(['resolve', 'reject'])

const resolveData = ref({ result: 'confirmed' })
const rejectData = ref({ reason: 'cancelled' })
</script>

<template>
  <el-dialog
    :model-value="true"
    title="标题"
    @close="emits('reject', rejectData.value)"
  >
    <p>{{ msg }}</p>
    <template #footer>
      <el-button @click="emits('reject', rejectData.value)">取消</el-button>
      <el-button type="primary" @click="emits('resolve', resolveData.value)"
        >确认</el-button
      >
    </template>
  </el-dialog>
</template>
```

**步骤 3**：使用 `openDialog` 打开弹窗：

```ts
import { openDialog } from '@hgj/element-plus'

// 打开弹窗并等待结果
async function handleOpen() {
  try {
    const result = await openDialog(MyDialogComponent, { msg: 'Hello' })
    console.log('确认结果:', result)
  } catch (error) {
    console.log('取消或关闭:', error)
  }
}
```

---

## API

| 函数            | 说明                   | 签名                                                          |
| --------------- | ---------------------- | ------------------------------------------------------------- |
| `openDialog`    | 打开弹窗，返回 Promise | `<C>(component: C, props?: PropsType<C>) => Promise<unknown>` |
| `resolveDialog` | 确认关闭弹窗           | `(id: symbol, result: unknown) => void`                       |
| `rejectDialog`  | 取消关闭弹窗           | `(id: symbol, error: unknown) => void`                        |
| `unmountDialog` | 卸载弹窗 DOM           | `(id: symbol) => void`                                        |

---

## 与 ElDialog 的选择建议

| 场景                       | 推荐方案                               |
| -------------------------- | -------------------------------------- |
| 简单确认/提示，无需返回值  | `el-dialog` + `v-model`                |
| 表单提交，需要返回值和校验 | **DialogWrapper** + `openDialog`       |
| 异步流程，需要等待用户操作 | **DialogWrapper** + `await openDialog` |
