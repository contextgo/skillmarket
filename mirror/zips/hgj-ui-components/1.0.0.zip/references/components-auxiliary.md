# Auxiliary 辅助组件

## ConfigProvider

全局配置组件，用于统一配置国际化、尺寸、zIndex 等。

| 属性                         | 说明         | 类型                      | 默认值 |
| ---------------------------- | ------------ | ------------------------- | ------ |
| `locale`                     | 语言包       | `object`                  | —      |
| `size`                       | 全局尺寸     | `large / default / small` | —      |
| `zIndex`                     | 全局 zIndex  | `number`                  | —      |
| `namespace`                  | 命名空间     | `string`                  | `hep`  |
| `a11y`                       | 无障碍支持   | `boolean`                 | `true` |
| `keyboardNavigation`         | 键盘导航     | `boolean`                 | `true` |
| `experimentalFeatures`       | 实验性功能   | `object`                  | —      |
| `button`                     | 按钮配置     | `object`                  | —      |
| `message`                    | 消息配置     | `object`                  | —      |
| `message-box` / `messageBox` | 消息框配置   | `object`                  | —      |
| `nas`                        | NasFile 配置 | `object`                  | —      |

> 注：本库额外支持 `nas` 配置，用于 NasFile 组件。`nas.env` 可选值：`dev` / `beta` / `prod`。

```vue
<template>
  <el-config-provider :size="size" :z-index="3000" :nas="{ env: 'dev' }">
    <app />
  </el-config-provider>
</template>
```

---

## Scrollbar

| 属性         | 说明           | 类型              | 默认值  |
| ------------ | -------------- | ----------------- | ------- |
| `height`     | 高度           | `string / number` | —       |
| `max-height` | 最大高度       | `string / number` | —       |
| `native`     | 原生滚动       | `boolean`         | `false` |
| `wrap-style` | 容器样式       | `string / object` | —       |
| `wrap-class` | 容器类名       | `string`          | —       |
| `view-style` | 视图样式       | `string / object` | —       |
| `view-class` | 视图类名       | `string`          | —       |
| `noresize`   | 不响应容器变化 | `boolean`         | `false` |
| `tag`        | 视图标签       | `string`          | `div`   |
| `always`     | 滚动条常显     | `boolean`         | `false` |
| `min-size`   | 最小尺寸       | `number`          | `20`    |

| 事件     | 说明   |
| -------- | ------ |
| `scroll` | 滚动时 |

| 插槽      | 说明 |
| --------- | ---- |
| `default` | 内容 |

| 方法            | 说明         |
| --------------- | ------------ |
| `handleScroll`  | 滚动         |
| `scrollTo`      | 滚动到       |
| `setScrollTop`  | 设置纵向滚动 |
| `setScrollLeft` | 设置横向滚动 |
| `update`        | 更新         |
| `wrap$`         | 容器引用     |

```vue
<template>
  <el-scrollbar height="400px">
    <div v-for="item in 20" :key="item">{{ item }}</div>
  </el-scrollbar>
</template>
```

---

## Divider

| 属性               | 说明     | 类型                    | 默认值       |
| ------------------ | -------- | ----------------------- | ------------ |
| `direction`        | 方向     | `horizontal / vertical` | `horizontal` |
| `content-position` | 内容位置 | `left / center / right` | `center`     |
| `border-style`     | 边框样式 | `string`                | `solid`      |

| 插槽      | 说明 |
| --------- | ---- |
| `default` | 内容 |

```vue
<template>
  <el-divider />
  <el-divider content-position="left">左侧文字</el-divider>
  <el-divider direction="vertical" />
</template>
```

---

## Space

| 属性         | 说明     | 类型                                          | 默认值       |
| ------------ | -------- | --------------------------------------------- | ------------ |
| `alignment`  | 对齐     | `string`                                      | `center`     |
| `class`      | 类名     | `string / array / object`                     | —            |
| `direction`  | 方向     | `vertical / horizontal`                       | `horizontal` |
| `prefix-cls` | 前缀类名 | `string`                                      | —            |
| `style`      | 样式     | `string / array / object`                     | —            |
| `spacer`     | 分隔符   | `string / number / VNode`                     | —            |
| `size`       | 间距     | `large / default / small / number / number[]` | —            |
| `wrap`       | 换行     | `boolean`                                     | `false`      |
| `fill`       | 填充     | `boolean`                                     | `false`      |
| `fill-ratio` | 填充比例 | `number`                                      | `100`        |

| 插槽      | 说明 |
| --------- | ---- |
| `default` | 内容 |

```vue
<template>
  <el-space>
    <el-button>按钮1</el-button>
    <el-button>按钮2</el-button>
  </el-space>
</template>
```

---

## Affix

| 属性       | 说明     | 类型           | 默认值 |
| ---------- | -------- | -------------- | ------ |
| `offset`   | 偏移     | `number`       | `0`    |
| `position` | 位置     | `top / bottom` | `top`  |
| `target`   | 目标容器 | `string`       | —      |
| `z-index`  | 层级     | `number`       | `100`  |

| 事件     | 说明         |
| -------- | ------------ |
| `change` | 固定状态变化 |
| `scroll` | 滚动时       |

| 方法     | 说明         |
| -------- | ------------ |
| `update` | 更新固定状态 |

| 插槽      | 说明 |
| --------- | ---- |
| `default` | 内容 |

```vue
<template>
  <el-affix :offset="80">
    <el-button type="primary">吸顶按钮</el-button>
  </el-affix>
</template>
```

---

## Anchor / AnchorLink

### Anchor 属性

| 属性        | 说明         | 类型                    | 默认值     |
| ----------- | ------------ | ----------------------- | ---------- |
| `container` | 容器         | `string / HTMLElement`  | —          |
| `offset`    | 偏移         | `number`                | `0`        |
| `bound`     | 边界         | `number`                | `15`       |
| `duration`  | 动画时长     | `number`                | `300`      |
| `marker`    | 是否显示标记 | `boolean`               | `true`     |
| `type`      | 类型         | `default / underline`   | `default`  |
| `direction` | 方向         | `vertical / horizontal` | `vertical` |

### Anchor 事件

| 事件     | 说明     |
| -------- | -------- |
| `change` | 激活变化 |
| `click`  | 点击     |

### Anchor 方法

| 方法       | 说明           |
| ---------- | -------------- |
| `scrollTo` | 滚动到指定锚点 |

### AnchorLink 属性

| 属性    | 说明     | 类型     |
| ------- | -------- | -------- |
| `href`  | 锚点链接 | `string` |
| `title` | 标题     | `string` |

| 插槽      | 说明   |
| --------- | ------ |
| `default` | 子链接 |

```vue
<template>
  <el-anchor>
    <el-anchor-link href="#section1" title="章节1" />
    <el-anchor-link href="#section2" title="章节2" />
  </el-anchor>
</template>
```

---

## Backtop

| 属性                | 说明     | 类型                 | 默认值 |
| ------------------- | -------- | -------------------- | ------ |
| `visibility-height` | 可见高度 | `number`             | `200`  |
| `right`             | 右边距   | `number`             | `40`   |
| `bottom`            | 底边距   | `number`             | `40`   |
| `target`            | 目标容器 | `string`             | —      |
| `icon`              | 图标     | `string / Component` | —      |

| 事件    | 说明 |
| ------- | ---- |
| `click` | 点击 |

| 插槽      | 说明       |
| --------- | ---------- |
| `default` | 自定义内容 |

```vue
<template>
  <el-backtop :visibility-height="100" />
</template>
```

---

## ImageViewer

图片预览组件，通常由 `el-image` 的 `preview-src-list` 属性触发。

| 属性                    | 说明          | 类型       | 默认值  |
| ----------------------- | ------------- | ---------- | ------- |
| `url-list`              | 图片列表      | `string[]` | `[]`    |
| `z-index`               | 层级          | `number`   | —       |
| `initial-index`         | 初始索引      | `number`   | `0`     |
| `infinite`              | 无限循环      | `boolean`  | `true`  |
| `hide-on-click-modal`   | 点击遮罩关闭  | `boolean`  | `false` |
| `teleported`            | 是否 teleport | `boolean`  | `false` |
| `close-on-press-escape` | ESC 关闭      | `boolean`  | `true`  |

| 事件     | 说明 |
| -------- | ---- |
| `close`  | 关闭 |
| `switch` | 切换 |

---

## CollapseTransition

内置折叠过渡组件。

```vue
<template>
  <el-collapse-transition>
    <div v-show="visible">内容</div>
  </el-collapse-transition>
</template>
```
