# 布局场景

布局是页面搭建的基础。本文档覆盖页面级布局、卡片容器、栅格系统的组合使用。

---

## 页面级布局（Container）

典型的后台管理页面骨架：

```vue
<template>
  <el-container>
    <el-aside width="200px">
      <!-- 侧边菜单 -->
      <el-menu>
        <el-menu-item index="1">首页</el-menu-item>
        <el-sub-menu index="2">
          <template #title>系统管理</template>
          <el-menu-item index="2-1">用户管理</el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header>
        <!-- 顶部导航 -->
      </el-header>

      <el-main>
        <!-- 页面内容 -->
        <router-view />
      </el-main>

      <el-footer>
        <!-- 页脚 -->
      </el-footer>
    </el-container>
  </el-container>
</template>
```

### Container 系列组件

| 组件           | 说明                     |
| -------------- | ------------------------ |
| `el-container` | 外层容器，可嵌套         |
| `el-header`    | 顶部区域，默认高度 60px  |
| `el-aside`     | 侧边区域，默认宽度 300px |
| `el-main`      | 主体区域                 |
| `el-footer`    | 底部区域，默认高度 60px  |

---

## 卡片容器（CardContainer）

用于在内容区纵向编排多个卡片区域，有三种预设快捷组件：

| 组件                | 说明           | 默认间距         | 适用场景                 |
| ------------------- | -------------- | ---------------- | ------------------------ |
| `el-card-list`      | 列表页卡片容器 | `16px`           | 一级页面、筛选页、列表页 |
| `el-card-form`      | 表单页卡片容器 | `20px`           | 详情页、编辑页、配置页   |
| `el-card-custom`    | 自定义卡片容器 | `32px`           | 特殊间距需求             |
| `el-card-container` | 基础容器       | 通过 `type` 控制 | 动态切换场景             |

### 使用建议

1. 页面骨架先用 `el-container` 系列搭建，内容区再用 `el-card-list` 或 `el-card-form` 组织
2. `el-card-list` 适合一级页面、筛选页、列表页等高频页面
3. `el-card-form` 适合详情页、编辑页、配置页等内容更聚合的场景
4. `el-card-custom` 仅在设计稿明确要求特殊节奏时使用，可通过 `gap` 调整
5. 直接子元素不强制必须是 `el-card`，但推荐保持同类内容块

### 属性

| 属性   | 说明                       | 类型              | 可选值                 | 默认值   |
| ------ | -------------------------- | ----------------- | ---------------------- | -------- |
| `type` | 容器类型                   | `string`          | `list / form / custom` | `custom` |
| `gap`  | 容器间距，仅 `custom` 生效 | `string / number` | —                      | `32px`   |

### 完整列表示例

```vue
<template>
  <el-card-list>
    <el-card>
      <!-- 筛选表单 -->
    </el-card>

    <el-card>
      <template #header>
        <span>数据列表</span>
      </template>
      <!-- 表格 -->
    </el-card>
  </el-card-list>
</template>
```

### 表单页示例

```vue
<template>
  <el-card-form>
    <h3>基本信息</h3>
    <el-form :model="form">
      <!-- 基础字段 -->
    </el-form>
  </el-card-form>

  <el-card-form>
    <h3>扩展配置</h3>
    <el-form :model="form">
      <!-- 扩展字段 -->
    </el-form>
  </el-card-form>
</template>
```

---

## 栅格系统（Row / Col）

基于 24 分栏的响应式栅格系统：

```vue
<template>
  <el-row :gutter="16">
    <el-col :span="6">
      <el-card>
        <div class="stat-title">总订单数</div>
        <div class="stat-value">1,234</div>
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">今日收入</div>
        <div class="stat-value">¥ 56,789</div>
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">用户数</div>
        <div class="stat-value">8,901</div>
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <div class="stat-title">待处理</div>
        <div class="stat-value">23</div>
      </el-card>
    </el-col>
  </el-row>
</template>
```

### Row 常用属性

| 属性      | 说明         | 类型                                                                 | 默认值  |
| --------- | ------------ | -------------------------------------------------------------------- | ------- |
| `gutter`  | 栅格间隔     | `number`                                                             | `0`     |
| `justify` | 水平排列方式 | `start / center / end / space-between / space-around / space-evenly` | `start` |
| `align`   | 垂直排列方式 | `top / middle / bottom`                                              | `top`   |

### Col 常用属性

| 属性                     | 说明         | 类型                        |
| ------------------------ | ------------ | --------------------------- |
| `span`                   | 占据栏数     | `number`（1-24）            |
| `offset`                 | 左侧偏移栏数 | `number`                    |
| `push`                   | 向右移动栏数 | `number`                    |
| `pull`                   | 向左移动栏数 | `number`                    |
| `xs / sm / md / lg / xl` | 响应式断点   | `number / { span, offset }` |

### 响应式示例

```vue
<template>
  <el-row :gutter="16">
    <el-col :xs="24" :sm="12" :md="8" :lg="6">
      <el-card>内容1</el-card>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="6">
      <el-card>内容2</el-card>
    </el-col>
  </el-row>
</template>
```

---

## Space 间距

用于设置子元素之间的水平/垂直间距：

```vue
<template>
  <el-space>
    <el-button>按钮1</el-button>
    <el-button>按钮2</el-button>
    <el-button>按钮3</el-button>
  </el-space>

  <el-space direction="vertical" :size="20">
    <el-card>卡片1</el-card>
    <el-card>卡片2</el-card>
  </el-space>
</template>
```

| 属性        | 说明             | 类型                                     | 默认值       |
| ----------- | ---------------- | ---------------------------------------- | ------------ |
| `direction` | 排列方向         | `vertical / horizontal`                  | `horizontal` |
| `size`      | 间隔大小         | `number / 'large' / 'default' / 'small'` | `8`          |
| `alignment` | 对齐方式         | `align-items` 值                         | `center`     |
| `fill`      | 子元素填充父容器 | `boolean`                                | `false`      |

---

## 吸顶（Affix）

将元素固定在页面可视区域：

```vue
<template>
  <el-affix :offset="80">
    <el-button type="primary">吸顶按钮</el-button>
  </el-affix>
</template>
```

| 属性       | 说明               | 类型                   | 默认值 |
| ---------- | ------------------ | ---------------------- | ------ |
| `offset`   | 偏移距离           | `number`               | `0`    |
| `position` | 吸顶位置           | `top / bottom`         | `top`  |
| `target`   | 指定监听滚动的容器 | `string / HTMLElement` | —      |
| `z-index`  | 层级               | `number`               | `100`  |

---

## 常见页面骨架汇总

### 列表页

```
el-container
  ├─ el-aside
  │   └─ el-menu
  └─ el-container
      ├─ el-header
      └─ el-main
           └─ el-card-list
                ├─ el-card（筛选表单）
                └─ el-card（表格 + 分页）
```

### 表单页

```
el-container
  └─ el-main
       └─ el-card-form
            └─ el-form
                 ├─ 输入控件
                 └─ 提交/重置按钮
```

### 详情页

```
el-container
  └─ el-main
       └─ el-card-form
            ├─ el-descriptions
            ├─ el-divider
            └─ 扩展信息
```
