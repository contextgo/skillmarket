# NumberFlow

**注册名**：`ElNumberFlow` / `ElNumberFlowGroup` | **模板标签**：`el-number-flow` / `el-number-flow-group`

数字流动画组件，用于以平滑动画展示数字变化，常用于看板、统计数据等场景。

---

## NumberFlow 属性

| 名称                        | 说明                                           | 类型                                   | 默认值                                  |
| --------------------------- | ---------------------------------------------- | -------------------------------------- | --------------------------------------- |
| `value`                     | 当前显示的数值                                 | `number / string`                      | `0`                                     |
| `format`                    | 数字格式化配置，透传给 `Intl.NumberFormat`     | `Intl.NumberFormatOptions`             | `{}`                                    |
| `prefix` / `suffix`         | 数字内容前缀/后缀                              | `string`                               | —                                       |
| `trend`                     | 数值增减趋势                                   | `number / (oldValue, value) => number` | 随差值计算                              |
| `animated`                  | 是否启用动画                                   | `boolean`                              | `true`                                  |
| `color`                     | 自定义数字颜色                                 | `string`                               | —                                       |
| `font-size`                 | 自定义字体大小                                 | `number / string`                      | —                                       |
| `locales`                   | 数字格式化语言环境，透传给 `Intl.NumberFormat` | `Intl.LocalesArgument`                 | `undefined`                             |
| `transformTiming`           | 数字位变换动画的时序配置                       | `EffectTiming`                         | 见源码                                  |
| `spinTiming`                | 数字滚动动画的时序配置                         | `EffectTiming`                         | `undefined`                             |
| `opacityTiming`             | 数字透明度动画的时序配置                       | `EffectTiming`                         | `{ duration: 450, easing: 'ease-out' }` |
| `digits`                    | 自定义数字位映射                               | `Digits`                               | `undefined`                             |
| `willChange`                | 是否启用 `will-change` 优化                    | `boolean`                              | `false`                                 |
| `respect-motion-preference` | 是否尊重用户「减少动效」偏好                   | `boolean`                              | `true`                                  |

## NumberFlowGroup

用于让多个 `ElNumberFlow` 在同一次更新中同步开始与结束动画：

```vue
<template>
  <el-number-flow-group>
    <el-number-flow :value="value1" />
    <el-number-flow :value="value2" />
  </el-number-flow-group>
</template>
```

## 事件

| 名称               | 说明               |
| ------------------ | ------------------ |
| `animationsstart`  | 数字动画开始时     |
| `animationsfinish` | 数字动画全部结束时 |
