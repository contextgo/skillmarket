# Navigation 导航组件

## Menu / MenuItem / MenuItemGroup / SubMenu

### Menu 属性

| 属性                   | 说明         | 类型                    | 默认值     |
| ---------------------- | ------------ | ----------------------- | ---------- | --- |
| `default-active`       | 当前激活     | `string`                | —          |
| `default-openeds`      | 默认展开     | `string[]`              | `[]`       |
| `default-openeds-all`  | 全部展开     | `boolean`               | `false`    |
| `unique-opened`        | 唯一展开     | `boolean`               | `false`    |
| `router`               | 启用路由     | `boolean`               | `false`    |
| `collapse`             | 折叠         | `boolean`               | `false`    |
| `collapse-transition`  | 折叠动画     | `boolean`               | `false`    | ⚠️  |
| `show-collapse-toggle` | 显示折叠切换 | `boolean`               | `false`    | 🔧  |
| `dark-icon`            | 深色图标     | `boolean`               | `false`    | 🔧  |
| `mode`                 | 模式         | `vertical / horizontal` | `vertical` |
| `menu-trigger`         | 触发方式     | `hover / click`         | `hover`    |

### Menu 事件

| 事件     | 说明 |
| -------- | ---- |
| `select` | 选中 |
| `open`   | 展开 |
| `close`  | 收起 |

### MenuItem 属性

| 属性    | 说明     | 类型                 |
| ------- | -------- | -------------------- |
| `index` | 唯一标识 | `string`             |
| `route` | 路由     | `string / object`    |
| `icon`  | 图标     | `string / Component` |

### SubMenu 属性

| 属性            | 说明     | 类型                 | 默认值  |
| --------------- | -------- | -------------------- | ------- |
| `index`         | 唯一标识 | `string`             | —       |
| `title`         | 标题     | `string`             | —       |
| `icon`          | 图标     | `string / Component` | —       |
| `show-timeout`  | 展开延迟 | `number`             | `300`   |
| `hide-timeout`  | 收起延迟 | `number`             | `300`   |
| `show-arrow`    | 显示箭头 | `boolean`            | `false` |
| `popper-class`  | 弹出类名 | `string`             | —       |
| `popper-offset` | 弹出偏移 | `number`             | `12`    |

```vue
<template>
  <el-menu default-active="1">
    <el-menu-item index="1">首页</el-menu-item>
    <el-sub-menu index="2">
      <template #title>系统管理</template>
      <el-menu-item index="2-1">用户管理</el-menu-item>
    </el-sub-menu>
  </el-menu>
</template>
```

### MenuItemGroup 属性

| 属性    | 说明     | 类型                 |
| ------- | -------- | -------------------- |
| `title` | 分组标题 | `string`             |
| `icon`  | 图标     | `string / Component` |

```vue
<template>
  <el-menu>
    <el-menu-item-group title="分组1">
      <el-menu-item index="1-1">选项1</el-menu-item>
      <el-menu-item index="1-2">选项2</el-menu-item>
    </el-menu-item-group>
  </el-menu>
</template>
```

---

## Tabs / TabPane

### Tabs 属性

| 属性           | 说明       | 类型                          | 默认值             |
| -------------- | ---------- | ----------------------------- | ------------------ |
| `v-model`      | 绑定值     | `string / number`             | 第一个 tab 的 name |
| `type`         | 类型       | `'' / 'card' / 'border-card'` | `''`               |
| `tab-position` | 位置       | `top / right / bottom / left` | `top`              |
| `stretch`      | 拉伸       | `boolean`                     | `false`            |
| `closable`     | 可关闭     | `boolean`                     | `false`            |
| `addable`      | 可增加     | `boolean`                     | `false`            |
| `editable`     | 可编辑     | `boolean`                     | `false`            |
| `before-leave` | 离开前钩子 | `function`                    | —                  |

### Tabs 事件

| 事件         | 说明     |
| ------------ | -------- |
| `tab-click`  | 点击 tab |
| `tab-change` | tab 变化 |
| `tab-remove` | 移除 tab |
| `tab-add`    | 添加 tab |
| `edit`       | 编辑 tab |

### TabPane 属性

| 属性       | 说明     | 类型              |
| ---------- | -------- | ----------------- |
| `label`    | 标签     | `string`          |
| `name`     | 名称     | `string / number` |
| `disabled` | 禁用     | `boolean`         |
| `closable` | 可关闭   | `boolean`         |
| `lazy`     | 延迟渲染 | `boolean`         |

```vue
<template>
  <el-tabs v-model="activeTab">
    <el-tab-pane label="基本信息" name="basic">...</el-tab-pane>
    <el-tab-pane label="操作日志" name="log">...</el-tab-pane>
  </el-tabs>
</template>
```

---

## TabsPro

🔧 自定义组件，详细文档见 `tabs-pro.md`。

```vue
<template>
  <el-tabs-pro v-model="activeTab" v-model:tabs="tabs" />
</template>
```

---

## Breadcrumb / BreadcrumbItem

### Breadcrumb 属性

| 属性             | 说明       | 类型                 | 默认值 |
| ---------------- | ---------- | -------------------- | ------ |
| `separator`      | 分隔符     | `string`             | `''`   |
| `separator-icon` | 分隔符图标 | `string / Component` | —      |

### BreadcrumbItem 属性

| 属性      | 说明 | 类型              |
| --------- | ---- | ----------------- |
| `to`      | 路由 | `string / object` |
| `replace` | 替换 | `boolean`         |

| 插槽      | 说明 |
| --------- | ---- |
| `default` | 内容 |

```vue
<template>
  <el-breadcrumb separator="/">
    <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>当前页</el-breadcrumb-item>
  </el-breadcrumb>
</template>
```

---

## Steps / Step

### Steps 属性

| 属性                 | 说明                          | 类型                               | 默认值       |
| -------------------- | ----------------------------- | ---------------------------------- | ------------ |
| `active` / `v-model` | 当前步骤                      | `number`                           | `0`          |
| `space`              | 间距                          | `number / string`                  | `''`         |
| `direction`          | 方向                          | `vertical / horizontal`            | `horizontal` |
| `finish-type`        | 完成状态类型（🔧 内部扩展）   | `info / success / warning / error` | `success`    |
| `process-type`       | 进行中状态类型（🔧 内部扩展） | `info / success / warning / error` | `info`       |

### Steps 事件

| 事件            | 说明                   |
| --------------- | ---------------------- | --- |
| `change`        | 步骤变化（新值, 旧值） | 🔄  |
| `update:active` | 更新当前步骤           |     |

### Steps 方法

| 方法   | 说明                     |
| ------ | ------------------------ |
| `prev` | 上一步（支持 loop 循环） |
| `next` | 下一步（支持 loop 循环） |

### Step 属性

| 属性          | 说明     | 类型                               |
| ------------- | -------- | ---------------------------------- |
| `title`       | 标题     | `string`                           |
| `description` | 描述     | `string`                           |
| `icon`        | 图标     | `string / Component`               |
| `type`        | 状态类型 | `info / success / warning / error` |

### Step 插槽

| 插槽          | 说明 |
| ------------- | ---- |
| `icon`        | 图标 |
| `title`       | 标题 |
| `description` | 描述 |

```vue
<template>
  <el-steps :active="1" finish-type="success">
    <el-step title="步骤1" description="描述1" />
    <el-step title="步骤2" description="描述2" />
    <el-step title="步骤3" description="描述3" />
  </el-steps>
</template>
```

---

## Dropdown / DropdownItem / DropdownMenu

### Dropdown 属性

| 属性             | 说明         | 类型                          | 默认值   |
| ---------------- | ------------ | ----------------------------- | -------- | --- |
| `type`           | 菜单按钮类型 | `string`                      | —        |
| `size`           | 尺寸         | `string`                      | —        |
| `split-button`   | 分裂按钮     | `boolean`                     | `false`  |
| `disabled`       | 禁用         | `boolean`                     | `false`  |
| `placement`      | 菜单位置     | `string`                      | `bottom` |
| `trigger`        | 触发方式     | `hover / click / contextmenu` | `hover`  |
| `hide-on-click`  | 点击隐藏     | `boolean`                     | `true`   |
| `show-timeout`   | 展开延迟     | `number`                      | `150`    |
| `hide-timeout`   | 收起延迟     | `number`                      | `150`    |
| `tabindex`       | tabindex     | `number / string`             | `0`      |
| `popper-class`   | 弹出类名     | `string`                      | —        |
| `popper-options` | popper 配置  | `object`                      | —        |
| `max-height`     | 最大高度     | `string / number`             | —        | 🔧  |
| `effect`         | 主题         | `string`                      | `light`  |
| `loop`           | 键盘循环     | `boolean`                     | `true`   |
| `role`           | 角色         | `string`                      | `menu`   | 🔧  |
| `button-props`   | 按钮属性     | `object`                      | —        | 🔧  |

### Dropdown 事件

| 事件             | 说明         |
| ---------------- | ------------ |
| `visible-change` | 显隐变化     |
| `command`        | 点击菜单项   |
| `click`          | 分裂按钮点击 |

### DropdownItem 属性

| 属性         | 说明     | 类型                       |
| ------------ | -------- | -------------------------- | --- | --- |
| `command`    | 指令     | `string / number / object` |
| `disabled`   | 禁用     | `boolean`                  |     |
| `divided`    | 分隔线   | `boolean`                  |     |
| `icon`       | 图标     | `string / Component`       |     |
| `text-value` | 文本值   | `string`                   |     | 🔧  |
| `checked`    | 选中     | `boolean`                  |     | 🔧  |
| `danger`     | 危险样式 | `boolean`                  |     | 🔧  |

```vue
<template>
  <el-dropdown @command="handleCommand">
    <el-button type="primary">
      下拉菜单<el-icon><arrow-down /></el-icon>
    </el-button>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item command="a">选项A</el-dropdown-item>
        <el-dropdown-item command="b">选项B</el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>
```

---

## PageHeader

| 属性      | 说明 | 类型                 |
| --------- | ---- | -------------------- |
| `icon`    | 图标 | `string / Component` |
| `title`   | 标题 | `string`             |
| `content` | 内容 | `string`             |

| 事件   | 说明     |
| ------ | -------- |
| `back` | 点击返回 |

| 插槽      | 说明 |
| --------- | ---- |
| `icon`    | 图标 |
| `title`   | 标题 |
| `content` | 内容 |

```vue
<template>
  <el-page-header title="标题" content="详情页" @back="goBack" />
</template>
```
