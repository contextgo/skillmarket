# Basic 基础组件

## Button / ButtonGroup

### Button 属性

| 属性              | 说明               | 类型                                                  | 默认值      |
| ----------------- | ------------------ | ----------------------------------------------------- | ----------- | --- |
| `size`            | 尺寸               | `large / default / small`                             | —           |
| `type`            | 类型               | `default / primary / success / warning / danger / ''` | —           |
| `plain`           | 朴素按钮           | `boolean`                                             | `undefined` | ⚠️  |
| `text`            | 文字按钮           | `boolean`                                             | `false`     |     |
| `round`           | 圆角               | `boolean`                                             | `false`     |     |
| `circle`          | 圆形               | `boolean`                                             | `false`     |     |
| `loading`         | 加载中             | `boolean`                                             | `false`     |     |
| `disabled`        | 禁用               | `boolean`                                             | `false`     |     |
| `autofocus`       | 自动聚焦           | `boolean`                                             | `false`     |     |
| `native-type`     | 原生 type          | `button / submit / reset`                             | `button`    |     |
| `icon`            | 图标               | `string / Component`                                  | —           |     |
| `suffixIcon`      | 尾部图标           | `string / Component`                                  | —           |     |
| `blank`           | 链接在新标签页打开 | `boolean`                                             | `undefined` | 🔧  |
| `block`           | 块级按钮           | `boolean`                                             | `false`     | 🔧  |
| `color`           | 自定义颜色         | `string`                                              | —           |
| `dark`            | 暗色模式           | `boolean`                                             | `false`     |
| `throttle`        | 节流               | `boolean / number`                                    | —           | 🔧  |
| `autoInsertSpace` | 自动插入空格       | `boolean`                                             | —           |

### Button 插槽

| 插槽      | 说明           |
| --------- | -------------- |
| `default` | 按钮内容       |
| `loading` | 自定义加载图标 |
| `icon`    | 图标           |

### ButtonGroup 属性

| 属性    | 说明               | 类型                                                  | 默认值  |
| ------- | ------------------ | ----------------------------------------------------- | ------- |
| `size`  | 尺寸               | `large / default / small`                             | —       |
| `type`  | 类型               | `default / primary / success / warning / danger / ''` | —       |
| `blank` | 链接在新标签页打开 | `boolean`                                             | `false` |

```vue
<template>
  <el-button type="primary">主要按钮</el-button>
  <el-button type="primary" loading>加载中</el-button>
  <el-button type="danger" text>删除</el-button>
  <el-button type="primary" circle>
    <el-icon><Plus /></el-icon>
  </el-button>

  <el-button-group>
    <el-button type="primary">上一页</el-button>
    <el-button type="primary">下一页</el-button>
  </el-button-group>
</template>
```

---

## Icon

图标组件，直接使用 SVG 图标。

```vue
<template>
  <el-icon :size="20" color="var(--hep-color-primary)">
    <Search />
  </el-icon>
  <el-icon><Plus /></el-icon>
  <el-icon><Delete /></el-icon>
</template>
```

| 属性    | 说明     | 类型              | 默认值 |
| ------- | -------- | ----------------- | ------ |
| `size`  | 图标大小 | `number / string` | —      |
| `color` | 图标颜色 | `string`          | —      |
| `name`  | 图标名称 | `string`          | —      |

---

## Tag

| 属性       | 说明       | 类型                                                               | 默认值    |
| ---------- | ---------- | ------------------------------------------------------------------ | --------- | --- |
| `type`     | 类型       | `primary / success / info / warning / danger / progress / invalid` | `primary` | 🔧  |
| `closable` | 是否可关闭 | `boolean`                                                          | `false`   |     |
| `hit`      | 边框描边   | `boolean`                                                          | `false`   |     |
| `size`     | 尺寸       | `large / default / small`                                          | —         |     |
| `effect`   | 主题       | `plain / dark / light / state`                                     | `plain`   | 🔧  |
| `round`    | 圆角       | `boolean`                                                          | `false`   |     |
| `larger`   | 大号标签   | `boolean`                                                          | `false`   | 🔧  |

| 事件    | 说明       |
| ------- | ---------- |
| `close` | 关闭时触发 |
| `click` | 点击时触发 |

```vue
<template>
  <el-tag type="success">成功</el-tag>
  <el-tag type="danger" closable @close="handleClose">可关闭</el-tag>
  <el-tag type="primary" effect="dark">深色</el-tag>
</template>
```

---

## Link

| 属性         | 说明      | 类型                                               | 默认值    |
| ------------ | --------- | -------------------------------------------------- | --------- |
| `type`       | 类型      | `primary / success / warning / danger / info / ''` | `primary` |
| `size`       | 尺寸      | `large / default / small`                          | —         |
| `underline`  | 下划线    | `boolean`                                          | `true`    |
| `disabled`   | 禁用      | `boolean`                                          | `false`   |
| `href`       | 原生 href | `string`                                           | —         |
| `icon`       | 图标      | `string / Component / boolean`                     | —         |
| `suffixIcon` | 尾部图标  | `string / Component / boolean`                     | —         |

```vue
<template>
  <el-link type="primary">主要链接</el-link>
  <el-link type="danger" :underline="false">无下划线</el-link>
  <el-link href="https://example.com" target="_blank">外部链接</el-link>
</template>
```

---

## Image

| 属性                    | 说明              | 类型                                         | 默认值  |
| ----------------------- | ----------------- | -------------------------------------------- | ------- |
| `src`                   | 图片源            | `string`                                     | —       |
| `fit`                   | 适应方式          | `fill / contain / cover / none / scale-down` | —       |
| `lazy`                  | 懒加载            | `boolean`                                    | `false` |
| `scroll-container`      | 滚动容器          | `string / HTMLElement`                       | —       |
| `preview-src-list`      | 预览图片列表      | `string[]`                                   | —       |
| `loading`               | 加载方式          | `eager / lazy`                               | —       |
| `previewTeleported`     | 预览是否插入 body | `boolean`                                    | —       |
| `zIndex`                | 预览层级          | `number`                                     | —       |
| `infinite`              | 无限循环预览      | `boolean`                                    | `true`  |
| `hide-on-click-modal`   | 点击遮罩关闭预览  | `boolean`                                    | `false` |
| `initial-index`         | 初始预览索引      | `number`                                     | `0`     |
| `close-on-press-escape` | ESC 关闭预览      | `boolean`                                    | `true`  |

| 事件     | 说明               |
| -------- | ------------------ |
| `load`   | 加载成功           |
| `error`  | 加载失败           |
| `switch` | 切换图片（预览时） |
| `close`  | 关闭预览           |
| `show`   | 打开预览           |

| 插槽             | 说明         |
| ---------------- | ------------ |
| `placeholder`    | 加载中占位   |
| `error`          | 加载失败占位 |
| `viewer-toolbar` | 预览工具栏   |

```vue
<template>
  <el-image :src="url" :preview-src-list="[url]" fit="cover" />
</template>
```

---

## TextEllipsis

🔧 自定义组件，详细文档见 `text-ellipsis.md`。

简要说明：文本省略组件，支持 Tooltip 提示和展开/收起两种溢出处理方式。

```vue
<template>
  <!-- Tooltip 模式（默认） -->
  <el-text-ellipsis>这是一段很长的文本</el-text-ellipsis>

  <!-- 展开/收起模式 -->
  <el-text-ellipsis :expand="true">这是一段很长的文本</el-text-ellipsis>
</template>
```
