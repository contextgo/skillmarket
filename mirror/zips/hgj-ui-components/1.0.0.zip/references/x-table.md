# XTable

**注册名**：`ElXTable` | **模板标签**：`el-x-table`

- **完全自研**，不是基于 `el-table` 的封装，参照 TDesign Table 接口风格
- **配置驱动**：通过 `columns` 数组配置列，而非 `el-table-column` 子组件
- 内置虚拟滚动、行编辑、树形数据、拖拽排序、列宽调整等高级能力

---

## 最小可用模板

```vue
<script setup lang="ts">
import type { XTableColumn } from '@hgj/element-plus'

interface Row {
  id: string
  name: string
  amount: number
}

const columns: XTableColumn<Row>[] = [
  { colKey: 'id', title: 'ID', width: 80 },
  { colKey: 'name', title: '名称' },
  { colKey: 'amount', title: '金额', align: 'right' },
]

const data: Row[] = [
  { id: '1', name: '订单A', amount: 1000 },
  { id: '2', name: '订单B', amount: 2000 },
]
</script>

<template>
  <el-x-table :columns="columns" :data="data" row-key="id" />
</template>
```

---

## Props 总览

| 属性                           | 说明                       | 类型                                 | 默认值    |
| ------------------------------ | -------------------------- | ------------------------------------ | --------- |
| `data`                         | 表格数据                   | `T[]`                                | `[]`      |
| `columns`                      | 列配置                     | `XTableColumn<T>[]`                  | `[]`      |
| `footData`                     | 表尾数据                   | `T[]`                                | `[]`      |
| `rowKey`                       | 行唯一标识字段名或函数     | `string / function`                  | `'id'`    |
| `attach`                       | 弹出层挂载节点             | `string / function`                  | —         |
| `filterRow`                    | 筛选结果行内容             | `string / function`                  | —         |
| `firstFullRow`                 | tbody 顶部通栏行           | `string / function`                  | —         |
| `virtualScroll`                | 虚拟滚动配置               | `boolean / object`                   | `true`    |
| `dragSort`                     | 拖拽排序模式               | `string`                             | —         |
| `dragSortOptions`              | 拖拽排序选项（SortableJS） | `object`                             | —         |
| `rowSelectionType`             | 行选择类型                 | `string`                             | —         |
| `rowSelectionAllowUncheck`     | 单选允许取消选中           | `boolean`                            | —         |
| `editableCellState`            | 单元格可编辑控制函数       | `function`                           | —         |
| `editableRowKeys`              | 可编辑行标识（受控）       | `array`                              | —         |
| `showSortColumnBgColor`        | 排序列显示背景色           | `boolean`                            | —         |
| `sortIcon`                     | 自定义排序图标             | `function`                           | —         |
| `filterIcon`                   | 自定义筛选图标             | `function`                           | —         |
| `expandIcon`                   | 自定义展开图标             | `boolean / string / function`        | `true`    |
| `selectedRowKeys`              | 选中行标识（受控）         | `array`                              | —         |
| `defaultSelectedRowKeys`       | 默认选中行标识             | `array`                              | `[]`      |
| `activeRowKeys`                | 高亮行标识（受控）         | `array`                              | —         |
| `defaultActiveRowKeys`         | 默认高亮行标识             | `array`                              | `[]`      |
| `activeRowType`                | 高亮行模式                 | `single / multiple`                  | —         |
| `expandedRowKeys`              | 展开行标识（受控）         | `array`                              | —         |
| `defaultExpandedRowKeys`       | 默认展开行标识             | `array`                              | `[]`      |
| `sorter`                       | 排序状态（受控）           | `object`                             | —         |
| `defaultSorter`                | 默认排序状态               | `object`                             | —         |
| `filterValue`                  | 筛选值（受控）             | `object`                             | —         |
| `defaultFilterValue`           | 默认筛选值                 | `object`                             | —         |
| `tree`                         | 树形结构配置               | `object`                             | —         |
| `treeExpandAndFoldIcon`        | 树节点展开/折叠图标        | `string / function`                  | —         |
| `expandedTreeNodes`            | 展开树节点（受控）         | `array`                              | —         |
| `defaultExpandedTreeNodes`     | 默认展开树节点             | `array`                              | `[]`      |
| `indeterminateSelectedRowKeys` | 半选行标识                 | `array`                              | —         |
| `rowspanAndColspan`            | 行列合并函数               | `function`                           | —         |
| `rowspanAndColspanInFooter`    | 表尾行列合并函数           | `function`                           | —         |
| `height`                       | 表格高度                   | `string / number`                    | —         |
| `maxHeight`                    | 最大高度                   | `string / number`                    | —         |
| `headerAffixedTop`             | 表头吸顶                   | `boolean / object`                   | —         |
| `footerAffixedBottom`          | 表尾吸底                   | `boolean / object`                   | —         |
| `footerSummary`                | 表尾汇总内容               | `string / function`                  | —         |
| `border`                       | 显示边框                   | `boolean`                            | `true`    |
| `stripe`                       | 斑马纹                     | `boolean`                            | `false`   |
| `hover`                        | 行悬浮高亮                 | `boolean`                            | `true`    |
| `small`                        | 小型尺寸                   | `boolean`                            | `true`    |
| `showHeader`                   | 显示表头                   | `boolean`                            | `true`    |
| `empty`                        | 空数据内容                 | `string / function`                  | —         |
| `emptyText`                    | 空数据文案                 | `string`                             | —         |
| `locale`                       | 国际化配置                 | `object`                             | —         |
| `cellEmptyContent`             | 空单元格默认内容           | `string / function`                  | —         |
| `resizable`                    | 允许调整列宽               | `boolean`                            | `false`   |
| `scrollbarAlwaysOn`            | 始终显示滚动条             | `boolean`                            | `true`    |
| `verticalAlign`                | 垂直对齐                   | `string`                             | `'top'`   |
| `sorterMode`                   | 排序模式                   | `local / remote`                     | `'local'` |
| `filterMode`                   | 筛选模式                   | `local / remote`                     | `'local'` |
| `rowClassName`                 | 行类名                     | `string / array / object / function` | —         |
| `rowAttributes`                | 行 HTML 属性               | `object / array / function`          | —         |
| `disableSpaceInactiveRow`      | 禁用空格取消高亮           | `boolean`                            | —         |
| `keyboardRowHover`             | 键盘行悬浮                 | `boolean`                            | `true`    |
| `selectOnRowClick`             | 点击行触发选择             | `boolean`                            | —         |
| `expandOnRowClick`             | 点击行展开                 | `boolean`                            | —         |
| `expandedRow`                  | 展开行内容渲染             | `function`                           | —         |
| `beforeDragSort`               | 拖拽前拦截                 | `function`                           | —         |

## Events 总览

| 事件                         | 说明                 | 参数              |
| ---------------------------- | -------------------- | ----------------- |
| `change`                     | 排序/筛选/分页等变化 | `change, context` |
| `drag-sort`                  | 拖拽排序             | `context`         |
| `expand-change`              | 展开行变化           | `keys, context`   |
| `filter-change`              | 筛选变化             | `filter, context` |
| `row-edit`                   | 行编辑               | `context`         |
| `row-validate`               | 行校验               | `context`         |
| `sort-change`                | 排序变化             | `sort, context`   |
| `validate`                   | 整表校验             | `context`         |
| `expanded-tree-nodes-change` | 展开树节点变化       | `nodes, context`  |
| `abnormal-drag-sort`         | 非法树拖拽           | `context`         |
| `tree-expand-change`         | 树展开变化           | `context`         |
| `tree-load`                  | 树加载成功           | `context`         |
| `tree-load-error`            | 树加载失败           | `context`         |
| `row-click`                  | 行点击               | `context`         |
| `row-dblclick`               | 行双击               | `context`         |
| `row-mousedown`              | 行鼠标按下           | `context`         |
| `row-mouseenter`             | 行鼠标进入           | `context`         |
| `row-mouseleave`             | 行鼠标离开           | `context`         |
| `row-mouseover`              | 行鼠标悬停           | `context`         |
| `row-mouseup`                | 行鼠标释放           | `context`         |
| `cell-click`                 | 单元格点击           | `context`         |
| `scroll`                     | 滚动                 | `{ e }`           |
| `scroll-x`                   | 横向滚动             | `{ e }`           |
| `scroll-y`                   | 纵向滚动             | `{ e }`           |
| `select-change`              | 选择变化             | `keys, context`   |
| `active-change`              | 高亮行变化           | `keys, context`   |
| `active-row-action`          | 高亮行操作           | `context`         |
| `data-change`                | 数据变化             | `data, context`   |
| `column-resize-change`       | 列宽调整             | `context`         |
| `update:sorter`              | 更新排序             | `sorter`          |
| `update:filterValue`         | 更新筛选             | `filterValue`     |
| `update:expandedRowKeys`     | 更新展开行           | `keys`            |
| `update:selectedRowKeys`     | 更新选中行           | `keys`            |
| `update:activeRowKeys`       | 更新高亮行           | `keys`            |
| `update:expandedTreeNodes`   | 更新展开树节点       | `nodes`           |
| `update:editableRowKeys`     | 更新可编辑行         | `keys`            |

## Slots 总览

| 插槽             | 说明           | 参数                                      |
| ---------------- | -------------- | ----------------------------------------- |
| `cell`           | 全局单元格兜底 | `{ row, col, rowIndex, colIndex, value }` |
| `cell-{colKey}`  | 指定列单元格   | `{ row, col, rowIndex, colIndex, value }` |
| `title`          | 全局表头兜底   | `{ col, colIndex }`                       |
| `title-{colKey}` | 指定列表头     | `{ col, colIndex }`                       |
| `foot`           | 全局表尾兜底   | `{ row, col, rowIndex, colIndex, value }` |
| `foot-{colKey}`  | 指定列表尾     | `{ row, col, rowIndex, colIndex, value }` |
| `expanded-row`   | 展开行内容     | `{ row, index, rowIndex }`                |
| `filter-row`     | 筛选结果行     | —                                         |
| `footer-summary` | 表尾汇总区     | —                                         |
| `empty`          | 空数据内容     | —                                         |
| `header-actions` | 表头操作区     | —                                         |

---

## columns 核心字段

| 字段                        | 说明                       | 常见用法                                              |
| --------------------------- | -------------------------- | ----------------------------------------------------- |
| `colKey`                    | 列唯一标识，默认取值字段名 | 普通列必填                                            |
| `type`                      | 特殊列类型                 | `'selection'` / `'expand'` / `'index'` / `'row-drag'` |
| `title`                     | 表头内容                   | `string` 或渲染函数                                   |
| `field`                     | 自定义取值字段             | `colKey` 与取值字段解耦时使用                         |
| `width`                     | 固定列宽                   | `string / number`                                     |
| `minWidth`                  | 弹性列最小宽度             | 仅对未配置 `width` 的列生效                           |
| `align`                     | 对齐方式                   | `'left' / 'center' / 'right'`                         |
| `fixed`                     | 固定列                     | `'left' / 'right'`                                    |
| `cell`                      | 自定义单元格内容           | 函数或字符串                                          |
| `ellipsis`                  | 超长省略                   | `boolean / tooltip props / 函数`                      |
| `sorter`                    | 排序配置                   | `boolean / (a, b) => number`                          |
| `sortType`                  | 排序方向限制               | `'desc' / 'asc' / 'all'`                              |
| `filter`                    | 筛选配置                   | `{ type: 'single' / 'multiple' / 'input', ... }`      |
| `edit`                      | 编辑配置                   | 见下文「编辑能力详解」                                |
| `resizable`                 | 列宽拖拽                   | `boolean`                                             |
| `children`                  | 多级表头                   | `XTableColumn<T>[]`                                   |
| `foot`                      | 列级表尾内容               | 函数或字符串                                          |
| `className` / `thClassName` | body / header 单元格类名   | —                                                     |
| `attrs`                     | 自定义 DOM 属性            | —                                                     |
| `disabled` / `checkProps`   | 选择列禁用与透传           | 适用于 `type: 'selection'`                            |
| `stopPropagation`           | 阻止单元格内部事件冒泡     | `boolean`                                             |

---

## 特殊列类型

```ts
const columns: XTableColumn<Row>[] = [
  { type: 'selection', width: 50, fixed: 'left' }, // 选择列
  { type: 'expand', width: 50 }, // 展开列
  { type: 'index', width: 60, title: '序号' }, // 序号列
  { type: 'row-drag', width: 40 }, // 行拖拽手柄列
  { colKey: 'name', title: '名称' },
]
```

---

## 状态控制约定

- **`default*` 系列**：只负责初始化非受控状态，后续由组件内部维护
- **`v-model:*` 系列**：受控状态，外部完全掌控

| 状态   | 初始化属性                 | 受控属性            | 事件                                                      |
| ------ | -------------------------- | ------------------- | --------------------------------------------------------- |
| 排序   | `defaultSorter`            | `sorter`            | `sort-change` / `update:sorter`                           |
| 筛选   | `defaultFilterValue`       | `filterValue`       | `filter-change` / `update:filterValue`                    |
| 选择   | `defaultSelectedRowKeys`   | `selectedRowKeys`   | `select-change` / `update:selectedRowKeys`                |
| 展开   | `defaultExpandedRowKeys`   | `expandedRowKeys`   | `expand-change` / `update:expandedRowKeys`                |
| 激活行 | `defaultActiveRowKeys`     | `activeRowKeys`     | `active-change` / `update:activeRowKeys`                  |
| 编辑行 | —                          | `editableRowKeys`   | `update:editableRowKeys`                                  |
| 树展开 | `defaultExpandedTreeNodes` | `expandedTreeNodes` | `expanded-tree-nodes-change` / `update:expandedTreeNodes` |

---

## 内容渲染优先级

### 单元格内容（高优先级覆盖低优先级）

1. `col.cell`（函数）
2. `col.cell` 字符串直接显示
3. `slots['cell-' + col.colKey]` 动态命名插槽
4. `slots.cell` 全局插槽
5. `cellEmptyContent`（仅当值为 `null/undefined`）
6. 原始字段值 `String(value ?? '')`

### 表头内容

1. `col.title`（函数）
2. `col.title` 字符串
3. `slots['title-' + col.colKey]`
4. `slots.title`
5. `col.colKey`

### 表尾内容

1. `col.foot`（函数）
2. `col.foot` 字符串
3. `slots['foot-' + col.colKey]`
4. `slots.foot`
5. `cellEmptyContent`
6. 原始字段值

---

## cell 渲染函数

```ts
// JSX / TSX 场景推荐
{
  colKey: 'status',
  title: '状态',
  cell: ({ row, col, rowIndex }) => (
    <el-tag type={row.status === 'active' ? 'success' : 'danger'}>
      {row.status}
    </el-tag>
  ),
}

// Vue template 场景推荐使用动态命名插槽
// <template #cell-status="{ row }">
//   <el-tag>{{ row.status }}</el-tag>
// </template>
```

`cell` 函数参数（`XTableCellRenderParams<T>`）：

| 字段       | 说明                         |
| ---------- | ---------------------------- |
| `row`      | 当前行数据 `T`               |
| `col`      | 当前列配置 `XTableColumn<T>` |
| `colIndex` | 列索引                       |
| `rowIndex` | 行索引                       |
| `value`    | 当前单元格值                 |

---

## 动态命名插槽

```vue
<template>
  <el-x-table :columns="columns" :data="data" row-key="id">
    <template #cell-name="{ row }">
      <span class="name-cell">{{ row.name }}</span>
    </template>
    <template #title-name="{ col }">
      <el-icon><User /></el-icon> {{ col.title }}
    </template>
    <template #foot-amount="{ row }">
      <strong>合计: {{ row.amount }}</strong>
    </template>
  </el-x-table>
</template>
```

---

## ellipsis 四种配置

```ts
// 1. 布尔值：使用默认 Tooltip
{ colKey: 'desc', title: '描述', ellipsis: true }

// 2. Tooltip 配置对象
{
  colKey: 'desc',
  ellipsis: { placement: 'top', content: (params) => params.row.desc },
}

// 3. 渲染函数：自定义溢出内容
{
  colKey: 'desc',
  ellipsis: (params) => h('div', { class: 'custom-tooltip' }, params.row.desc),
}

// 4. Overlay 配置
{
  colKey: 'desc',
  ellipsis: { mode: 'overlay', content: '自定义浮层内容' },
}
```

---

## sorter 与 sortType

```ts
// 基础排序：点击表头切换升/降序
{ colKey: 'amount', title: '金额', sorter: true }

// 自定义排序函数
{
  colKey: 'amount',
  sorter: (a, b) => a.amount - b.amount,
  sortType: 'desc',  // 只允许降序（可选 'desc' / 'asc' / 'all'）
}
```

---

## filter 筛选配置

```ts
// 单选筛选
{
  colKey: 'status',
  title: '状态',
  filter: {
    type: 'single',
    list: [
      { label: '启用', value: 'active' },
      { label: '禁用', value: 'inactive' },
    ],
    confirmEvents: ['onConfirm'],
  },
}

// 多选筛选
{
  colKey: 'channel',
  filter: {
    type: 'multiple',
    list: [
      { label: '合同审批', value: 'contract' },
      { label: '采购审批', value: 'purchase' },
    ],
  },
}

// 输入型筛选
{
  colKey: 'keyword',
  filter: {
    type: 'input',
    placeholder: '请输入关键词',
    confirmEvents: ['onEnter', 'onBlur'],
  },
}

// 自定义筛选组件
{
  colKey: 'date',
  filter: {
    type: 'single',
    component: ElDatePicker,
    props: { type: 'daterange' },
    popupProps: { attach: 'body' },
  },
}
```

---

## 样式控制字段

```ts
{
  colKey: 'name',
  title: '名称',
  className: 'name-cell',           // body 单元格 class
  thClassName: 'name-header',       // header 单元格 class
  headerClassName: 'custom-header', // 表头额外 class
  style: { color: 'red' },          // body 单元格 style
  headerStyle: { fontWeight: 'bold' }, // header 单元格 style
  attrs: { 'data-testid': 'name' },  // 自定义 DOM 属性
}
```

---

## 编辑能力详解

### 推荐模式：统一保存 / 取消

```
点击"编辑" → enterRowEdit → 编辑字段 → validateRowData → getEditedRowData
  → 回写外部 data → exitRowEdit
                     ↓
               校验失败 → scrollToFirstError
```

取消时直接调用 `exitRowEdit`，编辑缓存自动丢弃，外部 `data` 保持原样。

### edit 配置完整说明

```ts
{
  colKey: 'name',
  title: '名称',
  edit: {
    // 编辑态渲染组件
    component: ElInput,

    // 进入编辑态前拦截
    beforeEdit: (params) => params.row.status !== 'locked',

    // 编辑组件透传属性（支持静态对象或动态函数）
    props: { placeholder: '请输入名称', maxlength: 50 },
    // 或动态：
    props: (params) => ({
      disabled: params.row.status === 'locked',
    }),

    // 编辑组件事件透传
    on: (params) => ({
      onFocus: () => console.log('focus'),
    }),

    // 校验规则（支持静态或动态）
    rules: [
      { required: true, message: '名称必填' },
      { max: 50, message: '最多50个字符' },
    ],
    // 动态规则（支持跨字段联动）
    rules: (params) => [
      {
        validator: (rule, value) => {
          if (value && params.editedRow.type === 'special') {
            return value.startsWith('SP-')
          }
          return true
        },
        message: '特殊类型必须以 SP- 开头',
      },
    ],

    // 默认进入编辑态（与 editableRowKeys 互斥）
    defaultEditable: false,

    // 始终保持编辑态（含初始化），不可退出
    keepEditMode: false,

    // 是否显示编辑图标
    showEditIcon: true,

    // 校验触发时机：exit（退出编辑时）/ change（值变化时）/ blur（失焦时）
    validateTrigger: 'exit',

    // 配置哪些事件触发时退出编辑态
    abortEditOnEvent: ['onChange'],

    // 编辑完成后的回调（退出编辑且值变化时触发）
    onEdited: (context) => console.log('edited:', context),
  },
}
```

### 行编辑 vs 单元格编辑

| 模式           | 控制方式                                                  | 使用场景                     |
| -------------- | --------------------------------------------------------- | ---------------------------- |
| **行编辑**     | `editableRowKeys`（受控）+ `enterRowEdit` / `exitRowEdit` | 整行统一进入/退出编辑态      |
| **单元格编辑** | 列级 `edit.defaultEditable` / `edit.keepEditMode`         | 特定列始终可编辑             |
| **动态控制**   | `editableCellState` 函数                                  | 根据条件决定哪些单元格可编辑 |

```ts
// 动态控制单元格编辑态
editableCellState: (params) => {
  return params.row.status !== 'locked' && params.col.colKey !== 'id'
}
```

### 校验方法行为差异

| 方法                    | 校验范围                   | 说明                                |
| ----------------------- | -------------------------- | ----------------------------------- |
| `validateTableData`     | 所有配置了 `edit` 的单元格 | 无论是否进入过编辑态，覆盖整表      |
| `validateTableCellData` | 当前处于编辑态的单元格     | 仅已挂载且 `isEdit = true` 的单元格 |
| `validateRowData`       | 指定行的所有可编辑单元格   | —                                   |

### 跨字段更新协议

通过 `updateEditedCellValue` 更新跨多字段或跨行数据时，对象参数**必须**包含 `isAdvancedUpdate: true`：

```ts
// 在 edit.on 中跨字段更新
on: (params) => ({
  onChange: (value) => {
    params.updateEditedCellValue({
      isAdvancedUpdate: true, // 必须！
      name: value,
      code: `CODE-${value}`,
    })
  },
})
```

### 编辑态互斥警告

- `editableRowKeys`（受控编辑行）与 `defaultEditable` / `keepEditMode`（列级默认编辑态）**不可叠加使用**
- 一旦显式传入 `editableRowKeys`（包括空数组 `[]`），列级的 `defaultEditable` 和 `keepEditMode` 将完全失效
- `keepEditMode` 已包含 `defaultEditable` 的初始化效果，区别在于 `keepEditMode` 会阻止退出编辑态

---

## 树表能力详解

### tree 配置

```ts
{
  colKey: 'name',
  title: '名称',
  tree: {
    childrenKey: 'children',      // 子节点字段名，默认 'children'
    indent: 24,                   // 层级缩进宽度（px）
    treeNodeColumnIndex: 0,       // 哪一列显示树节点展开器
    defaultExpandAll: false,      // 是否默认展开全部
    expandTreeNodeOnClick: true,  // 点击整行展开树节点
    checkStrictly: false,         // 选择时父子是否独立
    load: async (context) => {    // 异步加载子节点
      const children = await api.getChildren(context.row.id)
      return children
    },
  },
}
```

### 异步加载

当行数据的 `childrenKey` 字段值为 `true` 时，触发 `tree.load` 异步加载：

```ts
const data = [
  {
    id: '1',
    name: '父节点',
    children: true, // true 表示有子节点但尚未加载
  },
]
```

### 树表事件

| 名称                 | 说明            | 回调参数                          |
| -------------------- | --------------- | --------------------------------- |
| `tree-expand-change` | 树节点展开/折叠 | `XTableTreeExpandContext<T>`      |
| `tree-load`          | 异步加载成功    | `XTableTreeLoadSuccessContext<T>` |
| `tree-load-error`    | 异步加载失败    | `XTableTreeLoadErrorContext<T>`   |
| `abnormal-drag-sort` | 非法树拖拽      | `XTableAbnormalDragSortContext`   |

### 树表实例方法

| 名称                           | 说明                         | 签名                                           |
| ------------------------------ | ---------------------------- | ---------------------------------------------- |
| `expandAll` / `foldAll`        | 展开/折叠所有树节点          | `() => void`                                   |
| `appendTo`                     | 向目标节点追加子节点         | `(referenceRowValue, newRecord) => void`       |
| `insertAfter` / `insertBefore` | 在指定节点后/前插入          | `(key, newData) => void`                       |
| `remove` / `removeChildren`    | 删除节点/删除其全部子节点    | `(key) => void`                                |
| `resetData`                    | 重置整棵树数据               | `(newData: T[]) => void`                       |
| `setData`                      | 更新指定节点数据             | `(key, newRowData) => void`                    |
| `swapData`                     | 交换两个节点数据或位置       | `(params) => void`                             |
| `toggleExpandData`             | 切换指定节点的普通展开行状态 | `(params) => void`                             |
| `getData`                      | 获取指定节点行状态数据       | `(rowValue) => XTableRowState<T> \| undefined` |
| `getTreeExpandedRow`           | 获取当前已展开树节点         | `(type?) => ...[]`                             |
| `getTreeNode`                  | 获取指定节点或整棵树节点数据 | `(rowValue?) => T \| T[] \| undefined`         |

### 树拖拽校验

```ts
beforeDragSort: (context) => {
  // 禁止跨层级拖拽
  if (context.target?.treeNode?.level !== context.current?.treeNode?.level) {
    return false
  }
  return true
}
```

---

## 虚拟滚动配置

```ts
// 默认配置（threshold 100 时自动启用）
virtualScroll: true

// 自定义配置
virtualScroll: {
  threshold: 100,         // 数据量不超过该值时不启用虚拟滚动
  rowHeight: 48,          // 行高参考值，建议设为平均行高
  bufferSize: 20,         // 可见区域外额外渲染行数，建议 5~30
  isFixedRowHeight: false // 固定行高时设为 true，性能更好
}
```

**限制**：与 `rowspanAndColspan`（合并单元格）不兼容，启用合并单元格时自动禁用虚拟滚动。

---

## 固定列 / 吸顶 / 吸底

### 固定列

- 左侧固定列和右侧固定列均应**连续排列**，中间不要夹杂非固定列
- 否则固定列的偏移计算可能出现异常

```ts
const columns = [
  { colKey: 'select', type: 'selection', fixed: 'left', width: 50 },
  { colKey: 'name', fixed: 'left', width: 120 },
  { colKey: 'field1' }, // 中间非固定列
  { colKey: 'field2' },
  { colKey: 'action', fixed: 'right', width: 100 },
]
```

### 吸顶 / 吸底

| 属性                  | 说明                                                                              |
| --------------------- | --------------------------------------------------------------------------------- |
| `headerAffixedTop`    | 表头吸顶。`boolean` 或 `{ offsetTop, container, zIndex }`                         |
| `footerAffixedBottom` | 表底（表尾 + 横向滚动条）吸底。`boolean` 或 `{ offsetBottom, container, zIndex }` |

- 设置 `height` 或 `maxHeight` 时，表尾自动通过 `sticky` 固定在滚动容器底部
- `footerAffixedBottom` 是页面级 Affix，表格滚出屏幕后仍可看到汇总行

---

## 行样式

```ts
// 行 class
rowClassName: (params) => (params.row.status === 'error' ? 'risk-row' : '')

// 行 DOM 属性
rowAttributes: (params) => ({
  'data-risk': params.row.riskLevel,
  title: params.row.riskDesc,
})
```

---

## 外部分页组合

XTable **不内置分页**，由业务层自行组合 `el-pagination`：

```vue
<template>
  <el-x-table
    :columns="columns"
    :data="pagedData"
    row-key="id"
    :sorter="sorter"
    :filter-value="filterValue"
    sorter-mode="remote"
    filter-mode="remote"
    @change="handleChange"
  />
  <el-pagination
    v-model:current-page="page"
    v-model:page-size="pageSize"
    :total="total"
  />
</template>

<script setup>
// 外部状态统一管理
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const sorter = ref()
const filterValue = ref({})

// 排序/筛选变化时重置页码并请求数据
function handleChange(change, context) {
  page.value = 1
  sorter.value = change.sorter
  filterValue.value = change.filter
  fetchData()
}

async function fetchData() {
  const res = await api.getList({
    page: page.value,
    pageSize: pageSize.value,
    sorter: sorter.value,
    filter: filterValue.value,
  })
  pagedData.value = res.list
  total.value = res.total
}
</script>
```

---

## 实例方法速查

| 名称                           | 说明                        | 签名                                           |
| ------------------------------ | --------------------------- | ---------------------------------------------- |
| `refreshTable`                 | 刷新布局、sticky 与滚动状态 | `() => void`                                   |
| `scrollTo`                     | 滚动到指定位置              | `(options: ScrollToOptions) => void`           |
| `scrollToTop`                  | 滚动到顶部                  | `() => void`                                   |
| `scrollToElement`              | 滚动到指定行                | `(params) => void`                             |
| `scrollColumnIntoView`         | 将指定列滚动到可视区        | `(colKey: string, behavior?) => void`          |
| `clearValidateData`            | 清空编辑校验态              | `() => void`                                   |
| `scrollToFirstError`           | 滚动到第一个校验错误        | `(behavior?) => Promise<void>`                 |
| `validateRowData`              | 校验指定行                  | `(rowValue) => Promise<...>`                   |
| `validateTableCellData`        | 校验当前编辑单元格          | `() => Promise<...>`                           |
| `validateTableData`            | 校验整表所有可编辑单元格    | `() => Promise<...>`                           |
| `enterRowEdit`                 | 进入指定行编辑态            | `(rowValue) => void`                           |
| `exitRowEdit`                  | 退出指定行编辑态            | `(rowValue) => void`                           |
| `getEditedRows`                | 获取所有存在编辑缓存的行    | `() => T[]`                                    |
| `getEditedRowData`             | 获取指定行编辑数据          | `(rowValue) => T \| undefined`                 |
| `revertRowEdit`                | 撤销编辑，恢复原数据        | `(rowValue) => void`                           |
| `expandAll` / `foldAll`        | 展开/折叠所有树节点         | `() => void`                                   |
| `appendTo`                     | 向目标节点追加子节点        | `(referenceRowValue, newRecord) => void`       |
| `insertAfter` / `insertBefore` | 在指定节点后/前插入         | `(key, newData) => void`                       |
| `remove` / `removeChildren`    | 删除节点/删除其全部子节点   | `(key) => void`                                |
| `resetData`                    | 重置整棵树数据              | `(newData: T[]) => void`                       |
| `setData`                      | 更新指定节点数据            | `(key, newRowData) => void`                    |
| `swapData`                     | 交换两个节点数据或位置      | `(params) => void`                             |
| `getData`                      | 获取指定节点行状态数据      | `(rowValue) => XTableRowState<T> \| undefined` |
| `getTreeExpandedRow`           | 获取已展开树节点            | `(type?) => ...[]`                             |
| `getTreeNode`                  | 获取指定节点或整棵树数据    | `(rowValue?) => T \| T[] \| undefined`         |

---

## TypeScript 泛型

```ts
import type {
  XTableColumn,
  XTableInstance,
  XTableCellRenderParams,
} from '@hgj/element-plus'

interface User {
  id: number
  name: string
  role: 'admin' | 'user'
}

// columns 的 field 自动约束为 keyof T
const columns: XTableColumn<User>[] = [
  { colKey: 'name', title: 'Name', field: 'name' },
]

// 模板引用指定泛型
const tableRef = ref<XTableInstance<User>>()

// 事件回调参数自动推导
function onCellClick(params: XTableCellRenderParams<User>) {
  console.log(params.row.name) // 类型安全
}
```

SFC 泛型组件：

```vue
<script setup lang="ts" generic="T extends { id: number; name: string }">
import type { XTableColumn } from '@hgj/element-plus'

const props = defineProps<{
  data: T[]
  columns: XTableColumn<T>[]
}>()
</script>
```

---

## 常见错误预防

| 错误                                        | 正确做法                                                                        |
| ------------------------------------------- | ------------------------------------------------------------------------------- |
| 固定列中间夹杂非固定列                      | 左侧/右侧固定列均连续排列                                                       |
| 虚拟滚动 + 合并单元格同时使用               | 二者不兼容，启用合并时虚拟滚动自动禁用                                          |
| `editableRowKeys` 与 `defaultEditable` 叠加 | 二者互斥，传入 `editableRowKeys` 后列级 `defaultEditable` / `keepEditMode` 失效 |
| 在 `row-edit` 事件中逐字段同步外部 `data`   | 编辑期间不更新外部 `data`，保存时通过 `getEditedRowData` 统一回写               |
| 动态行高下 `scrollToElement` 定位不准       | 对定位精度有严格要求时，使用固定行高 `isFixedRowHeight: true`                   |
| 未设置 `row-key`                            | 始终显式传入 `row-key`，尤其在分页联动、选择、展开、树表场景中                  |
