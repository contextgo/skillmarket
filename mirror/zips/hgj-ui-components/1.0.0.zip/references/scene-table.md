# 表格场景

表格是后台系统最核心的数据展示组件。本文档覆盖 XTable 与分页、远程数据、筛选排序、行选择、CRUD 等完整实践。

---

## 最小可用示例

```vue
<script setup lang="ts">
import type { XTableColumn } from '@hgj/element-plus'

interface Row {
  id: string
  name: string
  amount: number
}

const columns: XTableColumn<Row>[] = [
  { colKey: 'id', title: 'ID', width: 80 },
  { colKey: 'name', title: '名称' },
  { colKey: 'amount', title: '金额', align: 'right' },
]

const data: Row[] = [
  { id: '1', name: '订单A', amount: 1000 },
  { id: '2', name: '订单B', amount: 2000 },
]
</script>

<template>
  <el-x-table :columns="columns" :data="data" row-key="id" />
</template>
```

---

## XTable + Pagination 远程数据模式

这是列表页最标准的组合方式：

```vue
<script setup lang="ts">
import type { XTableColumn } from '@hgj/element-plus'

interface Row {
  id: string
  name: string
  status: string
  amount: number
  createdAt: string
}

const columns: XTableColumn<Row>[] = [
  { type: 'selection', width: 50, fixed: 'left' },
  { colKey: 'name', title: '名称', sorter: true },
  {
    colKey: 'status',
    title: '状态',
    filter: {
      type: 'single',
      list: [
        { label: '启用', value: 'active' },
        { label: '禁用', value: 'inactive' },
      ],
    },
  },
  { colKey: 'amount', title: '金额', align: 'right', sorter: true },
  { colKey: 'createdAt', title: '创建时间' },
  {
    colKey: 'action',
    title: '操作',
    width: 120,
    fixed: 'right',
    cell: ({ row }) =>
      h('div', [
        h(
          ElButton,
          { type: 'primary', link: true, onClick: () => handleEdit(row) },
          '编辑'
        ),
        h(
          ElButton,
          { type: 'danger', link: true, onClick: () => handleDelete(row) },
          '删除'
        ),
      ]),
  },
]

const tableData = ref<Row[]>([])
const selectedRowKeys = ref<string[]>([])
const sorter = ref()
const filterValue = ref({})

// 分页
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

// 加载数据
async function loadData() {
  const res = await api.getList({
    page: page.value,
    pageSize: pageSize.value,
    sorter: sorter.value,
    filter: filterValue.value,
  })
  tableData.value = res.list
  total.value = res.total
}

// 表格变化（排序/筛选）
function handleTableChange(change: any) {
  page.value = 1
  sorter.value = change.sorter
  filterValue.value = change.filter
  loadData()
}

// 分页变化
function handlePageChange() {
  loadData()
}

onMounted(loadData)
</script>

<template>
  <el-card-list>
    <el-card>
      <template #header>
        <div class="table-header">
          <span>数据列表</span>
          <el-button type="primary" @click="handleCreate">新建</el-button>
        </div>
      </template>

      <el-x-table
        v-model:selected-row-keys="selectedRowKeys"
        :columns="columns"
        :data="tableData"
        row-key="id"
        row-selection-type="multiple"
        sorter-mode="remote"
        filter-mode="remote"
        @change="handleTableChange"
      />

      <el-pagination
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="handlePageChange"
        @size-change="handlePageChange"
      />
    </el-card>
  </el-card-list>
</template>
```

---

## 筛选表单 + 表格联动

列表页通常在上部放置筛选表单，与表格联动：

```vue
<script setup>
const searchForm = reactive({
  keyword: '',
  status: '',
  dateRange: [] as Date[],
})

async function loadData() {
  const res = await api.getList({
    ...searchForm,
    page: page.value,
    pageSize: pageSize.value,
    sorter: sorter.value,
    filter: filterValue.value,
  })
  tableData.value = res.list
  total.value = res.total
}

function handleSearch() {
  page.value = 1
  loadData()
}

function handleReset() {
  searchForm.keyword = ''
  searchForm.status = ''
  searchForm.dateRange = []
  sorter.value = undefined
  filterValue.value = {}
  page.value = 1
  loadData()
}
</script>

<template>
  <el-card-list>
    <el-card>
      <el-form :model="searchForm" inline>
        <el-form-item label="关键词">
          <el-input
            v-model="searchForm.keyword"
            placeholder="请输入"
            clearable
          />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="请选择" clearable>
            <el-option label="启用" value="active" />
            <el-option label="禁用" value="inactive" />
          </el-select>
        </el-form-item>
        <el-form-item label="日期">
          <el-date-picker v-model="searchForm.dateRange" type="daterange" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card>
      <el-x-table :columns="columns" :data="tableData" row-key="id" />
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
      />
    </el-card>
  </el-card-list>
</template>
```

---

## 行选择与批量操作

```vue
<script setup>
const selectedRowKeys = ref<string[]>([])

function handleBatchDelete() {
  if (!selectedRowKeys.value.length) {
    ElMessage.warning('请先选择数据')
    return
  }
  // 执行批量删除
}
</script>

<template>
  <el-card>
    <template #header>
      <div class="table-header">
        <span>数据列表</span>
        <el-button type="danger" @click="handleBatchDelete">批量删除</el-button>
      </div>
    </template>

    <el-x-table
      v-model:selected-row-keys="selectedRowKeys"
      :columns="columns"
      :data="tableData"
      row-key="id"
      row-selection-type="multiple"
    />
  </el-card>
</template>
```

---

## 展开行展示详情

适用于审批/工单中心等需要展示额外信息的场景：

```vue
<template>
  <el-x-table
    v-model:expanded-row-keys="expandedKeys"
    :columns="columns"
    :data="data"
    row-key="id"
  >
    <template #expanded-row="{ row }">
      <el-descriptions :column="3">
        <el-descriptions-item label="申请人">{{
          row.applicant
        }}</el-descriptions-item>
        <el-descriptions-item label="申请时间">{{
          row.applyTime
        }}</el-descriptions-item>
        <el-descriptions-item label="审批意见">{{
          row.comment
        }}</el-descriptions-item>
      </el-descriptions>
    </template>
  </el-x-table>
</template>
```

---

## 树形表格

```vue
<script setup>
const columns = [
  {
    colKey: 'name',
    title: '名称',
    tree: { childrenKey: 'children', indent: 24 },
  },
  { colKey: 'status', title: '状态' },
]

const data = [
  {
    id: '1',
    name: '父节点',
    status: 'active',
    children: [
      { id: '1-1', name: '子节点1', status: 'active' },
      { id: '1-2', name: '子节点2', status: 'inactive' },
    ],
  },
]
</script>

<template>
  <el-x-table :columns="columns" :data="data" row-key="id" />
</template>
```

---

## 行编辑模式

```vue
<script setup>
const tableRef = ref()
const editableRowKeys = ref<string[]>([])

const columns = [
  { colKey: 'name', title: '名称', edit: { component: ElInput, rules: [{ required: true }] } },
  { colKey: 'amount', title: '金额', edit: { component: ElInputNumber } },
  {
    colKey: 'action',
    title: '操作',
    cell: ({ row }) =>
      h('div', [
        h(ElButton, { link: true, onClick: () => tableRef.value?.enterRowEdit(row) }, '编辑'),
        h(ElButton, { link: true, onClick: () => handleSave(row) }, '保存'),
        h(ElButton, { link: true, onClick: () => tableRef.value?.exitRowEdit(row) }, '取消'),
      ]),
  },
]

async function handleSave(row) {
  const valid = await tableRef.value?.validateRowData(row).catch(() => false)
  if (!valid) return
  const edited = tableRef.value?.getEditedRowData(row)
  await api.update(edited)
  tableRef.value?.exitRowEdit(row)
}
</script>

<template>
  <el-x-table ref="tableRef" :columns="columns" :data="data" row-key="id" />
</template>
```

**要点**：

- 编辑期间不更新外部 `data`
- 保存时通过 `getEditedRowData` 统一回写
- 取消时直接调用 `exitRowEdit`，编辑缓存自动丢弃

---

## 虚拟滚动配置

当数据量超过 100 行时，XTable 默认自动启用虚拟滚动：

```ts
// 默认配置（threshold 100 时自动启用）
virtualScroll: true

// 自定义配置
virtualScroll: {
  threshold: 100,
  rowHeight: 48,
  bufferSize: 20,
  isFixedRowHeight: false,
}
```

**限制**：与 `rowspanAndColspan`（合并单元格）不兼容，启用合并时虚拟滚动自动禁用。

---

## 固定列与吸顶

### 固定列

左侧/右侧固定列均应**连续排列**，中间不要夹杂非固定列：

```ts
const columns = [
  { colKey: 'select', type: 'selection', fixed: 'left', width: 50 },
  { colKey: 'name', fixed: 'left', width: 120 },
  { colKey: 'field1' }, // 中间非固定列
  { colKey: 'field2' },
  { colKey: 'action', fixed: 'right', width: 100 },
]
```

### 吸顶 / 吸底

```vue
<el-x-table
  :columns="columns"
  :data="data"
  row-key="id"
  :header-affixed-top="{ offsetTop: 60 }"
  :footer-affixed-bottom="true"
/>
```
