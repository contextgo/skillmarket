# 导入、配置与主题

## 安装

```bash
pnpm add @hgj/element-plus
```

## 导入方式

### 自动导入（推荐）

安装依赖：

```bash
pnpm add -D unplugin-vue-components unplugin-auto-import @hgj/element-plus-import-resolver
```

Vite 配置：

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import HElementPlusResolver from '@hgj/element-plus-import-resolver'

export default defineConfig({
  plugins: [
    AutoImport({
      resolvers: [HElementPlusResolver()],
    }),
    Components({
      resolvers: [HElementPlusResolver()],
    }),
  ],
})
```

Webpack 配置：

```js
// webpack.config.js
const AutoImport = require('unplugin-auto-import/webpack')
const Components = require('unplugin-vue-components/webpack')
const HElementPlusAutoResolver = require('@hgj/element-plus-import-resolver')

module.exports = {
  plugins: [
    AutoImport({ resolvers: [HElementPlusAutoResolver()] }),
    Components({ resolvers: [HElementPlusAutoResolver()] }),
  ],
}
```

自动导入后，模板中可直接使用组件，无需显式 import：

```vue
<template>
  <el-button>按钮</el-button>
  <el-x-table :columns="columns" :data="data" />
</template>

<script setup>
// 无需 import ElButton 或 ElXTable
</script>
```

### 完整引入

```ts
// main.ts
import { createApp } from 'vue'
import HElementPlus from '@hgj/element-plus'
import '@hgj/element-plus/dist/index.css'
import App from './App.vue'

const app = createApp(App)
app.use(HElementPlus)
app.mount('#app')
```

### 手动导入

```ts
import { ElButton, ElXTable } from '@hgj/element-plus'
```

配合 `@hgj/element-plus-manual-import-resolver` 自动引入样式。

### Nuxt

```bash
pnpm add -D @hgj/element-plus-nuxt
```

```ts
// nuxt.config.ts
export default defineNuxtConfig({
  modules: ['@hgj/element-plus-nuxt'],
})
```

## TypeScript Volar 支持

```json
// tsconfig.json
{
  "compilerOptions": {
    "types": ["@hgj/element-plus/global"]
  }
}
```

这样可以在模板中获得组件的类型提示和属性校验。

## 全局配置

### 通过 app.use 配置（完整引入时）

```ts
app.use(HElementPlus, { size: 'small', zIndex: 3000 })
```

### 通过 ElConfigProvider 配置（按需引入时）

```vue
<template>
  <el-config-provider :size="size" :z-index="zIndex" :nas="nasConfig">
    <app />
  </el-config-provider>
</template>

<script setup>
const size = ref('small')
const zIndex = ref(3000)
const nasConfig = ref({ env: 'dev' }) // NasFile 依赖此配置
</script>
```

### ElConfigProvider 配置项

| 属性     | 说明           | 类型                               | 默认值           |
| -------- | -------------- | ---------------------------------- | ---------------- |
| `size`   | 全局组件尺寸   | `'large' / 'default' / 'small'`    | —                |
| `zIndex` | 弹窗层级基准值 | `number`                           | —                |
| `locale` | 国际化语言包   | `Language`                         | 中文（无需配置） |
| `nas`    | NAS 文件配置   | `{ env: 'dev' / 'beta' / 'prod' }` | —                |

## 样式引入

### 完整 CSS（完整引入时）

```ts
import '@hgj/element-plus/dist/index.css'
```

### 按需引入样式

使用自动导入时，样式由 resolver 自动处理，无需手动引入。

使用手动导入时，配合 `@hgj/element-plus-manual-import-resolver`：

```ts
// vite.config.ts
import HElementPlusManualResolver from '@hgj/element-plus-manual-import-resolver/vite'

export default defineConfig({
  plugins: [HElementPlusManualResolver()],
})
```

## 主题定制

### CSS 变量覆盖

hgj-ui-components 使用 `--hep-*` 作为 CSS 变量前缀：

```css
/* 覆盖主题色 */
:root {
  --hep-color-primary: #409eff;
  --hep-color-success: #67c23a;
  --hep-color-warning: #e6a23c;
  --hep-color-danger: #f56c6c;
}
```

### SCSS 变量

如需深度定制，可修改 theme-chalk 源码中的 SCSS 变量后重新构建主题。

## 国际化

默认语言为中文（`zh-cn`），无需额外配置。

如需切换语言：

```ts
import { ElConfigProvider } from '@hgj/element-plus'
import zhCn from '@hgj/element-plus/dist/locale/zh-cn.mjs'
import en from '@hgj/element-plus/dist/locale/en.mjs'

// 模板中使用
<el-config-provider :locale="en">
```

## 注意事项

- 自动导入和手动导入可以同时使用，resolver 会自动处理去重
- 使用手动导入时，不要额外引入任何样式文件
- 全局配置请通过 `ElConfigProvider` 进行，不要直接修改样式文件
- 默认语言为 `zh-cn`，不需要特别指定
