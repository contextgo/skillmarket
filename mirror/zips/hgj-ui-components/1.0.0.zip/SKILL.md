---
name: hgj-ui-components
description: |
  @hgj/element-plus 海管家内部 Vue 3 UI 组件库使用指南。
  触发条件（满足任一即触发）：
  1. 代码中出现 el-button、el-input、el-form、el-table、el-dialog、el-select、el-date-picker、el-pagination、el-tooltip、el-menu、el-tabs 等 el- 前缀组件；
  2. 使用 @hgj/element-plus 包；
  3. 编写 Vue 3 管理后台、表单页、列表页、数据表格、弹窗、页签导航、看板仪表盘、通知公告；
  4. 涉及 XTable、TabsPro、DialogWrapper、CardContainer、HighlightInput、TextEllipsis、Notice、NasFile、NumberFlow 等自定义组件；
  5. 使用 ElMessage、ElMessageBox、ElNotification、ElLoading 等方法型 API。
  警告：本库标准组件（el-xxx）与 Element Plus 开源版同名但 API、默认值、行为已显著变更，严禁参考外部开源文档。
---

# hgj-ui-components 组件库使用指南

## LLM 使用指令（必读）

1. **强制触发**：当任务涉及任何 `el-` 前缀组件或 `@hgj/element-plus` 时，**必须**调用并遵循本文档。
2. **严禁外参**：标准组件（el-xxx）的 API **严禁**使用 Element Plus 开源版的记忆，必须以本文档和源码类型定义为准。
3. **标记识别**：
   - `🔧` = 本库独有属性（开源版不存在）
   - `⚠️` = 默认值/行为与 Element Plus 开源版不同
   - `🔄` = 用法模式与开源版不同（如属性回调替代事件）
4. **未知属性**：当需要使用的属性未在本文档列出时，**必须**查阅组件库包源码类型定义 `node_modules/@hgj/element-plus/es/components/<组件名(移除el-前缀)>/index.d.ts` 进行查询，不得编造。

## 库概述

hgj-ui-components（包名 `@hgj/element-plus`，CSS 变量前缀 `--hep-*`）是海管家内部维护的 Vue 3 组件库，全局注册名统一为 `ElXxx`，模板中使用 `<el-xxx>`。

> **重要警告：本库为内部独立维护的组件库，虽然大量组件名称与 Element Plus 开源版相同，但 API、默认值、行为均已发生显著变更。编写代码时严禁参考外部 Element Plus 开源文档，必须以本文档和类型定义为准。**

---

## 自定义组件特别警告

以下 9 个组件是自定义或二次封装的，**API 与库内标准组件差异极大**，不可凭记忆编造：

| 组件               | 模板标签                                                                         | 说明                                                       | 详细文档                        |
| ------------------ | -------------------------------------------------------------------------------- | ---------------------------------------------------------- | ------------------------------- |
| **XTable**         | `<el-x-table>`                                                                   | 完全自研配置驱动表格，内置虚拟滚动、行编辑、树表、拖拽排序 | `references/x-table.md`         |
| **TabsPro**        | `<el-tabs-pro>`                                                                  | 完全自研业务页签，支持溢出替换和程序化增删                 | `references/tabs-pro.md`        |
| **DialogWrapper**  | `<el-dialog-wrapper>`                                                            | Promise 式弹窗管理（`openDialog`）                         | `references/dialog-wrapper.md`  |
| **CardContainer**  | `<el-card-container>` / `<el-card-list>` / `<el-card-form>` / `<el-card-custom>` | 卡片容器系列，三种预设间距                                 | `references/card-container.md`  |
| **HighlightInput** | `<el-highlight-input>`                                                           | 继承 ElInput，支持正则高亮匹配                             | `references/highlight-input.md` |
| **TextEllipsis**   | `<el-text-ellipsis>`                                                             | 文本省略，支持多行省略和展开/收起                          | `references/text-ellipsis.md`   |
| **Notice**         | `<el-notice>`                                                                    | 通知公告，支持轮播、折叠、持久化                           | `references/notice.md`          |
| **NasFile**        | `<el-nas-file>`（方法导出）                                                      | NAS 文件操作，依赖 `ElConfigProvider` 传入 `nas.env`       | `references/nas-file.md`        |
| **NumberFlow**     | `<el-number-flow>` / `<el-number-flow-group>`                                    | 数字流动画，支持复杂时序和联动                             | `references/number-flow.md`     |

---

## 高频业务场景速查

| 场景            | 涉及的典型组件组合                                                   | 详细文档                           |
| --------------- | -------------------------------------------------------------------- | ---------------------------------- |
| **表单页**      | `el-form` + 输入控件 + 校验规则                                      | `references/scene-form.md`         |
| **列表页/表格** | `el-x-table` + `el-pagination` + 远程数据                            | `references/scene-table.md`        |
| **弹窗/抽屉**   | `el-dialog` / `el-drawer` / `dialog-wrapper`                         | `references/scene-dialog.md`       |
| **布局**        | `el-container` + `el-card-list` / `el-card-form` + `el-row`/`el-col` | `references/scene-layout.md`       |
| **页签导航**    | `el-tabs-pro` / `el-tabs`                                            | `references/scene-navigation.md`   |
| **看板/仪表盘** | `el-number-flow` + `el-statistic` + `el-card`                        | `references/scene-dashboard.md`    |
| **通知公告**    | `el-notice` + `el-alert`                                             | `references/scene-notification.md` |

---

## 安装与导入（精简）

```bash
pnpm add @hgj/element-plus
```

注意：由于组件库存储在内部私有仓库项目中，因此需要在项目根目录的`.npmrc`为包管理器(`npm`或`pnpm`)配置`registry`:

```
# @hgj registry 指向公司私有库
@hgj:registry=http://nexus.hgj.net/repository/npm-internal/
```

**推荐自动导入**（安装 `unplugin-vue-components` + `unplugin-auto-import` + `@hgj/element-plus-import-resolver`）：

```ts
import HElementPlusResolver from '@hgj/element-plus-import-resolver'

export default defineConfig({
  plugins: [
    AutoImport({ resolvers: [HElementPlusResolver()] }),
    Components({ resolvers: [HElementPlusResolver()] }),
  ],
})
```

**TypeScript Volar 支持**：`tsconfig.json` 中加 `"types": ["@hgj/element-plus/global"]`

**全局配置**：通过 `ElConfigProvider` 传入 `size`、`zIndex`、`nas`（NasFile 依赖 `nas.env`）

详细配置（主题、国际化、Nuxt、手动导入）见 `references/setup.md`。

---

## 完整组件索引

> **以下标准组件虽然名称与 Element Plus 开源版相同，但 API、默认值和行为已发生显著变更，不应参考外部文档，请以本文档为准。**
> 属性表中：`🔧` = 本库独有属性；`⚠️` = 默认值与开源版不同；`🔄` = 用法模式与开源版不同。

自定义组件以 🔧 标记，API 与标准组件差异较大，务必查阅独立文档。

### Basic 基础

文档：`references/components-basic.md`

| 注册名           | 模板标签           | 备注                            |
| ---------------- | ------------------ | ------------------------------- |
| `ElButton`       | `el-button`        |                                 |
| `ElButtonGroup`  | `el-button-group`  | 子组件                          |
| `ElIcon`         | `el-icon`          |                                 |
| `ElTag`          | `el-tag`           |                                 |
| `ElLink`         | `el-link`          |                                 |
| `ElImage`        | `el-image`         |                                 |
| `ElTextEllipsis` | `el-text-ellipsis` | 文本省略，见 `text-ellipsis.md` |

### Form 表单

文档：`references/components-form.md`

| 注册名                                                | 模板标签                                                   | 备注                                |
| ----------------------------------------------------- | ---------------------------------------------------------- | ----------------------------------- |
| `ElInput`                                             | `el-input`                                                 |                                     |
| `ElHighlightInput`                                    | `el-highlight-input`                                       | 高亮输入框，见 `highlight-input.md` |
| `ElInputNumber`                                       | `el-input-number`                                          |                                     |
| `ElInputTag`                                          | `el-input-tag`                                             |                                     |
| `ElAutocomplete`                                      | `el-autocomplete`                                          |                                     |
| `ElSwitch`                                            | `el-switch`                                                |                                     |
| `ElRadio` / `ElRadioButton` / `ElRadioGroup`          | `el-radio` / `el-radio-button` / `el-radio-group`          | 组合使用                            |
| `ElCheckbox` / `ElCheckboxGroup` / `ElCheckboxButton` | `el-checkbox` / `el-checkbox-group` / `el-checkbox-button` | 组合使用                            |
| `ElSelect` / `ElOption` / `ElOptionGroup`             | `el-select` / `el-option` / `el-option-group`              | 组合使用                            |
| `ElSelectV2`                                          | `el-select-v2`                                             | 虚拟化选择器                        |
| `ElDatePicker`                                        | `el-date-picker`                                           |                                     |
| `ElTimePicker`                                        | `el-time-picker`                                           |                                     |
| `ElTimeSelect`                                        | `el-time-select`                                           |                                     |
| `ElCascader`                                          | `el-cascader`                                              |                                     |
| `ElTreeSelect`                                        | `el-tree-select`                                           |                                     |
| `ElUpload`                                            | `el-upload`                                                |                                     |
| `ElColorPicker`                                       | `el-color-picker`                                          |                                     |
| `ElSlider`                                            | `el-slider`                                                |                                     |
| `ElRate`                                              | `el-rate`                                                  |                                     |
| `ElForm` / `ElFormItem`                               | `el-form` / `el-form-item`                                 | 组合使用                            |

### Data 数据展示

文档：`references/components-data.md`

| 注册名                                               | 模板标签                                                     | 备注                            |
| ---------------------------------------------------- | ------------------------------------------------------------ | ------------------------------- |
| `ElTable` / `ElTableColumn`                          | `el-table` / `el-table-column`                               | 标准表格                        |
| `ElXTable`                                           | `el-x-table`                                                 | 核心增强表格，见 `x-table.md`   |
| `ElPagination`                                       | `el-pagination`                                              |                                 |
| `ElSkeleton` / `ElSkeletonItem`                      | `el-skeleton` / `el-skeleton-item`                           |                                 |
| `ElEmpty`                                            | `el-empty`                                                   |                                 |
| `ElResult`                                           | `el-result`                                                  |                                 |
| `ElDescriptions` / `ElDescriptionsItem`              | `el-descriptions` / `el-descriptions-item`                   |                                 |
| `ElAvatar`                                           | `el-avatar`                                                  |                                 |
| `ElBadge`                                            | `el-badge`                                                   |                                 |
| `ElCollapse` / `ElCollapseItem`                      | `el-collapse` / `el-collapse-item`                           |                                 |
| `ElCard`                                             | `el-card`                                                    |                                 |
| `ElCarousel` / `ElCarouselItem`                      | `el-carousel` / `el-carousel-item`                           |                                 |
| `ElProgress`                                         | `el-progress`                                                |                                 |
| `ElTimeline` / `ElTimelineItem`                      | `el-timeline` / `el-timeline-item`                           |                                 |
| `ElTransfer`                                         | `el-transfer`                                                |                                 |
| `ElTree`                                             | `el-tree`                                                    |                                 |
| `ElStatistic` / `ElCountdown`                        | `el-statistic` / `el-countdown`                              |                                 |
| `ElNumberFlow` / `ElNumberFlowGroup`                 | `el-number-flow` / `el-number-flow-group`                    | 数字流动画，见 `number-flow.md` |
| `ElTreeV2`                                           | `el-tree-v2`                                                 | 虚拟化树                        |
| `ElListV2` / `ElDynamicSizeList` / `ElFixedSizeList` | `el-list-v2` / `el-dynamic-size-list` / `el-fixed-size-list` | 虚拟化列表                      |
| `ElTour` / `ElTourStep`                              | `el-tour` / `el-tour-step`                                   |                                 |

### Navigation 导航

文档：`references/components-navigation.md`

| 注册名                                                    | 模板标签                                                          | 备注                       |
| --------------------------------------------------------- | ----------------------------------------------------------------- | -------------------------- |
| `ElMenu` / `ElMenuItem` / `ElMenuItemGroup` / `ElSubMenu` | `el-menu` / `el-menu-item` / `el-menu-item-group` / `el-sub-menu` | 组合使用                   |
| `ElTabs` / `ElTabPane`                                    | `el-tabs` / `el-tab-pane`                                         | 标准页签                   |
| `ElTabsPro`                                               | `el-tabs-pro`                                                     | 业务页签，见 `tabs-pro.md` |
| `ElBreadcrumb` / `ElBreadcrumbItem`                       | `el-breadcrumb` / `el-breadcrumb-item`                            |                            |
| `ElSteps` / `ElStep`                                      | `el-steps` / `el-step`                                            |                            |
| `ElDropdown` / `ElDropdownItem` / `ElDropdownMenu`        | `el-dropdown` / `el-dropdown-item` / `el-dropdown-menu`           |                            |
| `ElPageHeader`                                            | `el-page-header`                                                  |                            |

### Feedback 反馈

文档：`references/components-feedback.md`

| 注册名         | 模板标签        | 备注                     |
| -------------- | --------------- | ------------------------ |
| `ElAlert`      | `el-alert`      |                          |
| `ElDialog`     | `el-dialog`     | 标准对话框               |
| `ElDrawer`     | `el-drawer`     |                          |
| `ElTooltip`    | `el-tooltip`    |                          |
| `ElPopover`    | `el-popover`    |                          |
| `ElPopconfirm` | `el-popconfirm` |                          |
| `ElNotice`     | `el-notice`     | 通知公告，见 `notice.md` |

### Auxiliary 辅助

文档：`references/components-auxiliary.md`

| 注册名                      | 模板标签                       | 备注     |
| --------------------------- | ------------------------------ | -------- |
| `ElConfigProvider`          | `el-config-provider`           | 全局配置 |
| `ElScrollbar`               | `el-scrollbar`                 |          |
| `ElDivider`                 | `el-divider`                   |          |
| `ElSpace`                   | `el-space`                     |          |
| `ElAffix`                   | `el-affix`                     |          |
| `ElAnchor` / `ElAnchorLink` | `el-anchor` / `el-anchor-link` |          |
| `ElBacktop`                 | `el-backtop`                   |          |
| `ElImageViewer`             | `el-image-viewer`              |          |
| `ElCollapseTransition`      | `el-collapse-transition`       | 内置过渡 |

### Layout 布局

文档：`references/components-layout.md`

| 注册名                                                           | 模板标签                                                                 | 备注                                 |
| ---------------------------------------------------------------- | ------------------------------------------------------------------------ | ------------------------------------ |
| `ElRow` / `ElCol`                                                | `el-row` / `el-col`                                                      | 栅格                                 |
| `ElContainer` / `ElAside` / `ElHeader` / `ElMain` / `ElFooter`   | `el-container` / `el-aside` / `el-header` / `el-main` / `el-footer`      | 页面布局                             |
| `ElCardContainer` / `ElCardList` / `ElCardForm` / `ElCardCustom` | `el-card-container` / `el-card-list` / `el-card-form` / `el-card-custom` | 卡片容器系列，见 `card-container.md` |

---

## 功能关键词反查

| 需求关键词    | 推荐组件/方法                   | 备选组件                              |
| ------------- | ------------------------------- | ------------------------------------- |
| 表格/列表展示 | `el-x-table`                    | `el-table`                            |
| 简单表格      | `el-table`                      | —                                     |
| 页签/标签页   | `el-tabs-pro`（业务页签）       | `el-tabs`（内容切换）                 |
| 卡片容器      | `el-card-list` / `el-card-form` | `el-card-container`                   |
| 弹窗/对话框   | `el-dialog`                     | `dialog-wrapper`（Promise 式）        |
| 通知/公告     | `el-notice`                     | `el-alert` / `ElNotification`（方法） |
| 文件操作      | `el-nas-file`                   | `el-upload`                           |
| 数字动画      | `el-number-flow`                | `el-statistic` / `el-countdown`       |
| 文本省略      | `el-text-ellipsis`              | `el-tooltip`                          |
| 高亮输入      | `el-highlight-input`            | `el-input`                            |
| 表单          | `el-form` + `el-form-item`      | —                                     |
| 分页          | `el-pagination`                 | —                                     |
| 树形数据      | `el-tree` / `el-tree-v2`        | —                                     |
| 选择器        | `el-select` / `el-select-v2`    | `el-cascader` / `el-tree-select`      |
| 日期时间      | `el-date-picker`                | `el-time-picker` / `el-time-select`   |
| 加载状态      | `ElLoading`（方法）             | `el-skeleton`                         |
| 步骤/流程     | `el-steps`                      | —                                     |
| 菜单/导航     | `el-menu`                       | `el-breadcrumb`                       |
| 消息提示      | `ElMessage`（方法）             | `ElNotification`（方法）              |
| 确认弹窗      | `ElMessageBox.confirm`（方法）  | `el-popconfirm`                       |
| 消息提示      | `ElMessage`（方法）             | —                                     |
| 全局通知      | `ElNotification`（方法）        | `el-notice`                           |
| 加载状态      | `ElLoading`（方法）             | `el-skeleton`                         |

---

## 信息检索指引

当需要查询某个组件的详细 API 时：

1. **自定义组件** — 查阅 `references/<component-name>.md`（如 `x-table.md`、`tabs-pro.md`）
2. **标准组件** — 在上文索引中确认类别，再读对应 `references/components-*.md`
3. **业务场景** — 查阅 `references/scene-*.md` 了解跨组件组合用法
4. **类型定义** — 在源码 `packages/components/<component-name>/src/<component-name>.ts` 中查看
5. **源码实现** — 当文档和类型定义都不足以解答时

---

## Reference 文件导航

| 文件                               | 内容                                                                    | 何时读取                                  |
| ---------------------------------- | ----------------------------------------------------------------------- | ----------------------------------------- |
| `references/setup.md`              | 安装、导入、主题、国际化                                                | 项目初始化或配置相关                      |
| `references/patterns.md`           | 业务页面模式总览                                                        | 编写列表页/表单页/详情页/弹窗时的架构参考 |
| `references/scene-*.md`            | 7 个高频场景详细文档                                                    | 对应业务场景的实现细节                    |
| `references/components-*.md`       | 7 个类别标准组件 API                                                    | 查询具体组件的属性/事件/插槽              |
| `references/components-methods.md` | 方法型反馈 API（ElMessage / ElMessageBox / ElNotification / ElLoading） | 使用消息提示、确认弹窗、通知、加载时      |
| `references/x-table.md`            | XTable 完整文档                                                         | 使用 XTable 时（必读）                    |
| `references/tabs-pro.md`           | TabsPro 完整文档                                                        | 使用 TabsPro 时                           |
| `references/dialog-wrapper.md`     | DialogWrapper 完整文档                                                  | 使用 Promise 式弹窗时                     |
| `references/card-container.md`     | CardContainer 完整文档                                                  | 使用卡片容器系列时                        |
| `references/highlight-input.md`    | HighlightInput 完整文档                                                 | 使用高亮输入框时                          |
| `references/text-ellipsis.md`      | TextEllipsis 完整文档                                                   | 使用文本省略时                            |
| `references/notice.md`             | Notice 完整文档                                                         | 使用通知公告时                            |
| `references/nas-file.md`           | NasFile 完整文档                                                        | 使用 NAS 文件操作时                       |
| `references/number-flow.md`        | NumberFlow 完整文档                                                     | 使用数字流动画时                          |
