#!/usr/bin/env node

/**
 * 微信公众号内容生成器主脚本（修复版）
 * 修复问题：
 * 1. 移除测试文章内容
 * 2. 图片生成基于实际文章内容
 * 3. 发布后清理本地图片
 * 4. 支持直接传入文章内容
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const sharp = require('sharp');

// 加载配置文件
const configPath = path.join(__dirname, 'configs', 'wechat_config.json');
let config;
try {
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
} catch (error) {
  console.error('❌ 配置文件读取失败:', error.message);
  console.log('💡 请确保已正确配置 configs/wechat_config.json 文件');
  process.exit(1);
}

class WeChatContentGenerator {
  constructor() {
    this.config = config;
    this.accessToken = null;
    this.localImagePaths = []; // 记录本地图片路径，用于后续清理
  }

  /**
   * 主处理函数
   * @param {string} articleContent - 文章内容
   * @returns {Promise<Object>} 处理结果
   */
  async processArticle(articleContent) {
    console.log('🚀 微信公众号内容生成器（修复版）');
    console.log('='.repeat(70));
    
    // 显示文章内容预览
    console.log('📝 文章内容预览:');
    console.log(articleContent.substring(0, 150) + (articleContent.length > 150 ? '...' : ''));
    console.log('='.repeat(70));
    
    try {
      // 1. 获取微信访问令牌
      await this.getAccessToken();
      
      // 2. 分析文章内容，生成相关图片提示词
      console.log('\n🔍 分析文章内容，生成相关图片...');
      const articleAnalysis = this.analyzeArticleContent(articleContent);
      
      // 3. 生成优化封面图（基于文章内容）
      console.log('\n🎨 1. 生成优化封面图...');
      const coverResult = await this.generateArticleCoverImage(articleAnalysis);
      
      // 4. 生成优化内容插图（基于文章内容）
      console.log('\n🎨 2. 生成优化内容插图...');
      const contentImages = await this.generateArticleContentImages(articleAnalysis);
      
      // 5. 格式化文章内容
      console.log('\n📝 3. 格式化文章内容...');
      const formattedContent = this.formatArticleContent(articleContent, contentImages, articleAnalysis);
      
      // 6. 创建微信公众号草稿
      console.log('\n📄 4. 创建微信公众号草稿...');
      const draftResult = await this.createWeChatDraft(
        articleAnalysis.title,
        formattedContent,
        coverResult.mediaId,
        articleAnalysis.summary
      );
      
      // 7. 保存处理结果
      const result = this.saveResult(articleContent, articleAnalysis, coverResult, contentImages, draftResult);
      
      // 8. 清理本地图片文件（可选，根据配置决定）
      this.cleanupLocalImages();
      
      console.log('\n' + '='.repeat(70));
      console.log('🎉 文章发布成功！');
      console.log('='.repeat(70));
      this.displayResult(result);
      
      return result;
      
    } catch (error) {
      console.error('\n❌ 处理失败:', error.message);
      // 即使失败也尝试清理本地图片
      this.cleanupLocalImages();
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * 分析文章内容
   */
  analyzeArticleContent(articleContent) {
    const lines = articleContent.split('\n').filter(line => line.trim().length > 0);
    const firstLine = lines[0] || '';
    
    // 提取关键词
    const keywords = this.extractKeywords(articleContent);
    
    // 生成标题
    let title = firstLine;
    if (title.length > 30) {
      title = title.substring(0, 27) + '...';
    }
    
    // 生成摘要
    let summary = firstLine;
    if (summary.length > 50) {
      summary = summary.substring(0, 47) + '...';
    }
    
    // 分析文章主题
    const themes = this.identifyThemes(articleContent);
    
    return {
      title: title,
      summary: summary,
      keywords: keywords,
      themes: themes,
      wordCount: articleContent.length,
      lineCount: lines.length
    };
  }

  /**
   * 提取关键词
   */
  extractKeywords(content) {
    const commonWords = ['的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'];
    
    const words = content
      .replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 1 && !commonWords.includes(word));
    
    // 统计词频
    const wordCount = {};
    words.forEach(word => {
      wordCount[word] = (wordCount[word] || 0) + 1;
    });
    
    // 按频率排序，取前5个
    return Object.entries(wordCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(entry => entry[0]);
  }

  /**
   * 识别文章主题（优先级：具体场景 > 抽象概念）
   */
  identifyThemes(content) {
    const themes = [];
    
    // ---- 优先识别具体场景主题（权重高） ----
    // 亲子/家庭
    if (/孩[子们]|带娃|陪[孩娃]|父母|教育孩|家庭/.test(content)) {
      themes.push('亲子');
    }
    // 自然/户外
    if (/户外|大自然|山坡|花草|树木|花开|花瓣|游玩|游乐|滑梯|秋千/.test(content)) {
      themes.push('自然');
    }
    // 旅行/探索
    if (/旅行|旅游|出门走走|走进去|去看看|走出去/.test(content)) {
      themes.push('探索');
    }
    // 成长/感悟
    if (/启发|收获|感悟|见识|经历|体验|认知|成长/.test(content)) {
      themes.push('感悟');
    }
    
    // ---- 如果具体场景已足够，直接返回 ----
    if (themes.length >= 2) {
      return themes;
    }
    
    // ---- 其次识别抽象概念主题（权重低，排除误匹配） ----
    // 职场（需排除"工作忙"等非职场用法的"工作"）
    if (/职场|职业发展|同事|老板|晋升|跳槽/.test(content)) {
      themes.push('职场');
    }
    // 事业/创业
    if (/创业|事业|企业|老板|雇佣/.test(content) && !/工作忙|忙/.test(content)) {
      themes.push('事业');
    }
    // 投资/理财
    if (/投资|股票|基金|财富|理财|资产/.test(content)) {
      themes.push('投资');
    }
    // 科技/AI（需排除"AI时代"等泛指用法）
    if (/(?:人工智能|AI技术|机器学习|深度学习|编程|算法)/.test(content)) {
      themes.push('科技');
    }
    // 生活/人生
    if (/生活[意义]?|人生[价值意义]?|日子/.test(content)) {
      themes.push('生活');
    }
    
    return themes.length > 0 ? themes : ['思考', '分享'];
  }

  /**
   * 生成文章相关封面图
   */
  async generateArticleCoverImage(articleAnalysis) {
    const { title, themes, keywords } = articleAnalysis;
    
    // 基于文章主题生成封面图提示词
    const themeText = themes.join('、');
    const keywordText = keywords.slice(0, 3).join('、');
    
    const coverPrompt = `微信公众号封面图：${title}。主题：${themeText}，关键词：${keywordText}。设计概念：现代商务风格，简洁大气，视觉冲击力强，适合移动端点击，蓝色主题，高质量插画，4K画质`;
    
    try {
      console.log(`  生成封面图: ${title.substring(0, 30)}...`);
      const coverBuffer = await this.generateImageWithVolcano(coverPrompt, 'cover');
      
      // 保存封面图
      const outputsDir = path.join(__dirname, 'outputs');
      if (!fs.existsSync(outputsDir)) {
        fs.mkdirSync(outputsDir, { recursive: true });
      }
      
      const coverPath = path.join(outputsDir, `cover_${Date.now()}.jpg`);
      fs.writeFileSync(coverPath, coverBuffer);
      this.localImagePaths.push(coverPath);
      console.log(`  ✅ 封面图已保存到: ${coverPath}`);
      
      // 上传封面图
      const coverMediaId = await this.uploadCoverImage(coverBuffer);
      
      return {
        localPath: coverPath,
        mediaId: coverMediaId,
        prompt: coverPrompt
      };
      
    } catch (error) {
      console.error('  ❌ 封面图生成失败:', error.message);
      // 使用备选方案
      return await this.generateFallbackCoverImage(articleAnalysis);
    }
  }

  /**
   * 生成文章相关内容插图
   */
  async generateArticleContentImages(articleAnalysis) {
    const { themes, keywords } = articleAnalysis;
    
    // 基于文章主题生成图片提示词
    const imagePrompts = this.generateImagePromptsFromThemes(themes, keywords);
    
    const imageResults = [];
    const imageCount = Math.min(imagePrompts.length, this.config.volcengine?.image_count || 3);
    
    for (let i = 0; i < imageCount; i++) {
      const { prompt, desc } = imagePrompts[i];
      
      try {
        console.log(`  ${i + 1}. 生成插图: ${desc}`);
        
        // 生成图片
        const imageBuffer = await this.generateImageWithVolcano(prompt, 'content');
        
        // 保存图片到本地
        const outputsDir = path.join(__dirname, 'outputs');
        const imagePath = path.join(outputsDir, `content_${Date.now()}_${i + 1}.jpg`);
        fs.writeFileSync(imagePath, imageBuffer);
        this.localImagePaths.push(imagePath);
        console.log(`    ✅ 图片已保存到: ${imagePath}`);
        
        // 上传到微信公众号
        const imageUrl = await this.uploadImageToWeChat(imageBuffer, `content_${i + 1}.jpg`);
        
        imageResults.push({
          index: i + 1,
          desc: desc,
          prompt: prompt,
          localPath: imagePath,
          url: imageUrl
        });
        
        // 等待避免API限制
        if (i < imageCount - 1) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
      } catch (error) {
        console.error(`    ❌ 插图${i + 1}生成失败:`, error.message);
        // 继续处理下一张图片
      }
    }
    
    console.log(`✅ 内容插图生成完成，共 ${imageResults.length} 张`);
    return imageResults;
  }

  /**
   * 根据文章主题生成图片提示词
   */
  generateImagePromptsFromThemes(themes, keywords) {
    const themePrompts = [];
    
    themes.forEach((theme, index) => {
      switch (theme) {
        case '亲子':
          themePrompts.push({
            prompt: `温馨亲子场景，父母和孩子一起户外探索，小孩在草地上奔跑玩耍，家人在自然中互动，阳光温暖，充满快乐和爱，${keywords.join('、')}，温馨插画风格，暖色调，情感丰富`,
            desc: '亲子时光：陪伴是最好的教育'
          });
          break;
        case '自然':
          themePrompts.push({
            prompt: `大自然户外场景，儿童游乐区，孩子们在滑梯和秋千上玩耍，旁边有开花的树和飘落的花瓣，阳光明媚，生机盎然，${keywords.join('、')}，清新插画风格，绿蓝暖色调，细节精致`,
            desc: '自然探索：户外的惊喜发现'
          });
          break;
        case '探索':
          themePrompts.push({
            prompt: `探索发现场景，一个家庭走进未知的小路，发现惊喜的美好景象，孩子眼睛发亮，充满好奇，${keywords.join('、')}，冒险插画风格，明亮色调，充满希望`,
            desc: '探索世界：走出去才能看到'
          });
          break;
        case '感悟':
          themePrompts.push({
            prompt: `深度思考与成长场景，一个人在户外反思，头脑中有想法的火花闪现，表现从经历中获得启发，${keywords.join('、')}，现代插画风格，蓝色金色主题，温暖而有力量`,
            desc: '生活感悟：经历是最好的老师'
          });
          break;
        case '职场':
          themePrompts.push({
            prompt: `职场场景，现代办公室环境，职业人士在工作，表现专业和成长，${keywords.join('、')}，现代商务插画风格，蓝色调，简洁大气`,
            desc: '职场成长：专业与发展的平衡'
          });
          break;
        case '事业':
          themePrompts.push({
            prompt: `创业或事业发展场景，表现自主创业和事业建设，${keywords.join('、')}，现代商务插画，金色和蓝色主题，充满希望和动力`,
            desc: '事业发展：自主创业与建设'
          });
          break;
        case '投资':
          themePrompts.push({
            prompt: `投资理财场景，表现财富增长和资产配置，${keywords.join('、')}，现代金融插画，绿色和金色主题，专业可靠`,
            desc: '投资理财：财富增长与配置'
          });
          break;
        case '科技':
          themePrompts.push({
            prompt: `科技与AI场景，表现技术创新和人工智能，${keywords.join('、')}，现代科技插画，紫色和蓝色主题，未来感强`,
            desc: '科技创新：AI与未来发展'
          });
          break;
        case '生活':
          themePrompts.push({
            prompt: `生活与人生场景，表现生活意义和人生价值，${keywords.join('、')}，现代生活插画，温暖色调，情感丰富`,
            desc: '生活意义：价值与平衡'
          });
          break;
        default:
          themePrompts.push({
            prompt: `思考与分享场景，表现深度思考和知识分享，${keywords.join('、')}，现代简约插画，中性色调，简洁清晰`,
            desc: '思考分享：深度与交流'
          });
      }
    });
    
    // 如果主题不够，补充通用提示词
    while (themePrompts.length < 3) {
      themePrompts.push({
        prompt: `深度思考场景，表现个人成长和价值实现，${keywords.join('、')}，现代简约插画，专业可靠`,
        desc: '深度思考：成长与实现'
      });
    }
    
    return themePrompts.slice(0, 4); // 最多4张
  }

  /**
   * 获取微信访问令牌
   */
  async getAccessToken() {
    const { appid, secret } = this.config.wechat;
    const url = `${this.config.api.wechat_token_url}?grant_type=client_credential&appid=${appid}&secret=${secret}`;
    
    try {
      console.log('🔑 获取微信访问令牌...');
      const response = await axios.get(url);
      
      if (response.data.errcode) {
        throw new Error(`微信API错误: ${response.data.errmsg}`);
      }
      
      this.accessToken = response.data.access_token;
      console.log(`✅ 访问令牌获取成功: ${this.accessToken.substring(0, 20)}...`);
      return this.accessToken;
    } catch (error) {
      console.error('❌ 获取微信访问令牌失败:', error.message);
      throw error;
    }
  }

  /**
   * 使用火山引擎API生成图片
   */
  async generateImageWithVolcano(prompt, imageType = 'content') {
    const { api_key, model_id, api_url, image_style, image_size } = this.config.volcengine;
    
    // 根据图片类型调整参数
    const size = imageType === 'cover' ? '1920x1920' : image_size;
    const style = imageType === 'cover' ? 
      '封面图设计，高吸引力，视觉冲击力强，现代商务风格，蓝色主题，简洁大气，适合微信公众号封面，高质量插画，4K画质' :
      '生动有趣，形象具体，情感丰富，场景丰富，细节精致，故事性强，现代插画风格，适合移动端阅读，4K画质';
    
    const fullPrompt = `${prompt}。${style}，尺寸：${size}，禁止水印，高质量插画，适合微信公众号文章使用。`;
    
    const requestBody = {
      model: model_id,
      prompt: fullPrompt,
      n: 1,
      size: size,
      response_format: "url",
      watermark: false
    };
    
    const headers = {
      'Authorization': `Bearer ${api_key}`,
      'Content-Type': 'application/json'
    };
    
    try {
      const response = await axios.post(api_url, requestBody, { headers });
      
      if (response.data.error) {
        throw new Error(`火山引擎API错误: ${response.data.error.message}`);
      }
      
      // 下载图片
      const imageUrl = response.data.data[0].url;
      const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      
      return Buffer.from(imageResponse.data);
    } catch (error) {
      console.error('❌ 图片生成失败:', error.message);
      throw error;
    }
  }

  /**
   * 上传图片到微信公众号
   */
  async uploadImageToWeChat(imageBuffer, filename = 'content.jpg') {
    const url = `https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=${this.accessToken}`;
    
    const form = new FormData();
    form.append('media', imageBuffer, {
      filename: filename,
      contentType: 'image/jpeg'
    });
    
    try {
      const response = await axios.post(url, form, {
        headers: form.getHeaders()
      });
      
      if (response.data.errcode) {
        throw new Error(`微信上传错误: ${response.data.errmsg}`);
      }
      
      return response.data.url;
    } catch (error) {
      console.error('❌ 图片上传失败:', error.message);
      throw error;
    }
  }

  /**
   * 上传封面图到微信公众号
   */
  async uploadCoverImage(imageBuffer) {
    const url = `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${this.accessToken}&type=image`;
    
    try {
      // 确保图片尺寸符合要求 (900x383)
      const resizedBuffer = await sharp(imageBuffer)
        .resize(900, 383, { fit: 'cover' })
        .jpeg({ quality: 95 })
        .toBuffer();
      
      const form = new FormData();
      form.append('media', resizedBuffer, {
        filename: `cover_${Date.now()}.jpg`,
        contentType: 'image/jpeg'
      });
      
      const response = await axios.post(url, form, {
        headers: form.getHeaders()
      });
      
      if (response.data.errcode) {
        throw new Error(`封面图上传错误: ${response.data.errmsg}`);
      }
      
      console.log(`✅ 封面图上传成功，media_id: ${response.data.media_id.substring(0, 20)}...`);
      return response.data.media_id;
    } catch (error) {
      console.error('❌ 封面图上传失败:', error.message);
      throw error;
    }
  }

  /**
   * 生成备选封面图
   */
  async generateFallbackCoverImage(articleAnalysis) {
    const { title, themes } = articleAnalysis;
    const themeText = themes.join('、');
    
    const fallbackBuffer = await sharp({
      create: {
        width: 900,
        height: 383,
        channels: 3,
        background: { r: 45, g: 100, b: 180 }
      }
    })
    .composite([
      {
        input: Buffer.from(`
          <svg width="900" height="383">
            <rect width="900" height="383" fill="#2d64b4"/>
            <text x="450" y="150" font-family="Arial" font-size="36" fill="white" text-anchor="middle" font-weight="bold">${title.substring(0, 20)}</text>
            <text x="450" y="200" font-family="Arial" font-size="24" fill="white" text-anchor="middle">${themeText}</text>
            <text x="450" y="280" font-family="Arial" font-size="18" fill="#e6e6e6" text-anchor="middle">微信公众号内容生成</text>
          </svg>
        `),
        top: 0,
        left: 0
      }
    ])
    .jpeg({ quality: 90 })
    .toBuffer();
    
    const outputsDir = path.join(__dirname, 'outputs');
    const fallbackPath = path.join(outputsDir, `cover_fallback_${Date.now()}.jpg`);
    fs.writeFileSync(fallbackPath, fallbackBuffer);
    this.localImagePaths.push(fallbackPath);
    
    const coverMediaId = await this.uploadCoverImage(fallbackBuffer);
    
    return {
      localPath: fallbackPath,
      mediaId: coverMediaId,
      prompt: '备选封面图'
    };
  }

  /**
   * 创建微信公众号草稿
   */
  async createWeChatDraft(title, content, thumbMediaId, summary) {
    const url = `https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${this.accessToken}`;
    
    const draftData = {
      articles: [
        {
          title: title,
          author: this.config.wechat.author,
          digest: summary || '深度思考，价值分享',
          content: content,
          content_source_url: "",
          thumb_media_id: thumbMediaId,
          show_cover_pic: 1,
          need_open_comment: 1,
          only_fans_can_comment: 0
        }
      ]
    };
    
    try {
      const response = await axios.post(url, draftData);
      
      if (response.data.errcode) {
        throw new Error(`草稿创建错误: ${response.data.errmsg}`);
      }
      
      console.log(`✅ 草稿创建成功，media_id: ${response.data.media_id}`);
      return response.data;
    } catch (error) {
      console.error('❌ 草稿创建失败:', error.message);
      throw error;
    }
  }

  /**
   * 格式化文章内容
   */
  formatArticleContent(articleContent, contentImages, articleAnalysis) {
    const lines = articleContent.split('\n').filter(line => line.trim().length > 0);
    
    let formattedContent = `
      <h1 style="text-align: center; color: #2d64b4; font-size: 28px; margin-bottom: 30px;">${articleAnalysis.title}</h1>
    `;
    
    // 添加文章内容
    lines.forEach((line, index) => {
      if (line.trim().length > 0) {
        const isImportant = line.includes('：') || line.includes('●') || line.includes('•') || line.includes('- ');
        const isQuote = line.includes('"') || line.includes('"') || line.includes('《') || line.includes('》');
        
        let style = "font-size: 16px; line-height: 1.8; color: #333;";
        
        if (isImportant) {
          style += " font-weight: bold; background-color: #f8f9fa; padding: 10px; border-radius: 6px; margin: 10px 0;";
        } else if (isQuote) {
          style += " font-style: italic; color: #666; border-left: 3px solid #4a90e2; padding-left: 15px; margin: 15px 0;";
        } else {
          style += " margin: 8px 0;";
        }
        
        formattedContent += `<p style="${style}">${line}</p>`;
        
        // 在关键位置插入图片
        if (index % 4 === 2 && contentImages.length > 0) {
          const imgIndex = Math.min(Math.floor(index / 4), contentImages.length - 1);
          const image = contentImages[imgIndex];
          
          formattedContent += `
            <div style="text-align: center; margin: 30px 0; padding: 15px; background-color: #f8fafc; border-radius: 8px;">
              <img src="${image.url}" alt="${image.desc}" style="max-width: 100%; border-radius: 6px; margin-bottom: 10px;" />
              <p style="color: #666; font-size: 14px; margin-top: 5px;">${image.desc}</p>
            </div>
          `;
        }
      }
    });
    
    // 添加总结部分
    formattedContent += `
      <div style="background-color: #2d64b4; color: white; padding: 25px; border-radius: 12px; margin: 40px 0; text-align: center;">
        <h3 style="margin: 0; font-size: 24px;">🎯 总结</h3>
        <p style="margin: 15px 0 0; font-size: 18px;">
          感谢阅读，希望本文对您有所启发。
        </p>
      </div>
      
      <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666; font-size: 14px;">
        <p>作者：${this.config.wechat.author}</p>
        <p>发布时间：${new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        <p style="color: #999;">主题：${articleAnalysis.themes.join('、')}</p>
      </div>
    `;
    
    return formattedContent;
  }

  /**
   * 保存处理结果
   */
  saveResult(articleContent, articleAnalysis, coverResult, contentImages, draftResult) {
    const result = {
      success: true,
      timestamp: new Date().toISOString(),
      article: {
        title: articleAnalysis.title,
        author: this.config.wechat.author,
        content: articleContent,
        wordCount: articleAnalysis.wordCount,
        themes: articleAnalysis.themes,
        keywords: articleAnalysis.keywords
      },
      draft: draftResult,
      images: {
        cover: coverResult,
        content: contentImages
      },
      localImagePaths: this.localImagePaths
    };
    
    // 保存结果到文件
    const outputsDir = path.join(__dirname, 'outputs');
    const resultPath = path.join(outputsDir, `publish_result_${Date.now()}.json`);
    fs.writeFileSync(resultPath, JSON.stringify(result, null, 2));
    
    console.log(`✅ 结果已保存到: ${resultPath}`);
    
    return result;
  }

  /**
   * 清理本地图片文件
   */
  cleanupLocalImages() {
    if (this.localImagePaths.length === 0) {
      return;
    }
    
    console.log('\n🧹 清理本地图片文件...');
    let deletedCount = 0;
    
    this.localImagePaths.forEach(imagePath => {
      try {
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
          console.log(`  ✅ 已删除: ${path.basename(imagePath)}`);
          deletedCount++;
        }
      } catch (error) {
        console.log(`  ⚠️  删除失败: ${path.basename(imagePath)} - ${error.message}`);
      }
    });
    
    console.log(`✅ 共清理 ${deletedCount} 个图片文件`);
    
    // 清空记录
    this.localImagePaths = [];
  }

  /**
   * 显示处理结果
   */
  displayResult(result) {
    console.log('📋 处理结果:');
    console.log(`- 文章标题: ${result.article.title}`);
    console.log(`- 文章作者: ${result.article.author}`);
    console.log(`- 文章字数: ${result.article.wordCount}`);
    console.log(`- 文章主题: ${result.article.themes.join('、')}`);
    console.log(`- 草稿ID: ${result.draft.media_id}`);
    console.log(`- 封面图: 已上传 (media_id: ${result.images.cover.mediaId})`);
    console.log(`- 内容图片: ${result.images.content.length} 张`);
    console.log(`- 发布时间: ${new Date(result.timestamp).toLocaleString()}`);
    console.log('='.repeat(70));
    console.log('💡 提示：文章已保存到微信公众号草稿箱，请登录公众号后台查看和发布。');
    console.log('🎨 所有图片均基于文章内容生成，无水印，高质量。');
  }
}

/**
 * 主函数 - 支持多种输入方式
 */
async function main() {
  try {
    // 检查命令行参数
    const args = process.argv.slice(2);
    let articleContent = '';
    
    if (args.length > 0) {
      // 方式1：从命令行参数读取
      articleContent = args.join(' ');
      console.log('📝 从命令行参数读取文章内容');
    } else if (!process.stdin.isTTY) {
      // 方式2：从管道或重定向读取
      const chunks = [];
      for await (const chunk of process.stdin) {
        chunks.push(chunk);
      }
      articleContent = Buffer.concat(chunks).toString('utf8').trim();
      console.log('📝 从标准输入读取文章内容');
    } else {
      // 方式3：交互式输入
      const readline = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
      });
      
      console.log('\n📝 请输入文章内容（输入完成后按Ctrl+D或输入END结束）：');
      console.log('='.repeat(70));
      
      articleContent = await new Promise((resolve) => {
        let content = '';
        readline.on('line', (line) => {
          if (line.trim() === 'END') {
            readline.close();
          } else {
            content += line + '\n';
          }
        });
        
        readline.on('close', () => {
          resolve(content.trim());
        });
      });
    }
    
    // 验证文章内容
    if (!articleContent || articleContent.trim().length === 0) {
      console.error('❌ 错误：文章内容不能为空');
      console.log('💡 使用方式:');
      console.log('   1. node main.js "文章内容"');
      console.log('   2. echo "文章内容" | node main.js');
      console.log('   3. node main.js (然后交互式输入)');
      process.exit(1);
    }
    
    // 处理文章
    const publisher = new WeChatContentGenerator();
    const result = await publisher.processArticle(articleContent);
    
    if (!result.success) {
      console.error('❌ 文章处理失败:', result.error);
      process.exit(1);
    }
    
  } catch (error) {
    console.error('❌ 程序执行失败:', error.message);
    process.exit(1);
  }
}

// 运行主函数
if (require.main === module) {
  main().catch(console.error);
}

module.exports = WeChatContentGenerator;