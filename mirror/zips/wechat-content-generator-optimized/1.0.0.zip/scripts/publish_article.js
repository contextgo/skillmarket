#!/usr/bin/env node

/**
 * 微信公众号文章发布脚本（修复兼容版）
 * 用于兼容旧版本的调用方式，使用修复后的逻辑
 */

const path = require('path');

// 加载主脚本类
const WeChatContentGenerator = require('../main.js');

async function publishArticle() {
  console.log('📱 微信公众号文章发布脚本（修复兼容版）');
  console.log('='.repeat(60));
  
  // 检查是否有命令行参数
  const args = process.argv.slice(2);
  let articleContent = '';
  
  if (args.length > 0) {
    // 从命令行参数读取文章内容
    articleContent = args.join(' ');
    console.log('📝 从命令行参数读取文章内容');
  } else if (!process.stdin.isTTY) {
    // 从管道读取
    const chunks = [];
    for await (const chunk of process.stdin) {
      chunks.push(chunk);
    }
    articleContent = Buffer.concat(chunks).toString('utf8').trim();
    console.log('📝 从标准输入读取文章内容');
  } else {
    // 显示使用说明
    console.log('❌ 错误：请提供文章内容');
    console.log('');
    console.log('💡 使用方式:');
    console.log('   1. node publish_article.js "文章内容"');
    console.log('   2. echo "文章内容" | node publish_article.js');
    console.log('   3. cat article.txt | node publish_article.js');
    console.log('');
    console.log('📝 文章内容预览:');
    console.log('今天和大家聊一下事业。大家是怎么理解事业的？我曾经问过一些朋友...');
    console.log('='.repeat(60));
    process.exit(1);
  }
  
  // 验证文章内容
  if (!articleContent || articleContent.trim().length === 0) {
    console.error('❌ 错误：文章内容不能为空');
    process.exit(1);
  }
  
  console.log('='.repeat(60));
  console.log('文章内容预览:');
  console.log(articleContent.substring(0, 150) + (articleContent.length > 150 ? '...' : ''));
  console.log('='.repeat(60));
  
  try {
    // 创建生成器实例
    const generator = new WeChatContentGenerator();
    
    // 处理文章
    const result = await generator.processArticle(articleContent);
    
    if (result.success) {
      console.log('\n🎉 文章发布成功！');
      process.exit(0);
    } else {
      console.error('\n❌ 文章发布失败:', result.error);
      process.exit(1);
    }
    
  } catch (error) {
    console.error('\n❌ 脚本执行失败:', error.message);
    process.exit(1);
  }
}

// 运行
if (require.main === module) {
  publishArticle().catch(console.error);
}