# 快速开始指南 - 微信公众号内容生成技能（优化版）

## 🚀 5分钟快速上手

### 步骤1：安装技能
```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 运行注册脚本
./register.sh
```

### 步骤2：配置API密钥
```bash
# 复制配置文件模板
cp configs/wechat_config_template.json configs/wechat_config.json

# 编辑配置文件
nano configs/wechat_config.json
```

**需要配置的API密钥：**
1. **微信公众平台**：
   - `appid`: 微信公众号AppID
   - `secret`: 微信公众号AppSecret
   - `author`: 公众号名称

2. **火山引擎**：
   - `api_key`: 火山引擎API密钥
   - 其他参数可使用默认值

### 步骤3：运行技能
```bash
# 方式1：直接运行主脚本
node main.js

# 方式2：通过OpenClaw运行
openclaw skill run wechat-content-generator-optimized

# 方式3：使用兼容脚本
node scripts/publish_article.js
```

### 步骤4：输入文章内容
运行脚本后，按照提示：
1. 输入文章内容（支持多行）
2. 输入完成后按 `Ctrl+D` 或输入 `END`
3. 等待脚本处理完成

## 📋 基本使用示例

### 示例1：发布新文章
```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 运行主脚本并输入文章
node main.js
```

### 示例2：使用命令行参数
```bash
# 直接传递文章内容
node main.js << 'EOF'
这里是文章内容
可以有多行
EOF
```

### 示例3：从文件读取文章
```bash
# 将文章保存到文件
echo "文章内容..." > article.txt

# 从文件读取并发布
node main.js < article.txt
```

## ⚙️ 配置详解

### 微信配置 (`wechat`)
```json
{
  "appid": "wx0e5b600b2bba4451",      // 微信公众号AppID
  "secret": "bdce19e749007b1d...",    // 微信公众号AppSecret
  "author": "视野 UP",                // 公众号名称
  "access_token": "",                 // 自动生成，无需填写
  "token_expire_time": 0              // 自动更新，无需填写
}
```

### 火山引擎配置 (`volcengine`)
```json
{
  "api_key": "ark-db68f31c-7db1-49c6...",  // 火山引擎API密钥
  "model_id": "doubao-seedream-4-5-251128", // 模型ID
  "api_url": "https://ark.cn-beijing.volces.com/api/v3/images/generations",
  "image_count": 4,                        // 生成图片数量
  "image_style": "生动有趣，形象具体...",   // 图片风格
  "image_size": "1920x1920"                // 图片尺寸
}
```

## 🔧 常见问题

### Q1：如何获取微信API密钥？
1. 登录[微信公众平台](https://mp.weixin.qq.com)
2. 进入「开发」-「基本配置」
3. 获取AppID和AppSecret

### Q2：如何获取火山引擎API密钥？
1. 登录[火山引擎控制台](https://console.volcengine.com)
2. 进入「人工智能」-「图像生成」
3. 创建API密钥

### Q3：图片生成失败怎么办？
1. 检查火山引擎API密钥是否正确
2. 检查网络连接
3. 查看错误信息，调整提示词

### Q4：微信发布失败怎么办？
1. 检查微信API密钥是否正确
2. 确认公众号有素材管理权限
3. 检查网络连接

## 📊 输出说明

### 成功输出
```
🎉 文章发布成功！
📋 处理结果:
- 文章标题: xxx
- 文章作者: xxx
- 草稿ID: LAAldbDbFEQWeC8XL5dUi...
- 内容图片: 4张
- 发布时间: 2026-04-25 08:20:07
💡 提示：文章已保存到微信公众号草稿箱
```

### 生成的文件
```
outputs/
├── cover_optimized.jpg          # 封面图
├── content_image_1.jpg          # 内容插图1
├── content_image_2.jpg          # 内容插图2
├── content_image_3.jpg          # 内容插图3
├── content_image_4.jpg          # 内容插图4
└── publish_result_*.json        # 发布结果文件
```

## 🎯 高级功能

### 自定义图片提示词
编辑 `main.js` 中的 `generateOptimizedContentImages` 函数，修改图片提示词。

### 调整图片数量
修改 `configs/wechat_config.json` 中的 `image_count` 参数。

### 自定义文章格式
编辑 `main.js` 中的 `formatArticleContent` 函数，调整HTML格式。

## 📞 技术支持

遇到问题？请：
1. 查看错误信息
2. 检查配置文件
3. 参考本文档
4. 如无法解决，可联系技术支持

---

**提示**：本技能已优化，开箱即用。建议先使用示例文章测试，确认功能正常后再发布正式内容。