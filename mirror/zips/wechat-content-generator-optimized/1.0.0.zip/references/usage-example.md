# 使用示例 - 微信公众号内容生成技能（优化版）

## 📝 示例1：基础使用

### 场景：发布一篇关于职场智慧的文章

```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 运行主脚本
node main.js
```

**输入文章内容：**
```
年轻时，遇到点不如意的事，心里不爽，就忍不住想表达出来，一吐为快，心里确实舒服多了。
但代价也挺大的，不仅得罪了人，还伤了关系。甚至亲人、同事、朋友、客户之间的。
吃了很多闭门羹，受到了很多次的教训。
才明白：真正的绝交，是不动声色地退出，而不是大闹一场。
不管对方说什么、耍什么心眼，玩什么手段。始终面带微笑，静静的看着就好，没必要去争执，没必要生一肚子火，更没必要大吵一场。
觉得对方不适合交往，就默默退出就行，没必要闹得不可开交。
就像有句职场话讲的：做人留一线，日后好想见。
有些时候圈子挺小的，风水轮流转，说不定有一天，就碰着，需要对方帮忙呢。
厉害的人的最顶级的智慧就是这样：表面不翻脸，内心说再见
觉得不适合交往，就默默撤退就好了，后面就不联系了。
有些人觉得，这是一种软弱，觉得自己在气势上输给了别人，
其实并不是，反而是一种智慧。
如果你非得大脑一场，首先你的心情会受到影响，长期都在气愤的状态，这将消耗你的精力和时间；其次也会影响到你身体各个器官和机能，有的人就是一天到晚生各种气，结果抑郁而终。
另外你在气愤状态，你也没心思去做重要的事情了，就算你本来打算就休息的，结果哪有心情休息。
所以觉得对方不适合交往，就好聚好散，后面不相往来就好，如果关系在那，无法完全断掉，那就减少来往就好了。
最后，祝大家都能养成这种顶级的智慧：表面不翻脸，内心说再见。
```

**输出结果：**
```
🚀 微信公众号内容生成器（优化版）
======================================================================
🔑 获取微信访问令牌...
✅ 访问令牌获取成功: 103_ABSGpcGqs15mlEOk...

🎨 1. 生成优化封面图...
  生成封面图...
✅ 封面图上传成功，media_id: LAAldbDbFEQWeC8XL5dU...

🎨 2. 生成优化内容插图...
  1. 生成插图: 优雅转身：平静微笑中的坚定决心
  2. 生成插图: 保持冷静：在风暴中心保持平静
  3. 生成插图: 智慧告别：相互尊重中的重新出发
  4. 生成插图: 情绪管理：从愤怒到平静的智慧转变
✅ 内容插图生成完成，共 4 张

📝 3. 格式化文章内容...

📄 4. 创建微信公众号草稿...
✅ 草稿创建成功，media_id: LAAldbDbFEQWeC8XL5dUilMk7iqffGKLOVTU1ZB8tN4A1lKXO8QeyE2D0zEqjSGp

✅ 结果已保存到: /path/to/outputs/publish_result_1777076407110.json

======================================================================
🎉 文章发布成功！
======================================================================
📋 处理结果:
- 文章标题: 智慧：年轻时，遇到点不如意的事...
- 文章作者: 视野 UP
- 文章字数: 586
- 草稿ID: LAAldbDbFEQWeC8XL5dUilMk7iqffGKLOVTU1ZB8tN4A1lKXO8QeyE2D0zEqjSGp
- 封面图: 已上传 (media_id: LAAldbDbFEQWeC8XL5dUiu8EGPYGeg1KvEXaryL80Higf45F_vZW3AJhMGQIkGxI)
- 内容图片: 4 张
- 发布时间: 2026-04-25 08:20:07
======================================================================
💡 提示：文章已保存到微信公众号草稿箱，请登录公众号后台查看和发布。
🎨 所有图片均由火山引擎Seedream API生成，无水印，高质量。
======================================================================
```

## 📝 示例2：使用OpenClaw调用

### 场景：通过OpenClaw技能系统调用

```bash
# 注册技能（首次使用）
openclaw skill register ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 运行技能
openclaw skill run wechat-content-generator-optimized
```

**交互过程：**
```
📱 微信公众号内容生成技能（优化版）
========================================
📝 请输入文章内容（输入完成后按Ctrl+D或输入END结束）：
========================================
（输入文章内容...）
（按Ctrl+D结束输入）
...
```

## 📝 示例3：批量处理文章

### 场景：从多个文件发布文章

```bash
#!/bin/bash
# batch_publish.sh

# 文章文件列表
ARTICLES=(
  "article1.txt"
  "article2.txt"
  "article3.txt"
)

# 技能目录
SKILL_DIR="~/openclaw/workspace/skills/wechat-content-generator-optimized"

for article_file in "${ARTICLES[@]}"; do
  echo "📝 处理文章: $article_file"
  
  # 从文件读取文章内容并发布
  node "$SKILL_DIR/main.js" < "$article_file"
  
  if [ $? -eq 0 ]; then
    echo "✅ $article_file 发布成功"
  else
    echo "❌ $article_file 发布失败"
  fi
  
  echo ""
done

echo "🎉 批量处理完成"
```

## 📝 示例4：自定义配置

### 场景：调整图片生成参数

**修改 `configs/wechat_config.json`：**
```json
{
  "volcengine": {
    "api_key": "your-api-key",
    "model_id": "doubao-seedream-4-5-251128",
    "image_count": 3,  // 减少图片数量
    "image_style": "简约现代风格，商务感强，适合职场文章",
    "image_size": "1200x1200"  // 调整图片尺寸
  }
}
```

**运行结果：**
- 生成3张图片（原为4张）
- 图片风格调整为简约现代
- 图片尺寸调整为1200x1200

## 📝 示例5：错误处理场景

### 场景：API密钥错误

```bash
node main.js
```

**错误输出：**
```
❌ 配置文件读取失败: Unexpected token Y in JSON at position 0
💡 请确保已正确配置 configs/wechat_config.json 文件
```

**解决方案：**
1. 检查配置文件格式
2. 确保JSON格式正确
3. 重新配置API密钥

### 场景：网络连接问题

```bash
node main.js
```

**错误输出：**
```
❌ 获取微信访问令牌失败: connect ECONNREFUSED 127.0.0.1:443
```

**解决方案：**
1. 检查网络连接
2. 确认API服务可用
3. 检查防火墙设置

## 📝 示例6：结果文件解析

### 生成的JSON结果文件示例

**文件：`outputs/publish_result_1777076407110.json`**
```json
{
  "success": true,
  "timestamp": "2026-04-25T00:20:07.110Z",
  "article": {
    "title": "智慧：年轻时，遇到点不如意的事...",
    "author": "视野 UP",
    "content": "年轻时，遇到点不如意的事...",
    "wordCount": 586
  },
  "draft": {
    "media_id": "LAAldbDbFEQWeC8XL5dUilMk7iqffGKLOVTU1ZB8tN4A1lKXO8QeyE2D0zEqjSGp",
    "item": [
      {
        "index": 0,
        "ad_count": 1
      }
    ]
  },
  "images": {
    "cover": {
      "localPath": "/path/to/cover_optimized.jpg",
      "mediaId": "LAAldbDbFEQWeC8XL5dUiu8EGPYGeg1KvEXaryL80Higf45F_vZW3AJhMGQIkGxI"
    },
    "content": [
      {
        "index": 1,
        "desc": "优雅转身：平静微笑中的坚定决心",
        "prompt": "一个优雅的职业人士在办公室中转身离开...",
        "localPath": "/path/to/content_image_1.jpg",
        "url": "http://mmbiz.qpic.cn/..."
      },
      // ... 更多图片
    ]
  }
}
```

**使用结果文件：**
```bash
# 查看结果
cat outputs/publish_result_*.json | jq .

# 获取草稿ID
cat outputs/publish_result_*.json | jq -r '.draft.media_id'

# 统计处理结果
cat outputs/publish_result_*.json | jq '.images.content | length'
```

## 🎯 最佳实践建议

### 1. 测试环境验证
```bash
# 使用示例文章测试
echo "测试文章内容" | node main.js
```

### 2. 逐步调试
```bash
# 先测试配置
node -e "console.log(require('./configs/wechat_config.json').wechat.appid)"

# 再测试API连接
node -e "const axios = require('axios'); axios.get('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=YOUR_APPID&secret=YOUR_SECRET').then(res => console.log('✅ API连接正常')).catch(err => console.log('❌ API连接失败'))"
```

### 3. 监控日志
```bash
# 查看详细日志
DEBUG=* node main.js

# 保存日志到文件
node main.js 2>&1 | tee publish.log
```

### 4. 定期清理
```bash
# 清理旧的输出文件
find outputs/ -name "*.json" -mtime +7 -delete
find outputs/ -name "*.jpg" -mtime +7 -delete
```

---

**提示**：建议先在小流量环境下测试，确认功能正常后再进行正式发布。所有图片生成和API调用都可能产生费用，请注意监控使用量。