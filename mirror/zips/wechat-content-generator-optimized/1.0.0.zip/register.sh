#!/bin/bash

# 微信公众号内容生成技能注册脚本（优化版）

set -e

echo "🔧 开始注册微信公众号内容生成技能（优化版）..."
echo "=========================================================="

# 检查是否在OpenClaw环境中
if ! command -v openclaw &> /dev/null; then
    echo "❌ 错误：未找到 openclaw 命令"
    echo "请确保已安装OpenClaw并正确配置环境"
    exit 1
fi

# 获取技能目录
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "📁 技能目录: $SKILL_DIR"

# 检查必要文件
if [ ! -f "$SKILL_DIR/SKILL.md" ]; then
    echo "❌ 错误：缺少 SKILL.md 文件"
    exit 1
fi

if [ ! -f "$SKILL_DIR/skillhub.json" ]; then
    echo "❌ 错误：缺少 skillhub.json 文件"
    exit 1
fi

# 检查配置目录
if [ ! -d "$SKILL_DIR/configs" ]; then
    echo "📁 创建配置目录..."
    mkdir -p "$SKILL_DIR/configs"
fi

# 检查配置文件
if [ ! -f "$SKILL_DIR/configs/wechat_config.json" ]; then
    echo "⚠️  警告：未找到配置文件 wechat_config.json"
    echo "请先创建配置文件："
    echo "1. 复制模板文件："
    echo "   cp $SKILL_DIR/configs/wechat_config_template.json $SKILL_DIR/configs/wechat_config.json"
    echo "2. 编辑配置文件，填写您的API密钥"
    echo ""
    echo "是否需要创建配置文件模板？(y/n)"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        if [ -f "$SKILL_DIR/configs/wechat_config_template.json" ]; then
            cp "$SKILL_DIR/configs/wechat_config_template.json" "$SKILL_DIR/configs/wechat_config.json"
            echo "✅ 已创建配置文件模板"
            echo "请编辑 $SKILL_DIR/configs/wechat_config.json 填写您的API密钥"
        else
            echo "❌ 错误：未找到配置文件模板"
        fi
    fi
fi

# 检查依赖
echo "📦 检查依赖..."
if [ ! -d "$SKILL_DIR/node_modules" ]; then
    echo "📦 安装依赖..."
    cd "$SKILL_DIR"
    npm install
else
    echo "✅ 依赖已安装"
fi

# 注册技能
echo "📝 注册技能到OpenClaw..."
openclaw skill register "$SKILL_DIR"

if [ $? -eq 0 ]; then
    echo "🎉 技能注册成功！"
    echo "=========================================================="
    echo "📋 使用说明："
    echo "1. 配置API密钥："
    echo "   编辑 $SKILL_DIR/configs/wechat_config.json"
    echo "2. 运行技能："
    echo "   openclaw skill run wechat-content-generator-optimized"
    echo "3. 或直接运行："
    echo "   cd $SKILL_DIR && node main.js"
    echo ""
    echo "💡 提示：请确保已正确配置微信和火山引擎的API密钥"
    echo "=========================================================="
else
    echo "❌ 技能注册失败"
    exit 1
fi