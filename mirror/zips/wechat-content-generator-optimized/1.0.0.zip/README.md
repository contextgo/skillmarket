# wechat-content-generator-optimized

基于实际使用经验优化的微信公众号内容全流程生成技能。

## 功能特点
- 🚀 完整公众号内容发布流程
- 🎨 火山引擎API图片生成
- 📱 微信API集成
- 🧹 自动清理本地文件
- 🔧 配置简单，开箱即用

## 安装
```bash
openclaw skill install /path/to/wechat-content-generator-optimized-v2.0.0.zip
```

## 配置
编辑 `configs/wechat_config.json` 文件：
```json
{
  "wechat": {
    "appid": "YOUR_APPID",
    "secret": "YOUR_SECRET"
  },
  "volcengine": {
    "api_key": "YOUR_API_KEY"
  }
}
```

## 使用
```bash
cd ~/.openclaw/workspace/skills/wechat-content-generator-optimized
node main.js
```

## 许可证
MIT
