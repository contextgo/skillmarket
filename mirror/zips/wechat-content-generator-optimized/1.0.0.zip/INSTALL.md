# 微信公众号内容生成技能安装指南

## 📦 安装方式

### 方式一：通过 OpenClaw 技能管理器安装（推荐）
```bash
# 1. 将技能文件上传到 OpenClaw 服务器
# 2. 运行安装命令
openclaw skill install /path/to/${SKILL_NAME}-v${SKILL_VERSION}.zip
```

### 方式二：手动安装
```bash
# 1. 解压技能包
unzip ${SKILL_NAME}-v${SKILL_VERSION}.zip -d ~/.openclaw/workspace/skills/

# 2. 进入技能目录
cd ~/.openclaw/workspace/skills/${SKILL_NAME}

# 3. 安装依赖
npm install

# 4. 配置微信API
# 复制配置模板并编辑
cp configs/wechat_config_template.json configs/wechat_config.json
# 编辑 configs/wechat_config.json 文件，填写您的微信API密钥和火山引擎API密钥
```

### 方式三：通过 register.sh 脚本注册
```bash
# 1. 解压并进入技能目录后
chmod +x register.sh
./register.sh
```

## ⚙️ 配置要求

### 必要条件
1. Node.js 16+ 环境
2. 微信公众号开发权限（AppID 和 AppSecret）
3. 火山引擎 API 密钥

### 配置文件
编辑 `configs/wechat_config.json` 文件：
```json
{
  "wechat": {
    "appid": "YOUR_WECHAT_APPID",
    "secret": "YOUR_WECHAT_SECRET",
    "author": "您的公众号名称"
  },
  "volcengine": {
    "api_key": "YOUR_VOLCENGINE_API_KEY",
    "model_id": "doubao-seedream-4-5-251128",
    "api_url": "https://ark.cn-beijing.volces.com/api/v3/images/generations",
    "image_count": 4,
    "image_style": "生动有趣，形象具体，无灰色背景，无水印，高质量插画，4K画质",
    "image_size": "1920x1920"
  }
}
```

## 🚀 使用方式

### 基础使用
```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/${SKILL_NAME}

# 运行技能
node main.js
```

### 通过 OpenClaw 调用
```bash
# 注册技能后
openclaw skill run ${SKILL_NAME}
```

## 🔧 验证安装

运行以下命令验证安装是否成功：
```bash
cd ~/.openclaw/workspace/skills/${SKILL_NAME}
node -e "console.log('✅ Skill environment check passed')"
```

## 📞 技术支持

1. 查看 `SKILL.md` 获取详细使用说明
2. 参考 `references/` 目录中的文档
3. 确保所有配置文件已正确填写

## 📊 技能特点

✅ **智能图片生成**：基于实际文章内容生成相关图片  
✅ **自动清理**：发布后自动清理本地图片文件  
✅ **多种输入方式**：支持命令行参数、管道输入、交互式输入  
✅ **图片质量**：使用火山引擎API生成高质量无水印图片  
✅ **代码简洁**：移除所有测试和冗余代码  
✅ **稳定可靠**：经过实际验证的完整发布流程  
✅ **易用性强**：开箱即用，配置简单
