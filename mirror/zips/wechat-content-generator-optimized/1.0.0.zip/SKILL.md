# 微信公众号内容生成技能（优化版） - wechat-content-generator

## 🎯 技能描述
基于实际使用经验优化的微信公众号内容全流程生成技能。能够将普通文章内容自动转化为高质量的公众号推文，包含**火山引擎API图片生成**、**微信API集成**、**专业排版**等功能。

## ✨ 核心优化特点
✅ **智能图片生成**：基于实际文章内容生成相关图片，非固定测试内容  
✅ **自动清理**：发布后自动清理本地图片文件，保持整洁  
✅ **多种输入方式**：支持命令行参数、管道输入、交互式输入  
✅ **图片质量**：使用火山引擎API生成高质量无水印图片  
✅ **代码简洁**：移除所有测试和冗余代码  
✅ **稳定可靠**：经过实际验证的完整发布流程  
✅ **易用性强**：开箱即用，配置简单  

## 📁 文件结构（优化后）
```
wechat-content-generator-optimized/
├── SKILL.md                    # 技能说明文档（本文档）
├── skillhub.json              # 技能注册配置
├── register.sh                # 注册脚本
├── package.json               # 依赖配置
├── main.js                    # 主执行脚本（优化版）
├── configs/                   # 配置文件目录
│   ├── wechat_config.json     # 微信API配置
│   └── wechat_config_template.json # 配置模板
├── scripts/                   # 辅助脚本目录
│   ├── publish_article.js     # 发布脚本（兼容旧版本）
│   └── package.json          # scripts依赖配置
├── references/               # 参考文档
│   ├── quick-start.md       # 快速开始指南
│   └── usage-example.md    # 使用示例
└── outputs/                 # 输出目录（运行时生成）
    └── publish_result_*.json # 发布结果文件
```

## ⚙️ 配置说明
### 配置文件位置
`~/.openclaw/workspace/skills/wechat-content-generator-optimized/configs/wechat_config.json`

### 配置内容（示例）
```json
{
  "wechat": {
    "appid": "YOUR_WECHAT_APPID",
    "secret": "YOUR_WECHAT_SECRET",
    "author": "您的公众号名称"
  },
  "volcengine": {
    "api_key": "YOUR_VOLCENGINE_API_KEY",
    "model_id": "doubao-seedream-4-5-251128",
    "api_url": "https://ark.cn-beijing.volces.com/api/v3/images/generations",
    "image_count": 4,
    "image_style": "生动有趣，形象具体，无灰色背景，无水印，高质量插画，4K画质",
    "image_size": "1920x1920"
  },
  "content": {
    "max_title_candidates": 5,
    "summary_length": 50,
    "format_options": {
      "enable_bold": true,
      "enable_color": true,
      "enable_paragraph": true,
      "default_font_size": 16,
      "highlight_color": "#FF6B35"
    }
  },
  "api": {
    "wechat_token_url": "https://api.weixin.qq.com/cgi-bin/token",
    "wechat_upload_url": "https://api.weixin.qq.com/cgi-bin/media/upload",
    "wechat_draft_url": "https://api.weixin.qq.com/cgi-bin/draft/add"
  }
}
```

## 🚀 使用方式

### 1. 基础使用（推荐）
```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 运行主脚本（会提示输入文章内容）
node main.js
```

### 2. 通过OpenClaw调用
```bash
# 先注册技能
openclaw skill register ~/.openclaw/workspace/skills/wechat-content-generator-optimized

# 然后运行
openclaw skill run wechat-content-generator-optimized
```

### 3. 直接处理文章
```bash
# 编辑main.js中的articleContent变量
# 然后运行脚本
node main.js
```

## 🔧 工作流程
1. **读取输入**：获取文章内容
2. **生成图片**：调用火山引擎API生成4张高质量插图
3. **上传图片**：上传图片到微信公众号
4. **格式化内容**：将文章转为微信公众号富文本格式
5. **创建草稿**：调用微信API创建草稿
6. **保存结果**：生成发布结果文件

## 📊 输出结果
发布成功后，会生成一个JSON格式的结果文件，包含：
```json
{
  "success": true,
  "timestamp": "2026-04-25T00:20:07.110Z",
  "article": {
    "title": "文章标题",
    "author": "公众号名称",
    "content": "文章内容...",
    "wordCount": 586
  },
  "draft": {
    "media_id": "LAAldbDbFEQWeC8XL5dUilMk7iqffGKLOVTU1ZB8tN4A1lKXO8QeyE2D0zEqjSGp"
  },
  "images": {
    "cover": {
      "localPath": "/path/to/cover.jpg",
      "mediaId": "LAAldbDbFEQWeC8XL5dUiu8EGPYGeg1KvEXaryL80Higf45F_vZW3AJhMGQIkGxI"
    },
    "content": [
      {
        "index": 1,
        "desc": "图片描述",
        "prompt": "AI提示词",
        "localPath": "/path/to/image1.jpg",
        "url": "http://mmbiz.qpic.cn/..."
      }
    ]
  }
}
```

## 🎨 图片生成优化
本技能包含**深度优化的图片提示词**，能够生成：
- **封面图**：设计概念性封面，视觉冲击力强
- **内容插图**：4张高质量插图，情感表达丰富
- **优化特点**：光影效果、象征元素、场景细节、色彩对比

## 📦 依赖项
- Node.js 16+
- axios (HTTP请求)
- form-data (文件上传)
- sharp (图片处理)
- 微信公众号开发权限
- 火山引擎API密钥

## 🛡️ 错误处理
- ✅ API调用失败时提供详细错误信息
- ✅ 图片上传失败时自动重试
- ✅ 配置缺失时提供明确的错误提示
- ✅ 自动创建必要的目录结构

## 🔄 更新日志
### v2.1 (2026-04-25) - 修复版
- ✅ **修复逻辑问题**：图片生成基于实际文章内容，而非测试文章
- ✅ **移除测试文章**：完全删除默认测试文章内容
- ✅ **添加清理功能**：发布后自动清理本地图片文件
- ✅ **支持多种输入**：命令行参数、管道输入、交互式输入
- ✅ **智能图片生成**：根据文章主题和关键词生成相关图片

### v2.0 (2026-04-25) - 优化版
- ✅ 基于实际使用经验全面优化
- ✅ 移除所有测试和冗余代码
- ✅ 深度优化图片提示词，更具吸引力
- ✅ 简化文件结构，易于使用
- ✅ 验证完整的发布流程
- ✅ 保留所有核心功能

### v1.0 (2026-04-24) - 基础版
- 基础功能实现
- 微信公众号API集成
- 图片上传功能
- 草稿发布功能

## 📞 技术支持
如有问题，请参考：
1. `references/quick-start.md` - 快速开始指南
2. `references/usage-example.md` - 使用示例
3. 检查配置文件是否正确
4. 确保API密钥有效

---

**注意**：本技能已移除所有测试内容和冗余代码，专注于核心功能，开箱即用，稳定可靠。