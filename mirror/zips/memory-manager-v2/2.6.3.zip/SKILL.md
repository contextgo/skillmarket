---
name: "记忆管家"
description: >
  AI加速器 V2.6.1，智能管理记忆与文件，减少Token消耗，支持差异化自动清理（推送类次日清理，个人/工作类每5天提醒）。
  新增：内容哈希去重、Token消耗趋势、本地文件夹同步备份、定时任务管理、doctor诊断、wizard向导、feedback反馈。
  V2.6.3新增：函数层面强制confirm参数，静态分析更安全。V2.6.2新增：归档/向导操作需用户确认。V2.6.1修复：manifest异常处理、分块读取大文件、scan_workspace性能优化（os.scandir）。
  This skill should be used when users want to manage memories, reduce token consumption,
  summarize memory files, rank memory importance, smart load memories, search memories,
  clean up workspace files, optimize memory usage, auto-clean old logs, deduplicate files,
  view token trends, backup memories, diagnose problems, setup wizard, provide feedback,
  or ask about memory/file status.
  触发词：记忆管家、清理缓存、省token、记忆总结、减少消耗、内存优化、文件清理、扫描存储、存储报告、优化记忆、效率加速、Token管理、减少Token、记忆分析、扫描工作空间、清理预览、空目录清理、记忆归档、HTML报告、摘要生成、记忆分级、智能加载、记忆搜索、自动清理、超期删除、差异化清理、去重、备份、统计、定时、诊断、向导、反馈
---

# 记忆管家 V2.6 - AI加速器

🧠 **让AI更懂你，更快回应，更省Token**

智能管理记忆与文件，减少Token消耗，支持定时自动清理超期日志，新增去重、统计、备份、定时任务、诊断向导功能。

---

## ✨ V2.6 核心升级

| 维度 | V2.5 | V2.6 | 提升 |
:|------|------|------|------|
| 🔍 诊断工具 | ❌ | **✅** | 一键检测配置异常和潜在问题 |
| 🧙 设置向导 | ❌ | **✅** | 引导首次配置和路径设置 |
| 💬 用户反馈 | ❌ | **✅** | 收集使用问题和建议 |
| 🐛 Bug修复 | - | **✅** | 修复hashlib导入、进度条等 |

---

## ✨ V2.5 核心升级

| 维度 | V2.4 | V2.5 | 提升 |
:|------|------|------|------|
| 🔍 去重 | ❌ | **✅** | 基于内容哈希智能去重 |
| 📊 Token统计 | ❌ | **✅** | 消耗趋势可视化 |
| 💾 备份 | ❌ | **✅** | 本地文件夹同步备份 |
| ⏰ 定时任务 | ❌ | **✅** | 定时执行整理任务 |

| 维度 | V2.3 | V2.4 | 提升 |
:|------|------|------|------|
| 🧹 清理策略 | 统一按时间 | **差异化分类** | 推送类次日清，个人/工作每5天提醒 |
| 🔔 提醒机制 | 统一提醒 | **按类型提醒** | 个人/工作类到期才提醒，不打扰 |
| 📊 清理汇总 | 无 | **三类分别统计** | 推送/个人工作/其他清晰分开 |
| ⚙️ 过滤支持 | ❌ | **✅** | 支持按内容类型过滤清理范围 |

| 维度 | V2.2 | V2.3 | 提升 |
:|------|------|------|------|
| ⚙️ 配置管理 | ❌ | **✅** | 可自定义保留天数/提醒频率 |
| 🧹 自动清理 | ❌ | **✅** | 超期日志自动归档，释放空间 |
| 🔔 定时集成 | ❌ | **✅** | 可集成定时任务，每N天执行 |
| 📊 Token节省 | 50-80% | **50-80%** | 维持高效 |

---

## 🚀 核心功能（共18个）

### 基础功能（V2.1）
1. **记忆分析** (`analyze`) - 分析记忆文件状态
2. **工作空间扫描** (`scan`) - 扫描.workbuddy目录
3. **清理预览** (`preview`) - Dry Run模式
4. **智能清理** (`clean`) - 预览确认执行
5. **记忆归档** (`archive`) - 压缩后移动

### 升级功能（V2.2）
6. **摘要生成** (`summarize`) - 一键生成所有记忆摘要
7. **重要性分级** (`rank`) - 自动分核心/普通/冷门
8. **智能加载** (`load`) - 按分级加载，节省TOKEN
9. **记忆搜索** (`search`) - 关键词快速搜索
10. **HTML报告** (`html`) - 可视化图表展示

### 新增功能（V2.3）
11. **配置管理** (`config`) - 查看/修改保留策略
12. **自动清理** (`auto-clean`) - 定时归档超期日志

### 新增功能（V2.4）
13. **差异化清理** - 推送类次日自动清，个人/工作类每5天提醒
14. **内容过滤** (`--content`) - 按内容类型过滤清理范围

### 新增功能（V2.5）⭐⭐⭐
15. **内容去重** (`dedup`) - 基于内容哈希智能去重
16. **Token统计** (`stats`) - 消耗趋势可视化
17. **备份同步** (`backup`) - 本地文件夹增量备份
18. **定时任务** (`schedule`) - 定时执行整理任务

### 新增功能（V2.6）🆕
19. **诊断工具** (`doctor`) - 一键检测配置异常和潜在问题
20. **设置向导** (`wizard`) - 引导首次配置和路径设置
21. **用户反馈** (`feedback`) - 收集使用问题和建议

---

## 💰 TOKEN节省原理

```
传统方式（全量加载）:
记忆文件: 10个 × 5KB = 50KB → ~12500 TOKEN

V2.2方式（智能加载）:
├── 核心记忆(10%) × 5KB = 5KB → ~1250 TOKEN
├── 普通记忆(30%) × 摘要500字 = 1.5KB → ~375 TOKEN
└── 冷门记忆(60%) × 压缩归档 = 1KB → ~250 TOKEN
总计: ~1875 TOKEN (节省85%)
```

---

## 💻 CLI 使用指南

### 基础命令

```bash
# 分析记忆状态
memory_manager.py analyze

# 扫描工作空间
memory_manager.py scan

# 执行清理
memory_manager.py clean --force
```

### V2.3/V2.4 命令速查

```bash
# === 摘要与分级 ===
# 生成所有记忆摘要
memory_manager.py summarize

# 指定文件生成摘要
memory_manager.py summarize --file 2026-04-26.md

# 重新生成摘要
memory_manager.py summarize --regenerate

# 记忆重要性分级
memory_manager.py rank

# 智能加载（默认normal模式）
memory_manager.py load

# 只加载摘要（最省TOKEN）
memory_manager.py load --mode brief

# 加载相关记忆
memory_manager.py load --mode normal --keyword 绿舜生态 --limit 5

# 搜索记忆
memory_manager.py search -k 绿舜生态

# 搜索并显示详细内容
memory_manager.py search -k 绿舜生态 --mode normal
```

### V2.4 差异化自动清理

```bash
# 1. 查看当前配置（包含差异化规则）
memory_manager.py config

# 2. 差异化自动清理预览（推送次日清，个人/工作到期提醒）
memory_manager.py auto-clean

# 3. 执行差异化自动清理
memory_manager.py auto-clean --execute

# 4. 只清理推送类内容
memory_manager.py auto-clean --content push --execute
```

### V2.6 新增命令 🆕

```bash
# === 诊断工具 ===
# 一键检测配置异常和潜在问题
memory_manager.py doctor

# === 设置向导 ===
# 执行首次设置（完整）
memory_manager.py wizard

# 只执行特定步骤
memory_manager.py wizard --step memory
memory_manager.py wizard --step config
memory_manager.py wizard --step summarize

# === 用户反馈 ===
# 提交问题反馈
memory_manager.py feedback --type bug --content "发现一个问题"

# 提交功能建议
memory_manager.py feedback --type feature --content "建议添加云备份功能"
```

### V2.5 新增命令 ⭐⭐⭐

```bash
# === 内容去重 ===
# 预览重复文件
memory_manager.py dedup

# 执行去重（删除重复文件）
memory_manager.py dedup --execute

# === Token消耗统计 ===
# 查看最近7天趋势
memory_manager.py stats --days 7

# 查看最近30天趋势
memory_manager.py stats --days 30

# === 本地备份 ===
# 预览备份到本地文件夹
memory_manager.py backup --path "D:\记忆备份"

# 执行备份
memory_manager.py backup --path "D:\记忆备份" --execute

# 从备份恢复（预览）
memory_manager.py backup --path "D:\记忆备份" --restore

# 执行恢复
memory_manager.py backup --path "D:\记忆备份" --restore --execute

# === 定时任务 ===
# 查看定时任务状态
memory_manager.py schedule --check

# 设置每日自动清理（18:00执行）
memory_manager.py schedule --task auto_clean --enable --schedule daily --time 18:00

# 设置每周自动去重
memory_manager.py schedule --task dedup --enable --schedule weekly --day monday --time 20:00

# 设置每月备份
memory_manager.py schedule --task backup --enable --schedule monthly --time 09:00

# 禁用定时任务
memory_manager.py schedule --task auto_clean --disable
```

### 归档和报告

```bash
# 归档60天前的记忆
memory_manager.py archive --age 60

# 生成HTML报告
memory_manager.py html
```

### 高级选项

| 命令 | 参数 | 说明 | 示例 |
:|------|------|------|------|
| summarize | `--file` | 指定文件 | `--file 2026-04-26.md` |
| summarize | `--regenerate` | 强制重新生成 | `--regenerate` |
| load | `--mode` | 加载模式 | `--mode brief` |
| load | `--mode` | brief=摘要 / normal=摘要+要点 / full=全文 | |
| load | `--keyword` | 关键词过滤 | `--keyword 绿舜生态` |
| load | `--limit` | 返回数量 | `--limit 5` |
| search | `-k/--keyword` | 搜索关键词 | `-k 绿舜` |
| search | `--mode` | 结果详细程度 | `--mode normal` |
| archive | `--age` | 归档天数 | `--age 60` |
| html | `--output` | 输出路径 | `--output report.html` |
| auto-clean | `--content` | 内容类型过滤 | `--content push` |
| dedup | `--execute` | 执行去重 | `--execute` |
| stats | `--days` | 统计天数 | `--days 7` |
| backup | `--path` | 备份路径 | `--path "D:\备份"` |
| backup | `--execute` | 执行备份 | `--execute` |
| backup | `--restore` | 从备份恢复 | `--restore` |
| schedule | `--task` | 任务名称 | `--task auto_clean` |
| schedule | `--enable` | 启用任务 | `--enable` |
| schedule | `--disable` | 禁用任务 | `--disable` |
| schedule | `--schedule` | 执行周期 | `--schedule daily` |
| schedule | `--time` | 执行时间 | `--time 18:00` |
| schedule | `--day` | 周几(weekly) | `--day monday` |
| doctor | - | 诊断检查 | (无参数) |
| wizard | `--step` | 执行步骤 | `--step memory` |
| feedback | `--type` | 反馈类型 | `--type bug` |
| feedback | `--content` | 反馈内容 | `--content "内容"` |

---

## 🧠 智能分级原理

### 评分维度

| 维度 | 权重 | 说明 |
:|------|------|------|
| 📊 访问频率 | 40% | 最近访问越多越重要 |
| ⏰ 时间衰减 | 30% | 新记忆权重更高 |
| 📏 内容长度 | 15% | 1-10KB最佳 |
| 🏷️ 关键词匹配 | 15% | 匹配用户关注领域 |

### 分级结果

| 等级 | 阈值 | 加载策略 | TOKEN消耗 |
:|------|------|----------|-----------|
| 🔴 核心 | >=70% | 全文加载 | 高 |
| 🟡 普通 | 30-70% | 摘要加载 | 中 |
| 🟢 冷门 | <30% | 归档压缩 | 低 |

---

## 📊 功能对比

| 功能 | V2.2 | V2.3 | V2.4 | V2.5 | V2.6 |
|------|------|------|------|------|------|
| analyze/scan/preview/clean | ✅ | ✅ | ✅ | ✅ | ✅ |
| archive/html | ✅ | ✅ | ✅ | ✅ | ✅ |
| summarize (摘要生成) | ✅ | ✅ | ✅ | ✅ | ✅ |
| rank (重要性分级) | ✅ | ✅ | ✅ | ✅ | ✅ |
| load (智能加载) | ✅ | ✅ | ✅ | ✅ | ✅ |
| search (全文搜索) | ✅ | ✅ | ✅ | ✅ | ✅ |
| config (配置管理) | ❌ | ✅ | ✅ | ✅ | ✅ |
| auto-clean (自动清理) | ❌ | ✅ | ✅ | ✅ | ✅ |
| 差异化清理 | ❌ | ❌ | ✅ | ✅ | ✅ |
| dedup (内容去重) | ❌ | ❌ | ❌ | ✅ | ✅ |
| stats (Token统计) | ❌ | ❌ | ❌ | ✅ | ✅ |
| backup (本地备份) | ❌ | ❌ | ❌ | ✅ | ✅ |
| schedule (定时任务) | ❌ | ❌ | ❌ | ✅ | ✅ |
| doctor (诊断工具) | ❌ | ❌ | ❌ | ❌ | ✅ |
| wizard (设置向导) | ❌ | ❌ | ❌ | ❌ | ✅ |
| feedback (用户反馈) | ❌ | ❌ | ❌ | ❌ | ✅ |
| 颜色输出 | ✅ | ✅ | ✅ | ✅ | ✅ |
| TOKEN节省 | 50-80% | 50-80% | 50-80% | **50-80%** | **50-80%** |

---

## 🛡️ 安全特性

| 特性 | 说明 |
|------|------|
| 🔗 符号链接防护 | 防止路径穿越 |
| 📄 单文件限制 | 最大1MB |
| 📊 累计读取限制 | 不超过5MB |
| 📋 报告数量限制 | 最多1000条 |
| ✅ 预览确认 | 清理前显示清单 |
| 🔒 受保护目录 | memory/skills永不删除 |
| 🧠 内容分类保护 | 个人/工作类永不自动清理，需用户确认 |
| 💾 备份保护 | 备份前自动预览，确认后执行 |

---

## 📁 目录结构

```
.workbuddy/
├── memory/           # 原始记忆文件
│   ├── MEMORY.md     # 核心记忆（永不删除）
│   └── 2026-04-26.md
├── .summary/         # 摘要缓存
│   ├── 2026-04-26.summary  # 摘要文件
│   └── summary_index.json  # 访问统计
├── .token_stats/     # Token统计(V2.5新增)
│   └── 2026-04-28.json
├── archive/         # 归档文件
└── 其他文件...

备份目录结构(V2.5新增):
D:\记忆备份/
├── .backup_manifest.json  # 备份清单
├── MEMORY.md
└── 2026-04-26.md
```

---

## 🎯 使用场景

### 场景1：减少TOKEN消耗
```bash
# 首次使用：生成所有摘要
memory_manager.py summarize

# 日常对话：使用智能加载
memory_manager.py load --mode brief
```

### 场景2：快速定位信息
```bash
# 搜索关键词
memory_manager.py search 绿舜生态

# 加载相关记忆
memory_manager.py load --keyword 绿舜生态 --limit 5
```

### 场景3：定期整理
```bash
# 查看分级
memory_manager.py rank

# 归档冷门记忆
memory_manager.py archive --age 60
```

### 场景4：差异化定时自动清理（V2.4）
```bash
# 差异化自动清理
memory_manager.py auto-clean --execute
```

### 场景5：去重与备份（V2.5）⭐⭐⭐
```bash
# 定期去重（先预览后执行）
memory_manager.py dedup
memory_manager.py dedup --execute

# 定期备份到本地
memory_manager.py backup --path "D:\记忆备份" --execute

# 设置每日自动整理
memory_manager.py schedule --task auto_clean --enable --schedule daily --time 18:00
memory_manager.py schedule --task dedup --enable --schedule weekly --day sunday --time 20:00
```

---

## 🗺️ 未来规划

- [ ] export: 记忆导出/导入功能（跨工作空间迁移）
- [ ] encrypt: 记忆加密功能（敏感信息保护）
- [ ] share: 记忆分享功能（团队协作）
- [ ] tags: 记忆标签系统（多维度分类）
- [ ] cloud: 云端同步备份功能

---

**版本：V2.6.3 | 核心升级：诊断+向导+反馈+函数级确认机制** 🆕



