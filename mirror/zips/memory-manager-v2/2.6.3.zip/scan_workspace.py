#!/usr/bin/env python3
"""
记忆管家 - 工作空间扫描脚本
扫描.workbuddy目录，生成存储报告
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

# 受保护目录
PROTECTED_DIRS = {'memory', 'memory\\', '.workbuddy'}

def scan_workspace(workspace_path: str) -> dict:
    """扫描工作空间"""
    workbuddy_path = Path(workspace_path) / ".workbuddy"
    
    if not workbuddy_path.exists():
        return {"error": ".workbuddy目录不存在", "files": [], "stats": {}}
    
    files_info = []
    total_size = 0
    cleanable_size = 0
    
    # 需要清理的类型
    cleanable_exts = {'.tmp', '.log', '.cache', '.bak', '.temp'}
    
    for file_path in workbuddy_path.rglob("*"):
        if file_path.is_file():
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parent).split('\\')[0] if '\\' in str(rel_path) else str(rel_path.parent)
            
            stat = file_path.stat()
            size_kb = stat.st_size / 1024
            mtime = datetime.fromtimestamp(stat.st_mtime)
            
            # 判断是否可清理
            is_protected = parent_dir in PROTECTED_DIRS or 'memory' in str(rel_path).lower()
            is_cleanable = not is_protected and (file_path.suffix.lower() in cleanable_exts or 'cache' in file_path.name.lower() or 'temp' in file_path.name.lower())
            
            if is_cleanable:
                cleanable_size += size_kb
            
            files_info.append({
                "name": file_path.name,
                "path": str(rel_path),
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "protected": is_protected,
                "cleanable": is_cleanable
            })
            total_size += size_kb
    
    # 按大小排序
    files_info.sort(key=lambda x: x["size_kb"], reverse=True)
    
    # Token预估 (简化计算: 1KB ≈ 300 Token)
    token_saving = cleanable_size * 300
    
    return {
        "workspace": workspace_path,
        "files": files_info,
        "stats": {
            "total_files": len(files_info),
            "total_size_kb": round(total_size, 2),
            "cleanable_size_kb": round(cleanable_size, 2),
            "protected_size_kb": round(total_size - cleanable_size, 2),
            "estimated_token_saving": int(token_saving)
        },
        "recommendations": generate_recommendations(cleanable_size, len(files_info))
    }

def generate_recommendations(cleanable_size: float, file_count: int) -> list:
    """生成优化建议"""
    recs = []
    
    if cleanable_size > 50:
        recs.append(f"💾 可清理缓存: {cleanable_size:.1f} KB，建议清理")
    elif cleanable_size > 0:
        recs.append(f"💾 可清理缓存: {cleanable_size:.1f} KB")
    
    if file_count > 50:
        recs.append(f"📁 文件数量较多({file_count}个)，建议检查是否冗余")
    
    if cleanable_size == 0:
        recs.append("✨ 存储状态良好，无需清理")
    
    return recs

if __name__ == "__main__":
    workspace = sys.argv[1] if len(sys.argv) > 1 else "."
    result = scan_workspace(workspace)
    print(json.dumps(result, ensure_ascii=False, indent=2))
