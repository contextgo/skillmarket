---
name: "Memory Manager"
description: >
  AI Accelerator V2.6.1 - Intelligently manage memories and files, reduce token consumption,
  support differentiated auto-cleanup (push content: next day, personal/work: every 5 days).
  New features: Content hash deduplication, Token consumption trends, Local folder backup,
  Scheduled tasks, Doctor diagnostics, Wizard setup, Feedback collection.
  V2.6.3: Function-level confirm parameter, safer static analysis.
  V2.6.2: Archive/wizard requires user confirmation.
  V2.6.1: Fixed manifest exception handling, chunked reading for large files, scan_workspace performance optimization (os.scandir).
  This skill should be used when users want to manage memories, reduce token consumption,
  summarize memory files, rank memory importance, smart load memories, search memories,
  clean up workspace files, optimize memory usage, auto-clean old logs, deduplicate files,
  view token trends, backup memories, diagnose problems, setup wizard, provide feedback,
  or ask about memory/file status.
  Trigger words: memory manager, clean cache, save token, memory summary, reduce consumption,
  memory optimization, file cleanup, scan storage, storage report, optimize memory,
  efficiency boost, token management, reduce token, memory analysis, scan workspace,
  cleanup preview, empty directory cleanup, memory archive, HTML report, summary generation,
  memory ranking, smart load, memory search, auto cleanup, overdue deletion,
  differentiated cleanup, deduplicate, backup, stats, schedule, doctor, wizard, feedback
---

# Memory Manager V2.6 - AI Accelerator

:brain: **Making AI understand you better, respond faster, save more tokens**

Intelligently manage memories and files, reduce token consumption, support scheduled auto-cleanup
of expired logs, with new features: deduplication, statistics, backup, scheduled tasks,
diagnostics, and setup wizard.

---

## :sparkles: V2.6 Core Upgrades

| Dimension | V2.5 | V2.6 | Improvement |
|:----------|:----:|:----:|:------------|
| Diagnostic Tool | :x: | **:white_check_mark:** | One-click detection of config issues |
| Setup Wizard | :x: | **:white_check_mark:** | Guide first-time configuration |
| User Feedback | :x: | **:white_check_mark:** | Collect usage issues and suggestions |
| Bug Fixes | - | **:white_check_mark:** | Fixed hashlib import, progress bar, etc. |

---

## :sparkles: V2.5 Core Upgrades

| Dimension | V2.4 | V2.5 | Improvement |
|:----------|:----:|:----:|:------------|
| Deduplication | :x: | **:white_check_mark:** | MD5-based smart deduplication |
| Token Stats | :x: | **:white_check_mark:** | Consumption trend visualization |
| Backup | :x: | **:white_check_mark:** | Local folder incremental backup |
| Scheduled Tasks | :x: | **:white_check_mark:** | Scheduled execution of tasks |

| Dimension | V2.3 | V2.4 | Improvement |
|:----------|:----:|:----:|:------------|
| Cleanup Strategy | Unified by time | **Differentiated** | Push: next day, personal/work: every 5 days |
| Reminder Mechanism | Unified | **By type** | Only remind when personal/work due |
| Cleanup Summary | None | **3 categories** | Push/personal work/other clearly separated |
| Filter Support | :x: | **:white_check_mark:** | Filter cleanup scope by content type |

| Dimension | V2.2 | V2.3 | Improvement |
|:----------|:----:|:----:|:------------|
| Config Management | :x: | **:white_check_mark:** | Customizable retention/reminder settings |
| Auto Cleanup | :x: | **:white_check_mark:** | Auto-archive expired logs, free space |
| Scheduled Integration | :x: | **:white_check_mark:** | Integrate with scheduled tasks |
| Token Savings | 50-80% | **50-80%** | Maintained efficiency |

---

## :rocket: Core Features (18 total)

### Basic Features (V2.1)
1. **Memory Analysis** (`analyze`) - Analyze memory file status
2. **Workspace Scan** (`scan`) - Scan .workbuddy directory
3. **Cleanup Preview** (`preview`) - Dry run mode
4. **Smart Cleanup** (`clean`) - Preview and confirm execution
5. **Memory Archive** (`archive`) - Compress and move

### Upgraded Features (V2.2)
6. **Summary Generation** (`summarize`) - One-click generate all memory summaries
7. **Importance Ranking** (`rank`) - Auto-classify core/normal/cold
8. **Smart Loading** (`load`) - Load by ranking, save TOKENS
9. **Memory Search** (`search`) - Fast keyword search
10. **HTML Report** (`html`) - Visual chart display

### New Features (V2.3)
11. **Config Management** (`config`) - View/modify retention strategy
12. **Auto Cleanup** (`auto-clean`) - Scheduled archive of expired logs

### New Features (V2.4)
13. **Differentiated Cleanup** - Push: next day, personal/work: every 5 days
14. **Content Filter** (`--content`) - Filter cleanup scope by content type

### New Features (V2.5) :star::star::star:
15. **Content Deduplication** (`dedup`) - MD5-based smart deduplication
16. **Token Stats** (`stats`) - Consumption trend visualization
17. **Backup Sync** (`backup`) - Local folder incremental backup
18. **Scheduled Tasks** (`schedule`) - Scheduled execution of tasks

### New Features (V2.6) :new:
19. **Diagnostic Tool** (`doctor`) - One-click detection of config issues
20. **Setup Wizard** (`wizard`) - Guide first-time configuration
21. **User Feedback** (`feedback`) - Collect usage issues and suggestions

---

## :moneybag: TOKEN Savings Principle

```
Traditional (full load):
Memory files: 10 × 5KB = 50KB → ~12500 TOKENS

V2.2 (smart load):
├── Core (10%) × 5KB = 5KB → ~1250 TOKENS
├── Normal (30%) × 500 char summary = 1.5KB → ~375 TOKENS
└── Cold (60%) × compressed archive = 1KB → ~250 TOKENS
Total: ~1875 TOKENS (85% savings)
```

---

## :computer: CLI Usage Guide

### Basic Commands

```bash
# Analyze memory status
memory_manager.py analyze

# Scan workspace
memory_manager.py scan

# Execute cleanup
memory_manager.py clean --force
```

### V2.3/V2.4 Command Quick Reference

```bash
# === Summary & Ranking ===
# Generate all memory summaries
memory_manager.py summarize

# Generate summary for specific file
memory_manager.py summarize --file 2026-04-26.md

# Regenerate summaries
memory_manager.py summarize --regenerate

# Memory importance ranking
memory_manager.py rank

# Smart load (default normal mode)
memory_manager.py load

# Load summaries only (most token-saving)
memory_manager.py load --mode brief

# Load related memories
memory_manager.py load --mode normal --keyword project --limit 5

# Search memories
memory_manager.py search -k project

# Search and show detailed content
memory_manager.py search -k project --mode normal
```

### V2.4 Differentiated Auto Cleanup

```bash
# 1. View current config (with differentiated rules)
memory_manager.py config

# 2. Differentiated auto cleanup preview (push: next day, personal/work: remind)
memory_manager.py auto-clean

# 3. Execute differentiated auto cleanup
memory_manager.py auto-clean --execute

# 4. Only clean push content
memory_manager.py auto-clean --content push --execute
```

### V2.6 New Commands :new:

```bash
# === Diagnostic Tool ===
# One-click detection of config issues
memory_manager.py doctor

# === Setup Wizard ===
# Execute first-time setup (full)
memory_manager.py wizard

# Execute specific step only
memory_manager.py wizard --step memory
memory_manager.py wizard --step config
memory_manager.py wizard --step summarize

# === User Feedback ===
# Submit bug report
memory_manager.py feedback --type bug --content "Found an issue"

# Submit feature request
memory_manager.py feedback --type feature --content "Suggest adding cloud backup"
```

### V2.5 New Commands :star::star::star:

```bash
# === Content Deduplication ===
# Preview duplicate files
memory_manager.py dedup

# Execute deduplication (delete duplicates)
memory_manager.py dedup --execute

# === Token Consumption Stats ===
# View last 7 days trend
memory_manager.py stats --days 7

# View last 30 days trend
memory_manager.py stats --days 30

# === Local Backup ===
# Preview backup to local folder
memory_manager.py backup --path "D:\Backup"

# Execute backup
memory_manager.py backup --path "D:\Backup" --execute

# Restore from backup (preview)
memory_manager.py backup --path "D:\Backup" --restore

# Execute restore
memory_manager.py backup --path "D:\Backup" --restore --execute

# === Scheduled Tasks ===
# Check scheduled task status
memory_manager.py schedule --check

# Set daily auto cleanup (18:00)
memory_manager.py schedule --task auto_clean --enable --schedule daily --time 18:00

# Set weekly auto deduplication
memory_manager.py schedule --task dedup --enable --schedule weekly --day monday --time 20:00

# Set monthly backup
memory_manager.py schedule --task backup --enable --schedule monthly --time 09:00

# Disable scheduled task
memory_manager.py schedule --task auto_clean --disable
```

### Archive and Reports

```bash
# Archive memories older than 60 days
memory_manager.py archive --age 60

# Generate HTML report
memory_manager.py html
```

### Advanced Options

| Command | Parameter | Description | Example |
|:--------|:----------|:------------|:--------|
| summarize | `--file` | Specify file | `--file 2026-04-26.md` |
| summarize | `--regenerate` | Force regeneration | `--regenerate` |
| load | `--mode` | Load mode | `--mode brief` |
| load | `--mode` | brief=summary / normal=summary+points / full=all | |
| load | `--keyword` | Keyword filter | `--keyword project` |
| load | `--limit` | Return count | `--limit 5` |
| search | `-k/--keyword` | Search keyword | `-k project` |
| search | `--mode` | Result detail level | `--mode normal` |
| archive | `--age` | Archive days | `--age 60` |
| html | `--output` | Output path | `--output report.html` |
| auto-clean | `--content` | Content type filter | `--content push` |
| dedup | `--execute` | Execute deduplication | `--execute` |
| stats | `--days` | Stats days | `--days 7` |
| backup | `--path` | Backup path | `--path "D:\Backup"` |
| backup | `--execute` | Execute backup | `--execute` |
| backup | `--restore` | Restore from backup | `--restore` |
| schedule | `--task` | Task name | `--task auto_clean` |
| schedule | `--enable` | Enable task | `--enable` |
| schedule | `--disable` | Disable task | `--disable` |
| schedule | `--schedule` | Schedule type | `--schedule daily` |
| schedule | `--time` | Execute time | `--time 18:00` |
| schedule | `--day` | Day of week (weekly) | `--day monday` |
| doctor | - | Diagnostic check | (no params) |
| wizard | `--step` | Execute step | `--step memory` |
| feedback | `--type` | Feedback type | `--type bug` |
| feedback | `--content` | Feedback content | `--content "content"` |

---

## :brain: Smart Ranking Principle

### Scoring Dimensions

| Dimension | Weight | Description |
|:----------|:------:|:------------|
| Access Frequency | 40% | More recent accesses = more important |
| Time Decay | 30% | New memories have higher weight |
| Content Length | 15% | 1-10KB is optimal |
| Keyword Match | 15% | Matches user's focus areas |

### Ranking Results

| Level | Threshold | Load Strategy | Token Consumption |
|:------|:----------|:--------------|:-----------------|
| :red_circle: Core | >=70% | Full load | High |
| :yellow_circle: Normal | 30-70% | Summary load | Medium |
| :green_circle: Cold | <30% | Archive & compress | Low |

---

## :chart_with_upwards_trend: Feature Comparison

| Feature | V2.2 | V2.3 | V2.4 | V2.5 | V2.6 |
|:--------|:----:|:----:|:----:|:----:|:----:|
| analyze/scan/preview/clean | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| archive/html | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| summarize (summary) | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| rank (importance) | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| load (smart load) | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| search (full-text) | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| config (management) | :x: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| auto-clean | :x: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| Differentiated cleanup | :x: | :x: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| dedup (deduplication) | :x: | :x: | :x: | :white_check_mark: | :white_check_mark: |
| stats (Token stats) | :x: | :x: | :x: | :white_check_mark: | :white_check_mark: |
| backup (local) | :x: | :x: | :x: | :white_check_mark: | :white_check_mark: |
| schedule (tasks) | :x: | :x: | :x: | :white_check_mark: | :white_check_mark: |
| doctor (diagnostic) | :x: | :x: | :x: | :x: | :white_check_mark: |
| wizard (setup) | :x: | :x: | :x: | :x: | :white_check_mark: |
| feedback | :x: | :x: | :x: | :x: | :white_check_mark: |
| Color output | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| Token savings | 50-80% | 50-80% | 50-80% | **50-80%** | **50-80%** |

---

## :shield: Security Features

| Feature | Description |
|:--------|:------------|
| Symlink Protection | Prevents path traversal |
| Single File Limit | Max 1MB |
| Cumulative Read Limit | Max 5MB |
| Report Count Limit | Max 1000 items |
| Preview Confirmation | Show list before cleanup |
| Protected Directories | memory/skills never deleted |
| Content Classification | Personal/work never auto-cleaned, requires confirmation |
| Backup Protection | Auto-preview before backup, confirm to execute |

---

## :file_folder: Directory Structure

```
.workbuddy/
├── memory/           # Original memory files
│   ├── MEMORY.md     # Core memory (never deleted)
│   └── 2026-04-26.md
├── .summary/         # Summary cache
│   ├── 2026-04-26.summary  # Summary files
│   └── summary_index.json  # Access statistics
├── .token_stats/     # Token stats (V2.5)
│   └── 2026-04-28.json
├── archive/         # Archived files
└── Other files...

Backup directory structure (V2.5):
D:\Backup\
├── .backup_manifest.json  # Backup manifest
├── MEMORY.md
└── 2026-04-26.md
```

---

## :dart: Use Cases

### Scenario 1: Reduce TOKEN consumption
```bash
# First use: Generate all summaries
memory_manager.py summarize

# Daily conversation: Use smart load
memory_manager.py load --mode brief
```

### Scenario 2: Quickly locate information
```bash
# Search keyword
memory_manager.py search project

# Load related memories
memory_manager.py load --keyword project --limit 5
```

### Scenario 3: Regular organization
```bash
# View ranking
memory_manager.py rank

# Archive cold memories
memory_manager.py archive --age 60
```

### Scenario 4: Differentiated scheduled auto cleanup (V2.4)
```bash
# Differentiated auto cleanup
memory_manager.py auto-clean --execute
```

### Scenario 5: Deduplication & Backup (V2.5) :star::star::star:
```bash
# Regular deduplication (preview then execute)
memory_manager.py dedup
memory_manager.py dedup --execute

# Regular backup to local
memory_manager.py backup --path "D:\Backup" --execute

# Set daily auto organization
memory_manager.py schedule --task auto_clean --enable --schedule daily --time 18:00
memory_manager.py schedule --task dedup --enable --schedule weekly --day sunday --time 20:00
```

---

## :map: Future Plans

- [ ] export: Memory export/import (cross-workspace migration)
- [ ] encrypt: Memory encryption (sensitive info protection)
- [ ] share: Memory sharing (team collaboration)
- [ ] tags: Memory tagging system (multi-dimensional classification)
- [ ] cloud: Cloud sync backup

---

**Version: V2.6.3 | Core Upgrades: Diagnostics + Wizard + Feedback + Function-level Confirm** :new:


