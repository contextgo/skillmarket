# Memory Management Best Practices

## Directory Structure

```
{workspace}/.workbuddy/
├── memory/
│   ├── MEMORY.md          # Long-term memory (core, <1KB)
│   └── YYYY-MM-DD.md      # Daily logs (retain 30 days)
└── settings.local.json    # Config (not loaded)

# Large project files (not auto-loaded)
{workspace}/
├── projects/
│   └── project_name/
│       └── details.md
└── assets/
```

## MEMORY.md Simplified Template

```markdown
# MEMORY.md - Core Memory

## User
- Name/Identity/Preferences
- Communication style (concise/detailed)
- Common tools

## Project
- Project name/positioning
- Core products/services
- Key milestones

## Focus
- Current priority areas
- To-do items
- Preferred directions

## Tool Habits
- Common AI tools
- Work equipment/environment
```

## Token Optimization Tips

### 1. Reduce Injection Volume
- MEMORY.md kept under **500 characters**
- Daily logs record key points only
- Avoid duplicate content

### 2. Load on Demand
| Task Type | Load Content |
|:----------|:-------------|
| Daily conversation | MEMORY.md |
| Historical tasks | MEMORY.md + related logs |
| Large projects | Read file only, don't inject |

### 3. File Management
- Large files stored locally, read directly
- Attachments not loaded into context
- Use relative paths for references

## Cleanup Rules

| Type | Retain | Handle |
|:-----|:-------|:-------|
| MEMORY.md | Permanent | Regularly simplify |
| 30-day logs | 30 days | Load on demand |
| Expired logs | 0 | Delete or archive |
| Cache files | 0 | Clean |

## Expected Results

| Optimization | Token Savings |
|:------------|:--------------|
| MEMORY.md simplified | ~200-500 |
| Don't load expired logs | ~100-300/session |
| Don't inject large files | ~500-2000/session |
| **Total** | **30-50%** |
