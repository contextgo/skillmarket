#!/usr/bin/env python3
"""
Memory Manager - Workspace Scan Script
Scan .workbuddy directory, generate storage report
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

# Protected directories
PROTECTED_DIRS = {'memory', 'memory\\', '.workbuddy'}

def scan_workspace(workspace_path: str) -> dict:
    """Scan workspace"""
    workbuddy_path = Path(workspace_path) / ".workbuddy"
    
    if not workbuddy_path.exists():
        return {"error": ".workbuddy directory does not exist", "files": [], "stats": {}}
    
    files_info = []
    total_size = 0
    cleanable_size = 0
    
    # File types to clean
    cleanable_exts = {'.tmp', '.log', '.cache', '.bak', '.temp'}
    
    for file_path in workbuddy_path.rglob("*"):
        if file_path.is_file():
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parent).split('\\')[0] if '\\' in str(rel_path) else str(rel_path.parent)
            
            stat = file_path.stat()
            size_kb = stat.st_size / 1024
            mtime = datetime.fromtimestamp(stat.st_mtime)
            
            # Check if cleanable
            is_protected = parent_dir in PROTECTED_DIRS or 'memory' in str(rel_path).lower()
            is_cleanable = not is_protected and (file_path.suffix.lower() in cleanable_exts or 'cache' in file_path.name.lower() or 'temp' in file_path.name.lower())
            
            if is_cleanable:
                cleanable_size += size_kb
            
            files_info.append({
                "name": file_path.name,
                "path": str(rel_path),
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "protected": is_protected,
                "cleanable": is_cleanable
            })
            total_size += size_kb
    
    # Sort by size
    files_info.sort(key=lambda x: x["size_kb"], reverse=True)
    
    # Token estimation (simplified: 1KB ~ 300 Token)
    token_saving = cleanable_size * 300
    
    return {
        "workspace": workspace_path,
        "files": files_info,
        "stats": {
            "total_files": len(files_info),
            "total_size_kb": round(total_size, 2),
            "cleanable_size_kb": round(cleanable_size, 2),
            "protected_size_kb": round(total_size - cleanable_size, 2),
            "estimated_token_saving": int(token_saving)
        },
        "recommendations": generate_recommendations(cleanable_size, len(files_info))
    }

def generate_recommendations(cleanable_size: float, file_count: int) -> list:
    """Generate optimization suggestions"""
    recs = []
    
    if cleanable_size > 50:
        recs.append(f"Cleanable cache: {cleanable_size:.1f} KB, suggest cleaning")
    elif cleanable_size > 0:
        recs.append(f"Cleanable cache: {cleanable_size:.1f} KB")
    
    if file_count > 50:
        recs.append(f"Many files ({file_count}), suggest checking for redundancy")
    
    if cleanable_size == 0:
        recs.append("Storage status is good, no cleanup needed")
    
    return recs

if __name__ == "__main__":
    workspace = sys.argv[1] if len(sys.argv) > 1 else "."
    result = scan_workspace(workspace)
    print(json.dumps(result, ensure_ascii=False, indent=2))
