#!/usr/bin/env python3
"""
Memory Manager - Memory Analysis Script
Analyze WorkBuddy memory file status, generate reports
"""

import os
import sys
from pathlib import Path
from datetime import datetime, timedelta
import json

def analyze_memory(workspace_path: str) -> dict:
    """Analyze workspace memory directory"""
    memory_path = Path(workspace_path) / ".workbuddy" / "memory"
    
    if not memory_path.exists():
        return {"error": "Memory directory does not exist", "files": [], "stats": {}}
    
    files_info = []
    total_size = 0
    file_count = 0
    
    # Iterate all md files
    for md_file in memory_path.glob("*.md"):
        stat = md_file.stat()
        size_kb = stat.st_size / 1024
        mtime = datetime.fromtimestamp(stat.st_mtime)
        
        files_info.append({
            "name": md_file.name,
            "size_kb": round(size_kb, 2),
            "modified": mtime.strftime("%Y-%m-%d"),
            "path": str(md_file)
        })
        total_size += size_kb
        file_count += 1
    
    # Sort by modification time
    files_info.sort(key=lambda x: x["modified"], reverse=True)
    
    # Analyze content
    memory_content = ""
    recent_logs = []
    
    # Read MEMORY.md
    memory_file = memory_path / "MEMORY.md"
    if memory_file.exists():
        with open(memory_file, "r", encoding="utf-8") as f:
            memory_content = f.read()
    
    # Read recent 7 days logs
    for f in files_info:
        if f["name"] != "MEMORY.md":
            days_ago = (datetime.now() - datetime.strptime(f["modified"], "%Y-%m-%d")).days
            if days_ago <= 7:
                file_path = Path(f["path"])
                with open(file_path, "r", encoding="utf-8") as fp:
                    recent_logs.append({
                        "name": f["name"],
                        "content": fp.read(),
                        "modified": f["modified"]
                    })
    
    # Generate summary
    summary = {
        "project_context": extract_section(memory_content, "Project", "##"),
        "user_profile": extract_section(memory_content, "User", "##"),
        "recent_activities": [log["modified"] for log in recent_logs]
    }
    
    return {
        "files": files_info,
        "stats": {
            "total_files": file_count,
            "total_size_kb": round(total_size, 2),
            "memory_size_kb": round(memory_file.stat().st_size / 1024, 2) if memory_file.exists() else 0
        },
        "summary": summary,
        "recommendations": generate_recommendations(files_info, total_size)
    }

def extract_section(content: str, keyword: str, prefix: str = "##") -> str:
    """Extract content section"""
    lines = content.split("\n")
    result = []
    capture = False
    
    for line in lines:
        if line.strip().startswith(f"{prefix} {keyword}") or line.strip().startswith(f"{prefix}*{keyword}"):
            capture = True
            continue
        if capture and line.strip().startswith(prefix):
            break
        if capture:
            result.append(line)
    
    return "\n".join(result[:5])  # Take first 5 lines only

def generate_recommendations(files: list, total_size: float) -> list:
    """Generate optimization suggestions"""
    recs = []
    
    if total_size > 100:
        recs.append("Memory files are large (>100KB), suggest cleaning expired logs")
    
    if len(files) > 20:
        recs.append("Many files, suggest merging or archiving old logs")
    
    # Check files older than 30 days
    old_files = []
    for f in files:
        if f["name"] != "MEMORY.md":
            days_ago = (datetime.now() - datetime.strptime(f["modified"], "%Y-%m-%d")).days
            if days_ago > 30:
                old_files.append(f["name"])
    
    if old_files:
        recs.append(f"{len(old_files)} logs older than 30 days can be archived")
    
    if not recs:
        recs.append("Memory status is good, no cleanup needed")
    
    return recs

if __name__ == "__main__":
    workspace = sys.argv[1] if len(sys.argv) > 1 else "."
    result = analyze_memory(workspace)
    print(json.dumps(result, ensure_ascii=False, indent=2))
