#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Memory Manager V2.6 - AI Efficiency Tool
Intelligently manage memories and files, reduce token consumption, support differentiated auto-cleanup

Main Features:
- Memory Analysis: Analyze memory file status with age filtering
- Workspace Scan: Scan .workbuddy directory, identify cleanable content
- Smart Cleanup: Preview and confirm, safe without accidental deletion
- Empty Directory Cleanup: Remove empty directories
- Differentiated Auto Cleanup (V2.4):
  · Push content → Auto-clean after 1 day
  · Personal/work content → No auto-clean, remind every 5 days
- Content Hash Deduplication (V2.5): MD5-based duplicate detection
- Token Consumption Trends (V2.5): Daily token usage statistics
- Local Folder Backup (V2.5): Incremental backup to specified directory
- Scheduled Tasks (V2.5): Auto-execute cleanup/backup/dedup
- Diagnostic Tool (V2.6): One-click detection of config issues
- Setup Wizard (V2.6): Guide first-time configuration and path setup
- User Feedback (V2.6): Collect usage issues and suggestions

Author: Kele138
Version: 2.6.3
"""

import argparse
import hashlib
import json
import os
import sys
import shutil
import gzip
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

# ============ Cross-Platform Initialization ============
# Ensure stdout/stderr support UTF-8 output on Windows
if sys.platform == 'win32':
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        # Try importing colorama (Windows color support)
        try:
            from colorama import init, Fore, Style
            init(autoreset=True)
            COLOR_SUPPORT = True
        except ImportError:
            COLOR_SUPPORT = False
    except Exception:
        COLOR_SUPPORT = False
else:
    try:
        from colorama import init, Fore, Style
        init(autoreset=True)
        COLOR_SUPPORT = True
    except ImportError:
        COLOR_SUPPORT = False

# ============ Constants ============
VERSION = "2.6.3"  # V2.6.3: Function-level confirm parameter, safer static analysis
PROTECTED_DIRS = {'memory', '.workbuddy', '.skills', 'skills'}
CLEANABLE_EXTS = {'.tmp', '.log', '.cache', '.bak', '.temp', '.swp', '.pyc', '__pycache__'}
IMAGE_SIGNATURES = {
    'png': b'\x89PNG\r\n\x1a\n',
    'jpg': b'\xff\xd8\xff',
    'gif': b'GIF87a',
    'gif89': b'GIF89a',
    'bmp': b'BM',
    'webp': b'RIFF',
    'ico': b'\x00\x00\x01\x00',
}
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.ico'}

# Security Limits
MAX_FILE_SIZE = 1 * 1024 * 1024  # 1MB
MAX_TOTAL_READ = 5 * 1024 * 1024  # 5MB
MAX_REPORT_ITEMS = 1000

# Summary Configuration
SUMMARY_DIR = ".summary"  # Summary cache directory
SUMMARY_MAX_CHARS = 300   # Max characters for summary
SUMMARY_INDEX_FILE = "summary_index.json"  # Summary index file

# Importance Ranking Thresholds
RANK_CORE_THRESHOLD = 0.7   # Core memory threshold (>=70%)
RANK_NORMAL_THRESHOLD = 0.3  # Normal memory threshold (>=30%)
# Below 30% = cold memory → Archive

# ============ V2.3: Auto Cleanup Configuration ============
CONFIG_FILE = str(Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json")

DEFAULT_CONFIG = {
    "retention_days": 1,        # Default retention days (push content auto-clean after 1 day)
    "auto_remind_days": 5,      # Personal/work content reminder every 5 days
    "auto_archive": True,       # Auto archive when exceeding retention (True=compress and move, False=report only)
    "last_remind_date": "",     # Last reminder date (auto-maintained)
    "last_clean_date": "",      # Last cleanup date (auto-maintained)
    "_automation_rules": {     # V2.4 Differentiated cleanup rules
        "push_content": {
            "retention_days": 1,       # Push content: auto-clean after 1 day
            "auto_clean": True,
            "keywords": ["push", "AI news", "history push", "daily AI", "news push"]
        },
        "personal_work_content": {
            "retention_days": 0,        # Personal/work content: no auto time-based cleanup
            "auto_clean": False,
            "remind_days": 5,           # Remind every 5 days
            "keywords": ["personal", "work", "project", "client", "business", "MEMORY.md"]
        }
    }
}

def load_config() -> dict:
    """Load configuration file, create default if not exists"""
    config = DEFAULT_CONFIG.copy()
    try:
        if Path(CONFIG_FILE).exists():
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                config.update(user_config)
        else:
            save_config(config)
    except (json.JSONDecodeError, IOError, PermissionError):
        pass  # Use default config on load failure
    return config

def save_config(config: dict) -> None:
    """Save configuration file"""
    cfg_path = Path(CONFIG_FILE)
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cfg_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

def config_memory(workspace_path: str, key: str = None, value: str = None) -> dict:
    """
    View/modify configuration
    - No params: view current config
    - key+value: modify specified item
    """
    config = load_config()
    result = {"action": "view", "config": config}

    if key is not None and value is not None:
        if key not in DEFAULT_CONFIG:
            return {"error": f"Unknown config key: {key}, available: {list(DEFAULT_CONFIG.keys())}"}
        # Type conversion
        default_type = type(DEFAULT_CONFIG[key])
        try:
            typed_value = default_type(value)
        except (ValueError, TypeError):
            return {"error": f"Value '{value}' type error, should be {default_type.__name__}"}
        config[key] = typed_value
        save_config(config)
        result = {"action": "update", "key": key, "value": typed_value, "config": config}

    return result

def classify_content(file_path: Path, rules: dict) -> str:
    """
    V2.4 New Feature: Content Classification
    - push: Push-type info (AI news, history pushes, etc.)
    - personal_work: Personal/work related content
    - other: Other content (use default retention rules)
    """
    # Read file content (first 2KB is enough for classification)
    content = ""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(2048).lower()
    except (OSError, IOError, UnicodeDecodeError):
        pass  # Skip if cannot read file

    file_name_lower = file_path.name.lower()

    # Push content keywords
    push_keywords = rules.get("push_content", {}).get("keywords", [])
    for kw in push_keywords:
        if kw.lower() in content or kw.lower() in file_name_lower:
            return "push"

    # Personal/work keywords
    personal_keywords = rules.get("personal_work_content", {}).get("keywords", [])
    for kw in personal_keywords:
        if kw.lower() in content or kw.lower() in file_name_lower:
            return "personal_work"

    return "other"


def check_remind_due(config: dict) -> bool:
    """
    V2.4: Check if user should be reminded about personal/work content cleanup
    Returns True if it's been remind_days since last reminder
    """
    last_remind = config.get("last_remind_date", "")
    remind_days = config.get("auto_remind_days", 5)
    if not last_remind:
        return True  # Never reminded, first reminder

    try:
        last_date = datetime.strptime(last_remind, "%Y-%m-%d").date()
        days_since = (datetime.now().date() - last_date).days
        return days_since >= remind_days
    except (ValueError, TypeError):
        return True  # Return needs reminder on date parse failure


def auto_clean_memory(workspace_path: str, dry_run: bool = True, content_filter: str = None) -> dict:
    """
    V2.4 New Feature: Differentiated Auto Cleanup
    - Push content: auto-clean after 1 day (auto_clean=True)
    - Personal/work content: no auto-clean, remind every 5 days (auto_clean=False)
    - Other content: use default retention_days rules
    - Returns cleanup report (supports automation)
    - If auto_archive=True, actually archive; otherwise only report
    """
    config = load_config()
    rules = config.get("_automation_rules", DEFAULT_CONFIG["_automation_rules"])
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    result = {
        "timestamp": datetime.now().isoformat(),
        "retention_days": config["retention_days"],
        "auto_remind_days": config["auto_remind_days"],
        "auto_archive": config["auto_archive"],
        "push_auto_clean_days": rules.get("push_content", {}).get("retention_days", 1),
        "personal_work_remind_days": rules.get("personal_work_content", {}).get("remind_days", 5),
        "files_to_archive": [],
        "files_archived": 0,
        "size_freed_kb": 0,
        "kept_files": [],
        "remind_files": [],       # Personal/work type, needs user reminder
        "errors": [],
        "clean_summary": {
            "push_auto_clean": 0,
            "personal_work_to_remind": 0,
            "other_archived": 0
        }
    }

    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result

    today = datetime.now().date()

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue
        # MEMORY.md never cleaned
        if md_file.name == "MEMORY.md":
            result["kept_files"].append({"name": md_file.name, "reason": "Core memory, permanently retained", "type": "core"})
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        age = (datetime.now() - mtime).days

        # V2.4: Content classification
        content_type = classify_content(md_file, rules)

        file_entry = {
            "name": md_file.name,
            "age_days": age,
            "size_kb": round(size_kb, 2),
            "modified": mtime.strftime("%Y-%m-%d"),
            "type": content_type
        }

        # Content filter
        if content_filter and content_filter != content_type and content_filter != "all":
            # User specified filter type, skip if not matching
            result["kept_files"].append({**file_entry, "reason": f"Content type ({content_type}) not in this cleanup scope"})
            continue

        if content_type == "push":
            # Push content: auto-clean after retention days
            push_retention = rules.get("push_content", {}).get("retention_days", 1)
            if age > push_retention:
                result["files_to_archive"].append({**file_entry, "reason": f"Push content, auto-archive after {push_retention} days"})
                result["clean_summary"]["push_auto_clean"] += 1
                if not dry_run:
                    try:
                        if config["auto_archive"]:
                            _do_archive(md_file, mtime, base_path)
                            result["files_archived"] += 1
                            result["size_freed_kb"] += size_kb
                    except Exception as e:
                        result["errors"].append(f"{md_file.name}: {str(e)}")
            else:
                result["kept_files"].append({**file_entry, "reason": f"Push content, {age} days old, retained"})

        elif content_type == "personal_work":
            # Personal/work content: no auto-clean, check if should remind
            if check_remind_due(config):
                result["remind_files"].append({**file_entry, "reason": "Personal/work content, please confirm cleanup"})
                result["clean_summary"]["personal_work_to_remind"] += 1
            else:
                result["kept_files"].append({**file_entry, "reason": "Personal/work content, not yet 5 days since last reminder, retained"})

        else:
            # Other content: use default rules
            default_retention = config.get("retention_days", 1)
            if age > default_retention:
                result["files_to_archive"].append({**file_entry, "reason": f"Other content, archive after {default_retention} days"})
                result["clean_summary"]["other_archived"] += 1
                if not dry_run:
                    try:
                        if config["auto_archive"]:
                            _do_archive(md_file, mtime, base_path)
                            result["files_archived"] += 1
                            result["size_freed_kb"] += size_kb
                    except Exception as e:
                        result["errors"].append(f"{md_file.name}: {str(e)}")
            else:
                result["kept_files"].append({**file_entry, "reason": f"{age} days old, within retention"})

    # Update last cleanup date
    if not dry_run:
        config["last_clean_date"] = today.isoformat()
        # Update reminder date if there were reminders this run
        if result["remind_files"]:
            config["last_remind_date"] = today.isoformat()
        save_config(config)

    return result


def _do_archive(md_file: Path, mtime: datetime, base_path: Path) -> None:
    """Execute archive operation (internal function)"""
    archive_dir = base_path / ".workbuddy" / "archive"
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_name = f"{md_file.stem}_{mtime.strftime('%Y%m%d')}.md.gz"
    archive_file = archive_dir / archive_name
    with open(md_file, 'rb') as f_in:
        with gzip.open(archive_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    md_file.unlink()

# Load modes
LOAD_BRIEF = "brief"   # Load summary only (~200 chars)
LOAD_NORMAL = "normal"  # Summary + key paragraphs (~2KB)
LOAD_FULL = "full"      # Full file

# Color support
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    C = {
        'red': Fore.RED, 'green': Fore.GREEN, 'yellow': Fore.YELLOW,
        'cyan': Fore.CYAN, 'magenta': Fore.MAGENTA, 'white': Fore.WHITE,
        'bright': Style.BRIGHT, 'reset': Style.RESET_ALL
    }
except ImportError:
    C = {k: '' for k in ['red', 'green', 'yellow', 'cyan', 'magenta', 'white', 'bright', 'reset']}


# ============ Safety Functions ============
def is_symlink(path: Path) -> bool:
    """Check if path is a symlink"""
    try:
        return path.is_symlink()
    except (OSError, ValueError):
        return False


def safe_resolve(path: Path, base_path: Path) -> Optional[Path]:
    """
    Safe path resolution: Ensure path is within base directory, prevent path traversal attacks
    
    Args:
        path: Path to check
        base_path: Allowed base directory
    
    Returns:
        Resolved absolute path, or None if out of bounds
    """
    try:
        # Resolve to absolute and normalize
        abs_path = path.resolve()
        abs_base = base_path.resolve()
        
        # Check if within base directory
        try:
            abs_path.relative_to(abs_base)
            return abs_path
        except ValueError:
            # Path outside base directory
            return None
    except (OSError, ValueError):
        return None


def safe_file_read(path: Path, max_size: int = MAX_FILE_SIZE) -> tuple[Optional[str], str]:
    """
    Safe file content reading
    Returns: (content, status info)
    """
    try:
        # Safety check
        if is_symlink(path):
            return None, "Skipped symlink"
        
        stat = path.stat()
        if stat.st_size > max_size:
            return None, f"File exceeds {max_size//1024}KB limit"
        
        # Chunked reading to avoid loading large files at once
        chunk_size = 64 * 1024  # 64KB per chunk
        chunks = []
        bytes_read = 0
        
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            while bytes_read < max_size:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                chunks.append(chunk)
                bytes_read += len(chunk.encode('utf-8', errors='ignore'))
        
        content = ''.join(chunks)
        if len(content.encode('utf-8')) > max_size:
            content = content[:max_size]
        return content, "Success"
    except Exception as e:
        return None, f"Read failed: {type(e).__name__}"


def get_file_info(path: Path) -> tuple[Optional[datetime], Optional[int]]:
    """
    Get file modification time and size (single stat call)
    
    Returns:
        (mtime, size_kb) or (None, None) on failure
    """
    try:
        stat = path.stat()
        return datetime.fromtimestamp(stat.st_mtime), stat.st_size / 1024
    except (OSError, ValueError):
        return None, None


# ============ Progress Bar Support ============
def get_progress_bar():
    """Get progress bar (prefer tqdm, use simple implementation otherwise)"""
    try:
        from tqdm import tqdm
        return tqdm
    except ImportError:
        # Simple progress bar fallback
        class SimpleProgress:
            def __init__(self, total, desc=''):
                self.total = total
                self.n = 0
                self.desc = desc
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
        return SimpleProgress

def detect_image_format(file_path: Path) -> Optional[str]:
    """
    Detect image format by file header (only reads 16 bytes)
    Supports: PNG, JPG, GIF, BMP, WebP, ICO
    """
    try:
        with open(file_path, 'rb') as f:
            header = f.read(16)
        
        for fmt, sig in IMAGE_SIGNATURES.items():
            if header.startswith(sig):
                # WebP needs extra check
                if fmt == 'webp':
                    if len(header) >= 12 and header[8:12] == b'WEBP':
                        return 'webp'
                    continue
                return fmt
        return None
    except (OSError, IOError):
        return None


# ============ Memory Analysis ============
def analyze_memory(
    workspace_path: str,
    age_days: Optional[int] = None,
    exclude_patterns: Optional[list] = None
) -> dict:
    """
    Analyze workspace memory directory
    
    Args:
        workspace_path: Workspace directory path
        age_days: Only analyze files within N days (optional)
        exclude_patterns: Directory patterns to exclude (optional)
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0
        },
        "recommendations": []
    }
    
    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result
    
    if exclude_patterns is None:
        exclude_patterns = []
    
    total_read = 0
    
    try:
        for md_file in memory_path.glob("*.md"):
            # Safety check: symlink + path traversal
            if is_symlink(md_file):
                continue
            if safe_resolve(md_file, memory_path) is None:
                continue
            
            # Get file info (single stat)
            mtime, size_kb = get_file_info(md_file)
            if mtime is None:
                continue
            
            # Age filter
            age = (datetime.now() - mtime).days
            if age_days is not None and age > age_days:
                continue
            
            # Cumulative read limit
            file_size = int(size_kb * 1024)
            if total_read + file_size > MAX_TOTAL_READ:
                result["warning"] = f"Reached read limit of {MAX_TOTAL_READ//1024}KB, report may be truncated"
                break
            
            # Check if cleanable (30+ days old, not MEMORY.md)
            is_cleanable = (
                md_file.name != "MEMORY.md" and 
                age > 30
            )
            
            file_info = {
                "name": md_file.name,
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "age_days": age,
                "cleanable": is_cleanable
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            
            # Limit report items
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"File count exceeds {MAX_REPORT_ITEMS} item limit"
                break
        
        # Generate recommendations
        result["recommendations"] = _generate_recommendations(result["files"], result["stats"])
        
    except Exception as e:
        result["error"] = f"Analysis failed: {type(e).__name__}: {str(e)}"
    
    return result


# ============ Workspace Scan ============
def scan_workspace(
    workspace_path: str,
    exclude_dirs: Optional[list] = None,
    clean_empty_dirs: bool = False
) -> dict:
    """
    Scan workspace, generate storage report
    
    Args:
        workspace_path: Workspace directory path
        exclude_dirs: List of directories to exclude
        clean_empty_dirs: Whether to identify empty directories
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "empty_dirs": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0,
            "protected_size_kb": 0
        },
        "recommendations": []
    }
    
    if not workbuddy_path.exists():
        result["error"] = ".workbuddy directory does not exist"
        return result
    
    if exclude_dirs is None:
        exclude_dirs = []
    
    # Use os.scandir instead of rglob for better performance on large directories
    def scan_dir_recursive(dir_path: Path, results: list):
        """Recursively scan directory (use scandir to avoid rglob performance issues)"""
        try:
            with os.scandir(dir_path) as entries:
                for entry in entries:
                    if entry.is_symlink():
                        continue
                    try:
                        resolved = Path(entry.path).resolve()
                        if not str(resolved).startswith(str(workbuddy_path)):
                            continue
                    except (OSError, ValueError):
                        continue
                    
                    if entry.is_file():
                        results.append(Path(entry.path))
                    elif entry.is_dir():
                        scan_dir_recursive(Path(entry.path), results)
        except (OSError, PermissionError):
            pass

    scanned_files = []
    scan_dir_recursive(workbuddy_path, scanned_files)
    
    for file_path in scanned_files:
        # Safety check: symlink + path traversal
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue
        
        if file_path.is_file():
            # Get file info (single stat)
            mtime, size_kb = get_file_info(file_path)
            if mtime is None:
                continue
            
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""
            
            # Check if protected
            is_protected = (
                parent_dir in PROTECTED_DIRS or
                any(ex in str(rel_path) for ex in exclude_dirs)
            )
            
            # Check if cleanable
            is_cleanable = (
                not is_protected and
                (
                    file_path.suffix.lower() in CLEANABLE_EXTS or
                    'cache' in file_path.name.lower() or
                    'temp' in file_path.name.lower()
                )
            )
            
            # Image detection (only for image extensions <5MB)
            image_format = None
            if file_path.suffix.lower() in IMAGE_EXTENSIONS:
                file_size_kb = int(size_kb)
                if file_size_kb < 5000:  # Less than 5MB
                    image_format = detect_image_format(file_path)
            
            file_info = {
                "name": file_path.name,
                "path": str(rel_path),
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "protected": is_protected,
                "cleanable": is_cleanable,
                "image_format": image_format
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            elif is_protected:
                result["stats"]["protected_size_kb"] += size_kb
            
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"File count exceeds {MAX_REPORT_ITEMS} item limit"
                break
        
        elif clean_empty_dirs and file_path.is_dir():
            # Check empty directory
            try:
                if not any(file_path.iterdir()):
                    result["empty_dirs"].append(str(file_path.relative_to(workbuddy_path)))
            except (OSError, PermissionError):
                continue
    
    # Sort by size
    result["files"].sort(key=lambda x: x["size_kb"], reverse=True)
    
    # Token estimation (rough estimate, for reference only)
    # Rough estimate: 1KB ≈ 300 Token, actual savings depend on content
    estimated_token_saving = int(result["stats"]["cleanable_size_kb"] * 300)
    result["stats"]["estimated_token_saving"] = estimated_token_saving
    result["stats"]["token_saving_note"] = "(Estimate only, actual savings depend on compression rate and loading strategy)"
    
    # Generate recommendations
    result["recommendations"] = _generate_scan_recommendations(
        result["stats"],
        len(result["empty_dirs"])
    )
    
    return result


# ============ Cleanup Preview ============
def generate_cleanup_preview(
    workspace_path: str,
    dry_run: bool = True
) -> dict:
    """
    Generate cleanup preview (dry run mode)

    Args:
        workspace_path: Workspace directory path
        dry_run: True for no actual deletion
    """
    scan_result = scan_workspace(workspace_path)

    preview = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "dry_run": dry_run,
        "files_to_clean": [],
        "total_size_kb": 0,
        "token_saving": 0,
        "message": ""
    }

    if "error" in scan_result:
        preview["error"] = scan_result["error"]
        return preview

    for f in scan_result["files"]:
        if f["cleanable"]:
            preview["files_to_clean"].append(f)
            preview["total_size_kb"] += f["size_kb"]

    # Token savings estimation (rough estimate)
    preview["token_saving"] = int(preview["total_size_kb"] * 300)
    preview["token_saving_note"] = "(Estimate only, for reference)"

    if dry_run:
        preview["message"] = f"Preview mode: {len(preview['files_to_clean'])} files ({preview['total_size_kb']:.1f}KB), reply '同意' to confirm"
    else:
        preview["message"] = f"Will delete {len(preview['files_to_clean'])} files"

    return preview


# ============ P0: Actual Cleanup Execution ============
def execute_cleanup(workspace_path: str, confirm: bool = False) -> dict:
    """
    Execute actual cleanup (P0 fix)

    Args:
        workspace_path: Workspace directory path
        confirm: Whether to confirm deletion (default False, requires explicit confirmation)

    Returns:
        Cleanup result statistics
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"

    result = {
        "deleted_count": 0,
        "deleted_size_kb": 0,
        "failed_count": 0,
        "errors": []
    }

    if not workbuddy_path.exists():
        result["errors"].append(".workbuddy directory does not exist")
        return result

    # Scan cleanable files
    files_to_delete = []
    for file_path in workbuddy_path.rglob("*"):
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue

        if file_path.is_file():
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""

            # Check if protected
            if parent_dir in PROTECTED_DIRS:
                continue

            # Check if cleanable
            is_cleanable = (
                file_path.suffix.lower() in CLEANABLE_EXTS or
                'cache' in file_path.name.lower() or
                'temp' in file_path.name.lower()
            )

            if is_cleanable:
                files_to_delete.append(file_path)

    # Batch delete (only execute after confirmation)
    if confirm:
        print(f"\nStarting cleanup of {len(files_to_delete)} files...")
        for file_path in files_to_delete:
            try:
                mtime, size_kb = get_file_info(file_path)
                file_path.unlink()
                result["deleted_count"] += 1
                result["deleted_size_kb"] += size_kb if size_kb else 0
            except Exception as e:
                result["failed_count"] += 1
                result["errors"].append(f"{file_path.name}: {str(e)}")
    else:
        # Report only when not confirmed
        result["pending_delete"] = len(files_to_delete)

    return result


# ============ P1: Archive Function ============
def archive_old_memory(
    workspace_path: str,
    age_days: int = 30,
    archive_path: Optional[str] = None,
    confirm: bool = False
) -> dict:
    """
    Archive old memory files (P1 function)

    Args:
        workspace_path: Workspace directory path
        age_days: Archive files older than N days
        archive_path: Archive directory path (default: .workbuddy/archive)
        confirm: Whether to confirm deletion (default False, requires explicit confirmation)
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if archive_path is None:
        archive_dir = base_path / ".workbuddy" / "archive"
    else:
        archive_dir = Path(archive_path)

    # Create archive directory
    archive_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "archived_count": 0,
        "archived_size_kb": 0,
        "failed_count": 0,
        "archive_path": str(archive_dir)
    }

    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result

    # Scan old files
    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        # Skip MEMORY.md and non-expired files
        if md_file.name == "MEMORY.md":
            continue
        age = (datetime.now() - mtime).days
        if age <= age_days:
            continue

        try:
            # Compress and archive
            archive_name = f"{md_file.stem}_{mtime.strftime('%Y%m%d')}.md.gz"
            archive_file = archive_dir / archive_name

            with open(md_file, 'rb') as f_in:
                with gzip.open(archive_file, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)

            # Delete original file (only after confirmation)
            if confirm:
                md_file.unlink()
            else:
                # Without confirmation, archive but don't delete, mark as "pending"
                result["pending_delete"] = result.get("pending_delete", 0) + 1

            result["archived_count"] += 1
            result["archived_size_kb"] += size_kb
        except Exception as e:
            result["failed_count"] += 1

    return result


# ============ P0: Summary Generation ============
def extract_keywords(content: str, max_keywords: int = 5) -> list:
    """
    Extract keywords (simple implementation: count high-frequency words)

    Args:
        content: File content
        max_keywords: Maximum number of keywords

    Returns:
        List of keywords
    """
    import re
    # Simple tokenization
    words = re.findall(r'[\w]{2,}', content.lower())
    # Stop words
    stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but', 'if', 'or', 'because', 'until', 'while', 'about', 'against', 'this', 'that', 'these', 'those', 'what', 'which', 'who', 'whom', 'their', 'they', 'them', 'his', 'her', 'its', 'we', 'us', 'our', 'you', 'your', 'i', 'me', 'my'}
    # Filter stop words
    words = [w for w in words if w not in stopwords and len(w) > 1]
    # Count frequency
    from collections import Counter
    counter = Counter(words)
    return [w for w, _ in counter.most_common(max_keywords)]


def generate_summary(content: str, max_chars: int = SUMMARY_MAX_CHARS) -> str:
    """
    Generate summary (rule-based implementation to reduce TOKEN consumption)

    Strategy:
    1. Extract first paragraph as overview
    2. Extract lines with # as headers
    3. Extract key conclusions
    """
    lines = content.split('\n')
    summary_parts = []

    # 1. Extract headers
    headers = [l.strip() for l in lines if l.strip().startswith('#') and len(l) < 100]
    if headers:
        summary_parts.extend(headers[:3])

    # 2. Extract unordered list items (usually key points)
    bullets = [l.strip().lstrip('-*').strip() for l in lines
              if l.strip().startswith(('-', '*')) and len(l) > 5]
    if bullets:
        summary_parts.extend(bullets[:5])

    # 3. Extract first row of tables (usually important info)
    tables = []
    in_table = False
    for l in lines:
        if '|' in l and l.count('|') >= 2:
            if not in_table:
                tables.append(l.strip())
                in_table = True
        else:
            in_table = False

    # 4. If summary too short, add first paragraph
    summary = '\n'.join(summary_parts)
    if len(summary) < 100 and lines:
        # Find first non-empty paragraph
        for l in lines:
            if l.strip() and not l.strip().startswith('#'):
                para = l.strip()[:max_chars]
                if len(summary) < max_chars:
                    summary += '\n' + para

    # Truncate to max length
    if len(summary) > max_chars:
        summary = summary[:max_chars] + '...'

    return summary.strip()


def summarize_memory(
    workspace_path: str,
    file_name: Optional[str] = None,
    regenerate: bool = False
) -> dict:
    """
    Summary generation function (P0 core)

    Args:
        workspace_path: Workspace directory path
        file_name: Specified file (None for all files)
        regenerate: Whether to force regeneration

    Returns:
        Summary results
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    # Create summary directory
    summary_path.mkdir(parents=True, exist_ok=True)

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "summarized": [],
        "skipped": [],
        "errors": []
    }

    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result

    # Process single file
    def process_file(md_file: Path) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        # Check cache
        summary_file = summary_path / f"{md_file.stem}.summary"

        if summary_file.exists() and not regenerate:
            # Read cache
            with open(summary_file, 'r', encoding='utf-8') as f:
                return json.loads(f.read())

        # Read original file
        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # Generate summary
        summary = generate_summary(content)
        keywords = extract_keywords(content)

        mtime, size_kb = get_file_info(md_file)

        summary_data = {
            "file": md_file.name,
            "summary": summary,
            "keywords": keywords,
            "size_kb": size_kb,
            "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
            "generated": datetime.now().isoformat(),
            "token_estimate": len(summary) // 4  # Rough estimate
        }

        # Save cache
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=2)

        return summary_data

    # Process files
    if file_name:
        md_file = memory_path / file_name
        if not md_file.exists():
            result["error"] = f"File does not exist: {file_name}"
            return result
        data = process_file(md_file)
        if data:
            result["summarized"].append(data)
        else:
            result["errors"].append(f"Processing failed: {file_name}")
    else:
        # Process all md files
        for md_file in memory_path.glob("*.md"):
            data = process_file(md_file)
            if data:
                result["summarized"].append(data)
            else:
                result["skipped"].append(md_file.name)

    return result


# ============ P0: Importance Ranking ============
def rank_memory(
    workspace_path: str,
    weights: Optional[dict] = None
) -> dict:
    """
    Memory importance ranking (P0 core)

    Scoring dimensions:
    - Access frequency (40%): More recent accesses = more important
    - Time decay (30%): New memories have higher weight
    - Content length (15%): Medium length is best (too short = meaningless, too long = redundant)
    - Keyword matching (15%): Matches user's focus areas

    Ranking results:
    - Core memory (>=70%): Load full content
    - Normal memory (30%-70%): Load summary
    - Cold memory (<30%): Archive and compress
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if weights is None:
        weights = {"access": 0.4, "recency": 0.3, "length": 0.15, "keywords": 0.15}

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "core": [],
        "normal": [],
        "cold": [],
        "stats": {
            "total": 0,
            "core_count": 0,
            "normal_count": 0,
            "cold_count": 0
        }
    }

    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result

    # Read summary index (if exists)
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR
    index_file = summary_path / SUMMARY_INDEX_FILE
    access_counts = {}

    if index_file.exists():
        with open(index_file, 'r', encoding='utf-8') as f:
            index_data = json.load(f)
            access_counts = index_data.get("access_counts", {})

    # Score each file
    memory_scores = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file) or md_file.name == "MEMORY.md":
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        age_days = (datetime.now() - mtime).days
        size_kb = size_kb or 0

        # 1. Access frequency score (0-100)
        access_count = access_counts.get(md_file.name, 0)
        access_score = min(100, access_count * 20)  # +20 per access, max 100

        # 2. Time decay score (0-100) - newer = higher
        recency_score = max(0, 100 - age_days * 2)  # -2 per day

        # 3. Content length score (0-100) - 1-10KB is best
        if size_kb < 0.5:
            length_score = size_kb * 100  # Too short
        elif size_kb > 10:
            length_score = max(0, 100 - (size_kb - 10) * 5)  # Too long
        else:
            length_score = 100  # Best range

        # 4. Keyword matching score (if summary exists)
        keyword_score = 50  # Default
        summary_file = summary_path / f"{md_file.stem}.summary"
        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)
                # Extra points if keywords exist
                keywords = summary_data.get("keywords", [])
                if keywords:
                    keyword_score = 70  # Slight bonus for having summary

        # Total score
        total_score = (
            access_score * weights["access"] +
            recency_score * weights["recency"] +
            length_score * weights["length"] +
            keyword_score * weights["keywords"]
        ) / 100

        # Ranking
        memory_info = {
            "file": md_file.name,
            "score": round(total_score, 2),
            "size_kb": round(size_kb, 2),
            "age_days": age_days,
            "modified": mtime.strftime("%Y-%m-%d"),
            "details": {
                "access_score": round(access_score, 1),
                "recency_score": round(recency_score, 1),
                "length_score": round(length_score, 1),
                "keyword_score": round(keyword_score, 1)
            }
        }

        if total_score >= RANK_CORE_THRESHOLD * 100:
            result["core"].append(memory_info)
        elif total_score >= RANK_NORMAL_THRESHOLD * 100:
            result["normal"].append(memory_info)
        else:
            result["cold"].append(memory_info)

        memory_scores.append(total_score)

    # Statistics
    result["stats"]["total"] = len(memory_scores)
    result["stats"]["core_count"] = len(result["core"])
    result["stats"]["normal_count"] = len(result["normal"])
    result["stats"]["cold_count"] = len(result["cold"])

    # Sort by score
    result["core"].sort(key=lambda x: x["score"], reverse=True)
    result["normal"].sort(key=lambda x: x["score"], reverse=True)
    result["cold"].sort(key=lambda x: x["score"], reverse=True)

    return result


# ============ P0: Smart Loading ============
def load_memory(
    workspace_path: str,
    mode: str = LOAD_NORMAL,
    keyword: Optional[str] = None,
    limit: int = 10
) -> dict:
    """
    Smart memory loading (P0 core)

    Args:
        workspace_path: Workspace directory path
        mode: Load mode (brief/normal/full)
        keyword: Keyword filter
        limit: Return count limit

    Returns:
        Loaded memory content
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "mode": mode,
        "loaded": [],
        "total_tokens_estimate": 0
    }

    # First do ranking
    rank_result = rank_memory(workspace_path)

    # Decide what to load based on ranking and mode
    def load_file(md_file: Path, load_mode: str) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            return None

        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # Decide what to load based on mode
        if load_mode == LOAD_BRIEF:
            # Load summary only
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    return {
                        "file": md_file.name,
                        "type": "summary",
                        "content": summary_data.get("summary", ""),
                        "keywords": summary_data.get("keywords", []),
                        "modified": mtime.strftime("%Y-%m-%d"),
                        "token_estimate": summary_data.get("token_estimate", 0)
                    }
            else:
                # No summary, generate one
                summary = generate_summary(content, 200)
                return {
                    "file": md_file.name,
                    "type": "summary",
                    "content": summary,
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        elif load_mode == LOAD_NORMAL:
            # Summary + key paragraphs
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    summary = summary_data.get("summary", "")
                # Append some original text
                lines = content.split('\n')
                key_lines = [l for l in lines if l.strip().startswith(('-', '*'))][:5]
                extra = '\n'.join(key_lines)
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": summary + ("\n\nKey Points:\n" + extra if extra else ""),
                    "keywords": summary_data.get("keywords", []),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4 + len(extra) // 4
                }
            else:
                summary = generate_summary(content, 500)
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": summary,
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        else:  # full
            return {
                "file": md_file.name,
                "type": "full",
                "content": content,
                "modified": mtime.strftime("%Y-%m-%d"),
                "token_estimate": len(content) // 4
            }

    # Prioritize loading core memories
    files_to_load = []

    # Core memories → Load full content
    for item in rank_result.get("core", [])[:limit]:
        files_to_load.append((memory_path / item["file"], LOAD_FULL))

    # Normal memories → Load summary
    normal_limit = limit - len(files_to_load)
    for item in rank_result.get("normal", [])[:max(0, normal_limit)]:
        files_to_load.append((memory_path / item["file"], mode))

    # Cold memories → All summaries
    cold_limit = limit - len(files_to_load)
    for item in rank_result.get("cold", [])[:max(0, cold_limit)]:
        files_to_load.append((memory_path / item["file"], LOAD_BRIEF))

    # Keyword filter
    if keyword:
        keyword = keyword.lower()
        files_to_load = [
            (f, m) for f, m in files_to_load
            if keyword in f.name.lower() or (summary_path / f"{f.stem}.summary").exists()
        ]

    # Load
    for md_file, load_mode in files_to_load:
        data = load_file(md_file, load_mode)
        if data:
            result["loaded"].append(data)
            result["total_tokens_estimate"] += data.get("token_estimate", 0)

    return result


# ============ P1: Search Function ============
def search_memory(
    workspace_path: str,
    keyword: str,
    mode: str = "brief"
) -> dict:
    """
    Memory search function (P1)

    Args:
        workspace_path: Workspace directory path
        keyword: Search keyword
        mode: Search mode (brief/normal/full)

    Returns:
        Search results
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "keyword": keyword,
        "matches": [],
        "total": 0
    }

    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result

    keyword_lower = keyword.lower()
    matches = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        # First check summary (fast)
        summary_file = summary_path / f"{md_file.stem}.summary"
        score = 0

        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)

            # Check keyword match
            if keyword_lower in summary_data.get("summary", "").lower():
                score += 10
            if keyword_lower in " ".join(summary_data.get("keywords", [])).lower():
                score += 20
        else:
            # No summary, read original
            content, _ = safe_file_read(md_file)
            if content and keyword_lower in content.lower():
                score = 5
            else:
                continue

        if score > 0:
            mtime, size_kb = get_file_info(md_file)

            # Decide what to return based on mode
            if mode == LOAD_BRIEF:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")[:200]
            elif mode == LOAD_NORMAL:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")
            else:
                content, _ = safe_file_read(md_file)
                content_preview = content[:500] if content else ""

            matches.append({
                "file": md_file.name,
                "score": score,
                "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
                "preview": content_preview,
                "size_kb": round(size_kb, 2) if size_kb else 0
            })

    # Sort by score
    matches.sort(key=lambda x: x["score"], reverse=True)
    result["matches"] = matches
    result["total"] = len(matches)

    return result


# ============ P2: HTML Report Generation ============
def generate_html_report(result: dict, output_path: Optional[str] = None) -> str:
    """
    Generate HTML format storage report (P2 function)
    """
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Memory Manager V{VERSION} - Storage Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; background: #f5f5f5; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; }}
        .stat-card.green {{ background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }}
        .stat-card.orange {{ background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }}
        .stat-card h3 {{ margin: 0 0 10px; font-size: 14px; opacity: 0.9; }}
        .stat-card .value {{ font-size: 28px; font-weight: bold; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #3498db; color: white; }}
        tr:hover {{ background: #f8f9fa; }}
        .badge {{ display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
        .badge-protected {{ background: #e74c3c; color: white; }}
        .badge-cleanable {{ background: #27ae60; color: white; }}
        .footer {{ text-align: center; color: #999; margin-top: 30px; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Memory Manager V{VERSION} - Storage Report</h1>
        <p>Workspace: {result.get('workspace', 'N/A')} | Time: {result.get('timestamp', 'N/A')[:19]}</p>

        <div class="stats">
            <div class="stat-card">
                <h3>Total Files</h3>
                <div class="value">{result['stats'].get('total_files', 0)}</div>
            </div>
            <div class="stat-card green">
                <h3>Total Size</h3>
                <div class="value">{result['stats'].get('total_size_kb', 0):.1f} KB</div>
            </div>
            <div class="stat-card orange">
                <h3>Cleanable</h3>
                <div class="value">{result['stats'].get('cleanable_size_kb', 0):.1f} KB</div>
            </div>
        </div>

        <h2>File List</h2>
        <table>
            <thead>
                <tr>
                    <th>Filename</th>
                    <th>Size</th>
                    <th>Modified</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
"""

    for f in result.get('files', [])[:50]:
        status = '<span class="badge badge-protected">Protected</span>' if f.get('protected') else \
                 '<span class="badge badge-cleanable">Cleanable</span>' if f.get('cleanable') else 'File'
        html += f"""
                <tr>
                    <td>{f['name'][:40]}</td>
                    <td>{f['size_kb']:.2f} KB</td>
                    <td>{f['modified']}</td>
                    <td>{status}</td>
                </tr>
"""

    html += f"""
            </tbody>
        </table>

        <h2>Optimization Suggestions</h2>
        <ul>
"""
    for rec in result.get('recommendations', []):
        html += f"<li>{rec}</li>"

    html += f"""
        </ul>

        <div class="footer">
            Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Memory Manager V{VERSION}
        </div>
    </div>
</body>
</html>"""

    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return output_path

    return html


# ============ Helper Functions ============
def _generate_recommendations(files: list, stats: dict) -> list:
    """Generate memory optimization suggestions"""
    recs = []
    
    if stats["total_size_kb"] > 100:
        recs.append(f"Memory files are large ({stats['total_size_kb']:.1f}KB), suggest cleaning expired logs")
    
    if stats["total_files"] > 20:
        recs.append(f"Many files ({stats['total_files']}), suggest merging or archiving old logs")
    
    cleanable_count = stats.get("cleanable_files", 0)
    if cleanable_count > 0:
        recs.append(f"{cleanable_count} logs older than 30 days can be cleaned")
    
    if not recs:
        recs.append("Memory status is good, no cleanup needed")
    
    return recs


def _generate_scan_recommendations(stats: dict, empty_dir_count: int) -> list:
    """Generate scan optimization suggestions"""
    recs = []
    
    cleanable = stats["cleanable_size_kb"]
    if cleanable > 50:
        recs.append(f"Cleanable cache: {cleanable:.1f}KB, suggest cleaning")
    elif cleanable > 0:
        recs.append(f"Cleanable cache: {cleanable:.1f}KB")
    
    if empty_dir_count > 0:
        recs.append(f"Found {empty_dir_count} empty directories that can be cleaned")
    
    if stats["total_files"] > 100:
        recs.append(f"Many files ({stats['total_files']}), suggest checking for redundancy")
    
    if cleanable == 0 and empty_dir_count == 0:
        recs.append("Storage status is good, no cleanup needed")
    
    return recs


def print_report(result: dict, format_type: str = "text") -> None:
    """Format and output report (with colors)"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    # Text format output
    print(f"\n{C['bright']}{'='*50}{C['reset']}")
    print(f"{C['cyan']}Memory Manager V{VERSION} - Storage Report{C['reset']}")
    print(f"{C['bright']}{'='*50}{C['reset']}")
    print(f"Workspace: {result.get('workspace', 'N/A')}")
    print(f"Scan Time: {result.get('timestamp', 'N/A')[:19]}")
    print()

    if "error" in result:
        print(f"{C['red']}Error: {result['error']}{C['reset']}")
        return

    stats = result.get("stats", {})
    print(f"Statistics Overview:")
    print(f"   Total Files: {C['white']}{stats.get('total_files', 0)}{C['reset']}")
    print(f"   Total Size: {C['yellow']}{stats.get('total_size_kb', 0):.2f} KB{C['reset']}")
    print(f"   Cleanable: {C['green']}{stats.get('cleanable_size_kb', 0):.2f} KB{C['reset']} ({stats.get('cleanable_files', 0)} files)")

    if "estimated_token_saving" in stats:
        print(f"   Est. Token Saving: ~{C['magenta']}{stats['estimated_token_saving']}{C['reset']}")

    if result.get("files"):
        print(f"\nFile Distribution (Top 10 largest files):")
        for i, f in enumerate(result["files"][:10], 1):
            if f.get("protected"):
                status = f"{C['red']}Locked{C['reset']}"
            elif f.get("cleanable"):
                status = f"{C['green']}Cleanable{C['reset']}"
            else:
                status = "File"
            img = f" [{f.get('image_format')}]" if f.get("image_format") else ""
            print(f"   {status} {i}. {f['name'][:30]:30s} {f['size_kb']:>8.2f} KB {img}")

    if result.get("empty_dirs"):
        print(f"\nEmpty Directories ({len(result['empty_dirs'])}):")
        for d in result["empty_dirs"][:5]:
            print(f"   - {d}")
        if len(result["empty_dirs"]) > 5:
            print(f"   ... and {len(result['empty_dirs'])-5} more")

    recs = result.get("recommendations", [])
    if recs:
        print(f"\nOptimization Suggestions:")
        for r in recs:
            print(f"   {r}")

    if result.get("warning"):
        print(f"\n{C['yellow']}Warning: {result['warning']}{C['reset']}")

    print(f"\n{C['bright']}{'='*50}{C['reset']}")


def print_memory_analysis(result: dict, format_type: str = "text") -> None:
    """Format and output memory analysis"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    print(f"\n{'='*50}")
    print(f"Memory Manager V{VERSION} - Memory Analysis")
    print(f"{'='*50}")
    print(f"Workspace: {result.get('workspace', 'N/A')}")
    print()
    
    if "error" in result:
        print(f"Error: {result['error']}")
        return
    
    stats = result.get("stats", {})
    print(f"Memory Status:")
    print(f"   Total Files: {stats.get('total_files', 0)}")
    print(f"   Total Size: {stats.get('total_size_kb', 0):.2f} KB")
    
    if result.get("files"):
        print(f"\nFile List:")
        for f in result["files"][:20]:
            age = f.get("age_days", 0)
            status = "New" if age <= 7 else "Recent" if age <= 30 else "Old"
            clean = "Cleanable" if f.get("cleanable") else "  "
            print(f"   {status}{clean} {f['name']:30s} {f['size_kb']:>7.2f}KB  {f['modified']} ({age} days ago)")
        
        if len(result["files"]) > 20:
            print(f"   ... and {len(result['files'])-20} more files")
    
    recs = result.get("recommendations", [])
    if recs:
        print(f"\nSuggestions:")
        for r in recs:
            print(f"   {r}")
    
    print(f"\n{'='*50}")


def print_preview(preview: dict) -> None:
    """Format and output cleanup preview"""
    print(f"\n{'='*50}")
    print(f"Cleanup Preview {'[Preview Mode]' if preview.get('dry_run') else ''}")
    print(f"{'='*50}")
    
    if "error" in preview:
        print(f"Error: {preview['error']}")
        return
    
    files = preview.get("files_to_clean", [])
    print(f"Will delete {len(files)} files ({preview.get('total_size_kb', 0):.1f} KB)")
    print(f"Est. Token Saving: ~{preview.get('token_saving', 0)}")
    print()
    
    for i, f in enumerate(files[:20], 1):
        print(f"   [{i}] {f['name'][:40]:40s} {f['size_kb']:>7.2f} KB")
    
    if len(files) > 20:
        print(f"   ... and {len(files)-20} more files")
    
    print(f"\n{preview.get('message', '')}")
    print(f"\n{'='*50}")


# ============ CLI Entry ============

# ============ V2.5 New Features ============

def compute_content_hash(file_path):
    """Calculate file content hash (for deduplication detection)"""
    try:
        with open(file_path, 'rb') as f:
            return hashlib.md5(f.read(50*1024)).hexdigest()
    except (OSError, IOError, hashlib.HTTPError):
        return ""

def dedup_memory(workspace_path, dry_run=True, delete_dup=False):
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {"total_files": 0, "unique_files": 0, "duplicate_groups": [], "duplicates_found": 0, "space_saved_kb": 0}
    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result
    file_hashes = {}
    for md_file in memory_path.glob("*.md"):
        if md_file.name == "MEMORY.md":
            continue
        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        h = compute_content_hash(md_file)
        if h not in file_hashes:
            file_hashes[h] = []
        file_hashes[h].append({"path": str(md_file), "name": md_file.name, "size_kb": round(size_kb, 2), "modified": mtime.strftime("%Y-%m-%d")})
        result["total_files"] += 1
    for h, files in file_hashes.items():
        if len(files) > 1:
            files.sort(key=lambda x: x["modified"])
            dups = files[1:]
            result["duplicate_groups"].append({"hash": h[:12]+"...", "original": files[0], "duplicates": dups})
            result["duplicates_found"] += len(dups)
            result["space_saved_kb"] += sum(f["size_kb"] for f in dups)
            if not dry_run and delete_dup:
                for dup in dups:
                    try:
                        Path(dup["path"]).unlink()
                    except (OSError, IOError, PermissionError):
                        pass  # Silently ignore delete failures
    result["unique_files"] = result["total_files"] - result["duplicates_found"]
    return result

def get_token_stats_dir(workspace_path):
    base_path = Path(workspace_path).resolve()
    stats_dir = base_path / ".workbuddy" / ".token_stats"
    stats_dir.mkdir(parents=True, exist_ok=True)
    return stats_dir

def record_token_usage(workspace_path, tokens, operation="load"):
    stats_dir = get_token_stats_dir(workspace_path)
    today = datetime.now().date().isoformat()
    stats_file = stats_dir / (today + ".json")
    stats = {"date": today, "operations": {}} if not stats_file.exists() else json.loads(stats_file.read_text(encoding="utf-8"))
    if operation not in stats["operations"]:
        stats["operations"][operation] = {"count": 0, "tokens": 0}
    stats["operations"][operation]["count"] += 1
    stats["operations"][operation]["tokens"] += tokens
    stats_file.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    return stats

def get_token_trends(workspace_path, days=30):
    stats_dir = get_token_stats_dir(workspace_path)
    today = datetime.now().date()
    daily_data, total_tokens, op_totals = [], 0, {}
    for i in range(days):
        date = today - timedelta(days=i)
        stats_file = stats_dir / (date.isoformat() + ".json")
        day_entry = {"date": date.isoformat(), "total_tokens": 0, "operations": {}}
        if stats_file.exists():
            try:
                stats = json.loads(stats_file.read_text(encoding="utf-8"))
                day_total = sum(op["tokens"] for op in stats.get("operations", {}).values())
                day_entry = {"date": date.isoformat(), "total_tokens": day_total, "operations": stats.get("operations", {})}
                total_tokens += day_total
                for op, data in stats.get("operations", {}).items():
                    op_totals[op] = op_totals.get(op, 0) + data["tokens"]
            except (json.JSONDecodeError, KeyError, IOError):
                pass  # Silently ignore corrupted stats files
        daily_data.append(day_entry)
    daily_data.reverse()
    recent = daily_data[-7:] if len(daily_data) >= 7 else daily_data
    recent_avg = sum(d["total_tokens"] for d in recent) / max(1, len(recent))
    return {"version": "2.5.0", "period_days": days, "daily_data": daily_data, "total_tokens": total_tokens, "daily_average": round(recent_avg, 1), "operation_totals": op_totals}

def backup_memory(workspace_path, backup_path=None, dry_run=True, incremental=True):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    bp_cfg = config.get("_backup_config", {})
    if backup_path is None:
        backup_path = bp_cfg.get("local_path", "")
    if not backup_path:
        return {"error": "Backup path not configured"}
    backup_path = Path(backup_path).resolve()
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {"backup_path": str(backup_path), "files_copied": 0, "files_updated": 0, "total_size_kb": 0}
    if not memory_path.exists():
        result["error"] = "Memory directory does not exist"
        return result
    if not dry_run:
        backup_path.mkdir(parents=True, exist_ok=True)
    manifest_file = backup_path / ".backup_manifest.json"
    last_backup = {}
    if manifest_file.exists():
        try:
            last_backup = json.loads(manifest_file.read_text(encoding="utf-8")).get("files", {})
        except (json.JSONDecodeError, IOError, KeyError):
            pass  # Silently ignore corrupted backup records
    for md_file in memory_path.glob("*.md"):
        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        rel = md_file.relative_to(memory_path)
        backup_file = backup_path / rel
        current_hash = compute_content_hash(md_file)
        file_key = str(rel)
        should_backup = not incremental or file_key not in last_backup or last_backup.get(file_key, {}).get("hash") != current_hash
        if should_backup:
            if dry_run:
                result["files_copied" if file_key not in last_backup else "files_updated"] += 1
                result["total_size_kb"] += size_kb
            else:
                try:
                    backup_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(md_file, backup_file)
                    result["files_copied" if file_key not in last_backup else "files_updated"] += 1
                    result["total_size_kb"] += size_kb
                except (OSError, IOError, PermissionError) as e:
                    pass  # Silently ignore backup failures
    if not dry_run:
        manifest_file.write_text(json.dumps({"last_backup": datetime.now().isoformat(), "files": {str(f.relative_to(memory_path)): {"hash": compute_content_hash(f), "size_kb": get_file_info(f)[1]} for f in memory_path.glob("*.md")}}, ensure_ascii=False, indent=2), encoding="utf-8")
    return result

def restore_backup(workspace_path, backup_path=None, dry_run=True):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    bp_cfg = config.get("_backup_config", {})
    if backup_path is None:
        backup_path = bp_cfg.get("local_path", "")
    if not backup_path:
        return {"error": "Backup path not configured"}
    backup_path = Path(backup_path).resolve()
    manifest_file = backup_path / ".backup_manifest.json"
    if not manifest_file.exists():
        return {"error": "Backup manifest does not exist"}
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, IOError):
        return {"error": "Backup manifest corrupted, cannot parse"}
    result = {"files_restored": 0}
    for file_key in manifest.get("files", {}):
        src = backup_path / file_key
        dst = Path(workspace_path).resolve() / ".workbuddy" / "memory" / file_key
        if src.exists():
            if dry_run:
                result["files_restored"] += 1
            else:
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                    result["files_restored"] += 1
                except (OSError, IOError, PermissionError):
                    pass  # Silently ignore restore failures
    return result

def setup_schedule(workspace_path, task, enabled=True, schedule="daily", time="18:00", day=None):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    if "_schedule_config" not in config:
        config["_schedule_config"] = {"enabled": False, "tasks": {}}
    if "tasks" not in config["_schedule_config"]:
        config["_schedule_config"]["tasks"] = {}
    task_cfg = {"enabled": enabled, "schedule": schedule, "time": time}
    if schedule == "weekly" and day:
        task_cfg["day"] = day
    config["_schedule_config"]["tasks"][task] = task_cfg
    config["_schedule_config"]["enabled"] = any(t.get("enabled", False) for t in config["_schedule_config"]["tasks"].values())
    config_file.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"task": task, "config": task_cfg}

def check_schedule(workspace_path):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    sched_cfg = config.get("_schedule_config", {})
    result = {"enabled": sched_cfg.get("enabled", False), "tasks_to_run": [], "tasks_scheduled": []}
    if not result["enabled"]:
        return result
    now = datetime.now()
    for task_name, task_cfg in sched_cfg.get("tasks", {}).items():
        if not task_cfg.get("enabled", False):
            continue
        schedule, task_time, task_day = task_cfg.get("schedule", "daily"), task_cfg.get("time", "18:00"), task_cfg.get("day")
        should_run = False
        if schedule == "daily" and now.strftime("%H:%M") == task_time:
            should_run = True
        elif schedule == "weekly" and task_day and now.strftime("%A").lower() == task_day and now.strftime("%H:%M") == task_time:
            should_run = True
        elif schedule == "monthly" and now.day == 1 and now.strftime("%H:%M") == task_time:
            should_run = True
        task_info = {"name": task_name, "schedule": schedule, "time": task_time}
        if should_run:
            result["tasks_to_run"].append(task_info)
        else:
            result["tasks_scheduled"].append(task_info)
    return result

# ============ V2.6 New Features ============

def doctor_diagnose(workspace_path: str) -> dict:
    """
    V2.6 New Feature: Diagnostic Tool
    One-click detection of config issues and potential problems
    """
    base_path = Path(workspace_path).resolve()
    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "issues": [],
        "warnings": [],
        "passed": [],
        "score": 100
    }

    # 1. Check memory directory
    memory_path = base_path / ".workbuddy" / "memory"
    if not memory_path.exists():
        result["issues"].append({"type": "error", "item": "Memory Directory", "message": ".workbuddy/memory directory does not exist"})
        result["score"] -= 30
    else:
        result["passed"].append({"item": "Memory Directory", "status": "OK"})
        # Check file permissions (use read test to avoid write operations)
        try:
            # Check if directory is readable
            test_read = any(memory_path.glob("*.md"))
            # Check if directory is enumerable
            list(memory_path.iterdir())
            result["passed"].append({"item": "Access Permissions", "status": "OK"})
        except (PermissionError, OSError) as e:
            result["issues"].append({"type": "error", "item": "Access Permissions", "message": f"Cannot access memory directory: {e}"})
            result["score"] -= 20

    # 2. Check config file
    config = load_config()
    if not config:
        result["issues"].append({"type": "warning", "item": "Config File", "message": "Config file is empty or corrupted"})
        result["score"] -= 10
    else:
        result["passed"].append({"item": "Config File", "status": "OK"})

    # 3. Check backup config
    bp_cfg = config.get("_backup_config", {})
    if bp_cfg.get("local_path"):
        backup_path = Path(bp_cfg["local_path"])
        if not backup_path.exists():
            result["warnings"].append({"item": "Backup Path", "message": f"Configured backup path does not exist: {backup_path}"})
        else:
            result["passed"].append({"item": "Backup Path", "status": "OK"})
    else:
        result["warnings"].append({"item": "Backup Path", "message": "Backup path not configured, recommend setting for data safety"})

    # 4. Check scheduled task config
    sched_cfg = config.get("_schedule_config", {})
    if sched_cfg.get("enabled"):
        result["passed"].append({"item": "Scheduled Tasks", "status": "Enabled"})
        # Check task config
        for task_name, task_cfg in sched_cfg.get("tasks", {}).items():
            if not task_cfg.get("enabled"):
                result["warnings"].append({"item": f"Task {task_name}", "message": "Task is disabled"})
    else:
        result["warnings"].append({"item": "Scheduled Tasks", "message": "Scheduled tasks not enabled, recommend setting auto cleanup"})

    # 5. Check memory file status
    if memory_path.exists():
        md_files = list(memory_path.glob("*.md"))
        total_size = sum(f.stat().st_size for f in md_files if f.is_file()) / 1024

        if len(md_files) > 100:
            result["warnings"].append({"item": "File Count", "message": f"Many memory files ({len(md_files)}), recommend cleanup or archive"})
            result["score"] -= 5

        if total_size > 500:
            result["warnings"].append({"item": "Storage Size", "message": f"Memory occupies significant space ({total_size:.1f}KB), may affect token consumption"})
            result["score"] -= 5

        # Check duplicate files (reuse existing file list for hash calculation to avoid duplicate scanning)
        file_hashes = {}
        dup_count = 0
        for md_file in md_files:
            if md_file.name == "MEMORY.md":
                continue
            h = compute_content_hash(md_file)
            if h in file_hashes:
                dup_count += 1
            else:
                file_hashes[h] = md_file
        
        if dup_count > 0:
            result["warnings"].append({
                "item": "Duplicate Files",
                "message": f"Found approximately {dup_count} duplicate files, recommend running 'python memory_manager.py dedup' for deduplication"
            })

    # 6. Check summary cache
    summary_path = base_path / ".workbuddy" / ".summary"
    if summary_path.exists():
        summary_files = list(summary_path.glob("*.summary"))
        result["passed"].append({"item": "Summary Cache", "status": f"{len(summary_files)} caches"})
    else:
        result["warnings"].append({"item": "Summary Cache", "message": "No summary cache generated, recommend running summarize command"})

    # Calculate final score
    result["score"] = max(0, result["score"])

    return result


def run_wizard(workspace_path: str, step: str = "all") -> dict:
    """
    V2.6 New Feature: Setup Wizard
    Guide first-time configuration and path setup
    """
    base_path = Path(workspace_path).resolve()
    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "steps_completed": [],
        "config": {}
    }

    # Step 1: Confirm workspace
    if step in ["all", "workspace"]:
        if base_path.exists() and base_path.is_dir():
            result["steps_completed"].append({"step": "workspace", "status": "ok", "path": str(base_path)})
        else:
            return {"error": f"Workspace does not exist: {workspace_path}"}

    # Step 2: Initialize memory directory
    if step in ["all", "memory"]:
        memory_path = base_path / ".workbuddy" / "memory"
        memory_path.mkdir(parents=True, exist_ok=True)

        # Create example file (if not exists)
        example_file = memory_path / "MEMORY.md"
        if not example_file.exists():
            example_file.write_text("""# Memory Manager Usage Example

This is a sample memory file.

## Features
- Memory Manager automatically manages files in this directory
- Push content older than 1 day will be auto-cleaned
- Personal/work content will remind every 5 days

## Retention Rules
- Push content keywords: push, AI news, history push
- Personal/work keywords: personal, work, project, client
""", encoding="utf-8")
        result["steps_completed"].append({"step": "memory", "status": "ok", "path": str(memory_path)})

    # Step 3: Initialize config
    if step in ["all", "config"]:
        config = load_config()
        # Ensure default config exists
        if "retention_days" not in config:
            config["retention_days"] = 1
        if "_automation_rules" not in config:
            config["_automation_rules"] = DEFAULT_CONFIG["_automation_rules"]
        save_config(config)
        result["steps_completed"].append({"step": "config", "status": "ok"})
        result["config"] = config

    # Step 4: Generate summaries
    if step in ["all", "summarize"]:
        summary_result = summarize_memory(workspace_path, regenerate=True)
        result["steps_completed"].append({
            "step": "summarize",
            "status": "ok",
            "summarized": len(summary_result.get("summarized", []))
        })

    return result


def collect_feedback(workspace_path: str, feedback_type: str, content: str) -> dict:
    """
    V2.6 New Feature: User Feedback Collection
    Collect usage issues and suggestions
    """
    feedback_dir = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "feedback"
    feedback_dir.mkdir(parents=True, exist_ok=True)

    # Generate feedback file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    feedback_file = feedback_dir / f"feedback_{timestamp}.json"

    feedback_data = {
        "version": VERSION,
        "type": feedback_type,  # bug/feature/suggestion/general
        "content": content,
        "timestamp": datetime.now().isoformat(),
        "workspace": workspace_path,
        "status": "pending"  # pending/processed/resolved
    }

    feedback_file.write_text(json.dumps(feedback_data, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "status": "saved",
        "file": str(feedback_file),
        "message": "Thank you for your feedback!"
    }


def add_v25_cli(subparsers):
    # V2.6: doctor command
    doctor_parser = subparsers.add_parser("doctor", help="Diagnostic tool - Detect config issues and potential problems")

    # V2.6: wizard command
    wizard_parser = subparsers.add_parser("wizard", help="Setup wizard - Guide first-time configuration")
    wizard_parser.add_argument("--step", type=str, default="all",
                              choices=["all", "workspace", "memory", "config", "summarize"],
                              help="Steps to execute")

    # V2.6: feedback command
    feedback_parser = subparsers.add_parser("feedback", help="User feedback - Submit issues or suggestions")
    feedback_parser.add_argument("--type", type=str, default="general",
                                choices=["bug", "feature", "suggestion", "general"],
                                help="Feedback type")
    feedback_parser.add_argument("--content", type=str, required=True,
                                help="Feedback content")

    # V2.5: dedup command
    dedup_parser = subparsers.add_parser("dedup", help="Content hash-based deduplication")
    dedup_parser.add_argument("--execute", action="store_true", help="Execute deduplication")
    stats_parser = subparsers.add_parser("stats", help="Token consumption trends")
    stats_parser.add_argument("--days", type=int, default=30, help="Days to analyze")
    backup_parser = subparsers.add_parser("backup", help="Backup/restore")
    backup_parser.add_argument("--path", type=str, help="Backup directory")
    backup_parser.add_argument("--execute", action="store_true", help="Execute backup")
    backup_parser.add_argument("--restore", action="store_true", help="Restore from backup")
    schedule_parser = subparsers.add_parser("schedule", help="Scheduled tasks")
    schedule_parser.add_argument("--task", type=str, choices=["auto_clean", "backup", "dedup"], help="Task name")
    schedule_parser.add_argument("--enable", action="store_true")
    schedule_parser.add_argument("--disable", action="store_true")
    schedule_parser.add_argument("--schedule", type=str, default="daily", choices=["daily", "weekly", "monthly"])
    schedule_parser.add_argument("--time", type=str, default="18:00")
    schedule_parser.add_argument("--day", type=str)
    schedule_parser.add_argument("--check", action="store_true")

def handle_v25_command(args):
    # V2.6: doctor command
    if args.command == "doctor":
        res = doctor_diagnose(args.workspace)
        print(f"\n{C['bright']}{'='*50}{C['reset']}")
        print(f"{C['cyan']}Memory Manager V{VERSION} - Diagnostic Report{C['reset']}")
        print(f"{'='*50}")
        print(f"\nHealth Score: {C['yellow']}{res['score']}/100{C['reset']}")

        if res["issues"]:
            print(f"\n{C['red']}Issues ({len(res['issues'])}):{C['reset']}")
            for issue in res["issues"]:
                print(f"   - [{issue['type']}] {issue['item']}: {issue['message']}")

        if res["warnings"]:
            print(f"\n{C['yellow']}Warnings ({len(res['warnings'])}):{C['reset']}")
            for warn in res["warnings"]:
                print(f"   - {warn['item']}: {warn['message']}")

        if res["passed"]:
            print(f"\n{C['green']}OK ({len(res['passed'])}):{C['reset']}")
            for item in res["passed"][:5]:
                print(f"   [OK] {item['item']}: {item['status']}")
            if len(res["passed"]) > 5:
                print(f"   ... and {len(res['passed'])-5} more")

        print(f"\n{'='*50}")
        return res

    # V2.6: wizard command
    elif args.command == "wizard":
        print(f"\n{C['yellow']}Setup wizard will create the following structure in workspace:{''}")
        print(f"   - .workbuddy/memory/  (memory directory)")
        print(f"   - .workbuddy/config.json  (config file)")
        print(f"Reply 'agree' to confirm: ")
        user_input = input().strip()
        if user_input != 'agree':
            print(f"{C['red']}Wizard cancelled{''}")
            return {"cancelled": True}
        res = run_wizard(args.workspace, step=args.step)
        print(f"\n{C['bright']}{'='*50}{C['reset']}")
        print(f"{C['cyan']}Memory Manager V{VERSION} - Setup Wizard{C['reset']}")
        print(f"{'='*50}")

        if "error" in res:
            print(f"{C['red']}Error: {res['error']}{C['reset']}")
            return res

        print(f"\nCompleted {len(res['steps_completed'])} steps:")
        for step in res["steps_completed"]:
            print(f"   [OK] {step['step']}: {step['status']}")
            if "path" in step:
                print(f"     Path: {step['path']}")
            if "summarized" in step:
                print(f"     Generated {step['summarized']} summaries")

        print(f"\nRecommended next steps:")
        print(f"   - Run 'python memory_manager.py doctor' to check config")
        print(f"   - Run 'python memory_manager.py auto-clean --execute' for first cleanup")
        print(f"   - Run 'python memory_manager.py config' to view current config")

        print(f"\n{'='*50}")
        return res

    # V2.6: feedback command
    elif args.command == "feedback":
        res = collect_feedback(args.workspace, args.type, args.content)
        print(f"\n{C['green']}[OK] {res['message']}{C['reset']}")
        print(f"   Feedback type: {args.type}")
        print(f"   Saved to: {res['file']}")
        return res

    # V2.5: dedup command
    if args.command == "dedup":
        res = dedup_memory(args.workspace, dry_run=not args.execute, delete_dup=args.execute)
        print("\nTotal: %d | Unique: %d | Duplicates: %d | Recoverable: %.1fKB" % (res.get("total_files", 0), res.get("unique_files", 0), res.get("duplicates_found", 0), res.get("space_saved_kb", 0)))
        if res.get("duplicate_groups"):
            print("\nDuplicate groups (first 5):")
            for g in res["duplicate_groups"][:5]:
                print("  Original: %s (%s)" % (g["original"]["name"], g["original"]["modified"]))
                print("  Duplicates: %s" % ", ".join(d["name"] for d in g["duplicates"]))
        if not args.execute and res.get("duplicates_found", 0) > 0:
            print("\n[Tip] Use --execute to confirm deletion")
        return res
    elif args.command == "stats":
        res = get_token_trends(args.workspace, days=args.days)
        print("\n[Token Stats] Last %d days:" % res["period_days"])
        print("   Total: %s | Daily Avg: %s" % (format(res["total_tokens"], ","), format(int(res["daily_average"]), ",")))
        for op, tokens in res.get("operation_totals", {}).items():
            if tokens > 0:
                pct = tokens / max(1, res["total_tokens"]) * 100
                bar = "#" * int(pct / 3)
                print("   %-12s: %s %s (%.1f%%)" % (op, bar, format(tokens, ","), pct))
        print("\n   Last 7 days trend:")
        for d in res["daily_data"][-7:]:
            bar = "#" * min(30, int(d["total_tokens"] / max(1, res["daily_average"]) * 30))
            print("   %s: %s %s" % (d["date"][5:], bar, format(d["total_tokens"], ",")))
        return res
    elif args.command == "backup":
        if args.restore:
            res = restore_backup(args.workspace, args.path, dry_run=not args.execute)
            print("\n[%s] Will restore %d files" % ("Preview" if not args.execute else "Complete", res.get("files_restored", 0)))
        else:
            res = backup_memory(args.workspace, args.path, dry_run=not args.execute)
            if res.get("error"):
                print("\n[Error] %s" % res["error"])
            else:
                print("\nBackup[%s]:" % ("Preview" if not args.execute else "Complete"))
                print("   Path: %s" % res.get("backup_path"))
                print("   New: %d | Updated: %d | Size: %.1fKB" % (res.get("files_copied", 0), res.get("files_updated", 0), res.get("total_size_kb", 0)))
        return res
    elif args.command == "schedule":
        if args.check:
            res = check_schedule(args.workspace)
            print("\n[Scheduled Tasks] Status: %s" % ("Enabled" if res["enabled"] else "Disabled"))
            for t in res.get("tasks_scheduled", []):
                info = "   - %s: %s @ %s" % (t["name"], t["schedule"], t["time"])
                if t.get("day"):
                    info += " (%s)" % t["day"]
                print(info)
            if res.get("tasks_to_run"):
                print("   >> Pending: %s" % ", ".join(t["name"] for t in res["tasks_to_run"]))
        elif args.task:
            enabled = args.enable and not args.disable
            res = setup_schedule(args.workspace, args.task, enabled=enabled, schedule=args.schedule, time=args.time, day=args.day)
            print("\n[OK] Scheduled task %s: %s" % ("enabled" if enabled else "disabled", args.task))
            print("  Schedule: %s | Time: %s" % (res["config"]["schedule"], res["config"]["time"]))
        return res
    return {}



def main():
    parser = argparse.ArgumentParser(
        description=f"Memory Manager V{VERSION} - AI Efficiency Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example Usage:
  %(prog)s analyze                    # Analyze memory status
  %(prog)s analyze --age 7            # Only files within 7 days
  %(prog)s scan                       # Scan workspace
  %(prog)s scan --exclude temp,logs  # Exclude specific directories
  %(prog)s preview                    # Generate cleanup preview
  %(prog)s preview --json             # JSON format output
  %(prog)s auto-clean                 # Differentiated auto cleanup (preview)
  %(prog)s auto-clean --execute       # Execute differentiated auto cleanup
  %(prog)s auto-clean --content push # Only clean push content
  %(prog)s auto-clean --content personal_work  # Only handle personal/work (prompt user)

Security Features:
  - Symlink protection
  - Single file 1MB limit
  - Cumulative read 5MB limit
  - Max 1000 report items
  - Content type classification, no accidental deletion of personal/work content
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    parser.add_argument('--json', action='store_true', help='JSON format output')
    parser.add_argument('workspace', nargs='?', default='.', help='Workspace directory path')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    add_v25_cli(subparsers)  # V2.5 New commands
    
    # analyze command
    analyze_parser = subparsers.add_parser('analyze', help='Analyze memory status')
    analyze_parser.add_argument('--age', type=int, metavar='N', 
                                help='Only analyze files within N days')
    analyze_parser.add_argument('--exclude', type=str, metavar='DIRS',
                                help='Directories to exclude (comma-separated)')
    
    # scan command
    scan_parser = subparsers.add_parser('scan', help='Scan workspace')
    scan_parser.add_argument('--exclude', type=str, metavar='DIRS',
                            help='Directories to exclude (comma-separated)')
    scan_parser.add_argument('--clean-empty-dirs', action='store_true',
                            help='Identify empty directories')
    
    # preview command
    preview_parser = subparsers.add_parser('preview', help='Generate cleanup preview')
    
    # clean command
    clean_parser = subparsers.add_parser('clean', help='Execute cleanup (requires confirmation)')
    clean_parser.add_argument('--force', action='store_true', help='Skip confirmation and execute')

    # archive command
    archive_parser = subparsers.add_parser('archive', help='Archive old memories (compress and move)')
    archive_parser.add_argument('--age', type=int, default=30, help='Archive files older than N days (default 30)')
    archive_parser.add_argument('--path', type=str, help='Specify archive directory')

    # html command
    html_parser = subparsers.add_parser('html', help='Generate HTML format report')
    html_parser.add_argument('--output', type=str, help='Output file path')

    # summarize command
    summarize_parser = subparsers.add_parser('summarize', help='Generate memory summaries')
    summarize_parser.add_argument('--file', type=str, help='Specify file (process all if not specified)')
    summarize_parser.add_argument('--regenerate', action='store_true', help='Force regeneration')

    # rank command
    rank_parser = subparsers.add_parser('rank', help='Memory importance ranking')

    # load command
    load_parser = subparsers.add_parser('load', help='Smart memory loading')
    load_parser.add_argument('--mode', type=str, default='normal',
                            choices=['brief', 'normal', 'full'], help='Load mode')
    load_parser.add_argument('--keyword', type=str, help='Keyword filter')
    load_parser.add_argument('--limit', type=int, default=10, help='Return count limit')

    # search command - keyword as option to avoid position conflict
    search_parser = subparsers.add_parser('search', help='Search memories')
    search_parser.add_argument('-k', '--keyword', dest='keyword', required=True, help='Search keyword')
    search_parser.add_argument('--mode', type=str, default='brief',
                              choices=['brief', 'normal', 'full'], help='Result mode')

    # config command V2.3
    config_parser = subparsers.add_parser('config', help='View/modify config')
    config_parser.add_argument('--key', type=str, help='Config key name')
    config_parser.add_argument('--value', type=str, help='New config value')

    # auto-clean command V2.4
    auto_clean_parser = subparsers.add_parser('auto-clean', help='Differentiated auto cleanup (push: next day, personal/work: every 5 days)')
    auto_clean_parser.add_argument('--dry-run', action='store_true', default=True,
                                 help='Preview mode (report only, no cleanup)')
    auto_clean_parser.add_argument('--execute', action='store_true',
                                 help='Execute mode (actually archive expired files)')
    auto_clean_parser.add_argument('--retention', type=int, metavar='N',
                                 help='Override default retention days (does not affect push/personal_work rules)')
    auto_clean_parser.add_argument('--content', type=str, default='all',
                                 choices=['all', 'push', 'personal_work', 'other'],
                                 help='Specify cleanup content type (default all)')

    args = parser.parse_args()
    
    # Default command
    if args.command is None:
        # Default to scan
        result = scan_workspace(args.workspace)
        print_report(result, "json" if args.json else "text")
        return
    
    # Parse exclude directories
    exclude_dirs = []
    if hasattr(args, 'exclude') and args.exclude:
        exclude_dirs = [d.strip() for d in args.exclude.split(',')]
    
    # Execute corresponding command
    if args.command == 'analyze':
        result = analyze_memory(
            args.workspace,
            age_days=args.age,
            exclude_patterns=exclude_dirs
        )
        print_memory_analysis(result, "json" if args.json else "text")
    
    elif args.command == 'dedup':
        handle_v25_command(args)
    elif args.command == 'stats':
        handle_v25_command(args)
    elif args.command == 'backup':
        handle_v25_command(args)
    elif args.command == 'schedule':
        handle_v25_command(args)
    elif args.command == 'doctor':
        handle_v25_command(args)
    elif args.command == 'wizard':
        handle_v25_command(args)
    elif args.command == 'feedback':
        handle_v25_command(args)
    elif args.command == 'scan':
        result = scan_workspace(
            args.workspace,
            exclude_dirs=exclude_dirs,
            clean_empty_dirs=args.clean_empty_dirs
        )
        print_report(result, "json" if args.json else "text")
    
    elif args.command == 'preview':
        result = generate_cleanup_preview(args.workspace, dry_run=True)
        print_preview(result)
    
    elif args.command == 'clean':
        # First preview files to clean
        preview = execute_cleanup(args.workspace, confirm=False)
        if preview.get("errors"):
            for err in preview["errors"]:
                print(f"{C['red']}[X] {err}{''}")
            return

        if preview.get("pending_delete", 0) > 0:
            print(f"\n{C['yellow']}Will clean {preview['pending_delete']} cleanable files{''}")
            print("This will permanently delete files. Make sure you have reviewed the preview.")
            print("Reply 'agree' to confirm:")
            user_input = input().strip()
            if user_input == 'agree':
                result = execute_cleanup(args.workspace, confirm=True)
                print(f"\n{C['green']}[OK] Cleaned {result['deleted_count']} files, freed {result['deleted_size_kb']:.1f} KB{''}")
            else:
                print(f"\n{C['red']}[X] Cleanup cancelled{''}")
        else:
            print(f"\n{C['green']}[OK] No files to clean{''}")

    elif args.command == 'archive':
        print(f"\n{C['cyan']}Archiving memories older than {args.age} days...{''}")
        # First preview (no delete)
        result = archive_old_memory(args.workspace, age_days=args.age, archive_path=args.path, confirm=False)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            print(f"\n{C['green']}[OK] Archived {result['archived_count']} files, freed {result['archived_size_kb']:.1f} KB")
            print(f"Archive location: {result['archive_path']}{''}")
            if result.get('pending_delete', 0) > 0:
                print(f"\n{C['yellow']}{result['pending_delete']} files pending original deletion")
                print("Reply 'agree' to confirm deletion of original files: ")
                user_input = input().strip()
                if user_input == 'agree':
                    # Call again to delete originals
                    result = archive_old_memory(args.workspace, age_days=args.age, archive_path=args.path, confirm=True)
                    print(f"\n{C['green']}[OK] Original files deleted{''}")
                else:
                    print(f"\n{C['yellow']}Original files retained, available in archive directory{''}")

    elif args.command == 'html':
        print(f"\n{C['cyan']}Generating HTML report...{''}")
        result = scan_workspace(args.workspace)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            output = generate_html_report(result, args.output)
            if args.output:
                print(f"\n{C['green']}[OK] HTML report saved: {output}{''}")
            else:
                # Open in browser
                import tempfile
                import webbrowser
                with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
                    f.write(generate_html_report(result))
                    temp_path = f.name
                webbrowser.open(f'file://{temp_path}')
                print(f"\n{C['green']}[OK] Report opened in browser{''}")

    elif args.command == 'summarize':
        print(f"\n{C['cyan']}Generating memory summaries...{''}")
        result = summarize_memory(args.workspace, file_name=args.file, regenerate=args.regenerate)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            print(f"\n{C['green']}[OK] Summary generation complete{C['reset']}")
            print(f"   Processed: {len(result['summarized'])} files")
            print(f"   Skipped: {len(result['skipped'])} files")
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.command == 'rank':
        print(f"\n{C['cyan']}Memory importance ranking...{''}")
        result = rank_memory(args.workspace)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            print(f"\n{C['bright']}{'='*50}{C['reset']}")
            print(f"{C['cyan']}Memory Ranking Report{C['reset']}")
            print(f"{'='*50}")

            stats = result["stats"]
            print(f"\nRanking Statistics:")
            print(f"   Total Memories: {stats['total']}")
            print(f"   {C['red']}Core:{C['reset']} {stats['core_count']}")
            print(f"   {C['yellow']}Normal:{C['reset']} {stats['normal_count']}")
            print(f"   {C['green']}Cold:{C['reset']} {stats['cold_count']}")

            if result.get("core"):
                print(f"\n{C['red']}Core Memories (>=70%):{C['reset']}")
                for item in result["core"][:5]:
                    print(f"   - {item['file']} ({item['score']} pts)")

            if result.get("normal"):
                print(f"\n{C['yellow']}Normal Memories (30-70%):{C['reset']}")
                for item in result["normal"][:5]:
                    print(f"   - {item['file']} ({item['score']} pts)")

            if result.get("cold"):
                print(f"\n{C['green']}Cold Memories (<30%):{C['reset']}")
                for item in result["cold"][:5]:
                    print(f"   - {item['file']} ({item['score']} pts)")

            print(f"\n{C['bright']}{'='*50}{C['reset']}")

    elif args.command == 'load':
        print(f"\n{C['cyan']}Smart memory loading...{''}")
        result = load_memory(args.workspace, mode=args.mode, keyword=args.keyword, limit=args.limit)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            print(f"\n{C['green']}[OK] Load complete{C['reset']}")
            print(f"   Mode: {result['mode']}")
            print(f"   Loaded: {len(result['loaded'])} memories")
            print(f"   Est. Tokens: ~{result['total_tokens_estimate']}")

            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(f"\n{C['bright']}--- Memory Content ---{C['reset']}")
                for item in result["loaded"][:5]:
                    print(f"\nFile: {item['file']} [{item['type']}]")
                    print(f"{item['content'][:300]}...")

    elif args.command == 'search':
        print(f"\n{C['cyan']}Searching memories: {args.keyword}{''}")
        result = search_memory(args.workspace, args.keyword, mode=args.mode)
        if "error" in result:
            print(f"{C['red']}[X] {result['error']}{''}")
        else:
            print(f"\nFound {result['total']} matches:")
            for item in result["matches"][:10]:
                print(f"\nFile: {item['file']} (Score: {item['score']})")
                print(f"   {item['preview'][:150]}...")

    # config command V2.4
    elif args.command == 'config':
        res = config_memory(args.workspace, key=args.key, value=args.value)
        if "error" in res:
            print(f"{C['red']}[X] {res['error']}{''}")
        elif res["action"] == "update":
            print(f"{C['green']}[OK] Config updated: {res['key']} = {res['value']}{''}")
        else:
            cfg = res["config"]
            print(f"\n{C['bright']}Memory Manager V{VERSION} Current Config{C['reset']}")
            print(f"{'='*50}")
            print(f"\n{C['bright']}Basic Config{C['reset']}")
            basic_keys = ["retention_days", "auto_remind_days", "auto_archive", "last_remind_date", "last_clean_date"]
            for k in basic_keys:
                if k in cfg:
                    default = DEFAULT_CONFIG.get(k, "")
                    v = cfg[k]
                    marker = "" if v == default else f" <- Default: {default}"
                    print(f"  {C['cyan']}{k}{C['reset']}: {C['yellow']}{v}{C['reset']}{marker}")

            print(f"\n{C['bright']}V2.4 Differentiated Cleanup Rules{C['reset']}")
            rules = cfg.get("_automation_rules", {})
            push = rules.get("push_content", {})
            pw = rules.get("personal_work_content", {})
            print(f"  {C['green']}Push Content{C['reset']}: Auto-clean after {push.get('retention_days',1)} days | Keywords: {', '.join(push.get('keywords',[]))}")
            print(f"  {C['yellow']}Personal/Work{C['reset']}: No auto-clean, remind every {pw.get('remind_days',5)} days | Keywords: {', '.join(pw.get('keywords',[]))}")
            print(f"{'='*50}")
            print(f"\nExample: config --key retention_days --value 3")

    # auto-clean command V2.4
    elif args.command == 'auto-clean':
        # Temporarily override retention days
        if args.retention:
            cfg = load_config()
            cfg["retention_days"] = args.retention
            save_config(cfg)
        dry_run = not args.execute
        mode_label = "Preview" if dry_run else "Execute"
        print(f"\n{C['cyan']}Differentiated Auto Cleanup [{mode_label} Mode]{''}")
        res = auto_clean_memory(args.workspace, dry_run=dry_run, content_filter=args.content)
        if "error" in res:
            print(f"{C['red']}[X] {res['error']}{''}")
        else:
            summary = res.get("clean_summary", {})
            print(f"\n{C['bright']}Differentiated Cleanup Report{C['reset']}")
            print(f"{'='*50}")
            print(f"  Push Auto-clean: Archive after {C['yellow']}{res['push_auto_clean_days']}{C['reset']} days")
            print(f"  Personal/Work Reminder: Every {C['yellow']}{res['personal_work_remind_days']}{C['reset']} days")
            print(f"  Default Others: Archive after {C['yellow']}{res['retention_days']}{C['reset']} days")
            print(f"  Auto Archive: {'ON' if res['auto_archive'] else 'OFF'}")
            if args.content != 'all':
                print(f"  Content Filter: {C['cyan']}{args.content}{C['reset']}")

            # Cleanup summary
            print(f"\n{C['bright']}Cleanup Summary{C['reset']}")
            print(f"  Push Archived: {C['green']}{summary.get('push_auto_clean', 0)}{C['reset']}")
            print(f"  Personal/Work Pending: {C['yellow']}{summary.get('personal_work_to_remind', 0)}{C['reset']}")
            print(f"  Others Archived: {C['cyan']}{summary.get('other_archived', 0)}{C['reset']}")

            # Personal/work reminder
            if res.get("remind_files"):
                print(f"\n{C['yellow']}Personal/Work Content Pending Confirmation ({len(res['remind_files'])}):{C['reset']}")
                for f in res["remind_files"][:10]:
                    print(f"   - {f['name']} ( {f['age_days']} days ago | {f['size_kb']}KB)")
                if len(res["remind_files"]) > 10:
                    print(f"   ... and {len(res['remind_files'])-10} more")
                print(f"\n{C['yellow']}Reply 'agree' to clean these files, otherwise keep{C['reset']}")

            # About to archive
            if res.get("files_to_archive"):
                print(f"\n{C['red']}Will Archive ({len(res['files_to_archive'])}):{C['reset']}")
                for f in res["files_to_archive"][:10]:
                    print(f"   - {f['name']} ( {f['age_days']} days ago | {f['size_kb']}KB | {f.get('type', '?')})")
                if len(res["files_to_archive"]) > 10:
                    print(f"   ... and {len(res['files_to_archive'])-10} more")

            # Kept files
            if res.get("kept_files"):
                print(f"\n{C['green']}Kept Files ({len(res['kept_files'])}):{C['reset']}")
                for f in res["kept_files"][:5]:
                    reason = f.get('reason', '')
                    print(f"   - {f['name']} ( {f.get('age_days', 0)} days | {reason})")
                if len(res["kept_files"]) > 5:
                    print(f"   ... and {len(res['kept_files'])-5} more")

            if dry_run:
                print(f"\n{C['yellow']}Preview mode, add --execute to execute{C['reset']}")
            else:
                print(f"\n{C['green']}[OK] Archived {res['files_archived']} files, freed {res['size_freed_kb']:.1f} KB{''}")
                if res['errors']:
                    print(f"{C['red']}Warnings: {res['errors']}{''}")


if __name__ == "__main__":
    main()
