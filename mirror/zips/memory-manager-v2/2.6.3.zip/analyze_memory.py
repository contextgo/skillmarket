#!/usr/bin/env python3
"""
记忆管家 - 记忆分析脚本
分析WorkBuddy记忆文件状态，生成报告
"""

import os
import sys
from pathlib import Path
from datetime import datetime, timedelta
import json

def analyze_memory(workspace_path: str) -> dict:
    """分析工作记忆目录"""
    memory_path = Path(workspace_path) / ".workbuddy" / "memory"
    
    if not memory_path.exists():
        return {"error": "记忆目录不存在", "files": [], "stats": {}}
    
    files_info = []
    total_size = 0
    file_count = 0
    
    # 遍历所有md文件
    for md_file in memory_path.glob("*.md"):
        stat = md_file.stat()
        size_kb = stat.st_size / 1024
        mtime = datetime.fromtimestamp(stat.st_mtime)
        
        files_info.append({
            "name": md_file.name,
            "size_kb": round(size_kb, 2),
            "modified": mtime.strftime("%Y-%m-%d"),
            "path": str(md_file)
        })
        total_size += size_kb
        file_count += 1
    
    # 按修改时间排序
    files_info.sort(key=lambda x: x["modified"], reverse=True)
    
    # 分析内容
    memory_content = ""
    recent_logs = []
    
    # 读取MEMORY.md
    memory_file = memory_path / "MEMORY.md"
    if memory_file.exists():
        with open(memory_file, "r", encoding="utf-8") as f:
            memory_content = f.read()
    
    # 读取最近7天日志
    for f in files_info:
        if f["name"] != "MEMORY.md":
            days_ago = (datetime.now() - datetime.strptime(f["modified"], "%Y-%m-%d")).days
            if days_ago <= 7:
                file_path = Path(f["path"])
                with open(file_path, "r", encoding="utf-8") as fp:
                    recent_logs.append({
                        "name": f["name"],
                        "content": fp.read(),
                        "modified": f["modified"]
                    })
    
    # 生成摘要
    summary = {
        "project_context": extract_section(memory_content, "项目背景", "##"),
        "user_profile": extract_section(memory_content, "用户", "##"),
        "recent_activities": [log["modified"] for log in recent_logs]
    }
    
    return {
        "files": files_info,
        "stats": {
            "total_files": file_count,
            "total_size_kb": round(total_size, 2),
            "memory_size_kb": round(memory_file.stat().st_size / 1024, 2) if memory_file.exists() else 0
        },
        "summary": summary,
        "recommendations": generate_recommendations(files_info, total_size)
    }

def extract_section(content: str, keyword: str, prefix: str = "##") -> str:
    """提取内容章节"""
    lines = content.split("\n")
    result = []
    capture = False
    
    for line in lines:
        if line.strip().startswith(f"{prefix} {keyword}") or line.strip().startswith(f"{prefix}*{keyword}"):
            capture = True
            continue
        if capture and line.strip().startswith(prefix):
            break
        if capture:
            result.append(line)
    
    return "\n".join(result[:5])  # 只取前5行

def generate_recommendations(files: list, total_size: float) -> list:
    """生成优化建议"""
    recs = []
    
    if total_size > 100:
        recs.append("💡 记忆文件较大(>100KB)，建议清理过期日志")
    
    if len(files) > 20:
        recs.append("📁 文件数量较多，建议合并或归档旧日志")
    
    # 检查30天前的文件
    old_files = []
    for f in files:
        if f["name"] != "MEMORY.md":
            days_ago = (datetime.now() - datetime.strptime(f["modified"], "%Y-%m-%d")).days
            if days_ago > 30:
                old_files.append(f["name"])
    
    if old_files:
        recs.append(f"📅 有 {len(old_files)} 个30天前的日志可归档")
    
    if not recs:
        recs.append("✨ 记忆状态良好，无需清理")
    
    return recs

if __name__ == "__main__":
    workspace = sys.argv[1] if len(sys.argv) > 1 else "."
    result = analyze_memory(workspace)
    print(json.dumps(result, ensure_ascii=False, indent=2))
