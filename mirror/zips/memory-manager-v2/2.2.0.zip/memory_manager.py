#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆管家 V2.0 - AI效率工具
智能管理记忆与文件，减少Token消耗

主要功能:
- 记忆分析：分析记忆文件状态，支持年龄过滤
- 工作空间扫描：扫描.workbuddy目录，识别可清理内容
- 图片识别：快速识别7种图片格式（仅读16字节头）
- 智能清理：预览确认，安全不误删
- 空目录清理：清理无内容的空目录

作者: 可乐138
版本: 2.0.1
"""

import argparse
import json
import os
import sys
import shutil
import gzip
from datetime import datetime
from pathlib import Path
from typing import Optional

# ============ 跨平台初始化 ============
# 确保stdout/stderr在Windows下支持UTF-8输出
if sys.platform == 'win32':
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        # 尝试导入colorama（Windows颜色支持）
        try:
            from colorama import init, Fore, Style
            init(autoreset=True)
            COLOR_SUPPORT = True
        except ImportError:
            COLOR_SUPPORT = False
    except Exception:
        COLOR_SUPPORT = False
else:
    try:
        from colorama import init, Fore, Style
        init(autoreset=True)
        COLOR_SUPPORT = True
    except ImportError:
        COLOR_SUPPORT = False

# ============ 常量定义 ============
VERSION = "2.2.0"  # V2.2 摘要+分级功能
PROTECTED_DIRS = {'memory', '.workbuddy', '.skills', 'skills'}
CLEANABLE_EXTS = {'.tmp', '.log', '.cache', '.bak', '.temp', '.swp', '.pyc', '__pycache__'}
IMAGE_SIGNATURES = {
    'png': b'\x89PNG\r\n\x1a\n',
    'jpg': b'\xff\xd8\xff',
    'gif': b'GIF87a',
    'gif89': b'GIF89a',
    'bmp': b'BM',
    'webp': b'RIFF',
    'ico': b'\x00\x00\x01\x00',
}
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.ico'}

# 安全限制
MAX_FILE_SIZE = 1 * 1024 * 1024  # 1MB
MAX_TOTAL_READ = 5 * 1024 * 1024  # 5MB
MAX_REPORT_ITEMS = 1000

# 摘要配置
SUMMARY_DIR = ".summary"  # 摘要缓存目录
SUMMARY_MAX_CHARS = 300   # 摘要最大字符数
SUMMARY_INDEX_FILE = "summary_index.json"  # 摘要索引文件

# 重要性分级阈值
RANK_CORE_THRESHOLD = 0.7   # 核心记忆阈值 (>=70%)
RANK_NORMAL_THRESHOLD = 0.3  # 普通记忆阈值 (>=30%)
# 低于30% = 冷门记忆 → 归档

# 加载模式
LOAD_BRIEF = "brief"   # 只加载摘要 (~200字)
LOAD_NORMAL = "normal"  # 摘要 + 关键段落 (~2KB)
LOAD_FULL = "full"      # 完整文件

# 颜色支持
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    C = {
        'red': Fore.RED, 'green': Fore.GREEN, 'yellow': Fore.YELLOW,
        'cyan': Fore.CYAN, 'magenta': Fore.MAGENTA, 'white': Fore.WHITE,
        'bright': Style.BRIGHT, 'reset': Style.RESET_ALL
    }
except ImportError:
    C = {k: '' for k in ['red', 'green', 'yellow', 'cyan', 'magenta', 'white', 'bright', 'reset']}


# ============ 安全函数 ============
def is_symlink(path: Path) -> bool:
    """检查是否为符号链接"""
    try:
        return path.is_symlink()
    except (OSError, ValueError):
        return False


def safe_resolve(path: Path, base_path: Path) -> Optional[Path]:
    """
    安全路径解析：确保路径在基础目录内，防止路径遍历攻击
    
    Args:
        path: 要检查的路径
        base_path: 允许的基础目录
    
    Returns:
        解析后的绝对路径，如果超出范围则返回None
    """
    try:
        # 解析为绝对路径并规范化
        abs_path = path.resolve()
        abs_base = base_path.resolve()
        
        # 检查是否在基础目录内
        try:
            abs_path.relative_to(abs_base)
            return abs_path
        except ValueError:
            # 路径超出基础目录
            return None
    except (OSError, ValueError):
        return None


def safe_file_read(path: Path, max_size: int = MAX_FILE_SIZE) -> tuple[Optional[str], str]:
    """
    安全读取文件内容
    返回: (内容, 状态信息)
    """
    try:
        # 安全检查
        if is_symlink(path):
            return None, "跳过符号链接"
        
        stat = path.stat()
        if stat.st_size > max_size:
            return None, f"文件超过{max_size//1024}KB限制"
        
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(max_size)
            return content, "成功"
    except Exception as e:
        return None, f"读取失败: {type(e).__name__}"


def get_file_info(path: Path) -> tuple[Optional[datetime], Optional[int]]:
    """
    获取文件修改时间和大小（单次stat调用）
    
    Returns:
        (mtime, size_kb) 或 (None, None) 如果失败
    """
    try:
        stat = path.stat()
        return datetime.fromtimestamp(stat.st_mtime), stat.st_size / 1024
    except (OSError, ValueError):
        return None, None


# ============ 进度条支持 ============
def get_progress_bar():
    """获取进度条（优先使用tqdm，否则使用简单实现）"""
    try:
        from tqdm import tqdm
        return tqdm
    except ImportError:
        # 简单进度条替代
        class SimpleProgress:
            def __init__(self, total, desc=''):
                self.total = total
                self.n = 0
                self.desc = desc
            def __enter__(self):
                return self

def detect_image_format(file_path: Path) -> Optional[str]:
    """
    通过文件头识别图片格式（仅读16字节）
    支持: PNG, JPG, GIF, BMP, WebP, ICO
    """
    try:
        with open(file_path, 'rb') as f:
            header = f.read(16)
        
        for fmt, sig in IMAGE_SIGNATURES.items():
            if header.startswith(sig):
                # WebP需要额外检查
                if fmt == 'webp':
                    if len(header) >= 12 and header[8:12] == b'WEBP':
                        return 'webp'
                    continue
                return fmt
        return None
    except (OSError, IOError):
        return None


# ============ 记忆分析 ============
def analyze_memory(
    workspace_path: str,
    age_days: Optional[int] = None,
    exclude_patterns: Optional[list] = None
) -> dict:
    """
    分析工作记忆目录
    
    Args:
        workspace_path: 工作目录路径
        age_days: 只分析N天内的文件（可选）
        exclude_patterns: 排除的目录模式（可选）
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0
        },
        "recommendations": []
    }
    
    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result
    
    if exclude_patterns is None:
        exclude_patterns = []
    
    total_read = 0
    
    try:
        for md_file in memory_path.glob("*.md"):
            # 安全检查：符号链接 + 路径遍历
            if is_symlink(md_file):
                continue
            if safe_resolve(md_file, memory_path) is None:
                continue
            
            # 获取文件信息（单次stat）
            mtime, size_kb = get_file_info(md_file)
            if mtime is None:
                continue
            
            # 年龄过滤
            age = (datetime.now() - mtime).days
            if age_days is not None and age > age_days:
                continue
            
            # 累计读取限制
            file_size = int(size_kb * 1024)
            if total_read + file_size > MAX_TOTAL_READ:
                result["warning"] = f"已达到读取上限{MAX_TOTAL_READ//1024}KB，报告可能被截断"
                break
            
            # 判断是否可清理（30天以上的非MEMORY.md文件）
            is_cleanable = (
                md_file.name != "MEMORY.md" and 
                age > 30
            )
            
            file_info = {
                "name": md_file.name,
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "age_days": age,
                "cleanable": is_cleanable
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            
            # 限制报告数量
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"文件数量超过{MAX_REPORT_ITEMS}条限制"
                break
        
        # 生成建议
        result["recommendations"] = _generate_recommendations(result["files"], result["stats"])
        
    except Exception as e:
        result["error"] = f"分析失败: {type(e).__name__}: {str(e)}"
    
    return result


# ============ 工作空间扫描 ============
def scan_workspace(
    workspace_path: str,
    exclude_dirs: Optional[list] = None,
    clean_empty_dirs: bool = False
) -> dict:
    """
    扫描工作空间，生成存储报告
    
    Args:
        workspace_path: 工作目录路径
        exclude_dirs: 排除的目录列表
        clean_empty_dirs: 是否识别空目录
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "empty_dirs": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0,
            "protected_size_kb": 0
        },
        "recommendations": []
    }
    
    if not workbuddy_path.exists():
        result["error"] = ".workbuddy目录不存在"
        return result
    
    if exclude_dirs is None:
        exclude_dirs = []
    
    for file_path in workbuddy_path.rglob("*"):
        # 安全检查：符号链接 + 路径遍历
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue
        
        if file_path.is_file():
            # 获取文件信息（单次stat）
            mtime, size_kb = get_file_info(file_path)
            if mtime is None:
                continue
            
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""
            
            # 检查是否受保护
            is_protected = (
                parent_dir in PROTECTED_DIRS or
                any(ex in str(rel_path) for ex in exclude_dirs)
            )
            
            # 检查是否可清理
            is_cleanable = (
                not is_protected and
                (
                    file_path.suffix.lower() in CLEANABLE_EXTS or
                    'cache' in file_path.name.lower() or
                    'temp' in file_path.name.lower()
                )
            )
            
            # 图片检测（仅对图片后缀且小于5MB的文件）
            image_format = None
            if file_path.suffix.lower() in IMAGE_EXTENSIONS:
                file_size_kb = int(size_kb)
                if file_size_kb < 5000:  # 小于5MB才检测
                    image_format = detect_image_format(file_path)
            
            file_info = {
                "name": file_path.name,
                "path": str(rel_path),
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "protected": is_protected,
                "cleanable": is_cleanable,
                "image_format": image_format
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            elif is_protected:
                result["stats"]["protected_size_kb"] += size_kb
            
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"文件数量超过{MAX_REPORT_ITEMS}条限制"
                break
        
        elif clean_empty_dirs and file_path.is_dir():
            # 检查空目录
            try:
                if not any(file_path.iterdir()):
                    result["empty_dirs"].append(str(file_path.relative_to(workbuddy_path)))
            except (OSError, PermissionError):
                continue
    
    # 按大小排序
    result["files"].sort(key=lambda x: x["size_kb"], reverse=True)
    
    # Token预估
    token_saving = int(result["stats"]["cleanable_size_kb"] * 300)
    result["stats"]["estimated_token_saving"] = token_saving
    
    # 生成建议
    result["recommendations"] = _generate_scan_recommendations(
        result["stats"],
        len(result["empty_dirs"])
    )
    
    return result


# ============ 清理预览 ============
def generate_cleanup_preview(
    workspace_path: str,
    dry_run: bool = True
) -> dict:
    """
    生成清理预览（dry run模式）

    Args:
        workspace_path: 工作目录路径
        dry_run: True则不实际删除
    """
    scan_result = scan_workspace(workspace_path)

    preview = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "dry_run": dry_run,
        "files_to_clean": [],
        "total_size_kb": 0,
        "token_saving": 0,
        "message": ""
    }

    if "error" in scan_result:
        preview["error"] = scan_result["error"]
        return preview

    for f in scan_result["files"]:
        if f["cleanable"]:
            preview["files_to_clean"].append(f)
            preview["total_size_kb"] += f["size_kb"]

    preview["token_saving"] = int(preview["total_size_kb"] * 300)

    if dry_run:
        preview["message"] = f"预览模式：{len(preview['files_to_clean'])}个文件({preview['total_size_kb']:.1f}KB)，确认执行请回复'同意'"
    else:
        preview["message"] = f"将删除{len(preview['files_to_clean'])}个文件"

    return preview


# ============ P0: 实际清理执行 ============
def execute_cleanup(workspace_path: str) -> dict:
    """
    执行实际清理操作（P0修复）

    Returns:
        清理结果统计
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"

    result = {
        "deleted_count": 0,
        "deleted_size_kb": 0,
        "failed_count": 0,
        "errors": []
    }

    if not workbuddy_path.exists():
        result["errors"].append(".workbuddy目录不存在")
        return result

    # 扫描可清理文件
    files_to_delete = []
    for file_path in workbuddy_path.rglob("*"):
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue

        if file_path.is_file():
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""

            # 检查是否受保护
            if parent_dir in PROTECTED_DIRS:
                continue

            # 检查是否可清理
            is_cleanable = (
                file_path.suffix.lower() in CLEANABLE_EXTS or
                'cache' in file_path.name.lower() or
                'temp' in file_path.name.lower()
            )

            if is_cleanable:
                files_to_delete.append(file_path)

    # 批量删除（带进度条）
    print(f"\n开始清理 {len(files_to_delete)} 个文件...")

    for file_path in files_to_delete:
        try:
            mtime, size_kb = get_file_info(file_path)
            file_path.unlink()
            result["deleted_count"] += 1
            result["deleted_size_kb"] += size_kb if size_kb else 0
        except Exception as e:
            result["failed_count"] += 1
            result["errors"].append(f"{file_path.name}: {str(e)}")

    return result


# ============ P1: 归档功能 ============
def archive_old_memory(
    workspace_path: str,
    age_days: int = 30,
    archive_path: Optional[str] = None
) -> dict:
    """
    归档旧记忆文件（P1功能）

    Args:
        workspace_path: 工作目录路径
        age_days: 归档超过N天的文件
        archive_path: 归档目录路径（默认: .workbuddy/archive）
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if archive_path is None:
        archive_dir = base_path / ".workbuddy" / "archive"
    else:
        archive_dir = Path(archive_path)

    # 创建归档目录
    archive_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "archived_count": 0,
        "archived_size_kb": 0,
        "failed_count": 0,
        "archive_path": str(archive_dir)
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 扫描旧文件
    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        # 跳过MEMORY.md和不超龄文件
        if md_file.name == "MEMORY.md":
            continue
        age = (datetime.now() - mtime).days
        if age <= age_days:
            continue

        try:
            # 压缩归档
            archive_name = f"{md_file.stem}_{mtime.strftime('%Y%m%d')}.md.gz"
            archive_file = archive_dir / archive_name

            with open(md_file, 'rb') as f_in:
                with gzip.open(archive_file, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)

            # 删除原文件
            md_file.unlink()

            result["archived_count"] += 1
            result["archived_size_kb"] += size_kb
        except Exception as e:
            result["failed_count"] += 1

    return result


# ============ P0: 摘要生成 ============
def extract_keywords(content: str, max_keywords: int = 5) -> list:
    """
    提取关键词（简单实现：统计高频词）

    Args:
        content: 文件内容
        max_keywords: 最大关键词数量

    Returns:
        关键词列表
    """
    import re
    # 简单分词
    words = re.findall(r'[\w]{2,}', content.lower())
    # 停用词
    stopwords = {'的', '了', '是', '在', '和', '与', '或', '等', '于', '对', '这', '那', '有', '我', '你', '他', '她', '它', '们', '一个', '我们', '他们', '这个', '什么', '如何', '怎么', '可以', '需要', '如果', '因为', '所以', '但是', '而且', '或者', '以及', '对于', '关于', '通过', '使用', '进行', '实现', '完成', '开始', '结束', '之后', '之前', '时候', '情况', '问题', '方法', '内容', '文件', '功能', '支持'}
    # 过滤停用词
    words = [w for w in words if w not in stopwords and len(w) > 1]
    # 统计频率
    from collections import Counter
    counter = Counter(words)
    return [w for w, _ in counter.most_common(max_keywords)]


def generate_summary(content: str, max_chars: int = SUMMARY_MAX_CHARS) -> str:
    """
    生成摘要（规则-based实现，减少TOKEN消耗）

    策略：
    1. 提取第一段作为概述
    2. 提取带#的标题行
    3. 提取关键结论
    """
    lines = content.split('\n')
    summary_parts = []

    # 1. 提取标题
    headers = [l.strip() for l in lines if l.strip().startswith('#') and len(l) < 100]
    if headers:
        summary_parts.extend(headers[:3])

    # 2. 提取无序列表项（通常是关键点）
    bullets = [l.strip().lstrip('-*').strip() for l in lines
              if l.strip().startswith(('-', '*')) and len(l) > 5]
    if bullets:
        summary_parts.extend(bullets[:5])

    # 3. 提取表格第一行（通常是重要信息）
    tables = []
    in_table = False
    for l in lines:
        if '|' in l and l.count('|') >= 2:
            if not in_table:
                tables.append(l.strip())
                in_table = True
        else:
            in_table = False

    # 4. 如果摘要太短，添加第一段
    summary = '\n'.join(summary_parts)
    if len(summary) < 100 and lines:
        # 找第一段非空文字
        for l in lines:
            if l.strip() and not l.strip().startswith('#'):
                para = l.strip()[:max_chars]
                if len(summary) < max_chars:
                    summary += '\n' + para

    # 截断到最大长度
    if len(summary) > max_chars:
        summary = summary[:max_chars] + '...'

    return summary.strip()


def summarize_memory(
    workspace_path: str,
    file_name: Optional[str] = None,
    regenerate: bool = False
) -> dict:
    """
    摘要生成功能（P0核心）

    Args:
        workspace_path: 工作目录路径
        file_name: 指定文件（None则处理所有）
        regenerate: 是否强制重新生成

    Returns:
        摘要结果
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    # 创建摘要目录
    summary_path.mkdir(parents=True, exist_ok=True)

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "summarized": [],
        "skipped": [],
        "errors": []
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 处理单个文件
    def process_file(md_file: Path) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        # 检查缓存
        summary_file = summary_path / f"{md_file.stem}.summary"

        if summary_file.exists() and not regenerate:
            # 读取缓存
            with open(summary_file, 'r', encoding='utf-8') as f:
                return json.loads(f.read())

        # 读取原文件
        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # 生成摘要
        summary = generate_summary(content)
        keywords = extract_keywords(content)

        mtime, size_kb = get_file_info(md_file)

        summary_data = {
            "file": md_file.name,
            "summary": summary,
            "keywords": keywords,
            "size_kb": size_kb,
            "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
            "generated": datetime.now().isoformat(),
            "token_estimate": len(summary) // 4  # 粗略估算
        }

        # 保存缓存
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=2)

        return summary_data

    # 处理文件
    if file_name:
        md_file = memory_path / file_name
        if not md_file.exists():
            result["error"] = f"文件不存在: {file_name}"
            return result
        data = process_file(md_file)
        if data:
            result["summarized"].append(data)
        else:
            result["errors"].append(f"处理失败: {file_name}")
    else:
        # 处理所有md文件
        for md_file in memory_path.glob("*.md"):
            data = process_file(md_file)
            if data:
                result["summarized"].append(data)
            else:
                result["skipped"].append(md_file.name)

    return result


# ============ P0: 重要性分级 ============
def rank_memory(
    workspace_path: str,
    weights: Optional[dict] = None
) -> dict:
    """
    记忆重要性分级（P0核心）

    评分维度：
    - 访问频率 (40%): 最近访问次数越多越重要
    - 时间衰减 (30%): 新记忆权重更高
    - 内容长度 (15%): 内容适中最重要（过短无意义，过长冗余）
    - 关键词匹配 (15%): 匹配用户关注领域

    分级结果：
    - 核心记忆 (>=70%): 全部加载
    - 普通记忆 (30%-70%): 摘要加载
    - 冷门记忆 (<30%): 归档压缩
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if weights is None:
        weights = {"access": 0.4, "recency": 0.3, "length": 0.15, "keywords": 0.15}

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "core": [],
        "normal": [],
        "cold": [],
        "stats": {
            "total": 0,
            "core_count": 0,
            "normal_count": 0,
            "cold_count": 0
        }
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 读取摘要索引（如果有）
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR
    index_file = summary_path / SUMMARY_INDEX_FILE
    access_counts = {}

    if index_file.exists():
        with open(index_file, 'r', encoding='utf-8') as f:
            index_data = json.load(f)
            access_counts = index_data.get("access_counts", {})

    # 评分每个文件
    memory_scores = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file) or md_file.name == "MEMORY.md":
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        age_days = (datetime.now() - mtime).days
        size_kb = size_kb or 0

        # 1. 访问频率得分 (0-100)
        access_count = access_counts.get(md_file.name, 0)
        access_score = min(100, access_count * 20)  # 每次访问+20，最高100

        # 2. 时间衰减得分 (0-100) - 越新越高
        recency_score = max(0, 100 - age_days * 2)  # 每天-2分

        # 3. 内容长度得分 (0-100) - 1-10KB最佳
        if size_kb < 0.5:
            length_score = size_kb * 100  # 太短
        elif size_kb > 10:
            length_score = max(0, 100 - (size_kb - 10) * 5)  # 太长
        else:
            length_score = 100  # 最佳范围

        # 4. 关键词匹配得分 (如果有摘要)
        keyword_score = 50  # 默认
        summary_file = summary_path / f"{md_file.stem}.summary"
        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)
                # 如果有关键词，额外加分
                keywords = summary_data.get("keywords", [])
                if keywords:
                    keyword_score = 70  # 有摘要的稍微加分

        # 综合得分
        total_score = (
            access_score * weights["access"] +
            recency_score * weights["recency"] +
            length_score * weights["length"] +
            keyword_score * weights["keywords"]
        ) / 100

        # 分级
        memory_info = {
            "file": md_file.name,
            "score": round(total_score, 2),
            "size_kb": round(size_kb, 2),
            "age_days": age_days,
            "modified": mtime.strftime("%Y-%m-%d"),
            "details": {
                "access_score": round(access_score, 1),
                "recency_score": round(recency_score, 1),
                "length_score": round(length_score, 1),
                "keyword_score": round(keyword_score, 1)
            }
        }

        if total_score >= RANK_CORE_THRESHOLD * 100:
            result["core"].append(memory_info)
        elif total_score >= RANK_NORMAL_THRESHOLD * 100:
            result["normal"].append(memory_info)
        else:
            result["cold"].append(memory_info)

        memory_scores.append(total_score)

    # 统计
    result["stats"]["total"] = len(memory_scores)
    result["stats"]["core_count"] = len(result["core"])
    result["stats"]["normal_count"] = len(result["normal"])
    result["stats"]["cold_count"] = len(result["cold"])

    # 按分数排序
    result["core"].sort(key=lambda x: x["score"], reverse=True)
    result["normal"].sort(key=lambda x: x["score"], reverse=True)
    result["cold"].sort(key=lambda x: x["score"], reverse=True)

    return result


# ============ P0: 智能加载 ============
def load_memory(
    workspace_path: str,
    mode: str = LOAD_NORMAL,
    keyword: Optional[str] = None,
    limit: int = 10
) -> dict:
    """
    智能加载记忆（P0核心）

    Args:
        workspace_path: 工作目录路径
        mode: 加载模式 (brief/normal/full)
        keyword: 关键词过滤
        limit: 返回数量限制

    Returns:
        加载的记忆内容
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "mode": mode,
        "loaded": [],
        "total_tokens_estimate": 0
    }

    # 先做分级
    rank_result = rank_memory(workspace_path)

    # 根据分级和模式决定加载哪些
    def load_file(md_file: Path, load_mode: str) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            return None

        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # 根据模式决定加载内容
        if load_mode == LOAD_BRIEF:
            # 只加载摘要
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    return {
                        "file": md_file.name,
                        "type": "summary",
                        "content": summary_data.get("summary", ""),
                        "keywords": summary_data.get("keywords", []),
                        "modified": mtime.strftime("%Y-%m-%d"),
                        "token_estimate": summary_data.get("token_estimate", 0)
                    }
            else:
                # 无摘要，生成一个
                summary = generate_summary(content, 200)
                return {
                    "file": md_file.name,
                    "type": "summary",
                    "content": summary,
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        elif load_mode == LOAD_NORMAL:
            # 摘要 + 关键段落
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    summary = summary_data.get("summary", "")
                # 追加部分原文
                lines = content.split('\n')
                key_lines = [l for l in lines if l.strip().startswith(('-', '*'))][:5]
                extra = '\n'.join(key_lines)
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": summary + ("\n\n关键要点:\n" + extra if extra else ""),
                    "keywords": summary_data.get("keywords", []),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4 + len(extra) // 4
                }
            else:
                summary = generate_summary(content, 500)
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": summary,
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        else:  # full
            return {
                "file": md_file.name,
                "type": "full",
                "content": content,
                "modified": mtime.strftime("%Y-%m-%d"),
                "token_estimate": len(content) // 4
            }

    # 优先加载核心记忆
    files_to_load = []

    # 核心记忆 → 全部加载
    for item in rank_result.get("core", [])[:limit]:
        files_to_load.append((memory_path / item["file"], LOAD_FULL))

    # 普通记忆 → 摘要加载
    normal_limit = limit - len(files_to_load)
    for item in rank_result.get("normal", [])[:max(0, normal_limit)]:
        files_to_load.append((memory_path / item["file"], mode))

    # 冷门记忆 → 全部摘要
    cold_limit = limit - len(files_to_load)
    for item in rank_result.get("cold", [])[:max(0, cold_limit)]:
        files_to_load.append((memory_path / item["file"], LOAD_BRIEF))

    # 关键词过滤
    if keyword:
        keyword = keyword.lower()
        files_to_load = [
            (f, m) for f, m in files_to_load
            if keyword in f.name.lower() or (summary_path / f"{f.stem}.summary").exists()
        ]

    # 加载
    for md_file, load_mode in files_to_load:
        data = load_file(md_file, load_mode)
        if data:
            result["loaded"].append(data)
            result["total_tokens_estimate"] += data.get("token_estimate", 0)

    return result


# ============ P1: 搜索功能 ============
def search_memory(
    workspace_path: str,
    keyword: str,
    mode: str = "brief"
) -> dict:
    """
    记忆搜索功能（P1）

    Args:
        workspace_path: 工作目录路径
        keyword: 搜索关键词
        mode: 搜索模式 (brief/normal/full)

    Returns:
        搜索结果
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "keyword": keyword,
        "matches": [],
        "total": 0
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    keyword_lower = keyword.lower()
    matches = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        # 先检查摘要（快速）
        summary_file = summary_path / f"{md_file.stem}.summary"
        score = 0

        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)

            # 检查关键词匹配
            if keyword_lower in summary_data.get("summary", "").lower():
                score += 10
            if keyword_lower in " ".join(summary_data.get("keywords", [])).lower():
                score += 20
        else:
            # 无摘要，读取原文
            content, _ = safe_file_read(md_file)
            if content and keyword_lower in content.lower():
                score = 5
            else:
                continue

        if score > 0:
            mtime, size_kb = get_file_info(md_file)

            # 根据模式决定返回内容
            if mode == LOAD_BRIEF:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")[:200]
            elif mode == LOAD_NORMAL:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")
            else:
                content, _ = safe_file_read(md_file)
                content_preview = content[:500] if content else ""

            matches.append({
                "file": md_file.name,
                "score": score,
                "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
                "preview": content_preview,
                "size_kb": round(size_kb, 2) if size_kb else 0
            })

    # 按分数排序
    matches.sort(key=lambda x: x["score"], reverse=True)
    result["matches"] = matches
    result["total"] = len(matches)

    return result


# ============ P2: HTML报告生成 ============
def generate_html_report(result: dict, output_path: Optional[str] = None) -> str:
    """
    生成HTML格式的存储报告（P2功能）
    """
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>记忆管家 V{VERSION} - 存储报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; background: #f5f5f5; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; }}
        .stat-card.green {{ background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }}
        .stat-card.orange {{ background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }}
        .stat-card h3 {{ margin: 0 0 10px; font-size: 14px; opacity: 0.9; }}
        .stat-card .value {{ font-size: 28px; font-weight: bold; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #3498db; color: white; }}
        tr:hover {{ background: #f8f9fa; }}
        .badge {{ display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
        .badge-protected {{ background: #e74c3c; color: white; }}
        .badge-cleanable {{ background: #27ae60; color: white; }}
        .footer {{ text-align: center; color: #999; margin-top: 30px; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧠 记忆管家 V{VERSION} - 存储报告</h1>
        <p>📁 {result.get('workspace', 'N/A')} | ⏰ {result.get('timestamp', 'N/A')[:19]}</p>

        <div class="stats">
            <div class="stat-card">
                <h3>📁 总文件数</h3>
                <div class="value">{result['stats'].get('total_files', 0)}</div>
            </div>
            <div class="stat-card green">
                <h3>💾 总占用</h3>
                <div class="value">{result['stats'].get('total_size_kb', 0):.1f} KB</div>
            </div>
            <div class="stat-card orange">
                <h3>🗑️ 可清理</h3>
                <div class="value">{result['stats'].get('cleanable_size_kb', 0):.1f} KB</div>
            </div>
        </div>

        <h2>📋 文件列表</h2>
        <table>
            <thead>
                <tr>
                    <th>文件名</th>
                    <th>大小</th>
                    <th>修改时间</th>
                    <th>状态</th>
                </tr>
            </thead>
            <tbody>
"""

    for f in result.get('files', [])[:50]:
        status = '<span class="badge badge-protected">🔒 受保护</span>' if f.get('protected') else \
                 '<span class="badge badge-cleanable">🗑️ 可清理</span>' if f.get('cleanable') else '📄'
        html += f"""
                <tr>
                    <td>{f['name'][:40]}</td>
                    <td>{f['size_kb']:.2f} KB</td>
                    <td>{f['modified']}</td>
                    <td>{status}</td>
                </tr>
"""

    html += f"""
            </tbody>
        </table>

        <h2>💡 优化建议</h2>
        <ul>
"""
    for rec in result.get('recommendations', []):
        html += f"<li>{rec}</li>"

    html += f"""
        </ul>

        <div class="footer">
            生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 记忆管家 V{VERSION}
        </div>
    </div>
</body>
</html>"""

    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return output_path

    return html


# ============ 辅助函数 ============
def _generate_recommendations(files: list, stats: dict) -> list:
    """生成记忆优化建议"""
    recs = []
    
    if stats["total_size_kb"] > 100:
        recs.append(f"💡 记忆文件较大({stats['total_size_kb']:.1f}KB)，建议清理过期日志")
    
    if stats["total_files"] > 20:
        recs.append(f"📁 文件数量较多({stats['total_files']}个)，建议合并或归档旧日志")
    
    cleanable_count = stats.get("cleanable_files", 0)
    if cleanable_count > 0:
        recs.append(f"🧹 有{cleanable_count}个30天前的日志可清理")
    
    if not recs:
        recs.append("✨ 记忆状态良好，无需清理")
    
    return recs


def _generate_scan_recommendations(stats: dict, empty_dir_count: int) -> list:
    """生成扫描优化建议"""
    recs = []
    
    cleanable = stats["cleanable_size_kb"]
    if cleanable > 50:
        recs.append(f"💾 可清理缓存: {cleanable:.1f}KB，建议清理")
    elif cleanable > 0:
        recs.append(f"💾 可清理缓存: {cleanable:.1f}KB")
    
    if empty_dir_count > 0:
        recs.append(f"📂 发现{empty_dir_count}个空目录可清理")
    
    if stats["total_files"] > 100:
        recs.append(f"📁 文件数量较多({stats['total_files']}个)，建议检查是否冗余")
    
    if cleanable == 0 and empty_dir_count == 0:
        recs.append("✨ 存储状态良好，无需清理")
    
    return recs


def print_report(result: dict, format_type: str = "text") -> None:
    """格式化输出报告（带颜色）"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    # 文本格式输出
    print(f"\n{C['bright']}{'='*50}{C['reset']}")
    print(f"{C['cyan']}🧠 记忆管家 V{VERSION} - 存储报告{C['reset']}")
    print(f"{C['bright']}{'='*50}{C['reset']}")
    print(f"📁 工作目录: {result.get('workspace', 'N/A')}")
    print(f"⏰ 扫描时间: {result.get('timestamp', 'N/A')[:19]}")
    print()

    if "error" in result:
        print(f"{C['red']}❌ 错误: {result['error']}{C['reset']}")
        return

    stats = result.get("stats", {})
    print(f"📊 统计概览:")
    print(f"   总文件数: {C['white']}{stats.get('total_files', 0)}{C['reset']} 个")
    print(f"   总占用: {C['yellow']}{stats.get('total_size_kb', 0):.2f} KB{C['reset']}")
    print(f"   可清理: {C['green']}{stats.get('cleanable_size_kb', 0):.2f} KB{C['reset']} ({stats.get('cleanable_files', 0)} 个)")

    if "estimated_token_saving" in stats:
        print(f"   预估Token节省: ~{C['magenta']}{stats['estimated_token_saving']}{C['reset']}")

    if result.get("files"):
        print(f"\n📈 文件分布 (前10个最大文件):")
        for i, f in enumerate(result["files"][:10], 1):
            if f.get("protected"):
                status = f"{C['red']}🔒{C['reset']}"
            elif f.get("cleanable"):
                status = f"{C['green']}🗑️{C['reset']}"
            else:
                status = "📄"
            img = f" [{f.get('image_format')}]" if f.get("image_format") else ""
            print(f"   {status} {i}. {f['name'][:30]:30s} {f['size_kb']:>8.2f} KB {img}")

    if result.get("empty_dirs"):
        print(f"\n📂 空目录 ({len(result['empty_dirs'])}个):")
        for d in result["empty_dirs"][:5]:
            print(f"   • {d}")
        if len(result["empty_dirs"]) > 5:
            print(f"   ... 还有 {len(result['empty_dirs'])-5} 个")

    recs = result.get("recommendations", [])
    if recs:
        print(f"\n💡 优化建议:")
        for r in recs:
            print(f"   {r}")

    if result.get("warning"):
        print(f"\n{C['yellow']}⚠️  警告: {result['warning']}{C['reset']}")

    print(f"\n{C['bright']}{'='*50}{C['reset']}")


def print_memory_analysis(result: dict, format_type: str = "text") -> None:
    """格式化输出记忆分析"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    print(f"\n{'='*50}")
    print(f"🧠 记忆管家 V{VERSION} - 记忆分析")
    print(f"{'='*50}")
    print(f"📁 工作目录: {result.get('workspace', 'N/A')}")
    print()
    
    if "error" in result:
        print(f"❌ 错误: {result['error']}")
        return
    
    stats = result.get("stats", {})
    print(f"📊 记忆状态:")
    print(f"   总文件数: {stats.get('total_files', 0)} 个")
    print(f"   总占用: {stats.get('total_size_kb', 0):.2f} KB")
    
    if result.get("files"):
        print(f"\n📝 文件列表:")
        for f in result["files"][:20]:
            age = f.get("age_days", 0)
            status = "🆕" if age <= 7 else "📅" if age <= 30 else "📁"
            clean = "🗑️" if f.get("cleanable") else "  "
            print(f"   {status}{clean} {f['name']:30s} {f['size_kb']:>7.2f}KB  {f['modified']} ({age}天前)")
        
        if len(result["files"]) > 20:
            print(f"   ... 还有 {len(result['files'])-20} 个文件")
    
    recs = result.get("recommendations", [])
    if recs:
        print(f"\n💡 建议:")
        for r in recs:
            print(f"   {r}")
    
    print(f"\n{'='*50}")


def print_preview(preview: dict) -> None:
    """格式化输出清理预览"""
    print(f"\n{'='*50}")
    print(f"🧹 清理预览 {'[预览模式]' if preview.get('dry_run') else ''}")
    print(f"{'='*50}")
    
    if "error" in preview:
        print(f"❌ 错误: {preview['error']}")
        return
    
    files = preview.get("files_to_clean", [])
    print(f"将删除 {len(files)} 个文件 ({preview.get('total_size_kb', 0):.1f} KB)")
    print(f"预估Token节省: ~{preview.get('token_saving', 0)}")
    print()
    
    for i, f in enumerate(files[:20], 1):
        print(f"   [{i}] {f['name'][:40]:40s} {f['size_kb']:>7.2f} KB")
    
    if len(files) > 20:
        print(f"   ... 还有 {len(files)-20} 个文件")
    
    print(f"\n{preview.get('message', '')}")
    print(f"\n{'='*50}")


# ============ CLI入口 ============
def main():
    parser = argparse.ArgumentParser(
        description=f"记忆管家 V{VERSION} - AI效率工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  %(prog)s analyze                    # 分析记忆状态
  %(prog)s analyze --age 7            # 只看7天内的文件
  %(prog)s scan                        # 扫描工作空间
  %(prog)s scan --exclude temp,logs   # 排除特定目录
  %(prog)s preview                     # 生成清理预览
  %(prog)s preview --json              # JSON格式输出

安全特性:
  ✓ 符号链接防护
  ✓ 单文件1MB限制
  ✓ 累计读取5MB限制
  ✓ 最多1000条报告
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    parser.add_argument('--json', action='store_true', help='JSON格式输出')
    parser.add_argument('workspace', nargs='?', default='.', help='工作目录路径')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # analyze命令
    analyze_parser = subparsers.add_parser('analyze', help='分析记忆状态')
    analyze_parser.add_argument('--age', type=int, metavar='N', 
                                help='只分析N天内的文件')
    analyze_parser.add_argument('--exclude', type=str, metavar='DIRS',
                                help='排除的目录（逗号分隔）')
    
    # scan命令
    scan_parser = subparsers.add_parser('scan', help='扫描工作空间')
    scan_parser.add_argument('--exclude', type=str, metavar='DIRS',
                            help='排除的目录（逗号分隔）')
    scan_parser.add_argument('--clean-empty-dirs', action='store_true',
                            help='识别空目录')
    
    # preview命令
    preview_parser = subparsers.add_parser('preview', help='生成清理预览')
    
    # clean命令
    clean_parser = subparsers.add_parser('clean', help='执行清理（需确认）')
    clean_parser.add_argument('--force', action='store_true', help='跳过确认直接执行')

    # archive命令
    archive_parser = subparsers.add_parser('archive', help='归档旧记忆（压缩后移动）')
    archive_parser.add_argument('--age', type=int, default=30, help='归档超过N天的文件（默认30天）')
    archive_parser.add_argument('--path', type=str, help='指定归档目录')

    # html命令
    html_parser = subparsers.add_parser('html', help='生成HTML格式报告')
    html_parser.add_argument('--output', type=str, help='输出文件路径')

    # summarize命令
    summarize_parser = subparsers.add_parser('summarize', help='生成记忆摘要')
    summarize_parser.add_argument('--file', type=str, help='指定文件（不指定则处理所有）')
    summarize_parser.add_argument('--regenerate', action='store_true', help='强制重新生成')

    # rank命令
    rank_parser = subparsers.add_parser('rank', help='记忆重要性分级')

    # load命令
    load_parser = subparsers.add_parser('load', help='智能加载记忆')
    load_parser.add_argument('--mode', type=str, default='normal',
                            choices=['brief', 'normal', 'full'], help='加载模式')
    load_parser.add_argument('--keyword', type=str, help='关键词过滤')
    load_parser.add_argument('--limit', type=int, default=10, help='返回数量')

    # search命令 - keyword作为选项参数避免位置冲突
    search_parser = subparsers.add_parser('search', help='搜索记忆')
    search_parser.add_argument('-k', '--keyword', dest='keyword', required=True, help='搜索关键词')
    search_parser.add_argument('--mode', type=str, default='brief',
                              choices=['brief', 'normal', 'full'], help='结果模式')

    args = parser.parse_args()
    
    # 默认命令
    if args.command is None:
        # 默认执行扫描
        result = scan_workspace(args.workspace)
        print_report(result, "json" if args.json else "text")
        return
    
    # 解析排除目录
    exclude_dirs = []
    if hasattr(args, 'exclude') and args.exclude:
        exclude_dirs = [d.strip() for d in args.exclude.split(',')]
    
    # 执行对应命令
    if args.command == 'analyze':
        result = analyze_memory(
            args.workspace,
            age_days=args.age,
            exclude_patterns=exclude_dirs
        )
        print_memory_analysis(result, "json" if args.json else "text")
    
    elif args.command == 'scan':
        result = scan_workspace(
            args.workspace,
            exclude_dirs=exclude_dirs,
            clean_empty_dirs=args.clean_empty_dirs
        )
        print_report(result, "json" if args.json else "text")
    
    elif args.command == 'preview':
        result = generate_cleanup_preview(args.workspace, dry_run=True)
        print_preview(result)
    
    elif args.command == 'clean':
        # 检查force参数
        if args.force:
            # 直接执行清理
            result = execute_cleanup(args.workspace)
            print(f"\n{C['green']}✅ 已清理 {result['deleted_count']} 个文件，释放 {result['deleted_size_kb']:.1f} KB{''}")
        else:
            print(f"\n{C['yellow']}⚠️  确认执行清理？{''}")
            print("此操作将永久删除可清理文件，请确保已查看预览。")
            print("回复 '同意' 确认执行:")
            
            user_input = input().strip()
            if user_input == '同意':
                result = execute_cleanup(args.workspace)
                print(f"\n{C['green']}✅ 已清理 {result['deleted_count']} 个文件，释放 {result['deleted_size_kb']:.1f} KB{''}")
            else:
                print(f"\n{C['red']}❌ 取消清理操作{''}")

    elif args.command == 'archive':
        print(f"\n{C['cyan']}🗜️  归档超过 {args.age} 天的记忆文件...{''}")
        result = archive_old_memory(args.workspace, age_days=args.age, archive_path=args.path)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['green']}✅ 已归档 {result['archived_count']} 个文件，释放 {result['archived_size_kb']:.1f} KB")
            print(f"📁 归档位置: {result['archive_path']}{''}")

    elif args.command == 'html':
        print(f"\n{C['cyan']}📊 生成HTML报告...{''}")
        result = scan_workspace(args.workspace)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            output = generate_html_report(result, args.output)
            if args.output:
                print(f"\n{C['green']}✅ HTML报告已保存: {output}{''}")
            else:
                # 浏览器打开
                import tempfile
                import webbrowser
                with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
                    f.write(generate_html_report(result))
                    temp_path = f.name
                webbrowser.open(f'file://{temp_path}')
                print(f"\n{C['green']}✅ 已在浏览器中打开报告{''}")

    elif args.command == 'summarize':
        print(f"\n{C['cyan']}📝 生成记忆摘要...{''}")
        result = summarize_memory(args.workspace, file_name=args.file, regenerate=args.regenerate)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['green']}✅ 摘要生成完成{C['reset']}")
            print(f"   已处理: {len(result['summarized'])} 个文件")
            print(f"   跳过: {len(result['skipped'])} 个文件")
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.command == 'rank':
        print(f"\n{C['cyan']}⭐ 记忆重要性分级...{''}")
        result = rank_memory(args.workspace)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['bright']}{'='*50}{C['reset']}")
            print(f"{C['cyan']}🧠 记忆分级报告{C['reset']}")
            print(f"{'='*50}")

            stats = result["stats"]
            print(f"\n📊 分级统计:")
            print(f"   总记忆数: {stats['total']}")
            print(f"   {C['red']}🔴 核心记忆:{C['reset']} {stats['core_count']} 个")
            print(f"   {C['yellow']}🟡 普通记忆:{C['reset']} {stats['normal_count']} 个")
            print(f"   {C['green']}🟢 冷门记忆:{C['reset']} {stats['cold_count']} 个")

            if result.get("core"):
                print(f"\n{C['red']}🔴 核心记忆 (>=70%):{C['reset']}")
                for item in result["core"][:5]:
                    print(f"   • {item['file']} ({item['score']}分)")

            if result.get("normal"):
                print(f"\n{C['yellow']}🟡 普通记忆 (30-70%):{C['reset']}")
                for item in result["normal"][:5]:
                    print(f"   • {item['file']} ({item['score']}分)")

            if result.get("cold"):
                print(f"\n{C['green']}🟢 冷门记忆 (<30%):{C['reset']}")
                for item in result["cold"][:5]:
                    print(f"   • {item['file']} ({item['score']}分)")

            print(f"\n{C['bright']}{'='*50}{C['reset']}")

    elif args.command == 'load':
        print(f"\n{C['cyan']}📖 智能加载记忆...{''}")
        result = load_memory(args.workspace, mode=args.mode, keyword=args.keyword, limit=args.limit)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['green']}✅ 加载完成{C['reset']}")
            print(f"   模式: {result['mode']}")
            print(f"   加载: {len(result['loaded'])} 个记忆")
            print(f"   预估Token: ~{result['total_tokens_estimate']}")

            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(f"\n{C['bright']}--- 记忆内容 ---{C['reset']}")
                for item in result["loaded"][:5]:
                    print(f"\n📄 {item['file']} [{item['type']}]")
                    print(f"{item['content'][:300]}...")

    elif args.command == 'search':
        print(f"\n{C['cyan']}🔍 搜索记忆: {args.keyword}{''}")
        result = search_memory(args.workspace, args.keyword, mode=args.mode)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n找到 {result['total']} 个匹配结果:")
            for item in result["matches"][:10]:
                print(f"\n📄 {item['file']} (匹配度: {item['score']})")
                print(f"   {item['preview'][:150]}...")


if __name__ == "__main__":
    main()
