---
name: "记忆管家"
description: >
  AI加速器 V2.2，智能管理记忆与文件，减少Token消耗。
  This skill should be used when users want to manage memories, reduce token consumption,
  summarize memory files, rank memory importance, smart load memories, search memories,
  clean up workspace files, optimize memory usage, or ask about memory/file status.
  触发词：记忆管家、清理缓存、省token、记忆总结、减少消耗、内存优化、文件清理、扫描存储、存储报告、优化记忆、效率加速、Token管理、减少Token、记忆分析、扫描工作空间、清理预览、空目录清理、记忆归档、HTML报告、摘要生成、记忆分级、智能加载、记忆搜索
---

# 记忆管家 V2.2 - AI加速器

🧠 **让AI更懂你，更快回应，更省Token**

智能管理记忆与文件，减少Token消耗，让AI响应更快更准。

---

## ✨ V2.2 核心升级（TOKEN优化重点）

| 维度 | V2.1 | V2.2 | 提升 |
|------|------|------|------|
| 📝 摘要生成 | ❌ | **✅** | 减少90%加载量 |
| ⭐ 重要性分级 | ❌ | **✅** | 核心记忆优先 |
| 📖 智能加载 | ❌ | **✅** | 按需加载 |
| 🔍 全文搜索 | ❌ | **✅** | 快速定位 |
| 💰 TOKEN节省 | 30-50% | **50-80%** | 翻倍提升 |

---

## 🚀 十大核心功能

### 基础功能（V2.1）
1. **记忆分析** (`analyze`) - 分析记忆文件状态
2. **工作空间扫描** (`scan`) - 扫描.workbuddy目录
3. **清理预览** (`preview`) - Dry Run模式
4. **智能清理** (`clean`) - 预览确认执行
5. **记忆归档** (`archive`) - 压缩后移动

### 升级功能（V2.2）⭐
6. **摘要生成** (`summarize`) - 一键生成所有记忆摘要
7. **重要性分级** (`rank`) - 自动分核心/普通/冷门
8. **智能加载** (`load`) - 按分级加载，节省TOKEN
9. **记忆搜索** (`search`) - 关键词快速搜索
10. **HTML报告** (`html`) - 可视化图表展示

---

## 💰 TOKEN节省原理

```
传统方式（全量加载）:
记忆文件: 10个 × 5KB = 50KB → ~12500 TOKEN

V2.2方式（智能加载）:
├── 核心记忆(10%) × 5KB = 5KB → ~1250 TOKEN
├── 普通记忆(30%) × 摘要500字 = 1.5KB → ~375 TOKEN
└── 冷门记忆(60%) × 压缩归档 = 1KB → ~250 TOKEN
总计: ~1875 TOKEN (节省85%)
```

---

## 💻 CLI 使用指南

### 基础命令

```bash
# 分析记忆状态
memory_manager.py analyze

# 扫描工作空间
memory_manager.py scan

# 执行清理
memory_manager.py clean --force
```

### V2.2 新增命令 ⭐

```bash
# 1. 生成所有记忆摘要
memory_manager.py summarize

# 2. 指定文件生成摘要
memory_manager.py summarize --file 2026-04-26.md

# 3. 重新生成摘要
memory_manager.py summarize --regenerate

# 4. 记忆重要性分级
memory_manager.py rank

# 5. 智能加载（默认normal模式）
memory_manager.py load

# 6. 只加载摘要（最省TOKEN）
memory_manager.py load --mode brief

# 7. 加载相关记忆
memory_manager.py load --mode normal --keyword 养虾 --limit 5

# 8. 搜索记忆
memory_manager.py search -k 绿舜生态

# 9. 搜索并显示详细内容
memory_manager.py search -k 绿舜生态 --mode normal
```

### 归档和报告

```bash
# 归档60天前的记忆
memory_manager.py archive --age 60

# 生成HTML报告
memory_manager.py html
```

### 高级选项

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| summarize | `--file` | 指定文件 | `--file 2026-04-26.md` |
| summarize | `--regenerate` | 强制重新生成 | `--regenerate` |
| load | `--mode` | 加载模式 | `--mode brief` |
| load | `--mode` | brief=摘要 / normal=摘要+要点 / full=全文 | |
| load | `--keyword` | 关键词过滤 | `--keyword 养虾` |
| load | `--limit` | 返回数量 | `--limit 5` |
| search | `-k/--keyword` | 搜索关键词 | `-k 绿舜` |
| search | `--mode` | 结果详细程度 | `--mode normal` |
| archive | `--age` | 归档天数 | `--age 60` |
| html | `--output` | 输出路径 | `--output report.html` |

---

## 🧠 智能分级原理

### 评分维度

| 维度 | 权重 | 说明 |
|------|------|------|
| 📊 访问频率 | 40% | 最近访问越多越重要 |
| ⏰ 时间衰减 | 30% | 新记忆权重更高 |
| 📏 内容长度 | 15% | 1-10KB最佳 |
| 🏷️ 关键词匹配 | 15% | 匹配用户关注领域 |

### 分级结果

| 等级 | 阈值 | 加载策略 | TOKEN消耗 |
|------|------|----------|-----------|
| 🔴 核心 | >=70% | 全文加载 | 高 |
| 🟡 普通 | 30-70% | 摘要加载 | 中 |
| 🟢 冷门 | <30% | 归档压缩 | 低 |

---

## 📊 功能对比

| 功能 | V2.0 | V2.1 | V2.2 |
|------|------|------|------|
| analyze/scan/preview/clean | ✅ | ✅ | ✅ |
| archive/html | ❌ | ✅ | ✅ |
| summarize (摘要生成) | ❌ | ❌ | ✅ |
| rank (重要性分级) | ❌ | ❌ | ✅ |
| load (智能加载) | ❌ | ❌ | ✅ |
| search (全文搜索) | ❌ | ❌ | ✅ |
| 颜色输出 | ❌ | ✅ | ✅ |
| TOKEN节省 | 30% | 30-50% | **50-80%** |

---

## 🛡️ 安全特性

| 特性 | 说明 |
|------|------|
| 🔗 符号链接防护 | 防止路径穿越 |
| 📄 单文件限制 | 最大1MB |
| 📊 累计读取限制 | 不超过5MB |
| 📋 报告数量限制 | 最多1000条 |
| ✅ 预览确认 | 清理前显示清单 |
| 🔒 受保护目录 | memory/skills永不删除 |

---

## 📁 目录结构

```
.workbuddy/
├── memory/           # 原始记忆文件
│   ├── MEMORY.md     # 核心记忆（永不删除）
│   └── 2026-04-26.md
├── .summary/         # 摘要缓存 ⭐V2.2新增
│   ├── 2026-04-26.summary  # 摘要文件
│   └── summary_index.json  # 访问统计
├── archive/         # 归档文件
└── 其他文件...
```

---

## 🎯 使用场景

### 场景1：减少TOKEN消耗
```bash
# 首次使用：生成所有摘要
memory_manager.py summarize

# 日常对话：使用智能加载
memory_manager.py load --mode brief
```

### 场景2：快速定位信息
```bash
# 搜索关键词
memory_manager.py search 绿舜生态

# 加载相关记忆
memory_manager.py load --keyword 绿舜生态 --limit 5
```

### 场景3：定期整理
```bash
# 查看分级
memory_manager.py rank

# 归档冷门记忆
memory_manager.py archive --age 60
```

---

## 🗺️ 未来规划 (V2.3)

- [ ] dedup: 基于内容哈希去重
- [ ] stats: Token消耗趋势图
- [ ] backup: 云端备份支持
- [ ] schedule: 定时自动整理

---

**版本：V2.2.0 | 核心升级：TOKEN节省50-80%** 💰

