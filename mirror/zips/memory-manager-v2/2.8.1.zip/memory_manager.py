﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆管家 V2.8.1 - AI效率工具
智能管理记忆与文件，减少Token消耗

主要功能:
- 记忆分析：分析记忆文件状态，支持年龄过滤
- 工作空间扫描：扫描.workbuddy目录，识别可清理内容
- 智能清理：预览确认，安全不误删
- 增量加载：--days N 只加载N天内文件
- 摘要压缩：输出限制300字符（节省50-80% Token）

作者: 可乐138
版本: 2.8.1

核心升级 (V2.8.1):
- 省Token优化：增量加载(days参数) + 摘要压缩输出(300字符)
- 叠加效果：综合节省50-80% Token
"""

import argparse
import hashlib
import json
import os
import sys
import shutil
import gzip
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from functools import lru_cache

# ============ 全局缓存 ============
_CONFIG_CACHE = None
_CONFIG_CACHE_TIME = 0
_CONFIG_CACHE_TTL = 300  # 5分钟缓存

# ============ i18n 翻译支持 ============
_LANG = "zh"  # 默认中文
_I18N_DATA = None

def init_i18n(lang="zh"):
    """初始化i18n（懒加载）"""
    global _LANG, _I18N_DATA
    _LANG = lang
    i18n_path = Path(__file__).parent / "i18n.json"
    if i18n_path.exists():
        try:
            with open(i18n_path, 'r', encoding='utf-8') as f:
                _I18N_DATA = json.load(f)
        except:
            _I18N_DATA = {"zh": {}, "en": {}}
    else:
        _I18N_DATA = {"zh": {}, "en": {}}

def _(key: str) -> str:
    """翻译函数"""
    global _LANG, _I18N_DATA
    if _I18N_DATA is None:
        init_i18n()
    return _I18N_DATA.get(_LANG, {}).get(key, key)

def set_lang(lang: str):
    """设置语言"""
    if lang in ("zh", "en"):
        init_i18n(lang)

# ============ 跨平台初始化 ============
# 确保stdout/stderr在Windows下支持UTF-8输出
if sys.platform == 'win32':
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        # 尝试导入colorama（Windows颜色支持）
        try:
            from colorama import init, Fore, Style
            init(autoreset=True)
            COLOR_SUPPORT = True
        except ImportError:
            COLOR_SUPPORT = False
    except Exception:
        COLOR_SUPPORT = False
else:
    try:
        from colorama import init, Fore, Style
        init(autoreset=True)
        COLOR_SUPPORT = True
    except ImportError:
        COLOR_SUPPORT = False

# ============ 常量定义 ============
VERSION = "2.8.1"  # V2.8.1: 增量加载(days参数) + 摘要压缩输出
MAX_OUTPUT_CHARS = 300  # 输出摘要最大字符数（省Token）
PROTECTED_DIRS = {'memory', '.workbuddy', '.skills', 'skills'}
CLEANABLE_EXTS = {'.tmp', '.log', '.cache', '.bak', '.temp', '.swp', '.pyc', '__pycache__'}
IMAGE_SIGNATURES = {
    'png': b'\x89PNG\r\n\x1a\n',
    'jpg': b'\xff\xd8\xff',
    'gif': b'GIF87a',
    'gif89': b'GIF89a',
    'bmp': b'BM',
    'webp': b'RIFF',
    'ico': b'\x00\x00\x01\x00',
}
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.ico'}

# 安全限制
MAX_FILE_SIZE = 1 * 1024 * 1024  # 1MB
MAX_TOTAL_READ = 5 * 1024 * 1024  # 5MB
MAX_REPORT_ITEMS = 1000

# 摘要配置
SUMMARY_DIR = ".summary"  # 摘要缓存目录
SUMMARY_MAX_CHARS = 300   # 摘要最大字符数
SUMMARY_INDEX_FILE = "summary_index.json"  # 摘要索引文件

# 重要性分级阈值
RANK_CORE_THRESHOLD = 0.7   # 核心记忆阈值 (>=70%)
RANK_NORMAL_THRESHOLD = 0.3  # 普通记忆阈值 (>=30%)
# 低于30% = 冷门记忆 → 归档

# ============ 自动清理配置 ============
CONFIG_FILE = str(Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json")

DEFAULT_CONFIG = {
    "retention_days": 1,        # 默认保留天数（推送类超1天自动清理）
    "auto_remind_days": 5,      # 个人/工作内容每5天提醒一次
    "auto_archive": True,       # 超过保留期是否自动归档（True=压缩移走，False=只报告不删除）
    "last_remind_date": "",     # 上次提醒日期（自动维护）
    "last_clean_date": "",      # 上次清理日期（自动维护）
    "_automation_rules": {     # V2.4 差异化清理规则
        "push_content": {
            "retention_days": 1,       # 推送类：超1天自动清理
            "auto_clean": True,
            "keywords": ["推送", "AI动态", "历史推送摘要", "每日AI", "动态推送", "新闻推送"]
        },
        "personal_work_content": {
            "retention_days": 0,        # 个人/工作类：不自动按时间清理
            "auto_clean": False,
            "remind_days": 5,           # 每5天提醒一次
            "keywords": ["个人", "工作", "项目", "客户", "企业", "MEMORY.md"]
        }
    }
}

def load_config() -> dict:
    """加载配置文件（带5分钟缓存）"""
    global _CONFIG_CACHE, _CONFIG_CACHE_TIME
    
    now = datetime.now().timestamp()
    if _CONFIG_CACHE is not None and (now - _CONFIG_CACHE_TIME) < _CONFIG_CACHE_TTL:
        return _CONFIG_CACHE
    
    config = DEFAULT_CONFIG.copy()
    try:
        config_path = Path(CONFIG_FILE)
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                config.update(user_config)
        else:
            save_config(config)
    except (json.JSONDecodeError, IOError, PermissionError):
        pass
    
    _CONFIG_CACHE = config
    _CONFIG_CACHE_TIME = now
    return config

def clear_config_cache():
    """清除配置缓存（配置修改后调用）"""
    global _CONFIG_CACHE, _CONFIG_CACHE_TIME
    _CONFIG_CACHE = None
    _CONFIG_CACHE_TIME = 0

def save_config(config: dict) -> None:
    """保存配置文件"""
    cfg_path = Path(CONFIG_FILE)
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cfg_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    # 清除缓存
    clear_config_cache()

def config_memory(workspace_path: str, key: str = None, value: str = None) -> dict:
    """
    查看/修改配置
    - 不传参数：查看当前配置
    - key+value：修改指定项
    """
    config = load_config()
    result = {"action": "view", "config": config}

    if key is not None and value is not None:
        if key not in DEFAULT_CONFIG:
            return {"error": f"未知配置项: {key}，可用项: {list(DEFAULT_CONFIG.keys())}"}
        # 类型转换
        default_type = type(DEFAULT_CONFIG[key])
        try:
            typed_value = default_type(value)
        except (ValueError, TypeError):
            return {"error": f"值 '{value}' 类型错误，应为 {default_type.__name__}"}
        config[key] = typed_value
        save_config(config)
        result = {"action": "update", "key": key, "value": typed_value, "config": config}

    return result

def classify_content(file_path: Path, rules: dict) -> str:
    """
    V2.4 新功能：内容分类
    - push: 推送类信息（AI动态、历史推送等）
    - personal_work: 个人/工作相关内容
    - other: 其他内容（使用默认保留规则）
    """
    # 读取文件内容（前2KB足够判断）
    content = ""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(2048).lower()
    except (OSError, IOError, UnicodeDecodeError):
        pass  # 无法读取文件时跳过

    file_name_lower = file_path.name.lower()

    # 推送类关键词
    push_keywords = rules.get("push_content", {}).get("keywords", [])
    for kw in push_keywords:
        if kw.lower() in content or kw.lower() in file_name_lower:
            return "push"

    # 个人/工作类关键词
    personal_keywords = rules.get("personal_work_content", {}).get("keywords", [])
    for kw in personal_keywords:
        if kw.lower() in content or kw.lower() in file_name_lower:
            return "personal_work"

    return "other"


def check_remind_due(config: dict) -> bool:
    """
    V2.4：检查是否该提醒用户清理个人/工作内容
    距上次提醒已满 remind_days 天则返回 True
    """
    last_remind = config.get("last_remind_date", "")
    remind_days = config.get("auto_remind_days", 5)
    if not last_remind:
        return True  # 从未提醒过，首次提醒

    try:
        last_date = datetime.strptime(last_remind, "%Y-%m-%d").date()
        days_since = (datetime.now().date() - last_date).days
        return days_since >= remind_days
    except (ValueError, TypeError):
        return True  # 日期解析失败时返回需要提醒


def auto_clean_memory(workspace_path: str, dry_run: bool = True, content_filter: str = None, confirm_action: bool = False) -> dict:
    """
    V2.4/V2.7 差异化自动清理（提醒确认模式）
    
    V2.7 变更：所有内容类型统一改为提醒模式，不再自动归档
    - 推送类信息：超过保留期 → 提醒用户确认后清理
    - 个人/工作内容：不自动清理，每5天提示用户确认
    - 其他内容：超过保留期 → 提醒用户确认后清理
    
    Args:
        workspace_path: 工作空间路径
        dry_run: True=预览模式（默认），False=准备执行
        content_filter: 内容过滤 ('push'/'personal_work'/'all')
        confirm_action: 确认执行（需用户回复"同意"）
    
    Returns:
        dict: 清理报告，包含 remind_files（待确认列表）、kept_files（保留列表）
    """
    config = load_config()
    rules = config.get("_automation_rules", DEFAULT_CONFIG["_automation_rules"])
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    result = {
        "timestamp": datetime.now().isoformat(),
        "retention_days": config["retention_days"],
        "auto_remind_days": config["auto_remind_days"],
        "auto_archive": config["auto_archive"],  # 保留但不再自动使用
        "push_auto_clean_days": rules.get("push_content", {}).get("retention_days", 1),
        "personal_work_remind_days": rules.get("personal_work_content", {}).get("remind_days", 5),
        "files_archived": 0,       # 实际归档数
        "size_freed_kb": 0,       # 释放空间
        "kept_files": [],
        "remind_files": [],       # V2.7: 所有超期文件统一放入提醒列表
        "errors": [],
        "clean_summary": {
            "push_to_remind": 0,         # V2.7: 推送类待提醒
            "personal_work_to_remind": 0,
            "other_to_remind": 0         # V2.7: 其他类待提醒
        }
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    today = datetime.now().date()

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue
        # MEMORY.md 永不清理
        if md_file.name == "MEMORY.md":
            result["kept_files"].append({"name": md_file.name, "reason": "核心记忆永久保留", "type": "core"})
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        age = (datetime.now() - mtime).days

        # V2.4: 内容分类
        content_type = classify_content(md_file, rules)

        file_entry = {
            "name": md_file.name,
            "age_days": age,
            "size_kb": round(size_kb, 2),
            "modified": mtime.strftime("%Y-%m-%d"),
            "type": content_type
        }

        # 内容过滤
        if content_filter and content_filter != content_type and content_filter != "all":
            # 用户指定了过滤类型，不匹配则跳过
            result["kept_files"].append({**file_entry, "reason": f"内容类型({content_type})不在本次清理范围"})
            continue

        # V2.7 变更：所有内容类型统一改为提醒模式
        # 推送类：超保留期 → 提醒确认后清理
        if content_type == "push":
            push_retention = rules.get("push_content", {}).get("retention_days", 1)
            if age >= push_retention:
                result["remind_files"].append({**file_entry, "reason": f"推送类内容，超{push_retention}天，建议清理"})
                result["clean_summary"]["push_to_remind"] += 1
                # V2.7: 只有 confirm_action=True 时才执行归档
                if confirm_action and not dry_run:
                    try:
                        _do_archive(md_file, mtime, base_path)
                        result["files_archived"] += 1
                        result["size_freed_kb"] += size_kb
                    except Exception as e:
                        result["errors"].append(f"{md_file.name}: {str(e)}")
            else:
                result["kept_files"].append({**file_entry, "reason": f"推送类内容，距创建{age}天，保留中"})

        # 个人/工作类：提醒用户确认
        elif content_type == "personal_work":
            if check_remind_due(config):
                result["remind_files"].append({**file_entry, "reason": "个人/工作内容，请确认是否清理"})
                result["clean_summary"]["personal_work_to_remind"] += 1
            else:
                result["kept_files"].append({**file_entry, "reason": "个人/工作内容，距上次提醒未满5天，保留"})

        # V2.7 变更：其他内容也改为提醒模式
        else:
            default_retention = config.get("retention_days", 1)
            if age >= default_retention:
                result["remind_files"].append({**file_entry, "reason": f"其他内容，超{default_retention}天，建议清理"})
                result["clean_summary"]["other_to_remind"] += 1
                # V2.7: 只有 confirm_action=True 时才执行归档
                if confirm_action and not dry_run:
                    try:
                        _do_archive(md_file, mtime, base_path)
                        result["files_archived"] += 1
                        result["size_freed_kb"] += size_kb
                    except Exception as e:
                        result["errors"].append(f"{md_file.name}: {str(e)}")
            else:
                result["kept_files"].append({**file_entry, "reason": f"距创建{age}天，保留期内"})

    # V2.7: 只有确认执行时才更新配置日期
    if confirm_action and not dry_run:
        config["last_clean_date"] = today.isoformat()
        # 如果本次有提醒，更新提醒日期
        if result["remind_files"]:
            config["last_remind_date"] = today.isoformat()
        save_config(config)

    return result


def _do_archive(md_file: Path, mtime: datetime, base_path: Path) -> None:
    """执行归档操作（内部函数）"""
    archive_dir = base_path / ".workbuddy" / "archive"
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_name = f"{md_file.stem}_{mtime.strftime('%Y%m%d')}.md.gz"
    archive_file = archive_dir / archive_name
    with open(md_file, 'rb') as f_in:
        with gzip.open(archive_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    md_file.unlink()

# 加载模式
LOAD_BRIEF = "brief"   # 只加载摘要 (~200字)
LOAD_NORMAL = "normal"  # 摘要 + 关键段落 (~2KB)
LOAD_FULL = "full"      # 完整文件

# 颜色支持
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    C = {
        'red': Fore.RED, 'green': Fore.GREEN, 'yellow': Fore.YELLOW,
        'cyan': Fore.CYAN, 'magenta': Fore.MAGENTA, 'white': Fore.WHITE,
        'bright': Style.BRIGHT, 'reset': Style.RESET_ALL
    }
except ImportError:
    C = {k: '' for k in ['red', 'green', 'yellow', 'cyan', 'magenta', 'white', 'bright', 'reset']}


# ============ 安全函数 ============
def is_symlink(path: Path) -> bool:
    """检查是否为符号链接"""
    try:
        return path.is_symlink()
    except (OSError, ValueError):
        return False


def safe_resolve(path: Path, base_path: Path) -> Optional[Path]:
    """
    安全路径解析：确保路径在基础目录内，防止路径遍历攻击
    
    Args:
        path: 要检查的路径
        base_path: 允许的基础目录
    
    Returns:
        解析后的绝对路径，如果超出范围则返回None
    """
    try:
        # 解析为绝对路径并规范化
        abs_path = path.resolve()
        abs_base = base_path.resolve()
        
        # 检查是否在基础目录内
        try:
            abs_path.relative_to(abs_base)
            return abs_path
        except ValueError:
            # 路径超出基础目录
            return None
    except (OSError, ValueError):
        return None


def safe_file_read(path: Path, max_size: int = MAX_FILE_SIZE) -> tuple[Optional[str], str]:
    """
    安全读取文件内容（带LRU缓存）
    返回: (内容, 状态信息)
    """
    return _safe_file_cached(str(path.resolve()), max_size)

@lru_cache(maxsize=128)
def _safe_file_cached(path_str: str, max_size: int) -> tuple[Optional[str], str]:
    """内部缓存版本"""
    path = Path(path_str)
    try:
        if is_symlink(path):
            return None, "跳过符号链接"
        
        stat = path.stat()
        if stat.st_size > max_size:
            return None, f"文件超过{max_size//1024}KB限制"
        
        chunk_size = 64 * 1024  # 64KB per chunk
        chunks = []
        bytes_read = 0
        
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            while bytes_read < max_size:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                chunks.append(chunk)
                bytes_read += len(chunk.encode('utf-8', errors='ignore'))
        
        content = ''.join(chunks)
        if len(content.encode('utf-8')) > max_size:
            content = content[:max_size]
        return content, "成功"
    except Exception as e:
        return None, f"读取失败: {type(e).__name__}"


def get_file_info(path: Path) -> tuple[Optional[datetime], Optional[int]]:
    """
    获取文件修改时间和大小（带LRU缓存，单次stat调用）
    
    Returns:
        (mtime, size_kb) 或 (None, None) 如果失败
    """
    return _get_file_info_cached(str(path.resolve()))

@lru_cache(maxsize=256)
def _get_file_info_cached(path_str: str) -> tuple[Optional[datetime], Optional[float]]:
    """内部缓存版本"""
    try:
        path = Path(path_str)
        stat = path.stat()
        return datetime.fromtimestamp(stat.st_mtime), stat.st_size / 1024
    except (OSError, ValueError):
        return None, None


# ============ 进度条支持 ============
def get_progress_bar():
    """获取进度条（优先使用tqdm，否则使用简单实现）"""
    try:
        from tqdm import tqdm
        return tqdm
    except ImportError:
        # 简单进度条替代
        class SimpleProgress:
            def __init__(self, total, desc=''):
                self.total = total
                self.n = 0
                self.desc = desc
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
        return SimpleProgress

def detect_image_format(file_path: Path) -> Optional[str]:
    """
    通过文件头识别图片格式（仅读16字节）
    支持: PNG, JPG, GIF, BMP, WebP, ICO
    """
    try:
        with open(file_path, 'rb') as f:
            header = f.read(16)
        
        for fmt, sig in IMAGE_SIGNATURES.items():
            if header.startswith(sig):
                # WebP需要额外检查
                if fmt == 'webp':
                    if len(header) >= 12 and header[8:12] == b'WEBP':
                        return 'webp'
                    continue
                return fmt
        return None
    except (OSError, IOError):
        return None


# ============ 记忆分析 ============
def analyze_memory(
    workspace_path: str,
    age_days: Optional[int] = None,
    exclude_patterns: Optional[list] = None
) -> dict:
    """
    分析工作记忆目录
    
    Args:
        workspace_path: 工作目录路径
        age_days: 只分析N天内的文件（可选）
        exclude_patterns: 排除的目录模式（可选）
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0
        },
        "recommendations": []
    }
    
    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result
    
    if exclude_patterns is None:
        exclude_patterns = []
    
    total_read = 0
    
    try:
        for md_file in memory_path.glob("*.md"):
            # 安全检查：符号链接 + 路径遍历
            if is_symlink(md_file):
                continue
            if safe_resolve(md_file, memory_path) is None:
                continue
            
            # 获取文件信息（单次stat）
            mtime, size_kb = get_file_info(md_file)
            if mtime is None:
                continue
            
            # 年龄过滤
            age = (datetime.now() - mtime).days
            if age_days is not None and age > age_days:
                continue
            
            # 累计读取限制
            file_size = int(size_kb * 1024)
            if total_read + file_size > MAX_TOTAL_READ:
                result["warning"] = f"已达到读取上限{MAX_TOTAL_READ//1024}KB，报告可能被截断"
                break
            
            # 判断是否可清理（30天以上的非MEMORY.md文件）
            is_cleanable = (
                md_file.name != "MEMORY.md" and 
                age > 30
            )
            
            file_info = {
                "name": md_file.name,
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "age_days": age,
                "cleanable": is_cleanable
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            
            # 限制报告数量
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"文件数量超过{MAX_REPORT_ITEMS}条限制"
                break
        
        # 生成建议
        result["recommendations"] = _generate_recommendations(result["files"], result["stats"])
        
    except Exception as e:
        result["error"] = f"分析失败: {type(e).__name__}: {str(e)}"
    
    return result


# ============ 工作空间扫描 ============
def scan_workspace(
    workspace_path: str,
    exclude_dirs: Optional[list] = None,
    clean_empty_dirs: bool = False
) -> dict:
    """
    扫描工作空间，生成存储报告
    
    Args:
        workspace_path: 工作目录路径
        exclude_dirs: 排除的目录列表
        clean_empty_dirs: 是否识别空目录
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"
    result = {
        "version": VERSION,
        "workspace": workspace_path,
        "timestamp": datetime.now().isoformat(),
        "files": [],
        "empty_dirs": [],
        "stats": {
            "total_files": 0,
            "total_size_kb": 0,
            "cleanable_files": 0,
            "cleanable_size_kb": 0,
            "protected_size_kb": 0
        },
        "recommendations": []
    }
    
    if not workbuddy_path.exists():
        result["error"] = ".workbuddy目录不存在"
        return result
    
    if exclude_dirs is None:
        exclude_dirs = []
    
    # 使用os.scandir替代rglob提升大目录扫描性能
    def scan_dir_recursive(dir_path: Path, results: list):
        """递归扫描目录（使用scandir避免rglob性能问题）"""
        try:
            with os.scandir(dir_path) as entries:
                for entry in entries:
                    if entry.is_symlink():
                        continue
                    try:
                        resolved = Path(entry.path).resolve()
                        if not str(resolved).startswith(str(workbuddy_path)):
                            continue
                    except (OSError, ValueError):
                        continue
                    
                    if entry.is_file():
                        results.append(Path(entry.path))
                    elif entry.is_dir():
                        scan_dir_recursive(Path(entry.path), results)
        except (OSError, PermissionError):
            pass

    scanned_files = []
    scan_dir_recursive(workbuddy_path, scanned_files)
    
    for file_path in scanned_files:
        # 安全检查：符号链接 + 路径遍历
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue
        
        if file_path.is_file():
            # 获取文件信息（单次stat）
            mtime, size_kb = get_file_info(file_path)
            if mtime is None:
                continue
            
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""
            
            # 检查是否受保护
            is_protected = (
                parent_dir in PROTECTED_DIRS or
                any(ex in str(rel_path) for ex in exclude_dirs)
            )
            
            # 检查是否可清理
            is_cleanable = (
                not is_protected and
                (
                    file_path.suffix.lower() in CLEANABLE_EXTS or
                    'cache' in file_path.name.lower() or
                    'temp' in file_path.name.lower()
                )
            )
            
            # 图片检测（仅对图片后缀且小于5MB的文件）
            image_format = None
            if file_path.suffix.lower() in IMAGE_EXTENSIONS:
                file_size_kb = int(size_kb)
                if file_size_kb < 5000:  # 小于5MB才检测
                    image_format = detect_image_format(file_path)
            
            file_info = {
                "name": file_path.name,
                "path": str(rel_path),
                "size_kb": round(size_kb, 2),
                "modified": mtime.strftime("%Y-%m-%d"),
                "protected": is_protected,
                "cleanable": is_cleanable,
                "image_format": image_format
            }
            
            result["files"].append(file_info)
            result["stats"]["total_files"] += 1
            result["stats"]["total_size_kb"] += size_kb
            
            if is_cleanable:
                result["stats"]["cleanable_files"] += 1
                result["stats"]["cleanable_size_kb"] += size_kb
            elif is_protected:
                result["stats"]["protected_size_kb"] += size_kb
            
            if len(result["files"]) >= MAX_REPORT_ITEMS:
                result["warning"] = f"文件数量超过{MAX_REPORT_ITEMS}条限制"
                break
        
        elif clean_empty_dirs and file_path.is_dir():
            # 检查空目录
            try:
                if not any(file_path.iterdir()):
                    result["empty_dirs"].append(str(file_path.relative_to(workbuddy_path)))
            except (OSError, PermissionError):
                continue
    
    # 按大小排序
    result["files"].sort(key=lambda x: x["size_kb"], reverse=True)
    
    # Token预估（估算值，仅供参考）
    # 按1KB≈300Token的粗略估算，实际压缩效果取决于内容
    estimated_token_saving = int(result["stats"]["cleanable_size_kb"] * 300)
    result["stats"]["estimated_token_saving"] = estimated_token_saving
    result["stats"]["token_saving_note"] = "（估算值，实际节省取决于压缩率和加载策略）"
    
    # 生成建议
    result["recommendations"] = _generate_scan_recommendations(
        result["stats"],
        len(result["empty_dirs"])
    )
    
    return result


# ============ 清理预览 ============
def generate_cleanup_preview(
    workspace_path: str,
    dry_run: bool = True
) -> dict:
    """
    生成清理预览（dry run模式）

    Args:
        workspace_path: 工作目录路径
        dry_run: True则不实际删除
    """
    scan_result = scan_workspace(workspace_path)

    preview = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "dry_run": dry_run,
        "files_to_clean": [],
        "total_size_kb": 0,
        "token_saving": 0,
        "message": ""
    }

    if "error" in scan_result:
        preview["error"] = scan_result["error"]
        return preview

    for f in scan_result["files"]:
        if f["cleanable"]:
            preview["files_to_clean"].append(f)
            preview["total_size_kb"] += f["size_kb"]

    # Token节省预估（估算值）
    preview["token_saving"] = int(preview["total_size_kb"] * 300)
    preview["token_saving_note"] = "（估算值，仅供参考）"

    if dry_run:
        preview["message"] = f"预览模式：{len(preview['files_to_clean'])}个文件({preview['total_size_kb']:.1f}KB)，确认执行请回复'同意'"
    else:
        preview["message"] = f"将删除{len(preview['files_to_clean'])}个文件"

    return preview


# ============ P0: 实际清理执行 ============
def execute_cleanup(workspace_path: str, confirm: bool = False) -> dict:
    """
    执行实际清理操作（P0修复）

    Args:
        workspace_path: 工作目录路径
        confirm: 是否确认删除（默认False，需显式确认）

    Returns:
        清理结果统计
    """
    base_path = Path(workspace_path).resolve()
    workbuddy_path = base_path / ".workbuddy"

    result = {
        "deleted_count": 0,
        "deleted_size_kb": 0,
        "failed_count": 0,
        "errors": []
    }

    if not workbuddy_path.exists():
        result["errors"].append(".workbuddy目录不存在")
        return result

    # 扫描可清理文件
    files_to_delete = []
    for file_path in workbuddy_path.rglob("*"):
        if is_symlink(file_path):
            continue
        if safe_resolve(file_path, workbuddy_path) is None:
            continue

        if file_path.is_file():
            rel_path = file_path.relative_to(workbuddy_path)
            parent_dir = str(rel_path.parts[0]) if rel_path.parts else ""

            # 检查是否受保护
            if parent_dir in PROTECTED_DIRS:
                continue

            # 检查是否可清理
            is_cleanable = (
                file_path.suffix.lower() in CLEANABLE_EXTS or
                'cache' in file_path.name.lower() or
                'temp' in file_path.name.lower()
            )

            if is_cleanable:
                files_to_delete.append(file_path)

    # 批量删除（仅在确认后执行）
    if confirm:
        print(f"\n开始清理 {len(files_to_delete)} 个文件...")
        for file_path in files_to_delete:
            try:
                mtime, size_kb = get_file_info(file_path)
                file_path.unlink()
                result["deleted_count"] += 1
                result["deleted_size_kb"] += size_kb if size_kb else 0
            except Exception as e:
                result["failed_count"] += 1
                result["errors"].append(f"{file_path.name}: {str(e)}")
    else:
        # 未确认时只报告
        result["pending_delete"] = len(files_to_delete)

    return result


# ============ P1: 归档功能 ============
def archive_old_memory(
    workspace_path: str,
    age_days: int = 30,
    archive_path: Optional[str] = None,
    confirm: bool = False
) -> dict:
    """
    归档旧记忆文件（P1功能）

    Args:
        workspace_path: 工作目录路径
        age_days: 归档超过N天的文件
        archive_path: 归档目录路径（默认: .workbuddy/archive）
        confirm: 是否确认删除（默认False，需显式确认）
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if archive_path is None:
        archive_dir = base_path / ".workbuddy" / "archive"
    else:
        archive_dir = Path(archive_path)

    # 创建归档目录
    archive_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "archived_count": 0,
        "archived_size_kb": 0,
        "failed_count": 0,
        "archive_path": str(archive_dir)
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 扫描旧文件
    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        # 跳过MEMORY.md和不超龄文件
        if md_file.name == "MEMORY.md":
            continue
        age = (datetime.now() - mtime).days
        if age <= age_days:
            continue

        try:
            # 压缩归档
            archive_name = f"{md_file.stem}_{mtime.strftime('%Y%m%d')}.md.gz"
            archive_file = archive_dir / archive_name

            with open(md_file, 'rb') as f_in:
                with gzip.open(archive_file, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)

            # 删除原文件（仅在确认后执行）
            if confirm:
                md_file.unlink()
            else:
                # 未确认时只归档不删除，记录为"待确认"
                result["pending_delete"] = result.get("pending_delete", 0) + 1

            result["archived_count"] += 1
            result["archived_size_kb"] += size_kb
        except Exception as e:
            result["failed_count"] += 1

    return result


# ============ P0: 摘要生成 ============
def extract_keywords(content: str, max_keywords: int = 5) -> list:
    """
    提取关键词（简单实现：统计高频词）

    Args:
        content: 文件内容
        max_keywords: 最大关键词数量

    Returns:
        关键词列表
    """
    import re
    # 简单分词
    words = re.findall(r'[\w]{2,}', content.lower())
    # 停用词
    stopwords = {'的', '了', '是', '在', '和', '与', '或', '等', '于', '对', '这', '那', '有', '我', '你', '他', '她', '它', '们', '一个', '我们', '他们', '这个', '什么', '如何', '怎么', '可以', '需要', '如果', '因为', '所以', '但是', '而且', '或者', '以及', '对于', '关于', '通过', '使用', '进行', '实现', '完成', '开始', '结束', '之后', '之前', '时候', '情况', '问题', '方法', '内容', '文件', '功能', '支持'}
    # 过滤停用词
    words = [w for w in words if w not in stopwords and len(w) > 1]
    # 统计频率
    from collections import Counter
    counter = Counter(words)
    return [w for w, _ in counter.most_common(max_keywords)]


def generate_summary(content: str, max_chars: int = SUMMARY_MAX_CHARS) -> str:
    """
    生成摘要（规则-based实现，减少TOKEN消耗）

    策略：
    1. 提取第一段作为概述
    2. 提取带#的标题行
    3. 提取关键结论
    """
    lines = content.split('\n')
    summary_parts = []

    # 1. 提取标题
    headers = [l.strip() for l in lines if l.strip().startswith('#') and len(l) < 100]
    if headers:
        summary_parts.extend(headers[:3])

    # 2. 提取无序列表项（通常是关键点）
    bullets = [l.strip().lstrip('-*').strip() for l in lines
              if l.strip().startswith(('-', '*')) and len(l) > 5]
    if bullets:
        summary_parts.extend(bullets[:5])

    # 3. 提取表格第一行（通常是重要信息）
    tables = []
    in_table = False
    for l in lines:
        if '|' in l and l.count('|') >= 2:
            if not in_table:
                tables.append(l.strip())
                in_table = True
        else:
            in_table = False

    # 4. 如果摘要太短，添加第一段
    summary = '\n'.join(summary_parts)
    if len(summary) < 100 and lines:
        # 找第一段非空文字
        for l in lines:
            if l.strip() and not l.strip().startswith('#'):
                para = l.strip()[:max_chars]
                if len(summary) < max_chars:
                    summary += '\n' + para

    # 截断到最大长度
    if len(summary) > max_chars:
        summary = summary[:max_chars] + '...'

    return summary.strip()


def summarize_memory(
    workspace_path: str,
    file_name: Optional[str] = None,
    regenerate: bool = False
) -> dict:
    """
    摘要生成功能（P0核心）

    Args:
        workspace_path: 工作目录路径
        file_name: 指定文件（None则处理所有）
        regenerate: 是否强制重新生成

    Returns:
        摘要结果
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    # 创建摘要目录
    summary_path.mkdir(parents=True, exist_ok=True)

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "summarized": [],
        "skipped": [],
        "errors": []
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 处理单个文件
    def process_file(md_file: Path) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        # 检查缓存
        summary_file = summary_path / f"{md_file.stem}.summary"

        if summary_file.exists() and not regenerate:
            # 读取缓存
            with open(summary_file, 'r', encoding='utf-8') as f:
                return json.loads(f.read())

        # 读取原文件
        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # 生成摘要
        summary = generate_summary(content)
        keywords = extract_keywords(content)

        mtime, size_kb = get_file_info(md_file)

        summary_data = {
            "file": md_file.name,
            "summary": summary,
            "keywords": keywords,
            "size_kb": size_kb,
            "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
            "generated": datetime.now().isoformat(),
            "token_estimate": len(summary) // 4  # 粗略估算
        }

        # 保存缓存
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=2)

        return summary_data

    # 处理文件
    if file_name:
        md_file = memory_path / file_name
        if not md_file.exists():
            result["error"] = f"文件不存在: {file_name}"
            return result
        data = process_file(md_file)
        if data:
            result["summarized"].append(data)
        else:
            result["errors"].append(f"处理失败: {file_name}")
    else:
        # 处理所有md文件
        for md_file in memory_path.glob("*.md"):
            data = process_file(md_file)
            if data:
                result["summarized"].append(data)
            else:
                result["skipped"].append(md_file.name)

    return result


# ============ P0: 重要性分级 ============
def rank_memory(
    workspace_path: str,
    weights: Optional[dict] = None,
    days: Optional[int] = None  # 🆕 V2.8.1: 只处理N天内修改的文件
) -> dict:
    """
    记忆重要性分级（P0核心）

    Args:
        workspace_path: 工作目录路径
        weights: 评分权重
        days: 🆕 V2.8.1 只处理N天内修改的文件（None=全部）

    评分维度：
    - 访问频率 (40%): 最近访问次数越多越重要
    - 时间衰减 (30%): 新记忆权重更高
    - 内容长度 (15%): 内容适中最重要（过短无意义，过长冗余）
    - 关键词匹配 (15%): 匹配用户关注领域

    分级结果：
    - 核心记忆 (>=70%): 全部加载
    - 普通记忆 (30%-70%): 摘要加载
    - 冷门记忆 (<30%): 归档压缩
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"

    if weights is None:
        weights = {"access": 0.4, "recency": 0.3, "length": 0.15, "keywords": 0.15}

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "days_filter": days,  # 🆕 记录过滤条件
        "core": [],
        "normal": [],
        "cold": [],
        "stats": {
            "total": 0,
            "core_count": 0,
            "normal_count": 0,
            "cold_count": 0
        }
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    # 🆕 V2.8.1 计算日期过滤边界
    cutoff_date = None
    if days is not None:
        cutoff_date = datetime.now() - timedelta(days=days)

    # 读取摘要索引（如果有）
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR
    index_file = summary_path / SUMMARY_INDEX_FILE
    access_counts = {}

    if index_file.exists():
        with open(index_file, 'r', encoding='utf-8') as f:
            index_data = json.load(f)
            access_counts = index_data.get("access_counts", {})

    # 评分每个文件
    memory_scores = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file) or md_file.name == "MEMORY.md":
            continue

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue

        # 🆕 V2.8.1 日期过滤：跳过超过N天的文件
        if cutoff_date and mtime < cutoff_date:
            continue

        age_days = (datetime.now() - mtime).days
        size_kb = size_kb or 0

        # 1. 访问频率得分 (0-100)
        access_count = access_counts.get(md_file.name, 0)
        access_score = min(100, access_count * 20)  # 每次访问+20，最高100

        # 2. 时间衰减得分 (0-100) - 越新越高
        recency_score = max(0, 100 - age_days * 2)  # 每天-2分

        # 3. 内容长度得分 (0-100) - 1-10KB最佳
        if size_kb < 0.5:
            length_score = size_kb * 100  # 太短
        elif size_kb > 10:
            length_score = max(0, 100 - (size_kb - 10) * 5)  # 太长
        else:
            length_score = 100  # 最佳范围

        # 4. 关键词匹配得分 (如果有摘要)
        keyword_score = 50  # 默认
        summary_file = summary_path / f"{md_file.stem}.summary"
        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)
                # 如果有关键词，额外加分
                keywords = summary_data.get("keywords", [])
                if keywords:
                    keyword_score = 70  # 有摘要的稍微加分

        # 综合得分
        total_score = (
            access_score * weights["access"] +
            recency_score * weights["recency"] +
            length_score * weights["length"] +
            keyword_score * weights["keywords"]
        ) / 100

        # 分级
        memory_info = {
            "file": md_file.name,
            "score": round(total_score, 2),
            "size_kb": round(size_kb, 2),
            "age_days": age_days,
            "modified": mtime.strftime("%Y-%m-%d"),
            "details": {
                "access_score": round(access_score, 1),
                "recency_score": round(recency_score, 1),
                "length_score": round(length_score, 1),
                "keyword_score": round(keyword_score, 1)
            }
        }

        if total_score >= RANK_CORE_THRESHOLD * 100:
            result["core"].append(memory_info)
        elif total_score >= RANK_NORMAL_THRESHOLD * 100:
            result["normal"].append(memory_info)
        else:
            result["cold"].append(memory_info)

        memory_scores.append(total_score)

    # 统计
    result["stats"]["total"] = len(memory_scores)
    result["stats"]["core_count"] = len(result["core"])
    result["stats"]["normal_count"] = len(result["normal"])
    result["stats"]["cold_count"] = len(result["cold"])

    # 按分数排序
    result["core"].sort(key=lambda x: x["score"], reverse=True)
    result["normal"].sort(key=lambda x: x["score"], reverse=True)
    result["cold"].sort(key=lambda x: x["score"], reverse=True)

    return result


# ============ P0: 智能加载 ============
def load_memory(
    workspace_path: str,
    mode: str = LOAD_NORMAL,
    keyword: Optional[str] = None,
    limit: int = 10,
    days: Optional[int] = None  # 🆕 V2.8.1: 只加载N天内修改的文件
) -> dict:
    """
    智能加载记忆（P0核心）

    Args:
        workspace_path: 工作目录路径
        mode: 加载模式 (brief/normal/full)
        keyword: 关键词过滤
        limit: 返回数量限制
        days: 🆕 V2.8.1 只加载N天内修改的文件（None=加载全部）

    Returns:
        加载的记忆内容
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "mode": mode,
        "days_filter": days,  # 🆕 记录过滤条件
        "loaded": [],
        "total_tokens_estimate": 0
    }

    # 先做分级（带days过滤）
    rank_result = rank_memory(workspace_path, days=days)

    # 🆕 V2.8.1 辅助函数：截断输出内容（省Token）
    def truncate_output(text: str, max_chars: int = MAX_OUTPUT_CHARS) -> str:
        """截断文本到最大字符数"""
        if len(text) <= max_chars:
            return text
        return text[:max_chars] + "..."

    # 根据分级和模式决定加载哪些
    def load_file(md_file: Path, load_mode: str) -> Optional[dict]:
        if is_symlink(md_file):
            return None

        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            return None

        content, status = safe_file_read(md_file)
        if content is None:
            return None

        # 根据模式决定加载内容
        if load_mode == LOAD_BRIEF:
            # 只加载摘要
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    return {
                        "file": md_file.name,
                        "type": "summary",
                        "content": truncate_output(summary_data.get("summary", "")),  # 🆕 压缩输出
                        "keywords": summary_data.get("keywords", []),
                        "modified": mtime.strftime("%Y-%m-%d"),
                        "token_estimate": summary_data.get("token_estimate", 0)
                    }
            else:
                # 无摘要，生成一个
                summary = generate_summary(content, 200)
                return {
                    "file": md_file.name,
                    "type": "summary",
                    "content": truncate_output(summary),  # 🆕 压缩输出
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        elif load_mode == LOAD_NORMAL:
            # 摘要 + 关键段落
            summary_file = summary_path / f"{md_file.stem}.summary"
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    summary = summary_data.get("summary", "")
                # 追加部分原文
                lines = content.split('\n')
                key_lines = [l for l in lines if l.strip().startswith(('-', '*'))][:5]
                extra = '\n'.join(key_lines)
                # 🆕 压缩输出：摘要200 + 关键要点100
                full_content = summary[:200] + ("\n\n关键要点:\n" + extra[:100] if extra else "")
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": truncate_output(full_content, MAX_OUTPUT_CHARS),  # 🆕 压缩输出
                    "keywords": summary_data.get("keywords", []),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(full_content) // 4
                }
            else:
                summary = generate_summary(content, 500)
                return {
                    "file": md_file.name,
                    "type": "summary+keys",
                    "content": truncate_output(summary, MAX_OUTPUT_CHARS),  # 🆕 压缩输出
                    "keywords": extract_keywords(content),
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "token_estimate": len(summary) // 4
                }

        else:  # full
            # 🆕 full模式也做限制（仅full模式可用）
            return {
                "file": md_file.name,
                "type": "full",
                "content": content[:5000] if len(content) > 5000 else content,  # 🆕 限制5KB
                "modified": mtime.strftime("%Y-%m-%d"),
                "token_estimate": len(content) // 4
            }

    # 优先加载核心记忆
    files_to_load = []

    # 核心记忆 → 全部加载
    for item in rank_result.get("core", [])[:limit]:
        files_to_load.append((memory_path / item["file"], LOAD_FULL))

    # 普通记忆 → 摘要加载
    normal_limit = limit - len(files_to_load)
    for item in rank_result.get("normal", [])[:max(0, normal_limit)]:
        files_to_load.append((memory_path / item["file"], mode))

    # 冷门记忆 → 全部摘要
    cold_limit = limit - len(files_to_load)
    for item in rank_result.get("cold", [])[:max(0, cold_limit)]:
        files_to_load.append((memory_path / item["file"], LOAD_BRIEF))

    # 关键词过滤
    if keyword:
        keyword = keyword.lower()
        files_to_load = [
            (f, m) for f, m in files_to_load
            if keyword in f.name.lower() or (summary_path / f"{f.stem}.summary").exists()
        ]

    # 加载
    for md_file, load_mode in files_to_load:
        data = load_file(md_file, load_mode)
        if data:
            result["loaded"].append(data)
            result["total_tokens_estimate"] += data.get("token_estimate", 0)

    return result


# ============ P1: 搜索功能 ============
def search_memory(
    workspace_path: str,
    keyword: str,
    mode: str = "brief"
) -> dict:
    """
    记忆搜索功能（P1）

    Args:
        workspace_path: 工作目录路径
        keyword: 搜索关键词
        mode: 搜索模式 (brief/normal/full)

    Returns:
        搜索结果
    """
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    summary_path = base_path / ".workbuddy" / SUMMARY_DIR

    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "keyword": keyword,
        "matches": [],
        "total": 0
    }

    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result

    keyword_lower = keyword.lower()
    matches = []

    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue

        # 先检查摘要（快速）
        summary_file = summary_path / f"{md_file.stem}.summary"
        score = 0

        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)

            # 检查关键词匹配
            if keyword_lower in summary_data.get("summary", "").lower():
                score += 10
            if keyword_lower in " ".join(summary_data.get("keywords", [])).lower():
                score += 20
        else:
            # 无摘要，读取原文
            content, _ = safe_file_read(md_file)
            if content and keyword_lower in content.lower():
                score = 5
            else:
                continue

        if score > 0:
            mtime, size_kb = get_file_info(md_file)

            # 根据模式决定返回内容
            if mode == LOAD_BRIEF:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")[:200]
            elif mode == LOAD_NORMAL:
                content_preview = ""
                if summary_file.exists():
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content_preview = json.load(f).get("summary", "")
            else:
                content, _ = safe_file_read(md_file)
                content_preview = content[:500] if content else ""

            matches.append({
                "file": md_file.name,
                "score": score,
                "modified": mtime.strftime("%Y-%m-%d") if mtime else "unknown",
                "preview": content_preview,
                "size_kb": round(size_kb, 2) if size_kb else 0
            })

    # 按分数排序
    matches.sort(key=lambda x: x["score"], reverse=True)
    result["matches"] = matches
    result["total"] = len(matches)

    return result


# ============ P2: HTML报告生成 ============
def generate_html_report(result: dict, output_path: Optional[str] = None) -> str:
    """
    生成HTML格式的存储报告（P2功能）
    """
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>记忆管家 V{VERSION} - 存储报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; background: #f5f5f5; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; }}
        .stat-card.green {{ background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }}
        .stat-card.orange {{ background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }}
        .stat-card h3 {{ margin: 0 0 10px; font-size: 14px; opacity: 0.9; }}
        .stat-card .value {{ font-size: 28px; font-weight: bold; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #3498db; color: white; }}
        tr:hover {{ background: #f8f9fa; }}
        .badge {{ display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
        .badge-protected {{ background: #e74c3c; color: white; }}
        .badge-cleanable {{ background: #27ae60; color: white; }}
        .footer {{ text-align: center; color: #999; margin-top: 30px; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧠 记忆管家 V{VERSION} - 存储报告</h1>
        <p>📁 {result.get('workspace', 'N/A')} | ⏰ {result.get('timestamp', 'N/A')[:19]}</p>

        <div class="stats">
            <div class="stat-card">
                <h3>📁 总文件数</h3>
                <div class="value">{result['stats'].get('total_files', 0)}</div>
            </div>
            <div class="stat-card green">
                <h3>💾 总占用</h3>
                <div class="value">{result['stats'].get('total_size_kb', 0):.1f} KB</div>
            </div>
            <div class="stat-card orange">
                <h3>🗑️ 可清理</h3>
                <div class="value">{result['stats'].get('cleanable_size_kb', 0):.1f} KB</div>
            </div>
        </div>

        <h2>📋 文件列表</h2>
        <table>
            <thead>
                <tr>
                    <th>文件名</th>
                    <th>大小</th>
                    <th>修改时间</th>
                    <th>状态</th>
                </tr>
            </thead>
            <tbody>
"""

    for f in result.get('files', [])[:50]:
        status = '<span class="badge badge-protected">🔒 受保护</span>' if f.get('protected') else \
                 '<span class="badge badge-cleanable">🗑️ 可清理</span>' if f.get('cleanable') else '📄'
        html += f"""
                <tr>
                    <td>{f['name'][:40]}</td>
                    <td>{f['size_kb']:.2f} KB</td>
                    <td>{f['modified']}</td>
                    <td>{status}</td>
                </tr>
"""

    html += f"""
            </tbody>
        </table>

        <h2>💡 优化建议</h2>
        <ul>
"""
    for rec in result.get('recommendations', []):
        html += f"<li>{rec}</li>"

    html += f"""
        </ul>

        <div class="footer">
            生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 记忆管家 V{VERSION}
        </div>
    </div>
</body>
</html>"""

    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return output_path

    return html


# ============ 辅助函数 ============
def _generate_recommendations(files: list, stats: dict) -> list:
    """生成记忆优化建议"""
    recs = []
    
    if stats["total_size_kb"] > 100:
        recs.append(f"💡 记忆文件较大({stats['total_size_kb']:.1f}KB)，建议清理过期日志")
    
    if stats["total_files"] > 20:
        recs.append(f"📁 文件数量较多({stats['total_files']}个)，建议合并或归档旧日志")
    
    cleanable_count = stats.get("cleanable_files", 0)
    if cleanable_count > 0:
        recs.append(f"🧹 有{cleanable_count}个30天前的日志可清理")
    
    if not recs:
        recs.append("✨ 记忆状态良好，无需清理")
    
    return recs


def _generate_scan_recommendations(stats: dict, empty_dir_count: int) -> list:
    """生成扫描优化建议"""
    recs = []
    
    cleanable = stats["cleanable_size_kb"]
    if cleanable > 50:
        recs.append(f"💾 可清理缓存: {cleanable:.1f}KB，建议清理")
    elif cleanable > 0:
        recs.append(f"💾 可清理缓存: {cleanable:.1f}KB")
    
    if empty_dir_count > 0:
        recs.append(f"📂 发现{empty_dir_count}个空目录可清理")
    
    if stats["total_files"] > 100:
        recs.append(f"📁 文件数量较多({stats['total_files']}个)，建议检查是否冗余")
    
    if cleanable == 0 and empty_dir_count == 0:
        recs.append("✨ 存储状态良好，无需清理")
    
    return recs


def print_report(result: dict, format_type: str = "text") -> None:
    """格式化输出报告（带颜色）"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    # 文本格式输出
    print(f"\n{C['bright']}{'='*50}{C['reset']}")
    print(f"{C['cyan']}🧠 记忆管家 V{VERSION} - 存储报告{C['reset']}")
    print(f"{C['bright']}{'='*50}{C['reset']}")
    print(f"📁 工作目录: {result.get('workspace', 'N/A')}")
    print(f"⏰ 扫描时间: {result.get('timestamp', 'N/A')[:19]}")
    print()

    if "error" in result:
        print(f"{C['red']}❌ 错误: {result['error']}{C['reset']}")
        return

    stats = result.get("stats", {})
    print(f"📊 统计概览:")
    print(f"   总文件数: {C['white']}{stats.get('total_files', 0)}{C['reset']} 个")
    print(f"   总占用: {C['yellow']}{stats.get('total_size_kb', 0):.2f} KB{C['reset']}")
    print(f"   可清理: {C['green']}{stats.get('cleanable_size_kb', 0):.2f} KB{C['reset']} ({stats.get('cleanable_files', 0)} 个)")

    if "estimated_token_saving" in stats:
        print(f"   预估Token节省: ~{C['magenta']}{stats['estimated_token_saving']}{C['reset']}")

    if result.get("files"):
        print(f"\n📈 文件分布 (前10个最大文件):")
        for i, f in enumerate(result["files"][:10], 1):
            if f.get("protected"):
                status = f"{C['red']}🔒{C['reset']}"
            elif f.get("cleanable"):
                status = f"{C['green']}🗑️{C['reset']}"
            else:
                status = "📄"
            img = f" [{f.get('image_format')}]" if f.get("image_format") else ""
            print(f"   {status} {i}. {f['name'][:30]:30s} {f['size_kb']:>8.2f} KB {img}")

    if result.get("empty_dirs"):
        print(f"\n📂 空目录 ({len(result['empty_dirs'])}个):")
        for d in result["empty_dirs"][:5]:
            print(f"   • {d}")
        if len(result["empty_dirs"]) > 5:
            print(f"   ... 还有 {len(result['empty_dirs'])-5} 个")

    recs = result.get("recommendations", [])
    if recs:
        print(f"\n💡 优化建议:")
        for r in recs:
            print(f"   {r}")

    if result.get("warning"):
        print(f"\n{C['yellow']}⚠️  警告: {result['warning']}{C['reset']}")

    print(f"\n{C['bright']}{'='*50}{C['reset']}")


def print_memory_analysis(result: dict, format_type: str = "text") -> None:
    """格式化输出记忆分析"""
    if format_type == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    print(f"\n{'='*50}")
    print(f"🧠 记忆管家 V{VERSION} - 记忆分析")
    print(f"{'='*50}")
    print(f"📁 工作目录: {result.get('workspace', 'N/A')}")
    print()
    
    if "error" in result:
        print(f"❌ 错误: {result['error']}")
        return
    
    stats = result.get("stats", {})
    print(f"📊 记忆状态:")
    print(f"   总文件数: {stats.get('total_files', 0)} 个")
    print(f"   总占用: {stats.get('total_size_kb', 0):.2f} KB")
    
    if result.get("files"):
        print(f"\n📝 文件列表:")
        for f in result["files"][:20]:
            age = f.get("age_days", 0)
            status = "🆕" if age <= 7 else "📅" if age <= 30 else "📁"
            clean = "🗑️" if f.get("cleanable") else "  "
            print(f"   {status}{clean} {f['name']:30s} {f['size_kb']:>7.2f}KB  {f['modified']} ({age}天前)")
        
        if len(result["files"]) > 20:
            print(f"   ... 还有 {len(result['files'])-20} 个文件")
    
    recs = result.get("recommendations", [])
    if recs:
        print(f"\n💡 建议:")
        for r in recs:
            print(f"   {r}")
    
    print(f"\n{'='*50}")


def print_preview(preview: dict) -> None:
    """格式化输出清理预览"""
    print(f"\n{'='*50}")
    print(f"🧹 清理预览 {'[预览模式]' if preview.get('dry_run') else ''}")
    print(f"{'='*50}")
    
    if "error" in preview:
        print(f"❌ 错误: {preview['error']}")
        return
    
    files = preview.get("files_to_clean", [])
    print(f"将删除 {len(files)} 个文件 ({preview.get('total_size_kb', 0):.1f} KB)")
    print(f"预估Token节省: ~{preview.get('token_saving', 0)}")
    print()
    
    for i, f in enumerate(files[:20], 1):
        print(f"   [{i}] {f['name'][:40]:40s} {f['size_kb']:>7.2f} KB")
    
    if len(files) > 20:
        print(f"   ... 还有 {len(files)-20} 个文件")
    
    print(f"\n{preview.get('message', '')}")
    print(f"\n{'='*50}")


# ============ CLI入口 ============

# ============ V2.5 新增功能 ============

def compute_content_hash(file_path):
    """计算文件内容哈希（用于去重检测）"""
    try:
        with open(file_path, 'rb') as f:
            return hashlib.md5(f.read(50*1024)).hexdigest()
    except (OSError, IOError, hashlib.HTTPError):
        return ""

def dedup_memory(workspace_path, dry_run=True, delete_dup=False):
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {"total_files": 0, "unique_files": 0, "duplicate_groups": [], "duplicates_found": 0, "space_saved_kb": 0}
    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result
    file_hashes = {}
    for md_file in memory_path.glob("*.md"):
        if md_file.name == "MEMORY.md":
            continue
        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        h = compute_content_hash(md_file)
        if h not in file_hashes:
            file_hashes[h] = []
        file_hashes[h].append({"path": str(md_file), "name": md_file.name, "size_kb": round(size_kb, 2), "modified": mtime.strftime("%Y-%m-%d")})
        result["total_files"] += 1
    for h, files in file_hashes.items():
        if len(files) > 1:
            files.sort(key=lambda x: x["modified"])
            dups = files[1:]
            result["duplicate_groups"].append({"hash": h[:12]+"...", "original": files[0], "duplicates": dups})
            result["duplicates_found"] += len(dups)
            result["space_saved_kb"] += sum(f["size_kb"] for f in dups)
            if not dry_run and delete_dup:
                for dup in dups:
                    try:
                        Path(dup["path"]).unlink()
                    except (OSError, IOError, PermissionError):
                        pass  # 静默忽略删除失败
    result["unique_files"] = result["total_files"] - result["duplicates_found"]
    return result

def get_token_stats_dir(workspace_path):
    base_path = Path(workspace_path).resolve()
    stats_dir = base_path / ".workbuddy" / ".token_stats"
    stats_dir.mkdir(parents=True, exist_ok=True)
    return stats_dir

def record_token_usage(workspace_path, tokens, operation="load"):
    stats_dir = get_token_stats_dir(workspace_path)
    today = datetime.now().date().isoformat()
    stats_file = stats_dir / (today + ".json")
    stats = {"date": today, "operations": {}} if not stats_file.exists() else json.loads(stats_file.read_text(encoding="utf-8"))
    if operation not in stats["operations"]:
        stats["operations"][operation] = {"count": 0, "tokens": 0}
    stats["operations"][operation]["count"] += 1
    stats["operations"][operation]["tokens"] += tokens
    stats_file.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    return stats

def get_token_trends(workspace_path, days=30):
    stats_dir = get_token_stats_dir(workspace_path)
    today = datetime.now().date()
    daily_data, total_tokens, op_totals = [], 0, {}
    for i in range(days):
        date = today - timedelta(days=i)
        stats_file = stats_dir / (date.isoformat() + ".json")
        day_entry = {"date": date.isoformat(), "total_tokens": 0, "operations": {}}
        if stats_file.exists():
            try:
                stats = json.loads(stats_file.read_text(encoding="utf-8"))
                day_total = sum(op["tokens"] for op in stats.get("operations", {}).values())
                day_entry = {"date": date.isoformat(), "total_tokens": day_total, "operations": stats.get("operations", {})}
                total_tokens += day_total
                for op, data in stats.get("operations", {}).items():
                    op_totals[op] = op_totals.get(op, 0) + data["tokens"]
            except (json.JSONDecodeError, KeyError, IOError):
                pass  # 静默忽略损坏的统计文件
        daily_data.append(day_entry)
    daily_data.reverse()
    recent = daily_data[-7:] if len(daily_data) >= 7 else daily_data
    recent_avg = sum(d["total_tokens"] for d in recent) / max(1, len(recent))
    return {"version": "2.5.0", "period_days": days, "daily_data": daily_data, "total_tokens": total_tokens, "daily_average": round(recent_avg, 1), "operation_totals": op_totals}

def backup_memory(workspace_path, backup_path=None, dry_run=True, incremental=True):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    bp_cfg = config.get("_backup_config", {})
    if backup_path is None:
        backup_path = bp_cfg.get("local_path", "")
    if not backup_path:
        return {"error": "未配置备份路径"}
    backup_path = Path(backup_path).resolve()
    base_path = Path(workspace_path).resolve()
    memory_path = base_path / ".workbuddy" / "memory"
    result = {"backup_path": str(backup_path), "files_copied": 0, "files_updated": 0, "total_size_kb": 0}
    if not memory_path.exists():
        result["error"] = "记忆目录不存在"
        return result
    if not dry_run:
        backup_path.mkdir(parents=True, exist_ok=True)
    manifest_file = backup_path / ".backup_manifest.json"
    last_backup = {}
    if manifest_file.exists():
        try:
            last_backup = json.loads(manifest_file.read_text(encoding="utf-8")).get("files", {})
        except (json.JSONDecodeError, IOError, KeyError):
            pass  # 静默忽略损坏的备份记录
    for md_file in memory_path.glob("*.md"):
        if is_symlink(md_file):
            continue
        mtime, size_kb = get_file_info(md_file)
        if mtime is None:
            continue
        rel = md_file.relative_to(memory_path)
        backup_file = backup_path / rel
        current_hash = compute_content_hash(md_file)
        file_key = str(rel)
        should_backup = not incremental or file_key not in last_backup or last_backup.get(file_key, {}).get("hash") != current_hash
        if should_backup:
            if dry_run:
                result["files_copied" if file_key not in last_backup else "files_updated"] += 1
                result["total_size_kb"] += size_kb
            else:
                try:
                    backup_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(md_file, backup_file)
                    result["files_copied" if file_key not in last_backup else "files_updated"] += 1
                    result["total_size_kb"] += size_kb
                except (OSError, IOError, PermissionError) as e:
                    pass  # 静默忽略备份失败
    if not dry_run:
        manifest_file.write_text(json.dumps({"last_backup": datetime.now().isoformat(), "files": {str(f.relative_to(memory_path)): {"hash": compute_content_hash(f), "size_kb": get_file_info(f)[1]} for f in memory_path.glob("*.md")}}, ensure_ascii=False, indent=2), encoding="utf-8")
    return result

def restore_backup(workspace_path, backup_path=None, dry_run=True):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    bp_cfg = config.get("_backup_config", {})
    if backup_path is None:
        backup_path = bp_cfg.get("local_path", "")
    if not backup_path:
        return {"error": "未配置备份路径"}
    backup_path = Path(backup_path).resolve()
    manifest_file = backup_path / ".backup_manifest.json"
    if not manifest_file.exists():
        return {"error": "备份记录不存在"}
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, IOError):
        return {"error": "备份记录损坏，无法解析"}
    result = {"files_restored": 0}
    for file_key in manifest.get("files", {}):
        src = backup_path / file_key
        dst = Path(workspace_path).resolve() / ".workbuddy" / "memory" / file_key
        if src.exists():
            if dry_run:
                result["files_restored"] += 1
            else:
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                    result["files_restored"] += 1
                except (OSError, IOError, PermissionError):
                    pass  # 静默忽略恢复失败
    return result

def setup_schedule(workspace_path, task, enabled=True, schedule="daily", time="18:00", day=None, times=None):
    """
    设置定时任务（V2.7 支持 three_times 多时间点）
    times: 逗号分隔的时间列表，如 "09:00,12:00,18:00"
    """
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    if "_schedule_config" not in config:
        config["_schedule_config"] = {"enabled": False, "tasks": {}}
    if "tasks" not in config["_schedule_config"]:
        config["_schedule_config"]["tasks"] = {}
    
    task_cfg = {"enabled": enabled, "schedule": schedule, "time": time}
    if schedule == "weekly" and day:
        task_cfg["day"] = day
    # V2.7: 支持多时间点
    if schedule == "three_times" and times:
        task_cfg["times"] = [t.strip() for t in times.split(",")]
    
    config["_schedule_config"]["tasks"][task] = task_cfg
    config["_schedule_config"]["enabled"] = any(t.get("enabled", False) for t in config["_schedule_config"]["tasks"].values())
    config_file.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"task": task, "config": task_cfg}

def check_schedule(workspace_path):
    config_file = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "config.json"
    config = json.loads(config_file.read_text(encoding="utf-8")) if config_file.exists() else {}
    sched_cfg = config.get("_schedule_config", {})
    result = {"enabled": sched_cfg.get("enabled", False), "tasks_to_run": [], "tasks_scheduled": []}
    if not result["enabled"]:
        return result
    now = datetime.now()
    for task_name, task_cfg in sched_cfg.get("tasks", {}).items():
        if not task_cfg.get("enabled", False):
            continue
        schedule = task_cfg.get("schedule", "daily")
        task_time = task_cfg.get("time", "18:00")
        task_day = task_cfg.get("day")
        should_run = False
        
        if schedule == "daily" and now.strftime("%H:%M") == task_time:
            should_run = True
        elif schedule == "weekly" and task_day and now.strftime("%A").lower() == task_day and now.strftime("%H:%M") == task_time:
            should_run = True
        elif schedule == "monthly" and now.day == 1 and now.strftime("%H:%M") == task_time:
            should_run = True
        # V2.7: 三时提醒
        elif schedule == "three_times":
            times = task_cfg.get("times", ["09:00", "12:00", "18:00"])
            if now.strftime("%H:%M") in times:
                should_run = True
        
        task_info = {"name": task_name, "schedule": schedule, "time": task_time}
        if should_run:
            result["tasks_to_run"].append(task_info)
        else:
            result["tasks_scheduled"].append(task_info)
    return result

# ============ V2.6 新增功能 ============

def doctor_diagnose(workspace_path: str) -> dict:
    """
    V2.6 新功能：诊断工具
    一键检测配置异常和潜在问题
    """
    base_path = Path(workspace_path).resolve()
    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "issues": [],
        "warnings": [],
        "passed": [],
        "score": 100
    }

    # 1. 检查记忆目录
    memory_path = base_path / ".workbuddy" / "memory"
    if not memory_path.exists():
        result["issues"].append({"type": "error", "item": "记忆目录", "message": ".workbuddy/memory 目录不存在"})
        result["score"] -= 30
    else:
        result["passed"].append({"item": "记忆目录", "status": "正常"})
        # 检查文件权限（使用读取检测，避免写入操作）
        try:
            # 检查目录是否可读
            test_read = any(memory_path.glob("*.md"))
            # 检查目录是否可列举
            list(memory_path.iterdir())
            result["passed"].append({"item": "访问权限", "status": "正常"})
        except (PermissionError, OSError) as e:
            result["issues"].append({"type": "error", "item": "访问权限", "message": f"无法访问记忆目录: {e}"})
            result["score"] -= 20

    # 2. 检查配置文件
    config = load_config()
    if not config:
        result["issues"].append({"type": "warning", "item": "配置文件", "message": "配置文件为空或损坏"})
        result["score"] -= 10
    else:
        result["passed"].append({"item": "配置文件", "status": "正常"})

    # 3. 检查备份配置
    bp_cfg = config.get("_backup_config", {})
    if bp_cfg.get("local_path"):
        backup_path = Path(bp_cfg["local_path"])
        if not backup_path.exists():
            result["warnings"].append({"item": "备份路径", "message": f"配置的备份路径不存在: {backup_path}"})
        else:
            result["passed"].append({"item": "备份路径", "status": "正常"})
    else:
        result["warnings"].append({"item": "备份路径", "message": "未配置备份路径，建议设置以防数据丢失"})

    # 4. 检查定时任务配置
    sched_cfg = config.get("_schedule_config", {})
    if sched_cfg.get("enabled"):
        result["passed"].append({"item": "定时任务", "status": "已启用"})
        # 检查任务配置
        for task_name, task_cfg in sched_cfg.get("tasks", {}).items():
            if not task_cfg.get("enabled"):
                result["warnings"].append({"item": f"任务 {task_name}", "message": "任务已禁用"})
    else:
        result["warnings"].append({"item": "定时任务", "message": "定时任务未启用，建议设置自动清理"})

    # 5. 检查记忆文件状态
    if memory_path.exists():
        md_files = list(memory_path.glob("*.md"))
        total_size = sum(f.stat().st_size for f in md_files if f.is_file()) / 1024

        if len(md_files) > 100:
            result["warnings"].append({"item": "文件数量", "message": f"记忆文件较多({len(md_files)}个)，建议清理或归档"})
            result["score"] -= 5

        if total_size > 500:
            result["warnings"].append({"item": "存储大小", "message": f"记忆占用较大({total_size:.1f}KB)，可能影响Token消耗"})
            result["score"] -= 5

        # 检查重复文件（复用已有的文件列表进行哈希计算，避免重复扫描）
        file_hashes = {}
        dup_count = 0
        for md_file in md_files:
            if md_file.name == "MEMORY.md":
                continue
            h = compute_content_hash(md_file)
            if h in file_hashes:
                dup_count += 1
            else:
                file_hashes[h] = md_file
        
        if dup_count > 0:
            result["warnings"].append({
                "item": "重复文件",
                "message": f"发现约 {dup_count} 个重复文件，建议运行 'python memory_manager.py dedup' 执行去重"
            })

    # 6. 检查摘要缓存
    summary_path = base_path / ".workbuddy" / ".summary"
    if summary_path.exists():
        summary_files = list(summary_path.glob("*.summary"))
        result["passed"].append({"item": "摘要缓存", "status": f"{len(summary_files)} 个缓存"})
    else:
        result["warnings"].append({"item": "摘要缓存", "message": "未生成摘要缓存，建议运行 summarize 命令"})

    # 计算最终评分
    result["score"] = max(0, result["score"])

    return result


def run_wizard(workspace_path: str, step: str = "all") -> dict:
    """
    V2.6 新功能：设置向导
    引导首次配置和路径设置
    """
    base_path = Path(workspace_path).resolve()
    result = {
        "version": VERSION,
        "timestamp": datetime.now().isoformat(),
        "steps_completed": [],
        "config": {}
    }

    # 步骤1: 确认工作目录
    if step in ["all", "workspace"]:
        if base_path.exists() and base_path.is_dir():
            result["steps_completed"].append({"step": "workspace", "status": "ok", "path": str(base_path)})
        else:
            return {"error": f"工作目录不存在: {workspace_path}"}

    # 步骤2: 初始化记忆目录
    if step in ["all", "memory"]:
        memory_path = base_path / ".workbuddy" / "memory"
        memory_path.mkdir(parents=True, exist_ok=True)

        # 创建示例文件（如果不存在）
        example_file = memory_path / "MEMORY.md"
        if not example_file.exists():
            example_file.write_text("""# 记忆管家使用示例

这是一个示例记忆文件。

## 功能说明
- 记忆管家会自动管理这个目录下的文件
- 超过1天的推送类内容会自动清理
- 个人/工作内容会每5天提醒一次

## 保留规则
- 推送类关键词：推送、AI动态、历史推送摘要
- 个人/工作关键词：个人、工作、项目、客户
""", encoding="utf-8")
        result["steps_completed"].append({"step": "memory", "status": "ok", "path": str(memory_path)})

    # 步骤3: 初始化配置
    if step in ["all", "config"]:
        config = load_config()
        # 确保有默认配置
        if "retention_days" not in config:
            config["retention_days"] = 1
        if "_automation_rules" not in config:
            config["_automation_rules"] = DEFAULT_CONFIG["_automation_rules"]
        save_config(config)
        result["steps_completed"].append({"step": "config", "status": "ok"})
        result["config"] = config

    # 步骤4: 生成摘要
    if step in ["all", "summarize"]:
        summary_result = summarize_memory(workspace_path, regenerate=True)
        result["steps_completed"].append({
            "step": "summarize",
            "status": "ok",
            "summarized": len(summary_result.get("summarized", []))
        })

    return result


def collect_feedback(workspace_path: str, feedback_type: str, content: str) -> dict:
    """
    V2.6 新功能：用户反馈收集
    收集使用问题和建议
    """
    feedback_dir = Path.home() / ".workbuddy" / "skills" / "memory-manager-v2" / "feedback"
    feedback_dir.mkdir(parents=True, exist_ok=True)

    # 生成反馈文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    feedback_file = feedback_dir / f"feedback_{timestamp}.json"

    feedback_data = {
        "version": VERSION,
        "type": feedback_type,  # bug/feature/suggestion/general
        "content": content,
        "timestamp": datetime.now().isoformat(),
        "workspace": workspace_path,
        "status": "pending"  # pending/processed/resolved
    }

    feedback_file.write_text(json.dumps(feedback_data, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "status": "saved",
        "file": str(feedback_file),
        "message": "感谢您的反馈！"
    }


def add_v25_cli(subparsers):
    # V2.6: doctor命令
    doctor_parser = subparsers.add_parser("doctor", help="诊断工具 - 检测配置异常和潜在问题")

    # V2.6: wizard命令
    wizard_parser = subparsers.add_parser("wizard", help="设置向导 - 引导首次配置")
    wizard_parser.add_argument("--step", type=str, default="all",
                              choices=["all", "workspace", "memory", "config", "summarize"],
                              help="执行的步骤")

    # V2.6: feedback命令
    feedback_parser = subparsers.add_parser("feedback", help="用户反馈 - 提交问题或建议")
    feedback_parser.add_argument("--type", type=str, default="general",
                                choices=["bug", "feature", "suggestion", "general"],
                                help="反馈类型")
    feedback_parser.add_argument("--content", type=str, required=True,
                                help="反馈内容")

    # V2.5: dedup命令
    dedup_parser = subparsers.add_parser("dedup", help="基于内容哈希去重")
    dedup_parser.add_argument("--execute", action="store_true", help="执行去重")
    stats_parser = subparsers.add_parser("stats", help="Token消耗趋势")
    stats_parser.add_argument("--days", type=int, default=30, help="统计天数")
    backup_parser = subparsers.add_parser("backup", help="备份/恢复")
    backup_parser.add_argument("--path", type=str, help="备份目录")
    backup_parser.add_argument("--execute", action="store_true", help="执行备份")
    backup_parser.add_argument("--restore", action="store_true", help="从备份恢复")
    schedule_parser = subparsers.add_parser("schedule", help="定时任务")
    schedule_parser.add_argument("--task", type=str, choices=["auto_clean", "backup", "dedup", "cache_reminder", "report"], help="任务名（report=记忆清单报告）")
    schedule_parser.add_argument("--enable", action="store_true")
    schedule_parser.add_argument("--disable", action="store_true")
    schedule_parser.add_argument("--schedule", type=str, default="daily", choices=["daily", "weekly", "monthly", "three_times"])
    schedule_parser.add_argument("--time", type=str, default="18:00", help="单时间点（daily/weekly/monthly用）")
    schedule_parser.add_argument("--times", type=str, help="多时间点（three_times用，逗号分隔，如 09:00,12:00,18:00）")
    schedule_parser.add_argument("--day", type=str)
    schedule_parser.add_argument("--check", action="store_true")

def handle_v25_command(args):
    # V2.6: doctor命令
    if args.command == "doctor":
        res = doctor_diagnose(args.workspace)
        print(f"\n{C['bright']}{'='*50}{C['reset']}")
        print(f"{C['cyan']}🔍 记忆管家 V{VERSION} - 诊断报告{C['reset']}")
        print(f"{'='*50}")
        print(f"\n📊 健康评分: {C['yellow']}{res['score']}/100{C['reset']}")

        if res["issues"]:
            print(f"\n{C['red']}❌ 问题 ({len(res['issues'])} 个):{C['reset']}")
            for issue in res["issues"]:
                print(f"   • [{issue['type']}] {issue['item']}: {issue['message']}")

        if res["warnings"]:
            print(f"\n{C['yellow']}⚠️  警告 ({len(res['warnings'])} 个):{C['reset']}")
            for warn in res["warnings"]:
                print(f"   • {warn['item']}: {warn['message']}")

        if res["passed"]:
            print(f"\n{C['green']}✅ 正常 ({len(res['passed'])} 项):{C['reset']}")
            for item in res["passed"][:5]:
                print(f"   ✓ {item['item']}: {item['status']}")
            if len(res["passed"]) > 5:
                print(f"   ... 还有 {len(res['passed'])-5} 项")

        print(f"\n{'='*50}")
        return res

    # V2.6: wizard命令
    elif args.command == "wizard":
        print(f"\n{C['yellow']}⚠️  设置向导将在工作目录创建以下结构:{''}")
        print(f"   - .workbuddy/memory/  (记忆目录)")
        print(f"   - .workbuddy/config.json  (配置文件)")
        print(f"回复 '同意' 确认: ")
        user_input = input().strip()
        if user_input != '同意':
            print(f"{C['red']}❌ 取消向导{''}")
            return {"cancelled": True}
        res = run_wizard(args.workspace, step=args.step)
        print(f"\n{C['bright']}{'='*50}{C['reset']}")
        print(f"{C['cyan']}🧙 记忆管家 V{VERSION} - 设置向导{C['reset']}")
        print(f"{'='*50}")

        if "error" in res:
            print(f"{C['red']}❌ 错误: {res['error']}{C['reset']}")
            return res

        print(f"\n✅ 已完成 {len(res['steps_completed'])} 个步骤:")
        for step in res["steps_completed"]:
            print(f"   ✓ {step['step']}: {step['status']}")
            if "path" in step:
                print(f"     路径: {step['path']}")
            if "summarized" in step:
                print(f"     已生成 {step['summarized']} 个摘要")

        print(f"\n💡 建议下一步:")
        print(f"   - 运行 'python memory_manager.py doctor' 检查配置")
        print(f"   - 运行 'python memory_manager.py auto-clean --execute' 执行首次清理")
        print(f"   - 运行 'python memory_manager.py config' 查看当前配置")

        print(f"\n{'='*50}")
        return res

    # V2.6: feedback命令
    elif args.command == "feedback":
        res = collect_feedback(args.workspace, args.type, args.content)
        print(f"\n{C['green']}✅ {res['message']}{C['reset']}")
        print(f"   反馈类型: {args.type}")
        print(f"   保存位置: {res['file']}")
        return res

    # V2.5: dedup命令
    if args.command == "dedup":
        res = dedup_memory(args.workspace, dry_run=not args.execute, delete_dup=args.execute)
        print("\n总文件: %d | 唯一: %d | 重复: %d | 可回收: %.1fKB" % (res.get("total_files", 0), res.get("unique_files", 0), res.get("duplicates_found", 0), res.get("space_saved_kb", 0)))
        if res.get("duplicate_groups"):
            print("\n重复组（前5组）:")
            for g in res["duplicate_groups"][:5]:
                print("  原始: %s (%s)" % (g["original"]["name"], g["original"]["modified"]))
                print("  重复: %s" % ", ".join(d["name"] for d in g["duplicates"]))
        if not args.execute and res.get("duplicates_found", 0) > 0:
            print("\n[提示] 使用 --execute 确认删除")
        elif args.execute and res.get("duplicates_found", 0) > 0:
            print(f"\n{C['yellow']}⚠️  将删除 {res['duplicates_found']} 个重复文件（不可恢复）{''}")
            print(f"{C['yellow']}回复「同意」确认删除:{''}")
            try:
                user_input = input().strip()
            except EOFError:
                user_input = ""
            if user_input == "同意":
                res = dedup_memory(args.workspace, dry_run=False, delete_dup=True)
                print(f"\n{C['green']}✅ 已删除 {res['duplicates_found']} 个重复文件，释放 {res['space_saved_kb']:.1f} KB{''}")
            else:
                print(f"\n{C['red']}❌ 取消去重操作{''}")
        return res
    elif args.command == "stats":
        res = get_token_trends(args.workspace, days=args.days)
        print("\n[Token统计] 最近%d天:" % res["period_days"])
        print("   总消耗: %s | 日均: %s" % (format(res["total_tokens"], ","), format(int(res["daily_average"]), ",")))
        for op, tokens in res.get("operation_totals", {}).items():
            if tokens > 0:
                pct = tokens / max(1, res["total_tokens"]) * 100
                bar = "#" * int(pct / 3)
                print("   %-12s: %s %s (%.1f%%)" % (op, bar, format(tokens, ","), pct))
        print("\n   最近7天趋势:")
        for d in res["daily_data"][-7:]:
            bar = "#" * min(30, int(d["total_tokens"] / max(1, res["daily_average"]) * 30))
            print("   %s: %s %s" % (d["date"][5:], bar, format(d["total_tokens"], ",")))
        return res
    elif args.command == "backup":
        if args.restore:
            res = restore_backup(args.workspace, args.path, dry_run=not args.execute)
            print("\n[%s] 将恢复 %d 个文件" % ("预览" if not args.execute else "完成", res.get("files_restored", 0)))
        else:
            res = backup_memory(args.workspace, args.path, dry_run=not args.execute)
            if res.get("error"):
                print("\n[错误] %s" % res["error"])
            else:
                print("\n备份[%s]:" % ("预览" if not args.execute else "完成"))
                print("   路径: %s" % res.get("backup_path"))
                print("   新增: %d | 更新: %d | 大小: %.1fKB" % (res.get("files_copied", 0), res.get("files_updated", 0), res.get("total_size_kb", 0)))
        return res
    elif args.command == "schedule":
        if args.check:
            res = check_schedule(args.workspace)
            print("\n[定时任务] 状态: %s" % ("已启用" if res["enabled"] else "已禁用"))
            for t in res.get("tasks_scheduled", []):
                info = "   - %s: %s" % (t["name"], t["schedule"])
                if t.get("time"):
                    info += " @ %s" % t["time"]
                if t.get("day"):
                    info += " (%s)" % t["day"]
                if t.get("times"):
                    info += " [%s]" % ", ".join(t["times"])
                print(info)
            if res.get("tasks_to_run"):
                print("   >> 待执行: %s" % ", ".join(t["name"] for t in res["tasks_to_run"]))
        elif args.task:
            enabled = args.enable and not args.disable
            res = setup_schedule(args.workspace, args.task, enabled=enabled, 
                               schedule=args.schedule, time=args.time, 
                               day=args.day, times=args.times)
            print("\n[OK] 已%s定时任务: %s" % ("启用" if enabled else "禁用", args.task))
            print("  周期: %s" % res["config"]["schedule"])
            if res["config"].get("times"):
                print("  时间点: %s" % ", ".join(res["config"]["times"]))
            elif res["config"].get("time"):
                print("  时间: %s" % res["config"]["time"])
            if res["config"].get("day"):
                print("  星期: %s" % res["config"]["day"])
        return res
    return {}


# ============ Command Handlers ============

def _handle_clean(args, C):
    """处理 clean 命令（需要交互确认）"""
    preview = execute_cleanup(args.workspace, confirm=False)
    if preview.get("errors"):
        for err in preview["errors"]:
            print(f"{C['red']}❌ {err}{''}")
        return
    if preview.get("pending_delete", 0) > 0:
        print(f"\n{C['yellow']}⚠️  将清理 {preview['pending_delete']} 个可清理文件{''}")
        print("此操作将永久删除，请确保已查看预览。")
        print("回复 '同意' 确认执行:")
        user_input = input().strip()
        if user_input == '同意':
            result = execute_cleanup(args.workspace, confirm=True)
            print(f"\n{C['green']}✅ 已清理 {result['deleted_count']} 个文件，释放 {result['deleted_size_kb']:.1f} KB{''}")
        else:
            print(f"\n{C['red']}❌ 取消清理操作{''}")
    else:
        print(f"\n{C['green']}✅ 没有需要清理的文件{''}")


def _handle_archive(args, C):
    """处理 archive 命令"""
    print(f"\n{C['cyan']}🗜️  归档超过 {args.age} 天的记忆文件...{''}")
    result = archive_old_memory(args.workspace, age_days=args.age, archive_path=args.path, confirm=False)
    if "error" in result:
        print(f"{C['red']}❌ {result['error']}{''}")
    else:
        print(f"\n{C['green']}✅ 已归档 {result['archived_count']} 个文件，释放 {result['archived_size_kb']:.1f} KB")
        print(f"📁 归档位置: {result['archive_path']}{''}")
        if result.get('pending_delete', 0) > 0:
            print(f"\n{C['yellow']}⚠️  有 {result['pending_delete']} 个文件待删除原文件")
            print("回复 '同意' 确认删除原文件: ")
            user_input = input().strip()
            if user_input == '同意':
                result = archive_old_memory(args.workspace, age_days=args.age, archive_path=args.path, confirm=True)
                print(f"\n{C['green']}✅ 已删除原文件{''}")
            else:
                print(f"\n{C['yellow']}📝 原文件保留，可在归档目录查看{''}")


def _handle_auto_clean(args, C):
    """处理 auto-clean 命令"""
    if args.retention:
        cfg = load_config()
        cfg["retention_days"] = args.retention
        save_config(cfg)
    dry_run = not args.execute
    mode_label = "预览" if dry_run else "执行"
    print(f"\n{C['cyan']}🧹 差异化自动清理 [{mode_label}模式]{''}")
    res = auto_clean_memory(args.workspace, dry_run=dry_run, content_filter=args.content)
    if "error" in res:
        print(f"{C['red']}❌ {res['error']}{''}")
    else:
        summary = res.get("clean_summary", {})
        print(f"\n{C['bright']}🧹 差异化清理报告（提醒确认模式）{C['reset']}")
        print(f"{'='*50}")
        print(f"  推送类: 超过 {C['yellow']}{res['push_auto_clean_days']}{C['reset']} 天 → 提醒确认")
        print(f"  个人/工作: 每 {C['yellow']}{res['personal_work_remind_days']}{C['reset']} 天提醒一次")
        print(f"  其他类: 超过 {C['yellow']}{res['retention_days']}{C['reset']} 天 → 提醒确认")
        if args.content != 'all':
            print(f"  内容过滤: {C['cyan']}{args.content}{C['reset']}")
        total_remind = summary.get('push_to_remind', 0) + summary.get('personal_work_to_remind', 0) + summary.get('other_to_remind', 0)
        print(f"\n{C['bright']}📊 清理汇总{C['reset']}")
        print(f"  推送类待确认: {C['yellow']}{summary.get('push_to_remind', 0)}{C['reset']} 个")
        print(f"  个人/工作待确认: {C['yellow']}{summary.get('personal_work_to_remind', 0)}{C['reset']} 个")
        print(f"  其他类待确认: {C['yellow']}{summary.get('other_to_remind', 0)}{C['reset']} 个")
        print(f"  {C['bright']}待确认总计: {C['red']}{total_remind}{C['reset']} 个{C['reset']}")
        if res.get("remind_files"):
            print(f"\n{C['yellow']}🔔 待确认清理文件 ({len(res['remind_files'])} 个):{C['reset']}")
            push_files = [f for f in res["remind_files"] if f.get('type') == 'push']
            pw_files = [f for f in res["remind_files"] if f.get('type') == 'personal_work']
            other_files = [f for f in res["remind_files"] if f.get('type') not in ('push', 'personal_work')]
            if push_files:
                print(f"   {C['green']}推送类{C['reset']} ({len(push_files)} 个):")
                for f in push_files[:5]:
                    print(f"     • {f['name']} ({f['age_days']}天前 | {f['size_kb']}KB)")
                if len(push_files) > 5:
                    print(f"     ... 还有 {len(push_files)-5} 个")
            if pw_files:
                print(f"   {C['yellow']}个人/工作类{C['reset']} ({len(pw_files)} 个):")
                for f in pw_files[:5]:
                    print(f"     • {f['name']} ({f['age_days']}天前 | {f['size_kb']}KB)")
                if len(pw_files) > 5:
                    print(f"     ... 还有 {len(pw_files)-5} 个")
            if other_files:
                print(f"   {C['cyan']}其他类{C['reset']} ({len(other_files)} 个):")
                for f in other_files[:5]:
                    print(f"     • {f['name']} ({f['age_days']}天前 | {f['size_kb']}KB)")
                if len(other_files) > 5:
                    print(f"     ... 还有 {len(other_files)-5} 个")
        if res.get("kept_files"):
            print(f"\n{C['green']}✅ 保留文件 ({len(res['kept_files'])} 个):{C['reset']}")
            for f in res["kept_files"][:5]:
                reason = f.get('reason', '')
                print(f"   • {f['name']} ({f.get('age_days', 0)}天 | {reason})")
            if len(res["kept_files"]) > 5:
                print(f"   ... 还有 {len(res['kept_files'])-5} 个")
        if args.execute:
            print(f"\n{C['red']}⚠️  确认清理 {total_remind} 个文件？{C['reset']}")
            print(f"{C['yellow']}回复「同意」确认清理，或按任意键取消:{C['reset']}")
            try:
                user_input = input().strip()
            except EOFError:
                user_input = ""
            if user_input == "同意":
                confirm_res = auto_clean_memory(args.workspace, dry_run=False, content_filter=args.content, confirm_action=True)
                print(f"\n{C['green']}✅ 已清理 {confirm_res['files_archived']} 个文件，释放 {confirm_res['size_freed_kb']:.1f} KB{''}")
                if confirm_res.get('errors'):
                    print(f"{C['red']}⚠️  错误: {', '.join(confirm_res['errors'])}{''}")
            else:
                print(f"{C['yellow']}已取消清理操作{C['reset']}")
        else:
            print(f"\n{C['yellow']}💡 预览模式，如需执行请加 --execute{C['reset']}")


def _handle_rank_display(args, result, C):
    """显示 rank 命令的输出"""
    print(f"\n{C['bright']}{'='*50}{C['reset']}")
    print(f"{C['cyan']}🧠 记忆分级报告{C['reset']}")
    print(f"{'='*50}")
    stats = result["stats"]
    print(f"\n📊 分级统计:")
    print(f"   总记忆数: {stats['total']}")
    print(f"   {C['red']}🔴 核心记忆:{C['reset']} {stats['core_count']} 个")
    print(f"   {C['yellow']}🟡 普通记忆:{C['reset']} {stats['normal_count']} 个")
    print(f"   {C['green']}🟢 冷门记忆:{C['reset']} {stats['cold_count']} 个")
    if result.get("core"):
        print(f"\n{C['red']}🔴 核心记忆 (>=70%):{C['reset']}")
        for item in result["core"][:5]:
            print(f"   • {item['file']} ({item['score']}分)")
    if result.get("normal"):
        print(f"\n{C['yellow']}🟡 普通记忆 (30-70%):{C['reset']}")
        for item in result["normal"][:5]:
            print(f"   • {item['file']} ({item['score']}分)")
    if result.get("cold"):
        print(f"\n{C['green']}🟢 冷门记忆 (<30%):{C['reset']}")
        for item in result["cold"][:5]:
            print(f"   • {item['file']} ({item['score']}分)")
    print(f"\n{C['bright']}{'='*50}{C['reset']}")


def _handle_config_display(args, res, C):
    """显示 config 命令的输出"""
    cfg = res["config"]
    print(f"\n{C['bright']}⚙️  记忆管家 V{VERSION} 当前配置{C['reset']}")
    print(f"{'='*50}")
    print(f"\n{C['bright']}📋 基础配置{C['reset']}")
    basic_keys = ["retention_days", "auto_remind_days", "auto_archive", "last_remind_date", "last_clean_date"]
    for k in basic_keys:
        if k in cfg:
            default = DEFAULT_CONFIG.get(k, "")
            v = cfg[k]
            marker = "" if v == default else f" ← 默认: {default}"
            print(f"  {C['cyan']}{k}{C['reset']}: {C['yellow']}{v}{C['reset']}{marker}")
    print(f"\n{C['bright']}📋 差异化清理规则{C['reset']}")
    rules = cfg.get("_automation_rules", {})
    push = rules.get("push_content", {})
    pw = rules.get("personal_work_content", {})
    print(f"  {C['green']}推送类{C['reset']}: 超{push.get('retention_days',1)}天自动清理 | 关键词: {', '.join(push.get('keywords',[]))}")
    print(f"  {C['yellow']}个人/工作类{C['reset']}: 不自动清理，每{pw.get('remind_days',5)}天提醒一次 | 关键词: {', '.join(pw.get('keywords',[]))}")
    print(f"{'='*50}")
    print(f"\n💡 示例: config --key retention_days --value 3")


def main():
    parser = argparse.ArgumentParser(
        description=f"记忆管家 V{VERSION} - AI效率工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  %(prog)s analyze                    # 分析记忆状态
  %(prog)s analyze --age 7            # 只看7天内的文件
  %(prog)s scan                       # 扫描工作空间
  %(prog)s scan --exclude temp,logs  # 排除特定目录
  %(prog)s preview                    # 生成清理预览
  %(prog)s preview --json             # JSON格式输出
  %(prog)s auto-clean                 # 差异化自动清理（预览）
  %(prog)s auto-clean --execute       # 执行差异化自动清理
  %(prog)s auto-clean --content push # 只清理推送类内容
  %(prog)s auto-clean --content personal_work  # 只处理个人/工作类（提示用户）

安全特性:
  ✓ 符号链接防护
  ✓ 单文件1MB限制
  ✓ 累计读取5MB限制
  ✓ 最多1000条报告
  ✓ 内容类型分类，不误删个人/工作内容
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    parser.add_argument('--json', action='store_true', help='JSON格式输出')
    parser.add_argument('workspace', nargs='?', default='.', help='工作目录路径')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    add_v25_cli(subparsers)  # V2.5 新增命令
    
    # analyze命令
    analyze_parser = subparsers.add_parser('analyze', help='分析记忆状态')
    analyze_parser.add_argument('--age', type=int, metavar='N', 
                                help='只分析N天内的文件')
    analyze_parser.add_argument('--exclude', type=str, metavar='DIRS',
                                help='排除的目录（逗号分隔）')
    
    # scan命令
    scan_parser = subparsers.add_parser('scan', help='扫描工作空间')
    scan_parser.add_argument('--exclude', type=str, metavar='DIRS',
                            help='排除的目录（逗号分隔）')
    scan_parser.add_argument('--clean-empty-dirs', action='store_true',
                            help='识别空目录')
    
    # preview命令
    preview_parser = subparsers.add_parser('preview', help='生成清理预览')
    
    # clean命令
    clean_parser = subparsers.add_parser('clean', help='执行清理（需确认）')
    clean_parser.add_argument('--force', action='store_true', help='跳过确认直接执行')

    # archive命令
    archive_parser = subparsers.add_parser('archive', help='归档旧记忆（压缩后移动）')
    archive_parser.add_argument('--age', type=int, default=30, help='归档超过N天的文件（默认30天）')
    archive_parser.add_argument('--path', type=str, help='指定归档目录')

    # html命令
    html_parser = subparsers.add_parser('html', help='生成HTML格式报告')
    html_parser.add_argument('--output', type=str, help='输出文件路径')

    # summarize命令
    summarize_parser = subparsers.add_parser('summarize', help='生成记忆摘要')
    summarize_parser.add_argument('--file', type=str, help='指定文件（不指定则处理所有）')
    summarize_parser.add_argument('--regenerate', action='store_true', help='强制重新生成')

    # rank命令
    rank_parser = subparsers.add_parser('rank', help='记忆重要性分级')
    rank_parser.add_argument('--days', type=int, metavar='N',
                            help='🆕 V2.8.1 只处理N天内修改的文件')

    # load命令
    load_parser = subparsers.add_parser('load', help='智能加载记忆')
    load_parser.add_argument('--mode', type=str, default='normal',
                            choices=['brief', 'normal', 'full'], help='加载模式')
    load_parser.add_argument('--keyword', type=str, help='关键词过滤')
    load_parser.add_argument('--limit', type=int, default=10, help='返回数量')
    load_parser.add_argument('--days', type=int, metavar='N',
                            help='🆕 V2.8.1 只加载N天内修改的文件')

    # search命令 - keyword作为选项参数避免位置冲突
    search_parser = subparsers.add_parser('search', help='搜索记忆')
    search_parser.add_argument('-k', '--keyword', dest='keyword', required=True, help='搜索关键词')
    search_parser.add_argument('--mode', type=str, default='brief',
                              choices=['brief', 'normal', 'full'], help='结果模式')

    # config命令 V2.3
    config_parser = subparsers.add_parser('config', help='查看/修改配置')
    config_parser.add_argument('--key', type=str, help='配置项名称')
    config_parser.add_argument('--value', type=str, help='配置项新值')

    # auto-clean命令 V2.4
    auto_clean_parser = subparsers.add_parser('auto-clean', help='差异化自动清理（推送类次日清理，个人/工作类每5天提醒）')
    auto_clean_parser.add_argument('--dry-run', action='store_true', default=True,
                                 help='预览模式（只报告，不清理）')
    auto_clean_parser.add_argument('--execute', action='store_true',
                                 help='执行模式（真正归档超期文件）')
    auto_clean_parser.add_argument('--retention', type=int, metavar='N',
                                 help='覆盖配置的默认保留天数（不影响推送/个人工作类规则）')
    auto_clean_parser.add_argument('--content', type=str, default='all',
                                 choices=['all', 'push', 'personal_work', 'other'],
                                 help='指定清理内容类型（默认all）')


    
    # cache-clean命令 V2.7
    cache_clean_parser = subparsers.add_parser('cache-clean', help='缓存清理（孤儿摘要+过期统计+临时文件）')
    cache_clean_parser.add_argument('--execute', action='store_true', help='执行清理（默认预览模式）')
    cache_clean_parser.add_argument('--type', type=str, default='all',
                                   choices=['all', 'orphan', 'stats', 'temp'],
                                   help='清理类型（默认all）')
    cache_clean_parser.add_argument('--days', type=int, default=30, help='Token统计保留天数（默认30）')
    
    # export命令 V2.7
    export_parser = subparsers.add_parser('export', help='导出记忆文件（跨空间迁移）')
    export_parser.add_argument('--output', type=str, required=True, help='输出ZIP文件路径')
    
    # import命令 V2.7
    import_parser = subparsers.add_parser('import', help='导入记忆文件（跨空间恢复）')
    import_parser.add_argument('--file', type=str, required=True, help='输入ZIP文件路径')
    import_parser.add_argument('--merge', action='store_true', help='合并模式（跳过同名文件）')
    
    # cache-reminder命令 V2.7（用于定时任务）
    reminder_parser = subparsers.add_parser('cache-reminder', help='缓存提醒（只读扫描，用于定时任务）')

    # report命令 V2.7.2（记忆文件清单报告）
    report_parser = subparsers.add_parser('report', help='记忆文件清单报告（所有文件列表+使用统计）')

    args = parser.parse_args()
    
    # 默认命令
    if args.command is None:
        # 默认执行扫描
        result = scan_workspace(args.workspace)
        print_report(result, "json" if args.json else "text")
        return
    
    # 解析排除目录
    exclude_dirs = []
    if hasattr(args, 'exclude') and args.exclude:
        exclude_dirs = [d.strip() for d in args.exclude.split(',')]
    
    # 执行对应命令
    if args.command == 'analyze':
        result = analyze_memory(
            args.workspace,
            age_days=args.age,
            exclude_patterns=exclude_dirs
        )
        print_memory_analysis(result, "json" if args.json else "text")
    
    elif args.command == 'dedup':
        handle_v25_command(args)
    elif args.command == 'stats':
        handle_v25_command(args)
    elif args.command == 'backup':
        handle_v25_command(args)
    elif args.command == 'schedule':
        handle_v25_command(args)
    elif args.command == 'doctor':
        handle_v25_command(args)
    elif args.command == 'wizard':
        handle_v25_command(args)
    elif args.command == 'feedback':
        handle_v25_command(args)

    
    # V2.7 新命令
    elif args.command == 'cache-clean':
        result = cache_clean(
            args.workspace,
            dry_run=not args.execute,
            confirm=False,
            cache_type=args.type,
            days=args.days
        )
    
    elif args.command == 'export':
        result = export_memories(args.workspace, args.output)
    
    elif args.command == 'import':
        result = import_memories(args.workspace, args.file, merge_mode=args.merge)
    
    elif args.command == 'cache-reminder':
        result = cache_reminder(args.workspace)

    elif args.command == 'report':
        result = generate_memory_report(args.workspace)
    
    elif args.command == 'scan':
        result = scan_workspace(
            args.workspace,
            exclude_dirs=exclude_dirs,
            clean_empty_dirs=args.clean_empty_dirs
        )
        print_report(result, "json" if args.json else "text")
    
    elif args.command == 'preview':
        result = generate_cleanup_preview(args.workspace, dry_run=True)
        print_preview(result)
    
    elif args.command == 'clean':
        _handle_clean(args, C)

    elif args.command == 'archive':
        _handle_archive(args, C)

    elif args.command == 'html':
        print(f"\n{C['cyan']}📊 生成HTML报告...{''}")
        result = scan_workspace(args.workspace)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            output = generate_html_report(result, args.output)
            if args.output:
                print(f"\n{C['green']}✅ HTML报告已保存: {output}{''}")
            else:
                # 浏览器打开
                import tempfile
                import webbrowser
                with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
                    f.write(generate_html_report(result))
                    temp_path = f.name
                webbrowser.open(f'file://{temp_path}')
                print(f"\n{C['green']}✅ 已在浏览器中打开报告{''}")

    elif args.command == 'summarize':
        print(f"\n{C['cyan']}📝 生成记忆摘要...{''}")
        result = summarize_memory(args.workspace, file_name=args.file, regenerate=args.regenerate)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['green']}✅ 摘要生成完成{C['reset']}")
            print(f"   已处理: {len(result['summarized'])} 个文件")
            print(f"   跳过: {len(result['skipped'])} 个文件")
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.command == 'rank':
        print(f"\n{C['cyan']}⭐ 记忆重要性分级...{''}")
        days = getattr(args, 'days', None)  # 🆕 V2.8.1
        if days:
            print(f"   📅 过滤: 只显示最近 {days} 天内修改的文件")
        result = rank_memory(args.workspace, days=days)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            _handle_rank_display(args, result, C)

    elif args.command == 'load':
        print(f"\n{C['cyan']}📖 智能加载记忆...{''}")
        days = getattr(args, 'days', None)  # 🆕 V2.8.1
        if days:
            print(f"   📅 过滤: 只加载最近 {days} 天内修改的文件")
        result = load_memory(args.workspace, mode=args.mode, keyword=args.keyword, limit=args.limit, days=days)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n{C['green']}✅ 加载完成{C['reset']}")
            print(f"   模式: {result['mode']}")
            print(f"   加载: {len(result['loaded'])} 个记忆")
            print(f"   预估Token: ~{result['total_tokens_estimate']}")

            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(f"\n{C['bright']}--- 记忆内容 ---{C['reset']}")
                for item in result["loaded"][:5]:
                    print(f"\n📄 {item['file']} [{item['type']}]")
                    print(f"{item['content'][:300]}...")

    elif args.command == 'search':
        print(f"\n{C['cyan']}🔍 搜索记忆: {args.keyword}{''}")
        result = search_memory(args.workspace, args.keyword, mode=args.mode)
        if "error" in result:
            print(f"{C['red']}❌ {result['error']}{''}")
        else:
            print(f"\n找到 {result['total']} 个匹配结果:")
            for item in result["matches"][:10]:
                print(f"\n📄 {item['file']} (匹配度: {item['score']})")
                print(f"   {item['preview'][:150]}...")

    # config命令 V2.4
    elif args.command == 'config':
        res = config_memory(args.workspace, key=args.key, value=args.value)
        if "error" in res:
            print(f"{C['red']}❌ {res['error']}{''}")
        elif res["action"] == "update":
            print(f"{C['green']}✅ 配置已更新: {res['key']} = {res['value']}{''}")
        else:
            _handle_config_display(args, res, C)

    elif args.command == 'auto-clean':
        _handle_auto_clean(args, C)

# ==================== V2.7 新增功能 ====================

def cache_clean(workspace_path, dry_run=True, confirm=False, cache_type='all', days=30):
    """
    缓存清理功能（V2.7新增）
    清理孤儿摘要、过期Token统计、临时文件
    
    Args:
        workspace_path: 工作空间路径
        dry_run: True=预览模式，False=执行模式
        confirm: 是否跳过交互确认（用于自动化任务）
        cache_type: 'orphan'/'stats'/'temp'/'all'
        days: 过期Token统计保留天数（默认30天）
    """
    import os, json
    from datetime import datetime, timedelta
    from pathlib import Path
    
    C = get_colors()
    workspace = Path(workspace_path).resolve()
    workbuddy_dir = workspace / ".workbuddy"
    
    # 收集待清理文件
    to_clean = []
    summary_count = 0
    stats_count = 0
    temp_count = 0
    
    print(f"{C['cyan']}🧹 缓存清理分析...{C['reset']}")
    
    # ---- 1. 孤儿摘要清理 ----
    if cache_type in ('orphan', 'all'):
        summary_dir = workbuddy_dir / ".summary"
        if summary_dir.exists():
            for sum_file in summary_dir.glob("*.summary"):
                # 对应的记忆文件是否存在？
                memory_name = sum_file.stem  # 移除 .summary
                memory_file = workbuddy_dir / "memory" / f"{memory_name}.md"
                if not memory_file.exists():
                    size_kb = sum_file.stat().st_size / 1024
                    to_clean.append({
                        'path': str(sum_file),
                        'name': sum_file.name,
                        'type': 'orphan',
                        'size_kb': size_kb
                    })
                    summary_count += 1
    
    # ---- 2. 过期Token统计清理 ----
    if cache_type in ('stats', 'all'):
        stats_dir = workbuddy_dir / ".token_stats"
        if stats_dir.exists():
            cutoff = datetime.now() - timedelta(days=days)
            for stat_file in stats_dir.glob("*.json"):
                mtime = datetime.fromtimestamp(stat_file.stat().st_mtime)
                if mtime < cutoff:
                    size_kb = stat_file.stat().st_size / 1024
                    to_clean.append({
                        'path': str(stat_file),
                        'name': stat_file.name,
                        'type': 'stats',
                        'size_kb': size_kb,
                        'mtime': mtime.strftime('%Y-%m-%d')
                    })
                    stats_count += 1
    
    # ---- 3. 临时文件清理 ----
    if cache_type in ('temp', 'all'):
        temp_patterns = ['*.tmp', '*.cache', '*.bak', '*.swp', '*.temp']
        memory_dir = workbuddy_dir / "memory"
        if memory_dir.exists():
            import glob
            for pattern in temp_patterns:
                for f in memory_dir.glob(pattern):
                    if f.is_file():
                        size_kb = f.stat().st_size / 1024
                        to_clean.append({
                            'path': str(f),
                            'name': f.name,
                            'type': 'temp',
                            'size_kb': size_kb
                        })
                        temp_count += 1
        # 清理 __pycache__
        for pycache in workspace.rglob("__pycache__"):
            if pycache.is_dir():
                size_kb = sum(f.stat().st_size for f in pycache.rglob("*") if f.is_file()) / 1024
                to_clean.append({
                    'path': str(pycache),
                    'name': pycache.name + "/",
                    'type': 'temp',
                    'size_kb': size_kb
                })
                temp_count += 1
    
    # ---- 输出预览 ----
    total_size_kb = sum(item['size_kb'] for item in to_clean)
    
    print(f"\n{C['bright']}📊 缓存扫描结果：{C['reset']}")
    if cache_type in ('orphan', 'all'):
        print(f"   📄 孤儿摘要: {summary_count} 个")
    if cache_type in ('stats', 'all'):
        print(f"   📊 过期Token统计(>{days}天): {stats_count} 个")
    if cache_type in ('temp', 'all'):
        print(f"   🗂️  临时文件: {temp_count} 个")
    print(f"   💾 可释放空间: {total_size_kb:.1f} KB")
    
    if not to_clean:
        print(f"\n{C['green']}✅ 没有需要清理的缓存文件{C['reset']}")
        return {"cleaned": 0, "freed_kb": 0}
    
    # 预览清单
    print(f"\n{C['yellow']}📋 待清理文件清单（前20个）:{C['reset']}")
    for i, item in enumerate(to_clean[:20], 1):
        print(f"   [{i}] [{item['type']}] {item['name']} ({item['size_kb']:.1f}KB)")
    if len(to_clean) > 20:
        print(f"   ... 还有 {len(to_clean)-20} 个")
    
    # ---- 执行清理 ----
    if dry_run:
        print(f"\n{C['yellow']}💡 预览模式，不删除任何文件{C['reset']}")
        print(f"{C['yellow']}💡 加 --execute 参数执行清理{C['reset']}")
        return {"preview": len(to_clean), "freed_kb": total_size_kb}
    
    # 交互确认
    if not confirm:
        answer = input(f"\n{C['bright']}⚠️  确认删除以上 {len(to_clean)} 个缓存文件？输入 Y 确认，N 取消: {C['reset']}").strip().upper()
        if answer != 'Y':
            print(f"{C['green']}✅ 已取消{C['reset']}")
            return {"cleaned": 0, "freed_kb": 0}
    
    # 执行删除
    cleaned = 0
    freed_kb = 0
    errors = []
    
    for item in to_clean:
        try:
            p = Path(item['path'])
            if p.is_file():
                freed_kb += item['size_kb']
                p.unlink()
                cleaned += 1
            elif p.is_dir():
                freed_kb += item['size_kb']
                shutil.rmtree(p)
                cleaned += 1
        except Exception as e:
            errors.append(f"删除失败 {item['name']}: {e}")
    
    print(f"\n{C['green']}✅ 已清理 {cleaned} 个缓存文件，释放 {freed_kb:.1f} KB{C['reset']}")
    if errors:
        print(f"{C['red']}⚠️  错误: {len(errors)} 个{''}")
        for err in errors[:5]:
            print(f"   {err}")
    
    return {"cleaned": cleaned, "freed_kb": freed_kb, "errors": errors}


def export_memories(workspace_path, output_path, memory_only=False):
    """
    导出记忆文件（V2.7新增）
    将 .workbuddy/memory/ 目录打包为 ZIP
    
    Args:
        workspace_path: 工作空间路径
        output_path: 输出ZIP文件路径
        memory_only: True=只导出memory目录，False=导出整个.workbuddy
    """
    import zipfile
    from pathlib import Path
    
    C = get_colors()
    workspace = Path(workspace_path).resolve()
    workbuddy_dir = workspace / ".workbuddy"
    memory_dir = workbuddy_dir / "memory"
    
    if not memory_dir.exists():
        return {"error": "记忆目录不存在"}
    
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"{C['cyan']}📤 导出记忆文件...{C['reset']}")
    
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zf:
        # 写入 manifest.json
        manifest = {
            "export_time": datetime.now().isoformat(),
            "version": VERSION,
            "source_workspace": str(workspace),
            "files": []
        }
        
        # 打包 memory/ 目录
        for md_file in memory_dir.glob("*.md"):
            arcname = f"memory/{md_file.name}"
            zf.write(md_file, arcname)
            manifest["files"].append(arcname)
        
        # 打包 .summary/ 目录（如果有）
        summary_dir = workbuddy_dir / ".summary"
        if summary_dir.exists():
            for sum_file in summary_dir.glob("*.summary"):
                arcname = f".summary/{sum_file.name}"
                zf.write(sum_file, arcname)
                manifest["files"].append(arcname)
        
        # 写入 manifest
        manifest_str = json.dumps(manifest, ensure_ascii=False, indent=2)
        zf.writestr("manifest.json", manifest_str)
    
    file_count = len(manifest["files"])
    size_kb = output.stat().st_size / 1024
    
    print(f"{C['green']}✅ 导出完成{C['reset']}")
    print(f"   文件: {output}")
    print(f"   包含: {file_count} 个文件")
    print(f"   大小: {size_kb:.1f} KB")
    
    return {"output": str(output), "files": file_count, "size_kb": size_kb}


def import_memories(workspace_path, input_path, merge_mode=False, confirm=False):
    """
    导入记忆文件（V2.7新增，V2.7.2修复：增加confirm参数）
    从 ZIP 恢复记忆到目标工作空间
    
    Args:
        workspace_path: 目标工作空间路径
        input_path: 输入ZIP文件路径
        merge_mode: True=合并模式（同名跳过），False=覆盖模式
        confirm: 是否确认导入（默认False，需显式确认）
    """
    if not confirm:
        return {"error": "需要确认才能导入，请添加 --confirm 参数", "require_confirm": True}
    import zipfile
    from pathlib import Path
    
    C = get_colors()
    workspace = Path(workspace_path).resolve()
    workbuddy_dir = workspace / ".workbuddy"
    memory_dir = workbuddy_dir / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)
    
    input_file = Path(input_path)
    if not input_file.exists():
        return {"error": f"导入文件不存在: {input_path}"}
    
    print(f"{C['cyan']}📥 导入记忆文件...{C['reset']}")
    print(f"   源文件: {input_path}")
    print(f"   目标空间: {workspace}")
    print(f"   模式: {'合并（跳过同名）' if merge_mode else '覆盖（替换同名）'}")
    
    imported = 0
    skipped = 0
    errors = []
    
    with zipfile.ZipFile(input_file, 'r') as zf:
        for info in zf.infolist():
            if info.filename == "manifest.json":
                continue
            if info.is_dir():
                continue
            
            # 确定目标路径（安全检查：防止ZIP路径穿越）
            target = workbuddy_dir / info.filename
            try:
                target = safe_resolve(target, workbuddy_dir)
            except (ValueError, OSError):
                errors.append(f"导入失败 {info.filename}: 路径超出安全范围")
                continue
            if target is None:
                errors.append(f"导入失败 {info.filename}: 路径超出安全范围")
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            
            # 合并模式：跳过已存在的文件
            if merge_mode and target.exists():
                skipped += 1
                continue
            
            # 提取文件
            try:
                zf.extract(info, workbuddy_dir)
                imported += 1
            except Exception as e:
                errors.append(f"导入失败 {info.filename}: {e}")
    
    print(f"\n{C['green']}✅ 导入完成{C['reset']}")
    print(f"   已导入: {imported} 个文件")
    if skipped > 0:
        print(f"   已跳过: {skipped} 个同名文件（合并模式）")
    if errors:
        print(f"{C['red']}⚠️  错误: {len(errors)} 个{''}")
    
    return {"imported": imported, "skipped": skipped, "errors": errors}


def cache_reminder(workspace_path):
    """
    缓存提醒功能（V2.7新增）
    V2.7.1：增加Token使用统计和缓存大小显示
    """
    from pathlib import Path
    from datetime import datetime, timedelta
    
    workspace = Path(workspace_path)
    workbuddy_dir = workspace / ".workbuddy"
    
    summary_count = 0
    stats_count = 0
    temp_count = 0
    total_cache_size_kb = 0.0
    total_tokens = 0
    
    # 孤儿摘要 + 缓存大小
    summary_dir = workbuddy_dir / ".summary"
    if summary_dir.exists():
        for sum_file in summary_dir.glob("*.summary"):
            memory_name = sum_file.stem
            memory_file = workbuddy_dir / "memory" / f"{memory_name}.md"
            if not memory_file.exists():
                summary_count += 1
            try:
                total_cache_size_kb += sum_file.stat().st_size / 1024
            except OSError:
                pass
    
    # 过期Token统计 + Token使用统计 + 缓存大小
    stats_dir = workbuddy_dir / ".token_stats"
    if stats_dir.exists():
        cutoff = datetime.now() - timedelta(days=30)
        for stat_file in stats_dir.glob("*.json"):
            mtime = datetime.fromtimestamp(stat_file.stat().st_mtime)
            if mtime < cutoff:
                stats_count += 1
            try:
                total_cache_size_kb += stat_file.stat().st_size / 1024
            except OSError:
                pass
            # 读取Token使用统计
            try:
                stat_data = json.loads(stat_file.read_text(encoding="utf-8"))
                if isinstance(stat_data, dict):
                    for key in ["input_tokens", "output_tokens", "total_tokens"]:
                        if key in stat_data:
                            try:
                                total_tokens += int(stat_data[key])
                            except (ValueError, TypeError):
                                pass
            except (json.JSONDecodeError, OSError):
                pass
    
    # 临时文件 + 缓存大小
    memory_dir = workbuddy_dir / "memory"
    if memory_dir.exists():
        for pattern in ["*.tmp", "*.cache"]:
            for f in memory_dir.glob(pattern):
                temp_count += 1
                try:
                    total_cache_size_kb += f.stat().st_size / 1024
                except OSError:
                    pass
    
    total = summary_count + stats_count + temp_count
    
    # 输出提醒内容
    msg = "🧹 记忆管家·缓存提醒\n"
    
    # V2.7.1 新增：Token使用统计
    if total_tokens > 0:
        msg += f"📊 Token使用统计: ~{total_tokens:,} tokens\n"
    else:
        msg += "📊 Token使用统计: 暂无数据\n"
    
    # V2.7.1 新增：缓存大小
    if total_cache_size_kb > 1024:
        msg += f"💾 现有缓存: {total_cache_size_kb/1024:.1f} MB\n"
    else:
        msg += f"💾 现有缓存: {total_cache_size_kb:.1f} KB\n"
    
    if summary_count > 0:
        msg += f"📄 孤儿摘要: {summary_count} 个\n"
    if stats_count > 0:
        msg += f"📊 过期统计: {stats_count} 个\n"
    if temp_count > 0:
        msg += f"🗂️ 临时文件: {temp_count} 个\n"
    
    if total == 0:
        msg += "✅ 缓存状态良好，无需清理"
    else:
        msg += f"💡 总计 {total} 项可清理\n"
        msg += "💡 手动清理: memory_manager.py cache-clean --execute"
    
    print(msg)
    
    return {
        "orphan": summary_count,
        "expired_stats": stats_count,
        "temp_files": temp_count,
        "total": total,
        "total_tokens": total_tokens,
        "cache_size_kb": round(total_cache_size_kb, 1)
    }


def generate_memory_report(workspace_path):
    """
    生成记忆文件清单报告（V2.7.2新增）
    显示：所有记忆文件列表（按日期/类型排列）+ 记忆使用统计
    """
    from pathlib import Path
    from datetime import datetime, timedelta
    import re
    
    workspace = Path(workspace_path)
    workbuddy_dir = workspace / ".workbuddy"
    memory_dir = workbuddy_dir / "memory"
    
    # 初始化统计
    total_files = 0
    total_size_kb = 0.0
    total_tokens = 0
    cache_size_kb = 0.0
    by_type = {"推送": 0, "个人/工作": 0, "其他": 0}
    by_date = {}  # date -> list of files
    recent_files = []  # 最近7天的文件
    old_files = []  # 超过30天的文件
    
    # 定义分类关键词（与差异化清理保持一致）
    push_keywords = ["ai", "新闻", "推送", "日报", "周报", "资讯", "动态", "融资", "发布", "发布", "大模型", "产品", "技术", "更新"]
    personal_work_keywords = ["用户", "个人", "工作", "项目", "任务", "笔记", "会议", "客户", "合同", "方案"]
    
    def _classify_report_content(content):
        """分类记忆内容（为报告内部使用）"""
        if not content:
            return "其他"
        content_lower = content.lower()
        push_score = sum(1 for kw in push_keywords if kw.lower() in content_lower)
        pw_score = sum(1 for kw in personal_work_keywords if kw.lower() in content_lower)
        if push_score > pw_score and push_score >= 2:
            return "推送"
        elif pw_score > push_score and pw_score >= 1:
            return "个人/工作"
        return "其他"
    
    # 扫描记忆文件
    if memory_dir.exists():
        for md_file in sorted(memory_dir.glob("*.md")):
            if md_file.name in ["MEMORY.md", "memory.md"]:
                continue  # 跳过长期记忆文件
            total_files += 1
            try:
                size_kb = md_file.stat().st_size / 1024
                total_size_kb += size_kb
                mtime = datetime.fromtimestamp(md_file.stat().st_mtime)
                date_key = mtime.strftime("%Y-%m-%d")
                
                # 读取内容进行分类
                try:
                    content = md_file.read_text(encoding="utf-8")[:500]  # 只读前500字符
                    content_type = _classify_report_content(content)
                except:
                    content_type = "其他"
                
                # 按日期分类
                if date_key not in by_date:
                    by_date[date_key] = []
                by_date[date_key].append({
                    "name": md_file.name,
                    "size_kb": round(size_kb, 1),
                    "type": content_type,
                    "date": mtime.strftime("%Y-%m-%d %H:%M")
                })
                
                # 分类统计
                by_type[content_type] += 1
                
                # 最近/老化文件
                days_old = (datetime.now() - mtime).days
                if days_old <= 7:
                    recent_files.append(md_file.name)
                elif days_old > 30:
                    old_files.append(md_file.name)
                    
            except OSError:
                pass
    
    # 统计Token使用量
    stats_dir = workbuddy_dir / ".token_stats"
    if stats_dir.exists():
        for stat_file in stats_dir.glob("*.json"):
            cache_size_kb += stat_file.stat().st_size / 1024
            try:
                stat_data = json.loads(stat_file.read_text(encoding="utf-8"))
                if isinstance(stat_data, dict):
                    for key in ["input_tokens", "output_tokens", "total_tokens"]:
                        if key in stat_data:
                            try:
                                total_tokens += int(stat_data[key])
                            except (ValueError, TypeError):
                                pass
            except:
                pass
    
    # 统计缓存大小
    summary_dir = workbuddy_dir / ".summary"
    if summary_dir.exists():
        for f in summary_dir.glob("*.summary"):
            cache_size_kb += f.stat().st_size / 1024
    
    # 生成报告
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    msg = f"""
{'='*55}
📋 记忆文件清单报告
生成时间: {now}
{'='*55}

📊 【记忆使用统计】
   ├─ 文件总数: {total_files} 个
   ├─ 占用空间: {total_size_kb:.1f} KB
   ├─ Token使用量: {'约 {:,}'.format(total_tokens) if total_tokens > 0 else '暂无数据'}
   ├─ 缓存大小: {cache_size_kb:.1f} KB
   │
   ├─ 🔴 推送类: {by_type['推送']} 个
   ├─ 🟡 个人/工作: {by_type['个人/工作']} 个
   └─ 🟢 其他: {by_type['其他']} 个

📁 【记忆文件列表（按日期排列）】
"""
    # 按日期排序输出
    if by_date:
        for date_key in sorted(by_date.keys(), reverse=True)[:10]:  # 最多显示最近10天
            files = by_date[date_key]
            days_ago = (datetime.now() - datetime.strptime(date_key, "%Y-%m-%d")).days
            age_tag = f"(今天)" if days_ago == 0 else f"({days_ago}天前)"
            msg += f"\n   📅 {date_key} {age_tag}\n"
            for f in files[:5]:  # 每天最多显示5个
                type_icon = "🔴" if f['type'] == "推送" else "🟡" if f['type'] == "个人/工作" else "🟢"
                msg += f"      {type_icon} {f['name']} ({f['size_kb']}KB)\n"
            if len(files) > 5:
                msg += f"      ... 还有 {len(files)-5} 个文件\n"
    else:
        msg += "\n   (暂无记忆文件)\n"
    
    # 补充信息
    msg += f"""
{'='*55}
💡 【补充信息】
"""
    if recent_files:
        msg += f"   • 最近7天新增: {len(recent_files)} 个文件\n"
    if old_files:
        msg += f"   • 超过30天: {len(old_files)} 个文件\n"
        msg += f"   • 建议归档或清理旧文件以释放空间\n"
    if cache_size_kb > 100:
        msg += f"   • 缓存较大，可运行 cache-clean 清理\n"
    msg += f"""
   • 完整统计: memory_manager.py stats
   • 清理建议: memory_manager.py auto-clean
   • 生成摘要: memory_manager.py summarize
{'='*55}
"""
    
    print(msg)
    
    return {
        "total_files": total_files,
        "total_size_kb": round(total_size_kb, 1),
        "total_tokens": total_tokens,
        "cache_size_kb": round(cache_size_kb, 1),
        "by_type": by_type,
        "by_date": by_date,
        "recent_files_count": len(recent_files),
        "old_files_count": len(old_files)
    }


# ==================== V2.7 新增功能结束 ====================

if __name__ == "__main__":
    main()
