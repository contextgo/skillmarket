---
name: "记忆管家"
description: >
  AI加速器 V2.8.1，智能管理记忆与文件，减少Token消耗。
  V2.8.1核心升级：增量加载(--days参数) + 摘要压缩输出(300字符)，省Token 50-80%。
  This skill should be used when users want to manage memories, reduce token consumption,
  view token stats, check cache size, clean up workspace files,
  export memories, import memories, view memory file list/report,
  or ask about memory/file status.
  触发词：记忆管家、缓存提醒、Token统计、缓存大小、清理缓存、省token、记忆清单、记忆报告

# 记忆管家 V2.8.1 - AI加速器

🧠 **让AI更懂你，更快回应，更省Token**

## 🚀 V2.8.1 核心升级

| 维度 | 提升 |
|------|------|
| 📅 增量加载 | `--days N` 只加载N天内文件，省50-70% Token |
| 📏 摘要压缩 | 输出限制300字符，再省30% Token |
| ⚡ 综合节省 | 叠加效果可达 **50-80%** |

## 💻 常用命令

```bash
# 增量加载（V2.8.1 省Token核心）
memory_manager.py load --days 7 --mode brief
memory_manager.py rank --days 30

# 记忆管理
memory_manager.py analyze           # 分析记忆状态
memory_manager.py scan              # 扫描工作空间
memory_manager.py summarize         # 生成摘要
memory_manager.py search -k 关键词   # 搜索记忆
memory_manager.py report            # 记忆清单报告

# 清理维护
memory_manager.py config            # 查看/修改配置
memory_manager.py auto-clean        # 差异化自动清理（预览）
memory_manager.py cache-clean       # 缓存清理
memory_manager.py dedup             # 内容去重

# 备份与恢复
memory_manager.py export --output backup.zip
memory_manager.py import --file backup.zip
memory_manager.py backup --path "D:\备份"

# 高级功能
memory_manager.py rank              # 重要性分级
memory_manager.py doctor            # 诊断工具
memory_manager.py wizard            # 设置向导
memory_manager.py html              # HTML报告
```

## 🛡️ 安全特性

- 符号链接防护 + 路径穿越检测
- 文件读取上限1MB/累计5MB
- 所有删除操作需用户确认（"同意"机制）
- 受保护目录永不删除（memory/skills）
- 内容分类保护，个人/工作类不自动清理

## 💰 Token节省原理

```
传统全量加载 → V2.8.1增量加载(days) + 摘要压缩(300字)
省Token效果: 50-80%
```

## 📦 目录结构

```
.workbuddy/
├── memory/           # 记忆文件
├── .summary/         # 摘要缓存
├── .token_stats/     # Token统计
├── archive/          # 归档文件
└── config.json       # 配置
```

**版本：V2.8.1 | 增量加载 + 摘要压缩** 🆕
