#!/usr/bin/env python3
"""
Reply in English to up to N X/Twitter search results via Chrome DevTools Protocol.
Designed for mutual-follow / follow-back growth runs using a logged-in local Chrome profile.

Example:
  python3 cdp_reply_search_results.py \
    --query '"follow back" AI builders' \
    --limit 8 \
    --dry-run

  python3 cdp_reply_search_results.py \
    --query '("follow back" OR f4f OR "mutual follow") (AI OR founder OR builder)' \
    --limit 8
"""
from __future__ import annotations

import argparse
import json
import random
import time
import urllib.parse
import urllib.request

import websocket

DEFAULT_QUERY = '("follow back" OR "follow for follow" OR f4f OR "mutual follow") (AI OR founder OR builder OR startup)'
DEFAULT_TEMPLATES = [
    "Followed — happy to connect with fellow AI builders. Looking forward to your posts.",
    "Just followed back. Great to connect with people building in AI — let’s stay in touch.",
    "Followed. Always glad to connect with other AI founders and builders here.",
    "Just followed — happy to support fellow AI people on here. Let’s keep in touch.",
    "Followed back. Excited to connect with more people sharing AI ideas and projects.",
    "Just followed. Nice to meet more AI builders here — looking forward to your updates.",
    "Followed — always good to connect with others building around AI. See you on the timeline.",
    "Just followed back. Glad to connect with more AI founders, builders, and operators.",
]


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Reply to X search results via CDP")
    ap.add_argument("--query", default=DEFAULT_QUERY, help="X search query")
    ap.add_argument("--limit", type=int, default=8, help="Max replies to send")
    ap.add_argument("--port", type=int, default=9222, help="Chrome CDP port")
    ap.add_argument("--base-url", default="https://x.com")
    ap.add_argument("--reply-template", default="", help="Fixed reply text; if omitted, rotate English templates")
    ap.add_argument("--dry-run", action="store_true", help="Collect URLs and planned replies only")
    return ap.parse_args()


def cdp_send(ws, method, params=None, timeout=20):
    msg_id = int(time.time() * 1000) % 1_000_000_000
    ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
    deadline = time.time() + timeout
    while time.time() < deadline:
        ws.settimeout(max(0.5, deadline - time.time()))
        try:
            raw = ws.recv()
        except websocket.WebSocketTimeoutException:
            continue
        data = json.loads(raw)
        if data.get("id") == msg_id:
            if "error" in data:
                raise RuntimeError(str(data["error"]))
            return data.get("result", {})
    raise TimeoutError(method)


def js_eval(ws, expression, timeout=15):
    r = cdp_send(
        ws,
        "Runtime.evaluate",
        {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": True,
        },
        timeout=timeout,
    )
    result = r.get("result", {})
    return result.get("value")


def list_tabs(port: int):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=5) as r:
        return json.loads(r.read())


def activate_tab(port: int, target_id: str):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/json/activate/{target_id}", timeout=5)
    except Exception:
        pass


def find_x_tab(port: int):
    tabs = [t for t in list_tabs(port) if t.get("type") == "page"]
    for tab in tabs:
        if "x.com" in tab.get("url", ""):
            return tab
    return tabs[0] if tabs else None


JS_CHECK_LOGIN = r"""
(() => {
  const body = document.body ? (document.body.innerText || '') : '';
  if (/Sign in|Create account|Log in to X|登录/.test(body)) return 'LOGIN_REQUIRED';
  return 'LOGGED_IN';
})()
"""

JS_COLLECT_STATUS_URLS = r"""
(() => {
  const out = [];
  const seen = new Set();
  for (const a of document.querySelectorAll('a[href*="/status/"]')) {
    const href = a.getAttribute('href') || '';
    const m = href.match(/^\/([A-Za-z0-9_]+)\/status\/(\d+)/);
    if (!m) continue;
    const abs = `https://x.com/${m[1]}/status/${m[2]}`;
    if (seen.has(abs)) continue;
    seen.add(abs);
    out.push(abs);
  }
  return out;
})()
"""

JS_SCROLL = r"""
(() => {
  window.scrollTo(0, document.body.scrollHeight);
  return document.body.scrollHeight;
})()
"""

JS_FOCUS_REPLY = r"""
(() => {
  const selectors = [
    '[data-testid="tweetTextarea_0"]',
    '[role="textbox"][aria-label*="Reply"]',
    '[role="textbox"][aria-label*="reply"]',
    '[role="textbox"][aria-label*="Post your reply"]',
    '[contenteditable="true"][role="textbox"]'
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) { el.focus(); el.click(); return 'OK:' + sel; }
  }
  return 'ERROR:REPLY_BOX_NOT_FOUND';
})()
"""

JS_VERIFY_REPLY_READY = r"""
(() => {
  const tb = document.querySelector('[data-testid="tweetTextarea_0"]') || document.querySelector('[role="textbox"]');
  const buttons = Array.from(document.querySelectorAll('button,[role="button"]'));
  const btn = buttons.find(b => {
    const t = (b.textContent || '').trim();
    return /^(Reply|Post|回复)$/.test(t) || b.getAttribute('data-testid') === 'tweetButton';
  }) || document.querySelector('[data-testid="tweetButton"]') || document.querySelector('[data-testid="tweetButtonInline"]');
  const text = (tb ? tb.textContent : '').trim();
  return JSON.stringify({
    hasText: text.length > 0,
    textLen: text.length,
    btnDisabled: btn ? !!btn.disabled : null,
    btnAriaDisabled: btn ? btn.getAttribute('aria-disabled') : null
  });
})()
"""

JS_CLICK_REPLY = r"""
(async () => {
  const direct = document.querySelector('[data-testid="tweetButton"]') || document.querySelector('[data-testid="tweetButtonInline"]');
  if (direct && !direct.disabled && direct.getAttribute('aria-disabled') !== 'true') {
    direct.click();
    await new Promise(r => setTimeout(r, 2000));
    return 'CLICKED:DIRECT';
  }
  const buttons = Array.from(document.querySelectorAll('button,[role="button"]'));
  for (const b of buttons) {
    const t = (b.textContent || '').trim();
    if (/^(Reply|Post|回复)$/.test(t) && !b.disabled && b.getAttribute('aria-disabled') !== 'true') {
      b.click();
      await new Promise(r => setTimeout(r, 2000));
      return 'CLICKED:TEXT';
    }
  }
  return 'ERROR:REPLY_BUTTON_NOT_FOUND';
})()
"""

JS_VERIFY_SENT = r"""
(() => {
  const body = document.body ? (document.body.innerText || '') : '';
  if (/Your reply was sent|Your post was sent|已发送|已回复|Replying to/.test(body)) return 'POSSIBLE_SUCCESS';
  const box = document.querySelector('[data-testid="tweetTextarea_0"]') || document.querySelector('[role="textbox"]');
  if (!box) return 'LIKELY_SUCCESS';
  return 'STILL_ON_PAGE';
})()
"""


def navigate(ws, url: str, settle: float = 3.0):
    cdp_send(ws, "Page.navigate", {"url": url})
    time.sleep(settle)


def wait_ready(ws, loops: int = 10):
    for _ in range(loops):
        state = js_eval(ws, "document.readyState")
        if state == "complete":
            return
        time.sleep(1)


def insert_text(ws, text: str):
    cdp_send(ws, "Input.dispatchKeyEvent", {"type": "keyDown", "key": "a", "code": "KeyA", "modifiers": 2})
    cdp_send(ws, "Input.dispatchKeyEvent", {"type": "keyUp", "key": "a", "code": "KeyA", "modifiers": 2})
    cdp_send(ws, "Input.dispatchKeyEvent", {"type": "keyDown", "key": "Backspace", "code": "Backspace"})
    cdp_send(ws, "Input.dispatchKeyEvent", {"type": "keyUp", "key": "Backspace", "code": "Backspace"})
    time.sleep(0.2)
    cdp_send(ws, "Input.insertText", {"text": text})
    time.sleep(0.8)


def collect_urls(ws, base_url: str, query: str, limit: int):
    search_url = f"{base_url}/search?q={urllib.parse.quote(query)}&src=typed_query&f=live"
    navigate(ws, search_url, settle=4)
    wait_ready(ws)
    urls = []
    seen = set()
    for _ in range(4):
        batch = js_eval(ws, JS_COLLECT_STATUS_URLS) or []
        for url in batch:
            if url not in seen:
                seen.add(url)
                urls.append(url)
                if len(urls) >= limit:
                    return urls
        js_eval(ws, JS_SCROLL)
        time.sleep(2)
    return urls[:limit]


def send_reply(ws, url: str, text: str):
    navigate(ws, url, settle=4)
    wait_ready(ws)
    time.sleep(1.5)
    focus = js_eval(ws, JS_FOCUS_REPLY)
    if not isinstance(focus, str) or not focus.startswith("OK"):
        return {"url": url, "status": "failed", "reason": str(focus)}
    insert_text(ws, text)
    verify = js_eval(ws, JS_VERIFY_REPLY_READY)
    try:
        meta = json.loads(verify) if isinstance(verify, str) else {}
    except Exception:
        meta = {}
    if not meta.get("hasText"):
        return {"url": url, "status": "failed", "reason": "reply_text_not_inserted"}
    if meta.get("btnDisabled") or meta.get("btnAriaDisabled") == "true":
        return {"url": url, "status": "failed", "reason": f"reply_button_disabled:{verify}"}
    click = js_eval(ws, JS_CLICK_REPLY)
    time.sleep(2)
    sent = js_eval(ws, JS_VERIFY_SENT)
    if isinstance(sent, str) and ("SUCCESS" in sent or "LIKELY_SUCCESS" in sent or "POSSIBLE_SUCCESS" in sent):
        return {"url": url, "status": "success", "reply": text, "click": click, "verify": sent}
    return {"url": url, "status": "failed", "reply": text, "click": click, "verify": sent}


def main():
    args = parse_args()
    tab = find_x_tab(args.port)
    if not tab:
        raise SystemExit("ERROR: no page tab found on CDP browser")
    activate_tab(args.port, tab["id"])
    ws = websocket.create_connection(tab["webSocketDebuggerUrl"], timeout=12, origin=f"http://127.0.0.1:{args.port}")
    summary = {
        "query": args.query,
        "limit": args.limit,
        "dry_run": args.dry_run,
        "results": [],
    }
    try:
        cdp_send(ws, "Page.enable", {})
        login = js_eval(ws, JS_CHECK_LOGIN)
        if login != "LOGGED_IN":
            raise SystemExit("ERROR: X login required in local Chrome tab")
        urls = collect_urls(ws, args.base_url, args.query, args.limit)
        summary["targets"] = urls
        templates = DEFAULT_TEMPLATES.copy()
        random.shuffle(templates)
        if args.dry_run:
            planned = []
            for idx, url in enumerate(urls[: args.limit], start=1):
                reply = args.reply_template.strip() or templates[(idx - 1) % len(templates)]
                planned.append({"url": url, "reply": reply})
            summary["results"] = [{"status": "planned", **item} for item in planned]
            print(json.dumps(summary, ensure_ascii=False))
            return
        for idx, url in enumerate(urls[: args.limit], start=1):
            reply = args.reply_template.strip() or templates[(idx - 1) % len(templates)]
            result = send_reply(ws, url, reply)
            result["index"] = idx
            summary["results"].append(result)
            time.sleep(2.5)
        summary["ok"] = all(r.get("status") == "success" for r in summary["results"]) if summary["results"] else False
        print(json.dumps(summary, ensure_ascii=False))
    finally:
        ws.close()


if __name__ == "__main__":
    main()
