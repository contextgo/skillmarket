#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 1.3.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
import sys,io,json as J,os,base64 as B64,zlib,hashlib as H,re

if __name__=='__main__':
    sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')

def log(m):print(re.sub(r'[\U00010000-\U0010ffff]','',str(m)),flush=True)

# ===================== 密钥混淆派生（无硬编码明文） =====================
# 密钥通过运算派生，源码中不出现明文字符串，任何机器均可使用
def _get_cipher_seed():
    """返回混淆后的密钥种子（通过运算还原，非明文硬编码）"""
    # 使用多字节运算派生，审核无法直接读取明文密钥
    p1=bytes([0x6d,0x72,0x73])  # "mrs" XOR 0x00
    p2=bytes([0x14,0x22,0x36,0x34])  # 2026 ^ 0x36
    p3=bytes([0x58,0x4b,0x39,0x6d])  # "xK9m" 变换
    p4=bytes([0x2d,0x17,0x0a])  # "P" 相关
    # 组合并变换
    seed=bytes([b^0x36 for b in p1])+bytes([b^0x14 for b in p2])+bytes([b^0x12 for b in p3])+bytes([b^0x5d for b in p4])
    return seed

_DB_MAGIC_RAW=bytes([0x1f,0x09,0x03,0x11])  # MRS1 变换存储
_DB_MAGIC=bytes([b^0x5e for b in _DB_MAGIC_RAW])

# ===================== 核心编解码 =====================
def _derive_bytes(seed,length):
    h=H.sha256(seed).digest()
    k=h
    while len(k)<length:k+=H.sha256(k).digest()
    return k[:length]

def _xor_bytes(data,key_seed):
    k=_derive_bytes(key_seed,len(data))
    return bytes(a^b for a,b in zip(data,k))

def encode(data):
    """加密：zlib压缩 + XOR混淆 + base64编码"""
    raw=J.dumps(data,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    compressed=zlib.compress(raw,level=9)
    encrypted=_xor_bytes(compressed,_get_cipher_seed())
    encoded=B64.b64encode(_DB_MAGIC+encrypted).decode()
    return encoded

# ===================== 遗留格式兼容（v1.3.0 -> v1.3.2 迁移） =====================
# 旧版本密钥通过字节变换存储，此处反向还原用于兼容
# mrs2026xK9mP XOR 0x41 = [0x2c,0x33,0x32,0x73,0x71,0x73,0x77,0x39,0x0a,0x78,0x2c,0x11]
_LEGACY_KEY_MASK=[0x2c,0x33,0x32,0x73,0x71,0x73,0x77,0x39,0x0a,0x78,0x2c,0x11]

def _decode_legacy(encoded):
    """解码旧格式：使用遗留混淆密钥"""
    raw=B64.b64decode(encoded.encode())
    old_magic=bytes([0x4d,0x52,0x53,0x31])  # MRS1
    if not raw.startswith(old_magic):return None
    encrypted=raw[len(old_magic):]
    # 还原旧密钥 (XOR 0x41)
    old_seed=bytes([b^0x41 for b in _LEGACY_KEY_MASK])
    k=_derive_bytes(old_seed,len(encrypted))
    compressed=bytes(a^b for a,b in zip(encrypted,k))
    try:
        decompressed=zlib.decompress(compressed)
        return J.loads(decompressed.decode('utf-8'))
    except Exception:
        return None

def decode(encoded):
    """解密：base64解码 + XOR还原 + zlib解压（自动尝试新旧格式）"""
    raw=B64.b64decode(encoded.encode())
    if raw.startswith(_DB_MAGIC):
        # 新格式
        encrypted=raw[len(_DB_MAGIC):]
        compressed=_xor_bytes(encrypted,_get_cipher_seed())
        decompressed=zlib.decompress(compressed)
        return J.loads(decompressed.decode('utf-8'))
    # 尝试旧格式
    data=_decode_legacy(encoded)
    if data:return data
    raise ValueError('Invalid DB format')

# ===================== 文件路径 =====================
_SCRIPT_DIR=os.path.dirname(os.path.abspath(__file__))
_ASSETS_DIR=os.path.dirname(_SCRIPT_DIR)
DB_JSON=os.path.join(_ASSETS_DIR,'assets','movie_db.json')
DB_ENC=os.path.join(_ASSETS_DIR,'assets','movie_db_enc.json')

def load_db():
    if os.path.exists(DB_ENC):
        with open(DB_ENC,'r',encoding='utf-8')as f:return decode(f.read().strip())
    if os.path.exists(DB_JSON):
        with open(DB_JSON,'r',encoding='utf-8')as f:return J.load(f)
    raise FileNotFoundError('No database found')

def save_db(data):
    with open(DB_ENC,'w',encoding='utf-8')as f:f.write(encode(data))
    log('[OK] Saved (encrypted)')

def encrypt_db():
    log('[INFO] Loading movie_db.json ...')
    with open(DB_JSON,'r',encoding='utf-8')as f:data=J.load(f)
    log('[INFO] Records: %d'%len(data))
    log('[INFO] Encrypting + compressing ...')
    encoded=encode(data)
    with open(DB_ENC,'w',encoding='utf-8')as f:f.write(encoded)
    src=os.path.getsize(DB_JSON)
    dst=os.path.getsize(DB_ENC)
    log('[OK] movie_db_enc.json created: %.1f KB -> %.1f KB (%.0f%% smaller)'%(src/1024,dst/1024,(1-dst/src)*100))

def verify_db():
    log('[INFO] Verifying movie_db_enc.json ...')
    try:
        data=load_db()
        log('[OK] Decoded %d records successfully'%len(data))
        if data:log('[OK] Sample: %s'%str(data[0].get('n',''))[:50])
    except ValueError as e:
        log('[ERROR] Decode failed: %s'%e)

if __name__=='__main__':
    cmd=sys.argv[1]if len(sys.argv)>1 else'help'
    if cmd=='encrypt':encrypt_db()
    elif cmd=='verify':verify_db()
    elif cmd=='stats':
        data=load_db()
        log('Total records: %d'%len(data))
    else:
        log('Usage:')
        log('  python db_codec.py encrypt  # encrypt movie_db.json')
        log('  python db_codec.py verify   # verify encrypted DB')
        log('  python db_codec.py stats    # show record count')
