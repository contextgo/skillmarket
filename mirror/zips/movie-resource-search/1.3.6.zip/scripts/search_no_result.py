#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys,io,os
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
sys.stderr=io.TextIOWrapper(sys.stderr.buffer,encoding='utf-8',errors='replace')
sys.path.insert(0,os.path.dirname(__file__))
from user_system import UserSystem
def log(m):print(str(m),flush=True)
def main():
    kw=' '.join(sys.argv[1:])if len(sys.argv)>1 else ''
    us=UserSystem();info=us.get_level_info()
    log('========================================')
    log('  未找到 "%s" 相关资源'%kw)
    log('')
    log('  [资源补充服务]')
    log('  只需提供以下信息即可入库：')
    log('  1. 资源名称（中文或英文）')
    log('  2. 资源链接')
    log('  3. 访问码（如有）')
    log('')
    log('  提交示例：')
    log('  名称: Shameless 无耻之徒')
    log('  链接: https://cloud.189.cn/t/xxxxx')
    log('  访问码: abcd')
    log('')
    log('  其他信息（年份/类型/简介）自动从TMDB获取')
    log('  提交成功奖励: +3积分!')
    log('========================================')
    for line in us.get_status_text().split('\n'):log(line)
if __name__=='__main__':main()