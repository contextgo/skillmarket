#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from user_system import UserSystem

def record_contribution(name):
    us = UserSystem()
    r = us.add_score('contribute', f'补充资源: {name}')
    lines = ['========================================',
        '  >>> 贡献记录成功 <<<',
        '  +%d分 | 当前%d分' % (r['points_added'], r['new_score'])]
    if r['level_up']:
        lines.append('  *** 恭喜升级: %s %s -> %s %s ***' % (r['old_level']['level'],r['old_level']['title'],r['new_level']['level'],r['new_level']['title']))
    lines += ['  当前等级: %s %s' % (r['new_level']['level'],r['new_level']['title']),
        '========================================']
    return '\n'.join(lines)

if __name__=='__main__':
    if len(sys.argv)<2: print("Usage: python record_contribution.py <name>"); sys.exit(1)
    print(record_contribution(' '.join(sys.argv[1:])))