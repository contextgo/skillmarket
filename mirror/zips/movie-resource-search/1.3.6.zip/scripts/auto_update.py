#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys,io,json,re,os
from datetime import datetime
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
sys.stderr=io.TextIOWrapper(sys.stderr.buffer,encoding='utf-8',errors='replace')
sys.path.insert(0,os.path.dirname(__file__))
from learn import LearnSystem
DB=os.path.join(os.path.dirname(__file__),'..','assets','movie_db.json')
def log(m):print(re.sub(r'[\U00010000-\U0010ffff]','',str(m)),flush=True)
def load_db():
    with open(DB,'r',encoding='utf-8')as f:return json.load(f)
def save_db(d):
    with open(DB,'w',encoding='utf-8')as f:json.dump(d,f,ensure_ascii=False,separators=(',',':'))
def dedup_names(db):
    seen=set();cleaned=[];removed=0
    for item in db:
        n=item['n']
        if n not in seen:seen.add(n);cleaned.append(item)
        else:removed+=1
    return cleaned,removed
def merge_links(db):
    name_links={}
    for item in db:
        n=item['n']
        if n not in name_links:name_links[n]=[]
        for l in item['l']:
            if l['u'] not in [x['u']for x in name_links[n]]:name_links[n].append(l)
    merged=0
    for item in db:
        n=item['n']
        if len(item['l'])<len(name_links[n]):item['l']=name_links[n];merged+=1
    return db,merged
def remove_dead(db,ls):
    dead_urls=set(ls.data.get('dead_links',{}).keys())
    marked=0
    for item in db:
        for l in item['l']:
            if l['u'] in dead_urls:marked+=1
    return db,marked
def auto_learn(db,ls):
    for item in db:
        nm=item['n'].lower()
        m=item.get('m',{})
        if m.get('c'):ls.learn_kw_map(nm,m['c'].lower())
        g=item.get('g',[])
        for tg in g:ls.learn_kw_map(nm,tg.lower())
        for part in nm.split():
            if len(part)>=2:
                if m.get('c'):ls.learn_kw_map(part,m['c'].lower())
                for tg in g:ls.learn_kw_map(part,tg.lower())
    return len(db)
def main():
    cmd=sys.argv[1]if len(sys.argv)>1 else'clean'
    ls=LearnSystem()
    if cmd=='clean':
        db=load_db();orig=len(db)
        db,dup=dedup_names(db);log('[OK] Dedup: removed %d duplicates'%dup)
        db,mg=merge_links(db);log('[OK] Merge: merged %d links'%mg)
        db,marked=remove_dead(db,ls);log('[OK] Dead links: %d marked (will show warning)'%marked)
        save_db(db);log('[OK] DB: %d items (none removed, only marked)'%len(db))
        ls.auto_clean();log('[OK] Learn data cleaned')
    elif cmd=='learn':
        db=load_db();n=auto_learn(db,ls);log('[OK] Learned from %d items'%n)
        log('[OK] KW map: %d mappings'%len(ls.data['kw_map']))
        log('[OK] Hot items: %d'%len(ls.data['hot_items']))
    elif cmd=='stats':
        ls2=LearnSystem()
        log('Search stats: %d keywords'%len(ls2.data['search_stats']))
        log('KW map: %d mappings'%len(ls2.data['kw_map']))
        log('Hot items: %d tracked'%len(ls2.data['hot_items']))
        log('Dead links: %d reported'%len(ls2.data['dead_links']))
        db=load_db();log('DB items: %d'%len(db))
        log('Last clean: %s'%ls2.data.get('last_clean','never'))
    elif cmd=='dead':
        url=sys.argv[2]if len(sys.argv)>2 else''
        reason=sys.argv[3]if len(sys.argv)>3 else'user report'
        if url:ls.record_dead_link(url,reason);log('[OK] Dead link recorded')
    else:log("Commands: clean|learn|stats|dead <url> [reason]")
if __name__=='__main__':main()