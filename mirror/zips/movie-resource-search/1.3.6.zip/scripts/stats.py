#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, io, json, os
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

p = os.path.join(os.path.dirname(__file__), '..', 'assets', 'movie_resources.json')
data = json.load(open(p,'r',encoding='utf-8'))
tc=Counter(); yc=Counter(); tg=Counter()
for item in data:
    tm=item.get('TMDB信息',{})
    tc[tm.get('类型','未知')]+=1
    if tm.get('年份'): yc[str(tm['年份'])]+=1
    for t in item.get('标签',[]): tg[t]+=1
print(f"总资源: {len(data)}条")
print("类型分布:")
for t,c in tc.most_common(10): print(f"  {t}: {c}条")
print("年份分布:")
for y,c in yc.most_common(10): print(f"  {y}年: {c}条")
print("热门标签:")
for t,c in tg.most_common(15): print(f"  {t}: {c}条")