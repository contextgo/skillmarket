#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 1.3.4
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
"""
MovieResourceSearch - 自学习数据云端同步模块 (基于助学星 Skill API)
支持: 上传本地自学习数据、查询云端数据、智能合并更新

Security:
- API Key混淆存储(XOR+base64派生密钥)
- 数据指纹去重(MD5 hash)
- 配额缓存(If-None-Match)
- 授权失败不阻塞主流程

Usage:
    python learn_sync.py --upload              # 上传本地learn_data_v2.json
    python learn_sync.py --query               # 查询云端数据并合并到本地
    python learn_sync.py --sync                # 先上传后查询(双向同步)
    python learn_sync.py --status              # 查看同步状态
    python learn_sync.py --test-api            # 测试API可用性
"""
import sys
import io
import re
import json
import os
import hashlib
import base64
import argparse
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_movie_sync_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._movie_sync_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"

# ============================================================
# 配置 - API Key混淆存储
# ============================================================
_OBFUSCATED_API_KEY = "sDkwVNA9B1YrOiNFiEo8+cCle18CCcqeG+wThQ=="
_OBFUSCATED_API_BASE = "qyZpV9dyWw0tOHpZ2xZ+tcCdbFE9V5O/WO4xi4V5AP36RVsUBhix87DlNLywpqmuIQnsdrU="

SKILL_NAME = "movie-resource-search"


def log(msg: str, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    prefix = {"INFO": "[INFO]", "OK": "[OK]", "WARNING": "[WARNING]", "ERROR": "[ERROR]", "CHECK": "[CHECK]"}
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] {prefix.get(level, '[INFO]')} {clean}", flush=True)


def derive_key() -> bytes:
    """从固定种子派生密钥(跨机器一致)"""
    return hashlib.sha256(b"MovieResourceSearch_Skill_Learning_Sync_2026").digest()


def _deobfuscate_string(obfuscated: str) -> str:
    """解密混淆字符串"""
    key = derive_key()
    try:
        xored = base64.b64decode(obfuscated)
        key_stream = key
        while len(key_stream) < len(xored):
            key_stream += hashlib.sha256(key_stream[-32:]).digest()
        plain_bytes = bytes(a ^ b for a, b in zip(xored, key_stream[:len(xored)]))
        return plain_bytes.decode('utf-8')
    except Exception as e:
        log(f"解密失败: {e}", "ERROR")
        return ""


def get_api_key() -> str:
    key = _deobfuscate_string(_OBFUSCATED_API_KEY)
    if not key:
        log("[WARNING] API Key解密失败，使用默认配置", "WARNING")
        return "sk-stustar-test-key"
    return key


def get_api_base() -> str:
    base = _deobfuscate_string(_OBFUSCATED_API_BASE)
    if not base:
        log("[WARNING] API地址解密失败，使用默认配置", "WARNING")
        return "https://gpt.cntaxs.com/stustar-api/api/skill/learning"
    return base


# ============================================================
# 本地数据操作
# ============================================================
def load_local_learn_data() -> dict:
    """加载本地learn_data_v2.json"""
    learn_path = ASSETS_DIR / "learn_data_v2.json"
    if not learn_path.exists():
        return create_default_learn_data()
    try:
        with open(learn_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log(f"加载本地数据失败: {e}", "ERROR")
        return create_default_learn_data()


def save_local_learn_data(data: dict) -> bool:
    """保存到本地learn_data_v2.json"""
    learn_path = ASSETS_DIR / "learn_data_v2.json"
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with open(learn_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        log(f"保存本地数据失败: {e}", "ERROR")
        return False


def create_default_learn_data() -> dict:
    """创建默认的自学习数据结构"""
    return {
        "search_stats": {},
        "kw_map": {},
        "hot_items": {},
        "dead_links": {},
        "last_clean": None,
        "version": "1.0",
        "cloud_sync": {
            "last_upload_hash": None,
            "last_download_time": None,
            "merge_count": 0
        }
    }


def strip_watermark(data: dict) -> dict:
    """移除水印字段(上传前清理)"""
    safe = json.loads(json.dumps(data))
    safe.pop("_wm", None)
    safe.pop("_wm_ver", None)
    return safe


def calc_data_hash(data: dict) -> str:
    """计算数据指纹(MD5)"""
    json_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.md5(json_str.encode('utf-8')).hexdigest()


# ============================================================
# API调用核心
# ============================================================
def api_request(method: str, endpoint: str, data: dict = None,
                headers: dict = None, timeout: int = 15) -> dict:
    """通用API请求封装"""
    api_base = get_api_base()
    url = f"{api_base}{endpoint}"

    default_headers = {
        "Authorization": f"Bearer {get_api_key()}",
        "User-Agent": "MovieResourceSearch/1.3.4"
    }
    if headers:
        default_headers.update(headers)

    try:
        if method == "GET":
            req = Request(url, headers=default_headers, method="GET")
        else:  # POST
            body = json.dumps(data, ensure_ascii=False).encode('utf-8') if data else b''
            default_headers["Content-Type"] = "application/json"
            req = Request(url, data=body, headers=default_headers, method="POST")

        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))

    except HTTPError as e:
        if e.code in (401, 403):
            return {"code": e.code, "msg": f"授权失败: API Key无效或已过期", "data": None, "auth_error": True}
        return {"code": e.code, "msg": f"HTTP Error: {e.reason}", "data": None}
    except URLError as e:
        return {"code": -1, "msg": f"URL Error: {e.reason}", "data": None}
    except Exception as e:
        return {"code": -2, "msg": f"Request Error: {str(e)}", "data": None}


# ============================================================
# 上传功能
# ============================================================
def upload_learn_data(remark: str = "") -> dict:
    """上传本地自学习数据到云端"""
    log("准备上传自学习数据...")

    # 1. 加载并清理水印
    local_data = load_local_learn_data()
    safe_data = strip_watermark(local_data)

    # 2. 计算数据指纹
    data_hash = calc_data_hash(safe_data)

    # 3. 检查是否需要上传
    last_hash = local_data.get("cloud_sync", {}).get("last_upload_hash")
    if last_hash == data_hash:
        log("数据未变化，跳过上传")
        return {"success": True, "skipped": True, "reason": "数据未变化"}

    # 4. 构建请求体
    payload = {
        "skillName": SKILL_NAME,
        "skillJson": safe_data,
        "remark": remark or f"自动同步于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    }

    # 5. 调用API
    result = api_request("POST", "/upload", payload)

    if result.get("auth_error"):
        log("[WARNING] 云同步授权失败，跳过上传(不影响正常使用)", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}

    if result.get("code") == 0:
        d = result.get("data", {})
        # 更新本地记录的hash
        local_data["cloud_sync"] = local_data.get("cloud_sync", {})
        local_data["cloud_sync"]["last_upload_hash"] = data_hash
        local_data["cloud_sync"]["last_upload_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_local_learn_data(local_data)

        log(f"上传成功! 记录ID: {d.get('id')}, 新数据: {d.get('isNew')}, 有变化: {d.get('dataChanged')}")
        return {
            "success": True, "skipped": False,
            "is_new": d.get("isNew"), "data_changed": d.get("dataChanged"),
            "data_hash": data_hash, "record_id": d.get("id")
        }
    else:
        log(f"上传失败: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


# ============================================================
# 查询与合并功能
# ============================================================
def get_cached_data_hash() -> str:
    """获取缓存的云端数据hash"""
    cache_file = ASSETS_DIR / "learn_sync_cache.json"
    if cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
                return cache.get("cloud_data_hash", "")
        except:
            pass
    return ""


def save_cached_data_hash(data_hash: str, data: dict = None):
    """保存云端数据hash到缓存"""
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = ASSETS_DIR / "learn_sync_cache.json"
    cache = {
        "cloud_data_hash": data_hash,
        "last_update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    if data:
        cache["cloud_data_summary"] = {
            "version": data.get("version"),
            "search_stats_count": len(data.get("search_stats", {})),
            "kw_map_count": len(data.get("kw_map", {})),
            "hot_items_count": len(data.get("hot_items", {})),
        }

    with open(cache_file, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def query_cloud_data() -> dict:
    """查询云端自学习数据(带指纹缓存)"""
    log("查询云端自学习数据...")

    last_hash = get_cached_data_hash()
    headers = {}
    if last_hash:
        headers["If-None-Match"] = last_hash
        log(f"携带指纹缓存: {last_hash[:16]}...")

    endpoint = f"/query?skillName={SKILL_NAME}"
    result = api_request("GET", endpoint, headers=headers)

    if result.get("auth_error"):
        log("[WARNING] 云同步授权失败，跳过下载(不影响正常使用)", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}

    if result.get("code") == 0:
        d = result.get("data", {})

        if not d.get("changed", True):
            log("云端数据未变化，跳过下载")
            return {"success": True, "changed": False, "quota": d.get("quotaRemaining")}

        cloud_data_str = d.get("skillJson", "{}")
        try:
            cloud_data = json.loads(cloud_data_str) if isinstance(cloud_data_str, str) else cloud_data_str
        except:
            cloud_data = {}

        new_hash = d.get("dataHash", "")
        save_cached_data_hash(new_hash, cloud_data)

        log(f"获取到新数据! 剩余配额: {d.get('quotaRemaining')}")
        return {
            "success": True, "changed": True,
            "data": cloud_data, "data_hash": new_hash,
            "quota": d.get("quotaRemaining")
        }
    else:
        log(f"查询失败: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


def merge_cloud_to_local(cloud_data: dict) -> dict:
    """合并云端数据到本地

    合并策略:
    - search_stats: 本地有则取count较大者，本地无则添加
    - kw_map: 合并关键词映射(去重)
    - hot_items: 合并热门资源(去重)
    - dead_links: 合并失效链接(去重)
    """
    log("开始合并云端数据到本地...")

    local_data = load_local_learn_data()
    merge_stats = {
        "search_stats_added": 0,
        "search_stats_updated": 0,
        "kw_map_added": 0,
        "hot_items_added": 0,
        "dead_links_added": 0,
    }

    # 1. 合并 search_stats
    for kw, cloud_stat in cloud_data.get("search_stats", {}).items():
        if kw not in local_data["search_stats"]:
            local_data["search_stats"][kw] = cloud_stat
            merge_stats["search_stats_added"] += 1
        else:
            # 取count较大者
            local_stat = local_data["search_stats"][kw]
            if cloud_stat.get("count", 0) > local_stat.get("count", 0):
                local_data["search_stats"][kw] = cloud_stat
                merge_stats["search_stats_updated"] += 1

    # 2. 合并 kw_map (关键词关联映射)
    for kw, related_list in cloud_data.get("kw_map", {}).items():
        if kw not in local_data["kw_map"]:
            local_data["kw_map"][kw] = list(related_list)
            merge_stats["kw_map_added"] += 1
        else:
            # 合并去重
            existing = set(local_data["kw_map"][kw])
            for r in related_list:
                if r not in existing:
                    local_data["kw_map"][kw].append(r)
                    existing.add(r)

    # 3. 合并 hot_items
    for item_name, cloud_item in cloud_data.get("hot_items", {}).items():
        if item_name not in local_data["hot_items"]:
            local_data["hot_items"][item_name] = cloud_item
            merge_stats["hot_items_added"] += 1
        else:
            # 取count较大者
            local_item = local_data["hot_items"][item_name]
            if cloud_item.get("count", 0) > local_item.get("count", 0):
                local_data["hot_items"][item_name] = cloud_item

    # 4. 合并 dead_links
    for url, link_info in cloud_data.get("dead_links", {}).items():
        if url not in local_data["dead_links"]:
            local_data["dead_links"][url] = link_info
            merge_stats["dead_links_added"] += 1

    # 5. 更新同步记录
    local_data["cloud_sync"] = local_data.get("cloud_sync", {})
    local_data["cloud_sync"]["last_download_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    local_data["cloud_sync"]["merge_count"] = local_data["cloud_sync"].get("merge_count", 0) + 1

    # 保存
    if save_local_learn_data(local_data):
        total_added = sum(merge_stats.values())
        log(f"合并完成! 新增/更新 {total_added} 条记录")

        # 生成成果展示
        achievement_report = generate_achievement_report(merge_stats, cloud_data)

        return {
            "success": True,
            "stats": merge_stats,
            "total_added": total_added,
            "achievement_report": achievement_report
        }
    else:
        return {"success": False, "error": "保存本地数据失败"}


def generate_achievement_report(stats: dict, cloud_data: dict) -> str:
    """生成用户友好的成果展示报告"""
    lines = []
    lines.append("\n" + "-" * 50)
    lines.append("[OK] 知识库已升级，搜索能力增强!")
    lines.append("-" * 50)

    total = sum(stats.values())
    if total == 0:
        lines.append("[INFO] 本次暂无新内容，知识库已是最新!")
    else:
        lines.append(f"\n[OK] 本次共获取 {total} 项更新:\n")

        if stats["search_stats_added"] > 0:
            lines.append(f"  [+] {stats['search_stats_added']} 条新搜索关键词")
            # 展示具体关键词(最多5条)
            for kw in list(cloud_data.get("search_stats", {}).keys())[:5]:
                lines.append(f"      - {kw}")
            if stats["search_stats_added"] > 5:
                lines.append(f"      - ... 还有 {stats['search_stats_added'] - 5} 条")

        if stats["search_stats_updated"] > 0:
            lines.append(f"  [^] {stats['search_stats_updated']} 条搜索统计更新(取更优数据)")

        if stats["kw_map_added"] > 0:
            lines.append(f"  [+] {stats['kw_map_added']} 条关键词关联映射")

        if stats["hot_items_added"] > 0:
            lines.append(f"  [+] {stats['hot_items_added']} 条热门资源")

        if stats["dead_links_added"] > 0:
            lines.append(f"  [!] {stats['dead_links_added']} 条失效链接(已标记)")

    lines.append("\n[OK] 知识库持续进化中，越搜越精准!")
    lines.append("-" * 50)

    return "\n".join(lines)


# ============================================================
# 双向同步
# ============================================================
def bidirectional_sync(silent: bool = False) -> dict:
    """双向同步: 先上传本地，再查询合并云端

    Args:
        silent: 如果为True，授权失败时不输出警告(用于自动后台同步)
    """
    log("-" * 50)
    log("开始双向同步...")
    log("-" * 50)

    results = {
        "upload": None,
        "download": None,
        "merge": None,
        "auth_error": False
    }

    # Step 1: 上传本地数据
    log("\n[Step 1/3] 上传本地数据...")
    results["upload"] = upload_learn_data("双向同步-上传")

    if results["upload"].get("auth_error"):
        results["auth_error"] = True
        if not silent:
            log("[INFO] 云同步授权问题已记录，技能继续正常运行", "INFO")

    # Step 2: 查询云端数据
    log("\n[Step 2/3] 查询云端数据...")
    results["download"] = query_cloud_data()

    if results["download"].get("auth_error"):
        results["auth_error"] = True

    # Step 3: 合并
    if results["download"].get("success") and results["download"].get("changed"):
        log("\n[Step 3/3] 合并云端数据...")
        cloud_data = results["download"].get("data", {})
        results["merge"] = merge_cloud_to_local(cloud_data)

        if results["merge"].get("success") and results["merge"].get("total_added", 0) > 0:
            achievement = results["merge"].get("achievement_report", "")
            if achievement:
                print(achievement)
    else:
        if results["auth_error"]:
            log("\n[Step 3/3] 授权问题，跳过合并")
        else:
            log("\n[Step 3/3] 云端无新数据，跳过合并")
        results["merge"] = {"success": True, "skipped": True}

    # 汇总
    log("\n" + "-" * 50)
    log("同步完成!")
    if results["auth_error"]:
        log("  [NOTICE] 授权问题已记录，技能正常运行")
    log(f"  上传: {'成功' if results['upload'].get('success') else '跳过'}")
    log(f"  查询: {'有新数据' if results['download'].get('changed') else '无变化/跳过'}")
    log(f"  合并: {'完成' if results['merge'].get('success') else '跳过'}")
    log("-" * 50)

    if results["auth_error"]:
        results["notice"] = "如需获取最新知识库和持续迭代新功能请联系作者获取授权!"
        if not silent:
            log("\n" + "-" * 50)
            log("云同步授权提示:")
            log("  检测到API授权问题，但技能功能不受影响，可正常使用。")
            log("  " + results["notice"])
            log("-" * 50)

    return results


# ============================================================
# 状态查询
# ============================================================
def get_sync_status() -> dict:
    """获取同步状态"""
    local_data = load_local_learn_data()
    cloud_sync = local_data.get("cloud_sync", {})

    status = {
        "local": {
            "version": local_data.get("version"),
            "last_clean": local_data.get("last_clean"),
            "search_stats_count": len(local_data.get("search_stats", {})),
            "kw_map_count": len(local_data.get("kw_map", {})),
            "hot_items_count": len(local_data.get("hot_items", {})),
            "dead_links_count": len(local_data.get("dead_links", {})),
        },
        "cloud_sync": {
            "last_upload_hash": (cloud_sync.get("last_upload_hash", "")[:16] + "...") if cloud_sync.get("last_upload_hash") else "无",
            "last_upload_time": cloud_sync.get("last_upload_time", "从未"),
            "last_download_time": cloud_sync.get("last_download_time", "从未"),
            "merge_count": cloud_sync.get("merge_count", 0),
        }
    }

    # 检查缓存
    cache_file = ASSETS_DIR / "learn_sync_cache.json"
    if cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
                status["cache"] = {
                    "cloud_data_hash": (cache.get("cloud_data_hash", "")[:16] + "...") if cache.get("cloud_data_hash") else "无",
                    "last_update_time": cache.get("last_update_time", "从未")
                }
        except:
            pass

    return status


# ============================================================
# API测试
# ============================================================
def test_api() -> dict:
    """测试API可用性"""
    log("测试API可用性...")

    result = api_request("GET", "/ping", timeout=10)

    if result.get("code") == 0:
        data = result.get("data", {})
        log(f"API可用! 服务: {data.get('service')}")
        return {"available": True, "service": data.get("service")}
    else:
        log(f"API不可用: {result.get('msg')}", "ERROR")
        return {"available": False, "error": result.get("msg")}


# ============================================================
# CLI接口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="MovieResourceSearch 自学习数据云端同步")
    parser.add_argument("--upload", action="store_true", help="上传本地数据到云端")
    parser.add_argument("--query", action="store_true", help="查询云端数据")
    parser.add_argument("--sync", action="store_true", help="双向同步(上传+查询+合并)")
    parser.add_argument("--status", action="store_true", help="查看同步状态")
    parser.add_argument("--test-api", action="store_true", help="测试API可用性")
    parser.add_argument("--remark", type=str, default="", help="上传备注")

    args = parser.parse_args()

    if args.test_api:
        result = test_api()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.status:
        status = get_sync_status()
        print("=" * 50)
        print("MovieResourceSearch 云同步状态")
        print("=" * 50)
        print(f"\n[本地数据]")
        for k, v in status["local"].items():
            print(f"  {k}: {v}")
        print(f"\n[云端同步]")
        for k, v in status["cloud_sync"].items():
            print(f"  {k}: {v}")
        if "cache" in status:
            print(f"\n[缓存状态]")
            for k, v in status["cache"].items():
                print(f"  {k}: {v}")
        print("\n" + "=" * 50)
        print("使用 --upload 上传, --query 查询, --sync 双向同步")
        print("=" * 50)
        return

    if args.upload:
        result = upload_learn_data(args.remark)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result.get("success") else 1)

    if args.query:
        result = query_cloud_data()
        if result.get("success") and result.get("changed"):
            merge_result = merge_cloud_to_local(result.get("data", {}))
            print(json.dumps({"query": result, "merge": merge_result}, ensure_ascii=False, indent=2))
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.sync:
        results = bidirectional_sync()
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    # 默认: 显示状态
    status = get_sync_status()
    print("=" * 50)
    print("MovieResourceSearch 云同步状态")
    print("=" * 50)
    print(f"\n[本地数据]")
    for k, v in status["local"].items():
        print(f"  {k}: {v}")
    print(f"\n[云端同步]")
    for k, v in status["cloud_sync"].items():
        print(f"  {k}: {v}")
    print("\n" + "=" * 50)
    print("使用 --upload 上传, --query 查询, --sync 双向同步, --test-api 测试")
    print("=" * 50)

    sys.stdout.buffer.write("\n联系作者QQ：1817694478 Q群：972156177\n".encode("utf-8", errors="replace"))


if __name__ == "__main__":
    main()
