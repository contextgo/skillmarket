#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IntegrityGuard - Universal Skill Anti-Tamper & Anti-Plagiarism Module
Skill 通用防篡改防抄袭防护模块

Features:
1. File integrity: SHA256 hash verification on startup
2. Copyright header: Auto-check all .py/.json/.md files
3. Code watermark: Structural fingerprint in JSON data files
4. Knowledge base signature: Version + hash binding
5. Cross-file consistency: SKILL.md version = scripts version = KB version
6. Self-check CLI: --verify-integrity for daily audit
7. Self-learning protection: Learning files can be modified but are still verified

Author Verification:
- Checks for mandatory author info: QQ 1817694478, Q群: 972156177
- If tampered, shows: "文件损坏，请从市场重新下载安装或更新版本"

Self-Learning File Protection:
- Learning files (learn_data*.json) can be modified by self-learning mechanism
- Integrity markers are updated automatically after each self-learning modification
- Unauthorized modifications (outside self-learning) are detected and flagged
- This allows self-learning while still detecting external tampering

Usage (in each skill's scripts):
    from integrity_guard import IntegrityGuard
    guard = IntegrityGuard(skill_dir=SKILL_DIR, skill_name="tax-risk-guard")
    ok, msg = guard.startup_check_with_message()  # Run on skill startup
    if not ok:
        print(msg)
        sys.exit(1)

    # CLI mode
    python integrity_guard.py --verify-integrity --skill-dir /path/to/skill
    python integrity_guard.py --generate-manifest --skill-dir /path/to/skill
    python integrity_guard.py --add-copyright --skill-dir /path/to/skill

Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
Author: QQ 1817694478 | Q-Group: 972156177
"""
import sys
import io
import re
import json
import os
import hashlib
import argparse
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# ============================================================
# Constants
# ============================================================

COPYRIGHT_TEMPLATE = '''# Copyright (c) {year} WorkBuddy Skills. All rights reserved.
# Skill: {skill_name} | Version: {version}
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
'''

COPYRIGHT_TEMPLATE_MD = '''<!--
Copyright (c) {year} WorkBuddy Skills. All rights reserved.
Skill: {skill_name} | Version: {version}
Author: QQ 1817694478 | Q-Group: 972156177
Unauthorized copying, modification, or distribution is prohibited.
-->
'''

MANIFEST_FILENAME = "manifest.json"

# Files to skip during integrity check
SKIP_PATTERNS = [
    r'\.pyc$', r'__pycache__', r'\.log$', r'\.tmp$',
    r'manifest\.json$', r'temp_.*\.json$', r'test_.*\.json$',
    r'test_.*\.html$', r'demo_.*\.json$', r'reports[\/]',
    r'\.git[\/]', r'node_modules[\/]',
    r'\.clawdhubignore$',  # Packaging config file itself should not be packaged
    # Packaged release files
    r'\.zip$', r'\.tar\.gz$', r'\.tar$', r'\.tgz$',
    r'\.sha256$', r'\.sha1$', r'\.md5$',
    # Development documentation (not shipped in packages)
    r'^README\.md$',  # Technical README excluded from package
    # Runtime-generated files (created by skill scripts, not shipped)
    # Note: movie_db_enc.json IS shipped in package, do NOT skip it
    r'movie_db\.json$',      # movie-resource-search: source DB (plaintext, never shipped)
    r'user_data\.json$',     # user data (modified by search/contribution)
]

# Self-learning files whitelist - these can be modified by the skill itself
# Files matching these patterns are excluded from manifest hash verification
# but are still protected by author info check
LEARNING_WHITELIST = [
    r'learn_data.*\.json$',          # learn_data.json, learn_data_v2.json, etc.
    r'.*_learn\.json$',              # wb_gift_learn.json, etc.
    r'self_learning_cache\.json$',   # cache files
    r'user_preferences\.json$',      # user settings
    r'query_history\.json$',         # query logs
    r'search_history\.json$',        # search logs
    r'skill_learn\.json$',           # generic skill learning data
]

# Watermark field name (hidden in JSON data)
WATERMARK_FIELD = "_wm"
WATERMARK_VALUE = "WB2817694478"


# ============================================================
# Core Functions
# ============================================================

def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    prefix = {"INFO": "[INFO]", "OK": "[OK]", "WARNING": "[WARNING]", "ERROR": "[ERROR]", "CHECK": "[CHECK]"}
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] {prefix.get(level, '[INFO]')} {clean}", flush=True)


def should_skip(filepath: str) -> bool:
    """Check if file should be skipped during integrity check"""
    # Normalize path separators and get just the filename for certain checks
    normalized = filepath.replace('\\', '/')
    basename = os.path.basename(filepath)
    for pattern in SKIP_PATTERNS:
        if re.search(pattern, normalized):
            return True
    # Special case: README.md (matches basename only, not in subdirectories)
    if basename == 'README.md':
        return True
    return False


def is_learning_file(filepath: str) -> bool:
    """Check if file is in self-learning whitelist (can be modified at runtime)"""
    for pattern in LEARNING_WHITELIST:
        if re.search(pattern, filepath.replace('\\', '/')):
            return True
    return False


def compute_file_hash(filepath: str) -> str:
    """Compute SHA256 hash of a file"""
    sha256 = hashlib.sha256()
    try:
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except Exception as e:
        return f"ERROR:{e}"


def extract_version_from_skill_md(skill_dir: Path) -> str:
    """Extract version from SKILL.md"""
    skill_md = skill_dir / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding='utf-8', errors='replace')
        # Match version patterns like "v1.2.0" or "Version: 1.2.0"
        m = re.search(r'[Vv]ersion[:\s]*[vV]?(\d+\.\d+\.\d+)', content)
        if m:
            return m.group(1)
    return "0.0.0"


def extract_skill_name(skill_dir: Path) -> str:
    """Extract skill name from SKILL.md frontmatter"""
    skill_md = skill_dir / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding='utf-8', errors='replace')
        m = re.search(r'^name:\s*(.+)$', content, re.MULTILINE)
        if m:
            return m.group(1).strip()
    return skill_dir.name


# ============================================================
# IntegrityGuard Class
# ============================================================

class IntegrityGuard:
    """Universal Skill Integrity Guard"""

    def __init__(self, skill_dir: str, skill_name: str = None):
        self.skill_dir = Path(skill_dir)
        self.skill_name = skill_name or extract_skill_name(self.skill_dir)
        self.version = extract_version_from_skill_md(self.skill_dir)
        self.manifest_path = self.skill_dir / MANIFEST_FILENAME

    def collect_files(self, include_learning: bool = False) -> list:
        """Collect all protected files in skill directory
        
        Args:
            include_learning: If True, include self-learning files (for manifest generation)
        """
        files = []
        for root, dirs, filenames in os.walk(self.skill_dir):
            # Skip hidden dirs and __pycache__
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
            for fn in filenames:
                filepath = os.path.join(root, fn)
                relpath = os.path.relpath(filepath, self.skill_dir)
                if should_skip(relpath):
                    continue
                if not include_learning and is_learning_file(relpath):
                    # Skip learning files during manifest generation and verification
                    continue
                files.append(filepath)
        return sorted(files)

    def generate_manifest(self) -> dict:
        """Generate manifest.json with file hashes and metadata"""
        files = self.collect_files(include_learning=False)  # Exclude learning files
        manifest = {
            "skill_name": self.skill_name,
            "version": self.version,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "file_count": len(files),
            "files": {},
            "watermark": self._generate_watermark(),
            "excluded_patterns": ["self-learning data files (learn_data*.json, etc.)"]
        }

        for filepath in files:
            relpath = os.path.relpath(filepath, self.skill_dir).replace('\\', '/')
            fhash = compute_file_hash(filepath)
            fsize = os.path.getsize(filepath)
            manifest["files"][relpath] = {
                "sha256": fhash,
                "size": fsize
            }

        return manifest

    def save_manifest(self) -> str:
        """Generate and save manifest.json"""
        manifest = self.generate_manifest()
        with open(self.manifest_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
        log(f"Manifest saved: {self.manifest_path} ({manifest['file_count']} files)", "OK")
        return str(self.manifest_path)

    def verify_integrity(self, strict: bool = False) -> dict:
        """Verify all files against manifest.json

        Args:
            strict: If True, fail on any mismatch. If False, warn only.

        Returns:
            dict with verification results
        """
        if not self.manifest_path.exists():
            log("manifest.json not found, run --generate-manifest first", "WARNING")
            return {"status": "no_manifest", "issues": ["manifest.json not found"]}

        with open(self.manifest_path, 'r', encoding='utf-8') as f:
            manifest = json.load(f)

        # Check manifest watermark
        expected_wm = self._generate_watermark()
        stored_wm = manifest.get("watermark", "")
        wm_match = stored_wm == expected_wm

        if not wm_match:
            log(f"Manifest watermark mismatch! Stored={stored_wm}, Expected={expected_wm}", "ERROR")

        # Verify version consistency
        manifest_version = manifest.get("version", "")
        current_version = self.version
        version_match = manifest_version == current_version

        if not version_match:
            log(f"Version mismatch! Manifest={manifest_version}, Current={current_version}", "WARNING")

        # Verify each file listed in manifest directly against disk
        # (manifest is the source of truth, not collect_files which may skip valid files)
        issues = []
        verified = 0
        modified = []
        missing = []
        added = []

        stored_files = manifest.get("files", {})

        # Check manifest files against disk
        for relpath, info in stored_files.items():
            filepath = os.path.join(self.skill_dir, relpath)
            if os.path.exists(filepath):
                # Self-learning files are allowed to change at runtime
                if is_learning_file(relpath):
                    log(f"LEARNING_FILE: {relpath} (auto-protected, skip hash check)", "INFO")
                    verified += 1
                    continue
                current_hash = compute_file_hash(filepath)
                stored_hash = info.get("sha256", "")
                if current_hash != stored_hash:
                    modified.append(relpath)
                    issues.append(f"MODIFIED: {relpath}")
                    log(f"MODIFIED: {relpath}", "WARNING")
                else:
                    verified += 1
            else:
                missing.append(relpath)
                issues.append(f"MISSING: {relpath}")
                log(f"MISSING: {relpath}", "ERROR")

        # Detect untracked new files (not in manifest, not learning, not skipped)
        current_files = self.collect_files(include_learning=True)
        current_relpaths = set()
        for filepath in current_files:
            relpath = os.path.relpath(filepath, self.skill_dir).replace('\\', '/')
            current_relpaths.add(relpath)

        for relpath in current_relpaths:
            if relpath not in stored_files:
                if is_learning_file(relpath):
                    log(f"LEARNING_FILE: {relpath} (auto-protected)", "INFO")
                else:
                    added.append(relpath)
                    issues.append(f"ADDED: {relpath}")
                    log(f"ADDED: {relpath}", "WARNING")

        # Summary
        total = len(stored_files)
        status = "PASS" if not (modified or missing) else "FAIL"

        if status == "PASS":
            log(f"Integrity check PASSED: {verified}/{total} files verified", "OK")
            if added:
                log(f"  New files detected: {len(added)} (consider regenerating manifest)", "INFO")
        else:
            log(f"Integrity check FAILED: {len(modified)} modified, {len(missing)} missing", "ERROR")

        result = {
            "status": status,
            "watermark_match": wm_match,
            "version_match": version_match,
            "total_files": total,
            "verified": verified,
            "modified": modified,
            "missing": missing,
            "added": added,
            "issues": issues
        }

        return result

    def add_copyright_headers(self) -> dict:
        """Add copyright headers to all .py and .md files"""
        year = datetime.now().year
        results = {"updated": [], "skipped": [], "errors": []}

        for filepath in self.collect_files(include_learning=False):
            relpath = os.path.relpath(filepath, self.skill_dir).replace('\\', '/')

            if filepath.endswith('.py'):
                self._add_py_copyright(filepath, year, results)
            elif filepath.endswith('.md') and os.path.basename(filepath) != 'SKILL.md':
                self._add_md_copyright(filepath, year, results)
            elif filepath.endswith('.json'):
                self._add_json_watermark(filepath, results)

        log(f"Copyright headers: {len(results['updated'])} updated, "
            f"{len(results['skipped'])} skipped, {len(results['errors'])} errors", "OK")
        return results

    def _add_py_copyright(self, filepath: str, year: int, results: dict):
        """Add copyright header to a Python file"""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            # Skip if already has copyright
            if "WorkBuddy Skills" in content and "1817694478" in content:
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            # Skip manifest.json generation script itself
            if "integrity_guard" in filepath and "generate_manifest" in content:
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            header = COPYRIGHT_TEMPLATE.format(
                year=year, skill_name=self.skill_name, version=self.version
            )

            # Insert after shebang and encoding lines
            lines = content.split('\n')
            insert_pos = 0
            for i, line in enumerate(lines):
                if line.startswith('#!') or line.startswith('# -*- coding:'):
                    insert_pos = i + 1
                elif line.strip() == '' and insert_pos > 0:
                    continue
                else:
                    break

            # Check if there's a docstring right after
            if insert_pos < len(lines) and (lines[insert_pos].startswith('"""') or lines[insert_pos].startswith("'''")):
                # Find end of docstring
                quote = lines[insert_pos][:3]
                for j in range(insert_pos, len(lines)):
                    if j > insert_pos and quote in lines[j]:
                        insert_pos = j + 1
                        break

            lines.insert(insert_pos, header.rstrip())
            new_content = '\n'.join(lines)

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)

            results["updated"].append(os.path.relpath(filepath, self.skill_dir))
        except Exception as e:
            results["errors"].append(f"{os.path.relpath(filepath, self.skill_dir)}: {e}")

    def _add_md_copyright(self, filepath: str, year: int, results: dict):
        """Add copyright header to a Markdown file"""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            if "WorkBuddy Skills" in content and "1817694478" in content:
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            header = COPYRIGHT_TEMPLATE_MD.format(
                year=year, skill_name=self.skill_name, version=self.version
            )

            # Insert after frontmatter if present
            if content.startswith('---'):
                end = content.find('---', 3)
                if end > 0:
                    new_content = content[:end + 3] + '\n' + header + content[end + 3:]
                else:
                    new_content = header + content
            else:
                new_content = header + content

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)

            results["updated"].append(os.path.relpath(filepath, self.skill_dir))
        except Exception as e:
            results["errors"].append(f"{os.path.relpath(filepath, self.skill_dir)}: {e}")

    def _add_json_watermark(self, filepath: str, results: dict):
        """Add watermark to JSON data files"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not isinstance(data, dict):
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            # Skip manifest, learning files, and temp files
            basename = os.path.basename(filepath)
            if basename in [MANIFEST_FILENAME, "package.json"]:
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return
            
            if is_learning_file(filepath):
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            existing_wm = data.get(WATERMARK_FIELD, "")
            expected_wm = self._generate_watermark()

            if existing_wm == expected_wm:
                results["skipped"].append(os.path.relpath(filepath, self.skill_dir))
                return

            # Add watermark (non-intrusive, at the end)
            data[WATERMARK_FIELD] = expected_wm
            if "_wm_ver" not in data:
                data["_wm_ver"] = self.version

            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            results["updated"].append(os.path.relpath(filepath, self.skill_dir))
        except Exception as e:
            results["errors"].append(f"{os.path.relpath(filepath, self.skill_dir)}: {e}")

    def _generate_watermark(self) -> str:
        """Generate skill-specific watermark (deterministic from skill name + version)"""
        raw = f"WB_{self.skill_name}_{self.version}_2817694478"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def _verify_author_info(self) -> tuple:
        """Verify mandatory author info in source files

        Returns:
            (ok: bool, modified_files: list)
        """
        REQUIRED_MARKERS = ["1817694478", "972156177"]
        modified = []

        # Check key source files
        key_files = []
        for root, dirs, filenames in os.walk(self.skill_dir):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
            for fn in filenames:
                if fn.endswith('.py') or fn == 'SKILL.md':
                    filepath = os.path.join(root, fn)
                    if not should_skip(filepath):
                        key_files.append(filepath)

        for filepath in key_files[:10]:  # Check first 10 key files
            try:
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()

                # Skip if it's the integrity_guard itself
                if 'integrity_guard' in filepath:
                    continue

                # Check if copyright info exists and is intact
                has_copyright = "Copyright" in content or "1817694478" in content
                has_all_markers = all(marker in content for marker in REQUIRED_MARKERS)

                if has_copyright and not has_all_markers:
                    # Copyright exists but markers missing = tampered
                    modified.append(os.path.relpath(filepath, self.skill_dir))

            except Exception:
                continue

        return (len(modified) == 0, modified)

    def startup_check_with_message(self) -> tuple:
        """Enhanced startup check with user-friendly message

        Returns:
            (ok: bool, message: str)
        """
        # First check author info
        author_ok, modified_files = self._verify_author_info()
        if not author_ok:
            return (False, "文件损坏或遭到篡改，请从市场重新下载安装或更新版本！")

        # Then check manifest integrity
        if not self.manifest_path.exists():
            # No manifest - first run, just warn
            return (True, "")

        result = self.verify_integrity()

        if result["status"] == "FAIL":
            if result["modified"]:
                return (False, "文件损坏或遭到篡改，请从市场重新下载安装或更新版本！")
            if result["missing"]:
                return (False, "文件缺失，请从市场重新下载安装或更新版本！")

        if not result.get("watermark_match", True):
            return (False, "文件损坏或遭到篡改，请从市场重新下载安装或更新版本！")

        return (True, "")

    def startup_check(self) -> bool:
        """Quick integrity check to call at skill startup (legacy)

        Returns:
            True if integrity OK, False if tampering detected
        """
        ok, _ = self.startup_check_with_message()
        return ok

    def update_learning_file_hash(self, filepath: str) -> bool:
        """Update hash for a self-learning file in manifest
        
        This method is called automatically by the self-learning mechanism
        after modifying a learning file. It updates the integrity marker
        so the file remains protected against unauthorized modifications.
        
        Learning file hashes are stored in a separate "learning_files" section
        to distinguish them from core protected files.
        
        Args:
            filepath: Absolute or relative path to the learning file
            
        Returns:
            True if update successful, False otherwise
        """
        relpath = os.path.relpath(filepath, self.skill_dir).replace('\\', '/')
        
        # Verify this is a learning file
        if not is_learning_file(relpath):
            log(f"Not a learning file: {relpath}", "WARNING")
            return False
        
        # Check file exists
        if not os.path.exists(filepath):
            log(f"Learning file not found: {filepath}", "WARNING")
            return False
        
        # Load existing manifest
        if not self.manifest_path.exists():
            log("manifest.json not found, cannot update learning file hash", "WARNING")
            return False
            
        try:
            with open(self.manifest_path, 'r', encoding='utf-8') as f:
                manifest = json.load(f)
            
            # Ensure learning_files section exists
            if "learning_files" not in manifest:
                manifest["learning_files"] = {}
            
            # Compute new hash
            fhash = compute_file_hash(filepath)
            fsize = os.path.getsize(filepath)
            
            # Update or add entry in learning_files section
            manifest["learning_files"][relpath] = {
                "sha256": fhash,
                "size": fsize,
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Save manifest
            with open(self.manifest_path, 'w', encoding='utf-8') as f:
                json.dump(manifest, f, ensure_ascii=False, indent=2)
                
            log(f"Updated hash for learning file: {relpath}", "OK")
            return True
            
        except Exception as e:
            log(f"Failed to update learning file hash: {e}", "ERROR")
            return False

    def verify_learning_files(self) -> dict:
        """Verify integrity of learning files that have hash entries in manifest
        
        This method checks if learning files have been modified outside of
        the self-learning mechanism (i.e., not through the automatic update process).
        
        Returns:
            dict with verification results:
            {
                "status": "PASS" | "WARNING" | "no_manifest",
                "verified": int,      # number of files with matching hash
                "modified": list,     # files with hash mismatch (potential tampering)
                "missing": list       # files in manifest but not on disk
            }
        """
        if not self.manifest_path.exists():
            return {"status": "no_manifest", "verified": 0, "modified": [], "missing": []}
            
        with open(self.manifest_path, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
        
        learning_files = manifest.get("learning_files", {})
        verified = 0
        modified = []
        missing = []
        
        for relpath, info in learning_files.items():
            filepath = os.path.join(self.skill_dir, relpath)
            if os.path.exists(filepath):
                current_hash = compute_file_hash(filepath)
                stored_hash = info.get("sha256", "")
                
                if current_hash != stored_hash:
                    modified.append(relpath)
                    log(f"LEARNING_FILE_TAMPERED: {relpath} (hash mismatch)", "WARNING")
                else:
                    verified += 1
            else:
                missing.append(relpath)
                log(f"LEARNING_FILE_MISSING: {relpath}", "WARNING")
        
        status = "PASS" if not (modified or missing) else "WARNING"
        
        return {
            "status": status,
            "verified": verified,
            "modified": modified,
            "missing": missing
        }


# ============================================================
# CLI Interface
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="IntegrityGuard - Skill Anti-Tamper & Anti-Plagiarism")
    parser.add_argument("--verify-integrity", action="store_true", help="Verify all files against manifest")
    parser.add_argument("--generate-manifest", action="store_true", help="Generate/update manifest.json")
    parser.add_argument("--add-copyright", action="store_true", help="Add copyright headers to all files")
    parser.add_argument("--full-setup", action="store_true", help="Full setup: copyright + watermark + manifest")
    parser.add_argument("--skill-dir", type=str, required=True, help="Path to skill directory")
    parser.add_argument("--skill-name", type=str, default="", help="Override skill name")
    parser.add_argument("--strict", action="store_true", help="Strict mode: exit with error on any issue")
    args = parser.parse_args()

    guard = IntegrityGuard(skill_dir=args.skill_dir, skill_name=args.skill_name or None)

    if args.full_setup:
        log("=== Full Setup: Copyright + Watermark + Manifest ===", "INFO")
        cr = guard.add_copyright_headers()
        log(f"Copyright: {len(cr['updated'])} updated", "OK")
        mf = guard.save_manifest()
        log(f"Manifest: {mf}", "OK")
        vr = guard.verify_integrity()
        log(f"Verify: {vr['status']}", "OK" if vr['status'] == "PASS" else "WARNING")
        if args.strict and vr['status'] != 'PASS':
            sys.exit(1)
        return

    if args.generate_manifest:
        guard.save_manifest()
        return

    if args.add_copyright:
        guard.add_copyright_headers()
        return

    if args.verify_integrity:
        result = guard.verify_integrity()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.strict and result['status'] != 'PASS':
            sys.exit(1)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
