#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import json, os, sys
from datetime import datetime

LEVEL_CONFIG = [
    (0,    'Lv1', '新手影迷',   '刚刚踏入影视世界'),
    (20,   'Lv2', '初级影迷',   '开始有了自己的片单'),
    (50,   'Lv3', '资深影迷',   '看过的片子比大多数人多'),
    (100,  'Lv4', '电影达人',   '朋友圈里的影视顾问'),
    (200,  'Lv5', '资源猎人',   '总能找到别人找不到的'),
    (500,  'Lv6', '影视大师',   '半个行业都认识你'),
    (1000, 'Lv7', '传奇收藏家', '你的收藏堪称一座图书馆'),
    (2000, 'Lv8', '殿堂级影迷', '影视界的活百科全书'),
]

SCORE_RULES = {'search':1, 'contribute':3, 'daily_bonus':1}

class UserSystem:
    def __init__(self):
        self.data_file = os.path.join(os.path.dirname(__file__), '..', 'assets', 'user_data.json')
        self.data = self._load()

    def _load(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r', encoding='utf-8') as f: return json.load(f)
        return {'total_score':0,'search_count':0,'contribute_count':0,'history':[],'achievements':[],'last_search_date':None,'joined_at':datetime.now().strftime('%Y-%m-%d')}

    def _save(self):
        with open(self.data_file, 'w', encoding='utf-8') as f: json.dump(self.data, f, ensure_ascii=False, indent=2)

    def get_level_info(self, score=None):
        score = score or self.data['total_score']
        cur = LEVEL_CONFIG[0]
        nxt = LEVEL_CONFIG[1] if len(LEVEL_CONFIG)>1 else None
        for i,(ms,lv,tl,dc) in enumerate(LEVEL_CONFIG):
            if score>=ms: cur=(ms,lv,tl,dc); nxt=LEVEL_CONFIG[i+1] if i+1<len(LEVEL_CONFIG) else None
        return {'score':score,'min_score':cur[0],'level':cur[1],'title':cur[2],'desc':cur[3],'next_score':nxt[0] if nxt else None,'next_title':nxt[2] if nxt else None,'need_score':(nxt[0]-score) if nxt else 0,'is_max':nxt is None}

    def add_score(self, action_type, description=''):
        today = datetime.now().strftime('%Y-%m-%d')
        pts = SCORE_RULES.get(action_type, 0)
        bonus = 0
        if action_type=='search' and self.data.get('last_search_date')!=today:
            bonus = SCORE_RULES['daily_bonus']; pts+=bonus; self.data['last_search_date']=today
        old_score = self.data['total_score']
        self.data['total_score'] += pts
        if action_type=='search': self.data['search_count']+=1
        elif action_type=='contribute': self.data['contribute_count']+=1
        self.data['history'].append({'time':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'action':action_type,'points':pts,'bonus':bonus,'desc':description,'total':self.data['total_score']})
        self.data['history'] = self.data['history'][-50:]
        old_lv = self.get_level_info(old_score)
        new_lv = self.get_level_info()
        self._save()
        return {'points_added':pts,'bonus':bonus,'old_score':old_score,'new_score':self.data['total_score'],'level_up':old_lv['level']!=new_lv['level'],'old_level':old_lv,'new_level':new_lv}

    def get_status_text(self, result=None):
        info = self.get_level_info()
        lines = []
        sep = '----------------------------------------'
        if result:
            next_level_score = info['next_score'] if info['next_score'] else info['score']
            lines.append(sep)
            lines.append('  %s %s | +%d分(本次) | 当前%d分/%d分升级' % (
                info['level'], info['title'], result['points_added'], 
                result['new_score'], next_level_score
            ))
            lines.append('  搜索%d次 | 贡献%d次 | Q群+972156177分享更多...' % (
                self.data['search_count'], self.data['contribute_count']
            ))
            if result['level_up']:
                lines.append('  *** 恭喜升级: %s %s -> %s %s ***' % (result['old_level']['level'],result['old_level']['title'],result['new_level']['level'],result['new_level']['title']))
            lines.append(sep)
        else:
            lines.append(sep)
            if not info['is_max']: 
                lines.append('  %s %s | 当前%d分/%d分升级' % (
                    info['level'], info['title'], info['score'], info['next_score']
                ))
                lines.append('  搜索%d次 | 贡献%d次 | Q群+972156177分享更多...' % (
                    self.data['search_count'], self.data['contribute_count']
                ))
            else: 
                lines.append('  %s %s | %d分(已满级)' % (
                    info['level'], info['title'], info['score']
                ))
                lines.append('  搜索%d次 | 贡献%d次 | Q群+972156177分享更多...' % (
                    self.data['search_count'], self.data['contribute_count']
                ))
            lines.append(sep)
        return '\n'.join(lines)

def record_search():
    us=UserSystem(); return us.add_score('search')

def record_contribute(desc=''):
    us=UserSystem(); return us.add_score('contribute', desc)

if __name__=='__main__':
    if len(sys.argv)>1:
        cmd=sys.argv[1]
        if cmd=='status': us=UserSystem(); print(us.get_status_text())
        elif cmd=='search': r=record_search(); us=UserSystem(); print(us.get_status_text(r))
        elif cmd=='contribute': d=sys.argv[2] if len(sys.argv)>2 else ''; r=record_contribute(d); us=UserSystem(); print(us.get_status_text(r))
    else: us=UserSystem(); print(us.get_status_text())