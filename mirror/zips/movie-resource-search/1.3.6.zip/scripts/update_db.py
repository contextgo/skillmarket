#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys,io,json,re,os
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
sys.stderr=io.TextIOWrapper(sys.stderr.buffer,encoding='utf-8',errors='replace')
sys.path.insert(0,os.path.dirname(__file__))
from api_config import get_key as get_tmdb_api_key;from user_system import UserSystem
from db_codec import load_db,save_db
def log(m):print(re.sub(r'[\U00010000-\U0010ffff]','',str(m)),flush=True)
def load():return load_db()
def save(d):save_db(d)
def find_tmdb(name,typ='tv'):
    key=get_tmdb_api_key()
    if not key:log('[WARNING] API not configured');return None
    import urllib.request,urllib.parse
    t='tv'if typ in('tv','电视剧','国产剧','海外剧','美剧','韩剧','日剧','动画','综艺')else 'movie'
    url=f'https://api.themoviedb.org/3/search/{t}?api_key={key}&query={urllib.parse.quote(name)}&language=zh-CN'
    try:
        req=urllib.request.Request(url);r=urllib.request.urlopen(req,timeout=10);data=json.loads(r.read().decode())
        if data.get('results'):f=data['results'][0];return{'i':str(f.get('id','')),'y':str(f.get('first_air_date',f.get('release_date',''))[:4]if f.get('first_air_date')or f.get('release_date')else''),'c':typ,'r':str(f.get('vote_average','')),'d':f.get('overview','')}
    except Exception as e:log(f'[WARNING] TMDB query failed: {e}')
    return None
def add(name,url,code='',cloud='',typ=''):
    d=load();m=find_tmdb(name,typ)if typ else None
    item={'n':name,'l':[{'u':url,'a':code,'t':cloud or '云盘'}]}
    if m:item['m']=m
    d.append(item);save(d)
    us=UserSystem();r=us.add_score('contribute',name)
    log('[OK] Added: %s (%d total)'%(name,len(d)))
    log('[OK] Link: %s | Code: %s'%(url,code))
    if m:log('[OK] TMDB info fetched: %s'%json.dumps(m,ensure_ascii=False))
    for line in us.get_status_text(r).split('\n'):log(line)
if __name__=='__main__':
    if len(sys.argv)<3:log("Usage: python update_db.py add <name> <url> [code] [cloud] [type]");sys.exit(1)
    cmd=sys.argv[1]
    if cmd=='add':add(sys.argv[2],sys.argv[3],sys.argv[4]if len(sys.argv)>4 else '',sys.argv[5]if len(sys.argv)>5 else '',sys.argv[6]if len(sys.argv)>6 else '')