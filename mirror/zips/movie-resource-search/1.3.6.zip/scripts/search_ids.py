#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys,io,json,re,os
sys.path.insert(0,os.path.dirname(__file__))
# Integrity check on startup
try:
    _skill_dir=os.path.dirname(os.path.dirname(__file__))
    # integrity_guard.py can be in scripts/ (self-contained) or skills/ (shared)
    from integrity_guard import IntegrityGuard
    _guard=IntegrityGuard(_skill_dir)
    _ok,_msg=_guard.startup_check_with_message()
    if not _ok:print(f'[ERROR] {_msg}',flush=True);sys.exit(1)
except ImportError:pass
from user_system import UserSystem
from learn import LearnSystem
from db_codec import load_db
def log(m):print(re.sub(r'[\U00010000-\U0010ffff]','',str(m)),flush=True)
def kw(i):p=[str(i['n'])];p.extend([str(x)for x in i.get('g',[])]);m=i.get('m',{});m.get('c')and p.append(str(m['c']));m.get('y')and p.append(str(m['y']));return ' '.join(p).lower()
def load():return load_db()
def tokenize(s):
    # 按中文/英文/数字分词
    # 提取中文字符、英文单词、数字
    tokens = re.findall(r'[\u4e00-\u9fa5]+|[a-zA-Z]+|\d+', s.lower())
    return tokens
def _do_search(d, q_tokens, limit=10, seen_ids=None):
    """执行实际搜索，支持去重"""
    r = []
    seen_ids = seen_ids or set()
    for i in d:
        # 去重检查
        item_id = i.get('id') or i.get('n')
        if item_id in seen_ids:
            continue
        # 可搜索文本
        searchable = kw(i)
        # 资源分词
        i_tokens = tokenize(searchable)
        # 检查查询的每个词是否都能在资源中找到匹配
        match_count = 0
        for qt in q_tokens:
            # 模糊匹配：token相等，或token包含查询词，或查询词包含token
            for it in i_tokens:
                if qt == it or qt in it or it in qt:
                    match_count += 1
                    break
        # 所有查询词都匹配才算命中
        if match_count >= len(q_tokens):
            r.append(i)
            seen_ids.add(item_id)
        if len(r) >= limit:
            break
    return r, seen_ids
def search(d, q, ls=None, limit=10):
    if not q.strip():
        return [], []
    q_tokens = tokenize(q)
    # 1. 直接搜索
    r, seen_ids = _do_search(d, q_tokens, limit)
    expanded_from = []
    # 2. 如果结果不足且有关联词，扩展搜索
    if len(r) < limit and ls:
        related = ls.get_related_kws(q)
        # 过滤出高质量的关联词（中文词长度>=2，排除符号碎片）
        quality_related = []
        for rel_kw in related:
            # 提取有效中文词
            cn_words = re.findall(r'[\u4e00-\u9fa5]{2,}', rel_kw)
            if cn_words:
                quality_related.append(rel_kw)
        for rel_kw in quality_related:
            if len(r) >= limit:
                break
            if rel_kw == q.lower().strip():
                continue
            rel_tokens = tokenize(rel_kw)
            rel_results, seen_ids = _do_search(d, rel_tokens, limit - len(r), seen_ids)
            if rel_results:
                expanded_from.append((rel_kw, len(rel_results)))
                r.extend(rel_results)
    return r, expanded_from
def fmt(idx,i,dead_urls):
    L=[f'{idx}. {i["n"]}'];m=i.get('m',{});info=[]
    m.get('y')and info.append(f'年份:{m["y"]}');m.get('c')and info.append(f'类型:{m["c"]}')
    g=i.get('g',[]);g and info.append(f'标签:{"|".join(g)}')
    info and L.append(f"   {' | '.join(info)}");L.append('')
    links=i['l'][:3];total=len(links)
    for li,l in enumerate(links,1):
        prefix=f'[{li}/{total}]'if total>1 else''
        if l['u'] in dead_urls:
            L.append(f'   [{l.get("t","云盘")}]{prefix}');L.append(f'       {l["u"]} (已失效，可联系作者或自行更新)');L.append('')
        else:
            L.append(f'   [{l.get("t","云盘")}]{prefix}');L.append(f'       {l["u"]}')
            l.get('a')and L.append(f'       访问码: {l["a"]}');L.append('')
    return '\n'.join(L)
def main():
    if len(sys.argv)<2:log("Usage: python search_ids.py <keyword>");sys.exit(1)
    q=' '.join(sys.argv[1:]);us=UserSystem();ls=LearnSystem()
    r=us.add_score('search',q);d=load();res,expanded_from=search(d,q,ls)
    ls.learn_from_result(q,res)
    log('========================================');log('')
    if not res:
        log(f'未找到 "{q}" 相关资源');log('');log('提示: 试试更简单的关键词，如 国产剧、美剧、4K、2025')
        sug=ls.get_search_suggestions()
        if sug:log('');log('热门搜索: '+' | '.join(sug))
    else:
        if expanded_from:
            log(f'找到 {len(res)} 条相关资源 (关键词: {q}) [算法已优化]')
        else:
            log(f'找到 {len(res)} 条相关资源 (关键词: {q})')
        log('');log('========================================');log('')
    dead_urls=set(ls.data.get('dead_links',{}).keys())
    for idx,i in enumerate(res,1):log(fmt(idx,i,dead_urls))
    for line in us.get_status_text(r).split('\n'):log(line)
    log('');log('更新或补充：发送"资源名称+资源链接"即可入库');log('有问题、建议、需求可联系作者QQ：1817694478；加Q群：972156177交流分享更多...');log('')
if __name__=='__main__':main()