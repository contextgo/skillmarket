#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import json, os, sys
from datetime import datetime

DF = os.path.join(os.path.dirname(__file__), '..', 'assets', 'user_data.json')

if os.path.exists(DF):
    d = json.load(open(DF,'r',encoding='utf-8'))
    print(f"已存在 | 积分:{d.get('total_score',0)} | 搜索:{d.get('search_count',0)}次 | 贡献:{d.get('contribute_count',0)}次")
else:
    json.dump({'total_score':0,'search_count':0,'contribute_count':0,'history':[],'achievements':[],'last_search_date':None,'joined_at':datetime.now().strftime('%Y-%m-%d')}, open(DF,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
    print("用户数据已创建 | Lv1 新手影迷")