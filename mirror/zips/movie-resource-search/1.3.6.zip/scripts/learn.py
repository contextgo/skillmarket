#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import json,os,sys,re
from datetime import datetime
from collections import defaultdict

LF=os.path.join(os.path.dirname(__file__),'..','assets','learn_data_v2.json')
DB=os.path.join(os.path.dirname(__file__),'..','assets','movie_db.json')

class LearnSystem:
    def __init__(self):
        self.data=self._load()

    def _load(self):
        if os.path.exists(LF):
            try:
                with open(LF,'r',encoding='utf-8')as f:return json.load(f)
            except:pass
        return{'search_stats':{},'kw_map':{},'hot_items':{},'dead_links':{},'last_clean':None,'version':'1.0'}

    def _save(self):
        with open(LF,'w',encoding='utf-8')as f:
            json.dump(self.data,f,ensure_ascii=False,separators=(',',':'))
            f.flush()

    def record_search(self,keyword,hit_count):
        k=keyword.lower().strip()
        if k not in self.data['search_stats']:
            self.data['search_stats'][k]={'count':0,'hits':0,'first':datetime.now().strftime('%Y-%m-%d'),'last':''}
        s=self.data['search_stats'][k]
        s['count']+=1;s['hits']+=hit_count;s['last']=datetime.now().strftime('%Y-%m-%d %H:%M')
        self._save()

    def learn_kw_map(self,src,dst):
        s=src.lower().strip();d=dst.lower().strip()
        if s==d:return
        if s not in self.data['kw_map']:self.data['kw_map'][s]=[]
        if d not in self.data['kw_map'][s]:self.data['kw_map'][s].append(d)
        if d not in self.data['kw_map']:self.data['kw_map'][d]=[]
        if s not in self.data['kw_map'][d]:self.data['kw_map'][d].append(s)
        self._save()

    def record_hot(self,item_name):
        n=item_name.strip()
        if n not in self.data['hot_items']:self.data['hot_items'][n]={'count':0,'first':''}
        h=self.data['hot_items'][n];h['count']+=1
        if not h['first']:h['first']=datetime.now().strftime('%Y-%m-%d')
        h['last']=datetime.now().strftime('%Y-%m-%d %H:%M')
        self._save()

    def record_dead_link(self,url,reason=''):
        u=url.strip()
        self.data['dead_links'][u]={'time':datetime.now().strftime('%Y-%m-%d %H:%M'),'reason':reason}
        self._save()

    def get_related_kws(self,keyword):
        k=keyword.lower().strip()
        related=[k]
        if k in self.data['kw_map']:
            for m in self.data['kw_map'][k]:related.append(m)
        for mk,mvs in self.data['kw_map'].items():
            if k in mvs and mk not in related:related.append(mk)
        return related

    def get_hot_boost(self,items,top_n=5):
        hot_names=set()
        sorted_hot=sorted(self.data['hot_items'].items(),key=lambda x:x[1].get('count',0),reverse=True)
        for name,_ in sorted_hot[:top_n]:hot_names.add(name)
        boosted=[]
        normal=[]
        for i in items:
            if i['n'] in hot_names:boosted.append(i)
            else:normal.append(i)
        return boosted+normal

    def get_search_suggestions(self,keyword=''):
        k=keyword.lower().strip()if keyword else''
        suggestions=[]
        for sk,sv in sorted(self.data['search_stats'].items(),key=lambda x:x[1].get('hits',0),reverse=True)[:5]:
            suggestions.append(sk)
        if k and k in self.data['kw_map']:
            for m in self.data['kw_map'][k][:3]:suggestions.append(m)
        return suggestions[:5]

    def auto_clean(self):
        now=datetime.now().strftime('%Y-%m-%d')
        if self.data.get('last_clean')==now:return False
        self.data['search_stats']=dict(sorted(self.data['search_stats'].items(),key=lambda x:x[1].get('count',0),reverse=True)[:200])
        self.data['hot_items']=dict(sorted(self.data['hot_items'].items(),key=lambda x:x[1].get('count',0),reverse=True)[:100])
        self.data['kw_map']=dict((k,v[:10])for k,v in self.data['kw_map'].items()if len(v)>0)
        self.data['last_clean']=now
        self._save()
        return True

    def learn_from_result(self,keyword,results):
        k=keyword.lower().strip()
        self.record_search(keyword,len(results))
        if results:
            top=results[0]
            self.record_hot(top['n'])
            nm=top['n'].lower()
            for part in nm.split():
                if len(part)>=2 and part!=k:self.learn_kw_map(k,part)
            m=top.get('m',{})
            if m.get('c'):self.learn_kw_map(k,m['c'].lower())
            g=top.get('g',[])
            for tg in g:self.learn_kw_map(k,tg.lower())
        else:
            self.record_search(keyword,0)
        self.auto_clean()

if __name__=='__main__':
    ls=LearnSystem()
    cmd=sys.argv[1]if len(sys.argv)>1 else'stats'
    if cmd=='stats':
        print('Search stats: %d keywords'%len(ls.data['search_stats']))
        print('KW map: %d mappings'%len(ls.data['kw_map']))
        print('Hot items: %d tracked'%len(ls.data['hot_items']))
        print('Dead links: %d reported'%len(ls.data['dead_links']))
    elif cmd=='suggest':
        kw=sys.argv[2]if len(sys.argv)>2 else''
        for s in ls.get_search_suggestions(kw):print(s)
    elif cmd=='related':
        kw=sys.argv[2]if len(sys.argv)>2 else''
        for r in ls.get_related_kws(kw):print(r)