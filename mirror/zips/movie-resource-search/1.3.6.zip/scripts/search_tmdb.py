#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: movie-resource-search | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, os, requests, json, re
sys.path.insert(0, os.path.dirname(__file__))
from api_config import get_tmdb_api_key

def log(msg):
    print(re.sub(r'[\U00010000-\U0010ffff]', '', str(msg)), flush=True)

def search_tmdb(query, media_type=None):
    api_key = get_tmdb_api_key()
    if not api_key: log("[ERROR] API未配置"); return []
    base = "https://api.themoviedb.org/3"
    try:
        url = f"{base}/search/multi"
        if media_type in ['movie','tv']: url = f"{base}/search/{media_type}"
        params = {'api_key':api_key,'query':query,'language':'zh-CN','include_adult':'false'}
        r = requests.get(url, params=params, timeout=10)
        r.raise_for_status()
        d = r.json().get('results', [])
        fmt = []
        for item in d[:5]:
            mt = item.get('media_type','unknown')
            if mt=='movie': title=item.get('title',''); orig=item.get('original_title',''); yr=item.get('release_date','')[:4]; tp='电影'
            elif mt=='tv': title=item.get('name',''); orig=item.get('original_name',''); yr=item.get('first_air_date','')[:4]; tp='电视剧'
            else: continue
            fmt.append({'id':item.get('id'),'title':title,'original_title':orig,'year':yr,'type':tp,'media_type':mt,'overview':item.get('overview','')[:100]+'...' if item.get('overview') else '','poster_path':item.get('poster_path',''),'vote_average':item.get('vote_average',0),'popularity':item.get('popularity',0)})
        return fmt
    except requests.exceptions.Timeout: log("请求超时"); return []
    except Exception as e: log(f"请求错误: {e}"); return []

def get_details(tmdb_id, media_type):
    api_key = get_tmdb_api_key()
    if not api_key: return None
    try:
        url = f"https://api.themoviedb.org/3/{media_type}/{tmdb_id}"
        r = requests.get(url, params={'api_key':api_key,'language':'zh-CN'}, timeout=10)
        r.raise_for_status(); d = r.json()
        return {'id':d.get('id'),'title':d.get('title') or d.get('name',''),'original_title':d.get('original_title') or d.get('original_name',''),'year':str(d.get('release_date','')[:4]) if d.get('release_date') else str(d.get('first_air_date','')[:4]) if d.get('first_air_date') else '','type':'电影' if media_type=='movie' else '电视剧','overview':d.get('overview',''),'poster_path':d.get('poster_path',''),'vote_average':d.get('vote_average',0),'genres':[g.get('name','') for g in d.get('genres',[])]}
    except Exception as e: log(f"获取详情失败: {e}"); return None

def display_results(results):
    if not results: log("未找到"); return
    log(""); log("=== TMDB 搜索结果 ==="); log("")
    for i,item in enumerate(results,1):
        log(f"{i}. {item['title']}")
        if item['original_title'] and item['original_title']!=item['title']: log(f"   原名: {item['original_title']}")
        log(f"   类型:{item['type']} | 年份:{item['year']} | 评分:{item['vote_average']}")
        log(f"   TMDB ID: {item['id']} ({item['media_type']})"); log("")

def main():
    if len(sys.argv)<2: log("Usage: python search_tmdb.py <keyword> [movie|tv]"); sys.exit(1)
    q = ' '.join(sys.argv[1:])
    mt = None
    if q.endswith(' movie'): mt='movie'; q=q[:-6]
    elif q.endswith(' tv'): mt='tv'; q=q[:-3]
    if not get_tmdb_api_key(): log("[ERROR] 未配置"); sys.exit(1)
    log(f"正在搜索: {q}")
    display_results(search_tmdb(q, mt))

if __name__=='__main__': main()