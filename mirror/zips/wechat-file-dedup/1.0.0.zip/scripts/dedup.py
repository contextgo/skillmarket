# -*- coding: utf-8 -*-
import os, re, sys
from datetime import datetime

# Windows 控制台 UTF-8 支持
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def get_file_key(filename):
    """提取文件名基准（去除末尾的 (N) / （1） 后缀后返回规范化名称）"""
    _, orig_ext = os.path.splitext(filename)
    if not orig_ext:
        return filename
    basename = filename[:-len(orig_ext)] if orig_ext else filename
    base = re.sub(r'\s*[（(]\d+[）)]\s*', '', basename)
    return base + orig_ext

def scan_duplicates(directory):
    """扫描目录中的重复文件组"""
    files = []
    for f in os.listdir(directory):
        full_path = os.path.join(directory, f)
        if os.path.isfile(full_path):
            stat = os.stat(full_path)
            files.append({
                'name': f,
                'path': full_path,
                'size': stat.st_size,
                'mtime': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M')
            })

    groups = {}
    for f in files:
        key = (get_file_key(f['name']), f['size'])
        if key not in groups:
            groups[key] = []
        groups[key].append(f)

    duplicates = {k: v for k, v in groups.items() if len(v) >= 2}
    return duplicates

def rename_to_base(name):
    """移除末尾所有 (N) / （数字） 后缀，保留基础文件名"""
    _, orig_ext = os.path.splitext(name)
    basename = name[:-len(orig_ext)] if orig_ext else name
    base = re.sub(r'\s*[（(]\d+[）)]\s*', '', basename)
    prev = None
    while prev != base:
        prev = base
        base = re.sub(r'\s*[（(]\d+[）)]\s*', '', base)
    return base + orig_ext

# --- 主流程 ---
if len(sys.argv) < 2:
    print("用法: python dedup.py <目录路径>")
    sys.exit(1)

target_dir = sys.argv[1]
if not os.path.isdir(target_dir):
    print(f"错误: {target_dir} 不是有效的目录")
    sys.exit(1)

duplicates = scan_duplicates(target_dir)

if not duplicates:
    print("✅ 未检测到重复文件，无需清理。")
    sys.exit(0)

# 打印预览报告
total_files_to_remove = sum(len(v) - 1 for v in duplicates.values())
total_size_free = sum(
    sum(f['size'] for f in v[1:])
    for k, v in duplicates.items()
)

total_scanned = sum(len(v) for v in duplicates.values())
print(f"\n📁 目录: {target_dir}")
print(f"🔍 发现 {len(duplicates)} 组重复文件（共涉及 {total_files_to_remove + len(duplicates)} 个副本）")

for i, (key, group) in enumerate(sorted(duplicates.items()), 1):
    group.sort(key=lambda f: f['mtime'], reverse=True)
    kept = group[0]
    to_remove = group[1:]

    base_name = os.path.basename(kept['name']) if '(' not in kept['name'] else rename_to_base(kept['name'])
    print(f"\n{i}. {base_name} (共 {len(group)} 个副本)")

    for f in [kept] + to_remove:
        is_kept = f == kept
        action = '✅ 保留' if is_kept else '🗑️ 删除'
        print(f"   {action}: {f['name']:40s} | {f['size'] / (1024*1024):.1f} MB | 修改时间: {f['mtime']}")

print(f"\n--- 统计 ---")
print(f"📦 将清理的文件数: {total_files_to_remove}")
print(f"💾 预计释放空间: {total_size_free / (1024*1024):.1f} MB")

# 执行删除 + 重命名
confirmed = input("\n是否确认执行？(y/n): ").strip().lower()
if confirmed != 'y':
    print("已取消操作。")
    sys.exit(0)

# 修复：先删除重复文件，再重命名保留文件
deleted_count = 0
failed_delete_count = 0
renamed_count = 0
failed_rename_count = 0

for key, group in duplicates.items():
    group.sort(key=lambda f: f['mtime'], reverse=True)
    kept = group[0]
    to_remove = group[1:]

    # 第一步：先删除重复文件
    for f in to_remove:
        if not os.path.exists(f['path']):
            print(f"⚠️ 跳过已不存在的文件: {f['name']}")
            continue
        try:
            os.remove(f['path'])
            print(f"🗑️ 已删除: {f['name']}")
            deleted_count += 1
        except PermissionError:
            print(f"❌ 权限不足，无法删除: {f['name']}")
            failed_delete_count += 1
        except Exception as e:
            print(f"❌ 删除失败: {f['name']} - {e}")
            failed_delete_count += 1

    # 第二步：重命名保留文件（此时目标文件名应该已释放）
    old_name = os.path.basename(kept['path'])
    new_name = rename_to_base(old_name)
    old_path = kept['path']

    if old_name != new_name:
        target_path = os.path.join(os.path.dirname(old_path), new_name)
        try:
            # 如果目标文件仍然存在（删除失败），尝试带后缀的重命名
            if os.path.exists(target_path):
                base, ext = os.path.splitext(new_name)
                counter = 1
                while os.path.exists(target_path):
                    target_path = os.path.join(os.path.dirname(old_path), f"{base} ({counter}){ext}")
                    counter += 1
                print(f"⚠️ 目标文件仍存在，重命名为: {os.path.basename(target_path)}")
            os.rename(old_path, target_path)
            print(f"✅ 已重命名: {old_name} → {os.path.basename(target_path)}")
            renamed_count += 1
        except PermissionError:
            print(f"❌ 权限不足，无法重命名: {old_name}")
            failed_rename_count += 1
        except Exception as e:
            print(f"❌ 重命名失败: {old_name} - {e}")
            failed_rename_count += 1

print(f"\n--- 执行结果 ---")
print(f"🗑️ 成功删除: {deleted_count} 个文件")
if failed_delete_count:
    print(f"❌ 删除失败: {failed_delete_count} 个文件（权限不足）")
print(f"✅ 成功重命名: {renamed_count} 个文件")
if failed_rename_count:
    print(f"❌ 重命名失败: {failed_rename_count} 个文件（权限不足）")

if failed_delete_count or failed_rename_count:
    print("\n⚠️ 部分操作失败，建议关闭微信后重试。")
else:
    print("\n✅ 清理完成！")
