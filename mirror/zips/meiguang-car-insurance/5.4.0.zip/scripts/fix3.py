#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Trace parse_pdf routing for 亚太交强."""
import sys, os, re, fitz
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
from run_extract import route_company, route_type, clean_data, parse_jiaoqiang, parse_shangye, parse_dadi_anyang

folder = r"C:\Users\Administrator\Desktop\车险保单"

for fn in os.listdir(folder):
    if "交强" in fn and "F0QE80" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        
        company = route_company(text)
        rt = route_type(text)
        print(f"=== {fn[:30]} ===")
        print(f"  company: {company}")
        print(f"  route_type: {rt}")
        
        # Try direct parse
        result = parse_jiaoqiang(text, company, path)
        print(f"  parse_jiaoqiang:")
        for k in ["签单时间", "保单号", "被保人姓名", "实收保费"]:
            print(f"    {k}: [{result.get(k, '')}]")
        
        # Try clean_data
        result2 = clean_data(result, text, path)
        print(f"  after clean_data:")
        for k in ["签单时间", "保单号", "被保人姓名", "实收保费"]:
            print(f"    {k}: [{result2.get(k, '')}]")
        break

print()

# Trace 大地意外险 routing
for fn in os.listdir(folder):
    if "意外" in fn and "FCS899" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        pymupdf_text = doc[0].get_text()
        
        import pdfplumber
        plumber_text = ""
        try:
            with pdfplumber.open(path) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t: plumber_text += t + "\n"
        except: pass
        
        combined = pymupdf_text
        company = route_company(combined)
        rt = route_type(combined)
        print(f"=== {fn[:30]} ===")
        print(f"  company: {company}")
        print(f"  route_type: {rt}")
        print(f"  has PDDA: {bool(re.search(r'PDDA\\d+', combined))}")
        print(f"  has 大地: {'大地' in combined}")
        print(f"  has 63706700: {bool(re.search(r'63706700', combined))}")
        
        # Check if dadi routing would trigger
        has_dadi_route = ("大地" in combined and ("安行如意保" in combined or "团体意外" in combined)) or \
                        (re.search(r"63706700\d{10,}", combined) and rt == "驾乘险") or \
                        re.search(r"237067006B\d{10,}", combined)
        print(f"  dadi route match: {has_dadi_route}")
        
        result = parse_dadi_anyang(pymupdf_text, plumber_text)
        print(f"  parse_dadi_anyang:")
        for k in ["签单时间", "保单号", "保险起期", "被保人姓名", "车架号"]:
            print(f"    {k}: [{result.get(k, '')}]")
        break
