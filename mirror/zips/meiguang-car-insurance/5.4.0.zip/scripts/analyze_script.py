# -*- coding: utf-8 -*-
"""Analyze run_extract.py for issues."""
import re, sys
from collections import Counter

SCRIPT = r'C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts\run_extract.py'

with open(SCRIPT, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Syntax check
import py_compile
try:
    py_compile.compile(SCRIPT, doraise=True)
    print('1. Syntax OK')
except py_compile.PyCompileError as e:
    print(f'1. SYNTAX ERROR: {e}')

# 2. Duplicate function definitions
func_defs = re.findall(r'def (\w+)\(', content)
dupes = {name: count for name, count in Counter(func_defs).items() if count > 1}
if dupes:
    print(f'2. Duplicate function defs: {dupes}')
else:
    print('2. No duplicate function defs')

# 3. Dead code: return False followed by return False
dead_code = re.findall(r'return False\s*\n\s*return False', content)
print(f'3. Dead code (return False x2): {len(dead_code)} occurrences')

# 4. NATURE_LIST duplicates
nature_match = re.search(r'NATURE_LIST\s*=\s*\[(.*?)\]', content, re.DOTALL)
if nature_match:
    items = re.findall(r'"([^"]+)"', nature_match.group(1))
    nd = {k: v for k, v in Counter(items).items() if v > 1}
    if nd:
        print(f'4. NATURE_LIST duplicates: {nd}')
    else:
        print('4. NATURE_LIST no duplicates')

# 5. import fitz inside functions
fitz_positions = [i+1 for i, line in enumerate(content.split('\n')) if 'import fitz' in line]
print(f'5. import fitz at lines: {fitz_positions}')

# 6. Bare except count
bare = len(re.findall(r'except\s*:', content))
print(f'6. Bare except: {bare}')

# 7. chinese_num defined multiple times
cn_defs = [(i+1, line.strip()) for i, line in enumerate(content.split('\n')) if 'def chinese_num' in line]
print(f'7. chinese_num defs: {cn_defs}')

# 8. Check file size
lines = content.count('\n')
print(f'8. Total lines: {lines}')

# 9. Check for potential regex issues
# Patterns with unescaped special chars
print('9. Analysis complete')
