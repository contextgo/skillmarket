# -*- coding: utf-8 -*-
"""Fix issues in run_extract.py."""
import re

path = r'C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts\run_extract.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix 1: Remove dead code (return False followed by return False)
content = content.replace('return False\n        return False', 'return False')
print(f'Fix 1: dead code removed')

# Fix 2: Remove duplicate is_valid_insured_name
parts = content.split('def is_valid_insured_name(v):')
if len(parts) == 3:
    content = parts[0] + 'def is_valid_insured_name(v):' + parts[1] + 'def is_valid_insured_name(v):' + parts[2]
    print('Fix 2: duplicate is_valid_insured_name removed')
else:
    print(f'Fix 2: found {len(parts)-1} definitions (expected 2)')

# Fix 3: Move import fitz to top
first_def = content.find('\ndef ')
header = content[:first_def]
if 'import fitz' not in header:
    content = content.replace('import re, os, sys\n', 'import re, os, sys\nimport fitz\n')
    print('Fix 3: import fitz moved to top')
else:
    print('Fix 3: import fitz already at top')

# Fix 4: Deduplicate NATURE_LIST
nature_match = re.search(r'NATURE_LIST\s*=\s*\[([^\]]+)\]', content, re.DOTALL)
if nature_match:
    items_str = nature_match.group(1)
    items = re.findall(r'"([^"]+)"', items_str)
    seen = set()
    unique = []
    for item in items:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    removed = len(items) - len(unique)
    new_list_str = ',\n    '.join(f'"{item}"' for item in unique)
    new_block = f'NATURE_LIST = [\n    {new_list_str},\n]'
    content = content[:nature_match.start()] + new_block + content[nature_match.end():]
    print(f'Fix 4: removed {removed} duplicate NATURE_LIST entries')
else:
    print('Fix 4: NATURE_LIST not found')

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)
print('All fixes applied!')
