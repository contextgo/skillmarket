# -*- coding: utf-8 -*-
"""Fix remaining issues in run_extract.py."""
import re

path = r'C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts\run_extract.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix 1: Remove duplicate is_valid_insured_name (keep only the second one - it has more thorough checks)
# Split by the function definition
parts = re.split(r'(?=def is_valid_insured_name\(v\):)', content)
if len(parts) == 3:
    # parts[0] = before first def
    # parts[1] = first def body (up to second def)
    # parts[2] = second def body (to end)
    # Keep parts[0] + parts[2] (second definition)
    content = parts[0] + parts[2]
    print('Fix 1: Removed first duplicate is_valid_insured_name')
elif len(parts) == 2:
    print('Fix 1: Only one definition found, skipping')
else:
    print(f'Fix 1: Found {len(parts)-1} definitions, unexpected')

# Fix 2: Remove 'import fitz' from inside functions (keep only top-level)
# Find all import fitz lines
lines = content.split('\n')
new_lines = []
removed = 0
for i, line in enumerate(lines):
    stripped = line.strip()
    if stripped == 'import fitz' and i > 10:  # Skip top-level import
        # Check if it's inside a function (indented)
        if line.startswith(' ') or line.startswith('\t'):
            removed += 1
            continue  # Skip this line
    new_lines.append(line)
content = '\n'.join(new_lines)
print(f'Fix 2: Removed {removed} function-level import fitz')

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)
print('Done!')
