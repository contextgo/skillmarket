#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Add tracing to parse_pdf to see what's happening."""
import sys, os, re, fitz
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")

# Monkey-patch parse_jiaoqiang to add trace
import run_extract
_orig_jq = run_extract.parse_jiaoqiang
def traced_jq(text, company="unknown", pdf_path=None):
    result = _orig_jq(text, company, pdf_path)
    fname = os.path.basename(pdf_path or "")
    if "F0QE80" in fname and "交强" in fname:
        print(f"  [TRACE] parse_jiaoqiang called for {fname[:30]}")
        print(f"    text len={len(text)}, company={company}")
        print(f"    保单号=[{result.get('保单号','')}]")
        print(f"    签单时间=[{result.get('签单时间','')}]")
    return result
run_extract.parse_jiaoqiang = traced_jq

_orig_sy = run_extract.parse_shangye
def traced_sy(text, company="unknown", pdf_path=None):
    result = _orig_sy(text, company, pdf_path)
    fname = os.path.basename(pdf_path or "")
    if "F0QE80" in fname and "商业" in fname:
        print(f"  [TRACE] parse_shangye called for {fname[:30]}")
        print(f"    text len={len(text)}, company={company}")
        print(f"    保单号=[{result.get('保单号','')}]")
    return result
run_extract.parse_shangye = traced_sy

from run_extract import parse_pdf

folder = r"C:\Users\Administrator\Desktop\车险保单"
for fn in os.listdir(folder):
    if "交强" in fn and "F0QE80" in fn:
        path = os.path.join(folder, fn)
        print(f"=== parse_pdf({fn[:30]}) ===")
        result = parse_pdf(path)
        print(f"  FINAL: 保单号=[{result.get('保单号','')}] 签单时间=[{result.get('签单时间','')}]")
        break
