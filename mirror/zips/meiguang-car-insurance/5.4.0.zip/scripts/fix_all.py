#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Debug all remaining empty fields."""
import sys, os, re, fitz
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
from run_extract import parse_pdf

folder = r"C:\Users\Administrator\Desktop\车险保单"

# Test ALL problematic files
targets = [
    # 亚太交强 (sign_date, policy, name, premium)
    ("交强", "F0QE80"), ("交强", "F8CD70"), ("交强", "FC268X"), ("交强", "Y27V08"),
    # 亚太商业 (policy, premium)
    ("商业", "F0QE80"), ("商业", "F8CD70"), ("商业", "FC268X"), ("商业", "Y27V08"),
    # 大地意外险
    ("意外", None),
    # 大地交强 (VIN)
    ("交强", "FCS899"), ("交强", "FH690S"), ("交强", "FW121M"), ("交强", "Y7A308"), ("交强", "Y97661"),
]

for kw1, kw2 in targets:
    for fn in os.listdir(folder):
        if kw1 in fn and (kw2 is None or kw2 in fn):
            path = os.path.join(folder, fn)
            result = parse_pdf(path)
            
            # Check empty fields
            empties = []
            for k in ["签单时间", "保单号", "保险起期", "被保人姓名", "实收保费", "车架号"]:
                v = result.get(k, "")
                if not v:
                    empties.append(k)
            
            if empties:
                print(f"=== {fn[:40]} ===")
                for k in empties:
                    print(f"  {k}: EMPTY")
                
                # Debug: show what's in the PDF text
                doc = fitz.open(path)
                text = doc[0].get_text()
                
                if "保单号" in empties:
                    # Find all policy number candidates
                    pnums = re.findall(r"[A-Z0-9]{15,}", text)
                    for m in re.finditer("保单", text):
                        s = max(0, m.start()-3)
                        e = min(len(text), m.end()+30)
                        print(f"   保单ctx: {text[s:e][:80]}")
                    print(f"   okens: {pnums[:5]}")
                
                if "签单时间" in empties:
                    dates = re.findall(r"(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})", text)
                    print(f"   ates: {dates}")
                
                if "保险起期" in empties:
                    for m in re.finditer("保险期间", text):
                        s = max(0, m.start()-3)
                        e = min(len(text), m.end()+80)
                        print(f"    period ctx: {text[s:e][:100]}")
                
                if "车架号" in empties:
                    for m in re.finditer("车架|VIN|识别代码", text):
                        s = max(0, m.start()-3)
                        e = min(len(text), m.end()+40)
                        print(f"    VIN ctx: {text[s:e][:80]}")
                    vins = re.findall(r"[A-HJ-NPR-Z0-9]{17}", text)
                    print(f"    17-char: {vins[:5]}")
                
                print()
            break
