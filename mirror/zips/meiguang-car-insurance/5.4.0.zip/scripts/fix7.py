#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys, os, re, fitz
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
from run_extract import parse_pdf, route_type, route_company, parse_jiaoqiang

path = r"C:\Users\Administrator\Desktop\车险保单\鲁F0QE80-交强险(1).pdf"
doc = fitz.open(path)
text = doc[0].get_text()

print(f"text_len={len(text)}")
company = route_company(text)
rt = route_type(text)
print(f"company={company}, rt={rt}")
print(f"TAIPING={'TAIPING' in text}")
print(f"大地={'大地' in text}")
print(f"太平洋={'太平洋' in text}")
print(f"PAIC={'PAIC' in text}")
print(f"RMB={'RMB' in text}")

# Direct call
result = parse_jiaoqiang(text, company, path)
print(f"\nDirect parse_jiaoqiang:")
print(f" 保单号=[{result.get('保单号','')}]")
print(f" 签单=[{result.get('签单时间','')}]")

# Via parse_pdf
result2 = parse_pdf(path)
print(f"\nparse_pdf result:")
print(f" 保单号=[{result2.get('保单号','')}]")
print(f" 签单=[{result2.get('签单时间','')}]")
