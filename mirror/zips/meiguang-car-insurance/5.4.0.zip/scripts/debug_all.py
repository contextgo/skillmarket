#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deep debug: check all problematic PDFs for 保单号/保险起期/被保人姓名."""
import fitz, os, re

folder = r"C:\Users\Administrator\Desktop\车险保单"

# 1. 亚太交强险 - check 保单号 and 签单时间
print("=" * 60)
print("1. 亚太交强险 (保单号 + 签单时间)")
print("=" * 60)
for fn in os.listdir(folder):
    if "交强" in fn and ("F0QE80" in fn or "F8CD70" in fn or "FC268X" in fn or "Y27V08" in fn):
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        # Policy number
        p_all = re.findall(r"[A-Z0-9]{15,}", text)
        # Date
        dates = re.findall(r"(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})", text)
        # Find 保单号 context
        for m in re.finditer("保单", text):
            s = max(0, m.start()-5)
            e = min(len(text), m.end()+40)
            print(f"  BAODAN ctx: {repr(text[s:e])}")
        print(f"  {fn[:35]}")
        print(f"    long tokens: {p_all[:5]}")
        print(f"    dates: {dates}")
        print()

# 2. 亚太商业险 - check 保单号
print("=" * 60)
print("2. 亚太商业险 (保单号)")
print("=" * 60)
for fn in os.listdir(folder):
    if "商业" in fn and ("F0QE80" in fn or "F8CD70" in fn or "FC268X" in fn or "Y27V08" in fn):
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        p_all = re.findall(r"[A-Z0-9]{15,}", text)
        # Find 保单号 context
        for m in re.finditer("保单", text):
            s = max(0, m.start()-5)
            e = min(len(text), m.end()+40)
            print(f"  BAODAN ctx: {repr(text[s:e])}")
        print(f"  {fn[:35]}")
        print(f"    long tokens: {p_all[:5]}")
        print()

# 3. 大地意外险 - check all fields
print("=" * 60)
print("3. 大地意外险 (保单号 + 保险起期 + 被保人姓名)")
print("=" * 60)
for fn in os.listdir(folder):
    if "意外" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        p_all = re.findall(r"[A-Z0-9]{15,}", text)
        dates = re.findall(r"(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})", text)
        # Find 保单号/保险期间/投保人 context
        for kw in ["保单", "保险期间", "投保人", "被保人"]:
            for m in re.finditer(kw, text):
                s = max(0, m.start()-5)
                e = min(len(text), m.end()+60)
                ctx = text[s:e].replace("\n", " ")
                print(f"  {kw} ctx: {ctx[:100]}")
        print(f"  {fn[:35]}")
        print(f"    long tokens: {p_all[:5]}")
        print(f"    dates: {dates}")
        print()

# 4. 大地交强险 - check 车架号
print("=" * 60)
print("4. 大地交强险 (车架号)")
print("=" * 60)
for fn in os.listdir(folder):
    if "交强" in fn and ("FCS899" in fn or "FH690S" in fn or "FW121M" in fn or "Y7A308" in fn or "Y97661" in fn):
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        vins = re.findall(r"[A-Z0-9]{17}", text)
        # Find VIN context
        for m in re.finditer(r"车架|VIN|识别代码", text):
            s = max(0, m.start()-5)
            e = min(len(text), m.end()+40)
            print(f"  VIN ctx: {repr(text[s:e])}")
        print(f"  {fn[:35]}")
        print(f"    17-char tokens: {vins[:5]}")
        print()
