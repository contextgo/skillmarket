#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Trace ALL parser calls in parse_pdf."""
import sys, os, re
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
import run_extract

# Patch ALL parsers
for pname in ["parse_jiaoqiang", "parse_shangye", "parse_changxing", "parse_jiacheng",
              "parse_pingan_jiaoqiang", "parse_pingan_garbled", "parse_taipingProperty",
              "parse_taiping_jiacheng", "parse_taiping_changxing", "parse_taishan",
              "parse_taishan_jiacheng", "parse_dadi_anyang", "parse_anhua", "parse_anhua_jiacheng",
              "parse_zhongmei", "parse_zhongmei_jiacheng"]:
    orig = getattr(run_extract, pname, None)
    if orig:
        def make_tracer(name, fn):
            def traced(*args, **kwargs):
                pdf_path = kwargs.get("pdf_path") or (args[2] if len(args) > 2 else None)
                fname = os.path.basename(pdf_path or "")[:30]
                if "F0QE80" in fname and "交强" in fname:
                    print(f"  [TRACE] {name} called for {fname}")
                return fn(*args, **kwargs)
            return traced
        setattr(run_extract, pname, make_tracer(pname, orig))

from run_extract import parse_pdf
folder = r"C:\Users\Administrator\Desktop\车险保单"
for fn in os.listdir(folder):
    if "交强" in fn and "F0QE80" in fn:
        path = os.path.join(folder, fn)
        print(f"=== parse_pdf({fn[:30]}) ===")
        result = parse_pdf(path)
        print(f"  FINAL:保单号=[{result.get('保单号','')}]")
        break
