#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Check what parse_pdf actually does by reading the source."""
import sys, os
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
from run_extract import parse_pdf
import inspect

# Get source of parse_pdf
src = inspect.getsource(parse_pdf)

# Find the line that handles 交强险 routing
for i, line in enumerate(src.split('\n')):
    if '交强' in line or 'F0QE80' in line or 'route_type' in line.lower() or 'pymupdf_text' in line[:30]:
        print(f"L{i}: {line[:120]}")
