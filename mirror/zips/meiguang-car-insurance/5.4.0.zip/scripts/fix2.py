#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Directly test parse_jiaoqiang and parse_shangye on 亚太 text."""
import sys, os, re, fitz
sys.path.insert(0, r"C:\Users\Administrator\.openclaw\workspace\skills\meiguang-car-insurance\scripts")
from run_extract import parse_jiaoqiang, parse_shangye

folder = r"C:\Users\Administrator\Desktop\车险保单"

# Test 亚太交强
for fn in os.listdir(folder):
    if "交强" in fn and "F0QE80" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        
        result = parse_jiaoqiang(text, "亚太", path)
        print(f"=== parse_jiaoqiang on {fn[:30]} ===")
        for k in ["签单时间", "保单号", "被保人姓名", "实收保费"]:
            print(f"  {k}: [{result.get(k, 'MISSING')}]")
        
        # Check if PDDA is in text
        has_pdda = bool(re.search(r"PDDA\d+", text))
        print(f"  PDDA in text: {has_pdda}")
        
        # Check if date fallback would work
        dates = re.findall(r"(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})", text)
        print(f"  dates in text: {dates}")
        break

# Test 亚太商业
for fn in os.listdir(folder):
    if "商业" in fn and "F0QE80" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        text = doc[0].get_text()
        
        result = parse_shangye(text, "亚太", path)
        print(f"\n=== parse_shangye on {fn[:30]} ===")
        for k in ["保单号", "实收保费"]:
            print(f"  {k}: [{result.get(k, 'MISSING')}]")
        
        has_pddi = bool(re.search(r"PDDI\d+", text))
        print(f"  PDDI in text: {has_pddi}")
        break

# Test 大地意外险 - check what parse_dadi_anyang returns
for fn in os.listdir(folder):
    if "意外" in fn and "FCS899" in fn:
        path = os.path.join(folder, fn)
        doc = fitz.open(path)
        pymupdf_text = doc[0].get_text()
        
        import pdfplumber
        plumber_text = ""
        try:
            with pdfplumber.open(path) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t: plumber_text += t + "\n"
        except: pass
        
        from run_extract import parse_dadi_anyang
        result = parse_dadi_anyang(pymupdf_text, plumber_text)
        print(f"\n=== parse_dadi_anyang on {fn[:30]} ===")
        for k in ["签单时间", "保单号", "保险起期", "被保人姓名", "车架号"]:
            print(f"  {k}: [{result.get(k, 'MISSING')}]")
        
        # Check labels in text
        has_baodan = "保单号" in pymupdf_text
        has_qichejia = "车架号" in pymupdf_text
        print(f"  保单号 in pymupdf: {has_baodan}")
        print(f"  车架号 in pymupdf: {has_qichejia}")
        print(f"  pymupdf len: {len(pymupdf_text)}, plumber len: {len(plumber_text)}")
        break
