---
name: create-uk8s
description: 创建 UK8S Kubernetes 集群。通过 ucloud-cli 调用 API，自动获取 VPC/Subnet/版本/镜像，生成配置并创建集群。Use when user wants to create a UK8S cluster.
argument-hint: "[cluster-name]"
allowed-tools: Bash(ucloud *), Bash(openssl *), Bash(base64 *), Bash(cat *), Bash(echo *), Bash(python3 *), Bash(which *), Bash(curl *), Bash(unzip *), Bash(docker *), Read, AskUserQuestion
---

# 创建 UK8S Kubernetes 集群（create-uk8s）

用于引导用户通过 `ucloud-cli` 自动创建 UK8S 集群。
流程包含：环境检查 → 参数收集 → 配置生成 → 集群创建 → 结果反馈。

---

## 基本说明

- 集群名称来自 `$ARGUMENTS`，默认值为 `uk8s`
- 全流程自动化执行，必要时向用户提问补充信息
- 所有 API 调用通过 `ucloud-cli` 完成

---

## 默认配置

```bash
CLUSTER_NAME = $ARGUMENTS 或 "uk8s"

# Master 节点
MASTER_MACHINE_TYPE = "O"
MASTER_CPU = 2
MASTER_MEM = 4096
MASTER_COUNT = 3
MASTER_BOOT_DISK_TYPE = "CLOUD_RSSD"
MASTER_BOOT_DISK_SIZE = 40
MASTER_DATA_DISK_TYPE = "CLOUD_RSSD"
MASTER_DATA_DISK_SIZE = 20

# Node 节点
NODE_MACHINE_TYPE = "O"
NODE_CPU = 4
NODE_MEM = 4096
NODE_COUNT = 2
NODE_MAX_PODS = 110
NODE_BOOT_DISK_TYPE = "CLOUD_RSSD"
NODE_DATA_DISK_TYPE = "CLOUD_RSSD"
NODE_DATA_DISK_SIZE = 20

# 网络
SERVICE_CIDR = "192.168.0.0/16"

# 其他
CHARGE_TYPE = "Dynamic"
KUBE_PROXY = "iptables"
EXTERNAL_API_SERVER = "Yes"
IMAGE_OS = "Ubuntu 24.04"
```

> **注意**：以下参数不是 API 参数，禁止写入 JSON：`CNI_MODE`、`LB_CLASS`、`DELETE_PROTECTION`

---

## Step 1：检查 ucloud-cli

### 1.1 检测是否已安装

```bash
which ucloud && ucloud config list
```

| 状态 | 操作 |
|------|------|
| 未安装 | 进入 1.2 |
| 已安装但未配置 | 进入 Step 2 |
| 已安装且已配置 | 直接进入 Step 3 |

### 1.2 安装 ucloud-cli

读取官方 README 获取最新版本号和安装步骤：

```
https://github.com/ucloud/ucloud-cli
```

根据环境选择安装方式：

- **可访问 GitHub** → 直接下载 release，安装到 `~/.local/bin/`，添加可执行权限并加入 `PATH`
- **国内网络** → 使用 `https://ghfast.top` 作为 GitHub 代理前缀，其余步骤同上
- **有 Docker** → 使用 `uhub.service.ucloud.cn/ucloudcli/ucloud-cli:source-code` 镜像创建 wrapper 脚本
- **都不可行** → 告知用户从 README 获取链接手动下载安装

安装后验证：`ucloud --help`

> **路径注意**：用户未 `source` 配置文件前，后续命令均用绝对路径 `~/.local/bin/ucloud` 执行。

---

## Step 2：检查 CLI 配置

```bash
ucloud config list
```

必须包含：`public_key`、`private_key`、`region`、`zone`、`project_id`

若缺失，用 `AskUserQuestion` 向用户获取，然后执行：

```bash
ucloud config set --region <Region> --zone <Zone> --project-id <ProjectId>
```

**记录 `Region / Zone / ProjectId`，后续步骤必须使用。**

---

## Step 3：并行收集资源信息

同时执行以下命令，一次性拿到所有变量：

```bash
ucloud api --Action DescribeVPC --Region <Region> --ProjectId <ProjectId>
ucloud api --Action GetUK8SVersions --Region <Region> --ProjectId <ProjectId> --Kind Dedicated
ucloud api --Action DescribeUK8SImage --Region <Region> --ProjectId <ProjectId>

PLAIN_PWD=$(openssl rand -base64 12 | tr -dc 'A-Za-z0-9' | head -c 12)
PASSWORD_BASE64=$(echo -n "$PLAIN_PWD" | base64)
```

解析规则：

| 参数 | 规则 |
|------|------|
| VPCId | `DataSet` 中 `Tag == "Default"`；无默认则 `AskUserQuestion` |
| SubnetId | 用 VPCId 调用 `DescribeSubnet`，优先 `Tag == "Default"`；无则询问 |
| K8sVersion | `Data[0].K8sVersion`（完整三段式，如 `1.32.8`）；失败则询问 |
| ImageId | `ImageSet` 中 `ImageName` 含 `Ubuntu 24.04` 且 Zone 匹配；找不到取最新 Ubuntu；失败则询问 |
| Password | `$PLAIN_PWD` 明文仅在最终报告时展示一次；API 传 `$PASSWORD_BASE64` |

异常情况必须询问用户，不允许猜测。

---

## Step 4：读取 SDK 并构造请求 JSON

### 4.1 从 Go SDK 读取参数定义

> **不要尝试 WebFetch UCloud 文档页**——该页面是 JS 渲染的 SPA，工具拿不到任何内容。  
> 使用 `curl` 直接读取 Go SDK 源文件，内容是纯文本，一次即可获取全部 struct 定义。

```bash
curl -s https://raw.githubusercontent.com/ucloud/ucloud-sdk-go/master/services/uk8s/apis.go
```

从输出中找到以下四个 struct，读取所有字段名和 `required` tag：

- `CreateUK8SClusterV2Request` — 顶层请求参数
- `CreateUK8SClusterV2ParamMaster` — `Master.N.*` 数组元素
- `CreateUK8SClusterV2ParamNodes` — `Nodes.N.*` 数组元素
- `CreateUK8SClusterV2ParamKubeProxy` — `KubeProxy.*` 结构体

### 4.2 参数映射规则

根据 struct 定义，将字段按以下规则映射到 JSON key：

| Struct 字段位置 | JSON key 格式 | 示例 |
|----------------|--------------|------|
| `CreateUK8SClusterV2Request` 的字段 | 顶层，直接用字段名 | `"MasterCPU": 2` |
| `Master []CreateUK8SClusterV2ParamMaster` 的子字段 | `Master.N.字段名`，N 从 0 开始 | `"Master.0.Zone": "cn-sh2-01"` |
| `Nodes []CreateUK8SClusterV2ParamNodes` 的子字段 | `Nodes.N.字段名`，N 从 0 开始 | `"Nodes.0.CPU": 4` |
| `KubeProxy *CreateUK8SClusterV2ParamKubeProxy` 的子字段 | `KubeProxy.字段名`（非数组） | `"KubeProxy.Mode": "iptables"` |

### 4.3 生成 JSON 并写入文件

将 Step 3 收集到的值（Region/Zone/ProjectId/VPCId/SubnetId/K8sVersion/ImageId/PASSWORD_BASE64）以及默认配置填入对应字段，用 Bash heredoc 写入：

```bash
cat > /tmp/create_uk8s.json << EOF
{ ... }
EOF
```

> **写文件用 Bash heredoc，不用 Write 工具**——Write 工具对未读过的文件会拒绝写入。

### 创建前确认

向用户展示配置摘要，等待确认后再执行：

```
即将创建 UK8S 集群：

集群名称:    <ClusterName>
Region/Zone: <Region> / <Zone>
VPC/Subnet:  <VPCId> / <SubnetId>
Master:      3 × O型 (2C/4G) · CLOUD_RSSD 40GB
Node:        2 × O型 (4C/4G) · CLOUD_RSSD · MaxPods 110
K8s 版本:    <K8sVersion>
镜像:        <ImageId> (Ubuntu 24.04)
计费:        Dynamic (按需)

是否立即创建？(y/n)
```

---

## Step 5：执行创建

```bash
ucloud api --local-file /tmp/create_uk8s.json
```

| RetCode | 处理 |
|---------|------|
| 0 | 解析 `ClusterId`，进入 Step 6 |
| 非 0 | 输出完整错误信息，给出修复建议 |

常见错误：

- `BalanceInsufficiency` → 账户余额不足，请充值后重试
- `PermissionDenied` → 权限错误，确认 ProjectId 和 API 密钥是否匹配
- 参数错误 → 检查字段名拼写、数组索引是否从 0 开始、Master 参数是否误放入数组

---

## Step 6：结果输出

```
UK8S 集群创建成功！

集群名称: <ClusterName>
集群 ID:   <ClusterId>
Region:    <Region>
Zone:      <Zone>

Master: 3 × O型 (2C/4G)
Node:   2 × O型 (4C/4G)

K8s 版本:     <K8sVersion>
Service CIDR: 192.168.0.0/16

登录密码: <PLAIN_PWD>
（仅展示一次，请立即保存）

集群创建中，预计 5-10 分钟完成。
查看状态：
ucloud api --Action DescribeUK8SCluster \
  --Region <Region> \
  --ProjectId <ProjectId> \
  --ClusterId <ClusterId>
```

---

## 错误处理原则

- 不允许吞错误，必须输出 RetCode + Message
- 提供明确修复建议
- 优先排查：字段名拼写 → 数组索引（必须从 0）→ 参数位置（Master 规格在顶层，Nodes 在数组）

---

## 参数来源

CreateUK8SClusterV2 参数结构来自 UCloud Go SDK（实测有效）：

```
https://raw.githubusercontent.com/ucloud/ucloud-sdk-go/master/services/uk8s/apis.go
```

如需核查或获取新增参数，直接用 `curl` 读取该文件，`grep` 对应 struct 即可。

---

## 参考文档

- UK8S API: https://docs.ucloud.cn/api/uk8s-api/
- VPC API: https://docs.ucloud.cn/api/vpc-api/README
- ucloud-cli: https://github.com/ucloud/ucloud-cli
