#!/usr/bin/env bash
# run_tandian.sh — 薄入口，全部逻辑委托给 tandian_cli.js
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CLI_SCRIPT="$SCRIPT_DIR/tandian_cli.js"

# 校验环境变量
[[ -n "${REPLICATE_API_TOKEN:-}" ]] || { echo "Missing REPLICATE_API_TOKEN" >&2; exit 2; }

exec node "$CLI_SCRIPT" "$@"
