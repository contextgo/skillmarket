#!/usr/bin/env node
/*
xiaofeng-skills 统一入口脚本 (v3)
功能：AI探店图生成 → 腾讯文档发布（可选）
模式：
  [图模式]   node tandian_cli.js --image scene.jpg --out output.webp
  [图文模式] node tandian_cli.js --image scene.jpg --publish --title "标题" --content "文案" [--dish1 a.jpg] [--dish2 b.jpg] --fileName "文档名"

环境变量：
  REPLICATE_API_TOKEN  — Replicate 生图认证（必选）
  TENCENT_DOCS_TOKEN   — 腾讯文档 MCP 认证（--publish 时必选）
*/
const fs = require('node:fs/promises')
const fss = require('node:fs')
const path = require('node:path')
const { PRESET_ROLE_TEMPLATES } = require('./role_templates')

// ── 常量 ──
const POLL_INTERVAL = 1500
const POLL_TIMEOUT = 90_000
const ALLOWED_ASPECT_RATIOS = ['1:1', '2:3', '3:2']
const DEFAULT_PROMPT = '帮我生成一个探店照片，要求：提取图1中的美女人物角色，放入场景参考图2中，参考图2场景空间保持不变'
const MCP_URL = 'https://docs.qq.com/openapi/mcp'
const DEFAULT_FOLDER_ID = 'PcjmfSXfzzEP'

// ── 帮助函数 ──
function usage() {
  console.log(`用法:
  # 仅生成AI探店图
  node tandian_cli.js --image scene.jpg --out output.webp

  # 生成 + 发布腾讯文档
  node tandian_cli.js --image scene.jpg --publish --title "标题" --content "文案" \\
    [--dish1 a.jpg] [--dish2 b.jpg] --fileName "文件名" [--photo c.jpg] [--folder folderId]
`)
}

function parseArgs() {
  const args = process.argv.slice(2)
  const res = {}
  for (let i = 0; i < args.length; i++) {
    const a = args[i]
    if (a.startsWith('--')) {
      const key = a.slice(2)
      const val = args[i + 1] && !args[i + 1].startsWith('--') ? args[++i] : 'true'
      res[key] = val
    }
  }
  return res
}

function isRemoteUrl(input) {
  return input.startsWith('http://') || input.startsWith('https://')
}

function getMimeType(filePathOrUrl) {
  const ext = path.extname(filePathOrUrl).toLowerCase()
  if (ext === '.webp') return 'image/webp'
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg'
  return 'image/png'
}

function getPresetTemplateEntries() {
  return Object.entries(PRESET_ROLE_TEMPLATES).filter(([, url]) => typeof url === 'string' && isRemoteUrl(url))
}

function pickRandomItem(items) {
  return items[Math.floor(Math.random() * items.length)]
}

function normalizePresetKey(rawKey) {
  const lower = rawKey.toLowerCase().trim()
  return lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.webp')
    ? lower.slice(0, lower.lastIndexOf('.'))
    : lower
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// ── 模板选择 ──
function resolveTemplateSource(args) {
  // 1. 用户显式指定远程URL
  if (args.templateUrl) {
    if (!isRemoteUrl(args.templateUrl)) throw new Error(`templateUrl must be an http/https URL: ${args.templateUrl}`)
    return { url: args.templateUrl, label: args.templateUrl, source: 'user-url' }
  }

  // 2. 请求特定预设模板
  const requestedPreset = args.templatePreset || args.template
  if (requestedPreset) {
    const key = normalizePresetKey(requestedPreset)
    const selected = PRESET_ROLE_TEMPLATES[key]
    if (!selected) {
      const entries = getPresetTemplateEntries()
      const available = entries.map(([name]) => name).join(', ')
      throw new Error(`Template preset not found: ${requestedPreset}. Available: ${available}`)
    }
    return { url: selected, label: `preset:${key}`, source: 'preset' }
  }

  // 3. roles/ 目录自动随机选图
  const rolesDir = path.resolve(__dirname, '../templates/roles')
  if (fss.existsSync(rolesDir)) {
    const files = fss.readdirSync(rolesDir).filter(f => {
      const ext = path.extname(f).toLowerCase()
      return ['.jpg', '.jpeg', '.png', '.webp'].includes(ext)
    })
    if (files.length > 0) {
      const chosen = pickRandomItem(files)
      return { url: path.join(rolesDir, chosen), label: `role:${chosen}`, source: 'roles-dir' }
    }
  }

  // 4. 最后兜底：随机预设
  const presetEntries = getPresetTemplateEntries()
  if (presetEntries.length > 0) {
    const [randomKey, randomUrl] = pickRandomItem(presetEntries)
    return { url: randomUrl, label: `preset:${randomKey}`, source: 'preset-random' }
  }

  throw new Error('No template source available — add images to templates/roles/ or configure PRESET_ROLE_TEMPLATES')
}

async function fileOrUrlToDataUrl(input) {
  if (!input) throw new Error('no input')
  if (isRemoteUrl(input)) {
    const resp = await fetch(input)
    if (!resp.ok) throw new Error(`Failed to fetch template: ${resp.status}`)
    const ab = await resp.arrayBuffer()
    const b64 = Buffer.from(ab).toString('base64')
    const mime = resp.headers.get('content-type') || 'image/png'
    return `data:${mime};base64,${b64}`
  } else {
    const abs = path.resolve(process.cwd(), input)
    const buf = await fs.readFile(abs)
    const mime = getMimeType(abs)
    return `data:${mime};base64,${buf.toString('base64')}`
  }
}

// ── Replicate 生图 ──
async function createPrediction(token, userImage, templateImage, aspectRatio, prompt) {
  const input = {
    aspect_ratio: aspectRatio,
    background: 'auto',
    input_images: [templateImage, userImage],
    moderation: 'auto',
    number_of_images: 1,
    output_compression: 90,
    output_format: 'webp',
    prompt: prompt || DEFAULT_PROMPT,
    quality: 'low',
  }
  const res = await fetch('https://api.replicate.com/v1/models/openai/gpt-image-2/predictions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ input }),
  })
  if (!res.ok) { const text = await res.text(); throw new Error(`Replicate create failed: ${res.status} ${text}`) }
  return res.json()
}

async function getPrediction(id, token) {
  const res = await fetch(`https://api.replicate.com/v1/predictions/${id}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  if (!res.ok) { const text = await res.text(); throw new Error(`Replicate get failed: ${res.status} ${text}`) }
  return res.json()
}

async function createUpscalePrediction(token, mediaUrl) {
  const res = await fetch('https://api.replicate.com/v1/predictions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({
      version: 'ca98249be9cb623f02a80a7851a2b1a33d5104c251a8f5a1588f251f79bf7c78',
      input: {
        media: mediaUrl, fps: 24, sp_size: 1, cfg_scale: 1, sample_steps: 1,
        model_variant: '3b', output_format: 'webp', output_quality: 90, apply_color_fix: true,
      },
    }),
  })
  if (!res.ok) { const text = await res.text(); throw new Error(`SeedVR2 create failed: ${res.status} ${text}`) }
  return res.json()
}

async function downloadToFile(url, outPath) {
  const resp = await fetch(url)
  if (!resp.ok) throw new Error(`Failed downloading output: ${resp.status}`)
  const ab = await resp.arrayBuffer()
  await fs.mkdir(path.dirname(outPath), { recursive: true })
  await fs.writeFile(outPath, Buffer.from(ab))
}

// ── 腾讯文档发布 ──
async function uploadImage(token, filePath, fileName) {
  const buf = await fs.readFile(path.resolve(process.cwd(), filePath))
  const b64 = buf.toString('base64')

  const payload = {
    jsonrpc: '2.0', id: 1, method: 'tools/call',
    params: { name: 'upload_image', arguments: { file_name: fileName, image_base64: b64 } },
  }
  const res = await fetch(MCP_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(`Upload failed: ${res.status}`)
  const body = await res.json()
  const data = JSON.parse(body.result.content[0].text)
  return data.image_id
}

async function createDocument(token, title, mdxContent) {
  const payload = {
    jsonrpc: '2.0', id: 2, method: 'tools/call',
    params: { name: 'create_smartcanvas_by_mdx', arguments: { title, mdx: mdxContent, content_format: 'markdown' } },
  }
  const res = await fetch(MCP_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(`Create doc failed: ${res.status}`)
  const body = await res.json()
  const data = JSON.parse(body.result.content[0].text)
  return { fileId: data.file_id, url: data.url }
}

async function callManageTool(token, name, args) {
  const payload = {
    jsonrpc: '2.0', id: 1, method: 'tools/call',
    params: { name, arguments: args },
  }
  await fetch(MCP_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  })
}

async function publishToTencentDocs(token, { title, content, dish1, dish2, photo, fileName, folderId }) {
  let img1Id = '', img2Id = ''
  if (dish1) {
    console.log('📤 上传菜谱图1...')
    img1Id = await uploadImage(token, dish1, 'dish1.jpg')
    console.log('   ✅')
  } else {
    console.log('📤 跳过菜谱图1（未提供）')
  }

  if (dish2) {
    console.log('📤 上传菜谱图2...')
    img2Id = await uploadImage(token, dish2, 'dish2.jpg')
    console.log('   ✅')
  } else {
    console.log('📤 跳过菜谱图2（未提供）')
  }

  let photoId = ''
  if (photo) {
    console.log('📤 上传探店图...')
    try {
      photoId = await uploadImage(token, photo, 'tandian.jpg')
      console.log('   ✅')
    } catch { console.log('   ⚠️ 探店图上传说失败') }
  }

  // 组装文档：探店图在前，有菜谱图则拼在后面
  let mdx = ''
  if (photoId) mdx += `![探店打卡](${photoId})\n\n`
  const dishParts = [img1Id, img2Id].filter(Boolean).map(id => `![菜品](${id})`).join('\n')
  if (dishParts) mdx += dishParts + '\n\n'
  mdx += content

  console.log('📝 创建文档...')
  const doc = await createDocument(token, title, mdx)
  console.log(`   file_id=${doc.fileId}`)

  console.log('📂 移动文件夹...')
  await callManageTool(token, 'manage.move_file', { file_id: doc.fileId, target_folder_id: folderId || DEFAULT_FOLDER_ID })
  console.log('🔓 设置公开编辑...')
  await callManageTool(token, 'manage.set_privilege', { file_id: doc.fileId, policy: 3 })
  console.log('✏️  重命名...')
  await callManageTool(token, 'manage.rename_file_title', { file_id: doc.fileId, title: fileName })

  console.log('\n✅ 发布完成！')
  console.log(`📄 ${fileName}`)
  console.log(`👉 ${doc.url}`)
}

// ── 主流程 ──
async function generateImage(args) {
  const token = process.env.REPLICATE_API_TOKEN
  if (!token) { console.error('Missing REPLICATE_API_TOKEN'); process.exit(2) }

  const aspect = args.aspect || '2:3'
  if (!ALLOWED_ASPECT_RATIOS.includes(aspect)) { console.error('Invalid aspect ratio'); process.exit(1) }

  const userImage = await fileOrUrlToDataUrl(args.image)
  const selectedTemplate = resolveTemplateSource(args)
  const templateImage = await fileOrUrlToDataUrl(selectedTemplate.url)
  console.log('Using role template:', selectedTemplate.label)

  console.log('🎨 AI生图...')
  const pred = await createPrediction(token, userImage, templateImage, aspect, args.prompt || '')
  const start = Date.now()
  let finalUrl = null
  while (true) {
    const status = await getPrediction(pred.id, token)
    if (status.status === 'succeeded') {
      const output = Array.isArray(status.output) ? status.output[0] : status.output
      if (!output) throw new Error('Invalid output')
      console.log('✨ 高清放大...')
      const up = await createUpscalePrediction(token, output)
      const upStart = Date.now()
      while (true) {
        const upStatus = await getPrediction(up.id, token)
        if (upStatus.status === 'succeeded') {
          finalUrl = Array.isArray(upStatus.output) ? upStatus.output[0] : upStatus.output
          break
        }
        if (upStatus.status === 'failed') throw new Error(upStatus.error || 'SeedVR2 failed')
        if (Date.now() - upStart > POLL_TIMEOUT) throw new Error('Timeout waiting for SeedVR2')
        await sleep(POLL_INTERVAL)
      }
      break
    }
    if (status.status === 'failed') throw new Error(status.error || 'Replicate failed')
    if (Date.now() - start > POLL_TIMEOUT) throw new Error('Timeout waiting for prediction')
    await sleep(POLL_INTERVAL)
  }

  if (!finalUrl) throw new Error('No final url')
  await downloadToFile(finalUrl, path.resolve(process.cwd(), args.out))
  console.log('Saved output to', args.out)
  return path.resolve(process.cwd(), args.out)
}

async function main() {
  const args = parseArgs()
  if (!args.image || !args.out) { usage(); process.exit(1) }

  // 1. 生成AI探店图
  const photoPath = await generateImage(args)

  // 2. 如果需要发布
  if (args.publish) {
    const docsToken = process.env.TENCENT_DOCS_TOKEN
    if (!docsToken) { console.error('Missing TENCENT_DOCS_TOKEN (required for --publish)'); process.exit(2) }
    if (!args.title || !args.content || !args.fileName) {
      console.error('--publish 需要 --title, --content, --fileName')
      process.exit(1)
    }
    await publishToTencentDocs(docsToken, {
      title: args.title,
      content: args.content,
      dish1: args.dish1,
      dish2: args.dish2,
      photo: photoPath,  // 自动传入刚生成的探店图
      fileName: args.fileName,
      folderId: args.folder,
    })
  }
}

if (process.argv[1] && process.argv[1].endsWith('tandian_cli.js')) { main() }
