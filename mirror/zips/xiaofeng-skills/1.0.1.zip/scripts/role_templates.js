// Role template presets for AI探店图人物合成.
// 邓哥可以把模特图放进 templates/roles/ 目录，
// 并在下方添加预设映射条目。
// 文件名（不含扩展名）作为 --templatePreset 参数值。
const PRESET_ROLE_TEMPLATES = {
  // 示例：'lucy': 'https://images.unsplash.com/photo-xxx',
  // 使用 --templatePreset lucy 引用，或随机选
}

module.exports = { PRESET_ROLE_TEMPLATES }
