---
name: xiaofeng-skills
description: 探店笔记完整生产流水线。接收门店场景图→AI生成探店图 + 接收点评链接→抓取网友推荐菜图片 → 生成爆款文案 → 发布到腾讯文档。适合餐饮品牌线上运营、探店笔记批量代写场景。
version: 2.1.0
author: 小枫 🍁
metadata:
  openclaw:
    emoji: "🍁"
    requires:
      skills:
        - tencent-docs
      env:
        - REPLICATE_API_TOKEN
---

# 探店笔记完整生产流水线 SOP

## 概述

本 skill 覆盖探店笔记从**图到文到发布**的全流程，集成所有能力于一体：

- AI 探店图生成（Replicate gpt-image-2 人物合成 → SeedVR2 高清放大）
- 腾讯文档发布（上传图片 → 创建文档 → 移动 → 权限 → 重命名）

### 文档最终结构

```
1. 🫣 AI探店图（人物角色合成到门店场景）
2. 🍖 菜谱图 × 2（来自点评网友推荐菜）
3. ✍️ 爆款探店文案
```

---

## 前置条件

### 依赖

- `tencent-docs` — 已安装并授权
- `REPLICATE_API_TOKEN` — 环境变量已配置

### 脚本

| 脚本 | 用途 |
|------|------|
| `scripts/run_tandian.sh` | AI探店图生成入口（调用 replicate_cli.js）|
| `scripts/replicate_cli.js` | Replicate API 调用：gpt-image-2 编辑 + SeedVR2 放大 |
| `scripts/publish_note.sh` | 一键发布：上传图片 → 创建文档 → 移动 → 权限 → 重命名 |

### 模特模板

AI 探店图需要一张人物参考图。两个方式指定：

1. **默认随机**：从 `templates/roles/` 目录随机选一张模特图（需先放图进去）
2. **远程 URL**：通过 `--template-url` 参数传入模特图链接

---

## 输入

| 输入 | 说明 |
|------|------|
| 门店场景图 | 餐厅门店/环境实拍图，用于 AI 合成探店图 |
| 模特图 | 人物参考图（可选，默认从 templates/roles/ 随机选） |
| 大众点评链接 | 餐厅的点评链接，用于抓取菜谱图 |

---

## 工作流

### Step 1：生成 AI 探店图

收到门店场景图后，用内置脚本生成探店打卡照：

**基本用法（默认随机模特模板）：**
```bash
REPLICATE_API_TOKEN=你的token bash scripts/run_tandian.sh 门店场景图路径
```

**指定远程模特图 URL：**
```bash
REPLICATE_API_TOKEN=你的token bash scripts/run_tandian.sh \
  门店场景图路径 \
  [输出路径] \
  --template-url "https://...模特图URL" \
  --aspect "2:3"
```

**参数说明：**
- `--template`：指定 `templates/roles/` 中的模板文件名
- `--template-url`：传入远程模特图 URL
- `--aspect`：`1:1` / `2:3` / `3:2`，默认 `2:3`
- `--prompt`：自定义提示词，不传则使用默认探店提示词

**默认提示词：**
```
帮我生成一个探店照片，要求：提取图1中的美女人物角色，放入场景参考图2中，参考图2场景空间保持不变
```

**模特图自动选择（templates/roles/）：**
- 脚本默认从 `templates/roles/` 目录随机选一张模特图
- 邓哥把模特图片放入 `templates/roles/` 即可自动使用
- 若需指定特定模特，用 `--template-url 图片URL` 或 `--templatePreset 文件名`
- roles 目录已包含默认模特 `lucy.png`

**底层命令（可直接调JS）：**
```bash
REPLICATE_API_TOKEN=你的token node scripts/replicate_cli.js \
  --image 场景图路径 \
  --out 输出路径 \
  --aspect "2:3"  # 自动从 templates/roles/ 随机选模特

# 如需指定模特图URL：
REPLICATE_API_TOKEN=你的token node scripts/replicate_cli.js \
  --image 场景图路径 \
  --template-url 模特图URL \
  --out 输出路径
```

输出文件为高清 WEBP 格式，带回路径备用。

### Step 2：抓取网友推荐菜图片

用浏览器打开点评链接，滚动触发懒加载，提取网友推荐菜的图片URL。

- 只抓**网友推荐菜**区域，不抓商家招牌菜
- 选2道菜下载
- 用 ffmpeg 适当压缩（宽度≥1200px、质量≥8，确保手机端清晰）

### Step 3：创作探店文案

按以下模板写文案：

```
# [标题] 感叹句式+情绪词+emoji

[开头] 有"活人味"的个人体验，朋友推荐口吻

[环境] 简单描述店铺氛围

[2道菜品] 统一emoji标记：🍖 菜名 — 简短口感描述

[地址] 📍 餐厅名(分店)
[人均] 💴 人均¥XX

[标签] 8个#话题标签
```

**风格：** 口语化、有烟火气，禁用目录式结构，emoji统一不混用。

### Step 4：一键发布

调用脚本自动完成全部腾讯文档操作：

```bash
bash scripts/publish_note.sh \
  --title "临时标题" \
  --content "文案全文" \
  --name "小枫 AI 探店笔记_[餐厅名(分店)]_[YYYYMMDD]" \
  --photo /path/to/AI探店图.jpg \
  --dish1 /path/to/菜谱图1.jpg \
  --dish2 /path/to/菜谱图2.jpg
```

脚本自动完成：上传图片 → 组装文档 → 创建 → 移动文件夹 → 设公开编辑 → 重命名。

---

## 输出

📄 小枫 AI 探店笔记_[餐厅名(分店)]_[YYYYMMDD]
👉 https://docs.qq.com/aio/[文档ID]

---

## 异常处理

| 问题 | 原因 | 处理 |
|------|------|------|
| 点评滑块验证 | 高频访问 | 等待3-5分钟再试 |
| AI 生图失败 | API 超时/报错 | 重试或换输入图 |
| 图片上传失败 | base64过长 | 直调MCP API，大图也能传 |
| 模特图未找到 | templates/roles/ 为空 | 用 --template-url 指定远程图 |

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-05-02 | 初始版本 |
| ... | ... | ... |
| 1.1.3 | 2026-05-02 | MCP API直调，突破大图上传限制 |
| **2.0.0** | **2026-05-02** | **整合tandian-image-skills，独立一站式skill** |
