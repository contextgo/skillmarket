---
name: design-experts
description: 设计专家群 —— 汇聚同济大学、中央美院、清华大学等顶尖院校的70余位设计领域专家数字分身。根据你的问题自动匹配最合适的专家，支持设计咨询对话、设计作品点评（支持图片上传）、AI设计图片生成。专家覆盖交互体验、城市规划、工业设计、品牌战略、智能计算、社会创新、视觉传达等12大领域。
---

# 设计专家群

汇聚同济大学、中央美院、清华大学等顶尖院校的70余位设计领域专家数字分身，根据你的问题自动匹配最合适的专家进行对话。

## When to Use

- 用户想咨询设计领域相关问题（交互设计、品牌设计、建筑设计、可持续设计、AI设计等）
- 用户想让专家点评设计作品（支持图片上传）
- 用户想根据描述生成设计相关图片
- 用户想了解有哪些专家可以咨询
- 用户想指定某位专家进行对话

## Tools

| 工具 | 说明 |
|------|------|
| `expert_chat` | 与设计专家对话，自动匹配最合适的专家（也可指定 expert_agent_id） |
| `expert_review` | 上传设计作品图片，获取专家专业点评与分析 |
| `expert_image` | 根据描述通过专家生成设计相关图片 |
| `list_experts` | 列出所有可用专家及其领域 |
| `match_expert` | 根据问题预览会匹配到哪位专家 |

## Expert Fields

专家覆盖以下12大领域：

| 领域 | 关键词 |
|------|--------|
| 交互体验 | 交互设计、用户体验、人机交互、可穿戴设计 |
| 城市区域 | 城市规划、建筑设计、城市更新、乡村振兴 |
| 工业设计 | 产品设计、工业设计、材料应用、家具设计 |
| 战略管理 | 设计战略、品牌战略、设计管理 |
| 智能计算 | AI设计、算法设计、智能系统、数字化 |
| 服务系统 | 服务设计、系统设计、社会创新服务 |
| 环境空间 | 环境设计、室内设计、空间设计 |
| 社会创新 | 社会创新、可持续设计、社区设计 |
| 视觉传达 | 平面设计、品牌视觉、字体设计 |
| 设计教育 | 设计教育、设计研究 |
| 设计理论 | 设计历史、设计理论、设计批评 |
| 跨域前沿 | 跨学科设计、前沿探索、新兴技术 |

## Authentication (Token 鉴权)

所有接口调用需要提供鉴权 token。

### Token 缺失或无效时的提示

当用户未提供 token，或接口返回 **HTTP 401**（鉴权失败）时，技能会统一返回以下固定提示信息：

```
[点击获取 token](https://edu.tencent.com/agent/#/api-keys)
```

## Workflow

1. **接收请求**：handler.py 从 stdin 读取工具调用 JSON
2. **专家匹配**：根据问题关键词与专家的 classify、fields、intro 进行相关度评分，自动选出最合适的专家
3. **会话管理**：多轮对话时自动沿用同一个专家，避免重复匹配
4. **鉴权检查**：验证 token 是否存在
5. **构建请求**：根据匹配到的专家 agent_id 构建请求体
6. **调用接口**：POST 到 `/sse/aiwriter/v1/chat`
7. **解析 SSE**：异步解析 SSE 流式响应，拼接增量内容
8. **返回结果**：输出 JSON 结果（含 matched_expert 信息）到 stdout

## 多轮对话特性

系统支持多轮对话，具有以下特性：

- **智能专家延续**：系统会智能判断是否应该沿用上一个专家
  - 当用户的问题与当前专家领域相关时，自动沿用专家
  - 当用户的问题与当前专家领域不相关时，自动重新匹配更合适的专家
- **会话管理**：通过 `conversation_id` 参数维护对话上下文
- **智能切换**：基于问题与专家专长的匹配度进行智能判断

## 智能判断逻辑

系统通过以下方式判断是否沿用专家：

1. **专长关键词匹配**：检查新问题是否包含当前专家的专长关键词
2. **领域匹配**：检查新问题是否属于当前专家的专业领域
3. **介绍文本匹配**：检查新问题是否与专家介绍内容相关
4. **阈值判断**：当相关度得分达到阈值时，沿用专家；否则重新匹配

这种设计确保用户可以在同一个会话中：
- 深入探讨同一领域的问题时，保持专家一致性
- 切换不同设计领域时，自动匹配合适的新专家

## Usage Examples

```json
{"tool": "expert_chat", "arguments": {"question": "如何做好品牌视觉设计？"}}

{"tool": "expert_chat", "arguments": {"question": "能详细说说色彩搭配的技巧吗？", "conversation_id": "会话ID"}}

{"tool": "expert_chat", "arguments": {"question": "可持续设计的核心理念是什么？", "expert_agent_id": 10071}}

{"tool": "expert_review", "arguments": {"message": "请帮我点评这个交互设计", "image_url": "https://example.com/design.png"}}

{"tool": "expert_review", "arguments": {"message": "针对刚才的设计，还有哪些改进建议？", "image_url": "https://example.com/design.png", "conversation_id": "会话ID"}}

{"tool": "expert_image", "arguments": {"prompt": "帮我生成一张可持续设计概念图"}}

{"tool": "expert_image", "arguments": {"prompt": "基于刚才的概念，生成一个更具体的版本", "conversation_id": "会话ID"}}

{"tool": "list_experts", "arguments": {}}

{"tool": "match_expert", "arguments": {"question": "我想了解参数化设计"}}
```

## Configuration

See `config.json` for:
- API 基础地址与超时配置
- 所有专家配置（agent_id、name、classify、fields、intro）
- 领域分组描述（field_groups）
- 支持的图片类型
- Authentication token