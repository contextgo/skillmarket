# 设计专家群

汇聚同济大学、中央美院、清华大学、浙江大学等顶尖院校的 70+ 位设计领域专家数字分身，根据你的问题自动匹配最合适的专家进行对话。

## Features

- 💬 **设计咨询对话** — 根据问题自动匹配最合适的专家，覆盖工业设计、视觉传达、交互体验、环境空间、城市区域、社会创新、战略管理、智能计算、服务系统、设计教育、设计理论、跨域前沿等 12 大领域
- 🎨 **设计作品点评** — 上传设计作品图片，由匹配专家提供专业点评与分析建议
- 🖼️ **AI 图片生成** — 根据描述通过专家生成设计相关图片
- 🔍 **专家列表查询** — 查看所有可用专家及其专业领域
- 🎯 **专家预匹配** — 预览某个问题会匹配到哪位专家

## Experts

专家覆盖以下 12 大领域（共 70+ 位），所有专家配置统一维护在 `config.json`：

| 领域 | 代表专家 |
|------|----------|
| 工业设计 | 刘力丹（力丹老师）、王受之（受之老师）、莫娇（老莫）、方海教授、侯正光（侯哥）、杨继栋（继栋老师）、Carl Liu 等 |
| 视觉传达 | 孙大旺（大旺老师）、吴端（端姐姐）、WM、江波老师、刘钊老师、韩家英老师、刘治治、杜钦老师 等 |
| 交互体验 | 辛向阳（Prof XXY）、王琦（琦老师）、冠云老师、孙效华（孙教授）、江波老师 等 |
| 环境空间 | 袁教授、汪洋老师、俞挺老师、青山周平（青山老师）、灏哥、王兰老师、郝光教授 等 |
| 城市区域 | 苏运升老师、张尚武（武教授）、匡晓明（匡教授）、李振宇、麟学老师 等 |
| 社会创新 | 娄永琪（Prof.lou）、John Thackara（John）、张磊老师、周子书老师、淼森老师 等 |
| 战略管理 | 辛向阳（Prof XXY）、John（John Thackara）、Prof JP、魏姐、童老师 等 |
| 智能计算 | 张周捷（周捷老师）、王萌（萌学长）、苏运升老师、麻菁、冠云老师 等 |
| 服务系统 | 辛向阳（Prof XXY）、王国胜（国胜老师）、陈嘉嘉老师、孙大旺（大旺老师） 等 |
| 设计教育 | 娄永琪（Prof.lou）、王受之（受之老师）、张磊老师、许平老师、丁伟老师、Carl Liu 等 |
| 设计理论 | 王受之（受之老师）、圣玺老师、黎老师、志鹏老师、定邦老师、韩家英老师 等 |
| 跨域前沿 | 康思大（Prof Kosta）、孟筱筱（Candace）、孙守迁教授、冠云老师、麟学老师 等 |

## Installation

```bash
pip install -e .
```

## Usage

### As OpenClaw Skill

工具调用通过 stdin/stdout JSON 交互：

```bash
# 自动匹配专家对话
echo '{"tool": "expert_chat", "arguments": {"question": "如何做好品牌视觉设计？"}}' | \
  python src/script/handler.py

# 指定专家对话（Prof.lou，agent_id=10071）
echo '{"tool": "expert_chat", "arguments": {"question": "可持续设计的核心理念？", "expert_agent_id": 10071}}' | \
  python src/script/handler.py

# 作品点评
echo '{"tool": "expert_review", "arguments": {"message": "请点评这个交互设计", "image_url": "https://example.com/design.png"}}' | \
  python src/script/handler.py

# 列出所有专家
echo '{"tool": "list_experts", "arguments": {}}' | \
  python src/script/handler.py

# 预览匹配专家
echo '{"tool": "match_expert", "arguments": {"question": "我想了解参数化设计"}}' | \
  python src/script/handler.py
```

### Command Line

```bash
# 自动匹配专家对话
python src/script/skill.py chat <token> <question> [conversation_id] [expert_agent_id]

# 设计作品点评
python src/script/skill.py review <token> <message> <image_url> [image_name] [conversation_id] [expert_agent_id]

# 图片生成
python src/script/skill.py image <token> <prompt> [conversation_id] [expert_agent_id]

# 列出所有专家
python src/script/skill.py list_experts

# 预览匹配专家
python src/script/skill.py match <question>
```

## Expert Matching

根据问题关键词与专家的专长、领域、简介进行相关度评分，自动选出最合适的专家：

| 匹配维度 | 权重 |
|----------|------|
| 专长关键词（classify）命中 | +3 分 |
| 领域名称（fields）命中 | +2 分 |
| 领域扩展词命中 | +1 分 |
| 简介关键词（intro）命中 | +0.5 分 |

无任何匹配时，默认返回第一位专家（娄永琪教授，Prof.lou）。

## Configuration

所有专家配置统一维护在 `config.json`：

```json
{
  "api": { "base_url": "...", "authorization": "" },
  "experts": [
    {
      "agent_id": 10071,
      "name": "Prof.lou",
      "classify": "环境设计, 社会创新, 可持续设计, ...",
      "fields": ["社会创新", "设计教育"],
      "intro": "娄永琪教授，..."
    },
    // ... 共 70+ 位专家
  ],
  "field_groups": {
    "社会创新": "社会创新、可持续设计、社区设计、公共设计",
    ...
  }
}
```

## API

本 skill 调用 `/sse/aiwriter/v1/chat` 接口，使用 SSE 流式返回，`agent_id` 根据匹配结果动态传入。

## Authentication (Token 鉴权)

所有接口调用需要提供鉴权 token。

### Token 缺失或无效时的提示

当用户未提供 token，或接口返回 **HTTP 401**（鉴权失败）时，技能会统一返回以下固定提示信息：

```
[点击获取 token](https://edu.tencent.com/agent/#/api-keys)
```

> ⚠️ 此提示信息为固定文案，请勿修改。

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
python test_runner.py
```
