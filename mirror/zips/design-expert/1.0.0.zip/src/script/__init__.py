"""
Prof.Lou 设计专家 — OpenClaw Skill 入口

提供三个工具：
1. design_chat   - 设计咨询对话
2. design_review - 设计作品点评（支持图片上传）
3. design_image  - AI设计图片生成
"""

__version__ = "1.0.0"

from .skill import (
    expert_chat,
    expert_review,
    expert_image,
    list_experts,
    match_expert,
)

from .api_client import (
    chat_stream,
    chat_stream_sync,
    build_attachment,
    build_chat_payload,
    AGENT_ID,
    API_BASE_URL,
)

__all__ = [
    "expert_chat",
    "expert_review",
    "expert_image",
    "list_experts",
    "match_expert",
    "chat_stream",
    "chat_stream_sync",
    "build_attachment",
    "build_chat_payload",
    "AGENT_ID",
    "API_BASE_URL",
]
