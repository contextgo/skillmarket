#!/usr/bin/env python3
"""
Design Experts — OpenClaw Tool Handler

OpenClaw 框架调用此脚本执行工具。
输入：从 stdin 读取 JSON，格式为 {"tool": "tool_name", "arguments": {...}}
输出：向 stdout 写入 JSON 结果
"""

import json
import sys
import os

# 将当前目录加入模块搜索路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from skill import (
    expert_chat,
    expert_review,
    expert_image,
    list_experts,
    match_expert,
)
from api_client import _api_config

# 从 config.json 读取默认 authorization
_DEFAULT_AUTHORIZATION: str = _api_config.get("authorization", "")


def handle_tool_call(tool_name: str, arguments: dict) -> dict:
    """处理工具调用

    Args:
        tool_name: 工具名称
        arguments: 工具参数

    Returns:
        工具执行结果
    """
    # 从参数获取鉴权 token，若未传则使用 config.json 中的默认值
    authorization = arguments.pop("authorization", "") or _DEFAULT_AUTHORIZATION

    if tool_name == "list_experts":
        # 列出所有专家，不需要鉴权
        return {"experts": list_experts()}

    if tool_name == "match_expert":
        # 匹配专家，不需要鉴权
        question = arguments.get("question", "")
        if not question:
            return {"error": "question 参数不能为空"}
        expert = match_expert(question)
        return {"matched_expert": expert}

    if not authorization:
        return {"error": "缺少鉴权 token，[点击获取 token](https://edu.tencent.com/agent/#/api-keys)"}

    # 可选：指定专家 agent_id（为 0 时自动匹配）
    expert_agent_id = int(arguments.get("expert_agent_id", 0))

    if tool_name == "expert_chat":
        question = arguments.get("question", "")
        conversation_id = arguments.get("conversation_id", "")
        if not question:
            return {"error": "question 参数不能为空"}
        return expert_chat(authorization, question, conversation_id, expert_agent_id)

    elif tool_name == "expert_review":
        message = arguments.get("message", "")
        image_url = arguments.get("image_url", "")
        image_name = arguments.get("image_name", "design.png")
        conversation_id = arguments.get("conversation_id", "")
        if not message:
            return {"error": "message 参数不能为空"}
        if not image_url:
            return {"error": "image_url 参数不能为空"}
        return expert_review(authorization, message, image_url, image_name, conversation_id, expert_agent_id)

    elif tool_name == "expert_image":
        prompt = arguments.get("prompt", "")
        conversation_id = arguments.get("conversation_id", "")
        if not prompt:
            return {"error": "prompt 参数不能为空"}
        return expert_image(authorization, prompt, conversation_id, expert_agent_id)

    else:
        return {"error": f"未知工具: {tool_name}"}


def main():
    """主入口：从 stdin 读取工具调用请求，执行后输出结果"""
    try:
        # 从 stdin 读取请求
        input_data = sys.stdin.read()
        if not input_data.strip():
            print(json.dumps({"error": "输入为空"}))
            return

        request = json.loads(input_data)
        tool_name = request.get("tool", "")
        arguments = request.get("arguments", {})

        if not tool_name:
            print(json.dumps({"error": "缺少 tool 参数"}))
            return

        # 执行工具调用
        result = handle_tool_call(tool_name, arguments)
        print(json.dumps(result, ensure_ascii=False))

    except json.JSONDecodeError as e:
        print(json.dumps({"error": f"JSON 解析失败: {str(e)}"}))
    except Exception as e:
        print(json.dumps({"error": f"执行失败: {str(e)}"}))


if __name__ == "__main__":
    main()
