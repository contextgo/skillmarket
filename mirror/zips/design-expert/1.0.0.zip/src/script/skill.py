#!/usr/bin/env python3
"""
Design Experts Skill - Main Entry Point
根据用户问题智能匹配合适的设计专家，并进行对话、作品点评或图片生成。
"""

import json
import sys
import os

# Add scripts to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api_client import (
    build_attachment,
    chat_stream_sync,
    _load_config,
)


# ==================== 专家配置加载 ====================


def _get_experts() -> list:
    """从 config.json 加载专家列表"""
    config = _load_config()
    return config.get("experts", [])


def _get_field_groups() -> dict:
    """从 config.json 加载领域分组描述"""
    config = _load_config()
    return config.get("field_groups", {})


# ==================== 专家匹配 ====================


def _build_expert_summary(expert: dict) -> str:
    """构建单个专家的摘要描述，用于匹配提示词"""
    name = expert.get("name", "")
    classify = expert.get("classify", "")
    fields = ", ".join(expert.get("fields", []))
    intro = expert.get("intro", "")
    # 截取 intro 前 100 字，避免提示词过长
    intro_short = intro[:100] + "..." if len(intro) > 100 else intro
    return f"- {name}（领域：{fields}；专长：{classify}）：{intro_short}"


def match_expert(question: str) -> dict:
    """根据用户问题匹配最合适的专家

    使用规则匹配：对比问题关键词与专家的 classify、fields、intro，
    计算相关度得分，返回得分最高的专家。

    Args:
        question: 用户的问题

    Returns:
        匹配到的专家配置字典，若无专家则返回空字典
    """
    experts = _get_experts()
    if not experts:
        return {}

    field_groups = _get_field_groups()
    question_lower = question.lower()

    best_expert = None
    best_score = -1

    for expert in experts:
        score = 0
        classify = expert.get("classify", "").lower()
        fields = expert.get("fields", [])
        intro = expert.get("intro", "").lower()
        name = expert.get("name", "").lower()

        # 按 classify 关键词匹配
        for keyword in classify.split(","):
            keyword = keyword.strip()
            if keyword and keyword in question_lower:
                score += 3

        # 按 fields 领域匹配（含领域描述扩展词）
        for field in fields:
            if field in question_lower:
                score += 2
            # 用领域描述扩展词匹配
            field_desc = field_groups.get(field, "").lower()
            for word in field_desc.split("、"):
                word = word.strip()
                if word and word in question_lower:
                    score += 1

        # 按 intro 关键词匹配（权重较低）
        intro_keywords = [w for w in intro.split() if len(w) >= 2]
        for kw in intro_keywords[:30]:  # 只取前30个词避免过度匹配
            if kw in question_lower:
                score += 0.5

        if score > best_score:
            best_score = score
            best_expert = expert

    # 若无任何匹配，返回第一个专家（默认 Prof.lou）
    if best_score <= 0:
        return experts[0] if experts else {}

    return best_expert


def list_experts() -> list:
    """返回所有专家的简要信息列表

    Returns:
        专家简要信息列表，每项包含 agent_id、name、classify、fields
    """
    experts = _get_experts()
    return [
        {
            "agent_id": e.get("agent_id"),
            "name": e.get("name"),
            "classify": e.get("classify"),
            "fields": e.get("fields", []),
        }
        for e in experts
    ]


# ==================== 会话管理 ====================

# 存储会话与专家的映射关系（conversation_id -> expert_agent_id）
_conversation_expert_map = {}

def _should_keep_expert(current_expert: dict, new_question: str) -> bool:
    """智能判断是否应该沿用当前专家
    
    基于问题与专家专长的匹配度判断：
    - 如果新问题与当前专家领域高度相关，则沿用
    - 如果新问题与当前专家领域不相关，则重新匹配
    
    Args:
        current_expert: 当前会话的专家
        new_question: 新的用户问题
        
    Returns:
        True 表示应该沿用专家，False 表示应该重新匹配
    """
    if not current_expert:
        return False
    
    question_lower = new_question.lower()
    
    # 检查新问题是否与当前专家的专长相关
    classify = current_expert.get("classify", "").lower()
    fields = current_expert.get("fields", [])
    intro = current_expert.get("intro", "").lower()
    
    # 计算新问题与当前专家的相关度得分
    score = 0
    
    # 按 classify 关键词匹配
    for keyword in classify.split(","):
        keyword = keyword.strip()
        if keyword and keyword in question_lower:
            score += 3
    
    # 按 fields 领域匹配
    for field in fields:
        if field in question_lower:
            score += 2
    
    # 按 intro 关键词匹配（权重较低）
    intro_keywords = [w for w in intro.split() if len(w) >= 2]
    for kw in intro_keywords[:30]:
        if kw in question_lower:
            score += 0.5
    
    # 设置阈值：得分超过2分认为相关，沿用专家
    return score >= 2

def _get_expert_for_conversation(conversation_id: str, question: str) -> dict:
    """根据会话ID智能获取专家
    
    智能判断逻辑：
    - 如果会话不存在，重新匹配专家
    - 如果会话存在，判断新问题是否与当前专家相关
    - 相关则沿用专家，不相关则重新匹配
    
    Args:
        conversation_id: 会话ID
        question: 用户问题（用于智能判断和重新匹配）
        
    Returns:
        专家配置字典
    """
    if conversation_id and conversation_id in _conversation_expert_map:
        # 已有会话，检查是否应该沿用专家
        expert_agent_id = _conversation_expert_map[conversation_id]
        experts = _get_experts()
        current_expert = next((e for e in experts if e.get("agent_id") == expert_agent_id), None)
        
        if current_expert:
            # 智能判断是否应该沿用当前专家
            if _should_keep_expert(current_expert, question):
                return current_expert
            else:
                # 问题与当前专家不相关，移除映射并重新匹配
                _conversation_expert_map.pop(conversation_id, None)
        else:
            # 专家不存在了，移除映射
            _conversation_expert_map.pop(conversation_id, None)
    
    # 新会话、专家不存在或需要重新匹配，重新匹配专家
    expert = match_expert(question)
    if expert and conversation_id:
        # 保存会话与专家的映射
        _conversation_expert_map[conversation_id] = expert.get("agent_id")
    return expert


# ==================== 对话功能 ====================


def expert_chat(
    authorization: str,
    question: str,
    conversation_id: str = "",
    expert_agent_id: int = 0,
) -> dict:
    """与专家对话

    根据问题自动匹配专家（若未指定 expert_agent_id），然后发起对话。
    多轮对话时会沿用同一个专家。

    Args:
        authorization: 用户鉴权 token
        question: 用户问题
        conversation_id: 会话ID（多轮对话时传入）
        expert_agent_id: 指定专家的 agent_id，为 0 时自动匹配

    Returns:
        对话结果，包含 conversation_id、content、success、matched_expert
    """
    if expert_agent_id:
        experts = _get_experts()
        expert = next((e for e in experts if e.get("agent_id") == expert_agent_id), None)
        if not expert:
            return {"success": False, "error": f"未找到 agent_id={expert_agent_id} 的专家"}
    else:
        expert = _get_expert_for_conversation(conversation_id, question)
        if not expert:
            return {"success": False, "error": "暂无可用专家"}

    is_first = conversation_id == ""
    result = chat_stream_sync(
        authorization=authorization,
        message=question,
        conversation_id=conversation_id,
        is_first=is_first,
        agent_id=expert["agent_id"],
    )
    result["matched_expert"] = {
        "agent_id": expert.get("agent_id"),
        "name": expert.get("name"),
        "classify": expert.get("classify"),
    }
    return result


def expert_review(
    authorization: str,
    message: str,
    image_url: str,
    image_name: str = "design.png",
    conversation_id: str = "",
    expert_agent_id: int = 0,
) -> dict:
    """专家点评设计作品

    上传设计作品图片，根据问题自动匹配专家（若未指定），获取专业点评。
    多轮对话时会沿用同一个专家。

    Args:
        authorization: 用户鉴权 token
        message: 点评请求消息
        image_url: 设计作品图片URL
        image_name: 图片文件名
        conversation_id: 会话ID
        expert_agent_id: 指定专家的 agent_id，为 0 时自动匹配

    Returns:
        点评结果
    """
    if expert_agent_id:
        experts = _get_experts()
        expert = next((e for e in experts if e.get("agent_id") == expert_agent_id), None)
        if not expert:
            return {"success": False, "error": f"未找到 agent_id={expert_agent_id} 的专家"}
    else:
        expert = _get_expert_for_conversation(conversation_id, message)
        if not expert:
            return {"success": False, "error": "暂无可用专家"}

    # 从文件名推断文件类型
    file_type = "png"
    lower_name = image_name.lower()
    if lower_name.endswith(".jpg") or lower_name.endswith(".jpeg"):
        file_type = "jpg"
    elif lower_name.endswith(".webp"):
        file_type = "webp"
    elif lower_name.endswith(".gif"):
        file_type = "gif"

    attachment = build_attachment(
        file_name=image_name,
        file_path=image_url,
        file_type=file_type,
    )
    is_first = conversation_id == ""
    result = chat_stream_sync(
        authorization=authorization,
        message=message,
        conversation_id=conversation_id,
        is_first=is_first,
        attachments=[attachment],
        agent_id=expert["agent_id"],
    )
    result["matched_expert"] = {
        "agent_id": expert.get("agent_id"),
        "name": expert.get("name"),
        "classify": expert.get("classify"),
    }
    return result


def expert_image(
    authorization: str,
    prompt: str,
    conversation_id: str = "",
    expert_agent_id: int = 0,
) -> dict:
    """通过专家生成设计图片

    根据描述自动匹配专家（若未指定），生成设计相关图片。
    多轮对话时会沿用同一个专家。

    Args:
        authorization: 用户鉴权 token
        prompt: 图片生成描述
        conversation_id: 会话ID
        expert_agent_id: 指定专家的 agent_id，为 0 时自动匹配

    Returns:
        生成结果（内容中包含图片URL）
    """
    if expert_agent_id:
        experts = _get_experts()
        expert = next((e for e in experts if e.get("agent_id") == expert_agent_id), None)
        if not expert:
            return {"success": False, "error": f"未找到 agent_id={expert_agent_id} 的专家"}
    else:
        expert = _get_expert_for_conversation(conversation_id, prompt)
        if not expert:
            return {"success": False, "error": "暂无可用专家"}

    is_first = conversation_id == ""
    result = chat_stream_sync(
        authorization=authorization,
        message=prompt,
        conversation_id=conversation_id,
        is_first=is_first,
        agent_id=expert["agent_id"],
    )
    result["matched_expert"] = {
        "agent_id": expert.get("agent_id"),
        "name": expert.get("name"),
        "classify": expert.get("classify"),
    }
    return result


# ==================== 命令行入口 ====================


def main():
    """CLI entry point

    Usage:
        python skill.py chat <token> <question> [conversation_id] [expert_agent_id]
        python skill.py review <token> <message> <image_url> [image_name] [conversation_id] [expert_agent_id]
        python skill.py image <token> <prompt> [conversation_id] [expert_agent_id]
        python skill.py list_experts
        python skill.py match <question>
    """
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python skill.py chat <token> <question> [conversation_id] [expert_agent_id]")
        print("  python skill.py review <token> <message> <image_url> [image_name] [conversation_id] [expert_agent_id]")
        print("  python skill.py image <token> <prompt> [conversation_id] [expert_agent_id]")
        print("  python skill.py list_experts")
        print("  python skill.py match <question>")
        sys.exit(1)

    command = sys.argv[1]

    if command == "list_experts":
        result = list_experts()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if command == "match":
        if len(sys.argv) < 3:
            print("match 命令需要 question 参数")
            sys.exit(1)
        question = sys.argv[2]
        expert = match_expert(question)
        print(json.dumps(expert, ensure_ascii=False, indent=2))
        return

    if len(sys.argv) < 4:
        print("缺少必要参数")
        sys.exit(1)

    token = sys.argv[2]

    if command == "chat":
        question = sys.argv[3]
        cid = sys.argv[4] if len(sys.argv) > 4 else ""
        agent_id = int(sys.argv[5]) if len(sys.argv) > 5 else 0
        result = expert_chat(token, question, cid, agent_id)
    elif command == "review":
        if len(sys.argv) < 5:
            print("review 命令需要 message 和 image_url 参数")
            sys.exit(1)
        message = sys.argv[3]
        image_url = sys.argv[4]
        image_name = sys.argv[5] if len(sys.argv) > 5 else "design.png"
        cid = sys.argv[6] if len(sys.argv) > 6 else ""
        agent_id = int(sys.argv[7]) if len(sys.argv) > 7 else 0
        result = expert_review(token, message, image_url, image_name, cid, agent_id)
    elif command == "image":
        prompt = sys.argv[3]
        cid = sys.argv[4] if len(sys.argv) > 4 else ""
        agent_id = int(sys.argv[5]) if len(sys.argv) > 5 else 0
        result = expert_image(token, prompt, cid, agent_id)
    else:
        print(f"未知命令: {command}")
        sys.exit(1)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()