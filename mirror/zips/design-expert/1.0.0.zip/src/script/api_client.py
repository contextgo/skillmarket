#!/usr/bin/env python3
"""
Prof.Lou Design Expert - API Client Module
Handles SSE streaming communication with the backend API via httpx
"""

import json
import sys
import os
import httpx
import asyncio
import re
from typing import Callable, Optional


def _find_config_path() -> str:
    """查找 config.json 的完整路径

    查找顺序：
    1. 环境变量 DESIGN_EXPERT_CONFIG 指定的路径
    2. 固定路径：当前文件上两级目录（../../config.json，即 Skill 根目录）
    3. 当前工作目录
    4. 用户 home 目录 ~/.design_expert/config.json

    Returns:
        config.json 的完整路径，未找到时返回空字符串
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    search_paths = [
        os.environ.get("DESIGN_EXPERT_CONFIG", ""),
        os.path.normpath(os.path.join(script_dir, "..", "..", "config.json")),
        os.path.join(os.getcwd(), "config.json"),
        os.path.expanduser("~/.design_expert/config.json"),
    ]
    for path in search_paths:
        if path and os.path.isfile(path):
            return path
    return ""


def _load_config() -> dict:
    """从 config.json 加载配置

    查找顺序见 _find_config_path。
    若未找到则返回空字典，由调用方使用默认值兜底。

    Returns:
        配置字典，未找到时返回 {}
    """
    config_path = _find_config_path()
    if not config_path:
        return {}
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


_config = _load_config()
_api_config = _config.get("api", {})

# 默认 agent_id（兜底用，优先使用调用方传入的 agent_id）
_DEFAULT_AGENT_ID: int = 10074
# 公开导出的默认 agent_id
AGENT_ID: int = _DEFAULT_AGENT_ID
API_BASE_URL: str = os.environ.get(
    "PROFLOU_API_BASE",
    _api_config.get("base_url", ""),
)
_chat_endpoint_path: str = _api_config.get("chat_endpoint", "/sse/aiwriter/v1/chat")
CHAT_ENDPOINT: str = API_BASE_URL.rstrip("/") + "/" + _chat_endpoint_path.lstrip("/")
_DEFAULT_TIMEOUT: float = float(_api_config.get("timeout", 120))


def fetch_user_api_key(user_token: str) -> str:
    """调用 get_user_api_key 接口获取用户的 api_key

    Args:
        user_token: 用户登录 token，用于调用 get_user_api_key 接口的 Authorization header

    Returns:
        api_key 字符串，失败时返回空字符串
    """
    url = API_BASE_URL.rstrip("/") + "/trpc/openclaw/v1/get_user_api_key"
    headers = {"Authorization": user_token}
    try:
        import httpx as _httpx
        resp = _httpx.get(url, headers=headers, timeout=10.0)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("code") == 0:
                return data.get("api_key", "")
    except Exception:
        pass
    return ""


def save_authorization_to_config(api_key: str) -> bool:
    """将 api_key 写入 config.json 的 api.authorization 字段

    Args:
        api_key: 要写入的 api_key

    Returns:
        写入成功返回 True，否则返回 False
    """
    config_path = _find_config_path()
    if not config_path:
        return False
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        config.setdefault("api", {})["authorization"] = api_key
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def build_chat_payload(
    message: str,
    conversation_id: str = "",
    is_first: bool = True,
    attachments: Optional[list] = None,
    incr_rsp: bool = True,
    agent_id: int = 0,
) -> dict:
    """构建对话请求体

    对应后端 ChatReq 结构体，message 字段为对象格式（包含 content 和 attachments）。

    Args:
        message: 用户消息内容
        conversation_id: 会话ID，首次对话为空
        is_first: 是否为首条消息
        attachments: 附件列表（图片等）
        incr_rsp: 是否增量返回
        agent_id: 专家 agent_id，为 0 时使用默认值

    Returns:
        请求体字典，格式示例：
        {
            "agent_id": 10074,
            "message": {"content": "...", "attachments": []},
            "conversation_id": "xxx",
            "is_first": true,
            "incr_rsp": true
        }
    """
    payload: dict = {
        "agent_id": agent_id if agent_id else _DEFAULT_AGENT_ID,
        "message": {
            "content": message,
            "attachments": attachments or [],
        },
        "is_first": is_first,
        "incr_rsp": incr_rsp,
    }
    # conversation_id 为空时不传，避免后端误判
    if conversation_id:
        payload["conversation_id"] = conversation_id
    return payload


def build_attachment(file_name: str, file_path: str, file_type: str = "png", size: str = "0") -> dict:
    """构建附件对象

    对应后端 AttachmentMsg 结构体。

    Args:
        file_name: 文件名
        file_path: 文件URL路径
        file_type: 文件类型（png/jpg/pdf等）
        size: 文件大小（字节）

    Returns:
        附件字典
    """
    return {
        "file_name": file_name,
        "show": True,
        "path": file_path,
        "file_type": file_type,
        "size": str(size),
    }


def _convert_image_links_to_markdown(content: str) -> str:
    """将内容中的图片链接转换为Markdown格式
    
    识别以https://edu-aigc-开头的图片链接，转换为Markdown图片格式
    
    Args:
        content: 原始内容
        
    Returns:
        转换后的内容，图片链接已转换为Markdown格式
    """
    # 匹配以https://edu-aigc-开头的图片链接
    pattern = r'(https://edu-aigc-[^\s]+)\.(png|jpg|jpeg|gif|webp)'
    
    def replace_with_markdown(match):
        url = match.group(0)
        # 从URL中提取图片描述（使用文件名或简单描述）
        filename = os.path.basename(url).split('.')[0]
        description = f"生成的设计图片"
        return f"![{description}]({url})"
    
    # 替换所有匹配的图片链接
    return re.sub(pattern, replace_with_markdown, content)


async def chat_stream(
    authorization: str,
    message: str,
    conversation_id: str = "",
    is_first: bool = True,
    attachments: Optional[list] = None,
    on_content: Optional[Callable] = None,
    on_finish: Optional[Callable] = None,
    on_error: Optional[Callable] = None,
    timeout: float = 120.0,
    agent_id: int = 0,
) -> dict:
    """SSE 流式对话

    Args:
        authorization: 用户鉴权 token
        message: 用户消息
        conversation_id: 会话ID
        is_first: 是否首条消息
        attachments: 附件列表
        on_content: 收到内容的回调 (content: str, full_content: str)
        on_finish: 对话结束回调 (conversation_id: str, full_content: str)
        on_error: 错误回调 (error: str)
        timeout: 超时时间（秒）
        agent_id: 专家 agent_id，为 0 时使用默认值

    Returns:
        dict: {"conversation_id": str, "content": str, "success": bool}
    """
    payload = build_chat_payload(
        message=message,
        conversation_id=conversation_id,
        is_first=is_first,
        attachments=attachments,
        agent_id=agent_id,
    )

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    full_content = ""
    result_conversation_id = conversation_id

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", CHAT_ENDPOINT, json=payload, headers=headers) as response:
                if response.status_code != 200:
                    error_msg = f"请求失败，状态码: {response.status_code}"
                    if response.status_code == 401:
                        error_msg = "鉴权失败，请重新获取 token：[点击获取 token](https://edu.tencent.com/agent/#/api-keys)"
                    if on_error:
                        on_error(error_msg)
                    return {"conversation_id": conversation_id, "content": "", "success": False, "error": error_msg}

                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    # 解析 SSE 数据流
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()

                        if not line:
                            continue

                        if line.startswith("data:"):
                            data_str = line[5:].strip()
                            if not data_str:
                                continue
                            try:
                                resp = json.loads(data_str)
                            except json.JSONDecodeError:
                                continue

                            # 处理顶层错误（code != 0）
                            if resp.get("code", 0) != 0:
                                error_msg = resp.get("msg", "未知错误")
                                if on_error:
                                    on_error(error_msg)
                                return {
                                    "conversation_id": result_conversation_id,
                                    "content": full_content,
                                    "success": False,
                                    "error": error_msg,
                                }

                            # 业务数据在 data["data"] 层（LKE V2 协议）
                            data = resp.get("data", {})
                            if not data:
                                continue

                            event_type = data.get("Type", "")

                            # 流结束事件
                            if event_type == "done":
                                if on_finish:
                                    on_finish(result_conversation_id, full_content)
                                return {
                                    "conversation_id": result_conversation_id,
                                    "content": full_content,
                                    "success": True,
                                }

                            # response.completed 事件：提取 conversation_id
                            if event_type == "response.completed":
                                response_obj = data.get("Response", {})
                                cid = response_obj.get("ConversationId", "")
                                if cid:
                                    result_conversation_id = cid
                                continue

                            # message.done 事件：提取完整回复内容（Type=reply 的消息）
                            if event_type == "message.done":
                                msg_obj = data.get("Message", {})
                                if msg_obj.get("Type") == "reply":
                                    contents = msg_obj.get("Contents", [])
                                    text = ""
                                    for c in contents:
                                        if c.get("Type") == "text":
                                            text += c.get("Text", "")
                                    if text:
                                        full_content = text
                                        if on_content:
                                            on_content(text, full_content)
                                continue

                            # 其他事件（message.processing、message.added、text.delta 等）忽略

    except httpx.TimeoutException:
        error_msg = "请求超时，请稍后重试"
        if on_error:
            on_error(error_msg)
        return {"conversation_id": result_conversation_id, "content": full_content, "success": False, "error": error_msg}
    except Exception as e:
        error_msg = f"请求异常: {str(e)}"
        if on_error:
            on_error(error_msg)
        return {"conversation_id": result_conversation_id, "content": full_content, "success": False, "error": error_msg}

    # 在返回结果之前，检查内容中是否包含图片链接，转换为Markdown格式
    if full_content and "https://edu-aigc-" in full_content:
        full_content = _convert_image_links_to_markdown(full_content)
    
    return {"conversation_id": result_conversation_id, "content": full_content, "success": True}


def chat_stream_sync(
    authorization: str,
    message: str,
    conversation_id: str = "",
    is_first: bool = True,
    attachments: Optional[list] = None,
    timeout: float = _DEFAULT_TIMEOUT,
    agent_id: int = 0,
) -> dict:
    """同步版本的 SSE 流式对话（会打印流式内容到 stdout）

    Args:
        authorization: 用户鉴权 token
        message: 用户消息
        conversation_id: 会话ID
        is_first: 是否首条消息
        attachments: 附件列表
        timeout: 超时时间（秒）
        agent_id: 专家 agent_id，为 0 时使用默认值

    Returns:
        dict: {"conversation_id": str, "content": str, "success": bool}
    """

    def on_content(text, full):
        print(text, end="", flush=True)

    def on_finish(cid, full):
        print()  # 换行

    def on_error(err):
        print(f"\n[Error] {err}", file=sys.stderr)

    return asyncio.run(
        chat_stream(
            authorization=authorization,
            message=message,
            conversation_id=conversation_id,
            is_first=is_first,
            attachments=attachments,
            on_content=on_content,
            on_finish=on_finish,
            on_error=on_error,
            timeout=timeout,
            agent_id=agent_id,
        )
    )