# Design Expert - API References

## 后端接口

### SSE Chat Endpoint

### Request Body

```json
{
  "conversation_id": "",
  "message": {
    "content": "用户消息内容",
    "attachments": []
  },
  "agent_id": 10074,
  "is_first": true,
  "incr_rsp": true
}
```

### 带图片附件的请求

```json
{
  "conversation_id": "",
  "message": {
    "content": "请帮我点评这个设计作品",
    "attachments": [
      {
        "file_name": "design.png",
        "app_name": "design.png",
        "show": true,
        "path": "https://example.com/design.png",
        "file_type": "png",
        "size": "0"
      }
    ]
  },
  "agent_id": 10074,
  "is_first": true,
  "incr_rsp": true
}
```

### SSE Response Format

```
data: {"conversation_id": "xxx", "content": {"content": "增量文本"}, "stop": false}
data: {"conversation_id": "xxx", "content": {"content": ""}, "stop": true}
```

### Error Response

```
data: {"error": {"message": "错误描述"}}
```

### Agent Info

每位专家对应独立的 `agent_id`，在请求时按需传入对应专家的 `agent_id`。专家列表及其 `agent_id` 定义在 `config.json` 中，共 72 位设计领域专家，涵盖工业设计、社会创新、城市规划、视觉传达、可持续设计、设计教育等方向。

| Field | Value |
|-------|-------|
| agent_id | 见 config.json 中各专家的 agent_id 字段 |
| 专家数量 | 72 位 |
| 涵盖领域 | 工业设计、社会创新、城市规划、视觉传达、可持续设计、设计教育等 |

### Error Handling

- **401**: 鉴权失败，token 无效或过期
- **Token 缺失**: 用户未提供鉴权 token 时，同样返回上述固定提示信息。
- **Timeout**: 默认 120 秒超时
