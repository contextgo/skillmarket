#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
未来7天逐3小时天气预报查询脚本
支持全国3193个区县级城市
"""

import sys
import json
import ssl
import urllib.request
import urllib.error
from datetime import datetime, timedelta

# 导入内置城市映射表
from cities import CITY_MAP

# 腾讯云COS基础URL
COS_BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/cww3hour/"

# 创建SSL上下文
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE

# 合法的3小时时间点
VALID_HOURS = [2, 5, 8, 11, 14, 17, 20, 23]


def fuzzy_match_city(city_name, city_map):
    """
    模糊匹配城市名
    支持：精确匹配、包含匹配、前缀匹配
    """
    if not city_name:
        return None, None

    # 精确匹配
    if city_name in city_map:
        return city_map[city_name], city_name

    # 包含匹配
    matches = [(name, cid) for name, cid in city_map.items() if city_name in name]
    if matches:
        return matches[0][1], matches[0][0]

    # 前缀匹配
    matches = [(name, cid) for name, cid in city_map.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]

    return None, None


def fetch_weather_data(city_id):
    """
    从COS获取3小时天气数据
    """
    url = "{}{}.json".format(COS_BASE_URL, city_id)
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        with urllib.request.urlopen(req, timeout=15, context=SSL_CONTEXT) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise Exception("HTTP错误: {}".format(e.code))
    except Exception as e:
        raise Exception("获取数据失败: {}".format(str(e)))


def get_weather_emoji(weather_desc):
    """
    根据天气描述获取emoji
    """
    if not weather_desc:
        return "🌡️"

    desc = weather_desc

    if "晴" in desc:
        return "☀️"
    elif "多云" in desc:
        return "⛅"
    elif "阴" in desc:
        return "☁️"
    elif "雷" in desc and "阵雨" in desc:
        return "⛈️"
    elif "暴雨" in desc or "大暴雨" in desc:
        return "⛈️"
    elif "大雨" in desc:
        return "🌧️"
    elif "中雨" in desc:
        return "🌧️"
    elif "小雨" in desc:
        return "🌧️"
    elif "阵雨" in desc:
        return "🌦️"
    elif "雨夹雪" in desc:
        return "🌨️"
    elif "中雪" in desc or "大雪" in desc or "暴雪" in desc:
        return "❄️"
    elif "小雪" in desc or "阵雪" in desc:
        return "🌨️"
    elif "雪" in desc:
        return "❄️"
    elif "雾" in desc or "霾" in desc:
        return "🌫️"
    elif "沙尘" in desc or "扬沙" in desc:
        return "🌪️"
    else:
        return "🌡️"


def get_day_night_icon(is_day):
    """
    根据昼夜状态返回图标
    """
    if is_day and is_day != 0:
        return "☀️"
    return "🌙"


def find_nearest_hour(target_hour):
    """
    找到最近的合法3小时时间点
    """
    nearest = min(VALID_HOURS, key=lambda h: abs(h - target_hour))
    return nearest


def query_3hour_weather(city_name, target_date=None, target_hour=None):
    """
    查询未来7天逐3小时天气预报
    """
    # 城市匹配
    city_id, matched_name = fuzzy_match_city(city_name, CITY_MAP)
    if not city_id:
        suggestions = [name for name in CITY_MAP.keys() if city_name.lower() in name.lower()]
        if suggestions:
            raise ValueError("未找到城市: {}\n您是否想找: {}".format(
                city_name, ", ".join(suggestions[:5])))
        raise ValueError("未找到城市: {}".format(city_name))

    # 获取数据
    data = fetch_weather_data(city_id)
    if data is None:
        raise Exception("城市 {}({}) 的逐3小时预报数据不存在".format(matched_name, city_id))

    # 过滤数据
    filtered = data
    if target_date:
        filtered = [item for item in data if item.get("date") == target_date]

    if target_hour is not None:
        nearest = find_nearest_hour(target_hour)
        filtered = [item for item in filtered if item.get("hour") == nearest]

    return {
        "code": 0,
        "message": "success",
        "data": {
            "city_id": city_id,
            "city_name": matched_name,
            "total_records": len(data) if isinstance(data, list) else 0,
            "filtered_records": len(filtered) if isinstance(filtered, list) else 0,
            "weather_data": filtered
        }
    }


def print_result(result):
    """
    打印格式化结果
    """
    if result.get("code") != 0:
        print("❌ 错误: {}".format(result.get("message", "未知错误")))
        return

    data = result["data"]
    weather_list = data.get("weather_data", [])

    print("")
    print("=" * 60)
    print("📍 城市: {} (ID: {})".format(data["city_name"], data["city_id"]))
    print("🕐 预报: 未来7天逐3小时 (共{}条)".format(data["total_records"]))
    if data["filtered_records"] < data["total_records"]:
        print("🔍 筛选: 显示{}条".format(data["filtered_records"]))
    print("=" * 60)

    current_date = None
    for item in weather_list:
        date = item.get("date", "未知日期")
        hour = item.get("hour", "-")
        weather = item.get("weather", "未知")
        temperature = item.get("temperature", "-")
        wind_dir = item.get("wind_direction", "-")
        wind_power = item.get("wind_power", "-")
        is_day = item.get("is_day", 0)

        # 日期分组
        if date != current_date:
            current_date = date
            print("")
            print("📅 {}".format(date))
            print("-" * 50)

        # 格式化小时
        hour_str = "{:02d}:00".format(hour) if isinstance(hour, int) else "{}:00".format(hour)

        # 昼夜图标
        dn_icon = get_day_night_icon(is_day)

        # 天气emoji
        w_emoji = get_weather_emoji(weather)

        print("  {} {}  {} {}  {}  {} {}".format(
            dn_icon, hour_str, w_emoji, weather, temperature, wind_dir, wind_power))

    print("")
    print("=" * 60)


def main():
    """
    主函数
    """
    if len(sys.argv) < 2:
        print("用法: python3 query.py <城市名> [日期] [小时]")
        print("")
        print("参数:")
        print("  城市名   - 城市/区县名称，支持模糊匹配")
        print("  日期     - 可选，YYYY-MM-DD格式")
        print("  小时     - 可选，0-23，自动匹配最近3小时")
        print("")
        print("示例:")
        print("  python3 query.py 北京")
        print("  python3 query.py 上海 2026-04-20")
        print("  python3 query.py 广州 2026-04-20 14")
        print("")
        print("支持 {} 个城市/区县".format(len(CITY_MAP)))
        sys.exit(1)

    city_name = sys.argv[1]
    target_date = sys.argv[2] if len(sys.argv) > 2 else None
    target_hour = None
    if len(sys.argv) > 3:
        try:
            target_hour = int(sys.argv[3])
            if not (0 <= target_hour <= 23):
                print("❌ 小时参数需在0-23之间")
                sys.exit(1)
        except ValueError:
            print("❌ 小时参数需为数字")
            sys.exit(1)

    try:
        result = query_3hour_weather(city_name, target_date, target_hour)
        print_result(result)
    except Exception as e:
        print("❌ 查询失败: {}".format(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
