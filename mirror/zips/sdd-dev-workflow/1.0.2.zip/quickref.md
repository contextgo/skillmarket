# SDD 工作流快速参考

## 🚀 一键命令

### 环境检查
```bash
~/.openclaw/skills/sdd-dev-workflow/scripts/check-environment.sh
```

### 项目初始化
```bash
# 正式项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh my-project

# 临时项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh test-xyz --tmp
```

### 启动 Claude Code
```bash
cd ~/openclaw/workspace/projects/my-project
claude --permission-mode acceptEdits
```

## 📋 Speckit 命令序列

```bash
# 1. 宪法
/speckit.constitution 阅读并使用 ~/.openclaw/skills/sdd-dev-workflow/templates/constitution-enterprise.md

# 2. 规范
/speckit.specify [功能描述]

# 3. 澄清 ⚠️ 强制
/speckit.clarify
/speckit.clarify  # 第二次确认

# 4. 计划
/speckit.plan [技术栈]

# 5. 任务
/speckit.tasks

# 6. 分析 ⚠️ 强制
/speckit.analyze
/speckit.analyze  # 第二次确认

# 7. 实施
/speckit.implement 严格遵循宪法 @.specify/memory/constitution.md
```

## 🎯 完成标准

```bash
# 语法检查
python3 -m py_compile <main-file>

# 核心测试
pytest tests/ -v

# 服务启动
timeout 5 uvicorn app.main:app || true
```

## 🚨 子 Agent 驱动脚本

```bash
# 启动会话
~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  start my-project /path/to/project acceptEdits

# 执行阶段
~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  run my-project constitution "提示" 300

# 验收测试
~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  verify /path/to/project

# 检查进度
~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  status /path/to/project
```

## 📁 路径速查

| 路径 | 用途 |
|------|------|
| `projects/` | 正式项目 |
| `tmp/` | 临时项目 |
| `.specify/memory/constitution.md` | 项目宪法 |
| `specs/001-*/spec.md` | 功能规范 |
| `specs/001-*/plan.md` | 技术方案 |
| `specs/001-*/tasks.md` | 任务列表 |
| `.task-context/progress.json` | 进度跟踪 |

## ⚠️ 强制规则

### 绝对禁止
- ❌ 跳过 clarify 阶段
- ❌ 跳过 analyze 阶段
- ❌ 配置未使用的外部服务
- ❌ 生成空测试文件

### 必须执行
- ✅ clarify 至少 1 次（推荐 2 次）
- ✅ analyze 至少 1 次（推荐 2 次）
- ✅ 验收测试（语法 + pytest + 启动）
- ✅ 更新 progress.json

## 🔄 进度恢复

```javascript
// 查看进度
sessions_list({ kinds: ["isolated"] })

// 继续任务
sessions_spawn({
  task: "读取 .task-context/checkpoint.md 恢复上下文，继续执行",
  agentId: "dev-agent",
  runTimeoutSeconds: 7200
})
```

## 🐛 常见错误

| 错误 | 解决方案 |
|------|----------|
| specify init 卡住 | `specify init . --here --force --ai claude --no-git` |
| 网络错误 | 检查 Gateway：`openclaw gateway status` |
| 429 限流 | 等待 5 分钟后重试 |
| ModuleNotFoundError | 直接 `pip install <module>` |

## 📞 获取帮助

- 完整文档：`SKILL.md`
- 问题排查：`references/troubleshooting.md`
- 宪法模板：`templates/constitution-*.md`
