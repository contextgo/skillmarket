---
name: sdd-dev-workflow
version: 1.2.0
description: 规范驱动开发工作流（SDD + Speckit + Claude Code）。用于复杂软件开发项目，包含完整的规范驱动开发流程、Claude Code 交互式操作、开发最佳实践。当用户需要开发复杂应用、进行多迭代开发项目时使用此 skill。
metadata:
  { "openclaw": { "emoji": "📐", "os": ["darwin", "linux"], "requires": { "bins": ["tmux", "claude", "python3", "uv", "specify", "npm"] }, "env": ["ZHIPU_API_KEY", "GITHUB_TOKEN"], "permissions": ["filesystem:home", "network:github", "network:npm"] } }
---

# SDD 开发工作流 Skill

> **快速开始**：`quickref.md` | **完整文档**：`README.md` | **问题排查**：`references/troubleshooting.md`

## 🎯 核心理念

> **用规范驱动开发（SDD）把需求变成结构化的"规范文档"，让大语言模型在相对准确且完整的上下文中，收敛注意力，提供更符合预期的输出。**

### 三大原则

1. **规范优先（Spec First）**：开发前先编写规范，确保方向一致
2. **规范锚定（Spec Anchored）**：规范持续演进，作为长期资产
3. **规范作为源（Spec as Source）**：规范是主要源文件，代码由规范驱动生成

---

## ⚠️ 工具链协作方式（必读）

### Specify CLI 的角色

```
Specify CLI         →       Claude Code          →      完成开发
（仅用于初始化）           （执行 /speckit 命令）        （代码实现）
```

**Specify CLI 仅用于初始化**：
- ✅ `specify init` 初始化项目结构
- ❌ **不支持** clarify/plan/tasks/analyze/implement

**⚠️ Specify CLI 非交互模式**：
```bash
# 非交互式初始化（推荐）
specify init . --here --ai claude --force --no-git
```

**后续工作在 Claude Code 中执行**：
- ✅ `/speckit.constitution` 定义项目宪法
- ✅ `/speckit.specify` 创建功能规范
- ✅ `/speckit.clarify` 需求澄清
- ✅ `/speckit.plan` 实现计划
- ✅ `/speckit.tasks` 任务拆分
- ✅ `/speckit.analyze` 一致性分析
- ✅ `/speckit.implement` **代码实现（最终目标）**

### 最终目标

| ❌ 错误理解 | ✅ 正确理解 |
|------------|------------|
| 生成 spec.md | 完成代码实现 |
| 生成 plan.md | 通过测试验证 |
| 生成 tasks.md | 功能可以运行 |

**任务完成的标志**：
- ✅ 代码已实现（不是文档）
- ✅ 测试已通过
- ✅ 功能可运行

---

## 🚨 子 Agent 强制规则（CRITICAL）

> **核心原则**：子 agent = 流程驱动器（driver），不是代码实现者（implementer）

### 绝对禁止

- ❌ **禁止使用 `write` 工具写代码文件**（`src/**/*.py`, `tests/**/*.py`）
- ❌ **禁止使用 `write` 工具创建 constitution/spec/plan/tasks**
- ❌ **禁止跳过 /speckit.* 命令**
- ❌ **禁止直接实现代码**

### 必须执行

- ✅ **必须通过 `sdd-driver.sh` 脚本操作**
- ✅ **必须通过 tmux 驱动 Claude Code**
- ✅ **必须监控脚本输出并判断意外情况**
- ✅ **必须尝试自动修复常见错误**

### 意外处理原则

| 情况 | 可恢复 | 子 agent 行动 |
|------|--------|--------------|
| 429 rate limit | ✅ | 等待 5 分钟后重试 |
| timeout | ✅ | 检查输出，重启会话或增加超时 |
| stuck（输出无变化） | ✅ | 重启会话 |
| execution_error | ✅ | 让 Claude Code 修复 |
| template_missing | ❌ | **通知人工** |
| session_not_found | ❌ | **通知人工** |
| 需要补充上下文 | ❌ | **通知人工** |

### 通知人工的条件

只有在以下情况才通知人工：
1. **无法自动修复**（error.recoverable = false）
2. **需要补充上下文**（需求不明确、技术选型需决策）
3. **多次重试失败**（同类型错误超过 3 次）

### 标准流程（使用驱动脚本）

```bash
# 1. 启动会话
result=$(~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  start my-project /path/to/project acceptEdits)

# 2. 执行阶段（逐个执行，监控输出）
for phase in constitution specify clarify plan tasks analyze implement; do
  result=$(~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
    run my-project "$phase" "提示内容" 300)

  # 解析 JSON 输出
  status=$(echo "$result" | jq -r '.status')
  recoverable=$(echo "$result" | jq -r '.error.recoverable')

  if [ "$status" != "success" ]; then
    if [ "$recoverable" = "true" ]; then
      # 尝试自动修复
      handle_error "$result"
    else
      # 通知人工
      notify_human "$result"
      exit 1
    fi
  fi
done

# 3. 验收测试
result=$(~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
  verify /path/to/project)
```

### 驱动脚本返回结构

```json
{
  "phase": "constitution",
  "status": "success|error|timeout|stuck",
  "output": "最后 50 行输出...",
  "error": {
    "type": "rate_limit|timeout|stuck|execution_error|template_missing|session_not_found",
    "message": "错误描述",
    "recoverable": true|false
  },
  "timestamp": "2026-03-12T10:30:00+08:00"
}
```

---

## 📋 Speckit 工作流

### 工作流概览

```
┌─────────────────────────────────────────────────────────────┐
│                    Speckit 工作流                            │
├─────────────────────────────────────────────────────────────┤
│  1. init          → 初始化项目结构                           │
│  2. constitution  → 建立项目宪法（工程原则）                  │
│  3. specify       → 编写功能规范（what & why）               │
│  4. clarify       → 需求澄清（消除歧义）⚠️ 强制执行 ≥1 次    │
│  5. plan          → 生成实现计划（how）                      │
│  6. tasks         → 拆分任务（可执行单元）                   │
│  7. analyze       → 一致性分析（质量门禁）⚠️ 强制执行 ≥1 次  │
│  8. implement     → 自动实施（代码生成）                     │
└─────────────────────────────────────────────────────────────┘
```

**⚠️ 强制阶段（不可跳过）**：
- **clarify**：必须执行至少 1 次（推荐 2 次）
- **analyze**：必须执行至少 1 次（推荐 2 次）

即使内容看起来完整/一致，也必须由 AI 主动验证。

### 🤝 人类介入点（Human Checkpoints）

SDD 工作流中，以下阶段**必须**等待人类确认：

| 阶段 | 介入原因 | 介入方式 |
|------|----------|----------|
| **clarify** | 需求歧义需要澄清 | 发送问题 → 等待回复 |
| **analyze** | 一致性问题需要决策 | 发送报告 → 等待确认 |
| **implement** | 大规模代码变更 | 可选：发送摘要 → 等待确认 |

#### 介入判断逻辑

```
┌─────────────────────────────────────────────────────────────┐
│                    是否需要人类介入？                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  clarify/analyze 发现问题                                    │
│         │                                                    │
│         ▼                                                    │
│  ┌─────────────────────┐                                     │
│  │ 信息是否完整？       │                                     │
│  └─────────────────────┘                                     │
│      │         │                                             │
│     完整      不完整/疑义                                     │
│      │         │                                             │
│      ▼         ▼                                             │
│  ┌────────┐  ┌──────────────┐                                │
│  │ 自己决策 │  │ 转发用户确认 │                                │
│  │ 补充规范 │  │ 等待回复     │                                │
│  │ 继续执行 │  │ 收到后继续   │                                │
│  └────────┘  └──────────────┘                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### 自动决策条件（无需介入）

| 情况 | 我的处理 |
|------|----------|
| 信息完整，只是细节缺失 | 基于最佳实践自行补充 |
| 常规技术选择（如用 requests 还是 httpx） | 选择主流方案，记录理由 |
| 宪法已有明确规定 | 直接遵循宪法执行 |
| clarify 连续 2 次无问题 | 自动进入下一阶段 |
| 简单项目，需求明确 | 全程自动化 |

#### 需要介入的条件

| 情况 | 原因 |
|------|------|
| 多个方案各有优劣，需要业务决策 | 我无法判断业务优先级 |
| 需求有明显矛盾或冲突 | 需要澄清真实意图 |
| 涉及外部依赖或资源 | 需要确认可用性 |
| 超出宪法规定的边界 | 需要明确约束 |
| analyze 发现严重一致性问题 | 需要决定修复方向 |

### 阶段详解

#### 阶段 1：初始化（specify init）

```bash
# 安装 Speckit
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# 初始化新项目
specify init <项目名称>

# 在现有项目中初始化
specify init .
```

#### 阶段 2-8：Claude Code 阶段

所有后续阶段在 Claude Code 中使用 `/speckit.*` 命令执行。

详见：[quickref.md](quickref.md)

---

## 🏛️ 公共宪法模板

### 为什么需要公共宪法？

宪法是项目的通用工程原则，不应该每次新项目都从零开始。

### 使用方式

```bash
# 在 Claude Code 中引用公共宪法
/speckit.constitution 阅读并使用公共宪法模板 ~/.openclaw/skills/sdd-dev-workflow/templates/constitution-enterprise.md
```

**模板位置**：`templates/constitution-enterprise.md`（推荐）或 `templates/constitution-lite.md`

详见：[references/constitution-guide.md](references/constitution-guide.md)

---

## 📁 项目路径规范

### 标准目录结构

```
~/openclaw/workspace/
├── projects/                    # 正式开发项目（长期维护）
├── tmp/                         # 临时项目（验证、测试，可随时清理）
├── docs/                        # 文档（可选，按需创建）
├── research/                    # 深度研究报告
└── memory/                      # 日期日记
```

### 路径规则

| 类型 | 路径 | 示例 |
|------|------|------|
| **正式项目** | `projects/<name>/` | `projects/my-app/` |
| **临时项目** | `tmp/<name>/` | `tmp/test-workflow/` |
| **研究报告** | `research/<topic>/` | `research/ai-sovereignty/` |

### 新项目创建规范

```bash
# ✅ 正式项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh my-project

# ✅ 临时项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh test-xyz --tmp

# ❌ 错误：在 workspace 根目录创建
cd ~/openclaw/workspace
specify init my-project  # 错误！
```

---

## 📦 依赖安装原则

> **目标**：完成开发，不为依赖停顿

### 核心原则

**遇到依赖缺失 → 直接安装，不询问**

```python
# 运行时缺少依赖
ModuleNotFoundError: No module named 'redis'
→ 直接执行：pip install redis
```

---

## 🚀 快速开始模板

### 场景 A：全新项目

```bash
# 1. 初始化项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh my-project
cd ~/openclaw/workspace/projects/my-project

# 2. 启动 Claude Code
claude --permission-mode acceptEdits

# 3. 执行 Speckit 工作流
/speckit.constitution 阅读并使用 ~/.openclaw/skills/sdd-dev-workflow/templates/constitution-enterprise.md
/speckit.specify [功能描述]
/speckit.clarify    # ⚠️ 强制
/speckit.plan [技术栈]
/speckit.tasks
/speckit.analyze    # ⚠️ 强制
/speckit.implement 严格遵循宪法规范
```

### 场景 B：使用子 Agent（推荐）

```javascript
sessions_spawn({
  task: `
    开发 [项目描述]

    ## 🚨 强制规则

    **角色定位**：你是流程驱动器（driver），不是代码实现者

    **必须执行**：
    - ✅ 通过 \`sdd-driver.sh\` 脚本操作 Claude Code
    - ✅ 监控脚本输出，判断意外情况
    - ✅ 尝试自动修复可恢复错误
    - ✅ 仅在无法修复或需要补充上下文时通知人工

    ## 标准流程

    \`\`\`bash
    # 1. 初始化项目（如需要）
    cd ~/openclaw/workspace/projects/your-project
    specify init . --here --ai claude --force --no-git

    # 2. 启动 Claude Code 会话
    ~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
      start dev-session . acceptEdits

    # 3. 逐个执行阶段
    ~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
      run dev-session constitution "创建项目宪法" 300

    # ... 继续其他阶段

    # 4. 验收测试
    ~/.openclaw/skills/sdd-dev-workflow/scripts/sdd-driver.sh \
      verify .
    \`\`\`

    ## 完成标准

    - ✅ 代码已实现（不是文档）
    - ✅ 测试已通过（至少 1 个核心测试）
    - ✅ 功能可运行（服务能启动）
  `,
  agentId: "dev-agent",
  runTimeoutSeconds: 7200
})
```

详见：[references/autonomous-agent.md](references/autonomous-agent.md)

---

## 🔄 长时间运行 Agent

### 核心问题

长时间运行 Agent 面临的挑战：

| 挑战 | 说明 |
|------|------|
| **上下文丢失** | Context window 溢出，忘记之前的工作 |
| **进度中断** | 网络断开、服务重启导致任务中断 |
| **状态不可知** | 不知道任务执行到哪一步 |
| **无法恢复** | 中断后无法从断点继续 |

### 解决方案：断点续传机制

所有项目默认支持断点续传：

```
.task-context/
├── progress.json     # 进度跟踪
├── checkpoint.md     # 检查点快照
└── session-log.md    # 会话日志（可选）
```

### 恢复中断的任务

**方式1：sessions_spawn 继续执行（推荐）**

```javascript
sessions_spawn({
  task: "继续开发 [项目名]，读取 .task-context/checkpoint.md 恢复上下文",
  agentId: "dev-agent",
  runTimeoutSeconds: 7200
})
```

**方式2：手动继续**

直接对话描述任务，我会自动读取 checkpoint.md 恢复上下文。

### 自动化监控

Heartbeat 会自动检查所有 in_progress 任务的进度，发现异常时通知。

---

## 📐 开发最佳实践

### 1. 需求表达原则

| 原则 | 说明 | 示例 |
|------|------|------|
| **结构化** | 使用规范文档而非散落 prompt | spec.md > 对话记录 |
| **可追溯** | 需求有明确来源和理由 | "因为 X，所以需要 Y" |
| **可验证** | 有明确的验收标准 | "支持 100 并发请求" |

### 2. 质量控制

```
┌─────────────────────────────────────────┐
│              质量门禁                    │
├─────────────────────────────────────────┤
│  clarify → 连续2次无问题                 │
│  analyze → 连续2次无问题                 │
│  implement → 每阶段测试通过              │
└─────────────────────────────────────────┘
```

### 3. 迭代管理

| 场景 | 处理方式 |
|------|----------|
| **需求变更** | 开启新迭代周期，新建分支 |
| **Bug 修复** | Agent 实现导致的 → 直接 prompt 修复<br>规范问题 → 新迭代 |
| **功能扩展** | 新迭代，MVP 先行 |
| **上下文丢失** | 规范文档是锚点，不依赖对话 |

---

## 📁 项目目录结构

```
project-root/
├── .specify/
│   ├── memory/
│   │   └── constitution.md    # 项目宪法
│   ├── scripts/               # 辅助脚本
│   └── templates/             # 规范模板
├── specs/
│   └── 001-<feature>/
│       ├── spec.md            # 功能规范
│       ├── plan.md            # 技术方案
│       ├── tasks.md           # 任务拆分
│       ├── data-model.md      # 数据模型
│       ├── research.md        # 技术调研
│       └── contracts/         # API 契约
├── src/                       # 源代码
└── tests/                     # 测试代码
```

---

## ⚠️ 常见问题

详见：[references/troubleshooting.md](references/troubleshooting.md)

快速参考：
- **specify init 卡住** → `specify init . --here --force --ai claude --no-git`
- **网络错误** → `openclaw gateway status`
- **429 限流** → 等待 5 分钟后重试
- **ModuleNotFoundError** → 直接 `pip install <module>`

---

## 🔧 问题排查清单

遇到问题时按此顺序检查：

```
1. [ ] Gateway 是否正常运行？
   → openclaw gateway status

2. [ ] 大模型 API 是否可用？
   → 测试简单对话

3. [ ] 环境依赖是否满足？
   → ~/.openclaw/skills/sdd-dev-workflow/scripts/check-environment.sh

4. [ ] Speckit 是否可用？
   → specify --help

5. [ ] 网络是否通畅？
   → curl -s https://api.github.com | head -5
```

---

## 📚 参考文档

| 文档 | 用途 | 何时阅读 |
|------|------|----------|
| [README.md](README.md) | 安装指南 | 首次安装时 |
| [quickref.md](quickref.md) | 快速参考卡 | 开发中速查 |
| [references/autonomous-agent.md](references/autonomous-agent.md) | 子 agent 模式 | 使用 sessions_spawn 时 |
| [references/constitution-guide.md](references/constitution-guide.md) | 宪法模板指南 | 定制项目宪法时 |
| [references/troubleshooting.md](references/troubleshooting.md) | 问题排查 | 遇到错误时 |

---

## ⚠️ 安全警告

- 本 skill 包含 `bypassPermissions` 模式，会跳过 Claude Code 权限检查
- 脚本会执行全局 npm 安装和 `curl | sh` 安装器
- 需要 GitHub Token 和智谱 API Key（建议使用最小权限）

**安装前检查清单**：
- [ ] 检查 `scripts/` 目录下的脚本内容
- [ ] 确认不需要在敏感环境中运行
- [ ] 准备最小权限的 GITHUB_TOKEN
- [ ] 准备智谱 API Key

---

## 🔗 相关资源

- [Speckit 官方文档](https://github.com/github/spec-kit)
- [Claude Code 文档](https://docs.anthropic.com/claude-code)
- [ClawHub](https://clawhub.com) - Skill 分发平台
