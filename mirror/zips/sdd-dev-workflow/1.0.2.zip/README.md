# SDD 开发工作流 Skill

> 规范驱动开发（SDD）+ Speckit + Claude Code 完整工作流

## 🎯 核心理念

**用规范驱动开发（SDD）把需求变成结构化的"规范文档"，让大语言模型在相对准确且完整的上下文中，收敛注意力，提供更符合预期的输出。**

## ⚡ 快速开始

### 1. 安装依赖

```bash
# 检查环境
~/.openclaw/skills/sdd-dev-workflow/scripts/check-environment.sh

# 安装缺失依赖
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git
npm install -g @anthropic-ai/claude-code
```

### 2. 创建项目

```bash
# 正式项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh my-project

# 临时项目
~/.openclaw/skills/sdd-dev-workflow/scripts/init-project.sh test-xyz --tmp
```

### 3. 启动开发

```bash
cd ~/openclaw/workspace/projects/my-project
claude --permission-mode acceptEdits
```

### 4. 执行 Speckit 工作流

在 Claude Code 中执行：

```bash
/speckit.constitution 创建项目宪法
/speckit.specify 描述功能需求
/speckit.clarify    # ⚠️ 强制执行至少1次
/speckit.plan 技术栈选择
/speckit.tasks
/speckit.analyze    # ⚠️ 强制执行至少1次
/speckit.implement 严格遵循宪法
```

## 📚 文档导航

| 文档 | 用途 | 何时阅读 |
|------|------|----------|
| [SKILL.md](SKILL.md) | 完整技能定义 | 开发前必读 |
| [quickref.md](quickref.md) | 快速参考卡 | 开发中速查 |
| [references/autonomous-agent.md](references/autonomous-agent.md) | 子 agent 模式 | 使用 sessions_spawn 时 |
| [references/constitution-guide.md](references/constitution-guide.md) | 宪法模板指南 | 定制项目宪法时 |
| [references/troubleshooting.md](references/troubleshooting.md) | 问题排查 | 遇到错误时 |

## 🔧 工具链

```
Specify CLI         →       Claude Code          →      完成开发
（仅用于初始化）           （执行 /speckit 命令）        （代码实现）
```

**Specify CLI 仅用于初始化**：
- ✅ `specify init` 初始化项目结构
- ❌ **不支持** clarify/plan/tasks/analyze/implement

**⚠️ Specify CLI 非交互模式**：
```bash
specify init . --here --ai claude --force --no-git
```

## 🚨 核心规则

### 强制阶段（不可跳过）

- **clarify**：必须执行至少 1 次
- **analyze**：必须执行至少 1 次

即使内容看起来完整，也必须由 AI 主动验证。

### 最终目标

| ❌ 错误理解 | ✅ 正确理解 |
|------------|------------|
| 生成 spec.md | 完成代码实现 |
| 生成 plan.md | 通过测试验证 |
| 生成 tasks.md | 功能可以运行 |

### 完成标准

- ✅ 代码已实现（不是文档）
- ✅ 测试已通过（至少 1 个核心测试）
- ✅ 功能可运行（服务能启动）

### 核心原则

> **可运行 > 完整性**

禁止：
- ❌ 配置未使用的外部服务
- ❌ 生成空测试文件
- ❌ 只写代码不验证

## 🛠️ 辅助脚本

| 脚本 | 功能 |
|------|------|
| `scripts/check-environment.sh` | 环境检查 |
| `scripts/init-project.sh` | 项目初始化 |
| `scripts/sdd-driver.sh` | 子 agent 驱动脚本 |
| `scripts/claude-code-helper.sh` | tmux 操作辅助 |

## 📁 项目路径规范

| 类型 | 路径 | 示例 |
|------|------|------|
| **正式项目** | `projects/<name>/` | `projects/my-app/` |
| **临时项目** | `tmp/<name>/` | `tmp/test-workflow/` |
| **研究报告** | `research/<topic>/` | `research/ai-sovereignty/` |

## ⚠️ 安全警告

- 本 skill 包含 `bypassPermissions` 模式，会跳过 Claude Code 权限检查
- 脚本会执行全局 npm 安装和 `curl | sh` 安装器
- 需要 GitHub Token 和智谱 API Key（建议使用最小权限）

**安装前检查清单**：
- [ ] 检查 `scripts/` 目录下的脚本内容
- [ ] 确认不需要在敏感环境中运行
- [ ] 准备最小权限的 GITHUB_TOKEN
- [ ] 准备智谱 API Key

## 📋 常见问题

详见：[references/troubleshooting.md](references/troubleshooting.md)

## 🔗 相关资源

- [Speckit 官方文档](https://github.com/github/spec-kit)
- [Claude Code 文档](https://docs.anthropic.com/claude-code)
- [ClawHub](https://clawhub.com) - Skill 分发平台
