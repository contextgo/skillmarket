---
name: obsidian-brain
description: Agent跨会话记忆——任务前搜agent memory L0→L1→L2分层加载，任务结束LLM提取事实→哈希去重→写入碎片。禁type/[[链接]]/related_fragments
version: 1.5.0
author: Hermes Agent
license: MIT
agent_trigger: 当需要读写跨会话记忆碎片、搜索Obsidian库中已有知识上下文、或任何涉及agent memory文件夹的操作时加载
metadata:
  hermes:
    tags: [obsidian, agent-memory, knowledge-graph, token-saving]
---

# Obsidian Brain — Agent 记忆系统

对话开始搜 agent memory，任务结束写回。读：L0→L1→L2。写：LLM提取→去重→碎片化。

## 碎片格式

文件名：`{项目} - {YYYY-MM-DD} - {描述}.md`

```yaml
---
tags: [agent-memory]
project: 项目名
date: 2026-05-05
summary: 一句话概述（L0扫描用）
importance: 0.8
confidence: 0.9          # 可选
source: conversation     # 可选
---
# 标题

## 关键发现 / 决策 / 待查
```

**禁写字段：** `type` `related_fragments` `[[链接]]`。碎片纯文本，不属KG图谱。用 `project` 字段分组代替关联。

## L0/L1/L2 分层

| 层 | 加载内容 | 时机 |
|:--|:-----|:-----|
| L0 | frontmatter: `summary` `tags` `importance` | 搜到即加载 |
| L1 | 正文 | L0确认相关 |
| L2 | 同 project 其他碎片 | L1不够时 `search_files` |

## 写入

**判断（什么该记）：** 决策/结论/价格数据、踩坑教训、调研发现 ✔ | 临时计算、一次性信息 ✘

**流程：** LLM从结果提取关键事实 → 去重（有相似碎片且度>0.8→合并更新）→ 写 `.md`

## 读出

**顺序：** agent memory/ → 知识库skill(agent_trigger) → 概念/某物(abstract) → 网络

**排序：** `相关性×0.5 + importance×0.3 + e^(-0.01×days)×0.2`

## 维护

- `importance<0.3` 且 90天未访问 → `_archive/`
- 同 project 碎片 > 20 → 生成 L2 总结合并

## 执行流程

```
0. ⚠️ 读 agent memory（不可跳过）
   search_files → L0 → 相关则L1 → 注入上下文
1~N. 执行任务（中途转向时重搜）
N+1. ⚠️ 写 agent memory（不可跳过）
   三问：决策/结论/发现？踩坑/教训？下次需要？
   任一"是" → 立即写入，同轮次完成。不等不拖。
```

## 触发约束

- **AGENTS.md**：对话开始强制搜 + 任务结束强制写
- **流程第0步**：任务前必搜，优先于网络/知识库
- **📋 留位**：每次回复末尾检查
- **失效保护**：连续3次漏读/漏写 → 下次加载时回溯

## 速查

```
读: 任务前→搜碎片L0→L1→L2  写: LLM提取→去重→碎片化
禁: type/[[链接]]/related_fragments
排: 0.5×相关+0.3×importance+0.2×时间
维: <0.3且90天→archive   >20碎片→总结
```

## 陷阱

- **忘读** → AGENTS.md 系统约束，不靠自觉
- **忘写** → 三问+同轮次+📋留位
- **碎片写type/[[链接]]/related_fragments** → 禁止。纯文本
