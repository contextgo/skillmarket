# Checklists

Use these checklists when the task is complex, business-rule heavy, or likely to need review loops.

## Requirement Restatement Checklist

- Did I restate the goal in my own words?
- Did I separate current behavior from expected behavior?
- Did I identify affected modules, interfaces, tables, caches, and external systems?
- Did I identify out-of-scope items?
- Did I identify ambiguities and convert them into direct questions?
- For business-rule tasks, did I convert the requirement into scenarios or a scenario matrix draft?

## Technical Approach Checklist

- Did I list the touched modules and files?
- Did I explain how data changes flow through main tables, record tables, cache, and external systems?
- Did I describe rollback or blast-radius concerns when relevant?
- Did I list the primary risks?
- Did I define a validation strategy?

## Implementation Plan Checklist

- Does each step correspond to a concrete action?
- Are expected file touch points explicit?
- Are documentation updates included?
- Are verification steps included?
- Is the plan minimal rather than expansive?

## Review Checklist

- Does the implementation match the confirmed requirement?
- Does it still match the approved technical approach?
- Does it still match the approved plan?
- Are there regression risks?
- Are there data consistency or cache risks?
- Are there missing tests or missing scripts?
- Are there missing docs?
- Can findings be grouped into:
  - 必须修复
  - 需要你确认
  - 可接受残留

## Testing Checklist

- Did I run static or smoke checks if available?
- Did I run compile or build validation?
- Did I run targeted automated tests if available?
- Did I run script-based or integration validation where useful?
- If SIT is needed, did I stay within safe, non-destructive boundaries?
- Did I record what I could not test?

## Commit Scope Checklist

- Are all staged files directly related to the task?
- Have I excluded local config changes by default?
- Have I excluded logs, temp files, and build artifacts?
- If config files remain, do I have explicit approval and a clear reason?
