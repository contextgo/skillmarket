---
name: capital-market-report
description: Generate high-signal, impact-driven capital market anomaly and rumor reports. Focuses on actionable business signals, expectation-breaking news, and deep logical deduction rather than routine index reading. Uses local scanners to digest Chinese and global financial media, Reddit, and Twitter. Features strict market-isolation rules to prevent cross-border misattribution and requires real source URLs.
---

# Capital Market Report (High-Signal Anomaly Edition)

Generates forward-looking business deduction reports based on an "Absolute Impact Threshold." This skill abandons traditional macroeconomic index reading (e.g., "Nasdaq down 1%"), shifting instead to deep scraping of domestic and international forums, news, and social media to lock in supply-chain anomalies and earnings explosion points with extreme expectation gaps.

## Core Philosophy (Absolute Impact Threshold)

1. **Zero Routine Data**: No longer reports routine market data like index points or daily percentage changes. Focuses entirely on nuclear-level anomalies in the business world.
2. **Dynamic Capacity**: Abolishes mechanical rules like "must have 3-5 items." If only 2 events meet the threshold today, report 2; if 8 major global supply-chain-shaking news break, report all 8.
3. **Core on Selected Assets, Inclusive of Global Leaders**: While deeply scanning specific target assets (e.g., Chinese ADRs, A/HK tech stocks, AI/consumer/EV supply chains), it absolutely must not miss strategic turning points from global tech giants (e.g., the "Magnificent Seven" or core global AI leaders).

## Execution Pipeline & Toolchain

### Step 1: Launch Underlying Scanners

You must run the following information scraping tools:

**1. Chinese Financial Core News Scraper** (Scraping domestic sources like Cailianshe, Wall Street CN, Sina Finance):
```bash
cd ~/.openclaw/skills/capital-market-report; uv run scripts/news-processor.py --delta --delta
```

**2. Overseas Anomaly & Rumor Radar** (Monitoring Reddit WSB, CoinGecko, Yahoo Finance movers, Google News rumors):
*(Note: Requires the `stock-analysis` skill to be installed)*
```bash
uv run ~/.openclaw/skills/stock-analysis/scripts/hot_scanner.py
uv run ~/.openclaw/skills/stock-analysis/scripts/rumor_scanner.py
```

### Step 2: Comprehensive Inclusion of Major Market Events

From the scraped results, retain news based on the following rules:
- **Include All High-Attention Events**: Any news heavily discussed by the market (e.g., major AI model releases like Claude/GPT updates, big tech earnings, macro data, geopolitical shifts) **MUST** be included, even if they perfectly meet market expectations. Do not filter out highly focused topics.
- **Retain Anomalies**: Keep extremely strong earnings reversals, supply-chain-level product delays, or major rumors.
- **Red Line**: Do not aggressively filter out major news just because it lacks a "shock" factor. If the market cares, it goes in the report.

### Step 3: Mandatory Source Tracking (Real URL Verification)

**Red Line**: Every piece of news reported must include a real source URL `[Read Original](URL)`. 
- The URL is natively extracted and provided by the underlying `news-processor.py` script from the original RSS or HTML feeds.
- Do not invent URLs or use generic domain homepages. Rely on the exact link returned by the scripts.

### Step 4: Isolated Deduction & Localization

Perform strict logical deduction on the selected events:
- **推测性内容红线（绝对禁止）**: 任何涉及具体公司立场、态度、游说方向、战略意图的判断，必须有原文明确依据。如果原文没有提及，**直接删除该条点评，不要猜测**。禁止用"可能"、"倾向于"、"说明"等词包装无原文依据的推断。宁可不写，不可编造。
- **Market Isolation Red Line**: Rigorously distinguish the "country/market" where the anomaly occurred. For example, a surge in US domestic airfares can only be deduced as bullish for US airlines and US OTAs; it **absolutely cannot be forcefully applied** to Chinese companies like Trip.com.
- If the event is a shock to an overseas giant (e.g., Honda taking a massive loss), the deduction must clarify whether the logical link to its global competitors genuinely holds up.
- **Language Localization**: Although this skill description is in English, the final report generated **MUST** be written in the user's primary conversational language (e.g., if the user communicates in Chinese, the report must be in Chinese).

### Step 5: Rolling Updates & Delta Extraction (Temporal Event Tracking)

For multi-source concurrency or rolling reports on the same market event, **DO NOT simply discard duplicate news items**. Instead, apply strict "Delta Extraction" tracking based on time:
- **Definition of Delta**: "Delta" means **new information added since the last generated report** (temporal delta), NOT whether the news broke market expectations.
- **Baseline Comparison**: You MUST read the previous report from `~/.openclaw/workspace-group/memory/last_capital_market_report.md` before generating the new report. Use it to compare newly scraped news against the *previous report's* coverage of the same event.
- **Extract Delta (New Information)**: Specifically pull out any new data, new official statements, or new market reactions that weren't in the previous report.
- **Visual Labeling**: Use tiered labeling for event tracking updates. For example:
  - `🔴 [增量更新 - 关键细节/市场反应]` for news containing substantial new facts since the last report.
  - `⚪ [跟进报道 - 与上次相比无新增]` for news that merely repeats facts already covered in the previous report.
- **Save State**: After generating the new report, you MUST overwrite `~/.openclaw/workspace-group/memory/last_capital_market_report.md` with the exact text of the new report so it is available for the next run.

## Telegram 排版规则（强制）

- **绝对禁止使用表格（table）** — Telegram 中表格渲染极差，无法阅读
- 所有信息使用 **列表（- / 1.）**、**粗体**、**emoji** 组织呈现
- 多组数据对比用列表嵌套或分段展示

## 🔴 防幻觉强制规则（Anti-Hallucination Guardrails）

**每次生成报告前必须逐条检查，违反任何一条 = 报告作废。**

### 规则1：时间校验（Temporal Verification）
- 每一条涉及公司财报、盘后涨跌、经济数据的新闻，必须确认该事件是否已在**当前北京时间**发生。
- **盘后数据规则**：北京时间 06:00 之前（美东 18:00 之前），不存在当日美股盘后数据。北京时间 21:00 之前，不存在当日美股收盘数据。
- 如果盘后数据尚未产生，**绝对不写盘后涨跌幅**。

### 规则2：财年 vs 日历年（Fiscal vs Calendar Year）
- 警惕标题中的 "Q1 2026"——部分公司（微软等）财年始于7月，"fiscal Q1 2026" 可能是 2025年7-9月的旧数据。
- 必须区分**财年季度**和**日历季度**。若无法确认，标注 "⚠️ 时间存疑"。

### 规则3：来源可信度分级（Source Credibility）
- 🔴 **禁止引用**：Clarqo、Briefly、Quartz 等 AI 内容聚合/摘要站，如果其内容涉及**尚未发生的事件**（如财报结果发布于实际财报日之前），直接丢弃该条。
- 🟡 **谨慎引用**：AI 生成的内容农场——如果同一事件在 BBC/Reuters/Bloomberg 等可信源中找不到交叉验证，直接丢弃。
- 🟢 **可信来源**：Reuters、Bloomberg、BBC、WSJ、FT、CNBC、官方 IR 页面、公司新闻稿。

### 规则4：如实汇报（Honest Reporting）
- 如果某条新闻无法确认时间或来源真伪，在报告中标注 "⚠️ 无法确认时间/来源"，**而不是编造细节**。
- **宁缺毋滥**：如果只有一个可靠来源，就只报一个。绝不为了凑篇幅而引用可疑来源。

### 规则5：交叉验证（Cross-Verification）
- 涉及具体财务数据（营收、EPS、增速、涨跌幅）的新闻，必须有**至少一个可信来源**的交叉验证。
- 如果所有来源都是 AI 内容农场或无法验证，**该条丢弃**。

## 翻译规则

- **英文标题必须翻译为中文**: 报告中出现的带 `[EN]` 标签的英文标题，必须翻译为中文，同时保留英文原标题在括号中。
- 格式: `中文翻译（English Original Title）`
- 翻译由模型在生成报告时完成，news-processor.py 仅负责数据采集。

## 中英文新闻平衡规则

- **每条报告必须至少包含3-5条 🇨🇳 中国公司/中国市场的新闻**
- 不要只关注美国科技巨头，中国企业（A股、港股、中概股）的动态必须占据显著篇幅
- 如果某时段中国新闻偏少，可以适当多选取几条；如果重大中文新闻密集，可以超过英文数量

## 🔬 行业先行指标扫描（每报必查）

**简报核心目标：帮 Phil 赚钱，不是了解国际形势。先行信号同时关注利好和利空——做空信号的交易价值与做多信号完全对等。**

### 通用框架（适用所有行业）

| 信号类别 | 通用问题 | 可信数据源 |
|----------|----------|------------|
| 产能/供给 | 行业产能收缩/扩张？减产/转产/停产？ | 公司财报/电话会、行业研究 |
| 价格/成本 | 上游原材料/中间品价格异动？合约价趋势？ | 行业定价基准 |
| 订单/需求 | 龙头在手订单/backlog/交期变化？ | 电话会transcript、供应链调研 |
| capex/资本 | 下游大客户资本开支调整？行业capex周期？ | 大客户财报、行业capex指引 |

### AI 全产业链监控

**传导链路**：上游硬件 → 中游云设施 → 下游应用（间隔2-4周）

🔴 **上游硬件**（最先感知）：
- GPU出货/交期（NVDA）
- HBM产能售罄年份（MU/SK Hynix/Samsung）
- NAND/HDD库存水平（WDC/STX/SNDK）
- 服务器CPU出货（INTC/AMD）
- 电力/冷却基础设施

🟡 **中游云设施**（验证需求）：
- 四大云厂商（AMZN/MSFT/GOOGL/META）capex指引
- AI收入增速
- 数据中心开工/电力合同

🟢 **下游应用**（验证商业化）：
- 企业AI支出/订阅增速
- AI终端设备出货
- 自动驾驶/Robotaxi扩张
- AI广告/搜索收入
- 🇨🇳 中国AI应用：微信AI/百度AI/字节豆包用户量 → 小米AI手机/PC出货 → 比亚迪/小鹏智能驾驶

### 标注规则

- 单一先行指标触发 → `⚡ [行业 先行信号]`
- 同一行业 2+ 指标同时触发 → `🔥🔥🔥 [行业 多重先行信号]`
- 跨行业共振（如芯片+云capex同时亮灯）→ `🚨🚨🚨 [全链条先行信号共振]` — 最高级别预警

### 监控板块（非公司白名单）

> **公司列不完。以下为板块索引——实际监控从news-processor.py抓取的所有新闻动态匹配，不限所列名称。**

**AI上游硬件**：GPU/加速器(NVDA/寒武纪/海光等)、HBM/DRAM(MU/SK Hynix/Samsung等)、NAND/HDD(WDC/STX等)、CPU(INTC/AMD/ARM等)
**🇨🇳 中国半导体**：AI芯片设计(寒武纪/海光等)、晶圆代工(中芯/华虹等)、服务器/算力(中科曙光/浪潮等)、存储(长江存储/长鑫等)
**AI中游云**：超大规模(AMZN/MSFT/GOOGL/META)、🇨🇳 中国云(腾讯/阿里/百度/华为)、数据中心REITs
**AI下游**：企业AI软件(PLTR/CRM等)、🇨🇳 AI应用(科大讯飞/金山等)、AI终端(苹果/小米)、自动驾驶(Waymo/PONY/百度/Tesla)
**能源/电力**：数据中心电力(VRT/CEG)、电网
**消费/出海**：电商(PDD/阿里/美团/京东)、新能源车(比亚迪/小米/蔚小理)

**传导顺序**：HBM内存（最先被抽空） → SSD/HDD存储 → CPU处理器（最后验证）。全链条传导时间约6-8周。

## Report Output Format

以下为最终模板，每条报告严格按此格式输出。

### 顶部区域（必须）

```markdown
📊 **资本市场绝对影响力简报 | YYYY-MM-DD HH:MM**

⚠️ **Delta说明**：vs 上一版（HH:MM）。X小时增量：[核心变化简述，5-8项关键词]

---

## 🔬 先行信号扫描

| 象限 | 板块 | 状态 | 信号 |
|------|------|------|------|
| 产能/供给 | ... | 🟢/⚡/🔥 | ... |
| 价格/成本 | ... | ... | ... |
| 订单/需求 | ... | ... | ... |
| capex/资本 | ... | ... | ... |

**综合判断**：[无异常 / ⚡单信号 / 🔥🔥🔥多重信号 / 🚨🚨🚨全链条共振]

---
```

### 主体区域：增量新闻 + 严谨推导

每条新闻按以下格式，逐条排列：

```markdown
## 🟢/🔴/🟡 [增量类型 — 事件标题] emoji

**vs HH:MM版增量**：[一句话说明与上一版的差异]

**来源**：来源A（[阅读原文](真实URL)）/ 来源B（[阅读原文](真实URL)）🟢/🟡 可信度标注

**核心**：
- 关键数据/事实点1
- 关键数据/事实点2

**严谨推导**：
- 🟢/🔴/🟡 多角度推导
- 🇨🇳 如涉及中国市场，单独标注
- ⚡ 如涉及先行信号，单独标注
```

**增量类型标签**：
- `[增量更新]` — 已在上版覆盖，本版有新的细节/数据/反应
- `[全新]` — 上版未覆盖的新事件
- `[跟进]` — 进展有限，做简要追踪

### 底部区域（必须）

```markdown
## 📋 本版 vs HH:MM版 核心Delta总结

| 事件 | 方向 | HH:MM状态 | 当前状态 |
|------|------|-----------|----------|
| ... | 🟢/🔴 | ... | ... |

## 🔥 关键日历窗口

| 时间 | 事件 | 重要性 |
|------|------|--------|
| ... | ... | 🔥🔥🔥🔥🔥 |

---

⚠️ **防幻觉校验**：✅ 逐条确认...

⏰ 数据截止：...
*⚠️ 免责：基于公开信息，不构成投资建议。*
```