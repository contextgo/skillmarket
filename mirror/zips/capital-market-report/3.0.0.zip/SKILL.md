---
name: capital-market-report
description: Generate high-signal, impact-driven capital market anomaly and rumor reports. Focuses on actionable business signals, expectation-breaking news, and deep logical deduction rather than routine index reading. Uses local scanners to digest Chinese and global financial media, Reddit, and Twitter. Features strict market-isolation rules to prevent cross-border misattribution and requires real source URLs.
---

# Capital Market Report (High-Signal Anomaly Edition)

Generates forward-looking business deduction reports based on an "Absolute Impact Threshold." This skill abandons traditional macroeconomic index reading (e.g., "Nasdaq down 1%"), shifting instead to deep scraping of domestic and international forums, news, and social media to lock in supply-chain anomalies and earnings explosion points with extreme expectation gaps.

## Core Philosophy (Absolute Impact Threshold)

1. **Zero Routine Data**: No longer reports routine market data like index points or daily percentage changes. Focuses entirely on nuclear-level anomalies in the business world.
2. **Dynamic Capacity**: Abolishes mechanical rules like "must have 3-5 items." If only 2 events meet the threshold today, report 2; if 8 major global supply-chain-shaking news break, report all 8.
3. **Core on Selected Assets, Inclusive of Global Leaders**: While deeply scanning specific target assets (e.g., Chinese ADRs, A/HK tech stocks, AI/consumer/EV supply chains), it absolutely must not miss strategic turning points from global tech giants (e.g., the "Magnificent Seven" or core global AI leaders).

## Execution Pipeline & Toolchain

### Step 1: Launch Underlying Scanners

You must run the following information scraping tools:

**1. Chinese Financial Core News Scraper** (Scraping domestic sources like Cailianshe, Wall Street CN, Sina Finance):
```bash
cd ~/.openclaw/skills/capital-market-report; uv run scripts/news-processor.py --delta --delta
```

**2. Overseas Anomaly & Rumor Radar** (Monitoring Reddit WSB, CoinGecko, Yahoo Finance movers, Google News rumors):
*(Note: Requires the `stock-analysis` skill to be installed)*
```bash
uv run ~/.openclaw/skills/stock-analysis/scripts/hot_scanner.py
uv run ~/.openclaw/skills/stock-analysis/scripts/rumor_scanner.py
```

### Step 2: Comprehensive Inclusion of Major Market Events

From the scraped results, retain news based on the following rules:
- **Include All High-Attention Events**: Any news heavily discussed by the market (e.g., major AI model releases like Claude/GPT updates, big tech earnings, macro data, geopolitical shifts) **MUST** be included, even if they perfectly meet market expectations. Do not filter out highly focused topics.
- **Retain Anomalies**: Keep extremely strong earnings reversals, supply-chain-level product delays, or major rumors.
- **Red Line**: Do not aggressively filter out major news just because it lacks a "shock" factor. If the market cares, it goes in the report.

### Step 3: Mandatory Source Tracking (Real URL Verification)

**Red Line**: Every piece of news reported must include a real source URL `[Read Original](URL)`. 
- The URL is natively extracted and provided by the underlying `news-processor.py` script from the original RSS or HTML feeds.
- Do not invent URLs or use generic domain homepages. Rely on the exact link returned by the scripts.

### Step 4: Isolated Deduction & Localization

Perform strict logical deduction on the selected events:
- **推测性内容红线（绝对禁止）**: 任何涉及具体公司立场、态度、游说方向、战略意图的判断，必须有原文明确依据。如果原文没有提及，**直接删除该条点评，不要猜测**。禁止用"可能"、"倾向于"、"说明"等词包装无原文依据的推断。宁可不写，不可编造。
- **Market Isolation Red Line**: Rigorously distinguish the "country/market" where the anomaly occurred. For example, a surge in US domestic airfares can only be deduced as bullish for US airlines and US OTAs; it **absolutely cannot be forcefully applied** to Chinese companies like Trip.com.
- If the event is a shock to an overseas giant (e.g., Honda taking a massive loss), the deduction must clarify whether the logical link to its global competitors genuinely holds up.
- **Language Localization**: Although this skill description is in English, the final report generated **MUST** be written in the user's primary conversational language (e.g., if the user communicates in Chinese, the report must be in Chinese).

### Step 5: Rolling Updates & Delta Extraction (Temporal Event Tracking)

For multi-source concurrency or rolling reports on the same market event, **DO NOT simply discard duplicate news items**. Instead, apply strict "Delta Extraction" tracking based on time:
- **Definition of Delta**: "Delta" means **new information added since the last generated report** (temporal delta), NOT whether the news broke market expectations.
- **Baseline Comparison**: You MUST read the previous report from `~/.openclaw/workspace-group/memory/last_capital_market_report.md` before generating the new report. Use it to compare newly scraped news against the *previous report's* coverage of the same event.
- **Extract Delta (New Information)**: Specifically pull out any new data, new official statements, or new market reactions that weren't in the previous report.
- **Visual Labeling**: Use tiered labeling for event tracking updates. For example:
  - `🔴 [增量更新 - 关键细节/市场反应]` for news containing substantial new facts since the last report.
  - `⚪ [跟进报道 - 与上次相比无新增]` for news that merely repeats facts already covered in the previous report.
- **Save State**: After generating the new report, you MUST overwrite `~/.openclaw/workspace-group/memory/last_capital_market_report.md` with the exact text of the new report so it is available for the next run.

## Telegram 排版规则（强制）

- **绝对禁止使用表格（table）** — Telegram 中表格渲染极差，无法阅读
- 所有信息使用 **列表（- / 1.）**、**粗体**、**emoji** 组织呈现
- 多组数据对比用列表嵌套或分段展示

## 🔴 防幻觉强制规则（Anti-Hallucination Guardrails）

**每次生成报告前必须逐条检查，违反任何一条 = 报告作废。**

### 规则1：时间校验（Temporal Verification）
- 每一条涉及公司财报、盘后涨跌、经济数据的新闻，必须确认该事件是否已在**当前北京时间**发生。
- **盘后数据规则**：北京时间 06:00 之前（美东 18:00 之前），不存在当日美股盘后数据。北京时间 21:00 之前，不存在当日美股收盘数据。
- 如果盘后数据尚未产生，**绝对不写盘后涨跌幅**。

### 规则2：财年 vs 日历年（Fiscal vs Calendar Year）
- 警惕标题中的 "Q1 2026"——部分公司（微软等）财年始于7月，"fiscal Q1 2026" 可能是 2025年7-9月的旧数据。
- 必须区分**财年季度**和**日历季度**。若无法确认，标注 "⚠️ 时间存疑"。

### 规则3：来源可信度分级（Source Credibility）
- 🔴 **禁止引用**：Clarqo、Briefly、Quartz 等 AI 内容聚合/摘要站，如果其内容涉及**尚未发生的事件**（如财报结果发布于实际财报日之前），直接丢弃该条。
- 🟡 **谨慎引用**：AI 生成的内容农场——如果同一事件在 BBC/Reuters/Bloomberg 等可信源中找不到交叉验证，直接丢弃。
- 🟢 **可信来源**：Reuters、Bloomberg、BBC、WSJ、FT、CNBC、官方 IR 页面、公司新闻稿。

### 规则4：如实汇报（Honest Reporting）
- 如果某条新闻无法确认时间或来源真伪，在报告中标注 "⚠️ 无法确认时间/来源"，**而不是编造细节**。
- **宁缺毋滥**：如果只有一个可靠来源，就只报一个。绝不为了凑篇幅而引用可疑来源。

### 规则5：交叉验证（Cross-Verification）
- 涉及具体财务数据（营收、EPS、增速、涨跌幅）的新闻，必须有**至少一个可信来源**的交叉验证。
- 如果所有来源都是 AI 内容农场或无法验证，**该条丢弃**。

## 翻译规则

- **英文标题必须翻译为中文**: 报告中出现的带 `[EN]` 标签的英文标题，必须翻译为中文，同时保留英文原标题在括号中。
- 格式: `中文翻译（English Original Title）`
- 翻译由模型在生成报告时完成，news-processor.py 仅负责数据采集。

## 中英文新闻平衡规则

- **每条报告必须至少包含3-5条 🇨🇳 中国公司/中国市场的新闻**
- 不要只关注美国科技巨头，中国企业（A股、港股、中概股）的动态必须占据显著篇幅
- 如果某时段中国新闻偏少，可以适当多选取几条；如果重大中文新闻密集，可以超过英文数量

## Report Output Format

The output must be minimalist, sharp, and deduction-driven:

```markdown
📊 **Capital Market Absolute Impact Report | YYYY-MM-DD HH:MM**

⚠️ **Core Anomaly Alerts (Potential Expectation Gaps & Strategic Inflection Points)**

- **[Category/Theme] Core Event Title (Marked with Country/Market)**
  **Source & Link**: News Source Name ([Read Original](Real_Article_URL))
  **Core**: A single sentence highlighting the crux of the anomaly.
  **Rigorous Deduction**: 1-2 sentences pointing out the bullish/bearish impact and specific stock tickers or supply chains. The logic must be airtight.

- **[Category/Theme] Core Event Title (Marked with Country/Market)**
  **Source & Link**: News Source Name ([Read Original](Real_Article_URL))
  **Core**: ...
  **Rigorous Deduction**: ...
```