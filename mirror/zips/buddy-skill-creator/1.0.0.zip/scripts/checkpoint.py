#!/usr/bin/env python3
"""
Skill Creator Checkpoint System
断点恢复机制 - 记录Skill创建进度，支持从断点恢复

Usage:
    python checkpoint.py --init <skill_path>           # 初始化检查点
    python checkpoint.py --save <skill_path> <phase>   # 保存当前阶段
    python checkpoint.py --load <skill_path>           # 加载检查点
    python checkpoint.py --status <skill_path>         # 查看当前状态
    python checkpoint.py --resume <skill_path>         # 恢复并继续
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
import argparse

CHECKPOINT_FILE = ".skill_checkpoint.json"


class Checkpoint:
    """Skill创建断点管理系统"""
    
    PHASES = [
        "init",           # 初始化
        "capture_intent", # 意图捕获
        "research",       # 调研
        "planning",       # 规划
        "generation",     # 生成
        "testing",        # 测试
        "evaluation",     # 评估
        "improvement",    # 改进
        "iteration_N",    # 迭代中 (N为数字)
        "complete"        # 完成
    ]
    
    def __init__(self, skill_path: str):
        self.skill_path = Path(skill_path)
        self.checkpoint_file = self.skill_path / CHECKPOINT_FILE
    
    def _load_checkpoint(self) -> Dict[str, Any]:
        """加载检查点文件"""
        if not self.checkpoint_file.exists():
            return {}
        try:
            with open(self.checkpoint_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    
    def _save_checkpoint(self, data: Dict[str, Any]) -> None:
        """保存检查点文件"""
        with open(self.checkpoint_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def init(self, skill_name: str, description: str = "") -> Dict[str, Any]:
        """初始化检查点"""
        checkpoint_data = {
            "skill_name": skill_name,
            "description": description,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "current_phase": "init",
            "phase_history": [],
            "decisions": [],
            "issues": [],
            "test_cases": [],
            "iteration": 0,
            "metadata": {}
        }
        self._save_checkpoint(checkpoint_data)
        return checkpoint_data
    
    def save_phase(self, phase: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """保存当前阶段"""
        if phase not in self.PHASES and not phase.startswith("iteration_"):
            print(f"警告: 未知阶段 {phase}")
        
        checkpoint_data = self._load_checkpoint()
        
        # 记录阶段历史
        phase_entry = {
            "phase": phase,
            "timestamp": datetime.now().isoformat(),
            "context": context or {}
        }
        
        checkpoint_data.setdefault("phase_history", []).append(phase_entry)
        checkpoint_data["current_phase"] = phase
        checkpoint_data["updated_at"] = datetime.now().isoformat()
        
        # 如果是迭代阶段，更新迭代计数
        if phase.startswith("iteration_"):
            try:
                iteration_num = int(phase.split("_")[1])
                checkpoint_data["iteration"] = iteration_num
            except (IndexError, ValueError):
                pass
        
        self._save_checkpoint(checkpoint_data)
        return checkpoint_data
    
    def add_decision(self, decision: str, reason: str, options: Optional[List[str]] = None) -> None:
        """记录一个决策"""
        checkpoint_data = self._load_checkpoint()
        
        decision_entry = {
            "decision": decision,
            "reason": reason,
            "options": options or [],
            "timestamp": datetime.now().isoformat()
        }
        
        checkpoint_data.setdefault("decisions", []).append(decision_entry)
        checkpoint_data["updated_at"] = datetime.now().isoformat()
        
        self._save_checkpoint(checkpoint_data)
    
    def add_issue(self, issue: str, severity: str, suggestion: str = "") -> None:
        """记录一个问题"""
        checkpoint_data = self._load_checkpoint()
        
        issue_entry = {
            "issue": issue,
            "severity": severity,  # high, medium, low
            "suggestion": suggestion,
            "timestamp": datetime.now().isoformat(),
            "resolved": False
        }
        
        checkpoint_data.setdefault("issues", []).append(issue_entry)
        checkpoint_data["updated_at"] = datetime.now().isoformat()
        
        self._save_checkpoint(checkpoint_data)
    
    def resolve_issue(self, issue_index: int) -> bool:
        """标记问题已解决"""
        checkpoint_data = self._load_checkpoint()
        
        issues = checkpoint_data.get("issues", [])
        if 0 <= issue_index < len(issues):
            issues[issue_index]["resolved"] = True
            issues[issue_index]["resolved_at"] = datetime.now().isoformat()
            checkpoint_data["issues"] = issues
            self._save_checkpoint(checkpoint_data)
            return True
        return False
    
    def add_test_case(self, test_id: str, prompt: str, expected: str = "") -> None:
        """添加测试用例"""
        checkpoint_data = self._load_checkpoint()
        
        test_entry = {
            "id": test_id,
            "prompt": prompt,
            "expected": expected,
            "status": "pending",  # pending, running, passed, failed
            "added_at": datetime.now().isoformat()
        }
        
        checkpoint_data.setdefault("test_cases", []).append(test_entry)
        checkpoint_data["updated_at"] = datetime.now().isoformat()
        
        self._save_checkpoint(checkpoint_data)
    
    def update_test_status(self, test_id: str, status: str, result: Optional[str] = None) -> None:
        """更新测试状态"""
        checkpoint_data = self._load_checkpoint()
        
        test_cases = checkpoint_data.get("test_cases", [])
        for test in test_cases:
            if test["id"] == test_id:
                test["status"] = status
                test["updated_at"] = datetime.now().isoformat()
                if result:
                    test["result"] = result
                break
        
        checkpoint_data["test_cases"] = test_cases
        self._save_checkpoint(checkpoint_data)
    
    def get_status(self) -> Dict[str, Any]:
        """获取当前状态"""
        checkpoint_data = self._load_checkpoint()
        
        if not checkpoint_data:
            return {
                "exists": False,
                "message": "No checkpoint found"
            }
        
        # 统计信息
        total_issues = len(checkpoint_data.get("issues", []))
        resolved_issues = len([i for i in checkpoint_data.get("issues", []) if i.get("resolved")])
        
        pending_tests = len([t for t in checkpoint_data.get("test_cases", []) if t.get("status") == "pending"])
        passed_tests = len([t for t in checkpoint_data.get("test_cases", []) if t.get("status") == "passed"])
        failed_tests = len([t for t in checkpoint_data.get("test_cases", []) if t.get("status") == "failed"])
        
        return {
            "exists": True,
            "skill_name": checkpoint_data.get("skill_name", "Unknown"),
            "current_phase": checkpoint_data.get("current_phase", "unknown"),
            "iteration": checkpoint_data.get("iteration", 0),
            "created_at": checkpoint_data.get("created_at", ""),
            "updated_at": checkpoint_data.get("updated_at", ""),
            "phase_history_count": len(checkpoint_data.get("phase_history", [])),
            "decisions_count": len(checkpoint_data.get("decisions", [])),
            "issues": {
                "total": total_issues,
                "resolved": resolved_issues,
                "pending": total_issues - resolved_issues
            },
            "test_cases": {
                "total": len(checkpoint_data.get("test_cases", [])),
                "pending": pending_tests,
                "passed": passed_tests,
                "failed": failed_tests
            }
        }
    
    def generate_handoff_summary(self) -> str:
        """生成阶段交接摘要（用于长对话断点恢复）"""
        checkpoint_data = self._load_checkpoint()
        
        if not checkpoint_data:
            return "# 无检查点数据"
        
        # 生成摘要
        summary = f"""# Skill创建断点摘要

## 基本信息
- **Skill名称**: {checkpoint_data.get('skill_name', 'Unknown')}
- **创建时间**: {checkpoint_data.get('created_at', '')}
- **最后更新**: {checkpoint_data.get('updated_at', '')}
- **当前阶段**: {checkpoint_data.get('current_phase', 'unknown')}
- **迭代次数**: {checkpoint_data.get('iteration', 0)}

## 阶段历史
"""
        for i, entry in enumerate(checkpoint_data.get('phase_history', [])):
            summary += f"- {i+1}. {entry['phase']} ({entry['timestamp'][:19]})\n"
        
        summary += f"""
## 决策记录 ({len(checkpoint_data.get('decisions', []))}条)
"""
        for i, decision in enumerate(checkpoint_data.get('decisions', [])):
            summary += f"- **{decision['decision']}**: {decision['reason']}\n"
        
        summary += f"""
## 问题跟踪 ({len(checkpoint_data.get('issues', []))}条)
"""
        for i, issue in enumerate(checkpoint_data.get('issues', [])):
            status = "✅" if issue.get('resolved') else "❌"
            summary += f"- {status} [{issue['severity']}] {issue['issue']}\n"
        
        summary += f"""
## 测试用例 ({len(checkpoint_data.get('test_cases', []))}个)
"""
        for test in checkpoint_data.get('test_cases', []):
            status_icon = {
                "pending": "⏳",
                "running": "🔄",
                "passed": "✅",
                "failed": "❌"
            }.get(test.get("status", "pending"), "❓")
            summary += f"- {status_icon} {test['id']}: {test['prompt'][:50]}...\n"
        
        return summary
    
    def create_recovery_prompt(self) -> str:
        """生成恢复提示（用于新对话中恢复上下文）"""
        checkpoint_data = self._load_checkpoint()
        
        if not checkpoint_data:
            return "无检查点数据，无法恢复。"
        
        # 获取当前阶段和待办事项
        current_phase = checkpoint_data.get('current_phase', 'unknown')
        pending_issues = [i for i in checkpoint_data.get('issues', []) if not i.get('resolved')]
        
        prompt = f"""## 断点恢复提示

**请加载以下检查点继续工作:**

- **Skill**: {checkpoint_data.get('skill_name', 'Unknown')}
- **当前阶段**: {current_phase}
- **迭代**: {checkpoint_data.get('iteration', 0)}

### 关键决策
"""
        for decision in checkpoint_data.get('decisions', [])[-3:]:
            prompt += f"- {decision['decision']}: {decision['reason']}\n"
        
        if pending_issues:
            prompt += "\n### 待解决问题\n"
            for issue in pending_issues[:3]:
                prompt += f"- [{issue['severity']}] {issue['issue']}\n"
        
        # 包含阶段历史摘要
        phase_history = checkpoint_data.get('phase_history', [])
        if phase_history:
            prompt += f"\n### 阶段历史摘要\n"
            for entry in phase_history[-5:]:
                prompt += f"- {entry['phase']}\n"
        
        return prompt


def main():
    parser = argparse.ArgumentParser(description="Skill Creator Checkpoint System")
    parser.add_argument("--init", metavar="SKILL_PATH", help="初始化检查点")
    parser.add_argument("--skill-name", help="Skill名称")
    parser.add_argument("--description", help="Skill描述")
    parser.add_argument("--save", nargs="+", metavar="SKILL_PATH PHASE", help="保存阶段")
    parser.add_argument("--context", help="阶段上下文 (JSON)")
    parser.add_argument("--load", metavar="SKILL_PATH", help="加载检查点")
    parser.add_argument("--status", metavar="SKILL_PATH", help="查看状态")
    parser.add_argument("--resume", metavar="SKILL_PATH", help="恢复并生成摘要")
    parser.add_argument("--summary", action="store_true", help="生成交接摘要")
    
    args = parser.parse_args()
    
    if args.init:
        skill_path = args.init
        skill_name = args.skill_name or Path(skill_path).name
        cp = Checkpoint(skill_path)
        result = cp.init(skill_name, args.description or "")
        print(f"✅ 检查点已初始化: {skill_name}")
        print(f"   文件位置: {cp.checkpoint_file}")
        return
    
    if args.save and len(args.save) >= 2:
        skill_path = args.save[0]
        phase = args.save[1]
        context = json.loads(args.context) if args.context else None
        cp = Checkpoint(skill_path)
        result = cp.save_phase(phase, context)
        print(f"✅ 阶段已保存: {phase}")
        print(f"   当前阶段: {result['current_phase']}")
        return
    
    if args.status:
        cp = Checkpoint(args.status)
        status = cp.get_status()
        
        if not status.get("exists"):
            print("❌ 未找到检查点")
            return
        
        print(f"""
╔══════════════════════════════════════╗
║       Skill创建状态检查点            ║
╠══════════════════════════════════════╣
║ Skill名称: {status['skill_name']:<25} ║
║ 当前阶段: {status['current_phase']:<25} ║
║ 迭代次数: {status['iteration']:<25} ║
╠══════════════════════════════════════╣
║ 阶段历史: {status['phase_history_count']:<24} ║
║ 决策记录: {status['decisions_count']:<24} ║
╠══════════════════════════════════════╣
║ 问题统计                               ║
║   总数: {status['issues']['total']:<25} ║
║   已解决: {status['issues']['resolved']:<23} ║
║   待解决: {status['issues']['pending']:<23} ║
╠══════════════════════════════════════╣
║ 测试用例                               ║
║   总数: {status['test_cases']['total']:<25} ║
║   通过: {status['test_cases']['passed']:<26} ║
║   失败: {status['test_cases']['failed']:<26} ║
║   待运行: {status['test_cases']['pending']:<23} ║
╚══════════════════════════════════════╝
        """)
        return
    
    if args.resume:
        cp = Checkpoint(args.resume)
        summary = cp.generate_handoff_summary()
        recovery = cp.create_recovery_prompt()
        
        print("=== 阶段交接摘要 ===")
        print(summary)
        print("\n=== 恢复提示 ===")
        print(recovery)
        return
    
    if args.summary and args.load:
        cp = Checkpoint(args.load)
        summary = cp.generate_handoff_summary()
        print(summary)
        return
    
    parser.print_help()


if __name__ == "__main__":
    main()
