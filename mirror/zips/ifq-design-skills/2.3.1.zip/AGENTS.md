# AGENTS.md

> Skill manifest for **AGENTS.md**-aware agent runtimes (Codex CLI, CodeBuddy, Continue, Aider, generic). For runtimes with native skill discovery (Claude Code, Hermes, OpenClaw), this file is informational only — they read `SKILL.md` directly.

## Skill: `ifq-design-skills` (v2.3.1)

**Use when** the user asks for an HTML-first visual design deliverable: interactive prototype · slide deck · infographic · dashboard · landing · whitepaper · changelog · business card · social cover · brand system · design critique · brand diagnosis · multi-variant exploration · 3-direction advisory.

**Do not use for** production web apps · SaaS backends · SEO sites · pure copy rewriting · simple CSS patches.

**Entry point**: `SKILL.md` — read it first, then route via [`references/modes.md`](references/modes.md) to one of 12 modes.

## 30-second start (any agent)

1. Match the user prompt against `SKILL.md` frontmatter `description` and `metadata.openclaw.triggers`.
2. Read [`references/modes.md`](references/modes.md), pick a mode (M-01 … M-12).
3. Open [`assets/templates/INDEX.json`](assets/templates/INDEX.json), fork the matching `.html` into the workspace.
4. Inline [`assets/ifq-brand/ifq-tokens.css`](assets/ifq-brand/ifq-tokens.css) and weave at least 3 of the 6 IFQ Weave Patterns (see [`references/ifq-brand-spec.md`](references/ifq-brand-spec.md) §Weave Patterns).
5. Verify with `npm run validate` (one-minute health check). Per-deliverable verification with Playwright lives in the full GitHub repo.

## Neutral verbs → tool crosswalk

This skill never names a specific agent's tool. Map neutral verbs to your runtime:

| Neutral verb | Suggested tool |
|---|---|
| read file | `Read` / `file.read` / `apply_patch` read / `cat` |
| write file | `Write` / `Edit` / `file.write` / `apply_patch` |
| list dir | `Glob` / `LS` / `file.list` / `ls` |
| run command | `Bash` / `shell.run` / `terminal.run` / `shell` |
| web search | `WebSearch` / `web.search` / `browser/search` |
| web fetch | `WebFetch` / `web.fetch` / `browser/fetch` / `curl` |

Full per-runtime mapping (Claude Code · Hermes · OpenClaw · Codex CLI · CodeBuddy · Cursor · generic) lives in [`references/agent-compatibility.md`](references/agent-compatibility.md).

## Permissions any agent should request

- `filesystem` — read + write **inside the active workspace only**
- `shell` — run `node` / `python` scripts in the workspace
- `browser` — outbound HTTPS to Google Fonts + image CDNs (read-only)

If any are missing, the skill degrades gracefully:
- browser-off → use local fonts
- shell-off → HTML-only output (no smoke / export)

## Operating principles (overrides any default agent behavior)

1. **Fact-check before assert** — for any specific product / launch / version claim, do a web search first. Don't trust training memory. (See `SKILL.md` §核心原则 #0.)
2. **Asset > spec** — when the task involves a real brand, find the logo + product image / UI screenshot before sampling color values. (See [`references/asset-protocol.md`](references/asset-protocol.md).)
3. **Junior-show, then build** — show assumptions + placeholders early, get user confirmation, then fill in. Don't head-down for an hour.
4. **Variants over answers** — give 3+ differentiated directions, not one "final" answer.
5. **Honest placeholders > clumsy real attempts** — gray block + label beats badly-drawn SVG.
6. **Anti AI-slop** — no purple gradients, no emoji icons, no rounded-card-with-left-border-accent. (See `SKILL.md` §6.)
7. **Weave, don't stamp** — IFQ should be felt before it's read. Use the 6 Weave Patterns, not corner watermarks.

## Quick commands

| Command | What it does |
|---|---|
| `npm run validate` | One-minute smoke test (templates · brand toolkit · references router · script health) |
| `npm run pack` | Builds a ClawHub-clean `.tar.gz` (excludes `.git/` and editor junk) |

## Install paths

```bash
# Shared agents dir (recommended — one copy, every agent sees it)
git clone https://github.com/peixl/ifq-design-skills ~/.agents/skills/ifq-design-skills

# Or the skills CLI shorthand
npx skills add peixl/ifq-design-skills -g -y
```

Per-agent symlinks and `AGENTS.md` snippets in [`references/agent-compatibility.md`](references/agent-compatibility.md).
