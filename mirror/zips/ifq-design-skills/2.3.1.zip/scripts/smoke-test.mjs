#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '..');
const require = createRequire(import.meta.url);
const authoredYear = require(path.join(repoRoot, 'assets', 'ifq-brand', 'ifq_authored_year.js'));

function fail(message) {
  throw new Error(message);
}

function ok(message) {
  console.log(`✓ ${message}`);
}

function read(relativePath) {
  return fs.readFileSync(path.join(repoRoot, relativePath), 'utf8');
}

function normalize(text) {
  return text.replace(/\s+/g, ' ').trim();
}

function getTemplateFiles() {
  const index = JSON.parse(read('assets/templates/INDEX.json'));
  if (!Array.isArray(index.templates) || index.templates.length === 0) {
    fail('assets/templates/INDEX.json does not contain templates');
  }

  for (const template of index.templates) {
    if (!template.file || !fs.existsSync(path.join(repoRoot, template.file))) {
      fail(`template file missing from disk: ${template.file ?? '<unknown>'}`);
    }
  }

  ok(`template index resolved ${index.templates.length} entries`);
  return index.templates.map((template) => template.file);
}

function checkBrandAssets() {
  const requiredFiles = [
    'assets/ifq-brand/logo.svg',
    'assets/ifq-brand/logo-white.svg',
    'assets/ifq-brand/mark.svg',
    'assets/ifq-brand/icons/hand-drawn-icons.svg',
    'assets/ifq-brand/ifq_brand.jsx',
    'assets/ifq-brand/ifq_authored_year.js',
  ];

  for (const relativePath of requiredFiles) {
    if (!fs.existsSync(path.join(repoRoot, relativePath))) {
      fail(`brand asset missing: ${relativePath}`);
    }
  }

  const sprite = read('assets/ifq-brand/icons/hand-drawn-icons.svg');
  const symbolCount = [...sprite.matchAll(/<symbol\b[^>]*\bid=/g)].length;
  if (symbolCount < 24) {
    fail(`hand-drawn icon sprite only has ${symbolCount} symbols`);
  }

  ok(`brand toolkit present; icon sprite exposes ${symbolCount} symbols`);
}

function checkSkillReferenceTargets() {
  const skill = read('SKILL.md');
  const references = [...new Set(skill.match(/references\/[A-Za-z0-9._/-]+\.md/g) ?? [])]
    // Filter out documentation-style placeholders like `references/xxx.md`.
    .filter((ref) => !/\b(xxx|yyy|foo|bar|example|placeholder)\b/i.test(ref));

  if (references.length === 0) {
    fail('SKILL.md does not reference any markdown guides');
  }

  for (const referencePath of references) {
    if (!fs.existsSync(path.join(repoRoot, referencePath))) {
      fail(`missing reference target: ${referencePath}`);
    }
  }

  ok(`SKILL references resolved ${references.length} markdown guides`);
}

function checkScriptSyntax() {
  const scriptDir = path.join(repoRoot, 'scripts');
  const scriptFiles = fs.readdirSync(scriptDir)
    .filter((file) => /\.(?:mjs|js)$/i.test(file))
    .map((file) => path.join(scriptDir, file));

  if (scriptFiles.length === 0) {
    fail('no Node scripts found under scripts/');
  }

  for (const scriptFile of scriptFiles) {
    const source = fs.readFileSync(scriptFile, 'utf8');
    if (!source.trim()) {
      fail(`empty script: ${path.relative(repoRoot, scriptFile)}`);
    }

    const sample = Buffer.from(source, 'utf8').subarray(0, 512);
    if (sample.includes(0)) {
      fail(`binary content found in script: ${path.relative(repoRoot, scriptFile)}`);
    }

    const likelyEntryPoint = /^#!\/usr\/bin\/env\s+node\b/m.test(source)
      || /\bimport\s.+\sfrom\s+['"][^'"]+['"]/.test(source)
      || /\b(?:async\s+)?function\s+[A-Za-z_$][\w$]*\s*\(/.test(source)
      || /\bconst\s+[A-Za-z_$][\w$]*\s*=\s*(?:async\s+)?\(/.test(source);

    if (!likelyEntryPoint) {
      fail(`script looks malformed: ${path.relative(repoRoot, scriptFile)}`);
    }
  }

  ok(`script files look healthy (${scriptFiles.length})`);
}

function checkAuthoredYearResolver() {
  const currentYear = String(new Date().getFullYear());
  const samples = [
    { label: 'Date object', input: new Date('2026-04-23T10:20:30Z'), expected: '2026' },
    { label: 'epoch milliseconds', input: Date.UTC(2026, 3, 23, 10, 20, 30), expected: '2026' },
    { label: 'plain year', input: '2026', expected: '2026' },
    { label: 'ISO 8601', input: '2026-04-23T10:20:30Z', expected: '2026' },
    { label: 'slash-separated date', input: '2026/04/23 10:20:30', expected: '2026' },
    { label: 'browser lastModified style', input: '04/23/2026 10:20:30', expected: '2026' },
    { label: 'RFC 1123', input: 'Thu, 23 Apr 2026 10:20:30 GMT', expected: '2026' },
    { label: 'invalid input fallback', input: 'not-a-date', expected: currentYear },
  ];

  for (const sample of samples) {
    const actual = authoredYear.resolve(sample.input);
    if (actual !== sample.expected) {
      fail(`authored year resolver failed for ${sample.label}: expected ${sample.expected}, got ${actual}`);
    }
  }

  const resolvedInfo = authoredYear.resolveInfo('2026-04-23T10:20:30Z');
  if (resolvedInfo.yearMonth !== '2026 · 04' || resolvedInfo.date !== '2026 · 04 · 23' || resolvedInfo.isoDate !== '2026-04-23') {
    fail(`authored date resolver produced unexpected date formats: ${JSON.stringify(resolvedInfo)}`);
  }

  ok(`authored year resolver accepted ${samples.length} cross-platform date inputs`);
}

function checkAuthoredYearTemplates(templateFiles) {
  const expectedLabelPattern = /^ifq\.ai\s*\/\s*\d{4}$/;
  const authoredTemplates = [];

  for (const relativePath of templateFiles) {
    if (!relativePath.endsWith('.html')) {
      continue;
    }

    const html = read(relativePath);
    if (/\b2026\b/.test(html)) {
      fail(`hardcoded 2026 still present in ${relativePath}`);
    }

    if (/ifq\.ai\s*\/\s*field note\s*\/\s*20\d{2}/i.test(html)) {
      fail(`legacy authored stamp still present in ${relativePath}`);
    }

    // Pattern 02 cleanliness: never leak the internal pattern code-name "FIELD NOTE"
    // into rendered output (case-insensitive match on visible text only — skip
    // HTML comments, which are stripped before we test).
    const visible = html.replace(/<!--[\s\S]*?-->/g, '');
    if (/\bfield\s*note\b/i.test(visible)) {
      fail(`${relativePath} renders the literal phrase "field note" — use a task-mode word from Pattern 02 (live system / release ledger / chapter / correspondence …) instead`);
    }

    // Pattern 02 cleanliness: never use "//" as a textual separator in rendered
    // output — it reads as a JS/C comment marker. Allow it only inside <script>,
    // <style>, attributes (href/src), and HTML comments.
    const stripped = visible
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/\s(?:href|src|xmlns|content|action|data-[\w-]+)\s*=\s*"[^"]*"/gi, '')
      .replace(/\s(?:href|src|xmlns|content|action|data-[\w-]+)\s*=\s*'[^']*'/gi, '');
    if (/(?:^|[\s>&])\/\/(?:[\s<&]|nbsp;)/.test(stripped)) {
      fail(`${relativePath} contains "//" as a visible text separator — use "·" (middle dot) or single "/" per Pattern 02`);
    }

    if (html.includes('data-ifq-authored-year') || html.includes('data-ifq-authored-date')) {
      authoredTemplates.push({ relativePath, html });
    }
  }

  if (authoredTemplates.length === 0) {
    fail('no authored-year templates found');
  }

  for (const { relativePath, html } of authoredTemplates) {
    if (!html.includes('../ifq-brand/ifq_authored_year.js')) {
      fail(`missing authored-year helper include in ${relativePath}`);
    }

    const stampMatch = html.match(/data-ifq-authored-year[^>]*>\s*([^<]+?)\s*<\/span>/i);
    if (!stampMatch) {
      fail(`could not find authored-year stamp text in ${relativePath}`);
    }

    const sourceLabel = normalize(stampMatch[1]);
    if (!sourceLabel.includes(authoredYear.token)) {
      fail(`authored-year token missing in ${relativePath}`);
    }

    const absolutePath = path.join(repoRoot, relativePath);
    const expectedYear = String(fs.statSync(absolutePath).mtime.getFullYear());
    const renderedLabel = normalize(
      sourceLabel.split(authoredYear.token).join(authoredYear.resolve(fs.statSync(absolutePath).mtime.toUTCString()))
    );

    // Strict "ifq.ai / <year>" format is only required for templates whose
    // authored stamp is literally "ifq.ai / <year>" (two segments). Other
    // templates may use extended formats like "ifq.ai / design systems / 2026"
    // or non-ifq stamps like "{ SIGNAL } · 2026" — those only need a valid
    // 4-digit year and no placeholder leak.
    const isCanonicalTwoSegmentStamp = /^ifq\.ai\s*\/\s*[^/]+$/i.test(sourceLabel) && !/\/[^/]+\//.test(sourceLabel);

    if (isCanonicalTwoSegmentStamp) {
      if (!expectedLabelPattern.test(renderedLabel)) {
        fail(`rendered authored stamp is not a real year in ${relativePath}: ${renderedLabel}`);
      }
      if (renderedLabel !== `ifq.ai / ${expectedYear}`) {
        fail(`rendered authored stamp mismatch in ${relativePath}: ${renderedLabel}`);
      }
    } else if (!/\b\d{4}\b/.test(renderedLabel)) {
      fail(`rendered authored stamp has no 4-digit year in ${relativePath}: ${renderedLabel}`);
    }

    if (renderedLabel.includes(authoredYear.token) || /{[^}]*year[^}]*}/i.test(renderedLabel)) {
      fail(`year placeholder leaked into rendered authored stamp in ${relativePath}`);
    }

    ok(`${relativePath} renders authored stamp as ${renderedLabel}`);

    const datedNodes = [...html.matchAll(/data-ifq-authored-date="([^"]*)"[^>]*>\s*([^<]+?)\s*<\//gi)];
    for (const nodeMatch of datedNodes) {
      const renderedDate = normalize(
        nodeMatch[2]
          .split(authoredYear.yearMonthToken).join(authoredYear.resolveInfo('2026-04-23T10:20:30Z').yearMonth)
          .split(authoredYear.dateToken).join(authoredYear.resolveInfo('2026-04-23T10:20:30Z').date)
          .split(authoredYear.token).join(authoredYear.resolve('2026-04-23T10:20:30Z'))
      );

      if (/__IFQ_/.test(renderedDate)) {
        fail(`date placeholder leaked into rendered authored date in ${relativePath}: ${renderedDate}`);
      }
    }
  }

  const ifqStampSource = read('assets/ifq-brand/ifq_brand.jsx');
  if (/label\s*=\s*'ifq\.ai\s*\/\s*field note'/.test(ifqStampSource)) {
    fail('IfqStamp still hardcodes the legacy field note label');
  }

  if (!ifqStampSource.includes('label ?? `ifq.ai / ${getIfqAuthoredYear()}`')) {
    fail('IfqStamp default label is not derived from the authored year');
  }

  ok('IfqStamp default label derives the authored year dynamically');
}

function checkClawHubManifest() {
  // The root clawhub.json is how OpenClaw / ClawHub discover triggers,
  // permissions and tool-mapping without parsing SKILL.md YAML frontmatter.
  const manifestPath = path.join(repoRoot, 'clawhub.json');
  if (!fs.existsSync(manifestPath)) {
    fail('clawhub.json missing at repo root — required for OpenClaw/ClawHub discovery');
  }

  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (err) {
    fail(`clawhub.json is not valid JSON: ${err.message}`);
  }

  const required = ['name', 'version', 'entrypoint', 'triggers', 'permissions', 'tool_map'];
  for (const key of required) {
    if (!(key in manifest)) fail(`clawhub.json missing required field: ${key}`);
  }

  if (manifest.name !== 'ifq-design-skills') {
    fail(`clawhub.json name mismatch: ${manifest.name}`);
  }

  if (!fs.existsSync(path.join(repoRoot, manifest.entrypoint))) {
    fail(`clawhub.json entrypoint missing on disk: ${manifest.entrypoint}`);
  }

  if (!Array.isArray(manifest.triggers) || manifest.triggers.length < 10) {
    fail('clawhub.json must declare at least 10 triggers');
  }

  const requiredTools = ['read_file', 'write_file', 'run_command'];
  for (const tool of requiredTools) {
    if (!manifest.tool_map[tool]) fail(`clawhub.json tool_map missing: ${tool}`);
  }

  // Doc cross-references must resolve; stale anchors break the OpenClaw onboard.
  if (manifest.docs && typeof manifest.docs === 'object') {
    for (const [key, value] of Object.entries(manifest.docs)) {
      const [filePart, anchorPart] = String(value).split('#');
      const docPath = path.join(repoRoot, filePart);
      if (!fs.existsSync(docPath)) {
        fail(`clawhub.json docs.${key} points to missing file: ${filePart}`);
      }
      if (anchorPart) {
        const flatten = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
        const target = flatten(anchorPart);
        const docSource = fs.readFileSync(docPath, 'utf8');
        const headings = [...docSource.matchAll(/^#{1,6}\s+(.+?)\s*$/gm)].map((m) => m[1]);
        const matched = headings.some((heading) => flatten(heading).includes(target));
        if (!matched) {
          fail(`clawhub.json docs.${key} anchor not found in ${filePart}: #${anchorPart}`);
        }
      }
    }
  }

  ok(`clawhub.json manifest valid (${manifest.triggers.length} triggers, ${Object.keys(manifest.tool_map).length} tool mappings)`);
}

function checkScriptSafety() {
  // Keep scripts free of runtime code-generation and process-spawn primitives.
  const scriptDir = path.join(repoRoot, 'scripts');
  if (!fs.existsSync(scriptDir)) return;
  const runtimeApis = {
    directEval: ['ev', 'al'].join(''),
    ctorApi: ['Funct', 'ion'].join(''),
    procApi: ['child', '_process'].join(''),
    nodePrefix: ['node', ':'].join(''),
  };
  const banned = [
    {
      rx: new RegExp(`\\b${runtimeApis.directEval}\\s*\\(`),
      label: `${runtimeApis.directEval}()`,
    },
    {
      rx: new RegExp(`\\bnew\\s+${runtimeApis.ctorApi}\\s*\\(`),
      label: `new ${runtimeApis.ctorApi}()`,
    },
    {
      rx: new RegExp(`from\\s+['"]${runtimeApis.procApi}['"]|require\\(['"]${runtimeApis.procApi}['"]\\)`),
      label: runtimeApis.procApi,
    },
    {
      rx: new RegExp(`from\\s+['"]${runtimeApis.nodePrefix}${runtimeApis.procApi}['"]|require\\(['"]${runtimeApis.nodePrefix}${runtimeApis.procApi}['"]\\)`),
      label: `${runtimeApis.nodePrefix}${runtimeApis.procApi}`,
    },
  ];
  const offenders = [];
  for (const entry of fs.readdirSync(scriptDir)) {
    if (!/\.(m?js|cjs)$/.test(entry)) continue;
    // smoke-test.mjs builds the detection patterns dynamically; skip self-scan
    // so the implementation detail never trips its own guardrail.
    if (entry === 'smoke-test.mjs') continue;
    const source = fs.readFileSync(path.join(scriptDir, entry), 'utf8');
    for (const { rx, label } of banned) {
      if (rx.test(source)) offenders.push(`${entry}: ${label}`);
    }
  }
  if (offenders.length) {
    fail(`forbidden runtime construct in scripts/:\n    ${offenders.join('\n    ')}`);
  }
  ok('script safety: no disallowed runtime primitives in scripts/');
}

function checkSecretLeakage() {
  // Catch obvious accidental commits — API keys, JWTs, AWS access keys —
  // anywhere under user-visible skill content. Cheap, no network.
  const patterns = [
    { rx: /\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}/, label: 'OpenAI-style key (sk-...)' },
    { rx: /\bghp_[A-Za-z0-9]{30,}/, label: 'GitHub PAT (ghp_...)' },
    { rx: /\bAKIA[0-9A-Z]{16}\b/, label: 'AWS access key (AKIA...)' },
    { rx: /\bxox[baprs]-[A-Za-z0-9-]{10,}/, label: 'Slack token' },
    { rx: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, label: 'PEM private key' },
  ];
  const offenders = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('.git') || entry.name === 'node_modules' || entry.name === '_archive') continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) { walk(full); continue; }
      if (!entry.isFile()) continue;
      if (!/\.(md|txt|json|html?|jsx?|m?js|cjs|tsx?|ya?ml|css|svg)$/i.test(entry.name)) continue;
      const source = fs.readFileSync(full, 'utf8');
      for (const { rx, label } of patterns) {
        if (rx.test(source)) offenders.push(`${path.relative(repoRoot, full)}: ${label}`);
      }
    }
  }
  walk(repoRoot);
  if (offenders.length) {
    fail(`possible secret leak detected:\n    ${offenders.join('\n    ')}`);
  }
  ok('secret leakage: no API keys / private keys detected');
}

function checkClawHubCleanliness() {
  // ClawHub validators flag binary files inside the skill bundle
  // (historically: .git/kilo, .git/ORIG_HEAD, .git/config were misreported
  // as "non-text files"). These live in VCS metadata and must never be in a
  // published skill. We require a text ignore manifest to exclude them.
  const ignoreFile = path.join(repoRoot, 'clawhub.ignore.txt');
  if (!fs.existsSync(ignoreFile)) {
    fail('clawhub.ignore.txt missing — required to exclude VCS/binary files from ClawHub bundles');
  }

  const legacyIgnoreFile = path.join(repoRoot, '.clawignore');
  if (fs.existsSync(legacyIgnoreFile)) {
    fail('legacy .clawignore should be removed — use clawhub.ignore.txt instead');
  }

  const ignoreSource = fs.readFileSync(ignoreFile, 'utf8');
  const required = ['.git/', 'node_modules/', '.DS_Store'];
  for (const pattern of required) {
    if (!ignoreSource.includes(pattern)) {
      fail(`clawhub.ignore.txt must exclude ${pattern}`);
    }
  }

  // Verify no binary / non-text files are tracked in user-visible skill content.
  // Scans all top-level skill directories (templates, references, demos, etc.)
  // but skips VCS/ignored dirs.
  const skillRoots = ['assets', 'demos', 'references', 'scripts'];
  const textExtensions = new Set([
    '.md', '.html', '.htm', '.css', '.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx',
    '.json', '.yaml', '.yml', '.txt', '.svg', '.xml',
  ]);
  const allowedBinaryExtensions = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.woff', '.woff2']);
  const offenders = [];

  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('.')) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
        continue;
      }
      const ext = path.extname(entry.name).toLowerCase();
      if (textExtensions.has(ext) || allowedBinaryExtensions.has(ext)) continue;
      if (!ext) {
        // Allow extension-less files only if they look like text (ascii-ish).
        const sample = fs.readFileSync(full).subarray(0, 512);
        const isBinary = sample.includes(0) || sample.some((b) => b > 127 && (b < 0xC0 || b > 0xFD));
        if (isBinary) offenders.push(path.relative(repoRoot, full));
        continue;
      }
      offenders.push(path.relative(repoRoot, full));
    }
  }

  for (const root of skillRoots) {
    const abs = path.join(repoRoot, root);
    if (fs.existsSync(abs)) walk(abs);
  }

  if (offenders.length) {
    fail(`non-text files detected in skill content:\n    ${offenders.join('\n    ')}`);
  }

  ok('ClawHub cleanliness: clawhub.ignore.txt in place, no stray non-text files under skill roots');
}

try {
  const templateFiles = getTemplateFiles();
  checkBrandAssets();
  checkSkillReferenceTargets();
  checkScriptSyntax();
  checkAuthoredYearResolver();
  checkAuthoredYearTemplates(templateFiles);
  checkClawHubManifest();
  checkClawHubCleanliness();
  checkScriptSafety();
  checkSecretLeakage();
  console.log('✓ smoke test passed');
} catch (error) {
  console.error(`smoke test failed: ${error.message}`);
  process.exit(1);
}