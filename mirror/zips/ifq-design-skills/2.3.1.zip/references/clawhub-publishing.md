# Publishing this skill to ClawHub

This bundle ships with tooling to make ClawHub validation painless.

## TL;DR

```bash
npm run validate     # smoke test: structure, references, ClawHub cleanliness
npm run pack         # produces ../ifq-design-clawhub-YYYY-MM-DD.tar.gz
```

Upload the resulting tarball (**not** the raw repo folder) to ClawHub.

## Why not upload the folder directly?

Some ClawHub validators walk the directory as-is and flag internal Git files
(`.git/kilo`, `.git/ORIG_HEAD`, `.git/config`) as "non-text files". They are
VCS metadata and must never be part of a published skill.

ClawHub's web uploader can also misclassify a hidden ignore file such as
`.clawignore` as a non-text artifact. This repo therefore uses
`clawhub.ignore.txt`: same purpose, but safe to keep inside the published skill
so `npm run validate` and `npm run pack` still work after install.

The `npm run pack` script reads `clawhub.ignore.txt` (gitignore-style) and builds a
deterministic `.tar.gz` that excludes:

- `.git/` and other VCS internals
- `.DS_Store`, editor junk, logs
- `node_modules/`, build output
- local `.env` and personal config
- OpenClaw local state (`.openclaw*/`)

The pack script also self-verifies — it will exit non-zero if any forbidden
entry slips into the final archive.

## OpenClaw-friendly workflow

```bash
# 1. Validate locally
npm run validate

# 2. Produce a clean bundle
npm run pack

# 3. Inspect before upload (optional)
tar -tzf ../ifq-design-clawhub-*.tar.gz | head

# 4. Publish via OpenClaw
openclaw skills install ../ifq-design-clawhub-*.tar.gz
```

## Custom output path

```bash
node scripts/pack-skill.mjs --out /tmp/my-bundle.tar.gz
```
