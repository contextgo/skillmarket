#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prana 封装技能 — 薄客户端（无业务逻辑，仅负责与 Prana 服务通信）
从 GitHub / Claw Hub 等下载本技能包后，通过本脚本将用户输入转发到 Prana 执行真实能力。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import time
import uuid
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urlencode

# 技能根目录（本脚本位于 scripts/ 下）
SKILL_ROOT = Path(__file__).resolve().parent.parent
SKILL_MD_FILE = SKILL_ROOT / "SKILL.md"

# 封装打包时由服务端替换为 dict（见锚点注释）；仓库模板为 None，仅供开发或旧版 frontmatter 回退。
_ENCAPSULATION_EMBEDDED: Optional[Dict[str, Any]] = {"public_skill_key": "stock_scoring_analysis_v2_public", "original_skill_key": "stock_scoring_analysis_v2", "encapsulation_target": "skillhub"}

DEFAULT_PRANA_BASE = "https://claw-uat.ebonex.io/"

# agent-run 为长连接场景；超时或失败后改查 agent-result（同一 request_id）
HTTP_TIMEOUT_SEC = 7200
# agent-run 非合法 JSON 或需改查时，按固定间隔轮询 POST /api/claw/agent-result（默认每 2 分钟）
AGENT_RESULT_POLL_INTERVAL_SEC = int(os.environ.get("PRANA_AGENT_RESULT_POLL_INTERVAL_SEC", "120"))
AGENT_RESULT_POLL_MAX_ATTEMPTS = int(os.environ.get("PRANA_AGENT_RESULT_POLL_MAX_ATTEMPTS", "20"))
# 自动拉取 API key（GET /api/v2/api-keys）超时
API_KEYS_FETCH_TIMEOUT_SEC = 60


def _normalize_encapsulation_target(raw: Optional[str]) -> str:
    """与后端 encapsulation target_system 一致：默认 prana；clawHub 等归一为 claw_hub。"""
    s = (raw or "").strip().lower().replace("-", "_")
    if not s:
        return "prana"
    aliases = {"clawhub": "claw_hub", "openclaw": "claw_hub", "open_claw": "claw_hub"}
    key = aliases.get(s, s)
    return key[:64] if len(key) > 64 else key


def _load_encapsulation_runtime() -> Optional[Dict[str, Any]]:
    """封装包内写入 `prana_skill_client.py` 的 `_ENCAPSULATION_EMBEDDED`；未封装/模板为 None。"""
    emb = _ENCAPSULATION_EMBEDDED
    if isinstance(emb, dict) and emb:
        return dict(emb)
    return None


def _extract_frontmatter(content: str) -> Tuple[Optional[Dict[str, Any]], str]:
    if not content.strip().startswith("---"):
        return None, content
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
    if not match:
        return None, content
    try:
        import yaml

        fm = yaml.safe_load(match.group(1))
        return (fm if isinstance(fm, dict) else None), match.group(2)
    except Exception:
        return None, content


def load_skill_config() -> Dict[str, Any]:
    """
    从本脚本内嵌 `_ENCAPSULATION_EMBEDDED` 与 SKILL.md frontmatter 合并读取配置。
    agent-run 使用的 skill_key：优先内嵌 `original_skill_key`，其次旧版 SKILL.md 字段。
    """
    if not SKILL_MD_FILE.exists():
        print(
            "错误: 未找到 SKILL.md，请使用完整封装技能包解压后运行。",
            file=sys.stderr,
        )
        sys.exit(1)
    runtime = _load_encapsulation_runtime()
    raw = SKILL_MD_FILE.read_text(encoding="utf-8")
    frontmatter, _ = _extract_frontmatter(raw)
    if not frontmatter:
        print("错误: SKILL.md 缺少有效的 YAML frontmatter。", file=sys.stderr)
        sys.exit(1)
    original = str((runtime or {}).get("original_skill_key") or "").strip()
    pub_fm = str(frontmatter.get("original_skill_key") or "").strip()
    pub_key_fm = str(frontmatter.get("skill_key") or "").strip()
    if not original:
        original = pub_fm
    pub = str((runtime or {}).get("public_skill_key") or "").strip()
    if not pub:
        pub = pub_key_fm
    # 调用远端：优先 original_skill_key；再回退旧包仅含 skill_key
    sk = original if original else pub
    if not sk:
        print(
            "错误: 缺少远端技能标识。请使用服务端封装生成的技能包（脚本内已写入 _ENCAPSULATION_EMBEDDED），"
            "或为旧版包在 SKILL.md frontmatter 中保留 original_skill_key / skill_key。",
            file=sys.stderr,
        )
        sys.exit(1)
    sip = ""
    for key in ("input_format", "input_schema", "params"):
        v = frontmatter.get(key)
        if v is not None and str(v).strip():
            sip = str(v).strip()[:16000]
            break
    if not sip:
        d = frontmatter.get("description")
        if d is not None and str(d).strip():
            sip = str(d).strip()[:8000]
    enc = _normalize_encapsulation_target(
        str((runtime or {}).get("encapsulation_target") or frontmatter.get("encapsulation_target") or "")
    )
    return {"skill_key": sk, "skill_invocation_params": sip, "encapsulation_target": enc}


def _parse_credentials_json(text: str) -> Optional[Tuple[str, str]]:
    """解析 GET /api/v2/api-keys 等响应：data.api_key 可为 `pk:sk` 单字符串，或嵌套 public_key/secret_key。"""
    t = text.strip()
    if not t.startswith("{"):
        return None
    try:
        obj = json.loads(t)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    data = obj.get("data")
    ak = None
    if isinstance(data, dict):
        ak = data.get("api_key")
    if isinstance(ak, str) and ":" in ak:
        line = _parse_credentials_line(ak)
        if line:
            return line
    if isinstance(ak, dict) and ak.get("public_key") and ak.get("secret_key"):
        return str(ak["public_key"]).strip(), str(ak["secret_key"]).strip()
    ak = obj.get("api_key")
    if isinstance(ak, str) and ":" in ak:
        line = _parse_credentials_line(ak)
        if line:
            return line
    if isinstance(ak, dict) and ak.get("public_key") and ak.get("secret_key"):
        return str(ak["public_key"]).strip(), str(ak["secret_key"]).strip()
    if obj.get("public_key") and obj.get("secret_key"):
        return str(obj["public_key"]).strip(), str(obj["secret_key"]).strip()
    return None


def _parse_credentials_line(line: str) -> Optional[Tuple[str, str]]:
    """单行 public_key:secret_key（取首个冒号分割，避免密钥中含冒号时误拆）。"""
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if ":" not in line:
        return None
    pub, _, sec = line.partition(":")
    pub, sec = pub.strip(), sec.strip()
    if pub and sec:
        return pub, sec
    return None


def _headers_x_api_key(public_key: str, secret_key: str) -> dict[str, str]:
    """Claw 接口要求：x-api-key 为 public_key:secret_key。"""
    return {
        "Content-Type": "application/json",
        "x-api-key": f"{public_key}:{secret_key}",
    }


def _build_api_keys_fetch_url(base_url: str) -> str:
    """组装 GET /api/v2/api-keys 完整 URL（封装为 prana 分发时可附加查询参数，见脚本内实现）。"""
    root = base_url.rstrip("/")
    path = f"{root}/api/v2/api-keys"
    return path


def fetch_prana_api_keys_via_get(base_url: str) -> Optional[Tuple[str, str]]:
    """
    调用 GET /api/v2/api-keys（无需 JWT），解析 data.api_key（`pk:sk` 字符串或旧版 JSON 对象）。
    """
    url = _build_api_keys_fetch_url(base_url)
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=API_KEYS_FETCH_TIMEOUT_SEC) as resp:
            text = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        print(
            f"错误: 自动获取 API key 失败（HTTP {e.code}）：{err[:2000]}",
            file=sys.stderr,
        )
        return None
    except urllib.error.URLError as e:
        print(f"错误: 自动获取 API key 失败（网络）：{e.reason}", file=sys.stderr)
        return None
    except TimeoutError:
        print("错误: 自动获取 API key 超时。", file=sys.stderr)
        return None
    parsed = _parse_credentials_json(text)
    if not parsed:
        print(
            "错误: 自动获取 API key 成功但响应无法解析出可用的 pk:sk（请检查 data.api_key 格式）。",
            file=sys.stderr,
        )
        return None
    return parsed


def _sync_prana_keys_into_environ(public_key: str, secret_key: str) -> Tuple[str, str]:
    """将密钥写入当前进程环境：仅设置 PRANA_SKILL_API_FLAG（pk:sk），供后续解析为 x-api-key。"""
    pk = (public_key or "").strip()
    sk = (secret_key or "").strip()
    if pk and sk:
        os.environ["PRANA_SKILL_API_FLAG"] = f"{pk}:{sk}"
    return pk, sk


def _credentials_from_environment() -> Optional[Tuple[str, str]]:
    """从环境变量 PRANA_SKILL_API_FLAG（或嵌套 JSON 字符串）解析 pk/sk，不发起网络请求。"""
    raw = os.environ.get("PRANA_SKILL_API_FLAG", "").strip()
    if raw:
        parsed = _parse_credentials_json(raw)
        if parsed:
            return parsed[0], parsed[1]
        p = _parse_credentials_line(raw)
        if p:
            return p[0], p[1]
    return None


def load_prana_credentials(prana_base_url: Optional[str] = None) -> Tuple[str, str]:
    """
    调用 agent-run 前解析 x-api-key：**先**环境变量 **`PRANA_SKILL_API_FLAG`**（`pk:sk` 或 JSON）；否则 **GET /api/v2/api-keys**。
    成功后仅写入 **`PRANA_SKILL_API_FLAG`**。
    """
    from_env = _credentials_from_environment()
    if from_env:
        print(
            "提示: 已使用环境变量 PRANA_SKILL_API_FLAG（跳过 GET /api/v2/api-keys），随后调用 POST /api/claw/agent-run。",
            file=sys.stderr,
        )
        return _sync_prana_keys_into_environ(from_env[0], from_env[1])

    base = (prana_base_url or os.environ.get("NEXT_PUBLIC_URL") or DEFAULT_PRANA_BASE or "").strip()
    if base:
        print(
            "提示: 未设置 PRANA_SKILL_API_FLAG，正在请求 GET /api/v2/api-keys，成功后写入环境并调用 POST /api/claw/agent-run。",
            file=sys.stderr,
        )
        fetched = fetch_prana_api_keys_via_get(base)
        if fetched:
            pub, sec = fetched
            return _sync_prana_keys_into_environ(pub, sec)

    print(
        "错误: 未配置 PRANA_SKILL_API_FLAG，且 GET /api/v2/api-keys 失败，或未配置可访问的 --base-url / NEXT_PUBLIC_URL。\n"
        "  可选方式：\n"
        "  1) 设置 PRANA_SKILL_API_FLAG 为 `pk_...:sk_...`（与同次接口返回的 data.api_key 一致）。\n"
        "  2) 保证 --base-url（或 NEXT_PUBLIC_URL）可访问；",
        file=sys.stderr,
    )
    sys.exit(2)


def _claw_target_system_for_body(cfg: dict) -> str | None:
    """封装包内嵌/ frontmatter 的 encapsulation_target，作为 Claw 请求体 target_system。"""
    ts = str(cfg.get("encapsulation_target") or "").strip()
    return ts if ts else None


def _is_prana_encapsulation(cfg: dict) -> bool:
    """Prana 分发：可读写沙盒 THREAD_ID，与其它平台区分。"""
    return (cfg.get("encapsulation_target") or "").strip().lower() == "prana"


def _extract_response_thread_id(payload: dict) -> str:
    """从 Claw 信封 JSON 取 data.thread_id。"""
    data = payload.get("data")
    if isinstance(data, dict):
        tid = data.get("thread_id")
        if tid is not None and str(tid).strip():
            return str(tid).strip()
    return ""


def _user_facing_stdout_from_claw_envelope(result: Any) -> str:
    """
    渠道约定：优先输出 data.content（链接或文本）；否则输出完整 JSON（付费、running、错误等）。
    """
    if isinstance(result, dict):
        data = result.get("data")
        if isinstance(data, dict) and "content" in data:
            raw = data.get("content")
            if raw is not None:
                if isinstance(raw, str):
                    return raw
                return json.dumps(raw, ensure_ascii=False)
    return json.dumps(result, ensure_ascii=False, indent=2)


def _skill_key_safe_filename(skill_key: str) -> str:
    s = re.sub(r"[^\w\-.]", "_", (skill_key or "default").strip())[:120]
    return s or "default"


def _thread_id_state_dir() -> Path:
    raw = (os.environ.get("PRANA_THREAD_ID_STATE_DIR") or "").strip()
    if raw:
        return Path(raw)
    try:
        home = Path.home()
        if home.exists() and str(home) not in ("/", ""):
            return home / ".prana_skill_state"
    except Exception:
        pass
    return Path(tempfile.gettempdir()) / "prana_skill_state"


def _thread_id_state_file(skill_key: str) -> Path:
    return _thread_id_state_dir() / f"{_skill_key_safe_filename(skill_key)}_thread_id.txt"


def _read_stored_thread_id(skill_key: str) -> str:
    p = _thread_id_state_file(skill_key)
    try:
        if p.is_file():
            t = p.read_text(encoding="utf-8").strip()
            return t if t else ""
    except OSError:
        pass
    return ""


def _write_stored_thread_id(skill_key: str, tid: str) -> None:
    p = _thread_id_state_file(skill_key)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text((tid or "").strip() + "\n", encoding="utf-8")
    except OSError:
        pass


def _clear_stored_thread_id(skill_key: str) -> None:
    p = _thread_id_state_file(skill_key)
    try:
        p.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _emit_thread_id_session_hint(
    tid: str, *, prana_pack: bool, remote_skill_key: str
) -> None:
    """提示 THREAD_ID；并写入可写目录状态文件（技能包只读时仍可按 skill 续聊）。"""
    _write_stored_thread_id(remote_skill_key, tid)
    label = "Prana" if prana_pack else "OpenClaw/其它封装"
    state = _thread_id_state_file(remote_skill_key)
    print(
        f"[{label}] 续聊：已写入 thread_id 状态文件（{state}）；"
        f"亦可在同一会话 shell 执行 export THREAD_ID={tid}\n"
        f"新开会话或结束会话请使用 --new-session（-n）。\n"
        f"（可选环境变量 PRANA_THREAD_ID_STATE_DIR 指定状态目录）",
        file=sys.stderr,
    )


def resolve_effective_thread_id(
    cli_thread_id: str, *, new_session: bool, remote_skill_key: str
) -> str:
    """
    请求 agent-run 使用的 thread_id。
    --new-session：不传 thread_id；并清除状态文件。
    否则：优先 -t，其次环境变量 THREAD_ID，再次状态文件（见 _thread_id_state_file）。
    """
    if new_session:
        _clear_stored_thread_id(remote_skill_key)
        return ""
    t = (cli_thread_id or "").strip()
    if t:
        return t
    t = (os.environ.get("THREAD_ID") or "").strip()
    if t:
        return t
    return _read_stored_thread_id(remote_skill_key)


def build_invoke_content(cfg: dict, user_message: str) -> str:
    """
    组装请求 question：参数说明 + 用户消息。
    skill_key 来自 SKILL.md frontmatter，由调用方单独传入 HTTP body。
    """
    params_from_skill = (cfg.get("skill_invocation_params") or "").strip()
    lines = [
        f"参数：{params_from_skill}",
        f"用户消息：{user_message}",
    ]
    return "\n".join(lines)


def fetch_agent_result(
    base_url: str,
    request_id: str,
    public_key: str,
    secret_key: str,
    target_system: str | None = None,
) -> dict:
    """
    当 agent-run 超时或失败时，用同一 request_id 查询运行结果。
    POST /api/claw/agent-result  body: request_id；封装技能会附加 target_system（鉴权见 x-api-key）
    Header: x-api-key: public_key:secret_key
    """
    url = base_url.rstrip("/") + "/api/claw/agent-result"
    body: dict = {"request_id": request_id}
    if target_system:
        body["target_system"] = target_system
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers=_headers_x_api_key(public_key, secret_key),
    )
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SEC) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        try:
            return json.loads(err_body)
        except json.JSONDecodeError:
            return {
                "error": True,
                "status": e.code,
                "detail": err_body,
                "_from": "agent-result",
            }
    except urllib.error.URLError as e:
        return {"error": True, "detail": str(e.reason), "_from": "agent-result"}


def _claw_response_is_pay_required_envelope(payload: dict) -> bool:
    """付费技能未购买等：服务端 200 + data.status=pay_required，不得再改查 agent-result 或重试技能。"""
    if not isinstance(payload, dict) or payload.get("error") is True:
        return False
    data = payload.get("data")
    if not isinstance(data, dict):
        return False
    return str(data.get("status") or "").strip().lower() == "pay_required"


def _agent_result_payload_still_running(payload: dict) -> bool:
    """Claw 返回 data.status == running 时继续轮询。"""
    if payload.get("error") is True:
        return False
    if _claw_response_is_pay_required_envelope(payload):
        return False
    data = payload.get("data")
    if not isinstance(data, dict):
        return False
    return str(data.get("status") or "").strip().lower() == "running"


def _poll_agent_result_until_settled(
    base_url: str,
    request_id: str,
    public_key: str,
    secret_key: str,
    *,
    target_system: str | None = None,
    trigger_reason: str = "需通过 agent-result 拉取结果",
) -> dict:
    """
    每隔 AGENT_RESULT_POLL_INTERVAL_SEC 秒请求一次 POST /api/claw/agent-result，
    直至 data.status 不为 running（或响应不含 running）、或达到最大次数。
    首次请求前也会先等待一个间隔（agent-run 刚返回非 JSON 时任务往往尚未写入结果）。
    """
    interval = max(1, AGENT_RESULT_POLL_INTERVAL_SEC)
    max_attempts = max(1, AGENT_RESULT_POLL_MAX_ATTEMPTS)
    last: dict = {}
    for attempt in range(1, max_attempts + 1):
        if attempt == 1:
            print(
                f"提示: {trigger_reason}，{interval} 秒后首次 POST /api/claw/agent-result … "
                f"(request_id={request_id}, 最多 {max_attempts} 次，每 {interval}s)",
                file=sys.stderr,
            )
        else:
            print(
                f"提示: 第 {attempt} 次查询 agent-result（间隔 {interval}s）…",
                file=sys.stderr,
            )
        time.sleep(interval)
        last = fetch_agent_result(
            base_url, request_id, public_key, secret_key, target_system
        )
        if _claw_response_is_pay_required_envelope(last):
            return last
        if _agent_result_payload_still_running(last):
            continue
        return _mark_recovered(last)

    print(
        f"警告: agent-result 已轮询 {max_attempts} 次仍未结束，返回最后一次响应。",
        file=sys.stderr,
    )
    return _mark_recovered(last)


def _mark_recovered(d: dict) -> dict:
    d = dict(d)
    d["_recovered_via"] = "agent-result"
    return d


def invoke_prana(
    base_url: str,
    skill_key: str,
    content: str,
    thread_id: str | None,
    request_id: str,
    public_key: str,
    secret_key: str,
    target_system: str | None = None,
) -> dict:
    """
    调用 Prana 技能执行接口。
    body: skill_key, question, thread_id, request_id；封装技能可含 target_system（不含 api_key）
    Header: x-api-key: public_key:secret_key
    若 HTTP 超时、连接失败，或网关类错误（5xx / 408 / 504），或 200 但响应非合法 JSON，则改调 agent-result：
    自首次查询起按 AGENT_RESULT_POLL_INTERVAL_SEC（默认 120s）间隔轮询，直至非 running 或达上限。
    若响应为付费引导（data.status=pay_required），直接返回该 JSON，**不**轮询 agent-result、不重试技能。
    """
    url = base_url.rstrip("/") + "/api/claw/agent-run"
    body: dict = {
        "skill_key": skill_key,
        "question": content,
        "request_id": request_id,
    }
    tid = (thread_id or "").strip()
    if tid:
        body["thread_id"] = tid
    if target_system:
        body["target_system"] = target_system
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers=_headers_x_api_key(public_key, secret_key),
    )
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SEC) as resp:
            raw = resp.read().decode("utf-8")
            # pay_required 等仅为合法 JSON，直接返回，不走 agent-result 轮询（见下方 except）
            return json.loads(raw)
    except json.JSONDecodeError:
        return _poll_agent_result_until_settled(
            base_url,
            request_id,
            public_key,
            secret_key,
            target_system=target_system,
            trigger_reason="agent-run 响应非合法 JSON",
        )
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        # 网关/服务端错误或超时类状态：任务可能已在服务端执行，改查 agent-result
        if e.code >= 500 or e.code in (408, 504):
            return _poll_agent_result_until_settled(
                base_url,
                request_id,
                public_key,
                secret_key,
                target_system=target_system,
                trigger_reason=f"agent-run HTTP {e.code}，改查 agent-result",
            )
        try:
            return json.loads(err_body)
        except json.JSONDecodeError:
            return {"error": True, "status": e.code, "detail": err_body}
    except urllib.error.URLError:
        # 含连接失败、DNS、超时等
        return _poll_agent_result_until_settled(
            base_url,
            request_id,
            public_key,
            secret_key,
            target_system=target_system,
            trigger_reason="agent-run 网络异常",
        )
    except TimeoutError:
        return _poll_agent_result_until_settled(
            base_url,
            request_id,
            public_key,
            secret_key,
            target_system=target_system,
            trigger_reason="agent-run 超时",
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="调用 Prana 远程技能服务")
    parser.add_argument("--message", "-m", required=True, help="用户消息 / 任务描述")
    parser.add_argument(
        "--thread-id",
        "-t",
        default="",
        help="对话 thread_id；未传时读环境变量 THREAD_ID 或状态文件（~/.prana_skill_state/ 或 PRANA_THREAD_ID_STATE_DIR）",
    )
    parser.add_argument(
        "--new-session",
        "-n",
        action="store_true",
        help="新开会话或结束上一会话：本次不传 thread_id（忽略 -t 与 THREAD_ID）",
    )
    parser.add_argument("--base-url", "-b", default=DEFAULT_PRANA_BASE, help="Prana API 根地址")
    args = parser.parse_args()

    cfg = load_skill_config()
    skill_key = cfg.get("skill_key") or ""
    if not skill_key:
        print(
            "错误: 配置中缺少远端 skill_key（请检查脚本内 _ENCAPSULATION_EMBEDDED 或旧版 SKILL.md）",
            file=sys.stderr,
        )
        sys.exit(1)

    public_key, secret_key = load_prana_credentials(args.base_url)
    request_id = str(uuid.uuid4())
    content = build_invoke_content(cfg, args.message)
    claw_ts = _claw_target_system_for_body(cfg)
    eff_thread = resolve_effective_thread_id(
        args.thread_id,
        new_session=args.new_session,
        remote_skill_key=skill_key,
    )
    result = invoke_prana(
        args.base_url,
        skill_key,
        content,
        eff_thread or None,
        request_id,
        public_key,
        secret_key,
        claw_ts,
    )
    if not _claw_response_is_pay_required_envelope(result):
        tid_out = _extract_response_thread_id(result)
        if tid_out:
            _emit_thread_id_session_hint(
                tid_out,
                prana_pack=_is_prana_encapsulation(cfg),
                remote_skill_key=skill_key,
            )
    print(_user_facing_stdout_from_claw_envelope(result))


if __name__ == "__main__":
    main()
