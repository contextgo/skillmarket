---
name: A股多维度深度分析skill
description: 通过基本面、技术面、机构动向等多个维度对股票进行数据深度分析，生成交互式HTML分析报告。帮助投资者多方面了解股票的各项指标和数据。
encapsulation_target: skillhub
skill_key: stock_scoring_analysis_v2_public
original_skill_key: stock_scoring_analysis_v2
---
# 一、运行流程说明

1. 调用任何接口前先检查 OpenClaw 环境中是否已配置 **`PRANA_SKILL_API_FLAG`**（值为 **`pk_...:sk_...`** 整段，与同次 `GET /api/v2/api-keys` 返回的 `data.api_key` 一致）：

- 若已配置，直接进入第5步；

- 若未配置，执行第2步获取密钥。

2. 调用接口`GET /api/v2/api-keys`，在响应 `data.api_key` 中得到 **`pk_...:sk_...`** 单一字符串，写入环境变量 **`PRANA_SKILL_API_FLAG`**。

接口调用命令：

```bash
curl -sS https://claw-uat.ebonex.io/api/v2/api-keys
```

接口正常响应示例：

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "api_key": "pk_CFkNCTgAnQs7CPnqXSHkkA6ofwiHxemL:sk_roynxpnzfzjuLG05dFNYHtSfrBHFOr0y"
  }
}
```

3. 将 `data.api_key` 配置到 OpenClaw（**一条变量即可**）：

```bash
openclaw config set env.PRANA_SKILL_API_FLAG "<粘贴 data.api_key 整段>"
```

4. 校验：**`PRANA_SKILL_API_FLAG`** 非空且包含一个英文冒号 `:`（`pk` 与 `sk` 两段）；不满足则回到第3步；未配置则提示并终止；通过后进入第5步。

5. 脚本执行：根据本机已安装的客户端选择运行方式，**默认优先使用 Node.js**；若未安装 Node.js 或无法使用时再选用 Python 3。

- **Node.js 18+（默认）**

  **Node 依赖**（包根目录执行 `npm install yaml` 安装 `yaml` 解析库；）：

  ```bash
  npm install yaml
  ```

  安装完成后执行（Node **20.10+**，按需将本目录作为 ESM 解析 `import`）：

  ```bash
  NODE_OPTIONS=--experimental-default-type=module node scripts/prana_skill_client.js -m "…" [-t thread_id] [-n]
  ```

- **Python 3（备选）**

  **Python 脚本 pip 依赖**（用于解析 `SKILL.md` 的 YAML frontmatter）：

  ```bash
  pip install pyyaml
  ```

  安装完成后执行：`python3 scripts/prana_skill_client.py -m "…" [-t thread_id] [-n]`

**封装与会话 `thread_id`：** 除首轮或明示新会话外，应在请求中带上上一个响应的 `data.thread_id`。薄客户端会写入状态文件（见上 Prana 节）并提示 `THREAD_ID`；OpenClaw 多轮独立进程时**优先依赖状态文件**。**`--new-session`（`-n`）** 会清除状态且本次 JSON **省略** `thread_id`。
## 运行与结果展示约定

集成方在运行本封装技能时：对 **`/api/claw/agent-run`** 与 **`/api/claw/agent-result`** 返回的响应体，请从 **`data.content`** 取出内容交给最终用户：**若为链接（URL 字符串），将完整链接直接发给用户**；**若为普通文本，将原文发给用户**。**不要**对业务结果做额外摘要、改写或拼接。无 `data.content`（例如running、错误 envelope）时，可将整段 JSON 交给用户或按产品规则提示。如果是需付费引导，返回付费链接

薄客户端优先在标准输出打印 `data.content`（存在且非 null 时）；否则打印完整 JSON 便于排障。

**鉴权与 agent-run**每次 **`POST /api/claw/agent-run`** 前，薄客户端**先检查环境变量 `PRANA_SKILL_API_FLAG`**（`pk:sk`）；**有则直接带 `x-api-key` 调用，不再请求** `GET /api/v2/api-keys`；**无则再 GET** 并将结果注入进程环境为 **`PRANA_SKILL_API_FLAG`**。

**长任务与网络异常**两脚本行为一致——在上述凭证就绪后请求 `POST /api/claw/agent-run`；若返回的是需要付费，直接返回，等待付费成功；对 agent-run 的重试前仍应先确认环境变量中密钥仍完整，避免重复 GET；若接口超时、连接失败、网关 / 服务端错误（5xx、408、504），或 **running** 但响应非合法 JSON，会改查 `POST /api/claw/agent-result`。**首次查询前会等待 120 秒**，之后若 `data.status` 仍为 `running`，则每隔 120 秒再查一次，直至结束或达上限（默认 20 次）。可用 `PRANA_AGENT_RESULT_POLL_INTERVAL_SEC`、`PRANA_AGENT_RESULT_POLL_MAX_ATTEMPTS` 调整。

# 二、获取Prana历史支付记录

用户获取可在浏览器中打开的 **历史支付记录（技能购买记录）** 页面链接: https://claw-uat.ebonex.io/api/claw/skill-purchase-history-url。须先完成 **第一节**，已配置 **`PRANA_SKILL_API_FLAG`**（值为 `pk_...:sk_...`）。

1. 前置校验：

- 若 **`PRANA_SKILL_API_FLAG`** 未配置或无效：提示需先配置环境变量，并终止本流程；

- 若已配置：进入第2步。

2. 构造请求头 **`x-api-key`**：取值与 **`PRANA_SKILL_API_FLAG` 完全相同**（即 `pk_...:sk_...` 整段）。示例：`x-api-key: pk_abc:sk_xyz`（与 `PRANA_SKILL_API_FLAG` 一致）。

3. 调用接口`GET /api/claw/skill-purchase-history-url`。

- **成功时**：从响应体 `data.url` 取出链接。不要把返回的完整链接写进日志；把完整链接直接发给用户即可。

接口调用命令：

```bash
curl -sS -H "x-api-key: pk_...:sk_..." https://claw-uat.ebonex.io/api/claw/skill-purchase-history-url
```

接口正常响应示例：

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "url": "https://prana.chat/skill-purchase-history?pay_token=xxxxxxx"
  }
}
```

