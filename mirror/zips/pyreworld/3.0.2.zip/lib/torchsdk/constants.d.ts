import { PublicKey } from '@solana/web3.js';
export declare const PROGRAM_ID: PublicKey;
export declare const getRaydiumCpmmProgram: () => PublicKey;
/** @deprecated Use getRaydiumCpmmProgram() for dynamic network support */
export declare const RAYDIUM_CPMM_PROGRAM: PublicKey;
export declare const WSOL_MINT: PublicKey;
export declare const getRaydiumAmmConfig: () => PublicKey;
/** @deprecated Use getRaydiumAmmConfig() for dynamic network support */
export declare const RAYDIUM_AMM_CONFIG: PublicKey;
export declare const getRaydiumFeeReceiver: () => PublicKey;
/** @deprecated Use getRaydiumFeeReceiver() for dynamic network support */
export declare const RAYDIUM_FEE_RECEIVER: PublicKey;
export declare const MEMO_PROGRAM_ID: PublicKey;
export declare const TOKEN_2022_PROGRAM_ID: PublicKey;
export declare const GLOBAL_CONFIG_SEED = "global_config";
export declare const BONDING_CURVE_SEED = "bonding_curve";
export declare const TREASURY_SEED = "treasury";
export declare const USER_POSITION_SEED = "user_position";
export declare const VOTE_SEED = "vote";
export declare const PROTOCOL_TREASURY_SEED = "protocol_treasury_v11";
export declare const USER_STATS_SEED = "user_stats";
export declare const STAR_RECORD_SEED = "star_record";
export declare const LOAN_SEED = "loan";
export declare const COLLATERAL_VAULT_SEED = "collateral_vault";
export declare const TORCH_VAULT_SEED = "torch_vault";
export declare const VAULT_WALLET_LINK_SEED = "vault_wallet";
export declare const TREASURY_LOCK_SEED = "treasury_lock";
export declare const TOTAL_SUPPLY: bigint;
export declare const TOKEN_DECIMALS = 6;
export declare const LEGACY_MINTS: string[];
export declare const BLACKLISTED_MINTS: string[];
export declare const LAMPORTS_PER_SOL = 1000000000;
export declare const TOKEN_MULTIPLIER: number;
//# sourceMappingURL=constants.d.ts.map