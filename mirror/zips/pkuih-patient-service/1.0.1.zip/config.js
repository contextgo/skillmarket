/**
 * 配置管理
 * 优先级：环境变量 > 配置文件 > null
 */

const fs = require('fs');
const path = require('path');

// 配置文件路径
const CONFIG_FILE = path.join(__dirname, '.pkuih.config.json');

// 从配置文件读取（如果存在）
let fileConfig = {};
if (fs.existsSync(CONFIG_FILE)) {
  try {
    fileConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
  } catch (error) {
    // 忽略配置文件错误
  }
}

module.exports = {
  // API 服务器地址（固定）
  apiBase: 'https://server.pkucare.com',
  
  // API 密钥（优先级：环境变量 > 配置文件 > null）
  apiKey: process.env.PKUIH_API_KEY || fileConfig.apiKey || null,
  
  // 状态文件路径（临时）
  stateFile: '/tmp/pkuih_state.json',
  
  // Token 有效期（毫秒）
  tokenTTL: 30 * 60 * 1000,  // 30 分钟
  
  // 验证码间隔（秒）
  captchaInterval: 60,
  
  // 配置文件路径
  configFile: CONFIG_FILE,
  
  /**
   * 从配置文件获取 token
   */
  getTokenFromFile() {
    if (!fileConfig.token) return null;
    
    // 检查是否过期
    if (fileConfig.tokenExpiresAt && Date.now() > fileConfig.tokenExpiresAt) {
      return null;  // token 已过期
    }
    
    return fileConfig.token;
  },
  
  /**
   * 保存 token 到配置文件
   */
  saveTokenToFile(token, user) {
    const config = {
      ...fileConfig,
      token: token,
      tokenExpiresAt: Date.now() + this.tokenTTL,
      user: user
    };
    
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
    
    // 重新加载配置
    fileConfig = config;
  },
  
  /**
   * 清除配置文件中的 token
   */
  clearTokenFromFile() {
    if (fileConfig.token) {
      delete fileConfig.token;
      delete fileConfig.tokenExpiresAt;
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(fileConfig, null, 2), 'utf-8');
    }
  }
};
