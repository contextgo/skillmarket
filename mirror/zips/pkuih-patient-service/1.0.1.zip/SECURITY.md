# 安全说明

本文档说明 pkuih-hospital Skill 的安全特性和最佳实践。

## 🔒 安全特性

### 1. Token 管理

- **30 分钟自动过期** - Token 保存后 30 分钟自动失效
- **安全存储** - Token 存储在 `/tmp/pkuih_state.json`，文件权限设置为 `0600`（仅所有者可读写）
- **自动清理** - Token 过期或登出时自动删除状态文件
- **日志脱敏** - 所有日志中 Token 显示为 `***`，不暴露完整值

### 2. API Key 保护

- **环境变量优先** - API Key 优先从环境变量 `PKUIH_API_KEY` 读取
- **配置文件备份** - 配置文件中 API Key 已添加到 `.gitignore`
- **日志脱敏** - API Key 在日志中仅显示前 8 位 + `***`

### 3. 敏感信息保护

- **不暴露完整 Token** - 所有 console.log 中 Token 均脱敏
- **不暴露身份证号** - 用户身份证号不在日志中显示
- **不暴露手机号** - 日志中手机号已脱敏处理（生产环境建议）

### 4. 文件安全

```
.gitignore 已配置：
- .pkuih.config.json (配置文件)
- /tmp/pkuih_state.json (状态文件)
- node_modules/
- *.log
```

### 5. 安全级别

| 操作类型 | 安全级别 | 验证方式 |
|----------|---------|---------|
| 查询科室/排班 | LOW | 检查本地状态 |
| 查看报告 | LOW | 检查本地状态 |
| 预约挂号 | MEDIUM | 本地状态 + API 验证 |
| 在线缴费 | HIGH | 强制重新登录 |
| 取消预约 | HIGH | 强制重新登录 |

## ⚠️ 安全警告

### 不要做的事

1. ❌ **不要提交配置文件到版本控制**
   ```bash
   # 错误：会暴露 API Key 和用户信息
   git add .pkuih.config.json
   
   # 正确：已在 .gitignore 中
   ```

2. ❌ **不要在生产环境使用测试 API Key**
   ```javascript
   // 错误：硬编码 API Key
   const apiKey = "jD3UFiE1Lo27EsdKZvMP8EHdkkFao1Q@Joum__MCsVTXoCLNGrJgjKyNq4VZDUOr";
   
   // 正确：使用环境变量
   const apiKey = process.env.PKUIH_API_KEY;
   ```

3. ❌ **不要在日志中输出敏感信息**
   ```javascript
   // 错误：暴露完整 token
   console.log('token:', token);
   
   // 正确：脱敏处理
   console.log('token:', token ? '***' : '无');
   ```

4. ❌ **不要共享状态文件**
   ```bash
   # 错误：状态文件包含有效 token
   cp /tmp/pkuih_state.json /shared/location
   ```

### 应该做的事

1. ✅ **使用环境变量管理 API Key**
   ```bash
   export PKUIH_API_KEY="your_api_key"
   ```

2. ✅ **定期清理状态文件**
   ```bash
   # 登出后自动清理，也可手动清理
   rm /tmp/pkuih_state.json
   ```

3. ✅ **使用安全的文件权限**
   ```bash
   # 配置文件权限（如果必须存在）
   chmod 600 .pkuih.config.json
   ```

4. ✅ **在生产环境启用日志脱敏**
   - 所有 Token 显示为 `***`
   - API Key 仅显示前 8 位
   - 不输出完整请求体中的敏感字段

## 🚨 安全事件响应

### 如果 API Key 泄露

1. 立即联系医院信息科更换 API Key
2. 更新环境变量和配置文件
3. 检查是否有异常调用记录

### 如果 Token 泄露

1. Token 30 分钟后自动过期
2. 如需立即失效，联系医院重置用户会话
3. 修改登录密码（如果支持）

### 如果用户信息泄露

1. 立即通知用户
2. 检查日志和访问记录
3. 必要时报警处理

## 📋 安全检查清单

部署前检查：

- [ ] API Key 已设置到环境变量
- [ ] 配置文件已添加到 `.gitignore`
- [ ] 状态文件路径正确（`/tmp/pkuih_state.json`）
- [ ] 日志中无敏感信息泄露
- [ ] 文件权限设置正确（`chmod 600`）
- [ ] Token 30 分钟过期机制正常
- [ ] 敏感操作需要重新验证

## 📞 安全联系

发现安全漏洞，请：
1. 提交 Issue 到 Gitee 仓库（不要公开细节）
2. 或直接联系作者：高坤

---

**最后更新**: 2026-04-11  
**版本**: v2.2.4
