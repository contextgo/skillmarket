# pkuih-hospital v2.0.0

北京大学国际医院医疗服务 Skill - 分层模块化架构

## 🎯 版本亮点

- ✅ **分层架构** - 核心层 + 业务模块，代码清晰易维护
- ✅ **状态持久化** - 30 分钟短时记忆，跨会话无需重新登录
- ✅ **安全策略** - 敏感操作强制重验，保障账户安全
- ✅ **模块化设计** - 挂号、报告、缴费独立模块，按需使用
- ✅ **易扩展** - 新增功能只需添加模块，不影响现有代码

## 📁 目录结构

```
pkuih-hospital/
├── core/                    # 核心层
│   ├── state.js            # 状态管理（持久化）
│   ├── auth.js             # 认证管理
│   ├── request.js          # HTTP 请求封装
│   └── security.js         # 安全策略
│
├── modules/                 # 业务模块
│   ├── appointment/        # 挂号模块
│   ├── report/             # 报告模块（预留）
│   └── payment/            # 缴费模块（预留）
│
├── utils.js                 # 工具函数
├── config.js                # 配置管理
├── index.js                 # 统一导出
├── SKILL.md                 # Skill 文档
└── README.md                # 使用说明
```

## 🚀 快速开始

### 1. 申请 API Key（⚠️ 必须）

**申请方式**:
1. 打开微信，搜索「**北京大学国际医院**」小程序
2. 登录/注册个人账号
3. 申请 API Key（具体入口请咨询医院信息科）
4. 复制并保存 API Key

⚠️ **重要**: API Key 是使用本服务的前提！

### 2. 配置环境变量

```bash
# 推荐方式：添加到 ~/.profile（永久生效）
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile

# 验证是否生效
echo $PKUIH_API_KEY
```

### 3. 安装依赖

### 2. 基本使用

```javascript
const pkuih = require('pkuih-hospital');

// 登录
const captcha = await pkuih.getCaptcha();
await pkuih.sendSms('18612707357', captcha.captcha_key, captcha.captcha_code);
await pkuih.login('18612707357', '短信验证码');

// 查询排班
const doctors = await pkuih.appointment.getDoctorSchedule('005003', '2026-04-10', '2026-04-17');

// 预约
const slot = doctors[0].sch_list.find(s => s.remain > 0);
await pkuih.appointment.book(doctors[0], slot);
```

### 3. 跨会话使用

```javascript
// 第一次会话
await pkuih.login('18612707357', smsCode);
// 状态持久化到 /tmp/pkuih_state.json

// 第二次会话（30 分钟内）
const pkuih = require('pkuih-hospital');
// 自动恢复登录状态
const reports = await pkuih.report.getLabReports('000100158400');
```

## 🔐 安全策略

| 操作 | 安全级别 | 说明 |
|------|---------|------|
| 查询 | LOW | 检查本地状态 |
| 预约 | MEDIUM | 验证 token 有效性 |
| 支付 | HIGH | 强制重新登录 |

## 📊 性能指标

- 首次加载：< 200ms
- 状态恢复：< 100ms
- API 调用：< 2s
- 内存占用：< 50MB

## 🔄 从 v1.x 迁移

### API 兼容性

```javascript
// v1.x
await pkuih.getDoctorSchedule('005003');
await pkuih.book(doctor, slot);

// v2.0 - 保持兼容
await pkuih.getDoctorSchedule('005003');  // ✅ 可用
await pkuih.book(doctor, slot);  // ✅ 可用

// v2.0 - 推荐方式
await pkuih.appointment.getDoctorSchedule('005003');
await pkuih.appointment.book(doctor, slot);
```

### 新增功能

```javascript
// 检查登录状态
if (pkuih.isLoggedIn()) {
  // 已登录
}

// 获取当前用户
const user = pkuih.getCurrentUser();

// 安全登出
pkuih.logout();
```

## 🛠️ 开发指南

### 添加新模块

1. 在 `modules/` 创建新目录
2. 实现模块功能
3. 在 `index.js` 导出

### 测试

```bash
# 单元测试
npm test

# 集成测试
node test/integration.js
```

## 📦 版本历史

- **v2.0.0** (2026-04-10) - 分层模块化重构
- **v1.0.14** (2026-04-10) - 清理调试日志

## 📞 支持

- 仓库：https://gitee.com/vegetable-bird-0209/pkuih_service.git
- 作者：高坤
