# pkuih-hospital 安装与配置指南

本文档详细说明如何安装和配置 pkuih-hospital Skill。

## 📋 前置要求

### 1. Node.js 环境

- **版本要求**: Node.js 18.0 或更高版本
- **检查方式**: `node --version`
- **安装方式**: 访问 https://nodejs.org/

### 2. Git

- 用于克隆代码仓库
- **检查方式**: `git --version`
- **安装方式**: `sudo apt install git` (Ubuntu/Debian) 或 `brew install git` (macOS)

### 3. API Key

- **申请方式**: 前往「北京大学国际医院」微信小程序申请
- **格式**: 类似 `jD3UFiE1Lo27EsdKZvMP8EHdkkFao1Q@Joum__MCsVTXoCLNGrJgjKyNq4VZDUOr`
- **重要性**: ⚠️ **必须配置，否则无法使用**

---

## 🚀 安装步骤

### 步骤 1: 克隆仓库

```bash
# 选择安装目录
cd /path/to/your/workspace

# 克隆仓库
git clone https://gitee.com/vegetable-bird-0209/pkuih_service.git pkuih-hospital

# 进入目录
cd pkuih-hospital
```

### 步骤 2: 申请 API Key（⚠️ 必须）

1. **打开微信**，搜索「北京大学国际医院」小程序
2. **登录/注册** 个人账号
3. **申请 API Key**（具体入口请咨询医院信息科或查看小程序帮助）
4. **复制 API Key**，格式类似：`jD3UFiE1Lo27EsdKZvMP8EHdkkFao1Q@Joum__MCsVTXoCLNGrJgjKyNq4VZDUOr`

⚠️ **注意**: API Key 是使用本服务的前提，请务必先完成申请。

---

### 步骤 3: 配置环境变量（⚠️ 必须）

#### 方式 1: 添加到 ~/.profile（推荐，永久生效）

```bash
# 编辑 ~/.profile
nano ~/.profile

# 在文件末尾添加
export PKUIH_API_KEY="你的 API Key"

# 保存后，重新登录或执行
source ~/.profile
```

#### 方式 2: 添加到 ~/.bashrc（仅交互式 shell）

```bash
# 编辑 ~/.bashrc
nano ~/.bashrc

# 在文件末尾添加
export PKUIH_API_KEY="你的 API Key"

# 保存后执行
source ~/.bashrc
```

⚠️ **重要提示**:
- `~/.bashrc` 中的配置**不会**在非交互式 shell（如脚本、Node.js 子进程）中加载
- **强烈建议使用 `~/.profile`**，它支持所有类型的 shell

#### 方式 3: 临时设置（仅当前会话）

```bash
export PKUIH_API_KEY="你的 API Key"
```

⚠️ **注意**: 关闭终端后会失效

---

### 步骤 4: 验证配置

```bash
# 验证环境变量是否生效
echo $PKUIH_API_KEY

# 应该输出你的 API Key（部分）
# 例如：jD3UFiE1Lo27EsdKZvMP...
```

如果输出为空，说明配置未生效，请检查：
1. 是否已执行 `source ~/.profile` 或 `source ~/.bashrc`
2. 是否需要重新登录
3. API Key 是否正确配置

---

## 🔧 测试安装

### 快速测试

```bash
cd pkuih-hospital

# 运行测试脚本（如果有的话）
node test.js
```

### 功能测试

```javascript
const pkuih = require('./index.js');

// 测试模块加载
console.log('✅ 模块加载成功');

// 测试环境变量
if (!process.env.PKUIH_API_KEY) {
  console.error('❌ 环境变量 PKUIH_API_KEY 未配置');
  process.exit(1);
}

console.log('✅ 环境变量已配置');
```

---

## 📝 使用说明

### 基本流程

1. **获取验证码**
   ```javascript
   const captcha = await pkuih.getCaptcha();
   console.log('验证码:', captcha.captcha_code);
   ```

2. **发送短信**
   ```javascript
   await pkuih.sendSms('手机号', captcha.captcha_key, captcha.captcha_code);
   ```

3. **登录**
   ```javascript
   const user = await pkuih.login('手机号', '短信验证码');
   console.log('登录成功:', user.name);
   ```

4. **查询排班**
   ```javascript
   const doctors = await pkuih.appointment.getDoctorSchedule('科室代码', '开始日期', '结束日期');
   ```

5. **预约挂号**
   ```javascript
   const result = await pkuih.appointment.bookAppointment(医生，号源，序号);
   console.log('预约成功:', result.apt_id);
   ```

---

## ⚠️ 常见问题

### 1. "无效的 API Key" 或 "未配置 API Key"

**原因**: 环境变量未配置或配置错误

**解决方案**:
```bash
# 检查是否配置
echo $PKUIH_API_KEY

# 如果为空，重新配置
export PKUIH_API_KEY="你的 API Key"

# 永久配置添加到 ~/.profile
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile
```

**还没有 API Key？**
1. 打开微信，搜索「北京大学国际医院」小程序
2. 登录个人账号
3. 申请 API Key（具体入口请咨询医院信息科）
4. 复制并配置到环境变量

### 2. "登录已过期，请重新登录"

**原因**: Token 已过期（30 分钟有效期）

**解决方案**: 重新执行登录流程

### 3. "号位状态不是未用"

**原因**: 
- 号位已被其他用户预约
- 号位已被当前用户预约（重复提交）
- 号位状态已变更（停诊、约满等）

**解决方案**:
1. 重新查询排班，获取最新号源状态
2. 选择其他可用号位
3. 避免重复提交同一号位

### 4. 环境变量不生效

**原因**: `~/.bashrc` 在非交互式 shell 中不加载

**解决方案**:
```bash
# 使用 ~/.profile 而不是 ~/.bashrc
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile
```

---

## 🔒 安全注意事项

### 1. 保护 API Key

- ⚠️ **不要**将 API Key 提交到 Git 仓库
- ⚠️ **不要**在公开场合分享 API Key
- ⚠️ **不要**硬编码在代码中

✅ **正确做法**:
```bash
# 使用环境变量
export PKUIH_API_KEY="你的 API Key"

# 在代码中读取
const apiKey = process.env.PKUIH_API_KEY;
```

### 2. 配置文件保护

`.pkuih.config.json` 包含敏感信息，已自动添加到 `.gitignore`

如果误提交，立即：
```bash
# 从 Git 历史中移除
git rm --cached .pkuih.config.json
git commit -m "Remove sensitive config file"

# 联系医院更换 API Key
```

### 3. 状态文件

- 位置：`/tmp/pkuih_state.json`
- 包含：Token、用户信息
- 权限：`0600`（仅所有者可读写）
- 过期：30 分钟自动失效

---

## 📞 获取帮助

### API Key 申请

1. **首选方式**: 前往「北京大学国际医院」微信小程序申请
   - 打开微信 → 搜索「北京大学国际医院」
   - 登录个人账号
   - 查找 API Key 申请入口

2. **备选方式**: 联系医院信息科获取
   - 提供个人身份信息和用途说明
   - 等待审核和发放

### 技术支持

- **仓库**: https://gitee.com/vegetable-bird-0209/pkuih_service.git
- **Issue**: 在 Gitee 提交 Issue
- **作者**: 高坤

### 文档

- `SKILL.md` - Skill 功能说明
- `README.md` - 项目说明
- `SECURITY.md` - 安全说明
- `INSTALL.md` - 本文档

---

## 📋 检查清单

安装完成后，请确认：

- [ ] Node.js 版本 >= 18.0
- [ ] Git 已安装
- [ ] **已申请 API Key**（北京大学国际医院微信小程序）
- [ ] 环境变量已配置 (`echo $PKUIH_API_KEY` 有输出)
- [ ] 模块可以加载 (`node -e "require('./index.js')"`)
- [ ] 配置文件已排除在 Git 外 (`git status` 不显示 `.pkuih.config.json`)

---

**最后更新**: 2026-04-11  
**版本**: v2.2.6
