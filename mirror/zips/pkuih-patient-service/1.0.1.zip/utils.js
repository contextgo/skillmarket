/**
 * 工具函数
 */

/**
 * 解析日期字符串
 */
function parseDate(dateStr) {
  if (!dateStr) return null;
  
  const today = new Date();
  
  if (dateStr === '今天' || dateStr === 'today') {
    return formatDate(today);
  }
  
  if (dateStr === '明天' || dateStr === 'tomorrow') {
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    return formatDate(tomorrow);
  }
  
  const match = dateStr.match(/(\d{1,2}) 月 (\d{1,2}) 日/);
  if (match) {
    const year = today.getFullYear();
    const month = String(match[1]).padStart(2, '0');
    const day = String(match[2]).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  return dateStr;
}

/**
 * 格式化日期为 YYYY-MM-DD
 */
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * 获取日期范围
 */
function getDateRange(days = 7) {
  const today = new Date();
  const startDate = formatDate(today);
  
  const endDateObj = new Date(today);
  endDateObj.setDate(today.getDate() + days);
  const endDate = formatDate(endDateObj);
  
  return { startDate, endDate };
}

module.exports = {
  parseDate,
  formatDate,
  getDateRange
};
