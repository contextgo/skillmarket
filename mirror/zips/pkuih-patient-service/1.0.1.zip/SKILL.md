# pkuih-hospital - 北京大学国际医院医疗服务 Skill

## 📋 简介

北京大学国际医院医疗服务 Skill，提供挂号预约、报告查看、在线缴费等一站式医疗服务。

## ✨ 功能特性

### 🏥 挂号服务
- ✅ 查询科室列表
- ✅ 查询医生排班
- ✅ 预约挂号
- ✅ 查询预约记录

### 📋 报告服务（即将推出）
- 🔜 检验报告查询
- 🔜 检查报告查询

### 💰 缴费服务（即将推出）
- 🔜 待缴费查询
- 🔜 在线缴费

## 🔒 安全特性

- **Token 30 分钟自动过期** - 保障账户安全
- **敏感操作强制重验** - 支付、取消等操作需重新验证
- **状态自动清理** - 登出或过期后自动清除敏感数据

## 🚀 快速开始

### 1. 安装 Skill

```bash
# 克隆仓库
git clone https://gitee.com/vegetable-bird-0209/pkuih_service.git
cd pkuih_service
```

### 2. 申请 API Key（⚠️ 必须）

**申请方式**:
1. 打开微信，搜索「**北京大学国际医院**」小程序
2. 登录/注册个人账号
3. 申请 API Key（具体入口请咨询医院信息科或查看小程序帮助）
4. 复制 API Key，格式类似：`jD3UFiE1Lo27EsdKZvMP8EHdkkFao1Q@Joum__MCsVTXoCLNGrJgjKyNq4VZDUOr`

⚠️ **重要**: API Key 是使用本服务的前提，请务必先完成申请。

⚠️ **安全**: 不要将 API Key 提交到 Git 仓库（已自动添加到 `.gitignore`）

### 3. 配置环境变量（⚠️ 必须）

**⚠️ 重要**: 环境变量必须配置在 `~/.profile` 中（不是 `~/.bashrc`），否则在非交互式 shell 中无法加载。

```bash
# 推荐方式：添加到 ~/.profile（永久生效，支持所有 shell）
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile

# 验证是否生效
echo $PKUIH_API_KEY
```

**为什么不用 ~/.bashrc？**
- `~/.bashrc` 只在交互式 shell 中加载
- Node.js 子进程、脚本等**非交互式 shell**不会加载 `~/.bashrc`
- 这会导致 `process.env.PKUIH_API_KEY` 为空

**详细说明请查看**: [INSTALL.md](./INSTALL.md)

### 4. 使用示例

#### 登录
```javascript
const pkuih = require('pkuih-hospital');

// 获取验证码
const captcha = await pkuih.getCaptcha();
console.log('验证码：', captcha.captcha_code);

// 发送短信
await pkuih.sendSms('18612707357', captcha.captcha_key, captcha.captcha_code);

// 登录
const user = await pkuih.login('18612707357', '短信验证码');
```

#### 查询排班
```javascript
// 查询中医科未来 7 天排班
const { startDate, endDate } = pkuih.getDateRange(7);
const doctors = await pkuih.appointment.getDoctorSchedule('005003', startDate, endDate);

// 查找黄娟医生
const huang = doctors.find(d => d.name.includes('黄娟'));
console.log('黄娟医生排班：', huang.sch_list);
```

#### 预约挂号
```javascript
// 选择号位
const slot = huang.sch_list.find(s => s.ampm === 'a' && s.remain > 0);

// 预约
const result = await pkuih.appointment.book(huang, slot);
console.log('预约成功！序号：', result.sequence);
```

#### 跨会话使用
```javascript
// 第一次使用
await pkuih.login('18612707357', smsCode);
// ... 30 分钟内 ...

// 第二次使用（无需重新登录）
const pkuih = require('pkuih-hospital');
// 自动恢复登录状态
const reports = await pkuih.report.getLabReports('000100158400');
```

## 📚 API 文档

### 认证相关

#### `getCaptcha()`
获取图形验证码

#### `sendSms(phone, captchaKey, captchaCode)`
发送短信验证码

#### `login(phone, smsCode, smsId)`
登录

#### `logout()`
登出（清理状态）

#### `isLoggedIn()`
检查是否已登录

### 挂号模块

#### `appointment.getDoctorSchedule(deptCode, startDate, endDate)`
查询医生排班

**参数**:
- `deptCode` - 科室代码
- `startDate` - 开始日期 (YYYY-MM-DD)
- `endDate` - 结束日期 (YYYY-MM-DD)

**返回**: 医生列表（含排班信息）

#### `appointment.getScheduleDetail(schId)`
获取号位详情

**参数**:
- `schId` - 排班 ID

**返回**: 可用号位列表

#### `appointment.book(doctor, slot, sequence)`
预约挂号

**参数**:
- `doctor` - 医生对象
- `slot` - 号位对象
- `sequence` - 号位序号（可选，自动选择第一个）

**返回**: 预约结果

#### `appointment.getAppointments(options)`
查询预约记录

### 报告模块

#### `report.getLabReports(patientId, startDate, endDate)`
获取检验报告

### 缴费模块

#### `payment.getUnpaidOrders(patientId)`
获取待缴费订单

#### `payment.payOrder(orderId, payMethod)`
在线缴费（需重新验证身份）

## 🔐 安全级别说明

| 操作类型 | 安全级别 | 验证方式 |
|----------|---------|---------|
| 查询排班 | LOW | 检查本地状态 |
| 查看报告 | LOW | 检查本地状态 |
| 预约挂号 | MEDIUM | 本地状态 + API 验证 |
| 在线缴费 | HIGH | 强制重新登录 |
| 取消预约 | HIGH | 强制重新登录 |

## 📝 注意事项

1. **Token 有效期 30 分钟** - 超时需重新登录
2. **短信验证码 5 分钟有效** - 请尽快使用
3. **敏感操作需重验** - 支付、取消等操作要求重新验证身份
4. **状态文件位置** - `/tmp/pkuih_state.json`（自动清理）

## 🛠️ 开发指南

### 添加新功能模块

1. 在 `modules/` 下创建新目录
2. 实现模块功能
3. 在 `index.js` 中导出

### 测试

```javascript
// 单元测试示例
const { appointment } = require('pkuih-hospital');

// Mock 登录状态
core.state.STATE.token = 'test_token';

// 测试查询功能
const doctors = await appointment.getDoctorSchedule('005003', '2026-04-10', '2026-04-17');
```

## 📦 版本历史

### v2.2.3 (2026-04-11)
- 🔧 修复 payment.js 缺失 state 导入

### v2.2.2 (2026-04-11)
- 🐛 修复 auth.js 中 CONFIG 重复导入问题
- 🐛 修复 auth.js 中 login() 函数 token 变量未定义（应为 result.token）
- ✨ request.js 新增 useApiKey 参数，支持强制使用 API Key 认证
- ✨ request.js 自动识别公开接口使用 API Key
- ✨ request.js 添加详细的 HTTP 请求/响应日志
- 🐛 修复 appointment/book 接口认证失败问题
- ✅ 测试验证：登录、查询、预约功能全部正常

### v2.2.1 (2026-04-10)
- 🐛 修复 auth.js 缺失 CONFIG 导入

### v2.2.0 (2026-04-10)
- ✨ 配置文件持久化 token，支持跨会话使用

### v2.1.5 (2026-04-10)
- 🐛 security.js 支持跨进程状态加载

### v2.1.4 (2026-04-10)
- 🐛 request.js 优先使用登录 token

### v2.1.3 (2026-04-10)
- 🐛 request.js 自动加载 token

### v2.1.0 (2026-04-10)
- ✨ 新增 loginInteractive() 交互式登录功能
- ✨ 自动获取验证码、发送短信、等待用户输入
- ⏰ 支持超时自动退出（默认 4 分 30 秒）
- 🔄 验证码错误支持重试（最多 5 次）

### v2.0.0 (2026-04-10)
- 🎉 重构为分层模块化架构
- ✅ 新增状态持久化（30 分钟）
- ✅ 新增安全策略（敏感操作重验）
- ✅ 新增报告模块（预留）
- ✅ 新增缴费模块（预留）

### v1.0.14 (2026-04-10)
- 清理调试日志
- 优化代码结构

## 📞 技术支持

- **作者**: 高坤
- **仓库**: https://gitee.com/vegetable-bird-0209/pkuih_service.git
- **问题反馈**: 请在 Gitee 提交 Issue

## 📄 许可证

MIT License
