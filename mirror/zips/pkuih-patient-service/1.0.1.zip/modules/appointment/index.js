/**
 * 挂号模块
 * 提供医生排班查询、预约挂号功能
 */

const request = require('../../core/request');
const security = require('../../core/security');
const state = require('../../core/state');

/**
 * 获取科室树
 * 无需登录，公开接口
 * 递归展开所有层级的科室
 */
async function getDepartments(flat = true) {
  const result = await request('/api/v1/department/tree');
  
  if (!flat) {
    return result;  // 返回原始树形结构
  }
  
  // 扁平化：递归展开所有子科室
  const flatDepts = [];
  
  function flatten(depts, parentName = '') {
    for (const dept of depts) {
      const fullName = parentName ? parentName + ' > ' + dept.dept_name : dept.dept_name;
      
      flatDepts.push({
        dept_code: dept.dept_code,
        dept_name: dept.dept_name,
        dept_name_full: fullName,
        parent_code: dept.parent_code || null,
        level: parentName ? 2 : 1,
        hasChildren: !!dept.children
      });
      
      if (dept.children && dept.children.length > 0) {
        flatten(dept.children, fullName);
      }
    }
  }
  
  flatten(result);
  
  return flatDepts;
}

/**
 * 查询医生排班
 * 无需登录，公开接口
 */
async function getDoctorSchedule(deptCode, startDate, endDate) {
  const path = `/api/v1/schedule/doctors?dept_code=${deptCode}&start_date=${startDate}&end_date=${endDate}`;
  const result = await request(path);
  
  if (Array.isArray(result)) {
    const doctorMap = new Map();
    
    for (const item of result) {
      if (item.list && Array.isArray(item.list)) {
        for (const doctor of item.list) {
          const code = doctor.code || doctor.name;
          
          if (doctorMap.has(code)) {
            const existing = doctorMap.get(code);
            if (doctor.sch_list) {
              existing.sch_list.push(...doctor.sch_list);
            }
          } else {
            doctorMap.set(code, { ...doctor });
          }
        }
      }
    }
    
    for (const doctor of doctorMap.values()) {
      if (doctor.sch_list) {
        doctor.sch_list = doctor.sch_list.filter(slot => slot.enable === true);
        
        doctor.sch_list.sort((a, b) => {
          const dateCompare = a.sch_date.localeCompare(b.sch_date);
          if (dateCompare !== 0) return dateCompare;
          const periodOrder = { 'a': 1, 'p': 2, 'n': 3 };
          return (periodOrder[a.ampm] || 9) - (periodOrder[b.ampm] || 9);
        });
      }
    }
    
    return Array.from(doctorMap.values());
  }
  
  return result || [];
}

/**
 * 获取号位详情
 * 无需登录，公开接口
 */
async function getScheduleDetail(schId) {
  const result = await request('/api/v1/schedule/detail', {
    method: 'POST',
    body: { sch_ids: [schId] }
  });
  
  const slots = result.data || result || [];
  return slots.filter(slot => slot.enable === true);
}

/**
 * 预约挂号
 * 需要登录（token 在请求体中传递）
 */
async function bookAppointment(doctor, slot, sequence) {
  // 确保有有效的 token
  if (!state.STATE.token && !state.loadState()) {
    throw new Error('请先登录');
  }
  
  const schInfo = doctor.sch_list[0];
  
  let finalSequence = sequence || slot.sequence;
  
  if (!finalSequence) {
    const slots = await getScheduleDetail(schInfo.sch_id);
    if (!slots || slots.length === 0) {
      throw new Error('未找到可用号位');
    }
    finalSequence = slots[0].sequence;
  } else {
    // ✅ 验证指定号位是否仍可用
    const slots = await getScheduleDetail(schInfo.sch_id);
    const validSlot = slots.find(s => s.sequence === finalSequence && s.enable === true);
    
    if (!validSlot) {
      // 号位已不可用，尝试选择其他号位
      const alternativeSlot = slots.find(s => s.enable === true);
      
      if (alternativeSlot) {
        console.log(`⚠️ 号位 ${finalSequence} 已被占用，使用备选号位 ${alternativeSlot.sequence}`);
        finalSequence = alternativeSlot.sequence;
      } else {
        throw new Error('该号位已被占用，且无其他可用号位');
      }
    }
  }
  
  // 📋 展示预约详情，等待用户确认
  const patient = state.STATE.patient;
  const timeStr = schInfo.ampm === 'a' ? '上午' : schInfo.ampm === 'p' ? '下午' : '夜间';
  
  console.log('');
  console.log('╔═══════════════════════════════════════════════════════╗');
  console.log('║           📋 请确认预约信息                           ║');
  console.log('╠═══════════════════════════════════════════════════════╣');
  console.log(`║  👤 就诊人：${patient.name} (PID: ${patient.pid})`);
  console.log(`║  🏥 科室：${schInfo.dept_name || '中医科'}`);
  console.log(`║  👨‍⚕️ 医生：${doctor.name} (${doctor.duty || '未知职称'})`);
  console.log(`║  📅 日期：${schInfo.sch_date}`);
  console.log(`║  ⏰ 时间：${timeStr}`);
  console.log(`║  🔢 号序：第 ${finalSequence} 号`);
  console.log(`║  💰 费用：¥60（副主任医师）`);
  console.log('╠═══════════════════════════════════════════════════════╣');
  console.log('║  💡 提示：预约成功后请前往北京大学国际医院微信小程序中查看  ║');
  console.log('╚═══════════════════════════════════════════════════════╝');
  console.log('');
  
  const readline = require('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise((resolve, reject) => {
    rl.question('请输入 "确认" 继续预约，或输入任意内容取消：', (answer) => {
      rl.close();
      
      if (answer.trim() !== '确认') {
        console.log('');
        console.log('❌ 预约已取消');
        console.log('');
        reject(new Error('用户取消预约'));
        return;
      }
      
      console.log('');
      console.log('✅ 确认预约，正在提交...');
      console.log('');
      
      const body = {
    token: state.STATE.token,
    pid: state.STATE.patient.pid,
    dept_code: schInfo.dept_code,
    dept_code_oa: '',
    sch_date: schInfo.sch_date,
    ampm: schInfo.ampm,
    sch_id: schInfo.sch_id,
    serial_type: schInfo.register_code,
    doctor_code: doctor.code,
    sequence: finalSequence,
    chl_type: '16',
    online_pay: '2',
    patient_type: '0',
    pay_model_code: 'weChatAccount',
    channel: '3',
    other_patient_id: '',
    third_user_id: '',
    is_change: false
  };
  
      // 预约接口需要使用 API Key 认证（token 在请求体中传递）
      request('/api/v1/appointment/book', {
        method: 'POST',
        useApiKey: true,
        body
      })
        .then(result => {
          console.log('');
          console.log('╔═══════════════════════════════════════════════════════╗');
          console.log('║              ✅ 预约成功！                            ║');
          console.log('╠═══════════════════════════════════════════════════════╣');
          console.log(`║  🎫 预约 ID: ${result.apt_id}`);
          console.log(`║  📅 就诊日期：${result.visit_date}`);
          console.log(`║  ⏰ 就诊时间：${result.visit_time}`);
          console.log(`║  🏥 就诊地点：${result.visit_place}`);
          console.log(`║  🔢 序号：${result.sequence}`);
          console.log(`║  📝 订单号：${result.app_order}`);
          console.log('╠═══════════════════════════════════════════════════════╣');
          console.log('║  💡 提示：请提前 15 分钟到达医院，携带身份证和医保卡    ║');
          console.log('╚═══════════════════════════════════════════════════════╝');
          console.log('');
          resolve(result);
        })
        .catch(err => {
          console.log('');
          console.log('❌ 预约失败:', err.message);
          console.log('');
          reject(err);
        });
    });
  });
}

/**
 * 查询预约记录
 */
async function getAppointments(options = {}) {
  await security.ensureLoggedIn(security.SECURITY_LEVELS.MEDIUM);
  
  const pageCur = options.page || 1;
  const pageSize = options.limit || 10;
  const startDate = options.start_date || '2025-03-23';
  const endDate = options.end_date || '2026-06-23';
  
  const path = `/api/v1/appointment/list?token=${state.STATE.token}&pageCur=${pageCur}&pageSize=${pageSize}&start_date=${startDate}&end_date=${endDate}`;
  return request(path);
}

module.exports = {
  getDepartments,
  getDoctorSchedule,
  getScheduleDetail,
  bookAppointment,
  getAppointments
};
