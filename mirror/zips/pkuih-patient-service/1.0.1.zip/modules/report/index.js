/**
 * 报告模块（预留）
 * 未来扩展：检验报告、检查报告
 */

const request = require('../../core/request');
const security = require('../../core/security');

/**
 * 获取检验报告列表
 */
async function getLabReports(patientId, startDate, endDate) {
  await security.ensureLoggedIn(security.SECURITY_LEVELS.LOW);
  
  const path = `/api/v1/report/lab?patient_id=${patientId}&start_date=${startDate}&end_date=${endDate}`;
  return request(path);
}

/**
 * 获取检查报告列表
 */
async function getExamReports(patientId) {
  await security.ensureLoggedIn(security.SECURITY_LEVELS.LOW);
  
  const path = `/api/v1/report/exam?patient_id=${patientId}`;
  return request(path);
}

module.exports = {
  getLabReports,
  getExamReports
};
