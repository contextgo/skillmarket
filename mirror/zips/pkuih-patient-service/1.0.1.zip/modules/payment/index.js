/**
 * 缴费模块（预留）
 * 未来扩展：门诊缴费、处方缴费
 */

const request = require('../../core/request');
const security = require('../../core/security');
const state = require('../../core/state');

/**
 * 获取待缴费订单
 */
async function getUnpaidOrders(patientId) {
  await security.ensureLoggedIn(security.SECURITY_LEVELS.LOW);
  
  const path = `/api/v1/payment/unpaid?patient_id=${patientId}`;
  return request(path);
}

/**
 * 在线缴费（高安全级别）
 */
async function payOrder(orderId, payMethod) {
  const valid = await security.verifySecurity(security.SECURITY_LEVELS.HIGH);
  
  if (!valid) {
    throw new Error('支付操作需要重新验证身份');
  }
  
  const body = {
    token: state.STATE.token,
    order_id: orderId,
    pay_method: payMethod
  };
  
  return request('/api/v1/payment/pay', {
    method: 'POST',
    body
  });
}

module.exports = {
  getUnpaidOrders,
  payOrder
};
