# 故障排查指南

本文档帮助解决使用 pkuih-hospital 时遇到的常见问题。

---

## 🔍 问题诊断流程

### 第一步：检查环境变量

```bash
# 检查是否配置
echo $PKUIH_API_KEY

# 如果为空，说明未配置
if [ -z "$PKUIH_API_KEY" ]; then
  echo "❌ 环境变量未配置"
  echo "请执行：echo 'export PKUIH_API_KEY=\"你的 API Key\"' >> ~/.profile"
  echo "然后执行：source ~/.profile"
fi
```

### 第二步：检查模块加载

```bash
cd pkuih-hospital
node -e "require('./index.js'); console.log('✅ 模块加载成功')"
```

如果报错，检查：
- Node.js 版本是否 >= 18.0
- 依赖是否完整
- 文件权限是否正确

### 第三步：检查登录状态

```bash
node -e "
const pkuih = require('./index.js');
const state = require('./core/state');
console.log('登录状态:', state.isLoggedIn() ? '已登录' : '未登录');
"
```

---

## ❌ 常见错误及解决方案

### 1. "无效的 API Key"

**错误信息**:
```
Error: 无效的 API Key
```

**可能原因**:
1. 环境变量未配置
2. 环境变量配置在 `~/.bashrc` 中（非交互式 shell 不加载）
3. API Key 本身无效或已过期

**解决方案**:

```bash
# 1. 检查环境变量
echo $PKUIH_API_KEY

# 2. 如果为空，重新配置（使用 ~/.profile）
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile

# 3. 验证
bash -c 'echo "测试：${PKUIH_API_KEY:0:20}..."'

# 4. 如果还是无效，联系医院信息科更换 API Key
```

---

### 2. "号位状态不是未用！"

**错误信息**:
```
Error: 号位状态不是未用！
```

**原因分析**:

这个错误表示尝试预约的号位已被占用，可能有以下情况：

1. **号位已被其他用户预约**
   - 医院挂号系统号源紧张，特别是热门医生
   - 从查询到预约的时间差内，号位被其他人抢走

2. **号位已被当前用户预约（重复提交）**
   - 同一个号位重复提交预约请求
   - 第一次预约成功，但客户端未收到响应，再次提交

3. **号位状态已变更**
   - 医生停诊
   - 号源被医院收回
   - 号位被锁定（支付中、保留中等）

4. **缓存问题**
   - 查询到的排班信息已过时
   - 号位详情中的 `enable` 状态与实际不符

**解决方案**:

```javascript
// 方案 1: 重新查询排班，获取最新状态
const doctors = await pkuih.appointment.getDoctorSchedule('005003', '2026-04-12', '2026-04-18');
const yao = doctors.find(d => d.name.includes('姚小芹'));

// 方案 2: 选择其他可用号源
const availableSlot = yao.sch_list.find(s => s.remain > 0);

// 方案 3: 获取最新号位详情，选择未使用的号位
const slots = await pkuih.appointment.getScheduleDetail(availableSlot.sch_id);
const availableSequence = slots.find(s => s.enable === true);

// 方案 4: 添加重试机制
async function bookWithRetry(doctor, slot, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await pkuih.appointment.bookAppointment(doctor, slot);
    } catch (err) {
      if (err.message.includes('号位状态不是未用')) {
        console.log(`号位已被占用，重试 ${i + 1}/${maxRetries}...`);
        // 重新获取号位详情
        const slots = await pkuih.appointment.getScheduleDetail(slot.sch_id);
        const newSequence = slots.find(s => s.enable === true);
        if (!newSequence) throw err;  // 没有可用号位了
        slot.sequence = newSequence.sequence;
      } else {
        throw err;  // 其他错误，直接抛出
      }
    }
  }
}
```

**最佳实践**:

1. **查询后立即预约** - 减少时间差
2. **准备备选号源** - 第一个号源被占时立即切换
3. **添加重试逻辑** - 自动处理号位占用
4. **避免重复提交** - 记录已预约的号位

---

### 3. "登录已过期，请重新登录"

**错误信息**:
```
Error: 登录已过期，请重新登录
```

**原因**:
- Token 已过期（30 分钟有效期）
- 状态文件被删除
- 用户主动登出

**解决方案**:

```javascript
// 重新登录
const captcha = await pkuih.getCaptcha();
await pkuih.sendSms('手机号', captcha.captcha_key, captcha.captcha_code);
const user = await pkuih.login('手机号', '短信验证码');
```

**预防措施**:

```javascript
// 在执行敏感操作前检查登录状态
if (!pkuih.isLoggedIn()) {
  console.log('未登录，请先登录');
  // 执行登录流程
}
```

---

### 4. "未找到可用号位"

**错误信息**:
```
Error: 未找到可用号位
```

**原因**:
- 该排班所有号位都已约满
- 号位都被禁用（`enable: false`）
- 医生停诊

**解决方案**:

1. 查询其他日期的排班
2. 查询其他医生的排班
3. 等待医院放出新的号源

---

### 5. "响应格式错误"

**错误信息**:
```
Error: 响应格式错误：...
```

**原因**:
- API 返回的不是 JSON 格式
- 网络问题导致响应不完整
- 服务器返回 HTML 错误页面

**解决方案**:

1. 检查网络连接
2. 检查 API Key 是否有效
3. 查看完整错误信息
4. 联系医院信息科

---

## 🔧 调试技巧

### 启用详细日志

```javascript
// 所有 HTTP 请求都会输出详细日志
// 包括：URL、认证类型、请求体、响应等
const pkuih = require('./index.js');
```

### 检查状态文件

```bash
# 查看状态文件内容
cat /tmp/pkuih_state.json

# 检查是否过期
node -e "
const fs = require('fs');
const state = JSON.parse(fs.readFileSync('/tmp/pkuih_state.json', 'utf-8'));
console.log('过期时间:', new Date(state.expiresAt).toLocaleString());
console.log('是否过期:', Date.now() > state.expiresAt);
"
```

### 清理状态

```bash
# 手动清理状态文件
rm /tmp/pkuih_state.json

# 或在代码中
const state = require('./core/state');
state.clearState();
```

---

## 📞 获取帮助

如果以上方法都无法解决问题：

1. **查看日志** - 记录完整的错误信息
2. **检查配置** - 确认环境变量、API Key 正确
3. **提交 Issue** - 在 Gitee 仓库提交详细问题描述
4. **联系医院** - API 相关问题联系医院信息科

---

**最后更新**: 2026-04-11  
**版本**: v2.2.6
