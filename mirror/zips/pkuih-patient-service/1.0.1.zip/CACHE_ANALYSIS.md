# 缓存问题分析报告

## 📊 问题背景

在预约测试中遇到"号位状态不是未用！"错误，怀疑与缓存问题相关。

---

## 🔍 缓存类型分析

### 1️⃣ **内存缓存（Memory Cache）**

**位置**: `core/state.js` - `STATE` 对象

```javascript
const STATE = {
  token: null,
  user: null,
  // ...
};
```

**特点**:
- ✅ 进程内缓存，速度最快
- ❌ 进程重启后丢失
- ❌ 多个进程间不同步

**当前使用场景**:
- Token 存储
- 用户信息
- 短信 ID（currentSmsId）

**潜在问题**:
```javascript
// 问题：跨进程场景下，内存状态与文件状态不一致
// 进程 A: 登录成功，保存状态到文件
// 进程 B: 启动，内存中无状态，从文件加载
// 进程 A: 内存状态过期，但未从文件重新加载
```

**已实现的解决方案**:
```javascript
// state.js - loadState()
function loadState() {
  const data = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
  
  // ✅ 验证过期时间
  if (Date.now() > data.expiresAt) {
    clearState();
    return false;
  }
  
  // ✅ 恢复状态
  STATE.token = data.token;
  // ...
}

// state.js - isLoggedIn()
function isLoggedIn() {
  if (STATE.token && STATE.expiresAt) {
    if (Date.now() < STATE.expiresAt) {
      return true;
    }
    clearState();
  }
  return loadState();  // ✅ 内存失效时从文件加载
}
```

**评估**: ✅ **已正确处理**

---

### 2️⃣ **文件缓存（File Cache）**

**位置**: `/tmp/pkuih_state.json`

**内容**:
```json
{
  "token": "eyJ0eXAi...",
  "user": {...},
  "expiresAt": 1775870826319,
  "savedAt": 1775869026319
}
```

**特点**:
- ✅ 跨进程共享
- ✅ 支持进程重启
- ❌ 磁盘 I/O 较慢
- ❌ 并发写入可能冲突

**当前使用场景**:
- Token 持久化
- 状态恢复

**潜在问题**:
```javascript
// 问题 1: 并发写入冲突
// 进程 A 和进程 B 同时保存状态
// 后写入的覆盖先写入的

// 问题 2: 文件权限
// 如果权限设置不当，其他用户可能读取

// 问题 3: 文件残留
// 进程异常退出，文件未清理
```

**已实现的解决方案**:
```javascript
// ✅ 文件权限设置
fs.writeFileSync(STATE_FILE, JSON.stringify(data, null, 2), 'utf-8', { mode: 0o600 });

// ✅ 过期验证
if (Date.now() > data.expiresAt) {
  clearState();
  return false;
}

// ✅ 异常处理
try {
  // 读取/写入
} catch (error) {
  clearState();
  return false;
}
```

**评估**: ✅ **已正确处理**

---

### 3️⃣ **API 响应缓存（HTTP Cache）**

**位置**: 无显式缓存

**当前实现**:
```javascript
// request.js - 每次都是实时请求
async function request(path, options = {}) {
  const res = await fetch(url, config);
  // 无缓存逻辑
}
```

**潜在问题**:
```javascript
// 问题：API 返回的数据可能已过时
// 1. 查询排班：10:00:00 - 剩余 25/31
// 2. 其他用户预约：10:00:05
// 3. 用户预约：10:00:10 - 失败（号位已被占用）
```

**评估**: ⚠️ **需要改进**

---

## 🎯 号位状态缓存问题分析

### 问题场景重现

```javascript
// 步骤 1: 查询排班（10:00:00）
const doctors = await pkuih.appointment.getDoctorSchedule('005003', '2026-04-17', '2026-04-17');
const yao = doctors.find(d => d.name.includes('姚小芹'));
const slot = yao.sch_list.find(s => s.sch_date === '2026-04-17' && s.ampm === 'a');
// slot.remain = 25 (剩余 25/31)

// 步骤 2: 获取号位详情（10:00:01）
const slots = await pkuih.appointment.getScheduleDetail(slot.sch_id);
// slots[0].enable = true, sequence = 8

// 步骤 3: 其他用户预约（10:00:02）
// 医院系统：sequence 8 已被占用

// 步骤 4: 当前用户预约（10:00:03）
const result = await pkuih.appointment.bookAppointment(yao, slot, 8);
// ❌ 错误："号位状态不是未用！"
```

### 根本原因

**不是代码缓存问题，而是数据时效性问题！**

1. **查询与预约的时间差** - 从查询到预约有几秒延迟
2. **并发访问** - 多个用户同时查询和预约
3. **号源紧张** - 热门医生号源秒光

---

## 💡 解决方案

### 方案 1: 添加响应缓存控制（不推荐）

```javascript
// request.js
const responseCache = new Map();
const CACHE_TTL = 5000;  // 5 秒

async function request(path, options = {}) {
  const cacheKey = path + JSON.stringify(options.body);
  
  // 检查缓存
  const cached = responseCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  
  // 请求
  const res = await fetch(url, config);
  const data = await res.json();
  
  // 缓存（仅 GET 请求）
  if (options.method === 'GET') {
    responseCache.set(cacheKey, { data, timestamp: Date.now() });
  }
  
  return data;
}
```

**问题**: ❌ **会加剧号位占用问题**
- 缓存导致数据更不及时
- 预约时使用过时的号位信息

---

### 方案 2: 实时刷新号位状态（推荐）

```javascript
// modules/appointment/index.js
async function bookAppointment(doctor, slot, sequence) {
  // 确保有有效的 token
  if (!state.STATE.token && !state.loadState()) {
    throw new Error('请先登录');
  }
  
  const schInfo = doctor.sch_list[0];
  let finalSequence = sequence || slot.sequence;
  
  // ✅ 预约前重新获取号位详情（确保最新状态）
  if (!finalSequence) {
    const slots = await getScheduleDetail(schInfo.sch_id);
    if (!slots || slots.length === 0) {
      throw new Error('未找到可用号位');
    }
    finalSequence = slots[0].sequence;
  } else {
    // ✅ 验证指定号位是否仍可用
    const slots = await getScheduleDetail(schInfo.sch_id);
    const validSlot = slots.find(s => s.sequence === finalSequence && s.enable === true);
    if (!validSlot) {
      // 号位已不可用，尝试选择其他号位
      const alternativeSlot = slots.find(s => s.enable === true);
      if (alternativeSlot) {
        console.log(`号位 ${finalSequence} 已被占用，使用备选号位 ${alternativeSlot.sequence}`);
        finalSequence = alternativeSlot.sequence;
      } else {
        throw new Error('该号位已被占用，且无其他可用号位');
      }
    }
  }
  
  // 执行预约
  const body = { /* ... */ };
  const result = await request('/api/v1/appointment/book', {
    method: 'POST',
    useApiKey: true,
    body
  });
  
  return result;
}
```

**优点**:
- ✅ 预约前验证号位状态
- ✅ 自动选择备选号位
- ✅ 减少"号位状态不是未用"错误

**缺点**:
- ⚠️ 增加一次 API 调用
- ⚠️ 极端情况下仍可能失败（验证与预约之间的时间差）

---

### 方案 3: 重试机制 + 备选号源（推荐）

```javascript
// 用户代码示例
async function bookWithRetry(doctor, slot, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await pkuih.appointment.bookAppointment(doctor, slot);
    } catch (err) {
      if (err.message.includes('号位状态不是未用')) {
        console.log(`号位已被占用，重试 ${i + 1}/${maxRetries}...`);
        
        // 重新获取号位详情
        const slots = await pkuih.appointment.getScheduleDetail(slot.sch_id);
        const newSequence = slots.find(s => s.enable === true);
        
        if (!newSequence) {
          throw new Error('所有号位已被占用');
        }
        
        // 使用新号位重试
        slot.sequence = newSequence.sequence;
      } else {
        throw err;  // 其他错误直接抛出
      }
    }
  }
}

// 备选号源方案
async function bookWithAlternatives(doctor, availableSlots) {
  for (const slot of availableSlots) {
    try {
      const result = await pkuih.appointment.bookAppointment(doctor, slot);
      console.log('预约成功:', result.apt_id);
      return result;
    } catch (err) {
      console.log(`号位 ${slot.sch_date} ${slot.ampm} 被占用，尝试下一个...`);
    }
  }
  throw new Error('所有备选号源均已被占用');
}
```

**优点**:
- ✅ 自动处理号位占用
- ✅ 提供备选方案
- ✅ 用户友好

---

### 方案 4: 缓存失效策略（不推荐）

```javascript
// 在查询排班时添加时间戳
const doctors = await pkuih.appointment.getDoctorSchedule(...);
doctors.queryTimestamp = Date.now();

// 预约前检查是否过期
const CACHE_MAX_AGE = 10000;  // 10 秒
if (Date.now() - doctors.queryTimestamp > CACHE_MAX_AGE) {
  console.log('排班信息已过期，重新查询...');
  // 重新查询
}
```

**问题**: ❌ **增加复杂度，收益有限**

---

## 📋 结论与建议

### 当前缓存状态评估

| 缓存类型 | 状态 | 评估 |
|---------|------|------|
| 内存缓存（Token） | ✅ 已实现 | 正确 |
| 文件缓存（状态持久化） | ✅ 已实现 | 正确 |
| API 响应缓存 | ❌ 未实现 | **故意不实现** |
| 号位状态验证 | ⚠️ 部分实现 | 需要改进 |

### 为什么 API 响应不应该缓存？

**医疗挂号系统的特殊性：**
1. **高并发** - 热门医生号源秒光
2. **实时性** - 号位状态随时变化
3. **低延迟** - 从查询到预约应在秒级完成

**缓存会带来的问题：**
- ❌ 使用过时的号位信息
- ❌ 增加"号位状态不是未用"错误
- ❌ 用户体验下降

### 推荐方案

**短期（立即实施）：**
1. ✅ 在 `bookAppointment()` 中添加号位状态验证
2. ✅ 提供备选号位自动切换
3. ✅ 文档中说明号位占用问题

**中期（功能增强）：**
1. 添加重试机制示例代码
2. 提供备选号源选择策略
3. 优化错误提示（告知用户具体原因）

**长期（架构优化）：**
1. 考虑 WebSocket 实时推送号位变化
2. 与医院系统协商号位锁定机制
3. 实现预约队列系统

---

## 🔧 立即实施的修复

修改 `modules/appointment/index.js` 的 `bookAppointment()` 函数：

```javascript
async function bookAppointment(doctor, slot, sequence) {
  // 确保有有效的 token
  if (!state.STATE.token && !state.loadState()) {
    throw new Error('请先登录');
  }
  
  const schInfo = doctor.sch_list[0];
  let finalSequence = sequence || slot.sequence;
  
  // 🔍 预约前重新获取号位详情（确保最新状态）
  if (!finalSequence) {
    const slots = await getScheduleDetail(schInfo.sch_id);
    if (!slots || slots.length === 0) {
      throw new Error('未找到可用号位');
    }
    finalSequence = slots[0].sequence;
  } else {
    // ✅ 验证指定号位是否仍可用
    const slots = await getScheduleDetail(schInfo.sch_id);
    const validSlot = slots.find(s => s.sequence === finalSequence && s.enable === true);
    
    if (!validSlot) {
      // 号位已不可用，尝试选择其他号位
      const alternativeSlot = slots.find(s => s.enable === true);
      
      if (alternativeSlot) {
        console.log(`⚠️ 号位 ${finalSequence} 已被占用，使用备选号位 ${alternativeSlot.sequence}`);
        finalSequence = alternativeSlot.sequence;
      } else {
        throw new Error('该号位已被占用，且无其他可用号位');
      }
    }
  }
  
  // 执行预约
  const body = { /* ... */ };
  const result = await request('/api/v1/appointment/book', {
    method: 'POST',
    useApiKey: true,
    body
  });
  
  return result;
}
```

---

**最后更新**: 2026-04-11  
**版本**: v2.2.7
