/**
 * 安全策略模块
 * 定义不同操作的安全级别和验证方式
 */

const state = require('./state');
const request = require('./request');
const CONFIG = require('../config');

/**
 * 安全级别
 */
const SECURITY_LEVELS = {
  LOW: 'low',        // 仅检查本地状态
  MEDIUM: 'medium',  // 本地状态 + API 验证
  HIGH: 'high'       // 强制重新登录
};

/**
 * 验证安全级别
 * @param {string} requiredLevel - 要求的安全级别
 * @returns {boolean} 是否验证通过
 */
async function verifySecurity(requiredLevel) {
  // 1. 优先检查配置文件中的 token（最可靠，支持跨进程）
  const configToken = CONFIG.getTokenFromFile();
  if (configToken) {
    // 配置文件中有有效 token，尝试验证
    if (requiredLevel === SECURITY_LEVELS.LOW) {
      return true;
    }
    
    // MEDIUM/HIGH 级别需要验证 API
    try {
      await request('/api/v1/user/info');
      return true;
    } catch (error) {
      // token 无效，清除配置文件
      CONFIG.clearTokenFromFile();
      return false;
    }
  }
  
  // 2. 配置文件没有 token，尝试从临时文件加载
  state.loadState();
  
  switch (requiredLevel) {
    case SECURITY_LEVELS.LOW:
      return state.isLoggedIn();
    
    case SECURITY_LEVELS.MEDIUM:
      if (!state.isLoggedIn()) return false;
      try {
        await request('/api/v1/user/info');
        return true;
      } catch (error) {
        state.clearState();
        return false;
      }
    
    case SECURITY_LEVELS.HIGH:
      state.clearState();
      return false;
  }
  
  return false;
}

/**
 * 确保已登录（根据安全级别）
 * @param {string} level - 安全级别
 */
async function ensureLoggedIn(level = SECURITY_LEVELS.LOW) {
  const valid = await verifySecurity(level);
  
  if (!valid) {
    if (level === SECURITY_LEVELS.HIGH) {
      throw new Error('敏感操作需要重新验证身份');
    } else {
      throw new Error('登录已过期，请重新登录');
    }
  }
}

module.exports = {
  SECURITY_LEVELS,
  verifySecurity,
  ensureLoggedIn
};
