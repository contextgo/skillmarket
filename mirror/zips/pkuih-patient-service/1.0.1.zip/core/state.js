/**
 * 状态管理模块
 * 负责登录状态的持久化和恢复
 * 安全策略：30 分钟自动过期
 */

const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join('/tmp', 'pkuih_state.json');
const TOKEN_TTL = 30 * 60 * 1000;  // 30 分钟

const STATE = {
  token: null,
  user: null,
  phone: null,
  patient: null,
  expiresAt: null,
  currentSmsId: null,
  currentPhone: null,
  lastCaptchaTime: 0
};

/**
 * 保存状态到文件
 * 🔒 安全提示：状态文件包含敏感信息，已添加到 .gitignore
 */
function saveState() {
  try {
    const data = {
      token: STATE.token,
      user: STATE.user,
      phone: STATE.phone,
      patient: STATE.patient,
      currentSmsId: STATE.currentSmsId,
      currentPhone: STATE.currentPhone,
      lastCaptchaTime: STATE.lastCaptchaTime,
      expiresAt: Date.now() + TOKEN_TTL,
      savedAt: Date.now()
    };
    
    // 🔒 设置文件权限为仅所有者可读写 (Unix 系统)
    fs.writeFileSync(STATE_FILE, JSON.stringify(data, null, 2), 'utf-8', { mode: 0o600 });
  } catch (error) {
    // 忽略错误
  }
}

/**
 * 从文件加载状态
 * @returns {boolean} 是否加载成功
 */
function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) {
      return false;
    }
    
    const data = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    
    // 验证是否过期
    if (Date.now() > data.expiresAt) {
      clearState();
      return false;
    }
    
    // 恢复状态
    STATE.token = data.token;
    STATE.user = data.user;
    STATE.phone = data.phone;
    STATE.patient = data.patient;
    STATE.currentSmsId = data.currentSmsId;
    STATE.currentPhone = data.currentPhone;
    STATE.lastCaptchaTime = data.lastCaptchaTime;
    STATE.expiresAt = data.expiresAt;
    
    return true;
  } catch (error) {
    clearState();
    return false;
  }
}

/**
 * 清理状态（登出或过期时）
 */
function clearState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      fs.unlinkSync(STATE_FILE);
    }
  } catch (error) {
    // 忽略错误
  }
  
  STATE.token = null;
  STATE.user = null;
  STATE.phone = null;
  STATE.patient = null;
  STATE.expiresAt = null;
  STATE.currentSmsId = null;
  STATE.currentPhone = null;
  STATE.lastCaptchaTime = 0;
}

/**
 * 检查是否已登录
 */
function isLoggedIn() {
  if (STATE.token && STATE.expiresAt) {
    if (Date.now() < STATE.expiresAt) {
      return true;
    }
    clearState();
  }
  return loadState();
}

/**
 * 获取当前 token（确保有效）
 */
function getToken() {
  if (!isLoggedIn()) {
    throw new Error('请先登录');
  }
  return STATE.token;
}

module.exports = {
  STATE,
  saveState,
  loadState,
  clearState,
  isLoggedIn,
  getToken
};
