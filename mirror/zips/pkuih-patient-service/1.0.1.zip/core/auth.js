/**
 * 认证管理模块
 * 负责登录、验证码、登出等认证相关功能
 */

const request = require('./request');
const state = require('./state');
const CONFIG = require('../config');

/**
 * 获取图形验证码
 */
async function getCaptcha() {
  // 登录接口使用 API Key
  const captcha = await request('/api/v1/login/captcha', {
    method: 'POST',
    useApiKey: true
  });
  return captcha;
}

/**
 * 发送短信验证码
 * @param {string} phone - 手机号
 * @param {string} captchaKey - 验证码 key
 * @param {string} captchaCode - 验证码 code
 */
async function sendSms(phone, captchaKey, captchaCode) {
  console.log('[短信] 开始发送短信...');
  console.log('[短信] 手机号:', phone);
  console.log('[短信] captcha_key:', captchaKey);
  console.log('[短信] captcha_code:', captchaCode);
  
  // 登录接口使用 API Key
  const sms = await request('/api/v1/login/send-sms', {
    method: 'POST',
    useApiKey: true,
    body: { phone, captcha_key: captchaKey, captcha_code: captchaCode }
  });
  
  console.log('[短信] 响应结果:', JSON.stringify(sms, null, 2));
  
  // ✅ 只更新短信相关字段，保留已有的 token 和 user
  const oldToken = state.STATE.token;
  const oldUser = state.STATE.user;
  const oldPhone = state.STATE.phone;
  const oldPatient = state.STATE.patient;
  
  state.STATE.currentSmsId = sms.sms_id;
  state.STATE.currentPhone = phone;
  
  console.log('[短信] 内存状态:');
  console.log('[短信]   currentSmsId:', sms.sms_id);
  console.log('[短信]   currentPhone:', phone);
  console.log('[短信]   token:', oldToken ? '***' : '无');  // 🔒 不显示完整 token
  
  // ✅ 立即持久化，支持跨进程场景
  console.log('[短信] 保存到文件...');
  state.saveState();
  
  // ✅ 恢复 token 和 user（避免被覆盖）
  state.STATE.token = oldToken;
  state.STATE.user = oldUser;
  state.STATE.phone = oldPhone;
  state.STATE.patient = oldPatient;
  
  // 验证文件是否保存成功
  const fs = require('fs');
  const path = require('path');
  const stateFile = path.join('/tmp', 'pkuih_state.json');
  if (fs.existsSync(stateFile)) {
    const savedState = JSON.parse(fs.readFileSync(stateFile, 'utf-8'));
    console.log('[短信] ✅ 状态文件已保存');
    console.log('[短信] 文件中的 currentSmsId:', savedState.currentSmsId);
    console.log('[短信] 文件中的 currentPhone:', savedState.currentPhone);
    console.log('[短信] 文件中的 token:', savedState.token ? '***' : '无');  // 🔒 不显示完整 token
  } else {
    console.log('[短信] ❌ 状态文件未保存');
  }
  
  console.log('[短信] 验证码已发送，有效期 5 分钟');
  return sms;
}

/**
 * 登录
 * @param {string} phone - 手机号
 * @param {string} smsCode - 短信验证码
 * @param {string} smsId - 短信 ID（可选）
 */
async function login(phone, smsCode, smsId) {
  console.log('[登录] 开始登录流程...');
  console.log('[登录] 手机号:', phone);
  console.log('[登录] 验证码:', smsCode);
  console.log('[登录] 提供的 smsId:', smsId || '无');
  console.log('[登录] 内存中的 currentSmsId:', state.STATE.currentSmsId || '无');
  
  // ✅ 尝试从文件恢复状态（跨进程场景）
  if (!state.STATE.currentSmsId) {
    console.log('[登录] 内存中无 smsId，尝试从文件加载...');
    const loaded = state.loadState();
    console.log('[登录] 文件加载结果:', loaded);
    console.log('[登录] 加载后的 currentSmsId:', state.STATE.currentSmsId || '无');
  }
  
  const effectiveSmsId = smsId || state.STATE.currentSmsId;
  
  if (!effectiveSmsId) {
    console.log('[登录] ❌ 未找到有效的短信 ID');
    throw new Error('未找到有效的短信 ID，请先调用 sendSms()');
  }
  
  console.log('[登录] ✅ 使用 smsId:', effectiveSmsId);
  console.log('[登录] 请求体:', { phone, sms_code: smsCode, sms_id: effectiveSmsId });
  
  // 登录接口使用 API Key
  const result = await request('/api/v1/login/phone', {
    method: 'POST',
    useApiKey: true,
    body: { phone, sms_code: smsCode, sms_id: effectiveSmsId }
  });
  
  console.log('[登录] 响应结果:', JSON.stringify(result, null, 2));
  
  state.STATE.token = result.token;
  state.STATE.user = result.user;
  state.STATE.phone = phone;
  state.STATE.patient = { pid: result.user.pid, name: result.user.name };
  state.STATE.expiresAt = Date.now() + 30 * 60 * 1000;
  
  console.log('[登录] 保存状态...');
  console.log('[登录] token:', result.token ? '*** (' + result.token.length + ' 字符)' : '无');  // 🔒 不显示完整 token
  console.log('[登录] user:', result.user ? result.user.name : '无');
  console.log('[登录] expiresAt:', state.STATE.expiresAt);
  
  state.saveState();
  
  // 验证文件是否保存成功
  const fs = require('fs');
  const path = require('path');
  const stateFile = path.join('/tmp', 'pkuih_state.json');
  if (fs.existsSync(stateFile)) {
    const savedState = JSON.parse(fs.readFileSync(stateFile, 'utf-8'));
    console.log('[登录] ✅ 状态文件已保存');
    console.log('[登录] 文件中的 token:', savedState.token ? '***' : '无');  // 🔒 不显示完整 token
    console.log('[登录] 文件中的 user:', savedState.user ? savedState.user.name : '无');
  } else {
    console.log('[登录] ❌ 状态文件未保存');
  }
  
  // ✅ 保存 token 到配置文件（支持跨进程场景）
  console.log('[登录] 保存到配置文件...');
  CONFIG.saveTokenToFile(result.token, result.user);
  console.log('[登录] ✅ 配置文件已更新');
  
  console.log('[登录] 登录成功');
  return result.user;
}

/**
 * 登出
 */
function logout() {
  state.clearState();
  console.log('[登出] 已安全登出');
}

/**
 * 获取当前用户信息
 */
function getCurrentUser() {
  if (!state.isLoggedIn()) {
    throw new Error('请先登录');
  }
  return state.STATE.user;
}

/**
 * 获取就诊人信息
 */
function getPatient() {
  if (!state.isLoggedIn()) {
    throw new Error('请先登录');
  }
  return state.STATE.patient;
}

/**
 * 交互式登录（带 readline 等待）
 * 自动获取验证码、发送短信、等待用户输入、完成登录
 * 进程会保持运行直到登录完成或超时
 * 验证码错误时允许重新输入（最多 5 次）
 * @param {string} phone - 手机号
 * @param {number} timeout - 超时时间（毫秒），默认 4 分 30 秒
 * @returns {Promise<object>} 用户信息
 */
async function loginInteractive(phone, timeout = 4 * 60 * 1000 + 30 * 1000) {
  const readline = require('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  let timeoutTimer = null;
  let smsId = null;
  let attempts = 0;
  const maxAttempts = 5;  // 最多尝试 5 次
  
  return new Promise((resolve, reject) => {
    // 设置超时
    timeoutTimer = setTimeout(() => {
      console.log('');
      console.log('⏰ 超时，进程自动退出');
      rl.close();
      reject(new Error('登录超时'));
    }, timeout);
    
    console.log('');
    console.log('📱 正在获取验证码...');
    
    getCaptcha()
      .then(captcha => {
        console.log('🔑 captcha_code:', captcha.captcha_code);
        console.log('');
        console.log('📱 正在发送短信...');
        return sendSms(phone, captcha.captcha_key, captcha.captcha_code);
      })
      .then(sms => {
        smsId = sms.sms_id;
        console.log('');
        console.log('✅ 短信已发送，有效期 5 分钟');
        console.log('');
        console.log('⏰ 请在下方输入短信验证码（最多尝试 ' + maxAttempts + ' 次）：');
        console.log('');
        
        // 递归等待输入，支持重试
        function waitForInput() {
          attempts++;
          console.log('📝 第 ' + attempts + ' 次尝试：');
          
          rl.question('', async (smsCode) => {
            try {
              console.log('');
              console.log('📝 正在登录...');
              
              // 使用保存的 smsId，不重新发送短信
              const user = await login(phone, smsCode.trim(), smsId);
              
              console.log('');
              console.log('✅ 登录成功：' + user.name + ' (PID: ' + user.pid + ')');
              console.log('');
              
              clearTimeout(timeoutTimer);
              rl.close();
              resolve(user);
            } catch (error) {
              console.log('');
              console.log('❌ 登录失败：' + error.message);
              console.log('');
              
              if (attempts >= maxAttempts) {
                console.log('⚠️ 已达到最大尝试次数 (' + maxAttempts + ' 次)，需要重新获取验证码');
                console.log('');
                clearTimeout(timeoutTimer);
                rl.close();
                reject(error);
              } else {
                const remaining = maxAttempts - attempts;
                console.log('⚠️ 还可尝试 ' + remaining + ' 次');
                console.log('');
                waitForInput();  // 递归等待下一次输入
              }
            }
          });
        }
        
        waitForInput();
      })
      .catch(error => {
        clearTimeout(timeoutTimer);
        rl.close();
        reject(error);
      });
  });
}

module.exports = {
  getCaptcha,
  sendSms,
  login,
  loginInteractive,
  logout,
  getCurrentUser,
  getPatient
};
