/**
 * HTTP 请求封装
 * 自动注入 token，统一错误处理
 */

const state = require('./state');
const CONFIG = require('../config');

/**
 * 获取有效的认证 token
 * 优先级：配置文件 token > 内存 token > 文件 token > API Key
 */
function getAuth() {
  // 1. 优先使用配置文件中的 token（最可靠，支持跨进程）
  const configToken = CONFIG.getTokenFromFile();
  if (configToken) {
    return configToken;
  }
  
  // 2. 使用内存中的 token
  if (state.STATE.token) {
    return state.STATE.token;
  }
  
  // 3. 尝试从临时文件加载
  if (state.loadState()) {
    if (state.STATE.token) {
      return state.STATE.token;
    }
  }
  
  // 4. 使用 API Key 作为备选
  return CONFIG.apiKey;
}

/**
 * 发送 HTTP 请求
 * @param {string} path - API 路径
 * @param {object} options - 请求选项
 * @param {boolean} options.useApiKey - 强制使用 API Key 而不是 user token（用于公开接口）
 */
async function request(path, options = {}) {
  const url = CONFIG.apiBase + path;
  
  // 如果明确指定使用 API Key，或者路径是公开接口，则使用 API Key
  const publicPaths = ['/api/v1/department/tree', '/api/v1/schedule/'];
  const isPublicPath = publicPaths.some(p => path.startsWith(p));
  const useApiKey = options.useApiKey || isPublicPath;
  
  const auth = useApiKey ? CONFIG.apiKey : getAuth();
  const authType = auth === CONFIG.apiKey ? 'API_KEY' : 'TOKEN';
  // 🔒 敏感信息脱敏：API Key 只显示前 8 位，Token 不显示
  const authPreview = auth === CONFIG.apiKey 
    ? (auth ? auth.substring(0, 8) + '***' : 'null')
    : (auth ? '***' : 'null');
  
  console.log('[HTTP] ===== 请求开始 =====');
  console.log('[HTTP] URL:', url);
  console.log('[HTTP] 认证类型:', authType);
  console.log('[HTTP] 认证预览:', authPreview);
  console.log('[HTTP] 方法:', options.method || 'GET');
  console.log('[HTTP] 使用 API Key:', useApiKey ? '是' : '否');
  // 🔒 脱敏处理：不显示敏感字段
  if (options.body) {
    const safeBody = { ...options.body };
    if (safeBody.token) safeBody.token = '***';
    console.log('[HTTP] 请求体:', JSON.stringify(safeBody));
  }
  
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${auth}`
  };
  
  console.log('[HTTP] Headers:', JSON.stringify(headers, null, 2));
  
  const config = {
    method: options.method || 'GET',
    headers
  };
  
  if (options.body) {
    config.body = JSON.stringify(options.body);
  }
  
  const res = await fetch(url, config);
  const rawText = await res.text();
  console.log('[HTTP] 响应状态码:', res.status);
  // 🔒 脱敏处理：不显示完整响应中的敏感信息
  let safeText = rawText.substring(0, 500);
  if (safeText.includes('"token"')) {
    safeText = safeText.replace(/"token":"[^"]+"/g, '"token":"***"');
  }
  console.log('[HTTP] 响应原文:', safeText);
  
  let result;
  try {
    result = JSON.parse(rawText);
  } catch (e) {
    console.log('[HTTP] ❌ 响应不是 JSON 格式');
    throw new Error('响应格式错误：' + rawText.substring(0, 100));
  }
  
  // 处理错误
  if (result.code !== 200 && result.code !== 201) {
    console.log('[HTTP] ❌ 业务错误 code:', result.code, 'msg:', result.msg);
    throw new Error(result.msg || '操作失败');
  }
  
  console.log('[HTTP] ✅ 请求成功');
  return result.data || result;
}

module.exports = request;
