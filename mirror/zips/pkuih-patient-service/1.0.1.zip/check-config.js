#!/usr/bin/env node

/**
 * pkuih-hospital 配置检查脚本
 * 用于安装后、第一次使用前验证环境配置是否正确
 */

const fs = require('fs');
const path = require('path');

console.log('');
console.log('╔═══════════════════════════════════════════════════════╗');
console.log('║        pkuih-hospital 配置检查                        ║');
console.log('╠═══════════════════════════════════════════════════════╣');
console.log('║  版本：v2.2.9                                         ║');
console.log('║  检查：安装后、第一次使用前的配置验证                 ║');
console.log('╚═══════════════════════════════════════════════════════╝');
console.log('');

let allPassed = true;
const results = [];

/**
 * 检查项
 */
function check(name, fn) {
  try {
    const result = fn();
    results.push({ name, status: 'pass', message: result });
    console.log(`✅ ${name}`);
    if (result) console.log(`   ${result}`);
  } catch (err) {
    results.push({ name, status: 'fail', message: err.message });
    console.log(`❌ ${name}`);
    console.log(`   ${err.message}`);
    allPassed = false;
  }
}

/**
 * 警告项
 */
function warn(name, fn) {
  try {
    const result = fn();
    if (result) {
      results.push({ name, status: 'warn', message: result });
      console.log(`⚠️  ${name}`);
      console.log(`   ${result}`);
    } else {
      results.push({ name, status: 'pass', message: '无问题' });
      console.log(`✅ ${name}`);
    }
  } catch (err) {
    results.push({ name, status: 'pass', message: '未检查' });
  }
}

console.log('📋 开始检查...\n');

// ============================================================================
// 1. Node.js 版本检查
// ============================================================================
check('Node.js 版本', () => {
  const version = process.version;
  const major = parseInt(version.slice(1).split('.')[0]);
  
  if (major < 18) {
    throw new Error(`版本 ${version} 过低，需要 Node.js 18.0 或更高版本`);
  }
  
  return `版本 ${version} ✅`;
});

// ============================================================================
// 2. 环境变量检查
// ============================================================================
check('环境变量 PKUIH_API_KEY', () => {
  const apiKey = process.env.PKUIH_API_KEY;
  
  if (!apiKey) {
    throw new Error('未配置，请执行：echo \'export PKUIH_API_KEY="你的 API Key"\' >> ~/.profile');
  }
  
  if (apiKey === 'your-api-key' || apiKey === 'your_api_key_here') {
    throw new Error('使用默认值，请替换为真实的 API Key');
  }
  
  if (apiKey === '[REDACTED]' || apiKey === 'REDACTED') {
    throw new Error('配置文件中的占位符，请替换为真实的 API Key');
  }
  
  return `已配置 (${apiKey.substring(0, 8)}***)`;
});

// ============================================================================
// 3. 模块加载检查
// ============================================================================
check('模块加载', () => {
  try {
    const pkuih = require('./index.js');
    
    // 检查必要的导出
    const requiredExports = ['getCaptcha', 'sendSms', 'login', 'appointment'];
    for (const exp of requiredExports) {
      if (!pkuih[exp]) {
        throw new Error(`缺少导出：${exp}`);
      }
    }
    
    return '所有必要模块已加载';
  } catch (err) {
    throw new Error(`加载失败：${err.message}`);
  }
});

// ============================================================================
// 4. 配置文件检查
// ============================================================================
warn('配置文件 .gitignore', () => {
  const gitignorePath = path.join(__dirname, '.gitignore');
  
  if (!fs.existsSync(gitignorePath)) {
    return '⚠️  .gitignore 文件不存在，建议创建以防止敏感信息泄露';
  }
  
  const gitignore = fs.readFileSync(gitignorePath, 'utf-8');
  
  if (!gitignore.includes('.pkuih.config.json')) {
    return '⚠️  .pkuih.config.json 未在 .gitignore 中，有泄露风险';
  }
  
  return '.pkuih.config.json 已正确排除';
});

// ============================================================================
// 5. 配置文件内容检查
// ============================================================================
warn('配置文件敏感信息', () => {
  const configPath = path.join(__dirname, '.pkuih.config.json');
  
  if (!fs.existsSync(configPath)) {
    return null; // 配置文件不存在是正常的
  }
  
  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    
    // 检查是否包含真实 API Key
    if (config.apiKey && 
        config.apiKey !== '[REDACTED]' && 
        config.apiKey !== 'REDACTED' &&
        config.apiKey.length > 20) {
      return '⚠️  配置文件中包含真实 API Key，建议删除或替换为 [REDACTED]';
    }
    
    return null;
  } catch (err) {
    return null;
  }
});

// ============================================================================
// 6. Git 仓库检查
// ============================================================================
warn('Git 敏感文件检查', () => {
  const { execSync } = require('child_process');
  
  try {
    // 检查 .pkuih.config.json 是否在 Git 中
    const result = execSync('git ls-files .pkuih.config.json', { 
      cwd: __dirname,
      encoding: 'utf-8',
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    if (result.trim()) {
      return '⚠️  .pkuih.config.json 已提交到 Git，请立即执行：git rm --cached .pkuih.config.json';
    }
    
    return null;
  } catch (err) {
    // git ls-files 返回非 0 表示文件不在 Git 中，这是正常的
    return null;
  }
});

// ============================================================================
// 7. 文件权限检查
// ============================================================================
warn('状态文件权限', () => {
  const stateFile = '/tmp/pkuih_state.json';
  
  if (!fs.existsSync(stateFile)) {
    return null; // 状态文件不存在是正常的
  }
  
  const stats = fs.statSync(stateFile);
  const mode = stats.mode & 0o777;
  
  if (mode !== 0o600) {
    return `⚠️  权限 ${mode.toString(8)} 不够安全，建议：chmod 600 ${stateFile}`;
  }
  
  return null;
});

// ============================================================================
// 8. API 连接测试（可选）
// ============================================================================
warn('API 连接测试', () => {
  // 不实际调用 API，只检查配置是否可能成功
  const apiKey = process.env.PKUIH_API_KEY;
  
  if (!apiKey || apiKey.length < 20) {
    return '⚠️  API Key 长度异常，可能配置错误';
  }
  
  if (!apiKey.includes('@')) {
    return '⚠️  API Key 格式可能不正确（缺少 @ 字符）';
  }
  
  return null;
});

// ============================================================================
// 总结
// ============================================================================
console.log('\n');
console.log('╔═══════════════════════════════════════════════════════╗');

if (allPassed) {
  console.log('║  ✅ 所有检查通过！                                       ║');
  console.log('║                                                         ║');
  console.log('║  配置正确，可以开始使用 pkuih-hospital                   ║');
} else {
  console.log('║  ❌ 存在配置问题                                         ║');
  console.log('║                                                         ║');
  console.log('║  请根据上述错误提示修复配置                              ║');
  console.log('║  修复后重新运行：node check-config.js                    ║');
}

console.log('╚═══════════════════════════════════════════════════════╝');
console.log('');

// 输出快速修复命令
if (!allPassed) {
  console.log('📝 快速修复命令：');
  console.log('');
  
  const failChecks = results.filter(r => r.status === 'fail');
  
  if (failChecks.some(r => r.name.includes('PKUIH_API_KEY'))) {
    console.log('# 配置环境变量');
    console.log('echo \'export PKUIH_API_KEY="你的 API Key"\' >> ~/.profile');
    console.log('source ~/.profile');
    console.log('');
  }
  
  if (failChecks.some(r => r.name.includes('Git'))) {
    console.log('# 从 Git 移除配置文件');
    console.log('git rm --cached .pkuih.config.json');
    console.log('git commit -m "Remove sensitive config file"');
    console.log('');
  }
}

console.log('📚 更多帮助：');
console.log('   - 快速安装指引：QUICKSTART.md');
console.log('   - 详细安装指南：INSTALL.md');
console.log('   - 故障排查：TROUBLESHOOTING.md');
console.log('');

// 退出码
process.exit(allPassed ? 0 : 1);
