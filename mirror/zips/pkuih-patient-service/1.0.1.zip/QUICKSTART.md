# pkuih-hospital 快速安装指引

---

## 📦 安装步骤

### 1️⃣ 克隆仓库

```bash
git clone https://gitee.com/vegetable-bird-0209/pkuih_service.git pkuih-hospital
cd pkuih-hospital
```

---

### 2️⃣ 配置环境变量

**⚠️ 重要：必须配置到 `~/.profile`（不是 `~/.bashrc`）**

```bash
# 添加环境变量
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile

# 立即生效
source ~/.profile

# 验证配置
echo $PKUIH_API_KEY
```

**为什么用 ~/.profile？**
- `~/.bashrc` 只在交互式终端加载
- Node.js 脚本、子进程等**非交互式 shell**不会加载 `~/.bashrc`
- `~/.profile` 支持所有类型的 shell

---

### 3️⃣ 获取 API Key

**联系医院信息科获取 API Key**

- 格式：类似 `jD3UFiE1Lo27EsdKZvMP8EHdkkFao1Q@Joum__MCsVTXoCLNGrJgjKyNq4VZDUOr`
- ⚠️ **不要提交到 Git 仓库**（已自动添加到 `.gitignore`）
- ⚠️ **不要公开分享**

---

## ✅ 验证安装

```bash
# 运行配置检查（推荐）
node check-config.js

# 或手动测试
# 测试模块加载
node -e "require('./index.js'); console.log('✅ 安装成功')"

# 测试环境变量
node -e "console.log('API Key:', process.env.PKUIH_API_KEY ? '已配置' : '未配置')"
```

---

## 🚀 快速使用

```javascript
const pkuih = require('./index.js');

// 1. 获取验证码
const captcha = await pkuih.getCaptcha();
console.log('验证码:', captcha.captcha_code);

// 2. 发送短信
await pkuih.sendSms('手机号', captcha.captcha_key, captcha.captcha_code);

// 3. 登录
const user = await pkuih.login('手机号', '短信验证码');

// 4. 查询排班
const doctors = await pkuih.appointment.getDoctorSchedule('科室代码', '开始日期', '结束日期');

// 5. 预约（会自动显示确认界面）
const result = await pkuih.appointment.bookAppointment(医生，号源，序号);
```

---

## 📋 完整文档

| 文档 | 说明 |
|------|------|
| [INSTALL.md](./INSTALL.md) | 详细安装与配置指南 |
| [SKILL.md](./SKILL.md) | 功能说明和使用示例 |
| [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) | 常见问题排查 |
| [SECURITY.md](./SECURITY.md) | 安全说明 |

---

## ⚠️ 常见问题

### "无效的 API Key"

```bash
# 检查环境变量
echo $PKUIH_API_KEY

# 如果为空，重新配置
echo 'export PKUIH_API_KEY="你的 API Key"' >> ~/.profile
source ~/.profile
```

### "号位状态不是未用"

- 号位已被其他用户预约
- 重新查询排班，选择其他号源
- 添加重试机制（见 TROUBLESHOOTING.md）

### "登录已过期"

- Token 30 分钟自动过期
- 重新执行登录流程

---

## 📞 获取帮助

- **仓库**: https://gitee.com/vegetable-bird-0209/pkuih_service.git
- **Issue**: 在 Gitee 提交问题
- **作者**: 高坤

---

**最后更新**: 2026-04-11  
**版本**: v2.2.9
