/**
 * pkuih-hospital - 北京大学国际医院医疗服务 Skill
 * 
 * 核心功能：
 * - 挂号服务：查询排班、预约挂号
 * - 报告服务：检验报告、检查报告（即将推出）
 * - 缴费服务：在线缴费、缴费记录（即将推出）
 * 
 * @author 高坤
 * @version 2.3.0
 */

// 核心层
const state = require('./core/state');
const auth = require('./core/auth');
const request = require('./core/request');
const security = require('./core/security');

// 业务模块
const appointment = require('./modules/appointment');
const report = require('./modules/report');
const payment = require('./modules/payment');

// 工具函数
const utils = require('./utils');

module.exports = {
  // 认证相关
  getCaptcha: auth.getCaptcha,
  sendSms: auth.sendSms,
  login: auth.login,
  loginInteractive: auth.loginInteractive,  // ✅ 交互式登录
  logout: auth.logout,
  getCurrentUser: auth.getCurrentUser,
  getPatient: auth.getPatient,
  isLoggedIn: state.isLoggedIn,
  
  // 挂号模块
  appointment,
  
  // 报告模块
  report,
  
  // 缴费模块
  payment,
  
  // 工具函数
  getDateRange: utils.getDateRange,
  formatDate: utils.formatDate,
  parseDate: utils.parseDate,
  
  // 核心导出（高级用法）
  core: {
    state,
    auth,
    request,
    security
  }
};
