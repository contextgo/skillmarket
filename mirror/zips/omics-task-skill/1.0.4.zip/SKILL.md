---
name: omics-task-skill
description: >
  Tencent Healthcare Omics Platform assistant with 19 APIs.
  Use this skill when the user wants to: (1) run or submit bioinformatics analysis tasks
  such as WGS, RNA-seq, WDL or Nextflow applications via RunApplication, (2) query task status,
  run progress, or job details, (3) download logs, reports, or execution results,
  (4) retry failed tasks or terminate running tasks, (5) manage projects, applications,
  environments, parameter templates, tables, or import public applications.
  Trigger on any mention of: omics, 组学平台, 基因组, bioinformatics, genomics,
  WGS, RNA-seq, WDL, Nextflow, pipeline, 投递, 运行, 查询, 重试, 终止, 任务, 批次,
  日志, 报告, 项目, 应用, 环境, 模板, 表格, 公共应用, or IDs matching patterns
  like run-xxx, app-xxx, env-xxx, prj-xxx, tab-xxx.
---

# 腾讯健康-组学平台-组学任务分析

## 前置规则（触发本 Skill 时必须遵守）

1. **调用前必须查阅 `./references/omics-api-reference.md`** 获取参数定义，禁止凭记忆猜测
2. **所有命令通过 `./scripts/tccli_runner.sh` 执行**，禁止自行拼接 tccli 命令
3. **仅允许 omics 产品 API**，禁止调用 cvm/cos/iam 等其他产品
4. **缺少必选参数时禁止执行、禁止编造 ID**，必须先调用上游 API 获取或向用户追问
5. **所有相对路径以 SKILL.md 所在目录为基准**
6. **执行 `RunApplication` 或 `RetryRuns` 前，必须先与用户确认一遍运行任务的完整信息**，获得用户明确的「确认 / 继续 / OK」等肯定答复后再投递；用户拒绝或提出修改时，按用户意图调整后重新确认

---

## 调用流程

用户通过会话通道以自然语言提出需求，按以下 5 步处理：

### 第 1 步：意图识别

根据用户输入，匹配下方映射表，确定需要调用哪些云 API。可能涉及多个 API 的组合调用。

| 用户说                                                                                    | API                                            | 说明                              |
| ----------------------------------------------------------------------------------------- | ---------------------------------------------- | --------------------------------- |
| "跑一个 WGS 分析" / "投递 RNA-seq" / "运行 app-xxx" / "提交批量分析" / "跑 Nextflow 流程" | **RunApplication**                             | 投递任务                          |
| "任务跑完了吗" / "查看 run-xxx 状态" / "最近任务进度" / "有没有失败的"                    | **DescribeRunGroups**                          | 任务批次列表/状态                 |
| "批次里的子任务" / "run-xxx 下有哪些任务"                                                 | **DescribeRuns**                               | 子任务列表                        |
| "查看任务详情" / "这个任务具体信息"                                                       | **GetRunStatus**                               | 单个任务详情                      |
| "查看作业步骤" / "作业树是什么样"                                                         | **GetRunCalls**                                | 作业层级（递归调用，见 API 参考） |
| "下载日志" / "查看报告" / "获取结果" / "拿 nextflow.log"                                  | **GetRunMetadataFile**                         | 日志/报告下载                     |
| "重试失败任务" / "重跑 run-xxx" / "重新运行这批" / "重跑成功的任务"                       | **RetryRuns**，失败时降级为 **RunApplication** | 重跑（见下方特殊处理）            |
| "终止任务" / "取消 run-xxx" / "停掉分析"                                                  | **TerminateRunGroup**                          | 终止                              |
| "我有哪些项目" / "查看项目列表"                                                           | **DescribeProjects**                           | 项目列表                          |
| "项目里有哪些应用" / "有哪些 WDL 应用" / "可用的分析流程" / "项目应用列表"                | **DescribeApplications**                       | 查询**项目内**已导入的应用        |
| "应用有哪些版本" / "查看 app-xxx 版本"                                                    | **DescribeApplicationVersions**                | 仅限项目应用                      |
| "有哪些公共应用" / "公共流程" / "可以导入哪些应用" / "某分类的公共应用" / "公共应用列表"  | **DescribePublicApplications**                 | 查询**平台公共**应用列表          |
| "查看子应用" / "这个应用下有哪些子应用" / "app-xxx 的子应用"                              | **DescribePublicApplications**                 | 传 ParentAppId 查子应用           |
| "导入公共应用到项目" / "把 scBERT 加到项目" / "从公共应用导入"                            | **ImportCommonApplication**                    | 将公共应用导入到项目中            |
| "有哪些运行环境" / "查看可用环境"                                                         | **DescribeEnvironments**                       | 环境列表                          |
| "应用有哪些参数模板" / "查看输入模板"                                                     | **DescribeInputTemplates**                     | 参数模板列表                      |
| "查看模板内容" / "模板里填了什么"                                                         | **GetInputTemplateFile**                       | 模板内容                          |
| "导入样本表格" / "上传 CSV 到项目"                                                        | **ImportTableFile**                            | 导入表格                          |
| "查看项目表格" / "有哪些表格"                                                             | **DescribeTables**                             | 表格列表                          |
| "查看表格数据" / "表格里有哪些行"                                                         | **DescribeTablesRows**                         | 表格行数据                        |

> **⚠️ 暂不支持的能力**：以下操作需前往[组学平台](https://omics.qq.com/platform)操作：
>
> | 类别 | 不支持操作 |
> |------|-----------|
> | 项目管理 | 新建/编辑/删除项目、设为默认 |
> | 应用生命周期 | 新建(空白/Git/COS/模板)、编辑/删除/复制/收藏应用 |
> | WDL 详情页 | 文件管理、版本发布/DAG 预览、保存为模板、流程编辑 |
> | 运行增强 | 校验应用、子任务终止/删除/搜索、作业重跑/释放/事件/日志、删批次记录 |
> | 参数模板 | 新建/修改/删除参数模板 |
> | 表格 | 删除表格、创建表格模板 |
> | 资源授权 | 关联 COS 存储桶/缓存卷、COS 授权、Git 凭证配置 |

**重跑任务特殊处理：**

用户可以重跑任意已结束的任务（终态为 COMPLETE/COMPLETE_ERROR/SUCCESS/EXECUTOR_ERROR/CANCELED/ERROR 均可）。**仅当任务批次仍在运行中（SUBMITTED/RUNNING/RUNNING_ERROR）时不允许重跑**，需提示用户等待任务结束或先终止任务。

> **状态枚举说明**：WDL 批次使用 GroupStatusEnum（如 COMPLETE、RUNNING_ERROR）；NF 批次使用 RunResultStatusEnum（如 SUCCESS、EXECUTOR_ERROR、CANCELED）。完整映射见下方「批次运行状态映射规则」章节。

处理流程：

1. **优先调用 RetryRuns** — 使用 ProjectId + RunGroupId 发起重跑
2. **RetryRuns 失败时降级为 RunApplication** — 可能是环境不可用或其他原因导致失败，此时：
   - 调用 `DescribeRunGroups` 查询该任务批次，获取对应的 `ApplicationId` 和 `ProjectId`
   - 调用 `GetRunStatus` 尝试获取原任务的运行参数 `Input`：
     - **取到 Input** → 通过 `encode_input.sh` 编码为 InputBase64，直接复用
     - **取不到 Input** → 调用 `DescribeInputTemplates(ApplicationId)` 查询最新模板列表，向用户展示并追问选择，调用 `GetInputTemplateFile` 获取 Content 后通过 `encode_input.sh` 编码
   - 补全 RunApplication 所需的其他参数（EnvironmentId 等）
   - 按照 RunApplication 的完整流程重新运行该应用，实现重跑

---

### 第 2 步：参数整理与确认

读取 `./references/omics-api-reference.md` 中对应 API 章节，整理所需入参：

1. **检查上下文** — 当前会话中是否已有可复用的参数（如之前获取的 ProjectId、ApplicationId 等），避免重复追问
2. **按依赖链补全** — 缺少必选入参时，先调用上游 API 获取（依赖关系见 `omics-api-reference.md`）
3. **引导用户提供** — 关键入参无法自动获取时，引导用户提供：
   - 每轮最多追问 1 个问题，避免一次问太多
   - 能自动获取的信息不追问（如只有 1 个项目时直接使用）
   - 列出选项时附带 ID 和名称，方便用户选择
   - 示例："查到 3 个项目，请选择：① WGS 项目(prj-xxx) ② RNA 项目(prj-yyy) ③ 测试项目(prj-zzz)"

---

### 第 3 步：拼接命令并执行

参数齐全后，通过 `tccli_runner.sh` 拼接并执行 tccli 命令：

```bash
bash ./scripts/tccli_runner.sh <API名称> <region> [--参数名 值 ...]
```

脚本内置白名单校验、地域校验、必选参数校验、响应解析。缺参时脚本拒绝执行并输出提示。

---

### 第 3.5 步：执行前最终确认（仅 RunApplication / RetryRuns 必经）

**凡是即将调用 `RunApplication` 或 `RetryRuns`，必须先向用户汇总任务信息并等待用户确认，禁止直接执行。**

汇总信息至少包含以下字段（缺项以「未设置 / 使用默认」注明）：

| 字段              | RunApplication                         | RetryRuns                              |
| ----------------- | -------------------------------------- | -------------------------------------- |
| 操作类型          | 🚀 投递新任务                          | 🔁 重跑已结束批次                      |
| 项目              | ProjectId + 项目名                     | ProjectId + 项目名                     |
| 应用              | ApplicationId + 应用名（+ 版本）       | 原批次的 ApplicationId + 应用名        |
| 运行环境          | EnvironmentId + 环境名                 | （沿用原批次环境，无需展示）           |
| 运行名称          | Name（用户提供或默认）                 | —                                      |
| 参数模板          | 模板名 + InputTemplateId               | —                                      |
| 运行参数          | Input（JSON 摘要，关键键名与值）       | —                                      |
| 重跑范围          | —                                      | RunGroupId，重跑全部 / 仅失败任务      |
| 其他              | Cache 缓存策略、Config 自定义配置      | —                                      |

确认语术模板：

```
即将投递以下任务，请确认：

  • 应用：<应用名>（<ApplicationId>）
  • 项目：<项目名>（<ProjectId>）
  • 环境：<环境名>（<EnvironmentId>）
  • 参数模板：<模板名>（<InputTemplateId>）
  • 运行参数（摘要）：<关键参数 JSON 片段>
  • 运行名称：<Name>

确认无误请回复「确认 / 继续」；如需调整，请告诉我要改什么。
```

处理规则：

- 用户回复「确认 / 继续 / OK / 好的」等肯定词 → 进入第 4 步执行
- 用户提出修改（换项目 / 换模板 / 改参数等）→ 按意图返回第 2 步调整，再次走到本步重新确认
- 用户明确拒绝 / 取消 → 终止流程，不执行任何投递

---

### 第 4 步：结果返回

- **执行成功** → 用中文向用户总结执行结果
- **执行失败** → 查阅 `./references/error-handling.md`，按错误码向用户说明原因和建议

---

### 第 5 步：特殊结果处理

**仅针对 RunApplication 和 RetryRuns 调用成功后**，提示用户可以随时主动询问任务状态：

```
✅ 任务已投递！批次 ID: run-xxx
⏱️ 组学分析通常需要 30 分钟到数小时。你可以随时对我说：
  • "查看 run-xxx 状态" — 查询最新进度
  • "run-xxx 跑完了吗" — 快速检查是否完成
  • "下载 run-xxx 日志" — 获取执行日志
```

> **禁止**提示定时查询、自动跟踪等功能。仅引导用户主动问询。

---

## 暂不支持的能力（引导至组学平台独立操作）

> **以下能力组学平台支持但 SKILL 未实现**，用户触发时统一引导至 **[https://omics.qq.com/platform](https://omics.qq.com/platform)** 操作，不尝试通过 tccli 绕行。
>
> **不支持清单（7 类 36 项）：**
>
> | 类别 | 不支持操作 | 原因 |
> |------|-----------|------|
> | 项目管理(4) | 新建、编辑(名称/描述/成员/环境)、删除(含运行中检查)、默认项目管理 | 涉及多步表单+权限校验 |
> | 应用生命周期(6) | 新建应用(空白WDL/Git/COS/内部模板)、编辑设置、删除、复制副本、收藏 | 需前端交互式流程；WDL详情页依赖延迟提交模型(Lazy Commit) |
> | WDL 详情页专属(8) | 文件资源管理(增删改上传)、设主文件、版本控制/发布、Code/Dnd编辑、DAG预览、保存为模板 | 编辑器内存树 + `WDLVersionSaveAPI` 批量事务提交，无法拆为独立CLI调用 |
> | 运行增强(10) | 校验WDL应用、终止/删除/搜索子任务、批量重跑子任务、重跑/释放作业(Job)、作业事件时间线、Job实时日志、删除批次记录 | 作业级API需精确的RunUuid+Path，链路过长 |
> | 参数模板写操作(3) | 新建(4步串行: create→凭证→COS→confirm)、修改(仅NF)、删除 | 涉及COS临时凭证上传 |
> | 表格写操作(2) | 删除表格(需权限+二次确认)、创建模板(纯前端下载CSV) | 创建模板不产生实体，仅为本地文件 |
> | 资源授权(4) | 关联COS存储桶、缓存卷管理、COS跨账号授权、Git凭证配置 | 涉及IAM/COS非omics产品权限 |

---

## 典型会话场景

**场景 1：用户说"帮我跑一个 WGS 分析"**

1. 【第 1 步】识别意图 → RunApplication（可能需组合多个 API）
2. 【第 2 步】DescribeProjects → 若多个项目，追问选择
3. 【第 2 步】DescribeApplications → 若多个应用，追问选择
4. 【第 2 步】DescribeInputTemplates → 追问模板 → GetInputTemplateFile → encode_input.sh 编码
5. 【第 2 步】DescribeEnvironments → 若多个环境，追问选择
6. 【第 3.5 步】向用户汇总应用/项目/环境/模板/参数，等待用户「确认」
7. 【第 3 步】查阅 omics-api-reference.md → tccli_runner.sh 执行 RunApplication
8. 【第 4 步】回复执行结果
9. 【第 5 步】提示："任务已投递！批次 ID: run-xxx。你可以随时问我查看进度。"

**场景 2：用户说"帮我导入 scBERT 并运行"**

1. 【第 1 步】识别意图 → ImportCommonApplication + RunApplication
2. 【第 2 步】DescribePublicApplications → 匹配 scBERT，获取 UUID
3. 【第 2 步】DescribeProjects → 若多个项目，追问选择
4. 【第 3 步】执行 ImportCommonApplication → 获取 ApplicationId
5. 【第 2 步】DescribeEnvironments → 若多个环境，追问选择
6. 【第 3.5 步】向用户汇总应用/项目/环境/模板/参数，等待用户「确认」
7. 【第 3 步】执行 RunApplication
8. 【第 5 步】提示："scBERT 已导入并投递运行！批次 ID: run-xxx。你可以随时问我查看进度。"

**场景 3：用户说"重跑 run-xxx"**

1. 【第 1 步】识别意图 → 重跑任务（任务已结束即可，不限终态）
2. 【第 2 步】用户提供 RunGroupId → 若未提供 ProjectId，追问
3. 【第 3.5 步】向用户汇总项目/批次/重跑范围，等待用户「确认」
4. 【第 3 步】执行 RetryRuns(ProjectId, RunGroupId)
5. 【第 4 步】若成功 → 【第 5 步】提示："已发起重跑！新批次 ID: run-yyy。你可以随时问我查看进度。"
6. 【第 4 步】若失败 → 告知用户 RetryRuns 失败原因，尝试降级方案：
   - 【第 2 步】调用 DescribeRunGroups 获取该批次的 ApplicationId 和 ProjectId
   - 【第 2 步】调用 GetRunStatus 尝试获取原任务 Input
     - 取到 → `encode_input.sh` 编码为 InputBase64
     - 取不到 → DescribeInputTemplates → 追问用户选择模板 → GetInputTemplateFile → `encode_input.sh` 编码
   - 【第 2 步】补全 RunApplication 所需的其他参数（EnvironmentId 等）
   - 【第 3.5 步】向用户汇总降级方案的完整参数，等待用户「确认」
   - 【第 3 步】执行 RunApplication
   - 【第 5 步】提示："已通过重新投递实现重跑！新批次 ID: run-zzz。你可以随时问我查看进度。"

**场景 4：用户说"最近的任务跑完了吗"**

1. 【第 1 步】识别意图 → DescribeRunGroups
2. 【第 2 步】检查上下文是否有 ProjectId
3. 【第 3 步】执行 DescribeRunGroups
4. 【第 4 步】回复：**按上方「批次运行状态判断规则」展示结果**，例如："最近 5 个任务：✅ 已完成 3 | ❌ 已失败 1 | 🔄 分析中 1"

**场景 5：用户说"下载 run-xxx 的日志"**

1. 【第 1 步】识别意图 → GetRunMetadataFile（需先 DescribeRuns 获取 RunUuid）
2. 【第 2 步】DescribeRuns 获取批次下的 RunUuid
3. 【第 3 步】执行 GetRunMetadataFile
4. 【第 4 步】回复："日志下载链接（1 分钟内有效）：https://..."

---

## 批次运行状态判断规则

> 调用 `DescribeRunGroups` 后，AI **必须**按照 `./references/run-group-status-mapping.md` 中的规则解读和展示批次状态。
>
> 涉及本规则的典型操作：查询任务进度（DescribeRunGroups）、判断终态/可重跑（RetryRuns 前置条件）、向用户汇报运行结果。
>
> **核心要点速查：**
> - WDL 取 `row.Status`(GroupStatusEnum)，NF 取 `row.RunStatusCounts[0].Status`(RunResultStatusEnum)，两者不可混用
> - RunAnalysisStatusEnum 命中时优先显示"分析中"，跳过后续映射
> - 禁止使用 Succeeded / Failed / Aborted / Pending 等旧状态名
> - 完整枚举→中文映射表、终态集合、关键陷阱详见上述参考文件

---

## Resources

| 文档/脚本        | 路径                                  | 说明                              |
| ---------------- | ------------------------------------- | --------------------------------- |
| **API 参数参考** | `./references/omics-api-reference.md` | **每次调用前必须查阅**            |
| **批次状态映射** | `./references/run-group-status-mapping.md` | DescribeRunGroups 结果解读规则 |
| **错误处理指南** | `./references/error-handling.md`      | API 返回错误时                    |
| **任务生命周期** | `./references/task-lifecycle.md`      | 需了解状态机时                    |
| **命令执行器**   | `./scripts/tccli_runner.sh`           | 所有 API 调用的入口               |
| **输入编码**     | `./scripts/encode_input.sh`           | RunApplication 输入编码           |
