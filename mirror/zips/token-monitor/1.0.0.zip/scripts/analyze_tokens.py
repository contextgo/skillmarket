#!/usr/bin/env python3
"""Analyze OpenClaw session token usage from JSONL session files."""

import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path

# Default timezone: Asia/Shanghai (UTC+8)
CST = timezone(timedelta(hours=8))


def find_sessions(base_dir=None):
    """Find all session JSONL files under ~/.openclaw/agents/*/sessions/."""
    if base_dir is None:
        base_dir = Path.home() / ".openclaw" / "agents"
    base = Path(base_dir)
    sessions = []
    if not base.exists():
        print(f"Agents directory not found: {base}", file=sys.stderr)
        return sessions
    for agent_dir in sorted(base.iterdir()):
        if not agent_dir.is_dir():
            continue
        sessions_dir = agent_dir / "sessions"
        if not sessions_dir.exists():
            continue
        for f in sorted(sessions_dir.glob("*.jsonl")):
            sessions.append(f)
    return sessions


def parse_session(filepath):
    """Parse a session JSONL file and extract token usage records."""
    records = []
    try:
        with open(filepath, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if obj.get("type") != "message":
                    continue
                msg = obj.get("message", {})
                if msg.get("role") != "assistant":
                    continue
                usage = msg.get("usage")
                if not usage:
                    continue
                ts = obj.get("timestamp", "")
                model = msg.get("model", "unknown")
                provider = msg.get("provider", "unknown")
                records.append({
                    "timestamp": ts,
                    "model": model,
                    "provider": provider,
                    "input": usage.get("input", 0),
                    "output": usage.get("output", 0),
                    "cache_read": usage.get("cacheRead", 0),
                    "cache_write": usage.get("cacheWrite", 0),
                    "total": usage.get("totalTokens", 0),
                    "cost_total": usage.get("cost", {}).get("total", 0),
                })
    except Exception as e:
        print(f"Error parsing {filepath}: {e}", file=sys.stderr)
    return records


def to_cst(ts_str):
    """Convert ISO timestamp string to CST (UTC+8) datetime."""
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        return dt.astimezone(CST)
    except (ValueError, TypeError):
        return None


def fmt_tokens(n):
    """Format token count with k/M suffix."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}k"
    return str(n)


def report_all(records, days=7, top_n=10):
    """Print a comprehensive token usage report."""
    if not records:
        print("No token usage data found.")
        return

    now_cst = datetime.now(CST)
    cutoff = None
    if days:
        cutoff = now_cst.timestamp() * 1000 - days * 86_400_000

    filtered = []
    for r in records:
        ts_str = r["timestamp"]
        if ts_str:
            dt_cst = to_cst(ts_str)
            if dt_cst:
                ts_ms = dt_cst.timestamp() * 1000
                if cutoff and ts_ms < cutoff:
                    continue
            else:
                continue
        else:
            continue
        filtered.append(r)

    if not filtered:
        print(f"No token usage data in the last {days} days.")
        return

    # Summary
    total_in = sum(r["input"] for r in filtered)
    total_out = sum(r["output"] for r in filtered)
    total_cache_r = sum(r["cache_read"] for r in filtered)
    total_cache_w = sum(r["cache_write"] for r in filtered)
    total_all = sum(r["total"] for r in filtered)
    total_cost = sum(r["cost_total"] for r in filtered)
    num_calls = len(filtered)
    avg_in = total_in / num_calls if num_calls else 0
    avg_out = total_out / num_calls if num_calls else 0

    label = f"Last {days} days" if days else "All time"
    print(f"\n{'='*60}")
    print(f"  Token Usage Report ({label}) · 北京时间")
    print(f"  Generated: {now_cst.strftime('%Y-%m-%d %H:%M:%S')} CST")
    print(f"{'='*60}")
    print(f"\n📊 Overview")
    print(f"  API Calls:       {num_calls}")
    print(f"  Input tokens:    {fmt_tokens(total_in)}")
    print(f"  Output tokens:   {fmt_tokens(total_out)}")
    print(f"  Cache read:      {fmt_tokens(total_cache_r)}")
    print(f"  Cache write:     {fmt_tokens(total_cache_w)}")
    print(f"  Total tokens:    {fmt_tokens(total_all)}")
    if total_cost > 0:
        print(f"  Est. cost:       ${total_cost:.4f}")
    print(f"  Avg input/call:  {fmt_tokens(int(avg_in))}")
    print(f"  Avg output/call: {fmt_tokens(int(avg_out))}")

    # By Model
    model_stats = defaultdict(lambda: {"input": 0, "output": 0, "total": 0, "calls": 0, "cache_r": 0, "cache_w": 0})
    for r in filtered:
        key = f"{r['provider']}/{r['model']}"
        model_stats[key]["input"] += r["input"]
        model_stats[key]["output"] += r["output"]
        model_stats[key]["total"] += r["total"]
        model_stats[key]["cache_r"] += r["cache_read"]
        model_stats[key]["cache_w"] += r["cache_write"]
        model_stats[key]["calls"] += 1

    sorted_models = sorted(model_stats.items(), key=lambda x: x[1]["total"], reverse=True)
    print(f"\n🤖 By Model (top {min(top_n, len(sorted_models))})")
    print(f"  {'Model':<35} {'Calls':>6} {'Input':>8} {'Output':>8} {'Total':>8}")
    print(f"  {'-'*35} {'-'*6} {'-'*8} {'-'*8} {'-'*8}")
    for name, stats in sorted_models[:top_n]:
        pct_str = f"({stats['total']/total_all*100:.0f}%)" if total_all else ""
        print(f"  {name:<35} {stats['calls']:>6} {fmt_tokens(stats['input']):>8} {fmt_tokens(stats['output']):>8} {fmt_tokens(stats['total']):>8} {pct_str}")

    # Daily Trend
    daily = defaultdict(lambda: {"input": 0, "output": 0, "total": 0, "calls": 0})
    for r in filtered:
        dt_cst = to_cst(r["timestamp"])
        if dt_cst:
            day_key = dt_cst.strftime("%Y-%m-%d")
            daily[day_key]["input"] += r["input"]
            daily[day_key]["output"] += r["output"]
            daily[day_key]["total"] += r["total"]
            daily[day_key]["calls"] += 1

    if daily:
        sorted_days = sorted(daily.items())
        max_daily = max(v["total"] for _, v in sorted_days) if sorted_days else 1
        print(f"\n📈 Daily Trend (北京时间)")
        print(f"  {'Date':<12} {'Calls':>6} {'Input':>8} {'Output':>8} {'Total':>8}  {'Bar'}")
        print(f"  {'-'*12} {'-'*6} {'-'*8} {'-'*8} {'-'*8}  {'-'*20}")
        for day, stats in sorted_days:
            bar_len = int(stats["total"] / max_daily * 20) if max_daily else 0
            bar = "█" * bar_len
            print(f"  {day:<12} {stats['calls']:>6} {fmt_tokens(stats['input']):>8} {fmt_tokens(stats['output']):>8} {fmt_tokens(stats['total']):>8}  {bar}")

    # Hourly distribution
    if sorted_days:
        latest_day = sorted_days[-1][0]
        hourly = defaultdict(lambda: {"input": 0, "output": 0, "total": 0})
        for r in filtered:
            dt_cst = to_cst(r["timestamp"])
            if dt_cst and dt_cst.strftime("%Y-%m-%d") == latest_day:
                h = dt_cst.strftime("%H:00")
                hourly[h]["input"] += r["input"]
                hourly[h]["output"] += r["output"]
                hourly[h]["total"] += r["total"]

        if hourly:
            max_hourly = max(v["total"] for v in hourly.values()) if hourly else 1
            print(f"\n⏰ Hourly Breakdown ({latest_day} 北京时间)")
            print(f"  {'Hour':<8} {'Input':>8} {'Output':>8} {'Total':>8}  {'Bar'}")
            print(f"  {'-'*8} {'-'*8} {'-'*8} {'-'*8}  {'-'*20}")
            for h in sorted(hourly.keys()):
                stats = hourly[h]
                bar_len = int(stats["total"] / max_hourly * 20) if max_hourly else 0
                bar = "█" * bar_len
                print(f"  {h:<8} {fmt_tokens(stats['input']):>8} {fmt_tokens(stats['output']):>8} {fmt_tokens(stats['total']):>8}  {bar}")

    print()


def report_json(records, days=7):
    """Output as JSON for programmatic consumption."""
    now_cst = datetime.now(CST)
    cutoff = None
    if days:
        cutoff = now_cst.timestamp() * 1000 - days * 86_400_000

    filtered = []
    for r in records:
        ts_str = r["timestamp"]
        if ts_str:
            dt_cst = to_cst(ts_str)
            if dt_cst:
                ts_ms = dt_cst.timestamp() * 1000
                if cutoff and ts_ms < cutoff:
                    continue
            else:
                continue
        else:
            continue
        filtered.append(r)

    model_stats = defaultdict(lambda: {"input": 0, "output": 0, "total": 0, "calls": 0})
    for r in filtered:
        key = f"{r['provider']}/{r['model']}"
        model_stats[key]["input"] += r["input"]
        model_stats[key]["output"] += r["output"]
        model_stats[key]["total"] += r["total"]
        model_stats[key]["calls"] += 1

    daily = defaultdict(lambda: {"input": 0, "output": 0, "total": 0})
    for r in filtered:
        dt_cst = to_cst(r["timestamp"])
        if dt_cst:
            day_key = dt_cst.strftime("%Y-%m-%d")
            daily[day_key]["input"] += r["input"]
            daily[day_key]["output"] += r["output"]
            daily[day_key]["total"] += r["total"]

    result = {
        "generated": now_cst.isoformat(),
        "timezone": "Asia/Shanghai (CST, UTC+8)",
        "period_days": days,
        "summary": {
            "calls": len(filtered),
            "input": sum(r["input"] for r in filtered),
            "output": sum(r["output"] for r in filtered),
            "total": sum(r["total"] for r in filtered),
        },
        "by_model": dict(sorted(model_stats.items(), key=lambda x: x[1]["total"], reverse=True)),
        "by_day": dict(sorted(daily.items())),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Analyze OpenClaw token usage")
    parser.add_argument("--days", type=int, default=7, help="Number of days to include (default: 7, 0 for all)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--base-dir", default=None, help="Custom agents directory")
    parser.add_argument("--top", type=int, default=10, help="Top N models to show")
    args = parser.parse_args()

    sessions = find_sessions(args.base_dir)
    if not sessions:
        print("No session files found.", file=sys.stderr)
        sys.exit(1)

    all_records = []
    for s in sessions:
        all_records.extend(parse_session(s))

    if args.json:
        report_json(all_records, days=args.days if args.days > 0 else None)
    else:
        report_all(all_records, days=args.days if args.days > 0 else None, top_n=args.top)


if __name__ == "__main__":
    main()
