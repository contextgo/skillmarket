---
name: token-usage-monitor
description: 'Monitor and analyze OpenClaw token usage across sessions. Shows models used, token counts (input/output/cache), daily trends, and hourly breakdowns. Use when the user asks about token usage, API consumption, cost tracking, model usage stats, token trends, or how many tokens have been used. Triggers: token usage, 用量, token统计, 消耗, cost, 花费, model usage, API usage.'
---

# Token Usage Monitor

Analyze OpenClaw session token usage from JSONL session files.

## Quick Usage

Run the analysis script:

```bash
python3 ~/.openclaw/workspace/skills/token-usage-monitor/scripts/analyze_tokens.py
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `--days N` | 7 | Include last N days (0 = all time) |
| `--json` | false | Output as JSON for programmatic use |
| `--top N` | 10 | Show top N models |
| `--base-dir PATH` | ~/.openclaw/agents | Custom agents directory |

### Examples

```bash
# Last 7 days (default)
python3 scripts/analyze_tokens.py

# Last 30 days
python3 scripts/analyze_tokens.py --days 30

# All time, JSON output
python3 scripts/analyze_tokens.py --days 0 --json

# Top 5 models
python3 scripts/analyze_tokens.py --top 5
```

## What It Shows

1. **Overview** — Total API calls, input/output/cache tokens, average per call
2. **By Model** — Token breakdown per model with percentage share
3. **Daily Trend** — Day-by-day token consumption with visual bars
4. **Hourly Breakdown** — Usage distribution for the latest active day

## Data Source

Reads from `~/.openclaw/agents/*/sessions/*.jsonl` — all agent session files. Each assistant message includes a `usage` object with `input`, `output`, `cacheRead`, `cacheWrite`, `totalTokens`, and `cost` fields.

## Notes

- Cost is $0.00 if the provider doesn't return pricing (e.g., some local/custom providers)
- The script aggregates across ALL agents (main, sub-agents, etc.)
- Timestamps are in UTC; daily grouping uses UTC dates
