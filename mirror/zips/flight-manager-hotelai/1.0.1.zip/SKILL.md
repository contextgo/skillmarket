---
name: hotelTool
description: 酒店管家预订助手 - 通过 curl 调用 MCP 实现国内酒店搜索、详情查询、预订下单。适用于用户询问酒店、查询酒店价格或提交酒店订单时使用。
version: 1.0.0
metadata: {"openclaw": {"emoji": "🏨", "category": "travel", "tags": ["酒店管家", "酒店", "预订", "MCP"], "requires": {"bins": ["curl"]}, "env": {"HUOLI_API_KEY": {"type": "string", "description": "酒店管家分配的 API key，用于 Authorization: Bearer 请求头", "required": true}}}}
---

# 酒店管家预订助手

当用户询问酒店搜索、详情查询或酒店预订时，使用此 skill 通过 curl 调用酒店管家 MCP 服务。

## 运行环境要求

本 skill 通过 **shell exec** 执行 **curl** 向 MCP 服务发起 HTTP POST 请求，使用 JSON-RPC 2.0 / `tools/call` 协议。

本项目网关支持"无 Session 直通"模式：不需要先 `initialize` 建立会话，直接在请求头携带 `Authorization: Bearer <api_key>` 即可调用工具。

## 隐私与个人信息（PII）说明

预订功能会将用户提供的**个人信息**（联系人姓名、手机号、身份证号等）通过 HTTP POST 发送至酒店管家 MCP 远端服务，以完成酒店预订。使用本 skill 即表示用户知晓并同意上述 PII 被发送到外部服务。请勿在终端日志或大模型回复中暴露用户的完整个人信息。

## 适用场景

- 调用业务工具 (`tools/call`)，如城市数据映射、酒店搜索、详情查询、预订下单等

## 配置要求

### 必需配置
- **HUOLI_API_KEY**：酒店管家分配的 API key，用于 `Authorization: Bearer <api_key>` 请求头。
  
  **获取方式**：
> C 端用户获取 API Key：https://h5.133.cn/webapp/pages/mcpApiKey

### 可选配置
- **MCP_URL**：MCP 服务地址，默认 `https://t.rsscc.com/mcp/hotelai`。

## 功能概述

该工具提供酒店搜索相关功能，包括：
1. **城市ID查询**：查询城市ID，返回城市名（cityName）对应的城市ID（cityId），用于通过城市名找城市ID。如果查询失败就重试1次，再失败可以提示用户重新输入城市名。
2. **条件搜索酒店**：根据条件(要尽量从用户的对话上下文中获取每个参数的值)搜索酒店，这个接口会返回一个酒店列表。不要直接匹配结果（即使已经存在匹配的酒店），按照左侧显示封面图、右侧显示酒店信息的格式展示酒店列表，然后询问用户要选择哪一个酒店来查看价格。用户有可能不会说是哪个酒店，可能给的是一个地标，如XX广场、XX车站、XX中心等，就获取这些地标的GCJ-02坐标系。
3. **精确查询酒店价格**：根据酒店ID查询酒店的价格信息，这个接口不能自动触发，需要用户在列表中选择一个酒店后调用。
4. **创建订单**：提交酒店预订订单，这个接口需要在精确查询酒店价格后调用，由用户确认订单信息后调用该接口。如果参数缺失，需要提示用户重新输入。最多支持1人入住。
5. **查询订单**：模糊或精确查询订单详细信息，创建完订单后调用此工具查询订单详情。
6. **取消订单**：取消酒店预订订单，取消结果：1-成功，2-失败，3-申请取消中。

**重要流程**：
如果没有解析到城市信息，则先询问用户"你在哪个城市"，用户确认后，根据用户确认的城市，调用城市数据映射工具获取城市ID。
调用完条件搜索酒店后，不要直接猜测具体是哪一个酒店，按照左侧显示封面图、右侧显示酒店信息的格式展示酒店列表，然后询问用户要选择哪一个酒店来查看价格：
- 如果搜索结果只有一个酒店，也必须询问用户"是否就是这个酒店？"
- 如果搜索结果有多个酒店，必须询问用户"要查看这些酒店中的哪一个的价格？"
创建完订单后，获取订单号，调用[查询订单]工具，查询订单详情，展示给用户确认订单信息，如果状态[payStatus]显示未支付，则提示用户"订单未支付，是否支付？"。如果用户确认支付则调用浏览器打开支付链接[url]，否则不用处理，直接返回。

用户确认选择后（用户可以说第几个，也可以说酒店名字），调用hotel_detail_price接口查询该酒店的价格信息。

## 调用方式与示例

直接调用工具：在请求头携带 `Authorization: Bearer $HUOLI_API_KEY`，发送 `tools/call` 即可。

## 可用工具 (业务接口)

**重要**：下方示例中的参数均为占位，调用时需**根据用户当前需求**填入实际值（城市、日期、酒店ID等），勿直接照抄示例值。

### 1. 城市ID查询 (find_city_id)

**功能**：通过城市名查询城市ID
**触发词**：查城市、城市ID、城市列表

**关键参数 (arguments)**：
```typescript
{
  cityName: string;  // 城市名，如"北京"
}
```

**响应字段 (structuredContent.data)**：
```typescript
{
  code: number;
  msg: string;
  data: {
    cities: [{
      cityId: string;    // 城市ID
      cityName: string;  // 城市名
    }]
  }
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "base_hote_city",
      "arguments": {"cityName": "北京"}
    }
  }'
```

### 2. 条件搜索酒店 (search_hotel_list)

**功能**：根据城市、日期等条件搜索酒店，这个接口会返回一个酒店列表
**触发词**：查酒店、搜索酒店、酒店价格

**关键参数 (arguments)**：
- `cityId` (必填): 城市ID（通过城市名到base_hote_city获取的结果中查询）
- `checkIn` (必填): 入住日期（若用户未指定则默认今天）
- `checkOut` (必填): 离店日期（若用户未指定则默认入住日期+1天）
- `location` (可选): 地理位置坐标（高德坐标系，格式：纬度,经度），如果用户指定了位置信息，则该参数不能为空。
- `hotelName` (可选): 酒店名
- `price` (可选): 价格（用户给出的一个大概的中间价格，单位：元/人）重点：不是范围，是一个大概的价格。

**响应字段 (structuredContent.data)**：
```typescript
{
  success: boolean;
  code: number;
  msg: string;
  data: {
    total: number;       // 酒店总数
    page: number;        // 当前页码
    pageSize: number;    // 每页数量
    hotels: [{
      huoliId: string;   // 酒店ID
      hotelName: string; // 酒店名称
      starLevel: string; // 星级/档次
      score: string;     // 评分
      address: string;   // 地址
      minPrice: string;  // 最低价（元）
      imageUrl: string;  // 酒店首图URL
      phone: string;     // 联系电话
      highlights: string;// 亮点摘要
      location: string;  // 经纬度
    }]
  }
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
      "name": "search_hotel_list",
      "arguments": {
        "cityId": "1801",
        "checkIn": "2026-04-09"
      }
    }
  }'
```

### 3. 精确查询酒店价格 (hotel_detail_price)

**功能**：根据酒店ID查询酒店的价格信息
**触发词**：酒店详情、查看酒店、酒店价格

**关键参数 (arguments)**：
- `huoliId` (必填): 酒店ID（从search_hotel_list返回的结果中获得）
- `checkIn` (必填): 入住日期（若用户未指定则默认今天）
- `checkOut` (必填): 离店日期（若用户未指定则默认入住日期+1天）

**响应字段 (structuredContent.data)**：
```typescript
{
  success: boolean;
  code: number;
  msg: string;
  data: {
    huoliId: string;   // 酒店ID
    hotelName: string; // 酒店名称
    starLevel: string; // 星级/档次
    score: string;     // 评分
    address: string;   // 地址
    minPrice: string;  // 最低价（元）
    imageUrl: string;  // 酒店首图URL
    phone: string;     // 联系电话
    highlights: string;// 亮点摘要
    location: string;  // 经纬度
    rooms: [{
      roomName: string;       // 房型名称
      minPrice: string;       // 最低价
      huoliProductId: string; // 房型产品id
    }]
  }
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "hotel_detail_price",
      "arguments": {
        "huoliId": "hl_5032377",
        "checkIn": "2026-04-09"
      }
    }
  }'
```

### 4. 创建订单 (createOrder)

**功能**：提交酒店预订订单
**触发词**：创建订单、下订单、预订

**关键参数 (arguments)**：
- `hotelId` (必填): 酒店ID（从hotel_detail_price返回的结果中获得）
- `productId` (必填): 产品ID（从hotel_detail_price返回的结果中获得）
- `huoliProductId` (必填): 房型产品ID（从hotel_detail_price返回的结果中获得）
- `checkIn` (必填): 入住日期
- `checkOut` (必填): 离店日期
- `price` (必填): 价格（从hotel_detail_price返回的结果中获得）
- `count` (必填): 房间数
- `guest` (必填): 入住人
- `contactPhone` (必填): 联系电话

**响应字段 (structuredContent.data)**：
```typescript
{
  code: number;
  data: {
    orderId: string;  // 订单号
  };
  msg: string;
  ok: boolean;
  success: boolean;
  traceId: string;
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 4,
    "method": "tools/call",
    "params": {
      "name": "createOrder",
      "arguments": {
        "hotelId": "hl_5032377",
        "productId": "P123456",
        "huoliProductId": "HP123456",
        "checkIn": "2026-04-09",
        "checkOut": "2026-04-10",
        "price": "1288",
        "count": "1",
        "guest": "张三",
        "contactPhone": "13800138000"
      }
    }
  }'
```

### 5. 查询订单 (orderDetail)

**功能**：通过订单号查询订单详细信息
**触发词**：订单详情、查询订单、订单信息、支付、状态

**关键参数 (arguments)**：
- `orderId` (可选): 订单号
- `limit` (可选): 查询最近的订单数。当用户指定查询未完成、未支付、待支付的订单时，传0；否则传10

**响应字段 (structuredContent.data)**：
```typescript
{
  success: string;
  code: number;
  msg: string;
  data: [{
    orderId: string;      // 订单号
    hotelName: string;    // 酒店名称
    hotelAddr: string;    // 酒店地址
    hotelPhone: string;   // 酒店电话
    hotelLon: string;     // 酒店经度
    hotelLat: string;     // 酒店纬度
    cityName: string;     // 城市名称
    roomName: string;     // 房型名称
    guest: string;       // 入住人
    checkIn: string;      // 入住日期
    checkOut: string;    // 离店日期
    price: string;       // 订单金额
    phone: string;       // 联系电话
    payStatus: string;   // 支付状态
    orderStatus: string;  // 订单状态
    url: string;         // 支付链接地址
  }];
  ok: boolean;
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 5,
    "method": "tools/call",
    "params": {
      "name": "orderDetail",
      "arguments": {
        "orderId": "26040216182123770",
        "limit": 10
      }
    }
  }'
```

### 6. 取消订单 (cancelOrder)

**功能**：取消酒店订单
**触发词**：取消订单、退订

**关键参数 (arguments)**：
- `orderId` (必填): 订单号

**响应字段 (structuredContent.data)**：
```typescript
{
  success: string;
  code: number;
  msg: string;
  data: {
    result: number;  // 取消结果：1-成功，2-失败，3-申请取消中
  };
  ok: boolean;
}
```

**调用示例**：
```bash
curl -s -X POST "${MCP_URL:-https://t.rsscc.com/mcp/hotelai}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $HUOLI_API_KEY" \
  -d '{
    "jsonrpc": "2.0",
    "id": 6,
    "method": "tools/call",
    "params": {
      "name": "cancelOrder",
      "arguments": {
        "orderId": "26040216182123770"
      }
    }
  }'
```

## 响应处理与输出建议

### 响应解析
网关返回标准 JSON-RPC 2.0 格式：
```json
{
  "jsonrpc": "2.0",
  "result": {
    "isError": false,
    "content": [
      {
        "type": "text",
        "text": "..."
      }
    ],
    "structuredContent": {
      "data": { /* 业务数据 */ }
    }
  },
  "id": 1
}
```

### 输出建议
- 对于城市数据映射：返回城市列表或根据城市名查找对应的城市ID
- 对于酒店搜索：按照以下格式返回酒店列表，左侧显示封面图，右侧显示酒店信息：
  ```
  【酒店名称】
  星级：星级/档次 | 评分：评分
  价格：¥最低价
  地址：地址
  ```
  显示示例：
  🏨 【上海外滩W酒店】
  星级：五星级 | 评分：4.8
  价格：¥1288
  地址：上海市黄浦区中山东一路32号
- 对于酒店详情：返回酒店详细信息，包括房型、价格、设施等
- 对于预订结果：返回订单状态、订单号等信息
- 对于订单查询结果：
  - 如果订单数大于1条，横向显示每个订单的简要信息（表格形式）：
    | 序号 | 酒店名称 | 房型 | 入住日期 | 退房日期 | 价格 | 入住人 | 订单状态 |
    |------|---------|------|---------|---------|------|--------|----------|
  - 如果只有1条，纵向铺开每一个字段（支付链接不显示）：
    - 酒店名称：[酒店名称]
    - 酒店地址：[酒店地址]
    - 酒店电话：[酒店电话]
    - 城市名称：[城市名称]
    - 房型名称：[房型名称]
    - 入住人：[入住人]
    - 入住日期：[入住日期]
    - 离店日期：[离店日期]
    - 订单金额：[价格]
    - 联系电话：[联系电话]
    - 支付状态：[支付状态]（如果是未支付，则该字段可点击，跳转到支付链接地址：url）
    - 订单状态：[订单状态]

### 错误处理
如果接口调用失败，返回的 `isError` 为 `true`，需根据 `content` 中的错误信息向用户反馈。