---
name: singapore-fnb-location
description: "🍜 新加坡餐饮选址助手：分析租金、人流、竞争、盈亏平衡，辅助餐饮店铺选址决策"
metadata:
  {
    "openclaw":
      {
        "emoji": "🍜",
        "requires": { "bins": [] },
        "homepage": "https://github.com/gisellekokkok/Fnb-location-SG",
        "author": "gisellekokkok",
        "version": "1.0.0",
        "tags": ["singapore", "fnb", "restaurant", "location", "business"],
        "pricing": "free"
      }
  }
---

# 🍜 新加坡餐饮选址助手

帮助餐饮创业者分析选址可行性，计算盈亏平衡，评估区域潜力。

## 📋 核心功能

1. **区域租金参考** - 各区域租金范围、特点分析
2. **人流量评估** - 人流特征、适合业态匹配
3. **盈亏平衡计算** - 自动计算回本周期、成功几率
4. **身份匹配指南** - 不同身份开店路径（公民/PR/外国人）
5. **避坑指南** - 常见陷阱和应对方法

## 📖 详细指南

完整内容请查看：
👉 https://github.com/gisellekokkok/Fnb-location-SG/blob/main/README.md

包含：
- 精确到街道/楼栋的推荐
- 实时客单价调研方法
- 回本周期计算公式
- 成功几率评估模型
- 完整避坑清单

## 💬 使用示例

**场景1：盈亏计算**
```
输入：月租$6,000，人工$8,000，毛利率60%
输出：盈亏平衡点$23,333/月，日均需65单
```

**场景2：成功几率评估**
```
输入：甜品铺，Tiong Bahru，预算$100,000
输出：54/100分，建议找本地合伙人
```

**场景3：选址对比**
```
输入：Tanjong Pagar vs Lavender 开火锅店
输出：多维度对比表，根据需求推荐
```

## 📊 数据来源

- 租金数据：PropertyGuru Commercial, EdgeProp
- 行业统计：新加坡餐饮协会, NEA
- 市场趋势：URA 规划文件

*提示：数据仅供参考，实际决策需结合具体情况*
