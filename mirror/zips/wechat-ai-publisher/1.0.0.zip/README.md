# 微信公众号AI内容创作与发布 Skill

从AI新闻素材中挖掘选题，生成原创观点文章，自动发布到微信公众号。

## 功能特点

- 🔍 **智能选题**：从新闻素材中挖掘有价值的选题，不是简单汇总
- ✍️ **原创撰写**：按你的人设撰写有观点的文章
- 🎨 **自动配图**：AI生成封面图和插图
- 📤 **一键发布**：自动发布到微信草稿箱
- 🎯 **宁缺毋滥**：没有好选题就建议不发

## 适用人群

- AI领域自媒体创作者
- 技术博主/独立开发者
- AI创业者/产品经理
- 企业AI培训讲师

## 安装

### 1. 克隆 Skill

```bash
git clone https://github.com/your-repo/wechat-ai-publisher.git ~/.workbuddy/skills/wechat-ai-publisher
```

### 2. 安装依赖

```bash
# 即梦CLI（AI图片生成）
pip install dreamina-cli
dreamina login

# wenyan（Markdown转微信公众号HTML）
npm install -g @wenyan/cli
```

### 3. 运行配置向导

```bash
python3 ~/.workbuddy/skills/wechat-ai-publisher/scripts/setup.py
```

向导会引导你完成：
- 配置微信API凭证
- 设置作者信息
- 设置品牌签名
- 配置内容策略

### 4. 测试配置

```bash
python3 ~/.workbuddy/skills/wechat-ai-publisher/scripts/test_publish.py
```

## 使用方法

### 自动选题创作

```
帮我看看今天有什么值得写的选题
```

### 指定类型创作

```
帮我写一篇深度分析
帮我写一篇工具实测
帮我写一篇观点专栏
```

### 基于热点创作

```
针对【某个热点】，帮我写一篇深度解读
```

## 工作流程

1. **收集素材** - 多维度搜索AI新闻
2. **选题判断** - 评估选题价值（宁缺毋滥）
3. **原创撰写** - 按你的人设写文章
4. **生成配图** - AI生成封面图
5. **排版发布** - 自动发布到微信草稿箱

## 配置说明

配置文件位置：`~/.workbuddy/skills/wechat-ai-publisher/config.toml`

```toml
[wechat]
app_id = "your_app_id"
app_secret = "your_app_secret"

[author]
name = "你的名字"
title = "你的称号"
background = "你的背景"
expertise = "你的专业领域"

[brand]
public_account = "公众号名称"
slogan = "口号"
signature = "品牌签名"
footer_image = "引导关注图路径"
```

## 文章类型

### 深度解读
分析行业事件影响，必须有"你的实战视角"板块

### 工具推荐
AI工具实测，包括优缺点和适用场景

### 观点专栏
独立观点，有论据支撑和趋势判断

### 实战案例
企业AI落地案例拆解，方法论提炼

## 写作规范

- 标题含具体数字/事实，有观点态度
- 段落不超过4行，手机阅读友好
- 每篇文章自动追加品牌签名
- 避免"登顶"、"碾压"等极端化表述

## 踩坑经验

1. **IP白名单**：微信公众号API需要配置IP白名单
2. **图片压缩**：微信要求图片小于2MB
3. **敏感词**：避免极端化表述
4. **API权限**：普通权限只能创建草稿

## 目录结构

```
wechat-ai-publisher/
├── SKILL.md              # Skill 主文件
├── README.md             # 使用说明
├── config.template.toml  # 配置模板
├── config.toml           # 你的配置（gitignore）
├── scripts/
│   ├── setup.py          # 配置向导
│   └── test_publish.py   # 测试脚本
├── images/               # 图片目录
└── drafts/               # 草稿目录
```

## 更新日志

### v1.0.0
- 初始版本
- 支持选题判断、原创撰写、自动发布

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 PR！
