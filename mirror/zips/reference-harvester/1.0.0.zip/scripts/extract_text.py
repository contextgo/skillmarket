"""
Extract full text from a PDF using pdfplumber.
Usage: python extract_text.py <pdf_path> <output_text_path>
"""
import pdfplumber
import sys
import os

def extract_text(pdf_path, output_path):
    if not os.path.exists(pdf_path):
        print(f"ERROR: PDF not found: {pdf_path}")
        sys.exit(1)

    all_text = []
    with pdfplumber.open(pdf_path) as doc:
        total_pages = len(doc.pages)
        print(f"Total pages: {total_pages}")
        for i, page in enumerate(doc.pages):
            text = page.extract_text()
            if text:
                all_text.append(f"--- PAGE {i+1} ---\n{text}")
            else:
                all_text.append(f"--- PAGE {i+1} ---\n[no text extracted]")

    full_text = '\n'.join(all_text)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(full_text)

    print(f"Extracted {total_pages} pages -> {output_path}")
    print(f"Total characters: {len(full_text)}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python extract_text.py <pdf_path> <output_text_path>")
        sys.exit(1)
    extract_text(sys.argv[1], sys.argv[2])
