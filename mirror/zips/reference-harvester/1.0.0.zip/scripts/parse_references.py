"""
Parse individual references from extracted PDF text.
Supports multiple reference formats via auto-detection:
  - Format A: Numbered references (e.g., "1. Title, URL")
  - Format B: Author-first references (traditional academic style)

Applies broken-URL repair before any processing.

Usage: python parse_references.py <text_path> <output_json_path>
"""
import re
import json
import sys
import os


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def fix_broken_urls(text):
    """Fix URLs broken by PDF text extraction (spaces inserted after protocol
    or within the URL body due to line wrapping)."""
    # Collapse "https:// " -> "https://"
    text = re.sub(r'(https?://)\s+', r'\1', text)
    # Collapse "https://www. " -> "https://www."
    text = re.sub(r'(https?://(?:www\.))\s+', r'\1', text)
    return text


# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

REF_SECTION_MARKERS = [
    'References', 'REFERENCES', 'Bibliography', 'BIBLIOGRAPHY',
    '参考文献', '参考资料', 'Literaturverzeichnis', 'Bibliographie',
]

NOISE_PATTERNS = [
    r'^--- PAGE \d+',       # page markers from extract_text.py
    r'^\d{1,3}$',           # standalone page numbers (1-3 digits only)
    r'^AI Generated$',
    r'^Supported by SciMaster$',
    r'^www\.bohrium\.com',
]


def find_ref_section(text):
    """Return the text from the References section header onward."""
    for marker in REF_SECTION_MARKERS:
        idx = text.find(marker + '\n')
        if idx != -1:
            return text[idx:]
        # Also try marker at end of line
        idx = text.find(marker + '\r')
        if idx != -1:
            return text[idx:]
    # Case-insensitive fallback
    lower = text.lower()
    for marker in REF_SECTION_MARKERS:
        idx = lower.find(marker.lower() + '\n')
        if idx != -1:
            return text[idx:]
    return None


def clean_lines(lines):
    """Remove noise lines (page markers, headers, blank lines)."""
    cleaned = []
    compiled = [re.compile(p) for p in NOISE_PATTERNS]
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if any(pat.match(stripped) for pat in compiled):
            continue
        cleaned.append(stripped)
    return cleaned


def detect_format(cleaned_lines):
    """Detect whether references use numbered format or author-first format."""
    numbered_count = 0
    author_count = 0
    for line in cleaned_lines[:15]:  # check first 15 non-noise lines
        if re.match(r'^\d{1,3}\.\s+', line):
            numbered_count += 1
        elif re.match(r'^[A-Z][a-z\u00e4\u00f6\u00fc\u00e9\u00e8]+ [A-Z]', line):
            author_count += 1
    if numbered_count >= 2:
        return 'numbered'
    return 'author_first'


# ---------------------------------------------------------------------------
# Format A: Numbered references  (e.g., "1. Title, URL")
# ---------------------------------------------------------------------------

def parse_numbered(cleaned_lines):
    """Parse numbered reference format."""
    references = []
    current_lines = []
    current_num = None

    for line in cleaned_lines:
        match = re.match(r'^(\d{1,3})\.\s+(.+)', line)
        if match:
            # Save previous reference
            if current_lines and current_num is not None:
                ref_text = ' '.join(current_lines)
                references.append({'num': current_num, 'raw': ref_text})
            current_num = int(match.group(1))
            current_lines = [match.group(2)]
        else:
            if current_num is not None:
                current_lines.append(line)

    # Last reference
    if current_lines and current_num is not None:
        ref_text = ' '.join(current_lines)
        references.append({'num': current_num, 'raw': ref_text})

    # Post-process each reference
    result = []
    for ref in references:
        raw = ref['raw']
        # Remove footnote back-references (↩, ↩2, etc.)
        raw = re.sub(r'\s*↩\d*', '', raw).strip()

        title, url, doi, arxiv_id = '', '', '', None

        # Extract URL
        url_match = re.search(r'(https?://[^\s,↩]+)', raw)
        if url_match:
            url = url_match.group(1).rstrip('.)')

        # Extract DOI from URL or text
        doi_match = re.search(r'(?:doi\.org/|doi:\s*|/doi/)(10\.\d{4,}/[^\s,↩]+)', raw, re.IGNORECASE)
        if doi_match:
            doi = doi_match.group(1).rstrip('.)')

        # Title is everything before the URL
        if url_match:
            title = raw[:url_match.start()].strip().rstrip(',').strip()
        else:
            title = raw.strip()

        # Clean title
        title = re.sub(r'^\[PDF\]\s*', '', title)
        title = re.sub(r'\s*-\s*PMC\s*(-\s*NIH)?$', '', title)
        title = re.sub(r'\s*-\s*PubMed$', '', title)
        title = re.sub(r'\s*\.\.\.\s*$', '', title)
        title = title.strip().rstrip(',').strip()

        # Try to extract arXiv ID
        ax = re.search(r'arxiv\.org/(?:abs|content)/(?:10\.1101/)?(\d{4}\.\d{4,5}(?:v\d+)?)', raw)
        if ax:
            arxiv_id = ax.group(1)
        else:
            ax = re.search(r'arXiv[:\s]*(\d{4}\.\d{4,5}(?:v\d+)?)', raw)
            if ax:
                arxiv_id = ax.group(1)

        # Extract PMC ID
        pmc_match = re.search(r'(PMC\d+)', raw)
        pmc_id = pmc_match.group(1) if pmc_match else ''

        result.append({
            'index': ref['num'],
            'title': title,
            'url': url,
            'doi': doi,
            'arxiv_id': arxiv_id,
            'pmc_id': pmc_id,
            'raw': raw,
        })

    return result


# ---------------------------------------------------------------------------
# Format B: Author-first references
# ---------------------------------------------------------------------------

def looks_like_ref_start(line):
    """Check if a line looks like the start of a new author-first reference."""
    line = line.strip()
    if not line:
        return False
    patterns = [
        r'^[A-Z][a-z\u00e4\u00f6\u00fc\u00e9\u00e8]+ [A-Z]',
        r'^[A-Z][a-z\u00e4\u00f6\u00fc\u00e9\u00e8]+ [a-z]+ [A-Z]',
        r'^[A-Z][a-z]+ [A-Z][a-z]+,',
        r'^\[[0-9]+\]\s',  # [1] style
    ]
    return any(re.match(p, line) for p in patterns)


def ref_seems_complete(text):
    """Check if accumulated reference text seems complete."""
    text = text.strip()
    if re.search(r'(?:19|20)\d{2}[a-z]?\.\s*$', text):
        return True
    if re.search(r'https?://[^\s]+\.?\s*$', text):
        return True
    if re.search(r'\d+[-\u2013]\d+,\s*(?:19|20)\d{2}[a-z]?\.\s*$', text):
        return True
    return False


def parse_author_first(cleaned_lines):
    """Parse author-first style references."""
    references = []
    current_ref_lines = []

    for line in cleaned_lines:
        current_text = ' '.join(current_ref_lines).strip()
        if current_ref_lines and looks_like_ref_start(line) and ref_seems_complete(current_text):
            references.append(current_text)
            current_ref_lines = [line]
        else:
            current_ref_lines.append(line)

    if current_ref_lines:
        current_text = ' '.join(current_ref_lines).strip()
        if len(current_text) > 20:
            references.append(current_text)

    # Filter short entries
    references = [r for r in references if len(r) > 30]

    # Split merged references (year followed by new author)
    final_refs = []
    for ref in references:
        split_points = list(re.finditer(
            r'(\b(?:19|20)\d{2}[a-z]?\.)\s+([A-Z][a-z\u00e4\u00f6\u00fc\u00e9\u00e8]+ [A-Z])', ref))
        if split_points:
            parts, last_end = [], 0
            for sp in split_points:
                end_pos = sp.start() + len(sp.group(1))
                part = ref[last_end:end_pos].strip()
                if len(part) > 30:
                    parts.append(part)
                last_end = end_pos + 1
            remaining = ref[last_end:].strip()
            if len(remaining) > 30:
                parts.append(remaining)
            final_refs.extend(parts if len(parts) > 1 else [ref])
        else:
            final_refs.append(ref)

    # Convert to structured format
    result = []
    for i, raw in enumerate(final_refs):
        url_match = re.search(r'(https?://[^\s,]+)', raw)
        url = url_match.group(1).rstrip('.)') if url_match else ''
        doi_match = re.search(r'(?:doi\.org/|doi:\s*|/doi/)(10\.\d{4,}/[^\s,]+)', raw, re.IGNORECASE)
        doi = doi_match.group(1).rstrip('.)') if doi_match else ''
        ax = re.search(r'(?:arXiv[:\s]*|arxiv\.org/abs/)(\d{4}\.\d{4,5}(?:v\d+)?)', raw)
        arxiv_id = ax.group(1) if ax else None
        pmc_match = re.search(r'(PMC\d+)', raw)
        pmc_id = pmc_match.group(1) if pmc_match else ''

        # Try to extract title (first `. `-delimited segment after authors)
        parts = raw.split('. ')
        title = parts[1].strip() if len(parts) >= 2 else raw[:100]

        result.append({
            'index': i + 1,
            'title': title,
            'url': url,
            'doi': doi,
            'arxiv_id': arxiv_id,
            'pmc_id': pmc_id,
            'raw': raw,
        })

    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_references(text_path, output_path):
    with open(text_path, 'r', encoding='utf-8') as f:
        text = f.read()

    # Fix broken URLs throughout the text
    text = fix_broken_urls(text)

    # Find reference section
    refs_text = find_ref_section(text)
    if refs_text is None:
        print("ERROR: Could not find 'References' section in text.")
        sys.exit(1)

    lines = refs_text.split('\n')

    # Skip the section header line
    start_idx = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        for marker in REF_SECTION_MARKERS:
            if stripped.lower() == marker.lower() or stripped.startswith(marker):
                start_idx = i + 1
                break
    lines = lines[start_idx:]

    # Clean noise
    cleaned = clean_lines(lines)

    if not cleaned:
        print("ERROR: No reference content found after cleaning.")
        sys.exit(1)

    # Detect format
    fmt = detect_format(cleaned)
    print(f"Detected reference format: {fmt}")

    if fmt == 'numbered':
        refs = parse_numbered(cleaned)
    else:
        refs = parse_author_first(cleaned)

    print(f"Parsed {len(refs)} references:")
    for r in refs:
        try:
            line = f"  [{r['index']}] {r['title'][:80].encode('ascii', 'replace').decode()}"
            if r.get('doi'):
                line += f"  DOI:{r['doi'][:40]}"
            if r.get('arxiv_id'):
                line += f"  arXiv:{r['arxiv_id']}"
            if r.get('pmc_id'):
                line += f"  {r['pmc_id']}"
            print(line)
        except Exception:
            print(f"  [{r['index']}] [encoding error]")

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(refs, f, indent=2, ensure_ascii=False)
    print(f"\nSaved {len(refs)} references to: {output_path}")


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python parse_references.py <text_path> <output_json_path>")
        sys.exit(1)
    parse_references(sys.argv[1], sys.argv[2])
