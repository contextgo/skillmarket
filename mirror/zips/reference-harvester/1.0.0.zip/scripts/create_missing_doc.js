/**
 * Generate a Word document listing missing references with download page URLs.
 * 
 * Input JSON format: array of objects with fields:
 *   { authors, title, venue, url, note }
 * 
 * Usage: node create_missing_doc.js <missing_refs_json_path> <output_docx_path>
 * 
 * Requires: npm install docx
 */
const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
        ShadingType, PageNumber, ExternalHyperlink } = require('docx');

const args = process.argv.slice(2);
if (args.length !== 2) {
  console.log("Usage: node create_missing_doc.js <missing_refs_json_path> <output_docx_path>");
  process.exit(1);
}

const inputPath = args[0];
const outputPath = args[1];

// Read missing references (must be enriched with url and note fields by the agent)
const missingRefs = JSON.parse(fs.readFileSync(inputPath, 'utf-8'));

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const hdrBorder = { style: BorderStyle.SINGLE, size: 1, color: "4472C4" };
const hdrBorders = { top: hdrBorder, bottom: hdrBorder, left: hdrBorder, right: hdrBorder };

// Build header row
const tableRows = [
  new TableRow({
    tableHeader: true,
    children: [
      new TableCell({ borders: hdrBorders, width: { size: 400, type: WidthType.DXA }, shading: { fill: "4472C4", type: ShadingType.CLEAR },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "#", bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })] }),
      new TableCell({ borders: hdrBorders, width: { size: 2800, type: WidthType.DXA }, shading: { fill: "4472C4", type: ShadingType.CLEAR },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Authors", bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })] }),
      new TableCell({ borders: hdrBorders, width: { size: 3000, type: WidthType.DXA }, shading: { fill: "4472C4", type: ShadingType.CLEAR },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Title", bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })] }),
      new TableCell({ borders: hdrBorders, width: { size: 1600, type: WidthType.DXA }, shading: { fill: "4472C4", type: ShadingType.CLEAR },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Venue", bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })] }),
      new TableCell({ borders: hdrBorders, width: { size: 1560, type: WidthType.DXA }, shading: { fill: "4472C4", type: ShadingType.CLEAR },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Download Page", bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })] }),
    ]
  })
];

// Build data rows
missingRefs.forEach((ref, idx) => {
  const rowShading = idx % 2 === 0
    ? { fill: "F2F7FB", type: ShadingType.CLEAR }
    : { fill: "FFFFFF", type: ShadingType.CLEAR };

  const downloadCell = ref.url
    ? [new Paragraph({ children: [new ExternalHyperlink({
        children: [new TextRun({ text: ref.note || "Link", style: "Hyperlink", font: "Arial", size: 16 })],
        link: ref.url
      })] })]
    : [new Paragraph({ children: [new TextRun({ text: "N/A", font: "Arial", size: 16, color: "999999" })] })];

  tableRows.push(new TableRow({
    children: [
      new TableCell({ borders, width: { size: 400, type: WidthType.DXA }, shading: rowShading,
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: `${idx + 1}`, font: "Arial", size: 18 })] })] }),
      new TableCell({ borders, width: { size: 2800, type: WidthType.DXA }, shading: rowShading,
        children: [new Paragraph({ children: [new TextRun({ text: ref.authors || "", font: "Arial", size: 18 })] })] }),
      new TableCell({ borders, width: { size: 3000, type: WidthType.DXA }, shading: rowShading,
        children: [new Paragraph({ children: [new TextRun({ text: ref.title || "", font: "Arial", size: 18, bold: true })] })] }),
      new TableCell({ borders, width: { size: 1600, type: WidthType.DXA }, shading: rowShading,
        children: [new Paragraph({ children: [new TextRun({ text: ref.venue || "", font: "Arial", size: 16, color: "555555" })] })] }),
      new TableCell({ borders, width: { size: 1560, type: WidthType.DXA }, shading: rowShading,
        children: downloadCell }),
    ]
  }));
});

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal",
        run: { size: 36, bold: true, color: "1F3864", font: "Arial" },
        paragraph: { spacing: { before: 120, after: 200 }, alignment: AlignmentType.CENTER } },
    ]
  },
  sections: [{
    properties: {
      page: {
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
        size: { orientation: 1 }  // landscape
      }
    },
    headers: {
      default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
        children: [new TextRun({ text: "References Not Available for Direct Download", italics: true, color: "888888", size: 18, font: "Arial" })] })] })
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: "Page ", size: 18, font: "Arial" }),
          new TextRun({ children: [PageNumber.CURRENT], size: 18, font: "Arial" }),
          new TextRun({ text: " / ", size: 18, font: "Arial" }),
          new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, font: "Arial" })
        ] })] })
    },
    children: [
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("Unfound References - Download Pages")] }),
      new Paragraph({ spacing: { after: 200 }, children: [
        new TextRun({ text: `The following ${missingRefs.length} references could not be directly downloaded as PDFs. Their official download/access pages are listed below.`, size: 20 })
      ]}),
      new Table({
        columnWidths: [400, 2800, 3000, 1600, 1560],
        rows: tableRows
      }),
      new Paragraph({ spacing: { before: 300 }, children: [
        new TextRun({ text: "Note: ", bold: true, size: 20 }),
        new TextRun({ text: "Some papers may require institutional access or purchase. Open Access papers are marked where applicable.", size: 20, color: "666666" })
      ]}),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync(outputPath, buffer);
  console.log(`Document saved to: ${outputPath}`);
  console.log(`Total missing references listed: ${missingRefs.length}`);
});
