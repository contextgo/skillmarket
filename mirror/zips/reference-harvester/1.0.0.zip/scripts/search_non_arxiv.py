"""
Multi-source Open Access PDF downloader for non-arXiv references.

Tries multiple download strategies in priority order:
  1. Direct PDF URL
  2. bioRxiv / medRxiv
  3. PMC (EuropePMC backend)
  4. MDPI (mdpi-res.com CDN + www fallback)
  5. Nature / Springer OA
  6. PLoS
  7. RSC (Royal Society of Chemistry)
  8. Wiley OA
  9. Elsevier OA (ScienceDirect /pdfft)
  10. arXiv title search (last resort)

All downloads are validated by PDF header (%PDF-) check.

Usage: python search_non_arxiv.py <info_json_path> <output_dir> <missing_json_path>
"""
import urllib.request
import urllib.parse
import json
import os
import sys
import time
import ssl
import xml.etree.ElementTree as ET
import re

ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

MIN_PDF_SIZE = 5000  # 5KB minimum
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/pdf,*/*',
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def sanitize_filename(name, max_len=80):
    name = re.sub(r'[<>:"/\\|?*\u2013\u2014\u2018\u2019\u201c\u201d]', '_', name)
    name = re.sub(r'\s+', '_', name)
    name = re.sub(r'_+', '_', name)
    return name[:max_len].rstrip('_')


def is_valid_pdf(filepath):
    if not os.path.exists(filepath):
        return False
    if os.path.getsize(filepath) < MIN_PDF_SIZE:
        return False
    try:
        with open(filepath, 'rb') as f:
            return f.read(5) == b'%PDF-'
    except Exception:
        return False


def download_pdf(url, filepath, label=""):
    """Download a file, validate it is a real PDF, return True on success."""
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, context=ssl_context, timeout=30) as resp:
            data = resp.read()
            if data[:5] == b'%PDF-' and len(data) >= MIN_PDF_SIZE:
                with open(filepath, 'wb') as f:
                    f.write(data)
                print(f"    OK ({len(data)//1024}KB) via {label}")
                return True
            else:
                ct = resp.headers.get('Content-Type', 'unknown')
                print(f"    Not PDF ({len(data)} bytes, {ct}) via {label}")
                return False
    except Exception as e:
        print(f"    Failed via {label}: {str(e)[:80]}")
        return False


def search_arxiv_by_title(title):
    """Search arXiv API for a paper by title. Returns arXiv ID or None."""
    clean = re.sub(r'[^\w\s]', ' ', title)
    words = [w for w in clean.split()[:8] if len(w) > 2]
    if not words:
        return None
    query = '+AND+'.join([f'ti:{w}' for w in words])
    url = f'http://export.arxiv.org/api/query?search_query={query}&max_results=3'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'research-ref-downloader'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = resp.read().decode('utf-8')
        root = ET.fromstring(data)
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        title_lower = title.lower()
        title_words = set(re.findall(r'\w+', title_lower))
        for entry in root.findall('atom:entry', ns):
            et = entry.find('atom:title', ns)
            if et is not None and et.text:
                entry_words = set(re.findall(r'\w+', ' '.join(et.text.split()).lower()))
                if title_words and len(title_words & entry_words) / len(title_words) > 0.5:
                    eid = entry.find('atom:id', ns)
                    if eid is not None:
                        m = re.search(r'(\d{4}\.\d{4,5})', eid.text)
                        if m:
                            return m.group(1)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Download strategies
# ---------------------------------------------------------------------------

def try_direct_pdf(ref, filepath):
    """Strategy 1: URL ends in .pdf -> download directly."""
    url = ref.get('url', '')
    if url.endswith('.pdf'):
        return download_pdf(url, filepath, "direct PDF")
    return False


def try_biorxiv(ref, filepath):
    """Strategy 2: bioRxiv / medRxiv (DOI starts with 10.1101/)."""
    doi = ref.get('doi', '')
    if not doi or not doi.startswith('10.1101/'):
        return False
    for base in ['https://www.biorxiv.org', 'https://www.medrxiv.org']:
        pdf_url = f"{base}/content/{doi}v1.full.pdf"
        if download_pdf(pdf_url, filepath, base.split('//')[1]):
            return True
        time.sleep(2)
    return False


def try_pmc(ref, filepath):
    """Strategy 3: PMC via EuropePMC backend."""
    pmc_id = ref.get('pmc_id', '')
    if not pmc_id:
        # Try to extract from URL
        url = ref.get('url', '')
        m = re.search(r'(PMC\d+)', url)
        if m:
            pmc_id = m.group(1)
    if not pmc_id:
        return False
    urls = [
        f"https://europepmc.org/backend/ptpmcrender.fcgi?accid={pmc_id}&blobtype=pdf",
        f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmc_id}/pdf/",
    ]
    for purl in urls:
        if download_pdf(purl, filepath, f"PMC ({pmc_id})"):
            return True
        time.sleep(2)
    return False


def try_mdpi(ref, filepath):
    """Strategy 4: MDPI open access (all MDPI journals are OA)."""
    doi = ref.get('doi', '')
    url = ref.get('url', '')
    if 'mdpi.com' not in url and not (doi and '10.3390/' in doi):
        return False

    # Try mdpi-res.com CDN (less likely to 403)
    if doi and '10.3390/' in doi:
        # Parse DOI: 10.3390/{journal_abbr}{vol}{issue}{article_num}
        # e.g. 10.3390/cells14191539 -> cells, 14, 19, 1539
        doi_part = doi.replace('10.3390/', '')
        # Try constructing MDPI download URL from the web URL
        if 'mdpi.com/' in url:
            mdpi_pdf = url.rstrip('/') + '/pdf'
            if download_pdf(mdpi_pdf, filepath, "MDPI www"):
                return True
            time.sleep(1)

    # Try mdpi-res CDN with various patterns
    if 'mdpi.com/' in url:
        # Extract ISSN/vol/issue/article from URL like /2073-4409/14/19/1539
        m = re.search(r'mdpi\.com/([\d-]+)/(\d+)/(\d+)/(\d+)', url)
        if m:
            issn, vol, issue, article = m.groups()
            # Guess journal short name from ISSN
            cdn_url = (f"https://mdpi-res.com/d_attachment/"
                       f"{issn}/{issn}-{vol.zfill(2)}-{article.zfill(5)}/"
                       f"article_deploy/{issn}-{vol.zfill(2)}-{article.zfill(5)}.pdf")
            if download_pdf(cdn_url, filepath, "MDPI CDN"):
                return True
    return False


def try_nature_springer(ref, filepath):
    """Strategy 5: Nature / Springer / BMC open access."""
    url = ref.get('url', '')
    doi = ref.get('doi', '')

    # Nature family
    if 'nature.com/articles/' in url:
        article_id = url.split('/articles/')[-1].split('/')[0].split('?')[0]
        pdf_url = f"https://www.nature.com/articles/{article_id}.pdf"
        if download_pdf(pdf_url, filepath, "Nature"):
            return True
        time.sleep(2)

    # Springer / BMC (open access journals)
    if doi and ('springer.com' in url or 'biomedcentral.com' in url or
                doi.startswith('10.1186/') or doi.startswith('10.1007/')):
        pdf_url = f"https://link.springer.com/content/pdf/{doi}.pdf"
        if download_pdf(pdf_url, filepath, "Springer"):
            return True
        time.sleep(2)

    return False


def try_plos(ref, filepath):
    """Strategy 6: PLoS (all open access)."""
    doi = ref.get('doi', '')
    if not doi or '10.1371/' not in doi:
        return False
    pdf_url = f"https://journals.plos.org/plosone/article/file?id={doi}&type=printable"
    return download_pdf(pdf_url, filepath, "PLoS")


def try_rsc(ref, filepath):
    """Strategy 7: RSC (Royal Society of Chemistry)."""
    doi = ref.get('doi', '')
    if not doi or '10.1039/' not in doi:
        return False
    article_id = doi.split('/')[-1]
    # Try common RSC PDF pattern
    pdf_url = f"https://pubs.rsc.org/en/content/articlepdf/2024/ra/{article_id}"
    if download_pdf(pdf_url, filepath, "RSC"):
        return True
    # Try alternative years
    for year in ['2023', '2025', '2022']:
        pdf_url = f"https://pubs.rsc.org/en/content/articlepdf/{year}/ra/{article_id}"
        if download_pdf(pdf_url, filepath, f"RSC ({year})"):
            return True
        time.sleep(1)
    return False


def try_wiley(ref, filepath):
    """Strategy 8: Wiley open access."""
    doi = ref.get('doi', '')
    url = ref.get('url', '')
    if not doi and 'wiley.com' not in url:
        return False
    if doi:
        pdf_url = f"https://onlinelibrary.wiley.com/doi/pdfdirect/{doi}"
        if download_pdf(pdf_url, filepath, "Wiley"):
            return True
        time.sleep(1)
        pdf_url = f"https://onlinelibrary.wiley.com/doi/pdf/{doi}"
        if download_pdf(pdf_url, filepath, "Wiley alt"):
            return True
    return False


def try_elsevier_oa(ref, filepath):
    """Strategy 9: Elsevier OA via ScienceDirect /pdfft endpoint."""
    url = ref.get('url', '')
    if 'sciencedirect.com' not in url:
        return False
    m = re.search(r'pii/(S\d+)', url)
    if m:
        pii = m.group(1)
        pdf_url = f"https://www.sciencedirect.com/science/article/pii/{pii}/pdfft"
        return download_pdf(pdf_url, filepath, "Elsevier OA")
    return False


def try_arxiv_search(ref, filepath):
    """Strategy 10: Search arXiv by title (last resort)."""
    title = ref.get('title', ref.get('full_title', ''))
    if not title:
        return False
    arxiv_id = search_arxiv_by_title(title)
    if arxiv_id:
        print(f"    Found on arXiv: {arxiv_id}")
        ref['found_arxiv_id'] = arxiv_id
        pdf_url = f"https://arxiv.org/pdf/{arxiv_id}"
        return download_pdf(pdf_url, filepath, "arXiv search")
    return False


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

# Ordered list of strategies to try
STRATEGIES = [
    ('Direct PDF',       try_direct_pdf),
    ('bioRxiv/medRxiv',  try_biorxiv),
    ('PMC',              try_pmc),
    ('MDPI',             try_mdpi),
    ('Nature/Springer',  try_nature_springer),
    ('PLoS',             try_plos),
    ('RSC',              try_rsc),
    ('Wiley',            try_wiley),
    ('Elsevier OA',      try_elsevier_oa),
    ('arXiv search',     try_arxiv_search),
]


def search_and_download(info_json_path, output_dir, missing_json_path):
    with open(info_json_path, 'r', encoding='utf-8') as f:
        ref_info = json.load(f)

    os.makedirs(output_dir, exist_ok=True)

    # Process references without arXiv IDs (or all if no arXiv IDs exist)
    non_arxiv = [r for r in ref_info if not r.get('arxiv_id')]
    if not non_arxiv:
        non_arxiv = ref_info  # process all if none have arXiv IDs
    print(f"Non-arXiv references to process: {len(non_arxiv)}")

    downloaded = []
    still_missing = []

    for ref in non_arxiv:
        idx = ref.get('index', '?')
        title = ref.get('title', ref.get('full_title', ''))[:60]
        try:
            print(f"\n[{idx}] {title.encode('ascii','replace').decode()}")
        except Exception:
            print(f"\n[{idx}] [title encoding error]")

        # Build filename
        safe_title = sanitize_filename(ref.get('title', ref.get('full_title', f'ref_{idx}')))
        filename = f"{idx:02d}_{safe_title}.pdf" if isinstance(idx, int) else f"{idx}_{safe_title}.pdf"
        filepath = os.path.join(output_dir, filename)

        # Skip if already have a valid PDF
        if is_valid_pdf(filepath):
            print(f"  Already downloaded: {filename[:60]}")
            downloaded.append(ref)
            continue

        # Try each strategy in order
        success = False
        for strat_name, strat_fn in STRATEGIES:
            success = strat_fn(ref, filepath)
            if success:
                downloaded.append(ref)
                break
            # Small delay between strategies hitting different hosts
            time.sleep(0.5)

        if not success:
            still_missing.append(ref)
            print(f"  -> Not downloaded (all strategies exhausted)")

        time.sleep(1)  # General rate limiting

    # Summary
    print(f"\n{'='*60}")
    print(f"Multi-Source Download Summary")
    print(f"{'='*60}")
    print(f"Processed:  {len(non_arxiv)}")
    print(f"Downloaded: {len(downloaded)}")
    print(f"Missing:    {len(still_missing)}")

    # Save results
    extra_path = os.path.join(os.path.dirname(info_json_path), 'oa_download_results.json')
    with open(extra_path, 'w', encoding='utf-8') as f:
        json.dump({'downloaded': [r.get('index') for r in downloaded],
                   'missing': [r.get('index') for r in still_missing]},
                  f, indent=2, ensure_ascii=False)

    with open(missing_json_path, 'w', encoding='utf-8') as f:
        json.dump(still_missing, f, indent=2, ensure_ascii=False)

    print(f"\nStill missing ({len(still_missing)}):")
    for ref in still_missing:
        try:
            t = ref.get('title', ref.get('full_title', ''))[:60]
            print(f"  [{ref.get('index','?')}] {t.encode('ascii','replace').decode()}")
        except Exception:
            print(f"  [{ref.get('index','?')}] [encoding error]")


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python search_non_arxiv.py <info_json_path> <output_dir> <missing_json_path>")
        sys.exit(1)
    search_and_download(sys.argv[1], sys.argv[2], sys.argv[3])
