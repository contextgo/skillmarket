"""
Download arXiv papers as PDFs with proper validation.
Usage: python download_arxiv.py <info_json_path> <output_dir>
"""
import urllib.request
import json
import os
import sys
import time
import ssl
import re

ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

MIN_PDF_SIZE = 5000  # 5KB minimum for a valid PDF


def sanitize_filename(name, max_len=80):
    invalid_chars = '<>:"/\\|?*\u2013\u2014\u2018\u2019\u201c\u201d'
    for c in invalid_chars:
        name = name.replace(c, '_')
    name = re.sub(r'\s+', '_', name)
    name = re.sub(r'_+', '_', name)
    if len(name) > max_len:
        name = name[:max_len].rstrip('_')
    return name


def is_valid_pdf(filepath):
    """Check that a file exists, is large enough, and has a PDF header."""
    if not os.path.exists(filepath):
        return False
    if os.path.getsize(filepath) < MIN_PDF_SIZE:
        return False
    try:
        with open(filepath, 'rb') as f:
            header = f.read(5)
        return header == b'%PDF-'
    except Exception:
        return False


def download_arxiv(info_json_path, output_dir):
    with open(info_json_path, 'r', encoding='utf-8') as f:
        ref_info = json.load(f)

    os.makedirs(output_dir, exist_ok=True)

    # Collect all references with arXiv IDs
    arxiv_refs = [r for r in ref_info if r.get('arxiv_id')]
    print(f"Found {len(arxiv_refs)} references with arXiv IDs")

    downloaded = []
    failed = []

    for i, ref in enumerate(arxiv_refs):
        arxiv_id = ref['arxiv_id']
        clean_id = re.sub(r'v\d+$', '', arxiv_id) or arxiv_id

        # Build filename: {index:02d}_{FirstAuthor}_{Year}_{Title}.pdf
        title = sanitize_filename(ref.get('title', ref.get('full_title', '')))
        authors = ref.get('authors', '')
        first_author = authors.split(',')[0].strip().split()[-1] if authors else 'unknown'
        first_author = sanitize_filename(first_author, 20)
        year = ref.get('year', '0000')
        idx = ref.get('index', i + 1)
        filename = f"{idx:02d}_{first_author}_{year}_{title}.pdf"
        filepath = os.path.join(output_dir, filename)

        # Skip if already downloaded AND valid
        if is_valid_pdf(filepath):
            print(f"[{i+1}/{len(arxiv_refs)}] SKIP (valid): {filename[:60]}")
            downloaded.append({'arxiv_id': arxiv_id, 'filename': filename, 'status': 'exists'})
            continue

        url = f"https://arxiv.org/pdf/{clean_id}"
        try:
            print(f"[{i+1}/{len(arxiv_refs)}] Downloading: {arxiv_id} -> {filename[:60].encode('ascii','replace').decode()}")
        except Exception:
            print(f"[{i+1}/{len(arxiv_refs)}] Downloading: {arxiv_id}")

        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'Mozilla/5.0 (research reference downloader)'
            })
            with urllib.request.urlopen(req, context=ssl_context, timeout=60) as response:
                data = response.read()

                # Validate: must be a real PDF
                if data[:5] == b'%PDF-' and len(data) >= MIN_PDF_SIZE:
                    with open(filepath, 'wb') as f:
                        f.write(data)
                    downloaded.append({'arxiv_id': arxiv_id, 'filename': filename, 'status': 'downloaded'})
                    print(f"  OK ({len(data)//1024} KB)")
                elif data[:5] != b'%PDF-':
                    failed.append({'arxiv_id': arxiv_id, 'filename': filename, 'error': 'not a PDF (HTML/redirect)'})
                    print(f"  FAILED: response is not a PDF (got {data[:20]})")
                else:
                    failed.append({'arxiv_id': arxiv_id, 'filename': filename, 'error': f'too small ({len(data)} bytes)'})
                    print(f"  FAILED: PDF too small ({len(data)} bytes)")
        except Exception as e:
            failed.append({'arxiv_id': arxiv_id, 'filename': filename, 'error': str(e)[:100]})
            print(f"  FAILED: {str(e)[:80]}")

        time.sleep(3)  # Rate limit

    print(f"\n=== arXiv Download Summary ===")
    print(f"Downloaded: {len(downloaded)}")
    print(f"Failed: {len(failed)}")

    results_path = os.path.join(os.path.dirname(info_json_path), 'arxiv_download_results.json')
    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump({'downloaded': downloaded, 'failed': failed}, f, indent=2, ensure_ascii=False)

    if failed:
        print("\nFailed downloads:")
        for item in failed:
            print(f"  {item['arxiv_id']}: {item['error'][:60]}")


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python download_arxiv.py <info_json_path> <output_dir>")
        sys.exit(1)
    download_arxiv(sys.argv[1], sys.argv[2])
