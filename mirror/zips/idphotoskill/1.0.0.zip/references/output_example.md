# 输出格式参考

## 成功响应示例

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "orderId": "ORD202604150001",
    "specificationName": "二代居民身份证"
  }
}
```

## 失败响应示例

```json
{
  "code": 401,
  "msg": "签名校验失败"
}
```

```json
{
  "code": 500,
  "msg": "图片格式不支持"
}
```

---

## 本地记录文件

调用成功后，脚本会在输出目录生成以下文件：

### 1. 检测结果 JSON

文件名：`原图名_result.json`

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "orderId": "ORD202604150001",
    "specificationName": "中国护照照片"
  }
}
```

### 2. 调用记录 CSV

文件名：`order_log.csv`

```csv
"文件名","orderId","规格名称","时间"
"photo1.jpg","ORD202604150001","中国护照照片","2026-04-15 10:00:00"
"photo2.jpg","ORD202604150002","中国护照照片","2026-04-15 10:01:00"
```

---

## 检测项说明（needEachDetectionItem=1 时）

返回的 data 中增加 `detectionItems` 字段：

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "orderId": "ORD202604150001",
    "specificationName": "中国护照照片",
    "detectionItems": {
      "background": { "pass": true, "score": 95 },
      "face": { "pass": true, "score": 88 },
      "lighting": { "pass": true, "score": 90 },
      "posture": { "pass": false, "score": 60, "reason": "头部倾斜过大" }
    }
  }
}
```
