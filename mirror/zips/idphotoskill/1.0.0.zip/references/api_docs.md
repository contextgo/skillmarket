# API 协议参考

---

## 接口一：提交照片检测

### 基本信息

| 项目 | 值 |
|------|-----|
| 请求地址 | `https://www.idphotoplus.com/api/thirdParty/photo/upload` |
| 请求方式 | POST |
| Content-Type | `application/json; charset=utf-8` |

### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `appKey` | String | ✅ | AppKey |
| `timestamp` | Long | ✅ | 时间戳（秒级 Unix 时间） |
| `nonce` | String | ✅ | 随机字符串（12位以上字母数字） |
| `signature` | String | ✅ | 签名（MD5 + ASCII排序，见下方） |
| `specificationId` | Integer | ✅ | 规格ID |
| `image` | String | ✅ | 照片的 Base64 字符串（不含前缀） |
| `hasHighDefinition` | Integer | ❌ | `1` = 高清输出 |
| `needEachDetectionItem` | Integer | ❌ | `1` = 生成检测项详情 |
| `notifyUrl` | String | ❌ | 异步回调地址 |

### 响应

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "orderId": "ORD202604150001",
    "specificationName": "规格名称"
  }
}
```

---

## 接口二：获取合格照片

> 异步轮询，建议 ≥1 秒请求一次。

| 项目 | 值 |
|------|-----|
| 请求地址 | `https://www.idphotoplus.com/api/thirdParty/photo/getPhoto` |
| 请求方式 | POST |

### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `appKey` | String | ✅ | AppKey |
| `timestamp` | Long | ✅ | 时间戳 |
| `nonce` | String | ✅ | 随机字符串 |
| `signature` | String | ✅ | 签名 |
| `orderId` | String | ✅ | 检测单号 |

### 响应

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "orderId": "ORD202604150001",
    "thumbnailPhoto": "iVBORw0KGgoAAAANS...（Base64）",
    "processPhoto": "iVBORw0KGgoAAAANS...（Base64）",
    "printTemplate": "iVBORw0KGgoAAAANS...（Base64）",
    "flag": 1,
    "reason": ""
  }
}
```

### flag 状态

| flag | 说明 |
|------|------|
| `-1` | 检测中，继续轮询 |
| `0` | 不合格，`reason` 说明原因 |
| `1` | 合格，`processPhoto` 为处理后照片 |
| `2` | 预览，初检合格 |

---

## 签名算法（MD5）

```
Step 1: 所有请求参数（除 signature 外）按 ASCII 码从小到大排序
Step 2: URL 键值对格式拼接（key1=value1&key2=value2...）
Step 3: 末尾拼接 &appSecret=你的AppSecret
Step 4: MD5 摘要
Step 5: 结果所有字符转为大写
```

**PowerShell 示例：**
```powershell
$bodyParams = @{
    appKey    = $AppKey
    timestamp = $timestamp
    nonce     = $nonce
    orderId   = $oid
}
$sortedKeys = $bodyParams.Keys | Sort-Object
$pairs = $sortedKeys | ForEach-Object { "$_=$($bodyParams[$_])" }
$stringA = ($pairs -join "&") + "&appSecret=$AppSecret"
$md5 = [System.Security.Cryptography.MD5]::Create()
$bytes = [System.Text.Encoding]::UTF8.GetBytes($stringA)
$hash = $md5.ComputeHash($bytes)
$signature = ([BitConverter]::ToString($hash) -replace '-', '').ToUpper()
```

---

## 响应码说明

| code | 说明 |
|------|------|
| `200` | 请求成功 |
| `401` | 无权限访问（AppKey/AppSecret 错误或已过期） |
| `500` | 服务端异常 |


