# 办证照片检测与优化 - 使用指南

> 适用于多规格证件照的质量检测与自动优化。

---

## 一、安装配置

### Step 1: 配置凭证

编辑 `assets/config.json`，填入你的 AppKey 和 AppSecret。

### Step 2: 安装依赖

```bash
pip install requests
```

---

## 二、使用方式

### 单张检测

```bash
python scripts\idphoto.py "D:\photo.jpg" "身份证"
python scripts\idphoto.py "D:\photo.jpg" "一寸"
python scripts\idphoto.py "D:\photo.jpg" 607
```

### 批量检测

```bash
python scripts\idphoto-batch.py "D:\photos文件夹" "身份证"
python scripts\idphoto-batch.py "D:\photos文件夹" "一寸"
```

---

## 三、支持的输入格式

| 输入方式 | 示例 | 说明 |
|----------|------|------|
| **规格名称** | `身份证` `一寸` `二寸` | 自然语言匹配 |
| **规格ID** | `607` `101` `102` | 直接指定数字ID |
| **交互选择** | （不填参数） | 显示菜单选择 |

---

## 四、输出结构

```
证照检测结果_日期/
├── 合格/              ← API处理后的照片
└── 不合格/            ← 原图（方便复查重拍）
```

---

## 五、检测状态说明

| flag | 含义 | 处理方式 |
|------|------|---------|
| `1` | 合格 | 保存处理后照片到 合格/ |
| `0` | 不合格 | 复制原图到 不合格/，显示原因 |

---

## 六、常见问题

**Q: flag=0 不合格？**
> `reason` 说明原因，重新拍照后再次提交。

**Q: 无法识别规格？**
> 可省略参数，脚本会显示完整菜单供选择。

**Q: 返回 code 401？**
> AppKey/AppSecret 错误或过期，联系证照家客服。
