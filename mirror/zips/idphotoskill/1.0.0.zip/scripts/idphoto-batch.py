#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
证照批量检测 - Python 版本 v0.04
新增：多规格支持 + 自然语言匹配 + 交互式菜单
依赖: pip install requests
"""
import os
import sys
import json
import time
import base64
import hashlib
import random
import string
import shutil
import requests
from pathlib import Path
from datetime import datetime

# ============================================
# 规格管理模块（与单张版共用）
# ============================================
def load_specs():
    """加载规格配置"""
    config_path = Path(__file__).parent.parent / "assets" / "specs.json"
    if not config_path.exists():
        return {"规格列表": []}
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def match_spec(spec_input, specs_data):
    """根据输入匹配规格ID - 精确匹配优先"""
    specs = specs_data.get("规格列表", [])
    
    # 空输入：返回交互选择
    if not spec_input or spec_input.strip() == "":
        return None, None
    
    spec_input = str(spec_input).strip()
    
    # 1. 直接数字ID匹配
    if spec_input.isdigit():
        spec_id = int(spec_input)
        for spec in specs:
            if spec["id"] == spec_id:
                return spec_id, spec["名称"]
        return spec_id, f"ID:{spec_id}"
    
    spec_input_lower = spec_input.lower()
    
    # 2. 精确匹配关键词（完全相等）
    for spec in specs:
        for keyword in spec.get("关键词", []):
            if spec_input_lower == keyword.lower():
                return spec["id"], spec["名称"]
    
    # 3. 关键词包含匹配
    best_match = None
    best_score = 0
    
    for spec in specs:
        # 检查关键词
        for keyword in spec.get("关键词", []):
            if spec_input_lower in keyword.lower():
                score = len(keyword)
                if score > best_score:
                    best_score = score
                    best_match = spec
        
        # 检查规格名称
        if spec_input_lower in spec["名称"].lower():
            score = len(spec["名称"]) + 0.5
            if score > best_score:
                best_score = score
                best_match = spec
    
    if best_match:
        return best_match["id"], best_match["名称"]
    
    return None, None

def show_spec_menu(specs_data):
    """显示规格选择菜单"""
    specs = specs_data.get("规格列表", [])
    
    print("\n" + "=" * 50)
    print("  请选择证件照规格")
    print("=" * 50)
    print()
    
    for i, spec in enumerate(specs, 1):
        keywords = " / ".join(spec.get("关键词", [])[:3])
        print(f"  [{i}] {spec['名称']} ({spec['尺寸像素']})")
        print(f"      关键词: {keywords}")
        print()
    
    print(f"  [0] 退出")
    print("=" * 50)
    
    while True:
        choice = input("\n请输入编号或直接输入规格名称(如身份证/一寸): ").strip()
        
        if choice == "0":
            return None
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(specs):
                return specs[idx]["id"]
        
        spec_id, spec_name = match_spec(choice, specs_data)
        if spec_id:
            return spec_id
        
        print("  无法识别，请重新输入")

def confirm_spec(spec_name, spec_id, specs_data):
    """确认规格是否正确"""
    spec_info = None
    for s in specs_data.get("规格列表", []):
        if s["id"] == spec_id:
            spec_info = s
            break
    
    pixel_size = spec_info["尺寸像素"] if spec_info else ""
    usage = spec_info.get("用途", "") if spec_info else ""
    
    print("\n" + "-" * 40)
    print(f"  规格: {spec_name}")
    print(f"  ID:   {spec_id}")
    print(f"  尺寸: {pixel_size}" + (f"（{usage}）" if usage else ""))
    print("-" * 40)
    
    answer = input("\n确认使用此规格? (Y/n): ").strip().lower()
    return answer in ("y", "", "yes")

# ============================================
# API 调用模块
# ============================================
def load_config():
    """加载配置"""
    config_path = Path(__file__).parent.parent / "assets" / "config.json"
    if not config_path.exists():
        print(f"[错误] 配置文件不存在: {config_path}")
        sys.exit(1)

    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    if "请填入" in config.get("app_key", ""):
        print("[错误] 请先在 assets/config.json 中填入凭证")
        sys.exit(1)

    return config

def get_timestamp():
    return int(datetime.now().timestamp())

def gen_nonce(length=12):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def sign(params, app_secret):
    """生成签名"""
    sorted_keys = sorted(params.keys())
    pairs = [f"{k}={params[k]}" for k in sorted_keys]
    sign_str = '&'.join(pairs) + f'&appSecret={app_secret}'
    return hashlib.md5(sign_str.encode()).hexdigest().upper()

def read_image_base64(image_path):
    """读取图片并转为 Base64"""
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')

def upload_photo(image_path, config, spec_id):
    """上传照片"""
    url = config["api_base_url"] + config["api_path"]
    timestamp = get_timestamp()
    nonce = gen_nonce()
    img_data = read_image_base64(image_path)

    params_for_sign = {
        'appKey': config['app_key'],
        'timestamp': timestamp,
        'nonce': nonce,
        'specificationId': spec_id,
        'detectionMode': 0,
        'image': img_data,
    }
    signature = sign(params_for_sign, config['app_secret'])

    json_data = {
        'appKey': config['app_key'],
        'timestamp': timestamp,
        'nonce': nonce,
        'signature': signature,
        'specificationId': spec_id,
        'detectionMode': 0,
        'image': img_data,
    }

    response = requests.post(url, json=json_data, timeout=60)
    result = response.json()

    if result.get("code") == 200:
        return result["data"]["orderId"]
    else:
        print(f"    [错误] 上传失败: code={result.get('code')}, msg={result.get('msg')}")
        return None

def get_result(order_id, config, max_wait=30):
    """轮询获取结果"""
    url = config["api_base_url"] + "/api/thirdParty/photo/getPhoto"

    for i in range(max_wait):
        time.sleep(1.5 if i < 3 else 1)
        timestamp = get_timestamp()
        nonce = gen_nonce()

        params_for_sign = {
            'appKey': config['app_key'],
            'timestamp': timestamp,
            'nonce': nonce,
            'orderId': order_id,
        }
        signature = sign(params_for_sign, config['app_secret'])

        response = requests.post(url, json={
            'appKey': config['app_key'],
            'timestamp': timestamp,
            'nonce': nonce,
            'signature': signature,
            'orderId': order_id
        }, timeout=30)

        result = response.json()
        if result.get("code") == 200:
            flag = result["data"].get("flag", -1)
            if flag == 1:
                return result["data"]
            elif flag == 0:
                reason = result["data"].get("reason", "不合格")
                return {"flag": 0, "reason": reason}

    return None

def process_single(image_path, config, output_dir, spec_id, spec_name):
    """处理单张照片"""
    image_name = Path(image_path).stem
    print(f"\n[{image_name}]")
    
    # 上传
    order_id = upload_photo(image_path, config, spec_id)
    if not order_id:
        print(f"    上传失败，跳过")
        return False
    
    # 获取结果
    result = get_result(order_id, config)
    
    os.makedirs(os.path.join(output_dir, "合格"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "不合格"), exist_ok=True)
    
    if result and result.get("flag") == 1:
        # 合格
        output_name = f"{image_name}.jpg"
        output_path = os.path.join(output_dir, "合格", output_name)
        
        try:
            if result.get("processPhoto"):
                img_data = base64.b64decode(result["processPhoto"])
            elif result.get("thumbnailPhoto"):
                img_data = base64.b64decode(result["thumbnailPhoto"])
            else:
                print(f"    未找到处理后照片")
                return False
            
            with open(output_path, 'wb') as f:
                f.write(img_data)
            print(f"    合格")
            return True
        except Exception as e:
            print(f"    保存失败: {e}")
            return False
    else:
        # 不合格
        reason = result.get("reason", "不合格") if result else "获取结果超时"
        print(f"    不合格: {reason}")
        
        fail_path = os.path.join(output_dir, "不合格", Path(image_path).name)
        shutil.copy2(image_path, fail_path)
        return False

def get_image_files(folder):
    """获取文件夹下所有支持的图片"""
    supported = ['.jpg', '.jpeg', '.png', '.bmp']
    images = []
    for f in os.listdir(folder):
        if Path(f).suffix.lower() in supported:
            images.append(os.path.join(folder, f))
    return sorted(images)

def main():
    if len(sys.argv) < 2:
        print("=" * 50)
        print("  证照批量检测 v0.04 - 支持自然语言匹配")
        print("=" * 50)
        print("\n用法:")
        print("  python idphoto-batch.py <文件夹路径> [规格]")
        print()
        print("规格示例:")
        print("  python idphoto-batch.py D:\\photos 身份证")
        print("  python idphoto-batch.py D:\\photos 一寸")
        print("  python idphoto-batch.py D:\\photos 607")
        print("  python idphoto-batch.py D:\\photos   # 显示菜单选择")
        print("\n支持的规格: 身份证/一寸/二寸/护照/驾驶证 等")
        sys.exit(1)

    folder_path = sys.argv[1]
    if not os.path.isdir(folder_path):
        print(f"[错误] 文件夹不存在: {folder_path}")
        sys.exit(1)

    config = load_config()
    specs_data = load_specs()

    # 解析规格参数
    spec_input = sys.argv[2] if len(sys.argv) >= 3 else None
    spec_id, spec_name = match_spec(spec_input, specs_data)
    
    if spec_id is None:
        print(f"\n无法识别规格: {spec_input}")
        spec_id = show_spec_menu(specs_data)
        if spec_id is None:
            print("已取消")
            sys.exit(0)
        for spec in specs_data.get("规格列表", []):
            if spec["id"] == spec_id:
                spec_name = spec["名称"]
                break
        if not spec_name:
            spec_name = f"ID:{spec_id}"

    # 确认规格
    if not confirm_spec(spec_name, spec_id, specs_data):
        print("已取消")
        sys.exit(0)

    # 获取图片列表
    images = get_image_files(folder_path)
    if not images:
        print(f"[错误] 文件夹中没有找到支持的图片文件")
        sys.exit(1)

    # 生成输出目录
    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M")
    output_dir = os.path.join(folder_path, f"证照检测结果_{timestamp}")

    print("\n" + "=" * 50)
    print("  证照批量检测 v0.04")
    print("=" * 50)
    print(f"\n  输入目录: {folder_path}")
    print(f"  输出目录: {output_dir}")
    print(f"  规格: {spec_name} (ID: {spec_id})")
    print(f"  图片数量: {len(images)}")

    passed = 0
    failed = 0

    for i, img_path in enumerate(images, 1):
        print(f"\n[{i}/{len(images)}]", end="")
        if process_single(img_path, config, output_dir, spec_id, spec_name):
            passed += 1
        else:
            failed += 1

    print("\n" + "=" * 50)
    print("  批量处理完成")
    print("=" * 50)
    print(f"  总计: {len(images)}")
    print(f"  合格: {passed} -> {output_dir}\\合格")
    print(f"  不合格: {failed} -> {output_dir}\\不合格")
    print(f"\n结果目录: {output_dir}")

if __name__ == "__main__":
    main()
