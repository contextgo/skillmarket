#!/usr/bin/env node

/**
 * 内容生成模块
 * 功能：为每节课生成详细的 Markdown 内容
 */

const fs = require('fs');
const path = require('path');

/**
 * 生成所有课时内容
 * @param {Object} repoInfo - 仓库信息
 * @param {Object} courseOutline - 课程大纲
 * @returns {Promise<Array>} 所有课时文件路径
 */
async function generateAllLessons(repoInfo, courseOutline) {
  const lessonPaths = [];
  
  for (const lesson of courseOutline.lessons) {
    const lessonPath = await generateLessonContent(repoInfo, courseOutline, lesson);
    lessonPaths.push(lessonPath);
    console.log(`  ✅ 已生成：第${lesson.lessonNumber}课 - ${lesson.title}`);
  }
  
  return lessonPaths;
}

/**
 * 生成单节课内容
 * @param {Object} repoInfo - 仓库信息
 * @param {Object} courseOutline - 课程大纲
 * @param {Object} lesson - 课时信息
 * @returns {Promise<string>} 文件路径
 */
async function generateLessonContent(repoInfo, courseOutline, lesson) {
  const templatePath = path.join(__dirname, '../templates/lesson-content.md');
  let template = fs.readFileSync(templatePath, 'utf8');
  
  // 生成生动比喻
  const analogy = generateAnalogy(repoInfo, lesson);
  
  // 生成代码示例
  const codeExample = generateCodeExample(repoInfo, lesson);
  
  // 生成内容
  const content = template
    .replace(/{{lessonNumber}}/g, lesson.lessonNumber)
    .replace(/{{lessonTitle}}/g, lesson.title)
    .replace(/{{objective1}}/g, `理解${lesson.title}的核心概念`)
    .replace(/{{objective2}}/g, `掌握${lesson.title}的关键用法`)
    .replace(/{{objective3}}/g, `能够完成相关实践作业`)
    .replace(/{{estimatedTime}}/g, lesson.estimatedTime)
    .replace(/{{concept1Name}}/g, `${lesson.title}核心概念`)
    .replace(/{{concept1Explanation}}/g, generateConceptExplanation(repoInfo, lesson))
    .replace(/{{concept2Name}}/g, '关键 API/接口')
    .replace(/{{concept2Explanation}}/g, '详细讲解关键 API 的使用方法和参数说明')
    .replace(/{{analogy}}/g, analogy)
    .replace(/{{codeFilePath}}/g, `待分析（根据${repoInfo.repo}源码）`)
    .replace(/{{language}}/g, repoInfo.language.toLowerCase() || 'javascript')
    .replace(/{{codeExample}}/g, codeExample)
    .replace(/{{codeAnalysis}}/g, '逐行解析代码逻辑和设计思路')
    .replace(/{{assignment1Title}}/g, lesson.assignment?.title || `第${lesson.lessonNumber}课实践`)
    .replace(/{{assignment1Requirement}}/g, lesson.assignment?.requirements?.join('\n') || '完成课堂示例')
    .replace(/{{assignment2Title}}/g, '进阶挑战')
    .replace(/{{assignment2Description}}/g, '尝试阅读相关源码并提出优化建议')
    .replace(/{{commonMistakes}}/g, generateCommonMistakes(lesson))
    .replace(/{{link1}}/g, repoInfo.url)
    .replace(/{{link2}}/g, `${repoInfo.url}/issues`)
    .replace(/{{nextLessonPreview}}/g, `下节课：${courseOutline.lessons[lesson.lessonNumber]?.title || '综合实战'}`);
  
  // 保存文件
  const repoDir = path.join(process.env.HOME, `openclaw/workspace/github-learning/${repoInfo.fullName.replace('/', '-')}`);
  const lessonsDir = path.join(repoDir, 'lessons');
  fs.mkdirSync(lessonsDir, { recursive: true });
  
  const safeTitle = lesson.title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '-');
  const lessonPath = path.join(lessonsDir, `lesson-${String(lesson.lessonNumber).padStart(2, '0')}-${safeTitle}.md`);
  fs.writeFileSync(lessonPath, content, 'utf8');
  
  return lessonPath;
}

/**
 * 生成生动比喻
 */
function generateAnalogy(repoInfo, lesson) {
  const analogies = [
    `学习这个项目就像学习做菜：${lesson.phase === '入门' ? '先认识食材和厨具（基础概念）' : lesson.phase === '进阶' ? '学习刀工和火候（核心技巧）' : '掌握创新菜式（源码级理解）'}。`,
    `可以把这个项目想象成一个精密的钟表：每个模块就像齿轮，理解它们如何咬合运转是关键。`,
    `学习源码就像探索一座城市：先看地图（文档），再走主干道（核心代码），最后探索小巷（细节实现）。`
  ];
  return analogies[lesson.lessonNumber % analogies.length];
}

/**
 * 生成代码示例
 */
function generateCodeExample(repoInfo, lesson) {
  const examples = {
    javascript: `// 示例代码 - 根据${repoInfo.repo}实际代码调整
const example = async () => {
  // TODO: 从仓库中提取实际示例
  console.log('Hello from ${repoInfo.repo}');
};`,
    python: `# 示例代码 - 根据${repoInfo.repo}实际代码调整
def example():
    # TODO: 从仓库中提取实际示例
    print("Hello from ${repoInfo.repo}")`,
    go: `// 示例代码 - 根据${repoInfo.repo}实际代码调整
func Example() {
    // TODO: 从仓库中提取实际示例
    fmt.Println("Hello from ${repoInfo.repo}")
}`,
    default: `// 示例代码占位符
// 实际使用时需要从${repoInfo.repo}中提取真实代码
function example() {
  // TODO
}`
  };
  
  const lang = (repoInfo.language || 'default').toLowerCase();
  return examples[lang] || examples.default;
}

/**
 * 生成概念解释
 */
function generateConceptExplanation(repoInfo, lesson) {
  return `这里是${lesson.title}的核心概念讲解。

**关键点**：
1. 概念的定义和作用
2. 为什么需要这个概念
3. 如何在${repoInfo.repo}中使用

**深入理解**：
建议结合源码中的具体实现来理解这个概念。`;
}

/**
 * 生成常见误区
 */
function generateCommonMistakes(lesson) {
  return `- 误区 1：概念理解不透彻就急于写代码
- 误区 2：忽略错误处理
- 误区 3：不阅读官方文档
- 建议：每学一个概念，先理解再实践`;
}

module.exports = {
  generateAllLessons,
  generateLessonContent
};
