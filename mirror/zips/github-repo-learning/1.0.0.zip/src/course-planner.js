#!/usr/bin/env node

/**
 * 课程规划模块
 * 功能：根据用户参数生成课程大纲
 */

const fs = require('fs');
const path = require('path');

/**
 * 生成用户调研问题
 * @param {Object} repoInfo - 仓库信息
 * @returns {Array} 问题列表
 */
function generateQuestions(repoInfo) {
  return [
    {
      id: 'lessonCount',
      question: `你希望分几个课时学习 ${repoInfo.repo}？`,
      type: 'choice',
      options: [
        { value: 6, label: '6 节（快速入门，1-2 周）' },
        { value: 10, label: '10 节（系统学习，3-4 周）' },
        { value: 15, label: '15 节（深入掌握，1-2 月）' },
        { value: 'custom', label: '自定义节数' }
      ],
      suggested: 10
    },
    {
      id: 'learningDepth',
      question: '你的学习目标是什么？',
      type: 'choice',
      options: [
        { value: 'intro', label: '入门了解（会用即可）' },
        { value: 'proficient', label: '掌握应用（能独立开发项目）' },
        { value: 'expert', label: '精通原理（能阅读源码/贡献代码）' }
      ],
      suggested: 'proficient'
    },
    {
      id: 'weeklyTime',
      question: '你每周能投入多少学习时间？',
      type: 'choice',
      options: [
        { value: 5, label: '5 小时左右（轻松学习）' },
        { value: 10, label: '10 小时左右（正常进度）' },
        { value: 20, label: '20 小时以上（密集学习）' }
      ],
      suggested: 10
    },
    {
      id: 'focusArea',
      question: '你更想侧重哪个方向？',
      type: 'choice',
      options: [
        { value: 'practical', label: '实战应用（快速上手做项目）' },
        { value: 'principle', label: '原理剖析（理解底层设计）' },
        { value: 'extension', label: '源码扩展（能修改和贡献）' },
        { value: 'architecture', label: '架构设计（学习系统设计思想）' }
      ],
      suggested: 'practical'
    },
    {
      id: 'experience',
      question: `你有 ${repoInfo.language} 相关经验吗？`,
      type: 'choice',
      options: [
        { value: 'beginner', label: '新手（需要基础讲解）' },
        { value: 'intermediate', label: '有一定基础（可以直接学框架）' },
        { value: 'advanced', label: '熟练（想深入源码）' }
      ],
      suggested: 'intermediate'
    }
  ];
}

/**
 * 根据用户参数生成课程大纲
 * @param {Object} repoInfo - 仓库信息
 * @param {Object} userParams - 用户参数
 * @returns {Promise<Object>} 课程大纲对象
 */
async function generateOutline(repoInfo, userParams) {
  const { lessonCount, learningDepth, weeklyTime, focusArea, experience } = userParams;
  
  // 计算学习周期
  const totalHours = lessonCount * 3; // 每节课约 3 小时
  const weeks = Math.ceil(totalHours / weeklyTime);
  
  // 根据深度和经验生成课程主题
  const lessonThemes = generateLessonThemes(repoInfo, lessonCount, learningDepth, focusArea, experience);
  
  const outline = {
    repoName: repoInfo.fullName,
    repoUrl: repoInfo.url,
    totalLessons: lessonCount,
    learningDepth,
    weeklyTime,
    focusArea,
    experience,
    estimatedPeriod: `${weeks} 周`,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + weeks * 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    courseGoals: generateCourseGoals(learningDepth, focusArea),
    prerequisites: generatePrerequisites(repoInfo.language, experience),
    learningOutcomes: generateLearningOutcomes(learningDepth, focusArea),
    lessons: lessonThemes
  };
  
  return outline;
}

/**
 * 生成课程主题列表
 */
function generateLessonThemes(repoInfo, count, depth, focus, experience) {
  const themes = [];
  
  // 基础课程结构
  const baseStructure = [
    { phase: '入门', ratio: 0.3 },
    { phase: '进阶', ratio: 0.4 },
    { phase: '深入', ratio: 0.3 }
  ];
  
  // 根据深度调整
  if (depth === 'intro') {
    baseStructure[0].ratio = 0.6;
    baseStructure[1].ratio = 0.3;
    baseStructure[2].ratio = 0.1;
  } else if (depth === 'expert') {
    baseStructure[0].ratio = 0.2;
    baseStructure[1].ratio = 0.3;
    baseStructure[2].ratio = 0.5;
  }
  
  // 分配课时
  let lessonNum = 1;
  baseStructure.forEach(({ phase, ratio }) => {
    const phaseLessons = Math.floor(count * ratio);
    for (let i = 0; i < phaseLessons && lessonNum <= count; i++) {
      themes.push({
        lessonNumber: lessonNum,
        phase,
        title: generateLessonTitle(repoInfo, lessonNum, phase, focus),
        estimatedTime: 180, // 分钟
        topics: [],
        assignment: generateAssignmentTemplate(lessonNum, phase)
      });
      lessonNum++;
    }
  });
  
  // 确保课时数匹配
  while (themes.length < count) {
    themes.push({
      lessonNumber: themes.length + 1,
      phase: '实践',
      title: `综合实战 ${themes.length - count + 2}`,
      estimatedTime: 240,
      topics: ['项目实战'],
      assignment: { title: '完成一个完整的小项目', requirements: [] }
    });
  }
  
  return themes.slice(0, count);
}

/**
 * 生成课程标题
 */
function generateLessonTitle(repoInfo, num, phase, focus) {
  const introTitles = [
    '环境搭建与 Hello World',
    '核心概念快速了解',
    '第一个完整示例',
    '基础功能实战'
  ];
  
  const advancedTitles = [
    '核心模块深入解析',
    '关键源码剖析',
    '最佳实践与设计模式',
    '性能优化技巧'
  ];
  
  const expertTitles = [
    '架构设计思想',
    '源码贡献指南',
    '扩展与定制开发',
    '源码级问题调试'
  ];
  
  if (phase === '入门') return introTitles[(num - 1) % introTitles.length];
  if (phase === '进阶') return advancedTitles[(num - 1) % advancedTitles.length];
  return expertTitles[(num - 1) % expertTitles.length];
}

/**
 * 生成作业模板
 */
function generateAssignmentTemplate(num, phase) {
  return {
    title: `第${num}课实践作业`,
    requirements: [
      '完成课堂示例代码',
      '记录学习心得',
      '解决至少 1 个实际问题'
    ],
    deliverable: '代码 + 文档',
    estimatedTime: 60
  };
}

/**
 * 生成课程目标
 */
function generateCourseGoals(depth, focus) {
  const goals = {
    intro: '能够使用本项目完成基础功能开发',
    proficient: '能够独立使用本项目进行生产级开发，理解核心概念',
    expert: '能够阅读源码、调试问题、贡献代码，理解架构设计思想'
  };
  
  const focusAdditions = {
    practical: '，重点掌握实战应用技巧',
    principle: '，重点理解底层原理',
    extension: '，重点掌握扩展开发能力',
    architecture: '，重点学习架构设计思想'
  };
  
  return (goals[depth] || goals.proficient) + (focusAdditions[focus] || '');
}

/**
 * 生成前置要求
 */
function generatePrerequisites(language, experience) {
  const base = `${language} 编程基础`;
  const additions = {
    beginner: '，建议先学习基础语法',
    intermediate: '，了解常用库和框架',
    advanced: '，有实际项目经验'
  };
  return base + (additions[experience] || additions.intermediate);
}

/**
 * 生成学习成果
 */
function generateLearningOutcomes(depth, focus) {
  return [
    '理解项目的核心设计理念',
    '掌握主要 API 和使用方法',
    '能够独立开发相关功能',
    '具备阅读源码的能力',
    '能够解决常见问题'
  ];
}

/**
 * 保存课程大纲到文件
 * @param {Object} outline - 课程大纲对象
 * @returns {Promise<string>} 文件路径
 */
async function saveOutline(outline) {
  const templatePath = path.join(__dirname, '../templates/course-outline.md');
  let template = fs.readFileSync(templatePath, 'utf8');
  
  // 生成课时安排表格
  const lessonSchedule = outline.lessons.map(l => 
    `| 第${l.lessonNumber}课 | ${l.phase} | ${l.title} | ${l.estimatedTime}分钟 |`
  ).join('\n');
  
  const content = template
    .replace(/{{repoName}}/g, outline.repoName)
    .replace(/{{learningDepth}}/g, outline.learningDepth)
    .replace(/{{totalLessons}}/g, outline.totalLessons)
    .replace(/{{estimatedPeriod}}/g, outline.estimatedPeriod)
    .replace(/{{weeklyTime}}/g, `${outline.weeklyTime}小时`)
    .replace(/{{courseGoals}}/g, outline.courseGoals)
    .replace(/{{prerequisites}}/g, outline.prerequisites)
    .replace(/{{lessonSchedule}}/g, `| 课时 | 阶段 | 主题 | 时长 |\n|------|------|------|------|\n${lessonSchedule}`)
    .replace(/{{learningOutcomes}}/g, outline.learningOutcomes.map(o => `- ${o}`).join('\n'))
    .replace(/{{startDate}}/g, outline.startDate)
    .replace(/{{endDate}}/g, outline.endDate);
  
  const repoDir = path.join(process.env.HOME, `openclaw/workspace/github-learning/${outline.repoName.replace('/', '-')}`);
  const outlinePath = path.join(repoDir, 'course-outline.md');
  fs.writeFileSync(outlinePath, content, 'utf8');
  
  return outlinePath;
}

module.exports = {
  generateQuestions,
  generateOutline,
  saveOutline
};
