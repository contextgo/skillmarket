#!/usr/bin/env node

/**
 * github-repo-learning Skill - 主入口
 * 
 * 功能：帮助用户深入学习 GitHub 开源代码仓库
 * 流程：仓库分析 → 课程规划 → 内容生成 → 飞书同步
 */

const fs = require('fs');
const path = require('path');

// 导入功能模块
const repoAnalyzer = require('./repo-analyzer');
const coursePlanner = require('./course-planner');
const contentGenerator = require('./content-generator');
const feishuSync = require('./feishu-sync');

// 配置
const WORKSPACE_ROOT = path.join(process.env.HOME, 'openclaw/workspace/github-learning');

/**
 * 主函数：处理用户学习请求
 * @param {string} repoUrl - GitHub 仓库地址或名称
 * @param {Object} userParams - 用户参数（课时数、深度等）
 */
async function main(repoUrl, userParams = {}) {
  console.log('📚 开始 GitHub 仓库学习课程规划...\n');
  
  try {
    // 步骤 1: 分析仓库
    console.log('📊 步骤 1/5: 分析仓库...');
    const repoInfo = await repoAnalyzer.analyze(repoUrl);
    const summaryPath = await repoAnalyzer.generateSummary(repoInfo);
    console.log(`✅ 仓库摘要已保存：${summaryPath}\n`);
    
    // 步骤 2: 如果用户参数不完整，进入交互模式
    if (!userParams.complete) {
      console.log('🤔 步骤 2/5: 需要更多信息...\n');
      const questions = coursePlanner.generateQuestions(repoInfo);
      return {
        status: 'need_input',
        repoInfo,
        questions,
        nextStep: 'collect_params'
      };
    }
    
    // 步骤 3: 生成课程大纲
    console.log('📋 步骤 3/5: 生成课程大纲...');
    const courseOutline = await coursePlanner.generateOutline(repoInfo, userParams);
    const outlinePath = await coursePlanner.saveOutline(courseOutline);
    console.log(`✅ 课程大纲已保存：${outlinePath}\n`);
    
    // 步骤 4: 生成课时内容
    console.log('📝 步骤 4/5: 生成课时内容...');
    const lessonPaths = await contentGenerator.generateAllLessons(repoInfo, courseOutline);
    console.log(`✅ 已生成 ${lessonPaths.length} 节课的详细内容\n`);
    
    // 步骤 5: 同步到飞书
    console.log('📅 步骤 5/5: 同步到飞书...');
    const feishuInfo = await feishuSync.createBitable(courseOutline, userParams);
    console.log(`✅ 飞书多维表格已创建：${feishuInfo.bitableUrl}\n`);
    
    return {
      status: 'complete',
      repoInfo,
      courseOutline,
      lessonPaths,
      feishuInfo,
      summaryPath,
      outlinePath
    };
    
  } catch (error) {
    console.error('❌ 错误:', error.message);
    throw error;
  }
}

/**
 * 初始化学习目录
 * @param {string} repoName - 仓库名称
 */
function initWorkspace(repoName) {
  const safeName = repoName.replace(/[\/\\:*?"<>|]/g, '-');
  const workspacePath = path.join(WORKSPACE_ROOT, safeName);
  const lessonsPath = path.join(workspacePath, 'lessons');
  
  // 创建目录结构
  fs.mkdirSync(lessonsPath, { recursive: true });
  
  return {
    workspacePath,
    lessonsPath,
    repoName: safeName
  };
}

module.exports = {
  main,
  initWorkspace
};
