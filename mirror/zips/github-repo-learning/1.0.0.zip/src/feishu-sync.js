#!/usr/bin/env node

/**
 * 飞书同步模块
 * 功能：创建多维表格、设置字段、同步课程数据
 */

const fs = require('fs');
const path = require('path');

/**
 * 创建飞书多维表格并同步课程
 * @param {Object} courseOutline - 课程大纲
 * @param {Object} userParams - 用户参数
 * @returns {Promise<Object>} 飞书表格信息
 */
async function createBitable(courseOutline, userParams) {
  console.log('正在创建飞书多维表格...');
  
  // 这里应该调用 feishu_bitable_create_app API
  // 由于这是 Skill 脚本，实际调用由 OpenClaw 工具层处理
  // 这里生成调用指令
  
  const bitableInfo = {
    name: `${courseOutline.repoName} 学习课程`,
    description: `系统学习 ${courseOutline.repoName} 的课程规划`,
    totalLessons: courseOutline.totalLessons,
    lessons: courseOutline.lessons.map(l => ({
      lessonNumber: l.lessonNumber,
      title: l.title,
      phase: l.phase,
      estimatedTime: l.estimatedTime,
      status: '未开始',
      deadline: calculateDeadline(courseOutline.startDate, l.lessonNumber, courseOutline.totalLessons),
      assignmentStatus: '未完成'
    }))
  };
  
  // 保存同步指令文件（供 OpenClaw 主流程调用）
  const repoDir = path.join(process.env.HOME, `openclaw/workspace/github-learning/${courseOutline.repoName.replace('/', '-')}`);
  const syncCommandPath = path.join(repoDir, 'feishu-sync-command.json');
  
  const syncCommand = {
    action: 'createBitable',
    name: bitableInfo.name,
    fields: [
      { name: '课时编号', type: 'number' },
      { name: '课程主题', type: 'text' },
      { name: '学习阶段', type: 'single_select', options: ['入门', '进阶', '深入', '实践'] },
      { name: '预计时长 (分钟)', type: 'number' },
      { name: '学习状态', type: 'single_select', options: ['未开始', '进行中', '已完成'] },
      { name: '截止日期', type: 'date' },
      { name: '作业状态', type: 'single_select', options: ['未完成', '已完成'] },
      { name: '笔记链接', type: 'url' }
    ],
    records: bitableInfo.lessons.map(l => ({
      fields: {
        '课时编号': l.lessonNumber,
        '课程主题': l.title,
        '学习阶段': l.phase,
        '预计时长 (分钟)': l.estimatedTime,
        '学习状态': '未开始',
        '截止日期': l.deadline,
        '作业状态': '未完成',
        '笔记链接': ''
      }
    }))
  };
  
  fs.writeFileSync(syncCommandPath, JSON.stringify(syncCommand, null, 2), 'utf8');
  
  // 保存结果文件
  const resultPath = path.join(repoDir, 'feishu-bitable-url.txt');
  const resultContent = `飞书多维表格创建指令已生成
文件：${syncCommandPath}

请 OpenClaw 调用 feishu_bitable_create_app 和 feishu_bitable_create_record API 完成同步。

课程名称：${bitableInfo.name}
课时数量：${bitableInfo.totalLessons}
`;
  fs.writeFileSync(resultPath, resultContent, 'utf8');
  
  return {
    bitableName: bitableInfo.name,
    bitableUrl: '待创建',
    syncCommandPath,
    resultPath,
    totalRecords: bitableInfo.lessons.length
  };
}

/**
 * 计算每节课的截止日期
 */
function calculateDeadline(startDate, lessonNum, totalLessons) {
  const start = new Date(startDate);
  const totalWeeks = Math.ceil(totalLessons / 2); // 假设每周 2 节课
  const lessonWeek = Math.ceil(lessonNum / 2);
  const deadline = new Date(start);
  deadline.setDate(deadline.getDate() + (lessonWeek * 7));
  return deadline.toISOString().split('T')[0];
}

/**
 * 创建日程待办（调用飞书日历 API）
 */
async function createCalendarEvents(courseOutline, bitableId) {
  // 这里应该调用飞书日历 API
  // 生成调用指令
  const events = courseOutline.lessons.map(lesson => ({
    title: `学习：${lesson.title}`,
    startTime: calculateLessonTime(courseOutline.startDate, lesson.lessonNumber),
    duration: lesson.estimatedTime * 60 * 1000, // 转换为毫秒
    description: `第${lesson.lessonNumber}课\n\n作业：${lesson.assignment?.title || '见课程文档'}`,
    reminders: [{ minutes: 60 }] // 提前 1 小时提醒
  }));
  
  return { events };
}

/**
 * 计算课程开始时间
 */
function calculateLessonTime(startDate, lessonNum) {
  const start = new Date(startDate);
  const lessonDay = Math.floor((lessonNum - 1) / 2) * 3 + ((lessonNum - 1) % 2) * 1; // 每 3 天一节课
  const time = new Date(start);
  time.setDate(time.getDate() + lessonDay);
  time.setHours(20, 0, 0, 0); // 晚上 8 点
  return time.toISOString();
}

module.exports = {
  createBitable,
  createCalendarEvents
};
