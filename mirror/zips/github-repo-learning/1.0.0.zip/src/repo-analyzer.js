#!/usr/bin/env node

/**
 * 仓库分析模块
 * 功能：获取 GitHub 仓库信息，生成摘要文档
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

/**
 * 解析 GitHub 仓库地址
 * @param {string} input - GitHub 地址或仓库名
 * @returns {Object} 解析后的仓库信息
 */
function parseRepoInput(input) {
  let owner, repo;
  
  // 处理完整 URL
  const urlMatch = input.match(/github\.com[\/:]([^\/]+)\/([^\/\s]+)/);
  if (urlMatch) {
    owner = urlMatch[1];
    repo = urlMatch[2].replace('.git', '');
  } 
  // 处理 owner/repo 格式
  else if (input.includes('/')) {
    [owner, repo] = input.split('/').map(s => s.trim());
  }
  // 仅 repo 名（尝试从当前用户推断）
  else {
    throw new Error('请提供完整的仓库地址或 owner/repo 格式');
  }
  
  return {
    owner,
    repo,
    fullName: `${owner}/${repo}`,
    url: `https://github.com/${owner}/${repo}`,
    deepwikiUrl: `https://deepwiki.com/${owner}/${repo}` // 假设的 deepwiki 格式
  };
}

/**
 * 分析仓库（使用 web_fetch 或 GitHub API）
 * @param {string} repoInput - 仓库地址或名称
 * @returns {Promise<Object>} 仓库详细信息
 */
async function analyze(repoInput) {
  const repoInfo = parseRepoInput(repoInput);
  
  console.log(`正在分析仓库：${repoInfo.fullName}...`);
  
  // 使用 web_fetch 获取 GitHub 页面内容
  const readmeUrl = `https://raw.githubusercontent.com/${repoInfo.owner}/${repoInfo.repo}/main/README.md`;
  const readmeAltUrl = `https://raw.githubusercontent.com/${repoInfo.owner}/${repoInfo.repo}/master/README.md`;
  
  let readmeContent = '';
  try {
    // 这里应该调用 web_fetch 工具，但在脚本中我们用 curl 模拟
    const curlCmd = `curl -sL "${readmeUrl}" 2>/dev/null || curl -sL "${readmeAltUrl}" 2>/dev/null`;
    readmeContent = execSync(curlCmd, { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });
  } catch (e) {
    readmeContent = '*README 获取失败*';
  }
  
  // 获取仓库元数据（通过 GitHub API）
  const apiCmd = `curl -sL "https://api.github.com/repos/${repoInfo.fullName}" 2>/dev/null`;
  let apiData = {};
  try {
    const apiResponse = execSync(apiCmd, { encoding: 'utf8' });
    apiData = JSON.parse(apiResponse);
  } catch (e) {
    console.log('GitHub API 获取失败，使用基本信息');
  }
  
  return {
    ...repoInfo,
    description: apiData.description || '暂无描述',
    stars: apiData.stargazers_count || 0,
    forks: apiData.forks_count || 0,
    language: apiData.language || 'Unknown',
    license: apiData.license?.name || 'Unknown',
    topics: apiData.topics || [],
    readmeContent,
    updatedAt: apiData.updated_at || new Date().toISOString(),
    defaultBranch: apiData.default_branch || 'main'
  };
}

/**
 * 生成仓库摘要文档
 * @param {Object} repoInfo - 仓库信息
 * @returns {Promise<string>} 摘要文件路径
 */
async function generateSummary(repoInfo) {
  const templatePath = path.join(__dirname, '../templates/repo-summary.md');
  let template = fs.readFileSync(templatePath, 'utf8');
  
  // 替换模板变量
  const summary = template
    .replace(/{{repoName}}/g, repoInfo.fullName)
    .replace(/{{repoUrl}}/g, repoInfo.url)
    .replace(/{{deepwikiUrl}}/g, repoInfo.deepwikiUrl)
    .replace(/{{primaryLanguage}}/g, repoInfo.language)
    .replace(/{{stars}}/g, repoInfo.stars)
    .replace(/{{forks}}/g, repoInfo.forks)
    .replace(/{{license}}/g, repoInfo.license)
    .replace(/{{lastUpdate}}/g, repoInfo.updatedAt.split('T')[0])
    .replace(/{{projectDescription}}/g, repoInfo.description)
    .replace(/{{coreValue}}/g, `基于 ${repoInfo.language} 构建，${repoInfo.description}`)
    .replace(/{{techStack}}/g, repoInfo.language)
    .replace(/{{projectStructure}}/g, '待分析...')
    .replace(/{{coreFiles}}/g, '待分析...')
    .replace(/{{learningTips}}/g, '建议从 README 和文档开始，逐步深入核心模块')
    .replace(/{{prerequisites}}/g, `需要 ${repoInfo.language} 基础知识`)
    .replace(/{{officialDocs}}/g, repoInfo.url)
    .replace(/{{communityLinks}}/g, `${repoInfo.url}/issues`)
    .replace(/{{generatedAt}}/g, new Date().toISOString());
  
  // 保存文件
  const workspacePath = path.join(process.env.HOME, 'openclaw/workspace/github-learning');
  const repoDir = path.join(workspacePath, repoInfo.fullName.replace('/', '-'));
  fs.mkdirSync(repoDir, { recursive: true });
  
  const summaryPath = path.join(repoDir, 'repo-summary.md');
  fs.writeFileSync(summaryPath, summary, 'utf8');
  
  return summaryPath;
}

module.exports = {
  parseRepoInput,
  analyze,
  generateSummary
};
