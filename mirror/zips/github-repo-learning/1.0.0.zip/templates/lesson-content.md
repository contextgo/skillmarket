# 第{{lessonNumber}}课：{{lessonTitle}}

## 学习目标

学完这节课后，你将能够：

- {{objective1}}
- {{objective2}}
- {{objective3}}

## 预计用时

{{estimatedTime}} 分钟

## 核心概念

### 概念 1: {{concept1Name}}

{{concept1Explanation}}

### 概念 2: {{concept2Name}}

{{concept2Explanation}}

## 生动比喻

{{analogy}}

## 代码 Walkthrough

### 关键文件：{{codeFilePath}}

```{{language}}
{{codeExample}}
```

### 代码解析

{{codeAnalysis}}

## 实践作业

### 作业 1: {{assignment1Title}}

**要求**: {{assignment1Requirement}}

**提示**: 
- 提示 1
- 提示 2

**验收标准**:
- [ ] 标准 1
- [ ] 标准 2

### 作业 2: {{assignment2Title}}（可选进阶）

{{assignment2Description}}

## 常见误区

{{commonMistakes}}

## 延伸阅读

- [相关链接 1]({{link1}})
- [相关链接 2]({{link2}})

## 下节预告

{{nextLessonPreview}}

---

**完成时间**: _________  
**作业完成**: [ ] 是 [ ] 否  
**难点记录**: _________
