# {{repoName}} 仓库学习指南

## 仓库信息

- **仓库地址**: {{repoUrl}}
- **DeepWiki 地址**: {{deepwikiUrl}}
- **主要语言**: {{primaryLanguage}}
- **Stars**: {{stars}} | **Forks**: {{forks}}
- **许可证**: {{license}}
- **最后更新**: {{lastUpdate}}

## 项目简介

{{projectDescription}}

## 核心价值

{{coreValue}}

## 技术栈

{{techStack}}

## 项目结构

```
{{projectStructure}}
```

## 核心文件/模块

{{coreFiles}}

## 学习建议

{{learningTips}}

## 前置知识

{{prerequisites}}

## 相关资源

- 官方文档：{{officialDocs}}
- 社区讨论：{{communityLinks}}

---
*本文档由 github-repo-learning Skill 自动生成*
*生成时间：{{generatedAt}}*
