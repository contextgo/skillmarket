# github-repo-learning Skill

帮助用户深入学习 GitHub 开源代码仓库的 AI 助手技能。

## 功能特性

- 📊 **仓库分析**：自动获取 GitHub 仓库信息，生成摘要文档
- 📋 **课程规划**：交互式询问学习参数，生成个性化课程大纲
- 📝 **内容生成**：为每节课生成详细内容（代码样例、实践作业、生动比喻）
- 📅 **飞书同步**：创建多维表格和日程待办，跟踪学习进度

## 使用方式

### 触发方式

在聊天中提供 GitHub 仓库地址并表达学习意图：

```
我想深入学习 https://github.com/vercel/next.js 这个仓库，帮我规划一个系统学习课程
```

或

```
帮我分析 github:facebook/react，设计一个学习路线
```

### 交互流程

1. **仓库分析**：Skill 自动获取仓库信息，生成 `repo-summary.md`
2. **参数收集**：询问以下问题：
   - 计划几个课时？
   - 学习深度（入门/进阶/精通）？
   - 每周时间投入？
   - 侧重方向（实战/原理/扩展/架构）？
   - 相关经验水平？
3. **大纲生成**：生成 `course-outline.md`
4. **内容生成**：为每节课创建 `lessons/lesson-XX.md`
5. **飞书同步**：创建多维表格，设置待办任务

## 输出文件

```
~/openclaw/workspace/github-learning/[repo-name]/
├── repo-summary.md          # 仓库摘要
├── course-outline.md        # 课程大纲
├── lessons/
│   ├── lesson-01-环境搭建与 Hello World.md
│   ├── lesson-02-核心概念快速了解.md
│   └── ...
├── feishu-sync-command.json # 飞书同步指令
└── feishu-bitable-url.txt   # 飞书表格信息
```

## 技术架构

```
src/
├── index.js              # 主入口
├── repo-analyzer.js      # 仓库分析模块
├── course-planner.js     # 课程规划模块
├── content-generator.js  # 内容生成模块
└── feishu-sync.js        # 飞书同步模块

templates/
├── repo-summary.md       # 仓库摘要模板
├── course-outline.md     # 课程大纲模板
└── lesson-content.md     # 课时内容模板
```

## 依赖的 OpenClaw 工具

- `web_fetch`：获取 GitHub 页面内容
- `feishu_bitable_create_app`：创建飞书多维表格
- `feishu_bitable_create_field`：创建表格字段
- `feishu_bitable_create_record`：创建记录
- `write`：保存本地文件

## 自定义配置

可以在 Skill 中调整以下参数：

- 每节课的默认时长（默认 180 分钟）
- 课程阶段分配比例（入门/进阶/深入）
- 飞书表格字段配置
- 模板内容

## 注意事项

1. **仓库规模**：超大型仓库建议分模块学习
2. **私有仓库**：需要提供 GitHub Token
3. **飞书权限**：确保已授权飞书 API
4. **语言支持**：目前主要针对 JavaScript/Python/Go 优化

## 开发计划

- [ ] 支持自动提取仓库实际代码示例
- [ ] 支持视频/文档链接自动收集
- [ ] 支持学习进度追踪和提醒
- [ ] 支持多人协作学习
- [ ] 支持导出为 PDF/Notion

## 贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

MIT
