#!/usr/bin/env node

/**
 * github-repo-learning Skill 测试脚本
 */

const path = require('path');

// 测试模块导入
console.log('🧪 测试 github-repo-learning Skill...\n');

try {
  // 测试 repo-analyzer
  console.log('📊 测试 repo-analyzer 模块...');
  const analyzer = require('../src/repo-analyzer');
  
  const testInput = 'https://github.com/vercel/next.js';
  const parsed = analyzer.parseRepoInput(testInput);
  console.log('  ✅ parseRepoInput:', parsed.fullName);
  
  // 测试 course-planner
  console.log('\n📋 测试 course-planner 模块...');
  const planner = require('../src/course-planner');
  
  const questions = planner.generateQuestions({ repo: 'next.js', language: 'JavaScript' });
  console.log('  ✅ generateQuestions:', questions.length, '个问题');
  console.log('     问题示例:', questions[0].question);
  
  // 测试 content-generator
  console.log('\n📝 测试 content-generator 模块...');
  const generator = require('../src/content-generator');
  console.log('  ✅ 模块加载成功');
  
  // 测试 feishu-sync
  console.log('\n📅 测试 feishu-sync 模块...');
  const feishu = require('../src/feishu-sync');
  console.log('  ✅ 模块加载成功');
  
  console.log('\n✅ 所有模块测试通过！\n');
  
} catch (error) {
  console.error('\n❌ 测试失败:', error.message);
  console.error(error.stack);
  process.exit(1);
}
