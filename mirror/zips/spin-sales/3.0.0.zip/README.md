# 🎯 Spin-Sales技能 - 终极版SPIN销售法专家系统

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com/openclaw/spin-sales)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![OpenClaw](https://img.shields.io/badge/OpenClaw-compatible-orange.svg)](https://openclaw.ai)

## 📖 技能概述

Spin-Sales是一个基于尼尔·雷克汉姆SPIN销售法理论框架的专家系统，提供从开场、挖掘、到促成的全周期、可操作的销售对话脚本框架。适用于复杂的B2B销售咨询场景。

### 🎯 核心特色

- **完整的SPIN销售法流程**: 严格按照S-P-I-N四个阶段执行
- **专业的提问框架**: 每个阶段都有结构化的问题库
- **智能异议处理**: 针对常见异议提供专业应对策略
- **行动计划生成**: 将诊断结果转化为可执行的项目计划
- **数据支持**: 整合外部数据增强说服力

## 🚀 快速开始

### 基础使用

```javascript
const SpinSalesSkill = require('./index');

// 初始化技能
const spinSales = new SpinSalesSkill();
await spinSales.initialize();

// 执行开场白
const opening = await spinSales.executeOpening();

// 按顺序执行SPIN流程
const situation = await spinSales.executeStage('situation');
const problem = await spinSales.executeStage('problem');
const implication = await spinSales.executeStage('implication');
const needPayoff = await spinSales.executeStage('need-payoff');

// 生成行动计划
const actionPlan = await spinSales.generateActionPlan();
```

### 运行示例

```bash
# 基础使用示例
node examples/basic_usage.js

# 异议处理示例
node examples/objection_handling.js
```

## 📋 SPIN销售法流程

### 1. 开场与建立信任 (Opening)
- **目标**: 在30秒内建立专业形象，激发客户继续对话的兴趣
- **时长**: 2-3分钟
- **关键活动**: 显示行业了解、表明挑战洞察、建立信任、引导诊断

### 2. 现状了解 (Situation)
- **目标**: 收集客户当前的业务流程、现有系统和关键运营数据
- **时长**: 5-8分钟
- **关键活动**: 组织背景调研、系统调研、流程调研、数据调研

### 3. 痛点挖掘 (Problem)  
- **目标**: 基于现状，识别客户当前流程中的不合理、低效或令人不满意的问题点
- **时长**: 5-8分钟
- **关键活动**: 效率痛点识别、成本痛点识别、质量痛点识别

### 4. 影响放大 (Implication)
- **目标**: 将客户承认的痛点提升到公司、部门或个人层面，量化损失
- **时长**: 8-12分钟
- **关键活动**: 时间影响放大、决策影响放大、财务影响放大

### 5. 价值确认 (Need-Payoff)
- **目标**: 让客户自己说出解决方案的价值，制定可执行的项目计划
- **时长**: 5-8分钟
- **关键活动**: 价值确认、行动计划制定

## 🛡️ 异议处理

### 支持的异议类型

| 异议类型 | 描述 | 关键短语 | 处理策略 |
|---------|------|---------|---------|
| 预算异议 | 对价格和预算的顾虑 | "价格太贵", "超出预算" | 重述价值，ROI分析 |
| 时间异议 | 对时间和资源的顾虑 | "很忙", "没时间", "考虑" | 理解共情，强调紧迫性 |
| 信任异议 | 对经验和可信度的顾虑 | "经验", "放心", "保证成功" | 建立信任，提供证据 |
| 功能替代 | 认为现有产品可以满足需求 | "也可以实现", "已有解决方案" | 对比分析，价值聚焦 |

### 处理原则

- **不反驳，而是深入提问**: 将异议视为新的"痛点/关注点"
- **四步法**: 倾听认可 → 澄清定位 → 重述价值 → 提供解决方案
- **重新引导**: 将话题拉回到SPIN流程的当前阶段

## 📊 成功标准

### 销售对话成功
- ✅ 客户主动表达解决方案兴趣
- ✅ 客户清晰描述问题带来的具体损失
- ✅ 客户主动提出解决方案带来的具体价值
- ✅ 客户同意进入详细规划阶段

### 行动计划成功
- ✅ 包含明确可衡量的目标
- ✅ 有具体时间节点和里程碑
- ✅ 有清晰的责任人分配
- ✅ 有资源配置和预算规划

## ⚙️ 配置

### 技能配置

```json
{
  "name": "spin-sales",
  "version": "2.0.0",
  "stages": ["opening", "situation", "problem", "implication", "need-payoff"],
  "objection_types": {
    "budget": { "name": "预算异议", "handling_strategy": "重述价值" },
    "time": { "name": "时间异议", "handling_strategy": "理解共情" },
    "trust": { "name": "信任异议", "handling_strategy": "建立信任" },
    "feature": { "name": "功能替代", "handling_strategy": "对比分析" }
  }
}
```

### 依赖工具

- **memory_search**: 用户画像构建，提取历史信息
- **tavily_search**: 实时数据验证，获取市场行业数据

## 📚 参考文件

- `references/s-questions.md` - 现状事实收集
- `references/p-questions.md` - 痛点挖掘
- `references/i-questions.md` - 影响放大与数据佐证
- `references/n-questions.md` - 价值确认与行动计划制定
- `references/objections.md` - 专业异议处理
- `references/opening_scripts.md` - 开场与建立信任

## 🚀 最佳实践

### 顾问心态
- 定位为解决复杂业务难题的"战略咨询师"
- 通过引导性提问发掘深层需求
- 避免直接推销产品

### 流程控制
- 必须严格按照S-P-I-N流程执行
- 不能跳过任何阶段
- 确保对话不偏离SPIN框架

### 数据支持
- 在I阶段必须提供数据支持
- 使用tavily_search获取行业数据
- 使用memory_search了解用户历史背景

## ⚠️ 注意事项

### 使用边界
- 仅适用于复杂的、需要诊断性的B2B销售咨询场景
- 不处理简单的功能演示、价格询价或仅基于产品手册的信息查询

### 安全与合规
- 涉及隐私数据操作前必须获得明确授权
- 使用外部数据时确保数据来源可靠
- 严格遵守数据保护相关规定

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个技能！

### 开发指南

1. Fork这个仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🙏 致谢

- 基于尼尔·雷克汉姆的SPIN销售法理论框架
- 感谢所有贡献者和测试用户

---

*最后更新: 2026-05-06*
*版本: 2.0.0*