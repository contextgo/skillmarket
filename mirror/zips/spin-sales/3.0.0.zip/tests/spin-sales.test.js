#!/usr/bin/env node

/**
 * Spin-Sales技能测试文件
 * 验证技能的各个功能模块
 */

import fs from 'fs';
import path from 'path';
import SpinSalesSkill from '../index.js';

// 测试工具函数
function assert(condition, message) {
  if (!condition) {
    throw new Error(`测试失败: ${message}`);
  }
}

async function runTests() {
  console.log("🧪 Spin-Sales技能测试开始");
  console.log("=" .repeat(50));
  
  const testResults = {
    passed: 0,
    failed: 0,
    total: 0
  };
  
  // 测试1: 初始化技能
  console.log("\n📋 测试1: 初始化技能");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    assert(spinSales.currentStage === "opening", "初始阶段应为opening");
    assert(Array.isArray(spinSales.conversationHistory), "对话历史应为数组");
    assert(spinSales.conversationHistory.length === 0, "初始对话历史应为空");
    
    testResults.passed++;
    console.log("✅ 技能初始化测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 技能初始化测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试2: 开场白执行
  console.log("\n📋 测试2: 开场白执行");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    const openingResult = await spinSales.executeOpening();
    
    assert(openingResult.success === true, "开场白应执行成功");
    assert(typeof openingResult.message === 'string', "开场白消息应为字符串");
    assert(spinSales.currentStage === "situation", "开场白后阶段应切换为situation");
    assert(spinSales.conversationHistory.length === 1, "对话历史应记录1条");
    
    testResults.passed++;
    console.log("✅ 开场白执行测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 开场白执行测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试3: SPIN流程执行
  console.log("\n📋 测试3: SPIN流程执行");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    // 执行开场白
    await spinSales.executeOpening();
    
    // 执行S阶段
    const situationResult = await spinSales.executeStage("situation");
    assert(situationResult.success === true, "S阶段应执行成功");
    assert(spinSales.currentStage === "situation", "当前阶段应为situation");
    
    // 执行P阶段
    const problemResult = await spinSales.executeStage("problem");
    assert(problemResult.success === true, "P阶段应执行成功");
    assert(spinSales.currentStage === "problem", "当前阶段应为problem");
    
    // 执行I阶段
    const implicationResult = await spinSales.executeStage("implication");
    assert(implicationResult.success === true, "I阶段应执行成功");
    assert(spinSales.currentStage === "implication", "当前阶段应为implication");
    
    // 执行N阶段
    const needPayoffResult = await spinSales.executeStage("need-payoff");
    assert(needPayoffResult.success === true, "N阶段应执行成功");
    assert(spinSales.currentStage === "need-payoff", "当前阶段应为need-payoff");
    
    testResults.passed++;
    console.log("✅ SPIN流程执行测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ SPIN流程执行测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试4: 异议处理
  console.log("\n📋 测试4: 异议处理");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    // 先建立一些对话历史
    await spinSales.executeOpening();
    await spinSales.executeStage("situation");
    
    const objection = "你们的价格太贵了";
    const objectionResult = await spinSales.handleObjection(objection);
    
    assert(objectionResult.success === true, "异议处理应执行成功");
    assert(typeof objectionResult.response === 'string', "异议回应应为字符串");
    assert(objectionResult.continueFlow === true, "应继续SPIN流程");
    assert(spinSales.conversationHistory.length > 2, "对话历史应包含异议记录");
    
    testResults.passed++;
    console.log("✅ 异议处理测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 异议处理测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试5: 行动计划生成
  console.log("\n📋 测试5: 行动计划生成");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    // 完整执行SPIN流程
    await spinSales.executeOpening();
    await spinSales.executeStage("situation");
    await spinSales.executeStage("problem");
    await spinSales.executeStage("implication");
    await spinSales.executeStage("need-payoff");
    
    const actionPlanResult = await spinSales.generateActionPlan();
    
    assert(actionPlanResult.success === true, "行动计划生成应执行成功");
    assert(actionPlanResult.actionPlan !== null, "行动计划不应为空");
    assert(Array.isArray(actionPlanResult.actionPlan.tasks), "任务应为数组");
    assert(actionPlanResult.actionPlan.tasks.length > 0, "应包含至少一个任务");
    
    // 验证任务结构
    const firstTask = actionPlanResult.actionPlan.tasks[0];
    assert(firstTask.goal, "任务应有目标");
    assert(firstTask.task, "任务应有具体行动");
    assert(firstTask.owner, "任务应有负责人");
    assert(firstTask.deadline, "任务应有截止日期");
    assert(firstTask.metric, "任务应有成功标准");
    
    testResults.passed++;
    console.log("✅ 行动计划生成测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 行动计划生成测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试6: 状态检查
  console.log("\n📋 测试6: 状态检查");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    // 初始状态
    const initialStatus = spinSales.getStatus();
    assert(initialStatus.currentStage === "opening", "初始阶段应为opening");
    assert(initialStatus.conversationHistory === 0, "初始对话历史应为0");
    assert(initialStatus.actionPlan === "未生成", "初始行动计划状态应为未生成");
    
    // 执行一些流程后
    await spinSales.executeOpening();
    await spinSales.executeStage("situation");
    
    const afterStatus = spinSales.getStatus();
    assert(afterStatus.currentStage === "situation", "执行后阶段应为situation");
    assert(afterStatus.conversationHistory > 0, "对话历史应大于0");
    assert(afterStatus.actionPlan === "未生成", "行动计划状态仍应为未生成");
    
    testResults.passed++;
    console.log("✅ 状态检查测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 状态检查测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试7: 阶段顺序验证
  console.log("\n📋 测试7: 阶段顺序验证");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    const stageOrder = ["opening", "situation", "problem", "implication", "need-payoff"];
    let currentStage = "opening";
    
    for (const stage of stageOrder) {
      if (stage === "opening") {
        await spinSales.executeOpening();
        // executeOpening会自动切换到situation阶段
        continue; 
      } else {
        await spinSales.executeStage(stage);
      }
      
      assert(spinSales.currentStage === stage, `阶段${stage}应正确设置`);
      currentStage = stage;
    }
    
    // 验证最后阶段没有下一个阶段
    const finalStatus = spinSales.getStatus();
    assert(finalStatus.nextStage === null, "最后阶段应没有下一个阶段");
    
    testResults.passed++;
    console.log("✅ 阶段顺序验证测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 阶段顺序验证测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试8: 错误处理
  console.log("\n📋 测试8: 错误处理");
  try {
    const spinSales = new SpinSalesSkill();
    await spinSales.initialize();
    
    // 测试无效阶段
    const invalidStageResult = await spinSales.executeStage("invalid_stage");
    assert(invalidStageResult.success === false, "无效阶段应返回失败");
    
    testResults.passed++;
    console.log("✅ 错误处理测试通过");
  } catch (error) {
    testResults.failed++;
    console.error("❌ 错误处理测试失败:", error.message);
  }
  testResults.total++;
  
  // 测试总结
  console.log("\n" + "=" .repeat(50));
  console.log("🧪 测试总结");
  console.log("=" .repeat(50));
  console.log(`✅ 通过: ${testResults.passed}`);
  console.log(`❌ 失败: ${testResults.failed}`);
  console.log(`📊 总计: ${testResults.total}`);
  
  if (testResults.failed === 0) {
    console.log("\n🎉 所有测试通过！Spin-Sales技能运行正常。");
    process.exit(0);
  } else {
    console.log(`\n⚠️ 有 ${testResults.failed} 个测试失败，请检查代码。`);
    process.exit(1);
  }
}

// 运行测试
if (import.meta.url === `file://${process.argv[1]}`) {
  runTests().catch(console.error);
}

export { runTests };