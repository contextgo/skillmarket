#!/usr/bin/env node

/**
 * Spin-Sales技能入口文件
 * 终极版SPIN销售法专家系统 - 提供从开场、挖掘、到促成的全周期销售对话框架
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { cacheManager } from './cache.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 加载技能配置
const SKILL_CONFIG = {
  name: "spin-sales",
  version: "2.0.0",
  description: "终极版SPIN销售法专家系统",
  author: "mikewongonline",
  stages: ["opening", "situation", "problem", "implication", "need-payoff"],
  references: {
    s_questions: "references/s-questions.md",
    p_questions: "references/p-questions.md", 
    i_questions: "references/i-questions.md",
    n_questions: "references/n-questions.md",
    objections: "references/objections.md",
    opening_scripts: "references/opening_scripts.md"
  }
};

class SpinSalesSkill {
  constructor() {
    this.currentStage = "opening";
    this.conversationHistory = [];
    this.userProfile = {};
    this.actionPlan = null;
  }

  /**
   * 初始化技能
   */
  async initialize() {
    console.log("🎯 Spin-Sales技能已激活");
    console.log("📋 当前阶段:", this.currentStage);
    return this;
  }

  /**
   * 执行开场白流程
   */
  async executeOpening() {
    console.log("\n🚀 开始执行开场白流程...");
    console.log("📊 进度: 0%");
    
    // 模拟进度更新
    const progressInterval = setInterval(() => {
      const progress = Math.floor(Math.random() * 30) + 10;
      console.log(`📊 进度: ${progress}%`);
    }, 800);
    
    try {
      // 读取开场白脚本
      const openingScript = fs.readFileSync(
        path.join(__dirname, SKILL_CONFIG.references.opening_scripts), 
        'utf8'
      );
      
      // 解析开场白内容
      const opener = this.parseOpeningScript(openingScript);
      
      clearInterval(progressInterval);
      console.log("📊 进度: 100%");
      
      this.currentStage = "situation";
      this.conversationHistory.push({
        stage: "opening",
        timestamp: new Date().toISOString(),
        content: opener
      });

      return {
        success: true,
        message: opener,
        nextStage: "situation"
      };
      
    } catch (error) {
      console.error("执行开场白时出错:", error);
      console.error('🔍 错误详情:', error.stack);
      console.error('📋 当前状态:', this.getStatus());
      return {
        success: false,
        error: "无法加载开场白脚本",
        message: "抱歉，开场白加载失败，请稍后重试。"
      };
    }
  }

  /**
   * 解析开场白脚本
   */
  parseOpeningScript(script) {
    // 这里应该根据用户行业和背景定制开场白
    // 现在使用通用开场白
    return `您好！我是您的专业销售顾问。很高兴能和您交流。

从我的经验来看，在当前竞争激烈的市场环境中，很多企业都面临着效率、成本和质量的三重挑战。今天我想和您一起深入探讨，如何通过系统性的方法来识别和解决业务中的关键问题。

让我们开始吧！首先，我想了解一下您目前的业务状况。`;
  }

  /**
   * 执行SPIN流程的指定阶段
   */
  async executeStage(stage, userInput = null) {
    console.log(`\n🔄 执行${stage}阶段...`);
    console.log(`📊 阶段进度: 0%`);
    
    // 模拟进度更新
    const progressInterval = setInterval(() => {
      const progress = Math.floor(Math.random() * 30) + 10;
      console.log(`📊 阶段进度: ${progress}%`);
    }, 1000);
    
    try {
      let referenceFile;
      if (stage === 'opening') {
        referenceFile = SKILL_CONFIG.references.opening_scripts;
      } else {
        // 映射阶段名称到配置中的键名
        const stageMapping = {
          'situation': 's_questions',
          'problem': 'p_questions', 
          'implication': 'i_questions',
          'need-payoff': 'n_questions'
        };
        
        const configKey = stageMapping[stage] || `${stage}_questions`;
        referenceFile = SKILL_CONFIG.references[configKey];
      }
      
      if (!referenceFile) {
        throw new Error(`找不到${stage}阶段的参考文件`);
      }

      const referenceContent = await cacheManager.getFileContent(
        path.join(__dirname, referenceFile)
      );

      const questions = this.parseReferenceContent(referenceContent, stage);
      
      clearInterval(progressInterval);
      console.log(`📊 阶段进度: 100%`);
      
      this.currentStage = stage;
      this.conversationHistory.push({
        stage: stage,
        timestamp: new Date().toISOString(),
        userInput: userInput,
        questions: questions
      });

      return {
        success: true,
        stage: stage,
        questions: questions,
        nextStage: this.getNextStage(stage)
      };
      
    } catch (error) {
      console.error(`执行${stage}阶段时出错:`, error);
      console.error('🔍 错误详情:', error.stack);
      console.error('📋 当前状态:', this.getStatus());
      return {
        success: false,
        error: `无法执行${stage}阶段`,
        message: "抱歉，流程执行失败，请稍后重试。"
      };
    }
  }

  /**
   * 解析参考内容
   */
  parseReferenceContent(content, stage) {
    // 简化的内容解析逻辑
    // 实际应用中应该更复杂，能够提取关键问题和指导
    const lines = content.split('\n');
    const questions = [];
    
    let currentSection = '';
    let currentQuestions = [];
    
    for (const line of lines) {
      if (line.includes('###') || line.includes('**关键问题**')) {
        if (currentSection && currentQuestions.length > 0) {
          questions.push({
            section: currentSection,
            questions: currentQuestions
          });
        }
        currentSection = line.replace(/[#\*\s]/g, '').trim();
        currentQuestions = [];
      } else if (line.includes('"') && line.includes('？')) {
        const question = line.match(/"([^"]+)"/);
        if (question) {
          currentQuestions.push(question[1]);
        }
      }
    }
    
    // 添加最后一个section
    if (currentSection && currentQuestions.length > 0) {
      questions.push({
        section: currentSection,
        questions: currentQuestions
      });
    }
    
    return questions;
  }

  /**
   * 获取下一个阶段
   */
  getNextStage(currentStage) {
    const stageOrder = ["opening", "situation", "problem", "implication", "need-payoff"];
    const currentIndex = stageOrder.indexOf(currentStage);
    
    if (currentIndex < stageOrder.length - 1) {
      return stageOrder[currentIndex + 1];
    }
    
    return null; // 流程结束
  }

  /**
   * 处理异议
   */
  async handleObjection(objection) {
    console.log("\n🛡️ 处理异议...");
    
    try {
      const objectionContent = fs.readFileSync(
        path.join(__dirname, SKILL_CONFIG.references.objections), 
        'utf8'
      );

      const response = this.generateObjectionResponse(objectionContent, objection);
      
      this.conversationHistory.push({
        stage: "objection",
        timestamp: new Date().toISOString(),
        objection: objection,
        response: response
      });

      return {
        success: true,
        response: response,
        continueFlow: true
      };
      
    } catch (error) {
      console.error("处理异议时出错:", error);
      console.error('🔍 错误详情:', error.stack);
      console.error('📋 当前状态:', this.getStatus());
      return {
        success: false,
        error: "无法处理异议",
        message: "抱歉，异议处理失败，请稍后重试。"
      };
    }
  }

  /**
   * 生成异议回应
   */
  generateObjectionResponse(content, objection) {
    // 简化的异议回应逻辑
    // 实际应用中应该根据异议类型生成专业回应
    return `我理解您的顾虑。让我们深入探讨一下这个问题。

您提到"${objection}"，这是一个很重要的考虑点。为了更好地帮您，我想了解一下：
1. 这个顾虑背后的具体原因是什么？
2. 如果这个问题不解决，会对您的业务产生什么影响？
3. 您理想中的解决方案应该具备哪些特点？

让我们回到之前讨论的核心问题上...`;
  }

  /**
   * 生成行动计划
   */
  async generateActionPlan() {
    console.log("\n📋 生成行动计划...");
    
    try {
      const planContent = fs.readFileSync(
        path.join(__dirname, SKILL_CONFIG.references.n_questions), 
        'utf8'
      );

      this.actionPlan = this.parseActionPlan(planContent);
      
      this.conversationHistory.push({
        stage: "action_plan",
        timestamp: new Date().toISOString(),
        actionPlan: this.actionPlan
      });

      return {
        success: true,
        actionPlan: this.actionPlan
      };
      
    } catch (error) {
      console.error("生成行动计划时出错:", error);
      console.error('🔍 错误详情:', error.stack);
      console.error('📋 当前状态:', this.getStatus());
      return {
        success: false,
        error: "无法生成行动计划",
        message: "抱歉，行动计划生成失败，请稍后重试。"
      };
    }
  }

  /**
   * 解析行动计划
   */
  parseActionPlan(content) {
    // 生成示例行动计划
    return {
      title: "SPIN销售法行动计划",
      goals: [
        "识别并量化当前业务痛点",
        "评估问题对业务的实际影响",
        "制定解决方案的价值主张",
        "确定实施路径和时间表"
      ],
      tasks: [
        {
          goal: "业务现状调研",
          task: "收集现有流程和数据",
          owner: "客户方项目负责人",
          deadline: "2026-05-15",
          metric: "完成现状分析报告"
        },
        {
          goal: "痛点深度分析",
          task: "识别关键瓶颈和问题点",
          owner: "顾问团队",
          deadline: "2026-05-20", 
          metric: "提交痛点分析报告"
        },
        {
          goal: "解决方案设计",
          task: "制定详细的解决方案",
          owner: "双方联合团队",
          deadline: "2026-05-25",
          metric: "获得方案审批"
        }
      ]
    };
  }

  /**
   * 获取当前状态
   */
  getStatus() {
    return {
      currentStage: this.currentStage,
      conversationHistory: this.conversationHistory.length,
      actionPlan: this.actionPlan ? "已生成" : "未生成",
      nextStage: this.getNextStage(this.currentStage)
    };
  }
}

// 导出技能模块
export default SpinSalesSkill;
export { SpinSalesSkill };