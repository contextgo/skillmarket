#!/usr/bin/env node

/**
 * 缓存管理模块
 * 用于优化文件读取和性能
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class CacheManager {
  constructor() {
    this.cache = new Map();
    this.cacheTimeout = 300000; // 5分钟缓存
  }

  /**
   * 获取缓存项
   * @param {string} key - 缓存键
   * @returns {*} 缓存值或null
   */
  get(key) {
    const item = this.cache.get(key);
    if (!item) return null;
    
    if (Date.now() - item.timestamp > this.cacheTimeout) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }

  /**
   * 设置缓存项
   * @param {string} key - 缓存键
   * @param {*} value - 缓存值
   */
  set(key, value) {
    this.cache.set(key, {
      value,
      timestamp: Date.now()
    });
  }

  /**
   * 清除缓存
   */
  clear() {
    this.cache.clear();
  }

  /**
   * 获取带缓存的文件内容
   * @param {string} filePath - 文件路径
   * @returns {Promise<string>} 文件内容
   */
  async getFileContent(filePath) {
    const cacheKey = `file:${filePath}`;
    const cachedContent = this.get(cacheKey);
    
    if (cachedContent) {
      return cachedContent;
    }
    
    try {
      const content = await fs.promises.readFile(filePath, 'utf8');
      this.set(cacheKey, content);
      return content;
    } catch (error) {
      throw new Error(`无法读取文件 ${filePath}: ${error.message}`);
    }
  }

  /**
   * 获取带缓存的JSON内容
   * @param {string} filePath - 文件路径
   * @returns {Promise<Object>} JSON对象
   */
  async getJsonContent(filePath) {
    const content = await this.getFileContent(filePath);
    try {
      return JSON.parse(content);
    } catch (error) {
      throw new Error(`无法解析JSON文件 ${filePath}: ${error.message}`);
    }
  }
}

// 导出缓存管理器
export const cacheManager = new CacheManager();
export default CacheManager;