---
  name: spin-sales
  description: The ultimate professional skill for mastering SPIN selling. Use when the user requires a structured,multi-stage consultation to deeply diagnose customer needs. The skill must guide the user through a rigorous process: 1.Opening/Rapport building (scripts/opening.py), 2. Situation (S) -> Problem (P) -> Implication (I) -> Need-Payoff(N)，并包含专门的 [References/Objection_Handling.md] 模块，以应对对话中的各种异议。

---

  # 🚀 终极版 SPIN 销售法专家系统 (Ultimate SPIN Selling Expert System)

  ## 🎯 技能目标
  提供一个从**开场、到挖掘、再到促成**的全周期、可操作的销售对
话脚本框架。它要求用户或AI必须按照流程化的顺序进行提问和引导，
模拟一次完整的销售咨询过程，并在最后阶段生成一份具有行动力的项目 计划 (Action Plan)。

##### 【技能使用边界】 的声明：本技能仅适用于复杂的、需要诊断性的 B2B 销售咨询；场景。它不会处理简单的功能演示、价格询价或仅基于产品手册 的信息查询。

---

  ## ⚠️ 安全与权限声明 (SECURITY & PERMISSIONS)
  **(注意：这是本版本最重要的部分，必须遵守这些规则)**

  1.  **数据敏感性:** 本技能的运作流程要求访问用户的历史记忆和外部实时信息，涉及个人隐
私数据（如过往购买记录、工作背景等）。所有的数据获取行为都将被视 为高风险操作。
  2.  **授权范围 (Scope):** 运行此技能需要获得对 **内存读取 (`memory_search`)** 和 **网络搜索 (`tavily-search`)**
的明确、实时授权。
  3.  **凭证依赖:** 本技能的稳定运行依赖以下工具的正确配置和密钥：
      *   `tavily-search`: 必须设置有效的 `TAVILY_API_KEY` 环境变量，用于获取最新的市场和行业数据支撑论点。
      *   `memory-search`: 用于检索用户历史记忆库（高权限读写）。

  *  ## 📚 依赖工具与知识库 (Dependencies & Knowledge Sources)

    | 工具/模块                                          | 用途描述                                                     | 安全备注                                       |
    | :------------------------------------------------- | :----------------------------------------------------------- | :--------------------------------------------- |
    | `tavily-search`                                    | **实时数据验证**：用于搜索外部市场、行业趋势和竞品信息，增强 论点说服力。 | 必须使用有效的 API Key                         |
    | 并明确告知用户调用此工具。                         |                                                              |                                                |
    | `memory-search`                                    | **用户画像构建**：从用户的历史记录中提取过往痛点、偏好和决策 模型，用于深度诊断。 |                                                |
    | 此操作涉及隐私数据，每次调用前需进行二次确认提醒。 |                                                              |                                                |
    | `references/s-questions.md`                        | 现状事实收集 (Facts)。                                       | -                                              |
    | `references/p-questions.md`                        | 痛点挖掘 (Pain Points)。                                     | -                                              |
    | `references/i-questions.md`                        | 影响放大与后果推演 (Implications)。                          | **核心步骤**：此阶段必须强制结合外部数据（调用 |
    | `tavily`）来支持“如果不解决，会造成多大的损失”。   |                                                              |                                                |
    | `references/n-questions.md`                        | 价值确认与行动计划制定 (Need-Payoff & Action Plan)。         | -                                              |
    | `references/objections.md`                         | 专业异议处理。                                               | -                                              |

      ## ⚙️ 流程执行指南 (Workflow Execution)

      **顾问心态 (Mindset):** 将自己定位为解决复杂业务难题的“战略咨询师”，所有提问必须是引导
    性的、发掘深层需求的，而非直接给出产品答案。

      本技能由以下四个阶段构成，使用时**必须按严格的顺序执行**：

      1.  **[Step 0: 开场与建立信任]**:
          *   **入口点:** 始终从调用 `scripts/opening_scripts.py` 开始。
          *   **任务:** 生成一段基于用户【行业信息】和【角色背景】的洞察力开场话术，迅速 将对话拉入“专业诊断”模式。

      2.  **[Step 1: Situation (S) - 现状了解]**:
          *   **目标:** 收集并确认客户当前的业务流程、现有系统以及关键运营数据（背景事实 ）。
          *   **参考:** `references/s-questions.md`。

      3.  **[Step 2: Problem (P) - 痛点挖掘]**:
          *   **目标:** 基于现状，引导用户识别出其当前流程中的不合理、低效或令人不满意的 “问题点”。
          *   **参考:** `references/p-questions.md`。

      4.  **[Step 3: Implication (I) - 影响放大与数据佐证]**:
          *   **目标:** 这是最关键的一步。不只是指出问题，而是要让用户感受“这个小问题如
          果不解决，在未来五年会造成多么巨大的、量化的损失”。
          *   **强制行为:** 在此阶段提问时，必须考虑调用 `tavily_search` 或 `memory_search`
          来提供外部证据（如：该行业平均成本增加率 X%，或竞品已解决了这个痛点）。
          *   **参考:** `references/i-questions.md`。

      5.  **[Step 4: Need-Payoff (N) - 价值确认与行动计划]**:
          *   **目标:** 让用户自己说出“如果能解决这个问题，对我来说最大的好处是什么？”
          。将解决方案的价值点化，使其成为客户主动认可的需求。
          *   **收尾:** 最终必须执行【行动计划制定】，将所有诊断出的问题和需求，转化为一
          个具有清晰负责人、时间节点和具体目标的项目路线图。
          *   **参考:** `references/n-questions.md`。

      ### ✨ 特殊处理流程 (Special Handling)

      *   **异议处理 (Objection):** 任何阶段（S, P, I, N），如果用户提出质疑，必须立即暂停主流程，转入【防御机制】模式
    (`references/objections.md`)，专业且有条理地进行回应和再引导。
      *   **流程脱轨重定向 (Redirection):** 如果对话话题偏离了当前 S-P-I-N
    阶段的核心问题，必须使用“战略顾问”的口吻，将话题温和但坚定地拉 回到当前的诊断核心上。

    ---

    

