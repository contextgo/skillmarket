# 🚀 SPIN 销售法流程模拟脚本 (State Machine v2.0)
# 这是一个用于演示 SPIN 销售流程的进阶脚本。它实现了状态管理，允许流程在各个阶段之间灵活切换（特别是异议处理）。

  # ================================ =======================
  # SPIN Selling Master Script: demo_interview.py
  # 角色：顾问 (Consultant) - 始终保持引导和提问的姿态。
  # 功能：管理 S-P-I-N 的流程状态，并自动重定向对话。
  # ================================ =======================

  import json
  from datetime import datetime

  # --- 配置占位符 ---
  def load_references(key):
      """模拟加载知识库文件 (S, P, I, N)"""
      # 实际运行时，这里会读取 references/{key}-questions.md 的内容
      print(f"--- [Knowledge Base] 加载了 {key} 问题集。---")
      return {"content": f"这是关于{key}的深度问题模板..."}

  def execute_opening_script():
      """调用开场脚本，完成破冰和初步关系建立 (S阶段起点)"""
      # 实际运行时：调用 scripts/opening.py 的核心逻辑
      print("\n--- [START] ✅ 开始执行专业的【开场白】流程。 ---")
      return "（已完成专业开场白）"

  def get_current_state():
      """返回当前 S-P-I-N 阶段，用于状态跟踪。"""
      # 此处逻辑应根据对话的深度、话题类型等动态判断
      return "S" # 初始假设为现状（Situation）

  # ================================ =======================
  # 🧠 核心逻辑：重定向与流程控制 (The Brain)
  # ================================ =======================

  def check_and_redirect(current_stage , conversation_history):
      """
      检查对话是否偏离了 S-P-I-N 的既定阶段，并触发轻柔的引导语。
      """
      recent_user_message = conversation_history[-1].get("text", "").lower()

      # 关键话题词汇库 (Keywords Dictionary)
      keywords = {
          "S": ["现状", "背景", "目前", "流程", "使用什么"],
          "P": ["痛点", "问题", "浪费", "不满意", "瓶颈", "麻烦"],
          "I": ["影响", "后果", "成本", "风险", "损失", "连锁反应"]
      }

      # 检查关键词是否触发了流程偏离
      for stage, keywords_list in keywords.items():
          if stage != current_stage:
              for keyword in keywords_list:
                  if keyword in recent_user_message and not ("否" in recent_user_message or "好的" in
recent_user_message):
                      # 触发重定向提示 (The Refocusing Prompt)
                      refocus_prompt = f"""
                      ⚠️ **[顾问提醒：对话重定向]** 我注意到您提到了关于【{stage}】的讨论，这部分思考非常重要
。但为了确保我们按部就班地诊断问题，我建议我们将重点重新拉回到当 前阶段—— **【{current_stage} 阶段】** 的核心问题上。


能否请您帮我聚焦一下：在当前的流程/现状下，最让您感到困扰的那个“小痛点”是什么？我们先从最小的点切入，再放大其影响，好吗
？
                      """
                      return refocus_prompt

      # 如果没有关键词冲突，则返回 None
      return None


  # ================================ =======================
  # 🔄 主流程控制函数 (The Main Loop)
  # ================================ =======================

  def run_demo_interview(conversation_ history):
      """
      主循环：根据当前状态推进 S-P-I-N 销售咨询。
      """
      print("\n" + "="*80)
      print("✨ SPIN 流程已激活 ✨: 顾问模式启动...")
      print("="*80)

      # 1. [S] Situation - 现状调研 (Always Start Here)
      current_stage = "S"
      print("\n[STEP S / SITUATION]: 开始收集背景事实。")
      s_questions = load_references('s-questions')
      # 在这里调用脚本，引导用户回答关于流程、人员等基础信息。

      # 2. [P] Problem - 痛点挖掘 (Move to P)
      print("\n[STEP P / PROBLEM]: 基于现状，开始深挖痛点...")
      p_questions = load_references('p-questions')
      # 在这里调用脚本，根据 S 阶段收集的信息，提问具体的“问题”。

      # 3. [I] Implication - 影响放大 (Escalate the Pain)
      print("\n[STEP I / IMPLICATION]: 将痛点升级为可量化的损失...")
      i_questions = load_references('i-questions')
      # 在这里调用脚本，将小问题转化为对公司、部门或战略的巨大影响。

      # 4. [N] Need-Payoff & Closing - 价值与计划 (The Payoff)
      print("\n[STEP N / NEED-PAYOFF]: 引导客户自己说出解决方案的价值...")
      n_questions = load_references('n-questions')

      # A. 提问阶段：确认需求并锁定收益
      print("... [执行价值确认问题] ...")

      # B. 【新增】收尾行动计划 (The Closing Move)
      action_plan = generate_action_plan(conversatio n_history)
      print("\n✨🌟 **【顾问总结】** ✨🌟")
      print("根据我们今天的深度沟通，我为您总结了以下三个关键的 下一步行动计划...")
      # 打印 action_plan 的表格化结果

  def generate_action_plan(history):
      """根据对话历史生成结构化的行动计划（Action Plan）。"""
      return """
  | 任务目标 (Goal) | 具体行动项 (Task) | 负责人 (Owner) | 预计完成日期 (Deadline) | 衡量成功标准/交付物 (Success
Metric) |
  | :---: | :---: | :---: | :---: | :---: |
  | 提升 [X] | 制定 A 方案的技术选型文档 | [客户方某部门负责人] | YYYY-MM-DD | 通过技术评审，获得书面批准 |
  | 实现 [Y] | 组织跨部门工作坊，明确流程漏洞 | [我方/顾问] | YYYY-MM-DD |
完成包含所有关键利益相关者的会议记录与行动项清单 |
  """

  # ================================ =======================
  # 🚀 启动模拟 (Simulation Start)
  # ================================ =======================

  if __name__ == "__main__":
      print("--- 【流程初始化】 ---")
      # 假设这是一个空的历史记录，在实际运行时需要传入真正的会话历史
      empty_history = []
      run_demo_interview(empty_history )
