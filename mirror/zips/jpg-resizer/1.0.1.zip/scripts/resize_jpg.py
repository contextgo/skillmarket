#!/usr/bin/env python3
"""
JPG Image Resizer - 调整JPG图片大小，支持压缩或放大到目标尺寸范围
"""

import os
import sys
import argparse
from pathlib import Path
from PIL import Image
import math


def get_file_size_kb(path):
    """获取文件大小（KB）"""
    return os.path.getsize(path) / 1024


def resize_image(input_path, output_path, target_size_kb=None, quality=85, 
                 max_dimension=None, scale_factor=None, preserve_aspect=True):
    """
    调整图片大小
    
    参数:
        input_path: 输入文件路径
        output_path: 输出文件路径
        target_size_kb: 目标文件大小（KB），None表示不限制
        quality: JPEG质量 (1-100)
        max_dimension: 最大边像素值
        scale_factor: 缩放因子 (如 2.0 表示放大2倍)
        preserve_aspect: 是否保持宽高比
    """
    img = Image.open(input_path)
    
    # 转换为RGB（处理PNG透明通道等）
    if img.mode in ('RGBA', 'P', 'LA'):
        background = Image.new('RGB', img.size, (255, 255, 255))
        if img.mode == 'P':
            img = img.convert('RGBA')
        background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
        img = background
    elif img.mode != 'RGB':
        img = img.convert('RGB')
    
    original_size = img.size
    
    # 计算缩放
    if max_dimension:
        # 根据最大边缩放
        width, height = img.size
        max_side = max(width, height)
        if max_side > max_dimension:
            ratio = max_dimension / max_side
            new_width = int(width * ratio)
            new_height = int(height * ratio)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    elif scale_factor:
        # 按比例缩放
        new_width = int(img.width * scale_factor)
        new_height = int(img.height * scale_factor)
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    # 迭代调整质量以达到目标大小
    current_quality = quality
    min_quality = 10
    max_quality = 100
    tolerance = target_size_kb * 0.1 if target_size_kb else float('inf')  # 10%容差
    
    if target_size_kb:
        for iteration in range(20):  # 最多迭代20次
            img.save(output_path, 'JPEG', quality=current_quality, optimize=True)
            current_size = get_file_size_kb(output_path)
            
            diff = current_size - target_size_kb
            
            if abs(diff) <= tolerance:
                break
            
            # 根据差异调整质量
            if diff > 0:
                # 文件太大，降低质量
                max_quality = current_quality
                current_quality = (min_quality + current_quality) // 2
            else:
                # 文件太小，增加质量
                min_quality = current_quality
                current_quality = (current_quality + max_quality) // 2
            
            if current_quality == min_quality or current_quality == max_quality:
                break
    else:
        # 不需要目标大小，直接保存
        img.save(output_path, 'JPEG', quality=current_quality, optimize=True)
    
    final_size = get_file_size_kb(output_path)
    return {
        'original_size': original_size,
        'new_size': img.size,
        'file_size_kb': final_size,
        'quality': current_quality
    }


def process_single(input_file, output_file=None, target_size_kb=None, quality=85,
                   max_dimension=None, scale_factor=None, preserve_aspect=True):
    """处理单个文件"""
    if not os.path.exists(input_file):
        print(f"错误: 文件不存在 - {input_file}")
        return None
    
    if output_file is None:
        path = Path(input_file)
        output_file = path.stem + '_resized.jpg'
    
    print(f"\n处理文件: {input_file}")
    print(f"原始大小: {get_file_size_kb(input_file):.2f} KB")
    
    if target_size_kb:
        print(f"目标大小: {target_size_kb} KB")
    if max_dimension:
        print(f"最大边: {max_dimension}px")
    if scale_factor:
        print(f"缩放比例: {scale_factor}x")
    print(f"质量: {quality}")
    
    result = resize_image(
        input_file, output_file,
        target_size_kb=target_size_kb,
        quality=quality,
        max_dimension=max_dimension,
        scale_factor=scale_factor,
        preserve_aspect=preserve_aspect
    )
    
    print(f"新尺寸: {result['new_size'][0]}x{result['new_size'][1]}")
    print(f"最终质量: {result['quality']}")
    print(f"输出文件: {output_file}")
    print(f"文件大小: {result['file_size_kb']:.2f} KB")
    
    return result


def process_directory(input_dir, output_dir=None, target_size_kb=None, quality=85,
                      max_dimension=None, scale_factor=None, recursive=False, preserve_aspect=True):
    """批量处理目录"""
    input_path = Path(input_dir)
    
    if output_dir:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
    else:
        output_path = input_path
    
    # 查找JPG文件
    patterns = ['*.jpg', '*.jpeg', '*.JPG', '*.JPEG']
    files = []
    
    for pattern in patterns:
        if recursive:
            files.extend(input_path.rglob(pattern))
        else:
            files.extend(input_path.glob(pattern))
    
    if not files:
        print(f"在 {input_dir} 中未找到JPG文件")
        return
    
    print(f"找到 {len(files)} 个JPG文件")
    
    results = []
    for i, file in enumerate(files, 1):
        print(f"\n[{i}/{len(files)}] 处理中...")
        
        if output_dir:
            relative = file.relative_to(input_path)
            output_file = output_path / relative.with_suffix('.jpg')
            output_file.parent.mkdir(parents=True, exist_ok=True)
        else:
            output_file = file.parent / (file.stem + '_resized.jpg')
        
        try:
            result = resize_image(
                str(file), str(output_file),
                target_size_kb=target_size_kb,
                quality=quality,
                max_dimension=max_dimension,
                scale_factor=scale_factor,
                preserve_aspect=preserve_aspect
            )
            results.append((str(file), str(output_file), result))
            print(f"✓ 完成: {result['file_size_kb']:.2f} KB")
        except Exception as e:
            print(f"✗ 失败: {file} - {e}")
    
    # 汇总统计
    if results:
        total_original = sum(get_file_size_kb(r[0]) for r in results)
        total_new = sum(r[2]['file_size_kb'] for r in results)
        print(f"\n========== 批量处理完成 ==========")
        print(f"处理文件数: {len(results)}")
        print(f"原始总大小: {total_original:.2f} KB")
        print(f"新总大小: {total_new:.2f} KB")
        print(f"变化: {(total_new - total_original) / total_original * 100:+.1f}%")


def main():
    parser = argparse.ArgumentParser(
        description='JPG图片大小调整工具 - 支持压缩和放大到目标尺寸',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 压缩图片到100KB
  resize_jpg.py photo.jpg --target-size 100
  
  # 放大图片2倍
  resize_jpg.py photo.jpg --scale 2
  
  # 设置最大边为1000px
  resize_jpg.py photo.jpg --max-dimension 1000
  
  # 批量处理目录
  resize_jpg.py ./photos --output-dir ./output --target-size 200
'''
    )
    
    parser.add_argument('input', help='输入文件或目录')
    parser.add_argument('output', nargs='?', help='输出文件（单文件模式）或目录（批量模式）')
    
    # 大小控制组（互斥）
    size_group = parser.add_mutually_exclusive_group()
    size_group.add_argument('--target-size', type=int, help='目标文件大小（KB）')
    size_group.add_argument('--max-dimension', type=int, help='最大边像素值')
    size_group.add_argument('--scale', type=float, help='缩放倍数 (如 2.0)')
    
    # 质量设置
    parser.add_argument('--quality', type=int, default=85, help='JPEG质量 1-100 (默认: 85)')
    parser.add_argument('--no-preserve-aspect', action='store_true', help='不保持宽高比')
    
    # 批量处理选项
    parser.add_argument('--output-dir', help='输出目录（批量模式）')
    parser.add_argument('--recursive', '-r', action='store_true', help='递归处理子目录')
    
    args = parser.parse_args()
    
    # 参数验证
    if args.quality < 1 or args.quality > 100:
        print("错误: 质量必须在 1-100 之间")
        sys.exit(1)
    
    if os.path.isdir(args.input):
        process_directory(
            args.input,
            output_dir=args.output_dir or args.output,
            target_size_kb=args.target_size,
            quality=args.quality,
            max_dimension=args.max_dimension,
            scale_factor=args.scale,
            recursive=args.recursive,
            preserve_aspect=not args.no_preserve_aspect
        )
    else:
        process_single(
            args.input,
            output_file=args.output,
            target_size_kb=args.target_size,
            quality=args.quality,
            max_dimension=args.max_dimension,
            scale_factor=args.scale,
            preserve_aspect=not args.no_preserve_aspect
        )


if __name__ == '__main__':
    main()
