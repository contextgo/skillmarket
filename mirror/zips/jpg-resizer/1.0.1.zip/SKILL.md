---
name: jpg-resizer
description: |
  JPG图片大小调整工具，支持压缩减少体积或放大增加体积到用户指定的目标大小范围。
  This skill should be used when users want to: resize JPG images to a specific file size range,
  compress images to reduce file size, enlarge images to increase file size,
  batch process images to uniform file sizes, or adjust image dimensions while maintaining quality.
  触发场景包括：调整图片大小、压缩图片、放大图片、指定目标文件大小等。
---

# JPG Image Resizer

JPG图片大小调整工具，支持压缩或放大到用户指定的目标尺寸范围。

## 核心功能

1. **目标大小模式** - 用户指定KB值，自动调整质量和/或尺寸达到目标
2. **压缩模式** - 减少图片体积，可通过降低质量或尺寸实现
3. **放大模式** - 增加图片体积，通过放大尺寸实现
4. **尺寸控制** - 支持最大边限制或缩放倍数控制

## 使用方式

### 单文件处理

```bash
resize_jpg.py <input_file> [output_file] [options]
```

### 批量处理目录

```bash
resize_jpg.py <input_directory> --output-dir <output_directory> [options]
```

## 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `--target-size KB` | 目标文件大小（KB） | `--target-size 500` |
| `--max-dimension PX` | 最大边像素值 | `--max-dimension 1920` |
| `--scale N` | 缩放倍数 | `--scale 2` |
| `--quality N` | JPEG质量 1-100 | `--quality 85` |
| `--recursive` | 递归处理子目录 | `--recursive` |

## 使用示例

### 1. 压缩到指定大小

用户说："把这张图压缩到100KB以内"
```bash
resize_jpg.py photo.jpg --target-size 100
```

### 2. 放大到指定大小

用户说："把这张图放大到500KB以上"
```bash
# 方案1：使用scale放大
resize_jpg.py photo.jpg --scale 2 --quality 95

# 方案2：设置最大尺寸 + 高质量
resize_jpg.py photo.jpg --max-dimension 3000 --quality 100
```

### 3. 调整到大小范围

用户说："把这张图调整到200-300KB之间"
```bash
# 设置目标为范围中间值
resize_jpg.py photo.jpg --target-size 250 --quality 90
```

### 4. 批量处理

用户说："把这个文件夹里的图片都压缩到200KB"
```bash
resize_jpg.py ./photos --output-dir ./output --target-size 200
```

## 实现原理

脚本 `scripts/resize_jpg.py` 工作流程：

1. 打开图片并转换为RGB模式（处理PNG透明通道等）
2. 根据参数应用尺寸调整（如果指定了max_dimension或scale）
3. 如果指定了target_size：
   - 以当前质量保存
   - 比较文件大小与目标的差异
   - 迭代调整质量（增加或降低）直到达到目标范围
4. 输出结果统计

## 质量指南

| 质量 | 文件大小 | 适用场景 |
|------|----------|----------|
| 90-100 | 大 | 高质量输出、印刷 |
| 80-89 | 中等 | 推荐日常使用 |
| 70-79 | 较小 | 网页、优化存储 |
| <70 | 最小 | 极小文件、缩略图 |

## 注意事项

1. 放大图片会显著增加文件大小和质量设置对最终大小影响很大
2. 保持宽高比是默认行为，使用 `--no-preserve-aspect` 可禁用
3. 批量处理会自动在输出目录保持目录结构
4. 迭代调整质量最多20次以避免无限循环

## 前置依赖

```bash
pip install Pillow
```
