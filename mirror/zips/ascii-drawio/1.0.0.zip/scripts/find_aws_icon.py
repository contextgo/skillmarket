#!/usr/bin/env python3
"""AWS icon search script with expanded fuzzy matching.

Supports English, Chinese, capability-based queries, abbreviations,
and generic (non-AWS) icon lookup.

Usage:
    python find_aws_icon.py <query>
    python find_aws_icon.py ec2
    python find_aws_icon.py load balancer
    python find_aws_icon.py 缓存
    python find_aws_icon.py 负载均衡
    python find_aws_icon.py user
    python find_aws_icon.py --style lambda
"""

import re
import sys
from pathlib import Path
from difflib import SequenceMatcher


# ---------------------------------------------------------------------------
# Alias dictionary: maps a canonical key to a list of alternative terms.
# When a user searches for ANY of these terms, the corresponding AWS icon(s)
# will be matched.  Both English and Chinese terms are supported.
# ---------------------------------------------------------------------------
ALIASES = {
    # --- Compute ---
    "alb": ["application load balancer", "load balancer", "ingress", "应用负载均衡"],
    "nlb": ["network load balancer", "load balancer", "网络负载均衡"],
    "glb": ["gateway load balancer", "load balancer", "网关负载均衡"],
    "elb": ["elastic load balancing", "load balancer", "负载均衡", "lb"],
    "ec2": ["elastic compute cloud", "vm", "instance", "server", "虚拟机", "服务器", "实例", "计算"],
    "lambda": ["serverless", "function", "faas", "无服务器", "函数计算", "serverless function"],
    "batch": ["batch computing", "batch job", "批处理", "批量计算"],
    "lightsail": ["vps", "simple vm", "轻量服务器"],
    "app runner": ["app hosting", "应用托管", "容器托管"],
    "auto scaling": ["autoscaling", "弹性伸缩", "自动扩缩", "scaling"],

    # --- Containers ---
    "ecs": ["container orchestration", "containers", "service orchestration", "容器编排", "容器服务", "container service"],
    "eks": ["kubernetes", "k8s", "container orchestration", "容器编排", "k8s集群"],
    "ecr": ["container registry", "image registry", "docker registry", "镜像仓库", "容器镜像"],
    "fargate": ["serverless container", "无服务器容器", "fargate"],

    # --- Storage ---
    "s3": ["object storage", "bucket", "blob storage", "对象存储", "存储桶", "文件存储", "oss"],
    "ebs": ["block storage", "disk", "volume", "块存储", "云盘", "磁盘"],
    "efs": ["file storage", "nfs", "shared filesystem", "文件系统", "共享存储", "网络文件系统"],
    "fsx": ["file system", "lustre", "windows file server", "高性能文件系统"],
    "glacier": ["archive", "cold storage", "归档", "冷存储", "长期存储"],
    "storage gateway": ["hybrid storage", "混合存储", "存储网关"],
    "backup": ["backup service", "备份", "数据备份"],
    "snow family": ["data transfer", "edge computing", "snowball", "snowcone", "snowmobile", "数据迁移设备"],

    # --- Database ---
    "rds": ["relational database", "sql database", "database", "关系数据库", "关系型数据库", "数据库", "mysql", "postgresql", "postgres", "sql"],
    "aurora": ["mysql", "postgresql", "高性能数据库", "aurora"],
    "dynamodb": ["nosql", "key value", "document database", "kv数据库", "键值数据库", "文档数据库", "nosql数据库"],
    "elasticache": ["cache", "redis", "memcached", "缓存", "内存缓存", "分布式缓存"],
    "redshift": ["data warehouse", "olap", "数据仓库", "分析数据库", "列式存储"],
    "neptune": ["graph database", "graph db", "图数据库", "知识图谱", "图谱"],
    "documentdb": ["mongodb", "document db", "文档数据库", "mongodb兼容"],
    "timestream": ["time series", "time series database", "时序数据库", "时间序列"],
    "memorydb": ["redis compatible", "内存数据库", "持久化redis"],
    "keyspaces": ["cassandra", "wide column", "宽列数据库"],
    "qldb": ["ledger", "immutable", "账本数据库", "不可变数据库"],

    # --- Networking ---
    "vpc": ["network", "private network", "virtual network", "虚拟网络", "私有网络", "网络"],
    "cloudfront": ["cdn", "content delivery", "内容分发", "加速", "全球加速"],
    "route 53": ["dns", "domain name service", "域名", "dns解析", "域名解析"],
    "api gateway": ["api management", "api ingress", "gateway", "api网关", "接口网关", "api管理"],
    "direct connect": ["dedicated connection", "专线", "专线连接", "直连"],
    "transit gateway": ["network hub", "网络中枢", "中转网关", "网络互联"],
    "privatelink": ["private endpoint", "私有链接", "私有终端节点"],
    "global accelerator": ["global network", "全球加速器", "网络加速"],
    "app mesh": ["service mesh", "服务网格", "微服务网格"],
    "cloud map": ["service discovery", "服务发现", "服务注册"],
    "network firewall": ["firewall", "network security", "网络防火墙", "防火墙"],

    # --- Security ---
    "iam": ["identity", "access control", "permissions", "authentication", "authorization",
            "身份", "权限", "访问控制", "认证", "鉴权", "身份认证"],
    "cognito": ["user auth", "user pool", "用户认证", "用户池", "登录认证", "oauth"],
    "kms": ["key management", "encryption", "keys", "密钥管理", "加密", "密钥"],
    "secrets manager": ["secrets", "credential storage", "secret management", "密钥存储", "凭证管理", "密码管理"],
    "waf": ["web application firewall", "firewall", "waf防火墙", "web防火墙", "应用防火墙"],
    "shield": ["ddos protection", "ddos", "ddos防护", "抗ddos"],
    "certificate manager": ["ssl", "tls", "certificate", "证书", "ssl证书", "https"],
    "guardduty": ["threat detection", "威胁检测", "安全监控", "入侵检测"],
    "inspector": ["vulnerability", "漏洞扫描", "安全扫描"],
    "macie": ["data privacy", "数据隐私", "敏感数据"],
    "security hub": ["security posture", "安全中心", "安全态势"],

    # --- Analytics ---
    "athena": ["sql query", "query service", "lake query", "数据湖查询", "sql查询", "交互式查询"],
    "glue": ["etl", "data integration", "data catalog", "数据集成", "数据目录", "etl工具", "数据治理"],
    "kinesis": ["stream", "streaming", "event stream", "实时流", "流处理", "数据流", "stream processing"],
    "emr": ["hadoop", "spark", "big data", "大数据", "hadoop集群", "spark集群"],
    "opensearch": ["search", "elasticsearch", "search engine", "搜索", "搜索引擎", "全文检索", "日志分析"],
    "quicksight": ["bi", "business intelligence", "dashboard", "报表", "数据可视化", "bi工具"],
    "msk": ["kafka", "message streaming", "kafka集群", "消息流"],
    "lake formation": ["data lake", "数据湖", "湖仓"],
    "data pipeline": ["data workflow", "数据管道", "数据工作流"],
    "managed grafana": ["grafana", "dashboard", "监控面板", "grafana托管"],
    "managed prometheus": ["prometheus", "metrics", "指标采集", "prometheus托管"],

    # --- AI/ML ---
    "sagemaker": ["machine learning", "ml", "model training", "机器学习", "模型训练", "ml平台", "ai平台"],
    "bedrock": ["foundation model", "llm", "large language model", "大模型", "基础模型", "生成式ai", "genai", "大语言模型"],
    "lex": ["chatbot", "conversational ai", "对话机器人", "聊天机器人"],
    "polly": ["text to speech", "tts", "语音合成"],
    "rekognition": ["image recognition", "computer vision", "图像识别", "人脸识别", "视觉ai"],
    "transcribe": ["speech to text", "stt", "语音识别", "语音转文字"],
    "comprehend": ["nlp", "text analysis", "自然语言处理", "文本分析"],
    "textract": ["ocr", "document extraction", "文字识别", "文档提取"],
    "translate": ["translation", "翻译", "机器翻译"],
    "personalize": ["recommendation", "推荐", "个性化推荐"],
    "forecast": ["forecasting", "time series prediction", "预测", "时序预测"],
    "kendra": ["enterprise search", "企业搜索", "知识检索"],

    # --- Application Integration ---
    "sqs": ["queue", "message queue", "messaging", "消息队列", "队列", "mq"],
    "sns": ["pubsub", "topic", "notification", "pub sub", "消息通知", "发布订阅", "通知"],
    "eventbridge": ["event bus", "events", "event routing", "事件总线", "事件驱动", "事件路由"],
    "step functions": ["workflow", "state machine", "orchestration", "工作流", "状态机", "流程编排", "编排"],
    "appflow": ["saas integration", "数据集成", "saas连接"],
    "mq": ["message broker", "activemq", "rabbitmq", "消息代理", "消息中间件"],
    "appsync": ["graphql", "real time api", "graphql接口", "实时api"],

    # --- Management ---
    "cloudwatch": ["monitoring", "metrics", "logs", "observability", "监控", "日志", "指标", "可观测性", "告警"],
    "cloudformation": ["infrastructure as code", "iac", "基础设施即代码", "模板部署"],
    "cloudtrail": ["audit", "audit log", "审计", "操作审计", "审计日志"],
    "systems manager": ["ops", "operations", "运维", "运维管理", "系统管理"],
    "config": ["compliance", "configuration", "合规", "配置审计"],
    "trusted advisor": ["best practices", "最佳实践", "优化建议"],
    "control tower": ["multi account", "多账号", "组织管理"],

    # --- Developer Tools ---
    "codebuild": ["build", "ci", "构建", "持续集成"],
    "codepipeline": ["ci cd", "pipeline", "cicd", "持续交付", "流水线", "ci/cd"],
    "codecommit": ["git", "source control", "代码仓库", "版本控制"],
    "codedeploy": ["deployment", "cd", "部署", "持续部署"],
    "codeartifact": ["artifact", "package registry", "制品库", "包管理"],
    "cloud9": ["ide", "cloud ide", "在线ide", "云端开发"],
    "xray": ["tracing", "distributed tracing", "链路追踪", "分布式追踪", "trace"],

    # --- Front-end & Mobile ---
    "amplify": ["frontend", "mobile backend", "前端托管", "移动后端"],
    "pinpoint": ["push notification", "推送", "消息推送", "用户触达"],

    # --- Migration ---
    "dms": ["database migration", "数据迁移", "数据库迁移"],
    "datasync": ["data transfer", "数据同步", "数据传输"],
    "transfer family": ["sftp", "ftp", "file transfer", "文件传输"],

    # --- IoT ---
    "iot core": ["iot", "internet of things", "物联网", "设备管理", "iot平台"],
    "iot greengrass": ["edge computing", "iot edge", "边缘计算", "边缘iot"],
}

# ---------------------------------------------------------------------------
# Chinese-only aliases: map Chinese terms directly to icon IDs for concepts
# that don't have a natural English alias key above.
# ---------------------------------------------------------------------------
CHINESE_ALIASES = {
    "负载均衡": ["elb", "alb", "nlb"],
    "消息队列": ["sqs", "mq"],
    "缓存": ["elasticache"],
    "对象存储": ["s3"],
    "块存储": ["ebs"],
    "文件存储": ["efs"],
    "数据库": ["rds", "aurora", "dynamodb"],
    "关系数据库": ["rds", "aurora"],
    "容器": ["ecs", "eks", "fargate"],
    "容器编排": ["ecs", "eks"],
    "无服务器": ["lambda", "fargate"],
    "函数计算": ["lambda"],
    "网关": ["api gateway", "transit gateway"],
    "防火墙": ["waf", "network firewall"],
    "监控": ["cloudwatch"],
    "日志": ["cloudwatch"],
    "搜索": ["opensearch"],
    "大模型": ["bedrock"],
    "机器学习": ["sagemaker"],
    "数据仓库": ["redshift"],
    "图数据库": ["neptune"],
    "认证": ["cognito", "iam"],
    "鉴权": ["iam", "cognito"],
    "加密": ["kms"],
    "密钥": ["kms", "secrets manager"],
    "证书": ["certificate manager"],
    "审计": ["cloudtrail"],
    "编排": ["step functions"],
    "工作流": ["step functions"],
    "流水线": ["codepipeline"],
    "部署": ["codedeploy"],
    "构建": ["codebuild"],
    "域名": ["route 53"],
    "cdn": ["cloudfront"],
    "内容分发": ["cloudfront"],
    "专线": ["direct connect"],
    "物联网": ["iot core"],
    "边缘计算": ["iot greengrass"],
    "推荐": ["personalize"],
    "翻译": ["translate"],
    "语音": ["polly", "transcribe"],
    "图像识别": ["rekognition"],
    "数据湖": ["lake formation"],
    "大数据": ["emr"],
    "etl": ["glue"],
    "流处理": ["kinesis"],
    "事件驱动": ["eventbridge"],
    "通知": ["sns"],
    "备份": ["backup"],
}

# ---------------------------------------------------------------------------
# Category hints: map broad capability words to lists of alias keys that
# belong to that capability category.
# ---------------------------------------------------------------------------
CATEGORY_HINTS = {
    "compute": ["ec2", "lambda", "batch", "lightsail", "app runner", "auto scaling"],
    "containers": ["ecs", "eks", "ecr", "fargate"],
    "storage": ["s3", "efs", "ebs", "fsx", "glacier", "backup", "storage gateway", "snow family"],
    "database": ["rds", "aurora", "dynamodb", "elasticache", "redshift", "neptune", "documentdb", "timestream", "memorydb", "keyspaces", "qldb"],
    "network": ["vpc", "cloudfront", "route 53", "elb", "alb", "nlb", "api gateway", "direct connect", "transit gateway", "privatelink", "global accelerator", "network firewall"],
    "networking": ["vpc", "cloudfront", "route 53", "elb", "alb", "nlb", "api gateway", "direct connect", "transit gateway"],
    "security": ["iam", "cognito", "kms", "secrets manager", "waf", "shield", "certificate manager", "guardduty", "inspector", "macie", "security hub"],
    "analytics": ["athena", "glue", "kinesis", "emr", "opensearch", "quicksight", "msk", "lake formation", "data pipeline"],
    "ai": ["sagemaker", "bedrock", "lex", "polly", "rekognition", "transcribe", "comprehend", "textract", "translate", "personalize", "forecast", "kendra"],
    "ml": ["sagemaker", "bedrock", "lex", "polly", "rekognition", "transcribe", "comprehend", "textract", "translate", "personalize", "forecast", "kendra"],
    "machine learning": ["sagemaker", "bedrock"],
    "integration": ["sqs", "sns", "eventbridge", "step functions", "appflow", "mq", "appsync"],
    "messaging": ["sqs", "sns", "eventbridge", "mq", "msk", "kinesis"],
    "management": ["cloudwatch", "cloudformation", "cloudtrail", "systems manager", "config", "trusted advisor", "control tower"],
    "monitoring": ["cloudwatch", "xray", "managed grafana", "managed prometheus"],
    "devtools": ["codebuild", "codepipeline", "codecommit", "codedeploy", "codeartifact", "cloud9", "xray"],
    "cicd": ["codebuild", "codepipeline", "codecommit", "codedeploy"],
    "migration": ["dms", "datasync", "transfer family", "snow family"],
    "iot": ["iot core", "iot greengrass"],
}

# ---------------------------------------------------------------------------
# Generic (non-AWS) icons: map common concepts to their mxgraph icon IDs.
# These are useful for architecture diagrams involving users, the internet,
# on-premises servers, etc.
# ---------------------------------------------------------------------------
GENERIC_ICONS = {
    "user": {
        "name": "User",
        "resIcon": "mxgraph.aws4.user",
        "aliases": ["用户", "使用者", "person", "人"],
    },
    "users": {
        "name": "Users (multiple)",
        "resIcon": "mxgraph.aws4.users",
        "aliases": ["用户组", "多用户", "people", "团队", "team"],
    },
    "client": {
        "name": "Client",
        "resIcon": "mxgraph.aws4.client",
        "aliases": ["客户端", "终端"],
    },
    "internet": {
        "name": "Internet",
        "resIcon": "mxgraph.aws4.internet",
        "aliases": ["互联网", "公网", "外网", "internet"],
    },
    "mobile": {
        "name": "Mobile Client",
        "resIcon": "mxgraph.aws4.mobile_client",
        "aliases": ["手机", "移动端", "app", "手机端", "移动客户端", "mobile app"],
    },
    "laptop": {
        "name": "Laptop",
        "resIcon": "mxgraph.aws4.laptop",
        "aliases": ["笔记本", "电脑", "pc", "客户端电脑"],
    },
    "desktop": {
        "name": "Desktop",
        "resIcon": "mxgraph.aws4.illustration_desktop",
        "aliases": ["台式机", "桌面", "桌面端"],
    },
    "tablet": {
        "name": "Tablet",
        "resIcon": "mxgraph.aws4.tablet",
        "aliases": ["平板", "ipad"],
    },
    "browser": {
        "name": "Browser",
        "resIcon": "mxgraph.aws4.browser",
        "aliases": ["浏览器", "web客户端", "web browser"],
    },
    "server": {
        "name": "Traditional Server",
        "resIcon": "mxgraph.aws4.traditional_server",
        "aliases": ["服务器", "物理机", "物理服务器", "on-prem server", "本地服务器", "idc服务器"],
    },
    "database": {
        "name": "Generic Database",
        "resIcon": "mxgraph.aws4.generic_database",
        "aliases": ["通用数据库", "数据库图标", "db", "database icon"],
    },
    "firewall": {
        "name": "Generic Firewall",
        "resIcon": "mxgraph.aws4.generic_firewall",
        "aliases": ["通用防火墙", "防火墙图标"],
    },
    "cloud": {
        "name": "AWS Cloud",
        "resIcon": "mxgraph.aws4.aws_cloud",
        "aliases": ["云", "云平台", "云端", "cloud platform"],
    },
    "data center": {
        "name": "Data Center",
        "resIcon": "mxgraph.aws4.data_center",
        "aliases": ["数据中心", "机房", "idc"],
    },
    "corporate data center": {
        "name": "Corporate Data Center",
        "resIcon": "mxgraph.aws4.corporate_data_center",
        "aliases": ["企业机房", "企业数据中心", "on-premises", "本地机房"],
    },
    "office": {
        "name": "Office Building",
        "resIcon": "mxgraph.aws4.office_building",
        "aliases": ["办公室", "办公楼", "公司"],
    },
    "folder": {
        "name": "Folder",
        "resIcon": "mxgraph.aws4.folder",
        "aliases": ["文件夹", "目录"],
    },
    "disk": {
        "name": "Disk",
        "resIcon": "mxgraph.aws4.disk",
        "aliases": ["磁盘", "硬盘"],
    },
    "ssl": {
        "name": "SSL Padlock",
        "resIcon": "mxgraph.aws4.ssl_padlock",
        "aliases": ["ssl", "https", "锁", "安全锁"],
    },
    "sdk": {
        "name": "SDK",
        "resIcon": "mxgraph.aws4.generic_sdk",
        "aliases": ["sdk", "开发包", "开发工具包"],
    },
    "on premises": {
        "name": "On-Premises",
        "resIcon": "mxgraph.aws4.on_premises",
        "aliases": ["本地", "线下", "自建机房", "on-prem"],
    },
}


def normalize(text: str) -> str:
    """Normalize text for matching: lowercase, strip noise words, collapse whitespace."""
    text = text.lower().strip()
    text = text.replace("&", " and ")
    # Strip common Chinese suffixes that add noise
    for suffix in ["服务", "系统", "平台", "托管", "管理"]:
        if text.endswith(suffix) and len(text) > len(suffix):
            text = text[: -len(suffix)]
    # Remove AWS/Amazon prefixes for matching
    text = re.sub(r"aws|amazon|elastic\s+", " ", text)
    text = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def contains_term(text: str, term: str) -> bool:
    """Check if term appears as a whole word/phrase in text."""
    normalized_text = normalize(text)
    normalized_term = normalize(term)
    if not normalized_text or not normalized_term:
        return False
    # For Chinese characters, do substring match
    if re.search(r"[\u4e00-\u9fff]", normalized_term):
        return normalized_term in normalized_text
    return f" {normalized_term} " in f" {normalized_text} "


def load_icon_data() -> list[dict[str, str]]:
    """Load icon data from aws-icons.md."""
    icons = []
    script_dir = Path(__file__).parent
    aws_icons_path = script_dir.parent / "references" / "aws-icons.md"

    if not aws_icons_path.exists():
        return icons

    content = aws_icons_path.read_text(encoding="utf-8")
    current_category = "uncategorized"
    pattern = r"\|\s*([^|]+?)\s*\|\s*(mxgraph\.aws4\.[a-z0-9_]+)\s*\|"

    for line in content.splitlines():
        category_match = re.match(r"^###\s+\d+\.\d+\.\s+(.+)$", line.strip())
        if category_match:
            current_category = category_match.group(1).strip()
            continue

        match = re.search(pattern, line)
        if not match:
            continue

        service_name = match.group(1).strip()
        res_icon = match.group(2).strip()
        normalized_name = normalize(service_name)
        alias_terms = []

        for alias_key, alias_values in ALIASES.items():
            normalized_key = normalize(alias_key)
            if normalized_name == normalized_key or contains_term(normalized_name, normalized_key):
                alias_terms.extend(alias_values)
            elif any(
                normalize(alias) == normalized_name or contains_term(normalized_name, alias)
                for alias in alias_values
            ):
                alias_terms.extend(alias_values)

        icons.append(
            {
                "name": service_name,
                "resIcon": res_icon,
                "category": current_category,
                "normalized_name": normalized_name,
                "keywords": " ".join(alias_terms),
            }
        )

    return icons


def query_terms(query: str) -> set[str]:
    """Expand a query into a set of search terms using aliases and categories."""
    normalized_query = normalize(query)
    terms = set(normalized_query.split())
    terms.add(normalized_query)

    # --- Expand via ALIASES ---
    for alias_key, alias_values in ALIASES.items():
        normalized_key = normalize(alias_key)
        normalized_aliases = {normalize(alias) for alias in alias_values}
        if normalized_query == normalized_key or normalized_query in normalized_aliases:
            terms.update(normalized_aliases)
            terms.add(normalized_key)
        elif contains_term(normalized_key, normalized_query) or any(
            contains_term(alias, normalized_query) for alias in normalized_aliases
        ):
            terms.update(normalized_aliases)
            terms.add(normalized_key)

    # --- Expand via CHINESE_ALIASES ---
    for cn_term, alias_keys in CHINESE_ALIASES.items():
        if normalized_query == normalize(cn_term) or contains_term(normalized_query, cn_term):
            terms.add(normalize(cn_term))
            for akey in alias_keys:
                terms.add(normalize(akey))
                # Also pull in the English aliases for each key
                if akey in ALIASES:
                    terms.update(normalize(a) for a in ALIASES[akey])

    # --- Expand via CATEGORY_HINTS ---
    for category, hints in CATEGORY_HINTS.items():
        hint_terms = {normalize(item) for item in hints}
        if normalized_query == normalize(category) or normalized_query in hint_terms:
            terms.add(normalize(category))
            terms.update(hint_terms)

    return {term for term in terms if term}


def score_icon(icon: dict[str, str], query: str, terms: set[str]) -> tuple[float, list[str]]:
    """Score how well an icon matches the query.  Higher = better match."""
    normalized_query = normalize(query)
    score = 0.0
    reasons = []
    normalized_res_icon = normalize(icon["resIcon"])
    normalized_category = normalize(icon["category"])
    normalized_keywords = normalize(icon["keywords"])

    # --- Exact official name match ---
    if normalized_query == icon["normalized_name"]:
        score += 120
        reasons.append("official-name-exact")
    elif contains_term(icon["normalized_name"], normalized_query):
        score += 70
        reasons.append("official-name-partial")

    # --- Icon ID match ---
    if contains_term(normalized_res_icon, normalized_query):
        score += 55
        reasons.append("icon-id-match")

    # --- Category exact match ---
    if normalized_query == normalized_category:
        score += 35
        reasons.append("category-exact")

    # --- Chinese direct match in keywords ---
    if re.search(r"[\u4e00-\u9fff]", normalized_query):
        if normalized_query in normalized_keywords:
            score += 60
            reasons.append("chinese-keyword-exact")
        elif any(contains_term(normalized_keywords, t) for t in normalized_query if re.search(r"[\u4e00-\u9fff]", t)):
            score += 25
            reasons.append("chinese-keyword-partial")

    # --- Term-by-term scoring ---
    for term in terms:
        if not term:
            continue
        if contains_term(icon["normalized_name"], term):
            score += 18
        if contains_term(normalized_res_icon, term):
            score += 12
        if contains_term(normalized_keywords, term):
            score += 15
            if f"alias:{term}" not in reasons:
                reasons.append(f"alias:{term}")
        if contains_term(normalized_category, term):
            score += 8

    # --- Fuzzy name similarity ---
    similarity = SequenceMatcher(None, normalized_query, icon["normalized_name"]).ratio()
    score += similarity * 30
    if similarity >= 0.72:
        reasons.append("fuzzy-name")

    # --- Bigram boost for multi-word queries ---
    query_words = normalized_query.split()
    if len(query_words) >= 2:
        name_words = icon["normalized_name"].split()
        shared = set(query_words) & set(name_words)
        if len(shared) >= 2:
            score += 25 * len(shared)
            reasons.append("multi-word-overlap")

    return score, reasons


def search_generic_icons(query: str) -> list[dict]:
    """Search generic (non-AWS-service) icons."""
    normalized_query = normalize(query)
    results = []

    for key, info in GENERIC_ICONS.items():
        score = 0.0
        reasons = []
        normalized_key = normalize(key)
        normalized_name = normalize(info["name"])

        # Exact key match
        if normalized_query == normalized_key:
            score += 120
            reasons.append("generic-key-exact")
        elif contains_term(normalized_key, normalized_query):
            score += 60
            reasons.append("generic-key-partial")

        # Name match
        if normalized_query == normalized_name:
            score += 100
            reasons.append("generic-name-exact")
        elif contains_term(normalized_name, normalized_query):
            score += 50
            reasons.append("generic-name-partial")

        # Alias match
        for alias in info["aliases"]:
            normalized_alias = normalize(alias)
            if normalized_query == normalized_alias:
                score += 90
                reasons.append(f"generic-alias:{alias}")
                break
            elif contains_term(normalized_alias, normalized_query) or contains_term(normalized_query, normalized_alias):
                score += 40
                reasons.append(f"generic-alias-partial:{alias}")

        # Fuzzy
        similarity = SequenceMatcher(None, normalized_query, normalized_key).ratio()
        score += similarity * 20

        if score > 0:
            results.append({
                "name": info["name"],
                "resIcon": info["resIcon"],
                "category": "Generic / General",
                "normalized_name": normalized_name,
                "keywords": " ".join(info["aliases"]),
                "score": score,
                "reasons": ",".join(sorted(set(reasons))) if reasons else "weak-match",
            })

    return results


def search_icon(query: str) -> list[dict]:
    """Search icons matching the query across AWS services and generic icons."""
    icons = load_icon_data()
    results = []
    terms = query_terms(query)

    # Score AWS service icons
    for icon in icons:
        score, reasons = score_icon(icon, query, terms)
        if score <= 0:
            continue
        enriched = dict(icon)
        enriched["score"] = score
        enriched["reasons"] = ",".join(sorted(set(reasons))) if reasons else "weak-match"
        results.append(enriched)

    # Score generic icons
    generic_results = search_generic_icons(query)
    results.extend(generic_results)

    # Sort by score descending, then name ascending
    results.sort(key=lambda item: (-item["score"], item["name"]))
    return results[:10]


def format_style(res_icon: str) -> str:
    """Generate a ready-to-paste draw.io style string."""
    return (
        f"shape=mxgraph.aws4.resourceIcon;resIcon={res_icon};"
        f"labelBackgroundColor=#ffffff;sketch=0;fontFamily=Helvetica;"
    )


def main():
    if len(sys.argv) < 2:
        print("Usage: python find_aws_icon.py [--style] <query>")
        print("Example: python find_aws_icon.py ec2")
        print("         python find_aws_icon.py --style lambda")
        print("         python find_aws_icon.py 缓存")
        print("         python find_aws_icon.py 负载均衡")
        sys.exit(1)

    args = sys.argv[1:]
    show_style = False
    if "--style" in args:
        show_style = True
        args.remove("--style")

    query = " ".join(args)
    results = search_icon(query)

    if not results:
        print(f"No icons found for: {query}")
        sys.exit(1)

    print(f"Found {len(results)} icon(s) for '{query}':\n")
    for result in results:
        print(f"  Service:  {result['name']}")
        print(f"  Category: {result['category']}")
        print(f"  resIcon:  {result['resIcon']}")
        print(f"  Score:    {result['score']:.1f}")
        print(f"  Why:      {result['reasons']}")
        if show_style:
            print(f"  Style:    {format_style(result['resIcon'])}")
        else:
            print(f"  Style:    shape=mxgraph.aws4.resourceIcon;resIcon={result['resIcon']};")
        print()


if __name__ == "__main__":
    main()
