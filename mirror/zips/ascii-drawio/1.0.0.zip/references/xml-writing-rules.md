# XML 书写规范

生成 draw.io XML 前必须逐项遵守以下规则。形状/连线模板见 `drawio-xml-guide.md`。

---

## B-1. 禁止 html=1（最高优先级 — 强制规则）

**所有 mxCell 的 style 属性中严禁包含 `html=1`。违反此规则将导致以下严重渲染错误：**

1. `fontStyle=1`（加粗）被渲染为可见的 `<b>` 标签文字
2. 文字尺寸计算异常，导致文字溢出节点边界、相互重叠
3. 特殊字符被错误解析

**换行方式**：使用 `&#xa;` 实现换行（纯文本模式），禁止使用 `<br>`。

**生成 XML 后必须执行验证**：全文搜索 `html=1`，如有残留必须删除后才能保存文件。

---

## B0. 页面白底（强制规则）

`mxGraphModel` 根标签必须加 `background="#FFFFFF"` 属性。

---

## B1. XML 元素顺序

箭头必须放在节点之前（背景层），防止箭头压在文字上：

```
① 标题/元数据 → ② 背景框 → ③ 背景框标题 → ④ 所有边(edge) → ⑤ 所有节点(vertex)
```

---

## B2. 箭头必须指定锚点方向（强制规则）

**每条箭头都必须显式声明 `exitX/exitY/exitPerimeter` 和 `entryX/entryY/entryPerimeter`，禁止省略。**

| 箭头走向 | exit（出口） | entry（入口） |
|----------|-------------|--------------|
| 向右 | `exitX=1;exitY=0.5;exitPerimeter=0;` | `entryX=0;entryY=0.5;entryPerimeter=0;` |
| 向左 | `exitX=0;exitY=0.5;exitPerimeter=0;` | `entryX=1;entryY=0.5;entryPerimeter=0;` |
| 向下 | `exitX=0.5;exitY=1;exitPerimeter=0;` | `entryX=0.5;entryY=0;entryPerimeter=0;` |
| 向上 | `exitX=0.5;exitY=0;exitPerimeter=0;` | `entryX=0.5;entryY=1;entryPerimeter=0;` |

`text` 类型元素不支持锚点，必须用显式坐标（`mxPoint as="sourcePoint/targetPoint"`）。

---

## B3. 边标签规则（底线规则）

### 标签位置

标签必须放在线的**旁侧**，禁止居中覆盖在线上：

- `labelBackgroundColor` 必须为 `none`，禁止设为 `#FFFFFF`
- 标签与最近节点边界距离 >= 16px
- 两条平行线的标签不能重叠

**位置速查**：

| 场景 | 推荐设置 |
|------|---------|
| 水平线，标签在线上方 | `verticalAlign=bottom` |
| 水平线，标签在线下方 | `verticalAlign=top` |
| 竖直线，标签在线左侧 | `align=right` |
| 竖直线，标签在线右侧 | `align=left` |
| 标签靠近起点 | `geometry x=-0.8 relative=1` |
| 标签靠近终点 | `geometry x=0.8 relative=1` |

### 标签偏移

用 `offset` 调整标签距箭头的距离：

```xml
<mxPoint x="0" y="-40" as="offset"/>  <!-- 上方 -->
<mxPoint x="0" y="40" as="offset"/>   <!-- 下方 -->
```

---

## B4. 拐点坐标必须精确计算

`Array as="points"` 中的拐点坐标必须基于节点的**实际 x/y/width/height** 计算：

```
节点中心 x = node.x + node.width / 2
节点中心 y = node.y + node.height / 2
节点右边缘 x = node.x + node.width
节点底边缘 y = node.y + node.height
```

**生成 XML 前先列出坐标表**，据此计算所有拐点，严禁凭感觉填写。

---

## B5. 背景框内元素边距

内部元素距边框**至少 30px**，防止视觉溢出。背景框标题用空 `value=""` 的框体 + 单独 `text` 节点，框内节点顶部留 >= 40px 给标题。

---

## B6. 箭头粗细规范

| 场景 | strokeWidth | 说明 |
|------|-------------|------|
| 普通调用关系 | `2` | 基础线宽 |
| 主流程关键路径 | `3` | 加粗突出 |
| 辅助/数据读取 | `1.5` + `dashed=1` | 虚线区分 |

---

## B7. 坐标规划表（生成 XML 前必须输出）

```
节点ID      x    y    w    h    标签         图标
-------------------------------------------------------------
bg_stage1   40   40   800  200  阶段一       -
n_user      80   80   200  84   用户         mxgraph.aws4.user
...
```

用这张表计算所有拐点坐标和间距验证，**禁止凭感觉估算**。
