# draw.io XML Reference Guide

配色见 `color-palettes.md`，尺寸/间距见 `style-system.md`。

## ⛔ 禁止使用 html=1（最高优先级规则）

**所有 mxCell 的 style 中严禁包含 `html=1`。** 这是导致图表中出现 `<b>` 标签文字和文字重叠的根本原因。

- 当 `html=1` 存在时，draw.io 会把 `fontStyle=1`（加粗）渲染为 HTML `<b>` 标签，导致图中可见 `<b>` 文字
- 当 `html=1` 存在时，文字尺寸计算方式不同，容易导致文字溢出节点、相互重叠
- **换行方式**：使用 `&#xa;` 实现换行（纯文本模式），**禁止使用 `<br>`**
- 生成 XML 后必须全文搜索 `html=1`，如有残留则删除

## Root Structure

**必须加 `background="#FFFFFF"` 确保白底页面。**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1"
              tooltips="1" connect="1" arrows="1" fold="1" page="1"
              pageScale="1" pageWidth="1654" pageHeight="1169"
              math="0" shadow="0" background="#FFFFFF">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <!-- shapes go here, all with parent="1" -->
  </root>
</mxGraphModel>
```

## Shape Templates

### Rounded Rectangle (service/component)
```xml
<mxCell id="n1" value="Service Name" style="rounded=1;arcSize=8;
  fillColor=#EBF3FA;strokeColor=#5B8DB8;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=22;fontStyle=1;
  whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="100" y="100" width="200" height="80" as="geometry"/>
</mxCell>
```

### Cylinder (database)
```xml
<mxCell id="n2" value="Database" style="shape=mxgraph.flowchart.database;
  fillColor=#EBF7EE;strokeColor=#5FAD78;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=20;
  whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="300" y="100" width="200" height="80" as="geometry"/>
</mxCell>
```

### Queue / Parallelogram (async)
```xml
<mxCell id="n3" value="Message Queue" style="shape=parallelogram;
  fillColor=#FDF3E7;strokeColor=#E8944A;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=20;
  whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="500" y="100" width="200" height="80" as="geometry"/>
</mxCell>
```

### Section Label (bold header)
```xml
<mxCell id="h1" value="Frontend Layer" style="text;
  strokeColor=none;fillColor=none;
  fontFamily=Helvetica;fontSize=24;fontStyle=1;fontColor=#1A2B3C;
  align=left;verticalAlign=middle;" vertex="1" parent="1">
  <mxGeometry x="40" y="60" width="300" height="30" as="geometry"/>
</mxCell>
```

### Section Background Box
```xml
<mxCell id="b1" value="" style="rounded=1;arcSize=4;
  fillColor=#F8FBFF;strokeColor=#C5DAF0;
  dashed=0;" vertex="1" parent="1">
  <mxGeometry x="30" y="50" width="600" height="150" as="geometry"/>
</mxCell>
```

### Stage Group Box + Title Label

```xml
<!-- 先写背景框（背景层），节点写在后面（前景层）-->
<mxCell id="bg_stage1" value="" style="rounded=1;arcSize=4;
  fillColor=#FDF3E7;strokeColor=#E8944A;strokeWidth=2;dashed=0;" vertex="1" parent="1">
  <mxGeometry x="60" y="280" width="800" height="220" as="geometry"/>
</mxCell>
<!-- 标题标签贴在背景框左上角 -->
<mxCell id="bg_stage1_label" value="阶段二：并行收集（×4）" style="text;
  strokeColor=none;fillColor=none;
  fontFamily=Helvetica;fontSize=24;fontStyle=1;fontColor=#E8944A;
  align=left;verticalAlign=middle;" vertex="1" parent="1">
  <mxGeometry x="70" y="284" width="300" height="30" as="geometry"/>
</mxCell>
```

### Status Badge（终态结果节点）

```xml
<!-- 通过：绿色 + 勾 -->
<mxCell id="n_pass" value="✓ 通过" style="rounded=1;arcSize=8;
  fillColor=#EBF7EE;strokeColor=#5FAD78;strokeWidth=2;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=22;fontStyle=1;whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="100" y="200" width="200" height="80" as="geometry"/>
</mxCell>
<!-- 拦截：橙色 + 叉 -->
<mxCell id="n_block" value="✗ 拦截" style="rounded=1;arcSize=8;
  fillColor=#FDF3E7;strokeColor=#E8944A;strokeWidth=2;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=22;fontStyle=1;whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="300" y="200" width="200" height="80" as="geometry"/>
</mxCell>
<!-- 待定：灰色 -->
<mxCell id="n_pending" value="◷ 待定" style="rounded=1;arcSize=8;
  fillColor=#F2F4F6;strokeColor=#8A9BAE;strokeWidth=2;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=22;fontStyle=1;whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="500" y="200" width="200" height="80" as="geometry"/>
</mxCell>
```

## Connection Templates

### Solid Arrow (sync call) — 水平向右
```xml
<mxCell id="e1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#5B8DB8;strokeWidth=2;
  exitX=1;exitY=0.5;exitPerimeter=0;
  entryX=0;entryY=0.5;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n1" target="n2" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Solid Arrow (sync call) — 垂直向下
```xml
<mxCell id="e1b" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#5B8DB8;strokeWidth=2;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n1" target="n2" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Dashed Arrow (async / data flow)
```xml
<mxCell id="e2" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#E8944A;strokeWidth=2;dashed=1;dashPattern=8 4;
  exitX=1;exitY=0.5;exitPerimeter=0;
  entryX=0;entryY=0.5;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n1" target="n3" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Bold Arrow — 主流程关键路径（strokeWidth=3）

```xml
<mxCell id="e_bold" value="主流程标签" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#5B8DB8;strokeWidth=3;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#5B8DB8;fontStyle=1;
  labelBackgroundColor=none;labelBorderColor=none;" edge="1" source="n1" target="n2" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Edge with Label

```xml
<mxCell id="e3" value="REST/JSON" style="edgeStyle=orthogonalEdgeStyle;
  strokeColor=#5B8DB8;strokeWidth=1.5;dashed=0;
  exitX=1;exitY=0.5;exitPerimeter=0;
  entryX=0;entryY=0.5;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#5B8DB8;
  labelBackgroundColor=none;" edge="1" source="n1" target="n2" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Arrow with Explicit Waypoints (avoid crossing)

```xml
<mxCell id="e4" style="edgeStyle=orthogonalEdgeStyle;strokeColor=#5B8DB8;strokeWidth=2;
  endArrow=block;endFill=1;" edge="1" source="n1" target="n2" parent="1">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="800" y="200"/>
      <mxPoint x="800" y="450"/>
    </Array>
  </mxGeometry>
</mxCell>
```

## Fan-out / Fan-in / 引用节点模板

### Fan-out via Decision Diamond（决策菱形分叉）

一个源节点根据不同条件走不同分支（如 low/medium/high）。菱形从不同边出发，避免线交叉。

```xml
<!-- 菱形决策节点 -->
<mxCell id="n_decision" value="score?" style="shape=rhombus;
  fillColor=#FFF3E0;strokeColor=#F57C00;strokeWidth=2;fontColor=#BF360C;
  fontFamily=Helvetica;fontSize=20;fontStyle=1;
  whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="500" y="300" width="140" height="100" as="geometry"/>
</mxCell>
<!-- 从菱形左边出发 → 左侧分支 -->
<mxCell id="e_left" value="low" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#388E3C;strokeWidth=2;
  exitX=0;exitY=0.5;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#388E3C;fontStyle=1;
  labelBackgroundColor=none;" edge="1" source="n_decision" target="n_left" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
<!-- 从菱形底部出发 → 中间分支 -->
<mxCell id="e_down" value="medium" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=3;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#F57C00;fontStyle=1;
  labelBackgroundColor=none;" edge="1" source="n_decision" target="n_center" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
<!-- 从菱形右边出发 → 右侧分支 -->
<mxCell id="e_right" value="high" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#E64A19;strokeWidth=2;
  exitX=1;exitY=0.5;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#E64A19;fontStyle=1;
  labelBackgroundColor=none;" edge="1" source="n_decision" target="n_right" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Fan-out via Distribution Point（分发点并行触发）

源节点同时触发多个并行目标，无条件区分。用 1 条主干线到分发点，再从分发点短线到各目标。

```xml
<!-- 分发点（不可见小圆） -->
<mxCell id="n_dist" value="" style="shape=ellipse;
  fillColor=none;strokeColor=none;" vertex="1" parent="1">
  <mxGeometry x="566" y="496" width="8" height="8" as="geometry"/>
</mxCell>
<!-- 源节点 → 分发点（主干线） -->
<mxCell id="e_trunk" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=3;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=none;endFill=0;" edge="1" source="n_source" target="n_dist" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
<!-- 分发点 → 目标1（左） -->
<mxCell id="e_fan1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=2;
  exitX=0;exitY=0.5;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n_dist" target="n_t1" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
<!-- 分发点 → 目标2（中） -->
<mxCell id="e_fan2" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=2;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n_dist" target="n_t2" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
<!-- 分发点 → 目标3（右） -->
<mxCell id="e_fan3" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=2;
  exitX=1;exitY=0.5;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;" edge="1" source="n_dist" target="n_t3" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Fan-out to Container（连到容器/背景框）

源节点触发一个阶段整体执行，只画 1 条线到入口节点，框内组件视为隐式接收者。

```xml
<!-- 只画 1 条线到容器入口 -->
<mxCell id="e_to_stage" value="触发并行收集" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#F57C00;strokeWidth=3;
  exitX=0.5;exitY=1;exitPerimeter=0;
  entryX=0.5;entryY=0;entryPerimeter=0;
  endArrow=block;endFill=1;
  fontFamily=Helvetica;fontSize=18;fontColor=#F57C00;fontStyle=1;
  labelBackgroundColor=none;" edge="1" source="n_source" target="bg_stage" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### Reference Node（引用节点 — 避免跨区长线）

当数据源距消费者太远时，在消费者附近放一个虚线引用节点，只画短线。

```xml
<!-- 引用节点（虚线边框 + 斜体标签） -->
<mxCell id="n_kb_ref" value="Knowledge DB (ref)" style="rounded=1;arcSize=8;
  fillColor=#ECEFF1;strokeColor=#78909C;strokeWidth=1.5;
  dashed=1;dashPattern=8 4;
  fontColor=#78909C;fontFamily=Helvetica;fontSize=18;fontStyle=2;
  whiteSpace=wrap;" vertex="1" parent="1">
  <mxGeometry x="480" y="500" width="200" height="60" as="geometry"/>
</mxCell>
<!-- 消费者到引用节点的短虚线 -->
<mxCell id="e_to_ref" value="get" style="edgeStyle=orthogonalEdgeStyle;rounded=0;
  strokeColor=#78909C;strokeWidth=1.5;dashed=1;dashPattern=8 4;
  exitX=0;exitY=0.5;exitPerimeter=0;
  entryX=1;entryY=0.5;entryPerimeter=0;
  endArrow=open;endFill=0;
  fontFamily=Helvetica;fontSize=18;fontColor=#78909C;
  labelBackgroundColor=none;" edge="1" source="n_consumer" target="n_kb_ref" parent="1">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

---

## Anchor Points 速查

| Value | Side |
|-------|------|
| `exitX=1;exitY=0.5` | right center (→) |
| `exitX=0;exitY=0.5` | left center (←) |
| `exitX=0.5;exitY=0` | top center (↑) |
| `exitX=0.5;exitY=1` | bottom center (↓) |

## Layout Tips

- Use `x` increments of **200–240** between columns, `y` increments of **120–140** between rows
- Group related nodes in section background boxes (draw boxes first, nodes on top)
- IDs must be unique strings; use sequential `n1,n2...`, `e1,e2...`, `b1,b2...`, `h1,h2...`
