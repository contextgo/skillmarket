# 生成后质检 Checklist

生成 XML 后**必须逐项执行**。标记为 BLOCK 的项为**底线项**——不通过则必须修正后重新输出 XML，禁止带缺陷交付。

具体数值阈值见 `style-system.md`，防重叠规则见 `design-principles.md`。

---

## A. 背景与页面

- [ ] **全文搜索 `html=1`，确认无任何残留** [BLOCK] — 残留会导致 `<b>` 标签显示和文字重叠
- [ ] **全文搜索 `<br>`，确认无任何残留** [BLOCK] — 换行必须用 `&#xa;`
- [ ] `mxGraphModel` 已加 `background="#FFFFFF"` [BLOCK]
- [ ] 节点填充色使用选定的 `COLOR_PALETTE`
- [ ] 字号达标（参照 `style-system.md` 字号规范） [BLOCK]

## B. 节点尺寸与文字

- [ ] 普通节点 >= `200 x 80` [BLOCK]
- [ ] 图标+标签节点 >= `220 x 90` [BLOCK]
- [ ] 每个节点的文字宽度通过验证（参照 `style-system.md` 文字宽度公式） [BLOCK]

## C. 箭头与连线

- [ ] 边在 XML 中排在节点之前 [BLOCK]
- [ ] 每条边都声明了 `exitX/exitY/exitPerimeter` 和 `entryX/entryY/entryPerimeter` [BLOCK]
- [ ] 主流程箭头 `strokeWidth=3`，辅助箭头 `strokeWidth=1.5;dashed=1`
- [ ] 线交叉总数 <= 1 [BLOCK]
- [ ] 无 >= 3 条独立 edge 从同一节点出发到不同目标（fan-out 需用 C8.1 模式模板：决策菱形/分发点/连到容器）[BLOCK]
- [ ] 无跨越 >= 2 个背景框的辅助连线（需用 C8.3 替代方案：引用节点/标签标注/就近放置）[BLOCK]

## D. 防重叠验证 [BLOCK]

- [ ] 节点不互相重叠
- [ ] 边标签 `labelBackgroundColor=none`，放在线旁侧
- [ ] 边标签不压节点（距离 >= 16px）
- [ ] 背景框标题不压内容（y 差 >= 50px）
- [ ] 连线不穿不相关节点
- [ ] 多条平行线不重叠（偏移 >= 20px）

## E. 间距验证

- [ ] 水平相邻节点间距 >= 160px [BLOCK]
- [ ] 垂直相邻节点间距 >= 120px [BLOCK]
- [ ] 背景框上内边距 >= 60px [BLOCK]
- [ ] 背景框左右下内边距 >= 40px [BLOCK]

## F. 布局与层级

- [ ] 每个逻辑阶段有背景框 + 颜色标题标签
- [ ] 同层节点 y 坐标一致，主流程列对齐

## G. 图标与视觉

- [ ] 至少 50% 的节点使用了图标或颜色区分
- [ ] 使用了至少 2 种不同的形状
- [ ] 有元数据（标题、日期）
- [ ] 图标节点（`verticalLabelPosition=bottom`）标签 ≤4 中文字，否则改用圆角矩形 [BLOCK]
- [ ] 所有图标节点已设置 `labelWidth` ≥ 200（详见 `visual-elements.md`） [BLOCK]

## H. 最终验证

- [ ] 坐标规划表与 XML 中的实际坐标一致
- [ ] XML 元素顺序正确（标题 → 背景框 → 标签 → 边 → 节点）
- [ ] 无已知缺陷遗留

---

## BLOCK 项失败处理

1. 禁止保存文件
2. 修正坐标规划表
3. 重新生成 XML
4. 再次执行本 checklist
5. 全部通过后才能保存 `.drawio` 文件
