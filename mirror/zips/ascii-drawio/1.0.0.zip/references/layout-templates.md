# Layout Templates for draw.io

> 以下模板仅为常见布局的 XML 起点，**不代表固定选项**。
> 实际使用哪种布局由用户意图决定；若用户选择的布局不在此列，直接按 draw.io XML 规范构造即可。

尺寸/间距规范见 `style-system.md`，防重叠/交叉规则见 `design-principles.md`，生成后质检见 `quality-checklist.md`。

---

## 1. Swimlane Layout（泳道图）

水平泳道按角色分层。每个泳道高度 = 180px，标题栏 30px。

```xml
<!-- Swimlane container -->
<mxCell id="swim1" value="System" style="shape=pool;startSize=30;horizontal=1;
  fillColor=#F2F4F6;strokeColor=#8A9BAE;fontFamily=Helvetica;fontSize=18;fontStyle=1;fontColor=#2C3E50;"
  vertex="1" parent="1">
  <mxGeometry x="40" y="40" width="1400" height="580" as="geometry"/>
</mxCell>
<!-- Lane 1 -->
<mxCell id="lane1" value="User" style="swimlane;startSize=30;horizontal=0;
  fillColor=#EBF3FA;strokeColor=#5B8DB8;fontFamily=Helvetica;fontSize=16;fontStyle=1;fontColor=#2C3E50;"
  vertex="1" parent="swim1">
  <mxGeometry x="0" y="30" width="1400" height="180" as="geometry"/>
</mxCell>
<!-- Lane 2 -->
<mxCell id="lane2" value="Backend" style="swimlane;startSize=30;horizontal=0;
  fillColor=#EBF7EE;strokeColor=#5FAD78;fontFamily=Helvetica;fontSize=16;fontStyle=1;fontColor=#2C3E50;"
  vertex="1" parent="swim1">
  <mxGeometry x="0" y="210" width="1400" height="180" as="geometry"/>
</mxCell>
<!-- Lane 3 -->
<mxCell id="lane3" value="Database" style="swimlane;startSize=30;horizontal=0;
  fillColor=#FDF3E7;strokeColor=#E8944A;fontFamily=Helvetica;fontSize=16;fontStyle=1;fontColor=#2C3E50;"
  vertex="1" parent="swim1">
  <mxGeometry x="0" y="390" width="1400" height="180" as="geometry"/>
</mxCell>
<!-- Nodes go inside lanes using parent="lane1" etc. x/y relative to lane -->
```

## 2. Layered Architecture Layout（分层架构图）

水平分层（行），每行一个层级。使用背景框。

结构（上到下）：Client -> Gateway/LB -> Services -> Data

```
y=60:   Client layer   (background box, blue,  height=160)
y=280:  API / Gateway  (background box, green, height=160)
y=500:  Services       (background box, orange, height=160)
y=720:  Data / DB      (background box, gray,  height=160)
```

每个背景框：`x=40, width=page-80, height=160`。节点在框内 y+60 开始。层间距 60px。

## 3. Fishbone (Ishikawa) Layout（鱼骨图）

主干水平居中；分支斜向 45 度。

```
主干：水平箭头 from (100,400) to (1300,400)
结果框：圆角矩形 at x=1300,y=370 w=200 h=60

上方分支（斜向右下）：
  原因 1: x=250,y=180 -> 主干交汇 x=400,y=400
  原因 2: x=550,y=180 -> 主干交汇 x=700,y=400
  原因 3: x=850,y=180 -> 主干交汇 x=1000,y=400

下方分支（斜向右上）：
  原因 4: x=250,y=620 -> x=400,y=400
  原因 5: x=550,y=620 -> x=700,y=400
  原因 6: x=850,y=620 -> x=1000,y=400
```

## 4. Flowchart Layout（流程图）

上到下顺序流程，带决策菱形。

节点垂直间距 140px。所有节点水平居中对齐 x=500。

形状：
- **Start/End**: `shape=mxgraph.flowchart.terminator` (blue fill), w=200, h=60
- **Process**: rounded rectangle (blue fill), w=240, h=80
- **Decision**: `shape=rhombus` (orange fill), w=200, h=100, labels on exit edges (Yes/No)
- **I/O**: `shape=parallelogram` (gray fill), w=220, h=70

## 5. ER / Entity Relationship Layout（ER 图）

实体用圆角矩形，属性用椭圆，关系用菱形。

实体间距 >= 300px。属性围绕实体放置，距实体边缘 60px。

```xml
<!-- Entity -->
<mxCell id="ent1" value="User" style="rounded=1;arcSize=8;
  fillColor=#EBF3FA;strokeColor=#5B8DB8;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=18;fontStyle=1;" vertex="1" parent="1">
  <mxGeometry x="100" y="200" width="200" height="80" as="geometry"/>
</mxCell>
```
