# 视觉元素工具箱

## 可用元素类型

| 元素 | 用途 | 实现方式 |
|------|------|----------|
| 图标+标签复合节点 | 服务/组件展示 | `shape=mxgraph.aws4.resourceIcon;resIcon=...` + 下方标签 |
| 状态徽章 | 终态（通过/拦截/待定） | 圆角矩形 + 配色 + 符号前缀 |
| 编号圆圈 | 步骤序号标注 | `shape=ellipse` + 数字 |
| 注释气泡 | 补充说明 | `shape=callout;rounded=1` |
| 虚线分组框 | 逻辑分组（非阶段） | `rounded=1;dashed=1;dashPattern=8 4` |
| 分阶段背景框 | 阶段/泳道区分 | 背景色矩形 + 标题标签 |
| 图例框 | 线型/颜色说明 | 固定位置文本组 |
| 平行四边形 | 异步/人工介入节点 | `shape=parallelogram` |
| 圆柱体 | 数据库 | `shape=mxgraph.flowchart.database` |
| 菱形 | 决策判断 | `shape=rhombus` |

## 图标选择策略

为每个节点按以下优先级选择图标：
1. **精确匹配**：节点名称对应具体 AWS 服务 → 使用该服务图标
2. **类别匹配**：节点是某类能力（如"缓存"）→ 搜索最匹配的服务图标
3. **通用图标**：节点是通用概念（用户/服务器/数据库）→ 使用 Generic Icons
4. **无图标**：找不到合适图标 → 使用纯矩形/圆柱体等形状

**原则**：宁可用通用图标，也不要选错图标。找不到精确图标时退回泛化图标。

## 图标节点标签溢出问题（重要）

AWS 图标节点（`shape=mxgraph.aws4.resourceIcon`）固定尺寸 80x80，使用 `verticalLabelPosition=bottom` 将标签放在图标下方时，存在以下已知问题：

### 问题描述

1. **标签宽度受限**：即使设置了 `labelWidth=200`，中文标签在 fontSize=20 时 6 个字就会超过 200px 触发换行
2. **标签溢出遮挡**：底部标签会与下方相邻节点重叠，垂直间距需预留 **图标高度(80) + 标签行高(~30/行) + 间距(40)** = 至少 150-190px
3. **标签渲染异常**：长中文标签在 draw.io 导出时可能出现字符重叠/乱码

### 推荐做法

**优先使用"圆角矩形内嵌文字"代替"图标+底部标签"**，除非标签极短（≤4 个中文字符）：

```xml
<!-- ✓ 推荐：圆角矩形，文字内嵌，无溢出风险 -->
<mxCell id="n1" value="A+B 实时表（素材组格式）" style="rounded=1;arcSize=8;
  fillColor=#FDF3E7;strokeColor=#E8944A;strokeWidth=2;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=20;fontStyle=1;whiteSpace=wrap;html=1;
  verticalAlign=middle;" vertex="1" parent="1">
  <mxGeometry x="200" y="100" width="340" height="60" as="geometry"/>
</mxCell>

<!-- △ 仅短标签可用：图标+底部标签 -->
<mxCell id="n2" value="广告引擎" style="shape=mxgraph.aws4.resourceIcon;
  resIcon=mxgraph.aws4.opensearch;labelBackgroundColor=none;sketch=0;
  fillColor=#E8944A;strokeColor=#E8944A;fontColor=#2C3E50;
  fontFamily=Helvetica;fontSize=20;fontStyle=1;whiteSpace=wrap;html=1;
  verticalLabelPosition=bottom;verticalAlign=top;align=center;
  labelWidth=200;" vertex="1" parent="1">
  <mxGeometry x="600" y="100" width="80" height="80" as="geometry"/>
</mxCell>
```

### 标签长度判断标准

| 标签字符数 | 建议节点类型 |
|-----------|-----------|
| ≤4 中文字 | 可用图标+底部标签（需加 `labelWidth=200`） |
| 5-8 中文字 | 改用圆角矩形内嵌文字（width≥240） |
| >8 中文字 | 必须用圆角矩形（width≥340），或精简标签 |
