---
name: ascii-drawio
description: Generates professional technical architecture diagrams in draw.io XML format. Use when user asks to draw diagrams, architecture charts, flowcharts, swimlane diagrams, fishbone diagrams, ER diagrams, sequence diagrams, topology maps, mind maps, or any system/architecture visualization. Saves .drawio files to the current working directory. Do NOT trigger when user only wants to edit text content without visual diagram output.
---

# DrawIO Architect

生成专业技术架构图，保存为 `.drawio` 文件。**语言：所有与用户的对话均使用中文。**

---

## 交互总则（最高优先级）

1. **每次只问一个问题**，使用 `AskUserQuestion` 工具，每个 `questions` 数组只包含 1 个问题
2. **所有问题必须是选择题**（2-4 个选项），支持开放用户自由输入的选项
3. 如果用户需求不明确，将可能的理解拆成选项让用户选，而非追问开放性问题
4. 每步必须等用户回复后才能进入下一步，**绝对禁止合并或跳过任何步骤**
5. 每条回复**第一行**必须声明：`【Step N: 步骤名称】`

---

## State Machine

```
Step 1 ──► Step 2 ──► Step 3 ──► Step 3b ──► Step 4 ──► Done
  需求确认     配色选择    布局选择    线框确认     生成图表
```

---

## Workflow

### Step 1: 需求确认

**目标**：帮用户把要表达的事情描述清楚。本步骤**只关心业务/技术内容本身**，不涉及画图设计。

1. 分析用户描述，提取业务信息：涉及哪些系统/模块/角色、它们之间的关系/流程/数据流向
2. 如果用户已经把事情说清楚了（能识别出核心组件和关系），直接进入 Step 2
3. 如果信息有缺口，**每次只问一个选择题**，聚焦于业务理解

**禁止在此步骤问**：用什么布局、用什么配色、画什么类型的图——这些由后续步骤处理。

> **STOP — 业务信息足够后才进入 Step 2。**

### Step 2: 配色选择

用 `AskUserQuestion` 呈现 3-4 种配色方案。流程：

1. 根据场景从 `references/color-palettes.md` 挑选 3-4 种配色
2. 先用 Bash 输出 ANSI 色块预览（按 color-palettes.md 中的命令格式）
3. 再用 `AskUserQuestion` 让用户选择

用户选择后记录为 `COLOR_PALETTE`。

> **STOP — 等用户选择配色后才进入 Step 3。**

### Step 3: 布局选择

用 `AskUserQuestion` 推荐 3-4 种布局，每个选项必须包含：
- **label**：布局名称（推荐项放第一个并加 "(Recommended)"）
- **description**：为什么适合（1-2 句）
- **preview**（必填）：基于用户内容的 ASCII 线框图（宽 <= 42 字符，<= 14 行）

> **STOP — 等用户选择一种布局后才进入 Step 3b。**

### Step 3b: 线框确认

生成**完整 ASCII 线框图**供用户确认。

- 包含所有节点、连接、分组，使用真实标签（可缩写，附对照表）
- 用 `-> <- ^ v` 标注流向，`-|+` 绘制框线，宽度 <= 80 字符
- 然后用 `AskUserQuestion` 问用户是否满足需求，**只提供 2 个选项**：
  1. **确认，开始生成图表**
  2. **线框比较乱，自动修复**
  （支持用户输入）

如果用户输入了修改意见，按修改后重新展示线框图并再次确认（同样只提供以上 2 个选项）。

> **STOP — 用户确认后才进入 Step 4。确认前禁止输出任何 XML 或写入文件。**

### Step 4: 生成图表

严格按以下子步骤顺序执行：

**4.1 图标选择** — 查 `references/aws-icons.md` 和 `scripts/find_aws_icon.py`，优先图标+标签复合节点。详见 `references/visual-elements.md`

**4.2 坐标规划表** — 按 `references/xml-writing-rules.md` B7 格式输出

**4.3 间距自检** — 按 `references/style-system.md` 间距规范逐对检查，违规则修正

**4.4 线交叉预检与修正** — 按 `references/design-principles.md` C3 规则，列出所有连线路径，逐对检查交叉和穿越节点，输出检测结果表。**当检测到交叉或违反 C8 模式规则时，必须按 C8 连线模式模板（fan-out/fan-in/跨区引用）修正坐标规划后，重新回到 4.2 输出修正后的坐标表。禁止带交叉直接进入 4.5 生成 XML。**

**4.5 生成 XML** — 参考文档：
- `references/xml-writing-rules.md` — 书写规则（**特别注意 B-1 禁止 html=1 规则**）
- `references/drawio-xml-guide.md` — 根结构、形状/连线模板
- `references/layout-templates.md` — 布局坐标示例

使用 `COLOR_PALETTE` 配色。**所有 style 中禁止包含 `html=1`，换行用 `&#xa;` 不用 `<br>`。**

**4.6 质检** — 按 `references/quality-checklist.md` 逐项核对，**首先全文搜索 `html=1` 和 `<br>` 确认无残留**，BLOCK 项不通过则修正后重新生成

**4.7 元数据** — 画布右下角放置标题、版本、日期

**4.8 保存文件** — 保存 .drawio 文件

---

## AWS 图标

使用 `mxgraph.aws4.*` 系列。搜索脚本：
```sh
python skills/ascii-drawio/scripts/find_aws_icon.py <关键词>
```
支持中文、英文缩写、能力关键词。完整列表见 `references/aws-icons.md`。
