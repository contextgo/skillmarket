# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import requests

from auth import MEMBER_ACCESS_ERROR, SkillAuthError, ensure_member_access
from region_lookup import RegionLookupError, convert_submit_region_fields
from recommender import CONSULT_FIELD_TABLE, recommend_experts

EXPERT_API_URL = "https://huichashui.com/api/aiExpert/getListSkill"
SUBMIT_API_URL = "https://huichashui.com/api/userCounselling/addSkill"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="慧专家推荐入口")
    parser.add_argument("--payload-file", help="可选：输入 JSON 文件路径；默认从 stdin 读取。")
    parser.add_argument("--output-file", help="可选：将 Markdown 结果写入指定文件。")
    parser.add_argument("--submit-file", help="可选：咨询提交 JSON 文件路径。存在时会提交咨询信息。")
    return parser.parse_args()


def _read_json(raw: str, empty_message: str) -> Dict[str, Any]:
    if not raw or not raw.strip():
        raise ValueError(empty_message)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"输入不是合法 JSON：{exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("输入必须是 JSON 对象。")
    return payload


def _read_payload(args: argparse.Namespace) -> Dict[str, Any]:
    raw = Path(args.payload_file).read_text(encoding="utf-8") if args.payload_file else sys.stdin.read()
    return _read_json(raw, "未收到专家推荐输入。请通过 stdin 或 --payload-file 传入 JSON。")


def fetch_experts(api_key: str) -> List[Dict[str, Any]]:
    response = requests.get(
        EXPERT_API_URL,
        params={"apiKey": api_key},
        headers={"Accept": "application/json"},
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    if payload.get("code") != 200:
        raise RuntimeError("专家接口返回异常，未能获取专家列表。")
    data = payload.get("data") or []
    if not isinstance(data, list):
        raise RuntimeError("专家接口返回格式异常。")
    return [item for item in data if str(item.get("delFlag", "0")) == "0"]


def submit_consult(api_key: str, submit_payload: Dict[str, Any]) -> Dict[str, Any]:
    required = [
        "userName",
        "enterpriseName",
        "industry",
        "phonenumber",
        "remark",
        "province",
        "city",
        "area",
        "expertId",
        "expertName",
        "preContent",
    ]
    missing = [key for key in required if not str(submit_payload.get(key, "")).strip()]
    if missing:
        raise ValueError(f"咨询提交缺少必填字段：{', '.join(missing)}")

    converted_payload = convert_submit_region_fields(submit_payload)
    converted_payload["apiKey"] = api_key
    response = requests.post(
        SUBMIT_API_URL,
        json=converted_payload,
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    if payload.get("code") != 200:
        raise RuntimeError(payload.get("message") or "咨询提交失败。")
    return {
        **payload,
        "resolvedRegion": {
            "provinceId": converted_payload["province"],
            "cityId": converted_payload["city"],
            "areaId": converted_payload["area"],
            "provinceName": converted_payload["provinceName"],
            "cityName": converted_payload["cityName"],
            "areaName": converted_payload["areaName"],
        },
        "submittedPayload": converted_payload,
    }


def main() -> None:
    try:
        api_key = ensure_member_access()
    except SkillAuthError:
        print(MEMBER_ACCESS_ERROR)
        sys.exit(1)

    args = parse_args()
    try:
        payload = _read_payload(args)
    except ValueError as exc:
        print(json.dumps({"success": False, "message": str(exc)}, ensure_ascii=False, indent=2))
        sys.exit(1)

    try:
        experts = fetch_experts(api_key)
    except Exception as exc:
        print(
            json.dumps(
                {
                    "success": False,
                    "message": "获取专家列表失败。",
                    "error": str(exc),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(1)

    result = recommend_experts(payload, experts)
    if args.output_file:
        Path(args.output_file).write_text(result["markdown"], encoding="utf-8")

    submit_result = None
    if args.submit_file:
        try:
            submit_payload = _read_json(Path(args.submit_file).read_text(encoding="utf-8"), "未收到咨询提交信息。")
            submit_result = submit_consult(api_key, submit_payload)
        except RegionLookupError as exc:
            submit_result = {"success": False, "message": f"地区转换失败：{exc}"}
        except Exception as exc:
            submit_result = {"success": False, "message": str(exc)}

    print(
        json.dumps(
            {
                "success": True,
                "message": "已完成慧专家推荐。",
                "fetchedExperts": len(experts),
                "recommendationCount": len(result["recommendations"]),
                "summary": result["summary"],
                "recommendations": result["recommendations"],
                "caseExamples": result["caseExamples"],
                "consultFields": CONSULT_FIELD_TABLE,
                "submitResult": submit_result,
                "markdown": result["markdown"],
                "closing": "你希望联系哪位专家呢，请填写专家名称和对应的信息提交之后，后续等专家联系你，给你对应的企业咨询。",
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
