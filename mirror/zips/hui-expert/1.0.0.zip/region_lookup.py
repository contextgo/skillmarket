# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List


class RegionLookupError(ValueError):
    """Raised when province/city/area names cannot be resolved."""


REGION_FILE = Path(__file__).with_name("regions.json")
CODE_PATTERN = re.compile(r"^\d{6}$")

PROVINCE_SUFFIXES = (
    "特别行政区",
    "维吾尔自治区",
    "壮族自治区",
    "回族自治区",
    "自治区",
    "省",
    "市",
)

CITY_SUFFIXES = (
    "自治州",
    "地区",
    "盟",
    "市",
)

AREA_SUFFIXES = (
    "自治县",
    "自治旗",
    "联合旗",
    "矿区",
    "新区",
    "林区",
    "特区",
    "街道",
    "苏木",
    "右旗",
    "左旗",
    "后旗",
    "前旗",
    "区",
    "县",
    "旗",
    "市",
)


def _strip_suffix(value: str, suffixes: tuple[str, ...]) -> str:
    for suffix in suffixes:
        if value.endswith(suffix) and len(value) > len(suffix):
            return value[: -len(suffix)]
    return value


def normalize_region_name(value: str, level: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = re.sub(r"\s+", "", text)
    if level == "province":
        return _strip_suffix(text, PROVINCE_SUFFIXES)
    if level == "city":
        return _strip_suffix(text, CITY_SUFFIXES)
    if level == "area":
        return _strip_suffix(text, AREA_SUFFIXES)
    return text


@lru_cache(maxsize=1)
def load_region_tree() -> List[Dict[str, Any]]:
    return json.loads(REGION_FILE.read_text(encoding="utf-8"))


def _same_code(value: str, node: Dict[str, Any]) -> bool:
    return bool(CODE_PATTERN.fullmatch(str(value or "").strip())) and str(value).strip() == str(node.get("code", "")).strip()


def _match_region(nodes: List[Dict[str, Any]], raw_name: str, level: str) -> Dict[str, Any]:
    if not raw_name:
        raise RegionLookupError(f"缺少{level}名称，无法匹配地区编码。")

    direct_name = str(raw_name).strip()
    normalized = normalize_region_name(raw_name, level)

    exact_matches = [node for node in nodes if _same_code(direct_name, node)]
    if len(exact_matches) == 1:
        return exact_matches[0]

    exact_matches = [node for node in nodes if str(node.get("name", "")).strip() == direct_name]
    if len(exact_matches) == 1:
        return exact_matches[0]

    normalized_matches = [
        node for node in nodes if normalize_region_name(node.get("name", ""), level) == normalized
    ]
    if len(normalized_matches) == 1:
        return normalized_matches[0]

    if not normalized_matches:
        raise RegionLookupError(f"未找到匹配的{level}：{raw_name}")

    candidates = ", ".join(str(node.get("name", "")) for node in normalized_matches[:5])
    raise RegionLookupError(f"{level}存在多个匹配项：{raw_name}，候选：{candidates}")


def resolve_region_ids(province: str, city: str, area: str) -> Dict[str, str]:
    provinces = load_region_tree()
    province_node = _match_region(provinces, province, "province")

    city_candidates: List[Dict[str, Any]] = list(province_node.get("children") or [])
    city_node = _match_region(city_candidates, city, "city")

    area_candidates: List[Dict[str, Any]] = list(city_node.get("children") or [])
    if area_candidates:
        area_node = _match_region(area_candidates, area, "area")
    else:
        area_node = city_node if _same_code(area, city_node) or normalize_region_name(area, "area") == normalize_region_name(city_node.get("name", ""), "area") else _match_region([city_node], area, "area")

    return {
        "provinceId": str(province_node.get("code", "")),
        "provinceName": str(province_node.get("name", "")),
        "cityId": str(city_node.get("code", "")),
        "cityName": str(city_node.get("name", "")),
        "areaId": str(area_node.get("code", "")),
        "areaName": str(area_node.get("name", "")),
    }


def convert_submit_region_fields(submit_payload: Dict[str, Any]) -> Dict[str, Any]:
    province = str(submit_payload.get("province", "")).strip()
    city = str(submit_payload.get("city", "")).strip()
    area = str(submit_payload.get("area", "")).strip()

    region = resolve_region_ids(province, city, area)
    converted = dict(submit_payload)
    converted["province"] = region["provinceId"]
    converted["city"] = region["cityId"]
    converted["area"] = region["areaId"]
    converted["provinceName"] = region["provinceName"]
    converted["cityName"] = region["cityName"]
    converted["areaName"] = region["areaName"]
    return converted
