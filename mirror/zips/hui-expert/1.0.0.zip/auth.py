# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import os
from typing import Iterable, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API_KEY_VALIDATE_URL = "https://huichashui.com/api/skill/info/apikey/validate"
API_KEY_ENV_NAMES = ("HCS_SKILL_API_KEY", "HUICHASHUI_API_KEY")
MEMBER_ACCESS_ERROR = "您不是慧查税平台会员，当前技能不可使用，或请联系慧查税平台的工作人员。"
DEFAULT_TIMEOUT = 8
_VALIDATION_CACHE: dict[str, bool] = {}


class SkillAuthError(Exception):
    """技能会员鉴权失败。"""


def get_api_key(env_names: Iterable[str] = API_KEY_ENV_NAMES) -> Optional[str]:
    for env_name in env_names:
        api_key = os.getenv(env_name, "").strip()
        if api_key:
            return api_key
    return None


def validate_api_key(api_key: str, timeout: int = DEFAULT_TIMEOUT) -> bool:
    if not api_key:
        return False
    if api_key in _VALIDATION_CACHE:
        return _VALIDATION_CACHE[api_key]

    query = urlencode({"apiKey": api_key})
    request = Request(
        f"{API_KEY_VALIDATE_URL}?{query}",
        headers={"Accept": "application/json"},
        method="GET",
    )

    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, ValueError, json.JSONDecodeError):
        return False

    is_valid = bool(payload.get("ok")) and payload.get("data") is True
    _VALIDATION_CACHE[api_key] = is_valid
    return is_valid


def ensure_member_access() -> str:
    api_key = get_api_key()
    if not api_key or not validate_api_key(api_key):
        raise SkillAuthError(MEMBER_ACCESS_ERROR)
    return api_key
