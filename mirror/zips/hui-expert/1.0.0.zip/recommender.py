# -*- coding: utf-8 -*-

from __future__ import annotations

from typing import Any, Dict, List


TOPIC_KEYWORDS = {
    "财税合规": ["税务", "合规", "发票", "申报", "税负", "稽查", "账务", "票据", "往来款"],
    "财务经营分析": ["财务分析", "经营分析", "利润", "毛利", "现金流", "预算", "报表", "降本增效", "人效"],
    "内控审计": ["内控", "审计", "流程", "制度", "风险", "整改", "合规管理"],
    "行业专项": ["医疗", "餐饮", "新零售", "制造", "物业", "家政", "影院", "传媒", "医药", "软件"],
}

CONSULT_FIELD_TABLE = [
    {"label": "联系人姓名", "required": True, "example": "刘大"},
    {"label": "企业名称", "required": True, "example": "科大讯飞"},
    {"label": "所属行业", "required": True, "example": "软件信息"},
    {"label": "联系电话", "required": True, "example": "17623452345"},
    {"label": "咨询问题说明", "required": True, "example": "如何进行大企业的财税申报服务"},
    {"label": "省份", "required": True, "example": "安徽省"},
    {"label": "城市", "required": True, "example": "合肥市"},
    {"label": "区域", "required": True, "example": "蜀山区"},
    {"label": "期望咨询方向", "required": True, "example": "企业零工如何节税"},
]


def _text(value: Any, default: str = "") -> str:
    text = str(value or "").strip()
    return text or default


def _collect_text(payload: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ("userQuery", "industry"):
        if payload.get(key):
            parts.append(_text(payload.get(key)))
    for key in ("problems", "risks", "goals", "topics"):
        for item in payload.get(key) or []:
            parts.append(_text(item))
    company = payload.get("companyProfile") or {}
    if isinstance(company, dict):
        for value in company.values():
            parts.append(_text(value))
    return "\n".join(part for part in parts if part)


def _score_expert(expert: Dict[str, Any], combined_text: str) -> int:
    haystack = " ".join(
        [
            _text(expert.get("name")),
            _text(expert.get("position")),
            _text(expert.get("des")),
            _text(expert.get("preGood")),
            _text(expert.get("preContent")),
            " ".join(expert.get("preGoodList") or []),
            " ".join(expert.get("preContentList") or []),
        ]
    )
    score = 0
    for token in combined_text.split():
        if token and token in haystack:
            score += 3
    for keywords in TOPIC_KEYWORDS.values():
        for keyword in keywords:
            if keyword in combined_text and keyword in haystack:
                score += 2
    if "降本增效" in combined_text and any(x in haystack for x in ("经营数据分析", "财务数据分析", "内控")):
        score += 4
    if any(x in combined_text for x in ("税务", "合规", "申报", "发票")) and any(
        x in haystack for x in ("审计", "内控", "财务数据分析")
    ):
        score += 3
    return score


def _build_reason(expert: Dict[str, Any], combined_text: str) -> str:
    reasons: List[str] = []
    pre_good = expert.get("preGoodList") or []
    pre_content = expert.get("preContentList") or []
    if pre_good:
        reasons.append(f"擅长{'、'.join(pre_good[:3])}")
    if pre_content:
        reasons.append(f"可重点处理{'、'.join(pre_content[:2])}")
    if "降本增效" in combined_text:
        reasons.append("适合从财务和经营视角帮助企业识别降本增效抓手")
    if any(x in combined_text for x in ("税务", "合规", "风险")):
        reasons.append("能帮助企业把风险问题转成更清晰的整改和咨询方向")
    return "；".join(reasons[:3]) or "与当前企业问题匹配度较高，适合优先联系。"


def _build_landing_value(payload: Dict[str, Any]) -> str:
    query = _collect_text(payload)
    if "降本增效" in query:
        return "适合先做财务与经营问题诊断，帮助企业梳理可落地的降本和提效方向。"
    if any(x in query for x in ("税务", "申报", "合规", "发票")):
        return "适合先对税务和合规风险做重点答疑，帮助企业减少后续整改和沟通成本。"
    return "适合先做一轮针对性咨询，帮助企业快速明确问题重点、处理顺序和后续动作。"


def _build_case_examples(query: str) -> List[Dict[str, str]]:
    examples: List[Dict[str, str]] = []

    if "降本增效" in query or "经营" in query or "利润" in query:
        examples.append(
            {
                "title": "门店与费用结构优化案例",
                "industry": "零售/新消费",
                "problem": "企业收入有增长，但利润持续承压，固定成本和人员配置不匹配。",
                "expertAction": "专家先从财务数据、门店经营数据和费用结构切入，帮助企业识别高成本门店、冗余支出和预算控制缺口。",
                "result": "企业逐步优化预算与门店策略后，年度综合成本有机会下降约 8% - 15%，经营分析口径也更清晰。",
            }
        )

    if any(x in query for x in ("税务", "合规", "风险", "申报", "发票", "往来款")):
        examples.append(
            {
                "title": "税务风险梳理与整改路径案例",
                "industry": "贸易/服务业",
                "problem": "企业存在往来款、票据和申报处理不规范，管理层不清楚风险轻重和处理顺序。",
                "expertAction": "专家先帮助企业完成风险清单、申报疑点和整改优先级梳理，再明确需要补齐的资料和后续沟通重点。",
                "result": "企业明显降低了后续税务沟通和整改压力，也减少了盲目处理中带来的时间和管理成本。",
            }
        )

    if any(x in query for x in ("内控", "流程", "审计", "制度")):
        examples.append(
            {
                "title": "内控流程规范案例",
                "industry": "制造/综合型企业",
                "problem": "企业审批流程和财务流程割裂，制度不清，导致风险暴露后难以及时定位责任。",
                "expertAction": "专家从审计和内控角度帮助企业梳理关键流程节点、职责边界和高风险环节。",
                "result": "企业逐步建立起更明确的流程和责任机制，后续问题排查和整改效率明显提升。",
            }
        )

    if not examples:
        examples.append(
            {
                "title": "综合问题诊断案例",
                "industry": "成长型企业",
                "problem": "企业同时面临财务、税务和经营问题，内部难以判断先处理什么。",
                "expertAction": "专家先帮助企业做问题优先级排序，再分别推进财税整改和经营优化。",
                "result": "企业避免了多头推进带来的试错成本，后续沟通和执行路径也更明确。",
            }
        )

    return examples[:2]


def recommend_experts(payload: Dict[str, Any], experts: List[Dict[str, Any]]) -> Dict[str, Any]:
    combined_text = _collect_text(payload)
    scored: List[Dict[str, Any]] = []
    for expert in experts:
        item = dict(expert)
        item["_score"] = _score_expert(item, combined_text)
        scored.append(item)

    scored.sort(key=lambda item: (item.get("_score", 0), _text(item.get("name"))), reverse=True)
    top = [item for item in scored if item.get("_score", 0) > 0][:3]
    if not top:
        top = scored[:3]

    recommendations: List[Dict[str, Any]] = []
    for item in top:
        recommendations.append(
            {
                "expertId": item.get("id"),
                "expertName": item.get("name"),
                "position": item.get("position"),
                "avatar": item.get("headUrl"),
                "industryDescription": item.get("des"),
                "expertise": item.get("preGoodList") or item.get("preGood"),
                "specialContent": item.get("preContentList") or item.get("preContent"),
                "matchReason": _build_reason(item, combined_text),
                "landingValue": _build_landing_value(payload),
            }
        )

    case_examples = _build_case_examples(combined_text)
    summary = "建议优先联系以下 1-3 位专家进行针对性答疑和咨询。"
    if payload.get("goals"):
        summary = f"结合企业当前“{'、'.join(_text(x) for x in (payload.get('goals') or [])[:2])}”目标，建议优先联系以下 1-3 位专家。"

    markdown_lines: List[str] = [
        "# 慧专家推荐结果",
        "",
        summary,
        "",
    ]
    for index, item in enumerate(recommendations, start=1):
        expertise = item["expertise"] if isinstance(item["expertise"], str) else "、".join(item["expertise"] or [])
        markdown_lines.extend(
            [
                f"## {index}. {item['expertName']}",
                "",
                f"- 职位：{_text(item.get('position'), '未提供')}",
                f"- 擅长领域：{expertise}",
                f"- 行业方向：{_text(item.get('industryDescription'), '未提供')}",
                f"- 推荐原因：{item['matchReason']}",
                f"- 可提供的帮助：{item['landingValue']}",
                "",
            ]
        )

    markdown_lines.extend(["## 成功咨询案例参考", ""])
    for case in case_examples:
        markdown_lines.extend(
            [
                f"### {case['title']}",
                f"- 行业场景：{case['industry']}",
                f"- 典型问题：{case['problem']}",
                f"- 专家介入方式：{case['expertAction']}",
                f"- 结果参考：{case['result']}",
                "",
            ]
        )

    markdown_lines.extend(
        [
            "## 咨询提交信息",
            "",
            "| 填写项 | 是否必填 | 示例 |",
            "|---|---|---|",
        ]
    )
    for item in CONSULT_FIELD_TABLE:
        markdown_lines.append(
            f"| {item['label']} | {'是' if item['required'] else '否'} | {item['example']} |"
        )
    markdown_lines.extend(
        [
            "",
            "你希望联系哪位专家呢，请填写专家名称和对应的信息提交之后，后续等专家联系你，给你对应的企业咨询。",
        ]
    )

    return {
        "summary": summary,
        "recommendations": recommendations,
        "caseExamples": case_examples,
        "consultFields": CONSULT_FIELD_TABLE,
        "markdown": "\n".join(markdown_lines).strip() + "\n",
    }
