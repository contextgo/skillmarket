---
code: hui-expert
name: 慧专家
version: 1.0.0
description: 根据企业财税问题、经营问题、风险点和咨询诉求，推荐 1-3 位更匹配的慧查税专家，输出专家介绍、适配原因、可提供的帮助、参考咨询案例和咨询提交流程。适用于企业咨询、风险答疑、财税问题研判、经营问题问诊和专家对接场景。
private: true
auth:
  type: huichashui_api_key
  env:
    - HCS_SKILL_API_KEY
    - HUICHASHUI_API_KEY
  validateUrl: https://huichashui.com/api/skill/info/apikey/validate
  successCondition: code=200 && ok=true && data=true
  failureMessage: 您不是慧查税平台会员，当前技能不可使用，或请联系慧查税平台的工作人员。
loadPolicy:
  authBeforeLoad: true
  denyOnFailure: true
  doNotUseSkillContentBeforeAuth: true
execution:
  required: true
---

# 慧专家

宿主必须先完成一次 `apiKey` 校验，再使用本技能。

默认入口是 [main.py](E:\hcs_project_ai\hcs-skills\慧专家\main.py)。

本技能负责：

1. 校验 `apiKey`
2. 拉取慧查税专家库
3. 根据企业问题、风险和咨询目标推荐 1-3 位专家
4. 输出专家介绍、匹配原因、可提供的帮助和参考案例
5. 提供咨询提交字段表
6. 可选调用咨询提交接口，向平台发送客户信息

输入可以通过 `stdin` 或 `--payload-file` 传入，建议至少包含：

- `userQuery`
- `problems`
- `risks`
- `goals`
- `industry`
- `topics`
- `companyProfile`

最终输出为结构化 JSON，其中包含：

- 推荐摘要
- 专家推荐列表
- 参考咨询案例
- 咨询提交字段表
- 面向用户的 Markdown 结果
- 可选的提交结果

私有推荐规则见 [private.md](E:\hcs_project_ai\hcs-skills\慧专家\private.md)。
