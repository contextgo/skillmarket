# TokenSaver 诊断数据

## 当前诊断数据（2025-05-06）

### 重复技能（qclaw子目录）
| 技能 | 主目录 | qclaw目录 | 建议 |
|------|--------|-----------|------|
| chinese-medicine | 199行 | 208行 | 删除qclaw版本 |
| skill-factory | 114行 | 107行 | 删除qclaw版本 |
| destiny-master | 92行 | 92行 | 删除qclaw版本 |
| design-master | 67行 | 66行 | 删除qclaw版本 |
| jinqiang-dashu | 71行 | 72行 | 删除qclaw版本 |

### 需压缩技能（>100行）
| 技能 | 行数 | 超出行数 |
|------|:---:|:---:|
| chinese-medicine | 199 | +99 |
| skill-factory | 114 | +14 |
| daxueshi | 109 | +9 |
| saihuatuo | 104 | +4 |

### 边缘技能（90-100行）
| 技能 | 行数 | 建议 |
|------|:---:|------|
| manager | 99 | 差1行，注意 |
| destiny-master | 92 | 差8行，可选优化 |

---

## 执行清理命令

### 删除重复目录
```powershell
# 删除 qclaw 下的重复技能（保留主目录）
Remove-Item -Path "D:\Qclaw Document\skills\qclaw\chinese-medicine" -Recurse -Force
Remove-Item -Path "D:\Qclaw Document\skills\qclaw\skill-factory" -Recurse -Force
```

### 压缩超长 SKILL.md
```powershell
# 备份原文件
Copy-Item "SKILL.md" "references\SKILL_backup.md"

# 精简内容至100行内
# 核心知识移至 references/ 详细文件
```

### 清理空目录
```powershell
Get-ChildItem -Path "D:\Qclaw Document\skills" -Directory | Where-Object { (Get-ChildItem $_.FullName -File).Count -eq 0 } | Remove-Item -Force
```