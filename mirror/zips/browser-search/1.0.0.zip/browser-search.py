#!/usr/bin/env python3
"""
Browser Search 技能（安全优化版）
使用本地浏览器进行自动化搜索和内容提取

支持搜索引擎：Bing, Google, Baidu, DuckDuckGo
无需 API 配置，直接使用本地浏览器

【安全优化】减少可疑模式，增强安全性
"""

import os
import sys
import json
import time
from typing import List, Dict, Optional
from playwright.sync_api import sync_playwright

# 配置
DEFAULT_TIMEOUT = 30000  # 30 秒超时
DEFAULT_MAX_RESULTS = 10
SUPPORTED_ENGINES = ["bing", "google", "baidu", "duckduckgo"]

# 安全配置
ALLOWED_BASE_DIR = os.path.expanduser("~")


class BrowserSearch:
    def __init__(self):
        self.engine = "bing"
        self.search_url = ""
        self.query_selector = "h2"
        self.output_file: Optional[str] = None
        self.results: List[Dict] = []
        
    def set_engine(self, engine: str) -> None:
        """设置搜索引擎"""
        if engine not in SUPPORTED_ENGINES:
            print(f"⚠️ 不支持的搜索引擎：{engine}")
            print(f"支持的引擎：{', '.join(SUPPORTED_ENGINES)}")
            return
        self.engine = engine
        configs = {
            "bing": "https://www.bing.com/search?q={query}",
            "google": "https://www.google.com/search?q={query}",
            "baidu": "https://www.baidu.com/s?wd={query}",
            "duckduckgo": "https://duckduckgo.com/?q={query}"
        }
        self.search_url = configs.get(engine, configs["bing"])
    
    def validate_output_path(self, path: str) -> bool:
        """
        验证输出路径是否在允许范围内
        
        Args:
            path: 输出文件路径
            
        Returns:
            True 如果路径安全，False 如果路径不安全
        """
        if not path:
            return False
        
        if not path.endswith(('.json', '.txt', '.md')):
            print(f"⚠️ 建议输出文件格式为 .json、.txt 或 .md")
        
        try:
            # 处理 ~ 开头的路径
            if path.startswith("~/"):
                path = os.path.expanduser(path)
            
            # 转换为绝对路径
            abs_path = os.path.abspath(path)
            real_path = os.path.realpath(abs_path)
            real_base = os.path.realpath(ALLOWED_BASE_DIR)
            
            # 检查是否在允许的主目录内
            if real_path.startswith(real_base + os.sep) or real_path == real_base:
                return True
            
            print(f"❌ 拒绝写入路径：{path}")
            print(f"   原因：输出文件只能保存到用户主目录 ({ALLOWED_BASE_DIR}) 或子目录")
            print(f"   安全路径示例：{os.path.join(ALLOWED_BASE_DIR, 'output.json')}")
            return False
            
        except Exception as e:
            print(f"❌ 路径验证失败：{str(e)}")
            return False
    
    def search(self, query: str, max_results: int = DEFAULT_MAX_RESULTS, output_file: Optional[str] = None) -> Dict:
        """执行搜索"""
        # 清洗搜索词
        clean_query = " ".join(query.split())
        
        self.results = []
        self.output_file = output_file
        
        # 安全验证
        if output_file and not self.validate_output_path(output_file):
            return {
                "error": "invalid_output_path",
                "message": f"输出路径必须位于用户主目录 ({ALLOWED_BASE_DIR}) 或子目录",
                "results": []
            }
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    viewport={"width": 1280, "height": 720},
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                )
                page = context.new_page()
                
                # 构建搜索 URL
                import urllib.parse
                encoded_query = urllib.parse.quote(clean_query, safe="+")
                search_url = self.search_url.format(query=encoded_query)
                
                print(f"\n🔍 正在搜索：{clean_query}")
                print(f"🌐 搜索引擎：{self.engine}")
                
                # 打开页面
                try:
                    page.goto(search_url, wait_until="domcontentloaded", timeout=DEFAULT_TIMEOUT)
                    time.sleep(1)
                except Exception as e:
                    print(f"❌ 打开页面失败：{str(e)[:100]}")
                    return {"error": "page_open_failed", "message": str(e)}
                
                # 提取结果
                results = page.query_selector_all(self.query_selector)
                
                print(f"\n📊 找到 {len(results)} 个搜索结果")
                
                if len(results) == 0:
                    print("⚠️ 尝试备用选择器...")
                    for selector in ["h3 a", "h2 a", "li a", "a"]:
                        try:
                            alt_results = page.query_selector_all(selector)
                            if len(alt_results) > 0:
                                results = alt_results
                                print(f"✓ 使用 '{selector}' 找到 {len(results)} 个结果")
                                break
                        except:
                            continue
                
                # 提取详情
                count = 0
                for result in results[:max_results]:
                    try:
                        link = result.query_selector("h2 a") or result.query_selector("a")
                        if link:
                            title = link.text_content().strip()
                            url = link.get_attribute("href")
                            
                            if title and url:
                                self.results.append({
                                    "title": title,
                                    "url": url,
                                    "engine": self.engine
                                })
                                count += 1
                    except:
                        continue
                
                print(f"\n📝 成功提取 {count} 条结果")
                browser.close()
                
                response = {
                    "query": clean_query,
                    "engine": self.engine,
                    "count": len(self.results),
                    "results": self.results
                }
                
                if self.output_file:
                    try:
                        with open(self.output_file, 'w', encoding='utf-8') as f:
                            json.dump(response, f, ensure_ascii=False, indent=2)
                        print(f"\n💾 结果已保存到：{self.output_file}")
                    except Exception as e:
                        print(f"❌ 保存失败：{str(e)}")
                
                return response
                
        except Exception as e:
            print(f"\n❌ 搜索错误：{str(e)}")
            return {"error": str(e), "results": []}

def main():
    """命令行入口"""
    if len(sys.argv) < 2:
        print("🔎 Browser Search - 浏览器自动化搜索")
        print("\n用法：browser-search.py \"搜索词\" [选项]")
        print("\n选项:")
        print(f"  --engine <{', '.join(SUPPORTED_ENGINES)}>  搜索引擎（默认：bing）")
        print("  --output <file>                           输出文件（路径必须位于用户主目录）")
        print("  --max <n>                                 结果数量（默认：10）")
        print("  --help                                    显示帮助")
        sys.exit(1)
    
    args = sys.argv[1:]
    engine = "bing"
    output_file = None
    max_results = DEFAULT_MAX_RESULTS
    
    i = 0
    while i < len(args):
        if args[i] == "--engine" and i + 1 < len(args):
            engine = args[i + 1]
            i += 2
        elif args[i] == "--output" and i + 1 < len(args):
            output_file = args[i + 1]
            i += 2
        elif args[i] == "--max" and i + 1 < len(args):
            try:
                max_results = int(args[i + 1])
                i += 2
            except ValueError:
                print(f"❌ 无效的 --max 参数：{args[i + 1]}")
                sys.exit(1)
        elif args[i] == "--help":
            main()
            sys.exit(0)
        else:
            query_parts = []
            while i < len(args) and not (args[i].startswith("--")):
                query_parts.append(args[i])
                i += 1
            query = " ".join(query_parts)
            break
    
    if not query:
        print("❌ 需要提供搜索词")
        sys.exit(1)
    
    search = BrowserSearch()
    search.set_engine(engine)
    search.output_file = output_file
    
    response = search.search(query, max_results=max_results)
    
    print("\n" + "=" * 70)
    print(f"搜索结果 ({response.get('count', 0)} 条)")
    print("=" * 70)
    
    if "error" in response:
        print(f"❌ 错误：{response['error']}")
    else:
        for i, result in enumerate(response["results"], 1):
            print(f"\n{i}. {result['title']}")
            print(f"   🔗 {result['url']}")
    
    print("\n" + "=" * 70)

if __name__ == "__main__":
    main()
