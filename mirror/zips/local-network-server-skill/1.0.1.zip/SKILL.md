---
name: local-network-server-skill
description: 局域网二维码文件共享技能。支持主站网关/单文件直传/从站自动发现三种模式，零配置跨设备共享，生命周期同步管理。
homepage: https://github.com/QClaw/skills
metadata:
  {
    "clawdbot":
      {
        "emoji": "📡",
        "requires": { "bins": ["python3"], "packages": ["flask", "qrcode[pil]", "pillow", "werkzeug"] },
        "primaryEnv": "python3",
        "systemDeps": { 
          "linux": ["python3-tk", "python3-pil.imagetk"], 
          "macos": [], 
          "windows": [] 
        },
        "autoInstall": true
      }
  }
---

# 📡 局域网二维码文件共享技能

> 零配置 · 跨设备 · 生命周期同步 · 扫码即用

通过二维码实现局域网内快速文件共享，无需互联网、无需账号、无需手动配置IP。支持**主站网关**、**单文件直传**、**从站自动发现**三种工作模式。

---

## 🤖 Agent 执行指令

**执行本技能后，代理必须：**

### 1. 启动服务（如用户未指定目录，默认共享桌面）
```bash
# 共享桌面（推荐）
python local_network_server_skill.py --master --dir "%USERPROFILE%\Desktop"

# 共享自定义目录
python local_network_server_skill.py --master --dir "D:\资料"
```

### 2. 显示连接信息
- 主站模式：展示访问链接 + 告知二维码已弹出
- 从站模式：列出发现的主站列表

### 3. 确认服务状态
- 明确告知用户服务已启动
- 标注访问地址、端口、共享目录

### 4. 提供操作指引
- 手机端：扫码 → 浏览器打开 → 上传/下载
- 电脑端：浏览器访问链接
- 关闭服务：关闭窗口或按 `Ctrl+C`

### 5. 异常处理
- 端口冲突：提示更换 `--port` 参数
- 依赖缺失：脚本会自动尝试安装
- 访问失败：检查防火墙设置

---

## 🚀 快速开始

### 方式一：共享桌面文件夹
```bash
python local_network_server_skill.py --master --dir "%USERPROFILE%\Desktop"
```

### 方式二：共享指定文件夹
```bash
python local_network_server_skill.py --master --dir "D:\工作资料"
```

### 方式三：单文件直传
```bash
python local_network_server_skill.py --single "C:\Users\xxx\Documents\report.pdf"
```

### 方式四：从站发现（连接他人的共享）
```bash
python local_network_server_skill.py --slave
```

---

## 📋 命令行参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--master` | 主站模式（开启文件共享网关） | 必选其一 |
| `--single FILE` | 单文件模式（共享指定文件） | 必选其一 |
| `--slave` | 从站模式（发现并连接主站） | 必选其一 |
| `--dir PATH` | 共享目录路径 | `./qclaw_shared` |
| `--port PORT` | 服务端口 | `8989` |
| `--no-gui` | 禁用 GUI 弹窗（无桌面环境用） | 启用 |
| `--timeout SEC` | 从站发现超时秒数 | `8` |

---

## 🔧 依赖说明

**自动安装**：脚本首次运行时会自动检查并安装依赖（flask, qrcode, pillow, werkzeug）

**手动安装（如自动失败）**：
```bash
pip install flask qrcode[pil] pillow werkzeug
```

---

## 🐛 故障排查

### 问题：手机扫描二维码无法访问
- 确认手机和电脑在同一 WiFi 网络
- 检查防火墙是否阻止了 8989 端口

### 问题：服务启动报 "端口已被占用"
- 换一个端口：`--port 8990`

### 问题：二维码不显示
- 使用 `--no-gui` 参数，然后手动访问控制台输出的链接

---

## 📝 更新日志

- **v1.3.0**：增加自动安装依赖、修复 Windows 编码问题
- **v1.2.0**：修复版，支持自定义共享目录
- **v1.0.0**：初始版本
