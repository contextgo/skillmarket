#!/bin/bash
#
# QClaw Skill 安装脚本
# 文件: install_local_networw_server_skill.sh
# 功能: 自动安装局域网二维码共享工具依赖
#

set -e  # 遇到错误立即退出

SKILL_NAME="local_networw_server_skill"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_CMD="${PYTHON:-python3}"
PIP_CMD="${PIP:-pip3}"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查前置条件
check_prerequisites() {
    log_info "检查系统环境..."
    
    # 检查Python
    if ! command -v $PYTHON_CMD &> /dev/null; then
        log_error "未找到 $PYTHON_CMD，请安装 Python 3.7+"
        exit 1
    fi
    
    local py_version=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    log_info "Python 版本: $py_version"
    
    if [[ $(echo "$py_version < 3.7" | bc -l 2>/dev/null || echo 0) -eq 1 ]]; then
        log_error "Python 版本过低，需要 3.7+"
        exit 1
    fi
    
    # 检查pip
    if ! $PYTHON_CMD -m pip --version &> /dev/null; then
        log_error "未找到 pip，请安装 python3-pip"
        exit 1
    fi
}

# 安装Python依赖
install_python_deps() {
    log_info "安装Python依赖..."
    
    $PIP_CMD install --user \
        "flask>=2.0.0" \
        "qrcode[pil]>=7.0.0" \
        "pillow>=8.0.0" \
        "werkzeug>=2.0.0" 2>/dev/null
    
    if [ $? -ne 0 ]; then
        log_warn "用户模式安装失败，尝试系统模式(可能需要sudo)..."
        sudo $PIP_CMD install \
            "flask>=2.0.0" \
            "qrcode[pil]>=7.0.0" \
            "pillow>=8.0.0" \
            "werkzeug>=2.0.0" || {
            log_error "依赖安装失败，请手动执行:"
            echo "  $PIP_CMD install flask qrcode[pil] pillow werkzeug"
            exit 1
        }
    fi
    
    log_info "✓ Python依赖安装完成"
}

# 检查系统GUI依赖
check_gui_deps() {
    log_info "检查GUI环境依赖..."
    
    # 检测操作系统
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux: 检查tkinter
        if ! $PYTHON_CMD -c "import tkinter" 2>/dev/null; then
            log_warn "tkinter 未安装，尝试自动安装..."
            
            # 根据发行版安装
            if command -v apt-get &> /dev/null; then
                sudo apt-get update -qq && sudo apt-get install -y python3-tk python3-pil.imagetk 2>/dev/null || true
            elif command -v yum &> /dev/null; then
                sudo yum install -y python3-tkinter python3-pillow-tk 2>/dev/null || true
            elif command -v pacman &> /dev/null; then
                sudo pacman -S tk 2>/dev/null || true
            fi
            
            # 再次检查
            if ! $PYTHON_CMD -c "import tkinter" 2>/dev/null; then
                log_warn "⚠️  tkinter 仍不可用，二维码弹窗将禁用"
                log_warn "💡  可手动安装: sudo apt install python3-tk (Debian/Ubuntu)"
            else
                log_info "✓ tkinter 安装成功"
            fi
        fi
        
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS: 通常预装tkinter，检查Pillow
        if ! $PYTHON_CMD -c "from PIL import ImageTk" 2>/dev/null; then
            log_warn "Pillow ImageTk 模块缺失，尝试修复..."
            $PIP_CMD install --user --upgrade pillow 2>/dev/null || true
        fi
    fi
    
    log_info "✓ GUI依赖检查完成"
}

# 初始化共享目录
init_share_dir() {
    local share_dir="$SKILL_DIR/qclaw_shared"
    mkdir -p "$share_dir"
    chmod 755 "$share_dir" 2>/dev/null || true
    log_info "共享目录: $share_dir"
}

# 创建快捷方式(可选)
create_shortcut() {
    log_info "创建快捷命令..."
    
    local script="$SKILL_DIR/local_networw_server_skill.py"
    local link_name="qclaw-share"
    
    # 尝试创建用户bin目录的软链接
    local user_bin="$HOME/.local/bin"
    mkdir -p "$user_bin"
    
    if [[ ":$PATH:" != *":$user_bin:"* ]]; then
        log_warn "⚠️  $user_bin 不在PATH中，添加以下行到 ~/.bashrc 或 ~/.zshrc:"
        echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
    fi
    
    # 创建可执行脚本
    cat > "$user_bin/$link_name" << EOF
#!/bin/bash
exec $PYTHON_CMD "$script" "\$@"
EOF
    chmod +x "$user_bin/$link_name"
    
    log_info "✓ 快捷命令创建: $link_name"
    log_info "  使用示例: $link_name --master"
}

# 主流程
main() {
    echo "╔════════════════════════════════════╗"
    echo "║  QClaw Skill 安装向导 v1.1.0      ║"
    echo "║  局域网二维码文件共享工具          ║"
    echo "╚════════════════════════════════════╝"
    echo
    
    check_prerequisites
    install_python_deps
    check_gui_deps
    init_share_dir
    create_shortcut
    
    echo
    log_info "🎉 安装完成!"
    echo
    echo "📚 使用文档: 查看 SKILL.md"
    echo "🚀 快速开始:"
    echo "   # 主站模式"
    echo "   python3 local_networw_server_skill.py --master"
    echo
    echo "   # 或使用快捷命令(如已配置PATH)"
    echo "   qclaw-share --single ~/document.pdf"
    echo
    echo "💡 提示: 首次运行请确保防火墙允许 $DEFAULT_PORT 和 UDP 10086 端口"
}

# 执行
main "$@"