#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QClaw 局域网二维码文件共享 Skill
功能：主站网关/单文件共享/从站UDP自动发现/生命周期同步
版本: 1.3.0 (兼容增强版)
"""
import os
import sys
import socket
import threading
import time
import json
import argparse
import logging
import signal
import webbrowser
import subprocess
from pathlib import Path
from typing import Optional, List, Dict

# ===== Windows 终端编码兼容处理 =====
if sys.platform == "win32":
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

# ===== 自动安装依赖 =====
def ensure_dependencies():
    """检查并自动安装所需依赖"""
    required = ['flask', 'qrcode', 'PIL', 'werkzeug']
    missing = []
    
    for mod in required:
        try:
            __import__(mod.lower() if mod != 'PIL' else 'PIL')
        except ImportError:
            missing.append(mod)
    
    if missing:
        print(f"[INFO] 正在自动安装依赖: {', '.join(missing)}")
        try:
            pip_cmd = [sys.executable, '-m', 'pip', 'install', 'flask', 'qrcode[pil]', 'pillow', 'werkzeug']
            subprocess.check_call(pip_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"[INFO] 依赖安装完成")
        except Exception as e:
            print(f"[WARN] 自动安装失败，请手动运行: pip install flask qrcode pillow werkzeug")
            print(f"       错误: {e}")

# 延迟导入第三方依赖
flask_pkg = qrcode_pkg = PIL_pkg = tkinter_pkg = None

# ===================== 基础配置 =====================
BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# 默认共享目录：Windows 用桌面，其他系统用 skill 同目录
if sys.platform == "win32":
    DEFAULT_SHARE_DIR = os.path.join(os.environ.get("USERPROFILE", BASE_PATH), "Desktop")
else:
    DEFAULT_SHARE_DIR = os.path.join(BASE_PATH, "qclaw_shared")

SHARE_DIR = DEFAULT_SHARE_DIR
LOG_FILE = os.path.join(BASE_PATH, "qclaw_share.log")
ALLOWED_TYPES = {"pdf", "txt", "png", "jpg", "jpeg", "zip", "md", "docx", "xlsx", "pptx", "mp4", "mp3"}
HOST = "0.0.0.0"
DEFAULT_PORT = 8989
UDP_BROADCAST_IP = "255.255.255.255"
UDP_PORT = 10086
BROADCAST_INTERVAL = 2
DISCOVER_TIMEOUT = 8
MAX_FILE_SIZE = 200 * 1024 * 1024

# 日志配置（UTF-8 编码避免 Windows GBK 问题）
try:
    _log_handler = logging.StreamHandler(sys.stdout)
    _log_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
    logging.basicConfig(
        level=logging.INFO,
        handlers=[
            logging.FileHandler(LOG_FILE, encoding='utf-8', errors='replace'),
            _log_handler
        ]
    )
except Exception:
    logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ===================== 全局状态 =====================
class GlobalState:
    server_running = True
    current_mode = "master"
    single_file_path: Optional[str] = None
    flask_app = None
    qr_window = None
    main_window = None
    no_gui_mode = False

    @classmethod
    def shutdown(cls):
        logger.info("正在关闭服务...")
        cls.server_running = False
        if cls.qr_window:
            try:
                cls.qr_window.destroy()
            except Exception:
                pass
        if cls.main_window:
            try:
                cls.main_window.destroy()
            except Exception:
                pass
        sys.exit(0)


# ===================== 依赖检查与导入 =====================
def check_dependencies(no_gui: bool = False):
    """检查并导入必需的第三方库"""
    global flask_pkg, qrcode_pkg, PIL_pkg, tkinter_pkg

    # Flask 核心（必需）
    try:
        from flask import Flask, request, send_from_directory, jsonify, render_template_string
        from werkzeug.utils import secure_filename
        flask_pkg = {
            "Flask": Flask,
            "request": request,
            "send_from_directory": send_from_directory,
            "jsonify": jsonify,
            "render_template_string": render_template_string,
            "secure_filename": secure_filename,
        }
    except ImportError as e:
        logger.error(f"缺少 flask: {e}")
        logger.error("请运行安装脚本")
        sys.exit(1)

    # qrcode（必需，用于生成二维码）
    try:
        import qrcode
        qrcode_pkg = qrcode
    except ImportError as e:
        logger.error(f"缺少 qrcode: {e}")
        sys.exit(1)

    # Pillow（必需，二维码图片处理）
    try:
        from PIL import Image
        PIL_pkg = {"Image": Image}
    except ImportError as e:
        logger.error(f"缺少 pillow: {e}")
        sys.exit(1)

    # tkinter（可选，仅无 GUI 模式可跳过）
    # 注意：macOS 的 tkinter 必须在主线程测试，所以这里只导入不测窗口
    # 实际测试窗口是否可用在 start_server() / 从站模式入口中进行
    if not no_gui:
        try:
            import tkinter as tk
            from tkinter import (
                Tk, Label, Button, Toplevel, Listbox,
                Scrollbar, END, SINGLE, messagebox, Frame
            )
            tkinter_pkg = {
                "Tk": Tk,
                "Label": Label,
                "Button": Button,
                "Toplevel": Toplevel,
                "Listbox": Listbox,
                "Scrollbar": Scrollbar,
                "END": END,
                "SINGLE": SINGLE,
                "messagebox": messagebox,
                "Frame": Frame,
            }
            logger.info("tkinter 已加载（窗口测试延后到 GUI 启动时）")
        except Exception as e:
            logger.warning(f"⚠️ tkinter 不可用 ({e})，GUI 弹窗已禁用")
            tkinter_pkg = None

    logger.info("依赖检查通过 ✓")


# ===================== 共享目录初始化 =====================
def init_share_dir():
    """初始化共享目录"""
    global SHARE_DIR
    # 如果用户没有指定目录，使用默认目录（Windows 为桌面）
    if SHARE_DIR == DEFAULT_SHARE_DIR and sys.platform == "win32":
        SHARE_DIR = os.path.join(os.environ.get("USERPROFILE", BASE_PATH), "Desktop")
    os.makedirs(SHARE_DIR, exist_ok=True)
    logger.info(f"共享目录: {SHARE_DIR}")


# ===================== 网络工具函数 =====================
def get_local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception as e:
        logger.warning(f"获取IP失败: {e}")
        return "127.0.0.1"


def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_TYPES


# ===================== Flask 服务 =====================
def create_flask_app() -> "Flask":
    """创建并配置 Flask 应用"""
    f = flask_pkg
    app = f["Flask"](__name__)
    app.config["UPLOAD_FOLDER"] = SHARE_DIR
    app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE

    @app.route("/")
    def index():
        if GlobalState.current_mode == "single" and GlobalState.single_file_path:
            filename = os.path.basename(GlobalState.single_file_path)
            return f["send_from_directory"](
                os.path.dirname(GlobalState.single_file_path),
                filename,
                as_attachment=False
            )

        files = [
            f for f in os.listdir(SHARE_DIR)
            if os.path.isfile(os.path.join(SHARE_DIR, f))
        ]
        html = """
        <!DOCTYPE html>
        <html><head><meta charset="UTF-8"><title>QClaw 共享网关</title>
        <style>
            body{font-family:sans-serif;max-width:800px;margin:2rem auto;padding:0 1rem;}
            .file-list{list-style:none;padding:0;}
            .file-list li{padding:0.5rem;border-bottom:1px solid #eee;display:flex;align-items:center;}
            .file-list li .size{color:#888;font-size:0.85em;margin-left:auto;}
            .upload-box{background:#f5f5f5;padding:1rem;border-radius:8px;margin:1rem 0;}
            a{text-decoration:none;color:#0066cc;}a:hover{text-decoration:underline;}
            .header{display:flex;align-items:center;gap:1rem;margin-bottom:1rem;}
            .header h2{margin:0;}
            .info-box{background:#e8f4ff;padding:0.75rem;border-radius:8px;margin-bottom:1rem;font-size:0.9em;}
            .info-box code{background:#fff;padding:0.2rem 0.5rem;border-radius:4px;}
        </style></head><body>
        <div class="header">
            <h2>📡 QClaw 局域网共享网关</h2>
        </div>
        <div class="info-box">
            🌐 访问地址: <code id="baseUrl"></code>
            <script>document.getElementById('baseUrl').textContent = window.location.origin;</script>
            &nbsp;|&nbsp; 📁 共享目录: <code>{{ share_dir }}</code>
            &nbsp;|&nbsp; 📄 文件数: {{ files|length }}
        </div>
        <div class="upload-box">
            <b>📤 上传文件</b><br><br>
            <form action="/upload" method=post enctype=multipart/form-data>
                <input type=file name=file multiple accept="*/*">
                <button type=submit>上传</button>
            </form>
        </div>
        <h3>📁 已共享文件</h3>
        {% if files %}
        <ul class="file-list">
        {% for f in files %}
            <li>
                📄 <a href='/files/{{f}}' target='_blank'>{{f}}</a>
                <span class="size">{{ sizes.get(f, '?') }}</span>
            </li>
        {% endfor %}
        </ul>
        {% else %}
        <p style="color:#888">暂无共享文件</p>
        {% endif %}
        <p><small>💡 提示: 同一局域网内设备可直接访问此地址</small></p>
        </body></html>
        """
        # 计算文件大小
        file_sizes = {}
        for fname in files:
            fpath = os.path.join(SHARE_DIR, fname)
            size = os.path.getsize(fpath)
            if size > 1024 * 1024:
                file_sizes[fname] = f"{size/1024/1024:.1f} MB"
            elif size > 1024:
                file_sizes[fname] = f"{size/1024:.0f} KB"
            else:
                file_sizes[fname] = f"{size} B"

        return f["render_template_string"](
            html,
            files=files,
            sizes=file_sizes,
            share_dir=SHARE_DIR
        )

    @app.route("/files/<path:filename>")
    def get_file(filename):
        return f["send_from_directory"](SHARE_DIR, filename, as_attachment=True)

    @app.route("/upload", methods=["POST"])
    def upload_file():
        if "file" not in f["request"].files:
            return f["jsonify"]({"status": "err", "msg": "未找到文件字段"})

        uploaded = f["request"].files.getlist("file")
        results = []

        for file in uploaded:
            if not file.filename:
                continue
            if allowed_file(file.filename):
                name = f["secure_filename"](file.filename)
                save_path = os.path.join(SHARE_DIR, name)
                if os.path.exists(save_path):
                    base, ext = os.path.splitext(name)
                    counter = 1
                    while os.path.exists(save_path):
                        name = f"{base}_{counter}{ext}"
                        save_path = os.path.join(SHARE_DIR, name)
                        counter += 1
                file.save(save_path)
                logger.info(f"文件上传成功: {name}")
                results.append({"name": name, "status": "ok"})
            else:
                results.append({"name": file.filename, "status": "err", "msg": "不支持的文件类型"})

        return f["jsonify"]({"results": results})

    @app.route("/api/info")
    def api_info():
        return f["jsonify"]({
            "mode": GlobalState.current_mode,
            "ip": get_local_ip(),
            "port": DEFAULT_PORT,
            "files_count": len(os.listdir(SHARE_DIR)) if os.path.exists(SHARE_DIR) else 0
        })

    return app


# ===================== UDP 主站广播 =====================
def udp_broadcast_server(port: int):
    local_ip = get_local_ip()
    broadcast_msg = json.dumps({
        "type": "qclaw_share_master",
        "version": "1.2.0",
        "ip": local_ip,
        "port": port,
        "hostname": socket.gethostname(),
        "mode": GlobalState.current_mode,
        "timestamp": time.time()
    }).encode('utf-8')

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(1)

    logger.info(f"📡 开始广播: {local_ip}:{port}")

    while GlobalState.server_running:
        try:
            sock.sendto(broadcast_msg, (UDP_BROADCAST_IP, UDP_PORT))
            for _ in range(BROADCAST_INTERVAL):
                if not GlobalState.server_running:
                    break
                time.sleep(0.5)
        except Exception as e:
            logger.debug(f"广播异常: {e}")
            time.sleep(1)

    sock.close()
    logger.info("📡 广播服务已停止")


# ===================== UDP 从站发现 =====================
def udp_discover_masters(timeout: int = DISCOVER_TIMEOUT) -> List[Dict]:
    masters = []
    seen = set()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", UDP_PORT))
    sock.settimeout(1)

    logger.info(f"🔍 扫描主站 (超时: {timeout}秒)...")
    start_time = time.time()

    while time.time() - start_time < timeout:
        try:
            data, addr = sock.recvfrom(2048)
            info = json.loads(data.decode('utf-8', errors='ignore'))
            if info.get("type") == "qclaw_share_master":
                key = f"{info['ip']}:{info['port']}"
                if key not in seen:
                    seen.add(key)
                    masters.append({
                        "name": info.get("hostname", "未知主机"),
                        "ip": info["ip"],
                        "port": info["port"],
                        "mode": info.get("mode", "master"),
                        "version": info.get("version", "1.0"),
                        "display": f"{info.get('hostname', '未知')} | {info['ip']}:{info['port']}"
                    })
                    logger.info(f"✅ 发现主站: {masters[-1]['display']}")
        except socket.timeout:
            continue
        except Exception as e:
            logger.debug(f"接收异常: {e}")
            continue

    sock.close()
    return masters


# ===================== GUI: 二维码弹窗 =====================
def show_qr_popup(url: str, title: str = "QClaw 共享服务"):
    if not tkinter_pkg:
        logger.warning("tkinter 不可用，跳过 GUI 弹窗")
        return

    tk = tkinter_pkg
    root = tk["Tk"]()
    root.title(title)
    root.geometry("420x520")
    root.attributes("-topmost", True)
    root.resizable(False, False)
    GlobalState.qr_window = root

    def on_close():
        logger.info("窗口关闭，停止服务")
        GlobalState.shutdown()

    root.protocol("WM_DELETE_WINDOW", on_close)

    # 标题
    tk["Label"](root, text="🔗 QClaw 局域网共享", font=("Arial", 13, "bold")).pack(pady=(18, 5))
    tk["Label"](root, text="访问地址:", font=("Arial", 10)).pack()
    tk["Label"](root, text=url, wraplength=380, fg="#0066cc", font=("Courier New", 10)).pack(pady=5)

    # 生成二维码
    try:
        qr = qrcode_pkg.QRCode(box_size=8, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

        qr_path = os.path.join(BASE_PATH, "qclaw_qr.png")
        img.save(qr_path)
        logger.info(f"二维码已保存: {qr_path}")

        from PIL import ImageTk
        pil_img = ImageTk.PhotoImage(img)
        qr_label = tk["Label"](root, image=pil_img)
        qr_label.image = pil_img
        qr_label.pack(pady=10)
    except Exception as e:
        tk["Label"](root, text=f"⚠️ 二维码生成失败: {e}", fg="red").pack(pady=10)

    # 按钮
    btn_frame = tk["Frame"](root)
    btn_frame.pack(pady=12)

    def copy_url():
        root.clipboard_clear()
        root.clipboard_append(url)
        tk["messagebox"].showinfo("已复制", "链接已复制到剪贴板！")

    tk["Button"](btn_frame, text="📋 复制链接", command=copy_url, width=12).pack(side="left", padx=8)
    tk["Button"](btn_frame, text="🚪 关闭服务", command=on_close, bg="#e74c3c", fg="white", width=12).pack(side="left", padx=8)

    tk["Label"](root, text="💡 同局域网设备扫码即可访问 / 上传", fg="#666", font=("Arial", 9)).pack(pady=(0, 15))

    root.mainloop()


# ===================== GUI: 主站选择器 =====================
def show_master_selector(masters: List[Dict]):
    if not tkinter_pkg:
        print("\n📡 发现的主站:")
        for i, m in enumerate(masters, 1):
            print(f"  {i}. {m['display']}")
        if masters:
            url = f"http://{masters[0]['ip']}:{masters[0]['port']}"
            print(f"🔗 自动打开: {url}")
            webbrowser.open(url)
        return

    tk = tkinter_pkg
    root = tk["Tk"]()
    root.title("🔍 QClaw 发现共享主站")
    root.geometry("520x380")
    root.attributes("-topmost", True)
    GlobalState.main_window = root

    tk["Label"](root, text=f"✅ 发现 {len(masters)} 个共享主站", font=("Arial", 11, "bold")).pack(pady=10)

    listbox = tk["Listbox"](root, width=65, height=12, selectmode=tk["SINGLE"], font=("Arial", 10))
    scrollbar = tk["Scrollbar"](root, command=listbox.yview)
    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    listbox.pack(pady=5, padx=10)

    for m in masters:
        listbox.insert(tk["END"], m["display"])
    if masters:
        listbox.selection_set(0)

    def select_master():
        sel = listbox.curselection()
        if not sel:
            tk["messagebox"].showwarning("提示", "请先选择一个主站")
            return
        master = masters[sel[0]]
        url = f"http://{master['ip']}:{master['port']}"
        logger.info(f"🔗 打开主站: {url}")
        webbrowser.open(url)
        root.destroy()

    def refresh():
        root.destroy()
        new_masters = udp_discover_masters()
        if new_masters:
            show_master_selector(new_masters)
        else:
            tk["messagebox"].showinfo("提示", "未发现新主站，请确认主站已开启")

    btn_frame = tk["Frame"](root)
    btn_frame.pack(pady=15)
    tk["Button"](btn_frame, text="🚀 打开网关", command=select_master, bg="#27ae60", fg="white", width=16).pack(side="left", padx=8)
    tk["Button"](btn_frame, text="🔄 重新扫描", command=refresh, width=12).pack(side="left", padx=8)
    tk["Button"](btn_frame, text="❌ 退出", command=root.destroy, width=10).pack(side="left", padx=8)

    listbox.bind("<Double-Button-1>", lambda _: select_master())
    tk["Label"](root, text="💡 双击列表项快速打开", fg="#888", font=("Arial", 9)).pack(pady=(0, 10))

    root.mainloop()


# ===================== 服务启动 =====================
def start_server(port: int, file_path: Optional[str] = None, no_gui: bool = False):
    """启动共享服务（主站/单文件模式）"""
    GlobalState.no_gui_mode = no_gui
    GlobalState.flask_app = create_flask_app()
    local_ip = get_local_ip()

    if file_path and os.path.exists(file_path):
        GlobalState.current_mode = "single"
        GlobalState.single_file_path = os.path.abspath(file_path)
        filename = os.path.basename(file_path)
        url = f"http://{local_ip}:{port}/{filename}"
        logger.info(f"📄 单文件模式: {filename}")
    else:
        GlobalState.current_mode = "master"
        url = f"http://{local_ip}:{port}"
        logger.info(f"🌐 主站模式: {url}")

    # 保存二维码到文件
    try:
        qr = qrcode_pkg.QRCode(box_size=8, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        qr_path = os.path.join(BASE_PATH, "qclaw_qr.png")
        img.save(qr_path)
        logger.info(f"二维码已保存: {qr_path}")
    except Exception as e:
        logger.warning(f"二维码生成失败: {e}")

    # 启动 UDP 广播线程
    broadcast_thread = threading.Thread(
        target=udp_broadcast_server,
        args=(port,),
        daemon=True,
        name="UDPBroadcaster"
    )
    broadcast_thread.start()

    # 信号处理
    def signal_handler(signum, frame):
        logger.info(f"收到关闭信号")
        GlobalState.shutdown()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Flask 必须运行在后台线程
    flask_thread = threading.Thread(
        target=lambda: GlobalState.flask_app.run(
            host=HOST, port=port, debug=False, use_reloader=False, threaded=True
        ),
        daemon=True,
        name="FlaskServer"
    )
    flask_thread.start()
    logger.info(f"🚀 Flask 服务运行中: {HOST}:{port}")

    if no_gui or not tkinter_pkg:
        # 无 GUI 模式：打印信息，主线程空转等信号
        print(f"\n{'='*50}")
        print(f"🎯 QClaw 局域网共享服务已启动 (无 GUI)")
        print(f"{'='*50}")
        print(f"🌐 访问地址: {url}")
        print(f"📁 共享目录: {SHARE_DIR}")
        print(f"🌐 本地 IP: {local_ip}")
        print(f"📋 二维码: {qr_path}")
        print(f"{'='*50}")
        print(f"📱 手机/其他设备可直接访问: {url}")
        print(f"💡 关闭服务: Ctrl+C")
        print(f"{'='*50}\n")
        # 用一个事件阻塞主线程，保持进程存活
        GlobalState.server_running = True
        while GlobalState.server_running:
            time.sleep(0.5)

    else:
        # macOS tkinter 必须在主线程测试，先测能否创建窗口
        gui_ok = False
        try:
            test_root = tkinter_pkg["Tk"]()
            test_root.withdraw()
            test_root.destroy()
            gui_ok = True
        except Exception as e:
            logger.warning(f"⚠️ tkinter 窗口测试失败 ({e})，降级为无 GUI 模式")

        if not gui_ok:
            # 降级：打印信息，主线程空转
            print(f"\n{'='*50}")
            print(f"🎯 QClaw 局域网共享服务已启动 (无 GUI)")
            print(f"{'='*50}")
            print(f"🌐 访问地址: {url}")
            print(f"📁 共享目录: {SHARE_DIR}")
            print(f"📋 二维码: {qr_path}")
            print(f"{'='*50}")
            print(f"📱 手机/其他设备可直接访问: {url}")
            print(f"💡 关闭服务: Ctrl+C")
            print(f"{'='*50}\n")
            GlobalState.server_running = True
            while GlobalState.server_running:
                time.sleep(0.5)
        else:
            # GUI 正常：主线程跑 mainloop()，Flask 在后台线程
            print(f"\n{'='*50}")
            print(f"🎯 QClaw 局域网共享服务已启动")
            print(f"🌐 访问地址: {url}")
            print(f"📁 共享目录: {SHARE_DIR}")
            print(f"📋 二维码: {qr_path}")
            print(f"{'='*50}")
            show_qr_popup(url, "QClaw 局域网共享")


# ===================== 主入口 =====================
def main():
    global SHARE_DIR

    # ===== 自动检查并安装依赖 =====
    ensure_dependencies()

    parser = argparse.ArgumentParser(
        description="🔗 QClaw 局域网二维码文件共享工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python %(prog)s --master                          # 主站模式
  python %(prog)s --master --dir ~/Desktop           # 共享桌面
  python %(prog)s --single /path/to/file.pdf         # 单文件共享
  python %(prog)s --slave                           # 从站发现
  python %(prog)s --master --no-gui                 # 无 GUI（服务器用）
  python %(prog)s --master --port 9000               # 自定义端口
        """
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--master", action="store_true", help="主站模式：开启文件共享网关")
    mode_group.add_argument("--single", metavar="FILE", help="单文件模式：直接共享指定文件")
    mode_group.add_argument("--slave", action="store_true", help="从站模式：自动发现并连接主站")

    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"服务端口 (默认: {DEFAULT_PORT})")
    parser.add_argument("--dir", "--path", dest="dir", type=str, default=None,
                        help="共享目录路径（默认: skill 同目录的 qclaw_shared）")
    parser.add_argument("--timeout", type=int, default=DISCOVER_TIMEOUT,
                        help=f"从站发现超时秒数 (默认: {DISCOVER_TIMEOUT})")
    parser.add_argument("--no-gui", action="store_true",
                        help="禁用 GUI 弹窗（适合服务器/Linux/无桌面环境）")

    args = parser.parse_args()

    # 先用 no_gui 模式检查依赖，避免 tkinter 崩溃
    check_dependencies(no_gui=args.no_gui)
    init_share_dir()

    # 处理自定义共享目录
    if args.dir:
        SHARE_DIR = os.path.abspath(os.path.expanduser(args.dir))
        os.makedirs(SHARE_DIR, exist_ok=True)

    logger.info("=" * 50)
    logger.info("🎯 QClaw 局域网共享工具启动")
    logger.info(f"📁 共享目录: {SHARE_DIR}")
    logger.info(f"🌐 本地 IP: {get_local_ip()}")
    logger.info(f"🎨 GUI 模式: {'禁用' if args.no_gui else '启用'}")
    logger.info("=" * 50)

    # 从站模式
    if args.slave:
        masters = udp_discover_masters(timeout=args.timeout)
        if not masters:
            print("\n❌ 未发现任何共享主站")
            print("💡 请确保主站已启动，且在同一局域网内")
            sys.exit(1)

        if args.no_gui or not tkinter_pkg:
            first = masters[0]
            url = f"http://{first['ip']}:{first['port']}"
            print(f"\n📡 发现主站: {first['display']}")
            print(f"🔗 自动打开: {url}")
            webbrowser.open(url)
        else:
            show_master_selector(masters)
        return

    # 主站 / 单文件模式
    start_server(
        port=args.port,
        file_path=args.single if args.single else None,
        no_gui=args.no_gui
    )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 服务已停止")
        sys.exit(0)
    except Exception as e:
        logger.exception(f"❌ 程序异常: {e}")
        sys.exit(1)
