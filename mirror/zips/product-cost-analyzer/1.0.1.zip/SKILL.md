---
name: product-cost-analyzer
version: 1.0.0
description: 计算产品总成本、单位成本及各项成本（原料、包装、制造费用、管理费用、运费、税金）的构成与占比
inputs: ./schema.json#/input
outputs: ./schema.json#/output
---

# 产品成本分析技能

## 功能描述

本技能用于核算单个或批量产品的完全成本，并自动生成：
- 总成本 & 单位成本
- 各项成本金额明细（含制造费用子项：人工、折旧、水电、维修、低值易耗）
- 各项成本占总成本的百分比（用于成本结构分析）

## 输入参数（详见 `schema.json`）

| 字段              | 类型          | 必填 | 说明                                         |
| ----------------- | ------------- | ---- | -------------------------------------------- |
| `product_name`    | string        | 是   | 产品名称                                     |
| `quantity`        | number        | 是   | 生产数量，必须 > 0                           |
| `raw_material`    | number        | 否   | 原料总成本，默认 0                           |
| `packaging`       | number        | 否   | 包装总成本，默认 0                           |
| `manufacturing`   | object        | 否   | 包含 `labor`, `depreciation`, `utilities`, `maintenance`, `consumables`，默认 0 |
| `admin_expense`   | number        | 否   | 管理费用总额，默认 0                         |
| `freight`         | number        | 否   | 运费总额，默认 0                             |
| `tax`             | number        | 否   | 税金总额，默认 0                             |

## 输出结果

```json
{
  "product_name": "string",
  "quantity": 1000,
  "total_cost": 11100,
  "unit_cost": 11.1,
  "cost_breakdown": { ... },   // 金额明细（含制造费用分项）
  "percentage_breakdown": { ... } // 各项占总成本百分比
}