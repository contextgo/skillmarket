import json
from typing import Dict, Any

def run(input_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    产品成本分析核心函数
    :param input_data: 符合 schema 的输入字典
    :return: 输出字典，包含总成本、单位成本、成本明细及百分比
    """
    # 提取并验证数量
    quantity = input_data.get("quantity", 0)
    if quantity <= 0:
        return {"error": "生产数量必须大于0"}

    product_name = input_data.get("product_name", "未知产品")

    # 原料
    raw_material = max(0, input_data.get("raw_material", 0))
    # 包装
    packaging = max(0, input_data.get("packaging", 0))
    # 制造费用明细
    mfg = input_data.get("manufacturing", {})
    labor = max(0, mfg.get("labor", 0))
    depreciation = max(0, mfg.get("depreciation", 0))
    utilities = max(0, mfg.get("utilities", 0))
    maintenance = max(0, mfg.get("maintenance", 0))
    consumables = max(0, mfg.get("consumables", 0))
    manufacturing_total = labor + depreciation + utilities + maintenance + consumables
    # 管理费用
    admin_expense = max(0, input_data.get("admin_expense", 0))
    # 运费
    freight = max(0, input_data.get("freight", 0))
    # 税金
    tax = max(0, input_data.get("tax", 0))

    # 总成本
    total_cost = (raw_material + packaging + manufacturing_total +
                  admin_expense + freight + tax)

    # 单位成本
    unit_cost = total_cost / quantity

    # 成本明细（金额）
    cost_breakdown = {
        "raw_material": raw_material,
        "packaging": packaging,
        "manufacturing_total": manufacturing_total,
        "manufacturing_details": {
            "labor": labor,
            "depreciation": depreciation,
            "utilities": utilities,
            "maintenance": maintenance,
            "consumables": consumables
        },
        "admin_expense": admin_expense,
        "freight": freight,
        "tax": tax
    }

    # 计算百分比（避免除以0）
    if total_cost == 0:
        percentage_breakdown = {
            "raw_material": 0.0,
            "packaging": 0.0,
            "manufacturing": 0.0,
            "admin_expense": 0.0,
            "freight": 0.0,
            "tax": 0.0
        }
    else:
        percentage_breakdown = {
            "raw_material": round(raw_material / total_cost * 100, 2),
            "packaging": round(packaging / total_cost * 100, 2),
            "manufacturing": round(manufacturing_total / total_cost * 100, 2),
            "admin_expense": round(admin_expense / total_cost * 100, 2),
            "freight": round(freight / total_cost * 100, 2),
            "tax": round(tax / total_cost * 100, 2)
        }

    return {
        "product_name": product_name,
        "quantity": quantity,
        "total_cost": total_cost,
        "unit_cost": unit_cost,
        "cost_breakdown": cost_breakdown,
        "percentage_breakdown": percentage_breakdown
    }