# 支付成功回调通知（服务商 - Go）

> 内容与 [`Java/5-回调通知/支付成功回调通知说明.md`](../../Java/5-回调通知/支付成功回调通知说明.md) 完全一致；本副本仅为 Go 项目按目录约定查找方便而存在。

> 源文档：[支付成功回调通知](https://pay.weixin.qq.com/doc/v3/partner/4012586136.md)
> 通用解密 / 验签 / 回包流程：[../../../接入指南/回调处理.md](../../../接入指南/回调处理.md)

## 触发场景

完结订单后，若订单 `need_collection = true`，微信支付分异步发起代扣，并在收款进展变化时回推本通知。

## 回调报文骨架

```json
{
  "id": "EV-2018022511223320873",
  "create_time": "2015-05-20T13:29:35+08:00",
  "resource_type": "encrypt-resource",
  "event_type": "PAYSCORE.USER_PAID",
  "summary": "用户支付成功",
  "resource": {
    "original_type": "payscore",
    "algorithm": "AEAD_AES_256_GCM",
    "ciphertext": "<密文，使用服务商 APIv3 密钥解密>",
    "associated_data": "transaction",
    "nonce": "<随机串>"
  }
}
```

## 解密后关键字段

| 字段 | 说明 |
|------|------|
| `sp_mchid` / `sub_mchid` | 服务商号、特约商户号 |
| `out_order_no` | 商户订单号 |
| `state` | `DONE` |
| `collection.state` | 终态多为 `USER_PAID` |
| `collection.paid_amount` | 已收款金额（分），需累计 |
| `collection.details[]` | 每笔扣款明细：`amount` / `paid_type` / `paid_time` / `transaction_id` |
| `transaction_id` | **特约商户**收款的支付单号；用于资金对账与分账请求 |

## 服务商处理要求

1. **路由 + 幂等**：以 `sub_mchid` 路由 → 以 `out_order_no` 幂等。
2. **状态机**：终态前可能多次回推（多笔代扣），需累加 `paid_amount` 写入流水表，避免覆盖。
3. **资金归属**：扣款资金直接进入特约商户账户；服务商若有分润需求，请走「服务商分账」（基于此 `transaction_id`）。
4. **应答**：成功返回 `200 + {"code":"SUCCESS","message":"成功"}`。

## 与商户模式的差异

- 资金最终进入 `sub_mchid` 账户（不是 `sp_mchid`）。
- 分账请求需以 `sub_mchid` + `transaction_id` 调用「服务商分账」相关接口。
