# 确认订单回调通知（服务商 - Go）

> 内容与 [`Java/5-回调通知/确认订单回调通知说明.md`](../../Java/5-回调通知/确认订单回调通知说明.md) 完全一致；本副本仅为 Go 项目按目录约定查找方便而存在。

> 源文档：[确认订单回调通知](https://pay.weixin.qq.com/doc/v3/partner/4012586137.md)
> 通用解密 / 验签 / 回包流程：[../../../接入指南/回调处理.md](../../../接入指南/回调处理.md)
> 通用签名规则：[../../../接入指南/签名与验签规则.md](../../../接入指南/签名与验签规则.md)

## 触发场景

特约商户的用户在「确认订单」页面点击同意后，微信支付分以 **POST** 方式向 **服务商在创建订单时填写的 `notify_url`** 推送本通知。所有特约商户共用同一个 `notify_url`，服务商需以解密后报文中的 `sub_mchid` 为路由依据。

## 回调报文骨架

```json
{
  "id": "EV-2018022511223320873",
  "create_time": "2015-05-20T13:29:35+08:00",
  "resource_type": "encrypt-resource",
  "event_type": "PAYSCORE.USER_CONFIRM",
  "summary": "支付分订单用户已确认",
  "resource": {
    "original_type": "payscore",
    "algorithm": "AEAD_AES_256_GCM",
    "ciphertext": "<密文，使用服务商 APIv3 密钥 + AEAD_AES_256_GCM 解密后得到 ServiceOrderEntity>",
    "associated_data": "transaction",
    "nonce": "<随机串>"
  }
}
```

## 关键字段（解密后）

| 字段 | 说明 |
|------|------|
| `sp_mchid` | 服务商商户号 |
| `sp_appid` | 服务商 appid |
| `sub_mchid` | **特约商户号**——服务商按此字段路由到对应特约商户的业务系统 |
| `sub_appid` | 特约商户 appid（如有） |
| `out_order_no` | 服务商生成的商户订单号，幂等键 |
| `service_id` | 在该子商户上申请的支付分服务 ID |
| `state` | `DOING`（用户已确认） |
| `openid` | 用户在 sub_appid（无 sub_appid 时为 sp_appid）下的 openid |

## 服务商处理要求

1. **验签**：使用 **服务商 API 证书私钥对应的公钥** 验签（不是子商户的）；微信支付公钥同样使用服务商体系下的公钥。
2. **解密**：使用 **服务商 APIv3 密钥** 解密；不要使用子商户的密钥。
3. **路由**：先按 `sub_mchid` 路由到对应特约商户的业务系统；按 `out_order_no + event_type` 幂等。
4. **状态机**：将订单标记为 `DOING`，登记 `openid` / `order_id`，可开始提供服务。
5. **应答**：成功返回 `200 + {"code":"SUCCESS","message":"成功"}`；业务异常返回 5xx 触发重试。

## 与商户模式的差异

| 对比项 | 商户模式 | 服务商模式 |
|--------|----------|-----------|
| 解密密钥 | 商户 APIv3 密钥 | **服务商** APIv3 密钥（不能用子商户的） |
| 验签证书 | 商户接入的微信支付公钥 | **服务商**接入的微信支付公钥 |
| 路由字段 | `mchid` | `sub_mchid` |
| openid 归属 | `appid` | `sub_appid` 或 `sp_appid` |
