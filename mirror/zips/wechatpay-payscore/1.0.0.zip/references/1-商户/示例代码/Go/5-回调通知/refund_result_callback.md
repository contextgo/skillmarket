# 退款结果回调通知（商户 - Go）

> 内容与 [`Java/5-回调通知/退款结果回调通知说明.md`](../../Java/5-回调通知/退款结果回调通知说明.md) 完全一致；本副本仅为 Go 项目按目录约定查找方便而存在。

> 源文档：[退款结果通知](https://pay.weixin.qq.com/doc/v3/merchant/4012587976.md)
> 通用解密 / 验签 / 回包流程：[../接入指南/回调处理.md](../../../接入指南/回调处理.md)

## 触发场景

商户调用「申请退款」接口（`/v3/payscore/refunds`）受理后，微信支付分异步处理实际退款，退款进入终态时（`SUCCESS` / `CLOSED` / `ABNORMAL`）回推本通知。

## 回调报文骨架

```json
{
  "id": "EV-2018022511223320873",
  "create_time": "2015-05-20T13:29:35+08:00",
  "resource_type": "encrypt-resource",
  "event_type": "REFUND.SUCCESS",
  "summary": "退款成功",
  "resource": {
    "original_type": "refund",
    "algorithm": "AEAD_AES_256_GCM",
    "ciphertext": "<密文，使用商户 APIv3 密钥 + AEAD_AES_256_GCM 解密后得到退款详情>",
    "associated_data": "refund",
    "nonce": "<随机串>"
  }
}
```

## event_type 一览

| event_type | 含义 | 处理建议 |
|------------|------|---------|
| `REFUND.SUCCESS` | 退款成功 | 更新业务退款单为成功，触发对账 / 通知用户 |
| `REFUND.CLOSED` | 退款被关闭 | 一般为商户重复发起 / 资金不足等，需按 `refund_status` + `error_msg` 分支处理 |
| `REFUND.ABNORMAL` | 退款异常 | 按异常原因人工介入，可发起「异常退款」补救 |

## 解密后关键字段

| 字段 | 说明 |
|------|------|
| `out_refund_no` | 商户退款单号，幂等键 |
| `refund_id` | 微信侧退款单号，唯一 |
| `out_order_no` | 关联的支付分订单号 |
| `transaction_id` | 关联的支付单号（若该退款关联具体扣款流水） |
| `amount.refund` | 实际退款金额（分） |
| `refund_status` | `SUCCESS` / `CLOSED` / `PROCESSING` / `ABNORMAL` |
| `success_time` | 退款成功时间 |

## 商户处理要求

1. **验签 + 解密** 与 `回调处理.md` 一致。
2. **幂等**：以 `out_refund_no` 入库去重；同一单多次回调取最新终态。
3. **状态机**：仅信任 `refund_status` 字段，不要以 HTTP 200 作为退款成功判据。
4. **多退一致性**：如需多次部分退款，需累加 `amount.refund`，确保不超过 `total_amount`。
5. **应答**：成功返回 `200 + {"code":"SUCCESS","message":"成功"}`。
