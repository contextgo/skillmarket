#!/usr/bin/env node
/**
 * Edge TTS Voice Skill - 测试脚本
 * 测试 TTS 服务是否正常工作
 */

const http = require('http');

const COLORS = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${COLORS[color]}${message}${COLORS.reset}`);
}

const TEST_CASES = [
  { text: '你好，这是中文测试', voice: 'zh-CN-XiaoxiaoNeural', desc: '中文女声' },
  { text: 'Hello, this is an English test', voice: 'zh-CN-XiaoxiaoNeural', desc: '英文测试' },
  { text: '欢迎使用 Edge TTS 语音服务', voice: 'zh-CN-YunxiNeural', desc: '中文男声' }
];

async function testTTS(text, voice, desc) {
  const testData = JSON.stringify({ input: text, voice });
  
  const options = {
    hostname: '127.0.0.1',
    port: 5050,
    path: '/v1/audio/speech',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': testData.length
    }
  };
  
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(chunks);
        if (buffer.length > 0) {
          resolve(buffer.length);
        } else {
          reject(new Error('生成空音频'));
        }
      });
    });
    
    req.on('error', reject);
    req.write(testData);
    req.end();
    
    setTimeout(() => reject(new Error('请求超时')), 10000);
  });
}

async function runTests() {
  log('\n🎵 Edge TTS Voice Skill - 测试程序', 'cyan');
  log('=' .repeat(50), 'cyan');
  
  log('\n正在连接 TTS 服务器...', 'blue');
  
  // 检查服务是否运行
  try {
    await testTTS('测试', 'zh-CN-XiaoxiaoNeural', '连接测试');
    log('✅ TTS 服务器运行正常', 'green');
  } catch (error) {
    log('❌ TTS 服务器未响应', 'red');
    log('请先启动服务：node workspace/tts-server.js', 'yellow');
    process.exit(1);
  }
  
  // 运行测试用例
  log('\n开始测试语音生成...\n', 'blue');
  
  for (const testCase of TEST_CASES) {
    process.stdout.write(`测试：${testCase.desc}... `);
    
    try {
      const size = await testTTS(testCase.text, testCase.voice, testCase.desc);
      log(`✅ 成功 (${size} 字节)`, 'green');
    } catch (error) {
      log(`❌ 失败：${error.message}`, 'red');
    }
  }
  
  log('\n' + '='.repeat(50), 'cyan');
  log('🎉 测试完成！', 'green');
  log('='.repeat(50), 'cyan');
  log('\n');
}

runTests().catch(error => {
  log(`❌ 测试失败：${error.message}`, 'red');
  process.exit(1);
});
