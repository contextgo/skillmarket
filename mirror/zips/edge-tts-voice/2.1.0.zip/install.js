#!/usr/bin/env node
/**
 * Edge TTS Voice Skill - 自动安装脚本
 * 一键安装 TTS 服务，自动配置 OpenClaw
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const COLORS = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${COLORS[color]}${message}${COLORS.reset}`);
}

function exec(command) {
  try {
    return execSync(command, { encoding: 'utf8', stdio: 'pipe' });
  } catch (error) {
    return null;
  }
}

// 配置
const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.join(process.env.APPDATA, '..', '.openclaw', 'workspace');
const SKILL_DIR = path.join(WORKSPACE, 'skills', 'edge-tts-voice');
const BACKUP_DIR = path.join(WORKSPACE, 'backups', `edge-tts-install-${Date.now()}`);
const CONFIG_FILE = path.join(path.dirname(WORKSPACE), 'openclaw.json');

log('\n🎵 Edge TTS Voice Skill - 自动安装程序', 'cyan');
log('=' .repeat(50), 'cyan');

// Step 1: 检查环境
log('\n[1/7] 检查环境...', 'blue');

try {
  const nodeVersion = exec('node --version');
  log(`✅ Node.js: ${nodeVersion.trim()}`, 'green');
} catch (error) {
  log('❌ 错误：需要安装 Node.js', 'red');
  process.exit(1);
}

// Step 2: 检查依赖
log('\n[2/7] 检查依赖...', 'blue');

try {
  log('正在检查 edge-tts (Python)...', 'yellow');
  const result = exec('edge-tts --version');
  if (result) {
    log(`✅ edge-tts 已安装：${result.trim()}`, 'green');
  } else {
    log('⚠️  edge-tts 未安装，请手动安装：pip install edge-tts', 'yellow');
    log('   或访问：https://pypi.org/project/edge-tts/', 'yellow');
  }
} catch (error) {
  log('⚠️  edge-tts 未安装，请手动安装：pip install edge-tts', 'yellow');
  log('   或访问：https://pypi.org/project/edge-tts/', 'yellow');
}

// Step 3: 备份配置
log('\n[3/7] 备份配置...', 'blue');

try {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
  
  if (fs.existsSync(CONFIG_FILE)) {
    fs.copyFileSync(CONFIG_FILE, path.join(BACKUP_DIR, 'openclaw.json.backup'));
    log(`✅ 配置已备份到：${BACKUP_DIR}`, 'green');
  } else {
    log('⚠️ 未找到配置文件，将创建新配置', 'yellow');
  }
} catch (error) {
  log(`⚠️ 备份失败：${error.message}`, 'yellow');
}

// Step 4: 复制 TTS 服务器
log('\n[4/7] 部署 TTS 服务器...', 'blue');

try {
  const ttsServerSrc = path.join(SKILL_DIR, 'tts-server.js');
  const ttsServerDest = path.join(WORKSPACE, 'tts-server.js');
  
  if (fs.existsSync(ttsServerSrc)) {
    fs.copyFileSync(ttsServerSrc, ttsServerDest);
    log(`✅ TTS 服务器已复制到：${ttsServerDest}`, 'green');
  } else {
    log('❌ 未找到 tts-server.js', 'red');
    process.exit(1);
  }
} catch (error) {
  log(`❌ 复制失败：${error.message}`, 'red');
  process.exit(1);
}

// Step 5: 修改 OpenClaw 配置
log('\n[5/7] 配置 OpenClaw...', 'blue');

try {
  let config = {};
  
  if (fs.existsSync(CONFIG_FILE)) {
    const content = fs.readFileSync(CONFIG_FILE, 'utf8');
    config = JSON.parse(content);
  }
  
  // 添加 QQBot TTS 配置
  config['channels.qqbot.tts'] = {
    enabled: true,
    provider: 'openai',
    baseUrl: 'http://127.0.0.1:5050/v1',
    apiKey: 'not-needed',
    voice: 'zh-CN-XiaoxiaoNeural'
  };
  
  // 添加全局 TTS 配置
  config['messages.tts'] = {
    auto: 'always',
    provider: 'openai',
    maxTextLength: 1500,
    providers: {
      openai: {
        enabled: true,
        baseUrl: 'http://127.0.0.1:5050/v1',
        apiKey: 'not-needed',
        voice: 'zh-CN-XiaoxiaoNeural'
      }
    }
  };
  
  // 添加 OpenAI provider 配置（必需）
  if (!config.models) config.models = {};
  if (!config.models.providers) config.models.providers = {};
  config.models.providers.openai = {
    enabled: true,
    baseUrl: 'http://127.0.0.1:5050/v1',
    apiKey: 'not-needed'
  };
  
  // 保存配置
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
  log('✅ OpenClaw 配置已更新', 'green');
  
} catch (error) {
  log(`❌ 配置失败：${error.message}`, 'red');
  log('请手动配置 openclaw.json', 'yellow');
}

// Step 6: 创建 Windows 计划任务（可选）
log('\n[6/7] 创建 Windows 计划任务（开机自启）...', 'blue');

try {
  const serviceScript = path.join(WORKSPACE, 'tts-server-wrapper.bat');
  const serviceContent = `@echo off
REM Edge TTS Server - Windows 启动脚本
cd /d "${WORKSPACE}"
start "Edge TTS Server" node tts-server.js
`;
  
  fs.writeFileSync(serviceScript, serviceContent);
  log('✅ 启动脚本已创建', 'green');
  
  // 尝试创建计划任务
  const taskName = 'EdgeTTSServer';
  const taskCmd = `schtasks /Create /TN "${taskName}" /TR "${serviceScript}" /SC ONLOGON /RL HIGHEST /F`;
  
  try {
    exec(taskCmd);
    log('✅ Windows 计划任务已创建', 'green');
    log(`   任务名：${taskName}`, 'yellow');
  } catch (taskError) {
    log('⚠️  计划任务创建失败（需要管理员权限）', 'yellow');
    log('   可手动创建：右键 tts-server-wrapper.bat → 创建基本任务', 'yellow');
  }
  
} catch (error) {
  log(`⚠️ 服务创建失败：${error.message}`, 'yellow');
}

// Step 7: 测试服务
log('\n[7/7] 测试 TTS 服务...', 'blue');

try {
  log('正在启动 TTS 服务器...', 'yellow');
  
  // 启动服务（后台）
  const { spawn } = require('child_process');
  const ttsProcess = spawn('node', [path.join(WORKSPACE, 'tts-server.js')], {
    detached: true,
    stdio: 'ignore'
  });
  ttsProcess.unref();
  
  // 等待服务启动
  log('等待服务启动...', 'yellow');
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  await sleep(3000);
  
  // 测试 API
  const http = require('http');
  
  const testData = JSON.stringify({
    input: '你好，这是 Edge TTS 语音测试',
    voice: 'zh-CN-XiaoxiaoNeural'
  });
  
  const options = {
    hostname: '127.0.0.1',
    port: 5050,
    path: '/v1/audio/speech',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': testData.length
    }
  };
  
  await new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(chunks);
        if (buffer.length > 0) {
          log(`✅ 测试成功！生成 ${buffer.length} 字节音频`, 'green');
          resolve();
        } else {
          reject(new Error('生成空音频'));
        }
      });
    });
    
    req.on('error', reject);
    req.write(testData);
    req.end();
    
    // 超时保护
    setTimeout(() => reject(new Error('请求超时')), 10000);
  });
  
} catch (error) {
  log(`⚠️ 测试失败：${error.message}`, 'yellow');
  log('可以手动启动服务：node workspace/tts-server.js', 'yellow');
}

// 完成
log('\n' + '='.repeat(50), 'cyan');
log('🎉 安装完成！', 'green');
log('='.repeat(50), 'cyan');

log('\n📋 下一步操作：', 'blue');
log('1. 重启 OpenClaw Gateway: openclaw gateway restart', 'yellow');
log('2. 在 QQ 中发送消息测试语音回复', 'yellow');
log('3. 查看配置说明：cat skills/edge-tts-voice/SKILL.md', 'yellow');

log('\n🛠️  管理命令：', 'blue');
log('• 启动服务：node workspace/tts-server.js', 'yellow');
log('• 停止服务：taskkill /F /PID <进程 ID>', 'yellow');
log('• 检查状态：netstat -ano | findstr :5050', 'yellow');

log('\n💾 备份位置：', 'blue');
log(BACKUP_DIR, 'yellow');

log('\n祝你使用愉快！🎵\n', 'green');
