# 🎵 Edge TTS Voice Skill (v2.0 - CLI 方案)

为 OpenClaw QQBot 提供**免费、稳定、高质量**的中文语音合成功能。

**v2.0 新特性**：进程级隔离、5000+ 字符超长文本、UTF-8 编码优化

---

## ⚡ 快速开始

### 前置要求

```bash
# 安装 Python edge-tts 包
pip install edge-tts
```

### 一键安装

```bash
# 方式 1：SkillHub（推荐）
python "C:\Users\你的用户名\.skillhub\skills_store_cli.py" install edge-tts-voice

# 方式 2：ClawHub
clawhub install edge-tts-voice

# 方式 3：手动安装
node workspace/skills/edge-tts-voice/install.js
```

### 测试语音

```bash
node workspace/skills/edge-tts-voice/test-tts.js
```

### 重启 Gateway

```bash
openclaw gateway restart
```

---

## 📦 技能包结构

```
edge-tts-voice/
├── SKILL.md           # 技能说明文档
├── install.js         # 自动安装脚本
├── uninstall.js       # 卸载脚本
├── tts-server.js      # TTS 服务器（核心）
├── test-tts.js        # 测试脚本
├── package.json       # 包配置
└── README.md          # 本文件
```

---

## 🔧 安装脚本做了什么？

1. ✅ 检查依赖 `edge-tts` (Python 包)
2. ✅ 备份现有配置
3. ✅ 复制 `tts-server.js` 到 workspace
4. ✅ 修改 `openclaw.json` 添加 TTS 配置
5. ✅ 创建 Windows 计划任务（开机自启）
6. ✅ 自动测试语音生成

---

## 🎵 支持的语音

| 语音 | 性别 | 风格 | 适用场景 |
|------|------|------|---------|
| `zh-CN-XiaoxiaoNeural` | 女 | 温暖、友好 | 通用、助手 |
| `zh-CN-YunxiNeural` | 男 | 沉稳、专业 | 新闻、讲解 |
| `zh-CN-YunjianNeural` | 男 | 激情、运动 | 体育、广告 |
| `zh-CN-XiaoyiNeural` | 女 | 活泼、可爱 | 娱乐、客服 |
| `zh-CN-YunyangNeural` | 男 | 专业、新闻 | 播客、朗读 |

---

## 🛠️ 管理命令

```bash
# 启动服务
node workspace/tts-server.js

# 停止服务
netstat -ano | findstr :5050
taskkill /F /PID <找到 PID>

# 测试服务（短文本）
node workspace/skills/edge-tts-voice/test-tts.js

# 测试服务（长文本）
node -e "fetch('http://127.0.0.1:5050/v1/audio/speech',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({input:'这是一段超长文本测试，用于验证 CLI 方案是否支持 5000+ 字符的语音合成。'.repeat(100),voice:'zh-CN-XiaoxiaoNeural'})}).then(r=>r.arrayBuffer()).then(b=>console.log('生成成功：'+b.byteLength+' bytes'))"

# 卸载技能
node workspace/skills/edge-tts-voice/uninstall.js
```

---

## 📖 完整文档

查看 `SKILL.md` 获取详细说明。

---

## 💡 技巧

### 更换语音

修改 `workspace/tts-server.js` 中的 `DEFAULT_VOICE`：

```javascript
const DEFAULT_VOICE = 'zh-CN-YunxiNeural'; // 改为男声
```

然后重启服务。

### 自定义配置

编辑 `openclaw.json`：

```json
{
  "channels.qqbot.tts": {
    "enabled": true,
    "provider": "openai",
    "baseUrl": "http://127.0.0.1:5050/v1",
    "voice": "zh-CN-XiaoxiaoNeural"
  }
}
```

---

## 🐛 故障排查

**问题**：服务无法启动

```bash
# 检查端口占用
netstat -ano | findstr :5050
# 杀死占用进程
taskkill /F /PID <找到 PID>
```

**问题**：语音生成失败

```bash
# 检查 edge-tts 是否安装
edge-tts --version

# 测试 edge-tts CLI
edge-tts --text "测试" --voice zh-CN-XiaoxiaoNeural --write-media test.mp3

# 查看日志
Get-Content workspace/tts-server.log -Tail 50
```

**问题**：中文乱码

```bash
# CLI 方案已自动使用 UTF-8 临时文件，无需手动处理
# 如仍有问题，检查 Python 默认编码
python -c "import sys; print(sys.getdefaultencoding())"
```

---

## 📚 资源

- [SKILL.md](SKILL.md) - 完整文档
- [Microsoft Edge TTS](https://docs.microsoft.com/azure/cognitive-services/speech-service/)
- [OpenClaw 文档](https://docs.openclaw.ai)

---

**祝你使用愉快！** 🎵
