#!/usr/bin/env node
/**
 * Edge TTS HTTP Server - CLI 方案
 * 监听 127.0.0.1:5050，提供 OpenAI 兼容的 TTS API
 * 使用 edge-tts CLI（Python）替代 node-edge-tts 库
 * 进程级隔离，崩溃不影响主进程，支持 5000+ 字符超长文本
 */

const http = require('http');
const { execFile } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

const PORT = 5050;
const HOST = '127.0.0.1';
const DEFAULT_VOICE = 'zh-CN-XiaoxiaoNeural';
const DEFAULT_TIMEOUT = 60000; // 60s CLI 超时（支持超长文本）
const MAX_RETRIES = 2;

console.log('🎵 Edge TTS Server starting (CLI mode)...');
console.log(`   Listening on http://${HOST}:${PORT}`);
console.log(`   Default voice: ${DEFAULT_VOICE}`);
console.log('   Mode: edge-tts CLI (subprocess isolation)');
console.log('   Max text length: 5000+ chars');
console.log('');

// 带超时的 Promise 包装器
function withTimeout(promise, ms, context = '') {
  return Promise.race([
    promise,
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error(`Timeout after ${ms}ms${context ? ': ' + context : ''}`)), ms)
    )
  ]);
}

// 使用 edge-tts CLI 生成音频（带超时保护和重试）
async function generateAudio(text, voice = DEFAULT_VOICE) {
  let lastError = null;
  
  for (let attempt = 1; attempt <= MAX_RETRIES + 1; attempt++) {
    const tmpFile = path.join(os.tmpdir(), `tts-${Date.now()}-${Math.random().toString(36).slice(2)}-${attempt}.mp3`);
    
    try {
      console.log(`   Attempt ${attempt}/${MAX_RETRIES + 1}...`);
      
      // 对于超长文本，使用临时文件传递（避免 CLI 参数长度限制和编码问题）
      const useFile = text.length > 500;
      let cliArgs;
      
      if (useFile) {
        const textFile = path.join(os.tmpdir(), `tts-text-${Date.now()}.txt`);
        fs.writeFileSync(textFile, text, 'utf8');
        cliArgs = [
          '--file', textFile,
          '--voice', voice,
          '--write-media', tmpFile
        ];
        // CLI 执行后删除文本文件
        setTimeout(() => { try { fs.unlinkSync(textFile); } catch(e) {} }, 5000);
      } else {
        cliArgs = [
          '--text', text,
          '--voice', voice,
          '--write-media', tmpFile
        ];
      }

      // execFile 自动处理参数转义，无需手动处理引号
      const cliCmd = 'edge-tts';
      
      // 使用 execFile 而非 exec，更安全（无 shell 注入风险）
      await withTimeout(
        new Promise((resolve, reject) => {
          const child = execFile(cliCmd, cliArgs, { timeout: DEFAULT_TIMEOUT }, (error, stdout, stderr) => {
            if (error) {
              reject(new Error(stderr || error.message || 'edge-tts CLI failed'));
            } else {
              resolve({ stdout, stderr });
            }
          });
        }),
        DEFAULT_TIMEOUT + 5000,
        `CLI for "${text.slice(0, 30)}..."`
      );
      
      // 验证文件存在且非空
      if (!fs.existsSync(tmpFile)) {
        throw new Error('Output file not created');
      }
      
      const stat = fs.statSync(tmpFile);
      if (stat.size === 0) {
        throw new Error('Generated empty audio');
      }
      
      // 读取文件到内存
      const audio = fs.readFileSync(tmpFile);
      
      // 删除临时文件
      try { fs.unlinkSync(tmpFile); } catch(e) {}
      
      return audio;
      
    } catch (err) {
      lastError = err;
      console.error(`   Attempt ${attempt} failed: ${err.message}`);
      
      // 清理失败的临时文件
      try { fs.unlinkSync(tmpFile); } catch(e) {}
      
      // 重试前等待（指数退避）
      if (attempt <= MAX_RETRIES) {
        const delay = 1000 * attempt; // 1s, 2s
        console.log(`   Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw new Error(`All ${MAX_RETRIES + 1} attempts failed. Last error: ${lastError?.message}`);
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method !== 'POST' || req.url !== '/v1/audio/speech') {
    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Not found' }));
    return;
  }

  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });

  req.on('end', async () => {
    const startTime = Date.now();

    try {
      const data = JSON.parse(body);
      const text = data.input || data.text || '';
      const voice = data.voice || DEFAULT_VOICE;

      if (!text) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Missing "input" or "text" field' }));
        return;
      }

      const textPreview = text.slice(0, 50) + (text.length > 50 ? '...' : '');
      console.log(`[${new Date().toISOString()}] Request: "${textPreview}"`);
      console.log(`   Voice: ${voice}`);

      // 生成音频（使用官方公开 API: ttsPromise）
      const audioBuffer = await generateAudio(text, voice);

      if (audioBuffer.length === 0) {
        throw new Error('Generated empty audio buffer');
      }

      const duration = Date.now() - startTime;
      console.log(`   ✓ Generated ${audioBuffer.length} bytes in ${duration}ms`);

      res.setHeader('Content-Type', 'audio/mpeg');
      res.setHeader('Content-Length', audioBuffer.length);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.writeHead(200);
      res.end(audioBuffer);

    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`   ✗ Error after ${duration}ms:`, error.message);

      res.writeHead(500);
      res.end(JSON.stringify({
        error: error.message,
        type: error.constructor.name
      }));
    }
  });

  // 客户端断开清理（仅日志）
  req.on('close', () => {
    console.log(`[${new Date().toISOString()}] Client disconnected`);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`✅ Edge TTS Server is running!`);
  console.log('');
  console.log('Usage examples:');
  console.log('  curl -X POST http://127.0.0.1:5050/v1/audio/speech \\');
  console.log('    -H "Content-Type: application/json" \\');
  console.log('    -d \'{"input": "你好，世界", "voice": "zh-CN-XiaoxiaoNeural"}\' \\');
  console.log('    --output test.mp3');
  console.log('');
  console.log('OpenClaw QQBot config:');
  console.log('  channels.qqbot.tts: {');
  console.log('    "provider": "openai",');
  console.log('    "baseUrl": "http://127.0.0.1:5050/v1",');
  console.log('    "apiKey": "not-needed",');
  console.log('    "voice": "zh-CN-XiaoxiaoNeural"');
  console.log('  }');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`❌ Port ${PORT} is already in use!`);
    console.error('   Try: netstat -ano | findstr :5050');
  } else {
    console.error('❌ Server error:', err);
  }
  process.exit(1);
});
