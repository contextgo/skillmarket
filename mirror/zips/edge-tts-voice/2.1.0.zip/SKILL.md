# Edge TTS 语音技能

为 OpenClaw QQBot 提供**免费、稳定、高质量**的中文语音合成功能。

---

## 🎯 功能特性

- ✅ **完全免费** - 使用 Microsoft Edge TTS 公开 API
- ✅ **中文优化** - 支持多种中文语音（晓晓、云希等）
- ✅ **稳定可靠** - 进程级隔离 + 超时保护 + 自动重试
- ✅ **零配置** - 一键安装，自动配置
- ✅ **低延迟** - 短文本 2-3 秒，长文本 30-60 秒
- ✅ **超长文本** - 支持 5000+ 字符一次性合成
- ✅ **CLI 方案** - 使用 edge-tts CLI，崩溃不影响主进程

---

## 📦 快速安装

### 方式 1：SkillHub（推荐）

```bash
python "C:\Users\你的用户名\.skillhub\skills_store_cli.py" install edge-tts-voice
```

### 方式 2：ClawHub

```bash
clawhub install edge-tts-voice
```

### 方式 3：手动安装

```bash
# 1. 复制技能到 workspace
cp -r workspace/skills/edge-tts-voice ~/.openclaw/workspace/skills/

# 2. 运行安装脚本
node ~/.openclaw/workspace/skills/edge-tts-voice/install.js

# 3. 重启 Gateway
openclaw gateway restart
```

---

## 🔧 自动配置

安装脚本会自动完成以下操作：

1. ✅ 检查依赖：`edge-tts` (Python 包)
2. ✅ 复制 TTS 服务器到 workspace
3. ✅ 修改 `openclaw.json` 添加配置
4. ✅ 创建 Windows 计划任务（开机自启）
5. ✅ 测试语音生成
6. ✅ 备份原配置

---

## 🎵 支持的语音

| 语音名称 | 性别 | 风格 | 适用场景 |
|---------|------|------|---------|
| `zh-CN-XiaoxiaoNeural` | 女 | 温暖、友好 | 通用、助手 |
| `zh-CN-YunxiNeural` | 男 | 沉稳、专业 | 新闻、讲解 |
| `zh-CN-YunjianNeural` | 男 | 激情、运动 | 体育、广告 |
| `zh-CN-XiaoyiNeural` | 女 | 活泼、可爱 | 娱乐、客服 |
| `zh-CN-YunyangNeural` | 男 | 专业、新闻 | 播客、朗读 |

**默认语音**：`zh-CN-XiaoxiaoNeural`（最自然的女声）

---

## ⚙️ 配置说明

### QQBot 自动语音回复

```json
{
  "channels.qqbot.tts": {
    "enabled": true,
    "provider": "openai",
    "baseUrl": "http://127.0.0.1:5050/v1",
    "apiKey": "not-needed",
    "voice": "zh-CN-XiaoxiaoNeural"
  }
}
```

### 全局 TTS 配置

```json
{
  "messages.tts": {
    "auto": "always",
    "provider": "openai",
    "maxTextLength": 1500,
    "providers": {
      "openai": {
        "enabled": true,
        "baseUrl": "http://127.0.0.1:5050/v1",
        "apiKey": "not-needed",
        "voice": "zh-CN-XiaoxiaoNeural"
      }
    }
  }
}
```

---

## 🧪 测试语音

安装完成后自动运行测试，或手动测试：

```bash
# 方式 1：使用测试脚本
node workspace/skills/edge-tts-voice/test-tts.js

# 方式 2：curl 测试
curl -X POST http://127.0.0.1:5050/v1/audio/speech \
  -H "Content-Type: application/json" \
  -d '{"input": "你好，这是测试语音", "voice": "zh-CN-XiaoxiaoNeural"}' \
  --output test.mp3

# 方式 3：PowerShell 测试
$body = [System.Text.Encoding]::UTF8.GetBytes('{"input": "测试", "voice": "zh-CN-XiaoxiaoNeural"}')
Invoke-WebRequest -Uri "http://127.0.0.1:5050/v1/audio/speech" -Method POST -ContentType "application/json" -Body $body -OutFile "test.mp3"
```

---

## 🛠️ 手动管理

### 启动/停止服务

```bash
# 启动
node workspace/tts-server.js

# 停止（找到 PID）
netstat -ano | findstr :5050
taskkill /F /PID <找到 PID>
```

### 查看服务状态

```bash
# 检查端口
netstat -ano | findstr :5050

# 检查进程
Get-Process node | Where-Object { $_.StartTime -gt (Get-Date).AddMinutes(-60) }
```

### 更换语音

修改 `workspace/tts-server.js` 中的 `DEFAULT_VOICE`：

```javascript
const DEFAULT_VOICE = 'zh-CN-YunxiNeural'; // 改为云希（男声）
```

然后重启服务。

---

## 🔄 卸载

```bash
# 方式 1：使用卸载脚本
node workspace/skills/edge-tts-voice/uninstall.js

# 方式 2：手动卸载
# 1. 停止服务
taskkill /F /PID <TTS 服务 PID>

# 2. 删除文件
rm workspace/tts-server.js
rm -rf workspace/skills/edge-tts-voice

# 3. 恢复 openclaw.json 配置（从备份）
```

---

## 📊 技术细节

### 架构（CLI 方案）

```
┌─────────────┐      HTTP       ┌──────────────┐     子进程调用    ┌─────────────┐
│  OpenClaw   │ ───────────────> │ TTS 服务器    │ ───────────────> │ edge-tts CLI │
│  QQBot      │ <─────────────── │ (127.0.0.1:5050)│                 │   (Python)   │
└─────────────┘   音频响应       └──────────────┘                      └─────────────┘
     │                                                                       │
     │                          WebSocket                                     │
     └──────────────────────────────────────────────────────────────────────> │
                                                              Edge TTS API    │
                                                                              └─> Microsoft
```

### 稳定性机制

| 机制 | 说明 | 效果 |
|------|------|------|
| **进程级隔离** | CLI 子进程独立运行 | 崩溃不影响主进程 |
| **OS 级超时** | 60 秒强制终止 | 防止永久挂起 |
| **自动重试** | 最多 3 次尝试 | 应对临时波动 |
| **指数退避** | 1s → 2s 延迟 | 避免雪崩 |
| **UTF-8 文件传递** | 超长文本用临时文件 | 解决 Windows 编码问题 |
| **详细日志** | 记录每次尝试 | 方便诊断 |

### 性能指标

| 指标 | 数值 |
|------|------|
| 短文本延迟（<100 字） | 2-3 秒 |
| 中文本延迟（500 字） | 10-15 秒 |
| 长文本延迟（2000 字） | 30-40 秒 |
| 超长文本（5000+ 字） | 60-90 秒 |
| 成功率 | >99% |
| 并发支持 | 10+ 请求/秒 |
| 内存占用 | ~30MB |
| CPU 占用 | <3% |

---

## ⚠️ 注意事项

1. **需要网络连接** - 调用 Microsoft Edge TTS API
2. **端口占用** - 默认使用 5050 端口
3. **防火墙** - 确保 127.0.0.1:5050 可访问
4. **依赖 Python** - 需要安装 `edge-tts` Python 包 (`pip install edge-tts`)
5. **依赖 Node.js** - 需要 Node.js 16+

---

## 🐛 故障排查

### 问题 1：服务无法启动

```bash
# 检查端口占用
netstat -ano | findstr :5050

# 杀死占用进程
taskkill /F /PID <找到 PID>

# 重启服务
node workspace/tts-server.js
```

### 问题 2：语音生成失败

```bash
# 测试网络连接
curl https://speech.platform.bing.com

# 查看日志
Get-Content workspace/tts-server.log -Tail 50
```

### 问题 3：QQBot 没有语音回复

```bash
# 检查配置
openclaw config.get channels.qqbot.tts

# 检查 Gateway 状态
openclaw gateway status

# 重启 Gateway
openclaw gateway restart
```

---

## 📚 相关资源

- [Microsoft Edge TTS 文档](https://docs.microsoft.com/azure/cognitive-services/speech-service/)
- [node-edge-tts 库](https://www.npmjs.com/package/node-edge-tts)
- [OpenClaw 文档](https://docs.openclaw.ai)

---

## 📝 更新日志

### v2.0.0 (2026-04-07) - CLI 方案
- ✅ 迁移到 edge-tts CLI（进程级隔离）
- ✅ 支持 5000+ 字符超长文本
- ✅ UTF-8 临时文件解决中文编码问题
- ✅ 超时延长至 60 秒（支持长文本）
- ✅ 崩溃不影响主进程

### v1.0.0 (2026-04-06)
- ✅ 初始版本
- ✅ 超时保护机制
- ✅ 自动重试机制
- ✅ 一键安装脚本
- ✅ Windows 服务支持

---

## 💡 技巧

### 批量生成语音

```javascript
const texts = ["你好", "欢迎", "再见"];
for (const text of texts) {
  const res = await fetch('http://127.0.0.1:5050/v1/audio/speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ input: text })
  });
  const buffer = await res.arrayBuffer();
  require('fs').writeFileSync(`${text}.mp3`, Buffer.from(buffer));
}
```

### 自定义语音参数

```javascript
// 修改 tts-server.js 中的 generateAudio 函数
const tts = new EdgeTTS({
  voice: 'zh-CN-XiaoxiaoNeural',
  lang: 'zh-CN',
  timeout: 30000,
  rate: '+10%',  // 语速 +10%
  pitch: '+5Hz'  // 音调 +5Hz
});
```

---

**祝你使用愉快！** 🎵
