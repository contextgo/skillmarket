#!/usr/bin/env node
/**
 * Edge TTS Voice Skill - 卸载脚本
 * 清理 TTS 服务配置，恢复原始状态
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const COLORS = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${COLORS[color]}${message}${COLORS.reset}`);
}

function exec(command) {
  try {
    return execSync(command, { encoding: 'utf8', stdio: 'pipe' });
  } catch (error) {
    return null;
  }
}

// 配置
const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.join(process.env.APPDATA, '..', '.openclaw', 'workspace');
const SKILL_DIR = path.join(WORKSPACE, 'skills', 'edge-tts-voice');
const CONFIG_FILE = path.join(path.dirname(WORKSPACE), 'openclaw.json');
const TTS_SERVER = path.join(WORKSPACE, 'tts-server.js');

log('\n🗑️  Edge TTS Voice Skill - 卸载程序', 'cyan');
log('=' .repeat(50), 'cyan');

// Step 1: 停止服务
log('\n[1/5] 停止 TTS 服务...', 'blue');

try {
  const result = exec('netstat -ano | findstr :5050');
  if (result) {
    const match = result.match(/5050.*?(\d+)\s+LISTENING/);
    if (match) {
      const pid = match[1];
      log(`正在停止进程 ${pid}...`, 'yellow');
      exec(`taskkill /F /PID ${pid}`);
      log('✅ TTS 服务已停止', 'green');
    }
  } else {
    log('ℹ️  TTS 服务未运行', 'yellow');
  }
} catch (error) {
  log(`⚠️ 停止服务失败：${error.message}`, 'yellow');
}

// Step 2: 删除 TTS 服务器文件
log('\n[2/5] 删除 TTS 服务器...', 'blue');

try {
  if (fs.existsSync(TTS_SERVER)) {
    fs.unlinkSync(TTS_SERVER);
    log('✅ tts-server.js 已删除', 'green');
  } else {
    log('ℹ️  tts-server.js 不存在', 'yellow');
  }
} catch (error) {
  log(`⚠️ 删除失败：${error.message}`, 'yellow');
}

// Step 3: 清理 OpenClaw 配置
log('\n[3/5] 清理 OpenClaw 配置...', 'blue');

try {
  if (fs.existsSync(CONFIG_FILE)) {
    const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    let modified = false;
    
    // 删除 QQBot TTS 配置
    if (config['channels.qqbot.tts']) {
      delete config['channels.qqbot.tts'];
      modified = true;
      log('✅ 已删除 channels.qqbot.tts 配置', 'green');
    }
    
    // 删除全局 TTS 配置
    if (config['messages.tts']) {
      delete config['messages.tts'];
      modified = true;
      log('✅ 已删除 messages.tts 配置', 'green');
    }
    
    // 删除 OpenAI provider 配置（如果只用于 TTS）
    if (config.models?.providers?.openai) {
      delete config.models.providers.openai;
      modified = true;
      log('✅ 已删除 models.providers.openai 配置', 'green');
    }
    
    if (modified) {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
      log('✅ OpenClaw 配置已恢复', 'green');
    } else {
      log('ℹ️  无需清理配置', 'yellow');
    }
  } else {
    log('ℹ️  未找到配置文件', 'yellow');
  }
} catch (error) {
  log(`❌ 配置清理失败：${error.message}`, 'red');
}

// Step 4: 删除技能文件（可选）
log('\n[4/5] 删除技能文件...', 'blue');

try {
  if (fs.existsSync(SKILL_DIR)) {
    log('⚠️  技能目录存在，是否删除？', 'yellow');
    log(`路径：${SKILL_DIR}`, 'yellow');
    log('提示：如需保留技能文件，请手动删除', 'yellow');
    // 不自动删除技能目录，用户可能需要重新安装
  } else {
    log('ℹ️  技能目录不存在', 'yellow');
  }
} catch (error) {
  log(`⚠️ 删除失败：${error.message}`, 'yellow');
}

// Step 5: 清理启动脚本
log('\n[5/5] 清理启动脚本...', 'blue');

try {
  const startupScript = path.join(WORKSPACE, 'tts-server-wrapper.bat');
  if (fs.existsSync(startupScript)) {
    fs.unlinkSync(startupScript);
    log('✅ 启动脚本已删除', 'green');
  } else {
    log('ℹ️  启动脚本不存在', 'yellow');
  }
} catch (error) {
  log(`⚠️ 清理失败：${error.message}`, 'yellow');
}

// 完成
log('\n' + '='.repeat(50), 'cyan');
log('🗑️  卸载完成！', 'green');
log('='.repeat(50), 'cyan');

log('\n📋 后续操作：', 'blue');
log('1. 重启 OpenClaw Gateway: openclaw gateway restart', 'yellow');
log('2. 验证 QQBot 语音回复已关闭', 'yellow');

log('\n💡 如需重新安装：', 'blue');
log('node workspace/skills/edge-tts-voice/install.js', 'yellow');

log('\n再见！👋\n', 'cyan');
