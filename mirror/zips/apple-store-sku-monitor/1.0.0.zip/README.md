# Apple Store Monitor

A skill for OpenClaw to monitor Apple Store in-store pickup availability for Apple products.

## Features

- Monitor Apple Store inventory for specific products
- Check availability at nearby stores based on location
- **自动通过OpenClaw已连接的消息平台发送通知** (飞书/QQ/Telegram/微信等)
- Support multiple notification methods (openclaw, console, email, webhook, ntfy)
- Handle anti-scraping measures with proxy rotation
- Track multiple products simultaneously
- Real-time stock status updates

## Installation

```bash
# Install via OpenClaw
openclaw skills install apple-store-monitor

# Or install manually
git clone https://github.com/your-username/apple-store-monitor.git
cd apple-store-monitor
npm install
npm run build
```

## Configuration

### Basic Configuration

```bash
# Set your location (zip code or city)
openclaw skills config apple-store-monitor --set location=北京

# Set check interval (in seconds)
openclaw skills config apple-store-monitor --set check_interval=300
```

### Notification Methods

#### OpenClaw消息通道 (推荐)

**无需额外配置！** 当你在OpenClaw中使用此skill时，库存提醒会自动通过你已连接的消息平台发送：

- 飞书 (Feishu/Lark)
- QQ
- Telegram
- 微信
- Slack
- Discord
- 其他OpenClaw支持的平台

```bash
# 使用OpenClaw消息通道 (默认)
openclaw skills config apple-store-monitor --set notification_method=openclaw
```

**工作原理：**
1. 你已将OpenClaw接入飞书/QQ等平台
2. 当检测到库存时，skill通过OpenClaw发送通知
3. OpenClaw自动将消息转发到你已连接的所有平台
4. 你会在飞书/QQ上收到库存提醒

#### 其他通知方式

如果需要额外的通知渠道，可以配置：

```bash
openclaw skills config apple-store-monitor --set notification_method=email
openclaw skills config apple-store-monitor --set email_config.smtp_server=smtp.gmail.com
openclaw skills config apple-store-monitor --set email_config.smtp_port=587
openclaw skills config apple-store-monitor --set email_config.sender_email=your-email@gmail.com
openclaw skills config apple-store-monitor --set email_config.sender_password=your-password
openclaw skills config apple-store-monitor --set email_config.recipient_email=recipient@example.com
```

#### Webhook Notifications

```bash
openclaw skills config apple-store-monitor --set notification_method=webhook
openclaw skills config apple-store-monitor --set webhook_url=https://your-webhook-url.com
```

#### ntfy Push Notifications

```bash
openclaw skills config apple-store-monitor --set notification_method=ntfy
openclaw skills config apple-store-monitor --set ntfy_topic=your-topic-name
```

#### Proxy Rotation

```bash
openclaw skills config apple-store-monitor --set use_proxy=true
openclaw skills config apple-store-monitor --set proxy_list.0=proxy1:port
openclaw skills config apple-store-monitor --set proxy_list.1=proxy2:port
```

## Usage

### Adding Products to Monitor

```bash
# Add by product name
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"

# Add by model number
openclaw skills run apple-store-monitor --action add --model "MU7A3LL/A"

# Add with specific location
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB" --location "北京"
```

### Managing Products

```bash
# List monitored products
openclaw skills run apple-store-monitor --action list

# Remove a product
openclaw skills run apple-store-monitor --action remove --model "MU7A3LL/A"
```

### Monitoring

```bash
# Start monitoring
openclaw skills run apple-store-monitor --action start

# Check status
openclaw skills run apple-store-monitor --action status

# Stop monitoring
openclaw skills run apple-store-monitor --action stop
```

## Apple Product Model Numbers

Apple uses specific model numbers for each product variant. Here are some common ones:

### iPhone 17 Series
- iPhone 17 Pro 256GB 橙色: MX9A3CH/A
- iPhone 17 Pro 256GB 深空黑: MX9B3CH/A
- iPhone 17 Pro 256GB 白色: MX9C3CH/A
- iPhone 17 Pro 256GB 钛金色: MX9D3CH/A

### Mac mini
- Mac mini M4 16+256GB: MYF63CH/A
- Mac mini M4 16+512GB: MYF73CH/A
- Mac mini M4 Pro 24+512GB: MYF83CH/A

### MacBook Pro
- MacBook Pro 14" M3 Space Black: MRX33CH/A
- MacBook Pro 16" M3 Pro Silver: MRX63CH/A

### Apple Watch
- Apple Watch Ultra 2: MQDY3CH/A
- Apple Watch Series 9 41mm Midnight: MQTT3CH/A

## Anti-Scraping Features

The monitor includes several features to avoid rate limiting:

1. **Random delays**: 1-3 seconds between requests
2. **User-Agent rotation**: Cycles through common browser user agents
3. **Request throttling**: Limits requests per minute
4. **Proxy rotation**: Supports multiple proxy servers
5. **Automatic retry**: Exponential backoff on errors
6. **Store hours awareness**: Avoids checking during off-hours

## API Reference

Apple uses an undocumented API for inventory checking:

```
GET https://www.apple.com/shop/fulfillment-messages
  ?parts.0=MODEL_NUMBER
  &searchNearby=true
  &location=ZIP_CODE
  &store=STORE_ID (optional)
```

Response format:
```json
{
  "body": {
    "content": {
      "pickupMessage": {
        "stores": [
          {
            "storeNumber": "R001",
            "storeName": "Apple Store Name",
            "address": { "address": "123 Main St" },
            "partsAvailability": {
              "MODEL_NUMBER": {
                "pickupDisplay": "available",
                "storePickupQty": 5,
                "messageTypes": {
                  "regular": {
                    "storePickupQuote": "Available for pickup today"
                  }
                }
              }
            }
          }
        ]
      }
    }
  }
}
```

## Troubleshooting

### "Rate limited" errors
- Increase check interval to 5+ minutes
- Enable proxy rotation
- Reduce number of monitored products

### "No stores found" error
- Verify your location (zip code or city)
- Check if Apple Stores exist in your area
- Try a nearby major city

### "Product not found" error
- Verify product model number
- Check if product is available in your region
- Use Apple's website to confirm product availability

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT

## Disclaimer

This tool uses Apple's undocumented inventory API. Use responsibly and respect Apple's terms of service. The authors are not responsible for any misuse or consequences of using this tool.