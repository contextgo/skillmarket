# Apple Store Monitor - Installation Guide

## Quick Start

### 1. Install via OpenClaw

```bash
openclaw skills install apple-store-monitor
```

### 2. Configure

```bash
# Set your location (zip code or city)
openclaw skills config apple-store-monitor --set location=北京

# Set notification method (console, email, webhook, ntfy)
openclaw skills config apple-store-monitor --set notification_method=console

# Set check interval in seconds (default: 300 = 5 minutes)
openclaw skills config apple-store-monitor --set check_interval=300
```

### 3. Add Products

```bash
# Add by product name
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"

# Add by model number
openclaw skills run apple-store-monitor --action add --model "MX9A3CH/A"
```

### 4. Start Monitoring

```bash
openclaw skills run apple-store-monitor --action start
```

## Manual Installation

### Prerequisites

- Node.js 18+
- npm

### Steps

1. Clone the repository:
```bash
git clone https://github.com/your-username/apple-store-monitor.git
cd apple-store-monitor
```

2. Install dependencies:
```bash
npm install
```

3. Build the project:
```bash
npm run build
```

4. Copy configuration:
```bash
cp config.example.json ~/.apple-store-monitor.json
```

5. Edit configuration:
```bash
nano ~/.apple-store-monitor.json
```

6. Run the monitor:
```bash
npm start
```

## Configuration Options

### Location
- Zip code (e.g., "10001")
- City name (e.g., "北京", "上海", "广州")

### Notification Methods
- `console`: Print to console (default)
- `email`: Send email notifications
- `webhook`: POST to webhook URL
- `ntfy`: Push notifications via ntfy.sh

### Check Interval
- In seconds
- Recommended: 300 (5 minutes) or higher
- Minimum: 60 (1 minute)

### Proxy Rotation
Enable to avoid rate limiting:
```bash
openclaw skills config apple-store-monitor --set use_proxy=true
openclaw skills config apple-store-monitor --set proxy_list.0=proxy1:port
```

## Common Apple Product Model Numbers

### iPhone 17 Series
- iPhone 17 Pro 256GB 橙色: `MX9A3CH/A`
- iPhone 17 Pro 256GB 深空黑: `MX9B3CH/A`
- iPhone 17 Pro 256GB 白色: `MX9C3CH/A`
- iPhone 17 Pro 256GB 钛金色: `MX9D3CH/A`

### Mac mini
- Mac mini M4 16+256GB: `MYF63CH/A`
- Mac mini M4 16+512GB: `MYF73CH/A`
- Mac mini M4 Pro 24+512GB: `MYF83CH/A`

### MacBook Pro
- MacBook Pro 14" M3 Space Black: `MRX33CH/A`
- MacBook Pro 16" M3 Pro Silver: `MRX63CH/A`

### Apple Watch
- Apple Watch Ultra 2: `MQDY3CH/A`
- Apple Watch Series 9 41mm Midnight: `MQTT3CH/A`

## Troubleshooting

### Rate Limiting
If you get "429 Too Many Requests" errors:
1. Increase check interval to 5+ minutes
2. Enable proxy rotation
3. Reduce number of monitored products

### No Stores Found
1. Verify your location (zip code or city)
2. Check if Apple Stores exist in your area
3. Try a nearby major city

### Product Not Found
1. Verify product model number
2. Check if product is available in your region
3. Use Apple's website to confirm product availability

## Support

For issues or questions:
1. Check the GitHub repository
2. Review Apple's product model numbers
3. Verify your location settings

## License

MIT