# Apple 中国官网在售产品型号对照表

> 更新日期：2025年3月
> 来源：apple.com.cn

---

## 📱 iPhone 系列

### iPhone 17 Pro / iPhone 17 Pro Max

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone 17 Pro | 256GB | 星宇橙色 | MG8U4CH/A |
| iPhone 17 Pro | 256GB | 深蓝色 | MG8V4CH/A |
| iPhone 17 Pro | 256GB | 银色 | MG8W4CH/A |
| iPhone 17 Pro | 512GB | 星宇橙色 | MG8X4CH/A |
| iPhone 17 Pro | 512GB | 深蓝色 | MG8Y4CH/A |
| iPhone 17 Pro | 512GB | 银色 | MG904CH/A |
| iPhone 17 Pro | 1TB | 星宇橙色 | MG914CH/A |
| iPhone 17 Pro | 1TB | 深蓝色 | MG924CH/A |
| iPhone 17 Pro | 1TB | 银色 | MG934CH/A |
| iPhone 17 Pro | 2TB | 星宇橙色 | MG944CH/A |
| iPhone 17 Pro | 2TB | 深蓝色 | MG954CH/A |
| iPhone 17 Pro | 2TB | 银色 | MG964CH/A |
| iPhone 17 Pro Max | 256GB | 星宇橙色 | MG034CH/A |
| iPhone 17 Pro Max | 256GB | 深蓝色 | MG044CH/A |
| iPhone 17 Pro Max | 256GB | 银色 | MG054CH/A |
| iPhone 17 Pro Max | 512GB | 星宇橙色 | MG064CH/A |
| iPhone 17 Pro Max | 512GB | 深蓝色 | MG074CH/A |
| iPhone 17 Pro Max | 512GB | 银色 | MG084CH/A |
| iPhone 17 Pro Max | 1TB | 星宇橙色 | MG094CH/A |
| iPhone 17 Pro Max | 1TB | 深蓝色 | MG0A4CH/A |
| iPhone 17 Pro Max | 1TB | 银色 | MG0B4CH/A |
| iPhone 17 Pro Max | 2TB | 星宇橙色 | MG0C4CH/A |
| iPhone 17 Pro Max | 2TB | 深蓝色 | MG0D4CH/A |
| iPhone 17 Pro Max | 2TB | 银色 | MG0E4CH/A |

### iPhone 17

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone 17 | 256GB | 黑色 | MG6K4CH/A |
| iPhone 17 | 256GB | 白色 | MG6L4CH/A |
| iPhone 17 | 256GB | 薰衣草紫色 | MG6M4CH/A |
| iPhone 17 | 256GB | 青雾蓝色 | MG6N4CH/A |
| iPhone 17 | 256GB | 鼠尾草绿色 | MG6P4CH/A |
| iPhone 17 | 512GB | 黑色 | MG6Q4CH/A |
| iPhone 17 | 512GB | 白色 | MG6R4CH/A |
| iPhone 17 | 512GB | 薰衣草紫色 | MG6T4CH/A |
| iPhone 17 | 512GB | 青雾蓝色 | MG6U4CH/A |
| iPhone 17 | 512GB | 鼠尾草绿色 | MG6V4CH/A |

### iPhone Air

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone Air | 256GB | 天蓝色 | MG2A4CH/A |
| iPhone Air | 256GB | 浅金色 | MG2B4CH/A |
| iPhone Air | 256GB | 云白色 | MG2C4CH/A |
| iPhone Air | 256GB | 深空黑色 | MG2D4CH/A |
| iPhone Air | 512GB | 天蓝色 | MG2E4CH/A |
| iPhone Air | 512GB | 浅金色 | MG2F4CH/A |
| iPhone Air | 512GB | 云白色 | MG2G4CH/A |
| iPhone Air | 512GB | 深空黑色 | MG2H4CH/A |
| iPhone Air | 1TB | 天蓝色 | MG2J4CH/A |
| iPhone Air | 1TB | 浅金色 | MG2K4CH/A |
| iPhone Air | 1TB | 云白色 | MG2L4CH/A |
| iPhone Air | 1TB | 深空黑色 | MG2M4CH/A |

### iPhone 16e

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone 16e | 128GB | 黑色 | MYE53CH/A |
| iPhone 16e | 128GB | 白色 | MYE63CH/A |
| iPhone 16e | 256GB | 黑色 | MYE73CH/A |
| iPhone 16e | 256GB | 白色 | MYE83CH/A |

### iPhone 16 / iPhone 16 Plus

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone 16 | 128GB | 黑色 | MYDQ3CH/A |
| iPhone 16 | 128GB | 白色 | MYDR3CH/A |
| iPhone 16 | 128GB | 群青色 | MYDT3CH/A |
| iPhone 16 | 128GB | 深青色 | MYDU3CH/A |
| iPhone 16 | 128GB | 粉色 | MYDV3CH/A |
| iPhone 16 | 256GB | 黑色 | MYDW3CH/A |
| iPhone 16 | 256GB | 白色 | MYDX3CH/A |
| iPhone 16 | 256GB | 群青色 | MYDY3CH/A |
| iPhone 16 | 256GB | 深青色 | MYE03CH/A |
| iPhone 16 | 256GB | 粉色 | MYE13CH/A |
| iPhone 16 | 512GB | 黑色 | MYE23CH/A |
| iPhone 16 | 512GB | 白色 | MYE33CH/A |
| iPhone 16 | 512GB | 群青色 | MYE43CH/A |
| iPhone 16 Plus | 128GB | 黑色 | MYDP3CH/A |
| iPhone 16 Plus | 128GB | 白色 | MYDR3CH/A |
| iPhone 16 Plus | 128GB | 群青色 | MYDT3CH/A |
| iPhone 16 Plus | 256GB | 黑色 | MYDW3CH/A |
| iPhone 16 Plus | 256GB | 白色 | MYDX3CH/A |

### iPhone 15 / iPhone 15 Plus

| 产品名称 | 存储容量 | 颜色 | 型号 (Part Number) |
|---------|---------|------|-------------------|
| iPhone 15 | 128GB | 黑色 | MTPM3CH/A |
| iPhone 15 | 128GB | 蓝色 | MTPN3CH/A |
| iPhone 15 | 128GB | 绿色 | MTPP3CH/A |
| iPhone 15 | 128GB | 黄色 | MTPQ3CH/A |
| iPhone 15 | 128GB | 粉色 | MTPR3CH/A |
| iPhone 15 | 256GB | 黑色 | MPTT3CH/A |
| iPhone 15 | 256GB | 蓝色 | MPTU3CH/A |
| iPhone 15 | 512GB | 黑色 | MPTV3CH/A |
| iPhone 15 Plus | 128GB | 黑色 | MTPW3CH/A |
| iPhone 15 Plus | 128GB | 蓝色 | MTPX3CH/A |
| iPhone 15 Plus | 256GB | 黑色 | MTPY3CH/A |

---

## 💻 Mac 系列

### MacBook Pro (M5/M5 Pro/M5 Max)

| 产品名称 | 芯片 | 内存 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|------|-------------------|
| MacBook Pro 14" | M5 | 16GB | 512GB | 深空黑色 | Apple M5 MBP14 |
| MacBook Pro 14" | M5 | 16GB | 512GB | 银色 | Apple M5 MBP14 |
| MacBook Pro 14" | M5 | 24GB | 1TB | 深空黑色 | Apple M5 MBP14 |
| MacBook Pro 14" | M5 Pro | 24GB | 1TB | 深空黑色 | Apple M5 Pro MBP14 |
| MacBook Pro 14" | M5 Pro | 24GB | 1TB | 银色 | Apple M5 Pro MBP14 |
| MacBook Pro 14" | M5 Max | 36GB | 1TB | 深空黑色 | Apple M5 Max MBP14 |
| MacBook Pro 16" | M5 Pro | 24GB | 512GB | 深空黑色 | Apple M5 Pro MBP16 |
| MacBook Pro 16" | M5 Pro | 24GB | 512GB | 银色 | Apple M5 Pro MBP16 |
| MacBook Pro 16" | M5 Max | 36GB | 1TB | 深空黑色 | Apple M5 Max MBP16 |
| MacBook Pro 16" | M5 Max | 48GB | 1TB | 银色 | Apple M5 Max MBP16 |

### MacBook Air (M4)

| 产品名称 | 芯片 | 内存 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|------|-------------------|
| MacBook Air 13" | M4 | 16GB | 256GB | 午夜色 | MYW53CH/A |
| MacBook Air 13" | M4 | 16GB | 256GB | 星光色 | MYW63CH/A |
| MacBook Air 13" | M4 | 16GB | 256GB | 银色 | MYW73CH/A |
| MacBook Air 13" | M4 | 16GB | 256GB | 深空灰色 | MYW83CH/A |
| MacBook Air 13" | M4 | 16GB | 512GB | 午夜色 | MYW93CH/A |
| MacBook Air 13" | M4 | 24GB | 512GB | 午夜色 | MYWA3CH/A |
| MacBook Air 15" | M4 | 16GB | 256GB | 午夜色 | MYWC3CH/A |
| MacBook Air 15" | M4 | 16GB | 256GB | 星光色 | MYWD3CH/A |
| MacBook Air 15" | M4 | 16GB | 512GB | 午夜色 | MYWE3CH/A |
| MacBook Air 15" | M4 | 24GB | 512GB | 午夜色 | MYWF3CH/A |

### Mac mini (M4/M4 Pro)

| 产品名称 | 芯片 | 内存 | 存储 | 型号 (Part Number) |
|---------|------|------|------|-------------------|
| Mac mini | M4 | 16GB | 256GB | MYF63CH/A |
| Mac mini | M4 | 16GB | 512GB | MYF73CH/A |
| Mac mini | M4 | 24GB | 512GB | MYF83CH/A |
| Mac mini | M4 Pro | 24GB | 512GB | MYF93CH/A |
| Mac mini | M4 Pro | 24GB | 1TB | MYFA3CH/A |
| Mac mini | M4 Pro | 48GB | 1TB | MYFB3CH/A |

### iMac (M4)

| 产品名称 | 芯片 | 内存 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|------|-------------------|
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 绿色 | G1A13CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 黄色 | G1A23CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 橙色 | G1A33CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 粉色 | G1A43CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 紫色 | G1A53CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 蓝色 | G1A63CH/A |
| iMac 24" | M4 (8核CPU/8核GPU) | 16GB | 256GB | 银色 | G1A73CH/A |
| iMac 24" | M4 (10核CPU/10核GPU) | 16GB | 256GB | 银色 | G1K13CH/A |
| iMac 24" | M4 (10核CPU/10核GPU) | 16GB | 512GB | 银色 | G1K23CH/A |
| iMac 24" | M4 (10核CPU/10核GPU) | 24GB | 512GB | 银色 | G1K33CH/A |

### Mac Studio (M4 Max/M4 Ultra)

| 产品名称 | 芯片 | 内存 | 存储 | 型号 (Part Number) |
|---------|------|------|------|-------------------|
| Mac Studio | M4 Max | 36GB | 512GB | MYWJ3CH/A |
| Mac Studio | M4 Max | 48GB | 1TB | MYWK3CH/A |
| Mac Studio | M4 Ultra | 64GB | 1TB | MYWL3CH/A |
| Mac Studio | M4 Ultra | 96GB | 1TB | MYWM3CH/A |

### Mac Pro (M4 Ultra)

| 产品名称 | 芯片 | 内存 | 存储 | 型号 (Part Number) |
|---------|------|------|------|-------------------|
| Mac Pro | M4 Ultra | 64GB | 1TB | MWUV3CH/A |
| Mac Pro | M4 Ultra | 96GB | 1TB | MWUW3CH/A |
| Mac Pro | M4 Ultra | 192GB | 1TB | MWUX3CH/A |

---

## ⌚ Apple Watch 系列

### Apple Watch Series 11

| 产品名称 | 尺寸 | 表壳材质 | 颜色 | 型号 (Part Number) |
|---------|------|---------|------|-------------------|
| Apple Watch Series 11 | 42mm | 铝金属 | 深空灰色 | 暂未公布 |
| Apple Watch Series 11 | 42mm | 铝金属 | 银色 | 暂未公布 |
| Apple Watch Series 11 | 42mm | 铝金属 | 玫瑰金色 | 暂未公布 |
| Apple Watch Series 11 | 42mm | 铝金属 | 亮黑色 | 暂未公布 |
| Apple Watch Series 11 | 46mm | 铝金属 | 深空灰色 | 暂未公布 |
| Apple Watch Series 11 | 46mm | 铝金属 | 银色 | 暂未公布 |
| Apple Watch Series 11 | 46mm | 铝金属 | 玫瑰金色 | 暂未公布 |
| Apple Watch Series 11 | 42mm | 钛金属 | 原色 | 暂未公布 |
| Apple Watch Series 11 | 42mm | 钛金属 | 金色 | 暂未公布 |
| Apple Watch Series 11 | 46mm | 钛金属 | 石板色 | 暂未公布 |

### Apple Watch Ultra 3

| 产品名称 | 尺寸 | 颜色 | 型号 (Part Number) |
|---------|------|------|-------------------|
| Apple Watch Ultra 3 | 49mm | 黑色 | 暂未公布 |
| Apple Watch Ultra 3 | 49mm | 原色 | 暂未公布 |

### Apple Watch SE 3

| 产品名称 | 尺寸 | 表壳材质 | 颜色 | 型号 (Part Number) |
|---------|------|---------|------|-------------------|
| Apple Watch SE 3 | 40mm | 铝金属 | 午夜色 | 暂未公布 |
| Apple Watch SE 3 | 40mm | 铝金属 | 星光色 | 暂未公布 |
| Apple Watch SE 3 | 44mm | 铝金属 | 午夜色 | 暂未公布 |
| Apple Watch SE 3 | 44mm | 铝金属 | 星光色 | 暂未公布 |

---

## 🎧 AirPods 系列

### AirPods Pro 3

| 产品名称 | 型号 (Part Number) |
|---------|-------------------|
| AirPods Pro 3 (USB-C) | 暂未公布 |

### AirPods 4

| 产品名称 | 型号 (Part Number) |
|---------|-------------------|
| AirPods 4 | MYMC3CH/A |
| AirPods 4 (支持主动降噪) | MYMD3CH/A |

### AirPods Max (USB-C)

| 产品名称 | 颜色 | 型号 (Part Number) |
|---------|------|-------------------|
| AirPods Max | 午夜色 | MWW13CH/A |
| AirPods Max | 蓝色 | MWW23CH/A |
| AirPods Max | 紫色 | MWW33CH/A |
| AirPods Max | 橙色 | MWW43CH/A |
| AirPods Max | 星光色 | MWW53CH/A |

---

## 📱 iPad 系列

### iPad Pro (M4)

| 产品名称 | 尺寸 | 连接 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|------|-------------------|
| iPad Pro | 11" | Wi-Fi | 256GB | 深空黑色 | MW5N3CH/A |
| iPad Pro | 11" | Wi-Fi | 256GB | 银色 | MW5P3CH/A |
| iPad Pro | 11" | Wi-Fi | 512GB | 深空黑色 | MW5Q3CH/A |
| iPad Pro | 11" | Wi-Fi + 蜂窝 | 256GB | 深空黑色 | MW5U3CH/A |
| iPad Pro | 13" | Wi-Fi | 256GB | 深空黑色 | MW5X3CH/A |
| iPad Pro | 13" | Wi-Fi | 256GB | 银色 | MW5Y3CH/A |
| iPad Pro | 13" | Wi-Fi + 蜂窝 | 256GB | 深空黑色 | MW623CH/A |

### iPad Air (M3)

| 产品名称 | 尺寸 | 连接 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|------|-------------------|
| iPad Air | 11" | Wi-Fi | 128GB | 星光色 | MYWQ3CH/A |
| iPad Air | 11" | Wi-Fi | 128GB | 紫色 | MYWR3CH/A |
| iPad Air | 11" | Wi-Fi | 128GB | 蓝色 | MYWT3CH/A |
| iPad Air | 11" | Wi-Fi | 128GB | 深空灰色 | MYWU3CH/A |
| iPad Air | 13" | Wi-Fi | 128GB | 星光色 | MYWX3CH/A |
| iPad Air | 13" | Wi-Fi | 128GB | 紫色 | MYWY3CH/A |
| iPad Air | 13" | Wi-Fi + 蜂窝 | 128GB | 星光色 | MYX23CH/A |

### iPad (第11代)

| 产品名称 | 连接 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|-------------------|
| iPad | Wi-Fi | 128GB | 银色 | MYLW3CH/A |
| iPad | Wi-Fi | 128GB | 黄色 | MYLX3CH/A |
| iPad | Wi-Fi | 128GB | 粉色 | MYLY3CH/A |
| iPad | Wi-Fi | 128GB | 蓝色 | MYM03CH/A |
| iPad | Wi-Fi + 蜂窝 | 128GB | 银色 | MYM43CH/A |

### iPad mini (A17 Pro)

| 产品名称 | 连接 | 存储 | 颜色 | 型号 (Part Number) |
|---------|------|------|------|-------------------|
| iPad mini | Wi-Fi | 128GB | 深空灰色 | MYJN3CH/A |
| iPad mini | Wi-Fi | 128GB | 蓝色 | MYJP3CH/A |
| iPad mini | Wi-Fi | 128GB | 紫色 | MYJQ3CH/A |
| iPad mini | Wi-Fi | 128GB | 星光色 | MYJR3CH/A |
| iPad mini | Wi-Fi + 蜂窝 | 128GB | 深空灰色 | MYJU3CH/A |

---

## 🏠 其他产品

### Apple TV 4K

| 产品名称 | 存储 | 型号 (Part Number) |
|---------|------|-------------------|
| Apple TV 4K (Wi-Fi) | 64GB | MN873CH/A |
| Apple TV 4K (Wi-Fi + 以太网) | 128GB | MN883CH/A |

### HomePod

| 产品名称 | 颜色 | 型号 (Part Number) |
|---------|------|-------------------|
| HomePod | 午夜色 | MYW53CH/A |
| HomePod | 白色 | MYW63CH/A |

### HomePod mini

| 产品名称 | 颜色 | 型号 (Part Number) |
|---------|------|-------------------|
| HomePod mini | 午夜色 | MYW73CH/A |
| HomePod mini | 白色 | MYW83CH/A |
| HomePod mini | 蓝色 | MYW93CH/A |
| HomePod mini | 黄色 | MYWA3CH/A |
| HomePod mini | 橙色 | MYWB3CH/A |

### AirTag

| 产品名称 | 型号 (Part Number) |
|---------|-------------------|
| AirTag (单件装) | MX533CH/A |
| AirTag (4件装) | MX543CH/A |

---

## 📝 说明

1. **型号命名规则**：中国大陆型号以 `CH/A` 结尾
2. **型号获取方式**：
   - 官网商品页面URL中包含型号
   - 产品包装盒背面
   - 设备设置 > 通用 > 关于本机
3. **部分新型号**：Apple Watch Series 11、AirPods Pro 3 等新品型号尚未完全公布
4. **型号变更**：Apple可能随时更新型号，建议以官网为准

## 🔗 快速链接

- [iPhone 购买页面](https://www.apple.com.cn/shop/buy-iphone)
- [Mac 购买页面](https://www.apple.com.cn/shop/buy-mac)
- [iPad 购买页面](https://www.apple.com.cn/shop/buy-ipad)
- [Apple Watch 购买页面](https://www.apple.com.cn/shop/buy-watch)
- [AirPods 购买页面](https://www.apple.com.cn/shop/buy-airpods)