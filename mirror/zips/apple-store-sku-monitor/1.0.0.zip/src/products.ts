import axios from 'axios';

export interface Product {
  name: string;
  model: string;
  category: string;
  description?: string;
}

interface AppleProduct {
  name: string;
  model: string;
  category: string;
  colors?: string[];
  storages?: string[];
}

// Common Apple product categories
const APPLE_CATEGORIES = [
  'iPhone',
  'iPad',
  'Mac',
  'Apple Watch',
  'AirPods',
  'Apple TV',
  'HomePod',
  'Accessories'
];

// Common product patterns
const PRODUCT_PATTERNS: Record<string, RegExp> = {
  iPhone: /iPhone\s*(\d+\s*(Pro\s*Max|Pro|Plus|SE)?)/i,
  iPad: /iPad\s*(Pro|Air|mini)?\s*(\d+)?/i,
  Mac: /(MacBook\s*(Pro|Air)|iMac|Mac\s*mini|Mac\s*Studio|Mac\s*Pro)/i,
  AppleWatch: /Apple\s*Watch\s*(Series\s*\d+|SE|Ultra)?/i,
  AirPods: /AirPods?\s*(Pro|Max)?\s*(\d+)?/i
};

export class ProductManager {
  private knownProducts: AppleProduct[] = [];

  constructor() {
    this.initializeKnownProducts();
  }

  private initializeKnownProducts(): void {
    // Initialize with common Apple products
    // This is a simplified list - in production, you'd want to fetch from Apple's website
    this.knownProducts = [
      // iPhone 17 series
      { name: 'iPhone 17 Pro', model: 'MX9A3CH/A', category: 'iPhone', colors: ['橙色', '深空黑', '白色', '钛金色'], storages: ['256GB', '512GB', '1TB'] },
      { name: 'iPhone 17 Pro Max', model: 'MX9E3CH/A', category: 'iPhone', colors: ['橙色', '深空黑', '白色', '钛金色'], storages: ['256GB', '512GB', '1TB'] },
      { name: 'iPhone 17', model: 'MX8A3CH/A', category: 'iPhone', colors: ['黑色', '蓝色', '绿色', '黄色', '粉色'], storages: ['128GB', '256GB', '512GB'] },
      { name: 'iPhone 17 Plus', model: 'MX8E3CH/A', category: 'iPhone', colors: ['黑色', '蓝色', '绿色', '黄色', '粉色'], storages: ['128GB', '256GB', '512GB'] },
      
      // Mac mini M4
      { name: 'Mac mini M4', model: 'MYF63CH/A', category: 'Mac', colors: ['银色'], storages: ['16+256GB', '16+512GB'] },
      { name: 'Mac mini M4 Pro', model: 'MYF83CH/A', category: 'Mac', colors: ['银色'], storages: ['24+512GB', '24+1TB'] },
      
      // MacBook Pro
      { name: 'MacBook Pro 14" M3', model: 'MRX33CH/A', category: 'Mac', colors: ['深空黑色', '银色'], storages: ['512GB', '1TB'] },
      { name: 'MacBook Pro 14" M3 Pro', model: 'MRX43CH/A', category: 'Mac', colors: ['深空黑色', '银色'], storages: ['512GB', '1TB'] },
      { name: 'MacBook Pro 16" M3 Pro', model: 'MRX63CH/A', category: 'Mac', colors: ['深空黑色', '银色'], storages: ['512GB', '1TB'] },
      
      // iPad Pro
      { name: 'iPad Pro 12.9" M2', model: 'MNXR3CH/A', category: 'iPad', colors: ['深空灰', '银色'], storages: ['128GB', '256GB', '512GB', '1TB', '2TB'] },
      { name: 'iPad Pro 11" M2', model: 'MNXA3CH/A', category: 'iPad', colors: ['深空灰', '银色'], storages: ['128GB', '256GB', '512GB', '1TB', '2TB'] },
      
      // Apple Watch
      { name: 'Apple Watch Ultra 2', model: 'MQDY3CH/A', category: 'Apple Watch', colors: ['原色钛金属'], storages: ['GPS + 蜂窝网络'] },
      { name: 'Apple Watch Series 9', model: 'MQTT3CH/A', category: 'Apple Watch', colors: ['午夜色', '星光色', '银色', '粉色', '红色'], storages: ['41mm', '45mm'] },
      
      // AirPods
      { name: 'AirPods Pro 2', model: 'MQD83CH/A', category: 'AirPods', colors: ['白色'], storages: [] },
      { name: 'AirPods Max', model: 'MGYH3CH/A', category: 'AirPods', colors: ['深空灰', '银色', '绿色', '天蓝色', '粉色'], storages: [] }
    ];
  }

  async resolveProduct(identifier: string, location: string): Promise<Product | null> {
    // First, try to find by model number
    if (this.isModelNumber(identifier)) {
      return this.findProductByModel(identifier);
    }

    // Try to parse product description
    const parsed = this.parseProductDescription(identifier);
    if (parsed) {
      return this.findMatchingProduct(parsed);
    }

    // Try to search Apple's website
    return await this.searchAppleWebsite(identifier, location);
  }

  private isModelNumber(identifier: string): boolean {
    // Apple model numbers typically end with /A and contain letters and numbers
    return /^[A-Z0-9]{5,}\/[A-Z]$/i.test(identifier);
  }

  private findProductByModel(model: string): Product | null {
    const found = this.knownProducts.find(p => 
      p.model.toLowerCase() === model.toLowerCase()
    );
    
    if (found) {
      return {
        name: found.name,
        model: found.model,
        category: found.category,
        description: `${found.name} - ${found.colors?.join(', ')} - ${found.storages?.join(', ')}`
      };
    }

    // Return a basic product if model looks valid
    if (this.isModelNumber(model)) {
      return {
        name: `Apple Product (${model})`,
        model: model,
        category: 'Unknown',
        description: `Product with model number ${model}`
      };
    }

    return null;
  }

  private parseProductDescription(description: string): Partial<AppleProduct> | null {
    const lower = description.toLowerCase();
    
    // Try to match iPhone
    const iPhoneMatch = lower.match(/iphone\s*(\d+\s*(pro\s*max|pro|plus|se)?)/i);
    if (iPhoneMatch) {
      return {
        name: `iPhone ${iPhoneMatch[1]}`.trim(),
        category: 'iPhone'
      };
    }

    // Try to match iPad
    const iPadMatch = lower.match(/ipad\s*(pro|air|mini)?\s*(\d+)?/i);
    if (iPadMatch) {
      let name = 'iPad';
      if (iPadMatch[1]) name += ` ${iPadMatch[1]}`;
      if (iPadMatch[2]) name += ` ${iPadMatch[2]}`;
      return {
        name: name.trim(),
        category: 'iPad'
      };
    }

    // Try to match Mac
    const macMatch = lower.match(/(macbook\s*(pro|air)|imac|mac\s*mini|mac\s*studio|mac\s*pro)/i);
    if (macMatch) {
      return {
        name: macMatch[1],
        category: 'Mac'
      };
    }

    // Try to match Apple Watch
    const watchMatch = lower.match(/apple\s*watch\s*(series\s*\d+|se|ultra)?/i);
    if (watchMatch) {
      let name = 'Apple Watch';
      if (watchMatch[1]) name += ` ${watchMatch[1]}`;
      return {
        name: name.trim(),
        category: 'Apple Watch'
      };
    }

    return null;
  }

  private findMatchingProduct(parsed: Partial<AppleProduct>): Product | null {
    const found = this.knownProducts.find(p => 
      p.name.toLowerCase().includes(parsed.name?.toLowerCase() || '') &&
      p.category === parsed.category
    );

    if (found) {
      return {
        name: found.name,
        model: found.model,
        category: found.category,
        description: `${found.name} - ${found.colors?.join(', ')} - ${found.storages?.join(', ')}`
      };
    }

    return null;
  }

  private async searchAppleWebsite(query: string, location: string): Promise<Product | null> {
    try {
      // This is a simplified search - in production, you'd want to implement
      // a more robust search using Apple's website or a product database
      const searchUrl = `https://www.apple.com/shop/search/${encodeURIComponent(query)}`;
      
      // For now, return null to indicate we couldn't find the product
      // In a real implementation, you'd parse the search results
      console.log(`Would search Apple website for: ${query}`);
      return null;
    } catch (error) {
      console.error('Error searching Apple website:', error);
      return null;
    }
  }

  getKnownProducts(): AppleProduct[] {
    return [...this.knownProducts];
  }

  getProductsByCategory(category: string): AppleProduct[] {
    return this.knownProducts.filter(p => 
      p.category.toLowerCase() === category.toLowerCase()
    );
  }

  searchProducts(query: string): AppleProduct[] {
    const lower = query.toLowerCase();
    return this.knownProducts.filter(p =>
      p.name.toLowerCase().includes(lower) ||
      p.model.toLowerCase().includes(lower) ||
      p.category.toLowerCase().includes(lower)
    );
  }
}