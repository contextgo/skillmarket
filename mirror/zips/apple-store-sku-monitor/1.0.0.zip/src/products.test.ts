import { ProductManager } from './products';

describe('ProductManager', () => {
  let productManager: ProductManager;

  beforeEach(() => {
    productManager = new ProductManager();
  });

  test('should have known products', () => {
    const products = productManager.getKnownProducts();
    expect(products.length).toBeGreaterThan(0);
  });

  test('should search products by name', () => {
    const iPhoneProducts = productManager.searchProducts('iPhone');
    expect(iPhoneProducts.length).toBeGreaterThan(0);
    iPhoneProducts.forEach(product => {
      expect(product.name.toLowerCase()).toContain('iphone');
    });
  });

  test('should get products by category', () => {
    const iPhoneProducts = productManager.getProductsByCategory('iPhone');
    expect(iPhoneProducts.length).toBeGreaterThan(0);
    iPhoneProducts.forEach(product => {
      expect(product.category).toBe('iPhone');
    });
  });

  test('should resolve product by model number', async () => {
    const product = await productManager.resolveProduct('MU7A3LL/A', '10001');
    expect(product).not.toBeNull();
    expect(product?.model).toBe('MU7A3LL/A');
  });

  test('should resolve product by name', async () => {
    const product = await productManager.resolveProduct('iPhone 15 Pro Max', '10001');
    expect(product).not.toBeNull();
    expect(product?.name).toContain('iPhone');
  });
});