import { ProductManager } from './products';
import { ConfigManager } from './config';
import { NotificationManager } from './notifications';

// Test ProductManager
console.log('Testing ProductManager...');
const productManager = new ProductManager();

// Test known products
const knownProducts = productManager.getKnownProducts();
console.log(`Found ${knownProducts.length} known products`);

// Test product search
const iPhoneProducts = productManager.searchProducts('iPhone');
console.log(`Found ${iPhoneProducts.length} iPhone products`);

// Test product resolution
async function testProductResolution() {
  const product = await productManager.resolveProduct('iPhone 15 Pro Max', '10001');
  if (product) {
    console.log('Resolved product:', product);
  } else {
    console.log('Could not resolve product');
  }
}

// Test ConfigManager
console.log('\nTesting ConfigManager...');
const configManager = new ConfigManager();

// Test default values
console.log('Default check interval:', configManager.getCheckInterval());
console.log('Default location:', configManager.getLocation());
console.log('Default notification method:', configManager.getNotificationMethod());

// Test NotificationManager
console.log('\nTesting NotificationManager...');
const notificationManager = new NotificationManager(configManager);

// Test notification
async function testNotification() {
  await notificationManager.testNotification();
}

// Run tests
async function runTests() {
  await testProductResolution();
  await testNotification();
  console.log('\nAll tests completed!');
}

runTests().catch(console.error);