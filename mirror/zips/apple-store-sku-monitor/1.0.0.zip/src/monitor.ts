import axios, { AxiosInstance, AxiosError } from 'axios';
import { ConfigManager } from './config';
import { NotificationManager } from './notifications';
import { ProductManager, Product } from './products';
import { setTimeout } from 'timers/promises';

interface StoreAvailability {
  storeId: string;
  storeName: string;
  storeAddress: string;
  available: boolean;
  pickupDisplay: string;
  pickupMessage: string;
  quantity: number;
}

interface ProductAvailability {
  product: Product;
  stores: StoreAvailability[];
  timestamp: Date;
}

interface MonitorStatus {
  running: boolean;
  productsCount: number;
  lastCheck: Date | null;
  nextCheck: Date | null;
  errors: string[];
}

export class Monitor {
  private config: ConfigManager;
  private notifications: NotificationManager;
  private products: ProductManager;
  private client: AxiosInstance;
  private running: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private lastCheck: Date | null = null;
  private errors: string[] = [];
  private userAgents: string[] = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  ];

  constructor(
    config: ConfigManager,
    notifications: NotificationManager,
    products: ProductManager
  ) {
    this.config = config;
    this.notifications = notifications;
    this.products = products;
    this.client = this.createHttpClient();
  }

  private createHttpClient(): AxiosInstance {
    const client = axios.create({
      timeout: 30000,
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      }
    });

    // Add request interceptor for anti-scraping
    client.interceptors.request.use((config) => {
      // Rotate user agent
      const userAgent = this.userAgents[Math.floor(Math.random() * this.userAgents.length)];
      config.headers['User-Agent'] = userAgent;

      // Add random delay to avoid detection
      const delay = Math.random() * 2000 + 1000; // 1-3 seconds
      return new Promise(resolve => {
        setTimeout(delay).then(() => resolve(config));
      });
    });

    // Add response interceptor for error handling
    client.interceptors.response.use(
      response => response,
      async (error: AxiosError) => {
        if (error.response?.status === 429) {
          // Rate limited - wait longer
          console.log('Rate limited, waiting 60 seconds...');
          await setTimeout(60000);
          return client.request(error.config!);
        }
        throw error;
      }
    );

    return client;
  }

  async start(): Promise<void> {
    if (this.running) {
      console.log('Monitor is already running');
      return;
    }

    this.running = true;
    console.log('Starting Apple Store monitor...');

    // Initial check
    await this.checkAvailability();

    // Schedule periodic checks
    const interval = this.config.getCheckInterval() * 1000;
    this.intervalId = setInterval(async () => {
      try {
        await this.checkAvailability();
      } catch (error) {
        console.error('Error during availability check:', error);
        this.errors.push(`Check failed: ${error}`);
      }
    }, interval);

    console.log(`Monitor started. Checking every ${this.config.getCheckInterval()} seconds.`);
  }

  async stop(): Promise<void> {
    if (!this.running) {
      console.log('Monitor is not running');
      return;
    }

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.running = false;
    console.log('Monitor stopped');
  }

  getStatus(): MonitorStatus {
    const interval = this.config.getCheckInterval();
    const nextCheck = this.lastCheck
      ? new Date(this.lastCheck.getTime() + interval * 1000)
      : null;

    return {
      running: this.running,
      productsCount: this.config.getProducts().length,
      lastCheck: this.lastCheck,
      nextCheck: nextCheck,
      errors: this.errors.slice(-10) // Last 10 errors
    };
  }

  private async checkAvailability(): Promise<void> {
    const products = this.config.getProducts();
    if (products.length === 0) {
      console.log('No products to monitor');
      return;
    }

    console.log(`Checking availability for ${products.length} products...`);
    this.lastCheck = new Date();

    for (const product of products) {
      try {
        const availability = await this.checkProductAvailability(product);
        await this.processAvailability(availability);
      } catch (error) {
        console.error(`Error checking ${product.name}:`, error);
        this.errors.push(`Failed to check ${product.name}: ${error}`);
      }

      // Add delay between product checks to avoid detection
      await setTimeout(Math.random() * 3000 + 2000); // 2-5 seconds
    }
  }

  private async checkProductAvailability(product: Product): Promise<ProductAvailability> {
    const location = this.config.getLocation();
    if (!location) {
      throw new Error('Location not configured');
    }

    // Build API URL
    const baseUrl = 'https://www.apple.com/shop/fulfillment-messages';
    const params = new URLSearchParams();
    
    // Add product parts
    params.append('parts.0', product.model);
    params.append('searchNearby', 'true');
    params.append('location', location);

    // Try to get store ID if location is a zip code
    if (/^\d{5}(-\d{4})?$/.test(location)) {
      params.append('mts.0', 'regular');
      params.append('fts', 'true');
    }

    const url = `${baseUrl}?${params.toString()}`;
    
    try {
      const response = await this.client.get(url);
      const data = response.data;

      if (!data.body?.content?.pickupMessage?.stores) {
        throw new Error('Invalid response format');
      }

      const stores = data.body.content.pickupMessage.stores;
      const storeAvailabilities: StoreAvailability[] = [];

      for (const store of stores) {
        const partAvailability = store.partsAvailability?.[product.model];
        if (partAvailability) {
          storeAvailabilities.push({
            storeId: store.storeNumber,
            storeName: store.storeName,
            storeAddress: store.address?.address ?? 'Unknown address',
            available: partAvailability.pickupDisplay === 'available',
            pickupDisplay: partAvailability.pickupDisplay,
            pickupMessage: partAvailability.messageTypes?.regular?.storePickupQuote ?? '',
            quantity: partAvailability.storePickupQty ?? 0
          });
        }
      }

      return {
        product,
        stores: storeAvailabilities,
        timestamp: new Date()
      };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 404) {
          throw new Error(`Product ${product.model} not found`);
        }
        if (error.response?.status === 429) {
          throw new Error('Rate limited by Apple');
        }
      }
      throw error;
    }
  }

  private async processAvailability(availability: ProductAvailability): Promise<void> {
    const availableStores = availability.stores.filter(store => store.available);
    
    if (availableStores.length > 0) {
      console.log(`✅ ${availability.product.name} is available at ${availableStores.length} stores!`);
      
      // Send notification
      await this.notifications.sendAvailabilityAlert(availability.product, availableStores);
      
      // Log details
      availableStores.forEach(store => {
        console.log(`  - ${store.storeName}: ${store.pickupMessage}`);
      });
    } else {
      console.log(`❌ ${availability.product.name} is not available at nearby stores`);
    }
  }

  // Handle proxy rotation if enabled
  private getProxyConfig(): any {
    if (!this.config.getUseProxy()) {
      return {};
    }

    const proxies = this.config.getProxyList();
    if (proxies.length === 0) {
      return {};
    }

    const proxy = proxies[Math.floor(Math.random() * proxies.length)];
    const [host, port] = proxy.split(':');
    
    return {
      proxy: {
        host,
        port: parseInt(port),
        protocol: 'http'
      }
    };
  }
}