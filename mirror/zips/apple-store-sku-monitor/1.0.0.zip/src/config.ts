import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import { Product } from './products';

interface AppConfig {
  check_interval: number;
  location: string;
  notification_method: string;
  webhook_url?: string;
  ntfy_topic?: string;
  email_config?: {
    smtp_server: string;
    smtp_port: number;
    sender_email: string;
    sender_password: string;
    recipient_email: string;
  };
  use_proxy: boolean;
  proxy_list: string[];
  products: Product[];
}

const DEFAULT_CONFIG: AppConfig = {
  check_interval: 300,
  location: '',
  notification_method: 'console',
  use_proxy: false,
  proxy_list: [],
  products: []
};

export class ConfigManager {
  private configPath: string;
  private config: AppConfig;

  constructor(configPath?: string) {
    this.configPath = configPath || join(process.env.HOME || process.env.USERPROFILE || '.', '.apple-store-monitor.json');
    this.config = this.loadConfig();
  }

  private loadConfig(): AppConfig {
    try {
      if (existsSync(this.configPath)) {
        const data = readFileSync(this.configPath, 'utf8');
        const parsed = JSON.parse(data);
        return { ...DEFAULT_CONFIG, ...parsed };
      }
    } catch (error) {
      console.warn('Failed to load config, using defaults:', error);
    }
    return { ...DEFAULT_CONFIG };
  }

  private saveConfig(): void {
    try {
      writeFileSync(this.configPath, JSON.stringify(this.config, null, 2));
    } catch (error) {
      console.error('Failed to save config:', error);
    }
  }

  getCheckInterval(): number {
    return this.config.check_interval;
  }

  setCheckInterval(interval: number): void {
    this.config.check_interval = interval;
    this.saveConfig();
  }

  getLocation(): string {
    return this.config.location;
  }

  setLocation(location: string): void {
    this.config.location = location;
    this.saveConfig();
  }

  getNotificationMethod(): string {
    return this.config.notification_method;
  }

  setNotificationMethod(method: string): void {
    this.config.notification_method = method;
    this.saveConfig();
  }

  getWebhookUrl(): string | undefined {
    return this.config.webhook_url;
  }

  setWebhookUrl(url: string): void {
    this.config.webhook_url = url;
    this.saveConfig();
  }

  getNtfyTopic(): string | undefined {
    return this.config.ntfy_topic;
  }

  setNtfyTopic(topic: string): void {
    this.config.ntfy_topic = topic;
    this.saveConfig();
  }

  getEmailConfig(): AppConfig['email_config'] {
    return this.config.email_config;
  }

  setEmailConfig(config: AppConfig['email_config']): void {
    this.config.email_config = config;
    this.saveConfig();
  }

  getUseProxy(): boolean {
    return this.config.use_proxy;
  }

  setUseProxy(use: boolean): void {
    this.config.use_proxy = use;
    this.saveConfig();
  }

  getProxyList(): string[] {
    return this.config.proxy_list;
  }

  setProxyList(proxies: string[]): void {
    this.config.proxy_list = proxies;
    this.saveConfig();
  }

  addProxy(proxy: string): void {
    if (!this.config.proxy_list.includes(proxy)) {
      this.config.proxy_list.push(proxy);
      this.saveConfig();
    }
  }

  removeProxy(proxy: string): void {
    const index = this.config.proxy_list.indexOf(proxy);
    if (index > -1) {
      this.config.proxy_list.splice(index, 1);
      this.saveConfig();
    }
  }

  getProducts(): Product[] {
    return this.config.products;
  }

  addProduct(product: Product): void {
    // Check if product already exists
    const exists = this.config.products.some(
      p => p.model === product.model
    );
    if (!exists) {
      this.config.products.push(product);
      this.saveConfig();
    }
  }

  removeProduct(identifier: string): boolean {
    const index = this.config.products.findIndex(
      p => p.model === identifier || p.name.toLowerCase() === identifier.toLowerCase()
    );
    if (index > -1) {
      this.config.products.splice(index, 1);
      this.saveConfig();
      return true;
    }
    return false;
  }

  clearProducts(): void {
    this.config.products = [];
    this.saveConfig();
  }

  // Get all config for display
  getAllConfig(): AppConfig {
    return { ...this.config };
  }

  // Update multiple config values
  updateConfig(updates: Partial<AppConfig>): void {
    this.config = { ...this.config, ...updates };
    this.saveConfig();
  }
}