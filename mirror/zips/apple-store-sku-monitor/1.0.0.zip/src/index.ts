import { Monitor } from './monitor';
import { ConfigManager } from './config';
import { NotificationManager } from './notifications';
import { ProductManager } from './products';
import { parseArgs } from 'util';

interface Args {
  action: 'add' | 'remove' | 'start' | 'stop' | 'status' | 'list';
  product?: string;
  model?: string;
  location?: string;
  interval?: number;
  notification?: string;
}

class AppleStoreMonitor {
  private monitor: Monitor;
  private config: ConfigManager;
  private notifications: NotificationManager;
  private products: ProductManager;

  constructor() {
    this.config = new ConfigManager();
    this.notifications = new NotificationManager(this.config);
    this.products = new ProductManager();
    this.monitor = new Monitor(this.config, this.notifications, this.products);
  }

  async run(args: Args): Promise<void> {
    try {
      switch (args.action) {
        case 'add':
          await this.addProduct(args);
          break;
        case 'remove':
          await this.removeProduct(args);
          break;
        case 'start':
          await this.startMonitoring();
          break;
        case 'stop':
          await this.stopMonitoring();
          break;
        case 'status':
          await this.showStatus();
          break;
        case 'list':
          await this.listProducts();
          break;
        default:
          this.showHelp();
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }

  private async addProduct(args: Args): Promise<void> {
    if (!args.product && !args.model) {
      console.error('Please specify a product name or model number');
      return;
    }

    const identifier = args.model || args.product;
    const location = args.location || this.config.getLocation();

    if (!location) {
      console.error('Please specify a location (zip code or city)');
      return;
    }

    const product = await this.products.resolveProduct(identifier!, location);
    if (product) {
      this.config.addProduct(product);
      console.log(`Added product: ${product.name} (${product.model})`);
    } else {
      console.error('Could not resolve product. Please check the product name or model number.');
    }
  }

  private async removeProduct(args: Args): Promise<void> {
    if (!args.product && !args.model) {
      console.error('Please specify a product name or model number');
      return;
    }

    const identifier = args.model || args.product;
    const removed = this.config.removeProduct(identifier!);
    if (removed) {
      console.log(`Removed product: ${identifier}`);
    } else {
      console.error('Product not found in monitor list');
    }
  }

  private async startMonitoring(): Promise<void> {
    const interval = this.config.getCheckInterval();
    console.log(`Starting Apple Store monitor (checking every ${interval} seconds)...`);
    await this.monitor.start();
  }

  private async stopMonitoring(): Promise<void> {
    await this.monitor.stop();
    console.log('Stopped Apple Store monitor');
  }

  private async showStatus(): Promise<void> {
    const status = this.monitor.getStatus();
    console.log('Apple Store Monitor Status:');
    console.log(`- Running: ${status.running}`);
    console.log(`- Products monitored: ${status.productsCount}`);
    console.log(`- Last check: ${status.lastCheck}`);
    console.log(`- Next check: ${status.nextCheck}`);
  }

  private async listProducts(): Promise<void> {
    const products = this.config.getProducts();
    if (products.length === 0) {
      console.log('No products being monitored');
      return;
    }

    console.log('Monitored Products:');
    products.forEach((product, index) => {
      console.log(`${index + 1}. ${product.name} (${product.model})`);
    });
  }

  private showHelp(): void {
    console.log('Apple Store Monitor - Usage:');
    console.log('  --action <add|remove|start|stop|status|list>');
    console.log('  --product <product name>');
    console.log('  --model <model number>');
    console.log('  --location <zip code or city>');
    console.log('  --interval <seconds>');
    console.log('  --notification <console|email|webhook|ntfy>');
  }
}

// CLI interface
if (require.main === module) {
  const args = process.argv.slice(2);
  const parsedArgs: Args = {
    action: 'status'
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--action':
        parsedArgs.action = args[++i] as Args['action'];
        break;
      case '--product':
        parsedArgs.product = args[++i];
        break;
      case '--model':
        parsedArgs.model = args[++i];
        break;
      case '--location':
        parsedArgs.location = args[++i];
        break;
      case '--interval':
        parsedArgs.interval = parseInt(args[++i]);
        break;
      case '--notification':
        parsedArgs.notification = args[++i];
        break;
    }
  }

  const monitor = new AppleStoreMonitor();
  monitor.run(parsedArgs).catch(console.error);
}

export { AppleStoreMonitor };