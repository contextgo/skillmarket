import axios from 'axios';
import { writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { ConfigManager } from './config';
import { Product } from './products';

interface StoreAvailability {
  storeId: string;
  storeName: string;
  storeAddress: string;
  available: boolean;
  pickupDisplay: string;
  pickupMessage: string;
  quantity: number;
}

interface OpenClawMessage {
  type: 'notification' | 'alert' | 'message';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  title: string;
  body: string;
  metadata?: Record<string, any>;
}

export class NotificationManager {
  private config: ConfigManager;
  private openclawMessageDir: string;

  constructor(config: ConfigManager) {
    this.config = config;
    // OpenClaw消息目录 - 用于写入消息文件
    this.openclawMessageDir = join(
      process.env.OPENCLAW_WORKSPACE || process.env.HOME || process.cwd(),
      '.openclaw',
      'messages',
      'outbox'
    );
  }

  async sendAvailabilityAlert(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    const method = this.config.getNotificationMethod();
    
    // 总是通过OpenClaw发送通知（如果在OpenClaw环境中）
    if (this.isOpenClawEnvironment()) {
      await this.sendOpenClawNotification(product, availableStores);
      return;
    }

    // 非OpenClaw环境使用配置的通知方式
    switch (method) {
      case 'console':
        await this.sendConsoleNotification(product, availableStores);
        break;
      case 'email':
        await this.sendEmailNotification(product, availableStores);
        break;
      case 'webhook':
        await this.sendWebhookNotification(product, availableStores);
        break;
      case 'ntfy':
        await this.sendNtfyNotification(product, availableStores);
        break;
      case 'openclaw':
        await this.sendOpenClawNotification(product, availableStores);
        break;
      default:
        console.error(`Unknown notification method: ${method}`);
        await this.sendConsoleNotification(product, availableStores);
    }
  }

  /**
   * 检测是否在OpenClaw环境中运行
   */
  private isOpenClawEnvironment(): boolean {
    return !!(
      process.env.OPENCLAW_WORKSPACE ||
      process.env.OPENCLAW_SESSION_ID ||
      process.env.OPENCLAW_GATEWAY_URL
    );
  }

  /**
   * 通过OpenClaw发送通知
   * 这会自动通过用户已连接的消息平台（飞书、QQ、Telegram等）发送
   */
  private async sendOpenClawNotification(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    const message = this.formatOpenClawMessage(product, availableStores);
    
    // 方式1: 通过标准输出发送（OpenClaw会自动捕获）
    console.log('\n' + message.formatted);
    
    // 方式2: 通过OpenClaw消息文件发送
    await this.writeOpenClawMessageFile({
      type: 'alert',
      priority: 'high',
      title: message.title,
      body: message.body,
      metadata: {
        product: product,
        stores: availableStores,
        timestamp: new Date().toISOString()
      }
    });

    // 方式3: 如果配置了OpenClaw Gateway URL，直接发送
    const gatewayUrl = process.env.OPENCLAW_GATEWAY_URL;
    if (gatewayUrl) {
      await this.sendToOpenClawGateway(gatewayUrl, {
        type: 'alert',
        priority: 'high',
        title: message.title,
        body: message.body
      });
    }

    console.log('[OpenClaw] Notification sent to connected platforms (Feishu/QQ/Telegram/etc.)');
  }

  /**
   * 格式化OpenClaw消息
   */
  private formatOpenClawMessage(product: Product, availableStores: StoreAvailability[]): { title: string; body: string; formatted: string } {
    const title = `🍎 Apple Store库存提醒 - ${product.name}`;
    
    let body = `好消息！${product.name} 现在有货了！\n\n`;
    body += `📱 产品信息:\n`;
    body += `- 名称: ${product.name}\n`;
    body += `- 型号: ${product.model}\n`;
    body += `- 分类: ${product.category}\n\n`;
    
    body += `🏪 可取货门店 (${availableStores.length}家):\n\n`;
    
    availableStores.forEach((store, index) => {
      body += `${index + 1}. ${store.storeName}\n`;
      body += `   📍 地址: ${store.storeAddress}\n`;
      body += `   ✅ 状态: ${store.pickupDisplay === 'available' ? '有货' : store.pickupDisplay}\n`;
      body += `   💬 ${store.pickupMessage}\n`;
      if (store.quantity > 0) {
        body += `   📦 库存: ${store.quantity}件\n`;
      }
      body += '\n';
    });

    body += `🔗 前往Apple Store选购:\n`;
    body += `https://www.apple.com.cn/shop/buy-iphone\n\n`;
    body += `⏰ 检测时间: ${new Date().toLocaleString('zh-CN')}`;

    const formatted = `
╔══════════════════════════════════════════════════════════╗
║  🍎 Apple Store 库存有货提醒！                          ║
╚══════════════════════════════════════════════════════════╝

📱 产品: ${product.name}
📋 型号: ${product.model}
📂 分类: ${product.category}

🏪 可取货门店 (${availableStores.length}家):
${availableStores.map((store, i) => `
${i + 1}. ${store.storeName}
   📍 ${store.storeAddress}
   ✅ ${store.pickupMessage}
`).join('')}
🔗 立即前往选购: https://www.apple.com.cn/shop/buy-iphone

⏰ 检测时间: ${new Date().toLocaleString('zh-CN')}
`;

    return { title, body, formatted };
  }

  /**
   * 写入OpenClaw消息文件
   */
  private async writeOpenClawMessageFile(message: OpenClawMessage): Promise<void> {
    try {
      // 确保目录存在
      if (!existsSync(this.openclawMessageDir)) {
        mkdirSync(this.openclawMessageDir, { recursive: true });
      }

      const filename = `apple-store-alert-${Date.now()}.json`;
      const filepath = join(this.openclawMessageDir, filename);
      
      writeFileSync(filepath, JSON.stringify(message, null, 2));
      console.log(`[OpenClaw] Message file written: ${filepath}`);
    } catch (error) {
      console.error('[OpenClaw] Failed to write message file:', error);
    }
  }

  /**
   * 通过OpenClaw Gateway发送消息
   */
  private async sendToOpenClawGateway(gatewayUrl: string, message: OpenClawMessage): Promise<void> {
    try {
      const sessionId = process.env.OPENCLAW_SESSION_ID;
      const response = await axios.post(`${gatewayUrl}/api/messages/send`, {
        sessionId,
        message
      }, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 5000
      });
      
      console.log(`[OpenClaw] Gateway notification sent: ${response.status}`);
    } catch (error) {
      console.error('[OpenClaw] Failed to send to gateway:', error);
    }
  }

  /**
   * 控制台通知（非OpenClaw环境）
   */
  private async sendConsoleNotification(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    console.log('\n' + '='.repeat(60));
    console.log('🍎 APPLE STORE STOCK ALERT! 🍎');
    console.log('='.repeat(60));
    console.log(`Product: ${product.name}`);
    console.log(`Model: ${product.model}`);
    console.log(`Category: ${product.category}`);
    console.log(`\nAvailable at ${availableStores.length} store(s):`);
    
    availableStores.forEach((store, index) => {
      console.log(`\n${index + 1}. ${store.storeName}`);
      console.log(`   Address: ${store.storeAddress}`);
      console.log(`   Status: ${store.pickupDisplay}`);
      console.log(`   Message: ${store.pickupMessage}`);
      if (store.quantity > 0) {
        console.log(`   Quantity: ${store.quantity}`);
      }
    });
    
    console.log('\n' + '='.repeat(60));
    console.log('Check Apple Store for pickup options!');
    console.log('='.repeat(60) + '\n');
  }

  /**
   * 邮件通知
   */
  private async sendEmailNotification(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    const emailConfig = this.config.getEmailConfig();
    if (!emailConfig) {
      console.error('Email configuration not set');
      return;
    }

    const subject = `Apple Store Alert: ${product.name} Available!`;
    const body = this.formatEmailBody(product, availableStores);

    console.log(`[EMAIL] To: ${emailConfig.recipient_email}`);
    console.log(`[EMAIL] Subject: ${subject}`);
    console.log(`[EMAIL] Body:\n${body}`);
    console.log('Email notification sent (simulated)');
  }

  private formatEmailBody(product: Product, availableStores: StoreAvailability[]): string {
    let body = `Great news! The ${product.name} is now available for pickup at Apple Stores near you.\n\n`;
    body += `Product Details:\n`;
    body += `- Name: ${product.name}\n`;
    body += `- Model: ${product.model}\n`;
    body += `- Category: ${product.category}\n\n`;
    
    body += `Available at ${availableStores.length} store(s):\n\n`;
    
    availableStores.forEach((store, index) => {
      body += `${index + 1}. ${store.storeName}\n`;
      body += `   Address: ${store.storeAddress}\n`;
      body += `   Status: ${store.pickupDisplay}\n`;
      body += `   Message: ${store.pickupMessage}\n`;
      if (store.quantity > 0) {
        body += `   Quantity: ${store.quantity}\n`;
      }
      body += '\n';
    });
    
    body += `Check Apple Store for pickup options:\n`;
    body += `https://www.apple.com.cn/shop/buy-iphone\n\n`;
    body += `This alert was generated by Apple Store Monitor.`;
    
    return body;
  }

  /**
   * Webhook通知
   */
  private async sendWebhookNotification(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    const webhookUrl = this.config.getWebhookUrl();
    if (!webhookUrl) {
      console.error('Webhook URL not configured');
      return;
    }

    const payload = {
      event: 'apple_store_stock_alert',
      timestamp: new Date().toISOString(),
      product: {
        name: product.name,
        model: product.model,
        category: product.category,
        description: product.description
      },
      availableStores: availableStores.map(store => ({
        storeId: store.storeId,
        storeName: store.storeName,
        storeAddress: store.storeAddress,
        pickupDisplay: store.pickupDisplay,
        pickupMessage: store.pickupMessage,
        quantity: store.quantity
      })),
      totalStores: availableStores.length
    };

    try {
      const response = await axios.post(webhookUrl, payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'AppleStoreMonitor/1.0'
        },
        timeout: 10000
      });
      
      console.log(`Webhook notification sent: ${response.status}`);
    } catch (error) {
      console.error('Failed to send webhook notification:', error);
    }
  }

  /**
   * ntfy通知
   */
  private async sendNtfyNotification(product: Product, availableStores: StoreAvailability[]): Promise<void> {
    const topic = this.config.getNtfyTopic();
    if (!topic) {
      console.error('ntfy topic not configured');
      return;
    }

    const title = `🍎 ${product.name} Available!`;
    const message = this.formatNtfyMessage(product, availableStores);
    const url = `https://ntfy.sh/${topic}`;

    try {
      await axios.post(url, message, {
        headers: {
          'Title': title,
          'Priority': 'high',
          'Tags': 'apple,stock,alert',
          'Click': `https://www.apple.com.cn/shop/buy-iphone`
        },
        timeout: 10000
      });
      
      console.log('ntfy notification sent');
    } catch (error) {
      console.error('Failed to send ntfy notification:', error);
    }
  }

  private formatNtfyMessage(product: Product, availableStores: StoreAvailability[]): string {
    let message = `${product.name} is available at ${availableStores.length} store(s)!\n\n`;
    
    availableStores.slice(0, 3).forEach((store, index) => {
      message += `${index + 1}. ${store.storeName}\n`;
      message += `   ${store.pickupMessage}\n\n`;
    });
    
    if (availableStores.length > 3) {
      message += `... and ${availableStores.length - 3} more stores\n`;
    }
    
    message += `Model: ${product.model}`;
    
    return message;
  }

  /**
   * 测试通知
   */
  async testNotification(): Promise<void> {
    const testProduct: Product = {
      name: 'iPhone 17 Pro 橙色 256GB',
      model: 'MG8U4CH/A',
      category: 'iPhone',
      description: '测试产品'
    };

    const testStores: StoreAvailability[] = [
      {
        storeId: 'R001',
        storeName: 'Apple 三里屯',
        storeAddress: '北京市朝阳区三里屯路19号院',
        available: true,
        pickupDisplay: 'available',
        pickupMessage: '今日可取货',
        quantity: 5
      },
      {
        storeId: 'R002',
        storeName: 'Apple 王府井',
        storeAddress: '北京市东城区王府井大街138号',
        available: true,
        pickupDisplay: 'available',
        pickupMessage: '明日可取货',
        quantity: 3
      }
    ];

    await this.sendAvailabilityAlert(testProduct, testStores);
  }
}