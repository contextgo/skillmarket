---
name: apple-store-monitor
description: Monitor Apple Store in-store pickup availability for Apple products and get notified when stock becomes available
---

# Apple Store Monitor

Monitor Apple Store in-store pickup availability for Apple products and get notified when stock becomes available.

## What I do

- Monitor Apple Store inventory for specific products
- Check availability at nearby stores based on location
- Send notifications when products become available
- Support multiple notification methods (console, email, webhook, ntfy)
- Handle anti-scraping measures with proxy rotation
- Track multiple products simultaneously
- Provide real-time stock status updates

## When to use me

- When you want to buy a new Apple product but it's out of stock
- When monitoring for limited availability items (new iPhone releases)
- When you want to be alerted when a product becomes available at your local Apple Store
- When tracking stock for multiple Apple products
- When setting up automated monitoring for Apple product availability

## Prerequisites

- Node.js 18+ installed
- Internet connection
- Location information (zip code or city name)
- Product model numbers (optional, can be auto-detected)

## Steps

### Step 1: Install the skill

Install the skill using OpenClaw CLI:

```bash
openclaw skills install apple-store-monitor
```

### Step 2: Configure the skill

Configure the skill with your preferences:

```bash
openclaw skills config apple-store-monitor
```

Set at minimum:
- `location`: Your zip code or city name
- `check_interval`: How often to check (in seconds)
- `notification_method`: How you want to be notified

### Step 3: Add products to monitor

Add products to monitor by model number or product name:

```bash
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"
```

Or add by model number:

```bash
openclaw skills run apple-store-monitor --action add --model "MU7A3ZD/A"
```

### Step 4: Start monitoring

Start the monitoring service:

```bash
openclaw skills run apple-store-monitor --action start
```

### Step 5: Check status

Check current monitoring status:

```bash
openclaw skills run apple-store-monitor --action status
```

### Step 6: Stop monitoring

Stop the monitoring service:

```bash
openclaw skills run apple-store-monitor --action stop
```

## Configuration Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `check_interval` | number | 300 | Check interval in seconds |
| `location` | string | required | Zip code or city name |
| `notification_method` | string | console | Notification method: console, email, webhook, ntfy |
| `webhook_url` | string | optional | Webhook URL for notifications |
| `ntfy_topic` | string | optional | ntfy topic name for push notifications |
| `use_proxy` | boolean | false | Use proxy rotation |
| `proxy_list` | array | optional | List of proxy servers |

## Notification Methods

### Console (default)
Notifications are printed to the console where the skill is running.

### Email
Configure SMTP settings in `email_config`:
- `smtp_server`: Your SMTP server
- `smtp_port`: SMTP port (default: 587)
- `sender_email`: Sender email address
- `sender_password`: Sender email password
- `recipient_email`: Recipient email address

### Webhook
Set `webhook_url` to receive POST requests with availability data.

### ntfy
Set `ntfy_topic` to receive push notifications via ntfy.sh.

## Anti-Scraping Features

The skill includes several features to avoid rate limiting:
- Random delays between requests
- User-Agent rotation
- Proxy rotation support
- Request throttling
- Automatic retry with exponential backoff

## Best Practices

1. **Set reasonable check intervals**: Don't check more frequently than every 5 minutes
2. **Use proxy rotation**: Enable if you're monitoring many products
3. **Monitor only what you need**: Limit the number of products to avoid detection
4. **Use ntfy for mobile notifications**: Best for real-time alerts
5. **Check store hours**: Apple Store inventory updates during business hours

## Common Issues

### "Rate limited" errors
- Increase check interval
- Enable proxy rotation
- Reduce number of monitored products

### "No stores found" error
- Verify your location (zip code or city)
- Check if Apple Stores exist in your area
- Try a nearby major city

### "Product not found" error
- Verify product model number
- Check if product is available in your region
- Use Apple's website to confirm product availability

## API Reference

Apple uses an undocumented API for inventory checking:
```
GET https://www.apple.com/shop/fulfillment-messages
  ?parts.0=MODEL_NUMBER
  &searchNearby=true
  &store=STORE_ID
  &location=ZIP_CODE
```

## Example Usage

### 监控 iPhone 17 Pro
```bash
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB" --location "北京"
openclaw skills run apple-store-monitor --action start
```

### 监控 Mac mini M4
```bash
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB" --location "北京"
openclaw skills run apple-store-monitor --action start
```

### 监控多个产品
```bash
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB" --location "北京"
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB" --location "北京"
openclaw skills run apple-store-monitor --action start
```

### Monitor with ntfy notifications
```bash
openclaw skills config apple-store-monitor --set notification_method=ntfy
openclaw skills config apple-store-monitor --set ntfy_topic=my-apple-alerts
openclaw skills run apple-store-monitor --action start
```

## Support

For issues or questions:
- Check the GitHub repository
- Review Apple's product model numbers
- Verify your location settings

## License

MIT