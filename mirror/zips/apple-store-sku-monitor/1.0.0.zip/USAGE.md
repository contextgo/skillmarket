# Apple Store Monitor - 使用示例

## 基本使用流程

### 1. 安装skill
```bash
openclaw skills install apple-store-monitor
```

### 2. 配置位置
```bash
openclaw skills config apple-store-monitor --set location=北京
```

### 3. 添加要监控的产品
```bash
# 添加 iPhone 17 Pro 橙色 256GB
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"

# 添加 Mac mini M4 16+256GB
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB"

# 添加 Apple Watch
openclaw skills run apple-store-monitor --action add --model "MQDY3CH/A"
```

### 4. 开始监控
```bash
openclaw skills run apple-store-monitor --action start
```

### 5. 查看监控状态
```bash
openclaw skills run apple-store-monitor --action status
```

## 高级配置

### 设置ntfy推送通知
```bash
openclaw skills config apple-store-monitor --set notification_method=ntfy
openclaw skills config apple-store-monitor --set ntfy_topic=my-apple-alerts
```

### 设置邮件通知
```bash
openclaw skills config apple-store-monitor --set notification_method=email
openclaw skills config apple-store-monitor --set email_config.smtp_server=smtp.gmail.com
openclaw skills config apple-store-monitor --set email_config.smtp_port=587
openclaw skills config apple-store-monitor --set email_config.sender_email=your-email@gmail.com
openclaw skills config apple-store-monitor --set email_config.sender_password=your-app-password
openclaw skills config apple-store-monitor --set email_config.recipient_email=recipient@example.com
```

### 设置Webhook通知
```bash
openclaw skills config apple-store-monitor --set notification_method=webhook
openclaw skills config apple-store-monitor --set webhook_url=https://your-webhook-url.com
```

### 启用代理旋转
```bash
openclaw skills config apple-store-monitor --set use_proxy=true
openclaw skills config apple-store-monitor --set proxy_list.0=proxy1:port
openclaw skills config apple-store-monitor --set proxy_list.1=proxy2:port
```

## 常用产品型号

### iPhone 17系列
- iPhone 17 Pro 256GB 橙色: `MX9A3CH/A`
- iPhone 17 Pro 256GB 深空黑: `MX9B3CH/A`
- iPhone 17 Pro 256GB 白色: `MX9C3CH/A`
- iPhone 17 Pro 256GB 钛金色: `MX9D3CH/A`

### Mac mini
- Mac mini M4 16+256GB: `MYF63CH/A`
- Mac mini M4 16+512GB: `MYF73CH/A`
- Mac mini M4 Pro 24+512GB: `MYF83CH/A`

### MacBook Pro
- MacBook Pro 14" M3 深空黑色: `MRX33CH/A`
- MacBook Pro 16" M3 Pro 银色: `MRX63CH/A`

### Apple Watch
- Apple Watch Ultra 2: `MQDY3CH/A`
- Apple Watch Series 9 41mm 午夜色: `MQTT3CH/A`

## 监控示例

### 监控 iPhone 17 Pro 橙色 256GB
```bash
# 添加产品
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"

# 设置位置
openclaw skills config apple-store-monitor --set location=北京

# 开始监控
openclaw skills run apple-store-monitor --action start
```

### 监控 Mac mini M4
```bash
# 添加产品
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB"

# 设置位置
openclaw skills config apple-store-monitor --set location=北京

# 开始监控
openclaw skills run apple-store-monitor --action start
```

### 监控多个产品
```bash
# 添加多个产品
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"
openclaw skills run apple-store-monitor --action add --product "Mac mini M4 16+256GB"

# 设置位置
openclaw skills config apple-store-monitor --set location=北京

# 查看监控列表
openclaw skills run apple-store-monitor --action list

# 开始监控
openclaw skills run apple-store-monitor --action start
```

### 监控北京所有门店
```bash
# 设置位置为北京
openclaw skills config apple-store-monitor --set location="北京"

# 添加产品
openclaw skills run apple-store-monitor --action add --product "iPhone 17 Pro 橙色 256GB"

# 开始监控
openclaw skills run apple-store-monitor --action start
```

## 故障排除

### 速率限制错误
如果遇到"429 Too Many Requests"错误：
1. 增加检查间隔：`openclaw skills config apple-store-monitor --set check_interval=600`
2. 启用代理旋转：`openclaw skills config apple-store-monitor --set use_proxy=true`
3. 减少监控产品数量

### 找不到商店
1. 验证位置是否正确
2. 检查所在区域是否有Apple Store
3. 尝试使用附近的邮编

### 找不到产品
1. 验证产品型号是否正确
2. 检查产品是否在您所在区域可用
3. 使用Apple网站确认产品可用性

## 注意事项

1. **检查间隔**：建议设置为5分钟或更长，避免被Apple限制
2. **代理使用**：如果监控多个产品，建议启用代理旋转
3. **通知方式**：ntfy提供最好的实时推送体验
4. **产品型号**：使用正确的型号可以提高监控准确性
5. **位置设置**：使用邮编通常比城市名称更准确

## 支持

如有问题，请检查：
1. GitHub仓库的README
2. Apple产品型号是否正确
3. 位置设置是否准确