#!/bin/bash

# Apple Store Monitor Demo Script

echo "🍎 Apple Store Monitor Demo 🍎"
echo "================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

echo "1. Building the project..."
npm run build

echo ""
echo "2. Testing the product manager..."
node -e "
const { ProductManager } = require('./dist/products');
const pm = new ProductManager();
console.log('Known products:', pm.getKnownProducts().length);
console.log('iPhone products:', pm.searchProducts('iPhone').length);
"

echo ""
echo "3. Testing configuration..."
node -e "
const { ConfigManager } = require('./dist/config');
const cm = new ConfigManager();
console.log('Default check interval:', cm.getCheckInterval(), 'seconds');
console.log('Default notification method:', cm.getNotificationMethod());
"

echo ""
echo "4. Example usage:"
echo ""
echo "   # Add iPhone 17 Pro 橙色 256GB to monitor"
echo "   node dist/index.js --action add --product \"iPhone 17 Pro 橙色 256GB\" --location 北京"
echo ""
echo "   # Add Mac mini M4 16+256GB to monitor"
echo "   node dist/index.js --action add --product \"Mac mini M4 16+256GB\" --location 北京"
echo ""
echo "   # Start monitoring"
echo "   node dist/index.js --action start"
echo ""
echo "   # Check status"
echo "   node dist/index.js --action status"
echo ""
echo "   # List monitored products"
echo "   node dist/index.js --action list"
echo ""
echo "5. Configuration file location:"
echo "   ~/.apple-store-monitor.json"
echo ""
echo "6. For OpenClaw integration:"
echo "   openclaw skills install apple-store-monitor"
echo "   openclaw skills config apple-store-monitor --set location=北京"
echo "   openclaw skills run apple-store-monitor --action start"
echo ""
echo "Demo completed!"