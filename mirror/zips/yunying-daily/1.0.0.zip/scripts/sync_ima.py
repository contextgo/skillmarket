#!/usr/bin/env python3
"""
IMA知识库同步模块
上传日报图片到IMA知识库并创建笔记
"""

import os
import json
import base64
import hashlib
import hmac
import time
from datetime import datetime
from typing import Dict, Optional
from urllib.parse import urlencode, quote
import requests

# IMA API配置
IMA_API_BASE = "https://ima.qq.com/api"
DEFAULT_KB_ID = "9V7e8YtjP1dyxmbfyZzcPJtImM6TpLqSdvWnNqXCg9g="


class IMAClient:
    """IMA API客户端"""
    
    def __init__(self, client_id: str = None, api_key: str = None):
        """
        初始化IMA客户端
        
        Args:
            client_id: IMA Client ID，默认从环境变量读取
            api_key: IMA API Key，默认从环境变量读取
        """
        self.client_id = client_id or os.environ.get("IMA_OPENAPI_CLIENTID")
        self.api_key = api_key or os.environ.get("IMA_OPENAPI_APIKEY")
        
        if not self.client_id or not self.api_key:
            raise ValueError("IMA credentials not found. Set IMA_OPENAPI_CLIENTID and IMA_OPENAPI_APIKEY environment variables.")
    
    def _generate_signature(self, params: Dict) -> str:
        """生成API签名"""
        # 按key排序并拼接
        sorted_params = sorted(params.items())
        query_string = urlencode(sorted_params)
        
        # HMAC-SHA256签名
        signature = hmac.new(
            self.api_key.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        return signature
    
    def _make_request(self, endpoint: str, params: Dict = None, method: str = "GET") -> Dict:
        """发起API请求"""
        if params is None:
            params = {}
        
        # 添加公共参数
        params["client_id"] = self.client_id
        params["timestamp"] = str(int(time.time()))
        params["nonce"] = hashlib.md5(os.urandom(16)).hexdigest()[:16]
        
        # 生成签名
        params["signature"] = self._generate_signature(params)
        
        url = f"{IMA_API_BASE}{endpoint}"
        
        if method == "GET":
            response = requests.get(url, params=params, timeout=30)
        else:
            response = requests.post(url, json=params, timeout=30)
        
        response.raise_for_status()
        return response.json()
    
    def create_media(self, file_path: str) -> Dict:
        """
        创建媒体资源（获取上传URL）
        
        Args:
            file_path: 本地文件路径
        
        Returns:
            包含上传URL和媒体ID的字典
        """
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        
        # 计算文件MD5
        with open(file_path, "rb") as f:
            file_md5 = hashlib.md5(f.read()).hexdigest()
        
        params = {
            "file_name": file_name,
            "file_size": file_size,
            "file_md5": file_md5,
            "media_type": "image"
        }
        
        return self._make_request("/media/create", params, "POST")
    
    def upload_to_cos(self, upload_url: str, file_path: str) -> bool:
        """
        上传文件到COS
        
        Args:
            upload_url: COS上传URL
            file_path: 本地文件路径
        
        Returns:
            是否上传成功
        """
        with open(file_path, "rb") as f:
            files = {"file": f}
            response = requests.post(upload_url, files=files, timeout=60)
        
        return response.status_code == 200
    
    def add_knowledge(self, kb_id: str, media_id: str, title: str = None) -> Dict:
        """
        添加资源到知识库
        
        Args:
            kb_id: 知识库ID
            media_id: 媒体资源ID
            title: 资源标题
        
        Returns:
            API响应
        """
        if title is None:
            title = f"AI日报 {datetime.now().strftime('%Y-%m-%d')}"
        
        params = {
            "kb_id": kb_id,
            "media_id": media_id,
            "title": title,
            "type": "image"
        }
        
        return self._make_request("/knowledge/add", params, "POST")
    
    def upload_image(self, file_path: str, kb_id: str = None, title: str = None) -> str:
        """
        完整的图片上传流程
        
        Args:
            file_path: 本地图片路径
            kb_id: 知识库ID，默认使用配置值
            title: 资源标题
        
        Returns:
            CDN图片URL
        """
        if kb_id is None:
            kb_id = DEFAULT_KB_ID
        
        if title is None:
            date_str = os.path.basename(file_path).replace(".png", "")
            title = f"云鹰汇AI日报 {date_str}"
        
        # 1. 创建媒体资源
        media_resp = self.create_media(file_path)
        
        if media_resp.get("code") != 0 and media_resp.get("retcode") != 0:
            raise Exception(f"Create media failed: {media_resp}")
        
        upload_url = media_resp["data"]["upload_url"]
        media_id = media_resp["data"]["media_id"]
        
        # 2. 上传到COS
        if not self.upload_to_cos(upload_url, file_path):
            raise Exception("Upload to COS failed")
        
        # 3. 添加到知识库
        knowledge_resp = self.add_knowledge(kb_id, media_id, title)
        
        if knowledge_resp.get("code") != 0 and knowledge_resp.get("retcode") != 0:
            raise Exception(f"Add knowledge failed: {knowledge_resp}")
        
        # 返回CDN URL
        return knowledge_resp["data"].get("cdn_url", "")


def sync_daily_report(date_str: str = None, workspace: str = None, 
                     kb_id: str = None) -> Dict:
    """
    同步日报到IMA知识库
    
    Args:
        date_str: 日期字符串，默认今天
        workspace: 工作目录
        kb_id: 知识库ID
    
    Returns:
        同步结果字典
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    # 检查图片是否存在
    image_path = os.path.join(workspace, f"{date_str}.png")
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"日报图片不存在: {image_path}")
    
    # 初始化客户端
    client = IMAClient()
    
    # 上传图片
    title = f"云鹰汇AI日报 {date_str}"
    cdn_url = client.upload_image(image_path, kb_id, title)
    
    return {
        "date": date_str,
        "image_path": image_path,
        "cdn_url": cdn_url,
        "title": title,
        "status": "success",
        "timestamp": datetime.now().isoformat()
    }


def load_sync_result(date_str: str = None, workspace: str = None) -> Optional[Dict]:
    """
    加载同步结果
    
    Args:
        date_str: 日期字符串
        workspace: 工作目录
    
    Returns:
        同步结果字典，如果不存在返回None
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    result_path = os.path.join(workspace, ".sync_results", f"{date_str}.json")
    
    if not os.path.exists(result_path):
        return None
    
    with open(result_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_sync_result(result: Dict, workspace: str = None):
    """
    保存同步结果
    
    Args:
        result: 同步结果字典
        workspace: 工作目录
    """
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    results_dir = os.path.join(workspace, ".sync_results")
    os.makedirs(results_dir, exist_ok=True)
    
    date_str = result.get("date", datetime.now().strftime("%Y-%m-%d"))
    result_path = os.path.join(results_dir, f"{date_str}.json")
    
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 测试
    try:
        result = sync_daily_report("2026-04-09")
        print(f"同步成功: {result}")
        save_sync_result(result)
    except Exception as e:
        print(f"同步失败: {e}")
