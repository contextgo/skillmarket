#!/usr/bin/env python3
"""
AI新闻收集模块
多维度分层搜索，覆盖周报、社区、产品、融资、研究、监管6个维度
"""

import json
import os
from datetime import datetime
from typing import List, Dict
import hashlib

# 搜索维度配置
SEARCH_DIMENSIONS = {
    "weekly": ["AI weekly roundup", "AI周报", "AI weekly digest"],
    "community": ["viral AI tool", "trending AI", "AI社区热度", "GitHub trending AI"],
    "product": ["AI model release", "LLM launch", "AI产品发布", "new AI feature"],
    "funding": ["AI startup funding", "AI融资", "AI investment", "venture capital AI"],
    "research": ["AI breakthrough", "AI paper", "AI研究", "arXiv AI"],
    "regulation": ["AI regulation", "AI policy", "AI监管", "AI governance"]
}

# 新闻源黑名单
SOURCE_BLACKLIST = ["zhihu.com", "知乎"]

# 热度评分标准
HOTNESS_CRITERIA = {
    5: "重大发布/行业里程碑/顶级公司战略级产品",
    4: "重要融资/知名公司动态/技术突破",
    3: "产品更新/中等规模融资/行业趋势",
    2: "小众工具/早期融资/技术讨论",
    1: "一般资讯/观点文章"
}


def calculate_hotness(news_item: Dict) -> int:
    """
    根据多维度计算新闻热度
    返回1-5的整数评分
    """
    score = 1
    title = news_item.get("title", "").lower()
    summary = news_item.get("summary", "").lower()
    text = title + " " + summary
    
    # 重大发布指标
    major_keywords = ["发布", "launch", "release", "开源", "open source", "突破", "breakthrough"]
    if any(k in text for k in major_keywords):
        score += 1
    
    # 顶级公司
    top_companies = ["openai", "google", "anthropic", "meta", "microsoft", "deepseek", "智谱", "claude", "gpt"]
    if any(c in text for c in top_companies):
        score += 1
    
    # 融资规模
    funding_keywords = ["billion", "亿", "融资", "funding", "investment"]
    if any(k in text for k in funding_keywords):
        score += 1
    
    # 社区热度
    viral_keywords = ["viral", "trending", "热门", "爆款", "病毒式"]
    if any(k in text for k in viral_keywords):
        score += 1
    
    return min(score, 5)


def validate_source(url: str, source_name: str) -> bool:
    """验证新闻源是否在黑名单中"""
    for blacklisted in SOURCE_BLACKLIST:
        if blacklisted in url or blacklisted in source_name:
            return False
    return True


def format_news_for_json(news_items: List[Dict]) -> List[Dict]:
    """
    格式化新闻为JSON结构
    处理中文引号等特殊字符
    """
    formatted = []
    for item in news_items:
        # 处理中文引号，避免JSON格式错误
        title = item.get("title", "").replace('"', '「').replace('"', '」')
        summary = item.get("summary", "").replace('"', '「').replace('"', '」')
        
        formatted.append({
            "title": title,
            "summary": summary,
            "category": item.get("category", "资讯"),
            "hotness": item.get("hotness", 3),
            "source": item.get("source", ""),
            "url": item.get("url", ""),
            "timestamp": item.get("timestamp", datetime.now().isoformat())
        })
    
    # 按热度排序
    formatted.sort(key=lambda x: x["hotness"], reverse=True)
    return formatted


def save_news(news_items: List[Dict], date_str: str = None, workspace: str = None) -> str:
    """
    保存新闻到JSON文件
    
    Args:
        news_items: 新闻列表
        date_str: 日期字符串，默认今天
        workspace: 工作目录，默认从环境变量或当前目录
    
    Returns:
        保存的文件路径
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    # 确保目录存在
    raw_news_dir = os.path.join(workspace, "raw-news")
    os.makedirs(raw_news_dir, exist_ok=True)
    
    # 格式化并保存
    formatted_news = format_news_for_json(news_items)
    
    output_path = os.path.join(raw_news_dir, f"{date_str}.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(formatted_news, f, ensure_ascii=False, indent=2)
    
    return output_path


def load_news(date_str: str = None, workspace: str = None) -> List[Dict]:
    """
    从JSON文件加载新闻
    
    Args:
        date_str: 日期字符串，默认今天
        workspace: 工作目录
    
    Returns:
        新闻列表
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    news_path = os.path.join(workspace, "raw-news", f"{date_str}.json")
    
    if not os.path.exists(news_path):
        return []
    
    with open(news_path, "r", encoding="utf-8") as f:
        return json.load(f)


if __name__ == "__main__":
    # 测试代码
    test_news = [
        {
            "title": "智谱发布GLM-5.1",
            "summary": "全球最强开源模型，支持8小时持续工作",
            "category": "产品发布",
            "source": "官方公告",
            "url": "https://example.com"
        }
    ]
    
    # 计算热度
    for item in test_news:
        item["hotness"] = calculate_hotness(item)
    
    # 保存
    path = save_news(test_news)
    print(f"测试新闻已保存到: {path}")
