#!/usr/bin/env python3
"""
AI日报卡片生成模块
使用Playwright + html-to-image生成PNG图片
"""

import os
import json
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

# 默认配置
DEFAULT_CONFIG = {
    "news_count": 8,
    "image_width": 1080,
    "image_height": 1920,
    "viewport_width": 540,
    "template": "style6-yunyinghui.html"
}

# 农历数据（简化版）
LUNAR_MONTHS = ["正月", "二月", "三月", "四月", "五月", "六月", 
                "七月", "八月", "九月", "十月", "冬月", "腊月"]
LUNAR_DAYS = ["初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十",
              "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十",
              "廿一", "廿二", "廿三", "廿四", "廿五", "廿六", "廿七", "廿八", "廿九", "三十"]


def get_lunar_date(date_obj: datetime) -> str:
    """
    获取农历日期（简化实现）
    实际使用时可接入lunarcalendar库
    """
    try:
        from lunarcalendar import Converter, Solar
        solar = Solar(date_obj.year, date_obj.month, date_obj.day)
        lunar = Converter.Solar2Lunar(solar)
        return f"{LUNAR_MONTHS[lunar.month - 1]}{LUNAR_DAYS[lunar.day - 1]}"
    except ImportError:
        # 简化回退：根据日期哈希选择一个农历日期
        day_hash = (date_obj.year + date_obj.month + date_obj.day) % 12
        return LUNAR_MONTHS[day_hash]


def get_daily_quote(date_obj: datetime) -> str:
    """
    获取每日一言
    使用日期哈希确定性选取，确保每天固定
    """
    quotes = [
        "AI不会取代人类，但会用AI的人会取代不会用AI的人。",
        "未来已来，只是分布不均。",
        "工具越智能，思考越重要。",
        "预测未来的最好方式就是创造它。",
        "在AI时代，提问比回答更有价值。",
        "技术本身没有善恶，关键在于使用技术的人。",
        "人工智能是人类智慧的放大器。",
        "拥抱变化，才能成为时代的弄潮儿。",
        "学习AI不是选择，而是必然。",
        "数据是新时代的石油，AI是提炼厂。",
        "算法没有灵魂，但创造者可以有。",
        "AI让不可能变为可能，让可能变为简单。",
        "智能时代，终身学习是唯一的不变。",
        "与其担心AI取代工作，不如让AI为你工作。",
        "创新不是天赋，而是方法。"
    ]
    
    # 使用日期哈希确定性选择
    date_hash = (date_obj.year * 366 + date_obj.month * 31 + date_obj.day) % len(quotes)
    return quotes[date_hash]


def build_news_html(news_items: List[Dict], max_count: int = 8) -> str:
    """
    构建新闻HTML片段
    
    Args:
        news_items: 新闻列表
        max_count: 最大新闻数量
    
    Returns:
        HTML字符串
    """
    html_parts = []
    
    for idx, item in enumerate(news_items[:max_count], 1):
        title = item.get("title", "")
        summary = item.get("summary", "")
        category = item.get("category", "资讯")
        
        news_html = f'''
        <div class="news-item">
            <div class="news-index">{idx:02d}</div>
            <div class="news-content">
                <div class="news-title">{title}</div>
                <div class="news-meta">{category} · {summary}</div>
            </div>
        </div>
        '''
        html_parts.append(news_html)
    
    return "\n".join(html_parts)


def generate_html_template(news_items: List[Dict], date_obj: datetime, 
                          workspace: str, config: Dict = None) -> str:
    """
    生成完整的HTML模板
    
    Args:
        news_items: 新闻列表
        date_obj: 日期对象
        workspace: 工作目录
        config: 配置字典
    
    Returns:
        完整HTML字符串
    """
    if config is None:
        config = DEFAULT_CONFIG
    
    # 读取模板文件
    template_path = os.path.join(workspace, "templates", config["template"])
    
    # 如果模板不存在，使用内嵌模板
    if not os.path.exists(template_path):
        template = get_default_template()
    else:
        with open(template_path, "r", encoding="utf-8") as f:
            template = f.read()
    
    # 准备替换变量
    date_str = date_obj.strftime("%Y-%m-%d")
    weekday = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][date_obj.weekday()]
    lunar = get_lunar_date(date_obj)
    quote = get_daily_quote(date_obj)
    
    # 构建新闻HTML
    news_html = build_news_html(news_items, config["news_count"])
    
    # 替换占位符
    template = template.replace("{{DATE}}", date_str)
    template = template.replace("{{WEEKDAY}}", weekday)
    template = template.replace("{{LUNAR_DATE}}", lunar)
    template = template.replace("{{QUOTE}}", quote)
    template = template.replace("{{NEWS_ITEMS}}", news_html)
    
    return template


def get_default_template() -> str:
    """
    获取默认HTML模板
    """
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width={{VIEWPORT_WIDTH}}, initial-scale=1.0">
    <title>云鹰汇AI日报 {{DATE}}</title>
    <script src="https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.min.js"></script>
    <style>
        :root {
            --header-bg: #0f172a;
            --midnight-blue: #1e3a8a;
            --eagle-orange: #f97316;
            --warm-white: #fff8f0;
            --eagle-light: #fb923c;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: var(--warm-white);
            color: #1e293b;
        }
        
        .container {
            width: {{IMAGE_WIDTH}}px;
            min-height: {{IMAGE_HEIGHT}}px;
            margin: 0 auto;
            background: var(--warm-white);
            position: relative;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, var(--header-bg) 0%, var(--midnight-blue) 100%);
            padding: 60px 40px;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--eagle-orange), transparent);
        }
        
        .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
        }
        
        .date-info {
            color: white;
        }
        
        .date-main {
            font-size: 48px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .date-sub {
            font-size: 24px;
            opacity: 0.8;
        }
        
        /* News Section */
        .news-section {
            padding: 40px;
        }
        
        .news-item {
            display: flex;
            gap: 20px;
            margin-bottom: 24px;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        
        .news-index {
            width: 40px;
            height: 40px;
            background: var(--eagle-orange);
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 16px;
            flex-shrink: 0;
        }
        
        .news-content {
            flex: 1;
        }
        
        .news-title {
            font-size: 26px;
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 8px;
            line-height: 1.4;
        }
        
        .news-meta {
            font-size: 20px;
            color: #64748b;
            line-height: 1.5;
        }
        
        /* Quote Section */
        .quote-section {
            padding: 40px;
            background: linear-gradient(135deg, #fef3e2 0%, #fff8f0 100%);
            margin: 0 40px 40px;
            border-radius: 16px;
            border-left: 4px solid var(--eagle-orange);
        }
        
        .quote-text {
            font-size: 24px;
            color: #475569;
            font-style: italic;
            line-height: 1.6;
        }
        
        /* Footer */
        .footer {
            background: var(--header-bg);
            padding: 30px 40px;
            text-align: center;
            color: white;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class="container" id="capture">
        <header class="header">
            <div class="date-info">
                <div class="date-main">{{DATE}} {{WEEKDAY}}</div>
                <div class="date-sub">农历 {{LUNAR_DATE}}</div>
            </div>
        </header>
        
        <section class="news-section">
            {{NEWS_ITEMS}}
        </section>
        
        <section class="quote-section">
            <p class="quote-text">「{{QUOTE}}」</p>
        </section>
        
        <footer class="footer">
            云鹰汇 · AI资讯日报
        </footer>
    </div>
</body>
</html>'''


def generate_card(date_str: str = None, workspace: str = None, 
                 config: Dict = None) -> str:
    """
    生成日报卡片图片
    
    Args:
        date_str: 日期字符串，默认今天
        workspace: 工作目录
        config: 配置字典
    
    Returns:
        生成的图片路径
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    if workspace is None:
        workspace = os.environ.get("DAILY_REPORT_WORKSPACE", "/Users/chengdong/WorkBuddy/云鹰汇日报")
    
    if config is None:
        config = DEFAULT_CONFIG
    
    # 解析日期
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")
    
    # 加载新闻
    from .collect_news import load_news
    news_items = load_news(date_str, workspace)
    
    if not news_items:
        raise ValueError(f"没有找到 {date_str} 的新闻数据")
    
    # 生成HTML
    html_content = generate_html_template(news_items, date_obj, workspace, config)
    
    # 替换模板中的尺寸变量
    html_content = html_content.replace("{{IMAGE_WIDTH}}", str(config["image_width"]))
    html_content = html_content.replace("{{IMAGE_HEIGHT}}", str(config["image_height"]))
    html_content = html_content.replace("{{VIEWPORT_WIDTH}}", str(config["viewport_width"]))
    
    # 保存HTML临时文件
    temp_html_path = os.path.join(workspace, f"temp_{date_str}.html")
    with open(temp_html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    
    # 使用Playwright生成图片
    output_path = os.path.join(workspace, f"{date_str}.png")
    _render_with_playwright(temp_html_path, output_path, config)
    
    # 清理临时文件
    os.remove(temp_html_path)
    
    return output_path


def _render_with_playwright(html_path: str, output_path: str, config: Dict):
    """
    使用Playwright渲染HTML为PNG
    """
    import subprocess
    
    script = f'''
const {{ chromium }} = require('playwright');
const htmlToImage = require('html-to-image');

(async () => {{
    const browser = await chromium.launch();
    const page = await browser.newPage({{
        viewport: {{ width: {config["viewport_width"]}, height: 100 }}
    }});
    
    await page.goto('file://{html_path}');
    await page.waitForLoadState('networkidle');
    
    // 等待html-to-image库加载
    await page.waitForFunction(() => typeof htmlToImage !== 'undefined');
    
    // 获取元素并渲染
    const element = await page.$('#capture');
    const dataUrl = await element.evaluate((el) => {{
        return htmlToImage.toPng(el, {{ pixelRatio: 2 }});
    }});
    
    // 保存图片
    const fs = require('fs');
    const base64Data = dataUrl.replace(/^data:image\\/png;base64,/, '');
    fs.writeFileSync('{output_path}', base64Data, 'base64');
    
    await browser.close();
}})();
'''
    
    # 保存并执行Node脚本
    js_path = html_path.replace('.html', '.js')
    with open(js_path, 'w') as f:
        f.write(script)
    
    try:
        subprocess.run(['node', js_path], check=True, capture_output=True)
    finally:
        if os.path.exists(js_path):
            os.remove(js_path)


if __name__ == "__main__":
    # 测试
    test_news = [
        {"title": "测试新闻1", "summary": "这是摘要", "category": "测试", "hotness": 5},
        {"title": "测试新闻2", "summary": "这是摘要2", "category": "测试", "hotness": 4},
    ]
    
    from collect_news import save_news
    save_news(test_news, "2026-04-09")
    
    path = generate_card("2026-04-09")
    print(f"卡片已生成: {path}")
