#!/usr/bin/env python3
"""
AI日报生成技能 - 命令行入口

使用方法:
    python -m ai_daily_report generate [--date YYYY-MM-DD]
    python -m ai_daily_report collect [--date YYYY-MM-DD]
    python -m ai_daily_report card [--date YYYY-MM-DD]
    python -m ai_daily_report sync [--date YYYY-MM-DD]
"""

import argparse
import sys
import os
from datetime import datetime

# 添加技能目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai_daily_report.scripts.collect_news import save_news, load_news
from ai_daily_report.scripts.generate_card import generate_card
from ai_daily_report.scripts.sync_ima import sync_daily_report, save_sync_result


def get_workspace() -> str:
    """获取工作目录"""
    return os.environ.get(
        "DAILY_REPORT_WORKSPACE",
        "/Users/chengdong/WorkBuddy/云鹰汇日报"
    )


def cmd_generate(args):
    """执行完整生成流程"""
    date_str = args.date or datetime.now().strftime("%Y-%m-%d")
    workspace = get_workspace()
    
    print(f"🚀 开始生成AI日报: {date_str}")
    print("=" * 50)
    
    # 1. 检查新闻数据
    print("\n📰 步骤1: 检查新闻数据...")
    news_items = load_news(date_str, workspace)
    
    if not news_items:
        print(f"❌ 错误: 没有找到 {date_str} 的新闻数据")
        print(f"   请先运行: python -m ai_daily_report collect --date {date_str}")
        return 1
    
    print(f"✅ 找到 {len(news_items)} 条新闻")
    
    # 2. 生成卡片
    print("\n🎨 步骤2: 生成日报卡片...")
    try:
        card_path = generate_card(date_str, workspace)
        print(f"✅ 卡片已生成: {card_path}")
    except Exception as e:
        print(f"❌ 卡片生成失败: {e}")
        return 1
    
    # 3. 同步到IMA
    print("\n☁️ 步骤3: 同步到IMA知识库...")
    try:
        result = sync_daily_report(date_str, workspace)
        save_sync_result(result, workspace)
        print(f"✅ 同步成功!")
        print(f"   CDN URL: {result.get('cdn_url', 'N/A')}")
    except Exception as e:
        print(f"❌ 同步失败: {e}")
        return 1
    
    print("\n" + "=" * 50)
    print(f"🎉 日报生成完成!")
    print(f"   日期: {date_str}")
    print(f"   图片: {card_path}")
    print(f"   CDN:  {result.get('cdn_url', 'N/A')}")
    
    return 0


def cmd_collect(args):
    """收集新闻（占位，实际需配合AI搜索）"""
    print("📰 新闻收集")
    print("=" * 50)
    print()
    print("此步骤需要AI进行多维度搜索，请使用以下提示词:")
    print()
    print("---")
    print("你是一个AI新闻收集助手。请执行以下任务:")
    print()
    print("1. 使用web_search进行多维度分层搜索（至少8次）:")
    print("   - A. 周报聚合: AI weekly roundup April 2026")
    print("   - B. 社区热度: viral AI tool trending this week")
    print("   - C. 产品发布: AI model release LLM launch")
    print("   - D. 融资新闻: AI startup funding April 2026")
    print("   - E. 研究论文: AI breakthrough paper April 2026")
    print("   - F. 监管动态: AI regulation policy April 2026")
    print()
    print("2. 收集15-25条新闻，按热度1-5星排序")
    print("3. 避免知乎等黑名单来源")
    print("4. 保存到JSON格式")
    print("---")
    print()
    print(f"目标文件: {get_workspace()}/raw-news/{args.date or 'YYYY-MM-DD'}.json")
    
    return 0


def cmd_card(args):
    """生成日报卡片"""
    date_str = args.date or datetime.now().strftime("%Y-%m-%d")
    workspace = get_workspace()
    
    print(f"🎨 生成日报卡片: {date_str}")
    print("=" * 50)
    
    try:
        card_path = generate_card(date_str, workspace)
        print(f"✅ 卡片已生成: {card_path}")
        return 0
    except Exception as e:
        print(f"❌ 生成失败: {e}")
        return 1


def cmd_sync(args):
    """同步到IMA"""
    date_str = args.date or datetime.now().strftime("%Y-%m-%d")
    workspace = get_workspace()
    
    print(f"☁️ 同步到IMA: {date_str}")
    print("=" * 50)
    
    try:
        result = sync_daily_report(date_str, workspace)
        save_sync_result(result, workspace)
        print(f"✅ 同步成功!")
        print(f"   CDN URL: {result.get('cdn_url', 'N/A')}")
        return 0
    except Exception as e:
        print(f"❌ 同步失败: {e}")
        return 1


def main():
    parser = argparse.ArgumentParser(
        prog="ai_daily_report",
        description="AI日报生成工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 完整流程（一键生成）
  python -m ai_daily_report generate
  
  # 生成指定日期日报
  python -m ai_daily_report generate --date 2026-04-09
  
  # 分步执行
  python -m ai_daily_report collect   # 收集新闻
  python -m ai_daily_report card      # 生成卡片
  python -m ai_daily_report sync      # 同步IMA
        """
    )
    
    parser.add_argument(
        "--date",
        help="指定日期 (YYYY-MM-DD格式)，默认今天"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # generate 命令
    gen_parser = subparsers.add_parser("generate", help="执行完整生成流程")
    gen_parser.set_defaults(func=cmd_generate)
    
    # collect 命令
    collect_parser = subparsers.add_parser("collect", help="收集新闻（需AI配合）")
    collect_parser.set_defaults(func=cmd_collect)
    
    # card 命令
    card_parser = subparsers.add_parser("card", help="生成日报卡片")
    card_parser.set_defaults(func=cmd_card)
    
    # sync 命令
    sync_parser = subparsers.add_parser("sync", help="同步到IMA知识库")
    sync_parser.set_defaults(func=cmd_sync)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
