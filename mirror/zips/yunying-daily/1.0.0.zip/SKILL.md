---
name: yunying-daily
description: 自动化生成AI资讯日报。触发词：生成AI日报、AI日报、今日AI资讯、run daily report。功能：收集AI新闻、生成精美日报卡片、同步到IMA知识库。适用于：AI自媒体、行业观察、每日资讯推送。
---

# AI日报生成技能 (ai-daily-report)

自动化生成AI资讯日报，包括新闻收集、卡片生成、IMA同步。

## 功能特点

- 🤖 **智能新闻收集**：多维度分层搜索，覆盖产品发布、融资、研究、监管等6大维度
- 🎨 **精美卡片生成**：自动生成1080×1920px竖版日报图片，适合手机阅读和社交媒体分享
- ☁️ **IMA知识库同步**：自动上传图片到IMA知识库，获取CDN链接
- ⚙️ **高度可配置**：支持自定义新闻数量、模板样式、知识库ID等
- 🔧 **模块化设计**：新闻收集、卡片生成、IMA同步三个模块可独立使用

## 使用方法

### 完整流程（一键生成）

```bash
# 生成今日日报
python -m ai_daily_report generate

# 生成指定日期日报
python -m ai_daily_report generate --date 2026-04-09
```

### 分步执行

```bash
# 1. 收集新闻（需配合AI搜索）
python -m ai_daily_report collect --date 2026-04-09

# 2. 生成卡片
python -m ai_daily_report card --date 2026-04-09

# 3. 同步到IMA
python -m ai_daily_report sync --date 2026-04-09
```

## 安装

### 方式1：手动安装

```bash
# 克隆到WorkBuddy技能目录
git clone https://github.com/yourname/ai-daily-report ~/.workbuddy/skills/ai-daily-report

# 安装依赖
pip install playwright lunarcalendar cos-python-sdk-v5
playwright install chromium
```

### 方式2：通过SkillHub安装（推荐）

```bash
skillhub install ai-daily-report
```

## 配置

创建配置文件 `~/.workbuddy/skills/ai-daily-report/config/config.json`：

```json
{
  "news_count": 8,
  "image_width": 1080,
  "image_height": 1920,
  "viewport_width": 540,
  "template": "style6-yunyinghui.html",
  "ima_kb_id": "your-knowledge-base-id",
  "sources": {
    "enabled": ["csdn", "qbitai", "36kr", "jiqizhixin"],
    "blacklist": ["zhihu"]
  }
}
```

### 环境变量

```bash
# IMA API凭证（必需）
export IMA_OPENAPI_CLIENTID="your-client-id"
export IMA_OPENAPI_APIKEY="your-api-key"

# 工作目录（可选，默认当前目录）
export DAILY_REPORT_WORKSPACE="/path/to/workspace"
```

## 输出

- 📄 新闻JSON：`{workspace}/raw-news/YYYY-MM-DD.json`
- 🖼️ 日报图片：`{workspace}/YYYY-MM-DD.png`
- ☁️ IMA笔记：自动同步到知识库，返回CDN URL

## 项目结构

```
ai-daily-report/
├── SKILL.md                    # 技能说明文档
├── __init__.py                 # 模块导出
├── __main__.py                 # CLI入口
├── scripts/
│   ├── collect_news.py         # 新闻收集模块
│   ├── generate_card.py        # 卡片生成模块
│   └── sync_ima.py             # IMA同步模块
└── config/                     # 配置目录
```

## 依赖

- Python 3.8+
- Playwright（截图渲染）
- html-to-image（CDN引入，无需安装）
- cos-python-sdk-v5（IMA同步）
- lunarcalendar（农历计算，可选）

## 使用场景

- 🤖 **AI自媒体运营**：每日自动生成AI资讯卡片，发布到公众号/小红书
- 📊 **行业观察**：追踪AI行业动态，生成内部日报
- 💼 **投资研究**：收集AI领域融资、产品发布等商业动态
- 🎓 **知识管理**：同步到IMA知识库，构建个人AI资讯库

## 截图示例

![日报示例](screenshots/example-2026-04-09.png)

## 相关技能

- [ai-news-collectors](https://github.com/yourname/ai-news-collectors) - AI新闻收集技能，可与本技能配合使用

## 许可证

MIT License

## 作者

- GitHub: [@yourname](https://github.com/yourname)
- Email: your.email@example.com
