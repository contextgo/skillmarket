# 使用指南

## 基本用法

### 一键生成日报

```bash
python -m ai_daily_report generate
```

这将执行完整流程：
1. 读取 `raw-news/YYYY-MM-DD.json` 新闻数据
2. 生成日报卡片图片
3. 同步到IMA知识库（如配置）

### 指定日期

```bash
python -m ai_daily_report generate --date 2026-04-09
```

## 分步执行

### 1. 收集新闻

```bash
python -m ai_daily_report collect --date 2026-04-09
```

此命令会输出提示，指导你使用AI进行新闻搜索。

### 2. 生成卡片

```bash
python -m ai_daily_report card --date 2026-04-09
```

### 3. 同步IMA

```bash
python -m ai_daily_report sync --date 2026-04-09
```

## 作为Python模块使用

```python
from ai_daily_report import generate_card, sync_daily_report

# 生成卡片
card_path = generate_card("2026-04-09")
print(f"卡片已生成: {card_path}")

# 同步到IMA
result = sync_daily_report("2026-04-09")
print(f"CDN URL: {result['cdn_url']}")
```

## 自动化任务

配合 WorkBuddy 自动化功能，可设置每日定时生成：

```toml
# ~/.workbuddy/automations/ai-daily-report/automation.toml
name = "每日AI日报"
rrule = "FREQ=DAILY;BYHOUR=8;BYMINUTE=0"
prompt = "执行AI日报生成: python -m ai_daily_report generate"
```
