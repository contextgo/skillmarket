# 配置说明

## 配置文件

创建 `~/.workbuddy/skills/ai-daily-report/config/config.json`：

```json
{
  "news_count": 8,
  "image_width": 1080,
  "image_height": 1920,
  "viewport_width": 540,
  "template": "style6-yunyinghui.html",
  "ima_kb_id": "your-knowledge-base-id",
  "sources": {
    "enabled": ["csdn", "qbitai", "36kr", "jiqizhixin"],
    "blacklist": ["zhihu"]
  }
}
```

## 配置项说明

| 配置项 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `news_count` | int | 8 | 日报显示的新闻数量 |
| `image_width` | int | 1080 | 输出图片宽度（像素） |
| `image_height` | int | 1920 | 输出图片高度（像素） |
| `viewport_width` | int | 540 | 浏览器视口宽度 |
| `template` | string | style6-yunyinghui.html | HTML模板文件名 |
| `ima_kb_id` | string | - | IMA知识库ID |
| `sources.enabled` | array | - | 启用的新闻源 |
| `sources.blacklist` | array | - | 黑名单新闻源 |

## 环境变量

### 必需

```bash
# IMA API凭证
export IMA_OPENAPI_CLIENTID="your-client-id"
export IMA_OPENAPI_APIKEY="your-api-key"
```

### 可选

```bash
# 工作目录（默认当前目录）
export DAILY_REPORT_WORKSPACE="/path/to/workspace"
```

## 自定义模板

1. 复制默认模板：
```bash
cp templates/style6-yunyinghui.html templates/my-template.html
```

2. 修改模板中的CSS样式

3. 在配置中指定新模板：
```json
{
  "template": "my-template.html"
}
```

## 占位符

模板中可使用以下占位符：

- `{{DATE}}` - 日期（2026-04-09）
- `{{WEEKDAY}}` - 星期（周一/周二...）
- `{{LUNAR_DATE}}` - 农历日期
- `{{QUOTE}}` - 每日一言
- `{{NEWS_ITEMS}}` - 新闻列表HTML
