"""
AI日报生成技能
自动化收集AI新闻、生成日报卡片、同步到IMA知识库
"""

__version__ = "1.0.0"
__author__ = "WorkBuddy"

from .scripts.collect_news import (
    calculate_hotness,
    validate_source,
    format_news_for_json,
    save_news,
    load_news
)

from .scripts.generate_card import (
    get_lunar_date,
    get_daily_quote,
    build_news_html,
    generate_card
)

from .scripts.sync_ima import (
    IMAClient,
    sync_daily_report,
    load_sync_result,
    save_sync_result
)

__all__ = [
    # 新闻收集
    "calculate_hotness",
    "validate_source",
    "format_news_for_json",
    "save_news",
    "load_news",
    # 卡片生成
    "get_lunar_date",
    "get_daily_quote",
    "build_news_html",
    "generate_card",
    # IMA同步
    "IMAClient",
    "sync_daily_report",
    "load_sync_result",
    "save_sync_result",
]
