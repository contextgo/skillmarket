# AI日报生成技能 🤖📰

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![WorkBuddy Skill](https://img.shields.io/badge/WorkBuddy-Skill-green.svg)](https://www.codebuddy.cn/)

自动化生成AI资讯日报，从新闻收集到精美卡片，一键完成。

## ✨ 功能特点

| 功能 | 说明 |
|------|------|
| 🔍 **智能收集** | 6维度分层搜索，覆盖产品、融资、研究、监管等 |
| 🎨 **精美卡片** | 1080×1920px竖版设计，适合手机阅读和社交分享 |
| ☁️ **IMA同步** | 自动上传知识库，获取CDN链接 |
| ⚙️ **高度可配** | 自定义数量、模板、样式 |
| 🔧 **模块分离** | 收集/生成/同步可独立使用 |

## 📸 效果预览

![AI日报示例](screenshots/example.png)

*生成的日报卡片示例*

## 🚀 快速开始

### 安装

```bash
# 方式1：SkillHub安装（推荐）
skillhub install ai-daily-report

# 方式2：手动安装
git clone https://github.com/yourname/ai-daily-report ~/.workbuddy/skills/ai-daily-report
cd ~/.workbuddy/skills/ai-daily-report
pip install -r requirements.txt
playwright install chromium
```

### 配置IMA（可选）

如需同步到IMA知识库，配置环境变量：

```bash
export IMA_OPENAPI_CLIENTID="your-client-id"
export IMA_OPENAPI_APIKEY="your-api-key"
```

### 使用

```bash
# 一键生成今日日报
python -m ai_daily_report generate

# 生成指定日期
python -m ai_daily_report generate --date 2026-04-09
```

## 📖 详细文档

- [使用指南](docs/usage.md)
- [配置说明](docs/configuration.md)
- [API文档](docs/api.md)
- [常见问题](docs/faq.md)

## 🏗️ 项目结构

```
ai-daily-report/
├── SKILL.md              # 技能元数据
├── README.md             # 本文件
├── __init__.py           # 模块导出
├── __main__.py           # CLI入口
├── requirements.txt      # 依赖列表
├── scripts/
│   ├── collect_news.py   # 新闻收集
│   ├── generate_card.py  # 卡片生成
│   └── sync_ima.py       # IMA同步
├── config/               # 配置示例
└── docs/                 # 文档
```

## 🔧 进阶用法

### 自定义模板

复制 `templates/style6-yunyinghui.html` 并修改：

```bash
cp templates/style6-yunyinghui.html templates/my-template.html
# 编辑 my-template.html
```

然后在配置中指定：

```json
{
  "template": "my-template.html"
}
```

### 批量生成

```python
from ai_daily_report import generate_card

for date in ["2026-04-01", "2026-04-02", "2026-04-03"]:
    generate_card(date)
```

## 🤝 相关项目

- [ai-news-collectors](https://github.com/yourname/ai-news-collectors) - AI新闻收集技能

## 📄 许可证

[MIT License](LICENSE)

## 🙏 致谢

- [WorkBuddy](https://www.codebuddy.cn/) - AI智能体平台
- [SkillHub](https://skillhub.tencent.com/) - AI技能商店
