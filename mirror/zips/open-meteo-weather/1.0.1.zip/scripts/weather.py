#!/usr/bin/env python3
"""
Open-Meteo 天气查询脚本
支持：地理编码、实时天气、天气预报、历史天气
固定：摄氏度、中文、中国、东八区
"""

import sys
import json
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timedelta


# ── 常量 ──────────────────────────────────────────────
GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

# 天气代码 → 中文描述
WMO_CODES = {
    0: "晴", 1: "大部晴", 2: "多云", 3: "阴",
    45: "雾", 48: "冻雾",
    51: "小毛毛雨", 53: "中毛毛雨", 55: "大毛毛雨",
    56: "冻毛毛雨(小)", 57: "冻毛毛雨(大)",
    61: "小雨", 63: "中雨", 65: "大雨",
    66: "冻雨(小)", 67: "冻雨(大)",
    71: "小雪", 73: "中雪", 75: "大雪",
    77: "雪粒",
    80: "阵雨(小)", 81: "阵雨(中)", 82: "阵雨(大)",
    85: "阵雪(小)", 86: "阵雪(大)",
    95: "雷暴", 96: "雷暴+冰雹(小)", 99: "雷暴+冰雹(大)",
}


# ── 网络请求 ──────────────────────────────────────────
def http_get(url, params):
    """GET 请求，返回 JSON；错误时友好退出"""
    qs = urllib.parse.urlencode(params, doseq=True)
    full_url = f"{url}?{qs}"
    req = urllib.request.Request(full_url, headers={"User-Agent": "open-meteo-weather-skill/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode()
        except Exception:
            pass
        print(f"API 请求失败 (HTTP {e.code}): {body or e.reason}")
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"网络错误: {e.reason}")
        sys.exit(1)

    # 检查 API 返回的业务错误
    if isinstance(data, dict) and data.get("error"):
        reason = data.get("reason", "未知原因")
        print(f"API 返回错误: {reason}")
        sys.exit(1)

    return data


# ── 中国主要城市映射表 ──────────────────────────────────
# Open-Meteo Geocoding 基于 GeoNames，中国地名按拼音索引
# 中文搜索直辖市/省会经常匹配到同名小村庄，所以内置常用城市坐标
MAJOR_CITIES = {
    # 直辖市
    "北京": (39.9075, 116.39723, "北京 · 北京市", "Asia/Shanghai"),
    "上海": (31.23039, 121.47370, "上海 · 上海市", "Asia/Shanghai"),
    "天津": (39.14222, 117.17667, "天津 · 天津市", "Asia/Shanghai"),
    "重庆": (29.56278, 106.55278, "重庆 · 重庆市", "Asia/Shanghai"),
    # 省会
    "合肥": (31.86391, 117.28083, "安徽 · 合肥", "Asia/Shanghai"),
    "福州": (26.06139, 119.30611, "福建 · 福州", "Asia/Shanghai"),
    "兰州": (36.05639, 103.79222, "甘肃 · 兰州", "Asia/Shanghai"),
    "广州": (23.12911, 113.26438, "广东 · 广州", "Asia/Shanghai"),
    "南宁": (22.83333, 108.61667, "广西 · 南宁", "Asia/Shanghai"),
    "贵阳": (26.64700, 106.63022, "贵州 · 贵阳", "Asia/Shanghai"),
    "海口": (20.04422, 110.19989, "海南 · 海口", "Asia/Shanghai"),
    "石家庄": (38.04139, 114.47861, "河北 · 石家庄", "Asia/Shanghai"),
    "郑州": (34.74667, 113.64972, "河南 · 郑州", "Asia/Shanghai"),
    "哈尔滨": (45.75, 126.65, "黑龙江 · 哈尔滨", "Asia/Shanghai"),
    "武汉": (30.58333, 114.26667, "湖北 · 武汉", "Asia/Shanghai"),
    "长沙": (28.19874, 112.97087, "湖南 · 长沙", "Asia/Shanghai"),
    "长春": (43.88, 125.32278, "吉林 · 长春", "Asia/Shanghai"),
    "南京": (32.06026, 118.79688, "江苏 · 南京", "Asia/Shanghai"),
    "南昌": (28.68333, 115.88333, "江西 · 南昌", "Asia/Shanghai"),
    "沈阳": (41.79222, 123.43278, "辽宁 · 沈阳", "Asia/Shanghai"),
    "呼和浩特": (40.81056, 111.65222, "内蒙古 · 呼和浩特", "Asia/Shanghai"),
    "银川": (38.46806, 106.27306, "宁夏 · 银川", "Asia/Shanghai"),
    "西宁": (36.62555, 101.77839, "青海 · 西宁", "Asia/Shanghai"),
    "济南": (36.66833, 116.99722, "山东 · 济南", "Asia/Shanghai"),
    "太原": (37.86944, 112.56028, "山西 · 太原", "Asia/Shanghai"),
    "西安": (34.25833, 108.92861, "陕西 · 西安", "Asia/Shanghai"),
    "成都": (30.57282, 104.06677, "四川 · 成都", "Asia/Shanghai"),
    "拉萨": (29.65, 91.1, "西藏 · 拉萨", "Asia/Shanghai"),
    "乌鲁木齐": (43.80111, 87.58472, "新疆 · 乌鲁木齐", "Asia/Shanghai"),
    "昆明": (25.03889, 102.71833, "云南 · 昆明", "Asia/Shanghai"),
    "杭州": (30.29364, 120.16142, "浙江 · 杭州", "Asia/Shanghai"),
    # 重要城市
    "深圳": (22.54310, 114.05787, "广东 · 深圳", "Asia/Shanghai"),
    "苏州": (31.29889, 120.58528, "江苏 · 苏州", "Asia/Shanghai"),
    "无锡": (31.56889, 120.28861, "江苏 · 无锡", "Asia/Shanghai"),
    "宁波": (29.87819, 121.54945, "浙江 · 宁波", "Asia/Shanghai"),
    "厦门": (24.47979, 118.08941, "福建 · 厦门", "Asia/Shanghai"),
    "青岛": (36.06708, 120.38261, "山东 · 青岛", "Asia/Shanghai"),
    "大连": (38.91222, 121.60222, "辽宁 · 大连", "Asia/Shanghai"),
    "东莞": (23.04889, 113.74472, "广东 · 东莞", "Asia/Shanghai"),
    "佛山": (23.02917, 113.11667, "广东 · 佛山", "Asia/Shanghai"),
    "温州": (28.00035, 120.67217, "浙江 · 温州", "Asia/Shanghai"),
    "珠海": (22.27694, 113.56778, "广东 · 珠海", "Asia/Shanghai"),
    "常州": (31.78333, 119.96667, "江苏 · 常州", "Asia/Shanghai"),
    "绍兴": (30.03278, 120.58056, "浙江 · 绍兴", "Asia/Shanghai"),
    "嘉兴": (30.75278, 120.75194, "浙江 · 嘉兴", "Asia/Shanghai"),
    "金华": (29.07889, 119.64972, "浙江 · 金华", "Asia/Shanghai"),
    "台州": (28.66167, 121.42028, "浙江 · 台州", "Asia/Shanghai"),
    "徐州": (34.26167, 117.18472, "江苏 · 徐州", "Asia/Shanghai"),
    "南通": (31.98028, 120.89417, "江苏 · 南通", "Asia/Shanghai"),
    "泉州": (24.91389, 118.58583, "福建 · 泉州", "Asia/Shanghai"),
    "烟台": (37.46389, 121.44778, "山东 · 烟台", "Asia/Shanghai"),
}


# ── 地理编码 ──────────────────────────────────────────
def _format_display(r):
    """格式化地区显示名"""
    admin_parts = [r.get("admin1", ""), r.get("admin2", ""), r.get("name", "")]
    return " · ".join(p for p in admin_parts if p)


def _geocode_api(name, count=10):
    """调用 Geocoding API，按人口降序返回结果"""
    data = http_get(GEOCODE_URL, {
        "name": name,
        "count": count,
        "language": "zh",
        "countryCode": "CN",
        "format": "json",
    })
    results = data.get("results", [])
    # 按人口降序排序
    results.sort(key=lambda r: r.get("population", 0) or 0, reverse=True)
    return results


def geocode(name):
    """区域名称 → (lat, lon, display_name, timezone)"""
    # 优先查内置映射
    if name in MAJOR_CITIES:
        lat, lon, display, tz = MAJOR_CITIES[name]
        print(f"地区: {display}")
        print(f"纬度: {lat}  经度: {lon}  时区: {tz}")
        return lat, lon, display, tz

    # 走 API
    results = _geocode_api(name)
    if not results:
        # 中文搜索可能匹配不到（GeoNames 按拼音索引），尝试拼音搜索
        pinyin_map = {
            "义乌": "Yiwu", "慈溪": "Cixi", "余姚": "Yuyao", "昆山": "Kunshan",
            "江阴": "Jiangyin", "张家港": "Zhangjiagang", "常熟": "Changshu",
            "太仓": "Taicang", "宜兴": "Yixing", "海宁": "Haining",
            "桐乡": "Tongxiang", "诸暨": "Zhuji", "瑞安": "Rui'an",
            "乐清": "Yueqing", "临海": "Linhai", "龙港": "Longgang",
            "永康": "Yongkang", "温岭": "Wenling", "嵊州": "Shengzhou",
            "平湖": "Pinghu", "建德": "Jiande", "兰溪": "Lanxi",
            "江山": "Jiangshan", "大丰": "Dafeng", "邳州": "Pizhou",
            "兴化": "Xinghua", "高邮": "Gaoyou", "丹阳": "Danyang",
            "扬中": "Yangzhong", "句容": "Jurong", "靖江": "Jingjiang",
            "泰兴": "Taixing", "如皋": "Rugao", "海安": "Hai'an",
        }
        pinyin_name = pinyin_map.get(name)
        if pinyin_name:
            results = _geocode_api(pinyin_name)
        if not results:
            print(f"未找到地区：{name}")
            print(f"提示：部分中文地名在 API 中按拼音索引，可尝试输入拼音（如 Yiwu 代替 义乌）")
            sys.exit(1)

    r = results[0]
    lat = r["latitude"]
    lon = r["longitude"]
    tz = r.get("timezone", "Asia/Shanghai")
    display = _format_display(r)
    pop = r.get("population", 0)

    print(f"地区: {display}")
    print(f"纬度: {lat}  经度: {lon}  时区: {tz}")
    if pop:
        print(f"人口: {pop:,}")

    if len(results) > 1:
        print(f"\n其他匹配结果：")
        for i, alt in enumerate(results[1:6], 2):
            alt_display = _format_display(alt)
            alt_pop = alt.get("population", 0)
            pop_str = f" 人口:{alt_pop:,}" if alt_pop else ""
            print(f"  {i}. {alt_display} (纬度:{alt['latitude']} 经度:{alt['longitude']}{pop_str})")

    return lat, lon, display, tz


def geocode_silent(name):
    """地理编码，只返回坐标，不打印备选项"""
    # 优先查内置映射
    if name in MAJOR_CITIES:
        lat, lon, display, tz = MAJOR_CITIES[name]
        return lat, lon, display, tz

    # 走 API
    results = _geocode_api(name, count=10)
    if not results:
        # 中文搜索可能匹配不到（GeoNames 按拼音索引），尝试拼音搜索
        pinyin_map = {
            "义乌": "Yiwu", "慈溪": "Cixi", "余姚": "Yuyao", "昆山": "Kunshan",
            "江阴": "Jiangyin", "张家港": "Zhangjiagang", "常熟": "Changshu",
            "太仓": "Taicang", "宜兴": "Yixing", "海宁": "Haining",
            "桐乡": "Tongxiang", "诸暨": "Zhuji", "瑞安": "Rui'an",
            "乐清": "Yueqing", "临海": "Linhai", "龙港": "Longgang",
            "永康": "Yongkang", "温岭": "Wenling", "嵊州": "Shengzhou",
            "平湖": "Pinghu", "建德": "Jiande", "兰溪": "Lanxi",
            "江山": "Jiangshan", "大丰": "Dafeng", "邳州": "Pizhou",
            "兴化": "Xinghua", "高邮": "Gaoyou", "丹阳": "Danyang",
            "扬中": "Yangzhong", "句容": "Jurong", "靖江": "Jingjiang",
            "泰兴": "Taixing", "如皋": "Rugao", "海安": "Hai'an",
        }
        pinyin_name = pinyin_map.get(name)
        if pinyin_name:
            results = _geocode_api(pinyin_name, count=10)
        if not results:
            print(f"未找到地区：{name}")
            print(f"提示：部分中文地名在 API 中按拼音索引，可尝试输入拼音（如 Yiwu 代替 义乌）")
            sys.exit(1)

    r = results[0]
    display = _format_display(r)
    return r["latitude"], r["longitude"], display, r.get("timezone", "Asia/Shanghai")


# ── 通用小时级变量 ─────────────────────────────────────
HOURLY_VARS = [
    "temperature_2m",
    "apparent_temperature",
    "precipitation",
    "rain",
    "snowfall",
    "weather_code",
]


# ── 格式化输出 ────────────────────────────────────────
def format_hourly(data, title, tz="Asia/Shanghai"):
    """格式化小时级数据为表格，自动过滤全空数据行"""
    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    temps = hourly.get("temperature_2m", [])
    apparent = hourly.get("apparent_temperature", [])
    precip = hourly.get("precipitation", [])
    rain = hourly.get("rain", [])
    snow = hourly.get("snowfall", [])
    wcodes = hourly.get("weather_code", [])

    if not times:
        print("无数据返回")
        return

    print(f"\n{'时间':<18} {'天气':<8} {'温度°C':>7} {'体感°C':>7} {'降水mm':>7} {'降雨mm':>7} {'降雪cm':>7}")
    print("─" * 76)

    skipped_count = 0
    last_valid_idx = -1

    # 先找到最后一个有效数据的索引（温度不为 None 的最后一个）
    for i in range(len(times) - 1, -1, -1):
        if i < len(temps) and temps[i] is not None:
            last_valid_idx = i
            break

    for i, t in enumerate(times):
        # 停止输出：如果温度为 None 且已经过了有效数据区
        tmp_val = temps[i] if i < len(temps) else None
        if tmp_val is None and i > last_valid_idx:
            skipped_count += 1
            continue

        # 格式化时间
        dt_str = t.replace("T", " ") if "T" in t else t
        wc = wcodes[i] if i < len(wcodes) else None
        weather = WMO_CODES.get(wc, "未知") if wc is not None else "--"
        tmp = f"{tmp_val:.1f}" if tmp_val is not None else "-"
        app_val = apparent[i] if i < len(apparent) else None
        app = f"{app_val:.1f}" if app_val is not None else "-"
        prec_val = precip[i] if i < len(precip) else None
        prec = f"{prec_val:.1f}" if prec_val is not None else "-"
        rn_val = rain[i] if i < len(rain) else None
        rn = f"{rn_val:.1f}" if rn_val is not None else "-"
        sn_val = snow[i] if i < len(snow) else None
        sn = f"{sn_val:.1f}" if sn_val is not None else "-"

        print(f"{dt_str:<18} {weather:<8} {tmp:>7} {app:>7} {prec:>7} {rn:>7} {sn:>7}")

    if skipped_count > 0:
        print(f"\n（{skipped_count} 个小时数据暂缺，已省略）")


# ── 实时天气 ──────────────────────────────────────────
def cmd_current(location):
    """查询实时天气（过去24h + 当前 + 未来几小时）"""
    lat, lon, display, tz = geocode_silent(location)
    print(f"\n📍 {display} 实时天气")
    print(f"坐标: {lat}, {lon}")

    data = http_get(FORECAST_URL, {
        "latitude": lat,
        "longitude": lon,
        "hourly": ",".join(HOURLY_VARS),
        "timezone": "Asia/Shanghai",
        "past_days": 1,
        "forecast_days": 2,
        "temperature_unit": "celsius",
        "precipitation_unit": "mm",
    })

    # 只保留最近 25 小时（过去24h + 当前）到未来几小时
    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    now = datetime.now()
    cutoff = now - timedelta(hours=25)

    start_idx = 0
    for i, v in enumerate(times):
        dt = datetime.fromisoformat(v)
        if dt >= cutoff:
            start_idx = i
            break

    filtered = {"hourly": {}}
    for key in hourly:
        filtered["hourly"][key] = hourly[key][start_idx:]

    format_hourly(filtered, "实时天气", tz)


# ── 天气预报 ──────────────────────────────────────────
def cmd_forecast(location, days=7):
    """查询未来 N 天预报（CMA GRAPES 模型，失败回退 Best Match）"""
    lat, lon, display, tz = geocode_silent(location)
    print(f"\n📍 {display} 未来 {days} 天预报")
    print(f"坐标: {lat}, {lon}")

    # 先尝试 CMA GRAPES 模型
    try:
        data = http_get(FORECAST_URL, {
            "latitude": lat,
            "longitude": lon,
            "hourly": ",".join(HOURLY_VARS),
            "timezone": "Asia/Shanghai",
            "forecast_days": days,
            "models": "cma_grapes_global",
            "temperature_unit": "celsius",
            "precipitation_unit": "mm",
        })

        # 检查有效数据量：如果超过一半的数据行温度为 None，说明 CMA 断档
        hourly = data.get("hourly", {})
        temps = hourly.get("temperature_2m", [])
        total = len(temps)
        null_count = sum(1 for t in temps if t is None)

        if total > 0 and null_count / total > 0.3:
            print("（CMA 模型数据不足，已回退到 Best Match 模型）")
            raise RuntimeError("CMA data insufficient")

        print("（数据源：CMA GRAPES 全球模型）")
        format_hourly(data, "天气预报", tz)

    except (RuntimeError, SystemExit):
        # SystemExit 来自 http_get 的错误处理，这里只捕获 RuntimeError
        # 回退到 Best Match 模型（不指定 models 参数）
        data = http_get(FORECAST_URL, {
            "latitude": lat,
            "longitude": lon,
            "hourly": ",".join(HOURLY_VARS),
            "timezone": "Asia/Shanghai",
            "forecast_days": days,
            "temperature_unit": "celsius",
            "precipitation_unit": "mm",
        })
        print("（数据源：Best Match 综合模型）")
        format_hourly(data, "天气预报", tz)


# ── 历史天气 ──────────────────────────────────────────
def cmd_history(location, start_date, end_date):
    """查询历史天气"""
    lat, lon, display, tz = geocode_silent(location)

    # 检查日期是否在未来
    today = datetime.now().strftime("%Y-%m-%d")
    if start_date > today:
        print(f"⚠️  {start_date} 是未来日期，历史天气 API 不支持查询未来数据。")
        print(f"   如需查看未来天气，请使用: python3 weather.py forecast {location}")
        return
    if end_date > today:
        print(f"⚠️  结束日期 {end_date} 超过今天，将自动截断到 {today}")
        end_date = today

    print(f"\n📍 {display} 历史天气 ({start_date} ~ {end_date})")
    print(f"坐标: {lat}, {lon}")

    data = http_get(ARCHIVE_URL, {
        "latitude": lat,
        "longitude": lon,
        "hourly": ",".join(HOURLY_VARS),
        "timezone": "Asia/Shanghai",
        "start_date": start_date,
        "end_date": end_date,
        "temperature_unit": "celsius",
        "precipitation_unit": "mm",
    })

    format_hourly(data, "历史天气", tz)


# ── 入口 ──────────────────────────────────────────────
USAGE = """
Open-Meteo 天气查询（中国地区专用）

用法:
  python3 weather.py geocode  <地区名称>
  python3 weather.py current  <地区名称>
  python3 weather.py forecast <地区名称> [天数(1-10, 默认7)]
  python3 weather.py history  <地区名称> <开始日期> <结束日期>

示例:
  python3 weather.py geocode 宁波
  python3 weather.py current 宁波
  python3 weather.py forecast 上海 3
  python3 weather.py history 北京 2025-01-01 2025-01-07
"""


def main():
    if len(sys.argv) < 3:
        print(USAGE)
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "geocode":
        geocode(sys.argv[2])

    elif cmd == "current":
        cmd_current(sys.argv[2])

    elif cmd == "forecast":
        days = int(sys.argv[3]) if len(sys.argv) > 3 else 7
        days = max(1, min(10, days))
        cmd_forecast(sys.argv[2], days)

    elif cmd == "history":
        if len(sys.argv) < 5:
            print("历史天气需要：地区名称 开始日期 结束日期")
            print("示例: python3 weather.py history 宁波 2026-04-20 2026-04-27")
            sys.exit(1)
        cmd_history(sys.argv[2], sys.argv[3], sys.argv[4])

    else:
        print(f"未知命令：{cmd}")
        print(USAGE)
        sys.exit(1)


if __name__ == "__main__":
    main()
