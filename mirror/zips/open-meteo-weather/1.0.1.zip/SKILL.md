---
name: open-meteo-weather
description: 查询中国地区天气信息，包括实时天气、未来预报、历史天气。支持小时级温度、体感温度、降雨/雪情况。使用 Open-Meteo API 实现。当用户询问天气、气温、降雨、降雪、体感温度、历史天气、天气预报时触发此 skill。也适用于用户提到"今天天气"、"明天会不会下雨"、"上周天气"、"某地气温"等场景。
---

# Open-Meteo 天气查询

基于 Open-Meteo 免费 API 的中国地区天气查询工具，覆盖实时、预报、历史三大场景。

## 核心能力

1. **地理编码** — 区域名称逆解析为经纬度坐标（Geocoding API）
2. **实时天气** — 当前小时及过去数小时的天气状况（Forecast API）
3. **天气预报** — 未来最多 10 天的小时级预报（CMA GRAPES 模型）
4. **历史天气** — 1940 年至今的历史气象数据（Archive API）

## 固定参数

- 温度单位：摄氏度（celsius）
- 语言：中文（zh）
- 国家：中国（countryCode=CN）
- 时区：Asia/Shanghai（东八区）

## 使用方式

运行脚本 `scripts/weather.py`，通过子命令执行不同查询：

### 1. 地理编码 — 区域名称 → 经纬度

```bash
python3 scripts/weather.py geocode <地区名称>
```

示例：
```bash
python3 scripts/weather.py geocode 宁波
python3 scripts/weather.py geocode 北京
```

返回该地区的 latitude、longitude、timezone 等信息。

### 2. 实时天气 — 当前小时 + 过去 24 小时

```bash
python3 scripts/weather.py current <地区名称>
```

自动先 geocode 再查询，输出小时级温度、体感温度、降水/降雪量。

### 3. 天气预报 — 未来 N 天

```bash
python3 scripts/weather.py forecast <地区名称> [天数]
```

天数默认 7，最大 10。使用 CMA GRAPES 全球模型。

示例：
```bash
python3 scripts/weather.py forecast 宁波 3
python3 scripts/weather.py forecast 上海
```

### 4. 历史天气 — 指定日期范围

```bash
python3 scripts/weather.py history <地区名称> <开始日期> <结束日期>
```

日期格式：YYYY-MM-DD

示例：
```bash
python3 scripts/weather.py history 宁波 2026-04-20 2026-04-27
python3 scripts/weather.py history 北京 2025-01-01 2025-01-07
```

## 输出格式

所有查询结果以中文表格形式输出，包含以下字段：

| 字段 | 说明 |
|------|------|
| 时间 | 日期+小时（东八区） |
| 温度(°C) | 2米高度气温 |
| 体感温度(°C) | 考虑风寒、湿度、辐射的体感温度 |
| 降水(mm) | 当小时总降水量 |
| 降雨(mm) | 液态降水 |
| 降雪(cm) | 降雪量 |

## API 端点

| 功能 | 端点 |
|------|------|
| 地理编码 | `https://geocoding-api.open-meteo.com/v1/search` |
| 天气预报（含实时） | `https://api.open-meteo.com/v1/forecast` |
| 历史天气 | `https://archive-api.open-meteo.com/v1/archive` |

## 注意事项

- Open-Meteo 免费版无需 API Key，有速率限制（合理使用不会触发）
- CMA 模型数据近期可能因 CMA 开放数据服务过载而出现延迟，此时预报会回退到默认 Best Match 模型
- 历史天气数据最近 5 天可能有延迟（ERA5 模型特性），更近的数据使用 IFS 模型
- 地理编码固定过滤 countryCode=CN，如需其他国家请在脚本中修改
- 降雪量单位为 cm（Open-Meteo 原始单位），降水量和降雨量单位为 mm

## 常见查询场景

| 用户说法 | 推荐命令 |
|----------|----------|
| "今天宁波天气怎么样" | `current 宁波` |
| "明天会下雨吗" | `forecast <地区> 2` |
| "这周天气怎么样" | `forecast <地区> 7` |
| "上周天气" | `history <地区> <上周一> <上周日>` |
| "某地经纬度" | `geocode <地区>` |
| "去年元旦天气" | `history <地区> 2025-01-01 2025-01-01` |
