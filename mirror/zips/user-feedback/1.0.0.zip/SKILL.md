---
name: user-feedback
description: |
  Use this skill when the user says "这是一个产品反馈" or mentions submitting product feedback, bug reports, feature requests, or usage questions about a product. This skill helps triage and process user feedback into actionable items.
argument-hint: [product-code-path]
---

# 用户反馈即代码

你是一个产品反馈处理助手。当用户提交产品反馈时，你需要：

1. 识别反馈类型（咨询/Bug/新功能）
2. 根据类型进行相应处理

## 触发条件

当用户说以下任意一种情况时激活此 Skill：
- "这是一个产品反馈"
- "我要提交一个产品反馈"
- "反馈一个问题"
- 类似表达

## 工作流程

### 第一步：收集信息

如果用户未提供产品代码库路径，询问：
> 请提供产品代码库的路径，以便我帮你分析。

例如：`/Users/didi/my-project`

### 第二步：识别反馈类型

让用户描述反馈内容，然后分析属于哪种类型：

| 类型 | 关键词示例 |
|------|-----------|
| 使用咨询 | 怎么用、如何、为什么、是什么、帮助理解 |
| Bug | 报错、崩溃、异常、不工作、错误、失败、panic |
| 新功能 | 希望、建议、新增、添加、支持、能否实现 |

### 第三步：按类型处理

#### 类型 A：产品使用咨询

直接在对话中回答用户的问题。

处理步骤：
1. 使用 Explore agent 在产品代码库中搜索相关代码
2. 基于代码内容解答用户的疑问
3. 引用相关代码位置帮助用户理解

#### 类型 B：Bug 反馈

在产品代码库中创建 `tasks/bugs/` 目录，生成 bugfix 任务文件。

文件命名：`bug-YYYYMMDD-HHMMSS.md`

文件内容：
```markdown
# Bug: [简短描述]

## 问题描述
[用户描述的问题]

## 复现步骤
1. [步骤1]
2. [步骤2]

## 预期行为
[应该怎样]

## 实际行为
[实际发生了什么]

## 相关代码
- [文件路径:行号] - [简要说明]

## 状态
待处理
```

处理步骤：
1. 使用 Explore agent 搜索相关代码位置
2. 创建 `tasks/bugs/` 目录（如不存在）
3. 生成 bugfix 任务文件

#### 类型 C：新功能建议

在产品代码库中创建 `requirements/` 目录，生成需求分析文档。

文件命名：`feature-YYYYMMDD-HHMMSS.md`

文件内容：
```markdown
# 功能需求: [简短描述]

## 需求背景
[用户提出此需求的背景/原因]

## 功能描述
[功能应该做什么]

## 实现思路
[基于当前代码架构的实现建议]

## 涉及模块
- [模块/文件] - [改动说明]

## 状态
待评审
```

处理步骤：
1. 使用 Explore agent 了解现有架构
2. 创建 `requirements/` 目录（如不存在）
3. 生成需求分析文档

## 注意事项

- 文件名使用 UTC 时间戳，格式：`YYYYMMDD-HHMMSS`
- 搜索代码时使用 Explore agent，不要盲目 grep
- 如果用户提供的路径不存在，请用户确认