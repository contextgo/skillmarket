# 配置说明

本文档详细说明鲨鱼记账的配置文件结构和配置项。

## 配置文件位置

- **模板文件**：`config.template.json`
- **实际配置**：`config.json`（由 `install.py` 生成）

## 配置文件结构

```json
{
  "dataDir": "data",
  "defaultCurrency": "CNY",
  "dateFormat": "YYYY年MM月DD日",
  "files": { ... },
  "reports": { ... },
  "assets": { ... },
  "categories": { ... },
  "assetTypes": [ ... ],
  "version": "0.2.0"
}
```

## 配置项说明

### 基础配置

#### dataDir
- **类型**：字符串
- **默认值**：`"data"`
- **说明**：数据文件存储目录的相对路径
- **示例**：
  ```json
  "dataDir": "data"
  ```

#### defaultCurrency
- **类型**：字符串
- **默认值**：`"CNY"`
- **说明**：默认货币单位
- **支持的值**：`"CNY"`, `"USD"`, `"EUR"`, `"JPY"` 等
- **示例**：
  ```json
  "defaultCurrency": "CNY"
  ```

#### dateFormat
- **类型**：字符串
- **默认值**：`"YYYY年MM月DD日"`
- **说明**：日期显示格式
- **支持的格式**：
  - `"YYYY年MM月DD日"`（中文格式）
  - `"YYYY-MM-DD"`（ISO 格式）
  - `"MM/DD/YYYY"`（美式格式）
- **示例**：
  ```json
  "dateFormat": "YYYY年MM月DD日"
  ```

### 文件配置

#### files
- **类型**：对象
- **说明**：数据文件路径配置
- **子配置项**：
  - `expenses`：支出记录文件路径
  - `assets`：资产记录文件路径

**示例**：
```json
"files": {
  "expenses": "data/expenses.csv",
  "assets": "data/assets.csv"
}
```

**自定义路径**：
```json
"files": {
  "expenses": "/path/to/my/expenses.csv",
  "assets": "/path/to/my/assets.csv"
}
```

### 报表配置

#### reports
- **类型**：对象
- **说明**：报表生成相关配置

**子配置项**：

##### defaultTopCategories
- **类型**：整数
- **默认值**：`5`
- **说明**：月度支出报告默认显示的类别数量
- **示例**：
  ```json
  "defaultTopCategories": 5
  ```

##### savingsRateTarget
- **类型**：对象
- **说明**：储蓄率健康范围
- **子配置项**：
  - `min`：最低健康储蓄率（%）
  - `max`：最高健康储蓄率（%）
- **示例**：
  ```json
  "savingsRateTarget": {
    "min": 20,
    "max": 30
  }
  ```

### 资产配置

#### assets
- **类型**：对象
- **说明**：资产管理相关配置

**子配置项**：

##### allocation
- **类型**：对象
- **说明**：资产配置健康范围

**各资产类型配置**：

###### liquid（流动资产）
- `min`：最低占比（%）
- `max`：最高占比（%）
- `description`：说明
- **示例**：
  ```json
  "liquid": {
    "min": 10,
    "max": 30,
    "description": "流动资产（应急基金）"
  }
  ```

###### investment（投资资产）
- `min`：最低占比（%）
- `max`：最高占比（%）
- `description`：说明
- **示例**：
  ```json
  "investment": {
    "min": 40,
    "max": 70,
    "description": "投资资产（长期增值）"
  }
  ```

###### physical（实物资产）
- `min`：最低占比（%）
- `max`：最高占比（%）
- `description`：说明
- **示例**：
  ```json
  "physical": {
    "min": 20,
    "max": 40,
    "description": "实物资产（房产、车辆）"
  }
  ```

###### liability（负债）
- `max`：负债率上限（%）
- `description`：说明
- **示例**：
  ```json
  "liability": {
    "max": 30,
    "description": "负债率上限"
  }
  ```

### 类别配置

#### categories
- **类型**：对象
- **说明**：收支类别配置

**子配置项**：

##### expense（支出类别）
- **类型**：数组
- **默认值**：`["餐饮", "购物", "交通", "娱乐", "医疗", "教育", "住房", "通讯", "其他"]`
- **说明**：支出类别列表
- **示例**：
  ```json
  "expense": [
    "餐饮",
    "购物",
    "交通",
    "娱乐",
    "医疗",
    "教育",
    "住房",
    "通讯",
    "其他"
  ]
  ```

**自定义类别**：
```json
"expense": [
  "餐饮",
  "购物",
  "交通",
  "娱乐",
  "医疗",
  "教育",
  "住房",
  "通讯",
  "宠物",
  "旅游",
  "其他"
]
```

##### income（收入类别）
- **类型**：数组
- **默认值**：`["工资", "兼职", "投资", "其他"]`
- **说明**：收入类别列表
- **示例**：
  ```json
  "income": [
    "工资",
    "兼职",
    "投资",
    "其他"
  ]
  ```

**自定义类别**：
```json
"income": [
  "工资",
  "兼职",
  "投资",
  "奖金",
  "红包",
  "其他"
]
```

### 资产类型配置

#### assetTypes
- **类型**：数组
- **默认值**：`["流动资产", "投资资产", "实物资产", "负债"]`
- **说明**：资产类型列表
- **示例**：
  ```json
  "assetTypes": [
    "流动资产",
    "投资资产",
    "实物资产",
    "负债"
  ]
  ```

### 版本配置

#### version
- **类型**：字符串
- **说明**：配置文件版本号
- **示例**：
  ```json
  "version": "0.2.0"
  ```

## 配置示例

### 默认配置
```json
{
  "dataDir": "data",
  "defaultCurrency": "CNY",
  "dateFormat": "YYYY年MM月DD日",
  "files": {
    "expenses": "data/expenses.csv",
    "assets": "data/assets.csv"
  },
  "reports": {
    "defaultTopCategories": 5,
    "savingsRateTarget": {
      "min": 20,
      "max": 30
    }
  },
  "assets": {
    "allocation": {
      "liquid": {
        "min": 10,
        "max": 30,
        "description": "流动资产（应急基金）"
      },
      "investment": {
        "min": 40,
        "max": 70,
        "description": "投资资产（长期增值）"
      },
      "physical": {
        "min": 20,
        "max": 40,
        "description": "实物资产（房产、车辆）"
      },
      "liability": {
        "max": 30,
        "description": "负债率上限"
      }
    }
  },
  "categories": {
    "expense": [
      "餐饮",
      "购物",
      "交通",
      "娱乐",
      "医疗",
      "教育",
      "住房",
      "通讯",
      "其他"
    ],
    "income": [
      "工资",
      "兼职",
      "投资",
      "其他"
    ]
  },
  "assetTypes": [
    "流动资产",
    "投资资产",
    "实物资产",
    "负债"
  ],
  "version": "0.2.0"
}
```

### 自定义配置示例

#### 使用外部数据目录
```json
{
  "dataDir": "/mnt/storage/finance",
  "files": {
    "expenses": "/mnt/storage/finance/expenses.csv",
    "assets": "/mnt/storage/finance/assets.csv"
  }
}
```

#### 调整储蓄率目标
```json
{
  "reports": {
    "savingsRateTarget": {
      "min": 30,
      "max": 50
    }
  }
}
```

#### 添加自定义类别
```json
{
  "categories": {
    "expense": [
      "餐饮",
      "购物",
      "交通",
      "娱乐",
      "医疗",
      "教育",
      "住房",
      "通讯",
      "宠物",
      "旅游",
      "保险",
      "其他"
    ],
    "income": [
      "工资",
      "兼职",
      "投资",
      "奖金",
      "红包",
      "退税",
      "其他"
    ]
  }
}
```

#### 调整资产配置目标
```json
{
  "assets": {
    "allocation": {
      "liquid": {
        "min": 15,
        "max": 25,
        "description": "流动资产（应急基金）"
      },
      "investment": {
        "min": 50,
        "max": 70,
        "description": "投资资产（长期增值）"
      },
      "physical": {
        "min": 10,
        "max": 30,
        "description": "实物资产（房产、车辆）"
      },
      "liability": {
        "max": 20,
        "description": "负债率上限"
      }
    }
  }
}
```

## 配置文件管理

### 创建配置文件

运行安装脚本会自动创建配置文件：
```bash
python install.py
```

### 手动创建配置文件

复制模板文件并修改：
```bash
cp config.template.json config.json
# 编辑 config.json
```

### 验证配置文件

确保配置文件是有效的 JSON 格式：
```bash
python -m json.tool config.json
```

### 备份配置文件

定期备份配置文件：
```bash
cp config.json config.json.backup
```

### 恢复默认配置

删除 `config.json` 并重新运行安装脚本：
```bash
rm config.json
python install.py
```

## 配置最佳实践

1. **不要修改模板文件**：始终修改 `config.json`，保持 `config.template.json` 不变
2. **备份配置**：修改前备份配置文件
3. **验证 JSON**：修改后验证 JSON 格式是否正确
4. **版本控制**：如果使用 Git，将 `config.json` 添加到 `.gitignore`（包含个人路径）
5. **文档化修改**：在配置文件中添加注释说明自定义配置的原因（JSON 不支持注释，可在单独文档中记录）

## 常见问题

### Q: 修改配置后需要重启吗？
A: 不需要。脚本每次运行时都会读取配置文件。

### Q: 配置文件丢失怎么办？
A: 重新运行 `python install.py` 会生成默认配置文件。

### Q: 可以使用相对路径吗？
A: 可以。相对路径是相对于 `shark-bookkeeping` 目录的。

### Q: 配置文件支持注释吗？
A: JSON 格式不支持注释。如需注释，可以使用单独的文档记录。

### Q: 如何在多台电脑间同步配置？
A: 
1. 使用云存储同步整个 `shark-bookkeeping` 目录
2. 或使用 Git 管理（注意 `.gitignore` 个人数据）
3. 或手动复制 `config.json` 文件

## 配置升级

当技能版本升级时，配置文件可能需要更新：

1. 查看 `CHANGELOG.md` 了解配置变更
2. 备份当前配置：`cp config.json config.json.old`
3. 对比新旧模板：`diff config.template.json config.json.old`
4. 手动合并新配置项到 `config.json`
5. 验证配置文件格式

## 高级配置

### 环境变量覆盖

脚本支持使用环境变量覆盖配置：

```bash
export SHARK_DATA_DIR=/path/to/data
export SHARK_EXPENSES_FILE=/path/to/expenses.csv
python scripts/analyze_shark.py --all
```

### 命令行参数优先级

配置优先级（从高到低）：
1. 命令行参数
2. 环境变量
3. 配置文件
4. 默认值

示例：
```bash
# 使用命令行参数覆盖配置文件
python scripts/analyze_shark.py --data /custom/path/expenses.csv --all
```
