# 故障排查指南

本文档提供鲨鱼记账技能常见问题的诊断和解决方案。

## 快速诊断

### 使用数据验证工具

遇到问题时，首先运行数据验证工具：

```bash
python scripts/validate_data.py --data data/expenses.csv --verbose
python scripts/validate_data.py --data data/expenses.csv --assets data/assets.csv --debug
```

### 启用调试模式

所有脚本都支持 `--verbose` 和 `--debug` 选项：

```bash
python scripts/analyze_shark.py --data data/expenses.csv --all --debug
python scripts/quick_add.py --支出 餐饮 25 --verbose
python scripts/asset_manager.py --data data/assets.csv --all --debug
```

## 常见错误

### 1. 文件相关错误

#### 错误：FileNotFoundError: [Errno 2] No such file or directory

**症状：**
```
FileNotFoundError: [Errno 2] No such file or directory: 'data/expenses.csv'
```

**原因：**
- 数据文件不存在
- 文件路径错误
- 未运行初始化脚本

**解决方案：**
```bash
# 1. 检查文件是否存在
ls -la data/

# 2. 运行初始化脚本
python install.py

# 3. 使用绝对路径
python scripts/analyze_shark.py --data /absolute/path/to/expenses.csv --all

# 4. 使用验证工具检查
python scripts/validate_data.py --data data/expenses.csv --debug
```

#### 错误：PermissionError: [Errno 13] Permission denied

**症状：**
```
PermissionError: [Errno 13] Permission denied: 'data/expenses.csv'
```

**原因：**
- 文件权限不足
- 文件被其他程序占用
- 目录权限问题

**解决方案：**
```bash
# 1. 检查文件权限
ls -l data/expenses.csv

# 2. 修改权限
chmod 644 data/expenses.csv

# 3. 检查是否被占用（Linux/Mac）
lsof data/expenses.csv

# 4. 关闭占用文件的程序（如 Excel）
```

### 2. CSV 格式错误

#### 错误：CSV 文件缺少必需列

**症状：**
```
ValidationError: CSV 文件缺少必需列: 日期, 金额
```

**原因：**
- CSV 文件表头不完整
- 列名拼写错误
- 文件格式损坏

**解决方案：**
```bash
# 1. 使用验证工具检查
python scripts/validate_data.py --data data/expenses.csv --verbose

# 2. 检查表头
head -1 data/expenses.csv

# 3. 正确的表头格式（支出记录）
日期,收支类型,类别,账户,金额,备注

# 4. 正确的表头格式（资产记录）
资产类型,资产名称,资产账户,币种,当前价值,更新时间,备注

# 5. 如果文件损坏，从备份恢复或重新初始化
python install.py --force
```

#### 错误：CSV 文件为空或格式错误

**症状：**
```
ValidationError: CSV 文件为空或格式错误
```

**原因：**
- 文件只有表头没有数据
- 文件完全为空
- 文件编码错误

**解决方案：**
```bash
# 1. 检查文件内容
cat data/expenses.csv

# 2. 检查文件大小
ls -lh data/expenses.csv

# 3. 检查文件编码
file data/expenses.csv

# 4. 如果文件为空，添加示例数据
python install.py

# 5. 确保文件使用 UTF-8 编码
iconv -f GBK -t UTF-8 data/expenses.csv > data/expenses_utf8.csv
mv data/expenses_utf8.csv data/expenses.csv
```

### 3. 日期格式错误

#### 错误：无法解析日期

**症状：**
```
ValidationError: 无法解析日期: 2026/4/13。支持格式: YYYY年MM月DD日, YYYY-MM-DD, YYYY/MM/DD
```

**原因：**
- 日期格式不符合要求
- 月份或日期缺少前导零
- 使用了不支持的日期格式

**解决方案：**
```bash
# 支持的日期格式：
# ✅ 2026年04月13日
# ✅ 2026-04-13
# ✅ 2026/04/13

# ❌ 不支持的格式：
# ❌ 2026/4/13 （缺少前导零）
# ❌ 04/13/2026 （美式格式）
# ❌ 13-04-2026 （欧式格式）

# 修复方法：
# 1. 手动编辑 CSV 文件，统一日期格式
# 2. 使用脚本批量转换（见下方脚本）
```

**日期格式转换脚本：**
```python
import csv
from datetime import datetime

# 读取并转换日期格式
with open('data/expenses.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    rows = list(reader)
    
for row in rows:
    # 尝试解析各种格式
    for fmt in ['%Y/%m/%d', '%Y-%m-%d', '%Y年%m月%d日']:
        try:
            date = datetime.strptime(row['日期'], fmt)
            row['日期'] = date.strftime('%Y年%m月%d日')
            break
        except:
            continue

# 写回文件
with open('data/expenses.csv', 'w', encoding='utf-8', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
```

### 4. 金额格式错误

#### 错误：金额格式错误

**症状：**
```
ValidationError: 第 5 行: 金额格式错误 '¥25.50'
```

**原因：**
- 金额包含货币符号
- 金额包含逗号分隔符
- 金额为非数字字符

**解决方案：**
```bash
# 正确的金额格式：
# ✅ 25.50
# ✅ 25
# ✅ 1000.00

# ❌ 错误的格式：
# ❌ ¥25.50 （包含货币符号）
# ❌ 1,000.00 （包含逗号）
# ❌ 二十五 （中文数字）

# 修复方法：
# 1. 使用验证工具找出所有错误
python scripts/validate_data.py --data data/expenses.csv --verbose

# 2. 手动编辑 CSV 文件，移除货币符号和逗号
# 3. 确保金额为纯数字
```

#### 错误：金额必须大于 0

**症状：**
```
ValidationError: 第 10 行: 金额必须大于 0，当前值为 -50
```

**原因：**
- 支出记录中金额为负数
- 金额为零

**解决方案：**
```bash
# 支出和收入记录中，金额应为正数
# 收支类型字段标识是收入还是支出

# 正确示例：
# 日期,收支类型,类别,账户,金额,备注
# 2026年04月13日,支出,餐饮,未关联,25,午饭
# 2026年04月13日,收入,工资,工商银行,5000,月薪

# 资产记录中，负债的金额应为负数
# 资产类型,资产名称,资产账户,币种,当前价值,更新时间,备注
# 负债,招商信用卡,Liabilities:CreditCard:CMB,CNY,-5000,2026-04-13,
```

### 5. 编码问题

#### 错误：UnicodeDecodeError

**症状：**
```
UnicodeDecodeError: 'utf-8' codec can't decode byte 0xd6 in position 0
```

**原因：**
- CSV 文件使用了非 UTF-8 编码（如 GBK）
- 文件包含特殊字符

**解决方案：**
```bash
# 1. 检查文件编码
file -i data/expenses.csv

# 2. 转换为 UTF-8
iconv -f GBK -t UTF-8 data/expenses.csv > data/expenses_utf8.csv
mv data/expenses_utf8.csv data/expenses.csv

# 3. 在 Excel 中另存为 CSV UTF-8 格式
# 文件 -> 另存为 -> CSV UTF-8 (逗号分隔)

# 4. 使用 Python 转换
python -c "
import codecs
with codecs.open('data/expenses.csv', 'r', 'gbk') as f:
    content = f.read()
with codecs.open('data/expenses.csv', 'w', 'utf-8') as f:
    f.write(content)
"
```

### 6. 脚本运行错误

#### 错误：ModuleNotFoundError: No module named 'utils'

**症状：**
```
ModuleNotFoundError: No module named 'utils'
```

**原因：**
- utils.py 文件不存在
- Python 路径配置问题
- 在错误的目录运行脚本

**解决方案：**
```bash
# 1. 检查 utils.py 是否存在
ls -la scripts/utils.py

# 2. 确保在正确的目录运行
cd shark-bookkeeping
python scripts/analyze_shark.py --data data/expenses.csv --all

# 3. 如果 utils.py 不存在，重新安装
python install.py

# 4. 使用绝对路径运行
python /absolute/path/to/shark-bookkeeping/scripts/analyze_shark.py --data data/expenses.csv --all
```

#### 错误：Python 版本不兼容

**症状：**
```
SyntaxError: invalid syntax
```

**原因：**
- Python 版本过低（需要 3.7+）
- 使用了 Python 2

**解决方案：**
```bash
# 1. 检查 Python 版本
python --version
python3 --version

# 2. 使用 Python 3.7+ 运行
python3 scripts/analyze_shark.py --data data/expenses.csv --all

# 3. 升级 Python
# Ubuntu/Debian:
sudo apt update
sudo apt install python3.9

# macOS:
brew install python@3.9

# Windows:
# 从 python.org 下载安装最新版本
```

## 性能问题

### 脚本运行缓慢

**症状：**
- 脚本运行时间过长
- 处理大文件时卡顿

**诊断：**
```bash
# 1. 检查文件大小
ls -lh data/expenses.csv

# 2. 统计记录数量
wc -l data/expenses.csv

# 3. 使用 --debug 查看详细信息
python scripts/analyze_shark.py --data data/expenses.csv --all --debug
```

**解决方案：**
```bash
# 1. 按年份过滤数据
python scripts/analyze_shark.py --data data/expenses.csv --year 2026 --all

# 2. 分割大文件
# 将历史数据归档到单独的文件

# 3. 优化 CSV 文件
# 移除不必要的空行和重复数据
```

## 数据问题

### 数据不一致

**症状：**
- 报表数字不匹配
- 净资产计算错误
- 类别统计异常

**诊断：**
```bash
# 1. 运行完整验证
python scripts/validate_data.py --data data/expenses.csv --assets data/assets.csv --verbose

# 2. 检查重复记录
# 使用 Excel 或文本编辑器查找重复行

# 3. 检查数据完整性
python scripts/analyze_shark.py --data data/expenses.csv --all --debug
```

**解决方案：**
```bash
# 1. 备份数据
cp data/expenses.csv data/expenses_backup_$(date +%Y%m%d).csv

# 2. 清理重复数据
# 手动编辑或使用脚本去重

# 3. 重新验证
python scripts/validate_data.py --data data/expenses.csv --verbose
```

### 类别不一致

**症状：**
- 同一类别有多种拼写
- 类别统计分散

**示例：**
```
餐饮
餐 饮
餐饮 
Dining
```

**解决方案：**
```bash
# 1. 统一类别名称
# 使用查找替换功能统一拼写

# 2. 使用标准类别
python scripts/quick_add.py --list-categories

# 3. 批量修正（Python 脚本）
import csv

# 类别映射
category_map = {
    '餐 饮': '餐饮',
    '餐饮 ': '餐饮',
    'Dining': '餐饮',
}

with open('data/expenses.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

for row in rows:
    if row['类别'] in category_map:
        row['类别'] = category_map[row['类别']]

with open('data/expenses.csv', 'w', encoding='utf-8', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
```

## 安装问题

### 安装失败

**症状：**
```
错误: 无法创建目录
```

**解决方案：**
```bash
# 1. 检查权限
ls -ld shark-bookkeeping/

# 2. 使用 sudo（如果需要）
sudo python install.py

# 3. 指定自定义目录
python install.py --data-dir ~/my_finance_data

# 4. 强制重新安装
python install.py --force
```

## 获取帮助

### 启用详细日志

所有脚本都支持详细日志：

```bash
# 详细模式
python scripts/analyze_shark.py --data data/expenses.csv --all --verbose

# 调试模式
python scripts/analyze_shark.py --data data/expenses.csv --all --debug
```

### 查看文档

- **快速开始**：`README.md`
- **技能说明**：`SKILL.md`
- **脚本使用**：`references/scripts.md`
- **常见问题**：`references/faq.md`
- **配置说明**：`references/configuration.md`

### 报告问题

如果问题仍未解决，请提供以下信息：

1. **错误信息**：完整的错误堆栈
2. **运行命令**：你执行的完整命令
3. **环境信息**：
   ```bash
   python --version
   uname -a  # Linux/Mac
   ver  # Windows
   ```
4. **数据样本**：脱敏后的数据示例（前几行）
5. **调试日志**：使用 `--debug` 选项的输出

## 预防措施

### 定期备份

```bash
# 每周备份
cp -r data data_backup_$(date +%Y%m%d)

# 自动备份脚本
#!/bin/bash
BACKUP_DIR=~/shark_backups
mkdir -p $BACKUP_DIR
cp -r data $BACKUP_DIR/data_$(date +%Y%m%d_%H%M%S)
```

### 数据验证

```bash
# 添加数据后验证
python scripts/quick_add.py --支出 餐饮 25
python scripts/validate_data.py --data data/expenses.csv

# 定期完整验证
python scripts/validate_data.py --data data/expenses.csv --assets data/assets.csv --verbose
```

### 使用版本控制

```bash
# 初始化 Git 仓库
cd shark-bookkeeping
git init
git add data/*.csv
git commit -m "Initial data"

# 每次修改后提交
git add data/*.csv
git commit -m "Update expenses"
```

## 高级故障排查

### 使用 Python 调试器

```bash
# 使用 pdb 调试
python -m pdb scripts/analyze_shark.py --data data/expenses.csv --all

# 在代码中添加断点
import pdb; pdb.set_trace()
```

### 检查系统资源

```bash
# 检查磁盘空间
df -h

# 检查内存使用
free -h  # Linux
top  # Linux/Mac

# 检查文件句柄
ulimit -n
```

### 日志文件分析

```bash
# 将日志保存到文件
python scripts/analyze_shark.py --data data/expenses.csv --all --debug > debug.log 2>&1

# 分析日志
grep ERROR debug.log
grep WARNING debug.log
```
