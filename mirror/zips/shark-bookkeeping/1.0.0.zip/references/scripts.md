# 脚本使用指南

本文档详细说明鲨鱼记账技能提供的所有脚本及其使用方法。

## 脚本概览

| 脚本 | 用途 | 何时使用 |
|------|------|----------|
| `analyze_shark.py` | 财务分析和报表生成 | 需要分析收支数据、生成财务报告 |
| `asset_manager.py` | 资产管理和净资产计算 | 需要追踪资产、计算净资产、分析配置 |
| `quick_add.py` | 快速记账 | 需要快速记录收支交易 |

## analyze_shark.py - 财务分析脚本

### 基本用法

```bash
python scripts/analyze_shark.py --data <csv文件> [选项]
```

### 选项说明

| 选项 | 说明 | 示例 |
|------|------|------|
| `--data <file>` | 指定支出数据文件路径（必需） | `--data data/expenses.csv` |
| `--assets <file>` | 指定资产数据文件路径（可选） | `--assets data/assets.csv` |
| `--year YYYY` | 按特定年份过滤 | `--year 2026` |
| `--report <type>` | 指定报告类型 | `--report balance_sheet` |
| `--top N` | 月度支出报告显示的类别数量 | `--top 10` |
| `--all` | 运行所有报告 | `--all` |

### 报告类型

#### 1. balance_sheet - 资产负债表
显示资产、负债和净资产的快照。

```bash
python scripts/analyze_shark.py --data data/expenses.csv --report balance_sheet
```

**输出内容：**
- 流动资产总额
- 投资资产总额
- 实物资产总额
- 负债总额
- 净资产

#### 2. income_statement - 损益表
显示收入、支出和净收益。

```bash
python scripts/analyze_shark.py --data data/expenses.csv --report income_statement
```

**输出内容：**
- 总收入（按类别）
- 总支出（按类别）
- 净收益/亏损

#### 3. savings_rate - 储蓄率报告
计算储蓄率和储蓄金额。

```bash
python scripts/analyze_shark.py --data data/expenses.csv --report savings_rate
```

**输出内容：**
- 总收入
- 总支出
- 储蓄金额
- 储蓄率（%）
- 与健康基准（20-30%）的比较

#### 4. monthly_expenses - 月度支出报告
显示每月支出趋势和主要支出类别。

```bash
python scripts/analyze_shark.py --data data/expenses.csv --report monthly_expenses --top 5
```

**输出内容：**
- 每月总支出
- 月度趋势图
- 前 N 个支出类别
- 类别占比

#### 5. net_worth_change - 净资产变化报告
追踪净资产随时间的变化。

```bash
python scripts/analyze_shark.py --data data/expenses.csv --assets data/assets.csv --report net_worth_change
```

**输出内容：**
- 期初净资产
- 期末净资产
- 净资产变化
- 变化率（%）

### 使用示例

#### 完整财务分析
```bash
python scripts/analyze_shark.py --data data/expenses.csv --assets data/assets.csv --all
```

#### 2026年度报告
```bash
python scripts/analyze_shark.py --data data/expenses.csv --year 2026 --all
```

#### 查看前10个支出类别
```bash
python scripts/analyze_shark.py --data data/expenses.csv --report monthly_expenses --top 10
```

### 常见错误

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| `FileNotFoundError` | 文件路径不存在 | 检查文件路径是否正确 |
| `CSV 格式错误` | CSV 文件格式不符合要求 | 参见 `csv_format.md` 检查格式 |
| `日期解析错误` | 日期格式不正确 | 使用 `YYYY年MM月DD日` 格式 |
| `空数据` | CSV 文件为空或只有表头 | 添加至少一条数据记录 |

## asset_manager.py - 资产管家脚本

### 基本用法

```bash
python scripts/asset_manager.py --data <csv文件> [选项]
```

### 选项说明

| 选项 | 说明 | 示例 |
|------|------|------|
| `--data <file>` | 指定资产数据文件路径（必需） | `--data data/assets.csv` |
| `--list` | 列出所有资产 | `--list` |
| `--net-worth` | 计算净资产 | `--net-worth` |
| `--allocation` | 资产配置分析 | `--allocation` |
| `--all` | 运行所有报告 | `--all` |
| `--add` | 添加资产 | `--add --type 流动资产 --name 工商银行 --value 50000` |
| `--delete <name>` | 删除资产 | `--delete 工商银行储蓄卡` |
| `--update <name>` | 更新资产 | `--update 工商银行储蓄卡 --value 60000` |

### 资产类型

| 类型 | 说明 | 示例 |
|------|------|------|
| 流动资产 | 现金、银行活期、支付宝、微信钱包 | 工商银行储蓄卡、支付宝余额 |
| 投资资产 | 股票、基金、债券、理财 | 天天基金、招商证券 |
| 实物资产 | 房产、车辆 | 北京房产、本田雅阁 |
| 负债 | 信用卡、房贷、车贷 | 招商信用卡、工行房贷 |

### 使用示例

#### 查看所有资产
```bash
python scripts/asset_manager.py --data data/assets.csv --list
```

#### 计算净资产
```bash
python scripts/asset_manager.py --data data/assets.csv --net-worth
```

#### 资产配置分析
```bash
python scripts/asset_manager.py --data data/assets.csv --allocation
```

#### 完整报告
```bash
python scripts/asset_manager.py --data data/assets.csv --all
```

#### 添加资产
```bash
# 添加流动资产
python scripts/asset_manager.py --data data/assets.csv --add --type 流动资产 --name 工商银行储蓄卡 --value 50000 --currency CNY

# 添加投资资产
python scripts/asset_manager.py --data data/assets.csv --add --type 投资资产 --name 天天基金 --value 80000 --currency CNY

# 添加负债
python scripts/asset_manager.py --data data/assets.csv --add --type 负债 --name 招商信用卡 --value -5000 --currency CNY
```

#### 更新资产
```bash
python scripts/asset_manager.py --data data/assets.csv --update 工商银行储蓄卡 --value 60000
```

#### 删除资产
```bash
python scripts/asset_manager.py --data data/assets.csv --delete 工商银行储蓄卡
```

### 资产配置建议

脚本会根据以下标准提供配置建议：

| 资产类型 | 健康范围 | 说明 |
|----------|----------|------|
| 流动资产 | 10-30% | 应急基金，3-6个月支出 |
| 投资资产 | 40-70% | 长期增值，分散风险 |
| 实物资产 | 20-40% | 房产、车辆等 |
| 负债 | <30% | 负债率不宜过高 |

## quick_add.py - 快速记账脚本

### 基本用法

```bash
python scripts/quick_add.py --data <csv文件> [选项]
```

### 选项说明

| 选项 | 说明 | 示例 |
|------|------|------|
| `--data <file>` | 指定支出数据文件路径（必需） | `--data data/expenses.csv` |
| `--支出 <类别> <金额>` | 记录支出 | `--支出 餐饮 25` |
| `--收入 <类别> <金额>` | 记录收入 | `--收入 工资 5000` |
| `--账户 <账户名>` | 指定账户 | `--账户 工商银行` |
| `--备注 <备注>` | 添加备注 | `--备注 午饭` |
| `--date <日期>` | 指定日期 | `--date 2026-04-01` |

### 使用示例

#### 记录支出
```bash
# 基本支出
python scripts/quick_add.py --data data/expenses.csv --支出 餐饮 25 --备注 午饭

# 指定账户
python scripts/quick_add.py --data data/expenses.csv --支出 购物 200 --账户 招商信用卡 --备注 买衣服

# 指定日期
python scripts/quick_add.py --data data/expenses.csv --date 2026-04-01 --支出 交通 50 --备注 打车
```

#### 记录收入
```bash
# 工资收入
python scripts/quick_add.py --data data/expenses.csv --收入 工资 5000

# 兼职收入
python scripts/quick_add.py --data data/expenses.csv --收入 兼职 1000 --备注 周末兼职
```

### 支出类别

常用支出类别：
- 餐饮：日常饮食
- 购物：服装、日用品
- 交通：打车、公交、地铁
- 娱乐：电影、游戏
- 医疗：看病、买药
- 教育：培训、书籍
- 住房：房租、物业费
- 通讯：话费、网费
- 其他：其他支出

### 收入类别

常用收入类别：
- 工资：主要工作收入
- 兼职：兼职收入
- 投资：股票、基金收益
- 其他：其他收入

## 脚本组合使用

### 日常记账流程
1. 使用 `quick_add.py` 快速记录收支
2. 定期使用 `analyze_shark.py` 分析财务状况
3. 使用 `asset_manager.py` 更新资产数据

### 月度财务审查
```bash
# 1. 记录本月所有收支
python scripts/quick_add.py --data data/expenses.csv --支出 餐饮 25 --备注 午饭
# ... 更多记录

# 2. 生成月度报告
python scripts/analyze_shark.py --data data/expenses.csv --report monthly_expenses

# 3. 更新资产数据
python scripts/asset_manager.py --data data/assets.csv --update 工商银行储蓄卡 --value 50000

# 4. 查看净资产变化
python scripts/asset_manager.py --data data/assets.csv --net-worth
```

### 年度财务总结
```bash
# 生成年度完整报告
python scripts/analyze_shark.py --data data/expenses.csv --assets data/assets.csv --year 2026 --all

# 资产配置分析
python scripts/asset_manager.py --data data/assets.csv --allocation
```

## 故障排查

### 脚本无法运行
1. 检查 Python 版本（需要 Python 3.7+）
2. 检查文件路径是否正确
3. 检查 CSV 文件格式是否符合要求

### 数据不准确
1. 检查 CSV 文件中的数据是否正确
2. 检查日期格式是否统一
3. 检查金额是否为数字类型

### 中文显示乱码
1. 确保 CSV 文件使用 UTF-8 编码
2. 确保终端支持中文显示
3. 在 Windows 上使用 `chcp 65001` 切换到 UTF-8

## 最佳实践

1. **定期备份数据**：每周备份 CSV 文件
2. **保持数据一致性**：使用统一的类别名称和账户名称
3. **及时记录**：当天记录当天的收支
4. **定期审查**：每月生成报告并审查财务状况
5. **验证数据**：定期检查数据准确性
