# 财务报告指南

## 报告类型概述

### 资产负债表 (Balance Sheet)

**用途**：显示特定时间点的资产、负债和净资产状况。

**组成**：
- **Assets（资产）**：现金、银行存款、投资、房产等
- **Liabilities（负债）**：信用卡欠款、贷款、抵押贷款等
- **Equity（净资产）**：资产减去负债

**解读**：
- 净资产为正 = 财务健康（有资产净值）
- 净资产为负 = 资不抵债（债务超过资产）

**在 Fava 中查看**：
```
/balance_sheet/
```

### 损益表 (Income Statement)

**用途**：显示一段时间内的收入和支出。

**组成**：
- **Income（收入）**：工资、奖金、利息、投资收益等
- **Expenses（支出）**：所有消费类别
- **Net（净收益/亏损）**：收入减去支出

**解读**：
- 正值 = 盈利（收入超过支出）
- 负值 = 亏损（支出超过收入）

**在 Fava 中查看**：
```
/income_statement/
```

### 储蓄率报告

**计算公式**：`储蓄率 = (收入 - 支出) / 收入 × 100%`

**基准**：
| 储蓄率 | 评估 |
|--------|------|
| 0-5% | 危险 - 财务韧性有限 |
| 5-10% | 低于平均 - 易受紧急情况影响 |
| 10-20% | 平均 - 建立基础 |
| 20-30% | 良好 - 财务状况强劲 |
| 30-50% | 优秀 - 加速财富积累 |
| 50%+ | 卓越 - 有提前退休潜力 |

### 月度支出报告

**用途**：按类别详细分析月度支出。

**常见分类**：
- Housing（住房）：房租/房贷、水电费
- Transportation（交通）：汽油、保险、维修
- Food（食物）：日用品、外食
- Healthcare（医疗）：保险、药品
- Entertainment（娱乐）：订阅、旅游
- Personal（个人）：服装、化妆品

**在 Fava 中查看**：
```
/expenses_by_account/
```

### 净资产变化报告

**用途**：追踪净资产随时间的增长或下降。

**组成**：
- 月度/年度净资产
- 资产变化
- 负债变化

**在 Fava 中查看**：
```
/net_accounts/
```

## 生成报告的方法

### 使用 Fava 界面

1. 打开 Fava 界面
2. 导航到相应的报告页面
3. 使用时间过滤器选择日期范围
4. 导出为 CSV 或 Excel（如需要）

### 使用 BQL 查询

**月度汇总**：
```sql
SELECT
  year, month,
  sum(position) WHERE account ~ 'Income:' AS income,
  sum(position) WHERE account ~ 'Expenses:' AS expenses
GROUP BY year, month
ORDER BY year, month
```

**年度汇总**：
```sql
SELECT
  year,
  sum(position) WHERE account ~ 'Income:' AS income,
  sum(position) WHERE account ~ 'Expenses:' AS expenses
GROUP BY year
ORDER BY year
```

### 使用分析脚本

```bash
# 完整报告
python scripts/analyze_shark.py finances.beancount --all

# 仅净资产
python scripts/analyze_shark.py finances.beancount --net-worth

# 储蓄率
python scripts/analyze_shark.py finances.beancount --savings-rate --year 2024

# 月度支出
python scripts/analyze_shark.py finances.beancount --monthly-expenses --year 2024
```

## 报告时间范围选择

### 每周报告
- 适用于紧密预算跟踪
- 快速发现异常支出

### 每月报告
- 适合大多数人的标准周期
- 与账单周期匹配

### 每季度报告
- 适合税收规划
- 长期趋势分析

### 年度报告
- 全面财务回顾
- 目标进展评估
- 税务规划

## 财务健康指标

### 应急基金充足性

**公式**：`流动资产 / 月支出`

| 月数 | 评估 |
|------|------|
| < 1 个月 | 危险 |
| 1-3 个月 | 最低保护 |
| 3-6 个月 | 充足（稳定就业）|
| 6-12 个月 | 较强（不稳定情况）|
| 12+ 个月 | 卓越缓冲 |

### 债务收入比

**公式**：`每月债务支付 / 月总收入 × 100%`

| 比率 | 评估 |
|------|------|
| < 20% | 优秀 |
| 20-36% | 可接受 |
| 36-43% | 令人担忧 |
| > 43% | 危险 - 高违约风险 |

### 支出类别分布

**健康范围**（因地区/情况而异）：
- 住房：25-35%
- 交通：10-20%
- 食物：10-15%
- 公用事业：5-10%
- 保险：10-15%
- 储蓄/投资：20%+
- 娱乐：5-10%
- 个人：5-10%

## 自定义报告

### 在 Beancount 中保存查询

```beancount
2024-01-01 query "年度支出汇总"
  SELECT
    year,
    account,
    sum(position) AS total
  WHERE
    account ~ 'Expenses:'
  GROUP BY year, account
  ORDER BY year, total DESC
```

### 使用 Fava 仪表板

参见 `references/fava_dashboards.md` 了解创建自定义仪表板的信息。

## 解读报告的技巧

1. **与基准比较**：将您的支出与健康范围比较
2. **趋势分析**：查看月份间和年份间的变化
3. **关注异常**：注意显著偏离正常模式的类别
4. **设定目标**：使用报告追踪财务目标进展
5. **定期审查**：至少每月审查一次关键报告
