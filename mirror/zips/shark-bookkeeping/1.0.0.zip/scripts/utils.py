#!/usr/bin/env python3
"""
通用工具函数库

提供日志记录、错误处理、数据验证等通用功能。
"""

import logging
import sys
from typing import Optional
from datetime import datetime


def setup_logger(name: str, level: int = logging.INFO,
                 log_file: Optional[str] = None) -> logging.Logger:
    """
    设置日志记录器

    Args:
        name: 日志记录器名称
        level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: 日志文件路径（可选）

    Returns:
        配置好的日志记录器
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # 避免重复添加处理器
    if logger.handlers:
        return logger

    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    # 格式化器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 文件处理器（如果指定）
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def get_log_level(verbose: bool = False, debug: bool = False) -> int:
    """
    根据命令行参数确定日志级别

    Args:
        verbose: 是否启用详细输出
        debug: 是否启用调试输出

    Returns:
        日志级别
    """
    if debug:
        return logging.DEBUG
    elif verbose:
        return logging.INFO
    else:
        return logging.WARNING


class ValidationError(Exception):
    """数据验证错误"""
    pass


class FileError(Exception):
    """文件操作错误"""
    pass


def validate_file_exists(file_path: str, logger: Optional[logging.Logger] = None) -> bool:
    """
    验证文件是否存在

    Args:
        file_path: 文件路径
        logger: 日志记录器（可选）

    Returns:
        文件是否存在

    Raises:
        FileError: 文件不存在时抛出
    """
    import os

    if not os.path.exists(file_path):
        error_msg = f"文件不存在: {file_path}"
        if logger:
            logger.error(error_msg)
        raise FileError(error_msg)

    if logger:
        logger.debug(f"文件存在: {file_path}")

    return True


def validate_csv_format(file_path: str, required_columns: list,
                       logger: Optional[logging.Logger] = None) -> bool:
    """
    验证 CSV 文件格式

    Args:
        file_path: CSV 文件路径
        required_columns: 必需的列名列表
        logger: 日志记录器（可选）

    Returns:
        格式是否正确

    Raises:
        ValidationError: 格式不正确时抛出
    """
    import csv

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames

            if not headers:
                error_msg = f"CSV 文件为空或格式错误: {file_path}"
                if logger:
                    logger.error(error_msg)
                raise ValidationError(error_msg)

            missing_columns = [col for col in required_columns if col not in headers]
            if missing_columns:
                error_msg = f"CSV 文件缺少必需列: {', '.join(missing_columns)}"
                if logger:
                    logger.error(error_msg)
                raise ValidationError(error_msg)

            if logger:
                logger.debug(f"CSV 格式验证通过: {file_path}")

            return True

    except Exception as e:
        if isinstance(e, ValidationError):
            raise
        error_msg = f"读取 CSV 文件失败: {str(e)}"
        if logger:
            logger.error(error_msg)
        raise FileError(error_msg)


def parse_date(date_str: str, logger: Optional[logging.Logger] = None) -> datetime:
    """
    解析日期字符串

    支持格式:
    - YYYY年MM月DD日
    - YYYY-MM-DD
    - YYYY/MM/DD

    Args:
        date_str: 日期字符串
        logger: 日志记录器（可选）

    Returns:
        datetime 对象

    Raises:
        ValidationError: 日期格式不正确时抛出
    """
    formats = [
        '%Y年%m月%d日',
        '%Y-%m-%d',
        '%Y/%m/%d',
    ]

    for fmt in formats:
        try:
            date_obj = datetime.strptime(date_str, fmt)
            if logger:
                logger.debug(f"日期解析成功: {date_str} -> {date_obj}")
            return date_obj
        except ValueError:
            continue

    error_msg = f"无法解析日期: {date_str}。支持格式: YYYY年MM月DD日, YYYY-MM-DD, YYYY/MM/DD"
    if logger:
        logger.error(error_msg)
    raise ValidationError(error_msg)


def format_currency(amount: float, currency: str = 'CNY') -> str:
    """
    格式化货币金额

    Args:
        amount: 金额
        currency: 货币代码

    Returns:
        格式化后的字符串
    """
    symbols = {
        'CNY': '¥',
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'JPY': '¥',
    }

    symbol = symbols.get(currency, currency)
    return f"{symbol}{amount:,.2f}"


def safe_float(value: str, default: float = 0.0,
               logger: Optional[logging.Logger] = None) -> float:
    """
    安全地将字符串转换为浮点数

    Args:
        value: 字符串值
        default: 默认值
        logger: 日志记录器（可选）

    Returns:
        浮点数
    """
    try:
        return float(value)
    except (ValueError, TypeError):
        if logger:
            logger.warning(f"无法转换为浮点数: {value}，使用默认值 {default}")
        return default
