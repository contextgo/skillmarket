#!/usr/bin/env python3
"""
数据验证工具

验证鲨鱼记账 CSV 数据文件的格式和内容完整性。

用法：
    python validate_data.py --data data/expenses.csv
    python validate_data.py --data data/expenses.csv --assets data/assets.csv
    python validate_data.py --data data/expenses.csv --verbose
    python validate_data.py --data data/expenses.csv --debug
"""

import csv
import argparse
import os
import sys
from datetime import datetime
from typing import List, Dict, Tuple

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import (
    setup_logger, get_log_level, validate_file_exists,
    validate_csv_format, parse_date, ValidationError, FileError
)


# 必需的列
EXPENSES_REQUIRED_COLUMNS = ['日期', '收支类型', '类别', '账户', '金额', '备注']
ASSETS_REQUIRED_COLUMNS = ['资产类型', '资产名称', '资产账户', '币种', '当前价值', '更新时间', '备注']

# 有效的收支类型
VALID_TRANSACTION_TYPES = ['收入', '支出']

# 有效的资产类型
VALID_ASSET_TYPES = ['流动资产', '投资资产', '实物资产', '负债']

# 有效的货币
VALID_CURRENCIES = ['CNY', 'USD', 'EUR', 'GBP', 'JPY', 'HKD']


class DataValidator:
    """数据验证器"""

    def __init__(self, logger):
        self.logger = logger
        self.errors = []
        self.warnings = []

    def add_error(self, message: str):
        """添加错误"""
        self.errors.append(message)
        self.logger.error(message)

    def add_warning(self, message: str):
        """添加警告"""
        self.warnings.append(message)
        self.logger.warning(message)

    def validate_expenses_file(self, file_path: str) -> bool:
        """
        验证支出记录文件

        Args:
            file_path: 文件路径

        Returns:
            是否验证通过
        """
        self.logger.info(f"开始验证支出记录文件: {file_path}")

        try:
            # 验证文件存在
            validate_file_exists(file_path, self.logger)

            # 验证 CSV 格式
            validate_csv_format(file_path, EXPENSES_REQUIRED_COLUMNS, self.logger)

            # 验证数据内容
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                row_count = 0

                for i, row in enumerate(reader, start=2):  # 从第2行开始（第1行是表头）
                    row_count += 1
                    self._validate_expense_row(row, i)

                if row_count == 0:
                    self.add_warning("文件中没有数据记录")
                else:
                    self.logger.info(f"共验证 {row_count} 条记录")

            return len(self.errors) == 0

        except (ValidationError, FileError) as e:
            self.add_error(str(e))
            return False
        except Exception as e:
            self.add_error(f"验证过程中发生错误: {str(e)}")
            return False

    def _validate_expense_row(self, row: Dict[str, str], row_num: int):
        """验证单条支出记录"""
        # 验证日期
        try:
            parse_date(row['日期'], self.logger)
        except ValidationError:
            self.add_error(f"第 {row_num} 行: 日期格式错误 '{row['日期']}'")

        # 验证收支类型
        if row['收支类型'] not in VALID_TRANSACTION_TYPES:
            self.add_error(f"第 {row_num} 行: 无效的收支类型 '{row['收支类型']}'，应为 {VALID_TRANSACTION_TYPES}")

        # 验证类别
        if not row['类别'].strip():
            self.add_error(f"第 {row_num} 行: 类别不能为空")

        # 验证账户
        if not row['账户'].strip():
            self.add_warning(f"第 {row_num} 行: 账户为空")

        # 验证金额
        try:
            amount = float(row['金额'])
            if amount <= 0:
                self.add_error(f"第 {row_num} 行: 金额必须大于 0，当前值为 {amount}")
        except ValueError:
            self.add_error(f"第 {row_num} 行: 金额格式错误 '{row['金额']}'")

    def validate_assets_file(self, file_path: str) -> bool:
        """
        验证资产记录文件

        Args:
            file_path: 文件路径

        Returns:
            是否验证通过
        """
        self.logger.info(f"开始验证资产记录文件: {file_path}")

        try:
            # 验证文件存在
            validate_file_exists(file_path, self.logger)

            # 验证 CSV 格式
            validate_csv_format(file_path, ASSETS_REQUIRED_COLUMNS, self.logger)

            # 验证数据内容
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                row_count = 0

                for i, row in enumerate(reader, start=2):
                    row_count += 1
                    self._validate_asset_row(row, i)

                if row_count == 0:
                    self.add_warning("文件中没有数据记录")
                else:
                    self.logger.info(f"共验证 {row_count} 条记录")

            return len(self.errors) == 0

        except (ValidationError, FileError) as e:
            self.add_error(str(e))
            return False
        except Exception as e:
            self.add_error(f"验证过程中发生错误: {str(e)}")
            return False

    def _validate_asset_row(self, row: Dict[str, str], row_num: int):
        """验证单条资产记录"""
        # 验证资产类型
        if row['资产类型'] not in VALID_ASSET_TYPES:
            self.add_error(f"第 {row_num} 行: 无效的资产类型 '{row['资产类型']}'，应为 {VALID_ASSET_TYPES}")

        # 验证资产名称
        if not row['资产名称'].strip():
            self.add_error(f"第 {row_num} 行: 资产名称不能为空")

        # 验证资产账户
        if not row['资产账户'].strip():
            self.add_warning(f"第 {row_num} 行: 资产账户为空")

        # 验证币种
        if row['币种'] not in VALID_CURRENCIES:
            self.add_warning(f"第 {row_num} 行: 不常见的货币代码 '{row['币种']}'")

        # 验证当前价值
        try:
            value = float(row['当前价值'])
            if row['资产类型'] == '负债' and value > 0:
                self.add_warning(f"第 {row_num} 行: 负债的价值应为负数，当前值为 {value}")
            elif row['资产类型'] != '负债' and value < 0:
                self.add_warning(f"第 {row_num} 行: 资产的价值应为正数，当前值为 {value}")
        except ValueError:
            self.add_error(f"第 {row_num} 行: 当前价值格式错误 '{row['当前价值']}'")

        # 验证更新时间
        try:
            parse_date(row['更新时间'], self.logger)
        except ValidationError:
            self.add_error(f"第 {row_num} 行: 更新时间格式错误 '{row['更新时间']}'")

    def print_summary(self):
        """打印验证摘要"""
        print("\n" + "=" * 60)
        print("验证摘要")
        print("=" * 60)

        if self.errors:
            print(f"\n❌ 发现 {len(self.errors)} 个错误:")
            for error in self.errors:
                print(f"  - {error}")

        if self.warnings:
            print(f"\n⚠️  发现 {len(self.warnings)} 个警告:")
            for warning in self.warnings:
                print(f"  - {warning}")

        if not self.errors and not self.warnings:
            print("\n✅ 所有验证通过，数据格式正确！")
        elif not self.errors:
            print("\n✅ 验证通过（有警告）")
        else:
            print("\n❌ 验证失败，请修复错误后重试")

        print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description='验证鲨鱼记账数据文件')
    parser.add_argument('--data', required=True, help='支出记录文件路径')
    parser.add_argument('--assets', help='资产记录文件路径（可选）')
    parser.add_argument('--verbose', action='store_true', help='显示详细信息')
    parser.add_argument('--debug', action='store_true', help='显示调试信息')

    args = parser.parse_args()

    # 设置日志
    log_level = get_log_level(args.verbose, args.debug)
    logger = setup_logger('validate_data', log_level)

    # 创建验证器
    validator = DataValidator(logger)

    # 验证支出记录文件
    expenses_valid = validator.validate_expenses_file(args.data)

    # 验证资产记录文件（如果提供）
    assets_valid = True
    if args.assets:
        assets_valid = validator.validate_assets_file(args.assets)

    # 打印摘要
    validator.print_summary()

    # 返回退出码
    if expenses_valid and assets_valid:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()
