#!/usr/bin/env python3
"""
快速记账脚本

用法：
    python quick_add.py --data /path/to/expenses.csv --支出 餐饮 50 --备注 午饭
    python quick_add.py --data /path/to/expenses.csv --date 2026-04-13 --type 支出 --category 餐饮 --amount 50 --note 午饭
"""

import csv
import argparse
import os
import sys
from datetime import datetime
from typing import Optional

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import setup_logger, get_log_level, validate_file_exists, ValidationError, FileError

# 默认数据目录（相对于技能目录）
DEFAULT_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
DEFAULT_FILE = os.path.join(DEFAULT_DATA_DIR, 'expenses.csv')

# 支持的类别（收入）
INCOME_CATEGORIES = ['工资', '兼职', '奖金', '投资', '利息', '分红', '退款', '其他收入']

# 支持的类别（支出）
EXPENSE_CATEGORIES = [
    '餐饮', '购物', '交通', '住房', '医疗', '教育',
    '娱乐', '通讯', '服装', '美容', '旅行', '烟酒',
    '饮料', '零食', '水果', '蔬菜', '日用', '办公',
    '家居', '数码', '家电', '汽车', '礼物', '捐赠',
    '长辈', '宠物', '花卉', '母婴', '运动', '图书',
    '游戏', '彩票', '社交', '礼金', '维修', '快递',
    '豆豆', '剪发', '学习', '证券', '还债', '其他'
]


def quick_add(date: datetime, trans_type: str, category: str, amount: float,
              note: str = '', csv_path: Optional[str] = None, logger=None) -> bool:
    """快速添加一笔记账记录。"""
    if csv_path is None:
        csv_path = DEFAULT_FILE

    if logger:
        logger.info(f"开始添加记账记录: {trans_type} {category} {amount}")

    # 验证类别
    all_categories = INCOME_CATEGORIES + EXPENSE_CATEGORIES
    if category not in all_categories:
        warning_msg = f"类别 '{category}' 不在常用列表中，但仍可添加"
        if logger:
            logger.warning(warning_msg)
        else:
            print(f"警告: {warning_msg}")

    # 验证金额
    try:
        amount = float(amount)
        if amount <= 0:
            error_msg = "金额必须大于 0"
            if logger:
                logger.error(error_msg)
            else:
                print(f"错误: {error_msg}")
            return False
    except ValueError:
        error_msg = f"无效的金额: {amount}"
        if logger:
            logger.error(error_msg)
        else:
            print(f"错误: {error_msg}")
        return False

    # 验证类型
    if trans_type not in ['收入', '支出']:
        error_msg = f"无效的收支类型: {trans_type}，应为 '收入' 或 '支出'"
        if logger:
            logger.error(error_msg)
        else:
            print(f"错误: {error_msg}")
        return False

    # 格式化日期
    date_str = date.strftime('%Y年%m月%d日')
    if logger:
        logger.debug(f"格式化日期: {date_str}")

    # 检查文件是否存在
    if not os.path.exists(csv_path):
        error_msg = f"数据文件不存在: {csv_path}"
        if logger:
            logger.error(error_msg)
            logger.info("请先运行 install.py 初始化")
        else:
            print(f"错误: {error_msg}")
            print(f"请先运行 install.py 初始化")
        return False

    if logger:
        logger.debug(f"读取数据文件: {csv_path}")

    # 读取现有数据
    rows = []
    fieldnames = None
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        for row in reader:
            rows.append(row)

    if logger:
        logger.debug(f"读取到 {len(rows)} 条现有记录")

    # 添加新行
    new_row = {
        '日期': date_str,
        '收支类型': trans_type,
        '类别': category,
        '账户': '未关联',
        '金额': str(amount),
        '备注': note
    }
    rows.insert(1, new_row)  # 插入到标题行后面（最新在前）

    if logger:
        logger.debug(f"插入新记录: {new_row}")

    # 写回文件
    with open(csv_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    success_msg = f"已添加: {date_str} {trans_type} {category} {amount}"
    if logger:
        logger.info(success_msg)
    else:
        print(success_msg)
    return True


def list_categories() -> None:
    """列出常用类别。"""
    print("\n常用收入类别:")
    print("   " + ", ".join(INCOME_CATEGORIES[:8]))

    print("\n常用支出类别:")
    for i in range(0, len(EXPENSE_CATEGORIES), 8):
        print("   " + ", ".join(EXPENSE_CATEGORIES[i:i+8]))


def main() -> None:
    parser = argparse.ArgumentParser(
        description='快速记账',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例：
  python quick_add.py --支出 餐饮 25 --备注 午饭
  python quick_add.py --收入 兼职 100
  python quick_add.py --list-categories

  # 指定数据文件
  python quick_add.py --data /path/to/expenses.csv --支出 餐饮 50

  # 调试模式
  python quick_add.py --支出 餐饮 25 --verbose
  python quick_add.py --支出 餐饮 25 --debug
'''
    )
    parser.add_argument('--data', type=str, default=None,
                       help='CSV 数据文件路径')
    parser.add_argument('--date', type=str, default=None,
                       help='日期 (YYYY-MM-DD)，默认今天')
    parser.add_argument('--type', type=str, default='支出',
                       help='收支类型 (收入/支出)')
    parser.add_argument('--支出', dest='category_expense', type=str,
                       help='支出类别')
    parser.add_argument('--收入', dest='category_income', type=str,
                       help='收入类别')
    parser.add_argument('--category', type=str,
                       help='类别（与 --支出/--收入 二选一）')
    parser.add_argument('--amount', type=float,
                       help='金额')
    parser.add_argument('--备注', '--note', dest='note', type=str, default='',
                       help='备注')
    parser.add_argument('--list-categories', action='store_true',
                       help='列出所有常用类别')
    parser.add_argument('--verbose', action='store_true',
                       help='显示详细信息')
    parser.add_argument('--debug', action='store_true',
                       help='显示调试信息')

    args = parser.parse_args()

    # 设置日志
    log_level = get_log_level(args.verbose, args.debug)
    logger = setup_logger('quick_add', log_level)

    if args.list_categories:
        list_categories()
        return

    # 确定类别
    category = args.category
    if args.category_expense:
        category = args.category_expense
        trans_type = '支出'
    elif args.category_income:
        category = args.category_income
        trans_type = '收入'
    elif args.category:
        category = args.category
        trans_type = args.type
    else:
        error_msg = "请指定类别（--支出 或 --收入 或 --category）"
        logger.error(error_msg)
        print(f"错误: {error_msg}")
        print("   使用 --list-categories 查看所有类别")
        return

    if args.amount is None:
        error_msg = "请指定金额（--amount）"
        logger.error(error_msg)
        print(f"错误: {error_msg}")
        return

    if args.date:
        try:
            date = datetime.strptime(args.date, '%Y-%m-%d')
            logger.debug(f"使用指定日期: {date}")
        except ValueError:
            error_msg = f"无效的日期格式: {args.date}，应为 YYYY-MM-DD"
            logger.error(error_msg)
            print(f"错误: {error_msg}")
            return
    else:
        date = datetime.now()
        logger.debug(f"使用当前日期: {date}")

    note = args.note or ''

    quick_add(date, trans_type, category, args.amount, note, args.data, logger)


if __name__ == '__main__':
    main()
