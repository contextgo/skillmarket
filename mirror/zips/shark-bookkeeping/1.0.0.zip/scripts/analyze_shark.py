#!/usr/bin/env python3
"""
鲨鱼记账分析脚本

对齐 shark_reports.md 报告结构，支持以下报告类型：
- 资产负债表 (Balance Sheet)
- 损益表 (Income Statement)
- 储蓄率报告 (Savings Rate)
- 月度支出报告 (Monthly Expenses)
- 净资产变化报告 (Net Worth Changes)

用法：
    python analyze_shark.py --data /path/to/expenses.csv --report <type>
    python analyze_shark.py --data /path/to/expenses.csv --report balance_sheet
    python analyze_shark.py --data /path/to/expenses.csv --report income_statement
    python analyze_shark.py --data /path/to/expenses.csv --report savings_rate
    python analyze_shark.py --data /path/to/expenses.csv --report monthly_expenses
    python analyze_shark.py --data /path/to/expenses.csv --report net_worth_change
    python analyze_shark.py --data /path/to/expenses.csv --all
"""

import csv
import argparse
import os
from datetime import datetime
from collections import defaultdict
from typing import Optional


# 默认数据目录
DEFAULT_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
DEFAULT_EXPENSES_FILE = os.path.join(DEFAULT_DATA_DIR, 'expenses.csv')
DEFAULT_ASSETS_FILE = os.path.join(DEFAULT_DATA_DIR, 'assets.csv')

# 资产类型
ASSET_TYPES = ['流动资产', '投资资产', '实物资产', '其他资产', '短期负债', '长期负债']

# 汇率配置
EXCHANGE_RATES = {
    'CNY': 1.0,
    'USD': 7.25,
    'HKD': 0.93,
    'EUR': 7.85,
    'GBP': 9.15,
    'JPY': 0.048
}

# 储蓄率基准
SAVINGS_RATE_BENCHMARKS = [
    (0, "危险 - 财务韧性有限"),
    (5, "低于平均 - 易受紧急情况影响"),
    (10, "平均 - 建立基础"),
    (20, "良好 - 财务状况强劲"),
    (30, "优秀 - 加速财富积累"),
    (50, "卓越 - 有提前退休潜力"),
]


def parse_date(date_str: str) -> Optional[datetime]:
    """解析中文日期格式：2026年04月12日 -> datetime"""
    try:
        date_str = date_str.strip().replace('年', '-').replace('月', '-').replace('日', '')
        return datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        return None


def load_expenses(filename: str) -> list[dict]:
    """加载支出数据。"""
    transactions = []
    if not os.path.exists(filename):
        return transactions
    with open(filename, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            date_str = row['日期'].strip()
            date = parse_date(date_str)
            if date is None:
                continue

            trans_type = row['收支类型'].strip()
            category = row['类别'].strip()
            account = row['账户'].strip()
            amount_str = row['金额'].strip()

            try:
                amount = float(amount_str)
            except ValueError:
                amount = 0.0

            note = row.get('备注', '').strip()

            transactions.append({
                'date': date,
                'year': date.year,
                'month': date.month,
                'type': trans_type,
                'category': category,
                'account': account,
                'amount': amount,
                'note': note
            })

    return transactions


def load_assets(filepath: str) -> list[dict]:
    """加载资产数据。"""
    assets = []
    if not os.path.exists(filepath):
        return assets
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                row['当前价值'] = float(row['当前价值'])
            except ValueError:
                row['当前价值'] = 0.0
            assets.append(row)
    return assets


def get_savings_rate_assessment(rate: float) -> str:
    """根据储蓄率返回评估。"""
    for threshold, message in SAVINGS_RATE_BENCHMARKS:
        if rate < threshold:
            return message
    return "卓越 - 有提前退休潜力"


# =============================================================================
# 报告生成函数
# =============================================================================

def report_balance_sheet(expenses_file: str, assets_file: str, year: Optional[int] = None) -> None:
    """
    资产负债表 (Balance Sheet)

    显示特定时间点的资产、负债和净资产状况。
    资产数据来自 assets.csv，支出数据用于计算期间储蓄累计。
    """
    assets = load_assets(assets_file)
    transactions = load_expenses(expenses_file)

    # 按币种汇总资产
    total_assets = defaultdict(float)
    total_liabilities = defaultdict(float)

    for asset in assets:
        currency = asset['币种']
        value = asset['当前价值']
        asset_type = asset['资产类型']

        value_cny = value * EXCHANGE_RATES.get(currency, 1)

        if '负债' in asset_type:
            total_liabilities[currency] += abs(value)
        else:
            total_assets[currency] += value_cny

    # 计算期间储蓄（作为净资产调整项）
    period_savings = 0.0
    for t in transactions:
        if year and t['year'] != year:
            continue
        if t['type'] == '收入':
            period_savings += t['amount']
        else:
            period_savings -= t['amount']

    total_assets_cny = sum(total_assets.values())
    total_liabilities_cny = sum(total_liabilities.values())
    net_worth = total_assets_cny - total_liabilities_cny + period_savings

    print("\n" + "=" * 70)
    print(f"资产负债表 {'(' + str(year) + ')' if year else '(累计)'}")
    print("=" * 70)

    print("\n【资产】")
    if total_assets:
        for currency, amount in sorted(total_assets.items(), key=lambda x: x[1], reverse=True):
            print(f"  {currency:6} {amount:>15,.2f}")
    else:
        print("  暂无资产记录")

    print(f"\n  资产总计: {total_assets_cny:>15,.2f} CNY")

    print("\n【负债】")
    if total_liabilities:
        for currency, amount in sorted(total_liabilities.items(), key=lambda x: x[1], reverse=True):
            print(f"  {currency:6} {amount:>15,.2f}")
    else:
        print("  暂无负债记录")

    print(f"\n  负债总计: {total_liabilities_cny:>15,.2f} CNY")

    print("\n" + "-" * 70)
    print(f"  净资产: {net_worth:>15,.2f} CNY")
    print("=" * 70)

    # 健康评估
    if net_worth < 0:
        print("\n【评估】净资产为负，债务超过资产，需要优先偿债。")
    elif net_worth < total_assets_cny * 0.2:
        print("\n【评估】净资产偏低，建议增加储蓄。")
    else:
        print("\n【评估】财务状况良好。")
    print()


def report_income_statement(expenses_file: str, year: Optional[int] = None) -> None:
    """
    损益表 (Income Statement)

    显示一段时间内的收入和支出，计算净收益/亏损。
    """
    transactions = load_expenses(expenses_file)

    monthly_data = defaultdict(lambda: {'income': 0.0, 'expense': 0.0})

    for t in transactions:
        if year and t['year'] != year:
            continue
        period = f"{t['year']}-{t['month']:02d}"
        if t['type'] == '收入':
            monthly_data[period]['income'] += t['amount']
        else:
            monthly_data[period]['expense'] += t['amount']

    if not monthly_data:
        print("\n未找到收入/支出数据\n")
        return

    print("\n" + "=" * 70)
    print(f"损益表 {'(' + str(year) + ')' if year else '(累计)'}")
    print("=" * 70)

    total_income = 0.0
    total_expense = 0.0

    print("\n【月度明细】")
    for period in sorted(monthly_data.keys()):
        data = monthly_data[period]
        net = data['income'] - data['expense']
        total_income += data['income']
        total_expense += data['expense']
        print(f"  {period}: 收入 {data['income']:>12,.2f} | 支出 {data['expense']:>12,.2f} | 净收益 {net:>12,.2f}")

    net_profit = total_income - total_expense

    print("\n" + "-" * 70)
    print(f"  收入总计: {total_income:>15,.2f}")
    print(f"  支出总计: {total_expense:>15,.2f}")
    print("-" * 70)
    print(f"  净收益:   {net_profit:>15,.2f}")
    print("=" * 70)

    # 健康评估
    if net_profit < 0:
        print("\n【评估】亏损状态，支出超过收入，需要控制支出。")
    elif net_profit < total_income * 0.1:
        print("\n【评估】净收益偏低，建议增加储蓄率。")
    else:
        print("\n【评估】盈利状态，财务增长良好。")
    print()


def report_savings_rate(expenses_file: str, year: Optional[int] = None) -> None:
    """
    储蓄率报告

    计算储蓄率并与基准对比。
    """
    transactions = load_expenses(expenses_file)

    total_income = 0.0
    total_expense = 0.0

    for t in transactions:
        if year and t['year'] != year:
            continue
        if t['type'] == '收入':
            total_income += t['amount']
        else:
            total_expense += t['amount']

    if total_income == 0:
        print("\n未找到收入数据，无法计算储蓄率。\n")
        return

    savings = total_income - total_expense
    savings_rate = (savings / total_income) * 100

    print("\n" + "=" * 50)
    print(f"储蓄率报告 {'(' + str(year) + ')' if year else '(累计)'}")
    print("=" * 50)
    print(f"总收入:    {total_income:>15,.2f}")
    print(f"总支出:    {total_expense:>15,.2f}")
    print(f"总储蓄:    {savings:>15,.2f}")
    print("-" * 50)
    print(f"储蓄率:    {savings_rate:>14.1f}%")
    print("-" * 50)
    print(f"评估:      {get_savings_rate_assessment(savings_rate)}")
    print("=" * 50)

    # 基准对比
    print("\n【基准参考】")
    print("  0-5%:   危险 - 财务韧性有限")
    print("  5-10%:  低于平均 - 易受紧急情况影响")
    print("  10-20:  平均 - 建立基础")
    print("  20-30%: 良好 - 财务状况强劲")
    print("  30-50%: 优秀 - 加速财富积累")
    print("  50%+:   卓越 - 有提前退休潜力")
    print()


def report_monthly_expenses(expenses_file: str, year: Optional[int] = None, top_n: int = 10) -> None:
    """
    月度支出报告

    按类别详细分析月度支出。
    """
    transactions = load_expenses(expenses_file)

    monthly_data = defaultdict(lambda: {'expenses': defaultdict(float), 'total': 0.0})

    for t in transactions:
        if year and t['year'] != year:
            continue
        if t['type'] == '支出':
            period = f"{t['year']}-{t['month']:02d}"
            monthly_data[period]['expenses'][t['category']] += t['amount']
            monthly_data[period]['total'] += t['amount']

    if not monthly_data:
        print("\n未找到支出数据\n")
        return

    print("\n" + "=" * 70)
    print(f"月度支出报告 {'(' + str(year) + ')' if year else '(累计)'}")
    print("=" * 70)

    for period in sorted(monthly_data.keys()):
        data = monthly_data[period]
        print(f"\n【{period}】总支出: {data['total']:,.2f}")
        print("-" * 50)

        sorted_cats = sorted(data['expenses'].items(), key=lambda x: x[1], reverse=True)
        for cat, amount in sorted_cats[:top_n]:
            pct = amount / data['total'] * 100 if data['total'] > 0 else 0
            bar = '#' * int(pct / 2)
            print(f"  {cat:12} {amount:>12,.2f}  ({pct:>5.1f}%)  {bar}")

        if len(sorted_cats) > top_n:
            others = sum(amt for _, amt in sorted_cats[top_n:])
            print(f"  {'其他':12} {others:>12,.2f}")

    print("\n" + "=" * 70)


def report_net_worth_change(expenses_file: str, assets_file: str, year: Optional[int] = None) -> None:
    """
    净资产变化报告

    追踪净资产随时间的增长或下降。
    由于 expenses.csv 只记录收支，净资产变化基于期间储蓄累计。
    """
    assets = load_assets(assets_file)
    transactions = load_expenses(expenses_file)

    # 初始净资产（来自 assets.csv）
    initial_net_worth = 0.0
    for asset in assets:
        currency = asset['币种']
        value = asset['当前价值']
        asset_type = asset['资产类型']
        value_cny = value * EXCHANGE_RATES.get(currency, 1)
        if '负债' in asset_type:
            initial_net_worth -= abs(value_cny)
        else:
            initial_net_worth += value_cny

    # 按月计算储蓄累计
    monthly_savings = defaultdict(float)
    for t in transactions:
        if year and t['year'] != year:
            continue
        period = f"{t['year']}-{t['month']:02d}"
        if t['type'] == '收入':
            monthly_savings[period] += t['amount']
        else:
            monthly_savings[period] -= t['amount']

    print("\n" + "=" * 70)
    print(f"净资产变化报告 {'(' + str(year) + ')' if year else '(累计)'}")
    print("=" * 70)

    print(f"\n期初净资产: {initial_net_worth:>15,.2f} CNY")
    print("\n【月度变化】")

    current_net_worth = initial_net_worth
    for period in sorted(monthly_savings.keys()):
        change = monthly_savings[period]
        current_net_worth += change
        pct = (change / current_net_worth * 100) if current_net_worth != 0 else 0
        direction = "+" if change > 0 else ""
        print(f"  {period}: {direction}{change:>12,.2f} | 净资产: {current_net_worth:>15,.2f} ({pct:+.1f}%)")

    print("\n" + "-" * 70)
    total_change = sum(monthly_savings.values())
    direction = "+" if total_change > 0 else ""
    print(f"  累计变化: {direction}{total_change:>15,.2f}")
    print(f"  期末净资产: {current_net_worth:>15,.2f} CNY")
    print("=" * 70)
    print()


def print_all_reports(expenses_file: str, assets_file: str, year: Optional[int] = None) -> None:
    """打印所有报告。"""
    report_balance_sheet(expenses_file, assets_file, year)
    report_income_statement(expenses_file, year)
    report_savings_rate(expenses_file, year)
    report_monthly_expenses(expenses_file, year)
    report_net_worth_change(expenses_file, assets_file, year)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='鲨鱼记账分析 - 对齐 shark_reports.md 报告结构',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
报告类型 (--report):
  balance_sheet      资产负债表
  income_statement  损益表
  savings_rate      储蓄率报告
  monthly_expenses  月度支出报告
  net_worth_change  净资产变化报告

示例：
  python analyze_shark.py --data expenses.csv --report balance_sheet
  python analyze_shark.py --data expenses.csv --report income_statement
  python analyze_shark.py --data expenses.csv --report savings_rate
  python analyze_shark.py --data expenses.csv --report monthly_expenses
  python analyze_shark.py --data expenses.csv --report net_worth_change
  python analyze_shark.py --data expenses.csv --all
  python analyze_shark.py --data expenses.csv --year 2026 --all
'''
    )

    parser.add_argument('--data', type=str, default=None,
                       help='支出数据文件路径 (默认: ./data/expenses.csv)')
    parser.add_argument('--assets', type=str, default=None,
                       help='资产数据文件路径 (默认: ./data/assets.csv)')
    parser.add_argument('--year', type=int, help='按年份过滤 (如 2026)')
    parser.add_argument('--report', type=str,
                       choices=['balance_sheet', 'income_statement', 'savings_rate',
                               'monthly_expenses', 'net_worth_change'],
                       help='报告类型')
    parser.add_argument('--all', action='store_true', help='显示所有报告')
    parser.add_argument('--top', type=int, default=10,
                       help='月度支出报告显示的类别数量 (默认: 10)')

    args = parser.parse_args()

    # 确定数据文件
    expenses_file = args.data or DEFAULT_EXPENSES_FILE
    assets_file = args.assets or DEFAULT_ASSETS_FILE

    if not os.path.exists(expenses_file):
        print(f"支出数据文件不存在: {expenses_file}")
        print("请先运行 install.py 初始化")
        return

    # 如果没有指定报告，显示所有
    if not args.report and not args.all:
        args.all = True

    if args.all:
        print_all_reports(expenses_file, assets_file, args.year)
        return

    # 执行特定报告
    if args.report == 'balance_sheet':
        report_balance_sheet(expenses_file, assets_file, args.year)
    elif args.report == 'income_statement':
        report_income_statement(expenses_file, args.year)
    elif args.report == 'savings_rate':
        report_savings_rate(expenses_file, args.year)
    elif args.report == 'monthly_expenses':
        report_monthly_expenses(expenses_file, args.year, args.top)
    elif args.report == 'net_worth_change':
        report_net_worth_change(expenses_file, assets_file, args.year)


if __name__ == '__main__':
    main()
