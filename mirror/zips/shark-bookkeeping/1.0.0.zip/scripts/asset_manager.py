#!/usr/bin/env python3
"""
资产管家脚本

用于管理个人资产数据，支持增删改查和资产分析。

用法：
    python asset_manager.py --data /path/to/assets.csv --list
    python asset_manager.py --data /path/to/assets.csv --add --type 流动资产 --name 工商银行 --value 50000
    python asset_manager.py --data /path/to/assets.csv --net-worth
"""

import csv
import argparse
import os
import json
from datetime import datetime
from collections import defaultdict
from typing import Optional

# 默认数据目录
DEFAULT_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
DEFAULT_FILE = os.path.join(DEFAULT_DATA_DIR, 'assets.csv')

# 默认字段
FIELDNAMES = ['资产类型', '资产名称', '资产账户', '币种', '当前价值', '更新时间', '备注']

# 资产类型
ASSET_TYPES = ['流动资产', '投资资产', '实物资产', '其他资产', '短期负债', '长期负债']

# 币种
CURRENCIES = ['CNY', 'USD', 'HKD', 'EUR', 'GBP', 'JPY']

# 汇率配置（警告：这些是示例值，实际应按需更新）
# 建议定期从可靠来源获取最新汇率
EXCHANGE_RATES = {
    'CNY': 1.0,
    'USD': 7.25,
    'HKD': 0.93,
    'EUR': 7.85,
    'GBP': 9.15,
    'JPY': 0.048
}

# 配置阈值
LIQUIDITY_MIN = 10  # 流动性资产建议最低比例(%)
LIQUIDITY_MAX = 50  # 流动性资产建议最高比例(%)
INVEST_MIN = 20      # 投资资产建议最低比例(%)
INVEST_MAX = 70      # 投资资产建议最高比例(%)


def ensure_file(filepath: str) -> None:
    """确保资产文件存在。"""
    if not os.path.exists(filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
        print(f"已创建资产文件: {filepath}")


def load_assets(filepath: str) -> list[dict]:
    """加载资产数据。"""
    ensure_file(filepath)
    assets = []
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                row['当前价值'] = float(row['当前价值'])
            except ValueError:
                row['当前价值'] = 0.0
            assets.append(row)
    return assets


def save_assets(assets: list[dict], filepath: str) -> None:
    """保存资产数据。"""
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(assets)


def add_asset(asset_type: str, name: str, account: str, currency: str, 
              value: float, note: str = '', filepath: Optional[str] = None) -> bool:
    """添加资产。"""
    if filepath is None:
        filepath = DEFAULT_FILE

    assets = load_assets(filepath)

    # 检查是否已存在
    for asset in assets:
        if asset['资产名称'] == name:
            print(f"资产 '{name}' 已存在，正在更新...")
            asset['当前价值'] = value
            asset['币种'] = currency
            asset['更新时间'] = datetime.now().strftime('%Y-%m-%d')
            asset['备注'] = note
            save_assets(assets, filepath)
            print(f"已更新: {name} = {value} {currency}")
            return True

    # 新增
    new_asset = {
        '资产类型': asset_type,
        '资产名称': name,
        '资产账户': account,
        '币种': currency,
        '当前价值': value,
        '更新时间': datetime.now().strftime('%Y-%m-%d'),
        '备注': note
    }
    assets.append(new_asset)
    save_assets(assets, filepath)
    print(f"已添加: {name} = {value} {currency}")
    return True


def delete_asset(name: str, filepath: Optional[str] = None) -> bool:
    """删除资产。"""
    if filepath is None:
        filepath = DEFAULT_FILE

    assets = load_assets(filepath)
    original_count = len(assets)
    assets = [a for a in assets if a['资产名称'] != name]

    if len(assets) == original_count:
        print(f"未找到资产 '{name}'")
        return False

    save_assets(assets, filepath)
    print(f"已删除: {name}")
    return True


def list_assets(filepath: Optional[str] = None) -> None:
    """列出所有资产。"""
    if filepath is None:
        filepath = DEFAULT_FILE

    assets = load_assets(filepath)

    if not assets:
        print("\n暂无资产记录")
        print("使用 --add 添加资产")
        return

    print("\n" + "="*70)
    print("资产列表")
    print("="*70)

    for asset in sorted(assets, key=lambda x: x['资产类型']):
        print(f"{asset['资产类型']:8} | {asset['资产名称']:15} | {asset['当前价值']:>12,.2f} {asset['币种']:4} | {asset['更新时间']}")

    print("="*70)


def calculate_net_worth(filepath: Optional[str] = None) -> float:
    """计算净资产。"""
    if filepath is None:
        filepath = DEFAULT_FILE

    assets = load_assets(filepath)

    total_assets = defaultdict(float)
    total_liabilities = defaultdict(float)

    for asset in assets:
        currency = asset['币种']
        value = asset['当前价值']
        asset_type = asset['资产类型']

        value_cny = value * EXCHANGE_RATES.get(currency, 1)

        if '负债' in asset_type:
            total_liabilities[currency] += abs(value)
        else:
            total_assets[currency] += value_cny

    print("\n" + "="*70)
    print("净资产计算")
    print("="*70)

    total_assets_cny = 0.0
    total_liabilities_cny = 0.0

    print("\n【资产】")
    for currency, amount in sorted(total_assets.items()):
        if currency == 'CNY':
            total_assets_cny += amount
            print(f"  {currency}: {amount:>15,.2f}")
        else:
            amount_in_cny = amount
            total_assets_cny += amount_in_cny
            print(f"  {currency}: {amount/EXCHANGE_RATES.get(currency,1):>15,.2f} (~{amount_in_cny:,.2f} CNY)")

    print(f"\n  总资产: {total_assets_cny:>15,.2f} CNY")

    print("\n【负债】")
    for currency, amount in sorted(total_liabilities.items()):
        if currency == 'CNY':
            total_liabilities_cny += amount
            print(f"  {currency}: {amount:>15,.2f}")
        else:
            amount_in_cny = amount * EXCHANGE_RATES.get(currency, 1)
            total_liabilities_cny += amount_in_cny
            print(f"  {currency}: {amount:>15,.2f} (~{amount_in_cny:,.2f} CNY)")

    print(f"\n  总负债: {total_liabilities_cny:>15,.2f} CNY")

    net_worth = total_assets_cny - total_liabilities_cny

    print("\n" + "-"*70)
    print(f"  净资产: {net_worth:>15,.2f} CNY")
    print("="*70)

    return net_worth


def show_allocation(filepath: Optional[str] = None) -> None:
    """显示资产配置。"""
    if filepath is None:
        filepath = DEFAULT_FILE

    assets = load_assets(filepath)

    if not assets:
        print("\n暂无资产记录")
        return

    categories = defaultdict(float)
    total_assets = 0.0
    total_liabilities = 0.0

    for asset in assets:
        currency = asset['币种']
        value = asset['当前价值']
        asset_type = asset['资产类型']

        value_cny = value * EXCHANGE_RATES.get(currency, 1)

        if '负债' in asset_type:
            total_liabilities += abs(value_cny)
        else:
            main_type = asset_type.split(':')[0] if ':' in asset_type else asset_type
            categories[main_type] += value_cny
            total_assets += value_cny

    print("\n" + "="*70)
    print("资产配置分析")
    print("="*70)

    total = total_assets + total_liabilities

    print("\n【资产分布】")
    for cat, amount in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        pct = (amount / total * 100) if total > 0 else 0
        bar = '#' * int(pct / 2)
        print(f"  {cat:10} {amount:>15,.2f}  {pct:>5.1f}%  {bar}")

    if total_liabilities > 0:
        pct = (total_liabilities / total * 100)
        bar = '#' * int(pct / 2)
        print(f"  {'负债':10} {total_liabilities:>15,.2f}  {pct:>5.1f}%  {bar}")

    print("\n【配置建议】")
    total_net = total_assets - total_liabilities

    liq_ratio = (categories.get('流动资产', 0) / total_net * 100) if total_net > 0 else 0
    if liq_ratio < LIQUIDITY_MIN:
        print(f"  警告: 流动性资产偏低 ({liq_ratio:.1f}%)，建议保持 {LIQUIDITY_MIN}-{LIQUIDITY_MAX}%")
    elif liq_ratio > LIQUIDITY_MAX:
        print(f"  提示: 流动性资产偏高 ({liq_ratio:.1f}%)，可考虑部分投资")
    else:
        print(f"  OK: 流动性资产比例合理 ({liq_ratio:.1f}%)")

    inv_ratio = (categories.get('投资资产', 0) / total_net * 100) if total_net > 0 else 0
    if inv_ratio < INVEST_MIN:
        print(f"  警告: 投资资产偏低 ({inv_ratio:.1f}%)，建议增加 {INVEST_MIN}-{INVEST_MAX}%")
    elif inv_ratio > INVEST_MAX:
        print(f"  警告: 投资资产偏高 ({inv_ratio:.1f}%)，注意风险分散")
    else:
        print(f"  OK: 投资资产比例合理 ({inv_ratio:.1f}%)")

    print("="*70)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='资产管家',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例：
  python asset_manager.py --data assets.csv --list
  python asset_manager.py --data assets.csv --add --type 流动资产 --name 工商银行 --value 50000
  python asset_manager.py --data assets.csv --net-worth
  python asset_manager.py --data assets.csv --delete 工商银行
'''
    )

    parser.add_argument('--data', type=str, default=None,
                       help='资产数据文件路径 (默认: ./data/assets.csv)')

    # 操作模式
    parser.add_argument('--add', action='store_true', help='添加资产')
    parser.add_argument('--delete', type=str, help='删除资产（资产名称）')
    parser.add_argument('--list', action='store_true', help='列出所有资产')
    parser.add_argument('--net-worth', action='store_true', help='计算净资产')
    parser.add_argument('--allocation', action='store_true', help='资产配置分析')
    parser.add_argument('--all', action='store_true', help='显示完整报告')

    # 添加参数
    parser.add_argument('--type', type=str, help='资产类型')
    parser.add_argument('--name', type=str, help='资产名称')
    parser.add_argument('--account', type=str, default='', help='资产账户')
    parser.add_argument('--currency', type=str, default='CNY', help='币种')
    parser.add_argument('--value', type=float, help='资产价值')
    parser.add_argument('--note', type=str, default='', help='备注')

    args = parser.parse_args()

    # 确定数据文件
    data_file = args.data or DEFAULT_FILE

    # 默认显示列表
    if not any([args.add, args.delete, args.list, args.net_worth, args.allocation, args.all]):
        args.list = True

    if args.add:
        if not args.name or args.value is None:
            print("错误: 添加资产需要 --name 和 --value")
            return
        if not args.type:
            args.type = '流动资产'
        add_asset(args.type, args.name, args.account, args.currency, args.value, args.note, data_file)

    if args.delete:
        delete_asset(args.delete, data_file)

    if args.list:
        list_assets(data_file)

    if args.allocation:
        show_allocation(data_file)

    if args.net_worth or args.all:
        calculate_net_worth(data_file)

    if args.all:
        show_allocation(data_file)


if __name__ == '__main__':
    main()
