# -*- coding: utf-8 -*-
"""
农发行贷款调查评估报告自动审核脚本 v2
"""

import sys
import re
import os
from docx import Document
from xml.etree import ElementTree as ET

# ---------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------

def extract_full_text(docx_path):
    """从 docx 提取完整文本（段落+表格）"""
    ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    texts = []
    try:
        with docx_path.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for para in root.iter(f'{{{ns}}}p'):
                parts = []
                for t in para.iter(f'{{{ns}}}t'):
                    if t.text:
                        parts.append(t.text)
                line = ''.join(parts).strip()
                if line:
                    texts.append(line)
            for tbl in root.iter(f'{{{ns}}}tbl'):
                for row in tbl.iter(f'{{{ns}}}tr'):
                    cells = []
                    for cell in row.iter(f'{{{ns}}}tc'):
                        parts = []
                        for t in cell.iter(f'{{{ns}}}t'):
                            if t.text:
                                parts.append(t.text)
                        ct = ''.join(parts).strip()
                        if ct:
                            cells.append(ct)
                    if cells:
                        texts.append(' | '.join(cells))
    except Exception:
        doc = Document(docx_path)
        texts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        for tbl in doc.tables:
            for row in tbl.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    texts.append(' | '.join(cells))
    return texts


def extract_tables(docx_path):
    """提取所有表格"""
    ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    tables = []
    try:
        with docx_path.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for tbl in root.iter(f'{{{ns}}}tbl'):
                rows_data = []
                for row in tbl.iter(f'{{{ns}}}tr'):
                    cells = []
                    for cell in row.iter(f'{{{ns}}}tc'):
                        parts = []
                        for t in cell.iter(f'{{{ns}}}t'):
                            if t.text:
                                parts.append(t.text)
                        cells.append(''.join(parts).strip())
                    rows_data.append(cells)
                tables.append(rows_data)
    except Exception:
        doc = Document(docx_path)
        for tbl in doc.tables:
            tables.append([[c.text.strip() for c in row.cells] for row in tbl.rows])
    return tables


# ---------------------------------------------------------------
# 数字提取工具
# ---------------------------------------------------------------

def extract_amount(text):
    """提取金额数字（亿/万/元），返回浮点数值（统一为亿元）"""
    amount_pattern = r'(\d+(?:\.\d+)?)\s*(亿|万|元)'
    matches = re.findall(amount_pattern, text)
    total = 0.0
    for num_str, unit in matches:
        num = float(num_str)
        if unit == '元':
            num /= 1e8
        elif unit == '万':
            num /= 10000
        total = num  # 取最后一个（通常最大）
    return total


# ---------------------------------------------------------------
# 审核规则
# ---------------------------------------------------------------

class LoanReportReviewer:
    """贷款调查评估报告审核器"""

    def __init__(self, docx_path):
        self.path = str(docx_path)
        self.full_text = ''
        self.paragraphs = []
        self.tables = []
        self.issues = {
            'format': [],
            'completeness': [],
            'logic': [],
            'numeric': [],
            'typo': [],
        }
        self._load()

    def _load(self):
        import pathlib
        p = pathlib.Path(self.path)
        self.paragraphs = extract_full_text(p)
        self.tables = extract_tables(p)
        self.full_text = '\n'.join(self.paragraphs)

    # ---------- 1. 格式规范性 ----------
    def check_format(self):
        """检查格式规范性"""
        issues = []
        text = self.full_text

        # 1. 标题层级规范性
        # 常见错误：章节编号跳跃（如"一、二、五"，缺了"三、四"）
        roman = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
                 '十一', '十二', '十三', '十四', '十五']
        # 1. 章节编号规范性（检测明显跳跃）
        roman_order = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
        roman_positions = {}
        for r in roman_order:
            m = re.search(rf'^{r}、', text)
            if m:
                roman_positions[r] = m.start()

        if len(roman_positions) >= 2:
            ordered = sorted(roman_positions.items(), key=lambda x: x[1])
            for k in range(len(ordered) - 1):
                cur_idx = roman_order.index(ordered[k][0])
                next_idx = roman_order.index(ordered[k + 1][0])
                if next_idx - cur_idx > 1 and next_idx - cur_idx <= 3:
                    missing = roman_order[cur_idx + 1:next_idx]
                    issues.append(f'章节编号疑似跳跃：缺少编号 {"、".join(missing)}')
                    break

        # 2. 数字格式规范性
        for i, para in enumerate(self.paragraphs):
            # 千分位格式（如3,000万元在中文报告中不规范）
            if re.search(r'\d{1,3}(,\d{3})+\s*(亿|万|元|%)', para):
                issues.append(f'段落{i+1}：数字使用千分位格式（如3,000万），中文报告建议改为万/亿为单位')
            # 连续标点
            if re.search(r'\d+\.\.+-?\d+', para):
                issues.append(f'段落{i+1}：数字格式错误（连续标点）')

        # 3. 全角百分号
        for i, para in enumerate(self.paragraphs):
            if re.search(r'\d+\uff05', para):
                issues.append(f'段落{i+1}：百分号应使用半角"%"，不应使用全角"％"')

        self.issues['format'] = issues
        return issues

    # ---------- 2. 内容完整性 ----------
    def check_completeness(self):
        """检查内容完整性"""
        issues = []
        text = self.full_text

        # 按《信贷审查办法（2023年修订）》及评审材料清单
        required_checks = [
            (r'借款人|借款企业|公司名称', '借款人基本情况（含名称、统一社会信用代码等）'),
            (r'营业执照|登记|公司章程', '借款人证照资质（营业执照、公司章程）'),
            (r'信用等级|评级|信用等级为', '信用评级情况（必填评级结论）'),
            (r'资产负债率', '财务指标（资产负债率）'),
            (r'担保|抵押|质押|保证', '担保情况（担保方式、担保人/物）'),
            (r'抵押|质押|保证', '担保方式不完整（需明确具体担保类型）', True),  # 告警，非强制
            (r'项目|建设|选址', '项目建设情况'),
            (r'贷款.*(期限|金额|利率)|额度.*年', '贷款方案（金额、期限、利率）'),
            (r'还款来源', '还款来源分析'),
            (r'风险|防控', '风险分析与防控措施'),
        ]

        for item in required_checks:
            pattern = item[0]
            msg = item[1]
            warn_only = len(item) > 2 and item[2]
            if not re.search(pattern, text):
                if warn_only:
                    issues.append(f'【提示】{msg}')
                else:
                    issues.append(f'缺少：{msg}')

        # 关键数据检查
        if not re.search(r'\d+\.?\d*\s*(亿|万)\s*元', text):
            issues.append('缺少明确的贷款金额（应注明金额单位）')
        if not re.search(r'\d+\s*年', text):
            issues.append('缺少明确的贷款期限')
        if not re.search(r'\d+\.?\d*\s*%|百分之', text):
            issues.append('缺少明确的利率信息')

        # 担保材料完整性（固定资产贷款）
        if re.search(r'固定资产|项目贷款|建设', text):
            guarantee_docs = [
                (r'抵押', '抵押担保调查情况表'),
                (r'保证|担保', '担保调查情况表/担保决议'),
            ]
            for pat, doc_name in guarantee_docs:
                if not re.search(pat, text):
                    issues.append(f'固定资产贷款缺少：{doc_name}')

        self.issues['completeness'] = issues
        return issues

    # ---------- 3. 逻辑一致性 ----------
    def check_logic(self):
        """检查逻辑一致性"""
        issues = []
        text = self.full_text

        # 1. 资产负债率逻辑校验
        # 提取法一：从文本中找"资产：XXX亿；负债：XXX亿；资产负债率：XX%"
        calcs = re.findall(
            r'资产[总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?[;；]?\s*'
            r'负债[总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?[;；]?\s*'
            r'资产负债率[：:]\s*(\d+\.?\d*)\s*%',
            text
        )
        if not calcs:
            # 尝试从表格中提取
            for tbl in self.tables:
                for row in tbl:
                    row_str = ' '.join(row)
                    if '资产负债率' in row_str:
                        calcs += re.findall(
                            r'(\d+\.?\d*)\s*(亿|万|元)?[;；\s]+(\d+\.?\d*)\s*(亿|万|元)?[;；\s]+(\d+\.?\d*)\s*%',
                            row_str
                        )

        if calcs:
            for m in calcs:
                # m = (资产, 单位, 负债, 单位, 比率) 或 (资产, 单位, 负债, 单位, 比率)
                if len(m) == 5:
                    asset_str, asset_unit, liab_str, liab_unit, ratio_str = m
                    try:
                        asset = float(asset_str) * (10000 if asset_unit == '万' else (1e8 if asset_unit == '元' else 1e8))
                        liab = float(liab_str) * (10000 if liab_unit == '万' else (1e8 if liab_unit == '元' else 1e8))
                        ratio = float(ratio_str)
                        if asset > 0:
                            calc_ratio = liab / asset * 100
                            if abs(calc_ratio - ratio) > 1.5:  # 误差>1.5%报警
                                issues.append(
                                    f'资产负债率计算错误：资产{asset_str}{asset_unit or "亿"}，'
                                    f'负债{liab_str}{liab_unit or "亿"}，'
                                    f'实际应为{calc_ratio:.1f}%，报告中为{ratio}%'
                                )
                    except Exception:
                        pass

        # 2. 速动比率校验
        quick = re.findall(
            r'速动比率[：:]\s*(\d+\.?\d*)\s*%',
            text
        )
        if quick:
            ca = re.findall(r'流动资产[：:]\s*(\d+\.?\d*)', text)
            inv = re.findall(r'存货[：:]\s*(\d+\.?\d*)', text)
            cl = re.findall(r'流动负债[：:]\s*(\d+\.?\d*)', text)
            if ca and inv and cl:
                try:
                    calc = (float(ca[0]) - float(inv[0])) / float(cl[0]) * 100
                    reported = float(quick[0])
                    if abs(calc - reported) > 1.5:
                        issues.append(
                            f'速动比率计算错误：流动资产{ca[0]}-存货{inv[0]}=速动资产，'
                            f'流动负债{cl[0]}，应={calc:.1f}%，报告={reported}%'
                        )
                except Exception:
                    pass

        # 3. 贷款+资本金+其他来源 ≈ 总投资（固定资产贷款）
        invest = re.findall(r'(?:项目)?总投资[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        loan = re.findall(r'贷款[金额额度]?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        capital = re.findall(r'(?:资本金|自筹)[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)

        if invest and loan:
            try:
                def to_yi(s, u):
                    n = float(s)
                    if u == '万': n /= 10000
                    elif u == '元': n /= 1e8
                    return n
                ti = to_yi(invest[0], invest[1] if len(invest) > 1 else None)
                la = to_yi(loan[0], loan[1] if len(loan) > 1 else None)
                ca = to_yi(capital[0], capital[1] if capital and len(capital) > 1 else None) if capital else 0
                if ca > 0 and abs(ti - la - ca) > 0.5:
                    issues.append(
                        f'资金构成不平衡：贷款{la:.2f}亿+资本金{ca:.2f}亿={la+ca:.2f}亿，'
                        f'与总投资{ti:.2f}亿相差{abs(ti-la-ca):.2f}亿'
                    )
            except Exception:
                pass

        # 4. 百分比合计校验（多个占比之和接近100%，简化版）
        # 不做自动判断（需要业务上下文），直接跳过

        # 5. 期限一致性
        term_mentioned = re.findall(r'贷款期限[：:]\s*(\d+)年', text)
        grace_mentioned = re.findall(r'宽限期[：:]\s*(\d+)年', text)
        repay_mentioned = re.findall(r'贷款期限[：:]\s*(\d+)年', text)
        if term_mentioned:
            try:
                term = int(term_mentioned[0])
                if grace_mentioned:
                    grace = int(grace_mentioned[0])
                    if grace >= term:
                        issues.append(f'宽限期{grace}年不应大于等于贷款期限{term}年')
                if repay_mentioned:
                    repay = int(repay_mentioned[0])
                    if repay != term:
                        issues.append(f'还款期{repay}年与贷款期限{term}年不一致')
            except Exception:
                pass

        self.issues['logic'] = issues
        return issues

    # ---------- 4. 数字准确性 ----------
    def check_numeric(self):
        """检查数字准确性"""
        issues = []
        text = self.full_text

        # 1. 提取所有金额并检查合理性
        amounts = re.findall(r'(\d+\.?\d*)\s*(亿|万|元)', text)
        large_nums = [(float(n), u) for n, u in amounts if float(n) > 1000 and u in ('亿', '万')]
        if large_nums:
            max_amt = max(float(n) for n, u in amounts)
            # 亿元单位
            for n, u in amounts:
                num = float(n) / (10000 if u == '万' else (1e8 if u == '元' else 1))
                if num > 10000:
                    issues.append(f'金额异常偏大：{n}{u}（超过合理范围，请核实）')

        # 2. 百分比范围合理性
        for i, para in enumerate(self.paragraphs):
            pcts = re.findall(r'\d+\.?\d*%', para)
            for pct in pcts:
                val = float(pct.rstrip('%'))
                if val > 200:
                    issues.append(f'段落{i+1}：百分比值异常：{pct}（超过合理范围）')
                if val < 0:
                    issues.append(f'段落{i+1}：百分比值不能为负：{pct}')

        # 3. 贷款期限合理性
        terms = re.findall(r'贷款期限[：:]\s*(\d+)年', text)
        for t in terms:
            try:
                term = int(t)
                if term > 50:
                    issues.append(f'贷款期限{term}年超过合理上限（一般不超过30-40年），请核实')
            except Exception:
                pass

        # 4. 资产负债率合理性
        ratios = re.findall(r'资产负债率[：:]\s*(\d+\.?\d*)%?', text)
        for r in ratios:
            try:
                ratio = float(r)
                if ratio > 100:
                    issues.append(f'资产负债率{ratio}%已超过100%，存在资不抵债风险，请核实')
                elif ratio > 90:
                    issues.append(f'资产负债率{ratio}%偏高（超过90%），偿债压力较大，请关注')
            except Exception:
                pass

        self.issues['numeric'] = issues
        return issues

    # ---------- 5. 文字质量 ----------
    def check_typo(self):
        """检查文字质量"""
        issues = []
        text = self.full_text
        lines = self.paragraphs

        # 常见错别字/别字
        # key: (wrong, correct, note)
        typo_map = {
            '保垒': ('堡垒', '堡垒'),
            '象贷': ('贷款', None),
            '象款': ('贷款', None),
            '象计': ('设计', None),
            '保内': ('期内', None),
            '截止': ('截至', '金融文书"截止"应改为"截至"'),
            '代款': ('贷款', None),
            '借代': ('借贷', None),
            '帐户': ('账户', None),
            '帐款': ('账款', None),
            '计定': ('核定', None),
            '计录': ('记录', None),
            '计办': ('核办', None),
            '按排': ('安排', None),
            '步暑': ('部署', None),
            '象限': ('年限', None),
            '及将': ('即将', None),
            '供献': ('贡献', None),
            '提拱': ('提供', None),
            '提拱': ('提供', None),
            '象定': ('核定', None),
            '象有': ('具有', None),
            '元元': ('元', None),
            '万万元': ('万元', None),
            '亿万': ('亿元', None),
        }

        found_typos = {}
        for wrong, (correct, note) in typo_map.items():
            matches = re.findall(re.escape(wrong), text)
            if matches:
                note_text = note if note else f'"{wrong}"应改为"{correct}"'
                found_typos[wrong] = (correct, note_text)

        for wrong, (correct, note) in found_typos.items():
            issues.append(f'错别字："{wrong}"{note}')

        # 括号规范性检查（仅检查明显混用）
        for i, para in enumerate(lines):
            # 全角括号内嵌半角，或反之
            if re.search(r'[（（][^）)]*\)[^）)]*[））]', para):
                issues.append(f'段落{i+1}：括号嵌套不规范（全角括号内包含半角括号或反之）')
                break

        # 数据表述冗余
        redundant_patterns = [
            (r'大约.{0,10}左右', '数据表述冗余：同时使用"大约"和"左右"'),
            (r'大概.{0,10}左右', '数据表述冗余：同时使用"大概"和"左右"'),
            (r'约为.{0,10}约为', '数据表述重复：同时使用"约为"两次'),
            (r'基本上都', '表述不当："基本上都"建议改为"基本都"或"均"'),
        ]
        for pat, msg in redundant_patterns:
            if re.search(pat, text):
                issues.append(msg)

        self.issues['typo'] = issues
        return issues

    # ---------- 主审核流程 ----------
    def review(self):
        """执行全部审核"""
        import pathlib
        path_name = pathlib.Path(self.path).name
        print(f'开始审核：{path_name}')
        print(f'段落数：{len(self.paragraphs)}，表格数：{len(self.tables)}')
        print('─' * 60)

        self.check_format()
        self.check_completeness()
        self.check_logic()
        self.check_numeric()
        self.check_typo()

        self._print_report()

    def _print_report(self):
        """打印审核报告"""
        dim_names = {
            'format': '【格式规范性】',
            'completeness': '【内容完整性】',
            'logic': '【逻辑一致性】',
            'numeric': '【数字准确性】',
            'typo': '【文字质量】',
        }

        total_issues = 0
        for dim, issues in self.issues.items():
            total_issues += len(issues)
            name = dim_names[dim]
            if issues:
                print(f'\n{name} 发现 {len(issues)} 处问题')
                for issue in issues:
                    print(f'  - {issue}')
            else:
                print(f'\n{name} ✓ 未发现问题')

        print('\n' + '─' * 60)
        if total_issues == 0:
            print('【总体评价】✓ 通过 — 报告质量良好')
        elif total_issues <= 5:
            print(f'【总体评价】⚠ 需修改 — 共 {total_issues} 处问题，请参照上方详情修改')
        else:
            print(f'【总体评价】✗ 发现 {total_issues} 处问题，建议对照审核标准全面修改')


# ---------------------------------------------------------------
# 入口
# ---------------------------------------------------------------

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('用法: python review_report.py <报告.docx路径>')
        sys.exit(1)

    docx_path = sys.argv[1]
    if not os.path.exists(docx_path):
        print(f'错误：文件不存在 - {docx_path}')
        sys.exit(1)

    reviewer = LoanReportReviewer(docx_path)
    reviewer.review()
