# -*- coding: utf-8 -*-
"""
农发行贷款调查评估报告自动审核脚本 v4
基于以下制度文件：
- 信贷主审查人专业资质考试题库（案例分析，8个典型算例）
- 信贷审查办法（2023年修订）农发银规章〔2023〕26号
- 客户统一授信限额核定细则（2024年修订）
- 主要押品类型具体接受标准（2024年）
- 保证担保实施细则（2024年修订）
- 贷款子产品管理细则（82个子产品完整版）
- 固定资产/流动资金贷款评审指引

更新说明（v4）：
- 补全82个子产品完整准入规则（AL限值、信用等级、注册资本）
- 新增"表间数据校验"维度：表格与正文数字一致性核查
- 优化产品识别逻辑，支持更多子产品关键词匹配
"""

import sys
import re
import os
from xml.etree import ElementTree as ET

# ---------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------

def extract_full_text(docx_path):
    ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    texts = []
    try:
        with docx_path.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for para in root.iter(f'{{{ns}}}p'):
                parts = [t.text for t in para.iter(f'{{{ns}}}t') if t.text]
                line = ''.join(parts).strip()
                if line:
                    texts.append(line)
            for tbl in root.iter(f'{{{ns}}}tbl'):
                for row in tbl.iter(f'{{{ns}}}tr'):
                    cells = []
                    for cell in row.iter(f'{{{ns}}}tc'):
                        ct = ''.join(t.text for t in cell.iter(f'{{{ns}}}t') if t.text).strip()
                        if ct:
                            cells.append(ct)
                    if cells:
                        texts.append(' | '.join(cells))
    except Exception:
        from docx import Document
        doc = Document(docx_path)
        texts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        for tbl in doc.tables:
            for row in tbl.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    texts.append(' | '.join(cells))
    return texts


def extract_tables(docx_path):
    ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    tables = []
    try:
        with docx_path.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for tbl in root.iter(f'{{{ns}}}tbl'):
                rows_data = []
                for row in tbl.iter(f'{{{ns}}}tr'):
                    cells = []
                    for cell in row.iter(f'{{{ns}}}tc'):
                        parts = []
                        for t in cell.iter(f'{{{ns}}}t'):
                            if t.text:
                                parts.append(t.text)
                        cells.append(''.join(parts).strip())
                    rows_data.append(cells)
                tables.append(rows_data)
    except Exception:
        from docx import Document
        doc = Document(docx_path)
        for tbl in doc.tables:
            tables.append([[c.text.strip() for c in row.cells] for row in tbl.rows])
    return tables


def to_num(s, unit=''):
    """将字符串数字转换为亿元数值"""
    try:
        n = float(s)
        if unit in ('万',):
            n /= 10000
        elif unit in ('元',):
            n /= 1e8
        return n
    except Exception:
        return None


def extract_num_with_unit(text):
    """从文本中提取数字和单位，返回 (数值, 单位) 列表"""
    results = []
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*(亿|万|元|%)?', text):
        results.append((m.group(1), m.group(2) or ''))
    return results


# ---------------------------------------------------------------
# 农发行关键参数常量（来自IMA知识库制度文件）
# ---------------------------------------------------------------

# 押品最高抵质押率（来自《主要押品类型具体接受标准》）
COLLATERAL_MAX_RATES = {
    '商品房': 70.0,
    '住房': 70.0,
    '商业用房': 60.0,
    '土地': 70.0,
    '应收账款': 60.0,
    '存单': 90.0,
    '国债': 90.0,
    '标准厂房': 70.0,
    '机器设备': 50.0,
    '车辆': 60.0,
}

# 82个贷款子产品完整准入规则（来自《贷款子产品管理细则》2024年）
# 格式：(注册资本下限_万, 资产负债率上限%, 信用等级下限, 备注)
# 注册资本：None=无硬性要求；资产负债率：第一数字为上年末AL上限，第二数字为融资后AL上限
# 信用等级：L11=至少L11级(含)，L12=至少L12级(含)
PRODUCT_RULES = {
    # ========== 中央储备类（1-12）==========
    '中央储备粮油':   (None, (None, None),   'L12', '信用贷款，期限≤3年'),
    '国家储备棉':     (None, (None, None),   'L12', '信用贷款，期限≤3年'),
    '国家储备肉':     (1000,  (80, None),   'L12', '注册资本≥1000万，AL≤80%'),
    '国家储备糖':     (None,  (80, None),   'L12', 'L12级以上'),
    '国家储备化肥':   (2000,  (90, None),   'L11', '注册资本≥2000万，融资后AL≤90%'),
    '国家储备羊毛':   (2000,  (80, None),   'L11', '注册资本≥2000万，融资后AL≤80%'),
    '国家战略物资储备': (None, (None, None), 'L11', 'L11级以上'),
    '地方储备粮棉油':  (None, (None, None),  'L12', '信用贷款'),
    '地方储备糖':      (2000,  (80, None),   'L11', '注册资本≥2000万'),
    '地方储备化肥':    (2000,  (90, None),   'L11', '注册资本≥2000万，融资后AL≤90%'),
    '地方储备肉':      (2000,  (80, None),   'L11', '注册资本≥2000万'),
    '市县储备':        (5000,  (80, None),   'L11', '注册资本≥5000万'),
    '政策性挂账':       (None, (None, None),  'L12', '信用贷款'),
    '战略储备应急设施': (None,  (80, 85),    'L12', 'AL≤80%，融资后≤85%'),

    # ========== 粮棉油购销（21-23）==========
    '粮棉油收购':     (None,  (75, 85),     'L12', '粮油收购：融资后AL≤75%，国企≤85%'),
    '粮棉油调销':     (None,  (75, 85),     'L12', '融资后AL≤75%，国企≤85%'),
    '粮棉油流通':     (None,  (75, 85),     'L12', '融资后AL≤75%，国企≤85%'),

    # ========== 粮棉油种植/加工（32-33）==========
    '粮棉油种植':     (None,  (75, 85),     'L12', '流动资金：自有≥10%；固定资产：自有≥20%'),
    '粮棉油加工':     (None,  (75, 85),     'L12', '棉花加工：净资产≥2亿，AL≤70%，自有≥30%，纱锭≥15万锭'),

    # ========== 种业振兴（30-32）==========
    '高标准农田':     (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '耕地治理与保护':  (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '耕地流转':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '耕地后备资源':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农用地整理':      (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '良种繁育':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '种业生产':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '种业基地建设':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 农产品种养加（34-38）==========
    '重要农产品':      (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%（生猪、牛羊、食糖、天然橡胶）'),
    '其他农产品种养加': (None,  (70, 75),    'L12', 'AL≤70%，融资后≤75%'),
    '农产品仓储物流':  (None,  (80, 85),     'L12', '农产品占比≥50%，AL≤80%，融资后≤85%'),
    '农产品购销':      (None,  (70, 75),     'L12', 'AL≤70%，融资后≤75%'),
    '农产品交易市场':  (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 农业科技与装备（40-42）==========
    '设施农业':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农业机械装备':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农业科技':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 农业生产资料（43-45）==========
    '化肥流通':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农兽药':          (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农业塑料制品':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 海洋涉农（46）==========
    '海洋渔业':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 精准帮扶防返贫（47-49）==========
    '精准帮扶':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '精准防返贫':      (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%；五项财务指标至少3项达行业均值'),
    '涉农线上小微':    (None,  (None, None),  'L12', '普惠型小微企业，线上自动化审批'),

    # ========== 水利建设（50-55）==========
    '农田水利':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '防洪排水':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '水资源优化配置':  (None,  (80, 85),    'L11', 'AL≤80%，融资后≤85%'),
    '城乡供水':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '水生态保护':      (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '水能资源':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),

    # ========== 交通设施（56-59）==========
    '国省道建设':      (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；强农惠农高速县域里程≥60%'),
    '农村公路':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；项目须纳入交通规划'),
    '水运设施':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；严禁支持工业港'),
    '其他交通设施':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),

    # ========== 政策性住房（60-63）==========
    '保障性住房':      (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '老旧小区改造':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；期限≤15-20年'),
    '棚户区改造':      (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；期限≤5年'),
    '特定住房':        (None,  (None, None),  'L11', '按具体产品制度执行'),

    # ========== 县域产业园区（64-66）==========
    '农业产业园区':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；农林牧渔企业≥50%'),
    '涉农产业园区':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%；农业及相关企业≥50%'),
    '农村特色小镇':    (None,  (75, 80),     'L11', 'AL≤75%，融资后≤80%；须纳入省级特色小镇名单'),

    # ========== 农村土地整治（67-69）==========
    '全域土地':        (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农村建设用地整理': (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%；不得支持土地收储'),
    '服务土地改革':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),

    # ========== 新型城镇化（70-73）==========
    '县域公用':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '县域公共服务':    (None,  (75, 80),     'L11', 'AL≤75%，融资后≤80%'),
    '县域商业体系':    (None,  (75, 80),     'L11', 'AL≤75%，融资后≤80%'),

    # ========== 改善农村人居环境（73-75）==========
    '村庄环境':        (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '农民居住条件':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '传统村落保护':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),

    # ========== 生态环保（76-82）==========
    '农村清洁能源生产': (None, (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '农村能源网络':    (None,  (80, 85),     'L11', 'AL≤80%，融资后≤85%'),
    '农村清洁能源储存': (None,  (70, 75),    'L11', 'AL≤70%，融资后≤75%'),
    '农业林草保护':    (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农村生态环境整治': (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '农业生产废弃物':  (None,  (80, 85),     'L12', 'AL≤80%，融资后≤85%'),
    '生态公园建设':    (None,  (70, 75),     'L11', 'AL≤70%，融资后≤75%'),
}

# 子产品识别关键词（优先匹配顺序）
PRODUCT_KEYWORDS = {
    # 储备类
    '中央储备粮油':   ['中央储备粮油', '中央储备粮'],
    '粮棉油收购':     ['粮棉油收购', '收购贷款'],
    '粮棉油流通':     ['粮棉油流通', '粮棉油购销'],
    '粮棉油加工':     ['粮棉油加工'],
    '粮棉油种植':     ['粮棉油种植'],
    '高标准农田':     ['高标准农田', '高标准农田建设'],
    '设施农业':       ['设施农业'],
    '精准帮扶':       ['精准帮扶', '精准扶贫'],
    '精准防返贫':     ['精准防返贫', '防止返贫'],
    '农田水利':       ['农田水利'],
    '防洪排水':       ['防洪排水', '防洪排涝'],
    '水资源优化配置': ['水资源优化配置', '引调水'],
    '城乡供水':       ['城乡供水', '供水工程'],
    '水生态保护':     ['水生态', '水生态保护'],
    '水能资源':       ['水能资源', '水电站', '抽水蓄能'],
    '农村公路':       ['农村公路', '县道', '乡道', '村道'],
    '保障性住房':     ['保障性住房', '保障性租赁住房', '租赁住房'],
    '老旧小区改造':   ['老旧小区改造'],
    '棚户区改造':     ['棚户区改造', '城市危旧房'],
    '农业产业园区':   ['农业产业园区'],
    '涉农产业园区':   ['涉农产业园区'],
    '农村特色小镇':   ['农村特色小镇'],
    '全域土地':       ['全域土地', '全域综合整治'],
    '农村建设用地整理': ['农村建设用地整理', '农村建设闲置地'],
    '服务土地改革':   ['服务农村土地制度改革', '土地制度改革'],
    '县域公用':       ['县域公用', '县域基础设施'],
    '县域公共服务':   ['县域公共服务', '公共服务设施'],
    '县域商业体系':   ['县域商业体系', '商业体系'],
    '村庄环境':       ['村庄环境', '人居环境', '村庄整治'],
    '农民居住条件':   ['农民居住', '农房改造', '农村危房'],
    '传统村落保护':   ['传统村落'],
    '农村清洁能源生产': ['清洁能源', '农村清洁能源'],
    '农村清洁能源储存': ['清洁能源储存', '储能'],
    '农村生态环境整治': ['生态环境整治', '农村生态环境'],
    '农业生产废弃物': ['农业生产废弃物', '废弃物'],
    '生态公园建设':   ['生态公园'],
    '农业林草保护':   ['林草保护', '林业保护'],
    '化肥流通':       ['化肥流通', '化肥'],
    '农兽药':         ['农兽药'],
    '农业塑料制品':   ['农业塑料'],
    '海洋渔业':       ['海洋渔业'],
    '重要农产品':     ['重要农产品', '生猪', '牛羊', '食糖', '天然橡胶'],
    '其他农产品种养加': ['农产品种养加'],
    '农产品仓储物流':  ['农产品仓储', '冷链'],
    '农产品购销':     ['农产品购销'],
    '农产品交易市场':  ['农产品交易市场', '批发交易市场'],
    '农业科技':       ['农业科技', '农业科研'],
    '农业机械装备':   ['农业机械', '农机'],
    '种业生产':       ['种业生产', '种子生产'],
    '良种繁育':       ['良种繁育', '种业'],
    '种业基地建设':   ['种业基地'],
    '耕地流转':       ['耕地流转'],
    '耕地治理与保护':  ['耕地治理', '耕地保护'],
    '涉农线上小微':   ['涉农小微', '普惠小微', '农发快贷'],
}

# 中期流动资金贷款要求借款人信用等级L11（含）以上（考试题库案例8）
MEDIUM_TERM_LOAN_MIN_GRADE = 11


# ---------------------------------------------------------------
# 审核器
# ---------------------------------------------------------------

class LoanReportReviewer:
    """农发行贷款调查评估报告审核器"""

    def __init__(self, docx_path):
        self.path = str(docx_path)
        self.full_text = ''
        self.paragraphs = []
        self.tables = []
        self.issues = {
            'format': [],
            'completeness': [],
            'logic': [],
            'numeric': [],
            'typo': [],
            'credit_limit': [],
            'collateral': [],
            'guarantee': [],
            'product_req': [],
            'table_consistency': [],  # 新增：表间数据校验
        }
        self._load()

    def _load(self):
        import pathlib
        p = pathlib.Path(self.path)
        self.paragraphs = extract_full_text(p)
        self.tables = extract_tables(p)
        self.full_text = '\n'.join(self.paragraphs)

    # ============================================================
    # 1. 格式规范性
    # ============================================================
    def check_format(self):
        issues = []
        text = self.full_text

        # 章节编号规范性
        roman_order = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
        roman_pos = {}
        for r in roman_order:
            m = re.search(rf'^{r}、', text)
            if m:
                roman_pos[r] = m.start()
        if len(roman_pos) >= 2:
            ordered = sorted(roman_pos.items(), key=lambda x: x[1])
            for k in range(len(ordered) - 1):
                ci, ni = roman_order.index(ordered[k][0]), roman_order.index(ordered[k+1][0])
                if ni - ci > 1 and ni - ci <= 3:
                    missing = roman_order[ci+1:ni]
                    issues.append(f'章节编号疑似跳跃：缺少编号 {"、".join(missing)}')
                    break

        # 千分位格式
        for i, para in enumerate(self.paragraphs):
            if re.search(r'\d{1,3}(,\d{3})+\s*(亿|万|元|%)', para):
                issues.append(f'段落{i+1}：数字使用千分位格式（如3,000万），中文报告建议改为万/亿为单位')
            if re.search(r'\d+\.\.+-?\d+', para):
                issues.append(f'段落{i+1}：数字格式错误（连续标点）')

        # 全角百分号
        for i, para in enumerate(self.paragraphs):
            if re.search(r'\d+\uff05', para):
                issues.append(f'段落{i+1}：百分号应使用半角"%"，不应使用全角"％"')

        self.issues['format'] = issues
        return issues

    # ============================================================
    # 2. 内容完整性
    # ============================================================
    def check_completeness(self):
        issues = []
        text = self.full_text

        required = [
            (r'借款人|借款企业|公司名称|企业名称', '借款人基本情况（含名称、统一社会信用代码）'),
            (r'营业执照|登记证书|公司章程', '借款人证照资质'),
            (r'信用等级|评级为|信用等级为L', '信用评级情况（必填评级结论）'),
            (r'资产负债率', '财务指标（资产负债率）'),
            (r'担保|抵押|质押|保证', '担保情况'),
            (r'项目|建设|选址', '项目建设情况'),
            (r'贷款.*期限|贷款期限|额度.*年', '贷款方案（金额、期限、利率）'),
            (r'还款来源', '还款来源分析'),
            (r'风险|防控|缓释', '风险分析与防控措施'),
        ]
        for pat, name in required:
            if not re.search(pat, text):
                issues.append(f'缺少：{name}')

        if not re.search(r'\d+\.?\d*\s*(亿|万)\s*元', text):
            issues.append('缺少明确的贷款金额')
        if not re.search(r'\d+\s*年', text):
            issues.append('缺少明确的贷款期限')
        if not re.search(r'\d+\.?\d*\s*%', text):
            issues.append('缺少明确的利率信息')

        if re.search(r'固定资产|项目贷款|建设', text):
            if not re.search(r'抵押|保证|质押', text):
                issues.append('固定资产贷款缺少担保方式说明')

        self.issues['completeness'] = issues
        return issues

    # ============================================================
    # 3. 逻辑一致性（含数字计算）
    # ============================================================
    def check_logic(self):
        issues = []
        text = self.full_text

        # 1. 资产负债率校验
        calcs = re.findall(
            r'资产[总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?'
            r'[;；\s]+[负债][总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?'
            r'[;；\s]+资产负债率[：:]\s*(\d+\.?\d*)\s*%',
            text
        )
        for m in calcs:
            if len(m) == 6:
                a_val, a_unit, l_val, l_unit, ratio_str = m[0], m[1], m[2], m[3], m[5]
                try:
                    asset = to_num(a_val, a_unit or '亿')
                    liab = to_num(l_val, l_unit or '亿')
                    ratio = float(ratio_str)
                    if asset and liab and asset > 0:
                        calc_ratio = liab / asset * 100
                        if abs(calc_ratio - ratio) > 1.5:
                            issues.append(
                                f'资产负债率计算错误：资产{a_val}{a_unit or "亿"}，'
                                f'负债{l_val}{l_unit or "亿"}，应为{calc_ratio:.1f}%，报告为{ratio}%'
                            )
                except Exception:
                    pass

        # 2. 速动比率
        quick_list = re.findall(r'速动比率[：:]\s*(\d+\.?\d*)\s*%?', text)
        if quick_list:
            ca = re.findall(r'流动资产[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            inv = re.findall(r'存货[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            cl = re.findall(r'流动负债[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            if ca and inv and cl:
                try:
                    calc = (to_num(ca[0][0], ca[0][1] or '亿') - to_num(inv[0][0], inv[0][1] or '亿')) / to_num(cl[0][0], cl[0][1] or '亿') * 100
                    reported = float(quick_list[0].rstrip('%'))
                    if abs(calc - reported) > 1.5:
                        issues.append(
                            f'速动比率计算错误：流动资产{ca[0][0]}{ca[0][1] or "亿"}-存货{inv[0][0]}{inv[0][1] or "亿"}=速动资产，'
                            f'流动负债{cl[0][0]}{cl[0][1] or "亿"}，应≈{calc:.1f}%，报告={reported}%'
                        )
                except Exception:
                    pass

        # 3. 资金构成（贷款+资本金≈总投资）
        invest = re.findall(r'项目?总投资[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        loan = re.findall(r'贷款[金额额度]?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        capital = re.findall(r'(?:资本金|自筹)[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        if invest and loan:
            try:
                ti = to_num(invest[0][0], invest[0][1] or '亿')
                la = to_num(loan[0][0], loan[0][1] or '亿')
                ca = to_num(capital[0][0], capital[0][1] or '亿') if capital else 0
                if ti and la and ca > 0:
                    if abs(ti - la - ca) > 0.5 and abs(ti - la - ca) / ti > 0.05:
                        issues.append(
                            f'资金构成不平衡：贷款{la:.2f}亿+资本金{ca:.2f}亿={la+ca:.2f}亿，'
                            f'总投资{ti:.2f}亿，差距{abs(ti-la-ca):.2f}亿'
                        )
            except Exception:
                pass

        # 4. 期限一致性
        term = re.findall(r'贷款期限[：:]\s*(\d+)年', text)
        grace = re.findall(r'宽限期[：:]\s*(\d+)年', text)
        if term:
            try:
                t = int(term[0])
                if grace:
                    g = int(grace[0])
                    if g >= t:
                        issues.append(f'宽限期{g}年不应≥贷款期限{t}年')
            except Exception:
                pass

        self.issues['logic'] = issues
        return issues

    # ============================================================
    # 4. 数字准确性
    # ============================================================
    def check_numeric(self):
        issues = []
        text = self.full_text

        ratios = re.findall(r'资产负债率[：:]\s*(\d+\.?\d*)%?', text)
        for r in ratios:
            try:
                rv = float(r)
                if rv > 100:
                    issues.append(f'资产负债率{rv}%超过100%，存在资不抵债风险，请核实')
                elif rv > 90:
                    issues.append(f'资产负债率{rv}%偏高（超过90%），偿债压力较大，请关注')
            except Exception:
                pass

        terms = re.findall(r'贷款期限[：:]\s*(\d+)年', text)
        for t in terms:
            try:
                tv = int(t)
                if tv > 50:
                    issues.append(f'贷款期限{tv}年超过合理上限（一般不超过40年），请核实')
            except Exception:
                pass

        for i, para in enumerate(self.paragraphs):
            pcts = re.findall(r'\d+\.?\d*%', para)
            for pct in pcts:
                try:
                    pv = float(pct.rstrip('%'))
                    if pv > 200:
                        issues.append(f'段落{i+1}：百分比值异常：{pct}（超过合理范围）')
                    if pv < 0:
                        issues.append(f'段落{i+1}：百分比值不能为负：{pct}')
                except Exception:
                    pass

        self.issues['numeric'] = issues
        return issues

    # ============================================================
    # 5. 文字质量
    # ============================================================
    def check_typo(self):
        issues = []
        text = self.full_text

        typo_map = {
            '截止': '截至',
            '帐户': '账户',
            '帐款': '账款',
            '代款': '贷款',
            '借代': '借贷',
            '保垒': '堡垒',
            '按排': '安排',
            '计定': '核定',
            '象限': '年限',
            '象计': '设计',
            '象定': '核定',
            '象有': '具有',
            '及将': '即将',
            '提拱': '提供',
            '供献': '贡献',
            '步暑': '部署',
            '亿万元': '亿元',
            '万万元': '万元',
            '元元': '元',
        }

        found = {}
        for wrong, correct in typo_map.items():
            if re.search(re.escape(wrong), text):
                found[wrong] = correct

        for wrong, correct in found.items():
            issues.append(f'错别字/用词错误："{wrong}"应改为"{correct}"')

        if re.search(r'大约.{0,10}左右', text):
            issues.append('数据表述冗余："大约"和"左右"不应同时使用')
        if re.search(r'大概.{0,10}左右', text):
            issues.append('数据表述冗余："大概"和"左右"不应同时使用')
        if re.search(r'约为.{0,10}约为', text):
            issues.append('数据表述重复：同时使用两次"约为"')

        self.issues['typo'] = issues
        return issues

    # ============================================================
    # 6. 统一授信
    # ============================================================
    def check_credit_limit(self):
        issues = []
        text = self.full_text

        eco_keywords = ['生态', '环境', '保护', 'EOD', '污水', '垃圾', '固废']
        has_eco = any(kw in text for kw in eco_keywords)
        asset_liab = re.findall(r'资产负债率[：:]\s*(\d+\.?\d*)%?', text)

        for r_str in asset_liab:
            try:
                rv = float(r_str)
                if has_eco:
                    if rv > 85:
                        issues.append(f'资产负债率{rv}%超过生态环境贷款融资后上限（85%），不符合准入')
                    elif rv > 80:
                        issues.append(f'【提示】资产负债率{rv}%接近生态环境贷款上限（80%/85%），请确认是否含新增融资')
                else:
                    if rv > 85:
                        issues.append(f'资产负债率{rv}%偏高（超过85%），偿债压力较大，请关注')
            except Exception:
                pass

        if re.search(r'净资产法|统一授信限额|授信.*测算', text):
            limit_vals = re.findall(r'统一授信限额[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            net_assets = re.findall(r'净资产[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)

            if net_assets and limit_vals:
                try:
                    na = to_num(net_assets[0][0], net_assets[0][1] or '亿')
                    lv = to_num(limit_vals[0][0], limit_vals[0][1] or '亿')
                    if na and lv:
                        if lv > na * 2.5:
                            issues.append(f'授信限额{lv:.1f}亿明显超过净资产{na:.1f}亿（2.5倍以上），请核实')
                        elif lv < na * 0.1:
                            issues.append(f'授信限额{lv:.1f}亿与净资产{na:.1f}亿比例异常偏低，请核实')
                except Exception:
                    pass

        na_matches = re.findall(r'有效净资产[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        if na_matches:
            try:
                na_val = to_num(na_matches[0][0], na_matches[0][1] or '亿')
                if na_val and na_val < 0:
                    issues.append(f'有效净资产为负数{na_val:.1f}亿，测算结果无效，请核实')
            except Exception:
                pass

        self.issues['credit_limit'] = issues
        return issues

    # ============================================================
    # 7. 押品合规
    # ============================================================
    def check_collateral(self):
        issues = []
        text = self.full_text

        # 商品房抵押率检查
        if re.search(r'商品房|住宅', text):
            rates = re.findall(r'(?:商品房|住宅)(?:抵押)?率[：:]\s*(\d+\.?\d*)\s*%?', text)
            for rate_str in rates:
                try:
                    rate = float(rate_str.rstrip('%'))
                    if rate > 70:
                        issues.append(f'商品房抵押率{rate}%超过最高上限70%，不符合《主要押品类型具体接受标准》')
                    elif rate > 70 * 0.9:
                        issues.append(f'【提示】商品房抵押率{rate}%接近上限（70%），请确认')
                except Exception:
                    pass

            cover_rates = re.findall(r'抵押担保?覆盖率[：:]\s*(\d+\.?\d*)\s*%?', text)
            for cr_str in cover_rates:
                try:
                    cr = float(cr_str.rstrip('%'))
                    if cr < 100:
                        issues.append(f'抵押担保覆盖率{cr}%低于100%，贷款本金保障不足，请确认')
                except Exception:
                    pass

        # 应收账款质押要求
        if re.search(r'应收账款.*质押|质押.*应收账款', text):
            ar_ages = re.findall(r'账龄[：:]\s*(\d+)\s*(个?月|天|年)', text)
            for age, unit in ar_ages:
                try:
                    age_n = int(age)
                    if unit in ('月', '个月') and age_n > 12:
                        issues.append(f'应收账款账龄{age_n}个月超过规定上限（12个月），不符合质押条件')
                except Exception:
                    pass
            if re.search(r'关联企业.*应收账款|应收账款.*关联企业', text):
                if re.search(r'质押', text):
                    issues.append('【合规】关联企业之间应收账款不得质押，请确认')

        # 土地抵押
        if re.search(r'土地.*抵押|抵押.*土地', text):
            land_rates = re.findall(r'土地抵押?率[：:]\s*(\d+\.?\d*)%?', text)
            for lr_str in land_rates:
                try:
                    lr = float(lr_str.rstrip('%'))
                    if lr > 70:
                        issues.append(f'土地抵押率{lr}%超过最高上限（一般70%），请确认')
                except Exception:
                    pass

        # 押品评估价值合理性
        pledge_vals = re.findall(r'(?:抵押|质押)物.*?价值[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        loan_vals = re.findall(r'贷款(?:金额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        if pledge_vals and loan_vals:
            try:
                pv = to_num(pledge_vals[0][0], pledge_vals[0][1] or '亿')
                lv = to_num(loan_vals[0][0], loan_vals[0][1] or '亿')
                if pv and lv and pv < lv * 0.8:
                    issues.append(f'押品价值{pv:.2f}亿低于贷款金额{lv:.2f}亿，可能无法覆盖贷款本息')
            except Exception:
                pass

        self.issues['collateral'] = issues
        return issues

    # ============================================================
    # 8. 保证担保
    # ============================================================
    def check_guarantee(self):
        issues = []
        text = self.full_text

        if re.search(r'保证人|保证担保|担保人', text):
            guarantor_assets = re.findall(r'保证人[^\n。]{0,20}资产[总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            guarantor_liab = re.findall(r'保证人[^\n。]{0,20}负债[总名]*(?:额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)

            if guarantor_assets and guarantor_liab:
                try:
                    ga = to_num(guarantor_assets[0][0], guarantor_assets[0][1] or '亿')
                    gl = to_num(guarantor_liab[0][0], guarantor_liab[0][1] or '亿')
                    if ga and gl:
                        net_asset = ga - gl
                        if net_asset < 0:
                            issues.append(f'保证人净资产为负数{net_asset:.1f}亿，不具备担保能力，请核实')
                        elif net_asset < 0.5:
                            issues.append(f'【提示】保证人净资产{net_asset:.2f}亿偏低，担保能力有限，请关注')
                except Exception:
                    pass

        if re.search(r'中期流动资金贷款', text):
            grade = re.findall(r'信用等级[：:]\s*(L\d+)', text)
            if grade:
                try:
                    lv = int(grade[0].lstrip('L'))
                    if lv < 11:
                        issues.append(f'中期流动资金贷款要求借款人信用等级L11（含）以上，当前{grade[0]}，不符合')
                except Exception:
                    pass

        guarantor_grades = re.findall(r'保证人[^\n]{0,30}信用等级[：:]\s*(L\d+)', text)
        for gg in guarantor_grades:
            try:
                gv = int(gg.lstrip('L'))
                if gv < 13:
                    issues.append(f'保证人信用等级{gg}低于L13级，按规定须每月进行存续期检查，请确认')
            except Exception:
                pass

        cap_texts = re.findall(r'(?:保证人)?担保能力[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        loan_texts = re.findall(r'贷款(?:本金)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        if cap_texts and loan_texts:
            try:
                gc = to_num(cap_texts[0][0], cap_texts[0][1] or '亿')
                gl = to_num(loan_texts[0][0], loan_texts[0][1] or '亿')
                if gc and gl and gl > 0 and gc < gl:
                    issues.append(f'保证人担保能力{gc:.2f}亿小于贷款本金{gl:.2f}亿，担保能力不足，请关注')
            except Exception:
                pass

        if re.search(r'保证担保', text):
            if not re.search(r'保证人.{0,50}(主体资格|具有.{0,20}担保能力|净资产)', text):
                issues.append('【完整性提示】保证担保部分缺少保证人主体资格及担保能力说明')

        self.issues['guarantee'] = issues
        return issues

    # ============================================================
    # 9. 子产品准入条件（82个子产品完整版）
    # ============================================================
    def check_product_requirements(self):
        """基于《贷款子产品管理细则》82个子产品，核验借款人是否满足具体子产品准入条件"""
        issues = []
        text = self.full_text

        # 1. 识别贷款产品类型
        detected_product = None
        detected_keywords = []
        for prod, kws in PRODUCT_KEYWORDS.items():
            for kw in kws:
                if kw in text:
                    detected_product = prod
                    detected_keywords.append(kw)
                    break
            if detected_product:
                break

        # 2. 获取产品规则
        rule = PRODUCT_RULES.get(detected_product)
        if rule:
            reg_min, al_limits, grade_min, note = rule
            al_before_limit, al_after_limit = al_limits[0], al_limits[1]

            # 2a. 核验注册资本
            reg_match = re.findall(r'注册资本[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
            if reg_min and reg_match:
                try:
                    val = float(reg_match[0][0])
                    unit = reg_match[0][1] or '万'
                    val_wan = val * (10000 if unit == '亿' else (1e8 if unit == '元' else 1))
                    if val_wan < reg_min:
                        issues.append(
                            f'注册资本{reg_match[0][0]}{unit}低于{detected_product}准入要求（≥{reg_min}万）'
                        )
                except Exception:
                    pass

            # 2b. 核验资产负债率（分融资前/融资后）
            al_before_vals = re.findall(r'上年末资产负债率[：:]\s*(\d+\.?\d*)%?', text)
            al_after_vals = re.findall(r'融资后资产负债率[：:]\s*(\d+\.?\d*)%?', text)
            al_general_vals = [v for v in re.findall(r'资产负债率[：:]\s*(\d+\.?\d*)%?', text)
                              if '融资后' not in text or '融资后资产负债率' not in text]

            # 融资前AL
            if al_before_limit and al_before_vals:
                for av in al_before_vals:
                    try:
                        av_val = float(av)
                        if av_val > al_before_limit:
                            issues.append(
                                f'上年末资产负债率{av_val}%超过{detected_product}准入上限（{al_before_limit}%）：{note}'
                            )
                    except Exception:
                        pass

            # 融资后AL
            if al_after_limit and al_after_vals:
                for av in al_after_vals:
                    try:
                        av_val = float(av)
                        if av_val > al_after_limit:
                            issues.append(
                                f'融资后资产负债率{av_val}%超过{detected_product}上限（{al_after_limit}%）：{note}'
                            )
                    except Exception:
                        pass

            # 2c. 核验信用等级
            grades = re.findall(r'信用等级[：:在]\s*(L\d+)', text)
            if grades and grade_min:
                try:
                    min_grade = int(grade_min.lstrip('L'))
                    for g in grades:
                        lv = int(g.lstrip('L'))
                        if lv < min_grade:
                            issues.append(
                                f'信用等级{g}低于{detected_product}准入要求（{grade_min}级以上）：{note}'
                            )
                except Exception:
                    pass

        # 3. 中期流动资金贷款须L11（含）以上（考试题库案例8）
        if re.search(r'中期流动资金贷款', text):
            grades = re.findall(r'信用等级[：:在]\s*(L\d+)', text)
            for g in grades:
                try:
                    lv = int(g.lstrip('L'))
                    if lv < 11:
                        issues.append(f'中期流动资金贷款要求借款人信用等级L11（含）以上，当前{g}，不符合准入')
                except Exception:
                    pass

        # 4. 精准防返贫特殊要求：五项财务指标至少3项达行业均值
        if detected_product == '精准防返贫':
            indicators = re.findall(
                r'(资产负债率|净资产收益率|销售利润率|应收账款周转率|速动比率)[：:在]\s*(\d+\.?\d*)\s*(%|次|倍)?',
                text
            )
            if len(indicators) < 3:
                issues.append('【提示】精准防返贫贷款要求五项财务指标（资产负债率、净资产收益率、销售利润率、应收账款周转率、速动比率）中至少3项达到行业平均值，请核实是否满足')

        # 5. 农村公路：项目须纳入交通规划
        if re.search(r'农村公路|县道|乡道|村道', text):
            if not re.search(r'纳入.*规划|交通.*规划', text):
                issues.append('【提示】农村公路贷款须确认项目已纳入交通相关规划')

        # 6. 农村特色小镇：须纳入省级特色小镇名单
        if re.search(r'特色小镇', text):
            if not re.search(r'省级.*名单|纳入.*名单|列入.*名单', text):
                issues.append('【合规提示】农村特色小镇贷款须确认已纳入省级特色小镇名单')

        # 7. 棚户区改造：须纳入当年/前一年度改造规划
        if re.search(r'棚户区改造', text):
            if not re.search(r'纳入.*规划|改造计划', text):
                issues.append('【合规提示】棚户区改造贷款须确认项目已纳入当年或前一年度棚户区改造规划')

        self.issues['product_req'] = issues
        return issues

    # ============================================================
    # 10. 表间数据校验（新增 v4）
    # ============================================================
    def check_table_consistency(self):
        """
        检查报告中表格数据与正文描述的一致性
        - 表格数字 vs 正文数字（同一指标）
        - 表格内部横向/纵向逻辑
        - 常见财务指标表内平衡
        """
        issues = []
        text = self.full_text
        tables = self.tables

        # ── 策略1：提取关键指标在正文和表格中的数值，交叉核对 ──
        # 关键指标：资产负债率、总资产、总负债、流动资产、流动负债、存货、贷款金额、期限、利率、注册资本

        def extract_val(label, context):
            """从文本/表格行中提取带标签的数值"""
            pattern = rf'{label}[：:]\s*(\d+\.?\d*)\s*(亿|万|元|%)?'
            m = re.search(pattern, context)
            return m.groups() if m else None

        def parse_val(val_str, unit):
            """转换为亿元浮点数"""
            try:
                v = float(val_str)
                if unit in ('万',):
                    return v / 10000
                elif unit in ('元',):
                    return v / 1e8
                return v  # 亿
            except:
                return None

        # ── 关键指标列表 ──
        indicators = [
            ('总资产', '总资产'),
            ('负债总额', '总负债'),
            ('资产负债率', '资产负债率'),
            ('流动资产', '流动资产'),
            ('流动负债', '流动负债'),
            ('存货', '存货'),
            ('注册资本', '注册资本'),
            ('净资产', '净资产'),
            ('营业收入', '营业收入'),
            ('净利润', '净利润'),
        ]

        # 构建正文数值字典
        text_vals = {}
        for key, label in indicators:
            m = re.search(rf'{label}[：:]\s*(\d+\.?\d*)\s*(亿|万|元|%)?', text)
            if m:
                text_vals[key] = parse_val(m.group(1), m.group(2) or '')

        # 构建表格数值字典（仅分析有财务数据的表格）
        table_vals = {}
        for ti, tbl in enumerate(tables):
            tbl_text = ' '.join([' '.join(row) for row in tbl])
            for key, label in indicators:
                if key not in table_vals:  # 取第一个匹配的表格
                    m = re.search(rf'{label}[：:]\s*(\d+\.?\d*)\s*(亿|万|元|%)?', tbl_text)
                    if m:
                        table_vals[key] = (ti, parse_val(m.group(1), m.group(2) or ''))

        # ── 核对：同一指标在正文和表格中的数值是否一致 ──
        common_keys = set(text_vals.keys()) & set(k for k, v in table_vals.items() if v[1] is not None)
        for key in common_keys:
            tv = text_vals[key]
            _, tval = table_vals[key]
            if tv and tval and tv != 0 and tval != 0:
                diff_pct = abs(tv - tval) / max(abs(tv), abs(tval)) * 100
                if diff_pct > 3:  # 误差超过3%则报
                    label_map = {
                        '总资产': '总资产', '总负债': '负债总额', '资产负债率': '资产负债率',
                        '流动资产': '流动资产', '流动负债': '流动负债', '存货': '存货',
                        '注册资本': '注册资本', '净资产': '净资产',
                        '营业收入': '营业收入', '净利润': '净利润'
                    }
                    issues.append(
                        f'【表-文不一致】{label_map.get(key, key)}：正文={tv:.2f}，表格={tval:.2f}，'
                        f'差异{abs(tv-tval):.2f}（{diff_pct:.1f}%），请核实哪个为准'
                    )

        # ── 策略2：表格内资产负债率横向逻辑校验 ──
        for ti, tbl in enumerate(tables):
            tbl_text = ' '.join([' '.join(row) for row in tbl])
            # 查找"资产"+"负债"+"资产负债率"三列是否同表
            assets = re.findall(r'资产(?:总额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            liabs = re.findall(r'负债(?:总额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            ratios = re.findall(r'资产负债率[：:]\s*(\d+\.?\d*)\s*%?', tbl_text)
            if assets and liabs and ratios:
                try:
                    a = parse_val(assets[0][0], assets[0][1] or '')
                    l = parse_val(liabs[0][0], liabs[0][1] or '')
                    r = float(ratios[0].rstrip('%'))
                    if a and l and a > 0:
                        calc_r = l / a * 100
                        if abs(calc_r - r) > 1.5:
                            issues.append(
                                f'【表{ti+1}内矛盾】资产负债率：资产{a:.2f}亿×负债{l:.2f}亿'
                                f'→应≈{calc_r:.1f}%，表中={r}%，请核实'
                            )
                except Exception:
                    pass

        # ── 策略3：表格内速动比率横向逻辑校验 ──
        for ti, tbl in enumerate(tables):
            tbl_text = ' '.join([' '.join(row) for row in tbl])
            ca_m = re.findall(r'流动资产[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            inv_m = re.findall(r'存货[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            cl_m = re.findall(r'流动负债[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            qr_m = re.findall(r'速动比率[：:]\s*(\d+\.?\d*)\s*%?', tbl_text)
            if ca_m and inv_m and cl_m and qr_m:
                try:
                    ca = parse_val(ca_m[0][0], ca_m[0][1] or '')
                    inv = parse_val(inv_m[0][0], inv_m[0][1] or '')
                    cl = parse_val(cl_m[0][0], cl_m[0][1] or '')
                    qr = float(qr_m[0].rstrip('%'))
                    if ca and inv and cl and cl > 0:
                        calc_qr = (ca - inv) / cl * 100
                        if abs(calc_qr - qr) > 1.5:
                            issues.append(
                                f'【表{ti+1}内矛盾】速动比率：流动资产{ca:.2f}-存货{inv:.2f}'
                                f'=速动资产，流动负债{cl:.2f}→应≈{calc_qr:.1f}%，表中={qr}%'
                            )
                except Exception:
                    pass

        # ── 策略4：贷款方案数据内部一致性 ──
        for ti, tbl in enumerate(tables):
            tbl_text = ' '.join([' '.join(row) for row in tbl])
            # 表格中：总投资 vs (贷款+资本金)
            invest = re.findall(r'总投资[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            loan = re.findall(r'贷款[金额]?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            capital = re.findall(r'资本金[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', tbl_text)
            if invest and loan and capital:
                try:
                    ti_val = parse_val(invest[0][0], invest[0][1] or '')
                    la_val = parse_val(loan[0][0], loan[0][1] or '')
                    ca_val = parse_val(capital[0][0], capital[0][1] or '')
                    if ti_val and la_val and ca_val and ca_val > 0:
                        if abs(ti_val - la_val - ca_val) > 0.5 and abs(ti_val - la_val - ca_val) / ti_val > 0.05:
                            issues.append(
                                f'【表{ti+1}内矛盾】资金构成：贷款{la_val:.2f}+资本金{ca_val:.2f}'
                                f'={la_val+ca_val:.2f}，总投资{ti_val:.2f}，差距{abs(ti_val-la_val-ca_val):.2f}亿'
                            )
                except Exception:
                    pass

            # 表格中：贷款期限 vs 宽限期
            term = re.findall(r'贷款期限[：:]\s*(\d+)年', tbl_text)
            grace = re.findall(r'宽限期[：:]\s*(\d+)年', tbl_text)
            if term and grace:
                try:
                    if int(term[0]) <= int(grace[0]):
                        issues.append(f'【表{ti+1}内矛盾】宽限期{int(grace[0])}年≥贷款期限{int(term[0])}年')
                except Exception:
                    pass

        # ── 策略5：检查表格中重复出现的同一数值是否存在不一致 ──
        # 查找贷款金额在正文和表格中是否有多处且数值不同
        loan_in_text = re.findall(r'贷款(?:金额)?[：:]\s*(\d+\.?\d*)\s*(亿|万|元)?', text)
        if len(loan_in_text) >= 2:
            # 取第一个作为基准
            base = parse_val(loan_in_text[0][0], loan_in_text[0][1] or '亿')
            for i, (val, unit) in enumerate(loan_in_text[1:], start=2):
                v = parse_val(val, unit or '亿')
                if base and v and abs(base - v) / max(base, v) > 0.01:  # 差异超过1%
                    issues.append(
                        f'【数据矛盾】贷款金额出现不一致：第1处={loan_in_text[0][0]}{loan_in_text[0][1] or "亿"}，'
                        f'第{i}处={val}{unit or "亿"}，请核实准确数值'
                    )

        self.issues['table_consistency'] = issues
        return issues

    # ============================================================
    # 主审核流程
    # ============================================================
    def review(self):
        import pathlib
        path_name = pathlib.Path(self.path).name
        print(f'开始审核：{path_name}')
        print(f'段落数：{len(self.paragraphs)}，表格数：{len(self.tables)}')
        print('─' * 60)

        self.check_format()
        self.check_completeness()
        self.check_logic()
        self.check_numeric()
        self.check_typo()
        self.check_credit_limit()
        self.check_collateral()
        self.check_guarantee()
        self.check_product_requirements()
        self.check_table_consistency()  # 新增：表间校验

        self._print_report()

    def _print_report(self):
        dim_names = {
            'format': '【格式规范性】',
            'completeness': '【内容完整性】',
            'logic': '【逻辑一致性】',
            'numeric': '【数字准确性】',
            'typo': '【文字质量】',
            'credit_limit': '【统一授信】',
            'collateral': '【押品合规】',
            'guarantee': '【保证担保】',
            'product_req': '【子产品准入】',
            'table_consistency': '【表间数据校验】',
        }

        total = 0
        for dim, issues in self.issues.items():
            total += len(issues)
            name = dim_names.get(dim, dim)
            if issues:
                print(f'\n{name} 发现 {len(issues)} 处问题')
                for issue in issues:
                    print(f'  - {issue}')
            else:
                print(f'\n{name} ✓ 未发现问题')

        print('\n' + '─' * 60)
        if total == 0:
            print('【总体评价】✓ 通过 — 报告质量良好')
        elif total <= 5:
            print(f'【总体评价】⚠ 需修改 — 共 {total} 处问题，请参照上方详情修改')
        else:
            print(f'【总体评价】✗ 发现 {total} 处问题，建议对照审核标准全面修改')


# ---------------------------------------------------------------
# 入口
# ---------------------------------------------------------------

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('用法: python review_report.py <报告.docx路径>')
        sys.exit(1)

    docx_path = sys.argv[1]
    if not os.path.exists(docx_path):
        print(f'错误：文件不存在 - {docx_path}')
        sys.exit(1)

    reviewer = LoanReportReviewer(docx_path)
    reviewer.review()
