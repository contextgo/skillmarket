---
name: tugraph-cypher
description: TuGraph Cypher query language reference guide. Use this skill when the user writes Cypher queries for TuGraph, creates schemas (vertex/edge labels), calls built-in procedures (db.*, dbms.*, algo.*), manages indexes, users, roles, subgraphs, or encounters OpenCypher features that TuGraph does not support. Covers operators, clauses, functions, procedures, and a compatibility matrix with standard OpenCypher.
version: 0.1.0
---

# TuGraph Cypher Skill

When working with TuGraph Cypher, follow these guidelines:

## Core Architecture Differences

| Feature | TuGraph | Standard OpenCypher |
|---------|---------|---------------------|
| Label count | **Must have exactly 1** label per node/edge | 0 to many labels |
| Schema | **Strong Schema** (define before use) | Schema-less |
| Label-less nodes | **Cannot create**, will error | Can create |

## Unsupported Features Quick Reference

These OpenCypher features are **NOT supported** in TuGraph:

- `RETURN *` — cannot return all variables
- `WHERE (a)-[]->(b)` — path pattern filtering in WHERE
- `node["prop"]` — dynamic property access
- `CREATE p = (a)-[:R]->(b)` — creating full paths
- `CALL proc($param)` — parameterized procedure arguments
- `SKIP rand()` — SKIP/LIMIT expressions (constants only)
- `` `VAR NAME` `` — backtick variable names
- `all()`, `any()`, `single()`, `none()` — predicate functions
- `UNION` (dedup) — only `UNION ALL` is supported

## Full Reference

For detailed examples, syntax, and complete procedure lists, read the reference files:

- `references/quick-reference.md` — operators, clauses, functions with examples
- `references/procedures.md` — all built-in procedures with signatures

## Version

Based on TuGraph DB 4.5.1. Features may change in newer versions.
