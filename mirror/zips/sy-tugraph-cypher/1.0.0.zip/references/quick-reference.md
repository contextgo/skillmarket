# TuGraph Cypher Quick Reference

> Based on TuGraph DB 4.5.1

## Operators

| Category | Supported | Notes |
|----------|-----------|-------|
| General | `DISTINCT`, `.` property access | `[]` dynamic access **unsupported** |
| Math | `+`, `-`, `*`, `/`, `%`, `^` | |
| Comparison | `=`, `<>`, `<`, `>`, `<=`, `>=`, `IS NULL`, `IS NOT NULL` | |
| String | `STARTS WITH`, `ENDS WITH`, `CONTAINS`, `REGEXP` | |
| Boolean | `AND`, `OR`, `XOR`, `NOT` | |
| List | `+` concat, `IN` check, `[]` access/slice | |

### Examples

```cypher
-- DISTINCT
MATCH (p:person) RETURN DISTINCT p.born

-- Math
WITH 2 AS number, 3 AS exponent RETURN number ^ exponent AS result

-- String
WHERE candidate STARTS WITH 'Jo'
WHERE candidate REGEXP 'Jo.*n'

-- List
RETURN [1,2,3] + [4,5] AS myList
WHERE number IN [2, 3, 8]
RETURN names[1..3] AS result
```

## Clauses

| Clause | Status | Notes |
|--------|--------|-------|
| `MATCH` / `OPTIONAL MATCH` | Supported | `MANDATORY MATCH` pending |
| `RETURN` / `WITH` / `UNWIND` | Supported | `RETURN *` unsupported |
| `WHERE` | Supported | No path pattern filter, no dynamic properties |
| `ORDER BY` | Supported | |
| `SKIP` / `LIMIT` | Supported | Constants only, no expressions |
| `CREATE` | Supported | No full path creation, no parameterized creation |
| `MERGE` / `SET` / `REMOVE` / `DELETE` / `DETACH DELETE` | Supported | |
| `CALL ... YIELD` | Supported | No parameterized args, no WHERE on results |
| `UNION ALL` | Supported | |
| `UNION` | **Unsupported** | Only UNION ALL |

### MATCH Examples

```cypher
-- Basic node
MATCH (movie:movie) RETURN movie.title

-- Relationship
MATCH (:person {name: 'Laurence Fishburne'})-[]->(movie) RETURN movie.title

-- Multiple relationship types
MATCH (m {title: 'The Matrix'})<-[:acted_in|:directed]-(person) RETURN person.name

-- Variable length
MATCH (l {name: 'Laurence Fishburne'})-[:acted_in*1..3]-(movie:movie) RETURN movie.title

-- Named path
MATCH p = (michael {name: 'Michael Douglas'})-[]->() RETURN p

-- By ID
MATCH (n) WHERE id(n) = 0 RETURN n
MATCH ()-[r]->() WHERE euid(r) = "0_3937_0_0_0" RETURN r

-- Shortest path
MATCH (a:person {name: 'Carrie-Anne Moss'}), (b:person {name: 'Laurence Fishburne'})
CALL algo.shortestPath(a, b) YIELD nodeCount, totalCost, path
RETURN nodeCount, totalCost, path
```

### WHERE Examples

```cypher
-- Boolean ops
WHERE n.name = 'X' XOR (n.born > 2000 AND n.name = 'Y')

-- By label
WHERE n:person

-- String matching
WHERE n.name STARTS WITH 'Pet'
WHERE n.name ENDS WITH 'ter'
WHERE n.name CONTAINS 'ete'

-- Lists
WHERE a.name IN ['Laurence Fishburne', 'Tobias']

-- NULL handling
WHERE n.belt = 'white' OR n.belt IS NULL
```

### CREATE Examples

```cypher
-- Create node
CREATE (n:person {id: 2001, name: 'Andres'})

-- Create relationship
MATCH (n:person), (m:movie)
WHERE n.name = 'X' AND m.title = 'Y'
CREATE (n)-[r:acted_in{role: 'Trinity'}]->(m)
```

### SKIP / LIMIT

```cypher
MATCH (n:person) RETURN n.name ORDER BY n.name SKIP 3 LIMIT 2
```

## Functions

### Predicate
- `exists()` — only supported predicate function
- **Unsupported**: `all()`, `any()`, `single()`, `none()`

### Scalar
`id()`, `euid()`, `properties()`, `head()`, `last()`, `toBoolean()`, `toFloat()`, `toInteger()`, `toString()`, `type()`, `startnode()`, `endnode()`, `size()`, `length()`, `substring()`, `concat()`, `label()`

### Aggregating
`avg()`, `collect()`, `count()`, `max()`, `min()`, `percentileCont()`, `percentileDisc()`, `stDev()`, `stDevP()`, `variance()`, `varianceP()`, `sum()`

### List
`keys()`, `labels()`, `nodes()`, `range()` — `subscript()` **unsupported**

### Math
`abs()`, `ceil()`, `floor()`, `rand()`, `round()`, `sign()`

## Unsupported Features Summary

### Operators
- `[]` dynamic property access: `node["prop_" + suffix]`

### Clauses
- `MANDATORY MATCH` — pending
- `UNION` (dedup) — only UNION ALL
- `CREATE` full paths: `CREATE p = (a)-[:R]->(b)`
- `CREATE` parameterized: `CREATE (n:Person $props)`
- `RETURN *`
- `RETURN` path pattern expressions: `(a)-[]->()`
- `RETURN` backtick variables: `` `This isn't valid` ``
- `WHERE` path pattern filter: `WHERE (a)-[]->(b)`
- `WHERE` dynamic computed properties: `WHERE n[toLower(propname)] < 30`
- `SKIP/LIMIT` expressions — constants only
- `MATCH` backtick relationship types: `` `TYPE WITH SPACE` ``
- `MATCH` variable-length relationship property filter: `[* {blocked:false}]`
- `CALL` quoted namespace: `` CALL `db`.`vertexLabels` ``
- `CALL` parameterized args: `CALL proc($param)`
- `CALL` mixed literal + parameter args
- `CALL` WHERE on results
- `CALL` renamed output with dynamic access

### Functions
- `all()`, `any()`, `single()`, `none()`, `subscript()`
