# TuGraph Built-in Procedures

> Based on TuGraph DB 4.5.1

## Schema Management

### List Labels
```cypher
CALL db.vertexLabels()                                    -- List vertex labels
CALL db.edgeLabels()                                      -- List edge labels
```

### Create Labels
```cypher
CALL db.createVertexLabel('Person', 'id', 'id','int64',false, 'name','string',true)
CALL db.createEdgeLabel('KNOWS', '[]', 'name','int32',true)
CALL db.createLabel('vertex', 'new_label', 'id', ['id','int32',false], ['name','string', true])
CALL db.createLabel('edge', 'new_edge', '[["id1","id2"]]', ['id','int32',false], ['name','string', true])
```

### Delete Labels
```cypher
CALL db.deleteLabel('vertex', 'Person')
```

### Alter Labels
```cypher
CALL db.alterLabelDelFields('vertex', 'Person', ['name', 'image'])
CALL db.alterLabelAddFields('vertex','new_label',['birth_date', DATE, '', true],['img', BLOB, '', true])
CALL db.alterLabelModFields('vertex','new_label',['birth_date', DATETIME, true],['gender', BOOL, true])
```

### Schema Inspection
```cypher
CALL db.getLabelSchema(label_type, label_name)            -- Get label schema
CALL db.getVertexSchema(label)                            -- Get vertex schema
CALL db.getEdgeSchema(label)                              -- Get edge schema
CALL db.propertyKeys()                                    -- List property keys
```

## Index Management

### Create Indexes
```cypher
CALL db.addIndex('Person', 'id', true)                    -- Unique vertex index
CALL db.addEdgeIndex('BornIn', 'id', true, false)         -- Edge index
CALL db.addVertexCompositeIndex('Person', ['name','age'], false)  -- Composite index
```

### Delete Indexes
```cypher
CALL db.deleteIndex('Person', 'id')
CALL db.deleteCompositeIndex('Person', ['name','age'])
```

### List Indexes
```cypher
CALL db.indexes()                                         -- All indexes
CALL db.listLabelIndexes(label_name, label_type)          -- Indexes for a label
```

### Full-Text Indexes
```cypher
CALL db.addFullTextIndex(is_vertex, label_name, field_name)
CALL db.deleteFullTextIndex(is_vertex, label_name, field_name)
CALL db.rebuildFullTextIndex(vertex_labels, edge_labels)
CALL db.fullTextIndexes()
```

## Shortest Path
```cypher
CALL algo.shortestPath(startNode, endNode) YIELD nodeCount, totalCost, path
CALL algo.allShortestPaths(startNode, endNode) YIELD nodeIds, relationshipIds, cost
```

## Subgraph
```cypher
CALL db.subgraph([3937, 4126, 4066])                      -- Get subgraph by vertex IDs
```

## Native Extract
```cypher
CALL algo.native.extract(vids, {isNode:true, field:'id'}) YIELD value
```

## User/Role Management

### Users
```cypher
CALL dbms.security.listUsers()
CALL dbms.security.createUser('user', 'password')
CALL dbms.security.deleteUser('user')
CALL dbms.security.changePassword('old', 'new')
CALL dbms.security.changeUserPassword('user', 'new_password')
CALL dbms.security.showCurrentUser()
CALL dbms.security.getUserPermissions('user')
CALL dbms.security.getUserInfo('user')
CALL dbms.security.disableUser('user', true/false)
CALL dbms.security.setCurrentDesc('description')
CALL dbms.security.setUserDesc('user', 'description')
CALL dbms.security.getUserMemoryUsage('user')
CALL dbms.security.setUserMemoryLimit('user', limit)
```

### Roles
```cypher
CALL dbms.security.listRoles()
CALL dbms.security.createRole('role', 'description')
CALL dbms.security.deleteRole('role')
CALL dbms.security.getRoleInfo('role')
CALL dbms.security.disableRole('role', true/false)
CALL dbms.security.modRoleDesc('role', 'description')
CALL dbms.security.rebuildRoleAccessLevel('role', access_level_map)
CALL dbms.security.modRoleAccessLevel('role', access_level_map)
CALL dbms.security.modRoleFieldAccessLevel('role', graph, label, field, label_type, access_level)
```

### User-Role Relations
```cypher
CALL dbms.security.addUserRoles('user', ['role1', 'role2'])
CALL dbms.security.deleteUserRoles('user', ['role1', 'role2'])
CALL dbms.security.rebuildUserRoles('user', ['role1', 'role2'])
```

### IP Allowlist
```cypher
CALL dbms.security.addAllowedHosts(['192.168.1.1'])
CALL dbms.security.deleteAllowedHosts(['192.168.1.1'])
CALL dbms.security.listAllowedHosts()
```

## Subgraph Management
```cypher
CALL dbms.graph.createGraph('graph1', 'description', 2045)
CALL dbms.graph.modGraph('graph1', {description:'this graph', max_size_GB:20})
CALL dbms.graph.deleteGraph('graph1')
CALL dbms.graph.listGraphs()
CALL dbms.graph.getGraphInfo('graph1')
```

## Configuration
```cypher
CALL dbms.config.list()
CALL dbms.config.update({enable_ip_check: false, durable:true, optimistic_txn:true})
```

## Task Management
```cypher
CALL dbms.task.listTasks()
CALL dbms.task.terminateTask(task_id)
```

## Meta Statistics
```cypher
CALL dbms.meta.count()                                    -- Total vertex/edge count
CALL dbms.meta.countDetail()                              -- Count by label
CALL dbms.meta.refreshCount()                             -- Refresh statistics
```

## HA Cluster
```cypher
CALL dbms.ha.clusterInfo()                                -- Cluster status
```

## Database Operations
```cypher
CALL db.dropDB()                                          -- Clear database
CALL db.flushDB()                                         -- Flush database
CALL db.backup(destination)                               -- Backup data
CALL db.warmup()                                          -- Warmup data
CALL db.takeSnapshot()                                    -- Take snapshot
```

## Plugins
```cypher
CALL db.plugin.loadPlugin(plugin_type, plugin_name, content, code_type, description, read_only, version)
CALL db.plugin.deletePlugin(plugin_type, plugin_name)
CALL db.plugin.listPlugin(plugin_type, plugin_version)
CALL db.plugin.getPluginInfo(plugin_type, plugin_name, show_code)
CALL db.plugin.callPlugin(plugin_type, plugin_name, param, timeout, in_process)
```

## Data Import
```cypher
CALL db.importor.dataImportor(description, content, continue_on_error, thread_nums, delimiter)
CALL db.importor.schemaImportor(description)
```

## List All Procedures
```cypher
CALL dbms.procedures()                                    -- List all available procedures
```

## Complete Procedure Reference

| Name | Description | Signature |
|------|-------------|-----------|
| db.subgraph | Subgraph by vertex IDs | `db.subgraph(vids::LIST) :: (subgraph::STRING)` |
| db.vertexLabels | List vertex labels | `db.vertexLabels() :: (label::STRING)` |
| db.edgeLabels | List edge labels | `db.edgeLabels() :: (edgeLabels::STRING)` |
| db.indexes | List all indexes | `db.indexes() :: (label,field,label_type,unique,pair_unique)` |
| db.listLabelIndexes | Indexes for a label | `db.listLabelIndexes(label_name,label_type) :: (label,field,unique,pair_unique)` |
| db.warmup | Warmup data | `db.warmup() :: (time_used::STRING)` |
| db.createVertexLabel | Create vertex label | `db.createVertexLabel(label_name,field_specs::LIST) :: (::VOID)` |
| db.createLabel | Create vertex/edge label | `db.createLabel(label_type,label_name,extra,field_specs::LIST) :: ()` |
| db.getLabelSchema | Get label schema | `db.getLabelSchema(label_type,label_name) :: (name,type,optional)` |
| db.getVertexSchema | Get vertex schema | `db.getVertexSchema(label) :: (schema::MAP)` |
| db.getEdgeSchema | Get edge schema | `db.getEdgeSchema(label) :: (schema::MAP)` |
| db.deleteLabel | Delete label | `db.deleteLabel(label_type,label_name) :: (::VOID)` |
| db.alterLabelDelFields | Delete label fields | `db.alterLabelDelFields(label_type,label_name,del_fields::LIST) :: (record_affected::INTEGER)` |
| db.alterLabelAddFields | Add label fields | `db.alterLabelAddFields(label_type,label_name,add_field_specs::LIST) :: (record_affected::INTEGER)` |
| db.alterLabelModFields | Modify label fields | `db.alterLabelModFields(label_type,label_name,mod_field_specs::LIST) :: (record_affected::INTEGER)` |
| db.createEdgeLabel | Create edge label | `db.createEdgeLabel(type_name,field_specs::LIST) :: (::VOID)` |
| db.addIndex | Create vertex index | `db.addIndex(label_name,field_name,unique) :: (::VOID)` |
| db.addEdgeIndex | Create edge index | `db.addEdgeIndex(label_name,field_name,unique,pair_unique) :: (::VOID)` |
| db.addVertexCompositeIndex | Create composite index | `db.addVertexCompositeIndex(label_name,field_names::LIST,unique) :: (::VOID)` |
| db.deleteIndex | Delete index | `db.deleteIndex(label_name,field_name) :: (::VOID)` |
| db.deleteCompositeIndex | Delete composite index | `db.deleteIndex(label_name,field_names::LIST) :: (::VOID)` |
| db.backup | Backup data | `db.backup(destination::STRING) :: ()` |
| dbms.procedures | List all procedures | `dbms.procedures() :: (name,signature)` |
| dbms.security.changePassword | Change current user password | `dbms.security.changePassword(current_password,new_password) :: (::VOID)` |
| dbms.security.changeUserPassword | Change specified user password | `dbms.security.changeUserPassword(user_name,new_password) :: (::VOID)` |
| dbms.security.createUser | Create user | `dbms.security.createUser(user_name,password) :: (::VOID)` |
| dbms.security.deleteUser | Delete user | `dbms.security.deleteUser(user_name) :: (::VOID)` |
| dbms.security.listUsers | List all users | `dbms.security.listUsers() :: (user_name,user_info::MAP)` |
| dbms.security.showCurrentUser | Show current user | `dbms.security.showCurrentUser() :: (current_user::STRING)` |
| dbms.security.getUserPermissions | Get user permissions | `dbms.security.getUserPermissions(user_name) :: (user_info::MAP)` |
| dbms.graph.createGraph | Create subgraph | `dbms.graph.createGraph(graph_name,description,max_size_GB) :: (::VOID)` |
| dbms.graph.modGraph | Modify subgraph | `dbms.graph.modGraph(graph_name,config::MAP) :: (::VOID)` |
| dbms.graph.deleteGraph | Delete subgraph | `dbms.graph.deleteGraph(graph_name) :: (::VOID)` |
| dbms.graph.listGraphs | List subgraphs | `dbms.graph.listGraphs() :: (graph_name,configuration::MAP)` |
| dbms.graph.getGraphInfo | Get subgraph info | `dbms.graph.getGraphInfo(graph_name) :: (graph_name,configuration::MAP)` |
| dbms.security.addAllowedHosts | Add IP to allowlist | `dbms.security.addAllowedHosts(hosts::LIST) :: (num_new::INTEGER)` |
| dbms.security.deleteAllowedHosts | Delete IP from allowlist | `dbms.security.deleteAllowedHosts(hosts::LIST) :: (record_affected::INTEGER)` |
| dbms.security.listAllowedHosts | List allowed hosts | `dbms.security.listAllowedHosts() :: (host::STRING)` |
| dbms.config.update | Update config | `dbms.config.update(updates::MAP) :: (message::STRING)` |
| dbms.config.list | List config | `dbms.config.list() :: (name,value::ANY)` |
| algo.shortestPath | Shortest path | `algo.shortestPath(startNode::NODE,endNode::NODE,config::MAP) :: (nodeCount,totalCost)` |
| algo.allShortestPaths | All shortest paths | `algo.allShortestPaths(startNode::NODE,endNode::NODE,config::MAP) :: (nodeIds,relationshipIds,cost)` |
| algo.native.extract | Extract field values | `algo.native.extract(id::ANY,config::MAP) :: (value::ANY)` |
| db.flushDB | Flush DB | `db.flushDB() :: (::VOID)` |
| dbms.security.listRoles | List roles | `dbms.security.listRoles() :: (role_name,role_info::MAP)` |
| dbms.security.createRole | Create role | `dbms.security.createRole(role_name,desc) :: (::VOID)` |
| dbms.security.deleteRole | Delete role | `dbms.security.deleteRole(role_name) :: (::VOID)` |
| dbms.security.getRoleInfo | Get role info | `dbms.security.getRoleInfo(role) :: (role_info::MAP)` |
| dbms.security.disableRole | Disable/enable role | `dbms.security.disableRole(role,disable) :: (::VOID)` |
| dbms.security.modRoleDesc | Modify role desc | `dbms.security.modRoleDesc(role,description) :: (::VOID)` |
| dbms.security.rebuildRoleAccessLevel | Rebuild role access | `dbms.security.rebuildRoleAccessLevel(role,access_level::MAP) :: (::VOID)` |
| dbms.security.modRoleAccessLevel | Modify role access | `dbms.security.modRoleAccessLevel(role,access_level::MAP) :: (::VOID)` |
| dbms.security.modRoleFieldAccessLevel | Modify role field access | `dbms.security.modRoleFieldAccessLevel(role,graph,label,field,label_type,access_level) :: (::VOID)` |
| dbms.security.getUserInfo | Get user info | `dbms.security.getUserInfo(user) :: (user_info::MAP)` |
| dbms.security.disableUser | Disable/enable user | `dbms.security.disableUser(user,disable) :: (::VOID)` |
| dbms.security.setCurrentDesc | Set current user desc | `dbms.security.setCurrentDesc(description) :: (::VOID)` |
| dbms.security.setUserDesc | Set user desc | `dbms.security.setUserDesc(user,description) :: (::VOID)` |
| dbms.security.getUserMemoryUsage | Get user memory usage | `dbms.security.getUserMemoryUsage(user) :: (memory_usage::INTEGER)` |
| dbms.security.setUserMemoryLimit | Set user memory limit | `dbms.security.setUserMemoryLimit(user,memorylimit) :: (::VOID)` |
| dbms.security.deleteUserRoles | Delete user roles | `dbms.security.deleteUserRoles(user,roles::LIST) :: (::VOID)` |
| dbms.security.rebuildUserRoles | Rebuild user roles | `dbms.security.rebuildUserRoles(user,roles::LIST) :: (::VOID)` |
| dbms.security.addUserRoles | Add user roles | `dbms.security.addUserRoles(user,roles::LIST) :: (::VOID)` |
| dbms.meta.count | Total count | `db.dbms.meta.count() :: (type,number)` |
| dbms.meta.countDetail | Count by label | `db.dbms.meta.countDetail() :: (is_vertex,label,count)` |
| dbms.meta.refreshCount | Refresh count | `db.dbms.meta.refreshCount() :: (::VOID)` |
| dbms.ha.clusterInfo | Cluster info | `dbms.ha.clusterInfo() :: (cluster_info,is_master)` |
| db.dropDB | Drop DB | `db.dropDB() :: (::VOID)` |
| dbms.task.listTasks | List tasks | `dbms.task.listTasks() :: (tasks::LIST)` |
| dbms.task.terminateTask | Terminate task | `dbms.task.terminateTask(task_id) :: (::VOID)` |
