class NovelAgent:

    def __init__(self, theme):
        self.theme = theme
        self.structure = None
        self.characters = None
        self.outline = None
        self.current_chapter = 1

    def generate_story_base(self):
        return {
            "background": "现代都市",
            "core_conflict": "人在关系与自我之间的拉扯",
            "main_question": "人究竟该忠于自己，还是忠于关系？"
        }

    def generate_characters(self):
        return [
            {"name": "主角A", "trait": "克制理性", "desire": "被理解"},
            {"name": "主角B", "trait": "感性冲动", "desire": "被爱"}
        ]

    def generate_outline(self):
        outline = []
        for i in range(1, 51):
            outline.append({
                "chapter": i,
                "title": f"第{i}章",
                "summary": f"关键事件推进 {i}"
            })
        return outline

    def write_chapter(self, chapter_num):
        return f"这是第{chapter_num}章正文内容（约2500字）"

    def next(self):
        content = self.write_chapter(self.current_chapter)
        self.current_chapter += 1
        return content


# 示例执行
agent = NovelAgent("都市情感")
base = agent.generate_story_base()
characters = agent.generate_characters()
outline = agent.generate_outline()

print(base)
print(characters)
print(outline[0])

print(agent.next())