#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Seedance统一视频生成器
支持所有模型：文生视频、图生视频、专业版、轻量版
"""

import sys
import json
import time
import requests
import argparse
import os
from pathlib import Path
from typing import Optional, Dict, List, Tuple

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

class SeedanceUnifiedGenerator:
    """Seedance统一视频生成器"""
    
    def __init__(self, config_path=None):
        """
        初始化统一视频生成器
        
        Args:
            config_path: 配置文件路径
        """
        # 确定配置文件路径
        if config_path is None:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(script_dir, 'config.json')
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 从配置中获取API Key
        self.api_key = self.config.get('api_key')
        
        if not self.api_key:
            raise ValueError("配置文件中缺少api_key")
        
        # API配置
        self.create_task_url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # 模型配置
        self.models = self.config.get('models', {})
        self.parameters = self.config.get('parameters', {})
        
        print(f"✅ Seedance统一视频生成器加载完成")
        print(f"   可用模型: {self.count_models()}个")
        print(f"   支持分辨率: {', '.join(self.parameters.get('resolutions', []))}")
    
    def load_config(self, config_path):
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"❌ 配置文件不存在: {config_path}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"❌ 配置文件格式错误: {e}")
            sys.exit(1)
    
    def count_models(self):
        """计算可用模型数量"""
        count = 0
        if 'text_to_video' in self.models:
            count += len(self.models['text_to_video'])
        if 'image_to_video' in self.models:
            count += len(self.models['image_to_video'])
        return count
    
    def get_model(self, task_type='text_to_video', model_type='pro_fast'):
        """
        获取指定类型的模型
        
        Args:
            task_type: 任务类型 ('text_to_video' 或 'image_to_video')
            model_type: 模型类型 ('pro_fast', 'pro', 'lite')
            
        Returns:
            str: 模型ID，失败返回None
        """
        task_models = self.models.get(task_type, {})
        model_id = task_models.get(model_type)
        
        if not model_id:
            print(f"❌ 未找到模型: {task_type}.{model_type}")
            return None
        
        return model_id
    
    def build_parameters(self, duration=5, resolution="1080p", ratio="16:9",
                        camera_fixed=False, watermark=True, audio_enabled=False):
        """
        构建参数字符串
        
        Args:
            duration: 视频时长
            resolution: 分辨率
            ratio: 宽高比
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            audio_enabled: 是否启用音频
            
        Returns:
            str: 参数字符串
        """
        params = []
        
        # 基本参数
        params.append(f"--duration {duration}")
        
        # 分辨率（如果提供）
        if resolution:
            params.append(f"--resolution {resolution}")
        
        # 宽高比（如果提供）
        if ratio:
            params.append(f"--ratio {ratio}")
        
        # 相机固定
        params.append(f"--camerafixed {str(camera_fixed).lower()}")
        
        # 水印
        params.append(f"--watermark {str(watermark).lower()}")
        
        # 音频
        if audio_enabled:
            params.append("--audio true")
        
        return " ".join(params)
    
    def create_text_to_video_task(self, prompt, duration=5, resolution="1080p", 
                                 ratio="16:9", camera_fixed=False, watermark=True,
                                 audio_enabled=False, model_type="pro_fast"):
        """
        创建文生视频任务
        
        Args:
            prompt: 文本提示词
            duration: 视频时长
            resolution: 分辨率
            ratio: 宽高比
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            audio_enabled: 是否启用音频
            model_type: 模型类型 ('pro_fast' 或 'lite')
            
        Returns:
            tuple: (任务ID, 模型ID)，失败返回(None, None)
        """
        print("🎬 创建文生视频任务...")
        
        # 获取模型
        model_id = self.get_model('text_to_video', model_type)
        if not model_id:
            return None, None
        
        print(f"  使用模型: {model_id} ({model_type})")
        
        # 构建参数
        params = self.build_parameters(
            duration=duration,
            resolution=resolution,
            ratio=ratio,
            camera_fixed=camera_fixed,
            watermark=watermark,
            audio_enabled=audio_enabled
        )
        
        # 构建完整的提示词
        full_prompt = f"{prompt} {params}"
        print(f"  提示词: {prompt[:100]}...")
        print(f"  参数: {params}")
        
        # 构建请求数据
        payload = {
            "model": model_id,
            "content": [
                {
                    "type": "text",
                    "text": full_prompt
                }
            ]
        }
        
        return self._send_request(payload, model_id)
    
    def create_image_to_video_task(self, prompt, image_url, duration=5, 
                                  resolution="1080p", ratio="16:9", 
                                  camera_fixed=False, watermark=True,
                                  audio_enabled=False, model_type="pro"):
        """
        创建图生视频任务
        
        Args:
            prompt: 文本提示词
            image_url: 图片URL
            duration: 视频时长
            resolution: 分辨率
            ratio: 宽高比
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            audio_enabled: 是否启用音频
            model_type: 模型类型 ('pro' 或 'lite')
            
        Returns:
            tuple: (任务ID, 模型ID)，失败返回(None, None)
        """
        print("🎬 创建图生视频任务...")
        
        # 获取模型
        model_id = self.get_model('image_to_video', model_type)
        if not model_id:
            return None, None
        
        print(f"  使用模型: {model_id} ({model_type})")
        print(f"  图片URL: {image_url[:100]}...")
        
        # 构建参数
        params = self.build_parameters(
            duration=duration,
            resolution=resolution,
            ratio=ratio,
            camera_fixed=camera_fixed,
            watermark=watermark,
            audio_enabled=audio_enabled
        )
        
        # 构建完整的提示词
        full_prompt = f"{prompt} {params}"
        print(f"  提示词: {prompt[:100]}...")
        print(f"  参数: {params}")
        
        # 构建请求数据
        payload = {
            "model": model_id,
            "content": [
                {
                    "type": "text",
                    "text": full_prompt
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": image_url
                    }
                }
            ]
        }
        
        return self._send_request(payload, model_id)
    
    def _send_request(self, payload, model_id):
        """发送API请求"""
        try:
            response = requests.post(
                self.create_task_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                task_id = result.get('id')
                
                if task_id:
                    print(f"✅ 任务创建成功!")
                    print(f"  任务ID: {task_id}")
                    return task_id, model_id
                else:
                    print(f"❌ 任务创建失败，响应中没有任务ID")
                    print(f"  响应: {result}")
                    return None, model_id
            else:
                print(f"❌ 任务创建失败 - 状态码: {response.status_code}")
                print(f"  响应: {response.text[:200]}")
                return None, model_id
                
        except Exception as e:
            print(f"❌ 创建任务时出错: {e}")
            return None, model_id
    
    def check_task_status(self, task_id):
        """检查任务状态"""
        url = f"{self.create_task_url}/{task_id}"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ 查询任务状态失败 - 状态码: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ 查询任务状态时出错: {e}")
            return None
    
    def download_video(self, video_url, output_path):
        """下载视频文件"""
        try:
            print(f"📥 开始下载视频...")
            
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(video_url, headers=headers, stream=True, timeout=60)
            
            if response.status_code == 200:
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(output_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f'  下载进度: {percent:.1f}%', end='\r')
                
                print(f'\n✅ 视频下载完成!')
                print(f'  文件大小: {os.path.getsize(output_path)} bytes')
                return True
            else:
                print(f'❌ 下载失败 - 状态码: {response.status_code}')
                return False
                
        except Exception as e:
            print(f'❌ 下载视频时出错: {str(e)}')
            return False
    
    def poll_and_download(self, task_id, output_path, max_attempts=60, interval=10):
        """轮询任务状态并下载视频"""
        print(f"\n🔍 开始轮询任务状态...")
        
        for attempt in range(1, max_attempts + 1):
            print(f"\n尝试 #{attempt}/{max_attempts}")
            
            result = self.check_task_status(task_id)
            
            if not result:
                print("  查询任务状态失败")
                continue
            
            status = result.get('status', 'unknown')
            print(f"  状态: {status}")
            
            if status == 'succeeded':
                print("  ✅ 视频生成成功!")
                
                video_url = None
                if 'content' in result and 'video_url' in result['content']:
                    video_url = result['content']['video_url']
                elif 'output' in result and 'video_url' in result['output']:
                    video_url = result['output']['video_url']
                
                if video_url:
                    success = self.download_video(video_url, output_path)
                    
                    if success:
                        print(f"\n🎉 视频下载完成!")
                        print(f"文件位置: {output_path}")
                        return True
                    else:
                        print(f"\n❌ 视频下载失败")
                        return False
                else:
                    print("  ❌ 任务成功但没有找到视频URL")
                    return False
                    
            elif status == 'failed':
                print("  ❌ 视频生成失败")
                if 'error' in result:
                    error = result['error']
                    print(f"  错误代码: {error.get('code')}")
                    print(f"  错误信息: {error.get('message')}")
                return False
                
            elif status == 'running':
                print("  ⏳ 视频正在生成中...")
                pass
                
            else:
                print(f"  📝 未知状态: {status}")
            
            if attempt < max_attempts:
                print(f"  等待 {interval}秒后重试...")
                time.sleep(interval)
        
        print(f"\n❌ 超过最大尝试次数")
        return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Seedance统一视频生成器')
    
    # 任务类型
    parser.add_argument('--task-type', choices=['text', 'image'], default='text',
                       help='任务类型: text(文生视频) 或 image(图生视频)')
    
    # 必需参数
    parser.add_argument('--prompt', required=True, help='文本提示词')
    
    # 图生视频专用参数
    parser.add_argument('--image-url', help='图片URL（图生视频必需）')
    
    # 模型选择
    parser.add_argument('--model-type', choices=['pro_fast', 'pro', 'lite'], 
                       default='pro_fast', help='模型类型')
    
    # 视频参数
    parser.add_argument('--duration', type=int, default=5, help='视频时长（4-12秒）')
    parser.add_argument('--resolution', default='1080p', help='分辨率')
    parser.add_argument('--ratio', default='16:9', help='宽高比')
    parser.add_argument('--camera-fixed', action='store_true', help='相机固定')
    parser.add_argument('--no-watermark', action='store_true', help='不添加水印')
    parser.add_argument('--audio', action='store_true', help='启用音频支持')
    
    # 输出和轮询
    parser.add_argument('--output', '-o', help='输出文件路径')
    parser.add_argument('--poll', action='store_true', help='自动轮询并下载')
    parser.add_argument('--max-attempts', type=int, default=60, help='最大轮询次数')
    parser.add_argument('--interval', type=int, default=10, help='轮询间隔秒数')
    
    args = parser.parse_args()
    
    # 验证参数
    if args.task_type == 'image' and not args.image_url:
        print("❌ 图生视频需要 --image-url 参数")
        return
    
    # 初始化生成器
    try:
        generator = SeedanceUnifiedGenerator()
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        return
    
    # 确定输出路径
    if args.output:
        output_path = args.output
    else:
        desktop = Path.home() / "Desktop"
        task_type = "t2v" if args.task_type == "text" else "i2v"
        safe_prompt = args.prompt[:50].replace(' ', '_').replace('/', '_')
        output_path = str(desktop / f"seedance_{task_type}_{safe_prompt}.mp4")
    
    # 创建任务
    if args.task_type == 'text':
        task_id, model_id = generator.create_text_to_video_task(
            prompt=args.prompt,
            duration=args.duration,
            resolution=args.resolution,
            ratio=args.ratio,
            camera_fixed=args.camera_fixed,
            watermark=not args.no_watermark,
            audio_enabled=args.audio,
            model_type=args.model_type
        )
    else:  # image
        task_id, model_id = generator.create_image_to_video_task(
            prompt=args.prompt,
            image_url=args.image_url,
            duration=args.duration,
            resolution=args.resolution,
            ratio=args.ratio,
            camera_fixed=args.camera_fixed,
            watermark=not args.no_watermark,
            audio_enabled=args.audio,
            model_type=args.model_type
        )
    
    if not task_id:
        print("❌ 任务创建失败")
        return
    
    # 轮询和下载
    if args.poll:
        success = generator.poll_and_download(
            task_id=task_id,
            output_path=output_path,
            max_attempts=args.max_attempts,
            interval=args.interval
        )
        
        if success:
            print(f"\n🎉 视频生成流程完成!")
            print(f"模型: {model_id}")
            print(f"文件: {output_path}")
        else:
            print(f"\n❌ 视频生成流程失败")
    else:
        print(f"\n📋 任务已创建:")
        print(f"任务ID: {task_id}")
        print(f"模型: {model_id}")
        print(f"查询命令: python3 check_task.py {task_id} --download")

if __name__ == '__main__':
    main()