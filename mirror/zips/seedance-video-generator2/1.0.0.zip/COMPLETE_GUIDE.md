# Seedance视频生成完整指南

## 🎯 功能概述

本技能包提供完整的火山引擎Seedance视频生成功能，包括：

### 1. **文生视频 (Text-to-Video)**
- 根据文本提示词生成视频
- 支持音频参数
- 自动轮询和下载

### 2. **图生视频 (Image-to-Video)**
- 根据图片+文本生成视频
- 基于参考图片创建动画
- 支持相同的参数配置

## 📦 可用脚本

### 1. `seedance_enhanced.py` - 增强版文生视频
```bash
# 基本使用
python3 seedance_enhanced.py "你的提示词" --poll

# 带音频
python3 seedance_enhanced.py "提示词" --audio --poll

# 测试音频支持
python3 seedance_enhanced.py "测试" --test-audio
```

### 2. `seedance_image_to_video.py` - 图生视频
```bash
# 基本使用
python3 seedance_image_to_video.py "提示词" --image-url "图片URL" --poll

# 带音频
python3 seedance_image_to_video.py "提示词" --image-url "图片URL" --audio --poll
```

### 3. `check_task.py` - 任务状态查询
```bash
# 查询任务状态
python3 check_task.py 任务ID

# 查询并下载
python3 check_task.py 任务ID --download
```

## 🔧 配置文件 (`config.json`)

```json
{
  "api_key": "你的火山引擎API Key",
  "models": {
    "text_to_video": "doubao-seedance-1-0-pro-fast-251015",
    "image_to_video": "doubao-seedance-1-0-pro-250528",
    "fallback": [
      "Doubao-Seedance-1.0-pro",
      "Doubao-Seedance-1.0-lite-t2v",
      "Doubao-Seedance-1.0-lite-i2v"
    ]
  },
  "audio_support": {
    "tested": true,
    "valid_parameters": ["--audio true"],
    "invalid_parameters": ["--with_audio true", "--generate_audio true"]
  }
}
```

## 🎵 音频支持

### 已验证：
- **有效参数**: `--audio true`
- **模型**: `doubao-seedance-1-0-pro-fast-251015` (文生视频)
- **状态**: 参数被API接受，但账户额度耗尽无法测试效果

### 待测试：
- `doubao-seedance-1-0-pro-250528` (图生视频) 的音频支持

## 🚀 快速开始示例

### 示例1：抽象搞笑文生视频
```bash
python3 seedance_enhanced.py \
  "一个穿着西装戴着香蕉头套的企鹅在跳不协调的踢踏舞，手持的吐司机突然弹出烤焦的面包片，面包片在空中旋转变成会飞的鱼，鱼撞到墙上变成彩色烟雾，烟雾中浮现'为什么？'文字" \
  --duration 12 \
  --no-watermark \
  --audio \
  --poll
```

### 示例2：图生视频（基于示例图片）
```bash
python3 seedance_image_to_video.py \
  "无人机以极快速度穿越复杂障碍或自然奇观，带来沉浸式飞行体验" \
  --image-url "https://ark-project.tos-cn-beijing.volces.com/doc_image/seepro_i2v.png" \
  --duration 5 \
  --poll
```

### 示例3：测试音频支持
```bash
# 测试文生视频音频
python3 seedance_enhanced.py "测试音频" --test-audio

# 测试图生视频音频（需要先有可用的图片URL）
python3 seedance_image_to_video.py "测试" --image-url "图片URL" --audio --poll
```

## ⚠️ 已知问题和解决方案

### 问题1：账户额度耗尽
**症状**：
```
错误代码: SetLimitExceeded
错误信息: Your account has reached the set inference limit
```

**解决方案**：
1. 登录火山引擎控制台
2. 找到"Model Activation"页面
3. 调整或关闭"Safe Experience Mode"

### 问题2：模型不存在
**症状**：
```
错误代码: InvalidEndpointOrModel.NotFound
错误信息: The model or endpoint does not exist or you do not have access to it
```

**解决方案**：
1. 使用已验证的模型ID：
   - 文生视频: `doubao-seedance-1-0-pro-fast-251015`
   - 图生视频: `doubao-seedance-1-0-pro-250528`
2. 申请其他模型的访问权限

### 问题3：视频无声音
**症状**：生成的视频播放时没有声音

**解决方案**：
1. 添加 `--audio true` 参数
2. 如果账户额度足够，测试音频效果
3. 或使用后期添加音频的方法

## 💡 最佳实践

### 1. **提示词编写**
- 具体描述场景、动作、风格
- 包含技术参数：`--duration 12 --resolution 1080p`
- 对于抽象内容，提供具体的视觉描述

### 2. **参数选择**
- **时长**: 4-12秒（短视频效果好）
- **分辨率**: 1080p（平衡质量和速度）
- **水印**: 测试时关闭，正式使用时开启
- **音频**: 需要时添加 `--audio true`

### 3. **工作流程**
```
1. 编写提示词 → 2. 测试短时长 → 3. 调整参数 → 4. 生成最终视频
```

### 4. **错误处理**
- 查看详细的错误信息
- 检查API Key和模型ID
- 验证账户额度和权限

## 🔍 故障排除

### 常见错误：
| 错误 | 原因 | 解决方案 |
|------|------|----------|
| `SetLimitExceeded` | 账户额度耗尽 | 调整安全体验模式 |
| `InvalidEndpointOrModel.NotFound` | 模型ID错误 | 使用正确的模型ID |
| 视频无声音 | 默认无声 | 添加 `--audio true` |
| 任务创建失败 | 参数格式错误 | 检查提示词格式 |

### 调试步骤：
1. 运行 `--test-audio` 测试音频参数
2. 检查 `config.json` 配置
3. 验证API Key有效性
4. 查看火山引擎控制台状态

## 📞 支持资源

### 官方资源：
- 火山引擎控制台: https://console.volcengine.com/
- 火山引擎文档: https://www.volcengine.com/docs/
- API文档: 查看控制台中的API指南

### 技能支持：
- 脚本帮助: `python3 脚本名.py --help`
- 配置文件: `config.json` 中的注释
- 示例文件: 查看脚本目录中的示例

## 🚀 下一步开发

### 计划功能：
1. **批量生成**：一次生成多个视频变体
2. **视频编辑**：基本的剪辑和合并功能
3. **质量优化**：自动优化提示词和参数
4. **额度监控**：实时显示账户使用情况

### 欢迎贡献：
- 提交Issue报告问题
- 提交Pull Request添加功能
- 分享使用经验和最佳实践

---

**祝您视频生成愉快！** 🎬