#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试不同Seedance模型的成本效益
"""

import json
import time
import requests
from pathlib import Path

def test_model_cost(model_id, prompt, is_image_to_video=False, image_url=None):
    """
    测试单个模型的成本（基于API响应）
    
    Args:
        model_id: 模型ID
        prompt: 提示词
        is_image_to_video: 是否为图生视频
        image_url: 图片URL（图生视频需要）
        
    Returns:
        dict: 测试结果
    """
    print(f"\n🔍 测试模型: {model_id}")
    print(f"  类型: {'图生视频' if is_image_to_video else '文生视频'}")
    
    # API配置（需要配置API Key）
    # 请从火山引擎控制台获取API Key: https://console.volcengine.com/
    api_key = "YOUR_VOLCANO_ENGINE_API_KEY_HERE"
    url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # 构建请求数据
    content = [
        {
            "type": "text",
            "text": f"{prompt} --duration 5 --resolution 720p --camerafixed false --watermark true"
        }
    ]
    
    if is_image_to_video and image_url:
        content.append({
            "type": "image_url",
            "image_url": {
                "url": image_url
            }
        })
    
    payload = {
        "model": model_id,
        "content": content
    }
    
    try:
        # 发送请求
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        
        result = {
            "model": model_id,
            "type": "image_to_video" if is_image_to_video else "text_to_video",
            "status_code": response.status_code,
            "success": response.status_code == 200
        }
        
        if response.status_code == 200:
            data = response.json()
            task_id = data.get('id')
            result["task_id"] = task_id
            result["message"] = "任务创建成功"
            
            print(f"  ✅ 任务创建成功")
            print(f"    任务ID: {task_id}")
            
            # 尝试获取更多信息
            if task_id:
                # 查询任务详情
                time.sleep(2)
                task_url = f"{url}/{task_id}"
                task_response = requests.get(task_url, headers=headers, timeout=30)
                
                if task_response.status_code == 200:
                    task_data = task_response.json()
                    result["task_status"] = task_data.get('status')
                    
                    # 分析可能的成本因素
                    cost_factors = {
                        "model_complexity": "专业版" if "pro" in model_id else "轻量版",
                        "video_type": "图生视频" if is_image_to_video else "文生视频",
                        "has_fast": "快速版" if "fast" in model_id else "标准版",
                        "resolution": "720p",
                        "duration": 5
                    }
                    result["cost_factors"] = cost_factors
                    
        else:
            error_data = response.json() if response.text else {}
            result["error"] = error_data
            result["message"] = f"请求失败: {response.status_code}"
            
            print(f"  ❌ 请求失败: {response.status_code}")
            if error_data:
                print(f"    错误: {error_data.get('error', {}).get('message', '未知错误')}")
        
        return result
        
    except Exception as e:
        print(f"  ❌ 测试出错: {e}")
        return {
            "model": model_id,
            "type": "image_to_video" if is_image_to_video else "text_to_video",
            "success": False,
            "error": str(e),
            "message": f"测试异常: {e}"
        }

def main():
    """主测试函数"""
    print("=" * 60)
    print("火山引擎Seedance模型成本测试")
    print("=" * 60)
    
    # 测试的模型列表
    models_to_test = [
        # 文生视频模型
        {
            "id": "doubao-seedance-1-0-pro-fast-251015",
            "name": "文生视频专业快速版",
            "is_image": False,
            "predicted_cost": "高"
        },
        {
            "id": "doubao-seedance-1-0-lite-t2v-250428",
            "name": "文生视频轻量版",
            "is_image": False,
            "predicted_cost": "低"
        },
        # 图生视频模型
        {
            "id": "doubao-seedance-1-0-pro-250528",
            "name": "图生视频专业版",
            "is_image": True,
            "predicted_cost": "中高"
        },
        {
            "id": "doubao-seedance-1-0-lite-i2v-250428",
            "name": "图生视频轻量版",
            "is_image": True,
            "predicted_cost": "最低"
        }
    ]
    
    # 测试参数
    test_prompt = "简单的测试场景，蓝天白云"
    test_image_url = "https://ark-project.tos-cn-beijing.volces.com/doc_image/see_i2v.jpeg"
    
    results = []
    
    print(f"\n📋 测试配置:")
    print(f"  提示词: {test_prompt}")
    print(f"  图片URL: {test_image_url[:80]}...")
    print(f"  时长: 5秒")
    print(f"  分辨率: 720p")
    
    # 测试每个模型
    for model_info in models_to_test:
        model_id = model_info["id"]
        model_name = model_info["name"]
        is_image = model_info["is_image"]
        predicted_cost = model_info["predicted_cost"]
        
        print(f"\n{'='*40}")
        print(f"测试: {model_name}")
        print(f"模型ID: {model_id}")
        print(f"预测成本: {predicted_cost}")
        print(f"{'='*40}")
        
        # 执行测试
        result = test_model_cost(
            model_id=model_id,
            prompt=test_prompt,
            is_image_to_video=is_image,
            image_url=test_image_url if is_image else None
        )
        
        # 添加额外信息
        result["model_name"] = model_name
        result["predicted_cost"] = predicted_cost
        
        results.append(result)
        
        # 短暂等待避免频率限制
        time.sleep(3)
    
    # 输出总结报告
    print(f"\n{'='*60}")
    print("测试结果总结")
    print(f"{'='*60}")
    
    successful_models = []
    failed_models = []
    
    for result in results:
        if result.get("success"):
            successful_models.append(result)
        else:
            failed_models.append(result)
    
    print(f"\n✅ 成功的模型 ({len(successful_models)}个):")
    for model in successful_models:
        print(f"  • {model['model_name']}")
        print(f"    模型ID: {model['model']}")
        print(f"    预测成本: {model['predicted_cost']}")
        print(f"    任务ID: {model.get('task_id', 'N/A')}")
        print(f"    状态: {model.get('task_status', 'N/A')}")
        print()
    
    print(f"\n❌ 失败的模型 ({len(failed_models)}个):")
    for model in failed_models:
        print(f"  • {model['model_name']}")
        print(f"    模型ID: {model['model']}")
        print(f"    错误: {model.get('message', '未知错误')}")
        print()
    
    # 成本分析
    print(f"\n💰 成本分析建议:")
    print(f"1. 从成功模型中选择:")
    for model in successful_models:
        cost_level = model['predicted_cost']
        if cost_level in ["低", "最低"]:
            print(f"  推荐: {model['model_name']} (预测成本: {cost_level})")
    
    print(f"\n2. 实际成本确认方法:")
    print(f"  a. 登录火山引擎控制台查看定价")
    print(f"  b. 少量测试后查看账单")
    print(f"  c. 联系客服获取报价单")
    
    print(f"\n3. 成本优化策略:")
    print(f"  • 测试阶段使用轻量版模型")
    print(f"  • 生产阶段根据质量需求选择")
    print(f"  • 优化提示词减少重试次数")
    print(f"  • 批量生成可能享受折扣")
    
    # 保存测试结果
    output_file = Path.home() / "Desktop" / "seedance_model_test_results.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print(f"\n📁 详细测试结果已保存到: {output_file}")

if __name__ == "__main__":
    main()