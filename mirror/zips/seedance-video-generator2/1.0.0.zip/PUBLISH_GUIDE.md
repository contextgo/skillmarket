# Video-Generator-Seedance Skill 发布指南

## 技能概述
这是一个基于火山引擎Seedance API的视频生成技能，支持文本到视频和图生视频功能。

## 文件结构
```
video-generator-seedance/
├── SKILL.md                    # 技能主文档
├── _meta.json                  # 技能元数据
├── config.json                 # 配置文件（已清理API密钥）
├── config.example.json         # 配置示例文件
├── README.md                   # 使用说明
├── README_SEEDANCE.md          # Seedance专用说明
├── PUBLISH_GUIDE.md           # 本发布指南
├── *.py                       # 所有Python脚本
└── scripts/                   # 脚本目录
```

## 已完成的清理工作
✅ 已替换所有硬编码的API密钥为 `YOUR_VOLCANO_ENGINE_API_KEY_HERE`
✅ 已清理配置文件中的敏感信息
✅ 已保留完整的示例和文档
✅ 已验证所有脚本从配置文件读取API密钥

## 发布到SkillHub步骤

### 1. 创建GitHub仓库
```bash
# 在GitHub创建新仓库
# 仓库名建议：video-generator-seedance
# 描述：OpenClaw skill for Seedance video generation
# 选择Public仓库
```

### 2. 上传文件到GitHub
```bash
# 克隆仓库
git clone https://github.com/你的用户名/video-generator-seedance.git
cd video-generator-seedance

# 复制所有文件
cp -r /path/to/seedance_skill_clean/* .

# 提交并推送
git add .
git commit -m "Initial release: Video Generator Seedance skill"
git push origin main
```

### 3. 发布到SkillHub
```bash
# 使用OpenClaw技能发布工具
npx skills publish https://github.com/你的用户名/video-generator-seedance

# 或使用GitHub URL直接安装
npx skills add https://github.com/你的用户名/video-generator-seedance
```

## 技能配置说明

### 用户安装后需要：
1. 获取火山引擎API密钥：https://console.volcengine.com/
2. 复制 `config.example.json` 为 `config.json`
3. 在 `config.json` 中填入自己的API密钥
4. 运行技能测试

### 配置文件示例：
```json
{
  "api_key": "sk-你的火山引擎API密钥",
  "models": {
    "text_to_video": {
      "pro_fast": "doubao-seedance-1-0-pro-fast-251015",
      "lite": "doubao-seedance-1-0-lite-t2v-250428"
    }
  }
}
```

## 技能功能特点

### 核心功能：
1. **文本到视频**：支持多种模型（pro_fast, lite）
2. **图生视频**：基于参考图片生成视频
3. **参数丰富**：支持时长、分辨率、宽高比等
4. **异步处理**：自动轮询和下载视频

### 主要脚本：
- `seedance_unified.py` - 统一生成器（推荐）
- `seedance_enhanced.py` - 增强版生成器
- `seedance_image_to_video.py` - 图生视频生成器
- `poll_and_download.py` - 轮询和下载工具

## 测试建议
发布前建议：
1. 使用测试API密钥验证所有功能
2. 确保文档清晰易懂
3. 提供完整的示例命令
4. 说明常见错误和解决方法

## 版本信息
- **当前版本**：v1.0.0
- **依赖**：Python 3.7+, requests库
- **兼容性**：OpenClaw所有平台
- **许可证**：MIT（建议）

## 联系方式
- 作者：你的名字
- GitHub：你的GitHub主页
- 问题反馈：GitHub Issues

---
祝发布顺利！🎉