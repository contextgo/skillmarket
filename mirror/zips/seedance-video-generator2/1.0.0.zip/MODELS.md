# Seedance 模型全称列表

本文档列出了火山引擎Seedance API支持的所有模型全称。

## 📊 模型总览

### 文本到视频模型（Text-to-Video）
| 模型别名 | 全称模型ID | 官方名称 | 最大时长 | 分辨率 | 音频 | 水印 | 推荐用途 |
|----------|------------|----------|----------|--------|------|------|----------|
| `pro_fast` | `doubao-seedance-1-0-pro-fast-251015` | Seedance 1.0 Pro Fast | 12秒 | 1080p, 720p | ✅ | 默认开启 | 快速高质量生成 |
| `standard` | `doubao-seedance-1-0-t2v-250428` | Seedance 1.0 Standard | 10秒 | 1080p, 720p | ❌ | 默认开启 | 平衡质量速度 |
| `lite` | `doubao-seedance-1-0-lite-t2v-250428` | Seedance 1.0 Lite | 12秒 | 720p | ❌ | 默认开启 | 低成本测试 |

### 图生视频模型（Image-to-Video）
| 模型别名 | 全称模型ID | 官方名称 | 最大时长 | 分辨率 | 音频 | 水印 | 推荐用途 |
|----------|------------|----------|----------|--------|------|------|----------|
| `pro` | `doubao-seedance-1-0-pro-250528` | Seedance 1.0 Pro | 12秒 | 1080p, 720p | ✅ | 默认开启 | 专业图生视频 |
| `lite` | `doubao-seedance-1-0-lite-i2v-250428` | Seedance 1.0 Lite | 10秒 | 720p | ❌ | 默认开启 | 轻量图生视频 |

## 🔍 模型详细信息

### doubao-seedance-1-0-pro-fast-251015
- **类型**：文本到视频
- **版本**：1.0 Pro Fast
- **发布日期**：2025-10-15
- **特点**：
  - 生成速度最快
  - 支持音频生成
  - 高质量输出
  - 适合实时应用
- **限制**：
  - 可能需要调整安全模式
  - 成本相对较高

### doubao-seedance-1-0-t2v-250428  
- **类型**：文本到视频
- **版本**：1.0 Standard
- **发布日期**：2025-04-28
- **特点**：
  - 平衡质量和速度
  - 稳定的生成效果
  - 适合一般用途
- **限制**：
  - 不支持音频
  - 最大时长10秒

### doubao-seedance-1-0-lite-t2v-250428
- **类型**：文本到视频
- **版本**：1.0 Lite
- **发布日期**：2025-04-28
- **特点**：
  - 成本最低
  - 生成速度快
  - 适合测试和批量生成
- **限制**：
  - 仅支持720p
  - 不支持音频
  - 质量相对较低

### doubao-seedance-1-0-pro-250528
- **类型**：图生视频
- **版本**：1.0 Pro
- **发布日期**：2025-05-28
- **特点**：
  - 基于图片生成高质量视频
  - 支持音频生成
  - 运动预测准确
- **限制**：
  - 需要参考图片
  - 成本较高

### doubao-seedance-1-0-lite-i2v-250428
- **类型**：图生视频
- **版本**：1.0 Lite
- **发布日期**：2025-04-28
- **特点**：
  - 轻量级图生视频
  - 成本较低
  - 适合简单动画
- **限制**：
  - 仅支持720p
  - 不支持音频
  - 最大时长10秒

## ⚙️ 配置示例

### 最小配置
```json
{
  "api_key": "your-api-key",
  "models": {
    "text_to_video": {
      "pro_fast": "doubao-seedance-1-0-pro-fast-251015"
    }
  }
}
```

### 完整配置
```json
{
  "api_key": "your-api-key",
  "models": {
    "text_to_video": {
      "pro_fast": "doubao-seedance-1-0-pro-fast-251015",
      "standard": "doubao-seedance-1-0-t2v-250428",
      "lite": "doubao-seedance-1-0-lite-t2v-250428"
    },
    "image_to_video": {
      "pro": "doubao-seedance-1-0-pro-250528",
      "lite": "doubao-seedance-1-0-lite-i2v-250428"
    }
  }
}
```

## 🎯 使用建议

### 根据需求选择模型

| 使用场景 | 推荐模型 | 理由 |
|----------|----------|------|
| 快速测试 | `lite` (文本或图生) | 成本低，速度快 |
| 高质量生成 | `pro_fast` (文本) / `pro` (图生) | 质量高，支持音频 |
| 平衡方案 | `standard` | 质量速度平衡 |
| 批量生成 | `lite` | 成本控制 |
| 实时应用 | `pro_fast` | 生成速度快 |

### 参数优化
```bash
# 高质量输出
--model-type pro_fast --resolution 1080p --duration 12 --audio true

# 快速测试  
--model-type lite --resolution 720p --duration 5

# 平衡方案
--model-type standard --resolution 1080p --duration 8
```

## 🔄 模型更新

火山引擎会定期更新模型，建议：
1. 定期查看官方文档
2. 测试新模型性能
3. 更新配置文件
4. 调整生成参数

## 📚 官方资源

- 模型文档：https://www.volcengine.com/docs/ai-services/seedance/models
- API文档：https://www.volcengine.com/docs/ai-services/seedance/api
- 控制台：https://console.volcengine.com/

## ❓ 常见问题

### Q: 如何知道模型是否可用？
A: 在火山引擎控制台的模型服务中查看，或使用 `test_model_costs.py --list-models`

### Q: 模型有使用限制吗？
A: 是的，每个模型可能有时长、分辨率、并发数等限制

### Q: 如何切换模型？
A: 修改config.json中的模型ID，或使用 `--model-type` 参数

### Q: 新模型如何添加？
A: 在config.json的对应类别中添加新模型ID即可

---

**最后更新**：2026-04-03  
**数据来源**：火山引擎官方文档  
**注意**：模型信息可能随时间变化，请以官方文档为准