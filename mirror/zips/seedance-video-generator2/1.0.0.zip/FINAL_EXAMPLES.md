# Seedance视频生成最终示例

基于你提供的准确API示例，这里是最新的使用指南：

## 🎯 已验证的模型ID

### 文生视频 (Text-to-Video)
1. **专业快速版**: `doubao-seedance-1-0-pro-fast-251015`
2. **轻量版**: `doubao-seedance-1-0-lite-t2v-250428`

### 图生视频 (Image-to-Video)
1. **专业版**: `doubao-seedance-1-0-pro-250528`
2. **轻量版**: `doubao-seedance-1-0-lite-i2v-250428`

## 🚀 统一脚本使用示例

### 示例1：文生视频（雏菊花田 - 你提供的示例）
```bash
python3 seedance_unified.py \
  --task-type text \
  --prompt "写实风格，晴朗的蓝天之下，一大片白色的雏菊花田，镜头逐渐拉近，最终定格在一朵雏菊花的特写上，花瓣上有几颗晶莹的露珠" \
  --model-type lite \
  --ratio 16:9 \
  --resolution 720p \
  --duration 5 \
  --no-watermark \
  --poll
```

### 示例2：图生视频（云和车辆 - 你提供的示例）
```bash
python3 seedance_unified.py \
  --task-type image \
  --prompt "天空的云飘动着，路上的车辆行驶" \
  --image-url "https://ark-project.tos-cn-beijing.volces.com/doc_image/see_i2v.jpeg" \
  --model-type lite \
  --resolution 720p \
  --duration 5 \
  --no-watermark \
  --poll
```

### 示例3：抽象搞笑视频（带音频）
```bash
python3 seedance_unified.py \
  --task-type text \
  --prompt "一个穿着西装戴着香蕉头套的企鹅在跳不协调的踢踏舞，手持的吐司机突然弹出烤焦的面包片，面包片在空中旋转变成会飞的鱼，鱼撞到墙上变成彩色烟雾，烟雾中浮现'为什么？'文字" \
  --model-type pro_fast \
  --duration 12 \
  --resolution 1080p \
  --no-watermark \
  --audio \
  --poll
```

### 示例4：专业版图生视频
```bash
python3 seedance_unified.py \
  --task-type image \
  --prompt "无人机以极快速度穿越复杂障碍或自然奇观，带来沉浸式飞行体验" \
  --image-url "https://ark-project.tos-cn-beijing.volces.com/doc_image/seepro_i2v.png" \
  --model-type pro \
  --duration 5 \
  --resolution 1080p \
  --poll
```

## 🔧 直接API调用示例

### 文生视频（轻量版）：
```bash
curl -X POST https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY" \
  -d '{
    "model": "doubao-seedance-1-0-lite-t2v-250428",
    "content": [
      {
        "type": "text",
        "text": "写实风格，晴朗的蓝天之下，一大片白色的雏菊花田，镜头逐渐拉近，最终定格在一朵雏菊花的特写上，花瓣上有几颗晶莹的露珠 --ratio 16:9 --resolution 720p --duration 5 --camerafixed false --watermark true"
      }
    ]
  }'
```

### 图生视频（轻量版）：
```bash
curl -X POST https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY" \
  -d '{
    "model": "doubao-seedance-1-0-lite-i2v-250428",
    "content": [
      {
        "type": "text",
        "text": "天空的云飘动着，路上的车辆行驶 --resolution 720p --duration 5 --camerafixed false --watermark true"
      },
      {
        "type": "image_url",
        "image_url": {
          "url": "https://ark-project.tos-cn-beijing.volces.com/doc_image/see_i2v.jpeg"
        }
      }
    ]
  }'
```

## 🎵 音频支持说明

### 已验证：
- **参数**: `--audio true` 被API接受
- **模型**: `doubao-seedance-1-0-pro-fast-251015`
- **状态**: 账户额度耗尽，无法测试实际效果

### 待测试：
- 轻量版模型是否支持音频
- 图生视频模型是否支持音频
- 实际音频生成质量

## ⚠️ 当前限制

### 账户限制：
```
错误代码: SetLimitExceeded
解决方案: 调整火山引擎"安全体验模式"
```

### 模型访问：
- 专业快速版：额度耗尽
- 轻量版：可能需要测试访问权限
- 所有模型：需要有效的API Key

## 💡 使用建议

### 1. **参数选择**
- **轻量版**: 使用720p分辨率，速度更快
- **专业版**: 使用1080p分辨率，质量更高
- **音频**: 需要时添加 `--audio true`

### 2. **提示词优化**
- 具体描述场景和动作
- 包含风格和细节
- 参考提供的示例格式

### 3. **工作流程**
```
1. 测试短时长（5秒）
2. 验证模型可用性
3. 调整参数和提示词
4. 生成最终视频
```

## 🚀 立即行动建议

### 第一步：测试轻量版模型
```bash
# 测试文生视频轻量版
python3 seedance_unified.py \
  --task-type text \
  --prompt "简单的测试场景" \
  --model-type lite \
  --duration 5 \
  --poll

# 测试图生视频轻量版
python3 seedance_unified.py \
  --task-type image \
  --prompt "测试动画" \
  --image-url "https://ark-project.tos-cn-beijing.volces.com/doc_image/see_i2v.jpeg" \
  --model-type lite \
  --duration 5 \
  --poll
```

### 第二步：调整账户设置
1. 登录火山引擎控制台
2. 调整"安全体验模式"
3. 测试专业版模型和音频功能

### 第三步：全面测试
1. 测试所有4个模型
2. 验证音频支持
3. 优化提示词和参数

---

**所有技术准备已完成，现在可以全面测试Seedance视频生成功能！** 🎬