# Video Generator Seedance - OpenClaw Skill

基于火山引擎Seedance API的视频生成技能，支持文本到视频和图生视频。

## 🚀 快速开始

### 1. 安装
```bash
npx skills add https://github.com/yourusername/video-generator-seedance
```

### 2. 配置
1. 获取火山引擎API密钥：https://console.volcengine.com/
2. 复制 `config.example.json` 为 `config.json`
3. 填入你的API密钥

### 3. 使用
```bash
# 生成第一个视频
python seedance_unified.py --task-type text --prompt "美丽的风景" --poll
```

## 📋 支持的模型（全称）

### 文本到视频模型
- **doubao-seedance-1-0-pro-fast-251015** (pro_fast) - 快速专业版
- **doubao-seedance-1-0-t2v-250428** (standard) - 标准版  
- **doubao-seedance-1-0-lite-t2v-250428** (lite) - 轻量版

### 图生视频模型
- **doubao-seedance-1-0-pro-250528** (pro) - 专业图生视频版
- **doubao-seedance-1-0-lite-i2v-250428** (lite) - 轻量图生视频版

## 🎬 功能特性

### 核心功能
- ✅ 文本到视频生成
- ✅ 图生视频生成  
- ✅ 多种模型选择
- ✅ 丰富的参数控制
- ✅ 异步处理和自动下载
- ✅ 错误处理和重试机制

### 参数支持
- **时长**：4-12秒
- **分辨率**：1080p, 720p
- **宽高比**：16:9, 9:16, 1:1
- **相机运动**：固定、推拉、平移、旋转等
- **水印控制**：可开启/关闭
- **音频支持**：部分模型支持音频生成

## 📁 文件结构

```
video-generator-seedance/
├── SKILL.md                    # 技能主文档
├── README.md                   # 本文件
├── config.json                 # 完整配置文件（含模型全称）
├── config.example.json         # 配置示例
├── seedance_unified.py         # 统一生成器（推荐）
├── seedance_enhanced.py        # 增强版生成器
├── seedance_image_to_video.py  # 图生视频生成器
├── seedance_1_0_pro_generator.py # 专业版生成器
├── poll_and_download.py        # 轮询下载工具
├── check_task.py               # 任务状态检查
├── test_model_costs.py         # 模型成本测试
└── scripts/                    # 辅助脚本目录
```

## 🔧 详细使用

### 基本命令
```bash
# 使用统一生成器
python seedance_unified.py --task-type text --prompt "你的提示词"

# 使用增强版生成器  
python seedance_enhanced.py "你的提示词" --poll

# 图生视频
python seedance_image_to_video.py "提示词" --image-url "图片URL"
```

### 完整示例
```bash
# 生成12秒搞笑视频
python seedance_unified.py --task-type text \
  --prompt "超现实办公室场景，程序员与智能咖啡杯争吵，咖啡杯跳舞洒出彩虹咖啡，搞笑幽默" \
  --duration 12 \
  --model-type lite \
  --ratio 16:9 \
  --resolution 720p \
  --camera-fixed \
  --poll \
  --output "搞笑视频.mp4"
```

## ⚡ 性能指标

### 生成时间
- **lite模型**：1-2分钟
- **pro_fast模型**：2-3分钟
- **pro模型**：3-5分钟

### 视频质量
- **lite**：基础质量，适合测试和快速生成
- **standard**：平衡质量和速度
- **pro_fast**：高质量，快速生成
- **pro**：最高质量，适合专业用途

## 🛠️ 开发指南

### 添加新模型
在 `config.json` 的 `models` 部分添加新模型：
```json
{
  "models": {
    "text_to_video": {
      "new_model": "模型全称ID"
    }
  }
}
```

### 扩展功能
1. 修改现有脚本添加新参数
2. 创建新的生成脚本
3. 添加批量处理功能
4. 集成其他视频处理工具

## 📚 文档资源

### 官方文档
- 火山引擎控制台：https://console.volcengine.com/
- Seedance API文档：https://www.volcengine.com/docs/ai-services/seedance
- 模型列表：https://www.volcengine.com/docs/ai-services/seedance/models

### 技能文档
- `SKILL.md` - 完整使用指南
- `COMPLETE_GUIDE.md` - 完整指南
- `USAGE_ENHANCED.md` - 高级用法
- `FINAL_EXAMPLES.md` - 最终示例

## 🤝 贡献指南

### 报告问题
1. 在GitHub Issues中创建新问题
2. 描述问题现象和复现步骤
3. 提供错误信息和日志

### 提交改进
1. Fork本仓库
2. 创建功能分支
3. 提交更改
4. 创建Pull Request

## 📄 许可证

MIT License - 详见LICENSE文件

## 👥 作者和维护者

- **作者**：你的名字
- **GitHub**：@yourusername
- **邮箱**：your.email@example.com

## 🔗 相关链接

- OpenClaw官方网站：https://openclaw.ai
- SkillHub：https://skillhub.openclaw.ai
- 火山引擎：https://www.volcengine.com/

---
**提示**：使用本技能前，请确保已了解并同意火山引擎的服务条款和费用政策。