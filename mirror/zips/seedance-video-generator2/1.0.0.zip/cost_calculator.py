#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
火山引擎Seedance视频生成成本计算器
基于官方定价信息
"""

import json
from typing import Dict, List, Tuple

class SeedanceCostCalculator:
    """Seedance成本计算器"""
    
    def __init__(self):
        """初始化成本计算器"""
        # 官方定价数据（来自火山方舟控制台）
        self.pricing_data = {
            "models": {
                "doubao-seedance-1-0-pro-fast-251015": {
                    "name": "Doubao-Seedance-1.0-pro-fast",
                    "online_pricing": {
                        "text_to_video": 0.0042,  # 元/千tokens
                        "image_to_video": 0.0042   # 元/千tokens
                    },
                    "batch_pricing": {
                        "text_to_video": 0.0021,   # 元/千tokens
                        "image_to_video": 0.0021   # 元/千tokens
                    },
                    "status": "服务暂停",
                    "remaining_tokens": 10000,
                    "total_tokens": 2000000
                },
                "doubao-seedance-1-0-pro-250528": {
                    "name": "Doubao-Seedance-1.0-pro",
                    "online_pricing": {
                        "text_to_video": 0.0150,   # 元/千tokens
                        "image_to_video": 0.0150   # 元/千tokens
                    },
                    "batch_pricing": {
                        "text_to_video": 0.0075,   # 元/千tokens
                        "image_to_video": 0.0075   # 元/千tokens
                    },
                    "status": "已开通",
                    "remaining_tokens": 1896182,
                    "total_tokens": 2000000
                },
                "doubao-seedance-1-0-lite-t2v-250428": {
                    "name": "Doubao-Seedance-1.0-lite-t2v",
                    "online_pricing": {
                        "text_to_video": 0.0100,   # 元/千tokens
                        "image_to_video": None     # 不支持
                    },
                    "batch_pricing": {
                        "text_to_video": 0.0050,   # 元/千tokens
                        "image_to_video": None     # 不支持
                    },
                    "status": "已开通",
                    "remaining_tokens": 1896182,
                    "total_tokens": 2000000
                },
                "doubao-seedance-1-0-lite-i2v-250428": {
                    "name": "Doubao-Seedance-1.0-lite-i2v",
                    "online_pricing": {
                        "text_to_video": None,     # 不支持
                        "image_to_video": 0.0100   # 元/千tokens
                    },
                    "batch_pricing": {
                        "text_to_video": None,     # 不支持
                        "image_to_video": 0.0050   # 元/千tokens
                    },
                    "status": "已开通",
                    "remaining_tokens": 1896182,
                    "total_tokens": 2000000
                }
            },
            "assumptions": {
                "tokens_per_second": 200,      # 每秒视频大约需要的tokens
                "prompt_tokens": 100,          # 提示词tokens
                "image_tokens": 500,           # 图片输入的tokens
                "batch_threshold": 10          # 批量推理阈值（个）
            }
        }
    
    def calculate_video_cost(self, model_id: str, task_type: str, 
                           duration: int = 5, is_batch: bool = False,
                           count: int = 1) -> Dict:
        """
        计算视频生成成本
        
        Args:
            model_id: 模型ID
            task_type: 任务类型 ('text_to_video' 或 'image_to_video')
            duration: 视频时长（秒）
            is_batch: 是否批量推理
            count: 生成数量
            
        Returns:
            dict: 成本计算结果
        """
        if model_id not in self.pricing_data["models"]:
            return {"error": f"未知模型: {model_id}"}
        
        model_info = self.pricing_data["models"][model_id]
        
        # 检查模型是否支持该任务类型
        pricing_key = "batch_pricing" if is_batch else "online_pricing"
        pricing = model_info[pricing_key]
        
        if task_type not in pricing or pricing[task_type] is None:
            return {"error": f"模型 {model_info['name']} 不支持 {task_type}"}
        
        # 计算tokens数量
        assumptions = self.pricing_data["assumptions"]
        
        # 基础tokens（提示词）
        base_tokens = assumptions["prompt_tokens"]
        
        # 视频内容tokens
        video_tokens = assumptions["tokens_per_second"] * duration
        
        # 图片输入tokens（如果是图生视频）
        if task_type == "image_to_video":
            base_tokens += assumptions["image_tokens"]
        
        # 总tokens
        total_tokens = base_tokens + video_tokens
        
        # 计算成本（元/千tokens）
        price_per_k_tokens = pricing[task_type]
        cost_per_video = (total_tokens / 1000) * price_per_k_tokens
        
        # 总成本
        total_cost = cost_per_video * count
        
        # 批量折扣信息
        batch_discount = 0
        if is_batch:
            online_price = model_info["online_pricing"][task_type]
            batch_price = model_info["batch_pricing"][task_type]
            if online_price and batch_price:
                batch_discount = (online_price - batch_price) / online_price * 100
        
        return {
            "model": model_info["name"],
            "model_id": model_id,
            "task_type": task_type,
            "duration": duration,
            "is_batch": is_batch,
            "count": count,
            "estimated_tokens": {
                "prompt": assumptions["prompt_tokens"],
                "image": assumptions["image_tokens"] if task_type == "image_to_video" else 0,
                "video_per_second": assumptions["tokens_per_second"],
                "video_content": video_tokens,
                "total": total_tokens
            },
            "pricing": {
                "price_per_k_tokens": price_per_k_tokens,
                "cost_per_video": round(cost_per_video, 4),
                "total_cost": round(total_cost, 4)
            },
            "batch_info": {
                "discount_percentage": round(batch_discount, 1) if is_batch else 0,
                "threshold": assumptions["batch_threshold"]
            },
            "model_status": model_info["status"],
            "remaining_tokens": model_info["remaining_tokens"],
            "can_generate_videos": model_info["remaining_tokens"] // total_tokens if total_tokens > 0 else 0
        }
    
    def compare_all_models(self, task_type: str, duration: int = 5, count: int = 1):
        """
        比较所有模型的成本
        
        Args:
            task_type: 任务类型
            duration: 视频时长
            count: 生成数量
            
        Returns:
            list: 所有模型的成本比较
        """
        results = []
        
        for model_id in self.pricing_data["models"]:
            # 检查模型是否支持该任务类型
            model_info = self.pricing_data["models"][model_id]
            pricing = model_info["online_pricing"]
            
            if task_type in pricing and pricing[task_type] is not None:
                # 计算在线推理成本
                online_result = self.calculate_video_cost(
                    model_id, task_type, duration, False, count
                )
                
                # 计算批量推理成本（如果数量达到阈值）
                batch_result = None
                if count >= self.pricing_data["assumptions"]["batch_threshold"]:
                    batch_result = self.calculate_video_cost(
                        model_id, task_type, duration, True, count
                    )
                
                results.append({
                    "model": model_info["name"],
                    "model_id": model_id,
                    "status": model_info["status"],
                    "online_cost": online_result["pricing"]["total_cost"],
                    "batch_cost": batch_result["pricing"]["total_cost"] if batch_result else None,
                    "batch_saving": round(
                        (online_result["pricing"]["total_cost"] - batch_result["pricing"]["total_cost"]) / 
                        online_result["pricing"]["total_cost"] * 100, 1
                    ) if batch_result else 0,
                    "remaining_tokens": model_info["remaining_tokens"],
                    "details": online_result
                })
        
        # 按成本排序
        results.sort(key=lambda x: x["online_cost"])
        
        return results
    
    def generate_cost_report(self, task_type: str, duration: int = 5, count: int = 1):
        """
        生成成本报告
        
        Args:
            task_type: 任务类型
            duration: 视频时长
            count: 生成数量
        """
        print("=" * 70)
        print("火山引擎Seedance视频生成成本报告")
        print("=" * 70)
        print(f"任务类型: {'文生视频' if task_type == 'text_to_video' else '图生视频'}")
        print(f"视频时长: {duration}秒")
        print(f"生成数量: {count}个")
        print()
        
        # 比较所有模型
        comparisons = self.compare_all_models(task_type, duration, count)
        
        print("📊 模型成本比较（从低到高）:")
        print("-" * 70)
        
        for i, model in enumerate(comparisons, 1):
            status_icon = "✅" if model["status"] == "已开通" else "⚠️"
            batch_info = ""
            
            if model["batch_cost"] is not None:
                batch_info = f" | 批量: ¥{model['batch_cost']:.4f} (节省{model['batch_saving']}%)"
            
            print(f"{i}. {status_icon} {model['model']}")
            print(f"   模型ID: {model['model_id']}")
            print(f"   状态: {model['status']}")
            print(f"   在线成本: ¥{model['online_cost']:.4f}{batch_info}")
            print(f"   剩余额度: {model['remaining_tokens']:,} tokens")
            print()
        
        print("💰 成本计算详情:")
        print("-" * 70)
        
        # 显示最便宜模型的详细计算
        if comparisons:
            cheapest = comparisons[0]
            details = cheapest["details"]
            
            print(f"最经济模型: {cheapest['model']}")
            print(f"预估tokens使用:")
            print(f"  • 提示词: {details['estimated_tokens']['prompt']} tokens")
            
            if task_type == "image_to_video":
                print(f"  • 图片输入: {details['estimated_tokens']['image']} tokens")
            
            print(f"  • 视频内容: {details['estimated_tokens']['video_content']} tokens")
            print(f"  • 总计: {details['estimated_tokens']['total']} tokens")
            print()
            print(f"单价: ¥{details['pricing']['price_per_k_tokens']:.4f}/千tokens")
            print(f"单个视频成本: ¥{details['pricing']['cost_per_video']:.4f}")
            print(f"总成本: ¥{details['pricing']['total_cost']:.4f}")
            
            if count >= self.pricing_data["assumptions"]["batch_threshold"]:
                print()
                print(f"💡 批量推理建议:")
                print(f"  生成{count}个视频达到批量阈值")
                print(f"  批量价格: ¥{cheapest['batch_cost']:.4f}")
                print(f"  节省: {cheapest['batch_saving']}%")
        
        print()
        print("💡 使用建议:")
        print("-" * 70)
        
        # 根据状态给出建议
        available_models = [m for m in comparisons if m["status"] == "已开通"]
        suspended_models = [m for m in comparisons if m["status"] == "服务暂停"]
        
        if available_models:
            print(f"1. 当前可用最经济模型: {available_models[0]['model']}")
            print(f"   成本: ¥{available_models[0]['online_cost']:.4f}")
        
        if suspended_models:
            print(f"2. 最便宜模型 {suspended_models[0]['model']} 服务暂停")
            print(f"   需要调整安全体验模式恢复使用")
            print(f"   恢复后成本可降低: ¥{available_models[0]['online_cost'] - suspended_models[0]['online_cost']:.4f}")
        
        if count >= self.pricing_data["assumptions"]["batch_threshold"]:
            print(f"3. 批量生成建议:")
            print(f"   当前数量({count})达到批量阈值")
            print(f"   使用批量推理可节省约50%成本")
        
        print()
        print("📝 注意事项:")
        print("-" * 70)
        print("• 以上成本为预估，实际tokens使用可能有所不同")
        print("• 批量推理需要达到一定数量阈值")
        print("• 服务暂停的模型需要调整账户设置恢复")
        print("• 建议定期查看火山引擎控制台的实际扣费")

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='火山引擎Seedance成本计算器')
    parser.add_argument('--task-type', choices=['text', 'image'], default='text',
                       help='任务类型: text(文生视频) 或 image(图生视频)')
    parser.add_argument('--duration', type=int, default=5, help='视频时长（秒）')
    parser.add_argument('--count', type=int, default=1, help='生成数量')
    parser.add_argument('--output', '-o', help='输出JSON文件路径')
    
    args = parser.parse_args()
    
    # 转换任务类型
    task_type = 'text_to_video' if args.task_type == 'text' else 'image_to_video'
    
    # 创建计算器
    calculator = SeedanceCostCalculator()
    
    # 生成报告
    calculator.generate_cost_report(task_type, args.duration, args.count)
    
    # 如果需要保存详细数据
    if args.output:
        comparisons = calculator.compare_all_models(task_type, args.duration, args.count)
        
        output_data = {
            "task_type": task_type,
            "duration": args.duration,
            "count": args.count,
            "comparisons": comparisons,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        import json
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n📁 详细数据已保存到: {args.output}")

if __name__ == "__main__":
    import time
    main()