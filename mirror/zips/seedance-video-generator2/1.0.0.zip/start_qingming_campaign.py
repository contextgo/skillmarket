#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
清明节专题内容快速启动脚本
一键生成清明节系列视频内容
"""

import subprocess
import sys
from pathlib import Path
import json
from datetime import datetime, timedelta

class QingmingCampaignStarter:
    """清明节专题启动器"""
    
    def __init__(self):
        self.script_dir = Path(__file__).parent
        self.output_dir = Path.home() / "Desktop" / "清明节专题内容"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 清明节日期
        self.qingming_date = datetime(2026, 4, 4)
        self.today = datetime(2026, 4, 2)
        
        # 内容计划
        self.content_plan = {
            "4月2日": [
                {"name": "清明出行全攻略", "style": "travel", "duration": 15},
                {"name": "十大热门目的地", "style": "scenery", "duration": 18},
            ],
            "4月3日": [
                {"name": "全国赏花地图", "style": "scenery", "duration": 18},
                {"name": "青团制作教程", "style": "food", "duration": 15},
            ],
            "4月4日": [
                {"name": "清明习俗科普", "style": "culture", "duration": 12},
                {"name": "祭祖礼仪讲解", "style": "culture", "duration": 15},
            ],
            "4月5日": [
                {"name": "踏青拍照技巧", "style": "scenery", "duration": 12},
                {"name": "地方特色小吃", "style": "food", "duration": 18},
            ],
            "4月6日": [
                {"name": "亲子游好去处", "style": "travel", "duration": 15},
                {"name": "清明家宴菜单", "style": "food", "duration": 12},
            ]
        }
    
    def print_banner(self):
        """打印横幅"""
        print("=" * 70)
        print("清明节专题内容生成系统")
        print("=" * 70)
        print(f"当前日期: {self.today.strftime('%Y年%m月%d日')}")
        print(f"清明节: {self.qingming_date.strftime('%Y年%m月%d日')}")
        print(f"输出目录: {self.output_dir}")
        print("=" * 70)
    
    def calculate_days_until(self):
        """计算距离清明节天数"""
        delta = self.qingming_date - self.today
        return delta.days
    
    def generate_today_content(self):
        """生成今日内容"""
        today_key = self.today.strftime("%m月%d日")
        
        if today_key not in self.content_plan:
            print(f"❌ 今日({today_key})无内容计划")
            return False
        
        print(f"\n📅 生成今日内容: {today_key}")
        print("-" * 50)
        
        today_content = self.content_plan[today_key]
        success_count = 0
        
        for item in today_content:
            print(f"\n🎬 生成: {item['name']}")
            print(f"   风格: {item['style']}")
            print(f"   时长: {item['duration']}秒")
            
            # 构建命令
            cmd = [
                sys.executable, "generate_hot_topic_video.py",
                "--topic", "qingming",
                "--style", item["style"],
                "--output-dir", str(self.output_dir)
            ]
            
            try:
                result = subprocess.run(cmd, cwd=self.script_dir, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print(f"   ✅ 生成成功")
                    success_count += 1
                else:
                    print(f"   ❌ 生成失败")
                    print(f"      错误: {result.stderr[:200]}")
                    
            except Exception as e:
                print(f"   ❌ 执行出错: {e}")
        
        print(f"\n📊 今日完成: {success_count}/{len(today_content)} 个视频")
        return success_count > 0
    
    def generate_all_content(self):
        """生成所有内容"""
        print(f"\n📅 生成全部清明节内容")
        print("-" * 50)
        
        total_videos = 0
        success_videos = 0
        
        for date_key, content_list in self.content_plan.items():
            print(f"\n🗓️ {date_key}:")
            
            for item in content_list:
                total_videos += 1
                print(f"  • {item['name']} ({item['style']}, {item['duration']}秒)")
                
                # 构建命令
                cmd = [
                    sys.executable, "generate_hot_topic_video.py",
                    "--topic", "qingming",
                    "--style", item["style"],
                    "--output-dir", str(self.output_dir / date_key)
                ]
                
                try:
                    result = subprocess.run(cmd, cwd=self.script_dir, capture_output=True, text=True)
                    
                    if result.returncode == 0:
                        success_videos += 1
                        print(f"    ✅ 成功")
                    else:
                        print(f"    ❌ 失败")
                        
                except Exception as e:
                    print(f"    ❌ 错误: {e}")
            
            # 日期间短暂等待
            import time
            time.sleep(2)
        
        print(f"\n📊 总体完成: {success_videos}/{total_videos} 个视频")
        
        # 成本计算
        self.calculate_cost(success_videos)
        
        return success_videos
    
    def calculate_cost(self, video_count):
        """计算成本"""
        print(f"\n💰 成本分析")
        print("-" * 50)
        
        # 平均每个视频成本（基于15秒估算）
        avg_cost_per_video = 0.0313  # 元
        
        total_cost = avg_cost_per_video * video_count
        
        print(f"生成视频数量: {video_count}个")
        print(f"平均单价: ¥{avg_cost_per_video:.4f}/视频")
        print(f"预估总成本: ¥{total_cost:.4f}")
        
        # 批量优惠
        if video_count >= 10:
            batch_cost = total_cost * 0.5
            saving = total_cost - batch_cost
            print(f"批量优惠价: ¥{batch_cost:.4f} (节省¥{saving:.4f})")
        
        print(f"\n💡 成本说明:")
        print(f"• 使用最经济的 lite-t2v 模型")
        print(f"• 实际成本以火山引擎账单为准")
        print(f"• 批量生成可享受额外优惠")
    
    def create_content_summary(self):
        """创建内容总结报告"""
        summary_file = self.output_dir / "清明节专题内容总结.md"
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write("# 清明节专题内容总结\n\n")
            f.write(f"生成时间: {datetime.now().strftime('%Y年%m月%d日 %H:%M:%S')}\n")
            f.write(f"输出目录: {self.output_dir}\n\n")
            
            f.write("## 内容计划\n\n")
            for date_key, content_list in self.content_plan.items():
                f.write(f"### {date_key}\n")
                for item in content_list:
                    f.write(f"- **{item['name']}**\n")
                    f.write(f"  - 风格: {item['style']}\n")
                    f.write(f"  - 时长: {item['duration']}秒\n")
                f.write("\n")
            
            f.write("## 使用说明\n\n")
            f.write("### 一键生成命令\n")
            f.write("```bash\n")
            f.write("cd /Users/macos13/.openclaw/workspace/skills/video-generator-seedance\n")
            f.write("python3 start_qingming_campaign.py --all\n")
            f.write("```\n\n")
            
            f.write("### 单个视频生成\n")
            f.write("```bash\n")
            f.write("python3 generate_hot_topic_video.py --topic qingming --style travel\n")
            f.write("```\n\n")
            
            f.write("## 成本预估\n\n")
            f.write("| 视频数量 | 预估成本 | 批量优惠价 |\n")
            f.write("|----------|----------|------------|\n")
            f.write("| 1个 | ¥0.0313 | - |\n")
            f.write("| 10个 | ¥0.3130 | ¥0.1565 |\n")
            f.write("| 全部10个 | ¥0.3130 | ¥0.1565 |\n\n")
        
        print(f"\n📄 内容总结已保存: {summary_file}")
    
    def show_quick_commands(self):
        """显示快速命令"""
        print(f"\n⚡ 快速命令")
        print("-" * 50)
        
        print("1. 生成今日内容:")
        print(f"   cd {self.script_dir}")
        print(f"   python3 start_qingming_campaign.py --today")
        
        print("\n2. 生成全部内容:")
        print(f"   cd {self.script_dir}")
        print(f"   python3 start_qingming_campaign.py --all")
        
        print("\n3. 生成特定风格:")
        print(f"   cd {self.script_dir}")
        print(f"   python3 generate_hot_topic_video.py --topic qingming --style travel")
        
        print("\n4. 计算成本:")
        print(f"   cd {self.script_dir}")
        print(f"   python3 cost_calculator.py --task-type text --duration 15 --count 10")

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='清明节专题内容快速启动')
    parser.add_argument('--today', action='store_true', help='生成今日内容')
    parser.add_argument('--all', action='store_true', help='生成全部内容')
    parser.add_argument('--summary', action='store_true', help='创建内容总结')
    
    args = parser.parse_args()
    
    starter = QingmingCampaignStarter()
    starter.print_banner()
    
    days_until = starter.calculate_days_until()
    print(f"距离清明节还有: {days_until}天")
    
    if args.today:
        starter.generate_today_content()
    elif args.all:
        starter.generate_all_content()
    elif args.summary:
        starter.create_content_summary()
    else:
        starter.show_quick_commands()
        
        print(f"\n🎯 建议操作:")
        if days_until >= 2:
            print(f"1. 立即生成今日内容: python3 start_qingming_campaign.py --today")
            print(f"2. 或生成全部内容: python3 start_qingming_campaign.py --all")
        else:
            print(f"1. 立即生成全部内容: python3 start_qingming_campaign.py --all")
            print(f"2. 重点生成节日当天内容")

if __name__ == "__main__":
    main()