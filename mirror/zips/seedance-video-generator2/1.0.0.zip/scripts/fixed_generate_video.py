#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复版：使用火山引擎 SD1.5pro API 生成视频
使用正确的parameters格式，支持4-12秒视频生成
"""

import sys
import json
import time
import requests
import argparse
import os

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

class SD15ProVideoGeneratorFixed:
    """修复版 SD1.5pro 视频生成器 - 使用正确的parameters格式"""
    
    def __init__(self, config_path=None):
        """
        初始化视频生成器
        
        Args:
            config_path: 配置文件路径，如果为None则使用默认路径
        """
        # 确定配置文件路径
        if config_path is None:
            # 使用技能目录中的config.json
            script_dir = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(script_dir, '..', 'config.json')
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 从配置中获取API Key和模型ID
        self.api_key = self.config.get('api_key')
        self.model = self.config.get('model', 'doubao-seedance-1-5-pro-251215')  # 默认模型
        
        if not self.api_key:
            raise ValueError("配置文件中缺少api_key，请在config.json中配置API Key")
        
        # API配置
        self.create_task_url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

    def load_config(self, config_path):
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"❌ 配置文件不存在: {config_path}")
            print("💡 请创建config.json文件，包含api_key和model配置")
            sys.exit(1)
        except json.JSONDecodeError:
            print(f"❌ 配置文件格式错误: {config_path}")
            sys.exit(1)

    def create_video_task(self, prompt, image_url=None, duration=5, camera_fixed=False, watermark=True):
        """
        创建视频生成任务（修复版：使用正确的parameters格式）
        
        Args:
            prompt: 文本提示词
            image_url: 参考图片URL（可选，图生视频）
            duration: 视频时长（4-12秒）
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            
        Returns:
            task_id: 任务ID，失败返回None
        """
        print("🎬 SD1.5pro 视频生成器（修复版）")
        print("=" * 60)
        print("🎬 开始创建视频任务...")
        print(f"  模型: {self.model}")
        print(f"  提示词: {prompt[:50]}..." if len(prompt) > 50 else f"  提示词: {prompt}")
        print(f"  参考图片: {'有' if image_url else '无'}（{'图生视频' if image_url else '纯文本生成'}）")
        print(f"  时长: {duration}秒（支持4-12秒）")
        print(f"  相机固定: {camera_fixed}")
        print(f"  水印: {watermark}")
        print()
        
        # 验证时长参数
        if duration < 4 or duration > 12:
            print(f"❌ 时长参数错误: {duration}秒")
            print("💡 Seedance 1.5 Pro支持4-12秒视频生成")
            return None
        
        # 构建content数组
        content = [
            {
                "type": "text",
                "text": prompt  # 注意：不再包含参数在text中
            }
        ]
        
        # 如果提供了参考图片，添加到content中
        if image_url:
            content.append({
                "type": "image_url",
                "image_url": {
                    "url": image_url
                }
            })
        
        # 修复版：使用正确的parameters格式
        payload = {
            "model": self.model,
            "parameters": {
                "duration": duration,
                "camera_fixed": camera_fixed,
                "watermark": watermark
            },
            "content": content
        }
        
        print("📝 请求体（修复版 - 正确格式）:")
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        print()
        
        try:
            response = requests.post(
                self.create_task_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            print(f"📥 响应状态码: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                print("📝 响应内容:")
                print(json.dumps(result, ensure_ascii=False, indent=2))
                print()
                
                # 提取任务ID
                if "id" in result:
                    task_id = result["id"]
                    print(f"✅ 视频生成任务已创建")
                    print(f"  任务ID: {task_id}")
                    return task_id
                else:
                    print("❌ 响应中未找到任务ID")
                    return None
            else:
                print(f"❌ 创建任务失败")
                error_text = response.text
                print(f"  错误信息: {error_text}")
                
                # 解析错误信息
                try:
                    error_data = json.loads(error_text)
                    if "error" in error_data:
                        error_msg = error_data["error"].get("message", "")
                        if "SetLimitExceeded" in error_msg:
                            print("\n💡 账户限制提示:")
                            print("   您的账户已达到模型推理限制")
                            print("   请访问Model Activation页面调整或关闭'Safe Experience Mode'")
                        elif "duration" in error_msg.lower():
                            print("\n💡 时长参数提示:")
                            print("   Seedance 1.5 Pro支持4-12秒视频生成")
                            print(f"   当前设置: {duration}秒")
                except:
                    pass
                    
                return None
                
        except Exception as e:
            print(f"❌ 创建视频任务时出错: {e}")
            return None
    
    def check_task_status(self, task_id):
        """
        查询任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息，失败返回None
        """
        if not task_id:
            print("❌ 任务ID为空")
            return None
        
        poll_url = f"{self.create_task_url}/{task_id}"
        
        try:
            response = requests.get(poll_url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result
            else:
                print(f"❌ 查询任务状态失败: {response.status_code}")
                print(f"  错误信息: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ 查询任务状态时出错: {e}")
            return None
    
    def wait_for_task_completion(self, task_id, max_wait_seconds=300, poll_interval=10):
        """
        等待任务完成
        
        Args:
            task_id: 任务ID
            max_wait_seconds: 最大等待时间（秒）
            poll_interval: 轮询间隔（秒）
            
        Returns:
            dict: 完成的任务信息，超时或失败返回None
        """
        if not task_id:
            return None
        
        print(f"⏳ 等待任务完成...")
        print(f"  最大等待时间: {max_wait_seconds}秒")
        print(f"  轮询间隔: {poll_interval}秒")
        
        start_time = time.time()
        poll_count = 0
        
        while time.time() - start_time < max_wait_seconds:
            poll_count += 1
            print(f"\n🔍 查询任务状态: {task_id}")
            print(f"  轮询次数: {poll_count}")
            print(f"  已等待: {int(time.time() - start_time)}秒")
            
            task_info = self.check_task_status(task_id)
            
            if not task_info:
                print("❌ 获取任务状态失败")
                return None
            
            status = task_info.get("status")
            print(f"  状态: {status}")
            
            if status == "SUCCEEDED":
                print("✅ 任务完成!")
                return task_info
            elif status == "FAILED":
                print("❌ 任务失败")
                error = task_info.get("error", {})
                print(f"  错误代码: {error.get('code', '未知')}")
                print(f"  错误信息: {error.get('message', '未知')}")
                return None
            elif status in ["PENDING", "RUNNING"]:
                # 继续等待
                print(f"  视频生成中，等待{poll_interval}秒...")
                time.sleep(poll_interval)
            else:
                print(f"⚠️ 未知状态: {status}")
                time.sleep(poll_interval)
        
        print(f"❌ 等待超时（{max_wait_seconds}秒）")
        return None
    
    def download_video(self, task_info, output_path):
        """
        下载生成的视频
        
        Args:
            task_info: 任务信息
            output_path: 输出文件路径
            
        Returns:
            bool: 是否下载成功
        """
        if not task_info:
            print("❌ 任务信息为空")
            return False
        
        # 获取视频URL
        content = task_info.get("content", {})
        video_url = content.get("video_url")
        
        if not video_url:
            print("❌ 任务信息中没有视频URL")
            return False
        
        print(f"📥 下载视频...")
        print(f"  URL: {video_url[:80]}...")
        print(f"  保存到: {output_path}")
        
        try:
            response = requests.get(video_url, timeout=60, stream=True)
            
            if response.status_code == 200:
                total_size = int(response.headers.get('content-length', 0))
                
                with open(output_path, 'wb') as f:
                    if total_size == 0:
                        f.write(response.content)
                    else:
                        downloaded = 0
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                
                                # 显示进度
                                if total_size > 0:
                                    percent = (downloaded / total_size) * 100
                                    print(f"  下载进度: {percent:.1f}% ({downloaded:,}/{total_size:,} 字节)", end='\r')
                
                file_size = os.path.getsize(output_path)
                print(f"\n✅ 视频下载完成!")
                print(f"  文件大小: {file_size:,} 字节 ({file_size/1024/1024:.2f} MB)")
                return True
            else:
                print(f"❌ 下载失败: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ 下载视频时出错: {e}")
            return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='使用火山引擎 SD1.5pro API 生成视频（修复版）')
    parser.add_argument('prompt', help='文本提示词')
    parser.add_argument('--image', '-i', help='参考图片URL（图生视频）')
    parser.add_argument('--duration', '-d', type=int, default=5, help='视频时长（4-12秒，默认5秒）')
    parser.add_argument('--output', '-o', help='输出文件路径')
    parser.add_argument('--camera-fixed', action='store_true', help='相机固定（默认False）')
    parser.add_argument('--watermark', action='store_false', help='不添加水印（默认添加）')
    
    args = parser.parse_args()
    
    # 创建生成器
    generator = SD15ProVideoGeneratorFixed()
    
    # 创建视频任务
    task_id = generator.create_video_task(
        prompt=args.prompt,
        image_url=args.image,
        duration=args.duration,
        camera_fixed=args.camera_fixed,
        watermark=args.watermark
    )
    
    if not task_id:
        print("❌ 无法创建视频任务")
        sys.exit(1)
    
    # 等待任务完成
    task_info = generator.wait_for_task_completion(task_id)
    
    if not task_info:
        print("❌ 视频生成失败或超时")
        sys.exit(1)
    
    # 确定输出路径
    if args.output:
        output_path = args.output
    else:
        # 默认输出到桌面
        desktop = os.path.expanduser("~/Desktop")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(desktop, f"video_{timestamp}.mp4")
    
    # 下载视频
    success = generator.download_video(task_info, output_path)
    
    if success:
        print(f"\n🎉 视频生成完成!")
        print(f"  文件位置: {output_path}")
    else:
        print("\n❌ 视频下载失败")
        sys.exit(1)

if __name__ == "__main__":
    main()