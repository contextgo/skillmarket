#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轮询任务状态并下载视频
"""

import requests
import json
import time
import os

def poll_task_status(task_id, api_key, max_attempts=60, interval=10):
    """
    轮询任务状态
    
    Args:
        task_id: 任务ID
        api_key: API密钥
        max_attempts: 最大轮询次数
        interval: 轮询间隔（秒）
    
    Returns:
        dict: 任务结果，如果失败返回None
    """
    url = f'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/{task_id}'
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    print(f'开始轮询任务状态: {task_id}')
    print(f'最大轮询次数: {max_attempts}，间隔: {interval}秒')
    print('=' * 50)
    
    for attempt in range(1, max_attempts + 1):
        try:
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                status = result.get('status', 'unknown')
                
                print(f'第{attempt}次轮询 - 状态: {status}')
                
                if status == 'succeeded':
                    print('✅ 视频生成成功！')
                    return result
                elif status == 'failed':
                    print('❌ 视频生成失败')
                    if 'error' in result:
                        error = result['error']
                        print(f'错误代码: {error.get("code")}')
                        print(f'错误信息: {error.get("message")}')
                    return None
                elif status == 'running':
                    print('⏳ 视频生成中...')
                else:
                    print(f'📝 未知状态: {status}')
                    
            else:
                print(f'第{attempt}次轮询失败 - 状态码: {response.status_code}')
                print(f'响应: {response.text[:200]}')
                
        except Exception as e:
            print(f'第{attempt}次轮询出错: {str(e)}')
        
        # 如果不是最后一次尝试，等待间隔时间
        if attempt < max_attempts:
            print(f'等待{interval}秒后继续轮询...')
            time.sleep(interval)
    
    print(f'⚠️ 达到最大轮询次数({max_attempts})，任务可能仍在处理中')
    return None

def download_video(video_url, output_path, api_key):
    """
    下载视频文件
    
    Args:
        video_url: 视频URL
        output_path: 输出文件路径
        api_key: API密钥
    """
    try:
        print(f'开始下载视频: {video_url}')
        print(f'保存到: {output_path}')
        
        headers = {
            'Authorization': f'Bearer {api_key}'
        }
        
        response = requests.get(video_url, headers=headers, stream=True, timeout=60)
        
        if response.status_code == 200:
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # 下载文件
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        # 显示进度
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            print(f'下载进度: {percent:.1f}% ({downloaded}/{total_size} bytes)', end='\r')
            
            print(f'\n✅ 视频下载完成: {output_path}')
            print(f'文件大小: {os.path.getsize(output_path)} bytes')
            return True
        else:
            print(f'❌ 下载失败 - 状态码: {response.status_code}')
            return False
            
    except Exception as e:
        print(f'❌ 下载视频时出错: {str(e)}')
        return False

def main():
    # 从配置文件读取API Key
    config_path = 'config.json'
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    api_key = config.get('api_key')
    task_id = 'cgt-20260402093149-2zthw'  # 你的任务ID
    output_path = '/Users/macos13/Desktop/抽象视频_12秒_图生视频.mp4'
    
    if not api_key:
        print('❌ 配置文件中缺少api_key')
        return
    
    print('=' * 50)
    print('火山引擎视频生成状态轮询')
    print('=' * 50)
    
    # 轮询任务状态
    result = poll_task_status(task_id, api_key, max_attempts=30, interval=15)
    
    if result and result.get('status') == 'succeeded':
        # 检查是否有视频URL
        if 'output' in result and 'video_url' in result['output']:
            video_url = result['output']['video_url']
            print(f'\n🎬 视频URL: {video_url}')
            
            # 下载视频
            print('\n' + '=' * 50)
            print('开始下载视频')
            print('=' * 50)
            download_video(video_url, output_path, api_key)
        else:
            print('❌ 任务成功但没有找到视频URL')
            print('完整响应:', json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print('\n❌ 视频生成失败或超时')

if __name__ == '__main__':
    main()