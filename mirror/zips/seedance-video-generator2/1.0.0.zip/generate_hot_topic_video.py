#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微博热搜主题视频一键生成器
"""

import argparse
import subprocess
import sys
from pathlib import Path

def generate_qingming_video(style="scenery", output_dir=None):
    """生成清明节主题视频"""
    
    prompts = {
        "scenery": {
            "name": "清明踏青美景",
            "prompt": "无人机航拍视角，穿越云雾缭绕的江南水乡，小桥流水人家，粉墙黛瓦的古镇在春雨中若隐若现，河面上乌篷船缓缓划过，两岸桃花、梨花、油菜花竞相开放，形成色彩斑斓的春日画卷，镜头从高空缓缓下降，聚焦在青石板路上打着油纸伞的行人，展现清明时节雨纷纷的诗意画面 --duration 12 --resolution 1080p --ratio 16:9 --camerafixed false --watermark true --audio true",
            "ratio": "16:9"
        },
        "travel": {
            "name": "城市周边游攻略",
            "prompt": "动态信息图风格，展示清明假期热门旅游城市的地图，从北京、上海、广州等大城市辐射出多条旅游路线，每条路线上标注景点图标、交通时间、特色美食，画面在多个城市间快速切换，展现故宫的红墙黄瓦、外滩的现代建筑、广州的早茶文化，最后汇总成清明出行小贴士 --duration 12 --resolution 1080p --ratio 9:16 --camerafixed false --watermark true --audio true",
            "ratio": "9:16"
        },
        "culture": {
            "name": "传统文化体验",
            "prompt": "传统水墨画风格动画，展现清明节的习俗：扫墓祭祖、踏青游玩、插柳戴柳、放风筝、荡秋千，画面从黑白水墨逐渐渲染成彩色，传统与现代交融，年轻人穿着汉服在樱花树下拍照，家庭在草地上野餐，孩子在空旷处放风筝，体现清明节既是缅怀先人也是亲近自然的节日 --duration 12 --resolution 1080p --ratio 16:9 --camerafixed false --watermark true --audio true",
            "ratio": "16:9"
        },
        "food": {
            "name": "清明时令美食",
            "prompt": "美食纪录片风格，镜头聚焦清明时令美食：青团、清明粿、润饼菜、子推馍，从食材准备到制作过程，再到成品特写，青团的艾草清香仿佛能透过屏幕，搭配各地特色小吃，最后呈现一桌丰盛的清明家宴，家人围坐分享美食的温馨场景 --duration 12 --resolution 1080p --ratio 9:16 --camerafixed false --watermark true --audio true",
            "ratio": "9:16"
        }
    }
    
    if style not in prompts:
        print(f"❌ 未知风格: {style}")
        print(f"可用风格: {', '.join(prompts.keys())}")
        return False
    
    prompt_info = prompts[style]
    
    # 确定输出目录
    if output_dir is None:
        output_dir = Path.home() / "Desktop" / "微博热搜视频"
    else:
        output_dir = Path(output_dir)
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成输出文件名
    safe_name = prompt_info["name"].replace(" ", "_").replace("/", "_")
    output_file = output_dir / f"清明主题_{safe_name}.mp4"
    
    print(f"🎬 生成清明节主题视频")
    print(f"   主题: {prompt_info['name']}")
    print(f"   画幅: {prompt_info['ratio']}")
    print(f"   输出: {output_file}")
    print(f"   提示词: {prompt_info['prompt'][:100]}...")
    
    # 构建命令
    cmd = [
        sys.executable, "seedance_enhanced.py",
        prompt_info["prompt"],
        "--model-type", "lite",
        "--output", str(output_file),
        "--poll"
    ]
    
    # 执行命令
    print(f"\n🚀 开始生成视频...")
    try:
        result = subprocess.run(cmd, cwd=Path(__file__).parent, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ 视频生成成功!")
            print(f"   文件: {output_file}")
            
            # 检查文件是否存在
            if output_file.exists():
                file_size = output_file.stat().st_size
                print(f"   大小: {file_size:,} bytes")
            return True
        else:
            print(f"❌ 视频生成失败")
            print(f"   错误: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        print(f"❌ 执行出错: {e}")
        return False

def generate_ai_tech_video(style="abstract", output_dir=None):
    """生成AI科技主题视频"""
    
    prompts = {
        "abstract": {
            "name": "科技感抽象风格",
            "prompt": "一个充满未来感的数字空间，无数发光的数据流在空中交织成复杂的神经网络图案，AI智能助手的虚拟形象从数据流中逐渐浮现，形象由流动的蓝色光粒子组成，不断变换形态，从简单的几何形状逐渐演变为复杂的人形轮廓，周围环绕着实时更新的信息流和交互界面，镜头围绕虚拟形象缓慢旋转，展示其与数据环境的深度融合 --duration 12 --resolution 1080p --ratio 16:9 --camerafixed false --watermark true --audio true",
            "ratio": "16:9"
        },
        "life": {
            "name": "生活场景应用",
            "prompt": "现代家庭客厅场景，透明的全息屏幕悬浮在空中，AI智能助手以温暖的光晕形式出现，帮助家庭成员完成各种任务：为孩子讲解作业题目、为老人提醒服药时间、为上班族规划出行路线、智能控制家居设备，场景在不同家庭成员间自然切换，展现AI助手在日常生活中的无缝融入 --duration 12 --resolution 1080p --ratio 9:16 --camerafixed false --watermark true --audio true",
            "ratio": "9:16"
        },
        "work": {
            "name": "企业办公应用",
            "prompt": "高科技办公室环境，AI智能助手以多任务处理中心的形式呈现，同时处理会议记录、数据分析、项目管理和客户服务，可视化的工作流像瀑布一样在多个屏幕上流动，团队成员通过自然语言与AI协作，工作效率显著提升，展现AI在企业数字化转型中的关键作用 --duration 12 --resolution 1080p --ratio 16:9 --camerafixed false --watermark true --audio true",
            "ratio": "16:9"
        },
        "education": {
            "name": "教育学习场景",
            "prompt": "智能教室场景，AI教育助手以互动全息投影的形式出现，为学生们提供个性化的学习体验：为不同学习进度的学生展示定制化的教学内容，通过AR技术让抽象概念可视化，实时评估学习效果并提供反馈，学生们在AI助手的引导下积极参与互动学习 --duration 12 --resolution 1080p --ratio 9:16 --camerafixed false --watermark true --audio true",
            "ratio": "9:16"
        }
    }
    
    if style not in prompts:
        print(f"❌ 未知风格: {style}")
        print(f"可用风格: {', '.join(prompts.keys())}")
        return False
    
    prompt_info = prompts[style]
    
    # 确定输出目录
    if output_dir is None:
        output_dir = Path.home() / "Desktop" / "微博热搜视频"
    else:
        output_dir = Path(output_dir)
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成输出文件名
    safe_name = prompt_info["name"].replace(" ", "_").replace("/", "_")
    output_file = output_dir / f"AI科技_{safe_name}.mp4"
    
    print(f"🎬 生成AI科技主题视频")
    print(f"   主题: {prompt_info['name']}")
    print(f"   画幅: {prompt_info['ratio']}")
    print(f"   输出: {output_file}")
    
    # 构建命令
    cmd = [
        sys.executable, "seedance_enhanced.py",
        prompt_info["prompt"],
        "--model-type", "lite",
        "--output", str(output_file),
        "--poll"
    ]
    
    # 执行命令
    print(f"\n🚀 开始生成视频...")
    try:
        result = subprocess.run(cmd, cwd=Path(__file__).parent, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ 视频生成成功!")
            print(f"   文件: {output_file}")
            
            if output_file.exists():
                file_size = output_file.stat().st_size
                print(f"   大小: {file_size:,} bytes")
            return True
        else:
            print(f"❌ 视频生成失败")
            print(f"   错误: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        print(f"❌ 执行出错: {e}")
        return False

def list_topics():
    """列出可用主题"""
    print("📋 可用热搜主题:")
    print()
    print("1. 清明节主题 (qingming)")
    print("   风格: scenery(美景), travel(旅行), culture(文化), food(美食)")
    print()
    print("2. AI科技主题 (ai)")
    print("   风格: abstract(抽象), life(生活), work(工作), education(教育)")
    print()
    print("💡 使用示例:")
    print("   python3 generate_hot_topic_video.py --topic qingming --style scenery")
    print("   python3 generate_hot_topic_video.py --topic ai --style life")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='微博热搜主题视频一键生成器')
    parser.add_argument('--topic', choices=['qingming', 'ai', 'list'], default='list',
                       help='主题: qingming(清明), ai(AI科技), list(列出所有主题)')
    parser.add_argument('--style', help='风格选择')
    parser.add_argument('--output-dir', help='输出目录')
    parser.add_argument('--all-styles', action='store_true', help='生成所有风格')
    
    args = parser.parse_args()
    
    if args.topic == 'list':
        list_topics()
        return
    
    if args.topic == 'qingming':
        if args.all_styles:
            print("🎬 生成所有清明节主题视频")
            styles = ['scenery', 'travel', 'culture', 'food']
            success_count = 0
            
            for style in styles:
                print(f"\n{'='*50}")
                success = generate_qingming_video(style, args.output_dir)
                if success:
                    success_count += 1
            
            print(f"\n📊 完成: {success_count}/{len(styles)} 个视频生成成功")
            
        elif args.style:
            generate_qingming_video(args.style, args.output_dir)
        else:
            print("❌ 请指定 --style 参数或使用 --all-styles")
            print("可用风格: scenery, travel, culture, food")
    
    elif args.topic == 'ai':
        if args.all_styles:
            print("🎬 生成所有AI科技主题视频")
            styles = ['abstract', 'life', 'work', 'education']
            success_count = 0
            
            for style in styles:
                print(f"\n{'='*50}")
                success = generate_ai_tech_video(style, args.output_dir)
                if success:
                    success_count += 1
            
            print(f"\n📊 完成: {success_count}/{len(styles)} 个视频生成成功")
            
        elif args.style:
            generate_ai_tech_video(args.style, args.output_dir)
        else:
            print("❌ 请指定 --style 参数或使用 --all-styles")
            print("可用风格: abstract, life, work, education")

if __name__ == "__main__":
    main()