#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Seedance 图生视频生成器
基于图片生成视频
"""

import sys
import json
import time
import requests
import argparse
import os
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

class SeedanceImageToVideo:
    """Seedance 图生视频生成器"""
    
    def __init__(self, config_path=None):
        """
        初始化图生视频生成器
        
        Args:
            config_path: 配置文件路径
        """
        # 确定配置文件路径
        if config_path is None:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(script_dir, 'config.json')
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 从配置中获取API Key
        self.api_key = self.config.get('api_key')
        
        if not self.api_key:
            raise ValueError("配置文件中缺少api_key")
        
        # API配置
        self.create_task_url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # 模型配置
        self.models = self.config.get('models', {})
        self.api_formats = self.config.get('api_formats', {})
        
        print(f"✅ 图生视频生成器加载完成")
        print(f"   模型: {self.models.get('image_to_video')}")
    
    def load_config(self, config_path):
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"❌ 配置文件不存在: {config_path}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"❌ 配置文件格式错误: {e}")
            sys.exit(1)
    
    def create_image_to_video_task(self, prompt, image_url, duration=5, 
                                  resolution="1080p", camera_fixed=False, 
                                  watermark=True, audio_enabled=False):
        """
        创建图生视频任务
        
        Args:
            prompt: 文本提示词
            image_url: 图片URL
            duration: 视频时长（4-12秒）
            resolution: 分辨率
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            audio_enabled: 是否启用音频
            
        Returns:
            str: 任务ID，失败返回None
        """
        print("🎬 创建图生视频任务...")
        print(f"  提示词: {prompt}")
        print(f"  图片URL: {image_url[:100]}...")
        print(f"  时长: {duration}秒")
        print(f"  分辨率: {resolution}")
        print(f"  相机固定: {camera_fixed}")
        print(f"  水印: {watermark}")
        print(f"  音频: {audio_enabled}")
        
        # 获取模型
        model = self.models.get('image_to_video', 'doubao-seedance-1-0-pro-250528')
        
        # 构建参数字符串
        params = f"--duration {duration} --resolution {resolution}"
        params += f" --camerafixed {str(camera_fixed).lower()}"
        params += f" --watermark {str(watermark).lower()}"
        
        if audio_enabled:
            params += " --audio true"
        
        # 构建完整的提示词
        full_prompt = f"{prompt} {params}"
        
        # 构建请求数据
        payload = {
            "model": model,
            "content": [
                {
                    "type": "text",
                    "text": full_prompt
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": image_url
                    }
                }
            ]
        }
        
        print(f"  使用模型: {model}")
        print(f"  完整提示词: {full_prompt[:100]}...")
        
        try:
            response = requests.post(
                self.create_task_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                task_id = result.get('id')
                
                if task_id:
                    print(f"✅ 图生视频任务创建成功!")
                    print(f"  任务ID: {task_id}")
                    return task_id
                else:
                    print(f"❌ 任务创建失败，响应中没有任务ID")
                    print(f"  响应: {result}")
                    return None
            else:
                print(f"❌ 任务创建失败 - 状态码: {response.status_code}")
                print(f"  响应: {response.text[:200]}")
                return None
                
        except Exception as e:
            print(f"❌ 创建任务时出错: {e}")
            return None
    
    def check_task_status(self, task_id):
        """
        检查任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息，失败返回None
        """
        url = f"{self.create_task_url}/{task_id}"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ 查询任务状态失败 - 状态码: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ 查询任务状态时出错: {e}")
            return None
    
    def download_video(self, video_url, output_path):
        """
        下载视频文件
        
        Args:
            video_url: 视频URL
            output_path: 输出文件路径
            
        Returns:
            bool: 是否下载成功
        """
        try:
            print(f"📥 开始下载视频...")
            print(f"  视频URL: {video_url[:100]}...")
            print(f"  保存到: {output_path}")
            
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(video_url, headers=headers, stream=True, timeout=60)
            
            if response.status_code == 200:
                # 确保输出目录存在
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                
                # 下载文件
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(output_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            # 显示进度
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f'  下载进度: {percent:.1f}% ({downloaded}/{total_size} bytes)', end='\r')
                
                print(f'\n✅ 视频下载完成!')
                print(f'  文件大小: {os.path.getsize(output_path)} bytes')
                return True
            else:
                print(f'❌ 下载失败 - 状态码: {response.status_code}')
                return False
                
        except Exception as e:
            print(f'❌ 下载视频时出错: {str(e)}')
            return False
    
    def poll_and_download(self, task_id, output_path, max_attempts=60, interval=10):
        """
        轮询任务状态并下载视频
        
        Args:
            task_id: 任务ID
            output_path: 输出文件路径
            max_attempts: 最大轮询次数
            interval: 轮询间隔秒数
            
        Returns:
            bool: 是否成功下载
        """
        print(f"\n🔍 开始轮询任务状态...")
        print(f"  任务ID: {task_id}")
        print(f"  最大尝试次数: {max_attempts}")
        print(f"  轮询间隔: {interval}秒")
        
        for attempt in range(1, max_attempts + 1):
            print(f"\n尝试 #{attempt}/{max_attempts}")
            
            # 查询任务状态
            result = self.check_task_status(task_id)
            
            if not result:
                print("  查询任务状态失败")
                continue
            
            status = result.get('status', 'unknown')
            print(f"  状态: {status}")
            
            if status == 'succeeded':
                print("  ✅ 视频生成成功!")
                
                # 提取视频URL
                video_url = None
                if 'content' in result and 'video_url' in result['content']:
                    video_url = result['content']['video_url']
                elif 'output' in result and 'video_url' in result['output']:
                    video_url = result['output']['video_url']
                
                if video_url:
                    print(f"  🔗 找到视频URL")
                    
                    # 下载视频
                    success = self.download_video(video_url, output_path)
                    
                    if success:
                        print(f"\n🎉 图生视频下载完成!")
                        print(f"文件位置: {output_path}")
                        return True
                    else:
                        print(f"\n❌ 视频下载失败")
                        return False
                else:
                    print("  ❌ 任务成功但没有找到视频URL")
                    return False
                    
            elif status == 'failed':
                print("  ❌ 视频生成失败")
                if 'error' in result:
                    error = result['error']
                    print(f"  错误代码: {error.get('code')}")
                    print(f"  错误信息: {error.get('message')}")
                return False
                
            elif status == 'running':
                print("  ⏳ 视频正在生成中...")
                # 继续等待
                pass
                
            else:
                print(f"  📝 未知状态: {status}")
            
            # 如果不是最后一次尝试，等待
            if attempt < max_attempts:
                print(f"  等待 {interval}秒后重试...")
                time.sleep(interval)
        
        print(f"\n❌ 超过最大尝试次数，任务可能仍在处理中或失败")
        return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Seedance 图生视频生成器')
    parser.add_argument('prompt', help='文本提示词')
    parser.add_argument('--image-url', required=True, help='图片URL')
    parser.add_argument('--duration', type=int, default=5, help='视频时长（4-12秒，默认5秒）')
    parser.add_argument('--resolution', default='1080p', help='分辨率（默认1080p）')
    parser.add_argument('--camera-fixed', action='store_true', help='相机固定（默认False）')
    parser.add_argument('--no-watermark', action='store_true', help='不添加水印（默认添加）')
    parser.add_argument('--audio', action='store_true', help='启用音频支持')
    parser.add_argument('--output', '-o', default=None, help='输出文件路径')
    parser.add_argument('--poll', action='store_true', help='自动轮询并下载视频')
    parser.add_argument('--max-attempts', type=int, default=60, help='最大轮询次数（默认60）')
    parser.add_argument('--interval', type=int, default=10, help='轮询间隔秒数（默认10）')
    
    args = parser.parse_args()
    
    # 初始化生成器
    try:
        generator = SeedanceImageToVideo()
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        return
    
    # 确定输出路径
    if args.output:
        output_path = args.output
    else:
        # 使用桌面路径
        desktop = Path.home() / "Desktop"
        safe_prompt = args.prompt[:50].replace(' ', '_').replace('/', '_')
        output_path = str(desktop / f"seedance_i2v_{safe_prompt}.mp4")
    
    # 创建图生视频任务
    task_id = generator.create_image_to_video_task(
        prompt=args.prompt,
        image_url=args.image_url,
        duration=args.duration,
        resolution=args.resolution,
        camera_fixed=args.camera_fixed,
        watermark=not args.no_watermark,
        audio_enabled=args.audio
    )
    
    if not task_id:
        print("❌ 图生视频任务创建失败")
        return
    
    # 如果指定了自动轮询，则等待并下载
    if args.poll:
        success = generator.poll_and_download(
            task_id=task_id,
            output_path=output_path,
            max_attempts=args.max_attempts,
            interval=args.interval
        )
        
        if success:
            print(f"\n🎉 图生视频生成流程完成!")
            print(f"文件: {output_path}")
        else:
            print(f"\n❌ 图生视频生成流程失败")
    else:
        print(f"\n📋 图生视频任务已创建，需要手动轮询:")
        print(f"任务ID: {task_id}")
        print(f"查询命令: python3 check_task.py {task_id} --download")

if __name__ == '__main__':
    main()