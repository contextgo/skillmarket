#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版Seedance视频生成器
支持多个模型轮换和音频参数测试
"""

import sys
import json
import time
import requests
import argparse
import os
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

class EnhancedSeedanceGenerator:
    """增强版Seedance视频生成器"""
    
    def __init__(self, config_path=None):
        """
        初始化视频生成器
        
        Args:
            config_path: 配置文件路径
        """
        # 确定配置文件路径
        if config_path is None:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(script_dir, 'config.json')
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 从配置中获取API Key
        self.api_key = self.config.get('api_key')
        
        if not self.api_key:
            raise ValueError("配置文件中缺少api_key")
        
        # API配置
        self.create_task_url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # 模型配置
        self.models = self.config.get('models', {})
        self.current_model_index = 0
        
        # 音频参数测试
        self.audio_params = self.config.get('audio_support', {}).get('parameters', [])
        
        print(f"✅ 加载配置完成")
        print(f"   可用模型: {len(self.get_available_models())}个")
        print(f"   音频参数: {len(self.audio_params)}种")
    
    def load_config(self, config_path):
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"❌ 配置文件不存在: {config_path}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"❌ 配置文件格式错误: {e}")
            sys.exit(1)
    
    def get_available_models(self):
        """获取所有可用模型列表"""
        models = []
        
        # 添加主模型
        primary = self.models.get('primary')
        if primary:
            models.append(primary)
        
        # 添加备用模型
        fallback = self.models.get('fallback', [])
        models.extend(fallback)
        
        return models
    
    def get_next_model(self):
        """获取下一个可用的模型（轮换策略）"""
        models = self.get_available_models()
        if not models:
            return "doubao-seedance-1-0-pro-fast-251015"  # 默认
        
        model = models[self.current_model_index]
        self.current_model_index = (self.current_model_index + 1) % len(models)
        return model
    
    def create_video_task(self, prompt, duration=5, resolution="1080p", 
                         camera_fixed=False, watermark=True, 
                         audio_enabled=False, audio_param=None):
        """
        创建视频生成任务
        
        Args:
            prompt: 文本提示词
            duration: 视频时长（4-12秒）
            resolution: 分辨率
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            audio_enabled: 是否启用音频
            audio_param: 音频参数
            
        Returns:
            tuple: (任务ID, 使用的模型, 使用的音频参数)
        """
        print("🎬 创建视频生成任务...")
        
        # 选择模型
        model = self.get_next_model()
        print(f"  使用模型: {model}")
        
        # 构建提示词
        full_prompt = prompt
        
        # 添加基本参数
        full_prompt += f" --duration {duration}"
        full_prompt += f" --resolution {resolution}"
        full_prompt += f" --camerafixed {str(camera_fixed).lower()}"
        full_prompt += f" --watermark {str(watermark).lower()}"
        
        # 添加音频参数
        if audio_enabled and audio_param:
            full_prompt += f" {audio_param}"
            print(f"  音频参数: {audio_param}")
        
        print(f"  完整提示词: {full_prompt[:100]}...")
        
        # 构建请求数据
        payload = {
            "model": model,
            "content": [
                {
                    "type": "text",
                    "text": full_prompt
                }
            ]
        }
        
        try:
            response = requests.post(
                self.create_task_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                task_id = result.get('id')
                
                if task_id:
                    print(f"✅ 任务创建成功!")
                    print(f"  任务ID: {task_id}")
                    return task_id, model, audio_param if audio_enabled else None
                else:
                    print(f"❌ 任务创建失败，响应中没有任务ID")
                    print(f"  响应: {result}")
                    return None, model, None
            else:
                print(f"❌ 任务创建失败 - 状态码: {response.status_code}")
                print(f"  响应: {response.text[:200]}")
                return None, model, None
                
        except Exception as e:
            print(f"❌ 创建任务时出错: {e}")
            return None, model, None
    
    def check_task_status(self, task_id):
        """
        检查任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息，失败返回None
        """
        url = f"{self.create_task_url}/{task_id}"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ 查询任务状态失败 - 状态码: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ 查询任务状态时出错: {e}")
            return None
    
    def download_video(self, video_url, output_path):
        """
        下载视频文件
        
        Args:
            video_url: 视频URL
            output_path: 输出文件路径
            
        Returns:
            bool: 是否下载成功
        """
        try:
            print(f"📥 开始下载视频...")
            print(f"  视频URL: {video_url[:100]}...")
            print(f"  保存到: {output_path}")
            
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(video_url, headers=headers, stream=True, timeout=60)
            
            if response.status_code == 200:
                # 确保输出目录存在
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                
                # 下载文件
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(output_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            # 显示进度
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f'  下载进度: {percent:.1f}% ({downloaded}/{total_size} bytes)', end='\r')
                
                print(f'\n✅ 视频下载完成!')
                print(f'  文件大小: {os.path.getsize(output_path)} bytes')
                return True
            else:
                print(f'❌ 下载失败 - 状态码: {response.status_code}')
                return False
                
        except Exception as e:
            print(f'❌ 下载视频时出错: {str(e)}')
            return False
    
    def poll_and_download(self, task_id, output_path, max_attempts=60, interval=10):
        """
        轮询任务状态并下载视频
        
        Args:
            task_id: 任务ID
            output_path: 输出文件路径
            max_attempts: 最大轮询次数
            interval: 轮询间隔秒数
            
        Returns:
            bool: 是否成功下载
        """
        print(f"\n🔍 开始轮询任务状态...")
        print(f"  任务ID: {task_id}")
        print(f"  最大尝试次数: {max_attempts}")
        print(f"  轮询间隔: {interval}秒")
        
        for attempt in range(1, max_attempts + 1):
            print(f"\n尝试 #{attempt}/{max_attempts}")
            
            # 查询任务状态
            result = self.check_task_status(task_id)
            
            if not result:
                print("  查询任务状态失败")
                continue
            
            status = result.get('status', 'unknown')
            print(f"  状态: {status}")
            
            if status == 'succeeded':
                print("  ✅ 视频生成成功!")
                
                # 提取视频URL
                video_url = None
                if 'content' in result and 'video_url' in result['content']:
                    video_url = result['content']['video_url']
                elif 'output' in result and 'video_url' in result['output']:
                    video_url = result['output']['video_url']
                
                if video_url:
                    print(f"  🔗 找到视频URL")
                    
                    # 下载视频
                    success = self.download_video(video_url, output_path)
                    
                    if success:
                        print(f"\n🎉 视频下载完成!")
                        print(f"文件位置: {output_path}")
                        return True
                    else:
                        print(f"\n❌ 视频下载失败")
                        return False
                else:
                    print("  ❌ 任务成功但没有找到视频URL")
                    print(f"  完整响应: {json.dumps(result, ensure_ascii=False, indent=2)}")
                    return False
                    
            elif status == 'failed':
                print("  ❌ 视频生成失败")
                if 'error' in result:
                    error = result['error']
                    print(f"  错误代码: {error.get('code')}")
                    print(f"  错误信息: {error.get('message')}")
                return False
                
            elif status == 'running':
                print("  ⏳ 视频正在生成中...")
                # 继续等待
                pass
                
            else:
                print(f"  📝 未知状态: {status}")
            
            # 如果不是最后一次尝试，等待
            if attempt < max_attempts:
                print(f"  等待 {interval}秒后重试...")
                time.sleep(interval)
        
        print(f"\n❌ 超过最大尝试次数，任务可能仍在处理中或失败")
        return False
    
    def test_audio_support(self, prompt, duration=5):
        """
        测试音频支持
        
        Args:
            prompt: 测试提示词
            duration: 测试时长
            
        Returns:
            dict: 测试结果
        """
        print("🔊 开始测试音频支持...")
        print(f"  测试提示词: {prompt}")
        print(f"  测试时长: {duration}秒")
        
        results = {}
        
        # 测试每个音频参数
        for audio_param in self.audio_params:
            print(f"\n测试音频参数: {audio_param}")
            
            # 创建任务
            task_id, model, _ = self.create_video_task(
                prompt=prompt,
                duration=duration,
                audio_enabled=True,
                audio_param=audio_param
            )
            
            if task_id:
                results[audio_param] = {
                    'task_id': task_id,
                    'model': model,
                    'status': 'created'
                }
                print(f"  ✅ 任务创建成功: {task_id}")
            else:
                results[audio_param] = {
                    'task_id': None,
                    'model': model,
                    'status': 'failed'
                }
                print(f"  ❌ 任务创建失败")
            
            # 短暂等待
            time.sleep(2)
        
        return results

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='增强版Seedance视频生成器')
    parser.add_argument('prompt', help='文本提示词')
    parser.add_argument('--duration', type=int, default=5, help='视频时长（4-12秒，默认5秒）')
    parser.add_argument('--resolution', default='1080p', help='分辨率（默认1080p）')
    parser.add_argument('--camera-fixed', action='store_true', help='相机固定（默认False）')
    parser.add_argument('--no-watermark', action='store_true', help='不添加水印（默认添加）')
    parser.add_argument('--audio', action='store_true', help='启用音频支持')
    parser.add_argument('--audio-param', help='指定音频参数')
    parser.add_argument('--output', '-o', default=None, help='输出文件路径')
    parser.add_argument('--poll', action='store_true', help='自动轮询并下载视频')
    parser.add_argument('--max-attempts', type=int, default=60, help='最大轮询次数（默认60）')
    parser.add_argument('--interval', type=int, default=10, help='轮询间隔秒数（默认10）')
    parser.add_argument('--test-audio', action='store_true', help='测试音频支持')
    
    args = parser.parse_args()
    
    # 初始化生成器
    try:
        generator = EnhancedSeedanceGenerator()
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        return
    
    # 测试音频支持
    if args.test_audio:
        test_prompt = "测试音频支持：简单的场景"
        results = generator.test_audio_support(test_prompt, duration=5)
        
        print("\n📊 音频测试结果:")
        for param, result in results.items():
            status = result['status']
            task_id = result['task_id']
            model = result['model']
            print(f"  {param}: {status} (任务ID: {task_id}, 模型: {model})")
        
        return
    
    # 确定输出路径
    if args.output:
        output_path = args.output
    else:
        # 使用桌面路径
        desktop = Path.home() / "Desktop"
        safe_prompt = args.prompt[:50].replace(' ', '_').replace('/', '_')
        output_path = str(desktop / f"seedance_video_{safe_prompt}.mp4")
    
    # 创建视频任务
    task_id, model, audio_param = generator.create_video_task(
        prompt=args.prompt,
        duration=args.duration,
        resolution=args.resolution,
        camera_fixed=args.camera_fixed,
        watermark=not args.no_watermark,
        audio_enabled=args.audio,
        audio_param=args.audio_param
    )
    
    if not task_id:
        print("❌ 任务创建失败")
        return
    
    # 如果指定了自动轮询，则等待并下载
    if args.poll:
        success = generator.poll_and_download(
            task_id=task_id,
            output_path=output_path,
            max_attempts=args.max_attempts,
            interval=args.interval
        )
        
        if success:
            print(f"\n🎉 视频生成流程完成!")
            print(f"模型: {model}")
            if audio_param:
                print(f"音频参数: {audio_param}")
            print(f"文件: {output_path}")
        else:
            print(f"\n❌ 视频生成流程失败")
    else:
        print(f"\n📋 任务已创建，需要手动轮询:")
        print(f"任务ID: {task_id}")
        print(f"模型: {model}")
        if audio_param:
            print(f"音频参数: {audio_param}")
        print(f"查询命令: python3 check_task.py {task_id} --download")

if __name__ == '__main__':
    main()