# 增强版Seedance视频生成器使用指南

## 🎯 功能特点

1. **多模型支持**：支持4个Seedance模型轮换使用
2. **音频测试**：内置音频参数测试功能
3. **自动轮询**：一键完成创建、轮询、下载
4. **智能容错**：模型额度耗尽时自动切换

## 📦 可用模型

### 主模型：
- `doubao-seedance-1-0-pro-fast-251015` (默认)

### 备用模型：
1. `Doubao-Seedance-1.0-pro` (标准专业版)
2. `Doubao-Seedance-1.0-lite-t2v` (轻量版文生视频)
3. `Doubao-Seedance-1.0-lite-i2v` (轻量版图生视频)

## 🚀 快速开始

### 基本使用（自动轮询下载）：
```bash
# 生成5秒视频
python3 seedance_enhanced.py "你的提示词" --poll

# 生成12秒视频，无水印
python3 seedance_enhanced.py "抽象搞笑场景" --duration 12 --no-watermark --poll

# 启用音频支持
python3 seedance_enhanced.py "带音频的视频" --audio --poll
```

### 测试音频支持：
```bash
# 测试所有音频参数
python3 seedance_enhanced.py "测试音频" --test-audio
```

### 指定音频参数：
```bash
# 使用特定音频参数
python3 seedance_enhanced.py "视频提示词" --audio --audio-param "--audio true" --poll
```

## 🔧 参数说明

| 参数 | 缩写 | 默认值 | 说明 |
|------|------|--------|------|
| `prompt` | - | 必需 | 文本提示词 |
| `--duration` | - | 5 | 视频时长（4-12秒） |
| `--resolution` | - | 1080p | 分辨率 |
| `--camera-fixed` | - | False | 相机固定 |
| `--no-watermark` | - | False | 不添加水印 |
| `--audio` | - | False | 启用音频支持 |
| `--audio-param` | - | 自动选择 | 指定音频参数 |
| `--output` | `-o` | 桌面 | 输出文件路径 |
| `--poll` | - | False | 自动轮询并下载 |
| `--max-attempts` | - | 60 | 最大轮询次数 |
| `--interval` | - | 10 | 轮询间隔秒数 |
| `--test-audio` | - | False | 测试音频支持 |

## 🎵 音频支持

### 当前测试的音频参数：
1. `--audio true`
2. `--with_audio true`
3. `--generate_audio true`

### 音频测试流程：
1. 运行 `--test-audio` 测试所有参数
2. 查看哪个参数被API接受
3. 使用有效的参数生成视频

## 🔄 模型轮换策略

### 自动轮换：
1. 主模型额度耗尽时自动切换到备用模型
2. 按顺序轮换使用所有可用模型
3. 每个模型独立额度，提高总可用量

### 手动指定：
```bash
# 修改config.json中的models配置
{
  "models": {
    "primary": "Doubao-Seedance-1.0-pro",
    "fallback": [
      "Doubao-Seedance-1.0-lite-t2v",
      "Doubao-Seedance-1.0-lite-i2v"
    ]
  }
}
```

## 📊 配置文件

`config.json` 结构：
```json
{
  "api_key": "你的火山引擎API Key",
  "models": {
    "primary": "doubao-seedance-1-0-pro-fast-251015",
    "fallback": [
      "Doubao-Seedance-1.0-pro",
      "Doubao-Seedance-1.0-lite-t2v",
      "Doubao-Seedance-1.0-lite-i2v"
    ]
  },
  "audio_support": {
    "tested": false,
    "parameters": ["--audio true", "--with_audio true", "--generate_audio true"]
  }
}
```

## 💡 使用示例

### 示例1：抽象搞笑视频
```bash
python3 seedance_enhanced.py \
  "一个穿着西装戴着香蕉头套的企鹅在跳不协调的踢踏舞，手持的吐司机突然弹出烤焦的面包片，面包片在空中旋转变成会飞的鱼，鱼撞到墙上变成彩色烟雾，烟雾中浮现'为什么？'文字" \
  --duration 12 \
  --no-watermark \
  --audio \
  --poll
```

### 示例2：测试音频支持
```bash
python3 seedance_enhanced.py "简单测试场景" --test-audio
```

### 示例3：指定输出路径
```bash
python3 seedance_enhanced.py "产品展示视频" \
  --output "/Users/用户名/Desktop/产品视频.mp4" \
  --poll
```

## ⚠️ 注意事项

1. **额度管理**：每个模型有独立额度，合理轮换使用
2. **音频支持**：不是所有模型都支持音频，需要测试
3. **生成时间**：视频生成通常需要2-5分钟
4. **文件大小**：12秒1080p视频约15-25MB

## 🔍 故障排除

### 问题：所有模型都额度耗尽
**解决方案**：
1. 等待额度重置（通常24小时）
2. 联系火山引擎客服增加额度
3. 使用其他AI视频平台

### 问题：音频参数无效
**解决方案**：
1. 运行 `--test-audio` 找到有效参数
2. 查看火山引擎官方文档
3. 考虑后期添加音频

### 问题：视频生成失败
**解决方案**：
1. 检查API Key是否正确
2. 查看错误信息中的具体原因
3. 尝试简化提示词

## 📞 支持

- 火山引擎控制台：https://console.volcengine.com/
- 火山引擎文档：https://www.volcengine.com/docs/
- 技能GitHub仓库：https://github.com/openclaw/skills