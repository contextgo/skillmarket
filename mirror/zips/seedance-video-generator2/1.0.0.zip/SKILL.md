---
name: Video-Generator-Seedance
description: 使用火山引擎Seedance API生成视频。支持文本到视频和图生视频，异步处理任务。包含完整的模型列表和参数配置。
allowed-tools: Bash(python *)
---

# Seedance 视频生成技能

## 功能
使用火山引擎的Seedance API生成高质量视频，支持：
- 文本到视频（Text-to-Video）
- 图生视频（Image-to-Video）
- 多种模型选择
- 丰富的参数控制
- 异步处理和自动下载

## 🎯 支持的模型（全称列表）

### 文本到视频模型（Text-to-Video）
| 模型别名 | 全称模型ID | 描述 | 最大时长 | 分辨率 | 音频支持 |
|----------|------------|------|----------|--------|----------|
| `pro_fast` | `doubao-seedance-1-0-pro-fast-251015` | 快速专业版，生成速度快 | 12秒 | 1080p, 720p | ✅ |
| `standard` | `doubao-seedance-1-0-t2v-250428` | 标准版，平衡质量和速度 | 10秒 | 1080p, 720p | ❌ |
| `lite` | `doubao-seedance-1-0-lite-t2v-250428` | 轻量版，成本较低 | 12秒 | 720p | ❌ |

### 图生视频模型（Image-to-Video）
| 模型别名 | 全称模型ID | 描述 | 最大时长 | 分辨率 | 音频支持 |
|----------|------------|------|----------|--------|----------|
| `pro` | `doubao-seedance-1-0-pro-250528` | 专业图生视频版 | 12秒 | 1080p, 720p | ✅ |
| `lite` | `doubao-seedance-1-0-lite-i2v-250428` | 轻量图生视频版 | 10秒 | 720p | ❌ |

## 首次使用配置

### 1. 获取API密钥
1. 访问火山引擎控制台：https://console.volcengine.com/
2. 注册/登录账号
3. 在API Key管理中创建API密钥
4. 开通Seedance服务权限

### 2. 创建配置文件
复制 `config.example.json` 为 `config.json` 并修改：

```json
{
  "api_key": "sk-your-volcano-engine-api-key-here",
  "models": {
    "text_to_video": {
      "pro_fast": "doubao-seedance-1-0-pro-fast-251015",
      "standard": "doubao-seedance-1-0-t2v-250428",
      "lite": "doubao-seedance-1-0-lite-t2v-250428"
    }
  }
}
```

### 3. 完整配置文件
查看 `config.json` 获取完整的配置选项，包括：
- 所有模型全称
- 参数默认值
- API端点
- 示例提示词

## 使用方法

### 统一生成器（推荐）
```bash
# 文本到视频
python seedance_unified.py --task-type text --prompt "你的提示词" --duration 10 --model-type pro_fast

# 图生视频
python seedance_unified.py --task-type image --prompt "基于图片生成动画" --image-url "https://example.com/image.jpg" --model-type pro
```

### 增强版生成器
```bash
python seedance_enhanced.py "你的提示词" --duration 12 --resolution 1080p --poll
```

### 图生视频专用
```bash
python seedance_image_to_video.py "提示词" --image-url "图片URL" --duration 8
```

## 参数说明

### 基本参数
| 参数 | 说明 | 可选值 | 默认值 |
|------|------|--------|--------|
| `--duration` | 视频时长 | 4-12秒 | 5秒 |
| `--resolution` | 分辨率 | 1080p, 720p | 720p |
| `--ratio` | 宽高比 | 16:9, 9:16, 1:1 | 16:9 |
| `--camera-fixed` | 相机固定 | true/false | false |
| `--watermark` | 水印 | true/false | true |
| `--model-type` | 模型类型 | pro_fast, pro, standard, lite | pro_fast |

### 高级功能
- **音频支持**：pro_fast和pro模型支持 `--audio true`
- **自动轮询**：使用 `--poll` 参数自动下载视频
- **自定义输出**：使用 `--output /path/to/video.mp4`
- **批量处理**：参考脚本中的批量处理示例

## 示例

### 示例1：生成搞笑视频
```bash
python seedance_unified.py --task-type text \
  --prompt "超现实办公室场景，程序员与智能咖啡杯争吵，咖啡杯跳舞洒出彩虹咖啡，搞笑幽默" \
  --duration 12 \
  --model-type lite \
  --poll \
  --output "搞笑视频.mp4"
```

### 示例2：高清专业视频
```bash
python seedance_enhanced.py "写实风格，晴朗的蓝天之下，一大片白色的雏菊花田，镜头逐渐拉近，最终定格在一朵雏菊花的特写上" \
  --duration 8 \
  --resolution 1080p \
  --model-type pro_fast \
  --audio \
  --poll
```

### 示例3：基于图片生成视频
```bash
python seedance_image_to_video.py "天空的云飘动着，路上的车辆行驶" \
  --image-url "https://example.com/cityscape.jpg" \
  --duration 6 \
  --model-type pro \
  --poll
```

## 脚本说明

### 主要脚本
- `seedance_unified.py` - 统一生成器（推荐使用）
- `seedance_enhanced.py` - 增强版生成器
- `seedance_image_to_video.py` - 图生视频专用
- `seedance_1_0_pro_generator.py` - 专业版生成器

### 工具脚本
- `poll_and_download.py` - 轮询和下载工具
- `check_task.py` - 任务状态检查
- `test_model_costs.py` - 模型成本测试

## 错误处理

### 常见错误
1. **API密钥错误**：检查config.json中的api_key
2. **模型不可用**：检查模型ID是否正确
3. **账户限制**：达到推理限制，需要调整安全模式
4. **网络错误**：检查网络连接和防火墙

### 调试建议
```bash
# 检查配置
python check_task.py --help

# 测试模型
python test_model_costs.py --list-models

# 查看任务状态
python check_task.py --task-id "你的任务ID"
```

## 性能优化

### 生成时间
- **lite模型**：约1-2分钟
- **pro_fast模型**：约2-3分钟  
- **pro模型**：约3-5分钟

### 成本考虑
- lite模型成本最低
- pro_fast适合快速生成
- pro模型质量最高但成本较高

## 更新日志

### v1.0.0 (2026-04-03)
- 初始发布版本
- 支持所有Seedance模型全称
- 完整的配置系统
- 多种生成脚本
- 详细的文档和示例

## 技术支持
- 火山引擎文档：https://www.volcengine.com/docs/
- Seedance模型文档：https://www.volcengine.com/docs/ai-services/seedance
- 问题反馈：GitHub Issues

---
**注意**：使用前请确保已阅读并同意火山引擎的服务条款。