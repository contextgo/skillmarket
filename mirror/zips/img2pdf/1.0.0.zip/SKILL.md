---
name: images-to-pdf
description: "将本地图片批量合并为 PDF 文档。支持自动修正 EXIF 方向、按文件名编号排序、大数量图片（200+张）处理。触发词：图片转PDF、合并图片为PDF、图片合成PDF、images to pdf、批量图片PDF、试卷图片PDF、照片转PDF、把图片做成PDF"
triggers:
  - 图片转PDF
  - 合并图片为PDF
  - 图片合成PDF
  - images to pdf
  - 批量图片PDF
  - 试卷图片PDF
  - 照片转PDF
  - 把图片做成PDF
---

# Images to PDF

将指定目录下的所有图片按文件名编号顺序合并为一个 PDF 文档，自动修正拍摄方向。

## 功能特点

- 自动扫描目录下 jpg/png/jpeg/webp/bmp/tiff 图片
- 按文件名中的数字编号排序（如 `图片_1_346.jpg`, `图片_2_346.jpg`）
- 自动通过 EXIF 信息修正手机拍摄方向（横屏自动转正）
- 等比缩放到 A4 页面尺寸（默认 150 DPI）
- 支持 200+ 张图片的大批量处理
- 单张图片失败不影响整体流程
- 输出单个完整 PDF 文件

## 依赖

- Python 3.8+
- Pillow（pip install Pillow）

## 使用方法

当用户要求将图片合并为 PDF 时，按以下步骤执行：

### Step 1: 确认图片目录

确认用户要处理的图片所在目录。如果用户没有指定，使用当前工作目录。

### Step 2: 检查依赖

```bash
python --version
pip show Pillow || pip install Pillow
```

### Step 3: 执行转换脚本

使用本技能 scripts 目录下的 `images_to_pdf.py` 脚本：

```bash
# 基本用法 - 指定图片目录，输出到同目录下的 合并输出.pdf
python <skill_dir>/scripts/images_to_pdf.py "图片目录路径"

# 指定输出路径
python <skill_dir>/scripts/images_to_pdf.py "图片目录路径" "输出.pdf"

# 调整 DPI（默认 150，数值越大清晰度越高但文件越大）
python <skill_dir>/scripts/images_to_pdf.py "图片目录路径" --dpi 300
```

其中 `<skill_dir>` 是本技能的安装目录，需要替换为实际路径。

脚本参数：
- 第一个位置参数（必需）：图片所在目录路径
- 第二个位置参数（可选）：输出 PDF 文件路径，默认为 `<目录>/合并输出.pdf`
- `--dpi`（可选）：PDF 分辨率，默认 150

### Step 4: 展示结果

使用 `open_result_view` 展示生成的 PDF 文件。

### Step 5: 清理

删除执行过程中产生的临时文件（如有）。

## 注意事项

- 如果图片数量非常多（300+）且分辨率很高，可能会遇到内存问题，可降低 DPI（如 `--dpi 72`）
- PNG/WebP/BMP/TIFF 图片会自动转换为 RGB 模式
- 脚本会跳过无法处理的图片并继续执行，不会因单张图片失败而中断
