#!/usr/bin/env python3
"""将目录下所有图片按编号顺序合并为 PDF，自动修正 EXIF 方向。

用法:
    python images_to_pdf.py <图片目录> [输出PDF路径] [--dpi 150] [--quality 90]

参数:
    图片目录      包含图片的目录路径（必需）
    输出PDF路径   输出 PDF 文件路径（可选，默认为 图片目录/合并输出.pdf）
    --dpi         PDF 分辨率，默认 150
    --quality     JPEG 压缩质量，默认 90（仅对缩放后的中间文件生效）
"""
import re
import os
import sys
import gc
import argparse


def extract_number(filename):
    """提取文件名中最后一个数字序列作为排序依据。"""
    numbers = re.findall(r"\d+", filename)
    return int(numbers[-1]) if numbers else 0


def scan_images(directory):
    """扫描目录下所有支持的图片文件，按文件名编号排序。"""
    valid_exts = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff")
    files = [
        f for f in os.listdir(directory)
        if f.lower().endswith(valid_exts)
    ]
    files.sort(key=extract_number)
    return files


def process_image(fpath, max_w, max_h):
    """处理单张图片：修正 EXIF 方向 + 等比缩放。"""
    from PIL import Image, ImageOps

    img = Image.open(fpath)
    # 使用 EXIF 信息自动修正方向（处理手机横拍等场景）
    img = ImageOps.exif_transpose(img)
    if img.mode != "RGB":
        img = img.convert("RGB")

    # 等比缩放到目标页面尺寸（只缩小，不放大）
    w, h = img.size
    scale = min(max_w / w, max_h / h, 1.0)
    if scale < 1.0:
        new_w = int(w * scale)
        new_h = int(h * scale)
        img = img.resize((new_w, new_h), Image.LANCZOS)

    img.load()  # 确保像素数据加载到内存，释放文件句柄
    return img


def images_to_pdf(img_dir, output_path, dpi=150):
    """主流程：扫描 → 处理 → 合并为 PDF。"""
    from PIL import Image

    # 根据 DPI 计算 A4 页面像素尺寸
    a4_w = int(210 * dpi / 25.4)  # 210mm
    a4_h = int(297 * dpi / 25.4)  # 297mm

    all_files = scan_images(img_dir)
    total = len(all_files)

    if total == 0:
        print("错误: 未找到图片文件！")
        sys.exit(1)

    print(f"共找到 {total} 张图片")

    images = []
    failed = 0
    for i, fname in enumerate(all_files):
        fpath = os.path.join(img_dir, fname)
        try:
            img = process_image(fpath, a4_w, a4_h)
            images.append(img)
        except Exception as e:
            print(f"  警告: 跳过 {fname} - {e}")
            failed += 1
            continue

        if (i + 1) % 50 == 0 or i + 1 == total:
            print(f"  已处理 {i+1}/{total} 张")

    if not images:
        print("错误: 没有成功处理的图片！")
        sys.exit(1)

    success = len(images)
    print(f"\n开始生成 PDF ({success} 页, DPI={dpi})...")

    images[0].save(
        output_path, "PDF",
        save_all=True,
        append_images=images[1:],
        resolution=dpi
    )

    file_size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"\n完成！")
    print(f"  输出: {output_path}")
    print(f"  页数: {success} 页")
    print(f"  大小: {file_size_mb:.1f} MB")
    if failed > 0:
        print(f"  跳过: {failed} 张（处理失败）")

    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="将目录下所有图片按编号顺序合并为 PDF"
    )
    parser.add_argument("img_dir", help="图片所在目录路径")
    parser.add_argument("output", nargs="?", default=None, help="输出 PDF 路径（默认: <目录>/合并输出.pdf）")
    parser.add_argument("--dpi", type=int, default=150, help="PDF 分辨率（默认 150）")
    args = parser.parse_args()

    img_dir = os.path.abspath(args.img_dir)
    if not os.path.isdir(img_dir):
        print(f"错误: 目录不存在 - {img_dir}")
        sys.exit(1)

    output = args.output or os.path.join(img_dir, "合并输出.pdf")
    output = os.path.abspath(output)

    images_to_pdf(img_dir, output, dpi=args.dpi)


if __name__ == "__main__":
    main()
