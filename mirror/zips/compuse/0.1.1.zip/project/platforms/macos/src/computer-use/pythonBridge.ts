import { createHash } from 'node:crypto'
import { readFile, mkdir, access, writeFile, rm } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileNoThrow } from '../lib/execFileNoThrow.js'
import { logDebug } from '../lib/log.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const projectRoot = path.resolve(__dirname, '../..')
const runtimeRoot = path.join(projectRoot, 'runtime')
const runtimeStateRoot = path.join(projectRoot, '.runtime')
const venvRoot = path.join(runtimeStateRoot, 'venv')
const requirementsPath = path.join(runtimeRoot, 'requirements.txt')
const helperPath = path.join(runtimeRoot, 'mac_helper.py')
const installStampPath = path.join(runtimeStateRoot, 'requirements.sha256')
const bootstrapLockDir = path.join(runtimeStateRoot, 'bootstrap.lock')

let bootstrapPromise: Promise<void> | undefined

function pythonBinPath(): string {
  return path.join(venvRoot, 'bin', 'python3')
}

async function pathExists(target: string): Promise<boolean> {
  try {
    await access(target)
    return true
  } catch {
    return false
  }
}

async function runOrThrow(file: string, args: string[], label: string): Promise<string> {
  const { code, stdout, stderr } = await execFileNoThrow(file, args, { useCwd: false })
  if (code !== 0) {
    throw new Error(`${label} failed with code ${code}: ${stderr || stdout || 'unknown error'}`)
  }
  return stdout
}

async function sleep(ms: number): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, ms))
}

async function acquireBootstrapLock(): Promise<() => Promise<void>> {
  while (true) {
    try {
      await mkdir(bootstrapLockDir)
      await writeFile(
        path.join(bootstrapLockDir, 'owner.json'),
        JSON.stringify({ pid: process.pid, createdAt: Date.now() }),
        'utf8',
      )
      return async () => {
        await rm(bootstrapLockDir, { recursive: true, force: true })
      }
    } catch (error) {
      const code =
        typeof error === 'object' && error !== null && 'code' in error
          ? String((error as { code?: unknown }).code)
          : undefined
      if (code !== 'EEXIST') throw error
      await sleep(250)
    }
  }
}

async function ensureBootstrapped(): Promise<void> {
  if (bootstrapPromise) return bootstrapPromise
  bootstrapPromise = (async () => {
    await mkdir(runtimeStateRoot, { recursive: true })
    const releaseLock = await acquireBootstrapLock()
    try {
      if (!(await pathExists(pythonBinPath()))) {
        logDebug('creating runtime venv at %s', venvRoot)
        await runOrThrow('python3', ['-m', 'venv', venvRoot], 'python venv creation')
      }

      if (!(await pathExists(path.join(venvRoot, 'bin', 'pip')))) {
        logDebug('bootstrapping pip with ensurepip')
        await runOrThrow(pythonBinPath(), ['-m', 'ensurepip', '--upgrade'], 'ensurepip')
      }

      const requirements = await readFile(requirementsPath, 'utf8')
      const digest = createHash('sha256').update(requirements).digest('hex')
      let installedDigest = ''
      try {
        installedDigest = (await readFile(installStampPath, 'utf8')).trim()
      } catch {}

      if (installedDigest !== digest) {
        logDebug('installing python runtime dependencies')
        await runOrThrow(pythonBinPath(), ['-m', 'pip', 'install', '--upgrade', 'pip'], 'pip upgrade')
        await runOrThrow(
          pythonBinPath(),
          ['-m', 'pip', 'install', '-r', requirementsPath],
          'python dependency install',
        )
        await writeFile(installStampPath, `${digest}\n`, 'utf8')
      }
    } finally {
      await releaseLock()
    }
  })()

  try {
    await bootstrapPromise
  } catch (error) {
    bootstrapPromise = undefined
    throw error
  }
}

export async function callPythonHelper<T>(command: string, payload: Record<string, unknown> = {}): Promise<T> {
  await ensureBootstrapped()
  const { code, stdout, stderr } = await execFileNoThrow(
    pythonBinPath(),
    [helperPath, command, '--payload', JSON.stringify(payload)],
    { useCwd: false },
  )

  if (code !== 0 && !stdout.trim()) {
    throw new Error(stderr || `Python helper ${command} failed with code ${code}`)
  }

  let parsed: { ok: boolean; result?: T; error?: { message?: string } }
  try {
    parsed = JSON.parse(stdout)
  } catch {
    throw new Error(stderr || stdout || `Python helper ${command} returned invalid JSON`)
  }

  if (!parsed.ok) {
    throw new Error(parsed.error?.message || `Python helper ${command} failed`)
  }

  return parsed.result as T
}

export function getRuntimePaths(): { projectRoot: string; runtimeRoot: string; venvRoot: string } {
  return { projectRoot, runtimeRoot, venvRoot }
}
