#!/usr/bin/env python3
"""
MiniMax 音乐生成脚本
用法:
  uv run --with requests --with pyglet python scripts/music_generate.py "音乐描述" --play
  uv run --with requests --with pyglet python scripts/music_generate.py "音乐描述" --lyrics "歌词" --play
  uv run --with requests python scripts/music_generate.py "音乐描述" --instrumental
"""

import argparse
import base64
import json
import os
import sys
import uuid
from pathlib import Path
import struct

try:
    import requests
except ImportError:
    print("Error: requests not installed")
    print("Run: uv pip install --python python requests")
    sys.exit(1)

API_URL = "https://api.minimaxi.com/v1/music_generation"

# 默认输出文件夹（相对于 workspace，向上三级 from skills/minimax-music/scripts/）
_workspace = os.environ.get("OPENCLAW_WORKSPACE") or str(Path(__file__).parent.parent.parent)
DEFAULT_OUTPUT_DIR = Path(_workspace) / "minimax-music-output"


def get_api_key():
    key = os.environ.get("MINIMAX_API_KEY", "")
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        try:
            with open(config_path, encoding="utf-8") as f:
                cfg = json.load(f)
                key = cfg.get("api_key", key)
        except Exception:
            pass
    return key


def configure_interactive():
    print("\n=== MiniMax 音乐生成 配置向导 ===")
    print("请到 https://platform.minimaxi.com/user-center/basic-information/interface-key 获取 API Key\n")
    key = input("API Key: ").strip()
    if key:
        config_path = Path(__file__).parent.parent / "config.json"
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump({"api_key": key}, f, indent=2)
        print(f"[OK] Config saved to {config_path}")
    else:
        print("配置已取消。")
    return key


def generate(prompt, model, lyrics, is_instrumental, output_format, bitrate, sample_rate, output, play):
    api_key = get_api_key()
    if not api_key:
        print("[WARN] 缺少 API Key，尝试交互式配置...")
        api_key = configure_interactive()
        if not api_key:
            print("Error: 需要 API Key才能生成音乐")
            sys.exit(1)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "output_format": "hex",
        "audio_setting": {
            "sample_rate": sample_rate,
            "bitrate": bitrate,
            "format": output_format,
        },
        "is_instrumental": is_instrumental,
    }

    if lyrics:
        payload["lyrics"] = lyrics

    print(f"[INFO] 正在生成音乐...")
    print(f"       Model: {model}")
    print(f"       Prompt: {prompt}")
    if is_instrumental:
        print(f"       模式: 纯音乐（无人声）")
    elif lyrics:
        print(f"       歌词: {lyrics[:50]}...")
    print(f"       格式: {output_format} / {bitrate}bps / {sample_rate}Hz")

    try:
        resp = requests.post(API_URL, headers=headers, json=payload, timeout=300)
    except requests.exceptions.RequestException as e:
        print(f"Error: 请求失败: {e}")
        sys.exit(1)

    if resp.status_code != 200:
        print(f"Error: HTTP {resp.status_code}: {resp.text[:200]}")
        sys.exit(1)

    result = resp.json()
    base_resp = result.get("base_resp", {})
    status_code = base_resp.get("status_code", -1)
    if status_code != 0:
        msg = base_resp.get("status_msg", "Unknown error")
        print(f"Error [{status_code}]: {msg}")
        sys.exit(1)

    data = result.get("data", {})
    audio_status = data.get("status")
    if audio_status != 2:
        print(f"Error: 音乐生成状态={audio_status}，请稍后重试")
        sys.exit(1)

    audio_hex = data.get("audio", "")
    if not audio_hex:
        print("Error: 未找到音频数据")
        sys.exit(1)

    # 解码 hex → 字节
    audio_bytes = bytes.fromhex(audio_hex)

    # 生成输出文件名（默认保存到 minimax-music-output 文件夹）
    if output is None:
        safe_prompt = prompt[:20].replace(" ", "_").replace("\n", "_")
        safe_prompt = "".join(c for c in safe_prompt if c.isalnum() or c in "_- ")
        suffix = output_format
        DEFAULT_OUTPUT_DIR.mkdir(exist_ok=True)
        output = str(DEFAULT_OUTPUT_DIR / f"minimax_music_{safe_prompt}.{suffix}")

    with open(output, "wb") as f:
        f.write(audio_bytes)

    size = os.path.getsize(output)
    duration_ms = result.get("extra_info", {}).get("music_duration", 0)
    duration_s = duration_ms / 1000 if duration_ms else 0
    print(f"[OK] Saved: {output} ({size:,} bytes, {duration_s:.1f}s)")

    if play:
        _play(output)

    return output


def _play(file_path):
    import subprocess
    result = subprocess.run(
        [sys.executable, str(Path(__file__).parent / "play_music.py"), file_path],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print("[OK] Played successfully")
    else:
        print(f"[WARN] Playback: {result.stderr.strip()}")


def parse_args():
    parser = argparse.ArgumentParser(description="MiniMax 音乐生成")
    parser.add_argument("prompt", nargs="?", help="音乐描述（风格/情绪/场景）")
    parser.add_argument("--lyrics", "-l", default="",
                        help="歌词（用 \\n 分隔行）")
    parser.add_argument("--instrumental", "-i", action="store_true",
                        help="生成纯音乐（无人声）")
    parser.add_argument("--model", "-m", default="music-2.6",
                        choices=["music-2.6", "music-2.6-free",
                                 "music-cover", "music-cover-free"],
                        help="模型 (默认: music-2.6)")
    parser.add_argument("--format", "-f", default="mp3",
                        choices=["mp3", "wav", "pcm"],
                        help="音频格式 (默认: mp3)")
    parser.add_argument("--bitrate", type=int, default=256000,
                        help="比特率 (默认: 256000)")
    parser.add_argument("--sample-rate", type=int, default=44100,
                        help="采样率 (默认: 44100)")
    parser.add_argument("--output", "-o", default=None,
                        help="输出文件路径 (默认: minimax-music-output/)")
    parser.add_argument("--play", "-p", action="store_true",
                        help="生成后播放")
    parser.add_argument("--config", action="store_true",
                        help="交互式配置 API Key")
    return parser.parse_args()


def main():
    args = parse_args()

    if args.config:
        configure_interactive()
        return

    if not args.prompt:
        print("Error: 请提供音乐描述（prompt）")
        print("示例: python music_generate.py \"流行音乐,欢快,阳光\"")
        sys.exit(1)

    if not args.prompt.strip():
        print("Error: prompt 不能为空")
        sys.exit(1)

    # 纯音乐时 lyrics 非必填
    if not args.instrumental and not args.lyrics:
        print("[INFO] 未提供歌词，将生成纯音乐（无人声）")
        args.instrumental = True

    # lyrics 中的 \n 字符串转真正换行
    lyrics_text = args.lyrics.replace("\\n", "\n") if args.lyrics else ""

    generate(
        prompt=args.prompt,
        model=args.model,
        lyrics=lyrics_text,
        is_instrumental=args.instrumental,
        output_format=args.format,
        bitrate=args.bitrate,
        sample_rate=args.sample_rate,
        output=args.output,
        play=args.play,
    )


if __name__ == "__main__":
    main()
