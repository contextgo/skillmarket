#!/usr/bin/env python3
"""
MiniMax 歌词生成脚本
用法:
  uv run --with requests python scripts/lyrics_generate.py "一首关于夏日海边的轻快情歌"
  uv run --with requests python scripts/lyrics_generate.py "歌词描述" -m write_full_song -o lyrics.txt
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    import requests
except ImportError:
    print("Error: requests not installed")
    print("Run: uv pip install --python python requests")
    sys.exit(1)

API_URL = "https://api.minimaxi.com/v1/lyrics_generation"


def get_api_key():
    key = os.environ.get("MINIMAX_API_KEY", "")
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        try:
            with open(config_path, encoding="utf-8") as f:
                cfg = json.load(f)
                key = cfg.get("api_key", key)
        except Exception:
            pass
    return key


def generate(prompt, mode, output):
    api_key = get_api_key()
    if not api_key:
        print("Error: 需要 API Key。请在 config.json 中配置，或设置环境变量 MINIMAX_API_KEY")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    payload = {
        "mode": mode,
        "prompt": prompt,
    }

    print(f"[INFO] 正在生成歌词...")
    print(f"       Mode: {mode}")
    print(f"       Prompt: {prompt}")

    try:
        resp = requests.post(API_URL, headers=headers, json=payload, timeout=60)
    except requests.exceptions.RequestException as e:
        print(f"Error: 请求失败: {e}")
        sys.exit(1)

    if resp.status_code != 200:
        print(f"Error: HTTP {resp.status_code}: {resp.text[:200]}")
        sys.exit(1)

    result = resp.json()
    base_resp = result.get("base_resp", {})
    status_code = base_resp.get("status_code", -1)
    if status_code != 0:
        msg = base_resp.get("status_msg", "Unknown error")
        print(f"Error [{status_code}]: {msg}")
        sys.exit(1)

    song_title = result.get("song_title", "未命名")
    style_tags = result.get("style_tags", "")
    lyrics = result.get("lyrics", "")

    print(f"\n=== {song_title} ===")
    print(f"风格标签: {style_tags}\n")
    print(lyrics)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(f"# {song_title}\n")
            f.write(f"# 风格: {style_tags}\n\n")
            f.write(lyrics)
        print(f"\n[OK] 已保存到: {output}")

    return result


def parse_args():
    parser = argparse.ArgumentParser(description="MiniMax 歌词生成")
    parser.add_argument("prompt", nargs="?", help="歌词描述/主题")
    parser.add_argument("--mode", "-m", default="write_full_song",
                        choices=["write_full_song", "write_lyrics_only", "optimize_lyrics"],
                        help="模式 (默认: write_full_song)")
    parser.add_argument("--output", "-o", default=None,
                        help="输出文件路径 (默认: 打印到屏幕)")
    return parser.parse_args()


def main():
    args = parse_args()

    if not args.prompt:
        print("Error: 请提供歌词描述（prompt）")
        print("示例: python lyrics_generate.py \"一首关于夏日海边的轻快情歌\"")
        sys.exit(1)

    generate(prompt=args.prompt, mode=args.mode, output=args.output)


if __name__ == "__main__":
    main()
