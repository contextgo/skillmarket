#!/usr/bin/env python3
"""MiniMax 音乐播放器（无头模式）"""
import sys
import time
import argparse

try:
    import pyglet
except ImportError:
    print("Error: pyglet not installed. Run: uv pip install --python python pyglet")
    sys.exit(1)


def play_audio(file_path, wait=True):
    try:
        music = pyglet.media.load(file_path)
        player = pyglet.media.Player()
        player.queue(music)
        player.play()
        if wait:
            duration = music.duration
            print(f"Playing: {file_path} ({duration:.1f}s)")
            time.sleep(duration + 0.5)
        else:
            print(f"Started: {file_path}")
    except FileNotFoundError:
        print(f"Error: File not found: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Audio Player (headless)")
    parser.add_argument("file", help="Audio file path")
    parser.add_argument("--no-wait", action="store_true", help="Don't wait for playback to finish")
    args = parser.parse_args()
    play_audio(args.file, wait=not args.no_wait)
