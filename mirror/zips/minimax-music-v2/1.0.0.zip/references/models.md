# MiniMax 音乐生成 - 模型参考

## API 信息

- **接口地址：** `POST https://api.minimaxi.com/v1/music_generation`
- **认证：** `Authorization: Bearer <API_KEY>`
- **API Key：** https://platform.minimaxi.com/user-center/basic-information/interface-key

---

## 模型列表

| 模型 | 说明 | 用户类型 |
|------|------|----------|
| `music-2.6` | 文本生成音乐（推荐） | Token Plan / 付费用户 |
| `music-2.6-free` | `music-2.6` 限免版，RPM 较低 | 所有用户 ✅ |
| `music-cover` | 基于参考音频生成翻唱 | Token Plan / 付费用户 |
| `music-cover-free` | `music-cover` 限免版 | 所有用户 |

---

## 参数说明

### 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `model` | string | ✅ | 模型名称 |
| `prompt` | string | ✅ | 音乐描述（风格/情绪/场景） |
| `lyrics` | string | 非纯音乐 ✅ | 歌词，`\n` 分隔行 |
| `is_instrumental` | boolean | 否 | 是否纯音乐（无人声） |
| `audio_url` | string | 否 | 参考音频 URL（仅 music-cover） |
| `output_format` | string | 否 | `url` 或 `hex`，默认 `hex` |
| `stream` | boolean | 否 | 是否流式，默认 false |
| `audio_setting.sample_rate` | int | 否 | 采样率：`16000`/`24000`/`32000`/`44100` |
| `audio_setting.bitrate` | int | 否 | 比特率：`32000`/`64000`/`128000`/`256000` |
| `audio_setting.format` | string | 否 | 格式：`mp3`/`wav`/`pcm` |

### 歌词结构标签

`[Intro]` `[Verse]` `[Pre Chorus]` `[Chorus]` `[Interlude]` `[Bridge]` `[Outro]` `[Post Chorus]` `[Transition]` `[Break]` `[Hook]` `[Build Up]` `[Inst]` `[Solo]`

---

## 错误码

| status_code | 说明 |
|-------------|------|
| `0` | 成功 |
| `1002` | 触发限流，请稍后再试 |
| `1004` | 账号鉴权失败，检查 API Key |
| `1008` | 账号余额不足 |
| `1026` | 内容涉及敏感内容 |
| `2013` | 参数异常，检查入参 |
| `2049` | 无效的 API Key |

---

## prompt 写作建议

格式：`风格,情绪,场景`

示例：
- `"流行音乐,欢快,阳光下"`
- `"钢琴独奏,安静,放松,咖啡馆"`
- `"电子音乐,充满能量,健身"`
- `"古风,忧伤,离别"`
- `"摇滚,叛逆,深夜"`

多个维度用逗号分隔，越详细生成效果越好。
