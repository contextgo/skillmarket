---
name: minimax-music-v2-v2
description: 使用 MiniMax API 生成 AI 音乐。当用户要求生成音乐、创作歌曲、作曲、或提到"AI音乐"、"生成歌曲"时触发。
---

# MiniMax 音乐生成

基于 MiniMax Music Generation API 生成 AI 音乐。

## 功能

- **歌词生成** — 根据描述生成完整歌词
- **音乐生成** — 根据描述（+歌词）生成音乐（需音乐 Plan）

## 依赖

- `requests` — HTTP 请求
- `pyglet` — 音频播放（播放 mp3/wav，仅音乐生成需要）

## 配置

API Key 保存在 `config.json`，或环境变量 `MINIMAX_API_KEY`。

API Key 获取地址：https://platform.minimaxi.com/user-center/basic-information/interface-key

> 注意：Music Generation API 需要独立的音乐 Plan；Lyrics Generation API 可用 Coding Plan Key。
> **已验证可用模型：`music-2.6`**（需音乐 Plan）；`music-2.6-free` 需独立申请。

## 输出目录

生成的音频文件默认保存在 `minimax-music-output/` 目录下（相对于 workspace）。

歌词文件默认打印到屏幕（指定 `-o` 时保存到指定路径）。

可使用 `--output, -o` 参数指定其他输出路径。

## 运行方式

```bash
# 生成歌词
uv run --with requests python <skill>/scripts/lyrics_generate.py "一首关于夏日海边的轻快情歌"

# 生成歌词并保存到文件
uv run --with requests python <skill>/scripts/lyrics_generate.py "描述" -o lyrics.txt

# 生成音乐（需音乐 Plan，推荐 model=music-2.6）
uv run --with requests --with pyglet python <skill>/scripts/music_generate.py "流行音乐,欢快,阳光" --lyrics "歌词内容" --play

# 生成纯音乐（无人声）
uv run --with requests --with pyglet python <skill>/scripts/music_generate.py "钢琴独奏,安静,放松" --instrumental --play

# 指定模型（默认 music-2.6，已验证可用）
uv run --with requests --with pyglet python <skill>/scripts/music_generate.py "..." -m music-2.6

# 播放已有音频
uv run --with pyglet python <skill>/scripts/play_music.py audio.mp3
```

## 参数

### 歌词生成参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `prompt` | 歌词描述/主题 | 必填 |
| `--mode, -m` | 模式 | write_full_song |
| `--output, -o` | 输出文件路径 | 打印到屏幕 |

**歌词生成模式：**
- `write_full_song` — 生成完整歌词（推荐）
- `write_lyrics_only` — 只生成歌词（无标题/标签）
- `optimize_lyrics` — 优化已有歌词

### 音乐生成参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `prompt` | 音乐描述（风格/情绪/场景） | 必填 |
| `--lyrics, -l` | 歌词（用 `\n` 分隔行） | 可选 |
| `--instrumental, -i` | 生成纯音乐无人声 | false |
| `--model, -m` | 模型 | music-2.6 |
| `--format, -f` | 输出格式 mp3/wav/pcm | mp3 |
| `--bitrate` | 比特率 | 256000 |
| `--sample-rate` | 采样率 | 44100 |
| `--output, -o` | 输出文件路径 | `minimax-music-output/` |
| `--play, -p` | 生成后播放 | 关闭 |

## 模型列表

| 模型 | 说明 | 适用场景 |
|------|------|----------|
| `music-2.6` | 文本生成音乐（推荐，已验证✅） | 需音乐 Plan |
| `music-2.6-free` | `music-2.6` 限免版 | 需独立申请 |
| `music-cover` | 参考音频生成翻唱 | 需音乐 Plan |
| `music-cover-free` | `music-cover` 限免版 | 需独立申请 |

## 歌词结构标签

可在歌词中使用以下标签：

`[Intro]` `[Verse]` `[Pre Chorus]` `[Chorus]` `[Interlude]` `[Bridge]` `[Outro]` `[Post Chorus]` `[Transition]` `[Break]` `[Hook]` `[Build Up]` `[Inst]` `[Solo]`

## 示例

```bash
# 流行歌曲，有歌词
uv run --with requests --with pyglet python <skill>/scripts/music_generate.py "流行音乐,欢快,阳光下" \
  --lyrics "[Verse]\n街道边的树叶\n阳光穿过缝隙\n[Verse]\n风吹过我的脸" \
  --play

# 纯音乐，无人声
uv run --with requests --with pyglet python <skill>/scripts/music_generate.py "钢琴独奏,安静,放松" \
  --instrumental \
  --play
```

## 安装依赖

```bash
uv pip install --python python requests pyglet
```
