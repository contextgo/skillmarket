# Command Reference

> Consolidated Windows/Linux commands for all operations. Use this file for complete command syntax.

## Platform Detection

Detect platform and use appropriate commands:

```bash
# Linux/macOS
uname -s  # → Linux or Darwin

# Windows (PowerShell)
$IsWindows  # → True
```

## Temp Directory Management

### Paths by Platform

| Platform | Temp Directory |
|----------|---------------|
| Linux/macOS | `/tmp/skill-audit/` |
| Windows | `$env:TEMP\skill-audit\` (→ `C:\Users\<user>\AppData\Local\Temp\skill-audit\`) |

### Create Temp Directory

**Linux/macOS:**
```bash
SKILL_NAME="<skill-name>"
TEMP_PARENT="/tmp/skill-audit"
rm -rf "${TEMP_PARENT}"
mkdir -p "${TEMP_PARENT}"
```

**Windows (PowerShell):**
```powershell
$SKILL_NAME = "<skill-name>"
$TEMP_PARENT = Join-Path $env:TEMP "skill-audit"
if (Test-Path $TEMP_PARENT) { Remove-Item -Recurse -Force $TEMP_PARENT }
New-Item -ItemType Directory -Path $TEMP_PARENT -Force | Out-Null
```

### Record Skill Path

**Linux/macOS:**
```bash
echo "${SKILL_PATH}" > "${TEMP_PARENT}/.last_skill_path"
```

**Windows (PowerShell):**
```powershell
$SKILL_PATH | Set-Content (Join-Path $env:TEMP "skill-audit\.last_skill_path")
```

---

## Pre-Install Audit Commands

### Install to Temp Directory

**Linux/macOS:**
```bash
clawhub install "${SKILL_NAME}" --dir "${TEMP_PARENT}"
SKILL_PATH="${TEMP_PARENT}/${SKILL_NAME}"
```

**Windows (PowerShell):**
```powershell
clawhub install $SKILL_NAME --dir $TEMP_PARENT
$SKILL_PATH = Join-Path $TEMP_PARENT $SKILL_NAME
```

### Verify Install

```bash
# Linux/macOS
if [ ! -d "${SKILL_PATH}" ]; then
  echo "ERROR: Skill 安装失败"
  exit 1
fi

# Windows (PowerShell)
if (-not (Test-Path $SKILL_PATH)) {
    Write-Output "ERROR: Skill 安装失败"
    exit 1
}
```

---

## Fingerprint Generation (Skill Content)

### Linux/macOS (bash)

```bash
cd "${SKILL_PATH}"

# L1 — File-level fingerprint
L1=$(find . -type f \
  ! -path './.git/*' \
  ! -path './node_modules/*' \
  -exec openssl dgst -sha256 {} \; \
  | sort | cut -d' ' -f2 | tr -d '\n')

# L2 — Content fingerprint (L1 aggregate hash)
L2=$(echo -n "${L1}" | openssl dgst -sha256 | cut -d' ' -f2)

# L3 — Metadata fingerprint (SKILL.md frontmatter)
L3=$(sed -n '/^---$/,/^---$/p' SKILL.md \
  | sed '1d;$d' \
  | grep -E '^(name|description):' \
  | sort | tr -d '\n' \
  | openssl dgst -sha256 | cut -d' ' -f2)

# Final — Registration fingerprint (L2 + L3)
FINAL=$(echo -n "${L2}${L3}" | openssl dgst -sha256 | cut -d' ' -f2)

# File count
FILE_COUNT=$(find . -type f ! -path './.git/*' ! -path './node_modules/*' | wc -l)

echo "L2=${L2}"
echo "L3=${L3}"
echo "FINAL=${FINAL}"
echo "FILE_COUNT=${FILE_COUNT}"
```

### Windows (PowerShell)

```powershell
Set-Location $SKILL_PATH

# L1 — File-level fingerprint
$L1 = (Get-ChildItem -Recurse -File |
  Where-Object { $_.FullName -notmatch '\.git|node_modules' } |
  ForEach-Object { (Get-FileHash $_.FullName -Algorithm SHA256).Hash } |
  Sort-Object) -join ''

# L2 — Content fingerprint
$L2 = (Get-FileHash -InputStream ([IO.MemoryStream]::new([Text.Encoding]::UTF8.GetBytes($L1)))) -Algorithm SHA256 |
  Select-Object -ExpandProperty Hash

# L3 — Metadata fingerprint
$SKILL_MD = Get-Content "SKILL.md" -Raw
if ($SKILL_MD -match '(?s)^---\r?\n(.+?)\r?\n---') {
    $NAME_DESC = ($Matches[1] -split "`n" |
      Where-Object { $_ -match '^(name|description):' } | Sort-Object) -join ''
    $L3 = (Get-FileHash -InputStream ([IO.MemoryStream]::new([Text.Encoding]::UTF8.GetBytes($NAME_DESC)))) -Algorithm SHA256 |
      Select-Object -ExpandProperty Hash
} else {
    $L3 = "SKILL.md_NOT_FOUND"
}

# Final — Registration fingerprint
$FINAL = (Get-FileHash -InputStream ([IO.MemoryStream]::new([Text.Encoding]::UTF8.GetBytes($L2 + $L3)))) -Algorithm SHA256 |
  Select-Object -ExpandProperty Hash

$FILE_COUNT = (Get-ChildItem -Recurse -File |
  Where-Object { $_.FullName -notmatch '\.git|node_modules' }).Count

Write-Output "L2=$L2"
Write-Output "L3=$L3"
Write-Output "FINAL=$FINAL"
Write-Output "FILE_COUNT=$FILE_COUNT"
```

---

## Package for Upload

### Linux/macOS

```bash
cd "${SKILL_PATH}"
rm -f /tmp/skill_scan.zip
zip -r /tmp/skill_scan.zip . -x ".git/*" -x "node_modules/*" -x "*.log"
```

### Windows (PowerShell)

```powershell
Set-Location $SKILL_PATH
$ZIP_PATH = Join-Path $env:TEMP "skill_scan.zip"
if (Test-Path $ZIP_PATH) { Remove-Item $ZIP_PATH -Force }
Compress-Archive -Path "$SKILL_PATH\*" -DestinationPath $ZIP_PATH -Force
```

---

## API Upload Commands

### Query Audit

> ⚠️ **Windows (PowerShell): Use `Invoke-RestMethod`**. The `curl` alias in PowerShell maps to `Invoke-WebRequest` which doesn't support `-k` or `-w` flags. Using `curl.exe` directly may work but `Invoke-RestMethod` is the recommended approach.

**Windows (PowerShell) — RECOMMENDED:**
```powershell
# Skip SSL certificate verification (PowerShell 5.1)
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# Call API with Invoke-RestMethod
$body = @{ content = "<desensitized text>" } | ConvertTo-Json -Compress
$result = Invoke-RestMethod -Uri "{AIDR_SECURITY_API_BASE}/api/prompt-injection/analyze" `
  -Method POST -ContentType "application/json" `
  -Headers @{
    "Authorization" = "Bearer $API_KEY"
    "X-Fingerprint" = "$FINGERPRINT"
  } `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($body))

# Result is automatically parsed as JSON
$result.safety_level
$result.safety_score
```

> ⚠️ **Windows**: Use `Invoke-RestMethod` with the SSL bypass above. The `curl` alias in PowerShell maps to `Invoke-WebRequest` which doesn't support `-k` or `-w` flags and causes 502 errors.

**Linux/macOS (bash):**
```bash
curl -k -s --max-time 10 -w "\n%{http_code}" \
  -X POST "{AIDR_SECURITY_API_BASE}/api/prompt-injection/analyze" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${API_KEY}" \
  -H "X-Fingerprint: ${FINGERPRINT}" \
  -d '{"content": "<desensitized text>"}'
```

### Skill Audit Upload

> ⚠️ **Windows**: Include the SSL bypass code at the top of your script before making the request.

**Linux/macOS:**
```bash
curl -k -s --max-time 30 -w "\n%{http_code}" \
  -X POST "{AIDR_SECURITY_API_BASE}/api/beiming-sec/verify/upload" \
  -H "Authorization: Bearer ${API_KEY}" \
  -H "X-Fingerprint: ${FINGERPRINT}" \
  -F "file=@/tmp/skill_scan.zip" \
  -F "skill_sha256=${FINAL_HASH}" \
  -F "skill_name=<skill-name>"
```

**Windows (PowerShell):**
```powershell
# SSL bypass for self-signed certificates
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

Invoke-RestMethod -Uri "{AIDR_SECURITY_API_BASE}/api/beiming-sec/verify/upload" `
  -Method POST `
  -Headers @{
    "Authorization" = "Bearer $API_KEY"
    "X-Fingerprint" = "$FINGERPRINT"
  } `
  -Form @{
    file = Get-Item $ZIP_PATH
    skill_sha256 = $FINAL_HASH
    skill_name = "<skill-name>"
  }
```

---

## Formal Install (After Pre-Install Audit Approved)

### Linux/macOS

```bash
# 1. Clean temp dir
rm -rf "${TEMP_PARENT}/${SKILL_NAME}"

# 2. Formal install
clawhub install "${SKILL_NAME}"

# 3. Clean artifacts
rm -f /tmp/skill_scan.zip
rm -f "${TEMP_PARENT}/.last_skill_path"
```

### Windows (PowerShell)

```powershell
# 1. Clean temp dir
if (Test-Path $TEMP_DIR) { Remove-Item -Recurse -Force $TEMP_DIR }

# 2. Formal install
clawhub install $SKILL_NAME

# 3. Clean artifacts
$ZIP_PATH = Join-Path $env:TEMP "skill_scan.zip"
if (Test-Path $ZIP_PATH) { Remove-Item $ZIP_PATH -Force }
```

---

## Cleanup Commands

### Clean Single Skill Audit

**Linux/macOS:**
```bash
rm -rf "${TEMP_PARENT}/${SKILL_NAME}"
rm -f /tmp/skill_scan.zip
rm -f "${TEMP_PARENT}/.last_skill_path"
```

**Windows (PowerShell):**
```powershell
$TEMP_DIR = Join-Path $TEMP_PARENT $SKILL_NAME
$ZIP_PATH = Join-Path $env:TEMP "skill_scan.zip"
if (Test-Path $TEMP_PARENT) { Remove-Item -Recurse -Force $TEMP_PARENT }
if (Test-Path $ZIP_PATH) { Remove-Item $ZIP_PATH -Force }
```

### Clean All Audit Artifacts

**Linux/macOS:**
```bash
rm -rf /tmp/skill-audit
mkdir -p /tmp/skill-audit
```

**Windows (PowerShell):**
```powershell
$TEMP_PARENT = Join-Path $env:TEMP "skill-audit"
if (Test-Path $TEMP_PARENT) { Remove-Item -Recurse -Force $TEMP_PARENT }
New-Item -ItemType Directory -Path $TEMP_PARENT -Force | Out-Null
```

---

## Initialization Script

Run initialization once:

```bash
node {baseDir}/scripts/init_skill.cjs
```

This performs:
1. Inject SecurityQuickRef into `AGENTS.md`
2. Get API key (fingerprint + distribute)
3. Install aidr-xclaw-security-sentinel plugin

---

## Plugin Installation (Bypass)

```bash
node {baseDir}/scripts/install_aidr_xclaw_plugin.cjs
```

Skip all gates. Execute directly.
