# Authentication Flow Reference

> Detailed auth flow for API calls. SKILL.md has the summary; this file has complete commands.

> ⚠️ **API Endpoint**: Use `https://venustech-ai.online:28200` (NOT `api.beiming-ai.com`)

## Dual Authentication

All API calls require:
1. **API Key** — stored locally in `{baseDir}/.state/api_state.json`
2. **Fingerprint** — generated fresh before every API call (never cached)

```
┌─────────────────────────────────────────────────────────────┐
│ [Agent]                              [Backend API]           │
│                                                              │
│ 1. Check local api_state.json ─────────────────────────────▶│
│                                                              │
│ 2. If missing:                                              │
│    ├─ Generate fingerprint (fingerprint.mjs)                │
│    └─ POST /api/baseline/api_key/distribute                 │
│                                                              │
│ 3. Store api_key locally                                     │
│                                                              │
│ 4. For every API call:                                      │
│    ├─ Generate fresh fingerprint                            │
│    └─ GET/POST with headers:                               │
│         Authorization: Bearer <api_key>                      │
│         X-Fingerprint: <fingerprint>                        │
└─────────────────────────────────────────────────────────────┘
```

## Phase 1: Check Existing API Key

### Linux/macOS

```bash
cat {baseDir}/.state/api_state.json
```

### Windows (PowerShell)

```powershell
Get-Content "{baseDir}\.state\api_state.json" -Raw
```

**Expected format:**
```json
{
  "api_key": "abc123...",
  "created_at": "2026-04-15T15:00:00.000Z"
}
```

- If file exists with valid `api_key` → skip Phase 2
- If file missing or `api_key` empty → proceed to Phase 2

## Phase 2: Get API Key

### Step 2.1: Generate Device Fingerprint

**Linux/macOS:**
```bash
node {baseDir}/scripts/fingerprint.mjs
```

**Windows (PowerShell):**
```powershell
node "{baseDir}\scripts\fingerprint.mjs"
```

Output: 64-character hexadecimal SHA-256 hash.

### Step 2.2: Apply for API Key

**Linux/macOS (bash):**
```bash
curl -k -s -X POST "{AIDR_SECURITY_API_BASE}/api/baseline/api_key/distribute" \
  -H "Content-Type: application/json" \
  -d '{"fingerprint": "FINGERPRINT"}'
```

**Windows (PowerShell):**
```powershell
$body = @{ fingerprint = "FINGERPRINT" } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri "{AIDR_SECURITY_API_BASE}/api/baseline/api_key/distribute" `
  -Method POST -ContentType "application/json" `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) | ConvertTo-Json
```

> ⚠️ **Windows**: Use `Invoke-RestMethod`, NOT `curl.exe`. PowerShell string escaping corrupts JSON bodies.

**Expected response:**
```json
{
  "api_key": "xyz...",
  "fingerprint": "my_machine_123"
}
```

### Step 2.3: Save to Local State

**Linux/macOS (bash):**
```bash
mkdir -p {baseDir}/.state
echo '{"api_key":"ACTUAL_API_KEY","created_at":"TIMESTAMP"}' > {baseDir}/.state/api_state.json
```

**Windows (PowerShell):**
```powershell
New-Item -ItemType Directory -Path "{baseDir}\.state" -Force | Out-Null
@{
  api_key = "ACTUAL_API_KEY"
  created_at = (Get-Date -Format "o")
} | ConvertTo-Json | Set-Content -Path "{baseDir}\.state\api_state.json" -Encoding UTF8
```

## Phase 3: Use Fingerprint + API Key

> ⚠️ **Critical**: Generate fresh fingerprint before EVERY API call. Never use cached values.

### Generate Fresh Fingerprint

**Linux/macOS:**
```bash
node {baseDir}/scripts/fingerprint.mjs
```

**Windows (PowerShell):**
```powershell
node "{baseDir}\scripts\fingerprint.mjs"
```

### API Call with Auth

**Query Audit (Windows PowerShell) — RECOMMENDED:**
```powershell
# Skip SSL certificate verification (PowerShell 5.1)
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# Generate fresh fingerprint
$FINGERPRINT = node "{baseDir}\scripts\fingerprint.mjs"

# Call API with Invoke-RestMethod
$body = @{ content = "..." } | ConvertTo-Json -Compress
$result = Invoke-RestMethod -Uri "{AIDR_SECURITY_API_BASE}/api/prompt-injection/analyze" `
  -Method POST -ContentType "application/json" `
  -Headers @{
    "Authorization" = "Bearer $API_KEY"
    "X-Fingerprint" = "$FINGERPRINT"
  } `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($body))
```

> ⚠️ **Windows**: Use `Invoke-RestMethod` with SSL bypass. The `curl` alias in PowerShell maps to `Invoke-WebRequest` which doesn't support `-k` or `-w` flags and may cause 502 errors.

**Query Audit (Linux/macOS):**
```bash
curl -k -s --max-time 10 -w "\n%{http_code}" \
  -X POST "{AIDR_SECURITY_API_BASE}/api/prompt-injection/analyze" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer API_KEY" \
  -H "X-Fingerprint: FINGERPRINT" \
  -d '{"content": "..."}'
```

**Skill Audit (Linux/macOS):**
```bash
curl -k -s --max-time 30 -w "\n%{http_code}" \
  -X POST "{AIDR_SECURITY_API_BASE}/api/beiming-sec/verify/upload" \
  -H "Authorization: Bearer ${API_KEY}" \
  -H "X-Fingerprint: ${FINGERPRINT}" \
  -F "file=@/tmp/skill_scan.zip" \
  -F "skill_sha256=${FINAL_HASH}" \
  -F "skill_name=<skill-name>"
```

**Skill Audit (Windows PowerShell):**
```powershell
# SSL bypass for self-signed certificates
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

Invoke-RestMethod -Uri "{AIDR_SECURITY_API_BASE}/api/beiming-sec/verify/upload" `
  -Method POST `
  -Headers @{
    "Authorization" = "Bearer $API_KEY"
    "X-Fingerprint" = "$FINGERPRINT"
  } `
  -Form @{
    file = Get-Item $ZIP_PATH
    skill_sha256 = $FINAL_HASH
    skill_name = "<skill-name>"
  }
```

## Error Handling

| Scenario | Action |
|----------|--------|
| `node` not found | Install Node.js 18+ |
| Fingerprint script fails | Check OS compatibility (darwin, win32, linux, freebsd) |
| API key request fails | Check backend service; check network |
| `401 Unauthorized` on analyze | API key invalid/expired → delete api_state.json, retry Phase 2 |
| `403 Forbidden` on analyze | Fingerprint mismatch → regenerate, retry |
| `422 Unprocessable Entity` | JSON encoding issue → use `Invoke-RestMethod` on Windows |

## Force Re-authentication

Delete `{baseDir}/.state/api_state.json` and restart from Phase 2.

## State File Format

`{baseDir}/.state/api_state.json`:

```json
{
  "api_key": "abc123...",
  "created_at": "2026-04-15T15:00:00.000Z"
}
```

> **Note**: Only `api_key` is stored. Fingerprint is NEVER persisted — always generated fresh from hardware.
