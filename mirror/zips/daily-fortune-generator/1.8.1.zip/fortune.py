import os
import sys
import json
import hashlib
import requests
from datetime import datetime

# ==================== 配置常量 ====================
API_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
VERSION = "1.8.1"
ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

ZODIACS = {
    "1": ("白羊座", "aries"), "2": ("金牛座", "taurus"), "3": ("双子座", "gemini"),
    "4": ("巨蟹座", "cancer"), "5": ("狮子座", "leo"), "6": ("处女座", "virgo"),
    "7": ("天秤座", "libra"), "8": ("天蝎座", "scorpio"), "9": ("射手座", "sagittarius"),
    "10": ("摩羯座", "capricorn"), "11": ("水瓶座", "aquarius"), "12": ("双鱼座", "pisces")
}

SCENARIOS = {
    "1": ("综合运势", "general"), "2": ("事业财运", "career"), 
    "3": ("爱情桃花", "love"), "4": ("健康出行", "health")
}

def get_api_key():
    return os.getenv("DASHSCOPE_API_KEY")

def call_ai(prompt):
    key = get_api_key()
    if not key:
        return "⚠️ 请先配置 DASHSCOPE_API_KEY 环境变量以启用 AI 解读功能。"
    
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {
        "model": "qwen-turbo",
        "input": {"messages": [{"role": "user", "content": prompt}]},
        "parameters": {"temperature": 0.8, "max_tokens": 1000}
    }
    try:
        resp = requests.post(API_URL, headers=headers, json=payload, timeout=15)
        return resp.json()["output"]["choices"][0]["message"]["content"]
    except Exception as e:
        return f"⚠️ 生成失败，请检查网络或 API Key: {str(e)}"

def print_menu(title, options):
    print(f"\n--- {title} ---")
    for k, (v, _) in options.items():
        print(f"  [{k}] {v}")
    print("  [q] 退出程序\n")

def show_help():
    qr_path = os.path.join(ASSETS_DIR, "ydwecom.png")
    print("\n" + "=" * 40)
    print("🆘 Poseidon 帮助与支持中心")
    print("=" * 40)
    print("遇到问题或有定制需求？欢迎扫码联系我们的企业微信客服。")
    print(f"二维码路径: {qr_path}")
    if os.path.exists(qr_path):
        print("（图片已保存在本地 assets 文件夹中）")
    else:
        print("（警告：本地未找到二维码图片，请联系管理员）")
    print("=" * 40 + "\n")

def generate_poster_via_host(zodiac, scenario, content):
    """在 OpenClaw 环境下触发原生绘图"""
    prompt = f"为{zodiac}的{scenario}运势生成一张橘色系扁平插画风格海报，9:16竖版。内容摘要：{content[:50]}..."
    # 这是一个约定的指令标记，宿主环境会捕获并处理
    print(f"\n[OpenClaw指令] generate_image --prompt \"{prompt}\" --style flat_illustration --ratio 9:16")

def interactive_guide():
    print(f"\n🔮 Poseidon Daily Fortune v{VERSION}")
    print("你的每日能量补给站 | 开启充满能量的一天")
    print("=" * 40)
    
    while True:
        user_input = input("请输入星座、场景编号，或输入'帮助'获取支持: ").strip()
        if user_input.lower() == 'q': break
        if user_input in ["帮助", "help", "客服", "support"]:
            show_help()
            continue

        # 简化的交互逻辑，实际可根据需要扩展更复杂的 NLP 匹配
        z_name, z_en = None, None
        s_name, s_en = None, None
        
        # 这里保留原有的菜单选择逻辑作为 fallback
        if user_input.isdigit() and int(user_input) <= 12:
             z_name, z_en = ZODIACS.get(user_input, (None, None))
        elif user_input in [name for name, _ in ZODIACS.values()]:
             for _, (name, en) in ZODIACS.items():
                if user_input == name: z_name, z_en = name, en

        if not z_name:
            print_menu("请选择你的星座", ZODIACS)
            continue
            
        print_menu(f"为【{z_name}】选择关注领域", SCENARIOS)
        s_choice = input("请输入编号: ").strip()
        s_name, s_en = SCENARIOS.get(s_choice, (None, None))
        
        if not s_name:
            print("❌ 未识别的场景，请重试。\n"); continue

        print(f"\n⏳ 正在为 {z_name} 解析 {s_name}...")
        prompt = f"请以温暖治愈的风格，为{z_name}生成今日{s_name}。包含评分(0-100)、星级、具体建议和占星学依据。多用 emoji。"
        result = call_ai(prompt)
        
        print(f"\n✨ 【{z_name} · {s_name} | {datetime.now().strftime('%m-%d')}】\n")
        print(result)
        
        action = input("\n接下来做什么？[P]生成海报 [H]帮助 [Q]退出: ").strip().upper()
        if action == 'Q': break
        if action == 'H': 
            show_help()
            continue
        if action == 'P':
            if os.getenv("OPENCLAW_ENV"):
                generate_poster_via_host(z_name, s_name, result)
            else:
                print("🎨 本地模式下，请配置 DASHSCOPE_API_KEY 以启用自动绘图，或前往 OpenClaw 平台体验一键生成。")

if __name__ == "__main__":
    interactive_guide()
