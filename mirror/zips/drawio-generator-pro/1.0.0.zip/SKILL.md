---
name: drawio-generator
description: 将自然语言流程描述或文档转换为 draw.io 可编辑 XML 图表（.drawio 文件）。使用场景：(1) 用户描述业务流程需要生成流程图，(2) 用户上传文档需要提取流程并生成图表，(3) 用户要求画架构图/时序图/网络拓扑图。生成后必须告知用户：用 draw.io 网页版（app.diagrams.net）或桌面版打开 .drawio 文件进行查看和手动微调。
---

# drawio-generator

## 执行流程

1. 接收用户描述（文字或文件）
2. 生成结构化 JSON（nodes + edges）→ 展示给用户确认
3. 用户确认后调用 `scripts/gen.py` 生成 `.drawio` 文件
4. 交付文件，告知用户打开方式

> ⚠️ **重要**：生成结果非完美，线条重叠、节点间距不理想等情况可能发生。正常流程：生成 `.drawio` → 用 draw.io 打开 → 手动微调 → 保存。

## 调用方式

```bash
python3 skills/drawio-generator/scripts/gen.py "图表标题" '{"title":"...","nodes":[...],"edges":[...]}' [类型]
```

输出路径：`/Users/owen/Desktop/drawio-generator/{图表标题}.drawio`

## JSON 结构

```json
{
  "title": "流程名称",
  "type": "flowchart",
  "nodes": [
    {"id": "0", "type": "start", "label": "开始"},
    {"id": "1", "type": "process", "label": "处理步骤"},
    {"id": "2", "type": "decision", "label": "判断条件？"},
    {"id": "3", "type": "end", "label": "结束"}
  ],
  "edges": [
    {"source": "0", "target": "1"},
    {"source": "1", "target": "2"},
    {"source": "2", "target": "3", "label": "是"},
    {"source": "2", "target": "1", "label": "否"}
  ]
}
```

### type 值

| 值 | 说明 |
|----|------|
| `start` | 椭圆，开始节点 |
| `end` | 椭圆，结束节点 |
| `process` | 圆角矩形，处理步骤 |
| `decision` | 菱形，判断节点 |
| `document` | 文档形状 |
| `data` | 平行四边形，数据存储 |

### edges.label 值

| 值 | 说明 |
|----|------|
| `是` / `Y` | 条件为真 |
| `否` / `N` | 条件为假 |
| 空字符串 | 普通顺序流 |

## 文件说明

| 文件 | 说明 |
|------|------|
| `scripts/gen.py` | **标准生成脚本**（必须使用，禁止直接调用 generator.py） |
| `scripts/__main__.py` | 完整管道（含 LLM 分析模式） |
| `scripts/generator.py` | 底层 XML 生成器（gen.py 内部调用） |
| `references/drawio-xml-spec.md` | draw.io XML 格式规范（详细样式/属性说明） |

## 布局参数

generator.py 内置参数（可在 gen.py 中修改）：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `CANVAS_WIDTH` | 850 | 画布宽度 |
| `_LAYER_GAP_Y` | 120 | 层间垂直间距 |
| `MAIN_X` | 425 | 主轴 X 坐标 |

如需压缩布局（A4 大小），调用 `generate_drawio_xml()` 前修改这些全局变量。
