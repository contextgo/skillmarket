# xsjc - 小说检查修改润色技能

> 小说全生命周期质量检查与优化工具集（v1.3.0）

## 一、技能简介

xsjc是专为番茄小说创作者设计的**全流程质量检查与优化技能**，整合了：

- ✅ **逻辑检查**：章节连贯性、伏笔追踪、角色一致性
- ✅ **文笔优化**：句式模板检测（AI味）、自动润色、替换建议
- ✅ **合规扫描**：敏感词检测、正面角色比例、合法手段统计
- ✅ **自动整改**：一键去除重复句式、批量替换比喻、dry-run模拟

**核心优势**：
- 📊 **多维度检测**：字符+词级+比喻三合一，更精准
- 🤖 **AI味专项**：检测11+种常见AI句式，生成替换方案
- 🔒 **安全执行**：dry-run模式 + 自动备份原文件
- 🚀 **一键整改**：10分钟完成全书300+处修改

## 二、快速安装

### 环境要求
- Python 3.7+（推荐3.10+）
- 可选：jieba（提升中文分词精度）
  ```bash
  pip install jieba
  ```

### 技能安装
将`xsjc`文件夹复制到`~/.workbuddy/skills/`目录下：
```
~/.workbuddy/skills/xsjc/
├── SKILL.md              # 技能描述（本文档的详细版）
├── README.md            # 本文件（快速入门）
├── scripts/             # 12个Python脚本
│   ├── logic_check.py
│   ├── similarity_detector.py
│   ├── style_pattern_detector.py
│   ├── polish_engine.py
│   └── ... (共12个)
└── config/              # 配置文件（待创建）
```

## 三、5分钟上手

### 3.1 检查单章
```bash
cd ~/.workbuddy/skills/xsjc/scripts
python chapter_check.py --input chapter-044.txt
```

**输出**：字数、对话比例、章节评分。

### 3.2 检测全文句式模板（AI味）
```bash
python style_pattern_detector.py --project "C:\Users\Administrator\Desktop\村书记的回头路\纯净版"
```

**输出**：`style_report.json` + `style_report.txt`，列出所有"愣了X秒"、"声音很X"等句式。

### 3.3 生成润色建议
```bash
python polish_advisor.py --input chapter-044.txt
```

**输出**：`polish_chapter-044.json` + `polish_chapter-044.txt`，按严重程度分级。

### 3.4 自动整改（全书）
```bash
# 先模拟运行（不实际修改）
python polish_engine.py --project "纯净版/" --dry-run

# 确认无误后，实际执行
python polish_engine.py --project "纯净版/"
```

**安全机制**：原文件自动备份为`.bak`。

## 四、常用命令速查表

| 需求 | 命令 | 用时 |
|------|------|------|
| 全书逻辑检查 | `python logic_check.py --project <路径>` | 2-5分钟（100章） |
| AI味句式检测 | `python style_pattern_detector.py --project <路径>` | 1-3分钟 |
| 自动润色（模拟） | `python polish_engine.py --project <路径> --dry-run` | 1-2分钟 |
| 自动润色（执行） | `python polish_engine.py --project <路径>` | 5-10分钟（100章） |
| 单章质量分析 | `python chapter_check.py --input ch.txt` | <10秒 |
| 角色声音校验 | `python voice_validator.py --project <路径>` | 1-2分钟 |
| 伏笔追踪 | `python foreshadowing_tracker.py --project <路径>` | 1-2分钟 |
| 疲劳度分析 | `python fatigue_analyzer.py --project <路径>` | <1分钟 |
| 合规扫描 | `python compliance_scanner.py --project <路径>` | <1分钟 |
| 生成总报告 | `python report_generator.py --project <路径>` | <1分钟 |
| 分割小说 | `python split_novel.py <合并文件.txt> <输出目录>` | <1分钟 |

## 五、与WorkBuddy集成

### 触发方式
1. **直接说触发词**：
   - "检查小说《村书记的回头路》"
   - "检测小说里的重复句式"
   - "帮我润色第44章"

2. **指定技能名**：
   ```
   /xsjc
   ```

3. **描述需求**（我会自动匹配）：
   ```
   "用xsjc检查一下我整本小说"
   "帮我把那些重复句式都改掉"
   ```

### 在WorkBuddy中调用
当您说"检查小说"时，我会：
1. 识别到xsjc技能触发
2. 按照SKILL.md定义的8阶段流程执行
3. 输出检查报告 + 整改建议
4. 提供一键整改命令

## 六、常见问题

### Q1：为什么Python脚本在WorkBuddy中无法运行？
**A**：WorkBuddy的Windows ACP模式可能阻止直接运行Python脚本。解决方案：
- 在外部CMD/PowerShell中手动运行
- 将脚本改写为PowerShell版本
- 使用`--dry-run`参数先模拟

### Q2：如何增加新的检测规则？
**A**：编辑`scripts/style_pattern_detector.py`，在`PATTERNS`列表中添加：
```python
{
    'id': 'your_id',
    'name': '句式名称',
    'pattern': r'正则表达式',
    'severity': 'high|medium|low',
    'replacements': ['替换1', '替换2', ...]
}
```

### Q3：如何自定义AI禁词库？
**A**：创建`ai_stop_words.txt`，每行一个词，然后在脚本中加载：
```python
with open('ai_stop_words.txt', 'r', encoding='utf-8') as f:
    stop_words = set(line.strip() for line in f)
```

### Q4：角色声音校验没有结果？
**A**：`voice_validator.py`当前为示例框架，需手动配置角色卡（JSON格式），后续版本将升级为实用工具。

## 七、后续计划（v1.4.0）

- [ ] 创建主控程序`xsjc.py`（统一入口）
- [ ] 扩展句式模板至30+种
- [ ] 角色声音校验升级（支持角色卡JSON）
- [ ] 伏笔追踪增强（TF-IDF算法）
- [ ] 配置文件支持（YAML格式）
- [ ] 添加单元测试

## 八、联系与反馈

- **技能维护**：xsjc技能自动进化系统
- **版本**：1.3.0（2026-05-06）
- **问题反馈**：在WorkBuddy中直接告诉我，我会更新技能

---

**快速开始**：选择一个命令，复制粘贴到终端，立刻体验xsjc的强大功能！
