---
name: token-optimizer
description: Automate token optimization for AI conversations with PERSISTENT activation. Once activated by keywords ("token优化", "save tokens"), stays active for entire session until explicitly deactivated ("关闭token优化", "disable"). Automatically optimizes all responses without re-confirmation. Use for ongoing token savings across multiple conversation turns.
---

# Token Optimizer

## Overview

Automatically optimize AI conversation tokens by analyzing user intent, refining input data, and constraining output format. The goal is to maintain task quality while minimizing token consumption through intelligent compression and filtering.

## Core Capabilities

This skill provides 4 integrated capabilities for token optimization:

### 0. Session Management (NEW)

Manage optimization activation state across conversation.

**Behavior:**
- **Default**: OFF at conversation start
- **Once activated**: Remains ACTIVE for entire session
- **Automatic**: Optimizes every turn without re-confirmation
- **Until**: Explicitly deactivated OR new conversation starts

**Activation workflow:**
```
1. User says: "token优化" / "optimize tokens"
2. Skill activates → persists state to session memory
3. Confirmation: "✅ Token optimization activated for this session"
4. All subsequent turns → automatic optimization
5. User can deactivate: "关闭token优化" / "disable token optimization"
```

**Session state tracking:**
```yaml
session:
  optimization_active: true
  activated_at: "2026-04-03T15:10:00"
  turns_optimized: 5
  total_tokens_saved: 1240
  last_override: null  # if user requested "no optimize" once
```

**Override options:**
- One-time skip: "skip optimization this time" (optimization stays active)
- Full deactivation: "disable token optimization" (optimization turns off)
- New session: Automatic reset to OFF

### 1. Intent Analysis & Task Distillation

Extract core user intent from verbose conversation history and eliminate redundant context.

**When to apply:**
- Conversation history exceeds 10 turns
- User request buried in lengthy context
- Multiple tangential discussions occurred

**Process:**
1. Identify the active task: What is the user asking for RIGHT NOW?
2. Extract essential context: What information is REQUIRED to complete this task?
3. Filter obsolete data: What previous turns are no longer relevant?
4. Distill to single intent statement: "User wants [specific outcome] with [constraints]"

**Example:**
```
Before (500 tokens):
"I've been working on this project for months, and we tried many approaches. 
First we used React, then switched to Vue, but the performance was still bad. 
The team had many meetings about architecture. We hired consultants. 
Eventually we settled on Next.js. Now I need to add a dark mode toggle."

After (80 tokens):
"Add dark mode toggle to existing Next.js project."
```

### 2. Input Optimization

Compress and filter user-provided data while preserving completeness.

**Optimization strategies:**
- Remove duplicate information
- Eliminate decorative language ("I think", "maybe", "possibly")
- Collapse repetitive structures into concise formats
- Extract key-value pairs from verbose descriptions
- Use structured formats (JSON, tables) instead of prose

**Example:**
```
Before (300 tokens):
"I have a list of products. The first product is called iPhone 15 Pro Max, 
it costs $1199, and it's available in black, white, and blue colors. 
The second product is Samsung Galaxy S24 Ultra, priced at $1299, available 
in titanium gray, violet, and yellow. The third product is..."

After (60 tokens):
Products:
1. iPhone 15 Pro Max | $1199 | black/white/blue
2. Samsung Galaxy S24 Ultra | $1299 | gray/violet/yellow
```

**Quality check:**
- Is all REQUIRED information preserved?
- Can the task still be completed without ambiguity?
- Are edge cases still captured?

### 3. Output Constraint

Apply token-saving instructions to AI outputs while maintaining quality.

**Constraint templates:**

| Output Type | Token-Saving Instructions |
|-------------|---------------------------|
| Code | No comments unless critical; use concise variable names; skip boilerplate explanations |
| Explanations | Use bullet points; avoid repetition; limit to 3 key points max |
| Data reports | Show top 10 items; use tables; link to full data if needed |
| Error messages | State problem + solution only; skip diagnostic details |
| Documentation | Use reference format; omit obvious steps; focus on non-obvious |

**Example directive:**
```
"Provide solution with minimal tokens:
- Code: essential logic only, no explanatory comments
- Explanation: max 3 bullet points
- Skip: greetings, confirmations, obvious steps"
```

### 4. Full Pipeline Workflow

Execute all optimization stages in sequence for maximum token efficiency.

**Trigger:** When user explicitly requests "token optimization" or "save tokens"

**Workflow:**

```
Phase 1: Analyze Conversation Context
├─ Identify active task (most recent user request)
├─ Extract required context from history
├─ Mark obsolete turns for compression
└─ Distill intent to single statement

Phase 2: Optimize Input Data
├─ Detect redundant information
├─ Apply compression strategies
├─ Validate completeness
└─ Format for efficiency

Phase 3: Apply Output Constraints
├─ Determine output type
├─ Load constraint template
├─ Inject token-saving instructions
└─ Set quality thresholds

Phase 4: Execute with Optimization
├─ Use optimized context
├─ Apply constraints during generation
└─ Monitor token usage vs quality

Phase 5: Validate & Report
├─ Check task completion
├─ Measure token savings
└─ Adjust if quality degraded
```

## Usage Examples

### Example 1: Activate Optimization (Persistent)

**User request:** "token优化"

**Response:**
```
✅ Token optimization activated for this session.
   Will automatically optimize all subsequent responses.
   Deactivate anytime by saying: "关闭token优化" or "disable token optimization"

   Optimizing:
   ✓ Conversation history compression
   ✓ Input data filtering
   ✓ Output token constraints

   Ready for next request...
```

### Example 2: Automatic Optimization After Activation

**User request (with optimization active):** "Fix the login bug in auth.js"

**Response (automatically optimized):**
```
[Optimized context applied]

Active task: Fix login bug in auth.js
Required: Error message, auth.js snippet, env details

Solution:
1. Check auth token expiration logic (line 45)
2. Add refresh token fallback
3. Update session timeout to 30min

Tokens saved: ~40% vs full response
```

### Example 3: Deactivate Optimization

**User request:** "关闭token优化"

**Response:**
```
❌ Token optimization deactivated.
   Will provide full detailed responses going forward.
   Reactivate by saying: "token优化" or "optimize tokens"
```

### Example 4: One-time Override

**User request (with optimization active):** "Generate complete API documentation without optimization"

**Response:**
```
[Optimization skipped for this request]

## API Documentation

[Full detailed documentation...]

Note: Provided full detail as requested. Optimization remains active for other requests.
```

### Example 5: Optimize Long Conversation

**User request:** "We've been discussing this for 20 turns, optimize tokens"

**Response:**
```
Analyzing conversation...

✅ Active task identified: "Fix login bug in auth.js"
✅ Required context: Error message, auth.js snippet, environment details
✅ Obsolete turns compressed: 15 turns → 3 key points

Token savings: 2,340 tokens (62% reduction)
Quality impact: None - all essential information preserved

✅ Token optimization now active for this session.
   Deactivate: "关闭token优化"

Optimized context ready. Proceeding with task...
```

### Example 2: Compress Input Data

**User request:** "Optimize this input: [verbose product list]"

**Response:**
```
Input compressed:
[Structured table format]

Tokens: 450 → 120 (73% saved)
Completeness: 100% - all products, prices, colors preserved
```

### Example 3: Apply Output Constraints

**User request:** "Generate code but save tokens"

**Response:**
```
Output constraints applied:
✓ Essential code only (no comments)
✓ Concise naming
✓ No boilerplate
✓ Max 3 key points for explanation

Estimated token savings: 40-60%
```

## Token Saving Estimates

| Optimization Type | Typical Savings | Quality Impact |
|-------------------|-----------------|----------------|
| Intent distillation | 50-70% | Low risk |
| Input compression | 40-75% | Low risk with validation |
| Output constraints | 30-60% | Medium risk (requires testing) |
| Full pipeline | 60-80% | Low risk if validated |

## Best Practices

1. **Always validate completeness** - Never sacrifice task success for token savings
2. **Test constraints incrementally** - Start conservative, increase compression
3. **Preserve edge cases** - Compress common patterns, keep rare scenarios
4. **Use structured formats** - Tables, JSON, YAML save more tokens than prose
5. **Measure, don't guess** - Track token usage before/after optimization
6. **Document savings** - Report token metrics to user for transparency

## Anti-Patterns to Avoid

❌ Removing critical error handling code to save tokens
❌ Compressing security-sensitive data (credentials, keys)
❌ Eliminating user preferences or constraints
❌ Over-compressing to the point of ambiguity
❌ Skipping validation steps

## Integration Notes

### Activation & Deactivation

**Activation (default OFF):**
Once activated, this skill remains enabled for the entire conversation session unless explicitly deactivated.

**How to activate:**
- User explicitly requests optimization: "optimize tokens", "token优化", "save tokens"
- User loads the skill via skill selection menu
- Conversation exceeds threshold (if configured in `references/config.md`)

**Persistence:**
- ✅ Activates once, applies to ALL subsequent turns in the session
- ✅ Automatically applies optimization without re-confirmation each turn
- ✅ Continues until end of conversation session OR user explicitly deactivates

**Deactivation:**
- User explicitly requests: "disable token optimization", "关闭token优化", "stop token saving"
- User removes the skill from loaded skills
- New conversation session starts (reset to default OFF)

**Deactivation keywords:**
- English: "disable token optimization", "stop optimizing", "turn off token saving", "cancel optimization"
- Chinese: "关闭token优化", "停止优化", "取消token节约", "关闭优化"

**Behavior when active:**
```
Turn N (activation requested):
  User: "optimize tokens"
  AI: [Activates token-optimizer]
      "✅ Token optimization activated. Will optimize all subsequent responses.
       Deactivate anytime by saying '关闭token优化'"

Turn N+1 (automatic optimization):
  User: [any request]
  AI: [Applies optimization automatically without confirmation]

Turn N+2 (automatic optimization):
  User: [any request]
  AI: [Applies optimization automatically without confirmation]

Turn N+3 (deactivation):
  User: "关闭token优化"
  AI: "❌ Token optimization deactivated."
```

### Manual Override

Even when token optimization is active, user can request NO optimization for specific requests:

**Keywords to skip optimization for ONE response only:**
- "no optimize this", "don't optimize", "full detail", "完整输出"
- "skip optimization", "disable optimization for this", "这次不优化"

**Example:**
```
Turn N+4 (active, but user wants full detail):
  User: "Generate full documentation without optimization"
  AI: [Produces detailed output without compression]
      "Provided full detail (optimization skipped for this request)"
```

### Configuration Override

For automated invocation, set token threshold in `references/config.md`.

**Session-level settings:**
```yaml
session_config:
  optimization_mode: "auto"  # auto, manual, off
  user_preference: "conserve"  # conserve, balance, quality
  persistent: true  # If true, stays active until deactivated
```

## Resources

### references/config.md
Configuration for automated optimization thresholds and rules.

### references/optimization_rules.md
Detailed compression strategies and token-saving patterns for different data types.

### scripts/validate_completeness.py
Validate that optimized input maintains task completeness. Run before finalizing optimization.
