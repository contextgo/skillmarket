# Token Optimizer - 快速开始指南

## 什么是 Token Optimizer?

Token Optimizer 是一个自动化技能,可以在 AI 对话中智能地节约 token 使用量,同时保持输出质量。

## 核心特性

### ✅ 持久化激活 (最重要)

**一次激活,全程生效!**

- 激活后,整个对话会话中的所有回复都会自动优化
- 无需每轮对话重复确认
- 直到你主动关闭或开始新对话

## 使用方法

### 1. 激活优化

说以下任意关键词即可激活:

**中文:**
- "token优化"
- "节约token"
- "压缩对话"
- "优化输入输出"

**英文:**
- "optimize tokens"
- "save tokens"
- "reduce context"
- "compress conversation"

**激活后你会看到:**
```
✅ Token optimization activated for this session.
   Will automatically optimize all subsequent responses.
   Deactivate anytime by saying: "关闭token优化"
```

### 2. 正常对话

激活后,你的所有后续请求都会自动优化,无需额外操作。

**示例:**
```
用户: token优化
AI: ✅ Token optimization activated...

用户: 帮我写一个登录功能的代码
AI: [自动优化后的代码,节省 40-60% token]

用户: 解释一下数据库连接池的原理
AI: [自动优化后的解释,使用简洁格式]

用户: 生成一个用户列表报告
AI: [自动优化后的报告,只显示关键信息]
```

### 3. 关闭优化

如果你想恢复完整详细输出,可以说:

**中文:**
- "关闭token优化"
- "停止优化"
- "取消token节约"

**英文:**
- "disable token optimization"
- "stop optimizing"
- "turn off token saving"

**关闭后你会看到:**
```
❌ Token optimization deactivated.
   Will provide full detailed responses going forward.
```

### 4. 一次跳过 (可选)

如果你只是想在某次请求中不优化,但保持优化激活:

**中文:**
- "这次不优化"
- "不要优化这个"
- "完整输出"

**英文:**
- "no optimize this"
- "don't optimize"
- "full detail"
- "skip optimization"

**示例:**
```
用户: [已激活优化]
AI: [优化回复中...]

用户: 这次不优化,给我完整的API文档
AI: [完整详细的文档,未优化]
   Note: Provided full detail as requested. 
         Optimization remains active for other requests.
```

## 节约效果

根据任务类型,预期节约:

| 优化类型 | 节约比例 | 风险等级 |
|---------|---------|---------|
| 意图提炼 | 50-70% | 低 |
| 输入压缩 | 40-75% | 低 (有验证) |
| 输出约束 | 30-60% | 中 (需要测试) |
| **完整流程** | **60-80%** | **低 (如果验证通过)** |

## 实际应用场景

### 场景 1: 长对话历史压缩

**问题:** 你和 AI 讨论了很久,对话历史很长,token 消耗大

**解决:** 
1. 说 "token优化"
2. AI 会自动压缩历史对话,只保留关键信息
3. 后续对话继续使用优化后的上下文

### 场景 2: 批量代码生成

**问题:** 需要生成多个相似功能的代码文件

**解决:**
1. 说 "token优化"
2. 逐个请求代码,每次都自动优化输出
3. 节省大量 token,代码质量不受影响

### 场景 3: 数据报告生成

**问题:** 需要生成大量数据报表和统计

**解决:**
1. 说 "token优化"
2. AI 会自动:
   - 只显示前 10 条记录
   - 使用表格代替列表
   - 提供完整数据的链接或附件
3. 大幅节省 token

### 场景 4: 文档和说明

**问题:** 需要很多技术文档和说明文字

**解决:**
1. 说 "token优化"
2. AI 会自动:
   - 使用要点列表
   - 链接到参考资料而非重复内容
   - 只说明非显而易见的步骤
3. 简洁但完整

## 质量保证

不用担心优化会影响质量:

✅ **完整性验证** - 自动检查关键信息是否保留
✅ **质量阈值** - 最低保持 95% 完整性
✅ **边缘情况** - 保留所有特殊情况的处理
✅ **人工控制** - 可以随时关闭或跳过优化

## 最佳实践

1. **激活时机:** 对话开始时或发现 token 使用过多时激活
2. **关闭时机:** 需要详细解释、调试信息或完整文档时关闭
3. **灵活使用:** 普通请求用优化,特殊请求用"一次跳过"
4. **监控效果:** 观察优化前后的 token 节约情况
5. **反馈调整:** 如果优化过度,可以调整配置参数

## 常见问题

### Q: 优化会影响代码运行吗?
**A:** 不会。代码优化只是去掉注释、使用更简洁的变量名、压缩结构,不改变逻辑。

### Q: 可以只优化输入不优化输出吗?
**A:** 目前是统一优化,但可以通过"一次跳过"功能控制单次输出。

### Q: 新对话会保持优化激活吗?
**A:** 不会。每次新对话都会重置为未激活状态,需要重新激活。

### Q: 优化后信息不完整怎么办?
**A:** 使用"一次跳过"功能,说"完整输出",AI 会提供完整信息。

### Q: 多长时间激活一次合适?
**A:** 建议:
   - 短对话 (<10 轮): 不需要激活
   - 中等对话 (10-30 轮): 中途激活一次
   - 长对话 (>30 轮): 尽早激活

## 配置选项 (高级)

如果需要自定义,可以编辑 `config.md`:

```yaml
user_preferences:
  optimization_level: moderate    # conservative | moderate | aggressive
  quality_priority: high         # high | medium | low
  persistent_mode: true         # 激活后持续生效
  max_compression: 0.75         # 最大压缩比例
```

## 技术支持

如果遇到问题:
1. 尝试关闭优化再重新激活
2. 检查技能是否正确加载
3. 查看工作日志: `~/.workbuddy/skills/token-optimizer/`

## 开始使用

现在就试试吧!

```
你: token优化
AI: ✅ Token optimization activated for this session...
```

然后继续你的对话,你会发现 token 使用量明显减少! 🚀
