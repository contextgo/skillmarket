#!/usr/bin/env python3
"""
Validate that optimized input maintains task completeness.

Usage:
    python validate_completeness.py <original_file> <optimized_file>

Exit codes:
    0 - Validation passed
    1 - Validation failed
    2 - Error (file not found, etc.)
"""

import sys
import json
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple


class CompletenessValidator:
    """Validates that optimized content maintains required information."""
    
    def __init__(self, completeness_threshold: float = 0.95):
        """
        Initialize validator.
        
        Args:
            completeness_threshold: Minimum completeness score (0.0-1.0)
        """
        self.threshold = completeness_threshold
        self.required_patterns = [
            r'\b\d+\b',  # Numbers
            r'\b[A-Z]{2,}\b',  # Acronyms
            r'\b\w+@\w+\.\w+\b',  # Emails
            r'https?://\S+',  # URLs
            r'\$\d+',  # Prices
            r'\b\d{4}-\d{2}-\d{2}\b',  # Dates
        ]
    
    def extract_key_entities(self, text: str) -> Dict[str, Set[str]]:
        """
        Extract key entities from text.
        
        Returns:
            Dictionary with entity types as keys and sets of entities as values
        """
        entities = {
            'numbers': set(),
            'acronyms': set(),
            'emails': set(),
            'urls': set(),
            'prices': set(),
            'dates': set(),
            'keywords': set()
        }
        
        # Extract numbers
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', text)
        entities['numbers'].update(numbers)
        
        # Extract acronyms
        acronyms = re.findall(r'\b[A-Z]{2,}\b', text)
        entities['acronyms'].update(acronyms)
        
        # Extract emails
        emails = re.findall(r'\b\w+@\w+\.\w+\b', text)
        entities['emails'].update(emails)
        
        # Extract URLs
        urls = re.findall(r'https?://\S+', text)
        entities['urls'].update(urls)
        
        # Extract prices
        prices = re.findall(r'\$[\d,]+(?:\.\d{2})?', text)
        entities['prices'].update(prices)
        
        # Extract dates
        dates = re.findall(r'\b\d{4}-\d{2}-\d{2}\b', text)
        entities['dates'].update(dates)
        
        # Extract keywords (important words)
        keywords = re.findall(r'\b[A-Z][a-z]+\b', text)
        entities['keywords'].update(keywords)
        
        return entities
    
    def calculate_completeness(
        self, 
        original: str, 
        optimized: str
    ) -> Tuple[float, Dict]:
        """
        Calculate completeness score between original and optimized text.
        
        Returns:
            Tuple of (score, details) where score is 0.0-1.0
        """
        original_entities = self.extract_key_entities(original)
        optimized_entities = self.extract_key_entities(optimized)
        
        details = {}
        total_score = 0.0
        total_weight = 0.0
        
        # Weight different entity types
        weights = {
            'numbers': 2.0,
            'acronyms': 1.5,
            'emails': 3.0,
            'urls': 3.0,
            'prices': 2.5,
            'dates': 2.0,
            'keywords': 1.0
        }
        
        for entity_type, weight in weights.items():
            original_set = original_entities[entity_type]
            optimized_set = optimized_entities[entity_type]
            
            if len(original_set) == 0:
                # No entities of this type in original
                details[entity_type] = {
                    'score': 1.0,
                    'original_count': 0,
                    'optimized_count': 0,
                    'missing': []
                }
            else:
                # Calculate retention rate
                retained = original_set & optimized_set
                missing = original_set - optimized_set
                score = len(retained) / len(original_set)
                
                details[entity_type] = {
                    'score': score,
                    'original_count': len(original_set),
                    'optimized_count': len(optimized_set),
                    'missing': list(missing)[:5]  # Show max 5 missing
                }
            
            total_score += details[entity_type]['score'] * weight
            total_weight += weight
        
        final_score = total_score / total_weight if total_weight > 0 else 1.0
        
        return final_score, details
    
    def validate(self, original: str, optimized: str) -> Tuple[bool, Dict]:
        """
        Validate that optimized text meets completeness threshold.
        
        Returns:
            Tuple of (is_valid, report)
        """
        score, details = self.calculate_completeness(original, optimized)
        
        report = {
            'completeness_score': score,
            'threshold': self.threshold,
            'is_valid': score >= self.threshold,
            'details': details,
            'recommendations': []
        }
        
        # Generate recommendations for failed entity types
        for entity_type, info in details.items():
            if info['score'] < 1.0 and info['missing']:
                report['recommendations'].append(
                    f"Missing {entity_type}: {', '.join(str(m) for m in info['missing'][:3])}"
                )
        
        return report['is_valid'], report


def load_file(filepath: str) -> str:
    """Load file content."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    return path.read_text(encoding='utf-8')


def main():
    """Main entry point."""
    if len(sys.argv) < 3:
        print("Usage: python validate_completeness.py <original_file> <optimized_file>")
        print("\nExit codes:")
        print("  0 - Validation passed")
        print("  1 - Validation failed")
        print("  2 - Error")
        sys.exit(2)
    
    original_file = sys.argv[1]
    optimized_file = sys.argv[2]
    
    try:
        original_text = load_file(original_file)
        optimized_text = load_file(optimized_file)
        
        validator = CompletenessValidator(completeness_threshold=0.95)
        is_valid, report = validator.validate(original_text, optimized_text)
        
        # Print report
        print("=" * 60)
        print("COMPLETENESS VALIDATION REPORT")
        print("=" * 60)
        print(f"\nOverall Score: {report['completeness_score']:.2%}")
        print(f"Threshold: {report['threshold']:.2%}")
        print(f"Status: {'✅ PASSED' if is_valid else '❌ FAILED'}")
        
        print("\n" + "-" * 60)
        print("ENTITY RETENTION DETAILS:")
        print("-" * 60)
        
        for entity_type, info in report['details'].items():
            status = "✓" if info['score'] >= 0.95 else "⚠"
            print(f"\n{status} {entity_type.upper()}:")
            print(f"  Original: {info['original_count']} items")
            print(f"  Optimized: {info['optimized_count']} items")
            print(f"  Retention: {info['score']:.1%}")
            if info['missing']:
                print(f"  Missing: {info['missing'][:3]}")
        
        if report['recommendations']:
            print("\n" + "-" * 60)
            print("RECOMMENDATIONS:")
            print("-" * 60)
            for rec in report['recommendations']:
                print(f"  • {rec}")
        
        print("\n" + "=" * 60)
        
        sys.exit(0 if is_valid else 1)
        
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(2)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(2)


if __name__ == '__main__':
    main()
