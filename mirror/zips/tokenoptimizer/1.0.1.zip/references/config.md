# Token Optimization Configuration

## Automated Optimization Thresholds

Configure when token optimization should trigger automatically.

### Conversation Length Thresholds

| Metric | Threshold | Action |
|--------|-----------|--------|
| Conversation turns | > 15 turns | Trigger intent analysis |
| Context window usage | > 70% | Trigger compression |
| Redundant content | > 30% repetition | Trigger input optimization |
| Token per turn ratio | > 500 tokens/turn | Suggest optimization to user |

### Optimization Rules

#### Automatic Compression Rules

1. **History Compression**
   - Keep last 5 turns in full
   - Compress turns 6-10 to summaries (1 sentence each)
   - Archive turns 11+ to intent-only (topic + outcome)

2. **Context Pruning**
   - Remove confirmed solved problems
   - Remove abandoned approaches
   - Keep active constraints and requirements
   - Keep error states and current blockers

3. **Input Validation**
   - Maximum input compression: 75%
   - Minimum completeness score: 95%
   - Required fields never removed

#### Output Constraint Rules

1. **Code Outputs**
   - Remove decorative comments (keep TODO, FIXME, WARNING)
   - Use single-letter variables in short functions (< 10 lines)
   - Omit obvious error handling (null checks, type checks) if pattern is clear
   - Keep critical security checks

2. **Explanation Outputs**
   - Maximum 3 bullet points per concept
   - No repeated information
   - Link to references instead of inline documentation
   - Skip "as mentioned earlier" phrases

3. **Data Reports**
   - Top 10 items in main report
   - Full data in separate artifact file
   - Aggregate statistics preferred over raw lists
   - Use compact table formats

### Quality Thresholds

Minimum quality requirements after optimization:

| Output Type | Min Quality Score | Validation Method |
|-------------|------------------|-------------------|
| Code | 95% | Run completeness validator |
| Explanations | 90% | Manual check of key points |
| Data | 100% | Validate all required fields present |
| Documentation | 85% | Peer review checklist |

### Language-Specific Rules

#### Chinese (中文)
- Remove polite phrases (请, 您, 麻烦)
- Compress repetitive honorifics
- Use technical terms directly without explanation

#### English
- Remove hedge words (I think, maybe, possibly)
- Prefer active voice (saves 10-20% tokens)
- Use contractions (don't, can't, won't)

### Integration Hooks

Configure optimization to trigger before:

```yaml
hooks:
  before_api_call:
    - check_token_usage
    - optimize_if_needed
  before_long_task:
    - analyze_intent
    - compress_history
  after_user_message:
    - detect_redundancy
    - suggest_optimization
```

### User Preferences

Store user-specific optimization preferences:

```yaml
user_preferences:
  optimization_level: moderate  # conservative | moderate | aggressive
  quality_priority: high        # high | medium | low
  auto_optimize: true           # true | false
  
  # NEW: Persistence settings
  persistent_mode: true         # true = once activated, stays active until deactivated
                               # false = must reactivate each turn
  
  # Optimization behavior when persistent
  apply_to_all_turns: true      # true = optimize every turn once activated
                               # false = ask before each optimization
  
  # Allow one-time override
  allow_override: true          # true = user can say "no optimize" for one response
                               # false = strict optimization when active
  
  max_compression: 0.75         # 0.0 - 1.0
  language: auto                # auto | zh | en
```

### Session State Management

Track optimization state across conversation turns:

```yaml
session_state:
  # Current status
  is_active: false              # Is optimization currently active?
  activated_at: null            # When was it activated (timestamp)?
  deactivated_at: null          # When was it deactivated (timestamp)?
  
  # Statistics
  total_turns_optimized: 0     # How many turns were optimized
  total_tokens_saved: 0         # Cumulative tokens saved
  average_savings_percent: 0.0   # Average % saved per turn
  
  # Last optimization
  last_optimization_type: null  # input | output | full_pipeline
  last_savings: 0               # Tokens saved in last optimization
```

### Activation/Deactivation Triggers

**Activation keywords:**
- English: "optimize tokens", "token optimization", "save tokens", "reduce context", "compress conversation"
- Chinese: "token优化", "节约token", "压缩对话", "优化输入输出", "token节约"

**Deactivation keywords:**
- English: "disable token optimization", "stop optimizing", "turn off token saving", "cancel optimization"
- Chinese: "关闭token优化", "停止优化", "取消token节约", "关闭优化"

**One-time override keywords:**
- English: "no optimize this", "don't optimize", "full detail", "skip optimization"
- Chinese: "这次不优化", "不要优化这个", "完整输出", "跳过优化"

### Metrics Tracking

Track optimization effectiveness:

```python
metrics_to_track = [
    "tokens_saved_per_session",
    "compression_ratio",
    "quality_score_post_optimization",
    "user_satisfaction_rating",
    "task_success_rate"
]
```

Store metrics in: `~/.workbuddy/skills/token-optimizer/metrics.json`
