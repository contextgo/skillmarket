# Token Optimization Rules & Patterns

Comprehensive guide for compressing different data types while maintaining completeness.

## Text Compression Patterns

### 1. Prose to Structured Format

**Pattern:** Convert verbose paragraphs to tables, lists, or key-value pairs.

**Example:**
```
Before (150 tokens):
The system has three main components. The first component is the user interface, 
which handles all user interactions and displays results. It's built with React 
and uses Material-UI for styling. The second component is the backend API, which 
processes business logic and communicates with the database. It's written in 
Python using Flask framework. The third component is the database, which stores 
all user data and application state. We use PostgreSQL for relational data and 
Redis for caching.

After (45 tokens):
Components:
1. UI (React + Material-UI): user interaction, display
2. API (Python/Flask): business logic, DB communication
3. Database (PostgreSQL + Redis): storage, caching

Savings: 70%
```

### 2. Remove Redundancy

**Pattern:** Eliminate repeated information, synonyms, and rephrased content.

**Example:**
```
Before (80 tokens):
I need to implement a feature for user authentication. The feature should allow 
users to log in and log out. Users should be able to authenticate themselves 
using their credentials. The authentication system must verify user identity.

After (25 tokens):
Implement user authentication: login/logout with credential verification.

Savings: 69%
```

### 3. Strip Decorative Language

**Pattern:** Remove filler words, hedging, and politeness markers.

**Common filler words to remove:**
- **English**: "I think", "maybe", "possibly", "just", "actually", "basically", "quite", "really"
- **中文**: "我想", "可能", "基本上", "其实", "然后", "就是", "的话"

**Example:**
```
Before (40 tokens):
I think we should probably just add a simple validation function to check if 
the input is valid or not.

After (15 tokens):
Add validation function to check input validity.

Savings: 63%
```

## Code Compression Patterns

### 1. Remove Non-Critical Comments

**Keep these comments:**
- TODO, FIXME, WARNING, HACK
- Non-obvious business logic explanations
- Security implications
- API contracts

**Remove these comments:**
- Obvious what-code-does explanations
- Inline documentation for standard libraries
- Decorative section dividers

**Example:**
```
Before (120 tokens):
# Function to calculate total price
def calculate_total(items):
    # Initialize total to zero
    total = 0
    
    # Loop through each item
    for item in items:
        # Add item price to total
        total += item.price
    
    # Return the total
    return total

After (40 tokens):
def calculate_total(items):
    total = 0
    for item in items:
        total += item.price
    return total

Savings: 67%
```

### 2. Use Concise Naming

**Pattern:** Use shorter names in small scopes, descriptive names in large scopes.

**Example:**
```
Before (100 tokens):
def calculate_monthly_user_subscription_price(user_subscription_object):
    base_price_amount = user_subscription_object.base_price
    discount_percentage = user_subscription_object.discount
    final_price_amount = base_price_amount * (1 - discount_percentage)
    return final_price_amount

After (55 tokens):
def calc_monthly_price(sub):
    base = sub.base_price
    discount = sub.discount
    return base * (1 - discount)

Savings: 45%
```

### 3. Collapse Boilerplate

**Pattern:** Use idiomatic constructs to reduce boilerplate code.

**Example:**
```
Before (80 tokens):
result_list = []
for item in input_list:
    if item.is_valid:
        result_list.append(item.value)

After (30 tokens):
result = [item.value for item in input_list if item.is_valid]

Savings: 63%
```

## Data Compression Patterns

### 1. Top-N with Overflow Reference

**Pattern:** Show limited items inline, reference full dataset.

**Example:**
```
Before (200 tokens - showing 5 products):
Products:
1. iPhone 15 Pro Max | $1199 | black/white/blue | In Stock
2. Samsung Galaxy S24 Ultra | $1299 | gray/violet/yellow | In Stock
3. Google Pixel 8 Pro | $999 | black/white | Low Stock
4. OnePlus 12 | $799 | black/green | In Stock
5. Xiaomi 14 Pro | $899 | black/white/green | In Stock
[... 45 more products]

After (60 tokens):
Top 5 Products (see full_list.json for 50 items):
iPhone 15 Pro Max | $1199
Samsung S24 Ultra | $1299
Pixel 8 Pro | $999
OnePlus 12 | $799
Xiaomi 14 Pro | $899

Savings: 70%
```

### 2. Aggregate Instead of Enumerate

**Pattern:** Use statistics instead of raw data lists.

**Example:**
```
Before (300 tokens):
User engagement data:
2024-01-01: 1234 users
2024-01-02: 1456 users
2024-01-03: 1389 users
[... 30 more daily entries]

After (50 tokens):
User Engagement (Jan 2024):
- Total: 45,230 users
- Daily avg: 1,459 users
- Peak: Jan 15 (1,892 users)
- Low: Jan 31 (1,102 users)

Savings: 83%
```

### 3. Hierarchical Summaries

**Pattern:** Provide overview with drill-down on demand.

**Example:**
```
Before (500 tokens):
[Full detailed error log with stack traces for 20 errors]

After (80 tokens):
Errors (20 total):
├─ Auth failures: 12 (see auth_errors.log)
├─ DB timeouts: 5 (see db_errors.log)
└─ API errors: 3 (see api_errors.log)

Common fix: Check network connectivity and DB connection pool.

Savings: 84%
```

## Conversation History Compression

### Turn-Level Compression

**Pattern:** Summarize past turns, keep recent turns detailed.

**Rules:**
- Turns 1-5 (most recent): Keep in full
- Turns 6-10: Summarize to 1 sentence
- Turns 11+: Record as "Topic: [topic], Outcome: [result]"

**Example:**
```
Before (1500 tokens for 12 turns):
[Full conversation history...]

After (400 tokens):
Recent turns (1-5):
[Full content preserved]

Earlier turns (6-10):
- Discussed architecture options → chose microservices
- Explored database choices → selected PostgreSQL
- Reviewed caching strategies → implemented Redis

Archived turns (11-12):
- Turn 11: Project kickoff → approved timeline
- Turn 12: Team assignment → roles defined

Savings: 73%
```

### Context Pruning

**Pattern:** Remove obsolete information from context.

**Remove when:**
- Problem was solved and confirmed
- Approach was abandoned
- Information is tangential to current task

**Keep when:**
- Active constraints (time, budget, tech stack)
- Unresolved blockers
- User preferences and requirements
- Error states currently being debugged

## Output Constraint Patterns

### 1. Bullet Point Limits

**Pattern:** Limit explanation depth to force conciseness.

**Template:**
```
Max bullet points: 3
Max sub-bullets: 2 per bullet
Max sentence length: 20 words
```

### 2. Reference-Based Documentation

**Pattern:** Link to external docs instead of inline explanation.

**Example:**
```
Before (200 tokens):
To install the package, first make sure you have Node.js version 18 or higher 
installed. Then run npm install to install dependencies. After that, you can 
run npm start to start the development server. The server will start on port 
3000 by default, but you can change this in the config file...

After (30 tokens):
Installation: see docs/installation.md
Configuration: see docs/config.md
Quick start: npm install && npm start

Savings: 85%
```

### 3. Progressive Disclosure

**Pattern:** Start with summary, offer details on request.

**Example:**
```
Summary (always shown):
✓ Solution implemented
✓ Tests passing
⚠️ Performance degraded 5%

Details (on request):
- Changed auth flow from sync to async
- Added caching layer for user data
- Updated 15 files, +234 lines, -189 lines
```

## Validation Rules

After compression, validate:

1. **Completeness Check**
   - All required fields present
   - All constraints captured
   - All edge cases documented

2. **Ambiguity Check**
   - No information loss that creates ambiguity
   - References are accessible and clear
   - Technical terms remain unambiguous

3. **Quality Check**
   - Task can still be completed
   - No critical errors introduced
   - User intent preserved

## Language-Specific Rules

### Chinese Optimization

**Remove:**
- Polite phrases: 请, 您, 麻烦, 不好意思
- Redundant honorifics
- Repetitive structure words: 的话, 这个, 那个

**Compress:**
- 多个 → 多
- 进行 → (remove in most contexts)
- 能够 → 可

**Example:**
```
Before (60 tokens):
请您帮我检查一下这个代码的话,我想可能是会有一些问题的,麻烦您看一下的话。

After (20 tokens):
请检查代码是否有问题。

Savings: 67%
```

### English Optimization

**Remove:**
- Hedge words: I think, maybe, possibly, sort of, kind of
- Filler: just, actually, basically, really, quite
- Passive voice constructions

**Compress:**
- In order to → to
- At this point in time → now
- Due to the fact that → because

**Example:**
```
Before (50 tokens):
I think that we should probably just refactor this function in order to make 
it more readable.

After (20 tokens):
Refactor function for readability.

Savings: 60%
```
