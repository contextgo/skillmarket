#!/usr/bin/env python3
"""Bridge JHora-flavored markdown exports into structured chart payloads."""

from __future__ import annotations

import json
import html
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

SIGN_MAP = {
    "Ar": "Aries",
    "Ta": "Taurus",
    "Ge": "Gemini",
    "Cn": "Cancer",
    "Le": "Leo",
    "Vi": "Virgo",
    "Li": "Libra",
    "Sc": "Scorpio",
    "Sg": "Sagittarius",
    "Cp": "Capricorn",
    "Aq": "Aquarius",
    "Pi": "Pisces",
}

SIGN_ORDER = list(SIGN_MAP.values())

NAKSHATRA_MAP = {
    "Ashw": "Ashwini",
    "Ashv": "Ashwini",
    "Bhar": "Bharani",
    "Krit": "Krittika",
    "Rohi": "Rohini",
    "Mrig": "Mrigashira",
    "Ardr": "Ardra",
    "Puna": "Punarvasu",
    "Push": "Pushya",
    "Asre": "Ashlesha",
    "Magh": "Magha",
    "PPha": "Purva Phalguni",
    "UPha": "Uttara Phalguni",
    "Hasta": "Hasta",
    "Hast": "Hasta",
    "Chit": "Chitra",
    "Swat": "Swati",
    "Visa": "Vishakha",
    "Vish": "Vishakha",
    "Anu": "Anuradha",
    "Jye": "Jyeshtha",
    "Mula": "Mula",
    "PSha": "Purva Ashadha",
    "USha": "Uttara Ashadha",
    "Srav": "Shravana",
    "Dhan": "Dhanishta",
    "Sata": "Shatabhisha",
    "PBha": "Purva Bhadrapada",
    "UBha": "Uttara Bhadrapada",
    "Reva": "Revati",
}

PLANET_NAME_MAP = {
    "Sun": "Sun",
    "Moon": "Moon",
    "Mars": "Mars",
    "Mercury": "Mercury",
    "Merc": "Mercury",
    "Jupiter": "Jupiter",
    "Jup": "Jupiter",
    "Venus": "Venus",
    "Ven": "Venus",
    "Saturn": "Saturn",
    "Rahu": "Rahu",
    "Ketu": "Ketu",
    "Su": "Sun",
    "Mo": "Moon",
    "Ma": "Mars",
    "Me": "Mercury",
    "Ju": "Jupiter",
    "Ve": "Venus",
    "Sat": "Saturn",
    "Sa": "Saturn",
    "Rah": "Rahu",
    "Ra": "Rahu",
    "Ket": "Ketu",
    "Ke": "Ketu",
}

MAHADASHA_SEQUENCE = ["Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury", "Ketu", "Venus"]


class _TableCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[dict[str, int | str]]]] = []
        self._current_table: list[list[dict[str, int | str]]] | None = None
        self._current_row: list[dict[str, int | str]] | None = None
        self._current_cell: dict[str, int | str] | None = None
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_map = {key: value for key, value in attrs}
        if tag == "table":
            self._current_table = []
        elif tag == "tr" and self._current_table is not None:
            self._current_row = []
        elif tag == "td" and self._current_row is not None:
            self._current_cell = {
                "text": "",
                "rowspan": int(attrs_map.get("rowspan") or "1"),
                "colspan": int(attrs_map.get("colspan") or "1"),
            }
            self._parts = []

    def handle_endtag(self, tag: str) -> None:
        if tag == "td" and self._current_cell is not None and self._current_row is not None:
            self._current_cell["text"] = _clean_text("".join(self._parts))
            self._current_row.append(self._current_cell)
            self._current_cell = None
        elif tag == "tr" and self._current_row is not None and self._current_table is not None:
            self._current_table.append(self._current_row)
            self._current_row = None
        elif tag == "table" and self._current_table is not None:
            self.tables.append(self._current_table)
            self._current_table = None

    def handle_data(self, data: str) -> None:
        if self._current_cell is not None:
            self._parts.append(data)


def _clean_text(value: str) -> str:
    value = html.unescape(value)
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def _expand_grid(rows: list[list[dict[str, int | str]]]) -> list[list[str]]:
    grid: list[list[str]] = []
    carry: list[dict[str, Any] | None] = []
    for row in rows:
        expanded: list[str] = []
        col = 0
        while col < len(carry):
            carry_cell = carry[col]
            if carry_cell is not None:
                expanded.append(carry_cell["text"])
                carry_cell["remaining"] -= 1
                if carry_cell["remaining"] <= 0:
                    carry[col] = None
            else:
                expanded.append("")
            col += 1

        write_col = 0
        for cell in row:
            while write_col < len(expanded) and expanded[write_col] != "":
                write_col += 1
            text = str(cell["text"])
            rowspan = int(cell["rowspan"])
            colspan = int(cell["colspan"])
            while len(expanded) < write_col + colspan:
                expanded.append("")
            while len(carry) < write_col + colspan:
                carry.append(None)
            for offset in range(colspan):
                expanded[write_col + offset] = text
                if rowspan > 1:
                    carry[write_col + offset] = {"text": text, "remaining": rowspan - 1}
            write_col += colspan
        grid.append(expanded)

    while carry and any(item is not None for item in carry):
        expanded = []
        for idx, carry_cell in enumerate(carry):
            if carry_cell is None:
                expanded.append("")
                continue
            expanded.append(carry_cell["text"])
            carry_cell["remaining"] -= 1
            if carry_cell["remaining"] <= 0:
                carry[idx] = None
        grid.append(expanded)
    return grid


def _planet_name(label: str) -> str | None:
    head = _clean_text(label.split("-")[0])
    head = re.sub(r"\([^)]*\)", "", head).strip()
    return PLANET_NAME_MAP.get(head)


def _planet_karaka(label: str) -> str | None:
    parts = label.split("-", 1)
    if len(parts) < 2:
        return None
    karaka = _clean_text(parts[1])
    karaka = karaka.replace("(R)", "").strip()
    return karaka or None


def _parse_degree(parts: list[str]) -> tuple[str, float]:
    if len(parts) < 3:
        raise ValueError(f"Unexpected longitude cells: {parts!r}")
    sign_match = re.match(r"(?P<deg>\d+(?:\.\d+)?)\s*(?P<sign>[A-Za-z]{2})", parts[0])
    if not sign_match:
        raise ValueError(f"Could not parse longitude head: {parts[0]!r}")
    sign_code = sign_match.group("sign")
    if sign_code not in SIGN_MAP:
        raise ValueError(f"Unknown sign code: {sign_code!r}")
    deg = float(sign_match.group("deg"))
    minutes = float(re.sub(r"[^\d.]+", "", parts[1]) or "0")
    seconds = float(re.sub(r"[^\d.]+", "", parts[2]) or "0")
    return SIGN_MAP[sign_code], deg + minutes / 60.0 + seconds / 3600.0


def _normalize_nakshatra(code: str) -> str:
    key = _clean_text(code)
    if key in NAKSHATRA_MAP:
        return NAKSHATRA_MAP[key]
    raise ValueError(f"Unknown nakshatra code: {code!r}")


def _parse_planet_table(grid: list[list[str]]) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    planets: dict[str, dict[str, Any]] = {}
    meta: dict[str, Any] = {}
    lagna_sign: str | None = None
    for row in grid[1:]:
        if not row or not row[0]:
            continue
        label = row[0]
        sign, degree = _parse_degree(row[1:4])
        nakshatra = _normalize_nakshatra(row[4])
        pada = int(re.sub(r"[^\d]+", "", row[5]) or "0")
        rasi_code = _clean_text(row[6])
        navamsha_code = _clean_text(row[7])
        if rasi_code not in SIGN_MAP or navamsha_code not in SIGN_MAP:
            continue
        if label == "Lagna":
            meta["lagna"] = {"sign": sign, "degree": degree, "nakshatra": nakshatra, "pada": pada}
            lagna_sign = sign
            continue
        planet = _planet_name(label)
        if planet is None:
            continue
        entry = {
            "sign": sign,
            "degree": degree,
            "nakshatra": nakshatra,
            "pada": pada,
            "navamsha_sign": SIGN_MAP[navamsha_code],
            "retrograde": True if planet in {"Rahu", "Ketu"} else "(R)" in label,
        }
        karaka = _planet_karaka(label)
        if karaka is not None:
            entry["karaka"] = karaka
        planets[planet] = entry
    if lagna_sign is not None:
        lagna_index = SIGN_ORDER.index(lagna_sign)
        for entry in planets.values():
            sign_index = SIGN_ORDER.index(entry["sign"])
            entry["house"] = (sign_index - lagna_index) % 12 + 1
    return planets, meta


def _parse_vimsottari(grid: list[list[str]]) -> dict[str, Any]:
    ordered: list[dict[str, str]] = []
    for row in grid:
        if len(row) < 3:
            continue
        outer = PLANET_NAME_MAP.get(row[0])
        inner = PLANET_NAME_MAP.get(row[1])
        start_raw = row[2]
        if outer is None or inner is None or outer != inner:
            continue
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start_raw):
            continue
        ordered.append({"lord": outer, "start": start_raw})
    ordered = [entry for entry in ordered if entry["lord"] in MAHADASHA_SEQUENCE]
    return {"mahadasha": ordered}


def _parse_shadbala(grid: list[list[str]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for row in grid[1:]:
        if len(row) < 4:
            continue
        planet = PLANET_NAME_MAP.get(row[0])
        if planet is None:
            continue
        try:
            result[planet] = {
                "shadbala": float(row[1]),
                "rupas": float(row[2]),
                "percent": float(row[3]),
            }
        except ValueError:
            continue
    return result


def _find_tables(markdown: str) -> list[list[list[str]]]:
    parser = _TableCollector()
    parser.feed(markdown)
    return [_expand_grid(table) for table in parser.tables]


def parse_jhora_markdown(markdown: str) -> dict[str, Any]:
    tables = _find_tables(markdown)
    if not tables:
        raise ValueError("No HTML tables found in JHora markdown export")

    payload: dict[str, Any] = {}

    for grid in tables:
        if not grid or not grid[0]:
            continue
        head = grid[0][0]
        row_text = " ".join(cell for cell in grid[0] if cell)
        if head == "Body":
            planets, meta = _parse_planet_table(grid)
            payload["planets"] = planets
            if meta:
                payload["meta"] = meta
        elif "Planet Shadbala" in row_text:
            payload["shadbala"] = _parse_shadbala(grid)
        elif any("1995-10-27" in cell or "2002-10-26" in cell for row in grid for cell in row):
            if "dasha" not in payload:
                payload["dasha"] = _parse_vimsottari(grid)

    if "planets" not in payload:
        raise ValueError("Could not locate the main planet table in JHora markdown export")
    return payload


def load_jhora_markdown(path: str | Path) -> dict[str, Any]:
    text = Path(path).read_text(encoding="utf-8")
    return parse_jhora_markdown(text)


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(
        description="Convert a JHora markdown export into a structured JSON payload."
    )
    parser.add_argument("input", help="Path to the markdown export.")
    args = parser.parse_args()

    payload = load_jhora_markdown(args.input)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
