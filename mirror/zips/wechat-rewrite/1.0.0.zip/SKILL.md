---
name: wechat-rewrite
description: "微信公众号文章深度改写工具 — 输入文章URL，自动抓取原文、AI深度改写去除AI痕迹、生成可直接粘贴到微信公众号编辑器的富文本HTML。当用户说「改写公众号文章」「洗稿」「把这篇文章原创化」「生成公众号版本」时使用。"
---

# ✍️ 微信公众号文章深度改写 (wechat-rewrite)

**一句话用法**：给我一篇公众号文章的链接，我抓取内容 → 深度改写 → 输出可直接粘贴进公众号编辑器的富文本版本。

---

## 触发场景

用户说以下任意一种时，加载本 Skill：

- "帮我改写/洗稿这篇公众号文章"
- "把这篇文章原创化"
- "生成公众号直接粘贴的版本"
- 给了一个 `mp.weixin.qq.com` 链接 + 改写/洗稿意图

---

## 完整工作流（必须按顺序执行）

### Step 1 — 抓取原文

使用 `web_fetch` 工具获取文章内容：

```
web_fetch(url="<用户提供的链接>", fetchInfo="获取文章完整内容，包括标题、所有正文段落、代码块、小标题")
```

如果 web_fetch 返回内容不完整（只有摘要），尝试用下载器：

```bash
cd C:\Users\CNKI\.workbuddy\skills\wechat-toolkit\scripts\downloader
npm install   # 首次使用才需要
node download.js "<文章URL>" --output "d:/workbuddy/wechat-articles"
```

---

### Step 2 — 分析文章结构

读取原文后，识别：
1. **文章类型**：技术教程 / 观点评论 / 新闻资讯 / 产品介绍 / 故事叙事
2. **核心主题**：一句话概括文章讲什么
3. **段落结构**：几个主要板块，各板块讲什么
4. **特殊内容**：有无代码块、表格、数据图

---

### Step 3 — 深度改写

#### 必须执行的改写策略

**A. 结构重组（首要任务）**
- 调整段落顺序，使逻辑线不同于原文
- 将长段拆短，或合并碎片段落
- 叙事角度转换：`教程型` → `踩坑型`；`列表型` → `叙述型`；`说明型` → `对比型`

**B. 语言去AI痕迹（逐句检查）**

必须删除以下词汇和句式：
- 意义膨胀词：标志性、里程碑、深远影响、历史性
- 虚假权威：专家认为、业内普遍认为、有数据显示（没有来源的）
- 伪深度动词：赋能、赋予、加持、赋予力量、提升能力
- 广告语气：卓越、极致体验、全方位、颠覆式
- AI高频词（直接删除替换）：**赋能、闭环、生态、抓手、底层逻辑、范式、沉淀、势能、护城河、降维打击**
- 填充短语（直接删除）：值得注意的是、事实上、不难发现、总体来说、综合来看
- 空洞结尾（改为实际结论）：未来可期、值得期待、相信XXX会带来更多可能性

**C. 标题重写**

生成 3 个备选标题，要求覆盖不同风格：
- 疑问型："为什么XXX大多数人都答不全？"
- 数字+痛点型："这X个XXX细节，大多数人都搞错了"  
- 悬念型："XXX的真相，做了3年才搞清楚"

**D. 开头重写**

将原文开头改为以下风格之一：
- **痛点引入**：直击读者最头疼的问题
- **场景引入**：用具体工作场景切入
- **数据引入**：用一个有趣的数字开头
- **反问引入**：抛出反直觉的问题

**E. 代码块处理**（如有）
- 代码不删改，但要补全被截断的示例
- 代码上方加一句说明这段代码解决什么问题
- 代码下方加一句说明运行效果或注意事项

#### AI痕迹检查清单（改写完执行）

| # | 检查项 | 要求 |
|---|--------|------|
| 1 | 读起来像真人说话，可以直接朗读 | ✅ |
| 2 | 无空洞句、模板段 | ✅ |
| 3 | 信息密度高，每句话有具体内容 | ✅ |
| 4 | 结构与原文明显不同 | ✅ |
| 5 | 保留核心信息 | ✅ |
| 6 | 无AI高频词 | ✅ |

---

### Step 4 — 保存改写版本（Markdown）

保存路径：`d:/workbuddy/wechat-articles/<文章主题简名>.md`

文件必须包含 frontmatter：

```markdown
---
title: <改写后的标题>
cover: https://picsum.photos/seed/<随机词>/1080/864
---

# <标题>

> <一句话引导语，说明本文价值>

---

<正文...>
```

---

### Step 5 — 生成公众号富文本HTML

这是最关键一步。生成一个**全部内联样式**的 HTML 文件，可以直接 Ctrl+A → Ctrl+C → 粘贴进微信公众号编辑器。

保存路径：`d:/workbuddy/wechat-articles/wechat-ready.html`

#### HTML模板规范

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>文章标题</title>
</head>
<body style="max-width:677px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;font-size:15px;line-height:1.8;color:#333;background:#fff;padding:20px;">

<!-- 一级标题 -->
<h1 style="font-size:22px;font-weight:700;color:#1a1a1a;line-height:1.4;margin:20px 0 10px;padding-left:12px;border-left:4px solid #1677ff;">标题文字</h1>

<!-- 二级标题（分节） -->
<h2 style="font-size:17px;font-weight:700;color:#fff;background:#1677ff;padding:8px 16px;border-radius:4px;margin:28px 0 14px;">分节标题</h2>

<!-- 三级标题 -->
<h3 style="font-size:16px;font-weight:700;color:#1677ff;margin:20px 0 8px;padding-left:10px;border-left:3px solid #1677ff;">小标题</h3>

<!-- 正文段落 -->
<p style="margin:0 0 12px;text-indent:0;">段落文字</p>

<!-- 引用块 -->
<blockquote style="margin:16px 0;padding:12px 16px;background:#f0f7ff;border-left:4px solid #1677ff;border-radius:0 4px 4px 0;color:#555;">
  <p style="margin:0;">引用内容</p>
</blockquote>

<!-- 代码块（深色背景） -->
<pre style="background:#1e1e2e;color:#cdd6f4;padding:16px;border-radius:8px;overflow-x:auto;margin:16px 0;font-size:13px;line-height:1.6;"><code>代码内容</code></pre>

<!-- 行内代码 -->
<code style="background:#f0f0f0;color:#d32f2f;padding:2px 6px;border-radius:3px;font-size:13px;font-family:monospace;">inline code</code>

<!-- 表格 -->
<table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px;">
  <thead>
    <tr style="background:#1677ff;color:#fff;">
      <th style="padding:10px 12px;text-align:left;border:1px solid #ddd;">表头</th>
    </tr>
  </thead>
  <tbody>
    <tr style="background:#fff;">
      <td style="padding:8px 12px;border:1px solid #ddd;">内容</td>
    </tr>
    <tr style="background:#f8f9fa;">
      <td style="padding:8px 12px;border:1px solid #ddd;">内容</td>
    </tr>
  </tbody>
</table>

<!-- 无序列表 -->
<ul style="padding-left:20px;margin:8px 0;">
  <li style="margin:4px 0;">列表项</li>
</ul>

<!-- 有序列表 -->
<ol style="padding-left:20px;margin:8px 0;">
  <li style="margin:4px 0;">列表项</li>
</ol>

<!-- 分割线 -->
<hr style="border:none;border-top:1px solid #eee;margin:24px 0;">

<!-- 强调（加粗） -->
<strong style="font-weight:700;color:#1a1a1a;">重要文字</strong>

</body>
</html>
```

#### 颜色主题规范

| 元素 | 颜色值 |
|------|--------|
| 主色调（标题边框、标签背景）| `#1677ff` |
| 正文文字 | `#333333` |
| 代码块背景 | `#1e1e2e` |
| 代码块文字 | `#cdd6f4` |
| 行内代码文字 | `#d32f2f` |
| 行内代码背景 | `#f0f0f0` |
| 引用块背景 | `#f0f7ff` |

---

### Step 6 — 输出结果

完成后告知用户：
1. Markdown 文件路径
2. HTML 文件路径
3. 使用方法：浏览器打开 HTML → Ctrl+A → Ctrl+C → 粘贴进公众号编辑器
4. 简要说明改动要点（标题、结构、去掉了哪些AI痕迹）

---

## 注意事项

- 微信公众号编辑器对CSS有限制，**必须使用内联样式**，不要用 `<style>` 标签
- 代码块背景色有时公众号会覆盖掉，建议告知用户这是平台限制
- 文章字数建议控制在 **2000-4000字**，过长公众号阅读体验差
- 所有改写仅供学习参考，请遵守版权法规
