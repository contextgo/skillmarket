# wechat-rewrite 使用说明

微信公众号文章深度改写工具，完整流程：**抓取原文 → AI改写 → 输出公众号富文本**。

---

## 快速开始

1. 给 AI 一篇公众号文章链接，说"帮我改写这篇文章"
2. AI 自动执行抓取 → 改写 → 生成HTML全流程
3. 用浏览器打开生成的HTML，Ctrl+A → Ctrl+C → 粘贴进公众号编辑器

---

## md2wechat.js 独立使用

如果你已经有了改写好的Markdown，可以直接转换成公众号HTML：

```bash
# 基本用法（输出同名.html文件）
node scripts/md2wechat.js article.md

# 指定输出路径
node scripts/md2wechat.js article.md wechat-ready.html

# 输出到标准输出（可管道处理）
node scripts/md2wechat.js article.md --stdout
```

---

## Markdown文章格式要求

文章开头加 frontmatter 才能正确设置标题：

```markdown
---
title: 文章标题
cover: https://picsum.photos/seed/topic/1080/864
---

# 正文标题

正文内容...
```

---

## 支持的Markdown语法

| 语法 | 效果 |
|------|------|
| `# 标题` | 蓝色左边框标题 |
| `## 标题` | 蓝底白字分节标题 |
| `### 标题` | 蓝色左边框小标题 |
| `` `代码` `` | 红色行内代码 |
| ```` ``` ```` 代码块 | 深色背景代码块 |
| `> 引用` | 蓝色左边框引用块 |
| `- 列表` | 无序列表 |
| `1. 列表` | 有序列表 |
| 表格 | 蓝色表头、交替行背景 |
| `**加粗**` | 加粗文字 |
| `*斜体*` | 斜体文字 |

---

## 注意事项

- 微信编辑器对CSS有限制，代码块背景色偶尔会被覆盖，这是平台问题
- 文章字数建议 2000-4000 字
- 内容仅供学习参考，请遵守版权法规
