#!/usr/bin/env node
/**
 * md2wechat.js — Markdown → 微信公众号富文本HTML 转换器
 * 
 * 用法：
 *   node md2wechat.js <input.md> [output.html]
 *   node md2wechat.js <input.md> --stdout
 * 
 * 输出：全内联样式的HTML，可直接Ctrl+A复制进微信公众号编辑器
 */

const fs = require('fs');
const path = require('path');

// ─── 颜色主题 ────────────────────────────────────────────────────────────────
const THEME = {
  primary:       '#1677ff',
  text:          '#333333',
  textLight:     '#666666',
  heading1:      '#1a1a1a',
  codeBg:        '#1e1e2e',
  codeText:      '#cdd6f4',
  inlineCodeBg:  '#f0f0f0',
  inlineCodeText:'#d32f2f',
  quoteBg:       '#f0f7ff',
  tableTh:       '#1677ff',
  tableEvenBg:   '#f8f9fa',
  border:        '#e8e8e8',
};

// ─── HTML 模板组件 ────────────────────────────────────────────────────────────
const styles = {
  body: `max-width:677px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;font-size:15px;line-height:1.8;color:${THEME.text};background:#fff;padding:20px 16px;`,
  h1: `font-size:22px;font-weight:700;color:${THEME.heading1};line-height:1.4;margin:24px 0 12px;padding-left:12px;border-left:4px solid ${THEME.primary};`,
  h2: `font-size:17px;font-weight:700;color:#fff;background:${THEME.primary};padding:8px 16px;border-radius:4px;margin:32px 0 16px;`,
  h3: `font-size:16px;font-weight:700;color:${THEME.primary};margin:20px 0 8px;padding-left:10px;border-left:3px solid ${THEME.primary};`,
  h4: `font-size:15px;font-weight:700;color:${THEME.heading1};margin:16px 0 6px;`,
  p:  `margin:0 0 12px;line-height:1.8;color:${THEME.text};`,
  pre: `background:${THEME.codeBg};color:${THEME.codeText};padding:16px;border-radius:8px;overflow-x:auto;margin:16px 0;font-size:13px;line-height:1.6;white-space:pre;`,
  code: `font-family:'JetBrains Mono','Fira Code','Courier New',monospace;`,
  inlineCode: `background:${THEME.inlineCodeBg};color:${THEME.inlineCodeText};padding:2px 6px;border-radius:3px;font-size:13px;font-family:'JetBrains Mono','Courier New',monospace;`,
  blockquote: `margin:16px 0;padding:12px 16px;background:${THEME.quoteBg};border-left:4px solid ${THEME.primary};border-radius:0 4px 4px 0;color:#555;`,
  ul: `padding-left:20px;margin:8px 0 12px;`,
  ol: `padding-left:20px;margin:8px 0 12px;`,
  li: `margin:4px 0;line-height:1.8;`,
  hr: `border:none;border-top:1px solid ${THEME.border};margin:24px 0;`,
  table: `width:100%;border-collapse:collapse;margin:16px 0;font-size:14px;`,
  th: `padding:10px 12px;text-align:left;border:1px solid ${THEME.border};background:${THEME.tableTh};color:#fff;font-weight:600;`,
  tdOdd: `padding:8px 12px;border:1px solid ${THEME.border};background:#fff;`,
  tdEven: `padding:8px 12px;border:1px solid ${THEME.border};background:${THEME.tableEvenBg};`,
  strong: `font-weight:700;color:${THEME.heading1};`,
  em: `font-style:italic;color:${THEME.textLight};`,
};

// ─── 解析器 ─────────────────────────────────────────────────────────────────

function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---\n/);
  if (!match) return { meta: {}, body: content };
  
  const meta = {};
  match[1].split('\n').forEach(line => {
    const [k, ...v] = line.split(':');
    if (k && v.length) meta[k.trim()] = v.join(':').trim();
  });
  return { meta, body: content.slice(match[0].length) };
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderInline(text) {
  // 行内代码
  text = text.replace(/`([^`]+)`/g, (_, code) =>
    `<code style="${styles.inlineCode}">${escapeHtml(code)}</code>`);
  // 加粗
  text = text.replace(/\*\*(.+?)\*\*/g, (_, t) =>
    `<strong style="${styles.strong}">${t}</strong>`);
  // 斜体
  text = text.replace(/\*(.+?)\*/g, (_, t) =>
    `<em style="${styles.em}">${t}</em>`);
  // 链接
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) =>
    `<a href="${href}" style="color:${THEME.primary};text-decoration:none;">${label}</a>`);
  return text;
}

function mdToHtml(md) {
  const lines = md.split('\n');
  let html = '';
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // 代码块
    if (line.startsWith('```')) {
      const lang = line.slice(3).trim();
      let code = '';
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) {
        code += lines[i] + '\n';
        i++;
      }
      i++; // skip closing ```
      html += `<pre style="${styles.pre}"><code style="${styles.code}">${escapeHtml(code.trimEnd())}</code></pre>\n`;
      continue;
    }

    // 水平线
    if (/^[-*]{3,}$/.test(line.trim())) {
      html += `<hr style="${styles.hr}">\n`;
      i++;
      continue;
    }

    // 标题
    const hMatch = line.match(/^(#{1,4})\s+(.+)/);
    if (hMatch) {
      const level = hMatch[1].length;
      const text = renderInline(hMatch[2]);
      const s = [styles.h1, styles.h2, styles.h3, styles.h4][level - 1];
      html += `<h${level} style="${s}">${text}</h${level}>\n`;
      i++;
      continue;
    }

    // 引用块
    if (line.startsWith('> ')) {
      let qLines = [];
      while (i < lines.length && lines[i].startsWith('> ')) {
        qLines.push(lines[i].slice(2));
        i++;
      }
      const qHtml = qLines.map(l => renderInline(l)).join('<br>');
      html += `<blockquote style="${styles.blockquote}"><p style="margin:0;">${qHtml}</p></blockquote>\n`;
      continue;
    }

    // 无序列表
    if (/^[-*+]\s/.test(line)) {
      let items = [];
      while (i < lines.length && /^[-*+]\s/.test(lines[i])) {
        items.push(`<li style="${styles.li}">${renderInline(lines[i].replace(/^[-*+]\s/, ''))}</li>`);
        i++;
      }
      html += `<ul style="${styles.ul}">${items.join('')}</ul>\n`;
      continue;
    }

    // 有序列表
    if (/^\d+\.\s/.test(line)) {
      let items = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i])) {
        items.push(`<li style="${styles.li}">${renderInline(lines[i].replace(/^\d+\.\s/, ''))}</li>`);
        i++;
      }
      html += `<ol style="${styles.ol}">${items.join('')}</ol>\n`;
      continue;
    }

    // 表格
    if (line.includes('|') && lines[i + 1] && lines[i + 1].match(/^[|: -]+$/)) {
      const headers = line.split('|').filter(c => c.trim()).map(c => c.trim());
      i += 2; // skip header + separator
      let rows = [];
      while (i < lines.length && lines[i].includes('|')) {
        rows.push(lines[i].split('|').filter(c => c.trim()).map(c => c.trim()));
        i++;
      }
      let tableHtml = `<table style="${styles.table}"><thead><tr>`;
      headers.forEach(h => {
        tableHtml += `<th style="${styles.th}">${renderInline(h)}</th>`;
      });
      tableHtml += '</tr></thead><tbody>';
      rows.forEach((row, ri) => {
        const tdStyle = ri % 2 === 0 ? styles.tdOdd : styles.tdEven;
        tableHtml += '<tr>';
        row.forEach(cell => {
          tableHtml += `<td style="${tdStyle}">${renderInline(cell)}</td>`;
        });
        tableHtml += '</tr>';
      });
      tableHtml += '</tbody></table>';
      html += tableHtml + '\n';
      continue;
    }

    // 空行
    if (line.trim() === '') {
      i++;
      continue;
    }

    // 普通段落
    html += `<p style="${styles.p}">${renderInline(escapeHtml(line).replace(/\\n/g, '<br>'))}</p>\n`;
    i++;
  }

  return html;
}

// ─── 主函数 ─────────────────────────────────────────────────────────────────

function buildPage(title, bodyHtml) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
</head>
<body style="${styles.body}">
${bodyHtml}
</body>
</html>`;
}

function main() {
  const args = process.argv.slice(2);
  if (!args.length) {
    console.error('用法: node md2wechat.js <input.md> [output.html]');
    console.error('      node md2wechat.js <input.md> --stdout');
    process.exit(1);
  }

  const inputFile = args[0];
  const toStdout = args.includes('--stdout');
  const outputFile = toStdout
    ? null
    : (args[1] && !args[1].startsWith('--') ? args[1] : inputFile.replace(/\.md$/, '.html'));

  if (!fs.existsSync(inputFile)) {
    console.error(`错误：找不到文件 ${inputFile}`);
    process.exit(1);
  }

  const raw = fs.readFileSync(inputFile, 'utf-8');
  const { meta, body } = parseFrontmatter(raw);
  const title = meta.title || path.basename(inputFile, '.md');
  const bodyHtml = mdToHtml(body);
  const page = buildPage(title, bodyHtml);

  if (toStdout) {
    process.stdout.write(page);
  } else {
    fs.writeFileSync(outputFile, page, 'utf-8');
    console.log(`✅ 已生成：${outputFile}`);
    console.log(`📋 使用方法：用浏览器打开 → Ctrl+A → Ctrl+C → 粘贴进公众号编辑器`);
  }
}

main();
