# MemoryVault 记忆琥珀

> 让AI拥有真正的长期记忆，像人类一样记住重要的事

## 核心理念

人类记忆有三个层次：瞬间印象 → 短期记忆 → 长期记忆。MemoryVault 模拟这个过程：

```
即时记忆 → 屏幕坐标、按钮位置、当前状态（用完即删）
    ↓
短期记忆 → 对话内容、临时任务（滑动窗口，保留最近N条）
    ↓
长期记忆 → 用户偏好、重要事实（持久化，跨会话）
```

## 核心功能

### 1. 三层记忆架构

| 层次 | 容量 | 持久化 | 典型用途 |
|------|------|--------|---------|
| 即时记忆 | 无限制 | 否 | 坐标、状态、临时数据 |
| 短期记忆 | 20条滑动窗口 | 否 | 最近对话、临时任务 |
| 长期记忆 | 无限制 | 是 | 偏好、事实、重要信息 |

### 2. 语义搜索
- 基于文本相似度的记忆检索
- 返回相关度评分
- 支持模糊匹配
- 多维度过滤（类型、标签、时间）

### 3. 标签系统
- 为记忆打标签
- 按标签检索
- 自动标签推荐
- 标签统计

### 4. 记忆持久化
- JSON格式存储
- 自动保存/加载
- 支持导出/导入
- 重启不丢失

### 5. 记忆管理
- 过期清理
- 去重检测
- 记忆压缩
- 统计报告

## 安装

```bash
pip install -r requirements.txt
```

## 快速使用

```python
from memory_vault import MemoryVault, MemoryType

# 初始化
vault = MemoryVault()

# 存储不同类型的记忆
vault.store(
    "明天下午2点有项目评审会议",
    MemoryType.LONG_TERM,
    tags=["会议", "日程", "重要"]
)

vault.store(
    "刚刚点击了屏幕坐标(500, 300)",
    MemoryType.IMMEDIATE,
    tags=["坐标", "操作"]
)

vault.store(
    "用户说喜欢喝美式咖啡",
    MemoryType.LONG_TERM,
    tags=["偏好", "饮食"]
)

# 检索记忆
results = vault.retrieve("咖啡", limit=5)
for r in results:
    print(f"[{r.relevance:.2f}] {r.content}")

# 获取短期记忆（最近对话）
short_mem = vault.get_short_term_memory(limit=10)

# 获取即时记忆（当前状态）
immediate_mem = vault.get_immediate_memory()

# 统计
stats = vault.get_stats()
print(f"总记忆数: {stats['total_count']}")
```

## 进阶配置

```python
vault = MemoryVault(
    data_dir="~/.memory_vault",     # 数据目录
    short_term_limit=20,           # 短期记忆容量
    auto_save=True,                 # 自动保存
    save_interval=60,               # 保存间隔（秒）
    embedding_model=None,           # 向量模型（可选）
)
```

## 记忆类型

```python
class MemoryType(Enum):
    SHORT_TERM = "short_term"    # 短期记忆（滑动窗口）
    LONG_TERM = "long_term"       # 长期记忆（持久化）
    IMMEDIATE = "immediate"       # 即时记忆（操作相关）
```

## 记忆检索

```python
# 语义检索
results = vault.retrieve("日程安排", limit=5)

# 按标签检索
results = vault.get_by_tag("偏好")

# 按类型检索
results = vault.get_by_type(MemoryType.LONG_TERM)

# 检索结果
@dataclass
class MemoryEntry:
    memory_id: str
    content: str
    memory_type: MemoryType
    tags: List[str]
    relevance: float          # 相关度评分
    created_at: str
    accessed_at: str
```

## 适用场景

- 个人AI助手
- 对话系统记忆
- 桌面自动化上下文
- 游戏AI状态管理
- 客服系统上下文

## 与其他方案的区别

| 功能 | 纯上下文 | Redis缓存 | MemoryVault |
|------|---------|----------|-------------|
| 记忆分层 | 无 | 单一 | 三层架构 |
| 语义搜索 | 无 | 精确key | 相似度 |
| 标签系统 | 无 | 简单 | 完整 |
| 持久化 | 无 | 可选 | 自动 |
| 容量管理 | 无 | 手动 | 自动清理 |

## 工作原理

### 即时记忆
- 用于存储当前操作的上下文
- 可随时清空
- 例：坐标、窗口状态、鼠标位置

### 短期记忆
- 滑动窗口，保留最近N条
- 新记忆加入时，最旧的被移除
- 例：最近10轮对话

### 长期记忆
- 持久化存储
- 支持语义检索
- 例：用户偏好、已学习的事实

## 数据格式

```python
@dataclass
class MemoryEntry:
    memory_id: str           # 唯一ID
    content: str              # 记忆内容
    memory_type: MemoryType  # 记忆类型
    tags: List[str]          # 标签
    embedding: List[float]   # 向量表示（可选）
    created_at: str           # 创建时间
    last_accessed: str       # 最后访问
    access_count: int        # 访问次数
```

## 技术细节

- 依赖：Python 3.8+
- 无需外部API，纯本地运行
- 数据持久化：JSON文件
- 向量搜索：可选（TF-IDF/余弦相似度）
- 内存占用 < 50MB

## License

MIT License
