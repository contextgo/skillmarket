# -*- coding: utf-8 -*-
"""
MemoryVault - 记忆琥珀
版本: 1.0.0

三层记忆架构：短期（滑动窗口）+ 长期（持久化）+ 事件（时间线）
无外部依赖，纯标准库实现。可选接入 sentence-transformers 升级为真向量搜索。
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any


class WorkingMemory:
    """
    短期记忆 - 滑动窗口对话缓冲

    保存最近 N 条消息，用于传递给 AI 的上下文窗口。
    """

    def __init__(self, max_size: int = 20):
        self._max = max_size
        self._messages: List[Dict] = []

    def add(self, role: str, content: str, metadata: Dict = None):
        """
        添加一条消息

        Args:
            role: "user" | "ai" | "system"
            content: 消息内容
            metadata: 额外信息（情绪、时间戳等）
        """
        entry = {
            "role": role,
            "content": content,
            "time": datetime.now().isoformat(),
        }
        if metadata:
            entry.update(metadata)
        self._messages.append(entry)
        # 超出时移除最旧的
        if len(self._messages) > self._max:
            self._messages = self._messages[-self._max:]

    def get_context(self, last_n: int = None) -> List[Dict]:
        """获取上下文消息列表（可传给 AI）"""
        msgs = self._messages
        if last_n:
            msgs = msgs[-last_n:]
        return [{"role": m["role"], "content": m["content"]} for m in msgs]

    def clear(self):
        self._messages.clear()

    def __len__(self):
        return len(self._messages)


class LongTermMemory:
    """
    长期记忆 - 持久化重要信息

    存储跨会话需要记住的重要事项（用户偏好、重要事件等）。
    """

    def __init__(self, data_file: str = "./vault_data/long_term.json"):
        self._file = Path(data_file)
        self._file.parent.mkdir(parents=True, exist_ok=True)
        self._db: Dict[str, List[Dict]] = self._load()

    def _load(self) -> Dict[str, List[Dict]]:
        if self._file.exists():
            try:
                with open(self._file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save(self):
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump(self._db, f, ensure_ascii=False, indent=2)

    def remember(self, user: str, content: str, tags: List[str] = None,
                 importance: int = 3) -> str:
        """
        存入长期记忆

        Args:
            user: 用户标识
            content: 记忆内容
            tags: 标签列表，用于分类检索
            importance: 重要程度 1-5

        Returns:
            记忆 ID
        """
        mem_id = f"{user}_{int(datetime.now().timestamp())}"
        entry = {
            "id": mem_id,
            "content": content,
            "tags": tags or [],
            "importance": importance,
            "created": datetime.now().isoformat(),
            "access_count": 0,
        }
        if user not in self._db:
            self._db[user] = []
        self._db[user].append(entry)
        self._save()
        return mem_id

    def recall(self, user: str, query: str = "", tag: str = "", limit: int = 5) -> List[Dict]:
        """
        检索记忆

        Args:
            query: 关键词搜索
            tag: 按标签过滤
            limit: 返回数量
        """
        memories = self._db.get(user, [])

        if tag:
            memories = [m for m in memories if tag in m.get("tags", [])]

        if query:
            # 关键词过滤（简单版；可升级为向量相似度）
            query_words = query.strip().split()
            def match_score(m: Dict) -> float:
                text = m["content"].lower()
                score = sum(1 for w in query_words if w.lower() in text)
                return score
            memories = sorted(
                [m for m in memories if match_score(m) > 0],
                key=match_score,
                reverse=True
            )
        else:
            # 按重要程度 + 时间排序
            memories = sorted(memories, key=lambda m: (m.get("importance", 3), m["created"]), reverse=True)

        results = memories[:limit]
        # 更新访问次数
        ids = {m["id"] for m in results}
        for m in self._db.get(user, []):
            if m["id"] in ids:
                m["access_count"] = m.get("access_count", 0) + 1
        self._save()
        return results

    def forget(self, user: str, mem_id: str) -> bool:
        if user not in self._db:
            return False
        before = len(self._db[user])
        self._db[user] = [m for m in self._db[user] if m["id"] != mem_id]
        if len(self._db[user]) < before:
            self._save()
            return True
        return False

    def get_all(self, user: str) -> List[Dict]:
        return self._db.get(user, [])

    def get_summary(self, user: str, max_memories: int = 5) -> str:
        """生成记忆摘要（可注入 AI system_prompt）"""
        memories = self.recall(user, limit=max_memories)
        if not memories:
            return ""
        lines = [f"[{user}的重要记忆]"]
        for m in memories:
            date = m["created"][5:10]
            lines.append(f"• {date} {m['content']}")
        return "\n".join(lines)


class EpisodicMemory:
    """
    事件记忆 - 时间线式对话快照

    记录"谁在什么时候说了什么"，支持按时间检索。
    """

    def __init__(self, data_file: str = "./vault_data/episodes.json"):
        self._file = Path(data_file)
        self._file.parent.mkdir(parents=True, exist_ok=True)
        self._db: Dict[str, List[Dict]] = self._load()

    def _load(self) -> Dict[str, List[Dict]]:
        if self._file.exists():
            try:
                with open(self._file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save(self):
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump(self._db, f, ensure_ascii=False, indent=2)

    def record_episode(self, session_id: str, user: str, messages: List[Dict],
                        summary: str = ""):
        """保存一段对话"""
        episode = {
            "session": session_id,
            "user": user,
            "messages": messages,
            "summary": summary,
            "time": datetime.now().isoformat(),
            "message_count": len(messages),
        }
        if user not in self._db:
            self._db[user] = []
        self._db[user].append(episode)
        # 最多保留 500 条
        self._db[user] = self._db[user][-500:]
        self._save()

    def get_by_date(self, user: str, date_str: str) -> List[Dict]:
        """按日期检索（格式 YYYY-MM-DD）"""
        return [e for e in self._db.get(user, []) if e["time"].startswith(date_str)]

    def get_recent_episodes(self, user: str, n: int = 5) -> List[Dict]:
        return self._db.get(user, [])[-n:]


# ============================================================================
# 主入口
# ============================================================================

class MemoryVault:
    """
    MemoryVault - 记忆琥珀（一体化接口）

    三层记忆：
    - working: 短期对话上下文（滑动窗口）
    - long_term: 持久化重要记忆
    - episodic: 时间线对话快照

    用法：
        vault = MemoryVault("小明")
        vault.add_message("user", "今天面试通过了！")
        vault.add_message("ai", "恭喜！太棒了！")
        vault.remember("小明面试通过Python工程师职位", tags=["工作"])
        context = vault.get_context()
        summary = vault.get_memory_summary()
    """

    def __init__(self, user_id: str, data_dir: str = "./vault_data",
                 context_window: int = 20):
        self.user_id = user_id
        self.working = WorkingMemory(max_size=context_window)
        self.long_term = LongTermMemory(f"{data_dir}/long_term.json")
        self.episodic = EpisodicMemory(f"{data_dir}/episodes.json")
        self._session_id = f"{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    def add_message(self, role: str, content: str, metadata: Dict = None):
        """添加消息到短期记忆"""
        self.working.add(role, content, metadata)

    def remember(self, content: str, tags: List[str] = None,
                  importance: int = 3) -> str:
        """存入长期记忆"""
        return self.long_term.remember(self.user_id, content, tags, importance)

    def recall(self, query: str = "", tag: str = "", limit: int = 5) -> List[Dict]:
        """从长期记忆检索"""
        return self.long_term.recall(self.user_id, query, tag, limit)

    def get_context(self, last_n: int = None) -> List[Dict]:
        """获取短期记忆上下文（传给 AI）"""
        return self.working.get_context(last_n)

    def get_all_memories(self) -> List[Dict]:
        """获取所有长期记忆"""
        return self.long_term.get_all(self.user_id)

    def get_memory_summary(self, max_memories: int = 5) -> str:
        """生成记忆摘要（可注入 AI system_prompt）"""
        return self.long_term.get_summary(self.user_id, max_memories)

    def save_episode(self, summary: str = ""):
        """保存当前会话为事件记忆"""
        msgs = self.working.get_context()
        self.episodic.record_episode(self._session_id, self.user_id, msgs, summary)

    def recall_by_date(self, date_str: str) -> List[Dict]:
        """按日期查找历史会话"""
        return self.episodic.get_by_date(self.user_id, date_str)

    def clear_working_memory(self):
        """清空短期记忆（新会话开始时调用）"""
        self.working.clear()

    def forget(self, mem_id: str) -> bool:
        """删除一条长期记忆"""
        return self.long_term.forget(self.user_id, mem_id)

    def get_full_context_for_ai(self, max_long_term: int = 3) -> str:
        """
        生成完整的 AI 上下文注入内容（system_prompt 片段）

        包含：用户长期记忆摘要 + 短期对话上下文
        """
        parts = []
        summary = self.get_memory_summary(max_long_term)
        if summary:
            parts.append(summary)
        return "\n".join(parts)
