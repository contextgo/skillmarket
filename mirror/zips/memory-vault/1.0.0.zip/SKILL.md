---
name: memory-vault
version: 1.0.0
author: 玲瑶
description: |
  记忆琥珀：为 AI 提供三层记忆架构（短期+向量+事件），真正实现跨会话长期记忆。
  
  触发词：长期记忆、跨会话记忆、记住上次对话、AI记忆、持久记忆、
  记忆系统、向量记忆、语义搜索记忆、记住聊天内容、记忆检索、
  memory system、long term memory、conversation memory、
  记住以前说的、翻出记忆、找历史记录、记忆召回、语义相关记忆、
  不要忘记、AI有记忆、跨天记忆、多会话记忆
  
  使用场景：
  - 长期陪伴 AI：记住用户的每次重要对话
  - 知识管理：用语义搜索召回相关记忆
  - 项目助手：记住项目上下文、决策历史
  - 情感陪伴：记住重要日期、用户偏好
---

# MemoryVault 记忆琥珀

## 能做什么

MemoryVault 给 AI 装上三层记忆，让它真正记住用户——不只是当次对话，而是跨越会话的长期记忆。

### 三层记忆架构

```
┌─────────────────────────────────────────┐
│  短期记忆 (Working Memory)               │
│  滑动窗口 · 最近 N 条对话 · 毫秒级读取   │
├─────────────────────────────────────────┤
│  长期记忆 (Long-term Memory)             │
│  重要信息 · 持久化 · 手动/自动保存       │
├─────────────────────────────────────────┤
│  事件记忆 (Episodic Memory)              │
│  "谁在什么时候说了什么" · 时间线检索     │
└─────────────────────────────────────────┘
```

## 快速使用

```python
from memory_vault import MemoryVault

vault = MemoryVault(user_id="小明")

# 1. 保存当次对话到短期记忆
vault.add_message("user", "今天面试通过了！好开心！")
vault.add_message("ai", "哇！太棒了！恭喜你！")

# 2. 存入长期记忆（重要事件）
vault.remember("小明面试通过了Python工程师职位", tags=["工作", "里程碑"])

# 3. 语义搜索记忆
results = vault.recall("工作")
# → ["小明面试通过了Python工程师职位 (2026-04-20)"]

# 4. 获取最近对话上下文（传给 AI）
context = vault.get_context(last_n=10)

# 5. 获取某用户所有长期记忆
memories = vault.get_all_memories()

# 6. 生成记忆摘要（传给 AI 作为系统提示）
summary = vault.get_memory_summary()
# → "关于小明：4月20日面试通过Python工程师..."
```

## 记忆检索方式

| 方式 | 用法 | 适合场景 |
|------|------|---------|
| 关键词检索 | `recall("面试")` | 快速找特定主题 |
| 时间检索 | `recall_by_date("2026-04-20")` | 找某天发生的事 |
| 标签检索 | `recall_by_tag("工作")` | 按分类查找 |
| 最近记忆 | `get_recent(n=5)` | 最近 N 条重要记忆 |

## 持久化

- 记忆保存为 JSON 文件，可配置路径
- 支持导入/导出（备份迁移）
- 可设置记忆过期时间（自动清理旧记忆）

## 依赖

- Python 3.8+
- 无需第三方库（仅用标准库）
- 可选：`sentence-transformers` 升级为真正的向量语义检索
