# -*- coding: utf-8 -*-
"""
MemoryVault 测试脚本
测试三层记忆架构、语义搜索、跨会话持久化等核心功能
"""

import sys
import os
import time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_vault import MemoryVault, MemoryType, MemoryEntry


def test_memory_storage():
    """测试记忆存储"""
    print("\n=== 测试1: 记忆存储 ===")

    vault = MemoryVault(user_id="test_user")

    # 存储短期记忆
    mem_id = vault.store("今天的会议改到了下午3点", MemoryType.SHORT_TERM, tags=["会议", "日程"])
    print(f"  存储短期记忆: ID={mem_id}")

    # 存储长期记忆
    mem_id2 = vault.store("用户喜欢喝咖啡", MemoryType.LONG_TERM, tags=["偏好", "饮食"])
    print(f"  存储长期记忆: ID={mem_id2}")

    # 存储即时记忆
    mem_id3 = vault.store("屏幕坐标(500, 300)", MemoryType.IMMEDIATE, tags=["坐标", "屏幕"])
    print(f"  存储即时记忆: ID={mem_id3}")

    status = "PASS" if mem_id and mem_id2 and mem_id3 else "FAIL"
    print(f"  [{status}] 记忆存储正常")


def test_memory_retrieval():
    """测试记忆检索"""
    print("\n=== 测试2: 记忆检索 ===")

    vault = MemoryVault()

    # 添加一些记忆
    vault.store("明天下午2点有项目评审会议", MemoryType.LONG_TERM, tags=["会议", "日程"])
    vault.store("用户上周去了日本旅游", MemoryType.LONG_TERM, tags=["旅行", "经历"])
    vault.store("用户正在使用Python编写数据分析脚本", MemoryType.LONG_TERM, tags=["编程", "Python"])
    vault.store("上次点击了屏幕坐标(800, 450)", MemoryType.IMMEDIATE, tags=["坐标"])

    # 检索
    results = vault.retrieve("会议安排", limit=3)
    print(f"  检索'会议安排': 找到 {len(results)} 条")
    for r in results[:2]:
        print(f"    - {r.content[:40]}... (相关度:{r.relevance:.2f})")

    results2 = vault.retrieve("日本", limit=3)
    print(f"  检索'日本': 找到 {len(results2)} 条")

    results3 = vault.retrieve("坐标", limit=3)
    print(f"  检索'坐标': 找到 {len(results3)} 条")

    status = "PASS" if len(results) > 0 else "FAIL"
    print(f"  [{status}] 记忆检索正常")


def test_short_term_memory():
    """测试短期记忆滑动窗口"""
    print("\n=== 测试3: 短期记忆 ===")

    vault = MemoryVault()

    # 添加超过窗口大小的记忆
    for i in range(15):
        vault.store(f"短期对话内容{i+1}", MemoryType.SHORT_TERM)

    # 获取短期记忆
    short_memories = vault.get_short_term_memory(limit=20)
    print(f"  短期记忆数: {len(short_memories)}")

    # 测试滑动窗口
    vault.store("新的短期记忆", MemoryType.SHORT_TERM)
    short_memories2 = vault.get_short_term_memory(limit=20)
    print(f"  添加后短期记忆数: {len(short_memories2)}")


def test_immediate_memory():
    """测试即时记忆"""
    print("\n=== 测试4: 即时记忆 ===")

    vault = MemoryVault()

    # 存储即时记忆
    vault.store("刚刚点击了(100, 200)", MemoryType.IMMEDIATE)
    vault.store("屏幕上有个红色的按钮", MemoryType.IMMEDIATE)
    vault.store("当前窗口标题: 未命名 - 记事本", MemoryType.IMMEDIATE)

    # 获取即时记忆
    immediate_memories = vault.get_immediate_memory()
    print(f"  即时记忆数: {len(immediate_memories)}")
    for m in immediate_memories[:3]:
        print(f"    - {m.content}")

    # 清理即时记忆
    vault.clear_immediate_memory()
    after_clear = vault.get_immediate_memory()
    print(f"  清理后即时记忆数: {len(after_clear)}")


def test_memory_persistence():
    """测试记忆持久化"""
    print("\n=== 测试5: 记忆持久化 ===")

    vault = MemoryVault()

    # 添加一些数据
    vault.store("持久化测试记忆1", MemoryType.LONG_TERM, tags=["测试"])
    vault.store("持久化测试记忆2", MemoryType.LONG_TERM, tags=["测试"])

    # 触发保存
    vault.save()
    print("  记忆已保存")

    # 创建新实例（模拟重启）
    vault2 = MemoryVault()

    # 检索
    results = vault2.retrieve("持久化测试", limit=5)
    print(f"  重启后检索: 找到 {len(results)} 条")
    if results:
        print(f"    - {results[0].content}")

    status = "PASS" if len(results) > 0 else "FAIL"
    print(f"  [{status}] 持久化正常")


def test_memory_tags():
    """测试标签管理"""
    print("\n=== 测试6: 标签管理 ===")

    vault = MemoryVault()

    # 添加带标签的记忆
    vault.store("Python教程视频", MemoryType.LONG_TERM, tags=["编程", "Python", "教程"])
    vault.store("JavaScript入门", MemoryType.LONG_TERM, tags=["编程", "JavaScript"])
    vault.store("咖啡推荐", MemoryType.LONG_TERM, tags=["生活", "美食"])

    # 按标签检索
    print("  按标签'编程'检索:")
    by_tag = vault.get_by_tag("编程")
    for m in by_tag:
        print(f"    - {m.content} (标签:{m.tags})")

    # 获取所有标签
    all_tags = vault.get_all_tags()
    print(f"  所有标签: {all_tags}")


def test_memory_stats():
    """测试统计接口"""
    print("\n=== 测试7: 记忆统计 ===")

    vault = MemoryVault()

    # 添加各种类型的记忆
    for i in range(5):
        vault.store(f"短期{i}", MemoryType.SHORT_TERM)
    for i in range(3):
        vault.store(f"长期{i}", MemoryType.LONG_TERM)
    vault.store("即时", MemoryType.IMMEDIATE)

    stats = vault.get_stats()
    print(f"  统计: {stats}")
    print(f"  短期记忆数: {stats['short_term_count']}")
    print(f"  长期记忆数: {stats['long_term_count']}")
    print(f"  即时记忆数: {stats['immediate_count']}")
    print(f"  总记忆数: {stats['total_count']}")


if __name__ == "__main__":
    print("=" * 60)
    print("MemoryVault 测试套件")
    print("=" * 60)

    test_memory_storage()
    test_memory_retrieval()
    test_short_term_memory()
    test_immediate_memory()
    test_memory_persistence()
    test_memory_tags()
    test_memory_stats()

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
