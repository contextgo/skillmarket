#!/usr/bin/env python3
"""
舆情监控报告生成器 v2
读取 JSON 数据，生成带 ECharts 可视化、实时筛选、暗色模式的 HTML 报告
"""
import json
import sys
import os
import argparse
from datetime import datetime


def calc_heat_label(heat):
    """热度等级标签"""
    if heat >= 10000:
        return "🔥🔥🔥"
    elif heat >= 1000:
        return "🔥🔥"
    elif heat >= 100:
        return "🔥"
    return ""


def generate_html(data, output_path):
    meta = data.get("report_meta", {})
    items = data.get("items", [])
    risks = data.get("risk_alerts", [])
    trend = data.get("trend_analysis", {})
    platforms = data.get("platform_breakdown", [])
    comp = data.get("competitive_analysis", {})
    tracking = data.get("tracking_timeline", {})

    keyword = meta.get("keyword", "未知")
    total = meta.get("total_items", len(items))
    time_range = meta.get("time_range", "")
    generated_at = meta.get("generated_at", datetime.now().isoformat())
    sentiment = meta.get("sentiment_summary", {})
    pos = sentiment.get("positive", 0)
    neg = sentiment.get("negative", 0)
    neu = sentiment.get("neutral", 0)
    mixed = sentiment.get("mixed", 0)
    overall_risk = meta.get("overall_risk", "none")
    heat_index = meta.get("heat_index", 0)
    covered_platforms = ", ".join(meta.get("platforms_covered", []))
    mode = meta.get("mode", "standard")

    risk_icon = {"high": "🔴", "medium": "🟠", "low": "🟡", "none": "🟢"}.get(overall_risk, "🟢")
    risk_text = {"high": "高风险", "medium": "中风险", "low": "低风险", "none": "无风险"}.get(overall_risk, "无风险")
    risk_color = {"high": "#ef4444", "medium": "#f59e0b", "low": "#3b82f6", "none": "#10b981"}.get(overall_risk, "#10b981")

    # ---- ECharts 数据 ----
    # 情感饼图
    pie_data = []
    if pos: pie_data.append(f'{{"name":"正面","value":{pos}}}')
    if neg: pie_data.append(f'{{"name":"负面","value":{neg}}}')
    if neu: pie_data.append(f'{{"name":"中性","value":{neu}}}')
    if mixed: pie_data.append(f'{{"name":"混合","value":{mixed}}}')
    pie_data_str = "[" + ",".join(pie_data) + "]"

    # 平台柱状图
    platform_names = [f'"{p.get("platform","")}"' for p in sorted(platforms, key=lambda x: x.get("count",0), reverse=True)]
    platform_pos = [p.get("positive", 0) for p in sorted(platforms, key=lambda x: x.get("count",0), reverse=True)]
    platform_neg = [p.get("negative", 0) for p in sorted(platforms, key=lambda x: x.get("count",0), reverse=True)]
    platform_neu = [p.get("neutral", 0) for p in sorted(platforms, key=lambda x: x.get("count",0), reverse=True)]
    platform_names_str = "[" + ",".join(platform_names) + "]"
    platform_pos_str = json.dumps(platform_pos)
    platform_neg_str = json.dumps(platform_neg)
    platform_neu_str = json.dumps(platform_neu)

    # 时间轴折线图
    timeline = trend.get("timeline", [])
    tl_dates = json.dumps([t.get("date","") for t in timeline])
    tl_pos = json.dumps([t.get("positive",0) for t in timeline])
    tl_neg = json.dumps([t.get("negative",0) for t in timeline])
    tl_neu = json.dumps([t.get("neutral",0) for t in timeline])
    has_timeline = "true" if len(timeline) >= 2 else "false"

    # 条目 JSON（供前端筛选使用）
    items_json = json.dumps(items, ensure_ascii=False)

    # 竞品对比数据
    comp_html = ""
    if comp.get("enabled") and comp.get("brands"):
        brands = comp["brands"]
        brand_rows = ""
        for b in brands:
            s = b.get("sentiment_summary", {})
            bp = s.get("positive", 0)
            bn = s.get("negative", 0)
            bt = b.get("total_items", 1)
            score = b.get("overall_score", 0)
            risk = b.get("risk_level", "none")
            risk_icon_b = {"high": "🔴", "medium": "🟠", "low": "🟡", "none": "🟢"}.get(risk, "🟢")
            kws = " ".join([f'<span class="tag">{k}</span>' for k in b.get("top_keywords", [])])
            brand_rows += f"""
            <tr>
                <td><strong>{b.get("name","")}</strong></td>
                <td>{bt}</td>
                <td style="color:#10b981">{bp} ({bp/bt*100:.0f}%)</td>
                <td style="color:#ef4444">{bn} ({bn/bt*100:.0f}%)</td>
                <td><div class="score-bar"><div class="score-fill" style="width:{score}%"></div></div><span class="score-num">{score:.1f}</span></td>
                <td>{risk_icon_b} {risk}</td>
                <td>{kws}</td>
            </tr>"""
        comp_html = f"""
        <div class="section" id="section-competitive">
            <h2>🏆 竞品对比分析</h2>
            <p style="color:#666;font-size:14px;margin-bottom:16px">{comp.get("comparison_summary","")}</p>
            <div class="table-wrapper">
            <table class="comp-table">
                <thead><tr>
                    <th>品牌</th><th>声量</th><th>正面</th><th>负面</th>
                    <th>口碑得分</th><th>风险</th><th>核心标签</th>
                </tr></thead>
                <tbody>{brand_rows}</tbody>
            </table>
            </div>
        </div>"""

    # 传播链路
    tracking_html = ""
    if tracking.get("enabled") and tracking.get("spread_path"):
        path_items = ""
        for stage in tracking["spread_path"]:
            path_items += f"""
            <div class="track-item">
                <div class="track-stage">阶段{stage.get("stage","")}</div>
                <div class="track-content">
                    <div class="track-date">{stage.get("date","")} · {stage.get("platform","")}</div>
                    <div class="track-desc">{stage.get("description","")}</div>
                    <div class="track-vol">声量：{stage.get("volume",0)}条</div>
                </div>
            </div>"""
        tracking_html = f"""
        <div class="section" id="section-tracking">
            <h2>🔗 传播链路追踪</h2>
            <div class="track-meta">
                <span>📍 最早来源：<strong>{tracking.get("origin_source","")}</strong></span>
                <span style="margin-left:16px">📅 发酵时间：<strong>{tracking.get("origin_date","")}</strong></span>
            </div>
            <div class="track-timeline">{path_items}</div>
        </div>"""

    # 风险预警
    risks_html = ""
    for r in risks:
        level = r.get("level", "low")
        icon = {"high": "🔴", "medium": "🟠", "low": "🔵"}.get(level, "⚪")
        speed = r.get("spread_speed", "")
        speed_html = f'<span class="spread-badge">{{"fast":"⚡ 快速扩散","medium":"➡️ 正常扩散","slow":"🐢 缓慢扩散"}}.get("{speed}","")</span>' if speed else ""
        risks_html += f"""
        <div class="risk-card level-{level}">
            <div class="risk-header">{icon} {r.get("title","")}{speed_html}</div>
            <p class="risk-desc">{r.get("description","")}</p>
            <p class="risk-rec"><strong>💡 建议：</strong>{r.get("recommendation","")}</p>
        </div>"""

    # 核心发现
    findings_html = "".join([f"<li>{f}</li>" for f in trend.get("key_findings", [])])
    recommendations_html = "".join([f"<li>{r}</li>" for r in trend.get("recommendations", [])])
    hot_topics_html = "".join([f'<span class="hot-topic">🔥 {t}</span>' for t in trend.get("hot_topics", [])])

    sentiment_label = {"mixed": "正负交织", "positive": "整体正面", "negative": "整体负面"}.get(
        trend.get("overall_sentiment", "mixed"), "正负交织")
    trend_label = {"improving": "📈 趋势向好", "stable": "➡️ 保持稳定", "declining": "📉 趋势下降"}.get(
        trend.get("sentiment_trend", "stable"), "➡️ 保持稳定")

    html = f"""<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>舆情监控报告 — {keyword}</title>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
<style>
:root {{
  --bg: #f0f2f5; --card: #ffffff; --text: #1a1a2e; --text2: #4b5563; --text3: #9ca3af;
  --border: #e5e7eb; --header-bg: linear-gradient(135deg,#1a1a2e,#16213e,#0f3460);
  --section-border: #f0f2f5; --input-bg: #f9fafb; --tag-bg: #f3f4f6; --tag-color: #6b7280;
  --hot-bg: #fef3c7; --hot-color: #92400e; --shadow: 0 2px 8px rgba(0,0,0,0.06);
}}
[data-theme="dark"] {{
  --bg: #0f172a; --card: #1e293b; --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
  --border: #334155; --section-border: #334155; --input-bg: #0f172a; --tag-bg: #334155;
  --tag-color: #94a3b8; --hot-bg: #451a03; --hot-color: #fbbf24; --shadow: 0 2px 8px rgba(0,0,0,0.3);
}}
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; background:var(--bg); color:var(--text); line-height:1.6; transition:background 0.3s,color 0.3s; }}
.container {{ max-width:1200px; margin:0 auto; padding:20px; }}

/* HEADER */
.header {{ background:var(--header-bg); color:white; padding:40px; border-radius:16px; margin-bottom:24px; position:relative; }}
.header h1 {{ font-size:28px; margin-bottom:8px; }}
.header .subtitle {{ opacity:0.85; font-size:14px; margin-top:4px; }}
.header-actions {{ position:absolute; top:20px; right:24px; display:flex; gap:10px; }}
.btn {{ padding:7px 16px; border-radius:8px; font-size:13px; font-weight:500; cursor:pointer; border:none; transition:all 0.2s; }}
.btn-ghost {{ background:rgba(255,255,255,0.15); color:white; }}
.btn-ghost:hover {{ background:rgba(255,255,255,0.25); }}
.btn-primary {{ background:#3b82f6; color:white; }}
.btn-primary:hover {{ background:#2563eb; }}

/* STATS */
.stats-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:16px; margin-bottom:24px; }}
.stat-card {{ background:var(--card); border-radius:12px; padding:20px 24px; box-shadow:var(--shadow); text-align:center; }}
.stat-number {{ font-size:36px; font-weight:700; }}
.stat-label {{ font-size:13px; color:var(--text2); margin-top:4px; }}
.stat-positive .stat-number {{ color:#10b981; }}
.stat-negative .stat-number {{ color:#ef4444; }}
.stat-neutral .stat-number {{ color:#6b7280; }}
.stat-total .stat-number {{ color:#3b82f6; }}
.stat-risk .stat-number {{ color:{risk_color}; font-size:24px; }}

/* SECTION */
.section {{ background:var(--card); border-radius:12px; padding:24px; margin-bottom:24px; box-shadow:var(--shadow); }}
.section h2 {{ font-size:20px; margin-bottom:16px; padding-bottom:12px; border-bottom:2px solid var(--section-border); }}

/* CHARTS */
.charts-row {{ display:grid; grid-template-columns:1fr 1fr; gap:24px; }}
.charts-row-3 {{ display:grid; grid-template-columns:1fr 1fr 1fr; gap:24px; }}
@media(max-width:768px) {{ .charts-row,.charts-row-3 {{ grid-template-columns:1fr; }} }}
.chart-box {{ background:var(--card); border-radius:12px; padding:20px; box-shadow:var(--shadow); }}
.chart-title {{ font-size:15px; font-weight:600; margin-bottom:12px; }}
.chart {{ width:100%; height:260px; }}
.chart-wide {{ width:100%; height:220px; }}

/* TREND */
.trend-badges {{ display:flex; gap:12px; margin-bottom:16px; flex-wrap:wrap; }}
.trend-badge {{ background:var(--tag-bg); border:1px solid var(--border); padding:8px 16px; border-radius:8px; font-size:14px; color:var(--text); }}
.hot-topic {{ display:inline-block; background:var(--hot-bg); color:var(--hot-color); padding:4px 12px; border-radius:20px; font-size:13px; margin-right:8px; margin-bottom:8px; }}
.findings-list {{ padding-left:20px; }}
.findings-list li {{ margin-bottom:8px; font-size:14px; color:var(--text2); }}

/* PLATFORM BARS */
.platform-row {{ display:flex; align-items:center; margin-bottom:12px; }}
.platform-name {{ width:90px; font-size:14px; font-weight:500; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }}
.platform-bar-wrapper {{ flex:1; margin:0 12px; }}
.platform-bar {{ height:22px; border-radius:11px; display:flex; overflow:hidden; background:var(--border); }}
.bar-positive {{ background:#10b981; }}
.bar-negative {{ background:#ef4444; }}
.bar-neutral {{ background:#9ca3af; }}
.bar-mixed {{ background:#a78bfa; }}
.platform-count {{ width:45px; text-align:right; font-size:13px; color:var(--text3); }}

/* FILTER BAR */
.filter-bar {{ display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; align-items:center; }}
.filter-input {{ flex:1; min-width:200px; padding:8px 14px; border-radius:8px; border:1px solid var(--border); background:var(--input-bg); color:var(--text); font-size:14px; outline:none; }}
.filter-input:focus {{ border-color:#3b82f6; }}
.filter-select {{ padding:8px 12px; border-radius:8px; border:1px solid var(--border); background:var(--input-bg); color:var(--text); font-size:14px; outline:none; cursor:pointer; }}
.filter-count {{ font-size:13px; color:var(--text3); white-space:nowrap; }}

/* ITEM CARDS */
.items-list {{ }}
.item-card {{ border:1px solid var(--border); border-radius:10px; padding:16px; margin-bottom:12px; transition:box-shadow 0.2s,transform 0.1s; cursor:default; }}
.item-card:hover {{ box-shadow:0 4px 16px rgba(0,0,0,0.1); transform:translateY(-1px); }}
.item-card.hidden {{ display:none; }}
.item-header {{ display:flex; align-items:center; gap:8px; margin-bottom:8px; flex-wrap:wrap; }}
.badge {{ padding:2px 10px; border-radius:20px; font-size:12px; font-weight:600; }}
.badge-positive {{ background:#d1fae5; color:#065f46; }}
.badge-negative {{ background:#fee2e2; color:#991b1b; }}
.badge-neutral {{ background:#f3f4f6; color:#4b5563; }}
.badge-mixed {{ background:#ede9fe; color:#5b21b6; }}
.source-badge {{ background:#dbeafe; color:#1e40af; padding:2px 10px; border-radius:20px; font-size:12px; }}
.official-badge {{ background:#fef9c3; color:#854d0e; padding:2px 8px; border-radius:20px; font-size:11px; }}
.kol-badge {{ background:#fce7f3; color:#9d174d; padding:2px 8px; border-radius:20px; font-size:11px; }}
.risk-badge {{ padding:2px 8px; border-radius:20px; font-size:11px; }}
.risk-badge.level-high {{ background:#fee2e2; color:#991b1b; }}
.risk-badge.level-medium {{ background:#fef3c7; color:#92400e; }}
.risk-badge.level-low {{ background:#dbeafe; color:#1e40af; }}
.heat-badge {{ font-size:13px; }}
.item-date {{ margin-left:auto; font-size:12px; color:var(--text3); }}
.item-title {{ font-size:15px; margin-bottom:6px; font-weight:600; }}
.item-title a {{ color:var(--text); text-decoration:none; }}
.item-title a:hover {{ color:#3b82f6; }}
.item-summary {{ font-size:13px; color:var(--text2); line-height:1.7; }}
.item-keypoints {{ margin-top:8px; }}
.keypoint {{ font-size:12px; color:var(--text2); padding:2px 0; }}
.keypoint::before {{ content:"• "; color:#3b82f6; }}
.item-tags {{ margin-top:8px; display:flex; flex-wrap:wrap; gap:4px; }}
.tag {{ background:var(--tag-bg); color:var(--tag-color); padding:2px 8px; border-radius:4px; font-size:12px; }}
.no-results {{ text-align:center; padding:40px; color:var(--text3); font-size:15px; display:none; }}

/* RISK CARDS */
.risk-card {{ border-radius:10px; padding:16px; margin-bottom:12px; }}
.risk-card.level-high {{ background:#fef2f2; border-left:4px solid #ef4444; }}
.risk-card.level-medium {{ background:#fffbeb; border-left:4px solid #f59e0b; }}
.risk-card.level-low {{ background:#eff6ff; border-left:4px solid #3b82f6; }}
[data-theme="dark"] .risk-card.level-high {{ background:#450a0a; }}
[data-theme="dark"] .risk-card.level-medium {{ background:#451a03; }}
[data-theme="dark"] .risk-card.level-low {{ background:#0c1a3d; }}
.risk-header {{ font-weight:600; margin-bottom:8px; font-size:15px; }}
.risk-desc {{ font-size:14px; color:var(--text2); margin-bottom:6px; }}
.risk-rec {{ font-size:13px; color:var(--text2); }}

/* COMPETITIVE TABLE */
.table-wrapper {{ overflow-x:auto; }}
.comp-table {{ width:100%; border-collapse:collapse; font-size:14px; }}
.comp-table th {{ text-align:left; padding:10px 12px; border-bottom:2px solid var(--border); color:var(--text2); font-weight:600; white-space:nowrap; }}
.comp-table td {{ padding:10px 12px; border-bottom:1px solid var(--border); vertical-align:middle; }}
.comp-table tr:last-child td {{ border-bottom:none; }}
.score-bar {{ display:inline-block; width:80px; height:8px; background:var(--border); border-radius:4px; overflow:hidden; vertical-align:middle; margin-right:6px; }}
.score-fill {{ height:100%; background:linear-gradient(90deg,#10b981,#3b82f6); border-radius:4px; }}
.score-num {{ font-size:13px; font-weight:600; color:#3b82f6; }}

/* TRACKING */
.track-meta {{ font-size:14px; color:var(--text2); margin-bottom:16px; }}
.track-timeline {{ position:relative; padding-left:24px; }}
.track-timeline::before {{ content:""; position:absolute; left:8px; top:0; bottom:0; width:2px; background:var(--border); }}
.track-item {{ position:relative; margin-bottom:20px; }}
.track-item::before {{ content:""; position:absolute; left:-20px; top:6px; width:10px; height:10px; background:#3b82f6; border-radius:50%; border:2px solid var(--card); }}
.track-stage {{ font-size:11px; background:#dbeafe; color:#1e40af; padding:1px 8px; border-radius:10px; display:inline-block; margin-bottom:4px; }}
.track-date {{ font-size:12px; color:var(--text3); }}
.track-desc {{ font-size:14px; color:var(--text); margin:2px 0; }}
.track-vol {{ font-size:12px; color:var(--text3); }}

/* NAV */
.sticky-nav {{ position:sticky; top:12px; z-index:100; background:var(--card); border-radius:12px; padding:10px 20px; box-shadow:var(--shadow); margin-bottom:24px; display:flex; gap:16px; align-items:center; flex-wrap:wrap; border:1px solid var(--border); }}
.nav-link {{ font-size:13px; color:var(--text2); text-decoration:none; white-space:nowrap; padding:4px 0; border-bottom:2px solid transparent; transition:all 0.2s; }}
.nav-link:hover {{ color:#3b82f6; border-bottom-color:#3b82f6; }}
.nav-spacer {{ flex:1; }}

/* FOOTER */
.footer {{ text-align:center; padding:20px; font-size:12px; color:var(--text3); }}

/* PRINT */
@media print {{
  .sticky-nav, .header-actions, .filter-bar {{ display:none!important; }}
  .item-card {{ break-inside:avoid; }}
  body {{ background:white; color:black; }}
  .section {{ box-shadow:none; border:1px solid #e5e7eb; }}
}}
</style>
</head>
<body>
<div class="container">

<!-- HEADER -->
<div class="header">
  <div class="header-actions">
    <button class="btn btn-ghost" onclick="toggleTheme()">🌙 暗色</button>
    <button class="btn btn-ghost" onclick="window.print()">🖨️ 打印</button>
  </div>
  <h1>📊 舆情监控报告 — "{keyword}"</h1>
  <div class="subtitle">
    生成时间：{generated_at[:19]} &nbsp;|&nbsp; 数据范围：{time_range} &nbsp;|&nbsp; 覆盖平台：{covered_platforms}
  </div>
</div>

<!-- NAV -->
<nav class="sticky-nav">
  <a class="nav-link" href="#section-overview">概览</a>
  <a class="nav-link" href="#section-charts">图表</a>
  <a class="nav-link" href="#section-trend">趋势</a>
  <a class="nav-link" href="#section-platform">平台</a>
  {'<a class="nav-link" href="#section-competitive">竞品</a>' if comp.get("enabled") else ''}
  {'<a class="nav-link" href="#section-tracking">传播</a>' if tracking.get("enabled") else ''}
  {'<a class="nav-link" href="#section-risk">风险</a>' if risks else ''}
  <a class="nav-link" href="#section-items">明细</a>
  <div class="nav-spacer"></div>
  <span style="font-size:12px;color:var(--text3)">共 {total} 条舆情</span>
</nav>

<!-- STATS -->
<div id="section-overview" class="stats-grid">
  <div class="stat-card stat-total"><div class="stat-number">{total}</div><div class="stat-label">📋 舆情总量</div></div>
  <div class="stat-card stat-positive"><div class="stat-number">{pos}</div><div class="stat-label">🟢 正面声量</div></div>
  <div class="stat-card stat-negative"><div class="stat-number">{neg}</div><div class="stat-label">🔴 负面声量</div></div>
  <div class="stat-card stat-neutral"><div class="stat-number">{neu}</div><div class="stat-label">🟡 中性/混合</div></div>
  <div class="stat-card stat-risk"><div class="stat-number">{risk_icon} {risk_text}</div><div class="stat-label">整体风险等级</div></div>
  {"" if not heat_index else f'<div class="stat-card"><div class="stat-number" style="color:#f59e0b;font-size:28px">{heat_index:.0f}</div><div class="stat-label">🔥 综合热度指数</div></div>'}
</div>

<!-- CHARTS -->
<div id="section-charts" class="section">
  <h2>📊 数据可视化</h2>
  <div class="charts-row">
    <div class="chart-box">
      <div class="chart-title">情感分布</div>
      <div id="chart-pie" class="chart"></div>
    </div>
    <div class="chart-box">
      <div class="chart-title">平台声量分布</div>
      <div id="chart-bar" class="chart"></div>
    </div>
  </div>
  {'<div class="chart-box" style="margin-top:16px"><div class="chart-title">情感趋势（时间轴）</div><div id="chart-line" class="chart-wide"></div></div>' if len(timeline) >= 2 else ''}
</div>

<!-- TREND -->
<div id="section-trend" class="section">
  <h2>📈 趋势分析</h2>
  <div class="trend-badges">
    <div class="trend-badge">整体情感：<strong>{sentiment_label}</strong></div>
    <div class="trend-badge">变化趋势：<strong>{trend_label}</strong></div>
    <div class="trend-badge">平台覆盖：<strong>{len(meta.get("platforms_covered",[]))} 个</strong></div>
  </div>
  <div style="margin-bottom:16px">{hot_topics_html or '<span style="color:var(--text3);font-size:13px">暂无热点话题</span>'}</div>
  {'<h3 style="font-size:16px;margin-bottom:8px;">🔍 核心发现</h3><ol class="findings-list">' + findings_html + '</ol>' if findings_html else ''}
  {'<h3 style="font-size:16px;margin:16px 0 8px;">💡 应对建议</h3><ol class="findings-list">' + recommendations_html + '</ol>' if recommendations_html else ''}
</div>

<!-- PLATFORM DISTRIBUTION -->
<div id="section-platform" class="section">
  <h2>🏷️ 平台声量分布</h2>
  <div style="margin-bottom:12px;display:flex;gap:16px;font-size:12px;color:var(--text3);">
    <span><span style="display:inline-block;width:10px;height:10px;background:#10b981;border-radius:2px;vertical-align:middle;margin-right:3px"></span>正面</span>
    <span><span style="display:inline-block;width:10px;height:10px;background:#ef4444;border-radius:2px;vertical-align:middle;margin-right:3px"></span>负面</span>
    <span><span style="display:inline-block;width:10px;height:10px;background:#9ca3af;border-radius:2px;vertical-align:middle;margin-right:3px"></span>中性</span>
  </div>
  {''.join([f"""
  <div class="platform-row">
    <div class="platform-name" title="{p.get('platform','')}">{p.get('platform','')}</div>
    <div class="platform-bar-wrapper">
      <div class="platform-bar">
        <div class="bar-positive" style="width:{p.get('positive',0)/p.get('count',1)*100 if p.get('count') else 0}%"></div>
        <div class="bar-negative" style="width:{p.get('negative',0)/p.get('count',1)*100 if p.get('count') else 0}%"></div>
        <div class="bar-neutral" style="width:{p.get('neutral',0)/p.get('count',1)*100 if p.get('count') else 0}%"></div>
        <div class="bar-mixed" style="width:{p.get('mixed',0)/p.get('count',1)*100 if p.get('count') else 0}%"></div>
      </div>
    </div>
    <div class="platform-count">{p.get('count',0)}条</div>
  </div>""" for p in sorted(platforms, key=lambda x: x.get('count',0), reverse=True)])}
</div>

{comp_html}
{tracking_html}

<!-- RISK ALERTS -->
{'<div id="section-risk" class="section"><h2>⚠️ 风险预警</h2>' + risks_html + '</div>' if risks_html else ''}

<!-- ITEMS -->
<div id="section-items" class="section">
  <h2>📋 舆情明细</h2>
  <div class="filter-bar">
    <input class="filter-input" id="search-input" type="text" placeholder="🔍 搜索标题、摘要、来源…" oninput="filterItems()">
    <select class="filter-select" id="filter-sentiment" onchange="filterItems()">
      <option value="">全部情感</option>
      <option value="positive">🟢 正面</option>
      <option value="negative">🔴 负面</option>
      <option value="neutral">🟡 中性</option>
      <option value="mixed">🔵 混合</option>
    </select>
    <select class="filter-select" id="filter-platform" onchange="filterItems()">
      <option value="">全部平台</option>
      {''.join([f'<option value="{p.get("platform","")}">{p.get("platform","")}</option>' for p in platforms])}
    </select>
    <select class="filter-select" id="filter-risk" onchange="filterItems()">
      <option value="">全部风险</option>
      <option value="high">🔴 高风险</option>
      <option value="medium">🟠 中风险</option>
      <option value="low">🟡 低风险</option>
    </select>
    <span class="filter-count" id="filter-count">共 {total} 条</span>
  </div>
  <div id="items-list"></div>
  <div class="no-results" id="no-results">😶 没有匹配的舆情条目</div>
</div>

<div class="footer">Sentiment Monitor Report v2 · Generated by BoxAI · {generated_at[:10]}</div>
</div>

<script>
// ==================== 数据 ====================
const ITEMS = {items_json};
const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';

// ==================== 主题切换 ====================
function toggleTheme() {{
  const html = document.documentElement;
  const newTheme = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', newTheme);
  document.querySelectorAll('.btn-ghost')[0].textContent = newTheme === 'dark' ? '☀️ 亮色' : '🌙 暗色';
  updateChartTheme();
}}

// ==================== 条目渲染 ====================
function renderItems(list) {{
  const container = document.getElementById('items-list');
  const noRes = document.getElementById('no-results');
  document.getElementById('filter-count').textContent = '共 ' + list.length + ' 条';
  if (list.length === 0) {{ container.innerHTML = ''; noRes.style.display = 'block'; return; }}
  noRes.style.display = 'none';
  const sentMap = {{positive:'正面',negative:'负面',neutral:'中性',mixed:'混合'}};
  const badgeMap = {{positive:'badge-positive',negative:'badge-negative',neutral:'badge-neutral',mixed:'badge-mixed'}};
  const riskMap = {{high:'⚠️ 高风险',medium:'🔶 中风险',low:'ℹ️ 低风险'}};
  container.innerHTML = list.map(item => {{
    const s = item.sentiment || 'neutral';
    const risk = item.risk_level;
    const riskHtml = (risk && risk !== 'none') ? `<span class="risk-badge level-${{risk}}">${{riskMap[risk]||''}}</span>` : '';
    const officialHtml = item.is_official ? '<span class="official-badge">🏛️ 官方</span>' : '';
    const kolHtml = item.is_kol ? '<span class="kol-badge">⭐ KOL</span>' : '';
    const heat = item.heat_index || 0;
    const heatHtml = heat >= 100 ? `<span class="heat-badge">${{heat>=10000?'🔥🔥🔥':heat>=1000?'🔥🔥':'🔥'}}</span>` : '';
    const tagsHtml = (item.tags||[]).map(t => `<span class="tag">${{t}}</span>`).join('');
    const kpsHtml = (item.key_points||[]).slice(0,2).map(k => `<div class="keypoint">${{k}}</div>`).join('');
    return `<div class="item-card">
      <div class="item-header">
        <span class="badge ${{badgeMap[s]}}">${{sentMap[s]||s}}</span>
        <span class="source-badge">${{item.source||''}}</span>
        ${{officialHtml}}${{kolHtml}}${{riskHtml}}${{heatHtml}}
        <span class="item-date">${{item.published_at||''}}</span>
      </div>
      <h3 class="item-title"><a href="${{item.url||'#'}}" target="_blank">${{item.title||''}}</a></h3>
      <p class="item-summary">${{item.summary||''}}</p>
      ${{kpsHtml ? '<div class="item-keypoints">'+kpsHtml+'</div>' : ''}}
      ${{tagsHtml ? '<div class="item-tags">'+tagsHtml+'</div>' : ''}}
    </div>`;
  }}).join('');
}}

// ==================== 筛选 ====================
function filterItems() {{
  const q = document.getElementById('search-input').value.trim().toLowerCase();
  const sentiment = document.getElementById('filter-sentiment').value;
  const platform = document.getElementById('filter-platform').value;
  const risk = document.getElementById('filter-risk').value;
  const result = ITEMS.filter(item => {{
    if (sentiment && item.sentiment !== sentiment) return false;
    if (platform && item.source !== platform) return false;
    if (risk && item.risk_level !== risk) return false;
    if (q) {{
      const text = [(item.title||''),(item.summary||''),(item.source||'')].join(' ').toLowerCase();
      if (!text.includes(q)) return false;
    }}
    return true;
  }});
  renderItems(result);
}}

// ==================== ECharts ====================
let chartPie, chartBar, chartLine;
function initCharts() {{
  const theme = isDark() ? 'dark' : '';
  const textColor = isDark() ? '#94a3b8' : '#4b5563';
  const bgColor = isDark() ? '#1e293b' : '#ffffff';

  // 情感饼图
  chartPie = echarts.init(document.getElementById('chart-pie'), theme, {{renderer:'canvas'}});
  chartPie.setOption({{
    backgroundColor: 'transparent',
    tooltip: {{ trigger:'item', formatter:'{{b}}: {{c}} ({{d}}%)' }},
    legend: {{ bottom:0, textStyle:{{color:textColor}} }},
    series: [{{
      name:'情感分布', type:'pie', radius:['35%','65%'],
      center:['50%','45%'],
      data: {pie_data_str},
      color: ['#10b981','#ef4444','#9ca3af','#a78bfa'],
      label: {{ color:textColor }},
      emphasis: {{ itemStyle: {{ shadowBlur:10, shadowOffsetX:0, shadowColor:'rgba(0,0,0,0.3)' }} }}
    }}]
  }});

  // 平台柱状图
  chartBar = echarts.init(document.getElementById('chart-bar'), theme, {{renderer:'canvas'}});
  chartBar.setOption({{
    backgroundColor: 'transparent',
    tooltip: {{ trigger:'axis', axisPointer:{{type:'shadow'}} }},
    legend: {{ bottom:0, textStyle:{{color:textColor}} }},
    grid: {{ left:'3%', right:'4%', bottom:'15%', top:'3%', containLabel:true }},
    xAxis: {{ type:'category', data:{platform_names_str}, axisLabel:{{color:textColor,rotate:30,fontSize:11}}, axisLine:{{lineStyle:{{color:textColor}}}} }},
    yAxis: {{ type:'value', axisLabel:{{color:textColor}}, splitLine:{{lineStyle:{{color:isDark()?'#334155':'#f0f2f5'}}}} }},
    series: [
      {{ name:'正面', type:'bar', stack:'total', data:{platform_pos_str}, itemStyle:{{color:'#10b981'}} }},
      {{ name:'负面', type:'bar', stack:'total', data:{platform_neg_str}, itemStyle:{{color:'#ef4444'}} }},
      {{ name:'中性', type:'bar', stack:'total', data:{platform_neu_str}, itemStyle:{{color:'#9ca3af'}} }}
    ]
  }});

  // 趋势折线图
  const lineEl = document.getElementById('chart-line');
  if (lineEl && {has_timeline}) {{
    chartLine = echarts.init(lineEl, theme, {{renderer:'canvas'}});
    chartLine.setOption({{
      backgroundColor: 'transparent',
      tooltip: {{ trigger:'axis' }},
      legend: {{ right:0, textStyle:{{color:textColor}} }},
      grid: {{ left:'3%', right:'10%', bottom:'5%', top:'8%', containLabel:true }},
      xAxis: {{ type:'category', data:{tl_dates}, axisLabel:{{color:textColor,fontSize:11}}, axisLine:{{lineStyle:{{color:textColor}}}} }},
      yAxis: {{ type:'value', axisLabel:{{color:textColor}}, splitLine:{{lineStyle:{{color:isDark()?'#334155':'#f0f2f5'}}}} }},
      series: [
        {{ name:'正面', type:'line', smooth:true, data:{tl_pos}, itemStyle:{{color:'#10b981'}}, areaStyle:{{opacity:0.15}} }},
        {{ name:'负面', type:'line', smooth:true, data:{tl_neg}, itemStyle:{{color:'#ef4444'}}, areaStyle:{{opacity:0.15}} }},
        {{ name:'中性', type:'line', smooth:true, data:{tl_neu}, itemStyle:{{color:'#9ca3af'}}, areaStyle:{{opacity:0.1}} }}
      ]
    }});
  }}
}}

function updateChartTheme() {{
  if (chartPie) {{ chartPie.dispose(); }}
  if (chartBar) {{ chartBar.dispose(); }}
  if (chartLine) {{ chartLine.dispose(); }}
  initCharts();
}}

// ==================== 响应式 ====================
window.addEventListener('resize', () => {{
  chartPie && chartPie.resize();
  chartBar && chartBar.resize();
  chartLine && chartLine.resize();
}});

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {{
  renderItems(ITEMS);
  initCharts();
}});
</script>
</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"✅ 报告已生成: {output_path}")
    print(f"   总条目: {total} | 正面: {pos} | 负面: {neg} | 中性: {neu} | 混合: {mixed}")
    print(f"   覆盖平台: {len(meta.get('platforms_covered', []))} 个")
    print(f"   整体风险: {risk_text}")


def main():
    parser = argparse.ArgumentParser(description="舆情监控 HTML 报告生成器 v2")
    parser.add_argument("--input", "-i", required=True, help="输入 JSON 数据文件路径")
    parser.add_argument("--output", "-o", required=True, help="输出 HTML 报告路径")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"❌ 输入文件不存在: {args.input}")
        sys.exit(1)

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    generate_html(data, args.output)


if __name__ == "__main__":
    main()
