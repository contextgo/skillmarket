---
name: sentiment-monitor
version: 2.0.0
description: Multi-platform sentiment monitoring and public opinion analysis tool with scheduled notification support
triggers:
  - 舆情监控
  - 舆情分析
  - 舆论分析
  - 口碑监控
  - 品牌监控
  - public opinion
  - sentiment analysis
  - brand monitoring
  - 舆情报告
  - 定时舆情
  - 舆情汇报
  - 舆情通知
  - 每天汇报
  - 定期监控
  - 竞品对比
  - 竞品舆情
  - 传播分析
  - 热点追踪
---

**📁 SKILL DIRECTORY PATH**

`{skillDir}`

**📂 DIRECTORY CONFIGURATION**

**Working Directory**: `/Users/blaze/Documents/box`
- This is the user's project root directory
- Final deliverables should be saved to `/Users/blaze/Documents/box/output/f916eef0-2844-414a-a99c-41db1d91d7f9`

**Session Temp Directory**: `/Users/blaze/Documents/box/.session_tmps/f916eef0-2844-414a-a99c-41db1d91d7f9`
- This is a dedicated temp directory for this session

**⚠️ CRITICAL FILE OPERATION RULES**:
1. All intermediate/temporary files (HTML, JS scripts, images, thumbnails, cache, etc.) MUST be written to the Session Temp Directory
2. Do NOT create "workspace/", "temp/", or other directories under Working Directory for intermediate files
3. Final deliverables (e.g., output HTML report) should be saved to `/Users/blaze/Documents/box/output/f916eef0-2844-414a-a99c-41db1d91d7f9` or user-specified location

**🚨 MANDATORY FILES (READ FIRST):**

- `{skillDir}/references/platforms.md`
- `{skillDir}/references/report_schema.md`

---

# 🔍 Sentiment Monitor v2 — 多平台舆情监控与智能分析

## 📋 支持的监控模式

| 模式 | 触发关键词 | 说明 |
|------|-----------|------|
| **标准监控** | 监控/分析/报告 | 单关键词全面舆情分析 |
| **竞品对比** | 竞品对比/品牌对比/vs | 多品牌横向对比分析 |
| **热点追踪** | 热点追踪/事件追踪 | 聚焦单一事件传播链路 |
| **负面预警** | 负面预警/风险监控 | 仅抓取负面/风险内容 |
| **定时推送** | 每天/每周/定时/定期 | 创建定时任务自动推送 |

---

## 🚀 工作流程

### Step 0: 识别监控模式

根据用户意图选择对应模式，若无法判断则询问用户：
- **多关键词**（用户提供多个词/品牌）→ 竞品对比模式
- **时间频率表达**（每天/每周等）→ 定时推送模式
- **单一事件**（某事件的传播/扩散）→ 热点追踪模式
- **其他** → 标准监控模式

### Step 1: 确认监控参数

向用户确认（尽量一次性问清，不要逐个询问）：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 关键词 | — | 必须，支持多个（竞品对比时） |
| 时间范围 | 近 7 天 | 可指定"近 24 小时"/"近 1 个月" |
| 平台范围 | 全平台 | 可筛选特定平台（见 platforms.md） |
| 关注维度 | 全面分析 | 正负面/风险/传播趋势/竞品 |
| 报告语言 | 中文 | 中文/英文 |

---

### Step 2: 多平台并行搜索（≥ 15 轮）

**核心原则：广撒网 · 多角度 · 深挖掘**

#### 第一批：核心平台 site 搜索（6 个并行）
```
{关键词} site:weibo.com
{关键词} site:news.qq.com OR site:new.qq.com
{关键词} site:163.com
{关键词} site:zhihu.com
{关键词} site:bilibili.com
{关键词} site:toutiao.com
```

#### 第二批：扩展平台搜索（6 个并行）
```
{关键词} site:douyin.com
{关键词} site:sohu.com OR site:sina.com.cn
{关键词} site:thepaper.cn OR site:caixin.com
{关键词} site:36kr.com OR site:huxiu.com
{关键词} site:mp.weixin.qq.com
{关键词} site:tieba.baidu.com OR site:baijiahao.baidu.com
```

#### 第三批：主题角度搜索（5 个并行）
```
{关键词} 争议 质疑 投诉 差评
{关键词} 好评 推荐 亮点 官方
{关键词} 数据 分析 报告 排名
{关键词} 最新 {当前年月}
{关键词} 海外 国际 出海（如适用）
```

#### 第四批：深度补充搜索（4 个并行）
```
{关键词} 事件 进展 声明 回应
{关键词} site:xiaohongshu.com OR {关键词} 小红书 种草
{关键词} site:hupu.com OR {关键词} 虎扑
{关键词} site:ithome.com OR {关键词} IT之家（科技类话题）
```

> **竞品对比模式**：对每个品牌分别执行以上搜索，最终进行横向对比

**目标：每个平台 ≥ 3 条有效信息，总计 ≥ 60 条原始搜索结果**

---

### Step 3: 详情深度抓取（10-20 篇）

使用 `web_fetch` 抓取重点内容正文：

**优先级排序：**
1. 🔴 **官方声明 / 央媒报道**（权重最高，必抓）
2. 🟠 **深度分析 / 调查报道**（权威媒体 / 知乎高赞）
3. 🟡 **高互动社交内容**（转发量/点赞量高）
4. 🟢 **代表性评论汇总**（各平台典型声音）

**热点追踪模式额外抓取：**
- 事件时间线：搜索 `{关键词} 事件经过 时间线`
- 各方回应：搜索 `{关键词} 官方回应 声明 解释`
- 传播来源：抓取最早报道的原始链接

---

### Step 4: 智能分析与结构化整理

#### 4.1 情感分类（三级精细标注）

| 等级 | 标签 | 判断标准 |
|------|------|---------|
| 🟢 正面 | positive | 赞扬、支持、推荐、数据亮眼、官方认可 |
| 🔴 负面 | negative | 批评、质疑、投诉、差评、法律风险 |
| 🟡 中性 | neutral | 客观报道、数据陈述、无明显倾向 |
| 🔵 混合 | mixed | 正负面观点并存、理性评测 |

#### 4.2 风险等级评定

| 等级 | 标志 | 触发条件 |
|------|------|---------|
| 高风险 | 🔴 | 大规模负面扩散（>100 条/24h）/ 官方媒体点名 / 法律诉讼 |
| 中风险 | 🟠 | 持续争议（>7天）/ 口碑明显下滑 / KOL集体批评 |
| 低风险 | 🟡 | 个别负面声音 / 局部争议 / 可控范围 |
| 无风险 | 🟢 | 以正面/中性为主 |

#### 4.3 传播热度评估（热点追踪模式）

对高传播内容计算热度指数：
```
热度指数 = 浏览量×0.1 + 点赞×1 + 评论×3 + 转发×5
```
标注传播链路：原始来源 → 二次传播 → 裂变节点

#### 4.4 竞品对比分析（竞品对比模式）

针对每个品牌输出：
- 情感分布占比
- 平台覆盖广度
- 高频关键词差异
- 风险等级对比
- 综合口碑得分（0-100）

---

### Step 5: 生成可视化 HTML 报告

使用 `{skillDir}/scripts/generate_report.py` 生成报告。

**数据准备：** 将分析结果整理为 JSON，格式参考 `{skillDir}/references/report_schema.md`

**执行命令：**
```bash
python {skillDir}/scripts/generate_report.py --input {数据JSON路径} --output {报告路径}
```

**报告功能（v2 新增）：**
- 📊 **概览卡片**：总条数、正/负/中性占比、风险等级
- 📈 **ECharts 可视化**：情感饼图 + 平台分布柱状图 + 时间趋势折线图
- 🔥 **热度排行**：按热度指数排序的 Top 10 内容
- 🏷️ **标签词云**：高频关键词可视化
- 🔍 **实时搜索筛选**：按关键词/平台/情感/风险过滤条目
- ⚠️ **风险预警面板**：突出显示高风险内容
- 📝 **综合结论与建议**
- 🖨️ **一键打印/导出**：浏览器打印友好布局
- 🌙 **暗色模式**：自动跟随系统

---

### Step 6: 企微推送摘要（可选）

生成 Markdown 格式摘要推送企微，格式参考 `{skillDir}/references/wecom_template.md`

摘要要求：
- 长度 ≤ 4000 字节（企微限制）
- 包含：概览数据 + 今日热点（Top 3）+ 风险预警
- 同时推送 HTML 报告文件

---

## ⚙️ 注意事项

1. **覆盖广度**：确保 ≥ 10 个平台，每平台 ≥ 3 条数据
2. **时效性**：优先最近 7 天内容；热点追踪模式优先 24 小时内
3. **去重**：同一事件不同平台报道 → 保留最详尽 1-2 条，标注"另有 X 个平台转载"
4. **客观性**：情感分析基于文本事实，避免主观臆断
5. **中文编码**：JSON 数据用 `json.dump(data, ensure_ascii=False)` 输出
6. **大模型辅助**：对于语义模糊的内容，优先判断为中性，加注说明

---

## 📅 定时舆情通知模式

### 触发识别

当用户消息包含**时间频率 + 舆情监控**相关表达时，进入定时通知模式：

- "每天早上 7 点给我汇报 xxx 的舆情"
- "每天 9 点和 18 点监控 xxx"
- "每周一汇报 xxx 品牌口碑"
- "工作日下午 3 点推送 xxx 最新舆情"
- "每小时监控一次 xxx 的负面信息"

### 定时模式流程

#### Step A: 解析定时参数

从用户消息中提取：
- **关键词**：监控核心词（必须）
- **执行频率**：自然语言时间（如"每天7点"）
- **关注重点**：全面分析 / 仅负面预警（默认全面）
- **通知方式**：企微推送（默认开启）

#### Step B: 构建定时任务 Prompt

```
请使用 sentiment-monitor Skill 对关键词"{关键词}"执行舆情监控分析：

1. 加载 Skill: use_skill("sentiment-monitor")
2. 按照 SKILL.md 中的 Step 2~5 完整执行：
   - 多平台并行搜索（≥ 15 轮，覆盖 10+ 平台）
   - 详情深度抓取（10-20 篇）
   - 智能情感分析与结构化整理
   - 生成 HTML 可视化报告（含 ECharts 图表）
3. 完成后，生成 Markdown 格式舆情摘要（≤ 4000 字节），格式参考 wecom_template.md：
   - 📊 数据概览：总条数、正/负/中性/混合分布
   - 🔥 今日热点（前 3 条，含来源和摘要）
   - ⚠️ 风险预警（如有高/中风险项，附应对建议）
   - 📈 情感趋势判断（与上期对比，如有）
4. 通过企微推送 Markdown 摘要给用户
5. 同时将 HTML 完整报告作为文件推送
```

**仅负面预警 Prompt 变体：**
```
重点搜索"{关键词} 争议 投诉 负面 质疑 差评 问题"，仅分析和推送负面/风险信息。
如无负面舆情，推送："✅ {关键词} 当前无负面舆情，一切正常。"
```

#### Step C: 创建定时任务

使用 `scheduled_task_create` MCP 工具创建任务：

| 参数 | 说明 |
|------|------|
| name | "舆情监控-{关键词}" |
| schedule | 将自然语言转为 cron："每天7点" → `0 7 * * *` |
| prompt | Step B 构建的完整 Prompt |
| notifyWecom | true |
| enabled | true |

**多时间点处理**：如"每天 7 点和 19 点"，拆分为 2 个独立任务：
- `舆情监控-{关键词}-早报` → `0 7 * * *`
- `舆情监控-{关键词}-晚报` → `0 19 * * *`

**常用 cron 对照：**
```
每天 7 点        → 0 7 * * *
每天 9 点和 18 点 → 0 9 * * * 和 0 18 * * *
工作日下午 3 点   → 0 15 * * 1-5
每小时           → 0 * * * *
每周一 9 点       → 0 9 * * 1
```

#### Step D: 确认并反馈

创建成功后向用户反馈：

```
✅ 定时舆情监控已设置！

📌 监控关键词：{关键词}
⏰ 执行频率：{频率描述}
📢 通知方式：企微推送（Markdown 摘要 + HTML 完整报告）
🔄 状态：已启用

每次执行时，我会：
1. 全网 12+ 平台采集最新舆情（≥ 15 轮搜索）
2. 深度抓取 10-20 篇重点内容
3. AI 智能情感分析 + 风险评级
4. 生成带 ECharts 图表的可视化报告并推送

如需调整，你可以说：
- "暂停 xxx 的舆情监控"
- "把 xxx 的监控改为每周一次"
- "删除 xxx 的舆情监控任务"
- "立即执行一次 xxx 舆情"
```

### 定时任务管理指令

| 用户指令 | 操作 |
|---------|------|
| "暂停/停止 xxx 监控" | `scheduled_task_update` 设置 enabled=false |
| "恢复 xxx 监控" | `scheduled_task_update` 设置 enabled=true |
| "删除 xxx 监控" | `scheduled_task_delete` |
| "改为每周一执行" | `scheduled_task_update` 修改 schedule |
| "加上 yyy 关键词一起监控" | 修改任务 prompt 中的关键词 |
| "查看我的监控任务" | `scheduled_task_list` |
| "立即执行一次" | `scheduled_task_run` |
| "查看执行历史" | `scheduled_task_executions` |

---

## 🏆 竞品对比模式详解

### 触发条件

用户提供 2 个及以上品牌/关键词进行对比：
- "对比一下 A 和 B 的舆情"
- "xxx 和 yyy 的口碑哪个好"
- "我们公司 vs 竞品的舆情分析"

### 竞品对比流程

1. **分品牌搜索**：对每个品牌分别执行 Step 2 的搜索（可并行）
2. **独立分析**：每个品牌单独完成情感分析和风险评级
3. **横向对比**：生成对比矩阵，包括：
   - 情感分布对比（正/负/中性占比）
   - 平台声量对比（各平台提及数）
   - 热度指数对比
   - 风险等级对比
   - 高频关键词差异（各品牌的独特标签）
4. **综合口碑得分**（0-100）：
   ```
   得分 = 正面比例×60 + (1-风险系数)×20 + 平台覆盖度×10 + 时效性×10
   ```
5. **报告格式**：在标准报告基础上新增"竞品对比"章节

---

## 🔥 热点追踪模式详解

### 触发条件

- "追踪 xxx 事件的传播"
- "xxx 事件的舆情走向"
- "分析 xxx 话题的扩散路径"

### 热点追踪流程

1. **溯源搜索**：找到事件最早来源
   ```
   {关键词} 事件起源 最早 首发
   ```
2. **时间线构建**：按时间顺序整理事件经过
3. **传播节点识别**：标注关键 KOL / 媒体的放大作用
4. **各方回应收集**：
   - 当事方声明
   - 官方媒体态度
   - 网民主流观点
5. **趋势预判**：基于传播速度和情感走向预判后续走向

