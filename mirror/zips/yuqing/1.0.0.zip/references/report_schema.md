# 舆情报告数据结构规范 v2

## JSON Schema

```json
{
  "report_meta": {
    "keyword": "监控关键词",
    "keywords": ["关键词1", "关键词2"],
    "mode": "standard|competitive|tracking|alert",
    "generated_at": "2026-04-22T12:00:00+08:00",
    "time_range": "2026-04-15 ~ 2026-04-22",
    "total_items": 55,
    "platforms_covered": ["微博", "腾讯新闻", "知乎", "B站", "微信公众号", "小红书", "抖音", "今日头条", "澎湃新闻", "虎扑"],
    "sentiment_summary": {
      "positive": 22,
      "negative": 18,
      "neutral": 12,
      "mixed": 3
    },
    "overall_risk": "high|medium|low|none",
    "heat_index": 78.5
  },

  "items": [
    {
      "id": 1,
      "title": "文章/帖子标题",
      "url": "https://example.com/article/123",
      "source": "平台名称",
      "source_type": "social|news|community|video|official|wechat",
      "author": "作者/发布者（可选）",
      "published_at": "2026-04-20",
      "sentiment": "positive|negative|neutral|mixed",
      "sentiment_score": 0.85,
      "summary": "200字以内的内容摘要，说明核心观点和关键信息",
      "key_points": ["核心观点1", "核心观点2"],
      "risk_level": "high|medium|low|none",
      "heat_index": 1250.5,
      "engagement": {
        "views": 100000,
        "likes": 5000,
        "comments": 800,
        "shares": 200,
        "collects": 300
      },
      "tags": ["标签1", "标签2"],
      "is_repost": false,
      "original_source": "转载时注明原始来源",
      "is_official": false,
      "is_kol": false
    }
  ],

  "risk_alerts": [
    {
      "level": "high|medium|low",
      "title": "风险标题",
      "description": "风险详细描述，说明影响范围和严重程度",
      "related_items": [1, 3, 7],
      "spread_speed": "fast|medium|slow",
      "recommendation": "具体应对建议，包括短期和长期措施"
    }
  ],

  "trend_analysis": {
    "overall_sentiment": "mixed|positive|negative",
    "sentiment_trend": "improving|stable|declining",
    "hot_topics": ["热点话题1", "热点话题2", "热点话题3"],
    "key_findings": [
      "核心发现1（基于数据）",
      "核心发现2（基于数据）",
      "核心发现3（基于数据）"
    ],
    "recommendations": ["具体建议1", "具体建议2"],
    "timeline": [
      {
        "date": "2026-04-20",
        "positive": 5,
        "negative": 8,
        "neutral": 3,
        "event": "关键事件描述（如有）"
      }
    ]
  },

  "platform_breakdown": [
    {
      "platform": "微博",
      "count": 10,
      "positive": 4,
      "negative": 5,
      "neutral": 1,
      "mixed": 0,
      "top_topic": "该平台最热话题",
      "heat_index": 3200
    }
  ],

  "competitive_analysis": {
    "enabled": false,
    "brands": [
      {
        "name": "品牌A",
        "total_items": 30,
        "sentiment_summary": {"positive": 18, "negative": 8, "neutral": 4},
        "overall_score": 72.5,
        "risk_level": "low",
        "top_keywords": ["关键词1", "关键词2"],
        "platform_coverage": 8
      }
    ],
    "comparison_summary": "对比总结文字"
  },

  "tracking_timeline": {
    "enabled": false,
    "origin_source": "事件最早来源",
    "origin_date": "2026-04-18",
    "spread_path": [
      {
        "stage": 1,
        "date": "2026-04-18",
        "platform": "微博",
        "description": "事件初始发酵",
        "volume": 50
      }
    ],
    "key_nodes": [
      {
        "date": "2026-04-19",
        "event": "关键放大节点",
        "impact": "high|medium|low"
      }
    ]
  }
}
```

---

## 字段说明

### report_meta

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| keyword | string | ✅ | 主监控关键词 |
| keywords | array | ❌ | 竞品对比时多个关键词 |
| mode | string | ✅ | 监控模式 |
| generated_at | string | ✅ | 报告生成时间 ISO 8601 |
| time_range | string | ✅ | 数据覆盖时间范围 |
| total_items | number | ✅ | 舆情条目总数 |
| platforms_covered | array | ✅ | 覆盖的平台列表 |
| sentiment_summary | object | ✅ | 情感分布汇总（含 mixed） |
| overall_risk | string | ✅ | 整体风险等级 |
| heat_index | number | ❌ | 综合热度指数（0-100） |

### items

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | number | ✅ | 唯一编号 |
| title | string | ✅ | 标题 |
| url | string | ✅ | 原始链接 |
| source | string | ✅ | 来源平台 |
| source_type | string | ✅ | 来源类型（新增 wechat） |
| sentiment | string | ✅ | 情感倾向（新增 mixed） |
| sentiment_score | number | ❌ | 情感得分 0-1 |
| summary | string | ✅ | 内容摘要（≥ 50 字） |
| key_points | array | ❌ | 核心观点列表 |
| risk_level | string | ❌ | 风险等级 |
| heat_index | number | ❌ | 单条热度指数 |
| engagement | object | ❌ | 互动数据 |
| tags | array | ❌ | 分类标签 |
| is_repost | bool | ❌ | 是否为转载 |
| is_official | bool | ❌ | 是否为官方来源 |
| is_kol | bool | ❌ | 是否为 KOL/大V |

### risk_alerts

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| level | string | ✅ | 风险等级 |
| title | string | ✅ | 风险标题 |
| description | string | ✅ | 详细描述 |
| recommendation | string | ✅ | 应对建议 |
| spread_speed | string | ❌ | 传播速度 |

### trend_analysis.timeline

时间轴数据用于生成趋势折线图，每天一条记录。

| 字段 | 类型 | 说明 |
|------|------|------|
| date | string | 日期 YYYY-MM-DD |
| positive | number | 当日正面条数 |
| negative | number | 当日负面条数 |
| neutral | number | 当日中性条数 |
| event | string | 当日关键事件（如有） |

---

## 热度指数计算公式

```
heat_index = views × 0.1 + likes × 1 + comments × 3 + shares × 5 + collects × 2
```

热度等级划分：
- 🔥🔥🔥 超热（>10000）
- 🔥🔥 较热（1000-10000）
- 🔥 一般（100-1000）
- 普通（<100）

---

## 数据质量要求

| 指标 | 最低要求 | 推荐 |
|------|---------|------|
| 条目数 | ≥ 30 条 | ≥ 50 条 |
| 平台覆盖 | ≥ 8 个 | ≥ 10 个 |
| 情感标注 | 每条必须标注 | — |
| 内容摘要 | ≥ 50 字/条 | ≥ 100 字/条 |
| 去重 | 相同内容只保留最详版本 | — |
| 时效性 | 优先最近 7 天 | 最近 3 天占比 >60% |
| 时间轴 | 如时间范围 >3 天则必填 | — |
