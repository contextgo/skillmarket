# 企微推送模板规范

## 通用摘要模板（≤ 4000 字节）

```markdown
## 📊 {关键词} 舆情日报
> 📅 {日期} · 数据范围：近 7 天

**数据概览**
| 指标 | 数值 |
|------|------|
| 舆情总量 | {total} 条 |
| 🟢 正面 | {pos} 条（{pos_pct}%）|
| 🔴 负面 | {neg} 条（{neg_pct}%）|
| 🟡 中性/混合 | {neu} 条（{neu_pct}%）|
| 整体风险 | {risk_icon} {risk_text} |
| 情感趋势 | {trend_label} |

---

**🔥 今日热点（Top 3）**

1. **{title1}**
   来源：{source1} · {date1}
   {summary1_short}

2. **{title2}**
   来源：{source2} · {date2}
   {summary2_short}

3. **{title3}**
   来源：{source3} · {date3}
   {summary3_short}

---

{risk_section}

📄 [查看完整报告]({report_link})
```

---

## 风险预警区块（有风险时插入）

```markdown
**⚠️ 风险预警**

{risk_icon} **{risk_title}**
{risk_description_short}
💡 建议：{recommendation_short}
```

若无风险：
```markdown
**✅ 风险状态**
当前无明显负面风险，情况可控。
```

---

## 仅负面预警模板

```markdown
## 🚨 {关键词} 负面预警
> 📅 {日期}

检测到 **{neg}** 条负面舆情

**高风险内容**
{high_risk_items}

**中风险内容**
{medium_risk_items}

💡 **处置建议**
{top_recommendation}

📄 [查看完整报告]({report_link})
```

若无负面：
```markdown
## ✅ {关键词} 负面监控
> 📅 {日期}

✅ 当前无负面舆情，一切正常。
```

---

## 竞品对比推送模板

```markdown
## 🏆 竞品舆情对比报告
> 📅 {日期} · 监控品牌：{brand_list}

**口碑得分排行**
{rank_table}

**关键差异**
- {brand_a} 优势：{brand_a_advantage}
- {brand_b} 劣势：{brand_b_weakness}

**风险对比**
{risk_compare}

📄 [查看完整报告]({report_link})
```

---

## 格式规范

| 要求 | 说明 |
|------|------|
| 总长度 | ≤ 4000 字节（企微消息限制） |
| 语言 | 简洁、专业，避免情绪化表达 |
| 摘要截取 | 每条热点摘要 ≤ 60 字 |
| 建议文字 | 每条建议 ≤ 30 字 |
| 链接 | HTML 报告文件同步推送，Markdown 摘要提供链接锚点 |

## 推送流程

1. 生成 Markdown 文本（确保 ≤ 4000 字节）
2. 调用 `wecom_push_markdown` 推送文字摘要
3. 调用 `wecom_push_file` 推送 HTML 完整报告文件
4. 如有高风险内容，在摘要中置顶展示
