---
name: group-mind
version: 1.0.0
author: 玲瑶
description: |
  群聊好感度系统：让群聊 AI 记住每个成员，并根据好感度动态调整回复策略。
  
  触发词：群聊管理、好感度、群聊AI、群聊机器人、回复概率、
  群成员管理、用户好感、AI群聊、动态回复、群聊情绪、群互动、
  group chat ai、affection system、群成员好感度、群聊回复策略、
  @回复、被@必回、群聊助手、群机器人好感、
  不想每条消息都回、选择性回复、按概率回复
  
  使用场景：
  - QQ/微信群聊机器人：差异化对待不同好感度的用户
  - Discord Bot：记录成员互动历史，个性化回复
  - 直播弹幕 AI：对高互动用户优先回应
  - 社区助手：根据用户活跃度调整回复频率
---

# GroupMind 群聊好感度系统

## 能做什么

GroupMind 给群聊 AI 装上"记忆"和"偏好"——不再机械地响应每条消息，而是像真人一样有选择地互动。

### 核心系统

1. **好感度系统** — 每个用户独立维护好感度(0-100)，互动越多越高
2. **情绪系统** — AI 自身有情绪值，影响整体回复概率
3. **回复决策引擎** — `@必回`、普通消息按概率+好感度决策
4. **颜文字库** — 丰富的颜文字表情，匹配不同互动情绪

## 快速使用

```python
from group_mind import GroupMind

gm = GroupMind()

# 收到消息时调用
message = {
    "user": "小明",
    "content": "玲瑶你好！",
    "is_at_me": False
}

# 1. 判断是否回复
should_reply = gm.should_reply(message)

if should_reply:
    # 2. 获取回复风格（根据好感度）
    style = gm.get_reply_style("小明")
    
    # 3. 互动后更新好感度
    gm.update_affection("小明", delta=+2)
    
    # 4. 获取颜文字
    emoji = gm.get_emoji("happy")
    
    reply = f"你好呀~ {emoji}"
    print(reply)

# 5. 查看某用户好感度
info = gm.get_user_info("小明")
print(f"好感度: {info['affection']}, 互动次数: {info['count']}")

# 6. 好感度排行榜
top = gm.get_top_users(5)
```

## 回复决策逻辑

```
被 @           → 100% 回复
好感度 >= 80   → 60% 概率回复
好感度 >= 50   → 40% 概率回复
好感度 < 20    → 15% 概率回复
AI情绪值低     → 整体概率 × 0.5
```

## 好感度变化规则

| 触发事件 | 变化 |
|---------|------|
| 与 AI 互动 | +2 |
| AI 主动回复了该用户 | +1 |
| 超过 7 天未互动 | -5/天 |
| 用户发送负面消息 | -3 |

## 依赖

- Python 3.8+
- 无需第三方库（仅用标准库）
