# -*- coding: utf-8 -*-
"""
GroupMind - 群聊好感度系统
版本: 1.0.0

独立版本，无外部依赖，可直接集成到任意群聊 AI 项目。
"""

import json
import random
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any


# 颜文字库
EMOJIS = {
    "happy": ["(´▽`)", "(≧▽≦)", "ヽ(✿ﾟ▽ﾟ)ノ", "へへ"],
    "excited": ["(๑•̀ㅂ•́)و✧", "╰(*°▽°*)╯", "(≧∇≦)ﾉ"],
    "sad": ["(´;ω;`)", "( ; ; )", "(´╥ω╥`)"],
    "neutral": ["(´・ω・`)", "(・ω・)", "嗯嗯~"],
    "cute": ["(｡♥‿♥｡)", "(≧ω≦)", "(*´∀`)~♥"],
    "cool": ["(￣▽￣)", "( ̄︶ ̄)", "(¬‿¬)"],
}


class AffectionSystem:
    """
    好感度系统 - 每个用户独立好感度追踪

    好感度范围: 0-100
    - 0~20: 陌生人，回复概率低
    - 20~50: 普通群友
    - 50~80: 熟悉的朋友
    - 80~100: 好朋友，优先回复
    """

    def __init__(self, data_file: str = "./group_data/affection.json"):
        self._file = Path(data_file)
        self._file.parent.mkdir(parents=True, exist_ok=True)
        self._db: Dict[str, Dict] = self._load()

    def _load(self) -> Dict[str, Dict]:
        if self._file.exists():
            try:
                with open(self._file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save(self):
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump(self._db, f, ensure_ascii=False, indent=2)

    def get(self, user: str) -> int:
        return self._db.get(user, {}).get("affection", 30)

    def update(self, user: str, delta: int):
        if user not in self._db:
            self._db[user] = {
                "affection": 30,
                "count": 0,
                "first_seen": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat(),
            }
        data = self._db[user]
        data["affection"] = max(0, min(100, data["affection"] + delta))
        data["count"] = data.get("count", 0) + 1
        data["last_seen"] = datetime.now().isoformat()
        self._save()

    def touch(self, user: str):
        """记录互动（不改变好感度，只更新时间和次数）"""
        self.update(user, 0)

    def get_info(self, user: str) -> Dict:
        return self._db.get(user, {
            "affection": 30, "count": 0,
            "first_seen": None, "last_seen": None
        })

    def get_top(self, n: int = 10) -> List[Dict]:
        sorted_users = sorted(
            self._db.items(),
            key=lambda x: x[1].get("affection", 0),
            reverse=True
        )
        return [{"user": u, **d} for u, d in sorted_users[:n]]

    def decay_inactive(self, days: int = 7, decay: int = 5):
        """对超过 N 天未互动的用户衰减好感度"""
        threshold = datetime.now() - timedelta(days=days)
        changed = 0
        for user, data in self._db.items():
            last = data.get("last_seen")
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt < threshold:
                        data["affection"] = max(0, data["affection"] - decay)
                        changed += 1
                except Exception:
                    pass
        if changed:
            self._save()
        return changed


class MoodSystem:
    """
    情绪系统 - AI 自身的情绪值，影响整体回复概率

    情绪值范围: 0-100
    高情绪 → 更活跃，回复概率更高
    低情绪 → 更安静，回复概率降低
    """

    def __init__(self):
        self.mood: int = 60  # 默认60分，比较好心情

    def adjust(self, delta: int):
        self.mood = max(0, min(100, self.mood + delta))

    def get_multiplier(self) -> float:
        """获取回复概率乘数 (0.3 ~ 1.5)"""
        return 0.3 + (self.mood / 100) * 1.2

    def describe(self) -> str:
        if self.mood >= 80:
            return "超开心"
        elif self.mood >= 60:
            return "心情不错"
        elif self.mood >= 40:
            return "一般般"
        elif self.mood >= 20:
            return "有点低落"
        else:
            return "心情很差"


class ReplyDecision:
    """
    回复决策引擎

    决策逻辑：
    1. 被 @ → 100% 回复
    2. 关键词触发 → 高概率回复
    3. 普通消息 → 根据好感度 + 情绪值决定概率
    """

    # 基础回复概率（按好感度区间）
    BASE_PROB = [
        (80, 0.65),   # 好感度 >= 80 → 65%
        (60, 0.45),   # 好感度 >= 60 → 45%
        (40, 0.30),   # 好感度 >= 40 → 30%
        (20, 0.18),   # 好感度 >= 20 → 18%
        (0,  0.10),   # 好感度 < 20  → 10%
    ]

    # 触发关键词 → 高概率回复
    TRIGGER_KEYWORDS = ["玲瑶", "ai", "AI", "机器人", "你好", "在吗", "help", "帮我"]

    def decide(self, user: str, content: str, is_at_me: bool,
               affection: int, mood_multiplier: float) -> bool:
        # @必回
        if is_at_me:
            return True

        # 关键词触发（高概率）
        for kw in self.TRIGGER_KEYWORDS:
            if kw in content:
                prob = min(1.0, 0.8 * mood_multiplier)
                return random.random() < prob

        # 按好感度获取基础概率
        base = 0.10
        for threshold, p in self.BASE_PROB:
            if affection >= threshold:
                base = p
                break

        # 乘以情绪系数
        final_prob = min(1.0, base * mood_multiplier)
        return random.random() < final_prob


class GroupMind:
    """
    GroupMind - 群聊好感度系统（一体化接口）

    用法：
        gm = GroupMind()

        # 收到消息
        msg = {"user": "小明", "content": "玲瑶你好", "is_at_me": False}
        if gm.should_reply(msg):
            gm.on_replied(msg["user"])
            emoji = gm.get_emoji("happy")
            print(f"你好呀~ {emoji}")
    """

    def __init__(self, data_dir: str = "./group_data"):
        self.affection = AffectionSystem(f"{data_dir}/affection.json")
        self.mood = MoodSystem()
        self.decision = ReplyDecision()

    def should_reply(self, message: Dict[str, Any]) -> bool:
        """
        判断是否回复这条消息

        Args:
            message: {"user": str, "content": str, "is_at_me": bool}
        """
        user = message.get("user", "unknown")
        content = message.get("content", "")
        is_at = message.get("is_at_me", False)

        # 记录互动（不改变好感度）
        self.affection.touch(user)

        aff = self.affection.get(user)
        mult = self.mood.get_multiplier()

        return self.decision.decide(user, content, is_at, aff, mult)

    def on_replied(self, user: str, affection_delta: int = 2):
        """AI 回复后调用，增加好感度"""
        self.affection.update(user, affection_delta)

    def on_positive_message(self, user: str):
        """用户发正面消息（表扬、感谢等）"""
        self.affection.update(user, 3)
        self.mood.adjust(+5)

    def on_negative_message(self, user: str):
        """用户发负面消息（骂人、投诉等）"""
        self.affection.update(user, -3)
        self.mood.adjust(-3)

    def get_reply_style(self, user: str) -> str:
        """
        根据好感度获取回复风格建议

        Returns:
            "warm" | "normal" | "brief" | "cold"
        """
        aff = self.affection.get(user)
        if aff >= 80:
            return "warm"    # 热情亲切
        elif aff >= 50:
            return "normal"  # 正常友好
        elif aff >= 20:
            return "brief"   # 简短回复
        else:
            return "cold"    # 冷淡疏离

    def get_emoji(self, mood_type: str = "neutral") -> str:
        pool = EMOJIS.get(mood_type, EMOJIS["neutral"])
        return random.choice(pool)

    def get_user_info(self, user: str) -> Dict:
        """获取用户信息（好感度、互动次数等）"""
        info = self.affection.get_info(user)
        info["reply_style"] = self.get_reply_style(user)
        return info

    def get_top_users(self, n: int = 5) -> List[Dict]:
        """获取好感度最高的 N 个用户"""
        return self.affection.get_top(n)

    def daily_decay(self):
        """每日好感度衰减（建议每天调用一次）"""
        return self.affection.decay_inactive()

    def get_mood_info(self) -> str:
        return f"AI情绪: {self.mood.describe()}（{self.mood.mood}/100）"
