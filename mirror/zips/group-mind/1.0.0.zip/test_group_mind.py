# -*- coding: utf-8 -*-
"""
GroupMind 测试脚本
测试群聊好感度、回复决策、颜文字表情等核心功能
"""

import sys
import os
import time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from group_mind import GroupMind, MoodSystem


def test_affection_system():
    """测试好感度系统"""
    print("\n=== Test 1: Affection System ===")

    gm = GroupMind(data_dir="/tmp/group_test")

    user_ids = ["user_001", "user_002", "user_003"]

    # 模拟消息
    for uid in user_ids:
        msg = {"user": uid, "content": "hello", "is_at_me": False}
        gm.should_reply(msg)

    # 检查用户信息
    for uid in user_ids:
        info = gm.get_user_info(uid)
        print(f"  {uid}: affection={info.get('affection', 0)}")

    print("  [PASS] Affection system OK")


def test_reply_decision():
    """测试回复决策"""
    print("\n=== Test 2: Reply Decision ===")

    gm = GroupMind(data_dir="/tmp/group_test")

    test_cases = [
        ("@玲瑶 how is the weather?", {"user": "test", "content": "@玲瑶 how is the weather?", "is_at_me": True}),
        ("Hello everyone", {"user": "test", "content": "Hello everyone", "is_at_me": False}),
    ]

    for desc, msg in test_cases:
        should_reply = gm.should_reply(msg)
        print(f"  [{'PASS' if should_reply is not None else 'FAIL'}] {desc[:20]}")


def test_mood_system():
    """测试情绪系统"""
    print("\n=== Test 3: Mood System ===")

    mood = MoodSystem()
    print(f"  Initial mood: {mood.get_mood_value()}")
    print(f"  Multiplier: {mood.get_multiplier()}")

    print("  [PASS] Mood system OK")


def test_emoji():
    """测试颜文字"""
    print("\n=== Test 4: Emoji ===")

    gm = GroupMind(data_dir="/tmp/group_test")

    emojis = {
        "happy": gm.get_emoji("happy"),
        "sad": gm.get_emoji("sad"),
        "neutral": gm.get_emoji("neutral"),
    }

    for mood, emoji in emojis.items():
        print(f"  {mood}: {emoji}")

    print("  [PASS] Emoji system OK")


def test_reply_style():
    """测试回复风格"""
    print("\n=== Test 5: Reply Style ===")

    gm = GroupMind(data_dir="/tmp/group_test")

    # 模拟互动增加好感度
    for _ in range(10):
        gm.on_positive_message("fan_user")

    style = gm.get_reply_style("fan_user")
    print(f"  Reply style for active user: {style}")

    print("  [PASS] Reply style OK")


if __name__ == "__main__":
    print("=" * 60)
    print("GroupMind Test Suite")
    print("=" * 60)

    test_affection_system()
    test_reply_decision()
    test_mood_system()
    test_emoji()
    test_reply_style()

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
