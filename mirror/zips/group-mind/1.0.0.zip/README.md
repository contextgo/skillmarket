# GroupMind 群聊好感度系统

> 让群聊AI有记忆、有偏好，像真实好友一样相处

## 核心功能

### 1. 好感度系统
- 每用户独立好感度（0-100）
- 互动类型加权：点赞 > 回复 > 引用回复
- 好感度衰减：长期不互动会逐渐降低
- 关系等级：陌生人 → 认识 → 熟悉 → 好友

### 2. 回复决策引擎
- @消息 → 必定回复（可配置概率）
- 普通消息 → 按概率 + 好感度综合决定
- 冷却时间控制，避免刷屏
- 每小时最大回复数限制

### 3. 情绪值系统
- 全局情绪值（0-100）
- 正面消息 → 情绪上升
- 负面消息 → 情绪下降
- 情绪影响回复概率和语气

### 4. 颜文字表情库
- 30+ 精美颜文字
- 根据情绪和好感度智能选择
- 支持自定义表情

### 5. 三层回复架构
- 7B模型：智能回复（需要Ollama）
- 3B模型：轻量回复
- 固定模板：兜底回复

## 安装

```bash
pip install -r requirements.txt
```

## 快速使用

```python
from group_mind import GroupMind, GroupConfig

# 初始化
gm = GroupMind()

# 模拟用户互动
gm.interact("user_001", "点赞")    # 好感度 +5
gm.interact("user_001", "回复")    # 好感度 +3
gm.interact("user_002", "回复")    # 好感度 +3

# 获取用户好感度
aff = gm.get_affection("user_001")
print(f"好感度: {aff.affection}, 互动次数: {aff.interaction_count}")

# 判断是否回复
should_reply = gm.should_reply("大家好", is_at=False, user_id="user_001")
print(f"是否回复: {should_reply}")

# 生成回复
reply = gm.generate_reply("今天天气真好", style="casual", user_id="user_001")
print(reply)
```

## 配置选项

```python
config = GroupConfig(
    group_id="my_group",
    respond_probability=0.7,      # 普通消息回复概率
    at_reply_probability=0.95,    # @消息回复概率
    max_replies_per_hour=20,       # 每小时最大回复数
    min_affection_to_reply=20,     # 最低好感度要求
    mood_affect_probability=True,  # 情绪影响概率
)

gm = GroupMind(config=config)
```

## 好感度计算规则

| 互动类型 | 好感度变化 | 说明 |
|---------|-----------|------|
| 点赞 | +5 | 最轻量互动 |
| 回复 | +3 | 常规互动 |
| 引用回复 | +5 | 较高认可 |
| @提及 | +2 | 被关注 |
| 负面互动 | -5 | 被怼/被骂 |
| 长期不互动 | -1/天 | 自然衰减 |

## 关系等级

| 等级 | 好感度范围 | 特征 |
|------|-----------|------|
| 陌生人 | 0-19 | 冷淡回复，颜文字少 |
| 认识 | 20-39 | 礼貌回复 |
| 熟悉 | 40-69 | 正常互动 |
| 好友 | 70-100 | 热情回复，颜文字多 |

## 适用场景

- QQ/微信群聊机器人
- Discord服务器Bot
- 论坛自动回复
- 直播弹幕互动
- 社群运营助手

## 与其他方案的区别

| 功能 | 简单复读机 | 普通Bot | GroupMind |
|------|----------|---------|-----------|
| 记忆用户 | 无 | 有限 | 完整好感度 |
| 回复概率 | 固定 | 固定 | 动态调整 |
| 情绪系统 | 无 | 无 | 完整 |
| 颜文字 | 无 | 固定 | 智能选择 |
| 用户区分 | 无 | 简单 | 每用户独立 |

## API 参考

### GroupMind

| 方法 | 说明 |
|------|------|
| `interact(user_id, type)` | 记录用户互动 |
| `get_affection(user_id)` | 获取用户好感度 |
| `should_reply(message, is_at, user_id)` | 判断是否回复 |
| `generate_reply(content, style, user_id)` | 生成回复 |
| `get_all_users(limit)` | 获取所有用户 |
| `update_mood(delta)` | 更新情绪值 |

## 技术细节

- 依赖：Python 3.8+
- 无需外部API，纯本地运行
- 数据持久化：JSON文件
- 内存占用 < 10MB
- 响应时间 < 10ms

## License

MIT License
