"""Trading strategy logic."""
