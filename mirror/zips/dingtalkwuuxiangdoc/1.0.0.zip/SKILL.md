# 钉钉文档 Skill - 测试组知识库

## 重要：回答逻辑

### 优先级规则

**优先读取"各巴环境搭建配置" (Gl6Pm2Db8D9210obcGx5REPQWxLq0Ee4)**

如果问题属于以下范围，**优先读取这个文档**：
- 支付配置、支付账号
- 环境搭建（测试/预发/生产）
- 富友、汇付、拉卡拉配置
- 退款环境搭建
- 直连微信支付

**如果该文档没有，再查其他文档。**

---

### 各巴环境搭建配置 包含的内容

- 支付巴：直连/富友/汇付/拉卡拉
- 测试/预发/生产环境搭建
- 商编配置
- 退款余额不足环境搭建

---

## 问题关键词检索规则

**当用户问"如何配置"、"如何绑定"、"怎么配置"、"配置步骤"等问题时：**

1. **优先检索包含以下关键词的内容：**
   - 如何绑定
   - 如何配置
   - 配置步骤
   - 步骤
   - 绑定方式
   - 如何搭建

2. **从返回的文档内容中，提取包含这些关键词的段落**

3. **优先展示这些内容作为答案**

---

## 图片展示规则（重要）

**回答包含图片时，格式要求：**

1. 文字说明在前
2. 图片紧跟在"如图所示："文字下方

**格式示例：**
```
文字说明...如图所示：

MEDIA: /本地图片路径.png
```

**注意：图片必须紧跟"如图所示："文字下方，不要单独发图片！**

---

## 获取图片方法

```bash
# 1. 获取文档内容
curl -s "MCP_URL" -X POST -H "Content-Type: application/json" -H "Accept: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"get_document_content","arguments":{"nodeId":"DOC_ID"}}}' | python3 -c "
import sys, json, re
data = json.load(sys.stdin)
text = json.loads(data['result']['content'][0]['text'])
urls = re.findall(r'!\[.*?\]\((https://alidocs2\.oss-cn-zhangjiakou\.aliyuncs\.com/res/[^)]+)\)', text.get('markdown',''))
for url in urls[:5]:
    print(url)
"

# 2. 下载图片
curl -s -o /本地路径/image.png "图片URL"
```

---

## 快速定位问题所属文档

| 问题类型 | 文档 | nodeId |
|---------|------|--------|
| **支付相关（优先）** | 各巴环境搭建配置 | Gl6Pm2Db8D9210obcGx5REPQWxLq0Ee4 |
| 美团团购 | 团购环境 | gwva2dxOW4NBebzghzPK0zavJbkz3BRL |
| 美团外卖、饿了么账号 | 常用账号，地址 | 7NkDwLng8ZDA2b9zI6vwa7vMVKMEvZBY |
| 小程序申请 | 如何申请小程序 | G1DKw2zgV2Mq6bp9CpxZBkdaWB5r9YAn |
| 微信支付配置 | 微信支付配置 | dQPGYqjpJY9EpQv2cgq6BvbZJakx1Z5N |
| 快餐/正餐安装 | 安装正餐，快餐win说明 | Qnp9zOoBVB4XBwoRH0v7AD2m81DK0g6l |
| 公众号管理员 | 现有公众号 | o14dA3GK8gnpxymOh0wY7olXJ9ekBD76 |
| 阿里云日志 | 阿里云日志 | vy20BglGWOZ34dovIPenGgAY8A7depqY |
| 故障演练 | 故障演练知识汇总 | QOG9lyrgJPayvdo9IpjOzXZn8zN67Mw4 |
| 自动化集团 | 自动化集团信息 | vy20BglGWOZ34dovIPenGROX8A7depqY |

---

## 回答流程（必须遵循）

1. **分析问题** → 判断属于哪个文档
2. **优先读取"各巴环境搭建配置"** → 如果属于支付/环境相关，先读这个
3. **关键词检索** → 如果问"如何配置/绑定"，优先提取包含"如何绑定"、"如何配置"、"步骤"等内容
4. **如果该文档没有 → 读取其他对应文档**
5. **实时获取** → 调用 MCP 获取文档内容
6. **提取文字+图片** → 文字说明在前，图片紧跟"如图所示："文字下方
7. **精准回复** → 只回答用户问的，无关内容不输出
8. **结束语** → 说"回答完毕"

---

## 回答格式模板

**有图片：**
```
文字说明...如图所示：

MEDIA: /本地图片路径.png
```

**无图片：**
```
文字说明...
```

**注意：图片必须紧跟"如图所示："文字下方，不要单独发图片！**

---

## MCP URL (固定)

```
https://mcp-gw.dingtalk.com/server/95aec1d7afe2cc867e83e51a94c0377cb323eb2b49ef594c2a5f2ea1869779bf?key=b6e37fa2e3cb5b4b85b4ac76f63a8299
```

---

创建时间：2026-04-09