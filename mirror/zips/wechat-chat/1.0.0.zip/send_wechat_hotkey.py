# -*- coding: utf-8 -*-
"""
微信好友发消息工具 v2.0
使用快捷键方式发送微信消息，最稳定可靠

用法: python send_wechat_hotkey.py "联系人" "消息内容"
示例: python send_wechat_hotkey.py "周军伢" "你好！"
"""
import sys
import os
import time
import pyautogui
import pyperclip

# UTF-8 输出
if sys.platform == "win32":
    os.system("chcp 65001 >nul 2>&1")
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

pyautogui.PAUSE = 0.5
pyautogui.FAILSAFE = True


def send_wechat_message(contact, message):
    """
    发送微信消息给指定联系人

    Args:
        contact: 联系人名称（好友备注或昵称）
        message: 要发送的消息内容

    Returns:
        bool: 发送是否成功
    """
    print("=" * 50)
    print(f"发送消息")
    print(f"联系人: {contact}")
    print(f"消息: {message}")
    print("=" * 50)

    try:
        # 1. 打开微信 (Ctrl+Alt+W)
        print("\n[1/6] 打开微信窗口...")
        pyautogui.keyDown('ctrl')
        pyautogui.keyDown('alt')
        pyautogui.keyDown('w')
        pyautogui.keyUp('w')
        pyautogui.keyUp('alt')
        pyautogui.keyUp('ctrl')
        time.sleep(1.5)
        print("OK")

        # 2. 打开搜索框 (Ctrl+F)
        print("\n[2/6] 打开搜索框...")
        pyautogui.hotkey("ctrl", "f")
        time.sleep(1)
        print("OK")

        # 3. 输入联系人名称
        print(f"\n[3/6] 搜索联系人: {contact}")
        pyperclip.copy(contact)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.8)
        print("OK")

        # 4. 按 Enter 打开对话（可能需要按两次）
        print("\n[4/6] 打开对话窗口...")
        pyautogui.press("enter")
        time.sleep(0.5)
        pyautogui.press("enter")
        time.sleep(1.5)
        print("OK")

        # 5. 输入消息内容
        print("\n[5/6] 输入消息...")
        pyperclip.copy(message)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.5)
        print("OK")

        # 6. 发送消息 (Enter)
        print("\n[6/6] 发送消息...")
        pyautogui.press("enter")
        time.sleep(1)
        print("OK")

        print("\n" + "=" * 50)
        print("发送成功！")
        print("=" * 50)
        return True

    except Exception as e:
        print(f"\n发送失败: {str(e)}")
        return False


def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("\n用法:")
        print("  python send_wechat_hotkey.py <联系人> <消息内容>")
        print("\n示例:")
        print('  python send_wechat_hotkey.py "周军伢" "你好！"')
        print('  python send_wechat_hotkey.py "张老师" "明天下午3点开会"')
        sys.exit(1)

    contact = sys.argv[1]
    message = sys.argv[2]

    success = send_wechat_message(contact, message)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
