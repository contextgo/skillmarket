"""
俄语学习笔记生成器
根据转录结果生成 Obsidian 格式的学习笔记
"""
import json
import sys
from datetime import datetime
from typing import List, Dict

# 常用俄语词汇库（可扩展）
VOCABULARY_DB = {
    "привет": {"word": "привет", "type": "名词", "meaning": "你好/打招呼", "example": "Привет! Как дела?"},
    "спасибо": {"word": "спасибо", "type": "副词", "meaning": "谢谢", "example": "Спасибо за помощь!"},
    "пожалуйста": {"word": "пожалуйста", "type": "副词", "meaning": "请/不客气", "example": "Пожалуйста, помогите."},
    "сегодня": {"word": "сегодня", "type": "副词", "meaning": "今天", "example": "Сегодня хорошая погода."},
    "завтра": {"word": "завтра", "type": "副词", "meaning": "明天", "example": "Завтра я поеду в Москву."},
    "очень": {"word": "очень", "type": "副词", "meaning": "非常", "example": "Очень красиво!"},
    "люблю": {"word": "любить", "type": "动词", "meaning": "爱/喜欢", "example": "Я люблю тебя."},
    "жизнь": {"word": "жизнь", "type": "名词", "meaning": "生活/生命", "example": "Жизнь прекрасна!"},
    "работа": {"word": "работа", "type": "名词", "meaning": "工作", "example": "У меня интересная работа."},
    "дом": {"word": "дом", "type": "名词", "meaning": "房子/家", "example": "Мой дом - моя крепость."},
    "выходные": {"word": "выходные", "type": "名词(复)", "meaning": "休息日/周末", "example": "У меня выходные."},
    "спортзал": {"word": "спортзал", "type": "名词", "meaning": "健身房", "example": "Я хожу в спортзал."},
    "фитнес": {"word": "фитнес", "type": "名词", "meaning": "健身", "example": "Фитнес очень популярен."},
    "классно": {"word": "классно", "type": "副词", "meaning": "太棒了/很酷", "example": "Классно! Молодец!"},
    "интересно": {"word": "интересно", "type": "副词", "meaning": "有趣地", "example": "Интересно, правда?"},
    "надеюсь": {"word": "надеяться", "type": "动词", "meaning": "希望", "example": "Надеюсь, у тебя всё хорошо."},
    "удача": {"word": "удача", "type": "名词", "meaning": "好运", "example": "Всем удачи!"},
    "позитивный": {"word": "позитивный", "type": "形容词", "meaning": "积极的/乐观的", "example": "Оставайтесь позитивными!"},
}


def format_time(seconds: float) -> str:
    """格式化时间显示"""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return f"{minutes}:{secs:02d}"


def extract_words(text: str) -> List[str]:
    """从文本中提取独立单词"""
    import re
    # 提取俄语单词
    words = re.findall(r'[а-яёА-ЯЁ]+', text)
    return list(set(words))


def generate_notes(segments: List[Dict], video_name: str = "", output_format: str = "obsidian") -> str:
    """
    生成俄语学习笔记
    
    Args:
        segments: 转录结果分段
        video_name: 视频名称
        output_format: 输出格式（obsidian/markdown/text）
    
    Returns:
        str: 格式化后的笔记内容
    """
    date = datetime.now().strftime("%Y-%m-%d")
    date_display = datetime.now().strftime("%Y年%m月%d日")
    
    # 生成时间轴表格
    timeline = []
    for i, seg in enumerate(segments):
        start = format_time(seg["start"])
        end = format_time(seg["end"])
        timeline.append(f"| {start}-{end} | {seg['text']} |")
    
    timeline_md = "\n".join(timeline)
    
    # 生成词汇表
    all_words = []
    for seg in segments:
        words = extract_words(seg["text"])
        all_words.extend(words)
    all_words = list(set(all_words))
    
    vocab_lines = []
    for word in all_words[:20]:  # 最多20个词
        word_lower = word.lower()
        if word_lower in VOCABULARY_DB:
            v = VOCABULARY_DB[word_lower]
            vocab_lines.append(f"| {v['word']} | {v['type']} | {v['meaning']} | {v['example']} |")
    
    vocab_md = "\n".join(vocab_lines)
    
    # 生成完整笔记
    if output_format == "obsidian":
        notes = f"""---

## {date_display} 视频学习：{video_name}

> 来源：{video_name}

### 俄语原句

| 时间 | 俄语原文 | 中文翻译 |
|------|----------|----------|
{timeline_md}

### 词汇学习

| 俄语 | 词性 | 中文 | 例句 |
|------|------|------|------|
{vocab_md}

### 实用表达

{generate_expressions(segments)}

### 备注

视频日期：{date_display}

---
"""
    else:
        # 简化格式
        notes = f"""【{date_display}】{video_name}

俄语原文：
{chr(10).join([seg['text'] for seg in segments])}

---
"""
    
    return notes


def generate_expressions(segments: List[Dict]) -> str:
    """从片段中提取实用表达"""
    expressions = []
    
    for seg in segments:
        text = seg["text"].lower()
        
        if "привет" in text:
            expressions.append("- **Всем привет!** - 大家好！（打招呼）")
        if "спасибо" in text:
            expressions.append("- **Спасибо за...** - 感谢...（表达感谢）")
        if "надеюсь" in text:
            expressions.append("- **Надеюсь...** - 我希望...（表达希望）")
        if "удачи" in text or "удача" in text:
            expressions.append("- **Всем удачи!** - 祝大家好运！（结束语）")
        if "интересно" in text:
            expressions.append("- **Интересно!** - 真有趣！")
        if "классно" in text:
            expressions.append("- **Классно!** - 太棒了！")
    
    if not expressions:
        expressions = ["（从视频内容中提取关键表达）"]
    
    return "\n".join(expressions)


def save_notes(notes: str, output_path: str):
    """保存笔记到文件"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(notes)
    print(f"Notes saved to: {output_path}")


if __name__ == "__main__":
    # 从 stdin 读取 JSON 数据
    data = json.load(sys.stdin)
    segments = data.get("segments", [])
    video_name = data.get("video", "Unknown")
    
    notes = generate_notes(segments, video_name)
    print(notes)
