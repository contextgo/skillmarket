"""
俄语视频转录核心脚本
使用 Whisper + av 库从视频中提取俄语内容
"""
import av
import numpy as np
import whisper
import json
import sys
import os
import tempfile
import shutil

def transcribe_video(video_path: str, output_dir: str = None) -> dict:
    """
    从视频中转录俄语内容
    
    Args:
        video_path: 视频文件路径
        output_dir: 输出目录，默认为当前目录
    
    Returns:
        dict: 包含 segments 和 full_text
    """
    print(f"[1/4] Loading Whisper model...")
    model = whisper.load_model("base")
    
    # 复制到临时文件避免中文路径
    ext = os.path.splitext(video_path)[1]
    temp_video = os.path.join(tempfile.gettempdir(), f"temp_video_{os.getpid()}{ext}")
    shutil.copy(video_path, temp_video)
    print(f"[2/4] Processing: {os.path.basename(video_path)}")
    
    try:
        container = av.open(temp_video)
        audio_stream = container.streams.audio[0]
        
        # 重采样到 16kHz 单声道
        resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
        
        # 读取所有音频
        frames = []
        for frame in container.decode(audio=0):
            resampled = resampler.resample(frame)
            if resampled:
                for rf in resampled:
                    arr = rf.to_ndarray()
                    frames.append(arr.flatten())
        
        container.close()
        
        # 合并所有帧
        audio_data = np.concatenate(frames)
        audio_data = audio_data.astype(np.float32) / 32768.0
        
        print(f"[3/4] Transcribing (Russian)...")
        result = model.transcribe(audio_data, language="ru", task="transcribe")
        
        # 提取俄语内容
        russian_segments = []
        for seg in result["segments"]:
            text = seg["text"].strip()
            # 过滤：包含俄语字母
            has_cyrillic = any('\u0400' <= c <= '\u04FF' for c in text)
            if has_cyrillic:
                russian_segments.append({
                    "start": seg["start"],
                    "end": seg["end"],
                    "text": text
                })
        
        print(f"[4/4] Found {len(russian_segments)} Russian segments")
        
        # 保存结果
        if output_dir is None:
            output_dir = os.path.dirname(os.path.abspath(video_path))
        
        # 生成输出文件名
        base_name = os.path.splitext(os.path.basename(video_path))[0]
        output_txt = os.path.join(output_dir, f"{base_name}_russian.txt")
        output_json = os.path.join(output_dir, f"{base_name}_full.json")
        
        with open(output_txt, "w", encoding="utf-8") as f:
            for seg in russian_segments:
                f.write(f"{seg['text']}\n")
        
        with open(output_json, "w", encoding="utf-8") as f:
            json.dump({
                "segments": russian_segments,
                "full_text": result["text"],
                "video": video_path
            }, f, ensure_ascii=False, indent=2)
        
        return {
            "success": True,
            "segments": russian_segments,
            "full_text": result["text"],
            "output_txt": output_txt,
            "output_json": output_json
        }
        
    finally:
        # 清理临时文件
        if os.path.exists(temp_video):
            os.remove(temp_video)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python transcribe.py <video_path> [output_dir]")
        sys.exit(1)
    
    video_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    result = transcribe_video(video_path, output_dir)
    
    if result["success"]:
        print(f"\nSuccess! Output files:")
        print(f"  - {result['output_txt']}")
        print(f"  - {result['output_json']}")
    else:
        print("\nError occurred!")
        sys.exit(1)
