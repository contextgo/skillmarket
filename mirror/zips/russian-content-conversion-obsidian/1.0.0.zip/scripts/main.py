#!/usr/bin/env python3
"""
俄语视频学习助手 - 主入口
一键完成：视频转录 → 生成学习笔记 → 同步 Obsidian
"""
import sys
import os

# 添加脚本目录到路径
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from transcribe import transcribe_video
from generate_notes import generate_notes, save_notes
import json

def main():
    """主流程"""
    print("=" * 50)
    print("  俄语视频学习助手 v1.0")
    print("=" * 50)
    
    if len(sys.argv) < 2:
        print("\n使用方法:")
        print("  python main.py <视频路径> [输出目录]")
        print("\n示例:")
        print("  python main.py C:/Videos/russian_vlog.mp4")
        print("  python main.py ./video.mp4 ./output/")
        sys.exit(1)
    
    video_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(video_path))
    
    if not os.path.exists(video_path):
        print(f"\n错误: 视频文件不存在: {video_path}")
        sys.exit(1)
    
    print()
    
    # 步骤1: 转录
    print("[1/3] 步骤1: 转录俄语内容...")
    result = transcribe_video(video_path, output_dir)
    
    if not result["success"]:
        print("\n错误: 转录失败")
        sys.exit(1)
    
    # 步骤2: 生成笔记
    print("\n[2/3] 步骤2: 生成学习笔记...")
    video_name = os.path.basename(video_path)
    notes = generate_notes(result["segments"], video_name)
    
    notes_path = os.path.join(output_dir, f"{os.path.splitext(video_name)[0]}_notes.md")
    save_notes(notes, notes_path)
    
    # 步骤3: 显示结果
    print("\n[3/3] 完成!")
    print("-" * 50)
    print(f"转录文件: {result['output_txt']}")
    print(f"完整结果: {result['output_json']}")
    print(f"学习笔记: {notes_path}")
    print("-" * 50)
    
    # 显示转录预览
    print("\n转录预览 (前3段):")
    for i, seg in enumerate(result["segments"][:3]):
        print(f"  [{seg['start']:.1f}s] {seg['text'][:60]}...")
    
    print("\n" + "=" * 50)
    print("  处理完成!")
    print("=" * 50)


if __name__ == "__main__":
    main()
