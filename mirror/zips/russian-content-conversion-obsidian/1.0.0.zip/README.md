# 俄语视频学习助手

从俄语视频（vlog、教程等）中自动提取俄语对话内容，生成结构化的学习笔记。

## 安装

```bash
cd scripts
pip install -r requirements.txt
```

## 使用方法

### 方法1: Python CLI 工具

```bash
python main.py <视频路径> [输出目录]

# 示例
python main.py C:/Videos/russian_vlog.mp4
python main.py ./video.mp4 ./output/
```

### 方法2: 作为模块导入

```python
from transcribe import transcribe_video
from generate_notes import generate_notes

# 转录视频
result = transcribe_video("video.mp4")

# 生成笔记
notes = generate_notes(result["segments"], "my_video.mp4")
```

## 工作流程

1. **视频导入** - 自动处理中文路径
2. **俄语转录** - 使用 Whisper 语音识别
3. **内容生成** - 生成学习笔记（词汇、语法、实用表达）
4. **导出** - 保存为 Markdown 格式

## 输出文件

- `*_russian.txt` - 纯俄语文本
- `*_full.json` - 完整结果（含时间轴）
- `*_notes.md` - 学习笔记

## 依赖

- Python 3.8+
- openai-whisper
- av
- numpy
- scipy

## 注意事项

- 首次运行 Whisper 会自动下载模型（约 140MB）
- 推荐视频时长：30秒 - 10分钟
- 长视频处理时间较长，请耐心等待
