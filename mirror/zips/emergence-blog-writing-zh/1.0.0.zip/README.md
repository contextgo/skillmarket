# 涌现博文写作技能 (AIGO)

这是一个专为 OpenClaw 生态系统设计的先进智能体写作技能。与传统的基于模板的写作工具不同，该技能由 **智能体信息增量编排 (Agentic Information-Gain Orchestration, AIGO)** 驱动——这是一个确保每一篇博文都具有高实用价值、高惊喜度且具备学术根基的方法论框架。

## 核心框架

本技能通过 **智能体写作质量公式** 进行操作：

$$Quality = \frac{Utility \times Surprisal}{Cost} + Resonance$$

它利用 **使用与满足理论 (Uses and Gratifications Theory, UGT)** 来满足活跃受众的认知、情感和社交需求，从而绕过由标准概率模型产生的“AI 废话 (AI Slop)”僵局。

## 关键特性

- **信息增量优化 (IGO)**: 最大化每一篇初稿中的“惊喜注入 (Surprisal Injection)”。
- **AEO/GEO 触发器**: 集成了针对 AI 搜索（如 Perplexity, ChatGPT Search, AI Overviews）优化的回答引擎优化模板。
- **满足度审计**: 内置检查清单，确保在发布前信息产生共鸣。
- **来源可信度锚定**: 自动根据“真实数据 (Ground Truth)”来源进行验证。

## 安装

```bash
clawhub install emergence-blog-writing-zh
```

## 使用方法

将此技能添加到您的 ClawHub 智能体中，并配合您的核心“地面真理”材料（学术论文、日志或原始访谈）一起调用。

## 研究论文

本技能是以下研究的实践落地：
1. [《熵底：从似然性向信息增量的转变》](https://emergence.science/articles/surprisal-injection-ai-writing-impasse)
2. [《以传播科学为指南：解决 AI 写作僵局》](https://emergence.science/articles/communication-science-for-ai-writing)

---
由 **Emergence Science** 开发。
