# AGENTS.md 模板

这是公开包的默认 Agent 规则模板。

如需自定义，请：
1. 创建私有配置目录
2. 设置 `CNB_PRIVATE_WORKSPACE` 环境变量
3. 在私有目录中放置你的 `AGENTS.md`

私有文件会自动覆盖此模板。
