# -*- coding: utf-8 -*-
"""
企业知识库大脑 - 主入口模块

整合知识库管理、智能配单、方案管理、多格式导出等核心功能。

【使用说明】
导入本模块即可使用所有功能：
```python
import sys
sys.path.insert(0, './scripts')
from scripts import *
```

【模块说明】
- config: 配置管理
- utils: 工具包（数据模型、Excel、飞书）
- 知识库: 知识库管理（导入、搜索、更新、模板）
- 配单: 智能配单（配单逻辑、约束检测）
- 方案: 方案管理（保存、对比、调整）
- 导出: 多格式导出（Excel、PDF、飞书）

【命令行使用】
```bash
# 知识库管理
python scripts/知识库/搜索.py "旋转木马"
python scripts/知识库/导入.py --文件 产品表.xlsx

# 智能配单
python scripts/配单/智能配单.py --预算 500000 --风格 高端

# 方案管理
python scripts/方案/保存方案.py --列出
python scripts/方案/方案对比.py --方案1 PLAN-001 --方案2 PLAN-002

# 导出
python scripts/导出/导出Excel.py --方案-id PLAN-001
python scripts/导出/导出PDF.py --方案-id PLAN-001
```

【API使用示例】
```python
from scripts.config import 获取配置, 切换模式
from scripts.知识库.搜索 import 搜索产品
from scripts.配单.智能配单 import 生成配单方案
from scripts.方案.保存方案 import 保存方案
from scripts.导出.导出Excel import 导出报价单

# 1. 配置
config = 获取配置()
print(f"当前模式: {config['模式']}")

# 2. 搜索产品
结果 = 搜索产品("旋转木马", limit=10)
for p in 结果:
    print(f"- {p['名称']}: ¥{p['单价']:,.2f}")

# 3. 智能配单
配单结果 = 生成配单方案(
    预算=500000,
    风格="均衡",
    目标人群="儿童"
)
if 配单结果['成功']:
    for 方案 in 配单结果['方案列表']:
        print(f"方案 {方案['编号']}: ¥{方案['总价']:,.2f}")

# 4. 保存方案
saved = 保存方案(配单结果['方案列表'][0]['方案'], 名称="XX客户报价")
print(f"方案已保存: {saved['方案ID']}")

# 5. 导出Excel
导出报价单(配单结果['方案列表'][0]['方案'], "报价单.xlsx")
```
"""

import os
import sys

# 添加当前目录到路径
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)


# ==================== 版本信息 ====================

__version__ = "1.0.0"
__author__ = "企业知识库大脑"
__description__ = "企业级知识管理+智能配单+方案输出一体化助手"


# ==================== 导入子模块 ====================

# 配置模块
from . import config

# 工具包
from . import utils

# 知识库模块
from . import 知识库

# 配单模块
from . import 配单

# 方案模块
from . import 方案

# 导出模块
from . import 导出


# ==================== 快捷函数 ====================

def 获取版本信息() -> dict:
    """获取版本信息"""
    return {
        "版本": __version__,
        "作者": __author__,
        "描述": __description__
    }


def 初始化系统(模式: str = "个人") -> dict:
    """
    初始化系统配置
    
    参数:
        模式: 使用模式 (个人/团队)
    
    返回:
        初始化结果
    """
    from .config import 切换模式, 保存配置
    
    # 切换模式
    切换模式(模式)
    
    # 获取配置
    配置 = config.获取配置()
    
    return {
        "成功": True,
        "模式": 配置.get("模式"),
        "消息": f"系统已初始化为{模式}模式"
    }


def 获取模块列表() -> list:
    """获取可用模块列表"""
    return [
        {
            "模块": "config",
            "名称": "配置管理",
            "功能": "模式切换、飞书配置、数据路径管理"
        },
        {
            "模块": "utils",
            "名称": "工具包",
            "功能": "数据模型、Excel工具、飞书工具"
        },
        {
            "模块": "知识库",
            "名称": "知识库管理",
            "功能": "产品导入、搜索、更新、模板下载"
        },
        {
            "模块": "配单",
            "名称": "智能配单",
            "功能": "预算配单、约束检测、方案生成"
        },
        {
            "模块": "方案",
            "名称": "方案管理",
            "功能": "保存、对比、调整、归档"
        },
        {
            "模块": "导出",
            "名称": "多格式导出",
            "功能": "Excel报价单、PDF文档、飞书文档"
        }
    ]


def 快速配单(
    预算: float,
    风格: str = "均衡",
    目标人群: str = "",
    保存: bool = True
) -> dict:
    """
    快速配单快捷函数
    
    参数:
        预算: 总预算
        风格: 风格偏好
        目标人群: 目标人群
        保存: 是否自动保存
    
    返回:
        配单结果
    """
    from .配单.智能配单 import 生成配单方案, 分析配单结果
    from .方案.保存方案 import 保存方案
    
    # 生成配单
    配单结果 = 生成配单方案(
        预算=预算,
        风格=风格,
        目标人群=目标人群
    )
    
    if not 配单结果.get("成功"):
        return 配单结果
    
    # 分析结果
    分析 = 分析配单结果(配单结果)
    
    结果 = {
        "成功": True,
        "输入": 配单结果["输入参数"],
        "方案数": len(配单结果["方案列表"]),
        "推荐方案": 分析.get("推荐方案"),
        "方案列表": []
    }
    
    # 处理每个方案
    for 方案 in 配单结果["方案列表"]:
        方案数据 = {
            "编号": 方案["编号"],
            "总价": 方案["总价"],
            "预算使用率": 方案["预算使用率"],
            "设备数": 方案["产品数"]
        }
        
        # 自动保存
        if 保存:
            保存结果 = 保存方案(方案["方案"], 名称=f"快速配单-{方案['编号']}")
            if 保存结果.get("成功"):
                方案数据["方案ID"] = 保存结果["方案ID"]
        
        结果["方案列表"].append(方案数据)
    
    return 结果


def 快速导出(
    方案ID: str,
    格式: str = "excel"
) -> dict:
    """
    快速导出快捷函数
    
    参数:
        方案ID: 方案ID
        格式: 导出格式 (excel/pdf/feishu)
    
    返回:
        导出结果
    """
    from .方案.保存方案 import 获取方案
    from .utils.数据模型 import 方案 as 方案模型
    from .导出.导出Excel import 导出报价单
    from .导出.导出PDF import 导出PDF报价单
    from .导出.导出飞书 import 导出到飞书文档
    
    # 获取方案
    方案数据 = 获取方案(方案ID)
    if not 方案数据:
        return {"成功": False, "消息": f"方案 {方案ID} 不存在"}
    
    方案对象 = 方案模型.from_dict(方案数据)
    
    # 导出
    if 格式 == "excel":
        输出文件 = f"报价单_{方案ID}.xlsx"
        return 导出报价单(方案对象, 输出文件)
    elif 格式 == "pdf":
        输出文件 = f"报价单_{方案ID}.pdf"
        return 导出PDF报价单(方案对象, 输出文件)
    elif 格式 == "feishu":
        return 导出到飞书文档(方案对象)
    else:
        return {"成功": False, "消息": f"不支持的格式: {格式}"}


# ==================== 导出所有公开接口 ====================

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    "__description__",
    # 函数
    "获取版本信息",
    "初始化系统",
    "获取模块列表",
    "快速配单",
    "快速导出",
    # 子模块
    "config",
    "utils",
    "知识库",
    "配单",
    "方案",
    "导出"
]
