# -*- coding: utf-8 -*-
"""
导出模块初始化

提供多格式导出功能。

【模块说明】
- 导出Excel: 生成Excel报价单
- 导出PDF: 生成PDF报价文档
- 导出飞书: 导出到飞书文档/表格

【快速导入】
```python
from 导出.导出Excel import 导出报价单, 导出多方案对比
from 导出.导出PDF import 导出PDF报价单
from 导出.导出飞书 import 导出到飞书文档, 同步到飞书
```
"""

from .导出Excel import (
    导出报价单,
    导出多方案对比
)

from .导出PDF import (
    导出PDF报价单
)

from .导出飞书 import (
    导出到飞书文档,
    创建飞书报价表,
    同步到飞书,
    生成飞书格式内容
)

__all__ = [
    # Excel导出
    "导出报价单",
    "导出多方案对比",
    # PDF导出
    "导出PDF报价单",
    # 飞书导出
    "导出到飞书文档",
    "创建飞书报价表",
    "同步到飞书",
    "生成飞书格式内容"
]
