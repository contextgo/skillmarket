# -*- coding: utf-8 -*-
"""
导出飞书模块

将方案导出为飞书文档格式。

【使用说明】
- 支持创建飞书多维表格
- 支持创建飞书文档
- 自动同步方案数据

【命令行使用】
```bash
# 导出到飞书文档
python 导出飞书.py --方案-id PLAN-XXXX --创建文档

# 创建多维表格
python 导出飞书.py --方案-id PLAN-XXXX --创建表格
```

【代码使用】
```python
from 导出.导出飞书 import 导出到飞书文档, 创建飞书报价表

# 导出到飞书文档
结果 = 导出到飞书文档(方案对象, 标题="XX客户报价")

# 创建多维表格
结果 = 创建飞书报价表(方案对象)
```
"""

import os
import sys
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from utils.数据模型 import 方案, 设备项
from config import 获取飞书配置, 获取配置


# ==================== 常量定义 ====================

# 飞书字段映射
字段映射 = {
    "产品ID": "text",
    "名称": "text",
    "规格": "text",
    "单位": "text",
    "数量": "number",
    "单价": "currency",
    "小计": "currency"
}

# 文档模板
文档模板 = """
# {标题}

## 基本信息

| 项目 | 内容 |
|------|------|
| 客户名称 | {客户名} |
| 预算金额 | ¥{预算:,.2f} |
| 方案风格 | {风格} |
| 编制日期 | {日期} |

## 设备清单

| 序号 | 产品名称 | 型号规格 | 单位 | 数量 | 单价 | 小计 |
|------|----------|----------|------|------|------|------|
{设备表格}

## 汇总信息

- **设备数量**: {设备数} 台/套
- **报价总额**: ¥{总价:,.2f}
- **预算使用率**: {使用率:.1f}%

---

📌 **报价说明**：
1. 本报价单有效期为30天
2. 设备价格含税，不含安装调试费用
3. 具体交货期以签订合同为准

> 文档由企业知识库大脑自动生成
"""


# ==================== 飞书API函数 ====================

def 获取飞书客户端():
    """
    获取飞书客户端
    
    返回:
        (是否成功, 客户端, 消息)
    """
    from utils.飞书工具 import 飞书客户端, 创建飞书客户端 as 创建客户端
    
    飞书配置 = 获取飞书配置()
    
    if not 飞书配置.get("app_id") or not 飞书配置.get("app_secret"):
        return False, None, "飞书配置不完整"
    
    客户端 = 创建客户端(
        app_id=飞书配置["app_id"],
        app_secret=飞书配置["app_secret"]
    )
    
    成功, token, 消息 = 客户端.获取_token()
    
    if not 成功:
        return False, None, f"获取token失败: {消息}"
    
    return True, 客户端, "成功"


def 生成文档内容(方案_obj: 方案, 标题: str = "") -> str:
    """
    生成飞书文档内容
    
    参数:
        方案对象: 方案对象
        标题: 文档标题
    
    返回:
        文档内容
    """
    # 生成设备表格行
    设备行列表 = []
    for i, 设备 in enumerate(方案_obj.设备清单):
        行 = f"| {i+1} | {设备.名称} | {设备.规格} | {设备.单位 if hasattr(设备, '单位') else '台'} | {设备.数量} | ¥{设备.单价:,.2f} | ¥{设备.小计:,.2f} |"
        设备行列表.append(行)
    
    设备表格 = "\n".join(设备行列表)
    
    # 填充模板
    内容 = 文档模板.format(
        标题=标题 or f"{方案_obj.客户名}报价方案",
        客户名=方案_obj.客户名 or "待定",
        预算=方案_obj.预算,
        风格=方案_obj.风格 or "均衡",
        日期=datetime.now().strftime("%Y年%m月%d日"),
        设备表格=设备表格,
        设备数=len(方案_obj.设备清单),
        总价=方案_obj.总价,
        使用率=方案_obj.获取预算使用率()
    )
    
    return 内容


def 导出到飞书文档(
    方案_obj: 方案,
    标题: str = "",
    文件夹ID: str = ""
) -> Dict[str, Any]:
    """
    导出方案到飞书文档
    
    参数:
        方案对象: 方案对象
        标题: 文档标题
        文件夹ID: 飞书文件夹ID
    
    返回:
        导出结果
    """
    # 获取飞书客户端
    成功, 客户端, 消息 = 获取飞书客户端()
    
    if not 成功:
        return {
            "成功": False,
            "消息": 消息,
            "提示": "请先配置飞书连接"
        }
    
    try:
        # 生成文档标题
        if not 标题:
            标题 = f"{方案_obj.客户名}报价方案_{datetime.now().strftime('%Y%m%d')}"
        
        # 获取文件夹ID
        if not 文件夹ID:
            飞书配置 = 获取飞书配置()
            文件夹ID = 飞书配置.get("文档文件夹ID", "")
        
        # 创建文档
        成功, 结果, 消息 = 客户端.创建文档(
            标题=标题,
            parent_token=文件夹ID
        )
        
        if not 成功:
            return {
                "成功": False,
                "消息": f"创建文档失败: {消息}"
            }
        
        文档ID = 结果.get("document_id", "")
        
        # 生成文档内容
        内容 = 生成文档内容(方案_obj, 标题)
        
        # 更新文档内容
        成功2, 消息2 = 客户端.更新文档内容(文档ID, 内容)
        
        if 成功2:
            return {
                "成功": True,
                "消息": f"飞书文档已创建",
                "文档ID": 文档ID,
                "文档链接": f"https://.feishu.cn/document/{文档ID}"
            }
        else:
            return {
                "成功": True,
                "消息": f"文档已创建但内容更新失败: {消息2}",
                "文档ID": 文档ID,
                "文档链接": f"https://feishu.cn/document/{文档ID}"
            }
            
    except Exception as e:
        return {
            "成功": False,
            "消息": f"导出失败: {str(e)}"
        }


def 创建飞书报价表(
    方案_obj: 方案,
    名称: str = ""
) -> Dict[str, Any]:
    """
    创建飞书多维表格报价表
    
    参数:
        方案对象: 方案对象
        名称: 表格名称
    
    返回:
        创建结果
    """
    # 获取飞书客户端
    成功, 客户端, 消息 = 获取飞书客户端()
    
    if not 成功:
        return {
            "成功": False,
            "消息": 消息,
            "提示": "请先配置飞书连接"
        }
    
    try:
        # 表格名称
        if not 名称:
            名称 = f"{方案_obj.客户名}报价表_{datetime.now().strftime('%Y%m%d')}"
        
        # 创建多维表格
        成功, 结果, 消息 = 客户端.创建_bitable(
            name=名称
        )
        
        if not 成功:
            return {
                "成功": False,
                "消息": f"创建表格失败: {消息}"
            }
        
        表格ID = 结果.get("app_id", "")
        
        # 获取第一个表
        成功2, 表列表, 消息2 = 客户端.获取表格列表(表格ID)
        
        if not 成功2 or not 表列表:
            return {
                "成功": True,
                "消息": f"表格已创建但获取表失败",
                "表格ID": 表格ID
            }
        
        表ID = 表列表[0].get("table_id", "")
        
        # 添加字段
        字段列表 = [
            {"field_name": "序号", "type": 1},  # 单行文本
            {"field_name": "产品名称", "type": 1},
            {"field_name": "型号规格", "type": 1},
            {"field_name": "单位", "type": 1},
            {"field_name": "数量", "type": 2},  # 数字
            {"field_name": "单价", "type": 5},  # 货币
            {"field_name": "小计", "type": 5}   # 货币
        ]
        
        for 字段 in 字段列表:
            客户端.添加字段(表格ID, 表ID, 字段["field_name"], 字段["type"])
        
        # 添加设备数据
        记录列表 = []
        for 设备 in 方案_obj.设备清单:
            记录 = {
                "序号": {"type": 1, "value": {"text": [str(len(记录列表) + 1)]}},
                "产品名称": {"type": 1, "value": {"text": [设备.名称]}},
                "型号规格": {"type": 1, "value": {"text": [设备.规格]}},
                "单位": {"type": 1, "value": {"text": [设备.单位 if hasattr(设备, '单位') else '台']}},
                "数量": {"type": 2, "value": 设备.数量},
                "单价": {"type": 5, "value": 设备.单价},
                "小计": {"type": 5, "value": 设备.小计}
            }
            记录列表.append(记录)
        
        if 记录列表:
            客户端.批量添加记录(表格ID, 表ID, 记录列表)
        
        return {
            "成功": True,
            "消息": f"飞书报价表已创建",
            "表格ID": 表格ID,
            "表格链接": f"https://feishu.cn/base/{表格ID}"
        }
        
    except Exception as e:
        return {
            "成功": False,
            "消息": f"创建失败: {str(e)}"
        }


def 同步到飞书(
    方案ID: str,
    目标类型: str = "both"
) -> Dict[str, Any]:
    """
    将方案同步到飞书
    
    参数:
        方案ID: 方案ID
        目标类型: 目标类型 (doc/table/both)
    
    返回:
        同步结果
    """
    from 方案.保存方案 import 获取方案
    
    方案数据 = 获取方案(方案ID)
    
    if not 方案数据:
        return {
            "成功": False,
            "消息": f"方案 {方案ID} 不存在"
        }
    
    方案对象 = 方案.from_dict(方案数据)
    结果列表 = []
    
    # 导出文档
    if 目标类型 in ["doc", "both"]:
        文档结果 = 导出到飞书文档(方案对象)
        结果列表.append(("飞书文档", 文档结果))
    
    # 创建表格
    if 目标类型 in ["table", "both"]:
        表格结果 = 创建飞书报价表(方案对象)
        结果列表.append(("飞书表格", 表格结果))
    
    # 汇总结果
    成功数 = sum(1 for _, r in 结果列表 if r.get("成功"))
    
    return {
        "成功": 成功数 > 0,
        "消息": f"已完成 {成功数}/{len(结果列表)} 项同步",
        "结果": dict(结果列表)
    }


# ==================== 简化版本（不依赖飞书SDK）====================

def 生成飞书格式内容(方案_obj: 方案) -> Dict[str, Any]:
    """
    生成飞书格式的数据（供手动复制粘贴使用）
    
    参数:
        方案对象: 方案对象
    
    返回:
        格式化的数据
    """
    # 生成Markdown表格
    markdown表格 = "| 序号 | 产品名称 | 型号规格 | 单位 | 数量 | 单价 | 小计 |\n"
    markdown表格 += "|------|----------|----------|------|------|------|------|\n"
    
    for i, 设备 in enumerate(方案_obj.设备清单):
        markdown表格 += f"| {i+1} | {设备.名称} | {设备.规格} | {设备.单位 if hasattr(设备, '单位') else '台'} | {设备.数量} | ¥{设备.单价:,.2f} | ¥{设备.小计:,.2f} |\n"
    
    # 生成文本格式
    文本格式 = []
    文本格式.append(f"{'='*50}")
    文本格式.append(f"设备报价单")
    文本格式.append(f"{'='*50}")
    文本格式.append(f"客户: {方案_obj.客户名 or '待定'}")
    文本格式.append(f"预算: ¥{方案_obj.预算:,.2f}")
    文本格式.append(f"风格: {方案_obj.风格 or '均衡'}")
    文本格式.append(f"{'='*50}")
    文本格式.append("")
    
    for i, 设备 in enumerate(方案_obj.设备清单):
        文本格式.append(f"{i+1}. {设备.名称}")
        文本格式.append(f"   规格: {设备.规格}")
        文本格式.append(f"   数量: {设备.数量} {设备.单位 if hasattr(设备, '单位') else '台'}")
        文本格式.append(f"   单价: ¥{设备.单价:,.2f}")
        文本格式.append(f"   小计: ¥{设备.小计:,.2f}")
        文本格式.append("")
    
    文本格式.append(f"{'='*50}")
    文本格式.append(f"合计: ¥{方案_obj.总价:,.2f}")
    文本格式.append(f"设备数: {len(方案_obj.设备清单)} 台/套")
    文本格式.append(f"预算使用率: {方案_obj.获取预算使用率():.1f}%")
    
    return {
        "成功": True,
        "markdown表格": markdown表格,
        "文本格式": "\n".join(文本格式),
        "客户名": 方案_obj.客户名,
        "总价": 方案_obj.总价,
        "设备数": len(方案_obj.设备清单)
    }


# ==================== 命令行入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="飞书导出工具")
    parser.add_argument("--方案-id", type=str, help="方案ID")
    parser.add_argument("--创建文档", action="store_true", help="创建飞书文档")
    parser.add_argument("--创建表格", action="store_true", help="创建飞书表格")
    parser.add_argument("--生成格式", action="store_true", help="生成飞书格式内容")
    
    args = parser.parse_args()
    
    if args.方案_id:
        from 方案.保存方案 import 获取方案
        from utils.数据模型 import 方案 as 方案模型
        
        方案数据 = 获取方案(args.方案_id)
        
        if not 方案数据:
            print(f"❌ 方案 {args.方案_id} 不存在")
            sys.exit(1)
        
        方案对象 = 方案模型.from_dict(方案数据)
        
        if args.创建文档:
            结果 = 导出到飞书文档(方案对象)
            if 结果["成功"]:
                print(f"✅ {结果['消息']}")
                print(f"📄 文档链接: {结果.get('文档链接', 'N/A')}")
            else:
                print(f"❌ {结果['消息']}")
        
        elif args.创建表格:
            结果 = 创建飞书报价表(方案对象)
            if 结果["成功"]:
                print(f"✅ {结果['消息']}")
                print(f"📊 表格链接: {结果.get('表格链接', 'N/A')}")
            else:
                print(f"❌ {结果['消息']}")
        
        elif args.生成格式:
            结果 = 生成飞书格式内容(方案对象)
            if 结果["成功"]:
                print("\n📋 Markdown表格格式:")
                print("-" * 40)
                print(result["markdown表格"])
                print("\n📝 文本格式:")
                print("-" * 40)
                print(result["文本格式"])
        else:
            parser.print_help()
    else:
        parser.print_help()
