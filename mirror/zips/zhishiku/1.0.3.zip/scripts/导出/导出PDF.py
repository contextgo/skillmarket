# -*- coding: utf-8 -*-
"""
导出PDF模块

将方案导出为PDF格式的报价文档。

【使用说明】
- 支持生成专业的PDF报价单
- 支持自定义模板和样式
- 支持添加公司Logo和水印

【命令行使用】
```bash
# 导出方案为PDF
python 导出PDF.py --方案-id PLAN-XXXX --输出报价单.pdf

# 带水印
python 导出PDF.py --方案-id PLAN-XXXX --水印 "机密文件"
```

【代码使用】
```python
from 导出.导出PDF import 导出PDF报价单

# 导出PDF
结果 = 导出PDF报价单(方案对象, "报价单.pdf")
```
"""

import os
import sys
from typing import Dict, Any, List, Optional
from datetime import datetime
from io import BytesIO

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from utils.数据模型 import 方案, 设备项


# ==================== 常量定义 ====================

# PDF配置
PDF配置 = {
    "页面大小": "A4",
    "页边距": (72, 72, 72, 72),  # 上下左右
    "标题字体大小": 18,
    "副标题字体大小": 14,
    "表头字体大小": 11,
    "正文字体大小": 10,
    "公司名称": "某游乐设备有限公司",
    "联系方式": "电话: 400-XXX-XXXX  |  邮箱: info@example.com"
}


# ==================== PDF生成函数 ====================

def 检查_reportlab() -> bool:
    """检查reportlab是否可用"""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        return True
    except ImportError:
        return False


def 获取PDF样式():
    """获取PDF样式定义"""
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    
    样式表 = getSampleStyleSheet()
    
    # 标题样式
    标题 = ParagraphStyle(
        'CustomTitle',
        parent=样式表['Heading1'],
        fontSize=PDF配置["标题字体大小"],
        spaceAfter=20,
        alignment=1,  # 居中
        textColor=colors.HexColor("#1F4E79")
    )
    
    # 副标题样式
    副标题 = ParagraphStyle(
        'SubTitle',
        parent=样式表['Heading2'],
        fontSize=PDF配置["副标题字体大小"],
        spaceAfter=10,
        textColor=colors.HexColor("#2E75B6")
    )
    
    # 信息样式
    信息 = ParagraphStyle(
        'Info',
        parent=样式表['Normal'],
        fontSize=PDF配置["正文字体大小"],
        spaceAfter=5,
        textColor=colors.HexColor("#333333")
    )
    
    # 表头样式
    表头 = ParagraphStyle(
        'TableHeader',
        parent=样式表['Normal'],
        fontSize=PDF配置["表头字体大小"],
        textColor=colors.white,
        alignment=1
    )
    
    return {
        "标题": 标题,
        "副标题": 副标题,
        "信息": 信息,
        "表头": 表头
    }


def 生成报价单HTML(方案_obj: 方案, 水印: str = "") -> str:
    """
    生成报价单HTML内容
    
    参数:
        方案对象: 方案对象
        水印: 水印文字
    
    返回:
        HTML字符串
    """
    当前时间 = datetime.now().strftime("%Y年%m月%d日")
    
    # 生成设备行
    设备行列表 = []
    总价 = 0
    
    for i, 设备 in enumerate(方案_obj.设备清单):
        行背景 = "#F2F2F2" if i % 2 == 1 else "#FFFFFF"
        小计 = 设备.数量 * 设备.单价
        总价 += 小计
        
        设备行 = f"""
        <tr style="background-color: {行背景};">
            <td style="padding: 10px; border: 1px solid #DDDDDD; text-align: center;">{i + 1}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD;">{设备.名称}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD;">{设备.规格}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD; text-align: center;">{设备.单位 if hasattr(设备, '单位') else '台'}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD; text-align: center;">{设备.数量}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD; text-align: right;">¥{设备.单价:,.2f}</td>
            <td style="padding: 10px; border: 1px solid #DDDDDD; text-align: right;">¥{小计:,.2f}</td>
        </tr>
        """
        设备行列表.append(设备行)
    
    设备表格 = "".join(设备行列表)
    
    # 水印样式
    水印样式 = ""
    if 水印:
        水印样式 = f"""
        <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-45deg); 
                    font-size: 80px; color: rgba(200, 200, 200, 0.3); z-index: -1; 
                    pointer-events: none; white-space: nowrap;">
            {水印}
        </div>
        """
    
    HTML = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>设备报价单</title>
        <style>
            @page {{
                size: A4;
                margin: 60px 50px;
            }}
            body {{
                font-family: "Microsoft YaHei", "SimHei", Arial, sans-serif;
                font-size: 12px;
                color: #333;
                margin: 0;
                padding: 20px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 3px solid #1F4E79;
                padding-bottom: 20px;
            }}
            .title {{
                font-size: 28px;
                font-weight: bold;
                color: #1F4E79;
                margin-bottom: 10px;
            }}
            .company {{
                font-size: 14px;
                color: #666;
                margin-bottom: 5px;
            }}
            .info-section {{
                margin-bottom: 20px;
                background-color: #F8F8F8;
                padding: 15px;
                border-radius: 5px;
            }}
            .info-row {{
                display: flex;
                flex-wrap: wrap;
                margin-bottom: 8px;
            }}
            .info-item {{
                width: 50%;
                box-sizing: border-box;
            }}
            .info-label {{
                font-weight: bold;
                color: #1F4E79;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            th {{
                background-color: #1F4E79;
                color: white;
                padding: 12px 10px;
                border: 1px solid #1F4E79;
                text-align: center;
                font-weight: bold;
            }}
            .summary {{
                background-color: #FFF2CC;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
            }}
            .summary-row {{
                display: flex;
                justify-content: space-between;
                margin-bottom: 5px;
            }}
            .summary-total {{
                font-size: 18px;
                font-weight: bold;
                color: #C00000;
                text-align: right;
                margin-top: 10px;
            }}
            .footer {{
                margin-top: 40px;
                padding-top: 20px;
                border-top: 1px solid #DDD;
                font-size: 10px;
                color: #666;
            }}
            .page-break {{
                page-break-after: always;
            }}
        </style>
    </head>
    <body>
        {水印样式}
        
        <div class="header">
            <div class="title">📋 设备报价单</div>
            <div class="company">{PDF配置["公司名称"]}</div>
            <div class="company">{PDF配置["联系方式"]}</div>
        </div>
        
        <div class="info-section">
            <div class="info-row">
                <div class="info-item">
                    <span class="info-label">客户名称：</span>{方案_obj.客户名 or "待定"}
                </div>
                <div class="info-item">
                    <span class="info-label">方案编号：</span>{方案_obj.方案ID}
                </div>
            </div>
            <div class="info-row">
                <div class="info-item">
                    <span class="info-label">预算金额：</span>¥{方案_obj.预算:,.2f}
                </div>
                <div class="info-item">
                    <span class="info-label">方案风格：</span>{方案_obj.风格 or "均衡"}
                </div>
            </div>
            <div class="info-row">
                <div class="info-item">
                    <span class="info-label">编制日期：</span>{当前时间}
                </div>
                <div class="info-item">
                    <span class="info-label">设备数量：</span>{len(方案_obj.设备清单)} 台/套
                </div>
            </div>
        </div>
        
        <h3 style="color: #1F4E79; margin-bottom: 15px;">📦 设备清单</h3>
        <table>
            <thead>
                <tr>
                    <th style="width: 5%;">序号</th>
                    <th style="width: 25%;">产品名称</th>
                    <th style="width: 25%;">型号规格</th>
                    <th style="width: 8%;">单位</th>
                    <th style="width: 8%;">数量</th>
                    <th style="width: 14%;">单价(元)</th>
                    <th style="width: 15%;">小计(元)</th>
                </tr>
            </thead>
            <tbody>
                {设备表格}
            </tbody>
        </table>
        
        <div class="summary">
            <div class="summary-row">
                <span>设备数量合计：</span>
                <span>{len(方案_obj.设备清单)} 台/套</span>
            </div>
            <div class="summary-row">
                <span>预算金额：</span>
                <span>¥{方案_obj.预算:,.2f}</span>
            </div>
            <div class="summary-row">
                <span>预算使用率：</span>
                <span>{方案_obj.获取预算使用率():.1f}%</span>
            </div>
            <div class="summary-total">
                报价总额：¥{方案_obj.总价:,.2f}
            </div>
        </div>
        
        <div class="footer">
            <p><strong>报价说明：</strong></p>
            <ul>
                <li>本报价单有效期为30天，自编制之日起计算</li>
                <li>设备价格含税，不含安装调试费用</li>
                <li>具体交货期以签订合同为准</li>
                <li>如有疑问请随时与我们联系</li>
            </ul>
            <p style="text-align: right; margin-top: 20px;">
                {PDF配置["公司名称"]}<br>
                {当前时间}
            </p>
        </div>
    </body>
    </html>
    """
    
    return HTML


def 导出PDF报价单(
    方案_obj: 方案,
    输出路径: str = "报价单.pdf",
    水印: str = ""
) -> Dict[str, Any]:
    """
    导出方案为PDF报价单
    
    参数:
        方案_obj: 方案对象
        输出路径: 输出文件路径
        水印: 水印文字
    
    返回:
        导出结果
    """
    # 方案1: 使用HTML转PDF (weasyprint 或 wkhtmltopdf)
    try:
        from weasyprint import HTML as WeasyHTML
        
        HTML内容 = 生成报价单HTML(方案_obj, 水印)
        WeasyHTML(string=HTML内容).write_pdf(输出路径)
        
        return {
            "成功": True,
            "消息": f"PDF报价单已导出: {输出路径}",
            "文件路径": 输出路径
        }
    except ImportError:
        pass
    
    # 方案2: 使用reportlab
    if 检查_reportlab():
        return 导出PDF用Reportlab(方案_obj, 输出路径, 水印)
    
    # 方案3: 生成HTML文件（降级方案）
    HTML内容 = 生成报价单HTML(方案_obj, 水印)
    HTML路径 = 输出路径.replace('.pdf', '.html')
    
    with open(HTML路径, 'w', encoding='utf-8') as f:
        f.write(HTML内容)
    
    return {
        "成功": True,
        "消息": f"PDF库未安装，已生成HTML文件: {HTML路径}",
        "消息2": "请手动使用浏览器打印为PDF",
        "文件路径": HTML路径,
        "降级方案": True
    }


def 导出PDF用Reportlab(
    方案_obj: 方案,
    输出路径: str,
    水印: str = ""
) -> Dict[str, Any]:
    """
    使用Reportlab导出PDF
    
    参数:
        方案对象: 方案对象
        输出路径: 输出路径
        水印: 水印文字
    
    返回:
        导出结果
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    
    try:
        # 创建文档
        doc = SimpleDocTemplate(
            输出路径,
            pagesize=A4,
            topMargin=20*mm,
            bottomMargin=20*mm,
            leftMargin=15*mm,
            rightMargin=15*mm
        )
        
        # 获取样式
        样式 = 获取PDF样式()
        
        # 构建内容
        内容 = []
        
        # 标题
        内容.append(Paragraph(PDF配置["公司名称"], 样式["副标题"]))
        内容.append(Paragraph("设备报价单", 样式["标题"]))
        内容.append(Spacer(1, 10*mm))
        
        # 基本信息
        信息数据 = [
            ["客户名称", 方案_obj.客户名 or "待定"],
            ["预算金额", f"¥{方案_obj.预算:,.2f}"],
            ["方案风格", 方案_obj.风格 or "均衡"],
            ["编制日期", datetime.now().strftime("%Y年%m月%d日")]
        ]
        
        信息表 = Table(信息数据, colWidths=[80*mm, 90*mm])
        信息表.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor("#1F4E79")),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        内容.append(信息表)
        内容.append(Spacer(1, 10*mm))
        
        # 设备清单表头
        表头 = ["序号", "产品名称", "型号规格", "单位", "数量", "单价", "小计"]
        
        # 表格数据
        表格数据 = [表头]
        总价 = 0
        
        for i, 设备 in enumerate(方案_obj.设备清单):
            小计 = 设备.数量 * 设备.单价
            总价 += 小计
            
            表格数据.append([
                str(i + 1),
                设备.名称,
                设备.规格,
                设备.单位 if hasattr(设备, '单位') else '台',
                str(设备.数量),
                f"¥{设备.单价:,.2f}",
                f"¥{小计:,.2f}"
            ])
        
        # 创建表格
        设备表 = Table(表格数据, colWidths=[15*mm, 40*mm, 45*mm, 15*mm, 15*mm, 30*mm, 30*mm])
        设备表.setStyle(TableStyle([
            # 表头样式
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # 数据样式
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (0, 1), (0, -1), 'CENTER'),  # 序号居中
            ('ALIGN', (4, 1), (4, -1), 'CENTER'),  # 数量居中
            ('ALIGN', (5, 1), (-1, -1), 'RIGHT'),  # 价格右对齐
            
            # 边框
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#1F4E79")),
            
            # 行高
            ('ROWHEIGHT', (0, 0), (-1, -1), 20),
            
            # 交替行颜色
            *[('BACKGROUND', (0, i), (-1, i), colors.HexColor("#F5F5F5")) 
              for i in range(2, len(表格数据), 2)],
        ]))
        
        内容.append(设备表)
        内容.append(Spacer(1, 5*mm))
        
        # 合计
        合计数据 = [
            ["设备数量", f"{len(方案_obj.设备清单)} 台/套"],
            ["报价总额", f"¥{总价:,.2f}"]
        ]
        
        合计表 = Table(合计数据, colWidths=[170*mm, 30*mm])
        合计表.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, -1), (1, -1), 'RIGHT'),
            ('TEXTCOLOR', (1, -1), (1, -1), colors.HexColor("#C00000")),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor("#FFF2CC")),
            ('BOX', (0, -1), (-1, -1), 1, colors.HexColor("#FFD700")),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        内容.append(合计表)
        
        # 页脚
        内容.append(Spacer(1, 20*mm))
        内容.append(Paragraph("📌 报价说明：", 样式["信息"]))
        内容.append(Paragraph("1. 本报价单有效期为30天", 样式["信息"]))
        内容.append(Paragraph("2. 设备价格含税，不含安装调试费用", 样式["信息"]))
        内容.append(Paragraph("3. 具体交货期以签订合同为准", 样式["信息"]))
        
        # 生成PDF
        doc.build(内容)
        
        return {
            "成功": True,
            "消息": f"PDF报价单已导出: {输出路径}",
            "文件路径": 输出路径
        }
        
    except Exception as e:
        return {
            "成功": False,
            "消息": f"PDF导出失败: {str(e)}"
        }


# ==================== 命令行入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="PDF导出工具")
    parser.add_argument("--方案-id", type=str, help="方案ID")
    parser.add_argument("--输出", type=str, default="报价单.pdf", help="输出文件路径")
    parser.add_argument("--水印", type=str, default="", help="水印文字")
    
    args = parser.parse_args()
    
    if args.方案_id:
        from 方案.保存方案 import 获取方案
        from utils.数据模型 import 方案 as 方案模型
        
        方案数据 = 获取方案(args.方案_id)
        
        if 方案数据:
            方案对象 = 方案模型.from_dict(方案数据)
            结果 = 导出PDF报价单(方案对象, args.输出, args.水印)
            print(f"{'✅' if 结果['成功'] else '❌'} {结果['消息']}")
        else:
            print(f"❌ 方案 {args.方案_id} 不存在")
    else:
        parser.print_help()
