# -*- coding: utf-8 -*-
"""
导出Excel模块

将方案导出为Excel格式的报价单。

【使用说明】
- 支持生成标准报价单格式
- 支持自定义列和样式
- 支持多sheet导出

【命令行使用】
```bash
# 导出方案为Excel
python 导出Excel.py --方案-id PLAN-XXXX --输出报价单.xlsx

# 批量导出
python 导出Excel.py --批量 --方案-ids PLAN-001 PLAN-002
```

【代码使用】
```python
from 导出.导出Excel import 导出报价单, 导出多方案对比

# 导出单个方案
导出报价单(方案对象, "报价单.xlsx")

# 导出多方案对比
导出多方案对比(方案列表, "方案对比.xlsx")
```
"""

import os
import sys
from typing import Dict, Any, List, Optional
from datetime import datetime

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from utils.数据模型 import 方案, 设备项
from utils.excel工具 import 检查_openpyxl


# ==================== 常量定义 ====================

# Excel列定义
报价单列 = [
    ("序号", 8),
    ("产品名称", 25),
    ("型号规格", 30),
    ("单位", 8),
    ("数量", 8),
    ("单价", 15),
    ("小计", 15),
    ("备注", 25)
]

# 样式配置
样式配置 = {
    "标题字体大小": 14,
    "表头字体大小": 11,
    "数据字体大小": 10,
    "标题背景色": "4472C4",
    "表头背景色": "D9E2F3",
    "交替行色": "F2F2F2"
}


# ==================== Excel导出函数 ====================

def 格式化金额(金额: float) -> str:
    """格式化金额显示"""
    return f"¥{金额:,.2f}"


def 获取工作表(工作簿, sheet_name: str = "报价单"):
    """获取或创建工作表"""
    try:
        return 工作簿[sheet_name]
    except KeyError:
        return 工作簿.create_sheet(sheet_name)


def 设置单元格样式(单元格, 字体=None, 边框=None, 对齐=None, 填充=None):
    """设置单元格样式"""
    if 字体:
        单元格.font = 字体
    if 边框:
        单元格.border = 边框
    if 对齐:
        单元格.alignment = 对齐
    if 填充:
        单元格.fill = 填充


def 创建表头(工作表, 标题行: int = 1):
    """创建报价单表头"""
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    
    填充 = PatternFill(start_color=样式配置["表头背景色"], end_color=样式配置["表头背景色"], fill_type="solid")
    字体 = Font(bold=True, size=样式配置["表头字体大小"])
    对齐 = Alignment(horizontal="center", vertical="center")
    边框 = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for col, (列名, 列宽) in enumerate(报价单列, 1):
        单元格 = 工作表.cell(row=标题行, column=col, value=列名)
        设置单元格样式(单元格, 字体=字体, 边框=边框, 对齐=对齐, 填充=填充)
        工作表.column_dimensions[chr(64 + col)].width = 列宽


def 填充报价数据(工作表, 设备清单: List[设备项], 数据起始行: int = 3):
    """填充报价数据"""
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    
    边框 = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    常规字体 = Font(size=样式配置["数据字体大小"])
    居中对齐 = Alignment(horizontal="center", vertical="center")
    左对齐 = Alignment(horizontal="left", vertical="center")
    右对齐 = Alignment(horizontal="right", vertical="center")
    
    填充1 = PatternFill(start_color=样式配置["交替行色"], end_color=样式配置["交替行色"], fill_type="solid")
    
    当前行 = 数据起始行
    
    for i, 设备 in enumerate(设备清单):
        行填充 = 填充1 if i % 2 == 1 else None
        
        # 序号
        单元格 = 工作表.cell(row=当前行, column=1, value=i + 1)
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=居中对齐, 填充=行填充)
        
        # 产品名称
        单元格 = 工作表.cell(row=当前行, column=2, value=设备.名称)
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=左对齐, 填充=行填充)
        
        # 型号规格
        单元格 = 工作表.cell(row=当前行, column=3, value=设备.规格)
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=左对齐, 填充=行填充)
        
        # 单位
        单元格 = 工作表.cell(row=当前行, column=4, value=设备.单位 if hasattr(设备, '单位') else "台")
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=居中对齐, 填充=行填充)
        
        # 数量
        单元格 = 工作表.cell(row=当前行, column=5, value=设备.数量)
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=居中对齐, 填充=行填充)
        
        # 单价
        单元格 = 工作表.cell(row=当前行, column=6, value=设备.单价)
        单元格.number_format = '¥#,##0.00'
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=右对齐, 填充=行填充)
        
        # 小计
        单元格 = 工作表.cell(row=当前行, column=7, value=设备.小计)
        单元格.number_format = '¥#,##0.00'
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=右对齐, 填充=行填充)
        
        # 备注（留空）
        单元格 = 工作表.cell(row=当前行, column=8, value="")
        设置单元格样式(单元格, 字体=常规字体, 边框=边框, 对齐=左对齐, 填充=行填充)
        
        当前行 += 1
    
    return 当前行


def 添加合计行(工作表, 总价: float, 行号: int):
    """添加合计行"""
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    
    填充 = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
    粗体 = Font(bold=True, size=样式配置["数据字体大小"])
    右对齐 = Alignment(horizontal="right", vertical="center")
    边框 = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='double')
    )
    
    for col in range(1, 8):
        单元格 = 工作表.cell(row=行号, column=col, value="")
        设置单元格样式(单元格, 边框=边框, 填充=填充)
    
    单元格 = 工作表.cell(row=行号, column=6, value="合计")
    设置单元格样式(单元格, 字体=粗体, 边框=边框, 对齐=右对齐, 填充=填充)
    
    单元格 = 工作表.cell(row=行号, column=7, value=总价)
    单元格.number_format = '¥#,##0.00'
    设置单元格样式(单元格, 字体=粗体, 边框=边框, 对齐=右对齐, 填充=填充)


def 添加表头信息(工作表, 方案_obj: 方案):
    """添加报价单头部信息"""
    from openpyxl.styles import Font, Alignment
    
    # 标题
    标题单元格 = 工作表.cell(row=1, column=1, value="设备报价单")
    标题单元格.font = Font(bold=True, size=样式配置["标题字体大小"])
    标题单元格.alignment = Alignment(horizontal="center", vertical="center")
    工作表.merge_cells('A1:H1')
    
    # 基本信息
    信息行 = 2
    信息 = [
        ("客户名称:", 方案_obj.客户名 or "待定"),
        ("预算金额:", f"¥{方案_obj.预算:,.2f}" if 方案_obj.预算 else "待定"),
        ("风格定位:", 方案_obj.风格 or "均衡"),
        ("编制日期:", datetime.now().strftime("%Y年%m月%d日"))
    ]
    
    for i, (标签, 值) in enumerate(信息):
        列 = i % 4 + 1
        行 = 信息行 if i < 4 else 信息行 + 1
        
        标签单元格 = 工作表.cell(row=行, column=1 if 列 == 1 else 列 + 3, value=标签)
        标签单元格.font = Font(bold=True, size=样式配置["数据字体大小"])
        
        值单元格 = 工作表.cell(row=行, column=2 if 列 == 1 else 列 + 4, value=值)
        值单元格.font = Font(size=样式配置["数据字体大小"])


def 导出报价单(
    方案_obj: 方案,
    输出路径: str = "报价单.xlsx"
) -> Dict[str, Any]:
    """
    导出方案为Excel报价单
    
    参数:
        方案_obj: 方案对象
        输出路径: 输出文件路径
    
    返回:
        导出结果
    """
    # 检查openpyxl
    if not 检查_openpyxl():
        return {
            "成功": False,
            "消息": "请先安装openpyxl: pip install openpyxl"
        }
    
    from openpyxl import Workbook
    
    try:
        # 创建工作簿
        工作簿 = Workbook()
        
        # 移除默认sheet
        默认sheet = 工作簿.active
        工作簿.remove(默认sheet)
        
        # 创建报价单sheet
        工作表 = 工作簿.create_sheet("报价单", 0)
        
        # 添加表头信息
        添加表头信息(工作表, 方案_obj)
        
        # 创建列标题
        创建表头(工作表, 标题行=4)
        
        # 填充数据
        结束行 = 填充报价数据(工作表, 方案_obj.设备清单, 数据起始行=5)
        
        # 添加合计行
        添加合计行(工作表, 方案_obj.总价, 行号=结束行)
        
        # 设置行高
        工作表.row_dimensions[1].height = 30
        工作表.row_dimensions[4].height = 25
        
        # 保存文件
        工作簿.save(输出路径)
        
        return {
            "成功": True,
            "消息": f"报价单已导出: {输出路径}",
            "文件路径": 输出路径,
            "设备数": len(方案_obj.设备清单),
            "总价": 方案_obj.总价
        }
        
    except Exception as e:
        return {
            "成功": False,
            "消息": f"导出失败: {str(e)}"
        }


def 导出多方案对比(
    方案列表: List[方案],
    输出路径: str = "方案对比.xlsx"
) -> Dict[str, Any]:
    """
    导出多方案对比表
    
    参数:
        方案列表: 方案对象列表
        输出路径: 输出文件路径
    
    返回:
        导出结果
    """
    if not 检查_openpyxl():
        return {
            "成功": False,
            "消息": "请先安装openpyxl: pip install openpyxl"
        }
    
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    
    try:
        工作簿 = Workbook()
        默认sheet = 工作簿.active
        工作簿.remove(默认sheet)
        
        # 创建对比sheet
        工作表 = 工作簿.create_sheet("方案对比", 0)
        
        # 标题
        标题单元格 = 工作表.cell(row=1, column=1, value="方案对比汇总表")
        标题单元格.font = Font(bold=True, size=样式配置["标题字体大小"])
        标题单元格.alignment = Alignment(horizontal="center")
        工作表.merge_cells('A1:G1')
        
        # 表头
        表头行 = 3
        表头 = ["方案名称", "客户", "设备数", "总价", "预算", "预算使用率", "风格"]
        
        填充 = PatternFill(start_color=样式配置["表头背景色"], end_color=样式配置["表头背景色"], fill_type="solid")
        字体 = Font(bold=True, size=样式配置["表头字体大小"])
        边框 = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        居中 = Alignment(horizontal="center", vertical="center")
        
        for col, 标题 in enumerate(表头, 1):
            单元格 = 工作表.cell(row=表头行, column=col, value=标题)
            设置单元格样式(单元格, 字体=字体, 边框=边框, 对齐=居中, 填充=填充)
        
        # 数据行
        当前行 = 表头行 + 1
        for 方案 in 方案列表:
            工作表.cell(row=当前行, column=1, value=方案.名称 if hasattr(方案, '名称') else 方案.方案ID)
            工作表.cell(row=当前行, column=2, value=方案.客户名)
            工作表.cell(row=当前行, column=3, value=len(方案.设备清单))
            
            单价单元格 = 工作表.cell(row=当前行, column=4, value=方案.总价)
            单价单元格.number_format = '¥#,##0.00'
            
            预算单元格 = 工作表.cell(row=当前行, column=5, value=方案.预算)
            预算单元格.number_format = '¥#,##0.00'
            
            使用率 = 工作表.cell(row=当前行, column=6, value=方案.获取预算使用率())
            使用率.number_format = '0.0"%"'
            
            工作表.cell(row=当前行, column=7, value=方案.风格)
            
            当前行 += 1
        
        # 设置列宽
        列宽 = [20, 15, 10, 15, 15, 12, 10]
        for i, 宽 in enumerate(列宽, 1):
            工作表.column_dimensions[chr(64 + i)].width = 宽
        
        # 保存
        工作簿.save(输出路径)
        
        return {
            "成功": True,
            "消息": f"方案对比表已导出: {输出路径}",
            "文件路径": 输出路径,
            "方案数": len(方案列表)
        }
        
    except Exception as e:
        return {
            "成功": False,
            "消息": f"导出失败: {str(e)}"
        }


# ==================== 命令行入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Excel导出工具")
    parser.add_argument("--方案-id", type=str, help="方案ID")
    parser.add_argument("--输出", type=str, default="报价单.xlsx", help="输出文件路径")
    
    args = parser.parse_args()
    
    if args.方案_id:
        from 方案.保存方案 import 获取方案
        from utils.数据模型 import 方案 as 方案模型
        
        方案数据 = 获取方案(args.方案_id)
        
        if 方案数据:
            方案对象 = 方案模型.from_dict(方案数据)
            结果 = 导出报价单(方案对象, args.输出)
            print(f"{'✅' if 结果['成功'] else '❌'} {结果['消息']}")
        else:
            print(f"❌ 方案 {args.方案_id} 不存在")
    else:
        parser.print_help()
