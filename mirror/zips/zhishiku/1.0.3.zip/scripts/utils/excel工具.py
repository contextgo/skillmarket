# -*- coding: utf-8 -*-
"""
Excel工具模块

封装openpyxl库，提供Excel文件的读写功能。

【使用说明】
- 支持读取Excel文件获取产品数据
- 支持生成标准模板和报价单
- 自动处理日期、数字等数据类型

【命令行使用】
```bash
# 导出产品数据到Excel
python -m excel工具 --export products.json --output products.xlsx

# 读取Excel文件
python -m excel工具 --import products.xlsx
```

【依赖】
- openpyxl>=3.0.0
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path

# 尝试导入openpyxl
try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    print("[警告] openpyxl未安装，Excel功能不可用。请运行: pip install openpyxl")


# ==================== 样式定义 ====================

class ExcelStyles:
    """Excel样式定义"""
    
    # 标题样式
    TITLE_FONT = Font(name='微软雅黑', size=14, bold=True, color='FFFFFF')
    TITLE_FILL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    
    # 表头样式
    HEADER_FONT = Font(name='微软雅黑', size=11, bold=True)
    HEADER_FILL = PatternFill(start_color='D6DCE4', end_color='D6DCE4', fill_type='solid')
    
    # 数据样式
    DATA_FONT = Font(name='微软雅黑', size=10)
    
    # 金额样式
    MONEY_FONT = Font(name='微软雅黑', size=10)
    MONEY_ALIGN = Alignment(horizontal='right')
    
    # 边框
    THIN_BORDER = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )


# ==================== 核心功能函数 ====================

def 检查_openpyxl() -> bool:
    """检查openpyxl是否可用"""
    if not OPENPYXL_AVAILABLE:
        print("[错误] openpyxl未安装，无法使用Excel功能")
        print("[提示] 请运行: pip install openpyxl")
        return False
    return True


def 创建工作簿() -> Optional['Workbook']:
    """创建新的Excel工作簿"""
    if not 检查_openpyxl():
        return None
    return Workbook()


def 读取Excel文件(文件路径: str, 工作表名: Optional[str] = None) -> Tuple[bool, Any, str]:
    """
    读取Excel文件
    
    参数:
        文件路径: Excel文件路径
        工作表名: 工作表名称（默认读取第一个）
    
    返回:
        (是否成功, 数据/错误信息, 消息)
    """
    if not 检查_openpyxl():
        return False, None, "openpyxl不可用"
    
    try:
        if not os.path.exists(文件路径):
            return False, None, f"文件不存在: {文件路径}"
        
        wb = load_workbook(文件路径, data_only=True)
        
        if 工作表名:
            if 工作表名 not in wb.sheetnames:
                return False, None, f"未找到工作表: {工作表名}"
            ws = wb[工作表名]
        else:
            ws = wb.active
        
        # 读取数据
        headers = []
        data = []
        
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            if row_idx == 1:
                headers = [str(cell) if cell is not None else "" for cell in row]
            else:
                if any(cell is not None for cell in row):
                    row_data = {}
                    for col_idx, (header, cell) in enumerate(zip(headers, row)):
                        row_data[header] = cell
                    data.append(row_data)
        
        wb.close()
        
        return True, {
            "headers": headers,
            "data": data,
            "工作表名": ws.title,
            "总行数": len(data) + 1
        }, f"成功读取 {len(data)} 条数据"
        
    except Exception as e:
        return False, None, f"读取失败: {str(e)}"


def Excel转产品列表(文件路径: str, 工作表名: Optional[str] = None) -> Tuple[bool, List[Dict[str, Any]], str]:
    """
    将Excel文件转换为产品列表
    
    参数:
        文件路径: Excel文件路径
        工作表名: 工作表名称
    
    返回:
        (是否成功, 产品列表, 消息)
    """
    success, result, msg = 读取Excel文件(文件路径, 工作表名)
    
    if not success:
        return False, [], msg
    
    products = []
    for row in result["data"]:
        product = {
            "产品ID": f"P{len(products) + 1:05d}",
            "创建时间": datetime.now().isoformat(),
            "更新时间": datetime.now().isoformat()
        }
        
        # 字段映射
        field_mapping = {
            "产品名称": "名称",
            "名称": "名称",
            "产品名称": "名称",
            "型号规格": "型号规格",
            "规格": "型号规格",
            "规格型号": "型号规格",
            "类别": "类别",
            "分类": "类别",
            "产品类别": "类别",
            "价格": "单价",
            "单价": "单价",
            "报价": "单价",
            "售价": "单价",
            "单位": "单位",
            "成本价": "成本价",
            "成本": "成本价",
            "技术参数": "技术参数",
            "参数": "技术参数",
            "规格参数": "技术参数",
            "产品卖点": "产品卖点",
            "卖点": "产品卖点",
            "特色": "产品卖点",
            "适用场景": "适用场景",
            "场景": "适用场景",
            "图片链接": "图片链接",
            "图片": "图片链接",
            "图片URL": "图片链接",
            "供应商": "供应商",
            "厂商": "供应商",
            "描述": "描述",
            "产品描述": "描述",
            "备注": "描述"
        }
        
        for excel_field, model_field in field_mapping.items():
            if excel_field in row and row[excel_field] is not None:
                value = row[excel_field]
                
                # 类型转换
                if model_field == "单价" and isinstance(value, (int, float)):
                    product[model_field] = float(value)
                elif model_field == "成本价" and isinstance(value, (int, float)):
                    product[model_field] = float(value)
                elif model_field == "单位" and value == "":
                    product[model_field] = "台"
                else:
                    product[model_field] = str(value) if value else ""
        
        products.append(product)
    
    return True, products, f"成功转换 {len(products)} 条产品"


def 生成产品模板(输出路径: str = "./template_products.xlsx") -> Tuple[bool, str]:
    """
    生成标准产品导入模板
    
    参数:
        输出路径: 输出文件路径
    
    返回:
        (是否成功, 消息)
    """
    if not 检查_openpyxl():
        return False, "openpyxl不可用"
    
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "产品表"
        
        # 定义表头
        headers = [
            "产品名称", "型号规格", "类别", "价格", "单位", 
            "成本价", "技术参数", "产品卖点", "适用场景", "图片链接", "供应商"
        ]
        
        # 宽度设置
        column_widths = [20, 20, 15, 12, 8, 12, 25, 25, 15, 30, 20]
        
        # 写入表头
        for col, (header, width) in enumerate(zip(headers, column_widths), 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = ExcelStyles.HEADER_FONT
            cell.fill = ExcelStyles.HEADER_FILL
            cell.border = ExcelStyles.THIN_BORDER
            cell.alignment = Alignment(horizontal='center', vertical='center')
            ws.column_dimensions[get_column_letter(col)].width = width
        
        # 添加示例数据
        sample_data = [
            ["旋转木马", "中型24座", "机械设备", 350000, "台", 280000, "功率4.5KW，电压380V", "进口电机，噪音低", "室外/亲子", "https://example.com/carousel.jpg", "XX游乐设备"],
            ["海盗船", "小型", "机械设备", 280000, "台", 220000, "承载24人，功率15KW", "性价比高", "室外", "https://example.com/pirate.jpg", "XX游乐设备"],
            ["碰碰车", "10车", "机械设备", 150000, "套", 120000, "电压48V，充电4小时", "操作简单", "室内", "https://example.com/bumper.jpg", "XX游乐设备"],
            ["淘气堡", "100平米", "无动力设备", 120000, "套", 95000, "EVA地垫，PVC软包", "安全环保", "室内/亲子", "https://example.com/softplay.jpg", "XX游乐设备"],
            ["玻璃水滑", "标准型", "水上游乐", 450000, "条", 360000, "长度200米，透明滑道", "刺激好玩", "室外", "https://example.com/waterslide.jpg", "XX游乐设备"],
        ]
        
        for row_idx, row_data in enumerate(sample_data, 2):
            for col_idx, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.font = ExcelStyles.DATA_FONT
                cell.border = ExcelStyles.THIN_BORDER
                cell.alignment = Alignment(vertical='center')
        
        # 冻结首行
        ws.freeze_panes = "A2"
        
        # 保存
        os.makedirs(os.path.dirname(os.path.abspath(输出路径)) if os.path.dirname(输出路径) else ".", exist_ok=True)
        wb.save(输出路径)
        wb.close()
        
        return True, f"模板已生成: {输出路径}"
        
    except Exception as e:
        return False, f"生成失败: {str(e)}"


def 生成报价单(
    方案数据: Dict[str, Any], 
    输出路径: str = "./报价单.xlsx",
    模板样式: str = "standard"
) -> Tuple[bool, str]:
    """
    生成报价单Excel
    
    参数:
        方案数据: 方案数据字典
        输出路径: 输出文件路径
        模板样式: 模板样式 (standard/brief/government)
    
    返回:
        (是否成功, 消息)
    """
    if not 检查_openpyxl():
        return False, "openpyxl不可用"
    
    try:
        wb = Workbook()
        
        # ========== 设备清单表 ==========
        ws1 = wb.active
        ws1.title = "设备清单"
        
        # 标题
        ws1.merge_cells('A1:F1')
        title_cell = ws1['A1']
        title_cell.value = f"【{方案数据.get('客户名', '客户')}】报价方案"
        title_cell.font = ExcelStyles.TITLE_FONT
        title_cell.fill = ExcelStyles.TITLE_FILL
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        ws1.row_dimensions[1].height = 30
        
        # 表头
        headers = ["序号", "设备名称", "规格型号", "数量", "单价(元)", "小计(元)"]
        for col, header in enumerate(headers, 1):
            cell = ws1.cell(row=2, column=col, value=header)
            cell.font = ExcelStyles.HEADER_FONT
            cell.fill = ExcelStyles.HEADER_FILL
            cell.border = ExcelStyles.THIN_BORDER
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # 数据行
        devices = 方案数据.get('设备清单', [])
        for row_idx, device in enumerate(devices, 3):
            row_data = [
                row_idx - 2,
                device.get('名称', ''),
                device.get('规格', ''),
                device.get('数量', 1),
                device.get('单价', 0),
                device.get('小计', 0)
            ]
            for col_idx, value in enumerate(row_data, 1):
                cell = ws1.cell(row=row_idx, column=col_idx, value=value)
                cell.font = ExcelStyles.DATA_FONT
                cell.border = ExcelStyles.THIN_BORDER
                if col_idx >= 4:  # 数字列右对齐
                    cell.alignment = ExcelStyles.MONEY_ALIGN
        
        # 合计行
        total_row = len(devices) + 3
        ws1.merge_cells(f'A{total_row}:D{total_row}')
        total_label = ws1.cell(row=total_row, column=1, value="合计")
        total_label.font = ExcelStyles.HEADER_FONT
        total_label.alignment = Alignment(horizontal='right')
        
        total_value = ws1.cell(row=total_row, column=5, value=方案数据.get('总价', 0))
        total_value.font = ExcelStyles.HEADER_FONT
        total_value.number_format = '¥#,##0.00'
        
        subtotal_value = ws1.cell(row=total_row, column=6, value=方案数据.get('总价', 0))
        subtotal_value.font = ExcelStyles.HEADER_FONT
        subtotal_value.number_format = '¥#,##0.00'
        
        for col in range(1, 7):
            ws1.cell(row=total_row, column=col).fill = ExcelStyles.HEADER_FILL
            ws1.cell(row=total_row, column=col).border = ExcelStyles.THIN_BORDER
        
        # 列宽
        ws1.column_dimensions['A'].width = 8
        ws1.column_dimensions['B'].width = 20
        ws1.column_dimensions['C'].width = 15
        ws1.column_dimensions['D'].width = 8
        ws1.column_dimensions['E'].width = 15
        ws1.column_dimensions['F'].width = 15
        
        # ========== 价格明细表 ==========
        ws2 = wb.create_sheet("价格明细")
        
        # 基本信息
        info_data = [
            ["客户名称", 方案数据.get('客户名', '')],
            ["预算金额", f"¥{方案数据.get('预算', 0):,.2f}"],
            ["实际总价", f"¥{方案数据.get('总价', 0):,.2f}"],
            ["预算使用率", f"{方案数据.get('预算使用率', 0):.1f}%"],
            ["风格", 方案数据.get('风格', '均衡')],
            ["场地面积", f"{方案数据.get('场地面积', 0)}平米" if 方案数据.get('场地面积') else "-"],
            ["创建时间", 方案数据.get('创建时间', '')[:10] if 方案数据.get('创建时间') else '-'],
        ]
        
        for row_idx, (label, value) in enumerate(info_data, 1):
            ws2.cell(row=row_idx, column=1, value=label).font = ExcelStyles.HEADER_FONT
            ws2.cell(row=row_idx, column=2, value=value).font = ExcelStyles.DATA_FONT
        
        ws2.column_dimensions['A'].width = 12
        ws2.column_dimensions['B'].width = 30
        
        # ========== 备注表 ==========
        ws3 = wb.create_sheet("备注说明")
        ws3['A1'] = "备注说明"
        ws3['A1'].font = ExcelStyles.TITLE_FONT
        ws3['A1'].fill = ExcelStyles.TITLE_FILL
        ws3['A1'].alignment = Alignment(horizontal='center')
        
        notes = [
            "1. 以上报价为含税价，不含安装调试费用。",
            "2. 设备保修期为一年（人为损坏除外）。",
            "3. 交货周期：定金到账后30-45个工作日。",
            "4. 付款方式：定金50%，发货前付清余款。",
            "5. 具体配置以实际签订合同为准。",
        ]
        
        for row_idx, note in enumerate(notes, 3):
            ws3.cell(row=row_idx, column=1, value=note)
        
        ws3.column_dimensions['A'].width = 60
        
        # 保存
        os.makedirs(os.path.dirname(os.path.abspath(输出路径)) if os.path.dirname(输出路径) else ".", exist_ok=True)
        wb.save(输出路径)
        wb.close()
        
        return True, f"报价单已生成: {输出路径}"
        
    except Exception as e:
        return False, f"生成报价单失败: {str(e)}"


def 保存JSON到Excel(json_path: str, 输出路径: str) -> Tuple[bool, str]:
    """
    将JSON文件转换为Excel
    
    参数:
        json_path: JSON文件路径
        输出路径: 输出Excel路径
    
    返回:
        (是否成功, 消息)
    """
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            # 产品列表
            products = data
        elif isinstance(data, dict) and 'products' in data:
            products = data['products']
        else:
            return False, "JSON格式不正确"
        
        return 生成产品模板(输出路径)
        
    except Exception as e:
        return False, f"转换失败: {str(e)}"


def 获取工作表列表(文件路径: str) -> Tuple[bool, List[str], str]:
    """
    获取Excel文件的工作表列表
    
    参数:
        文件路径: Excel文件路径
    
    返回:
        (是否成功, 工作表列表, 消息)
    """
    if not 检查_openpyxl():
        return False, [], "openpyxl不可用"
    
    try:
        wb = load_workbook(文件路径, read_only=True)
        sheets = wb.sheetnames
        wb.close()
        return True, sheets, f"共 {len(sheets)} 个工作表"
    except Exception as e:
        return False, [], f"获取失败: {str(e)}"


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Excel工具 - Excel文件处理")
    parser.add_argument("--export", type=str, help="导出JSON到Excel")
    parser.add_argument("--import", dest="import_file", type=str, help="导入Excel到JSON")
    parser.add_argument("--output", type=str, default="./output.xlsx", help="输出文件路径")
    parser.add_argument("--template", action="store_true", help="生成产品模板")
    
    args = parser.parse_args()
    
    if args.template:
        success, msg = 生成产品模板(args.output)
        print(msg)
    elif args.export:
        success, msg = 保存JSON到Excel(args.export, args.output)
        print(msg)
    elif args.import_file:
        success, products, msg = Excel转产品列表(args.import_file)
        print(msg)
        if success:
            print(f"读取到 {len(products)} 条产品")
    else:
        parser.print_help()
