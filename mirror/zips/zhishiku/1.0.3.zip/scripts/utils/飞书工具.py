# -*- coding: utf-8 -*-
"""
飞书工具模块

封装飞书开放API，提供飞书多维表格和文档的操作功能。

【使用说明】
- 需要先配置飞书应用的app_id和app_secret
- 支持多维表格的读写操作
- 支持飞书文档的创建和更新

【前提条件】
1. 在飞书开放平台创建应用
2. 配置应用权限（bitable、docx等）
3. 发布应用并获取app_id和app_secret

【示例】
```python
from 飞书工具 import 飞书客户端, 获取产品列表, 同步产品到飞书

# 初始化客户端
client = 飞书客户端(app_id="cli_xxx", app_secret="xxx")

# 获取产品列表
products = 获取产品列表(client, table_id="tblxxx")

# 创建文档
doc_id = 创建报价文档(client, folder_id="fldxxx", title="报价单", content="...")
```
"""

import json
import time
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from urllib.parse import urlencode

# 尝试导入requests
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("[警告] requests未安装，飞书API功能不可用。请运行: pip install requests")


# ==================== 日志配置 ====================

logging.basicConfig(
    level=logging.INFO,
    format='[飞书工具] %(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ==================== 常量定义 ====================

# 飞书API基础地址
FEISHU_BASE_URL = "https://open.feishu.cn/open-apis"
FEISHU_AUTH_URL = f"{FEISHU_BASE_URL}/auth/v3/tenant_access_token/internal"

# API路径
API_PATHS = {
    # 多维表格
    "bitable_app_list": "/bitable/v1/apps",  # 获取多维表格列表
    "bitable_table_list": "/bitable/v1/apps/{app_token}/tables",  # 获取表格列表
    "bitable_records": "/bitable/v1/apps/{app_token}/tables/{table_id}/records",  # 记录操作
    "bitable_fields": "/bitable/v1/apps/{app_token}/tables/{table_id}/fields",  # 字段操作
    
    # 文档
    "doc_create": "/docx/v1/documents",  # 创建文档
    "doc_blocks": "/docx/v1/documents/{document_id}/blocks",  # 获取文档块
    "doc_blocks_batch": "/docx/v1/documents/{document_id}/blocks/batch_update",  # 批量更新
    
    # 文件夹
    "folder_list": "/drive/v1/files",  # 获取文件夹列表
    "folder_create": "/drive/v1/files/create_folder",  # 创建文件夹
}


# ==================== 异常定义 ====================

class 飞书APIError(Exception):
    """飞书API异常"""
    def __init__(self, code: int, msg: str):
        self.code = code
        self.msg = msg
        super().__init__(f"[{code}] {msg}")


class 飞书认证Error(Exception):
    """飞书认证异常"""
    pass


# ==================== 核心功能类 ====================

class 飞书客户端:
    """
    飞书API客户端
    
    用于与飞书API交互，支持多维表格和文档操作。
    
    【使用示例】
    ```python
    client = 飞书客户端(app_id="cli_xxx", app_secret="xxx")
    if client.检查授权():
        records = client.获取记录列表(app_token, table_id)
    ```
    """
    
    def __init__(self, app_id: str = "", app_secret: str = "", tenant_access_token: str = ""):
        """
        初始化飞书客户端
        
        参数:
            app_id: 飞书应用ID
            app_secret: 飞书应用密钥
            tenant_access_token: 租户访问令牌（可直接传入）
        """
        self.app_id = app_id
        self.app_secret = app_secret
        self.tenant_access_token = tenant_access_token
        self.token_expires_at = 0  # 令牌过期时间戳
        self.session = requests.Session() if REQUESTS_AVAILABLE else None
    
    def 检查_requests(self) -> bool:
        """检查requests库是否可用"""
        if not REQUESTS_AVAILABLE:
            print("[错误] requests库不可用，无法使用飞书API")
            print("[提示] 请运行: pip install requests")
            return False
        return True
    
    def 获取_token(self) -> Tuple[bool, str]:
        """
        获取tenant_access_token
        
        返回:
            (是否成功, token/错误信息)
        """
        if not self.check_requests():
            return False, "requests不可用"
        
        # 检查缓存
        if self.tenant_access_token and time.time() < self.token_expires_at:
            return True, self.tenant_access_token
        
        try:
            response = self.session.post(
                FEISHU_AUTH_URL,
                json={
                    "app_id": self.app_id,
                    "app_secret": self.app_secret
                },
                timeout=10
            )
            
            result = response.json()
            
            if result.get("code") == 0:
                self.tenant_access_token = result["tenant_access_token"]
                # 令牌有效期2小时，提前5分钟过期
                self.token_expires_at = time.time() + (2 * 60 * 60) - 300
                logger.info("成功获取tenant_access_token")
                return True, self.tenant_access_token
            else:
                error_msg = result.get("msg", "未知错误")
                logger.error(f"获取token失败: {error_msg}")
                return False, error_msg
                
        except Exception as e:
            logger.error(f"获取token异常: {str(e)}")
            return False, str(e)
    
    def 检查授权(self) -> bool:
        """检查是否已授权"""
        if not self.tenant_access_token:
            success, _ = self.获取_token()
            return success
        return True
    
    def _请求(self, method: str, path: str, **kwargs) -> Tuple[bool, Dict[str, Any], int]:
        """
        发起API请求
        
        参数:
            method: 请求方法 (GET/POST/PUT/DELETE)
            path: API路径
            **kwargs: 其他请求参数
        
        返回:
            (是否成功, 响应数据, HTTP状态码)
        """
        if not self.check_requests():
            return False, {"error": "requests不可用"}, 0
        
        # 确保有token
        if not self.tenant_access_token:
            success, token = self.获取_token()
            if not success:
                return False, {"error": f"获取token失败: {token}"}, 401
        
        # 构建完整URL
        url = f"{FEISHU_BASE_URL}{path}"
        
        # 设置请求头
        headers = {
            "Authorization": f"Bearer {self.tenant_access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                timeout=kwargs.pop("timeout", 30),
                **kwargs
            )
            
            result = response.json()
            code = result.get("code", 0)
            
            if code == 0:
                return True, result.get("data", {}), response.status_code
            else:
                error_msg = result.get("msg", "API错误")
                logger.error(f"API请求失败 [{code}]: {error_msg}")
                return False, {"code": code, "error": error_msg}, response.status_code
                
        except requests.exceptions.Timeout:
            return False, {"error": "请求超时"}, 408
        except requests.exceptions.ConnectionError:
            return False, {"error": "连接失败，请检查网络"}, 503
        except Exception as e:
            logger.error(f"请求异常: {str(e)}")
            return False, {"error": str(e)}, 500
    
    def 获取多维表格列表(self) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        获取多维表格列表
        
        返回:
            (是否成功, 表格列表, 消息)
        """
        success, data, _ = self._请求("GET", API_PATHS["bitable_app_list"])
        
        if success:
            apps = data.get("items", [])
            return True, apps, f"获取到 {len(apps)} 个多维表格"
        else:
            return False, [], data.get("error", "获取失败")
    
    def 获取表格列表(self, app_token: str) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        获取多维表格的表格列表
        
        参数:
            app_token: 多维表格的app_token
        
        返回:
            (是否成功, 表格列表, 消息)
        """
        path = API_PATHS["bitable_table_list"].replace("{app_token}", app_token)
        success, data, _ = self._请求("GET", path)
        
        if success:
            tables = data.get("items", [])
            return True, tables, f"获取到 {len(tables)} 个表格"
        else:
            return False, [], data.get("error", "获取失败")
    
    def 获取记录列表(
        self, 
        app_token: str, 
        table_id: str,
        page_size: int = 100,
        continuation: str = ""
    ) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        获取表格记录列表
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
            page_size: 每页数量（最大500）
            continuation: 分页令牌
        
        返回:
            (是否成功, 记录列表, 消息)
        """
        path = API_PATHS["bitable_records"].replace("{app_token}", app_token).replace("{table_id}", table_id)
        
        params = {"page_size": min(page_size, 500)}
        if continuation:
            params["continuation"] = continuation
        
        success, data, _ = self._请求("GET", path, params=params)
        
        if success:
            records = data.get("items", [])
            has_more = data.get("has_more", False)
            continuation = data.get("continuation", "")
            
            return True, records, f"获取到 {len(records)} 条记录"
        else:
            return False, [], data.get("error", "获取失败")
    
    def 获取全部记录(self, app_token: str, table_id: str) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        获取表格全部记录（自动分页）
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
        
        返回:
            (是否成功, 全部记录, 消息)
        """
        all_records = []
        continuation = ""
        
        while True:
            success, records, msg = self.获取记录列表(app_token, table_id, continuation=continuation)
            
            if not success:
                return False, all_records, msg
            
            all_records.extend(records)
            
            # 检查是否还有更多
            if not msg or "继续" in msg:
                break
            continuation = ""
            
            # 简单处理：只获取第一页
            break
        
        return True, all_records, f"共获取 {len(all_records)} 条记录"
    
    def 创建记录(
        self, 
        app_token: str, 
        table_id: str, 
        fields: Dict[str, Any]
    ) -> Tuple[bool, str, str]:
        """
        创建单条记录
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
            fields: 字段数据
        
        返回:
            (是否成功, 记录ID/错误, 消息)
        """
        path = API_PATHS["bitable_records"].replace("{app_token}", app_token).replace("{table_id}", table_id)
        
        success, data, _ = self._请求("POST", path, json={"fields": fields})
        
        if success:
            record_id = data.get("record", {}).get("record_id", "")
            return True, record_id, "创建成功"
        else:
            return False, data.get("error", "创建失败"), data.get("error", "创建失败")
    
    def 批量创建记录(
        self, 
        app_token: str, 
        table_id: str, 
        records: List[Dict[str, Any]]
    ) -> Tuple[bool, int, str]:
        """
        批量创建记录
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
            records: 记录列表
        
        返回:
            (是否成功, 成功数量, 消息)
        """
        success_count = 0
        
        for record in records:
            ok, _, _ = self.创建记录(app_token, table_id, record)
            if ok:
                success_count += 1
        
        return True, success_count, f"成功创建 {success_count}/{len(records)} 条记录"
    
    def 更新记录(
        self, 
        app_token: str, 
        table_id: str,
        record_id: str,
        fields: Dict[str, Any]
    ) -> Tuple[bool, str]:
        """
        更新记录
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
            record_id: 记录ID
            fields: 要更新的字段
        
        返回:
            (是否成功, 消息)
        """
        path = API_PATHS["bitable_records"].replace("{app_token}", app_token).replace("{table_id}", table_id)
        path = f"{path}/{record_id}"
        
        success, _, _ = self._请求("PUT", path, json={"fields": fields})
        
        return success, "更新成功" if success else "更新失败"
    
    def 删除记录(
        self, 
        app_token: str, 
        table_id: str,
        record_id: str
    ) -> Tuple[bool, str]:
        """
        删除记录
        
        参数:
            app_token: 多维表格的app_token
            table_id: 表格ID
            record_id: 记录ID
        
        返回:
            (是否成功, 消息)
        """
        path = API_PATHS["bitable_records"].replace("{app_token}", app_token).replace("{table_id}", table_id)
        path = f"{path}/{record_id}"
        
        success, _, _ = self._请求("DELETE", path)
        
        return success, "删除成功" if success else "删除失败"
    
    def 创建文档(
        self, 
        folder_token: str,
        title: str
    ) -> Tuple[bool, str, str]:
        """
        创建飞书文档
        
        参数:
            folder_token: 文件夹token
            title: 文档标题
        
        返回:
            (是否成功, 文档ID, 消息)
        """
        success, data, _ = self._请求(
            "POST", 
            API_PATHS["doc_create"],
            json={
                "folder_token": folder_token,
                "title": title
            }
        )
        
        if success:
            doc_id = data.get("document", {}).get("document_id", "")
            return True, doc_id, f"文档创建成功: {doc_id}"
        else:
            return False, "", data.get("error", "创建失败")
    
    def 获取文件夹列表(
        self, 
        folder_token: str = ""
    ) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        获取文件夹列表
        
        参数:
            folder_token: 父文件夹token（空则获取根目录）
        
        返回:
            (是否成功, 文件夹列表, 消息)
        """
        params = {}
        if folder_token:
            params["folder_token"] = folder_token
        
        success, data, _ = self._请求("GET", API_PATHS["folder_list"], params=params)
        
        if success:
            files = data.get("files", [])
            return True, files, f"获取到 {len(files)} 个文件/文件夹"
        else:
            return False, [], data.get("error", "获取失败")
    
    def 创建文件夹(
        self, 
        name: str,
        folder_token: str = ""
    ) -> Tuple[bool, str, str]:
        """
        创建文件夹
        
        参数:
            name: 文件夹名称
            folder_token: 父文件夹token（空则在根目录创建）
        
        返回:
            (是否成功, 文件夹token, 消息)
        """
        body = {"name": name}
        if folder_token:
            body["folder_token"] = folder_token
        
        success, data, _ = self._请求("POST", API_PATHS["folder_create"], json=body)
        
        if success:
            token = data.get("token", "")
            return True, token, f"文件夹创建成功: {token}"
        else:
            return False, "", data.get("error", "创建失败")


# ==================== 便捷函数 ====================

def 创建飞书客户端(app_id: str, app_secret: str) -> 飞书客户端:
    """
    创建飞书客户端（便捷函数）
    
    参数:
        app_id: 飞书应用ID
        app_secret: 飞书应用密钥
    
    返回:
        飞书客户端实例
    """
    return 飞书客户端(app_id=app_id, app_secret=app_secret)


def 测试飞书连接(app_id: str, app_secret: str) -> Tuple[bool, str]:
    """
    测试飞书连接
    
    参数:
        app_id: 飞书应用ID
        app_secret: 飞书应用密钥
    
    返回:
        (是否成功, 消息)
    """
    client = 飞书客户端(app_id=app_id, app_secret=app_secret)
    success, _ = client.获取_token()
    
    if success:
        return True, "飞书连接正常"
    else:
        return False, "飞书连接失败"


def 获取产品列表(client: 飞书客户端, app_token: str, table_id: str) -> Tuple[bool, List[Dict], str]:
    """
    从飞书多维表格获取产品列表
    
    参数:
        client: 飞书客户端
        app_token: 多维表格app_token
        table_id: 表格ID
    
    返回:
        (是否成功, 产品列表, 消息)
    """
    success, records, msg = client.获取全部记录(app_token, table_id)
    
    if not success:
        return False, [], msg
    
    products = []
    for record in records:
        fields = record.get("fields", {})
        product = {
            "产品ID": record.get("record_id", ""),
            "创建时间": record.get("created_time", ""),
            "更新时间": record.get("last_modified_time", ""),
        }
        
        # 字段映射
        field_map = {
            "产品名称": "名称",
            "名称": "名称",
            "型号规格": "型号规格",
            "规格": "型号规格",
            "类别": "类别",
            "分类": "类别",
            "价格": "单价",
            "单价": "单价",
            "单位": "单位",
            "成本价": "成本价",
            "技术参数": "技术参数",
            "产品卖点": "产品卖点",
            "适用场景": "适用场景",
            "图片链接": "图片链接",
            "供应商": "供应商",
            "描述": "描述"
        }
        
        for feishu_field, model_field in field_map.items():
            if feishu_field in fields:
                product[model_field] = fields[feishu_field]
        
        products.append(product)
    
    return True, products, f"获取到 {len(products)} 条产品"


def 同步产品到飞书(
    client: 飞书客户端, 
    app_token: str, 
    table_id: str,
    products: List[Dict]
) -> Tuple[bool, int, str]:
    """
    同步产品到飞书多维表格
    
    参数:
        client: 飞书客户端
        app_token: 多维表格app_token
        table_id: 表格ID
        products: 产品列表
    
    返回:
        (是否成功, 成功数量, 消息)
    """
    success_count = 0
    
    for product in products:
        # 构建飞书字段格式
        fields = {}
        
        field_map = {
            "名称": "产品名称",
            "型号规格": "型号规格",
            "类别": "类别",
            "单价": "价格",
            "单位": "单位",
            "成本价": "成本价",
            "技术参数": "技术参数",
            "产品卖点": "产品卖点",
            "适用场景": "适用场景",
            "图片链接": "图片链接",
            "供应商": "供应商",
            "描述": "描述"
        }
        
        for model_field, feishu_field in field_map.items():
            if model_field in product and product[model_field]:
                fields[feishu_field] = product[model_field]
        
        ok, _, _ = client.创建记录(app_token, table_id, fields)
        if ok:
            success_count += 1
    
    return True, success_count, f"成功同步 {success_count}/{len(products)} 条产品"


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="飞书工具 - 飞书API操作")
    parser.add_argument("--test", action="store_true", help="测试飞书连接")
    parser.add_argument("--app-id", type=str, help="飞书应用ID")
    parser.add_argument("--app-secret", type=str, help="飞书应用密钥")
    
    args = parser.parse_args()
    
    if args.test:
        if not args.app_id or not args.app_secret:
            print("[错误] 测试连接需要提供 --app-id 和 --app-secret")
        else:
            success, msg = 测试飞书连接(args.app_id, args.app_secret)
            print(msg)
    else:
        parser.print_help()
