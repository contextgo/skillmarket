# -*- coding: utf-8 -*-
"""
数据模型定义模块

定义产品、方案、客户等核心数据结构和数据类型。

【使用说明】
- 本模块定义数据结构，供其他模块引用
- 使用@dataclass装饰器提供简洁的数据类定义
- 支持JSON序列化/反序列化

【示例】
```python
from 数据模型 import 产品, 方案, 客户

prod = 产品(名称="旋转木马", 单价=350000)
print(prod.名称)
```
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum
import json


class 模式(Enum):
    """使用模式枚举"""
    个人 = "personal"
    团队 = "team"


class 方案状态(Enum):
    """方案状态枚举"""
    草稿 = "draft"
    活跃 = "active"
    已归档 = "archived"


class 风格偏好(Enum):
    """风格偏好枚举"""
    高端 = "high_end"
    均衡 = "balanced"
    性价比 = "cost_effective"


@dataclass
class 产品:
    """
    产品数据模型
    
    属性:
        产品ID: 唯一标识符
        名称: 产品名称
        型号规格: 型号或规格描述
        类别: 产品分类
        单价: 报价（元）
        单位: 计量单位
        成本价: 成本（选填）
        技术参数: 关键参数
        产品卖点: 核心卖点
        适用场景: 使用场景
        图片链接: 产品图片URL
        供应商: 供应商信息
        描述: 产品详细描述
        创建时间: 创建时间戳
        更新时间: 更新时间戳
    """
    产品ID: str
    名称: str
    型号规格: str
    类别: str = ""
    单价: float = 0.0
    单位: str = "台"
    成本价: Optional[float] = None
    技术参数: str = ""
    产品卖点: str = ""
    适用场景: str = ""
    图片链接: str = ""
    供应商: str = ""
    描述: str = ""
    创建时间: str = field(default_factory=lambda: datetime.now().isoformat())
    更新时间: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '产品':
        """从字典创建"""
        return cls(**data)

    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, json_str: str) -> '产品':
        """从JSON字符串创建"""
        return cls.from_dict(json.loads(json_str))


@dataclass
class 设备项:
    """
    方案中的设备项
    
    属性:
        产品ID: 关联产品ID
        名称: 设备名称
        规格: 规格描述
        数量: 数量
        单价: 单价
        小计: 金额小计
    """
    产品ID: str
    名称: str
    规格: str
    数量: int = 1
    单价: float = 0.0
    小计: float = 0.0

    def __post_init__(self):
        """自动计算小计"""
        if self.小计 == 0.0:
            self.小计 = self.数量 * self.单价

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '设备项':
        """从字典创建"""
        return cls(**data)


@dataclass
class 方案:
    """
    方案数据模型
    
    属性:
        方案ID: 唯一标识符
        客户名: 客户名称
        预算: 总预算
        设备清单: 设备列表
        总价: 实际总价
        风格: 风格偏好
        场地面积: 场地面积（选填）
        目标人群: 目标人群（选填）
        创建时间: 创建时间
        更新时间: 更新时间
        状态: 方案状态
        备注: 备注信息
        创建人: 创建人
    """
    方案ID: str
    客户名: str
    预算: float
    设备清单: List[设备项] = field(default_factory=list)
    总价: float = 0.0
    风格: str = "均衡"
    场地面积: Optional[float] = None
    目标人群: str = ""
    创建时间: str = field(default_factory=lambda: datetime.now().isoformat())
    更新时间: str = field(default_factory=lambda: datetime.now().isoformat())
    状态: str = "活跃"
    备注: str = ""
    创建人: str = "系统"

    def __post_init__(self):
        """自动计算总价"""
        if self.设备清单 and self.总价 == 0.0:
            self.总价 = sum(item.小计 for item in self.设备清单)

    def 计算总价(self) -> float:
        """重新计算总价"""
        self.总价 = sum(item.小计 for item in self.设备清单)
        return self.总价

    def 获取预算使用率(self) -> float:
        """获取预算使用率"""
        if self.预算 <= 0:
            return 0.0
        return (self.总价 / self.预算) * 100

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        data = asdict(self)
        # 设备清单特殊处理
        data['设备清单'] = [item.to_dict() if hasattr(item, 'to_dict') else item for item in self.设备清单]
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '方案':
        """从字典创建"""
        # 设备清单特殊处理
        if '设备清单' in data and data['设备清单']:
            data['设备清单'] = [
                设备项.from_dict(item) if isinstance(item, dict) else item
                for item in data['设备清单']
            ]
        return cls(**data)

    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class 客户:
    """
    客户数据模型
    
    属性:
        客户ID: 唯一标识符
        名称: 客户名称
        联系人: 联系人姓名
        联系电话: 联系电话（脱敏存储）
        地址: 地址
        备注: 备注信息
        创建时间: 创建时间
        最后联系: 最后联系时间
    """
    客户ID: str
    名称: str
    联系人: str = ""
    联系电话: str = ""
    地址: str = ""
    备注: str = ""
    创建时间: str = field(default_factory=lambda: datetime.now().isoformat())
    最后联系: str = ""

    def 脱敏电话(self) -> str:
        """返回脱敏后的电话"""
        if not self.联系电话 or len(self.联系电话) < 7:
            return self.联系电话
        return self.联系电话[:3] + "****" + self.联系电话[-4:]

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '客户':
        """从字典创建"""
        return cls(**data)


@dataclass
class 飞书配置:
    """
    飞书配置数据模型
    
    属性:
        app_id: 飞书应用ID
        app_secret: 飞书应用密钥
        产品库表格ID: 产品库多维表格ID
        文档文件夹ID: 文档存储文件夹ID
        已授权: 是否已授权
    """
    app_id: str = ""
    app_secret: str = ""
    产品库表格ID: str = ""
    文档文件夹ID: str = ""
    已授权: bool = False
    授权时间: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '飞书配置':
        """从字典创建"""
        return cls(**data)


@dataclass
class 系统配置:
    """
    系统配置数据模型
    
    属性:
        模式: 当前使用模式
        知识库路径: 知识库本地路径
        方案存储路径: 方案存储路径
        客户存储路径: 客户存储路径
        飞书配置: 飞书配置
        语言: 语言设置
        时区: 时区设置
    """
    模式: str = "个人"
    知识库路径: str = "./data/products.json"
    方案存储路径: str = "./data/plans.json"
    客户存储路径: str = "./data/customers.json"
    日志路径: str = "./logs"
    飞书配置: 飞书配置 = field(default_factory=飞书配置)
    语言: str = "zh_CN"
    时区: str = "Asia/Shanghai"

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        data = asdict(self)
        # 飞书配置特殊处理
        if isinstance(self.飞书配置, 飞书配置):
            data['飞书配置'] = self.飞书配置.to_dict()
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '系统配置':
        """从字典创建"""
        if '飞书配置' in data and isinstance(data['飞书配置'], dict):
            data['飞书配置'] = 飞书配置.from_dict(data['飞书配置'])
        return cls(**data)


@dataclass
class 审计日志项:
    """
    审计日志项
    
    属性:
        日志ID: 唯一标识符
        操作人: 操作人
        操作类型: 操作类型
        详情: 详细信息
        时间: 操作时间
    """
    日志ID: str
    操作人: str
    操作类型: str
    详情: str
    时间: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> '审计日志项':
        """从字典创建"""
        return cls(**data)


@dataclass
class 导入校验结果:
    """
    导入校验结果
    
    属性:
        成功: 是否成功
        总数: 总记录数
        成功数: 成功导入数
        失败数: 失败数
        重复数: 重复数
        错误列表: 错误列表
        重复列表: 重复列表
    """
    成功: bool = True
    总数: int = 0
    成功数: int = 0
    失败数: int = 0
    重复数: int = 0
    错误列表: List[Dict[str, str]] = field(default_factory=list)
    重复列表: List[Dict[str, str]] = field(default_factory=list)

    def 添加错误(self, 行号: int, 字段: str, 问题: str, 建议: str = ""):
        """添加错误项"""
        self.成功 = False
        self.失败数 += 1
        self.错误列表.append({
            "行号": str(行号),
            "字段": 字段,
            "问题": 问题,
            "建议": 建议
        })

    def 添加重复(self, 新产品: str, 已存在: str, 相似度: float):
        """添加重复项"""
        self.重复数 += 1
        self.重复列表.append({
            "新产品": 新产品,
            "已存在": 已存在,
            "相似度": f"{相似度}%"
        })

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)


@dataclass
class 冲突检测结果:
    """
    冲突检测结果
    
    属性:
        有冲突: 是否有冲突
        空间冲突: 空间冲突列表
        用电冲突: 用电冲突列表
        人群冲突: 人群冲突列表
        建议: 建议列表
    """
    有冲突: bool = False
    空间冲突: List[Dict[str, str]] = field(default_factory=list)
    用电冲突: List[Dict[str, str]] = field(default_factory=list)
    人群冲突: List[Dict[str, str]] = field(default_factory=list)
    建议: List[str] = field(default_factory=list)

    def 添加空间冲突(self, 设备1: str, 设备2: str, 说明: str):
        """添加空间冲突"""
        self.有冲突 = True
        self.空间冲突.append({
            "设备1": 设备1,
            "设备2": 设备2,
            "说明": 说明
        })

    def 添加用电冲突(self, 设备1: str, 设备2: str, 说明: str):
        """添加用电冲突"""
        self.有冲突 = True
        self.用电冲突.append({
            "设备1": 设备1,
            "设备2": 设备2,
            "说明": 说明
        })

    def 添加人群冲突(self, 设备1: str, 设备2: str, 说明: str):
        """添加人群冲突"""
        self.有冲突 = True
        self.人群冲突.append({
            "设备1": 设备1,
            "设备2": 设备2,
            "说明": 说明
        })

    def 添加建议(self, 建议内容: str):
        """添加建议"""
        self.建议.append(建议内容)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)
