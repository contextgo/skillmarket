# -*- coding: utf-8 -*-
"""
方案保存模块

提供方案的命名、归档、存储等功能。

【使用说明】
- 保存配单方案到本地存储
- 支持方案命名和归档
- 管理方案版本历史

【命令行使用】
```bash
# 保存方案
python 保存方案.py --方案-id xxxx --名称 "XX客户报价方案"

# 归档方案
python 保存方案.py --归档 --方案-id xxxx
```

【代码使用】
```python
from 方案.保存方案 import 保存方案, 获取方案列表, 归档方案

# 保存方案
结果 = 保存方案(方案对象, 名称="XX客户报价")
print(f"方案ID: {结果['方案ID']}")

# 获取方案列表
列表 = 获取方案列表(状态="活跃")
```
"""

import os
import sys
import json
import uuid
import shutil
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from config import 获取方案存储路径, 获取配置
from utils.数据模型 import 方案 as 方案模型, 方案状态


# ==================== 常量定义 ====================

# 方案存储目录
方案文件夹 = "plans"
备份文件夹 = "backups"

# 默认归档目录
归档目录 = "archived"


# ==================== 存储路径函数 ====================

def 获取方案目录() -> str:
    """获取方案存储目录"""
    config = 获取配置()
    方案路径 = config.get("方案存储路径", "./data/plans.json")
    目录 = os.path.dirname(方案路径)
    os.makedirs(目录, exist_ok=True)
    return 目录


def 获取方案文件路径() -> str:
    """获取方案文件路径"""
    config = 获取配置()
    return config.get("方案存储路径", "./data/plans.json")


def 获取归档目录() -> str:
    """获取归档目录"""
    目录 = os.path.join(获取方案目录(), "archived")
    os.makedirs(目录, exist_ok=True)
    return 目录


# ==================== 核心功能函数 ====================

def 加载方案列表() -> List[Dict[str, Any]]:
    """
    加载所有方案
    
    返回:
        方案列表
    """
    方案文件 = 获取方案文件路径()
    
    if not os.path.exists(方案文件):
        return []
    
    try:
        with open(方案文件, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "plans" in data:
            return data["plans"]
        return []
    except Exception as e:
        print(f"[保存方案] 加载方案失败: {e}")
        return []


def 保存方案列表(方案列表: List[Dict[str, Any]]) -> bool:
    """
    保存方案列表到文件
    
    参数:
        方案列表: 方案列表
    
    返回:
        是否保存成功
    """
    方案文件 = 获取方案文件路径()
    
    try:
        os.makedirs(os.path.dirname(方案文件), exist_ok=True)
        
        with open(方案文件, 'w', encoding='utf-8') as f:
            json.dump({
                "plans": 方案列表,
                "更新时间": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        return True
    except Exception as e:
        print(f"[保存方案] 保存方案失败: {e}")
        return False


def 生成方案ID() -> str:
    """生成唯一的方案ID"""
    return f"PLAN-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"


def 生成方案名称(
    客户名: str = "",
    风格: str = "",
    前缀: str = ""
) -> str:
    """
    生成方案默认名称
    
    参数:
        客户名: 客户名称
        风格: 风格偏好
        前缀: 名称前缀
    
    返回:
        生成的方案名称
    """
    时间 = datetime.now().strftime("%m月%d日")
    
    parts = []
    
    if 前缀:
        parts.append(前缀)
    
    if 客户名:
        parts.append(客户名)
    
    parts.append(时间)
    
    if 风格 and 风格 != "均衡":
        parts.append(f"({风格})")
    
    return "".join(parts)


def 保存方案(
    方案_obj: 方案模型,
    名称: str = "",
    创建人: str = "系统"
) -> Dict[str, Any]:
    """
    保存配单方案
    
    参数:
        方案_obj: 方案对象
        名称: 方案名称
        创建人: 创建人
    
    返回:
        保存结果
    """
    # 生成方案ID
    if not 方案_obj.方案ID or 方案_obj.方案ID.startswith("PLAN-"):
        方案_obj.方案ID = 生成方案ID()
    
    # 生成方案名称
    if not 名称:
        名称 = 生成方案名称(
            客户名=方案_obj.客户名,
            风格=方案_obj.风格
        )
    
    # 加载现有方案
    方案列表 = 加载方案列表()
    
    # 转换为字典
    方案_dict = 方案_obj.to_dict()
    方案_dict["名称"] = 名称
    方案_dict["创建人"] = 创建人
    方案_dict["创建时间"] = 方案_obj.创建时间
    方案_dict["更新时间"] = datetime.now().isoformat()
    方案_dict["状态"] = "活跃"
    
    # 检查是否已存在（更新）
    存在索引 = -1
    for i, p in enumerate(方案列表):
        if p.get("方案ID") == 方案_obj.方案ID:
            存在索引 = i
            break
    
    if 存在索引 >= 0:
        # 更新现有方案
        方案列表[存在索引] = 方案_dict
        消息 = f"方案已更新: {名称}"
    else:
        # 添加新方案
        方案列表.append(方案_dict)
        消息 = f"方案已保存: {名称}"
    
    # 保存
    if 保存方案列表(方案列表):
        return {
            "成功": True,
            "消息": 消息,
            "方案ID": 方案_obj.方案ID,
            "名称": 名称
        }
    else:
        return {
            "成功": False,
            "消息": "保存方案失败",
            "方案ID": 方案_obj.方案ID
        }


def 获取方案列表(
    状态: str = "",
    客户名: str = "",
    创建人: str = "",
    限制: int = 100
) -> List[Dict[str, Any]]:
    """
    获取方案列表
    
    参数:
        状态: 方案状态筛选
        客户名: 客户名称筛选
        创建人: 创建人筛选
        限制: 返回数量限制
    
    返回:
        方案列表
    """
    方案列表 = 加载方案列表()
    
    # 筛选
    if 状态:
        方案列表 = [p for p in 方案列表 if p.get("状态") == 状态]
    
    if 客户名:
        方案列表 = [p for p in 方案列表 if 客户名 in p.get("客户名", "")]
    
    if 创建人:
        方案列表 = [p for p in 方案列表 if p.get("创建人") == 创建人]
    
    # 按时间倒序
    方案列表.sort(key=lambda x: x.get("更新时间", ""), reverse=True)
    
    # 限制数量
    return 方案列表[:限制]


def 获取方案(方案ID: str) -> Optional[Dict[str, Any]]:
    """
    获取指定方案
    
    参数:
        方案ID: 方案ID
    
    返回:
        方案数据或None
    """
    方案列表 = 加载方案列表()
    
    for 方案 in 方案列表:
        if 方案.get("方案ID") == 方案ID:
            return 方案
    
    return None


def 归档方案(方案ID: str, 归档原因: str = "") -> Dict[str, Any]:
    """
    归档方案
    
    参数:
        方案ID: 方案ID
        归档原因: 归档原因
    
    返回:
        操作结果
    """
    方案列表 = 加载方案列表()
    
    # 查找方案
    目标方案 = None
    目标索引 = -1
    
    for i, 方案 in enumerate(方案列表):
        if 方案.get("方案ID") == 方案ID:
            目标方案 = 方案
            目标索引 = i
            break
    
    if 目标方案 is None:
        return {
            "成功": False,
            "消息": f"方案 {方案ID} 不存在"
        }
    
    # 备份到归档目录
    归档文件 = os.path.join(
        获取归档目录(),
        f"{方案ID}_{datetime.now().strftime('%Y%m%d%H%M%S')}.json"
    )
    
    try:
        # 添加归档信息
        目标方案["归档时间"] = datetime.now().isoformat()
        目标方案["归档原因"] = 归档原因
        
        with open(归档文件, 'w', encoding='utf-8') as f:
            json.dump(目标方案, f, ensure_ascii=False, indent=2)
        
        # 从活跃列表移除
        方案列表.pop(目标索引)
        
        # 保存更新后的列表
        if 保存方案列表(方案列表):
            return {
                "成功": True,
                "消息": f"方案已归档: {目标方案.get('名称', 方案ID)}",
                "归档文件": 归档文件
            }
        else:
            return {
                "成功": False,
                "消息": "归档保存失败"
            }
            
    except Exception as e:
        return {
            "成功": False,
            "消息": f"归档失败: {str(e)}"
        }


def 删除方案(方案ID: str) -> Dict[str, Any]:
    """
    删除方案
    
    参数:
        方案ID: 方案ID
    
    返回:
        操作结果
    """
    方案列表 = 加载方案列表()
    
    # 查找方案
    目标索引 = -1
    for i, 方案 in enumerate(方案列表):
        if 方案.get("方案ID") == 方案ID:
            目标索引 = i
            break
    
    if 目标索引 < 0:
        return {
            "成功": False,
            "消息": f"方案 {方案ID} 不存在"
        }
    
    # 删除
    方案列表.pop(目标索引)
    
    if 保存方案列表(方案列表):
        return {
            "成功": True,
            "消息": f"方案已删除: {方案ID}"
        }
    else:
        return {
            "成功": False,
            "消息": "删除失败"
        }


def 复制方案(方案ID: str, 新名称: str = "") -> Dict[str, Any]:
    """
    复制方案
    
    参数:
        方案ID: 原方案ID
        新名称: 新方案名称
    
    返回:
        操作结果
    """
    原方案 = 获取方案(方案ID)
    
    if 原方案 is None:
        return {
            "成功": False,
            "消息": f"原方案 {方案ID} 不存在"
        }
    
    # 创建副本
    新方案 = 原方案.copy()
    新方案["方案ID"] = 生成方案ID()
    新方案["名称"] = 新名称 or f"{原方案.get('名称', '方案')} (副本)"
    新方案["创建时间"] = datetime.now().isoformat()
    新方案["更新时间"] = datetime.now().isoformat()
    新方案["状态"] = "活跃"
    
    # 保存
    方案列表 = 加载方案列表()
    方案列表.append(新方案)
    
    if 保存方案列表(方案列表):
        return {
            "成功": True,
            "消息": f"方案已复制: {新方案['名称']}",
            "新方案ID": 新方案["方案ID"],
            "新方案": 新方案
        }
    else:
        return {
            "成功": False,
            "消息": "复制失败"
        }


def 重命名方案(方案ID: str, 新名称: str) -> Dict[str, Any]:
    """
    重命名方案
    
    参数:
        方案ID: 方案ID
        新名称: 新名称
    
    返回:
        操作结果
    """
    方案列表 = 加载方案列表()
    
    # 查找并更新
    for 方案 in 方案列表:
        if 方案.get("方案ID") == 方案ID:
            旧名称 = 方案.get("名称", "")
            方案["名称"] = 新名称
            方案["更新时间"] = datetime.now().isoformat()
            
            if 保存方案列表(方案列表):
                return {
                    "成功": True,
                    "消息": f"方案已重命名: {旧名称} → {新名称}"
                }
            else:
                return {
                    "成功": False,
                    "消息": "重命名失败"
                }
    
    return {
        "成功": False,
        "消息": f"方案 {方案ID} 不存在"
    }


# ==================== 命令行入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="方案保存工具")
    parser.add_argument("--方案-id", type=str, help="方案ID")
    parser.add_argument("--名称", type=str, help="方案名称")
    parser.add_argument("--归档", action="store_true", help="归档方案")
    parser.add_argument("--列出", action="store_true", help="列出方案")
    parser.add_argument("--状态", type=str, default="", help="方案状态筛选")
    
    args = parser.parse_args()
    
    if args.列出:
        print("\n📋 方案列表:")
        print("-" * 80)
        
        列表 = 获取方案列表(状态=args.状态)
        
        for 方案 in 列表:
            print(f"ID: {方案.get('方案ID')}")
            print(f"名称: {方案.get('名称', '未命名')}")
            print(f"客户: {方案.get('客户名', '未知')}")
            print(f"总价: ¥{方案.get('总价', 0):,.2f}")
            print(f"状态: {方案.get('状态', '未知')}")
            print(f"更新时间: {方案.get('更新时间', '')}")
            print("-" * 40)
        
        print(f"\n共 {len(列表)} 个方案")
    
    elif args.归档:
        if not args.方案_id:
            print("❌ 请指定要归档的方案ID")
        else:
            结果 = 归档方案(args.方案_id)
            print(f"{'✅' if 结果['成功'] else '❌'} {结果['消息']}")
    
    elif args.方案_id:
        方案 = 获取方案(args.方案_id)
        if 方案:
            print("\n📋 方案详情:")
            print("-" * 40)
            print(f"ID: {方案.get('方案ID')}")
            print(f"名称: {方案.get('名称', '未命名')}")
            print(f"客户: {方案.get('客户名', '未知')}")
            print(f"预算: ¥{方案.get('预算', 0):,.2f}")
            print(f"总价: ¥{方案.get('总价', 0):,.2f}")
            print(f"状态: {方案.get('状态', '未知')}")
        else:
            print(f"❌ 方案 {args.方案_id} 不存在")
    
    else:
        parser.print_help()
