# -*- coding: utf-8 -*-
"""
智能配单模块

根据预算自动组合设备，支持多种约束条件，生成多个备选方案。

【使用说明】
- 根据预算、风格、场地等约束自动推荐产品组合
- 支持多种配单策略（预算优先/性价比优先/高端优先）
- 生成多个备选方案供选择

【命令行使用】
```bash
# 基础配单
python 智能配单.py --预算 500000 --风格 高端

# 复杂约束配单
python 智能配单.py --预算 500000 --场地 1000 --人群 儿童 --方案数 3
```

【代码使用】
```python
from 配单.智能配单 import 生成配单方案, 分析配单结果

# 生成配单方案
结果 = 生成配单方案(
    预算=500000,
    风格="均衡",
    场地面积=1000,
    目标人群="儿童"
)
for 方案 in 结果['方案列表']:
    print(f"方案 {方案['编号']}: {方案['总价']}元")
```
"""

import os
import sys
import json
import uuid
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from itertools import combinations

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from config import 获取知识库路径
from utils.数据模型 import 产品, 设备项, 方案, 风格偏好


# ==================== 常量定义 ====================

# 配单策略
配单策略 = {
    "预算优先": {
        "说明": "严格控制预算，确保不超支",
        "优先级": ["价格", "实用性"]
    },
    "性价比优先": {
        "说明": "平衡价格与品质，追求最优性价比",
        "优先级": ["性价比", "实用性", "价格"]
    },
    "高端优先": {
        "说明": "追求高品质和高利润空间",
        "优先级": ["品质", "卖点", "利润"]
    },
    "均衡配置": {
        "说明": "各方面均衡配置，避免极端",
        "优先级": ["均衡", "实用性", "价格"]
    }
}

# 预算使用率范围
MIN_预算使用率 = 85  # 最低使用率
MAX_预算使用率 = 105  # 最高超支容忍


# ==================== 数据加载函数 ====================

def 加载知识库(知识库路径: str = "") -> List[Dict[str, Any]]:
    """
    加载知识库产品数据
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        产品列表
    """
    if not 知识库路径:
        知识库路径 = 获取知识库路径()
    
    if not os.path.exists(知识库路径):
        print(f"[智能配单] 知识库文件不存在: {知识库路径}")
        return []
    
    try:
        with open(知识库路径, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "products" in data:
            return data["products"]
        return []
    except Exception as e:
        print(f"[智能配单] 加载知识库失败: {e}")
        return []


def 加载分类产品(知识库路径: str = "") -> Dict[str, List[Dict[str, Any]]]:
    """
    加载并按类别整理产品
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        分类后的产品字典 {类别: [产品列表]}
    """
    products = 加载知识库(知识库路径)
    
    分类产品 = {}
    for product in products:
        类别 = product.get("类别", "未分类")
        if 类别 not in 分类产品:
            分类产品[类别] = []
        分类产品[类别].append(product)
    
    return 分类产品


# ==================== 核心配单函数 ====================

def 筛选可行产品(
    预算: float,
    风格: str = "均衡",
    场地面积: Optional[float] = None,
    目标人群: str = "",
    知识库路径: str = ""
) -> List[Dict[str, Any]]:
    """
    根据约束条件筛选可行的产品
    
    参数:
        预算: 总预算
        风格: 风格偏好
        场地面积: 场地面积（平方米）
        目标人群: 目标人群描述
        知识库路径: 知识库路径
    
    返回:
        可行产品列表
    """
    products = 加载知识库(知识库路径)
    
    可行产品 = []
    
    for product in products:
        # 价格筛选：产品单价不超过预算的80%
        单价 = product.get("单价", 0)
        if 单价 > 预算 * 0.8:
            continue
        
        # 风格匹配
        卖点 = product.get("产品卖点", "")
        技术参数 = product.get("技术参数", "")
        
        if 风格 == "高端":
            # 高端风格偏好高端产品
            if "基础" in 卖点 or "经济" in 卖点:
                continue
        elif 风格 == "性价比":
            # 性价比偏好实用产品
            pass  # 不过滤
        
        # 人群匹配
        适用场景 = product.get("适用场景", "")
        if 目标人群:
            人群关键词 = ["儿童", "青少年", "成人", "家庭", "亲子"]
            for 人群 in 人群关键词:
                if 人群 in 目标人群 and 人群 in 适用场景:
                    可行产品.append(product)
                    break
            else:
                # 如果没有明确的人群匹配，不排除
                可行产品.append(product)
        else:
            可行产品.append(product)
    
    return 可行产品


def 计算产品性价比(产品数据: Dict[str, Any]) -> float:
    """
    计算产品性价比分数
    
    参数:
        产品数据: 产品数据字典
    
    返回:
        性价比分数 (0-100)
    """
    # 基础分数
    分数 = 50.0
    
    # 卖点加成
    卖点 = 产品数据.get("产品卖点", "")
    卖点关键词 = {
        "进口": 10,
        "专利": 8,
        "高品质": 8,
        "热销": 6,
        "环保": 5,
        "节能": 5,
        "安全": 5,
        "耐用": 4,
        "智能": 6,
        "多功能": 5
    }
    
    for 关键词, 加分 in 卖点关键词.items():
        if 关键词 in 卖点:
            分数 += 加分
    
    # 价格合理性（单价在1万-50万之间为最佳区间）
    单价 = 产品数据.get("单价", 0)
    if 10000 <= 单价 <= 500000:
        分数 += 10
    elif 单价 < 5000 or 单价 > 1000000:
        分数 -= 5
    
    return min(100, max(0, 分数))


def 生成方案组合(
    可行产品: List[Dict[str, Any]],
    预算: float,
    策略: str = "性价比优先",
    最小产品数: int = 2,
    最大产品数: int = 8
) -> List[List[Dict[str, Any]]]:
    """
    生成可行的产品组合
    
    参数:
        可行产品: 可行产品列表
        预算: 总预算
        策略: 配单策略
        最小产品数: 最少产品数量
        最大产品数: 最多产品数量
    
    返回:
        可行组合列表
    """
    组合列表 = []
    已处理组合 = set()
    
    # 策略性排序
    if 策略 == "性价比优先":
        可行产品 = sorted(可行产品, key=lambda p: 计算产品性价比(p), reverse=True)
    elif 策略 == "高端优先":
        可行产品 = sorted(可行产品, key=lambda p: p.get("单价", 0), reverse=True)
    elif 策略 == "预算优先":
        可行产品 = sorted(可行产品, key=lambda p: p.get("单价", 0))
    
    # 生成不同产品数量的组合
    for 产品数 in range(最小产品数, min(最大产品数 + 1, len(可行产品) + 1)):
        # 贪心选择高质量产品
        选中产品 = []
        当前总价 = 0
        
        for product in 可行产品:
            if len(选中产品) >= 产品数:
                break
            
            单价 = product.get("单价", 0)
            if 当前总价 + 单价 <= 预算 * MAX_预算使用率 / 100:
                选中产品.append(product)
                当前总价 += 单价
        
        # 验证组合
        if len(选中产品) >= 最小产品数:
            # 检查预算使用率
            使用率 = (当前总价 / 预算) * 100
            if 使用率 >= MIN_预算使用率:
                组合键 = tuple(sorted(p.get("产品ID", "") for p in 选中产品))
                if 组合键 not in 已处理组合:
                    已处理组合.add(组合键)
                    组合列表.append({
                        "产品": 选中产品,
                        "总价": 当前总价,
                        "使用率": 使用率,
                        "产品数": len(选中产品)
                    })
    
    # 按策略排序
    if 策略 == "性价比优先":
        组合列表.sort(key=lambda x: x["总价"] / 预算 if x["总价"] > 0 else 0, reverse=True)
    elif 策略 == "高端优先":
        组合列表.sort(key=lambda x: x["总价"], reverse=True)
    else:
        组合列表.sort(key=lambda x: x["使用率"], reverse=True)
    
    return 组合列表


def 构建配单方案(
    组合: Dict[str, Any],
    客户名: str = "",
    预算: float = 0,
    风格: str = "均衡",
    场地面积: Optional[float] = None,
    目标人群: str = "",
    创建人: str = "系统"
) -> 方案:
    """
    将产品组合构建为完整方案
    
    参数:
        组合: 产品组合
        客户名: 客户名称
        预算: 总预算
        风格: 风格偏好
        场地面积: 场地面积
        目标人群: 目标人群
        创建人: 创建人
    
    返回:
        方案对象
    """
    设备清单 = []
    
    for product in 组合["产品"]:
        设备项 = 设备项(
            产品ID=product.get("产品ID", ""),
            名称=product.get("名称", ""),
            规格=product.get("型号规格", ""),
            数量=1,
            单价=product.get("单价", 0)
        )
        设备清单.append(设备项)
    
    方案数据 = {
        "方案ID": str(uuid.uuid4()),
        "客户名": 客户名,
        "预算": 预算,
        "设备清单": 设备清单,
        "总价": 组合["总价"],
        "风格": 风格,
        "场地面积": 场地面积,
        "目标人群": 目标人群,
        "创建人": 创建人,
        "状态": "活跃"
    }
    
    return 方案.from_dict(方案数据)


def 生成配单方案(
    预算: float,
    风格: str = "均衡",
    场地面积: Optional[float] = None,
    目标人群: str = "",
    客户名: str = "",
    策略: str = "性价比优先",
    方案数量: int = 3,
    知识库路径: str = ""
) -> Dict[str, Any]:
    """
    生成智能配单方案
    
    参数:
        预算: 总预算（元）
        风格: 风格偏好（高端/均衡/性价比）
        场地面积: 场地面积（平方米）
        目标人群: 目标人群描述
        客户名: 客户名称
        策略: 配单策略
        方案数量: 生成方案数量
        知识库路径: 知识库路径
    
    返回:
        配单结果字典
    """
    # 参数验证
    if 预算 <= 0:
        return {
            "成功": False,
            "消息": "预算必须大于0",
            "方案列表": []
        }
    
    # 筛选可行产品
    可行产品 = 筛选可行产品(
        预算=预算,
        风格=风格,
        场地面积=场地面积,
        目标人群=目标人群,
        知识库路径=知识库路径
    )
    
    if not 可行产品:
        return {
            "成功": False,
            "消息": "没有找到符合条件的产品",
            "方案列表": []
        }
    
    # 生成方案组合
    组合列表 = 生成方案组合(
        可行产品=可行产品,
        预算=预算,
        策略=策略,
        最小产品数=2,
        最大产品数=min(8, len(可行产品))
    )
    
    if not 组合列表:
        return {
            "成功": False,
            "消息": "无法生成符合预算的方案组合",
            "方案列表": []
        }
    
    # 构建方案列表
    方案列表 = []
    for i, 组合 in enumerate(组合列表[:方案数量]):
        方案 = 构建配单方案(
            组合=组合,
            客户名=客户名,
            预算=预算,
            风格=风格,
            场地面积=场地面积,
            目标人群=目标人群
        )
        方案列表.append({
            "编号": f"方案{i+1}",
            "方案": 方案,
            "设备清单": 方案.设备清单,
            "总价": 方案.总价,
            "预算使用率": 方案.获取预算使用率(),
            "产品数": len(方案.设备清单),
            "平均单价": 方案.总价 / len(方案.设备清单) if 方案.设备清单 else 0
        })
    
    return {
        "成功": True,
        "消息": f"成功生成{len(方案列表)}个配单方案",
        "输入参数": {
            "预算": 预算,
            "风格": 风格,
            "场地面积": 场地面积,
            "目标人群": 目标人群,
            "策略": 策略
        },
        "方案列表": 方案列表,
        "可行产品数": len(可行产品)
    }


def 分析配单结果(配单结果: Dict[str, Any]) -> Dict[str, Any]:
    """
    分析配单结果，生成详细报告
    
    参数:
        配单结果: 配单结果字典
    
    返回:
        分析报告
    """
    if not 配单结果.get("成功"):
        return {
            "成功": False,
            "消息": 配单结果.get("消息", "配单失败")
        }
    
    方案列表 = 配单结果.get("方案列表", [])
    
    if not 方案列表:
        return {
            "成功": True,
            "消息": "无方案可分析",
            "摘要": {}
        }
    
    # 计算统计数据
    总价列表 = [p["总价"] for p in 方案列表]
    使用率列表 = [p["预算使用率"] for p in 方案列表]
    
    摘要 = {
        "方案总数": len(方案列表),
        "最低总价": min(总价列表),
        "最高总价": max(总价列表),
        "平均总价": sum(总价列表) / len(总价列表),
        "最优预算使用率": max(使用率列表),
        "平均产品数": sum(p["产品数"] for p in 方案列表) / len(方案列表)
    }
    
    # 推荐方案（预算使用率最接近100%的方案）
    推荐方案 = min(方案列表, key=lambda p: abs(p["预算使用率"] - 100))
    
    return {
        "成功": True,
        "摘要": 摘要,
        "推荐方案": 推荐方案["编号"],
        "推荐方案详情": 推荐方案,
        "所有方案": 方案列表
    }


def 计算性价比(设备清单: List[设备项], 预算: float) -> Dict[str, float]:
    """
    计算配单性价比
    
    参数:
        设备清单: 设备列表
        预算: 总预算
    
    返回:
        性价比指标
    """
    if not 设备清单:
        return {
            "整体性价比": 0,
            "平均单价": 0,
            "预算利用率": 0,
            "利润空间指数": 0
        }
    
    总价 = sum(item.小计 for item in 设备清单)
    
    return {
        "整体性价比": (总价 / 预算) * 100 if 预算 > 0 else 0,
        "平均单价": 总价 / len(设备清单),
        "预算利用率": (总价 / 预算) * 100 if 预算 > 0 else 0,
        "利润空间指数": (预算 - 总价) / 预算 * 100 if 预算 > 0 else 0
    }


# ==================== 命令行入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="智能配单工具")
    parser.add_argument("--预算", type=float, required=True, help="总预算（元）")
    parser.add_argument("--风格", type=str, default="均衡", choices=["高端", "均衡", "性价比"], help="风格偏好")
    parser.add_argument("--场地", type=float, help="场地面积（平方米）")
    parser.add_argument("--人群", type=str, default="", help="目标人群")
    parser.add_argument("--客户", type=str, default="", help="客户名称")
    parser.add_argument("--策略", type=str, default="性价比优先", help="配单策略")
    parser.add_argument("--方案数", type=int, default=3, help="生成方案数量")
    
    args = parser.parse_args()
    
    # 执行配单
    结果 = 生成配单方案(
        预算=args.预算,
        风格=args.风格,
        场地面积=args.场地,
        目标人群=args.人群,
        客户名=args.客户,
        策略=args.策略,
        方案数量=args.方案数
    )
    
    # 输出结果
    if 结果["成功"]:
        print(f"\n✅ {结果['消息']}")
        print(f"可行产品数: {结果['可行产品数']}\n")
        
        for 方案 in 结果["方案列表"]:
            print(f"{'='*50}")
            print(f"📋 {方案['编号']}")
            print(f"{'='*50}")
            print(f"总价: ¥{方案['总价']:,.2f}")
            print(f"预算使用率: {方案['预算使用率']:.1f}%")
            print(f"产品数量: {方案['产品数']}台/套")
            print(f"平均单价: ¥{方案['平均单价']:,.2f}")
            print("\n设备清单:")
            for i, item in enumerate(方案["设备清单"], 1):
                print(f"  {i}. {item.名称}")
                print(f"     规格: {item.规格}")
                print(f"     单价: ¥{item.单价:,.2f}")
            print()
    else:
        print(f"\n❌ {结果['消息']}")
