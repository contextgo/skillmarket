# -*- coding: utf-8 -*-
"""
配置管理模块

管理系统配置，包括个人/团队模式切换、飞书配置、数据路径等。

【使用说明】
- 配置存储在 config.json 文件中
- 支持命令行操作配置

【命令行使用】
```bash
# 查看当前配置
python config.py --show

# 切换模式
python config.py --mode team

# 配置飞书
python config.py --feishu --app-id cli_xxx --app-secret xxx

# 重置配置
python config.py --reset
```

【代码中使用】
```python
from config import 获取配置, 保存配置, 切换模式

config = 获取配置()
print(f"当前模式: {config.模式}")

切换模式("团队")
```
"""

import json
import os
import sys
import shutil
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
from pathlib import Path

# 尝试导入数据模型
try:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from utils.数据模型 import 系统配置, 飞书配置, 模式
except ImportError:
    from 数据模型 import 系统配置, 飞书配置, 模式


# ==================== 路径配置 ====================

# 当前目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 配置目录
CONFIG_DIR = os.path.join(BASE_DIR, "..", "data")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

# 默认数据目录
DEFAULT_DATA_DIR = os.path.join(BASE_DIR, "..", "data")
DEFAULT_LOGS_DIR = os.path.join(BASE_DIR, "..", "logs")


# ==================== 配置操作函数 ====================

def 获取配置路径() -> str:
    """获取配置文件路径"""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    return CONFIG_FILE


def 加载配置() -> Dict[str, Any]:
    """
    加载配置文件
    
    返回:
        配置字典
    """
    config_path = 获取配置路径()
    
    # 默认配置
    default_config = {
        "模式": "个人",
        "知识库路径": os.path.join(DEFAULT_DATA_DIR, "products.json"),
        "方案存储路径": os.path.join(DEFAULT_DATA_DIR, "plans.json"),
        "客户存储路径": os.path.join(DEFAULT_DATA_DIR, "customers.json"),
        "日志路径": DEFAULT_LOGS_DIR,
        "飞书配置": {
            "app_id": "",
            "app_secret": "",
            "产品库表格ID": "",
            "文档文件夹ID": "",
            "已授权": False,
            "授权时间": ""
        },
        "语言": "zh_CN",
        "时区": "Asia/Shanghai"
    }
    
    # 如果配置文件存在，读取并合并
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                saved_config = json.load(f)
                # 合并配置
                for key in default_config:
                    if key not in saved_config:
                        saved_config[key] = default_config[key]
                return saved_config
        except Exception as e:
            print(f"[警告] 读取配置文件失败: {e}，使用默认配置")
            return default_config
    
    return default_config


def 保存配置(config: Dict[str, Any]) -> Tuple[bool, str]:
    """
    保存配置文件
    
    参数:
        config: 配置字典
    
    返回:
        (是否成功, 消息)
    """
    config_path = 获取配置路径()
    
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True, f"配置已保存到: {config_path}"
    except Exception as e:
        return False, f"保存配置失败: {str(e)}"


def 获取配置() -> Dict[str, Any]:
    """
    获取当前配置
    
    返回:
        配置字典
    """
    return 加载配置()


def 获取系统配置() -> 系统配置:
    """
    获取系统配置对象
    
    返回:
        系统配置对象
    """
    config = 加载配置()
    
    # 飞书配置
    feishu_config_data = config.get("飞书配置", {})
    feishu_config = 飞书配置(**feishu_config_data)
    
    return 系统配置(
        模式=config.get("模式", "个人"),
        知识库路径=config.get("知识库路径", ""),
        方案存储路径=config.get("方案存储路径", ""),
        客户存储路径=config.get("客户存储路径", ""),
        日志路径=config.get("日志路径", ""),
        飞书配置=feishu_config,
        语言=config.get("语言", "zh_CN"),
        时区=config.get("时区", "Asia/Shanghai")
    )


def 获取模式() -> str:
    """
    获取当前使用模式
    
    返回:
        "个人" 或 "团队"
    """
    config = 加载配置()
    return config.get("模式", "个人")


def 是否团队模式() -> bool:
    """
    检查是否为团队模式
    
    返回:
        True=团队模式, False=个人模式
    """
    return 获取模式() == "团队"


def 是否个人模式() -> bool:
    """
    检查是否为个人模式
    
    返回:
        True=个人模式, False=团队模式
    """
    return 获取模式() == "个人"


def 切换模式(目标模式: str) -> Tuple[bool, str]:
    """
    切换使用模式
    
    参数:
        目标模式: "个人" 或 "团队"
    
    返回:
        (是否成功, 消息)
    """
    if 目标模式 not in ["个人", "团队"]:
        return False, f"无效的模式: {目标模式}，必须是'个人'或'团队'"
    
    config = 加载配置()
    old_mode = config.get("模式", "个人")
    
    if old_mode == 目标模式:
        return True, f"当前已是{目标模式}模式，无需切换"
    
    config["模式"] = 目标模式
    
    # 切换模式时更新路径
    if 目标模式 == "个人":
        # 团队模式切回个人模式，路径保持不变
        pass
    else:
        # 个人模式切到团队模式
        if not config.get("飞书配置", {}).get("已授权"):
            return False, "切换到团队模式需要先配置飞书授权"
    
    success, msg = 保存配置(config)
    
    if success:
        return True, f"已切换到{目标模式}模式"
    else:
        return False, msg


# ==================== 飞书配置函数 ====================

def 获取飞书配置() -> Dict[str, Any]:
    """
    获取飞书配置
    
    返回:
        飞书配置字典
    """
    config = 加载配置()
    return config.get("飞书配置", {})


def 更新飞书配置(
    app_id: str = "",
    app_secret: str = "",
    产品库表格ID: str = "",
    文档文件夹ID: str = ""
) -> Tuple[bool, str]:
    """
    更新飞书配置
    
    参数:
        app_id: 飞书应用ID
        app_secret: 飞书应用密钥
        产品库表格ID: 产品库多维表格ID
        文档文件夹ID: 文档文件夹ID
    
    返回:
        (是否成功, 消息)
    """
    config = 加载配置()
    
    feishu_config = config.get("飞书配置", {})
    
    if app_id:
        feishu_config["app_id"] = app_id
    if app_secret:
        feishu_config["app_secret"] = app_secret
    if 产品库表格ID:
        feishu_config["产品库表格ID"] = 产品库表格ID
    if 文档文件夹ID:
        feishu_config["文档文件夹ID"] = 文档文件夹ID
    
    config["飞书配置"] = feishu_config
    
    return 保存配置(config)


def 标记飞书授权(已授权: bool = True) -> Tuple[bool, str]:
    """
    标记飞书授权状态
    
    参数:
        已授权: 是否已授权
    
    返回:
        (是否成功, 消息)
    """
    config = 加载配置()
    
    feishu_config = config.get("飞书配置", {})
    feishu_config["已授权"] = 已授权
    feishu_config["授权时间"] = datetime.now().isoformat() if 已授权 else ""
    
    config["飞书配置"] = feishu_config
    
    return 保存配置(config)


def 检查飞书配置完整性() -> Tuple[bool, str]:
    """
    检查飞书配置是否完整
    
    返回:
        (是否完整, 消息)
    """
    feishu = 获取飞书配置()
    
    missing = []
    
    if not feishu.get("app_id"):
        missing.append("app_id")
    if not feishu.get("app_secret"):
        missing.append("app_secret")
    if not feishu.get("产品库表格ID"):
        missing.append("产品库表格ID")
    if not feishu.get("文档文件夹ID"):
        missing.append("文档文件夹ID")
    
    if not missing:
        return True, "飞书配置完整"
    else:
        return False, f"缺少配置: {', '.join(missing)}"


# ==================== 路径配置函数 ====================

def 获取知识库路径() -> str:
    """获取知识库路径"""
    config = 加载配置()
    return config.get("知识库路径", os.path.join(DEFAULT_DATA_DIR, "products.json"))


def 获取方案存储路径() -> str:
    """获取方案存储路径"""
    config = 加载配置()
    return config.get("方案存储路径", os.path.join(DEFAULT_DATA_DIR, "plans.json"))


def 获取客户存储路径() -> str:
    """获取客户存储路径"""
    config = 加载配置()
    return config.get("客户存储路径", os.path.join(DEFAULT_DATA_DIR, "customers.json"))


def 获取日志路径() -> str:
    """获取日志路径"""
    config = 加载配置()
    return config.get("日志路径", DEFAULT_LOGS_DIR)


def 设置数据路径(
    知识库路径: str = "",
    方案存储路径: str = "",
    客户存储路径: str = ""
) -> Tuple[bool, str]:
    """
    设置数据存储路径
    
    参数:
        知识库路径: 知识库文件路径
        方案存储路径: 方案存储文件路径
        客户存储路径: 客户存储文件路径
    
    返回:
        (是否成功, 消息)
    """
    config = 加载配置()
    
    if 知识库路径:
        config["知识库路径"] = 知识库路径
    if 方案存储路径:
        config["方案存储路径"] = 方案存储路径
    if 客户存储路径:
        config["客户存储路径"] = 客户存储路径
    
    return 保存配置(config)


# ==================== 配置管理函数 ====================

def 重置配置() -> Tuple[bool, str]:
    """
    重置配置到默认值
    
    返回:
        (是否成功, 消息)
    """
    try:
        # 删除配置文件
        config_path = 获取配置路径()
        if os.path.exists(config_path):
            os.remove(config_path)
        
        # 重置数据目录
        if os.path.exists(DEFAULT_DATA_DIR):
            shutil.rmtree(DEFAULT_DATA_DIR)
        
        return True, "配置已重置"
    except Exception as e:
        return False, f"重置配置失败: {str(e)}"


def 导出配置(输出路径: str) -> Tuple[bool, str]:
    """
    导出配置到文件
    
    参数:
        输出路径: 输出文件路径
    
    返回:
        (是否成功, 消息)
    """
    config = 加载配置()
    
    # 脱敏敏感信息
    export_config = config.copy()
    if "飞书配置" in export_config:
        feishu = export_config["飞书配置"]
        if feishu.get("app_secret"):
            feishu["app_secret"] = "***已脱敏***"
    
    try:
        with open(输出路径, 'w', encoding='utf-8') as f:
            json.dump(export_config, f, ensure_ascii=False, indent=2)
        return True, f"配置已导出到: {输出_path}"
    except Exception as e:
        return False, f"导出配置失败: {str(e)}"


def 导入配置(输入路径: str) -> Tuple[bool, str]:
    """
    从文件导入配置
    
    参数:
        输入路径: 配置文件路径
    
    返回:
        (是否成功, 消息)
    """
    try:
        with open(输入路径, 'r', encoding='utf-8') as f:
            import_config = json.load(f)
        
        # 保存配置
        return 保存配置(import_config)
    except Exception as e:
        return False, f"导入配置失败: {str(e)}"


def 显示配置() -> Dict[str, Any]:
    """
    获取并显示当前配置
    
    返回:
        配置字典
    """
    config = 加载配置()
    
    # 格式化输出
    print("\n" + "=" * 50)
    print("当前配置")
    print("=" * 50)
    print(f"使用模式: {config.get('模式', '个人')}")
    print(f"知识库路径: {config.get('知识库路径', '-')}")
    print(f"方案存储路径: {config.get('方案存储路径', '-')}")
    print(f"客户存储路径: {config.get('客户存储路径', '-')}")
    print()
    print("飞书配置:")
    feishu = config.get("飞书配置", {})
    print(f"  - App ID: {feishu.get('app_id', '-') or '-'}")
    print(f"  - App Secret: {'已配置' if feishu.get('app_secret') else '-'}")
    print(f"  - 产品库表格: {feishu.get('产品库表格ID', '-') or '-'}")
    print(f"  - 文档文件夹: {feishu.get('文档文件夹ID', '-') or '-'}")
    print(f"  - 已授权: {'是' if feishu.get('已授权') else '否'}")
    print("=" * 50 + "\n")
    
    return config


# ==================== 初始化函数 ====================

def 初始化目录结构() -> None:
    """初始化目录结构"""
    dirs = [
        DEFAULT_DATA_DIR,
        DEFAULT_LOGS_DIR
    ]
    
    for dir_path in dirs:
        os.makedirs(dir_path, exist_ok=True)
        print(f"确保目录存在: {dir_path}")


def 初始化配置(模式: str = "个人") -> Tuple[bool, str]:
    """
    初始化配置
    
    参数:
        模式: 初始使用模式
    
    返回:
        (是否成功, 消息)
    """
    # 初始化目录
    初始化目录结构()
    
    # 创建默认配置
    config = 加载配置()
    config["模式"] = 模式
    
    return 保存配置(config)


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="配置管理工具")
    parser.add_argument("--show", action="store_true", help="显示当前配置")
    parser.add_argument("--mode", type=str, choices=["个人", "团队"], help="切换使用模式")
    parser.add_argument("--feishu", action="store_true", help="配置飞书")
    parser.add_argument("--app-id", type=str, help="飞书App ID")
    parser.add_argument("--app-secret", type=str, help="飞书App Secret")
    parser.add_argument("--table-id", type=str, help="产品库表格ID")
    parser.add_argument("--folder-id", type=str, help="文档文件夹ID")
    parser.add_argument("--reset", action="store_true", help="重置配置")
    parser.add_argument("--init", action="store_true", help="初始化配置")
    
    args = parser.parse_args()
    
    if args.show:
        显示配置()
    
    elif args.mode:
        success, msg = 切换模式(args.mode)
        print(msg)
    
    elif args.feishu:
        if not args.app_id or not args.app_secret:
            print("[错误] 配置飞书需要提供 --app-id 和 --app-secret")
        else:
            success, msg = 更新飞书配置(
                app_id=args.app_id,
                app_secret=args.app_secret,
                产品库表格ID=args.table_id or "",
                文档文件夹ID=args.folder_id or ""
            )
            print(msg)
    
    elif args.reset:
        confirm = input("确认重置配置？(y/N): ")
        if confirm.lower() == 'y':
            success, msg = 重置配置()
            print(msg)
    
    elif args.init:
        success, msg = 初始化配置()
        print(msg)
    
    else:
        显示配置()
