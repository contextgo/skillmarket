# -*- coding: utf-8 -*-
"""
产品导入模块

支持Excel文件导入、数据校验、去重检测等功能。

【使用说明】
- 从Excel文件导入产品数据
- 支持数据校验和格式检查
- 自动检测重复产品

【命令行使用】
```bash
# 导入产品
python 导入.py products.xlsx

# 导入并跳过重复
python 导入.py products.xlsx --skip-duplicates

# 仅校验不导入
python 导入.py products.xlsx --validate-only
```

【代码使用】
```python
from 知识库.导入 import 导入产品, 校验产品数据, 检测重复

# 导入产品
success, result, msg = 导入产品("products.xlsx")

# 校验数据
校验结果 = 校验产品数据(products)

# 检测重复
重复列表 = 检测重复(new_products, existing_products)
```
"""

import os
import sys
import json
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from difflib import SequenceMatcher

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from utils.excel工具 import Excel转产品列表, 检查_openpyxl
from utils.数据模型 import 导入校验结果, 产品


# ==================== 常量定义 ====================

# 相似度阈值
SIMILARITY_THRESHOLD = 0.85

# 必填字段
REQUIRED_FIELDS = ["名称", "型号规格", "单价"]

# 数值字段
NUMBER_FIELDS = ["单价", "成本价"]

# 字段名称映射
FIELD_ALIASES = {
    "产品名称": "名称",
    "name": "名称",
    "型号规格": "型号规格",
    "spec": "型号规格",
    "规格": "型号规格",
    "类别": "类别",
    "category": "类别",
    "分类": "类别",
    "价格": "单价",
    "price": "单价",
    "单价": "单价",
    "单位": "单位",
    "unit": "单位",
    "成本价": "成本价",
    "cost": "成本价",
    "技术参数": "技术参数",
    "specs": "技术参数",
    "参数": "技术参数",
    "产品卖点": "产品卖点",
    "卖点": "产品卖点",
    "适用场景": "适用场景",
    "场景": "适用场景",
    "图片链接": "图片链接",
    "图片": "图片链接",
    "供应商": "供应商",
    "vendor": "供应商",
    "描述": "描述",
    "description": "描述"
}


# ==================== 核心功能函数 ====================

def 校验产品数据(products: List[Dict[str, Any]]) -> 导入校验结果:
    """
    校验产品数据
    
    参数:
        products: 产品列表
    
    返回:
        导入校验结果
    """
    result = 导入校验结果()
    result.总数 = len(products)
    
    for idx, product in enumerate(products, 1):
        # 检查必填字段
        for field in REQUIRED_FIELDS:
            if field not in product or not product[field]:
                result.添加错误(
                    行号=idx,
                    字段=field,
                    问题="字段为空",
                    建议=f"补充{field}信息"
                )
        
        # 检查数值字段
        for field in NUMBER_FIELDS:
            if field in product and product[field]:
                try:
                    value = float(product[field])
                    product[field] = value
                except (ValueError, TypeError):
                    result.添加错误(
                        行号=idx,
                        字段=field,
                        问题="非数字格式",
                        建议="修改为纯数字，如 350000"
                    )
                    product[field] = 0
        
        # 设置默认值
        if "单位" not in product or not product["单位"]:
            product["单位"] = "台"
        
        # 生成产品ID
        if "产品ID" not in product or not product["产品ID"]:
            product["产品ID"] = f"P{datetime.now().strftime('%Y%m%d%H%M%S')}{idx:03d}"
        
        # 设置时间戳
        now = datetime.now().isoformat()
        if "创建时间" not in product:
            product["创建时间"] = now
        product["更新时间"] = now
    
    result.成功数 = result.总数 - result.失败数
    return result


def 计算相似度(str1: str, str2: str) -> float:
    """
    计算两个字符串的相似度
    
    参数:
        str1: 字符串1
        str2: 字符串2
    
    返回:
        相似度 (0-1)
    """
    if not str1 or not str2:
        return 0.0
    
    # 标准化
    s1 = str1.lower().strip()
    s2 = str2.lower().strip()
    
    return SequenceMatcher(None, s1, s2).ratio()


def 检测重复(
    new_products: List[Dict[str, Any]], 
    existing_products: List[Dict[str, Any]],
    threshold: float = SIMILARITY_THRESHOLD
) -> List[Dict[str, Any]]:
    """
    检测重复产品
    
    参数:
        new_products: 新产品列表
        existing_products: 已有产品列表
        threshold: 相似度阈值
    
    返回:
        重复产品列表
    """
    duplicates = []
    
    for new_prod in new_products:
        new_name = new_prod.get("名称", "")
        new_spec = new_prod.get("型号规格", "")
        
        for exist_prod in existing_products:
            exist_name = exist_prod.get("名称", "")
            exist_spec = exist_prod.get("型号规格", "")
            
            # 计算名称相似度
            name_sim = 计算相似度(new_name, exist_name)
            
            # 计算规格相似度
            spec_sim = 计算相似度(new_spec, exist_spec)
            
            # 综合相似度
            overall_sim = (name_sim * 0.7 + spec_sim * 0.3) * 100
            
            if overall_sim >= threshold * 100:
                duplicates.append({
                    "新产品": f"{new_name} {new_spec}".strip(),
                    "已存在": f"{exist_name} {exist_spec}".strip(),
                    "相似度": round(overall_sim, 1),
                    "新产品ID": new_prod.get("产品ID", ""),
                    "已存在ID": exist_prod.get("产品ID", "")
                })
                break
    
    return duplicates


def 合并产品信息(
    existing: Dict[str, Any], 
    new_data: Dict[str, Any],
    strategy: str = "update"
) -> Dict[str, Any]:
    """
    合并产品信息
    
    参数:
        existing: 已有产品
        new_data: 新数据
        strategy: 合并策略 (update/keep/merge)
    
    返回:
        合并后的产品
    """
    merged = existing.copy()
    
    # 更新时间戳
    merged["更新时间"] = datetime.now().isoformat()
    
    if strategy == "update":
        # 用新数据覆盖
        for key, value in new_data.items():
            if value:  # 只更新非空字段
                merged[key] = value
    
    elif strategy == "merge":
        # 合并非空字段
        for key, value in new_data.items():
            if value and not merged.get(key):
                merged[key] = value
    
    # keep策略：不做任何修改
    return merged


def 加载知识库(知识库路径: str) -> List[Dict[str, Any]]:
    """
    加载知识库数据
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        产品列表
    """
    if not os.path.exists(知识库路径):
        return []
    
    try:
        with open(知识库路径, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "products" in data:
            return data["products"]
        else:
            return []
    except Exception as e:
        print(f"[导入] 加载知识库失败: {e}")
        return []


def 保存知识库(知识库路径: str, products: List[Dict[str, Any]]) -> Tuple[bool, str]:
    """
    保存知识库数据
    
    参数:
        知识库路径: 知识库文件路径
        products: 产品列表
    
    返回:
        (是否成功, 消息)
    """
    try:
        os.makedirs(os.path.dirname(知识库路径) or ".", exist_ok=True)
        
        data = {
            "version": "1.0",
            "update_time": datetime.now().isoformat(),
            "products": products
        }
        
        with open(知识库路径, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return True, f"已保存 {len(products)} 条产品到知识库"
    except Exception as e:
        return False, f"保存知识库失败: {str(e)}"


def 导入产品(
    文件路径: str,
    知识库路径: str = "./data/products.json",
    跳过重复: bool = True,
    合并策略: str = "update",
    仅校验: bool = False
) -> Tuple[bool, 导入校验结果, str]:
    """
    导入产品数据
    
    参数:
        文件路径: Excel文件路径
        知识库路径: 知识库文件路径
        跳过重复: 是否跳过重复产品
        合并策略: 重复时合并策略 (update/keep/merge)
        仅校验: 是否仅校验不导入
    
    返回:
        (是否成功, 校验结果, 消息)
    """
    print(f"[导入] 开始导入: {文件路径}")
    
    # 检查openpyxl
    if not 检查_openpyxl():
        return False, 导入校验结果(), "openpyxl不可用"
    
    # 读取Excel
    success, products, msg = Excel转产品列表(文件路径)
    
    if not success:
        return False, 导入校验结果(), msg
    
    print(f"[导入] 读取到 {len(products)} 条产品")
    
    # 校验数据
    result = 校验产品数据(products)
    print(f"[导入] 校验完成: 成功 {result.成功数}, 失败 {result.失败数}")
    
    if result.失败数 > 0:
        print(f"[导入] 错误列表:")
        for error in result.错误列表[:5]:  # 只显示前5条
            print(f"  - 行{error['行号']}: {error['字段']} - {error['问题']}")
        if result.失败数 > 5:
            print(f"  ... 还有 {result.失败数 - 5} 条错误")
    
    # 加载已有知识库
    existing_products = 加载知识库(知识库路径)
    print(f"[导入] 知识库现有 {len(existing_products)} 条产品")
    
    # 检测重复
    duplicates = 检测重复(products, existing_products)
    if duplicates:
        result.重复数 = len(duplicates)
        result.重复列表 = duplicates
        print(f"[导入] 检测到 {len(duplicates)} 条重复产品")
        for dup in duplicates[:3]:
            print(f"  - '{dup['新产品']}' 与 '{dup['已存在']}' 相似度 {dup['相似度']}%")
    
    # 仅校验模式
    if 仅校验:
        return True, result, f"校验完成，发现 {result.失败数} 个错误，{result.重复数} 条重复"
    
    # 导入处理
    new_products = []
    updated_count = 0
    
    for prod in products:
        # 检查是否重复
        is_duplicate = False
        for dup in duplicates:
            if dup["新产品ID"] == prod.get("产品ID"):
                is_duplicate = True
                
                if 跳过重复:
                    print(f"[导入] 跳过重复: {prod.get('名称')} {prod.get('型号规格')}")
                else:
                    # 合并更新
                    for exist in existing_products:
                        if exist.get("产品ID") == dup["已存在ID"]:
                            merged = 合并产品信息(exist, prod, 合并策略)
                            new_products.append(merged)
                            updated_count += 1
                            break
                break
        
        if not is_duplicate:
            new_products.append(prod)
    
    # 合并到知识库
    all_products = existing_products.copy()
    for new_prod in new_products:
        # 检查是否已存在
        exists = False
        for i, exist in enumerate(all_products):
            if exist.get("产品ID") == new_prod.get("产品ID"):
                all_products[i] = new_prod
                exists = True
                break
        
        if not exists:
            all_products.append(new_prod)
    
    # 保存
    success, msg = 保存知识库(知识库路径, all_products)
    
    if success:
        print(f"[导入] ✓ {msg}")
        print(f"[导入] 新增: {len(new_products)}, 更新: {updated_count}")
    else:
        print(f"[导入] ✗ {msg}")
    
    return success, result, msg


def 批量导入(
    文件列表: List[str],
    知识库路径: str = "./data/products.json",
    跳过重复: bool = True
) -> Tuple[bool, int, str]:
    """
    批量导入多个Excel文件
    
    参数:
        文件列表: Excel文件路径列表
        知识库路径: 知识库文件路径
        跳过重复: 是否跳过重复产品
    
    返回:
        (是否成功, 总导入数, 消息)
    """
    total_imported = 0
    failed_files = []
    
    for file_path in 文件列表:
        print(f"\n{'='*50}")
        print(f"[批量导入] 处理文件: {file_path}")
        print('='*50)
        
        success, result, msg = 导入产品(
            文件路径=file_path,
            知识库路径=知识库路径 if file_path == 文件列表[0] else 知识库路径,
            跳过重复=跳过重复
        )
        
        if success:
            total_imported += result.成功数
        else:
            failed_files.append(file_path)
    
    if failed_files:
        return False, total_imported, f"完成，但 {len(failed_files)} 个文件失败: {', '.join(failed_files)}"
    
    return True, total_imported, f"批量导入完成，共导入 {total_imported} 条产品"


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="产品导入工具")
    parser.add_argument("file", type=str, help="Excel文件路径")
    parser.add_argument("--output", "-o", type=str, default="./data/products.json", help="知识库路径")
    parser.add_argument("--skip-duplicates", "-s", action="store_true", help="跳过重复产品")
    parser.add_argument("--validate-only", "-v", action="store_true", help="仅校验不导入")
    parser.add_argument("--strategy", choices=["update", "keep", "merge"], default="update", help="重复合并策略")
    
    args = parser.parse_args()
    
    success, result, msg = 导入产品(
        文件路径=args.file,
        知识库路径=args.output,
        跳过重复=args.skip_duplicates,
        合并策略=args.strategy,
        仅校验=args.validate_only
    )
    
    print(f"\n结果: {msg}")
    
    if result.失败数 > 0:
        print(f"\n错误详情:")
        for error in result.错误列表:
            print(f"  行{error['行号']}: {error['字段']} - {error['问题']} (建议: {error['建议']})")
    
    if result.重复数 > 0:
        print(f"\n重复产品:")
        for dup in result.重复列表:
            print(f"  '{dup['新产品']}' ≈ '{dup['已存在']}' ({dup['相似度']}%)")
