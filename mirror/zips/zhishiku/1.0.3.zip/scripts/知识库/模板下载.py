# -*- coding: utf-8 -*-
"""
模板下载模块

生成标准产品Excel导入模板，支持下载和自定义配置。

【使用说明】
- 生成标准格式的Excel模板
- 支持自定义输出路径
- 模板包含完整的字段说明和示例数据

【命令行使用】
```bash
# 下载默认模板
python 模板下载.py

# 指定输出路径
python 模板下载.py --output /path/to/template.xlsx

# 查看模板信息
python 模板下载.py --info
```

【代码使用】
```python
from 知识库.模板下载 import 下载模板, 获取模板信息

# 下载模板
success, msg = 下载模板()

# 获取模板信息
info = 获取模板信息()
print(f"字段数: {info['字段数']}")
```
"""

import os
import sys
from typing import Dict, Any, Tuple

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.excel工具 import 生成产品模板


# ==================== 模板配置 ====================

# 默认模板路径
DEFAULT_TEMPLATE_PATH = "./template_products.xlsx"

# 模板字段定义
TEMPLATE_FIELDS = [
    {
        "字段名": "产品名称",
        "必填": True,
        "说明": "产品名称",
        "示例": "旋转木马",
        "验证规则": "不能为空"
    },
    {
        "字段名": "型号规格",
        "必填": True,
        "说明": "型号或规格",
        "示例": "中型24座",
        "验证规则": "不能为空"
    },
    {
        "字段名": "类别",
        "必填": False,
        "说明": "产品分类",
        "示例": "机械设备",
        "验证规则": ""
    },
    {
        "字段名": "价格",
        "必填": True,
        "说明": "报价（元）",
        "示例": "350000",
        "验证规则": "必须是数字"
    },
    {
        "字段名": "单位",
        "必填": False,
        "说明": "计量单位",
        "示例": "台",
        "验证规则": "默认为'台'"
    },
    {
        "字段名": "成本价",
        "必填": False,
        "说明": "成本价格",
        "示例": "280000",
        "验证规则": "必须是数字"
    },
    {
        "字段名": "技术参数",
        "必填": False,
        "说明": "关键参数",
        "示例": "功率4.5KW，电压380V",
        "验证规则": ""
    },
    {
        "字段名": "产品卖点",
        "必填": False,
        "说明": "核心卖点",
        "示例": "进口电机，噪音低",
        "验证规则": ""
    },
    {
        "字段名": "适用场景",
        "必填": False,
        "说明": "使用场景",
        "示例": "室外/亲子",
        "验证规则": ""
    },
    {
        "字段名": "图片链接",
        "必填": False,
        "说明": "产品图片URL",
        "示例": "https://example.com/image.jpg",
        "验证规则": "必须是有效的URL"
    },
    {
        "字段名": "供应商",
        "必填": False,
        "说明": "供应商名称",
        "示例": "XX游乐设备公司",
        "验证规则": ""
    }
]


# ==================== 功能函数 ====================

def 获取模板信息() -> Dict[str, Any]:
    """
    获取模板信息
    
    返回:
        模板信息字典
    """
    return {
        "模板名称": "产品导入模板",
        "文件格式": "Excel (.xlsx)",
        "版本": "v1.0",
        "字段数": len(TEMPLATE_FIELDS),
        "必填字段": [f["字段名"] for f in TEMPLATE_FIELDS if f["必填"]],
        "可选字段": [f["字段名"] for f in TEMPLATE_FIELDS if not f["必填"]],
        "字段列表": TEMPLATE_FIELDS,
        "示例数据行数": 5
    }


def 下载模板(输出路径: str = DEFAULT_TEMPLATE_PATH) -> Tuple[bool, str]:
    """
    下载标准产品模板
    
    参数:
        输出路径: 模板保存路径
    
    返回:
        (是否成功, 消息)
    """
    print(f"[模板下载] 正在生成模板: {输出路径}")
    
    success, msg = 生成产品模板(输出路径)
    
    if success:
        print(f"[模板下载] ✓ {msg}")
        print(f"[模板下载] 模板包含 {len(TEMPLATE_FIELDS)} 个字段")
        print(f"[模板下载] 包含 {5} 行示例数据")
    else:
        print(f"[模板下载] ✗ {msg}")
    
    return success, msg


def 下载模板并返回路径(输出路径: str = DEFAULT_TEMPLATE_PATH) -> Tuple[bool, str, str]:
    """
    下载模板并返回完整路径
    
    参数:
        输出路径: 模板保存路径
    
    返回:
        (是否成功, 消息, 文件路径)
    """
    success, msg = 下载模板(输出路径)
    
    if success:
        abs_path = os.path.abspath(输出路径)
        return success, msg, abs_path
    
    return success, msg, ""


def 验证模板格式(文件路径: str) -> Tuple[bool, str]:
    """
    验证Excel模板格式
    
    参数:
        文件路径: Excel文件路径
    
    返回:
        (是否有效, 消息)
    """
    if not os.path.exists(文件路径):
        return False, f"文件不存在: {文件路径}"
    
    # 读取Excel检查表头
    from utils.excel工具 import 读取Excel文件
    
    success, result, msg = 读取Excel文件(文件路径)
    
    if not success:
        return False, msg
    
    headers = result.get("headers", [])
    
    # 必需字段
    required_fields = ["产品名称", "型号规格", "价格"]
    
    missing_fields = []
    for field in required_fields:
        if field not in headers:
            missing_fields.append(field)
    
    if missing_fields:
        return False, f"缺少必需字段: {', '.join(missing_fields)}"
    
    return True, "模板格式正确"


def 打印模板说明() -> None:
    """打印模板使用说明"""
    info = 获取模板信息()
    
    print("\n" + "=" * 60)
    print("📥 产品导入模板说明")
    print("=" * 60)
    print(f"模板名称: {info['模板名称']}")
    print(f"文件格式: {info['文件格式']}")
    print(f"版本: {info['版本']}")
    print()
    
    print("【必填字段】")
    for field in info["必填字段"]:
        print(f"  ✓ {field}")
    print()
    
    print("【可选字段】")
    for field in info["可选字段"]:
        print(f"  - {field}")
    print()
    
    print("【字段详情】")
    for field in info["字段列表"]:
        required = "【必填】" if field["必填"] else ""
        print(f"  {field['字段名']} {required}")
        print(f"    说明: {field['说明']}")
        print(f"    示例: {field['示例']}")
        if field["验证规则"]:
            print(f"    验证: {field['验证规则']}")
    print()
    
    print("【注意事项】")
    print("  1. Excel内嵌图片无法读取，请使用'图片链接'列填入URL")
    print("  2. 价格字段必须是数字格式，不要包含货币符号")
    print("  3. 建议先下载模板，按照模板格式填充数据")
    print("=" * 60 + "\n")


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="模板下载工具 - 生成产品导入模板")
    parser.add_argument("--output", "-o", type=str, default=DEFAULT_TEMPLATE_PATH, help="输出文件路径")
    parser.add_argument("--info", "-i", action="store_true", help="查看模板信息")
    parser.add_argument("--validate", "-v", type=str, help="验证模板格式")
    
    args = parser.parse_args()
    
    if args.info:
        打印模板说明()
    
    elif args.validate:
        success, msg = 验证模板格式(args.validate)
        print(msg)
    
    else:
        success, msg = 下载模板(args.output)
        if success:
            print("\n提示: 使用 --info 查看字段说明")
