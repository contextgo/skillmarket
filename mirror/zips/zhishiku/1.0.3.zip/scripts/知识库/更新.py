# -*- coding: utf-8 -*-
"""
知识库更新模块

支持从飞书多维表格同步数据，检测更新差异。

【使用说明】
- 团队模式下同步飞书多维表格数据
- 检测新增、修改、删除的产品
- 支持增量更新和全量覆盖

【命令行使用】
```bash
# 同步飞书数据
python 更新.py --sync

# 仅检查更新
python 更新.py --check

# 查看差异
python 更新.py --diff
```

【代码使用】
```python
from 知识库.更新 import 同步知识库, 获取飞书更新, 获取更新差异

# 检查飞书更新
updates = 获取飞书更新()
print(f"新增: {updates['新增']}, 修改: {updates['修改']}")

# 同步数据
success, msg = 同步知识库()
```
"""

import os
import sys
import json
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from config import 获取飞书配置, 获取知识库路径, 是否团队模式
from utils.数据模型 import 飞书配置
from utils.飞书工具 import 飞书客户端, 获取产品列表


# ==================== 常量定义 ====================

# 更新状态
UPDATE_STATUS = {
    "新增": "new",
    "修改": "modified", 
    "删除": "deleted",
    "无变化": "unchanged"
}


# ==================== 核心功能函数 ====================

def 获取飞书客户端() -> Tuple[bool, 飞书客户端, str]:
    """
    获取飞书客户端
    
    返回:
        (是否成功, 客户端, 消息)
    """
    feishu_config = 获取飞书配置()
    
    if not feishu_config.get("app_id") or not feishu_config.get("app_secret"):
        return False, None, "飞书配置不完整，请先配置app_id和app_secret"
    
    client = 飞书客户端(
        app_id=feishu_config["app_id"],
        app_secret=feishu_config["app_secret"]
    )
    
    success, token = client.获取_token()
    
    if not success:
        return False, None, f"获取飞书token失败: {token}"
    
    return True, client, "飞书客户端初始化成功"


def 获取飞书产品(app_token: str = "", table_id: str = "") -> Tuple[bool, List[Dict], str]:
    """
    从飞书获取产品数据
    
    参数:
        app_token: 多维表格app_token
        table_id: 表格ID
    
    返回:
        (是否成功, 产品列表, 消息)
    """
    # 获取飞书配置
    feishu_config = 获取飞书配置()
    
    if not app_token:
        app_token = feishu_config.get("产品库表格ID", "")
    
    if not app_token:
        return False, [], "未配置产品库表格ID"
    
    # 如果table_id为空，尝试获取第一个表
    if not table_id:
        success, client, msg = 获取飞书客户端()
        if not success:
            return False, [], msg
        
        success, tables, msg = client.获取表格列表(app_token)
        if not success or not tables:
            return False, [], f"获取表格列表失败: {msg}"
        
        table_id = tables[0].get("table_id", "")
    
    if not table_id:
        return False, [], "未指定表格ID"
    
    # 获取产品列表
    success, client, msg = 获取飞书客户端()
    if not success:
        return False, [], msg
    
    return 获取产品列表(client, app_token, table_id)


def 获取本地产品(知识库路径: str = "") -> List[Dict[str, Any]]:
    """
    获取本地知识库产品
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        产品列表
    """
    if not 知识库路径:
        知识库路径 = 获取知识库路径()
    
    if not os.path.exists(知识库路径):
        return []
    
    try:
        with open(知识库路径, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "products" in data:
            return data["products"]
        else:
            return []
    except Exception as e:
        print(f"[更新] 读取本地知识库失败: {e}")
        return []


def 计算差异(
    飞书产品: List[Dict],
    本地产品: List[Dict]
) -> Dict[str, List[Dict]]:
    """
    计算飞书与本地的差异
    
    参数:
        飞书产品: 飞书产品列表
        本地产品: 本地产品列表
    
    返回:
        差异字典 {新增: [], 修改: [], 删除: []}
    """
    # 建立本地产品的索引
    local_index = {}
    for p in 本地产品:
        pid = p.get("产品ID", "")
        if pid:
            local_index[pid] = p
    
    # 建立飞书产品的索引
    feishu_index = {}
    for p in 飞书产品:
        pid = p.get("产品ID", "")
        if pid:
            feishu_index[pid] = p
    
    # 计算差异
    new_products = []  # 飞书中有，本地没有
    modified_products = []  # 两者都有，但内容不同
    deleted_products = []  # 本地有，飞书没有
    
    # 检查新增和修改
    for pid, feishu_p in feishu_index.items():
        if pid not in local_index:
            new_products.append(feishu_p)
        else:
            # 比较内容
            local_p = local_index[pid]
            if not 产品相同(feishu_p, local_p):
                modified_products.append({
                    "飞书版本": feishu_p,
                    "本地版本": local_p
                })
    
    # 检查删除
    for pid, local_p in local_index.items():
        if pid not in feishu_index:
            deleted_products.append(local_p)
    
    return {
        "新增": new_products,
        "修改": modified_products,
        "删除": deleted_products
    }


def 产品相同(p1: Dict, p2: Dict, ignore_fields: List[str] = None) -> bool:
    """
    比较两个产品是否相同
    
    参数:
        p1: 产品1
        p2: 产品2
        ignore_fields: 忽略比较的字段
    
    返回:
        是否相同
    """
    if ignore_fields is None:
        ignore_fields = ["更新时间", "创建时间"]
    
    # 比较关键字段
    compare_fields = ["名称", "型号规格", "类别", "单价", "单位", "成本价", "产品卖点"]
    
    for field in compare_fields:
        v1 = p1.get(field, "")
        v2 = p2.get(field, "")
        
        # 数值字段特殊处理
        if field in ["单价", "成本价"]:
            v1 = float(v1) if v1 else 0
            v2 = float(v2) if v2 else 0
        
        if v1 != v2:
            return False
    
    return True


def 获取更新差异(知识库路径: str = "") -> Tuple[bool, Dict[str, Any], str]:
    """
    获取飞书与本地的更新差异
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        (是否有更新, 差异信息, 消息)
    """
    # 获取飞书产品
    success, feishu_products, msg = 获取飞书产品()
    if not success:
        return False, {}, msg
    
    # 获取本地产品
    local_products = 获取本地产品(知识库路径)
    
    # 计算差异
    diff = 计算差异(feishu_products, local_products)
    
    has_updates = len(diff["新增"]) > 0 or len(diff["修改"]) > 0 or len(diff["删除"]) > 0
    
    return has_updates, diff, f"检查完成: 新增{len(diff['新增'])}个, 修改{len(diff['修改'])}个, 删除{len(diff['删除'])}个"


def 获取飞书更新(知识库路径: str = "") -> Dict[str, Any]:
    """
    获取飞书更新信息（简化版本）
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        更新信息字典
    """
    success, diff, msg = 获取更新差异(知识库路径)
    
    return {
        "成功": success,
        "消息": msg,
        "新增": len(diff.get("新增", [])),
        "修改": len(diff.get("修改", [])),
        "删除": len(diff.get("删除", [])),
        "详情": diff
    }


def 同步知识库(
    知识库路径: str = "",
    覆盖模式: bool = False,
    确认删除: bool = False
) -> Tuple[bool, str]:
    """
    同步知识库数据
    
    参数:
        知识库路径: 知识库文件路径
        覆盖模式: True=全量覆盖, False=增量更新
        确认删除: 是否确认删除操作
    
    返回:
        (是否成功, 消息)
    """
    if not 知识库路径:
        知识库路径 = 获取知识库路径()
    
    print("[同步] 开始同步知识库...")
    
    # 检查飞书配置
    feishu_config = 获取飞书配置()
    if not feishu_config.get("已授权"):
        return False, "飞书未授权，请先完成飞书配置"
    
    # 获取飞书产品
    success, feishu_products, msg = 获取飞书产品()
    if not success:
        return False, msg
    
    print(f"[同步] 飞书产品数: {len(feishu_products)}")
    
    # 加载本地产品
    local_products = 获取本地产品(知识库路径)
    print(f"[同步] 本地产品数: {len(local_products)}")
    
    if 覆盖模式:
        # 全量覆盖
        new_products = feishu_products
        print("[同步] 使用全量覆盖模式")
    else:
        # 增量更新
        diff = 计算差异(feishu_products, local_products)
        
        print(f"[同步] 新增: {len(diff['新增'])}")
        print(f"[同步] 修改: {len(diff['修改'])}")
        print(f"[同步] 删除: {len(diff['删除'])}")
        
        # 构建新列表
        new_products = local_products.copy()
        
        # 添加新增的
        for p in diff["新增"]:
            new_products.append(p)
        
        # 更新修改的
        for item in diff["修改"]:
            feishu_p = item["飞书版本"]
            for i, local_p in enumerate(new_products):
                if local_p.get("产品ID") == feishu_p.get("产品ID"):
                    new_products[i] = feishu_p
                    break
        
        # 删除的
        if diff["删除"] and 确认删除:
            deleted_ids = [p.get("产品ID") for p in diff["删除"]]
            new_products = [p for p in new_products if p.get("产品ID") not in deleted_ids]
            print(f"[同步] 已删除 {len(diff['删除'])} 条产品")
    
    # 保存
    try:
        os.makedirs(os.path.dirname(知识库路径) or ".", exist_ok=True)
        
        data = {
            "version": "1.0",
            "update_time": datetime.now().isoformat(),
            "source": "feishu",
            "products": new_products
        }
        
        with open(知识库路径, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return True, f"同步完成: 共 {len(new_products)} 条产品"
        
    except Exception as e:
        return False, f"保存失败: {str(e)}"


def 格式化更新信息(updates: Dict[str, Any]) -> str:
    """
    格式化更新信息
    
    参数:
        updates: 更新信息字典
    
    返回:
        格式化文本
    """
    if not updates.get("成功"):
        return f"获取更新失败: {updates.get('消息', '未知错误')}"
    
    lines = []
    lines.append("\n" + "=" * 40)
    lines.append("🔄 飞书数据更新检测")
    lines.append("=" * 40)
    
    diff = updates.get("详情", {})
    
    lines.append(f"新增产品: {len(diff.get('新增', []))}")
    lines.append(f"修改产品: {len(diff.get('修改', []))}")
    lines.append(f"删除产品: {len(diff.get('删除', []))}")
    
    # 显示新增产品
    new_products = diff.get("新增", [])
    if new_products:
        lines.append("\n【新增产品】")
        for p in new_products[:5]:
            lines.append(f"  + {p.get('名称', '')} {p.get('型号规格', '')}")
        if len(new_products) > 5:
            lines.append(f"  ... 还有 {len(new_products) - 5} 条")
    
    # 显示修改产品
    modified = diff.get("修改", [])
    if modified:
        lines.append("\n【修改产品】")
        for item in modified[:5]:
            p = item["飞书版本"]
            lines.append(f"  ~ {p.get('名称', '')} {p.get('型号规格', '')}")
        if len(modified) > 5:
            lines.append(f"  ... 还有 {len(modified) - 5} 条")
    
    lines.append("=" * 40 + "\n")
    
    return "\n".join(lines)


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="知识库同步工具")
    parser.add_argument("--sync", action="store_true", help="执行同步")
    parser.add_argument("--check", action="store_true", help="仅检查更新")
    parser.add_argument("--diff", action="store_true", help="查看详细差异")
    parser.add_argument("--overwrite", action="store_true", help="全量覆盖模式")
    parser.add_argument("--confirm-delete", action="store_true", help="确认删除")
    parser.add_argument("--path", "-p", type=str, default="./data/products.json", help="知识库路径")
    
    args = parser.parse_args()
    
    if not 是否团队模式():
        print("[警告] 当前不是团队模式，无法同步飞书数据")
        print("[提示] 使用 /模式 切换到团队模式")
        sys.exit(1)
    
    if args.check or args.diff:
        # 检查更新
        success, updates, msg = 获取更新差异(args.path)
        print(格式化更新信息(updates))
        
        if args.diff:
            print("\n详细差异:")
            print(json.dumps(updates, ensure_ascii=False, indent=2))
    
    elif args.sync:
        # 执行同步
        success, msg = 同步知识库(
            知识库路径=args.path,
            覆盖模式=args.overwrite,
            确认删除=args.confirm_delete
        )
        print(msg)
    
    else:
        parser.print_help()
        print("\n示例:")
        print("  python 更新.py --check     # 检查更新")
        print("  python 更新.py --sync      # 同步数据")
        print("  python 更新.py --overwrite # 全量覆盖")
