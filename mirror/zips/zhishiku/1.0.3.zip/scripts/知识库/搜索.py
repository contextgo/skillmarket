# -*- coding: utf-8 -*-
"""
知识库搜索模块

提供产品搜索、知识库统计等功能。

【使用说明】
- 支持模糊搜索和分类筛选
- 返回搜索结果和统计信息

【命令行使用】
```bash
# 搜索产品
python 搜索.py "旋转木马"

# 按类别搜索
python 搜索.py --category "机械设备"

# 查看知识库统计
python 搜索.py --stats
```

【代码使用】
```python
from 知识库.搜索 import 搜索产品, 获取知识库统计

# 搜索产品
results = 搜索产品("旋转木马", limit=10)

# 获取统计
stats = 获取知识库统计()
```
"""

import os
import sys
import json
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from difflib import SequenceMatcher

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# ==================== 常量定义 ====================

# 搜索模式
SEARCH_MODES = {
    "精确": 1.0,      # 完全匹配
    "包含": 0.8,      # 包含关键词
    "模糊": 0.6,      # 模糊匹配
    "联想": 0.4       # 联想匹配
}

# 默认搜索配置
DEFAULT_LIMIT = 20
DEFAULT_MIN_SCORE = 0.3


# ==================== 核心功能函数 ====================

def 加载知识库(知识库路径: str = "./data/products.json") -> List[Dict[str, Any]]:
    """
    加载知识库数据
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        产品列表
    """
    if not os.path.exists(知识库路径):
        return []
    
    try:
        with open(知识库路径, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "products" in data:
            return data["products"]
        else:
            return []
    except Exception as e:
        print(f"[搜索] 加载知识库失败: {e}")
        return []


def 计算匹配度(query: str, target: str) -> float:
    """
    计算查询词与目标字符串的匹配度
    
    参数:
        query: 查询词
        target: 目标字符串
    
    返回:
        匹配度 (0-1)
    """
    if not query or not target:
        return 0.0
    
    query_lower = query.lower().strip()
    target_lower = target.lower().strip()
    
    # 完全包含
    if query_lower in target_lower:
        return 0.9
    
    # 开头匹配
    if target_lower.startswith(query_lower):
        return 0.85
    
    # SequenceMatcher
    ratio = SequenceMatcher(None, query_lower, target_lower).ratio()
    
    return ratio


def 搜索产品(
    关键词: str,
    知识库路径: str = "./data/products.json",
    类别: str = "",
    最低价: float = 0,
    最高价: float = 0,
    适用场景: str = "",
    模式: str = "模糊",
    限制: int = DEFAULT_LIMIT,
    返回分数: bool = False
) -> List[Dict[str, Any]]:
    """
    搜索产品
    
    参数:
        关键词: 搜索关键词
        知识库路径: 知识库文件路径
        类别: 产品类别筛选
        最低价: 最低价格筛选
        最高价: 最高价格筛选
        适用场景: 适用场景筛选
        模式: 搜索模式 (精确/包含/模糊/联想)
        限制: 返回结果数量限制
        返回分数: 是否返回匹配分数
    
    返回:
        搜索结果列表
    """
    # 加载知识库
    products = 加载知识库(知识库路径)
    
    if not products:
        return []
    
    # 搜索字段
    search_fields = ["名称", "型号规格", "类别", "产品卖点", "技术参数", "适用场景"]
    
    # 最小匹配分数
    min_score = DEFAULT_MIN_SCORE
    if 模式 == "精确":
        min_score = 1.0
    elif 模式 == "包含":
        min_score = 0.8
    elif 模式 == "模糊":
        min_score = 0.5
    
    results = []
    
    for product in products:
        score = 0.0
        matched_fields = []
        
        # 分类筛选
        if 类别 and 类别 not in product.get("类别", ""):
            continue
        
        # 价格筛选
        price = product.get("单价", 0)
        if 最低价 > 0 and price < 最低价:
            continue
        if 最高价 > 0 and price > 最高价:
            continue
        
        # 适用场景筛选
        if 适用场景 and 适用场景 not in product.get("适用场景", ""):
            continue
        
        # 关键词匹配
        if 关键词:
            keyword_scores = []
            
            for field in search_fields:
                value = product.get(field, "")
                if value:
                    field_score = 计算匹配度(关键词, value)
                    keyword_scores.append(field_score)
                    
                    if field_score >= min_score:
                        matched_fields.append(field)
            
            if keyword_scores:
                # 取最高分
                score = max(keyword_scores)
            else:
                # 无匹配
                continue
        
        # 添加到结果
        result = product.copy()
        
        if 返回分数:
            result["_匹配分数"] = round(score, 2)
            result["_匹配字段"] = matched_fields
        
        results.append((score, result))
    
    # 按分数排序
    results.sort(key=lambda x: x[0], reverse=True)
    
    # 限制数量
    results = results[:限制]
    
    # 返回结果
    if 返回分数:
        return [r for _, r in results]
    else:
        return [r for _, r in results]


def 获取知识库统计(知识库路径: str = "./data/products.json") -> Dict[str, Any]:
    """
    获取知识库统计信息
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        统计信息字典
    """
    products = 加载知识库(知识库路径)
    
    if not products:
        return {
            "产品总数": 0,
            "本周新增": 0,
            "最后更新": None,
            "分类统计": {},
            "价格区间": {}
        }
    
    # 计算统计
    total = len(products)
    
    # 本周新增
    now = datetime.now()
    week_ago = now.timestamp() - 7 * 24 * 60 * 60
    week_count = 0
    
    # 分类统计
    categories = {}
    
    # 价格区间
    price_ranges = {
        "10万以下": 0,
        "10-30万": 0,
        "30-50万": 0,
        "50-100万": 0,
        "100万以上": 0
    }
    
    last_update = None
    total_price = 0
    
    for product in products:
        # 时间处理
        create_time = product.get("创建时间", "")
        if create_time:
            try:
                dt = datetime.fromisoformat(create_time.replace('Z', '+00:00'))
                if dt.timestamp() >= week_ago:
                    week_count += 1
                
                if last_update is None or dt > last_update:
                    last_update = dt
            except:
                pass
        
        # 分类统计
        category = product.get("类别", "未分类")
        categories[category] = categories.get(category, 0) + 1
        
        # 价格区间
        price = product.get("单价", 0)
        total_price += price
        
        if price < 100000:
            price_ranges["10万以下"] += 1
        elif price < 300000:
            price_ranges["10-30万"] += 1
        elif price < 500000:
            price_ranges["30-50万"] += 1
        elif price < 1000000:
            price_ranges["50-100万"] += 1
        else:
            price_ranges["100万以上"] += 1
    
    # 计算平均价格
    avg_price = total_price / total if total > 0 else 0
    
    # 分类占比
    category_ratios = {}
    for cat, count in categories.items():
        category_ratios[cat] = round(count / total * 100, 1) if total > 0 else 0
    
    return {
        "产品总数": total,
        "本周新增": week_count,
        "最后更新": last_update.strftime("%Y-%m-%d %H:%M") if last_update else None,
        "平均价格": round(avg_price / 10000, 1),  # 转换为万元
        "分类统计": categories,
        "分类占比": category_ratios,
        "价格区间": price_ranges
    }


def 获取分类列表(知识库路径: str = "./data/products.json") -> List[str]:
    """
    获取所有产品分类
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        分类列表
    """
    products = 加载知识库(知识库路径)
    
    categories = set()
    for product in products:
        category = product.get("类别", "").strip()
        if category:
            categories.add(category)
    
    return sorted(list(categories))


def 获取适用场景列表(知识库路径: str = "./data/products.json") -> List[str]:
    """
    获取所有适用场景
    
    参数:
        知识库路径: 知识库文件路径
    
    返回:
        适用场景列表
    """
    products = 加载知识库(知识库路径)
    
    scenarios = set()
    for product in products:
        scenario = product.get("适用场景", "").strip()
        if scenario:
            # 分割多个场景
            for s in scenario.replace("/", ",").split(","):
                s = s.strip()
                if s:
                    scenarios.add(s)
    
    return sorted(list(scenarios))


def 格式化搜索结果(results: List[Dict[str, Any]], 显示分数: bool = True) -> str:
    """
    格式化搜索结果为文本
    
    参数:
        results: 搜索结果列表
        显示分数: 是否显示匹配分数
    
    返回:
        格式化文本
    """
    if not results:
        return "未找到匹配的产品"
    
    lines = []
    lines.append(f"找到 {len(results)} 条结果：\n")
    
    for i, product in enumerate(results, 1):
        lines.append(f"【{i}】{product.get('名称', '')}")
        lines.append(f"    规格: {product.get('型号规格', '-')}")
        lines.append(f"    类别: {product.get('类别', '-')}")
        lines.append(f"    价格: {product.get('单价', 0):,.0f}元")
        
        if 显示分数 and "_匹配分数" in product:
            lines.append(f"    匹配度: {product['_匹配分数']*100:.0f}%")
        
        if product.get('产品卖点'):
            lines.append(f"    卖点: {product.get('产品卖点', '')}")
        
        lines.append("")
    
    return "\n".join(lines)


def 格式化统计信息(stats: Dict[str, Any]) -> str:
    """
    格式化统计信息为文本
    
    参数:
        stats: 统计信息
    
    返回:
        格式化文本
    """
    lines = []
    lines.append("=" * 40)
    lines.append("📊 知识库统计")
    lines.append("=" * 40)
    lines.append(f"产品总数: {stats.get('产品总数', 0)}")
    lines.append(f"本周新增: {stats.get('本周新增', 0)}")
    lines.append(f"最后更新: {stats.get('最后更新', '-')}")
    lines.append(f"平均价格: {stats.get('平均价格', 0)}万元")
    lines.append("")
    
    lines.append("分类统计:")
    for cat, count in stats.get('分类统计', {}).items():
        ratio = stats.get('分类占比', {}).get(cat, 0)
        lines.append(f"  {cat}: {count} ({ratio}%)")
    
    lines.append("")
    lines.append("价格区间:")
    for range_name, count in stats.get('价格区间', {}).items():
        lines.append(f"  {range_name}: {count}")
    
    lines.append("=" * 40)
    
    return "\n".join(lines)


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="知识库搜索工具")
    parser.add_argument("keyword", type=str, nargs="?", help="搜索关键词")
    parser.add_argument("--category", "-c", type=str, help="按类别筛选")
    parser.add_argument("--min-price", type=float, help="最低价格")
    parser.add_argument("--max-price", type=float, help="最高价格")
    parser.add_argument("--scenario", "-s", type=str, help="适用场景")
    parser.add_argument("--mode", "-m", choices=["精确", "包含", "模糊", "联想"], default="模糊", help="搜索模式")
    parser.add_argument("--limit", "-l", type=int, default=20, help="结果数量限制")
    parser.add_argument("--stats", action="store_true", help="显示统计信息")
    parser.add_argument("--path", "-p", type=str, default="./data/products.json", help="知识库路径")
    
    args = parser.parse_args()
    
    if args.stats:
        # 显示统计信息
        stats = 获取知识库统计(args.path)
        print(格式化统计信息(stats))
        
        # 显示分类列表
        categories = 获取分类列表(args.path)
        if categories:
            print("\n可用类别:")
            for cat in categories:
                print(f"  - {cat}")
        
        # 显示适用场景
        scenarios = 获取适用场景列表(args.path)
        if scenarios:
            print("\n适用场景:")
            for sc in scenarios:
                print(f"  - {sc}")
    
    elif args.keyword:
        # 搜索产品
        results = 搜索产品(
            关键词=args.keyword,
            知识库路径=args.path,
            类别=args.category or "",
            最低价=args.min_price or 0,
            最高价=args.max_price or 0,
            适用场景=args.scenario or "",
            模式=args.mode,
            限制=args.limit,
            返回分数=True
        )
        
        print(格式化搜索结果(results, 显示分数=True))
    
    else:
        parser.print_help()
        print("\n示例:")
        print('  python 搜索.py "旋转木马"')
        print('  python 搜索.py --category "机械设备"')
        print('  python 搜索.py --stats')
