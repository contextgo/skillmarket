---
name: doubao-workplan-generator
description: "豆包内容工作计划生成器。将张鸣董事长豆包链接中的工作指示自动转化为结构化工作计划并生成可视化驾驶舱。This skill should be used when: (1) 用户提供豆包链接并要求生成工作计划, (2) 用户提到'工作计划''豆包''张鸣董事长指示', (3) 需要将豆包对话内容转化为可执行工作项, (4) 需要生成工作进度驾驶舱或可视化看板, (5) 需要按6大核心职责分类管理工作任务, (6) 用户提到'10维度工作计划''标准化工作计划', (7) 需要铯镨平台成果归档与进度跟踪。触发词：豆包工作计划、豆包链接提炼、工作计划生成、驾驶舱、工作看板、10维度计划、职责匹配。"
---

# 豆包内容工作计划生成器

## Overview

将张鸣董事长豆包链接中的工作指示，自动转化为包含10大维度的标准化工作计划，并生成实时可视化驾驶舱。实现从指令接收到成果归档的全流程管理，联动铯镨平台与6大核心职责体系。

## Core Capabilities

### 1. 豆包链接解析与提炼

接收豆包对话链接，提取并结构化输出三类核心信息：

- **核心工作要求**：董事长指示的具体工作内容和目标
- **时间节点**：提及的截止日期、阶段性时间要求
- **协同需求**：涉及的部门、人员、外部合作方

**执行方式**：使用 `web_fetch` 工具获取豆包链接页面内容，然后进行语义结构化提取。

**提炼输出格式**：
```markdown
## 豆包链接提炼结果

**来源链接**：[豆包URL]
**生成日期**：YYYY-MM-DD

### 核心工作要求
1. [要求1]
2. [要求2]

### 时间节点
- [节点1]：YYYY-MM-DD
- [节点2]：YYYY-MM-DD

### 协同需求
- [部门/人员]：[协同内容]
```

### 2. 6大职责场景匹配

将提炼的工作内容与6大核心职责进行智能匹配。读取 `references/responsibilities.md` 获取完整职责定义和匹配规则。

**匹配流程**：
1. 对提炼的每项工作要求，扫描6大职责的关键词列表
2. 按关键词命中数量排序，选择匹配度最高的职责作为主职责
3. 标注关联职责（如有跨职责协作需求）
4. 匹配结果需明确：主职责编号、匹配关键词、关联职责

### 3. 10维度标准化工作计划生成

按10大维度填充工作计划表格。读取 `references/dimensions.md` 获取字段详细定义和填写规范。

**10大维度**：
| 序号 | 维度 | 说明 |
|------|------|------|
| 1 | 豆包链接信息 | 来源链接 + 生成日期 |
| 2 | 工作时间 | 起止日期 + 截止日期 |
| 3 | 工作项名称 | [职责标签] + 动词 + 对象 |
| 4 | 工作描述 | 详细任务说明（100-300字） |
| 5 | 协同人 | 姓名 + 角色/部门 |
| 6 | 预期量化成果 | 按职责模板自动匹配 |
| 7 | 成果完成情况 | 未开始/进行中/已完成/受阻 |
| 8 | 成果链接 | 默认关联铯镨平台路径 |
| 9 | 工作未完成原因 | 阻塞因素说明 |
| 10 | 豆包链接提炼与工作心得 | 核心要点 + 工作反思 |

**量化成果自动匹配**：读取 `references/quantified-outputs.md`，根据匹配的职责类别自动选择典型成果组合。

### 4. 可视化驾驶舱生成

生成独立HTML驾驶舱页面，包含六大模块：

- **统计概览**：总任务/已完成/进行中/未开始 四卡片
- **职责模块分布**：Chart.js环形图
- **工作计划表格**：10维度可交互表格，支持勾选更新状态
- **协同人关联面板**：各协同人关联任务与对接状态
- **进度时间线**：按工作时间排列的关键节点
- **铯镨平台成果归档**：可点击链接跳转

驾驶舱模板位于 `assets/dashboard-template.html`，使用该模板时需将工作计划JSON数据注入到模板的 `WORKPLAN_DATA` 变量中。

### 5. 数据管理与持久化

使用 `scripts/workplan-manager.py` 管理工作计划数据：

- 工作计划以JSON格式存储在用户工作目录的 `.workplan/` 文件夹
- 支持创建、更新状态、添加/删除工作项、导出Markdown
- 驾驶舱中的勾选操作通过修改JSON数据实现状态更新

---

## Workflow

### 完整工作流程（四阶段流水线）

```
阶段1：解析 → 阶段2：匹配 → 阶段3：生成 → 阶段4：可视化
```

#### 阶段1：豆包链接解析

1. 接收用户提供的豆包链接URL
2. 使用 `web_fetch` 工具提取页面文本内容
3. 对提取内容进行语义结构化分析，输出：核心工作要求、时间节点、协同需求
4. 自动同步豆包链接生成日期

**注意**：若 `web_fetch` 无法访问豆包链接（如需登录），提示用户直接粘贴豆包对话内容，然后执行相同的结构化提取。

#### 阶段2：职责场景匹配

1. 读取 `references/responsibilities.md` 获取6大职责定义和关键词
2. 对每项提炼的工作要求进行关键词扫描和语义匹配
3. 确定主职责和关联职责
4. 读取 `references/quantified-outputs.md` 匹配量化成果模板

#### 阶段3：10维度工作计划生成

1. 读取 `references/dimensions.md` 获取字段填写规范
2. 按规范填充10维度数据，生成Markdown格式表格
3. 使用 `scripts/workplan-manager.py` 将数据存储为JSON文件
4. JSON文件存储路径：`{workspace}/.workplan/workplan-YYYY-MM-DD.json`

**JSON数据结构**：
```json
{
  "meta": {
    "created_at": "YYYY-MM-DD",
    "source_links": ["豆包URL"],
    "total_tasks": 0
  },
  "tasks": [
    {
      "id": "T001",
      "doubao_link": {
        "url": "https://www.doubao.com/chat/xxxxx",
        "generated_date": "YYYY-MM-DD"
      },
      "work_time": {
        "start_date": "YYYY-MM-DD",
        "end_date": "YYYY-MM-DD",
        "deadline": "YYYY-MM-DD"
      },
      "task_name": "[职责标签] 工作项名称",
      "task_desc": "详细描述",
      "collaborators": [
        {"name": "姓名", "role": "角色", "type": "primary|secondary"}
      ],
      "expected_output": "量化成果描述",
      "completion_status": "not_started|in_progress|completed|blocked",
      "output_link": "https://ciip.com/projects/xxx/deliverables/",
      "incomplete_reason": "",
      "insights": "提炼与心得"
    }
  ]
}
```

#### 阶段4：可视化驾驶舱生成

1. 读取 `assets/dashboard-template.html` 驾驶舱模板
2. 将工作计划JSON数据注入模板的 `WORKPLAN_DATA` 变量
3. 生成完整的独立HTML文件到用户工作目录
4. 使用 `preview_url` 展示驾驶舱页面

**输出路径**：`{workspace}/.workplan/dashboard-YYYY-MM-DD.html`

---

## Quick Reference

| 场景 | 操作 |
|------|------|
| 用户提供豆包链接 | 阶段1→2→3→4 完整流程 |
| 用户直接粘贴豆包内容 | 跳过web_fetch，直接结构化提取后→阶段2→3→4 |
| 更新工作项完成状态 | 使用workplan-manager.py update命令 |
| 仅生成驾驶舱 | 读取已有JSON数据→阶段4 |
| 添加新工作项 | 使用workplan-manager.py add命令 |
| 导出Markdown表格 | 使用workplan-manager.py export命令 |

## 铯镨平台联动规范

- 成果链接默认路径模板：`https://ciip.com/projects/{project_name}/deliverables/`
- 项目名称命名规则：中文拼音首字母缩写 + 功能描述（如 `ymjd-homepage-redesign`）
- 驾驶舱中所有成果链接均可点击跳转至铯镨平台
- 支持批量关联铯镨平台项目文件夹

## 适配场景

- **跨部门协同推进**：通过协同人维度和对接状态管理跨部门协作
- **项目全流程管理**：从豆包指示到成果归档的端到端管理
- **成果沉淀追溯**：10维度完整记录，支持按时间/职责/协同人检索
- **铯镨平台运营支持**：成果链接关联平台路径，驾驶舱实时展示运营进度

## Resources

### references/

- `responsibilities.md` — 6大核心职责详细定义、关键词列表、匹配规则
- `dimensions.md` — 10大维度字段定义、填写规范、示例
- `quantified-outputs.md` — 各职责对应的量化成果标准模板与典型组合

### scripts/

- `workplan-manager.py` — 工作计划JSON数据管理脚本，支持create/update/add/delete/export子命令

### assets/

- `dashboard-template.html` — 可视化驾驶舱HTML模板（Chart.js + 内联CSS/JS）
