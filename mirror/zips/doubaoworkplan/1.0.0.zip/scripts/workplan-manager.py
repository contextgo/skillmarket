#!/usr/bin/env python3
"""
Workplan Manager - 工作计划JSON数据管理脚本

Usage:
    workplan-manager.py create --date YYYY-MM-DD [--output PATH]
    workplan-manager.py add --file PATH --task JSON_STRING
    workplan-manager.py update --file PATH --task-id ID --status STATUS
    workplan-manager.py delete --file PATH --task-id ID
    workplan-manager.py list --file PATH [--status STATUS] [--duty R1-R6]
    workplan-manager.py export --file PATH --format markdown [--output PATH]
"""

import sys
import os
import json
import argparse
from datetime import datetime
from pathlib import Path


def load_workplan(filepath):
    """Load workplan JSON data from file."""
    path = Path(filepath)
    if not path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_workplan(filepath, data):
    """Save workplan JSON data to file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"Saved: {filepath}")


def create_workplan(args):
    """Create a new workplan JSON file."""
    date_str = args.date or datetime.now().strftime('%Y-%m-%d')
    data = {
        "meta": {
            "created_at": date_str,
            "source_links": [],
            "total_tasks": 0
        },
        "tasks": []
    }

    output_dir = Path(args.output) if args.output else Path('.')
    output_dir.mkdir(parents=True, exist_ok=True)
    filepath = output_dir / f"workplan-{date_str}.json"
    save_workplan(str(filepath), data)


def add_task(args):
    """Add a new task to workplan."""
    data = load_workplan(args.file)

    try:
        task = json.loads(args.task)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON string: {e}")
        sys.exit(1)

    # Auto-generate task ID
    existing_ids = [t['id'] for t in data['tasks']]
    max_num = 0
    for tid in existing_ids:
        try:
            num = int(tid.replace('T', ''))
            max_num = max(max_num, num)
        except ValueError:
            pass
    task['id'] = f"T{max_num + 1:03d}"

    # Set defaults
    if 'completion_status' not in task:
        task['completion_status'] = 'not_started'
    if 'output_link' not in task:
        task['output_link'] = '待上传'
    if 'incomplete_reason' not in task:
        task['incomplete_reason'] = ''
    if 'insights' not in task:
        task['insights'] = ''

    data['tasks'].append(task)
    data['meta']['total_tasks'] = len(data['tasks'])

    # Update source links
    if task.get('doubao_link', {}).get('url'):
        url = task['doubao_link']['url']
        if url not in data['meta']['source_links']:
            data['meta']['source_links'].append(url)

    save_workplan(args.file, data)
    print(f"Added task: {task['id']} - {task.get('task_name', 'Untitled')}")


def update_status(args):
    """Update task completion status."""
    valid_statuses = ['not_started', 'in_progress', 'completed', 'blocked']
    if args.status not in valid_statuses:
        print(f"Error: Invalid status '{args.status}'. Must be one of: {', '.join(valid_statuses)}")
        sys.exit(1)

    data = load_workplan(args.file)
    task = next((t for t in data['tasks'] if t['id'] == args.task_id), None)
    if not task:
        print(f"Error: Task not found: {args.task_id}")
        sys.exit(1)

    old_status = task['completion_status']
    task['completion_status'] = args.status
    save_workplan(args.file, data)
    print(f"Updated {args.task_id}: {old_status} → {args.status}")


def delete_task(args):
    """Delete a task from workplan."""
    data = load_workplan(args.file)
    original_len = len(data['tasks'])
    data['tasks'] = [t for t in data['tasks'] if t['id'] != args.task_id]

    if len(data['tasks']) == original_len:
        print(f"Error: Task not found: {args.task_id}")
        sys.exit(1)

    data['meta']['total_tasks'] = len(data['tasks'])
    save_workplan(args.file, data)
    print(f"Deleted task: {args.task_id}")


def list_tasks(args):
    """List tasks with optional filtering."""
    data = load_workplan(args.file)
    tasks = data['tasks']

    # Filter by status
    if args.status:
        tasks = [t for t in tasks if t['completion_status'] == args.status]

    # Filter by duty
    if args.duty:
        import re
        tasks = [t for t in tasks if re.search(rf'\[{args.duty}', t.get('task_name', ''))]

    if not tasks:
        print("No tasks found.")
        return

    # Print table
    print(f"\n{'ID':<6} {'工作项名称':<30} {'完成情况':<10} {'截止日期':<12}")
    print('-' * 62)
    for t in tasks:
        status_map = {
            'not_started': '⬜ 未开始',
            'in_progress': '🔵 进行中',
            'completed': '✅ 已完成',
            'blocked': '🔴 受阻'
        }
        status_str = status_map.get(t['completion_status'], t['completion_status'])
        end_date = t.get('work_time', {}).get('end_date', '-')
        name = t.get('task_name', 'Untitled')[:28]
        print(f"{t['id']:<6} {name:<30} {status_str:<10} {end_date:<12}")

    print(f"\n共 {len(tasks)} 项任务")


def export_markdown(args):
    """Export workplan as Markdown table."""
    data = load_workplan(args.file)
    tasks = data['tasks']

    status_map = {
        'not_started': '⬜ 未开始',
        'in_progress': '🔵 进行中',
        'completed': '✅ 已完成',
        'blocked': '🔴 受阻'
    }

    md = f"# 豆包工作计划\n\n"
    md += f"生成日期：{data['meta']['created_at']}\n"
    md += f"来源链接：{', '.join(data['meta'].get('source_links', [])) or '无'}\n\n"

    md += "| 序号 | 豆包链接 | 工作时间 | 工作项名称 | 工作描述 | 协同人 | 预期量化成果 | 完成情况 | 成果链接 | 未完成原因 | 提炼与心得 |\n"
    md += "|------|----------|----------|------------|----------|--------|--------------|----------|----------|------------|------------|\n"

    for i, t in enumerate(tasks, 1):
        time_str = f"{t.get('work_time', {}).get('start_date', '')}~{t.get('work_time', {}).get('end_date', '')}" if t.get('work_time') else '-'
        link_str = f"[链接]({t.get('doubao_link', {}).get('url', '')}) {t.get('doubao_link', {}).get('generated_date', '')}" if t.get('doubao_link') else '-'
        collab_str = '、'.join([c.get('name', '') for c in t.get('collaborators', [])]) or '-'
        status_str = status_map.get(t.get('completion_status', ''), t.get('completion_status', ''))

        md += f"| {i} | {link_str} | {time_str} | {t.get('task_name', '-')} | {t.get('task_desc', '-')} | {collab_str} | {t.get('expected_output', '-')} | {status_str} | {t.get('output_link', '待上传')} | {t.get('incomplete_reason', '-')} | {t.get('insights', '-')} |\n"

    # Determine output path
    if args.output:
        output_path = args.output
    else:
        date_str = data['meta']['created_at']
        output_path = f"workplan-{date_str}.md"

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(md)

    print(f"Exported Markdown: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description='Workplan Manager - 工作计划数据管理工具'
    )
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # create
    p_create = subparsers.add_parser('create', help='创建新的工作计划文件')
    p_create.add_argument('--date', help='日期 YYYY-MM-DD')
    p_create.add_argument('--output', help='输出目录')

    # add
    p_add = subparsers.add_parser('add', help='添加工作项')
    p_add.add_argument('--file', required=True, help='工作计划JSON文件路径')
    p_add.add_argument('--task', required=True, help='工作项JSON字符串')

    # update
    p_update = subparsers.add_parser('update', help='更新工作项状态')
    p_update.add_argument('--file', required=True, help='工作计划JSON文件路径')
    p_update.add_argument('--task-id', required=True, help='工作项ID')
    p_update.add_argument('--status', required=True,
                          choices=['not_started', 'in_progress', 'completed', 'blocked'],
                          help='新状态')

    # delete
    p_delete = subparsers.add_parser('delete', help='删除工作项')
    p_delete.add_argument('--file', required=True, help='工作计划JSON文件路径')
    p_delete.add_argument('--task-id', required=True, help='工作项ID')

    # list
    p_list = subparsers.add_parser('list', help='列出工作项')
    p_list.add_argument('--file', required=True, help='工作计划JSON文件路径')
    p_list.add_argument('--status', help='按状态筛选')
    p_list.add_argument('--duty', help='按职责筛选 (R1-R6)')

    # export
    p_export = subparsers.add_parser('export', help='导出工作计划')
    p_export.add_argument('--file', required=True, help='工作计划JSON文件路径')
    p_export.add_argument('--format', required=True, choices=['markdown'], help='导出格式')
    p_export.add_argument('--output', help='输出文件路径')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        'create': create_workplan,
        'add': add_task,
        'update': update_status,
        'delete': delete_task,
        'list': list_tasks,
        'export': export_markdown,
    }

    commands[args.command](args)


if __name__ == '__main__':
    main()
