# 抗体突变分析 — 防错与修正技能

> **版本**: v1.0 | **创建日期**: 2026-05-07 | **来源**: H-GAMMA-1 突变位点推荐错误的实战复盘

---

## 1. 背景：一次真实错误

在 H-GAMMA-1 抗体的低 pH 敏感性改造分析中，原始报告推荐的 3 个核心突变**全部无效**：

| 推荐突变 | 声称的原氨基酸 | 实际该位置氨基酸 | 状态 |
|---|---|---|---|
| F35H | F (苯丙氨酸) | **H (组氨酸)** | ❌ 位置35已是His |
| D26H | D (天冬氨酸) | **G (甘氨酸)** | ❌ AA完全对不上 |
| N52H | N (天冬酰胺) | **S (丝氨酸)** | ❌ AA完全对不上 |

### 根因三要素

```
CDR边界硬编码偏移(30-35通用近似值) 
    + 0-based/1-based索引混用
    + 缺少反向校验步骤
    = 输出全部错误
```

**关键教训**：这不是模型能力问题，是方法论缺陷。任何AI/人/脚本跑同一个有缺陷的流程都会出同样的错。

---

## 2. 三大易错陷阱

### 陷阱① CDR边界"拍脑袋"（最常见）

**❌ 错误做法**：硬编码通用CDR范围

```python
# 从教科书抄来的近似值 —— 不同抗体会偏移！
'CDR-H1': {'start': 30, 'end': 35}   # 危险！
'CDR-H2': {'start': 49, 'end': 66}   # 危险！
'CDR-L1': {'start': 23, 'end': 33}   # 危险！
```

**为什么出错**：
- 不同抗体框架区(FR)长度不同（±2~5个AA很常见）
- 轻链κ vs λ 的CDR-L1起始位置不同
- 人源化/嵌合抗体的框架可能非标准

**✅ 正确做法**：

| 方法 | 工具 | 精度 | 备注 |
|---|---|---|---|
| **IMGT编号** | ANARCI (Python包) | ⭐⭐⭐⭐⭐ | 行业标准，推荐首选 |
| **Kabat编号** | AbRSA / IgBLAST | ⭐⭐⭐⭐ | 经典方案 |
| **序列模体匹配** | 手工找保守锚点 | ⭐⭐⭐ | 无工具时可用 |

**模体匹配法（无工具时的保底方案）**：

```python
def find_cdr_by_anchors(hc_seq):
    """利用保守锚点确定CDR边界"""
    anchors = {
        'FR1_end_CYS': hc_seq.find('C'),           # FR1末端的Cys (~26)
        'CDR1_start_after_C': None,                # Cys后的区域
        'W_in_FR2': hc_seq.find('W', 35),          # FR2中的Trp (~41)
        'CDR2_before_W': None,
        'FR3_conserved': None,                     # FR3保守 motif
    }
    # 基于锚点推算CDR边界，而非硬编码绝对位置
    # ...
```

**保守锚点参考**：

| 锚点 | 位置(约) | 序列特征 | 用途 |
|---|---|---|---|
| Cys1 | ~22-26 | `C` (形成二硫键) | FR1/CDR-H1分界 |
| Trp36 | ~41 | `W` | CDR-H1/FR2分界 |
| Cys92/104 | ~92,104 | `C` (另一个二硫键) | FR3/CDR-H3分界 |
| Phe/Tyr | CDR-H3前 | `F/Y/W` | CDR-H3起始标志 |

---

### 陷阱② 索引系统混用

Python内部用0-based (`seq[34]` = 第35个字符)，但生物学家习惯1-based（"第35位氨基酸"）。

**混用典型场景**：

```python
# 内部计算用0-based
pos_0based = 34
aa_at_pos = HC[pos_0based]  # HC[34]

# 报告输出时有时+1有时没加 → 混乱
report_position = pos_0based + 1       # 有时做了
report_position = pos_0based           # 有时忘了
```

**✅ 防御策略**：全程统一使用一种编号

```python
class SeqPosition:
    """统一的位置编号管理器"""
    def __init__(self, sequence, system='1-based'):
        self.seq = sequence
        self.system = system
    
    def aa_at(self, pos):
        """无论外部用什么体系，内部统一转0-based再读取"""
        idx = pos - 1 if self.system == '1-based' else pos
        assert 0 <= idx < len(self.seq), f"位置{pos}超出范围[1,{len(self.seq)}]"
        return self.seq[idx]
    
    def context(self, pos, window=3):
        """返回该位置前后各window个AA的上下文"""
        idx = pos - 1 if self.system == '1-based' else pos
        start = max(0, idx - window)
        end = min(len(self.seq), idx + window + 1)
        return self.seq[start:end], list(range(start+1, end+1))

# 使用
seq = SeqPosition(HC, system='1-based')
print(seq.aa_at(35))      # 自动处理转换
print(seq.context(35))     # 返回上下文方便检查
```

---

### 陷阱③ 缺少反向校验（最致命）

**这是成本最低、收益最高的防线。**

```
生成推荐 ≠ 完成
生成推荐 + 回读校验通过 = 完成
```

**✅ 必须执行的校验函数**：

```python
def validate_mutations(sequence, mutations):
    """
    突变推荐的反向校验 —— 输出前的必经之路
    
    Args:
        sequence: str, 完整氨基酸序列(1-based语义)
        mutations: List[dict], 每个元素包含:
            - name: str (如 "D31H")
            - position: int (1-based位置)
            - claimed_original: str (声称的原氨基酸)
    
    Returns:
        bool: True=全部通过, False=存在错误
    
    Raises:
        ValueError: 校验失败时抛出(阻止输出)
    """
    AA_NAME = {
        'A':'Ala','R':'Arg','N':'Asn','D':'Asp','C':'Cys','E':'Glu','Q':'Gln',
        'G':'Gly','H':'His','I':'Ile','L':'Leu','K':'Lys','M':'Met','F':'Phe',
        'P':'Pro','S':'Ser','T':'Thr','W':'Trp','Y':'Tyr','V':'Val'
    }
    
    errors = []
    warnings = []
    
    for m in mutations:
        pos = m['position']
        claimed = m['claimed_original'].upper()
        mut_name = m.get('name', f"{claimed}{pos}?")
        
        # 1. 边界检查
        idx = pos - 1  # 转0-based
        if idx < 0 or idx >= len(sequence):
            errors.append(f"[越界] {mut_name}: 位置{pos}超出序列长度({len(sequence)})")
            continue
        
        real_aa = sequence[idx].upper()
        
        # 2. AA一致性检查（最关键！）
        if real_aa != claimed:
            errors.append(
                f"[AA不匹配] {mut_name}: "
                f"声称原AA={claimed}({AA_NAME.get(claimed,'?')}) "
                f"→ 实际={real_aa}({AA_NAME.get(real_aa,'?')})"
            )
            
            # 打印上下文
            ctx_start = max(0, idx - 5)
            ctx_end = min(len(sequence), idx + 6)
            ctx_seq = sequence[ctx_start:ctx_end]
            highlight = ''.join(
                '^' if i == idx - ctx_start else c 
                for i, c in enumerate(ctx_seq)
            )
            print(f"  上下文 [{ctx_start+1}:{ctx_end}]: {ctx_seq}")
            print(f"  {' '*12}              {highlight}")
        
        # 3. 无意义突变检查
        target = mut_name[-1].upper()  # 突变目标AA
        if real_aa == target:
            errors.append(
                f"[无意义突变] {mut_name}: "
                f"位置{pos}已经是{real_aa}({AA_NAME.get(real_aa,'?')}), "
                f"突变为{target}没有效果"
            )
        
        # 4. 特殊警告
        if real_aa == 'C':
            warnings.append(f"[警告] {mut_name}: 位置{pos}是Cys, 可能涉及二硫键, 突变需谨慎")
        if real_aa in ('P', 'G') and target not in ('P', 'G'):
            warnings.append(f"[注意] {mut_name}: 原{real_aa}影响骨架构象, 突变可能改变结构")
    
    # 输出报告
    print("\n" + "=" * 60)
    print("🔬 突变校验报告")
    print("=" * 60)
    print(f"待校验突变数: {len(mutations)}")
    print(f"✅ 通过: {len(mutations) - len(errors)}")
    print(f"❌ 错误: {len(errors)}")
    print(f"⚠️  警告: {len(warnings)}")
    
    if errors:
        print("\n❌ 致命错误:")
        for e in errors:
            print(f"  • {e}")
    
    if warnings:
        print("\n⚠️  警告信息:")
        for w in warnings:
            print(f"  • {w}")
    
    # 决策
    if errors:
        print("\n" + "!" * 60)
        print("🛑 校验未通过! 请勿使用这些突变推荐!")
        print("请先修复以上错误后重新运行。")
        print("!" * 60)
        raise ValueError(f"突变校验失败: {len(errors)} 个错误")
    elif warnings:
        print("\n⚠️  校验通过但有警告, 请人工审核后决定是否继续。")
    else:
        print("\n✅ 全部校验通过!")
    
    return len(errors) == 0


# ═══════════ 使用示例 ═══════════
if __name__ == "__main__":
    HC = "EVQLVESGGGLVQPGGSLRLSCAASGFTFSDSWIHWVRQAPGKGLEWVA..."
    
    # 模拟之前错误的推荐数据
    wrong_mutations = [
        {"name": "F35H", "position": 35, "claimed_original": "F"},
        {"name": "D26H", "position": 26, "claimed_original": "D"},
        {"name": "N52H", "position": 52, "claimed_original": "N"},
    ]
    
    try:
        validate_mutations(HC, wrong_mutations)
    except ValueError as e:
        print(f"\n已拦截: {e}")
```

**预期输出**（能100%拦截之前的错误）：

```
============================================================
🔬 突变校验报告
============================================================
待校验突变数: 3
✅ 通过: 0
❌ 错误: 3
⚠️  警告: 0

❌ 致命错误:
  • [AA不匹配] F35H: 声称原AA=F(Ala) → 实际=H(His)
  • [无意义突变] F35H: 位置35已经是H(His), 突变为H没有效果
  • [AA不匹配] D26H: 声称原AA=D(Asp) → 实际=G(Gly)
  • [AA不匹配] N52H: 声称原AA=N(Asn) → 实际=S(Ser)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
🛑 校验未通过! 请勿使用这些突变推荐!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

已拦截: 突变校验失败: 4 个错误
```

---

## 3. 正确流程（标准操作程序 SOP）

```
┌─────────────────────────────────────────────────────┐
│                  抗体突变分析 SOP                    │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ① 输入序列                                         │
│     └─ 记录来源/版本号                               │
│                                                     │
│  ② CDR精确定位 ★★★                                  │
│     ├─ 方案A: ANARCI / IMGT编号 (推荐)               │
│     ├─ 方案B: AbRSA / Kabat编号                      │
│     └─ 方案C: 保守锚点模体匹配 (无工具时)             │
│                                                     │
│  ③ 筛选候选位点                                     │
│     ├─ CDR内优先                                     │
│     ├─ 排除结构关键残基(Cys, Pro保守区)              │
│     └─ 统一使用1-based编号                           │
│                                                     │
│  ④ 生成推荐突变                                     │
│                                                     │
│  ⑤ ★★★ 反向校验 (必经!) ★★★                         │
│     ├─ 逐位回读实际AA                                │
│     ├─ 与声称的原AA比对                              │
│     ├─ 检查无意义突变(AA→相同AA)                    │
│     └─ 输出上下文供肉眼审查                          │
│                                                     │
│  ⑥ 校验通过? ───No──→ 回到③修正                    │
│         │                                          │
│        Yes                                         │
│         ↓                                          │
│  ⑦ 输出最终报告                                     │
│     ├─ 包含每个位点的实际AA确认                      │
│     ├─ 附上校验通过标记                              │
│     └─ 提供完整可重现参数                            │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**步骤⑤不可跳过**——这是整个流程中ROI最高的一步。

---

## 4. 快速排查清单（Checklist）

在输出任何突变推荐之前，逐项勾选：

- [ ] **CDR边界不是硬编码的**？是否用了IMGT/Kabat编号或锚点定位？
- [ ] **编号体系统一**？全程只用了1-based（或者只用了0-based）？
- [ ] **反向校验已执行**？每个推荐都回读了实际AA？
- [ ] **无意义突变已排除**？没有"A→A"这种？
- [ ] **关键残基已标注**？Cys/Pro/Gly等特殊位置的突变有警告？
- [ ] **上下文已打印**？每个推荐位点前后3-5个AA可见？
- [ ] **结果可复现**？记录了所有参数和版本号？

> **如果有任何一项打 ❌，不要提交结果。**

---

## 5. 适用场景扩展

本技能的核心理念（**反向校验 + 编号统一 + 边界验证）**不仅适用于抗体突变分析，还适用于：

| 场景 | 易错项 | 同样需要校验的 |
|---|---|---|
| 基因变异注释 | cDNA位置 ↔ 蛋白质位置映射 | 外显子编号 |
| ChIP-seq peak注释 | genome build版本 (hg19 vs hg38) | 坐标系一致性 |
| 蛋白质结构域预测 | UniProt编号 vs PDB编号 | 链ID差异 |
| CRISPR gRNA设计 | 基因组坐标 vs 转录本坐标 | exon-intron边界 |
| 引物设计 | 正负链方向 | 产物长度反算 |

**共同原则**：
> 凡是涉及「把一个坐标系的信息映射到另一个坐标系的任务」，都必须做反向校验。

---

## 6. 参考资源

| 资源 | 说明 | 链接 |
|---|---|---|
| ANARCI | Python抗体编号工具 | `pip install anarci` |
| IMGT | 国际免疫遗传学信息系统 | imgt.org |
| Kabat Database | 抗体经典编号数据库 | kabatdatabase.com |
| AbRSA | 抗体结构分析工具箱 | github.com |
| PyIgClassify | Python Ig分类与编号 | pip install pyigclassify |

---

*本文档基于真实生产环境中的错误复盘编写。每一个建议背后都有血泪教训。*
*最后更新: 2026-05-07*
