# -*- coding: utf-8 -*-
"""
今日头条热门新闻获取技能 - 脚本包
"""

from .fetch_toutiao_hot_news import ToutiaoHotNewsFetcher

__all__ = ['ToutiaoHotNewsFetcher']
__version__ = '1.0'
__author__ = '魏星'
