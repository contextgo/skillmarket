#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
今日头条热门新闻获取脚本
功能：自动获取今日头条最新、最热门的前 10 个头条新闻
作者：魏星
版本：1.0
日期：2026-04-03
"""

import requests
import json
import re
from datetime import datetime


class ToutiaoHotNewsFetcher:
    """今日头条热榜新闻抓取器"""
    
    def __init__(self, limit=10):
        """
        初始化抓取器
        
        Args:
            limit: 获取新闻条数，默认 10 条（最大 50）
        """
        self.limit = min(limit, 50)  # 限制最大 50 条
        self.api_url = "https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Referer': 'https://www.toutiao.com/'
        }
    
    def fetch_hot_news(self):
        """
        获取热门新闻列表
        
        Returns:
            list: 新闻列表，每条新闻包含 rank, title, hot_value, category, label, url
            None: 如果请求失败
        """
        try:
            # 发送 HTTP 请求
            response = requests.get(self.api_url, headers=self.headers, timeout=10)
            
            # 检查响应状态码
            if response.status_code != 200:
                print(f"错误：HTTP 状态码异常 {response.status_code}")
                return None
            
            # 解析 JSON 数据
            data = response.json()
            
            # 验证数据结构
            if 'data' not in data or not isinstance(data['data'], list):
                print("错误：API 返回数据格式异常")
                return None
            
            news_list = []
            
            # 提取前 limit 条新闻
            for idx, item in enumerate(data['data'][:self.limit], start=1):
                # 提取并处理 URL
                raw_url = item.get('Url', '')
                clean_url = self._extract_clean_url(raw_url)
                
                # 构建新闻对象（确保 hot_value 转换为整数）
                hot_value_raw = item.get('HotValue', '0')
                try:
                    hot_value_int = int(hot_value_raw) if hot_value_raw else 0
                except (ValueError, TypeError):
                    hot_value_int = 0
                
                news_item = {
                    'rank': idx,
                    'title': item.get('Title', ''),
                    'hot_value': hot_value_int,
                    'category': item.get('Category', ''),
                    'label': item.get('Label', ''),
                    'url': clean_url
                }
                
                news_list.append(news_item)
            
            return news_list
            
        except requests.exceptions.Timeout:
            print("错误：请求超时")
            return None
        except requests.exceptions.RequestException as e:
            print(f"错误：网络请求失败 - {str(e)}")
            return None
        except json.JSONDecodeError:
            print("错误：JSON 解析失败")
            return None
        except Exception as e:
            print(f"错误：未知异常 - {str(e)}")
            return None
    
    def _extract_clean_url(self, raw_url):
        """
        从原始 URL 中提取干净的链接（去除冗余参数）
        
        Args:
            raw_url: 原始 URL 字符串
            
        Returns:
            str: 清理后的 URL
        """
        if not raw_url:
            return ''
        
        # 使用正则表达式提取 trending ID
        match = re.search(r'(?<=https://www\.toutiao\.com/trending/)\d+', raw_url)
        if match:
            news_id = match.group(0)
            return f'https://www.toutiao.com/trending/{news_id}/'
        
        # 如果匹配失败，返回原始 URL（截断过长的参数）
        if '?' in raw_url:
            return raw_url.split('?')[0]
        
        return raw_url
    
    def format_text(self, news_list):
        """
        格式化为文本输出
        
        Args:
            news_list: 新闻列表
            
        Returns:
            str: 格式化后的文本
        """
        if not news_list:
            return "未获取到新闻数据"
        
        update_time = datetime.now().strftime('%Y-%m-%d %H:%M')
        output = []
        output.append(f"【今日头条热榜 TOP{len(news_list)}】更新时间：{update_time}\n")
        
        for news in news_list:
            # 热度值格式化（超过 100 万显示为万）
            hot_value = news['hot_value']
            if hot_value >= 1000000:
                hot_str = f"{hot_value / 1000000:.1f}万"
            elif hot_value >= 10000:
                hot_str = f"{hot_value / 10000:.1f}万"
            else:
                hot_str = str(hot_value)
            
            output.append(f"{news['rank']}. [{news['category']}] {news['title']} 🔥 热度：{hot_str}")
            output.append(f"   链接：{news['url']}")
            output.append("")
        
        return '\n'.join(output)
    
    def format_markdown_table(self, news_list):
        """
        格式化为 Markdown 表格
        
        Args:
            news_list: 新闻列表
            
        Returns:
            str: Markdown 表格
        """
        if not news_list:
            return "未获取到新闻数据"
        
        update_time = datetime.now().strftime('%Y-%m-%d %H:%M')
        output = []
        output.append(f"### 今日头条热榜 TOP{len(news_list)}\n")
        output.append(f"*更新时间：{update_time}*\n")
        output.append("| 排名 | 分类 | 标题 | 热度值 | 链接 |")
        output.append("|------|------|------|--------|------|")
        
        for news in news_list:
            hot_value = news['hot_value']
            if hot_value >= 1000000:
                hot_str = f"{hot_value / 1000000:.1f}万"
            elif hot_value >= 10000:
                hot_str = f"{hot_value / 10000:.1f}万"
            else:
                hot_str = str(hot_value)
            
            # 标题截断（超过 30 字显示省略号）
            title = news['title']
            if len(title) > 30:
                title = title[:28] + '...'
            
            output.append(f"| {news['rank']} | {news['category']} | {title} | {hot_str} | [查看]({news['url']}) |")
        
        return '\n'.join(output)
    
    def format_json(self, news_list):
        """
        格式化为 JSON 输出
        
        Args:
            news_list: 新闻列表
            
        Returns:
            str: JSON 字符串
        """
        result = {
            'update_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_count': len(news_list) if news_list else 0,
            'news_list': news_list if news_list else []
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
    
    def save_to_file(self, news_list, filename='toutiao_hot_news.txt', format_type='text'):
        """
        保存新闻数据到文件
        
        Args:
            news_list: 新闻列表
            filename: 输出文件名
            format_type: 输出格式 ('text', 'markdown', 'json')
        """
        if not news_list:
            print("错误：没有可保存的数据")
            return
        
        # 根据格式选择格式化方法
        if format_type == 'text':
            content = self.format_text(news_list)
        elif format_type == 'markdown':
            content = self.format_markdown_table(news_list)
        elif format_type == 'json':
            content = self.format_json(news_list)
        else:
            print(f"错误：未知的格式类型 '{format_type}'")
            return
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✓ 数据已保存到文件：{filename}")
        except Exception as e:
            print(f"错误：文件保存失败 - {str(e)}")


def main():
    """主函数"""
    print("=" * 60)
    print("今日头条热门新闻获取工具 v1.0")
    print("=" * 60)
    print()
    
    # 创建抓取器实例（获取前 10 条）
    fetcher = ToutiaoHotNewsFetcher(limit=10)
    
    print("正在获取今日头条热榜数据...")
    print()
    
    # 获取新闻列表
    news_list = fetcher.fetch_hot_news()
    
    if news_list:
        # 输出文本格式
        print(fetcher.format_text(news_list))
        
        # 可选：保存到其他格式
        # fetcher.save_to_file(news_list, 'toutiao_hot_news.md', format_type='markdown')
        # fetcher.save_to_file(news_list, 'toutiao_hot_news.json', format_type='json')
    else:
        print("\n获取新闻失败，请检查网络连接后重试。")


if __name__ == '__main__':
    main()
