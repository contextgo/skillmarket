---
name: toutiao-hot-news
description: 自动从今日头条获取最新、最热门的前 10 个头条新闻，支持获取热榜排名、标题、热度值、分类和链接
license: Apache-2.0
metadata:
  author: 魏星
  version: "1.0"
  created: 2026-04-03
compatibility: Python 3.8+, requests 库，需要网络连接
allowed-tools: execute_shell, create_file
---

# 今日头条热门新闻获取技能

## 使用场景

当你需要获取今日头条实时热门新闻时使用此技能，适用于：
- 舆情监控和热点追踪
- 新闻资讯聚合展示
- 市场趋势分析
- 内容创作选题参考
- 每日新闻简报生成

## 功能特性

- ✅ 获取今日头条热榜前 10 条热门新闻
- ✅ 包含完整字段：排名、标题、热度值、分类、标签、链接
- ✅ 支持多种输出格式：文本列表、JSON、Markdown 表格
- ✅ 自动处理 API 请求和数据解析
- ✅ 无需配置 API Key，直接调用公开接口

## 使用方法

### 方式一：直接调用技能

```
使用 toutiao-hot-news 技能获取最新热门新闻
```

或

```
帮我获取今日头条热榜前 10 条新闻
```

### 方式二：运行脚本

在终端执行：

```bash
python scripts/fetch_toutiao_hot_news.py
```

### 方式三：指定输出格式

```
获取今日头条热榜，输出为 JSON 格式
```

或

```
获取今日头条热榜，用表格形式展示
```

## 输出示例

### 文本格式

```
【今日头条热榜 TOP10】更新时间：2026-04-03 09:50

1. [社会] 新闻标题内容... 🔥 热度：1234567
   链接：https://www.toutiao.com/trending/xxxxx/
   
2. [国际] 新闻标题内容... 🔥 热度：987654
   链接：https://www.toutiao.com/trending/xxxxx/
   
...
```

### Markdown 表格格式

| 排名 | 分类 | 标题 | 热度值 | 链接 |
|------|------|------|--------|------|
| 1 | 社会 | 新闻标题... | 1234567 | [查看](链接) |
| 2 | 国际 | 新闻标题... | 987654 | [查看](链接) |

### JSON 格式

```json
{
  "update_time": "2026-04-03 09:50:10",
  "total_count": 10,
  "news_list": [
    {
      "rank": 1,
      "title": "新闻标题",
      "category": "社会",
      "hot_value": 1234567,
      "url": "https://www.toutiao.com/trending/xxxxx/"
    }
  ]
}
```

## 技术实现

### API 接口

- **接口地址**: `https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc`
- **请求方式**: GET
- **返回格式**: JSON
- **数据字段**:
  - `Title`: 新闻标题
  - `HotValue`: 热度值
  - `Category`: 新闻分类
  - `Label`: 新闻标签
  - `Url`: 新闻链接（需提取 ID 后拼接）

### 核心代码逻辑

1. 发送 HTTP GET 请求到今日头条热榜 API
2. 解析返回的 JSON 数据
3. 提取前 10 条新闻的关键字段
4. 使用正则表达式处理 URL（去除冗余参数）
5. 格式化输出结果

### 依赖安装

```bash
pip install requests
```

或使用项目已有的虚拟环境：

```bash
.venv\Scripts\activate
pip install requests
```

## 注意事项

1. **网络要求**: 需要能够访问今日头条官网
2. **更新频率**: 热榜数据约 5-10 分钟更新一次
3. **反爬策略**: 已内置 User-Agent 请求头，避免频繁请求（建议间隔>=1 分钟）
4. **数据时效性**: 获取的是实时热榜，每次调用结果可能不同
5. **版权说明**: 仅用于个人学习和数据分析，请勿用于商业用途

## 常见问题

**Q: 为什么有时获取不到数据？**
A: 检查网络连接，确保能访问 toutiao.com。如仍失败，可能是接口临时调整。

**Q: 能否获取更多条新闻？**
A: 可以。修改脚本中的 `limit = 10` 参数即可（最大支持 50 条）。

**Q: 如何定时自动获取？**
A: 可配合系统定时任务（Windows 任务计划程序 / Linux cron）定期执行脚本。

**Q: 能否按分类筛选？**
A: 当前版本获取全部分类热榜。如需筛选，可在获取后根据 `category` 字段过滤。

## 相关文件

- `scripts/fetch_toutiao_hot_news.py` - 主脚本文件
- `scripts/__init__.py` - Python 包初始化文件

## 更新日志

### v1.0 (2026-04-03)
- ✨ 初始版本发布
- ✅ 支持获取热榜前 10 条新闻
- ✅ 支持文本、表格、JSON 三种输出格式
- ✅ 内置请求头防反爬
- ✅ 完整的错误处理和异常捕获

## 作者信息

- **Author**: 魏星
- **Organization**: 我的 AI 团队
- **License**: Apache-2.0

---

*本技能仅供学习交流使用，请遵守相关法律法规和网站 robots.txt 协议。*
