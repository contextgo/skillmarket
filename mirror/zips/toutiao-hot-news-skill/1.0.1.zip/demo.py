#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
今日头条热门新闻技能 - 使用示例演示
展示三种不同的输出格式
"""

from scripts.fetch_toutiao_hot_news import ToutiaoHotNewsFetcher

def main():
    print("=" * 70)
    print("今日头条热门新闻技能 - 使用示例")
    print("=" * 70)
    print()
    
    # 创建抓取器实例
    fetcher = ToutiaoHotNewsFetcher(limit=10)
    
    # 获取新闻列表
    print("📰 正在获取今日头条热榜数据...\n")
    news_list = fetcher.fetch_hot_news()
    
    if not news_list:
        print("❌ 获取新闻失败，请检查网络连接")
        return
    
    # ========== 格式一：文本格式 ==========
    print("\n" + "=" * 70)
    print("【格式一：文本格式】")
    print("=" * 70)
    print(fetcher.format_text(news_list))
    
    # ========== 格式二：Markdown 表格 ==========
    print("\n" + "=" * 70)
    print("【格式二：Markdown 表格】")
    print("=" * 70)
    print()
    print(fetcher.format_markdown_table(news_list))
    
    # ========== 格式三：JSON 格式 ==========
    print("\n\n" + "=" * 70)
    print("【格式三：JSON 格式（前 3 条）】")
    print("=" * 70)
    print()
    
    # 只展示前 3 条的 JSON
    sample_news = news_list[:3]
    json_output = fetcher.format_json(sample_news)
    print(json_output)
    
    # ========== 保存到文件示例 ==========
    print("\n\n" + "=" * 70)
    print("【保存文件示例】")
    print("=" * 70)
    print()
    
    fetcher.save_to_file(news_list, 'toutiao_hot_news_text.txt', format_type='text')
    fetcher.save_to_file(news_list, 'toutiao_hot_news_table.md', format_type='markdown')
    fetcher.save_to_file(news_list, 'toutiao_hot_news.json', format_type='json')
    
    print("\n✅ 演示完成！已生成以下文件：")
    print("   - toutiao_hot_news_text.txt (文本格式)")
    print("   - toutiao_hot_news_table.md (Markdown 表格)")
    print("   - toutiao_hot_news.json (JSON 格式)")


if __name__ == '__main__':
    main()
