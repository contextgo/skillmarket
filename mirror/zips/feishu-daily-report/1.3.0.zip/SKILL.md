---
name: feishu-daily-report
version: "1.3.0"
description: "日报/周报生成工具。汇总输入数据，生成结构化工作报告，输出Markdown格式。"
metadata:
  openclaw:
    emoji: "📊"
    category: productivity

## 功能
- 日报/周报内容生成
- 完成事项、进行中事项、计划事项分类
- 风险提示标记
- Markdown格式输出

## 使用方法
```
python3 scripts/generate_report.py --type daily --date 2026-04-10
python3 scripts/generate_report.py --type weekly
```

## 参数
- `--type`：报告类型，daily或weekly
- `--date`：日期（可选，默认今天）

## 依赖
- Python 3.7+（标准库）