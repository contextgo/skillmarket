---
name: gpt-image2-zh
description: "通过虾聊（ClawdChat）工具网关调用 GPT Image 2（OpenAI gpt-image-2）生成高质量图片。当用户要求创建 / 生成 / 绘制图片，或提到 GPT 画图、gpt-image-2、OpenAI 生图，或需要精确文字渲染（海报 / 信息图 / 菜单字）、多元素严格指令跟随、图生图保人保物，或使用吉卜力 / Pixar / 乐高 / 赛博朋克 / 粘土 / 盲盒 等具体风格时使用。"
homepage: https://clawdchat.cn
metadata:
  emoji: "🖼️"
  category: creative
  version: "0.6.0"
  language: zh-CN
  publisher: clawdchat
  requires:
    primary_credential:
      type: clawdchat_api_key
      managed_by: bundled bin/uno.py
      stored_at: ~/.uno/credentials.json
      obtained_via: "运行 `python bin/uno.py login --start` 获得 device code，在浏览器打开终端输出的授权链接（未登录时页面自动跳虾聊 SSO 登录，登录后回到授权页点「授权」），再运行 `python bin/uno.py login --poll DEVICE_CODE` 落盘 API key。"
      scope: "作为 Authorization Bearer token 调用虾聊工具网关。凭证存取由内置 bin/uno.py 全权管理；本 skill 不直接读取 / 打印 / 上传凭证文件。"
    config_paths:
      - ~/.uno/credentials.json（只读，由 bin/uno.py 管理）
    network_endpoints:
      - "虾聊（ClawdChat）工具网关，HTTPS — 接收 prompt 与 reference_image_urls"
    write_actions:
      - "提交付费生图任务（每次 submit 扣 300 credits）"
      - "不写本地文件；返回的图片 URL 由 agent 自行决定是否下载"
    cost:
      gpt_image2_submit: "300 credits / 次"
      gpt_image2_result: "0 credits / 次"
  openclaw:
    requires:
      scripts: ["bin/uno.py"]
---

# GPT Image 2 — 高质量 AI 生图

> 由虾聊（ClawdChat）官方提供 — 通过 Uno 工具网关调用 OpenAI `gpt-image-2`。

## 这个 skill 做什么

两个命令行调用，对接虾聊公共工具网关：

| 工具 slug | 用途 | 费用 |
|---|---|---|
| `gpt-image-2.gpt_image2_submit` | 提交生图任务，立即返回 `job_id`（异步） | **300 credits / 次** |
| `gpt-image-2.gpt_image2_result` | 查询任务状态、拿图片 URL | 0 credits |

内置的 `bin/uno.py` 负责认证、HTTP 传输和限流。**无需安装其他 skill**，装这一个即可直接使用。

## 凭证与权限声明（首次使用前请读完）

- **凭证类型**：虾聊 API key（Bearer token）。
- **存放位置**：`~/.uno/credentials.json`。由内置 `bin/uno.py` 全权管理，本 skill 不读取 / 不打印 / 不复制该文件。
- **如何获得**：运行 `python bin/uno.py login`（详见准备步骤）。内置脚本走虾聊 OAuth device-code 流程，授权完自动落盘。
- **授权范围**：以登录用户身份调用虾聊工具网关。每次 `gpt_image2_submit` 会从该账号扣 300 credits。
- **网络外发**：用户的 `prompt` 文本和 `reference_image_urls` 会通过 HTTPS 发送到虾聊网关。**请不要在 prompt 里粘贴私人、机密或可识别个人身份的内容，除非已确认能接受网关的数据处理策略**（详见 https://clawdchat.cn）。
- **登出 / 撤销**：运行 `python bin/uno.py logout`。

## 费用透明 & 确认规则

每次 `gpt_image2_submit` 都会消耗当前账号的真实积分。Agent **必须**：

1. 在第一次调用前向用户展示拟用的 prompt、size、style、张数。
2. 如果用户在本轮还未明确同意生图，**先征得用户确认**再调用。
3. 多张批量（`n > 1`）或重试，视为多次独立扣费事件，除非用户已批量授权，否则**逐次确认**。
4. 拿到 `error` 响应时，把错误原文展示给用户，不要静默重试。

`gpt_image2_result` 查询免费，只有 `submit` 扣费。

## 准备步骤

无外部依赖。`clawhub install gpt-image2-zh` 后目录结构：

```text
gpt-image2-zh/
├── SKILL.md
└── bin/
    └── uno.py    # 内置 CLI，无需额外安装
```

以下命令均在 `gpt-image2-zh/` 目录内执行。

### 检查是否已登录

```bash
python bin/uno.py whoami --compact
```

- 返回用户信息（名字、邮箱、积分）→ 凭证有效，**跳过登录**。
- 返回 `{"error": "Not logged in"}` → 需要登录，继续下一步。

### 登录

```bash
python bin/uno.py login --start
```

终端会输出 device code 和授权链接（形如 `https://clawdtools.uno/device?code=XXXX`）。

在浏览器打开该链接——未登录时页面自动跳虾聊 SSO 登录，登录后回到授权页，点「授权」即可。

然后 poll 完成：

```bash
python bin/uno.py login --poll DEVICE_CODE
```

或直接运行 `python bin/uno.py login`（阻塞式，自动轮询，等待授权完成）。

凭证写入 `~/.uno/credentials.json`，后续调用自动复用。

## 完整生图流程（异步）

GPT Image 2 单张 1024×1024 大约要 **150 秒**，超过默认 MCP 60s 超时，所以必须用 **submit → 循环 result** 模式。

### Step 1：提交

```bash
python bin/uno.py call gpt-image-2.gpt_image2_submit --compact \
  --args '{"prompt":"樱花树下的柴犬，午后阳光","size":"1024x1024","style":"ghibli_anime"}'
```

响应（已扁平化，无需 `content[0].text` 解包）：

```json
{"success": true, "data": {"status": "pending", "job_id": "0b84b8f0f0c8", "estimated_seconds": 150}, "meta": {"latency_ms": 120, "credits_used": 300}}
```

记下 `data.job_id`。

### Step 2：循环查询

```bash
python bin/uno.py call gpt-image-2.gpt_image2_result --compact --timeout 70 \
  --args '{"job_id":"0b84b8f0f0c8","wait_seconds":50}'
```

`wait_seconds=50` 让服务端帮你等 50 秒（卡在 60s MCP 超时内）；`--timeout 70` 是客户端余量。

反复调用直到 `data.status` 进入：

- `done` — 完成，URL 在 `data.items[].url`。
- `error` — 失败，`data.error` 给原因。
- `pending` / `running` — 立刻再调一次。**不要自己 sleep**，服务端已经帮你等了 50 秒。

通常 3–5 轮（150–250 秒）拿到结果。

### 标准 Python 循环

用 `subprocess.run` 参数列表传参，避免 prompt 含 shell 元字符时的注入风险：

```python
import json, subprocess, sys

UNO = "bin/uno.py"

def uno(args):
    r = subprocess.run(["python", UNO] + args, capture_output=True, text=True)
    return json.loads(r.stdout)

prompt = "梵高风格的星空"
resp = uno(["call", "gpt-image-2.gpt_image2_submit", "--compact",
            "--args", json.dumps({"prompt": prompt, "style": "oil_painting_vangogh"}, ensure_ascii=False)])
job_id = resp["data"]["job_id"]

for _ in range(6):
    r = uno(["call", "gpt-image-2.gpt_image2_result", "--compact", "--timeout", "70",
             "--args", json.dumps({"job_id": job_id, "wait_seconds": 50})])
    status = r["data"]["status"]
    if status == "done":
        print(json.dumps(r, ensure_ascii=False, indent=2))
        break
    if status == "error":
        print("Error:", r["data"].get("error"), file=sys.stderr)
        sys.exit(1)
```

## 参数说明

| 参数 | 说明 | 取值 |
|---|---|---|
| `prompt` | 图片描述（必填，中英文皆可） | 任意文字 |
| `size` | 图片尺寸 | `1024x1024`（默认）/ `1024x1536`（竖）/ `1536x1024`（横）/ `auto` |
| `n` | 生成数量 | 1–4（默认 1） |
| `style` | 风格 preset（见下表） | 20 个 key 之一 |
| `reference_image_urls` | 参考图 URL（图生图） | 字符串，多张逗号分隔 |

## 20 个内置风格 preset

| key | 风格说明 |
|---|---|
| `ghibli_anime` | 宫崎骏 / 吉卜力手绘动画 |
| `pixar_3d` | 皮克斯 / 迪士尼 3D 动画 |
| `claymation` | 粘土定格动画（Laika / Aardman） |
| `lego_brick` | 乐高 / LEGO 积木 |
| `popmart_figurine` | 盲盒 / Pop Mart 手办 |
| `isometric_game` | 等距视角游戏场景（2.5D） |
| `cinematic_photo` | 电影级写实摄影（35mm） |
| `polaroid_film` | 宝丽来胶片 |
| `watercolor_ink` | 水彩 / 东方水墨晕染 |
| `oil_painting_vangogh` | 梵高油画厚涂 |
| `cyberpunk_neon` | 赛博朋克霓虹夜景 |
| `vintage_infographic` | 复古信息图 / 数据海报 |
| `movie_poster` | 电影海报（大标题 + 剧照） |
| `flat_vector` | 扁平矢量插画 / 运营 banner |
| `pixel_8bit` | 像素艺术 8 / 16-bit |
| `papercraft_layered` | 层叠剪纸 / papercraft |
| `exploded_diagram` | 科普爆炸图 / 结构分解 |
| `dreamcore_liminal` | 梦核 / 阈限空间 |
| `knolling_flatlay` | 俯视 knolling / 开箱摆拍 |
| `botanical_engraving` | 博物铜版画 / 古籍插画 |

## 能力亮点

相较 Midjourney / Flux / SD：

- **文字渲染精准** — 海报标题、信息图、菜单字、表情包字，按 prompt 写进图里。
- **指令跟随强** — 多元素 prompt、顺序、空间关系都会严格贯彻。
- **图生图保人保物** — 参考图里的脸、品牌、角色跨图稳定保留。
- **风格泛化广** — 吉卜力 / Pixar / 粘土 / 乐高 / 盲盒 / 博物铜版画都能驾驭。

## Agent 工作流提示

- 提交后预估约 150 秒/张，提前告诉用户。
- result 已在服务端 sleep 50 秒，**不要自己再 sleep**。
- result 调用统一加 `--timeout 70`（50s 服务端 + 余量）。
- 用户用中文描述时直接传中文 prompt。
- 用户提供参考图 → 用 `reference_image_urls` 配合 `style`，做"换风格保人物"。
- 海报 / 信息图 / 菜单 → 充分利用 GPT 的文字渲染优势。
- `submit` 返回 `success=false` → 把 `error`/`hint` 字段直接展示给用户。
- 600 秒还在 running → 任务可能卡住，告诉用户后续可继续用同一 `job_id` 调 result。

## 响应格式

```json
{
  "success": true,
  "data": {"status": "...", "job_id": "...", "items": [{"url": "..."}]},
  "meta": {"latency_ms": 120, "credits_used": 300}
}
```

直接读 `data.status` / `data.job_id` / `data.items[].url`。

错误响应：

```json
{"success": false, "error": "...", "hint": "..."}
```
