# ironox-html-editor

为单文件 HTML 方案、调研报告注入可视化编辑器，让非技术用户在浏览器中直接修改文字、数字、图标、字体和颜色，无需编辑代码。

## 适用场景

- 单文件 HTML 方案页：需要替换客户名、调整内容、定制字体或颜色。
- 单文件 HTML 调研报告：需要反复翻阅、增删改、复用到不同场景。
- 不适用于工程产品类页面：包含 package.json、前后端框架、路由、状态管理或正在开发中的独立产品，不应注入。

## 技能包结构

```text
ironox-html-editor/
├── SKILL.md
├── README.md
├── PUBLISHING_GUIDE.md
├── assets/
│   └── editable-inject.js
└── examples/
    └── demo.html
```

## 使用方式

将 `assets/editable-inject.js` 复制到目标 HTML 文件同目录，然后在目标 HTML 的 `</body>` 前插入：

```html
<script src="editable-inject.js"></script>
</body>
```

打开 HTML 后：

- 进入编辑模式：`Cmd/Ctrl + E`，或点击右下角编辑按钮。
- 保存：`Cmd/Ctrl + S`。
- 确认退出：再次按 `Cmd/Ctrl + E`，或点击确认按钮。
- 取消：按 `Esc` 或点击取消。
- 导出定稿：使用导出功能下载无编辑器代码的纯净 HTML。

## 发布到 SkillHub

本包面向 SkillHub 控制台直接发布，可直接上传压缩包。

发布入口：

```text
https://skillhub.cn/dashboard/publish
```

发布类型建议选择：

```text
Agent
```

上传文件：

```text
ironox-html-editor-skillhub-agent.zip
```

详细步骤见 `PUBLISHING_GUIDE.md`。

## 核心能力

- 就地编辑文字：点击任意文字块直接改，基于 contenteditable。
- 查找替换：输入查找词和替换为，点「全局替换」批量改全文。
- 中英文字体分离：英文 / 中文两个下拉独立选；选中文字 = 局部套，未选中 + 点「应用到全文」= 改全局。
- 文字色（局部）：选中一段文字再拖色轮，实时预览；点别处或按 Esc 落定；非全局按钮。
- 撤销 / 重做：10 步快照栈，Cmd+Z / Cmd+Shift+Z。
- 重置样式：清除所有编辑器加的字体和颜色覆盖，恢复原始主题。
- 恢复初版：清 localStorage 草稿回到首次打开状态，不可逆，操作前建议先导出副本。
- 保存 / 离开提醒：改动存 localStorage，未保存关页会弹确认。
- 自动回填：下次打开按 data-edit 字段级 innerHTML 回填，不替换整个 body。
- 导出定稿：下载剥除编辑器代码的纯净 HTML，文件名带时间戳，原文件不动。

## 版本

当前稳定版：v2.4.4。
