# SkillHub 控制台直传发布指南

## 目标

将 `ironox-html-editor` 作为 Agent 技能发布到 SkillHub 控制台。

发布入口：

```text
https://skillhub.cn/dashboard/publish
```

## 上传包

使用本目录同级生成的压缩包：

```text
ironox-html-editor-skillhub-agent.zip
```

压缩包内包含：

```text
ironox-html-editor/
├── SKILL.md
├── README.md
├── PUBLISHING_GUIDE.md
├── assets/
│   └── editable-inject.js
└── examples/
    └── demo.html
```

## 发布页面填写建议

### 类型

选择：

```text
Agent
```

### 名称

```text
ironox-html-editor
```

### 标题 / 展示名

```text
HTML 可视化编辑器注入
```

### 简介

```text
为单文件 HTML 方案和调研报告注入可视化编辑器，让非技术用户在浏览器中直接修改文字、数字、图标、字体和颜色，无需编辑代码。
```

### 详细描述

可使用：

```text
为单文件 HTML 方案页、调研报告、客户汇报页注入零依赖的可视化编辑器。安装后按场景判断是否注入，将 assets/editable-inject.js 复制到目标 HTML 同目录，并在 </body> 前插入脚本引用即可。

核心能力：
- 就地改文字（contenteditable）
- 查找 + 全局替换（批量改客户名等）
- 中英文字体分离：选中=局部；未选中+应用到全文=全局
- 文字色：基于选区的局部上色，拖色轮实时预览
- 撤销/重做 10 步
- 重置样式（清编辑器覆盖）、恢复初版（清草稿回到首开状态）
- 自动保存到 localStorage，按 data-edit 字段级回填，不替换整个 body
- 导出定稿 HTML：剥除编辑器代码，文件名带时间戳，原文件不改

不适用于正在开发中的工程产品（含 package.json、前后端框架、路由、状态管理的独立应用）。
```

### 标签建议

```text
HTML
可视化编辑
方案页
调研报告
contenteditable
WorkBuddy
```

### 触发词建议

```text
改HTML
编辑HTML
HTML编辑器
可视化编辑
注入编辑器
editable-inject
方案定制化
小修小补HTML
```

## 发布前自检

1. `SKILL.md` 存在，并包含 `name`、`description`。
2. `assets/editable-inject.js` 存在且非空。
3. README 只保留控制台直传说明，避免其他发布方式干扰。
4. demo.html 可作为示例页面，不依赖外部服务。
5. zip 内不要包含 `.DS_Store`、临时文件、node_modules 或 dist。

## 发布后验证

发布完成后，搜索以下关键词验证是否可检索：

```text
ironox-html-editor
HTML 可视化编辑器
改HTML
editable-inject
方案定制化
```

安装后用一句话测试触发：

```text
给这个单文件 HTML 方案页注入可视化编辑器，让我能在浏览器里改文字和颜色。
```
