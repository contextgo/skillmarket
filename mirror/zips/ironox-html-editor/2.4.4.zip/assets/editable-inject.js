/**
 * 方案 HTML 可视化编辑器 · Editable Inject
 * @author Karma for 强哥
 * @date 2026-04-27
 * @version 2.4.3
 *
 * v2.4.3 修复（2026-04-27 凌晨）：
 *   - 🐛 bug ③「下拉卡值」：<select> 当前 value 等于新选 value 时不触发 change
 *     场景：第一次选"楷体" → 下拉卡在"楷体" → 换一段文字再想选"楷体" → 点不动
 *     修复：局部套字体场景下，change 处理完立即 `el.selectedIndex = 0` 归零
 *     （全局场景 —— 即无选区 —— 保留下拉值等"应用到全文"按钮，不归零）
 *
 *   - 🐛 bug ④「嵌套字体破坏前序操作」：选 5 字套楷体 → 再在里面选 3 字套宋体
 *     → 不但 3 字没变，外层 5 字楷体也丢了
 *     根因：用户点别处"以为 commit 了"，实际 mousedown 落到了预览 span 内部被 early return，
 *     前次预览仍挂在 __fontPreviewSpans 上；第二次选 change → 走 unwrap 分支 → 外层 span 被整体拆除
 *     修复：onFontDropdownChange 里**先检查当前选区是否完全在某个现存预览 span 内部**，
 *     如果是 → 主动 commitFontPreview() 让前一次预览落定，再走"第一次框选"分支嵌套包新 span
 *
 * v2.4.2 修复（2026-04-26）：
 *   - 🐛 bug #10 局部字体"一点感觉都没有"的真因：
 *     原生 <select> / <input color> 的 mousedown 会把 document.activeElement 切走，
 *     同时清空 window.getSelection() 的 Range；change/input 触发时选区已空。
 *     onFontDropdownChange 里 `if (!hasSelection) return` 直接静默返回，
 *     局部 wrapTextNodesWithStyle 从未执行（DevTools 搜 data-font-preview 是 0/0）。
 *   - 修复：mousedown 阶段 saveSelectionFromDocument → change/input 时 restoreSavedRange
 *     同步修了颜色选择器的同类问题
 *
 * v2.4.1 修复（2026-04-26）：
 *   - 🐛 bug #4/#5 合并 font-family 错误：原合并 `Inter, sans-serif, SimSun, serif` 里的
 *     `sans-serif` 会提前终结 fallback，中文字符永远命不中 SimSun。
 *     修复：extractNamedFamilies + mergeFontValues 去重去 generic，最后只补一个兜底
 *   - 🐛 bug #6 Cmd+Z 首次撤销失效：undoStack 空时 push 一次 == 栈长只有 1 → undo 被 `<=1` 拒绝
 *     修复：pushUndoSnapshot 如果栈空，先补一个栈底初始快照
 *   - 🐛 bug #9 刷新后字体下拉没回填：saveThemeState 被 applyFontFamilyGlobal 早触发，
 *     而 dataset.themeLatinFont/themeCjkFont 在其之后才写，localStorage 里永远是空
 *     修复：applyGlobalFontsByPair 改为先写 dataset 再调 applyFontFamilyGlobal
 *
 * v2.4.0 更新（2026-04-26）：
 *   - 🆕 中英文字体**全局分离**：英文下拉 + 中文下拉，各管各
 *     英文下拉只显示 coverage=latin/both 的字体（Inter/Poppins/TencentSans/苹方…）
 *     中文下拉只显示 coverage=cjk/both 的字体（宋体/楷体/TencentSans/苹方…）
 *     both 字体（TencentSans/苹方/思源/Noto Sans）在两个下拉都出现，用户在任一边选即可
 *   - 🔧 应用到全文：合并 font-family: 英文value, 中文value, sans-serif
 *     浏览器**逐字符回退**：英文字符命中英文字体，中文字符回退到中文字体
 *     选 both 字体（如 TencentSans）后只需在任一下拉选一次，该字体本身已覆盖中英
 *   - 🔧 撤销快照扩容：themeLatinFont / themeCjkFont 两个 dataset 字段，回退时自动恢复下拉选中状态
 *   - 🔧 saveThemeState / 页面刷新恢复 / 重置样式 / applyFullSnapshot 全部适配双下拉
 *   - 📋 **暂不做（待开发）**：both 字体选一次自动联动另一边的智能联动，逻辑复杂易踩坑先不做
 *       用户选 both 字体需要**手动**两个下拉都选一次（操作多一步，但结果可控）
 *   - 🗑 删除 v2.3.4 的单下拉 __font_all__
 *
 * v2.3.4 更新（2026-04-26）：
 *   - 🆕 字体下拉合并成一个！按\"本机字体 / 云字体\" optgroup 分组
 *     本机优先（分享给对方电脑装了才看得见原味），云字体兜底（跨平台稳定）
 *   - 🐛 撤销彻底重写：applyFullSnapshot 改为整体 body.innerHTML 替换
 *     之前按 [data-edit] key / tag+class 签名字段级恢复，遇 wrapper span 结构就对不上
 *     现在 captureCleanBody 和 applyFullSnapshot 成为**完全可逆**的一对
 *   - 🆕 快照扩为对象 { body, fontCSS, colorCSS, themeFont, themeTextColor }
 *     撤销时全局字体/颜色 override 也会一并回退（之前只恢复 body）
 *   - 🔧 applyFullSnapshot 自动重挂 editor UI（toolbar/fab/toast）和 contenteditable
 *   - 🗑 删除 mergeFontStack / EN_FONTS / 双下拉相关代码（已无调用）
 * v2.3.3 更新（2026-04-26）：
 *   - 🔧 字体顺序改回"本机优先 → 系统 fallback → CDN 兜底 → serif"，不再用 CDN 强制覆盖本机字体
 *     （本机装了隶书/华文行楷就用本机原味；没装才走 Google Fonts 兜底）
 *   - 🆕 新增 5 款 CDN 独立字体（ZCOOL黄油/Ma Shan Zheng/Long Cang/Zhi Mang Xing/ZCOOL XiaoWei）
 *     想要跨平台稳定效果的直接选这几款，不走本机字体
 *   - 🐛 修复撤销/重做对"没有 data-edit key 的元素"（kicker/lead/hero/section-title 等）不生效
 *     applyFullSnapshot 新增阶段 2：用 tag+class+父路径 签名按文档顺序对齐恢复
 *   - 🔧 扩大 EDITABLE_SELECTORS：kicker/lead/hero/section-title/subtitle/caption/blockquote 等常见 class
 *   - 🔧 扩大 wrapOrphanText 容器：cover-meta/meta/info 等 div 里的 orphan text 也包 span 可编辑
 *     （解决 div 里 "示范项目" 这种 text node 选不中 → 局部字体用不了的问题）
 * v2.3.2 更新（2026-04-26）：
 *   - 🐛 修复隶书/华文行楷/华文楷体等系统字体不稳定（全部加 CDN 字体前置，Google Fonts 兜底）
 *   - 🐛 修复「恢复初版」后被踢出编辑模式（sessionStorage 标记 reload 后自动重进）
 *   - 🐛 修复撤销/重做循环自毁 redo 栈（undo 期间 markDirty 不再触发 scheduleUndoSnapshot）
 *   - 🔧 undo/redo 改用 applyFullSnapshot，恢复完整样式（含局部 span 的字体/颜色）
 *   - 🔧 undo 栈扩至 20 步
 * v2.3.1 更新（2026-04-26）：
 *   - 🐛 修复应用全文时工具栏字体也被改掉（selector 用 :not() 排除编辑器元素）
 *   - 🐛 修复应用全文无法覆盖局部已改字体（应用全文前先 clearAllFontSpans 清掉局部 span）
 * v2.3.0 更新（2026-04-26）：
 *   - 🐛 修复应用全文后局部改字体不生效（inline !important 覆盖 stylesheet !important）
 *   - 🐛 修复选中跨元素文字只应用到部分（改用逐 text node 包 span）
 *   - 🐛 修复恢复初版不生效（改用 reload 彻底恢复，不再只用 restoreTextOnly）
 * v2.0.0 更新（2026-04-26）：
 *   - 🔧 按钮拆分：💾 保存（留在编辑模式）/ ✅ 确认退出（保存+退出）/ 取消（丢弃）/ Esc=取消
 *   - ↩️ 撤销/重做（快照栈方案）：Cmd+Z 撤销 / Cmd+Shift+Z 重做
 *     - 防抖 500ms，连续打字合并成一个快照
 *     - 覆盖所有操作（文字、字体、颜色、全局替换）
 *   - Cmd+S = 保存（不退出）；Cmd+E = 确认退出
 * v1.9.1 更新（2026-04-26）：
 *   - 🐛 修复多页 PPT 同名 data-edit key 互相覆盖的 bug
 *   - restoreTextOnly 改为按 key + DOM 顺序索引匹配，同名 key 的第 N 个对应第 N 个
 *   - 原则：没有手段证明是同一个元素，就独立对待
 * v1.8 更新（2026-04-24）：
 *   - 🎯 中英文字体独立选择：两个下拉框（中文 22 款 / 英文 28 款）
 *   - 应用全文时自动合并字体栈：英文在前（命中英文字符）→ 中文在后（fallback 中文字符）
 *   - 中英分离的混排效果，不再用中文字体把英文字符强制套得很丑
 * v1.7 更新（2026-04-24）：
 *   - 字体库大扩充：50+ 款；每款带 fallback 链；Google Fonts 按需加载
 * v1.6 更新（2026-04-24）：
 *   - 保存 = 保存 + 自动退出；取消 = 丢弃变更
 *   - 修复预览交互丢失（不再暴力 clearInterval，只清 PPT 的 autoTimer）
 *   - 修复 restoreBody 破坏 slide 结构 → 改为字段级 restoreTextOnly
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'editable_snapshot_' + location.pathname;
  const ORIGINAL_KEY = 'editable_original_' + location.pathname;
  const THEME_KEY = 'editable_theme_' + location.pathname;
  const VERSIONS_KEY = 'editable_versions_' + location.pathname;
  const REENTER_KEY = '__editable_reenter_edit_mode__';

  // ========== 自定义确认弹窗 ==========
  // showConfirm(title, desc, confirmText, onSecondary, onConfirm, secondaryText)
  // onSecondary = null → 双按钮（取消+确认）; 有值 → 三按钮（取消+副按钮+主按钮）
  function showConfirm(title, desc, confirmText, onSecondary, onConfirm, secondaryText) {
    // 兼容旧调用：showConfirm(title, desc, confirmText, onConfirm)
    if (typeof onSecondary === 'function' && !onConfirm) {
      onConfirm = onSecondary;
      onSecondary = null;
    }
    const overlay = document.createElement('div');
    overlay.id = '__editor_confirm_overlay__';
    Object.assign(overlay.style, {
      all: 'initial',
      position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
      zIndex: '999999', background: 'rgba(0,0,0,.45)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      lineHeight: '1.5', boxSizing: 'border-box'
    });

    // 按钮公共 style——用 all:initial 重置后再逐一设置
    const btnBase = 'all:initial;display:inline-block;box-sizing:border-box;padding:10px 0;border-radius:8px;font-size:14px;cursor:pointer;font-family:inherit;line-height:1.5;text-align:center;transition:all .15s;';
    let buttonsHTML = '';
    if (onSecondary && secondaryText) {
      buttonsHTML = `
        <button id="__confirm_cancel__" style="${btnBase}flex:1;border:1px solid #ddd;background:#fff;color:#333;">取消</button>
        <button id="__confirm_secondary__" style="${btnBase}flex:1.2;border:none;background:#1976d2;color:#fff;font-weight:600;">${secondaryText}</button>
        <button id="__confirm_ok__" style="${btnBase}flex:1;border:none;background:#e53935;color:#fff;font-weight:600;">${confirmText}</button>`;
    } else {
      buttonsHTML = `
        <button id="__confirm_cancel__" style="${btnBase}flex:1;border:1px solid #ddd;background:#fff;color:#333;">取消</button>
        <button id="__confirm_ok__" style="${btnBase}flex:1;border:none;background:#e53935;color:#fff;font-weight:600;">${confirmText}</button>`;
    }

    overlay.innerHTML = `
      <div style="all:initial;display:block;box-sizing:border-box;background:#fff;border-radius:12px;padding:28px 32px;max-width:420px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,.18);text-align:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;line-height:1.5;">
        <div style="all:initial;display:block;font-size:16px;font-weight:600;color:#1a1a1a;margin-bottom:8px;font-family:inherit;line-height:1.5;text-align:center;">${title}</div>
        <div style="all:initial;display:block;font-size:13px;color:#666;line-height:1.6;margin-bottom:24px;font-family:inherit;text-align:center;">${desc}</div>
        <div style="all:initial;display:flex;gap:10px;justify-content:center;font-family:inherit;">${buttonsHTML}</div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#__confirm_cancel__').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#__confirm_ok__').addEventListener('click', () => { overlay.remove(); if (onConfirm) onConfirm(); });
    if (onSecondary) {
      const secBtn = overlay.querySelector('#__confirm_secondary__');
      if (secBtn) secBtn.addEventListener('click', () => { overlay.remove(); onSecondary(); });
    }
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  }

  // ========== 版本管理 ==========
  function getVersions() {
    try { return JSON.parse(localStorage.getItem(VERSIONS_KEY) || '[]'); } catch (_) { return []; }
  }
  function saveVersion(name) {
    const versions = getVersions();
    const body = localStorage.getItem(STORAGE_KEY) || captureCleanBody();
    const theme = localStorage.getItem(THEME_KEY) || '';
    versions.push({ name, body, theme, time: new Date().toLocaleString('zh-CN') });
    // 最多保留 10 个版本
    while (versions.length > 10) versions.shift();
    localStorage.setItem(VERSIONS_KEY, JSON.stringify(versions));
    return versions.length;
  }

  // ========== 字体表 · 合并版（v2.3.4）==========
  // 一个下拉搞定：每项字体栈内部已经处理好中英文混排（英文在前命中英字符、中文在后 fallback）
  // 分组：① 本机字体（依赖本机安装，分享出去对方装了才有效）② 云字体（Google Fonts CDN，全平台稳定）
  // value: 常规权重字体栈； valueBold: 粗体字体栈（可选，标题/strong 用）

  // coverage 字段说明（v2.4）：
  //   'latin' = 只覆盖英文/拉丁字符（Inter/Poppins/Playfair 等）→ 只进英文下拉
  //   'cjk'   = 只覆盖中文字符（宋体/楷体/ZCOOL XiaoWei 等）→ 只进中文下拉
  //   'both'  = 中英都覆盖（TencentSans/苹方/思源/YaHei）→ 两个下拉都进，用户在任一边选就行
  const FONTS = [
    // ============ 本机字体（本机装了才能看到原味，分享需对方也装）============
    { group: '本机 · 黑体', name: 'TencentSans W3（腾讯常规）', coverage: 'both', value: '"TencentSans W3", "PingFang SC", "Microsoft YaHei", sans-serif' },
    { group: '本机 · 黑体', name: 'TencentSans W7（腾讯粗体）', coverage: 'both', value: '"TencentSans W7", "PingFang SC Semibold", "Microsoft YaHei Bold", sans-serif' },
    { group: '本机 · 黑体', name: '苹方 PingFang SC（苹果系统）', coverage: 'both', value: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif', valueBold: '-apple-system, BlinkMacSystemFont, "PingFang SC Semibold", "Microsoft YaHei Bold", sans-serif' },
    { group: '本机 · 黑体', name: '微软雅黑 YaHei（Windows）', coverage: 'both', value: '"Microsoft YaHei", "PingFang SC", sans-serif', valueBold: '"Microsoft YaHei Bold", "PingFang SC", sans-serif' },
    { group: '本机 · 黑体', name: '思源黑体 Source Han Sans', coverage: 'both', value: '"Source Han Sans SC", "PingFang SC", sans-serif', valueBold: '"Source Han Sans SC Bold", "PingFang SC", sans-serif' },
    { group: '本机 · 黑体', name: 'HarmonyOS Sans（鸿蒙）', coverage: 'both', value: '"HarmonyOS Sans", "HarmonyOS Sans SC", "PingFang SC", sans-serif', valueBold: '"HarmonyOS Sans", "HarmonyOS Sans SC Bold", "PingFang SC", sans-serif' },
    { group: '本机 · 黑体', name: '阿里巴巴普惠体', coverage: 'both', value: '"Alibaba PuHuiTi", "PingFang SC", sans-serif', valueBold: '"Alibaba PuHuiTi Bold", "PingFang SC", sans-serif' },
    { group: '本机 · 黑体', name: 'OPPO Sans', coverage: 'both', value: '"OPPO Sans", "PingFang SC", sans-serif' },

    { group: '本机 · 宋体', name: '宋体 SimSun', coverage: 'cjk', value: 'SimSun, "Songti SC", serif' },
    { group: '本机 · 宋体', name: '华文宋体 STSong', coverage: 'cjk', value: 'STSong, "Songti SC", serif' },
    { group: '本机 · 宋体', name: '思源宋体 Source Han Serif', coverage: 'both', value: '"Source Han Serif SC", "Songti SC", serif', valueBold: '"Source Han Serif SC Bold", "Songti SC", serif' },

    { group: '本机 · 楷/仿宋', name: '楷体 KaiTi', coverage: 'cjk', value: 'KaiTi, "Kaiti SC", STKaiti, serif' },
    { group: '本机 · 楷/仿宋', name: '华文楷体 STKaiti', coverage: 'cjk', value: 'STKaiti, "Kaiti SC", KaiTi, serif' },
    { group: '本机 · 楷/仿宋', name: '仿宋 FangSong', coverage: 'cjk', value: 'FangSong, "FangSong SC", STFangsong, serif' },

    { group: '本机 · 特色', name: '隶书 LiSu', coverage: 'cjk', value: 'LiSu, "Baoli SC", STLiti, serif' },
    { group: '本机 · 特色', name: '华文行楷 STXingkai', coverage: 'cjk', value: 'STXingkai, "Hannotate SC", cursive' },
    { group: '本机 · 特色', name: '华文琥珀 STHupo', coverage: 'cjk', value: 'STHupo, cursive' },
    { group: '本机 · 特色', name: '华文彩云 STCaiyun', coverage: 'cjk', value: 'STCaiyun, cursive' },

    // ============ 云字体（Google Fonts CDN，全平台稳定一致）============

    // 英文 · 无衬线（latin）
    { group: '云字体 · 英文无衬线', name: 'Inter（现代 UI）', coverage: 'latin', value: 'Inter, sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Poppins（几何）', coverage: 'latin', value: 'Poppins, sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Montserrat（标题）', coverage: 'latin', value: 'Montserrat, sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'DM Sans（简洁）', coverage: 'latin', value: '"DM Sans", sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Space Grotesk（科技）', coverage: 'latin', value: '"Space Grotesk", sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Plus Jakarta Sans（UI 友好）', coverage: 'latin', value: '"Plus Jakarta Sans", sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Manrope（圆润）', coverage: 'latin', value: 'Manrope, sans-serif' },
    { group: '云字体 · 英文无衬线', name: 'Work Sans（正文）', coverage: 'latin', value: '"Work Sans", sans-serif' },

    // 英文 · 衬线（latin）
    { group: '云字体 · 英文衬线', name: 'Playfair Display（杂志标题）', coverage: 'latin', value: '"Playfair Display", serif' },
    { group: '云字体 · 英文衬线', name: 'Lora（书本正文）', coverage: 'latin', value: 'Lora, serif' },
    { group: '云字体 · 英文衬线', name: 'IBM Plex Serif（现代衬线）', coverage: 'latin', value: '"IBM Plex Serif", serif' },

    // 中英同栈（both）· 思源系
    { group: '云字体 · 中英同栈', name: 'Noto Sans SC（谷歌思源 · 跨平台）', coverage: 'both', value: '"Noto Sans SC", "PingFang SC", sans-serif' },
    { group: '云字体 · 中英同栈', name: 'Noto Serif SC（谷歌思源宋）', coverage: 'both', value: '"Noto Serif SC", "Songti SC", serif' },

    // 中文装饰（cjk）
    { group: '云字体 · 中文装饰', name: 'ZCOOL XiaoWei（站酷小薇 · 文艺宋）', coverage: 'cjk', value: '"ZCOOL XiaoWei", "Songti SC", serif' },
    { group: '云字体 · 中文装饰', name: 'ZCOOL QingKe HuangYou（站酷黄油 · 粗黑）', coverage: 'cjk', value: '"ZCOOL QingKe HuangYou", "PingFang SC", sans-serif' },
    { group: '云字体 · 中文装饰', name: 'ZCOOL KuaiLe（站酷快乐 · 圆润）', coverage: 'cjk', value: '"ZCOOL KuaiLe", "PingFang SC", sans-serif' },
    { group: '云字体 · 中文装饰', name: 'Ma Shan Zheng（马善政 · 毛笔楷）', coverage: 'cjk', value: '"Ma Shan Zheng", STKaiti, cursive' },
    { group: '云字体 · 中文装饰', name: 'Long Cang（龙藏 · 行楷）', coverage: 'cjk', value: '"Long Cang", STXingkai, cursive' },
    { group: '云字体 · 中文装饰', name: 'Liu Jian Mao Cao（刘建毛草 · 草书）', coverage: 'cjk', value: '"Liu Jian Mao Cao", STXingkai, cursive' },
    { group: '云字体 · 中文装饰', name: 'Zhi Mang Xing（志莽 · 行书）', coverage: 'cjk', value: '"Zhi Mang Xing", STKaiti, cursive' },

    // 代码（latin）
    { group: '云字体 · 代码', name: 'JetBrains Mono（代码）', coverage: 'latin', value: '"JetBrains Mono", "SF Mono", Menlo, monospace' },
    { group: '云字体 · 代码', name: 'Fira Code（代码 · 连字）', coverage: 'latin', value: '"Fira Code", "SF Mono", Menlo, monospace' },
    { group: '云字体 · 代码', name: 'IBM Plex Mono（代码）', coverage: 'latin', value: '"IBM Plex Mono", "SF Mono", monospace' },
  ];


  /** 按 group 分组构建 optgroup HTML
   *  v2.4 新增 coverageFilter: 'latin' | 'cjk' | null
   *    'latin' → 只保留 coverage='latin' 或 'both' 的字体（给英文下拉）
   *    'cjk'   → 只保留 coverage='cjk'   或 'both' 的字体（给中文下拉）
   *    null    → 不过滤（兼容老代码）
   */
  function buildFontSelectOptions(fonts, placeholder, coverageFilter) {
    const filtered = !coverageFilter ? fonts : fonts.filter((f) => {
      const cov = f.coverage || 'both';
      if (coverageFilter === 'latin') return cov === 'latin' || cov === 'both';
      if (coverageFilter === 'cjk')   return cov === 'cjk'   || cov === 'both';
      return true;
    });
    const grouped = {};
    filtered.forEach((f) => {
      if (!grouped[f.group]) grouped[f.group] = [];
      grouped[f.group].push(f);
    });
    let html = `<option value="">${placeholder}</option>`;
    Object.keys(grouped).forEach((g) => {
      html += `<optgroup label="── ${g} ──">`;
      grouped[g].forEach((f) => {
        const bold = (f.valueBold || '').replace(/"/g, '&quot;');
        const val  = f.value.replace(/"/g, '&quot;');
        html += `<option value="${val}" data-bold="${bold}" data-name="${f.name.replace(/"/g, '&quot;')}" data-coverage="${f.coverage || 'both'}">${f.name}</option>`;
      });
      html += '</optgroup>';
    });
    return html;
  }

  const NO_EDIT_CLASSES = ['.chk', '.dot', '.bullet', '.separator', '.line'];

  // ========== 状态管理 ==========
  let dirty = false;
  let isEditMode = false;

  let pptKeydownHandler = null;
  let pptTouchStartHandler = null;
  let pptTouchEndHandler = null;

  function markDirty() { dirty = true; updateSaveStatus('modified'); scheduleUndoSnapshot(); }
  function markSaved() { dirty = false; updateSaveStatus('saved'); }

  function updateSaveStatus(state) {
    const el = document.getElementById('__save_status__');
    if (!el) return;
    const map = {
      saved:    { icon: '✅', text: '已保存', cls: '' },
      modified: { icon: '🔴', text: '未保存', cls: 'unsaved' },
      saving:   { icon: '⏳', text: '保存中…', cls: '' },
    };
    const s = map[state] || map.saved;
    el.innerHTML = `${s.icon} ${s.text}`;
    el.className = 'save-status ' + s.cls;
  }

  // ========== 撤销/重做 · 快照栈 ==========
  // 策略：每次操作后 push 当前 DOM 快照（captureCleanBody 的 innerHTML）
  // 连续打字 500ms 内合并成一个快照（防抖）
  // 覆盖所有操作：文字输入、字体、颜色、全局替换
  const UNDO_STACK_LIMIT = 20;    // 最多保留 20 步
  let undoStack = [];              // 快照栈（从旧到新）
  let redoStack = [];              // 重做栈
  let undoDebounceTimer = null;    // 防抖计时器
  let undoInitialized = false;     // 是否已 push 初始快照
  let isUndoRedoing = false;       // 🔑 关键：撤销/重做过程中不再记录新快照，避免循环自毁 redo 栈

  /** 捕获完整状态快照（body + 全局字体/颜色 override + themeFont dataset） */
  function captureFullSnapshot() {
    const fontStyle = document.getElementById('__font_global_override__');
    const colorStyle = document.getElementById('__text_color_override__');
    return {
      body: captureCleanBody(),
      fontCSS: fontStyle ? fontStyle.textContent : '',
      colorCSS: colorStyle ? colorStyle.textContent : '',
      themeFont: document.body.dataset.themeFont || '',
      themeFontBold: document.body.dataset.themeFontBold || '',
      themeLatinFont: document.body.dataset.themeLatinFont || '',  // v2.4 新：英文下拉选中字体 name
      themeCjkFont: document.body.dataset.themeCjkFont || '',      // v2.4 新：中文下拉选中字体 name
      themeTextColor: document.body.dataset.themeTextColor || ''
    };
  }

  /** 比较两个快照是否完全一致（避免重复 push） */
  function snapshotEquals(a, b) {
    if (!a || !b) return false;
    return a.body === b.body && a.fontCSS === b.fontCSS && a.colorCSS === b.colorCSS;
  }

  /** 推入一个 undo 快照
   *  v2.4.1 修复：如果是第一次 push 且栈空 → 先补一个"当前状态"作为栈底，
   *  再 push 当前状态做"操作前" —— 否则 undo() 里的 `<=1` 判断会拒绝首次撤销
   */
  function pushUndoSnapshot() {
    // 撤销/重做过程中触发的 markDirty 不能再 push 快照
    if (isUndoRedoing) return;
    const snap = captureFullSnapshot();
    // 首次 push：栈必须先有一个初始快照做栈底，不然 undo 拒绝
    if (undoStack.length === 0) {
      undoInitialized = true;
      undoStack.push(snap);
    }
    // 跳过与栈顶完全相同的快照（避免无效重复）
    if (undoStack.length > 0 && snapshotEquals(undoStack[undoStack.length - 1], snap)) return;
    undoStack.push(snap);
    if (undoStack.length > UNDO_STACK_LIMIT) undoStack.shift();
    // 有新操作就清空 redo
    redoStack = [];
    updateUndoRedoButtons();
  }

  /** 防抖推入快照（连续打字 500ms 合并） */
  function scheduleUndoSnapshot() {
    // 撤销/重做过程中不调度新快照
    if (isUndoRedoing) return;
    // 首次编辑前先保存初始状态
    if (!undoInitialized) {
      undoInitialized = true;
      const stored = localStorage.getItem(STORAGE_KEY);
      const initialSnap = {
        body: stored || captureCleanBody(),
        fontCSS: '',
        colorCSS: '',
        themeFont: '',
        themeFontBold: '',
        themeTextColor: ''
      };
      undoStack.push(initialSnap);
    }
    clearTimeout(undoDebounceTimer);
    undoDebounceTimer = setTimeout(() => { pushUndoSnapshot(); }, 500);
  }

  /**
   * 恢复一个完整快照（v2.3.4 全新实现：整体 body 替换 + 恢复全局样式）
   *
   * 参数 snapshot：
   *   - 对象形式 { body, fontCSS, colorCSS, themeFont, themeFontBold, themeTextColor } → 完整恢复
   *   - 字符串形式（老格式兼容）→ 只恢复 body 内容，清空全局样式
   *
   * 关键原则：captureCleanBody/captureFullSnapshot 剥离什么 → applyFullSnapshot 就重建什么
   *
   * 步骤：
   *   1. 保存工具栏/FAB/Toast 节点引用（editor UI，不能丢）
   *   2. 用快照整体替换 body.innerHTML（干净状态）
   *   3. 把 editor UI 放回 body 末尾
   *   4. 恢复全局字体/颜色 <style> 标签到快照状态
   *   5. 恢复 body.dataset.themeFont/themeTextColor
   *   6. 如果当前在编辑模式：重跑 wrapOrphanText + markEditable + markNoEdit
   */
  function applyFullSnapshot(snapshot) {
    if (!snapshot) return;

    // 兼容旧字符串格式
    const snap = typeof snapshot === 'string'
      ? { body: snapshot, fontCSS: '', colorCSS: '', themeFont: '', themeFontBold: '', themeLatinFont: '', themeCjkFont: '', themeTextColor: '' }
      : snapshot;

    if (!snap.body) return;

    // 1) 取出 editor UI 节点
    const toolbar = document.getElementById('__edit_toolbar__');
    const fab = document.getElementById('__edit_fab__');
    const toast = document.getElementById('__edit_toast__');

    // 2) 清空局部预览 span 引用（旧 DOM 节点引用即将失效）
    __fontPreviewSpans = [];
    __colorPreviewSpans = [];

    // 3) 整体替换 body
    document.body.innerHTML = snap.body;

    // 4) 把 editor UI 放回 body 末尾
    if (toolbar) document.body.appendChild(toolbar);
    if (fab) document.body.appendChild(fab);
    if (toast) document.body.appendChild(toast);

    // 5) 恢复全局字体 override
    let fontStyle = document.getElementById('__font_global_override__');
    if (snap.fontCSS) {
      if (!fontStyle) {
        fontStyle = document.createElement('style');
        fontStyle.id = '__font_global_override__';
        document.head.appendChild(fontStyle);
      }
      fontStyle.textContent = snap.fontCSS;
    } else if (fontStyle) {
      fontStyle.remove();
    }

    // 6) 恢复全局文字颜色 override
    let colorStyle = document.getElementById('__text_color_override__');
    if (snap.colorCSS) {
      if (!colorStyle) {
        colorStyle = document.createElement('style');
        colorStyle.id = '__text_color_override__';
        document.head.appendChild(colorStyle);
      }
      colorStyle.textContent = snap.colorCSS;
    } else if (colorStyle) {
      colorStyle.remove();
    }

    // 7) 恢复 dataset 状态
    if (snap.themeFont) document.body.dataset.themeFont = snap.themeFont;
    else delete document.body.dataset.themeFont;
    if (snap.themeFontBold) document.body.dataset.themeFontBold = snap.themeFontBold;
    else delete document.body.dataset.themeFontBold;
    if (snap.themeLatinFont) document.body.dataset.themeLatinFont = snap.themeLatinFont;
    else delete document.body.dataset.themeLatinFont;
    if (snap.themeCjkFont) document.body.dataset.themeCjkFont = snap.themeCjkFont;
    else delete document.body.dataset.themeCjkFont;
    if (snap.themeTextColor) document.body.dataset.themeTextColor = snap.themeTextColor;
    else delete document.body.dataset.themeTextColor;

    // v2.4 新：恢复两个字体下拉的选中项（按 name 匹配 option.dataset.name）
    //   如果 snap 是老格式（没 themeLatinFont/themeCjkFont），两个下拉都归零
    const restoreSelectByName = (selId, name) => {
      const sel = document.getElementById(selId);
      if (!sel) return;
      if (!name) { sel.selectedIndex = 0; return; }
      for (let i = 0; i < sel.options.length; i++) {
        if ((sel.options[i].dataset.name || '') === name) {
          sel.selectedIndex = i;
          return;
        }
      }
      sel.selectedIndex = 0; // 找不到就归零
    };
    restoreSelectByName('__font_latin__', snap.themeLatinFont);
    restoreSelectByName('__font_cjk__', snap.themeCjkFont);

    // 8) 如果当前在编辑模式，重新让元素可编辑
    if (isEditMode) {
      wrapOrphanText();
      markEditable();
      markNoEdit();
    }
  }

  /** 撤销 */
  function undo() {
    if (undoStack.length <= 1) { showToast('没有更多可撤销的操作', 1200); return; }
    // 先把任何挂起的防抖快照 flush 掉，避免 undo 之后它又 push
    clearTimeout(undoDebounceTimer);

    isUndoRedoing = true;
    try {
      // 当前状态入 redo
      const current = undoStack.pop();
      redoStack.push(current);
      // 恢复上一个状态
      const prev = undoStack[undoStack.length - 1];
      applyFullSnapshot(prev);
      updateUndoRedoButtons();
      // 直接标脏，不触发 scheduleUndoSnapshot
      dirty = true;
      updateSaveStatus('modified');
      showToast('↩️ 撤销', 800);
    } finally {
      // 下一 tick 再解锁，防止 input 事件冒泡触发新快照
      setTimeout(() => { isUndoRedoing = false; }, 50);
    }
  }

  /** 重做 */
  function redo() {
    if (redoStack.length === 0) { showToast('没有可重做的操作', 1200); return; }
    clearTimeout(undoDebounceTimer);

    isUndoRedoing = true;
    try {
      const next = redoStack.pop();
      undoStack.push(next);
      applyFullSnapshot(next);
      updateUndoRedoButtons();
      dirty = true;
      updateSaveStatus('modified');
      showToast('↪️ 重做', 800);
    } finally {
      setTimeout(() => { isUndoRedoing = false; }, 50);
    }
  }

  /** 更新按钮禁用状态 */
  function updateUndoRedoButtons() {
    const undoBtn = document.getElementById('__btn_undo__');
    const redoBtn = document.getElementById('__btn_redo__');
    if (undoBtn) {
      undoBtn.style.opacity = undoStack.length <= 1 ? '0.4' : '1';
      undoBtn.style.pointerEvents = undoStack.length <= 1 ? 'none' : 'auto';
    }
    if (redoBtn) {
      redoBtn.style.opacity = redoStack.length === 0 ? '0.4' : '1';
      redoBtn.style.pointerEvents = redoStack.length === 0 ? 'none' : 'auto';
    }
  }

  // ========== 1. 注入样式 ==========
  const style = document.createElement('style');
  style.id = '__editable_styles__';
  style.textContent = `
    html.__edit_mode__ body { cursor: default; }

    /* 文字元素：蓝色虚线 */
    html.__edit_mode__ [data-editable]:not([data-editable-icon]):hover {
      outline: 2px dashed #0052D9;
      outline-offset: 3px;
      box-shadow: inset 0 0 0 9999px rgba(0, 82, 217, 0.04);
      cursor: text !important;
      border-radius: 3px;
      transition: outline 0.15s;
    }
    html.__edit_mode__ [data-editable]:not([data-editable-icon]):focus {
      outline: 2px solid #0052D9 !important;
      outline-offset: 3px;
    }

    /* 图标元素：橙色虚线 + 角标 */
    html.__edit_mode__ [data-editable-icon]:hover {
      outline: 2px dashed #f59e0b;
      outline-offset: 3px;
      cursor: text !important;
      border-radius: 3px;
      transition: outline 0.15s;
      position: relative;
    }
    html.__edit_mode__ [data-editable-icon]:focus {
      outline: 2px solid #f59e0b !important;
      outline-offset: 3px;
    }
    html.__edit_mode__ [data-editable-icon]::after {
      content: "图标";
      position: absolute;
      top: -18px; left: 50%;
      transform: translateX(-50%);
      background: #f59e0b;
      color: #fff;
      font-size: 10px;
      padding: 1px 5px;
      border-radius: 3px;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s;
    }
    html.__edit_mode__ [data-editable-icon]:hover::after { opacity: 1; }

    /* 不可编辑装饰 */
    html.__edit_mode__ [data-no-edit]:hover {
      outline: 1px dotted #94a3b8;
      cursor: not-allowed !important;
    }

    /* 工具栏 */
    #__edit_toolbar__ {
      position: fixed; top: 0; left: 0; right: 0;
      z-index: 99999;
      background: #0f172a; color: #fff;
      padding: 0;
      display: none; flex-direction: column;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 13px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    html.__edit_mode__ #__edit_toolbar__ { display: flex; }
    html.__edit_mode__ body { padding-top: 96px !important; overflow: auto !important; height: auto !important; }

    /* 编辑模式：PPT 所有 slides 纵向平铺，全部可见可编辑 */
    html.__edit_mode__ .stage {
      position: static !important;
      width: 100% !important;
      height: auto !important;
      display: block !important;
      padding: 20px 0 !important;
    }
    html.__edit_mode__ .slide {
      position: relative !important;
      inset: auto !important;
      opacity: 1 !important;
      pointer-events: auto !important;
      width: 100% !important;
      height: auto !important;
      min-height: 720px !important;
      margin: 0 auto 24px !important;
      transition: none !important;
      display: flex !important;
    }
    /* 隐藏 PPT 原生导航 */
    html.__edit_mode__ #navDots,
    html.__edit_mode__ .nav-dots,
    html.__edit_mode__ .nav-arrow,
    html.__edit_mode__ .nav-left,
    html.__edit_mode__ .nav-right,
    html.__edit_mode__ #counter,
    html.__edit_mode__ .counter,
    html.__edit_mode__ .page-counter {
      display: none !important;
    }
    /* 每页左上角角标 */
    html.__edit_mode__ .slide::before {
      content: "P" counter(slide-num);
      counter-increment: slide-num;
      position: absolute;
      top: 8px; left: 16px;
      background: rgba(83,90,253,0.9);
      color: #fff;
      font-size: 11px;
      padding: 3px 8px;
      border-radius: 4px;
      z-index: 100;
      font-family: Inter, sans-serif;
      letter-spacing: 0.5px;
      pointer-events: none;
    }
    html.__edit_mode__ .stage { counter-reset: slide-num; }

    .tb-row { display: flex; align-items: center; gap: 8px; padding: 8px 16px; flex-wrap: wrap; }
    .tb-row.secondary { background: rgba(255,255,255,0.04); border-top: 1px solid rgba(255,255,255,0.08); }
    .tb-title { font-weight: 700; color: #60a5fa; display: flex; align-items: center; gap: 6px; }
    .tb-title::before { content: "✏️"; }
    .divider { width: 1px; height: 20px; background: rgba(255,255,255,0.2); flex-shrink: 0; }

    #__edit_toolbar__ button,
    #__edit_toolbar__ input,
    #__edit_toolbar__ select {
      background: rgba(255,255,255,0.1); color: #fff;
      border: 1px solid rgba(255,255,255,0.2);
      padding: 5px 10px; border-radius: 6px; font-size: 12px;
      cursor: pointer; transition: background 0.15s; font-family: inherit; white-space: nowrap;
    }
    #__edit_toolbar__ button:hover { background: rgba(255,255,255,0.2); }
    #__edit_toolbar__ button.primary { background: #0052D9; border-color: #0052D9; }
    #__edit_toolbar__ button.primary:hover { background: #0065ff; }
    #__edit_toolbar__ button.danger { background: transparent; color: #ef4444; border-color: #ef4444; }
    #__edit_toolbar__ button.save-btn { background: #059669; border-color: #059669; color: #fff; }
    #__edit_toolbar__ button.save-btn:hover { background: #10b981; }
    #__btn_undo__, #__btn_redo__ { opacity: 0.4; pointer-events: none; transition: opacity 0.15s; }
    #__edit_toolbar__ input[type="text"] { min-width: 100px; }
    #__edit_toolbar__ input[type="color"] { padding: 2px; width: 30px; height: 26px; cursor: pointer; }
    #__edit_toolbar__ select.font-sel { min-width: 180px; max-width: 240px; }
    #__edit_toolbar__ select option { color: #0f172a; background: #fff; }
    #__edit_toolbar__ select optgroup { color: #0f172a; font-weight: 700; background: #f1f5f9; }
    .tb-group { display: flex; align-items: center; gap: 5px; color: #cbd5e1; font-size: 12px; }
    .spacer { flex: 1; }
    .save-status { font-size: 12px; color: #94a3b8; display: flex; align-items: center; gap: 4px; padding: 4px 8px; border-radius: 4px; }
    .save-status.unsaved { color: #fbbf24; background: rgba(251, 191, 36, 0.1); }

    /* 幽灵浮动按钮 - 圆形半透明 */
    #__edit_fab__ {
      position: fixed; bottom: 24px; right: 24px; z-index: 99998;
      width: 48px; height: 48px; border-radius: 50%;
      background: rgba(5,27,49,0.72); color: rgba(255,255,255,0.4);
      border: 1.5px solid rgba(255,255,255,0.15);
      box-shadow: 0 4px 16px rgba(0,0,0,0.2);
      cursor: pointer; font-size: 18px;
      display: flex; align-items: center; justify-content: center;
      transition: opacity 0.25s, background 0.2s, color 0.2s, transform 0.2s, box-shadow 0.2s;
      opacity: 0.12;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }
    #__edit_fab__:hover {
      opacity: 0.7;
      background: rgba(5,27,49,0.88);
      color: rgba(255,255,255,0.9);
      transform: scale(1.05);
      box-shadow: 0 6px 20px rgba(0,0,0,0.25);
    }
    html.__edit_mode__ #__edit_fab__ { display: none; }

    /* Toast */
    #__edit_toast__ {
      position: fixed; bottom: 40px; left: 50%;
      transform: translateX(-50%);
      background: #0f172a; color: #fff; padding: 12px 24px;
      border-radius: 8px; font-size: 14px; z-index: 100000;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      opacity: 0; pointer-events: none;
      transition: opacity 0.3s, transform 0.3s;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    }
    #__edit_toast__.show { opacity: 1; transform: translateX(-50%) translateY(-8px); }

  `;
  document.head.appendChild(style);

  // ========== 2. 工具栏 ==========
  const toolbar = document.createElement('div');
  toolbar.id = '__edit_toolbar__';
  toolbar.innerHTML = `
    <div class="tb-row">
      <span class="tb-title">编辑模式</span>
      <div class="divider"></div>
      <input type="text" id="__find__" placeholder="查找…">
      <input type="text" id="__replace__" placeholder="替换为…">
      <button id="__btn_replace__">全局替换</button>
      <div class="divider"></div>
      <button id="__btn_clear_theme__">重置样式</button>
      <button id="__btn_reset__" class="danger">恢复初版</button>
      <div class="divider"></div>
      <button id="__btn_undo__" title="撤销 (Cmd+Z)">↩️ 撤销</button>
      <button id="__btn_redo__" title="重做 (Cmd+Shift+Z)">↪️ 重做</button>
      <div class="spacer"></div>
      <span class="save-status" id="__save_status__">✅ 已保存</span>
      <button id="__btn_save__" class="save-btn">💾 保存</button>
      <button id="__btn_confirm_exit__" class="primary">✅ 确认退出</button>
      <button id="__btn_export__">📥 导出</button>
      <button id="__btn_exit__">取消</button>
    </div>
    <div class="tb-row secondary">
      <div class="tb-group">
        英文 <select id="__font_latin__" class="font-sel" style="min-width:200px">${buildFontSelectOptions(FONTS, '保持原样', 'latin')}</select>
      </div>
      <div class="tb-group">
        中文 <select id="__font_cjk__" class="font-sel" style="min-width:200px">${buildFontSelectOptions(FONTS, '保持原样', 'cjk')}</select>
      </div>
      <button id="__btn_font_global__" class="primary" title="将选中字体应用到全文（支持只选英文、只选中文、或中英各选一个）">应用到全文</button>
      <div class="divider"></div>
      <div class="tb-group">
        文字色 <input type="color" id="__text_color__" value="#111111">
      </div>
    </div>
  `;
  document.body.appendChild(toolbar);

  // v2.4.1 修复：工具栏创建后，从 body.dataset 回填两个字体下拉的选中状态
  //   否则刷新后 localStorage 恢复了 font CSS、dataset，但下拉还是"保持原样"
  (function restoreFontDropdownsFromDataset() {
    const restore = (selId, datasetKey) => {
      const sel = document.getElementById(selId);
      const name = document.body.dataset[datasetKey];
      if (!sel || !name) return;
      for (let i = 0; i < sel.options.length; i++) {
        if ((sel.options[i].dataset.name || '') === name) { sel.selectedIndex = i; return; }
      }
    };
    restore('__font_latin__', 'themeLatinFont');
    restore('__font_cjk__', 'themeCjkFont');
  })();

  // ========== 4. 幽灵浮动按钮（圆形） ==========
  const fab = document.createElement('button');
  fab.id = '__edit_fab__';
  fab.title = '进入编辑模式（Ctrl/Cmd + E）';
  fab.innerHTML = '✏️';
  document.body.appendChild(fab);

  // ========== 6. Toast ==========
  const toast = document.createElement('div');
  toast.id = '__edit_toast__';
  document.body.appendChild(toast);

  function showToast(msg, ms = 1800) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), ms);
  }

  // ========== 7. PPT 导航屏蔽/恢复 ==========
  function blockPPTNavigation() {
    // 只调用 PPT 暴露的暂停接口（不再暴力清所有 interval）
    if (typeof window.__editorPauseAuto === 'function') {
      try { window.__editorPauseAuto(); } catch (e) { console.warn(e); }
    }

    // 屏蔽键盘翻页（不影响 contenteditable 输入）
    pptKeydownHandler = function(e) {
      const t = e.target;
      if (t && t.isContentEditable) return;
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', ' '].includes(e.key)) {
        e.stopImmediatePropagation();
      }
    };
    document.addEventListener('keydown', pptKeydownHandler, true);

    // 屏蔽触摸翻页（但不影响工具栏）
    pptTouchStartHandler = function(e) {
      if (e.target && e.target.closest && e.target.closest('#__edit_toolbar__')) return;
      e.stopImmediatePropagation();
    };
    pptTouchEndHandler = function(e) {
      if (e.target && e.target.closest && e.target.closest('#__edit_toolbar__')) return;
      e.stopImmediatePropagation();
    };
    document.addEventListener('touchstart', pptTouchStartHandler, true);
    document.addEventListener('touchend', pptTouchEndHandler, true);
  }

  function unblockPPTNavigation() {
    if (pptKeydownHandler) {
      document.removeEventListener('keydown', pptKeydownHandler, true);
      pptKeydownHandler = null;
    }
    if (pptTouchStartHandler) {
      document.removeEventListener('touchstart', pptTouchStartHandler, true);
      pptTouchStartHandler = null;
    }
    if (pptTouchEndHandler) {
      document.removeEventListener('touchend', pptTouchEndHandler, true);
      pptTouchEndHandler = null;
    }
    // 恢复自动播放
    if (typeof window.__editorResumeAuto === 'function') {
      try { window.__editorResumeAuto(); } catch (e) { console.warn(e); }
    }
  }

  // ========== 8. 首次备份 ==========
  if (!localStorage.getItem(ORIGINAL_KEY)) {
    localStorage.setItem(ORIGINAL_KEY, captureCleanBody());
  }

  // ========== 9. 恢复上次编辑（不自动恢复结构化 DOM，避免破坏 PPT） ==========
  // 注意：不在加载时 restoreBody，只在进入编辑模式时提示有历史
  // 因为 PPT 结构复杂，restoreBody 可能打乱 stage/slide 布局 → 预览卡死
  // 改为：只恢复主题（字体/颜色），文字编辑由 localStorage 文本块独立保存
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme) {
    try {
      const t = JSON.parse(savedTheme);
      if (t.font) applyFontFamilyGlobal(t.font, t.fontBold, false);
      // v2.4：回填两个字体下拉的选中状态 + dataset
      if (t.latinFont) {
        document.body.dataset.themeLatinFont = t.latinFont;
        const sel = document.getElementById('__font_latin__');
        if (sel) {
          for (let i = 0; i < sel.options.length; i++) {
            if ((sel.options[i].dataset.name || '') === t.latinFont) { sel.selectedIndex = i; break; }
          }
        }
      }
      if (t.cjkFont) {
        document.body.dataset.themeCjkFont = t.cjkFont;
        const sel = document.getElementById('__font_cjk__');
        if (sel) {
          for (let i = 0; i < sel.options.length; i++) {
            if ((sel.options[i].dataset.name || '') === t.cjkFont) { sel.selectedIndex = i; break; }
          }
        }
      }
    } catch (e) { console.warn(e); }
  }
  // 尝试恢复文字修改（但跳过结构化恢复）
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      restoreTextOnly(saved);
      setTimeout(() => showToast('已恢复上次保存的文字编辑', 1500), 300);
    } catch (e) { console.warn('恢复失败:', e); }
  }
  markSaved();

  // 🔑 恢复初版 reload 后自动重进编辑模式
  if (sessionStorage.getItem(REENTER_KEY) === '1') {
    sessionStorage.removeItem(REENTER_KEY);
    // 等 DOM 就绪再进（注入脚本可能在 body 还没完全 parse 时执行）
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(() => { enterEditMode(); showToast('✅ 已恢复为初始版本 · 编辑模式继续', 2000); }, 200);
    } else {
      window.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => { enterEditMode(); showToast('✅ 已恢复为初始版本 · 编辑模式继续', 2000); }, 200);
      });
    }
  }

  // ========== 10. 进入/退出 ==========
  function enterEditMode() {
    if (isEditMode) return;
    isEditMode = true;
    document.documentElement.classList.add('__edit_mode__');
    fab.classList.add('active');
    wrapOrphanText();
    markEditable();
    markNoEdit();
    blockPPTNavigation();
    showToast('✏️ 编辑模式 · 💾=保存 / ✅=确认退出 / Cmd+Z=撤销', 3000);
  }

  /**
   * 退出编辑模式
   * @param {Object} opts
   * @param {boolean} opts.save - 是否先保存再退出（true=保存，false=丢弃）
   */
  function exitEditMode(opts) {
    opts = opts || {};
    if (!isEditMode) return;

    // 退出前先落定字体预览和颜色预览
    commitFontPreview();
    commitColorPreview();

    if (opts.save) {
      saveSnapshot();
      saveThemeState();
    } else {
      // 丢弃：撤销 DOM 上的修改（通过重新加载原始文本）
      if (dirty) {
        discardDirtyChanges();
      }
    }

    isEditMode = false;
    unblockPPTNavigation();
    document.documentElement.classList.remove('__edit_mode__');
    fab.classList.remove('active');
    fab.innerHTML = '✏️';
    unmarkEditable();
    cleanupWrappedText();
    markSaved();
  }

  /** 丢弃当前 session 的编辑（重新加载页面，回到最后一次保存的状态） */
  function discardDirtyChanges() {
    // 最简单可靠的方式：刷新页面（保留 localStorage 里最后一次保存的内容）
    location.reload();
  }

  // ========== 11. 可编辑标记 ==========
  const EDITABLE_SELECTORS = [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'p', 'li', 'td', 'th',
    'span:not([data-no-edit])',
    'div.label', 'div.name', 'div.desc', 'div.sub',
    'div.k', 'div.v', 'div.big-num',
    'div.tag', 'div.eyebrow', 'div.section-eyebrow',
    // v2.3.3 扩：常见标题/副标题/引导文字 class
    'div.kicker', 'div.lead', 'div.hero', 'div.subtitle', 'div.caption',
    'div.section-title', 'div.title', 'div.meta', 'div.quote', 'div.author',
    'div.number', 'div.stat', 'div.count', 'div.date', 'div.tagline',
    'blockquote', 'figcaption',
    'strong', 'em', 'a',
    'div.icon', 'span.m-icon', 'div.m-icon',
    'div.g-icon', 'span.g-icon',
    'span.i', 'div.i',
  ];

  function isIconElement(el) {
    const text = el.textContent.trim();
    if (!text) return false;
    const cls = el.className || '';
    if (/\b(icon|m-icon|g-icon)\b/.test(cls)) return true;
    if (text.length <= 4 && !/[\u4e00-\u9fff\u3000-\u303f\u0041-\u007a\u0030-\u0039]/.test(text)) return true;
    return false;
  }

  function hasOnlyElementChildren(el) {
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) return false;
    }
    return true;
  }

  function markEditable() {
    // 优先：所有带 data-edit 属性的元素都可编辑（最可靠）
    document.querySelectorAll('[data-edit]').forEach((el) => {
      if (el.closest('#__edit_toolbar__, #__edit_toast__, #__edit_fab__')) return;
      if (el.hasAttribute('data-editable')) return;
      el.setAttribute('contenteditable', 'true');
      el.setAttribute('data-editable', 'true');
      el.addEventListener('input', onEditInput);
    });

    // 通用：按 selector 扫描（兜底）
    const sel = EDITABLE_SELECTORS.join(',');
    document.querySelectorAll(sel).forEach((el) => {
      if (el.closest('#__edit_toolbar__, #__edit_toast__, #__edit_fab__')) return;
      if (el.hasAttribute('data-no-edit')) return;
      if (el.hasAttribute('data-editable')) return;
      if (el.children.length > 0 && hasOnlyElementChildren(el)) return;
      const isIcon = isIconElement(el);
      el.setAttribute('contenteditable', 'true');
      el.setAttribute('data-editable', 'true');
      if (isIcon) el.setAttribute('data-editable-icon', 'true');
      el.addEventListener('input', onEditInput);
    });
  }

  function wrapOrphanText() {
    // v2.3.3 扩：td/th/li + 常见 meta 类 div
    const containers = document.querySelectorAll(
      'td, th, li, ' +
      'div.cover-meta div, div.meta div, div.info div, ' +
      'div.stat, div.tagline, div.caption, div.quote, div.author, ' +
      'div.kv div, div.pair div'
    );
    containers.forEach((el) => {
      if (el.closest('#__edit_toolbar__, #__edit_toast__, #__edit_fab__')) return;
      Array.from(el.childNodes).forEach((node) => {
        if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
          const span = document.createElement('span');
          span.setAttribute('data-editable-wrapped', 'true');
          el.insertBefore(span, node);
          span.appendChild(node);
        }
      });
    });
  }

  function cleanupWrappedText() {
    document.querySelectorAll('[data-editable-wrapped]').forEach((span) => {
      const parent = span.parentNode;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      span.remove();
    });
  }

  function markNoEdit() {
    NO_EDIT_CLASSES.forEach((cls) => {
      document.querySelectorAll(cls).forEach((el) => {
        el.setAttribute('data-no-edit', 'true');
      });
    });
  }

  function unmarkEditable() {
    document.querySelectorAll('[data-editable]').forEach((el) => {
      el.removeAttribute('contenteditable');
      el.removeAttribute('data-editable');
      el.removeAttribute('data-editable-icon');
      el.removeEventListener('input', onEditInput);
    });
    document.querySelectorAll('[data-no-edit]').forEach((el) => {
      el.removeAttribute('data-no-edit');
    });
  }

  function onEditInput() { markDirty(); }

  // ========== 12. 快照（文字级，不动 DOM 结构） ==========
  function captureCleanBody() {
    const clone = document.body.cloneNode(true);
    ['__edit_toolbar__', '__edit_fab__', '__edit_toast__'].forEach((id) => {
      const n = clone.querySelector('#' + id);
      if (n) n.remove();
    });
    clone.querySelectorAll('[contenteditable], [data-editable], [data-editable-icon], [data-no-edit]').forEach((el) => {
      el.removeAttribute('contenteditable');
      el.removeAttribute('data-editable');
      el.removeAttribute('data-editable-icon');
      el.removeAttribute('data-no-edit');
    });
    clone.querySelectorAll('[data-editable-wrapped]').forEach((span) => {
      const parent = span.parentNode;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      span.remove();
    });
    // 清理预览标记（font / color），保留 data-editor-styled 用于恢复后重置
    clone.querySelectorAll('[data-font-preview]').forEach((el) => el.removeAttribute('data-font-preview'));
    clone.querySelectorAll('[data-color-preview]').forEach((el) => el.removeAttribute('data-color-preview'));
    return clone.innerHTML;
  }

  /**
   * v1.9.1：按 data-edit key + DOM 出现顺序索引恢复文字内容
   * 同名 key 的第 N 个元素只跟保存快照里同名 key 的第 N 个匹配，
   * 不同页上的同名元素互不覆盖。
   */
  function restoreTextOnly(savedHTML) {
    if (!savedHTML) return;
    const parser = new DOMParser();
    const doc = parser.parseFromString('<body>' + savedHTML + '</body>', 'text/html');
    const savedBody = doc.body;

    // 为保存的 DOM 建索引：key → [el0, el1, el2, ...]
    const savedIndex = {};
    savedBody.querySelectorAll('[data-edit]').forEach((el) => {
      const key = el.getAttribute('data-edit');
      if (!key) return;
      if (!savedIndex[key]) savedIndex[key] = [];
      savedIndex[key].push(el);
    });

    // 为当前 DOM 按同样顺序遍历，同名 key 的第 N 个对应第 N 个
    const currentCount = {};
    const currentFields = document.querySelectorAll('[data-edit]');
    let restored = 0;
    currentFields.forEach((el) => {
      const key = el.getAttribute('data-edit');
      if (!key) return;
      if (!currentCount[key]) currentCount[key] = 0;
      const idx = currentCount[key]++;
      const savedList = savedIndex[key];
      if (!savedList || idx >= savedList.length) return;
      const saved = savedList[idx];
      if (saved.innerHTML !== el.innerHTML) {
        el.innerHTML = saved.innerHTML;
        restored++;
      }
    });
    return restored;
  }

  function saveSnapshot() {
    updateSaveStatus('saving');
    try {
      localStorage.setItem(STORAGE_KEY, captureCleanBody());
      markSaved();
      showToast('✅ 已保存', 1200);
    } catch (e) {
      updateSaveStatus('modified');
      showToast('❌ 保存失败（可能超容量）', 2500);
    }
  }

  function saveThemeState() {
    localStorage.setItem(THEME_KEY, JSON.stringify({
      font: document.body.dataset.themeFont || '',
      fontBold: document.body.dataset.themeFontBold || '',
      latinFont: document.body.dataset.themeLatinFont || '',
      cjkFont: document.body.dataset.themeCjkFont || ''
    }));
  }

  // ========== 13. 全局替换 ==========
  function globalReplace(find, replace) {
    if (!find) return 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (node.parentElement && node.parentElement.closest('#__edit_toolbar__, #__edit_toast__, #__edit_fab__, script, style')) return NodeFilter.FILTER_REJECT;
        return node.textContent.includes(find) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let count = 0;
    const nodes = [];
    let node;
    while ((node = walker.nextNode())) nodes.push(node);
    nodes.forEach((n) => {
      const before = n.textContent;
      const after = before.split(find).join(replace);
      if (before !== after) { count += before.split(find).length - 1; n.textContent = after; }
    });
    return count;
  }

  // ========== 14. 字体（含 Google Fonts 按需加载） ==========

  // 需要从 Google Fonts 加载的字体（关键词 → 对应 CSS 引用名）
  const GOOGLE_FONTS = {
    // ===== 英文 · 无衬线 =====
    'Inter': 'Inter:wght@300;400;500;600;700;800',
    'Roboto': 'Roboto:wght@300;400;500;700',
    'Poppins': 'Poppins:wght@300;400;500;600;700;800',
    'Montserrat': 'Montserrat:wght@300;400;500;600;700;800',
    'Lato': 'Lato:wght@300;400;700;900',
    'Open Sans': 'Open+Sans:wght@300;400;600;700',
    'Source Sans Pro': 'Source+Sans+Pro:wght@300;400;600;700',
    'IBM Plex Sans': 'IBM+Plex+Sans:wght@300;400;500;600;700',
    'Work Sans': 'Work+Sans:wght@300;400;500;600;700;800',
    'DM Sans': 'DM+Sans:wght@300;400;500;600;700',
    'Manrope': 'Manrope:wght@300;400;500;600;700;800',
    'Nunito': 'Nunito:wght@300;400;600;700;800',
    'Rubik': 'Rubik:wght@300;400;500;600;700;800',
    'Outfit': 'Outfit:wght@300;400;500;600;700;800',
    'Plus Jakarta Sans': 'Plus+Jakarta+Sans:wght@300;400;500;600;700;800',
    'Space Grotesk': 'Space+Grotesk:wght@300;400;500;600;700',

    // ===== 英文 · 衬线 =====
    'Playfair Display': 'Playfair+Display:wght@400;500;600;700;800',
    'Merriweather': 'Merriweather:wght@300;400;700;900',
    'Lora': 'Lora:wght@400;500;600;700',
    'IBM Plex Serif': 'IBM+Plex+Serif:wght@300;400;500;600;700',
    'PT Serif': 'PT+Serif:wght@400;700',
    'EB Garamond': 'EB+Garamond:wght@400;500;600;700',
    'Cormorant Garamond': 'Cormorant+Garamond:wght@300;400;500;600;700',
    'Crimson Pro': 'Crimson+Pro:wght@300;400;500;600;700',
    'DM Serif Display': 'DM+Serif+Display',
    'Bitter': 'Bitter:wght@300;400;500;600;700',

    // ===== 英文 · 等宽 =====
    'JetBrains Mono': 'JetBrains+Mono:wght@300;400;500;600;700',
    'Fira Code': 'Fira+Code:wght@300;400;500;600;700',
    'Source Code Pro': 'Source+Code+Pro:wght@300;400;500;600;700',
    'IBM Plex Mono': 'IBM+Plex+Mono:wght@300;400;500;600;700',
    'Space Mono': 'Space+Mono:wght@400;700',
    'Inconsolata': 'Inconsolata:wght@300;400;500;600;700',

    // ===== 英文 · 装饰/展示 =====
    'Pacifico': 'Pacifico',
    'Caveat': 'Caveat:wght@400;500;600;700',
    'Oswald': 'Oswald:wght@300;400;500;600;700',
    'Bebas Neue': 'Bebas+Neue',
    'Abril Fatface': 'Abril+Fatface',
    'Archivo Black': 'Archivo+Black',
    'Anton': 'Anton',
    'Righteous': 'Righteous',
    'Dancing Script': 'Dancing+Script:wght@400;500;600;700',
    'Great Vibes': 'Great+Vibes',
    'Satisfy': 'Satisfy',
    'Sacramento': 'Sacramento',
    'Permanent Marker': 'Permanent+Marker',
    'Shadows Into Light': 'Shadows+Into+Light',

    // ===== 中文 · Google Fonts SC =====
    'Noto Sans SC': 'Noto+Sans+SC:wght@300;400;500;700;900',
    'Noto Serif SC': 'Noto+Serif+SC:wght@300;400;500;700;900',
    'Source Han Sans SC': 'Noto+Sans+SC:wght@300;400;500;700;900',
    'Source Han Serif SC': 'Noto+Serif+SC:wght@300;400;500;700;900',
    'ZCOOL XiaoWei': 'ZCOOL+XiaoWei',
    'ZCOOL QingKe HuangYou': 'ZCOOL+QingKe+HuangYou',
    'ZCOOL KuaiLe': 'ZCOOL+KuaiLe',
    'Ma Shan Zheng': 'Ma+Shan+Zheng',
    'Long Cang': 'Long+Cang',
    'Liu Jian Mao Cao': 'Liu+Jian+Mao+Cao',
    'Zhi Mang Xing': 'Zhi+Mang+Xing',
  };

  /** 根据 fontValue（可能是多个 fallback）提取需要加载的 Google Fonts 并按需注入 */
  function ensureGoogleFonts(fontValue) {
    if (!fontValue) return;
    const families = [];
    Object.keys(GOOGLE_FONTS).forEach((key) => {
      // 匹配 "Family Name" 或 Family Name
      const re = new RegExp('["\']?' + key.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '["\']?', 'i');
      if (re.test(fontValue)) families.push(GOOGLE_FONTS[key]);
    });
    if (!families.length) return;
    const href = 'https://fonts.googleapis.com/css2?' + families.map(f => 'family=' + f).join('&') + '&display=swap';
    if (document.querySelector(`link[data-gfonts="${href}"]`)) return;
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = href;
    link.setAttribute('data-gfonts', href);
    document.head.appendChild(link);
  }

  // ========== 字体选区预览（可连续切换，逐 text node 包 span，不嵌套）==========
  // 思路：每次下拉变动，unwrap 上一轮预览 span 列表 → 收集选区内 text node → 逐个包新 span。
  // 直到用户"落定"（点非下拉区 / Esc / 退出编辑），预览 span 去掉标记变成普通 span。

  /**
   * 收集 range 内所有 text node（不进入编辑器自身元素）
   */
  function getTextNodesInRange(range) {
    const nodes = [];
    const walker = document.createTreeWalker(
      range.commonAncestorContainer.nodeType === Node.TEXT_NODE
        ? range.commonAncestorContainer.parentNode
        : range.commonAncestorContainer,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (node.parentElement && node.parentElement.closest('#__edit_toolbar__, #__edit_toast__, #__edit_fab__, script, style')) return NodeFilter.FILTER_REJECT;
          const nodeRange = document.createRange();
          nodeRange.selectNode(node);
          // 只要和选区有交集就算
          if (range.compareBoundaryPoints(Range.END_TO_START, nodeRange) < 0 &&
              range.compareBoundaryPoints(Range.START_TO_END, nodeRange) > 0) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    return nodes;
  }

  /**
   * 给一组 text node 各自包上 span 并设置样式
   * @param {Text[]} textNodes
   * @param {string} cssProp - CSS 属性名，如 'fontFamily'
   * @param {string} cssVal - CSS 值
   * @param {string} dataAttr - data 属性名，如 'data-font-preview'
   * @param {Range} originalRange - 原始选区 range，用于只处理选区内部分
   * @returns {HTMLElement[]} 创建的 span 数组
   */
  function wrapTextNodesWithStyle(textNodes, cssProp, cssVal, dataAttr, originalRange) {
    const spans = [];
    textNodes.forEach((textNode) => {
      // 计算 text node 中被选区覆盖的文字范围
      let startOff = 0;
      let endOff = textNode.length;
      if (textNode === originalRange.startContainer) startOff = originalRange.startOffset;
      if (textNode === originalRange.endContainer) endOff = originalRange.endOffset;
      if (startOff >= endOff) return; // 空选区跳过

      // 如果不是整个 text node 被选中，先拆分
      let targetNode = textNode;
      if (startOff > 0) {
        targetNode = textNode.splitText(startOff);
        endOff -= startOff;
      }
      if (endOff < targetNode.length) {
        targetNode.splitText(endOff);
      }

      // 包 span
      const span = document.createElement('span');
      span.style.setProperty(cssProp === 'fontFamily' ? 'font-family' : 'color', cssVal, 'important');
      span.setAttribute(dataAttr, '1');
      targetNode.parentNode.insertBefore(span, targetNode);
      span.appendChild(targetNode);
      spans.push(span);
    });
    return spans;
  }

  // 预览字体：有选区 or 有上一次预览的 span 列表 → 逐 text node 包 span，保持选区
  let __fontPreviewSpans = []; // 当前预览用的 span 元素列表（可能多个）
  // 兼容旧变量名（单个），改为用列表
  Object.defineProperty(window, '__fontPreviewSpan', {
    get() { return __fontPreviewSpans.length > 0 ? __fontPreviewSpans[0] : null; },
    set() {} // no-op, 用新列表 API
  });

  // 把所有预览 span 的内容放回父节点，删 span，返回覆盖全部内容的 range
  function unwrapFontPreview() {
    if (__fontPreviewSpans.length === 0) return null;
    let firstNode = null, lastNode = null;
    __fontPreviewSpans.forEach((span) => {
      if (!span || !span.parentNode) return;
      const parent = span.parentNode;
      const first = span.firstChild;
      const last = span.lastChild;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      span.remove();
      try { parent.normalize(); } catch (_) {}
      if (first && !firstNode) firstNode = first;
      if (last) lastNode = last;
    });
    __fontPreviewSpans = [];
    if (!firstNode || !lastNode) return null;
    try {
      const range = document.createRange();
      // normalize 后 firstNode/lastNode 可能已被合并，用安全方式
      range.setStartBefore(firstNode.parentNode ? firstNode : firstNode);
      range.setEndAfter(lastNode.parentNode ? lastNode : lastNode);
      return range;
    } catch (_) {
      return null;
    }
  }

  function previewFontOnSelection(fontValue) {
    if (!fontValue) return;
    ensureGoogleFonts(fontValue);

    const sel = window.getSelection();
    let range = null;

    if (__fontPreviewSpans.length > 0) {
      // 已经有预览中 → 先 unwrap，拿到覆盖原预览内容的 range
      range = unwrapFontPreview();
    } else if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
      // 用户第一次框选 → 用当前选区
      range = sel.getRangeAt(0).cloneRange();
    } else {
      showToast('请先选中要改字体的文字', 1500);
      return;
    }
    if (!range) return;

    // 收集选区内所有 text node，逐个包 span
    const textNodes = getTextNodesInRange(range);
    if (textNodes.length === 0) {
      showToast('选区内没有可修改的文字', 1500);
      return;
    }
    __fontPreviewSpans = wrapTextNodesWithStyle(textNodes, 'fontFamily', fontValue, 'data-font-preview', range);

    // 保持选区高亮
    try {
      if (__fontPreviewSpans.length > 0) {
        const newRange = document.createRange();
        newRange.setStartBefore(__fontPreviewSpans[0]);
        newRange.setEndAfter(__fontPreviewSpans[__fontPreviewSpans.length - 1]);
        sel.removeAllRanges();
        sel.addRange(newRange);
      }
    } catch (_) {}

    markDirty();
    const shortName = fontValue.split(',')[0].replace(/["']/g, '').trim();
    showToast(`预览字体 → ${shortName}（点别处或按 Esc 落定）`, 1200);
  }

  // 落定预览：去掉 data-font-preview 标记，加 data-editor-styled 永久标记
  function commitFontPreview() {
    if (__fontPreviewSpans.length === 0) return;
    __fontPreviewSpans.forEach((span) => {
      if (!span || !span.parentNode) return;
      span.removeAttribute('data-font-preview');
      span.setAttribute('data-editor-styled', '1');
    });
    __fontPreviewSpans = [];
  }

  // 旧 API 兼容别名
  function applyFontToSelection(fontValue) { previewFontOnSelection(fontValue); }

  /**
   * 清除所有编辑器产生的局部字体 span（data-font-preview / data-editor-styled 带 font-family 的）
   * 在"应用到全文"之前调用，确保全局字体成为唯一 source of truth
   */
  function clearAllFontSpans() {
    // 先落定还在预览状态的 span
    commitFontPreview();
    // 清除所有带 font-family 的编辑器 span
    const spans = document.querySelectorAll('span[data-editor-styled], span[data-font-preview]');
    spans.forEach((span) => {
      const hasFont = span.style && span.style.fontFamily;
      if (!hasFont) return; // 只管字体 span，不动颜色 span
      // 如果 span 只有 font-family 一个样式 → 直接 unwrap
      // 如果还有 color 等其他样式 → 只清 font-family，保留 span
      span.style.removeProperty('font-family');
      if (!span.getAttribute('style') || span.getAttribute('style').trim() === '') {
        // 空 style → unwrap
        const parent = span.parentNode;
        if (!parent) return;
        while (span.firstChild) parent.insertBefore(span.firstChild, span);
        span.remove();
        try { parent.normalize(); } catch (_) {}
      } else if (!span.style.color) {
        // 没 color 了就移除 editor 标记
        span.removeAttribute('data-editor-styled');
        span.removeAttribute('data-font-preview');
      }
    });
  }

  function applyFontFamilyGlobal(fontValue, boldValue, persist = true) {
    let s = document.getElementById('__font_global_override__');
    if (!fontValue) { if (s) s.remove(); delete document.body.dataset.themeFont; delete document.body.dataset.themeFontBold; if (persist) saveThemeState(); return; }
    ensureGoogleFonts(fontValue);
    if (boldValue) ensureGoogleFonts(boldValue);
    // 关键：应用全文前先清掉所有局部字体 span（Bug A 修复）
    // 否则局部 inline !important 会赢过 stylesheet !important，全局覆盖不到局部
    if (persist) clearAllFontSpans();
    if (!s) { s = document.createElement('style'); s.id = '__font_global_override__'; document.head.appendChild(s); }
    // 关键：selector 排除工具栏/FAB/Toast/弹窗（Bug B 修复）
    // :not() 里面不能用复杂选择器，所以用多个 :not() 叠加
    const EXCLUDE = ':not(#__edit_toolbar__):not(#__edit_toolbar__ *):not(#__edit_fab__):not(#__edit_toast__):not(#__editor_confirm_overlay__):not(#__editor_confirm_overlay__ *)';
    let css = `body${EXCLUDE} { font-family: ${fontValue} !important; }\n`;
    css += `body *${EXCLUDE} { font-family: ${fontValue} !important; }`;
    if (boldValue) {
      css += `\nbody h1${EXCLUDE}, body h2${EXCLUDE}, body h3${EXCLUDE}, body strong${EXCLUDE}, body .bold${EXCLUDE} { font-family: ${boldValue} !important; }`;
    }
    s.textContent = css;
    document.body.dataset.themeFont = fontValue;
    document.body.dataset.themeFontBold = boldValue || '';
    if (persist) { saveThemeState(); markDirty(); }
    const shortName = fontValue.split(',')[0].replace(/["']/g, '').trim();
    showToast(`全局字体 → ${shortName}`, 1200);
  }

  /** v2.4 新增：按"英文字体 + 中文字体"一起应用
   *  latinFont / cjkFont 为 FONTS 里的对象，或 null
   *  内部合并 font-family 后复用 applyFontFamilyGlobal 的 CSS 注入逻辑
   *
   *  关键修复（v2.4.1）：合并前要**剥离每个字体末尾的 generic family**
   *    （sans-serif / serif / monospace / cursive / fantasy）
   *    否则英文字体里的 sans-serif 会阻断中文 fallback，导致中文字符永远不会回退到中文字体
   *    例如错误合并：Inter, sans-serif, SimSun, serif
   *         → 中文字符查到 sans-serif 就停了，根本到不了 SimSun
   *    正确合并：Inter, SimSun, sans-serif
   *         → 中文字符 Inter 没覆盖 → fallback 到 SimSun → 中文字体命中
   */
  const GENERIC_FAMILIES = new Set(['sans-serif', 'serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'ui-sans-serif', 'ui-serif', 'ui-monospace', 'ui-rounded']);

  /** 把一个 font-family 字符串拆成具名字体数组（去掉 generic family） */
  function extractNamedFamilies(fontValue) {
    if (!fontValue) return [];
    // 按逗号切，但要保留 "xxx yyy" 这种带空格的引号包裹字体名
    return fontValue.split(',').map((s) => s.trim()).filter((s) => {
      if (!s) return false;
      // 去掉外层引号判断是否 generic
      const bare = s.replace(/^["']|["']$/g, '').trim().toLowerCase();
      return !GENERIC_FAMILIES.has(bare);
    });
  }

  /** 从一组字体 value 里合并出最终 font-family：先去重，再拼接，最后补兜底 */
  function mergeFontValues(values, fallbackGeneric) {
    const named = [];
    const seen = new Set();
    values.forEach((v) => {
      extractNamedFamilies(v).forEach((n) => {
        const key = n.toLowerCase();
        if (!seen.has(key)) { seen.add(key); named.push(n); }
      });
    });
    named.push(fallbackGeneric); // 只在最后放一个 generic 兜底
    return named.join(', ');
  }

  function applyGlobalFontsByPair(latinFont, cjkFont, persist = true) {
    // 两个都为空 → 清除全局字体
    if (!latinFont && !cjkFont) {
      applyFontFamilyGlobal('', '', persist);
      delete document.body.dataset.themeLatinFont;
      delete document.body.dataset.themeCjkFont;
      return;
    }

    // 选兜底：优先看中文字体（中文字体缺失的字符更常见），无中文则看英文
    // serif/monospace/sans-serif 根据第一个字体类型猜
    const guessGeneric = (fv) => {
      if (!fv) return 'sans-serif';
      const v = fv.toLowerCase();
      if (v.includes('serif') && !v.includes('sans-serif')) return 'serif';
      if (v.includes('monospace')) return 'monospace';
      if (v.includes('cursive')) return 'cursive';
      return 'sans-serif';
    };
    const generic = guessGeneric((cjkFont && cjkFont.value) || (latinFont && latinFont.value));

    const values = [];
    const boldValues = [];
    // 英文在前（英文字符优先命中英文字体），中文在后（中文字符 fallback 到中文字体）
    if (latinFont) {
      values.push(latinFont.value);
      boldValues.push(latinFont.valueBold || latinFont.value);
    }
    if (cjkFont && cjkFont !== latinFont) {
      values.push(cjkFont.value);
      boldValues.push(cjkFont.valueBold || cjkFont.value);
    }

    const mergedValue = mergeFontValues(values, generic);
    const hasBold = (latinFont && latinFont.valueBold) || (cjkFont && cjkFont.valueBold);
    const mergedBold = hasBold ? mergeFontValues(boldValues, generic) : '';

    // v2.4.1 关键：dataset 必须**在** applyFontFamilyGlobal **之前**写好
    // 因为 applyFontFamilyGlobal 内部会立即 saveThemeState，读的就是 dataset
    // 写晚了 → localStorage 里 latinFont/cjkFont 永远是空 → 刷新恢复时找不到
    if (latinFont) document.body.dataset.themeLatinFont = latinFont.name;
    else delete document.body.dataset.themeLatinFont;
    if (cjkFont) document.body.dataset.themeCjkFont = cjkFont.name;
    else delete document.body.dataset.themeCjkFont;

    applyFontFamilyGlobal(mergedValue, mergedBold, persist);
  }

  /** 根据 name 在 FONTS 里找字体对象 */
  function findFontByName(name) {
    if (!name) return null;
    return FONTS.find((f) => f.name === name) || null;
  }

  // ========== 15. 文字颜色预览（可连续拖色轮，逐 text node 包 span） ==========
  let __colorPreviewSpans = [];

  function unwrapColorPreview() {
    if (__colorPreviewSpans.length === 0) return null;
    let firstNode = null, lastNode = null;
    __colorPreviewSpans.forEach((span) => {
      if (!span || !span.parentNode) return;
      const parent = span.parentNode;
      const first = span.firstChild;
      const last = span.lastChild;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      span.remove();
      try { parent.normalize(); } catch (_) {}
      if (first && !firstNode) firstNode = first;
      if (last) lastNode = last;
    });
    __colorPreviewSpans = [];
    if (!firstNode || !lastNode) return null;
    try {
      const range = document.createRange();
      range.setStartBefore(firstNode.parentNode ? firstNode : firstNode);
      range.setEndAfter(lastNode.parentNode ? lastNode : lastNode);
      return range;
    } catch (_) {
      return null;
    }
  }

  function previewColorOnSelection(color) {
    if (!color) return;
    const sel = window.getSelection();
    let range = null;

    if (__colorPreviewSpans.length > 0) {
      range = unwrapColorPreview();
    } else if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
      range = sel.getRangeAt(0).cloneRange();
    } else {
      showToast('请先选中要改颜色的文字', 1500);
      return;
    }
    if (!range) return;

    const textNodes = getTextNodesInRange(range);
    if (textNodes.length === 0) {
      showToast('选区内没有可修改的文字', 1500);
      return;
    }
    __colorPreviewSpans = wrapTextNodesWithStyle(textNodes, 'color', color, 'data-color-preview', range);

    try {
      if (__colorPreviewSpans.length > 0) {
        const newRange = document.createRange();
        newRange.setStartBefore(__colorPreviewSpans[0]);
        newRange.setEndAfter(__colorPreviewSpans[__colorPreviewSpans.length - 1]);
        sel.removeAllRanges();
        sel.addRange(newRange);
      }
    } catch (_) {}
    markDirty();
    showToast(`预览颜色 → ${color}（点别处或按 Esc 落定）`, 1200);
  }

  function commitColorPreview() {
    if (__colorPreviewSpans.length === 0) return;
    __colorPreviewSpans.forEach((span) => {
      if (!span || !span.parentNode) return;
      span.removeAttribute('data-color-preview');
      span.setAttribute('data-editor-styled', '1');
    });
    __colorPreviewSpans = [];
  }


  function clearThemeOverrides() {
    showConfirm(
      '重置所有样式？',
      '将清除所有字体和颜色修改（包括全局覆盖和局部选中改色/改字体），恢复为 HTML 原始样式。<br>已编辑的文字内容不受影响。',
      '确认重置',
      null,
      () => {
        pushUndoSnapshot();
        // 清全局覆盖
        const fg = document.getElementById('__font_global_override__'); if (fg) fg.remove();
        delete document.body.dataset.themeFont; delete document.body.dataset.themeFontBold;
        delete document.body.dataset.themeLatinFont; delete document.body.dataset.themeCjkFont;
        const tc = document.getElementById('__text_color_override__'); if (tc) tc.remove();
        delete document.body.dataset.themeTextColor;
        delete document.body.dataset.themeThemeColor;
        const legacy = document.getElementById('__theme_override__'); if (legacy) legacy.remove();
        localStorage.removeItem(THEME_KEY);
        // 只清编辑器产生的 span（带标记），不误杀页面原有的 span
        const editorSpans = document.querySelectorAll('[data-editor-styled], [data-font-preview], [data-color-preview]');
        editorSpans.forEach((span) => {
          const parent = span.parentNode; if (!parent) return;
          while (span.firstChild) parent.insertBefore(span.firstChild, span);
          span.remove();
          try { parent.normalize(); } catch (_) {}
        });
        commitFontPreview();
        commitColorPreview();
        // 重置工具栏：两个字体下拉都归零
        const fontLatin = document.getElementById('__font_latin__');
        if (fontLatin) fontLatin.selectedIndex = 0;
        const fontCjk = document.getElementById('__font_cjk__');
        if (fontCjk) fontCjk.selectedIndex = 0;
        document.getElementById('__text_color__').value = '#111111';
        markDirty();
        showToast('✅ 已重置所有样式', 1500);
      }
    );
  }

  // ========== 17. 导出 ==========
  function exportHTML() {
    if (dirty) saveSnapshot();
    let savedBody = localStorage.getItem(STORAGE_KEY) || captureCleanBody();
    // 清理内部标记，不让它泄露到定稿
    savedBody = savedBody.replace(/ data-editor-styled="1"/g, '');
    const headHTML = document.head.innerHTML.replace(/<style id="__editable_styles__"[\s\S]*?<\/style>/, '');
    const extraStyles = [];
    const fontKey = document.body.dataset.themeFont;
    const fontBold = document.body.dataset.themeFontBold;
    if (fontKey) {
      let css = `body, body * { font-family: ${fontKey} !important; }`;
      if (fontBold) css += `\nbody h1, body h2, body h3, body strong, body .bold { font-family: ${fontBold} !important; }`;
      extraStyles.push(css);
    }
    const tc = document.getElementById('__text_color_override__');
    if (tc) extraStyles.push(tc.textContent);
    const themeColor = document.body.dataset.themeThemeColor;
    let inlineVars = '';
    if (themeColor) {
      const vars = ['--primary', '--accent', '--blue', '--brand', '--ibm-blue', '--qd-blue', '--primary-color', '--color-primary', '--theme-color'];
      inlineVars = ` style="${vars.map((v) => `${v}:${themeColor}`).join(';')}"`;
    }
    const styleTag = extraStyles.length ? `<style>\n${extraStyles.join('\n')}\n</style>` : '';
    const html = `<!DOCTYPE html>\n<html lang="zh-CN"${inlineVars}>\n<head>\n${headHTML}\n${styleTag}\n</head>\n<body>\n${savedBody}\n</body>\n</html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const baseName = location.pathname.split('/').pop().replace(/\.html?$/, '') || '方案';
    const ts = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    a.href = url;
    a.download = `${decodeURIComponent(baseName)}_定稿_${ts}.html`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('✅ 已导出定稿 HTML', 2500);
  }

  // ========== 19. 恢复初版 ==========
  function doResetToOriginal() {
    // 把 STORAGE_KEY 设为 original，清全局样式，然后 reload
    const original = localStorage.getItem(ORIGINAL_KEY);
    if (original) {
      localStorage.setItem(STORAGE_KEY, original);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
    localStorage.removeItem(THEME_KEY);
    // 🔑 标记：reload 后自动重新进入编辑模式（否则会被踢出编辑器）
    sessionStorage.setItem(REENTER_KEY, '1');
    location.reload();
  }

  function resetAll() {
    showConfirm(
      '⚠️ 恢复为初始版本？',
      '恢复后页面回到第一次打开时的状态。<br>建议保存副本后再恢复，以免丢失修改。',
      '确认恢复',
      // 副按钮：保存副本并恢复
      () => {
        const n = getVersions().length + 1;
        saveVersion(`副本 v${n}`);
        doResetToOriginal();
        showToast(`📋 已存副本 v${n} 并恢复初版`, 2000);
      },
      // 主按钮（红色）：直接恢复
      () => {
        doResetToOriginal();
        showToast('✅ 已恢复为初始版本', 2000);
      },
      '保存副本并恢复'
    );
  }

  // ========== 20. 事件绑定 ==========
  // 幽灵按钮：只负责进入编辑（退出由工具栏按钮控制）
  fab.addEventListener('click', () => {
    if (!isEditMode) enterEditMode();
  });

  // 💾 保存（留在编辑模式）
  document.getElementById('__btn_save__').addEventListener('click', () => {
    pushUndoSnapshot();
    saveSnapshot();
    saveThemeState();
  });
  // ✅ 确认退出（保存 + 退出）
  document.getElementById('__btn_confirm_exit__').addEventListener('click', () => {
    exitEditMode({ save: true });
  });
  // 取消：丢弃所有变更退出
  document.getElementById('__btn_exit__').addEventListener('click', () => {
    exitEditMode({ save: false });
  });
  document.getElementById('__btn_export__').addEventListener('click', exportHTML);
  document.getElementById('__btn_reset__').addEventListener('click', resetAll);
  document.getElementById('__btn_clear_theme__').addEventListener('click', clearThemeOverrides);
  document.getElementById('__btn_undo__').addEventListener('click', undo);
  document.getElementById('__btn_redo__').addEventListener('click', redo);
  document.getElementById('__btn_replace__').addEventListener('click', () => {
    const find = document.getElementById('__find__').value;
    const replace = document.getElementById('__replace__').value;
    if (!find) { showToast('请输入要查找的文字'); return; }
    pushUndoSnapshot(); // 替换前先保存快照
    const count = globalReplace(find, replace);
    showToast(count > 0 ? `✅ 已替换 ${count} 处` : '未找到匹配内容');
    if (count > 0) markDirty();
  });
  // v2.4 双下拉版：读取英文/中文下拉当前选中的字体对象
  //   返回 { latinFont, cjkFont }，任一可能为 null
  function getSelectedFonts() {
    const read = (id) => {
      const sel = document.getElementById(id);
      if (!sel || !sel.options.length) return null;
      const opt = sel.options[sel.selectedIndex];
      if (!opt || !opt.value) return null;
      return findFontByName(opt.dataset.name || '');
    };
    return {
      latinFont: read('__font_latin__'),
      cjkFont:   read('__font_cjk__')
    };
  }

  // ---- 选区暂存机制（解决 <select>/color input mousedown 清空文档选区的问题）----
  // 浏览器原生行为：点击表单控件（select / input）会把 document.activeElement 切走，
  // 同时清空 window.getSelection() 里的 Range。所以 change 触发时拿到的 selection 已经是空。
  // 解决：在 mousedown / focus 阶段提前把当前 Range 拷下来，change 时恢复。
  let __savedRange = null;
  function saveSelectionFromDocument() {
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
      const r = sel.getRangeAt(0);
      // 仅当选区落在可编辑区域里才保存，避免误存工具栏里的选区
      const container = r.commonAncestorContainer;
      const elt = container.nodeType === 1 ? container : container.parentElement;
      if (elt && !elt.closest('#__edit_toolbar__') && !elt.closest('#__reset_style_dialog__') && !elt.closest('#__restore_original_dialog__')) {
        __savedRange = r.cloneRange();
        return;
      }
    }
    // 没有有效选区就清空（不保留旧 Range，避免误套到上一次的文字）
    __savedRange = null;
  }
  function restoreSavedRange() {
    if (!__savedRange) return false;
    try {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(__savedRange);
      return true;
    } catch (err) {
      __savedRange = null;
      return false;
    }
  }

  // 下拉 change：有选区就套到选区；无选区不做任何事（等用户点"应用到全文"）
  //   局部套字体时，英文/中文下拉分别独立 —— 选哪个就套哪个的 value
  function onFontDropdownChange(e) {
    // 先尝试恢复 mousedown 时保存的 Range（解决 <select> 清空选区的问题）
    restoreSavedRange();
    const sel = window.getSelection();
    const hasSelection = sel && !sel.isCollapsed && sel.rangeCount > 0;
    const el = e.target;
    const opt = el.options[el.selectedIndex];
    const fontValue = opt ? opt.value : '';
    if (!hasSelection) {
      // 无选区 → 用户在为"应用到全文"做准备，保留下拉 value 等按钮
      return;
    }
    if (!fontValue) return;
    // v2.4.3 bug ④ 修复：下拉选字体前，**先判断当前选区是否与已有预览 span 重叠**
    //   - 如果选区**完全在**某个预览 span 内部 → 说明用户想在预览内部再套更细粒度的字体
    //     必须先 commit 前一次预览（让它落定为 data-editor-styled），
    //     这样新操作走"第一次框选"分支，嵌套包一层新 span，而不是把外层 unwrap 掉
    //   - 如果选区跨越了预览 span 边界（比如包含预览内 + 预览外）→ 维持原 unwrap 行为
    //   - 如果选区完全不相交预览 span → 也要 commit（用户在别处重新选了）
    if (__fontPreviewSpans.length > 0 && hasSelection) {
      const currentRange = sel.getRangeAt(0);
      let shouldCommitFirst = true;
      // 检查是否有任何预览 span 横跨选区边界（部分重叠）
      for (const span of __fontPreviewSpans) {
        if (!span || !span.parentNode) continue;
        const spanRange = document.createRange();
        try {
          spanRange.selectNodeContents(span);
          const startInside = currentRange.comparePoint(spanRange.startContainer, spanRange.startOffset) >= 0;
          const endInside = currentRange.comparePoint(spanRange.endContainer, spanRange.endOffset) <= 0;
          // 如果选区的边界一个在 span 内、一个在 span 外 → 部分重叠 → 维持 unwrap
          const selStartVsSpanStart = spanRange.comparePoint(currentRange.startContainer, currentRange.startOffset);
          const selEndVsSpanEnd = spanRange.comparePoint(currentRange.endContainer, currentRange.endOffset);
          // selStartVsSpanStart: >= 0 表示选区起点在 span 起点之后（即在 span 内或之后）
          // selEndVsSpanEnd: <= 0 表示选区终点在 span 终点之前（即在 span 内或之前）
          // 两者都成立 = 选区完全在 span 内部 → shouldCommitFirst 保持 true
          // 否则 = 部分重叠或完全在外 → shouldCommitFirst 置 false（维持 unwrap 行为）
          if (!(selStartVsSpanStart >= 0 && selEndVsSpanEnd <= 0)) {
            shouldCommitFirst = false;
            break;
          }
        } catch (_) {
          shouldCommitFirst = false;
          break;
        }
      }
      if (shouldCommitFirst) {
        commitFontPreview(); // 把前一次预览落定为 data-editor-styled，__fontPreviewSpans 清空
      }
    }
    applyFontToSelection(fontValue);
    // 套完后清掉 savedRange，下次选文字时会重新存
    __savedRange = null;
    // v2.4.3：**仅在局部套字体场景** reset 下拉到 placeholder
    //   原因：<select> 当前 value 等于新选的 value 时 change 不触发
    //   场景：第一次选"楷体" → 下拉卡在"楷体" → 换一段文字再想选"楷体" → 点不动
    //   不影响"应用到全文"按钮：全局场景是"无选区"走上面分支，不会 reset
    try { el.selectedIndex = 0; } catch (_) {}
  }
  const __latinSel = document.getElementById('__font_latin__');
  const __cjkSel   = document.getElementById('__font_cjk__');
  // mousedown 在 click-into-select 之前触发，此时文档选区还在
  __latinSel.addEventListener('mousedown', saveSelectionFromDocument);
  __cjkSel.addEventListener('mousedown', saveSelectionFromDocument);
  __latinSel.addEventListener('change', onFontDropdownChange);
  __cjkSel.addEventListener('change', onFontDropdownChange);

  document.getElementById('__btn_font_global__').addEventListener('click', () => {
    const { latinFont, cjkFont } = getSelectedFonts();
    if (!latinFont && !cjkFont) { showToast('请至少选择一个字体（英文或中文）', 1800); return; }
    pushUndoSnapshot(); // 全局字体操作前保存快照
    applyGlobalFontsByPair(latinFont, cjkFont);
  });
  const __textColorEl = document.getElementById('__text_color__');
  // color input 同样会清空文档选区，mousedown 阶段先存下来
  __textColorEl.addEventListener('mousedown', saveSelectionFromDocument);
  __textColorEl.addEventListener('input', (e) => {
    restoreSavedRange();
    previewColorOnSelection(e.target.value);
  });
  __textColorEl.addEventListener('change', () => {
    // 提交色值后清 savedRange
    __savedRange = null;
  });

  // 快捷键
  document.addEventListener('keydown', (e) => {
    // Cmd+E = 确认退出（保存+退出）/ 进入编辑
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'e') {
      e.preventDefault();
      if (isEditMode) exitEditMode({ save: true });
      else enterEditMode();
    }
    // Cmd+S = 仅保存（留在编辑模式）
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      if (isEditMode) {
        pushUndoSnapshot();
        saveSnapshot();
        saveThemeState();
      }
    }
    // Cmd+Z = 撤销 / Cmd+Shift+Z = 重做（仅在编辑模式下拦截）
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && isEditMode) {
      e.preventDefault();
      if (e.shiftKey) redo();
      else undo();
    }
    // Esc = 取消（两段式）
    if (e.key === 'Escape' && isEditMode) {
      // 有字体预览 → 先落定预览
      if (__fontPreviewSpans.length > 0) {
        commitFontPreview();
        showToast('已落定预览字体', 1000);
        e.preventDefault();
        return;
      }
      // 有颜色预览 → 先落定预览
      if (__colorPreviewSpans.length > 0) {
        commitColorPreview();
        showToast('已落定预览颜色', 1000);
        e.preventDefault();
        return;
      }
      exitEditMode({ save: false });
    }
  });

  // 点击非工具栏区域 → 落定字体预览和颜色预览
  document.addEventListener('mousedown', (e) => {
    if (__fontPreviewSpans.length === 0 && __colorPreviewSpans.length === 0) return;
    const t = e.target;
    if (!(t instanceof Node)) return;
    if (toolbar.contains(t)) return;
    if (fab && fab.contains(t)) return;
    // 点击在预览 span 内部也不落定
    if (__fontPreviewSpans.some(s => s && s.contains(t))) return;
    if (__colorPreviewSpans.some(s => s && s.contains(t))) return;
    commitFontPreview();
    commitColorPreview();
  }, true);

  console.info('[Editable v2.4.3] 下拉归零 · 嵌套字体安全 commit · 选区跨段 contenteditable 为已知限制');
})();
