---
author: vassiliylakhonin
description: Use the ClawHub CLI to publish, inspect, version, update,
  sync, and troubleshoot OpenClaw skills from the terminal.
homepage: "https://clawhub.ai/vassiliylakhonin/vassili-clawhub-cli"
name: vassili-clawhub-cli
tags:
- clawhub
- openclaw
- cli
- skills
- publishing
- versioning
- troubleshooting
version: 1.2.0
---

# ClawHub CLI Assistant

This skill helps developers manage OpenClaw skills using the ClawHub
CLI.

Use this skill when the user needs terminal commands to publish, update,
inspect, sync, or troubleshoot ClawHub skills.

## Skill trigger

Activate this skill when the user is asking about:

-   publishing a skill to ClawHub
-   releasing a new skill version
-   inspecting a ClawHub package
-   updating installed skills
-   syncing installed skills
-   troubleshooting clawhub CLI commands

## What this skill can do

This skill can:

-   publish a new skill to ClawHub
-   release a new skill version
-   inspect a published skill bundle
-   update installed skills
-   sync installed skills
-   troubleshoot ClawHub CLI errors

## Example user requests

Use this skill when the user asks things like:

-   publish my clawhub skill
-   update my clawhub skill
-   release a new version of my skill
-   inspect a clawhub bundle
-   update installed clawhub skills
-   sync installed clawhub skills
-   troubleshoot clawhub publish error

## Decision rule

Use this skill if the request involves:

-   ClawHub CLI
-   skill publishing
-   skill versioning
-   skill inspection
-   updating installed skills
-   syncing installed skills

## When NOT to use this skill

Do not use this skill for:

-   generic Git questions
-   unrelated programming tasks
-   OpenClaw runtime configuration
-   dashboard walkthroughs unless explicitly requested

## Command templates

Publish a skill:

clawhub publish .

Inspect a skill:

clawhub inspect `<owner>`{=html}/`<skill>`{=html}

Example:

clawhub inspect vassiliylakhonin/vassili-clawhub-cli

Update a skill:

clawhub update `<owner>`{=html}/`<skill>`{=html}

Example:

clawhub update vassiliylakhonin/vassili-clawhub-cli

Update all skills:

clawhub update --all

Sync installed skills:

clawhub sync --all

## Quick commands

Most common ClawHub commands:

clawhub publish .

clawhub inspect `<owner>`{=html}/`<skill>`{=html}

clawhub update `<owner>`{=html}/`<skill>`{=html}

clawhub update --all

clawhub sync --all

## Common workflows

### Publish a new skill

1.  Ensure the skill folder contains `SKILL.md`
2.  Confirm the version number
3.  Run:

clawhub publish .

### Release a new version

1.  Update the skill files
2.  Increase the version number

Example:

1.1.0 → 1.2.0

3.  Publish again

### Update installed skills

Update one skill:

clawhub update vassiliylakhonin/vassili-clawhub-cli

Update all skills:

clawhub update --all

## Typical developer workflow

A typical skill development workflow:

1.  Create a folder containing `SKILL.md`
2.  Write skill instructions
3.  Publish the skill:

clawhub publish .

4.  Inspect the published bundle:

clawhub inspect `<owner>`{=html}/`<skill>`{=html}

5.  Release new versions when needed

## Troubleshooting

### Error: SKILL.md required

Ensure that:

-   the file exists
-   it is located in the root of the skill folder

### Version did not change

Ensure the version number was updated before publishing.

### Authentication error

Run:

clawhub login

Then publish again.

## Output style

When helping the user:

-   provide exact CLI commands
-   keep explanations short
-   give step-by-step instructions
