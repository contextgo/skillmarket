---
name: practice-origin-topic-designer
description: identify and structure practice-origin topic plans for major-theme, policy, governance, and thought-communication reporting. use when chatgpt needs to turn an abstract theme into a source-grounded story plan by tracing formative places, real governance practices, long-term results, and a source-evolution-echo narrative arc for editorial planning.
---

# Practice Origin Topic Designer

Turn abstract themes into source-grounded editorial plans by tracing where an idea, governing approach, or development logic was formed, tested, and later validated in real practice.

This skill is for editorial planning, not final article drafting.

## Core task

Given a broad theme, produce a topic-planning output that answers:

1. Where did this theme take shape in practice?
2. Which places, projects, policies, people, or governance situations best embody it?
3. What observable long-term outcomes can make the theme credible?
4. How should the story be structured so the audience sees the theme as lived reality rather than abstract doctrine?

## Method

Apply this five-step method.

### 1. Define the abstract theme precisely
Restate the theme in one sentence without slogans. Identify the governing idea, the practical problem it tried to solve, and the kinds of real-world settings where it would likely appear.

### 2. Trace the practice origin
Look for the earliest or most formative practical settings where the theme was explored, shaped, or validated. Prefer cases with visible decision logic, clear problems, and strong reporting scenes.

### 3. Build a source-evolution-echo arc
Organize material into:
- **Source**: formative practical setting
- **Evolution**: expansion, refinement, or institutionalization
- **Echo**: present-day evidence showing continuing relevance

### 4. Translate the theme into audience-enterable evidence
Prefer scene, person, object, comparison, and timeline marker over abstract explanation alone.

### 5. Output a reporting plan
Always include:
- recommended central angle
- why the angle works
- source point
- evolution points
- present-day echo evidence
- reporting scenes
- interview targets
- risks or weak spots

## Output
Use the structure in `references/planning-output-template.md`.
Use evaluation logic from `references/source-evolution-echo-patterns.md` when deciding whether a candidate case is a true source point.

## Editorial rules

- Prefer practice over slogan.
- Prefer continuity over isolated examples.
- Prefer one strong anchor over many scattered examples.
- Write like an editorial planner designing a persuasive reporting path.

## Boundary

This skill is for topic planning, reporting architecture, and practice-based framing of abstract themes. It is not for full article drafting, line-by-line scripts, or social copy optimization.
