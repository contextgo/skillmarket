# Planning Output Template

## Standard output template

### Theme Restatement
Restate the abstract theme in plain editorial language.

### Planning Objective
State what the audience should understand.

### Source Point
Name the anchor case and explain why it is the source point.

### Evolution Path
List 2 to 4 later developments that extend the original logic.

### Echo Evidence
List present-day realities that make the original logic credible now.

### Recommended Story Angle
Give one main angle and up to two backups.

### Reporting Scenes
List the best scenes, locations, objects, archives, or daily-life details.

### Interview Targets
List witnesses, planners, implementers, residents, scholars, or practitioners.

### Evidence Chain
Show how the reporting moves from source to evolution to echo.

### Narrative Structure
Use a three-part structure:
1. concrete present-day entry
2. return to formative practice
3. reconnect to current significance

### Why This Plan Works
Explain why this plan is more understandable and less abstract.

### Risks and Gaps
Identify weak evidence, overclaim risk, excessive abstraction, or missing contrast.
