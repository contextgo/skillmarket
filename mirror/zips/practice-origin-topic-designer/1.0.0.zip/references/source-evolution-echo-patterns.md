# Source Evolution Echo Patterns

## Use
Use this file to distinguish true source points from later illustrations and to rank candidate cases.

## What counts as source
A true source point is a formative practical setting where an idea, method, or governing logic was first shaped, tested, clarified, or made legible. It usually has a concrete place, a clear practical problem, visible decision logic, and continuity into later developments.

## What counts as evolution
Evolution shows how the original logic expands, deepens, or becomes systematic across time, places, sectors, or policy layers.

## What counts as echo
Echo is the present-day evidence that makes the earlier source point meaningful now: visible change, ordinary-life effects, or lasting institutional outcomes.

## True source-point test
A candidate case is likely a true source point when it has most of the following:
- formative timing
- practical problem
- decision trace
- logic visible in early form
- continuity potential
- strong reporting legibility

## Strong-case signals
- clear place-based anchor
- visible before-and-after contrast
- timeline depth
- strong scene potential
- identifiable people
- archival or physical evidence
- present-day relevance

## Weak-case signals
- only slogan value
- no identifiable source point
- no current echo
- too many examples with no anchor
- depends on explanation more than observation

## Common patterns
- One place across time
- One source, multiple later expansions
- One problem, different stages of response
- One ordinary-life entry, one larger governance logic
- One symbolic object as evidence carrier
