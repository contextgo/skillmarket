# Practice Origin Topic Designer

Turn abstract themes into source-grounded editorial plans.

## Included files
- SKILL.md
- agents/openai.yaml
- references/
- MANIFEST.yaml
- CHANGELOG.md
- _meta.json

## Install notes
This bundle is packaged as a standard ZIP with a top-level `practice-origin-topic-designer/` directory so it can be imported by skill installers that expect one skill per archive.
