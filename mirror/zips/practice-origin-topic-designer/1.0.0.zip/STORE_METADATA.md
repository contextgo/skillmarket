# Store Metadata

    ## Listing identity
    - **Display name:** Practice Origin Topic Designer
    - **Slug:** `practice-origin-topic-designer`
    - **Category:** editorial-planning
    - **Short description:** Turn abstract themes into source-grounded editorial plans.
    - **One-line positioning:** Find the real practice origin behind a major theme and turn it into a reportable story spine.

    ## Suggested tags
    - `editorial-planning`
- `major-theme`
- `topic-design`
- `international-communication`
- `governance`
- `source-grounding`

    ## Best-fit queries
    - Design a practice-origin topic plan for a major-theme report on long-term planning.
- Check whether this case is a true source point or just a symbolic example.
- Give me three source-grounded angles for explaining ecological transformation overseas.

    ## Core use cases
    - Turn abstract themes into reportable angles
- Validate whether a case is a true source point
- Build a source-evolution-echo narrative arc

    ## README intro block
    > Practice Origin Topic Designer helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
