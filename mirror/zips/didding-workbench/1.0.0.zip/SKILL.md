---
name: bidding-workbench
description: 结构化解析招标文件，自动生成交互式投标全流程SOP网页工作台，辅助投标人完成从资质准备到文件递交的全流程管理。触发场景：用户上传招标文件要求"解析招标文件生成投标工作台""创建投标SOP""投标全流程辅助"等。
name_cn: AI招投标辅助工作台
description_cn: 解析招标文件，自动生成交互式投标全流程SOP网页，涵盖项目概览、评标分析、风险分析、技术/商务要求、资质准备、人员配置、需求评估、商务报价、文件递交全流程。
---

# AI招投标辅助工作台

## 触发条件

用户上传招标文件（PDF/Word），或要求对招标文件进行投标辅助分析时触发。关键词：招标文件、投标工作台、投标SOP、投标全流程、标书辅助。

## 工作流

### Step 1：获取招标文件

- 用户上传招标文件（PDF/Word）或提供文件路径
- 使用 PDF skill 或 PaddleOCR 或 docx skill 提取文本
- 若招标文件超过50页，优先提取关键章节（评标办法、采购需求、投标人须知、合同条款）

### Step 2：结构化解析招标文件

从提取的文本中解析以下数据：

**2.1 关键元数据**
- `bidNo`: 招标编号
- `purchaser`: 采购人名称
- `budget`: 预算金额（含单位）
- `maxPrice`: 最高限价（总金额）
- `deadline`: 投标截止/开标时间（ISO格式）
- `evalMethod`: 评标办法类型（综合评分法/最低评标价法等）
- `evalDetail`: 评标办法详细说明

**2.2 评分构成**
- `evalScores`: 数组，每项 `{name, score}`，如 `[{name:"商务报价",score:30},{name:"技术方案",score:65},{name:"资信业绩",score:5}]`

**2.3 技术要求**
- `techReqs`: 数组，每项 `{module, requirement, indicator, importance, evalResult, responsible}`
- `module`: 功能模块名称
- `requirement`: 技术要求描述
- `indicator`: 性能指标（如有）
- `importance`: 重要程度（核心/一般/可选）
- `evalResult`/`responsible`: 用户在网页中填写，初始为空

**2.4 商务要求**
- `bizReqs`: 数组，每项 `{name, value}`，字段包含：交付周期、验收标准、质保期、付款方式、培训要求、售后服务、保证金、递交方式等

**2.5 暗标格式规范**
- `darkMarks`: 数组，每项 `{item, requirement, consequence, checked}`
- `item`: 检查项目名称
- `requirement`: 具体格式要求
- `consequence`: 违规后果（默认"否决投标"）

**2.6 风险清单**
- `risks`: 数组，每项 `{type, desc, level, suggestion, status}`
- `type`: 废标风险/评分风险/合规风险/流程陷阱
- `level`: 高/中/低
- `status`: 初始为"待处理"

**2.7 资质准备清单**
- `qualifications`: 数组，每项 `{name, responsible, deliverable, prerequisite, deadline, status, daysBefore}`
- `daysBefore`: 距截止日的天数，网页会自动计算精确到秒的倒推时间
- `status`: 初始为"未开始"
- 典型资质项：营业执照副本、资质证书、业绩证明、财务审计报告、社保证明、税收证明、信用记录、投标保证金、授权委托书等

**2.8 人员配置**
- `personnel`: 数组，每项 `{role, count, requirements, certs, completed, note}`
- `role`: 岗位名称（如项目经理、技术负责人等）
- `requirements`: 数组，人员资质要求列表
- `certs`: 需准备的证书描述
- `completed`: 初始 false

**2.9 报价信息**
- `pricing`: 对象，字段包括 `budget, maxPrice, softwarePrice, hardwarePrice, scoreMethod, priceWeight, deposit, depositMethod, strategy`

**2.10 文件递交流程**
- `deliverySteps`: 数组，每项 `{title, desc}`
- `deliveryChecks`: 数组，每项 `{item, requirement, status}`（初始status为"未完成"）

### Step 3：生成网页

1. 读取模板文件 `assets/workbench-template.html`
2. 将模板内容写入工作空间：`{工作空间}/{项目名称}AI招投标辅助/{项目名称}_投标工作台.html`
3. 用浏览器打开该网页
4. 在浏览器中调用 `injectProjectData(data)` 注入Step 2解析的所有数据

**注入方式**：打开网页后，使用 playwright_browser_evaluate 工具执行：
```javascript
() => { injectProjectData({...parsedData}); }
```

**项目文件夹创建**：用户在网页中点击"新建投标项目"时，需通过 `window.onProjectCreated` 回调在工作空间创建 `{项目名称}AI招投标辅助` 文件夹。在注入数据前先设置该回调：
```javascript
() => { window.onProjectCreated = (name) => { /* 创建文件夹的逻辑 */ }; }
```
实际创建文件夹由智能体在检测到用户操作后执行，而非网页自身操作。

### Step 4：打开并确认

- 用本地HTTP服务器（`python -m http.server`）或直接用浏览器打开HTML文件
- 确认所有模块数据渲染正常
- 向用户说明网页的使用方式

## 网页模块说明

| 一级菜单 | 二级菜单 | 功能 | 数据状态 |
|:---|:---|:---|:---|
| 项目概览 | - | 项目基本信息、进度总览、时间节点 | AI填充 |
| 项目概览 | 评标分析 | 评标办法、评分构成图表、报价评分模拟器 | AI填充 |
| 项目概览 | 风险分析 | 风险清单表格，支持标记处置状态 | AI填充+用户操作 |
| 项目概览 | 技术要求 | 技术参数与建设内容结构化表格 | AI填充 |
| 项目概览 | 商务要求 | 商务条款信息卡+暗标格式规范检查表 | AI填充+用户操作 |
| 投标管理 | 资质准备 | 资质清单，责任方/完成情况可编辑，节点自动倒推 | AI填充+用户操作 |
| 投标管理 | 人员配置 | 人员资质卡片，支持确认+备注（100字内） | AI填充+用户操作 |
| 投标管理 | 需求评估 | 建设内容逐条评估，支持责任人+响应程度选择+导出Excel | AI填充+用户操作 |
| 投标管理 | 商务报价 | 报价信息+限价校验+报价策略 | AI填充 |
| 投标管理 | 文件递交 | 递交流程步骤+递交前检查清单 | AI填充+用户操作 |

## UI规范

- 默认浅蓝风格，支持深浅主题切换
- 所有数据列表必须配备分页功能
- 数据存localStorage，刷新不丢失
- 人员资质提醒用醒目的黄色警告卡片展示
- 金额单位统一用"万元"

