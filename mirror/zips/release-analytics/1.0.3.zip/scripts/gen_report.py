#!/usr/bin/env python3
"""
读取发布数据CSV，生成HTML分析报告。

用法：
  # 单期模式
  python3 gen_report.py --input data.csv --output report.html [--title "报告标题"]

  # 对比模式
  python3 gen_report.py --input_a a.csv --label_a "W12" --input_b b.csv --label_b "W13" --output report.html [--title "报告标题"]

自动检测：
  - 提供 --input_a + --input_b → 对比模式
  - 提供 --input → 单期模式
  - CSV中有"需求Lead Time"列 → 含Lead Time分析（L3）
"""
import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime


def short_mod(m):
    m = m.replace('导航技术中心导航组-', '').replace('导航技术中心-', '').replace('导航-', '')
    m = m.replace('服务架构中心-', '').replace('引擎研发中心引擎后台组-', '').replace('GeoLocation-', '')
    m = m.replace('服务中台-', '')
    return m.lstrip('-')


def parse_args():
    p = argparse.ArgumentParser(description='生成发布分析报告')
    # 单期模式
    p.add_argument('--input', help='单期模式：输入CSV路径')
    # 对比模式
    p.add_argument('--input_a', help='对比模式：A期CSV路径')
    p.add_argument('--label_a', help='对比模式：A期标签（如"W12 3/18-3/24"）')
    p.add_argument('--input_b', help='对比模式：B期CSV路径')
    p.add_argument('--label_b', help='对比模式：B期标签（如"W13 3/25-3/31"）')
    # 公共
    p.add_argument('--output', default='report.html', help='输出HTML路径')
    p.add_argument('--title', default='发布分析', help='报告标题前缀')
    args = p.parse_args()
    if not args.input and not (args.input_a and args.input_b):
        p.error('必须提供 --input（单期）或 --input_a + --input_b（对比）')
    return args


def load_data(csv_path):
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r['_dt'] = datetime.strptime(r['创建时间'], '%Y-%m-%d %H:%M:%S')
        r['_date'] = r['_dt'].strftime('%m/%d')
    return rows


def compute_stats(rows):
    s = {}
    s['total'] = len(rows)
    s['people'] = Counter(r['发布人'] for r in rows)
    s['services'] = Counter(r['发布的服务名称'] for r in rows if r['发布的服务名称'])
    s['no_svc_count'] = sum(1 for r in rows if not r['发布的服务名称'])
    s['modules'] = Counter(r['发布的业务模块'] for r in rows if r['发布的业务模块'])
    s['intents'] = Counter(r['变更意图分类'] for r in rows if r['变更意图分类'])
    s['date_counts'] = Counter(r['_dt'].strftime('%Y-%m-%d') for r in rows)
    s['dates_sorted'] = sorted(s['date_counts'].keys())
    s['min_date'] = min(r['_dt'] for r in rows).strftime('%Y/%m/%d')
    s['max_date'] = max(r['_dt'] for r in rows).strftime('%Y/%m/%d')
    s['min_date_short'] = min(r['_dt'] for r in rows).strftime('%m/%d')
    s['max_date_short'] = max(r['_dt'] for r in rows).strftime('%m/%d')
    s['unique_days'] = len(s['date_counts'])

    # 按模块分行
    s['mod_rows'] = defaultdict(list)
    for r in rows:
        s['mod_rows'][r['发布的业务模块'] or '(未标注模块)'].append(r)
    s['all_mod_counts'] = {k: len(v) for k, v in s['mod_rows'].items()}

    # 人员-模块
    s['person_mod'] = defaultdict(lambda: defaultdict(int))
    s['person_svc'] = defaultdict(lambda: Counter())
    for r in rows:
        s['person_mod'][r['发布人']][r['发布的业务模块'] or '(未标注)'] += 1
        if r['发布的服务名称']:
            s['person_svc'][r['发布人']][r['发布的服务名称']] += 1

    # Lead Time
    s['has_lt'] = any('需求Lead Time' in r for r in rows) and any(r.get('需求Lead Time') for r in rows)
    if s['has_lt']:
        s['no_tapd'] = sum(1 for r in rows if not r.get('需求单'))
        lt_rows = [r for r in rows if r.get('需求Lead Time')]
        s['lt_total'] = len(lt_rows)
        s['n_补录'] = sum(1 for r in lt_rows if '疑似补录' in r.get('Lead Time备注', ''))
        s['n_不规范'] = sum(1 for r in lt_rows if '状态扭转不规范' in r.get('Lead Time备注', ''))
        s['n_待判定'] = sum(1 for r in lt_rows if '待判定' in r.get('Lead Time备注', ''))
        s['n_异常'] = sum(1 for r in lt_rows if r['需求Lead Time'] in ('无权限', '未到达终态'))
        s['n_正常'] = s['n_待判定']  # 待判定视为有效数据（由大模型后续判断）

        # 解析有效LT值（排除补录、无权限、未到达终态），用于计算中位数
        def parse_lt_hours(lt_str):
            """将LT字符串转为小时数"""
            import re
            if not lt_str or lt_str in ('无权限', '未到达终态'):
                return None
            m = re.match(r'(\d+)天(\d+)小时', lt_str)
            if m:
                return int(m.group(1)) * 24 + int(m.group(2))
            m = re.match(r'([\d.]+)小时', lt_str)
            if m:
                return float(m.group(1))
            return None

        valid_hours = []
        for r in lt_rows:
            note = r.get('Lead Time备注', '')
            if '疑似补录' in note or r['需求Lead Time'] in ('无权限', '未到达终态'):
                continue
            h = parse_lt_hours(r['需求Lead Time'])
            if h is not None:
                valid_hours.append(h)

        s['lt_valid_hours'] = sorted(valid_hours)
        s['lt_valid_count'] = len(valid_hours)
        if valid_hours:
            sorted_h = sorted(valid_hours)
            mid = len(sorted_h) // 2
            s['lt_median_hours'] = sorted_h[mid] if len(sorted_h) % 2 else (sorted_h[mid-1] + sorted_h[mid]) / 2
            s['lt_long_tail'] = sum(1 for h in valid_hours if h > 30 * 24)  # >30天
        else:
            s['lt_median_hours'] = 0
            s['lt_long_tail'] = 0

        def fmt_hours(h):
            if h >= 24:
                d = int(h // 24)
                rh = int(h % 24)
                return f'{d}天{rh}小时'
            return f'{h:.1f}小时'
        s['lt_median_str'] = fmt_hours(s['lt_median_hours']) if valid_hours else '无数据'

    return s


# =========== HTML 生成 ===========

COLORS6 = ['blue', 'orange', 'green', 'purple', 'teal', 'gray']
DC = ['#1a73e8', '#e8710a', '#0d904f', '#6c3ae8', '#00897b', '#d93025', '#f5a623', '#9aa0a6']
INTENT_COLORS = {"策略优化": "", "新特性": "green", "AB实验": "orange", "问题修复": "red"}
INTENT_BADGE = {'策略优化': 'badge-blue', '新特性': 'badge-green', 'AB实验': 'badge-orange', '问题修复': 'badge-red'}

CSS = '''
:root{--primary:#1a73e8;--primary-light:#e8f0fe;--success:#0d904f;--success-light:#e6f4ea;--warning:#e37400;--warning-light:#fef7e0;--danger:#d93025;--danger-light:#fce8e6;--gray-50:#f8f9fa;--gray-100:#f1f3f4;--gray-200:#e8eaed;--gray-300:#dadce0;--gray-600:#80868b;--gray-700:#5f6368;--gray-900:#202124;--shadow-sm:0 1px 2px rgba(0,0,0,.06),0 1px 3px rgba(0,0,0,.1);--shadow-md:0 4px 6px rgba(0,0,0,.07),0 2px 4px rgba(0,0,0,.06);--shadow-lg:0 10px 15px rgba(0,0,0,.1),0 4px 6px rgba(0,0,0,.05);--radius:12px}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6;padding:24px}
.container{max-width:1280px;margin:0 auto}
.report-header{background:linear-gradient(135deg,#1a73e8 0%,#4a9af5 50%,#6c3ae8 100%);color:#fff;padding:48px 40px;border-radius:var(--radius);margin-bottom:32px;box-shadow:var(--shadow-lg)}
.report-header h1{font-size:28px;font-weight:700;margin-bottom:8px}
.report-header .subtitle{font-size:16px;opacity:.85}
.report-header .meta{margin-top:20px;display:flex;gap:32px;font-size:14px;opacity:.8;flex-wrap:wrap}
.section{background:#fff;border-radius:var(--radius);padding:32px;margin-bottom:24px;box-shadow:var(--shadow-sm);page-break-before:always}
.section-title{font-size:20px;font-weight:700;margin-bottom:24px;padding-bottom:12px;border-bottom:2px solid var(--gray-200);display:flex;align-items:center;gap:10px}
.section-title .icon{font-size:24px}
h4.sub{font-size:14px;margin-bottom:12px;color:var(--gray-700)}
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:16px;margin-bottom:24px}
.kpi-card{background:var(--gray-50);border-radius:10px;padding:20px;text-align:center;border:1px solid var(--gray-200);transition:transform .15s,box-shadow .15s}
.kpi-card:hover{transform:translateY(-2px);box-shadow:var(--shadow-md)}
.kpi-value{font-size:36px;font-weight:800;color:var(--primary)}
.kpi-value.green{color:var(--success)}.kpi-value.orange{color:var(--warning)}.kpi-value.red{color:var(--danger)}.kpi-value.gray{color:var(--gray-600)}
.kpi-label{font-size:13px;color:var(--gray-700);margin-top:4px}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}
@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600}
.badge-blue{background:var(--primary-light);color:var(--primary)}.badge-green{background:var(--success-light);color:var(--success)}.badge-orange{background:var(--warning-light);color:var(--warning)}.badge-red{background:var(--danger-light);color:var(--danger)}.badge-gray{background:var(--gray-100);color:var(--gray-700)}
.data-table{width:100%;border-collapse:collapse;font-size:13px}
.data-table th{background:var(--gray-100);padding:10px 12px;text-align:left;font-weight:600;font-size:12px;color:var(--gray-700);border-bottom:2px solid var(--gray-300);white-space:nowrap}
.data-table td{padding:10px 12px;border-bottom:1px solid var(--gray-200);vertical-align:top}
.data-table tbody tr:hover{background:var(--gray-50)}
.data-table .text-right{text-align:right}.data-table .text-center{text-align:center}
.bar-chart{margin:16px 0}.bar-row{display:flex;align-items:center;margin-bottom:8px}
.bar-label{width:180px;font-size:12px;color:var(--gray-700);flex-shrink:0;text-align:right;padding-right:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bar-track{flex:1;background:var(--gray-100);border-radius:6px;height:26px;overflow:hidden}
.bar-fill{height:100%;border-radius:6px;display:flex;align-items:center;padding-left:10px;color:#fff;font-size:12px;font-weight:600;min-width:fit-content}
.bar-fill.blue{background:linear-gradient(90deg,#1a73e8,#4a9af5)}.bar-fill.orange{background:linear-gradient(90deg,#e8710a,#f5a623)}.bar-fill.green{background:linear-gradient(90deg,#0d904f,#34a853)}.bar-fill.purple{background:linear-gradient(90deg,#6c3ae8,#9d6df5)}.bar-fill.teal{background:linear-gradient(90deg,#00897b,#26a69a)}.bar-fill.gray{background:linear-gradient(90deg,#5f6368,#9aa0a6)}
.donut-wrap{display:flex;align-items:center;gap:24px;margin:16px 0}
.donut{width:140px;height:140px;border-radius:50%;position:relative;flex-shrink:0}
.donut-center{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:28px;font-weight:800}
.donut-legend{font-size:13px}.donut-legend-item{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.donut-dot{width:12px;height:12px;border-radius:3px;flex-shrink:0}
.insight-card{background:var(--primary-light);border-left:4px solid var(--primary);padding:16px 20px;border-radius:0 10px 10px 0;margin-bottom:12px}
.insight-card.warning{background:var(--warning-light);border-left-color:var(--warning)}
.insight-card.danger{background:var(--danger-light);border-left-color:var(--danger)}
.insight-card.success{background:var(--success-light);border-left-color:var(--success)}
.insight-card .insight-title{font-size:14px;font-weight:700;margin-bottom:4px}
.insight-card .insight-body{font-size:13px;color:var(--gray-700)}
.risk-tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.risk-high{background:var(--danger-light);color:var(--danger)}.risk-mid{background:var(--warning-light);color:var(--warning)}.risk-low{background:var(--success-light);color:var(--success)}
.report-footer{text-align:center;padding:24px;font-size:12px;color:var(--gray-600)}
@media(max-width:600px){body{padding:12px}.report-header{padding:28px 20px}.report-header h1{font-size:22px}.section{padding:20px}.kpi-grid{grid-template-columns:repeat(2,1fr)}}
'''


def build_bar(items, max_val):
    return '\n'.join(
        f'<div class="bar-row"><div class="bar-label">{name}</div>'
        f'<div class="bar-track"><div class="bar-fill {COLORS6[i % 6]}" style="width:{cnt / max_val * 100:.0f}%">{cnt}次</div></div></div>'
        for i, (name, cnt) in enumerate(items)
    )


def build_donut(mod_counts, total):
    pct_s = 0
    conic = []
    legend = []
    for i, (m, cnt) in enumerate(sorted(mod_counts.items(), key=lambda x: -x[1])):
        pct = cnt / total * 100
        c = DC[i % len(DC)]
        conic.append(f'{c} {pct_s:.1f}% {pct_s + pct:.1f}%')
        pct_s += pct
        legend.append(f'<div class="donut-legend-item"><div class="donut-dot" style="background:{c}"></div>'
                      f'<span>{short_mod(m)} — {cnt}次（{pct:.0f}%）</span></div>')
    return ', '.join(conic), '\n'.join(legend)


def gen_cadence_insight(s):
    """动态生成节奏洞察"""
    dc = s['date_counts']
    ds = s['dates_sorted']
    total = s['total']
    peak_day = max(dc, key=dc.get)
    peak_cnt = dc[peak_day]
    peak_pct = peak_cnt / total * 100

    # 找高峰日（>=4次或最大）
    hot_days = [(d, dc[d]) for d in ds if dc[d] >= max(4, peak_cnt * 0.8)]
    hot_str = '、'.join(f'{d[5:]}（{c}次）' for d, c in hot_days) if hot_days else f'{peak_day[5:]}（{peak_cnt}次）'

    # 找低谷日
    cold_days = [(d, dc[d]) for d in ds if dc[d] <= max(1, peak_cnt * 0.2)]
    cold_str = '、'.join(f'{d[5:]}（{c}次）' for d, c in cold_days) if cold_days else '无明显低谷'

    # 是否有周末
    from datetime import datetime as dt
    weekends = [d for d in ds if dt.strptime(d, '%Y-%m-%d').weekday() >= 5]
    weekend_str = '有周末发布' if weekends else '无周末发布'

    # 前半/后半对比
    mid = len(ds) // 2
    first_half = sum(dc[d] for d in ds[:mid])
    second_half = sum(dc[d] for d in ds[mid:])
    if second_half > first_half * 1.5:
        trend = '后半段发布密度明显高于前半段，呈加速趋势'
    elif first_half > second_half * 1.5:
        trend = '前半段发布密度高于后半段，呈收敛趋势'
    else:
        trend = '发布节奏相对均匀'

    return (f'本次统计周期（{s["min_date_short"]}—{s["max_date_short"]}）共 <strong>{total}次发布</strong>，'
            f'跨{s["unique_days"]}个活跃天。'
            f'发布高峰日：{hot_str}。低谷日：{cold_str}。{weekend_str}。{trend}。')


def gen_intent_insight(intents, total):
    """动态生成变更意图洞察"""
    parts = []
    for intent, cnt in intents.most_common():
        pct = cnt / total * 100
        parts.append(f'<strong>{intent}</strong> {cnt}次（{pct:.0f}%）')
    top = intents.most_common(1)[0] if intents else ('无', 0)
    return f'变更意图分布：{" · ".join(parts)}。其中 <strong>{top[0]}</strong> 占比最高。'


def gen_team_insight(ppl_sorted, total):
    """动态生成团队洞察"""
    top4 = ppl_sorted[:4]
    top4_cnt = sum(c for _, c in top4)
    top4_pct = top4_cnt / total * 100
    top4_names = '、'.join(p for p, _ in top4)
    one_release = sum(1 for _, c in ppl_sorted if c == 1)
    return (f'Top {min(4, len(top4))} 发布人（{top4_names}）合计 '
            f'<strong>{top4_cnt}次（{top4_pct:.0f}%）</strong>。'
            f'{len(ppl_sorted)}人中有 <strong>{one_release}人仅发布1次</strong>。')


def gen_lt_insight(s):
    """动态生成Lead Time洞察"""
    lt_total = s['lt_total']
    return (f'{lt_total}条有TAPD链接的发布中，'
            f'<strong>{s["n_补录"]}条（{s["n_补录"] / max(lt_total, 1) * 100:.0f}%）疑似补录</strong>（Lead Time < 1小时），'
            f'{s["n_不规范"]}条状态扭转不规范。'
            f'仅 <strong>{s["n_正常"]}条（{s["n_正常"] / max(lt_total, 1) * 100:.0f}%）</strong> 为正常可信数据。'
            f'建议推行 TAPD 状态实时更新规范。')


def gen_summary_good(s):
    """动态生成正面总结"""
    intents = s['intents']
    intent_total = sum(intents.values())
    top_intent = intents.most_common(1)[0] if intents else ('无', 0)
    lines = []
    lines.append(f'<strong>1. 发布参与度高</strong>：{len(s["people"])}人参与发布，覆盖{len(s["modules"])}个业务模块，团队整体在交付状态。')
    lines.append(f'<strong>2. 发布节奏集中</strong>：{s["unique_days"]}天完成{s["total"]}次发布，执行效率高。')
    if top_intent[0] == '策略优化':
        lines.append(f'<strong>3. 变更以优化为主</strong>：{top_intent[0]}占{top_intent[1] / max(intent_total, 1) * 100:.0f}%，团队在持续打磨已有能力。')
    else:
        lines.append(f'<strong>3. 变更方向明确</strong>：{top_intent[0]}占{top_intent[1] / max(intent_total, 1) * 100:.0f}%。')
    lines.append(f'<strong>4. 服务覆盖广</strong>：涉及{len(s["services"])}个服务，多技术方向同步推进。')
    return '<br>\n'.join(lines)


def gen_summary_bad(s):
    """动态生成负面总结"""
    lines = []
    if s.get('has_lt'):
        lines.append(f'<strong>1. TAPD状态补录严重</strong>：{s["n_补录"]}条（{s["n_补录"] / max(s["lt_total"], 1) * 100:.0f}%）疑似补录，研发过程数据失真。')
        no_tapd = s.get('no_tapd', 0)
        lines.append(f'<strong>2. {no_tapd / s["total"] * 100:.0f}%发布无TAPD链接</strong>：{no_tapd}条发布缺少需求关联。')

    # 单点风险
    sp = []
    for m in s['modules']:
        pp = [p for p in s['people'] if s['person_mod'][p].get(m, 0) > 0]
        if len(pp) == 1:
            sp.append((short_mod(m), pp[0]))
    if sp:
        lines.append(f'<strong>{len(lines) + 1}. 部分模块单点风险</strong>：{len(sp)}个模块仅1人发布。')

    # 日峰值
    peak = max(s['date_counts'].values())
    if peak >= 10:
        lines.append(f'<strong>{len(lines) + 1}. 单日发布峰值高</strong>：单日最多{peak}次发布，建议控制节奏降低风险。')

    if not lines:
        lines.append('暂未发现明显问题。')
    return '<br>\n'.join(lines)


def gen_suggestions(s):
    """动态生成改进建议"""
    rows_html = ''
    idx = 0
    if s.get('has_lt') and s['n_补录'] > 0:
        idx += 1
        rows_html += f'<tr><td><span class="risk-tag risk-high">P0</span></td><td>推行TAPD状态实时更新规范，禁止事后批量补录</td><td>Lead Time可信率从{s["n_正常"] / max(s["lt_total"], 1) * 100:.0f}%提升至80%+</td></tr>\n'
    if s.get('no_tapd', 0) > 0:
        idx += 1
        pct = (s['total'] - s['no_tapd']) / s['total'] * 100
        rows_html += f'<tr><td><span class="risk-tag risk-high">P0</span></td><td>所有发布必须关联TAPD需求单</td><td>可统计率从{pct:.0f}%提升至95%+</td></tr>\n'
    # 单点风险
    sp_count = 0
    for m in s['modules']:
        pp = [p for p in s['people'] if s['person_mod'][p].get(m, 0) > 0]
        if len(pp) == 1:
            sp_count += 1
    if sp_count:
        rows_html += f'<tr><td><span class="risk-tag risk-mid">P1</span></td><td>建立跨模块backup机制，每人至少熟悉1个非主责模块</td><td>消除{sp_count}个单点风险模块</td></tr>\n'
    peak = max(s['date_counts'].values())
    if peak >= 10:
        rows_html += f'<tr><td><span class="risk-tag risk-low">P2</span></td><td>发布节奏均匀化，避免单日超过10次发布</td><td>降低发布高峰日的线上风险</td></tr>\n'
    return rows_html


def generate_html(rows, s, title_prefix):
    total = s['total']
    now_str = datetime.now().strftime('%Y/%m/%d')

    # 环形图
    conic_str, legend_html = build_donut(s['all_mod_counts'], total)

    # 服务条形图
    svc_sorted = s['services'].most_common(12)
    svc_bars = build_bar(svc_sorted, svc_sorted[0][1]) if svc_sorted else ''

    # 人员条形图
    ppl_sorted = s['people'].most_common()
    ppl_bars = build_bar(ppl_sorted, ppl_sorted[0][1]) if ppl_sorted else ''

    # 每日表格
    dc = s['date_counts']
    peak_cnt = max(dc.values())
    daily_trs = ''
    for d in s['dates_sorted']:
        c = dc[d]
        pct = c / total * 100
        bw = c / peak_cnt * 100
        daily_trs += (f'<tr><td>{d[5:]}</td><td class="text-center"><strong>{c}</strong></td>'
                      f'<td><div style="background:var(--primary-light);border-radius:4px;height:20px;'
                      f'width:{bw:.0f}%;display:inline-block;vertical-align:middle;margin-right:8px"></div>{pct:.0f}%</td></tr>\n')

    # 意图KPI
    intent_total = sum(s['intents'].values()) or 1
    intent_kpis = '\n'.join(
        f'<div class="kpi-card"><div class="kpi-value {INTENT_COLORS.get(k, "gray")}">{v}</div>'
        f'<div class="kpi-label">{k}（{v / intent_total * 100:.0f}%）</div></div>'
        for k, v in s['intents'].most_common()
    )

    # 模块明细
    mod_sections = ''
    for mod in sorted(s['all_mod_counts'].keys(), key=lambda x: -s['all_mod_counts'][x]):
        ml = s['mod_rows'][mod]
        cnt = len(ml)
        mi = Counter(r['变更意图分类'] for r in ml if r['变更意图分类'])
        ms = set(r['发布的服务名称'] for r in ml if r['发布的服务名称'])
        mp = set(r['发布人'] for r in ml)
        trs = '\n'.join(
            f'<tr><td>{r["发布标题"][:40]}</td><td style="font-size:11px">{r["发布的服务名称"] or "-"}</td>'
            f'<td><span class="badge {INTENT_BADGE.get(r["变更意图分类"], "badge-gray")}">{r["变更意图分类"] or "-"}</span></td>'
            f'<td>{r["发布人"]}</td><td>{r["_date"]}</td>'
            f'<td style="font-size:11px;max-width:200px;word-break:break-all">{(r.get("发布详情","") or "-")[:80]}</td></tr>'
            for r in sorted(ml, key=lambda x: x['_dt'])
        )
        ti = mi.most_common(1)[0] if mi else ('-', 0)
        mod_sections += (
            f'<div style="background:var(--gray-50);border-radius:10px;padding:20px;margin-bottom:16px;border:1px solid var(--gray-200);">'
            f'<h4 style="font-size:15px;margin-bottom:12px;"><span class="badge badge-blue">{short_mod(mod)}</span> '
            f'{cnt}次发布 · {len(mp)}人 · {len(ms)}个服务</h4>'
            f'<table class="data-table"><thead><tr><th>发布标题</th><th>服务</th><th>意图</th><th>发布人</th><th>日期</th><th>发布详情</th></tr></thead>'
            f'<tbody>{trs}</tbody></table>'
            f'<div class="insight-card success" style="margin-top:12px;"><div class="insight-body">'
            f'主要变更意图：<strong>{ti[0]}</strong>（{ti[1]}次），涉及服务：{", ".join(ms) if ms else "无服务记录"}</div></div></div>\n'
        )

    # 人员-模块矩阵
    display_mods = sorted(s['all_mod_counts'].keys(), key=lambda x: -s['all_mod_counts'][x])
    mh = ''.join(f'<th class="text-center" style="font-size:11px">{short_mod(m)}</th>' for m in display_mods)
    matrix = ''
    for p, cnt in ppl_sorted:
        cells = ''.join(f'<td class="text-center">{s["person_mod"][p].get(m, 0) or ""}</td>' for m in display_mods)
        ts = s['person_svc'][p].most_common(1)[0][0] if s['person_svc'][p] else '-'
        matrix += f'<tr><td><strong>{p}</strong></td>{cells}<td style="font-size:11px">{ts}</td></tr>\n'

    # 单点风险
    sp_html = ''
    sp_mods = []
    for m in s['modules']:
        pp = [p for p in s['people'] if s['person_mod'][p].get(m, 0) > 0]
        if len(pp) == 1:
            sp_mods.append((short_mod(m), pp[0]))
    if sp_mods:
        sp_text = '、'.join(f'{m}（仅{p}）' for m, p in sp_mods)
        sp_html = (f'<div class="insight-card warning" style="margin-top:16px;">'
                   f'<div class="insight-title">单点风险</div>'
                   f'<div class="insight-body">以下模块仅有1人发布：{sp_text}。建议建立跨模块backup机制。</div></div>')

    # Lead Time 章节
    lt_section = ''
    if s.get('has_lt'):
        lt_trs = ''
        for r in rows:
            lt = r.get('需求Lead Time', '')
            if not lt:
                continue
            note = r.get('Lead Time备注', '')
            mod_s = short_mod(r['发布的业务模块']) if r['发布的业务模块'] else '-'
            if '疑似补录' in note:
                lt_trs += (f'<tr style="color:var(--gray-600)"><td>{r["_date"]}</td><td>{r["发布标题"][:35]}</td>'
                           f'<td>{mod_s}</td><td class="text-right" style="text-decoration:line-through">{lt}</td>'
                           f'<td><span class="risk-tag risk-mid">疑似补录</span></td></tr>\n')
            elif '状态扭转不规范' in note:
                lt_trs += (f'<tr><td>{r["_date"]}</td><td>{r["发布标题"][:35]}</td><td>{mod_s}</td>'
                           f'<td class="text-right"><strong>{lt}</strong></td>'
                           f'<td><span class="risk-tag risk-mid">状态扭转不规范</span></td></tr>\n')
            elif lt in ('无权限', '未到达终态'):
                lt_trs += (f'<tr style="color:var(--gray-600)"><td>{r["_date"]}</td><td>{r["发布标题"][:35]}</td>'
                           f'<td>{mod_s}</td><td class="text-right">{lt}</td><td>{note}</td></tr>\n')
            else:
                lt_trs += (f'<tr><td>{r["_date"]}</td><td>{r["发布标题"][:35]}</td><td>{mod_s}</td>'
                           f'<td class="text-right"><strong>{lt}</strong></td><td>{note}</td></tr>\n')

        lt_section = f'''
<div class="section">
  <div class="section-title"><span class="icon">⏱️</span> 五、研发效能分析（Lead Time）</div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-value">{s["lt_total"]}</div><div class="kpi-label">有TAPD链接</div></div>
    <div class="kpi-card"><div class="kpi-value green">{s["n_正常"]}</div><div class="kpi-label">正常可信</div></div>
    <div class="kpi-card"><div class="kpi-value red">{s["n_补录"]}</div><div class="kpi-label">疑似补录</div></div>
    <div class="kpi-card"><div class="kpi-value orange">{s["n_不规范"]}</div><div class="kpi-label">状态扭转不规范</div></div>
    <div class="kpi-card"><div class="kpi-value gray">{s.get("no_tapd", 0)}</div><div class="kpi-label">无TAPD链接</div></div>
  </div>
  <h4 class="sub">Lead Time 明细</h4>
  <table class="data-table" style="margin-bottom:24px">
    <thead><tr><th>日期</th><th>发布标题</th><th>模块</th><th class="text-right">Lead Time</th><th>备注</th></tr></thead>
    <tbody>{lt_trs}</tbody>
  </table>
  <p style="font-size:11px;color:var(--gray-600);margin-bottom:16px">* 删除线标记为疑似补录，Lead Time不反映真实研发耗时</p>
  <div class="insight-card warning">
    <div class="insight-title">Lead Time 洞察</div>
    <div class="insight-body">{gen_lt_insight(s)}</div>
  </div>
</div>'''

    # 附录
    app_rows = ''
    for i, r in enumerate(sorted(rows, key=lambda x: x['_dt']), 1):
        ib = INTENT_BADGE.get(r.get('变更意图分类', ''), 'badge-gray')
        mod_s = short_mod(r['发布的业务模块']) if r['发布的业务模块'] else '-'
        lt_val = r.get('需求Lead Time', '-') or '-'
        detail_val = r.get('发布详情', '') or ''
        # 截断过长的详情，附录中最多显示80字符
        detail_display = (detail_val[:80] + '...') if len(detail_val) > 80 else detail_val
        detail_display = detail_display or '-'
        app_rows += (f'<tr><td>{i}</td><td>{r["_date"]}</td><td style="font-size:11px">{r.get("发布审批单类型", "-")}</td><td>{r["发布标题"][:40]}</td><td>{r["发布人"]}</td>'
                     f'<td style="font-size:11px">{r["发布类型"][:15]}</td>'
                     f'<td style="font-size:11px">{r["发布的服务名称"] or "-"}</td>'
                     f'<td style="font-size:11px">{mod_s}</td><td>{r.get("发布地域", "") or "-"}</td>'
                     f'<td><span class="badge {ib}">{r.get("变更意图分类", "") or "-"}</span></td>'
                     f'<td style="font-size:11px">{lt_val}</td>'
                     f'<td style="font-size:11px">{r.get("Lead Time备注", "") or "-"}</td>'
                     f'<td style="font-size:11px;max-width:200px;word-break:break-all">{detail_display}</td></tr>\n')

    # 章节编号（L3有Lead Time章节插在第五章，总结变为第六章）
    summary_num = '六' if s.get('has_lt') else '五'
    appendix_num = '七' if s.get('has_lt') else '六'

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title_prefix} — 发布变更分析报告</title>
<style>{CSS}</style>
</head>
<body>
<div class="container">

<div class="report-header">
  <h1>{title_prefix} — 发布变更分析报告</h1>
  <div class="subtitle">对{s["min_date_short"]}—{s["max_date_short"]}所有发布记录的全维度分析：发布节奏、变更方向、团队贡献、研发效能与改进建议</div>
  <div class="meta">
    <span>统计周期：{s["min_date"]} — {s["max_date"]}</span>
    <span>发布记录：{total}条</span>
    <span>报告生成：{now_str}</span>
  </div>
</div>

<div class="section" style="page-break-before:avoid">
  <div class="section-title"><span class="icon">📊</span> 一、全局概览</div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-value">{total}</div><div class="kpi-label">总发布次数</div></div>
    <div class="kpi-card"><div class="kpi-value green">{len(s["services"])}</div><div class="kpi-label">涉及服务数</div></div>
    <div class="kpi-card"><div class="kpi-value orange">{len(s["people"])}</div><div class="kpi-label">参与人数</div></div>
    <div class="kpi-card"><div class="kpi-value">{s["unique_days"]}</div><div class="kpi-label">活跃发布天数</div></div>
    <div class="kpi-card"><div class="kpi-value gray">{len(s["modules"])}</div><div class="kpi-label">业务模块数</div></div>
  </div>
  <div class="two-col">
    <div>
      <h4 class="sub">按业务模块分布</h4>
      <div class="donut-wrap">
        <div class="donut" style="background:conic-gradient({conic_str})"><div class="donut-center">{total}</div></div>
        <div class="donut-legend">{legend_html}</div>
      </div>
    </div>
    <div>
      <h4 class="sub">按服务分布（共{len(s["services"])}个）</h4>
      <div class="bar-chart">{svc_bars}</div>
      <p style="font-size:11px;color:#8e8e93;margin-top:8px">💡 注：仅统计携带服务名称的发布（{sum(s["services"].values())}条），另有{s["no_svc_count"]}条发布无服务名称（变更助手单和TKEX交付流部署单不携带此字段）</p>
    </div>
  </div>
</div>

<div class="section">
  <div class="section-title"><span class="icon">📅</span> 二、发布节奏分析</div>
  <div class="two-col">
    <div>
      <h4 class="sub">每日发布次数</h4>
      <table class="data-table">
        <thead><tr><th>日期</th><th class="text-center">次数</th><th>占比</th></tr></thead>
        <tbody>{daily_trs}</tbody>
      </table>
    </div>
    <div>
      <h4 class="sub">每日发布趋势</h4>
      <div style="position:relative;height:300px"><canvas id="dailyChart"></canvas></div>
      <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
      <script>
      new Chart(document.getElementById('dailyChart'),{{
        type:'bar',
        data:{{labels:{json.dumps([d[5:].replace('-', '/') for d in s['dates_sorted']])},
               datasets:[{{label:'发布次数',data:{json.dumps([dc[d] for d in s['dates_sorted']])},
                           backgroundColor:'rgba(26,115,232,0.7)',borderRadius:6}}]}},
        options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{display:false}}}},
                 scales:{{x:{{grid:{{display:false}}}},y:{{beginAtZero:true,ticks:{{stepSize:2}}}}}}}}
      }});
      </script>
    </div>
  </div>
  <div class="insight-card" style="margin-top:16px">
    <div class="insight-title">节奏观察</div>
    <div class="insight-body">{gen_cadence_insight(s)}</div>
  </div>
</div>

<div class="section">
  <div class="section-title"><span class="icon">🧭</span> 三、变更方向分析</div>
  <h4 class="sub">3.1 变更意图总览</h4>
  <div class="kpi-grid" style="grid-template-columns:repeat({min(len(s['intents']), 5)},1fr)">{intent_kpis}</div>
  <div class="insight-card">
    <div class="insight-title">变更意图分布</div>
    <div class="insight-body">{gen_intent_insight(s['intents'], intent_total)}</div>
  </div>
  <h4 class="sub" style="margin-top:24px">3.2 按业务模块拆解</h4>
  {mod_sections}
</div>

<div class="section">
  <div class="section-title"><span class="icon">👥</span> 四、团队贡献分析</div>
  <div class="two-col">
    <div>
      <h4 class="sub">按人发布次数</h4>
      <div class="bar-chart">{ppl_bars}</div>
    </div>
    <div>
      <h4 class="sub">发布负载分布</h4>
      <div class="kpi-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="kpi-card"><div class="kpi-value">{len(s["people"])}</div><div class="kpi-label">参与人数</div></div>
        <div class="kpi-card"><div class="kpi-value green">{ppl_sorted[0][1]}</div><div class="kpi-label">最多（{ppl_sorted[0][0]}）</div></div>
        <div class="kpi-card"><div class="kpi-value gray">{ppl_sorted[-1][1]}</div><div class="kpi-label">最少发布</div></div>
      </div>
      <div class="insight-card" style="margin-top:16px">
        <div class="insight-title">负载分布观察</div>
        <div class="insight-body">{gen_team_insight(ppl_sorted, total)}</div>
      </div>
    </div>
  </div>
  <h4 class="sub" style="margin-top:24px">人员-模块矩阵</h4>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>发布人</th>{mh}<th>主负责服务</th></tr></thead>
    <tbody>{matrix}</tbody>
  </table>
  </div>
  {sp_html}
</div>

{lt_section}

<div class="section">
  <div class="section-title"><span class="icon">📋</span> {summary_num}、总结与建议</div>
  <div class="two-col">
    <div>
      <h4 style="font-size:14px;margin-bottom:12px;color:var(--success)">✅ 做得好的地方</h4>
      <div class="insight-card success"><div class="insight-body">{gen_summary_good(s)}</div></div>
    </div>
    <div>
      <h4 style="font-size:14px;margin-bottom:12px;color:var(--danger)">⚠️ 需要改进的地方</h4>
      <div class="insight-card danger"><div class="insight-body">{gen_summary_bad(s)}</div></div>
    </div>
  </div>
  <h4 class="sub" style="margin-top:24px">改进建议优先级</h4>
  <table class="data-table">
    <thead><tr><th>优先级</th><th>建议</th><th>预期效果</th></tr></thead>
    <tbody>{gen_suggestions(s)}</tbody>
  </table>
</div>

<div class="section">
  <div class="section-title"><span class="icon">📎</span> {appendix_num}、附录：完整发布记录明细</div>
  <div style="overflow-x:auto">
  <table class="data-table" style="font-size:12px">
    <thead><tr><th>#</th><th>日期</th><th>发布审批单类型</th><th>发布标题</th><th>发布人</th><th>类型</th><th>服务</th><th>模块</th><th>地域</th><th>意图</th><th>Lead Time</th><th>LT备注</th><th>发布详情</th></tr></thead>
    <tbody>{app_rows}</tbody>
  </table>
  </div>
</div>

<div class="report-footer">
  {title_prefix} — 发布变更分析报告 | 数据来源：智研发布平台 + TAPD | 生成时间：{now_str}
</div>

</div>
</body>
</html>'''
    return html


def _delta_str(a, b, unit='', is_pct=False):
    """生成变化量字符串"""
    diff = b - a
    if a == 0:
        return f'<span style="color:var(--gray-600)">—</span>'
    pct = diff / a * 100
    if diff > 0:
        arrow = '↑'
        color = 'var(--success)' if not is_pct else 'var(--success)'
    elif diff < 0:
        arrow = '↓'
        color = 'var(--danger)'
    else:
        return f'<span style="color:var(--gray-600)">持平</span>'
    return f'<span style="color:{color};font-weight:700">{arrow}{abs(diff)}{unit}（{abs(pct):.0f}%）</span>'


def _compare_kpi(label, va, vb, unit=''):
    """生成对比KPI卡片"""
    delta = _delta_str(va, vb, unit)
    return (f'<div class="kpi-card">'
            f'<div style="font-size:14px;color:var(--gray-700);margin-bottom:8px">{label}</div>'
            f'<div style="display:flex;justify-content:center;align-items:baseline;gap:12px">'
            f'<span style="font-size:20px;color:var(--gray-600)">{va}{unit}</span>'
            f'<span style="font-size:16px">→</span>'
            f'<span style="font-size:24px;font-weight:800;color:var(--primary)">{vb}{unit}</span>'
            f'</div>'
            f'<div style="margin-top:6px">{delta}</div>'
            f'</div>')


def generate_compare_html(rows_a, rows_b, sa, sb, label_a, label_b, title_prefix):
    """生成对比模式HTML"""
    now_str = datetime.now().strftime('%Y/%m/%d')
    ta, tb = sa['total'], sb['total']

    # ========== Header ==========
    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title_prefix} — 发布变更对比分析报告</title>
<style>{CSS}
.compare-grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
@media(max-width:768px){{.compare-grid{{grid-template-columns:1fr}}}}
.period-tag{{display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600}}
.period-a{{background:#e8f0fe;color:#1a73e8}}
.period-b{{background:#e6f4ea;color:#0d904f}}
</style>
</head>
<body>
<div class="container">

<div class="report-header">
  <h1>{title_prefix} — 发布变更对比分析报告</h1>
  <div class="subtitle"><span class="period-tag period-a" style="background:rgba(255,255,255,.2);color:#fff">{label_a}</span> vs <span class="period-tag period-b" style="background:rgba(255,255,255,.2);color:#fff">{label_b}</span></div>
  <div class="meta">
    <span>A期：{sa["min_date"]} — {sa["max_date"]}（{ta}条）</span>
    <span>B期：{sb["min_date"]} — {sb["max_date"]}（{tb}条）</span>
    <span>报告生成：{now_str}</span>
  </div>
</div>
'''

    # ========== 第一章：全局概览对比 ==========
    html += f'''
<div class="section" style="page-break-before:avoid">
  <div class="section-title"><span class="icon">📊</span> 一、全局概览（{label_a} vs {label_b}）</div>
  <div class="kpi-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
    {_compare_kpi("总发布次数", ta, tb, "次")}
    {_compare_kpi("涉及服务数", len(sa["services"]), len(sb["services"]), "个")}
    {_compare_kpi("参与人数", len(sa["people"]), len(sb["people"]), "人")}
    {_compare_kpi("活跃天数", sa["unique_days"], sb["unique_days"], "天")}
    {_compare_kpi("业务模块数", len(sa["modules"]), len(sb["modules"]), "个")}
  </div>
  <div class="compare-grid">
    <div>
      <h4 class="sub"><span class="period-tag period-a">{label_a}</span> 模块分布</h4>
      <div class="donut-wrap">
        <div class="donut" style="background:conic-gradient({build_donut(sa["all_mod_counts"], ta)[0]})"><div class="donut-center">{ta}</div></div>
        <div class="donut-legend">{build_donut(sa["all_mod_counts"], ta)[1]}</div>
      </div>
    </div>
    <div>
      <h4 class="sub"><span class="period-tag period-b">{label_b}</span> 模块分布</h4>
      <div class="donut-wrap">
        <div class="donut" style="background:conic-gradient({build_donut(sb["all_mod_counts"], tb)[0]})"><div class="donut-center">{tb}</div></div>
        <div class="donut-legend">{build_donut(sb["all_mod_counts"], tb)[1]}</div>
      </div>
    </div>
  </div>
  <h4 class="sub" style="margin-top:24px">按服务分布对比</h4>
  <table class="data-table">
    <thead><tr><th>服务</th><th class="text-center">{label_a}</th><th class="text-center">{label_b}</th><th>变化</th></tr></thead>
    <tbody>'''

    # 服务对比表
    all_svcs = sorted(set(list(sa['services'].keys()) + list(sb['services'].keys())),
                      key=lambda x: -(sa['services'].get(x, 0) + sb['services'].get(x, 0)))
    for svc in all_svcs[:15]:
        ca = sa['services'].get(svc, 0)
        cb = sb['services'].get(svc, 0)
        html += f'<tr><td style="font-size:12px">{svc}</td><td class="text-center">{ca or "-"}</td><td class="text-center">{cb or "-"}</td><td>{_delta_str(ca, cb, "次") if ca and cb else ("🆕" if ca == 0 else "")}</td></tr>\n'

    html += f'''</tbody>
  </table>
  <p style="font-size:11px;color:#8e8e93;margin-top:8px">💡 注：仅统计携带服务名称的发布（A期{sum(sa["services"].values())}条，B期{sum(sb["services"].values())}条），部分发布无服务名称（变更助手单和TKEX交付流部署单不携带此字段）</p>
</div>
'''
    all_dates = sorted(set(sa['dates_sorted'] + sb['dates_sorted']))
    chart_labels = json.dumps([d[5:].replace('-', '/') for d in all_dates])
    chart_data_a = json.dumps([sa['date_counts'].get(d, 0) for d in all_dates])
    chart_data_b = json.dumps([sb['date_counts'].get(d, 0) for d in all_dates])

    # 按期间汇总表
    daily_compare = ''
    for d in all_dates:
        ca = sa['date_counts'].get(d, 0)
        cb = sb['date_counts'].get(d, 0)
        period = f'<span class="period-tag period-a">A</span>' if d in sa['date_counts'] else ''
        period += f' <span class="period-tag period-b">B</span>' if d in sb['date_counts'] else ''
        daily_compare += f'<tr><td>{d[5:]}</td><td class="text-center">{ca or "-"}</td><td class="text-center">{cb or "-"}</td><td>{period}</td></tr>\n'
    # 周小计
    avg_a = ta / max(sa['unique_days'], 1)
    avg_b = tb / max(sb['unique_days'], 1)

    html += f'''
<div class="section">
  <div class="section-title"><span class="icon">📅</span> 二、发布节奏对比</div>
  <div class="two-col">
    <div>
      <h4 class="sub">每日发布次数</h4>
      <table class="data-table">
        <thead><tr><th>日期</th><th class="text-center">{label_a}</th><th class="text-center">{label_b}</th><th>期间</th></tr></thead>
        <tbody>{daily_compare}
        <tr style="font-weight:700;border-top:2px solid var(--gray-300)">
          <td>合计</td><td class="text-center">{ta}</td><td class="text-center">{tb}</td><td>{_delta_str(ta, tb, "次")}</td>
        </tr>
        <tr style="color:var(--gray-600)">
          <td>日均</td><td class="text-center">{avg_a:.1f}</td><td class="text-center">{avg_b:.1f}</td><td>{_delta_str(avg_a, avg_b)}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <div>
      <h4 class="sub">发布趋势（双线对比）</h4>
      <div style="position:relative;height:300px"><canvas id="compareChart"></canvas></div>
      <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
      <script>
      new Chart(document.getElementById('compareChart'),{{
        type:'bar',
        data:{{labels:{chart_labels},
               datasets:[
                 {{label:'{label_a}',data:{chart_data_a},backgroundColor:'rgba(26,115,232,0.6)',borderRadius:4}},
                 {{label:'{label_b}',data:{chart_data_b},backgroundColor:'rgba(13,144,79,0.6)',borderRadius:4}}
               ]}},
        options:{{responsive:true,maintainAspectRatio:false,
                 plugins:{{legend:{{position:'top'}}}},
                 scales:{{x:{{grid:{{display:false}}}},y:{{beginAtZero:true,ticks:{{stepSize:2}}}}}}}}
      }});
      </script>
    </div>
  </div>
  <div class="insight-card" style="margin-top:16px">
    <div class="insight-title">节奏变化</div>
    <div class="insight-body">
      {label_a} 日均 <strong>{avg_a:.1f}次</strong>，{label_b} 日均 <strong>{avg_b:.1f}次</strong>，
      {'B期发布密度提升' if avg_b > avg_a else 'B期发布密度下降' if avg_b < avg_a else '两期发布密度持平'}。
      {label_a} 高峰日 {max(sa["date_counts"], key=sa["date_counts"].get)[5:]}（{max(sa["date_counts"].values())}次），
      {label_b} 高峰日 {max(sb["date_counts"], key=sb["date_counts"].get)[5:]}（{max(sb["date_counts"].values())}次）。
    </div>
  </div>
</div>
'''

    # ========== 第三章：变更方向对比 ==========
    # 意图对比
    all_intents = sorted(set(list(sa['intents'].keys()) + list(sb['intents'].keys())))
    intent_compare = ''
    for intent in all_intents:
        ca = sa['intents'].get(intent, 0)
        cb = sb['intents'].get(intent, 0)
        ib = INTENT_BADGE.get(intent, 'badge-gray')
        intent_compare += f'<tr><td><span class="badge {ib}">{intent}</span></td><td class="text-center">{ca}</td><td class="text-center">{cb}</td><td>{_delta_str(ca, cb, "次")}</td></tr>\n'

    # 模块对比
    all_mods = sorted(set(list(sa['all_mod_counts'].keys()) + list(sb['all_mod_counts'].keys())),
                      key=lambda x: -(sa['all_mod_counts'].get(x, 0) + sb['all_mod_counts'].get(x, 0)))
    mod_compare = ''
    for m in all_mods:
        ca = sa['all_mod_counts'].get(m, 0)
        cb = sb['all_mod_counts'].get(m, 0)
        mod_compare += f'<tr><td>{short_mod(m)}</td><td class="text-center">{ca}</td><td class="text-center">{cb}</td><td>{_delta_str(ca, cb, "次")}</td></tr>\n'

    html += f'''
<div class="section">
  <div class="section-title"><span class="icon">🧭</span> 三、变更方向对比</div>
  <div class="two-col">
    <div>
      <h4 class="sub">变更意图对比</h4>
      <table class="data-table">
        <thead><tr><th>意图</th><th class="text-center">{label_a}</th><th class="text-center">{label_b}</th><th>变化</th></tr></thead>
        <tbody>{intent_compare}</tbody>
      </table>
    </div>
    <div>
      <h4 class="sub">业务模块对比</h4>
      <table class="data-table">
        <thead><tr><th>模块</th><th class="text-center">{label_a}</th><th class="text-center">{label_b}</th><th>变化</th></tr></thead>
        <tbody>{mod_compare}</tbody>
      </table>
    </div>
  </div>
</div>
'''

    # ========== 第四章：团队贡献对比 ==========
    all_ppl = sorted(set(list(sa['people'].keys()) + list(sb['people'].keys())),
                     key=lambda x: -(sa['people'].get(x, 0) + sb['people'].get(x, 0)))
    ppl_compare = ''
    new_ppl = []
    gone_ppl = []
    for p in all_ppl:
        ca = sa['people'].get(p, 0)
        cb = sb['people'].get(p, 0)
        tag = ''
        if ca == 0:
            tag = ' <span style="color:var(--success);font-size:11px">🆕</span>'
            new_ppl.append(p)
        elif cb == 0:
            tag = ' <span style="color:var(--warning);font-size:11px">⚠️</span>'
            gone_ppl.append(p)
        ppl_compare += f'<tr><td><strong>{p}</strong>{tag}</td><td class="text-center">{ca or "-"}</td><td class="text-center">{cb or "-"}</td><td>{_delta_str(ca, cb, "次") if ca and cb else ""}</td></tr>\n'

    team_insight_parts = []
    if new_ppl:
        team_insight_parts.append(f'B期新增发布人：<strong>{", ".join(new_ppl)}</strong>')
    if gone_ppl:
        team_insight_parts.append(f'A期有但B期无：<strong>{", ".join(gone_ppl)}</strong>')
    team_insight_parts.append(f'A期{len(sa["people"])}人 → B期{len(sb["people"])}人参与发布')
    team_insight = '。'.join(team_insight_parts) + '。'

    html += f'''
<div class="section">
  <div class="section-title"><span class="icon">👥</span> 四、团队贡献对比</div>
  <table class="data-table">
    <thead><tr><th>发布人</th><th class="text-center">{label_a}</th><th class="text-center">{label_b}</th><th>变化</th></tr></thead>
    <tbody>{ppl_compare}</tbody>
  </table>
  <div class="insight-card" style="margin-top:16px">
    <div class="insight-title">团队变化</div>
    <div class="insight-body">{team_insight}</div>
  </div>
</div>
'''

    # ========== 第五章：总结（改善 vs 恶化） ==========
    improve = []
    worsen = []
    if tb > ta:
        improve.append(f'发布量增加：{ta}次 → {tb}次（{_delta_str(ta, tb, "次")}）')
    elif tb < ta:
        worsen.append(f'发布量减少：{ta}次 → {tb}次（{_delta_str(ta, tb, "次")}）')
    if len(sb['people']) > len(sa['people']):
        improve.append(f'参与人数增加：{len(sa["people"])}人 → {len(sb["people"])}人')
    elif len(sb['people']) < len(sa['people']):
        worsen.append(f'参与人数减少：{len(sa["people"])}人 → {len(sb["people"])}人')
    if len(sb['services']) > len(sa['services']):
        improve.append(f'服务覆盖扩大：{len(sa["services"])}个 → {len(sb["services"])}个')
    if new_ppl:
        improve.append(f'新增发布人{len(new_ppl)}人，团队参与面扩大')
    if gone_ppl:
        worsen.append(f'{len(gone_ppl)}人在B期未发布（{", ".join(gone_ppl)}）')

    improve_html = '<br>\n'.join(f'<strong>{i+1}. </strong>{t}' for i, t in enumerate(improve)) if improve else '无明显改善项'
    worsen_html = '<br>\n'.join(f'<strong>{i+1}. </strong>{t}' for i, t in enumerate(worsen)) if worsen else '无明显恶化项'

    # ========== 第五章：Lead Time对比（如果两期都有LT数据） ==========
    lt_compare_section = ''
    has_lt_a = sa.get('has_lt')
    has_lt_b = sb.get('has_lt')
    summary_num = '六' if (has_lt_a or has_lt_b) else '五'
    appendix_num = '七' if (has_lt_a or has_lt_b) else '六'

    if has_lt_a or has_lt_b:
        # 辅助函数
        def arrow(a, b, fmt='d', reverse=False):
            """生成变化箭头，reverse=True表示值越小越好"""
            if a == 0 and b == 0:
                return '<span style="color:gray">—</span>'
            if a == 0:
                return f'<span style="color:{"red" if reverse else "green"}">↑ 新增</span>'
            pct = (b - a) / a * 100
            if abs(pct) < 1:
                return '<span style="color:gray">持平</span>'
            color = 'green' if (pct < 0 if not reverse else pct > 0) else 'red' if (pct > 0 if not reverse else pct < 0) else 'gray'
            arrow_ch = '↑' if pct > 0 else '↓'
            return f'<span style="color:{color}">{arrow_ch} {abs(pct):.0f}%</span>'

        def fmt_hours(h):
            if h >= 24:
                d = int(h // 24)
                rh = int(h % 24)
                return f'{d}天{rh}小时'
            return f'{h:.1f}小时'

        # 获取两期数据
        va = sa.get('lt_valid_count', 0)
        vb = sb.get('lt_valid_count', 0)
        ma = sa.get('lt_median_hours', 0)
        mb = sb.get('lt_median_hours', 0)
        ma_s = sa.get('lt_median_str', '无数据')
        mb_s = sb.get('lt_median_str', '无数据')
        ba = sa.get('n_补录', 0)
        bb = sb.get('n_补录', 0)
        ta = sa.get('lt_total', 1)
        tb = sb.get('lt_total', 1)
        ba_pct = ba / max(ta, 1) * 100
        bb_pct = bb / max(tb, 1) * 100
        na = sa.get('no_tapd', 0)
        nb = sb.get('no_tapd', 0)
        lla = sa.get('lt_long_tail', 0)
        llb = sb.get('lt_long_tail', 0)

        # 中位数变化箭头（越小越好，reverse=True）
        median_arrow = arrow(ma, mb, reverse=True) if (va > 0 and vb > 0) else '<span style="color:gray">—</span>'

        # 洞察内容
        insights = []
        if va > 0 and vb > 0:
            if mb < ma:
                insights.append(f'<div class="insight-card success"><div class="insight-title">效能提升</div><div class="insight-body">有效Lead Time中位数从 <strong>{ma_s}</strong> 降至 <strong>{mb_s}</strong>，研发交付速度有所提升。</div></div>')
            elif mb > ma:
                insights.append(f'<div class="insight-card warning"><div class="insight-title">效能下降</div><div class="insight-body">有效Lead Time中位数从 <strong>{ma_s}</strong> 升至 <strong>{mb_s}</strong>，需关注是否有阻塞因素。</div></div>')
            else:
                insights.append(f'<div class="insight-card info"><div class="insight-title">效能持平</div><div class="insight-body">两期有效Lead Time中位数均为 <strong>{ma_s}</strong>。</div></div>')

        if ba_pct > 0 or bb_pct > 0:
            trend = '下降' if bb_pct < ba_pct else '上升' if bb_pct > ba_pct else '持平'
            cls = 'success' if bb_pct < ba_pct else 'warning' if bb_pct > ba_pct else 'info'
            insights.append(f'<div class="insight-card {cls}"><div class="insight-title">补录情况</div><div class="insight-body">疑似补录占比：A期 <strong>{ba_pct:.0f}%</strong>（{ba}条） → B期 <strong>{bb_pct:.0f}%</strong>（{bb}条），{trend}。建议推行TAPD状态实时更新规范。</div></div>')

        if lla > 0 or llb > 0:
            insights.append(f'<div class="insight-card warning"><div class="insight-title">长尾需求（>30天）</div><div class="insight-body">A期 <strong>{lla}条</strong> → B期 <strong>{llb}条</strong>。长尾需求通常意味着需求拆分粒度不够或跨迭代延期。</div></div>')

        if na > 0 or nb > 0:
            insights.append(f'<div class="insight-card info"><div class="insight-title">无TAPD链接</div><div class="insight-body">A期 <strong>{na}条</strong>（{na/sa["total"]*100:.0f}%） → B期 <strong>{nb}条</strong>（{nb/sb["total"]*100:.0f}%）。建议所有发布必须关联TAPD需求单。</div></div>')

        insights_html = '\n'.join(insights) if insights else '<div class="insight-card info"><div class="insight-body">数据不足，无法生成洞察。</div></div>'

        lt_compare_section = f'''
<div class="section">
  <div class="section-title"><span class="icon">⏱️</span> 五、研发效能对比（Lead Time）</div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-label">有效LT发布数</div><div class="kpi-value">{va} → {vb}</div><div class="kpi-sub">{arrow(va, vb)}</div></div>
    <div class="kpi-card"><div class="kpi-label">有效LT中位数</div><div class="kpi-value" style="font-size:20px">{ma_s} → {mb_s}</div><div class="kpi-sub">{median_arrow}</div></div>
    <div class="kpi-card"><div class="kpi-label">疑似补录占比</div><div class="kpi-value" style="font-size:20px">{ba_pct:.0f}% → {bb_pct:.0f}%</div><div class="kpi-sub">{arrow(ba_pct, bb_pct, reverse=True)}</div></div>
    <div class="kpi-card"><div class="kpi-label">无TAPD链接</div><div class="kpi-value">{na} → {nb}</div><div class="kpi-sub">{arrow(na, nb, reverse=True)}</div></div>
  </div>
  {insights_html}
</div>
'''
    else:
        summary_num = '五'
        appendix_num = '六'

    html += lt_compare_section

    html += f'''
<div class="section">
  <div class="section-title"><span class="icon">📋</span> {summary_num}、总结与建议</div>
  <div class="two-col">
    <div>
      <h4 style="font-size:14px;margin-bottom:12px;color:var(--success)">📈 改善的地方（A→B 变好）</h4>
      <div class="insight-card success"><div class="insight-body">{improve_html}</div></div>
    </div>
    <div>
      <h4 style="font-size:14px;margin-bottom:12px;color:var(--danger)">📉 恶化的地方（A→B 变差）</h4>
      <div class="insight-card danger"><div class="insight-body">{worsen_html}</div></div>
    </div>
  </div>
</div>
'''

    # ========== 附录 ==========
    app_rows_all = ''
    for i, r in enumerate(sorted(rows_a + rows_b, key=lambda x: x['_dt']), 1):
        ib = INTENT_BADGE.get(r.get('变更意图分类', ''), 'badge-gray')
        mod_s = short_mod(r['发布的业务模块']) if r['发布的业务模块'] else '-'
        period = f'<span class="period-tag period-a">A</span>' if r in rows_a else f'<span class="period-tag period-b">B</span>'
        detail_val = r.get('发布详情', '') or ''
        detail_display = (detail_val[:80] + '...') if len(detail_val) > 80 else (detail_val or '-')
        app_rows_all += (f'<tr><td>{i}</td><td>{period}</td><td>{r["_date"]}</td><td style="font-size:11px">{r.get("发布审批单类型", "-")}</td><td>{r["发布标题"][:35]}</td>'
                         f'<td>{r["发布人"]}</td><td style="font-size:11px">{r.get("发布类型","") or "-"}</td><td style="font-size:11px">{r["发布的服务名称"] or "-"}</td>'
                         f'<td style="font-size:11px">{mod_s}</td>'
                         f'<td style="font-size:11px">{r.get("发布地域","") or "-"}</td>'
                         f'<td><span class="badge {ib}">{r.get("变更意图分类","") or "-"}</span></td>'
                         f'<td style="font-size:11px">{r.get("需求Lead Time","") or "-"}</td>'
                         f'<td style="font-size:11px">{r.get("Lead Time备注","") or "-"}</td>'
                         f'<td style="font-size:11px;max-width:180px;word-break:break-all">{detail_display}</td></tr>\n')

    html += f'''
<div class="section">
  <div class="section-title"><span class="icon">📎</span> {appendix_num}、附录：完整发布记录明细</div>
  <div style="overflow-x:auto">
  <table class="data-table" style="font-size:12px">
    <thead><tr><th>#</th><th>期间</th><th>日期</th><th>发布审批单类型</th><th>发布标题</th><th>发布人</th><th>类型</th><th>服务</th><th>模块</th><th>地域</th><th>意图</th><th>Lead Time</th><th>LT备注</th><th>发布详情</th></tr></thead>
    <tbody>{app_rows_all}</tbody>
  </table>
  </div>
</div>

<div class="report-footer">
  {title_prefix} — 发布变更对比分析报告 | {label_a} vs {label_b} | 生成时间：{now_str}
</div>

</div>
</body>
</html>'''
    return html


def main():
    args = parse_args()

    if args.input_a and args.input_b:
        # 对比模式
        rows_a = load_data(args.input_a)
        rows_b = load_data(args.input_b)
        sa = compute_stats(rows_a)
        sb = compute_stats(rows_b)
        label_a = args.label_a or 'A期'
        label_b = args.label_b or 'B期'
        html = generate_compare_html(rows_a, rows_b, sa, sb, label_a, label_b, args.title)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f'对比报告已生成: {args.output}')
        print(f'文件大小: {len(html) / 1024:.0f} KB')
        print(f'A期: {sa["total"]}条 ({label_a})')
        print(f'B期: {sb["total"]}条 ({label_b})')
    else:
        # 单期模式
        rows = load_data(args.input)
        s = compute_stats(rows)
        html = generate_html(rows, s, args.title)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f'报告已生成: {args.output}')
        print(f'文件大小: {len(html) / 1024:.0f} KB')
        print(f'模式: {"L3（含Lead Time）" if s.get("has_lt") else "L2（标准报告）"}')


if __name__ == '__main__':
    main()
