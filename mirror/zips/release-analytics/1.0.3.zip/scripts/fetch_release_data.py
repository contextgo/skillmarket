#!/usr/bin/env python3
"""
从智研平台获取发布审批单数据，输出为CSV文件。

用法：
  python3 fetch_release_data.py --project_ids 10323,10988 --start 2026-03-23 --end 2026-03-29 --output data.csv

参数：
  --project_ids   智研项目ID，逗号分隔（如 10323,10988,10990,9259）
  --start         开始日期（YYYY-MM-DD）
  --end           结束日期（YYYY-MM-DD）
  --output        输出CSV文件路径（默认 release_data.csv）
  --plm_filter    可选，按 plm_app[].name 过滤，支持多值逗号分隔（如 "导航技术中心导航组-路线诱导,导航-诱导方向"）

环境要求：
  需要设置智研API的访问Token，通过环境变量 ZHIYAN_TOKEN 传入。

输出CSV字段（基础12列，不含Lead Time）：
  审批单ID, 智研空间名称, 发布标题, 发布人, 发布类型, 发布的服务名称,
  发布的业务模块, 发布地域, 需求单, 发布详情, 变更意图分类, 创建时间

注意：Lead Time 和 Lead Time备注 不由本脚本生成。
当用户选择L3级别报告时，由AI通过TAPD MCP逐条计算后追加到CSV。
"""
import argparse
import csv
import json
import os
import re
import sys
import urllib.request
import urllib.parse
from datetime import datetime

# 智研API基地址（注意：是openapi子域名）
API_BASE = "http://openapi.zhiyan.woa.com"
LIST_API = "/workflow/api/order/query_order_list"
GET_API = "/workflow/api/order/get"

# 项目ID → 分析字段取值
PROJECT_MAP = {
    "10323": "路线排序/车道级/诱导/吸附",
    "10988": "路况",
    "10990": "诱导动态方向",
    "9259": "步骑行/电动车/公交",
    "8934": "地图网关",
    "9251": "底图服务/异源/同源",
}

# 变更意图关键词（按优先级排序，先匹配先命中）
INTENT_KEYWORDS = {
    "AB实验": ["ab", "实验", "灰度放量", "横评", "灰度", "abtest", "ab test", "对照组", "实验组"],
    "问题修复": ["修复", "fix", "bugfix", "异常", "兜底", "hotfix", "紧急", "还原", "回滚", "revert", "避免"],
    "新特性": ["新增", "支持", "接入", "上线", "一期", "专项", "新功能", "增加", "添加", "新建", "落盘",
              "实现", "召回", "获取", "提供", "额外", "补招"],
    "策略优化": ["优化", "调整", "阈值", "参数", "配置", "缩容", "扩容", "升级", "切流", "迁移",
                "取消", "去除", "适配", "稳定性", "逻辑", "策略", "压测", "容量", "更新",
                "变更", "下沉", "合入", "透传", "合并", "标准化", "上报", "压缩", "解析",
                "不下发", "改造"],
}


def classify_intent(title, detail=""):
    """基于标题和详情的关键词匹配，归类变更意图"""
    text = (title + " " + detail).lower()
    for intent, keywords in INTENT_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in text:
                return intent
    return "未分类（信息不足）"


def api_request(path, body=None, token=None):
    """发送POST请求到智研API"""
    url = API_BASE + path
    data = json.dumps(body or {}).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("token", token)
    req.add_header("User-Agent", "release-analytics-skill/1.0")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_list(project_id, start, end, token):
    """获取审批单列表"""
    body = {
        "project_id": [int(project_id)],
        "start_time": f"{start} 00:00:00",
        "end_time": f"{end} 23:59:59",
        "page": 1,
        "page_size": 200,
        "status": [3],  # 已通过
    }
    result = api_request(LIST_API, body, token)
    orders = result.get("data", {}).get("item", []) or []
    # 处理分页
    total = result.get("data", {}).get("total", 0)
    while len(orders) < total:
        body["page"] += 1
        result = api_request(LIST_API, body, token)
        page_list = result.get("data", {}).get("item", []) or []
        if not page_list:
            break
        orders.extend(page_list)
    return orders


def fetch_detail(order_id, token):
    """获取审批单详情（用于提取发布详情）"""
    body = {"id": int(order_id)}
    result = api_request(GET_API, body, token)
    return result.get("data", {}).get("item", {}) or {}


def classify_order_type(order):
    """根据system和template_en判定审批单类型（5种）"""
    system = order.get("system", "")
    template_en = order.get("template_en", "")
    platform_type = order.get("platform_type", "")

    if system == "zhiyan_workflow-xxx-yyds":
        return "变更助手单"
    elif system == "zhiyan-cicd":
        if template_en == "csig_urgent_approval":
            return "交付流紧急部署单"
        elif template_en == "post_review":
            return "发布评审单"
        elif template_en == "csig":
            if platform_type == "tkex-csig":
                return "交付流部署单-TKEX"
            else:
                return "交付流部署单-智研"
    return "未知类型"


def extract_fields(order, detail_data, project_id):
    """从审批单数据中提取分析字段"""
    # 基础字段
    row = {
        "审批单ID": order.get("id", ""),
        "发布审批单类型": classify_order_type(order),
        "智研空间名称": PROJECT_MAP.get(str(project_id), str(project_id)),
        "发布标题": order.get("title", ""),
        "发布人": order.get("creator", ""),
        "发布类型": order.get("post_name", ""),
        "创建时间": order.get("created_at", ""),
    }

    # 服务名称
    apps = order.get("app", [])
    row["发布的服务名称"] = apps[0].get("app_name", "") if apps else ""

    # 业务模块
    plm_apps = order.get("plm_app", [])
    row["发布的业务模块"] = plm_apps[0].get("name", "") if plm_apps else ""

    # 发布地域
    region = order.get("region", [])
    row["发布地域"] = ", ".join(region) if isinstance(region, list) else str(region)

    # 需求单
    row["需求单"] = order.get("tapd_url", "")

    # 发布详情（不同类型来源不同）
    # - 变更助手单 / 交付流部署单：get接口 → data JSON → CSIG.co_params.impactDetails
    # - 交付流紧急部署单：无发布详情（紧急流程跳过）
    # - 发布评审单：list接口直接返回的 remarks 字段
    row["发布详情"] = ""
    # 先取list接口的remarks（发布评审单）
    remarks = order.get("remarks", "") or ""
    if remarks:
        row["发布详情"] = remarks
    # 再尝试get接口的 CSIG.co_params.impactDetails（变更助手单/交付流部署单）
    if not row["发布详情"] and detail_data:
        data_str = detail_data.get("data", "")
        if data_str:
            try:
                data_json = json.loads(data_str)
                csig = data_json.get("CSIG", {})
                co_params = csig.get("co_params", {})
                row["发布详情"] = co_params.get("impactDetails", "")
            except (json.JSONDecodeError, AttributeError):
                pass

    # 变更意图
    row["变更意图分类"] = classify_intent(row["发布标题"], row["发布详情"])

    return row


def main():
    parser = argparse.ArgumentParser(description="从智研平台获取发布数据")
    parser.add_argument("--project_ids", required=True, help="智研项目ID，逗号分隔")
    parser.add_argument("--start", required=True, help="开始日期 YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="结束日期 YYYY-MM-DD")
    parser.add_argument("--output", default="release_data.csv", help="输出CSV路径")
    parser.add_argument("--plm_filter", default="", help="按plm_app[].name过滤，多值逗号分隔")
    parser.add_argument("--skip_detail", action="store_true", help="跳过get接口（加速，但无发布详情）")
    args = parser.parse_args()

    token = os.environ.get("ZHIYAN_TOKEN", "")
    if not token:
        print("错误：请设置环境变量 ZHIYAN_TOKEN", file=sys.stderr)
        sys.exit(1)

    project_ids = [p.strip() for p in args.project_ids.split(",")]
    all_rows = []

    for pid in project_ids:
        print(f"正在查询项目 {pid} ({PROJECT_MAP.get(pid, '未知')})...")
        orders = fetch_list(pid, args.start, args.end, token)
        print(f"  获取到 {len(orders)} 条审批单")

        for order in orders:
            # PLM过滤（支持多值，逗号分隔，任一匹配即保留）
            if args.plm_filter:
                plm_filter_list = [f.strip() for f in args.plm_filter.split(",") if f.strip()]
                plm_apps = order.get("plm_app", [])
                plm_names = [p.get("name", "") for p in plm_apps]
                if not any(pn in plm_filter_list for pn in plm_names):
                    continue

            # 获取详情
            detail_data = None
            if not args.skip_detail:
                try:
                    detail_data = fetch_detail(order["id"], token)
                except Exception as e:
                    print(f"  警告：获取 {order['id']} 详情失败: {e}", file=sys.stderr)

            row = extract_fields(order, detail_data, pid)
            all_rows.append(row)

    # 按创建时间排序
    all_rows.sort(key=lambda r: r["创建时间"])

    # 写入CSV
    fieldnames = [
        "审批单ID", "发布审批单类型", "智研空间名称", "发布标题", "发布人", "发布类型",
        "发布的服务名称", "发布的业务模块", "发布地域", "需求单",
        "发布详情", "变更意图分类", "创建时间",
    ]
    with open(args.output, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"\n完成！共 {len(all_rows)} 条数据，已写入 {args.output}")


if __name__ == "__main__":
    main()
