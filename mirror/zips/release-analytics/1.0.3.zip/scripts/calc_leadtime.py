#!/usr/bin/env python3
"""批量计算Lead Time，追加到CSV中"""
import csv, re, json, sys, os, urllib.request
from datetime import datetime

TAPD_API = "http://apiv2.tapd.woa.com"

def get_tapd_token():
    """获取TAPD Token：优先环境变量，其次~/.tapd_token文件"""
    token = os.environ.get("TAPD_ACCESS_TOKEN", "")
    if token:
        return token
    token_file = os.path.expanduser("~/.tapd_token")
    if os.path.exists(token_file):
        return open(token_file).read().strip()
    print("错误：未找到TAPD Token。请通过以下方式之一配置：")
    print("  1. 设置环境变量 TAPD_ACCESS_TOKEN")
    print("  2. 将Token写入 ~/.tapd_token 文件")
    print("  获取地址：https://tapd.woa.com/platform/myhome?not_direct=1&from=mcp#tab=tab-mytoken")
    sys.exit(1)

TAPD_TOKEN = get_tapd_token()

def tapd_get(path, params):
    qs = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"{TAPD_API}/{path}?{qs}"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {TAPD_TOKEN}")
    try:
        resp = urllib.request.urlopen(req, timeout=10)
        return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"status": 0, "error": str(e)}

# 缓存：项目状态映射（key→中文名）
_status_map_cache = {}

def get_story_status_map(ws_id):
    """获取项目的story状态 key→中文名 映射"""
    if ws_id in _status_map_cache:
        return _status_map_cache[ws_id]
    data = tapd_get("stories/get_fields_info", {"workspace_id": ws_id})
    status_options = data.get("data", {}).get("status", {}).get("options", {})
    _status_map_cache[ws_id] = status_options
    return status_options

def parse_tapd_url(url):
    """解析TAPD链接，返回 (workspace_id, object_type, object_id) 列表
    支持两种格式：
    - 新版: tapd_fe/{ws_id}/story/detail/{id} 或 tapd_fe/{ws_id}/bug/detail/{id}
    - 旧版: {ws_id}/prong/stories/view/{id} 或 {ws_id}/prong/bugtrace/bugs/view/{id}
    """
    results = []
    # 新版格式
    for m in re.finditer(r'tapd_fe/(\d+)/(story|bug)/detail/(\d+)', url):
        results.append((m.group(1), m.group(2), m.group(3)))
    # 旧版格式 - stories
    for m in re.finditer(r'(\d+)/prong/stories/view/(\d+)', url):
        results.append((m.group(1), "story", m.group(2)))
    # 旧版格式 - bugs
    for m in re.finditer(r'(\d+)/prong/bugtrace/bugs/view/(\d+)', url):
        results.append((m.group(1), "bug", m.group(2)))
    return results

def get_created_time(ws_id, obj_type, obj_id):
    """获取需求/缺陷的创建时间"""
    path = "stories" if obj_type == "story" else "bugs"
    data = tapd_get(path, {"workspace_id": ws_id, "id": obj_id, "fields": "id,created"})
    items = data.get("data", [])
    if items:
        key = "Story" if obj_type == "story" else "Bug"
        return items[0].get(key, {}).get("created", "")
    return ""

def get_final_target_status(ws_id, obj_type, obj_id):
    """获取最终到达目标状态的时间 + 完整状态变更时间线
    返回 (final_time, timeline_str)
    timeline_str 格式: 新→需求已评审(13s)→开发中(6s)→待发布(3h2m)
    """
    path = "story_changes" if obj_type == "story" else "bug_changes"
    id_key = "story_id" if obj_type == "story" else "bug_id"
    params = {"workspace_id": ws_id, id_key: obj_id, "limit": "200"}
    if obj_type == "bug":
        params["field"] = "status"
    data = tapd_get(path, params)
    items = data.get("data", [])
    
    # bug的终态用英文key直接匹配
    bug_target = {"resolved", "closed"}
    # story的终态用中文名匹配
    story_target_cn = {"待发布", "已发布", "已实现", "已验证", "已关闭"}
    
    # 收集所有状态变更（时间、from、to）
    status_changes = []
    change_key = "WorkitemChange" if obj_type == "story" else "BugChange"
    
    for item in items:
        c = item.get(change_key, {}) or item
        created = c.get("created", "")
        if not created:
            continue
        
        if obj_type == "bug":
            field = c.get("field", "")
            if field == "status":
                old_val = c.get("old_value", "")
                new_val = c.get("new_value", "")
                status_changes.append({"time": created, "from": old_val, "to": new_val})
        else:
            for fc in c.get("field_changes", []):
                if fc.get("field") == "status":
                    from_cn = fc.get("value_before_parsed", "") or fc.get("value_before", "")
                    to_cn = fc.get("value_after_parsed", "") or fc.get("value_after", "")
                    status_changes.append({"time": created, "from": from_cn, "to": to_cn})
    
    if not status_changes:
        return "", ""
    
    # 按时间排序
    status_changes.sort(key=lambda x: x["time"])
    
    # 找最终到达终态的时间
    target_times = []
    for sc in status_changes:
        to_val = sc["to"]
        if obj_type == "bug":
            if to_val.lower() in bug_target:
                target_times.append(sc["time"])
        else:
            if to_val in story_target_cn:
                target_times.append(sc["time"])
    
    final_time = sorted(target_times)[-1] if target_times else ""
    
    # 生成时间线字符串
    def fmt_delta(secs):
        if secs < 60:
            return f"{int(secs)}s"
        elif secs < 3600:
            return f"{int(secs/60)}m"
        elif secs < 86400:
            h = int(secs / 3600)
            m = int((secs % 3600) / 60)
            return f"{h}h{m}m" if m else f"{h}h"
        else:
            d = int(secs / 86400)
            h = int((secs % 86400) / 3600)
            return f"{d}d{h}h" if h else f"{d}d"
    
    parts = []
    for i, sc in enumerate(status_changes):
        if i == 0:
            # 第一个变更，只显示from
            if sc["from"] and sc["from"] != "--":
                parts.append(sc["from"])
        if sc["to"]:
            if i > 0:
                # 计算与上一次变更的时间间隔
                prev_time = datetime.strptime(status_changes[i-1]["time"], "%Y-%m-%d %H:%M:%S")
                curr_time = datetime.strptime(sc["time"], "%Y-%m-%d %H:%M:%S")
                delta = (curr_time - prev_time).total_seconds()
                parts.append(f"{sc['to']}({fmt_delta(delta)})")
            else:
                parts.append(sc["to"])
    
    timeline = "→".join(parts)
    
    return final_time, timeline

def calc_lead_time(created_str, resolved_str):
    """计算Lead Time并返回人类可读格式+备注"""
    if not created_str or not resolved_str:
        return "", ""
    try:
        c = datetime.strptime(created_str, "%Y-%m-%d %H:%M:%S")
        r = datetime.strptime(resolved_str, "%Y-%m-%d %H:%M:%S")
        delta = r - c
        hours = delta.total_seconds() / 3600
        
        if hours < 0:
            return f"{hours:.1f}h", "异常（终态早于created）"
        elif hours < 24:
            days = delta.days
            remaining_hours = (delta.total_seconds() - days * 86400) / 3600
            lt_str = f"{hours:.1f}小时"
            return lt_str, "疑似补录"
        else:
            days = delta.days
            remaining_hours = (delta.total_seconds() - days * 86400) / 3600
            if days > 0:
                lt_str = f"{days}天{remaining_hours:.0f}小时"
            else:
                lt_str = f"{hours:.1f}小时"
            # ≥24小时的，标记"待判定"，由大模型根据时间线判断是否规范
            return lt_str, "待判定"
    except:
        return "", "解析异常"

def main():
    input_csv = sys.argv[1]
    output_csv = sys.argv[2] if len(sys.argv) > 2 else input_csv
    
    with open(input_csv, "r", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    
    # 缓存：同一需求ID只查一次
    cache = {}
    total = len(rows)
    has_tapd = sum(1 for r in rows if r["需求单"].strip())
    print(f"共 {total} 条，其中 {has_tapd} 条有TAPD链接")
    
    for i, r in enumerate(rows):
        tapd_url = r["需求单"].strip()
        if not tapd_url:
            r["需求Lead Time"] = ""
            r["Lead Time备注"] = "无TAPD链接"
            r["状态变更时间线"] = ""
            continue
        
        parsed = parse_tapd_url(tapd_url)
        if not parsed:
            r["需求Lead Time"] = ""
            r["Lead Time备注"] = "链接格式无法解析"
            r["状态变更时间线"] = ""
            continue
        
        ws_id, obj_type, obj_id = parsed[0]  # 取第一个链接
        cache_key = f"{obj_type}_{obj_id}"
        
        if cache_key in cache:
            r["需求Lead Time"], r["Lead Time备注"], r["状态变更时间线"] = cache[cache_key]
            print(f"  [{i+1}/{total}] {r['发布标题'][:30]} → 缓存命中")
            continue
        
        print(f"  [{i+1}/{total}] {r['发布标题'][:30]} → 查询 {obj_type}/{obj_id}...", end="")
        
        created = get_created_time(ws_id, obj_type, obj_id)
        if not created:
            r["需求Lead Time"] = "无权限"
            r["Lead Time备注"] = "无法获取需求信息"
            r["状态变更时间线"] = ""
            cache[cache_key] = (r["需求Lead Time"], r["Lead Time备注"], "")
            print(" 无权限")
            continue
        
        resolved, timeline = get_final_target_status(ws_id, obj_type, obj_id)
        if not resolved:
            r["需求Lead Time"] = "未到达终态"
            r["Lead Time备注"] = "需求未到达终态"
            r["状态变更时间线"] = timeline or ""
            cache[cache_key] = (r["需求Lead Time"], r["Lead Time备注"], r["状态变更时间线"])
            print(" 未到达终态")
            continue
        
        lt, note = calc_lead_time(created, resolved)
        r["需求Lead Time"] = lt
        r["Lead Time备注"] = note
        r["状态变更时间线"] = timeline
        cache[cache_key] = (lt, note, timeline)
        print(f" {lt} ({note})")
    
    # 写出
    fieldnames = list(rows[0].keys())
    if "需求Lead Time" not in fieldnames:
        fieldnames.extend(["需求Lead Time", "Lead Time备注", "状态变更时间线"])
    
    with open(output_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    
    print(f"\n已写入 {output_csv}")

if __name__ == "__main__":
    main()
