# OpenClaw 初中语文作文批改插件

## 简介

这是一个专为初中语文教师设计的 OpenClaw Skill 插件，可以帮助教师快速、高效地批改学生作文。

## 功能特点

- ✅ 多维度评分（中心思想、内容选材、结构布局、语言表达、细节规范）
- ✅ 亮点赏析标注
- ✅ 具体问题指出
- ✅ 可操作的修改建议
- ✅ 分年级差异化评价

## 安装方法

### 方法一：复制到 Skills 目录

```bash
# 将整个 openclaw-essay-review 文件夹复制到 OpenClaw 的 skills 目录
cp -r openclaw-essay-review ~/.openclaw/workspace/skills/
```

### 方法二：使用 ClawHub（如果支持）

```bash
openclaw skills install essay-review
```

## 使用方法

1. 在 OpenClaw 对话中，直接粘贴学生作文
2. 输入批改请求，如：
   - "帮我批改这篇作文"
   - "点评一下这篇学生作文"
   - "看看这篇作文有什么问题"

3. AI 将自动按照评分标准进行批改并输出报告

## 目录结构

```
openclaw-essay-review/
├── SKILL.md                           # 主技能文件
├── README.md                           # 使用说明
└── references/
    └── grading-standards.md            # 评分标准参考
```

## 注意事项

- 本技能基于通用初中语文教学标准设计
- 教师可根据学校具体要求调整评分权重
- 建议结合教师个人判断使用

## 更新日志

### v1.0.0 (2026-04-25)
- 初始版本发布
- 支持记叙文、说明文、议论文批改
- 包含完整评分标准
