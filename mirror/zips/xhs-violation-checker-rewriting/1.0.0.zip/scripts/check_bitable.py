"""
飞书多维表格 - 小红书违禁词批量检测与修改

从飞书多维表格读取「笔记标题」「笔记内容」字段，
基于289个违禁词库进行四级检测，输出报告并批量回写安全替换后的内容。

用法：
  python check_bitable.py --url "飞书多维表格链接" --app-id XXX --app-secret XXX
  python check_bitable.py --url "飞书多维表格链接" --dry-run          # 仅检测不修改
  python check_bitable.py --url "飞书多维表格链接" --report report.md  # 报告输出到文件

环境变量：
  FEISHU_APP_ID     - 飞书应用 APP_ID（可替代 --app-id）
  FEISHU_APP_SECRET - 飞书应用 APP_SECRET（可替代 --app-secret）
"""

import requests
import json
import sys
import io
import re
import argparse
import os
import time
from urllib.parse import urlparse, parse_qs
from datetime import datetime

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ===== 默认配置 =====
DEFAULT_APP_ID = os.environ.get('FEISHU_APP_ID', '')
DEFAULT_APP_SECRET = os.environ.get('FEISHU_APP_SECRET', '')
DEFAULT_TITLE_FIELD = '笔记标题'
DEFAULT_CONTENT_FIELD = '笔记内容'
BATCH_SIZE = 500

_token_cache = {'token': None, 'expire_at': 0}


# ==================== 飞书 API ====================

def get_token(app_id, app_secret):
    """获取飞书 tenant_access_token"""
    now = time.time()
    if _token_cache['token'] and now < _token_cache['expire_at']:
        return _token_cache['token']
    r = requests.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
        json={'app_id': app_id, 'app_secret': app_secret}
    )
    data = r.json()
    if data.get('code') != 0:
        raise Exception(f"获取token失败: {data.get('msg')}")
    _token_cache['token'] = data['tenant_access_token']
    _token_cache['expire_at'] = now + data.get('expire', 7200) - 300
    return _token_cache['token']


def parse_bitable_url(url):
    """
    从飞书多维表格链接解析 APP_TOKEN, TABLE_ID, VIEW_ID
    支持格式：
      https://xxx.feishu.cn/base/APP_TOKEN?table=TABLE_ID&view=VIEW_ID
      https://xxx.feishu.cn/base/APP_TOKEN/table/TABLE_ID?view=VIEW_ID
    """
    parsed = urlparse(url)
    path_parts = parsed.path.strip('/').split('/')

    app_token = ''
    table_id = ''
    for i, part in enumerate(path_parts):
        if part == 'base' and i + 1 < len(path_parts):
            app_token = path_parts[i + 1]
        if part == 'table' and i + 1 < len(path_parts):
            table_id = path_parts[i + 1]

    if not app_token:
        raise Exception(f"无法从链接解析 APP_TOKEN: {url}")

    params = parse_qs(parsed.query)
    if not table_id:
        table_id = params.get('table', [''])[0]
    view_id = params.get('view', [''])[0]

    return app_token, table_id, view_id


def get_all_records(token, app_token, table_id, view_id=''):
    """读取飞书多维表格所有记录"""
    records = []
    page_token = None
    while True:
        url = f'https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records?page_size=500'
        if view_id:
            url += f'&view={view_id}'
        if page_token:
            url += f'&page_token={page_token}'
        r = requests.get(url, headers={'Authorization': f'Bearer {token}'})
        data = r.json()
        if data.get('code') != 0:
            raise Exception(f"读取记录失败: {data.get('msg')}")
        for item in data['data']['items']:
            records.append({
                'record_id': item['record_id'],
                'fields': item['fields']
            })
        page_token = data['data'].get('page_token')
        if not page_token:
            break
    return records


def batch_update_records(token, app_token, table_id, updates):
    """批量更新飞书记录，每次最多500条"""
    results = {'success': 0, 'fail': 0}
    for i in range(0, len(updates), BATCH_SIZE):
        batch = updates[i:i + BATCH_SIZE]
        url = f'https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_update'
        records_body = []
        for u in batch:
            records_body.append({
                'record_id': u['record_id'],
                'fields': u['fields']
            })
        body = {'records': records_body}
        r = requests.post(url, headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }, json=body)
        data = r.json()
        if data.get('code') != 0:
            print(f"  ❌ 批量更新失败: {data.get('msg')}")
            results['fail'] += len(batch)
        else:
            results['success'] += len(batch)
    return results


def extract_field_text(fields, field_name):
    """从飞书记录字段中提取纯文本值"""
    value = fields.get(field_name, '')
    if not value:
        return ''
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        # URL 字段格式
        if 'text' in value:
            return value['text']
        if 'link' in value:
            return value['link']
        return str(value)
    if isinstance(value, list):
        # 多选/标签/富文本格式
        texts = []
        for v in value:
            if isinstance(v, str):
                texts.append(v)
            elif isinstance(v, dict):
                texts.append(v.get('text', v.get('link', str(v))))
            else:
                texts.append(str(v))
        return ' '.join(texts)
    return str(value)


# ==================== 违禁词库 ====================

def load_violation_words(filepath):
    """从违禁词库.md解析所有违禁词，返回按严重程度分组的字典"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    categories = {
        '🔴绝对违禁': [],
        '🟡敏感': [],
        '🟠行业限制': [],
        '⚫规避': []
    }

    current_category = None
    current_subcategory = ''

    for line in content.split('\n'):
        line = line.strip()

        # 检测类别标题
        if line.startswith('## 🔴'):
            current_category = '🔴绝对违禁'
        elif line.startswith('## 🟡'):
            current_category = '🟡敏感'
        elif line.startswith('## 🟠'):
            current_category = '🟠行业限制'
        elif line.startswith('## ⚫'):
            current_category = '⚫规避'

        # 检测子类别
        if line.startswith('### '):
            current_subcategory = line.replace('### ', '').strip()

        # 解析表格行
        if not line.startswith('|') or not current_category:
            continue

        cells = [c.strip() for c in line.split('|')]
        if len(cells) < 6:
            continue

        word = cells[1]
        example = cells[2]
        risk = cells[3]
        industry = cells[4]
        suggestion = cells[5]

        # 跳过表头和分隔行
        if word in ['违禁词', '---', ''] or word.startswith('-'):
            continue

        categories[current_category].append({
            'word': word,
            'example': example,
            'risk_level': risk,
            'industry': industry,
            'suggestion': suggestion,
            'subcategory': current_subcategory
        })

    return categories


# ==================== 检测逻辑 ====================

# 不参与检测和替换的词（词库中的误匹配条目）
# "1" 在词库中用于匹配 "第一"，但单字符 "1" 会误匹配所有包含1的文本
_DETECT_SKIP_WORDS = {'1'}
# 不参与自动替换的词（单字符或过于宽泛）
_AUTO_REPLACE_SKIP_WORDS = {'1'}

# 前缀模式白名单："最…" 匹配到的安全组合不算违禁
# "最近"(recently)、"最初"(initially)、"最终"(finally) 等非程度修饰用法
_PREFIX_SAFE_COMBOS = {
    '最': {'最近', '最初', '最终', '最迟', '最晚', '最早', '最为', '最少', '最多', '最前', '最后'},
    '第': set(),  # "第X" 暂无需要白名单的
}


def detect_violations(text, categories):
    """检测文本中的违禁词，返回命中列表（按严重程度排序）"""
    if not text or not isinstance(text, str):
        return []

    violations = []
    seen_words = set()

    severity_order = ['🔴绝对违禁', '🟡敏感', '🟠行业限制', '⚫规避']

    for severity in severity_order:
        words = categories[severity]
        for item in words:
            w = item['word']
            if not w or w in seen_words:
                continue
            if w.startswith('→') or w.startswith('-'):
                continue
            # 跳过已知的误匹配条目
            if w in _DETECT_SKIP_WORDS:
                continue

            matched = False
            match_word = w  # 实际匹配到的词
            is_prefix_pattern = False  # 是否为前缀模式（如 "最…"）

            # 前缀模式匹配：词末尾带 "…" 表示前缀（如 "最…" 匹配 "最好""最佳"）
            if w.endswith('…') or w.endswith('...'):
                root = w.rstrip('…').rstrip('.')
                if root and root in text:
                    is_prefix_pattern = True
                    # 扩展匹配：从 root 开始逐步扩展，最多2个字符
                    # 先试1个字符（如"最近"），再试2个（如"最便宜"）
                    idx = text.find(root)
                    if idx >= 0:
                        match_word = root  # 先只匹配 root 本身
                        end = idx + len(root)
                        # 逐步扩展1-2个字符
                        for step in range(1, 3):
                            if end + step - 1 < len(text) and not _is_chinese_delimiter(text[end + step - 1]):
                                candidate = text[idx:end + step]
                                # 如果当前扩展长度在白名单中，说明不是违禁用法
                                if root in _PREFIX_SAFE_COMBOS and candidate in _PREFIX_SAFE_COMBOS[root]:
                                    matched = False
                                    is_prefix_pattern = False
                                    break
                                match_word = candidate
                            else:
                                break
                        else:
                            # 循环正常结束（没被 break），说明不是白名单词，匹配成功
                            matched = True
                        # 如果被 break 了（白名单命中），continue 跳过
                        if not matched:
                            continue
                        matched = True

            # 精确/包含匹配
            if not matched and w in text:
                matched = True
            # 规避手段词：拼音/谐音替代
            elif not matched and severity == '⚫规避' and '→' in w:
                parts = w.split('→')
                if len(parts) == 2:
                    alt = parts[1].strip().rstrip(')')
                    if alt and alt.lower() in text.lower():
                        matched = True
                        match_word = alt
            # XX占位符模式（如 "XX天见效" 匹配 "3天见效"）
            elif not matched and 'XX' in w:
                pattern = w.replace('XX', '.{1,4}')
                regex = re.compile(pattern)
                m = regex.search(text)
                if m:
                    matched = True
                    match_word = m.group()

            if matched:
                seen_words.add(w)
                # 提取上下文
                search_word = match_word if match_word in text else w
                idx = text.find(search_word) if search_word in text else -1
                if idx >= 0:
                    start = max(0, idx - 5)
                    end = min(len(text), idx + len(search_word) + 5)
                    context = f"……{text[start:end]}……"
                else:
                    context = f"包含「{match_word}」"

                # 提取首个安全替换建议
                suggestion = item['suggestion']
                first_suggestion = ''
                if suggestion:
                    if '/' in suggestion:
                        first_suggestion = suggestion.split('/')[0].strip()
                    else:
                        first_suggestion = suggestion.strip()
                # 不适合自动替换的建议
                if first_suggestion.startswith('请') or first_suggestion.startswith('咨询'):
                    first_suggestion = ''

                # 是否可自动替换
                # 前缀模式词（如"最好"）和占位符模式词不自动替换，避免语境错误
                can_auto_replace = (
                    first_suggestion
                    and w not in _AUTO_REPLACE_SKIP_WORDS
                    and len(w) >= 2
                    and not is_prefix_pattern
                    and 'XX' not in w
                )

                violations.append({
                    'word': w,
                    'matched_word': match_word,
                    'severity': severity,
                    'context': context,
                    'example': item['example'],
                    'risk_level': item['risk_level'],
                    'suggestion': first_suggestion,
                    'all_suggestions': item['suggestion'],
                    'can_auto_replace': can_auto_replace,
                    'is_prefix_pattern': is_prefix_pattern,
                    'subcategory': item.get('subcategory', '')
                })

    return violations


def _is_chinese_delimiter(ch):
    """判断字符是否为中文分词边界（标点、空格等）"""
    delimiters = set('，。！？、；：""''【】《》（）—…·\n\r\t ,.!?:;\'"()[]{}<>')
    return ch in delimiters


def replace_violations(text, violations):
    """
    将文本中的违禁词替换为安全替代词
    只替换 can_auto_replace=True 的词
    返回 (修改后文本, 替换记录列表)
    """
    if not text or not isinstance(text, str):
        return text, []

    modified = text
    replacements = []

    # 按词长度降序排列，先替换长词避免部分匹配
    sorted_v = sorted(
        [v for v in violations if v['can_auto_replace']],
        key=lambda v: len(v['word']),
        reverse=True
    )

    for v in sorted_v:
        w = v['matched_word']
        suggestion = v['suggestion']
        if not suggestion or w not in modified:
            continue

        modified = modified.replace(w, suggestion)
        replacements.append({
            'original': w,
            'replacement': suggestion,
            'severity': v['severity']
        })

    return modified, replacements


# ==================== 报告生成 ====================

def generate_report(results, total_records, dry_run=False):
    """生成 Markdown 检测报告"""
    lines = []
    lines.append("## 🔍 违禁词检测报告\n")
    lines.append(f"**检测时间**：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**检测记录数**：{total_records}")
    lines.append(f"**执行模式**：{'仅检测（dry-run）' if dry_run else '检测 + 批量修改'}\n")
    lines.append("---\n")

    # 统计
    total_violations = sum(
        len(r['title_violations']) + len(r['content_violations'])
        for r in results
    )
    has_violation = [r for r in results if r['title_violations'] or r['content_violations']]

    severity_counts = {'🔴绝对违禁': 0, '🟡敏感': 0, '🟠行业限制': 0, '⚫规避': 0}
    auto_replaceable = 0
    manual_needed = 0

    for r in results:
        for v in r['title_violations'] + r['content_violations']:
            severity_counts[v['severity']] += 1
            if v['can_auto_replace']:
                auto_replaceable += 1
            else:
                manual_needed += 1

    if total_violations == 0:
        lines.append("### 检测结果\n")
        lines.append("- ✅ **通过**（未检测到违禁词）\n")
        return '\n'.join(lines)

    lines.append("### 检测结果\n")
    lines.append(f"- ⚠️ **发现 {total_violations} 处违禁词**，涉及 {len(has_violation)} 条记录\n")
    lines.append(f"- 🤖 可自动替换：{auto_replaceable} 处")
    lines.append(f"- ✋ 需手动修改：{manual_needed} 处（无安全替换词或词过短）\n")

    # 逐条记录详情
    for r in has_violation:
        title_preview = r['title_text'][:30] if r['title_text'] else '(无标题)'
        lines.append(f"\n#### 📝 记录 #{r['index']}（{title_preview}）\n")

        if r['title_violations']:
            lines.append(f"**笔记标题违规（{len(r['title_violations'])} 条）：**\n")
            lines.append("| # | 违禁词 | 所在位置 | 风险等级 | 安全替换 | 可自动替换 |")
            lines.append("|---|--------|----------|----------|----------|------------|")
            for i, v in enumerate(r['title_violations'], 1):
                auto_mark = '✅' if v['can_auto_replace'] else '❌'
                sug = v['suggestion'] or '需手动修改'
                lines.append(
                    f"| {i} | {v['word']} | {v['context']} | {v['risk_level']} | {sug} | {auto_mark} |"
                )
            lines.append("")

        if r['content_violations']:
            lines.append(f"**笔记内容违规（{len(r['content_violations'])} 条）：**\n")
            lines.append("| # | 违禁词 | 所在位置 | 风险等级 | 安全替换 | 可自动替换 |")
            lines.append("|---|--------|----------|----------|----------|------------|")
            for i, v in enumerate(r['content_violations'], 1):
                auto_mark = '✅' if v['can_auto_replace'] else '❌'
                sug = v['suggestion'] or '需手动修改'
                lines.append(
                    f"| {i} | {v['word']} | {v['context']} | {v['risk_level']} | {sug} | {auto_mark} |"
                )
            lines.append("")

    # 风险总览
    overall = ('🔴极高' if severity_counts['🔴绝对违禁'] > 0 else
               '🟡高' if severity_counts['🟡敏感'] > 0 else
               '🟠中' if severity_counts['🟠行业限制'] > 0 else '🟢低')

    lines.append("---\n")
    lines.append("### 📊 风险总览\n")
    lines.append("| 指标 | 值 |")
    lines.append("|------|----|")
    lines.append(f"| 违禁词总数 | {total_violations} |")
    lines.append(f"| 涉及记录数 | {len(has_violation)} / {total_records} |")
    lines.append(f"| 🔴绝对违禁 | {severity_counts['🔴绝对违禁']} 条 |")
    lines.append(f"| 🟡敏感词 | {severity_counts['🟡敏感']} 条 |")
    lines.append(f"| 🟠行业限制词 | {severity_counts['🟠行业限制']} 条 |")
    lines.append(f"| ⚫规避手段词 | {severity_counts['⚫规避']} 条 |")
    lines.append(f"| 🤖可自动替换 | {auto_replaceable} 处 |")
    lines.append(f"| ✋需手动修改 | {manual_needed} 处 |")
    lines.append(f"| 综合风险等级 | {overall} |")

    # 规避手段提示
    evasion_violations = []
    for r in has_violation:
        for v in r['title_violations'] + r['content_violations']:
            if v['severity'] == '⚫规避':
                evasion_violations.append(v)
    if evasion_violations:
        lines.append("\n---\n")
        lines.append("> ⚠️ 注意：以下词语通过规避手段伪装（拼音/谐音/符号），同样属于违规！平台会识别并处理。\n")
        for v in evasion_violations:
            lines.append(f"> - `{v['matched_word']}` → 规避替代「{v['word']}」")

    return '\n'.join(lines)


# ==================== 修改汇总 ====================

def generate_change_summary(results):
    """生成修改汇总"""
    lines = []
    lines.append("### 💡 修改汇总\n")

    any_changes = False
    for r in results:
        title_reps = []
        content_reps = []

        if r['title_violations']:
            _, reps = replace_violations(r['title_text'], r['title_violations'])
            title_reps = reps

        if r['content_violations']:
            _, reps = replace_violations(r['content_text'], r['content_violations'])
            content_reps = reps

        if not title_reps and not content_reps:
            continue

        any_changes = True
        title_preview = r['title_text'][:30] if r['title_text'] else '(无标题)'
        lines.append(f"**记录 #{r['index']}**（{title_preview}）\n")

        if title_reps:
            for rep in title_reps:
                lines.append(f"- 标题：「{rep['original']}」→「{rep['replacement']}」")
        if content_reps:
            for rep in content_reps:
                lines.append(f"- 内容：「{rep['original']}」→「{rep['replacement']}」")
        lines.append("")

    if not any_changes:
        lines.append("无需自动替换的违禁词（均需手动修改或无安全替换词）。\n")

    return '\n'.join(lines)


# ==================== 主流程 ====================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='飞书多维表格 - 小红书违禁词批量检测与修改')
    parser.add_argument('--url', required=True, help='飞书多维表格链接')
    parser.add_argument('--app-id', default=DEFAULT_APP_ID, help='飞书应用 APP_ID')
    parser.add_argument('--app-secret', default=DEFAULT_APP_SECRET, help='飞书应用 APP_SECRET')
    parser.add_argument('--title-field', default=DEFAULT_TITLE_FIELD, help='笔记标题字段名（默认: 笔记标题）')
    parser.add_argument('--content-field', default=DEFAULT_CONTENT_FIELD, help='笔记内容字段名（默认: 笔记内容）')
    parser.add_argument('--dry-run', action='store_true', help='仅检测，不执行修改')
    parser.add_argument('--report', default='', help='报告输出文件路径（Markdown）')

    args = parser.parse_args()

    # ===== 校验凭证 =====
    if not args.app_id or not args.app_secret:
        print("❌ 缺少飞书应用凭证")
        print("   请通过 --app-id 和 --app-secret 参数提供")
        print("   或设置环境变量 FEISHU_APP_ID 和 FEISHU_APP_SECRET")
        sys.exit(1)

    # ===== 解析链接 =====
    try:
        app_token, table_id, view_id = parse_bitable_url(args.url)
        print(f"📋 解析链接: APP_TOKEN={app_token}, TABLE_ID={table_id or '未指定'}, VIEW_ID={view_id or '未指定'}")
    except Exception as e:
        print(f"❌ 解析链接失败: {e}")
        sys.exit(1)

    if not table_id:
        print("❌ 链接中缺少 table 参数，请在链接中指定表ID")
        print("   示例: https://xxx.feishu.cn/base/APP_TOKEN?table=TABLE_ID")
        sys.exit(1)

    # ===== 获取 Token =====
    try:
        token = get_token(args.app_id, args.app_secret)
        print(f"🔑 飞书认证成功")
    except Exception as e:
        print(f"❌ 飞书认证失败: {e}")
        sys.exit(1)

    # ===== 读取记录 =====
    print(f"📖 正在读取飞书记录...")
    try:
        records = get_all_records(token, app_token, table_id, view_id)
        print(f"📖 共读取 {len(records)} 条记录")
    except Exception as e:
        print(f"❌ 读取记录失败: {e}")
        sys.exit(1)

    if not records:
        print("⚠️ 未读取到任何记录")
        sys.exit(0)

    # ===== 加载词库 =====
    base_dir = os.path.dirname(os.path.abspath(__file__))
    word_lib_path = os.path.join(base_dir, '..', 'references', '违禁词库.md')
    if not os.path.exists(word_lib_path):
        print(f"❌ 违禁词库文件不存在: {word_lib_path}")
        sys.exit(1)

    categories = load_violation_words(word_lib_path)
    total_words = sum(len(v) for v in categories.values())
    print(f"📚 加载违禁词库: {total_words} 条")
    for sev, words in categories.items():
        print(f"   {sev}: {len(words)} 条")

    # ===== 逐条检测 =====
    print(f"\n🔍 开始检测违禁词...\n")
    results = []

    for idx, record in enumerate(records, 1):
        fields = record['fields']
        title_text = extract_field_text(fields, args.title_field)
        content_text = extract_field_text(fields, args.content_field)

        title_violations = detect_violations(title_text, categories)
        content_violations = detect_violations(content_text, categories)

        results.append({
            'index': idx,
            'record_id': record['record_id'],
            'title_text': title_text,
            'content_text': content_text,
            'title_violations': title_violations,
            'content_violations': content_violations
        })

        if title_violations or content_violations:
            total_v = len(title_violations) + len(content_violations)
            auto_v = sum(1 for v in title_violations + content_violations if v['can_auto_replace'])
            print(f"  📝 记录 #{idx}: {total_v} 处违禁词 (可自动替换: {auto_v})")

    # ===== 生成报告 =====
    report = generate_report(results, len(records), dry_run=args.dry_run)
    print(f"\n{report}")

    if args.report:
        with open(args.report, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"\n📄 报告已保存至: {args.report}")

    # ===== 批量修改 =====
    if args.dry_run:
        print(f"\n⚠️ --dry-run 模式，未执行实际修改")
        print(f"   如需修改，请去掉 --dry-run 参数重新运行\n")
    else:
        updates = []
        for r in results:
            if not r['title_violations'] and not r['content_violations']:
                continue

            fields = {}
            has_change = False

            if r['title_violations']:
                new_title, title_reps = replace_violations(r['title_text'], r['title_violations'])
                if title_reps:
                    fields[args.title_field] = new_title
                    has_change = True

            if r['content_violations']:
                new_content, content_reps = replace_violations(r['content_text'], r['content_violations'])
                if content_reps:
                    fields[args.content_field] = new_content
                    has_change = True

            if has_change:
                updates.append({
                    'record_id': r['record_id'],
                    'fields': fields
                })

        if updates:
            print(f"\n✏️ 正在批量修改 {len(updates)} 条记录...")
            try:
                result = batch_update_records(token, app_token, table_id, updates)
                print(f"✅ 批量修改完成: 成功 {result['success']} 条, 失败 {result['fail']} 条")
            except Exception as e:
                print(f"❌ 批量修改失败: {e}")
                sys.exit(1)
        else:
            print(f"\n✅ 无可自动替换的违禁词（所有违规词均需手动修改）")

    # ===== 修改汇总 =====
    summary = generate_change_summary(results)
    print(f"\n{summary}")
