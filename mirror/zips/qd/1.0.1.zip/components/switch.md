# v-switch 开关

## 基本用法

```html
<!-- 基础 -->
<v-switch v-model="enabled"></v-switch>

<!-- 带说明文字 -->
<v-switch v-model="enabled" label="开关说明文字"></v-switch>

<!-- 自定义开关文字（不超过两个汉字或三个英文字母） -->
<v-switch v-model="enabled" on-text="开" off-text="关"></v-switch>
<v-switch v-model="enabled" on-text="ON" off-text="OFF"></v-switch>

<!-- 禁用 -->
<v-switch v-model="enabled" disabled></v-switch>
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value/v-model | 绑定值（开关状态） | boolean | false |
| disabled | 禁用 | boolean | false |
| on-text | 打开时的文字 | string | - |
| off-text | 关闭时的文字 | string | - |
| label | 开关后面的说明文本 | string | - |
| name | 原生 name 属性 | string | - |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | 绑定值改变时触发 | 新状态布尔值 |
| change | 绑定值改变时触发 | 新状态布尔值 |
