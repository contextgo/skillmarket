# v-date-picker 日期选择器

## 基本用法

```html
<!-- 日期范围选择（默认） -->
<v-date-picker
  v-model="dateRange"
  :max-range="100"
  :max-date="2"
  :min-date="-100"
  :shortcuts="shortcuts"
  placeholder="请选择日期范围"
  clearable>
</v-date-picker>

<!-- 日期 + 时间 -->
<v-date-picker
  v-model="dateRange"
  enable-timer
  displayFormat="YYYY-MM-DD HH:mm:ss"
  modelFormat="YYYY-MM-DD HH:mm:ss"
  :shortcuts="shortcuts"
  clearable
  shortcutsLayout="inner,stand"
  :timer-config="{ hasSecond: true }">
</v-date-picker>

<!-- 单日历（DatePanel） -->
<v-date-picker
  v-model="singleDate"
  kind="DatePanel"
  displayFormat="YYYY-MM-DD HH:mm:ss"
  modelFormat="YYYY-MM-DD HH:mm:ss"
  enable-timer
  :max-date="0">
</v-date-picker>

<!-- 自定义触发器 -->
<v-date-picker v-model="dateRange" kind="DatePanel" :max-date="0">
  <v-icon name="v-search" />
</v-date-picker>

<!-- 自动进位（选结束时间自动加24小时） -->
<v-date-picker v-model="dateRange" auto-carry></v-date-picker>
```

## shortcuts 配置

```javascript
shortcuts: [
  { text: '今天', value: [0, 0] },
  { text: '昨天', value: [-1, -1] },
  { text: '最近7天', value: [-7, -1] },
  { text: '最近30天', value: [-30, -1] },
  { text: '自定义', value: ['2017-3-3', new Date()] },
  { text: '全部时间', value: [] }
]
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| v-model | 开始和结束时间 | Array\<moment/string/number\> | 今天 |
| kind | 类型 | string | DateRangePanel/DatePanel |
| max-range | 最大跨度（天） | number | - |
| max-date | 可选最大日期（相对今天的天数，或绝对日期） | number/string/object | null |
| min-date | 可选最小日期 | number/string/object | null |
| disabled | 禁用 | boolean | false |
| clearable | 显示清除按钮 | boolean | false |
| isExpand | 默认展开 | boolean | false |
| shortcuts | 快捷方式配置 | Array | - |
| default-index | 默认选中快捷方式索引 | number | - |
| display-format | 显示格式 | string | YYYY-MM-DD |
| model-format | model格式（识别v-model值） | string | YYYY-MM-DD |
| placeholder | 占位文本 | string | - |
| enable-timer | 启用时间选择 | boolean | false |
| timer-config | timer-picker配置（enable-timer=true时生效） | Object | - |
| shortcuts-layout | shortcuts显示位置 | string/Array | stand |
| auto-carry | 自动进位（结束时间+24h，无时间选择时生效） | boolean | false |
| inline | 弹框DOM不移动到body | boolean | false |
| isIntervalTime | 启用区域间隔时间 | boolean | false |
| keep-selected-range | 选年/月时保留原选中数据 | boolean | false |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| confirm | 确认 | (date: moment) |
| cancel | 取消 | - |
| clear | 清除 | - |
| visibleChange | 显示/隐藏状态变化 | boolean |

## Slot

| Slot名称 | 说明 |
|----------|------|
| default | 自定义触发器 trigger |
