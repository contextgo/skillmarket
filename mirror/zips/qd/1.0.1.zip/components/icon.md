# v-icon 图标

## 基本用法

```html
<!-- 本地 SVG sprite（项目内注册的图标） -->
<v-icon name="icon-name" :size="20"></v-icon>

<!-- 远端图标库（推荐，使用 remote 属性） -->
<v-icon name="basic_search_line" remote></v-icon>
<v-icon name="basic_delete_line" remote :size="16" :style="{color: 'red'}"></v-icon>
<v-icon name="basic_setting_fill" remote :size="24"></v-icon>

<!-- 旋转 -->
<v-icon name="arrow_down_line" remote :rotate="90"></v-icon>
<v-icon name="arrow_down_line" remote :rotate="-90"></v-icon>

<!-- 翻转 -->
<v-icon name="v-search" flip="horizontal"></v-icon>
<v-icon name="v-search" flip="vertical"></v-icon>

<!-- 带 label（无障碍） -->
<v-icon name="basic_search_line" remote label="搜索"></v-icon>

<!-- 垂直对齐 -->
<v-icon name="basic_search_line" remote valign="middle"></v-icon>

<!-- 点击事件 -->
<v-icon name="basic_delete_line" remote @click="handleDelete"></v-icon>
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| name | 图标名称 | string | - |
| remote | 使用远端图标库 | boolean | false |
| size | 图标大小（px） | number/string | - |
| rotate | 旋转角度（deg） | number | - |
| flip | 翻转方向 | string | horizontal/vertical |
| label | 无障碍标签 | string | - |
| valign | 垂直对齐方式 | string | - |
| use-stroke | 使用 stroke 渲染 | boolean | false |
| scoped | 是否 scoped | boolean | false |

## 事件

| 事件名 | 说明 |
|--------|------|
| click | 点击事件 |
