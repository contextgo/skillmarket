# v-input 输入框

## 基本用法

```html
<!-- 默认类型 -->
<v-input v-model="value" placeholder="请输入" :limit="20" clearable :width="300"
  @change="handleChange" @enter="handleEnter"></v-input>

<!-- 禁用 -->
<v-input v-model="value" disabled></v-input>

<!-- 密码框 -->
<v-input v-model="password" password placeholder="请输入密码"></v-input>

<!-- 搜索框 -->
<v-input v-model="keyword" kind="search" placeholder="请搜索" realtimeSearch clearable></v-input>
<!-- 点击搜索按钮触发（安全替代 realtimeSearch） -->
<v-input v-model="keyword" kind="search" clickSearch></v-input>

<!-- 简单样式 -->
<v-input v-model="value" kind="simple" :limit="10" placeholder="请输入"></v-input>

<!-- 极简样式 -->
<v-input v-model="value" kind="simpler" :limit="10" placeholder="请输入"></v-input>

<!-- frame 样式（带后缀） -->
<v-input v-model="value" kind="frame" suffix="%" :limit="10"></v-input>

<!-- 带前后缀 -->
<v-input v-model="value" :prefix="prefixConfig" suffix=".com"></v-input>

<!-- 自定义左右 icon slot（仅 default 类型） -->
<v-input v-model="value">
  <template slot="left-icon"><v-icon name="v-error"></v-icon></template>
  <template slot="right-icon"><v-icon name="v-error"></v-icon></template>
</v-input>

<!-- 自定义字符长度计算 -->
<v-input kind="simple" limit="10" length-calculator="chinese"></v-input>
<v-input kind="simple" limit="10" :length-calculator="myCalculator"></v-input>

<!-- 自定义正则校验 -->
<v-input kind="simple" :reg="/^\d*\.?\d{0,3}$/" placeholder="精确到小数点后三位"></v-input>
```

## prefix/suffix 配置

```javascript
// 字符串类型（inline，不显示下拉框）
suffix: '.com'

// 对象类型（带下拉框）
prefix: {
  type: 'outline', // outline | inline
  options: [
    { text: 'http://', value: '1' },
    { text: 'https://', value: '2' }
  ],
  default: '2',
  isSearch: true,
  searchFilter(val, item) {
    return item.text.indexOf(val) !== -1;
  }
}
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value/v-model | 绑定值 | string | - | - |
| kind | 类型 | string | default/search/simple/simpler/frame | default |
| placeholder | 占位文本 | string | - | - |
| limit | 最大可提交字符长度 | number/string | - | - |
| maxlength | 最大可输入字符长度 | number/string | - | - |
| disabled | 禁用 | boolean | - | false |
| readonly | 只读 | boolean | - | false |
| autofocus | 自动获取焦点 | boolean | - | false |
| required | 显示必填样式 | boolean | - | false |
| password | 密码框 | boolean | - | false |
| clearable | 显示清除按钮（default/search类型） | boolean | - | true |
| realtimeSearch | 实时搜索（search类型，无搜索按钮） | boolean | - | false |
| clickSearch | 点击触发搜索（search类型，有搜索按钮） | boolean | - | false |
| prefix | 前缀 | object/string | - | - |
| suffix | 后缀 | object/string | - | - |
| reg | 自定义校验正则 | RegExp | - | null |
| length-calculator | 自定义字符长度计算规则 | string/function | 'default'/'chinese'/自定义函数 | 'default' |
| width | 宽度 | string/number | - | - |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | 绑定值改变时触发 | 新值 |
| change | 失焦后值有变化时触发 | 新值 |
| search | search类型，点击搜索图标或回车时触发 | 新值 |
| enter | 焦点在input上敲回车时触发 | Event |
| focus | 获得焦点 | Event |
| blur | 失焦 | Event |
| prefixChange | 前缀下拉框值改变 | 新前缀选项 |
| suffixChange | 后缀下拉框值改变 | 新后缀选项 |
