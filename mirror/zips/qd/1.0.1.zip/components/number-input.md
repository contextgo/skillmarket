# v-number-input 数字输入框

## 基本用法

```html
<!-- 默认极简模式 -->
<v-number-input v-model="value" placeholder="请输入数字"></v-number-input>

<!-- 只允许整数 -->
<v-number-input v-model="value" only-integer :default="100"></v-number-input>

<!-- 边框模式（限制输入位数，自动强制为整数） -->
<v-number-input kind="frame" maxlength="3" :default="100"></v-number-input>

<!-- 边框模式带后缀 -->
<v-number-input kind="frame" maxlength="3" :default="100" suffix="天"></v-number-input>

<!-- 步进模式（允许负值） -->
<v-number-input kind="step" negative :value="10"></v-number-input>

<!-- 步进模式（设置最大/最小值） -->
<v-number-input kind="step" :min="1" :max="100"></v-number-input>

<!-- 禁用 -->
<v-number-input kind="step" :min="1" :max="100" disabled></v-number-input>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| kind | 控件类型 | string | default/step/frame | default |
| value/v-model | 绑定值 | number | - | 0 |
| name | input 的 name 属性 | string | - | - |
| disabled | 禁用 | boolean | - | false |
| readonly | 只读 | boolean | - | false |
| step | 步进值（kind=step时生效） | number | - | 1 |
| min | 允许最小值 | number | - | - |
| max | 允许最大值 | number | - | - |
| maxlength | 最大输入长度（会强制为整数） | number/string | - | - |
| only-integer | 只允许整数 | boolean | - | false |
| negative | 允许负数 | boolean | - | false |
| autofocus | 自动获取焦点 | boolean | - | false |
| stepInputWidth | 步进模式输入框宽度 | number | - | 26 |
| suffix | frame 模式后缀 | string | - | '' |
