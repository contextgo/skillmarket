# v-dialog 弹窗

> ⚠️ **新业务必须使用新模态弹窗模式：`kind="modal" status="modal"`**

## 新模态弹窗（推荐）

```html
<!-- 含标题，单按钮（知道啦） -->
<v-dialog v-model="visible" kind="modal" status="modal" title="弹窗标题">
  <div slot="caption">副标题说明</div>
  <div>弹窗内容</div>
  <div slot="button-text">知道啦</div>
</v-dialog>

<!-- 无标题，双按钮（确认/取消） -->
<v-dialog v-model="visible" kind="modal" confirmText="删除" confirmKind="warning">
  <div>确认要删除吗？</div>
</v-dialog>

<!-- 无按钮（status="default"） -->
<v-dialog v-model="visible" kind="modal" status="default" title="提示">
  <div>内容</div>
</v-dialog>
```

## 老业务兼容（不推荐新业务使用）

```html
<!-- 默认弹窗 -->
<v-dialog v-model="visible" title="标题">
  <div slot="subtitle">副标题</div>
  <div>内容</div>
</v-dialog>

<!-- 操作确认弹窗 -->
<v-dialog v-model="visible" title="确认操作?" kind="confirm">
  <div>操作说明</div>
  <span slot="confirm-text">确认</span>
</v-dialog>

<!-- 警告确认弹窗 -->
<v-dialog v-model="visible" title="删除?" kind="confirm" status="warning">
  <span slot="confirm-text">删除</span>
</v-dialog>

<!-- 信息提示弹窗 -->
<v-dialog v-model="visible" title="提示内容" kind="alert"></v-dialog>

<!-- 成功提示弹窗 -->
<v-dialog v-model="visible" title="操作成功!" kind="alert" status="success">
  <div>详细说明</div>
</v-dialog>

<!-- 带 tips 的确认弹窗 -->
<v-dialog v-model="visible" title="确认操作" kind="confirm" status="primary">
  <div>操作说明</div>
  <div slot="tips">注意事项...</div>
</v-dialog>
```

## 快捷方法

```javascript
// $confirm
this.$confirm({
  title: '确定要删除吗？',
  content: '删除之后将无法恢复',
  status: 'warning',
  confirmText: '删除',
  cancelText: '取消',
  confirm(e) {
    e.preventDefault(); // 阻止默认关闭
    // 异步操作...
    dialog.showButtonLoading();
    setTimeout(() => dialog.$remove(), 3000);
  },
  cancel(e) { /* 取消回调 */ }
});

// $alert
this.$alert({
  title: '这是一条告警信息',
  content: '非常重要，不要忽视',
  status: 'warning',
  buttonText: '知道了'
});
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| open/v-model | 弹窗开关 | boolean | - | false |
| kind | 弹窗类型 | string | default/confirm/alert/modal | default |
| status | 弹窗状态（modal模式：modal=单按钮，default=无按钮，其余=双按钮） | string | primary/success/warning/default/modal | primary |
| title | 标题 | string | - | - |
| confirmText | 确定按钮文案 | string | - | 确定 |
| confirmKind | 确定按钮类型 | string | - | primary |
| cancelText | 取消按钮文案 | string | - | 取消 |
| disabled | 按钮和关闭icon禁用 | boolean | - | false |
| mask-closable | 点击蒙版关闭 | boolean | - | false |
| confirm-loading | 确认/取消按钮loading状态 | boolean | - | false |
| z-index | 自定义z-index | number/string | - | 2000 |

## Slot

| Slot名称 | 说明 |
|----------|------|
| default | 弹窗内容 |
| title | 标题区 |
| caption | 副标题（modal模式） |
| subtitle | 副标题（老模式） |
| footer | 按钮操作区 |
| tips | footer底部提示信息 |
| button-text | "知道啦"按钮文字（modal+status=modal时） |
| confirm-text | "确认"按钮文字（confirm/alert时） |
| cancel-text | "取消"按钮文字（confirm时） |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| show | 弹窗打开 | - |
| hide | 弹窗关闭 | - |
| input | 显示状态切换 | boolean |
| confirm | 确认按钮回调（kind=confirm时） | Event |
| cancel | 取消按钮回调（kind=confirm时） | Event |
| close | 右上角x或alert按钮回调 | Event |
