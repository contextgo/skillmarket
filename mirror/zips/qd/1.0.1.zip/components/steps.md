# v-steps 步骤条

## 基本用法

```html
<!-- 默认步骤条（3步） -->
<v-steps></v-steps>

<!-- 指定当前步骤 -->
<v-steps :index="2"></v-steps>

<!-- 自定义标题 -->
<v-steps :titles="['填写企业信息', '填写账户信息', '完成']" :index="currentStep"></v-steps>

<!-- 自定义步骤数量 -->
<v-steps :titles="['一', '二', '三', '四']" :index="1"></v-steps>
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| titles | 每一步骤的文字描述 | Array\<string\> | ['步骤一', '步骤二', '步骤三'] |
| index | 当前步骤索引（从1开始） | number | 1 |
