# v-radio / v-radio-group 单选框

> `v-radio` 必须和 `v-radio-group` 一起使用

## 基本用法

```html
<!-- 横向排列（默认） -->
<v-radio-group v-model="selected">
  <v-radio name="type" value="1">选项1</v-radio>
  <v-radio name="type" value="2">选项2</v-radio>
  <v-radio name="type" value="3" disabled>选项3（禁用）</v-radio>
</v-radio-group>

<!-- 垂直排列 -->
<v-radio-group v-model="selected" vertical>
  <v-radio name="type" value="1">选项1</v-radio>
  <v-radio name="type" value="2">选项2</v-radio>
</v-radio-group>

<!-- 按钮样式 -->
<v-radio-group v-model="selected" kind="button">
  <v-radio name="type" value="1">选项1</v-radio>
  <v-radio name="type" value="2">选项2</v-radio>
  <v-radio name="type" value="3" disabled>选项3</v-radio>
</v-radio-group>

<!-- 带图标的按钮样式 -->
<v-radio-group v-model="selected" kind="button">
  <v-radio name="type" value="1" icon="basic_setting_fill">选项1</v-radio>
  <v-radio name="type" value="2" icon="basic_setting_fill">选项2</v-radio>
</v-radio-group>

<!-- 只有图标（无文字） -->
<v-radio-group v-model="selected" kind="button">
  <v-radio name="type" value="1" icon="basic_setting_fill"></v-radio>
</v-radio-group>

<!-- 只有 label（无 slot） -->
<v-radio-group v-model="selected" kind="button">
  <v-radio name="type" value="广州" label="广州"></v-radio>
</v-radio-group>
```

## v-radio-group 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value/v-model | 选中值 | string/number | - | - |
| kind | 样式类型 | string | primary/button | primary |
| vertical | 垂直展示（button模式无效） | boolean | - | false |

## v-radio 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value | 当前 radio 的值 | string/number | - |
| name | 原生 name 属性 | string | - |
| checked | 是否选中 | boolean | false |
| disabled | 禁用 | boolean | false |
| icon | 图标名称 | string | - |
| label | 文本（有值时 slot 失效） | string | - |
| remote | 是否使用远端图标库 | boolean | true |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | 选项修改时触发 | value |
| change | 同 input | value |
