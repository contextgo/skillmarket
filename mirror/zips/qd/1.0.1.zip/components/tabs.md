# v-tabs / v-tab 标签页

## 基本用法

```html
<!-- 默认样式（通过 index 控制） -->
<v-tabs v-model="activeIndex">
  <v-tab>选项1</v-tab>
  <v-tab>选项2</v-tab>
</v-tabs>

<!-- 通过 value 控制（推荐，使用 v-if 时必须设置 value） -->
<v-tabs v-model="activeTab">
  <v-tab value="tab1">选项1</v-tab>
  <v-tab value="tab2">选项2</v-tab>
</v-tabs>

<!-- 居中对齐 -->
<v-tabs v-model="activeTab" align="center">
  <v-tab value="tab1">选项1</v-tab>
  <v-tab value="tab2">选项2</v-tab>
</v-tabs>

<!-- line 样式 -->
<v-tabs v-model="activeTab" kind="line">
  <v-tab value="tab1">选项1</v-tab>
  <v-tab value="tab2">选项2</v-tab>
</v-tabs>

<!-- view 样式 -->
<v-tabs v-model="activeTab" kind="view">
  <v-tab value="tab1">选项1</v-tab>
  <v-tab value="tab2">选项2</v-tab>
</v-tabs>

<!-- 设置第一个 tab 到左侧的距离 -->
<v-tabs v-model="activeTab" :indent="20">
  <v-tab value="tab1">选项1</v-tab>
</v-tabs>
```

## v-tabs 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value/v-model | 选中 tab 的 value | string/number | - | - |
| kind | 标签页类型 | string | default/line/view | default |
| align | 对齐方式（kind=line/view时居中不生效） | string | left/center | left |
| indent | 第一个 tab 到最左侧的距离（px） | string/number | - | - |

## v-tab 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value | tab 的值（使用 v-if 时必须设置） | string/number | tab的index |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | 选中 tab 改变时触发 | 选中 tab 的值或 index |
| change | 同 input | 选中 tab 的值或 index |
