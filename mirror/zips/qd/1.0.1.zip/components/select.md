# v-select 下拉选择器

## 基本用法

```html
<!-- 基本用法，options 格式：[{text, value}] -->
<v-select v-model="selected" :options="options" placeholder="请选择"></v-select>

<!-- 带清空按钮 -->
<v-select v-model="selected" :options="options" clearable></v-select>

<!-- 禁用 -->
<v-select :options="options" disabled></v-select>

<!-- 无边框样式 -->
<v-select :options="options" kind="simple" auto-width></v-select>

<!-- 带搜索 -->
<v-select :options="options" isSearch keyBoardSelect></v-select>

<!-- 多选 -->
<v-select :options="options" multiple v-model="selectedArr"></v-select>

<!-- 设置初始选中项（通过 value） -->
<v-select :options="options" v-model="defaultValue"></v-select>
<!-- 设置初始选中项（通过 index，优先级最高） -->
<v-select :options="options" :index="0"></v-select>

<!-- 长列表懒加载（大数据场景） -->
<v-select :options="optionsLong" use-scroll-list :scrollListProps="{max: 30}"></v-select>

<!-- 自定义字段映射 -->
<v-select :options="options" :maps="{text: 'label', value: 'key', disabled: 'non'}"></v-select>

<!-- 自定义 item 模板 -->
<v-select kind="popup" :options="options" v-model="selected">
  <template slot="item" slot-scope="props">
    <div>{{ props.item.text }} - {{ props.item.value }}</div>
  </template>
</v-select>

<!-- 自定义 header（选中后显示的内容） -->
<v-select kind="popup" :options="options" v-model="selected">
  <template slot="header" slot-scope="props">
    <div>{{ props.item.text }}</div>
  </template>
</v-select>

<!-- 自定义下拉区域 -->
<v-select kind="popup" :options="options">
  <template slot="optionsContainer">
    <div>自定义下拉内容</div>
  </template>
</v-select>

<!-- 自定义无数据提示 -->
<v-select :options="[]">
  <template slot="nodata">暂无选项哦~</template>
</v-select>

<!-- 严格模式（自动过滤不合法的 value） -->
<v-select :options="options" v-model="value" :strictMode="true"></v-select>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value/v-model | 绑定值 | string/Array | - | - |
| options | 选项列表 | array [{text, value}] | - | - |
| kind | 类型 | string | basic/popup/simple | basic |
| multiple | 多选 | boolean | - | false |
| disabled | 禁用 | boolean | - | false |
| clearable | 显示清除按钮 | boolean | - | false |
| placeholder | 占位文本 | string | - | 请选择 |
| isSearch | 搜索模式 | boolean | - | false |
| keyBoardSelect | 键盘上下键切换 | boolean | - | false |
| searchFilter | 自定义搜索过滤函数 | function(val, item) | - | - |
| index | 选中项索引（优先级高于 value） | number/Array | - | - |
| maps | 字段映射 | Object | - | {text:'text',value:'value',disabled:'disabled'} |
| max-height | 下拉最大高度 | number | - | - |
| strict-mode | 严格模式，自动过滤不合法 value | boolean | - | false |
| use-scroll-list | 大数据懒加载 | boolean | - | false |
| scroll-list-props | scroll-list 透传参数 | Object | - | {} |
| auto-width | 宽度自适应 | boolean | - | false |
| popper-clazz | 弹出层 class | string | - | - |
| inline | 是否加载在 dom 里（默认 append 到 body） | boolean | - | false |

## Slot

| Slot名称 | 说明 |
|----------|------|
| placeholder | 自定义无选中值时的 header 显示 |
| optionsContainer | 自定义下拉区域内容 |
| item (scoped) | 自定义下拉列表项，props.item 获取选项，props.selected 是否选中 |
| header (scoped) | 自定义选中后 header 显示，props.item 获取选项 |
| nodata | 无数据时显示 |
| customOptions | 自定义选项（插入到列表末尾） |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | value 变化 | - |
| change | value 变化 | - |
| select | 选中变化 | value, option, current |
| visibleChange | 下拉显示/隐藏 | boolean |
| clear | 清除操作 | - |
