# v-tags-input 标签输入

## 基本用法

```html
<!-- 基础用法 -->
<v-tags-input v-model="tags" placeholder="请输入标签，回车确认"></v-tags-input>

<!-- 只读模式（带状态颜色） -->
<v-tags-input
  v-model="tags"
  :readonly="true">
</v-tags-input>

<!-- 带校验（以邮箱为例） -->
<v-tags-input v-model="emails" @change="validateEmails"></v-tags-input>
```

```javascript
// tags 数据格式
tags: [
  { name: '北京' },
  { name: '上海', status: 'error' },    // 错误状态（红色）
  { name: '广东', status: 'primary' },  // 主色状态（蓝色）
  { name: '深圳', status: 'success' }   // 成功状态（绿色）
]

// 邮箱校验示例
methods: {
  validateEmails(emails) {
    const regEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
    emails.forEach(item => {
      if (!regEmail.test(item.name)) {
        item.status = 'error';
      }
    });
  }
}
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value/v-model | 绑定值 | Array\<{name, status}\> | [] |
| splitFlags | 分隔符 | Array | ['，','；','、',' ','/','\-','\|'] |
| readonly | 只读 | boolean | false |
| placeholder | 占位文本 | string | - |
| maxLength | 最大标签数量 | number | - |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| change | 绑定值改变时触发 | 新的绑定值 |

## 方法

| 方法名 | 说明 | 参数 | 返回值 |
|--------|------|------|--------|
| getSelected(index) | 指定 tag 是否被选中 | index（从1开始） | boolean |
| getSelectedTagsText() | 获取所有选中 tag 的文本 | - | - |
| selectAllTagHandle() | 全选所有 tag | - | - |
| blurHandle() | 取消全选 | - | - |
| deleteMultiHandle() | 删除所有选中的 tag | - | - |
