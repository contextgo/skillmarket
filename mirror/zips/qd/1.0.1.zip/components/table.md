# v-table 表格

## 基本用法

```html
<!-- 基础表格（通过 columns 配置） -->
<v-table :data="tableData" :columns="columns" :height="400">
</v-table>

<!-- 使用 v-table-column 插槽自定义列 -->
<v-table :data="tableData" :columns="columns">
  <v-table-column label="姓名" column-key="name" :width="180" fixed></v-table-column>
  <v-table-column label="操作" :width="120">
    <template slot-scope="props">
      <v-button type="link" kind="primary" @click="handleEdit(props.row)">编辑</v-button>
      <v-button type="link" kind="warning" @click="handleDelete(props.row)">删除</v-button>
    </template>
  </v-table-column>
</v-table>

<!-- 固定列 -->
<v-table :data="tableData" :columns="columns" :height="300">
  <v-table-column label="操作" :width="120" fixed="right">
    <template slot-scope="props">
      <v-button type="link" kind="primary">操作</v-button>
    </template>
  </v-table-column>
</v-table>

<!-- 树形表格 -->
<v-table :data="treeData" :columns="columns" tree-table></v-table>

<!-- 子表格（展开行） -->
<v-table :data="tableData" :columns="columns">
  <template slot="sub-table" slot-scope="props">
    <v-table :data="props.row.children" :columns="subColumns"></v-table>
  </template>
</v-table>
```

## columns 配置

```javascript
columns: [
  {
    label: '姓名',
    columnKey: 'name',
    width: 180,
    fixed: true,           // 固定列（left/right/true=left）
    align: 'center',       // 对齐方式：left/center/right
    sortable: true,        // 是否可排序
    formatter(val, row) {  // 自定义格式化
      return val + '同学';
    }
  },
  {
    label: '日期',
    columnKey: 'date',
    sortable: true,
    formatter: (val) => new Date(val).toLocaleDateString()
  },
  {
    label: '状态',
    columnKey: 'status',
    // 自定义渲染（render函数）
    render(h, { row }) {
      return h('span', { style: { color: row.status === 1 ? 'green' : 'red' } }, row.status === 1 ? '正常' : '异常');
    }
  }
]
```

## v-table 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| data | 表格数据 | Array | [] |
| columns | 列配置 | Array | [] |
| height | 表格高度（超出滚动） | number/string | - |
| loading | 加载状态 | boolean | false |
| empty-text | 无数据时的提示文字 | string | 暂无数据 |
| tree-table | 树形表格模式 | boolean | false |
| row-key | 树形表格行唯一标识字段 | string | id |
| children-key | 树形表格子节点字段 | string | children |
| stripe | 斑马纹 | boolean | false |
| border | 边框 | boolean | false |
| show-header | 是否显示表头 | boolean | true |
| default-sort | 默认排序 | Object {key, order} | - |

## v-table-column 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| label | 列标题 | string | - |
| column-key | 数据字段名 | string | - |
| width | 列宽（px） | number/string | - |
| min-width | 最小列宽 | number/string | - |
| fixed | 固定列 | boolean/string | false |
| align | 对齐方式 | string | left |
| sortable | 是否可排序 | boolean | false |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| sort-change | 排序改变 | {key, order} |
| row-click | 行点击 | row |
| selection-change | 选中行改变 | selectedRows |
