# v-collapse 折叠面板

## 基本用法

```html
<!-- 多项展开 -->
<v-collapse v-model="activeValues">
  <v-collapse-item text="标题1" :value="1" @expanded="onVisibleChange">
    <div slot="content"><p>内容1</p></div>
  </v-collapse-item>
  <v-collapse-item text="标题2" :value="2" :disabled="true">
    <div slot="content"><p>内容2（禁用）</p></div>
  </v-collapse-item>
  <v-collapse-item text="标题3" :value="3">
    <div slot="content"><p>内容3</p></div>
  </v-collapse-item>
</v-collapse>

<!-- 手风琴模式（每次只展开一项） -->
<v-collapse accordion v-model="activeValue">
  <v-collapse-item text="标题1" :value="1">
    <div slot="content"><p>内容1</p></div>
  </v-collapse-item>
  <v-collapse-item text="标题2" :value="2">
    <!-- 自定义 header -->
    <div slot="header"><span>自定义头：</span><span>标题2</span></div>
    <div slot="content"><p>内容2</p></div>
  </v-collapse-item>
</v-collapse>
```

## v-collapse 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value/v-model | 展开项的值数组 | Array | - |
| accordion | 手风琴模式 | boolean | false |

## v-collapse-item 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| text | 头部文字（不定义 header slot 时有效） | string | - |
| value | 当前项的值 | number | - |
| disabled | 禁用展开/收起 | boolean | false |

## v-collapse-item Slot

| Slot名称 | 说明 |
|----------|------|
| header | 自定义面板头部 |
| content | 面板内容 |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | value 变化 | - |
| change | 面板收起/展开变化 | - |
| expanded（绑定在 item 上） | 展开状态变化 | (visible: boolean, index: number) |
