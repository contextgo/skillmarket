# v-spinner 加载中

## 基本用法

```html
<!-- 四种状态 × 三种大小 -->
<v-spinner status="default"></v-spinner>
<v-spinner status="default">加载中..</v-spinner>
<v-spinner status="primary"></v-spinner>
<v-spinner status="primary">加载中..</v-spinner>
<v-spinner status="success"></v-spinner>
<v-spinner status="warning"></v-spinner>

<!-- 中等大小 -->
<v-spinner status="primary" size="medium">加载中..</v-spinner>

<!-- 大尺寸 -->
<v-spinner status="primary" size="large">加载中..</v-spinner>

<!-- 指令方式：覆盖某块区域 -->
<div v-spinner="isLoading">
  这里是数据内容
  <v-spinner :opacity="0.5">加载中...</v-spinner>
</div>

<!-- 指令方式：指定 spinner id（区分多个） -->
<div v-spinner:loading="isLoading">
  这里是数据内容
  <v-spinner id="loading" size="large" offset-x="10%" :offset-y="100"></v-spinner>
</div>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| status | 样式类型 | string | default/primary/warning/success | default |
| size | 大小 | string | small/medium/large | small |
| opacity | 背景蒙版透明度 | number | 0-1 | 1 |
| offset-x | 水平偏移 | string/number | 百分比/像素值 | 50% |
| offset-y | 垂直偏移 | string/number | 百分比/像素值 | 50% |
