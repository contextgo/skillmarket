# v-badge 徽标

## 基本用法

```html
<!-- 数字徽标 -->
<v-badge :value="12">
  <v-button>消息</v-button>
</v-badge>

<!-- 带最大值 -->
<v-badge :value="200" :max="99">
  <v-button>消息</v-button>
</v-badge>

<!-- 不同类型 -->
<v-badge :value="1" type="primary"><v-button>主色</v-button></v-badge>
<v-badge :value="2" type="warning"><v-button>警告</v-button></v-badge>
<v-badge :value="3" type="success"><v-button>成功</v-button></v-badge>

<!-- 自定义文字 -->
<v-badge value="new"><v-button>消息</v-button></v-badge>
<v-badge value="hot"><v-button>邮箱</v-button></v-badge>

<!-- 小红点 -->
<v-badge is-dot>开源节流</v-badge>
<v-badge is-dot><v-button>人工智能</v-button></v-badge>

<!-- 隐藏 -->
<v-badge :value="12" :hidden="true"><v-button>消息</v-button></v-badge>

<!-- 独立使用（不包裹元素） -->
<span>消息<v-badge :value="12" /></span>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value | 显示值 | string/number | - | - |
| max | 最大值（超出显示 max+，仅 value 为 number 时生效） | number | - | - |
| is-dot | 小圆点模式 | boolean | - | false |
| hidden | 隐藏 badge | boolean | - | false |
| type | 类型 | string | primary/success/warning/default | - |
