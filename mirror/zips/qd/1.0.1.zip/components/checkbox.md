# v-checkbox / v-checkbox-group 复选框

## 基本用法

```html
<!-- 单个复选框 -->
<v-checkbox v-model="checked" label="同意协议"></v-checkbox>
<v-checkbox v-model="checked" disabled label="禁用状态"></v-checkbox>

<!-- 使用 slot 作为描述 -->
<v-checkbox v-model="checked">自定义描述内容</v-checkbox>

<!-- 复选框组 -->
<v-checkbox-group v-model="selectedArr">
  <v-checkbox v-for="item in list" :key="item.value" :value="item.value">{{ item.label }}</v-checkbox>
</v-checkbox-group>

<!-- 垂直排列 -->
<v-checkbox-group v-model="selectedArr" vertical>
  <v-checkbox v-for="item in list" :key="item.value" :value="item.value">{{ item.label }}</v-checkbox>
</v-checkbox-group>

<!-- 全选 + 半选（indeterminate） -->
<v-checkbox
  v-model="isAll"
  :indeterminate="isIndeterminate"
  label="全选"
  @change="handleAllChange">
</v-checkbox>
<v-checkbox-group v-model="selectedArr" @change="handleGroupChange">
  <v-checkbox v-for="item in list" :key="item.value" :value="item.value">{{ item.label }}</v-checkbox>
</v-checkbox-group>
```

```javascript
methods: {
  handleGroupChange(value) {
    this.isIndeterminate = value.length > 0 && value.length < this.list.length;
    this.isAll = value.length === this.list.length;
  },
  handleAllChange(value) {
    this.selectedArr = value ? this.list.map(i => i.value) : [];
  }
}
```

## v-checkbox 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value | 原生 input value | boolean/string | false |
| checked/v-model | 勾选状态 | boolean | false |
| disabled | 禁用 | boolean | false |
| label | 无 slot 时的描述文字 | string | - |
| indeterminate | 半选状态 | boolean | false |
| name | 原生 name 属性 | string | - |

## v-checkbox-group 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| value/v-model | 选中值数组 | Array | [] |
| vertical | 垂直展示 | boolean | false |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| change | 状态改变时触发 | 新值 |
