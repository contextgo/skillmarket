# v-form 表单

> ⚠️ **必须使用 `kind="desc"`，直接子组件必须使用 `v-form-item`**

## 基本用法

```html
<v-form kind="desc" size="small" ref="form" :model="formData" @submit="handleSubmit">
  <v-form-item name="email" label="邮箱" required="邮箱必填" :rules="rules.email" desc="邮箱仅用于登录">
    <v-input v-model="formData.email" placeholder="请输入邮箱" style="width:400px;"></v-input>
  </v-form-item>
  <v-form-item name="password" label="密码" required="密码必填" :rules="rules.password" error-placement="bottom">
    <v-input v-model="formData.password" password placeholder="请输入密码" style="width:400px;"></v-input>
  </v-form-item>
  <v-form-item name="education" label="学历" :rules="rules.education">
    <v-select v-model="formData.education" :options="educationOptions"></v-select>
  </v-form-item>
  <v-form-item name="hobbies" label="兴趣爱好" required="请选择" :rules="rules.hobbies">
    <v-checkbox-group v-model="formData.hobbies">
      <v-checkbox v-for="item in hobbies" :key="item.value" :value="item.value">{{item.label}}</v-checkbox>
    </v-checkbox-group>
  </v-form-item>
  <v-form-item>
    <v-button type="submit" kind="primary">提交</v-button>
  </v-form-item>
</v-form>
```

## Ajax 提交

```html
<v-form ref="form" kind="desc" size="small" @submit="doAjaxSubmit">
  <v-form-item name="email" label="邮箱" required="邮箱必填" :rules="rules.email">
    <v-input placeholder="请输入邮箱" style="width:400px;"></v-input>
  </v-form-item>
  <v-form-item>
    <v-button type="submit" kind="primary" :loading="loading">登录</v-button>
    <!-- 自定义 trigger 提交 -->
    <v-button kind="primary" @click="$refs.form.submit('custom')">自定义提交</v-button>
  </v-form-item>
</v-form>
```

```javascript
methods: {
  doAjaxSubmit(e) {
    e.preventDefault();
    this.loading = true;
    const params = this.$refs.form.params();
    // 发起请求...
  }
}
```

## 自定义 label slot

```html
<v-form-item name="email" label="邮箱" required="邮箱必填" :rules="rules.email">
  <template slot="label" slot-scope="prop">
    <span v-if="prop.required">*</span>{{prop.label}}
  </template>
  <v-input placeholder="请输入邮箱"></v-input>
</v-form-item>
```

## 验证规则示例

```javascript
rules: {
  email: [
    { email: true, message: '请输入正确的邮箱地址', trigger: 'change' }
  ],
  password: [
    { required: true, trim: false },
    { minLength: 6, message: '密码不能小于6个字符', trim: false }
  ],
  password2: [
    { required: true, trim: false },
    { equalTo: 'password', message: '两次输入的密码不一致' }
  ],
  username: [
    { betweenLength: [4, 20], message: '用户名必须在4-20个字符之间' },
    { validate: /^[0-9a-zA-Z_]+$/, message: '只能包含英文、数字、下划线' }
  ],
  age: [
    { between: [1, 120], message: '年龄必须在1-120之间' }
  ],
  score: [
    { max: 100, message: '不能大于100' },
    { min: 0, message: '不能小于0' }
  ],
  // 自定义函数验证
  custom: [
    {
      validate(value, rule, allValue) {
        return value !== 'forbidden';
      },
      message: '不能使用该值'
    }
  ],
  // 异步验证
  asyncField: [
    {
      validate(value) {
        return fetch('/api/check?value=' + value).then(res => {
          if (!res.ok) throw new Error('验证失败');
        });
      },
      message: '验证失败',
      trigger: 'blur'
    }
  ]
}
```

## 内置验证规则

| 规则名 | 参数类型 | 说明 |
|--------|----------|------|
| required | boolean | 必填 |
| email | boolean | 邮箱格式 |
| url | boolean | URL格式 |
| ip | boolean | IP格式 |
| max | number | 不能大于某数 |
| min | number | 不能小于某数 |
| between | Array\<number\> | 数字区间 [min, max] |
| maxLength | number | 最大字符长度 |
| minLength | number | 最小字符长度 |
| betweenLength | Array\<number\> | 字符长度区间 |
| equalTo | string | 与另一个字段值相同 |
| validate | RegExp/function | 自定义验证 |

## v-form 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| kind | 表单类型 | string | default/inline/naked/desc | default |
| size | label大小（kind=desc时有效） | string | medium/small/short | medium |
| col | 表单列数（kind=desc时有效） | number | - | 1 |
| layout | 布局（kind=desc时有效） | string | horizontal/vertical | horizontal |
| model | 表单数据对象 | Object | - | - |
| action | 表单提交地址 | string | - | - |
| method | 表单method | string | GET/POST/PUT/DELETE | POST |

## v-form 方法

| 方法名 | 说明 | 参数 |
|--------|------|------|
| submit | 主动触发提交，可指定自定义 trigger | customTrigger(string) |
| focus | focus 到第一个可 focus 的组件 | - |
| focusError | focus 到第一个出错的组件 | - |
| params | 获取表单内所有数据 | - |

## v-form-item 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| name | 表单项 name | string | - | - |
| label | label 文字 | string | - | - |
| required | 必填（可传错误提示文字） | boolean/string | - | false |
| rules | 验证规则 | Array\<Object\> | - | - |
| desc | 补充描述（kind=desc时有效） | string | - | - |
| error | 错误信息（可 v-model 双向绑定） | string | - | '' |
| error-placement | 错误位置 | string | top-left/top-right/bottom/none | top-left |

## v-form-item Slot

| Slot名称 | 说明 |
|----------|------|
| default | 存放输入组件 |
| desc | 描述信息 |
| label (scoped) | 自定义 label，props: {required, label} |
| description-text (scoped) | label 内容区 |
| description-desc (scoped) | label 说明区 |

## v-form-input（自定义输入组件辅助）

```html
<!-- 用于非标准输入组件与 form 集成 -->
<v-form-input name="tags" v-model="tagsValues"></v-form-input>
<v-tags-input v-model="tagsValues"></v-tags-input>
```
