# v-pagination 分页

## 基本用法

```html
<!-- 基础分页 -->
<v-pagination :total="100" :index="currentPage" :count="15" @change="handlePageChange"></v-pagination>

<!-- 带快速跳转 -->
<v-pagination :total="100" :index="currentPage" :count="15" showQuick @change="handlePageChange"></v-pagination>

<!-- 带每页条数选择 -->
<v-pagination
  :total="total"
  :index="currentPage"
  :count="pageSize"
  :count-options="[10, 20, 50, 100]"
  showQuick
  @change="handlePageChange">
</v-pagination>
```

```javascript
methods: {
  handlePageChange(current, size) {
    this.currentPage = current;
    this.pageSize = size;
    // 重新加载数据...
  }
}
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| total | 总条数 | number | - |
| index | 当前页码（从1开始） | number | 1 |
| count | 每页条数 | number | 10 |
| count-options | 每页条数选项（有值时显示切换器） | Array\<number\> | - |
| show-quick | 显示快速跳转 | boolean | false |
| visible-count | 显示的页码数量 | number | 5 |
| limit | 最大页码数量 | number | - |
| show-first | 显示第一页按钮 | boolean | false |
| show-last | 显示最后一页按钮 | boolean | false |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| change | 页码或每页条数改变时触发 | (current: number, size: number) |
