# v-message 消息提示

## 基本用法

```javascript
// 实例方法（在 Vue 组件内使用）
this.$message.success('操作成功');
this.$message.error('操作失败');
this.$message.warning('警告信息');
this.$message.normal('普通消息');
this.$message.tips('提示消息');

// 带回调和自定义时长
this.$message.success('操作成功', callback, 3000);
this.$message.error('操作失败', null, 5000);

// 指定显示位置
this.$message.warning('警告信息', null, 5000, 'mid');

// duration=0 不自动关闭
this.$message.success('持续显示', null, 0);

// 静态方法（在非 Vue 组件中使用）
import { Message } from 'vhtml';
Message.success('成功');
Message.error('错误');
Message.warning('警告');
Message.normal('普通');
Message.tips('提示');
```

## 参数说明

```javascript
// 完整参数
this.$message.success(
  content,    // string - 消息内容
  onClose,    // function - 关闭回调
  duration,   // number - 显示时长(ms)，默认2000，0=不自动关闭
  position    // string - 位置：'top'(默认)/'mid'/'bottom'
);
```

## 消息类型

| 方法 | 说明 |
|------|------|
| success | 成功消息（绿色） |
| error | 错误消息（红色） |
| warning | 警告消息（黄色） |
| normal | 普通消息（灰色） |
| tips | 提示消息 |
