# v-empty 空状态

## 基本用法

```html
<!-- 默认空状态（跟随父容器宽高100%，水平垂直居中） -->
<v-empty />

<!-- 不同图片大小 -->
<v-empty size="medium" />
<v-empty size="small" />

<!-- 无图片（单行状态） -->
<v-empty image="" />

<!-- 自定义图片 -->
<v-empty image="https://example.com/img.png" />
<v-empty image="default_collection_blue" />

<!-- 自定义标题+描述 -->
<v-empty title="这是一个标题" desc="已经没有了" />

<!-- 描述区混排文字和按钮 -->
<v-empty :desc="['没有数据了', {type: 'link', size: 'small', kind: 'primary', label: '刷新', click: handleRefresh}, '试试']" />

<!-- 带操作按钮 -->
<v-empty
  title="重点提示文案"
  desc="没有数据时，可提供下一步操作行为"
  :button="{ kind: 'primary', label: '刷新重试', click: handleRefresh }" />

<!-- 多个操作按钮 -->
<v-empty
  desc="没有数据时，可提供多个操作行为"
  :button="[
    { label: '取消返回', click: handleCancel },
    { label: '禁止操作', disabled: true },
    { kind: 'primary', label: '刷新重试', click: handleRefresh }
  ]" />
```

## 内置异常状态

```html
<!-- 通用错误 -->
<v-empty image="default_internet" desc="服务异常，请稍后再试" :button="{ label: '刷新重试', click: handleRefresh }" />

<!-- 无权限 403 -->
<v-empty image="default_permissions" desc="您没有权限访问该服务，请联系管理员开通" :button="{ kind: 'primary', label: '联系管理员', click: handleContact }" />

<!-- 404 -->
<v-empty image="default_404" desc="当前页面不存在" :button="{ label: '返回首页', click: handleBack }" />
```

## 自定义 Slot

```html
<v-empty title="重要提示" desc="哦呵，没查询到任何数据！">
  <div slot="image">
    <img src="/custom-img.png" style="width: 300px;" />
  </div>
  <div slot="button">请联系管理员开通，然后点击 <v-button>刷新</v-button></div>
</v-empty>
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| image | 图片地址（支持远程icon名称和网络图片） | string | 空状态默认图标 |
| size | 图片大小 | string | small/medium/large |
| title | 标题内容 | string | - |
| desc | 描述内容（支持字符串和按钮对象组合） | string/Array | 暂无内容 |
| button | 按钮配置（支持单个对象或数组） | Object/Array | - |

## Slot

| Slot名称 | 说明 |
|----------|------|
| default | 同描述区 desc |
| image | 图片区 |
| title | 标题区 |
| desc | 描述区 |
| button | 按钮区 |
