# v-uploader 文件上传

## 基本用法

```html
<!-- 基础款 -->
<v-uploader
  url="/api/upload"
  name="file"
  tip-text="只支持 .jpg 和 .png 格式"
  @error="handleError"
  @complete="handleComplete">
</v-uploader>

<!-- 多文件上传 -->
<v-uploader
  url="/api/upload"
  :multiple="true"
  name="file"
  @error="handleError"
  @complete="handleComplete">
</v-uploader>

<!-- 自定义触发器 + 手动上传 -->
<v-uploader
  url="/api/upload"
  :multiple="true"
  name="file"
  :auto-upload="false"
  @success="handleSuccess"
  @error="handleError"
  @fileschange="handleFileChange">
  <a href="javascript:">自定义选择文件</a>
  <v-button slot="manualSubmitter">提交上传</v-button>
</v-uploader>

<!-- 可拖拽上传 -->
<v-uploader
  url="/api/upload"
  :draggable="true"
  size-limit="4MB"
  type-limit="*.jpg;*.png">
</v-uploader>

<!-- 自定义拖拽区域 -->
<v-uploader
  url="/api/upload"
  :draggable="true"
  :show-list="false"
  :auto-upload="false">
  <div>拖拽文件到此处</div>
</v-uploader>
```

## 属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| url | 上传目标地址 | string | - |
| name | input 的 name 属性 | string | - |
| form-key | formdata 的 key 值 | string | fileToUpload |
| tip-text | 用户提示文字 | string | - |
| size-limit | 文件大小限制 | string | 2MB |
| type-limit | 文件类型限制 | string | *.jpg;*.gif;*.jpeg;*.png;*.bmp |
| auto-upload | 选完文件后自动上传 | boolean | true |
| multiple | 支持多文件上传 | boolean | false |
| show-progress | 显示上传进度条 | boolean | true |
| show-list | 显示选中文件列表 | boolean | true |
| show-error-tip | 显示每个文件的错误信息 | boolean | true |
| draggable | 支持拖拽选择文件 | boolean | false |
| disabled | 禁用 | boolean | false |

## Slot

| Slot名称 | 说明 |
|----------|------|
| default | 文件选择触发节点 |
| manualSubmitter | 手动触发上传的节点 |
| errorOfEach | 每个文件上传失败的错误信息节点 |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| complete | 上传完成（推荐使用） | {file, status(0-4), data} |
| start | 上传开始 | file |
| progress | 上传进度改变 | file, origin |
| cancel | 上传取消 | file |
| fileschange | 选中文件改变 | 文件数组 |
| fileremove | 删除选中文件 | file |
| success | 上传成功（不推荐） | - |
| error | 上传出错（不推荐） | - |

## 方法

| 方法名 | 说明 | 参数 |
|--------|------|------|
| resetValueForForm | 修改内部隐藏 input 的 value | (file, value) |
| removeFile | 删除 fileList 中某个文件 | file（不传则清空） |
