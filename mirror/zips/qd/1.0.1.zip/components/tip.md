# v-tip 提示气泡

## 基本用法

```html
<!-- 1. 定义 tip 内容 -->
<v-tip ref="myTip" placement="top" kind="small">
  <span>这里是提示内容</span>
</v-tip>

<!-- 2. 绑定触发元素 -->
<!-- hover 触发 -->
<v-button v-tip:myTip.hover>hover 触发</v-button>
<!-- 点击触发 -->
<v-button v-tip:myTip.click.stop>点击触发</v-button>
<!-- 默认展示 -->
<v-button v-tip:myTip.show>默认展示</v-button>
<!-- focus 触发 -->
<v-input v-tip:myTip.focus>focus 触发</v-input>

<!-- 延迟消失（鼠标可移入 tip 内容区） -->
<div v-tip:myTip.hover.delay500>hover 延迟消失</div>

<!-- 动态内容（slot-scope） -->
<v-tip ref="dynTip">
  <template slot-scope="props">{{ props.data }}</template>
</v-tip>
<v-button v-tip:dynTip="'动态内容'">按钮</v-button>

<!-- 通过 content 属性设置内容 -->
<v-tip ref="contentTip" content="这是提示内容"></v-tip>
<v-button v-tip:contentTip.hover>按钮</v-button>

<!-- 禁用 -->
<v-tip ref="disabledTip" content="提示" :disabled="true"></v-tip>
<v-button v-tip:disabledTip.hover>按钮</v-button>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| kind | 大小类型 | string | large/small/tiny | large |
| placement | 弹出位置 | string | top/top-start/top-end/bottom/bottom-start/bottom-end/left/left-start/left-end/right/right-start/right-end | top |
| content | 提示内容（有 slot 时 content 无效） | string | - | - |
| offset | 偏移量（px） | number | - | 0 |
| gap | 与触发元素的间距（px） | number | - | 8 |
| disabled | 禁用 | boolean | - | false |
| z-index | 自定义 z-index | number | - | - |
| inline | 是否 inline 渲染（不 append 到 body） | boolean | - | false |
| lazy | 是否懒渲染 | boolean | - | false |

## 指令修饰符

| 修饰符 | 说明 |
|--------|------|
| .hover | hover 触发 |
| .click | 点击触发 |
| .show | 默认展示 |
| .focus | focus 触发 |
| .stop | 阻止事件冒泡 |
| .delay{N} | 延迟 N 毫秒消失（如 .delay500） |

## 方法

| 方法名 | 说明 |
|--------|------|
| show() | 显示 tip |
| hide() | 隐藏 tip |
