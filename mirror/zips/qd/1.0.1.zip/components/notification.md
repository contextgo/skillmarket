# v-notification 消息通知

## 基本用法

```javascript
// 实例方法（在 Vue 组件内使用）
this.$notify({
  title: '通知标题',
  content: '通知内容',
  duration: 10000,       // 显示时长(ms)，0=不自动关闭
  showClose: true,       // 显示关闭按钮
  showRead: true,        // 显示"标为已读"按钮
  dangerouslyUseHTMLString: false, // content 是否支持 HTML
  zIndex: 100,
  onClose(instance, e) {
    instance.close();    // 关闭当前通知
  },
  onRead(instance, e) {
    instance.close();
  },
  onClick(instance, e) {
    // 点击通知面板（非按钮区域）
  },
  autoClose(instance) {
    // 自动关闭时触发
  }
});

// 静态方法（等同于 this.$notify）
import { Notification } from 'vhtml';
Notification.notify({ title: '标题', content: '内容' });

// 关闭所有通知
Notification.closeAll();

// 全局配置
Notification.config({
  maxNotificationCount: 4, // 最多同时显示几个
  offset: 92,              // 距离顶部偏移值
  gap: 32                  // 通知之间的间距
});
```

## Notification.notify 参数

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| title | 标题（超出隐藏） | string | '标题' |
| content | 内容（支持HTML） | string | '' |
| dangerouslyUseHTMLString | 是否通过 v-html 渲染 content | boolean | false |
| duration | 显示时长(ms)，0=不自动关闭 | number | 10000 |
| customClass | 根元素自定义 class | string | '' |
| zIndex | z-index 值 | number | 100 |
| showClose | 显示关闭按钮 | boolean | true |
| showRead | 显示"标为已读"按钮 | boolean | true |
| onClose | 点击关闭按钮回调 | function(instance, e) | - |
| onRead | 点击"标为已读"回调 | function(instance, e) | - |
| onClick | 点击通知面板回调 | function(instance, e) | - |
| autoClose | 自动关闭时回调 | function(instance) | - |

## Notification.config 参数

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| maxNotificationCount | 最多同时显示数量 | number | 3 |
| offset | 距离顶部偏移值(px) | number | 92 |
| gap | 通知之间的间距(px) | number | 32 |
