# v-button 按钮

## 基本用法

```html
<!-- 四种 kind：default / primary / success / warning -->
<!-- 三种 size：small / medium(默认) / large -->
<v-button>取消</v-button>
<v-button kind="primary" size="small">确定</v-button>
<v-button kind="success">成功</v-button>
<v-button kind="warning">告警</v-button>

<!-- 禁用 / loading -->
<v-button kind="primary" disabled>禁用</v-button>
<v-button kind="primary" loading>加载中</v-button>

<!-- 链接型 -->
<v-button type="link" kind="primary">链接按钮</v-button>
<!-- 链接型带下划线 -->
<v-button type="link" kind="primary" underline>链接按钮</v-button>

<!-- 文字型 -->
<v-button type="text" kind="primary">文字按钮</v-button>

<!-- 提交/重置 -->
<v-button type="submit" kind="primary">提交</v-button>
<v-button type="reset">重置</v-button>

<!-- 图标按钮 -->
<v-button icon="basic_search_line" remote>搜索</v-button>
<v-button kind="primary" icon="basic_delete_line" remote></v-button>

<!-- a 标签 -->
<v-button kind="primary" href="https://xxx.com" target="_blank">跳转</v-button>

<!-- 指定宽度 -->
<v-button kind="primary" :width="200">指定宽度</v-button>

<!-- hover 提示 -->
<v-button kind="warning" tip="删除后不可恢复">删除</v-button>
```

## 按钮组

```html
<v-button-group>
  <v-button>取消</v-button>
  <v-button kind="primary">确定</v-button>
</v-button-group>

<!-- 带分割线 -->
<v-button-group spliter>
  <v-button type="link">选项1</v-button>
  <v-button type="link" kind="primary">选项2</v-button>
</v-button-group>
```

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| type | 按钮类型 | string | button/reset/submit/link/text | button |
| kind | 样式类型 | string | default/primary/warning/success | default |
| size | 大小 | string | small/medium/large | medium |
| width | 按钮宽度 | string/number | - | - |
| loading | loading状态 | boolean | - | false |
| disabled | 禁用状态 | boolean | - | false |
| href | a标签地址 | string | - | - |
| target | a标签target | string | - | _self |
| underline | link型hover时显示下划线 | boolean | - | false |
| icon | 内嵌图标名称 | string | - | - |
| remote | 是否使用远端图标库 | boolean | - | false |
| label | 无slot时的按钮文字 | string | - | - |
| tip | hover提示文字 | string | - | - |

## ButtonGroup属性

| 参数 | 说明 | 类型 | 默认值 |
|------|------|------|--------|
| spliter | 按钮间分割线 | boolean | false |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| click | 点击事件 | Event |
