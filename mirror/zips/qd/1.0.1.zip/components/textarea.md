# v-textarea 多行文本框

## 基本用法

```html
<!-- 默认样式 -->
<v-textarea v-model="value" placeholder="请输入" limit="100"></v-textarea>

<!-- 禁用/只读 -->
<v-textarea v-model="value" disabled readonly></v-textarea>

<!-- 简单样式，自动高度 -->
<v-textarea kind="simple" limit="100" autoheight placeholder="请输入"></v-textarea>

<!-- 极简样式 -->
<v-textarea v-model="value" kind="simpler" limit="100" autoheight></v-textarea>

<!-- 自定义字符长度计算 -->
<v-textarea kind="simple" limit="10" autoheight length-calculator="chinese"></v-textarea>
<v-textarea kind="simple" limit="10" autoheight :length-calculator="myCalculator"></v-textarea>
```

> 注意：textarea 组件的计数器不会考虑首尾空格和换行，但得到的 value 里面是包含首尾空格和换行的（可以自行 trim）。

## 属性

| 参数 | 说明 | 类型 | 可选值 | 默认值 |
|------|------|------|--------|--------|
| value/v-model | 绑定值 | string/Array | - | - |
| kind | 类型 | string | default/simple/simpler | default |
| placeholder | 占位文本 | string | - | - |
| limit | 最大可提交字符长度 | number/string | - | - |
| maxlength | 最大可输入字符长度 | number/string | - | - |
| disabled | 禁用 | boolean | - | false |
| readonly | 只读 | boolean | - | false |
| autofocus | 自动获取焦点 | boolean | - | false |
| autoheight | 自动依据内容扩展高度 | boolean | - | false |
| length-calculator | 自定义字符长度计算规则 | string/function | 'default'/'chinese'/自定义函数 | 'default' |

## 事件

| 事件名 | 说明 | 参数 |
|--------|------|------|
| input | 绑定值改变时触发 | 新值 |
| change | 失焦后值有变化时触发 | 新值 |
| focus | 获得焦点 | Event |
| blur | 失焦 | Event |
