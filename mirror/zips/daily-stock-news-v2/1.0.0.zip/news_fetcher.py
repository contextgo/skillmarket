#!/usr/bin/env python3
"""
每日股市新闻自动获取脚本
用于每日股市分析技能的新闻数据采集

使用方法:
    python news_fetcher.py [日期]
    python news_fetcher.py 20260427

依赖:
    pip install requests beautifulsoup4
"""

import sys
import datetime
import json
import re
from pathlib import Path

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("请先安装依赖: pip install requests beautifulsoup4")
    sys.exit(1)


class StockNewsFetcher:
    """股市新闻获取器"""

    def __init__(self, date_str=None):
        if date_str is None:
            self.date = datetime.datetime.now()
        else:
            self.date = datetime.datetime.strptime(date_str, "%Y%m%d")
        self.date_str = self.date.strftime("%Y%m%d")
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

    def get_eastmoney_breakfast(self):
        """获取东方财富财经早餐"""
        url = f"https://finance.eastmoney.com/a/{self.date_str}19393479.html"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            resp.encoding = 'utf-8'
            soup = BeautifulSoup(resp.text, 'html.parser')
            # 提取正文内容
            content = soup.get_text()
            return {"source": "东方财富", "url": url, "content": content[:5000]}
        except Exception as e:
            return {"source": "东方财富", "url": url, "error": str(e)}

    def get_cls_telegraph(self):
        """获取财联社电报"""
        url = "https://www.cls.cn/telegraph"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            resp.encoding = 'utf-8'
            soup = BeautifulSoup(resp.text, 'html.parser')
            items = soup.find_all('div', class_='tel-news-item')[:20]
            news = []
            for item in items:
                title = item.get_text(strip=True)
                if title:
                    news.append(title)
            return {"source": "财联社", "url": url, "news": news}
        except Exception as e:
            return {"source": "财联社", "url": url, "error": str(e)}

    def get_basket_data(self):
        """获取龙虎榜数据"""
        url = "https://data.eastmoney.com/stockdata/hs.html"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            return {"source": "龙虎榜", "url": url, "status": "需要JS渲染，建议手动查看"}
        except Exception as e:
            return {"source": "龙虎榜", "error": str(e)}

    def get_sector_flow(self):
        """获取板块资金流向"""
        url = "https://data.eastmoney.com/zjlx/"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            return {"source": "资金流向", "url": url, "status": "需要JS渲染，建议手动查看"}
        except Exception as e:
            return {"source": "资金流向", "error": str(e)}

    def run(self):
        """执行所有获取任务"""
        results = {
            "date": self.date_str,
            "fetch_time": datetime.datetime.now().isoformat(),
            "sources": []
        }

        # 获取各数据源
        sources = [
            self.get_eastmoney_breakfast,
            self.get_cls_telegraph,
            self.get_basket_data,
            self.get_sector_flow
        ]

        for source_fn in sources:
            result = source_fn()
            results["sources"].append(result)
            print(f"✓ {result.get('source', 'Unknown')}: {result.get('status', 'OK') if 'error' not in result else 'ERROR'}")

        # 保存结果
        output_dir = Path(__file__).parent.parent / "data"
        output_dir.mkdir(exist_ok=True)
        output_file = output_dir / f"news_{self.date_str}.json"

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

        print(f"\n📁 数据已保存至: {output_file}")
        return results


def main():
    date_str = sys.argv[1] if len(sys.argv) > 1 else None
    fetcher = StockNewsFetcher(date_str)
    results = fetcher.run()

    # 输出摘要
    print("\n" + "="*50)
    print(f"📰 {results['date']} 股市新闻获取完成")
    print("="*50)

    for source in results["sources"]:
        name = source.get("source", "Unknown")
        if "error" in source:
            print(f"❌ {name}: {source['error']}")
        else:
            print(f"✅ {name}: OK")


if __name__ == "__main__":
    main()
