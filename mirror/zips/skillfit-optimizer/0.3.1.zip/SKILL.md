---
name: skillfit-optimizer
description: Recommend the smallest reliable skill stack for a user goal. Use when selecting skills, reducing tool overlap, checking environment readiness, comparing candidate stacks, or choosing a minimal setup for a task. Also covers capability mapping, stack scoring, and JSON-ready recommendations.
user-invocable: true
metadata: {"openclaw":{"emoji":"🧩","os":["linux","darwin","win32"]}}
---

# SkillFit Optimizer

Recommend the smallest reliable skill stack needed for a user goal.

Analyze the task, map required capabilities, identify candidate skills,
remove redundancy, check environment readiness, and recommend the
best-fit configuration.

Default behavior is analysis-only. Do not modify the environment unless
the user explicitly asks for setup or installation actions.

## Quick Start

```bash
clawhub install skillfit-optimizer
text
skillfit What is the best skill stack for editing PDFs and analyzing documents?
skillfit --minimal Recommend a minimal setup for spreadsheet cleanup and chart generation.
skillfit --compare Best stack for research, note-taking, and structured writing?
Best For
Users choosing skills for a new workflow

Teams reducing tool overlap

Developers trying to keep setup minimal

Users comparing alternative skill stacks

People checking whether their environment is ready

Quick Reference
Need	Use
Default best-fit recommendation	skillfit [goal]
Smallest working stack	skillfit --minimal [goal]
Best tradeoff	skillfit --balanced [goal]
Maximum coverage	skillfit --maximum [goal]
Include environment readiness	skillfit --check-env [goal]
Compare stack options	skillfit --compare [goal]
Structured export	skillfit --json [goal]
When to Use
Use this skill when the user asks:

What skills are needed for a task

What the best skill stack is

Which tools overlap

How to simplify a workflow

What to install for a use case

How to reduce tool sprawl

What the minimal working setup is

Modes
text
skillfit [goal]
skillfit --minimal [goal]
skillfit --balanced [goal]
skillfit --maximum [goal]
skillfit --check-env [goal]
skillfit --compare [goal]
skillfit --json [goal]
If no profile is specified, default to balanced.

Intake
text
User goal:          |
Preferred profile:  | (minimal / balanced / maximum)
Installed skills:   | (optional)
Environment info:   | (optional)
Constraints:        | (speed / reliability / low setup / low overlap)
Output:             | (text / json)
Free-form input also works.

Core Rules
text
1. Prefer the smallest reliable stack.
2. Avoid overlapping tools when one skill covers the need well.
3. Separate required capabilities from nice-to-have features.
4. Check environment readiness before recommending setup-heavy stacks.
5. Stay in analysis mode unless the user asks for changes.
6. Surface missing dependencies clearly.
7. Provide alternatives when more than one stack is viable.
Profiles
Minimal

text
Smallest working stack.
Optimize for low setup friction and fast deployment.
Balanced

text
Best tradeoff between coverage, reliability, and setup effort.
Default profile.
Maximum

text
Highest capability coverage and redundancy.
Use only when extra complexity is justified.
Workflow
Step 1 — Analyze Goal

Extract:

text
- main task
- sub-tasks
- expected outputs
- constraints
- implied tool needs
Step 2 — Map Capabilities

Translate the request into capability labels.

Example:

text
Goal: "Edit PDFs and summarize documents"

Capabilities:
- pdf_editing
- document_analysis
- summarization
Step 3 — Find Candidate Skills

Build:

text
- candidate skill list
- capability coverage map
- overlap map
Prefer skills that cover multiple required capabilities well.

Step 4 — Detect Overlap

Penalize:

text
- duplicate tools
- narrow skills with high setup cost
- stacks with unnecessary handoffs
Prefer:

text
- fewer skills
- broader coverage
- simpler workflows
Step 5 — Generate Candidate Stacks

Produce:

text
- Minimal
- Balanced
- Maximum
For each stack include:

text
- selected skills
- covered capabilities
- missing capabilities
- main tradeoffs
Step 6 — Check Environment

If environment data is available, check:

text
python
node
jq
curl
git
Mark each as:

text
available
missing
unknown
If environment state is not known, keep it unknown.

Step 7 — Score Stacks

Score each candidate using:

text
Coverage            — capability satisfaction
Reliability         — expected fit and stability
Setup Friction      — install and dependency burden
Overlap Discipline  — redundancy penalty
Formula:

text
score = coverage * 0.40
      + reliability * 0.30
      + setup_friction * 0.20
      + overlap_discipline * 0.10
Range:

text
0–100
Step 8 — Select Recommendation

Choose the highest-scoring stack.

Tie-breakers:

text
1. fewer skills
2. higher coverage
3. lower setup friction
Step 9 — Return Recommendation

Always return:

text
- recommended profile
- recommended stack
- score
- capability coverage
- missing capabilities
- environment notes
- alternatives
- next steps
Capability Labels
Use short, reusable labels such as:

text
pdf_editing
document_analysis
summarization
spreadsheet_processing
automation
api_interaction
json_processing
workflow_orchestration
writing_assistance
data_visualization
Output Template
text
## Goal
[User goal]

## Recommended Profile
[Minimal / Balanced / Maximum]

## Recommended Stack
- Skill 1
- Skill 2

## Why This Stack
- Reason 1
- Reason 2

## Capability Coverage
- capability_a
- capability_b

## Missing or Weak Areas
- gap_a

## Environment Check
- python: available / missing / unknown
- node: available / missing / unknown
- jq: available / missing / unknown
- curl: available / missing / unknown
- git: available / missing / unknown

## Alternatives
### Minimal
- ...

### Balanced
- ...

### Maximum
- ...

## Recommendation
[Short action-oriented summary]
JSON Output
json
{
  "goal": "",
  "recommended_profile": "balanced",
  "recommended_stack": [],
  "stack_score": 0,
  "capability_coverage": [],
  "missing_capabilities": [],
  "environment_check": {
    "python": "unknown",
    "node": "unknown",
    "jq": "unknown",
    "curl": "unknown",
    "git": "unknown"
  },
  "alternatives": {
    "minimal": [],
    "balanced": [],
    "maximum": []
  },
  "notes": []
}
Limits
This skill does not:

execute the workflow itself

guarantee correctness of external tools

guarantee that every recommendation will work in every environment

replace validation after stack changes

It provides structured recommendations, not guarantees.

Related Skills
agent-regression-check

skill-creator

Tips
Start with balanced unless simplicity is the top priority.

Use minimal for narrow tasks and constrained environments.

Use maximum only when redundancy is worth the added complexity.

Re-run the optimizer when the workflow changes materially.

Prefer multi-capability skills over several narrow ones.

Treat unknown environment state as a real constraint.

If two stacks score similarly, choose the smaller one.

Return alternatives even when the recommendation is obvious.

Author
Vassiliy Lakhonin