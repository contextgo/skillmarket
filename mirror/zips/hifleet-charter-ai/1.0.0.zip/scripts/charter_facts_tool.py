#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hifleet-charter-ai：解析结果写入 / 检索 charter_facts.sqlite3（货盘表 + 船盘表 + unknown 表）。"""

from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

# 与 SKILL.md §2.4 JSON 键一致
CARGO_FIELD_KEYS: tuple[str, ...] = (
    "客户名称",
    "货物数量",
    "货物种类",
    "装货港",
    "卸货港",
    "装港消约期开始日期",
    "装港消约期结束日期",
    "是否为散装",
    "装货率",
    "装货条款",
    "允许船型",
    "最早船舶建造年份限制",
    "船级限制",
    "是否要求船吊",
    "是否为危险品",
    "冷藏需求",
    "舱型要求",
    "是否接收甲板货",
    "包装要求",
    "货物特殊说明",
    "货主要求",
    "dwt要求",
    "联系电话",
    "即时通讯",
)

OPENVESSEL_FIELD_KEYS: tuple[str, ...] = (
    "船名",
    "IMO",
    "船型",
    "载重吨",
    "建造年份",
    "OPEN位置",
    "OPEN开始日期",
    "OPEN结束日期",
    "航线意向",
    "吊机数量",
    "是否有船吊",
    "吊机类型",
    "舱口尺寸",
    "舱容（立方米）",
    "舱数",
    "舱盖类型",
    "甲板载重能力",
    "是否可装危险品",
    "冷藏插座数量",
    "是否有喷淋系统",
    "燃料类型",
    "所属公司",
    "IMO设备等级",
    "船速（节）",
    "载货设备描述",
    "租船类型",
    "是否可跑CIS航线",
    "是否可跑BH航线",
    "是否可跑AUS航线",
    "是否是BOX HOLD",
    "是否是NO IRAN/ISRAEL/YEMEN",
    "联系电话",
    "即时通讯",
    "卸货港",
    "是否有rightship",
    "O/A其他附加信息",
)

CARGO_INT_KEYS = {
    "货物数量",
    "是否为散装",
    "是否要求船吊",
    "是否为危险品",
    "冷藏需求",
    "是否接收甲板货",
}

OPENVESSEL_INT_KEYS = {
    "载重吨",
    "吊机数量",
    "是否有船吊",
    "舱容（立方米）",
    "舱数",
    "是否可装危险品",
    "冷藏插座数量",
    "是否有喷淋系统",
    "是否可跑CIS航线",
    "是否可跑BH航线",
    "是否可跑AUS航线",
    "是否是BOX HOLD",
    "是否是NO IRAN/ISRAEL/YEMEN",
    "是否有rightship",
}

OPENVESSEL_REAL_KEYS = {"船速（节）"}


def _q(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _norm_intent(intent: Any) -> list[str]:
    if intent is None:
        return []
    if isinstance(intent, str):
        return [intent] if intent else []
    if isinstance(intent, list):
        return [str(x) for x in intent if x is not None]
    return [str(intent)]


def coerce_field(key: str, val: Any, int_keys: set[str], real_keys: set[str]) -> Any:
    if val is None:
        return None
    if key in int_keys:
        if isinstance(val, bool):
            return 1 if val else 0
        if isinstance(val, (int, float)) and not isinstance(val, bool):
            return int(val)
        s = str(val).strip()
        if not s or s.lower() in ("null", "none"):
            return None
        m = re.search(r"-?\d+", s)
        return int(m.group(0)) if m else None
    if key in real_keys:
        if isinstance(val, (int, float)) and not isinstance(val, bool):
            return float(val)
        s = str(val).strip()
        if not s or s.lower() in ("null", "none"):
            return None
        try:
            return float(s.replace(",", ""))
        except ValueError:
            m = re.search(r"-?\d+\.?\d*", s)
            return float(m.group(0)) if m else None
    if isinstance(val, (dict, list)):
        return json.dumps(val, ensure_ascii=False)
    return val if isinstance(val, str) else str(val)


def _search_parts(
    subject: str,
    from_addr: str,
    row: dict[str, Any],
    keys: Iterable[str],
) -> str:
    parts = [subject or "", from_addr or ""]
    for k in keys:
        v = row.get(k)
        if v is not None and v != "":
            parts.append(str(v))
    return " ".join(parts)


class CharterFactsDB:
    def __init__(self, path: Path) -> None:
        self.path = path

    def connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self.path))
        conn.row_factory = sqlite3.Row
        return conn

    def init(self, conn: sqlite3.Connection) -> None:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = {r[0] for r in cur.fetchall()}

        if "charter_fact" in tables:
            cur.execute("DROP TABLE IF EXISTS charter_fact")

        if "cargo_plate" in tables:
            cur.execute("PRAGMA table_info(cargo_plate)")
            cols = {r[1] for r in cur.fetchall()}
            if "客户名称" not in cols:
                cur.execute("DROP TABLE IF EXISTS cargo_plate")
                cur.execute("DROP TABLE IF EXISTS openvessel_plate")
                cur.execute("DROP TABLE IF EXISTS mail_unknown")

        cargo_cols = ", ".join(f'{_q(k)} TEXT' for k in CARGO_FIELD_KEYS)
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS cargo_plate (
              message_id TEXT NOT NULL,
              email_date_utc TEXT,
              from_addr TEXT,
              subject TEXT,
              row_index INTEGER NOT NULL,
              {cargo_cols},
              payload_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              parsed_at TEXT NOT NULL
            )
            """
        )

        opv_cols = ", ".join(f'{_q(k)} TEXT' for k in OPENVESSEL_FIELD_KEYS)
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS openvessel_plate (
              message_id TEXT NOT NULL,
              email_date_utc TEXT,
              from_addr TEXT,
              subject TEXT,
              row_index INTEGER NOT NULL,
              {opv_cols},
              payload_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              parsed_at TEXT NOT NULL
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS mail_unknown (
              message_id TEXT NOT NULL,
              email_date_utc TEXT,
              from_addr TEXT,
              subject TEXT,
              intent_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              parsed_at TEXT NOT NULL
            )
            """
        )
        conn.commit()

    def save_parsed(
        self,
        conn: sqlite3.Connection,
        *,
        message_id: str,
        email_date_utc: str,
        from_addr: str,
        subject: str,
        parsed: dict[str, Any],
    ) -> None:
        self.init(conn)
        cur = conn.cursor()
        intent = _norm_intent(parsed.get("intent"))
        data = parsed.get("data") or {}
        cargo_list = data.get("cargo") if isinstance(data.get("cargo"), list) else []
        opv_list = data.get("openvessels") if isinstance(data.get("openvessels"), list) else []

        cur.execute("DELETE FROM cargo_plate WHERE message_id = ?", (message_id,))
        cur.execute("DELETE FROM openvessel_plate WHERE message_id = ?", (message_id,))
        cur.execute("DELETE FROM mail_unknown WHERE message_id = ?", (message_id,))

        parsed_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        cargo_cols_list = [_q(k) for k in CARGO_FIELD_KEYS]
        cargo_placeholders = ", ".join(["?"] * (5 + len(CARGO_FIELD_KEYS) + 3))
        cargo_insert = (
            f'INSERT INTO cargo_plate (message_id, email_date_utc, from_addr, subject, row_index, '
            f'{", ".join(cargo_cols_list)}, payload_json, search_text, parsed_at) VALUES ({cargo_placeholders})'
        )

        for idx, raw in enumerate(cargo_list):
            if not isinstance(raw, dict):
                continue
            row_vals: dict[str, Any] = {}
            for k in CARGO_FIELD_KEYS:
                row_vals[k] = coerce_field(k, raw.get(k), CARGO_INT_KEYS, set())
            payload = json.dumps(raw, ensure_ascii=False)
            st = _search_parts(subject, from_addr, row_vals, CARGO_FIELD_KEYS)
            vals: list[Any] = [
                message_id,
                email_date_utc,
                from_addr,
                subject,
                idx,
            ]
            vals.extend(row_vals[k] for k in CARGO_FIELD_KEYS)
            vals.extend([payload, st, parsed_at])
            cur.execute(cargo_insert, vals)

        opv_cols_list = [_q(k) for k in OPENVESSEL_FIELD_KEYS]
        opv_placeholders = ", ".join(["?"] * (5 + len(OPENVESSEL_FIELD_KEYS) + 3))
        opv_insert = (
            f'INSERT INTO openvessel_plate (message_id, email_date_utc, from_addr, subject, row_index, '
            f'{", ".join(opv_cols_list)}, payload_json, search_text, parsed_at) VALUES ({opv_placeholders})'
        )

        for idx, raw in enumerate(opv_list):
            if not isinstance(raw, dict):
                continue
            row_vals = {}
            for k in OPENVESSEL_FIELD_KEYS:
                row_vals[k] = coerce_field(k, raw.get(k), OPENVESSEL_INT_KEYS, OPENVESSEL_REAL_KEYS)
            payload = json.dumps(raw, ensure_ascii=False)
            st = _search_parts(subject, from_addr, row_vals, OPENVESSEL_FIELD_KEYS)
            vals = [message_id, email_date_utc, from_addr, subject, idx]
            vals.extend(row_vals[k] for k in OPENVESSEL_FIELD_KEYS)
            vals.extend([payload, st, parsed_at])
            cur.execute(opv_insert, vals)

        has_unknown = any(x.lower() == "unknown" for x in intent)
        if has_unknown and not cargo_list and not opv_list:
            st = " ".join(
                x for x in (subject, from_addr, json.dumps(intent, ensure_ascii=False)) if x
            )
            cur.execute(
                "INSERT INTO mail_unknown (message_id, email_date_utc, from_addr, subject, intent_json, search_text, parsed_at) VALUES (?,?,?,?,?,?,?)",
                (
                    message_id,
                    email_date_utc,
                    from_addr,
                    subject,
                    json.dumps(intent, ensure_ascii=False),
                    st,
                    parsed_at,
                ),
            )

        conn.commit()

    def search(self, conn: sqlite3.Connection, q: str, limit: int = 50) -> list[dict[str, Any]]:
        self.init(conn)
        cur = conn.cursor()
        like = f"%{q}%"
        out: list[dict[str, Any]] = []

        for table, ftype in (
            ("cargo_plate", "cargo"),
            ("openvessel_plate", "openvessel"),
        ):
            cur.execute(
                f"SELECT * FROM {table} WHERE search_text LIKE ? ORDER BY email_date_utc DESC LIMIT ?",
                (like, limit),
            )
            for row in cur.fetchall():
                d = dict(row)
                d["_source_table"] = table
                d["_fact_type"] = ftype
                pj = d.get("payload_json")
                if pj:
                    try:
                        d["payload"] = json.loads(pj)
                    except json.JSONDecodeError:
                        d["payload"] = None
                out.append(d)

        cur.execute(
            "SELECT * FROM mail_unknown WHERE search_text LIKE ? ORDER BY email_date_utc DESC LIMIT ?",
            (like, limit),
        )
        for row in cur.fetchall():
            d = dict(row)
            d["_source_table"] = "mail_unknown"
            d["_fact_type"] = "unknown"
            ij = d.get("intent_json")
            if ij:
                try:
                    d["intent"] = json.loads(ij)
                except json.JSONDecodeError:
                    d["intent"] = None
            out.append(d)

        return out[:limit]


def default_db_path() -> Path:
    return Path.home() / ".openclaw" / "workspace" / "skills" / "hifleet-charter-ai" / "charter_facts.sqlite3"


def cmd_save(args: argparse.Namespace) -> int:
    if args.file:
        raw = Path(args.file).read_text(encoding="utf-8")
    else:
        raw = sys.stdin.read()
    doc = json.loads(raw)
    parsed = doc.get("parsed") or doc
    db = CharterFactsDB(Path(args.db) if args.db else default_db_path())
    conn = db.connect()
    try:
        db.save_parsed(
            conn,
            message_id=doc.get("message_id") or "",
            email_date_utc=doc.get("email_date_utc") or "",
            from_addr=doc.get("from_addr") or "",
            subject=doc.get("subject") or "",
            parsed=parsed if isinstance(parsed, dict) else {},
        )
    finally:
        conn.close()
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    db = CharterFactsDB(Path(args.db) if args.db else default_db_path())
    conn = db.connect()
    try:
        rows = db.search(conn, args.query, limit=args.limit)
    finally:
        conn.close()
    print(json.dumps(rows, ensure_ascii=False, indent=2, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="hifleet-charter-ai charter_facts SQLite 工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    ps = sub.add_parser("save", help="从 JSON 写入（默认读标准输入，或用 -f 指定文件）")
    ps.add_argument("--db", help="sqlite3 路径（默认 ~/.openclaw/.../charter_facts.sqlite3）")
    ps.add_argument("--file", "-f", help="JSON 文件路径（未指定则从 stdin 读取）")
    ps.set_defaults(func=cmd_save)

    pr = sub.add_parser("search", help="关键词检索 search_text")
    pr.add_argument("--db", help="sqlite3 路径（默认 ~/.openclaw/.../charter_facts.sqlite3）")
    pr.add_argument("query")
    pr.add_argument("--limit", type=int, default=50)
    pr.set_defaults(func=cmd_search)

    args = p.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
