# config.json 示例（船期路由 B）

将下列字段合并进本 Skill 目录下的 `config.json`（与邮箱等配置同一文件即可）。**勿**把真实 Key 提交到公开仓库。

```json
{
  "hifleet_api_key": "在 HiFleet 网站获取的 API Key（与账号绑定、按次计费）",
  "hifleet_liner_api_base": "https://ttseapi.hifleet.com/openclaw/vessel/charter/liner"
}
```

- `hifleet_api_key`：必填（或等价环境变量，见 `SKILL.md`）。
- `hifleet_liner_api_base`：可选，默认如上；私有化/联调时可改。
