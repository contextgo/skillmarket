# 船期接口（路由 B）

本文件为 **hifleet-charter-ai** 中 **路由 B** 的约定；**路由 A（邮件船货盘）不适用本文**。

---

## 分发模式

1. 船期数据由 **HiFleet `ttseapi.hifleet.com`** 提供；触发路由 B 时由助手在环境中发 **HTTPS** 请求，**不得**用邮件检索、SQLite 或臆造数据代替。  
2. 用户在 **HiFleet 网站**申请密钥，与网站账号绑定、**按次计费**；本地存为 `hifleet_api_key` / `HIFLEET_API_KEY`；在请求里以 **`api_key`（query/header）** 或船期列表的 **`sk`（query）** 传递**同一串**，**勿在对话中完整暴露**。

---

## 配置与根路径

| 含义 | 默认值 |
|------|--------|
| 班轮 API 根（无末尾 `/`） | `https://ttseapi.hifleet.com/openclaw/vessel/charter/liner` |

**根路径**：`hifleet_liner_api_base`（config）→ `HIFLEET_LINER_API_BASE`（环境）→ 上表。  
**用户密钥字符串**：`hifleet_api_key`（config）→ `HIFLEET_API_KEY`（环境）。各接口在 HTTP 里以 **`api_key`（query/header）** 或 **`sk`（仅船期列表，见下）** 使用同一串，勿混为两个不同值。

无有效密钥时**不得**调接口，引导用户配置（见 `SKILL.md` Workflow 3）。

---

## 1. 港口联想

**`GET {root}/ports/suggest`**

| 方式 | 名称 | 值 |
|------|------|-----|
| **Header** | `api_key` | 用户 `api_key` 字符串 |
| **Query** | `keyword` | **英文**港口名（如上海 → `Shanghai`；助手需先把中文/口语港名换成英文再请求） |
| **Query** | `from` | `0` |
| **Query** | `size` | `1`（每条港只取一条联想） |
| **Query** | `api_key` | 与用户密钥相同，与 Header 一致 |

**成功响应**（结构示例）中从 **`data[0].portId`** 取装/卸港 ID；`msg` 为 `SUCCESS`、业务成功时 `status` 为 `"1"` 等以线上为准。装港、卸港（若用户有提）**各请求一次**，各取 `size=1` 对应一条。

**与船期查询的衔接（必读）**

- 班轮列表的筛选依据是 **`portId`（及日窗等）** 在 **`POST /schedules` 的 `params` 里**一次提交，**不是**在拿到结果后按**港口名字符串**再挑记录。  
- 用户**同时**说了装货港、卸货港时：须对**装港、卸港各调一次** §1 拿到 **`portid`** 与 **`dischargingPortid`**，并在**同一次** `POST /schedules` 的 **`params` 中同时带上两者**（见 §2 示例）。  
- **禁止**：只传装港的 `portid`、等返回后再在回答里用「卸货港是不是新加坡 / 用港名在文本里筛」**冒充**成「已按两港查过」——**不允许**。缺卸港的 `portId` 时须先走 §1 用卸港**英文** `keyword` 联想不到再提示用户，**不要**用港名在列表里硬筛替代 `dischargingPortid`。

**失败**：如 `code`/`message` 为 token 或鉴权类错误，检查 `api_key` 是否在 Header 与 Query 中均已正确携带。

---

## 2. 船期列表

**`POST {root}/schedules?sk={URL 编码的 api_key 字符串}`**

- **Query**：`sk` = 用户 `api_key`（与上节同一配置值）。若仍报「token 为空」，与后端核对鉴权参数。  
- **Body**：`Content-Type: application/json`。**现网**将装港、卸港、是否公开、**受载日窗** 一并放在 **`params` 中**。筛选与后端数据对齐依赖 **`portid` / `dischargingPortid`**，**不**能靠助手机侧对**港名**的模糊包含来替代。  

| 字段 | 说明 |
|------|------|
| `offset` / `limit` | 分页，如 `limit: 10` |
| `params.portid` | 装港 `portId`（**仅**能来自 §1 的 `portId`，**禁止**用未解析的港名当查询键） |
| `params.dischargingPortid` | 卸港 `portId`（**同上**）；**用户提了两港时本条必填**；仅单港需求时可省略（以现网为准） |
| `params.isPublic` | 如 `true` |
| `params.openDateStart` | 受载窗**起**，**`yyyy-MM-dd` 裸字符串** |
| `params.openDateEnd` | 受载窗**止**，**`yyyy-MM-dd` 裸字符串** |
| 其它 | 若后端在 `params` 中**增加**解约日窗等字段（如 `openEndDateStart`），**以你方现网/ShowDoc 为准** |

**口语「近期」的组参规则（助手侧）**

- 用户只模糊说「最近」「近期」、未给具体日：仍须通过 §1 取 **portid**；`params.openDateStart` / `openDateEnd` 设为由 **明天** 起算的**较宽**受载窗（**不要**只限 7 天、**不要**强套「解约早于受载」等额外关系）；若用户**未**提卸港，是否传 `dischargingPortid` 以现网为准。  
- 用户给了具体受载窗时，把其起、止**直接**写进 `params.openDateStart`、`params.openDateEnd`（**字符串**）。

**请求示例（`params` 内含受载日）**

```json
{
  "offset": 1,
  "limit": 10,
  "params": {
    "portid": "22214",
    "dischargingPortid": "15843",
    "isPublic": true,
    "openDateStart": "2026-04-23",
    "openDateEnd": "2026-05-07"
  }
}
```

**联调注记**

- 使用**真实** `sk` 时，接口**可用**；成功返回的 **`data` 中每条须有顶层 `id`**, 作 **`dataId` 调解锁。  
- **可**在**仅**关心装港、**未**指定卸港 的场景下，用下面 body **只**带 `portid`+`isPublic` 拉大列表，再在结果上**只**作**受载/解约日**等辅助压缩（**不得**在缺少 `dischargingPortid` 的查询结果上，用「是否含某卸港名字」**冒充**两港全约束查询）。用户**已明确**装港+卸港的，**必须**用 §1 解出**两个** `portId` 并**同次** `POST` 带全（见上节「禁止」）。

```json
{
  "offset": 1,
  "limit": 10,
  "params": {
    "portid": "27800",
    "isPublic": true
  }
}
```

- 历史上曾用 **`filterLabels` + 多段 `openDate*` 数组** 等形态；**当前以本节 `params` 为准**；若你方同时保留**旧式** `openDateDays` 筛桶，**以现网**实际接受为准。  

**联调与鉴权**（在公网用占位/无效 `sk` 试投 **`POST`）：服务**可达**；本环境会返回类似 `{"code":4005,"message":"token is empty.","url":".../schedules"}`，表示**未通过鉴权**、**不会**返回有效业务 `data`。**仅当**在 Query 中带上 HiFleet 下发的**真实** `api_key`（`sk=…`）后，才会按条件返回 `total` / `stat` / `data` 等。

**响应中 `id` 与 `dataId`（必读）**

- 成功时 **`data` 数组的每一条**船期对象，**必须**在**最外层**包含字段 **`id`**（数值或字符串，以线为准）。**解锁联系人**（§3）的 Query 参数 **`dataId`** = 该条记录的 **`id`** 转成字符串后传入。  
- 向用户展示列表时，**不得**省略此 `id`：每条可单独一行标为「**记录 id（用于解锁）**：`id`」，便于用户说「要解锁第几条 / 这个 id 的那条船」；**不要**用其它嵌套 id 替代（除非线上一致约定）。  
- 若某次响应里 `data` 有元素**缺少**顶层 `id`，即接口不闭环，**无法**正确调用 unlock，应联系后台补全。  

**其它**：列表中脱敏段（如 `******`）不得当明文；看完整公司/联系方式须先说明**扣积分**再调 §3。`stat` 等统计以线上为准。

---

## 3. 解锁联系人

**`POST {root}/unlock`**

仅 **Query 参数**（无特殊说明时 **Body 可为空**）：

| Query | 说明 |
|--------|------|
| `dataId` | 船期列表 `data` 中该条船期对象的**顶层** **`id`**（与 `POST /schedules` 返回的该条 `id` 一致） |
| `typeCode` | 固定为 **`product_vessel_liner_charter`**（默认值） |
| `api_key` | 用户 `api_key` |

**Header**：与 §1 一致，建议同时带 **`api_key`: 与 Query 相同**（若你方网关要求，与 ports 行为对齐）。

成功后解析响应中的明文联系人/公司/电话/邮箱等展示给用户，仍**不**在对话中泄露完整 `api_key`。

---

## 错误

HTTP 4xx/5xx 及 JSON 内 `code`/`message` / `msg` 非成功：用简短中文说明，不贴完整 `api_key`、不贴长堆栈。
