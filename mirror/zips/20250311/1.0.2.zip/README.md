# Budget Dashboard Generator Skill

通用预算看板生成器 - 一个用于快速生成交互式预算跟踪Web看板的AI助手技能包。

**完全通用化**：不限制团队成员数量，不预设成员姓名，可适配任意组织结构。

## 功能特点

- 📊 **多维度看板**：部门汇总 + 任意数量团队成员独立视图
- 📈 **三类指标**：整体指标、订阅指标、服务指标（支持自定义）
- 📅 **月度追踪**：月实际收款 vs 月指标差异分析
- 📆 **季度推测**：Q1-Q4 各季度数据预测
- ✏️ **CRUD管理**：预算/收款明细的添加、编辑、删除
- 💾 **数据持久化**：localStorage 本地存储

## 技术栈

| 组件 | 技术 |
|------|------|
| 前端框架 | React 18 + TypeScript |
| 构建工具 | Vite |
| 样式 | Tailwind CSS |
| 图表 | 自定义组件 |
| 数据存储 | localStorage |

## 目录结构

```
budget-dashboard-generator/
├── SKILL.md                    # 主技能文档
├── README.md                   # 本文件
└── references/
    └── data-structures.md      # 数据结构参考
```

## 安装方式

### 方式1：本地安装

将整个 `budget-dashboard-generator` 文件夹复制到您的 skill 目录：

```bash
# 复制到 nanobot skills 目录
cp -r budget-dashboard-generator ~/.nanobot/skills/
```

### 方式2：GitHub 分享

1. 创建 GitHub 仓库
2. 上传本文件夹内容
3. 发布仓库为 Public 公开
4. 其他用户通过 skill-finder 安装

## 触发关键词

- "帮我做一个预算看板"
- "把预算数据做成网页"
- "预算跟踪系统"
- "预算管理dashboard"
- "团队预算管理"

## 配置说明

### 团队成员配置（核心）

导航栏中的客户成功经理名称通过中央配置文件管理：

```typescript
// src/config/teamConfig.ts

// 客户成功经理名称列表（可自定义）
export const TEAM_MEMBERS: string[] = [
  '田旭财',  // 可修改为任意名称
  '杨洋',
  '于德鹏',
  '文德超',
  // 可添加任意数量的成员
];
```

修改方法：
1. 编辑 `src/config/teamConfig.ts` 中的 `TEAM_MEMBERS` 数组
2. 在 `src/data/budgetData.ts` 中添加对应成员数据
3. 在 `src/data/detailData.ts` 中添加对应成员数据
4. 重新构建部署

### 其他配置项

在生成看板时，AI会询问：
1. **团队成员名单**（数量不限，名称自定义）
2. **年度预算分配**（整体/订阅/服务）
3. **服务类型配置**（可扩展）
4. **季度分配比例**（可自定义）

## 数据安全

- 纯前端部署，服务器仅存储网页代码
- 数据存储在用户浏览器 localStorage
- 不同用户数据完全隔离

## License

MIT
