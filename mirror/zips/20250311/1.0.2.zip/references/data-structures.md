# 预算看板数据结构参考（通用化版）

## 0. 团队配置 (teamConfig.ts) - 核心配置

```typescript
// src/config/teamConfig.ts
// 这是最关键的配置文件，修改此文件即可自定义团队成员

/**
 * 团队配置 - 自定义客户成功经理名称
 *
 * 修改此文件中的 teamMembers 数组即可自定义导航栏中的客户成功经理名称
 * 支持任意数量成员，名称可自定义
 */

// 客户成功经理名称列表（可自定义）
export const TEAM_MEMBERS: string[] = [
  '田旭财',
  '杨洋',
  '于德鹏',
  '文德超',
];

// 导航栏显示配置
export const NAV_CONFIG = {
  // 部门汇总标签
  summaryLabel: '部门汇总',
  // 客户成功经理标签前缀
  managerLabel: '客户成功经理',
};

// 部门信息
export const DEPARTMENT_INFO = {
  name: '客户成功部',
  memberLabel: NAV_CONFIG.managerLabel,
};
```

### 如何添加/修改团队成员

1. 修改 `TEAM_MEMBERS` 数组中的名称
2. 在 `budgetData.ts` 中添加对应的成员数据
3. 在 `detailData.ts` 中添加对应的成员数据
4. 在 `customerDetails.ts` 的 `getInitialData()` 中自动初始化（已支持动态初始化）

---

## 1. budgetData.ts 核心结构

### ManagerData 接口（通用化）

```typescript
export interface MonthlyData {
  month: number;           // 1-12
  target: number;          // 月指标
  budget: number;          // 月预算
  actual: number;          // 月实际收款
  completionRate: number;  // 完成率 (actual/target)
  gap: number;            // 差距 (actual - target)
}

export interface YearlyData {
  month: number;
  cumulativeTarget: number;     // 累计指标
  cumulativeBudget: number;    // 累计预算
  cumulativeActual: number;    // 累计实际
  actualCompletionRate: number;// 累计完成率
  forecastAmount: number;      // 预测收款
  forecastCompletionRate: number;// 预测完成率
}

export interface QuarterlyData {
  quarter: string;        // Q1, Q2, Q3, Q4
  ratio: number;          // 季度占比
  target: number;         // 季度指标
  actual: number;         // 季度实际
}

export interface MetricData {
  annual: number;         // 年度预算
  monthly: MonthlyData[];
  yearly: YearlyData[];
  quarterly: QuarterlyData[];
}

export interface TeamMemberData {
  name: string;           // 成员名称（通用化）
  overall: MetricData;
  subscription: MetricData;
  service: MetricData;
}
```

### 数据初始化示例（通用化）

```typescript
// 通用化配置
const TEAM_MEMBERS = ['成员A', '成员B', '成员C', '成员D']; // 可任意数量

// 年度预算配置（可自定义）
const ANNUAL_BUDGET = {
  overall: 18000000,
  subscription: 13000000,
  service: 5000000,
};

// 季度分配配置（可自定义）
const QUARTERLY_RATIO = {
  Q1: 0.25,
  Q2: 0.25,
  Q3: 0.25,
  Q4: 0.25,
};

const teamMemberData: TeamMemberData[] = TEAM_MEMBERS.map(name => ({
  name,
  overall: {
    annual: ANNUAL_BUDGET.overall / TEAM_MEMBERS.length,
    monthly: [...],
    yearly: [...],
    quarterly: [...],
  },
  subscription: {...},
  service: {...},
}));
```

---

## 2. detailData.ts 结构（通用化）

```typescript
export interface DetailData {
  budget: {
    subscription: number;  // 订阅预算总额
    service: number;        // 服务预算总额
    total: number;          // 总预算
    by_month: {
      [month: string]: {
        subscription: number;
        service: number;
      }
    };
    by_service_type: {
      [type: string]: number;  // 通用化：支持任意服务类型
    };
  };
  actual: {
    total: number;          // 实际收款总额
    by_month: {
      [month: string]: {
        subscription: number;
        service: number;
      }
    };
  };
}

// 服务类型配置（通用化，可扩展）
export const SERVICE_TYPES = [
  '专项服务',
  '高级服务',
  '标准服务',
  '其他',
];

export const detailData: Record<string, DetailData> = {};
TEAM_MEMBERS.forEach(name => {
  detailData[name] = {
    budget: {
      subscription: 0,
      service: 0,
      total: 0,
      by_month: {},
      by_service_type: SERVICE_TYPES.reduce((acc, type) => ({...acc, [type]: 0}), {}),
    },
    actual: {
      total: 0,
      by_month: {},
    },
  };
});

export const getTotalBudget = () => {...}
export const getTotalActual = () => {...}
export const getTotalSubscription = () => {...}
export const getTotalService = () => {...}
```

---

## 3. customerDetails.ts 结构（CRUD支持，通用化）

```typescript
export interface BudgetItem {
  id: string;
  customer: string;
  product: string;
  amount: number;
  type: '订阅' | '服务' | '';
  serviceType: string;
  month: number;
  risk: string;
}

export interface CollectionItem {
  id: string;
  customer: string;
  product: string;
  amount: number;
  subscriptionAmount: number;
  type: '订阅' | '服务' | '';
  serviceType: string;
  month: number;
}

export interface TeamMemberCustomerDetails {
  budgetItems: BudgetItem[];
  collectionItems: CollectionItem[];
}

// localStorage 操作（通用化：支持任意成员）
const STORAGE_KEY = 'budget_dashboard_customer_details';

export const saveToLocalStorage = (data: Record<string, TeamMemberCustomerDetails>) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const loadFromLocalStorage = (): Record<string, TeamMemberCustomerDetails> | null => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : null;
};

export const getInitialData = (): Record<string, TeamMemberCustomerDetails> => {
  const saved = loadFromLocalStorage();
  if (saved) return saved;

  // 通用化：根据配置初始化所有成员
  const initialData: Record<string, TeamMemberCustomerDetails> = {};
  TEAM_MEMBERS.forEach(name => {
    initialData[name] = { budgetItems: [], collectionItems: [] };
  });
  return initialData;
};
```

---

## 4. 组件状态管理示例（通用化）

```typescript
interface DashboardProps {
  teamMembers: string[];  // 通用化：从配置读取
}

const TeamDashboard: React.FC<DashboardProps> = ({ teamMembers }) => {
  // 指标类型
  const [selectedMetric, setSelectedMetric] = useState<'overall' | 'subscription' | 'service'>('overall');

  // 月份选择
  const [selectedMonth, setSelectedMonth] = useState<number>(4);

  // 视图切换
  const [selectedView, setSelectedView] = useState<'stats' | 'budget' | 'collection'>('stats');

  // 当前成员（通用化）
  const [currentMember, setCurrentMember] = useState<string>(teamMembers[0]);

  // 客户明细数据（通用化：Record<string, ...>）
  const [customerData, setCustomerData] = useState<TeamMemberCustomerDetails>(() => {
    const initialData = getInitialData();
    return initialData[currentMember] || { budgetItems: [], collectionItems: [] };
  });

  // CRUD 状态（通用化）
  const [editingBudgetItem, setEditingBudgetItem] = useState<BudgetItem | null>(null);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  // ... 更多状态

  // 保存函数（通用化）
  const saveData = (newData: TeamMemberCustomerDetails) => {
    const allData = getInitialData();
    allData[currentMember] = newData;
    saveToLocalStorage(allData);
    setCustomerData(newData);
  };

  // CRUD 处理函数（通用化）
  const handleAddBudget = () => {...};
  const handleEditBudget = (item: BudgetItem) => {...};
  const handleSaveBudget = () => {...};
  const handleDeleteBudget = (id: string) => {...};
  // ... 类似处理收款项
};
```

---

## 5. 工具函数（通用化）

```typescript
// 金额格式化
export const formatCurrency = (value: number): string => {
  if (value >= 10000) {
    return `${(value / 10000).toFixed(2)}万`;
  }
  return `${value.toLocaleString()}元`;
};

// 百分比格式化
export const formatPercent = (value: number): string => {
  return `${(value * 100).toFixed(1)}%`;
};

// 获取季度
export const getQuarterByMonth = (month: number): string => {
  if (month <= 3) return 'Q1';
  if (month <= 6) return 'Q2';
  if (month <= 9) return 'Q3';
  return 'Q4';
};

// 计算季度数据（通用化）
export const calculateQuarterlyData = (monthly: MonthlyData[], ratio = QUARTERLY_RATIO) => {
  const quarterly: Record<string, { actual: number; target: number }> = {
    'Q1': { actual: 0, target: 0 },
    'Q2': { actual: 0, target: 0 },
    'Q3': { actual: 0, target: 0 },
    'Q4': { actual: 0, target: 0 },
  };

  monthly.forEach(m => {
    const q = getQuarterByMonth(m.month);
    quarterly[q].actual += m.actual;
    quarterly[q].target += m.target;
  });

  return quarterly;
};

// 动态计算成员年度预算（通用化）
export const calculateMemberBudget = (annual: number, memberCount: number) => {
  return annual / memberCount;
};
```

---

## 6. 样式常量（通用化）

```typescript
const COLORS = {
  primary: '#3B82F6',     // 蓝色 - 整体指标
  success: '#10B981',     // 绿色 - 订阅指标
  warning: '#F59E0B',     // 黄色 - 年预测
  danger: '#EF4444',       // 红色 - 月实际
  purple: '#8B5CF6',       // 紫色 - 服务指标
  cyan: '#06B6D4',         // 青色 - 订阅明细
};

// 可自定义扩展
const CUSTOM_COLORS = {
  // 用户可添加自定义指标颜色
};
```

---

## 7. Excel 解析要点（通用化）

### Sheet 名称检测

```python
# 通用化：根据实际sheet结构自动检测
def parse_excel_sheets(df_dict):
    members = []
    for sheet_name in df_dict.keys():
        # 检测是否为成员sheet
        if '预算明细' in sheet_name:
            # 提取成员名称
            member_name = sheet_name.replace('01-预算明细-', '').replace('01-预算明细', '')
            members.append(member_name)

    return members

# 示例sheet结构
example_sheets = [
    '01-预算明细',              # 部门汇总
    '01-预算明细-成员A',       # 成员A
    '01-预算明细-成员B',       # 成员B
    '02-实际收款明细',          # 收款明细
    '03-商机列表',             # 商机
]
```

### 列名处理（通用化）

```python
# 通用化：动态适配不同列名
def normalize_columns(df):
    column_mapping = {
        '预计收款月份': 'month',
        '预计收款份': 'month',  # 容错处理
        '客户名称': 'customer',
        '产品': 'product',
        '金额': 'amount',
        '类型': 'type',
        '服务类型': 'serviceType',
    }

    df_normalized = df.copy()
    for old_col, new_col in column_mapping.items():
        if old_col in df.columns:
            df_normalized = df_normalized.rename(columns={old_col: new_col})

    return df_normalized
```

---

## 8. 数据验证规则（通用化）

| 字段 | 验证规则 |
|------|---------|
| amount | > 0，数字 |
| month | 1-12 整数 |
| type | 只能是配置的指标类型 |
| serviceType | 仅当 type='服务' 时需要 |
| customer | 非空字符串 |

---

## 9. 配置化示例

```typescript
// 完整配置对象
export const BUDGET_CONFIG = {
  // 年度预算（可自定义）
  annualBudget: {
    overall: 18000000,
    subscription: 13000000,
    service: 5000000,
  },

  // 团队成员（数量不限，名称可自定义）
  teamMembers: [
    '成员A',
    '成员B',
    '成员C',
    '成员D',
  ],

  // 指标类型（可扩展）
  metricTypes: [
    { key: 'overall', name: '整体指标', color: '#3B82F6' },
    { key: 'subscription', name: '订阅指标', color: '#10B981' },
    { key: 'service', name: '服务指标', color: '#8B5CF6' },
  ],

  // 服务类型（可扩展）
  serviceTypes: [
    '专项服务',
    '高级服务',
    '标准服务',
  ],

  // 季度分配（可自定义）
  quarterlyRatio: {
    Q1: 0.25,
    Q2: 0.25,
    Q3: 0.25,
    Q4: 0.25,
  },

  // 月份范围
  monthRange: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
};
```