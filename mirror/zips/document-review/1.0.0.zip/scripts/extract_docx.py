#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""提取 DOCX 文档内容并保留结构"""

import zipfile
import re
import os
import sys

def extract_docx(filepath):
    """提取 DOCX 内容为 Markdown"""
    output = []

    with zipfile.ZipFile(filepath, 'r') as z:
        # 读取 document.xml
        with z.open('word/document.xml') as f:
            content = f.read().decode('utf-8')

        # 按段落提取
        paragraphs = re.findall(r'<w:p[^>]*>(.*?)</w:p>', content, re.DOTALL)

        current_heading_level = 0

        for para in paragraphs:
            # 提取文本
            texts = re.findall(r'<w:t[^>]*>([^<]*)</w:t>', para)
            para_text = ''.join(texts).strip()

            if not para_text:
                continue

            # 检查样式
            style_match = re.search(r'w:pStyle w:val="([^"]*)"', para)
            if not style_match:
                style_match = re.search(r"w:pStyle w:val='([^']*)'", para)

            if style_match:
                style = style_match.group(1)
                # 标题映射
                heading_map = {
                    'Heading1': 1, 'Heading2': 2, 'Heading3': 3,
                    'Heading4': 4, 'Heading5': 5, 'Heading6': 6,
                    'Title': 1, 'Subtitle': 2
                }
                if style in heading_map:
                    level = heading_map[style]
                    output.append(f"{'#' * level} {para_text}\n")
                    continue

            # 检查是否是章节标题模式（如"第一章"、"1.1"等）
            if re.match(r'^第 [一二三四五六七八九十]+章\s+', para_text):
                output.append(f"# {para_text}\n")
            elif re.match(r'^\d+\.\d+\s+', para_text):
                # 二级标题 如 1.1
                output.append(f"## {para_text}\n")
            elif re.match(r'^\d+\.\d+\.\d+\s+', para_text):
                # 三级标题 如 1.1.1
                output.append(f"### {para_text}\n")
            else:
                # 普通段落
                output.append(para_text)

    return '\n\n'.join(output)

if __name__ == '__main__':
    # 查找输液系统文件
    os.chdir(r'C:\Users\Administrator\AppData\Local\Temp\lobsterai\attachments')

    files = [f for f in os.listdir('.') if '输液系统' in f and f.endswith('.docx')]
    if not files:
        print('未找到文件')
        sys.exit(1)

    filename = files[0]
    print(f'正在处理：{filename}')

    markdown = extract_docx(filename)

    with open('doc_for_review.md', 'w', encoding='utf-8') as f:
        f.write(markdown)

    print(f'提取完成：{len(markdown)} 字符')
    print('已保存到 doc_for_review.md')
