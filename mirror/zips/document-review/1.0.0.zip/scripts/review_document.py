#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文档审核脚本 - Document Review Script
对文档进行全面审核，包括格式、逻辑、清晰度和可行性评估
"""

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class DocumentReviewer:
    """文档审核器"""

    def __init__(self, document_path: str, criteria: str = "general"):
        self.document_path = document_path
        self.criteria = criteria
        self.content = ""
        self.sections = []
        self.issues = {
            "format": [],
            "logic": [],
            "clarity": [],
            "feasibility": []
        }
        self.scores = {
            "format": 0,
            "logic": 0,
            "clarity": 0,
            "feasibility": 0
        }

    def extract_content(self) -> bool:
        """提取文档内容"""
        path = Path(self.document_path)

        if not path.exists():
            print(f"错误：文件不存在 - {self.document_path}")
            return False

        ext = path.suffix.lower()

        try:
            if ext in ['.md', '.txt']:
                with open(path, 'r', encoding='utf-8') as f:
                    self.content = f.read()
            elif ext == '.docx':
                self.content = self._extract_docx(path)
            elif ext == '.pdf':
                self.content = self._extract_pdf(path)
            else:
                print(f"警告：不支持的文件格式 {ext}，尝试作为文本读取")
                with open(path, 'r', encoding='utf-8') as f:
                    self.content = f.read()

            self._parse_sections()
            return True

        except Exception as e:
            print(f"错误：读取文档失败 - {str(e)}")
            return False

    def _extract_docx(self, path: Path) -> str:
        """提取 Word 文档内容"""
        try:
            # 优先使用 pandoc
            result = subprocess.run(
                ['pandoc', '--track-changes=all', str(path), '-t', 'markdown'],
                capture_output=True,
                text=True,
                encoding='utf-8'
            )
            if result.returncode == 0:
                return result.stdout
        except FileNotFoundError:
            pass

        # 备用：python-docx
        try:
            from docx import Document
            doc = Document(path)
            return '\n\n'.join([p.text for p in doc.paragraphs])
        except ImportError:
            print("警告：未安装 python-docx，尝试其他方式")
        except Exception:
            pass

        # 最后尝试：直接解压读取 XML
        return self._extract_docx_raw(path)

    def _extract_docx_raw(self, path: Path) -> str:
        """从 DOCX 原始 XML 提取文本"""
        import zipfile
        import xml.etree.ElementTree as ET

        try:
            with zipfile.ZipFile(path, 'r') as z:
                with z.open('word/document.xml') as f:
                    tree = ET.parse(f)
                    root = tree.getroot()
                    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                    texts = []
                    for t in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
                        if t.text:
                            texts.append(t.text)
                    return ' '.join(texts)
        except Exception as e:
            print(f"警告：DOCX 提取失败 - {e}")
            return ""

    def _extract_pdf(self, path: Path) -> str:
        """提取 PDF 文档内容"""
        # 尝试 pymupdf
        try:
            import fitz
            doc = fitz.open(path)
            text = ""
            for page in doc:
                text += page.get_text()
            doc.close()
            return text
        except ImportError:
            pass
        except Exception:
            pass

        # 尝试 pdftotext
        try:
            result = subprocess.run(
                ['pdftotext', '-layout', str(path), '-'],
                capture_output=True,
                text=True,
                encoding='utf-8'
            )
            if result.returncode == 0:
                return result.stdout
        except FileNotFoundError:
            pass

        print("警告：无法提取 PDF 内容，请安装 pymupdf 或 poppler")
        return ""

    def _parse_sections(self) -> None:
        """解析文档章节结构"""
        lines = self.content.split('\n')
        current_section = {"title": "引言", "level": 0, "content": [], "line_start": 0}

        for i, line in enumerate(lines):
            # 检测标题层级
            match = re.match(r'^(#{1,6})\s+(.+)$', line.strip())
            if match:
                level = len(match.group(1))
                title = match.group(2).strip()

                if current_section["content"]:
                    self.sections.append(current_section)

                current_section = {
                    "title": title,
                    "level": level,
                    "content": [],
                    "line_start": i
                }
            else:
                current_section["content"].append(line)

        if current_section["content"]:
            self.sections.append(current_section)

    def check_format(self) -> None:
        """检查文档格式"""
        issues = []

        # 1. 检查标题层级
        prev_level = 0
        for i, section in enumerate(self.sections):
            level = section["level"]
            if level > 0:
                # 检查层级跳跃（允许从 0 到任何级别，但中间不能跳跃）
                if prev_level > 0 and level > prev_level + 1:
                    issues.append({
                        "severity": "中",
                        "description": f"标题层级跳跃（从 H{prev_level} 直接到 H{level}）",
                        "location": f"第{section['title']}节",
                        "suggestion": f"建议使用 H{prev_level + 1} 作为中间层级"
                    })
                # 检查同级标题内的子标题跳跃
                elif prev_level > 0 and level == prev_level:
                    # 同级标题，检查下一个节的层级
                    pass
                prev_level = level

        # 2. 检查段落长度
        for i, section in enumerate(self.sections):
            para_text = '\n'.join(section["content"])
            paras = [p for p in para_text.split('\n\n') if len(p.strip()) > 50]
            for j, para in enumerate(paras):
                if len(para) > 400:
                    issues.append({
                        "severity": "低",
                        "description": f"段落过长（{len(para)} 字），建议拆分",
                        "location": f"第{section['title']}节",
                        "suggestion": "将长段落按语义拆分为 200-300 字的短段落"
                    })

        # 3. 检查文档结构完整性
        has_intro = any("引言" in s["title"] or "简介" in s["title"] or "背景" in s["title"]
                       for s in self.sections)
        has_conclusion = any("结论" in s["title"] or "总结" in s["title"] or "展望" in s["title"]
                            for s in self.sections)

        if not has_intro and len(self.sections) > 2:
            issues.append({
                "severity": "中",
                "description": "文档缺少引言或背景说明",
                "location": "文档开头",
                "suggestion": "添加引言章节，说明文档目的和背景"
            })

        if not has_conclusion and len(self.sections) > 2:
            issues.append({
                "severity": "中",
                "description": "文档缺少结论或总结",
                "location": "文档结尾",
                "suggestion": "添加结论章节，总结核心观点和建议"
            })

        # 4. 检查列表格式
        list_patterns = [r'^[\s]*[-*+]\s+', r'^[\s]*\d+\.\s+']
        for section in self.sections:
            para_text = '\n'.join(section["content"])
            for pattern in list_patterns:
                matches = re.findall(pattern, para_text, re.MULTILINE)
                if matches:
                    # 检查列表项是否完整
                    pass

        self.issues["format"] = issues

        # 计算格式得分
        base_score = 100
        penalty = {"高": 15, "中": 8, "低": 3}
        for issue in issues:
            base_score -= penalty.get(issue["severity"], 3)
        self.scores["format"] = max(0, min(100, base_score))

    def analyze_logic(self) -> None:
        """分析内容逻辑性"""
        issues = []

        # 1. 检查章节间过渡
        for i in range(1, len(self.sections)):
            prev = self.sections[i-1]
            curr = self.sections[i]

            # 简单的过渡检查：查看是否有承接词
            transition_words = ["因此", "然而", "此外", "同时", "基于", "接下来", "另一方面"]
            curr_text = ' '.join(curr["content"][:3]).lower()

            has_transition = any(word in curr_text for word in transition_words)
            if not has_transition and prev["level"] == curr["level"]:
                # 可能存在过渡生硬
                pass  # 不强制要求，避免过度报告

        # 2. 检查论点 - 论据匹配
        argument_indicators = ["应该", "必须", "建议", "需要", "因此", "所以", "由此可见"]
        evidence_indicators = ["数据", "显示", "表明", "根据", "研究", "统计", "例如", "比如"]

        for section in self.sections:
            text = '\n'.join(section["content"])
            has_argument = any(word in text for word in argument_indicators)
            has_evidence = any(word in text for word in evidence_indicators)

            if has_argument and not has_evidence and len(text) > 100:
                issues.append({
                    "severity": "高",
                    "description": f"提出论点但缺乏数据或案例支撑",
                    "location": f"第{section['title']}节",
                    "suggestion": "补充相关数据、调研结果或实际案例来支撑论点"
                })

        # 3. 检查矛盾表述
        positive_words = ["增长", "提升", "改善", "优化", "成功", "有效"]
        negative_words = ["下降", "降低", "恶化", "失败", "无效", "问题"]

        for section in self.sections:
            text = '\n'.join(section["content"])
            has_positive = any(word in text for word in positive_words)
            has_negative = any(word in text for word in negative_words)

            # 如果同一段落同时出现大量正面和负面词汇，可能存在矛盾
            if has_positive and has_negative:
                # 需要更复杂的 NLP 来判断，这里只记录提示
                pass

        self.issues["logic"] = issues

        # 计算逻辑得分
        base_score = 100
        penalty = {"高": 15, "中": 8, "低": 3}
        for issue in issues:
            base_score -= penalty.get(issue["severity"], 3)
        self.scores["logic"] = max(0, min(100, base_score))

    def analyze_clarity(self) -> None:
        """分析表述清晰度"""
        issues = []

        vague_words = ["可能", "大概", "也许", "左右", "一些", "某些", "相关", "等", "觉得", "认为", "应该", "挺好", "更好", "更好", "不错"]

        vague_locations = []
        for section in self.sections:
            text = '\n'.join(section["content"])

            # 1. 检查模糊表述 - 记录具体位置
            for word in vague_words:
                if word in text:
                    vague_locations.append(f"{section['title']}节 (使用'{word}')")

            # 2. 检查句子长度
            sentences = re.split(r'[。！？.!?]', text)
            long_sentences = [s for s in sentences if len(s.strip()) > 60]
            if len(long_sentences) > 3:
                issues.append({
                    "severity": "低",
                    "description": f"存在{len(long_sentences)}个长句（超过 60 字），建议简化",
                    "location": f"第{section['title']}节",
                    "suggestion": "将复杂长句拆分为 2-3 个短句，提高可读性"
                })

        # 汇总模糊表述问题
        if len(vague_locations) > 3:
            unique_vague = list(set(vague_locations))[:5]
            issues.append({
                "severity": "中",
                "description": f"使用较多模糊词汇（共{len(vague_locations)}处），包括：{', '.join(unique_vague)}",
                "location": "多处章节",
                "suggestion": "将模糊表述改为具体数据或明确陈述，如'大概需要一些人手'改为'需要 3 名开发人员'"
            })

        self.issues["clarity"] = issues

        # 计算清晰度得分
        base_score = 100
        penalty = {"高": 15, "中": 8, "低": 3}
        for issue in issues:
            base_score -= penalty.get(issue["severity"], 3)
        self.scores["clarity"] = max(0, min(100, base_score))

    def analyze_feasibility(self) -> None:
        """分析方案可行性"""
        issues = []
        text = self.content.lower()

        # 1. 检查是否包含具体执行步骤
        action_keywords = ["步骤", "流程", "计划", "方案", "实施", "执行", "操作"]
        detail_keywords = ["第一", "第二", "首先", "然后", "接着", "最后", "step", "phase", "阶段"]
        has_actions = any(word in text for word in action_keywords)
        has_details = any(word in text for word in detail_keywords)

        if not has_actions or not has_details:
            issues.append({
                "severity": "高",
                "description": "文档未明确说明具体的执行步骤或操作流程",
                "location": "全文",
                "suggestion": "添加详细的实施计划，包括具体步骤、责任人和时间节点"
            })

        # 2. 检查是否包含具体资源需求（而非模糊表述）
        resource_keywords = ["资源", "预算", "成本", "人员", "时间", "设备", "资金"]
        vague_resource_keywords = ["一些", "某些", "相关", "大概", "左右", "即将", "不久"]
        has_resources = any(word in text for word in resource_keywords)
        has_vague_resources = any(word in text for word in vague_resource_keywords)

        if not has_resources or (has_vague_resources and not has_resources):
            issues.append({
                "severity": "高",
                "description": "未说明所需资源（人力、物力、财力、时间等），或仅使用模糊表述",
                "location": "全文",
                "suggestion": "补充具体资源需求清单，如'需要 3 名开发人员、预算 50 万、周期 6 个月'"
            })

        # 3. 检查是否包含具体时间规划
        time_keywords = ["202", "203", "个月", "周", "天", "日", "季度", "半年", "一年", "Q1", "Q2", "Q3", "Q4"]
        has_time = any(word in text for word in time_keywords)
        vague_time_keywords = ["将来", "未来", "不久", "即将", "到时候", "适时", "择机"]
        has_vague_time = any(word in text for word in vague_time_keywords)

        if not has_time or has_vague_time:
            issues.append({
                "severity": "中",
                "description": "时间规划不明确，使用模糊表述（如'不久的将来'、'预计适时完成'）",
                "location": "全文",
                "suggestion": "使用具体时间节点，如'2026 年 6 月 30 日前完成第一阶段'"
            })

        # 4. 检查是否包含风险评估
        risk_keywords = ["风险", "挑战", "困难", "障碍", "应对", "预案", "mitigation"]
        has_risks = any(word in text for word in risk_keywords)

        if not has_risks:
            issues.append({
                "severity": "中",
                "description": "缺少风险评估和应对预案",
                "location": "全文",
                "suggestion": "添加风险分析章节，识别潜在风险并提供应对措施"
            })

        # 5. 检查是否包含可量化的成功指标
        metric_keywords = ["指标", "目标", "kpi", "衡量", "评估", "验收", "成功标准", "%", "提升", "降低"]
        has_metrics = any(word in text for word in metric_keywords)

        if not has_metrics:
            issues.append({
                "severity": "中",
                "description": "未定义可量化的成功指标或验收标准",
                "location": "全文",
                "suggestion": "明确说明如何衡量项目/方案的成功，设定可量化的目标（如'效率提升 30%'）"
            })

        self.issues["feasibility"] = issues

        # 计算可行性得分
        base_score = 100
        penalty = {"高": 15, "中": 8, "低": 3}
        for issue in issues:
            base_score -= penalty.get(issue["severity"], 3)
        self.scores["feasibility"] = max(0, min(100, base_score))

    def generate_report(self, output_format: str = "markdown") -> str:
        """生成审核报告"""
        total_score = sum(self.scores.values()) / 4

        if output_format == "json":
            return json.dumps({
                "document": self.document_path,
                "timestamp": datetime.now().isoformat(),
                "scores": self.scores,
                "total_score": round(total_score, 1),
                "issues": self.issues
            }, ensure_ascii=False, indent=2)

        # Markdown 格式
        def get_grade(score):
            if score >= 90: return "优"
            if score >= 75: return "良"
            if score >= 60: return "中"
            return "差"

        report = []
        report.append("# 文档审核报告\n")
        report.append(f"**审核文档**: {self.document_path}\n")
        report.append(f"**审核时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")

        # 综合评分
        report.append("\n## 📊 综合评分\n")
        report.append("| 维度 | 评分 | 等级 |")
        report.append("|------|------|------|")
        report.append(f"| 格式规范性 | {self.scores['format']} | {get_grade(self.scores['format'])} |")
        report.append(f"| 内容逻辑性 | {self.scores['logic']} | {get_grade(self.scores['logic'])} |")
        report.append(f"| 表述清晰度 | {self.scores['clarity']} | {get_grade(self.scores['clarity'])} |")
        report.append(f"| 方案可行性 | {self.scores['feasibility']} | {get_grade(self.scores['feasibility'])} |")
        report.append(f"| **综合** | **{round(total_score, 1)}** | **{get_grade(total_score)}** |")

        # 问题清单
        report.append("\n## ⚠️ 发现的问题\n")

        has_issues = False

        if self.issues["format"]:
            has_issues = True
            report.append("\n### 格式问题\n")
            for i, issue in enumerate(self.issues["format"], 1):
                report.append(f"{i}. [{issue['severity']}] {issue['description']}")
                report.append(f"   - 位置：{issue['location']}")
                report.append(f"   - 建议：{issue['suggestion']}\n")

        if self.issues["logic"]:
            has_issues = True
            report.append("\n### 逻辑问题\n")
            for i, issue in enumerate(self.issues["logic"], 1):
                report.append(f"{i}. [{issue['severity']}] {issue['description']}")
                report.append(f"   - 位置：{issue['location']}")
                report.append(f"   - 建议：{issue['suggestion']}\n")

        if self.issues["clarity"]:
            has_issues = True
            report.append("\n### 表述问题\n")
            for i, issue in enumerate(self.issues["clarity"], 1):
                report.append(f"{i}. [{issue['severity']}] {issue['description']}")
                report.append(f"   - 位置：{issue['location']}")
                report.append(f"   - 建议：{issue['suggestion']}\n")

        if self.issues["feasibility"]:
            has_issues = True
            report.append("\n### 可行性问题\n")
            for i, issue in enumerate(self.issues["feasibility"], 1):
                report.append(f"{i}. [{issue['severity']}] {issue['description']}")
                report.append(f"   - 位置：{issue['location']}")
                report.append(f"   - 建议：{issue['suggestion']}\n")

        if not has_issues:
            report.append("\n✅ 未发现明显问题，文档质量良好！\n")

        # 改进建议汇总
        all_suggestions = []
        for category in self.issues.values():
            for issue in category:
                if issue["suggestion"] not in all_suggestions:
                    all_suggestions.append(issue["suggestion"])

        if all_suggestions:
            report.append("\n## 💡 核心改进建议\n")
            for i, suggestion in enumerate(all_suggestions[:5], 1):
                report.append(f"{i}. {suggestion}")

        # 总结
        report.append("\n## 📝 总结\n")

        # 统计问题数量
        high_count = sum(1 for cat in self.issues.values() for issue in cat if issue.get('severity') == '高')
        medium_count = sum(1 for cat in self.issues.values() for issue in cat if issue.get('severity') == '中')
        low_count = sum(1 for cat in self.issues.values() for issue in cat if issue.get('severity') == '低')

        # 找出最弱维度
        min_dim = min(self.scores, key=self.scores.get)
        dim_names = {'format': '格式规范', 'logic': '内容逻辑', 'clarity': '表述清晰', 'feasibility': '方案可行'}

        if total_score >= 90:
            report.append(f"本文档质量优秀（综合评分{round(total_score, 1)}分），整体结构清晰，内容完整。\n")
        elif total_score >= 80:
            report.append(f"本文档整体质量良好（综合评分{round(total_score, 1)}分），结构清晰，内容完整。\n")
        elif total_score >= 60:
            report.append(f"本文档基本框架完整（综合评分{round(total_score, 1)}分），但在多个方面需要改进。\n")
        else:
            report.append(f"本文档存在较多问题（综合评分{round(total_score, 1)}分），需要全面修订。\n")

        if high_count > 0:
            report.append(f"**优先处理**: 发现{high_count}个高严重程度问题，建议优先修复。\n")

        report.append(f"**重点改进方向**: {dim_names.get(min_dim, '未知')} 是当前最薄弱的环节（{self.scores[min_dim]}分），建议重点关注。")

        return '\n'.join(report)

    def review(self, output_format: str = "markdown") -> str:
        """执行完整审核流程"""
        print(f"正在审核文档：{self.document_path}")

        # 1. 提取内容
        print("  → 提取文档内容...")
        if not self.extract_content():
            return "审核失败：无法读取文档内容"

        print(f"  → 文档长度：{len(self.content)} 字符")
        print(f"  → 章节数量：{len(self.sections)}")

        # 2. 格式检查
        print("  → 检查文档格式...")
        self.check_format()

        # 3. 逻辑分析
        print("  → 分析内容逻辑...")
        self.analyze_logic()

        # 4. 清晰度分析
        print("  → 分析表述清晰度...")
        self.analyze_clarity()

        # 5. 可行性分析
        print("  → 分析方案可行性...")
        self.analyze_feasibility()

        # 6. 生成报告
        print("  → 生成审核报告...")
        report = self.generate_report(output_format)

        print("\n✅ 审核完成！")
        return report


def main():
    parser = argparse.ArgumentParser(
        description='文档审核工具 - 对文档进行全面质量评估',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python review_document.py document.docx
  python review_document.py report.pdf --output json
  python review_document.py plan.md --criteria prd
        """
    )

    parser.add_argument('document_path', help='待审核文档路径')
    parser.add_argument(
        '--output', '-o',
        choices=['markdown', 'word', 'json'],
        default='markdown',
        help='输出格式（默认：markdown）'
    )
    parser.add_argument(
        '--criteria', '-c',
        choices=['general', 'prd', 'technical'],
        default='general',
        help='审核标准（默认：general 通用）'
    )
    parser.add_argument(
        '--output-file',
        help='将报告保存到指定文件'
    )

    args = parser.parse_args()

    # 创建审核器并执行
    reviewer = DocumentReviewer(args.document_path, args.criteria)
    report = reviewer.review(output_format=args.output)

    # 输出报告
    if args.output_file:
        with open(args.output_file, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"\n报告已保存到：{args.output_file}")
    else:
        print("\n" + "=" * 60)
        print(report)

    return 0


if __name__ == '__main__':
    sys.exit(main())
