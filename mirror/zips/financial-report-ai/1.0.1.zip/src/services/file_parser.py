#!/usr/bin/env python3
"""
File Parser for Financial Report AI
Supports: CSV, XLSX, XLS, PDF
Extracts structured tabular data from uploaded financial statements.
"""

import sys
import json
import os
import traceback
from pathlib import Path


def parse_csv(filepath):
    """Parse CSV file into a list of row dicts."""
    import pandas as pd
    df = pd.read_csv(filepath, dtype=str, keep_default_na=False)
    df = df.fillna("")
    return {
        "headers": list(df.columns),
        "rows": df.values.tolist(),
        "shape": list(df.shape),
        "raw_sample": df.head(20).to_dict(orient="records"),
    }


def parse_excel(filepath):
    """Parse Excel file - auto-detect sheet, return all sheets."""
    import pandas as pd
    xl = pd.ExcelFile(filepath)
    sheets = {}
    for sheet_name in xl.sheet_names:
        df = pd.read_excel(filepath, sheet_name=sheet_name, dtype=str, header=None, keep_default_na=False)
        df = df.fillna("")
        sheets[sheet_name] = {
            "headers": [str(h) for h in df.iloc[0].tolist()],
            "rows": df.iloc[1:].values.tolist(),
            "shape": [df.shape[0] - 1, df.shape[1]],
            "raw_sample": df.head(20).to_dict(orient="records"),
        }
    return {
        "sheets": sheets,
        "sheet_names": xl.sheet_names,
    }


def parse_pdf(filepath):
    """Parse PDF financial statements using pdfplumber."""
    import pdfplumber
    import pandas as pd

    tables = []
    all_text = []

    try:
        with pdfplumber.open(filepath) as pdf:
            for i, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                all_text.append({"page": i + 1, "text": text})

                # Try to extract tables
                page_tables = page.extract_tables()
                for j, table in enumerate(page_tables):
                    if table:
                        headers = table[0] if table else []
                        rows = table[1:] if len(table) > 1 else []
                        tables.append({
                            "page": i + 1,
                            "table_index": j,
                            "headers": [str(h or "").strip() for h in headers],
                            "rows": [[str(cell or "").strip() for cell in row] for row in rows],
                            "shape": [len(rows), len(headers)],
                        })
    except Exception as e:
        return {"error": str(e), "tables": [], "text": []}

    return {
        "tables": tables,
        "text": all_text,
        "num_pages": len(all_text),
    }


def parse_file(filepath, file_ext=None):
    """Main dispatcher - auto-detect format from extension or content."""
    if file_ext is None:
        file_ext = Path(filepath).suffix.lower()

    if file_ext in [".csv"]:
        return {"format": "csv", **parse_csv(filepath)}
    elif file_ext in [".xlsx", ".xls"]:
        return {"format": "excel", **parse_excel(filepath)}
    elif file_ext in [".pdf"]:
        return {"format": "pdf", **parse_pdf(filepath)}
    else:
        return {"error": f"Unsupported format: {file_ext}"}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: python file_parser.py <filepath>"}))
        sys.exit(1)

    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(json.dumps({"error": f"File not found: {filepath}"}))
        sys.exit(1)

    try:
        result = parse_file(filepath)
        print(json.dumps(result, ensure_ascii=False, default=str))
    except Exception as e:
        print(json.dumps({"error": str(e), "trace": traceback.format_exc()}, ensure_ascii=False))
        sys.exit(1)
