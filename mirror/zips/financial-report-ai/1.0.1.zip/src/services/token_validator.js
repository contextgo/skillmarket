/**
 * Token Validation Service
 * Validates API keys via api.yk-global.com/v1/verify
 * Caches results for 5 minutes to reduce API calls
 * 
 * Fallback: on network error → FREE tier (do not block usage)
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// --- Config ---
const VALIDATE_ENDPOINT = 'https://api.yk-global.com/v1/verify';
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes
const CACHE_DIR = path.join(process.env.OPENCLAW_SKILL_DIR || __dirname, '..', '.token_cache');

// Ensure cache directory exists
try {
  if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
} catch (_) {}

// --- Cache helpers ---
function cacheKey(apiKey) {
  // Hash the key to avoid storing raw keys in filesystem
  return crypto.createHash('sha256').update(apiKey).digest('hex') + '.json';
}

function readCache(apiKey) {
  try {
    const file = path.join(CACHE_DIR, cacheKey(apiKey));
    if (!fs.existsSync(file)) return null;
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (Date.now() - data.ts > CACHE_TTL_MS) {
      fs.unlinkSync(file);
      return null;
    }
    return data;
  } catch (_) {
    return null;
  }
}

function writeCache(apiKey, result) {
  try {
    const file = path.join(CACHE_DIR, cacheKey(apiKey));
    fs.writeFileSync(file, JSON.stringify({ ...result, ts: Date.now() }), 'utf8');
  } catch (_) {}
}

// --- Token validation ---
async function validateToken(apiKey) {
  if (!apiKey || apiKey.trim() === '') {
    return { valid: false, plan: 'FREE', reason: 'no_api_key' };
  }

  // Check cache first
  const cached = readCache(apiKey);
  if (cached) return cached;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(VALIDATE_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: '{}',
      signal: controller.signal,
    });

    clearTimeout(timeout);

    let data;
    try {
      data = await response.json();
    } catch (_) {
      data = {};
    }

    if (response.ok && data.valid === true) {
      const result = {
        valid: true,
        plan: data.plan || detectPlanFromKey(apiKey),
        features: data.features || {},
      };
      writeCache(apiKey, result);
      return result;
    } else {
      return { valid: false, plan: 'FREE', reason: data.reason || 'invalid_token' };
    }
  } catch (err) {
    // Network error / timeout → degrade to FREE tier, do not block
    console.error('[TokenValidator] Validation failed, degrading to FREE:', err.message);
    return { valid: false, plan: 'FREE', reason: 'network_error' };
  }
}

function detectPlanFromKey(apiKey) {
  // Token prefix convention: FIN-RPT-*
  if (apiKey.startsWith('FIN-RPT-PRO') || apiKey.startsWith('FIN-RPT-ENT')) return 'PRO';
  if (apiKey.startsWith('FIN-RPT-STD')) return 'STANDARD';
  if (apiKey.startsWith('FIN-RPT-FREE')) return 'FREE';
  return 'STANDARD'; // default fallback
}

// --- Plan limits ---
const PLAN_LIMITS = {
  FREE: { monthly: 3, formats: ['csv', 'xlsx'], dimensions: 3, charts: 0 },
  STANDARD: { monthly: 50, formats: ['csv', 'xlsx', 'pdf'], dimensions: 10, charts: 5 },
  PRO: { monthly: 300, formats: ['csv', 'xlsx', 'pdf'], dimensions: 99, charts: 15 },
  MAX: { monthly: Infinity, formats: ['csv', 'xlsx', 'pdf'], dimensions: 99, charts: 99 },
};

function getPlanLimits(plan) {
  return PLAN_LIMITS[plan] || PLAN_LIMITS.FREE;
}

module.exports = { validateToken, getPlanLimits, detectPlanFromKey };