#!/usr/bin/env python3
"""
Financial Report AI Analysis Engine
Generates structured AI-powered financial analysis reports.

Supports all analysis dimensions:
  1. 收入结构分析 (Revenue Structure)
  2. 成本异常检测 (Cost Anomaly Detection)
  3. 利润分析 (Profitability)
  4. 现金流分析 (Cash Flow)
  5. 资产负债分析 (Balance Sheet)
  6. KPI达成分析 (KPI Achievement)
  7. 异常预警 (Anomaly Alerts)
"""

import sys
import json
import re
import os
import traceback
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any
from datetime import datetime


# ─────────────────────────────────────────────────────────────────────────────
# Data Classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AnalysisSection:
    title: str
    content: str  # Markdown content
    data: Dict[str, Any] = field(default_factory=dict)
    has_chart: bool = False
    chart_path: Optional[str] = None


@dataclass
class AnomalyAlert:
    dimension: str
    severity: str  # 🔴 HIGH / 🟠 MEDIUM / 🟡 LOW
    description: str
    value: Optional[float] = None
    threshold: Optional[float] = None
    suggestion: str = ""


@dataclass
class AnalysisReport:
    company_name: str
    report_date: str
    period: str
    tier: str  # FREE / STANDARD / PRO / MAX
    revenue: AnalysisSection
    cost: AnalysisSection
    profit: AnalysisSection
    cashflow: AnalysisSection
    balance_sheet: AnalysisSection
    kpi: AnalysisSection
    anomalies: List[AnomalyAlert]
    summary: str
    raw_data_snippet: Dict[str, Any] = field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# Number parsing helpers
# ─────────────────────────────────────────────────────────────────────────────

def parse_number(val) -> Optional[float]:
    """Parse a value to float, handling currency/comma formats."""
    if val is None or val == "":
        return None
    s = str(val).strip()
    # Remove currency symbols and commas
    s = re.sub(r'[¥$,，￥\s]', '', s)
    # Handle parentheses for negative numbers
    if s.startswith('(') and s.endswith(')'):
        s = '-' + s[1:-1]
    try:
        return float(s)
    except ValueError:
        return None


def pct_change(current, previous) -> Optional[float]:
    """Calculate percentage change."""
    curr = parse_number(current)
    prev = parse_number(previous)
    if curr is None or prev is None or prev == 0:
        return None
    return round((curr - prev) / abs(prev) * 100, 2)


def detect_column_type(headers, rows) -> Dict[str, str]:
    """Auto-detect column types by header keywords."""
    type_map = {}
    all_headers = [str(h).lower() for h in headers]

    # Common financial column patterns
    patterns = {
        "revenue": ["收入", "营业收入", "销售额", "sales", "revenue", "主营收入"],
        "gross_profit": ["毛利", "毛利润", "gross", "gross_profit"],
        "net_profit": ["净利润", "净利", "net", "net_profit", "纯利"],
        "total_cost": ["成本", "营业成本", "cost", "total_cost"],
        "operating_cost": ["运营成本", "经营成本", "operating_cost"],
        "admin_cost": ["管理费用", "admin", "管理费"],
        "rd_cost": ["研发费用", "研发", "rd", "research"],
        "sales_cost": ["销售费用", "销售", "selling", "marketing"],
        "financial_cost": ["财务费用", "财务", "financial"],
        "cashflow_operating": ["经营活动现金流", "经营现金流", "operating_cashflow", "cashflow_operating"],
        "cashflow_investing": ["投资活动现金流", "投资现金流", "investing_cashflow"],
        "cashflow_financing": ["筹资活动现金流", "筹资现金流", "financing_cashflow"],
        "total_assets": ["总资产", "资产总计", "total_assets", "assets"],
        "total_liabilities": ["总负债", "负债合计", "total_liabilities", "liabilities"],
        "equity": ["所有者权益", "净资产", "equity", "shareholders_equity"],
        "current_assets": ["流动资产", "current_assets"],
        "current_liabilities": ["流动负债", "current_liabilities"],
        "fixed_assets": ["固定资产", "fixed_assets"],
        "revenue_yoy": ["收入同比增长", "收入增长率", "revenue_growth", "yoy"],
    }

    for col_idx, header in enumerate(headers):
        h = str(header).lower()
        for col_type, keywords in patterns.items():
            if any(kw in h for kw in keywords):
                type_map[col_idx] = col_type
                break

    return type_map


# ─────────────────────────────────────────────────────────────────────────────
# AI Prompt Templates
# ─────────────────────────────────────────────────────────────────────────────

ANALYSIS_PROMPT_TEMPLATE = """你是一位专业财务分析师。请根据以下财务报表数据，生成结构化经营分析报告。

**数据来源**：
{file_info}

**数据内容**（{sheet_name}）：
表头: {headers}
数据行（前20行）:
{rows}

---

请按以下7个维度进行分析，只分析数据中存在的维度，数据中找不到的维度说明"未检测到相关数据"：

## 1. 收入结构分析
- 总收入金额
- 收入同比/环比变化（如有）
- 各业务线/产品线占比（如可识别）
- 收入趋势评价

## 2. 成本异常检测
- 总成本及占收入比例
- 各项成本占比（营业成本/管理费用/销售费用/研发费用/财务费用）
- 异常波动标注（与行业基准对比，超阈值标红）

## 3. 利润分析
- 毛利率、净利率
- 利润同比/环比变化
- 利润质量评价

## 4. 现金流分析
- 经营现金流净额
- 投资/筹资现金流（如有）
- 现金流健康度评价

## 5. 资产负债分析
- 资产结构（流动/非流动资产）
- 负债结构（流动/非流动负债）
- 资产负债率
- 偿债风险评价

## 6. KPI达成分析
- 将关键指标与"预算"、"目标"列对比（如存在）
- 达成率计算

## 7. 异常预警
- 列出所有异常：毛利率骤降、负债率过高、经营现金流为负、收入下滑等
- 严重程度：🔴 严重 / 🟠 注意 / 🟡 提醒

---

**输出格式**（严格按此JSON格式返回，不要输出其他内容）：
```json
{{
  "revenue": {{
    "total": "金额（万元）",
    "yoy_change": "同比%",
    "qoq_change": "环比%",
    "breakdown": "各业务线占比说明",
    "summary": "收入结构评价"
  }},
  "cost": {{
    "total": "总成本",
    "占比": "占收入%",
    "cost_breakdown": "各项成本占比",
    "anomalies": ["异常项列表"],
    "summary": "成本分析评价"
  }},
  "profit": {{
    "gross_margin": "毛利率%",
    "net_margin": "净利率%",
    "yoy_change": "利润同比%",
    "summary": "利润分析评价"
  }},
  "cashflow": {{
    "operating": "经营现金流净额",
    "investing": "投资现金流",
    "financing": "筹资现金流",
    "summary": "现金流健康度评价"
  }},
  "balance_sheet": {{
    "total_assets": "总资产",
    "total_liabilities": "总负债",
    "equity": "净资产",
    "debt_ratio": "资产负债率%",
    "current_ratio": "流动比率",
    "summary": "资产负债评价"
  }},
  "kpi": {{
    "achieved": ["已识别KPI及达成情况"],
    "missing": "未检测到预算/目标数据"
  }},
  "anomalies": [
    {{"dimension": "维度", "severity": "🔴/🟠/🟡", "description": "描述", "value": "数值", "suggestion": "建议"}}
  ],
  "summary": "整体经营评价（100字以内）"
}}
```
"""


def build_prompt(file_info: str, headers: List[str], rows: List[List], sheet_name: str = "主数据") -> str:
    """Build the AI analysis prompt."""
    rows_str = "\n".join([str(row) for row in rows[:20]])
    return ANALYSIS_PROMPT_TEMPLATE.format(
        file_info=file_info,
        sheet_name=sheet_name,
        headers=headers,
        rows=rows_str,
    )


def call_ai_analysis(prompt: str, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Call AI API for financial analysis. Returns parsed JSON or raises."""
    import urllib.request
    import urllib.error

    # Detect provider from model name or default to OpenAI-compatible
    if "deepseek" in model.lower():
        base_url = "https://api.deepseek.com/v1"
    elif "claude" in model.lower() or "anthropic" in model.lower():
        base_url = "https://api.anthropic.com/v1"
    elif "qwen" in model.lower():
        base_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    elif "minimax" in model.lower():
        base_url = "https://api.minimax.chat/v1"
    else:
        base_url = "https://api.openai.com/v1"

    url = f"{base_url}/chat/completions"

    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.3,
        "max_tokens": 4000,
    })

    headers_map = {
        "openai": {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        "deepseek": {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        "anthropic": {"x-api-key": api_key, "Content-Type": "application/json", "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true"},
        "qwen": {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        "minimax": {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    }

    # Choose headers based on provider
    if "anthropic" in base_url:
        headers = headers_map["anthropic"]
        # Anthropic uses different payload format
        payload_dict = {"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": 4000}
        payload = json.dumps(payload_dict)
    else:
        headers = headers_map.get(
            next((k for k in headers_map if k in base_url), "openai"),
            headers_map["openai"]
        )

    req = urllib.request.Request(url, data=payload.encode("utf-8"), headers=headers, method="POST")

    # Determine API type for response parsing
    is_anthropic = "anthropic" in base_url

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            # Parse response based on API provider
            if is_anthropic:
                # Anthropic response format
                content = result["content"][0]["text"]
            else:
                # OpenAI / DeepSeek / Qwen / MiniMax compatible format
                content = result["choices"][0]["message"]["content"]

            # Extract JSON from markdown code block if present
            json_match = re.search(r'```(?:json)?\s*(.*?)```', content, re.DOTALL)
            if json_match:
                content = json_match.group(1)

            return json.loads(content)
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8") if e.fp else ""
        raise Exception(f"AI API HTTP {e.code}: {err_body[:500]}")
    except Exception as e:
        raise Exception(f"AI API call failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# Report Builder (Fallback when AI is not available)
# ─────────────────────────────────────────────────────────────────────────────

def build_fallback_report(headers: List[str], rows: List[List]) -> Dict[str, Any]:
    """Build a basic structured report from parsed data without AI."""
    col_types = detect_column_type(headers, rows)

    report = {
        "revenue": {"total": "N/A", "yoy_change": "N/A", "qoq_change": "N/A", "breakdown": "需AI分析", "summary": "数据已解析，请配置AI API Key获取完整分析"},
        "cost": {"total": "N/A", "占比": "N/A", "cost_breakdown": "需AI分析", "anomalies": [], "summary": "数据已解析，请配置AI API Key获取完整分析"},
        "profit": {"gross_margin": "N/A", "net_margin": "N/A", "yoy_change": "N/A", "summary": "数据已解析，请配置AI API Key获取完整分析"},
        "cashflow": {"operating": "N/A", "investing": "N/A", "financing": "N/A", "summary": "数据已解析，请配置AI API Key获取完整分析"},
        "balance_sheet": {"total_assets": "N/A", "total_liabilities": "N/A", "equity": "N/A", "debt_ratio": "N/A", "current_ratio": "N/A", "summary": "数据已解析，请配置AI API Key获取完整分析"},
        "kpi": {"achieved": [], "missing": "未检测到预算/目标数据"},
        "anomalies": [],
        "summary": "数据已解析。配置AI API Key后，将生成完整经营分析报告。"
    }
    return report


# ─────────────────────────────────────────────────────────────────────────────
# Markdown Report Renderer
# ─────────────────────────────────────────────────────────────────────────────

def render_markdown_report(report_data: Dict, tier: str, company: str = "", period: str = "") -> str:
    """Render a structured Markdown report from analysis JSON."""
    lines = [
        f"# 📊 财务报表AI解读报告",
        f"",
        f"**企业**：{company or '未提供'}",
        f"**期间**：{period or '未提供'}",
        f"**版本**：{tier}",
        f"**生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"",
        f"---",
        f"",
    ]

    r = report_data

    # Revenue
    rev = r.get("revenue", {})
    lines += [
        f"## 1. 收入结构分析",
        f"",
        f"| 项目 | 数值 |",
        f"|------|------|",
        f"| 总收入 | {rev.get('total', 'N/A')} |",
        f"| 同比变化 | {rev.get('yoy_change', 'N/A')} |",
        f"| 环比变化 | {rev.get('qoq_change', 'N/A')} |",
        f"",
        f"**结构分析**：{rev.get('breakdown', 'N/A')}",
        f"",
        f"**评价**：{rev.get('summary', '')}",
        f"",
    ]

    # Cost
    cost = r.get("cost", {})
    lines += [
        f"## 2. 成本异常检测",
        f"",
        f"| 项目 | 数值 |",
        f"|------|------|",
        f"| 总成本 | {cost.get('total', 'N/A')} |",
        f"| 占收入比 | {cost.get('占比', 'N/A')} |",
        f"",
        f"**成本结构**：{cost.get('cost_breakdown', 'N/A')}",
    ]
    anomalies_cost = cost.get("anomalies", [])
    if anomalies_cost:
        lines += ["", "**🚨 成本异常**："]
        for a in anomalies_cost:
            lines.append(f"- {a}")
    lines += ["", f"**评价**：{cost.get('summary', '')}", ""]

    # Profit
    prof = r.get("profit", {})
    lines += [
        f"## 3. 利润分析",
        f"",
        f"| 指标 | 数值 |",
        f"|------|------|",
        f"| 毛利率 | {prof.get('gross_margin', 'N/A')} |",
        f"| 净利率 | {prof.get('net_margin', 'N/A')} |",
        f"| 利润同比 | {prof.get('yoy_change', 'N/A')} |",
        f"",
        f"**评价**：{prof.get('summary', '')}",
        f"",
    ]

    # Cashflow
    cf = r.get("cashflow", {})
    lines += [
        f"## 4. 现金流分析",
        f"",
        f"| 项目 | 数值 |",
        f"|------|------|",
        f"| 经营现金流净额 | {cf.get('operating', 'N/A')} |",
        f"| 投资现金流 | {cf.get('investing', 'N/A')} |",
        f"| 筹资现金流 | {cf.get('financing', 'N/A')} |",
        f"",
        f"**评价**：{cf.get('summary', '')}",
        f"",
    ]

    # Balance Sheet
    bs = r.get("balance_sheet", {})
    lines += [
        f"## 5. 资产负债分析",
        f"",
        f"| 项目 | 数值 |",
        f"|------|------|",
        f"| 总资产 | {bs.get('total_assets', 'N/A')} |",
        f"| 总负债 | {bs.get('total_liabilities', 'N/A')} |",
        f"| 净资产 | {bs.get('equity', 'N/A')} |",
        f"| 资产负债率 | {bs.get('debt_ratio', 'N/A')} |",
        f"| 流动比率 | {bs.get('current_ratio', 'N/A')} |",
        f"",
        f"**评价**：{bs.get('summary', '')}",
        f"",
    ]

    # KPI
    kpi = r.get("kpi", {})
    lines += [
        f"## 6. KPI达成分析",
    ]
    achieved = kpi.get("achieved", [])
    if achieved:
        lines += ["", "| KPI指标 | 达成情况 |", "|------|------|"]
        for item in achieved:
            lines.append(f"| {item.get('name', 'N/A')} | {item.get('status', 'N/A')} |")
    else:
        lines += ["", f"未检测到KPI/预算数据（{kpi.get('missing', 'N/A')}）"]
    lines += [""]

    # Anomalies
    all_anomalies = r.get("anomalies", [])
    if all_anomalies:
        lines += [f"## 7. 异常预警", ""]
        lines += ["", "| 维度 | 严重程度 | 描述 | 数值 | 建议 |", "|------|------|------|------|------|"]
        for a in all_anomalies:
            lines.append(f"| {a.get('dimension','')} | {a.get('severity','')} | {a.get('description','')} | {a.get('value','')} | {a.get('suggestion','')} |")
        lines += [""]

    # Summary
    lines += [
        f"## 📋 整体经营评价",
        f"",
        f"{r.get('summary', 'N/A')}",
        f"",
        f"---",
        f"",
        f"> ⚠️ 本报告由AI自动生成，数据仅供参考，请以原始财务报表为准。",
    ]

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: report_generator.py <input_json_file>"}))
        sys.exit(1)

    input_file = sys.argv[1]
    if not os.path.exists(input_file):
        print(json.dumps({"error": f"Input file not found: {input_file}"}))
        sys.exit(1)

    with open(input_file, "r", encoding="utf-8") as f:
        params = json.load(f)

    file_path = params.get("file_path", "")
    api_key = params.get("api_key", "")
    model = params.get("model", "gpt-4o")
    tier = params.get("tier", "FREE")
    company = params.get("company_name", "")
    period = params.get("period", "")
    parsed_data = params.get("parsed_data", {})

    # Get sheet data
    if "sheets" in parsed_data:
        sheets = parsed_data["sheets"]
        sheet_name = list(sheets.keys())[0] if sheets else "主数据"
        sheet_data = sheets[sheet_name]
    else:
        sheet_name = parsed_data.get("format", "数据")
        sheet_data = {
            "headers": parsed_data.get("headers", []),
            "rows": parsed_data.get("rows", []),
        }

    headers = sheet_data.get("headers", [])
    rows = sheet_data.get("rows", [])

    file_ext = Path(file_path).suffix.lower()
    file_info = f"文件路径: {file_path} ({file_ext})"

    # Build prompt
    prompt = build_prompt(file_info, headers, rows, sheet_name)

    # Try AI analysis
    ai_result = None
    error_msg = None

    if api_key and api_key.strip():
        try:
            ai_result = call_ai_analysis(prompt, api_key, model)
        except Exception as e:
            error_msg = str(e)
            ai_result = None

    # Fallback if no AI or AI failed
    if ai_result is None:
        ai_result = build_fallback_report(headers, rows)
        if error_msg:
            ai_result["_warning"] = f"AI分析不可用: {error_msg}，已生成基础报告"

    # Render Markdown
    markdown_report = render_markdown_report(ai_result, tier, company, period)

    result = {
        "success": True,
        "tier": tier,
        "analysis": ai_result,
        "markdown": markdown_report,
        "file_info": {
            "path": file_path,
            "ext": file_ext,
            "sheet": sheet_name,
            "rows_count": len(rows),
            "cols_count": len(headers),
        }
    }

    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
