/**
 * Skill Invoke Handler - Main entry point for financial report analysis
 * Handles: skill.invoke events from OpenClaw
 */
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { validateToken, getPlanLimits } = require('../services/token_validator');

const SKILL_ROOT = path.resolve(__dirname, '..', '..');

// Plan tier → analysis dimensions available
const TIER_DIMENSIONS = {
  FREE: 3,
  STANDARD: 10,
  PRO: 99,
  MAX: 99,
};

function sanitizeJsonSafe(obj) {
  // Remove any non-serializable or potentially dangerous fields
  if (obj && typeof obj === 'object') {
    const clean = {};
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean' || v === null) {
        clean[k] = v;
      } else if (Array.isArray(v)) {
        clean[k] = v.map(sanitizeJsonSafe);
      } else if (typeof v === 'object') {
        clean[k] = sanitizeJsonSafe(v);
      }
    }
    return clean;
  }
  return obj;
}

function runPython(scriptPath, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('python3', [scriptPath, ...args], {
      cwd: SKILL_ROOT,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
      timeout: 120000,
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', d => { stdout += d.toString(); });
    proc.stderr.on('data', d => { stderr += d.toString(); });

    proc.on('close', code => {
      if (code !== 0) {
        reject(new Error(`Python exited ${code}: ${stderr || stdout}`));
      } else {
        resolve(stdout);
      }
    });
    proc.on('error', err => reject(err));
  });
}

async function parseFile(filePath) {
  const scriptPath = path.join(SKILL_ROOT, 'src', 'services', 'file_parser.py');
  const output = await runPython(scriptPath, [filePath]);
  return JSON.parse(output.trim());
}

async function generateReport(inputJsonPath, options) {
  const scriptPath = path.join(SKILL_ROOT, 'src', 'services', 'report_generator.py');
  const output = await runPython(scriptPath, [inputJsonPath]);
  return JSON.parse(output.trim());
}

/**
 * Main skill invoke handler
 * @param {Object} args - { apiKey, fileContent (base64), fileName, fileExt, model, tier, companyName, period }
 * @returns {Object} - { markdown, analysis, fileInfo }
 */
async function handleSkillInvoke(args) {
  const {
    apiKey = '',
    fileContent = '',   // base64 encoded file content
    fileName = 'report.xlsx',
    fileExt = '',
    model = '',
    companyName = '',
    period = '',
    userId = '',
  } = args;

  // 1. Token validation
  const validation = await validateToken(apiKey);
  const tier = validation.valid ? (validation.plan || 'FREE') : 'FREE';
  const limits = getPlanLimits(tier);

  // 2. Save uploaded file to temp
  const tmpDir = path.join(SKILL_ROOT, '.tmp');
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const decoded = Buffer.from(fileContent, 'base64');
  const savePath = path.join(tmpDir, `frp_${Date.now()}_${fileName}`);
  fs.writeFileSync(savePath, decoded);

  const detectedExt = fileExt || path.extname(fileName) || '.xlsx';

  // 3. Parse file
  let parsedData;
  try {
    parsedData = await parseFile(savePath);
  } catch (err) {
    // Clean up
    try { fs.unlinkSync(savePath); } catch (_) {}
    throw new Error(`文件解析失败: ${err.message}`);
  }

  // 4. Build input for report generator
  const inputJson = {
    file_path: savePath,
    api_key: apiKey,
    model: model || 'gpt-4o',
    tier,
    company_name: companyName || '',
    period: period || '',
    parsed_data: sanitizeJsonSafe(parsedData),
  };

  const inputJsonPath = path.join(tmpDir, `input_${Date.now()}.json`);
  fs.writeFileSync(inputJsonPath, JSON.stringify(inputJson, null, 2), 'utf8');

  // 5. Generate report
  let reportResult;
  try {
    reportResult = await generateReport(inputJsonPath, { tier });
  } catch (err) {
    try { fs.unlinkSync(inputJsonPath); } catch (_) {}
    try { fs.unlinkSync(savePath); } catch (_) {}
    throw new Error(`报告生成失败: ${err.message}`);
  } finally {
    // Clean up temp files
    try { fs.unlinkSync(inputJsonPath); } catch (_) {}
    try { fs.unlinkSync(savePath); } catch (_) {}
  }

  return {
    markdown: reportResult.markdown,
    analysis: sanitizeJsonSafe(reportResult.analysis || {}),
    file_info: reportResult.file_info || {},
    tier,
    limits,
    validation_result: {
      valid: validation.valid,
      plan: validation.plan,
      reason: validation.reason,
    },
  };
}

module.exports = { handleSkillInvoke };
