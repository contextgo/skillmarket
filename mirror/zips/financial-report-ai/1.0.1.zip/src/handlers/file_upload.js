/**
 * File Upload Handler
 * Handles file upload events from OpenClaw
 * Accepts: CSV, XLSX, XLS, PDF
 */
const path = require('path');
const fs = require('fs');
const { handleSkillInvoke } = require('./skill_invoke');

const ALLOWED_EXTENSIONS = ['.csv', '.xlsx', '.xls', '.pdf'];
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

function validateFile(ext, size) {
  const errors = [];
  if (!ALLOWED_EXTENSIONS.includes(ext.toLowerCase())) {
    errors.push(`不支持的文件格式: ${ext}。支持的格式: CSV, Excel (.xlsx/.xls), PDF`);
  }
  if (size > MAX_FILE_SIZE) {
    errors.push(`文件过大: ${(size / 1024 / 1024).toFixed(1)}MB，最大支持 50MB`);
  }
  return errors;
}

/**
 * Handle file upload
 * @param {Object} event - { fileName, fileSize, fileContent (base64), mimeType, apiKey, model }
 * @returns {Object} - analysis result
 */
async function handleFileUpload(event) {
  const {
    fileName = 'report.xlsx',
    fileSize = 0,
    fileContent = '',
    mimeType = '',
    apiKey = '',
    model = '',
    companyName = '',
    period = '',
    userId = '',
  } = event;

  const ext = path.extname(fileName).toLowerCase();

  // Validate
  const errors = validateFile(ext, fileSize);
  if (errors.length > 0) {
    return {
      success: false,
      errors,
      message: errors.join('；'),
    };
  }

  // Route to skill invoke
  const result = await handleSkillInvoke({
    apiKey,
    fileContent,
    fileName,
    fileExt: ext,
    model,
    companyName,
    period,
    userId,
  });

  return {
    success: true,
    ...result,
  };
}

module.exports = { handleFileUpload };
