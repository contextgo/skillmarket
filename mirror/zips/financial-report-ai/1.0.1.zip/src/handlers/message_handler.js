/**
 * Message Handler
 * Handles interactive chat messages for financial report analysis
 * Supports: text queries about uploaded reports, file upload instructions
 */
const path = require('path');
const { handleSkillInvoke } = require('./skill_invoke');

/**
 * Handle incoming message
 * @param {Object} message - { text, userId, sessionId, apiKey, model }
 * @returns {Object} - response
 */
async function handleMessage(message) {
  const { text = '', userId = '', sessionId = '', apiKey = '', model = '' } = message;

  // Return skill instructions / help
  if (!text || text.match(/^(帮助|help|使用说明|怎么用|使用指南)/i)) {
    return getHelpMessage();
  }

  // Check if asking about usage/quota
  if (text.match(/^(套餐|价格|版本|plan|tier|次数|限额)/i)) {
    return getPlanInfoMessage();
  }

  // Check if asking about status
  if (text.match(/^(状态|status|余额|余额查询)/i)) {
    return {
      success: true,
      message: '请提供您的 API Key，我将查询您的套餐状态。\n\n或者直接上传财务报表文件开始分析。',
    };
  }

  // Default: instructions
  return getHelpMessage();
}

function getHelpMessage() {
  return {
    success: true,
    message: `📊 **财务报表AI解读**

上传您的 Excel/CSV/PDF 财务报表，AI 自动生成经营分析报告。

**支持的分析维度**：
1. 收入结构分析
2. 成本异常检测
3. 利润分析
4. 现金流分析
5. 资产负债分析
6. KPI达成分析
7. 异常预警

**操作步骤**：
1️⃣ 上传财务文件（Excel/CSV/PDF）
2️⃣ 等待 AI 自动解析
3️⃣ 收取完整分析报告

**套餐说明**：
• Free：3次/月，基础3项分析
• Standard（¥29/月）：50次/月，10项分析
• Pro（¥99/月）：300次/月，全部分析+图表
• Max（¥299/月）：无限次

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)`,
    };
}

function getPlanInfoMessage() {
  return {
    success: true,
    message: `💰 **套餐版本对比**

| 功能 | Free | Standard ¥29 | Pro ¥99 | Max ¥299 |
|------|------|------|------|------|
| 解读次数 | 3次/月 | 50次/月 | 300次/月 | 无限 |
| 输入格式 | CSV/Excel | CSV/Excel/PDF | 全部 | 全部 |
| 分析维度 | 基础3项 | 10项 | 全部 | 全部 |
| 图表 | ❌ | 5种 | 15种 | 全部 |
| 行业对比 | ❌ | ✅ | ✅ | ✅ |

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)`,
  };
}

module.exports = { handleMessage };
