# Financial Report AI Pro

**Slug:** `financial-report-ai-pro`
**Name:** Financial Report AI Pro
**Category:** Finance / Data & Analytics
**Tags:** `financial-report`, `AI`, `Excel`, `CSV`, `PDF`, `analysis`, `income-statement`, `balance-sheet`, `cash-flow`

---

## Description

Upload Excel/CSV/PDF financial statements — AI automatically generates comprehensive business analysis reports covering revenue structure, cost anomalies, profit analysis, cash flow, balance sheet, KPI metrics, and anomaly alerts.

---

## Features

- **Multi-format Support** — Excel (.xlsx/.xls), CSV, PDF financial statements
- **7 Analysis Dimensions**:
  1. Revenue structure analysis
  2. Cost anomaly detection
  3. Profit analysis
  4. Cash flow analysis
  5. Balance sheet analysis
  6. KPI achievement analysis
  7. Anomaly early warning (🔴 High / 🟠 Medium / 🟡 Low)
- **Auto Chart Generation** — Line, bar, pie, scatter, area, heatmap (tier-dependent)
- **Multi-sheet Excel Reports** — Professional formatting with title, data, and charts
- **AI Model Agnostic** — Works with OpenAI GPT-4o / Claude / DeepSeek / Doubao / MiniMax (user provides their own API key)
- **Token Verification** — 4-tier system (Free/Standard/Pro/Max) with 5-minute SHA256 cache

---

## Pricing

| Tier | Price | Analyses/Month | Dimensions | Charts | Formats |
|------|-------|:--------------:|:---------:|:------:|---------|
| **Free** | ¥0 | 3/mo | 3 basic | ❌ | CSV/Excel |
| **Standard** | ¥29/mo | 50/mo | 10 | 5 | CSV/Excel/PDF |
| **Pro** | ¥99/mo | 300/mo | All 7 | 15 | All |
| **Max** | ¥299/mo | Unlimited | All 7 | All | All |

---

## Architecture

```
User uploads file
    ↓
index.js (entry, routing)
    ↓
src/handlers/
  ├── skill_invoke.js    # Core analysis engine
  ├── file_upload.js     # File upload handler
  └── message_handler.js # Text conversation handler
    ↓
src/services/
  ├── token_validator.js  # Token verification + 5-min cache
  ├── file_parser.py       # Excel/CSV/PDF parsing
  └── report_generator.py  # AI analysis + Markdown rendering
```

---

## Token Verification

- **Endpoint**: `POST https://api.yk-global.com/v1/verify`
- **Header**: `Authorization: Bearer {api_key}`
- **Body**: `{}`
- **Response**: Check `valid` field
- **Fallback**: Network error → FREE tier, no blocking
- **Cache**: SHA256 hash, 5-minute TTL

---

## Quick Start

```bash
# Install dependencies
npm install

# Configure API key
export OPENAI_API_KEY="sk-your-key-here"

# Run
node index.js
```

---

## AI Model Configuration

User provides their own API key — skill does not bind to any specific provider.

**Supported Providers** (auto-detected by model name):
- OpenAI (`api.openai.com/v1`)
- DeepSeek (`api.deepseek.com/v1`)
- Anthropic (`api.anthropic.com/v1`)
- Alibaba DashScope (`dashscope.aliyuncs.com`)
- MiniMax (`api.minimax.chat/v1`)

---

## Analysis Dimensions by Tier

| Dimension | Free | Standard | Pro | Max |
|-----------|:----:|:--------:|:---:|:---:|
| Revenue structure | ✅ | ✅ | ✅ | ✅ |
| Cost anomaly detection | ✅ | ✅ | ✅ | ✅ |
| Profit analysis | ✅ | ✅ | ✅ | ✅ |
| Cash flow | ❌ | ✅ | ✅ | ✅ |
| Balance sheet | ❌ | ✅ | ✅ | ✅ |
| KPI achievement | ❌ | ✅ | ✅ | ✅ |
| Anomaly early warning | ❌ | ✅ | ✅ | ✅ |

---

## File Structure

```
financial-report-ai/
├── SKILL.md              # Skill definition
├── README.md             # Documentation
├── SKILLHUB.md          # Tencent Skillhub listing (this file)
├── package.json          # Node.js dependencies
├── index.js              # Entry point
├── requirements.txt      # Python dependencies (for scripts)
├── public/               # Static assets
└── src/
    ├── handlers/
    │   ├── skill_invoke.js
    │   ├── file_upload.js
    │   └── message_handler.js
    └── services/
        ├── token_validator.js  # Token verification
        ├── file_parser.py       # File parsing
        └── report_generator.py  # AI report generation
```

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENCLAW_SKILL_DIR` | Skill root directory (for token cache) | `__dirname/..` |
| `VALIDATE_ENDPOINT` | Token verification URL | `https://api.yk-global.com/v1/verify` |

---

## Output Format

**Markdown report** includes:
- Revenue structure analysis table
- Cost anomaly detection results
- Profit analysis metrics
- Cash flow analysis
- Balance sheet structure
- KPI achievement status
- 🔴🟠🟡 Three-tier anomaly warnings
- Overall business evaluation

---

## Security Notes

- Token verification uses SHA256 hash cache — no raw key storage
- All files processed and immediately cleaned, no persistence
- AI analysis executes locally — no data transmission to third parties

---

## License

Proprietary — YK Global

> For paid plans, visit [YK-Global.com](https://yk-global.com)
