#!/usr/bin/env node
/**
 * Skill: 财务报表AI解读 (financial-report-ai-pro)
 * Entry point - OpenClaw-compatible skill
 *
 * Tier System:
 *   FREE     - 3 analyses/month, basic 3 dimensions
 *   STANDARD - ¥29/month, 50 analyses/month, 10 dimensions
 *   PRO      - ¥99/month, 300 analyses/month, all dimensions
 *   MAX      - ¥299/month, unlimited
 *
 * Core Features:
 *   1. Revenue structure analysis
 *   2. Cost anomaly detection
 *   3. Profitability analysis
 *   4. Cash flow analysis
 *   5. Balance sheet analysis
 *   6. KPI achievement
 *   7. Anomaly alerts
 */
const path = require('path');
const fs = require('fs');

// Resolve skill root
const SKILL_ROOT = __dirname;

// Load .env if present
const envPath = path.join(SKILL_ROOT, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8')
    .split('\n')
    .forEach(line => {
      const idx = line.indexOf('=');
      if (idx < 0 || line.startsWith('#')) return;
      const k = line.slice(0, idx).trim();
      const v = line.slice(idx + 1).trim();
      if (k && !process.env[k]) process.env[k] = v;
    });
}

// Lazy-load handlers to avoid circular deps
function getHandler(name) {
  try {
    return require(`./src/handlers/${name}`);
  } catch (_) {
    return null;
  }
}

const skillInvoke = getHandler('skill_invoke');
const fileUpload = getHandler('file_upload');
const messageHandler = getHandler('message');

const skill = {
  id: 'financial-report-ai-pro',
  name: '财务报表AI解读',
  description: '上传 Excel/CSV/PDF 财务报表，AI 自动解读并生成经营分析报告（收入结构/成本异常/现金流/资产负债/KPI达成/异常预警）',
  version: '1.0.0',
  author: 'YK Global',

  // Main skill invoke handler
  async invoke(params, context) {
    if (!skillInvoke) {
      return { success: false, error: 'skill_invoke handler not found' };
    }
    return skillInvoke.handleSkillInvoke(params, context);
  },

  // Config schema
  configSchema: {
    type: 'object',
    properties: {
      apiKey: {
        type: 'string',
        title: 'AI API Key',
        description: '用户自行配置的 AI 模型 API Key（不绑定、不推荐、不限定模型）',
      },
      defaultModel: {
        type: 'string',
        title: '默认模型',
        default: 'gpt-4o',
        description: '默认使用的 AI 模型',
      },
      chartTheme: {
        type: 'string',
        title: '图表主题',
        default: 'light',
        enum: ['light', 'dark'],
      },
    },
    required: [],
  },

  // Skill meta
  skillRoot: SKILL_ROOT,

  // Expose sub-handlers for OpenClaw routing
  handlers: {
    async 'skill.invoke'(params, context) {
      return this.invoke(params, context);
    },
    async 'file.upload'(params, context) {
      if (!fileUpload) return { success: false, error: 'file_upload handler not found' };
      return fileUpload.handleFileUpload(params, context);
    },
    async 'message.create'(params, context) {
      if (!messageHandler) return { success: false, error: 'message_handler not found' };
      return messageHandler.handleMessage(params, context);
    },
  },
};

module.exports = skill;
module.exports.default = skill;
