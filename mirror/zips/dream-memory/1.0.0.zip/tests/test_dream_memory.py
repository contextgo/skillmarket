#!/usr/bin/env python3
"""
梦境记忆系统测试套件
"""
import unittest
import sys
import os
import tempfile
from pathlib import Path
from datetime import datetime
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from dream_engine import DreamEngine
from memory_consolidator import MemoryConsolidator, MemoryCandidate


class TestDreamEngine(unittest.TestCase):
    """测试梦境记忆核心"""
    
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.dream = DreamEngine(data_dir=self.temp_dir)
    
    def test_light_sleep(self):
        """测试浅睡阶段"""
        content = """
# 今日工作
- 用户偏好使用 Python 进行开发
- 习惯在晚上进行代码审查
- 发现了一个新的调试模式
"""
        added = self.dream.light_sleep(content)
        
        # 应该提取到包含关键词的行
        self.assertGreaterEqual(added, 0)
    
    def test_deep_sleep(self):
        """测试深睡阶段"""
        # 先添加一些候选
        self.dream.consolidator.add_candidate("测试偏好1", "test")
        self.dream.consolidator.add_candidate("测试偏好2", "test")
        
        result = self.dream.deep_sleep()
        
        # 应该返回深睡结果
        self.assertIsInstance(result, dict)
    
    def test_rem_sleep(self):
        """测试REM阶段"""
        # 先执行深睡
        self.dream.consolidator.add_candidate("重要偏好", "test")
        self.dream.deep_sleep()
        
        result = self.dream.rem_sleep()
        
        # 应该返回REM结果（可能是list或dict）
        self.assertTrue(isinstance(result, (dict, list)))


class TestMemoryConsolidator(unittest.TestCase):
    """测试记忆巩固器"""
    
    def setUp(self):
        self.consolidator = MemoryConsolidator()
    
    def test_add_candidate(self):
        """测试添加候选记忆"""
        candidate = self.consolidator.add_candidate(
            content="测试内容",
            source="test"
        )
        
        self.assertEqual(candidate.content, "测试内容")
        self.assertEqual(candidate.source, "test")
        self.assertEqual(len(self.consolidator.candidates), 1)


class TestMemoryCandidate(unittest.TestCase):
    """测试记忆候选类"""
    
    def test_candidate_creation(self):
        """测试候选创建"""
        now = datetime.now().isoformat()
        candidate = MemoryCandidate(
            id="test-1",
            content="测试",
            source="test",
            created_at=now
        )
        
        self.assertEqual(candidate.content, "测试")
        self.assertEqual(candidate.source, "test")
    
    def test_candidate_to_dict(self):
        """测试候选序列化"""
        now = datetime.now().isoformat()
        candidate = MemoryCandidate(
            id="test-1",
            content="测试",
            source="test",
            created_at=now
        )
        
        data = candidate.to_dict()
        
        self.assertEqual(data["content"], "测试")
        self.assertEqual(data["source"], "test")


if __name__ == "__main__":
    unittest.main()
