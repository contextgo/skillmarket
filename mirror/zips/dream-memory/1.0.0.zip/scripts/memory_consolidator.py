"""
记忆固化器
实现三阶段记忆巩固过程
"""

import json
import re
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict


@dataclass
class MemoryCandidate:
    """记忆候选"""
    id: str
    content: str
    source: str
    created_at: str
    recall_count: int = 0
    query_contexts: List[str] = None
    
    def __post_init__(self):
        if self.query_contexts is None:
            self.query_contexts = []
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MemoryCandidate':
        return cls(**data)


@dataclass
class ScoreResult:
    """评分结果"""
    candidate_id: str
    relevance: float
    frequency: float
    diversity: float
    recency: float
    integration: float
    concept_density: float
    total_score: float
    passed: bool


class MemoryConsolidator:
    """记忆固化器"""
    
    # 三道门槛
    MIN_SCORE = 60
    MIN_RECALL = 2
    MIN_QUERIES = 1
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.candidates_file = self.data_dir / "candidates.json"
        self.scores_file = self.data_dir / "scores.json"
        self.recall_store_file = self.data_dir / "recall-store.json"
        
        self.candidates: Dict[str, MemoryCandidate] = {}
        self.recall_log: List[Dict] = []
        self._load_data()
    
    def _load_data(self):
        """加载数据"""
        if self.candidates_file.exists():
            try:
                with open(self.candidates_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for c_data in data.get("candidates", []):
                        c = MemoryCandidate.from_dict(c_data)
                        self.candidates[c.id] = c
            except:
                pass
        
        if self.recall_store_file.exists():
            try:
                with open(self.recall_store_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.recall_log = data.get("recalls", [])
            except:
                pass
    
    def _save_data(self):
        """保存数据"""
        with open(self.candidates_file, 'w', encoding='utf-8') as f:
            json.dump({
                "candidates": [c.to_dict() for c in self.candidates.values()],
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
    
    def add_candidate(self, content: str, source: str) -> MemoryCandidate:
        """添加记忆候选"""
        candidate_id = f"c_{len(self.candidates)+1:04d}"
        
        candidate = MemoryCandidate(
            id=candidate_id,
            content=content,
            source=source,
            created_at=datetime.now().isoformat()
        )
        
        self.candidates[candidate_id] = candidate
        self._save_data()
        
        return candidate
    
    def record_recall(self, candidate_id: str, context: str, quality: int = 5):
        """记录召回"""
        if candidate_id in self.candidates:
            self.candidates[candidate_id].recall_count += 1
            self.candidates[candidate_id].query_contexts.append(context)
        
        self.recall_log.append({
            "candidate_id": candidate_id,
            "context": context,
            "quality": quality,
            "timestamp": datetime.now().isoformat()
        })
        
        self._save_data()
    
    def _calculate_six_dimensions(self, candidate: MemoryCandidate) -> Tuple[float, ...]:
        """六维评分"""
        # 1. 相关性 (30%)
        relevance = min(10, candidate.recall_count * 2) / 10 * 100
        
        # 2. 频率 (24%)
        days_old = (datetime.now() - datetime.fromisoformat(candidate.created_at)).days
        decay = max(0, 1 - days_old * 0.1)
        frequency = candidate.recall_count * decay * 20
        
        # 3. 查询多样性 (15%)
        unique_contexts = len(set(candidate.query_contexts))
        diversity = min(100, unique_contexts * 25)
        
        # 4. 时效性 (15%)
        recency = 100 / (1 + days_old * 0.1)
        
        # 5. 整合度 (10%)
        integration = min(100, len(candidate.query_contexts) * 10)
        
        # 6. 概念丰富度 (6%)
        concept_patterns = [
            r'偏好|倾向|风格|习惯',
            r'模式|规律|趋势',
            r'策略|方法|技巧',
            r'规则|约束|限制'
        ]
        concept_count = sum(1 for p in concept_patterns if re.search(p, candidate.content))
        concept_density = concept_count / len(concept_patterns) * 100
        
        return relevance, frequency, diversity, recency, integration, concept_density
    
    def score_candidates(self) -> List[ScoreResult]:
        """评分所有候选"""
        results = []
        
        for candidate in self.candidates.values():
            rel, freq, div, rec, integ, conc = self._calculate_six_dimensions(candidate)
            
            # 加权总分
            total = (
                rel * 0.30 +
                freq * 0.24 +
                div * 0.15 +
                rec * 0.15 +
                integ * 0.10 +
                conc * 0.06
            )
            
            # 三道门槛
            passed = (
                total >= self.MIN_SCORE and
                candidate.recall_count >= self.MIN_RECALL and
                len(set(candidate.query_contexts)) >= self.MIN_QUERIES
            )
            
            results.append(ScoreResult(
                candidate_id=candidate.id,
                relevance=round(rel, 2),
                frequency=round(freq, 2),
                diversity=round(div, 2),
                recency=round(rec, 2),
                integration=round(integ, 2),
                concept_density=round(conc, 2),
                total_score=round(total, 2),
                passed=passed
            ))
        
        # 保存评分
        with open(self.scores_file, 'w', encoding='utf-8') as f:
            json.dump({
                "scores": [asdict(r) for r in results],
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        return results
    
    def get_passed_candidates(self) -> List[MemoryCandidate]:
        """获取通过筛选的候选"""
        scores = self.score_candidates()
        passed_ids = [s.candidate_id for s in scores if s.passed]
        return [self.candidates[cid] for cid in passed_ids if cid in self.candidates]
    
    def clear_candidates(self, keep_ids: Optional[List[str]] = None):
        """清空候选（保留指定ID）"""
        if keep_ids:
            self.candidates = {k: v for k, v in self.candidates.items() if k in keep_ids}
        else:
            self.candidates.clear()
        self._save_data()


# 单例
_consolidator_instance: Optional[MemoryConsolidator] = None


def get_memory_consolidator() -> MemoryConsolidator:
    global _consolidator_instance
    if _consolidator_instance is None:
        _consolidator_instance = MemoryConsolidator()
    return _consolidator_instance
