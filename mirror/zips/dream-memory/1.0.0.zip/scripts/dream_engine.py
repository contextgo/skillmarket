"""
梦境引擎
整合三阶段记忆巩固
"""

import json
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime

from memory_consolidator import get_memory_consolidator, MemoryCandidate


class DreamEngine:
    """梦境引擎"""
    
    TRIGGER_THRESHOLD = 10  # 10条候选触发深睡
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy"
        self.data_dir = data_dir
        
        self.dreams_dir = self.data_dir / "dreams"
        self.dreams_dir.mkdir(exist_ok=True)
        
        self.memory_dir = self.data_dir / "memory"
        self.memory_dir.mkdir(exist_ok=True)
        
        self.stage_file = self.dreams_dir / "stage.json"
        self.checkpoint_file = self.dreams_dir / "checkpoint.json"
        self.dreams_md = self.memory_dir / "DREAMS.md"
        self.memory_md = self.memory_dir / "MEMORY.md"
        
        self.consolidator = get_memory_consolidator()
    
    def _set_stage(self, stage: str):
        """设置当前阶段"""
        with open(self.stage_file, 'w', encoding='utf-8') as f:
            json.dump({
                "stage": stage,
                "timestamp": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
    
    def light_sleep(self, daily_content: str) -> int:
        """
        浅睡阶段：扫描生成候选
        
        Returns:
            新增候选数
        """
        self._set_stage("light")
        
        # 解析内容，提取关键信息
        lines = daily_content.split('\n')
        added = 0
        
        for line in lines:
            line = line.strip()
            # 跳过空行和标题
            if not line or line.startswith('#') or line.startswith('-'):
                continue
            
            # 提取有价值的信息（简化实现）
            if len(line) > 20 and any(kw in line for kw in ['偏好', '习惯', '模式', '策略', '规则']):
                self.consolidator.add_candidate(line, "daily_note")
                added += 1
        
        return added
    
    def deep_sleep(self) -> Dict:
        """
        深睡阶段：评分筛选写入
        
        Returns:
            深睡结果
        """
        self._set_stage("deep")
        
        # 评分
        scores = self.consolidator.score_candidates()
        passed = [s for s in scores if s.passed]
        
        # 写入 MEMORY.md
        if passed:
            self._write_to_memory(passed)
        
        # 更新检查点
        with open(self.checkpoint_file, 'w', encoding='utf-8') as f:
            json.dump({
                "last_deep_sleep": datetime.now().isoformat(),
                "candidates_processed": len(scores),
                "passed_count": len(passed)
            }, f, ensure_ascii=False, indent=2)
        
        # 清空已处理的候选
        passed_ids = [s.candidate_id for s in passed]
        self.consolidator.clear_candidates(keep_ids=None)
        
        return {
            "candidates_scanned": len(scores),
            "passed": len(passed),
            "passed_ids": passed_ids
        }
    
    def _write_to_memory(self, passed_scores: List):
        """写入永久记忆"""
        lines = []
        
        for score in passed_scores:
            candidate = self.consolidator.candidates.get(score.candidate_id)
            if candidate:
                lines.append(f"- {candidate.content}")
        
        # 追加到 MEMORY.md
        if lines:
            with open(self.memory_md, 'a', encoding='utf-8') as f:
                f.write(f"\n## {datetime.now().strftime('%Y-%m-%d')}\n")
                for line in lines:
                    f.write(line + "\n")
    
    def rem_sleep(self) -> List[str]:
        """
        REM阶段：寻找关联模式
        
        Returns:
            洞察列表
        """
        self._set_stage("rem")
        
        insights = []
        
        # 读取 MEMORY.md 寻找模式
        if self.memory_md.exists():
            try:
                with open(self.memory_md, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                    # 简单模式检测
                    if '偏好' in content and '风格' in content:
                        insights.append("用户有明确的风格偏好模式")
                    
                    if '习惯' in content:
                        insights.append("检测到高频工作习惯")
                    
                    if '策略' in content:
                        insights.append("用户倾向于使用系统化策略")
                        
            except:
                pass
        
        # 写入 DREAMS.md
        if insights:
            self._write_dreams(insights)
        
        self._set_stage("idle")
        
        return insights
    
    def _write_dreams(self, insights: List[str]):
        """写入梦境日记"""
        date_str = datetime.now().strftime('%Y-%m-%d')
        
        content = f"\n## {date_str} 梦境摘要\n\n"
        content += "### 🔮 REM 洞察\n"
        for insight in insights:
            content += f"- {insight}\n"
        content += "\n"
        
        # 追加或创建
        if self.dreams_md.exists():
            with open(self.dreams_md, 'a', encoding='utf-8') as f:
                f.write(content)
        else:
            with open(self.dreams_md, 'w', encoding='utf-8') as f:
                f.write("# 🌙 梦境日记\n\n")
                f.write(content)
    
    def run_full_cycle(self, daily_content: str) -> Dict:
        """
        运行完整三阶段
        
        Returns:
            完整结果
        """
        # 浅睡
        added = self.light_sleep(daily_content)
        
        # 检查是否触发深睡
        if len(self.consolidator.candidates) >= self.TRIGGER_THRESHOLD:
            deep_result = self.deep_sleep()
            rem_insights = self.rem_sleep()
            
            return {
                "light_sleep_added": added,
                "deep_sleep": deep_result,
                "rem_insights": rem_insights,
                "status": "completed"
            }
        
        return {
            "light_sleep_added": added,
            "candidates_count": len(self.consolidator.candidates),
            "status": "waiting_for_more_candidates"
        }
    
    def should_trigger(self) -> bool:
        """检查是否应该触发梦境"""
        return len(self.consolidator.candidates) >= self.TRIGGER_THRESHOLD


# 单例
_dream_engine_instance: Optional[DreamEngine] = None


def get_dream_engine() -> DreamEngine:
    global _dream_engine_instance
    if _dream_engine_instance is None:
        _dream_engine_instance = DreamEngine()
    return _dream_engine_instance
