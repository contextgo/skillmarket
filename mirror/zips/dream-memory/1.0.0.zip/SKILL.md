---
name: dream-memory
slug: dream-memory
version: 1.0.0
description: "全局梦境记忆系统。模拟人类大脑巩固记忆的三阶段生理过程（浅睡/深睡/REM），通过六维评分引擎筛选高价值信息写入永久记忆，生成人类可读的梦境日记 DREAMS.md。"
---

# 🌙 Dream Memory — 梦境记忆系统

## 核心架构

```
对话日志 / 召回痕迹
        ↓
  ① 浅睡 Light Sleep   ← 扫描去重，生成候选清单（不写 MEMORY.md）
        ↓
  ② 深睡 Deep Sleep    ← 六维评分 + 三道门槛筛选 → 写入 MEMORY.md
        ↓
  ③ REM 快速眼动       ← 寻找隐秘关联 → 写入 REM 洞察块
        ↓
  DREAMS.md 梦境日记   ← 人类可读摘要
```

---

## 自动触发规则（无需用户说"做梦"，全程自动运行）

### 触发时机（全自动）

| 触发条件 | 自动执行阶段 |
|---------|------------|
| 每次工具调用返回结果后 | 自动追加到 recall-store.json |
| 当前会话累积 ≥10 条新日志 | 自动触发深睡阶段 |
| 深睡阶段完成后 | 自动触发 REM 阶段 |
| 对话开始时 | 自动检查上次 checkpoint，断点续做 |
| 用户说"整理记忆"/"做梦"/"梦境" | 强制执行完整三阶段（跳过门槛限制） |

### 自动执行逻辑（内置，无需外部调用）

每次回复用户后，自动执行（静默，不打断用户）：
```
1. 检查 dreams/stage.json 当前状态
2. 如果是 "idle" 或上次运行在24小时前：
   - 执行浅睡扫描（追加到 candidates.json）
   - 检查 candidates 数量
3. 如果 candidates >= 10：
   - 自动触发深睡评分 + 写入
   - 自动触发 REM 洞察
4. 更新 stage.json → "idle"
5. 整个过程不告知用户，除非发现高价值记忆需要用户确认
```

---

## 人类可读梦境日记（DREAMS.md）

---

## 阶段一：浅睡（Light Sleep）

**目标**：扫描 + 去重 + 生成候选清单

```
1. 读取今日 daily note：.workbuddy/memory/YYYY-MM-DD.md
2. 读取近7日 daily notes（按日期倒序）
3. 读取召回记录：.workbuddy/dreams/recall-store.json
4. 执行去重：
   - 与 MEMORY.md 现有条目做语义对比
   - 删除重复 / 冗余 / 纯过程性内容
5. 生成候选清单：.workbuddy/dreams/candidates.json
6. 写入阶段信号：.workbuddy/dreams/stage.json → {"stage": "light", "ts": <timestamp>}
```

**约束**：本阶段**不修改** MEMORY.md，仅暂存候选数据。

---

## 阶段二：深睡（Deep Sleep）

**目标**：六维评分 → 三道门槛筛选 → 写入永久记忆

### 六维评分引擎

对 candidates.json 中每条信息打分（总分100）：

| 维度 | 权重 | 计算方式 |
|------|------|---------|
| 相关性（Relevance） | 30% | 该条目被检索时的平均解决质量（1-10分） |
| 频率（Frequency） | 24% | 近期日志中出现次数 × 衰减系数 |
| 查询多样性（Query Diversity） | 15% | 涉及该条目的不同上下文数量 |
| 时效性（Recency） | 15% | `score = 1 / (1 + days_old * 0.1)` |
| 整合度（Integration） | 10% | 跨多日重复出现的天数 |
| 概念丰富度（Concept Density） | 6% | 条目路径中提取的概念标签数量 |

### 三道门槛（必须同时通过）

```python
PASS = (
    total_score >= 60 and          # 最低评分门槛
    recall_count >= 2 and          # 最低召回次数
    unique_queries >= 1            # 最低独特查询次数
)
```

### 写入流程

```
1. 对比最新 daily note（剔除过时内容）
2. 将通过筛选的条目 APPEND 到 MEMORY.md
3. 生成深睡摘要写入 DREAMS.md：
   ## 深睡摘要 YYYY-MM-DD
   - 扫描条目：N 条
   - 通过筛选：M 条
   - 写入内容：[简洁列表]
4. 更新检查点：.workbuddy/dreams/checkpoint.json
5. 释放锁文件：删除 .workbuddy/dreams/write.lock
```

---

## 阶段三：REM（快速眼动）

**目标**：寻找隐秘关联 → 构建底层逻辑模式

```
1. 读取最新写入的 MEMORY.md 条目
2. 读取近期行为痕迹（daily notes 中的操作模式）
3. 识别跨条目的隐性关联：
   - 用户偏好模式（风格/风险倾向/工具偏好）
   - 任务流程模式（哪些任务经常连续出现）
   - 修正模式（用户最常纠正哪类错误）
4. 生成 REM 洞察，写入 DREAMS.md：
   ### 🔮 REM 神经突触 YYYY-MM-DD
   **发现的模式：**
   - [模式1]：[证据链]
   **反思摘要：**
   - [下次处理 X 类任务时应注意...]
5. 将高价值模式写入 MEMORY.md 的 ## REM Insights 区块
```

---

## 机器状态目录（.workbuddy/dreams/）

| 文件 | 用途 |
|------|------|
| `recall-store.json` | 召回痕迹存储，记录每次检索的条目ID和上下文 |
| `candidates.json` | 浅睡阶段的候选清单（临时） |
| `stage.json` | 当前阶段信号 `{"stage":"light/deep/rem","ts":...}` |
| `checkpoint.json` | 写入检查点，确保断电续写 |
| `write.lock` | 写锁文件，防止并发写入 MEMORY.md |
| `scores.json` | 每条候选的六维评分明细（调试用） |

---

## 人类可读梦境日记（DREAMS.md）

位置：`.workbuddy/memory/DREAMS.md`

格式：
```markdown
# 🌙 梦境日记

---

## 2026-04-08 深睡摘要
今天整理了 12 条信息，有 5 条通过了记忆门槛...
[简洁人话描述]

### 🔮 REM 洞察
发现用户在处理 PPT 任务时有固定的颜色偏好模式...
```

---

## 执行方式

完全自动运行。内部维护计数器，每次回复后自动评估是否触发。无需用户任何指令。

如需查看梦境日记，直接读取 `.workbuddy/memory/DREAMS.md` 即可。
