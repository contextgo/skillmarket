# 用户信息查询 API 文档

> **内部参考文档** - 仅供 Skill 开发和维护使用
>
> 此文档详细描述了 API 接口规范，包含企业特定的域名、认证机制等信息。
> 安装用户无需阅读此文档。

---

## 一、接口概览

### 1.1 用户查询接口

| 查询方式 | 接口地址 | 请求方法 |
|----------|----------|----------|
| userId | `http://{api_domain}/user/services/rest/user/{userId}` | GET |
| username / mobile | `http://{api_domain}/user/services/rest/user/Name/{name}` | GET |

### 1.2 登录接口（V2）

| 环境 | 地址 |
|------|------|
| dev | `http://{login_domain}/center/services/rest/user/V2/Login` |
| test | `http://{login_domain}/center/services/rest/user/V2/Login` |
| prod | `http://{login_domain}/center/services/rest/user/V2/Login` |

### 1.3 Logout 接口

| 项目 | 说明 |
|------|------|
| 地址 | `http://{server_domain}/user/services/rest/user/Logout` |
| 域名来源 | 登录响应中的 `server.domain` 字段 |

---

## 二、认证机制

### 2.1 登录认证

#### 请求头

```
Content-Type: application/json
DeviceUniqueId: zTang-dev-info  <!-- 固定值 -->
```

#### 请求体

```json
{
  "LoginUserArgu": {
    "key": "L[Base64(username:password)]S"
  }
}
```

> **UserKey 格式**：`L` + Base64(`username:password`) + `S`
>
> 示例：用户名 `admin`，密码 `pwd123`
> - Base64(`admin:pwd123`) = `YWRtaW46cHdkMTIz`
> - UserKey = `LYWRtaW46cHdkMTIzS`

#### 成功响应

```json
{
  "code": "0",
  "message": "Success",
  "token": "<登录令牌>",
  "server": {
    "domain": "<服务器域名，用于Logout接口>"
  }
}
```

### 2.2 Token 失效检测

**判断条件**（满足任一即判定为 Token 过期）：

- HTTP 状态码 401 / 403
- `code == "-1001"`
- `message` 包含 "登录失效"、"token expired"、"token invalid"

**Token 失效响应示例**：

```json
{
  "code": "-1001",
  "message": "登录失效，请重新登录",
  "resId": "714"
}
```

### 2.3 Logout 接口

#### 请求头

```
DeviceType: 0
AppType: 6
DeviceUniqueId: zTang-dev-info  <!-- 固定值 -->
token: <当前token>
```

#### 响应

```json
{
  "code": "0",
  "message": "Success"
}
```

---

## 三、响应结构

### 3.1 外层字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | string | 响应码，`"0"` 表示成功 |
| `message` | string | 响应描述 |
| `user` | object | 用户详情对象 |
| `startPos` | string | 分页起始位置 |
| `count` | string | 当前返回数量 |
| `total` | string | 总记录数 |

### 3.2 user 对象字段（常用）

| 字段 | 类型 | 说明 |
|------|------|------|
| `userId` | string | 用户 ID |
| `username` | string | 登录用户名 |
| `nickname` | string | 用户昵称 |
| `mobile` | string | 手机号 |
| `instId` | string | 机构 ID |
| `role` | string | 角色 |
| `gender` | string | 性别：`"0"` = 男，`"1"` = 女 |
| `activeDate` | string | 激活时间 |
| `expiredStatus` | string | 过期状态：`"0"` = 未过期 |
| `campusTitle` | string | 校区名称 |

---

## 四、成功响应示例

```json
{
    "code": "0",
    "message": "Success",
    "user": {
        "userId": "19857",
        "username": "stu_013",
        "nickname": "13",
        "mobile": "",
        "instId": "170573",
        "role": "groupMember",
        "gender": "0",
        "activeDate": "2020-04-01 21:57:59",
        "expiredStatus": "0",
        "campusTitle": "唐"
    },
    "startPos": "10",
    "count": "8",
    "total": "18"
}
```

---

## 五、错误处理

当 `code` 不为 `"0"` 时，表示请求失败，需检查 `message` 字段获取错误原因。

| 错误码 | 说明 | 处理方式 |
|--------|------|----------|
| `-1001` | 登录失效 | 自动刷新 Token 并重试 |
| 其他 | 请求失败 | 检查请求参数和网络连接 |

---

## 六、配置存储

### 6.1 密钥链存储内容

| 字段 | 说明 |
|------|------|
| `username` | 登录用户名 |
| `password` | 登录密码（操作系统级加密） |
| `env` | 登录环境 |
| `token` | 当前登录凭证 |
| `server_domain` | Logout 接口域名（来自登录响应） |
| `api_domain` | 查询 API 域名（用户配置时提供） |

> **注意**：设备标识符使用固定值 `zTang-dev-info`，不存储在密钥链中。

### 6.2 两种域名的区别

| 域名类型 | 用途 | 来源 |
|----------|------|------|
| `server_domain` | Logout 接口 | 登录响应的 `server.domain` |
| `api_domain` | 用户查询 API | 用户配置时提供 |

> ⚠️ **重要**：这两种域名可能不同，必须区分存储和使用。
