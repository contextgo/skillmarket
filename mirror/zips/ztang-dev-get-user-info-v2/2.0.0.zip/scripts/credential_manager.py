#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
credential_manager.py
凭证管理器 - 基于系统密钥链的自动登录刷新方案

核心概念：
- UserKey 格式：L + Base64(username:password) + S，每次登录实时计算不存储
- server_domain：来自登录响应的 server.domain，**用于 Logout 接口**
- api_domain：用户查询时提供的域名，**用于用户信息查询 API**

⚠️ 重要：Logout 域名与用户查询 API 域名可能不同！
- Logout 接口：http://{server_domain}/user/services/rest/user/Logout
- 用户查询 API：http://{api_domain}/user/services/rest/user/{userId}
              http://{api_domain}/user/services/rest/user/Name/{name}

依赖：
    pip install requests keyring
"""

import sys
import json
import base64
import keyring
import requests
from pathlib import Path

# ── Windows 控制台编码修复（仅在被直接运行时执行）─────────────────
# 注意：作为模块导入时不执行，避免双重包装
if __name__ == "__main__" and sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# ── 常量定义 ──────────────────────────────────────────────────────
SERVICE_NAME = "get-user-info-skill"

# 固定设备标识符
DEFAULT_DEVICE_ID = "zTang-dev-info"

# 密钥链存储的字段名
KEY_USERNAME = "username"
KEY_PASSWORD = "password"
KEY_DEVICE_ID = "device_unique_id"
KEY_ENV = "env"
KEY_TOKEN = "token"
# ⚠️ server_domain：来自登录响应的 server.domain，用于 Logout 接口
KEY_SERVER_DOMAIN = "server_domain"
# ⚠️ api_domain：用户查询时提供的域名，用于用户信息查询 API
KEY_API_DOMAIN = "api_domain"

# 登录环境配置
ENV_CONFIG = {
    "dev": "http://stage2.51tyty.com/center/services/rest/user/V2/Login",
    "test": "http://pre.51tyty.com/center/services/rest/user/V2/Login",
    "prod": "http://center.51tyty.com/center/services/rest/user/V2/Login",
}


# ═════════════════════════════════════════════════════════════════
# 密钥链操作
# ═════════════════════════════════════════════════════════════════

def _get(key: str) -> str | None:
    """从密钥链获取值。"""
    return keyring.get_password(SERVICE_NAME, key)


def _set(key: str, value: str) -> None:
    """存入密钥链。"""
    keyring.set_password(SERVICE_NAME, key, value)


def _delete(key: str) -> None:
    """从密钥链删除值。"""
    try:
        keyring.delete_password(SERVICE_NAME, key)
    except keyring.errors.PasswordDeleteError:
        pass


# ═════════════════════════════════════════════════════════════════
# UserKey 构造
# ═════════════════════════════════════════════════════════════════

def build_userkey(username: str, password: str) -> str:
    """
    构造 UserKey：L + Base64(username:password) + S

    每次登录实时计算，不存储。
    """
    credentials = f"{username}:{password}"
    encoded = base64.b64encode(credentials.encode("utf-8")).decode("ascii")
    return f"L{encoded}S"


# ═════════════════════════════════════════════════════════════════
# 登录 / Logout
# ═════════════════════════════════════════════════════════════════

def _do_login(env: str = "prod") -> dict:
    """
    执行登录请求，返回 token 和 server_domain。

    ⚠️ 返回的 server_domain 来自登录响应，用于 Logout 接口。
    ⚠️ 与用户查询 API 的域名（api_domain）是不同的！
    """
    username = _get(KEY_USERNAME)
    password = _get(KEY_PASSWORD)

    if not all([username, password]):
        raise ValueError("密钥链中缺少凭证信息，请先运行 --setup 配置")

    # 使用固定设备标识符
    device_id = DEFAULT_DEVICE_ID

    # 构造登录请求
    login_url = ENV_CONFIG.get(env, ENV_CONFIG["prod"])
    headers = {
        "Content-Type": "application/json",
        "DeviceType": "5",
        "AppType": "10",
        "DeviceUniqueId": device_id,
    }
    payload = {
        "LoginUserArgu": {
            "key": build_userkey(username, password)
        }
    }

    resp = requests.put(login_url, json=payload, headers=headers, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    if data.get("code") != "0":
        raise ValueError(f"登录失败: code={data.get('code')}, message={data.get('message')}")

    # 提取 token 和 server_domain（来自响应，用于 Logout）
    token = data.get("token")
    server_domain = data.get("server", {}).get("domain", "")

    if not token:
        raise ValueError("登录响应中未找到 token")

    return {"token": token, "server_domain": server_domain}


def _do_logout(server_domain: str) -> None:
    """
    调用 Logout 接口使旧 token 失效。

    ⚠️ 必须使用 server_domain（来自登录响应），而不是 api_domain！
    """
    token = _get(KEY_TOKEN)
    # 使用固定设备标识符
    device_id = DEFAULT_DEVICE_ID

    if not token or not server_domain:
        return  # 没有 token 或域名，无需 logout

    logout_url = f"http://{server_domain}/user/services/rest/user/Logout"
    headers = {
        "DeviceType": "0",
        "AppType": "6",
        "DeviceUniqueId": device_id,
        "token": token,
    }

    try:
        requests.put(logout_url, headers=headers, timeout=10)
    except requests.RequestException:
        pass  # Logout 失败不影响主流程


# ═════════════════════════════════════════════════════════════════
# Token 管理
# ═════════════════════════════════════════════════════════════════

def get_valid_token(api_domain: str = None) -> str:
    """
    获取有效 token。

    流程：
    1. 读取缓存的 token
    2. 若无 token，执行登录
    3. 返回 token（不验证是否过期，调用方负责处理 401/-1001）
    """
    token = _get(KEY_TOKEN)

    if not token:
        token = _do_login(_get(KEY_ENV) or "prod")["token"]
        _set(KEY_TOKEN, token)

    return token


def refresh_token() -> str:
    """
    刷新 Token：调用 Logout 使旧 token 失效，然后重新登录。

    ⚠️ Logout 必须使用 server_domain（来自登录响应），
       与用户查询 API 的 api_domain 是不同的域名！
    """
    old_server_domain = _get(KEY_SERVER_DOMAIN)

    # 先调用 logout（使用 server_domain）
    if old_server_domain:
        _do_logout(old_server_domain)

    # 清除旧 token
    _delete(KEY_TOKEN)

    # 重新登录，获取新的 token 和 server_domain
    result = _do_login(_get(KEY_ENV) or "prod")
    _set(KEY_TOKEN, result["token"])
    _set(KEY_SERVER_DOMAIN, result["server_domain"])

    print(f"✓ Token 已刷新（server_domain: {result['server_domain']}）")
    return result["token"]


# ═════════════════════════════════════════════════════════════════
# 配置管理
# ═════════════════════════════════════════════════════════════════

def setup(username: str, password: str, env: str = "prod",
          api_domain: str = None) -> None:
    """
    首次配置：存储凭证和 API 域名。

    参数：
        username: 登录用户名
        password: 登录密码
        env: 环境 (dev/test/prod)
        api_domain: 用户查询 API 的域名（可选，与 server_domain 不同）
                   例如：uh.51tyty.com

    注意：使用固定设备标识符 zTang-dev-info，无需手动配置
    """
    _set(KEY_USERNAME, username)
    _set(KEY_PASSWORD, password)
    _set(KEY_ENV, env)

    if api_domain:
        _set(KEY_API_DOMAIN, api_domain)

    # 立即登录验证
    result = _do_login(env)
    _set(KEY_TOKEN, result["token"])
    _set(KEY_SERVER_DOMAIN, result["server_domain"])

    print(f"✓ 配置完成")
    print(f"  - 登录环境: {env}")
    print(f"  - Logout 域名 (server_domain): {result['server_domain']} ← 用于注销 token")
    if api_domain:
        print(f"  - 查询 API 域名 (api_domain): {api_domain} ← 用于用户查询")
    print(f"  - Token: {result['token'][:20]}...")


def get_status() -> dict:
    """查看当前配置状态。"""
    username = _get(KEY_USERNAME)
    env = _get(KEY_ENV)
    token = _get(KEY_TOKEN)
    server_domain = _get(KEY_SERVER_DOMAIN)
    api_domain = _get(KEY_API_DOMAIN)

    return {
        "已配置": bool(username),
        "用户名": username or "未设置",
        "登录环境": env or "未设置",
        "Token": (token[:20] + "...") if token else "未设置",
        "Logout 域名 (server_domain)": server_domain or "未设置",
        "查询 API 域名 (api_domain)": api_domain or "未设置",
        "设备ID": DEFAULT_DEVICE_ID,
    }


def reset() -> None:
    """清除所有配置。"""
    for key in [KEY_USERNAME, KEY_PASSWORD, KEY_ENV,
                KEY_TOKEN, KEY_SERVER_DOMAIN, KEY_API_DOMAIN]:
        _delete(key)
    print("✓ 配置已清除（设备ID为固定值，无需清除）")


def get_headers(api_domain: str = None) -> dict:
    """
    获取完整的请求头（含 token）。

    参数：
        api_domain: 用户查询 API 的域名。
                   若不提供，尝试从密钥链读取。

    ⚠️ 注意：这里使用的是 api_domain（用户查询 API 域名），
       不是 server_domain（Logout 域名）。
    """
    if not api_domain:
        api_domain = _get(KEY_API_DOMAIN)

    token = get_valid_token(api_domain)

    headers = {
        "host": api_domain,
        "token": token,
        "AppType": "6",
        "DeviceType": "0",
        "Content-Type": "application/json",
    }
    return headers


# ═════════════════════════════════════════════════════════════════
# CLI 入口
# ═════════════════════════════════════════════════════════════════

def main():
    import argparse

    parser = argparse.ArgumentParser(description="凭证管理器 - 基于密钥链的自动登录刷新")
    sub = parser.add_subparsers(dest="cmd")

    # setup 命令
    p_setup = sub.add_parser("setup", help="首次配置")
    p_setup.add_argument("--username", required=True, help="登录用户名")
    p_setup.add_argument("--password", required=True, help="登录密码")
    p_setup.add_argument("--env", default="prod", choices=["dev", "test", "prod"], help="登录环境")
    p_setup.add_argument("--api-domain", help="用户查询 API 域名（如 uh.51tyty.com）")

    # status 命令
    sub.add_parser("status", help="查看配置状态")

    # reset 命令
    sub.add_parser("reset", help="清除配置")

    # refresh 命令
    sub.add_parser("refresh", help="刷新 Token")

    args = parser.parse_args()

    if args.cmd == "setup":
        setup(args.username, args.password, args.env, args.api_domain)

    elif args.cmd == "status":
        status = get_status()
        for k, v in status.items():
            print(f"  {k}: {v}")

    elif args.cmd == "reset":
        reset()

    elif args.cmd == "refresh":
        refresh_token()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
