#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
get_user_info.py
通过 userId、username 或 mobile 查询用户信息

配置来源（优先级从高到低）：
  1. 命令行参数  --host / --token / --apptype / --devicetype（无文件模式，适合 AI 直接调用）
  2. 环境变量    USER_API_HOST / USER_API_TOKEN / USER_API_APPTYPE / USER_API_DEVICETYPE
  3. 本地配置文件  ~/.codebuddy/skills/dev-get-user-info-v1/config.json
                  ~/.workbuddy/skills/get-user-info/config.json
  4. 密钥链凭证   （--setup 配置，需 pip install keyring）

⚠️ 重要域名概念：
  - api_domain（--host）：用户查询 API 的域名，如 uh.51tyty.com
  - server_domain：Logout 接口域名，来自登录响应的 server.domain
  这两个域名可能不同！

用法:
  # ── 密钥链模式（首次需配置）──────────────────────────────────────
  python get_user_info.py --setup --username xxx --password xxx --env prod
  python get_user_info.py --setup --username xxx --password xxx --api-domain uh.51tyty.com
  python get_user_info.py id 19857          # 自动使用密钥链中的 token
  python get_user_info.py name stu_013      # Token 过期自动刷新
  python get_user_info.py status            # 查看密钥链配置
  python get_user_info.py reset             # 清除密钥链配置

  # ── 无文件模式（AI 直接调用）──────────────────────────────────────
  python get_user_info.py name studentuhqqt --host uh.51tyty.com --token xxx
  python get_user_info.py id 19857 --host uh.51tyty.com --token xxx

依赖:
  pip install requests [keyring]
"""

import sys
import json
import os
import argparse
from pathlib import Path

# ── Windows 控制台编码修复 ────────────────────────────────────────
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

import requests

# ── 导入凭证管理器 ─────────────────────────────────────────────────
try:
    from credential_manager import (
        setup as keyring_setup,
        get_status as keyring_status,
        reset as keyring_reset,
        refresh_token,
        get_valid_token,
        get_headers as keyring_get_headers,
        KEY_API_DOMAIN,
    )
    HAS_KEYRING = True
except ImportError:
    HAS_KEYRING = False

# ── 配置文件候选路径（按优先级） ──────────────────────────────────
_CONFIG_PATHS = [
    Path.home() / ".codebuddy" / "skills" / "dev-get-user-info-v1" / "config.json",
    Path.home() / ".workbuddy" / "skills" / "get-user-info" / "config.json",
]
DEFAULT_CONFIG_FILE = _CONFIG_PATHS[0]

# ── 字段映射 ──────────────────────────────────────────────────────
GENDER_MAP = {"0": "男", "1": "女"}
CAMPUS_TYPE_MAP = {"main_campus": "主校区"}

# ── Token 失效的业务错误码 ─────────────────────────────────────────
TOKEN_EXPIRED_CODES = {"-1001", "401"}
TOKEN_EXPIRED_MSGS = {"登录失效，请重新登录", "token expired", "token invalid"}


# ═════════════════════════════════════════════════════════════════
# Token 失效检测
# ═════════════════════════════════════════════════════════════════

def is_token_expired(data: dict, status_code: int = None) -> bool:
    """
    检测 Token 是否过期。

    多种检测方式：
    1. HTTP 状态码 401/403
    2. 业务错误码 -1001
    3. 错误消息包含特定文本
    """
    if status_code in (401, 403):
        return True
    if data.get("code") in TOKEN_EXPIRED_CODES:
        return True
    msg = data.get("message", "").lower()
    if any(expired_msg.lower() in msg for expired_msg in TOKEN_EXPIRED_MSGS):
        return True
    return False


# ═════════════════════════════════════════════════════════════════
# 配置加载
# ═════════════════════════════════════════════════════════════════

def load_config_from_file() -> dict | None:
    """从本地配置文件加载，返回 None 表示不存在。"""
    for path in _CONFIG_PATHS:
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"⚠ 读取配置文件失败 ({path}): {e}", file=sys.stderr)
    return None


def load_config_from_env() -> dict | None:
    """从环境变量加载，返回 None 表示未配置。"""
    host = os.environ.get("USER_API_HOST")
    token = os.environ.get("USER_API_TOKEN")
    if not (host and token):
        return None
    return {
        "host": host,
        "token": token,
        "apptype": os.environ.get("USER_API_APPTYPE", "6"),
        "devicetype": os.environ.get("USER_API_DEVICETYPE", "0"),
        "Content-Type": "application/json",
    }


def build_config_from_args(args) -> dict | None:
    """从命令行参数构建配置，返回 None 表示参数中没有提供 host/token。"""
    if not (getattr(args, "host", None) and getattr(args, "token", None)):
        return None
    return {
        "host": args.host,
        "token": args.token,
        "apptype": getattr(args, "apptype", "6") or "6",
        "devicetype": getattr(args, "devicetype", "0") or "0",
        "Content-Type": "application/json",
    }


def resolve_config(args) -> dict:
    """
    按优先级解析配置：
      命令行参数 > 环境变量 > 本地文件 > 密钥链 > 交互式输入
    """
    # 1. 命令行参数（无文件模式）
    cfg = build_config_from_args(args)
    if cfg:
        return cfg

    # 2. 环境变量
    cfg = load_config_from_env()
    if cfg:
        return cfg

    # 3. 本地配置文件
    cfg = load_config_from_file()
    if cfg:
        return cfg

    # 4. 密钥链凭证
    if HAS_KEYRING:
        status = keyring_status()
        if status.get("已配置"):
            api_domain = status.get("查询 API 域名 (api_domain)")
            if api_domain and api_domain != "未设置":
                token = get_valid_token(api_domain)
                return {
                    "host": api_domain,
                    "token": token,
                    "apptype": "6",
                    "devicetype": "0",
                    "Content-Type": "application/json",
                    "_using_keyring": True,
                }

    # 5. 交互式输入（兜底，仅限人工命令行场景）
    return interactive_config()


def extract_domain(config: dict) -> str:
    """从配置中提取 host 字段作为 API 域名。"""
    for key, value in config.items():
        if key.lower() == "host":
            return value
    raise ValueError("配置中未找到 'host' 字段")


# ═════════════════════════════════════════════════════════════════
# 配置文件管理
# ═════════════════════════════════════════════════════════════════

def save_config(config: dict, path: Path = None):
    """保存配置到本地文件。"""
    target = path or DEFAULT_CONFIG_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    print(f"✔ 配置已保存到: {target}")


def interactive_config() -> dict:
    """交互式配置（命令行手动使用时的兜底方案）。"""
    print("=" * 52)
    print("  用户信息查询 - 配置向导")
    print("=" * 52)
    print()
    print("请逐行输入 API Headers（格式: key: value），")
    print("必须包含 host 字段。输入空行结束。")
    print()

    headers: dict = {}

    while True:
        try:
            line = input("  Header> ").strip()
        except EOFError:
            _print_no_interactive_help()
            sys.exit(2)

        if not line:
            break
        if ":" not in line:
            print("  ✗ 格式错误，请使用 'key: value'")
            continue
        key, _, value = line.partition(":")
        headers[key.strip()] = value.strip()

    if not any(k.lower() == "host" for k in headers):
        print("\n✗ 必须包含 host 字段，请重试。\n")
        return interactive_config()

    if not any(k.lower() == "content-type" for k in headers):
        headers["Content-Type"] = "application/json"

    save_config(headers)
    domain = extract_domain(headers)
    print(f"\n✔ 配置完成，API 域名: {domain}\n")
    return headers


def _print_no_interactive_help():
    """当 AI 环境中 input() 失败时，打印配置说明。"""
    print()
    print("✗ 当前环境不支持交互式输入（AI 代理模式）。")
    print()
    print("请通过以下方式配置：")
    print()
    print("方式 1: 密钥链模式（推荐，自动 Token 管理）")
    print("  pip install keyring")
    print("  python get_user_info.py --setup \\")
    print("    --username <用户名> --password <密码> \\")
    print("    --env prod --api-domain <API域名>")
    print()
    print("方式 2: 命令行参数（无文件模式）")
    print("  python get_user_info.py name <用户名> \\")
    print("    --host <API域名> --token <token>")
    print()
    print("或设置环境变量：")
    print("  $env:USER_API_HOST='<API域名>'; $env:USER_API_TOKEN='<token>'")


# ═════════════════════════════════════════════════════════════════
# API 查询（带 Token 自动刷新）
# ═════════════════════════════════════════════════════════════════

def query_by_id(user_id: str, config: dict, domain: str) -> dict:
    url = f"http://{domain}/user/services/rest/user/{user_id}"
    r = requests.get(url, headers=config, timeout=10)
    return r.json(), r.status_code


def query_by_name(name: str, config: dict, domain: str) -> dict:
    url = f"http://{domain}/user/services/rest/user/Name/{name}"
    r = requests.get(url, headers=config, timeout=10)
    return r.json(), r.status_code


def execute_query(args, config: dict) -> dict:
    """
    执行查询，支持 Token 过期自动刷新。
    返回 (data, status_code)。
    """
    domain = extract_domain(config)

    if args.command == "id":
        return query_by_id(args.value, config, domain)
    else:  # name or mobile
        return query_by_name(args.value, config, domain)


def check_response(data: dict, status_code: int = 200):
    """检查 API 响应，Token 过期时抛出特殊异常。"""
    if is_token_expired(data, status_code):
        raise TokenExpiredError()
    if data.get("code") != "0":
        raise ValueError(
            f"API 错误 code={data.get('code')}: {data.get('message', '未知错误')}"
        )


class TokenExpiredError(Exception):
    """Token 过期异常，触发自动刷新。"""
    pass


# ═════════════════════════════════════════════════════════════════
# 结果格式化
# ═════════════════════════════════════════════════════════════════

def format_user(user: dict) -> str:
    gender = GENDER_MAP.get(user.get("gender", ""), "未知")
    campus = CAMPUS_TYPE_MAP.get(user.get("campusType", ""), user.get("campusType", ""))
    is_valid = "有效" if user.get("isvalidate") == "true" else "无效"
    expired = "已过期" if user.get("expiredStatus") != "0" else "未过期"

    lines = [
        "=" * 52,
        "  用户信息查询结果",
        "=" * 52,
        f"  用户 ID     : {user.get('userId', '-')}",
        f"  用户名      : {user.get('username', '-')}",
        f"  昵称        : {user.get('nickname', '-')}",
        f"  性别        : {gender}",
        f"  手机号      : {user.get('mobile') or '未填写'}",
        f"  角色        : {user.get('role', '-')}",
        f"  机构 ID     : {user.get('instId', '-')}",
        f"  校区        : {user.get('campusTitle', '-')} ({campus})",
        f"  账号状态    : {is_valid} / {expired}",
        f"  激活时间    : {user.get('activeDate', '-')}",
        f"  有效期      : {user.get('startDate', '-')} ~ {user.get('endDate', '-')}",
        f"  积分(总/可用/已用): {user.get('total',0)} / {user.get('available',0)} / {user.get('consuming',0)}",
        f"  头像        : {user.get('photourl') or '未设置'}",
        "=" * 52,
    ]
    return "\n".join(lines)


# ═════════════════════════════════════════════════════════════════
# CLI 入口
# ═════════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="get_user_info.py",
        description="查询企业内部用户信息（支持密钥链自动 Token 管理）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
⚠️ 域名说明：
  - api_domain (--host)：用户查询 API 的域名，如 uh.51tyty.com
  - server_domain：Logout 接口域名，来自登录响应的 server.domain
  这两个域名可能不同！

密钥链模式（首次需配置）：
  python get_user_info.py --setup --username xxx --password xxx \\
    --env prod --api-domain uh.51tyty.com
  python get_user_info.py id 19857          # 自动使用 Token
  python get_user_info.py status            # 查看密钥链配置
  python get_user_info.py reset             # 清除密钥链配置
  python get_user_info.py refresh           # 刷新 Token

无文件模式（AI 直接调用）：
  python get_user_info.py name studentuhqqt --host uh.51tyty.com --token xxx
  python get_user_info.py id 19857 --host uh.51tyty.com --token xxx

配置文件模式：
  python get_user_info.py config            # 交互式创建配置文件
  python get_user_info.py show-config        # 查看配置文件
        """,
    )

    parser.add_argument(
        "command",
        nargs="?",
        choices=["id", "name", "mobile", "config", "show-config", "status", "reset", "refresh"],
        help="查询方式或管理命令",
    )
    parser.add_argument(
        "value",
        nargs="?",
        help="查询值（id/name/mobile 模式必填）",
    )

    # ── 密钥链配置参数 ──────────────────────────────────────
    group_keyring = parser.add_argument_group("密钥链模式（首次配置）")
    group_keyring.add_argument("--setup", action="store_true", help="进入密钥链配置向导")
    group_keyring.add_argument("--username", help="登录用户名")
    group_keyring.add_argument("--password", help="登录密码")
    group_keyring.add_argument("--env", default="prod", choices=["dev", "test", "prod"], help="登录环境")
    group_keyring.add_argument("--api-domain", help="用户查询 API 域名（如 uh.51tyty.com）")

    # ── 无文件模式参数 ──────────────────────────────────────
    group = parser.add_argument_group("无文件模式（直接传入配置）")
    group.add_argument("--host", metavar="DOMAIN", help="API 域名，如 uh.51tyty.com")
    group.add_argument("--token", metavar="TOKEN", help="认证令牌")
    group.add_argument("--apptype", metavar="N", default="6", help="应用类型（默认 6）")
    group.add_argument("--devicetype", metavar="N", default="0", help="设备类型（默认 0）")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    # ── 密钥链 setup 命令 ────────────────────────────────
    if args.setup:
        if not HAS_KEYRING:
            print("✗ 密钥链模式需要安装 keyring: pip install keyring")
            sys.exit(1)
        if not (args.username and args.password):
            print("✗ --setup 需要提供 --username, --password")
            sys.exit(1)
        keyring_setup(args.username, args.password,
                      args.env, args.api_domain)
        sys.exit(0)

    # ── 密钥链管理命令 ────────────────────────────────────
    if args.command in ("status", "reset", "refresh"):
        if not HAS_KEYRING:
            print("✗ 密钥链模式需要安装 keyring: pip install keyring")
            sys.exit(1)

        if args.command == "status":
            status = keyring_status()
            for k, v in status.items():
                print(f"  {k}: {v}")
        elif args.command == "reset":
            keyring_reset()
        elif args.command == "refresh":
            refresh_token()
        sys.exit(0)

    # ── config / show-config 管理命令 ─────────────────────
    if args.command == "config":
        interactive_config()
        sys.exit(0)

    if args.command == "show-config":
        cfg = load_config_from_file()
        if not cfg:
            print("未找到本地配置文件。")
            for p in _CONFIG_PATHS:
                print(f"  候选路径: {p}")
        else:
            # 脱敏展示 token
            display = {k: ("***已设置***" if k.lower() == "token" else v) for k, v in cfg.items()}
            print(json.dumps(display, ensure_ascii=False, indent=2))
        sys.exit(0)

    # ── 查询命令 ──────────────────────────────────────────
    if not args.value:
        parser.error(f"命令 '{args.command}' 需要提供查询值，例如：... {args.command} 19857")

    # 解析配置
    try:
        config = resolve_config(args)
        domain = extract_domain(config)
    except ValueError as e:
        print(f"✗ 配置错误: {e}")
        sys.exit(1)

    # 判断配置来源
    using_keyring = config.pop("_using_keyring", False)
    src = "密钥链" if using_keyring else (
        "命令行参数" if build_config_from_args(args) else
        ("环境变量" if load_config_from_env() else "本地配置文件")
    )
    print(f"▶ 配置来源: {src}  |  api_domain: {domain}")
    print()

    # 执行查询（带 Token 刷新重试）
    for attempt in range(2):
        try:
            if args.command == "id":
                print(f"正在通过 userId 查询: {args.value} ...")
                data, status_code = query_by_id(args.value, config, domain)
            else:  # name or mobile
                label = "用户名" if args.command == "name" else "手机号"
                print(f"正在通过{label}查询: {args.value} ...")
                data, status_code = query_by_name(args.value, config, domain)

            check_response(data, status_code)
            user = data.get("user", {})
            if not user:
                print("✗ 未找到该用户。")
                sys.exit(1)

            print(format_user(user))
            print("\n[原始 JSON]")
            print(json.dumps(data, ensure_ascii=False, indent=2))
            break  # 查询成功，退出重试循环

        except TokenExpiredError:
            if attempt == 0 and using_keyring:
                print("⚠ Token 已过期，正在刷新...")
                if HAS_KEYRING:
                    new_token = refresh_token()
                    config["token"] = new_token
                    print("✓ Token 刷新成功，正在重试...")
                    print()
                else:
                    print("✗ Token 过期且无法刷新，请重新配置")
                    sys.exit(1)
            else:
                print("✗ Token 过期，请重新配置")
                sys.exit(1)

        except requests.ConnectionError:
            print(f"✗ 无法连接服务器，请检查网络或 host 配置（当前: {domain}）")
            sys.exit(1)
        except requests.HTTPError as e:
            print(f"✗ HTTP 错误: {e}")
            sys.exit(1)
        except ValueError as e:
            print(f"✗ 业务错误: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"✗ 未知错误: {e}")
            sys.exit(1)


if __name__ == "__main__":
    main()
