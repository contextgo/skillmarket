---
name: get-user-info
version: 2.0.0
author: WorkBuddy User
description: >
  通过 REST API 查询企业内部用户信息，支持按 userId、username、mobile
  三种方式查询。自动管理登录凭证，Token 过期自动刷新。

  触发词：查询用户信息、获取用户信息、根据用户ID查用户、
  根据用户名查用户、根据手机号查用户、get user info、
  fetch user details 等。
tags: [api, user-query, enterprise, rest, auto-auth]
dependencies:
  - requests
  - keyring
---

# get-user-info Skill

## 功能概述

本 Skill 用于查询企业内部用户信息，无需手动管理配置文件，通过 AI 对话即可完成配置和使用。

### 支持的查询方式

| 查询方式 | 命令示例 | 说明 |
|----------|----------|------|
| userId | `id 19857` | 通过用户 ID 查询 |
| username | `name stu_013` | 通过登录用户名查询 |
| mobile | `mobile 13800138000` | 通过手机号查询 |

### 核心能力

- **零配置启动** - AI 在对话中引导配置，无需手动编辑文件
- **凭证安全管理** - 账号密码存入系统密钥链（操作系统级加密）
- **自动 Token 刷新** - 检测到 Token 过期自动重新登录
- **多环境支持** - 可配置 dev / test / prod 环境

---

## 快速开始

### 方式一：AI 引导配置（推荐）

直接告诉 AI 你想查询的用户信息，例如：

```
查询用户 ID 为 19857 的用户信息
```

AI 会自动引导你完成首次配置，后续查询无需重复配置。

### 方式二：命令行配置

```bash
# 首次配置
python scripts/get_user_info.py --setup \
  --username <用户名> \
  --password <密码> \
  --env prod \
  --api-domain <API域名>

# 查询用户
python scripts/get_user_info.py id 19857
python scripts/get_user_info.py name stu_013
python scripts/get_user_info.py mobile 13800138000
```

### 管理命令

```bash
python scripts/get_user_info.py status   # 查看配置状态
python scripts/get_user_info.py refresh  # 手动刷新 Token
python scripts/get_user_info.py reset    # 清除配置
```

---

## 配置参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `--username` | 是 | 登录用户名 |
| `--password` | 是 | 登录密码 |
| `--env` | 是 | 环境：`dev` / `test` / `prod` |
| `--api-domain` | 是 | 用户查询 API 的域名地址 |

> **注意**：设备标识符使用固定值 `zTang-dev-info`，无需手动配置。

---

## 文件结构

```
get-user-info/
├── SKILL.md                  # Skill 元数据和使用指南
├── README.md                 # 详细使用说明
├── manifest.json             # SkillHub 上传元数据
├── assets/
│   └── icon.svg              # Skill 图标
├── scripts/
│   ├── get_user_info.py      # 主脚本
│   └── credential_manager.py # 凭证管理器
└── references/
    └── api_doc.md            # API 接口参考（内部使用）
```

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-03 | 初始版本，交互式配置 |
| 1.1.0 | 2026-04-07 | 新增无文件模式（命令行传参） |
| 2.0.0 | 2026-04-09 | 新增密钥链自动 Token 管理 |
