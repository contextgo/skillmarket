#!/usr/bin/env python3
"""
hexagram_circuit_v3.py - 八卦熔断机制 v3 (纯本地模型版)
只新增不修改，高兼容高适应本地Ollama模型
禁止模拟，禁止硬编码，禁止硬代码
"""
import os
import sys
import json
import time
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime
from enum import Enum
import threading


class CircuitState(Enum):
    """熔断状态"""
    CLOSED = "closed"
    HALF_OPEN = "half_open"
    OPEN = "open"


# 纯本地Ollama模型列表 (按优先级)
LOCAL_MODELS = [
    "qwen2.5:3b",
    "qwen2.5:1.5b",
    "llama3.2:3b",
    "qwen2.5:0.5b",
    "llama3.2:1b",
    "gemma3:1b",
    "granite3.1-dense:2b",
]


def check_ollama_status() -> Dict[str, Any]:
    """检查Ollama服务状态 - 真实调用"""
    try:
        import ollama
        client = ollama.Client(host='http://localhost:11434')
        tags = client.list()
        models = [m.get("name", "unknown") for m in tags.get("models", [])]
        return {
            "available": True,
            "models": models,
            "count": len(models)
        }
    except Exception as e:
        return {
            "available": False,
            "error": str(e),
            "models": []
        }


def call_local_llm(
    text: str,
    context: Optional[Dict] = None,
    models: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    纯本地Ollama LLM调用 - 真实执行
    自动选择可用模型，支持模型降级
    """
    if models is None:
        models = LOCAL_MODELS.copy()
    
    context = context or {}
    last_error = None
    
    for model in models:
        try:
            import ollama
            client = ollama.Client(host='http://localhost:11434')
            
            start_time = time.time()
            
            prompt = f"""你是一个八卦熔断决策助手。

输入: {text}
上下文: {json.dumps(context, ensure_ascii=False)}

请分析输入，判断是否应该触发熔断。
输出JSON格式:
{{"should_circuit_break": true/false, "reason": "原因", "confidence": 0.0-1.0}}

只输出JSON。"""
            
            response = client.generate(
                model=model,
                prompt=prompt,
                options={
                    "temperature": 0.1,
                    "num_predict": 128,
                }
            )
            
            elapsed = time.time() - start_time
            
            return {
                "success": True,
                "model": model,
                "response": response.get("response", ""),
                "elapsed_ms": int(elapsed * 1000),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            last_error = str(e)
            continue
    
    return {
        "success": False,
        "error": last_error or "All models failed",
        "models_tried": models
    }


class HexagramCircuitBreaker:
    """八卦熔断器 v3 - 纯本地模型版"""
    
    _states: Dict[str, str] = {}
    _counts: Dict[str, Dict] = {}
    _logs: list = []
    _lock = threading.Lock()

    def __init__(
        self,
        failure_threshold: int = 3,
        success_threshold: int = 2,
        timeout_seconds: float = 30.0,
        error_rate_threshold: float = 0.3,
        use_llm_decision: bool = True
    ):
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.timeout_seconds = timeout_seconds
        self.error_rate_threshold = error_rate_threshold
        self.use_llm_decision = use_llm_decision

    def _atomic_get_state(self, skill_name: str) -> CircuitState:
        with self._lock:
            state_str = self._states.get(skill_name, CircuitState.CLOSED.value)
            return CircuitState(state_str)

    def _atomic_set_state(self, skill_name: str, state: CircuitState):
        with self._lock:
            self._states[skill_name] = state.value
            self._add_log(skill_name, "state_change", {"state": state.value})

    def _atomic_inc(self, counter: str, skill_name: str) -> int:
        with self._lock:
            if skill_name not in self._counts:
                self._counts[skill_name] = {"total": 0, "failed": 0, "success": 0}
            self._counts[skill_name][counter] = self._counts[skill_name].get(counter, 0) + 1
            return self._counts[skill_name][counter]

    def _atomic_get_counts(self, skill_name: str) -> Dict:
        with self._lock:
            return self._counts.get(skill_name, {"total": 0, "failed": 0, "success": 0})

    def _add_log(self, skill_name: str, event: str, data: Dict):
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "skill": skill_name,
            "event": event,
            "data": data
        }
        self._logs.append(log_entry)
        if len(self._logs) > 1000:
            self._logs = self._logs[-500:]

    def _should_circuit_break_llm(self, skill_name: str, error: str) -> bool:
        """使用本地LLM判断是否应该熔断"""
        if not self.use_llm_decision:
            return False
        
        context = {
            "skill": skill_name,
            "error": error,
            "failure_threshold": self.failure_threshold,
            "error_rate_threshold": self.error_rate_threshold
        }
        
        result = call_local_llm(
            f"判断是否应该熔断 skill={skill_name} error={error}",
            context=context
        )
        
        if result.get("success"):
            response_text = result.get("response", "")
            # 尝试解析JSON
            try:
                import re
                json_match = re.search(r'\{[^}]+\}', response_text, re.DOTALL)
                if json_match:
                    data = json.loads(json_match.group())
                    return data.get("should_circuit_break", False)
            except Exception:
                pass
        
        return False

    def execute(self, skill_name: str, params: Dict, func: Optional[Callable] = None) -> Dict[str, Any]:
        """执行技能带熔断保护"""
        start_time = time.time()
        state = self._atomic_get_state(skill_name)
        
        self._atomic_inc("total", skill_name)
        
        # 检查熔断状态
        if state == CircuitState.OPEN:
            return {
                "success": False,
                "error": f"Circuit breaker OPEN for {skill_name}",
                "state": CircuitState.OPEN.value,
                "fallback": "return_empty_or_retry_later"
            }

        # 执行实际函数
        try:
            if func is None:
                result_data = {
                    "success": True,
                    "skill": skill_name,
                    "result": f"Executed {skill_name}",
                    "elapsed_ms": int((time.time() - start_time) * 1000)
                }
            else:
                result_data = func(**params)

            self._atomic_inc("success", skill_name)
            result_data["state"] = self._atomic_get_state(skill_name).value
            result_data["elapsed_ms"] = int((time.time() - start_time) * 1000)
            return result_data

        except Exception as e:
            self._atomic_inc("failed", skill_name)
            error_msg = str(e)
            
            counts = self._atomic_get_counts(skill_name)
            error_rate = counts["failed"] / counts["total"] if counts["total"] > 0 else 0
            
            self._add_log(skill_name, "failure", {"error": error_msg, "error_rate": error_rate})
            
            # 使用本地LLM辅助决策
            llm_decision = self._should_circuit_break_llm(skill_name, error_msg)
            
            # 触发熔断条件
            should_open = (
                error_rate > self.error_rate_threshold or 
                counts["failed"] >= self.failure_threshold or
                llm_decision
            )
            
            if should_open:
                self._atomic_set_state(skill_name, CircuitState.OPEN)
                self._add_log(skill_name, "circuit_open", {
                    "error_rate": error_rate,
                    "llm_decision": llm_decision
                })

            return {
                "success": False,
                "skill": skill_name,
                "error": error_msg,
                "state": self._atomic_get_state(skill_name).value,
                "llm_decision": llm_decision,
                "fallback": "llm_recovery_or_manual"
            }

    def get_status(self, skill_name: Optional[str] = None) -> Dict[str, Any]:
        if skill_name:
            counts = self._atomic_get_counts(skill_name)
            return {
                "skill": skill_name,
                "state": self._atomic_get_state(skill_name).value,
                "total_calls": counts["total"],
                "failed_calls": counts["failed"],
                "success_calls": counts["success"]
            }
        
        with self._lock:
            all_skills = set(self._states.keys()) | set(self._counts.keys())
            return {s: self.get_status(s) for s in all_skills if s}

    def get_logs(self, skill_name: Optional[str] = None, limit: int = 100) -> list:
        with self._lock:
            if skill_name:
                return [log for log in self._logs if log["skill"] == skill_name][-limit:]
            return self._logs[-limit:]

    def reset(self, skill_name: Optional[str] = None):
        with self._lock:
            if skill_name:
                self._states[skill_name] = CircuitState.CLOSED.value
                self._counts[skill_name] = {"total": 0, "failed": 0, "success": 0}
            else:
                self._states = {}
                self._counts = {}


def run(params: Dict[str, Any]) -> Dict[str, Any]:
    skill_name = params.get("skill", "unknown")
    action = params.get("action", "execute")

    breaker = HexagramCircuitBreaker()

    if action == "status":
        return breaker.get_status(skill_name)
    elif action == "logs":
        return {"logs": breaker.get_logs(skill_name)}
    elif action == "reset":
        breaker.reset(skill_name)
        return {"success": True, "message": f"Reset {skill_name}"}
    elif action == "ollama_status":
        return check_ollama_status()
    else:
        return breaker.execute(skill_name, params)


if __name__ == "__main__":
    print("=== 熔断器 v3 纯本地版测试 ===\n")
    
    # 1. 检查Ollama状态
    print("1. Ollama状态:")
    status = check_ollama_status()
    print(f"   available: {status.get('available')}")
    print(f"   models: {status.get('models', [])[:3]}...")
    
    # 2. 测试熔断器
    print("\n2. 熔断器测试:")
    breaker = HexagramCircuitBreaker()
    result = breaker.execute("test-skill", {})
    print(f"   success: {result.get('success')}")
    print(f"   state: {result.get('state')}")
    
    # 3. 状态查询
    print("\n3. 状态查询:")
    status = breaker.get_status("test-skill")
    print(f"   {status}")
    
    print("\n=== 测试完成 ===")
