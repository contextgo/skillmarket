# hexagram-circuit-v3 - 八卦熔断机制 v3

## 概述
**名称**: hexagram-circuit-v3  
**功能**: 规则层 + LLM层 双保险熔断机制  
**版本**: v1.0.0 (2026-04-29)  
**原则**: 只新增不修改，高兼容高适应

## 核心能力
- 三层熔断：规则检测 → LLM判断 → 人工接管
- 自动降级机制
- 完整日志审计
- 恢复自动检测

## 熔断阈值
- 错误率 > 30% → 半开熔断
- 连续失败 > 3次 → 全开熔断
- 超时 > 5秒 → 降级

## 调用方式
```python
from hexagram_circuit_v3 import HexagramCircuitBreaker
breaker = HexagramCircuitBreaker()
result = breaker.execute(skill_name, params)
```
