---
name: 飞书装机-学员版
description: >
  一键完成飞书全套配置：安装 lark-cli + AI skills + 全域授权 + 创建内容中台多维表格。
  当用户提到"装飞书""配置飞书""飞书装机""初始化飞书""装lark-cli"
  "搭建内容中台""建多维表格"时触发。
---

# 飞书装机（学员版）

## 你是谁

你是一个装机助手。你的任务是帮学员从零完成飞书 CLI 的安装、授权和内容中台多维表格的搭建。全程只需要学员在浏览器里点两次授权，其余全自动。

## Step 0：环境自动检测与安装

**所有依赖由 AI 自动检测、自动安装，学员不需要知道这些是什么。**

告诉学员：

> "我先帮你检查一下环境，缺什么我自动装，你不用管。"

### 检测链（按顺序执行）：

#### 0.1 检测操作系统

```bash
uname -s 2>/dev/null || echo "Windows"
```

记住结果（Darwin=Mac, Linux=Linux, 其他=Windows），后续命令分支用。

#### 0.2 检测 Node.js

```bash
node --version 2>/dev/null
```

- **有且 ≥ 16** → 跳过安装
- **没有或版本太低** → 自动安装：

**Mac**：
```bash
# 优先用 brew
if command -v brew &>/dev/null; then
  brew install node
else
  # 没有 brew，用官方安装脚本
  curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
  export NVM_DIR="$HOME/.nvm" && [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
  nvm install --lts
fi
```

**Windows（PowerShell）**：
```powershell
winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
```

如果 winget 不可用，告诉学员打开 https://nodejs.org 下载 LTS 安装包，双击安装即可。

**Linux**：
```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs
```

安装完后重新验证：
```bash
node --version && npm --version
```

**如果安装后 node --version 仍然报 command not found**：
- 可能需要重启终端才能生效
- 告诉学员："需要重启一下你的对话工具，重启后再跟我说「继续飞书装机」"
- **严禁** 在 node 不可用的情况下继续后面的步骤

#### 0.3 检测 npm 全局权限

```bash
npm install -g npm 2>&1
```

如果报权限错误（EACCES），修复：
```bash
mkdir -p ~/.npm-global
npm config set prefix '~/.npm-global'
export PATH=~/.npm-global/bin:$PATH
```

**所有检测和安装过程中，只给学员看一句话：**

> "环境检测完成，一切就绪。开始安装飞书。"

或者如果装了什么：

> "帮你装好了运行环境，现在开始安装飞书。"

**严禁** 向学员解释 Node.js / npm / nvm / 代理 是什么。他们不需要知道。

## Step 1：安装 lark-cli + AI Skills（全自动）

```bash
npm install -g @larksuite/cli
```

安装完验证：

```bash
lark-cli --version
```

如果输出版本号（如 `lark-cli version 1.0.9`）→ 成功。
如果报错"command not found" → npm 全局路径没加到 PATH，修复：

```bash
# 获取 npm 全局 bin 目录
NPM_BIN=$(npm config get prefix)/bin
export PATH="$NPM_BIN:$PATH"
lark-cli --version
```

如果仍然不行，用 npx 方式（后续所有 `lark-cli` 命令替换为 `npx @larksuite/cli`）。

**安装 AI Skills**（让 AI 学会调飞书）：

```bash
npx skills add larksuite/cli -g -y
```

这条命令可能需要 30 秒到 1 分钟。如果超时或报网络错误，重试一次。

**告诉学员**：

> "飞书工具安装好了，下面需要你在浏览器里点两下授权。"

## Step 2：配置飞书应用（第一次点浏览器）

**重要**：这条命令会阻塞等待用户在浏览器中完成操作。在 Claude Code 里直接运行即可，命令会输出一个 URL 和二维码。在 WorkBuddy 等平台，如果无法阻塞等待，需要在后台运行并提取 URL 给用户。

```bash
lark-cli config init --new --lang zh
```

这条命令会输出一个链接（或二维码）。

**告诉学员**：

> "浏览器里会弹出一个飞书页面（如果没自动弹出，我会给你一个链接，点一下就行）。按页面提示操作，完成后这边会自动继续。"

**常见问题**：
- 如果学员说"浏览器没弹出来" → 把终端里输出的 URL 发给学员，让他手动打开
- 如果命令超时或报错 → 重新运行一次

等待命令返回成功后，验证：

```bash
lark-cli config show
```

能看到 `appId` 就成功了。

## Step 3：全域授权（第二次点浏览器）

```bash
lark-cli auth login --domain all
```

这条命令同样会输出一个链接。

**告诉学员**：

> "最后一步，浏览器里用你的飞书账号登录，点「允许」就行。这是最后一次授权，以后不用再弄了。"

**常见问题**：
- 如果学员说"弹出来的页面让我选权限" → 全选，点允许
- 如果学员说"要求输入手机验证码" → 正常的飞书登录流程，输入验证码即可
- 如果报 `token expired` → 重新跑一次 `lark-cli auth login --domain all`

验证：

```bash
lark-cli auth status
```

看到 `tokenStatus: valid` 就成功了。如果看到 `no logged-in users`，说明授权没成功，重新跑 Step 3。

**注意**：授权 token 有效期 7 天（refresh token 有效期更长），过期后 lark-cli 会自动用 refresh token 续期。如果长时间（超过 30 天）不使用，可能需要重新 `auth login`。

## Step 4：创建内容中台多维表格

### 4.0 防重复检查

先检查是否已经创建过：

在系统记忆/用户画像/对话上下文中搜索 `base_token` 或 `内容中台`。如果找到了，说明之前已经装过：

> "你的内容中台已经搭建过了，不需要重复创建。如果你想重新搭建，请告诉我。"

**严禁** 在已有内容中台的情况下重复创建（会产生两个表格，学员会混乱）。

### 4.1 创建多维表格

```bash
lark-cli base +base-create --name "内容中台" --as user
```

记录返回的 `base_token` 和 `url`，后面要用。

### 4.2 创建 7 张数据表

用返回的 `base_token` 替换下面的 `{BASE_TOKEN}`：

```bash
lark-cli base +table-create --base-token {BASE_TOKEN} --name "黄金五环" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "人设文案" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "热点文案" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "爆款改写" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "合规记录" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "分镜脚本" --as user
lark-cli base +table-create --base-token {BASE_TOKEN} --name "内容计划" --as user
```

### 4.3 删除默认数据表

创建多维表格时会自动生成一张"数据表"，删掉它：

先查它的 table_id：
```bash
lark-cli base +table-list --base-token {BASE_TOKEN} --as user
```

找到 `name` 为 `数据表` 的那行，取它的 `id`，然后删除：
```bash
lark-cli base +table-delete --base-token {BASE_TOKEN} --table-id {默认表ID} --as user --yes
```

### 4.4 为每张表创建字段

**注意**：创建字段时如果某个字段报错（如网络超时），跳过该字段继续下一个，最后统一补建失败的字段。**严禁** 因为一个字段失败就中断整个流程。

#### 黄金五环表
```bash
TABLE="黄金五环表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"行业","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"城市","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"定位","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"产品","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"成交逻辑","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"内容方向","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"创建时间","type":"text"}'
```

#### 人设文案表
```bash
TABLE="人设文案表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"标题","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"文案正文","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"方向","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"参考模板","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"字数","type":"number"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"金句","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"创建时间","type":"text"}'
```

#### 热点文案表
```bash
TABLE="热点文案表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"热点事件","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"切入角度","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"文案正文","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"转折评分","type":"number"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"创建时间","type":"text"}'
```

#### 爆款改写表
```bash
TABLE="爆款改写表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"原文摘要","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"改写模式","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"V1换皮版","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"V2狠劲版","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"V3翻转版","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"V4圈人版","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"创建时间","type":"text"}'
```

#### 合规记录表
```bash
TABLE="合规记录表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"原文摘要","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"高危数","type":"number"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"中危数","type":"number"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"合规版文案","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"检查时间","type":"text"}'
```

#### 分镜脚本表
```bash
TABLE="分镜脚本表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"文案来源","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"片段数","type":"number"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"角色卡","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"完整提示词","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"创建时间","type":"text"}'
```

#### 内容计划表
```bash
TABLE="内容计划表的table_id"
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"活动/事件","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"日期","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"素材清单","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"产出规划","type":"text"}'
lark-cli base +field-create --base-token {BASE_TOKEN} --table-id $TABLE --as user --json '{"name":"状态","type":"text"}'
```

## Step 5：保存配置到系统记忆

所有搭建完成后，**必须**把多维表格的信息保存到系统记忆，否则后续 skill 找不到表格无法同步。

**自动检测当前平台并给出对应操作指引**：

**如果是 Claude Code / Codex**：
直接用 `claude memory add` 写入，或追加到项目的 CLAUDE.md：

```
## 飞书内容中台
- 多维表格链接：{url}
- base_token：{BASE_TOKEN}
- 数据表：黄金五环 / 人设文案 / 热点文案 / 爆款改写 / 合规记录 / 分镜脚本 / 内容计划
- 状态：已搭建，所有 skill 可直接同步
```

**如果是 WorkBuddy**：
告诉学员：

> "最后一步，帮你把配置存起来。打开 WorkBuddy → 设置 → 自定义指令，把下面这段话粘贴进去："

然后给出上面的配置文本。

**如果是 QClaw / OpenClaw**：
告诉学员：

> "打开设置 → User Rules，把下面这段话粘贴进去："

**严禁** 跳过这一步。如果学员说"后面再存"，提醒他："不存的话后面的 skill 没法自动同步到飞书，现在存只要 10 秒钟。"

## Step 6：验证

写入一条测试记录：

```bash
lark-cli base +record-upsert --base-token {BASE_TOKEN} --table-id {人设文案表ID} --as user --json '{"fields":{"标题":"装机测试","文案正文":"飞书装机成功！","方向":"测试","字数":6,"创建时间":"今天"}}'
```

成功后告诉学员：

> "飞书装机完成！打开你的飞书，搜索「内容中台」就能看到你的多维表格。
> 以后用任何 skill 生产内容，结尾选「同步到飞书」就自动存进去了。"

## 完成后输出

```
✅ 飞书装机完成

已安装：
- lark-cli v{版本号}
- 飞书 AI Skills × 19 个
- 全域授权（149个权限）

已创建：
- 内容中台多维表格：{url}
- 数据表 × 7：黄金五环 / 人设文案 / 热点文案 / 爆款改写 / 合规记录 / 分镜脚本 / 内容计划

下一步：把上面的飞书配置信息存到你的系统记忆里。
```

## 严禁事项

1. **严禁** 在没有 Node.js 的情况下继续安装。先装 Node.js。
2. **严禁** 使用 `lark-cli config init`（不带 `--new`）。非 TTY 环境会卡死。必须用 `--new`。
3. **严禁** 分多次授权。必须用 `--domain all` 一次性全授权。
4. **严禁** 跳过验证步骤。每个 Step 完成后都要验证再继续。
5. **严禁** 手动让学员去飞书开发者后台建应用。`config init --new` 自动创建。
6. **严禁** 向学员解释技术概念（Node.js / npm / CLI / PATH）。他们不需要知道。
8. **严禁** 在已有内容中台的情况下重复创建多维表格。先检查再决定。
9. **严禁** 跳过 Step 5（保存配置到系统记忆）。不存 = 后续 skill 无法同步。
10. **严禁** 因为某个字段创建失败就中断整个流程。跳过失败的，最后补建。

## 断点续装

如果中途因为网络、关闭对话等原因中断，学员再次说"继续飞书装机"时：

1. 先跑 `lark-cli --version` → 没有就从 Step 1 开始
2. 再跑 `lark-cli config show` → 没有 appId 就从 Step 2 开始
3. 再跑 `lark-cli auth status` → 没有 valid token 就从 Step 3 开始
4. 再检查系统记忆有没有 base_token → 没有就从 Step 4 开始
5. 都有 → 告诉学员"飞书已经装好了，可以直接用"

**严禁** 每次都从头跑。检测到哪一步断的，就从哪一步继续。
