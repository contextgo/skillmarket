#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频下载脚本
用法: python download_video.py <视频URL> [输出路径]
"""

import os
import sys
import requests
import argparse


def download_video(url, save_path, chunk_size=8192):
    """下载视频到指定路径"""
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    print(f"正在下载: {url}")
    print(f"保存至: {save_path}")
    
    response = requests.get(url, headers=headers, stream=True, timeout=30)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    print(f"文件大小: {total_size / 1024 / 1024:.2f} MB")
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    downloaded = 0
    with open(save_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=chunk_size):
            if chunk:
                f.write(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    progress = downloaded / total_size * 100
                    print(f"\r下载进度: {progress:.1f}%", end="", flush=True)
    
    print(f"\n下载完成! {save_path}")
    return save_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="下载视频文件")
    parser.add_argument("url", help="视频URL")
    parser.add_argument("-o", "--output", default="video_frames/source_video.mp4", help="输出路径")
    
    args = parser.parse_args()
    
    try:
        download_video(args.url, args.output)
    except Exception as e:
        print(f"下载失败: {e}")
        sys.exit(1)