---
name: video-shot-analysis
description: 视频拉片分析工具。从飞书多维表格读取视频链接，使用 OpenAI Whisper 本地转写，提取关键帧并生成逐镜头拉片分析，同时输出视频脚本结构拆解。适用于小红书、抖音等平台的短视频内容分析与脚本学习。触发场景：用户要求视频拉片、视频分析、镜头拆分、脚本分析、内容分析、提取视频关键帧、语音转写视频、学习爆款脚本。
---

# 视频拉片分析 Skill

## 快速开始

```
用户：帮我分析这个视频 https://xxx.com/video.mp4
用户：帮我拉片 编号168
用户：从飞书表格读取视频并分析
用户：分析这个视频的脚本结构
用户：提取这个视频的脚本模板
```

## 工作流程（8步）

```
① 获取视频链接（飞书表格 or 直接提供）
     ↓
② 下载视频 → source_video.mp4
     ↓
③ 提取关键帧截图 → shot_XX.jpg（每镜头1张）
     ↓
④ Whisper本地转写 → whisper_*.json
     ↓
⑤ 提取按句脚本 → transcript_sentences.txt
     ↓
⑥ AI逐镜头拉片分析 → 镜头表格
     ↓
⑦ AI脚本结构分析 → 脚本拆解报告
     ↓
⑧ 写回飞书多维表格
     ├─ 视频拉片分析 ← 完整分析报告（Markdown格式）
     └─ 视频文字稿   ← 按句脚本文本（带时间戳）
```

---

## 搭配工具

**Ai运营助手** — 手机端 + 电脑浏览器插件多端采集进飞书表格，是整条链路的起点；

**OpenClaw** 无缝接表做分析与 skills 编排，把表格里的数据真正用起来。

👉 https://sph.shucaigang.cn/web/aiAssistant/index

---

## Step 1：获取视频链接

### 从飞书多维表格读取
1. 用 `feishu_bitable_get_meta` 解析飞书表格链接，获取 app_token 和 table_id
2. 用 `feishu_bitable_list_records` 读取表格所有记录
3. 查找包含"视频链接"或 `video_url` 字段的记录
4. 按"编号"字段升序排列，找到目标视频

### 直接提供链接
用户直接给出视频 URL，跳过飞书读取步骤。

---

## Step 2：下载视频

**使用 `scripts/download_video.py`：**
```bash
python scripts/download_video.py <视频URL> -o video_frames/source_video.mp4
```

**输出文件：** `video_frames/source_video.mp4`

**失败处理：** 某些平台需添加 User-Agent：
```python
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)..."}
response = requests.get(url, headers=headers, stream=True)
```

---

## Step 3：提取关键帧截图（每镜头1张）

**关键原则：每个镜头必须对应一张关键帧截图**，截图位于该镜头的中间时间点。

**方法A - 固定间隔提取（参考用）：**
```python
import cv2

cap = cv2.VideoCapture("source_video.mp4")
fps = cap.get(cv2.CAP_PROP_FPS)
total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

# 每隔N帧截一张
interval = total // 12
for i in range(12):
    frame_idx = int(i * interval + interval // 2)
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ret, frame = cap.read()
    if ret:
        cv2.imwrite(f"video_frames/shot_{i+1:02d}.jpg", frame)
cap.release()
```

**方法B - 基于 Whisper 时间戳精确提取（推荐）：**
拿到 Whisper 转写结果后，按镜头时间段，在每个镜头中间时间点截取一帧。

**输出文件：** `video_frames/shot_01.jpg` ~ `shot_XX.jpg`

---

## Step 4：Whisper 本地转写

**前置条件：**
```bash
pip install openai-whisper==20250625
pip install imageio-ffmpeg==0.5.1   # Windows ffmpeg
```

**转写脚本：**
```python
import whisper

def transcribe(video_path, model_name="base"):
    model = whisper.load_model(model_name)
    result = model.transcribe(video_path, language="zh")
    with open("whisper_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result
```

**注意：**
- 控制台输出可能有 GBK 编码乱码，JSON 文件内容正确
- base 模型约2分钟完成8分钟视频，small 更准但更慢
- 转写结果含多个片段，每个片段有 start/end/text

**转写结果结构：**
```json
{
  "segments": [
    {"start": 0.0, "end": 3.2, "text": "今年1月1号我在这个账号上发了我的第一条视频"},
    {"start": 3.2, "end": 5.1, "text": "到今天刚好4个月时间"},
    ...
  ]
}
```

**重要说明：** Whisper 输出的 `segments` 数组中，每个元素就是一个自然的断句单位，可直接用于生成按句划分的脚本文本。

---

## Step 4.5：提取按句划分的脚本文本（可选但推荐）

**从 Whisper segments 提取带时间戳的句子：**

```python
import json

# 读取转写结果
with open("whisper_result.json", "r", encoding="utf-8") as f:
    data = json.load(f)

segments = data["segments"]

# 生成按句划分的文本
result = []
for seg in segments:
    text = seg["text"].strip()
    start = seg["start"]
    end = seg["end"]
    if text:
        result.append({
            "text": text,
            "start": start,
            "end": end
        })

# 保存为可读格式
with open("transcript_sentences.txt", "w", encoding="utf-8") as f:
    f.write(f"视频脚本文本（按句划分）\n")
    f.write(f"共 {len(result)} 个句子\n")
    f.write(f"时长: {segments[-1]['end']:.1f}秒\n\n")
    f.write("=" * 60 + "\n\n")
    
    for i, s in enumerate(result, 1):
        start_time = f"{int(s['start']//60):02d}:{int(s['start']%60):02d}"
        end_time = f"{int(s['end']//60):02d}:{int(s['end']%60):02d}"
        f.write(f"{i:3d}. [{start_time}-{end_time}] {s['text']}\n")

print(f"共 {len(result)} 个句子")
```

**输出示例：**
```
视频脚本文本（按句划分）
共 82 个句子
时长: 148.4秒

============================================================

  1. [00:00-00:03] 今年1月1号我在这个账号上发了我的第一条视频
  2. [00:03-00:05] 到今天刚好4个月时间
  3. [00:05-00:09] 我一个人没有团队全网长了45万粉丝
  ...
```

**用途：** 作为分析报告附录，方便用户对照视频内容逐句学习。

---

## Step 5：AI 逐镜头拉片分析

### 镜头数量

**镜头数量不固定**，取决于视频实际内容、时长和叙事复杂度。短视频（<3分钟）可能只有5-8个镜头，长视频或高密度内容可能需要15-20个镜头。

**判断标准：**
- 每个镜头应有独立的叙事功能（钩子/论证/转折等）
- 镜头时长通常15秒-90秒不等
- 相邻镜头之间应有叙事功能变化
- 总镜头数 = 视频总时长 ÷ 平均镜头时长（建议40-60秒/镜头）

### 输出字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 镜头编号 | 文本 | 01, 02, 03... |
| 时间段 | 文本 | 精确到秒，如 `00:00-00:25` |
| 时长(秒) | 数字 | 每个镜头持续秒数 |
| 景别 | 单选 | 中景/中近景/特写/全景等 |
| 概述 | 文本 | 该镜头的核心内容（1-2句） |
| 叙事作用 | 文本 | 在全片叙事中的功能描述 |
| 作用标签 | 多选 | 🪝钩子/📐铺垫/📊论证/💥转折/🔄反转/💬故事/🐟类比/🔑核心/😱冲击/🌟升华 |
| 截图 | 附件 | shot_XX.jpg 关键帧图片 |

### 输出模板

```
# 🎬 镜头一览（共N个）

| # | 时间 | 标签 | 概述 |
|---|------|------|------|
| 01 | 00:00-00:25 | 🪝 钩子 | ... |
| 02 | 00:25-00:49 | 📐 铺垫 | ... |
...
```

---

## Step 6：AI 脚本结构分析（新增）

### 分析维度

基于 Whisper 转写文本，从以下维度拆解视频脚本：

| 维度 | 说明 | 输出内容 |
|------|------|----------|
| **结构拆解** | 脚本的整体框架 | 开头钩子 → 中间论证 → 结尾升华 |
| **钩子分析** | 开头3秒如何抓住注意力 | 设问/数字/反常识/痛点/悬念 |
| **论证技巧** | 中间如何说服观众 | 数据/案例/类比/对比/权威背书 |
| **金句提炼** | 可复用的表达模板 | 原句 + 模板化改写 |
| **情绪曲线** | 全片情绪起伏 | 低开/高走/反转/升华的节奏 |
| **互动设计** | 如何引导点赞/评论/收藏 | 埋点时机 + 话术设计 |
| **结尾设计** | 如何收尾并引导行动 | 升华金句/下期预告/互动请求 |

### 输出格式

```markdown
# 📝 视频脚本分析报告

## 一、脚本结构总览

【总时长】X分X秒，X个段落

| 段落 | 时间 | 功能 | 核心内容 |
|------|------|------|----------|
| 开场钩子 | 00:00-00:22 | 抓注意力 | ... |
| 核心论证 | 00:22-03:30 | 说服观众 | ... |
| 升华收尾 | 03:30-04:56 | 引导行动 | ... |

## 二、开头钩子拆解

**钩子类型：** [设问/数字冲击/反常识/痛点定位/悬念预告]

**原文：**
> （开头前3秒的原话）

**钩子技巧分析：**
1. ...
2. ...

**可复用模板：**
```
[钩子模板]
你有没有发现，[现象]？
其实这是一个很大的误解。
[核心观点]。
```

## 三、论证技巧拆解

### 3.1 论证结构
- 论点1：... → 论据：...
- 论点2：... → 论据：...
- 论点3：... → 论据：...

### 3.2 使用的说服技巧
| 技巧 | 原文示例 | 作用 |
|------|----------|------|
| 数字量化 | "10万到100万" | 具体可衡量 |
| 案例论证 | ... | 增强可信度 |
| 类比说明 | ... | 降低理解门槛 |
| 对比反差 | ... | 制造冲击 |

### 3.3 转折与节奏
- 转折点1（XX秒）：... → 作用：...
- 转折点2（XX秒）：... → 作用：...

## 四、金句提炼

| 金句原文 | 适用场景 | 模板化改写 |
|----------|----------|------------|
| "放下面子不是失去尊严，而是..." | 人生感悟类 | [X]不是[Y]，而是[Z] |
| "当你开始[X]的时候，你就开始赢了" | 励志类 | 当你开始[X]的时候，你就开始[Y] |

## 五、情绪曲线

```
情绪强度
  ↑
高 │     ╭──╮        ╭────╮
   │    ╱    ╲      ╱      ╲
中 │───╯      ╲────╯        ╲───
   │
低 │
   └────────────────────────────→ 时间
     开头   论证   转折   升华
```

**节奏分析：**
- 开头：[低开/高开] → 作用：...
- 中间：[平缓/起伏] → 作用：...
- 结尾：[升华/悬念] → 作用：...

## 六、互动设计分析

| 互动点 | 时间 | 话术 | 目的 |
|--------|------|------|------|
| 点赞引导 | XX秒 | "点赞收藏看完" | 提高互动率 |
| 评论引导 | XX秒 | "评论一下，下条继续" | 增加评论数 |
| 关注引导 | XX秒 | ... | 提高粉丝粘性 |

## 七、结尾设计

**结尾类型：** [升华金句/下期预告/互动请求/行动号召]

**原文：**
> （结尾原话）

**结尾技巧：**
1. ...
2. ...

**可复用模板：**
```
所以我想说，[核心观点]。
当你开始[X]的时候，你就会发现，[改变]。
```

## 八、脚本复用模板

基于本视频，提取可复用的脚本框架：

```markdown
【脚本模板：XXX类型视频】

## 开头（X秒）
[钩子类型]：[模板]
- 示例："你有没有发现..."

## 中间（X秒）
[论证结构]
1. 论点1 + 论据
2. 论点2 + 论据
3. 转折/深化

## 结尾（X秒）
[结尾类型]：[模板]
- 示例："所以我想说..."
```

## 九、一句话总结

[用一句话概括这个脚本的核心打法]
```

### AI 分析提示词

```
你是一个专业的短视频脚本分析师。请基于以下 Whisper 转写文本，进行深度的脚本结构分析：

【转写文本】
{whisper_text}

请从以下维度进行分析：
1. 脚本结构：开头钩子、中间论证、结尾升华的时间分配和功能
2. 钩子技巧：开头3秒如何抓住注意力，属于哪种钩子类型
3. 论证方法：使用了哪些说服技巧（数据、案例、类比、对比等）
4. 金句提炼：提取3-5句可复用的金句，并模板化
5. 情绪曲线：全片的情绪起伏和节奏设计
6. 互动设计：埋了哪些互动点，时机和话术是什么
7. 结尾设计：如何收尾，属于哪种结尾类型
8. 脚本模板：基于本视频，提炼一个可复用的脚本框架

输出格式参考上述"视频脚本分析报告"模板。
```

---

## Step 7：写入飞书多维表格

### ⚠️ 重要：必须写入两个字段

分析完成后，**必须同时写入两个字段到飞书表格**：
1. **视频拉片分析** — 完整分析报告（Markdown格式）
2. **视频文字稿** — 按句脚本文本（带时间戳）

### 字段说明

| 字段名 | 字段ID | 内容 | 类型 | 必填 |
|--------|--------|------|------|------|
| 视频拉片分析 | fldndYgps5 | 完整分析报告 | Text | ✅ 必填 |
| 视频文字稿 | fld3cZ9eom | 按句脚本文本 | Text | ✅ 必填 |
| 视频脚本分析 | - | 脚本结构拆解 | Text | 可选 |
| 关键帧截图 | - | 镜头截图 | Attachment | 暂不支持 |

### 写入方式（使用 feishu-bitable MCP 工具）

**Step 7.1：构建视频拉片分析内容**

从本地文件读取或直接构建完整的Markdown分析报告：
```python
# 方式1：从本地文件读取
with open("视频拉片分析报告_270_20260427.md", "r", encoding="utf-8") as f:
    analysis_content = f.read()

# 方式2：直接构建
analysis_content = """# 🎬 拉片分析报告：编号XXX《标题》

## 📋 基础信息
...

## 🔍 结构总览
...

## 🎯 核心方法论
...

## 💡 金句提炼
...

## 📊 内容特点
...
"""
```

**Step 7.2：构建视频文字稿内容**

从 Whisper segments 提取按句划分的脚本文本：
```python
import json

# 读取 Whisper 转写结果
with open("whisper_result.json", "r", encoding="utf-8") as f:
    data = json.load(f)

segments = data["segments"]

# 构建按句脚本文本
transcript_lines = []
for i, seg in enumerate(segments, 1):
    start = seg["start"]
    end = seg["end"]
    text = seg["text"].strip()
    if text:
        transcript_lines.append(f"{i:3d}. [{start:05.2f}-{end:05.2f}] {text}")

transcript_content = "\n".join(transcript_lines)
```

**Step 7.3：调用 feishu_bitable_update_record 写入两个字段**

```python
# 使用 feishu-bitable MCP 工具
feishu_bitable_update_record(
    app_token="Z4vpbRLXQaEsEPs0IREcCkTZnee",
    table_id="tblGMUNmoqh8c3Cr",
    record_id="recvhYHZTqS6qO",  # 从 Step 1 获取
    fields={
        "视频拉片分析": analysis_content,
        "视频文字稿": transcript_content
    }
)
```

**完整示例（编号270）：**
```python
# 读取本地文件
with open("视频拉片分析报告_270_20260427.md", "r", encoding="utf-8") as f:
    analysis = f.read()

with open("transcript_270_sentences.txt", "r", encoding="utf-8") as f:
    transcript = f.read()

# 写入飞书
feishu_bitable_update_record(
    app_token="Z4vpbRLXQaEsEPs0IREcCkTZnee",
    table_id="tblGMUNmoqh8c3Cr",
    record_id="recvhYHZTqS6qO",
    fields={
        "视频拉片分析": analysis,
        "视频文字稿": transcript
    }
)
```

### ⚠️ 注意事项

1. **必须写入两个字段**：
   - `视频拉片分析`：完整分析报告（Markdown格式）
   - `视频文字稿`：按句划分的脚本文本（纯文本格式，带时间戳）
   - ⚠️ **两个字段都必须写入，不能只写一个**

2. **飞书 AI 字段**（type_25）**不可通过 API 写入**，需使用普通文本字段
   - 目标字段 `视频拉片分析` 是 Text 类型（field_id: fldndYgps5）
   - 目标字段 `视频文字稿` 是 Text 类型（field_id: fld3cZ9eom）

3. **视频文字稿格式要求**：
   ```
     1. [00.00-02.36] 哈喽哈喽欢迎回到给女孩的商业第一课
     2. [02.36-04.88] 今天我们终于把我们的赛围老师
     3. [04.88-07.48] 请凡场了 给她一点掌声
   ```
   - 时间格式：`[开始秒.毫秒-结束秒.毫秒]`
   - 每句一行，序号右对齐

4. **附件字段**暂不支持，需手动上传截图

5. **写入成功验证**：
   - 使用 `feishu_bitable_get_record` 验证字段已更新
   - 检查返回的 `fields` 中是否包含两个字段的内容

---

## 常见问题

### Q: Whisper 安装失败
A:
```bash
pip install imageio-ffmpeg==0.5.1
# 将 ffmpeg.exe 复制到 Python Scripts 目录
```

### Q: 视频下载失败
A: 某些平台需添加 headers，或尝试浏览器工具下载。

### Q: 飞书表格字段不存在
A: 先用 `feishu_bitable_list_fields` 查看现有字段。type_25 AI 字段不可写，需新建普通文本字段。

### Q: 关键帧截取时间不准确
A: 以 Whisper 转写时间戳为基准，在镜头中间时间点截取。

### Q: 脚本分析太长怎么办
A: 可分段输出，或只输出核心维度（钩子/论证/金句/模板）。

---

## 输出文件清单（本地留存）

| 文件 | 说明 |
|------|------|
| `video_frames/source_video.mp4` | 原始视频 |
| `video_frames/shot_01.jpg` ~ `shot_XX.jpg` | 关键帧截图 |
| `whisper_*.json` | Whisper 转写结果（原始JSON） |
| `视频拉片分析报告_*.md` | 完整分析报告（Markdown格式） |
| `task-summary_YYYYMMDD_*.md` | 任务摘要 |

## 输出内容清单（写入飞书）

| 字段名 | 内容 | 格式说明 |
|--------|------|----------|
| **视频拉片分析** | 完整分析报告 | Markdown格式，包含基础信息、结构总览、分段详解、金句提炼、内容特点 |
| **视频文字稿** | 按句脚本文本 | 纯文本格式，每句含时间戳（序号. [开始-结束] 文本） |
| 视频脚本分析（可选） | 脚本结构拆解 | 9大维度分析，仅用户明确要求时写入 |

### 写入飞书示例

**视频拉片分析字段：**
```markdown
# 🎬 拉片分析报告：编号266《如何在感情里，持续制造吸引力》

## 📋 基础信息
| 维度 | 数据 |
|------|------|
| **时长** | 4分31秒（270.8秒） |
| **转写片段** | 128个 |
| **字数** | 约1430字 |

## 🔍 结构总览（5段落）
开场定义(35秒) → 生理吸引解析(30秒) → 情绪吸引定义(23秒) → 四大方法(157秒) → 升华收尾(26秒)

## 🎯 核心方法论
...

## 💡 金句提炼
...

## 📊 内容特点
...
```

**视频文字稿字段：**
```
  1. [00:00-00:05] 你有没有发现，那些真正厉害的人，从来都不在乎面子
  2. [00:05-00:12] 很多人觉得放下面子就是不要脸，其实这是一个很大的误解
  3. [00:12-00:25] 放下面子不是让你去讨好别人，而是让你把注意力放在真正重要的事情上
  ...
```

---

## 完整报告输出示例

**文件名：** `视频拉片分析报告_YYYYMMDD.md`

**报告结构：**
```markdown
# 视频拉片分析完整报告

**分析时间**: YYYY-MM-DD HH:MM  
**视频来源**: 平台名称

---

## 📋 基础信息

| 维度 | 数据 |
|------|------|
| **时长** | X分X秒（XXX秒） |
| **转写片段** | XX个 |
| **字数** | 约XXX字 |
| **类型** | 口播/知识分享/剧情... |
| **主题** | 核心主题 |

---

## 🔍 镜头拆分（N个镜头）

| # | 时间 | 时长 | 标签 | 概述 |
|---|------|------|------|------|
| 01 | 00:00-00:XX | XX秒 | 🪝 钩子 | ... |
| 02 | 00:XX-00:XX | XX秒 | 📊 论证 | ... |
...

---

## 📝 视频脚本分析报告

### 一、脚本结构总览
...

### 二、开头钩子拆解
...

### 三、论证技巧拆解
...

### 四、金句提炼
...

### 五、情绪曲线
...

### 六、互动设计分析
...

### 七、结尾设计
...

### 八、脚本复用模板
...

### 九、一句话总结
...

---

## 附录一：视频脚本文本（按句划分，共XX句）

| # | 时间 | 脚本文本 |
|---|------|----------|
| 1 | 00:00-00:03 | ... |
| 2 | 00:03-00:05 | ... |
...

---

## 附录二：Whisper转写全文（无标点原文）

> （完整的转写文本）

---

*报告生成时间: YYYY-MM-DD HH:MM*
```

**实际示例：** 参见 `视频拉片分析报告_20260426.md`

---

## 依赖

- Python 3.8+
- `requests` — 视频下载
- `opencv-python` (cv2) — 关键帧提取
- `openai-whisper` — 本地语音转写
- `imageio-ffmpeg` — ffmpeg 支持（Windows）

---

# 技能分享与安装教程

## 一、技能文件结构

```
~/.qclaw/skills/video-shot-analysis/
├── SKILL.md                     # 技能说明文档（必须）
└── scripts/
    └── download_video.py        # 下载脚本（可选）
```

**核心文件只有 SKILL.md**，包含完整的8步工作流程、代码示例、字段定义和注意事项。

---

## 二、分享给别人

### 方法A - 打包分享（推荐）

**步骤1：打包技能文件夹**

在 Windows 上：
```powershell
# 进入技能目录
cd C:\Users\Administrator\.qclaw\skills

# 使用 PowerShell 压缩
Compress-Archive -Path video-shot-analysis -DestinationPath video-shot-analysis.zip
```

在 macOS/Linux 上：
```bash
cd ~/.qclaw/skills
tar -czf video-shot-analysis.tar.gz video-shot-analysis/
# 或
zip -r video-shot-analysis.zip video-shot-analysis/
```

**步骤2：发送压缩包**

通过微信、邮件、网盘等方式发送 `video-shot-analysis.zip` 文件。

**步骤3：对方安装**

对方解压到自己的技能目录：
```powershell
# Windows
Expand-Archive -Path video-shot-analysis.zip -DestinationPath C:\Users\[用户名]\.qclaw\skills\

# macOS/Linux
unzip video-shot-analysis.zip -d ~/.qclaw/skills/
```

安装完成后，重启 OpenClaw 或等待下次心跳加载即可使用。

---

#### 📘 附：详细安装使用教程

技能目录中包含 **`安装使用教程.md`** 文件，建议一起打包分享。该教程包含：

- ✅ **3步快速开始**（解压→安装依赖→重启）
- ✅ **Python 依赖安装方法**（含国内镜像加速）
- ✅ **安装成功验证**（测试命令）
- ✅ **使用方法示例**（4种场景）
- ✅ **输出内容说明**（5种输出文件）
- ✅ **常见问题解答**（Q1-Q5，含解决方案）
- ✅ **高级配置**（Whisper模型选择、飞书写入）

**打包时包含教程文件：**
```
video-shot-analysis/
├── SKILL.md              # 技能核心文档
├── 安装使用教程.md        # 给接收方的详细教程 ← 新增
└── scripts/
    └── download_video.py
```

**对方收到后，按教程操作即可：**
1. 打开 `安装使用教程.md`
2. 按照"快速开始"3步操作
3. 遇到问题查看"常见问题"章节

---

---

### 方法B - GitHub 托管

**步骤1：创建 GitHub 仓库**

```bash
# 在 GitHub 上创建新仓库 video-shot-analysis
# 克隆到本地
git clone https://github.com/[你的用户名]/video-shot-analysis.git
cd video-shot-analysis
```

**步骤2：添加技能文件**

```bash
# 复制 SKILL.md 到仓库
cp ~/.qclaw/skills/video-shot-analysis/SKILL.md .

# 提交
git add .
git commit -m "Add video-shot-analysis skill"
git push
```

**步骤3：分享安装链接**

对方通过以下方式安装：
```bash
# 方法1：克隆到技能目录
git clone https://github.com/[你的用户名]/video-shot-analysis.git ~/.qclaw/skills/video-shot-analysis

# 方法2：下载 ZIP 解压
# 访问 https://github.com/[你的用户名]/video-shot-analysis
# 点击 Code → Download ZIP → 解压到 ~/.qclaw/skills/video-shot-analysis/
```

---

### 方法C - 提交到 SkillHub（官方索引）

**前提：** 需要联系 OpenClaw 官方团队提交技能审核。

**流程：**
1. 确保技能经过充分测试
2. 准备技能说明文档
3. 联系 OpenClaw 官方（通过社区、Issue 或邮件）
4. 等待审核通过后，技能将出现在 `skillhub search` 结果中

**审核通过后，用户可以直接安装：**
```bash
skillhub install video-shot-analysis
```

---

## 三、安装后的使用方式

### 自动触发（推荐）

技能安装后会自动被 OpenClaw 加载，用户只需自然对话即可触发：

```
用户：帮我分析这个视频 https://xxx.com/video.mp4
用户：帮我拉片 编号168
用户：分析这个视频的脚本结构
用户：提取这个视频的关键帧
```

OpenClaw 会根据 SKILL.md 里的 `description` 字段自动识别意图并执行。

### 手动指定

```
用户：请使用 video-shot-analysis 技能分析这个视频
```

---

## 四、使用前准备（环境依赖）

**接收方需要先安装以下依赖：**

```bash
# Python 依赖
pip install openai-whisper==20250625
pip install opencv-python==2.32.4
pip install requests==2.32.4
pip install imageio-ffmpeg==0.5.1  # Windows 用户
```

**验证安装：**
```python
import whisper
import cv2
print("✅ 环境就绪")
```

---

## 五、分享建议

为了让接收方更容易上手，建议在分享时附带以下说明：

```markdown
# video-shot-analysis 技能使用说明

## 安装步骤
1. 解压 video-shot-analysis.zip 到 ~/.qclaw/skills/
2. 安装依赖：pip install openai-whisper==20250625 opencv-python==2.32.4 requests==2.32.4 imageio-ffmpeg==0.5.1
3. 重启 OpenClaw 或等待下次心跳

## 使用方法
- "帮我分析这个视频 [链接]"
- "从飞书表格读取视频并分析"
- "提取这个视频的脚本模板"

## 输出内容
- 镜头拆分表格
- 脚本结构分析报告
- 按句划分的脚本文本（带时间戳）
```

---

## 六、技能更新

如果技能有更新，接收方只需覆盖 SKILL.md 文件即可：

```bash
# 下载新版本 SKILL.md
# 覆盖旧文件
cp 新SKILL.md ~/.qclaw/skills/video-shot-analysis/SKILL.md
```

OpenClaw 下次加载时会自动使用新版本。
