#!/usr/bin/env python3
"""
阿里百炼视频转文案 Skill

将本地视频文件的语音提取并转换为文字文案。

工作流程：
1. 使用 ffmpeg 从视频提取音频
2. 上传到阿里云 OSS（临时存储）
3. 调用阿里百炼 Paraformer-v2 语音识别 API 转写
4. 返回文案文本
"""
import sys
import json
import os
import time
import subprocess
import tempfile
import uuid
import requests
from pathlib import Path
from typing import Optional, Dict, List

# ============ 配置 ============
import os
import sys

# 添加 ffmpeg 路径（Windows winget 安装）
FFMPEG_PATH = r"C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1-full_build\bin"
if os.path.exists(FFMPEG_PATH) and FFMPEG_PATH not in os.environ.get("PATH", ""):
    os.environ["PATH"] = FFMPEG_PATH + os.pathsep + os.environ.get("PATH", "")

# 加载 .env 文件
ENV_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
if os.path.exists(ENV_FILE):
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ[key.strip()] = value.strip()

# 阿里云 OSS 配置
ALIYUN_ACCESS_KEY_ID = os.getenv("ALIYUN_ACCESS_KEY_ID", "")
ALIYUN_ACCESS_KEY_SECRET = os.getenv("ALIYUN_ACCESS_KEY_SECRET", "")
ALIYUN_OSS_BUCKET = os.getenv("ALIYUN_OSS_BUCKET", "")
ALIYUN_OSS_ENDPOINT = os.getenv("ALIYUN_OSS_ENDPOINT", "oss-cn-beijing.aliyuncs.com")

# 阿里百炼 DashScope 配置
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")

# 轮询配置
POLL_INTERVAL = 3  # 秒
MAX_POLL_COUNT = 200  # 最大轮询次数

# 支持的视频格式
VIDEO_FORMATS = {"mp4", "avi", "mov", "mkv", "flv", "wmv"}


def check_ffmpeg() -> bool:
    """检查 ffmpeg 是否可用"""
    # ffmpeg 路径
    ffmpeg_path = os.path.join(
        os.environ.get("LOCALAPPDATA", r"C:\Users\Administrator\AppData\Local"),
        "Microsoft", "WinGet", "Packages",
        "Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe",
        "ffmpeg-8.1-full_build", "bin", "ffmpeg.exe"
    )
    
    # 先检查默认路径
    if os.path.exists(ffmpeg_path):
        return True
    
    # 再检查系统 PATH
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def get_file_type(file_path: str) -> str:
    """从文件路径获取文件类型"""
    return Path(file_path).suffix.lower().lstrip(".")


def extract_audio(video_path: str, output_path: str) -> bool:
    """使用 ffmpeg 从视频提取音频"""
    # ffmpeg 路径
    ffmpeg_path = os.path.join(
        os.environ.get("LOCALAPPDATA", r"C:\Users\Administrator\AppData\Local"),
        "Microsoft", "WinGet", "Packages",
        "Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe",
        "ffmpeg-8.1-full_build", "bin", "ffmpeg.exe"
    )
    if not os.path.exists(ffmpeg_path):
        ffmpeg_path = "ffmpeg"  # 回退到系统 PATH
    
    try:
        # 使用 ffmpeg 提取音频，转换为 mp3 格式
        result = subprocess.run(
            [
                ffmpeg_path, "-y",  # 覆盖输出文件
                "-i", video_path,  # 输入文件
                "-vn",  # 禁用视频
                "-acodec", "libmp3lame",  # 使用 mp3 编码
                "-q:a", "2",  # 音频质量
                output_path  # 输出文件
            ],
            capture_output=True,
            text=True,
            timeout=300  # 5分钟超时
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        print(f"[ERROR] 提取音频超时: {video_path}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[ERROR] 提取音频失败: {e}", file=sys.stderr)
        return False


def upload_to_oss(file_path: str, object_name: str) -> Optional[str]:
    """上传文件到阿里云 OSS，返回公开访问 URL"""
    if not all([ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET, ALIYUN_OSS_BUCKET]):
        print("[ERROR] OSS 凭证未配置", file=sys.stderr)
        return None

    try:
        # 简单实现：使用 OSS HTTP API 上传
        import base64
        import hmac
        import hashlib
        from datetime import datetime

        # 读取文件内容
        with open(file_path, "rb") as f:
            file_content = f.read()

        # 生成签名 URL（简化版：使用 OSS 的公共读 bucket）
        # 实际生产环境建议使用 ossutil 或 oss2 库
        bucket_name = ALIYUN_OSS_BUCKET
        endpoint = ALIYUN_OSS_ENDPOINT
        
        # 使用阿里云 OSS 的简单上传方式
        # 这里使用 requests 直接上传
        url = f"https://{bucket_name}.{endpoint}/{object_name}"
        
        # 计算签名（使用阿里云 OSS API）
        from datetime import datetime, timezone, timedelta
        
        # 设置请求头
        date_gmt = datetime.now(timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')
        content_type = "audio/mpeg"
        
        # 构造签名字符串
        string_to_sign = f"PUT\n\n{content_type}\n{date_gmt}\n/{bucket_name}/{object_name}"
        
        # 计算 HMAC-SHA1 签名
        import hmac
        import base64
        signature = base64.b64encode(
            hmac.new(
                ALIYUN_ACCESS_KEY_SECRET.encode(),
                string_to_sign.encode(),
                hashlib.sha1
            ).digest()
        ).decode()
        
        # 构造 Authorization 头
        auth = f"OSS {ALIYUN_ACCESS_KEY_ID}:{signature}"
        
        headers = {
            "Content-Type": content_type,
            "Date": date_gmt,
            "Authorization": auth
        }
        
        # 上传文件
        response = requests.put(url, data=file_content, headers=headers)
        
        if response.status_code in [200, 201]:
            # 返回公开访问 URL（需要 bucket 设置为公共读）
            # 如果 bucket 不是公共读，需要使用签名 URL
            public_url = f"https://{bucket_name}.{endpoint}/{object_name}"
            print(f"[INFO] 上传成功: {public_url}", file=sys.stderr)
            return public_url
        else:
            print(f"[ERROR] OSS 上传失败: {response.status_code} {response.text}", file=sys.stderr)
            return None
            
    except Exception as e:
        print(f"[ERROR] OSS 上传异常: {e}", file=sys.stderr)
        return None


def upload_to_oss_simple(file_path: str, object_name: str) -> Optional[str]:
    """简化版 OSS 上传（使用签名URL方式 - 更安全）"""
    try:
        import oss2
        
        # 使用 oss2 库
        auth = oss2.Auth(ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET)
        bucket = oss2.Bucket(auth, ALIYUN_OSS_ENDPOINT, ALIYUN_OSS_BUCKET)
        
        # 上传文件（私有文件）
        with open(file_path, 'rb') as f:
            bucket.put_object(object_name, f)
        
        # 生成签名URL（有效期1小时），用于阿里百炼访问
        # 这个URL是临时的，1小时后过期
        signed_url = bucket.sign_url('GET', object_name, 3600)
        
        print(f"[INFO] 上传成功: {signed_url[:80]}...", file=sys.stderr)
        return signed_url
        
    except ImportError:
        print("[ERROR] 请安装 oss2 库: pip install oss2", file=sys.stderr)
        return None
    except Exception as e:
        print(f"[ERROR] OSS 上传失败: {e}", file=sys.stderr)
        return None


def create_transcription_task(audio_url: str) -> Optional[str]:
    """创建阿里百炼转写任务，返回 task_id"""
    if not DASHSCOPE_API_KEY:
        print("[ERROR] DASHSCOPE_API_KEY 未配置", file=sys.stderr)
        return None

    try:
        import dashscope
        from dashscope import Transcription
        
        dashscope.api_key = DASHSCOPE_API_KEY
        
        # 创建转写任务
        response = Transcription.call(
            model='paraformer-v2',
            file_urls=[audio_url],
            language_hints=['zh']
        )
        
        if response.status_code == 200:
            task_id = response.output.task_id
            print(f"[INFO] 转写任务创建成功: {task_id}", file=sys.stderr)
            return task_id
        else:
            print(f"[ERROR] 转写任务创建失败: {response.code} {response.message}", file=sys.stderr)
            return None
            
    except ImportError:
        print("[ERROR] 请安装 dashscope 库: pip install dashscope", file=sys.stderr)
        return None
    except Exception as e:
        print(f"[ERROR] 转写任务创建异常: {e}", file=sys.stderr)
        return None


def query_transcription(task_id: str) -> Optional[Dict]:
    """查询转写任务状态和结果"""
    try:
        import dashscope
        from dashscope import Transcription
        
        dashscope.api_key = DASHSCOPE_API_KEY
        
        # 查询任务（使用 fetch 方法）
        response = Transcription.fetch(task_id)
        
        if response.status_code == 200:
            result = response.output
            status = result.get('task_status')
            
            if status == 'SUCCEEDED':
                # 获取转写结果URL
                results = result.get('results', [{}])
                if results:
                    transcription_url = results[0].get('transcription_url', '')
                    if transcription_url:
                        # 下载转写结果
                        import requests
                        resp = requests.get(transcription_url)
                        if resp.status_code == 200:
                            transcription_data = resp.json()
                            # 解析转写文本 - 新版API格式
                            texts = []
                            transcripts = transcription_data.get('transcripts', [])
                            for transcript in transcripts:
                                text = transcript.get('text', '')
                                if text:
                                    texts.append(text)
                            
                            full_text = '\n'.join(texts)
                            
                            # 获取音频时长
                            properties = transcription_data.get('properties', {})
                            duration = properties.get('original_duration_in_milliseconds', 0)
                            
                            return {
                                'status': 'completed',
                                'text': full_text,
                                'duration': duration
                            }
                
                return {
                    'status': 'completed',
                    'text': '',
                    'duration': 0
                }
            elif status == 'FAILED':
                error_msg = result.get('message', 'Unknown error')
                print(f"[ERROR] 转写失败: {error_msg}", file=sys.stderr)
                return {
                    'status': 'failed',
                    'error': error_msg
                }
            else:
                return {
                    'status': status.lower()
                }
        else:
            print(f"[ERROR] 查询失败: {response.code} {response.message}", file=sys.stderr)
            return None
            
    except Exception as e:
        print(f"[ERROR] 查询异常: {e}", file=sys.stderr)
        return None


def process_video(video_path: str, output_dir: Optional[str] = None) -> Dict:
    """处理单个视频，返回转写结果"""
    print(f"[INFO] 处理视频: {video_path}", file=sys.stderr)
    
    # 检查 ffmpeg
    if not check_ffmpeg():
        return {
            'status': 'failed',
            'error': 'ffmpeg 未安装，请先安装 ffmpeg'
        }
    
    # 检查凭证
    if not all([DASHSCOPE_API_KEY, ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET, ALIYUN_OSS_BUCKET]):
        return {
            'status': 'failed',
            'error': '凭证未配置完整，请配置 DASHSCOPE_API_KEY, ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET, ALIYUN_OSS_BUCKET'
        }
    
    # 创建临时目录
    if output_dir:
        temp_dir = Path(output_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)
    else:
        temp_dir = Path(tempfile.gettempdir())
    
    # 生成临时音频文件路径
    audio_filename = f"{uuid.uuid4()}.mp3"
    audio_path = temp_dir / audio_filename
    
    try:
        # 1. 提取音频
        print(f"[INFO] 提取音频到: {audio_path}", file=sys.stderr)
        if not extract_audio(video_path, str(audio_path)):
            return {
                'status': 'failed',
                'error': '提取音频失败'
            }
        
        # 2. 上传到 OSS
        object_name = f"video2text/{uuid.uuid4()}.mp3"
        print(f"[INFO] 上传到 OSS: {object_name}", file=sys.stderr)
        
        # 尝试使用 oss2 库
        audio_url = upload_to_oss_simple(str(audio_path), object_name)
        if not audio_url:
            return {
                'status': 'failed',
                'error': 'OSS 上传失败'
            }
        
        # 3. 创建转写任务
        print(f"[INFO] 创建转写任务...", file=sys.stderr)
        task_id = create_transcription_task(audio_url)
        if not task_id:
            return {
                'status': 'failed',
                'error': '转写任务创建失败'
            }
        
        # 4. 轮询等待结果
        print(f"[INFO] 等待转写完成...", file=sys.stderr)
        for i in range(MAX_POLL_COUNT):
            result = query_transcription(task_id)
            if result is None:
                return {
                    'status': 'failed',
                    'error': '查询转写结果失败'
                }
            
            if result.get('status') == 'completed':
                print(f"[INFO] 转写完成，时长: {result.get('duration', 0)}ms", file=sys.stderr)
                return {
                    'status': 'completed',
                    'text': result.get('text', ''),
                    'duration': result.get('duration', 0)
                }
            elif result.get('status') == 'failed':
                return {
                    'status': 'failed',
                    'error': result.get('error', '转写失败')
                }
            
            print(f"[INFO] 转写中... ({i+1}/{MAX_POLL_COUNT})", file=sys.stderr)
            time.sleep(POLL_INTERVAL)
        
        return {
            'status': 'failed',
            'error': '转写超时'
        }
        
    except Exception as e:
        print(f"[ERROR] 处理异常: {e}", file=sys.stderr)
        return {
            'status': 'failed',
            'error': str(e)
        }
    finally:
        # 清理临时文件
        if audio_path.exists():
            try:
                audio_path.unlink()
            except:
                pass


def _emit(obj: dict):
    """输出一行 JSON 到 stdout（JSONL 格式），立即刷新"""
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def main():
    if len(sys.argv) < 2:
        print("Usage: python video2text.py '<json_request>'")
        print("")
        print("Request JSON 格式:")
        print('  单个视频: {"video": "/path/to/video.mp4"}')
        print('  批量处理: {"videos": ["/path/video1.mp4", "/path/video2.mp4"]}')
        print('  指定输出: {"video": "/path/to/video.mp4", "output_dir": "/path/to/output"}')
        sys.exit(1)

    try:
        request_data = json.loads(sys.argv[1])
    except json.JSONDecodeError as e:
        print(f"JSON parse error: {e}")
        sys.exit(1)

    # 获取视频列表
    videos = []
    output_dir = None
    
    if "video" in request_data:
        videos = [request_data["video"]]
    elif "videos" in request_data:
        videos = request_data["videos"]
    else:
        print("Error: request must contain 'video' or 'videos' field")
        sys.exit(1)
    
    if "output_dir" in request_data:
        output_dir = request_data["output_dir"]

    if not videos:
        print("Error: video list is empty")
        sys.exit(1)

    total = len(videos)
    results = []
    
    # 检查 ffmpeg
    if not check_ffmpeg():
        print("""
=================================================================
错误: ffmpeg 未安装
=================================================================
请先安装 ffmpeg:

Windows (winget):
  winget install ffmpeg

Windows (chocolatey):
  choco install ffmpeg

macOS:
  brew install ffmpeg

Linux (Ubuntu/Debian):
  sudo apt install ffmpeg

Linux (CentOS):
  sudo yum install ffmpeg
=================================================================
""", file=sys.stderr)
        # 输出每个文件的失败结果
        for i, video in enumerate(videos):
            _emit({
                "type": "video_result",
                "index": i,
                "video_path": video,
                "status": "failed",
                "error": "ffmpeg 未安装"
            })
        _emit({
            "type": "summary",
            "status": "failed",
            "total": total,
            "completed": 0,
            "failed": total
        })
        sys.exit(1)

    # 检查凭证
    missing_creds = []
    if not DASHSCOPE_API_KEY:
        missing_creds.append("DASHSCOPE_API_KEY")
    if not ALIYUN_ACCESS_KEY_ID:
        missing_creds.append("ALIYUN_ACCESS_KEY_ID")
    if not ALIYUN_ACCESS_KEY_SECRET:
        missing_creds.append("ALIYUN_ACCESS_KEY_SECRET")
    if not ALIYUN_OSS_BUCKET:
        missing_creds.append("ALIYUN_OSS_BUCKET")
    
    if missing_creds:
        print(f"""
=================================================================
错误: 凭证未配置
=================================================================
缺少以下环境变量:
  {', '.join(missing_creds)}

请在 .env 文件或环境变量中配置:
  DASHSCOPE_API_KEY=your-dashscope-api-key
  ALIYUN_ACCESS_KEY_ID=your-access-key-id
  ALIYUN_ACCESS_KEY_SECRET=your-access-key-secret
  ALIYUN_OSS_BUCKET=your-bucket-name
  ALIYUN_OSS_ENDPOINT=oss-cn-beijing.aliyuncs.com
=================================================================
""", file=sys.stderr)
        # 输出每个文件的失败结果
        for i, video in enumerate(videos):
            _emit({
                "type": "video_result",
                "index": i,
                "video_path": video,
                "status": "failed",
                "error": f"凭证未配置: {', '.join(missing_creds)}"
            })
        _emit({
            "type": "summary",
            "status": "failed",
            "total": total,
            "completed": 0,
            "failed": total
        })
        sys.exit(1)

    # 处理每个视频
    completed = 0
    failed = 0
    
    for i, video in enumerate(videos):
        result = process_video(video, output_dir)
        
        if result.get('status') == 'completed':
            _emit({
                "type": "video_result",
                "index": i,
                "video_path": video,
                "status": "completed",
                "text": result.get('text', ''),
                "duration": result.get('duration', 0)
            })
            completed += 1
        else:
            _emit({
                "type": "video_result",
                "index": i,
                "video_path": video,
                "status": "failed",
                "error": result.get('error', 'Unknown error')
            })
            failed += 1
    
    # 输出汇总
    _emit({
        "type": "summary",
        "status": "completed" if completed > 0 else "failed",
        "total": total,
        "completed": completed,
        "failed": failed
    })


if __name__ == "__main__":
    main()
