---
name: aliyun-video2text
description: 将本地视频文件的语音提取并转换为文字文案。当用户提到"视频转文案"、"提取视频文案"、"视频语音转文字"、"短视频文案提取"、"视频脚本提取"、"语音转写"时使用此技能。
---

# 阿里百炼视频转文案 Skill

将本地视频文件的语音提取并转换为文字文案。

## 触发关键词

当用户提到以下关键词时，使用此技能：
- 视频转文案
- 提取视频文案
- 视频语音转文字
- 短视频文案提取
- 视频脚本提取
- 语音转写

## 功能

- 提取本地视频的音频
- 上传到阿里云 OSS（临时存储）
- 调用阿里百炼 Paraformer-v2 语音识别 API 转写
- 返回文案文本

## 限制

- 支持格式：mp4, avi, mov, mkv, flv, wmv
- 音频格式：mp3, wav, m4a, pcm
- 最大视频大小：500MB
- 最大视频时长：无限制（服务端处理）
- 转写语言：中文普通话

## 前置要求

### 1. 安装 ffmpeg

**Windows:**
```bash
# 使用 winget
winget install ffmpeg

# 或使用 chocolatey
choco install ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

**Linux:**
```bash
sudo apt install ffmpeg  # Ubuntu/Debian
sudo yum install ffmpeg   # CentOS
```

### 2. 配置凭证

需要在环境变量或 `.env` 文件中配置：

```bash
# 阿里云 DashScope API Key（必填）
DASHSCOPE_API_KEY=your-dashscope-api-key

# 阿里云 OSS 配置（必填）
ALIYUN_ACCESS_KEY_ID=your-access-key-id
ALIYUN_ACCESS_KEY_SECRET=your-access-key-secret
ALIYUN_OSS_BUCKET=your-bucket-name
ALIYUN_OSS_ENDPOINT=oss-cn-beijing.aliyuncs.com
```

## 使用方式

### 提取单个视频文案

```bash
python3 scripts/video2text.py '{"video": "/path/to/video.mp4"}'
```

### 批量提取多个视频文案

```bash
python3 scripts/video2text.py '{"videos": ["/path/video1.mp4", "/path/video2.mp4"]}'
```

### 指定输出目录

```bash
python3 scripts/video2text.py '{"video": "/path/to/video.mp4", "output_dir": "/path/to/output"}'
```

## 输出格式

输出为 **JSONL**（每行一个 JSON），支持流式读取：

### 单个视频结果行

```json
{"type": "video_result", "index": 0, "video_path": "/path/to/video.mp4", "status": "completed", "text": "视频文案内容...", "duration": 65000}
```

### 汇总行

```json
{"type": "summary", "status": "completed", "total": 3, "completed": 2, "failed": 1}
```

## 工作流程

1. 校验 ffmpeg 是否可用
2. 使用 ffmpeg 从视频提取音频（转换为 mp3）
3. 上传音频到阿里云 OSS（生成临时 URL）
4. 调用阿里百炼转写 API 创建转写任务
5. 轮询任务状态，获取转写结果
6. 输出文案文本

## 错误处理

- ffmpeg 不可用：提示安装
- 凭证配置缺失：提示配置
- OSS 上传失败：输出错误信息
- 转写失败：输出错误信息，继续处理下一个文件
