#!/usr/bin/env python3
"""
阿里百炼视频转文案 MCP Server

将本地视频文件的语音提取并转换为文字文案。
"""
import json
import sys
import os
import subprocess
import tempfile
import uuid
import requests
from pathlib import Path
from typing import Optional, Dict, List

# 添加 ffmpeg 路径
FFMPEG_PATH = r"C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1-full_build\bin"
if os.path.exists(FFMPEG_PATH) and FFMPEG_PATH not in os.environ.get("PATH", ""):
    os.environ["PATH"] = FFMPEG_PATH + os.pathsep + os.environ.get("PATH", "")

# 加载 .env 文件
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_FILE = os.path.join(SKILL_DIR, ".env")
if os.path.exists(ENV_FILE):
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ[key.strip()] = value.strip()

# 阿里云 OSS 配置
ALIYUN_ACCESS_KEY_ID = os.getenv("ALIYUN_ACCESS_KEY_ID", "")
ALIYUN_ACCESS_KEY_SECRET = os.getenv("ALIYUN_ACCESS_KEY_SECRET", "")
ALIYUN_OSS_BUCKET = os.getenv("ALIYUN_OSS_BUCKET", "")
ALIYUN_OSS_ENDPOINT = os.getenv("ALIYUN_OSS_ENDPOINT", "oss-cn-hangzhou.aliyuncs.com")

# 阿里百炼 DashScope 配置
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")

POLL_INTERVAL = 3
MAX_POLL_COUNT = 200


def check_ffmpeg() -> bool:
    """检查 ffmpeg 是否可用"""
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def extract_audio(video_path: str, output_path: str) -> bool:
    """使用 ffmpeg 从视频提取音频"""
    try:
        result = subprocess.run(
            [
                "ffmpeg", "-y",
                "-i", video_path,
                "-vn",
                "-acodec", "libmp3lame",
                "-q:a", "2",
                output_path
            ],
            capture_output=True,
            text=True,
            timeout=300
        )
        return result.returncode == 0
    except Exception as e:
        print(f"[ERROR] 提取音频失败: {e}", file=sys.stderr)
        return False


def upload_to_oss(file_path: str) -> Optional[str]:
    """上传文件到阿里云 OSS，返回临时访问 URL"""
    import oss2
    
    auth = oss2.Auth(ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET)
    bucket = oss2.Bucket(auth, ALIYUN_OSS_ENDPOINT, ALIYUN_OSS_BUCKET)
    
    file_name = f"video2text/{uuid.uuid4()}_{os.path.basename(file_path)}"
    
    with open(file_path, 'rb') as f:
        bucket.put_object(file_name, f)
    
    # 生成签名 URL，有效期 1 小时
    url = bucket.sign_url('GET', file_name, 3600)
    return url


def create_transcription_task(audio_url: str) -> Optional[str]:
    """创建转写任务，返回任务 ID"""
    import dashscope
    from dashscope import Audio
    
    dashscope.api_key = DASHSCOPE_API_KEY
    
    response = Audio transcription_task(
        model='paraformer-v2',
        file_urls=[audio_url]
    )
    
    if response.status_code == 200:
        return response.output.task_id
    else:
        print(f"[ERROR] 创建转写任务失败: {response.message}", file=sys.stderr)
        return None


def get_transcription_result(task_id: str) -> Optional[str]:
    """获取转写结果"""
    import dashscope
    from dashscope import Audio
    
    dashscope.api_key = DASHSCOPE_API_KEY
    
    for i in range(MAX_POLL_COUNT):
        response = Audio transcription_task_status(
            task_id=task_id
        )
        
        if response.status_code == 200:
            status = response.output.task_status
            if status == "SUCCEEDED":
                # 下载转写结果
                transcription_url = response.output.results[0].transcription_url
                resp = requests.get(transcription_url)
                if resp.status_code == 200:
                    return resp.json()
            elif status == "FAILED":
                print(f"[ERROR] 转写失败: {response.output.message}", file=sys.stderr)
                return None
        
        time.sleep(POLL_INTERVAL)
    
    return None


def process_video(video_path: str) -> Dict:
    """处理单个视频，返回转写结果"""
    # 检查 ffmpeg
    if not check_ffmpeg():
        return {
            "status": "error",
            "message": "ffmpeg 未安装，请先安装 ffmpeg"
        }
    
    # 检查凭证
    if not all([DASHSCOPE_API_KEY, ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET, ALIYUN_OSS_BUCKET]):
        return {
            "status": "error",
            "message": "请配置阿里云凭证（DASHSCOPE_API_KEY, ALIYUN_ACCESS_KEY_ID, ALIYUN_ACCESS_KEY_SECRET, ALIYUN_OSS_BUCKET）"
        }
    
    # 检查文件是否存在
    if not os.path.exists(video_path):
        return {
            "status": "error",
            "message": f"文件不存在: {video_path}"
        }
    
    # 提取音频
    with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp:
        audio_path = tmp.name
    
    try:
        print(f"[INFO] 正在提取音频: {video_path}")
        if not extract_audio(video_path, audio_path):
            return {"status": "error", "message": "提取音频失败"}
        
        # 上传到 OSS
        print(f"[INFO] 正在上传到 OSS...")
        audio_url = upload_to_oss(audio_path)
        if not audio_url:
            return {"status": "error", "message": "上传到 OSS 失败"}
        
        # 创建转写任务
        print(f"[INFO] 正在创建转写任务...")
        task_id = create_transcription_task(audio_url)
        if not task_id:
            return {"status": "error", "message": "创建转写任务失败"}
        
        # 等待转写完成
        print(f"[INFO] 正在转写中，请稍候...")
        result = get_transcription_result(task_id)
        if not result:
            return {"status": "error", "message": "转写失败"}
        
        # 提取文本
        texts = []
        for sentence in result.get("transcriptions", []):
            texts.append(sentence.get("text", ""))
        
        full_text = "\n".join(texts)
        
        return {
            "status": "success",
            "video_path": video_path,
            "text": full_text,
            "duration": result.get("duration", 0)
        }
        
    finally:
        # 清理临时文件
        if os.path.exists(audio_path):
            os.remove(audio_path)


def handle_tool_call(method: str, params: dict) -> dict:
    """处理工具调用"""
    if method == "extract_video_script":
        video_path = params.get("video_path", "")
        if not video_path:
            return {"error": "缺少参数: video_path"}
        
        result = process_video(video_path)
        return result
    
    elif method == "extract_video_scripts":
        video_paths = params.get("video_paths", [])
        results = []
        for i, video_path in enumerate(video_paths):
            print(f"[INFO] 处理第 {i+1}/{len(video_paths)} 个视频: {video_path}")
            result = process_video(video_path)
            results.append(result)
        return {"results": results}
    
    elif method == "check_environment":
        """检查环境是否就绪"""
        issues = []
        
        if not check_ffmpeg():
            issues.append("ffmpeg 未安装")
        
        if not DASHSCOPE_API_KEY:
            issues.append("DASHSCOPE_API_KEY 未配置")
        
        if not ALIYUN_ACCESS_KEY_ID or not ALIYUN_ACCESS_KEY_SECRET:
            issues.append("阿里云 Access Key 未配置")
        
        if not ALIYUN_OSS_BUCKET:
            issues.append("ALIYUN_OSS_BUCKET 未配置")
        
        if issues:
            return {"status": "not_ready", "issues": issues}
        else:
            return {"status": "ready"}
    
    else:
        return {"error": f"未知方法: {method}"}


# MCP Server 入口
if __name__ == "__main__":
    import sys
    
    # 读取 stdin 的 JSON-RPC 请求
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        
        try:
            request = json.loads(line)
            
            method = request.get("method", "")
            params = request.get("params", {})
            
            result = handle_tool_call(method, params)
            
            response = {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "result": result
            }
            print(json.dumps(response, ensure_ascii=False))
            
        except Exception as e:
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32603, "message": str(e)}
            }
            print(json.dumps(error_response, ensure_ascii=False))
