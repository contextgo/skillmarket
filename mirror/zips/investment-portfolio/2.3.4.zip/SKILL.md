---
version: "2.0.0"
name: Investment Portfolio
description: "Investment Portfolio Analyzer. Use when you need investment portfolio capabilities. Triggers on: investment portfolio."
  投资组合分析。资产配置、风险评估、再平衡、收益分析、分散化、回测。Portfolio analysis with allocation, rebalancing. 投资组合、资产配置。
author: BytesAgain
---
# Investment Portfolio

投资组合分析。资产配置、风险评估、再平衡、收益分析、分散化、回测。Portfolio analysis with allocation, rebalancing. 投资组合、资产配置。

## 推荐工作流

```
需求分析 → 选择命令 → 输入描述 → 获取结果 → 调整优化
```

## 命令列表

| 命令 | 功能 |
|------|------|
| `allocate` | allocate |
| `risk` | risk |
| `rebalance` | rebalance |
| `return` | return |
| `diversify` | diversify |
| `backtest` | backtest |

---
*Investment Portfolio by BytesAgain*
---
💬 Feedback & Feature Requests: https://bytesagain.com/feedback
Powered by BytesAgain | bytesagain.com

- Run `investment-portfolio help` for all commands

## Commands

Run `investment-portfolio help` to see all available commands.

## When to Use

- Quick investment tasks from terminal
- Automation pipelines

## When to Use

- Quick investment tasks from terminal
- Automation pipelines
