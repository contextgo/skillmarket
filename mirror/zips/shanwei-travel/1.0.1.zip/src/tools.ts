import fs from 'fs';
import path from 'path';

// 知识库文件路径
const KNOWLEDGE_DIR = path.join(__dirname, '..', 'knowledge');

// 读取知识库文件
function readKnowledgeFile(filename: string): string {
  try {
    const filePath = path.join(KNOWLEDGE_DIR, filename);
    return fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    return `无法读取${filename}文件`;
  }
}

// 汕尾旅游工具
export const shanweiTravelTools = {
  // 查询景点信息
  queryAttractions: {
    name: 'query_attractions',
    description: '查询汕尾景点信息，包括开放时间、门票、游玩建议等',
    parameters: {
      type: 'object',
      properties: {
        attraction_name: {
          type: 'string',
          description: '景点名称，如"红海湾"、"玄武山"、"风车岛"等，不指定则返回所有景点'
        },
        category: {
          type: 'string',
          description: '景点分类，如"海滨"、"山岳"、"文化"、"岛屿"等'
        }
      }
    },
    execute: async ({ attraction_name, category }: any) => {
      const knowledge = readKnowledgeFile('景点.md');
      
      if (attraction_name) {
        // 查找特定景点
        const lines = knowledge.split('\n');
        let inTargetSection = false;
        let result = '';
        
        for (const line of lines) {
          if (line.includes(`### ${attraction_name}`) || line.includes(`**${attraction_name}**`)) {
            inTargetSection = true;
            result += line + '\n';
          } else if (inTargetSection && line.startsWith('### ')) {
            break; // 遇到下一个景点，结束
          } else if (inTargetSection) {
            result += line + '\n';
          }
        }
        
        if (result) {
          return `🏞️ **${attraction_name}** 景点信息：\n\n${result}`;
        } else {
          return `未找到景点"${attraction_name}"的详细信息，请检查景点名称是否正确。`;
        }
      } else if (category) {
        // 按分类查找
        const lines = knowledge.split('\n');
        let inCategorySection = false;
        let result = `🏝️ **${category}类景点**：\n\n`;
        let attractions: string[] = [];
        
        for (const line of lines) {
          if (line.includes(`## ${category}`)) {
            inCategorySection = true;
          } else if (inCategorySection && line.startsWith('## ')) {
            break; // 遇到下一个分类，结束
          } else if (inCategorySection && line.startsWith('### ')) {
            attractions.push(line.replace('### ', '').trim());
          }
        }
        
        if (attractions.length > 0) {
          result += attractions.map((att, index) => `${index + 1}. ${att}`).join('\n');
          result += '\n\n如需查看具体景点详情，请指定景点名称。';
          return result;
        } else {
          return `未找到"${category}"分类的景点，可用分类：海滨、山岳、文化历史、岛屿、自然生态。`;
        }
      } else {
        // 返回所有景点概览
        const lines = knowledge.split('\n');
        let result = '🏖️ **汕尾主要景点分类**：\n\n';
        const categories: string[] = [];
        let currentCategory = '';
        
        for (const line of lines) {
          if (line.startsWith('## ')) {
            currentCategory = line.replace('## ', '').trim();
            if (currentCategory && !currentCategory.includes('大全') && !currentCategory.includes('推荐') && !currentCategory.includes('贴士')) {
              categories.push(currentCategory);
            }
          }
        }
        
        result += categories.map((cat, index) => `${index + 1}. ${cat}`).join('\n');
        result += '\n\n请指定景点名称或分类查看详细信息。';
        return result;
      }
    }
  },

  // 查询美食信息
  queryFood: {
    name: 'query_food',
    description: '查询汕尾美食信息，包括特色小吃、海鲜、餐厅推荐等',
    parameters: {
      type: 'object',
      properties: {
        food_name: {
          type: 'string',
          description: '美食名称，如"汕尾薄饼"、"菜茶"、"牛肉饼"等'
        },
        category: {
          type: 'string',
          description: '美食分类，如"特色小吃"、"海鲜"、"主食"、"甜品"等'
        }
      }
    },
    execute: async ({ food_name, category }: any) => {
      const knowledge = readKnowledgeFile('美食.md');
      
      if (food_name) {
        // 查找特定美食
        const lines = knowledge.split('\n');
        let inTargetSection = false;
        let result = '';
        
        for (const line of lines) {
          if (line.includes(`### ${food_name}`) || line.includes(`**${food_name}**`)) {
            inTargetSection = true;
            result += line + '\n';
          } else if (inTargetSection && line.startsWith('### ')) {
            break;
          } else if (inTargetSection) {
            result += line + '\n';
          }
        }
        
        if (result) {
          return `🍜 **${food_name}** 美食信息：\n\n${result}`;
        } else {
          return `未找到"${food_name}"的详细信息，请检查美食名称是否正确。`;
        }
      } else if (category) {
        // 按分类查找
        const lines = knowledge.split('\n');
        let inCategorySection = false;
        let result = `🍽️ **${category}**：\n\n`;
        let foods: string[] = [];
        
        for (const line of lines) {
          if (line.includes(`## ${category}`)) {
            inCategorySection = true;
          } else if (inCategorySection && line.startsWith('## ')) {
            break;
          } else if (inCategorySection && line.startsWith('### ')) {
            foods.push(line.replace('### ', '').trim());
          }
        }
        
        if (foods.length > 0) {
          result += foods.map((food, index) => `${index + 1}. ${food}`).join('\n');
          result += '\n\n如需查看具体美食详情，请指定美食名称。';
          return result;
        } else {
          return `未找到"${category}"分类的美食，可用分类：特色小吃、海鲜美食、主食类、甜品小吃、美食街区、推荐餐厅。`;
        }
      } else {
        // 返回所有美食概览
        const lines = knowledge.split('\n');
        let result = '🍴 **汕尾美食分类**：\n\n';
        const categories: string[] = [];
        
        for (const line of lines) {
          if (line.startsWith('## ')) {
            const cat = line.replace('## ', '').trim();
            if (cat && !cat.includes('指南') && !cat.includes('街区') && !cat.includes('餐厅') && !cat.includes('时间') && !cat.includes('贴士')) {
              categories.push(cat);
            }
          }
        }
        
        result += categories.map((cat, index) => `${index + 1}. ${cat}`).join('\n');
        result += '\n\n请指定美食名称或分类查看详细信息。';
        return result;
      }
    }
  },

  // 查询交通信息
  queryTransportation: {
    name: 'query_transportation',
    description: '查询汕尾交通信息，包括高铁、公交、自驾路线等',
    parameters: {
      type: 'object',
      properties: {
        type: {
          type: 'string',
          description: '交通类型，如"高铁"、"公交"、"自驾"、"出租车"等'
        },
        from_to: {
          type: 'string',
          description: '出发地和目的地，如"深圳到汕尾"、"市区到红海湾"等'
        }
      }
    },
    execute: async ({ type, from_to }: any) => {
      if (type) {
        let result = `🚗 **${type}交通信息**：\n\n`;
        
        if (type.includes('高铁') || type.includes('火车')) {
          result += `**汕尾站（高铁站）**\n`;
          result += `• 位置：汕尾市城区东涌镇\n`;
          result += `• 主要线路：厦深铁路、广汕高铁\n`;
          result += `• 到达时间：深圳约1小时，广州约1.5小时，厦门约2小时\n`;
          result += `• 接驳交通：6路、112路公交到市区\n\n`;
          
          result += `**其他车站**\n`;
          result += `• 陆丰站：适合前往陆丰市、玄武山\n`;
          result += `• 鲘门站：适合前往海丰县、红海湾\n`;
          
        } else if (type.includes('公交') || type.includes('汽车')) {
          result += `**主要公交线路**\n`;
          result += `• 6路：高铁站-市区，2元\n`;
          result += `• 112路：高铁站-红海湾，5元\n`;
          result += `• 1路：市区环线，2元\n`;
          result += `• 海丰专线：市区-海丰，8元\n\n`;
          
          result += `**长途汽车**\n`;
          result += `• 汕尾汽车总站：到广州3-4小时，深圳2-3小时\n`;
          result += `• 海丰汽车站、陆丰汽车站\n`;
          
        } else if (type.includes('自驾')) {
          result += `**主要高速公路**\n`;
          result += `• 沈海高速（G15）：深圳到汕尾约2小时\n`;
          result += `• 甬莞高速（G1523）：惠州到汕尾约1.5小时\n`;
          result += `• 广汕高速（在建）：广州到汕尾约1.5小时\n\n`;
          
          result += `**到各景区**\n`;
          result += `• 到红海湾：市区出发约30分钟\n`;
          result += `• 到玄武山：约1小时（高速+省道）\n`;
          result += `• 到风车岛：红海湾出发约20分钟\n`;
          
        } else if (type.includes('出租') || type.includes('网约')) {
          result += `**出租车**\n`;
          result += `• 起步价：8元/2公里\n`;
          result += `• 每公里：2.4元\n`;
          result += `• 夜间加价：23:00-5:00加收20%\n\n`;
          
          result += `**网约车**\n`;
          result += `• 可用平台：滴滴出行、曹操出行\n`;
          result += `• 价格：比出租车略便宜\n`;
          result += `• 覆盖范围：市区、红海湾、海丰县\n`;
          
        } else if (type.includes('船') || type.includes('水上')) {
          result += `**到龟龄岛**\n`;
          result += `• 码头：捷胜镇码头\n`;
          result += `• 船程：约30分钟\n`;
          result += `• 价格：50-80元/人（往返）\n`;
          result += `• 班次：需凑够人数或包船\n\n`;
          
          result += `**红海湾游船**\n`;
          result += `• 位置：红海湾码头\n`;
          result += `• 项目：海上观光、环岛游\n`;
          result += `• 价格：80-150元/人\n`;
          
        } else {
          result += `可用交通类型：高铁/火车、公交/汽车、自驾、出租车/网约车、水上交通\n`;
        }
        
        return result;
        
      } else if (from_to) {
        let result = `🗺️ **${from_to}交通方案**：\n\n`;
        
        if (from_to.includes('深圳') && from_to.includes('汕尾')) {
          result += `**方案1：高铁（推荐）**\n`;
          result += `• 深圳北 → 汕尾站：约1小时\n`;
          result += `• 票价：二等座约80-100元\n`;
          result += `• 班次：每天多班，约30分钟一班\n\n`;
          
          result += `**方案2：自驾**\n`;
          result += `• 路线：沈海高速（G15）\n`;
          result += `• 时间：约2小时\n`;
          result += `• 过路费：约100元\n\n`;
          
          result += `**方案3：长途汽车**\n`;
          result += `• 深圳各车站 → 汕尾汽车总站\n`;
          result += `• 时间：约2-3小时\n`;
          result += `• 票价：约80-100元\n`;
          
        } else if (from_to.includes('广州') && from_to.includes('汕尾')) {
          result += `**方案1：高铁（推荐）**\n`;
          result += `• 广州南 → 汕尾站：约1.5小时（广汕高铁）\n`;
          result += `• 票价：二等座约120-150元\n\n`;
          
          result += `**方案2：自驾**\n`;
          result += `• 路线：广汕高速（在建）/沈海高速\n`;
          result += `• 时间：约3小时\n`;
          result += `• 过路费：约150元\n\n`;
          
          result += `**方案3：长途汽车**\n`;
          result += `• 广州各车站 → 汕尾汽车总站\n`;
          result += `• 时间：约3-4小时\n`;
          result += `• 票价：约100-120元\n`;
          
        } else if (from_to.includes('市区') && from_to.includes('红海湾')) {
          result += `**方案1：公交112路**\n`;
          result += `• 起点：市区各站点\n`;
          result += `• 终点：红海湾旅游区\n`;
          result += `• 时间：约1小时\n`;
          result += `• 票价：5元\n\n`;
          
          result += `**方案2：出租车/网约车**\n`;
          result += `• 时间：约30分钟\n`;
          result += `• 费用：50-60元\n\n`;
          
          result += `**方案3：自驾**\n`;
          result += `• 路线：汕尾大道 → X141县道\n`;
          result += `• 时间：约30分钟\n`;
          result += `• 路况：良好，有指示牌\n`;
          
        } else if (from_to.includes('高铁站') && from_to.includes('市区')) {
          result += `**方案1：公交6路**\n`;
          result += `• 起点：高铁站\n`;
          result += `• 终点：市区（市政府、汽车总站等）\n`;
          result += `• 时间：约30分钟\n`;
          result += `• 票价：2元\n\n`;
          
          result += `**方案2：出租车**\n`;
          result += `• 时间：约20分钟\n`;
          result += `• 费用：20-30元\n\n`;
          
          result += `**方案3：网约车**\n`;
          result += `• 滴滴、曹操出行等\n`;
          result += `• 费用：15-25元\n`;
          
        } else {
          result += `请描述更具体的路线，例如：\n`;
          result += `• "从深圳到汕尾"\n`;
          result += `• "从市区到红海湾"\n`;
          result += `• "从高铁站到市区"\n`;
        }
        
        return result;
        
      } else {
        // 返回交通概览
        let result = '🚄 **汕尾交通方式**：\n\n';
        result += `1. **高铁/火车**：深圳1小时，广州1.5小时，厦门2小时\n`;
        result += `2. **长途汽车**：广州3-4小时，深圳2-3小时\n`;
        result += `3. **自驾**：高速公路网络完善\n`;
        result += `4. **市内公交**：覆盖主要景点\n`;
        result += `5. **出租车/网约车**：方便快捷\n`;
        result += `6. **水上交通**：到龟龄岛等海岛\n\n`;
        result += `请指定交通类型或具体路线查看详细信息。`;
        return result;
      }
    }
  },

  // 行程规划
  planItinerary: {
    name: 'plan_itinerary',
    description: '根据旅行天数规划汕尾行程',
    parameters: {
      type: 'object',
      properties: {
        days: {
          type: 'number',
          description: '旅行天数，如1、2、3天'
        },
        travel_type: {
          type: 'string',
          description: '旅行类型，如"海滨度假"、"文化历史"、"美食体验"、"家庭亲子"等'
        }
      },
      required: ['days']
    },
    execute: async ({ days, travel_type }: any) => {
      const knowledge = readKnowledgeFile('行程规划.md');
      
      // 简化：直接返回相关部分
      let result = `📅 **汕尾${days}日游行程建议**：\n\n`;
      
      if (days === 1) {
        result += `**一日游推荐方案**：\n\n`;
        result += `**方案A：红海湾经典一日游**\n`;
        result += `• 上午：游览遮浪半岛，欣赏奇特的海景\n`;
        result += `• 中午：红海湾海鲜午餐\n`;
        result += `• 下午：南海观音景区、风车岛拍照\n`;
        result += `• 晚上：二马路美食街品尝小吃\n\n`;
        
        result += `**方案B：文化历史一日游**\n`;
        result += `• 上午：海丰红宫红场、彭湃故居\n`;
        result += `• 中午：海丰当地美食\n`;
        result += `• 下午：陆丰玄武山旅游区\n`;
        result += `• 晚上：市区海鲜晚餐\n`;
        
      } else if (days === 2) {
        result += `**二日游推荐方案**：\n\n`;
        result += `**第一天：红海湾深度游**\n`;
        result += `• 上午：抵达红海湾，沙滩活动\n`;
        result += `• 中午：海鲜大餐\n`;
        result += `• 下午：南海观音、风车岛\n`;
        result += `• 晚上：入住红海湾，海边散步\n\n`;
        
        result += `**第二天：海岛体验**\n`;
        result += `• 上午：龟龄岛浮潜、海钓\n`;
        result += `• 下午：返回市区，购买特产\n`;
        result += `• 晚上：二马路美食街告别宴\n`;
        
      } else if (days === 3) {
        result += `**三日游推荐方案**：\n\n`;
        result += `**第一天：市区文化美食**\n`;
        result += `• 抵达汕尾，入住市区酒店\n`;
        result += `• 凤山祖庙、海滨公园\n`;
        result += `• 二马路夜市美食\n\n`;
        
        result += `**第二天：红海湾海滨游**\n`;
        result += `• 红海湾、风车岛深度游\n`;
        result += `• 入住红海湾度假村\n`;
        result += `• 海边烧烤晚餐\n\n`;
        
        result += `**第三天：海岛生态游**\n`;
        result += `• 龟龄岛一日游\n`;
        result += `• 大湖湿地观鸟（季节性）\n`;
        result += `• 海鲜告别宴，返程\n`;
        
      } else {
        return `目前主要提供1-3日游行程规划。${days}天行程建议：\n\n` +
               `• 前3天参考上述行程\n` +
               `• 后续天数可安排：\n` +
               `  - 深度游览其他景点\n` +
               `  - 休闲度假，放松身心\n` +
               `  - 探索周边县市\n`;
      }
      
      if (travel_type) {
        result += `\n🏷️ **${travel_type}特别建议**：\n`;
        if (travel_type.includes('海滨') || travel_type.includes('度假')) {
          result += `• 重点安排红海湾、风车岛、龟龄岛\n`;
          result += `• 选择海景酒店或度假村\n`;
          result += `• 体验水上运动：冲浪、浮潜\n`;
        } else if (travel_type.includes('文化') || travel_type.includes('历史')) {
          result += `• 重点安排红宫红场、玄武山、凤山祖庙\n`;
          result += `• 了解汕尾红色文化和妈祖文化\n`;
          result += `• 选择市区酒店，交通便利\n`;
        } else if (travel_type.includes('美食')) {
          result += `• 重点安排二马路美食街、海鲜大排档\n`;
          result += `• 体验制作汕尾薄饼\n`;
          result += `• 尝试生腌海鲜、各种粿品\n`;
        } else if (travel_type.includes('家庭') || travel_type.includes('亲子')) {
          result += `• 选择安全沙滩，浅水区游玩\n`;
          result += `• 安排有趣活动：捡贝壳、观察海洋生物\n`;
          result += `• 选择有儿童设施的酒店\n`;
        }
      }
      
      // 添加实用贴士
      result += '\n---\n';
      result += '💡 **实用贴士**：\n';
      result += '• 提前预订住宿和交通\n';
      result += '• 根据季节准备衣物（夏季防晒，冬季保暖）\n';
      result += '• 注意饮食安全，海鲜要新鲜\n';
      result += '• 更多详细信息可使用其他查询功能\n';
      
      return result;
    }
  },

  // 综合查询
  generalQuery: {
    name: 'general_query',
    description: '综合查询汕尾旅游信息，回答各种旅游相关问题',
    parameters: {
      type: 'object',
      properties: {
        question: {
          type: 'string',
          description: '旅游相关问题，如"汕尾有什么好玩的"、"怎么去红海湾"、"汕尾特色美食"等'
        }
      },
      required: ['question']
    },
    execute: async ({ question }: any) => {
      const questionLower = question.toLowerCase();
      
      // 关键词匹配
      if (questionLower.includes('好玩') || questionLower.includes('景点') || questionLower.includes('玩什么')) {
        return await shanweiTravelTools.queryAttractions.execute({});
      } else if (questionLower.includes('吃') || questionLower.includes('美食') || questionLower.includes('特色小吃')) {
        return await shanweiTravelTools.queryFood.execute({});
      } else if (questionLower.includes('怎么去') || questionLower.includes('交通') || questionLower.includes('路线') || 
                 questionLower.includes('到汕尾') || questionLower.includes('去汕尾')) {
        // 尝试提取出发地
        if (questionLower.includes('深圳')) {
          return await shanweiTravelTools.queryTransportation.execute({ from_to: '深圳到汕尾' });
        } else if (questionLower.includes('广州')) {
          return await shanweiTravelTools.queryTransportation.execute({ from_to: '广州到汕尾' });
        } else if (questionLower.includes('高铁站') || questionLower.includes('火车站')) {
          return await shanweiTravelTools.queryTransportation.execute({ from_to: '高铁站到市区' });
        } else if (questionLower.includes('红海湾')) {
          return await shanweiTravelTools.queryTransportation.execute({ from_to: '市区到红海湾' });
        } else {
          return await shanweiTravelTools.queryTransportation.execute({});
        }
      } else if (questionLower.includes('行程') || questionLower.includes('规划') || questionLower.includes('几天') ||
                 questionLower.includes('日游') || questionLower.includes('攻略')) {
        // 尝试提取天数
        const dayMatch = questionLower.match(/(\d+)\s*天/);
        const dayMatch2 = questionLower.match(/(\d+)\s*日/);
        const dayMatch3 = questionLower.match(/(一|二|三|1|2|3)\s*日游/);
        
        let days = 0;
        if (dayMatch) {
          days = parseInt(dayMatch[1]);
        } else if (dayMatch2) {
          days = parseInt(dayMatch2[1]);
        } else if (dayMatch3) {
          const dayStr = dayMatch3[1];
          if (dayStr === '一' || dayStr === '1') days = 1;
          else if (dayStr === '二' || dayStr === '2') days = 2;
          else if (dayStr === '三' || dayStr === '3') days = 3;
        }
        
        if (days > 0) {
          return await shanweiTravelTools.planItinerary.execute({ days });
        } else {
          return '请告诉我您计划游玩几天（如1天、2天、3天），我可以为您规划行程。';
        }
      } else if (questionLower.includes('红海湾')) {
        return await shanweiTravelTools.queryAttractions.execute({ attraction_name: '红海湾' });
      } else if (questionLower.includes('玄武山')) {
        return await shanweiTravelTools.queryAttractions.execute({ attraction_name: '玄武山' });
      } else if (questionLower.includes('风车岛')) {
        return await shanweiTravelTools.queryAttractions.execute({ attraction_name: '风车岛' });
      } else if (questionLower.includes('薄饼') || questionLower.includes('菜茶')) {
        return await shanweiTravelTools.queryFood.execute({ food_name: questionLower.includes('薄饼') ? '汕尾薄饼' : '菜茶' });
      } else {
        return `关于"${question}"，我可以帮您查询：\n\n1. 🏞️ 景点信息\n2. 🍜 美食推荐\n3. 🚗 交通指南\n4. 📅 行程规划\n\n请告诉我您想了解哪方面的信息，或使用具体查询功能。`;
      }
    }
  }
};

// 导出工具
export default {
  tools: Object.values(shanweiTravelTools)
};