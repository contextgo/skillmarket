#!/usr/bin/env node

/**
 * 汕尾旅游Skill演示
 */

const { shanweiTravelTools } = require('./dist/tools.js');

async function runDemo() {
  console.log('🌊 汕尾旅游Skill演示');
  console.log('==================\n');
  
  console.log('🎯 **触发词**：');
  console.log('• "汕尾旅游"');
  console.log('• "汕尾攻略"');
  console.log('• "去汕尾怎么玩"');
  console.log('• "红海湾"');
  console.log('• "汕尾美食"\n');
  
  console.log('🚀 **功能演示**：\n');
  
  // 演示1：景点查询
  console.log('1. 🏞️ **景点查询演示**');
  console.log('用户："查询红海湾景点信息"');
  const demo1 = await shanweiTravelTools.generalQuery.execute({ question: '查询红海湾景点信息' });
  console.log('Skill：' + demo1.substring(0, 150) + '...\n');
  
  // 演示2：美食查询
  console.log('2. 🍜 **美食查询演示**');
  console.log('用户："汕尾有什么特色美食"');
  const demo2 = await shanweiTravelTools.generalQuery.execute({ question: '汕尾有什么特色美食' });
  console.log('Skill：' + demo2.substring(0, 150) + '...\n');
  
  // 演示3：交通查询
  console.log('3. 🚗 **交通查询演示**');
  console.log('用户："怎么从深圳到汕尾"');
  const demo3 = await shanweiTravelTools.generalQuery.execute({ question: '怎么从深圳到汕尾' });
  console.log('Skill：' + demo3.substring(0, 150) + '...\n');
  
  // 演示4：行程规划
  console.log('4. 📅 **行程规划演示**');
  console.log('用户："规划一个3日游行程"');
  const demo4 = await shanweiTravelTools.generalQuery.execute({ question: '规划一个3日游行程' });
  console.log('Skill：' + demo4.substring(0, 200) + '...\n');
  
  // 演示5：综合查询
  console.log('5. ❓ **综合查询演示**');
  console.log('用户："汕尾旅游攻略"');
  const demo5 = await shanweiTravelTools.generalQuery.execute({ question: '汕尾旅游攻略' });
  console.log('Skill：' + demo5.substring(0, 150) + '...\n');
  
  console.log('🎯 **完整功能列表**：');
  console.log('1. query_attractions - 查询景点信息');
  console.log('2. query_food - 查询美食信息');
  console.log('3. query_transportation - 查询交通信息');
  console.log('4. plan_itinerary - 行程规划');
  console.log('5. general_query - 综合查询\n');
  
  console.log('📋 **使用示例**：');
  console.log('• 查询具体景点："query_attractions" with attraction_name="红海湾"');
  console.log('• 查询美食分类："query_food" with category="特色小吃"');
  console.log('• 查询交通路线："query_transportation" with from_to="深圳到汕尾"');
  console.log('• 规划行程："plan_itinerary" with days=2, travel_type="海滨度假"');
  console.log('• 自然语言查询："general_query" with question="汕尾有什么好玩的"\n');
  
  console.log('📁 **知识库内容**：');
  console.log('• 景点.md - 30+个汕尾景点详细信息');
  console.log('• 美食.md - 20+种汕尾特色美食');
  console.log('• 交通.md - 完整交通指南');
  console.log('• 行程规划.md - 1-3日游行程方案\n');
  
  console.log('✅ **Skill已准备就绪！**');
  console.log('安装到OpenClaw后，用户可以使用触发词激活Skill。');
  console.log('Skill将根据用户问题提供准确的汕尾旅游信息。\n');
  
  console.log('🌊 **汕尾旅游 - 让您的旅程更轻松愉快！**');
}

// 运行演示
runDemo().catch(console.error);