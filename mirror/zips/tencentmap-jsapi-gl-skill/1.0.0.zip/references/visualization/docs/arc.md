## Arc {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建3D弧线图的类，弧线图用以展示两点之间的关联，可以用在迁徙图等表示流向的场景中。
|构造函数|
| :- |
|TMap.visualization.Arc(options:ArcOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setData(dataList:ArcLine[])	|this	|设置数据。|
|getData()	|ArcLine[]	|获取数据。|
|setZIndex(zIndex:Number)	|this	|设置图层绘制顺序。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|setPickStyle(pickStyle: Function)	|this	|设置弧线图样式映射函数。|
|getPickStyle()	|Function	|获取弧线图样式映射函数。|
|setCurvature(curvature: Number)	|this	|设置弧线的曲度。|
|getCurvature()	|Number	|获取弧线的曲度。|
|setMode(mode: String)	|this	|设置弧线的模式，是贴地的弧线或垂直的弧线。|
|getMode()	|String	|获取弧线的模式。|
|setAnimDuration(duration: Number)	|this	|设置动画时间，从起点到终点的运动时间(即将下线，请使用updateAnimation设置duration属性进行动画时间设置)。|
|getAnimDuration()	|Number	|获取动画时间，从起点到终点的运动时间(即将下线，请使用getAnimation获取duration属性)。|
|setHighlightDuration(HighlightTime: Number)	|this	|设置动画的高亮时间，影响弧线上高亮的长度(即将下线，请使用updateAnimation设置tailFactor属性进行动画尾迹时间设置)。|
|getHighlightDuration()	|Number	|获取高亮时间(即将下线，请使用getAnimation获取tailFactor属性)。|
|addTo(map:Map)	|this	|添加至指定地图实例。|
|updateAnimation(type:String, animationOptions: AnimationOptions)	|this	|更新指定类型的动画参数，type支持‘process’，‘toggle’。|
|getAnimation(type:String)	|AnimationOptions	|获取指定类型的动画参数，type支持‘process’，‘toggle’。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
|getMidPositions()  | LatLng[] | 获取图层所有弧线的中点坐标，不支持在大地曲线绘制模式下使用。 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|删除图层。|
|destroy()	|this	|销毁图层对象。|


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|click	|evt:VisualEvent	|点击弧线时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## ArcStyle {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;弧线图样式规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|color	|String\|GradientColor    |弧线颜色，支持rgb(), rgba(), #RRGGBB格式，默认为rgba(56,124,234,0.3)，同时支持渐变色，只支持双色渐变，默认沿弧线生长方向渐变，其中渐变色断点集合需符合GradientColor对象规范。|
|animateColor	|String	|动画颜色，支持rgb(), rgba(), #RRGGBB格式，默认为rgba(29,211,253,1)。|
|width	|Number	|弧线的宽度，默认为4(px)。|

</br></br>
## ArcLine {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;单条弧线数据规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|from	|LatLng	|弧线起点。|
|to	|LatLng	|弧线终点。|
| tilt | Number | 弧线相对于vertical模式的倾斜度，当mode为horizontal时此参数不生效，默认值为0，取值范围为[-90, 90]。以从弧线起点到弧线终点为正方向作参考，左边倾斜度为负数，右边倾斜度为正数，弧线与地面垂直时倾斜度为0。|
| properties | Object | 附加的属性值。  |


</br></br>
## ArcOptions {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;轨迹图配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|pickStyle	|Function	|轨迹图样式映射函数，接收ArcLine数据返回对应样式，样式对象规范详见 ArcStyle 。|
|animatable	|Boolean	|是否开启动画，默认为true(即将下线，请使用processAnimation设置enable属性)。|
|opacity	|Number	|弧线透明度，取值范围(0, 1]，默认0.5，(即将下线，请在ArcStyle中使用rgba格式设置透明度)。|
|width	|Number	|弧线的宽度，默认为1，单位是屏幕像素，(即将下线，请在ArcStyle定义弧线宽度)。|
|mode	|String	|弧线模式，horizontal 代表贴地的弧线，vertical 代表弧线所在平面会垂直于底图平面，默认为vertical。|
|curvature	|Number	|弧线曲度，取值范围(0, 1]，默认为0.6。|
|selectOptions	|VisualSelectOptions	|拾取配置，可设置拾取动作、选中样式、是否使用高亮效果，其中选中样式需符合ArcStyle对象规范。|
|enableBloom	|Boolean	|弧线图呈现泛光效果，默认为false。|
| enableGeodesic | Boolean | 弧线是否开启大地曲线绘制模式，当线段起始端点经度跨度大于180度时，开启后则两端点连线会跨越180度经线进行连线，不开启则跨越0度经线进行连线，默认为false |
|toggleAnimation	|AnimationOptions	|开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出，‘grow’生长两种类型，默认animationType为‘fade’淡入淡出。|
|processAnimation	|ArcAnimationOptions	|过程动画配置参数，不配置则启用默认流动动画。|
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |

</br></br>
## ArcAnimationOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;弧线图过程动画规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|enable	|Boolean	|是否启用，默认为true。|
|tailFactor	|Number	|尾迹比例，取值范围0～1，默认为0.3。|
|animationType	|String	|动画类型名称，支持‘flow’流动一种动画类型，默认为‘flow’流动。|
|duration	|Number	|动画时长，单位毫秒，默认3000。|
|yoyo	|Boolean	|是否回弹，默认false。|
|repeat	|Number	|动画执行次数，默认为Infinity，不支持设置为其他值。|