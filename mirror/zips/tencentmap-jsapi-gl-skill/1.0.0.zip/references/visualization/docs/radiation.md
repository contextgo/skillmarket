
## Radiation {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建辐射图的类，用以展示圆形辐射区域。

|构造函数|
| :- |
|TMap.visualization.Radiation(options:RadiationOptions)|



|方法名|返回值|说明|
|--|--|--|
| setStyles(styles:Object) | this | 设置样式集合。 |
| setData(dataList:RadiationPlane[]) | this | 设置数据。 |
| getData()	 | RadiationPlane[] | 获取数据。 |
| setZIndex(zIndex: Number) | this | 设置图层绘制顺序。 |
| getZIndex() | Number| 获取图层绘制顺序。 |
| setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
| getMinZoom() | Number| 获取图层最小缩放层级。 |
| setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
| getMaxZoom() | Number| 获取图层最大缩放层级。 |
| addTo(map:Map) | this | 添加至指定地图实例。 |
| updateAnimation(type:String, animationOptions:AnimationOptions) | this | 更新指定类别动画参数，type支持'toggle','process'。 |
| getAnimation(type:String) | AnimationOptions| 获取指定类型的动画参数，type支持'toggle','process'。 |
| getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
| setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
| show() | this | 显示图层。 |
| hide() | this | 隐藏图层。 |
| remove() | this | 从地图中删除图层。 |
| destroy() | this | 销毁图层对象。 |
| on(eventName:String, listener:Function) | this | 添加listener到eventName事件的监听器数组中。 |
| off(eventName:String, listener:Function) | this | 从eventName事件的监听器数组中移除指定的listener。 |



| 事件名 | 回调参数 | 说明 |
|--|--|--|
| click | evt:VisualEvent | 点击辐射圈时触发 |
| hover | evt:VisualEvent | 鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null |

</br></br>
## RadiationOptions 对象规范 {#2}
辐射图配置参数。

**属性**

|名称|类型|说明|
|--|--|--|
| styles | Object | 辐射图样式集合，key-value形式。key对应数据中的styleId，value为样式对象，需符合RadiationStyle对象规范。包含default属性，其值作为默认样式，可被覆盖 |
| selectOptions | VisualSelectOptions | 拾取配置，可设置拾取动作、选中样式，其中选中样式需符合RadiationStyle对象规范 |
| number | Number | 每一时刻，辐射圈的同心圆个数，默认为1 |
| enableBloom | Boolean | 辐射图呈现泛光效果，默认为false |
| toggleAnimation | AnimationOptions | 开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出，‘grow’生长两种类型，animationType默认为‘fade’淡入淡出 |
| processAnimation | RadiationProcessAnimationOptions | 过程动画配置参数，不配置则开启默认辐射动画，animationType支持‘radiated’辐射一种动画类型，默认为‘radiated’；repeat仅支持Infinity，默认为Infinity  |
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |

</br></br>
## RadiationStyle 对象规范 {#3}
辐射图样式规范。


|名称|类型|说明|
|--|--|--|
| fillColor | String | 辐射圈填充颜色，支持rgb()、rgba()、#RRGGBB格式，默认为rgba(56, 124, 234, 0.7) |
| strokeColor | String | 辐射圈边线颜色，支持rgb()、rgba()、#RRGGBB格式，默认为rgb(103, 153, 234) |
| strokeWidth | Number | 区域边线宽度，单位为米，默认为1 |
| strokeFadeMode | RADIATION_STROKE_FADE_MODE | 边线渐隐模式，默认为RADIATION_STROKE_FADE_MODE.NONE |


</br></br>
## RadiationPlane 对象规范 {#4}
辐射圈数据规范。

**属性**

|名称|类型|说明|
|--|--|--|
| center | LatLng | 辐射圈中心点经纬度。 |
| styleId | String | 样式id。 |
| radius | Number | 辐射圈半径，单位为米。 |
| properties | Object |附加的属性值。  |

</br>

## RadiationProcessAnimationOptions 对象规范 {#5}

辐射圈过程动画配置参数，继承自 AnimationOptions，增加了以下属性。

| 属性名 | 类型 | 说明 |
| :- | :- |:- |
| fadeFrom | Number | 辐射过程中颜色淡化起始值，取值范围为0~1，默认为0，即从中心开始淡化，直到半径最大处消失。若设置为1，则不会有淡化效果 |

</br>

## TMap.visualization.constants.RADIATION_STROKE_FADE_MODE 常量说明 {#6}

辐射圈边线渐隐模式常量。

| 常量 | 说明 |
| :- | :- |
| RADIATION_STROKE_FADE_MODE.NONE | 无渐隐 |
| RADIATION_STROKE_FADE_MODE.OUTWARD | 向外侧渐隐 |
| RADIATION_STROKE_FADE_MODE.INWARD | 向内侧渐隐 |
| RADIATION_STROKE_FADE_MODE.BOTHWAY | 双向渐隐 |
