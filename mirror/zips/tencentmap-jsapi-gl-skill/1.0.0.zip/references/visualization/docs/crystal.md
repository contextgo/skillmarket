## Prism {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建水晶体的类，用以展示不同高度的建筑轮廓形状和数据分布。
|构造函数|
| :- |
| TMap.visualization.Prism(options:PrismOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setStyles(styles: Object)	|this	|设置样式集合。|
|setData(dataList:AreaPlane[])	|this	|设置数据。|
|getData()	|AreaPlane[]	|获取数据。|
|setZIndex(zIndex:Number)	|this	|设置图层绘制顺序。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|addTo(map:Map)	|this	|添加至指定地图实例。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|从地图中删除图层。|
|destroy()	|this	|销毁图层对象。|
|updateAnimation(type:String, animationOptions: AnimationOptions)	|this	|更新指定类型的动画参数，type支持‘toggle’。|
|getAnimation(type:String)	|AnimationOptions	|获取指定类型的动画参数，type支持‘toggle’。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|


| 事件名 | 回调参数	 | 说明 |
| :- | :- |:- |
|click	|evt:VisualEvent	|	点击区域时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## PrismStyle {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;区域图样式规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|topFillColor	|String\|GradientColor 	|水晶体顶面颜色，支持rgb()、rgba()、#RRGGBB格式，默认为#017CF7，同时支持渐变色，渐变方向由GradientColor对象的angle属性决定，其中渐变色断点集合需符合GradientColor对象规范。|
|sideFillColor	|String\|GradientColor	|水晶体侧面颜色，支持rgb()、rgba()、#RRGGBB格式，默认为#017CF7，同时支持渐变色，渐变方向由GradientColor对象的angle属性决定，其中渐变色断点集合需符合GradientColor对象规范。|
|height	|Number	|水晶体拔起高度，单位为米，默认为0。|
|offset	|Number |水晶体距离地面高度，单位为米，默认为0。|

</br></br>
## PrismOptions {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;区域图配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|styles	|Object	|水晶体样式集合，key-value形式。key对应数据中的styleId，value为样式对象，需符合PrismStyle对象规范。包含default属性，其值作为默认样式，可被覆盖。|
|selectOptions	|VisualSelectOptions	|拾取配置，可设置拾取动作、选中样式，其中选中样式需符合PrismStyle对象规范，不支持设置height和offset。|
|enableBloom	|Boolean	|水晶体呈现泛光效果，默认为false。|
|enableLighting |Boolean |水晶体是否开启光照，默认为true。 |
|toggleAnimation	|AnimationOptions	|开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出，‘grow’生长两种类型，默认animationType为‘fade’淡入淡出。|
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |