## Pipe {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建管线图的类，用以展示管道线。
|构造函数|
| :- |
|TMap.visualization.Pipe(options:PipeOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- | :- |
| setPickStyle(pickStyle: Function) | this | 设置样式集合。 |
| setData(dataList: PipeLine[]) | this | 设置数据。 |
| getData() |  PipeLine[] | 获取数据。 |
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序。|
|getZIndex()		|Number		|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
| addTo(map:Map) | this | 添加至指定地图实例。 |
|updateAnimation(type:String,animationOptions:AnimationOptions)	|this	|更新指定类别动画参数，type支持'toggle'。|
|getAnimation(type:String) |AnimationOptions|获取指定类型的动画参数，type支持'toggle'。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
| show() | this | 显示图层。 |
| hide() | this | 隐藏图层。 |
| remove() | this | 从地图中删除图层。 |
| destroy() | this | 销毁图层对象。 |
| on(eventName:String, listener:Function) | this | 添加listener到eventName事件的监听器数组中。 |
| off(eventName:String, listener:Function) | this | 从eventName事件的监听器数组中移除指定的listener。 |


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
| click |  evt:VisualEvent | 点击管道线时触发。 |
| hover | evt:VisualEvent | 鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null |

</br></br>
## PipeStyle {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;管道图样式规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| color | String | 管道颜色，支持rgb()、rgba()、#RRGGBB格式，默认为rgba(56, 124, 234, 0.7) 。|

</br></br>
## PipeLine {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;管道线数据规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| path | LatLng[] \| PipePoint[] | 管道线经纬度点串。 |
| radius | Number | 管道半径，单位为米。 |
| styleId | String | 样式id。 |
| properties | Object |附加的属性值。  |

</br></br>
## PipePoint {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;管道线单点数据规范，PipePoint是一个Array类型
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| 0 | Number | 纬度。 |
| 1 | Number | 经度。 |
| 2 | Number | （可选）高度，单位为米，默认为0。 |

</br></br>
## PipeOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;管道图配置参数。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| pickStyle | Function | 管道图样式映射函数，接收 PipeLine  数据返回对应样式，样式对象规范详见 PipeStyle。 |
| selectOptions | VisualSelectOptions | 拾取配置，可设置拾取动作、选中样式，其中选中样式需符合 PipeStyle 对象规范。 |
| enableBloom | Boolean | 管道图呈现泛光效果，默认为false。 |
| toggleAnimation 	|AnimationOptions 	| 开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出，‘grow’生长两种类型，animationType默认为‘fade’淡入淡出   |
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |