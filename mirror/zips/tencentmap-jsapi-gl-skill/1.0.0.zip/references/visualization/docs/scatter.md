## Dot {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建3D散点图的类，散点图用以展示海量的独立数据点。
|构造函数|
| :- |
|TMap.visualization.Dot(options:DotOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setStyles(styles: Object)	|this	|设置样式集合，styles为key-value形式。key对应数据中的styleId，value为样式对象，需符合DotCircleStyle或DotImageStyle对象规范。|
|setFaceTo(faceTo: String)	|this	|设置散点朝向，可取map（贴地）或screen（直立）。|
|setData(dataList:DotPoint[])	|this	|设置数据。|
|getData()		|DotPoint[]		|获取数据。|
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序。|
|getZIndex()		|Number		|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|addTo(map:Map)	|this	|添加至指定地图实例。|
|updateAnimation(type:String,animationOptions:AnimationOptions)	|this	|更新指定类别动画参数，type支持'toggle','process'。|
|getAnimation(type:String) |AnimationOptions|获取指定类型的动画参数，type支持'toggle','process'。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|从地图中删除图层。|
|destroy()	|this	|销毁图层对象。|


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|click	|evt:VisualEvent	|点击散点时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## DotCircleStyle{#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;散点图圆形样式规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|type	|String	|取值为circle。|
|fillColor	|String\|GradientColor	|圆形样式属性，填充颜色，支持rgb(),rgba(), #RRGGBB格式，默认为rgba(56,124,234,0.75), 同时支持渐变色，只支持双色渐变，默认沿弧线生长方向渐变，其中渐变色断点集合需符合GradientColor对象规范。
|strokeColor	|String	|圆形样式属性，边线颜色，支持rgb(),rgba(), #RRGGBB格式。|
|strokeWidth	|Number	|圆形样式属性，边线宽度，不可为负数，默认为0(px)。|
|radius	|Number	|圆形样式属性，圆形半径，不可为负数，默认为4(px)。|

</br></br>
## DotImageStyle{#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;散点图图片样式规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|type	|String	|取值为image。|
|width	|Number	|图片样式属性，图片显示宽度，不可为负数，默认为10(px)。|
|height	|Number	|图片样式属性，图片显示高度，不可为负数，默认为10(px)。|
|anchor	|Object	|图片的锚点位置，对象字面量{x:Number, y:Number}形式，以图片左上角为原点，x轴向右为正，y轴向下为正，默认为{ x: width/2, y: height/2 }，即图片中心点。|
|src	|String	|图片样式属性，图片url或base64地址。|

</br></br>
## DotPoint {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;单点数据规范。
| 属性名称 | 类型 | 说明 |
| :- | :- |:- |
|lat	|Number	|（必需）纬度。|
|lng	|Number	|（必需）经度。|
|styleId	|String	|点样式ID。|
| properties | Object | 附加的属性值。  |

</br></br>
## RadiatedAnimationOptions 对象规范 {#6}
----
&nbsp;&nbsp;&nbsp;&nbsp;辐射动画配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| type	| String	|动画类型为辐射动画，取值radiated    |
| playRate	| Number	|动画播放倍速，默认为1(播放周期为1000ms)    |
| enableFade	| Boolean	|动画的辐射效果是否渐变消失，默认为false    |

</br></br>
## BeatingAnimationOptions 对象规范 {#7}
----
&nbsp;&nbsp;&nbsp;&nbsp;跳动动画配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
| type	| String	|动画类型为跳动动画，取值beating   |
| playRate	| Number	|动画播放倍速，默认为1(播放周期为1000ms)    |
| amplitude	| Number	|动画跳动的幅度，单位为像素高度    |


</br></br>
## DotAnimationOptions  {#8}
----
&nbsp;&nbsp;&nbsp;&nbsp;属性。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|enable	|Boolean	|是否启用，默认为true。|
|beatingAmplitude	|Number	|beating幅度，默认为5，仅在动画类型为‘beating’时生效。|
|enableFade	|Boolean	|动画的辐射效果是否渐变消失，默认为false，仅在动画类型为‘radiated’时生效。|
|animationType	|String	|动画类型名称，支持‘beating’跳动，‘radiated’辐射两种类型，默认为‘radiated’辐射。|
|duration	|Number	|动画时长，单位毫秒，默认2000。|
|repeat	|Number |迭代次数，默认Infinity，不支持设置为其他值。|
|yoyo	|Boolean	|是否回弹，默认false。|

</br></br>
## DotOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;散点图配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|styles	|Object	|散点图样式集合，key-value形式。key对应数据中的styleId，value为样式对象，需符合 CircleDotStyle 或 ImageDotStyle 对象规范。|
|faceTo	|String	|散点固定的朝向，可取map（贴地）或screen（直立），默认为screen。|
|selectOptions	|VisualSelectOptions	|拾取配置，可设置拾取动作、选中样式、是否使用高亮效果，其中选中样式需符合CircleDotStyle或ImageDotStyle对象规范。|
|animation	|RadiatedAnimationOptions \| BeatingAnimationOptions	| 散点动画参数 (1.1.0及以上版本即将下线，请使用processAnimation设置动画属性）。 |
|enableBloom	|Boolean	|散点图呈现泛光效果，默认为false。|
|toggleAnimation 	|AnimationOptions 	| 开关动画配置参数，不配置则无开关动画效果，支持animationType为‘fade’淡入淡出一种类型，默认为‘fade’淡入淡出   |
|processAnimation 	|DotAnimationOptions 	| 过程动画配置参数，不配置则无过程动画   |
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |
