## Heat {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建热力图的类，热力图以颜色来表现数据强弱大小及分布趋势。
|构造函数|
| :- |
|TMap.visualization.Heat(options:HeatOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setMin(min:Number)	|this	|设置热力最弱阈值，小于该值的不显示，默认为0。|
|getMin()	|Number	|获取热力最弱阈值。|
|setMax(max:Number)	|this	|设置热力最强阈值，大于该值的显示为最强色，默认为数据中的最大值。|
|getMax()	|Number	|获取热力最强阈值。|
|setRadius(radius: Number)	|this	|设置热力图辐射半径。|
|getRadius()	|Number	|获取热力图辐射半径。|
|setGradientColor(gradientColor: GradientColor)	|this	|设置热力图渐变颜色。|
|getGradientColor()	|GradientColor	|获取热力图渐变颜色。|
|setHeight(height: Number)	|this	|设置热力图高度。|
|getHeight()	|Number	|获取热力图高度。|
|setOpacity(opacity: Number)	|this	|设置热力图透明度。|
|getOpacity()	|Number	|获取热力图透明度。|
|setThreshold(min:Number, max:Number)	|this	|设置热力阈值范围。|
|setData(dataList:HeatPoint[] )	|this	|设置数据。|
|getData()	|HeatPoint[]	|获取数据。|
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|setOffset(offset: Number) | this | 设置图层底部离地高度。 |
|getOffset()  | Number| 获取图层底部离地高度。 |
|addTo(map:Map )	|this	|添加至指定地图实例。|
|updateAnimation(type:String, animationOptions:AnimationOptions )	|this	|更新指定类别动画参数，type支持'toggle'，'transit'两种。|
|getAnimation(type:String)	|AnimationOptions 	|获取指定类别动画参数，type支持'toggle'，'transit'两种。|
| setHeatDotEnable(enable: Boolean) | this | 设置是否开启自动切换散点图功能 |
| getHeatDotEnable() | Boolean | 获取是否开启自动切换散点图状态 |
| setHeatDotOptions(heatDotOptions: HeatDotOptions) | this | 设置自动切换散点图相关配置 |
| getHeatDotOptions() | HeatDotOptions | 获取自动切换散点图相关配置 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|从地图中删除图层。|
|destroy()	|this	|销毁图层对象。|

</br></br>
## HeatOptions  {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;热力图配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|radius	|Number	|最大辐射半径，默认为50。|
|height	|Number	|峰值高度，默认为100。|
|gradientColor	|GradientColor	|渐变颜色，渐变方向由GradientColor对象的angle属性决定，其中渐变色断点集合需符合GradientColor对象规范 |
|min	|Number	|热力最弱阈值，小于该值的不显示，默认为0。|
|max	|Number	|热力最强阈值，大于该值的显示为最强色，默认为数据中的最大值。|
|opacity	|Number	|全局透明度，取值范围[0，1]，默认为0.8。|
|enableAggregation | Boolean | 是否启用自动聚合预处理，适用于万级数据量，启用后可优化运行时性能，但对数据分布略有影响。默认为false。 |
|enableLighting | Boolean | 热力图是否呈现光照效果，默认为false。 |
|transitAnimation	|AnimationOptions 	|热力图数据源切换过渡动画配置参数，不配置则无过渡动画。支持animationType为‘mix’渐变一种类型，默认animationType为‘mix’渐变。|
|toggleAnimation 	|AnimationOptions 	|开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出一种类型，默认animationType为‘fade’淡入淡出。|
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |
|offset| Number | 图层底部离地高度，默认为0。 |
|distanceUnit| String | radius(半径)、height(峰值高度)、offset(离地高度)三个参数的单位，支持'pixel' 像素、'meter' 米，默认为'pixel'。 |
| enableHeatDot | Boolean | 热力图是否开启自动切换散点图效果，默认为false。|
| heatDotOptions | HeatDotOptions | 自动切换散点图相关配置参数。 |

</br></br>
## HeatPoint {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;热力图单点数据规范。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|lat	|Number	|纬度。|
|lng	|Number	|经度。|
|count	|Number	|（可选）热力权重，正整数，默认为1。|
| properties | Object | （可选）附加的属性值。  |

</br></br>
## HeatDotOptions {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;切换散点图相关配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
| radius | Number | 散点半径，默认为热力图最大辐射半径的一半 |
| minZoom | Number | 散点图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，minZoom需大于等于热力图设定的minZoom，默认为14 |
| maxZoom  | Number | 散点图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，maxZoom需小于等于热力图设定的maxZoom，默认为热力图设定的maxZoom |
| opacity | Number | 散点图层透明度，取值范围[0, 1]，默认为1.0 |
| fillColors | String[] | 散点颜色数组，每个散点将根据自身count属性值指定为数组中的对应颜色，默认为热力图中配置的渐变颜色，如[ '#13B06A', '#13B06A',  '#E9AB1D', '#E9AB1D',  '#E05649']，支持rgb(),rgba(), #RRGGBB格式 |
| strokeColor | String | 散点边线颜色，支持rgb(),rgba(), #RRGGBB格式，默认为'#FFF' |
| strokeWidth | Number | 散点边线宽度，不可为负数，默认为0(px)  |
| fadeArray | Number[] | 展现切换动画的层级，默认为[14,16], 表示在zoom层级为14时，热力图开始淡出（透明度减少），散点图开始淡入（透明度增加）； 在zoom层级为16时，热力图完全隐藏，散点图达到指定的散点图层透明度； fadeArray中的数值必须在散点图指定的minZoom与maxZoom范围内，且fadeArray[0]小于fadeArry[1]。  查看示例|