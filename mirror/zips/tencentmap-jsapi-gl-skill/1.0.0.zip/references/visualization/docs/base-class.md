## AnimationOptions {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;动画配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|enable	|Boolean	|	是否启用，默认为true|
|animationType	|String	|动画类型，各图层类型可支持动画类型不同，详见各图层类型动画说明|
|duration	|Number	|	动画时长，单位毫秒 默认2000|
|repeat	|Number	|动画执行次数，正整数，默认1。|
|yoyo	|Boolean	|是否回弹，若开启动画会从0过渡到1后再从1过渡回0，整个过程算两次执行，当repeat大于1时生效，默认false。|

</br></br>
