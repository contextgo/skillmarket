##  DistrictOverlay {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;行政区划图层，支持传入行政区划adcode，提供高品质的行政区划显示能力。

|构造函数|
| :- |
|TMap.visualization.DistrictOverlay(options:DistrictOverlayOptions)|

**方法**
| 方法名 | 返回值 | 说明 |
| :- | :- | :- |
| setStyle(style: DistrictOverlayStyle) | this | 设置行政区划图层样式 |
| getStyle() | DistrictOverlayStyle| 获取行政区划图层样式 |
| setAdcode(adcode: String) | this | 设置行政区划adcode |
| getAdcode() | String | 获取行政区划adcode |
| setVisible(visible: Boolean) | this | 设置行政区划图层的可见性 |
| getVisible() | Boolean | 获取行政区划图层的可见性 |
| setBGImageVisible(visible: Boolean) | this | 设置背景图的可见性 |
| getBGImageVisible() | Boolean | 获取背景图的可见性 |
| on(eventName:String, listener:Function)|this|添加listener到eventName事件的监听器数组中。|
| off(eventName:String, listener:Function)|this|从eventName事件的监听器数组中移除指定的listener。|
| destroy()| | 销毁添加的行政区划图层|


| 事件名 | 参数 | 说明 |
| :- | :- | :- |                                    
|click|DistrictOverlayEvent|点击事件|

## DistrictOverlayOptions 对象规范 {#2}
行政区划图层参数
| 名称 | 类型 | 说明 |
| :- | :- | :- |
| map | Map | 地图对象 |
| adcode | String | 行政区划的编码 |
| style | DistrictOverlayStyle| 行政区划的样式配置 |

## DistrictOverlayStyle 对象规范 {#3}
行政区划样式
| 名称 | 类型 | 说明 |
| :- | :- | :- |
| topColor | String \| GradientColor| 行政区划顶面填充色，支持rgb()，rgba()，#RRGGBB等形式，支持设置渐变色，支持设置自定义图片url或base64地址，若为url地址图片一定要在服务器端配置允许跨域。 |
| sideColor | String \| GradientColor| 行政区划侧面填充色，支持rgb()，rgba()，#RRGGBB等形式，支持设置渐变色，支持设置自定义图片url或base64地址，若为url地址图片一定要在服务器端配置允许跨域。 |
| extrudeHeight | Number | 行政区划拔起高度，单位米，默认值为2500 |
| backgroundImage | String | 行政区划周边背景图url或base64地址，若为url地址图片一定要在服务器端配置允许跨域。 | 
| borderColor    |String  | 边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为#75baff。|
| borderWidth   |Number |边线宽度，正整数，单位为像素，默认为2。|
| wallHeight | Number | 发光围墙高度，高度从行政区划顶面起算，取值范围[0,500000]，单位为米。默认值为2500。 |
| wallColor  | String | 发光围墙颜色，支持rgb()，rgba()，#RRGGBB等形式。  |
| childrenStyle |DistrictChildrenStyle  |子行政区样式。|


## DistrictChildrenStyle 对象规范 {#4}
子行政区划样式   
| 名称 | 类型 | 说明 |
| :- | :- | :- |
| borderColor    |String  | 子行政区划边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(255,255,255,1)。|
| borderWidth   |Number | 子行政区划边线宽度，正整数，单位为像素，默认为2。|
| borderDashArray   |Number[]   | 子行政区划边线虚线虚线展示方式，[0, 0]为实线，[10, 10]表示十个像素的实线和十个像素的空白（如此反复）组成的虚线，默认为[0, 0]。|
| showLabel     |Boolean |  是否显示子行政区划文字，默认为true。|
| labelSize    |String  |   子行政区划文字大小属性，默认为14。|
| labelColor    |String  |  子行政区划文字颜色属性，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(255,255,255,1)。|
| labelFaceTo     |String  |	子行政区划文字的朝向，可取map（贴地）或screen（直立），默认为map。|

## DistrictOverlayEvent 对象规范 {#5}
行政区划点击事件返回参数规范。

**属性**

| 名称 | 类型 | 说明 |
| -- | -- | -- |
| adcode | String | 子行政区划的adcode |
| name | String | 子行政区划的全称 |
| location | LatLng| 子行政区划的经纬度位置 |
| latLng | LatLng| 事件发生时的经纬度坐标 |
| type | String | 事件类型 |
| target | DistrictOverlay | 事件的目标对象 |
| originalEvent | MouseEvent 或 TouchEvent | 浏览器原生的事件对象 |