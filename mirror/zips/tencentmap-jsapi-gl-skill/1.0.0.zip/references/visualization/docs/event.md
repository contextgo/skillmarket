## VisualEvent {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;可视化事件返回参数规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|latLng	|LatLng	|事件发生时的经纬度坐标。|
|type	|String	|事件类型。|
|target	|Object	|事件的目标对象。|
|originalEvent	|MouseEvent 或 TouchEvent	|浏览器原生的事件对象。|
|detail	|VisualDetail	|与可视化组件实例相关的数据对象，包含特定事件下返回的数据信息。|

</br></br>
## VisualDetail {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;可视化事件实例数据对象规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|aggregator	|AggregatorObject	|与拾取到的聚合后的物体相关的数据对象；该属性适用于Grid和Hexagon实例上的相关事件。|
|arc	|ArcLine	|拾取到的弧线的原始数据对象；该属性适用于Arc实例上的相关事件。|
|dot	|DotPoint	|拾取到的散点的数据对象；该属性适用于Dot实例上的相关事件。|
|area	|AreaPlane	|拾取到的区域的数据对象；该属性适用于Area实例上的相关事件。|

</br></br>
## AggregatorObject {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;与拾取到的聚合后的物体相关的数据对象规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|count	|Number	|热力值。|
|centroid	|LatLng	|聚合中心点的经纬度。|
|rawData	|Object[]	|参与聚合的原始数据列表。|
|indexes	|Number[]	|参与聚合的原始数据在原data中的索引位置。|

</br></br>
## VisualSelectOptions {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;可视化图形拾取配置。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|action	|Null / String	|拾取动作，可枚举值为null、'click'、'hover'，默认为null。若为null，则不会触发任何图形被选中；若为'click'则单击图形将触发其被选中；若为'hover'则鼠标悬停于图形上方触发其被选中。|
|style	|*	|选中样式，图形被选中后将显示为该样式，在不同可视化类型中该参数的对象规范不同。默认为null，即不更改样式。注：配置style时需对支持的各个属性都进行指定才会生效，否则无选中效果。选中样式暂不支持渐变色。|
|enableHighlight	|Boolean	|是否使用高亮效果。默认为true，即未被选中的图形透明度将大幅降低，以凸显选中图形和地图。|