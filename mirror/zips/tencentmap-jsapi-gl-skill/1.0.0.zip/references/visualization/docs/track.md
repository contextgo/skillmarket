## Trail {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建轨迹图的类，轨迹图用以展示目标移动轨迹。
|构造函数|
| :- |
|TMap.visualization.Trail(options:TrailOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setData(dataList:TrailLine[])	|this	|设置数据。|
|getData() | TrailLine[] | 获取数据。 |
|setZIndex(zIndex: Number) | this | 设置图层绘制顺序。 |
|getZIndex() | Number| 获取图层绘制顺序。 |
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|setPickStyle(pickStyle: Function)	|this	|设置轨迹样式映射函数。|
|getPickStyle()	|Function	|获取轨迹样式映射函数。|
|setShowDuration(showDuration: Number)	|this	|设置动画中轨迹点高亮的持续时间。|
|getShowDuration()	|Number	|获取动画中轨迹点高亮的持续时间。|
|setPlayRate(playRate: Number)	|this	|设置轨迹图播放倍速。|
|getPlayRate()	|Number	|获取轨迹图播放倍速。|
|updateAnimation(type:String, animationOptions:AnimationOptions)|void|更新指定类别动画参数，类别包括‘toggle’一种。|
|getAnimation(type:String) | AnimationOptions | 获取指定类型的动画参数，类别包括‘toggle’一种。 |
|addTo(map:Map)	|this	|添加至指定地图实例。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|从地图中删除图层。|
|destroy()	|this	|销毁图层对象。|


|事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|click	|evt:VisualEvent	|点击轨迹时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## TrailStyle {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;轨迹图样式规范。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|color	|String \| GradientColor	|轨迹颜色，支持rgb()、rgba()、#RRGGBB格式，默认为#387CEA。同时支持渐变色，默认沿轨迹生长方向渐变，其中渐变色断点集合需符合GradientColor对象规范 。|
|width	|Number	|轨迹宽度，默认为4(px)。|

</br></br>
## TrailLine {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;单条轨迹数据规范。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|path	|TrailPoint[]	|轨迹点数组，轨迹点为纬度、经度、时间戳（可选）构成的数组，轨迹点需要按照时间从小到大排序。|
|colorOffset	|Number[]	|（可选）轨迹点对应的颜色偏移值数组，偏移值范围为[0,1]，数组长度与轨迹点数组需保持一致，且值顺序一一对应，，若不传入颜色偏移数组或者传入数据不符合要求，则默认按照轨迹点所处轨迹线的位置百分比进行线性渐变。|
| properties | Object |（可选）附加的属性值。  |

</br></br>
## TrailPoint {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;单条轨迹数据规范。
|索引	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		|说明|
| :- | :- |:- |
|0	|Number	|纬度。|
|1	|Number	|经度。|
|2	|Number \| String	|（可选）时间戳，支持Unix Timestamp或者符合RFC2822的字符串，若不传入时间点，则默认以1m/s匀速移动。|

</br></br>
## TrailOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;轨迹图配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- |:- |
|pickStyle	|Function	|轨迹图样式映射函数，接收TrailLine数据返回对应样式，样式对象规范详见TrailStyle。|
|showDuration	|Number	|动画中轨迹亮部持续时间，正数，默认5s，当设置为Infinity时轨迹将一直显示。|
|startTime	|Number	|动画循环周期的起始时间戳，支持Unix Timestamp或者符合RFC2822的字符串，默认为数据中的最小时间。|
|endTime	|Number	|动画循环周期的结束时间戳，支持Unix Timestamp或者符合RFC2822的字符串，默认为数据中的最大时间，需大于startTime。|
|playRate	|Number	|动画播放倍速，默认为1。|
|playTimes |Number	|动画播放次数，正整数，默认为Infinity。|
|selectOptions	|VisualSelectOptions	|拾取配置，可设置拾取动作、选中样式、是否使用高亮效果，其中选中样式需符合TrailStyle对象规范。|
|enableGeodesic | Boolean | 轨迹线是否开启大地曲线绘制模式，当线段起始端点经度跨度大于180度时，开启后则两端点连线会跨越180度经线进行连线，不开启则跨越0度经线进行连线，默认为false。 |
|toggleAnimation |AnimationOptions| 开关动画配置参数，不配置则无开关动画效果。支持animationType为'fade'淡入淡出动画一种类型。|
|enableHighlightPoint |Boolean| 是否显示头部高亮点，默认值为false。|
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |
|enableColorOffset | Boolean | 是否根据colorOffset来进行渐变色渲染，默认为false。 |