## Wall {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;是用于创建围墙面，用以展示重点区域、围栏等。
|构造函数|
| :- |
|TMap.visualization.Wall(options:WallOptions)|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setData(dataList:WallLine[])	|this	|设置数据。|
|getData()	|WallLine[]	|获取数据。|
|setZIndex(zIndex:Number)	|this	|设置图层绘制顺序。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|setMinZoom(minZoom: Number) | this | 设置图层最小缩放层级，当地图缩放层级小于该值时该图层不显示。 |
|getMinZoom() | Number| 获取图层最小缩放层级。 |
|setMaxZoom(maxZoom: Number) | this | 设置图层最大缩放层级，当地图缩放层级大于该值时该图层不显示。 |
|getMaxZoom() | Number| 获取图层最大缩放层级。 |
|setStyles(styles:Object)	|this	|设置样式。|
|addTo(map:Map)	|this	|添加至指定地图实例。|
|updateAnimation(type:String, animationOptions: AnimationOptions)	|this	|更新指定类型的动画参数，type支持‘process’，‘toggle’。|
|getAnimation(type:String)	|AnimationOptions	|获取指定类型的动画参数，type支持‘process’，‘toggle’。|
|getSelectOptions()  | VisualSelectOptions | 获取拾取配置。 |
|setSelectOptions(selectOptions: VisualSelectOptions) | this | 设置拾取配置。 |
|show()	|this	|显示图层。|
|hide()	|this	|隐藏图层。|
|remove()	|this	|删除图层。|
|destroy()	|this	|销毁图层对象。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|click	|evt:VisualEvent	|点击围墙面时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## WallStyle {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;围墙面样式规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|texture	|String	|纹理文件路径url，在墙体上重复拼接的图片，支持png、jpg、jpeg格式，优先级高于color。|
|color	|String\|GradientColor    |围墙面颜色，支持纯色或渐变色，颜色支持rgb()、rgba()、#RRGGBB格式，默认为rgba(255, 255, 255, 1)，渐变方向由GradientColor对象的angle属性决定，其中渐变色断点集合需符合GradientColor对象规范。|
|repeatX	|Number	|纹理横轴重复次数，取值范围 (0,100]默认1。|
|repeatY	|Number	|纹理纵轴重复次数，取值范围 (0,100]默认1。|
|strokeColor  | String | 边线颜色，只支持纯色，颜色支持rgb()、rgba()、#RRGGBB格式，默认值为#1DFAF2 |
|strokeWidth  | Number | 边线宽度，单位为像素，默认为0|

</br></br>
## WallLine {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;围墙面数据规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|styleId	|String	|围墙面样式配置id。|
|path	|LatLng[]	|经纬度数组。|
|height	|Number	|围墙面高度，取值范围(0,500000]，默认10。|
| properties | Object |附加的属性值。  |


</br></br>
## WallOptions {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;围墙面配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|styles	|Object	|围墙面样式集合，key-value形式。key对应数据中的styleId，value为样式对象，需符合WallStyle对象规范。|
|selectOptions	|VisualSelectOptions	|拾取配置，可设置拾取动作、选中样式、是否使用高亮效果，其中选中样式为String类型的颜色值。|
|enableBloom	|Boolean	|围墙面呈现泛光效果，默认为false。|
|toggleAnimation	|AnimationOptions	|开关动画配置参数，不配置则无开关动画效果。支持animationType为‘fade’淡入淡出，‘grow’生长两种类型，默认animationType为‘fade’淡入淡出。|
|processAnimation	|WallAnimationOptions	|过程动画配置参数，不配置则无过程动画。|
|enableAutoClose| Boolean | 设置围墙面是否自动闭合，设置为自动闭合，则会自动把首尾点连起来构成封闭的围墙面，默认为false |
|zIndex | Number | 图层绘制顺序。 |
|minZoom | Number | 图层最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3。 |
|maxZoom | Number | 图层最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20。 |


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|click	|evt:VisualEvent	|点击棱柱时触发。|
|hover	|evt:VisualEvent	|鼠标悬停目标改变时触发，若悬停在图形外部，则返回结果中的拾取对象为null。|

</br></br>
## WallAnimationOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;围墙面过程动画规范。
| 属性名称 | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|enable	|Boolean	|是否启用，默认为true。|
|flowDirection	|String	|流动方向，‘horizontal‘水平流动，’vertical‘垂直流动，默认‘horizontal’水平流动，仅在动画类型为‘flow’时生效。|
|breathAmplitude	|Number	|呼吸幅度，透明度降低，默认0.2，如默认透明度为0.8，幅度设为0.3后则透明度将在0.5～0.8之间波动，仅在动画类型为‘breath’时生效。|
|animationType	|String	|动画类型名称，支持‘flow’流动，‘breath’呼吸两种动画类型，默认为‘flow’流动。|
|duration	|Number	|动画时长，单位毫秒，默认2000。|
|yoyo	|Boolean	|是否回弹，默认false。|
|repeat	|Number	|动画执行次数，默认为Infinity，不支持设置为其他值。|