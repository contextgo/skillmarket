## GeometryEditor {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;几何图形编辑器。
|编辑器交互操作|说明|
| :- | :- |
|绘制|鼠标左键点击及移动即可绘制图形|
|结束绘制|鼠标左键双击即可结束绘制折线、多边形、圆形，多边形会自动闭合|
|单选|鼠标左键点击图形|
|多选|按下ctrl键后点击多个图形|
|删除|选中图形后按下delete键可删除图形|
|拆分|选中单个多边形后可绘制拆分线，拆分线绘制完成后自动进行拆分|
|中断|绘制或编辑过程中按下esc键可中断该过程|


|构造函数|
| :- |
|new TMap.tools.GeometryEditor(options)|


|参数名称|类型|说明|
| :- | :- |
|options	|GeometryEditorOptions	|几何编辑器配置参数|


| 方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setMap(map: Map)	|this	|设置地图对象，若为null则移除编辑器|
|setActiveOverlay(id: String)	|this	|设置指定图层处于编辑状态|
|setActionMode(mode: EDITOR_ACTION)	|this	|设置编辑器的操作状态|
| setKeyboardDeleteEnable(enable: Boolean)  | this | 设置编辑器Delete按键（删除）事件是否开启 |
| setKeyboardCtrlEnable(enable: Boolean)  | this | 设置编辑器Ctrl按键（多选）事件是否开启 |
| setKeyboardEscEnable(enable: Boolean)  | this | 设置编辑器Esc按键（中断操作）事件是否开启 |
| setUndoDrawEnable(enable: Boolean)  | this | 设置编辑器绘制撤销功能是否开启 |
| setSnapPolyStartPointOnDrawing | this | 设置编辑器绘制过程中是否允许线、面吸附自身第一个点 |
|getMap()	|Map	|获取绑定的地图对象|
|getActiveOverlay()	|EditableOverlay	|获取处于编辑状态的图层|
|getActionMode()	|EDITOR_ACTION	|获取编辑器的操作状态|
|getSelectedList()	|Geometry[]	|获取已选中的几何图形数组，Geometry可能是PointGeometry/PolylineGeometry/PolygonGeometry/CircleGeometry等|
| getKeyboardDeleteEnable()  | Boolean | 获取编辑器Delete按键（删除）事件开关状态 |
| getKeyboardCtrlEnable()  | Boolean | 获取编辑器Ctrl按键（多选）事件开关状态 |
| getKeyboardEscEnable()  | Boolean | 获取编辑器Esc按键（中断操作）事件开关状态 |
| getUndoDrawEnable()  | Boolean | 获取编辑器绘制撤销功能开关状态 |
| getSnapPolyStartPointOnDrawing | Boolean | 获取编辑器绘制过程中是否允许线、面吸附自身第一个点 |
|addOverlay(overlay: EditableOverlay)	|this	|添加用于编辑的几何图层|
|removeOverlay(id: String)	|this	|删除用于编辑的几何图层|
|getOverlayList()	|EditableOverlay[]	|获取图层列表|
|setSnappable(snappable: Boolean)	|this	|开启或关闭吸附功能，吸附功能开启时绘制或编辑图形会自动吸附到临近的点或线段上|
|setSelectable(selectable: Boolean)	|this	|开启或关闭点选功能，点选功能开启时用户可点击图形进行单选和多选，选中图形后会自动将其所属图层设置为编辑状态|
|select(idList: String[]) |this	|选中属于激活状态的图层内的几何图形，若传入空数组则清空|
|stop()	|this	|停止绘制或编辑过程|
|split()	|this	|拆分已选中多边形，用户可绘制拆分线进行拆分，若无选中图形则无效|
|union()	|this	|合并已选中多边形，若无选中图形则无效|
|delete()	|this	|删除已选中图形|
|destroy()	|this	|销毁编辑器|
|on(eventName:String, listener:Function)|this	|添加listener到eventName事件的监听器数组中|
|off(eventName:String, listener:Function)|this	|从eventName事件的监听器数组中移除指定的listener器|

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。 查看示例

| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明 |
| :- | :- |:- |
|active_changed	|	|切换编辑图层，调用setActiveOverlay接口、选中其他图层元素或删除一个处于编辑状态的图层都会引发此事件|
|select	|	|点选图形|
|drawing	|EditingEvent	|绘制中，返回绘制中信息|
|draw_complete	|Geometry	|绘制完成，返回几何图形|
| draw_error | DrawErrorMessage| 绘制失败，返回失败信息 |
|adjusting|EditingEvent	|修改中，返回修改中的信息|
|adjust_complete	|Geometry	|修改完成，返回修改后的几何图形|
| adjust_error | AdjustErrorMessage | 编辑失败，返回失败信息 |
|delete_complete	|Geometry[]	|删除完成，返回被删除的几何图形|
|split_complete	|PolygonGeometry[]	|拆分完成，返回拆分后的多边形数组|
|union_complete	|PolygonGeometry	|合并完成，返回合并后的多边形|
|split_fail	|Object	|拆分失败，返回对象中的message属性说明了失败原因|
|union_fail	|Object	|合并失败，返回对象中的message属性说明了失败原因|


</br></br>
## GeometryEditorOptions {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;几何编辑器配置参数对象规范。
|属性名称	|类型	|说明|
| :- | :- |:- |
|map	|Map	|编辑几何图形的地图对象|
|overlayList	|EditableOverlay[]	|用于编辑的几何图层|
|activeOverlayId	|String	|处于编辑状态的图层id，编辑状态下的图层可以新增图形、选中图形进行修改和删除|
|actionMode	|EDITOR_ACTION[]	|编辑器的操作状态|
|snappable	|Boolean	|是否开启吸附功能，默认为false|
|selectable	|Boolean	|是否开启点选功能，默认为false，开启后可以点选图形进行修改和删除操作|
|iconInfo	|EditorIconInfo	|编辑器的icon样式|
| modifierShapeMode | MODIFIER_SHAPE_MODE | 图形被选中编辑时的渲染模式，默认为SVG模式 |
| enableKeyboardDelete   | Boolean | 是否启用默认的Delete按键（删除）事件，默认为true |
| enableKeyboardCtrl   | Boolean | 是否启用默认的Ctrl按键（多选）事件，默认为true |
| enableKeyboardEsc   | Boolean | 是否启用默认的Esc按键（中断操作）事件，默认为true |
| enableUndoDraw   | Boolean | 是否启用编辑器绘制撤销功能，默认为true |
| snapPolyStartPointOnDrawing | Boolean | 编辑器在开启吸附后，绘制过程中是否允许线、面吸附自身的第一个点,默认为true |

</br></br>
## EditableOverlay {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;可编辑几何图层对象规范。
|属性名称	|类型	|说明|
| :- | :- |:- |
|id	|String	|标识，默认为图层id|
|name	|String	|在控件下拉列表中显示的图层名称|
|overlay	|GeometryOverlay	|几何图层，支持MultiMarker/MultiPolyline/MultiPolygon/MultiRectangle/MultiCircle/MultiEllipse|
|drawingStyleId	|String	|绘制图形的样式id，对应图层styles样式表中的id，默认为default|
|selectedStyleId	|String	|选中图形的样式id，对应图层styles样式表中的id，若不设置则使用默认样式|
| checkShape   | Function | 对于该图层图形绘制或编辑时的即时校验方法, 传入参数为EditingEvent,通过自定义该校验方法返回boolean值来处理当前编辑行为是否生效，该方法形式如下：Function(shape：EditingEvent): boolean |

</br></br>
## TMap.tools.constants.EDITOR_ACTION {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;编辑器操作模式。
|常量	|说明|
| :- | :- |
|EDITOR_ACTION.INTERACT	|交互模式，该模式下用户可选中图形进行删除、修改|
|EDITOR_ACTION.DRAW	|绘制模式，该模式下用户可绘制新图形|

</br></br>
## MODIFIER_SHAPE_MODE 常量说明 {#MODIFIER_SHAPE_MODE}
---
选中编辑时图形的渲染模式。
| 常量 | 说明 |
| - | - |
| MODIFIER_SHAPE_MODE.SVG | 采用SVG模式来渲染被选中编辑的图形，当数据形点较少时建议使用该模式；默认为该模式 |
| MODIFIER_SHAPE_MODE.GL | 采用webgl模式来渲染被选中编辑的图形，当编辑的数据形点量级较大时使用该模式性能较好，但图形的渲染质量可能受机器配置影响 |

</br></br>

## EditorIconInfo 对象规范 {#EditorIconInfo}
----
&nbsp;&nbsp;&nbsp;&nbsp;编辑器所包含的icon信息对象。
| 属性名  | 类型      | 说明               |
| :------ | :-------- | :----------------- |
| virtual |IconStyle | 改变虚点icon的样式 |
| actual  | IconStyle | 改变实点icon的样式 |
!

</br></br>
## IconStyle 对象规范 {#IconStyle}
----
&nbsp;&nbsp;&nbsp;&nbsp;编辑器icon的样式对象，可以设置src、宽高等属性。
| 属性名 &nbsp;&nbsp; | 类型  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    | 说明               |
| :------ | :-------- | :----------------- |
|  src   | String | 编辑点图片url或base64地址，若为url地址图片一定要在服务器端配置允许跨域 |
| width  | Number |                    图片的宽度，默认为10px                    |
| height | Number |                    图片的高度，默认为10px                    |
| anchor | Object | 图片的锚点位置，对象字面量{x:Number, y:Number}形式，在地图各种操作中，锚点的位置与标注位置点是永远对应的；若没有锚点默认为{ x: width / 2, y: height / 2 }；锚点以图片左上角点为原点 |

</br></br>
## EditingEvent 对象规范 {#EditingEvent}
----
&nbsp;&nbsp;&nbsp;&nbsp;编辑器所包含的icon信息对象。
| 属性名 &nbsp;&nbsp;| 类型&nbsp;&nbsp;     | 说明               |
| :------ | :-------- | :----------------- |
| position | LatLng   | 鼠标当前所在的经纬度 |
| geometry | Geometry | 几何图形信息，在最开始绘制时值为null   |


</br></br>
## DrawErrorMessage 对象规范 {#9}

&nbsp;&nbsp;&nbsp;&nbsp;编辑器绘制失败错误信息。

|  属性名  |   类型   |         说明         |
| - | - | - |
| errorDesc | String  | 错误描述 |
| errorType | Number |  错误类型   |
| errorGeometry | Geometry | 错误几何图形信息（errorType为2时提供） |

现有绘制错误类型说明：
- 多边形自相交错误信息：{ errorDesc: 'geometry illegals', errorType: 1 }
- 矩形、圆形、椭圆未通过校验方法信息：{ errorDesc: 'geometry check failed', errorType: 2 }


</br></br>

## AdjustErrorMessage 对象规范 {#AdjustErrorMessage}

&nbsp;&nbsp;&nbsp;&nbsp;编辑器编辑失败错误信息。

|  属性名  |   类型   |         说明         |
| - | - | - |
| errorDesc | String  | 错误描述 |
| errorType | Number |  错误类型   |
| errorGeometry | Geometry | 错误几何图形信息（errorType为2时提供） |

现有编辑错误类型说明：
- 删除多边形坐标点数量小于3时错误信息：{ errorDesc: 'geometry illegals', errorType: 1 }
- 矩形、圆形、椭圆未通过校验方法信息：{ errorDesc: 'geometry check failed', errorType: 2 }


</br></br>

## MeasureTool {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;测量工具用于地图测量，继承自Tool抽象类。
|构造函数|
| :- |
|new TMap.tools.MeasureTool(options);|


|参数名称|类型|说明|
| :- | :- |
|options	|MeasureToolOptions[]	|测量工具参数|


|方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |说明|
| :- | :- | :- |
|isMeasuring()	|Boolean	|判断用户是否在进行测量|
|measureDistance()	|Promise(DistanceMeasurementInfo)	|距离测量，调用方法后用户点击地图进行距离测量，双击结束测量；返回Promise，resolve状态下返回 DistanceMeasurementInfo 对象；如果用户在测量过程中该方法被调用，之前的测量过程将会被中断，并开始新的测量|
|measureArea()	|Promise(AreaMeasurementInfo)	|面积测量，调用方法后用户点击地图进行面积测量，双击结束测量；返回Promise，测量完成时resolve状态下返回 AreaMeasurementInfo 对象，顶点数不足3个测量失败时reject状态下返回错误信息；如果用户在测量过程中该方法被调用，之前的测量过程将会被强制结束，并开始新的测量|

</br></br>
## MeasureToolOptions {#6}
----
&nbsp;&nbsp;&nbsp;&nbsp;测量工具用于地图测量，继承自Tool抽象类。
|属性名称	|类型	|说明|
| :- | :- |:- |
|map	|Map	|展示图层的地图对象|

</br></br>
## DistanceMeasurementInfo {#7}
----
&nbsp;&nbsp;&nbsp;&nbsp;距离测量结果对象规范
|属性名称	|类型	|说明|
| :- | :- |:- |
|path	|LatLng[]	|线段节点数组|
|totalDistance	|Number	|总距离长度，单位为米|
|segmentDistanceList	|Number[]	|线段距离长度数组，数组元素代表每段距离长度，单位为米|
**方法**

| 方法名 | 返回值 | 说明 |Lite版本是否支持 |
| - | - | - |
| remove() | null | 将此次测量结果从地图上删除 |
</br></br>
## AreaMeasurementInfo {#8}
----
&nbsp;&nbsp;&nbsp;&nbsp;面积测量结果对象规范
|属性名称	|类型	|说明|
| :- | :- |:- |
|polygon	|LatLng[]	|多边形数组|
|area	|Number	|面积，单位为平方米
**方法**

| 方法名 | 返回值 | 说明 |Lite版本是否支持 |
| - | - | - |
| remove() | null | 将此次测量结果从地图上删除 |

