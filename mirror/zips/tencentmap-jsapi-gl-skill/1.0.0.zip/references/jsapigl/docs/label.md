## MultiLabel {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个文本标注，可以自定义每个文本标注的样式。
|构造函数|
| :- |
|TMap.MultiLabel(options:MultiLabelOptions)|


|方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明|
| :- | :- | :- |
|setMap(map:Map)	|this	|设置地图对象，如果map为null意味着将多个文本标注同时从地图中移除。|
|setGeometries(geometries: LabelGeometry[])	|this	|更新多文本标注数据，如果参数为null或undefined不会做任何处理。|
|setStyles(styles:MultiLabelStyleHash)	|this	|设置MultiLabel图层相关样式信息，如果参数为null或undefined不会做任何处理。|
|getMap()	|Map	|获取地图对象，若为空返回null。|
|getGeometries()	|LabelGeometry[]	|获取多文本标注数据。|
|getStyles()	|MultiLabelStyleHash	|获取图层相关样式信息。|
|setVisible(visible: Boolean)	|this	|设置图层是否可见。|
|getVisible()	|visible	|获取可见状态。|
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
|getGeometryById(id:String)	|LabelGeometry	|根据多文本数据id来获取点数据。|
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
|updateGeometries(geometry:LabelGeometry[])	|this	|更新多文本数据，如果geometry的id存在于集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的文本标注添加到集合中；如果参数为null或undefined不会做任何处理。|
|add(geometries: LabelGeometry[])	|this	|向图层中添加文本，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的文本存在重复id，这些文本会被重新分配id；如果参数为null或undefined不会做任何处理。|
|remove(ids: String[])	|this	|移除指定id的文本，如果参数为null或undefined不会做任何处理。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|
|destroy()	|  | 销毁图层对象 |
| getLabelBoxes(id:String) | LabelBoxHash | 获取文本整体像素宽高值，以一个key-value对象的形式返回，key为文本id，value为数组，第一个数据为文本整体的宽，第二个数据为文本整体的高。当未传入id时默认获得所有文本的宽高。注意该方法需要监听MultiLabel的'labelBox_changed'事件。|

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。 查看示例

|事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		|参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			|说明|
| :- | :- | :- |
|click	|GeometryOverlayEvent	|点击事件|
|dblclick	|GeometryOverlayEvent|双击事件|
|mousedown	|GeometryOverlayEvent|鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发|
|mouseup	|GeometryOverlayEvent|鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发|
|mousemove	|GeometryOverlayEvent|鼠标在地图上移动时触发，只在桌面浏览器中触发|
|hover	|GeometryOverlayEvent|鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的LabelGeometry，无图形时事件对象为null,只在桌面浏览器中触发|
|touchstart	|GeometryOverlayEvent|在地图区域触摸开始时触发，只在移动浏览器中触发|
|touchmove	|GeometryOverlayEvent	|在地图区域触摸移动时触发，只在移动浏览器中触发|
|touchend	|GeometryOverlayEvent|在地图区域触摸结束时触发，只在移动浏览器中触发|
|labelBox_changed	| - |在数据变化时触发|
| geometry_processed |  | 由增删改引起的几何数据变更被处理完成后触发。（注意：1、该事件仅代表数据处理完成，不代表数据被渲染完成，通常数据处理完后20~50ms内可被渲染；2、当该实例对象被编辑器激活进行编辑前，需要开发者手动阻止该事件监听函数中的业务逻辑执行，在编辑完成后可正常执行事件监听函数的业务逻辑） |


</br></br>
## MultiLabelOptions {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;MultiLabel配置参数。
|属性名称	|类型	|说明|
| :- | :- | :- |
|id	|String	|图层id，若没有会自动分配一个。|
|map	|Map	|显示文本标注图层的底图。|
|styles	|MultiLabelStyleHash	|文本标注的相关样式。|
| collisionOptions  | CollisionOptions | 图层碰撞配置参数 |
|geometries	|LabelGeometry[]	|文本标注数据数组。|
| disableInteractive | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |

</br></br>
## MultiLabelStyleHash {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示文本标注的相关样式信息，key使用字符串，value是 LabelStyle 对象。


</br></br>
## LabelStyle {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示应用于多标注图层的样式类型。
|构造函数|
| :- | 
|TMap.LabelStyle(options:LabelStyleOptions)|


|名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		|说明|
| :- | :- |:- |
|color	|String	|颜色属性，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(0,0,0,1)。|
| strokeColor	|String	|描边颜色属性，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(0,0,0,0)|
| strokeWidth | Number | 标注点文本描边宽度，默认为1 |
|size	|Number	|文字大小属性，默认为14。|
|offset	|Object	|文字偏移属性，单位为像素，以PointGeometry的位置点所对应屏幕位置为原点，x轴向右为正向左为负，y轴向下为正向上为负，默认为{x:0, y:0}。|
|angle	|Number	|文字旋转属性，单位为度，以PointGeometry的位置点所对应屏幕位置为原点，逆时针为正，默认为0。|
|alignment	|String	|文字水平对齐属性，默认为center，可选值为left（文字左侧与位置锚点对齐）、right（文字右侧与位置锚点对齐）、center（文字水平中心与位置锚点对齐）。|
|verticalAlignment	|String	|文字垂直对齐属性，默认为middle，可选值为top（文字顶部与位置点对齐）、bottom（文字底部与位置点对齐）、middle（文字垂直中心与位置点对齐）。|
| height	|Number	|文字背景框高度，单位为像素。|
| width	|Number	|文字背景框宽度，单位为像素。|
| padding	|String	|文字背景框内边距，单位为像素，属性支持接受1～2个值，规则符合css规范。</br>例："15px" 上下左右内边距为15px</br>例："15px 20px" 上下内边距为15px，左右内边距为20px</br>**注意设置宽高后padding将不生效**|
| backgroundColor	| String	|文字背景框颜色属性，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(0,0,0,0)；**该属性生效需要设置padding 或 width和hight**。  查看示例|
| borderWidth	|Number	|文字背景框边线宽度，单位为像素；**该属性生效需要设置padding 或 width和hight**。查看示例 |
| borderRadius|Number	|文字背景框圆角，单位为像素；**该属性生效需要设置padding 或 width和hight**。查看示例 |
| borderColor	|String	|文字背景框边线颜色属性，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(0,0,0,0)；**该属性生效需要设置padding 或 width和hight** 。查看示例|
| wrapOptions | LabelWrapOptions | 文本自动换行，支持设置软换行和硬换行，软换行支持配置最大换行宽度，硬换行换行符为'\n'。 LabelWrapOptions如果为空对象则以文本中换行符进行换行，如果为null或undefined则不换行|

</br></br>
## LabelGeometry {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;文本数据。
|属性名称	|类型	|说明|
| :- | :- |:- |
|id	|String	|点图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个。|
|styleId	|String	|对应MultiLabelStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制。|
|position	|LatLng	|标注点位置。|
|content	|String	|标注文本。|
|rank	|Number	|当开启文本碰撞时，值越大碰撞优先级越高。关闭碰撞时，表示标注文本的图层内绘制顺序。|
|properties	|Object	|标注点的属性数据。|
| collisionGroupId | String | 组合碰撞id，当开启碰撞时该id相同的文本作为一个整体进行碰撞，rank取组合中的最大值 |

</br></br>
## LabelWrapOptions {#6}
----
&nbsp;&nbsp;&nbsp;&nbsp;文本换行配置。当同时指定了最大换行宽度、最大行数和换行符时，换行优先级为: 最大行数>换行符>最大换行宽度。
|属性名称	|类型	|说明|
| :- | :- |:- |
| maxWidth | Number | 最大换行宽度，单位是像素，默认不限制 |
| maxLineCount | Number | 最大行数，默认不限制 |
| rowSpacing | Number | 行间距，单位是像素，默认为0 |

</br></br>
## CollisionOptions 对象规范{#7}
----
&nbsp;&nbsp;&nbsp;&nbsp;图层碰撞配置参数。

| 名称| 类型| 说明|
| -- | -- | -- |
| sameSource | Boolean | 是否开启图层内碰撞，优先级按rank进行碰撞，默认为false |
| crossSource | Boolean | 是否开启跨图层间碰撞，所有开启的图层间进行碰撞，优先级按zIndex进行碰撞，默认为false |
| vectorBaseMapSource | Boolean | 是否允许碰撞底图元素，默认为false |