## MultiPolyline {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个折线，可以自定义每个折线的样式。
|构造函数|
| :- |
|TMap.MultiPolyline(options:MultiPolylineOptions)|


|方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- |:- |:- |
|setMap(map:Map)	|this	|设置地图对象，如果map为null意味着将多折线同时从地图中移除。|
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序。|
|setGeometries(geometries: PolylineGeometry[])	|this	|更新折线数据，如果参数为null或undefined不会做任何处理。|
|setStyles(styles:MultiPolylineStyleHash)	|this	|设置MultiPolyline图层相关样式信息，如果参数为null或undefined不会做任何处理。|
|setVisible(visible: Boolean)	|this	|设置图层是否可见。|
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
|getMap()	|Map	|获取地图对象，若为空返回null。|
|getGeometries()	|PolylineGeometry[]	|获取折线数据。|
|getStyles()	|MultiPolylineStyleHash	|获取图层相关样式信息。
|getVisible()	|visible	|获取可见状态。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|getGeometryById(id:String)	|PolylineGeometry	|根据折线数据id来获取点数据。|
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
|updateGeometries(geometry: PolylineGeometry[])	|this	|更新折线数据，如果geometry的id存在于集合中，会更新对应id的数据，如果之前不存在于集合中，会作为新的折线添加到集合中；如果参数为null或undefined不会做任何处理。|
|add(geometries: PolylineGeometry[])	|this	|向图层中添加折线，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的折线存在重复id，这些折线会被重新分配id；如果参数为null或undefined不会做任何处理。|
|remove(ids: String[])	|this	|移除指定id的折线，如果参数为null或undefined不会做任何处理。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|
| destroy()	| 	| 销毁图层对象。 |
| eraseTo(id: String, index: Number, point:LatLng)	| 	| 用于线的擦除。第一个参数id 表示指定geometry的ID，擦除效果仅对该id对应的路线有效。 <br>第二个参数index表示要擦除到的坐标索引  index  。<br>第三个参数指线段 （坐标索引为[ index -1 ,  index ] ）上擦除点的经纬度坐标（ 如果这个坐标不在擦除的索引范围内，会一直擦除到坐标索引为index的点 ）。只支持简单折线。查看示例 |

&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。 查看示例


| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   | 说明 |
| :- | :- |:- |
|click	|GeometryOverlayEvent	|点击事件。|
|dblclick	|GeometryOverlayEvent	|双击事件。|
|rightclick	|GeometryOverlayEvent	|右键点击事件。|
|mousedown	|GeometryOverlayEvent	|鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发。|
|mouseup	|GeometryOverlayEvent	|鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发。|
|mousemove	|GeometryOverlayEvent	|鼠标在地图上移动时触发，只在桌面浏览器中触发。|
|mouseover	|GeometryOverlayEvent	|鼠标在移动到折线图层上时触发，只在桌面浏览器中触发。|
|mouseout	|GeometryOverlayEvent	|鼠标移出折线图层时触发，只在桌面浏览器中触发。|
|hover	|GeometryOverlayEvent	|鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的PolylineGeometry，无图形时事件对象为null,只在桌面浏览器中触发。|
|touchstart	|GeometryOverlayEvent	|在地图区域触摸开始时触发，只在移动浏览器中触发。|
|touchmove	|GeometryOverlayEvent	|在地图区域触摸移动时触发，只在移动浏览器中触发。|
|touchend	|GeometryOverlayEvent	|在地图区域触摸结束时触发，只在移动浏览器中触发。|
| geometry_processed |  | 由增删改引起的几何数据变更被处理完成后触发。（注意：1、该事件仅代表数据处理完成，不代表数据被渲染完成，通常数据处理完后20~50ms内可被渲染；2、当该实例对象被编辑器激活进行编辑前，需要开发者手动阻止该事件监听函数中的业务逻辑执行，在编辑完成后可正常执行事件监听函数的业务逻辑） |

</br></br>
MultiPolylineOptions {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;MultiPolyline配置参数。
| 名称	|类型	|说明|
| :- | :- |:- |
|id	|String	|图层id，若没有会自动分配一个。
|map	|Map		|显示折线图层的底图。
|zIndex	|Number	|图层绘制顺序
|styles	|MultiPolylineStyleHash[] |折线的相关样式。
|enableGeodesic | Boolean | 绘制折线是否是大圆航线， 默认为 false。
| enableSimplify | Boolean | 是否开启抽稀, 默认为true（开启大圆航线后将默认关闭抽稀）。
|geometries	|PolylineGeometry[] 	|折线数据数组。|
| disableInteractive  | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation  | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |

</br></br>
## MultiPolylineStyleHash {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示折线图层的相关样式信息，key使用字符串，value是 PolylineStyle 对象。

</br></br>
## PolylineStyle {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示应用于折线图层的样式类型。
|构造函数|
| :- |
|TMap.PolylineStyle(options:PolylineStyleOptions)|


|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|color	|String	|线填充色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF。|
|width	|Number	|折线宽度，正整数，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为3。|
|borderWidth	|Number	|边线宽度，非负整数，默认为0，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为1。|
|borderColor	|String	|边线颜色，支持rgb()，rgba()，#RRGGBB等形式，borderWidth不为0时有效，默认为#3777FF。|
|eraseColor	|String	|擦除线填充色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF。|
|lineCap	|String	|线端头方式，可选为butt，round，square，默认为butt。|
|dashArray	|Number[]	|虚线展示方式，[0, 0]为实线，[10, 10]表示十个像素的实线和十个像素的空白（如此反复）组成的虚线，默认为[0, 0];这里的像素指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差。|
|showArrow	|Boolean	|是否沿线路方向显示箭头，默认为false，建议线宽度大于6时使用。|
|arrowOptions	| ArrowOptions|箭头显示配置，仅在showArrow为true时有效。|
| enableBloom | Boolean | 是否对折线启用泛光效果，需在MapRenderOptions中开启泛光后才可使用。查看示例 |


</br></br>
## ArrowOptions {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;折线上箭头配置参数。
|属性名称|类型|说明|
| :- | :- | :- |
|width	|Number	|箭头图标宽度，单位为px，默认为6，最大支持255|
|height	|Number	|箭头图标高度（沿线方向长度），单位为px，默认为4，最大支持255|
|space	|Number	|箭头图标之间的孔隙长度，单位为px，默认为50，最大支持255|
| animSpeed	|Number	|箭头动态移动的速度，默认为0，静止不动，单位为(像素/秒)|

!

</br></br>
## PolylineGeometry {#6}
----
&nbsp;&nbsp;&nbsp;&nbsp;折线数据。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|id	|String	|折线图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个。|
|styleId	|String	|对应MultiPolylineStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制。|
|paths	|LatLng[] 或 LatLng[][]	|折线的位置信息，可以传入[latLng1, latLng2, latLng3]表示一条折线；另外一条折线可能由多个不相连的线组成一个逻辑单位，如：[[latLng1, latLng2, latLng3], [latLng4, latLng5, latLng6]]。|
|rainbowPaths	|Array	|多颜色折线的信息，若传入该属性，其优先级高于paths。数据格式：[{path: [latLng1, latLng2, latLng3], color: '#FFFFFF', borderColor: '#FFFFFF'}, {path: [latLng3, latLng4, latLng5], color: '#000000', borderColor: '#000000'}]，数组中每个对象包含一个path和对应填充颜色以及边线颜色，对于连续的线，需要保证后一个对象中path的起点是前一个对象中path的终点，颜色可选填，支持rgb()，rgba()，#RRGGBB等形式，默认为styleId对应的样式对象中的颜色配置。 查看示例|
|properties	|Object	|折线的属性数据。|
|rank	|Number	|折线图层内绘制顺序。|


</br></br>
## MultiPolygon {#7}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个多边形，可以自定义每个多边形的样式。
|构造函数|
| :- |
|TMap.MultiPolygon(options:MultiPolygonOptions)|


|方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|setMap(map:Map)	|this	|设置地图对象，如果map为null意味着将多边形同时从地图中移除。
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序。|
|setGeometries(geometries: PolygonGeometry[])	|this	|更新多边形数据，如果参数为null或undefined不会做任何处理。|
|setStyles(styles:MultiPolygonStyleHash)	|this	|设置MultiPolygon图层相关样式信息，如果参数为null或undefined不会做任何处理。|
|setVisible(visible: Boolean)	|this	|设置图层是否可见。|
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
|getMap()	|Map	|获取地图对象，若为空返回null。|
|getGeometries()	|PolygonGeometry[]	|获取多边形数据。|
|getStyles()	|MultiPolygonStyleHash	|获取图层相关样式信息。|
|getVisible()	|visible	|获取可见状态。|
|getZIndex()	|Number	|获取图层绘制顺序。|
|getGeometryById(id:String)	|PolygonGeometry	|根据多边形数据id来获取点数据。|
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
|updateGeometries(geometry:PolygonGeometry[])	|this	|更新多边形数据，如果geometry的id存在于集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的多边形添加到集合中；如果参数为null或undefined不会做任何处理。|
|add(geometries: PolygonGeometry[])	|this	|向图层中添加多边形，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的多边形存在重复id，这些多边形会被重新分配id；如果参数为null或undefined不会做任何处理。|
|remove(ids: String[])	|this	|移除指定id的多边形，如果参数为null或undefined不会做任何处理。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|
| destroy()	| 	| 销毁图层对象 |

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。 查看示例

| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   | 说明 |
| :- | :- |:- |
|click	|GeometryOverlayEvent	|点击事件。|
|dblclick	|GeometryOverlayEvent  |双击事件。|
|mousedown	|GeometryOverlayEvent  |鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发。|
|mouseup	|GeometryOverlayEvent |鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发。|
|mousemove	|GeometryOverlayEvent  |鼠标在地图上移动时触发，只在桌面浏览器中触发。|
|hover	|GeometryOverlayEvent  |鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的PolygonGeometry，无图形时事件对象为null,只在桌面浏览器中触发。|
|touchstart	|GeometryOverlayEvent  |在地图区域触摸开始时触发，只在移动浏览器中触发。|
|touchmove	|GeometryOverlayEvent	|在地图区域触摸移动时触发，只在移动浏览器中触发。|
|touchend	|GeometryOverlayEvent	|在地图区域触摸结束时触发，只在移动浏览器中触发。|
| geometry_processed |  | 由增删改引起的几何数据变更被处理完成后触发。（注意：1、该事件仅代表数据处理完成，不代表数据被渲染完成，通常数据处理完后20~50ms内可被渲染；2、当该实例对象被编辑器激活进行编辑前，需要开发者手动阻止该事件监听函数中的业务逻辑执行，在编辑完成后可正常执行事件监听函数的业务逻辑） |

</br></br>
## MultiPolygonOptions  {#8}
----
&nbsp;&nbsp;&nbsp;&nbsp;MultiPolygon配置参数。
|属性名称	|类型	|说明|
| :- | :- |:- |
|id	|String	|图层id，若没有会自动分配一个。|
|map	|Map	|显示多边形图层的底图。|
|zIndex	|Number	|图层绘制顺序。|
|styles	|MultiPolygonStyleHash	|多边形的相关样式。|
|geometries	|PolygonGeometry[]	|多边形数据数组。|
| disableInteractive  | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation  | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |

</br></br>
## MultiPolygonStyleHash {#9}
----
&nbsp;&nbsp;&nbsp;&nbsp;MultiPolygon一个key-value形式对象, 表示多边形图层的相关样式信息，key使用字符串，value是PolygonStyle或者ExtrudablePolygonStyle对象。

</br></br>
## PolygonStyle {#10}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示应用于多边形图层的样式类型。
|构造函数|
|:- |
|TMap.PolygonStyle(options:PolygonStyleOptions)|


|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- |:- |
|color	|String	|面填充色，支持rgb()，rgba()，#RRGGBB等形式，默认为rgba(55,119,255,0.16)。|
|showBorder	|Boolean	|是否显示边线，默认为true。|
|borderColor	|String	|边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF，showBorder为true时有效。|
|borderWidth	|Number	|边线宽度，正整数，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为2，showBorder为true时有效。|
|borderDashArray	|Number[]	|边线虚线虚线展示方式，[0, 0]为实线，[10, 10]表示十个像素的实线和十个像素的空白（如此反复）组成的虚线，默认为[0, 0];这里的像素指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差。|

</br></br>
## ExtrudablePolygonStyle {#11}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示应用于有立体拉伸需求的多边形的样式类型，拔起面块的边线不支持设置宽度永远为1像素宽度。
|构造函数|
|:- |
|TMap.ExtrudablePolygonStyle(options:ExtrudablePolygonStyleOptions)|


|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- |:- |
|color	|String	|面填充色，支持rgb()，rgba()，#RRGGBB等形式。|
|extrudeHeight	|Number	|多边形拔起高度，默认为1，单位米。|
|showBorder	|Boolean	|是否显示拔起面块的边线，拔起面块的边线不支持设置宽度，永远为1像素宽度。|
|borderColor	|String	|边线颜色，支持rgb()，rgba()，#RRGGBB等形式，showBorder为true时有效。|

</br></br>
## PolygonGeometry {#12}
----
&nbsp;&nbsp;&nbsp;&nbsp;多边形数据。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- |:- |
|id	|String	|多边形图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个。|
|styleId	|String	|对应MultiPolygonStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制。|
|paths	|LatLng[] 或 LatLng[][] 或 LatLng[][][]	|多边形的位置信息，可以传入[latLng1, latLng2, latLng3, latLng5, latLng1]这种简单多边形；也可以传入带洞多边形[[latLng1, latLng2, latLng3, latLng5, latLng1], [latLng6, latLng8, latLng9, latLng6], [latLng10, latLng11, latLng10]]这个多边形包含一个外环[latLng1, latLng2, latLng3, latLng5, latLng1]和两个洞[latLng6, latLng8, latLng9, latLng6], [latLng10, latLng11, latLng10]; 另外一个多边形可能有多个不相邻的多边形组成一个逻辑主体；比如南沙群岛就是由多个分离的多边形组成一个主体，一个岛屿可能存在多个岛中湖形成带洞多边形；示例：[[[latLng1, latLng2, latLng3, latLng5, latLng1], [latLng6, latLng8, latLng9, latLng6], [latLng10, latLng11, latLng10]], [[latLng11, latLng12, latLng13, latLng14, latLng11]], [[latLng15, latLng16, latLng17, latLng18, latLng15]]], 这个多边形主体中包含了三个多边形， 其中第一个多边形包含一个外环[latLng1, latLng2, latLng3, latLng5, latLng1]和两个洞[latLng6, latLng8, latLng9, latLng6], [latLng10, latLng11, latLng10]， 第二和第三个多边形都是不带洞的简单多边形。查看示例|
|rank	|Number	|多边形的图层内绘制顺序。|
|properties	|Object	|多边形的属性数据。|

<br><br>
## MultiRectangle{#MultiRectangle}

---------

&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个矩形，可以自定义每个矩形的样式。


| 构造函数                                                     |
| :----------------------------------------------------------- |
| new TMap.MultiRectangle(options: MultiRectangleOptions); |


| 方法名  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                                     | 返回值           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp;  &nbsp;&nbsp;                                     | 说明                                                         |
| :----------------------------------------------------------- | :----------------------------------------------------------- | :----------------------------------------------------------- |
| setMap(map:Map)                                              | this                                                         | 设置地图对象，如果map为null意味着将多矩形同时从地图中移除    |
| setZIndex(zIndex: Number)                                    | this                                                         | 设置图层绘制顺序                                             |
| setGeometries(geometries: RectangleGeometry[]) | this                                                         | 更新多矩形数据，如果参数为null或undefined不会做任何处理      |
| setStyles(styles:MultiRectangleStyleHash | this                                                         | 设置MultiRectangle图层相关样式信息，如果参数为null或undefined不会做任何处理 |
| setVisible(visible: Boolean)                                 | this                                                         | 设置图层是否可见                                             |
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
| getMap()                                                     | Map                                                          | 获取地图对象，若为空返回null                                 |
| getGeometries()                                              | RectangleGeometry[] | 获取多矩形数据                                               |
| getStyles()                                                  | MultiRectangleStyleHash | 获取图层相关样式信息                                         |
| getVisible()                                                 | visible                                                      | 获取可见状态                                                 |
| getZIndex()                                                  | Number                                                       | 获取图层绘制顺序                                             |
| getGeometryById(id:String)                                   | RectangleGeometry | 根据多矩形数据id来获取点数据                                 |
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
| updateGeometries(geometry:  RectangleGeometry[]) | this                                                         | 更新多矩形数据，如果geometry的id存在于集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的矩形添加到集合中；如果参数为null或undefined不会做任何处理 |
| add(geometries:  RectangleGeometry[]) | this                                                         | 向图层中添加矩形，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的多边形存在重复id，这些多边形会被重新分配id；如果参数为null或undefined不会做任何处理 |
| remove(ids: String[])                                        | this                                                         | 移除指定id的矩形，如果参数为null或undefined不会做任何处理    |
| destroy()                                                    |                                                              | 销毁图层对象                                               |

## 静态方法
| 方法名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     | 返回值   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              | 说明                                                         |
| :--------- | :------------------- | :--------------------------------------- |
| getBounds(geometry: RectangleGeometry)| LatLngBounds	| 根据geometry获取矩形的左下角和右上角顶点经纬度坐标                                                     |

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。

| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     | 参数   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;              | 说明                                                         |
| :--------- | :------------------- | :--------------------------------------- |
| click      | GeometryOverlayEvent | 点击事件                                                     |
| dblclick   | GeometryOverlayEvent | 双击事件                                                     |
| mousedown  | GeometryOverlayEvent | 鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发         |
| mouseup    | GeometryOverlayEvent | 鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发   |
| mousemove  | GeometryOverlayEvent | 鼠标在地图上移动时触发，只在桌面浏览器中触发                 |
| hover      | GeometryOverlayEvent | 鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的RectangleGeometry[]，无图形时事件对象为null,只在桌面浏览器中触发 |
| touchstart | GeometryOverlayEvent | 在地图区域触摸开始时触发，只在移动浏览器中触发               |
| touchmove  | GeometryOverlayEvent | 在地图区域触摸移动时触发，只在移动浏览器中触发               |
| touchend   | GeometryOverlayEvent | 在地图区域触摸结束时触发，只在移动浏览器中触发               |
<br><br>
## MultiRectangleOptions 对象规范{#MultiRectangleOptions}

MultiRectangle配置参数。


| 名称       | 类型                                                         | 说明                         |
| :--------- | :----------------------------------------------------------- | :--------------------------- |
| id         | String                                                       | 图层id，若没有会自动分配一个 |
| map        | Map                                                          | 显示多矩形图层的底图         |
| zIndex     | Number                                                       | 图层绘制顺序                 |
| styles     | MultiRectangleStyleHash | 矩形的相关样式               |
| geometries | RectangleGeometry[] | 矩形数据数组                 |
| disableInteractive  | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation  | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |
<br>

## MultiRectangleStyleHash 对象规范{#MultiRectangleStyleHash}

&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示多矩形图层的相关样式信息，key使用字符串，value是RectangleStyle。
<br><br>

## RectangleStyle{#RectangleStyle}

&nbsp;&nbsp;&nbsp;&nbsp;表示应用于矩形图层的样式类型。

| 构造函数                                                 |
| :-------------------------------------------------------- |
| new TMap.RectangleStyle(options: RectangleStyleOptions); |

<br>

## RectangleStyleOptions 对象规范{#RectangleStyleOptions}

&nbsp;&nbsp;&nbsp;&nbsp;RectangleStyle配置参数。

| 属性名称 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   | 类型  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明                                                         |
| :---------- | :------ | :----------------------------------------------------------- |
| color       | String  | 面填充色，支持rgb()，rgba()，#RRGGBB等形式             |
| showBorder  | Boolean | 是否显示边线，默认为true                                    |
| borderColor | String  | 边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF，showBorder为true时有效 |
| borderWidth | Number  | 折线宽度，正整数，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为2，showBorder为true时有效 |

## RectangleGeometry 对象规范{#RectangleGeometry}

-----

多矩形数据。

| 名称  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   | 说明                                                         |
| :--------- | :----- | :----------------------------------------------------------- |
| id         | String | 多矩形图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个 |
| styleId    | String | 对应MultiRectangleStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制 |
| center     | LatLng | 矩形的中心点位置                                             |
| width      | Number | 矩形的宽，正数，单位为米                                     |
| height     | Number | 矩形的高，正数，单位为米                                     |
| properties | Object | 矩形的属性数据                                               |
| rank       | Number | 矩形的图层内绘制顺序                                         |


</br></br>
## MultiCircle {#13}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个圆形，可以自定义每个圆形的样式。
|构造函数|
|:- |
|new TMap.MultiCircle(options);|


|参数名	|类型	|说明|
| :- | :- |:- |
|options	|MultiCircleOptions	|多圆的参数对象|


|方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|setMap(map:Map)	|this	|设置地图对象，如果map为null意味着将多圆同时从地图中移除|
|setZIndex(zIndex: Number)	|this	|设置图层绘制顺序|
|setGeometries(geometries:CircleGeometry[])	|this	|更新多圆数据，如果参数为null或undefined不会做任何处理|
|setStyles(styles:MultiCircleStyleHash)	|this	|设置MultiCircle图层相关样式信息，如果参数为null或undefined不会做任何处理|
|setVisible(visible: Boolean)	|this	|设置图层是否可见。|
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
|getMap()	|Map	|获取地图对象，若为空返回null|
|getGeometries()	|CircleGeometry[]	|获取多圆数据|
|getStyles()	|MultiCircleStyleHash	|获取图层相关样式信息|
|getVisible()	|visible	|获取可见状态|
|getZIndex()	|Number	|获取图层绘制顺序|
|getGeometryById(id:String)	|CircleGeometry	|根据多圆数据id来获取点数据|
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
|updateGeometries(geometry: CircleGeometry[])	|this	|更新多圆数据，如果geometry的id存在于集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的圆添加到集合中；如果参数为null或undefined不会做任何处理|
|add(geometries: CircleGeometry[])	|this	|向图层中添加圆，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的多边形存在重复id，这些多边形会被重新分配id；如果参数为null或undefined不会做任何处理|
|remove(ids: String[])	|this	|移除指定id的圆，如果参数为null或undefined不会做任何处理|
| destroy()	| 	| 销毁图层对象 |

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。

|事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|click	|GeometryOverlayEvent	|点击事件|
|dblclick	|GeometryOverlayEvent|双击事件|
|mousedown	|GeometryOverlayEvent|鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发|
|mouseup	|GeometryOverlayEvent|鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发|
|mousemove	|GeometryOverlayEvent|鼠标在地图上移动时触发，只在桌面浏览器中触发|
|hover	|GeometryOverlayEvent|鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的CircleGeometry，无图形时事件对象为null,只在桌面浏览器中触发|
|touchstart	|GeometryOverlayEvent|在地图区域触摸开始时触发，只在移动浏览器中触发|
|touchmove	|GeometryOverlayEvent|在地图区域触摸移动时触发，只在移动浏览器中触发|
|touchend	|GeometryOverlayEvent|在地图区域触摸结束时触发，只在移动浏览器中触发|

</br></br>
## MultiCircleOptions {#14}
----
&nbsp;&nbsp;&nbsp;&nbsp;MultiCircle配置参数。
|属性名称	|类型	|说明|
| :- | :- | :- |
|id	|String	|图层id，若没有会自动分配一个|
|map	|Map	|显示多圆图层的底图|
|zIndex	|Number	|图层绘制顺序|
|styles	|MultiCircleStyleHash	|圆的相关样式|
|geometries	|CircleGeometry[]	|圆数据数组|
| disableInteractive  | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation  | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |

</br></br>
## MultiCircleStyleHash {#15}
----
&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示多圆图层的相关样式信息，key使用字符串，value是 CircleStyle。

</br></br>
## CircleGeometry {#16}
----
&nbsp;&nbsp;&nbsp;&nbsp;多圆数据。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- | :- | :- |
|id	|String	|多圆图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个|
|styleId	|String	|对应MultiCircleStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制|
|center	|LatLng	|圆的中心点位置|
|radius	|Number	|圆的半径，正数，单位为米|
|properties	|Object	|圆的属性数据|
| rank	| Number	| 圆的图层内绘制顺序 |


</br></br>
## CircleStyle {#17}
----
&nbsp;&nbsp;&nbsp;&nbsp;表示应用于圆图层的样式类型。
|构造函数|
| :- |
|new TMap.CircleStyle(options);|


|参数名	|类型	|说明|
| :- |:- |:- |
|options	|CircleStyleOptions	|圆的样式信息|

</br></br>
## CircleStyleOptions {#18}
----
&nbsp;&nbsp;&nbsp;&nbsp;CircleStyle配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 	|说明|
| :- |:- |:- |
|color	|String	|面填充色，支持rgb()，rgba()，#RRGGBB等形式|
|showBorder	|Boolean	|是否显示边线，默认为true|
|borderColor	|String	|边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF，showBorder为true时有效|
|borderWidth	|Number	|折线宽度，正整数，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为2，showBorder为true时有效|
<br><br>

## MultiEllipse{#MultiEllipse}

-----------

​&nbsp;&nbsp;&nbsp;&nbsp;表示地图上的多个椭圆，可以自定义每个椭圆的样式。

| 构造函数                                                     |
| ------------------------------------------------------------ |
| new TMap.MultiEllipse(options:MultiEllipseOptions); |


| 方法名    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;                                                  | 返回值        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                               | 说明                                                         |
| :----------------------------------------------------------- | :----------------------------------------------------------- | :----------------------------------------------------------- |
| setMap(map:Map)                                              | this                                                         | 设置地图对象，如果map为null意味着将多椭圆同时从地图中移除    |
| setZIndex(zIndex: Number)                                    | this                                                         | 设置图层绘制顺序                                             |
| setGeometries(geometries:EllipseGeometry[]) | this                                                         | 更新多椭圆数据，如果参数为null或undefined不会做任何处理      |
| setStyles(styles:MultiEllipseStyleHash) | this                                                         | 设置MultiEllipse图层相关样式信息，如果参数为null或undefined不会做任何处理 |
| setVisible(visible: Boolean)                                 | this                                                         | 设置图层是否可见                                             |
| setInteractiveDisable(disableInteractive: Boolean) | this | 设置图层是否禁止参与交互事件|
| setStopPropagation(isStopPropagation: Boolean) | this | 设置当前覆盖物事件响应禁止冒泡至Map|
| getMap()                                                     | Map                                                          | 获取地图对象，若为空返回null                                 |
| getGeometries()                                              | EllipseGeometry[] | 获取多椭圆数据                                               |
| getStyles()                                                  | MultiEllipseStyleHash | 获取图层相关样式信息                                         |
| getVisible()                                                 | visible                                                      | 获取可见状态                                                 |
| getZIndex()                                                  | Number                                                       | 获取图层绘制顺序                                             |
| getGeometryById(id:String)                                   | EllipseGeometry | 根据多椭圆数据id来获取点数据                                 |
| getInteractiveDisable() | Boolean | 获取图层是否禁止参与交互事件的状态 |
| getStopPropagation() | Boolean | 获取当前覆盖物禁止冒泡状态 |
| updateGeometries(geometry: EllipseGeometry[]) | this                                                         | 更新多椭圆数据，如果geometry的id存在于集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的椭圆添加到集合中；如果参数为null或undefined不会做任何处理 |
| add(geometries: EllipseGeometry[]) | this                                                         | 向图层中添加椭圆，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的多边形存在重复id，这些多边形会被重新分配id；如果参数为null或undefined不会做任何处理 |
| remove(ids: String[])                                        | this                                                         | 移除指定id的椭圆，如果参数为null或undefined不会做任何处理    |
| destroy                                                      |                                                              | 销毁图层对象                                                 |


| 事件名  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   | 参数    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;             | 说明                                                         |
| :--------- | :------------------- | :----------------------------------------------------------- |
| click      | GeometryOverlayEvent | 点击事件                                                     |
| dblclick   | GeometryOverlayEvent | 双击事件                                                     |
| mousedown  | GeometryOverlayEvent | 鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发         |
| mouseup    | GeometryOverlayEvent | 鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发   |
| mousemove  | GeometryOverlayEvent | 鼠标在地图上移动时触发，只在桌面浏览器中触发                 |
| hover      | GeometryOverlayEvent | 鼠标在图层上悬停对象改变时触发，事件对象中的geometry属性会指向交互位置所在图形的EllipseGeometry，无图形时事件对象为null,只在桌面浏览器中触发 |
| touchstart | GeometryOverlayEvent | 在地图区域触摸开始时触发，只在移动浏览器中触发               |
| touchmove  | GeometryOverlayEvent | 在地图区域触摸移动时触发，只在移动浏览器中触发               |
| touchend   | GeometryOverlayEvent | 在地图区域触摸结束时触发，只在移动浏览器中触发               |
<br>

## MultiEllipseOptions 对象规范{#MultiEllipseOptions}

---------

&nbsp;&nbsp;&nbsp;&nbsp;MultiEllipse配置参数。

| 名称     | 类型                                                         | 说明                         |
| :--------- | :----------------------------------------------------------- | :--------------------------- |
| id         | String                                                       | 图层id，若没有会自动分配一个 |
| map        | Map                                                          | 显示多椭圆图层的底图         |
| zIndex     | Number                                                       | 图层绘制顺序                 |
| styles     | MultiEllipseStyleHash | 椭圆的相关样式               |
| geometries | EllipseGeometry[] | 椭圆数据数组                 |
| disableInteractive  | Boolean | 图层是否禁止参与交互事件，默认为false |
| isStopPropagation | Boolean  | 是否阻止鼠标、触摸事件冒泡，默认为false |

<br><br>
## MultiEllipseStyleHash 对象规范{#MultiEllipseStyleHash}

&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示多椭圆图层的相关样式信息，key使用字符串，value是EllipseStyle。
<br><br>
## EllipseStyle{#EllipseStyle}

&nbsp;&nbsp;&nbsp;&nbsp;表示应用于椭圆图层的样式类型。

| 构造函数                                                     |
| :------------------------------------------------------------ |
| new TMap.EllipseStyle(options:EllipseStyleOptions); |

<br><br>
## EllipseStyleOptions 对象规范{#EllipseStyleOptions}

&nbsp;&nbsp;&nbsp;&nbsp;EllipseStyle配置参数。

| 名称 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;      | 类型  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明                                                         |
| :---------- | :------ | :----------------------------------------------------------- |
| color       | String  | 面填充色，支持rgb()，rgba()，#RRGGBB等形式             |
| showBorder  | Boolean | 是否显示边线，默认为true                                    |
| borderColor | String  | 边线颜色，支持rgb()，rgba()，#RRGGBB等形式，默认为#3777FF，showBorder为true时有效 |
| borderWidth | Number  | 折线宽度，正整数，单位为像素，指的是地图pitch为0时的屏幕像素大小，如果pitch不为0，实际绘制出来的线宽度与屏幕像素会存在一定误差，默认为2，showBorder为true时有效 |
<br><br>
## EllipseGeometry 对象规范{#EllipseGeometry}

&nbsp;&nbsp;&nbsp;&nbsp;多椭圆数据。

| 名称        | 类型   | 说明                                                         |
| :---------- | :----- | :----------------------------------------------------------- |
| id          | String | 多椭圆图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个 |
| styleId     | String | 对应  MultiEllipseStyleHash中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry会以默认样式绘制 |
| center      | LatLng | 椭圆的中心点位置                                             |
| majorRadius | Number | 椭圆的主半径，正数，单位为米                                 |
| minorRadius | Number | 椭圆的辅半径，正数，单位为米                                 |
| properties  | Object | 椭圆的属性数据                                               |
| rank        | Number | 椭圆的图层内绘制顺序                                         |

