## 地点搜索 {#1}

### Search
---

提供多种搜索功能。

|构造函数|
| :- |
|new TMap.service.Search(options)|


|参数名称|类型|说明|
| :- | :- | -- |
|options	| Object	|搜索类配置参数对象规范见下表|


| 名称     | 类型   | 是否必填 | 说明                                   |
| -------- | ------ | -------- | -------------------------------------- |
| pageSize | Number | 否       | 每页条目数，最大限制为20条，默认为10条 |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| searchNearby(params: SearchNearByParams) | Promise | 搜索某地周围的一个圆形范围符合指定关键字的地点；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| searchRegion(params: SearchRegionParams) | Promise | 搜索某地区cityName附近符合给定关键字的地点；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| searchRectangle(params: SearchRectangleParams) | Promise | 在矩形范围内以给定关键定搜索地点；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| explore(params: ExploreParams) | Promise | 只需提供搜索中心点及半径（无须关键词），即可搜索获取周边高热度地点；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| here(params: HereParams) | Promise | 与explore相似，但本接口侧重于以地标+主要的路+近距离POI为主；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| searchPoiId(params: SearchPoiIdParams) | Promise | 通过POI的id查询详细信息；搜索完成后resolve状态下返回SearchResult，reject状态下返回ErrorResult |
| setPageSize(pageSize:Number)                                 | this    | 设置每页返回的结果数量                                       |
| getPageSize()                                                | Number  | 获取每页返回的结果数量                                       |


 <br>

### SearchNearbyParams {#2}

---

| 名称       | 类型        | 是否必填 | 说明                                                         |
| ---------- | ----------- | -------- | ------------------------------------------------------------ |
| keyword    | String      | 是       | 搜索关键字                                                   |
| center     | TMap.LatLng | 是       | 搜索中心点的经纬度                                           |
| radius     | Number      | 是       | 搜索半径，取值范围：10到1000                                                      |
| autoExtend | Boolean     | 否       | 当前范围无结果时，是否自动扩大范围，取值：<br/>false：不扩大；<br/>true [默认]：自动扩大范围（依次按照按1公里、2公里、5公里，最大到全城市范围搜索） |
| filter     | String      | 否       | 筛选条件，用法详见下方filter参数用法 |
| orderby    | String      | 否       | 排序，支持按距离由近到远排序，取值：_distance                |
| pageIndex  | Number      | 否       | 第x页，默认第1页                                             |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### SearchRegionParams {#3}

---

| 名称              | 类型        | 是否必填 | 说明                                                         |
| ----------------- | ----------- | -------- | ------------------------------------------------------------ |
| keyword           | String      | 是       | 搜索关键字                                                   |
| cityName          | String      | 是       | 检索城市名称， 如北京市，同时支持adcode（行政区划代码，可精确到区县级），如130681 |
| autoExtend        | Boolean     | 否       | 当前范围无结果时，是否自动扩大范围，取值：<br/>false：不扩大；<br/>true [默认]：自动扩大范围（依次按照按1公里、2公里、5公里，最大到全城市范围搜索） |
| referenceLocation | TMap.LatLng | 否       | 当keyword使用酒店、超市等泛分类关键词时，这类场景大多倾向于搜索附近，传入此经纬度，搜索结果会优先就近地点，体验更优 |
| filter            | String      | 否       | 筛选条件，用法详见下方filter参数用法 |
| pageIndex         | Number      | 否       | 第x页，默认第1页                                             |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### SearchRectangleParams {#4}

---

| 名称      | 类型              | 是否必填 | 说明                                                         |
| --------- | ----------------- | -------- | ------------------------------------------------------------ |
| keyword   | String            | 是       | 搜索关键字                                                   |
| bounds    | TMap.LatLngBounds | 是       | 检索范围                                                     |
| filter    | String            | 否       | 筛选条件，用法详见下方filter参数用法 |
| pageIndex | Number            | 否       | 第x页，默认第1页                                             |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### ExploreParams {#5}

---

| 名称          | 类型        | 是否必填 | 说明                                                         |
| ------------- | ----------- | -------- | ------------------------------------------------------------ |
| center        | TMap.LatLng | 是       | 搜索中心点的经纬度                                           |
| radius        | Number      | 是       | 搜索半径，取值范围：10到1000                                                     |
| autoExtend    | Boolean     | 否       | 当前范围无结果时，是否自动扩大范围，取值：<br/>0：不扩大；<br/>1 [默认]：自动扩大范围（依次按照按1公里、2公里、5公里，最大到全城市范围搜索）。 |
| policy        | Number      | 否       | 搜索策略，可选值：<br/>1 [默认]：地点签到场景，针对用户签到的热门 地点进行优先排序；<br/>2 ：位置共享场景，用于发送位置、位置分享等场景的热门地点优先排序 |
| addressFormat | String      | 否       | 地址格式，可选值：short，返回不包含省市区的短地址<br/>（缺省侧为包含省市区的标准地址） |
| filter        | String      | 否       | 筛选条件，用法详见下方filter参数用法 |
| orderby       | String      | 否       | 排序，支持按距离由近到远排序，取值：_distance                |
| pageIndex     | Number      | 否       | 第x页，默认第1页                                             |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### HereParams {#6}

---

| 名称          | 类型        | 是否必填 | 说明                                                         |
| ------------- | ----------- | -------- | ------------------------------------------------------------ |
| center        | TMap.LatLng | 是       | 搜索中心点的经纬度                                           |
| radius        | Number      | 是       | 搜索半径，取值范围：10到1000                                                     |
| policy        | Number      | 否       | 搜索策略：<br/>policy=1[默认]：以地标+主要的路+近距离POI为主，着力描述当前位置；<br/>policy=2 到家场景：筛选合适收货的POI，并会细化收货地址，精确到楼栋；<br/>policy=3 出行场景：过滤掉车辆不易到达的POI(如一些景区内POI)，增加道路出入口、交叉口、大区域出入口类POI，排序会根据真实API大用户的用户点击自动优化 |
| addressFormat | String      | 否       | 地址格式，可选值：short，返回不包含省市区的短地址<br/>（缺省侧为包含省市区的标准地址） |
| filter        | String      | 否       | 筛选条件，用法详见下方filter参数用法 |
| orderby       | String      | 否       | 排序，支持按距离由近到远排序，取值：_distance                |
| pageIndex     | Number      | 否       | 第x页，默认第1页                                             |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br >

### SearchPoiIdParams {#7}

---

| 名称 | 类型   | 是否必填 | 说明                        |
| ---- | ------ | -------- | --------------------------- |
| id   | String | 是       | 腾讯地图POI（地点）唯一标识 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### Search 类的filter 参数用法 {#8}

---

| 说明                                                         | 示例                                                         |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| 1. 指定分类筛选，语句格式为：<br/>category=分类名1,分类名2<br/>最多支持5个分类词（支持的分类请参考：POI分类表）<br/>2. 排除指定分类，语句格式为：<br/>category<>分类名1,分类名2<br/>最多支持5个分类词（支持的分类请参考：POI分类表）<br/>3. 筛选有电话的地点：tel<>null | **搜索指定分类**<br/>filter=category=公交站<br/>**搜索多个分类**<br/>filter=category=大学,中学<br/>**排除指定分类**<br/>filter=category<>商务楼宇 |

 <br>

### SearchResult {#9}

---

| 名称    |           |          | 类型                          | 说明                                                         |
| ------- | --------- | -------- | ----------------------------- | ------------------------------------------------------------ |
| status  |           |          | Number                        | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message |           |          | String                        | 状态说明                                                     |
| count   |           |          | Number                        | 本次搜索结果总数，另外本服务限制最多返回200条数据(data)， 翻页（pageIndex）超过搜索结果总数 或 最大200条限制时，将返回最后一页数据 |
| data    |           |          | Array（数组内各元素结构如下） | 搜索结果POI数组，每项为一个POI对象                           |
|         | id        |          | String                        | POI（地点）唯一标识                                          |
|         | title     |          | String                        | POI（地点）名称                                              |
|         | address   |          | String                        | 地址（不含省市区信息的短地址）                               |
|         | tel       |          | String                        | 电话                                                         |
|         | category  |          | String                        | POI分类                                                      |
|         | type      |          | Number                        | POI类型，值说明：0:普通POI / 1:公交车站 / 2:地铁站 / 3:公交线路 / 4:行政区划 |
|         | location  |          | TMap.LatLng                   | 坐标                                                         |
|         | _distance |          | Number                        | 距离，单位： 米，在周边搜索、城市范围搜索传入定位点时返回    |
|         | ad_info   |          | Object（对象结构如下）        | 行政区划信息                                                 |
|         |           | adcode   | Number                        | 行政区划代码，详见：行政区划代码说明 |
|         |           | province | String                        | 省                                                           |
|         |           | city     | String                        | 市                                                           |
|         |           | district | String                        | 区                                                           |

 <br>

## 关键词输入提示 {#10}

###  Suggestion 

---

用于获取输入关键字的补完与提示，以便帮助用户快速输入。

|构造函数|
| :- |
|new TMap.service.Suggestion(options)|


|参数名称|类型|说明|
| :- | :- | -- |
|options	| Object	|关键字提示类配置参数对象规范见下表|


| 名称      | 类型    | 是否必填 | 说明                                                         |
| --------- | ------- | -------- | ------------------------------------------------------------ |
| pageSize  | Number  | 否       | 每页条目数，最大限制为20条，默认为10条                       |
| region    | String  | 否       | 限制城市范围，根据城市名称限制地域范围， 如，仅获取“广州市”范围内的提示内容；缺省时侧进行全国范围搜索 |
| regionFix | Boolean | 否       | false：[默认]当前城市无结果时，自动扩大范围到全国匹配；<br/>true：固定在当前城市 |
| policy    | Number  | 否       | 检索策略，目前支持：<br/>policy=0：默认，常规策略；<br/>policy=1：本策略主要用于收货地址、上门服务地址的填写，提高了小区类、商务楼宇、大学等分类的排序，过滤行政区、道路等分类（如海淀大街、朝阳区等），排序策略引入真实用户对输入提示的点击热度，使之更为符合此类应用场景，体验更为舒适<br/>policy=10：出行场景（网约车） – 起点查询；<br/>policy=11：出行场景（网约车） – 终点查询 |
| filter    | String  | 否       | 筛选条件：<br/>基本语法：columnName<筛选列>=value<列值>；<br/>目前支持按POI分类筛选（例：category=分类词），若指定多个分类用英文逗号分隔，最多支持五个分类，支持的分类词可参考WebService API的相关说明 |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| getSuggestions(params: GetSuggestionsParams) | Promise | 获取输入关键字的补完与提示，帮助用户快速输入；搜索完成后resolve状态下返回SuggestionResult，reject状态下返回ErrorResult |
| setPageSize(pageSize:Number)                                 | this    | 设置每页返回的结果数量                                       |
| setRegion(region: String)                                    | this    | 设置城市范围                                                 |
| setRegionFix(regionFix: Boolean)                             | this    | 设置是否扩大匹配                                             |
| setPolicy(policy: Number)                                    | this    | 设置检索策略                                                 |
| setFilter(filter: String)                                    | this    | 设置筛选条件                                                 |
| getPageSize()                                                | Number  | 获取每页返回的结果数量                                       |
| getRegion()                                                  | String  | 获取城市范围                                                 |
| getRegionFix()                                               | Boolean | 获取是否扩大匹配                                             |
| getPolicy()                                                  | Number  | 获取检索策略                                                 |
| getFilter()                                                  | String  | 获取筛选条件                                                 |


 <br>

### GetSuggestionsParams {#11}

---


| 名称          | 类型        | 是否必填 | 说明                                                         |
| ------------- | ----------- | -------- | ------------------------------------------------------------ |
| keyword       | String | 是       | 希望获取输入提示的关键字                                         |
| location      | TMap.LatLng | 否       | 定位坐标，传入后，若用户搜索关键词为类别词（如酒店、餐馆时），与此坐标距离近的地点将靠前显示 |
| getSubpois    | Boolean     | 否       | 是否返回子地点，如大厦停车场、出入口等取值：<br/>false [默认]：不返回；<br/>true：返回 |
| addressFormat | String      | 否       | 地址格式，可选值：short，返回不包含省市区的短地址<br/>（缺省侧为包含省市区的标准地址） |
| pageIndex     | Number      | 否       | 第x页，默认第1页                                            |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### SuggestionResult {#12}

---

| 名称     |           | 类型                          | 是否必带 | 说明                                                         |
| :------- | --------- | :---------------------------- | :------- | :----------------------------------------------------------- |
| status   |           | Number                        | 是       | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message  |           | String                        | 是       | 状态说明                                                     |
| count    |           | Number                        | 是       | 结果总数（注：本服务一个查询条件最多返回100条结果）          |
| data     |           | Array（数组内各元素结构如下） | 是       | 提示词数组，每项为一个POI对象                                |
|          | id        | String                        | 是       | POI唯一标识                                                  |
|          | title     | String                        | 是       | 提示文字                                                     |
|          | address   | String                        | 是       | 地址                                                         |
|          | province  | String                        | 是       | 省                                                           |
|          | city      | String                        | 是       | 市                                                           |
|          | adcode    | String                        | 是       | 行政区划代码                                                 |
|          | type      | Number                        | 是       | POI类型，值说明：0:普通POI / 1:公交车站 / 2:地铁站 / 3:公交线路 / 4:行政区划 |
|          | _distance | Number                        | 否       | 传入location（定位坐标）参数时，返回定位坐标到各POI的距离    |
|          | location  | TMap.LatLng                   | 是       | 提示所述位置坐标                                             |
| sub_pois |           | Array（数组内各元素结构如下） | 否       | 子地点列表，仅在输入参数getSubpois=true时返回                |
|          | parent_id | String                        | 是       | 主地点ID，对应data中的地点ID                                 |
|          | id        | String                        | 是       | 地点唯一标识                                                 |
|          | title     | String                        | 是       | 地点名称                                                     |
|          | address   | String                        | 是       | 地址                                                         |
|          | location  | TMap.LatLng                   | 是       | 坐标                                                         |
|          | adcode    | Number                        | 是       | 行政区划代码                                                 |
|          | city      | String                        | 是       | 地点所在城市名称                                             |

 <br>

## 正逆地址解析 {#13}
### Geocoder 

---

提供文字地址与经纬度之间的转换工具。

|构造函数|
| :- |
|new TMap.service.Geocoder()|


| 方法                                | 返回值  | 说明                                                         |
| -------------------------------------- | ------- | ------------------------------------------------------------ |
| getAddress(params: GetAddressParams) | Promise | 提供由经纬度到文字地址及相关位置信息的转换能力；搜索完成后resolve状态下返回AddressResult，reject状态下返回ErrorResult |
| getLocation(params: GetLocationParams) | Promise | 根据指定的文字地址转换为经纬度，并同时提供结构化的省市区地址信息；搜索完成后resolve状态下返回LocationResult，reject状态下返回ErrorResult |

 <br>

### GetAddressParams {#14}

---

| 名称       | 类型        | 是否必填 | 说明                                                         |
| ---------- | ----------- | -------- | ------------------------------------------------------------ |
| location   | TMap.LatLng | 是       | 经纬度（GCJ02坐标系）                                        |
| getPoi     | Boolean     | 否       | 是否返回周边地点（POI）列表，可选值：<br/>false：不返回(默认)；<br/>true：返回 |
| poiOptions | String      | 否       | 周边POI列表控制参数，详见下方poiOptions用法 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### GetLocationParams  {#15}

---

| 名称    | 类型   | 是否必填 | 说明                                                 |
| ------- | ------ | -------- | ---------------------------------------------------- |
| address | String | 是       | 地址（注：地址中请包含城市名称，否则会影响解析效果） |
| region  | String | 否       | 地址所在城市（若地址中包含城市名称侧可不传）         |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### Geocoder类的 poiOptions 用法  {#16}

---

| 说明                                                         | 示例                                                         |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| 周边POI列表控制参数：<br/>1 poiOptions=address_format=short<br/>返回短地址，缺省时返回长地址<br/>2 poiOptions=radius=5000<br/>半径，取值范围 1-5000（米）<br/>3 poiOptions=policy=1/2/3/4/5<br/>控制返回场景，<br/>policy=1[默认] 以地标+主要的路+近距离POI为主，着力描述当前位置；<br/>policy=2 到家场景：筛选合适收货的POI，并会细化收货地址，精确到楼栋；<br/>policy=3 出行场景：过滤掉车辆不易到达的POI(如一些景区内POI)，增加道路出入口、交叉口、大区域出入口类POI，排序会根据真实API大用户的用户点击自动优化<br/>policy=4 社交签到场景，针对用户签到的热门 地点进行优先排序<br/>policy=5 位置共享场景，用户经常用于发送位置、位置分享等场景的热门地点优先排序<br/>4 注：本接口最多返回10条周边POI，如需更多请参见地点搜索-周边推荐 | 【单个参数写法示例】：<br/>poiOptions=address_format=short<br/>【多个参数英文分号间隔，写法示例】：<br/>poiOptions=address_format=short;radius=5000;policy=2 |

 <br>

### AddressResult  {#17}

---

| 名称       |                     |               |           | 类型                          | 是否必带 | 说明                                                         |
| :--------- | ------------------- | ------------- | --------- | :---------------------------- | :------- | :----------------------------------------------------------- |
| status     |                     |               |           | Number                        | 是       | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message    |                     |               |           | String                        | 是       | 状态说明                                                     |
| request_id |                     |               |           | String                        | 是       | 本次请求的唯一标识                                           |
| result     |                     |               |           | Object（对象结构如下）        | 是       | 逆地址解析结果                                               |
|            | address             |               |           | String                        | 是       | 以行政区划+道路+门牌号等信息组成的标准格式化地址             |
|            | formatted_addresses |               |           | Object（对象结构如下）        | 否       | 结合知名地点形成的描述性地址，更具人性化特点                 |
|            |                     | recommend     |           | String                        | 否       | 推荐使用的地址描述，描述精确性较高                           |
|            |                     | rough         |           | String                        | 否       | 粗略位置描述                                                 |
|            | address_component   |               |           | Object（对象结构如下）        | 是       | 地址部件，address不满足需求时可自行拼接                      |
|            |                     | nation        |           | String                        | 是       | 国家                                                         |
|            |                     | province      |           | String                        | 是       | 省                                                           |
|            |                     | city          |           | String                        | 是       | 市                                                           |
|            |                     | district      |           | String                        | 否       | 区，可能为空字串                                             |
|            |                     | street        |           | String                        | 否       | 街道，可能为空字串                                           |
|            |                     | street_number |           | String                        | 否       | 门牌，可能为空字串                                           |
|            | ad_info             |               |           | Object（对象结构如下）        | 是       | 行政区划信息                                                 |
|            |                     | nation_code   |           | String                        | 是       | 国家代码（ISO3166标准3位数字码）                             |
|            |                     | adcode        |           | String                        | 是       | 行政区划代码，规则详见：行政区划代码说明 |
|            |                     | city_code     |           | String                        | 是       | 城市代码，由国家码+行政区划代码（提出城市级别）组合而来，总共为9位 |
|            |                     | name          |           | String                        | 是       | 行政区划名称                                                 |
|            |                     | location      |           | TMap.LatLng                   | 是       | 行政区划中心点坐标                                           |
|            |                     | nation        |           | String                        | 是       | 国家                                                         |
|            |                     | province      |           | String                        | 是       | 省 / 直辖市                                                  |
|            |                     | city          |           | String                        | 是       | 市 / 地级区 及同级行政区划                                   |
|            |                     | district      |           | String                        | 否       | 区 / 县级市 及同级行政区划                                   |
|            | address_reference   |               |           | Object（对象结构如下）        | 否       | 坐标相对位置参考                                             |
|            |                     | famous_area   |           | Object（对象结构如下）        | 否       | 知名区域，如商圈或人们普遍认为有较高知名度的区域             |
|            |                     |               | id        | String                        | 是       | 地点唯一标识                                                 |
|            |                     |               | title     | String                        | 否       | 名称/标题                                                    |
|            |                     |               | location  | TMap.LatLng                   | 否       | 坐标                                                         |
|            |                     |               | _distance | Number                        | 否       | 此参考位置到输入坐标的直线距离                               |
|            |                     |               | _dir_desc | String                        | 否       | 此参考位置到输入坐标的方位关系，如：北、南、内               |
|            |                     | business_area |           | Object                        | 否       | 商圈【注】：对象结构同 famous_area                           |
|            |                     | town          |           | Object（对象结构如下）        | 否       | 乡镇街道                                                     |
|            |                     |               | id        | String                        | 是       | 地点唯一标识                                                 |
|            |                     |               | title     | String                        | 否       | 名称/标题                                                    |
|            |                     |               | location  | TMap.LatLng                   | 否       | 坐标                                                         |
|            |                     |               | _distance | Number                        | 否       | 此参考位置到输入坐标的直线距离                               |
|            |                     |               | _dir_desc | String                        | 否       | 此参考位置到输入坐标的方位关系，如：北、南、内               |
|            |                     | landmark_l1   |           | Object                        | 否       | 一级地标，可识别性较强、规模较大的地点、小区等 【注】对象结构同 famous_area |
|            |                     | landmark_l2   |           | Object                        | 否       | 二级地标，较一级地标更为精确，规模更小 【注】对象结构同 famous_area |
|            |                     | street        |           | Object                        | 否       | 街道 【注】对象结构同 famous_area                            |
|            |                     | street_number |           | Object                        | 否       | 门牌 【注】对象结构同 famous_area                            |
|            |                     | crossroad     |           | Object                        | 否       | 交叉路口 【注】对象结构同 famous_area                        |
|            |                     | water         |           | Object                        | 否       | 水系 【注】对象结构同 famous_area                            |
|            | poi_count           |               |           | Number                        | 否       | 查询的周边poi的总数，仅在传入参数getPoi=1时返回              |
|            | pois                |               |           | Array（数组内各元素结构如下） | 否       | 周边地点（POI）数组，数组中每个子项为一个POI对象             |
|            |                     | id            |           | String                        | 否       | 地点（POI）唯一标识                                          |
|            |                     | title         |           | String                        | 否       | 名称                                                         |
|            |                     | address       |           | String                        | 否       | 地址                                                         |
|            |                     | category      |           | String                        | 否       | 地点分类信息                                                 |
|            |                     | location      |           | TMap.LatLng                   | 否       | 提示所述位置坐标                                             |
|            |                     | ad_info       |           | Object（对象结构如下）        | 否       | 行政区划信息                                                 |
|            |                     |               | adcode    | Number                        | 是       | 行政区划代码                                                 |
|            |                     |               | province  | String                        | 是       | 省                                                           |
|            |                     |               | city      | String                        | 是       | 市                                                           |
|            |                     |               | district  | String                        | 是       | 区                                                           |
|            |                     | _distance     |           | Number                        | 否       | 该POI到逆地址解析传入的坐标的直线距离                        |

 <br>

### LocationResult  {#18}

---

| 名称    |                    |               | 类型                   | 是否必带 | 说明                                                         |
| :------ | ------------------ | ------------- | :--------------------- | :------- | :----------------------------------------------------------- |
| status  |                    |               | Number                 | 是       | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message |                    |               | String                 | 是       | 状态说明                                                     |
| result  |                    |               | Object（对象结构如下） | 是       | 地址解析结果                                                 |
|         | title              |               | String                 | 是       | 解析到坐标所用到的关键地址、地点                             |
|         | location           |               | TMap.LatLng            | 是       | 解析到的坐标（GCJ02坐标系）                                  |
|         | address_components |               | Object（对象结构如下） | 是       | 解析后的地址部件                                             |
|         |                    | province      | String                 | 是       | 省                                                           |
|         |                    | city          | String                 | 是       | 市                                                           |
|         |                    | district      | String                 | 是       | 区，可能为空字串                                             |
|         |                    | street        | String                 | 是       | 街道，可能为空字串                                           |
|         |                    | street_number | String                 | 是       | 门牌，可能为空字串                                           |
|         | ad_info            |               | Object（对象结构如下） | 是       | 行政区划信息                                                 |
|         |                    | adcode        | String                 | 是       | 行政区划代码，规则详见：行政区划代码说明 |
|         | similarity         |               | Number                 | 是       | 即将下线，由reliability代替                                  |
|         | deviation          |               | Number                 | 是       | 即将下线，由level代替                                        |
|         | reliability        |               | Number                 | 是       | 可信度参考：值范围 1 <低可信> - 10 <高可信> 我们根据用户输入地址的准确程度，在解析过程中，将解析结果的可信度(质量)，由低到高，分为1 - 10级，该值>=7时，解析结果较为准确，<7时，会存各类不可靠因素，开发者可根据自己的实际使用场景，对于解析质量的实际要求，进行参考 |
|         | level              |               | Number                 | 否       | 解析精度级别，分为11个级别，一般>=9即可采用（定位到点，精度较高） 也可根据实际业务需求自行调整，完整取值表见WebService API的相关说明 |

 <br>

## 路线规划  {#19}
### Driving

---

提供驾车路线规划服务，支持结合实时路况、少收费、不走高速等多种偏好，精准预估到达时间。

|构造函数|
| :- |
|new TMap.service.Driving(options)|


|参数名称|类型|说明|
| :- | :- | -- |
|options	| Object	|驾车路线规划服务类配置参数对象规范见下表|


| 名称        | 类型    | 是否必填 | 说明                                                         |
| ----------- | ------- | -------- | ------------------------------------------------------------ |
| policy      | String  | 否       | 检索策略<br />一、策略参数（以下三选一）<br/>LEAST_TIME：[默认]参考实时路况，时间最短；<br/>PICKUP：网约车场景 – 接乘客；<br/>TRIP：网约车场景 – 送乘客<br/>二、单项偏好参数<br/>（可与策略参数并用，可多选，逗号分隔）<br/>REAL_TRAFFIC：参考实时路况；<br/>LEAST_FEE：少收费；<br/>AVOID_HIGHWAY：不走高速；<br/>NAV_POINT_FIRST： 该策略会通过终点坐标查找所在地点（如小区/大厦等），并使用地点出入口做为目的地，使路径更为合理 |
| mp          | Boolean | 否       | 是否返回多种方案：<br />true：返回多种方案；<br />false：返回一种方案 |
| noStep      | Boolean | 否       | 是否不需路线引导：<br />true： 不需路线引导；<br />false：需要路线引导 |
| plateNumber | String  | 否       | 车牌号，填入后，路线引擎会根据车牌对限行区域进行避让，不填则不不考虑限行问题 |
| carType     | Number  | 否       | 车辆类型：<br />0：[默认]普通汽车；<br/>1：新能源            |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| search(params: DrivingSearchParams) | Promise | 搜索驾车路线；搜索完成后resolve状态下返回DrivingPlan，reject状态下返回ErrorResult |
| setPolicy(policy: String)                                    | this    | 设置检索策略                                                 |
| setMp(mp:Boolean)                                            | this    | 设置是否返回多种方案                                         |
| setNoStep(noStep: Boolean)                                   | this    | 设置是否不需路线引导                                         |
| setPlateNumber(plateNumber:String)                           | this    | 设置车牌号                                                   |
| setCarType(carType:String)                                   | this    | 设置车辆类型                                                 |
| getPolicy()                                                  | String  | 获取检索策略                                                 |
| getMp()                                                      | Boolean | 获取是否返回多种方案的设置                                   |
| getNoStep()                                                  | Boolean | 获取是否不需路线引导的设置                                   |
| getPlateNumber()                                             | String  | 获取车牌号                                                   |
| getCarType()                                                 | Number  | 获取车辆类型                                                 |


 <br>

### DrivingSearchParams   {#20}

---


| 名称         | 类型             | 是否必填 | 说明                                                         |
| ------------ | ---------------- | -------- | ------------------------------------------------------------ |
| from         | TMap.LatLng      | 是       | 起点位置坐标                                                 |
| to           | TMap.LatLng      | 是       | 终点位置坐标                                                 |
| fromPoi      | String           | 否       | 起点POI ID，传入后，优先级高于from                           |
| heading      | Number           | 否       | [from辅助参数]在起点位置时的车头方向，数值型，取值范围0至360（0度代表正北，顺时针一周360度）；传入车头方向，对于车辆所在道路的判断非常重要，直接影响路线计算的效果 |
| speed        | Number           | 否       | [from辅助参数]速度，单位：米/秒，默认3； 当速度低于1.39米/秒时，heading将被忽略 |
| accuracy     | Number           | 否       | [from辅助参数]定位精度，单位：米，取>0数值，默认5；当定位精度>30米时heading参数将被忽略 |
| roadType     | Number           | 否       | [from辅助参数] 起点道路类型，可选值：<br/>0 [默认]不考虑起点道路类型；<br/>1 在桥上；2 在桥下；3 在主路；4 在辅路；5 在对面；6 桥下主路；7 桥下辅路 |
| fromTrack    | TMap.LatLng[]    | 否       | 起点轨迹：在真实的场景中，易受各种环境及设备精度影响，导致定位点产生误差，传入起点前段轨迹，可有效提升准确度；传入一个TMap.LatLng数组，其元素为轨迹中的点 |
| toPoi        | String           | 否       | 终点POI ID（可通过腾讯位置服务地点搜索服务得到），当目的地为较大园区、小区时，会以引导点做为终点（如出入口等），体验更优；该参数优先级高于to（坐标），但是当目的地无引导点数据或POI ID失效时，仍会使用to（坐标）作为终点 |
| waypoints    | TMap.LatLng[]    | 否       | 为TMap.LatLng数组，其元素依序为途经的点                      |
| avoidPolygon | TMap.LatLng[] [] | 否       | 为TMap.LatLng的二维数组，表示避让区域。第一层每个元素代表一个多边形避让区域，最多支持32个避让区域；第二层每个元素代表多边形中的一个顶点，每个区域最多可有9个顶点 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>

### DrivingPlan   {#21}

---

| 参数    |        |                     |                  | 类型                          | 是否必带 | 说明                                                         |
| :------ | ------ | ------------------- | ---------------- | :---------------------------- | :------- | :----------------------------------------------------------- |
| status  |        |                     |                  | Number                        | 是       | 状态码，正常为0                                              |
| message |        |                     |                  | String                        | 是       | 状态说明                                                     |
| result  |        |                     |                  | Object（对象结构如下）        | 是       | 搜索结果                                                     |
|         | routes |                     |                  | Array（数组内各元素结构如下） | 是       | 路线方案（设置getMp=1时可返回最多3条）                       |
|         |        | mode                |                  | String                        | 是       | 方案交通方式，固定值：“DRIVING”                              |
|         |        | tags                |                  | String[]                      | 否       | 方案标签，表明方案特色 示例：tags:[“LEAST_LIGHT”]            |
|         |        | distance            |                  | Number                        | 是       | 方案总距离，单位：米                                         |
|         |        | duration            |                  | Number                        | 是       | 方案估算时间（结合路况），单位：分钟                         |
|         |        | traffic_light_count |                  | Number                        | 是       | 方案途经红绿灯个数                                           |
|         |        | toll                |                  | Number                        | 否       | 预估过路费（仅供参考），单位：元                             |
|         |        | restriction         |                  | Object（对象结构如下）        | 否       | 限行信息                                                     |
|         |        |                     | status           | Number                        | 是       | 限行状态码： 0 途经没有限行城市，或路线方案未涉及限行区域；1 途经包含有限行的城市；3 [设置车牌] 已避让限行 ；4 [设置车牌] 无法避开限行区域（本方案包含限行路段） |
|         |        | polyline            |                  | TMap.LatLng[]                 | 是       | 方案路线坐标点串                                             |
|         |        | waypoints           |                  | Array（数组内各元素结构如下） | 否       | 途经点，顺序与输入waypoints一致 （输入waypoints时才会有此结点返回） |
|         |        |                     | title            | String                        | 否       | 途经点路名                                                   |
|         |        |                     | location         | TMap.LatLng                   | 否       | 途经点坐标                                                   |
|         |        | taxi_fare           |                  | Object（对象结构如下）        | 否       | 预估打车费                                                   |
|         |        |                     | fare             | Number                        | 否       | 预估打车费用，单位：元                                       |
|         |        | steps               |                  | Array（数组内各元素结构如下） | 是       | 路线步骤                                                     |
|         |        |                     | instruction      | String                        | 是       | 阶段路线描述                                                 |
|         |        |                     | polyline_idx     | Number[]                      | 是       | 阶段路线坐标点串在方案路线坐标点串的位置                     |
|         |        |                     | road_name        | String                        | 否       | 阶段路线路名                                                 |
|         |        |                     | dir_desc         | String                        | 否       | 阶段路线方向                                                 |
|         |        |                     | distance         | Number                        | 是       | 阶段路线距离，单位：米                                       |
|         |        |                     | act_desc         | String                        | 否       | 阶段路线末尾动作：如：左转调头                               |
|         |        |                     | accessorial_desc | String                        | 否       | 末尾辅助动作：如：到达终点                                   |


 <br>

### Bicycling   {#22}

---

提供骑行路线规划服务。

|构造函数|
| :- |
|new TMap.service.Bicycling()|


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| search(params: BicyclingSearchParams) | Promise | 搜索骑行路线；搜索完成后resolve状态下返回BicyclingPlan，reject状态下返回ErrorResult |


 <br>

### BicyclingSearchParams  {#23}

---

| 名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型        | 是否必填 | 说明                                                         |
| ----- | ----------- | -------- | ------------------------------------------------------------ |
| from  | TMap.LatLng | 是       | 起点位置坐标                                                 |
| to    | TMap.LatLng | 是       | 终点位置坐标                                                 |
| toPoi | String      | 否       | 终点POI ID（可通过腾讯位置服务地点搜索服务得到），当目的地为较大园区、小区时，会以引导点做为终点（如出入口等），体验更优；该参数优先级高于to（坐标），但是当目的地无引导点数据或POI ID失效时，仍会使用to（坐标）作为终点 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |


 <br>

### BicyclingPlan  {#24}



| 参数    |        |           |              | 类型                          | 是否必带 | 说明                                     |
| :------ | ------ | --------- | ------------ | :---------------------------- | :------- | :--------------------------------------- |
| status  |        |           |              | Number                        | 是       | 状态码，正常为0                          |
| message |        |           |              | String                        | 是       | 状态说明                                 |
| result  |        |           |              | Object（对象结构如下）        | 是       | 搜索结果                                 |
|         | routes |           |              | Array（数组内各元素结构如下） | 是       | 路线方案                                 |
|         |        | mode      |              | String                        | 是       | 方案交通方式，固定值：“BICYCLING”        |
|         |        | distance  |              | Number                        | 是       | 方案整体距离，单位：米                   |
|         |        | duration  |              | Number                        | 是       | 方案估算时间，单位：分钟                 |
|         |        | direction |              | String                        | 是       | 方案整体方向                             |
|         |        | polyline  |              | TMap.LatLng[]                 | 是       | 方案路线坐标点串                         |
|         |        | steps     |              | Array（数组内各元素结构如下） | 是       | 路线步骤                                 |
|         |        |           | instruction  | String                        | 是       | 阶段路线描述                             |
|         |        |           | polyline_idx | Number[]                      | 是       | 阶段路线坐标点串在方案路线坐标点串的位置 |
|         |        |           | road_name    | String                        | 否       | 阶段路线路名                             |
|         |        |           | dir_desc     | String                        | 否       | 阶段路线方向                             |
|         |        |           | distance     | Number                        | 是       | 阶段路线距离，单位：米                   |
|         |        |           | act_desc     | String                        | 否       | 阶段路线末尾动作                         |

 <br>

### Walking {#25}

---

提供步行路线规划服务。

| 构造函数                   |
| :------------------------- |
| new TMap.service.Walking() |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| search(params: WalkingSearchParams) | Promise | 搜索自步行路线；搜索完成后resolve状态下返回WalkingPlan，reject状态下返回ErrorResult |

 <br>

### WalkingSearchParams{#26}

---

| 名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型        | 是否必填 | 说明                                                         |
| ----- | ----------- | -------- | ------------------------------------------------------------ |
| from  | TMap.LatLng | 是       | 起点位置坐标                                                 |
| to    | TMap.LatLng | 是       | 终点位置坐标                                                 |
| toPoi | String      | 否       | 终点POI ID（可通过腾讯位置服务地点搜索服务得到），当目的地为较大园区、小区时，会以引导点做为终点（如出入口等），体验更优；该参数优先级高于to（坐标），但是当目的地无引导点数据或POI ID失效时，仍会使用to（坐标）作为终点 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |


 <br>

###  WalkingPlan {#27}

---

| 参数    |        |           |              | 类型                          | 是否必带 | 说明                                                         |
| :------ | ------ | --------- | ------------ | :---------------------------- | :------- | :----------------------------------------------------------- |
| status  |        |           |              | Number                        | 是       | 状态码，正常为0                                              |
| message |        |           |              | String                        | 是       | 状态说明                                                     |
| result  |        |           |              | Object（对象结构如下）        | 是       | 搜索结果                                                     |
|         | routes |           |              | Array（数组内各元素结构如下） | 是       | 路线方案                                                     |
|         |        | mode      |              | String                        | 是       | 方案交通方式，固定值：“WALKING”                              |
|         |        | distance  |              | Number                        | 是       | 方案整体距离，单位：米                                       |
|         |        | duration  |              | Number                        | 是       | 方案估算时间，单位：分钟                                     |
|         |        | direction |              | String                        | 是       | 方案整体方向                                                 |
|         |        | polyline  |              | TMap.LatLng[]                 | 是       | 方案路线坐标点串                                             |
|         |        | steps     |              | Array（数组内各元素结构如下） | 是       | 路线步骤                                                     |
|         |        |           | instruction  | String                        | 是       | 阶段路线描述                                                 |
|         |        |           | polyline_idx | Number[]                      | 是       | 阶段路线坐标点串在方案路线坐标点串的位置                     |
|         |        |           | road_name    | String                        | 否       | 阶段路线路名                                                 |
|         |        |           | dir_desc     | String                        | 否       | 阶段路线方向                                                 |
|         |        |           | distance     | Number                        | 是       | 阶段路线距离，单位：米                                       |
|         |        |           | act_desc     | String                        | 否       | 阶段路线末尾动作                                             |
|         |        |           | type         | Number                        | 是       | 阶段路线的步行设施类型（type），包含： 0普通道路，1过街天桥，2地下通道，3人行横道 |


 <br>

### Transit  {#28}

---

提供公交换乖路线规划服务。

| 构造函数                          |
| :-------------------------------- |
| new TMap.service.Transit(options) |


| 参数名称 | 类型   | 说明                                         |
| :------- | :----- | -------------------------------------------- |
| options  | Object | 公交换乖路线规划服务类配置参数对象规范见下表 |


| 名称   | 类型   | 是否必填 | 说明                                                         |
| ------ | ------ | -------- | ------------------------------------------------------------ |
| policy | String | 否       | 检索策略<br />1) 排序策略，以下四选一：<br/>policy=LEAST_TIME：时间短（默认）；<br/>policy=LEAST_TRANSFER：少换乘；<br/>policy=LEAST_WALKING：少步行；<br/>policy=RECOMMEND：推荐策略，结合步行、换乘、耗时等多方面综合排序结果（与腾讯地图APP默认策略一致）<br/>2) 额外限制条件：<br/>NO_SUBWAY：不坐地铁；<br/>ONLY_SUBWAY：只坐地铁；<br/>SUBWAY_FIRST：地铁优先；<br/>3) 排序策略与额外条件可同时使用，如：<br/>policy=LEAST_TRANSFER,NO_SUBWAY |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| search(params: TransitSearchParams) | Promise | 搜索公交换乘路线；搜索完成后resolve状态下返回TransitPlan，reject状态下返回ErrorResult |
| setPolicy(policy: String)                                    | this    | 设置检索策略                                                 |
| getPolicy()                                                  | String  | 获取检索策略                                                 |


 <br>

### TransitSearchParams  {#29}

---

| 名称          | 类型        | 是否必填 | 说明                                                         |
| ------------- | ----------- | -------- | ------------------------------------------------------------ |
| from          | TMap.LatLng | 是       | 起点位置坐标                                                 |
| to            | TMap.LatLng | 是       | 终点位置坐标                                                 |
| departureTime | Number      | 否       | 出发时间，用于过滤掉非运营时段的线路，格式为Unix时间戳，默认使用当前时间 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |


 <br>

### TransitPlan{#30}

---

| 参数    |        |          |          | 类型                          | 是否必带 | 说明                                                         |
| :------ | ------ | -------- | -------- | :---------------------------- | :------- | :----------------------------------------------------------- |
| status  |        |          |          | Number                        | 是       | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message |        |          |          | String                        | 是       | 状态说明                                                     |
| result  |        |          |          | Object（对象结构如下）        | 是       | 计算结果                                                     |
|         | routes |          |          | Array（数组内各元素结构如下） | 是       | 路线方案                                                     |
|         |        | distance |          | Number                        | 是       | 方案整体距离，单位：米                                       |
|         |        | duration |          | Number                        | 是       | 方案估算时间，单位：分钟                                     |
|         |        | bounds   |          | Number                        | 是       | 整体路线的外接矩形范围，可在地图显示时使用， 通过矩形西南+东北两个端点坐标定义而面，示例： “39.901405,116.334023,39.940289,116.451720” |
|         |        | steps    |          | Array（数组内各元素结构如下） | 是       | 一条完整公交路线可能会包含多种公共交通工具，各交通工具的换乘由步行路线串联起来，形成这样的结构（即 steps数组的结构）： [步行 , 公交 , 步行 , 公交 , 步行(到终点)] |
|         |        |          | mode     | String                        | 是       | 本段交通方式，取值： <br />WALKING：步行 <br />TRANSIT：公共交通工具<br />不同的方式，返回不同的数据结构，须根据该参数值来判断以哪种结构进行解析，各类具体定义见WebService API的相关说明 |
|         |        |          | 其他字段 |                               | 是       | 随mode不同有不同字段返回，见WebService API的相关说明；其中凡为经纬度位置信息的，以TMap.LatLng格式输出。；凡为路线信息的，以TMap.LatLng格式的数组输出 |


 <br>

## 行政区划  {#31}

### District 

---

本接口提供中国标准行政区划数据，可用于生成城市列表控件等功能时使用。

| 构造函数                           |
| :--------------------------------- |
| new TMap.service.District(options) |


| 参数名称 | 类型   | 说明                                     |
| :------- | :----- | ---------------------------------------- |
| options  | Object | 行政区划数据服务类配置参数对象规范见下表 |


| 名称      | 类型   | 是否必填 | 说明                                                         |
| --------- | ------ | -------- | ------------------------------------------------------------ |
| polygon   | Number | 否       | 返回行政区划轮廓点串（经纬度点串）<br />注：本参数仅在keyword为adcode，且仅检索一个行政区划时生效<br />0：默认，不返回轮廓<br/>1：包含海域，3公里抽稀粒度<br/>2：纯陆地行政区划，可通过max_offset设置返回轮廓的抽稀级别 |
| maxOffset | Number | 否       | 轮廓点串的抽稀精度（仅对get_polygon=2时支持），单位米，可选值：<br/>100 ：100米（当缺省id返回省级区划时，将按500米返回，其它级别正常生效）<br/>500 ：500米<br/>1000：1000米<br/>3000：3000米 |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| list()                                                       | Promise | 获取省市区列表；搜索完成后resolve状态下返回DistrictInfo，reject状态下返回ErrorResult |
| getChildren(params: GetChildrenParams) | Promise | 获取指定行政区代码的下级行政区划；搜索完成后resolve状态下返回DistrictInfo，reject状态下返回ErrorResult |
| search(params: SearchParams) | Promise | 以关键字搜索行政区划；搜索完成后resolve状态下返回DistrictInfo，reject状态下返回ErrorResult |
| setPolygon(polygon: Number)                                  | this    | 设置是否获取行政区范围多边形数据                             |
| setMaxOffset(maxOffset: Number)                              | this    | 设置多边形数据精度                                           |
| getPolygon()                                                 | Number  | 获取是否获取行政区范围多边形数据                             |
| getMaxOffset()                                               | Number  | 获取多边形数据精度                                           |

 <br>


### GetChildrenParams {#32}

---

| 名称 | 类型   | 是否必填 | 说明                                                         |
| ---- | ------ | -------- | ------------------------------------------------------------ |
| id   | String | 否       | 父级行政区划ID（adcode），缺省时返回一级行政区划，也就是省级 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |

 <br>


###  SearchParams {#33}

---

| 名称    | 类型   | 是否必填 | 说明                                                         |
| ------- | ------ | -------- | ------------------------------------------------------------ |
| keyword | String | 是       | 搜索关键词：<br/>1.支持输入一个文本关键词<br/>2.支持多个行政区划代码(adcode)，英文逗号分隔 |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |


 <br>

### DistrictInfo {#34}

---

| 名称         |            |          |            | 类型                          | 是否必带 | 说明                                                         |
| :----------- | ---------- | -------- | ---------- | :---------------------------- | :------- | :----------------------------------------------------------- |
| status       |            |          |            | Number                        | 是       | 状态码，0为正常，其它为异常                                  |
| message      |            |          |            | String                        | 是       | 状态说明                                                     |
| data_version |            |          |            | Number                        | 是       | 行政区划数据版本，便于您判断更新                             |
| result[]     |            |          |            | Array                         | 是       | 结果数组                                                     |
|              | 其下数组项 |          |            | Array（数组内各元素结构如下） | 否       | 第0项，代表一级行政区划，第1项代表二级行政区划，以此类推；使用getChildren接口时，仅为指定父级行政区划的子级区划 |
|              |            | id       |            | String                        | 是       | 行政区划唯一标识（adcode）                                   |
|              |            | name     |            | String                        | 是       | 简称，如“内蒙古”                                             |
|              |            | fullname |            | String                        | 是       | 全称，如“内蒙古自治区”                                       |
|              |            | location |            | TMap.LatLng                   | 是       | 经纬度                                                       |
|              |            | pinyin   |            | String[]                      | 否       | 行政区划拼音，每一下标为一个字的全拼如： [“nei”,“meng”,“gu”] |
|              |            | cidx     |            | Number[]                      | 否       | 子级行政区划在下级数组中的下标位置                           |
|              |            | polygon  |            | Array                         | 否       | 该行政区划的轮廓经纬度点串（当使用getPolygon=1或2时返回），数组每一项为一个多边形，一个行政区划可以由多块多边形组成 |
|              |            |          | 其下数组项 | TMap.LatLng[]                 | 否       | 每个数组为一个轮廓多边形点串                                 |


 <br>

## IP定位  {#35}

### IPLocation


---

通过终端设备IP地址获取其当前所在地理位置，精确到市级，常用于显示当地城市天气预报、初始化用户城市等非精确定位场景。

| 构造函数                      |
| :---------------------------- |
| new TMap.service.IPLocation() |


| 方法                                                         | 返回值  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| locate(params: LocateParams) | Promise | 通过终端设备IP地址ip获取其当前所在地理位置；搜索完成后resolve状态下返回IPLocationResult，reject状态下返回ErrorResult |

 <br>


### LocateParams {#36}

---

| 名称 | 类型   | 是否必填 | 说明                           |
| ---- | ------ | -------- | ------------------------------ |
| ip   | String | 否       | IP地址，缺省时会使用请求端的IP |
| servicesk  | String      | 否       | 签名校验<br/> 开启WebServiceAPI签名校验的必传参数，只需要传入生成的SK字符串即可，不需要进行MD5加密操作                                            |


 <br>

### IPLocationResult {#38}

---

| 名称    |          |          | 类型                   | 是否必带 | 说明                                                         |
| :------ | -------- | -------- | :--------------------- | :------- | :----------------------------------------------------------- |
| status  |          |          | Number                 | 是       | 状态码，0为正常，其它为异常，详细请参阅状态码说明 |
| message |          |          | String                 | 是       | 对status的描述                                               |
| result  |          |          | Object（对象结构如下） | 是       | IP定位结果                                                   |
|         | ip       |          | String                 | 是       | 用于定位的IP地址                                             |
|         | location |          | TMap.LatLng            | 是       | 定位坐标                                                     |
|         | ad_info  |          | Object（对象结构如下） | 是       | 定位行政区划信息                                             |
|         |          | nation   | String                 | 是       | 国家                                                         |
|         |          | province | String                 | 是       | 省                                                           |
|         |          | city     | String                 | 否       | 市                                                           |
|         |          | district | String                 | 否       | 区                                                           |
|         |          | adcode   | Number                 | 是       | 行政区划代码                                                 |


 <br>

### ErrorResult {#37}

---

| 名称    | 类型   | 是否必带 | 说明     |
| ------- | ------ | -------- | -------- |
| status  | Number | 是       | 状态码   |
| message | String | 是       | 错误信息 |