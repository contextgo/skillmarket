## geometry 
----
&nbsp;&nbsp;&nbsp;&nbsp;几何计算库中的方法，进行距离、夹角、面积的计算，求取外接矩形，判断点、线、面之间的关系。
|使用示例|
| :- |
|var distance = TMap.geometry.computeDistance(path);|


| 方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|computeDistance(path: LatLng[] )	|Number	|计算传入路径的距离之和(单位：米)。|
|computeDestination(start: LatLng, heading: Number I LatLng, distance: Number)	|LatLng	|终点计算，根据起点、朝向和距离计算终点。（或根据线段的起点、终点、距离计算，会沿着起点指向终点的方向，从终点再前进指定的距离，单位：米）正北方向为0度，顺时针为正。|
|computeDistanceToLine(point: LatLng, line: LatLng[])	|Number	|计算点到直线的最短距离（单位：米）。|
|computeHeading(start: LatLng, end:LatLng, thumb: Boolean)	|Number	|计算两点之间的航向，默认为true，即为恒向线航向。设置为false为大圆航向，即最短路径的航向 (与正北的夹角，顺时针为正，单位：度）。|
|computeArea(polygon: LatLng[])	|Number	|计算多边形面积（只支持简单多边形，即一维数组，单位：平方米）。|
|computeCentroid(polygon: LatLng[])	|LatLng	|计算多边形的形心（只支持简单多边形， 即一维数组）。|
|computeBoundingRectangle(coords: LatLng[])	|LatLngBounds	|计算输入点的包围矩形。|
|isPointOnSegment(point: LatLng, segment: LatLng[], tolerance: Number)	|Boolean	|判断点是否在线段上 (tolerance单位为米)。|
| isPointInPolygon(point:  LatLng, polygon: LatLng[] \| LatLng[][], isPolygonWithHoles: Boolean) | Boolean| 判断点是否在多边形内，支持简单多边形、多个多边形和带洞多边形（在多边形边上认定为不在多边形内），isPolygonWithHoles默认为false  |
|isSegmentIntersect(segment: LatLng[], segment: LatLng[])	|Boolean	|判断线段是否与线段相交。|
|isSelfIntersect(polyline: LatLng[])	|Boolean	|判断折线是否自相交。|
|isPolygonIntersect(polygon: LatLng[], polygon: LatLng[])	|Boolean	|判断多边形是否与多边形相交（只支持简单多边形， 即一维数组）。|
| isClockwise(path:  LatLng[]) | Boolean | 判断一个经纬度路径是否为顺时针 |
| isLinePolygonIntersect(line: LatLng[], polygon: LatLng[] \| LatLng[][]) | Boolean | 判断线是否与单个或多个多边形相交，仅适用于简单多边形 |
| isPolygonInPolygon(innerPolygon: LatLng[], outerPolygon: LatLng[]) | Boolean | 判断多边形是否在另一个多边形内，仅支持简单多边形 |
| isPointOnPolygon(potint: LatLng, polygon: LatLng[] \| LatLng[][], tolerance?: Number) | Boolean | 判断点是否在单个或多个多边形的边上，传入多个多边形时点在任意一多边形边上即返回true，tolerance为误差范围 | 
| computeDistanceToSegment(point:  LatLng, line: LatLng[]) | Number | 计算给定点与线段之间的最短距离 |
| computePolygonIntersection(polygon1: LatLng[], polygon2: LatLng[])  | LatLng[] \| null \| Boolean | 计算多边形与多边形的交集区域（只支持简单凸多边形） |
| computeClosestPointOnLine(point: LatLng, line: LatLng[]) | LatLng \| null | 计算line上距离point最近的点。 |
| transfromClockwise(path: LatLng[])  | LatLng[]  \| Boolean | 将一个路径变为顺时针方向 |
| transfromAntiClockwise(path: LatLng[])  | LatLng[]  \| Boolean | 将一个路径变为逆时针方向 |
