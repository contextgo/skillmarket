## 地图 {#1}
- Map API中的核心类，用于创建地图实例。
- MapOptions 地图配置参数，通过这个参数来控制初始化地图的中心点、缩放级别、俯仰角度等。
- MapRenderOptions 地图渲染配置参数属性。
- SkyOptions 地图天空背景配置参数属性。
- FogOptions 地图雾化配置参数属性。
- FitBoundsOptions 地图自适应地理范围配置参数，可控制边距以及限制缩放等级。
- AnimationOptions 地图动画参数。
- AnimationEvent 地图动画事件回调参数规范。
- MapKeyFrame 地图动画关键帧对象。
- HighlightOptions 地图高亮区域设置。
- ClipOptions 地图掩膜区域设置。
- EaseOptions 地图缓动变化配置参数，可控制动画时长等。
- VectorBaseMap VectorBaseMap 对象规范。
- SatelliteBaseMap SatelliteBaseMap 对象规范。
- TrafficBaseMap TrafficBaseMap 对象规范。
- TMap.constants.MAP_ZOOM_TYPE 地图缩放焦点常量。
- TMap.constants.LAYER_LEVEL 图层渲染层级常量。
- TMap.constants. IMAGE_DISPLAY 图片呈现方式常量。
</br>

## 点标记 {#2}
- MultiMarker 表示地图上的多个标注点，可自定义标注的图标。
- MultiMarkerOptions MultiMarker的配置参数。
- CollisionOptions 图层碰撞配置参数。
- MarkerStyle 应用于Marker图层的样式类型。
- MarkerStyleOptions  MarkerStyle配置参数。
- PointGeometry 点图形数据。
- MoveAlongParam moveAlong方法的参数对象。
- MarkerMovingEventItem 点标记沿线移动时返回的信息。
- MarkerAnimation 点标记入离场动画配置参数。
- MarkerAnimationParams 点标记动画配置参数。
- LabelWrapOptions 点标记文本换行配置参数。
</br>

## 矢量图形 {#3}
- MultiPolyline 表示地图上的多个折线，可以自定义每个折线的样式。
- MultiPolylineOptions MultiPolyline配置参数。
- PolylineStyle 表示应用于折线图层的样式类型。
- ArrowOptions  折线上箭头配置参数。
- PolylineGeometry 折线数据。
- MultiPolygon 表示地图上的多个多边形，可以自定义每个多边形的样式。
- MultiPolygonOptions MultiPolygon配置参数。
- PolygonStyle 表示应用于多边形图层的样式类型。
- ExtrudablePolygonStyle  表示应用于有立体拉伸需求的多边形的样式类型。
- PolygonGeometry 多边形数据。
- MultiRectangle 表示地图上的多个矩形，可以自定义每个矩形的样式。
- MultiRectangleOptions MultiRectangle配置参数。
- RectangleStyle 表示应用于矩形图层的样式类型。
- RectangleStyleOptions  RectangleStyle配置参数。
- RectangleGeometry 多矩形数据。
- MultiCircle 表示地图上的多个圆形，可以自定义每个圆形的样式。
- MultiCircleOptions MultiCircle配置参数。
- CircleGeometry 多圆数据。
- CircleStyle 表示应用于圆图层的样式类型。
- CircleStyleOptions CircleStyle配置参数。
- MultiEllipse 表示地图上的多个椭圆，可以自定义每个椭圆的样式。
- MultiEllipseOptions  MultiEllipse配置参数。
- EllipseStyle 表示应用于椭圆图层的样式类型。
- EllipseStyleOptions EllipseStyle配置参数。
- EllipseGeometry 多椭圆数据。
</br>

## 文本标记 {#4}
- MultiLabel 表示地图上的多个文本标注，可以自定义每个文本标注的样式。
- MultiLabelOptions MultiLabel配置参数。
- LabelStyle 表示应用于多标注图层的样式类型。
- LabelGeometry 文本数据。
- LabelWrapOptions 文本换行配置参数。
- CollisionOptions 图层碰撞配置参数。
</br>

## DOM覆盖物 {#5}
- DOMOverlay DOM覆盖物抽象类，用户可以此作为基类实现自定义的DOM覆盖物类。
- DOMOverlayOptions 自定义DOM覆盖物配置参数。
- CollisionOptions 图层碰撞配置参数。
</br>

## 信息窗体 {#6}
- InfoWindow 用于创建信息窗覆盖物。
- InfoWindowOptions 信息窗配置参数。
</br>

## 点聚合 {#7}
- MarkerCluster 点聚合，可以对地图上的点进行聚合。
- MarkerClusterOptions  MarkerCluster配置参数。
- CollisionOptions 
 碰撞配置参数。
</br>

## 控件 {#8}
- Control 控件的基类，控件的方法及常量说明。
- ZoomControl 控件的基类，控件的方法及常量说明。
- TMap.constants.CONTROL_POSITION  控件位置常量说明。
- TMap.constants.DEFAULT_CONTROL_ID  默认控件常量说明。
</br>

## 自定义图层 {#9}
- ImageTileLayer 用于创建自定义栅格瓦片图层。
- ImageTileLayerOptions 配置参数。
- CustomLayerOptions 个性化图层配置参数。
- WMSLayer 创建基于OGC标准的WMS地图服务的图层类，仅支持EPSG3857坐标系统的WMS图层。
- WMSLayerOptions  WMSLayer配置参数。
- WMSParams WMSParams 对象规范
- WMTSLayer 创建基于OGC标准的WMTS地图服务的图层类，仅支持EPSG3857坐标系统的WMTS图层。
- WMTSLayerOptions WMTSLayer配置参数。
- WMTSParams WMTSParams 对象规范
- ImageGroundLayer 用于创建自定义图片图层，图片会随着地图缩放而缩放。
- ImageGroundLayerOptions ImageGroundLayer配置参数。
- CanvasGroundLayer 用于创建自定义图片图层，图片会随着地图缩放而缩放。
- CanvasGroundLayerOptions CanvasGroundLayer配置参数。
- MaskLayer 用于创建遮罩图层。
- MaskLayerOptions MaskLayer配置参数。
- MaskGeometry 单个遮罩区域数据。
- GLCustomLayer 用于创建自定义GL图层，可配合threejs实现自定义覆盖物效果。
- GLCustomLayerOptions GLCustomLayer配置参数。
</br>

## 事件 {#10}
- MapEvent 地图事件返回参数规范。
- POIInfo  地图事件返回参数中的poi信息。
- GeometryOverlayEvent 几何覆盖物事件返回参数规范。
</br>

## 基础类 {#11}
- LatLng 用于创建经纬度坐标实例。
- LatLngBounds 描述一个矩形的地理坐标范围。
- Point 用于创建二维坐标点。
- GradientColor 用于创建渐变色实例。
- GradientColorOptions GradientColor 配置参数。
</br>

## 室内图 {#12}
- IndoorManager 室内建筑物管理器，用于控制室内地图的加载显示，不可实例化，只能从Map中获取。
- IndoorBuilding 代表室内建筑实例，不可被实例化，只能通过IndoorManager获取。
- IndoorBuildingInfo 室内建筑相关信息。
- FloorInfo 室内建筑楼层相关信息。
</br>

## 附加库：地图工具 {#13}
- GeometryEditor 几何图形编辑器。
- GeometryEditorOptions 几何编辑器配置参数对象规范。
- EditableOverlay 可编辑几何图层对象规范。
- TMap.tools.constants.EDITOR_ACTION  编辑器操作模式常量。
- EditorIconInfo  编辑器所包含的icon信息对象。
- IconStyle  编辑器icon的样式对象，可以设置src、宽高等属性。
- EditingEvent  编辑器所包含的icon信息对象。
- DrawErrorMessage  编辑器绘制失败错误信息。
- AdjustErrorMessage  编辑器编辑失败错误信息。
- MeasureTool 测量工具用于地图测量，继承自Tool抽象类。
- MeasureToolOptions 测量工具用于地图测量，继承自Tool抽象类。
- DistanceMeasurementInfo 距离测量结果对象规范
- AreaMeasurementInfo 面积测量结果对象规范
</br>

## 附加库：几何计算库 {#14}
- geometry 进行距离、夹角、面积的计算，求取外接矩形，判断点、线、面之间的关系。
</br>

## 附加库：服务类库 {#15}
- Search 地点搜索
- Suggestion 关键词输入提示
- Geocoder 正逆地址解析
- Driving 路线规划
- District 行政区划
- IPLocation IP定位
</br>

## 附加库：地图视角附加库 {#16}
- Map 扩展方法 提供以观察者视角操作地图的能力
</br>

## 附加库：模型库 {#17}
- GLTFModel 用于创建GLTF模型对象，叠加在地图上进行显示。
- ModelOptions 创建模型对象的配置参数。
- ModelMoveAlongParam 模型沿线移动配置参数。
- PathPoint 模型沿线移动路径节点配置参数。
- ModelLoadEvent 模型对象的加载事件返回对象。
- ModelMouseEvent 模型对象的鼠标事件返回对象。
- AnimationOptions 模型动画参数。
- GLTFKeyFrame GLTF模型关键帧对象。
- Tileset3D Tileset3D用于创建3DTiles模型对象，叠加在地图上进行显示。
- Tileset3DOptions 创建 3DTiles 模型对象的配置参数。
- Tileset3DMouseEvent Tileset3D 单体模型鼠标事件返回对象。
- Marker3D Marker3D用于创建表示地图上3D样式的标注点。
- Marker3DOptions 创建 3DMarker 对象的配置参数。
- Marker3DStyle Marker3DStyle 应用于Marker3D图层的样式类型。
- Marker3DStyleOptions  Marker3DStyle配置参数。
- Marker3DGeometry  Marker3D点图形数据。





</br>

## 附加库：天气图层 {#weatherLayer}
- WeatherLayer  用于创建天气图层 ，用户传入对应瓦片key、tileUrl、 time和天气图类型，即可生成对应的气象图效果，当前支持云图、温度图、低云图三种类型。
- weatherLayerOptions 天气图层配置参数。
- WeatherLayerEvent 天气图层事件返回参数规范。
- TMap.weather.constants.WEATHER_TYPE 天气图层类型常量。
</br>

## 附加库：矢量数据图层 {#17}
- GeoJSONLayer  用于解析、加载GeoJSON格式的数据
- GeoJSONLayerOptions GeoJSONLayer配置参数。
- MVTLayer 用于创建符合mapbox-vector-tile标准的图层对象，叠加在地图上进行显示。
- MVTLayerOptions MVTLayer配置参数。
</br>

## 环境检测 {#18}
- Brower 用于环境检测
</br>