## LatLng  {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp; 用于创建经纬度坐标实例。
| 构造函数 |
| :- |
|TMap.LatLng(lat:Number, lng:Number, height: Number)|


| 参数说明 | 类型 | 说明 |
| :- | :- | :- |
|lat	|Number	|纬度值。|
|lng	|Number	|经度值。|
| height	|Number	|高度值，非必填，单位为米，默认为0。|



| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|getLat()	|Number	|获取纬度值。|
|getLng()	|Number	|返回经度值。|
|getHeight()	|Number	|获取高度值。|

</br></br>
## LatLngBounds  {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp; 描述一个矩形的地理坐标范围。
| 构造函数 |
| :- |
|TMap.LatLngBounds(sw:LatLng, ne:LatLng)|


| 参数说明 | 类型 | 说明 |
| :- | :- | :- |
|sw	|LatLng	|西南角位置经纬度。|
|ne	|LatLng	|东北角位置经纬度。|


| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|getCenter()	|LatLng	|获取该范围的中心点坐标。|
|getNorthEast()	|LatLng	|获取该范围的东北角坐标。|
|getSouthWest()	|LatLng	|获取该范围的西南角坐标。|
|extend(latlng:LatLng)	|this	|扩展该范围边界，以包含指定的坐标点。|
|union(other:LatLngBounds)	|this	|扩展该范围边界，以包含指定的一个矩形范围。|
|equals(other:LatLngBounds)	|Boolean	|比较两个矩形范围是否完全相等。|
|intersects(other:LatLngBounds)	|Boolean	|判断该范围是否与另一矩形范围相交。|
|isEmpty()	|Boolean	|判断该范围是否为空。|
|contains(latlng:LatLng)	|Boolean	|判断指定的坐标是否在这个范围内。|
|toString()	|String	|转换为字符串表示。|

</br></br>
## Point {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp; 用于创建二维坐标点。
| 构造函数 |
| :- |
|new TMap.Point(x, y);|


| 参数说明 | 类型 | 说明 |
| :- | :- | :- |
|x	|Number	|x坐标值|
|y	|Number	|y坐标值|


| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|getX()	|Number	|获取x坐标值|
|getY()	|Number	|获取y坐标值|
|equals(other: Point)	|Boolean	|判断两个点是否相等|
|clone()	|Point	|创建一个坐标值相同的点|
|toString()	|String	|转换为字符串表示|

</br></br>
## GradientColor {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp; 用于创建渐变色实例。
| 构造函数 |
| :- |
|new TMap.GradientColor(options);|


| 参数说明 | 类型 | 说明 |
| :- | :- | :- |
|options	|GradientColorOptions	|渐变色配置参数。|


| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|addColorStop(offset: Number, color: String)	|this	|添加一个由偏移(offset)和颜色(color)定义的断点，offset取值范围为0～1，颜色支持rgb(), rgba(),#RRGGBB格式。|
|setAngle(angle: Number)	|this	|设置水平线和渐变线之间的角度，逆时针方向旋转，0度从左到右，90度从下到上。|
|getAngle()	|Number	|获取水平线和渐变线之间的角度。|


| 静态方法 | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|createDoubleColorGradient(color1: String, color2: String, angle: Number)	|GradientColor	|创建双色渐变色，color1为起点颜色，color2为终点颜色，颜色支持rgb(), rgba(),#RRGGBB格式，angle为水平线和渐变线之间的角度，逆时针方向旋转，0度从左到右，90度从下到上，默认值0度。|
|convert(colors: Object)	|GradientColor	|将字面量对象和双色值数组，比如{0:'#FFFFFF', 1:'#000000'}或['#FFFFFF', '#000000']转换为GradientColor对象，颜色支持rgb(), rgba(),#RRGGBB格式，只支持双色，第一个颜色为起点颜色，默认offset为0，第二个颜色为终点颜色，默认offset为1，angle默认为0。|

</br></br>
## GradientColorOptions  {#5}
----
&nbsp;&nbsp;&nbsp;&nbsp;GradientColor 配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|stops	|Object	|渐变色中的断点集合，key-value形式。key为偏移(offset)，value为颜色(color)，比如{0:'#FFFFFF', 1:'#000000'}。|
|angle	|Number	|水平线和渐变线之间的角度，逆时针方向旋转，0度从左到右，90度从下到上，默认值0度。|