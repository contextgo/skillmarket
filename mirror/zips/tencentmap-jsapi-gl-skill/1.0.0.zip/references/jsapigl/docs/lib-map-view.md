## 地图视角附加库 {#1}
---
该附加库提供以观察者视角操作地图的能力。在Map类上扩展了以下方法进行观察者视角到地图视角的换算：
<br><br>
## Map 扩展方法



| 方法名                                                       | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明                                                         |
| ------------------------------------------------------------ | ------- | ------------------------------------------------------------ |
| getMapViewWhenLookFrom(position:LatLng, rotation: Number[]) | MapView | 指定观察者所在位置及三轴方向上的旋转角度，获取地图视角。position为观察者位置，需明确高度；rotation为XYZ三轴上的旋转角度，格式为[x, y, z]，默认为[0, 0, 0]。查看示例 |
| lookFrom(position: LatLng, rotation: Number[], easeOpts: EaseOptions) | this    | 将地图变换到指定观察者视角，position及rotation参数说明同getMapViewWhenLookFrom |

<br><br>
## MapView 对象规范
----
&nbsp;&nbsp;&nbsp;&nbsp;MapView为地图视角描述对象。
| 名称     | 类型   | 说明                                  |
| -------- | ------ | ------------------------------------- |
| center   | LatLng| 地图中心点经纬度                      |
| zoom     | Number | 地图缩放级别                          |
| rotation | Number | 地图在水平面上的旋转角度              |
| pitch    | Number | 地图俯仰角度，取值范围为0~80          |
| roll     | Number | 地图左右倾斜角度，取值范围为(-90, 90) |