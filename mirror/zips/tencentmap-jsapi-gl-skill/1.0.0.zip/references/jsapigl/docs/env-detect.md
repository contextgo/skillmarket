#### Brower {#1}

Brower用于环境检测。

**属性**

|名称|类型|说明
|--|--|--|
|userAgent |String |当前浏览器的userAgent信息 |
|isMobileDevice |Boolean |是否运行在移动设备 |
|platform |String |平台类型，如：'Windows'、'Mac'、'iPhone'、'Android'、'Linux' |
|isWindowsDevice |Boolean |是否运行在windows设备 |
|isIosDevice |Boolean |是否运行在iOS设备 |
|isIPad |Boolean |是否运行在iPad |
|isIPhone |Boolean |是否运行在iPhone |
|isAndroidDevice |Boolean |是否运行在安卓设备 |
|isAndroid23 |Boolean |是否运行在安卓4以下系统 |
|isChrome |Boolean |是否运行在Chrome浏览器 |
|isFirefox |Boolean |是否运行在火狐浏览器 |
|isSafari |Boolean |是否运行在Safari浏览器 |
|isWeChat |Boolean |是否运行在微信 |
|isUC |Boolean |是否运行在UC浏览器 |
|isQQ |Boolean |是否运行在QQ或者QQ浏览器 |
|isIE |Boolean |是否运行在IE浏览器 |
|isEdge |Boolean |是否运行在Edge浏览器 |
|isMiniProgram |Boolean |是否运行在微信小程序 |
|isMiniProgramMobile |Boolean |是否运行在微信小程序移动端 |
|isMiniProgramPC |Boolean |是否运行在微信小程序pc端 |
|isMobileWebkit |Boolean |是否运行在支持Webkit移动端浏览器 |
|isMobileWebkit3d |Boolean |是否运行在支持Css3D的Webkit移动端浏览器 |
|isRetinaDevice |Boolean |是否运行在高清屏幕设备，devicePixelRatio>1 |
|isTouchDevice |Boolean |是否运行在触屏设备 |
|isWebkit |Boolean |是否运行在webkit浏览器 |
|isSupportLocalStorage |Boolean |运行环境是否支持LocaStorage |
|isSupportGeolocation |Boolean |运行环境是否支持Geolocation |
|isSupportWebkit3d |Boolean |是否运行在支持Css3D的Webkit浏览器 |
|isSupportGecko3d |Boolean |是否运行在支持Css3D的gecko浏览器 |
|isSupportAny3d |Boolean |是否运行在支持Css3D的浏览器 |
|isSupportCanvas |Boolean |运行环境是否支持canvas |
|isSupportSvg |Boolean |运行环境是否支持svg |
|isSupportVML |Boolean |运行环境是否支持vml |
|isSupportWorker |Boolean |运行环境是否支持WebWorker |
|isSupportWebsocket |Boolean |运行环境是否支持WebSocket |
|isSupportIndexDB |Boolean |运行环境是否支持IndexDB |
|isSupportWebGL |Boolean |运行环境是否支持webgl |
|isSupportWebGL2 |Boolean |运行环境是否支持webgl 2.0 |