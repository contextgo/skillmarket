## GLTFModel {#1}
---
&nbsp;&nbsp;&nbsp;&nbsp;GLTFModel用于创建GLTF模型对象，叠加在地图上进行显示。默认以zoom=20的缩放比例显示模型数据。
|构造函数|
| :- |
|new TMap.model.GLTFModel(options: ModelOptions );|


| 方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|setPosition(position: LatLng)	|this	|设置模型锚点所在的经纬度坐标。|
|setAnchor(anchor: Number[])	|this	|设置模型锚点。|
|setRotation(rotation: Number[])	|this	|设置模型旋转角度。|
|setScale(scale: Number l Number[])	|this	|设置模型缩放比例。|
|setMask(mask:LatLng[])	|this	|设置模型遮罩区域。|
|getPosition()	|LatLng	|获取模型锚点所在的经纬度坐标。|
|getAnchor()	|Number[]	|获取模型锚点坐标。|
|getRotation()	|Number[]	|获取模型旋转角度。|
|getScale()	|Number[]	|获取模型缩放比例。|
|getMask()	|LatLng[]	|获取模型遮罩区域。|
|addTo(map: Map)	|this	|将模型添加到指定地图对象上。|
|remove()	|this	|将模型从地图上删除。|
|destroy()	|this	|销毁模型对象。|
|show()	|this	|显示模型。|
|hide()	|this	|隐藏模型。|
| moveAlong(param: ModelMoveAlongParam)    | this     | 模型的沿线移动方法（使用该方法需要引入geometry附加库）。                                |
| stopMove()                               | this     | 停止移动，尚未完成的动画会被取消，并触发move_stopped事件；已经完成的动画不会触发move_stopped事件 。|
| pauseMove()                              | this     | 暂停模型移动的动画效果 。|
| resumeMove()                             | this     | 重新开始模型移动的动画效果。 |
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|
| startAnimation(keyFrames:GLTFKeyFrame[], opt:AnimationOptions{})    | this     | 开始关键帧动画。 |
| stopAnimation()                          | this     | 停止关键帧动画 。 |
| pauseAnimation()                         | this     | 暂停关键帧动画。 |
| resumeAnimation()                          | this     | 恢复关键帧动画。  |


**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。
| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|loaded	|ModelLoadEvent	|模型资源加载完成。|
|loading	|ModelLoadEvent  |模型资源加载中。|
|load_failed	|ModelLoadEvent	|模型资源加载失败。|
|click	|ModelMouseEvent  |点击模型时触发。|
|moving     | ModelMovingEvent   |模型在执行moveAlong动画时触发事件。|
|move_end     | |模型执行moveAlong动画结束时触发事件。|
|move_stopped     |   |模型执行moveAlong动画被停止时触发事件。|

</br>

## ModelOptions {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;创建模型对象的配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
| :- | :- | :- |
|url	|String	|模型资源url。|
|map	|Map	|显示模型的地图。|
|position	|LatLng	|模型锚点所对应的经纬度坐标。|
|id	|String	|（可选）模型唯一标识。|
|anchor	|Number[]	|（可选）模型锚点坐标，锚点为模型局部坐标系中的一个点，与地图经纬度坐标点对齐，锚点格式为[x, y, z]，默认为[0, 0, 0]。|
|rotation	|Number[]	|（可选）模型XYZ三轴上的旋转角度，格式为[x, y, z]，默认为[0, 0, 0]。|
|scale	|Number l Number[]	|（可选）模型在XYZ三轴上的缩放比例。若为数字，则三轴均以该比值进行缩放；若为数组，则可分别指定三轴缩放比例，格式为[x, y, z]。默认为1。|
|mask	|LatLng[]	|（可选）模型遮罩，该坐标点串形成的封闭区域将不显示底图建筑及POI。|
| namedAnimationsEnabled | Boolean | （可选）是否激活模型内置动画，默认为false |

</br>

## ModelMoveAlongParam {#6}
----
&nbsp;&nbsp;&nbsp;&nbsp;模型沿线移动参数对象规范。
|属性名称	|类型	|说明|
| :- | :- | :- |
|path|PathPoint[]|移动过程中每个节点的位置及时间状态。|
|duration|Number|完成一次移动所需的时间，单位为ms。|
|loop|Number|移动循环的次数，若为Infinity则无线循环，默认为1。|
|degreeToNorth|Number|将模型朝向正北需要在z轴上旋转的角度，默认为0。|

</br>


## PathPoint {#pathpoint}
----
&nbsp;&nbsp;&nbsp;&nbsp;模型沿线移动路径节点。
|属性名称	|类型	|说明|
| :- | :- | :- |
|position|LatLng|路径节点经纬度|
|timestamp|Number|路径节点时间戳|

</br>


## ModelLoadEvent 对象规范{#loadevent}
----
模型对象的加载事件返回对象。
| 名称| 类型| 说明|
| -- | -- | -- |
| target | Model | 事件的目标模型对象。 |
| error | Error | 加载失败的错误对象，load_failed事件返回 。|
| progress | Number | 加载进度，取值范围在0～1之间，loading事件返回 。|
| loaded | Number | 已加载的字节数，loading事件返回。 |
| total | Number | 总字节数，loading事件返回 。|

</br>

## ModelMouseEvent 对象规范{#mouseEvent }
----
模型对象的鼠标事件返回对象。
| 名称| 类型| 说明|
| -- | -- | -- |
| type | String | 事件的类型。 |
| target | Model | 事件的目标模型对象。 |

</br>

## ModelMovingEvent 对象规范{#modelMovingEvent }
----
模型沿线移动中返回的事件对象。
| 名称| 类型| 说明|
| -- | -- | -- |
| passedPath | PathPoint[] | 模型走过的路径的坐标串。 |
| rotation | Number[] | 模型当前的旋转角度。 |

</br>



## AnimationOptions 对象规范{#animation}
----
&nbsp;&nbsp;&nbsp;&nbsp;动画参数。
| 名称     | 类型   | 说明                                                |
| :- | :- | :- |
| duration | Number | 动画周期时长，单位为ms，默认为1000。                  |
| loop     | Number | 动画周期循环次数，若为Infinity则无限循环，默认为1。 |

</br>


## GLTFKeyFrame 对象规范 {#gltfkeyframe}
----
&nbsp;&nbsp;&nbsp;&nbsp;GLTF模型关键帧对象。

| 名称       | 类型   | 说明     |
| :- | :- | :- |
| percentage | Number | 动画过程中该关键帧的百分比，取值范围为0~1。 |
| position     | LatLng | 模型位置经纬度。  |
| scale       | Number/Number[] | 模型缩放级别。  |
| rotation   | Number[] | 模型在[x,y,z]上的旋转角度。  |
| anchor   | Number[] | 模型锚点。  |

</br>


## Tileset3D {#Tileset3D}
---
&nbsp;&nbsp;&nbsp;&nbsp;Tileset3D用于创建3DTiles模型对象，叠加在地图上进行显示
|构造函数|
| :- |
|new TMap.model.Tileset3D(options:Tileset3DOptions);|


| 方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|setMask(mask: LatLng[]) |this |设置模型遮罩 |
|getMask() |LatLng[] |获取模型遮罩 |
|getPosition() |LatLng[] |获取模型位置 |
|addTo(map: Map) |this |将模型添加到指定地图对象上 |
|destroy() |this |销毁模型对象 |
|show() |this |显示模型 |
|hide() |this |隐藏模型 |
|on(eventName:String, listener:Function) |this |添加listener到eventName事件的监听器数组中 |
|off(eventName:String, listener:Function) |this |从eventName事件的监听器数组中移除指定的listener |


| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|initialized | - |模型索引初始化完成后执行的事件，此事件只触发一次 |
|loaded | - |模型资源加载完成，当视图范围内所有瓦片加载完成后触发的，这个事件会被多次触发 |
|load_failed |Error |模型资源加载失败 |
|click |ClickEvent |点击模型时触发 |
|update | - |模型更新，如拖拽、缩放等操作使场景的模型数据更新时触发 |

</br>

## Tileset3DOptions {#Tileset3DOptions}
----
&nbsp;&nbsp;&nbsp;&nbsp;创建 3DTiles 模型对象的配置参数。
|属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	|说明&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
| :- | :- | :- |
|url |String |3DTiles 模型资源 url |
|map |Map |显示模型的地图 |
|id |String |（可选）模型唯一标识 |
|coordType |String |（可选）模型所使用的地图坐标系类型，默认为'gcj02', 可选'wgs84' |
|mask | LatLng[] |（可选）模型遮罩，该遮罩形成的封闭区域将不显示底图建筑及POI |
|offset | Number[] |（可选）Tileset3D 偏移坐标，格式为[x, y, z]，单位米，默认为[0, 0, 0] |


</br>


## Tileset3DMouseEvent 对象规范 {#Tileset3DMouseEvent}
----
&nbsp;&nbsp;&nbsp;&nbsp;Tileset3D 单体模型鼠标事件返回对象。

| 名称       | 类型   | 说明     |
| :- | :- | :- |
|type |String |事件类型 |
|target |Tileset3D |事件的目标对象 |
|originalEvent | * |浏览器原生的事件对象 |
|position |LatLng |事件触发的经纬度坐标及高度 |


</br>


## Marker3D {#Marker3D}
---
&nbsp;&nbsp;&nbsp;&nbsp;Marker3D用于创建表示地图上3D样式的标注点。
|构造函数|
| :- |
|new TMap.model.Marker3D(options: Marker3DOptions);|


| 方法&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|setMap(map:Map) |this |设置地图对象，如果map为null意味着将多个Marker3D同时从地图中移除 |
|setGeometries(geometries: Marker3DGeometry[]) |this |更新3D标注点数据，如果参数为null或undefined不会做任何处理 |
|setStyles(styles: Marker3DStyleHash) |this |设置Marker3D图层相关样式信息，如果参数为null或undefined不会做任何处理 |
|setVisible(visible: Boolean) |this |设置图层是否可见 |
|getMap() |Map |获取地图对象，若为空返回null |
|getGeometries() | Marker3DGeometry[] |获取点数据 |
|getStyles() |Marker3DStyleHash |获取图层相关样式信息 |
|getVisible() | Boolean |获取可见状态 |
|getGeometryById(id:String) | Marker3DGeometry|根据点数据id来获取点数据 |
|updateGeometries(geometry:  Marker3DGeometry[]) |this |更新3D标注点数据，如果geometry的id存在于多点标注的集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的点标注添加到集合中；如果参数为null或undefined不会做任何处理 |
|add(geometries:  Marker3DGeometry[]) |this |向图层中添加3D标注点，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的标注存在重复id，这些3D标注点会被重新分配id；如果参数为null或undefined不会做任何处理 |
|remove(ids: String[]) |this |移除指定id的3D标注点，如果参数为null或undefined不会做任何处理 |
|destroy() |void |销毁图层对象 |


| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 说明 |
| :- | :- |:- |
|click |GeometryOverlayEvent |点击事件 |
|dblclick |GeometryOverlayEvent |双击事件 |
|mousedown |GeometryOverlayEvent |鼠标在地图区域中左键按下时触发，只在桌面浏览器中触发 |
|mouseup |GeometryOverlayEvent |鼠标在地图区域中左键按下又弹起时触发，只在桌面浏览器中触发 |
|mousemove |GeometryOverlayEvent |鼠标在地图上移动时触发，只在桌面浏览器中触发 |
|touchstart |GeometryOverlayEvent |在地图区域触摸开始时触发，只在移动浏览器中触发 |
|touchmove |GeometryOverlayEvent |在地图区域触摸移动时触发，只在移动浏览器中触发 |
|touchend |GeometryOverlayEvent |在地图区域触摸结束时触发，只在移动浏览器中触发 |

</br>


## Marker3DOptions 对象规范 {#Marker3DOptions}
----
&nbsp;&nbsp;&nbsp;&nbsp;创建 3DMarker 对象的配置参数。

| 名称       | 类型   | 说明     |
| :- | :- | :- |
|id |String |图层id，若没有会自动分配一个 |
|map |Map |显示Marker3D图层的底图 |
|styles |Marker3DStyleHash |点标注的相关样式 |
|geometries | Marker3DGeometry[] |点标注数据数组 |

</br>


## Marker3DStyleHash 对象规范 {#Marker3DStyleHash}
----
&nbsp;&nbsp;&nbsp;&nbsp;一个key-value形式对象, 表示Marker3D图层的相关样式信息，key使用字符串，value是 Marker3DStyle对象。

</br>


## Marker3DStyle  {#Marker3DStyle}
----
&nbsp;&nbsp;&nbsp;&nbsp;Marker3DStyle 表示应用于Marker3D图层的样式类型。
|构造函数|
| :- |
|new TMap.model.Marker3DStyle(options: Marker3DStyleOptions);|

</br>


## Marker3DStyleOptions {#Marker3DStyleOptions}
----
&nbsp;&nbsp;&nbsp;&nbsp;Marker3DStyle配置参数。
| 名称       | 类型   | 说明     |
| :- | :- | :- |
|type |String |Marker3D类型(location / radiation / maglev), 默认为location(标记点) |
|scale |Number |模型在XYZ三轴上的缩放比例。三轴均以该比值进行缩放, 默认为1。 |
|color |String |可选，Marker3D颜色属性，支持rgb()，#RRGGBB等形式，location默认为#D81611，maglev默认为#1DFAF2，radiation默认为#E5811C |



</br>

## Marker3DGeometry {#Marker3DGeometry}
----
&nbsp;&nbsp;&nbsp;&nbsp;Marker3D点图形数据。


| 名称       | 类型   | 说明     |
| :- | :- | :- |
|id |String |点图形数据的标志信息，不可重复，若id重复后面的id会被重新分配一个新id，若没有会随机生成一个 |
|styleId |String |对应 Marker3DStyleHash 中的样式id，如果样式表中没有包含geometry指定的styleId，则该geometry使用默认样式绘制 |
|position |LatLng |3D标注点位置 |
| properties | Object |3D标注点的属性数据 |