## IndoorManager {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;IndoorManager用于控制室内地图的加载显示，不可实例化，只能从Map中获取；IndoorManager中的室内地图由加载地图api时设置的key决定，该key权限下的室内建筑物都会被IndoorManager加载和管理。（获取室内相关信息，请点击 这里)
| 方法 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|initialize	|Promise	|初始化室内图管理器，返回Promise，室内图初始化完成后会进入promise的成功回调，初始化完成之前setActiveIndoorBuilding,getActiveIndoorBuilding,getIndoorBuilding等方法无效。|
|setAutoActive(autoActive:Bool)	|this	|设置室内建筑是否可以被自动激活；自动激活状态为true时，包含当前地图中心点的室内建筑物会被激活，激活状态下的室内建筑可以进行楼层切换等操作；处于自动激活状态下用户无法手动更改被激活的室内建筑物；自动激活状态为false时，用户可以通过setActiveIndoorBuilding来改变建筑物的激活状态。|
|setActiveIndoorBuilding(buildingId: String)	|this	|将buildingId对应的室内建筑设置为激活状态，激活状态下的室内建筑可以进行楼层切换等操作；若buildingId为假值所有室内建筑都将变为非激活状态，楼层控件从界面中消失；该方法只有在自动激活状态为false时有效。|
|setVisible(isVisible:Bool)	|this	|设置室内建筑是否显示。|
|showFloorControl()	|this	|显示处于激活状态的室内建筑的楼层控件，若没有激活状态的室内建筑，该方法无效。|
|hideFloorControl()	|this	|隐藏处于激活状态的室内建筑的楼层控件。|
|getMap()	|Map	|获取地图对象，若为空返回null。|
|getAutoActive()	|Boolean	|获取室内建筑是否可以被自动激活。|
|getActiveIndoorBuilding()	|IndoorBuilding	|获取处于激活状态下的室内建筑，若都为非激活状态，则返回null。|
|getVisible()	|Boolean	|获取室内图是否显示。|
|getIndoorBuilding(buildingId: String)	|IndoorBuilding   |获取室内建筑，若id不存在返回null。|
|getIndoorBuildingList()	|IndoorBuilding	|获取所有的室内建筑。|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中。|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener。|


| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|active_changed	|IndoorBuilding	|当激活的室内建筑发生变化时触发, 事件对象为当前处于激活状态的室内建筑。|

</br></br>
## IndoorBuilding {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;IndoorBuilding代表室内建筑实例，不可被实例化，只能通过IndoorManager获取。IndoorManager可以切换IndoorBuilding的激活状态，处于激活状态的室内建筑可以切换楼层。（获取室内相关信息，请点击 这里)
| 方法 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setSelectedFloor(floor:String)	|this	|设置当前选中楼层|
| setRegionExtrusion(factor:Number) | this | 设置室内区域墙体和面块高度的拉伸系数，最小值0.1、最大值10 |
| setPoiVisible(visible:Boolean) | this |  设置室内poi显隐 |
|getMap()	|Map	|获取地图对象，若为空返回null|
|getManager()	|IndoorManager	|获取室内建筑物的管理器|
|getSelectedFloor()	|String	|获取室内建筑物的当前展示的楼层|
|getBuildingInfo()	|IndoorBuildingInfo	|获取室内建筑物信息，indoorBuilding初始化完成后调用返回IndoorBuildingInfo对象，indoorBuilding没有初始化完成时调用返回null，推荐使用getBuildingInfoAsync|
|getBuildingInfoAsync()	|Promise	|异步获取室内建筑物信息，返回Promise，indoorBuilding初始化完成时resolve状态下返回IndoorBuildingInfo对象|
|isActive()	|Boolean	|室内建筑物是否处于激活状态|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener|

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。

| 事件名 | 参数 | 说明 |
| :- | :- |:- |
|floor_changed	|	|当室内图楼层切换时触发此事件。|
|show	|	|当该建筑显示时触发此事件。|
|hide	|	|当该建筑隐藏时触发此事件。|


</br></br>
## IndoorBuildingInfo {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;室内建筑相关信息。
| 属性方法 | 返回值 | 说明 |
| :- | :- |:- |
|cityId	|String	|室内建筑物所在的城市Id|
|buldingId	|String	|室内建筑物Id|
|buildingName	|String	|室内建筑名称|
|floorList	|FloorInfo[]	|室内建筑物的楼层信息列表|
|defaultFloor	|String	|室内建筑物默认显示的楼层|
|center	|LatLng	|室内建筑物的中心点，通常是建筑物的默认显示楼层的中心点|

</br></br>
## FloorInfo {#4}
----
&nbsp;&nbsp;&nbsp;&nbsp;室内建筑楼层相关信息。
| 属性方法 | 返回值 | 说明 |
| :- | :- |:- |
|name	|String	|楼层名称|
|bounds	|LatLngBounds	|室内建筑物的楼层范围|
