## GeoJSONLayer{#GeoJSONLayer}
---
&nbsp;&nbsp;&nbsp;&nbsp;GeoJSONLayer 用于解析、加载GeoJSON格式的数据
|构造函数|
| :- |
|new TMap.vector.GeoJSONLayer(options: GeoJSONLayerOptions);|


| 方法名                           | 返回值 | 说明                                                         |
| :------------------------------- | :------------------------------------------------------ | :----------------------------------------------------------- |
| setMap(map:Map)                  | this                                             | 设置展示数据的地图对象，如果map为null意味着将GeoJSON数据从地图中移除 |
| setVisible(visible: Boolean)     | this                                             | 设置GeoJSON数据是否可见                                      |
| setZIndex(zIndex: Number)        | this                                             | 设置图层绘制顺序                                             |
| setData(data:Object)             | this                                             | 切换图层数据源                                               |
| getGeometryOverlay(type: String) |MultiMarker|MultiPolyline  |MultiPolygon &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| 获取GeoJSON数据的指定类型图层，type支持的值有：'marker'、'polyline'、'polygon' |
| getId() |  string  | 获取图层的id。 |


 <br>

## GeoJSONLayerOptions{#GeoJSONLayerOptions}
GeoJSONLayer配置参数

| 参数名        | 类型          | 说明                                                         |
| :------------ | :------------ | :----------------------------------------------------------- |
| map           | Map	        | 加载GeoJSON的地图对象                                        |
| data          | Object        | GeoJSON标准格式的数据                |
| zIndex        | Number        | 图层绘制顺序，默认为1，有效范围为[1, 9999]                   |
| minZoom       | Number        | 最小缩放层级，当地图缩放层级小于该值时该图层不显示，默认为3  |
| maxZoom       | Number        | 最大缩放层级，当地图缩放层级大于该值时该图层不显示，默认为20 |
| markerStyle   | MarkerStyle 	  | GeoJSON数据中点状要素的样式，如果参数为null不会显示和创建点状要素 |
| polylineStyle |PolylineStyle  | GeoJSON数据中线状要素的样式，如果参数为null不会显示和创建线状要素 |
| polygonStyle  |PolygonStyle  | GeoJSON数据中面状要素的样式，如果参数为null不会显示和创建面状要素 |

<br><br>
## MVTLayer{#MVTLayer}
-------
​&nbsp;&nbsp;&nbsp;&nbsp;用于创建符合mapbox-vector-tile标准的图层对象，叠加在地图上进行显示；**注意，添加MVTLayer后不支持地图设置中心点偏移**。


| 构造函数                                            |
| :--------------------------------------------------- |
| new TMap.vector.MVTLayer(options: MVTLayerOptions); |


| 方法名                       | 返回值 | 说明                                                         |
| :--------------------------- | :----- | :----------------------------------------------------------- |
| setMap(map: Map/Null)        | this   | 将图层添加到地图上                                           |
| setZIndex(zIndex: Number)    | this   | 设置图层绘制顺序                                             |
| getZIndex()                  | this   | 获取图层的zindex                                             |
| getId()                      | string   | 获取图层的id                                                 |
| setStyle(style: String/JSON) | this   | 设置样式，是一个符合 Mapbox 样式规范 的 JSON 对象，或者是一个指向该 JSON 的 URL 地址 |
| addLayer(params: MVTParams)  | id     | 添加mvt图层，返回图层id，此处图层指mvt的标准图层，MVTParams符合Mapbox样式规范的图层定义 |
| removeLayer(id: String)      | this   | 移除mvt图层                                                  |
| getLayers()                  | id[]   | 返回当前加载的所有mvt图层id                                  |


<br>

## MVTLayerOptions对象规范{#MVTLayerOptions}

| 名称   | 类型        | 说明                                                         |
| :----- | :---------- | :----------------------------------------------------------- |
| map    | Map         | 显示图层的地图                                               |
| id     | String      | 图层id                                                       |
| style  | String/JSON | 非必填，是一个符合 Mapbox 样式规范 的 JSON 对象，或者是一个指向该 JSON 的 URL 地址 |
| zIndex | Number      | 图层绘制顺序，默认为0                                        |


