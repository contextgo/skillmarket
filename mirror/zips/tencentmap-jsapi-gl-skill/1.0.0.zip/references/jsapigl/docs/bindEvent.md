## MapEvent {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;地图事件返回参数规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型 | 说明 |
| :- | :- |:- |
|latLng	|LatLng   |事件发生时的经纬度坐标。|
|point	|Object	|事件发生时的屏幕位置，返回{x:Number, y:Number}格式|
|type	|String	|事件类型。|
|target	|Object	|事件的目标对象。|
|poi	|POIInfo I null	|事件触发位置的poi信息，当触发位置没有poi点时值为null（仅支持click事件）|
|originalEvent	|MouseEvent 或 TouchEvent	|浏览器原生的事件对象。|

</br></br>
## POIInfo {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;地图事件返回参数中的poi信息。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型 | 说明 |
| :- | :- |:- |
|latLng	|LatLng    |poi的经纬度位置。|
|name	|String	|Poi名称。|

</br></br>
## GeometryOverlayEvent {#3}
&nbsp;&nbsp;&nbsp;&nbsp;几何覆盖物事件返回参数规范。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型 | 说明 |
| :- | :- |:- |
|geometry	|Geometry	|事件发生时的图形数据信息，不同图层中该值所属对象规范不同，比如 MultiMarker（点标记图层）触发的事件中该值为PointGeometry对象。|
|latLng	|LatLng	|事件发生时的经纬度坐标。|
|point	|Object	|事件发生时的屏幕位置，返回{x:Number, y:Number}格式。|
|type	|String	|事件类型。|
|target	|Object	|事件的目标对象。|
|originalEvent	|MouseEvent 或 TouchEvent	|浏览器原生的事件对象。|

