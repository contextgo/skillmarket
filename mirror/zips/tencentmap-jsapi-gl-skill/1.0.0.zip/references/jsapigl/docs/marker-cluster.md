## MarkerCluster {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;点聚合，可以对地图上的点进行聚合。
|构造函数|
|:- |
|new TMap.MarkerCluster(options);|


|参数名	|类型	|说明|
| :- | :- |:- |
|options	|MarkerClusterOptions	|点聚合的参数对象|


| 方法名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 返回值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|setMap(map:Map)	|this	|设置地图对象，如果map为null意味着将点聚合图层从地图中移除|
|setGeometries(geometries:PointGeometry[])	|this	|更新点数据，如果参数为null或undefined不会做任何处理|
|getMap()	|Map	|获取地图对象，若为空返回null|
|getClusters()	|ClusterInfo[]	|获取当前地图视野范围内，聚合后的聚合簇数据；聚合是异步操作，可以绑定cluster_changed事件获取每次地图上最新的聚合簇|
|getGeometries()	|PointGeometry[]	|获取点数据|
|getGeometryById(id:String)	|PointGeometry	|根据点数据id来获取点数据|
|updateGeometries(geometry: PointGeometry[])	|this	|更新标注点数据，如果geometry的id存在于聚合点的集合中，会更新对id的数据，如果之前不存在于集合中，会作为新的点标注添加到集合中进行聚合；如果参数为null或undefined不会做任何处理|
|add(geometries: PointGeometry[])	|this	|向图层中添加标注点，如果geometry的id已经存在集合中，则该geometry不会被重复添加，如果geometry没有id或者id不存在于集合中会被添加到集合中进行聚合，没有id的geometry会被赋予一个唯一id；如果要添加到集合中的标注存在重复id，这些标注点会被重新分配id；如果参数为null或undefined不会做任何处理|
|remove(ids: String[])	|this	|移除指定id的标注点，如果参数为null或undefined不会做任何处理|
|on(eventName:String, listener:Function)	|this	|添加listener到eventName事件的监听器数组中|
|off(eventName:String, listener:Function)	|this	|从eventName事件的监听器数组中移除指定的listener|
|destroy()	| 	| 销毁图层对象 |

**事件：**</br>
&nbsp;&nbsp;&nbsp;&nbsp;监听事件通过on、off方法绑定与解绑。

| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明 |
| :- | :- |:- |
|click	|Object	|点击事件，如果有选中的聚合簇，事件对象中的cluster属性会指向选中的 ClusterInfo[]；如果有选中的单个标注点，事件对象中的geometry指向被选中的PointGeometry；只针对启用默认样式的点聚合适用|
|cluster_changed	|null	|聚合簇发生变化时触发|


</br></br>
## MarkerClusterOptions {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;MarkerCluster配置参数。
| 属性名称&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 类型&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | 说明 |
| :- | :- |:- |
|id	|String	|图层id，若没有会自动分配一个|
|map	|Map	|显示点聚合图层的底图|
|enableDefaultStyle	|Boolean	|是否启用默认的聚合样式; 默认样式是聚合点的数量在1-10,11-100,101-1000的样式图标; 默认为true; 如果用户想实现更加炫酷的聚合效果，可以关闭默认样式，使用getClusters获取到聚合簇数据后通过继承DOMOverlay来实现自定义聚合样式 查看示例|
|minimumClusterSize	|Number	|形成聚合簇的最小个数;默认为2|
|geometries	|PointGeometry[]	|点标记数据数组，注：该点标记不支持通过style更改样式|
|zoomOnClick	|Boolean	|点击已经聚合的标记点时是否实现聚合分离;默认为true; 但只对默认样式启用，自定义样式需要开发者监听相应元素的点击事件后使用Map.fitBounds方法实现|
|gridSize	|Number	|聚合算法的可聚合距离，即距离小于该值的点会聚合至一起，默认为60，以像素为单位，指的是地图pitch为0时的屏幕像素大小|
|averageCenter	|Boolean	|每个聚和簇的中心是否应该是聚类中所有标记的平均值,默认为false|
|maxZoom	|Number	|采用聚合策略的最大缩放级别，若地图缩放级别大于该值，则不进行聚合。默认为20|
| zIndex | Number  | 图层绘制顺序 |
| collisionOptions  | CollisionOptions | 图层碰撞配置参数 |

</br></br>
## ClusterInfo{#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;clusterInfo对象规范。
| 属性名称 | 类型 | 说明 |
| :- | :- |:- |
|center	|LatLng	|聚合簇的位置点|
|geometries	|PointGeometry[]	|该聚合簇内的点标记数据数组，注：该点标记不支持通过style更改样式|
|bounds	|LatLngBounds	|聚合簇的边界范围|


</br></br>
## CollisionOptions 对象规范{#4}
----

&nbsp;&nbsp;&nbsp;&nbsp;图层碰撞配置参数。


| 属性名称 | 类型 | 说明 |
| -- | -- | -- |
| crossSource | Boolean | 默认聚合样式下，是否开启聚合簇跨图层碰撞，所有开启的图层间进行碰撞，默认为false。</br> 开启后优先级按zIndex进行碰撞，zIndex默认0，如marker的rank = 10，MarkerCluster的zIndex = 11，MarkerCluster具有更高的优先级碰撞后marker消失。 |
| vectorBaseMapSource | Boolean | 默认聚合样式下，是否允许聚合簇碰撞底图元素（道路名、poi、icon），默认为false |