## 天气图层 {#1}
&nbsp;&nbsp;&nbsp;&nbsp;该附加库用于创建天气图层 ，用户传入对应瓦片key、tileUrl、 time和天气图类型，即可生成对应的气象图效果，当前支持云图、温度图、低云图三种类型。
<br>

|构造函数|
| :- |
|new TMap.weather.WeatherLayer(options)|


|参数名|类型|说明|
| :- | :- |  :- |
|options |WeatherLayerOptions |天气图层参数 |
## weatherLayerOptions 对象规范{#1}
<br />
&nbsp;&nbsp;&nbsp;&nbsp;天气图层配置参数。
<br />

| 名称 &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;                                     | 类型  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;                                                                             | 说明                                                         |
| :- | :- |:- |
|map |Map|展示图层的地图对象 |
|tileUrl |string |天气数据上传后返回的瓦片服务地址 |
|weatherType |WEATHER_TYPE |标识灰度图色值类型，类型常量见TMap.constants.WEATHER_TYPE，目前已知有云图 CLOUD ，温度 TEMPRATURE,低云LOWCLOUD |
|time |string |数据时间点，字符串类型 |
|key |string |用户上传瓦片后返回的数据标识key |
|colorMap |GradientColor  |色系映射方案，配置渐变色，当前图层下GradientColor 不支持设置angle，默认为0， |
|minZoom |Number |最小缩放层级，当地图缩放层级小于该值时该图层不显示，不填默认3 |
|maxZoom |Number |最大缩放层级，当地图缩放层级大于该值时该图层不显示， 不填默认20 |
|maxDataZoom|Number |最大数据层级，当缩放层级大于该值时不再加载新数据，而是以此层级数据拉伸进行展示（最大拉伸等级为9级），默认为等于maxZoom |
|enableBubble |	Boolean	|是否将图层的鼠标事件冒泡到地图上，默认值为true。|


| 事件名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 参数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  | 说明 |
| :- | :- |:- |
|click |WeatherLayerEvent |鼠标左键单击图层时触发 |
|hover |WeatherLayerEvent|鼠标在图层上悬停位置改变时触发 |

## WeatherLayerEvent 对象规范{#2}

&nbsp;&nbsp;&nbsp;&nbsp;天气图层事件返回参数规范。

| 属性名 &nbsp;&nbsp;| 类型&nbsp;&nbsp;     | 说明               |
| :------ | :-------- | :----------------- |
|value |Number |事件发生位置的对应图层属性值，如云图、低云图代表云量，温度图代表温度（摄氏度） |
|rgba |Array |返回灰度瓦片的像素值（注： 不是当前渲染瓦片的像素颜色值），如[255,255,255, 1] |
|latLng |LatLng|事件发生时的经纬度坐标 |
|point |Object |事件发生时的屏幕位置，返回{x:Number, y:Number}格式 |
|type |String |事件类型 |
|target |Object |事件的目标对象 |
|originalEvent |MouseEvent 或 TouchEvent |浏览器原生的事件对象 |

## TMap.weather.constants.WEATHER_TYPE 常量说明{#3}

&nbsp;&nbsp;&nbsp;&nbsp;天气图层类型常量。

|常量 |说明&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |
|:--|:--|
|WEATHER_TYPE.CLOUD |云图 |
|WEATHER_TYPE.TEMPERATURE |温度层 |
|WEATHER_TYPE.LOW_CLOUD |低云图 |