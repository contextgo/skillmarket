## Control  {#1}
----
&nbsp;&nbsp;&nbsp;&nbsp;控件的基类，控件的方法及常量说明。

| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|setPosition(position:CONTROL_POSITION)	|this	|设置控件的位置。|
|setClassName(className: String)	|this	|设置控件的css样式名。|
<br><br>
## ZoomControl  {#zoomControl}
---
&nbsp;&nbsp;&nbsp;&nbsp;缩放控件，为控件Control 的子类。

| 方法 | 返回值 | 说明 |
| :- | :- |:- |
|setPosition(position:CONTROL_POSITION)	|this	|设置控件的位置。|
|setClassName(className: String)	|this	|设置控件的css样式名。|
|setNumVisible(visible: boolean)	|this	|设置控件上是否显示缩放级别，默认为false（不显示）。|
</br></br>
## TMap.constants.CONTROL_POSITION 常量说明  {#2}
----
&nbsp;&nbsp;&nbsp;&nbsp;控件位置常量说明。

| 常量 | 说明 |
| :- | :- |
|CONTROL_POSITION.TOP_LEFT	|左上|
|CONTROL_POSITION.TOP_CENTER	|顶部中间|
|CONTROL_POSITION.TOP_RIGHT	|右上|
|CONTROL_POSITION.CENTER_LEFT	|左侧中间|
|CONTROL_POSITION.CENTER	|图区中间|
|CONTROL_POSITION.CENTER_RIGHT	|右侧中间|
|CONTROL_POSITION.BOTTOM_LEFT	|左下|
|CONTROL_POSITION.BOTTOM_CENTER	|底部中间|
|CONTROL_POSITION.BOTTOM_RIGHT	|右下|

</br></br>
## TMap.constants.DEFAULT_CONTROL_ID 常量说明  {#3}
----
&nbsp;&nbsp;&nbsp;&nbsp;默认控件常量说明。

| 常量 | 说明 |
| :- | :- |
|DEFAULT_CONTROL_ID.SCALE	|比例尺控件|
|DEFAULT_CONTROL_ID.ZOOM	|缩放控件|
|DEFAULT_CONTROL_ID.ROTATION	|旋转控件|

