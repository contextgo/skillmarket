"""quiet-mail API"""
