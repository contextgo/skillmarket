#!/usr/bin/env python3
"""
任务管理脚本
支持任务创建、查看、更新、删除
"""
import json
import os
from datetime import datetime, timedelta

def get_task_path():
    """获取任务文件路径"""
    base = os.path.join(os.path.expanduser("~"), "AI办公助手")
    return os.path.join(base, "任务记录", "任务清单.json")

def load_tasks():
    """加载任务列表"""
    path = get_task_path()
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"tasks": [], "last_updated": ""}

def save_tasks(data):
    """保存任务列表"""
    path = get_task_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def create_task(title: str, description: str = "", deadline: str = "", priority: str = "中", source: str = "手动创建"):
    """创建新任务"""
    tasks = load_tasks()
    
    task = {
        "id": len(tasks["tasks"]) + 1,
        "title": title,
        "description": description,
        "deadline": deadline,
        "priority": priority,  # 高/中/低
        "status": "待处理",
        "source": source,  # 老板布置/手动创建
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "completed_at": ""
    }
    
    tasks["tasks"].append(task)
    save_tasks(tasks)
    
    print(f"[OK] 任务已创建: {title}")
    return task

def list_tasks(status: str = None):
    """列出任务"""
    tasks = load_tasks()
    
    if status:
        filtered = [t for t in tasks["tasks"] if t["status"] == status]
    else:
        filtered = tasks["tasks"]
    
    print(f"\n{'='*60}")
    print(f"📋 任务列表 (共 {len(filtered)} 个任务)")
    print(f"{'='*60}")
    
    for t in filtered:
        status_icon = "✅" if t["status"] == "已完成" else "⏳" if t["status"] == "进行中" else "📝"
        print(f"\n{status_icon} #{t['id']} {t['title']}")
        print(f"   状态: {t['status']} | 优先级: {t['priority']} | 来源: {t['source']}")
        if t['deadline']:
            print(f"   截止: {t['deadline']}")
        if t['description']:
            print(f"   说明: {t['description']}")
    
    print(f"\n{'='*60}")
    return filtered

def update_task(task_id: int, status: str = None, note: str = None):
    """更新任务状态"""
    tasks = load_tasks()
    
    for task in tasks["tasks"]:
        if task["id"] == task_id:
            if status:
                task["status"] = status
                if status == "已完成":
                    task["completed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if note:
                task["description"] = note
            task["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            save_tasks(tasks)
            print(f"[OK] 任务 #{task_id} 已更新为: {status or task['status']}")
            return task
    
    print(f"[ERROR] 未找到任务 #{task_id}")
    return None

def delete_task(task_id: int):
    """删除任务"""
    tasks = load_tasks()
    
    original_len = len(tasks["tasks"])
    tasks["tasks"] = [t for t in tasks["tasks"] if t["id"] != task_id]
    
    if len(tasks["tasks"]) < original_len:
        save_tasks(tasks)
        print(f"[OK] 任务 #{task_id} 已删除")
        return True
    
    print(f"[ERROR] 未找到任务 #{task_id}")
    return False

def get_urgent_tasks():
    """获取紧急任务（截止日期在3天内）"""
    tasks = load_tasks()
    urgent = []
    
    now = datetime.now()
    three_days_later = now + timedelta(days=3)
    
    for task in tasks["tasks"]:
        if task["status"] == "已完成":
            continue
        if task["deadline"]:
            try:
                deadline = datetime.strptime(task["deadline"], "%Y-%m-%d")
                if deadline <= three_days_later:
                    task["is_urgent"] = True
                    urgent.append(task)
            except:
                pass
    
    return urgent

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法: task_manager.py <命令> [参数]")
        print("命令: list / create / update / delete")
        sys.exit(1)
    
    cmd = sys.argv[1]
    
    if cmd == "list":
        status = sys.argv[2] if len(sys.argv) > 2 else None
        list_tasks(status)
    elif cmd == "create":
        title = sys.argv[2] if len(sys.argv) > 2 else "新任务"
        description = sys.argv[3] if len(sys.argv) > 3 else ""
        create_task(title, description)
    elif cmd == "update":
        task_id = int(sys.argv[2]) if len(sys.argv) > 2 else 0
        status = sys.argv[3] if len(sys.argv) > 3 else None
        if task_id:
            update_task(task_id, status)
    elif cmd == "delete":
        task_id = int(sys.argv[2]) if len(sys.argv) > 2 else 0
        if task_id:
            delete_task(task_id)
    else:
        print(f"未知命令: {cmd}")
