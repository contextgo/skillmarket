#!/usr/bin/env python3
"""
试用与授权管理脚本
管理30天试用机制和版本授权
"""
import json
import os
from datetime import datetime, timedelta

def get_config_path():
    """获取配置文件路径"""
    base = os.path.join(os.path.expanduser("~"), "AI办公助手")
    return os.path.join(base, "config.json")

def get_default_config():
    """获取默认配置"""
    return {
        "install_date": datetime.now().strftime("%Y-%m-%d"),
        "trial_start": datetime.now().strftime("%Y-%m-%d"),
        "trial_days": 30,
        "version": "trial",  # trial / basic / pro
        "license_key": "",
        "expiry_date": (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d"),
        "trial_used": False,
        "last_check": datetime.now().strftime("%Y-%m-%d")
    }

def load_config():
    """加载配置"""
    path = get_config_path()
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        # 首次使用，创建默认配置（30天试用）
        config = get_default_config()
        save_config(config)
        return config

def save_config(config):
    """保存配置"""
    path = get_config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    config["last_check"] = datetime.now().strftime("%Y-%m-%d")
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

def get_version():
    """获取当前版本"""
    config = load_config()
    
    # 检查试用是否过期
    if config["version"] == "trial":
        trial_end = datetime.strptime(config["expiry_date"], "%Y-%m-%d")
        if datetime.now() > trial_end:
            # 试用过期，降为基础版
            config["version"] = "basic"
            save_config(config)
            return "basic"
    
    return config["version"]

def check_trial_status():
    """检查试用状态"""
    config = load_config()
    version = config["version"]
    
    if version == "trial":
        trial_end = datetime.strptime(config["expiry_date"], "%Y-%m-%d")
        remaining = (trial_end - datetime.now()).days
        
        if remaining <= 0:
            return {
                "status": "expired",
                "version": "basic",
                "remaining_days": 0,
                "message": f"试用期已结束，请升级到正式版"
            }
        elif remaining <= 3:
            return {
                "status": "expiring_soon",
                "version": "trial",
                "remaining_days": remaining,
                "message": f"试用期还剩 {remaining} 天，请及时续费"
            }
        else:
            return {
                "status": "active",
                "version": "trial",
                "remaining_days": remaining,
                "message": f"试用期还有 {remaining} 天"
            }
    else:
        return {
            "status": "active",
            "version": version,
            "remaining_days": None,
            "message": f"当前版本：{get_version_name(version)}"
        }

def get_version_name(version):
    """获取版本名称"""
    names = {
        "trial": "试用版（30天）",
        "basic": "基础版",
        "pro": "Pro版"
    }
    return names.get(version, version)

def activate_license(license_key: str):
    """激活授权码"""
    config = load_config()
    
    # 这里可以添加授权码验证逻辑
    # 简化版：直接识别版本
    if license_key.startswith("PRO-"):
        config["version"] = "pro"
        config["license_key"] = license_key
        # Pro版有效期1年
        config["expiry_date"] = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")
        save_config(config)
        return {"success": True, "version": "pro", "message": "Pro版授权成功！"}
    elif license_key.startswith("BASIC-"):
        config["version"] = "basic"
        config["license_key"] = license_key
        config["expiry_date"] = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")
        save_config(config)
        return {"success": True, "version": "basic", "message": "基础版授权成功！"}
    else:
        return {"success": False, "message": "无效的授权码"}

def has_feature(feature: str):
    """检查功能是否可用"""
    config = load_config()
    version = get_version()
    
    # 功能对应表
    feature_map = {
        "basic_features": ["trial", "basic", "pro"],  # 所有版本都有
        "task_management": ["pro"],  # 只有Pro版有
        "gitee_sync": ["pro"],  # 只有Pro版有
        "batch_generation": ["pro"],  # 只有Pro版有
    }
    
    allowed_versions = feature_map.get(feature, ["trial", "basic", "pro"])
    return version in allowed_versions

def get_upgrade_prompt():
    """获取升级提示"""
    status = check_trial_status()
    
    if status["status"] == "expired":
        return """
📢 **试用到期提醒**

您的AI办公助手试用期已结束

【升级选项】
- 基础版：**199元/年**（适合日常办公）
- Pro版：**399元/年**（含任务管理+Gitee同步）

【如何购买】
联系您的企业管理员或扫码购买

【输入授权码】
告诉AI："激活授权码 XXX"
"""
    elif status["status"] == "expiring_soon":
        return f"""
📢 **试用期即将结束**

您的AI办公助手试用期还剩 **{status['remaining_days']} 天**到期

【升级选项】
- 基础版：**199元/年**（适合日常办公）
- Pro版：**399元/年**（含任务管理+Gitee同步）

【现在升级】告诉AI "我要升级"
"""
    else:
        return f"""
📌 **当前状态**

版本：{get_version_name(status['version'])}
状态：{status['message']}
"""

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        # 检查状态
        status = check_trial_status()
        print(f"版本: {get_version_name(status['version'])}")
        print(f"状态: {status['message']}")
    else:
        cmd = sys.argv[1]
        
        if cmd == "status":
            status = check_trial_status()
            print(json.dumps(status, ensure_ascii=False, indent=2))
        
        elif cmd == "activate" and len(sys.argv) > 2:
            result = activate_license(sys.argv[2])
            print(result["message"])
        
        elif cmd == "check" and len(sys.argv) > 2:
            feature = sys.argv[2]
            available = has_feature(feature)
            print(f"功能 {feature}: {'可用' if available else '不可用'}")
        
        elif cmd == "upgrade":
            print(get_upgrade_prompt())
        
        else:
            print("用法:")
            print("  license_manager.py status      # 查看状态")
            print("  license_manager.py activate <授权码>  # 激活")
            print("  license_manager.py check <功能名>     # 检查功能")
            print("  license_manager.py upgrade            # 升级提示")
