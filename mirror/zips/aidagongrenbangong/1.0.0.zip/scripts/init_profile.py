#!/usr/bin/env python3
"""
员工档案初始化脚本
帮助员工快速建立自己的AI工作分身
"""
import json
import os
from datetime import datetime

def get_base_path():
    """获取工作目录"""
    return os.path.join(os.path.expanduser("~"), "AI办公助手")

def create_directories():
    """创建必要的目录结构"""
    base = get_base_path()
    dirs = [
        "员工档案",
        "标杆素材/文案",
        "标杆素材/海报",
        "标杆素材/PPT",
        "标杆素材/Word",
        "标杆素材/Excel",
        "任务记录",
        "知识库"
    ]
    for d in dirs:
        path = os.path.join(base, d)
        os.makedirs(path, exist_ok=True)
    return base

def init_profile():
    """初始化员工档案"""
    base = create_directories()
    
    profile = {
        "基本信息": {
            "姓名": "",
            "岗位": "",
            "部门": "",
            "入职日期": datetime.now().strftime("%Y-%m-%d"),
            "初始化日期": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        },
        "工作内容": {
            "日常工作": [],
            "常用文档类型": [],
            "常用文案类型": [],
            "常用表格类型": []
        },
        "技能偏好": {
            "文案风格": "",
            "设计偏好": "",
            "沟通风格": ""
        },
        "标杆素材": {
            "文案数量": 0,
            "海报数量": 0,
            "PPT数量": 0,
            "Word数量": 0,
            "Excel数量": 0
        },
        "AI学习状态": {
            "文案风格": "未学习",
            "设计风格": "未学习",
            "PPT风格": "未学习"
        },
        "版本": "基础版",
        "最后更新": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    profile_path = os.path.join(base, "员工档案", "我的档案.json")
    with open(profile_path, 'w', encoding='utf-8') as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    
    print(f"[OK] 员工档案已创建: {profile_path}")
    print(f"[OK] 目录结构已创建: {base}")
    return profile_path

def update_profile(field: str, data: dict):
    """更新档案中的指定字段"""
    base = get_base_path()
    profile_path = os.path.join(base, "员工档案", "我的档案.json")
    
    if os.path.exists(profile_path):
        with open(profile_path, 'r', encoding='utf-8') as f:
            profile = json.load(f)
    else:
        profile = {}
    
    # 更新字段
    if field in profile:
        profile[field].update(data)
    else:
        profile[field] = data
    
    profile["最后更新"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    with open(profile_path, 'w', encoding='utf-8') as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    
    print(f"[OK] 档案已更新: {field}")

def get_profile():
    """获取员工档案"""
    profile_path = os.path.join(get_base_path(), "员工档案", "我的档案.json")
    if os.path.exists(profile_path):
        with open(profile_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None

if __name__ == "__main__":
    init_profile()
