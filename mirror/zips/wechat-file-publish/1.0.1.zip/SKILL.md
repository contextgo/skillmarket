# SKILL.md - 微信公众号文件发布

## 基本信息

| 字段 | 值 |
|------|-----|
| 名称 | wechat-file-publish |
| 版本 | 1.4.0 |
| 显示名称 | 微信公众号文件发布 |
| 描述 | 将本地文件（Markdown/HTML/TXT）一键发布到微信公众号草稿箱，支持图片自动上传和配图生成 |
| 分类 | 社交媒体 |
| 图标 | 📤 |
| 作者 | CodeBuddy |
| 许可证 | MIT |
| 平台 | Windows / macOS / Linux |
| 运行时 | Python |

## 触发词

当用户提及以下关键词时自动触发此技能：

- `发布到公众号`
- `微信公众号`
- `草稿箱`
- `上传公众号`
- `微信文章发布`
- `wechat publish`
- `publish to wechat`
- `生成配图`
- `公众号配图`

## 使用方法

### 对话式调用

```
发布文件到公众号
文件路径：C:/Users/xxx/article.md
封面图：C:/Users/xxx/cover.png
```

或

```
将 article.md 发布到微信公众号草稿箱
```

### 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| inputFile | string | 是 | - | 要发布的文件路径（支持 .md, .html, .txt） |
| coverImage | string | 否 | 空 | 封面图片路径 |
| title | string | 否 | 自动提取 | 文章标题 |
| author | string | 否 | 公众号作者 | 文章作者 |

## 功能特性

1. **多格式支持** - 支持 Markdown、HTML、TXT 文件格式
2. **图片自动上传** - 自动识别并上传本地图片到公众号素材库
3. **封面设置** - 支持设置文章封面图
4. **中文优化** - 完善的 UTF-8 中文编码支持
5. **一键发布** - 快速发布到微信公众号草稿箱
6. **配图生成** - 内置文章配图生成器，支持生成封面图、AI工具图、智能体协作图、技能雷达图等
7. **配图自动插入** - Markdown 中的本地图片路径自动替换为微信素材URL，确保配图在公众号中正常显示

## 配图生成功能

### 生成文章配图

运行内置的配图生成器：

```bash
python generate_article_images.py
```

生成以下配图：
- `cover_2026_tech.png` - 封面图
- `ai_tools_era.png` - AI编程工具爆发图
- `multi_agent_era.png` - 多智能体协作图
- `developer_strategy.png` - 开发者策略图
- `skill_radar_2026.png` - 技能雷达图
- `future_vision.png` - 未来展望图

### 字体要求

确保系统安装以下字体之一：
- Windows: `微软雅黑 (msyh.ttc)`、`黑体 (simhei.ttf)`
- macOS: `PingFang.ttc`、`STHeiti Light.ttc`

如字体缺失，脚本会自动回退到默认字体。

## 工作流程

1. **生成配图（可选）** - 使用 generate_article_images.py 生成文章配图
2. **读取文件** - 解析 Markdown/HTML/TXT 内容
3. **处理图片** - 扫描本地图片并上传到微信素材库，**自动替换 Markdown 中的本地图片路径为微信素材URL**
4. **转换格式** - 将内容转换为微信支持的 HTML
5. **发布草稿** - 调用草稿箱 API 完成发布

### 配图自动插入说明

发布时，系统会自动：
1. 扫描 Markdown 文件中的 `![alt](本地路径)` 图片语法
2. 将本地图片上传到微信素材库
3. 将本地路径替换为微信返回的 `mmbiz.qpic.cn` 素材URL
4. 确保所有配图在公众号中正常显示，无需手动编辑

**示例：**
```markdown
![封面图](claude_code_cover.png)  <!-- 本地路径 -->
```
发布后会自动替换为：
```html
<img src="https://mmbiz.qpic.cn/mmbiz_png/..." alt="封面图" ... />
```

## 前提条件

使用此技能前需要：

1. 配置微信公众号 AppID 和 AppSecret
2. 将服务器 IP 添加到微信公众号白名单
3. 确保 Python 依赖已安装（requests、Pillow）

```bash
pip install requests Pillow
```

## 配置项

在 `config.json` 中配置：

```json
{
  "appId": "your_appid",
  "appSecret": "your_appsecret"
}
```

## 错误处理

| 错误码 | 原因 | 解决方案 |
|--------|------|----------|
| 40001 | Token无效 | 检查AppSecret或重新获取Token |
| 40125 | AppSecret错误 | 核对AppSecret是否正确 |
| -1 | 系统繁忙 | 稍后重试 |
| 40164 | IP未在白名单 | 添加当前IP到白名单 |

## HTML排版问题排查指南

### 常见排版问题及解决方案

| 问题类型 | 具体表现 | 原因 | 解决方案 |
|----------|----------|------|----------|
| **配图不显示** | 文章中图片显示为空白或加载失败 | HTML中使用了本地图片路径 | 使用已上传到微信素材库的图片URL（mmbiz.qpic.cn域名） |
| **排版错乱** | 文字、图片、表格位置混乱 | CSS样式不兼容微信编辑器 | 使用内联样式（style属性），避免复杂CSS选择器 |
| **多余空白** | 段落间存在大块空白区域 | HTML标签未正确闭合或使用了错误的块级元素 | 确保所有标签正确闭合，使用margin/padding控制间距 |
| **字体异常** | 文字大小不一或换行异常 | 未指定字体或字体单位不统一 | 使用px或em作为字体单位，指定fallback字体 |
| **表格错位** | 表格在移动端显示异常 | 表格宽度固定或未设置响应式 | 表格宽度使用100%，th/td设置overflow-wrap |
| **emoji显示异常** | 特殊符号显示为方框 | 系统不支持emoji字符 | 使用文字替代emoji，或使用PNG图片 |

### 推荐的HTML模板结构

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
</head>
<body style="margin:0;padding:0;background-color:#ffffff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">

<!-- 封面图 -->
<section style="margin:0;padding:0;">
    <img src="https://mmbiz.qpic.cn/..." style="width:100%;display:block;" />
</section>

<!-- 正文内容 -->
<section style="padding:20px 15px;">
    <h2 style="font-size:20px;color:#1a1a1a;margin:0 0 15px 0;">标题</h2>
    <p style="font-size:16px;color:#333333;line-height:1.8;margin:0 0 15px 0;">正文内容</p>
</section>

<!-- 配图（使用已上传的微信素材URL） -->
<img src="https://mmbiz.qpic.cn/mmbiz_png/..." style="width:100%;border-radius:8px;display:block;margin:15px 0;" />
<p style="text-align:center;font-size:13px;color:#999999;margin:0 0 20px 0;">图：图片说明</p>

<!-- 表格 -->
<table style="width:100%;border-collapse:collapse;font-size:14px;">
    <tr><th>表头1</th><th>表头2</th></tr>
    <tr><td>内容1</td><td>内容2</td></tr>
</table>

</body>
</html>
```

### 图片URL替换规则

发布文章时，图片需要：
1. **上传到微信素材库** - 通过API上传图片获取永久素材URL
2. **使用mmbiz.qpic.cn域名** - 微信返回的图片URL必须使用此域名
3. **保留URL参数** - 如 `?wx_fmt=png` 等参数必须保留
4. **使用https协议** - 微信要求使用https而非http

### 微信素材URL有效期问题（重要）

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| **配图不显示** | 之前上传的URL已失效或使用了错误的URL | 每次发布前重新上传图片获取新URL |
| **重复使用URL** | 同一URL被多次使用导致失效 | 每次发布文章时，重新上传所有配图 |
| **URL混用** | 封面图URL用作内容图 | 确保封面图和内容图分别上传，使用对应的URL |

**最佳实践**：
1. 每次发布文章前，使用 `upload_images_v2.py` 脚本重新上传所有图片
2. 生成的URL映射文件 `wechat_image_urls.json` 记录了所有图片URL
3. 替换HTML中的旧URL为新URL后再发布
4. 不要复用之前文章的图片URL

**URL映射文件格式**：
```json
{
  "cover_20260407.png": "https://mmbiz.qpic.cn/mmbiz_png/...",
  "img_github_trending.png": "https://mmbiz.qpic.cn/sz_mmbiz_png/...",
  ...
}
```

---

## 配图加载失败排查指南

### 常见失败原因及解决方案

| 问题类型 | 具体原因 | 解决方案 |
|----------|----------|----------|
| **文件问题** | 图片文件不存在 | 检查文件路径是否正确，使用绝对路径 |
| **大小超限** | 图片超过2MB | 使用图片压缩工具将图片缩小到2MB以下 |
| **格式不支持** | 使用了bmp/webp等格式 | 转换为 jpg/jpeg/png/gif 格式 |
| **MIME类型错误** | 文件扩展名与实际格式不符 | 确保文件扩展名与实际格式一致 |
| **Token过期** | AccessToken失效 | 重新获取Token（有效期2小时） |
| **IP白名单** | 服务器IP未添加 | 登录微信公众平台 → 安全中心 → IP白名单 |
| **权限不足** | 素材上传权限被限制 | 检查公众号类型（需已认证订阅号/服务号） |
| **中文字体缺失** | 字体渲染异常 | 安装微软雅黑或黑体字体 |
| **图标显示异常** | 系统不支持特殊符号 | 使用 PIL/Pillow 库生成图片而非 Canvas |

### 图片要求

- **格式**：JPG、JPEG、PNG、GIF
- **大小**：≤ 2MB
- **分辨率**：建议 900x383 像素（封面图）
- **宽高比**：建议 2.35:1 或 16:9

## 示例

### 示例1：生成并发布文章

**输入：**
```
生成2026年技术圈大变局的配图，然后发布到公众号草稿箱
```

**输出：**
```
📊 公众号文章配图生成器
==================================================
🎨 生成封面图... ✅ 已保存
🎨 生成AI工具图... ✅ 已保存
🎨 生成多智能体图... ✅ 已保存
🎨 生成开发者策略图... ✅ 已保存
🎨 生成技能雷达图... ✅ 已保存
🎨 生成未来展望图... ✅ 已保存
🎉 所有配图生成完成!

📤 微信公众号文件发布
==================================================
✅ 文件已发布到草稿箱
  - 标题：2026年技术圈大变局：AI正在重塑你的开发方式
  - media_id: xxxxxxxx
```

### 示例2：发布 Markdown 文件

**输入：**
```
发布文件到公众号，文件路径：C:/Users/xxx/article.md
```

**输出：**
```
✓ 文件已读取：C:/Users/xxx/article.md
✓ 检测到本地图片：3 张
✓ 图片上传完成
✓ 文章已发布到草稿箱
  - 标题：CodeBuddy 使用教程
  - media_id: xxxxxxxx
```

## 限制说明

- 支持 Windows / macOS / Linux 平台
- 需安装 Python 3.6+
- 文件路径需使用绝对路径
- 单次最多上传 10 张图片
- 图片大小限制：≤ 2MB

## 更新日志

### v1.4.0 (2026-04-10)

- 新增 **配图自动插入** 功能说明
- 明确 Markdown 图片语法自动转换为微信素材URL的流程
- 确保配图在公众号中正常显示，无需手动编辑草稿箱
- **修复代码块解析**：支持 bash、powershell、python 等多行代码块正确转换
- **修复 Markdown 语法解析**：支持 `---` 分隔线和 `>` 引用块
- **修复标题格式**：标题中的 `**粗体**` 和 `*斜体*` 符号自动去除，只保留纯文字
- **修复代码注释**：代码块中的 `# 注释` 行自动去除 `#` 符号，如 `# macOS/Linux 用户` → `macOS/Linux 用户`
- 代码块使用深色主题样式，提升阅读体验
- 支持 Windows/macOS 不同换行符格式（\r\n 和 \n）

### v1.3.0 (2026-04-07)

- 新增 **微信素材URL有效期问题说明**
- 添加配图不显示的完整原因分析（URL失效、重复使用URL、URL混用）
- 提供最佳实践：每次发布前重新上传图片
- 添加 `upload_images_v2.py` 脚本用于批量上传图片获取URL
- 说明URL映射文件格式（wechat_image_urls.json）
- 强调使用https协议的重要性

### v1.2.0 (2026-04-07)

- 新增 **HTML排版问题排查指南**
- 添加常见排版问题及解决方案（配图不显示、排版错乱、多余空白等）
- 提供推荐的HTML模板结构
- 明确图片URL替换规则（mmbiz.qpic.cn域名、URL参数保留）
- 解决本地图片路径导致配图不显示的问题
- 优化HTML内联样式，确保微信编辑器兼容性

### v1.1.0 (2026-04-03)

- 新增配图生成功能 `generate_article_images.py`
- 支持生成封面图、AI工具图、多智能体协作图等6种配图
- 修复配图中文字体和图标显示异常问题
- 使用 PIL/Pillow 库确保字体正确渲染
- 支持 Windows/macOS 多平台字体适配

### v1.0.1 (2026-04-03)

- 修复配图加载失败问题
- 添加动态 MIME 类型检测（支持 jpg/jpeg/png/gif/bmp/webp）
- 新增图片验证方法（文件大小≤2MB、格式检查）
- 完善错误提示，包含常见错误码映射

### v1.0.0 (2026-04-02)

- 初始版本发布
- 支持 Markdown/HTML/TXT 文件发布
- 支持图片自动上传
- 支持封面图设置
