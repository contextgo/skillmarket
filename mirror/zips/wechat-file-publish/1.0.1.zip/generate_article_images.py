#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文章配图生成器
生成高质量文章配图，确保中文字体和图标正确显示
支持封面图、AI工具图、多智能体协作图、技能雷达图等
"""

import sys
import os

# 确保中文输出正常
sys.stdout.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 尝试导入 PIL
try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    import math
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("⚠️ PIL (Pillow) 未安装，将尝试使用 HTML 方式生成...")

# ==================== 配置 ====================
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

# 中文字体路径配置
FONT_PATHS = [
    "C:/Windows/Fonts/msyh.ttc",      # 微软雅黑
    "C:/Windows/Fonts/simhei.ttf",    # 黑体
    "C:/Windows/Fonts/simsun.ttc",    # 宋体
    "C:/Windows/Fonts/arial.ttf",     # Arial
    "/System/Library/Fonts/PingFang.ttc",  # macOS
    "/System/Library/Fonts/STHeiti Light.ttc",  # macOS 黑体
]

def get_font(size, bold=False):
    """获取可用的中文字体"""
    if not HAS_PIL:
        return None
    
    for font_path in FONT_PATHS:
        if os.path.exists(font_path):
            try:
                if bold:
                    bold_path = font_path.replace('.ttc', 'bd.ttc').replace('.ttf', 'bd.ttf')
                    if os.path.exists(bold_path):
                        return ImageFont.truetype(bold_path, size)
                return ImageFont.truetype(font_path, size)
            except Exception:
                continue
    
    try:
        return ImageFont.truetype(FONT_PATHS[0], size)
    except:
        return ImageFont.load_default()

# ==================== 配色方案 ====================
COLORS = {
    'dark': (10, 15, 25),
    'dark_mid': (20, 30, 50),
    'primary': '#667eea',
    'primary_rgb': (102, 126, 234),
    'accent': '#764ba2',
    'accent_rgb': (118, 75, 162),
    'white': (255, 255, 255),
    'text_dim': (200, 200, 220),
    'glow': (102, 126, 234),
}

def gradient_color(c1, c2, t):
    """线性插值颜色"""
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))

def draw_grid(draw, width, height, spacing=40, alpha=20):
    """绘制网格"""
    for x in range(0, width, spacing):
        draw.line([(x, 0), (x, height)], fill=(102, 126, 234, alpha))
    for y in range(0, height, spacing):
        draw.line([(0, y), (width, y)], fill=(102, 126, 234, alpha))

# ==================== 配图生成函数 ====================

def create_cover_image(output_path=None):
    """生成封面图"""
    print("🎨 生成封面图...")
    
    width, height = 900, 383
    img = Image.new('RGB', (width, height), COLORS['dark'])
    draw = ImageDraw.Draw(img)
    
    for y in range(height):
        t = y / height
        color = gradient_color(COLORS['dark'], COLORS['dark_mid'], t)
        draw.line([(0, y), (width, y)], fill=color)
    
    draw_grid(draw, width, height)
    
    glow_x, glow_y = width // 2, height // 2
    for r in range(150, 0, -5):
        draw.ellipse([glow_x-r, glow_y-r, glow_x+r, glow_y+r], fill=COLORS['primary_rgb'])
    
    font_title = get_font(48, bold=True)
    font_subtitle = get_font(32, bold=True)
    font_tag = get_font(18)
    
    draw.text((width//2 + 2, 122), "2026年技术圈大变局", fill=(0, 0, 0), font=font_title, anchor="mm")
    draw.text((width//2, 120), "2026年技术圈大变局", fill=COLORS['white'], font=font_title, anchor="mm")
    
    draw.text((width//2 + 2, 187), "AI正在重塑你的开发方式", fill=(0, 0, 0), font=font_subtitle, anchor="mm")
    draw.text((width//2, 185), "AI正在重塑你的开发方式", fill=COLORS['primary_rgb'], font=font_subtitle, anchor="mm")
    
    draw.rounded_rectangle([width//2 - 120, 260, width//2 + 120, 305], radius=20, fill=(102, 126, 234, 50))
    draw.text((width//2, 285), "程序员 · AI · 技术趋势", fill=COLORS['primary_rgb'], font=font_tag, anchor="mm")
    
    # 显示器图形
    monitor_x, monitor_y = 700, 130
    monitor_w, monitor_h = 120, 90
    draw.rectangle([monitor_x, monitor_y, monitor_x + monitor_w, monitor_y + monitor_h], outline=COLORS['primary_rgb'], width=2)
    
    for i in range(5):
        line_y = monitor_y + 15 + i * 14
        line_w = 50 + (i * 15) % 50
        draw.rectangle([monitor_x + 15, line_y, monitor_x + 15 + line_w, line_y + 8], fill=(102, 126, 234, 100))
    
    head_x, head_y = monitor_x + 60, monitor_y + monitor_h + 15
    draw.ellipse([head_x - 12, head_y, head_x + 12, head_y + 24], fill=COLORS['primary_rgb'])
    draw.rectangle([head_x - 18, head_y + 24, head_x + 18, head_y + 60], fill=COLORS['primary_rgb'])
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "cover_2026_tech.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def create_ai_tools_image(output_path=None):
    """生成AI编程工具图"""
    print("🎨 生成AI工具图...")
    
    width, height = 900, 400
    img = Image.new('RGB', (width, height), (15, 20, 35))
    draw = ImageDraw.Draw(img)
    
    for y in range(height):
        t = y / height
        color = gradient_color((15, 20, 35), (25, 30, 50), t)
        draw.line([(0, y), (width, y)], fill=color)
    
    font_title = get_font(28, bold=True)
    font_label = get_font(16, bold=True)
    font_small = get_font(14)
    
    draw.text((width//2, 40), "AI编程工具进入全面爆发期", fill=COLORS['white'], font=font_title, anchor="mm")
    
    center_x, center_y = width // 2, height // 2 + 20
    main_radius = 60
    
    for r in range(main_radius + 30, main_radius, -3):
        draw.ellipse([center_x-r, center_y-r, center_x+r, center_y+r], fill=(102, 126, 234, 15))
    
    draw.ellipse([center_x-main_radius, center_y-main_radius, center_x+main_radius, center_y+main_radius], 
                 fill=COLORS['primary_rgb'])
    draw.text((center_x, center_y), "AI", fill=COLORS['white'], font=get_font(24, bold=True), anchor="mm")
    
    tools = [
        ("代码补全", -150, -80, (240, 147, 251)),
        ("架构设计", 150, -80, (79, 172, 254)),
        ("代码审查", -150, 80, (67, 233, 123)),
        ("自动重构", 150, 80, (250, 112, 154)),
        ("智能调试", 0, -150, (255, 200, 100)),
        ("测试生成", 0, 150, (180, 130, 255)),
    ]
    
    for name, offset_x, offset_y, color in tools:
        node_x = center_x + offset_x
        node_y = center_y + offset_y
        node_radius = 35
        
        draw.line([center_x, center_y, node_x, node_y], fill=(102, 126, 234, 80), width=2)
        draw.ellipse([node_x-node_radius, node_y-node_radius, node_x+node_radius, node_y+node_radius], fill=color)
        draw.text((node_x, node_y), name, fill=COLORS['white'], font=font_small, anchor="mm")
    
    draw.text((width//2, height - 30), "2026年 · AI成为开发团队主力成员", fill=COLORS['text_dim'], font=font_label, anchor="mm")
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "ai_tools_era.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def create_multi_agent_image(output_path=None):
    """生成多智能体协作图"""
    print("🎨 生成多智能体图...")
    
    width, height = 900, 400
    img = Image.new('RGB', (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    font_title = get_font(24, bold=True)
    font_label = get_font(16, bold=True)
    font_small = get_font(12)
    
    draw.text((width//2, 35), "多智能体协作工作流程", fill=(50, 50, 50), font=font_title, anchor="mm")
    
    center_x, center_y = width // 2, height // 2 + 10
    center_radius = 55
    
    draw.ellipse([center_x-center_radius, center_y-center_radius, center_x+center_radius, center_y+center_radius], 
                 fill=COLORS['primary_rgb'])
    draw.text((center_x, center_y - 12), "主控AI", fill=COLORS['white'], font=font_label, anchor="mm")
    draw.text((center_x, center_y + 10), "Coordinator", fill=COLORS['white'], font=font_small, anchor="mm")
    
    agents = [
        ("Agent A", "数据库设计", 180, 90, (240, 147, 251)),
        ("Agent B", "接口开发", 720, 90, (79, 172, 254)),
        ("Agent C", "前端页面", 180, 300, (67, 233, 123)),
        ("Agent D", "联调测试", 720, 300, (250, 112, 154)),
    ]
    
    for name, role, node_x, node_y, color in agents:
        node_radius = 42
        draw.line([center_x, center_y, node_x, node_y], fill=(102, 126, 234, 80), width=3)
        draw.ellipse([node_x-node_radius, node_y-node_radius, node_x+node_radius, node_y+node_radius], fill=color)
        draw.text((node_x, node_y - 6), name, fill=COLORS['white'], font=font_label, anchor="mm")
        draw.text((node_x, node_y + 12), role, fill=COLORS['white'], font=font_small, anchor="mm")
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "multi_agent_era.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def create_developer_strategy_image(output_path=None):
    """生成开发者策略图"""
    print("🎨 生成开发者策略图...")
    
    width, height = 900, 450
    img = Image.new('RGB', (width, height), (15, 20, 40))
    draw = ImageDraw.Draw(img)
    
    for y in range(height):
        t = y / height
        color = gradient_color((15, 20, 40), (30, 40, 70), t)
        draw.line([(0, y), (width, y)], fill=color)
    
    font_title = get_font(28, bold=True)
    font_label = get_font(18, bold=True)
    font_small = get_font(14)
    
    draw.text((width//2, 40), "开发者应对策略", fill=COLORS['white'], font=font_title, anchor="mm")
    
    strategies = [
        ("保持敏锐", "关注技术趋势\n但别追着每个新框架跑", 200, 180, (102, 126, 234)),
        ("聚焦价值", "技术最终要落地\n场景比技术本身更重要", 450, 180, (118, 75, 162)),
        ("学会协作", "掌握Prompt编程能力\n让AI成为你的放大器", 200, 330, (67, 233, 123)),
        ("系统思维", "从单点突破到全局设计\n从码农到架构师", 450, 330, (250, 112, 154)),
    ]
    
    for title, desc, cx, cy, color in strategies:
        card_w, card_h = 180, 100
        x1, y1 = cx - card_w//2, cy - card_h//2
        x2, y2 = cx + card_w//2, cy + card_h//2
        
        draw.rounded_rectangle([x1, y1, x2, y2], radius=12, fill=color)
        draw.text((cx, cy - 20), title, fill=COLORS['white'], font=font_label, anchor="mm")
        
        lines = desc.split('\n')
        for i, line in enumerate(lines):
            draw.text((cx, cy + 5 + i * 18), line, fill=(255, 255, 255, 200), font=font_small, anchor="mm")
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "developer_strategy.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def create_skill_radar_image(output_path=None):
    """生成技能雷达图"""
    print("🎨 生成技能雷达图...")
    
    width, height = 900, 450
    img = Image.new('RGB', (width, height), (102, 126, 234))
    draw = ImageDraw.Draw(img)
    
    for y in range(height):
        t = y / height
        color = gradient_color((102, 126, 234), (118, 75, 162), t)
        draw.line([(0, y), (width, y)], fill=color)
    
    font_title = get_font(28, bold=True)
    font_label = get_font(14, bold=True)
    
    center_x, center_y = width // 2, height // 2
    radius = 140
    
    draw.text((center_x, 50), "2026年核心技能图谱", fill=COLORS['white'], font=font_title, anchor="mm")
    
    skills = [
        ("AI系统设计", 0, -1),
        ("业务建模", 0.866, -0.5),
        ("技术决策", 0.866, 0.5),
        ("跨域整合", 0, 1),
        ("Prompt编程", -0.866, 0.5),
        ("架构思维", -0.866, -0.5),
    ]
    
    for level in [0.25, 0.5, 0.75, 1.0]:
        points = []
        for angle in range(6):
            rad = (angle * 60 - 90) * math.pi / 180
            x = center_x + radius * level * math.cos(rad)
            y = center_y + radius * level * math.sin(rad)
            points.append((x, y))
        
        for i in range(6):
            p1 = points[i]
            p2 = points[(i + 1) % 6]
            draw.line([p1, p2], fill=(255, 255, 255, 60), width=1)
    
    for angle in range(6):
        rad = (angle * 60 - 90) * math.pi / 180
        x = center_x + radius * math.cos(rad)
        y = center_y + radius * math.sin(rad)
        draw.line([center_x, center_y, x, y], fill=(255, 255, 255, 60), width=1)
    
    skill_values = [0.95, 0.88, 0.82, 0.85, 0.90, 0.92]
    data_points = []
    for i, (name, dx, dy) in enumerate(skills):
        val = skill_values[i]
        rad = (i * 60 - 90) * math.pi / 180
        x = center_x + radius * val * math.cos(rad)
        y = center_y + radius * val * math.sin(rad)
        data_points.append((x, y))
    
    draw.polygon(data_points, fill=(255, 255, 255, 80), outline=(255, 255, 255, 200))
    
    label_radius = radius + 40
    for i, (name, dx, dy) in enumerate(skills):
        rad = (i * 60 - 90) * math.pi / 180
        x = center_x + label_radius * math.cos(rad)
        y = center_y + label_radius * math.sin(rad)
        draw.text((x, y), name, fill=COLORS['white'], font=font_label, anchor="mm")
    
    draw.ellipse([center_x-8, center_y-8, center_x+8, center_y+8], fill=COLORS['white'])
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "skill_radar_2026.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def create_future_vision_image(output_path=None):
    """生成未来展望图"""
    print("🎨 生成未来展望图...")
    
    width, height = 900, 400
    img = Image.new('RGB', (width, height), (10, 15, 30))
    draw = ImageDraw.Draw(img)
    
    for y in range(height):
        t = y / height
        color = gradient_color((10, 15, 30), (20, 30, 60), t)
        draw.line([(0, y), (width, y)], fill=color)
    
    font_title = get_font(36, bold=True)
    font_large = get_font(48, bold=True)
    font_small = get_font(16)
    
    draw.text((width//2, 60), "2026年", fill=COLORS['white'], font=font_title, anchor="mm")
    draw.text((width//2, 120), "会用AI的程序员", fill=COLORS['primary_rgb'], font=font_large, anchor="mm")
    
    left_x = width // 4
    right_x = width * 3 // 4
    bar_y = 220
    
    draw.text((left_x, bar_y), "1x", fill=(150, 150, 150), font=get_font(40, bold=True), anchor="mm")
    draw.text((left_x, bar_y + 50), "传统效率", fill=(150, 150, 150), font=font_small, anchor="mm")
    
    draw.text((width//2, bar_y + 20), ">>>", fill=COLORS['white'], font=get_font(30), anchor="mm")
    
    draw.text((right_x, bar_y), "5-10x", fill=(67, 233, 123), font=get_font(40, bold=True), anchor="mm")
    draw.text((right_x, bar_y + 50), "AI辅助效率", fill=(67, 233, 123), font=font_small, anchor="mm")
    
    draw.text((width//2, 340), '"技术变革从来不是温和的"', fill=COLORS['text_dim'], font=font_small, anchor="mm")
    draw.text((width//2, 365), "与其焦虑，不如行动", fill=COLORS['white'], font=font_small, anchor="mm")
    
    output_path = output_path or os.path.join(OUTPUT_DIR, "future_vision.png")
    img.save(output_path, "PNG", quality=95)
    print(f"  ✅ 已保存: {output_path}")
    return output_path

def generate_all_images():
    """生成所有配图"""
    print("=" * 50)
    print("📊 公众号文章配图生成器")
    print("=" * 50)
    
    if not HAS_PIL:
        print("\n⚠️ PIL 未安装，无法生成图片")
        print("请安装 Pillow: pip install Pillow")
        return
    
    print(f"\n📁 输出目录: {OUTPUT_DIR}")
    print()
    
    try:
        create_cover_image()
        create_ai_tools_image()
        create_multi_agent_image()
        create_developer_strategy_image()
        create_skill_radar_image()
        create_future_vision_image()
        
        print("\n" + "=" * 50)
        print("🎉 所有配图生成完成!")
        print("=" * 50)
        
    except Exception as e:
        print(f"\n❌ 生成失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    generate_all_images()
