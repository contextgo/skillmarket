#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文件发布工具
支持 Markdown/HTML/TXT 文件一键发布到草稿箱
"""

import sys
import io
import os
import re
import json
import base64
import requests
from pathlib import Path

# 确保中文输出正常
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 默认配置
DEFAULT_CONFIG = {
    "appId": "",
    "appSecret": "",
    "defaultAuthor": "公众号作者"
}

class WeChatPublisher:
    """微信公众号发布器"""
    
    def __init__(self, config_path="config.json"):
        self.config = self._load_config(config_path)
        self.access_token = None
        
    def _load_config(self, config_path):
        """加载配置文件"""
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return DEFAULT_CONFIG.copy()
    
    def _save_config(self, config_path="config.json"):
        """保存配置文件"""
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def check_config(self):
        """检查配置是否完整"""
        if not self.config.get("appId"):
            return False, "AppID 未配置"
        if not self.config.get("appSecret"):
            return False, "AppSecret 未配置"
        return True, "配置完整"
    
    def set_credentials(self, app_id, app_secret):
        """设置公众号凭证"""
        self.config["appId"] = app_id
        self.config["appSecret"] = app_secret
        self._save_config()
        return True
    
    def get_access_token(self):
        """获取Access Token"""
        url = f"https://api.weixin.qq.com/cgi-bin/token"
        params = {
            "grant_type": "client_credential",
            "appid": self.config["appId"],
            "secret": self.config["appSecret"]
        }
        try:
            resp = requests.get(url, params=params, timeout=30)
            data = resp.json()
            if "access_token" in data:
                self.access_token = data["access_token"]
                return data["access_token"]
            else:
                error_msg = data.get("errmsg", "未知错误")
                raise Exception(f"获取Token失败: {error_msg}")
        except Exception as e:
            raise Exception(f"网络请求失败: {str(e)}")
    
    def _get_mime_type(self, file_path):
        """根据文件扩展名获取MIME类型"""
        import mimetypes
        ext = os.path.splitext(file_path)[1].lower()
        mime_map = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.bmp': 'image/bmp',
            '.webp': 'image/webp'
        }
        return mime_map.get(ext, mimetypes.guess_type(file_path)[0] or 'image/png')
    
    def _validate_image(self, image_path):
        """验证图片文件是否有效，返回(是否有效, 错误信息)"""
        if not os.path.exists(image_path):
            return False, f"图片文件不存在: {image_path}"
        
        # 检查文件大小（微信限制2MB）
        file_size = os.path.getsize(image_path)
        max_size = 2 * 1024 * 1024  # 2MB
        if file_size > max_size:
            size_mb = file_size / (1024 * 1024)
            return False, f"图片大小 {size_mb:.2f}MB 超过限制(2MB)"
        
        # 检查支持的格式
        ext = os.path.splitext(image_path)[1].lower()
        supported = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']
        if ext not in supported:
            return False, f"不支持的图片格式: {ext}，仅支持: {', '.join(supported)}"
        
        return True, "验证通过"
    
    def upload_thumb(self, image_path):
        """上传封面缩略图"""
        # 先验证图片
        is_valid, msg = self._validate_image(image_path)
        if not is_valid:
            raise FileNotFoundError(f"封面图片验证失败: {msg}")
        
        url = f"https://api.weixin.qq.com/cgi-bin/material/add_material"
        params = {"access_token": self.access_token, "type": "thumb"}
        
        # 使用动态MIME类型
        mime_type = self._get_mime_type(image_path)
        with open(image_path, 'rb') as f:
            files = {'media': (os.path.basename(image_path), f, mime_type)}
            resp = requests.post(url, params=params, files=files, timeout=60)
        
        data = resp.json()
        if "media_id" in data:
            return data["media_id"]
        raise Exception(f"封面上传失败: {data.get('errmsg', '未知错误')}")
    
    def upload_image(self, image_path):
        """上传正文图片，返回URL（用于图文消息）"""
        # 先验证图片
        is_valid, msg = self._validate_image(image_path)
        if not is_valid:
            print(f"    ⚠️ 图片验证失败: {msg}")
            return None
        
        # 使用图文消息内的图片上传接口（返回可用的URL）
        url = f"https://api.weixin.qq.com/cgi-bin/media/uploadimg"
        params = {"access_token": self.access_token}
        
        try:
            # 使用动态MIME类型
            mime_type = self._get_mime_type(image_path)
            with open(image_path, 'rb') as f:
                files = {'media': (os.path.basename(image_path), f, mime_type)}
                resp = requests.post(url, params=params, files=files, timeout=60)
            
            data = resp.json()
            if "url" in data:
                return data["url"]
            elif "errmsg" in data:
                # 常见错误码及解决方案
                error_mapping = {
                    "-1": "系统繁忙，请稍后重试",
                    "40001": "Token无效，请检查AppSecret",
                    "40164": "IP不在白名单，请添加服务器IP到白名单",
                    "41005": "缺少媒体文件，请检查文件是否正确上传"
                }
                err_code = data.get("errcode", "")
                solution = error_mapping.get(str(err_code), data.get("errmsg", "未知错误"))
                print(f"    ⚠️ 上传失败 [{err_code}]: {solution}")
                return None
            return None
        except Exception as e:
            print(f"    ⚠️ 上传异常: {e}")
            return None
    
    def parse_markdown(self, content, base_path=""):
        """解析Markdown为HTML"""
        html = content
        
        # 分隔线转换 (---)
        html = re.sub(r'^---$\s*', r'<hr style="border:none;border-top:1px solid #eee;margin:30px 0;">', html, flags=re.MULTILINE)
        
        # 引用块转换 (> )
        def replace_quote(match):
            lines = match.group(1).strip().split('\n')
            quote_content = '<br>'.join(line.lstrip('> ').strip() for line in lines)
            return f'<blockquote style="border-left:4px solid #667eea;padding:10px 15px;margin:15px 0;background:#f8f9fa;color:#555;font-style:italic;">{quote_content}</blockquote>'
        html = re.sub(r'^(?:>\s*(.+)\n?)+', replace_quote, html, flags=re.MULTILINE)
        
        # 标题转换（先去掉标题中的 ** 和 * 符号，只保留文字）
        def clean_title_text(title):
            """去掉标题中的 Markdown 格式符号，只保留文字"""
            # 去掉 **粗体** 的符号
            title = re.sub(r'\*\*(.+?)\*\*', r'\1', title)
            # 去掉 *斜体* 的符号
            title = re.sub(r'\*(.+?)\*', r'\1', title)
            return title
        
        def replace_h4(match):
            return f'<h4>{clean_title_text(match.group(1))}</h4>'
        html = re.sub(r'^#### (.+)$', replace_h4, html, flags=re.MULTILINE)
        
        def replace_h3(match):
            return f'<h3>{clean_title_text(match.group(1))}</h3>'
        html = re.sub(r'^### (.+)$', replace_h3, html, flags=re.MULTILINE)
        
        def replace_h2(match):
            return f'<h2>{clean_title_text(match.group(1))}</h2>'
        html = re.sub(r'^## (.+)$', replace_h2, html, flags=re.MULTILINE)
        
        def replace_h1(match):
            return f'<h1 style="text-align:center;color:#1a1a2e;">{clean_title_text(match.group(1))}</h1>'
        html = re.sub(r'^# (.+)$', replace_h1, html, flags=re.MULTILINE)
        
        # 替换图片
        def replace_image(match):
            alt = match.group(1)
            src = match.group(2)
            return f'<img src="{src}" alt="{alt}" style="width:100%;max-width:600px;display:block;margin:10px auto;" />'
        html = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', replace_image, html)
        
        # 列表转换
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*?</li>\n?)+', lambda m: f'<ul>{"".join(m.group().split())}</ul>', html)
        
        # 粗体和斜体
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        
        # 代码块 - 保留代码内容
        def replace_code_block(match):
            code = match.group(0)
            # 移除开头的 ``` 和语言标识（兼容多种格式）
            code = re.sub(r'^```\w*\r?\n', '', code, flags=re.MULTILINE)
            # 移除结尾的 ```
            code = re.sub(r'\r?\n```\s*$', '', code, flags=re.MULTILINE)
            # 将换行符转换为 <br> 以在 HTML 中保留格式
            lines = code.split('\n')
            # 处理代码行：去掉行首的 # 注释符号（保留缩进）
            processed_lines = []
            for line in lines:
                stripped = line.lstrip()
                if stripped.startswith('#') and not stripped.startswith('#!'):
                    # 去掉 # 符号，但保留前面的缩进空格
                    indent = len(line) - len(line.lstrip())
                    # 去掉 # 后的第一个空格
                    content = stripped[1:].lstrip() if len(stripped) > 1 else ''
                    line = ' ' * indent + content
                processed_lines.append(line.rstrip())
            # 保留缩进和格式
            code_html = '<br>'.join(processed_lines)
            # HTML转义（但保留换行转换后的<br>标签）
            code_html = code_html.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            # 恢复 <br> 标签
            code_html = code_html.replace('&lt;br&gt;', '<br>')
            return f'<pre style="background:#1e1e1e;color:#d4d4d4;padding:15px;border-radius:8px;overflow-x:auto;font-size:14px;line-height:1.6;margin:15px 0;"><code style="font-family:Consolas,Monaco,&quot;Courier New&quot;,monospace;white-space:pre-wrap;word-break:break-all;">{code_html}</code></pre>'
        
        html = re.sub(r'```[\s\S]*?```', replace_code_block, html)
        # 行内代码
        def replace_inline_code(match):
            code = match.group(1)
            code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return f'<code style="background:#f0f0f0;padding:2px 6px;border-radius:3px;font-family:Consolas,Monaco,monospace;font-size:90%;color:#e83e8c;">{code}</code>'
        html = re.sub(r'`([^`]+)`', replace_inline_code, html)
        
        # 段落
        paragraphs = html.split('\n\n')
        result = []
        for p in paragraphs:
            p = p.strip()
            if p and not p.startswith('<') and not p.endswith('>'):
                result.append(f'<p>{p}</p>')
            elif p:
                result.append(p)
        
        return '\n'.join(result)
    
    def parse_html(self, content):
        """解析HTML内容"""
        # 替换本地图片路径为微信素材URL
        def replace_src(match):
            src = match.group(1)
            if src.startswith('http'):
                return match.group(0)
            return match.group(0)  # 保持原样，后续上传处理
        
        return content
    
    def extract_title(self, content):
        """从内容中提取标题"""
        # Markdown标题
        match = re.search(r'^# (.+)$', content, re.MULTILINE)
        if match:
            return match.group(1).strip()
        
        # HTML标题
        match = re.search(r'<h1[^>]*>(.+?)</h1>', content, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        
        # HTML title标签
        match = re.search(r'<title>(.+?)</title>', content, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        
        return "未命名文章"
    
    def read_file(self, file_path):
        """读取文件内容"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    def scan_images(self, content, base_path):
        """扫描内容中的本地图片（支持Markdown和HTML格式）"""
        images = []
        img_paths = set()
        
        # Markdown图片
        for match in re.finditer(r'!\[([^\]]*)\]\(([^)]+)\)', content):
            img_path = match.group(2)
            if not img_path.startswith('http'):
                full_path = os.path.join(base_path, img_path) if not os.path.isabs(img_path) else img_path
                if full_path not in img_paths:
                    images.append(full_path)
                    img_paths.add(full_path)
        
        # HTML图片
        for match in re.finditer(r'<img[^>]+src=["\']([^"\']+)["\']', content):
            img_path = match.group(1)
            if not img_path.startswith('http'):
                full_path = os.path.join(base_path, img_path) if not os.path.isabs(img_path) else img_path
                if full_path not in img_paths:
                    images.append(full_path)
                    img_paths.add(full_path)
        
        return images
    
    def upload_content_images(self, content, base_path):
        """上传内容中的图片并替换URL（支持各种路径格式）"""
        images = self.scan_images(content, base_path)
        url_map = {}
        
        print(f"  📁 发现 {len(images)} 个本地图片:")
        
        for img_path in images:
            if os.path.exists(img_path):
                try:
                    url = self.upload_image(img_path)
                    if url:
                        # 存储所有可能的路径格式作为键
                        filename = os.path.basename(img_path)
                        abs_path = os.path.abspath(img_path)
                        rel_to_base = os.path.relpath(img_path, base_path)
                        
                        # 存储各种可能的键
                        url_map[img_path] = url  # 原始路径
                        url_map[abs_path] = url  # 绝对路径
                        url_map[filename] = url  # 文件名
                        url_map[rel_to_base] = url  # 相对于base的路径
                        
                        # 对于Windows路径，也存储正斜杠版本
                        if '\\' in rel_to_base:
                            url_map[rel_to_base.replace('\\', '/')] = url
                        if '\\' in img_path:
                            url_map[img_path.replace('\\', '/')] = url
                            
                        print(f"    ✅ 已上传: {filename} -> {url[:50]}...")
                    else:
                        print(f"    ⚠️ 上传失败: {filename}")
                except Exception as e:
                    print(f"    ❌ 上传出错: {os.path.basename(img_path)} - {e}")
            else:
                print(f"    ❌ 文件不存在: {img_path}")
        
        if not url_map:
            print("  ℹ️ 未找到需要上传的本地图片")
            return content
        
        # 1. 替换Markdown图片
        def replace_md(match):
            alt = match.group(1)
            src = match.group(2)
            
            # 尝试多种键格式进行匹配
            for key in [src, 
                       os.path.join(base_path, src) if not os.path.isabs(src) else src,
                       os.path.basename(src),
                       src.replace('/', '\\') if '/' in src else src,
                       src.replace('\\', '/') if '\\' in src else src]:
                if key in url_map:
                    return f'![{alt}]({url_map[key]})'
            
            # 如果都不匹配，返回原内容但不改变href，避免错误替换
            return match.group(0)
        
        updated = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', replace_md, content)
        
        # 2. 替换HTML图片
        def replace_html(match):
            tag = match.group(0)
            src_match = re.search(r'src=["\']([^"\']+)["\']', tag)
            if src_match:
                src = src_match.group(1)
                quote = '"' if f'src="{src}"' in tag else "'"
                
                # 尝试多种键格式进行匹配
                for key in [src, 
                           os.path.join(base_path, src) if not os.path.isabs(src) else src,
                           os.path.basename(src),
                           src.replace('/', '\\') if '/' in src else src,
                           src.replace('\\', '/') if '\\' in src else src]:
                    if key in url_map:
                        new_src = url_map[key]
                        new_tag = tag.replace(f'src={quote}{src}{quote}', f'src="{new_src}"')
                        return new_tag
            
            return tag
        
        updated = re.sub(r'<img[^>]+>', replace_html, updated)
        
        # 检查是否成功替换了所有图片
        remaining_images = self.scan_images(updated, base_path)
        local_remains = [img for img in remaining_images if not os.path.basename(img).startswith('http') and not img.startswith('http')]
        
        if local_remains:
            print(f"  ⚠️ 仍有 {len(local_remains)} 个本地图片未替换")
        else:
            print("  ✅ 所有本地图片已替换为微信URL")
        
        return updated
    
    def create_draft(self, title, author, content, thumb_id=None):
        """创建草稿"""
        url = f"https://api.weixin.qq.com/cgi-bin/draft/add"
        params = {"access_token": self.access_token}
        
        # 构建文章数据
        article = {
            "title": title,
            "author": author or self.config.get("defaultAuthor", "公众号作者"),
            "content": content,
            "digest": title[:50] + "..." if len(title) > 50 else title,
            "need_open_comment": 0,
            "only_fans": 0
        }
        
        # thumb_media_id 必须是有效的永久素材ID，如果没有封面图则不设置此字段
        if thumb_id:
            article["thumb_media_id"] = thumb_id
        
        # 打印请求内容以便调试
        print(f"\n📝 请求数据:")
        print(f"  标题: {article['title']}")
        print(f"  作者: {article['author']}")
        print(f"  内容长度: {len(content)} 字符")
        
        data = json.dumps({"articles": [article]}, ensure_ascii=False)
        print(f"  JSON数据: {data[:200]}...")
        
        headers = {'Content-Type': 'application/json; charset=utf-8'}
        
        resp = requests.post(url, params=params, data=data.encode('utf-8'), headers=headers, timeout=30)
        result = resp.json()
        
        print(f"  API响应: {result}")
        
        if "media_id" in result:
            return result["media_id"]
        raise Exception(f"创建草稿失败: {result.get('errmsg', result)}")
    
    def publish_file(self, file_path, cover_image=None, title=None, author=None):
        """发布文件到草稿箱"""
        print("=" * 50)
        print("📤 微信公众号文件发布")
        print("=" * 50)
        
        # 检查配置
        ok, msg = self.check_config()
        if not ok:
            raise Exception(f"配置错误: {msg}，请先运行配置命令设置 AppID 和 AppSecret")
        
        # 获取Token
        print("\n🔑 获取Access Token...")
        self.get_access_token()
        print("  ✅ 获取成功")
        
        # 读取文件
        print(f"\n📄 读取文件: {file_path}")
        content = self.read_file(file_path)
        base_path = os.path.dirname(os.path.abspath(file_path))
        
        # 提取标题
        if not title:
            title = self.extract_title(content)
        print(f"  📌 文章标题: {title}")
        
        # 先上传封面
        thumb_id = None
        if cover_image and os.path.exists(cover_image):
            print("\n🖼️ 上传封面图片...")
            thumb_id = self.upload_thumb(cover_image)
            print("  ✅ 封面上传成功")
        
        # 上传内容图片（在转换前处理Markdown中的图片）
        print("\n🖼️ 扫描并上传内容图片...")
        image_urls = self.scan_images(content, base_path)
        if image_urls:
            content = self.upload_content_images(content, base_path)
            print(f"  ✅ 成功上传 {len([u for u in image_urls if os.path.exists(u)])} 张图片")
        else:
            print("  ℹ️ 未发现本地图片")
        
        # 如果没有指定封面，尝试使用文章第一张图片
        if not thumb_id and not cover_image:
            for img_path in image_urls:
                if os.path.exists(img_path):
                    print(f"\n🖼️ 使用文章图片作为封面: {os.path.basename(img_path)}")
                    try:
                        thumb_id = self.upload_thumb(img_path)
                        print("  ✅ 封面设置成功")
                        break
                    except Exception as e:
                        print(f"  ⚠️ 封面上传失败: {e}")
                        thumb_id = None
        
        # 转换格式（图片URL已经替换为微信URL）
        ext = os.path.splitext(file_path)[1].lower()
        if ext == '.md':
            print("\n🔄 转换Markdown格式...")
            content = self.parse_markdown(content, base_path)
        elif ext == '.html':
            print("\n🔄 处理HTML格式...")
            content = self.parse_html(content)
        else:
            content = f'<p>{content}</p>'
        
        # 创建草稿
        print("\n📝 创建文章草稿...")
        media_id = self.create_draft(title, author, content, thumb_id)
        
        print("\n" + "=" * 50)
        print("🎉 发布成功！")
        print(f"   标题: {title}")
        print(f"   草稿ID: {media_id}")
        print("=" * 50)
        
        return {
            "success": True,
            "media_id": media_id,
            "title": title
        }


def setup_config():
    """交互式配置"""
    print("=" * 50)
    print("⚙️  微信公众号配置")
    print("=" * 50)
    
    config_path = "config.json"
    publisher = WeChatPublisher(config_path)
    
    # 获取AppID
    app_id = input(f"\n请输入AppID (当前: {publisher.config.get('appId', '未设置')}): ").strip()
    if not app_id:
        app_id = publisher.config.get("appId", "")
    
    # 获取AppSecret
    app_secret = input(f"请输入AppSecret (当前: {'已设置' if publisher.config.get('appSecret') else '未设置'}): ").strip()
    if not app_secret:
        app_secret = publisher.config.get("appSecret", "")
    
    if app_id and app_secret:
        publisher.set_credentials(app_id, app_secret)
        print("\n✅ 配置已保存!")
        
        # 测试连接
        try:
            token = publisher.get_access_token()
            print(f"✅ 连接测试成功! Token: {token[:20]}...")
        except Exception as e:
            print(f"⚠️ 连接测试失败: {e}")
    else:
        print("\n⚠️ AppID和AppSecret都不能为空")


def main():
    """主函数"""
    if len(sys.argv) > 1:
        if sys.argv[1] == "config":
            setup_config()
            return
        
        # 命令行模式
        file_path = sys.argv[1]
        cover_image = sys.argv[2] if len(sys.argv) > 2 else None
        
        # 获取脚本所在目录的绝对路径
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(script_dir, "config.json")
        publisher = WeChatPublisher(config_path)
        publisher.publish_file(file_path, cover_image)
    else:
        # 交互模式
        print("""
╔══════════════════════════════════════════════════════╗
║     📤 微信公众号文件发布工具 - 交互模式                  ║
╚══════════════════════════════════════════════════════╝

命令:
  python publish.py config     - 配置公众号凭证
  python publish.py <文件路径> [封面图] - 发布文件

示例:
  python publish.py article.md
  python publish.py article.md cover.png
""")
        
        # 检查配置
        publisher = WeChatPublisher()
        ok, msg = publisher.check_config()
        if not ok:
            print(f"\n⚠️ {msg}")
            print("\n请先运行 'python publish.py config' 配置公众号凭证")
            return
        
        # 输入文件路径
        file_path = input("\n请输入要发布的文件路径: ").strip().strip('"\'')
        if not file_path:
            print("❌ 文件路径不能为空")
            return
        
        # 可选：封面图
        cover_image = input("请输入封面图片路径 (直接回车跳过): ").strip().strip('"\'')
        if not cover_image:
            cover_image = None
        
        # 发布
        try:
            publisher.publish_file(file_path, cover_image)
        except Exception as e:
            print(f"\n❌ 发布失败: {e}")


if __name__ == "__main__":
    main()
