#!/bin/bash

echo "========================================"
echo "🗑️  缠论技能卸载脚本"
echo "========================================"
echo ""

SKILL_DIR="$HOME/.config/CherryStudio/Data/Skills/chanlun"

read -p "确认卸载 chanlun 技能吗？(y/n): " -n 1 -r

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🗑️  正在卸载..."
    
    # 备份（可选）
    BACKUP_DIR="$HOME/.config/CherryStudio/Data/Skills/chanlun_backup_$(date +%Y%m%d_%H%M%S)"
    if [ -d "$SKILL_DIR" ]; then
        echo "📦 创建备份：$BACKUP_DIR"
        cp -r "$SKILL_DIR" "$BACKUP_DIR" 2>/dev/null || true
    fi
    
    # 删除技能
    rm -rf "$SKILL_DIR"
    
    echo "✓ 技能已卸载"
    echo ""
    echo "如果想恢复备份："
    echo "   cp -r $BACKUP_DIR $SKILL_DIR"
else
    echo "已取消卸载"
fi

echo ""
