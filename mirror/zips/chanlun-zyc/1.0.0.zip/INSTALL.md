# 缠论 (Chan Lun) 技能安装指南

## 技能介绍

缠论 (Chan Lun) 股票监控技能是一个专门用于缠论技术分析的 AI 技能，集成到 CherryStudio 中。

### 核心功能

- ✅ 缠论中枢判断
- ✅ 买卖点识别（三类买点/卖点）
- ✅ 走势类型判断（上涨/下跌/盘整）
- ✅ 背驰检测（趋势背驰/盘整背驰）
- ✅ 级别划分（1 分型/5 分型/日线/周线）
- ✅ 走势演化推演
- ✅ 完全分类应对方案

## 系统要求

- Python 3.8+
- CherryStudio 环境
- 可选依赖：pandas, numpy (用于数据分析)

## 安装步骤

### 方法一：手动安装（推荐）

1. **下载技能包**

   ```bash
   # 从 GitHub 或其他仓库下载
   # 或者使用 git clone
   git clone <your_skill_repo_url> ~/skills/chanlun
   ```

2. **手动复制文件**

   将以下文件复制到 CherryStudio 的技能目录：

   ```bash
   mkdir -p ~/.config/CherryStudio/Data/Skills/chanlun
   cp -r /path/to/skill/* ~/.config/CherryStudio/Data/Skills/chanlun/
   ```

3. **设置执行权限**

   ```bash
   chmod +x ~/.config/CherryStudio/Data/Skills/chanlun/*.py
   ```

4. **重启 CherryStudio**

   重启 CherryStudio 使新技能生效

### 方法二：使用 pip 安装

如果技能是打包好的 Python 包：

```bash
pip install chanlun-stock-monitoring
```

然后 CherryStudio 会自动发现并启用。

### 方法三：使用脚本安装

```bash
# 下载并安装脚本
wget -O install_channlun.sh https://raw.githubusercontent.com/yourrepo/chanlun/install.sh
chmod +x install_channlun.sh
./install_channlun.sh
```

## 验证安装

启动 CherryStudio 后，检查技能是否可用：

```bash
# 在 CherryStudio 终端中输入
/chanlun --help
```

如果显示帮助信息，说明安装成功！

## 配置股票数据源

### 使用 Tushare

```bash
# 安装 Tushare
pip install tushare

# 设置 API Key
export TUSHARE_API_KEY=your_api_key

# 测试获取数据
python -c "import tushare as ts; print(ts.get('sh600000').head())"
```

### 使用 AKShare

```bash
# 安装 AKShare
pip install akshare

# 获取沪深 300 数据
python -c "import akshare as ak; print(ak.stock_zh_a_spot_df().head())"
```

## 使用说明

### 基础分析

```bash
# 监控渐海德曼的缠论走势
chanlun --code 688577 --interval 30m

# 判断是否出现买点
chanlun --code 688577 --check-buypoint

# 判断是否出现卖点
chanlun --code 688577 --check-sellpoint
```

### 参数说明

| 参数 | 类型 | 说明 |
|------|------|------|
| --code | string | 股票代码 |
| --interval | string | 监控级别 (1m/5m/30m/60m/1d) |
| --check-buypoint | boolean | 检查买点信号 |
| --check-sellpoint | boolean | 检查卖点信号 |
| --identify-center | boolean | 识别走势中枢 |

## 使用示例

```bash
#!/bin/bash

# 监控所有持仓股票
# 使用：./monitor.sh --batch

MODE=${1:-single}

if [ "$MODE" == "--batch" ]; then
    stocks="688577 600156 688694 600459 688556"
    for code in $stocks; do
        echo "分析 $code..."
        chanlun --code $code --interval 30m --check-reversal
    done
else
    # 单只股票分析
    echo "请输入股票代码："
    read CODE
    chanlun --code $CODE --interval 30m
fi
```

## 故障排除

### 问题 1：技能未启用

```bash
# 检查技能文件
ls ~/.config/CherryStudio/Data/Skills/chanlun/

# 检查 SKILL.md 是否存在
cat ~/.config/CherryStudio/Data/Skills/chanlun/SKILL.md
```

### 问题 2：Python 依赖缺失

```bash
# 安装缺失的依赖
pip install pandas numpy matplotlib

# 或者使用 uv（推荐的包管理器）
uv add pandas numpy
```

### 问题 3：权限错误

```bash
# 给技能文件添加执行权限
chmod -R 755 ~/.config/CherryStudio/Data/Skills/chanlun/
```

## 更新技能

```bash
# 拉取最新版本
git pull

# 或手动更新文件
cp new_files/* ~/.config/CherryStudio/Data/Skills/chanlun/
```

## 卸载技能

```bash
# 删除技能目录
rm -rf ~/.config/CherryStudio/Data/Skills/chanlun

# 或卸载 Python 包
pip uninstall chanlun-stock-monitoring
```

## 获取帮助

- **GitHub Issues**: https://github.com/yourrepo/chanlun/issues
- **文档**: https://yourrepo.com/doc
- **社区**: https://yourrepo.com/community

## 许可证

MIT License

## 联系方式

- Email: your.email@example.com
- Twitter: @yourhandle
- Telegram: your_channel
