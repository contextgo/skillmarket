#!/bin/bash

# 缠论技能安装脚本
set -e

echo "========================================"
echo "🎯 缠论 (Chan Lun) 技能安装器"
echo "========================================"
echo ""

# 检测系统
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "🍎 检测到 macOS 系统"
    sudo=$(yes | sudo)
else
    echo "🐧 检测到 Linux/Unix 系统"
    sudo=""
fi

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 请先安装 Python 3.8+"
    echo "   sudo apt install python3 python3-pip  # Ubuntu/Debian"
    echo "   sudo yum install python3               # CentOS/RHEL"
    echo "   或访问 https://www.python.org 下载"
    exit 1
fi

echo "✓ Python 版本：$(python3 --version)"

# 创建技能目录
SKILL_DIR="$HOME/.config/CherryStudio/Data/Skills/chanlun"
mkdir -p "$SKILL_DIR"

echo "📂 技能目录：$SKILL_DIR"

# 复制技能文件
echo ""
echo "📦 正在复制技能文件..."

# 检查源文件位置
if [ -d "/home/zxc/.config/CherryStudio/Data/Skills/chanlun" ]; then
    SOURCE_DIR="/home/zxc/.config/CherryStudio/Data/Skills/chanlun"
    echo "   源目录：$SOURCE_DIR"
elif [ -d "$SKILL_DIR" ] && [ "$(ls -A $SKILL_DIR 2>/dev/null)" ]; then
    SOURCE_DIR="$SKILL_DIR"
    echo "   使用现有技能目录：$SOURCE_DIR"
else
    echo "❌ 找不到技能文件"
    echo "   请将技能文件复制到：$SKILL_DIR"
    exit 1
fi

# 复制文件（跳过已存在的文件）
cp -n "$SOURCE_DIR"/* "$SKILL_DIR/" 2>/dev/null || true

# 设置权限
echo "⚙️  正在设置权限..."
chmod -R 755 "$SKILL_DIR"

# 安装依赖
echo ""
echo "📦 正在安装 Python 依赖..."
pip3 install --quiet --upgrade pip
pip3 install --quiet pandas numpy matplotlib

echo "✓ 依赖安装完成"

# 验证安装
echo ""
echo "✅ 正在验证安装..."
if [ -f "$SKILL_DIR/SKILL.md" ]; then
    echo "✓ SKILL.md 存在"
    echo "✓ 技能安装成功！"
else
    echo "❌ 验证失败：SKILL.md 不存在"
    exit 1
fi

echo ""
echo "========================================"
echo "🎉 安装完成！"
echo "========================================"
echo ""
echo "下一步："
echo "1. 重启 CherryStudio"
echo "2. 在终端输入：/chanlun --help"
echo "3. 开始使用缠论分析功能！"
echo ""
