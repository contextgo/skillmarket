#!/usr/bin/env python3
"""
mental-health-monitor: 心理健康评估报告生成脚本
====================================================
输入心理健康相关文本（直接文本、.md 文件或 .csv 文件），
通过本地 Ollama 模型生成结构化评估报告。

支持输入格式：
  - --message   直接传入文本
  - --file      .md / .csv / .txt 文件路径

安全设计：
  - 只连接预配置的固定端点（不从用户输入动态构造）
  - 输入长度校验（最大 500,000 字）
  - 敏感信息本地检测（发送前提示）
  - 系统提示词从文件加载，与代码分离

用法：
    python analyze.py --message "最近总是失眠，心情低落..."
    python analyze.py --file ./心理健康记录.md
    python analyze.py --file ./心理健康数据.csv
"""

import argparse
import csv
import json
import re
import sys
import urllib.request
import urllib.error
from pathlib import Path
from io import StringIO, TextIOWrapper

# ── 硬编码配置 ────────────────────────────────────────────────────────────────

DEFAULT_HOST = "http://localhost:11434"
DEFAULT_MODEL = "qwen3.5:4b"
MAX_INPUT_CHARS = 500_000

# 敏感信息模式（仅用于检测提示，不做传输阻断）
SENSITIVE_PATTERNS = {
    "身份证号": (r"\b\d{15}\b|\b\d{18}\b",   "身份证号"),
    "手机号":   (r"\b1[3-9]\d{9}\b",          "手机号"),
    "银行卡号": (r"\b\d{13,19}\b",             "银行卡号"),
}

# ── 工具函数 ──────────────────────────────────────────────────────────────────

def print_err(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)


def print_warn(msg: str) -> None:
    print(f"[WARNING] {msg}", file=sys.stderr)


def print_info(msg: str) -> None:
    print(f"[INFO] {msg}", file=sys.stderr)


def detect_sensitive_info(text: str) -> list:
    findings = []
    for label, (pattern, _) in SENSITIVE_PATTERNS.items():
        for m in re.finditer(pattern, text):
            findings.append((label, m.group()))
    return findings


def validate_input(text: str) -> tuple[bool, str]:
    if not text or not text.strip():
        return False, "输入内容为空，请提供有效文本。"
    char_count = len(text)
    if char_count > MAX_INPUT_CHARS:
        return False, f"内容过长（{char_count} 字），超过上限 {MAX_INPUT_CHARS} 字。"
    sensitive = detect_sensitive_info(text)
    if sensitive:
        labels = list(set(l for l, _ in sensitive))
        warning = f"⚠️ 检测到敏感信息类型：{', '.join(labels)}，已本地处理不会外传。"
        return True, warning
    return True, ""


def parse_csv(file_path: Path) -> str:
    try:
        raw = file_path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raw = file_path.read_text(encoding="gbk")
        print_warn("文件使用 GBK 编码读取。")
    if raw.startswith("\ufeff"):
        raw = raw[1:]
    try:
        reader = csv.reader(StringIO(raw))
        rows = list(reader)
    except Exception as e:
        print_err(f"CSV 解析失败: {e}")
        sys.exit(1)
    if not rows:
        return ""
    first_row = rows[0]
    if len(first_row) == 1:
        lines = [row[0].strip() for row in rows if row and row[0].strip()]
        return "\n".join(lines)
    else:
        header = first_row
        lines = []
        for row in rows[1:]:
            for i, cell in enumerate(row):
                cell = cell.strip()
                if cell:
                    col_name = header[i].strip() if i < len(header) else f"列{i+1}"
                    lines.append(f"{col_name}：{cell}")
        return "\n".join(lines)


def load_input_content(args) -> tuple[str, str]:
    if args.message:
        return args.message.strip(), ""
    if args.file:
        path = Path(args.file).expanduser().resolve()
        if not path.exists():
            print_err(f"文件不存在: {path}")
            sys.exit(1)
        suffix = path.suffix.lower()
        if suffix == ".csv":
            print_info(f"解析 CSV 文件: {path.name}")
            content = parse_csv(path)
        elif suffix in (".md", ".txt", ".text"):
            print_info(f"读取 Markdown/文本文件: {path.name}")
            content = path.read_text(encoding="utf-8").strip()
        else:
            print_warn(f"未知文件类型 '{suffix}'，将作为纯文本读取。")
            try:
                content = path.read_text(encoding="utf-8").strip()
            except UnicodeDecodeError:
                content = path.read_text(encoding="gbk").strip()
        return content, ""
    if args.interactive:
        print_info("请粘贴内容，完成后按 Ctrl+Z 回车（Windows）或 Ctrl+D 回车（Mac/Linux）：")
        content = sys.stdin.read()
        return content.strip(), ""
    print_err("请提供 --message、--file 或 --interactive 参数。")
    sys.exit(1)


# ── 配置与提示词加载 ──────────────────────────────────────────────────────────

def _get_skill_root() -> Path:
    return Path(__file__).resolve().parent.parent


def load_config() -> tuple[str, str]:
    root = _get_skill_root()
    config_path = root / "references" / "config.md"
    host, model = DEFAULT_HOST, DEFAULT_MODEL
    if config_path.exists():
        try:
            for line in config_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("OLLAMA_HOST:") and ":" in line:
                    host = line.split(":", 1)[1].strip()
                elif line.startswith("MODEL_NAME:") and len(line.split(":", 1)) > 1:
                    model = line.split(":", 1)[1].strip()
        except Exception as e:
            print_warn(f"读取 config.md 失败: {e}，将使用默认值。")
    return host, model


def load_system_prompt() -> str:
    """
    从 references/system_prompt.md 加载系统提示词。
    仅剥离文件开头的 YAML frontmatter（--- ... ---），保留其余全部内容。
    """
    root = _get_skill_root()
    prompt_path = root / "references" / "system_prompt.md"

    if not prompt_path.exists():
        print_err(f"系统提示词文件不存在: {prompt_path}")
        sys.exit(1)

    try:
        content = prompt_path.read_text(encoding="utf-8")
    except Exception as e:
        print_err(f"读取系统提示词失败: {e}")
        sys.exit(1)

    # 仅剥离文件开头的 YAML frontmatter（--- ... ---）
    # frontmatter 必须从第 1 行开始，且两个 --- 之间内容较少（< 20 行）
    lines = content.splitlines()
    if lines and lines[0].strip() == "---":
        end_idx = None
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                end_idx = i
                break
        if end_idx is not None and end_idx < 20:
            content = "\n".join(lines[end_idx + 1:])

    content = content.strip()
    if not content:
        print_err("系统提示词文件内容为空。")
        sys.exit(1)

    return content


# ── Ollama API 调用 ────────────────────────────────────────────────────────────

def call_ollama(host: str, model: str, system_prompt: str, user_content: str, stream: bool = True) -> str:
    """
    调用 Ollama /api/chat 端点，使用 messages 格式。
    """
    url = f"{host.rstrip('/')}/api/chat"

    payload = {
        "model": model,
        "stream": stream,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "think": False,
        "options": {
            "temperature": 0.05,
            "num_predict": 15000,
            "repeat_last_n": 256,
            "repeat_penalty": 1.5,
            "num_ctx": 16384,
        },
    }

    body = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json" if not stream else "text/event-stream",
    }

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            if stream:
                reader = TextIOWrapper(resp, encoding="utf-8", errors="replace")
                buffer = ""
                for line in reader:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                        msg = chunk.get("message", {})
                        if isinstance(msg, dict):
                            # 思考模型：优先输出 content，跳过 thinking
                            token = msg.get("content", "")
                            # thinking 内容仅显示到 stderr（可选）
                            thinking = msg.get("thinking", "")
                            if thinking and not token:
                                # 模型正在思考，尚未生成正文
                                pass
                        else:
                            token = chunk.get("response", "")  # 兼容旧版 /api/generate
                        if token:
                            print(token, end="", flush=True)
                            buffer += token
                    except json.JSONDecodeError:
                        continue
                print()
                return buffer
            else:
                result = json.loads(resp.read().decode("utf-8"))
                msg = result.get("message", {})
                return msg.get("content", "") if isinstance(msg, dict) else result.get("response", "(模型无响应)")
    except urllib.error.URLError as e:
        print_err(f"无法连接到 Ollama 服务 ({host})。")
        print_err("请确认：1) Ollama 服务已启动  2) 地址可达  3) 模型已加载（运行 ollama list 确认）")
        print_err(f"底层错误: {e.reason}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print_err(f"解析 Ollama 响应失败: {e}")
        sys.exit(1)
    except Exception as e:
        print_err(f"未知错误: {type(e).__name__}: {e}")
        sys.exit(1)


# ── 主入口 ────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="通过 Ollama 生成心理健康评估报告",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python analyze.py --message '最近总是失眠，心情低落...'\n"
            "  python analyze.py --file ./心理健康记录.md\n"
            "  python analyze.py --file ./心理健康数据.csv\n"
            "  python analyze.py --interactive\n"
        ),
    )

    group = parser.add_mutually_exclusive_group(required=False)
    group.add_argument("--message", "-m", help="直接传入心理健康记录文本")
    group.add_argument("--file", "-f", help="文件路径 (.md / .csv / .txt)")
    group.add_argument("--interactive", "-i", action="store_true", help="从标准输入读取内容")

    parser.add_argument("--host", help=f"Ollama 服务器地址 (默认: 配置文件或 {DEFAULT_HOST})")
    parser.add_argument("--model", help=f"模型名称 (默认: 配置文件或 {DEFAULT_MODEL})")
    parser.add_argument("--no-stream", action="store_true", help="禁用流式输出（一次性返回）")

    args = parser.parse_args()

    # 加载配置
    default_host, default_model = load_config()
    host = args.host or default_host
    model = args.model or default_model

    # 加载内容
    content, warn = load_input_content(args)

    # 安全校验
    valid, msg = validate_input(content)
    if not valid:
        print_err(msg)
        sys.exit(1)
    if warn:
        print_warn(warn)

    # 加载系统提示词
    system_prompt = load_system_prompt()
    print_info(f"系统提示词长度: {len(system_prompt)} 字符")
    print_info(f"正在生成报告...（模型: {model}，字数: {len(content)}）")
    print_info(f"地址: {host}")
    print("─" * 60)

    output = call_ollama(
        host=host,
        model=model,
        system_prompt=system_prompt,
        user_content=content,
        stream=not args.no_stream,
    )

    if args.no_stream:
        print(output)


if __name__ == "__main__":
    main()
