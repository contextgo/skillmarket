# Mental Health Monitor — 配置文件
# 请在此填入你的 Ollama 服务信息

## ⚠️ 首次使用必读：配置 Ollama 连接

本 skill 需要本地 Ollama 服务才能运行。请按以下步骤操作：

### 步骤 1：安装 Ollama

访问官网下载安装：**https://ollama.com**

- Windows / macOS：下载安装包，双击运行即可
- Linux：`curl -fsSL https://ollama.com/install.sh | sh`

### 步骤 2：下载模型

```bash
# 下载推荐模型（中文能力强，4B 参数，约 2.5GB）
ollama pull qwen3.5:4b

# 也可以选择其他模型，例如：
# ollama pull qwen3:8b        # 更强效果，需更多显存
# ollama pull llama3:8b       # 英文为主
# ollama pull deepseek-r1:7b  # 推理能力强
```

### 步骤 3：确认模型已就绪

```bash
# 查看已安装的模型，确认名称一致
ollama list
```

输出示例：
```
NAME              ID              SIZE      MODIFIED
qwen3.5:4b        abc123def456    2.5 GB    2 hours ago
```

> ⚠️ `MODEL_NAME` 必须与 `ollama list` 显示的 **NAME 列完全一致**（包括标签如 `:4b`）

### 步骤 4：确保 Ollama 服务运行中

```bash
# 方式一：手动启动（终端会持续占用）
ollama serve

# 方式二：如果安装了桌面版，Ollama 通常已自动后台运行
# 检查是否运行：访问 http://localhost:11434 应返回 "Ollama is running"
```

### 步骤 5：修改下方配置（如需自定义）

如果你的 Ollama 运行在默认地址且使用推荐模型，**无需修改任何配置**，直接使用即可。

---

## Ollama 连接配置

```
OLLAMA_HOST: http://localhost:11434
MODEL_NAME: qwen3.5:4b
```

| 参数 | 说明 |
|------|------|
| `OLLAMA_HOST` | Ollama 服务地址（必须包含 `http://` 或 `https://`） |
| → 本机默认 | `http://localhost:11434` |
| → 局域网其他设备 | 填入对应 IP，如 `http://192.168.1.100:11434` |
| `MODEL_NAME` | 模型名称，须与 `ollama list` 输出的 NAME 完全一致 |
| → 推荐模型 | `qwen3.5:4b`（中文 + 小显存友好） |
| → 替代选择 | `qwen3:8b`、`llama3:8b`、`deepseek-r1:7b` 等 |

## 安全限制

```
MAX_INPUT_CHARS: 10000
```

- `MAX_INPUT_CHARS`：单次对话最大输入字符数，超出则拒绝发送

## ❓ 常见问题

| 问题 | 解决方案 |
|------|---------|
| 连接失败（Connection refused） | 确认 `ollama serve` 正在运行，或访问 http://localhost:11434 检查 |
| 模型未找到（model not found） | 运行 `ollama pull <模型名>` 下载，或检查 `ollama list` 中的名称拼写 |
| 报告内容截断或复读 | 编辑 `scripts/analyze.py` 中的 `temperature`（降低）或 `num_ctx`（增大） |
| 生成速度慢 | 确保使用 GPU 推理；小模型（4B）比大模型（8B+）更快 |
| 防火墙拦截 | 开放 11434 端口 |
