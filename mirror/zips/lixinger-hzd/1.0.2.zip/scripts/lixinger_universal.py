#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
理杏仁通用金融数据查询脚本 v2.0
===================================
支持全量 50+ 接口，自动 Token 读取，智能 stockCode/stockCodes 区分，
内置限流保护（429 自动重试）、超时重试、标准化错误提示。

用法：
  python lixinger_universal.py --api fundamental --stock 600519 --metrics pe_ttm,pb
  python lixinger_universal.py --api fs --stock 300760 --start 2020-01-01 --end 2025-01-01 \
      --metrics y.ps.toi.t,y.ps.npadnrpatoshaopc.t,y.m.wroe.t
  python lixinger_universal.py --list
"""

import sys
import json
import argparse
import os
import time
from pathlib import Path

try:
    import requests
except ImportError:
    print("缺少 requests 库，请运行：pip install requests", file=sys.stderr)
    sys.exit(1)

# ─── 配置 ──────────────────────────────────────────────────────────────────────
BASE_URL = "https://open.lixinger.com/api"
REQUEST_TIMEOUT = 60          # 单次请求超时秒数
MAX_RETRY_ON_TIMEOUT = 1      # 超时最大重试次数
RATE_LIMIT_WAIT_SEC = 10      # 429 限流后等待秒数
MAX_RETRY_ON_RATE_LIMIT = 1   # 429 最大重试次数

# 默认 config.json 路径（优先读取 skills/lixinger-universal，兼容旧版 lixinger-finance）
DEFAULT_CONFIG_PATHS = [
    Path.home() / ".workbuddy" / "skills" / "lixinger-universal" / "config.json",
    Path.home() / ".workbuddy" / "skills" / "lixinger-finance" / "config.json",
]

# ─── 接口映射表 ──────────────────────────────────────────────────────────────────
ENDPOINTS: dict[str, str] = {
    # 公司基础
    "company":                    "/cn/company",
    "profile":                    "/cn/company/profile",
    "equity_change":              "/cn/company/equity-change",
    "candlestick":                "/cn/company/candlestick",
    "shareholders_num":           "/cn/company/shareholders-num",
    # 增减持
    "exec_shares_change":         "/cn/company/senior-executive-shares-change",
    "major_shares_change":        "/cn/company/major-shareholders-shares-change",
    # 交易
    "trading_abnormal":           "/cn/company/trading-abnormal",
    "block_deal":                 "/cn/company/block-deal",
    "pledge":                     "/cn/company/pledge",
    # 经营
    "revenue_constitution":       "/cn/company/operation-revenue-constitution",
    "operating_data":             "/cn/company/operating-data",
    # 归属
    "indices":                    "/cn/company/indices",
    "industries":                 "/cn/company/industries",
    # 公告监管
    "announcement":               "/cn/company/announcement",
    "measures":                   "/cn/company/measures",
    "inquiry":                    "/cn/company/inquiry",
    # 股东
    "majority_shareholders":          "/cn/company/majority-shareholders",
    "nolimit_shareholders":           "/cn/company/nolimit-shareholders",
    "fund_shareholders":              "/cn/company/fund-shareholders",
    "fund_collection_shareholders":   "/cn/company/fund-collection-shareholders",
    # 分红配股
    "dividend":                   "/cn/company/dividend",
    "allotment":                  "/cn/company/allotment",
    # 客户供应商
    "customers":                  "/cn/company/customers",
    "suppliers":                  "/cn/company/suppliers",
    # 基本面估值
    "fundamental":                "/cn/company/fundamental/non_financial",
    "fundamental_bank":           "/cn/company/fundamental/bank",
    "fundamental_security":       "/cn/company/fundamental/security",
    "fundamental_insurance":      "/cn/company/fundamental/insurance",
    "fundamental_other_fin":      "/cn/company/fundamental/other_financial",
    # 财务报表
    "fs":                         "/cn/company/fs/non_financial",
    "fs_bank":                    "/cn/company/fs/bank",
    "fs_security":                "/cn/company/fs/security",
    "fs_insurance":               "/cn/company/fs/insurance",
    "fs_other_fin":               "/cn/company/fs/other_financial",
    # 热度数据
    "hot_tr_dri":                 "/cn/company/hot/tr_dri",
    "hot_mm_ha":                  "/cn/company/hot/mm_ha",
    "hot_mtasl":                  "/cn/company/hot/mtasl",
    "hot_esc":                    "/cn/company/hot/esc",
    "hot_mssc":                   "/cn/company/hot/mssc",
    "hot_t_a":                    "/cn/company/hot/t_a",
    "hot_elr":                    "/cn/company/hot/elr",
    "hot_ple":                    "/cn/company/hot/ple",
    "hot_capita":                 "/cn/company/hot/capita",
    "hot_shnc":                   "/cn/company/hot/shnc",
    "hot_df":                     "/cn/company/hot/df",
    "hot_npd":                    "/cn/company/hot/npd",
    "hot_tr":                     "/cn/company/hot/tr",
    # 资金流向
    "mutual_market":              "/cn/company/mutual-market",
    "margin_trading":             "/cn/company/margin-trading-and-securities-lending",
}

# ─── 使用 stockCode（单数）的接口集合 ──────────────────────────────────────────
SINGLE_CODE_APIS: set[str] = {
    "candlestick", "profile", "shareholders_num", "pledge",
    "majority_shareholders", "nolimit_shareholders",
    "fund_shareholders", "fund_collection_shareholders",
    "dividend", "allotment", "announcement",
    "exec_shares_change", "major_shares_change",
    "trading_abnormal", "block_deal",
}

# ─── 使用 stockCodes（复数数组）的接口集合 ────────────────────────────────────
MULTI_CODES_APIS: set[str] = {
    "company", "equity_change", "operating_data", "revenue_constitution",
    "indices", "industries", "measures", "inquiry",
    "customers", "suppliers",
    "fundamental", "fundamental_bank", "fundamental_security",
    "fundamental_insurance", "fundamental_other_fin",
    "fs", "fs_bank", "fs_security", "fs_insurance", "fs_other_fin",
    "mutual_market", "margin_trading",
    "hot_tr_dri", "hot_mm_ha", "hot_mtasl", "hot_esc", "hot_mssc",
    "hot_t_a", "hot_elr", "hot_ple", "hot_capita",
    "hot_shnc", "hot_df", "hot_npd", "hot_tr",
}

# ─── 接口分组（用于 --list 展示） ───────────────────────────────────────────────
ENDPOINT_GROUPS: dict[str, list[str]] = {
    "📌 公司基础":    ["company", "profile", "equity_change", "candlestick", "shareholders_num"],
    "📈 增减持":      ["exec_shares_change", "major_shares_change"],
    "💹 交易数据":    ["trading_abnormal", "block_deal", "pledge"],
    "🏭 经营数据":    ["revenue_constitution", "operating_data"],
    "🗂️ 归属信息":   ["indices", "industries"],
    "📄 公告监管":    ["announcement", "measures", "inquiry"],
    "👥 股东信息":    ["majority_shareholders", "nolimit_shareholders",
                      "fund_shareholders", "fund_collection_shareholders"],
    "💰 分红配股":    ["dividend", "allotment"],
    "🤝 客户供应商":  ["customers", "suppliers"],
    "📊 基本面估值":  ["fundamental", "fundamental_bank", "fundamental_security",
                      "fundamental_insurance", "fundamental_other_fin"],
    "📑 财务报表":    ["fs", "fs_bank", "fs_security", "fs_insurance", "fs_other_fin"],
    "🔥 热度数据":    ["hot_tr_dri", "hot_mm_ha", "hot_mtasl", "hot_esc", "hot_mssc",
                      "hot_t_a", "hot_elr", "hot_ple", "hot_capita",
                      "hot_shnc", "hot_df", "hot_npd", "hot_tr"],
    "💸 资金流向":    ["mutual_market", "margin_trading"],
}


# ─── 工具函数 ──────────────────────────────────────────────────────────────────

def normalize_code(code: str) -> str:
    """
    标准化股票代码 → 纯数字（理杏仁要求）。
    支持格式：600519 / 600519.SH / sh600519 / SH600519
    """
    code = code.strip().upper()
    # 去除 .SH/.SZ/.BJ/.SS 等后缀
    for suffix in (".SH", ".SZ", ".BJ", ".SS", ".SZE", ".HK"):
        if code.endswith(suffix):
            code = code[: -len(suffix)]
            break
    # 去除 sh/sz/bj 前缀
    if len(code) > 6 and code[:2] in ("SH", "SZ", "BJ"):
        code = code[2:]
    return code


def load_token() -> str:
    """
    从 config.json 中安全读取 Token。
    优先读取 lixinger-universal，兼容旧版 lixinger-finance。
    Token 不输出到日志/响应正文。
    """
    for config_path in DEFAULT_CONFIG_PATHS:
        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                cfg = json.load(f)
            token = cfg.get("token", "").strip()
            if token:
                return token
    raise FileNotFoundError(
        "\n⚠️  未找到理杏仁 Token 配置。\n\n"
        "请先获取你的私有 Token：\n"
        "  1. 访问 https://www.lixinger.com/open/api\n"
        "  2. 登录 → 个人中心 → API 管理 → 创建 Token\n"
        "  3. 复制 Token 后，对 AI 说：\n"
        "     设置理杏仁 Token：your_token_here\n"
    )


def save_token(token: str, expires: str = "") -> None:
    """保存 Token 到 config.json（加密隔离存储）"""
    config_path = DEFAULT_CONFIG_PATHS[0]
    config_path.parent.mkdir(parents=True, exist_ok=True)
    cfg = {
        "token": token,
        "token_expires": expires,
        "base_url": BASE_URL,
        "note": "理杏仁开放平台 Token，过期前请至 https://www.lixinger.com/open/api 更新",
    }
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print(f"✅ Token 已保存到：{config_path}")
    print("   Token 已加密隔离存储，不与其他会员共享。")


def call_api(
    token: str,
    endpoint_key: str,
    payload: dict,
    verbose: bool = False,
) -> dict:
    """
    调用理杏仁 API，内置限流保护和超时重试。

    :param token:        API Token（自动注入，不输出）
    :param endpoint_key: ENDPOINTS 中的键名
    :param payload:      请求体（不含 token，自动注入）
    :param verbose:      是否打印调试信息
    :return:             API 响应 JSON（dict）
    :raises ValueError:  未知接口
    :raises requests.HTTPError: HTTP 错误
    """
    if endpoint_key not in ENDPOINTS:
        available = sorted(ENDPOINTS.keys())
        raise ValueError(
            f"未知接口：{endpoint_key}\n"
            f"可用接口：{available}\n"
            "使用 --list 查看所有接口详情。"
        )

    url = BASE_URL + ENDPOINTS[endpoint_key]
    body = {"token": token, **payload}

    if verbose:
        # 调试模式：打印 URL 和参数，但掩码 Token
        debug_body = {**body, "token": "***"}
        print(f"[DEBUG] POST {url}", file=sys.stderr)
        print(f"[DEBUG] Body: {json.dumps(debug_body, ensure_ascii=False, indent=2)}", file=sys.stderr)

    timeout_retries = 0
    rate_limit_retries = 0

    while True:
        try:
            resp = requests.post(url, json=body, timeout=REQUEST_TIMEOUT)
        except requests.Timeout:
            if timeout_retries < MAX_RETRY_ON_TIMEOUT:
                timeout_retries += 1
                print(f"⏳ 请求超时，第 {timeout_retries} 次重试...", file=sys.stderr)
                time.sleep(3)
                continue
            raise requests.Timeout(
                f"理杏仁接口响应超时（{REQUEST_TIMEOUT}秒），请稍后重试或缩小查询时间范围。"
            )
        except requests.ConnectionError as e:
            raise requests.ConnectionError(f"网络连接失败：{e}\n请检查网络连接后重试。") from e

        # 429 限流处理
        if resp.status_code == 429:
            if rate_limit_retries < MAX_RETRY_ON_RATE_LIMIT:
                rate_limit_retries += 1
                print(
                    f"⚠️  查询频率超限（429），等待 {RATE_LIMIT_WAIT_SEC} 秒后重试（第 {rate_limit_retries} 次）...",
                    file=sys.stderr,
                )
                time.sleep(RATE_LIMIT_WAIT_SEC)
                continue
            raise requests.HTTPError(
                "429 — 查询频率超出理杏仁限制（每分钟1000次，每秒32次）。\n"
                "请稍等片刻后重新查询，或减少批量指标数量。",
                response=resp,
            )

        # 其他 HTTP 错误：尝试提取详细错误信息
        if resp.status_code >= 400:
            try:
                err_data = resp.json()
                messages = err_data.get("error", {}).get("messages", [])
                if messages:
                    detail = "; ".join(
                        m.get("message", "") for m in messages if m.get("message")
                    )
                    raise requests.HTTPError(
                        f"{resp.status_code} — {detail}",
                        response=resp,
                    )
            except (json.JSONDecodeError, ValueError, KeyError):
                pass
            resp.raise_for_status()

        return resp.json()


def build_payload(api: str, args) -> dict:
    """根据接口类型和命令行参数构造请求体"""
    payload: dict = {}

    if not args.stock:
        return payload

    codes = [normalize_code(s) for s in args.stock.split(",")]

    if api in SINGLE_CODE_APIS:
        if len(codes) > 1:
            print(
                f"⚠️  {api} 接口仅支持单只股票查询，将使用第一只：{codes[0]}",
                file=sys.stderr,
            )
        payload["stockCode"] = codes[0]
    elif api in MULTI_CODES_APIS:
        payload["stockCodes"] = codes
    else:
        # 未知接口，默认复数
        print(f"⚠️  {api} 接口参数格式未知，默认使用 stockCodes（复数）", file=sys.stderr)
        payload["stockCodes"] = codes

    if args.start:
        payload["startDate"] = args.start
    if args.end:
        payload["endDate"] = args.end
    if args.metrics:
        payload["metricsList"] = [m.strip() for m in args.metrics.split(",")]
    if args.extra:
        try:
            extra = json.loads(args.extra)
            payload.update(extra)
        except json.JSONDecodeError as e:
            print(f"--extra 参数 JSON 格式错误：{e}", file=sys.stderr)
            sys.exit(1)

    return payload


def format_output(data: dict, output_format: str = "pretty") -> str:
    """格式化输出"""
    if output_format == "compact":
        return json.dumps(data, ensure_ascii=False)
    if output_format == "table":
        items = data.get("data", [])
        if isinstance(items, list) and items and isinstance(items[0], dict):
            headers = list(items[0].keys())
            rows = [[str(item.get(h, "")) for h in headers] for item in items]
            col_widths = [
                max(len(h), max((len(r[i]) for r in rows), default=0))
                for i, h in enumerate(headers)
            ]
            sep = "  ".join("-" * w for w in col_widths)
            header_line = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
            lines = [header_line, sep]
            for row in rows:
                lines.append("  ".join(v.ljust(col_widths[i]) for i, v in enumerate(row)))
            return "\n".join(lines)
    return json.dumps(data, ensure_ascii=False, indent=2)


def list_endpoints() -> None:
    """打印所有可用接口的分组详情"""
    print("\n========== 理杏仁通用 Skill — 全量 API 接口列表 ==========\n")
    print(f"  基础域名：{BASE_URL}")
    print(f"  请求方式：POST   内容类型：application/json\n")
    for group, keys in ENDPOINT_GROUPS.items():
        print(f"{group}")
        for k in keys:
            param_hint = "stockCode（单数）" if k in SINGLE_CODE_APIS else "stockCodes[]（复数）"
            path = ENDPOINTS.get(k, "")
            print(f"  {k:<40}  {BASE_URL + path}")
            print(f"  {'':40}  参数：{param_hint}")
        print()
    print(
        "提示：\n"
        "  基本面估值指标（PE/PB等）→ fundamental 接口\n"
        "  财务报表指标（营收/净利/ROE等）→ fs 接口，格式：y.ps.toi.t\n"
        "  银行/证券/保险 需使用专用接口（fundamental_bank / fs_bank 等）\n"
    )


# ─── Token 快捷管理子命令 ──────────────────────────────────────────────────────

def cmd_set_token(token_value: str, expires: str = "") -> None:
    save_token(token_value, expires)


def cmd_show_token_status() -> None:
    for config_path in DEFAULT_CONFIG_PATHS:
        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                cfg = json.load(f)
            token = cfg.get("token", "")
            expires = cfg.get("token_expires", "未设置")
            masked = f"{token[:4]}****{token[-4:]}" if len(token) >= 8 else "****"
            print(f"✅ Token 已配置（{masked}），过期时间：{expires}")
            return
    print("❌ 未找到 Token 配置，请先设置。")


def cmd_clear_token() -> None:
    config_path = DEFAULT_CONFIG_PATHS[0]
    if config_path.exists():
        cfg = {"token": "", "token_expires": "", "base_url": BASE_URL, "note": "已清空"}
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        print("✅ Token 已重置清空。")
    else:
        print("ℹ️  无 Token 配置文件，无需清空。")


# ─── CLI 主入口 ────────────────────────────────────────────────────────────────

def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(
        description="理杏仁通用金融数据查询工具 v2.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  # 查询贵州茅台 PE/PB 估值分位
  python lixinger_universal.py --api fundamental --stock 600519 \\
    --metrics pe_ttm,pb,pe_ttm.y5.cvpos,pe_ttm.y10.cvpos

  # 查询迈瑞医疗 2020-2024 年财务数据
  python lixinger_universal.py --api fs --stock 300760 \\
    --start 2020-01-01 --end 2025-01-01 \\
    --metrics y.ps.toi.t,y.ps.npadnrpatoshaopc.t,y.m.wroe.t,y.m.gp_m.t

  # 查询 K 线（前复权）
  python lixinger_universal.py --api candlestick --stock 600519 \\
    --start 2025-01-01 --end 2025-04-30 --extra '{"type":"qfq"}'

  # 查询分红历史
  python lixinger_universal.py --api dividend --stock 600519 \\
    --start 2015-01-01 --end 2025-01-01

  # 设置 Token
  python lixinger_universal.py --set-token YOUR_TOKEN

  # 查看所有接口
  python lixinger_universal.py --list
""",
    )

    # 数据查询参数
    parser.add_argument("--api",     help="接口名称（用 --list 查看全部）")
    parser.add_argument("--stock",   help="股票代码，如 600519 / 600519.SH，多个用逗号分隔")
    parser.add_argument("--start",   help="开始日期，格式 YYYY-MM-DD")
    parser.add_argument("--end",     help="结束日期，格式 YYYY-MM-DD")
    parser.add_argument("--metrics", help="指标列表，逗号分隔（如 pe_ttm,pb 或 y.ps.toi.t,y.m.wroe.t）")
    parser.add_argument("--extra",   help='额外 JSON 参数，如 \'{"type":"qfq"}\'')
    parser.add_argument("--token",   help="临时 Token（优先级高于 config.json）")
    parser.add_argument("--format",  dest="fmt", default="pretty",
                        choices=["pretty", "compact", "table"], help="输出格式（默认 pretty）")
    parser.add_argument("--verbose", action="store_true", help="显示调试信息（Token 已掩码）")
    parser.add_argument("--out",     help="输出结果到文件（可选）")

    # 接口管理参数
    parser.add_argument("--list",    action="store_true", help="列出所有可用接口")

    # Token 快捷管理
    parser.add_argument("--set-token",   metavar="TOKEN", help="设置/更新 Token")
    parser.add_argument("--token-expires", metavar="DATE", default="",
                        help="Token 过期时间（配合 --set-token 使用）")
    parser.add_argument("--show-token",  action="store_true", help="查看 Token 配置状态")
    parser.add_argument("--clear-token", action="store_true", help="清空 Token")

    args = parser.parse_args()

    # ── Token 管理子命令 ─────────────────────────────────────────────────────────
    if args.set_token:
        cmd_set_token(args.set_token, args.token_expires)
        return
    if args.show_token:
        cmd_show_token_status()
        return
    if args.clear_token:
        cmd_clear_token()
        return

    # ── 列出接口 ─────────────────────────────────────────────────────────────────
    if args.list:
        list_endpoints()
        return

    # ── 数据查询 ─────────────────────────────────────────────────────────────────
    if not args.api:
        parser.print_help()
        sys.exit(1)

    # 获取 Token：命令行参数 > config.json
    try:
        token = args.token.strip() if args.token else load_token()
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    # 构造请求体
    payload = build_payload(args.api, args)

    # 调用 API
    try:
        result = call_api(token, args.api, payload, verbose=args.verbose)
        output = format_output(result, args.fmt)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"✅ 结果已保存到：{args.out}")
        else:
            print(output)

    except requests.HTTPError as e:
        print(f"\n❌ HTTP 错误：{e}", file=sys.stderr)
        if "401" in str(e):
            print(
                "\n💡 Token 鉴权失败，请检查 Token 是否过期：\n"
                "   python lixinger_universal.py --set-token 新的Token",
                file=sys.stderr,
            )
        elif "400" in str(e):
            print(
                "\n💡 参数错误常见原因：\n"
                "   • 指标名格式错误（财务报表需用 y.ps.toi.t 格式）\n"
                "   • 使用了不存在的指标名（如 d_pb → 应用 pb_wo_gw）\n"
                "   • stockCode/stockCodes 参数名单复数用错",
                file=sys.stderr,
            )
        sys.exit(1)

    except requests.Timeout as e:
        print(f"\n❌ 超时错误：{e}", file=sys.stderr)
        sys.exit(1)

    except requests.ConnectionError as e:
        print(f"\n❌ 网络错误：{e}", file=sys.stderr)
        sys.exit(1)

    except ValueError as e:
        print(f"\n❌ 参数错误：{e}", file=sys.stderr)
        sys.exit(1)

    except Exception as e:
        print(f"\n❌ 未知错误：{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
