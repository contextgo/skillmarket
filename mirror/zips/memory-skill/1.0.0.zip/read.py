#!/usr/bin/env python3
"""
记忆读取脚本 (read.py)

读取指定记忆文件的完整内容。

用法:
    python read.py memory/Memory/project-a.md
    python read.py memory/Feedback/git-fix.md --format yaml
    python read.py memory/Daily/2026-04-14.md
"""

import os
import re
import json
import argparse
from pathlib import Path
from typing import Optional


def parse_frontmatter(content: str) -> dict:
    """解析 Markdown 文件的 YAML 头部"""
    pattern = r'^---\s*\n(.*?)\n---'
    match = re.match(pattern, content, re.DOTALL)
    
    if match:
        yaml_str = match.group(1)
        result = {}
        for line in yaml_str.split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()
                
                # 处理列表
                if value.startswith('[') and value.endswith(']'):
                    value = [v.strip().strip('"').strip("'") 
                             for v in value[1:-1].split(',')]
                # 移除引号
                elif value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]
                
                result[key] = value
        return result
    return {}


def extract_content(content: str) -> str:
    """提取 YAML 头部后的正文内容"""
    pattern = r'^---\s*\n.*?\n---\s*\n(.*)$'
    match = re.match(pattern, content, re.DOTALL)
    return match.group(1).strip() if match else content.strip()


def extract_full(content: str) -> str:
    """提取完整内容（YAML + 正文）"""
    pattern = r'^---\s*\n.*?\n---\s*\n(.*)$'
    match = re.match(pattern, content, re.DOTALL)
    return content.strip() if match else content.strip()


def read_memory(file_path: str, 
                format: str = 'content',
                base_path: str = 'memory') -> dict:
    """读取记忆文件
    
    Args:
        file_path: 文件路径（可以是相对路径或绝对路径）
        format: 返回格式
            - 'yaml': 只返回 YAML 头部
            - 'content': 只返回正文
            - 'full': YAML + 正文
            - 'preview': YAML + 前500字预览
        base_path: 基础路径（相对路径时使用）
    
    Returns:
        dict: 包含路径、yaml、content、full 等字段
    """
    # 处理文件路径
    path = Path(file_path)
    
    # 如果是相对路径，尝试在 base_path 下查找
    if not path.is_absolute():
        full_path = Path(base_path) / path
        if not full_path.exists():
            # 尝试直接作为绝对路径
            full_path = Path(file_path)
    else:
        full_path = path
    
    if not full_path.exists():
        return {
            'error': f'文件不存在: {full_path}',
            'path': str(path)
        }
    
    try:
        content = full_path.read_text(encoding='utf-8')
        yaml_meta = parse_frontmatter(content)
        text_content = extract_content(content)
        full_content = extract_full(content)
        
        result = {
            'path': str(path),
            'full_path': str(full_path),
            'yaml': yaml_meta,
            'content': text_content,
            'full': full_content,
            'preview': text_content[:500] + '...' if len(text_content) > 500 else text_content
        }
        
        # 根据 format 返回不同内容
        if format == 'yaml':
            return {'path': result['path'], 'yaml': result['yaml']}
        elif format == 'content':
            return {'path': result['path'], 'content': result['content']}
        elif format == 'preview':
            return {'path': result['path'], 'yaml': result['yaml'], 'preview': result['preview']}
        else:  # full
            return result
            
    except Exception as e:
        return {
            'error': f'读取失败: {str(e)}',
            'path': str(path)
        }


def format_output(data: dict, format_type: str = 'markdown') -> str:
    """格式化输出"""
    if 'error' in data:
        return f"❌ {data['error']}"
    
    if format_type == 'json':
        return json.dumps(data, ensure_ascii=False, indent=2)
    
    # Markdown 格式
    output = []
    
    if 'yaml' in data and data['yaml']:
        yaml = data['yaml']
        output.append("--- YAML 头部 ---")
        for key, value in yaml.items():
            output.append(f"- **{key}**: {value}")
        output.append("")
    
    if 'preview' in data:
        output.append("--- 内容预览 ---")
        output.append(data['preview'])
    elif 'content' in data:
        output.append("--- 内容 ---")
        output.append(data['content'])
    
    return "\n".join(output)


def list_directory(dir_path: str = 'memory', show_all: bool = False) -> dict:
    """列出目录下的所有记忆文件"""
    base_path = Path(dir_path)
    
    if not base_path.exists():
        return {'error': f'目录不存在: {dir_path}'}
    
    result = {
        'path': dir_path,
        'directories': {},
        'files': []
    }
    
    for item in sorted(base_path.iterdir()):
        if item.is_dir():
            files = list(item.glob('*.md'))
            result['directories'][item.name] = {
                'count': len(files),
                'files': [{'name': f.stem, 'path': str(f.relative_to(base_path))} 
                          for f in files[:5]]  # 每个目录最多显示5个
            }
        elif item.suffix == '.md':
            result['files'].append({
                'name': item.stem,
                'path': str(item.relative_to(base_path))
            })
    
    return result


def main():
    parser = argparse.ArgumentParser(description='记忆文件读取')
    parser.add_argument('file_path', nargs='?', help='文件路径')
    parser.add_argument('--path', default='memory', help='基础路径')
    parser.add_argument('--format', choices=['yaml', 'content', 'preview', 'full'], 
                        default='full', help='返回格式')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--list', action='store_true', help='列出目录内容')
    
    args = parser.parse_args()
    
    if args.list or not args.file_path:
        # 列出目录
        result = list_directory(args.path)
        if 'error' in result:
            print(result['error'])
            return
        
        print(f"[DIR] {result['path']}\n")
        
        for dir_name, dir_info in result['directories'].items():
            print(f"[DIR] {dir_name}/ ({dir_info['count']} files)")
            for f in dir_info['files']:
                print(f"   - {f['name']}")
            if dir_info['count'] > 5:
                print(f"   ... and {dir_info['count'] - 5} more")
            print()
        
        if result['files']:
            print(f"[FILE] Root files:")
            for f in result['files']:
                print(f"   - {f['name']}")
    else:
        # 读取文件
        data = read_memory(args.file_path, format=args.format, base_path=args.path)
        
        if args.json:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        else:
            print(format_output(data, format_type='markdown'))


if __name__ == '__main__':
    main()
