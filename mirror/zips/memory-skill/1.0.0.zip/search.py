#!/usr/bin/env python3
"""
记忆搜索脚本 (search.py)

搜索 memory/ 目录下的记忆文件，支持关键词匹配和 Qwen3-Rerank 精排。

用法:
    python search.py "关键词"
    python search.py "关键词" --tags project --importance 4
    python search.py "关键词" --no-rerank
    python search.py "关键词" --path memory/ --json
"""

import os
import re
import json
import argparse
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass


# ==================== 配置加载 ====================

def load_config():
    """从 .env 文件加载配置"""
    config = {
        "RERANK_ENABLED": "false",
        "RERANK_MODEL": "qwen3-rerank",
        "RERANK_API_URL": "https://dashscope.aliyuncs.com/api/v1/services/rerank/text-rerank/text-rerank",
        "DASHSCOPE_API_KEY": "",
        "DEFAULT_MEMORY_PATH": "memory",
        "DEFAULT_LIMIT": "10",
        "ENABLE_RERANK": "true",
        "RERANK_TOP_N": "5"
    }

    env_path = Path(__file__).parent / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").split("\n"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                config[key.strip()] = value.strip()

    return config


# ==================== 数据结构 ====================

@dataclass
class MemoryFile:
    """记忆文件数据结构"""
    path: str
    full_path: str
    name: str
    description: str
    tags: List[str]
    importance: int
    created: str
    updated: str
    source: str
    score: float = 0.0


# ==================== YAML 解析 ====================

def parse_frontmatter(content: str) -> dict:
    """解析 Markdown 文件的 YAML 头部"""
    pattern = r'^---\s*\n(.*?)\n---'
    match = re.match(pattern, content, re.DOTALL)

    if match:
        yaml_str = match.group(1)
        result = {}
        for line in yaml_str.split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()

                # 处理列表
                if value.startswith('[') and value.endswith(']'):
                    value = [v.strip().strip('"').strip("'")
                             for v in value[1:-1].split(',')]
                # 移除引号
                elif value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]

                result[key] = value
        return result
    return {}


def extract_content(content: str) -> str:
    """提取 YAML 头部后的正文内容"""
    pattern = r'^---\s*\n.*?\n---\s*\n(.*)$'
    match = re.match(pattern, content, re.DOTALL)
    return match.group(1) if match else content


# ==================== 评分逻辑 ====================

def calculate_score(meta: dict, content: str, query: str) -> float:
    """计算文件与查询的相关性得分"""
    query_lower = query.lower()
    score = 0.0

    # name 匹配 (权重 1.0)
    name = meta.get('name', '').lower()
    if query_lower in name:
        score += 1.0

    # description 匹配 (权重 0.8)
    desc = meta.get('description', '').lower()
    if query_lower in desc:
        score += 0.8

    # tags 匹配 (权重 0.6)
    tags = meta.get('tags', [])
    if isinstance(tags, list):
        for tag in tags:
            if query_lower in tag.lower():
                score += 0.6
                break

    # 正文内容匹配 (权重 0.4)
    content_lower = content.lower()
    count = content_lower.count(query_lower)
    if count > 0:
        score += 0.4 * min(count, 5)  # 最多累加5次

    # 重要性加成
    importance = int(meta.get('importance', 3))
    score += importance * 0.1

    return round(score, 2)


# ==================== 目录权重 ====================

DIRECTORY_WEIGHTS = {
    "user": 1.5,        # 用户偏好，始终优先
    "Feedback": 1.4,   # 避免重复犯错
    "Memory": 1.2,     # 主题记忆
    "Daily": 1.0,      # 每日记录
    "resources": 0.8   # 外部参考
}


def get_directory_weight(path: str) -> float:
    """获取目录权重"""
    for dir_name, weight in DIRECTORY_WEIGHTS.items():
        if f"/{dir_name}/" in path or path.startswith(f"{dir_name}/"):
            return weight
    return 1.0


def apply_directory_weight(score: float, path: str) -> float:
    """应用目录权重"""
    return score * get_directory_weight(path)


# ==================== 搜索逻辑 ====================

def search_files(directory: str, query: str,
                 tags: Optional[list] = None,
                 importance: Optional[int] = None,
                 limit: int = 10) -> List[MemoryFile]:
    """搜索目录下的记忆文件"""
    results = []
    base_path = Path(directory)

    if not base_path.exists():
        return []

    # 遍历所有 .md 文件
    for file_path in base_path.rglob('*.md'):
        try:
            content = file_path.read_text(encoding='utf-8')
            meta = parse_frontmatter(content)

            # 按 tags 筛选
            if tags:
                file_tags = meta.get('tags', [])
                if isinstance(file_tags, str):
                    file_tags = [file_tags]
                if not any(tag.lower() in t.lower() for tag in tags for t in file_tags):
                    continue

            # 按重要性筛选
            if importance:
                file_importance = int(meta.get('importance', 0))
                if file_importance < importance:
                    continue

            # 计算相关性得分
            raw_score = calculate_score(meta, content, query)

            # 应用目录权重
            try:
                rel_path = file_path.relative_to(base_path)
            except ValueError:
                rel_path = file_path

            score = apply_directory_weight(raw_score, str(rel_path))

            if raw_score > 0:  # 只要有匹配就加入
                results.append(MemoryFile(
                    path=str(rel_path),
                    full_path=str(file_path),
                    name=meta.get('name', file_path.stem),
                    description=meta.get('description', ''),
                    tags=meta.get('tags', []),
                    importance=int(meta.get('importance', 3)),
                    created=meta.get('created', ''),
                    updated=meta.get('updated', ''),
                    source=meta.get('source', 'auto'),
                    score=score
                ))
        except Exception as e:
            continue

    # 按得分排序
    results.sort(key=lambda x: x.score, reverse=True)

    return results[:limit]


# ==================== Rerank 功能 ====================

def rerank_with_qwen3(query: str, results: List[MemoryFile],
                       config: dict, top_n: int = 5) -> List[MemoryFile]:
    """使用 Qwen3-Rerank 精排

    只上传 YAML 内容（name + description + tags）
    """
    api_key = config.get("DASHSCOPE_API_KEY", "")
    if not api_key or api_key == "your_api_key_here":
        print("⚠️ 未配置 DASHSCOPE_API_KEY，跳过 Rerank")
        return results[:top_n]

    try:
        import requests

        # 构建 YAML 内容（只上传元数据）
        documents = [
            f"标题: {r.name}\n描述: {r.description}\n标签: {', '.join(r.tags)}"
            for r in results
        ]

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": config.get("RERANK_MODEL", "qwen3-rerank"),
            "documents": documents,
            "query": query,
            "top_n": top_n,
            "return_documents": False
        }

        response = requests.post(
            config.get("RERANK_API_URL", ""),
            headers=headers,
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            data = response.json()
            reranked = []

            for item in data.get("output", {}).get("results", []):
                idx = item.get("index", 0)
                if idx < len(results):
                    reranked_file = results[idx]
                    reranked_file.score = item.get("relevance_score", 0)
                    reranked.append(reranked_file)

            return reranked
        else:
            print(f"⚠️ Rerank API 返回错误: {response.status_code}")
            return results[:top_n]

    except ImportError:
        print("⚠️ 需要安装 requests: pip install requests")
        return results[:top_n]
    except Exception as e:
        print(f"⚠️ Rerank 调用失败: {e}")
        return results[:top_n]


# ==================== 格式化输出 ====================

def format_results(results: List[MemoryFile], show_path: bool = False) -> str:
    """格式化搜索结果为可读文本"""
    if not results:
        return "未找到匹配的记录"

    output = []
    for i, item in enumerate(results, 1):
        stars = "★" * item.importance + "☆" * (5 - item.importance)
        tags_str = ", ".join(item.tags) if item.tags else "-"

        line = f"{i}. {item.name} [{stars}]"
        if show_path:
            line += f"\n   路径: {item.path}"
        line += f"\n   描述: {item.description}"
        line += f"\n   标签: {tags_str}"
        line += f"\n   更新: {item.updated} | 得分: {item.score:.2f}"
        output.append(line)

    return "\n\n".join(output)


def results_to_dict(results: List[MemoryFile]) -> List[Dict[str, Any]]:
    """将结果转换为字典列表"""
    return [
        {
            "path": r.path,
            "full_path": r.full_path,
            "name": r.name,
            "description": r.description,
            "tags": r.tags,
            "importance": r.importance,
            "created": r.created,
            "updated": r.updated,
            "source": r.source,
            "score": r.score
        }
        for r in results
    ]


# ==================== 主函数 ====================

def main():
    parser = argparse.ArgumentParser(description='记忆文件搜索')
    parser.add_argument('query', help='搜索关键词')
    parser.add_argument('--path', default=None, help='记忆目录路径')
    parser.add_argument('--tags', nargs='+', help='按标签筛选')
    parser.add_argument('--importance', type=int, help='最低重要程度 (1-5)')
    parser.add_argument('--limit', type=int, default=None, help='初筛返回数量')
    parser.add_argument('--top-n', type=int, default=None, help='最终返回数量')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--show-path', action='store_true', help='显示文件路径')
    parser.add_argument('--no-rerank', action='store_true', help='禁用 Rerank')

    args = parser.parse_args()

    # 加载配置
    config = load_config()

    # 确定路径和参数
    search_path = args.path or config.get("DEFAULT_MEMORY_PATH", "memory")
    search_limit = args.limit or int(config.get("DEFAULT_LIMIT", "20"))
    top_n = args.top_n or int(config.get("RERANK_TOP_N", "5"))
    enable_rerank = not args.no_rerank and config.get("RERANK_ENABLED", "false").lower() == "true"

    # 初筛搜索
    results = search_files(
        directory=search_path,
        query=args.query,
        tags=args.tags,
        importance=args.importance,
        limit=search_limit
    )

    # Rerank 精排
    if enable_rerank and results:
        results = rerank_with_qwen3(args.query, results, config, top_n)
    else:
        results = results[:top_n]

    # 输出结果
    if args.json:
        print(json.dumps({
            'query': args.query,
            'path': search_path,
            'total': len(results),
            'reranked': enable_rerank,
            'results': results_to_dict(results)
        }, ensure_ascii=False, indent=2))
    else:
        rerank_note = "（Rerank 精排）" if enable_rerank else ""
        output = format_results(results, show_path=args.show_path)
        print(f"搜索「{args.query}」{rerank_note}，找到 {len(results)} 条结果:\n")
        print(output)


if __name__ == '__main__':
    main()
