# 记忆技能 (Memory Skill)

让 AI Agent 拥有长期记忆能力的技能系统，参考 OpenViking 的文件系统范式设计。

## 安装

### 方式一：手动安装（推荐）

```bash
# 克隆仓库
git clone https://gitee.com/ezemeti/memory-skill.git

# 复制到技能目录
cp -r memory-skill ~/.workbuddy/skills/memory

# 配置
cp ~/.workbuddy/skills/memory/.env.example ~/.workbuddy/skills/memory/.env
# 编辑 .env 填入你的 API Key
```

### 方式二：直接下载

```bash
# 下载 ZIP
curl -L https://gitee.com/ezemeti/memory-skill/repository/archive/master.zip -o memory-skill.zip
unzip memory-skill.zip
mv memory-skill-master ~/.workbuddy/skills/memory
```

## 核心原则

1. **记忆必须存放在工作区域** - 所有记忆文件在 `{workspace}/.workbuddy/memory/` 目录
2. **调用脚本必须传递路径** - 必须用 `--path` 参数指定记忆目录的绝对路径
3. **配置缺失需询问用户** - `.env` 中 `DEFAULT_MEMORY_PATH` 或 `RERANK_MODEL` 为空时询问
4. **写入前必须询问** - 写入记忆前必须先询问用户意见，获得确认后再写入

## 目录结构

```
memory/
├── resources/     # AI 搜索调研产生的外部参考
├── user/          # 用户偏好
├── Memory/        # 主题记忆
├── Daily/         # 每日记录 (YYYY-MM-DD.md)
└── Feedback/      # 用户反馈与纠正
```

## 使用方法

### 搜索记忆

```bash
python search.py "关键词" --path "{workspace}/.workbuddy/memory"
```

### 读取记忆

```bash
python read.py "{full_path}"
```

### 写入/更新/删除

使用文件工具直接操作：
- `write_to_file` - 新建记忆
- `replace_in_file` - 更新记忆
- `delete_file` - 删除记忆

## YAML 头部格式

```yaml
---
name: "标题"
description: "一句话描述"
tags: ["标签1", "标签2"]
importance: 3
created: "2026-04-15"
updated: "2026-04-15"
source: "auto|daily|search|feedback"
---

## 内容

- 要点1
- 要点2
```

## 配置

编辑 `.env` 文件配置 Rerank 功能：

```env
RERANK_ENABLED=false
RERANK_MODEL=qwen3-rerank
DASHSCOPE_API_KEY=your_api_key
```

## License

MIT
