---
name: "记忆技能"
description: "让 AI Agent 拥有长期记忆能力的技能系统。支持：用户偏好记忆、项目背景记录、错误教训积累、决策历史追踪、每日会话摘要、外部调研资料归档。基于文件系统存储，支持关键词检索、Qwen3-Rerank 精排、YAML 元数据管理。记忆存放在本地工作区 .workbuddy/memory/ 目录，隐私可控，可读可编辑。"
trigger:
  - 记忆
  - memory
  - 记住
  - 记录
  - 长期记忆
  - 记忆搜索
  - 用户偏好
  - 项目背景
  - 错误教训
---

# 记忆技能 (Memory Skill)

让 AI Agent 拥有长期记忆能力的技能系统，参考 OpenViking 的文件系统范式设计。

## 核心原则

1. **记忆必须存放在工作区域** - 所有记忆文件必须在当前 workspace 的 `.workbuddy/memory/` 目录下
2. **调用脚本必须传递路径** - 所有脚本调用必须通过 `--path` 参数指定记忆目录的绝对路径
3. **配置缺失需询问用户** - 如果 `.env` 中 `DEFAULT_MEMORY_PATH` 或 `RERANK_MODEL` 为空，必须询问用户

## viking:// 目录结构

```
memory/
├── resources/                    # AI 搜索调研产生的外部参考
│   └── {topic}_research.md      # 调研结果
├── user/                        # 用户信息
│   └── preferences.md           # 用户偏好
├── Memory/                       # 主题记忆
│   └── {topic}.md               # 主题记忆文件
├── Daily/                        # 每日记录
│   └── {YYYY-MM-DD}.md         # 每日会话摘要
└── Feedback/                     # 用户反馈与纠正
    └── {tool-name|topic|correction-id}.md  # 一事一档
```

## YAML 头部格式

每个记忆文件必须包含 YAML 头部：

```yaml
---
name: "标题"
description: "一句话描述"
tags: ["标签1", "标签2"]
importance: 3
created: "2026-04-14"
updated: "2026-04-14"
source: "auto|daily|search|feedback"
---
```

### 字段说明

| 字段 | 必须 | 说明 |
|------|------|------|
| name | 是 | 文件标题 |
| description | 是 | 一句话描述 |
| tags | 是 | 标签数组 |
| importance | 是 | 重要程度 1-5 |
| created | 是 | 创建时间 YYYY-MM-DD |
| updated | 是 | 更新时间 YYYY-MM-DD |
| source | 是 | 来源 |

### 预定义 Tags

**来源标签：**
- `auto` - 自动生成
- `daily` - 每日摘要
- `search` - 搜索调研
- `feedback` - 用户反馈

**类型标签：**
- `preference` - 用户偏好
- `decision` - 决策记录
- `error` - 错误教训
- `best-practice` - 最佳实践
- `project` - 项目相关

## 写入规则

### 何时写入记忆

1. **对话结束时** → 写入 `Daily/{日期}.md`
2. **发现用户偏好** → 写入 `user/preferences.md`
3. **完成重要任务/决策** → 写入 `Memory/{topic}.md`
4. **AI 搜索调研后** → 写入 `resources/{topic}_research.md`
5. **用户纠正错误** → 写入 `Feedback/{correction-id}.md`

### 写入前必须询问

**重要：写入记忆前必须先询问用户意见，获得确认后再写入。**

询问模板：
```
是否需要将以下内容添加到记忆？
- 文件位置：xxx
- 内容摘要：xxx
[确认/取消]
```

### 写入格式

```yaml
---
name: "标题"
description: "一句话描述"
tags: ["标签"]
importance: 3
created: "2026-04-14"
updated: "2026-04-14"
source: "auto"
---

## 关键内容

- 要点1
- 要点2
```

## 工具操作

所有记忆操作直接使用文件工具，无需额外脚本：

| 操作 | 工具 | 说明 |
|------|------|------|
| 搜索 | `search.py` | 关键词检索 |
| 读取 | `read.py` | 查看完整内容 |
| 写入 | `write_to_file` | 新建记忆文件 |
| 更新 | `replace_in_file` | 修改已有记忆 |
| 删除 | `delete_file` | 删除不需要的记忆 |

**重要：所有脚本调用必须传递 `--path` 参数指定记忆目录的绝对路径**

## 检索规则

### 调用流程

**重要：所有脚本调用必须传递 `--path` 参数指定记忆目录的绝对路径**

```
1. 使用 search.py 搜索相关记忆
   python search.py "关键词" --path "{workspace}/.workbuddy/memory"
   
2. 查看返回的列表和预览
3. 使用 read.py 读取完整内容
   python read.py "{full_path}"
```

### 检索优先级

1. `user/preferences.md` - 用户偏好，始终优先
2. `Feedback/` - 避免重复犯错
3. `Memory/` - 主题记忆
4. `Daily/` - 近期记录
5. `resources/` - 外部参考

### 注意事项

- 按需加载，不要一次性加载所有记忆
- 优先读取高重要性的记忆
- Feedback 目录的文件权重更高（避免重复犯错）

## 目录用途详解

### resources/ - 外部参考

AI 搜索调研产生的信息：
- 搜索结果整理
- 行业知识总结
- 技术调研报告

### user/ - 用户信息

用户偏好和基本信息：
- 沟通风格
- 工作习惯
- 项目偏好

### Memory/ - 主题记忆

按主题组织的长期记忆：
- 项目进展
- 技术方案
- 经验总结

### Daily/ - 每日记录

每日会话摘要：
- 当天关键决策
- 待办事项
- 重要发现

### Feedback/ - 用户反馈

用户纠正和错误教训：
- 工具使用纠正
- 错误做法记录
- 最佳实践确认

## 注意事项

1. **一事一档** - 每个文件聚焦一个主题
2. **YAML 头部必须完整** - 方便 AI 解析和检索
3. **按需加载** - 只读取相关的记忆文件
4. **保持简洁** - 避免冗长，突出关键信息
5. **必须传递路径** - 调用脚本时必须通过 `--path` 指定记忆目录，不使用默认路径
