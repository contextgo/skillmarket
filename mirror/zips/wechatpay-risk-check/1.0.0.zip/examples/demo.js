const WechatPay = require('../lib/wechatpay');

/**
 * 微信支付服务商集成示例
 * 演示：事前风控、事中交易、事后结算全流程
 */

// 初始化配置
const wp = new WechatPay({
  appId: 'wx8888888888888888',
  mchId: '1900000109',
  apiKey: 'YOUR_API_KEY',
  appSecret: 'YOUR_APP_SECRET',
  certPath: './cert/apiclient_cert.pem',
  certKeyPath: './cert/apiclient_key.pem',
  notifyUrl: 'https://your-domain.com/wechat/notify',
  isSandbox: false
});

/**
 * 示例1：事前 - 商户风险核查
 */
async function demoPreRisk() {
  console.log('=== 事前风控 - 商户风险核查 ===\n');
  
  try {
    // 场景1：仅核查身份证信息
    const result1 = await wp.preRisk.checkIdCardRisk(
      'RSA_ENCRYPTED_ID_CARD',  // RSA加密后的身份证号
      'RSA_ENCRYPTED_NAME'       // RSA加密后的姓名
    );
    
    console.log('风险核查结果:', result1);
    console.log('风险级别:', result1.risk_level);
    console.log('风险描述:', result1.risk_level_desc);
    
    // 解析风险级别
    const riskInfo = wp.preRisk.parseRiskLevel(result1.risk_level);
    console.log('建议操作:', riskInfo.action);
    
    // 场景2：完整信息核查
    const result2 = await wp.preRisk.queryMchRisk({
      certificates_number: 'RSA_ENCRYPTED_ID_CARD',
      certificates_name: 'RSA_ENCRYPTED_NAME',
      settlement_card_no: 'RSA_ENCRYPTED_CARD_NO',
      settlement_card_name: 'RSA_ENCRYPTED_CARD_NAME',
      settlement_card_bank: '招商银行科技园支行',
      business_license_number: 'RSA_ENCRYPTED_LICENSE',
      company_name: '测试科技有限公司',
      store_address: '深圳市南山区深南大道10000号',
      store_longitude: '22.5461478801',
      store_latitude: '113.9410519639'
    });
    
    console.log('\n完整核查结果:', result2);
    
  } catch (error) {
    console.error('风控核查失败:', error.message);
  }
}

/**
 * 示例2：事中 - 创建支付订单
 */
async function demoCreateOrder() {
  console.log('\n=== 事中交易 - 创建支付订单 ===\n');
  
  const orderNo = `ORDER${Date.now()}`;
  
  try {
    // JSAPI支付（小程序/H5）
    const order = await wp.trade.createJsapiOrder({
      body: '测试商品-商品描述',
      out_trade_no: orderNo,
      total_fee: 1,  // 1分钱
      spbill_create_ip: '127.0.0.1',
      sub_openid: 'oUpF8uMuAJO_M2pxb1Q9zNjWeS6o',
      attach: '自定义数据'
    });
    
    console.log('订单创建成功!');
    console.log('预支付ID:', order.prepay_id);
    console.log('小程序调起参数:', JSON.stringify(order.jsapi_params, null, 2));
    
    // 保存订单号供后续查询使用
    return orderNo;
    
  } catch (error) {
    console.error('创建订单失败:', error.message);
    throw error;
  }
}

/**
 * 示例3：事中 - 查询订单
 */
async function demoQueryOrder(outTradeNo) {
  console.log('\n=== 事中交易 - 查询订单 ===\n');
  
  try {
    const order = await wp.trade.queryOrder({
      out_trade_no: outTradeNo
    });
    
    console.log('订单信息:');
    console.log('  订单号:', order.out_trade_no);
    console.log('  交易状态:', order.trade_state);
    console.log('  交易金额:', order.total_fee, '分');
    console.log('  微信订单号:', order.transaction_id || '未支付');
    
    // 交易状态说明
    const stateDesc = {
      'SUCCESS': '支付成功',
      'REFUND': '转入退款',
      'NOTPAY': '未支付',
      'CLOSED': '已关闭',
      'REVOKED': '已撤销',
      'USERPAYING': '用户支付中',
      'PAYERROR': '支付失败'
    };
    console.log('  状态说明:', stateDesc[order.trade_state] || '未知状态');
    
    return order;
    
  } catch (error) {
    console.error('查询订单失败:', error.message);
    throw error;
  }
}

/**
 * 示例4：事中 - 申请退款
 */
async function demoRefund(outTradeNo) {
  console.log('\n=== 事中交易 - 申请退款 ===\n');
  
  const refundNo = `REFUND${Date.now()}`;
  
  try {
    const refund = await wp.trade.applyRefund({
      out_trade_no: outTradeNo,
      out_refund_no: refundNo,
      total_fee: 1,
      refund_fee: 1,
      refund_desc: '用户申请退款'
    });
    
    console.log('退款申请成功!');
    console.log('  退款单号:', refund.out_refund_no);
    console.log('  微信退款单号:', refund.refund_id);
    console.log('  退款状态:', refund.refund_status);
    
  } catch (error) {
    console.error('退款失败:', error.message);
  }
}

/**
 * 示例5：事后 - 查询余额
 */
async function demoGetBalance() {
  console.log('\n=== 事后结算 - 查询余额 ===\n');
  
  try {
    const balance = await wp.settlement.getBalance();
    
    console.log('账户余额:');
    console.log('  可用余额:', balance.available_balance, '分');
    console.log('  不可用余额:', balance.unavailable_balance, '分');
    console.log('  待结算金额:', balance.pending_balance || 0, '分');
    
  } catch (error) {
    console.error('查询余额失败:', error.message);
  }
}

/**
 * 示例6：事后 - 下载对账单
 */
async function demoDownloadBill() {
  console.log('\n=== 事后结算 - 下载对账单 ===\n');
  
  try {
    // 下载前一天的账单
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const billDate = yesterday.toISOString().slice(0, 10).replace(/-/g, '');
    
    const bill = await wp.settlement.getBillDownloadUrl({
      bill_date: billDate,
      bill_type: 'ALL'  // ALL: 所有账单, SUCCESS: 成功账单, REFUND: 退款账单
    });
    
    console.log('账单下载地址:', bill.download_url);
    console.log('账单日期:', billDate);
    
  } catch (error) {
    console.error('下载账单失败:', error.message);
  }
}

/**
 * 示例7：回调通知处理
 */
function handleNotify(xmlData) {
  console.log('\n=== 回调通知处理 ===\n');
  
  // 解析回调通知
  wp.utils.parseXML(xmlData).then(notify => {
    console.log('收到回调通知:', notify);
    
    // 验证签名
    const isValid = wp.utils.verifySign(notify);
    
    if (!isValid) {
      console.error('签名验证失败!');
      return;
    }
    
    // 处理业务逻辑
    if (notify.result_code === 'SUCCESS') {
      console.log('支付成功!');
      console.log('  订单号:', notify.out_trade_no);
      console.log('  金额:', notify.total_fee, '分');
      console.log('  支付时间:', notify.time_end);
      
      // TODO: 更新订单状态、通知用户等
      
    } else {
      console.log('支付失败:', notify.err_code_des);
    }
    
    // 返回成功响应给微信
    console.log('\n返回微信的响应:');
    console.log(wp.utils.buildXML({ return_code: 'SUCCESS', return_msg: 'OK' }));
    
  }).catch(error => {
    console.error('解析通知失败:', error.message);
  });
}

/**
 * 主流程演示
 */
async function main() {
  console.log('═══════════════════════════════════════');
  console.log('  微信支付服务商集成 - 完整流程演示');
  console.log('═══════════════════════════════════════\n');
  
  // 1. 事前风控
  await demoPreRisk();
  
  // 2. 创建订单
  const orderNo = await demoCreateOrder();
  
  // 3. 查询订单
  await demoQueryOrder(orderNo);
  
  // 4. 申请退款（可选）
  // await demoRefund(orderNo);
  
  // 5. 查询余额
  await demoGetBalance();
  
  // 6. 下载对账单
  await demoDownloadBill();
  
  console.log('\n═══════════════════════════════════════');
  console.log('  演示完成!');
  console.log('═══════════════════════════════════════');
}

// 运行演示
// main().catch(console.error);

module.exports = {
  demoPreRisk,
  demoCreateOrder,
  demoQueryOrder,
  demoRefund,
  demoGetBalance,
  demoDownloadBill,
  handleNotify
};
