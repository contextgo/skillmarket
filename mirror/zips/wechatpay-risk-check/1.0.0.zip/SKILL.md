# 微信支付风控核查技能

## 基本信息

| 字段 | 内容 |
|------|------|
| **Slug** | `wechatpay-risk-check` |
| **名称** | 微信支付风控核查 |
| **描述** | 微信支付风控核查解决方案，提供事前商户风险核查服务。基于微信支付官方风控接口，支持身份证、银行卡、营业执照、门店信息等多维度风险评估，精准识别高风险商户，保障支付安全。 |
| **版本** | 1.0.0 |
| **作者** | 叶建国 |
| **标签** | `payment`, `wechat`, `weixin`, `fintech`, `risk-control` |

---

## 功能概述

### 🔒 核心功能 - 风险商户核查
在商户入驻前进行多维度风险评估，精准识别高风险商户。

**核查维度：**
- 身份信息核查 - 身份证号、姓名
- 结算信息核查 - 银行卡号、户名、开户行
- 公司信息核查 - 营业执照、公司名称
- 门店信息核查 - 门店地址、经纬度

**风险级别：**
| 级别 | 说明 | 处理建议 |
|------|------|----------|
| UNKNOW | 未知风险 | 需人工复核 |
| NORMAL | 一般风险 | 正常进件 |
| MEDIUM | 中风险 | 需补充材料 |
| HIGH | 高风险 | 拒绝进件 |
| LOW | 低风险 | 快速通过 |
| FORBIDDEN | 禁入 | 永久拒绝 |

---

## 快速开始

### 1. 配置参数

```javascript
const WechatPay = require('./lib/wechatpay');

const wp = new WechatPay({
  appId: 'wx8888888888888888',
  mchId: '1900000109',        // 服务商号
  apiKey: 'YOUR_API_KEY',     // API密钥
  appSecret: 'YOUR_APPSECRET',
  certPath: '/path/to/apiclient_cert.pem',  // 证书路径
  certKeyPath: '/path/to/apiclient_key.pem', // 私钥路径
  notifyUrl: 'https://your-domain.com/notify',
  isSandbox: false            // 是否沙箱环境
});
```

### 2. 事前 - 商户风险核查

```javascript
// 查询商户风险
const riskResult = await wp.preRisk.queryMchRisk({
  certificates_number: '加密后的身份证号',
  certificates_name: '加密后的姓名',
  settlement_card_no: '加密后的银行卡号',
  settlement_card_name: '加密后的户名',
  business_license_number: '加密后的营业执照号',
  company_name: '公司名称',
  store_address: '门店地址',
  store_longitude: '经度',
  store_latitude: '纬度'
});

console.log('风险级别:', riskResult.risk_level);
console.log('风险描述:', riskResult.risk_level_desc);
```

### 3. 事中 - 创建支付订单

```javascript
// JSAPI支付下单
const order = await wp.trade.createJsapiOrder({
  body: '商品描述',
  out_trade_no: 'ORDER123456789',
  total_fee: 1,        // 单位：分
  spbill_create_ip: '客户端IP',
  notify_url: 'https://your-domain.com/notify',
  trade_type: 'JSAPI',
  sub_openid: '用户openid'
});

console.log('支付参数:', order);
// 返回唤起微信支付所需的参数
```

### 4. 事中 - 订单查询

```javascript
// 查询订单状态
const orderInfo = await wp.trade.queryOrder({
  out_trade_no: 'ORDER123456789'
});

console.log('订单状态:', orderInfo.trade_state);
console.log('交易金额:', orderInfo.total_fee);
```

### 5. 事中 - 申请退款

```javascript
// 申请退款
const refund = await wp.trade.applyRefund({
  out_trade_no: 'ORDER123456789',
  out_refund_no: 'REFUND123456789',
  total_fee: 1,
  refund_fee: 1,
  refund_desc: '用户申请退款'
});
```

### 6. 事后 - 查询余额

```javascript
// 查询账户余额
const balance = await wp.settlement.getBalance();

console.log('可用余额:', balance.available_balance);
console.log('待结算金额:', balance.pending_balance);
```

### 7. 事后 - 下载对账单

```javascript
// 获取对账单下载链接
const billUrl = await wp.settlement.getBillDownloadUrl({
  bill_date: '20240401',
  bill_type: 'ALL'   // ALL: 全部分账账单, SUCCESS: 成功账单, REFUND: 退款账单
});

console.log('账单下载地址:', billUrl.download_url);
```

---

## API 参考

### 事前风控模块 (PreRisk)

| 方法 | 说明 | 适用场景 |
|------|------|----------|
| `queryMchRisk` | 商户风险核查 | 商户入驻前必查 |
| `queryCertificateRisk` | 证照风险核查 | 营业执照核实 |
| `querySettlementRisk` | 结算信息风险 | 银行卡风控 |

### 交易模块 (Trade)

| 方法 | 说明 |
|------|------|
| `createJsapiOrder` | JSAPI支付下单 |
| `createNativeOrder` | Native支付下单 |
| `createAppOrder` | APP支付下单 |
| `queryOrder` | 查询订单 |
| `closeOrder` | 关闭订单 |
| `applyRefund` | 申请退款 |
| `queryRefund` | 查询退款 |
| `reverseOrder` | 撤销订单 |

### 结算模块 (Settlement)

| 方法 | 说明 |
|------|------|
| `getBalance` | 查询账户余额 |
| `getBillDownloadUrl` | 获取账单下载链接 |
| `getTransferBill` | 转账电子回单 |
| `getSettlementInfo` | 结算信息 |
| `getDailySummary` | 日交易汇总 |

### 回调通知模块 (Notify)

| 方法 | 说明 |
|------|------|
| `parseNotify` | 解析回调通知 |
| `verifyNotifySign` | 验签 |
| `responseSuccess` | 返回成功响应 |

---

## 配置说明

### 证书配置

微信支付需要双向SSL证书：
```javascript
{
  certPath: './cert/apiclient_cert.pem',
  certKeyPath: './cert/apiclient_key.pem'
}
```

证书获取方式：
1. 登录微信支付商户平台
2. 账户中心 → API安全
3. 申请API证书

### 加密说明

敏感信息（身份证、银行卡等）需使用RSA加密：
```javascript
const encrypted = wp.utils.rsaEncrypt(rawData, publicKey);
```

### 签名机制

所有请求需使用HMAC-SHA256签名：
```javascript
const sign = wp.utils.sign(params, apiKey);
```

---

## 错误码处理

| 错误码 | 说明 | 处理建议 |
|--------|------|----------|
| SYSTEMERROR | 系统错误 | 稍后重试 |
| PARAM_ERROR | 参数错误 | 检查参数 |
| ORDERPAID | 订单已支付 | 核实订单状态 |
| ORDERCLOSED | 订单已关闭 | 无需处理 |
| BANKERROR | 银行异常 | 联系银行 |
| USERPAYING | 用户支付中 | 等待支付结果 |
| AUTHCODEERROR | 授权码无效 | 重新获取授权码 |
| NOTENOUGH | 余额不足 | 用户充值 |

---

## 安全规范

1. **证书安全**：证书文件妥善保管，禁止提交到代码仓库
2. **敏感信息**：身份证、银行卡等需RSA加密传输
3. **签名验证**：回调通知必须验签后再处理业务
4. **日志规范**：禁止记录敏感信息（卡号、密码等）
5. **超时处理**：网络异常需做好幂等处理

---

## 依赖项

```json
{
  "axios": "^1.6.0",
  "xml2js": "^0.5.0",
  "crypto-js": "^4.2.0",
  "node-rsa": "^1.1.1"
}
```

---

## 注意事项

1. **事前风控是必选项**：建议所有商户入驻前必须调用风险核查接口
2. **交易金额单位**：所有金额单位为**分**，需自行转换
3. **签名类型**：仅支持HMAC-SHA256
4. **证书要求**：涉及资金操作需双向证书
5. **回调验签**：生产环境必须验签

---

## 版权声明

本技能基于微信支付官方文档开发，版权归属微信支付所有。
如有疑问请联系微信支付商户客服：95017

微信支付文档：https://pay.weixin.qq.com/

---

## 更新日志

### v1.0.0 (2026-04-05)
- 初始版本
- 支持事前风险核查
- 支持事中交易处理
- 支持事后结算对账
