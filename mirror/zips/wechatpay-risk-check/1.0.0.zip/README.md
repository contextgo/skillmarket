# 💳 微信支付风控核查技能

专业的微信支付风控解决方案，提供**事前商户风险核查**服务。基于微信支付官方风控接口，支持身份证、银行卡、营业执照、门店信息等多维度风险评估，精准识别高风险商户，保障支付安全。

## ✨ 核心功能

### 🔒 风险商户核查
在商户入驻前进行多维度风险评估，精准识别高风险商户。

**支持核查信息：**
- 身份信息 - 身份证号、姓名
- 结算信息 - 银行卡号、户名、开户行
- 公司信息 - 营业执照、公司名称
- 门店信息 - 门店地址、经纬度

**应用场景：**
- 商户入驻前风险评估
- 定期存量商户风险筛查
- 高风险交易预警
- 合规风控管理

---

## 🚀 快速开始

### 安装依赖
```bash
cd wechatpay-institution-skill
npm install
```

### 基础配置
```javascript
const WechatPay = require('./lib/wechatpay');

const wp = new WechatPay({
  appId: 'wx8888888888888888',
  mchId: '1900000109',        // 服务商号
  apiKey: 'YOUR_API_KEY',
  appSecret: 'YOUR_APP_SECRET',
  certPath: './cert/apiclient_cert.pem',
  certKeyPath: './cert/apiclient_key.pem',
  notifyUrl: 'https://your-domain.com/wechat/notify'
});
```

---

## 📖 使用示例

### 基础配置
```javascript
const WechatPay = require('./lib/wechatpay');

const wp = new WechatPay({
  appId: 'wx8888888888888888',
  mchId: '1900000109',        // 服务商号
  apiKey: 'YOUR_API_KEY',
  certPath: './cert/apiclient_cert.pem',
  certKeyPath: './cert/apiclient_key.pem'
});
```

### 1. 身份风险核查
```javascript
// 仅核查身份证信息
const result = await wp.preRisk.checkIdCardRisk(
  'RSA加密后的身份证号',
  'RSA加密后的姓名'
);

console.log('风险级别:', result.risk_level);  // LOW / MEDIUM / HIGH / FORBIDDEN
console.log('风险描述:', result.risk_level_desc);

// 解析风险级别
const info = wp.preRisk.parseRiskLevel(result.risk_level);
console.log('建议操作:', info.action);  // 快速通过 / 补充材料 / 拒绝进件
```

### 2. 完整信息风险核查
```javascript
// 多维度风险核查（身份信息+结算信息+公司信息+门店信息）
const risk = await wp.preRisk.queryMchRisk({
  certificates_number: 'RSA加密后的身份证号',
  certificates_name: 'RSA加密后的姓名',
  settlement_card_no: 'RSA加密后的银行卡号',
  settlement_card_name: 'RSA加密后的户名',
  settlement_card_bank: '招商银行科技园支行',
  business_license_number: 'RSA加密后的营业执照号',
  company_name: '测试科技有限公司',
  store_address: '深圳市南山区深南大道10000号',
  store_longitude: '22.5461478801',
  store_latitude: '113.9410519639'
});

console.log('综合风险级别:', risk.risk_level);
console.log('风险详细描述:', risk.risk_level_desc);
```

### 3. 敏感信息加密
```javascript
const { encryptIdCard, encryptCardNo, encryptLicenseNo } = require('./lib/utils');

// 加密身份证号
const encryptedIdCard = encryptIdCard('510105199001011234');

// 加密银行卡号
const encryptedCardNo = encryptCardNo('6222021234567890123');

// 加密营业执照
const encryptedLicense = encryptLicenseNo('91510105MA12345678');
```

---

## 🔐 安全说明

### 1. 证书配置
微信支付需要双向SSL证书：
- `apiclient_cert.pem` - 证书文件
- `apiclient_key.pem` - 私钥文件

证书获取：微信支付商户平台 → 账户中心 → API安全

### 2. 敏感信息加密
身份证、银行卡等敏感信息需要RSA加密：
```javascript
const encrypted = wp.utils.rsaEncrypt(rawData, publicKey);
```

### 3. 回调验签
生产环境必须验证回调签名：
```javascript
const isValid = wp.utils.verifySign(notifyData);
if (!isValid) {
  throw new Error('签名验证失败');
}
```

---

## 📚 风险级别说明

| 级别 | 说明 | 建议操作 |
|------|------|----------|
| UNKNOW | 未知风险 | 人工复核 |
| NORMAL | 一般 | 正常进件 |
| MEDIUM | 中风险 | 补充材料 |
| HIGH | 高风险 | 拒绝进件 |
| LOW | 低风险 | 快速通过 |
| FORBIDDEN | 禁入 | 永久拒绝 |

---

## 🔧 交易状态说明

| 状态 | 说明 |
|------|------|
| SUCCESS | 支付成功 |
| REFUND | 转入退款 |
| NOTPAY | 未支付 |
| CLOSED | 已关闭 |
| REVOKED | 已撤销 |
| USERPAYING | 用户支付中 |
| PAYERROR | 支付失败 |

---

## 📦 依赖项

- `axios` - HTTP请求
- `xml2js` - XML解析
- `node-rsa` - RSA加密

---

## 📝 版权声明

本技能基于微信支付官方文档开发，版权归属微信支付所有。

如有疑问请联系微信支付商户客服：**95017**

微信支付文档：https://pay.weixin.qq.com/

---

Made with ❤️ for OpenClaw
