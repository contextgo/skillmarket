---
name: ColorLab
description: "Convert colors and generate palettes with WCAG contrast checks. Use when building palettes, converting hex/RGB, checking accessibility."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["color","palette","design","hex","rgb","contrast","accessibility","css","wcag"]
categories: ["Design", "Developer Tools", "Utility"]
---

# ColorLab

A comprehensive design toolkit for creating palettes, previewing colors, generating schemes, converting formats, harmonizing colors, checking contrast, mixing colors, creating gradients, browsing swatches, and exporting — with built-in logging, search, statistics, and data export.

## Commands

| Command | Description |
|---------|-------------|
| `palette <input>` | Create or log a color palette; without args shows recent palette entries |
| `preview <input>` | Preview a color or scheme; without args shows recent preview entries |
| `generate <input>` | Generate a color scheme from input; without args shows recent entries |
| `convert <input>` | Convert color formats (hex/RGB/HSL); without args shows recent entries |
| `harmonize <input>` | Find harmonious colors (complementary, analogous, triadic); without args shows recent entries |
| `contrast <input>` | Check contrast ratio between colors; without args shows recent entries |
| `export <input>` | Export a color set; without args shows recent export entries |
| `random <input>` | Generate random color(s); without args shows recent entries |
| `browse <input>` | Browse color collections; without args shows recent browse entries |
| `mix <input>` | Mix two or more colors together; without args shows recent mix entries |
| `gradient <input>` | Create a gradient between colors; without args shows recent entries |
| `swatch <input>` | Create a color swatch; without args shows recent swatch entries |
| `stats` | Show summary statistics across all log categories |
| `export <fmt>` | Export all logged data (json, csv, or txt) |
| `search <term>` | Search across all logged entries for a keyword |
| `recent` | Show the 20 most recent entries from the activity log |
| `status` | Health check — version, data dir, total entries, disk usage, last activity |
| `help` | Show all available commands |
| `version` | Print version (v2.0.0) |

## Usage

```bash
colorlab <command> [args]
```

Each command with arguments logs the input with a timestamp to a category-specific log file. Running a command with no arguments displays the most recent entries for that category.

## Data Storage

- **Default location**: `~/.local/share/colorlab`
- **Log files**: Each command stores entries in its own file (e.g., `palette.log`, `contrast.log`, `gradient.log`)
- **History**: All actions are also recorded in `history.log` with timestamps
- **Export formats**: JSON (structured array of objects), CSV (type/time/value columns), plain text (grouped by category)

## Requirements

- Bash 4+ (strict mode: `set -euo pipefail`)
- No external dependencies or API keys required
- Standard Unix tools (`date`, `wc`, `grep`, `du`, `head`, `tail`)

## When to Use

1. **UI/UX design workflows** — Use `palette` and `generate` to create color schemes, then `contrast` to verify WCAG accessibility compliance
2. **Brand color management** — Use `harmonize` to find complementary colors for brand palettes, `swatch` to create reference swatches, and `export` to share with your team
3. **Color format conversion** — Use `convert` to transform between hex, RGB, and HSL formats when working across design tools and CSS
4. **Creative exploration** — Use `random` for color inspiration, `mix` to blend colors together, and `gradient` to create smooth transitions
5. **Color audit and tracking** — Use `stats` to review how many colors you've worked with, `search` to find past entries, and `recent` for quick activity review

## Examples

```bash
# Create a palette entry
colorlab palette "#3498db ocean blue scheme"

# Preview a color
colorlab preview "#e74c3c warm red"

# Generate a color scheme
colorlab generate "sunset warm tones"

# Convert a color format
colorlab convert "#ff5733 to RGB"

# Find harmonious colors
colorlab harmonize "#2ecc71 complementary"

# Check contrast ratio
colorlab contrast "#ffffff on #333333"

# Mix two colors
colorlab mix "#ff0000 and #0000ff"

# Create a gradient
colorlab gradient "#000000 to #ffffff 5 steps"

# Generate a random color
colorlab random

# Browse saved swatches
colorlab browse "pastels"

# View statistics
colorlab stats

# Export all data as JSON
colorlab export json

# Search for a color
colorlab search "blue"

# Show recent activity
colorlab recent

# Health check
colorlab status
```

## Output

- Command results print to stdout
- Entries are timestamped (`YYYY-MM-DD HH:MM`) and persisted to `~/.local/share/colorlab/<category>.log`
- Export files are written to `~/.local/share/colorlab/export.<fmt>` with a byte count confirmation

---

Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
