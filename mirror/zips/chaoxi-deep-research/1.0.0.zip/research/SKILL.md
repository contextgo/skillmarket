---
user-invocable: true
allowed-tools: Read, Write, Glob, WebSearch, Task, AskUserQuestion
description: Generate outline.yaml and fields.yaml for AI support policy research across Chinese regions.
---

# Research - AI扶持政策调研大纲

## 触发方式

```text
/research <topic>
```

典型输入：

```text
/research "全国各地对AI相关的扶持数据的excel"
```

## 执行流程

### Step 1：标准化用户需求

将用户输入标准化为：

```yaml
topic: 全国各地AI相关扶持政策Excel
target_output: AI扶持相关政策.xlsx
time_range: 2024年至今，优先仍有效政策
source_priority:
  - 政府官网
  - 工信局/科技局/发改委/数据局官网
  - 政策文件库
  - 政府公报
  - 官方PDF
```

### Step 2：生成初始调研对象

先生成重点地区种子列表，后续可通过 `/research-add-items` 扩展。

建议初始 items：

```yaml
items:
  - name: 北京
    category: 直辖市
    search_focus: 人工智能 赋能 新型工业化 算力补贴
  - name: 上海
    category: 直辖市
    search_focus: 算力券 模型券 语料券 人工智能应用
  - name: 深圳
    category: 计划单列市
    search_focus: 人工智能先锋城市 模型券 训力券 语料券
  - name: 杭州
    category: 省会城市
    search_focus: 人工智能 全产业链 算力券
  - name: 广州
    category: 省会城市
    search_focus: 人工智能产业 高质量发展 算力券
```

如果用户要求“全国完整覆盖”，继续补充：

```text
苏州、成都、武汉、合肥、南京、重庆、天津、西安、青岛、宁波、无锡、厦门、福州、长沙、郑州、济南、沈阳、大连、雄安、海南
```

### Step 3：询问用户确认范围

使用 AskUserQuestion 确认：

1. 是否只查 2024 年至今？
2. 是否只保留官方来源？
3. 是先做重点城市样例，还是尽量覆盖全国？
4. Excel 是否需要保留来源链接、待核验字段和可信度？

### Step 4：生成 outline.yaml

创建目录：

```text
./ai-policy-support/
```

写入：

```yaml
topic: 全国各地AI相关扶持政策Excel
target_output: AI扶持相关政策.xlsx
time_range: 2024年至今，优先仍有效政策
items:
  - name: 北京
    category: 直辖市
    search_focus: 人工智能 赋能 新型工业化 算力补贴
  - name: 上海
    category: 直辖市
    search_focus: 算力券 模型券 语料券 人工智能应用
  - name: 深圳
    category: 计划单列市
    search_focus: 人工智能先锋城市 模型券 训力券 语料券
  - name: 杭州
    category: 省会城市
    search_focus: 人工智能 全产业链 算力券
  - name: 广州
    category: 省会城市
    search_focus: 人工智能产业 高质量发展 算力券
execution:
  batch_size: 3
  items_per_agent: 1
  output_dir: ./results
```

### Step 5：生成 fields.yaml

写入字段定义：

```yaml
field_categories:
  - category: 基本信息
    fields:
      - name: province
        description: 省份或直辖市
        detail_level: 极简
        required: true
      - name: city_or_district
        description: 城市、区县或园区
        detail_level: 极简
        required: true
      - name: policy_name
        description: 政策正式名称
        detail_level: 极简
        required: true
      - name: issuing_authority
        description: 发文机构
        detail_level: 极简
        required: true
      - name: issue_date
        description: 发文日期，格式 yyyy-mm-dd
        detail_level: 极简
        required: true
      - name: policy_level
        description: 国家级、省级、市级、区级或园区
        detail_level: 极简
        required: true

  - category: 扶持内容
    fields:
      - name: support_direction
        description: 支持方向，如算力、模型、语料、场景、人才、基金
        detail_level: 简要
        required: true
      - name: support_method
        description: 扶持方式，如算力券、模型券、补贴、贴息、奖励
        detail_level: 简要
        required: true
      - name: funding_amount
        description: 资金总额、单项最高额度或奖励金额
        detail_level: 详细
        required: true
      - name: subsidy_ratio
        description: 补贴比例，如30%、50%；没有则写未披露
        detail_level: 简要
        required: false

  - category: 申报信息
    fields:
      - name: eligible_entities
        description: 适用对象
        detail_level: 简要
        required: true
      - name: application_conditions
        description: 申报条件摘要
        detail_level: 简要
        required: false
      - name: validity_period
        description: 有效期或实施期
        detail_level: 极简
        required: false

  - category: 来源与质量
    fields:
      - name: source_url
        description: 官方来源链接
        detail_level: 极简
        required: true
      - name: confidence
        description: 来源可信度，如官方政策原文、官方解读、媒体报道
        detail_level: 极简
        required: true
      - name: summary
        description: 一句话摘要
        detail_level: 简要
        required: false

uncertain: []
```

### Step 6：展示给用户确认

输出：

```text
已生成：
./ai-policy-support/outline.yaml
./ai-policy-support/fields.yaml

下一步：
/research-deep
```

