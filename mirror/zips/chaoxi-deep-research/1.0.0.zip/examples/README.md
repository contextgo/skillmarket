# AI扶持政策 Excel Skill 示例

用户输入：

```text
全国各地对AI相关的扶持数据的excel
```

推荐执行：

```text
/research "全国各地对AI相关的扶持数据的excel"
/research-add-items
/research-deep
/research-report
```

最终输出：

```text
AI扶持相关政策.xlsx
```

案例中的 Excel 建议包含：

1. 使用说明
2. 政策数据
3. 字段字典
4. DeepResearch配置
5. 来源清单

官方来源优先级：

1. 政府官网政策原文
2. 政府公报
3. 官方 PDF
4. 官方政策解读
5. 主管部门新闻
6. 媒体报道，仅作线索

