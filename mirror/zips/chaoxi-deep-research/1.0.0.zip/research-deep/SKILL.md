---
user-invocable: true
description: Search official AI support policies by region and output structured JSON files.
allowed-tools: Bash, Read, Write, Glob, WebSearch, Task
---

# Research Deep - AI政策深度搜索

## 触发方式

```text
/research-deep
```

## 执行流程

### Step 1：定位调研文件

在当前工作目录查找：

```text
*/outline.yaml
*/fields.yaml
```

读取：

```yaml
topic
time_range
items
execution.batch_size
execution.items_per_agent
execution.output_dir
```

### Step 2：断点续传

检查 `output_dir` 下已有 JSON：

```text
results/{region_slug}.json
```

已存在则跳过，避免重复搜索。

### Step 3：分批执行

按 `batch_size` 分批。

建议：

```yaml
batch_size: 3
items_per_agent: 1
```

一个 agent 只负责一个地区，降低不同地区政策混淆风险。

### Step 4：启动 policy-search-agent

对每个地区使用以下 Prompt。必须严格保留结构，只替换变量。

```text
## 任务
搜索 {region_name} 与 AI、人工智能、算力券、模型券、语料券、产业扶持、补贴、奖励、贴息、基金相关的官方政策。

当前日期：{YYYY-MM-DD}
时间范围：{time_range}

## 地区信息
{item_related_info}

## 来源优先级
1. 政府官网
2. 工信局、科技局、发改委、数据局官网
3. 政策文件库
4. 政府公报
5. 官方PDF

媒体报道只能作为线索，不能作为最终金额依据。

## 字段定义
读取 {fields_path}，按所有字段输出 JSON。

## 输出要求
1. 每条政策输出一个对象，放入 policies 数组。
2. 金额、比例、有效期必须保留原文口径。
3. 找不到官方来源的字段写 [不确定]。
4. 每条政策对象内添加 uncertain 数组。
5. 所有 source_url 必须可追溯。
6. 最终 JSON 值使用中文。
7. 写入 {output_path}。

## 输出结构
{
  "region": "{region_name}",
  "searched_at": "{YYYY-MM-DD}",
  "policies": [
    {
      "province": "",
      "city_or_district": "",
      "policy_name": "",
      "issuing_authority": "",
      "issue_date": "",
      "policy_level": "",
      "support_direction": "",
      "support_method": "",
      "funding_amount": "",
      "subsidy_ratio": "",
      "eligible_entities": "",
      "application_conditions": "",
      "validity_period": "",
      "source_url": "",
      "confidence": "",
      "summary": "",
      "uncertain": []
    }
  ]
}

## 验证
完成后检查：
- policies 数组不能为空
- 每条政策必须有 policy_name 和 source_url
- funding_amount 没有官方依据时必须写 [不确定]
```

### Step 5：汇总状态

全部完成后输出：

```text
已完成地区数量
跳过地区数量
失败地区数量
待核验字段数量
结果目录
```

