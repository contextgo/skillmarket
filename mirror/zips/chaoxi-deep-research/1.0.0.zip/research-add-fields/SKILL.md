---
user-invocable: true
description: Add policy extraction fields to fields.yaml for AI support policy Excel output.
allowed-tools: Bash, Read, Write, Glob, WebSearch, Task, AskUserQuestion
---

# Research Add Fields - 补充政策字段

## 触发方式

```text
/research-add-fields
```

## 执行流程

### Step 1：自动定位 fields.yaml

查找：

```text
*/fields.yaml
```

读取现有字段。

### Step 2：询问用户补充字段

推荐可选字段：

```text
申报入口
主管部门联系方式
是否需要入库
是否免申即享
是否可与其他政策叠加
申报材料
申报时间窗口
主管部门
政策状态
适合企业阶段
是否限本地企业
```

### Step 3：确认字段属性

每个字段需要确认：

```yaml
name:
description:
detail_level:
required:
category:
```

### Step 4：写回 fields.yaml

保留原字段，追加新字段，不删除用户已有字段。

### Step 5：提醒用户

如果字段是在 `/research-deep` 之后追加的，提醒用户：

```text
新增字段不会自动出现在已完成 JSON 中。需要重跑相关地区，或手动补充 results/*.json。
```

