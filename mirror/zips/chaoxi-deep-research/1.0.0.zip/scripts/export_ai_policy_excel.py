#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Export AI support policy research JSON files to a simple .xlsx workbook.

This script intentionally uses only Python standard library modules so the
Skill can run in restricted environments without openpyxl/xlsxwriter.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Iterable
from xml.sax.saxutils import escape


HEADERS = [
    "序号",
    "省份",
    "城市/区县",
    "政策名称",
    "发文机构",
    "发文日期",
    "政策层级",
    "支持方向",
    "扶持方式",
    "资金/额度",
    "补贴比例",
    "适用对象",
    "申报条件摘要",
    "有效期/实施期",
    "来源链接",
    "可信度",
    "状态",
    "待核验字段",
    "摘要",
]

KEYS = [
    "province",
    "city_or_district",
    "policy_name",
    "issuing_authority",
    "issue_date",
    "policy_level",
    "support_direction",
    "support_method",
    "funding_amount",
    "subsidy_ratio",
    "eligible_entities",
    "application_conditions",
    "validity_period",
    "source_url",
    "confidence",
    "summary",
]

FIELD_DICT = [
    ["字段名", "字段含义", "建议来源", "是否必填", "备注"],
    ["province", "省份/直辖市", "政策标题、发文机关、正文", "是", "直辖市可与城市相同"],
    ["city_or_district", "城市、区县或园区", "政策标题、发文机关", "是", "区级政策需写到区县"],
    ["policy_name", "政策正式名称", "政策标题", "是", "优先使用官方标题"],
    ["issuing_authority", "发文机构", "政策页元数据或正文落款", "是", "多个机构用顿号分隔"],
    ["issue_date", "发文/发布日期", "政策页元数据或正文落款", "是", "统一 yyyy-mm-dd"],
    ["policy_level", "国家/省级/市级/区级/园区", "发文机构层级", "是", "用于筛选"],
    ["support_direction", "政策支持方向", "正文条款", "是", "如算力、模型、语料、场景、人才"],
    ["support_method", "扶持方式", "正文条款", "是", "如补贴、券、奖励、贴息、基金"],
    ["funding_amount", "资金总额或单项额度", "正文金额条款", "是", "保留原文口径"],
    ["subsidy_ratio", "补贴比例", "正文比例条款", "否", "无比例时填“未披露”"],
    ["eligible_entities", "适用对象", "正文申报主体描述", "是", "企业/科研机构/平台等"],
    ["application_conditions", "申报条件摘要", "正文条件条款", "否", "不要写太长，保留关键门槛"],
    ["validity_period", "有效期/实施期", "正文或附则", "否", "没有则填“以申报指南为准”"],
    ["source_url", "来源链接", "官方网页/PDF", "是", "尽量使用政府官网"],
    ["confidence", "可信度", "来源类型判断", "是", "官方政策原文 > 官方解读 > 媒体报道"],
    ["uncertain", "待核验字段", "模型自检", "是", "无法确认的字段必须列出"],
]

CONFIG_ROWS = [
    ["配置项", "建议值", "说明"],
    ["topic", "全国各地对AI相关的扶持数据的excel", "用户输入的调研主题"],
    ["time_range", "2024年至今，优先仍有效政策", "政策类信息强时效，必须限制时间"],
    ["batch_size", "3", "每批3个地区，便于检查质量"],
    ["items_per_agent", "1", "一个agent只负责一个地区，降低混淆"],
    ["output_dir", "./results", "每个地区或政策输出一个JSON"],
    ["source_priority", "政府官网、工信局/科技局/发改委官网、政策文件库、政府公报、官方PDF", "媒体报道只能作为线索"],
    ["quality_rule", "无官方来源的金额字段标记[不确定]", "防止把二手信息写成事实"],
]


def col_name(index: int) -> str:
    name = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def cell_xml(row_idx: int, col_idx: int, value: object, style: int = 0) -> str:
    ref = f"{col_name(col_idx)}{row_idx}"
    text = "" if value is None else str(value)
    text = escape(text)
    style_attr = f' s="{style}"' if style else ""
    return f'<c r="{ref}" t="inlineStr"{style_attr}><is><t>{text}</t></is></c>'


def sheet_xml(rows: list[list[object]], widths: list[int] | None = None, freeze_header: bool = False) -> str:
    max_cols = max((len(r) for r in rows), default=1)
    max_rows = max(len(rows), 1)
    dimension = f"A1:{col_name(max_cols - 1)}{max_rows}"
    parts = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
        f'<dimension ref="{dimension}"/>',
    ]
    if freeze_header:
        parts.append(
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            '</sheetView></sheetViews>'
        )
    if widths:
        parts.append("<cols>")
        for i, width in enumerate(widths[:max_cols], start=1):
            parts.append(f'<col min="{i}" max="{i}" width="{width}" customWidth="1"/>')
        parts.append("</cols>")
    parts.append("<sheetData>")
    for r_idx, row in enumerate(rows, start=1):
        parts.append(f'<row r="{r_idx}">')
        for c_idx, value in enumerate(row):
            style = 1 if r_idx == 1 else 0
            parts.append(cell_xml(r_idx, c_idx, value, style))
        parts.append("</row>")
    parts.append("</sheetData>")
    if freeze_header and rows:
        parts.append(f'<autoFilter ref="A1:{col_name(max_cols - 1)}{max_rows}"/>')
    parts.append("</worksheet>")
    return "".join(parts)


def workbook_xml(sheet_names: list[str]) -> str:
    sheets = []
    for idx, name in enumerate(sheet_names, start=1):
        sheets.append(
            f'<sheet name="{escape(name)}" sheetId="{idx}" r:id="rId{idx}"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        "<sheets>"
        + "".join(sheets)
        + "</sheets></workbook>"
    )


def workbook_rels_xml(sheet_count: int) -> str:
    rels = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
    ]
    for idx in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{idx}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            f'Target="worksheets/sheet{idx}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>'
    )
    rels.append("</Relationships>")
    return "".join(rels)


def styles_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="2">'
        '<font><sz val="10"/><name val="Microsoft YaHei"/></font>'
        '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Microsoft YaHei"/></font>'
        '</fonts>'
        '<fills count="3">'
        '<fill><patternFill patternType="none"/></fill>'
        '<fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E79"/><bgColor indexed="64"/></patternFill></fill>'
        '</fills>'
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="2">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        '</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        "</styleSheet>"
    )


def content_types_xml(sheet_count: int) -> str:
    overrides = [
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
        '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ]
    for idx in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{idx}.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        + "".join(overrides)
        + "</Types>"
    )


def root_rels_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        "</Relationships>"
    )


def core_xml() -> str:
    now = dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:title>AI扶持相关政策</dc:title>"
        "<dc:creator>AI Policy Research Excel Skill</dc:creator>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
        "</cp:coreProperties>"
    )


def app_xml(sheet_names: list[str]) -> str:
    titles = "".join(f"<vt:lpstr>{escape(name)}</vt:lpstr>" for name in sheet_names)
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>AI Policy Research Excel Skill</Application>"
        '<TitlesOfParts><vt:vector size="5" baseType="lpstr">'
        + titles
        + "</vt:vector></TitlesOfParts>"
        "</Properties>"
    )


def write_xlsx(output: Path, sheets: list[tuple[str, list[list[object]], list[int], bool]]) -> None:
    sheet_names = [s[0] for s in sheets]
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types_xml(len(sheets)))
        zf.writestr("_rels/.rels", root_rels_xml())
        zf.writestr("docProps/core.xml", core_xml())
        zf.writestr("docProps/app.xml", app_xml(sheet_names))
        zf.writestr("xl/workbook.xml", workbook_xml(sheet_names))
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml(len(sheets)))
        zf.writestr("xl/styles.xml", styles_xml())
        for idx, (_, rows, widths, freeze) in enumerate(sheets, start=1):
            zf.writestr(f"xl/worksheets/sheet{idx}.xml", sheet_xml(rows, widths, freeze))


def clean_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return "；".join(clean_text(v) for v in value if clean_text(v))
    if isinstance(value, dict):
        return "；".join(f"{k}: {clean_text(v)}" for k, v in value.items())
    return re.sub(r"\s+", " ", str(value)).strip()


def load_policies(input_dir: Path) -> list[dict]:
    policies: list[dict] = []
    for path in sorted(input_dir.glob("*.json")):
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            candidates = data
        elif isinstance(data, dict) and isinstance(data.get("policies"), list):
            candidates = data["policies"]
        elif isinstance(data, dict):
            candidates = [data]
        else:
            continue
        for item in candidates:
            if isinstance(item, dict):
                item.setdefault("_source_file", path.name)
                policies.append(item)
    return policies


def policy_status(policy: dict) -> str:
    confidence = clean_text(policy.get("confidence"))
    uncertain = policy.get("uncertain") or []
    amount = clean_text(policy.get("funding_amount"))
    if "媒体" in confidence:
        return "仅线索"
    if uncertain or "[不确定]" in amount:
        return "待核验"
    return "已核验"


def policy_rows(policies: Iterable[dict]) -> list[list[object]]:
    rows = [HEADERS]
    for idx, policy in enumerate(policies, start=1):
        uncertain = policy.get("uncertain") or []
        row = [idx]
        for key in KEYS[:-1]:
            row.append(clean_text(policy.get(key)))
        row.append(policy_status(policy))
        row.append(clean_text(uncertain))
        row.append(clean_text(policy.get("summary")))
        rows.append(row)
    return rows


def source_rows(policies: Iterable[dict]) -> list[list[object]]:
    rows = [["地区", "政策名称", "来源类型", "URL", "已抽取的核心信息"]]
    for policy in policies:
        rows.append(
            [
                clean_text(policy.get("city_or_district") or policy.get("province")),
                clean_text(policy.get("policy_name")),
                clean_text(policy.get("confidence")),
                clean_text(policy.get("source_url")),
                clean_text(policy.get("funding_amount")),
            ]
        )
    return rows


def guide_rows(output_name: str) -> list[list[object]]:
    return [
        ["AI扶持相关政策 Deep Research 输出说明", ""],
        ["用途", "汇总全国各地 AI 相关扶持政策、算力券、模型券、语料券、补贴、奖励等结构化信息。"],
        ["输出文件", output_name],
        ["重要说明", "政策类数据时效性强，授课或正式交付前应重新运行 /research-deep 核验。"],
        ["质量标准", "金额、比例、有效期、适用对象必须有官方来源；没有官方来源时标记[不确定]。"],
        ["生成日期", dt.date.today().isoformat()],
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description="Export AI support policy JSON results to xlsx.")
    parser.add_argument("--input-dir", default="results", help="Directory containing *.json result files")
    parser.add_argument("--output", default="AI扶持相关政策.xlsx", help="Output .xlsx path")
    parser.add_argument("--topic-dir", default=".", help="Topic directory, used for context only")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output = Path(args.output)
    if not input_dir.exists():
        print(f"[错误] 输入目录不存在: {input_dir}", file=sys.stderr)
        return 1

    policies = load_policies(input_dir)
    if not policies:
        print(f"[错误] 未找到政策JSON: {input_dir}/*.json", file=sys.stderr)
        return 1

    output.parent.mkdir(parents=True, exist_ok=True)
    sheets = [
        ("使用说明", guide_rows(output.name), [24, 90], False),
        ("政策数据", policy_rows(policies), [8, 12, 18, 42, 32, 14, 12, 38, 34, 54, 34, 34, 54, 24, 60, 18, 14, 34, 48], True),
        ("字段字典", FIELD_DICT, [24, 42, 34, 12, 42], True),
        ("DeepResearch配置", CONFIG_ROWS, [24, 52, 70], True),
        ("来源清单", source_rows(policies), [18, 48, 20, 70, 60], True),
    ]
    write_xlsx(output, sheets)
    print(f"[完成] {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
