---
user-invocable: true
description: Merge AI support policy JSON files and export AI扶持相关政策.xlsx.
allowed-tools: Read, Write, Glob, Bash, AskUserQuestion
---

# Research Report - 导出 AI扶持相关政策.xlsx

## 触发方式

```text
/research-report
```

## 执行流程

### Step 1：定位结果

查找：

```text
*/outline.yaml
*/fields.yaml
*/results/*.json
```

读取 `outline.yaml` 中：

```yaml
target_output: AI扶持相关政策.xlsx
execution.output_dir: ./results
```

### Step 2：合并 JSON

合并所有 JSON 中的：

```json
policies[]
```

每条政策生成 Excel 的一行。

### Step 3：询问用户导出选项

询问：

1. Excel 是否只保留“已核验样例”？
2. 是否保留 `待核验字段`？
3. 是否保留媒体线索？
4. 输出路径是否为 `案例输出结果的模板/AI扶持相关政策.xlsx`？

默认：

```text
保留待核验字段，不删除不确定行，但状态标为“待核验”。
```

### Step 4：运行导出脚本

优先使用本 Skill 自带脚本：

```bash
python scripts/export_ai_policy_excel.py \
  --input-dir {topic}/results \
  --output "{topic}/AI扶持相关政策.xlsx" \
  --topic-dir {topic}
```

如果用户明确要求案例路径，则输出到：

```text
案例输出结果的模板/AI扶持相关政策.xlsx
```

### Step 5：Excel 必须包含的 Sheet

| Sheet | 说明 |
|---|---|
| 使用说明 | 说明用途、数据口径、更新时间 |
| 政策数据 | 每条政策一行 |
| 字段字典 | 字段含义和抽取规则 |
| DeepResearch配置 | topic、时间范围、并行配置、来源优先级 |
| 来源清单 | 每条政策的来源 URL |

### Step 6：验收规则

Excel 合格标准：

1. 每行都有 `source_url`。
2. 政策名称、地区、发文机构不为空。
3. 金额字段未核验时标记 `[不确定]`。
4. `uncertain` 不为空的行状态为 `待核验`。
5. 来源为媒体报道的行状态为 `仅线索`。
6. 输出文件名为 `AI扶持相关政策.xlsx`。

