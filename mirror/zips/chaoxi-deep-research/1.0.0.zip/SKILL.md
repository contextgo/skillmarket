---
name: AI Policy Research Excel
description: Structured deep research workflow for collecting AI-related government support policies across China and exporting them to Excel. Use when the user asks for 全国各地AI扶持政策、AI补贴政策、算力券、模型券、语料券、人工智能产业政策、政策Excel, or says “全国各地对AI相关的扶持数据的excel”. Produces outline.yaml, fields.yaml, results/*.json, and AI扶持相关政策.xlsx.
description_zh: "全国各地AI相关扶持政策搜索与Excel导出工作流"
version: 1.0.0
homepage: local
license: MIT
allowed-tools: Read, Write, Glob, WebSearch, Task, AskUserQuestion, Bash
disable: false
---

# AI Policy Research Excel

把用户的自然语言需求：

```text
全国各地对AI相关的扶持数据的excel
```

转成可执行的 Deep Research 工作流：

```text
/research
  -> outline.yaml + fields.yaml
/research-add-items
  -> 补充省市/区县
/research-add-fields
  -> 补充政策字段
/research-deep
  -> results/*.json
/research-report
  -> AI扶持相关政策.xlsx
```

## 核心命令

| 命令 | 说明 |
|---|---|
| `/research <topic>` | 生成政策调研大纲和字段定义 |
| `/research-add-items` | 追加省市、区县、园区或重点政策对象 |
| `/research-add-fields` | 追加 Excel 字段 |
| `/research-deep` | 逐地区搜索官方 AI 扶持政策并输出 JSON |
| `/research-report` | 汇总 JSON 并导出 Excel |

## 标准输出

```text
{topic_slug}/
├── outline.yaml
├── fields.yaml
├── results/
│   ├── beijing.json
│   ├── shanghai.json
│   └── ...
└── AI扶持相关政策.xlsx
```

## 质量原则

1. 政策金额、补贴比例、有效期必须优先来自政府官网、政府公报、主管部门官网或官方 PDF。
2. 媒体报道只能作为搜索线索，不能作为最终金额依据。
3. 找不到官方依据的字段必须写 `[不确定]`，并列入 `uncertain`。
4. 每条政策必须保留 `source_url`。
5. 最终 Excel 必须可筛选、可追溯、可继续补充。

