---
user-invocable: true
description: Add regions, districts, parks, or specific AI policy targets to the existing outline.yaml.
allowed-tools: Bash, Read, Write, Glob, WebSearch, Task, AskUserQuestion
---

# Research Add Items - 补充政策调研地区

## 触发方式

```text
/research-add-items
```

## 执行流程

### Step 1：自动定位 outline

在当前工作目录查找：

```text
*/outline.yaml
```

读取已有 `items`。

### Step 2：询问补充范围

询问用户是否补充：

1. 省级地区。
2. 市级地区。
3. 区县/园区。
4. 具体政策名称。

推荐补充候选：

```text
苏州、成都、武汉、合肥、南京、重庆、天津、西安、青岛、宁波、无锡、厦门、福州、长沙、郑州、济南、沈阳、大连、雄安、海南
```

### Step 3：可选 Web Search 扩展

如果用户同意，启动 `policy-search-agent` 搜索：

```text
2024 2025 人工智能 扶持政策 算力券 模型券 语料券 城市
```

输出建议补充地区和理由。

### Step 4：合并并去重

追加到 `outline.yaml` 的 `items` 中，保持字段：

```yaml
- name: 地区名称
  category: 省级/市级/区级/园区
  search_focus: 搜索关键词
```

### Step 5：保存

原地更新：

```text
{topic}/outline.yaml
```

