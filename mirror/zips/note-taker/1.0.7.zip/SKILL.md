---
version: "2.0.0"
name: note-taker
description: "笔记整理助手。康奈尔笔记法、卡片盒笔记(Zettelkasten)、思维导图笔记、会议笔记、课堂笔记、笔记整理。Note-taking with Cornell method, Zettelkasten, mind maps, meeting notes, lecture notes, organization. Use when you need note taker capabilities. Triggers on: note taker."
author: BytesAgain
---
# note-taker

笔记整理助手。康奈尔笔记法、卡片盒笔记(Zettelkasten)、思维导图笔记、会议笔记、课堂笔记、笔记整理。Note-taking with Cornell method, Zettelkasten, mind maps, meeting notes, lecture notes, organization.

## 推荐工作流

```
需求分析 → 选择命令 → 输入描述 → 获取结果 → 调整优化
```

## 可用命令

- **cornell** — cornell
- **zettel** — zettel
- **mindmap** — mindmap
- **meeting** — meeting
- **lecture** — lecture
- **organize** — organize

## 专业建议

- 页面分3区: 右侧(笔记)、左侧(线索)、底部(总结)
- 课后24小时内完成线索栏和总结
- 复习时遮住右侧，用线索回忆
- 每张卡片只写一个想法
- 用唯一ID编号

---
*note-taker by BytesAgain*
---
💬 Feedback & Feature Requests: https://bytesagain.com/feedback
Powered by BytesAgain | bytesagain.com

- Run `note-taker help` for all commands

## Commands

Run `note-taker help` to see all available commands.

- Run `note-taker help` for all commands
