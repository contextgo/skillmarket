#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
龙虾知识管家 - 体验版
Lobster Knowledge Butler - Free Version

核心功能：
1. 文本归纳与摘要生成
2. 关键词提取
3. 内容分类
4. 使用限制提示
"""

import re
import json
import hashlib
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict


@dataclass
class KnowledgeItem:
    """知识条目数据结构"""
    id: str
    title: str
    summary: str
    keywords: List[str]
    categories: List[str]
    original_text: str
    created_at: str
    

class KnowledgeEngine:
    """知识处理引擎 - 体验版"""
    
    # 达到限制提示
    LIMIT_REACHED_MESSAGE = """
🎉 今日体验次数已用完！

感谢您使用龙虾知识管家体验版。

明天再来继续使用吧～

🦞 青木会江湖 - 小龙虾AI+社群变现第一站\n📱 更多服务关注公众号：青木老贼说社群
"""
    
    # 功能受限提示（纯提示，无引导）
    LIMIT_MESSAGES = {
        "keywords": "",
        "length": "\n⚠️ 内容已截断，体验版支持3000字",
        "export": ""
    }
    
    def __init__(self):
        self.tier = "free"
        self.daily_limit = 10
        self.max_length = 3000
        self.max_keywords = 5
        self.usage_count = 0
        
    def _generate_id(self, text: str) -> str:
        """生成唯一ID"""
        return hashlib.md5(f"{text}{datetime.now()}".encode()).hexdigest()[:12]
    
    def _extract_title(self, text: str) -> str:
        """提取标题（第一行或前30字）"""
        lines = text.strip().split('\n')
        for line in lines[:3]:
            line = line.strip()
            if line and len(line) < 100:
                return line[:50]
        return text[:30] + "..." if len(text) > 30 else text
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词（体验版最多5个）"""
        stopwords = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', 
                     '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去',
                     '你', '会', '着', '没有', '看', '好', '自己', '这'}
        
        words = re.findall(r'[\u4e00-\u9fa5]{2,}|[a-zA-Z]+', text.lower())
        
        word_freq = {}
        for word in words:
            if word not in stopwords and len(word) >= 2:
                word_freq[word] = word_freq.get(word, 0) + 1
        
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [word for word, _ in sorted_words[:self.max_keywords]]
    
    def _generate_summary(self, text: str, max_sentences: int = 3) -> str:
        """生成摘要"""
        sentences = re.split(r'[。！？\n]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
        
        if not sentences:
            return text[:200] + "..." if len(text) > 200 else text
        
        summary_sentences = sentences[:max_sentences]
        return "。".join(summary_sentences) + "。"
    
    def _classify_content(self, text: str) -> List[str]:
        """内容分类"""
        categories = []
        
        category_rules = {
            "商业": ['商业', '营销', '销售', '品牌', '市场', '运营', '创业', '盈利', '收入'],
            "技术": ['技术', '代码', '编程', '开发', '软件', '系统', '算法', 'AI', '人工智能'],
            "内容": ['内容', '写作', '文案', '文章', '创作', '编辑', '发布', '传播'],
            "社群": ['社群', '社区', '群', '用户', '粉丝', '互动', '运营', '私域'],
            "知识": ['知识', '学习', '教育', '培训', '课程', '教程', '方法', '技巧'],
            "数据": ['数据', '分析', '统计', '报表', '指标', '增长', '转化', '漏斗'],
            "设计": ['设计', 'UI', '视觉', '海报', '图片', '配色', '排版', '美观']
        }
        
        text_lower = text.lower()
        for category, keywords in category_rules.items():
            if any(kw in text_lower for kw in keywords):
                categories.append(category)
        
        return categories if categories else ["综合"]
    
    def check_limit(self) -> tuple[bool, Optional[str]]:
        """
        检查使用限制
        
        Returns:
            (是否可用, 提示信息)
        """
        if self.usage_count >= self.daily_limit:
            return False, self.LIMIT_REACHED_MESSAGE
        return True, None
    
    def process(self, text: str, title: Optional[str] = None) -> Dict[str, Any]:
        """
        处理文本，生成知识条目
        
        Args:
            text: 原始文本
            title: 可选标题
            
        Returns:
            包含结果和提示信息的字典
        """
        # 检查限制
        can_use, limit_msg = self.check_limit()
        if not can_use:
            return {
                "success": False,
                "result": None,
                "message": limit_msg,
                "limit_reached": True
            }
        
        # 增加使用次数
        self.usage_count += 1
        
        # 检查字数限制
        warnings = []
        original_length = len(text)
        if len(text) > self.max_length:
            text = text[:self.max_length]
            warnings.append(self.LIMIT_MESSAGES["length"])
        
        # 生成知识条目
        item = KnowledgeItem(
            id=self._generate_id(text),
            title=title or self._extract_title(text),
            summary=self._generate_summary(text),
            keywords=self._extract_keywords(text),
            categories=self._classify_content(text),
            original_text=text,
            created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        
        # 构建返回结果
        remaining = self.daily_limit - self.usage_count
        result_text = self._format_result(item, remaining)
        
        # 添加功能提示
        if len(item.keywords) >= self.max_keywords:
            warnings.append(self.LIMIT_MESSAGES["keywords"])
        
        # 添加剩余次数提示
        if remaining <= 3:
            warnings.append(f"\n⚠️ 今日还剩 {remaining} 次体验机会")
        
        return {
            "success": True,
            "result": item,
            "message": result_text + "".join(warnings),
            "remaining": remaining,
            "limit_reached": remaining == 0
        }
    
    def _format_result(self, item: KnowledgeItem, remaining: int) -> str:
        """格式化输出结果"""
        return f"""
🦞 **龙虾知识管家**（体验版）

📚 **{item.title}**

📝 **内容摘要：**
{item.summary}

🔑 **核心关键词：**
{', '.join(item.keywords)}

📂 **内容分类：**
{', '.join(item.categories)}

---
💡 今日剩余体验次数：**{remaining}/{self.daily_limit}**
🦞 青木会江湖出品
""".strip()
    
    def export_text(self, item: KnowledgeItem) -> str:
        """导出为文本格式"""
        return f"""
{'='*50}
📚 {item.title}
{'='*50}

📝 摘要：
{item.summary}

🔑 关键词：{', '.join(item.keywords)}

📂 分类：{', '.join(item.categories)}

⏰ 生成时间：{item.created_at}

{'='*50}
🦞 龙虾知识管家（体验版）- 青木会江湖出品
{'='*50}
""".strip()


# 命令行接口
if __name__ == "__main__":
    import sys
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    # 示例用法
    sample_text = """
    社群运营是私域流量运营的核心环节。要做好社群运营，需要关注以下几个方面：
    第一，明确社群定位，知道你的社群是为谁服务的，提供什么价值。
    第二，建立社群规则，包括入群门槛、发言规范、奖惩机制等。
    第三，持续输出优质内容，保持社群活跃度。
    第四，设计互动机制，如话题讨论、问答环节、活动组织等。
    第五，做好用户分层，针对不同用户提供差异化服务。
    """
    
    engine = KnowledgeEngine()
    
    # 模拟10次使用
    for i in range(12):
        result = engine.process(sample_text, title=f"测试文章-{i+1}")
        print(f"\n{'='*60}")
        print(f"第 {i+1} 次调用")
        print(f"{'='*60}")
        print(result["message"])
        
        if not result["success"]:
            print("\n升级引导测试成功！")
            break
