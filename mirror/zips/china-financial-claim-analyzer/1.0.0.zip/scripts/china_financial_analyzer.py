"""
中国金融市场信息分析引擎
融合系统性事实核查与观点/事实分类方法论

功能：
1. 声明分解与分类（实体/事件/观点/预测/因果）
2. 证据分级（人证/物证，A-E 级）
3. 信息源可信度评分
4. 综合可信度评级
5. 市场操纵信号识别

适用场景：
- 上市公司公告真实性验证
- 研报观点与事实区分
- 市场传言调查
- ESG 披露信息评估
"""

import json
import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime


class ClaimType(Enum):
    """声明类型"""
    ENTITY = "实体"  # 公司、机构、个人
    EVENT = "事件"  # 已发生的具体事件
    STATE = "状态"  # 当前财务/运营状态
    FORECAST = "预测"  # 业绩预测、预期
    CAUSATION = "因果"  # 因果关系声明
    NARRATIVE = "叙事"  # 概念/题材包装
    POLICY = "政策"  # 政策解读/影响
    COMPETITIVE = "竞争"  # 竞争地位/市场份额


class EvidenceType(Enum):
    """证据类型"""
    HUMAN = "人证"
    PHYSICAL = "物证"


class EvidenceLevel(Enum):
    """证据等级"""
    A = "A级"  # 最高可信度
    B = "B级"
    C = "C级"
    D = "D级"
    E = "E级"  # 最低可信度


class SourceType(Enum):
    """信息源类型"""
    REGULATORY = "监管官方"  # 证监会、交易所等
    COMPANY_OFFICIAL = "公司官方"  # 上市公司公告
    MAINSTREAM_MEDIA = "主流媒体"
    RESEARCH_INSTITUTION = "研究机构"
    SOCIAL_MEDIA = "自媒体"
    ANONYMOUS = "匿名来源"


class ConfidenceLevel(Enum):
    """置信度等级"""
    CERTAIN = "确定"  # 90-100%
    HIGHLY_PROBABLE = "很可能"  # 75-89%
    PROBABLE = "可能"  # 60-74%
    UNCERTAIN = "不确定"  # 40-59%
    LIKELY_FALSE = "可能不实"  # 20-39%
    FALSE = "确定不实"  # 0-19%


@dataclass
class AtomicClaim:
    """原子声明"""
    id: str
    claim_type: ClaimType
    content: str
    verifiability: str  # "高/中/低/不可验证"
    verified: bool = False
    confidence: float = 0.0
    evidence: List[Dict] = None

    def __post_init__(self):
        if self.evidence is None:
            self.evidence = []


@dataclass
class Evidence:
    """证据"""
    evidence_type: EvidenceType
    evidence_level: EvidenceLevel
    source_type: SourceType
    content: str
    source_url: str
    source_credibility: float  # 0-1
    date: str
    notes: str = ""


@dataclass
class AnalysisReport:
    """分析报告"""
    original_statement: str
    company_name: str = ""
    analysis_date: str = ""
    atomic_claims: List[AtomicClaim] = None
    evidences: List[Evidence] = None
    verified_facts: List[Dict] = None
    disputed_claims: List[Dict] = None
    narrative_analysis: Dict = None
    risk_signals: List[str] = None
    overall_confidence: float = 0.0
    confidence_level: ConfidenceLevel = None
    recommendations: List[str] = None

    def __post_init__(self):
        if self.atomic_claims is None:
            self.atomic_claims = []
        if self.evidences is None:
            self.evidences = []
        if self.verified_facts is None:
            self.verified_facts = []
        if self.disputed_claims is None:
            self.disputed_claims = []
        if self.narrative_analysis is None:
            self.narrative_analysis = {}
        if self.risk_signals is None:
            self.risk_signals = []
        if self.recommendations is None:
            self.recommendations = []
        if not self.analysis_date:
            self.analysis_date = datetime.now().strftime("%Y-%m-%d")


class ChinaFinancialAnalyzer:
    """中国金融市场信息分析引擎"""

    def __init__(self):
        # 事实指标词
        self.fact_signals = [
            "财报显示", "公告称", "数据为", "会议记录", "监管文件",
            "审计报告", "实际发生", "根据", "披露", "报告期内"
        ]

        # 观点指标词
        self.opinion_signals = [
            "预计", "有望", "可能", "据传", "市场认为", "分析师认为",
            "估值合理", "前景看好", "预期", "预测", "看好", "看空"
        ]

        # 模糊表述（高风险）
        self.vague_signals = [
            "大幅", "显著", "明显", "众多", "若干", "相关", "有关",
            "据悉", "消息人士", "知情人士", "接近", "左右"
        ]

        # 概念炒作关键词
        self.hype_keywords = [
            "重磅", "爆发", "颠覆", "革命性", "突破性", "全球领先",
            "国产替代", "卡脖子", "填补空白", "世界首创", "弯道超车"
        ]

        # 信息源可信度权重
        self.source_credibility_weights = {
            SourceType.REGULATORY: 1.0,
            SourceType.COMPANY_OFFICIAL: 0.85,
            SourceType.MAINSTREAM_MEDIA: 0.7,
            SourceType.RESEARCH_INSTITUTION: 0.6,
            SourceType.SOCIAL_MEDIA: 0.3,
            SourceType.ANONYMOUS: 0.2
        }

        # 证据等级可信度
        self.evidence_level_credibility = {
            EvidenceLevel.A: 0.95,
            EvidenceLevel.B: 0.85,
            EvidenceLevel.C: 0.70,
            EvidenceLevel.D: 0.50,
            EvidenceLevel.E: 0.25
        }

    def decompose_statement(self, statement: str) -> List[AtomicClaim]:
        """
        分解声明为原子声明
        
        Args:
            statement: 原始声明文本
            
        Returns:
            原子声明列表
        """
        claims = []

        # 识别实体
        entities = self._extract_entities(statement)
        for i, entity in enumerate(entities):
            claims.append(AtomicClaim(
                id=f"E{i+1}",
                claim_type=ClaimType.ENTITY,
                content=f"存在实体：{entity}",
                verifiability="高"
            ))

        # 识别事件
        events = self._extract_events(statement)
        for i, event in enumerate(events):
            claims.append(AtomicClaim(
                id=f"V{i+1}",
                claim_type=ClaimType.EVENT,
                content=event,
                verifiability="中"
            ))

        # 识别预测
        forecasts = self._extract_forecasts(statement)
        for i, forecast in enumerate(forecasts):
            claims.append(AtomicClaim(
                id=f"F{i+1}",
                claim_type=ClaimType.FORECAST,
                content=forecast,
                verifiability="低"
            ))

        # 识别因果关系
        causations = self._extract_causations(statement)
        for i, causation in enumerate(causations):
            claims.append(AtomicClaim(
                id=f"C{i+1}",
                claim_type=ClaimType.CAUSATION,
                content=causation,
                verifiability="低"
            ))

        return claims

    def _extract_entities(self, text: str) -> List[str]:
        """提取实体"""
        entities = []
        # 简化实现：识别公司名称模式
        company_patterns = [
            r'[\u4e00-\u9fa5]{2,10}(?:股份)?(?:有限)?公司',
            r'[\u4e00-\u9fa5]{2,6}集团'
        ]
        for pattern in company_patterns:
            matches = re.findall(pattern, text)
            entities.extend(matches)
        return list(set(entities))

    def _extract_events(self, text: str) -> List[str]:
        """提取事件"""
        events = []
        event_keywords = ["获得", "发布", "签署", "完成", "启动", "公布"]
        sentences = re.split(r'[,，。；;]', text)
        for sentence in sentences:
            if any(kw in sentence for kw in event_keywords):
                events.append(sentence.strip())
        return events

    def _extract_forecasts(self, text: str) -> List[str]:
        """提取预测"""
        forecasts = []
        forecast_keywords = ["预计", "有望", "将", "预期", "预测"]
        sentences = re.split(r'[,，。；;]', text)
        for sentence in sentences:
            if any(kw in sentence for kw in forecast_keywords):
                forecasts.append(sentence.strip())
        return forecasts

    def _extract_causations(self, text: str) -> List[str]:
        """提取因果关系"""
        causations = []
        causation_patterns = [
            r'(.+?)(?:因为|由于|受|因)(.+?)(?:,|。|$)',
            r'(.+?)(?:导致|使得|引发)(.+?)(?:,|。|$)'
        ]
        for pattern in causation_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                causations.append(f"{match[0].strip()} → {match[1].strip()}")
        return causations

    def classify_statement(self, text: str) -> Tuple[str, float]:
        """
        分类声明为事实或观点
        
        Args:
            text: 声明文本
            
        Returns:
            (分类结果, 置信度)
        """
        fact_score = 0
        opinion_score = 0

        # 计算事实信号
        for signal in self.fact_signals:
            if signal in text:
                fact_score += 1

        # 计算观点信号
        for signal in self.opinion_signals:
            if signal in text:
                opinion_score += 1

        # 检测模糊表述
        vague_count = sum(1 for signal in self.vague_signals if signal in text)

        # 综合判断
        if fact_score > opinion_score and vague_count < 2:
            return ("事实", 0.7 + (fact_score * 0.1))
        elif opinion_score > fact_score:
            return ("观点", 0.6 + (opinion_score * 0.1))
        else:
            return ("混合", 0.5)

    def evaluate_evidence(self, evidence: Evidence) -> float:
        """
        评估证据可信度
        
        Args:
            evidence: 证据对象
            
        Returns:
            可信度评分 (0-1)
        """
        # 基础可信度
        base_credibility = self.evidence_level_credibility[evidence.evidence_level]

        # 信息源权重
        source_weight = self.source_credibility_weights[evidence.source_type]

        # 综合评分
        overall_credibility = (base_credibility * 0.6) + (source_weight * 0.4)

        return min(overall_credibility, 1.0)

    def detect_manipulation_signals(self, statement: str, context: Dict = None) -> List[str]:
        """
        检测市场操纵信号
        
        Args:
            statement: 声明文本
            context: 上下文信息（时间、股价变动等）
            
        Returns:
            风险信号列表
        """
        signals = []

        # 检测概念炒作
        hype_count = sum(1 for kw in self.hype_keywords if kw in statement)
        if hype_count >= 3:
            signals.append("高密度概念炒作词汇（疑似热点蹭概念）")

        # 检测模糊表述
        vague_count = sum(1 for signal in self.vague_signals if signal in statement)
        if vague_count >= 3:
            signals.append("大量模糊表述（信息透明度不足）")

        # 检测无证据因果关系
        if "因为" in statement or "由于" in statement or "受" in statement:
            if not any(signal in statement for signal in self.fact_signals):
                signals.append("无证据支持的因果关系声明")

        # 检测时间同步性（需要上下文数据）
        if context and context.get("price_spike"):
            if context.get("news_time_diff_minutes", 0) < 30:
                signals.append("消息发布与股价异动高度同步（疑似内幕交易）")

        return signals

    def calculate_overall_confidence(self, claims: List[AtomicClaim],
                                      evidences: List[Evidence]) -> Tuple[float, ConfidenceLevel]:
        """
        计算综合可信度
        
        Args:
            claims: 原子声明列表
            evidences: 证据列表
            
        Returns:
            (综合可信度评分, 置信度等级)
        """
        if not claims:
            return (0.0, ConfidenceLevel.UNCERTAIN)

        # 计算已验证声明比例
        verified_count = sum(1 for claim in claims if claim.verified)
        verification_rate = verified_count / len(claims)

        # 计算证据平均可信度
        if evidences:
            evidence_credibility = sum(self.evaluate_evidence(e) for e in evidences) / len(evidences)
        else:
            evidence_credibility = 0.0

        # 综合评分
        overall_score = (verification_rate * 0.5) + (evidence_credibility * 0.5)
        overall_score = overall_score * 100  # 转换为百分制

        # 确定置信度等级
        if overall_score >= 90:
            level = ConfidenceLevel.CERTAIN
        elif overall_score >= 75:
            level = ConfidenceLevel.HIGHLY_PROBABLE
        elif overall_score >= 60:
            level = ConfidenceLevel.PROBABLE
        elif overall_score >= 40:
            level = ConfidenceLevel.UNCERTAIN
        elif overall_score >= 20:
            level = ConfidenceLevel.LIKELY_FALSE
        else:
            level = ConfidenceLevel.FALSE

        return (overall_score, level)

    def generate_recommendations(self, confidence_score: float,
                                  risk_signals: List[str]) -> List[str]:
        """
        生成投资决策建议
        
        Args:
            confidence_score: 综合可信度评分
            risk_signals: 风险信号列表
            
        Returns:
            建议列表
        """
        recommendations = []

        if confidence_score >= 80:
            recommendations.append("信息基本可信，可作为决策参考")
            recommendations.append("建议持续跟踪公司后续公告及监管动态")
        elif confidence_score >= 50:
            recommendations.append("信息存在不确定性，需进一步验证")
            recommendations.append("建议等待官方公告或第三方独立验证")
            recommendations.append("谨慎决策，控制仓位")
        else:
            recommendations.append("信息存在重大疑点，不建议作为决策依据")
            recommendations.append("高度关注是否涉及市场操纵或虚假陈述")

        if risk_signals:
            recommendations.append(f"识别到 {len(risk_signals)} 个风险信号，建议审慎对待")

        return recommendations

    def analyze(self, statement: str, company_name: str = "",
                context: Dict = None) -> AnalysisReport:
        """
        完整分析流程
        
        Args:
            statement: 待分析的声明
            company_name: 公司名称
            context: 上下文信息
            
        Returns:
            分析报告
        """
        # 分解声明
        atomic_claims = self.decompose_statement(statement)

        # 检测操纵信号
        risk_signals = self.detect_manipulation_signals(statement, context)

        # 分类每个原子声明
        for claim in atomic_claims:
            claim_type, confidence = self.classify_statement(claim.content)
            claim.confidence = confidence

        # 计算综合可信度（此处使用简化逻辑，实际需要证据支持）
        overall_score, confidence_level = self.calculate_overall_confidence(
            atomic_claims, []
        )

        # 生成建议
        recommendations = self.generate_recommendations(overall_score, risk_signals)

        # 构建报告
        report = AnalysisReport(
            original_statement=statement,
            company_name=company_name,
            atomic_claims=atomic_claims,
            risk_signals=risk_signals,
            overall_confidence=overall_score,
            confidence_level=confidence_level,
            recommendations=recommendations
        )

        return report

    def export_report_markdown(self, report: AnalysisReport) -> str:
        """
        导出 Markdown 格式报告
        
        Args:
            report: 分析报告
            
        Returns:
            Markdown 文本
        """
        md = f"""# 【{report.company_name or '未命名'}】信息验证报告

## 一、声明原文
{report.original_statement}

## 二、原子声明分解
| 编号 | 声明类型 | 声明内容 | 可验证性 | 置信度 |
|------|----------|----------|----------|--------|
"""
        for claim in report.atomic_claims:
            status = "✓已验证" if claim.verified else "?待验证"
            md += f"| {claim.id} | {claim.claim_type.value} | {claim.content} | {claim.verifiability} | {claim.confidence:.0%} |\n"

        md += f"""
## 三、风险信号
"""
        if report.risk_signals:
            for signal in report.risk_signals:
                md += f"- ⚠️ {signal}\n"
        else:
            md += "- 未检测到明显风险信号\n"

        md += f"""
## 四、综合评级
- **综合可信度评分**: {report.overall_confidence:.1f}/100
- **置信度等级**: {report.confidence_level.value}
- **分析日期**: {report.analysis_date}

## 五、投资决策建议
"""
        for rec in report.recommendations:
            md += f"- {rec}\n"

        md += """
---
*本报告由 EasyClaw China Financial Analyzer 自动生成*
"""
        return md


# CLI 接口
if __name__ == "__main__":
    import sys

    analyzer = ChinaFinancialAnalyzer()

    # 示例分析
    if len(sys.argv) > 1:
        statement = sys.argv[1]
        company = sys.argv[2] if len(sys.argv) > 2 else ""
    else:
        # 默认示例
        statement = "某新能源公司因技术突破获得政府补贴，预计明年业绩将翻倍，已引发多家机构调研"
        company = "某新能源公司"

    report = analyzer.analyze(statement, company)
    markdown_report = analyzer.export_report_markdown(report)

    print(markdown_report)
    print("\n" + "="*50)
    print("原子声明详情（JSON）:")
    
    # 转换 Enum 为字符串以便序列化
    claims_dict = []
    for c in report.atomic_claims:
        claim_dict = asdict(c)
        claim_dict['claim_type'] = c.claim_type.value
        claims_dict.append(claim_dict)
    
    print(json.dumps(claims_dict, ensure_ascii=False, indent=2))
