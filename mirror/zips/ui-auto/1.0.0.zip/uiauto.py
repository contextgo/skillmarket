#!/usr/bin/env python3
"""
执行ui自动化
"""
from seliky.natural_langurage import NaturalLanguage
import argparse
import sys


def uiclaw(prompt: str) -> str:
    """网页自动化操作"""
    return NaturalLanguage().claw(prompt)

def main():
    parser = argparse.ArgumentParser(description="页面操作提示词")
    parser.add_argument("prompt", help="传入提示词")
    args = parser.parse_args()
    prompt= args.prompt
    return uiclaw(prompt)


if __name__ == "__main__":
    exit(main())
