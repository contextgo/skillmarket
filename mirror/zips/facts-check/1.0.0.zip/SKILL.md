---
name: "manuscript-factcheck-web-facts-only"
description: "Checks Chinese manuscripts and DOCX files for factual accuracy only. Trigger when the user wants names, places, organizations, titles in 《》, dates, timelines, affiliations, amounts, counts, proportions, increases, decreases, rankings, and other factual claims verified through web search, without grammar, wording, punctuation, or style correction."
---

# Chinese Manuscript Fact Check With Web Search Facts Only

Use this skill when the user wants a pure fact-check report and does not want language polishing, rewriting, or stylistic suggestions.

## Quick start

1. Collect the manuscript.
- Accept a pasted passage, a file path, or a `.docx` file.
- Preserve paragraph order and original wording for quotation in the report.

2. If the input is `.docx`, extract plain text first.
- On macOS, prefer `textutil -convert txt -stdout "<file>.docx"` when available.
- If that fails, use another deterministic extractor available in the environment.
- Ignore footers, styles, and revision markup unless the user explicitly asks to inspect them.

3. Set the scope.
- Default output is a fact-check report only.
- Do not produce a revised draft unless the user explicitly asks for one in a follow-up request.

## Workflow

### 1. Build a fact checklist

Before searching, scan the manuscript and list factual items that need checking:
- person names
- place names
- organization or institution names
- titles inside `《》`
- dates, years, dynasties, terms of office, and event order
- roles, affiliations, awards, publications, and counts
- amounts, percentages, ratios, rankings, totals, subtotals, increases, decreases, and comparisons

Treat every specific number as a factual claim unless the user clearly says it is illustrative or fictional.

### 2. Run an internal factual consistency pass

Check the manuscript itself for:
- inconsistent naming
- conflicting dates
- mismatched event order
- title variants used as if they were the same work
- role or affiliation drift across paragraphs
- totals that do not match component numbers
- percentage or increase statements that do not match the stated base value
- number-unit mismatches such as `亿元`, `万元`, `人次`, `个百分点`

Only note inconsistencies that bear on factual correctness.

### 3. Run mandatory web verification with web search

Use the configured web search capability for every uncertain, specific, or time-sensitive factual claim.

Minimum standard:
- For key claims, try to confirm with at least two sources.
- Prefer at least one primary or authoritative source when possible.
- When sources disagree, report the conflict instead of forcing a single answer.
- Verify the number itself whenever a sentence contains a specific amount, count, ratio, ranking, or change and a source is available.
- Provide concrete source page URLs, not only site names, search keywords, or general domains.
- A citation is valid only if it includes the full URL beginning with `http://` or `https://`.
- Separate sources into `主证据` and `辅证据` in the final report.
- Use `主证据` for official or original materials such as `gov.cn` pages, official department sites, statistical bulletins, annual reports, original tables, laws, regulations, publisher pages, museum/archive/university pages, or other primary documents.
- Use `辅证据` for media reports, reposts, encyclopedia summaries, or secondary commentary.
- Never place media platforms, news portals, reposts, blogs, or social platforms such as Sohu, Sina, NetEase, Tencent News, Toutiao, Baijiahao, WeChat public account reposts, or similar secondary pages under `主证据`.
- Do not treat media reports as enough for a high-confidence conclusion when a relevant official or original source should exist but was not found.
- If no official or original source is found, explicitly write `主证据：未找到官方/原始资料` and keep the conclusion conservative.

Search strategy:
- For names and institutions, search both the exact Chinese form and a likely official full name.
- For titles inside `《》`, search the exact title first, then add author, publisher, outlet, year, or medium.
- For dates and events, search the event name together with the claimed date or year.
- For numeric claims, search the exact figure together with the subject, time period, and unit.
- For claims involving government departments, regions, public data, policy, administrative events, or public institutions, first search official domains and primary pages using terms such as `site:gov.cn`, `site:<local-government-domain>`, `统计公报`, `年鉴`, `公告`, `通知`, `原文`, `全文`, `政务公开`.
- If the figure appears in a report or bulletin, find the original table, notice, annual report, statistical communiqué, or official news release rather than relying on second-hand summaries.
- When the manuscript states both a change amount and a resulting total, check whether the arithmetic is internally consistent.
- When web search returns broad summaries, open the underlying source pages before confirming an exact name, title, date, or affiliation.
- When web search returns a numeric snippet, open the source page and confirm the same number, unit, and time range.
- Prefer Chinese authoritative pages first when the manuscript is about Chinese people, institutions, policies, or publications.

### 4. Produce a fact-only report

Follow the output contract in `references/output-format.md`.

Report only:
- factual errors
- unresolved factual claims
- internal factual inconsistencies
- numeric inconsistencies
- wording that is too ambiguous to support factual verification

Before finalizing the report, run a citation self-check:
- Every `主证据` and `辅证据` entry must contain a full `http://` or `https://` URL.
- If an entry has only a site name, article title, organization name, domain, or search keyword, remove it or mark it as not found.
- If a source is media, reposted, encyclopedic, or commentary material, it must be under `辅证据`, not `主证据`.
- If `主证据` contains no valid official/original full URL, write `主证据：未找到官方/原始资料`.
- Do not make a high-confidence correction from `辅证据` alone when the claim should be verifiable from an official/original source.

Do not include:
- grammar suggestions
- wording improvements
- punctuation fixes
- logic or style edits unrelated to factual correctness
- a revised draft

## Guardrails

- Do not invent missing facts.
- Do not let a grammar or style suggestion replace factual verification.
- Do not silently "fix" a title inside `《》` unless the correction is supported by sources.
- Do not treat a search-result snippet as sufficient proof when an exact name, title, date, or number matters.
- Do not cite only a search result or homepage; cite the specific page URL used for verification.
- Do not cite a source without a full `http://` or `https://` URL.
- Do not cite only a publication name, article title, author name, date, or domain.
- Do not mix official/original sources and media/reposts in a single undifferentiated `来源` field.
- Do not treat an amount, count, percentage, ranking, or increase as probably correct just because the sentence reads smoothly.
- Do not classify a numeric sentence as non-factual when the number itself has not been checked.
- Do not include ordinary prose cleanup in the report.
- If a claim remains unresolved, mark it as `存疑，需人工确认`.

## References

- Source selection and query policy: `references/source-policy.md`
- Fact-only output contract: `references/output-format.md`
