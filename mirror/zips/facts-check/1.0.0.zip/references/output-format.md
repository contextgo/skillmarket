# Output Format

Use this format unless the user asks for a different layout.

## Section 1: 事实核查问题

For each fact-check issue, use this compact structure:

```md
### 事实问题 N
- 原文：…
- 类型：事实核查 / 数字核查 / 时间线 / 专名 / 书名号内容
- 判断：…
- 建议修改：…
- 主证据：<网页标题或来源名>：<具体 URL>（确认内容：…）
- 辅证据：<网页标题或来源名>：<具体 URL>（确认内容：…）
```

Rules:
- Quote only the minimum necessary part of the original sentence.
- Do not place grammar, wording, punctuation, or style-only comments in this section.
- If the sentence contains a specific number, amount, ratio, increase, decrease, or ranking, treat it as a fact issue unless it is clearly fictional or illustrative.
- Include concrete webpage URLs beginning with `http://` or `https://`, not just site names, article titles, authors, dates, or general domains.
- Put official and original sources under `主证据`, such as `gov.cn`, local government sites, official department pages, statistical bulletins, annual reports, laws, regulations, original tables, publisher pages, university/museum/archive pages, or other primary documents.
- Put media reports, reposts, encyclopedia summaries, databases, or secondary commentary under `辅证据`.
- Never put Sohu, Sina, NetEase, Tencent News, Toutiao, Baijiahao, WeChat public account reposts, or other media/platform pages under `主证据`.
- If no official or original source is found, write `主证据：未找到官方/原始资料`.
- If the fact cannot be confirmed, write `判断：存疑，需人工确认`.
- If no useful secondary source is needed, write `辅证据：无`.
- A source entry without a full URL is invalid and must be rewritten or removed before final output.

Invalid example:

```md
- 主证据：九江影像志（搜狐·冯晓晖，2022年4月1日）明确记载…
```

Valid example:

```md
- 主证据：未找到官方/原始资料
- 辅证据：九江影像志：https://www.sohu.com/a/...（确认内容：文章称年吞吐能力为70万吨）
```

## Section 2: 核查说明

Close with a short note:

```md
## 核查说明
- 已联网核查的重点：人名、机构名、书名号内容、时间与事件对应关系、金额与数量表述
- 未能完全确认的项目：…
- 主证据覆盖情况：…
- 处理原则：仅报告事实问题，不处理语法和用词
```

## Optional lightweight mode

If the user wants a faster pass, return only:
- `高风险事实问题`
- `存疑项`
