# Source Policy

Use this file only when you need guidance on search quality, source ranking, or ambiguous cases.

## Source classes

Use two source classes in the final report.

### 主证据

`主证据` means official, original, or primary material. Prefer it for final judgments.

Examples:
- `gov.cn` pages
- local government sites such as province, city, county, and department domains
- official department, bureau, court, university, museum, archive, library, publisher, or journal pages
- laws, regulations, notices, gazettes, public bulletins, statistical communiqués, yearbooks, annual reports, original tables, and full-text announcements
- original pages from the institution or person directly involved

### 辅证据

`辅证据` means secondary or contextual material.

Examples:
- media reports
- reposts
- encyclopedia summaries
- database summaries
- commentary articles
- news aggregators
- media or platform pages such as Sohu, Sina, NetEase, Tencent News, Toutiao, Baijiahao, WeChat public account reposts, and similar secondary pages

Use `辅证据` to supplement context, identify search leads, or corroborate a low-risk claim. Do not let it replace `主证据` when a relevant official or original source should exist.

## Source priority

Prefer sources in roughly this order:

1. official institution pages
2. government or court sites
3. publisher, journal, museum, archive, university, or library pages
4. original reporting from established media
5. reputable reference databases or encyclopedic summaries

For government, policy, public data, administrative events, and institution claims, search for `主证据` first. If none is found, say so explicitly.

Use caution with:
- reposts
- scraped mirror sites
- forum posts
- self-published summaries without citations
- AI-generated summary pages that do not expose the underlying source

## Query patterns

### Names

Use exact-match queries first:
- `"<name>" <organization>`
- `"<name>" 职务`
- `"<name>" 官方`
- `"<name>" site:gov.cn`
- `"<name>" "<organization>" 官方`

When the manuscript may contain a mistranscription:
- search the visible form
- search likely variants
- search the claimed organization plus role

### Titles inside `《》`

Start with:
- `"<title>"`
- `"<title>" 作者`
- `"<title>" 出版社`
- `"<title>" 刊物`
- `"<title>" 年份`

If the title is common or ambiguous:
- add genre, medium, or period
- check whether the manuscript confuses a book, article, policy document, speech, or film

### Dates and events

Use:
- `"<event>" "<year>"`
- `"<event>" "<full date>"`
- `"<person>" "<event>" "<year>"`
- `"<event>" "<year>" site:gov.cn`
- `"<event>" 公告`
- `"<event>" 通知`
- `"<event>" 原文`

When checking chronology:
- verify the event date
- verify the publication date of the source
- verify whether the text confuses announcement date, implementation date, or occurrence date

### Numeric claims

Use:
- `"<subject>" "<number>" "<unit>"`
- `"<subject>" 增加 "<number>" "<unit>"`
- `"<subject>" 同比 "<number>"`
- `"<subject>" 统计公报`
- `"<subject>" 年报`
- `"<subject>" "<number>" "<unit>" site:gov.cn`
- `"<subject>" "<number>" "<unit>" 统计公报`
- `"<subject>" "<number>" "<unit>" 年鉴`

When checking amounts and counts:
- confirm the exact number
- confirm the unit
- confirm the relevant time period
- confirm whether the number is cumulative, annual, quarterly, monthly, or point-in-time
- confirm whether the text confuses absolute change with growth rate

When possible, prefer original tables, bulletins, annual reports, statistical yearbooks, or official announcements over narrative summaries.

## URL requirements

For every cited source, include:
- source class: `主证据` or `辅证据`
- page title or source name
- concrete URL to the specific page used, beginning with `http://` or `https://`
- short note on what the page confirms

Do not cite:
- a search results page
- only a homepage
- only a domain name
- a vague source label such as `政府网站` or `新闻报道`
- an article title without a URL
- an author/date/source-name description without a URL

Invalid citation examples:
- `九江影像志（搜狐·冯晓晖，2022年4月1日）`
- `中国口岸协会（caop.org.cn，2019年）`
- `来源：搜狐`
- `来源：gov.cn`

Valid citation examples:
- `主证据：<页面标题>：https://www.gov.cn/...（确认内容：...）`
- `辅证据：<页面标题>：https://www.sohu.com/a/...（确认内容：...）`

## Conflict handling

When two credible sources disagree:
- prefer the more primary source
- prefer the source closer to the event
- mention the disagreement in the issue list
- avoid pretending the conflict is resolved if it is not

## Citation rules

In the final report, include source links only for claims you actually checked.
Keep citations attached to the relevant issue rather than dumping a long unrelated list.
Separate `主证据` from `辅证据`. If `主证据` is missing, write `主证据：未找到官方/原始资料` rather than silently replacing it with media reports.
Before finalizing, scan every citation. If any cited item lacks a full `http://` or `https://` URL, it is not a valid citation and must not be presented as evidence.
