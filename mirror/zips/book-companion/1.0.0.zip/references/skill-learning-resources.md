# OpenClaw Skill 学习资源

## 入门必读（官方/半官方）

| 资源 | 链接 | 适合谁 |
|---|---|---|
| SKILL.md 写作完全指南 | https://www.qclaw.run/zh/skill-md-xiezuo/ | 最通俗易懂的入门教程，从零教你怎么写第一个 Skill |
| 腾讯云官方解析：技能即文档 | https://cloud.tencent.com/developer/article/2638891 | 设计哲学和工程原理，理解 Skill 为什么是 Markdown 而不是代码 |
| OpenClaw 技能系统指南（GitHub 中文版） | https://github.com/KimYx0207/Claude-Code-x-OpenClaw-Guide-Zh/blob/main/docs/openclaw/06-%E6%8A%80%E8%83%BD%E7%B3%BB%E7%BB%9F%E6%8C%87%E5%8D%97.md | 完整体系讲解，含多 Agent 场景 |
| 阿里云：完全手册 | https://developer.aliyun.com/article/1718819 | 全生命周期管理（创建→打包→发布→调试） |

## 进阶实战

| 资源 | 链接 | 亮点 |
|---|---|---|
| SegmentFault 实战教程 | https://segmentfault.com/a/1190000047666689 | 以 AWS 成本监控为例，完整走一遍开发流程 |
| 美来：构建规范 Skill | https://www.meilai.com/openclaw-skill.html | 教你怎么省 80% Token 消耗，优化 Skill 质量 |
| OpenClaw101 技能入门 | https://www.openclaw101.club/docs/advanced/skills | 快速上手，5 分钟创建第一个 Skill |
