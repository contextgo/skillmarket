---
name: uk8s-del
description: 删除 UCloud UK8S Kubernetes 集群。Use when user asks to "删除 UK8S 集群", "delete UK8S cluster", "销毁集群".
argument-hint: "<cluster-id>"
disable-model-invocation: true
allowed-tools: Bash(ucloud *), Bash(which *), Read, AskUserQuestion
---

# 删除 UK8S 集群

通过 `ucloud-cli` 调用 `DelUK8SCluster` 删除集群。**此操作不可逆**，执行前必须二次确认。

- `$ARGUMENTS` 为 ClusterId，**必填**；若未提供，用 `AskUserQuestion` 询问

---

## Step 1：检查 ucloud-cli 环境

按 [`references/check-ucloud-cli.md`](references/check-ucloud-cli.md) 执行环境检查。

---

## Step 2：确认 ClusterId

若 `$ARGUMENTS` 为空，用 `AskUserQuestion` 询问：

```
请输入要删除的集群 ID（如 uk8s-xxxxxxxx）：
```

记录 `ClusterId`。

---

## Step 3：查询集群信息

删除前先查询集群基本信息，让用户确认目标正确：

```bash
ucloud api --Action ListUK8SClusterV2 --Region <Region> --ProjectId <ProjectId> --ClusterId <ClusterId>
```

若 RetCode 非 0 或 ClusterSet 为空，提示集群不存在，终止流程。

记录并展示：ClusterName、Status、K8sVersion、NodeCount。

若 `DeleteProtection=1`，提示用户需先关闭删除保护，终止流程。

---

## Step 4：收集删除选项

用 `AskUserQuestion` 询问以下两项：

**是否同时删除节点数据盘（ReleaseUDisk）：**
- 否（false，默认）
- 是（true）

**是否同时删除节点 EIP（ReleaseEIP）：**
- 否（false，默认）
- 是（true）

---

## Step 5：二次确认

展示完整删除摘要，等待用户最终确认：

```
⚠️  即将删除 UK8S 集群，此操作不可逆！

集群 ID:    <ClusterId>
集群名称:   <ClusterName>
K8s 版本:   <Version>
当前状态:   <Status>
Node 数量:  <NodeCount>

删除数据盘: <是/否>
删除 EIP:   <是/否>

确认删除？(y/n)
```

用 `AskUserQuestion` 等待用户确认。若回答非 y，终止流程并提示"已取消删除"。

---

## Step 6：执行删除

读取 [`references/DelUK8SCluster.md`](references/DelUK8SCluster.md) 了解请求结构。

```bash
ucloud api --Action DelUK8SCluster \
  --Region <Region> \
  --ProjectId <ProjectId> \
  --ClusterId <ClusterId> \
  --ReleaseUDisk <true/false> \
  --ReleaseEIP <true/false>
```

| RetCode | 处理 |
|---------|------|
| 0 | 进入 Step 7 |
| 非 0 | 输出完整 RetCode + Message，终止流程 |

---

## Step 7：结果输出

```
集群删除请求已提交。

集群 ID:   <ClusterId>
集群名称:  <ClusterName>

集群删除中，预计 3-5 分钟完成。
查看状态：
ucloud api --Action ListUK8SClusterV2 \
  --Region <Region> \
  --ProjectId <ProjectId> \
  --ClusterId <ClusterId>
```

---

## 错误处理原则

- 不允许吞错误，必须输出 RetCode + Message
- 集群处于 DELETING 状态时提示用户无需重复操作
- 集群开启删除保护（DeleteProtection=1）时，在 Step 3 提前终止并告知如何关闭
