# 删除UK8S集群-DelUK8SCluster

删除UK8S集群

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|地域。 参见 [地域和可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|**Yes**|
|ProjectId|string|项目ID。不填写为默认项目，子帐号必须填写。 请参考[GetProjectList接口](https://docs.ucloud.cn/api/summary/get_project_list)|No|
|ClusterId|string|集群id|**Yes**|
|ReleaseUDisk|bool|是否删除节点挂载的数据盘。枚举值[true:删除，false: 不删除]，默认不删除|No|
|ReleaseEIP|string|是否删除节点绑定的EIP。枚举值[true:删除，false: 不删除]，默认不删除|No|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|

# Request Example
```
https://api.ucloud.cn/?Action=DelUK8SCluster
&Region=cn-zj
&ProjectId=gXOHVanX
&ClusterId=BQOqCuFk
&ReleaseUDisk=true
&ReleaseEIP=OAKBPfZe
```

# Response Example
```
{
    "Action": "DelUK8SClusterResponse", 
    "RetCode": 0
}
```