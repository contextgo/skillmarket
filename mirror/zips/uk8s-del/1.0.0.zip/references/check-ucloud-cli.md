# 检查 ucloud-cli 环境

```bash
which ucloud && ucloud config list
```

| 状态 | 操作 |
|------|------|
| 未安装 | 提示用户先安装 ucloud-cli，终止流程 |
| 已安装但未配置 | 进入配置步骤 |
| 已安装且已配置 | 直接进入下一步 |

必须包含：`public_key`、`private_key`、`region`、`zone`、`project_id`

若缺失，用 `AskUserQuestion` 获取后执行：

```bash
ucloud config set --region <Region> --zone <Zone> --project-id <ProjectId>
```

**记录 `Region`、`Zone`、`ProjectId`，后续步骤必须使用。**

