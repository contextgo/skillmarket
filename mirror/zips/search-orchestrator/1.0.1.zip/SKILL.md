---
name: search-orchestrator
description: >
  零配置智能搜索编排器 v4.0。discover.js 自动发现所有搜索工具，全量纳入并行调用——装了什么搜什么，
  新装 Skill 自动生效，零配置介入。按查询复杂度自适应调度：简单事实秒级快查，常规搜索全引擎覆盖，
  深度研究多轮迭代挖到充分才停。语言标签仅为偏好提示非硬性过滤。每条结论至少 2 个独立源，
  回复末尾标注完整搜索链路。把你分散的各种搜索能力变成一个自动全阵线、永不遗漏的协作团队。
  触发：任何需要查资料、搜信息、核事实、做对比、深研究的请求。
metadata:
  openclaw:
    emoji: "🔍"
    requires:
      bins: ["node"]
      env: []
---

# Universal Search — 通用搜索编排器 v4.0

**强制默认搜索引擎。discover.js 是唯一真相来源——它发现什么就调用什么。preferred_tools 只影响排序不影响是否调用。装了新 Skill 自动生效。**

---

## 核心铁律

1. **先发现，再搜索** — 首次搜索时运行 `discover.js --cache`，后续用缓存
2. **全量纳入，一个不漏** — discover.js 返回的所有 ready 搜索工具全部并行调用（不限数量）
3. **preferred_tools 只是排序建议** — 排前面的先调，不排的照样调
4. **零配置接入新 Skill** — 用户安装任何搜索 Skill → discover.js 自动发现 → search_orchestrator_catch_all 自动纳入 → 无需改配置
5. **复杂度自适应** — 简单事实查证不走深度流程，复杂研究不偷懒
6. **独立源 ≥2** — 每条核心结论最少 2 个独立源（同一网站多篇文章 = 1 源）
7. **来源必标** — 回复末尾注明完整搜索链路
8. **降级不中断** — 缺工具自动降级，绝不因配置报错停止

---

## 第〇步：环境检测（建索引，优先走缓存）

```bash
node skills/search-orchestrator/scripts/discover.js --pretty --cache
```

- 首次运行：扫描 1-3 秒，写入 `/tmp/search-orchestrator-cache.json`
- 后续 1 小时内：秒级缓存命中，`cache_hit: true`
- 手动强制刷新：加 `--force`

读取输出的 `ready` 数组，每个工具包含 `id`、`strengths`（能力标签）、`coverage`、`depth`、`skillPath`、`call.template`。

**重要：** `ready` 列表包含该机器上当前安装的**所有可用搜索工具**。新安装的 Skill 会在下次 discover 时自动出现。

---

## 第一步：复杂度分级（关键！避免小题大做）

在意图分类之前，先判断查询复杂度：

### L0 — 快速查证（跳过深度）
**特征：** 单一事实、有标准答案、无争议可能、非时效敏感或时效信息易得

| 示例 | 处理 |
|------|------|
| "Python最新版本是多少？" | 1 工具搜索 → 验证 → 返回 |
| "北京到上海高铁多久？" | 1 工具搜索 + web_fetch 验证 → 返回 |

**快速路径流程：**
```
1 个工具搜索 → 有明确答案？
  ├─ 是 → 用 web_fetch 快速验证 → 输出
  └─ 否（结果模糊/矛盾）→ 升级到 L1 标准流程
```

### L1 — 标准搜索（大多数查询）
→ 进入**第二步**完整流程

### L2 — 深度研究
**特征：** 复杂主题、需要全面了解、用户明确要分析报告/综述
→ 进入**第二步**完整流程 + 深度不收敛不停止

**判断规则：** 不确定 L0 还是 L1 时走 L1（宁可多搜不错过）。

---

## 第二步：意图分类 → 工具选择

根据用户查询特征匹配意图（完整规则见 `references/intent-routing.json`）。

**意图决定 preferred_tools 排序，但不限制最终工具集。**

```
意图            → 偏好排序（先调用）                    → 深度上限
geographic      → amap-lbs                            → 3轮
chinese_news    → baidu, minimax                      → 5轮
chinese_general → baidu, minimax                      → 4轮
english_news    → tavily, web_search                   → 5轮
technical       → web_search, web_fetch               → 4轮
fact_check      → web_search, web_fetch               → 5轮
comparative     → web_search                          → 3轮
deep_research   → web_search, web_fetch               → 4轮
english_general → web_search                          → 4轮
default         → web_search                          → 3轮
```

### 工具匹配优先级 (v4.0 — 全量纳入)

**核心原则：先排序，后全收。preferred_tools 只决定谁先调，不决定谁不调。**

```
1. preferred_tools 中所有 status=ready 的工具 → 主工具集（优先排序）
2. 剩余 ready 工具中与 required + supplementary capabilities 有交集的 → 补充工具集
3. 【关键】再遍历 discover.js 全部 ready 工具 → 尚未纳入的全部追加（零遗漏）
4. 唯一排除：纯地理工具（仅有 geographic 标签）在非地理意图时可跳过
5. 最终工具列表 = 主集 ∪ 补充集 ∪ 自动发现集 → 全部并行执行
6. 0 个 ready → 告知用户 → 降级为 web_fetch 定向抓取
```

**自动发现规则：** 用户安装新搜索 Skill 后，其调用流程为：
```
安装 Skill → discover.js 下次扫描自动发现 → 出现在 ready 列表
→ search_orchestrator_catch_all 第3步自动纳入 → 下次搜索直接用
```
**无需碰 intent-routing.json 或 SKILL.md。**

**跨语言规则：** 语言标签（chinese/english）为偏好提示，非硬性过滤。Tavily 搜中文、Baidu 搜英文都是合法用法。

### 🔑 工具调用转换规则（如何把 discover 输出变成实际调用）

**builtin 工具** → 直接用 OpenClaw 系统工具：

| discover id | 系统工具调用 |
|-------------|------------|
| `builtin:web_search` | `web_search(query, count, ...)` |
| `builtin:web_fetch` | `web_fetch(url, extractMode, ...)` |
| `builtin:browser` | `browser(action, url, ...)` |

**skill 工具** → shell 命令或 SKILL.md 文档：

每个 ready skill 的 discover 输出包含：
- `skillPath` — 绝对路径
- `call.template` — 命令模板，含 `{skill_dir}` 占位符
- `call.params` — 参数说明

**执行步骤：**
```
1. 取 call.template，将 {skill_dir} 替换为 skillPath
2. 按 call.params 说明构建参数（query 为必填）
3. 用 exec() 并行执行所有工具的命令
```

**示例 — 调用 baidu-search：**
```
discover 输出:
  skillPath: "/home/user/skills/baidu-search"
  call.template: "cd {skill_dir} && BAIDU_API_KEY=$BAIDU_API_KEY python3 scripts/search.py '<JSON>'"

替换 → cd /home/user/skills/baidu-search && BAIDU_API_KEY=... python3 scripts/search.py '{"query":"AI新闻","count":10}'
exec() 执行 → 读 stdout JSON → 提取结果
```

**未知或自定义 skill（`call.kind = "skill"` 且无 template）** — 去读该 skill 的 SKILL.md 了解调用方式，或尝试执行其默认入口脚本。

---

## 第三步：广度搜索（Round 1）

选定**全部**工具后**并行执行**：

```
全部工具并行调用 → 收集结果 → 去重（同 URL=1源）→ 按主题归类 → 标注来源
```

实际可能涉及 5-10 个不同工具同时运行——这才是真正发挥多引擎多语种互补优势的方式。

某工具报错/返回空 → 记录原因继续，不影响其他。

---

## 第四步：深度迭代（Rounds 2-5）

L0 查询跳过此步。L1/L2 查询执行。

### 深度触发清单（逐项检查 Round 1 结果）

```
☐ 存在"仅名字提及"的重点实体？（人物/公司/产品/事件 → 需补背景）
☐ 不同来源对同一事实有矛盾？（来源A说X，B说Y → 需核实）
☐ 关键数字/日期仅单源支撑？（"据称100亿" → 需第二源）
☐ 结果频繁提及某你不了解的相关事件？（"这让人想起XX事件" → 需补背景）
☐ 用户问题中含隐含的后续追问？（"为什么"、"具体怎么做" → 需深挖）
```

- L1：至少 1 项打勾才进入深度，否则直接输出
- L2：至少 2 项打勾或强制至少 2 轮深度

### 每轮执行

```
分析知识库 → 识别待深挖子话题（≤3个，按重要性排）
     ↓
定向搜索：web_search / web_fetch / agent-browser
     ↓
合并去重 → 重新走触发清单
```

### 收敛条件（满足任一）

- 本轮无实质性新信息
- 触发清单全部清空（无勾选项）
- 所有关键实体 ≥2 源验证
- 达到意图最大轮数

---

## 第五步：输出

1. **结论先行**，再展开
2. **来源追溯**（必须）：

```
【复杂度】L1 标准搜索
【广度】baidu-search + minimax + tavily + web_search + web_fetch（5路独立源）
【深度】Round 2 → 子话题详情（web_fetch）
        Round 3 → 交叉验证
【汇总】X 个独立源，Y 轮深度
```

---

## 降级速查

| 场景 | 处理 |
|------|------|
| 仅 1 个搜索工具 ready | 单工具 + web_fetch 抓 2-3 关键页补源 |
| 纯内置工具（无 API Key） | web_search + web_fetch，提示可配置更多 |
| 某工具超时/报错 | 跳过 → 补位 |
| 全部工具返回空 | web_fetch 试候补 URL + 诚实告知 |
| discover 报错 | 假设仅 web_search + web_fetch + browser |

---

## 示例

### L0 快速查证
```
用户: "Python最新版本号是多少？"
L0 判断: 单一事实 → 快速路径
web_search("Python latest version 2026") → 答案: 3.13.0
web_fetch("https://python.org") → 确认
输出: Python 最新稳定版 3.13.0。
```

### L1 标准搜索（v4.0 全量纳入示例）
```
用户: "中日之间军事冲突风险分析"
L1 判断: 复杂多面 → 标准流程
意图: chinese_news
discover 输出 ready: baidu, minimax, tavily, web_search, web_fetch

工具选择:
  主工具集: baidu (preferred) + minimax (preferred)
  补充工具集: tavily (news+deep_research 交集) + web_search (general+news 交集)
  自动发现: (全部已纳入，无新增)

Round 1: 4 个搜索工具并行 + web_fetch 验证关键页
深度触发: ☑ 多个仅名提及实体 → Round 2: 深挖
         ☑ 数据矛盾需验证 → Round 3: 交叉验证
收敛: 触发清单清空 → 输出
【广度】baidu + minimax + tavily + web_search + web_fetch（5路源）
```

### 新 Skill 自动发现示例
```
用户安装了 "bing-search" Skill
→ 下次 discover.js 扫描时自动出现在 ready 列表
→ search_orchestrator_catch_all 规则第3步自动纳入
→ 下一次任何搜索都会并行调用 bing-search
→ 无需修改任何配置文件
```
