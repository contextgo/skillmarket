---
name: universal-search
description: >
  零配置智能搜索编排器。自动发现你安装的所有搜索工具（百度/Tavily/MiniMax/高德/Brave/Agent Browser
  或任何自定义搜索 Skill），无需手动指定用哪个。按查询复杂度自适应调度：简单事实秒级快查，常规搜索
  双引擎并行交叉验证，深度研究多轮迭代挖到信息充分才停。缺了某个工具的 API Key 也不影响，自动降级
  换下一个可用的。每条结论至少 2 个独立来源支撑，回复末尾标注完整搜索链路可追溯。把你分散的各种
  搜索能力变成一支自动协作的团队。
  触发：任何需要查资料、搜信息、核事实、做对比、深研究的请求。
metadata:
  openclaw:
    emoji: "🔍"
    requires:
      bins: ["node"]
      env: []
---

# Universal Search — 通用搜索编排器 v2.1

**强制默认搜索引擎** — 任何信息获取需求自动激活。

---

## 核心铁律

1. **先发现，再搜索** — 首次搜索时运行 `discover.js --cache`，后续用缓存
2. **复杂度自适应** — 简单事实查证不走深度流程，复杂研究不偷懒
3. **独立源 ≥2** — 每条核心结论最少 2 个独立源（同一网站多篇文章 = 1 源）
4. **来源必标** — 回复末尾注明完整搜索链路
5. **降级不中断** — 缺工具自动降级，绝不因配置问题报错停止

---

## 第〇步：环境检测（建索引，优先走缓存）

```bash
node skills/universal-search/scripts/discover.js --pretty --cache
```

- 首次运行：扫描 1-3 秒，写入 `/tmp/universal-search-cache.json`
- 后续 1 小时内：秒级缓存命中，`cache_hit: true`
- 手动强制刷新：加 `--force`

读取输出的 `ready` 数组，每个工具包含 `id`、`strengths`（能力标签）、`coverage`、`depth`。

---

## 第一步：复杂度分级（关键！避免小题大做）

在意图分类之前，先判断查询复杂度：

### L0 — 快速查证（跳过深度）
**特征：** 单一事实、有标准答案、无争议可能、非时效敏感或时效信息易得

| 示例 | 处理 |
|------|------|
| "Python最新版本是多少？" | web_search ×1 → 返回 |
| "北京到上海高铁多久？" | web_search ×1 + web_fetch 验证 → 返回 |
| "React 18 发布时间" | web_search ×1 → 返回 |
| "GPT-4 参数量" | web_search ×1 + web_fetch 验证 → 返回 |

**快速路径流程：**
```
1 个工具搜索 → 有明确答案？
  ├─ 是 → 用 web_fetch 快速验证 → 输出
  └─ 否（结果模糊/矛盾）→ 升级到 L1 标准流程
```

### L1 — 标准搜索（大多数查询）
**特征：** 多面信息、可能有争议、需要一定背景、中等复杂度

| 示例 | 处理 |
|------|------|
| "最近有什么AI新闻" | 意图分类 → 2工具广度 → 条件深度 |
| "WebAssembly 是什么" | 意图分类 → 2工具广度 → 条件深度 |
| "iPhone 15 vs 三星 S24" | 意图分类 → 2工具广度 → 条件深度 |

→ 进入**第二步**完整流程

### L2 — 深度研究
**特征：** 复杂主题、需要全面了解、用户明确要分析报告/综述

| 示例 | 处理 |
|------|------|
| "全面分析AI对齐问题的现状" | 意图分类 → 2-3工具广度 → 强制多轮深度 |
| "整理一份LLM发展简史" | 意图分类 → 2-3工具广度 → 强制多轮深度 |

→ 进入**第二步**完整流程 + 深度不收敛不停止

**判断规则：** 不确定 L0 还是 L1 时走 L1（宁可多搜不错过）。

---

## 第二步：意图分类 → 工具选择

根据用户查询特征匹配意图（完整规则见 `references/intent-routing.json`）：

```
意图          → 关键能力需求                    → 首选工具        深度上限
geographic    → strengths: geographic            → amap-lbs       3轮
chinese_news  → strengths: chinese + news         → baidu, minimax 5轮
chinese_general→ strengths: chinese              → baidu, minimax 4轮
english_news  → strengths: news; depth≥moderate   → tavily, web_search 5轮
technical     → strengths: technical/general     → web_search, web_fetch 4轮
fact_check    → min_sources: 3                   → web_search, web_fetch 5轮
comparative   → depth: deep                      → web_search     3轮
deep_research → depth: deep                      → web_search, web_fetch 4轮
english_general→ strengths: general/english      → web_search     4轮
default       → (兜底)                            → web_search     3轮
```

### 工具匹配优先级

```
1. 首选工具中 status=ready 的 → 取前 2 个
2. 不足 2 个 → 从所有 ready 工具中按 strengths 匹配度补足
3. 仍不足 → web_fetch 定向抓取关键 URL 作为第二源
4. 0 个 ready → 告知用户并停止
```

### 🔑 工具调用转换规则（如何把 discover 输出变成实际调用）

**builtin 工具** → 直接用 OpenClaw 系统工具：

| discover id | 系统工具调用 |
|-------------|------------|
| `builtin:web_search` | `web_search(query, count, ...)` |
| `builtin:web_fetch` | `web_fetch(url, extractMode, ...)` |
| `builtin:browser` | `browser(action, url, ...)` |

**skill 工具（已知）** → shell 命令：

discover 输出中每个 ready skill 包含：
- `skillPath` — 绝对路径，如 `/home/user/skills/baidu-search`
- `call.template` — 命令模板，含 `{skill_dir}` 占位符
- `call.params` — 参数说明

**执行步骤：**
```
1. 取 call.template，将 {skill_dir} 替换为 skillPath
2. 按 call.params 说明构建参数（query 为必填）
3. 用 exec() 并行执行所有主工具的命令
```

**示例 — 调用 baidu-search：**
```
discover 输出:
  skillPath: "/home/user/skills/baidu-search"
  call.template: "cd {skill_dir} && BAIDU_API_KEY=$BAIDU_API_KEY python3 scripts/search.py '<JSON>'"

替换 {skill_dir}:
  → cd /home/user/skills/baidu-search && BAIDU_API_KEY=$BAIDU_API_KEY python3 scripts/search.py '{"query":"AI新闻","count":10}'

exec() 执行 → 读取 stdout JSON → 提取结果
```

**skill 工具（自定义/未知）** — 查看 `call.note` 指引：
- `call.kind = "skill"` 且无 template → 去读该 skill 的 SKILL.md 了解调用方式
- 或尝试用 exec() 执行该 skill 的默认入口脚本

---

## 第三步：广度搜索（Round 1）

选定工具后**并行执行**：

```
全部并行调用 → 收集结果 → 去重（同 URL=1源）→ 按主题归类 → 标注来源
```

某工具报错/返回空 → 记录原因继续，不影响其他。

---

## 第四步：深度迭代（Rounds 2-5）

L0 查询跳过此步。L1/L2 查询执行。

### 深度触发清单（逐项检查 Round 1 结果）

```
☐ 存在"仅名字提及"的重点实体？（人物/公司/产品/事件 → 需补背景）
☐ 不同来源对同一事实有矛盾？（来源A说X，B说Y → 需核实）
☐ 关键数字/日期仅单源支撑？（"据称100亿" → 需第二源）
☐ 结果频繁提及某你不了解的相关事件？（"这让人想起XX事件" → 需补背景）
☐ 用户问题中含隐含的后续追问？（"为什么"、"具体怎么做" → 需深挖）
```

- L1：至少 1 项打勾才进入深度，否则直接输出
- L2：至少 2 项打勾或强制至少 2 轮深度

### 每轮执行

```
分析知识库 → 识别待深挖子话题（≤3个，按重要性排）
     ↓
对第1优先级话题：
  定向搜索：web_search 关键词 / web_fetch 抓原文 / agent-browser 看动态页
     ↓
合并去重 → 重新走触发清单
```

### 收敛条件（满足任一）

- 本轮无实质性新信息
- 触发清单全部清空（无勾选项）
- 所有关键实体 ≥2 源验证
- 达到意图最大轮数

---

## 第五步：输出

1. **结论先行**，再展开
2. **来源追溯**（必须）：

```
【复杂度】L1 标准搜索
【广度】来源：web_search + baidu-search（2路独立源）
【深度】Round 2 → "GPT-5 发布时间"（web_fetch → https://openai.com/...）
        Round 3 → "Llama 4 参数"（web_fetch → https://ai.meta.com/...）
【汇总】X 个独立源，Y 轮深度
```

---

## 降级速查

| 场景 | 处理 |
|------|------|
| 仅 1 个搜索工具 ready | 单工具 + web_fetch 抓 2-3 关键页补源 |
| 纯内置工具（无 API Key） | web_search + web_fetch，提示可配置更多 |
| 某工具超时/报错 | 跳过 → 补位 |
| 全部工具返回空 | web_fetch 试候补 URL + 诚实告知 |
| discover 报错 | 假设仅 web_search + web_fetch + browser |

---

## 示例

### L0 快速查证
```
用户: "Python最新版本号是多少？"
L0 判断: 单一事实 → 快速路径
web_search("Python latest version 2026") → 答案: 3.13.0
web_fetch("https://python.org") → 确认
输出: Python 最新稳定版 3.13.0。无需来源追溯（单源事实 + 官方验证）。
```

### L1 标准搜索
```
用户: "最近有什么AI大新闻"
L1 判断: 多面信息 → 标准流程
意图: chinese_news
主工具: baidu(ready) + minimax(ready)
Round 1: 并行搜索 → 去重得 5 事件
深度触发: ☑ GPT-5 仅标题提及 → Round 2: 深挖细节
         ☑ Llama 4 仅一段描述 → Round 3: 深挖参数
收敛: 触发清单清空 → 输出
```
