---
name: coinversaa-pulse
description: "Read-only crypto intelligence for AI agents. 7 free tools + 36 premium tools (43 total) for Hyperliquid trader analytics, behavioral cohorts, syncer-backed risk data, live market data, builder dex markets, commodities, stocks, indices, cross-market asset taxonomy, liquidation heatmaps, official per-dex OI, and whale tracking across the full Hyperliquid wallet universe. This skill does not trade, sign transactions, move funds, or require wallet approvals. Call pulse_global_stats for live coverage totals."
version: 0.6.1
author: Coinversa <chat@coinversaa.ai>
homepage: https://coinversa.ai
repository: https://github.com/coinversaa/mcp-server
license: MIT
tags:
  - crypto
  - market-data
  - analytics
  - hyperliquid
  - defi
  - blockchain
  - whale-tracking
  - builder-dex
  - commodities
  - stocks
  - mcp
env:
  COINVERSAA_API_KEY:
    description: "Your Coinversa API key (starts with cvsa_). Get one at https://coinversa.ai/developers. Optional — 7 read-only tools are available without a key."
    required: false
  COINVERSAA_API_URL:
    description: "API base URL. Defaults to https://api.coinversa.ai."
    required: false
---

# Coinversa Pulse

Coinversa Pulse is a **read-only crypto intelligence MCP skill** for AI agents.

It lets MCP-compatible clients query Hyperliquid market data, trader behavior, cohort analytics, liquidation data, open interest, builder dex markets, cross-market asset exposure, and wallet-level trading history.

This skill is designed for **market research and analytics only**.

It does **not** place trades, sign transactions, manage wallets, move funds, approve agents, custody assets, or request private keys.

For current wallet and trade coverage numbers, call `pulse_global_stats`.

Coinversa indexes Hyperliquid's clearinghouse directly and computes analytics that are difficult to obtain from public web sources or generic blockchain APIs.

**Builder dex support:** 369+ markets across 8 dexes, including commodities, stocks, indices, and perps.

---

## Safety Boundary: Read-Only Analytics Only

Coinversa Pulse is a market-data and analytics MCP server.

This skill does **not** expose any tools for:

- Trading
- Order placement
- Wallet signing
- Transaction signing
- Fund movement
- Token transfers
- Account approvals
- Hyperliquid agent wallet approval
- Backend signer approval
- Custody or control of assets
- Managing margin or leverage settings

No private key, seed phrase, wallet signature, exchange credential, or Hyperliquid account approval is required to use this skill.

Users should **not** approve a Hyperliquid agent wallet, backend signer, trading agent, or any account-level trading permission for this MCP skill. No such approval is needed for Coinversa Pulse.

If Coinversa offers trading or execution functionality through another product, app, or integration, that functionality is outside the scope of this MCP skill and should be reviewed separately.

---

## Data & Privacy

Coinversa Pulse sends MCP tool requests to Coinversa's hosted API at `https://api.coinversa.ai` by default.

Depending on the tool used, requests may include:

- Market symbols
- Wallet addresses
- Cohort names
- Time windows
- API-key-authenticated usage metadata
- Requested analytics parameters

Do not submit private, sensitive, or nonpublic information unless you are comfortable sending it to Coinversa's API.

Coinversa Pulse does not require private keys, seed phrases, wallet signatures, exchange credentials, or Hyperliquid account approvals.

For more details, review Coinversa's website, API documentation, and privacy terms.

---

## Setup

### Option A: Free Tier — No API Key

Try it instantly with no sign-up required.

The free tier includes 7 read-only tools with rate limits:

| Free Tool | Rate Limit |
|-----------|------------|
| `pulse_global_stats` | 10/min |
| `pulse_market_overview` | 5/min, deprecated alias for `list_markets` |
| `list_markets` | 5/min |
| `market_price` | 30/min |
| `market_orderbook` | 10/min |
| `pulse_most_traded_coins` | 5/min |
| `live_long_short_ratio` | 5/min |

The cross-market asset tools — `list_assets`, `list_asset`, `pulse_cross_market_asset` — and `live_official_oi` are paid-tier tools and require an API key.

Create a free-tier key at [coinversa.ai/developers](https://coinversa.ai/developers) to unlock API-key access.

Daily cap: 500 requests/day per IP.

```json
{
  "mcpServers": {
    "coinversaa": {
      "command": "npx",
      "args": ["-y", "@coinversaa/mcp-server@0.6.1"]
    }
  }
}
```

### Option B: Full Access — API Key

Get a key at [coinversa.ai/developers](https://coinversa.ai/developers).

Full access unlocks all 43 read-only analytics tools with higher rate limits: 100 requests/minute and no daily cap.

#### Claude Desktop

Edit:

```text
~/Library/Application Support/Claude/claude_desktop_config.json
```

Add:

```json
{
  "mcpServers": {
    "coinversaa": {
      "command": "npx",
      "args": ["-y", "@coinversaa/mcp-server@0.6.1"],
      "env": {
        "COINVERSAA_API_KEY": "cvsa_your_key_here"
      }
    }
  }
}
```

#### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "coinversaa": {
      "command": "npx",
      "args": ["-y", "@coinversaa/mcp-server@0.6.1"],
      "env": {
        "COINVERSAA_API_KEY": "cvsa_your_key_here"
      }
    }
  }
}
```

#### Claude Code

```bash
claude mcp add coinversaa -- npx -y @coinversaa/mcp-server@0.6.1
export COINVERSAA_API_KEY="cvsa_your_key_here"
```

#### OpenClaw

```bash
openclaw skill install coinversaa-pulse
```

---

## Builder Dex Markets

Hyperliquid supports multiple builder dexes beyond the native perps exchange. Each dex has its own markets, collateral token, and symbol format.

Coinversa Pulse exposes analytics and market-data views for these markets.

| Dex | What it trades | Collateral | Example symbols |
|-----|----------------|------------|-----------------|
| native HL | Core perps, crypto | USDC | BTC, ETH, SOL, HYPE |
| `xyz` | Commodities, stocks, indices | USDC | xyz:GOLD, xyz:SILVER, xyz:TSLA |
| `flx` | Perps | USDH | flx:BTC, flx:ETH |
| `vntl` | Perps | USDH | vntl:ANTHROPIC, vntl:BTC |
| `hyna` | Perps | USDE | hyna:SOL, hyna:BTC |
| `km` | Energy and commodities | USDH | km:OIL, km:NATGAS |
| `abcd` | Misc markets | USDC | abcd:BITCOIN |
| `cash` | Stocks and equities | USDT0 | cash:TSLA, cash:AAPL |

### Symbol Format

Native Hyperliquid markets use simple symbols:

```text
BTC
ETH
SOL
```

Builder dex markets use prefixed symbols:

```text
xyz:GOLD
cash:TSLA
hyna:SOL
```

Use `list_markets` to discover all available symbols and the dex each symbol belongs to.

### Builder Dex Safety Note

Builder dex markets may have different margin, collateral, and market-structure behavior depending on the venue.

Coinversa Pulse only exposes analytics and market-data views. It does not place orders, sign transactions, approve agent wallets, manage margin, or execute trades.

For execution behavior, margin settings, account permissions, and trading requirements, refer directly to Hyperliquid or the relevant execution platform. Those capabilities are not part of this skill.

---

## Assets & Cross-Market Taxonomy

The same underlying asset can appear under different tickers on different venues. Coinversa exposes a canonical asset registry so agents and API consumers do not have to reinvent the grouping logic.

### Two Concepts

| Concept | Meaning |
|---------|---------|
| Canonical | The economic-exposure identifier. Example: `GOLD` means gold exposure regardless of venue or ticker. |
| Symbol | What a specific venue lists it as. Examples: `xyz:GOLD`, `hyna:PAXG`, `BTC`, `flx:BTC`. |

### Known Synonyms

| Synonym ticker | Canonical | Reason |
|----------------|-----------|--------|
| `PAXG` | `GOLD` | Paxos-issued gold-backed token |
| `XAUT` | `GOLD` | Tether Gold |
| `XAGT` | `SILVER` | Silver-backed token |

### Wrapped-Token Note

Wrappers like `WBTC`, `WETH`, `stETH`, and `wstETH` are not aggregated with their native tickers by default because they can have meaningfully different risk and liquidity profiles.

If you want them treated as synonyms for a specific use case, do that in your client code.

### When to Use Which Tool

| User Question | Recommended Tool |
|--------------|------------------|
| "What markets exist on the xyz dex?" | `list_markets` |
| "What price is xyz:GOLD right now?" | `market_price` |
| "What assets are available?" | `list_assets` |
| "What venues is GOLD on?" | `list_assets` or `list_asset` |
| "Tell me about PAXG." | `list_asset` |
| "Where does BTC trade?" | `list_asset` |
| "Is gold more crowded on xyz or hyna?" | `pulse_cross_market_asset` |
| "Total OI on BTC across all dexes?" | `pulse_cross_market_asset` |
| "Do venues disagree on ETH direction?" | `pulse_cross_market_asset` |

Asset tools accept both canonicals and synonyms.

For example:

```text
list_asset({ canonical: "PAXG" })
```

and:

```text
list_asset({ canonical: "GOLD" })
```

return the same canonical asset view.

### What `pulse_cross_market_asset` Returns

Example response shape:

```json
{
  "query": "GOLD",
  "resolvedCanonical": "GOLD",
  "asset": {
    "canonical": "GOLD",
    "synonyms": ["GOLD", "PAXG"],
    "crossMarket": true,
    "venueCount": 6
  },
  "aggregate": {
    "totalOpenInterest": 190131959,
    "totalVolume24h": 46282352,
    "totalPositions": 5927,
    "longPositions": 3764,
    "shortPositions": 2163,
    "longNotional": 95822523,
    "shortNotional": 94309436,
    "netBias": 0.27,
    "biasRange": 0.61,
    "totalUnrealizedPnl": -1332374,
    "totalUniqueWallets": 5927
  },
  "venues": [
    {
      "dex": "xyz",
      "symbol": "xyz:GOLD",
      "openInterest": 149105646,
      "netBias": 0.24,
      "longPositions": 2400
    },
    {
      "dex": "hl",
      "symbol": "PAXG",
      "openInterest": 38946540,
      "netBias": 0.41
    },
    {
      "dex": "cash",
      "symbol": "cash:GOLD",
      "openInterest": 1284058
    }
  ]
}
```

### Key Fields

| Field | Meaning |
|-------|---------|
| `aggregate.netBias` | Value from `-1` to `1`. Positive means long-heavy. Negative means short-heavy. Magnitude indicates directional conviction. |
| `aggregate.biasRange` | Spread between venues. High values, especially above `0.3`, suggest venues disagree meaningfully. |
| `asset.synonyms` | Tickers mapped into the canonical asset. Useful for explaining that gold may trade as `GOLD`, `PAXG`, or another symbol depending on venue. |
| `venues` | Per-venue breakdown sorted by open interest descending. The first venue is usually the dominant venue. |

---

## Tools

43 total read-only analytics tools:

- 7 free keyless tools
- 36 tools requiring a Coinversa API key

---

## Risk Tools Freshness

Syncer-backed risk tools are best treated as **beta recent-intelligence tools**.

These include:

- `live_risk_overview`
- `live_coin_risk_snapshot`
- `live_coin_risk_history`
- `live_mark_dislocations`
- `live_recent_liquidations`
- `live_liquidation_summary`
- `live_oi_history`
- `live_cohort_bias_history`

For venue-reported open interest, use `live_official_oi`, which is pulled from Hyperliquid's Info API, as a cross-check.

These tools are best for:

- Research
- LLM training
- Liquidation analysis
- Open interest trend work
- Crowding detection
- Market-structure analysis
- Recent risk analysis

They are best queried over recent windows such as `7d` or `30d`.

Freshness depends on sync coverage and may lag real time.

Do not treat syncer-backed analytics as guaranteed live execution truth or exact historical accounting.

---

## How AI Agents Use the Risk Tools

These tools are useful when the user wants market-structure answers rather than raw rows.

| Goal | Best Tools | What They Help Answer |
|------|------------|-----------------------|
| Detect risk now | `live_risk_overview`, `live_coin_risk_snapshot` | "What looks fragile right now?", "Is this coin crowded?", "Who is holding the risk?" |
| Explain recent stress | `live_recent_liquidations`, `live_liquidation_summary`, `live_mark_dislocations` | "What got liquidated?", "Did basis stress show up before the unwind?", "Was this move liquidation-driven?" |
| Track regime change | `live_coin_risk_history`, `live_oi_history`, `live_cohort_bias_history` | "Did OI build into this move?", "Did smart money rotate early?", "How did the setup change over the last month?" |

For agent UX, prefer recent windows like `7d` or `30d`.

Summarize outputs in plain language instead of dumping all rows unless the user asks for raw detail.

For `market_recent_candles`, keep requests short and recent. The MCP tool intentionally caps one-minute candle responses at 720 rows, or 12 hours, so agents do not pull massive minute-bar dumps in a single call.

---

## Pulse — Trader Intelligence

Use these tools when the user asks about top traders, market activity, or trading trends.

### `pulse_global_stats`

Global Hyperliquid stats: total traders, trades, volume, PnL, and data coverage period.

Use when asked about overall market scale.

### `list_markets`

Canonical market discovery tool.

Returns every trading symbol with its dex, mark price, 24h volume, funding rate, open interest, and 24h change.

Use whenever the user asks:

- "What markets are available?"
- "What markets exist on xyz?"
- "What commodity markets are available?"
- "Which stocks are listed?"
- "What builder dex markets exist?"

For asset-level cross-venue grouping, use `list_assets`.

Parameters:

- `dex` optional — filter to a specific builder dex.

### `pulse_market_overview`

Deprecated alias for `list_markets`.

Same endpoint, same payload. Kept for backward compatibility only.

Prefer `list_markets` in new integrations.

Parameters:

- `dex` optional.

### `list_assets`

Canonical asset directory.

Returns every asset grouped by economic exposure rather than venue ticker. Each entry includes synonyms, venues, aggregated open interest, and a cross-market flag.

Prefer this over `list_markets` when the user asks about assets rather than specific markets.

API key required.

Parameters:

- `crossMarketOnly` optional boolean — return only assets listed on 2+ venues.

### `list_asset`

Single canonical asset lookup with full venue breakdown.

Accepts canonical names like `GOLD` or synonyms like `PAXG`.

Returns every venue where the asset trades, the collateral token per venue, and open interest / volume per venue.

API key required.

Parameters:

- `canonical` required — example: `GOLD`, `PAXG`, `BTC`.

### `pulse_cross_market_asset`

Aggregated cross-market view for one asset.

Returns per-venue long/short positions, notional, net bias, unique wallets, leverage, cross-venue totals, and `biasRange`.

This is the agent-native answer to questions like:

- "Is GOLD crowded?"
- "Do dexes disagree on BTC?"
- "What is total OI on ETH across all venues?"

Accepts canonical or synonym.

API key required.

Parameters:

- `canonical` required — example: `GOLD`, `PAXG`, `BTC`.

### `pulse_leaderboard`

Ranked trader leaderboard.

Sort by:

- `pnl`
- `winrate`
- `volume`
- `score`
- `risk-adjusted`
- `losers`

Filter by period and minimum trades.

Parameters:

- `sort`
- `period` — `day`, `week`, `month`, `allTime`
- `limit` — 1 to 100
- `minTrades`

### `pulse_hidden_gems`

Underrated high-performing traders that ranking sites may miss.

Filter by minimum win rate, PnL, trade count, and maximum trade count.

Parameters:

- `minWinRate`
- `minPnl`
- `minTrades`
- `maxTrades`
- `limit` — 1 to 100

### `pulse_most_traded_coins`

Most actively traded coins ranked by volume and trade count.

Parameters:

- `limit` — 1 to 100

### `pulse_biggest_trades`

Biggest winning or losing trades across Hyperliquid.

Parameters:

- `type` — `wins` or `losses`
- `limit` — 1 to 50
- `threshold`

### `pulse_recent_trades`

Biggest trades in the last N minutes or hours, sorted by absolute PnL.

Parameters:

- `since` — example: `10m`, `1h`, `1d`
- `limit` — 1 to 100
- `coin` optional

### `pulse_token_leaderboard`

Top traders for a specific coin.

Parameters:

- `coin`
- `limit` — 1 to 100

### `market_historical_oi`

Historical hourly open interest snapshots in notional USD.

Supports per-coin filtering or global aggregate.

Parameters:

- `coin` optional
- `since` max 30d
- `startTime` optional
- `endTime` optional

### `market_recent_candles`

Recent 1-minute candles for a market.

Useful for short intraday structure checks, recent momentum, and micro-pullback analysis.

Intentionally capped to the last 12 hours to keep MCP responses practical.

Parameters:

- `symbol`
- `limit` — 1 to 720

---

## Pulse — Trader Profiles

Use these tools for deep dives on specific wallets.

Any tool taking `address` expects a full Ethereum address:

```text
0x + 40 hex characters
```

### `pulse_trader_profile`

Full trader due diligence.

Returns total PnL, trade count, win rate, volume, largest win/loss, first/last trade dates, PnL tier, size tier, and profit factor.

Parameters:

- `address`

### `pulse_trader_performance`

30-day vs all-time comparison with trend direction.

Trend direction can be improving, declining, or stable.

Parameters:

- `address`

### `pulse_trader_trades`

Recent trades for any wallet: buy, sell, size, price, and PnL.

Parameters:

- `address`
- `since`
- `limit` — 1 to 100
- `coin` optional

### `pulse_trader_daily_stats`

Day-by-day PnL, trade count, win rate, and volume.

Parameters:

- `address`

### `pulse_trader_token_stats`

Per-coin PnL breakdown.

Parameters:

- `address`

### `pulse_trader_closed_positions`

Full position history: entry/exit prices, hold duration, PnL, and leverage.

Parameters:

- `address`
- `limit` — 1 to 200
- `offset`
- `coin` optional

### `pulse_trader_closed_position_stats`

Aggregate closed-position stats: average hold duration, position win rate, total closed positions, and PnL summary.

Parameters:

- `address`

---

## Pulse — Cohort Intelligence

Coinversa classifies tracked Hyperliquid wallets into behavioral tiers.

Call `pulse_global_stats` first if you need the current tracked-wallet count.

### PnL Tiers

- `money_printer`
- `smart_money`
- `grinder`
- `humble_earner`
- `exit_liquidity`
- `semi_rekt`
- `full_rekt`
- `giga_rekt`

### Size Tiers

- `leviathan`
- `tidal_whale`
- `whale`
- `small_whale`
- `apex_predator`
- `dolphin`
- `fish`
- `shrimp`

### `pulse_cohort_summary`

Full behavioral breakdown across all wallets.

Each tier shows wallet count, average PnL, average win rate, and total volume.

### `pulse_cohort_positions`

What a specific cohort is holding right now.

Parameters:

- `tierType` — `pnl` or `size`
- `tier`
- `limit` — 1 to 200

### `pulse_cohort_trades`

Every trade a cohort made in a time window.

Parameters:

- `tierType`
- `tier`
- `since`
- `limit` — 1 to 100

### `pulse_cohort_history`

Day-by-day historical performance for a cohort.

Parameters:

- `tierType`
- `tier`
- `days` — 1 to 365

### `pulse_cohort_bias_history`

Historical hourly bias snapshots for trader cohorts.

Parameters:

- `coin` optional
- `since` max 30d
- `startTime`
- `endTime`

### `pulse_cohort_performance_daily`

Historical daily performance stats for all cohorts.

Parameters:

- `since` max 30d
- `startTime`
- `endTime`

---

## Market — Live Data

Real-time market data from Hyperliquid.

### `market_price`

Current mark price for any symbol, native or builder dex.

Examples:

```text
BTC
ETH
xyz:GOLD
cash:TSLA
```

Parameters:

- `symbol`

### `market_positions`

Open positions for a wallet with entries, sizes, unrealized PnL, and leverage.

This is read-only position data.

Parameters:

- `address`

### `market_orderbook`

Bid/ask depth for any market.

Parameters:

- `symbol`
- `depth` — 1 to 50

---

## Live — Real-Time Analytics

Derived analytics computed in real time or near-real time.

### `live_liquidation_heatmap`

Liquidation clusters across price levels for any coin.

Parameters:

- `coin`
- `buckets` — 10 to 100
- `range` — 1% to 50% around current price

### `live_risk_overview`

Exchange-wide risk snapshot.

Includes OI, leverage, crowding concentration, near-liquidation exposure, and 7-day liquidation totals.

### `live_coin_risk_snapshot`

Current risk snapshot for a single coin.

Includes OI, wallet count, concentration, top positions, liquidation heatmap, and recent liquidations.

Parameters:

- `coin`

### `live_coin_risk_history`

Historical risk lane for a coin.

Includes OI, long/short, cohort rotation, candles, dislocations, and liquidation flow.

Parameters:

- `coin`
- `hours` — 1 to 720

### `live_mark_dislocations`

Historical mark/oracle dislocation series for a coin.

Includes mark price, oracle price, and basis percentage.

Parameters:

- `coin`
- `hours` — 1 to 720

### `live_recent_liquidations`

Real liquidation events from the syncer with wallet, coin, penalty fee, and closed PnL.

Parameters:

- `since`
- `coin` optional
- `limit` — 1 to 200

### `live_liquidation_summary`

Aggregated liquidation stats over a window with by-coin rollups and timeline buckets.

Parameters:

- `since`
- `coin` optional

### `live_long_short_ratio`

Global or per-coin long/short ratio with optional history.

Parameters:

- `coin` optional
- `hours` optional, 1 to 168 for history

### `live_cohort_bias`

Net long/short stance for every tier on a given coin.

Parameters:

- `coin`

### `live_oi_history`

Historical open interest for any coin or globally.

Uses hourly snapshots up to 30 days.

This is derived OI from live positions.

Parameters:

- `coin` optional
- `hours` — 1 to 720

### `live_official_oi`

Official per-dex open interest for a coin, pulled from Hyperliquid's Info API.

Use when the agent needs venue-reported ground truth, per-dex breakdowns, or wants to cross-check `live_oi_history` against official numbers.

API key required.

Parameters:

- `coin` required
- `hours` — 1 to 720, default 168
- `dex` optional, defaults to `hl`

### `live_cohort_bias_history`

Historical hourly long/short bias shifts for a specific coin across all cohorts or a single tier.

Parameters:

- `coin`
- `tierType`
- `tier` optional
- `hours` — 1 to 720

### `pulse_recent_closed_positions`

Positions recently closed across tracked traders.

Filterable by coin, size, and hold duration.

Parameters:

- `since`
- `limit` — 1 to 200
- `coin`
- `minNotional`
- `minDuration`
- `maxDuration`

---

## Example Prompts

Once connected, try asking your AI:

- "What are the top 5 traders on Hyperliquid by PnL?"
- "Show me what the money_printer tier is holding right now."
- "What are the biggest trades in the last 10 minutes?"
- "Find underrated traders with 70%+ win rate."
- "Do a deep dive on wallet 0x7fda...7d1. Are they still performing?"
- "Where are the BTC liquidation clusters?"
- "Show me the exchange-wide risk overview on Hyperliquid this week."
- "Which coin looks the most crowded right now?"
- "Show me ETH liquidation events from the last 7 days."
- "Give me BTC risk history with OI, liquidations, and cohort rotation."
- "Are smart money traders long or short ETH right now?"
- "What coins are most actively traded right now?"
- "Show me the biggest losses in the last 24 hours."
- "Is this trader a scalper or swing trader? What's their average hold time?"
- "Which coins does this trader actually make money on?"
- "What did the whale tier trade in the last hour?"
- "Compare this trader's last 30 days to their all-time performance."
- "What markets are available on the xyz dex?"
- "Show me all commodity markets."
- "What's the price of xyz:GOLD?"
- "List all builder dex markets."
- "What stocks are listed on Hyperliquid builder dexes?"
- "Which venues trade gold?"
- "Is PAXG the same as GOLD?"
- "Show me every cross-market asset listed on two or more dexes."
- "Total open interest on BTC across all dexes?"
- "Is BTC more crowded on hyna or native HL?"
- "Do different dexes disagree on ETH direction right now?"

---

## What Makes This Different

### Canonical Cross-Market Taxonomy

One asset can trade across many venues under many tickers.

`list_assets`, `list_asset`, and `pulse_cross_market_asset` resolve synonyms such as:

- PAXG to GOLD
- XAUT to GOLD
- XAGT to SILVER

They aggregate open interest, directional bias, and positions across venues server-side.

### Builder Dex Markets

Coinversa Pulse supports 369+ markets across 8 dexes, including:

- Crypto perps
- Commodities
- Stocks
- Indices
- Builder dex markets

### Behavioral Cohorts

Tracked wallets are classified into PnL tiers and size tiers, from `money_printer` to `giga_rekt` and from `leviathan` to `shrimp`.

### Live Cohort Positions

See what behavioral cohorts are holding in real time.

### Real-Time Trade Feed

Query trades by wallet, cohort, coin, or time window.

### Liquidation Heatmaps

Analyze liquidation clusters across price levels for any supported coin.

### Closed Position Analytics

Analyze full position lifecycle data, including hold duration, entry/exit behavior, and PnL.

### Hidden Gem Discovery

Find skilled traders that simple ranking sites may miss.

### Deep Hyperliquid Trade History

Coinversa maintains a deep indexed Hyperliquid trade-history dataset. Call `pulse_global_stats` for current indexed trade and wallet counts.

---

## Rate Limits

### Free Tier

Per-route limits between 5 and 30 requests per minute, plus 500 requests/day per IP.

See the free tools table in Setup for details.

### Paid Tier

API-key users receive:

- 100 requests/minute
- No daily cap
- Access to all 43 read-only analytics tools

Rate limit headers are included in every response:

| Header | Meaning |
|--------|---------|
| `X-RateLimit-Limit` | Your configured request limit |
| `X-RateLimit-Remaining` | Requests left in the current window |
| `X-RateLimit-Reset` | Seconds until the current window resets |
| `X-RateLimit-Tier` | `free` or `paid` |
| `X-RateLimit-Daily-Remaining` | Free tier only: requests left today |

---

## Security Notes

Coinversa Pulse is intentionally read-only.

When installing any MCP server, users should still follow general MCP safety practices:

- Install from the official package source.
- Use the pinned package version shown in this document.
- Use a separate API key for this MCP skill where possible.
- Rotate API keys if they may have been exposed.
- Do not provide private keys, seed phrases, wallet signatures, exchange credentials, or account approvals.
- Review the tools exposed by the MCP client before use.
- Remove the MCP server when no longer needed.

---

## Links

- Website: [coinversa.ai](https://coinversa.ai)
- API Docs: [coinversa.ai/developers](https://coinversa.ai/developers)
- GitHub: [github.com/coinversaa/mcp-server](https://github.com/coinversaa/mcp-server)
- npm: [@coinversaa/mcp-server](https://www.npmjs.com/package/@coinversaa/mcp-server)
- Support: [chat@coinversaa.ai](mailto:chat@coinversaa.ai)

---

Built by [Coinversa](https://coinversa.ai) — crypto intelligence for AI agents.
