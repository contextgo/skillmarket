#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SpringBoot项目初始化
功能：生成SpringBoot项目基础结构

@author: wql
@date: 2026-04-17
"""

import os
import sys
from datetime import datetime


class SpringBootInit:

    DEFAULT_VERSIONS = {
        "3.5": {
            "spring_boot": "3.5.13",
            "lombok": "1.18.30",
            "knife4j": "4.5.0",
            "knife4j_starter": "knife4j-openapi3-jakarta-spring-boot-starter"
        },
        "3.2": {
            "spring_boot": "3.2.3",
            "lombok": "1.18.30",
            "knife4j": "4.5.0",
            "knife4j_starter": "knife4j-openapi3-jakarta-spring-boot-starter"
        },
        "3.1": {
            "spring_boot": "3.1.10",
            "lombok": "1.18.30",
            "knife4j": "4.5.0",
            "knife4j_starter": "knife4j-openapi3-jakarta-spring-boot-starter"
        },
        "2.7": {
            "spring_boot": "2.7.18",
            "lombok": "1.18.30",
            "knife4j": "1.9.8",
            "knife4j_starter": "knife4j-openapi2-spring-boot-starter"
        }
    }

    def __init__(self, group_id: str, artifact_id: str = None, **kwargs):
        if not group_id:
            raise ValueError("groupId不能为空")

        self.group_id = group_id
        self.artifact_id = artifact_id or self._get_default_artifact_id()
        self.version = kwargs.get("version", "1.0.0")
        self.spring_boot_version = kwargs.get("springBootVersion", "3.5")
        self.package_name = kwargs.get("packageName", group_id)
        self.author = kwargs.get("author", "wql")
        self.project_name = kwargs.get("projectName", os.path.basename(os.getcwd()))
        self.create_time = datetime.now().strftime("%Y-%m-%d")

        user_lombok_version = kwargs.get("lombokVersion")
        user_knife4j_version = kwargs.get("knife4jVersion")
        user_knife4j_starter = kwargs.get("knife4jStarter")

        version_key = self.spring_boot_version.split(".")[0] + "." + self.spring_boot_version.split(".")[1]
        if version_key not in self.DEFAULT_VERSIONS:
            version_key = "3.5"

        default_versions = self.DEFAULT_VERSIONS[version_key]

        self.versions = {
            "spring_boot": default_versions["spring_boot"],
            "lombok": user_lombok_version or default_versions["lombok"],
            "knife4j": user_knife4j_version or default_versions["knife4j"],
            "knife4j_starter": user_knife4j_starter or default_versions["knife4j_starter"]
        }

        self.project_dir = os.getcwd()
        package_path = self.package_name.replace(".", os.sep)
        self.src_main_java = os.path.join(self.project_dir, "src", "main", "java", package_path)
        self.src_main_resources = os.path.join(self.project_dir, "src", "main", "resources")
        self.src_main_resources_static = os.path.join(self.project_dir, "src", "main", "resources", "static")
        self.src_test_java = os.path.join(self.project_dir, "src", "test", "java", package_path)
        self.src_test_resources = os.path.join(self.project_dir, "src", "test", "resources")

    def _get_default_artifact_id(self):
        cwd = os.getcwd()
        return cwd.split(os.sep)[-1]

    def generate(self):
        print(f"开始初始化SpringBoot项目: {self.project_name}")
        print(f"SpringBoot版本: {self.versions['spring_boot']}")
        print(f"Lombok版本: {self.versions['lombok']}")
        print(f"Knife4j版本: {self.versions['knife4j']}")
        print(f"项目目录: {self.project_dir}")

        self._create_project_structure()
        self._generate_pom_xml()
        self._generate_application_yml()
        self._generate_main_class()
        self._generate_knife4j_config()
        self._generate_favicon()

        print(f"\n[OK] 项目初始化成功!")
        print(f"下一步: 可使用 springboot-common 添加通用组件")

    def _create_project_structure(self):
        print("创建项目基础结构...")

        dirs = [
            self.src_main_java,
            self.src_main_resources,
            self.src_main_resources_static,
            self.src_test_java,
            self.src_test_resources
        ]

        packages = [
            "config", "constant", "controller", "entity", "mapper",
            "service", "serviceimpl", "exception", "aspect",
            "annotation", "interceptor", "util", "common"
        ]

        for package in packages:
            dirs.append(os.path.join(self.src_main_java, package))

        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)

    def _generate_pom_xml(self):
        print("生成pom.xml...")

        content = f'''<?xml version="1.0" encoding="UTF-8"?>
<!--
    {self.project_name}项目pom.xml
    SpringBoot项目Maven配置文件

    @author: {self.author}
    @date: {self.create_time}
-->
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>{self.versions['spring_boot']}</version>
        <relativePath/>
    </parent>

    <groupId>{self.group_id}</groupId>
    <artifactId>{self.artifact_id}</artifactId>
    <version>{self.version}</version>
    <packaging>jar</packaging>

    <name>{self.project_name}</name>
    <description>{self.project_name} - SpringBoot Project</description>

    <properties>
        <java.version>17</java.version>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>

        <knife4j.version>{self.versions['knife4j']}</knife4j.version>
        <knife4j.starter>{self.versions['knife4j_starter']}</knife4j.starter>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-aop</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

        <!-- Knife4j API文档 -->
        <dependency>
            <groupId>com.github.xiaoymin</groupId>
            <artifactId>${{knife4j.starter}}</artifactId>
            <version>${{knife4j.version}}</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
'''

        file_path = os.path.join(self.project_dir, "pom.xml")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_application_yml(self):
        print("生成application.yml...")

        content = f'''# {self.project_name}配置文件
# 服务器配置
server:
  port: 8080

# Spring配置
spring:
  application:
    name: {self.project_name}

# Knife4j配置
knife4j:
  enable: true
  setting:
    language: zh_cn

# 日志配置
logging:
  level:
    root: info
'''

        file_path = os.path.join(self.src_main_resources, "application.yml")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_main_class(self):
        print("生成启动类...")

        class_name = self._to_camel_case(self.project_name) + "Application"

        content = f'''package {self.package_name};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * {self.project_name}启动类
 * 初始化SpringBoot应用程序
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@SpringBootApplication
public class {class_name} {{

    public static void main(String[] args) {{
        SpringApplication.run({class_name}.class, args);
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, f"{class_name}.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_knife4j_config(self):
        print("生成Knife4j配置类...")

        is_spring3 = self.spring_boot_version.startswith("3")

        if is_spring3:
            content = f'''package {self.package_name}.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;

/**
 * Knife4j API文档配置类
 * 配置OpenAPI 3.0规范接口文档
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Configuration
public class Knife4jConfig {{

    @Bean
    public OpenAPI openAPI() {{
        return new OpenAPI()
                .info(new Info()
                        .title("{self.project_name} API")
                        .description("{self.project_name}接口文档")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("{self.author}")
                                .email("")));
    }}
}}
'''
        else:
            content = f'''package {self.package_name}.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Knife4j API文档配置类
 * 配置Swagger接口文档
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Configuration
@EnableOpenApi
public class Knife4jConfig {{

    @Bean
    public Docket docket() {{
        return new Docket(DocumentationType.OAS_30)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("{self.package_name}.controller"))
                .paths(PathSelectors.any())
                .build();
    }}

    private ApiInfo apiInfo() {{
        return new ApiInfoBuilder()
                .title("{self.project_name}接口文档")
                .description("{self.project_name}接口文档")
                .version("1.0.0")
                .build();
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "config", "Knife4jConfig.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_favicon(self):
        print("生成favicon.ico...")

        # 16x16 favicon.ico 文件的最小合法二进制数据
        # ICO文件头: 1(保留) + 1(类型) + 1(图像数量) = 6字节
        # 图像目录: 16(宽度) + 16(高度) + 0(颜色数) + 0(保留) + 1(颜色平面) + 32(位深度) + 40(数据大小) + 22(数据偏移) = 16字节
        # PNG数据: 一个最小的16x16透明PNG图像
        favicon_data = bytes([
            # ICO文件头 (6字节)
            0x00, 0x00,       # 保留
            0x01, 0x00,       # 类型: 1 = 图标
            0x01, 0x00,       # 图像数量: 1

            # 图像目录 (16字节)
            0x10,             # 宽度: 16
            0x10,             # 高度: 16
            0x00,             # 颜色数: 0 (真彩色)
            0x00,             # 保留
            0x01, 0x00,       # 颜色平面: 1
            0x20, 0x00,       # 位深度: 32
            0x28, 0x00, 0x00, 0x00,  # 数据大小: 40字节 (PNG数据大小)
            0x16, 0x00, 0x00, 0x00,  # 数据偏移: 22字节 (文件头+目录)

            # PNG数据: 16x16 透明PNG (40字节)
            0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,  # PNG签名
            0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,  # IHDR块头
            0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,  # 16x16
            0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0xF3, 0xFF,  # 8位RGBA, 压缩, 滤波, 交错
            0x61, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E,  # 结束
            0x44, 0xAE, 0x42, 0x60, 0x82
        ])

        file_path = os.path.join(self.src_main_resources_static, "favicon.ico")
        with open(file_path, "wb") as f:
            f.write(favicon_data)

    def _to_camel_case(self, name: str) -> str:
        if not name:
            return ""
        words = name.replace("-", " ").replace("_", " ").split()
        return "".join(word.capitalize() for word in words)


def main():
    if len(sys.argv) < 2:
        print("用法: python init.py <groupId> [artifactId] [version] [springBootVersion] [packageName] [author] [projectName] [lombokVersion] [knife4jVersion] [knife4jStarter]")
        print("")
        print("参数说明:")
        print("  groupId         - 项目groupId (必填)")
        print("  artifactId      - 项目artifactId (可选,默认使用当前目录名)")
        print("  version         - 项目版本号 (可选,默认1.0.0)")
        print("  springBootVersion - SpringBoot版本 (可选,默认3.5)")
        print("  packageName     - 主包名 (可选,默认使用groupId)")
        print("  author          - 作者信息 (可选,默认wql)")
        print("  projectName     - 项目名称 (可选,默认使用当前目录名)")
        print("  lombokVersion   - Lombok版本 (可选,默认1.18.30)")
        print("  knife4jVersion  - Knife4j版本 (可选,默认4.5.0)")
        print("  knife4jStarter  - Knife4j starter (可选)")
        print("")
        print("示例:")
        print("  python init.py com.example demo")
        print("  python init.py com.example demo 1.0.0 3.5")
        print("  python init.py com.example demo 1.0.0 3.5 com.example wql MyProject")
        print("  python init.py com.example demo 1.0.0 3.2 com.example wql DemoProject 1.18.31 4.5.0")
        print("  python init.py com.example demo 1.0.0 2.7 com.example wql DemoProject 1.18.30 1.9.8 knife4j-openapi2-spring-boot-starter")
        sys.exit(1)

    group_id = sys.argv[1]
    artifact_id = sys.argv[2] if len(sys.argv) > 2 else None

    kwargs = {}
    if len(sys.argv) > 3:
        kwargs["version"] = sys.argv[3]
    if len(sys.argv) > 4:
        kwargs["springBootVersion"] = sys.argv[4]
    if len(sys.argv) > 5:
        kwargs["packageName"] = sys.argv[5]
    if len(sys.argv) > 6:
        kwargs["author"] = sys.argv[6]
    if len(sys.argv) > 7:
        kwargs["projectName"] = sys.argv[7]
    if len(sys.argv) > 8:
        kwargs["lombokVersion"] = sys.argv[8]
    if len(sys.argv) > 9:
        kwargs["knife4jVersion"] = sys.argv[9]
    if len(sys.argv) > 10:
        kwargs["knife4jStarter"] = sys.argv[10]

    init = SpringBootInit(group_id, artifact_id, **kwargs)
    init.generate()


if __name__ == "__main__":
    main()
