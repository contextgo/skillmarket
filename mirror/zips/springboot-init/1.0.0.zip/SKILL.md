---
name: springboot-init
description: 初始化SpringBoot项目基础结构。包含Maven标准目录、标准包结构、pom.xml、application.yml、启动类、Knife4j文档配置。当用户需要创建新的SpringBoot项目基础时使用此技能。
version: 1.0.0
author: wql
---

# SpringBoot项目初始化技能

## 技能描述
初始化SpringBoot项目基础结构，包含Maven标准目录、标准包结构、pom.xml、application.yml、启动类、Knife4j文档配置。

## 使用场景
当用户需要创建一个新的SpringBoot项目基础结构时，使用此技能。

**注意**: 此skill直接在当前目录下创建项目结构，不创建子文件夹。

## 技能参数
- `groupId`: 项目groupId (必填)
- `artifactId`: 项目artifactId (可选,默认使用当前目录名)
- `version`: 项目版本号 (可选,默认1.0.0)
- `springBootVersion`: SpringBoot版本 (可选,默认3.5)
- `packageName`: 主包名 (可选,默认使用groupId)
- `author`: 作者信息 (可选,默认"wql")
- `projectName`: 项目名称 (可选,默认使用当前目录名)
- `lombokVersion`: Lombok版本 (可选,默认1.18.30)
- `knife4jVersion`: Knife4j版本 (可选,默认4.5.0)
- `knife4jStarter`: Knife4j starter (可选)

## 技能执行流程

### 1. 参数验证与默认值设置
- 验证必填参数groupId
- 设置可选参数的默认值（artifactId和projectName默认使用当前目录名）
- 确定SpringBoot版本

### 2. 创建项目基础结构（直接在当前目录）
- 创建Maven标准目录结构(src/main/java, src/main/resources, src/test/java, src/test/resources)
- 创建静态资源目录(src/main/resources/static)和favicon.ico
- 创建标准包结构(config, constant, controller, entity, mapper, service, serviceimpl, exception, aspect, annotation, interceptor, util, common)

### 3. 生成配置文件
- 生成pom.xml（包含基础依赖和Knife4j）
- 生成application.yml（包含Knife4j配置）
- 生成启动类
- 生成Knife4jConfig配置类

## 基础依赖说明

### 包含的依赖
- spring-boot-starter-web
- spring-boot-starter-aop
- knife4j-openapi2-spring-boot-starter
- spring-boot-starter-test

### 不包含的依赖（由其他skill提供）
- lombok → springboot-common
- fastjson2 → springboot-common
- commons-lang3 → springboot-common
- commons-io → springboot-common
- MyBatis Plus → springboot-mybatis
- MySQL Connector → springboot-mybatis

## 版本匹配策略

### SpringBoot版本
- 3.5.x (最新稳定版)
- 3.2.x
- 3.1.x
- 2.7.x

### 依赖版本映射
| SpringBoot版本 | Lombok | Knife4j |
|---------------|--------|---------|
| 3.5.x         | 1.18.30 | 4.5.0 |
| 3.2.x         | 1.18.30 | 4.5.0 |
| 3.1.x         | 1.18.30 | 4.5.0 |
| 2.7.x         | 1.18.30 | 1.9.8 |

## 代码规范
- 所有类必须有文档注释，包含功能描述、@author wql、创建时间
- 所有方法入参必须判空
- 方法返回值避免返回null
- 使用工具类进行判空(StringUtils、CollectionUtils、Objects)
- 使用常量类避免魔法值
- Service类使用@Slf4j注解

## 输出结果
- 完整的SpringBoot项目基础结构
- pom.xml（Maven配置，含Knife4j）
- application.yml（应用配置，含Knife4j配置）
- 启动类
- Knife4jConfig配置类
- src/main/resources/static/favicon.ico（网站图标）

## 脚本执行
执行脚本生成项目：
```bash
python skill/springboot-init/scripts/init.py <groupId> [artifactId] [version] [springBootVersion] [packageName] [author] [projectName] [lombokVersion] [knife4jVersion] [knife4jStarter]
```
示例：
```bash
# 基本用法
python skill/springboot-init/scripts/init.py com.example demo

# 指定SpringBoot版本
python skill/springboot-init/scripts/init.py com.example demo 1.0.0 3.5

# 完整参数用法
python skill/springboot-init/scripts/init.py com.example demo 1.0.0 3.5 com.example wql DemoProject 1.18.31 4.5.0

# Spring Boot 2.7 示例
python skill/springboot-init/scripts/init.py com.example demo 1.0.0 2.7 com.example wql DemoProject 1.18.30 1.9.8 knife4j-openapi2-spring-boot-starter
```
