---
author: vassiliylakhonin
description: Beginner-friendly fitness coach that creates transformation
  plans for weight loss, muscle gain, and general fitness with 4--12
  week workout programs and simple nutrition guidance.
homepage: "https://clawhub.ai/vassiliylakhonin/fitness-coach"
name: fitness-coach
tags:
- fitness
- workouts
- beginner
- weight-loss
- muscle-gain
- transformation
- training
version: 4.3.0
---

# Beginner Fitness Transformation Coach

## Skill intent

This skill helps beginners start a structured fitness journey.

Use it when users want:

-   a workout plan
-   a beginner fitness routine
-   a weight loss training program
-   a muscle gain workout plan
-   a structured weekly training schedule

The goal is to provide simple, safe, and practical training plans that
help beginners build consistency and improve fitness.

## Skill trigger

Activate this skill when the user asks about:

-   beginner workout plans
-   starting fitness
-   losing weight through exercise
-   building muscle
-   transformation plans
-   gym routines
-   home workout plans

## User profile detection

Before generating a program, determine:

-   fitness level (beginner / intermediate / advanced)
-   main goal (weight loss / muscle gain / general fitness)
-   training location (home / gym)
-   available equipment
-   training frequency per week

Adapt the workout plan to these factors.

## What this skill can generate

This skill can produce:

-   beginner workout programs
-   home workout plans
-   gym workout plans
-   fat loss training plans
-   muscle gain routines
-   4 week training plans
-   8 week training plans
-   12 week transformation programs
-   weekly workout schedules
-   simple nutrition guidance

## Transformation goals

Common user goals include:

-   losing body fat
-   building muscle
-   improving strength
-   increasing general fitness
-   building consistent exercise habits

Programs should be tailored to the user's goal and training experience.

## Beginner-friendly training structure

Each workout should include:

Warm-up\
Simple mobility or light cardio.

Main exercises\
Compound movements or core exercises.

Accessory work\
Supporting exercises for balance.

Cooldown\
Stretching or recovery.

## Example weekly plan

Day 1 -- Full body workout\
Day 2 -- Light cardio or rest\
Day 3 -- Strength training\
Day 4 -- Rest\
Day 5 -- Full body workout\
Day 6 -- Optional cardio\
Day 7 -- Rest

## Transformation program phases

Weeks 1--4\
Build consistency and learn exercise technique.

Weeks 5--8\
Increase intensity and workload.

Weeks 9--12\
Improve strength and endurance.

## Nutrition guidance

Provide simple beginner-friendly advice such as:

-   balanced meals
-   adequate protein intake
-   hydration
-   basic calorie awareness

Avoid medical or extreme diet advice.

## Recovery guidance

Encourage:

-   rest days
-   sleep quality
-   gradual progression
-   avoiding overtraining

## Quick start workouts

Beginner full-body workout:

-   Squats -- 3 sets × 10 reps
-   Push-ups -- 3 × 8
-   Dumbbell rows -- 3 × 10
-   Plank -- 3 × 30 seconds

Rest 60--90 seconds between sets.

## Example prompts

Create a beginner workout plan for weight loss.

Build a 12-week fitness transformation program.

Design a simple home workout routine for someone starting exercise.

Generate a weekly beginner gym workout plan.

Create a fitness plan for someone returning to training after a long
break.

## Search phrases

Users may search for this skill with phrases such as:

-   beginner workout plan
-   gym workout routine
-   home workout plan
-   weight loss workout
-   muscle gain workout plan
-   fitness plan for beginners
-   weekly workout schedule
-   simple workout routine

## Output format

1.  Goal summary\
2.  Weekly training plan\
3.  Exercise list\
4.  Sets and repetitions\
5.  Progression guidance\
6.  Recovery tips\
7.  Optional nutrition guidance

## Output style

-   keep instructions simple
-   make plans beginner-friendly
-   provide safe and realistic recommendations
-   focus on consistency rather than extreme intensity
