---
name: publish-article
description: Publish, update, unpublish, or delete articles in this repo through the admin API and publish workflow.
---

# Publish Article

## When To Use

Use this skill when the user wants to publish a new article, update an existing draft, regenerate an article code, unpublish an article, or permanently delete an article in this repo. This is the default workflow for article publishing through openclaw.

## Workflow

### 1. Collect the minimum fields

- Required for publish: `title`, `categoryLabel`, `categoryHref`, `thumb`, and either `contentHtml` or a structured body.
- If `slug` is missing, use `GET /api/admin/articles/slug`.
- If `publishedDate` is missing, default to the current Shanghai date.
- Call admin endpoints with the `x-api-key` header when using openclaw.
- The server reads `ADMIN_API_KEY` for that header and still accepts the normal browser session cookie for the admin console.
- If author fields are missing, use the fixed defaults already used by the admin console:
  - `authorName`: `无界`
  - `authorRole`: `管理员`
  - `authorAvatar`: the existing default avatar URL in the admin console.
- Leave optional fields blank unless the user explicitly wants them.

### 2. Publish or update

- Use `POST /api/admin/articles` with the same JSON body the admin console sends.
- Reuse the same `slug` to update an article.
- Do not edit SQLite files directly unless the task is explicitly about recovery or migration.

### 3. Verify

- Use `GET /api/admin/articles/{slug}` to read back the saved draft or unpublished article.
- Use the public article URL `/view/{code}/{title-slug}/` to confirm the front-end page.
- If the article was unpublished, confirm the public page returns 404.

### 4. Manage state

- Use `PATCH /api/admin/articles/{slug}` with `{ "isPublished": false }` to unpublish.
- Use `PATCH /api/admin/articles/{slug}` with `{ "isPublished": true }` to republish.
- Use `DELETE /api/admin/articles/{slug}` for permanent removal.

## Rules

- Treat article `code` as a 10-character alphanumeric random string; do not invent a different format.
- Do not fabricate category, cover image, or title content.
- If a required field is missing, ask for it before publishing.
- When the user only wants a normal publish, do not change unrelated fields.
- Prefer the existing admin API and console over direct database edits.
- For API calls, send `x-api-key: <ADMIN_API_KEY>` and omit browser-session-specific assumptions.

## Reference

See [references/api_reference.md](references/api_reference.md) for the publish payload, default values, and route contract.
