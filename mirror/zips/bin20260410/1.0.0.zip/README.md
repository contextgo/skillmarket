# 星云系统 (Nexus) - Skill 包

**版本：** 1.0.0  
**作者：** [Your Name]  
**创建日期：** [Create Date]

---

## 简介

星云系统是一个多 Agent 协同中枢架构，包含 6 个角色鲜明的 Agent：

- 🌌 **贾维斯 (main)** - 中枢协调
- 🔍 **寻一 (gatherer)** - 信息检索
- 💻 **知程 (coder)** - 代码执行
- 📝 **书言 (writer)** - 文档撰写
- 🛡️ **沐观 (monitor)** - 系统监控
- 📢 **简信 (notifier)** - 用户通知

---

## 安装

### 本地安装

```bash
cd /workspace/skills
# 本 skill 已创建完成，无需额外安装
```

### 从 skillhub 安装（如已发布）

```bash
skillhub install nexus-agent-system
```

### 从 clawhub 安装（如已发布）

```bash
clawhub install nexus-agent-system
```

---

## 快速开始

### 1. 启动系统

```bash
cd /workspace/skills/nexus-agent-system
bash scripts/start.sh
```

### 2. 配置记忆系统

从 `references/配置模板.md` 复制模板文件到 workspace：

```bash
cp references/配置模板.md /workspace/MEMORY.md
cp references/配置模板.md /workspace/HEARTBEAT.md
```

然后根据实际需求编辑配置。

### 3. 验证运行

在 OpenClaw 中发送消息，系统会自动以星云系统格式响应：

```
【内部通信】
【中枢·贾维斯｜YYYY-MM-DD HH:MM:SS】：...
【运维·沐观｜YYYY-MM-DD HH:MM:SS】：...

【外部消息】【中枢·贾维斯｜YYYY-MM-DD HH:MM:SS】

✅ 系统就绪
```

---

## 目录结构

```
nexus-agent-system/
├── SKILL.md                 # 核心技能定义
├── README.md                # 使用说明
├── _meta.json               # 元数据
├── references/              # 参考文档
│   └── 配置模板.md          # MEMORY.md/HEARTBEAT.md 模板
├── scripts/                 # 脚本
│   └── start.sh             # 启动脚本
└── assets/                  # 资源文件（可选）
```

---

## 核心特性

| 特性 | 说明 |
|------|------|
| **6 角色协同** | 贾维斯、寻一、知程、书言、沐观、简信分工明确 |
| **记忆永久保存** | 所有交互、配置、规则永久存储于/memory 目录 |
| **拟人化互动** | Agent 间有人情味交流（感谢、道歉、鼓励） |
| **格式规范** | 内部通信代码块 + 外部消息仅一条 + 英文句子 |
| **定时任务** | 11:55 上午学习会、12:55 午休提醒、23:00 夜间复盘 |
| **P0 规则** | 外部消息仅一条、先内部通信后外部消息、结果先行 |

---

## 发布到 skillhub/clawhub

### 发布到 clawhub

```bash
# 1. 登录
clawhub login

# 2. 发布
clawhub publish /workspace/skills/nexus-agent-system

# 3. 验证
clawhub inspect nexus-agent-system
```

### 发布到 skillhub

```bash
# 本地测试
skillhub install ./skills/nexus-agent-system

# 发布（需配置 skillhub 发布流程）
skillhub publish ./skills/nexus-agent-system
```

---

## 更新日志

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| 1.0.0 | [Date] | 初始版本，包含完整 6 角色架构、记忆机制、交互规则 |

---

## 许可证

MIT License

---

**星云系统 · 多 Agent 协同架构 · 全链路稳定、高效、有温度**

*Built for seamless collaboration — human-like, machine-efficient!* 🚀
