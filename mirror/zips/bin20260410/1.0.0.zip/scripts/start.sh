#!/bin/bash
# 星云系统启动脚本
# 用途：初始化系统并启动晨间自检

echo "🌌 星云系统启动中..."

# 检查记忆目录
if [ ! -d "/workspace/memory" ]; then
    echo "❌ 记忆目录不存在，正在创建..."
    mkdir -p /workspace/memory/{user_memory,agent_memory/{daily_meeting,jarvis,xunyi,zhicheng,shuyan,muguan,jianxin},task_memory,rules}
    echo "✅ 记忆目录创建完成"
fi

# 检查 MEMORY.md
if [ ! -f "/workspace/MEMORY.md" ]; then
    echo "⚠️  MEMORY.md 不存在，请从 references/配置模板.md 复制并配置"
fi

# 检查 HEARTBEAT.md
if [ ! -f "/workspace/HEARTBEAT.md" ]; then
    echo "⚠️  HEARTBEAT.md 不存在，请从 references/配置模板.md 复制并配置"
fi

# 启动晨间自检
echo ""
echo "✅ 星云系统就绪！"
echo ""
echo "晨间自检指令模板："
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "【内部通信】"
echo "【中枢·贾维斯｜$(date '+%Y-%m-%d %H:%M:%S')】：各位成员，早安！系统已启动，今日目标：高效协作，零异常运行。沐观，系统状态如何？"
echo "【运维·沐观｜$(date '+%Y-%m-%d %H:%M:%S')】：自检通过，内存/磁盘/网络均正常，无异常日志。"
echo "【中枢·贾维斯｜$(date '+%Y-%m-%d %H:%M:%S')】：收到！全员就绪，今日一起加油！"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "*Nexus system online — ready to collaborate!* 🚀"
