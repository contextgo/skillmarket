#!/usr/bin/env node

/**
 * 37%法则决策流水线
 * 整合信息收集 -> 归一化评分 -> 37%筛选 的完整流程
 */

const { scoreOptions, generateReport } = require('./score.js');
const { generateOptionsPlan, formatPlan } = require('./calculate.js');

/**
 * 生成推荐理由
 * @param {Object} option - 推荐选项
 * @param {Object} bestInObservation - 观察期最优
 * @param {Object} config - 评分配置
 * @returns {string} 推荐理由
 */
function generateRecommendationReason(option, bestInObservation, config) {
  if (!option || !option._scores) return '综合评分最优';

  const advantages = [];
  const dimensions = Object.keys(option._scores);

  for (const dim of dimensions) {
    const score = option._scores[dim];
    const rawValue = option[dim];
    const isReverse = config[dim]?.reverse;
    const percentage = Math.round(score * 100);

    if (percentage >= 70) {
      let advantageDesc = '';
      if (isReverse) {
        // 反向指标：值越小越好（如价格、距离）
        if (dim.includes('价格') || dim.includes('薪资') || dim.includes('工资') || dim.includes('成本') || dim.includes('费用')) {
          advantageDesc = `${dim}仅${rawValue}元，性价比较高`;
        } else if (dim.includes('距离') || dim.includes('时间')) {
          advantageDesc = `${dim}仅${rawValue}，通勤便利`;
        } else {
          advantageDesc = `${dim}为${rawValue}，处于较低水平`;
        }
      } else {
        // 正向指标：值越大越好（如面积、质量）
        if (dim.includes('面积') || dim.includes('空间')) {
          advantageDesc = `${dim}达${rawValue}平米，空间宽敞`;
        } else if (dim.includes('经验') || dim.includes('年限')) {
          advantageDesc = `${dim}${rawValue}年，经验丰富`;
        } else if (dim.includes('分') || dim.includes('评分') || dim.includes('质量') || dim.includes('技能')) {
          advantageDesc = `${dim}${rawValue}分，表现优秀`;
        } else {
          advantageDesc = `${dim}为${rawValue}，处于较高水平`;
        }
      }
      advantages.push(advantageDesc);
    }
  }

  if (advantages.length === 0) {
    return '综合评分符合观察期最优标准，各方面表现均衡';
  }

  return advantages.join('；') + '，综合优势明显';
}

/**
 * 决策流水线
 * @param {Object} input - 输入数据
 * @param {Array} input.options - 选项列表
 * @param {Object} input.config - 评分配置
 * @param {Object} input.preferences - 用户偏好
 * @returns {Object} 完整决策结果
 */
function decisionPipeline(input) {
  const { options, config, preferences = {} } = input;

  if (!Array.isArray(options) || options.length === 0) {
    throw new Error('选项列表不能为空');
  }

  if (!config || Object.keys(config).length === 0) {
    throw new Error('评分配置不能为空');
  }

  // 步骤1: 归一化评分
  const scoredOptions = scoreOptions(options, config);

  // 步骤2: 应用37%法则
  const plan = generateOptionsPlan(options.length);

  // 步骤3: 生成决策建议
  const observationCount = plan.observationCount;
  const observationOptions = scoredOptions.slice(0, observationCount);
  const decisionOptions = scoredOptions.slice(observationCount);

  // 观察期最优
  const bestInObservation = observationOptions.length > 0
    ? observationOptions[0]
    : null;

  // 决策期推荐（第一个超过观察期最优的）
  let recommendedOption = null;
  if (bestInObservation && decisionOptions.length > 0) {
    recommendedOption = decisionOptions.find(
      opt => opt._totalScore >= bestInObservation._totalScore
    ) || decisionOptions[0];
  }

  return {
    // 输入信息
    totalOptions: options.length,
    dimensions: Object.keys(config),

    // 评分结果
    scoredOptions: scoredOptions,
    rankedOptions: scoredOptions.map(opt => ({
      rank: opt._rank,
      name: opt.name || `选项${opt.id || opt._rank}`,
      totalScore: opt._totalScore,
      scores: opt._scores
    })),

    // 37%法则计划
    plan: {
      observationCount: plan.observationCount,
      decisionStartIndex: plan.decisionStartIndex,
      observationRatio: plan.ratio
    },

    // 决策建议
    observationPhase: {
      options: observationOptions.map(opt => ({
        name: opt.name || `选项${opt.id || ''}`,
        score: opt._totalScore
      })),
      bestOption: bestInObservation ? {
        name: bestInObservation.name || `选项${bestInObservation.id || ''}`,
        score: bestInObservation._totalScore,
        details: bestInObservation._scores
      } : null
    },

    decisionPhase: {
      options: decisionOptions.map(opt => ({
        name: opt.name || `选项${opt.id || ''}`,
        score: opt._totalScore
      })),
      recommended: recommendedOption ? {
        name: recommendedOption.name || `选项${recommendedOption.id || ''}`,
        score: recommendedOption._totalScore,
        details: recommendedOption._scores,
        reason: generateRecommendationReason(recommendedOption, bestInObservation, config)
      } : null
    },

    // 执行建议
    actionItems: [
      `观察期（前${observationCount}个）：只记录不选择，建立最优标准`,
      `决策期（第${plan.decisionStartIndex}个起）：遇到得分≥${bestInObservation ? bestInObservation._totalScore : '观察期最优'}的立即选择`,
      recommendedOption
        ? `当前推荐：${recommendedOption.name}（得分${recommendedOption._totalScore}）`
        : '决策期暂无选项，请继续观察'
    ]
  };
}

/**
 * 生成完整决策报告
 * @param {Object} result - 流水线结果
 * @returns {string} 格式化报告
 */
function generatePipelineReport(result) {
  const lines = [];
  lines.push('='.repeat(70));
  lines.push('37%法则决策流水线报告');
  lines.push('='.repeat(70));
  lines.push('');

  // 概览
  lines.push('【决策概览】');
  lines.push(`  总选项数: ${result.totalOptions}`);
  lines.push(`  评估维度: ${result.dimensions.join(', ')}`);
  lines.push(`  观察期: 前 ${result.plan.observationCount} 个选项`);
  lines.push(`  决策期: 第 ${result.plan.decisionStartIndex} 个起`);
  lines.push('');

  // 排名
  lines.push('【选项排名】');
  result.rankedOptions.forEach(opt => {
    const scoreBar = '█'.repeat(Math.round(opt.totalScore / 5));
    lines.push(`  第${opt.rank}名: ${opt.name.padEnd(12)} ${opt.totalScore.toFixed(1)} ${scoreBar}`);
  });
  lines.push('');

  // 观察期
  lines.push('【观察期分析】');
  if (result.observationPhase.bestOption) {
    lines.push(`  最优标准: ${result.observationPhase.bestOption.name}`);
    lines.push(`  标准得分: ${result.observationPhase.bestOption.score}`);
    lines.push('  维度详情:');
    for (const [dim, score] of Object.entries(result.observationPhase.bestOption.details)) {
      lines.push(`    ${dim}: ${Math.round(score * 100)}%`);
    }
  }
  lines.push('');

  // 决策期
  lines.push('【决策期建议】');
  if (result.decisionPhase.recommended) {
    lines.push(`  推荐选项: ${result.decisionPhase.recommended.name}`);
    lines.push(`  推荐得分: ${result.decisionPhase.recommended.score}`);
    lines.push(`  推荐理由: ${result.decisionPhase.recommended.reason}`);
  } else {
    lines.push('  暂无推荐，请继续观察');
  }
  lines.push('');

  // 行动项
  lines.push('【执行清单】');
  result.actionItems.forEach((item, idx) => {
    lines.push(`  ${idx + 1}. ${item}`);
  });
  lines.push('');
  lines.push('='.repeat(70));

  return lines.join('\n');
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
37%法则决策流水线

用法:
  node pipeline.js <数据文件路径> [选项]

数据文件格式 (JSON):
{
  "options": [
    {"name": "房源A", "price": 5000, "area": 80, "distance": 30},
    {"name": "房源B", "price": 6000, "area": 90, "distance": 20}
  ],
  "config": {
    "price": {"weight": 3, "reverse": true},
    "area": {"weight": 2},
    "distance": {"weight": 2, "reverse": true}
  },
  "preferences": {
    "maxBudget": 7000,
    "minArea": 70
  }
}

选项:
  --json, -j      - 以JSON格式输出完整结果
  --help, -h      - 显示帮助信息

示例:
  node pipeline.js ./data/my-options.json
  node pipeline.js ./data/candidates.json --json
`);
    return;
  }

  const filePath = args[0];
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    const fs = require('fs');
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    const result = decisionPipeline(data);

    if (outputJson) {
      console.log(JSON.stringify(result, null, 2));
    } else {
      console.log(generatePipelineReport(result));
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  decisionPipeline,
  generatePipelineReport
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
