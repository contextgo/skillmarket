#!/usr/bin/env node

/**
 * 多策略决策引擎
 * 支持37%法则、贪心算法、满意即可等多种决策策略
 */

const { scoreOptions } = require('./score.js');

/**
 * 37%法则策略
 * @param {Array} scoredOptions - 评分后的选项
 * @returns {Object} 决策结果
 */
function strategy37Percent(scoredOptions) {
  const total = scoredOptions.length;
  const observationCount = Math.ceil(total * 0.3679);
  const observationOptions = scoredOptions.slice(0, observationCount);
  const decisionOptions = scoredOptions.slice(observationCount);

  const bestInObservation = observationOptions[0] || null;
  const recommended = decisionOptions.find(
    opt => opt._totalScore >= (bestInObservation?._totalScore || 0)
  ) || decisionOptions[0] || null;

  return {
    strategy: '37%法则',
    description: '前37%只观察不选择，之后遇优即选',
    observationCount,
    decisionStartIndex: observationCount + 1,
    bestInObservation,
    recommended,
    confidence: '高（理论最优停止策略）'
  };
}

/**
 * 贪心算法策略
 * @param {Array} scoredOptions - 评分后的选项
 * @returns {Object} 决策结果
 */
function strategyGreedy(scoredOptions) {
  const recommended = scoredOptions[0];

  return {
    strategy: '贪心算法',
    description: '直接选择评分最高的选项',
    observationCount: 0,
    decisionStartIndex: 1,
    bestInObservation: null,
    recommended,
    confidence: '中（可能错过后续更优选项）'
  };
}

/**
 * 满意即可策略
 * @param {Array} scoredOptions - 评分后的选项
 * @param {number} threshold - 满意阈值（0-100）
 * @returns {Object} 决策结果
 */
function strategySatisficing(scoredOptions, threshold = 70) {
  const recommended = scoredOptions.find(opt => opt._totalScore >= threshold) || scoredOptions[0];
  const recommendedIndex = scoredOptions.findIndex(opt => opt.name === recommended.name);

  return {
    strategy: '满意即可',
    description: `选择首个达到${threshold}分满意线的选项`,
    observationCount: recommendedIndex,
    decisionStartIndex: recommendedIndex + 1,
    bestInObservation: recommendedIndex > 0 ? scoredOptions[0] : null,
    recommended,
    confidence: '低（快速决策，可能非最优）'
  };
}

/**
 * 探索-利用平衡策略
 * @param {Array} scoredOptions - 评分后的选项
 * @returns {Object} 决策结果
 */
function strategyExploreExploit(scoredOptions) {
  const total = scoredOptions.length;
  const exploreCount = Math.ceil(total * 0.5); // 前50%探索
  const exploitOptions = scoredOptions.slice(exploreCount);

  const bestInExplore = scoredOptions.slice(0, exploreCount)[0] || null;
  const recommended = exploitOptions[0] || scoredOptions[0];

  return {
    strategy: '探索-利用平衡',
    description: '前50%探索建立标准，后50%选择最优',
    observationCount: exploreCount,
    decisionStartIndex: exploreCount + 1,
    bestInObservation: bestInExplore,
    recommended,
    confidence: '中（更保守的策略）'
  };
}

/**
 * 多策略对比分析
 * @param {Array} options - 选项列表
 * @param {Object} config - 评分配置
 * @returns {Object} 各策略结果对比
 */
function compareStrategies(options, config) {
  const scoredOptions = scoreOptions(options, config);

  const strategies = [
    strategy37Percent(scoredOptions),
    strategyGreedy(scoredOptions),
    strategySatisficing(scoredOptions, 70),
    strategyExploreExploit(scoredOptions)
  ];

  return {
    options: scoredOptions,
    strategies,
    recommendation: strategies[0] // 默认推荐37%法则
  };
}

/**
 * 生成策略对比报告
 * @param {Object} result - 对比结果
 * @returns {string} 格式化报告
 */
function generateStrategyReport(result) {
  const lines = [];
  lines.push('='.repeat(70));
  lines.push('多策略决策对比报告');
  lines.push('='.repeat(70));
  lines.push('');

  lines.push('【选项排名】');
  result.options.slice(0, 5).forEach(opt => {
    lines.push(`  第${opt._rank}名: ${opt.name} - ${opt._totalScore.toFixed(1)}分`);
  });
  lines.push('');

  lines.push('【策略对比】');
  result.strategies.forEach(s => {
    lines.push(`\n  📊 ${s.strategy}`);
    lines.push(`     说明: ${s.description}`);
    lines.push(`     观察期: ${s.observationCount}个选项`);
    lines.push(`     推荐: ${s.recommended?.name || '无'} (${s.recommended?._totalScore.toFixed(1)}分)`);
    lines.push(`     置信度: ${s.confidence}`);
  });
  lines.push('');

  lines.push('【最终建议】');
  const rec = result.recommendation;
  lines.push(`  推荐策略: ${rec.strategy}`);
  lines.push(`  推荐选项: ${rec.recommended?.name}`);
  lines.push(`  理由: ${rec.description}`);
  lines.push('');
  lines.push('='.repeat(70));

  return lines.join('\n');
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
多策略决策引擎

用法:
  node strategy.js <数据文件> [选项]

策略:
  --strategy, -s  - 指定策略: 37|greedy|satisficing|explore (默认: 37)
  --threshold, -t - 满意阈值 (默认: 70)
  --compare, -c   - 对比所有策略
  --json, -j      - 输出JSON格式

示例:
  node strategy.js data.json
  node strategy.js data.json -s greedy
  node strategy.js data.json -s satisficing -t 80
  node strategy.js data.json --compare
`);
    return;
  }

  const dataFile = args[0];
  const strategyType = args.includes('--strategy') ? args[args.indexOf('--strategy') + 1] :
                       args.includes('-s') ? args[args.indexOf('-s') + 1] : '37';
  const threshold = args.includes('--threshold') ? parseInt(args[args.indexOf('--threshold') + 1]) :
                    args.includes('-t') ? parseInt(args[args.indexOf('-t') + 1]) : 70;
  const compareMode = args.includes('--compare') || args.includes('-c');
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    const fs = require('fs');
    const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));

    if (compareMode) {
      const result = compareStrategies(data.options, data.config);
      if (outputJson) {
        console.log(JSON.stringify(result, null, 2));
      } else {
        console.log(generateStrategyReport(result));
      }
    } else {
      const scoredOptions = scoreOptions(data.options, data.config);
      let result;

      switch (strategyType) {
        case 'greedy': result = strategyGreedy(scoredOptions); break;
        case 'satisficing': result = strategySatisficing(scoredOptions, threshold); break;
        case 'explore': result = strategyExploreExploit(scoredOptions); break;
        default: result = strategy37Percent(scoredOptions);
      }

      if (outputJson) {
        console.log(JSON.stringify(result, null, 2));
      } else {
        console.log(`策略: ${result.strategy}`);
        console.log(`说明: ${result.description}`);
        console.log(`推荐: ${result.recommended?.name} (${result.recommended?._totalScore.toFixed(1)}分)`);
        console.log(`置信度: ${result.confidence}`);
      }
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  strategy37Percent,
  strategyGreedy,
  strategySatisficing,
  strategyExploreExploit,
  compareStrategies,
  generateStrategyReport
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
