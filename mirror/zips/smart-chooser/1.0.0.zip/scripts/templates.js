#!/usr/bin/env node

/**
 * 场景模板管理器
 * 内置常见决策场景的模板
 */

const templates = {
  'house-rental': {
    name: '租房决策',
    description: '选择最优房源',
    dimensions: ['价格', '面积', '距离', '楼层', '采光'],
    config: {
      '价格': { weight: 3, reverse: true },
      '面积': { weight: 2 },
      '距离': { weight: 2, reverse: true },
      '楼层': { weight: 1 },
      '采光': { weight: 2 }
    },
    sample: `名称,价格,面积,距离,楼层,采光
房源A,5500,75,25,8,7
房源B,4800,65,35,3,5
房源C,6200,85,20,12,9`,
    tips: ['价格越低越好', '面积越大越好', '距离地铁越近越好']
  },

  'job-offer': {
    name: 'Offer选择',
    description: '选择最优工作机会',
    dimensions: ['薪资', '成长空间', '工作平衡', '地理位置', '团队氛围'],
    config: {
      '薪资': { weight: 3 },
      '成长空间': { weight: 3 },
      '工作平衡': { weight: 2 },
      '地理位置': { weight: 1 },
      '团队氛围': { weight: 1 }
    },
    sample: `名称,薪资,成长空间,工作平衡,地理位置,团队氛围
A公司,25000,8,6,9,7
B公司,30000,7,5,7,8
C公司,22000,9,8,8,9`,
    tips: ['薪资越高越好', '成长空间很重要', '工作生活平衡要考虑']
  },

  'car-purchase': {
    name: '购车决策',
    description: '选择最优车型',
    dimensions: ['价格', '续航', '空间', '智能化', '品牌'],
    config: {
      '价格': { weight: 3, reverse: true },
      '续航': { weight: 3 },
      '空间': { weight: 2 },
      '智能化': { weight: 2 },
      '品牌': { weight: 1 }
    },
    sample: `名称,价格,续航,空间,智能化,品牌
车型A,180000,500,7,8,7
车型B,220000,600,8,9,8
车型C,150000,400,6,6,6`,
    tips: ['价格越低越好', '续航越长越好', '空间越大越好']
  },

  'interview': {
    name: '面试筛选',
    description: '筛选最优候选人',
    dimensions: ['经验', '技能', '文化匹配', '潜力', '薪资期望'],
    config: {
      '经验': { weight: 2 },
      '技能': { weight: 3 },
      '文化匹配': { weight: 2 },
      '潜力': { weight: 2 },
      '薪资期望': { weight: 1, reverse: true }
    },
    sample: `名称,经验,技能,文化匹配,潜力,薪资期望
候选人A,5,8,7,8,25000
候选人B,3,7,9,9,15000
候选人C,7,9,6,6,22000`,
    tips: ['技能最重要', '文化匹配很关键', '薪资期望越低越好']
  },

  'product': {
    name: '商品对比',
    description: '选择最优商品',
    dimensions: ['价格', '质量', '品牌', '服务', '口碑'],
    config: {
      '价格': { weight: 3, reverse: true },
      '质量': { weight: 3 },
      '品牌': { weight: 1 },
      '服务': { weight: 1 },
      '口碑': { weight: 2 }
    },
    sample: `名称,价格,质量,品牌,服务,口碑
商品A,199,8,9,8,8
商品B,299,9,8,9,9
商品C,159,7,7,7,7`,
    tips: ['价格越低越好', '质量越高越好', '口碑很重要']
  },

  'dating': {
    name: '择偶决策',
    description: '选择合适伴侣',
    dimensions: ['外貌', '性格', '价值观', '经济条件', '家庭背景'],
    config: {
      '外貌': { weight: 1 },
      '性格': { weight: 3 },
      '价值观': { weight: 3 },
      '经济条件': { weight: 2 },
      '家庭背景': { weight: 1 }
    },
    sample: `名称,外貌,性格,价值观,经济条件,家庭背景
对象A,8,9,8,7,7
对象B,7,8,9,8,8
对象C,9,7,7,9,9`,
    tips: ['性格和价值观最重要', '外貌不是唯一标准', '经济条件适中即可']
  }
};

/**
 * 列出所有模板
 * @returns {Array} 模板列表
 */
function listTemplates() {
  return Object.entries(templates).map(([key, template]) => ({
    key,
    name: template.name,
    description: template.description,
    dimensions: template.dimensions
  }));
}

/**
 * 获取模板
 * @param {string} key - 模板键
 * @returns {Object} 模板数据
 */
function getTemplate(key) {
  return templates[key] || null;
}

/**
 * 生成模板文件
 * @param {string} key - 模板键
 * @param {string} outputFile - 输出文件路径
 */
function generateTemplateFile(key, outputFile) {
  const template = templates[key];
  if (!template) {
    throw new Error(`未知模板: ${key}`);
  }

  const data = {
    scenario: template.name,
    options: [],
    config: template.config,
    preferences: {}
  };

  // 解析sample数据
  const lines = template.sample.split('\n');
  const headers = lines[0].split(',');
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',');
    const row = {};
    headers.forEach((h, idx) => {
      const val = values[idx];
      row[h] = isNaN(parseFloat(val)) ? val : parseFloat(val);
    });
    data.options.push(row);
  }

  const fs = require('fs');
  fs.writeFileSync(outputFile, JSON.stringify(data, null, 2));

  return {
    file: outputFile,
    template: template
  };
}

/**
 * 生成CSV模板
 * @param {string} key - 模板键
 * @param {string} outputFile - 输出文件路径
 */
function generateCSVTemplate(key, outputFile) {
  const template = templates[key];
  if (!template) {
    throw new Error(`未知模板: ${key}`);
  }

  const fs = require('fs');
  fs.writeFileSync(outputFile, template.sample);

  return {
    file: outputFile,
    template: template
  };
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
场景模板管理器

用法:
  node templates.js <命令> [选项]

命令:
  list                    - 列出所有模板
  get <模板名>            - 获取模板详情
  create <模板名> <文件>  - 生成JSON模板文件
  csv <模板名> <文件>     - 生成CSV模板文件

可用模板:
  house-rental  - 租房决策
  job-offer     - Offer选择
  car-purchase  - 购车决策
  interview     - 面试筛选
  product       - 商品对比
  dating        - 择偶决策

示例:
  node templates.js list
  node templates.js get house-rental
  node templates.js create house-rental my-house.json
  node templates.js csv job-offer offers.csv
`);
    return;
  }

  const command = args[0];

  try {
    switch (command) {
      case 'list': {
        const list = listTemplates();
        console.log('可用模板:');
        list.forEach(t => {
          console.log(`\n  📋 ${t.name} (${t.key})`);
          console.log(`     ${t.description}`);
          console.log(`     维度: ${t.dimensions.join(', ')}`);
        });
        break;
      }

      case 'get': {
        const key = args[1];
        const template = getTemplate(key);
        if (!template) {
          console.error(`未知模板: ${key}`);
          process.exit(1);
        }
        console.log(`模板: ${template.name}`);
        console.log(`说明: ${template.description}`);
        console.log(`维度: ${template.dimensions.join(', ')}`);
        console.log(`\n配置:`);
        console.log(JSON.stringify(template.config, null, 2));
        console.log(`\n示例数据:`);
        console.log(template.sample);
        console.log(`\n提示:`);
        template.tips.forEach(tip => console.log(`  • ${tip}`));
        break;
      }

      case 'create': {
        const key = args[1];
        const outputFile = args[2] || `${key}.json`;
        const result = generateTemplateFile(key, outputFile);
        console.log(`模板文件已生成: ${result.file}`);
        console.log(`场景: ${result.template.name}`);
        console.log(`维度: ${result.template.dimensions.join(', ')}`);
        break;
      }

      case 'csv': {
        const key = args[1];
        const outputFile = args[2] || `${key}.csv`;
        const result = generateCSVTemplate(key, outputFile);
        console.log(`CSV模板已生成: ${result.file}`);
        console.log(`场景: ${result.template.name}`);
        break;
      }

      default:
        console.error(`未知命令: ${command}`);
        process.exit(1);
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  templates,
  listTemplates,
  getTemplate,
  generateTemplateFile,
  generateCSVTemplate
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
