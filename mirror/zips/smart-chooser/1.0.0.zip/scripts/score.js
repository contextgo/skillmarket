#!/usr/bin/env node

/**
 * 决策选项归一化评分器
 * 将多维度数据转化为标准化评分，供37%法则筛选使用
 */

/**
 * 归一化函数 - 将任意范围的值映射到 0-1
 * @param {number} value - 原始值
 * @param {number} min - 最小值
 * @param {number} max - 最大值
 * @param {boolean} reverse - 是否反向（值越小越好）
 * @returns {number} 0-1 之间的归一化值
 */
function normalize(value, min, max, reverse = false) {
  if (max === min) return reverse ? 0 : 1;
  let normalized = (value - min) / (max - min);
  normalized = Math.max(0, Math.min(1, normalized));
  return reverse ? 1 - normalized : normalized;
}

/**
 * 计算加权得分
 * @param {Object} scores - 各维度归一化得分 {维度: 分数}
 * @param {Object} weights - 各维度权重 {维度: 权重}
 * @returns {number} 加权总分 0-100
 */
function calculateWeightedScore(scores, weights) {
  let totalWeight = 0;
  let weightedSum = 0;

  for (const [dimension, score] of Object.entries(scores)) {
    const weight = weights[dimension] || 1;
    weightedSum += score * weight;
    totalWeight += weight;
  }

  return totalWeight > 0 ? (weightedSum / totalWeight) * 100 : 0;
}

/**
 * 对选项列表进行归一化评分
 * @param {Array} options - 选项列表，每个选项包含各维度原始值
 * @param {Object} config - 配置 {维度: {min, max, reverse, weight}}
 * @returns {Array} 带评分的选项列表
 */
function scoreOptions(options, config) {
  if (!Array.isArray(options) || options.length === 0) {
    throw new Error('选项列表不能为空');
  }

  // 计算每个维度的 min/max
  const dimensions = Object.keys(config);
  const stats = {};

  dimensions.forEach(dim => {
    const values = options.map(opt => opt[dim]).filter(v => typeof v === 'number');
    stats[dim] = {
      min: config[dim].min !== undefined ? config[dim].min : Math.min(...values),
      max: config[dim].max !== undefined ? config[dim].max : Math.max(...values)
    };
  });

  // 为每个选项计算归一化得分
  return options.map((option, index) => {
    const scores = {};

    dimensions.forEach(dim => {
      const value = option[dim];
      if (typeof value === 'number') {
        scores[dim] = normalize(
          value,
          stats[dim].min,
          stats[dim].max,
          config[dim].reverse
        );
      }
    });

    const weights = {};
    dimensions.forEach(dim => {
      weights[dim] = config[dim].weight || 1;
    });

    const totalScore = calculateWeightedScore(scores, weights);

    return {
      ...option,
      _scores: scores,
      _totalScore: Math.round(totalScore * 100) / 100,
      _rank: 0
    };
  }).sort((a, b) => b._totalScore - a._totalScore)
    .map((opt, idx) => ({ ...opt, _rank: idx + 1 }));
}

/**
 * 生成评分报告
 * @param {Array} scoredOptions - 评分后的选项
 * @param {Object} config - 配置
 * @returns {string} 格式化报告
 */
function generateReport(scoredOptions, config) {
  const lines = [];
  lines.push('='.repeat(60));
  lines.push('决策选项归一化评分报告');
  lines.push('='.repeat(60));
  lines.push('');

  // 配置信息
  lines.push('【评分配置】');
  const dimensions = Object.keys(config);
  dimensions.forEach(dim => {
    const cfg = config[dim];
    const direction = cfg.reverse ? '越小越好' : '越大越好';
    lines.push(`  ${dim}: 权重${cfg.weight || 1}, ${direction}`);
  });
  lines.push('');

  // 排名列表
  lines.push('【选项排名】');
  scoredOptions.forEach(opt => {
    lines.push(`  第${opt._rank}名: ${opt.name || '选项' + (opt.id || '')} - 综合得分 ${opt._totalScore}`);
    const scoreDetails = dimensions
      .map(dim => `${dim}:${Math.round(opt._scores[dim] * 100)}%`)
      .join(', ');
    lines.push(`    维度得分: ${scoreDetails}`);
  });
  lines.push('');

  // 前37%推荐
  const observationCount = Math.ceil(scoredOptions.length * 0.3679);
  lines.push('【37%法则建议】');
  lines.push(`  总选项数: ${scoredOptions.length}`);
  lines.push(`  观察期: 前 ${observationCount} 个选项（只记录不选择）`);
  lines.push(`  决策期: 从第 ${observationCount + 1} 个开始，遇到比观察期最优更好的立即选择`);
  lines.push('');

  // 观察期最优
  const observationOptions = scoredOptions.slice(0, observationCount);
  if (observationOptions.length > 0) {
    const bestInObservation = observationOptions[0];
    lines.push(`  观察期最优标准: ${bestInObservation.name || '选项' + (bestInObservation.id || '')}`);
    lines.push(`  最优得分: ${bestInObservation._totalScore}`);
    lines.push('  后续选项只要超过此分数即可选择');
  }
  lines.push('');
  lines.push('='.repeat(60));

  return lines.join('\n');
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
决策选项归一化评分器

用法:
  node score.js <数据文件路径> [选项]

数据文件格式 (JSON):
{
  "options": [
    {"name": "选项A", "price": 100, "quality": 8, "distance": 5},
    {"name": "选项B", "price": 150, "quality": 9, "distance": 3}
  ],
  "config": {
    "price": {"weight": 2, "reverse": true},
    "quality": {"weight": 3},
    "distance": {"weight": 1, "reverse": true}
  }
}

选项:
  --json, -j      - 以JSON格式输出结果
  --help, -h      - 显示帮助信息

示例:
  node score.js ./data/houses.json
  node score.js ./data/candidates.json --json
`);
    return;
  }

  const filePath = args[0];
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    const fs = require('fs');
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    if (!data.options || !data.config) {
      throw new Error('数据文件必须包含 options 和 config 字段');
    }

    const scoredOptions = scoreOptions(data.options, data.config);

    if (outputJson) {
      console.log(JSON.stringify(scoredOptions, null, 2));
    } else {
      console.log(generateReport(scoredOptions, data.config));
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  normalize,
  calculateWeightedScore,
  scoreOptions,
  generateReport
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
