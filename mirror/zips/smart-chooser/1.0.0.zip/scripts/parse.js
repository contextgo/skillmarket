#!/usr/bin/env node

/**
 * 自然语言解析器
 * 从文本中提取结构化数据，支持简历、商品描述、房源信息等
 */

/**
 * 提取数值
 * @param {string} text - 文本
 * @param {RegExp} pattern - 匹配模式
 * @returns {number|null} 提取的数值
 */
function extractNumber(text, pattern) {
  const match = text.match(pattern);
  if (match) {
    const num = parseFloat(match[1].replace(/,/g, ''));
    return isNaN(num) ? null : num;
  }
  return null;
}

/**
 * 提取评分（1-10分制）
 * @param {string} text - 文本
 * @param {string} keyword - 关键词
 * @returns {number|null} 评分
 */
function extractScore(text, keyword) {
  const patterns = [
    new RegExp(`${keyword}[:：]?\\s*(\\d+(?:\\.\\d+)?)\\s*分?`),
    new RegExp(`${keyword}[:：]?\\s*(\\d+(?:\\.\\d+)?)\\s*/\\s*10`),
    new RegExp(`${keyword}[:：]?\\s*(\\d+(?:\\.\\d+)?)\\s*分?\\s*[/／]\\s*10`),
    new RegExp(`${keyword}[:：]?\\s*(高|中|低|优|良|差)`)
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      const value = match[1];
      if (/^[\d.]+$/.test(value)) {
        return Math.min(10, Math.max(1, parseFloat(value)));
      }
      const scoreMap = { '高': 8, '优': 9, '中': 5, '良': 7, '低': 3, '差': 2 };
      return scoreMap[value] || null;
    }
  }
  return null;
}

/**
 * 解析简历文本
 * @param {string} text - 简历文本
 * @returns {Object} 结构化数据
 */
function parseResume(text) {
  const lines = text.split(/\n/).filter(line => line.trim());
  const candidates = [];
  let currentCandidate = null;

  for (const line of lines) {
    // 检测候选人名称（姓名、候选人X、Candidate X等）
    const nameMatch = line.match(/^(?:候选人|Candidate)?\s*([\u4e00-\u9fa5a-zA-Z]+)[：:\-]/);
    if (nameMatch || line.match(/^[\u4e00-\u9fa5]{2,4}$/)) {
      if (currentCandidate) candidates.push(currentCandidate);
      currentCandidate = {
        name: nameMatch ? nameMatch[1] : line.trim(),
        experience: extractNumber(line, /(\d+)\s*年/) || extractNumber(line, /经验[:：]\s*(\d+)/),
        skill: extractScore(line, '技能') || extractScore(line, '技术'),
        culture: extractScore(line, '文化') || extractScore(line, '匹配度'),
        potential: extractScore(line, '潜力') || extractScore(line, '成长性'),
        salary: extractNumber(line, /(?:薪资|工资|期望)[:：]?\s*(\d+)/) || extractNumber(line, /(\d{4,6})/)
      };
    } else if (currentCandidate) {
      // 补充当前候选人的信息
      if (!currentCandidate.experience) {
        currentCandidate.experience = extractNumber(line, /(\d+)\s*年/) || extractNumber(line, /经验[:：]\s*(\d+)/);
      }
      if (!currentCandidate.skill) {
        currentCandidate.skill = extractScore(line, '技能') || extractScore(line, '技术');
      }
      if (!currentCandidate.culture) {
        currentCandidate.culture = extractScore(line, '文化') || extractScore(line, '匹配度');
      }
      if (!currentCandidate.potential) {
        currentCandidate.potential = extractScore(line, '潜力') || extractScore(line, '成长性');
      }
      if (!currentCandidate.salary) {
        currentCandidate.salary = extractNumber(line, /(?:薪资|工资|期望)[:：]?\s*(\d+)/) || extractNumber(line, /(\d{4,6})/);
      }
    }
  }

  if (currentCandidate) candidates.push(currentCandidate);
  return candidates;
}

/**
 * 解析房源文本
 * @param {string} text - 房源描述文本
 * @returns {Array} 房源列表
 */
function parseHouses(text) {
  const lines = text.split(/\n/).filter(line => line.trim());
  const houses = [];
  let currentHouse = null;

  for (const line of lines) {
    // 检测房源名称
    const nameMatch = line.match(/^(房源|[\u4e00-\u9fa5]+区|[\u4e00-\u9fa5]+小区)?\s*([A-Z\u4e00-\u9fa5\d]+)[：:\-]/);
    if (nameMatch) {
      if (currentHouse) houses.push(currentHouse);
      currentHouse = {
        name: nameMatch[2],
        price: extractNumber(line, /(\d{3,5})\s*元/) || extractNumber(line, /租金[:：]\s*(\d+)/),
        area: extractNumber(line, /(\d+)\s*平/) || extractNumber(line, /面积[:：]\s*(\d+)/),
        distance: extractNumber(line, /(\d+)\s*分钟/) || extractNumber(line, /距离[:：]\s*(\d+)/) || extractNumber(line, /(\d+)\s*米/),
        floor: extractNumber(line, /(\d+)\s*楼/) || extractNumber(line, /楼层[:：]\s*(\d+)/),
        light: extractScore(line, '采光') || extractScore(line, '光照')
      };
    } else if (currentHouse) {
      if (!currentHouse.price) currentHouse.price = extractNumber(line, /(\d{3,5})\s*元/);
      if (!currentHouse.area) currentHouse.area = extractNumber(line, /(\d+)\s*平/);
      if (!currentHouse.distance) currentHouse.distance = extractNumber(line, /(\d+)\s*分钟/);
    }
  }

  if (currentHouse) houses.push(currentHouse);
  return houses;
}

/**
 * 解析商品文本
 * @param {string} text - 商品描述
 * @returns {Array} 商品列表
 */
function parseProducts(text) {
  const lines = text.split(/\n/).filter(line => line.trim());
  const products = [];
  let currentProduct = null;

  for (const line of lines) {
    const nameMatch = line.match(/^([\u4e00-\u9fa5a-zA-Z0-9]+)[：:\-]/);
    if (nameMatch) {
      if (currentProduct) products.push(currentProduct);
      currentProduct = {
        name: nameMatch[1],
        price: extractNumber(line, /(\d+(?:\.\d+)?)\s*元/) || extractNumber(line, /价格[:：]\s*(\d+)/),
        quality: extractScore(line, '质量') || extractScore(line, '品质'),
        brand: extractScore(line, '品牌') || extractScore(line, '口碑'),
        service: extractScore(line, '服务') || extractScore(line, '售后')
      };
    }
  }

  if (currentProduct) products.push(currentProduct);
  return products;
}

/**
 * 智能解析 - 自动识别类型
 * @param {string} text - 输入文本
 * @returns {Object} 解析结果
 */
function autoParse(text) {
  // 检测文本类型
  const hasResumeKeywords = /候选人|简历|经验|技能|薪资|工资/.test(text);
  const hasHouseKeywords = /房源|租房|租金|面积|平米|地铁/.test(text);
  const hasProductKeywords = /商品|产品|价格|品牌|质量/.test(text);

  if (hasResumeKeywords) {
    return { type: 'resume', data: parseResume(text) };
  } else if (hasHouseKeywords) {
    return { type: 'house', data: parseHouses(text) };
  } else if (hasProductKeywords) {
    return { type: 'product', data: parseProducts(text) };
  }

  // 默认尝试简历解析
  const resumeData = parseResume(text);
  if (resumeData.length > 0) {
    return { type: 'resume', data: resumeData };
  }

  return { type: 'unknown', data: [] };
}

/**
 * 生成默认配置
 * @param {string} type - 数据类型
 * @returns {Object} 默认配置
 */
function getDefaultConfig(type) {
  const configs = {
    resume: {
      experience: { weight: 2, min: 0, max: 10 },
      skill: { weight: 3, min: 1, max: 10 },
      culture: { weight: 2, min: 1, max: 10 },
      potential: { weight: 2, min: 1, max: 10 },
      salary: { weight: 1, reverse: true, min: 5000, max: 50000 }
    },
    house: {
      price: { weight: 3, reverse: true },
      area: { weight: 2 },
      distance: { weight: 2, reverse: true },
      floor: { weight: 1 },
      light: { weight: 2 }
    },
    product: {
      price: { weight: 3, reverse: true },
      quality: { weight: 3 },
      brand: { weight: 1 },
      service: { weight: 1 }
    }
  };
  return configs[type] || {};
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
自然语言解析器 - 从文本提取结构化数据

用法:
  node parse.js <文本文件路径> [选项]

选项:
  --type, -t      - 指定类型: resume|house|product
  --config, -c    - 同时输出默认配置
  --json, -j      - 以JSON格式输出
  --help, -h      - 显示帮助信息

示例:
  node parse.js ./resumes.txt
  node parse.js ./houses.txt --type house --config
  node parse.js ./products.txt -t product -c -j

支持的格式:
  简历: 候选人A: 5年经验, 技能8分, 文化7分, 潜力9分, 期望薪资25000
  房源: 房源A: 租金5500元, 面积75平, 距离地铁25分钟
  商品: 商品A: 价格199元, 质量8分, 品牌9分
`);
    return;
  }

  const filePath = args[0];
  const typeFlag = args.indexOf('--type') !== -1 ? args[args.indexOf('--type') + 1] :
                   args.indexOf('-t') !== -1 ? args[args.indexOf('-t') + 1] : null;
  const outputConfig = args.includes('--config') || args.includes('-c');
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    const fs = require('fs');
    const text = fs.readFileSync(filePath, 'utf8');

    let result;
    if (typeFlag) {
      const parsers = { resume: parseResume, house: parseHouses, product: parseProducts };
      result = { type: typeFlag, data: parsers[typeFlag](text) };
    } else {
      result = autoParse(text);
    }

    if (outputConfig) {
      result.config = getDefaultConfig(result.type);
    }

    if (outputJson) {
      console.log(JSON.stringify(result, null, 2));
    } else {
      console.log(`解析类型: ${result.type}`);
      console.log(`提取数量: ${result.data.length}`);
      console.log('');
      console.log('数据预览:');
      result.data.slice(0, 3).forEach((item, idx) => {
        console.log(`  ${idx + 1}. ${JSON.stringify(item)}`);
      });
      if (result.data.length > 3) {
        console.log(`  ... 还有 ${result.data.length - 3} 条`);
      }

      if (outputConfig && result.config) {
        console.log('');
        console.log('推荐配置:');
        console.log(JSON.stringify(result.config, null, 2));
      }
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  parseResume,
  parseHouses,
  parseProducts,
  autoParse,
  getDefaultConfig,
  extractNumber,
  extractScore
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
