#!/usr/bin/env node

/**
 * 37%法则计算器
 * 基于最优停止理论，帮助用户计算观察期和决策期
 */

const E = 2.71828;
const RATIO = 1 / E; // ≈ 0.3679

/**
 * 计算观察节点
 * @param {number} total - 总数（天数或选项数量）
 * @returns {number} 观察截止节点（向上取整）
 */
function calculateObservationPoint(total) {
  if (typeof total !== 'number' || total <= 0) {
    throw new Error('总数必须是正数');
  }
  return Math.ceil(total * RATIO);
}

/**
 * 按天数生成决策方案
 * @param {number} days - 总天数
 * @returns {Object} 决策方案
 */
function generateDaysPlan(days) {
  const observationDays = calculateObservationPoint(days);
  return {
    type: 'days',
    total: days,
    observationDays: observationDays,
    decisionStartDay: observationDays + 1,
    observationEndDay: observationDays,
    ratio: RATIO.toFixed(4),
    formula: `ceil(${days} × ${RATIO.toFixed(4)}) = ${observationDays}`
  };
}

/**
 * 按选项数量生成决策方案
 * @param {number} count - 总选项数
 * @returns {Object} 决策方案
 */
function generateOptionsPlan(count) {
  const observationCount = calculateObservationPoint(count);
  return {
    type: 'options',
    total: count,
    observationCount: observationCount,
    decisionStartIndex: observationCount + 1,
    observationEndIndex: observationCount,
    ratio: RATIO.toFixed(4),
    formula: `ceil(${count} × ${RATIO.toFixed(4)}) = ${observationCount}`
  };
}

/**
 * 格式化输出决策方案
 * @param {Object} plan - 决策方案
 * @returns {string} 格式化后的文本
 */
function formatPlan(plan) {
  const lines = [];
  lines.push('='.repeat(50));
  lines.push('37%法则决策分析结果');
  lines.push('='.repeat(50));
  lines.push('');

  if (plan.type === 'days') {
    lines.push(`📅 决策类型：按天数决策`);
    lines.push(`📊 总时长：${plan.total} 天`);
    lines.push(`🔍 观察期：前 ${plan.observationDays} 天（只观察不决策）`);
    lines.push(`✅ 决策期：第 ${plan.decisionStartDay} 天起（遇优即选）`);
    lines.push('');
    lines.push(`计算公式：${plan.formula}`);
    lines.push(`比例系数：1/e ≈ ${plan.ratio}`);
    lines.push('');
    lines.push('📋 执行建议：');
    lines.push(`  • 第 1-${plan.observationEndDay} 天：建立标准，记录最优选项特征`);
    lines.push(`  • 第 ${plan.decisionStartDay}-${plan.total} 天：遇到比之前更好的立即确定`);
  } else {
    lines.push(`📋 决策类型：按选项数量决策`);
    lines.push(`📊 总选项：${plan.total} 个`);
    lines.push(`🔍 观察样本：前 ${plan.observationCount} 个（只对比不敲定）`);
    lines.push(`✅ 决策节点：第 ${plan.decisionStartIndex} 个开始（择优选择）`);
    lines.push('');
    lines.push(`计算公式：${plan.formula}`);
    lines.push(`比例系数：1/e ≈ ${plan.ratio}`);
    lines.push('');
    lines.push('📋 执行建议：');
    lines.push(`  • 第 1-${plan.observationEndIndex} 个：建立标准，记录最优选项`);
    lines.push(`  • 第 ${plan.decisionStartIndex}-${plan.total} 个：遇到比之前更好的立即确定`);
  }

  lines.push('');
  lines.push('💡 使用口诀：');
  lines.push('  先算三七线，划定观察期');
  lines.push('  前期建标准，忍住不下手');
  lines.push('  后期遇更好，马上做决定');
  lines.push('  拒绝无限纠结，避免两头落空');
  lines.push('');
  lines.push('='.repeat(50));

  return lines.join('\n');
}

/**
 * 生成决策记录模板
 * @param {Object} plan - 决策方案
 * @returns {string} 记录模板
 */
function generateRecordTemplate(plan) {
  const lines = [];
  lines.push('='.repeat(50));
  lines.push('37%法则决策记录表');
  lines.push('='.repeat(50));
  lines.push('');

  if (plan.type === 'days') {
    lines.push(`总决策周期：${plan.total} 天`);
    lines.push(`观察截止日：第 ${plan.observationDays} 天`);
    lines.push(`决策启动日：第 ${plan.decisionStartDay} 天`);
  } else {
    lines.push(`总选项数量：${plan.total} 个`);
    lines.push(`观察截止数：第 ${plan.observationCount} 个`);
    lines.push(`决策启动点：第 ${plan.decisionStartIndex} 个`);
  }

  lines.push('');
  lines.push('观察期最优标准记录：');
  lines.push('_________________________________________');
  lines.push('_________________________________________');
  lines.push('_________________________________________');
  lines.push('');
  lines.push('最终决策结果：');
  lines.push('_________________________________________');
  lines.push('决策时间/序号：___________________________');
  lines.push('');
  lines.push('='.repeat(50));

  return lines.join('\n');
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
37%法则计算器 - 最优停止理论决策工具

用法:
  node calculate.js <类型> <数值> [选项]

类型:
  days     - 按天数决策（如找房、择偶周期）
  options  - 按选项数量决策（如面试Offer、商品选择）

选项:
  --template, -t  - 同时输出决策记录模板
  --json, -j      - 以JSON格式输出
  --help, -h      - 显示帮助信息

示例:
  node calculate.js days 30
  node calculate.js options 20 --template
  node calculate.js days 90 --json
`);
    return;
  }

  const type = args[0];
  const value = parseFloat(args[1]);

  if (isNaN(value) || value <= 0) {
    console.error('错误：请输入有效的正数');
    process.exit(1);
  }

  const showTemplate = args.includes('--template') || args.includes('-t');
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    let plan;
    if (type === 'days') {
      plan = generateDaysPlan(value);
    } else if (type === 'options') {
      plan = generateOptionsPlan(value);
    } else {
      console.error('错误：类型必须是 "days" 或 "options"');
      process.exit(1);
    }

    if (outputJson) {
      console.log(JSON.stringify(plan, null, 2));
    } else {
      console.log(formatPlan(plan));
      if (showTemplate) {
        console.log('\n');
        console.log(generateRecordTemplate(plan));
      }
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  calculateObservationPoint,
  generateDaysPlan,
  generateOptionsPlan,
  formatPlan,
  generateRecordTemplate,
  RATIO
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
