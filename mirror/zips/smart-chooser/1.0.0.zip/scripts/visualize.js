#!/usr/bin/env node

/**
 * 可视化报告生成器
 * 生成 HTML 报告，包含雷达图、柱状图等可视化组件
 */

const fs = require('fs');
const path = require('path');

/**
 * 生成雷达图数据
 * @param {Object} option - 选项数据
 * @param {Object} config - 配置
 * @returns {string} SVG 雷达图
 */
function generateRadarChart(option, config) {
  const dimensions = Object.keys(option._scores || {});
  if (dimensions.length === 0) return '';

  const size = 200;
  const center = size / 2;
  const radius = 80;
  const angleStep = (2 * Math.PI) / dimensions.length;

  // 生成多边形点
  const points = dimensions.map((dim, idx) => {
    const score = option._scores[dim] || 0;
    const angle = idx * angleStep - Math.PI / 2;
    const r = radius * score;
    const x = center + r * Math.cos(angle);
    const y = center + r * Math.sin(angle);
    return `${x},${y}`;
  }).join(' ');

  // 生成轴线
  const axes = dimensions.map((dim, idx) => {
    const angle = idx * angleStep - Math.PI / 2;
    const x = center + radius * Math.cos(angle);
    const y = center + radius * Math.sin(angle);
    const labelX = center + (radius + 15) * Math.cos(angle);
    const labelY = center + (radius + 15) * Math.sin(angle);
    return `
      <line x1="${center}" y1="${center}" x2="${x}" y2="${y}" stroke="#ddd" stroke-width="1"/>
      <text x="${labelX}" y="${labelY}" text-anchor="middle" font-size="10" fill="#666">${dim}</text>
    `;
  }).join('');

  // 生成同心圆
  const circles = [0.25, 0.5, 0.75, 1].map(ratio => {
    const r = radius * ratio;
    return `<circle cx="${center}" cy="${center}" r="${r}" fill="none" stroke="#eee" stroke-width="1"/>`;
  }).join('');

  return `
    <svg width="${size}" height="${size}" class="radar-chart">
      ${circles}
      ${axes}
      <polygon points="${points}" fill="rgba(66, 153, 225, 0.3)" stroke="#4299e1" stroke-width="2"/>
    </svg>
  `;
}

/**
 * 生成柱状图
 * @param {Array} options - 选项列表
 * @param {string} dimension - 维度
 * @returns {string} SVG 柱状图
 */
function generateBarChart(options, dimension) {
  const width = 400;
  const height = 200;
  const barWidth = width / options.length - 10;
  const maxValue = Math.max(...options.map(o => o[dimension] || 0));

  const bars = options.map((opt, idx) => {
    const value = opt[dimension] || 0;
    const barHeight = (value / maxValue) * (height - 40);
    const x = idx * (barWidth + 10) + 5;
    const y = height - barHeight - 20;
    return `
      <rect x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" fill="#4299e1" rx="3"/>
      <text x="${x + barWidth/2}" y="${height - 5}" text-anchor="middle" font-size="10" fill="#666">${opt.name}</text>
      <text x="${x + barWidth/2}" y="${y - 5}" text-anchor="middle" font-size="10" fill="#4299e1">${value}</text>
    `;
  }).join('');

  return `
    <svg width="${width}" height="${height}" class="bar-chart">
      ${bars}
    </svg>
  `;
}

/**
 * 生成对比表格
 * @param {Object} bestOption - 观察期最优
 * @param {Object} recommendedOption - 推荐选项
 * @param {Object} config - 配置
 * @returns {string} HTML 表格
 */
function generateComparisonTable(bestOption, recommendedOption, config) {
  if (!bestOption || !recommendedOption) return '';

  const dimensions = Object.keys(bestOption._scores || {});

  const rows = dimensions.map(dim => {
    const isReverse = config[dim]?.reverse;
    const bestScore = Math.round((bestOption._scores[dim] || 0) * 100);
    const recScore = Math.round((recommendedOption._scores[dim] || 0) * 100);
    const bestValue = bestOption[dim];
    const recValue = recommendedOption[dim];
    const winner = isReverse
      ? (recScore <= bestScore ? 'recommended' : 'best')
      : (recScore >= bestScore ? 'recommended' : 'best');

    return `
      <tr>
        <td>${dim}</td>
        <td class="${winner === 'best' ? 'highlight' : ''}">${bestValue} (${bestScore}%)</td>
        <td class="${winner === 'recommended' ? 'highlight' : ''}">${recValue} (${recScore}%)</td>
        <td>${isReverse ? '越小越好' : '越大越好'}</td>
      </tr>
    `;
  }).join('');

  return `
    <table class="comparison-table">
      <thead>
        <tr>
          <th>维度</th>
          <th>观察期最优 (${bestOption.name})</th>
          <th>推荐选项 (${recommendedOption.name})</th>
          <th>方向</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
    </table>
  `;
}

/**
 * 生成完整 HTML 报告
 * @param {Object} result - 决策结果
 * @param {Object} config - 配置
 * @returns {string} HTML 内容
 */
function generateHTMLReport(result, config) {
  const bestOption = result.observationPhase?.bestOption;
  const recommendedOption = result.decisionPhase?.recommended;

  const radarCharts = result.rankedOptions.slice(0, 3).map(opt => `
    <div class="radar-container">
      <h4>${opt.name} (得分: ${opt.totalScore.toFixed(1)})</h4>
      ${generateRadarChart(opt, config)}
    </div>
  `).join('');

  const barCharts = result.dimensions.slice(0, 3).map(dim => `
    <div class="chart-container">
      <h4>${dim}对比</h4>
      ${generateBarChart(result.rankedOptions.slice(0, 5), dim)}
    </div>
  `).join('');

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>37%法则决策分析报告</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px;
      text-align: center;
    }
    .header h1 { font-size: 2.5em; margin-bottom: 10px; }
    .header p { opacity: 0.9; font-size: 1.1em; }
    .content { padding: 40px; }
    .section { margin-bottom: 40px; }
    .section h2 {
      color: #333;
      border-bottom: 3px solid #667eea;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    .stat-card {
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      padding: 20px;
      border-radius: 12px;
      text-align: center;
    }
    .stat-card .number {
      font-size: 2.5em;
      font-weight: bold;
      color: #667eea;
    }
    .stat-card .label { color: #666; margin-top: 5px; }
    .ranking-list {
      list-style: none;
    }
    .ranking-item {
      display: flex;
      align-items: center;
      padding: 15px;
      margin-bottom: 10px;
      background: #f8f9fa;
      border-radius: 8px;
      transition: transform 0.2s;
    }
    .ranking-item:hover { transform: translateX(10px); }
    .rank { font-size: 1.5em; font-weight: bold; color: #667eea; margin-right: 20px; }
    .name { flex: 1; font-size: 1.1em; }
    .score { font-size: 1.3em; font-weight: bold; color: #764ba2; }
    .score-bar {
      width: 100px;
      height: 8px;
      background: #e0e0e0;
      border-radius: 4px;
      margin-left: 15px;
      overflow: hidden;
    }
    .score-bar-fill {
      height: 100%;
      background: linear-gradient(90deg, #667eea, #764ba2);
      border-radius: 4px;
    }
    .charts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
    }
    .radar-container, .chart-container {
      background: #f8f9fa;
      padding: 20px;
      border-radius: 12px;
      text-align: center;
    }
    .radar-container h4, .chart-container h4 {
      margin-bottom: 15px;
      color: #333;
    }
    .comparison-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .comparison-table th, .comparison-table td {
      padding: 12px;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
    }
    .comparison-table th {
      background: #667eea;
      color: white;
    }
    .comparison-table .highlight {
      background: #e8f5e9;
      font-weight: bold;
      color: #2e7d32;
    }
    .recommendation {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      text-align: center;
    }
    .recommendation h3 { font-size: 1.5em; margin-bottom: 15px; }
    .recommendation .reason { font-size: 1.1em; opacity: 0.95; }
    .action-list {
      background: #f8f9fa;
      padding: 20px;
      border-radius: 12px;
    }
    .action-list li {
      padding: 10px 0;
      border-bottom: 1px dashed #ddd;
    }
    .action-list li:last-child { border-bottom: none; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>37%法则决策分析报告</h1>
      <p>基于最优停止理论的智能决策辅助</p>
    </div>
    <div class="content">
      <div class="section">
        <h2>决策概览</h2>
        <div class="stats-grid">
          <div class="stat-card">
            <div class="number">${result.totalOptions}</div>
            <div class="label">总选项数</div>
          </div>
          <div class="stat-card">
            <div class="number">${result.plan.observationCount}</div>
            <div class="label">观察期数量</div>
          </div>
          <div class="stat-card">
            <div class="number">${result.plan.decisionStartIndex}</div>
            <div class="label">决策起始点</div>
          </div>
          <div class="stat-card">
            <div class="number">${result.dimensions.length}</div>
            <div class="label">评估维度</div>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>选项排名</h2>
        <ul class="ranking-list">
          ${result.rankedOptions.slice(0, 8).map((opt, idx) => `
            <li class="ranking-item">
              <span class="rank">#${opt.rank}</span>
              <span class="name">${opt.name}</span>
              <span class="score">${opt.totalScore.toFixed(1)}</span>
              <div class="score-bar">
                <div class="score-bar-fill" style="width: ${opt.totalScore}%"></div>
              </div>
            </li>
          `).join('')}
        </ul>
      </div>

      <div class="section">
        <h2>可视化分析</h2>
        <div class="charts-grid">
          ${radarCharts}
        </div>
        <div style="margin-top: 30px;">
          ${barCharts}
        </div>
      </div>

      ${bestOption && recommendedOption ? `
      <div class="section">
        <h2>对比分析</h2>
        ${generateComparisonTable(bestOption, recommendedOption, config)}
      </div>
      ` : ''}

      ${recommendedOption ? `
      <div class="section">
        <h2>最终推荐</h2>
        <div class="recommendation">
          <h3>推荐选择：${recommendedOption.name}</h3>
          <p class="reason">${recommendedOption.reason || '综合评分最优'}</p>
          <p style="margin-top: 10px; font-size: 1.3em;">综合得分：${recommendedOption.score}</p>
        </div>
      </div>
      ` : ''}

      <div class="section">
        <h2>执行清单</h2>
        <ol class="action-list">
          ${result.actionItems.map(item => `<li>${item}</li>`).join('')}
        </ol>
      </div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * 生成可视化报告
 * @param {string} dataFile - 数据文件路径
 * @param {string} outputFile - 输出文件路径
 */
function generateReport(dataFile, outputFile) {
  const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  const { decisionPipeline } = require('./pipeline.js');
  const result = decisionPipeline(data);

  const html = generateHTMLReport(result, data.config);
  fs.writeFileSync(outputFile, html);

  console.log(`可视化报告已生成: ${outputFile}`);
  return outputFile;
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
可视化报告生成器

用法:
  node visualize.js <数据文件> [输出文件]

示例:
  node visualize.js data.json report.html
  node visualize.js data.json
`);
    return;
  }

  const dataFile = args[0];
  const outputFile = args[1] || 'decision-report.html';

  try {
    generateReport(dataFile, outputFile);
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  generateRadarChart,
  generateBarChart,
  generateComparisonTable,
  generateHTMLReport,
  generateReport
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
