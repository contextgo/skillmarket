#!/usr/bin/env node

/**
 * 交互式决策助手
 * 支持表格数据 + 用户偏好输入，输出决策建议
 */

const fs = require('fs');
const path = require('path');

/**
 * 解析表格数据
 * @param {string} tableText - 表格文本
 * @returns {Object} 解析结果 {headers, rows}
 */
function parseTable(tableText) {
  const lines = tableText.trim().split('\n').filter(line => line.trim());
  if (lines.length < 2) {
    throw new Error('表格至少需要包含表头和一行数据');
  }

  // 解析表头
  const headerLine = lines[0];
  const headers = headerLine.split(/[,\t|]/).map(h => h.trim()).filter(h => h);

  // 解析数据行
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(/[,\t|]/).map(v => v.trim()).filter(v => v);
    if (values.length >= headers.length) {
      const row = {};
      headers.forEach((h, idx) => {
        // 尝试转换为数字
        const num = parseFloat(values[idx]);
        row[h] = isNaN(num) ? values[idx] : num;
      });
      rows.push(row);
    }
  }

  return { headers, rows };
}

/**
 * 解析用户偏好
 * @param {string} preferenceText - 偏好文本
 * @returns {Object} 偏好配置
 */
function parsePreferences(preferenceText) {
  const preferences = {
    weights: {},
    reverse: {},
    constraints: {}
  };

  const lines = preferenceText.trim().split('\n').filter(line => line.trim());

  for (const line of lines) {
    // 权重配置: 价格:3, 质量:2
    const weightMatch = line.match(/(.+?)[:：]\s*(\d+)/);
    if (weightMatch) {
      const key = weightMatch[1].trim();
      const weight = parseInt(weightMatch[2]);
      preferences.weights[key] = weight;
      continue;
    }

    // 反向指标: 价格越小越好, 距离反向
    const reverseMatch = line.match(/(.+?)(?:越小越好|反向|越低越好)/);
    if (reverseMatch) {
      const key = reverseMatch[1].trim();
      preferences.reverse[key] = true;
      continue;
    }

    // 约束条件: 预算<=5000, 经验>=3年
    const constraintMatch = line.match(/(.+?)(<=|>=|<|>|=)\s*(\d+)/);
    if (constraintMatch) {
      const key = constraintMatch[1].trim();
      const op = constraintMatch[2];
      const value = parseFloat(constraintMatch[3]);
      preferences.constraints[key] = { op, value };
    }
  }

  return preferences;
}

/**
 * 生成决策配置
 * @param {Object} tableData - 表格数据
 * @param {Object} preferences - 用户偏好
 * @returns {Object} 完整配置
 */
function generateConfig(tableData, preferences) {
  const { headers, rows } = tableData;
  const config = {};

  // 自动识别数值列并生成配置
  headers.forEach(header => {
    // 跳过名称列
    if (header === '名称' || header === 'name' || header === '选项') {
      return;
    }

    // 检查该列是否为数值
    const isNumeric = rows.every(row => typeof row[header] === 'number');
    if (!isNumeric) return;

    const values = rows.map(r => r[header]);
    const min = Math.min(...values);
    const max = Math.max(...values);

    // 判断是否为反向指标（价格、成本、距离等关键词）
    const isReverseKeyword = /价格|成本|费用|距离|时间|薪资|工资/.test(header);
    const isReverse = preferences.reverse[header] || isReverseKeyword;

    config[header] = {
      weight: preferences.weights[header] || 1,
      reverse: isReverse,
      min,
      max
    };
  });

  return config;
}

/**
 * 过滤不符合约束的选项
 * @param {Array} rows - 数据行
 * @param {Object} constraints - 约束条件
 * @returns {Array} 过滤后的数据
 */
function filterByConstraints(rows, constraints) {
  return rows.filter(row => {
    for (const [key, constraint] of Object.entries(constraints)) {
      const value = row[key];
      if (typeof value !== 'number') continue;

      const { op, value: limit } = constraint;
      switch (op) {
        case '<=': if (value > limit) return false; break;
        case '>=': if (value < limit) return false; break;
        case '<': if (value >= limit) return false; break;
        case '>': if (value <= limit) return false; break;
        case '=': if (value !== limit) return false; break;
      }
    }
    return true;
  });
}

/**
 * 运行决策分析
 * @param {string} tableFile - 表格文件路径
 * @param {string} preferenceFile - 偏好文件路径（可选）
 */
function runDecision(tableFile, preferenceFile = null) {
  // 读取表格数据
  const tableText = fs.readFileSync(tableFile, 'utf8');
  const tableData = parseTable(tableText);

  console.log('【数据概览】');
  console.log(`  选项数量: ${tableData.rows.length}`);
  console.log(`  评估维度: ${tableData.headers.join(', ')}`);
  console.log('');

  // 读取用户偏好
  let preferences = { weights: {}, reverse: {}, constraints: {} };
  if (preferenceFile && fs.existsSync(preferenceFile)) {
    const prefText = fs.readFileSync(preferenceFile, 'utf8');
    preferences = parsePreferences(prefText);
    console.log('【用户偏好】');
    console.log(`  权重配置: ${JSON.stringify(preferences.weights)}`);
    console.log(`  反向指标: ${Object.keys(preferences.reverse).join(', ') || '无'}`);
    console.log(`  约束条件: ${JSON.stringify(preferences.constraints)}`);
    console.log('');
  }

  // 应用约束过滤
  let filteredRows = tableData.rows;
  if (Object.keys(preferences.constraints).length > 0) {
    filteredRows = filterByConstraints(tableData.rows, preferences.constraints);
    console.log(`【约束过滤】从 ${tableData.rows.length} 个选项中筛选出 ${filteredRows.length} 个`);
    console.log('');
  }

  if (filteredRows.length === 0) {
    throw new Error('没有符合约束条件的选项');
  }

  // 生成配置
  const config = generateConfig({ headers: tableData.headers, rows: filteredRows }, preferences);

  // 构建pipeline输入 - 确保每个选项有name字段
  const pipelineInput = {
    scenario: '交互式决策',
    options: filteredRows.map((row, idx) => {
      // 提取名称字段（支持多种命名）
      const name = row['名称'] || row['name'] || row['选项'] || row['Name'] || `选项${idx + 1}`;
      return {
        name: name,
        ...row
      };
    }),
    config: config,
    preferences: preferences.constraints
  };

  // 保存临时文件
  const tempFile = path.join('/home/project/tmp', `decision-${Date.now()}.json`);
  fs.mkdirSync('/home/project/tmp', { recursive: true });
  fs.writeFileSync(tempFile, JSON.stringify(pipelineInput, null, 2));

  console.log('【评分配置】');
  for (const [dim, cfg] of Object.entries(config)) {
    const direction = cfg.reverse ? '越小越好' : '越大越好';
    console.log(`  ${dim}: 权重${cfg.weight}, ${direction}, 范围[${cfg.min}-${cfg.max}]`);
  }
  console.log('');

  return tempFile;
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
交互式决策助手

用法:
  node interactive.js <表格文件> [偏好文件] [选项]

输入格式:

【表格文件】CSV或制表符分隔格式:
名称,价格,面积,距离
房源A,5500,75,25
房源B,4800,65,35

【偏好文件】文本格式:
价格:3          # 权重配置
面积:2
距离:2
价格越小越好    # 反向指标
距离越小越好
价格<=6000      # 约束条件
面积>=60

选项:
  --run, -r       - 自动运行决策分析
  --json, -j      - 输出JSON格式
  --help, -h      - 显示帮助信息

示例:
  node interactive.js houses.csv preferences.txt --run
  node interactive.js candidates.csv
`);
    return;
  }

  const tableFile = args[0];
  const preferenceFile = args[1] && !args[1].startsWith('--') ? args[1] : null;
  const autoRun = args.includes('--run') || args.includes('-r');
  const outputJson = args.includes('--json') || args.includes('-j');

  try {
    const tempFile = runDecision(tableFile, preferenceFile);

    if (outputJson) {
      const data = JSON.parse(fs.readFileSync(tempFile, 'utf8'));
      console.log(JSON.stringify(data, null, 2));
    } else if (autoRun) {
      // 调用pipeline
      const { decisionPipeline, generatePipelineReport } = require('./pipeline.js');
      const data = JSON.parse(fs.readFileSync(tempFile, 'utf8'));
      const result = decisionPipeline(data);
      console.log(generatePipelineReport(result));
    } else {
      console.log(`配置已保存到: ${tempFile}`);
      console.log('运行以下命令进行决策分析:');
      console.log(`  node scripts/pipeline.js ${tempFile}`);
    }

    // 清理临时文件
    if (!outputJson) {
      fs.unlinkSync(tempFile);
    }
  } catch (error) {
    console.error('错误：', error.message);
    process.exit(1);
  }
}

// 导出函数供其他模块使用
module.exports = {
  parseTable,
  parsePreferences,
  generateConfig,
  filterByConstraints,
  runDecision
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
