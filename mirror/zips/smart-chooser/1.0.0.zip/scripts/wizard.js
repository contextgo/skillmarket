#!/usr/bin/env node

/**
 * 交互式决策向导
 * 通过问答模式逐步收集用户输入，引导完成决策分析
 */

const readline = require('readline');
const fs = require('fs');
const path = require('path');

const { listTemplates, getTemplate } = require('./templates.js');
const { decisionPipeline, generatePipelineReport } = require('./pipeline.js');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function ask(question) {
  return new Promise(resolve => {
    rl.question(question, answer => resolve(answer.trim()));
  });
}

async function selectTemplate() {
  console.log('\n📋 请选择决策场景模板：');
  console.log('0. 自定义场景');

  const templates = listTemplates();
  templates.forEach((t, idx) => {
    console.log(`${idx + 1}. ${t.name} - ${t.description}`);
  });

  const choice = await ask('\n请输入编号 (0-' + templates.length + '): ');
  const index = parseInt(choice);

  if (index === 0) {
    return null;
  } else if (index > 0 && index <= templates.length) {
    return templates[index - 1].key;
  } else {
    console.log('无效选择，使用自定义场景');
    return null;
  }
}

async function inputOptions() {
  console.log('\n📝 请输入选项数据（每行一个选项，格式：名称,维度1,维度2,...）');
  console.log('示例：房源A,5500,75,25,8,7');
  console.log('输入空行结束\n');

  const options = [];
  let lineNum = 1;

  while (true) {
    const line = await ask(`选项${lineNum}: `);
    if (!line) break;

    const values = line.split(/[,\t]/).map(v => v.trim());
    if (values.length >= 2) {
      const option = { name: values[0] };
      for (let i = 1; i < values.length; i++) {
        const num = parseFloat(values[i]);
        option[`维度${i}`] = isNaN(num) ? values[i] : num;
      }
      options.push(option);
      lineNum++;
    }
  }

  return options;
}

async function inputDimensions(options) {
  console.log('\n📊 请为每个维度设置名称和权重');

  const dimensions = Object.keys(options[0]).filter(k => k !== 'name');
  const config = {};

  for (const dim of dimensions) {
    console.log(`\n维度: ${dim}`);
    const name = await ask('  显示名称（如：价格、面积）: ') || dim;
    const weight = parseInt(await ask('  权重（1-5，越大越重要）: ') || '1');
    const isReverse = (await ask('  是否越小越好? (y/n): ')).toLowerCase() === 'y';

    config[name] = {
      weight: Math.min(5, Math.max(1, weight)),
      reverse: isReverse
    };

    // 更新选项中的维度名称
    options.forEach(opt => {
      opt[name] = opt[dim];
      delete opt[dim];
    });
  }

  return config;
}

async function inputConstraints(dimensions) {
  console.log('\n🔒 请设置约束条件（可选，直接回车跳过）');

  const constraints = {};

  for (const dim of dimensions) {
    const constraint = await ask(`  ${dim} 约束（如：<=5000, >=60）: `);
    if (constraint) {
      const match = constraint.match(/(<=|>=|<|>|=)\s*(\d+)/);
      if (match) {
        constraints[dim] = {
          op: match[1],
          value: parseFloat(match[2])
        };
      }
    }
  }

  return constraints;
}

async function selectStrategy() {
  console.log('\n🎯 请选择决策策略：');
  console.log('1. 37%法则（推荐）- 理论最优停止策略');
  console.log('2. 贪心算法 - 直接选最高分');
  console.log('3. 满意即可 - 达到阈值即选');
  console.log('4. 探索-利用平衡 - 更保守的策略');
  console.log('5. 对比所有策略');

  const choice = await ask('\n请输入编号 (1-5): ') || '1';
  return choice;
}

async function runWizard() {
  console.log('='.repeat(60));
  console.log('🎯 37%法则交互式决策向导');
  console.log('='.repeat(60));

  // 步骤1: 选择模板
  const templateKey = await selectTemplate();
  let scenario = '自定义决策';
  let options = [];
  let config = {};
  let constraints = {};

  if (templateKey) {
    const template = getTemplate(templateKey);
    scenario = template.name;
    config = template.config;
    console.log(`\n✅ 已选择模板: ${template.name}`);
    console.log(`   维度: ${template.dimensions.join(', ')}`);
    console.log('\n💡 提示: ' + template.tips[0]);

    // 使用模板示例数据或自定义输入
    const useSample = (await ask('\n使用模板示例数据? (y/n): ')).toLowerCase() === 'y';
    if (useSample) {
      const lines = template.sample.split('\n');
      const headers = lines[0].split(',');
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const row = { name: values[0] };
        template.dimensions.forEach((dim, idx) => {
          row[dim] = parseFloat(values[idx + 1]);
        });
        options.push(row);
      }
    } else {
      options = await inputOptions();
    }
  } else {
    // 自定义场景
    scenario = await ask('\n请输入决策场景名称: ') || '自定义决策';
    options = await inputOptions();
    if (options.length === 0) {
      console.log('未输入任何选项，退出');
      rl.close();
      return;
    }
    config = await inputDimensions(options);
  }

  // 步骤2: 设置约束
  const dimensions = Object.keys(config);
  constraints = await inputConstraints(dimensions);

  // 步骤3: 选择策略
  const strategyChoice = await selectStrategy();

  // 步骤4: 运行决策
  console.log('\n⏳ 正在分析...\n');

  const data = {
    scenario,
    options,
    config,
    preferences: { constraints }
  };

  // 保存临时文件
  const tempFile = path.join('/home/project/tmp', `wizard-${Date.now()}.json`);
  fs.mkdirSync('/home/project/tmp', { recursive: true });
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2));

  // 根据策略选择执行
  if (strategyChoice === '5') {
    const { compareStrategies, generateStrategyReport } = require('./strategy.js');
    const result = compareStrategies(options, config);
    console.log(generateStrategyReport(result));
  } else {
    const result = decisionPipeline(data);
    console.log(generatePipelineReport(result));

    // 询问是否生成可视化报告
    const genReport = (await ask('\n生成可视化HTML报告? (y/n): ')).toLowerCase() === 'y';
    if (genReport) {
      const { generateReport } = require('./visualize.js');
      const reportFile = `decision-report-${Date.now()}.html`;
      generateReport(tempFile, reportFile);
      console.log(`\n📄 报告已生成: ${reportFile}`);
    }
  }

  // 清理临时文件
  fs.unlinkSync(tempFile);

  console.log('\n✅ 决策分析完成！');
  rl.close();
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);

  if (args.includes('--help') || args.includes('-h')) {
    console.log(`
交互式决策向导

用法:
  node wizard.js

功能:
  1. 选择场景模板（租房、Offer、购车等）
  2. 输入选项数据
  3. 设置维度权重和约束
  4. 选择决策策略
  5. 生成决策报告

示例:
  node wizard.js
`);
    return;
  }

  runWizard().catch(error => {
    console.error('错误：', error.message);
    rl.close();
    process.exit(1);
  });
}

// 导出函数供其他模块使用
module.exports = {
  selectTemplate,
  inputOptions,
  inputDimensions,
  inputConstraints,
  selectStrategy,
  runWizard
};

// 如果是直接运行则执行主函数
if (require.main === module) {
  main();
}
