#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
实时股票行情获取脚本
支持 A股 / 港股 / 美股
数据来源: 东方财富 / 新浪财经
用法:
    python fetch_stock.py <股票代码> [--market sh|sz|hk|us]
    python fetch_stock.py 302132
    python fetch_stock.py 600519
    python fetch_stock.py 00700 --market hk
    python fetch_stock.py AAPL --market us
"""

import sys
import json
import argparse
import urllib.request
import urllib.parse
import re

# ─────────────────────────────────────────────
# 常量
# ─────────────────────────────────────────────
EASTMONEY_QUOTE_URL = "https://push2.eastmoney.com/api/qt/stock/get"
SINA_QUOTE_URL      = "https://hq.sinajs.cn/list="

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Referer": "https://finance.sina.com.cn/",
}


# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────
def http_get(url: str, headers: dict | None = None) -> str:
    req = urllib.request.Request(url, headers=headers or HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.read().decode("gbk", errors="replace")


def http_get_json(url: str) -> dict:
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def auto_detect_market(code: str) -> str:
    """自动识别市场"""
    code = code.upper()
    if re.match(r"^6\d{5}$", code):
        return "sh"   # 沪市主板
    if re.match(r"^(00|30|02)\d{4}$", code):
        return "sz"   # 深市主板/创业板
    if re.match(r"^\d{5}$", code):
        return "hk"   # 港股5位
    if re.match(r"^[A-Z]{1,5}$", code):
        return "us"   # 美股
    return "sz"        # 默认深市


# ─────────────────────────────────────────────
# 东方财富行情（A股主力）
# ─────────────────────────────────────────────
def _em_secid(code: str, market: str) -> str:
    prefix = "1" if market == "sh" else "0"
    return f"{prefix}.{code}"


def fetch_eastmoney(code: str, market: str) -> dict:
    secid = _em_secid(code, market)
    params = {
        "fields":  "f43,f44,f45,f46,f47,f48,f50,f51,f52,f57,f58,f60,f170,f169",
        "secid":   secid,
        "ut":      "fa5fd1943c7b386f172d6893dbfba10b",
        "invt":    "2",
        "fltt":    "1",
        "cb":      "",
    }
    url = EASTMONEY_QUOTE_URL + "?" + urllib.parse.urlencode(params)
    data = http_get_json(url)
    d = data.get("data", {})

    # f43=现价, f44=最高, f45=最低, f46=开盘, f60=昨收
    # f170=涨跌幅(%), f169=涨跌额, f47=成交量(手), f48=成交额
    try:
        price     = d.get("f43", "-")
        high      = d.get("f44", "-")
        low       = d.get("f45", "-")
        open_p    = d.get("f46", "-")
        pre_close = d.get("f60", "-")
        chg_pct   = d.get("f170", "-")
        chg_amt   = d.get("f169", "-")
        volume    = d.get("f47", "-")
        amount    = d.get("f48", "-")
        name      = d.get("f58", code)
        limit_up  = d.get("f51", "-")
        limit_dn  = d.get("f52", "-")

        def fmt(v, div=100):
            try: return round(float(v) / div, 2)
            except: return v

        return {
            "name":      name,
            "code":      code,
            "market":    market.upper(),
            "price":     fmt(price),
            "open":      fmt(open_p),
            "high":      fmt(high),
            "low":       fmt(low),
            "pre_close": fmt(pre_close),
            "chg_pct":   f"{fmt(chg_pct, 100)}%",
            "chg_amt":   fmt(chg_amt),
            "volume":    f"{fmt(volume, 1)}手",
            "amount":    f"{round(float(amount)/1e8, 2)}亿" if amount != "-" else "-",
            "limit_up":  fmt(limit_up),
            "limit_dn":  fmt(limit_dn),
            "source":    "eastmoney",
        }
    except Exception as e:
        return {"error": str(e), "raw": d}


# ─────────────────────────────────────────────
# 新浪财经行情（港股/美股/备用A股）
# ─────────────────────────────────────────────
SINA_PREFIX = {
    "sh": "sh",
    "sz": "sz",
    "hk": "hk",
    "us": "gb_",
}

SINA_A_FIELDS = [
    "name","open","pre_close","price","high","low",
    "buy1","sell1","vol","amount",
    "bid1_vol","bid1","bid2_vol","bid2","bid3_vol","bid3","bid4_vol","bid4","bid5_vol","bid5",
    "ask1_vol","ask1","ask2_vol","ask2","ask3_vol","ask3","ask4_vol","ask4","ask5_vol","ask5",
    "date","time","status"
]

def fetch_sina(code: str, market: str) -> dict:
    prefix  = SINA_PREFIX.get(market, "sz")
    sym     = f"{prefix}{code.lower()}"
    url     = SINA_QUOTE_URL + sym
    raw     = http_get(url)
    m = re.search(r'"([^"]*)"', raw)
    if not m:
        return {"error": "未找到行情数据", "raw": raw[:200]}

    parts = m.group(1).split(",")

    if market in ("sh", "sz"):
        if len(parts) < 10:
            return {"error": "字段不足", "raw": parts}
        name      = parts[0]
        open_p    = parts[1]
        pre_close = parts[2]
        price     = parts[3]
        high      = parts[4]
        low       = parts[5]
        vol       = parts[8]
        amount    = parts[9]
        try:
            chg_pct = round((float(price) - float(pre_close)) / float(pre_close) * 100, 2)
            chg_amt = round(float(price) - float(pre_close), 2)
        except:
            chg_pct = chg_amt = "-"
        return {
            "name":      name,
            "code":      code,
            "market":    market.upper(),
            "price":     price,
            "open":      open_p,
            "high":      high,
            "low":       low,
            "pre_close": pre_close,
            "chg_pct":   f"{chg_pct}%",
            "chg_amt":   chg_amt,
            "volume":    f"{round(int(vol)/100, 0)}手" if vol.isdigit() else vol,
            "amount":    f"{round(float(amount)/1e8, 2)}亿" if amount else "-",
            "source":    "sina",
        }

    elif market == "hk":
        # 港股字段: 名称,今开,昨收,现价,最高,最低,...
        if len(parts) < 6:
            return {"error": "港股字段不足", "raw": parts}
        name      = parts[1] if len(parts) > 1 else code
        pre_close = parts[3] if len(parts) > 3 else "-"
        price     = parts[6] if len(parts) > 6 else "-"
        high      = parts[4] if len(parts) > 4 else "-"
        low       = parts[5] if len(parts) > 5 else "-"
        open_p    = parts[2] if len(parts) > 2 else "-"
        try:
            chg_pct = round((float(price) - float(pre_close)) / float(pre_close) * 100, 2)
            chg_amt = round(float(price) - float(pre_close), 2)
        except:
            chg_pct = chg_amt = "-"
        return {
            "name":      name,
            "code":      code,
            "market":    "HK",
            "price":     price,
            "open":      open_p,
            "high":      high,
            "low":       low,
            "pre_close": pre_close,
            "chg_pct":   f"{chg_pct}%",
            "chg_amt":   chg_amt,
            "source":    "sina",
        }

    elif market == "us":
        if len(parts) < 5:
            return {"error": "美股字段不足", "raw": parts}
        name  = parts[0]
        price = parts[1]
        chg_amt = parts[2]
        chg_pct = parts[3]
        high  = parts[33] if len(parts) > 33 else "-"
        low   = parts[34] if len(parts) > 34 else "-"
        open_p = parts[5] if len(parts) > 5 else "-"
        pre_close = parts[26] if len(parts) > 26 else "-"
        return {
            "name":      name,
            "code":      code.upper(),
            "market":    "US",
            "price":     price,
            "open":      open_p,
            "high":      high,
            "low":       low,
            "pre_close": pre_close,
            "chg_pct":   f"{chg_pct}%",
            "chg_amt":   chg_amt,
            "source":    "sina",
        }

    return {"error": "不支持的市场", "market": market}


# ─────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────
def fetch(code: str, market: str | None = None) -> dict:
    if not market:
        market = auto_detect_market(code)

    if market in ("sh", "sz"):
        try:
            return fetch_eastmoney(code, market)
        except Exception as e:
            # 降级到新浪
            try:
                return fetch_sina(code, market)
            except Exception as e2:
                return {"error": f"东方财富失败: {e}; 新浪失败: {e2}"}
    else:
        try:
            return fetch_sina(code, market)
        except Exception as e:
            return {"error": str(e)}


def print_quote(info: dict):
    if "error" in info:
        print(f"❌ 获取失败: {info['error']}")
        return

    up = float(str(info.get("chg_pct","0%")).replace("%","")) >= 0
    arrow = "▲" if up else "▼"
    color_open  = "\033[91m" if up else "\033[92m"  # 涨红跌绿（A股惯例）
    reset = "\033[0m"

    print(f"\n{'='*45}")
    print(f"  {info.get('name','')}  ({info.get('code','')} · {info.get('market','')})")
    print(f"{'='*45}")
    print(f"  现价:   {color_open}{info.get('price','--')}{reset}  {arrow} {info.get('chg_amt','--')}  {info.get('chg_pct','--')}")
    print(f"  今开:   {info.get('open','--')}")
    print(f"  最高:   {info.get('high','--')}")
    print(f"  最低:   {info.get('low','--')}")
    print(f"  昨收:   {info.get('pre_close','--')}")
    if "limit_up" in info:
        print(f"  涨停:   {info.get('limit_up','--')}  跌停: {info.get('limit_dn','--')}")
    if "volume" in info:
        print(f"  成交量: {info.get('volume','--')}  成交额: {info.get('amount','--')}")
    print(f"  数据源: {info.get('source','--')}")
    print(f"{'='*45}\n")


def main():
    parser = argparse.ArgumentParser(description="实时股票行情查询")
    parser.add_argument("code",   help="股票代码, 如 302132 / 600519 / 00700 / AAPL")
    parser.add_argument("--market", choices=["sh","sz","hk","us"], default=None,
                        help="市场: sh=沪市 sz=深市 hk=港股 us=美股 (可自动识别)")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    args = parser.parse_args()

    info = fetch(args.code, args.market)

    if args.json:
        print(json.dumps(info, ensure_ascii=False, indent=2))
    else:
        print_quote(info)


if __name__ == "__main__":
    main()
