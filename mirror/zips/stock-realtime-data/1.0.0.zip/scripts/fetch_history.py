#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
历史股票行情获取脚本
支持 A股 / 港股 / 美股 历史K线数据
数据来源: 东方财富
用法:
    python fetch_history.py <股票代码> [--start YYYYMMDD] [--end YYYYMMDD] [--period daily|weekly|monthly] [--market sh|sz|hk|us]
    python fetch_history.py 302132
    python fetch_history.py 302132 --start 20260101 --end 20260325
    python fetch_history.py 600519 --period weekly --start 20250901
    python fetch_history.py 00700 --market hk --start 20260101
    python fetch_history.py AAPL --market us --start 20260101
"""

import sys
import json
import argparse
import urllib.request
import urllib.parse
import re
from datetime import datetime, timedelta

# ─────────────────────────────────────────────
# 常量
# ─────────────────────────────────────────────
EASTMONEY_KLINE_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Referer": "https://quote.eastmoney.com/",
}


# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────
def http_get_json(url: str) -> dict:
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def auto_detect_market(code: str) -> str:
    """自动识别市场"""
    code = code.upper()
    if re.match(r"^6\d{5}$", code):
        return "sh"
    if re.match(r"^(00|30|02)\d{4}$", code):
        return "sz"
    if re.match(r"^\d{5}$", code):
        return "hk"
    if re.match(r"^[A-Z]{1,5}$", code):
        return "us"
    return "sz"


def _em_secid(code: str, market: str) -> str:
    """构建东方财富 secid"""
    mapping = {"sh": "1", "sz": "0", "hk": "116", "us": "105"}
    prefix = mapping.get(market, "0")
    return f"{prefix}.{code}"


# ─────────────────────────────────────────────
# 东方财富历史K线
# ─────────────────────────────────────────────
# K线字段: 日期,开盘价,收盘价,最高价,最低价,成交量,成交额,振幅,涨跌幅,涨跌额,换手率
KLINE_FIELDS = "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13"

PERIOD_MAP = {
    "daily":   "101",
    "weekly":  "102",
    "monthly": "103",
}


def fetch_history(
    code: str,
    start_date: str | None = None,
    end_date: str | None = None,
    period: str = "daily",
    market: str | None = None,
    limit: int = 300,
) -> dict:
    """
    获取历史K线数据

    Args:
        code: 股票代码
        start_date: 开始日期 YYYYMMDD (默认: 半年前)
        end_date: 结束日期 YYYYMMDD (默认: 今天)
        period: 周期 daily/weekly/monthly
        market: 市场 sh/sz/hk/us
        limit: 最大返回条数
    """
    if not market:
        market = auto_detect_market(code)

    if not end_date:
        end_date = datetime.now().strftime("%Y%m%d")
    if not start_date:
        start = datetime.now() - timedelta(days=180)
        start_date = start.strftime("%Y%m%d")

    secid = _em_secid(code, market)
    klt = PERIOD_MAP.get(period, "101")

    params = {
        "secid":    secid,
        "fields1":  "f1,f2,f3,f4,f5,f6",
        "fields2":  "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63",
        "klt":      klt,
        "fqt":      "1",          # 前复权
        "beg":      start_date,
        "end":      end_date,
        "lmt":      str(limit),
        "ut":       "fa5fd1943c7b386f172d6893dbfba10b",
        "cb":       "",
    }

    url = EASTMONEY_KLINE_URL + "?" + urllib.parse.urlencode(params)
    data = http_get_json(url)

    if not data or "data" not in data or not data["data"]:
        return {"error": "未获取到K线数据", "code": code, "market": market}

    kdata = data["data"]
    name = kdata.get("name", code)
    code_raw = kdata.get("code", code)
    klines_raw = kdata.get("klines", [])

    if not klines_raw:
        return {"error": "K线数据为空", "code": code, "market": market}

    # 解析K线
    klines = []
    for line in klines_raw:
        parts = line.split(",")
        if len(parts) < 7:
            continue
        try:
            klines.append({
                "date":     parts[0],            # 日期
                "open":     float(parts[1]),     # 开盘价
                "close":    float(parts[2]),     # 收盘价
                "high":     float(parts[3]),     # 最高价
                "low":      float(parts[4]),     # 最低价
                "volume":   float(parts[5]),     # 成交量
                "amount":   float(parts[6]),     # 成交额
                "amplitude": float(parts[7]) if len(parts) > 7 else 0,   # 振幅%
                "chg_pct":  float(parts[8]) if len(parts) > 8 else 0,   # 涨跌幅%
                "chg_amt":  float(parts[9]) if len(parts) > 9 else 0,   # 涨跌额
                "turnover": float(parts[10]) if len(parts) > 10 else 0, # 换手率%
            })
        except (ValueError, IndexError):
            continue

    # 统计摘要
    if klines:
        closes = [k["close"] for k in klines]
        highs = [k["high"] for k in klines]
        lows = [k["low"] for k in klines]
        volumes = [k["volume"] for k in klines]
        amounts = [k["amount"] for k in klines]

        # 计算均线
        def ma(vals, n):
            if len(vals) < n:
                return None
            return round(sum(vals[-n:]) / n, 2)

        ma5 = ma(closes, 5)
        ma10 = ma(closes, 10)
        ma20 = ma(closes, 20)
        ma60 = ma(closes, 60)

        summary = {
            "period":         period,
            "date_range":     f"{klines[0]['date']} ~ {klines[-1]['date']}",
            "data_count":     len(klines),
            "latest_close":   closes[-1],
            "highest":        max(highs),
            "lowest":         min(lows),
            "avg_volume":     round(sum(volumes) / len(volumes), 0),
            "avg_amount":     round(sum(amounts) / len(amounts) / 1e8, 2),
            "total_amount":   round(sum(amounts) / 1e8, 2),
            "ma5": ma5, "ma10": ma10, "ma20": ma20, "ma60": ma60,
        }

        # 涨跌统计
        up_days = sum(1 for k in klines if k["chg_pct"] > 0)
        down_days = sum(1 for k in klines if k["chg_pct"] < 0)
        flat_days = len(klines) - up_days - down_days
        summary["up_days"] = up_days
        summary["down_days"] = down_days
        summary["flat_days"] = flat_days
        summary["up_ratio"] = f"{round(up_days/len(klines)*100, 1)}%"
    else:
        summary = {}

    return {
        "name":    name,
        "code":    code_raw,
        "market":  market.upper(),
        "source":  "eastmoney",
        "klines":  klines,
        "summary": summary,
    }


# ─────────────────────────────────────────────
# 输出格式化
# ─────────────────────────────────────────────
def print_history(result: dict):
    if "error" in result:
        print(f"❌ 获取失败: {result['error']}")
        return

    name = result["name"]
    code = result["code"]
    market = result["market"]
    summary = result["summary"]
    klines = result["klines"]

    up = klines[-1]["chg_pct"] >= 0
    arrow = "▲" if up else "▼"
    color = "\033[91m" if up else "\033[92m"
    reset = "\033[0m"

    print(f"\n{'='*60}")
    print(f"  {name} ({code} · {market})  历史行情")
    print(f"  区间: {summary.get('date_range', '-')}  共 {summary.get('data_count', 0)} 条")
    print(f"{'='*60}")

    # 摘要
    print(f"\n  ── 统计摘要 ──")
    print(f"  最新收盘: {color}{summary['latest_close']}{reset}  "
          f"{arrow} {klines[-1]['chg_amt']:+.2f} ({klines[-1]['chg_pct']:+.2f}%)")
    print(f"  区间最高: {summary['highest']}  区间最低: {summary['lowest']}")
    print(f"  均量: {summary['avg_volume']:.0f}手  均额: {summary['avg_amount']}亿  总额: {summary['total_amount']}亿")
    print(f"  上涨: {summary['up_days']}天  下跌: {summary['down_days']}天  平盘: {summary['flat_days']}天  涨率: {summary['up_ratio']}")

    # 均线
    ma_lines = []
    for label in ["ma5", "ma10", "ma20", "ma60"]:
        if summary.get(label) is not None:
            ma_lines.append(f"{label.upper()}={summary[label]}")
    if ma_lines:
        print(f"  均线: {'  '.join(ma_lines)}")

    # K线表（最近20条）
    display_lines = klines[-20:]
    print(f"\n  ── 近{len(display_lines)}日K线 ──")
    print(f"  {'日期':>12s}  {'开盘':>7s}  {'收盘':>7s}  {'最高':>7s}  {'最低':>7s}  {'涨跌幅':>7s}  {'成交量':>10s}  {'成交额':>10s}")
    print(f"  {'─'*78}")
    for k in reversed(display_lines):
        c = "\033[91m" if k["chg_pct"] > 0 else ("\033[92m" if k["chg_pct"] < 0 else "")
        print(f"  {k['date']:>12s}  {k['open']:>7.2f}  {c}{k['close']:>7.2f}{reset}  {k['high']:>7.2f}  {k['low']:>7.2f}  {k['chg_pct']:>+6.2f}%  {k['volume']:>8.0f}手  {k['amount']/1e8:>8.2f}亿")
    print(f"{'='*60}\n")


# ─────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="历史股票K线查询")
    parser.add_argument("code", help="股票代码, 如 302132 / 600519 / 00700 / AAPL")
    parser.add_argument("--start", default=None, help="开始日期 YYYYMMDD (默认半年前)")
    parser.add_argument("--end", default=None, help="结束日期 YYYYMMDD (默认今天)")
    parser.add_argument("--period", choices=["daily", "weekly", "monthly"], default="daily",
                        help="K线周期: daily(默认)/weekly/monthly")
    parser.add_argument("--market", choices=["sh", "sz", "hk", "us"], default=None,
                        help="市场 (可自动识别)")
    parser.add_argument("--limit", type=int, default=300, help="最大返回条数 (默认300)")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    args = parser.parse_args()

    result = fetch_history(
        code=args.code,
        start_date=args.start,
        end_date=args.end,
        period=args.period,
        market=args.market,
        limit=args.limit,
    )

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_history(result)


if __name__ == "__main__":
    main()
