---
name: stock-realtime-data
description: "This skill should be used whenever the user asks for real-time or historical stock price, quote, market data, K-line chart, price history, or trading information for A-shares (Shanghai/Shenzhen), Hong Kong stocks, or US stocks. Triggers include: 现价, 股价, 实时行情, 最新价格, 涨跌幅, 成交量, 当前报价, 历史行情, K线, 历史数据, 过往走势, stock price, real-time quote, historical data, price history, K-line, or any request to fetch live or past market data for a stock code or ticker symbol."
---

# Stock Real-Time & Historical Data Skill

## Purpose

Fetch real-time (or near-real-time) and historical stock market data for any stock symbol across:
- **A股** (沪市 Shanghai / 深市 Shenzhen)
- **港股** (Hong Kong)
- **美股** (US Markets)

Data is sourced from 东方财富 (Eastmoney) and 新浪财经 (Sina Finance) public APIs — no API key required.

---

## When to Use

Load this skill when the user asks about:
- Current stock price / 现价 / 最新价
- Intraday high/low, open, close / 最高最低开盘收盘
- Price change amount and percentage / 涨跌额涨跌幅
- Volume and turnover / 成交量成交额
- Limit-up / limit-down price / 涨停跌停价
- Historical K-line data / 历史行情 / K线 / 走势图
- Price history for a date range / 某段时间的走势
- Moving averages (MA5/MA10/MA20/MA60)
- Weekly or monthly candlestick data

---

## Workflow

### Step 1 — Identify the stock

Determine the stock code and market from the user's input.
Use the auto-detection logic in the script, or ask if ambiguous:

| Code pattern | Market |
|---|---|
| 6-digit starting with `6` | 沪市 (sh) |
| 6-digit starting with `00` or `30` | 深市 (sz) |
| 5-digit number | 港股 (hk) |
| Uppercase letters only | 美股 (us) |

For well-known names (e.g., "中航成飞", "贵州茅台", "腾讯"), resolve to code before running.

### Step 2a — Real-time quote

Execute the fetch script for live data:

```bash
python scripts/fetch_stock.py <CODE> [--market sh|sz|hk|us] [--json]
```

Examples:
```bash
python scripts/fetch_stock.py 302132              # 中航成飞
python scripts/fetch_stock.py 600519              # 贵州茅台
python scripts/fetch_stock.py 00700 --market hk   # 腾讯控股
python scripts/fetch_stock.py AAPL --market us    # 苹果
python scripts/fetch_stock.py 302132 --json       # JSON output
```

### Step 2b — Historical K-line

Execute the history script for past data:

```bash
python scripts/fetch_history.py <CODE> [--start YYYYMMDD] [--end YYYYMMDD] [--period daily|weekly|monthly] [--market sh|sz|hk|us] [--json]
```

Examples:
```bash
# Default: last 6 months daily
python scripts/fetch_history.py 302132

# Custom date range
python scripts/fetch_history.py 302132 --start 20260101 --end 20260325

# Weekly K-line
python scripts/fetch_history.py 600519 --period weekly --start 20250901

# Hong Kong stock
python scripts/fetch_history.py 00700 --market hk --start 20260101

# US stock
python scripts/fetch_history.py AAPL --market us --start 20260101

# JSON output (for programmatic use)
python scripts/fetch_history.py 302132 --start 20260101 --json
```

The scripts are located at: `~/.workbuddy/skills/stock-realtime-data/scripts/`

### Step 3 — Present the data

For **real-time quotes**, present:
- Stock name + code + market
- Current price with color hint: **涨=红色 跌=绿色** (A股惯例)
- Change amount and percentage
- Today's open / high / low
- Yesterday's close
- Volume and turnover (if available)
- Limit-up/down prices (A股)

For **historical data**, present:
- Summary statistics (highest/lowest, average volume, up/down day count, MA lines)
- Recent K-line table with OHLCV data
- Notable patterns or trends observed

Always append: `⚠️ 数据仅供参考，不构成投资建议。`

### Step 4 — Handle errors gracefully

If a script fails (network error, unsupported code, market closed):
1. Try the alternative data source (Eastmoney ↔ Sina fallback is built in)
2. Inform the user of the data source and any known latency (港股/美股 may have 15-min delay)
3. Suggest checking 券商 app for definitive real-time data

---

## Reference

See `references/api_reference.md` for:
- Full API endpoint documentation (real-time + historical)
- Field mappings for Eastmoney and Sina APIs
- Symbol format per market
- Troubleshooting tips
