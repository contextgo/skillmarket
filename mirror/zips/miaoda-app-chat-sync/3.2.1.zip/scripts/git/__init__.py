# Git operations module
