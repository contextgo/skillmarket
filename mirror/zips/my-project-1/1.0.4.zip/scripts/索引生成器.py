#!/usr/bin/env python3
"""
LSBX专业知识库构建框架 ES VI.0.1 — 索引生成器
功能：扫描知识库/记忆库/日志三库，生成目录索引和统计面板
"""

import sys
import io
import json
from pathlib import Path
from datetime import datetime

# 强制 UTF-8 输出（解决 Windows 控制台 GBK 编码问题）
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding="utf-8", errors="replace")

VERSION = "ES VI.0.1"

DEFAULT_ROOT = Path(r"G:\移动固态硬盘pssd\1675可持续进化的知识库体系（自用）")


def show_help():
    print(f"""LSBX索引生成器 {VERSION}

用法：
  python 索引生成器.py                    # 扫描默认路径三库
  python 索引生成器.py <根目录>            # 扫描指定路径
  python 索引生成器.py --knowledge         # 仅扫描知识库
  python 索引生成器.py --memory           # 仅扫描记忆库
  python 索引生成器.py --log               # 仅扫描日志
  python 索引生成器.py --list              # 仅列出文件结构
  python 索引生成器.py -h / --help         # 显示帮助

描述：
  扫描知识库/记忆库/日志三大系统，生成：
  - 各库INDEX.md（目录索引）
  - 各库STAT.md（统计面板）
  - 总览INDEX.md（三库总览）
  - 总览STAT.md（三库汇总统计）
""")


def scan_directory(root: Path, max_depth: int = 3, current_depth: int = 0) -> dict:
    """递归扫描目录，返回结构树和文件统计"""
    stats = {
        "total_files": 0,
        "total_folders": 0,
        "total_size": 0,
        "by_type": {},
        "by_module": {},
        "recent_files": [],
        "folders": []
    }

    if not root.exists():
        return stats

    try:
        items = sorted(root.iterdir(), key=lambda x: (not x.is_dir(), x.name))
    except PermissionError:
        return stats

    for item in items:
        if item.name.startswith(".") or item.name.startswith("_"):
            continue

        if item.is_dir():
            if current_depth < max_depth:
                sub_stats = scan_directory(item, max_depth, current_depth + 1)
                for k, v in sub_stats.items():
                    if k == "folders":
                        stats["folders"].append({
                            "name": item.name,
                            "path": str(item.relative_to(root)),
                            "type": "folder",
                            "children": sub_stats["folders"],
                            "files": sub_stats.get("files", []),
                            "file_count": sub_stats["total_files"]
                        })
                    else:
                        if isinstance(v, int):
                            stats[k] += v
                        elif isinstance(v, dict):
                            for tk, tv in v.items():
                                stats[k].setdefault(tk, 0)
                                stats[k][tk] += tv
                        elif isinstance(v, list):
                            stats[k].extend(v)
            else:
                # 达到最大深度，只计数
                file_count = sum(1 for _ in item.rglob("*") if _.is_file() and not _.name.startswith("."))
                stats["folders"].append({
                    "name": item.name,
                    "path": str(item.relative_to(root)),
                    "type": "folder",
                    "file_count": file_count
                })
                stats["total_folders"] += 1

        elif item.is_file() and item.suffix == ".md":
            size = item.stat().st_size
            mtime = datetime.fromtimestamp(item.stat().st_mtime)

            stats["total_files"] += 1
            stats["total_size"] += size

            ext = item.suffix
            stats["by_type"][ext] = stats["by_type"].get(ext, 0) + 1

            # 记录最近修改的文件（最近10个）
            stats["recent_files"].append({
                "name": item.name,
                "path": str(item.relative_to(root)),
                "size": size,
                "modified": mtime.strftime("%Y-%m-%d %H:%M")
            })
            stats["recent_files"].sort(key=lambda x: x["modified"], reverse=True)
            stats["recent_files"] = stats["recent_files"][:10]

    return stats


def generate_index_md(stats: dict, module_name: str, module_path: Path) -> str:
    """生成INDEX.md内容"""
    lines = [
        f"# {module_name} — 目录索引",
        "",
        f"> 自动生成 | {datetime.now().strftime('%Y-%m-%d %H:%M')} | 版本：{VERSION}",
        "",
        "---",
        "",
        "## 📊 统计概览",
        "",
        f"- **文档总数**：{stats['total_files']} 篇",
        f"- **目录总数**：{stats['total_folders']} 个",
        f"- **占用空间**：{stats['total_size'] / 1024:.1f} KB",
        "",
        "## 📁 目录结构",
        ""
    ]

    def print_tree(folders: list, indent: int = 0):
        prefix = "  " * indent
        for folder in folders:
            lines.append(f"{prefix}📁 {folder['name']}/")
            children = folder.get("children", [])
            files = folder.get("files", [])
            for f in files[:3]:
                lines.append(f"{prefix}  📄 {f['name']}")
            if len(files) > 3:
                lines.append(f"{prefix}  ... 还有 {len(files) - 3} 个文件")
            print_tree(children, indent + 1)

    print_tree(stats.get("folders", []))

    lines.extend([
        "",
        "## 📝 最近更新",
        ""
    ])

    for f in stats.get("recent_files", [])[:10]:
        lines.append(f"- `{f['modified']}` — {f['name']}")

    lines.extend([
        "",
        "---",
        f"*索引生成：{datetime.now().strftime('%Y-%m-%d %H:%M')}*"
    ])

    return "\n".join(lines)


def generate_stat_md(stats: dict, module_name: str) -> str:
    """生成STAT.md内容"""
    lines = [
        f"# {module_name} — 统计面板",
        "",
        f"> 自动生成 | {datetime.now().strftime('%Y-%m-%d %H:%M')} | 版本：{VERSION}",
        "",
        "---",
        "",
        "## 📈 核心指标",
        "",
        "| 指标 | 数值 |",
        "|------|------|",
        f"| 文档总数 | {stats['total_files']} |",
        f"| 目录总数 | {stats['total_folders']} |",
        f"| 占用空间 | {stats['total_size'] / 1024:.1f} KB |",
        "",
        "## 📊 文件类型分布",
        ""
    ]

    if stats.get("by_type"):
        lines.append("| 类型 | 数量 |")
        lines.append("|------|------|")
        for ext, count in sorted(stats["by_type"].items(), key=lambda x: x[1], reverse=True):
            lines.append(f"| {ext} | {count} |")

    lines.extend([
        "",
        "## 🕐 最近更新",
        ""
    ])

    for f in stats.get("recent_files", [])[:10]:
        lines.append(f"- `{f['modified']}` — {f['name']}（{f['size'] / 1024:.1f} KB）")

    lines.extend([
        "",
        "---",
        f"*统计生成：{datetime.now().strftime('%Y-%m-%d %H:%M')}*"
    ])

    return "\n".join(lines)


def scan_module(root: Path, module_name: str, module_key: str) -> dict:
    """扫描单个模块"""
    module_path = root / module_name
    meta_path = module_path / "0-元数据"

    if not module_path.exists():
        print(f"⚠️  {module_name} 目录不存在，跳过")
        return {}

    # 创建元数据目录
    meta_path.mkdir(parents=True, exist_ok=True)

    # 扫描
    stats = scan_directory(module_path)

    # 生成INDEX.md
    index_content = generate_index_md(stats, module_name, module_path)
    index_file = meta_path / "INDEX.md"
    index_file.write_text(index_content, encoding="utf-8")
    print(f"  ✅ 已生成：{index_file.name}")

    # 生成STAT.md
    stat_content = generate_stat_md(stats, module_name)
    stat_file = meta_path / "STAT.md"
    stat_file.write_text(stat_content, encoding="utf-8")
    print(f"  ✅ 已生成：{stat_file.name}")

    return stats


def scan_all(root: Path, modules: list) -> dict:
    """扫描所有模块并生成总览"""
    all_stats = {}
    total_files = 0
    total_size = 0
    total_folders = 0

    for module_name in modules:
        print(f"\n📦 扫描 {module_name}...")
        module_path = root / module_name
        meta_path = module_path / "0-元数据"
        meta_path.mkdir(parents=True, exist_ok=True)

        stats = scan_directory(module_path)
        all_stats[module_name] = stats
        total_files += stats["total_files"]
        total_size += stats["total_size"]
        total_folders += stats["total_folders"]

        # 生成模块INDEX和STAT
        index_content = generate_index_md(stats, module_name, module_path)
        (meta_path / "INDEX.md").write_text(index_content, encoding="utf-8")

        stat_content = generate_stat_md(stats, module_name)
        (meta_path / "STAT.md").write_text(stat_content, encoding="utf-8")

        print(f"  ✅ {module_name}：{stats['total_files']} 篇文档")

    # 生成总览INDEX.md
    overview_index = [
        "# 知识库体系 — 总览索引",
        "",
        f"> 自动生成 | {datetime.now().strftime('%Y-%m-%d %H:%M')} | 版本：{VERSION}",
        "",
        "---",
        "",
        "## 📊 总体统计",
        "",
        f"- **文档总数**：{total_files} 篇",
        f"- **目录总数**：{total_folders} 个",
        f"- **占用空间**：{total_size / 1024:.1f} KB",
        "",
        "## 📚 各库概览",
        ""
    ]

    for module_name, stats in all_stats.items():
        icon = "📚" if module_name == "知识库" else "🧠" if module_name == "记忆库" else "📋"
        overview_index.append(f"- {icon} {module_name}：{stats['total_files']} 篇文档")

    overview_index.extend(["", "## 📁 目录结构", ""])

    for module_name, stats in all_stats.items():
        overview_index.append(f"### {module_name}")
        for folder in stats.get("folders", [])[:5]:
            overview_index.append(f"- 📁 {folder['name']}/")
        if len(stats.get("folders", [])) > 5:
            overview_index.append(f"- ... 还有 {len(stats['folders']) - 5} 个目录")
        overview_index.append("")

    overview_index.extend(["---", f"*总览索引：{datetime.now().strftime('%Y-%m-%d %H:%M')}*"])

    overview_path = root / "总览INDEX.md"
    overview_path.write_text("\n".join(overview_index), encoding="utf-8")
    print(f"\n  ✅ 已生成总览：总览INDEX.md")

    return all_stats


def list_structure(root: Path, depth: int = 2):
    """列出目录结构（不生成文件）"""
    modules = ["知识库", "记忆库", "日志"]
    for module in modules:
        module_path = root / module
        if not module_path.exists():
            print(f"⚠️  {module} 不存在")
            continue

        print(f"\n{'='*40}")
        print(f"{'📚' if module=='知识库' else '🧠' if module=='记忆库' else '📋'} {module}")
        print(f"{'='*40}")

        def walk(path: Path, indent: int = 0):
            prefix = "  " * indent
            try:
                items = sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name))
            except PermissionError:
                return

            count = 0
            for item in items:
                if item.name.startswith(".") or item.name.startswith("_"):
                    continue
                if item.is_dir() and count < 20:
                    print(f"{prefix}📁 {item.name}/")
                    if indent < depth:
                        walk(item, indent + 1)
                    count += 1
                elif item.is_file() and item.suffix == ".md" and count < 20:
                    print(f"{prefix}📄 {item.name}")
                    count += 1

        walk(module_path)


def main():
    args = sys.argv[1:]

    if not args or "-h" in args or "--help" in args:
        show_help()
        return

    # 解析参数
    modules_only = []
    do_list = False
    target_root = DEFAULT_ROOT

    for arg in args:
        if arg == "--knowledge":
            modules_only = ["知识库"]
        elif arg == "--memory":
            modules_only = ["记忆库"]
        elif arg == "--log":
            modules_only = ["日志"]
        elif arg == "--list":
            do_list = True
        elif Path(arg).exists():
            target_root = Path(arg)

    if not target_root.exists():
        print(f"❌ 路径不存在：{target_root}")
        print("请先创建目录或指定正确路径。")
        return

    print(f"📍 目标路径：{target_root}")
    print(f"🔧 版本：{VERSION}")

    if do_list:
        list_structure(target_root)
        return

    modules = modules_only if modules_only else ["知识库", "记忆库", "日志"]
    scan_all(target_root, modules)

    print(f"\n✅ 索引生成完成！")


if __name__ == "__main__":
    main()
