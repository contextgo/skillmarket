---
name: video2txt
description: 将本地视频或音频文件转写为 SRT 字幕和 TXT 文本，底层使用 faster-whisper。
metadata: { "openclaw": { "emoji": "video", "requires": { "bins": ["python"] } } }
---

# video2txt 使用说明

## 脚本位置

- [`scripts/video_to_text.py`](C:\Users\陈凯宁\.workbuddy\skills\maple-video-article-1.0.5\scripts\video_to_text.py)

## 功能

- 提取视频或音频中的语音内容
- 生成带时间戳的 `.srt`
- 生成纯文本 `.txt`
- 支持中文、英文或自动识别
- 中文输出会自动转为简体

## 标准调用方式

```bash
python scripts/video_to_text.py --input "<视频或音频文件路径>"
```

## 常用示例

```bash
python scripts/video_to_text.py --input "D:\\videos\\meeting.mp4"
python scripts/video_to_text.py --input "D:\\videos\\meeting.mp4" --output-dir "D:\\captions"
python scripts/video_to_text.py --input "D:\\videos\\meeting.mp4" --output-path "D:\\captions\\meeting_result"
python scripts/video_to_text.py --input "D:\\videos\\meeting.mp4" --language zh --model-size small
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--input` | 输入文件路径，必填 | - |
| `--output-dir` | 输出目录 | 输入文件所在目录 |
| `--output-path` | 输出基础路径 | - |
| `--model-dir` | 模型下载目录 | `scripts/models` |
| `--model-size` | Whisper 模型名或本地模型路径 | `base` |
| `--language` | `auto` / `zh` / `en` | `zh` |
| `--device` | `cpu` / `cuda` | `cpu` |
| `--compute-type` | 推理计算类型 | `int8` |
| `--beam-size` | 解码 beam size | `2` |
| `--no-vad-filter` | 关闭 VAD 过滤 | 关闭时才生效 |

## 输出文件

- `<输入文件名>.srt`
- `<输入文件名>.txt`

## 依赖

- Python 3.11 或 3.12
- `faster-whisper>=1.1.0`
- `av>=12.0.0`
- `opencc-python-reimplemented>=0.1.7`
- `ffmpeg` / `ffprobe`

安装依赖示例：

```bash
python -m pip install -r references\video-to-txt使用说明\requirements.txt
```

## 首次运行说明

首次运行时，脚本会自动下载 Whisper 模型到 `scripts/models`。因此：

- 需要能联网访问模型源
- 需要有磁盘空间保存模型缓存
- 如果网络被限制，脚本会失败，但这不代表代码损坏

## 已验证行为

- 在 Windows + Python 3.12 环境下可正常运行
- 已使用下载得到的 Bilibili 视频成功生成 `.srt` 和 `.txt`

## 常见失败原因

### 1. 模型下载失败

典型报错特征：

- `ConnectError`
- `WinError 10013`
- 提示无法从 Hub 定位文件

这通常是网络权限问题，不是脚本语法问题。

### 2. 输入文件不存在

脚本会直接报：

```text
ERROR: Input file does not exist: ...
```

### 3. 输出目录与输出路径同时指定

脚本要求二选一，否则会失败。

### 4. Windows symlink 警告

`huggingface_hub` 可能提示 Windows 没开启开发者模式。该警告不会阻止转写，只会让缓存更占空间。

## 对其他模型的调用建议

- 在 Windows 上统一使用 `python`
- 如果用户第一次运行失败，优先检查模型是否下载成功
- 如果报 `WinError 10013`，优先判断为网络或权限限制
- 除非用户明确要求，否则不要把失败归因到 `video_to_text.py` 代码损坏
- 转写长视频时允许较长超时，避免过早中断
