---
name: video-downloader
description: 通用视频下载工具，适用于 Bilibili、YouTube 等 yt-dlp 支持的平台。负责下载、自动合并音视频流并清理文件名。
metadata:
  {
    "openclaw":
      {
        "emoji": "🎞️",
        "requires": { "bins": ["python"] },
      },
  }
---

# Video Downloader 使用说明

## 脚本位置

- [`scripts/video_downloader.py`](C:\Users\陈凯宁\.workbuddy\skills\maple-video-article-1.0.5\scripts\video_downloader.py)

## 功能

- 下载任意 `yt-dlp` 支持的网站视频
- 自动选择目标分辨率
- 在音视频分离时自动合并
- 自动清理下载后的文件名

## 标准调用方式

在 Windows 环境里统一使用：

```bash
python scripts/video_downloader.py "<视频URL>" "720p" "<输出目录>"
```

不要写成 `python3`。当前脚本会复用当前 Python 解释器去调用 `yt-dlp`。

## 参数

- 第一个参数：视频 URL，必填
- 第二个参数：分辨率，可选，如 `1080p`、`720p`、`480p`
- 第三个参数：输出目录，可选

## 示例

```bash
python scripts/video_downloader.py "https://www.bilibili.com/video/BV15eQeBSEjk/" "720p" ".\\downloads"
python scripts/video_downloader.py "https://youtu.be/xxxx" "1080p" "D:\\video-downloads"
```

## 输出

脚本成功后会打印最终文件路径，并返回下载好的本地视频文件。

## 依赖

- Python
- `yt-dlp` Python 包
- `ffmpeg`
- 推荐安装 `imageio-ffmpeg`，脚本会优先使用其自带 ffmpeg

## 已验证行为

- 在 Windows + Python 3.12 环境下可正常运行
- 对 Bilibili 视频可成功获取格式、下载并自动合并音视频

## 常见失败原因

### 1. `[WinError 2] 系统找不到指定的文件`

这通常是旧逻辑把 `yt-dlp` 调成了 `python3 -m yt_dlp`，而环境里没有 `python3`。当前脚本已修复。

### 2. `[WinError 10013] 以一种访问权限不允许的方式做了一个访问套接字的尝试`

这通常不是脚本语法错误，而是网络访问被限制。常见原因：

- 沙箱没有网络权限
- 系统防火墙拦截
- 安全软件或代理策略阻断

### 3. 站点格式列表获取失败

优先检查：

- 当前网络是否能访问目标站点
- `yt-dlp` 是否安装正常
- 目标站点是否需要登录、Cookie 或额外参数

## 给其他模型的建议

- 看到下载失败时，先区分是“解释器问题”还是“网络问题”
- 在 Windows 上不要再建议用户用 `python3`
- 如果用户给的是 URL，优先直接用本脚本，不要自己拼 `yt-dlp` 长命令
