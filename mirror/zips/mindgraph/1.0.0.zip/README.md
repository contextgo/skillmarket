# mindgraph
