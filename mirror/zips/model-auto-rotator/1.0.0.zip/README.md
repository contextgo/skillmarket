# Model Auto Rotator 使用指南

## 🎯 功能概述

`model-auto-rotator` 是一个智能模型轮询技能，能够：
- ✅ **自动发现** - 动态检测系统可用模型
- ✅ **智能轮询** - Round Robin 和 Weighted 两种模式
- ✅ **故障转移** - 自动跳过不可用模型
- ✅ **成本优化** - 优先使用免费模型
- ✅ **状态监控** - 实时显示模型使用情况
- ✅ **自适应配置** - 根据检测结果调整策略

## 📁 技能结构

```
skills/model-auto-rotator/
├── SKILL.md                    # 技能定义文档
├── README.md                   # 使用说明
├── scripts/
│   ├── model-auto-rotator.js   # 核心轮询逻辑
│   ├── integration.js          # OpenClaw集成模块
│   ├── auto-test.js           # 完整测试脚本
│   ├── simple-test.js         # 简化测试脚本
│   ├── quick-test.js          # 快速功能测试
│   └── usage-example.js       # 使用示例
└── examples/
    ├── basic-usage.js          # 基本使用示例
    ├── advanced-config.js      # 高级配置示例
    └── session-integration.js  # 会话集成示例
```

## 🚀 快速开始

### 1. 基本测试

```bash
# 运行快速功能测试
cd skills/model-auto-rotator/scripts
node quick-test.js

# 运行完整测试
node auto-test.js

# 运行简化测试
node simple-test.js
```

### 2. 基本使用

```javascript
const autoRotator = require('./scripts/model-auto-rotator.js');

// 获取下一个可用模型
const model = autoRotator.next();
console.log('下一个模型:', model);

// 获取当前状态
const status = autoRotator.getStatus();
console.log('轮询状态:', status);

// 标记模型为不可用
autoRotator.markUnhealthy('openrouter/deepseek/deepseek:free');

// 重置轮询状态
autoRotator.reset();
```

### 3. 环境变量配置

```bash
# 设置轮询模式 (round-robin 或 weighted)
export MODEL_ROTATION_MODE=round-robin

# 是否优先使用免费模型
export PREFER_FREE=true

# 最大失败次数
export MAX_FAILURES=3

# 超时时间(毫秒)
export MODEL_TIMEOUT=30000

# 模型权重配置
export MODEL_WEIGHTS='{"nemotron":0.4,"glm-4.7":0.3,"deepseek":0.3}'
```

## 📊 功能详解

### 自动发现机制

技能通过以下方式自动发现可用模型：

1. **预定义模型映射** - 检查11个预定义的模型别名
2. **环境变量检测** - 从系统环境变量中查找配置的模型
3. **连通性测试** - 验证模型格式和可用性
4. **健康状态监控** - 跟踪模型使用成功/失败情况

### 轮询模式

#### Round Robin 模式
```javascript
autoRotator.config.rotationMode = 'round-robin';
// 严格按顺序循环使用所有可用模型
// 均衡分配请求到每个模型
```

#### Weighted 模式
```javascript
autoRotator.config.rotationMode = 'weighted';
// 根据预设权重随机选择模型
// 可以自定义不同模型的使用概率
```

### 故障转移机制

```javascript
// 自动标记失败的模型
autoRotator.markUnhealthy('problematic-model');

// 重新发现可用模型
await autoRotator.discoverModels();

// 查看不健康模型列表
console.log(autoRotator.getStatus().unhealthyModels);
```

### 模型推荐系统

```javascript
// 根据任务类型获取推荐模型
const generalModel = autoRotator.getRecommendedModel('general');
const codingModel = autoRotator.getRecommendedModel('coding');
const creativeModel = autoRotator.getRecommendedModel('creative');
const analysisModel = autoRotator.getRecommendedModel('analysis');
const fastModel = autoRotator.getRecommendedModel('fast');
```

## 🔧 OpenClaw 集成

### 1. 基本集成

```javascript
const { createRotatedSession } = require('./scripts/integration.js');

// 创建使用轮询的会话
const session = await createRotatedSession('这是一个测试任务', {
  timeoutSeconds: 300,
  streamTo: 'parent'
});
```

### 2. 批量会话创建

```javascript
const tasks = [
  '写一段代码',
  '分析文本内容',
  '生成创意内容',
  '总结文档'
];

const sessions = await createRotatedSessions(tasks, {
  timeoutSeconds: 120,
  thread: true
});
```

### 3. 获取推荐模型会话

```javascript
const recommendedModel = getRecommendedModel('coding');
const session = await sessions_spawn({
  task: '编写Python代码',
  model: recommendedModel,
  timeoutSeconds: 300
});
```

## 🎛️ 配置选项

### 核心配置

```javascript
autoRotator.config = {
  rotationMode: 'round-robin',        // 轮询模式
  preferFree: true,                    // 优先使用免费模型
  maxFailures: 3,                      // 最大失败次数
  timeout: 30000,                      // 超时时间(毫秒)
  enableAutoDiscovery: true,          // 启用自动发现
  autoDiscoveryInterval: 300000,       // 自动发现间隔(毫秒)
  enableLogging: true,                 // 启用日志
  modelWeights: {                     // 权重配置
    'nemotron': 0.2,
    'glm-4.7-flash': 0.15,
    'deepseek': 0.15,
    // ... 其他权重
  }
};
```

### 环境变量配置

| 变量名 | 类型 | 默认值 | 描述 |
|--------|------|--------|------|
| `MODEL_ROTATION_MODE` | string | 'round-robin' | 轮询模式 |
| `PREFER_FREE` | boolean | true | 优先免费模型 |
| `MAX_FAILURES` | number | 3 | 最大失败次数 |
| `MODEL_TIMEOUT` | number | 30000 | 超时时间(毫秒) |
| `MODEL_WEIGHTS` | JSON | - | 模型权重配置 |

## 📈 监控和统计

### 实时状态监控

```javascript
const status = autoRotator.getStatus();
console.log('当前状态:', JSON.stringify(status, null, 2));
```

状态信息包括：
- `rotationMode` - 当前轮询模式
- `rotationCount` - 总轮询次数
- `currentIndex` - 当前索引位置
- `unhealthyModels` - 不健康模型列表
- `availableModels` - 可用模型列表
- `nextModel` - 下一个将要使用的模型

### 性能统计

```javascript
const stats = autoRotator.getRotationStats();
console.log('性能统计:', stats);
```

## 🔍 故障排除

### 常见问题

1. **所有模型都不可用**
   ```javascript
   // 重新发现模型
   await autoRotator.discoverModels();
   
   // 查看发现历史
   console.log(autoRotator.config.discoveryHistory);
   ```

2. **轮询卡死在某一个模型**
   ```javascript
   // 重置轮询状态
   autoRotator.reset();
   
   // 检查模型状态
   console.log(autoRotator.getStatus());
   ```

3. **环境变量不生效**
   ```javascript
   // 重新加载环境变量
   autoRotator.loadFromEnv();
   
   // 验证配置
   console.log(autoRotator.config);
   ```

### 调试模式

```javascript
// 启用详细日志
autoRotator.config.enableLogging = true;

// 手动触发重新发现
await autoRotator.forceModelDiscovery();
```

## 📋 测试验证

### 运行测试套件

```bash
# 快速功能测试
node quick-test.js

# 简化测试
node simple-test.js

# 完整测试
node auto-test.js
```

### 预期测试结果

1. **轮询模式测试** - 应该看到模型按顺序轮换
2. **加权模式测试** - 应该看到按权重分布的结果
3. **故障转移测试** - 应该看到被标记的模型被跳过
4. **状态显示** - 应该显示正确的状态信息

## 🎯 最佳实践

1. **定期重新发现** - 设置合理的自动发现间隔
2. **监控不健康模型** - 及时处理失败的模型
3. **合理设置权重** - 根据使用习惯调整模型权重
4. **配置环境变量** - 使用环境变量进行批量配置
5. **日志记录** - 启用日志以便问题排查

## 🔗 相关资源

- [SKILL.md](SKILL.md) - 完整技能定义
- [integration.js](scripts/integration.js) - OpenClaw集成代码
- [auto-test.js](scripts/auto-test.js) - 完整测试脚本
- [quick-test.js](scripts/quick-test.js) - 快速测试脚本

---

🚀 **技能已就绪！现在可以自动轮询模型，实现负载均衡和成本优化。**