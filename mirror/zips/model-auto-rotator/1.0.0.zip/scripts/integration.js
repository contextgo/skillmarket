// OpenClaw 自动模型轮询集成
// 提供与 OpenClaw 会话系统的无缝集成

const autoRotator = require('./model-auto-rotator.js');

class OpenClawModelIntegration {
  constructor() {
    this.activeSessions = new Map();
    this.sessionTimeouts = new Map();
  }

  // 创建使用自动轮询的会话
  async createRotatedSession(task, options = {}) {
    const model = autoRotator.next();
    
    // 构建会话选项
    const sessionOptions = {
      task: task,
      model: model,
      timeoutSeconds: options.timeoutSeconds || 300,
      streamTo: options.streamTo || 'parent',
      mode: options.mode || 'run'
    };

    // 如果需要持久会话，添加线程绑定
    if (options.thread) {
      sessionOptions.thread = true;
      sessionOptions.mode = 'session';
    }

    try {
      // 创建会话
      const session = await sessions_spawn(sessionOptions);
      
      // 记录会话信息
      this.registerSession(session, model, task);
      
      // 设置会话监控
      this.monitorSession(session, model, task);
      
      this.log(`创建轮询会话: 模型=${model}, 任务="${task.substring(0, 50)}..."`);
      
      return session;
    } catch (error) {
      this.log(`创建轮询会话失败: ${error.message}`);
      autoRotator.markUnhealthy(model);
      throw error;
    }
  }

  // 批量创建多个轮询会话
  async createRotatedSessions(tasks, options = {}) {
    const sessions = [];
    
    for (const task of tasks) {
      try {
        const session = await this.createRotatedSession(task, options);
        sessions.push(session);
      } catch (error) {
        this.log(`创建会话失败: ${error.message}`);
        // 继续尝试下一个任务
      }
    }
    
    return sessions;
  }

  // 监控会话状态
  monitorSession(session, model, task) {
    // 监听会话完成
    session.on('completed', () => {
      this.handleSessionComplete(session, model, task);
    });

    // 监听会话失败
    session.on('failed', (error) => {
      this.handleSessionFailed(session, model, task, error);
    });

    // 监听会话超时
    const timeoutId = setTimeout(() => {
      if (this.activeSessions.has(session.sessionKey)) {
        this.handleSessionTimeout(session, model, task);
      }
    }, options.timeoutSeconds * 1000);

    this.sessionTimeouts.set(session.sessionKey, timeoutId);
  }

  // 处理会话完成
  handleSessionComplete(session, model, task) {
    this.log(`会话完成: 模型=${model}, 会话Key=${session.sessionKey}`);
    
    // 清理会话记录
    this.cleanupSession(session.sessionKey);
    
    // 记录成功统计
    this.recordSuccess(model);
  }

  // 处理会话失败
  handleSessionFailed(session, model, task, error) {
    this.log(`会话失败: 模型=${model}, 错误=${error.message}`);
    
    // 标记模型为不可用
    autoRotator.markUnhealthy(model);
    
    // 清理会话记录
    this.cleanupSession(session.sessionKey);
    
    // 记录失败统计
    this.recordFailure(model);
  }

  // 处理会话超时
  handleSessionTimeout(session, model, task) {
    this.log(`会话超时: 模型=${model}`);
    
    // 标记模型为不可用
    autoRotator.markUnhealthy(model);
    
    // 清理会话记录
    this.cleanupSession(session.sessionKey);
    
    // 记录超时统计
    this.recordTimeout(model);
  }

  // 注册会话
  registerSession(session, model, task) {
    this.activeSessions.set(session.sessionKey, {
      session,
      model,
      task,
      startTime: Date.now()
    });
  }

  // 清理会话记录
  cleanupSession(sessionKey) {
    this.activeSessions.delete(sessionKey);
    
    if (this.sessionTimeouts.has(sessionKey)) {
      clearTimeout(this.sessionTimeouts.get(sessionKey));
      this.sessionTimeouts.delete(sessionKey);
    }
  }

  // 获取当前活跃会话状态
  getActiveSessionsStatus() {
    const sessions = Array.from(this.activeSessions.values());
    
    return {
      totalActive: sessions.length,
      sessionsByModel: this.groupSessionsByModel(sessions),
      averageSessionTime: this.calculateAverageSessionTime(sessions),
      oldestSession: this.getOldestSession(sessions)
    };
  }

  // 获取轮询统计信息
  getRotationStats() {
    const status = autoRotator.getStatus();
    
    return {
      ...status,
      activeSessions: this.getActiveSessionsStatus(),
      performanceStats: this.getPerformanceStats()
    };
  }

  // 按模型分组会话
  groupSessionsByModel(sessions) {
    const groups = {};
    
    for (const session of sessions) {
      if (!groups[session.model]) {
        groups[session.model] = [];
      }
      groups[session.model].push(session);
    }
    
    return groups;
  }

  // 计算平均会话时间
  calculateAverageSessionTime(sessions) {
    if (sessions.length === 0) return 0;
    
    const totalTime = sessions.reduce((sum, session) => {
      return sum + (Date.now() - session.startTime);
    }, 0);
    
    return Math.round(totalTime / sessions.length / 1000); // 返回秒数
  }

  // 获取最旧的会话
  getOldestSession(sessions) {
    if (sessions.length === 0) return null;
    
    return sessions.reduce((oldest, session) => {
      return session.startTime < oldest.startTime ? session : oldest;
    });
  }

  // 获取性能统计
  getPerformanceStats() {
    const stats = {
      totalSessions: 0,
      successfulSessions: 0,
      failedSessions: 0,
      timeoutSessions: 0,
      averageResponseTime: 0,
      modelPerformance: {}
    };
    
    // 这里可以添加更复杂的性能统计逻辑
    // 例如从日志中分析历史数据
    
    return stats;
  }

  // 记录成功
  recordSuccess(model) {
    this.log(`模型 ${model} 会话成功`);
    // 可以在这里添加更详细的统计逻辑
  }

  // 记录失败
  recordFailure(model) {
    this.log(`模型 ${model} 会话失败`);
    // 可以在这里添加更详细的统计逻辑
  }

  // 记录超时
  recordTimeout(model) {
    this.log(`模型 ${model} 会话超时`);
    // 可以在这里添加更详细的统计逻辑
  }

  // 日志记录
  log(message) {
    console.log(`[OpenClawModelIntegration] ${new Date().toISOString()} - ${message}`);
  }

  // 获取下一个模型用于手动会话创建
  getNextModel() {
    return autoRotator.next();
  }

  // 强制重新发现模型
  async forceModelDiscovery() {
    this.log('强制重新发现模型...');
    const models = await autoRotator.discoverModels();
    this.log(`重新发现完成，可用模型: ${models.join(', ')}`);
    return models;
  }

  // 获取当前推荐模型
  getRecommendedModel(taskType = 'general') {
    // 根据任务类型推荐模型
    const recommendations = {
      'general': 'GLM-4.7-Flash',
      'coding': 'Qwen3-Coder',
      'creative': 'GLM-4.7',
      'analysis': 'DeepSeek',
      'fast': 'NVIDIA'
    };
    
    const recommendedModel = recommendations[taskType] || 'GLM-4.7-Flash';
    
    // 检查推荐模型是否可用
    const availableModels = autoRotator.config.availableModels;
    if (availableModels.includes(recommendedModel)) {
      return recommendedModel;
    } else {
      // 如果不可用，使用下一个可用模型
      return autoRotator.next();
    }
  }
}

// 创建集成实例
const modelIntegration = new OpenClawModelIntegration();

// 导出模块
module.exports = modelIntegration;

// 导出便利函数
module.exports = {
  createRotatedSession: modelIntegration.createRotatedSession.bind(modelIntegration),
  createRotatedSessions: modelIntegration.createRotatedSessions.bind(modelIntegration),
  getRotationStats: modelIntegration.getRotationStats.bind(modelIntegration),
  getNextModel: modelIntegration.getNextModel.bind(modelIntegration),
  getRecommendedModel: modelIntegration.getRecommendedModel.bind(modelIntegration),
  forceModelDiscovery: modelIntegration.forceModelDiscovery.bind(modelIntegration)
};

// CLI 测试
if (require.main === module) {
  console.log('=== OpenClaw 自动模型轮询集成测试 ===\n');
  
  // 测试创建轮询会话
  console.log('测试创建轮询会话:');
  modelIntegration.createRotatedSession('这是一个测试任务', { timeoutSeconds: 60 })
    .then(session => {
      console.log('会话创建成功:', session.sessionKey);
    })
    .catch(error => {
      console.error('会话创建失败:', error.message);
    });
  
  // 显示当前状态
  console.log('\n当前轮询状态:');
  console.log(JSON.stringify(modelIntegration.getRotationStats(), null, 2));
  
  // 显示下一个推荐模型
  console.log('\n推荐模型:');
  console.log('一般任务:', modelIntegration.getRecommendedModel('general'));
  console.log('编程任务:', modelIntegration.getRecommendedModel('coding'));
  console.log('创意任务:', modelIntegration.getRecommendedModel('creative'));
}