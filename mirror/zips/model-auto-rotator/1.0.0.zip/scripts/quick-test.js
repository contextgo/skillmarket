const autoRotator = require('./model-auto-rotator.js');

// 快速功能测试
function runQuickTest() {
  console.log('=== Model Auto Rotator 快速测试 ===\n');
  
  // 设置测试模型
  autoRotator.config.availableModels = [
    'openrouter/nvidia/nemotron-3-nano-30b-a3b:free',
    'zai/glm-4.7-flash',
    'openrouter/deepseek/deepseek:free',
    'openrouter/mistral/mistral:free',
    'openrouter/qwen/qwen3-coder:free',
    'openrouter/stepfun/step-3.5:free',
    'openrouter/free'
  ];
  
  // 测试轮询模式
  console.log('🔄 轮询模式测试 (5次):');
  autoRotator.config.rotationMode = 'round-robin';
  autoRotator.reset();
  
  for (let i = 0; i < 5; i++) {
    console.log(`  ${i + 1}. ${autoRotator.next()}`);
  }
  
  // 测试故障转移
  console.log('\n🚫 故障转移测试:');
  const testModel = autoRotator.config.availableModels[2];
  autoRotator.markUnhealthy(testModel);
  console.log(`标记模型 "${testModel}" 为不可用`);
  
  for (let i = 0; i < 3; i++) {
    console.log(`  ${i + 1}. ${autoRotator.next()}`);
  }
  
  // 测试模型推荐
  console.log('\n🎯 模型推荐测试:');
  console.log('一般任务:', autoRotator.getRecommendedModel('general'));
  console.log('编程任务:', autoRotator.getRecommendedModel('coding'));
  console.log('创意任务:', autoRotator.getRecommendedModel('creative'));
  
  // 显示最终状态
  console.log('\n📊 最终状态:');
  console.log(JSON.stringify(autoRotator.getStatus(), null, 2));
  
  console.log('\n✅ 快速测试完成！');
}

runQuickTest();