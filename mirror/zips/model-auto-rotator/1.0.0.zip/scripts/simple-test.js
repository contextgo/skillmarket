const autoRotator = require('./model-auto-rotator.js');

// 简化测试脚本，不依赖 session_status
async function runSimplifiedTests() {
  console.log('=== Model Auto Rotator 简化测试 ===\n');
  
  // 设置测试用的预定义模型列表
  autoRotator.config.availableModels = [
    'openrouter/nvidia/nemotron-3-nano-30b-a3b:free',
    'zai/glm-4.7-flash',
    'openrouter/deepseek/deepseek:free',
    'openrouter/mistral/mistral:free',
    'openrouter/qwen/qwen3-coder:free',
    'openrouter/stepfun/step-3.5:free',
    'openrouter/free'
  ];
  
  console.log('✅ 设置测试模型完成');
  console.log(`可用模型数量: ${autoRotator.config.availableModels.length}`);
  console.log('可用模型列表:');
  autoRotator.config.availableModels.forEach((model, index) => {
    console.log(`  ${index + 1}. ${model}`);
  });
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试1: 轮询模式
  console.log('🔄 测试1: 轮询模式 (8次请求)');
  autoRotator.config.rotationMode = 'round-robin';
  autoRotator.reset();
  
  const roundRobinResults = [];
  for (let i = 0; i < 8; i++) {
    const model = autoRotator.next();
    roundRobinResults.push(model);
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  // 统计轮询结果
  const modelStats = {};
  roundRobinResults.forEach(model => {
    modelStats[model] = (modelStats[model] || 0) + 1;
  });
  console.log('\n轮询统计:');
  Object.entries(modelStats).forEach(([model, count]) => {
    console.log(`  ${model}: ${count} 次`);
  });
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试2: 加权模式
  console.log('⚖️  测试2: 加权模式 (10次请求)');
  autoRotator.config.rotationMode = 'weighted';
  
  const weightedResults = [];
  for (let i = 0; i < 10; i++) {
    const model = autoRotator.next();
    weightedResults.push(model);
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  // 统计加权结果
  const weightedStats = {};
  weightedResults.forEach(model => {
    weightedStats[model] = (weightedStats[model] || 0) + 1;
  });
  console.log('\n加权统计:');
  Object.entries(weightedStats).forEach(([model, count]) => {
    console.log(`  ${model}: ${count} 次`);
  });
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试3: 故障转移
  console.log('🚫 测试3: 故障转移测试');
  
  // 标记一个模型为不可用
  const testModel = autoRotator.config.availableModels[2];
  console.log(`标记模型 "${testModel}" 为不可用`);
  autoRotator.markUnhealthy(testModel);
  
  console.log('重新测试轮询 (5次请求):');
  for (let i = 0; i < 5; i++) {
    const model = autoRotator.next();
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试4: 状态显示
  console.log('📊 测试4: 显示当前状态');
  const status = autoRotator.getStatus();
  console.log(JSON.stringify(status, null, 2));
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试5: 环境变量配置
  console.log('⚙️  测试5: 环境变量配置测试');
  
  // 临时设置环境变量
  process.env.MODEL_ROTATION_MODE = 'weighted';
  process.env.PREFER_FREE = 'false';
  
  // 重新初始化以应用环境变量
  autoRotator.config.rotationMode = process.env.MODEL_ROTATION_MODE;
  autoRotator.config.preferFree = process.env.PREFER_FREE === 'true';
  
  console.log('应用环境变量配置后:');
  console.log(`  轮询模式: ${autoRotator.config.rotationMode}`);
  console.log(`  优先免费模型: ${autoRotator.config.preferFree}`);
  
  console.log('\n测试加权模式 (5次请求):');
  for (let i = 0; i < 5; i++) {
    const model = autoRotator.next();
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试6: 模型推荐
  console.log('🎯 测试6: 模型推荐测试');
  const testTasks = ['general', 'coding', 'creative', 'analysis', 'fast'];
  testTasks.forEach(taskType => {
    const recommendedModel = autoRotator.getRecommendedModel(taskType);
    console.log(`任务类型 "${taskType}": 推荐 ${recommendedModel}`);
  });
  
  console.log('\n=== 所有测试完成 ===');
}

// 运行测试
runSimplifiedTests().catch(error => {
  console.error('测试运行失败:', error.message);
  process.exit(1);
});