// Model Auto Rotator 使用示例
// 演示如何在 OpenClaw 中使用自动模型轮询

const autoRotator = require('./model-auto-rotator.js');

// 示例1: 基本轮询使用
console.log('=== 示例1: 基本轮询使用 ===');
autoRotator.config.availableModels = [
  'openrouter/nvidia/nemotron-3-nano-30b-a3b:free',
  'zai/glm-4.7-flash',
  'openrouter/deepseek/deepseek:free',
  'openrouter/mistral/mistral:free',
  'openrouter/qwen/qwen3-coder:free',
  'openrouter/stepfun/step-3.5:free',
  'openrouter/free'
];

// 轮询模式测试
console.log('轮询模式 (5次):');
autoRotator.config.rotationMode = 'round-robin';
for (let i = 0; i < 5; i++) {
  console.log(`  ${i + 1}. ${autoRotator.next()}`);
}

// 示例2: 加权模式
console.log('\n=== 示例2: 加权模式 ===');
autoRotator.config.rotationMode = 'weighted';
console.log('加权模式 (5次):');
for (let i = 0; i < 5; i++) {
  console.log(`  ${i + 1}. ${autoRotator.next()}`);
}

// 示例3: 故障转移
console.log('\n=== 示例3: 故障转移 ===');
const testModel = autoRotator.config.availableModels[2];
console.log(`标记模型 "${testModel}" 为不可用`);
autoRotator.markUnhealthy(testModel);
console.log('重新轮询 (3次):');
for (let i = 0; i < 3; i++) {
  console.log(`  ${i + 1}. ${autoRotator.next()}`);
}

// 示例4: 模型推荐
console.log('\n=== 示例4: 模型推荐 ===');
const recommendations = {
  'general': autoRotator.getRecommendedModel('general'),
  'coding': autoRotator.getRecommendedModel('coding'),
  'creative': autoRotator.getRecommendedModel('creative'),
  'analysis': autoRotator.getRecommendedModel('analysis'),
  'fast': autoRotator.getRecommendedModel('fast')
};

console.log('模型推荐:');
Object.entries(recommendations).forEach(([task, model]) => {
  console.log(`  ${task}: ${model}`);
});

// 示例5: 环境变量配置
console.log('\n=== 示例5: 环境变量配置 ===');
process.env.MODEL_ROTATION_MODE = 'weighted';
process.env.PREFER_FREE = 'false';
autoRotator.config.rotationMode = process.env.MODEL_ROTATION_MODE;
autoRotator.config.preferFree = process.env.PREFER_FREE === 'true';

console.log('配置更改后 (5次):');
for (let i = 0; i < 5; i++) {
  console.log(`  ${i + 1}. ${autoRotator.next()}`);
}

// 示例6: 状态监控
console.log('\n=== 示例6: 状态监控 ===');
const status = autoRotator.getStatus();
console.log('当前状态:');
console.log(`  轮询模式: ${status.rotationMode}`);
console.log(`  可用模型: ${status.totalModels}`);
console.log(`  免费模型: ${status.freeModels}`);
console.log(`  付费模型: ${status.paidModels}`);
console.log(`  轮询次数: ${status.rotationCount}`);
console.log(`  下一个模型: ${status.nextModel}`);
console.log(`  不健康模型: ${status.unhealthyModels.length} 个`);

console.log('\n✅ 所有示例执行完成！');