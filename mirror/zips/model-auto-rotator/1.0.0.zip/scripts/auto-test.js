const autoRotator = require('./model-auto-rotator.js');

// 测试自动模型发现和轮询功能
async function runAutoRotatorTests() {
  console.log('=== Model Auto Rotator 自动测试 ===\n');
  
  // 测试1: 自动发现可用模型
  console.log('🔍 测试1: 自动发现可用模型');
  try {
    const discoveredModels = await autoRotator.discoverModels();
    console.log(`✅ 发现了 ${discoveredModels.length} 个可用模型:`);
    discoveredModels.forEach((model, index) => {
      console.log(`  ${index + 1}. ${model}`);
    });
  } catch (error) {
    console.log(`❌ 模型发现失败: ${error.message}`);
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试2: 轮询模式测试
  console.log('🔄 测试2: 轮询模式测试 (10次请求)');
  const roundRobinResults = [];
  for (let i = 0; i < 10; i++) {
    const model = autoRotator.next();
    roundRobinResults.push(model);
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  // 统计轮询结果
  const modelStats = {};
  roundRobinResults.forEach(model => {
    modelStats[model] = (modelStats[model] || 0) + 1;
  });
  console.log('\n轮询统计:');
  Object.entries(modelStats).forEach(([model, count]) => {
    console.log(`  ${model}: ${count} 次`);
  });
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试3: 加权模式测试
  console.log('⚖️  测试3: 加权模式测试 (10次请求)');
  autoRotator.config.rotationMode = 'weighted';
  const weightedResults = [];
  for (let i = 0; i < 10; i++) {
    const model = autoRotator.next();
    weightedResults.push(model);
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  // 统计加权结果
  const weightedStats = {};
  weightedResults.forEach(model => {
    weightedStats[model] = (weightedStats[model] || 0) + 1;
  });
  console.log('\n加权统计:');
  Object.entries(weightedStats).forEach(([model, count]) => {
    console.log(`  ${model}: ${count} 次`);
  });
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试4: 故障转移测试
  console.log('🚫 测试4: 故障转移测试');
  
  // 标记一个模型为不可用
  const testModel = autoRotator.config.availableModels[0];
  if (testModel) {
    console.log(`标记模型 "${testModel}" 为不可用`);
    autoRotator.markUnhealthy(testModel);
    
    console.log('重新测试轮询 (5次请求):');
    for (let i = 0; i < 5; i++) {
      const model = autoRotator.next();
      console.log(`  请求 ${i + 1}: ${model}`);
    }
  } else {
    console.log('没有可用模型进行故障转移测试');
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试5: 状态显示
  console.log('📊 测试5: 显示当前状态');
  const status = autoRotator.getStatus();
  console.log(JSON.stringify(status, null, 2));
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试6: 环境变量配置测试
  console.log('⚙️  测试6: 环境变量配置测试');
  
  // 临时设置环境变量
  process.env.MODEL_ROTATION_MODE = 'weighted';
  process.env.PREFER_FREE = 'false';
  
  // 重新初始化以应用环境变量
  autoRotator.config.rotationMode = process.env.MODEL_ROTATION_MODE;
  autoRotator.config.preferFree = process.env.PREFER_FREE === 'true';
  
  console.log('应用环境变量配置后:');
  console.log(`  轮询模式: ${autoRotator.config.rotationMode}`);
  console.log(`  优先免费模型: ${autoRotator.config.preferFree}`);
  
  console.log('\n测试加权模式 (5次请求):');
  for (let i = 0; i < 5; i++) {
    const model = autoRotator.next();
    console.log(`  请求 ${i + 1}: ${model}`);
  }
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试7: 重置功能
  console.log('🔄 测试7: 重置功能');
  autoRotator.reset();
  console.log('轮询状态已重置');
  console.log('下一个模型:', autoRotator.next());
  
  console.log('\n' + '='.repeat(50) + '\n');
  
  // 测试8: 模型推荐测试
  console.log('🎯 测试8: 模型推荐测试');
  const testTasks = ['general', 'coding', 'creative', 'analysis', 'fast'];
  testTasks.forEach(taskType => {
    const recommendedModel = autoRotator.config.availableModels.length > 0 
      ? autoRotator.config.availableModels[0]  // 简化测试
      : 'N/A';
    console.log(`任务类型 "${taskType}": 推荐 ${recommendedModel}`);
  });
  
  console.log('\n=== 所有测试完成 ===');
}

// 运行测试
runAutoRotatorTests().catch(error => {
  console.error('测试运行失败:', error.message);
  process.exit(1);
});