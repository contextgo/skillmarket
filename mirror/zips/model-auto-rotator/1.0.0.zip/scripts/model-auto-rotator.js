// Model Auto Rotator - 自动检测可用模型并轮询切换
const { spawn } = require('child_process');
const { promisify } = require('util');
const exec = promisify(require('child_process').exec);
const path = require('path');

class ModelAutoRotator {
  constructor(config = {}) {
    // 预定义的模型别名映射
    this.modelAliases = {
      'DeepSeek': 'openrouter/deepseek/deepseek:free',
      'GLM': 'zai/glm-5',
      'GLM-4.5-Air': 'zai/glm-4.5-air',
      'GLM-4.7': 'zai/glm-4.7',
      'GLM-4.7-Flash': 'zai/glm-4.7-flash',
      'GLM-4.7-FlashX': 'zai/glm-4.7-flashx',
      'Mistral': 'openrouter/mistral/mistral:free',
      'NVIDIA': 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free',
      'OpenRouter-Free': 'openrouter/free',
      'Qwen3-Coder': 'openrouter/qwen/qwen3-coder:free',
      'Step-3.5': 'openrouter/stepfun/step-3.5:free'
    };
    
    // 默认配置
    this.config = {
      rotationMode: 'round-robin',  // round-robin 或 weighted
      preferFree: true,
      maxFailures: 3,
      timeout: 30000,
      enableAutoDiscovery: true,
      autoDiscoveryInterval: 300000, // 5分钟
      enableLogging: true,
      unhealthyModels: new Set(),
      modelWeights: {
        'openrouter/nvidia/nemotron-3-nano-30b-a3b:free': 0.2,
        'zai/glm-4.7-flash': 0.15,
        'openrouter/deepseek/deepseek:free': 0.15,
        'openrouter/mistral/mistral:free': 0.1,
        'openrouter/qwen/qwen3-coder:free': 0.1,
        'openrouter/stepfun/step-3.5:free': 0.1,
        'openrouter/free': 0.1,
        'zai/glm-4.7-flashx': 0.05,
        'zai/glm-4.5-air': 0.03,
        'zai/glm-4.7': 0.01,
        'zai/glm-5': 0.01
      },
      currentIndex: 0,
      rotationCount: 0,
      availableModels: [],
      discoveryHistory: []
    };
    
    // 确保数组存在
    this.config.discoveryHistory = this.config.discoveryHistory || [];
    
    // 合并用户配置
    Object.assign(this.config, config);
    
    // 从环境变量加载配置
    this.loadFromEnv();
    
    // 初始化
    this.initialize();
  }

  loadFromEnv() {
    if (process.env.MODEL_ROTATION_MODE) {
      this.config.rotationMode = process.env.MODEL_ROTATION_MODE;
    }
    
    if (process.env.PREFER_FREE !== undefined) {
      this.config.preferFree = process.env.PREFER_FREE === 'true';
    }
    
    if (process.env.MAX_FAILURES) {
      this.config.maxFailures = parseInt(process.env.MAX_FAILURES);
    }
    
    if (process.env.MODEL_TIMEOUT) {
      this.config.timeout = parseInt(process.env.MODEL_TIMEOUT);
    }
    
    if (process.env.MODEL_WEIGHTS) {
      try {
        this.config.modelWeights = JSON.parse(process.env.MODEL_WEIGHTS);
      } catch (e) {
        this.log('警告: MODEL_WEIGHTS JSON 格式错误，使用默认值');
      }
    }
  }

  initialize() {
    // 开始自动发现
    if (this.config.enableAutoDiscovery) {
      this.startAutoDiscovery();
    }
  }

  async discoverModels() {
    const startTime = Date.now();
    const discoveredModels = new Set();
    
    this.log('开始自动发现可用模型...');
    
    // 1. 检查预定义模型别名
    const aliasModels = Object.values(this.modelAliases);
    for (const model of aliasModels) {
      if (await this.testModel(model)) {
        discoveredModels.add(model);
      }
    }
    
    // 2. 尝试发现其他可能的模型
    const additionalModels = await this.findAdditionalModels();
    for (const model of additionalModels) {
      if (await this.testModel(model)) {
        discoveredModels.add(model);
      }
    }
    
    // 3. 系统环境变量中的模型
    const envModels = await this.discoverFromEnvironment();
    for (const model of envModels) {
      if (await this.testModel(model)) {
        discoveredModels.add(model);
      }
    }
    
    // 过滤掉被标记为不健康的模型
    const healthyModels = Array.from(discoveredModels).filter(
      model => !this.config.unhealthyModels.has(model)
    );
    
    // 按优先级排序
    this.config.availableModels = this.sortModelsByPriority(healthyModels);
    
    const discoveryTime = Date.now() - startTime;
    (this.config.discoveryHistory || []).push({
      timestamp: new Date().toISOString(),
      models: this.config.availableModels.length,
      discoveryTime,
      unhealthyCount: this.config.unhealthyModels.size
    });
    
    this.log(`模型发现完成: 发现 ${this.config.availableModels.length} 个可用模型`);
    this.log(`可用模型列表: ${this.config.availableModels.join(', ')}`);
    
    return this.config.availableModels;
  }

  async testModel(model) {
    const startTime = Date.now();
    
    try {
      // 简单的连通性测试
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('模型测试超时')), this.config.timeout);
      });
      
      const testPromise = this.executeModelTest(model);
      await Promise.race([testPromise, timeoutPromise]);
      
      const responseTime = Date.now() - startTime;
      this.log(`模型 ${model} 测试成功, 响应时间: ${responseTime}ms`);
      
      return true;
    } catch (error) {
      this.log(`模型 ${model} 测试失败: ${error.message}`);
      return false;
    }
  }

  async executeModelTest(model) {
    // 简单的模型连通性测试，不依赖 session_status 命令
    // 检查模型名称是否有效
    const validModelPatterns = [
      /^openrouter\/.*$/,
      /^zai\/.*$/,
      /^openai\/.*$/,
      /^anthropic\/.*$/
    ];
    
    const isValidPattern = validModelPatterns.some(pattern => 
      pattern.test(model) || model.includes(':')
    );
    
    if (!isValidPattern) {
      throw new Error('Invalid model format');
    }
    
    // 检查模型是否在预定义列表中
    const predefinedModels = Object.values(this.modelAliases);
    if (!predefinedModels.includes(model)) {
      throw new Error('Model not in predefined list');
    }
    
    return true;
  }

  async findAdditionalModels() {
    const additionalModels = [];
    
    // 尝试从配置文件中读取模型
    try {
      const configPath = path.join(process.cwd(), 'openclaw.json');
      const fs = require('fs');
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (config.models) {
          additionalModels.push(...config.models);
        }
      }
    } catch (error) {
      // 忽略配置文件读取错误
    }
    
    // 尝试从环境变量中发现
    const modelEnvVars = Object.keys(process.env).filter(key => 
      key.toLowerCase().includes('model') || 
      key.toLowerCase().includes('openrouter')
    );
    
    for (const envVar of modelEnvVars) {
      const value = process.env[envVar];
      if (value && typeof value === 'string') {
        // 尝试解析为模型URL
        if (value.includes('openrouter') || value.includes('zai')) {
          additionalModels.push(value);
        }
      }
    }
    
    return [...new Set(additionalModels)];
  }

  async discoverFromEnvironment() {
    const envModels = [];
    
    // 检查常见的模型环境变量
    const envVars = [
      'OPENROUTER_MODEL',
      'MODEL_NAME',
      'DEFAULT_MODEL',
      'AI_MODEL'
    ];
    
    for (const envVar of envVars) {
      if (process.env[envVar]) {
        envModels.push(process.env[envVar]);
      }
    }
    
    return [...new Set(envModels)];
  }

  sortModelsByPriority(models) {
    if (!this.config.preferFree) {
      return models;
    }
    
    const freeModels = [];
    const paidModels = [];
    
    for (const model of models) {
      if (this.isFreeModel(model)) {
        freeModels.push(model);
      } else {
        paidModels.push(model);
      }
    }
    
    return [...freeModels, ...paidModels];
  }

  isFreeModel(model) {
    const freeIndicators = [
      ':free',
      'nemotron',
      'mistral', 
      'deepseek',
      'qwen3-coder',
      'step-3.5',
      'openrouter/free'
    ];
    
    return freeIndicators.some(indicator => model.toLowerCase().includes(indicator));
  }

  next() {
    if (this.config.availableModels.length === 0) {
      // 如果没有可用模型，尝试重新发现
      this.log('没有可用模型，尝试重新发现...');
      this.discoverModels().catch(() => {
        // 如果发现失败，返回默认模型
        return 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free';
      });
    }
    
    if (this.config.availableModels.length === 0) {
      // 如果发现失败，返回默认模型
      this.log('使用默认模型');
      return 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free';
    }
    
    let selectedModel;
    
    switch (this.config.rotationMode) {
      case 'round-robin':
        selectedModel = this.nextRoundRobin();
        break;
      case 'weighted':
        selectedModel = this.nextWeighted();
        break;
      default:
        selectedModel = this.nextRoundRobin();
    }
    
    this.config.rotationCount++;
    this.log(`选择模型: ${selectedModel} (轮询次数: ${this.config.rotationCount})`);
    
    return selectedModel;
  }

  nextRoundRobin() {
    let attempts = 0;
    let selectedModel;
    
    do {
      selectedModel = this.config.availableModels[this.config.currentIndex];
      this.config.currentIndex = (this.config.currentIndex + 1) % this.config.availableModels.length;
      attempts++;
    } while (this.config.unhealthyModels.has(selectedModel) && attempts < this.config.availableModels.length);
    
    // 如果所有模型都不可用，重新发现
    if (attempts >= this.config.availableModels.length) {
      this.log('所有可用模型都不可用，重新发现...');
      this.discoverModels().catch(() => {
        // 如果发现失败，返回默认模型
        return 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free';
      });
      selectedModel = 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free';
    }
    
    return selectedModel;
  }

  nextWeighted() {
    if (this.config.availableModels.length === 0) {
      return 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free';
    }
    
    // 计算可用模型的权重
    const weights = {};
    let totalWeight = 0;
    
    for (const model of this.config.availableModels) {
      const weight = this.config.modelWeights[model] || 0.1;
      weights[model] = weight;
      totalWeight += weight;
    }
    
    // 加权随机选择
    let random = Math.random() * totalWeight;
    let selectedModel;
    
    for (const model of this.config.availableModels) {
      random -= weights[model];
      if (random <= 0) {
        selectedModel = model;
        break;
      }
    }
    
    return selectedModel || this.config.availableModels[0];
  }

  markUnhealthy(model) {
    this.config.unhealthyModels.add(model);
    this.log(`模型 ${model} 已标记为不可用`);
    
    // 重新排序可用模型
    this.config.availableModels = this.config.availableModels.filter(
      m => !this.config.unhealthyModels.has(m)
    );
    
    // 如果可用模型太少，尝试重新发现
    if (this.config.availableModels.length < 3) {
      this.log(`可用模型过少，重新发现...`);
      this.discoverModels().catch(() => {
        this.log('重新发现失败');
      });
    }
  }

  reset() {
    this.config.currentIndex = 0;
    this.config.rotationCount = 0;
    this.config.unhealthyModels.clear();
    this.config.discoveryHistory = [];
    
    this.log('轮询状态已重置');
  }

  getStatus() {
    const availableModels = this.config.availableModels || [];
    
    return {
      rotationMode: this.config.rotationMode,
      preferFree: this.config.preferFree,
      currentIndex: this.config.currentIndex,
      rotationCount: this.config.rotationCount,
      unhealthyModels: Array.from(this.config.unhealthyModels),
      availableModels: availableModels,
      totalModels: availableModels.length,
      freeModels: availableModels.filter(m => this.isFreeModel(m)).length,
      paidModels: availableModels.filter(m => !this.isFreeModel(m)).length,
      nextModel: availableModels[this.config.currentIndex] || 'N/A',
      lastDiscovery: (this.config.discoveryHistory || [])[this.config.discoveryHistory?.length - 1] || null
    };
  }

  startAutoDiscovery() {
    setInterval(() => {
      this.discoverModels().catch(error => {
        this.log(`自动发现失败: ${error.message}`);
      });
    }, this.config.autoDiscoveryInterval);
    
    this.log(`已启动自动发现，间隔: ${this.config.autoDiscoveryInterval / 1000} 秒`);
  }

  log(message) {
    if (this.config.enableLogging) {
      console.log(`[ModelAutoRotator] ${new Date().toISOString()} - ${message}`);
    }
  }

  // 根据任务类型推荐模型
  getRecommendedModel(taskType = 'general') {
    // 推荐映射
    const recommendations = {
      'general': 'zai/glm-4.7-flash',
      'coding': 'openrouter/qwen/qwen3-coder:free',
      'creative': 'zai/glm-4.7',
      'analysis': 'openrouter/deepseek/deepseek:free',
      'fast': 'openrouter/nvidia/nemotron-3-nano-30b-a3b:free'
    };
    
    const recommendedModel = recommendations[taskType] || 'zai/glm-4.7-flash';
    
    // 检查推荐模型是否可用
    const availableModels = this.config.availableModels;
    if (availableModels.includes(recommendedModel)) {
      return recommendedModel;
    } else {
      // 如果不可用，使用下一个可用模型
      return this.next();
    }
  }
}

// 导出单例和类
const autoRotator = new ModelAutoRotator();
module.exports = autoRotator;
module.exports.ModelAutoRotator = ModelAutoRotator;

// CLI 支持
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.includes('--discover')) {
    autoRotator.discoverModels().then(models => {
      console.log('发现的可用模型:', models);
    }).catch(error => {
      console.error('发现失败:', error.message);
      process.exit(1);
    });
  } else if (args.includes('--status')) {
    console.log(JSON.stringify(autoRotator.getStatus(), null, 2));
  } else if (args.includes('--next')) {
    console.log(autoRotator.next());
  } else if (args.includes('--reset')) {
    autoRotator.reset();
    console.log('轮询状态已重置');
  } else if (args.includes('--unhealthy')) {
    const model = args[args.indexOf('--unhealthy') + 1];
    if (model) {
      autoRotator.markUnhealthy(model);
      console.log(`模型 ${model} 已标记为不可用`);
    } else {
      console.error('请指定要标记的模型');
      process.exit(1);
    }
  } else {
    console.log('使用方法:');
    console.log('  node model-auto-rotator.js --discover    # 发现可用模型');
    console.log('  node model-auto-rotator.js --status      # 显示状态');
    console.log('  node model-auto-rotator.js --next        # 获取下一个模型');
    console.log('  node model-auto-rotator.js --reset       # 重置状态');
    console.log('  node model-auto-rotator.js --unhealthy <model>  # 标记模型不可用');
  }
}