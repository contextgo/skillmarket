---
name: model-auto-rotator
description: 自动检测系统可用模型并实现智能轮询切换的技能。能够动态发现当前可用的OpenRouter模型，实现自动故障转移、负载均衡和成本优化。使用环境变量、会话状态测试和连通性检测来自动构建可用模型列表，支持轮询和加权切换策略。
metadata: { "openclaw": { "emoji": "🔄", "requires": { "bins": ["node"] } } }
---

# Model Auto Rotator

自动检测并轮询系统可用模型的技能。

## 功能特性

- **🔍 自动发现** - 检测当前系统可用的模型
- **⚡ 智能轮询** - Round Robin 和 Weighted 模式
- **🚫 故障转移** - 自动跳过不可用模型
- **💰 成本优化** - 优先使用免费模型
- **📊 状态监控** - 实时显示模型可用性
- **⚙️ 自适应配置** - 根据检测结果动态调整

## 使用方法

```javascript
const autoRotator = require('./model-auto-rotator.js');

// 自动检测可用模型
const models = await autoRotator.discoverModels();
console.log('发现可用模型:', models);

// 获取下一个可用模型
const nextModel = autoRotator.next();
console.log('下一个模型:', nextModel);

// 获取当前状态
const status = autoRotator.getStatus();
console.log('轮询状态:', status);
```

## 环境变量配置

```bash
# 轮询模式
export MODEL_ROTATION_MODE=round-robin    # 或 weighted

# 优先使用免费模型
export PREFER_FREE=true

# 最大失败次数
export MAX_FAILURES=3

# 超时时间(毫秒)
export MODEL_TIMEOUT=30000
```

## 自动发现逻辑

1. **模型别名映射** - 检查预定义的模型别名
2. **会话状态测试** - 使用 session_status 测试模型
3. **连通性检测** - 简单的 API 调用测试
4. **性能分析** - 测试响应时间
5. **过滤不可用** - 移除失败和超时的模型

## API 方法

```javascript
// 发现所有可用模型
await autoRotator.discoverModels()

// 获取下一个可用模型
autoRotator.next()

// 标记模型为不可用
autoRotator.markUnhealthy(model)

// 获取当前状态
autoRotator.getStatus()

// 重置轮询状态
autoRotator.reset()

// 强制重新发现模型
await autoRotator.forceDiscovery()
```

## 集成示例

```javascript
// 在 OpenClaw 会话中使用
async function createRotatedSession(task) {
  const model = autoRotator.next();
  
  const session = await sessions_spawn({
    task: task,
    model: model,
    timeoutSeconds: 300
  });
  
  // 监听会话结果
  session.on('completed', () => {
    console.log(`会话完成，模型: ${model}`);
  });
  
  session.on('failed', (error) => {
    console.log(`会话失败，标记模型不可用: ${model}`);
    autoRotator.markUnhealthy(model);
  });
  
  return session;
}
```
