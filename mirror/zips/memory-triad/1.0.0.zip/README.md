# memory-triad

自动化三层记忆归档与索引维护。

---

## 前言：为什么需要三层记忆架构

单个文件或简单的每日日志无法解决 AI 助手的**上下文连续性**问题：

- **会话太长** → 触发 LCM 压缩，中间技术细节被 summary 吞掉，后续回答出现“失忆”。
- **跨会话跳转** → 昨天聊过的项目约束、今天的用户偏好变更，无法在新会话中快速恢复。
- **长期记忆腐烂** → `MEMORY.md` 越写越乱，变成无人维护的垃圾堆，最终只能被整体忽略。

memory-triad 的核心思路是**分层+自动化**：
- 每一层负责不同的**时间粒度**和**数据密度**；
- 三层之间有明确的晋升（flush）与降级（archive）规则；
- 把 80% 的机械归档工作交给脚本，你只用做最后的 judgment 和审阅。

**重要声明**：本 skill **不负责替代你的判断**。它自动完成的是繁琐的“复制、粘贴、整理目录、更新索引”工作，但哪些决策值得进 MEMORY.md、哪些项目应该标记为活跃，仍然需要你最终确认或编辑。

---

## 三层互补模型

| 层级 | 名称 | 存储位置 | 时间跨度 | 数据粒度 | 展开方式 | 主要职责 |
|------|------|----------|----------|----------|----------|----------|
| **L1** | LCM（Lossless Context Management） | 运行时内存 / LCM DAG | 当前会话内 | 原始消息 + 压缩摘要节点 | `lcm_expand` / `lcm_describe` | 会话内无损压缩，维持长对话可用性 |
| **L2** | CC（Context Compaction） | `memory/YYYY-MM-DD.md` | 近 3–7 天 | 结构化 5 部分摘要 | 直接读取 markdown | 跨会话快速恢复昨日/今日状态 |
| **L3** | 长期记忆索引 | `MEMORY.md` + `USER.md` | 数月到数年 | 关键决策、偏好、项目索引 | 按需读取特定章节 | 长期知识沉淀，防止腐烂 |

**互补关系简述**：

- **L1 → L2**：会话结束或检测到 LCM 压缩时，自动 flush 为 CC 摘要，写入每日日志。
- **L2 → L3**：心跳任务扫描近几日 CC 摘要，提取关键决策和偏好变更，合并更新到 MEMORY.md。
- **L3 → 归档**：7 天前的 L2 日志自动移入 `memory/archived/`，过大的 markdown 文件自动 gzip 压缩。
- **L3 ←→ 活跃话题**：MEMORY.md 置顶 `#活跃话题` 章节，作为每次对话前的预热来源。

---

## 安装与初始化

### 安装
```bash
# 推荐
clawhub install memory-triad

# 手动
unzip memory-triad.zip -d ~/.openclaw/workspace/skills/memory-triad/
```

### 初始化
首次安装后执行：
```bash
python3 ~/.openclaw/workspace/skills/memory-triad/setup_workspace.py
```

初始化脚本会完成以下检查与创建：
1. 检查 OpenClaw 版本（≥ 2.13）；
2. 探测 LCM / lossless-claw 插件状态，若缺失则配置降级模式；
3. 创建 `memory/`、`memory/archived/`、`templates/` 目录；
4. 释放默认的 `context_compaction_template.md` 模板；
5. 注册会话结束 flush hook（若 OpenClaw 支持）。

---

## 配置 cron / heartbeat 的完整示例

### 示例 1：每日心跳（推荐）
将以下内容追加到你的 `HEARTBEAT.md` 或设置为心跳脚本：

```bash
#!/bin/bash
# 每日记忆维护：03:17 执行，错峰
~/.openclaw/workspace/skills/memory-triad/bin/memory-triad heartbeat
```

如果你使用 OpenClaw 的 cron 系统：

```bash
openclaw cron add \
  --name "memory-triad-daily" \
  --schedule "0 17 3 * * *" \
  --command "~/.openclaw/workspace/skills/memory-triad/bin/memory-triad heartbeat" \
  --target isolated
```

### 示例 2：每周深度整理
```bash
openclaw cron add \
  --name "memory-triad-weekly" \
  --schedule "0 30 4 * * 0" \
  --command "~/.openclaw/workspace/skills/memory-triad/bin/memory-triad heartbeat --deep" \
  --target isolated
```

`--deep` 模式会：
- 重新扫描整个 `memory/` 目录；
- 对 MEMORY.md 进行去重、合并、章节重排；
- 归档所有超过 7 天的日志。

### 示例 3：LCM 定时检查
适合高频率长对话的场景，每 2 小时检查一次当前会话的 LCM 状态：

```bash
openclaw cron add \
  --name "memory-triad-audit" \
  --schedule "0 0 */2 * * *" \
  --command "~/.openclaw/workspace/skills/memory-triad/bin/memory-triad audit --auto-flush" \
  --target main
```

`--auto-flush` 表示如果检测到关键上下文已被 LCM 压缩而 L2/L3 尚未更新，则自动触发一次 flush。

---

## 使用流程图

```text
用户进入新会话
    ↓
[预热] 读取 SOUL.md → USER.md → MEMORY.md #活跃话题 → 今日/昨日 memory 日志
    ↓
会话进行中 （大量对话，上下文增长）
    ↓
上下文达到阈值 ──→ LCM 触发压缩（生成 DAG summary 节点）
    ↓
会话结束 / audit 检查
    ↓
memory-triad flush ──→ 生成 CC 5 部分摘要
    ↓
├── 写入 memory/YYYY-MM-DD.md  （L2）
├── 更新 MEMORY.md 关键决策/活跃话题 （L3）
└── 标记已落盘，避免重复写入
    ↓
每日 heartbeat
    ↓
├── 归档 7 天前日志 → memory/archived/
├── 压缩大文件 (>100KB)
└── 扫描近 3 日 CC → 合并提炼 → MEMORY.md
    ↓
下次会话预热时，从 L2/L3 恢复上下文
```

---

## 常见问题

**Q: 我已经有了 MEMORY.md，安装这个 skill 会不会覆盖我的内容？**
A: 不会。所有操作都是**追加或 patch**，初始化脚本和 flush/heartbeat 都不会覆盖现有文件。建议在 git 中跟踪 `memory/` 目录，以便随时回滚。

**Q: 为什么 LCM 压缩后还能“无损”展开？**
A: LCM 的“无损”指的是压缩过程保留了一条可展开的引用链（DAG），你可以用 `lcm_expand` 重新访问被 summary 的原始消息。但这并不意味着信息永远不会丢失：如果压缩节点本身的摘要质量不足，展开后看到的仍然是摘要，而非逐字原始对话。因此 memory-triad 的策略是**在压缩发生前先把关键决策写到 L3**。

**Q: 自动 flush 的内容质量不高怎么办？**
A: 编辑 `templates/context_compaction_template.md`。该模板定义了 CC 摘要的生成结构和提示词，完全由你控制。skill 更新时不会覆盖用户自定义模板。

**Q: 我不想用 cron，只想在会话结束时自动归档，可以吗？**
A: 可以。只需安装 skill 并完成初始化，`on_session_end` hook 会自动生效。heartbeat 和 audit 是可选增强。

**Q: memory-triad 会读取我的隐私内容吗？**
A: 它只读取你当前工作区（workspace）内已有的记忆文件和上下文数据，不会访问外部网络或上传任何信息。所有处理都在本地完成。
