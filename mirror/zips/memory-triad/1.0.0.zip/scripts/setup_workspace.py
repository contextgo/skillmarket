#!/usr/bin/env python3
"""setup_workspace.py - Initialize memory-triad workspace directories and templates."""

import json
import os
import re
import sys
from datetime import datetime


def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def sanitize_path(path):
    """Expand ~ and resolve to absolute path. Prevent path traversal."""
    expanded = os.path.expanduser(os.path.expandvars(path))
    abs_path = os.path.abspath(expanded)
    
    # Security check: reject paths containing ..
    if ".." in path:
        raise ValueError(f"Path traversal detected: {path}")
    
    return abs_path


def load_config(config_path=None):
    if config_path is None:
        config_path = os.path.join(get_script_dir(), "config", "memory_triad.json")
    if not os.path.exists(config_path):
        print(f"[ERROR] Config not found: {config_path}", file=sys.stderr)
        sys.exit(1)
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
        print(f"[OK] Created directory: {path}")
    else:
        print(f"[SKIP] Directory already exists: {path}")


def generate_memory_md(path):
    if os.path.exists(path):
        print(f"[SKIP] MEMORY.md already exists: {path}")
        return

    today = datetime.now().strftime("%Y-%m-%d")
    content = f"""# MEMORY.md

> 长期记忆索引。记录关键决策、用户偏好与历史项目。
> 初始化日期: {today}

---

## 活跃话题 (#活跃话题)
*当前进行中的事务汇总。*

- (暂无)

---

## 关键决策索引
*按时间倒序排列。*

### {today}
- 初始化 MEMORY.md 结构与记忆三元组系统。

---

## 用户偏好速查
*稳定的交互偏好与规则。*

- (待记录)

---

## 历史项目
*已完成或归档的项目。*

- (暂无)

---

*由 memory-triad/setup_workspace.py 自动生成*
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[OK] Generated {path}")


def main():
    print("=== memory-triad workspace setup ===")

    config = load_config()
    
    # 安全处理：展开 ~ 和环境变量
    try:
        base_dir = sanitize_path(config["paths"]["base_dir"])
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)
    
    if not os.path.exists(base_dir):
        print(f"[ERROR] Base directory does not exist: {base_dir}", file=sys.stderr)
        sys.exit(1)

    dirs = [
        config["paths"]["memory_dir"],
        config["paths"]["diary_dir"],
        config["paths"]["archive_dir"],
        config["paths"]["scattered_dir"],
        config["paths"]["memory_archived_dir"],
    ]

    for d in dirs:
        ensure_dir(os.path.join(base_dir, d))

    memory_md_path = os.path.join(base_dir, config["paths"]["memory_file"])
    generate_memory_md(memory_md_path)

    print("=== setup complete ===")


if __name__ == "__main__":
    main()
