#!/usr/bin/env python3
"""lcm_compatibility_check.py - Check LCM/上下文压缩工具在当前环境中的可用性。

兼容多种 AI Agent 环境（OpenClaw、Aily 等），不硬编码特定平台路径。
"""

import json
import os
import subprocess
import sys


def command_exists(cmd):
    try:
        subprocess.run(["which", cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except subprocess.CalledProcessError:
        return False


def check_agent_context():
    """检测是否在 AI Agent 环境中运行。"""
    # 常见 Agent 环境变量前缀
    agent_prefixes = ("OPENCLAW", "AILY", "CLAUDE", "ANTHROPIC", "OPENAI")
    return any(k.startswith(agent_prefixes) for k in os.environ)


def try_tool_call(tool_name, test_args=None):
    """尝试调用 LCM 工具。如果工具不存在则返回 False。"""
    if not command_exists(tool_name):
        return False, f"'{tool_name}' not found in PATH"
    try:
        args = [tool_name]
        if test_args:
            args.extend(test_args)
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        # Some tools might exit non-zero on test args, but if they print usage, it's available
        available = result.returncode == 0 or b"usage" in result.stderr.lower() or b"help" in result.stderr.lower()
        return available, result.stderr.decode("utf-8", errors="ignore").strip() or result.stdout.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        return False, str(e)


def detect_lcm_db():
    """检测 LCM 数据库是否存在。兼容多种平台。"""
    possible_paths = [
        "~/.openclaw/lcm.db",          # OpenClaw
        "~/.aily/lcm.db",               # Aily
        "~/.claude/lcm.db",             # Claude
    ]
    
    for path in possible_paths:
        expanded = os.path.expanduser(path)
        if os.path.exists(expanded):
            return True, expanded
    
    return False, None


def main():
    in_agent_context = check_agent_context()
    lcm_db_exists, lcm_db_path = detect_lcm_db()
    
    report = {
        "agent_context": {
            "detected": in_agent_context,
            "environment": {k: v for k, v in os.environ.items() if any(k.startswith(p) for p in ("OPENCLAW", "AILY", "CLAUDE"))}
        },
        "lcm": {
            "db_exists": lcm_db_exists,
            "db_path": lcm_db_path,
            "tools": {},
            "shell_callable": False,
        },
    }

    # 尝试检测常见的 LCM 工具
    lcm_tools = ["lcm_grep", "lcm_describe", "lcm_expand", "lcm_ls"]
    for tool in lcm_tools:
        available, detail = try_tool_call(tool, ["--help"])
        report["lcm"]["tools"][tool] = {
            "available": available,
            "detail": detail[:200] if detail else None,  # 截断避免过长输出
        }
        if available:
            report["lcm"]["shell_callable"] = True

    # Overall assessment
    lcm_usable = in_agent_context and (lcm_db_exists or report["lcm"]["shell_callable"])
    report["summary"] = {
        "lcm_usable": lcm_usable,
        "note": (
            "LCM 工具在 Agent 会话中可用。"
            if lcm_usable
            else "LCM 不可用，将降级为 CC + MEMORY 两层存储模式。"
        ),
    }

    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if lcm_usable else 1


if __name__ == "__main__":
    sys.exit(main())
