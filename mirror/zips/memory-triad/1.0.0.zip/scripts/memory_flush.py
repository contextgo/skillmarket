#!/usr/bin/env python3
"""memory_flush.py - Session-end memory flush: append CC summary and update MEMORY.md.

Design:
1. Accept Context Compaction (CC) content via --cc-file or stdin.
2. Append it to memory/YYYY-MM-DD.md.
3. Parse key decisions from the CC and append them to MEMORY.md index.
4. Graceful degradation when LCM is unavailable.
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime


def sanitize_path(path):
    """Expand ~ and resolve to absolute path. Prevent path traversal."""
    expanded = os.path.expanduser(os.path.expandvars(path))
    abs_path = os.path.abspath(expanded)
    if ".." in path:
        raise ValueError(f"Path traversal detected: {path}")
    return abs_path


def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def load_config(config_path=None):
    if config_path is None:
        config_path = os.path.join(get_script_dir(), "config", "memory_triad.json")
    if not os.path.exists(config_path):
        print(f"[ERROR] Config not found: {config_path}", file=sys.stderr)
        sys.exit(1)
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_lcm_available():
    """Check if LCM tools are callable from the current environment.
    LCM availability is determined by environment detection."""
    lcm_context = any(k.startswith(("OPENCLAW", "AILY")) for k in os.environ)
    return lcm_context


def read_cc_content(path_or_stdin):
    if path_or_stdin:
        with open(path_or_stdin, "r", encoding="utf-8") as f:
            return f.read()
    if sys.stdin.isatty():
        return ""
    return sys.stdin.read()


def append_to_daily_log(base_dir, memory_dir, content):
    today = datetime.now().strftime("%Y-%m-%d")
    log_dir = sanitize_path(os.path.join(base_dir, memory_dir))
    log_path = os.path.join(log_dir, f"{today}.md")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    entry = f"\n\n---\n\n## Flush @ {timestamp}\n\n{content}\n"

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(entry)
    print(f"[OK] Appended CC summary to {log_path}")
    return log_path


def extract_key_decisions(cc_text):
    """Extract decisions from section 3 (Important Discoveries).
    Looks for lines mentioning '决策' or '决定' under the section."""
    decisions = []
    lines = cc_text.splitlines()
    in_section = False

    for line in lines:
        stripped = line.strip()
        if re.match(r"^##\s*3\.\s*重要发现", stripped):
            in_section = True
            continue
        if in_section and re.match(r"^##\s*\d", stripped):
            break
        if in_section and ("决策" in stripped or "决定" in stripped):
            # Skip empty bullets or headers without content
            if stripped.startswith("-") or stripped.startswith("*"):
                cleaned = stripped.lstrip("- *").strip()
                # Skip structural headers like "决策及原因：" or empty "决策："
                if re.match(r"^(决策及原因|决定及原因)\s*[:：]?$", cleaned):
                    continue
                if re.match(r"^(决策|决定)\s*[:：]\s*$", cleaned):
                    continue
                decisions.append(cleaned)

    return decisions


def update_memory_md(base_dir, memory_file, decisions):
    path = sanitize_path(os.path.join(base_dir, memory_file))
    if not os.path.exists(path):
        print(f"[WARN] {path} not found. Run setup_workspace.py first.", file=sys.stderr)
        return

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    today = datetime.now().strftime("%Y-%m-%d")
    section_header = "## 关键决策索引"

    if section_header not in content:
        content += f"\n\n{section_header}\n*按时间倒序排列。*\n\n"

    # Build the new entry
    entry_lines = [f"### {today}"]
    if decisions:
        for d in decisions:
            entry_lines.append(f"- {d}")
    else:
        entry_lines.append("- (本次 flush 未提取到结构化决策)")

    new_entry = "\n".join(entry_lines) + "\n"

    # Insert after the section header, before the next ## section or EOF
    parts = content.split(section_header, 1)
    after_header = parts[1]

    # Find the next top-level section
    next_section_match = re.search(r"\n##\s+", after_header)
    if next_section_match:
        insert_pos = next_section_match.start()
        updated_after = after_header[:insert_pos] + "\n" + new_entry + after_header[insert_pos:]
    else:
        updated_after = after_header + "\n" + new_entry

    updated_content = parts[0] + section_header + updated_after

    with open(path, "w", encoding="utf-8") as f:
        f.write(updated_content)
    print(f"[OK] Updated {path} with {len(decisions)} key decision(s)")


def main():
    parser = argparse.ArgumentParser(description="Session-end memory flush for memory-triad.")
    parser.add_argument("--cc-file", help="Path to the Context Compaction markdown file. If omitted, reads from stdin.")
    parser.add_argument("--config", help="Path to memory_triad.json config. Default: ../config/memory_triad.json")
    args = parser.parse_args()

    config = load_config(args.config)
    
    # 安全处理 base_dir
    try:
        base_dir = sanitize_path(config["paths"]["base_dir"])
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)

    # LCM availability check
    lcm_ok = check_lcm_available()
    if not lcm_ok:
        msg = config.get("lcm", {}).get("fallback_message", "LCM unavailable. Falling back to CC + MEMORY.")
        print(f"[WARN] {msg}", file=sys.stderr)
    else:
        print("[OK] LCM environment detected. CC + MEMORY + LCM three-tier storage active.")

    # Read CC content
    cc_content = read_cc_content(args.cc_file)
    if not cc_content.strip():
        print("[WARN] No CC content provided. Nothing to flush.", file=sys.stderr)
        sys.exit(0)

    # Append to daily log
    append_to_daily_log(base_dir, config["paths"]["memory_dir"], cc_content)

    # Extract and update key decisions
    decisions = extract_key_decisions(cc_content)
    update_memory_md(base_dir, config["paths"]["memory_file"], decisions)

    print("=== memory flush complete ===")


if __name__ == "__main__":
    main()
