#!/usr/bin/env python3
"""heartbeat_memory_check.py - Heartbeat memory maintenance for memory-triad.

Tasks:
1. Check memory/ log volume (size & file count).
2. Archive memory/YYYY-MM-DD.md files older than N days to memory/archived/.
3. Extract key decisions from recent N days of logs and append to MEMORY.md.
4. Remove temporary files older than N days from scattered/ and configurable temp locations.
"""

import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta


def sanitize_path(path):
    """Expand ~ and resolve to absolute path. Prevent path traversal."""
    expanded = os.path.expanduser(os.path.expandvars(path))
    abs_path = os.path.abspath(expanded)
    if ".." in path:
        raise ValueError(f"Path traversal detected: {path}")
    return abs_path


def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def load_config(config_path=None):
    if config_path is None:
        config_path = os.path.join(get_script_dir(), "config", "memory_triad.json")
    if not os.path.exists(config_path):
        print(f"[ERROR] Config not found: {config_path}", file=sys.stderr)
        sys.exit(1)
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def run_cmd(cmd_list):
    """Safe subprocess execution with controlled arguments only."""
    import subprocess
    try:
        # Only allow specific commands
        allowed_commands = ["du", "find"]
        if cmd_list[0] not in allowed_commands:
            return ""
        
        result = subprocess.run(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        return ""
    except FileNotFoundError:
        return ""


def check_memory_volume(base_dir, memory_dir):
    path = sanitize_path(os.path.join(base_dir, memory_dir))
    if not os.path.exists(path):
        return 0, 0

    size_str = run_cmd(["du", "-sb", path])
    size_bytes = int(size_str.split()[0]) if size_str else 0

    file_count = 0
    for _, _, files in os.walk(path):
        file_count += len(files)

    size_mb = size_bytes / (1024 * 1024)
    return size_mb, file_count


def archive_old_logs(base_dir, memory_dir, archived_dir, retention_days):
    memory_path = sanitize_path(os.path.join(base_dir, memory_dir))
    archive_path = sanitize_path(os.path.join(base_dir, archived_dir))
    os.makedirs(archive_path, exist_ok=True)

    cutoff = datetime.now() - timedelta(days=retention_days)
    moved = 0

    if not os.path.exists(memory_path):
        return moved

    for fname in os.listdir(memory_path):
        # Only match date-formatted markdown files
        if not re.match(r"^\d{4}-\d{2}-\d{2}\.md$", fname):
            continue
        fpath = os.path.join(memory_path, fname)
        if not os.path.isfile(fpath):
            continue

        file_date = datetime.strptime(fname.replace(".md", ""), "%Y-%m-%d")
        if file_date < cutoff:
            dest = os.path.join(archive_path, fname)
            shutil.move(fpath, dest)
            moved += 1
            print(f"[ARCHIVE] Moved {fname} -> {archive_path}")

    return moved


def extract_key_decisions_from_file(fpath):
    decisions = []
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception:
        return decisions

    lines = content.splitlines()
    in_section = False
    for line in lines:
        stripped = line.strip()
        if re.match(r"^##\s*3\.\s*重要发现", stripped):
            in_section = True
            continue
        if in_section and re.match(r"^##\s*\d", stripped):
            break
        if in_section and ("决策" in stripped or "决定" in stripped):
            if stripped.startswith("-") or stripped.startswith("*"):
                cleaned = stripped.lstrip("- *").strip()
                # Skip structural headers like "决策及原因：" or empty "决策："
                if re.match(r"^(决策及原因|决定及原因)\s*[:：]?$", cleaned):
                    continue
                if re.match(r"^(决策|决定)\s*[:：]\s*$", cleaned):
                    continue
                decisions.append(cleaned)
    return decisions


def update_memory_md_with_recent(base_dir, memory_file, recent_days, memory_dir):
    path = sanitize_path(os.path.join(base_dir, memory_file))
    if not os.path.exists(path):
        print(f"[WARN] {path} not found. Run setup_workspace.py first.", file=sys.stderr)
        return

    memory_path = sanitize_path(os.path.join(base_dir, memory_dir))
    if not os.path.exists(memory_path):
        return

    cutoff = datetime.now() - timedelta(days=recent_days)
    all_decisions = []

    for fname in sorted(os.listdir(memory_path)):
        if not re.match(r"^\d{4}-\d{2}-\d{2}\.md$", fname):
            continue
        fpath = os.path.join(memory_path, fname)
        if not os.path.isfile(fpath):
            continue

        file_date = datetime.strptime(fname.replace(".md", ""), "%Y-%m-%d")
        if file_date >= cutoff:
            decisions = extract_key_decisions_from_file(fpath)
            if decisions:
                date_str = file_date.strftime("%Y-%m-%d")
                all_decisions.append((date_str, decisions))

    if not all_decisions:
        print("[INFO] No key decisions found in recent logs to update MEMORY.md")
        return

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    section_header = "## 关键决策索引"
    if section_header not in content:
        content += f"\n\n{section_header}\n*按时间倒序排列。*\n\n"

    # Determine insertion point
    parts = content.split(section_header, 1)
    after_header = parts[1]
    next_section_match = re.search(r"\n##\s+", after_header)
    insert_pos = next_section_match.start() if next_section_match else len(after_header)

    new_entries = []
    for date_str, decisions in all_decisions:
        # Avoid duplicating entries that already exist for this date
        if f"### {date_str}" in after_header:
            continue
        new_entries.append(f"### {date_str}")
        for d in decisions:
            new_entries.append(f"- {d}")
        new_entries.append("")

    if not new_entries:
        print("[INFO] All recent decisions already present in MEMORY.md")
        return

    updated_after = after_header[:insert_pos] + "\n" + "\n".join(new_entries) + after_header[insert_pos:]
    updated_content = parts[0] + section_header + updated_after

    with open(path, "w", encoding="utf-8") as f:
        f.write(updated_content)

    total_decisions = sum(len(d[1]) for d in all_decisions)
    print(f"[OK] Updated MEMORY.md with {total_decisions} decision(s) from {len(all_decisions)} day(s)")


def clean_temp_files(base_dir, scattered_dir, temp_file_days):
    cleaned = 0
    paths_to_check = [
        sanitize_path(os.path.join(base_dir, scattered_dir)),
    ]

    for path in paths_to_check:
        if not os.path.exists(path):
            continue
        try:
            # Safe: only list files older than N days
            output = run_cmd([
                "find", path, "-type", "f",
                "-mtime", f"+{temp_file_days}",
                "-print"
            ])
            if output:
                for fpath in output.splitlines():
                    # Additional safety: verify the path is within expected directory
                    if os.path.exists(fpath) and fpath.startswith(path):
                        os.remove(fpath)
                        cleaned += 1
                        print(f"[CLEAN] Removed temp file: {fpath}")
        except Exception as e:
            print(f"[WARN] Failed to clean {path}: {e}", file=sys.stderr)

    return cleaned


def main():
    print("=== heartbeat_memory_check start ===")

    config = load_config()
    
    # 安全处理 base_dir
    try:
        base_dir = sanitize_path(config["paths"]["base_dir"])
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)
    
    memory_dir = config["paths"]["memory_dir"]
    archived_dir = config["paths"]["memory_archived_dir"]
    scattered_dir = config["paths"]["scattered_dir"]
    memory_file = config["paths"]["memory_file"]
    retention = config["retention"]

    # 1. Check volume
    size_mb, file_count = check_memory_volume(base_dir, memory_dir)
    print(f"[STAT] memory/ size: {size_mb:.2f} MB, files: {file_count}")

    # 2. Extract recent decisions to MEMORY.md BEFORE archiving old logs
    update_memory_md_with_recent(base_dir, memory_file, retention["recent_decision_days"], memory_dir)

    # 3. Archive old logs
    moved = archive_old_logs(base_dir, memory_dir, archived_dir, retention["memory_log_days"])
    print(f"[STAT] Archived {moved} old log file(s)")

    # 4. Clean temp files
    cleaned = clean_temp_files(base_dir, scattered_dir, retention["temp_file_days"])
    print(f"[STAT] Cleaned {cleaned} temp file(s)")

    print("=== heartbeat_memory_check complete ===")


if __name__ == "__main__":
    main()
