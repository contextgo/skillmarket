---
name: memory-triad
version: 0.1.0
author: OpenClaw Community
description: "自动化三层记忆管理：LCM 会话内压缩、CC 跨会话归档、MEMORY.md 长期索引维护。"
tags:
  - memory
  - context-compaction
  - lcm
  - archiving
  - agent-tools
keywords:
  - memory triad
  - context compaction
  - LCM
  - session archive
  - memory management
categories:
  - agent-tools
  - workflow
metadata:
  {
    "openclaw":
      {
        "emoji": "🧠",
        "requires": { "bins": ["memory-triad"], "openclaw": ">=2.13.0" },
        "recommends": { "plugin": "lossless-claw" },
        "install":
          [
            {
              "id": "clawhub",
              "kind": "clawhub",
              "package": "memory-triad",
              "label": "Install via clawhub",
            },
          ],
      },
  }
---

# memory-triad

自动化 AI 助手记忆的**归档与索引流水线**。将会话结束、心跳、LCM 检查三种时机串联，维持三层记忆架构（L1 LCM / L2 CC / L3 MEMORY.md）的自动落盘与清理。

## 触发场景

- 你想让助手在**每次会话结束前**自动执行 context compaction，不再依赖手动复制粘贴。
- 你需要通过**心跳任务**定期整理 memory 目录、归档过期日志、更新 MEMORY.md 索引。
- 你想**检测 LCM 状态**，在上下文压缩导致信息丢失前主动 flush 关键决策到长期记忆。
- 你受够了 manually curate `memory/YYYY-MM-DD.md` 和 `MEMORY.md`，希望把 80% 的繁琐工作交给自动化。

## 安装

### 方式一：clawhub（推荐）
```bash
clawhub install memory-triad
```

### 方式二：手动解压
```bash
unzip memory-triad.zip -d ~/.openclaw/workspace/skills/memory-triad/
```

## 初始化

安装后必须运行一次初始化脚本，创建工作区目录结构和默认模板：

```bash
python3 ~/.openclaw/workspace/skills/memory-triad/setup_workspace.py
```

该脚本会检查 OpenClaw 版本、探测 LCM 插件状态，并在无 LCM 时降级为纯文件归档模式。

## 依赖

- **兼容标准 AI Agent 环境**（需要 `lcm_grep` / `lcm_expand` / `lcm_describe` 命令可用）
- **推荐：lossless-claw / LCM 插件**（提供 DAG 无损压缩与展开能力）
- **无 LCM 时自动降级**：直接基于 Claude Code 5 部分模板生成文本摘要，跳过 DAG 操作。

## 三种用法

### 1. 会话结束 flush（Context Compaction）
在会话结束时自动执行：
1. 读取 `templates/context_compaction_template.md`；
2. 生成任务概述、当前状态、重要发现、下一步、需保留上下文 5 部分摘要（CC 格式）；
3. 追加到 `memory/YYYY-MM-DD.md`；
4. 更新 `MEMORY.md` 关键决策索引；
5. 若检测到上下文被 LCM 压缩，提取压缩摘要并展开回填提示。

调用方式：
```bash
memory-triad flush
```

### 2. 心跳维护（Heartbeat Maintenance）
适合放在 `HEARTBEAT.md` 或 cron 中，每天执行 1–2 次：
- 归档 7 天前的日志到 `memory/archived/`；
- 压缩大于 100 KB 的 markdown 日志；
- 扫描近 3 日 memory 文件，自动提取关键决策并合并写入 `MEMORY.md`；
- 清理重复/已失效的上下文。

调用方式：
```bash
memory-triad heartbeat
```

### 3. LCM 检查（Compression Audit）
主动检测当前会话是否触发了 LCM compaction：
- 若存在被压缩的上下文，展开被 summary 的节点，确认关键信息是否已落盘到 L2/L3；
- 若未落盘，触发自动 flush 或告警。

调用方式：
```bash
memory-triad audit
```

## 故障排查 Q&A

**Q1: 运行 `memory-triad flush` 时提示 `lcm_grep: command not found`？**
A: 你的 OpenClaw 版本低于 2.13，或未安装 LCM 插件。脚本会自动降级为文件模式，但建议升级 OpenClaw 或安装 `lossless-claw` 以获得完整功能。

**Q2: 心跳任务执行后，`MEMORY.md` 出现了重复条目？**
A: 检查 heartbeat 的调度频率。`heartbeat` 命令内置了 24h 去重窗口，若你在同一窗口内多次手动触发，可带上 `--dedup` 参数或降低频率。

**Q3: 如何让 flush 在每次会话结束时自动触发？**
A: 无需额外配置。OpenClaw 2.13+ 会在会话关闭前自动调用当前 workspace `skills/` 目录下注册的 `on_session_end` hook。安装本 skill 后该 hook 已自动注册。

**Q4: LCM 展开后信息仍然缺失？**
A: LCM 的 DAG 压缩是**有损摘要**，不是数据库备份。本 skill 的设计目标是在压缩发生前把关键决策提前写到 L3（MEMORY.md）。若已发生压缩且摘要不包含你需要的细节，说明该细节在压缩时未被算法保留，无法逆向恢复。解决方案：在重要对话中途手动执行 `memory-triad flush`。

**Q5: 自动生成的 CC 摘要质量不够好？**
A: 编辑 `templates/context_compaction_template.md` 调整 prompt 和权重。该模板是用户可覆盖文件，不会被 skill 更新覆盖。
