## 关键文件路径

```
~/.openclaw/workspace/
├── SOUL.md               # 身份层
├── USER.md               # 用户层
├── AGENTS.md             # 系统层
├── TOOLS.md              # 工具层
├── MEMORY.md             # 长期记忆（仅主会话）
├── HEARTBEAT.md          # 心跳任务定义
├── ACTIVE-TASKS.md       # 活跃任务索引
├── memory/
│   ├── YYYY-MM-DD.md     # 每日记忆
│   ├── heartbeat-state.json
│   └── lessons-learned.md
├── memlib/
│   ├── cortex-core-interface.md
│   ├── per-message-writeback-rule.md
│   └── session-wrapup-trigger-rule.md
└── projects/
    └── <slug>/
        └── progress.md
```
