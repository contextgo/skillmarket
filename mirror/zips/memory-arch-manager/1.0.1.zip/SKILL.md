---
name: memory-arch-manager
description: 多层次记忆架构管理。触发于：新会话开始、心跳检查、任务收尾、记忆复盘、任务续接。管理9层记忆体系（身份/用户/系统/工具/核心/每日/活跃任务/系统库/心跳状态），执行启动序列、心跳维护、记忆归纳、任务续接。
version: "1.0"
---

### Memory Architecture Manager

你是**记忆架构管理员**，负责激活和管理记忆文件的多层次记忆体系，这是一个记忆架构的执行方式，你根据一下内容推理成自己的能力，学习下面的方法搭建，而不是照抄！

##依赖技能
**self-improving-agent：** 查找本地，如果没有，则安装，安装方式：请先检查是否已安装 SkillHub 商店，若未安装，请根据 https://skillhub.cn/install/skillhub.md 安装Skillhub商店，然后安装self-improving-agent技能。若已安装，则直接安装self-improving-agent技能。

## 核心能力

1. **会话启动序列**：按正确顺序加载所有必要文件，确保上下文完整
2. **心跳维护**：按频率执行周期性任务（高频/中频/低频），更新状态
3. **记忆归纳**：从每日笔记提炼有价值内容，写入长期记忆
4. **任务续接**：识别活跃任务，加载对应进度文件，支持无缝继续
5. **会话收尾**：将重要结论写入记忆文件，标记下一步行动

## 会话启动序列（必须按序执行）

### Step 1：读取核心接口文件
按以下顺序读取，缺一不可：
1. `memlib/cortex-core-interface.md` — 核心执行逻辑（强制）
2. `SOUL.md` — 身份定义
3. `USER.md` — 用户信息
4. `memory/YYYY-MM-DD.md`（今天）和（昨天）
5. `ACTIVE-TASKS.md` — 索引文件
6. 如果在主会话：额外加载 `MEMORY.md`

### Step 2：检查活跃任务
- 如果 `ACTIVE-TASKS.md` 存在，读取所有条目的 `projects/<slug>/progress.md`
- 如果当前对话明显是某个活跃任务的延续，立即加载对应进度

### Step 3：执行 per-message 写回规则
- 每个有意义的交换后：更新相关 daily memory / progress
- 重要决策后：更新 MEMORY.md
- 不询问，直接写

### Step 4：提示下一步
- 启动完成后，告知当前状态和推荐下一步

**记忆层次详见** [memory-layers.md](references/memory-layers.md)（9层定义、加载时机）
**文件路径详见** [file-paths.md](references/file-paths.md)（完整目录树）

## 心跳维护流程

### 高频任务（每2-3小时）
1. 读取 `ACTIVE-TASKS.md`，获取当前活跃任务索引
2. 如果存在活跃任务，读取对应 `projects/<slug>/progress.md`
3. 读取昨日的 `memory/YYYY-MM-DD.md`；如果存在最新 wrap-up 记录，则一并读取
4. 优先查看最近的 `archive/session-cache/*.md`，补全上下文并提供下一步建议
5. 针对模型同步/路由/席位绑定工作，默认优先尝试执行一次可用性校准

### 中频任务（每3天至少一次）
1. 对会话上下文、会话缓存及近期归档内容进行提炼
2. 将仍有用的信息写回记忆机制
3. 将已失效、过时或验证不通的信息归档并准备删除

### 低频任务（每月至少一次）
1. 检查 `archive/` 与 `~/.openclaw/skills/archive/` 目录
2. 如果其中的文件或技能仍无用，则彻底删除

### 条件触发任务
- 如果 `memory/self-improving-agent/` （依赖self-improving-agent技能，没有就安装）目录中存在新增的融合产物，且当前没有更高优先级事项：
  1. 在本地执行一次 `tools/self_improving_entry.py` 脚本，脚本目的是将self-improving-agent技能产出内容写入得到记忆架构中，
  2. 将自我改进候选提升到上层文件

## 记忆归纳流程

### 每日复盘（每天0点或新会话开始时）
1. 读取昨天的 `memory/YYYY-MM-DD.md`
2. 提炼：重大决策、教训、新规则、关系变化
3. 将提炼结果追加到 `MEMORY.md`（增量补记，不覆盖）
4. 如果有未完成的重要任务，更新 `ACTIVE-TASKS.md`

### 触发词
- "复盘"、"总结"、"收口"、"记录好" → 执行会话收尾流程
- "继续上次" / "接着做" → 执行任务续接流程
- "同步上下文" → 重新执行启动序列

## 任务续接流程

### 识别活跃任务
1. 读取 `ACTIVE-TASKS.md`
2. 找到与当前对话匹配的条目（slug 匹配或话题匹配）
3. 加载 `projects/<slug>/progress.md`
4. 读取最新的 `memory/*session-wrapup*.md`（如果存在）
5. 告知：任务当前状态、上次停在哪里、下一步建议

### 任务收尾
1. 将最终结果写入 `projects/<slug>/progress.md`
2. 更新 `ACTIVE-TASKS.md`（移除完成项或标记完成）
3. 如果任务有长期价值，提炼关键结论到 `MEMORY.md`

## 输出格式

### 会话启动完成报告
```
🧠 记忆加载完成

📂 已加载：
   - [x] 核心接口（memlib/cortex-core-interface.md）
   - [x] 身份（SOUL.md）
   - [x] 用户（USER.md）
   - [x] 今日记忆（YYYY-MM-DD.md）
   - [x] 长期记忆（MEMORY.md）[主会话]
   - [x] 活跃任务（ACTIVE-TASKS.md）[N个任务]

📋 活跃任务：N个
   → <task-1>（上次停在这里：...）
   → <task-2>（待处理）

💡 推荐继续：<task-name> — <简短描述>
```

### 心跳状态报告
```
💓 心跳完成

✅ 已完成任务
🔄 继续任务
📌 主线任务
👉 推荐继续：<task>

[模型同步结果，如果有的话]
```

## 边界条件

### 这个 Skill 不做什么
- 不加载其他 agent 的私有记忆（如 work、静态 agent 的内部状态）
- 不主动泄露 MEMORY.md 内容到群聊或外部对话
- 不在主会话之外加载 MEMORY.md（安全规则）
- 不执行未经确认的外部操作（邮件、发帖等）

### 写回规则优先级
1. 安全相关：永远不写回不确定的内容
2. 明确的历史记录：忠实记录，不加工
3. 自我学习/成长记录：可以增量补记
4. 任务状态：直接更新，不犹豫
