---
name: project-review-checklist
description: Execute a production-ready code review checklist for this Vue 3 + TypeScript + Vite project. Use when the user asks for review, self-check before commit, pre-merge quality gate, risk scan, or "按规范检查" style requests.
---

# Project Review Checklist

## Scope

Use this skill to run an actionable review for changed code in this repository.
Focus on correctness, regression risk, type safety, reactivity safety, maintainability, and release readiness.

## Required Review Output

Return findings in this order:

1. `Critical` - must fix before merge
2. `Major` - high-priority fixes
3. `Minor` - improvements and consistency issues
4. `Test Gaps` - missing validation cases
5. `Pass Summary` - only after listing findings

If no findings exist, explicitly state: `No blocking findings`.

## Execution Workflow

Copy this checklist and mark progress:

```text
Review Progress
- [ ] Step 1: Collect diff context
- [ ] Step 2: Run correctness and regression scan
- [ ] Step 3: Run Vue 3 + TS rule scan
- [ ] Step 4: Run UI and style consistency scan
- [ ] Step 5: Run testing and risk scan
- [ ] Step 6: Produce structured findings
```

### Step 1: Collect diff context

- Identify changed files first, then review the changed hunks.
- Prioritize files in `src/views`, `src/components`, `src/composables`, `src/router`.
- Keep comments tied to concrete code locations and behavior impact.

### Step 2: Correctness and regression scan

Check:

- API response shape assumptions without guards
- Async race conditions and stale state updates
- Missing loading/error/empty states
- Unhandled promise rejections
- Silent failures in `try/catch` that hide user impact
- Route guard and permission regressions

Block merge if business flow can break under partial/empty API data.

### Step 3: Vue 3 + TypeScript rule scan

Check against project conventions:

- Use `<script setup lang="ts">`; avoid Options API and mixins
- `ref` for primitive/single values, `reactive` for structured objects
- No implicit `any`; avoid `any` in composable returns
- Injected values must have types and fallback handling
- Avoid reactivity loss from direct destructuring of reactive objects
- Watch usage is justified; avoid expensive or duplicate watchers

Report each issue with: violated rule + risk + suggested fix.

### Step 4: UI and style consistency scan

Check:

- Semantic HTML usage (`button`, `input`, `img`) before generic `div`
- Repeated structures extracted with `v-for` where applicable
- Styles in `<style scoped lang="scss">`, avoid broad global leakage
- BEM naming consistency
- No unnecessary DOM nesting
- Skeleton/empty/error presentation consistency with shared components

### Step 5: Testing and risk scan

Check:

- Does the change include test updates for new behavior?
- Are edge cases covered (null/undefined/empty array/permission denied)?
- Is there a manual verification path for UI interactions and async failures?

If tests are missing, provide a minimal test checklist.

## Finding Template

Use this template for each issue:

```markdown
- Severity: Critical | Major | Minor
- Location: `path/to/file`
- Problem: One-line behavior risk statement
- Why it matters: User/business impact
- Suggested fix: Concrete and minimal change
```

## No-Finding Template

When no actionable issue is found, output:

```markdown
No blocking findings.

Residual risks:
- [List any low-confidence assumptions]

Suggested verification:
- [Manual or automated checks to run]
```

## Review Priorities For This Project

Always prioritize these risk classes first:

1. Runtime crashes from unguarded API fields
2. Type safety regressions (`any`, unchecked cast, missing null checks)
3. Reactivity bugs causing stale UI or non-updating views
4. Dialog/detail page state inconsistencies
5. Missing error fallback that blocks key user paths
