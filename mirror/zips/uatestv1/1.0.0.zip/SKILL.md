---
name: url-cloaking-detector
description: 使用多种User-Agent（爬虫/桌面/移动/裸客户端）请求同一URL并对比响应内容差异，自动识别UA差异化投放行为；当用户需要检测网站隐藏违规内容、验证页面是否存在UA伪装、排查搜索引擎与用户看到内容不一致时使用
dependency:
  python:
    - requests==2.32.3
    - beautifulsoup4==4.12.3
---

# URL 伪装检测器

## 任务目标
- 本 Skill 用于：检测目标 URL 是否针对不同 User-Agent 返回差异化内容，识别隐藏违规内容的伪装行为
- 能力包含：多 UA 并行请求、内容哈希对比、重定向差异分析、风险等级评估
- 触发条件：用户提供一个或多个 URL，要求检测是否存在隐藏/伪装内容，或排查搜索引擎收录与实际页面内容不一致的情况

## 前置准备
- Python 依赖：`requests`、`beautifulsoup4`
- 确保网络可访问目标 URL

## 操作步骤

### 1. 执行多 UA 请求
调用脚本对目标 URL 发起多 UA 请求，收集各 UA 下的响应：

```
python scripts/fetch_multi_ua.py --url "https://example.com" --timeout 15 --delay 0.5
```

**参数说明**：
- `--url`（必填）：目标 URL，支持 http/https，缺少协议时自动补 http
- `--timeout`（可选）：单次请求超时秒数，默认 15
- `--delay`（可选）：请求间隔秒数，默认 0.5（避免触发限流）
- `--ua-filter`（可选）：指定 UA 子集，逗号分隔，如 `googlebot,chrome_desktop`

**可用 UA 名称**：`googlebot` `bingbot` `baiduspider` `chrome_desktop` `firefox_desktop` `safari_mac` `chrome_android` `safari_ios` `curl` `python_requests` `empty_ua`

### 2. 分析差异结果
脚本输出 JSON，重点关注：

- **diff_summary.risk_level**：风险等级（`none`/`low`/`medium`/`high`）
- **diff_summary.has_content_difference**：是否存在内容差异
- **diff_summary.hash_groups**：按内容哈希分组，同一组表示内容相同
- **diff_summary.status_groups**：按状态码分组
- **diff_summary.redirect_groups**：按重定向目标分组
- **diff_summary.title_groups**：按页面标题分组
- **diff_summary.text_similarity_pairs**：UA 对间的文本相似度，低值表示内容差异大

### 3. 深入排查（智能体分析）
根据脚本返回的差异摘要，智能体执行以下分析：

- 若爬虫 UA 与浏览器 UA 内容不同：网站可能对搜索引擎展示合规内容，对用户展示违规内容（或反之）
- 若移动端与桌面端内容不同：可能存在移动端专属违规投放
- 若存在空 UA 被拦截/重定向：网站可能过滤非浏览器请求
- 读取 `content_snippet` 或 `plain_text_snippet`，识别具体违规内容（赌博、色情、诈骗等关键词）
- 对比 `redirect_groups`，判断是否存在 UA 针对性跳转

### 4. 输出检测报告
生成结构化报告，包含：
- 目标 URL 与检测时间
- 各 UA 响应概览（状态码、内容长度、标题）
- 差异发现（内容/状态码/重定向/标题的组别差异）
- 风险等级与判定依据
- 可疑违规内容摘录（如有）

## 使用示例

- 示例1：
  - 场景/输入：用户提供一个可疑网站 URL，要求检测是否存在隐藏违规内容
  - 预期产出：多 UA 请求结果 + 差异分析报告，标注风险等级和可疑内容
  - 关键要点：关注爬虫 UA 与浏览器 UA 的内容差异，这是最常见的伪装模式

- 示例2：
  - 场景/输入：用户发现搜索引擎收录的页面标题与实际访问不一致，要求排查原因
  - 预期产出：对比 `googlebot`/`baiduspider` 与 `chrome_desktop` 的响应，定位差异点
  - 关键要点：重点对比 `page_title` 和 `plain_text_snippet`，判断是否为 UA 针对性投放

- 示例3：
  - 场景/输入：用户只想快速检查爬虫视角的内容，不需要全量 UA 对比
  - 预期产出：仅爬虫 UA 的响应内容
  - 关键要点：使用 `--ua-filter googlebot,bingbot,baiduspider` 缩小检测范围

## 资源索引
- 脚本：见 [scripts/fetch_multi_ua.py](scripts/fetch_multi_ua.py)（使用多种 UA 请求 URL 并对比响应差异；参数：`--url` 必填，`--timeout`/`--delay`/`--ua-filter` 可选）

## 注意事项
- 请求间隔默认 0.5 秒，避免触发目标站点限流；目标站点响应慢时可增大 `--timeout`
- 脚本自动跟随重定向（`allow_redirects=True`），重定向目标会记录在 `redirect_url` 和 `redirect_history` 中
- `content_snippet` 截取前 2000 字符，`plain_text_snippet` 截取前 1500 字符纯文本，足够初步判断
- 风险等级仅基于自动化指标，最终判定需智能体结合内容语义分析
- 部分网站可能基于 IP/地区/ Cookie 等其他维度做差异化投放，UA 维度未检出不代表完全无伪装
