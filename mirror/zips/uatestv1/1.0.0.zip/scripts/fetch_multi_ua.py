#!/usr/bin/env python3
"""
使用多种 User-Agent 请求同一 URL，收集并对比响应内容，
用于检测网站是否存在 UA 差异化投放（隐藏违规内容）行为。
"""

import argparse
import hashlib
import json
import re
import sys
import time
import warnings
from urllib.parse import urlparse

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

import requests
from bs4 import BeautifulSoup

# ============================================================
# UA 列表：覆盖搜索引擎爬虫、桌面浏览器、移动浏览器、裸客户端
# ============================================================
USER_AGENTS = {
    "googlebot": "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "bingbot": "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "baiduspider": "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)",
    "chrome_desktop": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "firefox_desktop": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "safari_mac": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "chrome_android": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "safari_ios": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "curl": "curl/8.7.1",
    "python_requests": "python-requests/2.32.3",
    "empty_ua": "",
}


def fetch_with_ua(url: str, ua_name: str, ua_string: str, timeout: int) -> dict:
    """使用指定 UA 请求 URL，返回响应信息。"""
    headers = {"User-Agent": ua_string} if ua_string else {}
    try:
        resp = requests.get(
            url,
            headers=headers,
            timeout=timeout,
            allow_redirects=True,
            verify=False,
        )
        content = resp.text
        content_bytes = resp.content
        content_hash = hashlib.md5(content_bytes).hexdigest()

        # 提取纯文本（去 HTML 标签）
        try:
            soup = BeautifulSoup(content, "html.parser")
            # 移除 script / style
            for tag in soup(["script", "style"]):
                tag.decompose()
            plain_text = soup.get_text(separator=" ", strip=True)
        except Exception:
            plain_text = ""

        # 提取页面 title
        try:
            soup_full = BeautifulSoup(content, "html.parser")
            title_tag = soup_full.find("title")
            page_title = title_tag.get_text(strip=True) if title_tag else ""
        except Exception:
            page_title = ""

        # 重定向链
        redirect_url = resp.url if resp.url != url else ""
        redirect_history = [r.url for r in resp.history] if resp.history else []

        return {
            "ua_name": ua_name,
            "status_code": resp.status_code,
            "content_length": len(content_bytes),
            "content_hash": content_hash,
            "content_snippet": content[:2000] if content else "",
            "plain_text_snippet": plain_text[:1500] if plain_text else "",
            "page_title": page_title,
            "redirect_url": redirect_url,
            "redirect_history": redirect_history,
            "content_type": resp.headers.get("Content-Type", ""),
            "error": None,
        }
    except requests.exceptions.Timeout:
        return {"ua_name": ua_name, "status_code": None, "error": "timeout"}
    except requests.exceptions.TooManyRedirects:
        return {"ua_name": ua_name, "status_code": None, "error": "too_many_redirects"}
    except requests.exceptions.ConnectionError as e:
        return {"ua_name": ua_name, "status_code": None, "error": f"connection_error: {str(e)[:200]}"}
    except Exception as e:
        return {"ua_name": ua_name, "status_code": None, "error": f"unknown_error: {str(e)[:200]}"}


def compute_diff_summary(results: list) -> dict:
    """对比各 UA 响应，生成差异摘要。"""
    successful = [r for r in results if r.get("status_code") is not None and r.get("error") is None]
    if len(successful) < 2:
        return {"can_compare": False, "reason": "successful responses < 2"}

    # 按内容哈希分组
    hash_groups = {}
    for r in successful:
        h = r["content_hash"]
        if h not in hash_groups:
            hash_groups[h] = []
        hash_groups[h].append(r["ua_name"])

    # 按状态码分组
    status_groups = {}
    for r in successful:
        s = r["status_code"]
        if s not in status_groups:
            status_groups[s] = []
        status_groups[s].append(r["ua_name"])

    # 重定向差异
    redirect_diff = {}
    for r in successful:
        key = r.get("redirect_url") or "no_redirect"
        if key not in redirect_diff:
            redirect_diff[key] = []
        redirect_diff[key].append(r["ua_name"])

    # 标题差异
    title_diff = {}
    for r in successful:
        key = r.get("page_title") or "no_title"
        if key not in title_diff:
            title_diff[key] = []
        title_diff[key].append(r["ua_name"])

    # 找出内容差异最大的 UA 对（基于纯文本片段）
    text_pairs_diff = []
    for i in range(len(successful)):
        for j in range(i + 1, len(successful)):
            t1 = successful[i].get("plain_text_snippet", "")
            t2 = successful[j].get("plain_text_snippet", "")
            if t1 and t2:
                # 简单字符级差异率
                max_len = max(len(t1), len(t2), 1)
                common = sum(1 for a, b in zip(t1, t2) if a == b)
                similarity = common / max_len
                text_pairs_diff.append({
                    "ua_pair": f"{successful[i]['ua_name']} vs {successful[j]['ua_name']}",
                    "similarity": round(similarity, 4),
                })

    content_variants = len(hash_groups)
    has_content_diff = content_variants > 1
    has_status_diff = len(status_groups) > 1
    has_redirect_diff = len(redirect_diff) > 1
    has_title_diff = len(title_diff) > 1

    # 风险等级评估
    risk_indicators = 0
    if has_content_diff:
        risk_indicators += 2
    if has_status_diff:
        risk_indicators += 2
    if has_redirect_diff:
        risk_indicators += 1
    if has_title_diff:
        risk_indicators += 1

    if risk_indicators >= 4:
        risk_level = "high"
    elif risk_indicators >= 2:
        risk_level = "medium"
    elif risk_indicators >= 1:
        risk_level = "low"
    else:
        risk_level = "none"

    return {
        "can_compare": True,
        "content_variants": content_variants,
        "has_content_difference": has_content_diff,
        "has_status_code_difference": has_status_diff,
        "has_redirect_difference": has_redirect_diff,
        "has_title_difference": has_title_diff,
        "hash_groups": {k: v for k, v in hash_groups.items()},
        "status_groups": {str(k): v for k, v in status_groups.items()},
        "redirect_groups": redirect_diff,
        "title_groups": title_diff,
        "text_similarity_pairs": sorted(text_pairs_diff, key=lambda x: x["similarity"])[:10],
        "risk_level": risk_level,
        "risk_indicators_score": risk_indicators,
    }


def main():
    parser = argparse.ArgumentParser(
        description="使用多种 User-Agent 请求同一 URL，对比响应内容差异"
    )
    parser.add_argument("--url", required=True, help="目标 URL")
    parser.add_argument("--timeout", type=int, default=15, help="请求超时秒数（默认15）")
    parser.add_argument("--delay", type=float, default=0.5, help="每次请求间隔秒数（默认0.5）")
    parser.add_argument(
        "--ua-filter",
        type=str,
        default="",
        help="只使用指定UA，逗号分隔（如 googlebot,chrome_desktop）。留空则使用全部UA",
    )
    args = parser.parse_args()

    url = args.url
    if not re.match(r"^https?://", url):
        url = "http://" + url

    # 筛选 UA
    ua_map = dict(USER_AGENTS)
    if args.ua_filter:
        selected = [u.strip() for u in args.ua_filter.split(",") if u.strip()]
        ua_map = {k: v for k, v in ua_map.items() if k in selected}
        if not ua_map:
            print(json.dumps({"status": "error", "message": f"无有效UA，可用: {list(USER_AGENTS.keys())}"}, ensure_ascii=False))
            sys.exit(1)

    results = []
    for ua_name, ua_string in ua_map.items():
        result = fetch_with_ua(url, ua_name, ua_string, args.timeout)
        results.append(result)
        if args.delay > 0:
            time.sleep(args.delay)

    diff_summary = compute_diff_summary(results)

    output = {
        "status": "success",
        "url": url,
        "total_ua_count": len(ua_map),
        "successful_count": sum(1 for r in results if r.get("error") is None),
        "failed_count": sum(1 for r in results if r.get("error") is not None),
        "results": results,
        "diff_summary": diff_summary,
    }

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
