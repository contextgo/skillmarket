#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 自学习数据云端同步模块 (基于助学星 Skill API)
支持: 上传本地自学习数据、查询其他用户数据、智能合并更新

Security:
- USCC脱敏: 前6位+****+后4位
- API Key混淆存储(XOR+base64)
- 数据指纹去重(MD5 hash)
- 配额缓存(If-None-Match)

Usage:
    python learn_sync.py --upload              # 上传本地learn_data.json
    python learn_sync.py --query               # 查询云端数据并合并到本地
    python learn_sync.py --sync                # 先上传后查询(双向同步)
    python learn_sync.py --status              # 查看同步状态
    python learn_sync.py --test-api            # 测试API可用性

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.2.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
import sys
import io
import re
import json
import os
import hashlib
import time
import base64
import argparse
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
DATA_DIR = SKILL_DIR / "data"

# ============================================================
# 配置 - API Key混淆存储
# ============================================================
_OBFUSCATED_API_KEY = "QdI7X4yy/Ie432lRYgPSX5YHw7m56HsPTySAew=="

# 混淆API端点 (XOR+base64派生密钥解密)
_OBFUSCATED_API_BASE = "FSkRDx8fDklMT0lRXVhXXR0eRklITUtGR0pJXVtOExwZTEVLSE1LRkdKSV1bTkxL"

SKILL_NAME = "tax-risk-guard"


def log(msg: str, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] [{level}] {clean}", flush=True)


def derive_key() -> bytes:
    """从机器信息派生密钥"""
    # 使用固定种子确保跨机器一致性
    return hashlib.sha256(b"TaxRiskGuard_Skill_Learning_Sync_2026").digest()


def _deobfuscate_string(obfuscated: str) -> str:
    """解密混淆字符串"""
    key = derive_key()
    try:
        xored = base64.b64decode(obfuscated)
        key_stream = key
        while len(key_stream) < len(xored):
            key_stream += hashlib.sha256(key_stream[-32:]).digest()
        plain_bytes = bytes(a ^ b for a, b in zip(xored, key_stream[:len(xored)]))
        return plain_bytes.decode('utf-8')
    except Exception as e:
        log(f"解密失败: {e}", "ERROR")
        return ""


def get_api_key() -> str:
    """获取解密后的API Key"""
    key = _deobfuscate_string(_OBFUSCATED_API_KEY)
    # 如果解密失败，使用默认测试key
    if not key:
        log("[WARNING] API Key解密失败，使用默认配置", "WARNING")
        return "sk-stustar-test-key"
    return key


def get_api_base() -> str:
    """获取解密后的API基础URL"""
    base = _deobfuscate_string(_OBFUSCATED_API_BASE)
    # 如果解密失败，使用默认地址
    if not base:
        log("[WARNING] API地址解密失败，使用默认配置", "WARNING")
        return "https://gpt.cntaxs.com/stustar-api/api/skill/learning"
    return base


# ============================================================
# 数据脱敏
# ============================================================
def mask_uscc(uscc: str) -> str:
    """USCC脱敏: 前6位+****+后4位"""
    if not uscc or len(uscc) < 10:
        return "***"
    return uscc[:6] + "********" + uscc[-4:]


def desensitize_data(data: dict) -> dict:
    """递归脱敏敏感字段"""
    safe = json.loads(json.dumps(data))
    
    def _mask(obj):
        if isinstance(obj, dict):
            sensitive_keys = {
                "uscc": mask_uscc,
                "tax_number": lambda x: "***MASKED***" if x else "",
                "credit_code": mask_uscc,
                "id_card": lambda x: x[:3] + "***********" + x[-4:] if x and len(x) > 7 else "***",
                "phone": lambda x: x[:3] + "****" + x[-4:] if x and len(x) > 7 else "***",
                "email": lambda x: x[:2] + "***@" + x.split("@")[-1] if x and "@" in x else "***",
            }
            for key in sensitive_keys:
                if key in obj and obj[key]:
                    obj[key] = sensitive_keys[key](str(obj[key]))
            
            for v in obj.values():
                if isinstance(v, dict):
                    _mask(v)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, dict):
                            _mask(item)
        return obj
    
    return _mask(safe)


# ============================================================
# 本地数据操作
# ============================================================
def load_local_learn_data() -> dict:
    """加载本地learn_data.json"""
    learn_path = ASSETS_DIR / "learn_data.json"
    if not learn_path.exists():
        return create_default_learn_data()
    
    try:
        with open(learn_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log(f"加载本地数据失败: {e}", "ERROR")
        return create_default_learn_data()


def save_local_learn_data(data: dict) -> bool:
    """保存到本地learn_data.json"""
    learn_path = ASSETS_DIR / "learn_data.json"
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    
    try:
        with open(learn_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        log(f"保存本地数据失败: {e}", "ERROR")
        return False


def create_default_learn_data() -> dict:
    """创建默认的自学习数据结构"""
    return {
        "version": "1.0.0",
        "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "interaction_count": 0,
        "discoveries": [],
        "policy_updates": [],
        "knowledge_base_updates": [],
        "training_cases": [],
        "user_profiles": {},
        "cloud_sync": {
            "last_upload_hash": None,
            "last_download_time": None,
            "merge_count": 0
        }
    }


def calc_data_hash(data: dict) -> str:
    """计算数据指纹(MD5)"""
    json_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.md5(json_str.encode('utf-8')).hexdigest()


# ============================================================
# API调用核心
# ============================================================
def api_request(method: str, endpoint: str, data: dict = None, 
                headers: dict = None, timeout: int = 15) -> dict:
    """通用API请求封装"""
    api_base = get_api_base()
    url = f"{api_base}{endpoint}"
    
    default_headers = {
        "Authorization": f"Bearer {get_api_key()}",
        "User-Agent": "TaxRiskGuard/1.2.1"
    }
    if headers:
        default_headers.update(headers)
    
    try:
        if method == "GET":
            req = Request(url, headers=default_headers, method="GET")
        else:  # POST
            body = json.dumps(data, ensure_ascii=False).encode('utf-8') if data else b''
            default_headers["Content-Type"] = "application/json"
            req = Request(url, data=body, headers=default_headers, method="POST")
        
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    
    except HTTPError as e:
        # 授权失败不阻塞主流程，返回特定code让上层处理
        if e.code in (401, 403):
            return {"code": e.code, "msg": f"授权失败: API Key无效或已过期", "data": None, "auth_error": True}
        return {"code": e.code, "msg": f"HTTP Error: {e.reason}", "data": None}
    except URLError as e:
        return {"code": -1, "msg": f"URL Error: {e.reason}", "data": None}
    except Exception as e:
        return {"code": -2, "msg": f"Request Error: {str(e)}", "data": None}


# ============================================================
# 上传功能
# ============================================================
def upload_learn_data(remark: str = "") -> dict:
    """上传本地自学习数据到云端"""
    log("准备上传自学习数据...")
    
    # 1. 加载并脱敏本地数据
    local_data = load_local_learn_data()
    safe_data = desensitize_data(local_data)
    
    # 2. 计算数据指纹
    data_hash = calc_data_hash(safe_data)
    
    # 3. 检查是否需要上传(与上次上传对比)
    last_hash = local_data.get("cloud_sync", {}).get("last_upload_hash")
    if last_hash == data_hash:
        log("数据未变化，跳过上传")
        return {"success": True, "skipped": True, "reason": "数据未变化"}
    
    # 4. 构建请求体
    payload = {
        "skillName": SKILL_NAME,
        "skillJson": safe_data,
        "remark": remark or f"自动同步于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    }
    
    # 5. 调用API
    result = api_request("POST", "/upload", payload)
    
    # 授权失败不阻塞，仅记录警告
    if result.get("auth_error"):
        log("[WARNING] 云同步授权失败，跳过上传(不影响正常使用)", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}
    
    if result.get("code") == 0:
        data = result.get("data", {})
        is_new = data.get("isNew", False)
        data_changed = data.get("dataChanged", False)
        
        # 更新本地记录的hash
        local_data["cloud_sync"] = local_data.get("cloud_sync", {})
        local_data["cloud_sync"]["last_upload_hash"] = data_hash
        local_data["cloud_sync"]["last_upload_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_local_learn_data(local_data)
        
        log(f"上传成功! 记录ID: {data.get('id')}, 新数据: {is_new}, 有变化: {data_changed}")
        return {
            "success": True,
            "skipped": False,
            "is_new": is_new,
            "data_changed": data_changed,
            "data_hash": data_hash,
            "record_id": data.get("id")
        }
    else:
        log(f"上传失败: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


# ============================================================
# 查询与合并功能
# ============================================================
# 本地缓存的last_data_hash，用于If-None-Match
def get_cached_data_hash() -> str:
    """获取缓存的云端数据hash"""
    cache_file = DATA_DIR / "learn_sync_cache.json"
    if cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
                return cache.get("cloud_data_hash", "")
        except:
            pass
    return ""


def save_cached_data_hash(data_hash: str, data: dict = None):
    """保存云端数据hash到缓存"""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = DATA_DIR / "learn_sync_cache.json"
    cache = {
        "cloud_data_hash": data_hash,
        "last_update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    if data:
        cache["cloud_data_summary"] = {
            "version": data.get("version"),
            "interaction_count": data.get("interaction_count"),
            "discoveries_count": len(data.get("discoveries", [])),
            "policy_count": len(data.get("policy_updates", []))
        }
    
    with open(cache_file, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def query_cloud_data() -> dict:
    """查询云端自学习数据(带指纹缓存)"""
    log("查询云端自学习数据...")
    
    # 获取上次缓存的hash
    last_hash = get_cached_data_hash()
    
    headers = {}
    if last_hash:
        headers["If-None-Match"] = last_hash
        log(f"携带指纹缓存: {last_hash[:16]}...")
    
    endpoint = f"/query?skillName={SKILL_NAME}"
    result = api_request("GET", endpoint, headers=headers)
    
    # 授权失败不阻塞，仅记录警告
    if result.get("auth_error"):
        log("[WARNING] 云同步授权失败，跳过下载(不影响正常使用)", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}
    
    if result.get("code") == 0:
        data = result.get("data", {})
        
        # 数据未变化
        if not data.get("changed", True):
            log("云端数据未变化，跳过下载")
            return {"success": True, "changed": False, "quota": data.get("quotaRemaining")}
        
        # 数据有变化，解析skillJson
        cloud_data_str = data.get("skillJson", "{}")
        try:
            cloud_data = json.loads(cloud_data_str) if isinstance(cloud_data_str, str) else cloud_data_str
        except:
            cloud_data = {}
        
        # 保存新的hash
        new_hash = data.get("dataHash", "")
        save_cached_data_hash(new_hash, cloud_data)
        
        log(f"获取到新数据! 剩余配额: {data.get('quotaRemaining')}")
        return {
            "success": True,
            "changed": True,
            "data": cloud_data,
            "data_hash": new_hash,
            "quota": data.get("quotaRemaining")
        }
    else:
        log(f"查询失败: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


def merge_cloud_to_local(cloud_data: dict) -> dict:
    """合并云端数据到本地"""
    log("开始合并云端数据到本地...")
    
    local_data = load_local_learn_data()
    merge_stats = {
        "discoveries_added": 0,
        "policies_added": 0,
        "kb_updates_added": 0,
        "cases_added": 0,
        "profiles_merged": 0
    }
    
    # 合并discoveries(按ID去重)
    local_ids = {d.get("id") for d in local_data.get("discoveries", []) if d.get("id")}
    for discovery in cloud_data.get("discoveries", []):
        if discovery.get("id") and discovery["id"] not in local_ids:
            local_data["discoveries"].append(discovery)
            merge_stats["discoveries_added"] += 1
            local_ids.add(discovery["id"])
    
    # 合并policy_updates(按时间和内容去重)
    local_policies = {(p.get("date"), p.get("title")) for p in local_data.get("policy_updates", [])}
    for policy in cloud_data.get("policy_updates", []):
        key = (policy.get("date"), policy.get("title"))
        if key not in local_policies:
            local_data["policy_updates"].append(policy)
            merge_stats["policies_added"] += 1
            local_policies.add(key)
    
    # 合并knowledge_base_updates
    local_kb = {(k.get("date"), k.get("type"), k.get("field")) for k in local_data.get("knowledge_base_updates", [])}
    for kb in cloud_data.get("knowledge_base_updates", []):
        key = (kb.get("date"), kb.get("type"), kb.get("field"))
        if key not in local_kb:
            local_data["knowledge_base_updates"].append(kb)
            merge_stats["kb_updates_added"] += 1
            local_kb.add(key)
    
    # 合并training_cases
    local_cases = {c.get("case_id") for c in local_data.get("training_cases", [])}
    for case in cloud_data.get("training_cases", []):
        if case.get("case_id") and case["case_id"] not in local_cases:
            local_data["training_cases"].append(case)
            merge_stats["cases_added"] += 1
            local_cases.add(case["case_id"])
    
    # 合并user_profiles(云端数据补充本地)
    local_profiles = local_data.get("user_profiles", {})
    for uscc, profile in cloud_data.get("user_profiles", {}).items():
        if uscc not in local_profiles:
            local_profiles[uscc] = profile
            merge_stats["profiles_merged"] += 1
    local_data["user_profiles"] = local_profiles
    
    # 更新版本和时间
    local_data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    local_data["cloud_sync"] = local_data.get("cloud_sync", {})
    local_data["cloud_sync"]["last_download_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    local_data["cloud_sync"]["merge_count"] = local_data["cloud_sync"].get("merge_count", 0) + 1
    
    # 保存
    if save_local_learn_data(local_data):
        total_added = sum(merge_stats.values())
        log(f"合并完成! 新增 {total_added} 条记录")
        
        # 生成成果展示
        achievement_report = generate_achievement_report(merge_stats, cloud_data)
        
        return {
            "success": True, 
            "stats": merge_stats, 
            "total_added": total_added,
            "achievement_report": achievement_report
        }
    else:
        return {"success": False, "error": "保存本地数据失败"}


def generate_achievement_report(stats: dict, cloud_data: dict) -> str:
    """生成用户友好的成果展示报告"""
    lines = []
    lines.append("\n" + "=" * 60)
    lines.append("🎉 恭喜！知识库已升级，您的技能变得更强大了！")
    lines.append("=" * 60)
    
    total = sum(stats.values())
    if total == 0:
        lines.append("📭 本次暂无新内容，您的知识库已是最新！")
    else:
        lines.append(f"\n📊 本次共获取 {total} 条新知识：\n")
        
        # 展示 discoveries
        if stats["discoveries_added"] > 0:
            lines.append(f"  📚 {stats['discoveries_added']} 条发现")
            # 展示具体内容（最多3条）
            for i, d in enumerate(cloud_data.get("discoveries", [])[:3]):
                keyword = d.get("keyword", "未知")
                lines.append(f"     └─ {keyword}")
            if stats["discoveries_added"] > 3:
                lines.append(f"     └─ ... 还有 {stats['discoveries_added'] - 3} 条")
        
        # 展示 policies
        if stats["policies_added"] > 0:
            lines.append(f"  📋 {stats['policies_added']} 条政策更新")
            for i, p in enumerate(cloud_data.get("policy_updates", [])[:3]):
                title = p.get("title", "未知")[:30]
                lines.append(f"     └─ {title}...")
            if stats["policies_added"] > 3:
                lines.append(f"     └─ ... 还有 {stats['policies_added'] - 3} 条")
        
        # 展示 cases
        if stats["cases_added"] > 0:
            lines.append(f"  📁 {stats['cases_added']} 个训练案例")
            for i, c in enumerate(cloud_data.get("training_cases", [])[:3]):
                company = c.get("company", "未知企业")
                industry = c.get("industry", "未知行业")
                lines.append(f"     └─ {company} ({industry})")
            if stats["cases_added"] > 3:
                lines.append(f"     └─ ... 还有 {stats['cases_added'] - 3} 个")
        
        # 展示 profiles
        if stats["profiles_merged"] > 0:
            lines.append(f"  👤 {stats['profiles_merged']} 个用户画像")
        
        # 展示 kb_updates
        if stats["kb_updates_added"] > 0:
            lines.append(f"  🧠 {stats['kb_updates_added']} 条知识库更新")
    
    lines.append("\n✨ 知识库持续进化中，越用越智能！")
    lines.append("=" * 60)
    
    return "\n".join(lines)


# ============================================================
# 双向同步
# ============================================================
def bidirectional_sync(silent: bool = False) -> dict:
    """双向同步: 先上传本地，再查询合并云端
    
    Args:
        silent: 如果为True，授权失败时不输出警告(用于自动后台同步)
    """
    log("=" * 50)
    log("开始双向同步...")
    log("=" * 50)
    
    results = {
        "upload": None,
        "download": None,
        "merge": None,
        "auth_error": False  # 标记是否有授权问题
    }
    
    # Step 1: 上传本地数据
    log("\n[Step 1/3] 上传本地数据...")
    results["upload"] = upload_learn_data("双向同步-上传")
    
    # 检查授权失败
    if results["upload"].get("auth_error"):
        results["auth_error"] = True
        if not silent:
            log("[INFO] 云同步授权问题已记录，技能继续正常运行", "INFO")
        # 继续执行查询步骤，可能下载是开放的
    
    # Step 2: 查询云端数据
    log("\n[Step 2/3] 查询云端数据...")
    results["download"] = query_cloud_data()
    
    if results["download"].get("auth_error"):
        results["auth_error"] = True
        if not silent:
            log("[INFO] 云同步授权问题已记录，技能继续正常运行", "INFO")
    
    # Step 3: 合并(如果有新数据且没有授权错误)
    if results["download"].get("success") and results["download"].get("changed"):
        log("\n[Step 3/3] 合并云端数据...")
        cloud_data = results["download"].get("data", {})
        results["merge"] = merge_cloud_to_local(cloud_data)
        
        # 展示成果报告（给用户爽体验）
        if results["merge"].get("success") and results["merge"].get("total_added", 0) > 0:
            achievement = results["merge"].get("achievement_report", "")
            if achievement:
                print(achievement)  # 直接打印给用户看
    else:
        if results["auth_error"]:
            log("\n[Step 3/3] 授权问题，跳过合并")
        else:
            log("\n[Step 3/3] 云端无新数据，跳过合并")
        results["merge"] = {"success": True, "skipped": True}
    
    # 汇总
    log("\n" + "=" * 50)
    log("同步完成!")
    if results["auth_error"]:
        log("  [NOTICE] 授权问题已记录，技能正常运行")
    log(f"  上传: {'成功' if results['upload'].get('success') else '跳过'} ")
    log(f"  查询: {'有新数据' if results['download'].get('changed') else '无变化/跳过'} ")
    log(f"  合并: {'完成' if results['merge'].get('success') else '跳过'} ")
    log("=" * 50)
    
    # 如果有授权问题，在结果中添加提示信息
    if results["auth_error"]:
        results["notice"] = "如需获取最新知识库和持续迭代新功能请联系作者获取授权！"
        # 同时在日志中提示(即使silent=True也会在返回结果中包含)
        if not silent:
            log("\n" + "=" * 60)
            log("云同步授权提示:")
            log("  检测到API授权问题，但技能功能不受影响，可正常使用。")
            log("  " + results["notice"])
            log("=" * 60)
    
    return results


# ============================================================
# 状态查询
# ============================================================
def get_sync_status() -> dict:
    """获取同步状态"""
    local_data = load_local_learn_data()
    cloud_sync = local_data.get("cloud_sync", {})
    
    # 本地数据摘要
    status = {
        "local": {
            "version": local_data.get("version"),
            "last_updated": local_data.get("last_updated"),
            "interaction_count": local_data.get("interaction_count", 0),
            "discoveries_count": len(local_data.get("discoveries", [])),
            "policies_count": len(local_data.get("policy_updates", [])),
            "cases_count": len(local_data.get("training_cases", [])),
        },
        "cloud_sync": {
            "last_upload_hash": cloud_sync.get("last_upload_hash", "")[:16] + "..." if cloud_sync.get("last_upload_hash") else "无",
            "last_upload_time": cloud_sync.get("last_upload_time", "从未"),
            "last_download_time": cloud_sync.get("last_download_time", "从未"),
            "merge_count": cloud_sync.get("merge_count", 0)
        }
    }
    
    # 检查缓存
    cache_file = DATA_DIR / "learn_sync_cache.json"
    if cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
                status["cache"] = {
                    "cloud_data_hash": cache.get("cloud_data_hash", "")[:16] + "..." if cache.get("cloud_data_hash") else "无",
                    "last_update_time": cache.get("last_update_time", "从未")
                }
        except:
            pass
    
    return status


# ============================================================
# API测试
# ============================================================
def test_api() -> dict:
    """测试API可用性"""
    log("测试API可用性...")
    
    result = api_request("GET", "/ping", timeout=10)
    
    if result.get("code") == 0:
        data = result.get("data", {})
        log(f"API可用! 服务: {data.get('service')}")
        return {"available": True, "service": data.get("service")}
    else:
        log(f"API不可用: {result.get('msg')}", "ERROR")
        return {"available": False, "error": result.get("msg")}


# ============================================================
# CLI接口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="TaxRiskGuard 自学习数据云端同步")
    parser.add_argument("--upload", action="store_true", help="上传本地数据到云端")
    parser.add_argument("--query", action="store_true", help="查询云端数据")
    parser.add_argument("--sync", action="store_true", help="双向同步(上传+查询+合并)")
    parser.add_argument("--status", action="store_true", help="查看同步状态")
    parser.add_argument("--test-api", action="store_true", help="测试API可用性")
    parser.add_argument("--remark", type=str, default="", help="上传备注")
    parser.add_argument("--merge-only", action="store_true", help="仅合并，不上传")
    
    args = parser.parse_args()
    
    if args.test_api:
        result = test_api()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    if args.status:
        status = get_sync_status()
        print(json.dumps(status, ensure_ascii=False, indent=2))
        return
    
    if args.upload:
        result = upload_learn_data(args.remark)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result.get("success") else 1)
    
    if args.query:
        result = query_cloud_data()
        if result.get("success") and result.get("changed"):
            # 询问是否合并
            merge_result = merge_cloud_to_local(result.get("data", {}))
            print(json.dumps({"query": result, "merge": merge_result}, ensure_ascii=False, indent=2))
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    if args.sync:
        results = bidirectional_sync()
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return
    
    # 默认: 显示状态
    status = get_sync_status()
    print("=" * 60)
    print("TaxRiskGuard 自学习数据同步状态")
    print("=" * 60)
    print(f"\n本地数据:")
    for k, v in status["local"].items():
        print(f"  {k}: {v}")
    print(f"\n云端同步:")
    for k, v in status["cloud_sync"].items():
        print(f"  {k}: {v}")
    if "cache" in status:
        print(f"\n缓存状态:")
        for k, v in status["cache"].items():
            print(f"  {k}: {v}")
    print("\n" + "=" * 60)
    print("使用 --upload 上传, --query 查询, --sync 双向同步")
    print("=" * 60)


if __name__ == "__main__":
    main()
