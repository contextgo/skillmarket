#!/usr/bin/env python3
"""
招聘沟通邮件发送脚本
支持面试邀约、跟进、录用通知、拒信等场景
"""

import sys
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from pathlib import Path

# 邮件模板
EMAIL_TEMPLATES = {
    "interview_invitation": """
{recipient_name}你好，

感谢您申请{company_name}的{position}岗位！

经过初步简历筛选，我们诚挚邀请您参加面试。面试安排如下：

📅 面试时间：{interview_time}
📍 面试地点：{interview_location}
👤 面试官：{interviewer}
⏰ 预计时长：{duration}

请您携带以下材料：
- 身份证原件
- 学历学位证书复印件
- 其他相关证书

如有任何问题，请随时联系我们。

期待与您的见面！

此致
{company_name}人力资源部
{contact_email}
{contact_phone}
    """,
    
    "interview_followup": """
{recipient_name}你好，

感谢您于{interview_date}参加{position}岗位的面试。

经过面试评估，我们希望进一步了解您的相关经验。请您在方便的时候回复以下问题：

1. {question1}
2. {question2}
3. {question3}

您的回复将帮助我们更好地评估您的匹配度。

如有任何疑问，请随时联系。

此致
{company_name}人力资源部
    """,
    
    "offer_notification": """
{recipient_name}你好，

恭喜！我们很高兴地通知您，您已成功通过{company_name}{position}岗位的所有面试和评估。

我们诚挚地邀请您加入我们的团队。以下是录用量化信息：

💼 职位：{position}
💰 薪资：{salary_range}
📅 入职时间：{start_date}
📍 工作地点：{work_location}
🎁 福利待遇：{benefits}

请在{response_deadline}前确认是否接受此录用通知。

我们期待您的加入！

此致
{company_name}人力资源部
{contact_email}
{contact_phone}
    """,
    
    "rejection": """
{recipient_name}你好，

感谢您申请{company_name}的{position}岗位，并抽出时间参加我们的面试流程。

经过慎重考虑，我们遗憾地通知您，本次未能匹配到合适的岗位。

您的资历给我们留下了深刻印象，我们已将您的简历存入我司人才库。未来有合适机会，我们会第一时间联系您。

感谢您对我们公司的关注，祝您求职顺利！

此致
{company_name}人力资源部
    """
}

def send_email(smtp_config, recipient, subject, body, is_html=False):
    """发送邮件"""
    try:
        # 创建邮件
        msg = MIMEMultipart()
        msg['From'] = smtp_config['sender_name']
        msg['To'] = recipient
        msg['Subject'] = subject

        # 邮件正文
        if is_html:
            msg.attach(MIMEText(body, 'html', 'utf-8'))
        else:
            msg.attach(MIMEText(body, 'plain', 'utf-8'))

        # 连接 SMTP 服务器并发送
        use_ssl = smtp_config.get('use_ssl', False)
        smtp_port = smtp_config.get('smtp_port', 465 if use_ssl else 587)

        if use_ssl:
            server = smtplib.SMTP_SSL(smtp_config['smtp_server'], smtp_port)
        else:
            server = smtplib.SMTP(smtp_config['smtp_server'], smtp_port)
            server.starttls()

        server.login(smtp_config['username'], smtp_config['password'])

        text = msg.as_string()
        server.sendmail(smtp_config['sender_email'], recipient, text)
        server.quit()

        return {"success": True, "message": f"邮件已发送至 {recipient}"}

    except Exception as e:
        return {"success": False, "error": str(e)}

def generate_email_content(template_name, data):
    """根据模板生成邮件内容"""
    if template_name not in EMAIL_TEMPLATES:
        return {"error": f"未找到模板: {template_name}"}
    
    template = EMAIL_TEMPLATES[template_name]
    
    # 替换模板变量
    content = template
    for key, value in data.items():
        placeholder = "{" + key + "}"
        content = content.replace(placeholder, str(value))
    
    return {"content": content}

def main():
    if len(sys.argv) < 2:
        print("用法：")
        print("  生成邮件: python email_sender.py generate <template_name> <data_json_file>")
        print("  发送邮件: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file>")
        print("\n可用模板：")
        for template in EMAIL_TEMPLATES.keys():
            print(f"  - {template}")
        sys.exit(1)
    
    action = sys.argv[1]
    
    if action == "generate":
        # 生成邮件内容
        if len(sys.argv) < 4:
            print("用法: python email_sender.py generate <template_name> <data_json_file>")
            sys.exit(1)
        
        template_name = sys.argv[2]
        data_file = sys.argv[3]
        
        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        result = generate_email_content(template_name, data)
        
        if 'error' in result:
            print(f"错误: {result['error']}")
            sys.exit(1)
        else:
            print(result['content'])
    
    elif action == "send":
        # 发送邮件
        if len(sys.argv) < 6:
            print("用法: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file>")
            sys.exit(1)
        
        smtp_config_file = sys.argv[2]
        recipient = sys.argv[3]
        subject = sys.argv[4]
        body_file = sys.argv[5]
        
        # 读取 SMTP 配置
        with open(smtp_config_file, 'r', encoding='utf-8') as f:
            smtp_config = json.load(f)
        
        # 读取邮件正文
        with open(body_file, 'r', encoding='utf-8') as f:
            body = f.read()
        
        result = send_email(smtp_config, recipient, subject, body)
        
        if result['success']:
            print(result['message'])
        else:
            print(f"发送失败: {result['error']}")
            sys.exit(1)
    
    else:
        print(f"未知操作: {action}")
        sys.exit(1)

if __name__ == "__main__":
    main()
