#!/usr/bin/env python3
"""
评估报告生成脚本 - 支持 HTML/PDF/Word 格式输出
"""

import sys
import json
from pathlib import Path
from datetime import datetime

def generate_html_report(data, output_path):
    """生成 HTML 格式的评估报告"""
    html_template = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>候选人评估报告 - {candidate_name}</title>
    <style>
        body {{
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            line-height: 1.6;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .report-header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .report-header h1 {{
            margin: 0 0 10px 0;
            font-size: 28px;
        }}
        .report-meta {{
            opacity: 0.9;
            font-size: 14px;
        }}
        .section {{
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #667eea;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }}
        .info-item {{
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }}
        .info-label {{
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
        }}
        .match-score {{
            font-size: 48px;
            font-weight: bold;
            text-align: center;
            color: {score_color};
            margin: 20px 0;
        }}
        .score-bar {{
            background: #e0e0e0;
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }}
        .score-fill {{
            background: {score_color};
            height: 100%;
            width: {match_score}%;
            transition: width 0.5s ease-in-out;
        }}
        .pros-cons {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }}
        .pros, .cons {{
            padding: 15px;
            border-radius: 5px;
        }}
        .pros {{
            background: #d4edda;
            border-left: 4px solid #28a745;
        }}
        .cons {{
            background: #f8d7da;
            border-left: 4px solid #dc3545;
        }}
        .pros h3, .cons h3 {{
            margin-top: 0;
        }}
        .recommendation {{
            padding: 20px;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }}
        .recommend-strong {{
            background: #d4edda;
            color: #155724;
            border: 2px solid #28a745;
        }}
        .recommend-maybe {{
            background: #fff3cd;
            color: #856404;
            border: 2px solid #ffc107;
        }}
        .recommend-no {{
            background: #f8d7da;
            color: #721c24;
            border: 2px solid #dc3545;
        }}
        ul {{
            margin: 0;
            padding-left: 20px;
        }}
        li {{
            margin-bottom: 8px;
        }}
    </style>
</head>
<body>
    <div class="report-header">
        <h1>候选人评估报告</h1>
        <div class="report-meta">
            <p>候选人：{candidate_name} | 报告生成时间：{report_date}</p>
        </div>
    </div>
    
    <div class="section">
        <h2>基本信息</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">姓名</div>
                <div>{candidate_name}</div>
            </div>
            <div class="info-item">
                <div class="info-label">邮箱</div>
                <div>{email}</div>
            </div>
            <div class="info-item">
                <div class="info-label">电话</div>
                <div>{phone}</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2>人岗匹配分析</h2>
        <div class="match-score">{match_score} 分</div>
        <div class="score-bar">
            <div class="score-fill"></div>
        </div>
        
        <div class="pros-cons">
            <div class="pros">
                <h3>✓ 优势分析</h3>
                <ul>
                    {pros_list}
                </ul>
            </div>
            <div class="cons">
                <h3>✗ 差距分析</h3>
                <ul>
                    {cons_list}
                </ul>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2>教育背景</h2>
        <ul>
            {education_list}
        </ul>
    </div>
    
    <div class="section">
        <h2>工作/项目经验</h2>
        <ul>
            {experience_list}
        </ul>
    </div>
    
    <div class="section">
        <h2>技能评估</h2>
        <ul>
            {skills_list}
        </ul>
    </div>
    
    <div class="section">
        <h2>风险评估</h2>
        <ul>
            {risks_list}
        </ul>
    </div>
    
    <div class="recommendation {recommendation_class}">
        录用建议：{recommendation_text}
    </div>
</body>
</html>
"""
    
    # 填充模板数据
    score_color = "#28a745" if data.get('match_score', 0) >= 80 else "#ffc107" if data.get('match_score', 0) >= 60 else "#dc3545"
    
    html_content = html_template.format(
        candidate_name=data.get('name', '未知'),
        report_date=datetime.now().strftime('%Y-%m-%d %H:%M'),
        email=data.get('email', '未提供'),
        phone=data.get('phone', '未提供'),
        match_score=data.get('match_score', 0),
        score_color=score_color,
        pros_list='\n'.join([f'<li>{item}</li>' for item in data.get('pros', [])]),
        cons_list='\n'.join([f'<li>{item}</li>' for item in data.get('cons', [])]),
        education_list='\n'.join([f'<li>{item}</li>' for item in data.get('education', [])]),
        experience_list='\n'.join([f'<li>{item}</li>' for item in data.get('work_experience', [])]),
        skills_list='\n'.join([f'<li>{item}</li>' for item in data.get('skills', [])]),
        risks_list='\n'.join([f'<li>{item}</li>' for item in data.get('risks', [])]),
        recommendation_class=f"recommend-{data.get('recommendation', 'maybe')}",
        recommendation_text=data.get('recommendation_text', '待定')
    )
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return output_path

def generate_docx_report(data, output_path):
    """生成 Word 格式的评估报告"""
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        doc = Document()
        
        # 标题
        title = doc.add_heading('候选人评估报告', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 基本信息
        doc.add_heading('基本信息', level=1)
        table = doc.add_table(rows=3, cols=2)
        table.cell(0, 0).text = '姓名'
        table.cell(0, 1).text = data.get('name', '未知')
        table.cell(1, 0).text = '邮箱'
        table.cell(1, 1).text = data.get('email', '未提供')
        table.cell(2, 0).text = '电话'
        table.cell(2, 1).text = data.get('phone', '未提供')
        
        # 匹配分数
        doc.add_heading('人岗匹配分析', level=1)
        p = doc.add_paragraph()
        p.add_run(f"匹配分数：{data.get('match_score', 0)} 分").bold = True
        
        # 优势
        doc.add_heading('优势分析', level=2)
        for item in data.get('pros', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 差距
        doc.add_heading('差距分析', level=2)
        for item in data.get('cons', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 教育背景
        doc.add_heading('教育背景', level=1)
        for item in data.get('education', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 工作经历
        doc.add_heading('工作/项目经验', level=1)
        for item in data.get('work_experience', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 技能
        doc.add_heading('技能评估', level=1)
        for item in data.get('skills', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 风险评估
        doc.add_heading('风险评估', level=1)
        for item in data.get('risks', []):
            doc.add_paragraph(item, style='List Bullet')
        
        # 录用建议
        p = doc.add_paragraph()
        p.add_run(f"录用建议：{data.get('recommendation_text', '待定')}").bold = True
        
        doc.save(output_path)
        return output_path
        
    except ImportError:
        return {"error": "需要安装 python-docx: pip install python-docx"}

def main():
    if len(sys.argv) < 3:
        print("用法: python report_generator.py <json_data_file> <output_file> [format]")
        print("格式: html, docx, pdf (默认: html)")
        sys.exit(1)
    
    json_file = sys.argv[1]
    output_file = sys.argv[2]
    output_format = sys.argv[3] if len(sys.argv) > 3 else 'html'
    
    # 读取 JSON 数据
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 生成报告
    if output_format == 'html':
        result = generate_html_report(data, output_file)
    elif output_format == 'docx':
        result = generate_docx_report(data, output_file)
    elif output_format == 'pdf':
        print("PDF 格式需要额外依赖，建议使用 HTML 或 DOCX 格式")
        sys.exit(1)
    else:
        print(f"不支持的格式: {output_format}")
        sys.exit(1)
    
    if isinstance(result, dict) and 'error' in result:
        print(f"错误: {result['error']}")
        sys.exit(1)
    else:
        print(f"报告已生成: {result}")

if __name__ == "__main__":
    main()
