#!/usr/bin/env python3
"""
简历解析脚本 - 支持 Word/PDF/图片格式
使用 OCR 和 NLP 技术提取简历关键信息
"""

import sys
import json
from pathlib import Path

def parse_docx(file_path):
    """解析 Word 文档格式的简历"""
    try:
        from docx import Document
    
        doc = Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])
    
        # 提取表格内容（如果有）
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text += f"\n{cell.text}"
    
        return extract_info_from_text(text)
    except ImportError:
        return {"error": "需要安装 python-docx: pip install python-docx"}

def parse_pdf(file_path):
    """解析 PDF 格式的简历"""
    try:
        import PyPDF2
    
        text = ""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text += page.extract_text()
    
        return extract_info_from_text(text)
    except ImportError:
        return {"error": "需要安装 PyPDF2: pip install PyPDF2"}

def parse_image(file_path):
    """解析图片格式的简历（使用 OCR）"""
    try:
        import pytesseract
        from PIL import Image
    
        img = Image.open(file_path)
        text = pytesseract.image_to_string(img, lang='chi_sim+eng')
    
        return extract_info_from_text(text)
    except ImportError:
        return {"error": "需要安装 pytesseract 和 Pillow: pip install pytesseract Pillow"}

def extract_info_from_text(text):
    """从文本中提取关键信息"""
    import re
    
    info = {
        "name": "",
        "email": "",
        "phone": "",
        "education": [],
        "work_experience": [],
        "skills": [],
        "projects": []
    }
    
    # 提取邮箱
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    if emails:
        info["email"] = emails[0]
    
    # 提取手机号（中国手机号）
    phone_pattern = r'1[3-9]\d{9}'
    phones = re.findall(phone_pattern, text)
    if phones:
        info["phone"] = phones[0]
    
    # 提取姓名（简单启发式：通常在前几行）
    lines = text.strip().split('\n')
    for line in lines[:5]:
        line = line.strip()
        if line and len(line) <= 4 and not re.search(r'[@0-9]', line):
            info["name"] = line
            break
    
    # 提取教育背景（查找关键词）
    education_keywords = ['大学', '学院', '本科', '硕士', '博士', '学历', '学位', '专业']
    education_section = []
    in_education = False
    for line in lines:
        if any(keyword in line for keyword in education_keywords):
            in_education = True
        if in_education:
            education_section.append(line.strip())
            if len(education_section) > 10:  # 限制长度
                break
    info["education"] = education_section
    
    # 提取技能（查找关键词）
    skill_keywords = ['技能', '熟练掌握', '精通', '熟悉', '了解', 'Python', 'Java', 'C++', 
                     'JavaScript', 'HTML', 'CSS', 'SQL', 'Linux', 'Git']
    skills = []
    for line in lines:
        if any(keyword in line for keyword in skill_keywords):
            # 提取技能行中的关键词
            for skill in skill_keywords:
                if skill in line and skill not in skills:
                    skills.append(skill)
    info["skills"] = skills
    
    # 提取工作经历（查找关键词）
    work_keywords = ['工作经验', '工作经历', '职业经历', '公司', '任职', '担任']
    work_experience = []
    in_work = False
    for i, line in enumerate(lines):
        if any(keyword in line for keyword in work_keywords):
            in_work = True
        if in_work:
            work_experience.append(line.strip())
            if len(work_experience) > 20:  # 限制长度
                break
    info["work_experience"] = work_experience
    
    return info

def main():
    if len(sys.argv) < 2:
        print("用法: python resume_parser.py <resume_file>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    file_ext = Path(file_path).suffix.lower()
    
    if file_ext in ['.docx', '.doc']:
        result = parse_docx(file_path)
    elif file_ext == '.pdf':
        result = parse_pdf(file_path)
    elif file_ext in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']:
        result = parse_image(file_path)
    else:
        result = {"error": f"不支持的文件格式: {file_ext}"}
    
    # 输出 JSON 格式结果
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
