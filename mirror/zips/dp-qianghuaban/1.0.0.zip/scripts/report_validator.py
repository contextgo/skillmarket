#!/usr/bin/env python3
"""
实现 Skill4 的数据正确性校验
输入：Skill3 输出的最终周报（Markdown），以及 Skill2 输出的原始计算结果
输出：校验报告（Markdown）
"""

import re
import sys
from pathlib import Path

def validate_rounding(report_path, metrics_path):
    """
    校验周报中的环比%、环比量是否正确
    """
    errors = []
    # 读取 Skill2 的原始计算结果（例如表2的数值）
    # 解析周报中的对应数值，逐项比对
    # 如果误差超过0.1，记录错误
    # 由于没有具体数据，此处仅框架
    return errors

def validate_units_and_logic(report_text):
    """校验金额是否带“万”，人数是否为整数，趣味总金额≈延迟+即刻"""
    errors = []
    # 用正则提取表格中的数值，检查格式
    # 检查趣味总金额与延迟+即刻的差值是否在允许范围内
    return errors

def generate_validation_report(errors_format, errors_data, anomalies):
    """生成最终校验报告，格式如 Skill4 要求"""
    report = "# 周报校验报告\n\n"
    if not errors_format and not errors_data:
        report += "## 综合结论\n✅ 周报合格，可直接发布\n"
    else:
        report += "## 综合结论\n❌ 周报不合格，请按错误列表修改后重新生成\n\n"
        if errors_format:
            report += "## 1. 格式校验结果\n❌ 不通过\n错误列表：\n" + "\n".join(errors_format) + "\n\n"
        if errors_data:
            report += "## 2. 数据校验结果\n❌ 不通过\n错误列表：\n" + "\n".join(errors_data) + "\n\n"
        if anomalies:
            report += "## 3. 异常指标提醒（环比＞50%）\n" + "\n".join(anomalies) + "\n\n"
    return report

if __name__ == '__main__':
    # 假设传入参数：周报文件路径、原始计算结果路径
    if len(sys.argv) < 3:
        print("用法: python report_validator.py <周报.md> <原始指标.json>")
        sys.exit(1)
    report_file = sys.argv[1]
    metrics_file = sys.argv[2]
    with open(report_file, 'r', encoding='utf-8') as f:
        report_text = f.read()
    # 实际需要加载 metrics_file 中的原始数据
    # 这里仅示意
    errors_fmt = []  # 格式错误列表
    errors_data = validate_rounding(report_file, metrics_file)
    errors_data += validate_units_and_logic(report_text)
    anomalies = []   # 异常指标列表
    final = generate_validation_report(errors_fmt, errors_data, anomalies)
    print(final)