#!/usr/bin/env python3
"""
实现 Skill1：数据读取与清洗
输入：用户指定的14天时间段（如 "2026/3/19 至 2026/4/1"） + 原始数据文件
输出：clean_data/ 目录下的清洗后文件
"""

import pandas as pd
import numpy as np
from pathlib import Path
import sys

def parse_date_range(date_str: str):
    """解析用户输入，如 '2026/3/19 至 2026/4/1'，返回 (start, end)"""
    parts = date_str.split('至')
    start = pd.to_datetime(parts[0].strip())
    end = pd.to_datetime(parts[1].strip())
    return start, end

def clean_data(raw_dir='./raw_data', clean_dir='./clean_data', start_date=None, end_date=None):
    """
    raw_dir: 原始文件所在目录（用户上传）
    clean_dir: 清洗后输出目录
    start_date, end_date: datetime 对象
    """
    raw_path = Path(raw_dir)
    clean_path = Path(clean_dir)
    clean_path.mkdir(parents=True, exist_ok=True)
    
    # 生成日期序列
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    date_strs = [d.strftime('%Y-%m-%d') for d in date_range]
    
    # 1. 后台模板数据.csv
    df_tpl = pd.read_csv(raw_path / '后台模板数据.csv')
    time_col = df_tpl.columns[0]  # 第一列为时间列
    df_tpl[time_col] = pd.to_datetime(df_tpl[time_col]).dt.strftime('%Y-%m-%d')
    df_tpl = df_tpl[df_tpl[time_col].isin(date_strs)]
    df_tpl.dropna(how='any', inplace=True)
    df_tpl.to_csv(clean_path / '后台模板数据_clean.csv', index=False)
    
    # 2. 后台数据表格.csv
    df_back = pd.read_csv(raw_path / '后台数据表格.csv')
    time_col = df_back.columns[0]
    df_back[time_col] = pd.to_datetime(df_back[time_col]).dt.strftime('%Y-%m-%d')
    df_back = df_back[df_back[time_col].isin(date_strs)]
    df_back.dropna(how='any', inplace=True)
    df_back.to_csv(clean_path / '后台数据表格_clean.csv', index=False)
    
    # 3. 趣味玩法邮件表格.xlsx
    xlsx_path = raw_path / '趣味玩法邮件表格.xlsx'
    xlsx = pd.ExcelFile(xlsx_path)
    keep_sheets = ['关键', '营收', '趣味流水', '趣味粉区间', '入金100%-总', '入金100%金额', '入金100%人数']
    with pd.ExcelWriter(clean_path / '趣味玩法邮件表格_clean.xlsx') as writer:
        for sheet in keep_sheets:
            if sheet not in xlsx.sheet_names:
                continue
            df = pd.read_excel(xlsx, sheet_name=sheet)
            time_col = df.columns[0]
            df[time_col] = pd.to_datetime(df[time_col]).dt.strftime('%Y-%m-%d')
            df = df[df[time_col].isin(date_strs)]
            df.dropna(how='any', inplace=True)
            df.to_excel(writer, sheet_name=sheet, index=False)
    
    # 4. 玩法组规划时间表.xlsx（原样复制）
    df_plan = pd.read_excel(raw_path / '玩法组规划时间表.xlsx')
    df_plan.to_excel(clean_path / '玩法组规划时间表.xlsx', index=False)
    
    # 5. 记录时间段
    with open(clean_path / '时间段.txt', 'w') as f:
        f.write(f"{start_date.strftime('%Y-%m-%d')} 至 {end_date.strftime('%Y-%m-%d')}")
    
    print("数据清洗完成！")
    return True

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python data_cleaner.py '2026/3/19 至 2026/4/1'")
        sys.exit(1)
    start, end = parse_date_range(sys.argv[1])
    clean_data(start_date=start, end_date=end)