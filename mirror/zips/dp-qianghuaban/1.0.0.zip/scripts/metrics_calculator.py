#!/usr/bin/env python3
"""
实现 Skill2：核心指标计算
输入：clean_data/ 目录下的清洗后数据
输出：metrics_output/ 目录下的趋势图、表1.md、表2.md
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import sys
import re
from datetime import datetime

CLEAN_DIR = Path('./clean_data')
OUTPUT_DIR = Path('./metrics_output')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ==================== 1. 活动日期解析 ====================
def parse_activity_date_range(date_str: str, base_year=2026):
    """
    解析活动日期字符串，返回 (start_date, end_date) datetime 对象
    支持格式：
        "3.20-3.22"        -> 2026/3/20 ~ 2026/3/22
        "2026/3/20-2026/3/22"
        "2026-03-20至2026-03-22"
    """
    date_str = date_str.strip()
    # 尝试各种分隔符
    for sep in ['-', '至', '～']:
        if sep in date_str:
            parts = date_str.split(sep)
            if len(parts) == 2:
                start_raw, end_raw = parts[0].strip(), parts[1].strip()
                # 如果年份缺失，补充 base_year
                if re.match(r'^\d+\.\d+$', start_raw):  # 形如 "3.20"
                    start_raw = f"{base_year}/{start_raw.replace('.', '/')}"
                    end_raw = f"{base_year}/{end_raw.replace('.', '/')}"
                start = pd.to_datetime(start_raw)
                end = pd.to_datetime(end_raw)
                return start, end
    raise ValueError(f"无法解析活动日期格式: {date_str}")

def get_activities():
    """从玩法组规划时间表.xlsx中提取春季头条/精英赛的活动日期区间"""
    df = pd.read_excel(CLEAN_DIR / '玩法组规划时间表.xlsx')
    activities = []
    for _, row in df.iterrows():
        name = str(row.iloc[0])
        if '春季头条' in name or '精英赛' in name:
            date_range_str = str(row.iloc[1])
            try:
                start, end = parse_activity_date_range(date_range_str)
                activities.append((name, start, end))
            except Exception as e:
                print(f"警告：解析活动 {name} 的日期失败：{e}")
    return activities

# ==================== 2. 获取周期区间 ====================
def get_week_periods():
    """根据时间段.txt 计算上周、本周的起止日期（datetime）"""
    with open(CLEAN_DIR / '时间段.txt', 'r') as f:
        period = f.read().strip()
    start_end = period.split(' 至 ')
    start = pd.to_datetime(start_end[0])
    end = pd.to_datetime(start_end[1])
    date_range = pd.date_range(start=start, end=end, freq='D')
    last_week_start = date_range[0]
    last_week_end = date_range[6]
    curr_week_start = date_range[7]
    curr_week_end = date_range[13]
    return {
        'last_week': (last_week_start, last_week_end),
        'curr_week': (curr_week_start, curr_week_end),
        'all_dates': date_range
    }

# ==================== 3. 读取每日入金 & 出金数据 ====================
def load_daily_inflow_outflow():
    """
    从清洗后的趣味玩法邮件表格中读取：
        - 每日入金100% (来自分表 "入金100%-总", wanfa_type='all')
        - 每日出金消费 (来自分表 "关键", J列 "总-出金")
    返回两个 DataFrame，索引为日期，列为金额(万元)
    """
    xlsx_path = CLEAN_DIR / '趣味玩法邮件表格_clean.xlsx'
    
    # 读取入金100%数据
    df_inflow = pd.read_excel(xlsx_path, sheet_name='入金100%-总')
    time_col = df_inflow.columns[0]
    df_inflow[time_col] = pd.to_datetime(df_inflow[time_col])
    # 筛选 wanfa_type = 'all'
    df_inflow = df_inflow[df_inflow['wanfa_type'] == 'all']
    inflow = df_inflow.set_index(time_col)['amt'].rename('入金100%')
    
    # 读取出金消费数据
    df_outflow = pd.read_excel(xlsx_path, sheet_name='关键')
    time_col = df_outflow.columns[0]
    df_outflow[time_col] = pd.to_datetime(df_outflow[time_col])
    # J列通常是 "总-出金"，请根据实际列名调整，这里假设列位置为 9 (0-index)
    # 更安全的方式：按列名获取，如果列名不固定，可用 iloc[:, 9]
    outflow_col = df_outflow.columns[9] if len(df_outflow.columns) > 9 else '总-出金'
    outflow = df_outflow.set_index(time_col)[outflow_col].rename('出金消费')
    
    # 合并，统一索引
    daily = pd.concat([inflow, outflow], axis=1).dropna()
    # 转换为万元（原始数据单位可能为元，需确认；此处假设已经是万元）
    return daily

# ==================== 4. 生成趋势图 ====================
def generate_trend_chart(daily_df, activities, output_path):
    """
    daily_df: DataFrame，索引为日期，包含 '入金100%' 和 '出金消费' 两列（单位：万元）
    activities: 列表，元素为 (活动名, 开始日期, 结束日期)
    """
    plt.figure(figsize=(12, 6))
    dates = daily_df.index
    inflow = daily_df['入金100%']
    outflow = daily_df['出金消费']
    
    plt.plot(dates, inflow, color='#1E90FF', linewidth=2, label='入金100%')
    plt.plot(dates, outflow, color='#FF7F50', linewidth=2, label='出金消费')
    
    # 标注活动
    for name, start, end in activities:
        # 找到活动区间在横轴上的范围
        mask = (dates >= start) & (dates <= end)
        if mask.any():
            # 取活动区间中间点的 x 坐标和对应的 y 值（取入金和出金的最大值作为标注高度）
            mid_idx = dates[mask][len(dates[mask])//2]
            y_max = max(inflow[mask].max(), outflow[mask].max())
            # 添加文字框
            plt.annotate(f'{name}\n{start.strftime("%m/%d")}-{end.strftime("%m/%d")}',
                         xy=(mid_idx, y_max),
                         xytext=(0, 10),
                         textcoords='offset points',
                         ha='center',
                         va='bottom',
                         bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='#CCCCCC'),
                         fontsize=9)
    
    plt.xlabel('日期', fontsize=11)
    plt.ylabel('金额（万元）', fontsize=11)
    plt.title('入金出金趋势图', fontsize=14)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    print(f"趋势图已保存至 {output_path}")

# ==================== 5. 主计算流程（整合绘图） ====================
def calculate_metrics():
    """核心指标计算 + 生成趋势图、表1、表2"""
    print("开始计算核心指标...")
    
    # 1. 获取周期信息
    periods = get_week_periods()
    print(f"上周: {periods['last_week'][0].date()} ~ {periods['last_week'][1].date()}")
    print(f"本周: {periods['curr_week'][0].date()} ~ {periods['curr_week'][1].date()}")
    
    # 2. 获取活动信息
    activities = get_activities()
    if activities:
        print(f"检测到活动: {[a[0] for a in activities]}")
    else:
        print("未检测到春季头条/精英赛活动")
    
    # 3. 加载每日入金/出金数据
    daily = load_daily_inflow_outflow()
    if daily.empty:
        print("警告：未获取到每日入金/出金数据，无法生成趋势图")
    else:
        # 4. 生成趋势图
        generate_trend_chart(daily, activities, OUTPUT_DIR / 'trend.png')
    
    # ========== 以下为其他指标计算（根据你的 Skill2 补充） ==========
    # 此处需要根据实际数据表完成：周环比、非活对比、表1、表2 的生成
    # 建议将表1、表2 输出为 Markdown 文件，供 Skill3 读取
    # 示例：生成一个空的表1占位
    with open(OUTPUT_DIR / 'table1.md', 'w') as f:
        f.write("| 日期分类 | 开始时间 | 结束时间 | 天数 |\n")
        f.write("|----------|----------|----------|------|\n")
        f.write(f"| 上周非活 | ... | ... | ... |\n")
        f.write(f"| 本周非活 | ... | ... | ... |\n")
        f.write(f"| 上周 | {periods['last_week'][0].strftime('%Y/%m/%d')} | {periods['last_week'][1].strftime('%Y/%m/%d')} | 7 |\n")
        f.write(f"| 本周 | {periods['curr_week'][0].strftime('%Y/%m/%d')} | {periods['curr_week'][1].strftime('%Y/%m/%d')} | 7 |\n")
    
    with open(OUTPUT_DIR / 'table2.md', 'w') as f:
        f.write("表2数据待补充\n")
    
    print("指标计算完成（表格部分需根据实际字段补充）")
    return True

# ==================== 6. 命令行入口 ====================
if __name__ == '__main__':
    calculate_metrics()