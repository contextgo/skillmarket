# CHANGELOG

All notable changes to Synapse Skills will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-04-08

### Added

#### synapse-wiki
- **核心功能**:
  - `wiki_init` — 初始化新的 Wiki 知识库
  - `wiki_ingest` — 摄取源文件创建 Wiki 页面
  - `wiki_query` — 查询知识并综合答案
  - `wiki_lint` — 健康检查（死链接、孤立页面等）
- **Scripts**:
  - `scaffold.py` — 引导新的 Wiki 目录树
  - `ingest.py` — 摄取新资料，编译为 Wiki 页面
  - `query.py` — 查询 Wiki，综合答案
  - `lint_wiki.py` — 健康检查（死链接/孤立页/矛盾）
- **Commands**: `init.sh`, `ingest.sh`, `query.sh`, `lint.sh`
- **Tests**: 基线测试 4/4 通过

#### synapse-code
- **核心功能**:
  - `pipeline_init` — 初始化项目的 Synapse + Pipeline 环境
  - `pipeline_run` — 运行 Pipeline 交付代码
  - `synapse_log` — 手动触发 Synapse auto-log
  - `impact_check` — 检查代码变更影响范围
  - `status_check` — 检查项目状态
- **Scripts**:
  - `init_project.py` — 初始化项目环境
  - `run_pipeline.py` — 运行 Pipeline 并自动触发 auto-log (配置化)
  - `auto_log.py` — Synapse 自动记录脚本（内置）
  - `auto_log_trigger.py` — 触发 auto-log（配置化）
  - `check_status.py` — 检查项目状态
  - `infer_task_type.py` — 根据描述推断 task_type
  - `query_memory.py` — 查询记忆记录
- **Commands**: `init.sh`, `run.sh`, `log.sh`, `status.sh`, `query.sh`, `infer.sh`, `parallel.sh`
- **Tests**: 基线测试 3/3 通过

### Changed

- synapse-code 的 `run_pipeline.py` 和 `auto_log_trigger.py` 现在支持配置文件
- 移除了硬编码路径，使用 `config.json` 或 `config.template.json`
- `auto_log.py` 从外部依赖（synapse-core）改为内置脚本

### Deprecated

- 无

### Removed

- 移除了对 `~/.claude/skills/synapse-core/scripts/auto_log.py` 的硬依赖

### Fixed

- 配置化路径，支持用户自定义 Pipeline workspace 位置
- 增强错误处理和友好错误提示

### Security

- 无

---

## [0.1.0] - 2026-04-08 (Initial Draft)

### Added

- 初始版本创建
- 基线测试框架
