# Synapse Skills — OpenClaw Skill 包

基于 Karpathy LLM Wiki 模式的知识库管理系统 + Pipeline 代码交付工作流。

## 组成部分

### synapse-wiki
持久化 Wiki 构建 + 增量知识积累 + 自动健康维护

- **三层架构**: raw sources → wiki → outputs
- **核心操作**: Ingest（摄取）、Query（查询）、Lint（健康检查）
- **灵感来源**: [Karpathy llm-wiki Gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)

### synapse-code
Pipeline（交付）+ Synapse（沉淀）的整合工作流

- **项目初始化**: 自动检测并配置环境
- **Pipeline 运行**: REQ→ARCH→DEV→INT→QA→DEPLOY
- **Auto-Log**: 自动沉淀知识到记忆

## 安装方式

### 方式 1：使用安装脚本（推荐）

```bash
# 安装 synapse-code
cd ~/.claude/skills/synapse-code
./install.sh

# 安装 synapse-wiki
cd ~/.claude/skills/synapse-wiki
./install.sh
```

### 方式 2：手动复制

```bash
# 复制 synapse-wiki
cp -r synapse-wiki ~/.claude/skills/

# 复制 synapse-code  （不含 node_modules，安装时会自动安装 GitNexus）
cp -r synapse-code ~/.claude/skills/
```

**注意**: synapse-code 的 `node_modules/` 目录（GitNexus 依赖）不需要复制，`./install.sh` 会自动安装。复制后可手动运行一次 `npm install` 或重新执行安装脚本。

### 方式 3：使用 OpenClaw

```bash
claude skill install synapse-wiki.skill
claude skill install synapse-code.skill
```

## 依赖要求

### synapse-wiki
- Python 3.x ✓

### synapse-code
- Python 3.x ✓
- Pipeline workspace（需要用户自行配置）

**注**: synapse-code 已内建 GitNexus CLI（代码图谱分析），安装时通过 `npm install` 自动集成，无需单独安装。

## 配置说明

详见各技能的 `RELEASE.md` 和 `CHANGELOG.md`。

## 使用方法

### synapse-wiki 命令

```bash
# 初始化新知识库
/synapse-wiki init ~/my-wiki "AI 学习知识库"

# 摄取资料
/synapse-wiki ingest ~/my-wiki raw/articles/article.md

# 健康检查
/synapse-wiki lint ~/my-wiki

# 查询知识
/synapse-wiki query ~/my-wiki "LLM Wiki 的核心思想"
```

### synapse-code 命令

```bash
# 初始化项目
/synapse-code init ~/my-project

# 运行 Pipeline
/synapse-code run my-project "实现登录功能"

# 触发 auto-log
/synapse-code log ~/my-project

# 检查状态
/synapse-code status ~/my-project
```

## 基线测试

```bash
# 测试 synapse-wiki
cd ~/.claude/skills/synapse-wiki/synapse-wiki
python3 tests/baseline_test.py

# 测试 synapse-code
cd ~/.claude/skills/synapse-code
python3 tests/baseline_test.py
```

**测试结果**:
- synapse-wiki: **4/4 通过** (init, ingest, lint, query)
- synapse-code: **3/3 通过** (init_syntax, infer, status)

## 目录结构

```
synapse-wiki/
├── SKILL.md              # 技能定义（OpenClaw 格式）
├── .skillhub.json        # 技能元数据
├── README.md             # 本文档
├── tests/
│   └── baseline_test.py  # 基线测试
├── scripts/
│   ├── scaffold.py       # 初始化 Wiki 目录
│   ├── ingest.py         # 摄取源文件
│   ├── lint_wiki.py      # 健康检查
│   └── query.py          # 查询知识
└── commands/
    ├── init.sh
    ├── ingest.sh
    ├── lint.sh
    └── query.sh

synapse-code/
├── SKILL.md              # 技能定义（OpenClaw 格式）
├── .skillhub.json        # 技能元数据
├── README.md             # 本文档
├── tests/
│   └── baseline_test.py  # 基线测试
├── scripts/
│   ├── init_project.py   # 初始化项目
│   ├── run_pipeline.py   # 运行 Pipeline
│   ├── auto_log_trigger.py
│   ├── check_status.py
│   ├── infer_task_type.py
│   └── query_memory.py
└── commands/
    ├── init.sh
    ├── run.sh
    ├── log.sh
    ├── status.sh
    ├── query.sh
    └── parallel.sh
```

## 发布清单

- [x] SKILL.md 完成（符合 OpenClaw 格式）
- [x] .skillhub.json 配置（platform: openclaw）
- [x] scripts/ 目录完整
- [x] commands/ 目录完整
- [x] 基线测试通过（synapse-wiki: 4/4, synapse-code: 3/3）
- [x] README 文档完整
- [x] 配置化支持（config.json）
- [x] 安装脚本（install.sh）
- [x] 依赖嵌入（auto_log.py 内置）
- [x] 发布文档（CHANGELOG.md, RELEASE.md）

## 版本历史

- v1.0.0 (2026-04-08) — 初始公开发布版本

详见 [CHANGELOG.md](CHANGELOG.md) 和 [RELEASE.md](RELEASE.md)。

## 许可证

MIT
