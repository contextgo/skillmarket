#!/usr/bin/env python3
"""
infer_task_type.py — 根据需求描述推断 task_type（带学习率调度）

用法:
    python3 infer_task_type.py "需求描述文本"
    echo "修复登录 bug" | python3 infer_task_type.py

输出：JSON { "task_type": "...", "confidence": 0-1, "matched_keywords": [...] }
"""

import sys
import json
import re


# 基础配置
TASK_TYPE_PATTERNS = {
    "debug": {
        "keywords": ["bug", "error", "crash", "fails", "exception", "traceback", "报错", "错误", "崩溃", "失败"],
        "base_confidence": 0.9,
        "min_confidence": 0.7,
        "max_confidence": 0.95
    },
    "refactor": {
        "keywords": ["rename", "move", "extract", "refactor", "重构", "修复", "修改", "优化", "改进", "过时"],
        "base_confidence": 0.8,
        "min_confidence": 0.6,
        "max_confidence": 0.9
    },
    "review": {
        "keywords": ["review", "pr", "merge", "code review", "审查", "合并", "改动"],
        "base_confidence": 0.85,
        "min_confidence": 0.65,
        "max_confidence": 0.92
    },
    "design": {
        "keywords": ["design", "proposal", "rfc", "接口设计", "架构", "应该用", "还是", "方案"],
        "base_confidence": 0.75,
        "min_confidence": 0.55,
        "max_confidence": 0.85
    },
    "implementation": {
        "keywords": ["实现", "implement", "照着", "写代码", "开发", "功能", "模块", "接口"],
        "base_confidence": 0.7,
        "min_confidence": 0.5,
        "max_confidence": 0.8
    },
    "understand": {
        "keywords": ["是什么", "怎么工作", "what does", "how does", "理解", "understand", "调用链", "架构"],
        "base_confidence": 0.65,
        "min_confidence": 0.45,
        "max_confidence": 0.75
    }
}

# 负例排除（negative examples）
NEGATIVE_PATTERNS = {
    "debug": ["性能", "优化", "加速"],  # 性能优化不是 bug
    "implementation": ["理解", "学习", "阅读"],  # 学习需求不是实现
    "design": ["实现", "代码", "写"],  # 已经要实现了就不是纯设计
}


def apply_learning_rate_schedule(matches: list, text: str) -> list:
    """
    应用学习率调度（Learning Rate Scheduling）

    根据匹配质量动态调整 confidence:
    - 单一 task_type 匹配数 >> 其他 → 提高阈值增加信心
    - multiple task_types 匹配数接近 → 降低阈值返回 alternatives
    - 匹配关键词包含负例 → 降低信心

    Karpathy 原则："Learning Rate needs scheduling"
    """
    if not matches:
        return matches

    # 计算匹配分布
    max_match_count = max(m["match_count"] for m in matches)
    total_matched = sum(m["match_count"] for m in matches)

    for match in matches:
        task_type = match["task_type"]
        base_conf = TASK_TYPE_PATTERNS[task_type]["base_confidence"]
        min_conf = TASK_TYPE_PATTERNS[task_type]["min_confidence"]
        max_conf = TASK_TYPE_PATTERNS[task_type]["max_confidence"]

        # 1. 主导地位因子：如果这个 task_type 的匹配数远多于其他，提高信心
        dominance_ratio = match["match_count"] / max_match_count if max_match_count > 0 else 0
        if dominance_ratio >= 1.0 and match["match_count"] >= 2:
            # 绝对主导：提高信心 10-15%
            confidence_boost = 0.10 + (match["match_count"] - 1) * 0.025
        elif dominance_ratio >= 0.5:
            # 相对主导：提高信心 5%
            confidence_boost = 0.05
        else:
            # 非主导：不提高
            confidence_boost = 0

        # 2. 模糊性因子：如果多个 task_type 匹配数接近，降低信心
        if len(matches) >= 2:
            top_two_ratio = matches[0]["match_count"] / max(matches[1]["match_count"], 1)
            if top_two_ratio < 1.5:
                # 前两个很接近，降低信心 10%
                confidence_boost -= 0.10

        # 3. 负例排除因子
        if task_type in NEGATIVE_PATTERNS:
            for neg in NEGATIVE_PATTERNS[task_type]:
                if neg.lower() in text.lower():
                    confidence_boost -= 0.15
                    match.setdefault("negative_matches", []).append(neg)

        # 应用调度，限制在 min/max 范围内
        adjusted_conf = base_conf + confidence_boost
        adjusted_conf = max(min_conf, min(max_conf, adjusted_conf))
        match["confidence"] = adjusted_conf

        # 计算调度信息
        match["confidence_delta"] = round(confidence_boost, 3)
        match["dominance_ratio"] = round(dominance_ratio, 3)

    # 重新排序
    matches.sort(key=lambda x: (-x["match_count"], -x["confidence"]))

    return matches


def infer_task_type(text: str, base_threshold: float = 0.6) -> dict:
    """
    Infer task_type from text with learning rate scheduling.

    Args:
        text: Input requirement description
        base_threshold: Base confidence threshold (default 0.6)

    Returns:
        dict with task_type, confidence, and scheduling info
    """
    text_lower = text.lower()

    matches = []
    for task_type, config in TASK_TYPE_PATTERNS.items():
        matched = [kw for kw in config["keywords"] if kw.lower() in text_lower]
        if matched:
            matches.append({
                "task_type": task_type,
                "base_confidence": config["base_confidence"],
                "confidence": config["base_confidence"],
                "matched_keywords": matched,
                "match_count": len(matched)
            })

    if not matches:
        return {
            "task_type": "unknown",
            "confidence": 0.5,
            "matched_keywords": [],
            "fallback": "implementation",
            "scheduling_applied": False
        }

    # 应用学习率调度
    matches = apply_learning_rate_schedule(matches, text)
    best = matches[0]

    return {
        "task_type": best["task_type"],
        "confidence": round(best["confidence"], 3),
        "base_confidence": best["base_confidence"],
        "matched_keywords": best["matched_keywords"],
        "alternatives": [m["task_type"] for m in matches[1:3]] if len(matches) > 1 else [],
        "scheduling_info": {
            "confidence_delta": best.get("confidence_delta", 0),
            "dominance_ratio": best.get("dominance_ratio", 0),
            "negative_matches": best.get("negative_matches", [])
        },
        "scheduling_applied": True
    }


def main():
    if len(sys.argv) < 2:
        # Read from stdin
        text = sys.stdin.read().strip()
    else:
        text = sys.argv[1]

    if not text:
        print(json.dumps({"error": "No input text provided"}))
        sys.exit(1)

    result = infer_task_type(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
