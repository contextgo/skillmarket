#!/usr/bin/env python3
"""
check_status.py — 检查项目 Synapse + Pipeline 状态

用法:
    python3 check_status.py /path/to/project

检查内容:
1. .knowledge/ 目录存在性和健康度
2. .synapse/ 目录存在性和 memory 记录数
3. .gitnexus/ 目录存在性和新鲜度
4. Pipeline 项目状态
"""

import sys
import subprocess
from pathlib import Path
from datetime import datetime


def check_knowledge(project: Path) -> dict:
    """Check Wiki Layer status."""
    knowledge_dir = project / ".knowledge"
    result = {"exists": False, "files": [], "log_entries": 0}

    if not knowledge_dir.exists():
        return result

    result["exists"] = True

    # Check required files
    required_files = ["CLAUDE.md", "log.md", "index.md"]
    for f in required_files:
        if (knowledge_dir / f).exists():
            result["files"].append(f)

    # Count log entries
    log_path = knowledge_dir / "log.md"
    if log_path.exists():
        content = log_path.read_text()
        result["log_entries"] = content.count("## [")

    # Check pages directories
    pages_dir = knowledge_dir / "pages"
    if pages_dir.exists():
        result["pages"] = [d.name for d in pages_dir.iterdir() if d.is_dir()]

    return result


def check_synapse(project: Path) -> dict:
    """Check Synapse memory status."""
    synapse_dir = project / ".synapse"
    result = {"exists": False, "memory_count": 0, "task_types": {}}

    if not synapse_dir.exists():
        return result

    result["exists"] = True

    memory_dir = synapse_dir / "memory"
    if memory_dir.exists():
        for task_type_dir in memory_dir.iterdir():
            if task_type_dir.is_dir():
                count = len(list(task_type_dir.glob("*.md")))
                result["memory_count"] += count
                result["task_types"][task_type_dir.name] = count

    return result


def get_gitnexus_bin() -> str:
    """Get path to gitnexus binary (bundled or global)."""
    # Try bundled version first
    bundled = Path(__file__).parent.parent / "node_modules" / ".bin" / "gitnexus"
    if bundled.exists():
        return str(bundled)
    # Fallback to global
    return "gitnexus"


def check_gitnexus(project: Path) -> dict:
    """Check Code Layer status."""
    gitnexus_dir = project / ".gitnexus"
    result = {"exists": False, "fresh": False, "last_analyzed": None}

    if not gitnexus_dir.exists():
        return result

    result["exists"] = True

    # Check freshness via gitnexus status
    gitnexus_bin = get_gitnexus_bin()
    try:
        proc = subprocess.run(
            [gitnexus_bin, "status"],
            cwd=project,
            capture_output=True,
            text=True,
            timeout=10
        )
        output = proc.stdout.lower()
        result["fresh"] = "up-to-date" in output or "current" in output

        # Try to extract last analyzed time
        for line in proc.stdout.split("\n"):
            if "last analyzed" in line.lower() or "indexed" in line.lower():
                result["last_analyzed"] = line.strip()
    except Exception as e:
        result["error"] = str(e)

    return result


def check_pipeline(project: Path, pipeline_workspace: Path) -> dict:
    """Check Pipeline project status."""
    project_name = project.name
    pipeline_project = pipeline_workspace / project_name
    result = {"exists": False, "phase": "unknown", "contracts": []}

    if not pipeline_project.exists():
        return result

    result["exists"] = True

    # Check contract_board.db
    db_path = pipeline_project / "contract_board.db"
    if db_path.exists():
        result["db_exists"] = True

    # Try to get phase from pipeline status
    try:
        proc = subprocess.run(
            ["python3", "pipeline.py", "status", project_name],
            cwd=pipeline_workspace,
            capture_output=True,
            text=True,
            timeout=10
        )
        output = proc.stdout
        for line in output.split("\n"):
            if "current phase" in line.lower():
                result["phase"] = line.split(":")[-1].strip()
            if "contracts" in line.lower() or "[req]" in line.lower() or "[arch]" in line.lower():
                result["contracts"].append(line.strip())
    except Exception as e:
        result["error"] = str(e)

    return result


def print_status(project_name: str, knowledge: dict, synapse: dict, gitnexus: dict, pipeline: dict):
    """Print formatted status report."""
    print(f"\n{'='*60}")
    print(f"Synapse + Pipeline Status: {project_name}")
    print(f"{'='*60}\n")

    # Wiki Layer
    print("Wiki Layer (.knowledge/):")
    if knowledge["exists"]:
        print(f"  ✓ Directory exists")
        print(f"  Files: {', '.join(knowledge['files']) if knowledge['files'] else 'None'}")
        print(f"  Log entries: {knowledge['log_entries']}")
        if knowledge.get("pages"):
            print(f"  Pages: {', '.join(knowledge['pages'])}")
    else:
        print(f"  ✗ Not initialized")
    print()

    # Synapse Memory
    print("Synapse Memory (.synapse/memory/):")
    if synapse["exists"]:
        print(f"  ✓ Directory exists")
        print(f"  Total records: {synapse['memory_count']}")
        for task_type, count in synapse["task_types"].items():
            print(f"    - {task_type}: {count}")
    else:
        print(f"  ✗ Not initialized")
    print()

    # Code Layer
    print("Code Layer (.gitnexus/):")
    if gitnexus["exists"]:
        print(f"  ✓ Directory exists")
        print(f"  Fresh: {'Yes' if gitnexus.get('fresh') else 'No - run gitnexus analyze --force'}")
        if gitnexus.get("last_analyzed"):
            print(f"  {gitnexus['last_analyzed']}")
        if gitnexus.get("error"):
            print(f"  Error: {gitnexus['error']}")
    else:
        print(f"  ✗ Not initialized")
    print()

    # Pipeline
    print("Pipeline Status:")
    if pipeline["exists"]:
        print(f"  ✓ Project exists")
        print(f"  Current phase: {pipeline['phase']}")
        if pipeline.get("contracts"):
            print(f"  Contracts:")
            for c in pipeline["contracts"][:5]:
                print(f"    {c}")
    else:
        print(f"  ✗ Not created in pipeline-workspace")
    print()

    print(f"{'='*60}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 check_status.py /path/to/project")
        sys.exit(1)

    project = Path(sys.argv[1]).resolve()
    pipeline_workspace = Path.home() / "pipeline-workspace"

    if not project.exists():
        print(f"Error: Project directory {project} does not exist")
        sys.exit(1)

    print(f"Checking status for {project}...")

    # Run all checks
    knowledge = check_knowledge(project)
    synapse = check_synapse(project)
    gitnexus = check_gitnexus(project)
    pipeline = check_pipeline(project, pipeline_workspace)

    # Print status report
    print_status(project.name, knowledge, synapse, gitnexus, pipeline)

    # Recommendations
    recommendations = []
    if not knowledge["exists"]:
        recommendations.append("Run: python3 ~/.claude/skills/synapse-core/scripts/scaffold.py {}".format(project))
    if not gitnexus["exists"] or not gitnexus.get("fresh"):
        recommendations.append("Run: cd {} && gitnexus analyze --force".format(project))
    if not pipeline["exists"]:
        recommendations.append("Run: cd {} && python3 pipeline.py new {}".format(pipeline_workspace, project.name))

    if recommendations:
        print("\nRecommendations:")
        for r in recommendations:
            print(f"  → {r}")


if __name__ == "__main__":
    main()
