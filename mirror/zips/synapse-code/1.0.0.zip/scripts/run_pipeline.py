#!/usr/bin/env python3
"""
run_pipeline.py — 运行 Pipeline 并自动触发 auto-log（配置化版本）

用法:
    python3 run_pipeline.py project_name "需求描述"
    python3 run_pipeline.py project_name --input "需求描述"

功能:
1. 运行 pipeline.py run-pipeline
2. 成功后自动调用 auto_log_trigger.py
"""

import sys
import json
import subprocess
import argparse
from pathlib import Path


def load_config() -> dict:
    """Load configuration from config.json or use defaults."""
    config_file = Path(__file__).parent / "config.json"
    default_config = {
        "pipeline": {
            "workspace": "~/pipeline-workspace",
            "enabled": True,
            "auto_log": True
        },
        "paths": {
            "pipeline_script": "~/pipeline-workspace/pipeline.py",
            "pipeline_summary": "/tmp/pipeline_summary.json"
        }
    }

    if config_file.exists():
        try:
            with open(config_file) as f:
                config = json.load(f)
                # Merge with defaults
                for key in default_config:
                    if key not in config:
                        config[key] = default_config[key]
                return config
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not load config.json, using defaults: {e}")

    return default_config


def expand_path(path: str) -> Path:
    """Expand ~ to home directory."""
    return Path(path).expanduser()


def run_pipeline(project_name: str, input_text: str, config: dict, verbose: bool = False) -> bool:
    """Run pipeline run-pipeline command."""
    pipeline_workspace = expand_path(config.get("pipeline", {}).get("workspace", "~/pipeline-workspace"))
    pipeline_script = expand_path(config.get("paths", {}).get("pipeline_script", "~/pipeline-workspace/pipeline.py"))

    if not pipeline_workspace.exists():
        print(f"Error: Pipeline workspace not found: {pipeline_workspace}")
        print("Please ensure pipeline-workspace is installed or update config.json")
        return False

    if not pipeline_script.exists():
        print(f"Error: pipeline.py not found at {pipeline_script}")
        print("Please ensure pipeline is installed or update config.json")
        return False

    cmd = [
        "python3", str(pipeline_script), "run-pipeline", project_name,
        "--input", input_text
    ]

    if verbose:
        cmd.append("--verbose")

    try:
        result = subprocess.run(
            cmd,
            cwd=pipeline_workspace,
            capture_output=True,
            text=True,
            timeout=600  # 10 minutes timeout
        )

        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)

        return result.returncode == 0
    except subprocess.TimeoutExpired:
        print("Error: Pipeline execution timed out (10 minutes)", file=sys.stderr)
        return False
    except FileNotFoundError:
        print(f"Error: pipeline.py not found at {pipeline_script}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"Error running pipeline: {e}", file=sys.stderr)
        return False


def run_auto_log(project_path: Path, config: dict) -> bool:
    """Run auto_log_trigger.py after successful pipeline."""
    auto_log_script = Path(__file__).parent / "auto_log_trigger.py"

    if not auto_log_script.exists():
        print(f"Warning: auto_log_trigger.py not found at {auto_log_script}")
        print("Skipping auto-log...")
        return True

    try:
        result = subprocess.run(
            ["python3", str(auto_log_script), str(project_path)],
            capture_output=True,
            text=True
        )

        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)

        return result.returncode == 0
    except Exception as e:
        print(f"Error running auto-log: {e}", file=sys.stderr)
        return False


def main():
    # Load configuration
    config = load_config()

    parser = argparse.ArgumentParser(description="Run pipeline with auto-log")
    parser.add_argument("project_name", help="Project name")
    parser.add_argument("--input", "-i", dest="input_text", help="Requirement description")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument("--skip-auto-log", action="store_true", help="Skip auto-log after pipeline")
    parser.add_argument("--config", help="Path to config.json (default: ./config.json)")

    args = parser.parse_args()

    # Handle input text from various sources
    if not args.input_text:
        remaining = sys.argv[1:]
        for i, arg in enumerate(remaining):
            if arg in ["--input", "-i"] and i + 1 < len(remaining):
                args.input_text = remaining[i + 1]
                break
        else:
            input_parts = [a for a in remaining[1:] if not a.startswith("-")]
            if input_parts:
                args.input_text = " ".join(input_parts)

    if not args.input_text:
        print("Error: --input or requirement text required")
        parser.print_help()
        sys.exit(1)

    project_name = args.project_name
    input_text = args.input_text
    pipeline_workspace = expand_path(config.get("pipeline", {}).get("workspace", "~/pipeline-workspace"))
    project_path = pipeline_workspace / project_name

    print(f"Running Pipeline for project: {project_name}")
    print(f"Input: {input_text}")
    print("=" * 60)

    # Step 1: Run pipeline
    print("[1/2] Running pipeline...")
    if not run_pipeline(project_name, input_text, config, args.verbose):
        print("Pipeline failed. Skipping auto-log.")
        sys.exit(1)

    print("Pipeline completed successfully!")

    # Step 2: Run auto-log
    skip_auto_log = args.skip_auto_log or not config.get("pipeline", {}).get("auto_log", True)

    if not skip_auto_log:
        print("\n[2/2] Triggering auto-log...")
        if not run_auto_log(project_path, config):
            print("Auto-log failed, but pipeline succeeded.")
            sys.exit(1)
        print("\nAll done! Knowledge recorded to Synapse.")
    else:
        print("\nAuto-log skipped")

    print()
    print("Summary:")
    print(f"  Pipeline workspace: {pipeline_workspace}")
    print(f"  Project: {project_path}")
    if not skip_auto_log:
        print(f"  Knowledge: {project_path}/.knowledge/log.md")
        print(f"  Memory: {project_path}/.synapse/memory/")


if __name__ == "__main__":
    main()
