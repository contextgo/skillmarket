---
name: synapse-code
description: >
  Synapse Code — 智能代码开发工作流引擎。
  一体化完成项目初始化、代码交付、知识沉淀和影响分析。
  内建代码图谱引擎，越用越懂你的项目。
  当用户提到开发、实现功能、运行 pipeline、记录知识、检查影响范围时使用此技能。
version: 1.0.0
date: 2026-04-08
metadata:
  {
    "openclaw":
      {
        "emoji": "⚡",
        "requires": { "bins": ["python3"] },
        "install": [],
      },
  }
tags: [pipeline, workflow, knowledge-management, code-analysis, development]
---

# Synapse Code Skill

**Synapse Code = 代码交付 + 知识沉淀 一体化工作流**

核心理念：开发不仅是写代码，更是知识积累的过程。

| | 传统开发 | Synapse Code |
|--|---------|--------------|
| **知识留存** | 随会话消失 | 自动沉淀到项目记忆 |
| **影响分析** | 手动追踪调用链 | 一键查询影响范围 |
| **项目状态** | 靠记忆回忆 | 实时可视化的进度 |
| **团队协作** | 口头传递上下文 | 可查询的知识库 |

## 功能范围

1. **项目初始化检测** — 自动检测 `.knowledge/` `.synapse/` `.gitnexus/` 是否存在
2. **Pipeline 命令封装** — 提供简洁的 `pipeline run` 命令
3. **Auto-Log 触发** — Pipeline 成功后自动调用 `auto_log.py`
4. **Task Type 推断** — 根据需求描述自动推断 task_type
5. **代码图谱分析** — 内建 GitNexus 引擎，支持影响分析和调用链追踪

## 命令

### 初始化命令

```bash
# 初始化项目的 Synapse + Pipeline 环境
/synapse-code init [project_path]
```

执行内容：
1. 检测 `.git/` 存在
2. 调用 `scaffold.py` 创建 `.knowledge/` `.synapse/` 目录
3. 调用 `gitnexus analyze --force` 建图
4. 创建 pipeline 项目

### Pipeline 命令

```bash
# 运行完整 Pipeline
/synapse-code run [project_name] "需求描述"
```

### Auto-Log 命令

```bash
# 手动触发 auto-log
/synapse-code log [project_path]
```

### 状态检查命令

```bash
# 检查项目状态
/synapse-code status [project_path]
```

### 记忆查询命令

```bash
# 查询特定 task_type 的历史记录
/synapse-code query [project_path] --task-type debug --limit 5

# 按关键词搜索记录
/synapse-code query [project_path] --contains "登录 bug"
```

## Scripts

| 脚本 | 用途 |
|------|------|
| `scripts/init_project.py` | 初始化项目环境（含合约验证） |
| `scripts/run_pipeline.py` | 运行 Pipeline 并自动触发 auto-log |
| `scripts/auto_log_trigger.py` | 消费 pipeline_summary.json 写入 memory |
| `scripts/check_status.py` | 检查项目状态 |
| `scripts/infer_task_type.py` | 根据描述推断 task_type |
| `scripts/query_memory.py` | 查询记忆记录 |

## 使用场景

- 🚀 **新项目初始化** — 30 秒搭建完整开发环境
- 💻 **功能开发** — 运行 Pipeline 交付高质量代码
- 📝 **知识沉淀** — 自动记录开发经验，下次不再踩坑
- 🔍 **影响分析** — 改动前一键查询影响范围，避免事故
- 📊 **项目状态** — 实时查看开发进度和知识积累

## 安装

```bash
# 方式 1: 使用安装脚本（推荐）
cd ~/.claude/skills/synapse-code
./install.sh

# 方式 2: 手动复制
cp -r synapse-code ~/.claude/skills/

# 方式 3: OpenClaw (如有 .skill 文件)
claude skill install synapse-code.skill
```

安装后会自动创建 `config.json`，根据需要修改 Pipeline workspace 路径。

## 配置

编辑 `~/.claude/skills/synapse-code/config.json`:

```json
{
  "pipeline": {
    "workspace": "~/pipeline-workspace",
    "enabled": true,
    "auto_log": true
  },
  "paths": {
    "pipeline_script": "~/pipeline-workspace/pipeline.py",
    "pipeline_summary": "/tmp/pipeline_summary.json"
  }
}
```

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `pipeline.workspace` | Pipeline 工作目录 | `~/pipeline-workspace` |
| `pipeline.auto_log` | Pipeline 成功后自动记录知识 | `true` |
| `paths.pipeline_script` | pipeline.py 路径 | `~/pipeline-workspace/pipeline.py` |
| `paths.pipeline_summary` | Pipeline 输出摘要路径 | `/tmp/pipeline_summary.json` |

## 相关文件

- `/Users/leo/pipeline-workspace/pipeline.py` — Pipeline 引擎
- `~/.claude/skills/synapse-code/scripts/auto_log.py` — Auto-log 脚本（内置）
- `/Users/leo/pipeline-workspace/SYNAPSE_INTEGRATION.md` — 整合文档
