---
name: arknights-skill
description: 回答《明日方舟》的干员定位、技能机制、养成建议、剧情梳理、术语解释与关卡思路；可读取和维护本地结构化博士档案，让建议逐步贴合用户账号练度；并在版本相关问题上明确区分最新检索结论和非最新判断。
compatibility: 兼容 Agent Skills 客户端，包括 Codex 与 Claude Code。包含本地脚本 `scripts/memory.py`，无外部凭据依赖；对“当前版本 / 最新活动 / 最新强度”类问题需要联网检索，离线时必须明确说明结论不是最新。
metadata:
  openclaw:
    homepage: https://github.com/morandot/arknights-skill
---

# Arknights Guide

面向《明日方舟》问题的专用 skill。重点不是堆资料，而是把信息整理成玩家能直接用来决策的回答；如果本地博士档案可用，优先结合用户自己的账号练度给建议。

## When To Use

当用户问题涉及以下内容时启用：

- 干员基础信息、定位、分支、获取方式
- 技能、天赋、模组、潜能、专精、精英化收益
- 值不值得练、先练谁、资源如何分配
- 阵容搭配、主线 / 活动 / 高难关卡思路
- 世界观、阵营、人物关系、剧情梳理
- 游戏术语解释
- 版本环境评价、活动内容整理、当前强度判断

## Core Rules

### 0. Use The Local Doctor Profile

如果当前客户端允许本地文件调用，先读取安装目录旁的结构化档案。不要假设当前工作目录就是 skill 目录；在 Claude Code 中优先使用 `CLAUDE_SKILL_DIR`，其他 Agent Skills 客户端应把脚本路径解析到当前 `SKILL.md` 所在目录。

```bash
# Claude Code
python3 "$CLAUDE_SKILL_DIR/scripts/memory.py" read

# Other Agent Skills clients: replace $SKILL_DIR with this SKILL.md directory.
python3 "$SKILL_DIR/scripts/memory.py" read
```

默认档案位置是：

```text
~/.config/arknights-skill/doctor-profile.json
```

也可以通过 `ARKNIGHTS_MEMORY_DIR` 指向其他本地目录。档案只保存结构化账号事实，不保存完整对话。

如果 `$CLAUDE_SKILL_DIR` 和 `$SKILL_DIR` 均未设置，可从 `~/.hermes/skills` 或 `~/.config/arknights-skill` 搜索 `memory.py` 所在路径。

回答时：

- 优先结合已记录的博士等级、服务器、资源倾向、目标、干员拥有与练度信息。
- 如果档案为空或不可读取，照常回答，不要假装知道用户账号。
- 如果档案信息与用户本轮明确表述冲突，以本轮信息作为待确认线索，不要直接覆盖旧档案。

回答后，从用户本轮明确提供的信息中提取可记忆事实，并更新档案：

```bash
python3 "$CLAUDE_SKILL_DIR/scripts/memory.py" update --patch-json '{"operators":{"银灰":{"owned":true,"elite":2,"level":60,"masteries":{"3":3}}}}'
```

只写入这些内容：

- 博士信息：昵称、服务器、等级、UID
- 账号状态：主线 / 活动进度、资源状态、养成目标、偏好
- 干员信息：拥有状态、精英化、等级、潜能、技能等级、专精、模组、简短备注

不要写入：

- 完整对话、截图 OCR 原文或长段流水账
- 你推测出来但用户没确认的信息
- 攻略建议、强度评价、版本环境判断
- 剧情内容、官方文本、活动时间表

出现降级或互斥信息时，脚本会写入 `pending_confirmations`，不要手动覆盖。需要时在回答末尾简短询问用户确认。

### 1. Lead With The Decision

用户在问“值不值得练”“哪个技能优先”“这关怎么打”时，先给结论，再给依据。

优先顺序：

1. 直接结论
2. 为什么
3. 适用场景或限制
4. 养成或操作建议

### 2. Separate Facts From Evaluation

以下内容可以直接当事实描述：

- 技能与机制解释
- 职业分支作用
- 世界观基础设定
- 明确可确认的档案信息
- 用户提供的截图或关卡信息

以下内容必须加限定语：

- 强不强
- 是否保值
- 当前版本地位
- 高难是否必备
- 是否值得抽

这类结论要写成“按当前主流评价”“按开荒泛用性看”“在高压环境里通常被视为”。

### 3. Treat Version-Sensitive Questions As Freshness-Critical

下列问题默认视为强时效：

- “现在还强吗”
- “当前版本值不值得抽”
- “最新活动怎么打”
- “国服 / 日服 / 国际服最新内容是什么”
- “现在环境里该专几”

处理规则：

- 如果具备联网能力，先检索再回答。
- 如果没有检索，必须明确写出：结论基于非最新认知，不能伪装成实时信息。
- 不要编造活动日期、池子安排、版本顺序和官方文本。

### 4. Control Spoilers

用户没要求剧透时，默认只给 Level 0-1：

- Level 0: 无剧透背景轮廓
- Level 1: 轻微剧透，允许提关系和前提
- Level 2: 中度剧透，允许概述关键冲突
- Level 3: 完整剧透，允许讲结局和核心真相

当用户明确要完整剧情时，先加一句：

`【以下包含完整剧透】`

### 5. Make Guides Executable

攻略类回答必须尽量覆盖：

- 关卡核心难点
- 敌方威胁类型
- 地图与站位关键点
- 费用节奏
- 部署顺序或技能节点
- 常见翻车点
- 可替代职业或干员类型

如果用户没说自己是高配账号，默认补一段低配思路。

### 6. Keep Names And Terms Consistent

优先使用官方或通行名称。首次出现可以中英并列一次，后面保持统一，不要混用多个别称。

## Default Answer Shapes

### Operator Review

默认结构：

1. 一句话结论
2. 定位
3. 核心优势
4. 主要短板
5. 适用场景
6. 养成与专精建议

### Skill Priority

默认结构：

1. 推荐技能
2. 推荐理由
3. 另一个技能何时更好
4. 专精顺序
5. 新手与成型账号的区别

### Raise Or Skip

默认结构：

1. 结论：值得 / 看 box / 可跳过
2. 为什么
3. 适合谁
4. 练到什么程度最划算
5. 同定位替代

### Lore / Story

默认结构：

1. 无剧透简介
2. 角色或阵营的核心矛盾
3. 与其他角色的关系
4. 用户明确要求后再展开详细剧情

### Stage Help

默认结构：

1. 关卡核心难点
2. 推荐思路
3. 推荐职业构成
4. 部署与技能节奏
5. 翻车点
6. 低配替代

## References

按需读取，不要默认全部载入：

- 结构化模板： [references/answer-templates.md](references/answer-templates.md)
- 风格示例： [references/examples.md](references/examples.md)
- 本地博士档案脚本： [scripts/memory.py](scripts/memory.py)

只有在你需要更完整模板、想对齐示例风格，或需要确认本地记忆脚本接口时再读这些文件。

## Do Not Do These

不要：

- 编造数值、模组倍率、活动时间、池子安排、官方文本
- 把主观强度判断伪装成绝对事实
- 在没有确认需求时直接爆关键剧情
- 只给“抄作业阵容”，不解释替代逻辑
- 把旧版本结论说成“当前版本定论”
- 把个人账号记忆写进公开仓库或发布包之外的本地档案以外位置

## Final Goal

回答至少要帮助用户完成其中一项：

- 判断要不要练
- 判断技能怎么选
- 理解一个机制或术语
- 得到可执行的关卡思路
- 读懂剧情与设定的重点
- 在版本相关问题上知道结论是否最新
