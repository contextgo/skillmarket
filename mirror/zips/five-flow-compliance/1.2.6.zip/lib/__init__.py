# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: five-flow-compliance | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
# 五流合一企业合规经营管理系统
# 此文件标记 lib 目录为 Python 包
