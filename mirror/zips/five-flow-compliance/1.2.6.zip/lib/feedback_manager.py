# -*- coding: utf-8 -*-
"""
用户反馈收集模块（本地存储版）

功能：
- 记录用户使用过程中遇到的问题
- 本地 JSON 文件持久化存储
- 支持导出反馈记录供用户自行处理
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: five-flow-compliance | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict


# 反馈文件路径（由 FeedbackManager 初始化时设置）
FEEDBACK_DIR = None


class FeedbackManager:
    """反馈管理器 - 仅本地存储，不发送任何外部数据"""

    def __init__(self, data_dir: Path = None):
        if data_dir is None:
            skill_dir = Path(__file__).parent.parent
            data_dir = skill_dir / 'data'

        self.data_dir = Path(data_dir)
        self.feedback_dir = self.data_dir / 'feedback'
        self.feedback_dir.mkdir(parents=True, exist_ok=True)

        self.issues_file = self.feedback_dir / 'issues.json'
        self.history_file = self.feedback_dir / 'history.json'

        self._load_issues()
        self._load_history()

    def _load_issues(self):
        """加载问题列表"""
        if self.issues_file.exists():
            with open(self.issues_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.issues = data.get('issues', [])
        else:
            self.issues = []

    def _load_history(self):
        """加载历史记录"""
        if self.history_file.exists():
            with open(self.history_file, 'r', encoding='utf-8') as f:
                self.history = json.load(f)
        else:
            self.history = []

    def _save_issues(self):
        """保存问题列表"""
        data = {
            'issues': self.issues,
            'count': len(self.issues),
            'updated': datetime.now().isoformat()
        }
        with open(self.issues_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _save_history(self):
        """保存历史记录"""
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, ensure_ascii=False, indent=2)

    def add_issue(self, issue: str, context: str = '',
                  session_id: str = '', user_id: str = '') -> Dict:
        """添加一个问题（仅本地存储）

        Args:
            issue: 问题描述（必填）
            context: 上下文/场景描述
            session_id: 会话ID
            user_id: 用户标识

        Returns:
            包含添加结果
        """
        issue_entry = {
            'id': len(self.issues) + 1,
            'content': issue,
            'context': context,
            'session_id': session_id,
            'user_id': user_id,
            'timestamp': datetime.now().isoformat()
        }

        self.issues.append(issue_entry)
        self._save_issues()

        return {
            'added': True,
            'total_count': len(self.issues),
            'issue_id': issue_entry['id']
        }

    def get_issues(self, limit: int = 100) -> List[Dict]:
        """获取问题列表"""
        return self.issues[-limit:]

    def get_count(self) -> int:
        """获取问题数量"""
        return len(self.issues)

    def clear_issues(self, issue_ids: List[int] = None):
        """清除问题

        Args:
            issue_ids: 要清除的问题ID列表，None=全部清除
        """
        if issue_ids is None:
            self.issues = []
        else:
            self.issues = [i for i in self.issues if i['id'] not in issue_ids]

        self._save_issues()

    def export_feedback(self) -> str:
        """导出反馈报告（本地文件，无外部传输）

        Returns:
            报告文件路径
        """
        now = datetime.now()

        report_lines = [
            "=" * 60,
            "五流合一企业合规经营管理系统 - 用户反馈记录",
            "=" * 60,
            f"导出时间: {now.strftime('%Y-%m-%d %H:%M:%S')}",
            f"问题总数: {len(self.issues)}",
            "=" * 60,
            "",
            "【问题列表】",
            "-" * 60
        ]

        for issue in sorted(self.issues, key=lambda x: x['timestamp'], reverse=True):
            report_lines.extend([
                f"[#{issue['id']}] {issue['timestamp']}",
                f"问题: {issue['content']}",
                f"场景: {issue['context'] or '通用场景'}",
                "-" * 40
            ])

        report_lines.extend([
            "",
            "=" * 60,
            "【使用说明】",
            "本反馈记录仅保存在本地文件，不会上传或发送给任何人。",
            "如需反馈给作者，请手动复制上述内容。",
            ""
        ])

        report_text = '\n'.join(report_lines)

        report_filename = f"feedback_export_{now.strftime('%Y%m%d_%H%M%S')}.txt"
        report_file = self.feedback_dir / report_filename

        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_text)

        # 记录导出历史
        self.history.append({
            'timestamp': now.isoformat(),
            'report_file': report_filename,
            'issue_count': len(self.issues),
            'action': 'export'
        })
        self._save_history()

        return str(report_file)

    def get_history(self) -> List[Dict]:
        """获取导出历史"""
        return self.history[-30:]


def main():
    """命令行测试"""
    import sys

    fm = FeedbackManager()

    if len(sys.argv) < 2:
        print("用法:")
        print("  python feedback_manager.py add <问题描述>")
        print("  python feedback_manager.py list")
        print("  python feedback_manager.py count")
        print("  python feedback_manager.py export")
        print("  python feedback_manager.py clear")
        return

    cmd = sys.argv[1]

    if cmd == 'add':
        if len(sys.argv) < 3:
            print("请提供问题描述")
            return
        issue = sys.argv[2]
        context = sys.argv[3] if len(sys.argv) > 3 else ''

        result = fm.add_issue(issue, context)
        print(f"[OK] 问题已添加 (共 {result['total_count']} 条)")

    elif cmd == 'list':
        issues = fm.get_issues()
        if not issues:
            print("暂无问题记录")
            return

        for i in issues:
            print(f"  [#{i['id']}] {i['timestamp']}: {i['content']}")

    elif cmd == 'count':
        print(f"当前问题数量: {fm.get_count()}")

    elif cmd == 'export':
        path = fm.export_feedback()
        print(f"[OK] 反馈已导出到本地: {path}")

    elif cmd == 'clear':
        fm.clear_issues()
        print("[OK] 问题已清除")


if __name__ == '__main__':
    main()
