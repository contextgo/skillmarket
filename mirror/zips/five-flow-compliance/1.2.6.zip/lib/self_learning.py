"""
five-flow-compliance 自学习模块

功能：
- 记录 OCR 识别结果，积累发票/合同/流水字段模板
- 追踪合规检查规则命中率
- 检测政策变化（税负率阈值、费率调整）
- 自动发现新发票类型和字段格式
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: five-flow-compliance | Version: 0.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import json
from pathlib import Path
from datetime import datetime

LEARN_FILE = Path(__file__).parent.parent / "data" / "five_flow_learn.json"

DEFAULT_LEARN_DATA = {
    "version": 1,
    "skill_name": "five-flow-compliance",
    "last_success_date": None,
    "fail_streak": 0,
    "total_runs": 0,
    "total_success": 0,
    "total_failure": 0,
    "parameters": {
        # OCR 识别关键词模板
        "invoice_keywords": ["价税合计", "不含税金额", "税额", "税率", "发票号码", "开票日期"],
        "contract_keywords": ["合同金额", "甲方", "乙方", "合同编号", "签订日期"],
        "bank_keywords": ["交易金额", "对方账户", "交易日期", "交易类型"],
        # 合规检查阈值
        "tax_burden_warning_threshold": 0.15,  # 税负率偏差>15%预警
        "cost_ratio_warning_threshold": 0.30,  # 成本费用比例>30%预警
    },
    "discoveries": [],
    "environment": {
        "last_policy_update": None,
        "supported_invoice_types": ["增值税专用发票", "增值税普通发票", "机动车销售统一发票"],
    },
    "history": [],
}


def load_learn() -> dict:
    """加载经验文件"""
    if LEARN_FILE.exists():
        try:
            return json.loads(LEARN_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, Exception):
            pass
    # 初始化目录
    LEARN_FILE.parent.mkdir(parents=True, exist_ok=True)
    return json.loads(json.dumps(DEFAULT_LEARN_DATA))


def save_learn(data: dict):
    """保存经验文件（历史只保留最近30条）"""
    if len(data.get("history", [])) > 30:
        data["history"] = data["history"][-30:]
    LEARN_FILE.parent.mkdir(parents=True, exist_ok=True)
    LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def record_success(data: dict, params_used: dict = None, env_info: dict = None):
    """记录成功执行"""
    data["last_success_date"] = datetime.now().strftime("%Y-%m-%d")
    data["fail_streak"] = 0
    data["total_runs"] = data.get("total_runs", 0) + 1
    data["total_success"] = data.get("total_success", 0) + 1
    if params_used:
        data["parameters"].update(params_used)
    if env_info:
        data["environment"].update(env_info)
    # 成功后将 discoveries 提升为正式参数
    for d in data.get("discoveries", []):
        category = d.get("category", "")
        keyword = d.get("keyword", "")
        if category == "invoice" and keyword not in data["parameters"].get("invoice_keywords", []):
            data["parameters"]["invoice_keywords"].append(keyword)
        elif category == "contract" and keyword not in data["parameters"].get("contract_keywords", []):
            data["parameters"]["contract_keywords"].append(keyword)
        elif category == "bank" and keyword not in data["parameters"].get("bank_keywords", []):
            data["parameters"]["bank_keywords"].append(keyword)
        elif category == "invoice_type" and keyword not in data["environment"].get("supported_invoice_types", []):
            data["environment"]["supported_invoice_types"].append(keyword)
    data["discoveries"] = []
    save_learn(data)


def record_failure(data: dict, error: str = "", ocr_texts: list = None, env_info: dict = None):
    """记录失败"""
    data["fail_streak"] = data.get("fail_streak", 0) + 1
    data["total_runs"] = data.get("total_runs", 0) + 1
    data["total_failure"] = data.get("total_failure", 0) + 1
    if env_info:
        data["environment"].update(env_info)
    entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "failure",
        "error": error,
    }
    if ocr_texts:
        entry["ocr_texts"] = ocr_texts
        _auto_discover(data, ocr_texts)
    data["history"].append(entry)
    # 连续失败3次，临时启用 discoveries
    if data["fail_streak"] >= 3 and data.get("discoveries"):
        _promote_discoveries(data)
    save_learn(data)


def _auto_discover(data: dict, texts: list):
    """从 OCR 文本中自动发现新的发票/合同字段关键词"""
    invoice_field_markers = ["金额", "税额", "税率", "合计", "号码", "日期", "编号", "数量", "单价", "规格"]
    contract_field_markers = ["甲方", "乙方", "合同", "签订", "履约", "付款", "交付", "期限"]
    bank_field_markers = ["交易", "转账", "余额", "账户", "收入", "支出", "手续费"]
    invoice_type_markers = ["发票", "专用", "普通", "电子", "机动车", "火车", "机票", "收据"]

    for text in texts:
        text = text.strip()
        if len(text) > 20:
            continue  # 太长的不太可能是字段名
        # 检测发票字段
        for marker in invoice_field_markers:
            if marker in text and text not in data["parameters"].get("invoice_keywords", []):
                data.setdefault("discoveries", []).append({"category": "invoice", "keyword": text})
                break
        # 检测合同字段
        for marker in contract_field_markers:
            if marker in text and text not in data["parameters"].get("contract_keywords", []):
                data.setdefault("discoveries", []).append({"category": "contract", "keyword": text})
                break
        # 检测银行字段
        for marker in bank_field_markers:
            if marker in text and text not in data["parameters"].get("bank_keywords", []):
                data.setdefault("discoveries", []).append({"category": "bank", "keyword": text})
                break
        # 检测发票类型
        for marker in invoice_type_markers:
            if marker in text and text not in data["environment"].get("supported_invoice_types", []):
                data.setdefault("discoveries", []).append({"category": "invoice_type", "keyword": text})
                break


def _promote_discoveries(data: dict):
    """将发现的模式临时加入搜索范围"""
    for d in data.get("discoveries", []):
        category = d.get("category", "")
        keyword = d.get("keyword", "")
        if category == "invoice" and keyword not in data["parameters"].get("invoice_keywords", []):
            data["parameters"]["invoice_keywords"].append(keyword)
        elif category == "contract" and keyword not in data["parameters"].get("contract_keywords", []):
            data["parameters"]["contract_keywords"].append(keyword)
        elif category == "bank" and keyword not in data["parameters"].get("bank_keywords", []):
            data["parameters"]["bank_keywords"].append(keyword)


def get_effective_keywords(data: dict, category: str) -> list:
    """获取生效的关键词列表"""
    key = f"{category}_keywords"
    base = data.get("parameters", {}).get(key, DEFAULT_LEARN_DATA["parameters"][key])
    # 确保默认关键词都在列表中
    for kw in DEFAULT_LEARN_DATA["parameters"][key]:
        if kw not in base:
            base.append(kw)
    return base


def get_effective_thresholds(data: dict) -> dict:
    """获取生效的合规检查阈值"""
    return {
        "tax_burden_warning": data.get("parameters", {}).get(
            "tax_burden_warning_threshold",
            DEFAULT_LEARN_DATA["parameters"]["tax_burden_warning_threshold"]
        ),
        "cost_ratio_warning": data.get("parameters", {}).get(
            "cost_ratio_warning_threshold",
            DEFAULT_LEARN_DATA["parameters"]["cost_ratio_warning_threshold"]
        ),
    }


def stats(data: dict = None) -> str:
    """输出学习统计"""
    if data is None:
        data = load_learn()
    lines = [
        f"📊 五流合一自学习统计",
        f"  总执行: {data.get('total_runs', 0)} 次",
        f"  成功: {data.get('total_success', 0)} 次",
        f"  失败: {data.get('total_failure', 0)} 次",
        f"  连续失败: {data.get('fail_streak', 0)} 次",
        f"  最后成功: {data.get('last_success_date', '无')}",
        f"  OCR关键词(发票): {len(data.get('parameters', {}).get('invoice_keywords', []))}",
        f"  OCR关键词(合同): {len(data.get('parameters', {}).get('contract_keywords', []))}",
        f"  OCR关键词(银行): {len(data.get('parameters', {}).get('bank_keywords', []))}",
        f"  支持发票类型: {len(data.get('environment', {}).get('supported_invoice_types', []))}",
        f"  待确认发现: {len(data.get('discoveries', []))}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    data = load_learn()
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--stats":
            print(stats(data))
        elif cmd == "--success":
            record_success(data)
            print("✅ 已记录成功")
        elif cmd == "--failure":
            error = sys.argv[2] if len(sys.argv) > 2 else "未知错误"
            record_failure(data, error=error)
            print(f"❌ 已记录失败: {error}")
        elif cmd == "--reset":
            save_learn(json.loads(json.dumps(DEFAULT_LEARN_DATA)))
            print("🔄 已重置经验文件")
    else:
        print(stats(data))