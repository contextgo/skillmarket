#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
FiveFlowCompliance - 自学习数据云端同步模块
支持: 上传本地自学习数据、查询云端数据、智能合并更新

Usage:
    python learn_sync.py --upload              # 上传本地learn_data
    python learn_sync.py --query               # 查询云端数据并合并
    python learn_sync.py --sync                # 双向同步(上传+查询+合并)
    python learn_sync.py --status              # 查看同步状态
    python learn_sync.py --test-api            # 测试API可用性
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: five-flow-compliance | Version: 1.2.0
# Author: QQ 1817694478 | Q-Group: 972156177
import sys, io, re, json, os, hashlib, time, base64, argparse
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

if sys.platform == 'win32' and not getattr(sys, '_five_flow_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._five_flow_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
DATA_DIR = SKILL_DIR / "data"
ASSETS_DIR = SKILL_DIR / "assets"

# ============================================================
# 混淆存储
# ============================================================
_OBFUSCATED_API_KEY = "FEzfdmuImjyX5qGaKsHGefseftJHOa0DPFVHZg=="
_OBFUSCATED_API_BASE = "D1OGdWzHxmeR5PiGeZ2ENfsmadx4Z/Qif1dlaMvYO8knS8naiO7o4B+6DIHkTtUMFZduqeo="

SKILL_NAME = "five-flow-compliance"


def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] [{level}] {clean}", flush=True)


def derive_key() -> bytes:
    return hashlib.sha256(b"FiveFlowCompliance_Skill_Learning_Sync_2026").digest()


def _deobfuscate_string(obfuscated: str) -> str:
    key = derive_key()
    try:
        xored = base64.b64decode(obfuscated)
        key_stream = key
        while len(key_stream) < len(xored):
            key_stream += hashlib.sha256(key_stream[-32:]).digest()
        plain_bytes = bytes(a ^ b for a, b in zip(xored, key_stream[:len(xored)]))
        return plain_bytes.decode('utf-8')
    except Exception as e:
        log(f"decrypt failed: {e}", "ERROR")
        return ""


def get_api_key() -> str:
    key = _deobfuscate_string(_OBFUSCATED_API_KEY)
    if not key:
        log("[WARNING] API Key decrypt failed, using default", "WARNING")
        return "sk-stustar-test-key"
    return key


def get_api_base() -> str:
    base = _deobfuscate_string(_OBFUSCATED_API_BASE)
    if not base:
        log("[WARNING] API base decrypt failed, using default", "WARNING")
        return "https://gpt.cntaxs.com/stustar-api/api/skill/learning"
    return base


# ============================================================
# 本地数据操作
# ============================================================
def load_local_learn_data() -> dict:
    learn_path = DATA_DIR / "five_flow_learn.json"
    if learn_path.exists():
        try:
            return json.loads(learn_path.read_text(encoding='utf-8'))
        except Exception as e:
            log(f"load local data failed: {e}", "ERROR")
    # default
    return {
        "version": "1.0.0",
        "skill_name": SKILL_NAME,
        "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_runs": 0,
        "total_success": 0,
        "total_failure": 0,
        "parameters": {
            "invoice_keywords": ["价税合计", "不含税金额", "税额", "税率", "发票号码", "开票日期"],
            "contract_keywords": ["合同金额", "甲方", "乙方", "合同编号", "签订日期"],
            "bank_keywords": ["交易金额", "对方账户", "交易日期", "交易类型"],
            "tax_burden_warning_threshold": 0.15,
            "cost_ratio_warning_threshold": 0.30,
        },
        "discoveries": [],
        "environment": {
            "supported_invoice_types": ["增值税专用发票", "增值税普通发票", "机动车销售统一发票"],
        },
        "cloud_sync": {
            "last_upload_hash": None,
            "last_download_time": None,
            "merge_count": 0
        }
    }


def save_local_learn_data(data: dict) -> bool:
    learn_path = DATA_DIR / "five_flow_learn.json"
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        learn_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        return True
    except Exception as e:
        log(f"save local data failed: {e}", "ERROR")
        return False


def calc_data_hash(data: dict) -> str:
    json_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.md5(json_str.encode('utf-8')).hexdigest()


# ============================================================
# API调用
# ============================================================
def api_request(method, endpoint, data=None, headers=None, timeout=15):
    api_base = get_api_base()
    url = f"{api_base}{endpoint}"
    default_headers = {
        "Authorization": f"Bearer {get_api_key()}",
        "User-Agent": f"{SKILL_NAME}/1.2"
    }
    if headers:
        default_headers.update(headers)
    try:
        if method == "GET":
            req = Request(url, headers=default_headers, method="GET")
        else:
            body = json.dumps(data, ensure_ascii=False).encode('utf-8') if data else b''
            default_headers["Content-Type"] = "application/json"
            req = Request(url, data=body, headers=default_headers, method="POST")
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except HTTPError as e:
        if e.code in (401, 403):
            return {"code": e.code, "msg": "Auth failed: API Key invalid", "data": None, "auth_error": True}
        return {"code": e.code, "msg": f"HTTP Error: {e.reason}", "data": None}
    except URLError as e:
        return {"code": -1, "msg": f"URL Error: {e.reason}", "data": None}
    except Exception as e:
        return {"code": -2, "msg": f"Error: {str(e)}", "data": None}


# ============================================================
# 上传
# ============================================================
def upload_learn_data(remark="") -> dict:
    log("Uploading learn data...")
    local_data = load_local_learn_data()
    data_hash = calc_data_hash(local_data)

    last_hash = local_data.get("cloud_sync", {}).get("last_upload_hash")
    if last_hash == data_hash:
        log("Data unchanged, skip upload")
        return {"success": True, "skipped": True, "reason": "data unchanged"}

    payload = {
        "skillName": SKILL_NAME,
        "skillJson": local_data,
        "remark": remark or f"auto sync at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    }

    result = api_request("POST", "/upload", payload)

    if result.get("auth_error"):
        log("[WARNING] Auth failed, skip upload", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}

    if result.get("code") == 0:
        d = result.get("data", {})
        local_data["cloud_sync"] = local_data.get("cloud_sync", {})
        local_data["cloud_sync"]["last_upload_hash"] = data_hash
        local_data["cloud_sync"]["last_upload_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_local_learn_data(local_data)

        log(f"Upload OK! id={d.get('id')} new={d.get('isNew')} changed={d.get('dataChanged')}")
        return {
            "success": True, "skipped": False,
            "is_new": d.get("isNew"), "data_changed": d.get("dataChanged"),
            "data_hash": data_hash, "record_id": d.get("id")
        }
    else:
        log(f"Upload failed: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


# ============================================================
# 查询与合并
# ============================================================
def get_cached_data_hash() -> str:
    cache_file = DATA_DIR / "learn_sync_cache.json"
    if cache_file.exists():
        try:
            return json.loads(cache_file.read_text(encoding='utf-8')).get("cloud_data_hash", "")
        except:
            pass
    return ""


def save_cached_data_hash(data_hash, data=None):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = DATA_DIR / "learn_sync_cache.json"
    cache = {"cloud_data_hash": data_hash, "last_update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    if data:
        cache["cloud_data_summary"] = {
            "version": data.get("version"),
            "discoveries_count": len(data.get("discoveries", [])),
        }
    cache_file.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')


def query_cloud_data() -> dict:
    log("Querying cloud data...")
    last_hash = get_cached_data_hash()
    headers = {}
    if last_hash:
        headers["If-None-Match"] = last_hash

    result = api_request("GET", f"/query?skillName={SKILL_NAME}", headers=headers)

    if result.get("auth_error"):
        log("[WARNING] Auth failed, skip query", "WARNING")
        return {"success": False, "auth_error": True, "error": result.get("msg"), "code": result.get("code")}

    if result.get("code") == 0:
        d = result.get("data", {})
        if not d.get("changed", True):
            log("Cloud data unchanged, skip download")
            return {"success": True, "changed": False, "quota": d.get("quotaRemaining")}

        cloud_data_str = d.get("skillJson", "{}")
        try:
            cloud_data = json.loads(cloud_data_str) if isinstance(cloud_data_str, str) else cloud_data_str
        except:
            cloud_data = {}

        new_hash = d.get("dataHash", "")
        save_cached_data_hash(new_hash, cloud_data)

        log(f"New data fetched! quota={d.get('quotaRemaining')}")
        return {"success": True, "changed": True, "data": cloud_data, "data_hash": new_hash, "quota": d.get("quotaRemaining")}
    else:
        log(f"Query failed: {result.get('msg')}", "ERROR")
        return {"success": False, "error": result.get("msg"), "code": result.get("code")}


def merge_cloud_to_local(cloud_data: dict) -> dict:
    log("Merging cloud data to local...")
    local_data = load_local_learn_data()
    stats = {"discoveries_added": 0, "keywords_added": 0, "invoice_types_added": 0}

    # 合并discoveries
    local_ids = {d.get("keyword") for d in local_data.get("discoveries", []) if d.get("keyword")}
    for discovery in cloud_data.get("discoveries", []):
        if discovery.get("keyword") and discovery["keyword"] not in local_ids:
            local_data["discoveries"].append(discovery)
            stats["discoveries_added"] += 1
            local_ids.add(discovery["keyword"])

    # 合并keywords
    for kw_type in ["invoice_keywords", "contract_keywords", "bank_keywords"]:
        local_kws = set(local_data.get("parameters", {}).get(kw_type, []))
        for kw in cloud_data.get("parameters", {}).get(kw_type, []):
            if kw not in local_kws:
                local_data["parameters"][kw_type].append(kw)
                stats["keywords_added"] += 1

    # 合并发票类型
    local_types = set(local_data.get("environment", {}).get("supported_invoice_types", []))
    for t in cloud_data.get("environment", {}).get("supported_invoice_types", []):
        if t not in local_types:
            local_data["environment"]["supported_invoice_types"].append(t)
            stats["invoice_types_added"] += 1

    # 更新同步记录
    local_data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    local_data["cloud_sync"] = local_data.get("cloud_sync", {})
    local_data["cloud_sync"]["last_download_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    local_data["cloud_sync"]["merge_count"] = local_data["cloud_sync"].get("merge_count", 0) + 1

    if save_local_learn_data(local_data):
        total = sum(stats.values())
        log(f"Merge OK! {total} items added")
        return {"success": True, "stats": stats, "total_added": total}
    else:
        return {"success": False, "error": "save failed"}


# ============================================================
# 双向同步
# ============================================================
def bidirectional_sync(silent=False) -> dict:
    log("=" * 50)
    log("Bidirectional sync start...")
    log("=" * 50)
    results = {"upload": None, "download": None, "merge": None, "auth_error": False}

    # Step 1: Upload
    log("\n[Step 1/3] Upload local data...")
    results["upload"] = upload_learn_data("bidirectional-sync")
    if results["upload"].get("auth_error"):
        results["auth_error"] = True

    # Step 2: Query
    log("\n[Step 2/3] Query cloud data...")
    results["download"] = query_cloud_data()
    if results["download"].get("auth_error"):
        results["auth_error"] = True

    # Step 3: Merge
    if results["download"].get("success") and results["download"].get("changed"):
        log("\n[Step 3/3] Merge cloud data...")
        results["merge"] = merge_cloud_to_local(results["download"].get("data", {}))
    else:
        log("\n[Step 3/3] No new data, skip merge")
        results["merge"] = {"success": True, "skipped": True}

    log("\n" + "=" * 50)
    log("Sync complete!")
    log(f"  Upload: {'OK' if results['upload'].get('success') else 'skip'}")
    log(f"  Query:  {'new data' if results['download'].get('changed') else 'no change/skip'}")
    log(f"  Merge:  {'done' if results['merge'].get('success') else 'skip'}")
    if results["auth_error"]:
        log("  [NOTICE] Auth issue, skill works normally")
    log("=" * 50)

    return results


# ============================================================
# 状态和测试
# ============================================================
def get_sync_status() -> dict:
    local_data = load_local_learn_data()
    cloud_sync = local_data.get("cloud_sync", {})
    return {
        "local": {
            "version": local_data.get("version"),
            "last_updated": local_data.get("last_updated"),
            "discoveries_count": len(local_data.get("discoveries", [])),
        },
        "cloud_sync": {
            "last_upload_hash": (cloud_sync.get("last_upload_hash", "")[:16] + "...") if cloud_sync.get("last_upload_hash") else "none",
            "last_upload_time": cloud_sync.get("last_upload_time", "never"),
            "last_download_time": cloud_sync.get("last_download_time", "never"),
            "merge_count": cloud_sync.get("merge_count", 0),
        }
    }


def test_api() -> dict:
    log("Testing API...")
    result = api_request("GET", "/ping", timeout=10)
    if result.get("code") == 0:
        log(f"API OK! service={result.get('data', {}).get('service')}")
        return {"available": True, "service": result.get("data", {}).get("service")}
    else:
        log(f"API unavailable: {result.get('msg')}", "ERROR")
        return {"available": False, "error": result.get("msg")}


# ============================================================
# CLI
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="FiveFlowCompliance Cloud Sync")
    parser.add_argument("--upload", action="store_true", help="Upload local data")
    parser.add_argument("--query", action="store_true", help="Query cloud data")
    parser.add_argument("--sync", action="store_true", help="Bidirectional sync")
    parser.add_argument("--status", action="store_true", help="Sync status")
    parser.add_argument("--test-api", action="store_true", help="Test API")
    parser.add_argument("--remark", type=str, default="", help="Upload remark")
    args = parser.parse_args()

    if args.test_api:
        result = test_api()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.status:
        status = get_sync_status()
        print(json.dumps(status, ensure_ascii=False, indent=2))
        return

    if args.upload:
        result = upload_learn_data(args.remark)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result.get("success") else 1)

    if args.query:
        result = query_cloud_data()
        if result.get("success") and result.get("changed"):
            merge_result = merge_cloud_to_local(result.get("data", {}))
            print(json.dumps({"query": result, "merge": merge_result}, ensure_ascii=False, indent=2))
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.sync:
        results = bidirectional_sync()
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    # Default: status
    status = get_sync_status()
    print("=" * 60)
    print("FiveFlowCompliance Cloud Sync Status")
    print("=" * 60)
    for section, data in status.items():
        print(f"\n[{section}]")
        for k, v in data.items():
            print(f"  {k}: {v}")
    print("\n" + "=" * 60)
    print("Use --upload, --query, --sync, --test-api")
    print("=" * 60)


if __name__ == "__main__":
    main()
