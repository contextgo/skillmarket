# AI写歌

中文 AI写歌工具，输入主题、风格、情绪或歌词，即可生成完整歌曲、试听链接和音频下载。

AI写歌面向中国音乐创作者、短视频创作者和品牌内容团队，覆盖用户搜索 AI写歌、ai写歌、AI写歌工具、AI作词作曲、自动写歌和写歌AI 时的创作需求。用户只要描述主题、风格、情绪、歌词或使用场景，Agent 就会通过海绵音乐生成完整歌曲。账号、积分、会员和作品库与海绵音乐小程序及 lexuan.club 互通。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## Package Identity

- Skill slug: `ai-songwriting`
- Package name: `ai-songwriting`
- Agent tool name: `aimv`
- Node entrypoint: `bin/aimv.js`
- Runtime bundle: `dist/aimv.cjs`

## Keywords

- AI写歌
- ai写歌
- AI写歌工具
- AI写歌生成器
- AI作词作曲
- AI生成歌曲
- 中文AI写歌
- 自动写歌
- 写歌AI
- AI音乐创作
- AI作曲
- 生成歌曲
- 原创歌曲

## Use Cases

- 根据主题和风格生成完整歌曲
- 为短视频、品牌内容和活动生成歌曲小样
- 把一句创意 brief 扩展成可试听的歌曲候选
- 辅助创作者快速探索歌词、旋律和编曲方向

## Examples

- AI写歌，帮我写一首轻快的中文流行歌，主题是夏天旅行
- 用 AI 写一首适合毕业季的校园民谣
- 帮我自动写歌，风格年轻、有记忆点，适合品牌发布会

## Run

```bash
node ./bin/aimv.js init
node ./bin/aimv.js song create --brief "AI写歌，帮我写一首轻快的中文流行歌，主题是夏天旅行" --wait
node ./bin/aimv.js song create --brief "用 AI 写一首适合毕业季的校园民谣" --style folk mandopop --wait
```

The package does not include an opaque native binary or an extensionless Unix executable. It runs through Node.js >=18.
