---
name: ai-songwriting
description: >
  中文 AI写歌工具，输入主题、风格、情绪或歌词，即可生成完整歌曲、试听链接和音频下载。 Use this whenever the user wants AI写歌, ai写歌, AI写歌工具, AI写歌生成器, AI作词作曲, AI生成歌曲, 中文AI写歌, 自动写歌.
  Call the local aimv CLI through the Node entrypoint.
---

# AI写歌

AI写歌适合需要 AI写歌工具、AI作词作曲、自动写歌、写歌AI 和中文AI写歌的音乐创作者。你只要描述主题、风格、情绪、歌词或使用场景，就可以在 AI 助手中生成完整歌曲、试听链接和音频下载；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：AI写歌
- Skill slug / 目录名：`ai-songwriting`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- AI写歌
- ai写歌
- AI写歌工具
- AI写歌生成器
- AI作词作曲
- AI生成歌曲
- 中文AI写歌
- 自动写歌
- 写歌AI
- AI音乐创作
- AI作曲
- 生成歌曲
- 原创歌曲

## 适用场景

- 根据主题和风格生成完整歌曲
- 为短视频、品牌内容和活动生成歌曲小样
- 把一句创意 brief 扩展成可试听的歌曲候选
- 辅助创作者快速探索歌词、旋律和编曲方向

## 典型用户说法

- AI写歌，帮我写一首轻快的中文流行歌，主题是夏天旅行
- 用 AI 写一首适合毕业季的校园民谣
- 帮我自动写歌，风格年轻、有记忆点，适合品牌发布会

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "AI写歌，帮我写一首轻快的中文流行歌，主题是夏天旅行" --wait
node <安装目录>/bin/aimv.js song create --brief "用 AI 写一首适合毕业季的校园民谣" --style folk mandopop --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
