# token-tracker

`token-tracker` 是一个只依赖自身目录内容的 Token 用量监控 skill，覆盖三条链路：

1. **主动查询** — 用户随时问"今天用了多少 token"，秒回摘要
2. **日/周报** — 自动生成含费用、昨日对比、高峰时段、主力模型的报表
3. **熔断告警** — 预算即将超标时提前预警，超标后立即告警，每日去重

所有计算逻辑统一走 `scripts/token-tracker.js`，不依赖模型手算。

## 能力概览

| 场景 | 触发方式 | 底层命令 |
|------|----------|----------|
| 今日摘要 | "今天用了多少 token" | `summary --lang zh` |
| 历史查询 | "昨天用了多少" / "3月18号的账单" | `summary --lang zh --date 2026-03-18` |
| 今日明细 | "今日详细账单" | `bill --lang zh` |
| 本周报告 | "本周报告" | `week --lang zh` |
| 日报（含高峰时段） | "生成今日日报" | `daily-report --lang zh` |
| 周报 | "生成本周周报" | `weekly-report --lang zh` |
| 预算状态 | "预算还剩多少" | `budget-status --lang zh` |
| 设置预算 | "set budget 15" · "设置预算 20" | `set-budget --amount 15 --lang zh` |
| 熔断检查 | 定时任务或手动 | `alert-check --lang zh --update-state` |
| 配置服务商 | "配置 OpenAI API Key" | `configure-provider --name openai --api-key sk-xxx` |
| 从 API 获取用量 | "同步用量" / "fetch usage" | `fetch-usage --lang zh` |
| 查看服务商 | "查看服务商配置" | `list-providers --lang zh` |
| 查询余额 | "DeepSeek 余额" | `provider-balance --name deepseek --lang zh` |

> 以上命令均为 `node "{baseDir}/scripts/token-tracker.js"` 的子命令。
> 所有命令支持 `--lang zh|en` 和 `--date YYYY-MM-DD`（默认今天）。

说明：

- 当前会话的 cache/context 查询使用 `session_status`，不走脚本。
- 自动化是否已接入调度，由宿主环境决定；本 skill 只提供模板资产。
- 服务商 API 集成需要各平台的 API Key（OpenAI 和 Anthropic 需要 Admin Key）。

## 服务商 API 集成

支持直接调用大模型服务商的 Usage API 获取精确用量数据。

| 服务商 | 支持能力 | 所需 Key |
|--------|---------|---------|
| **OpenAI** | 费用 + 用量明细（按模型） | Admin API Key |
| **Anthropic** | 用量明细（按模型） + 定价表算费 | Admin API Key (`sk-ant-admin-...`) |
| **OpenRouter** | 费用 + 用量明细（按模型/日） + 余额 | Management API Key |
| **DeepSeek** | 余额查询 | 普通 API Key |
| **Kimi (月之暗面)** | 余额查询 | 普通 API Key |
| **MiniMax** | 余额查询 | 普通 API Key |

### 配置方法

```bash
# 配置 API Key
node scripts/token-tracker.js configure-provider --name openai --api-key sk-admin-xxx

# 查看当前配置
node scripts/token-tracker.js list-providers --lang zh

# 从所有已配置的服务商获取今日用量
node scripts/token-tracker.js fetch-usage --lang zh

# 获取指定日期的用量
node scripts/token-tracker.js fetch-usage --lang zh --date 2026-03-31

# 查询 DeepSeek 余额
node scripts/token-tracker.js provider-balance --name deepseek --lang zh
```

`fetch-usage` 会自动调用所有已启用的服务商 API，合并数据后写入本地存储。之后所有查询命令（summary、bill、week 等）会自动反映 API 数据。

Anthropic 用量报表中的费用部分依赖内置定价表估算；定价表位于 `scripts/providers/pricing.js`，需随官方价格更新。

## 数据来源

### 1. 当前会话

通过 `session_status` 获取：

- prompt/completion token
- session cost
- cache hit rate
- context usage

### 2. 历史聚合

通过 `usage.json` 获取（由 `record-session` 和 `fetch-usage` 命令写入）：

- 每日输入/输出 token
- 每日总费用
- 请求次数
- 逐模型明细（`models` 字段）
- 小时级分布（`hourly` 字段，用于日报的高峰时段分析）

> 该文件不存在时自动创建，初始为空记录。
> 文件存在但 JSON 损坏时会明确报错。

### 3. 本 skill 维护的配置和状态

- `budget.json`：预算上限、告警阈值、日报触发时间
- `alert-state.json`：告警去重状态、最后检查时间、最近错误（成功执行后自动清理）
- `report-state.json`：日报/周报投递状态（防止重复推送）

## 告警机制

告警分为两个级别：

| 级别 | 触发条件 | 输出样例 |
|------|---------|---------|
| **预警 (warning)** | 花费 ≥ 阈值 × 87.5% 且 < 阈值 | `⚠️ Token 消耗即将超标 — 已花费 $9.50 / $10` |
| **告警 (alert)** | 花费 ≥ 阈值 | `🚨 Token 预算超标 — 已花费 $10.95 / $10` |

- 预警和告警每个日历日只触发一次（通过 `alert-state.json` 去重）
- 未达预警线时返回 `HEARTBEAT_OK`
- Bootstrap hook 在新会话启动时提供补充提醒（不替代定时轮询）

## 自动化调度（Hook 驱动）

日报、周报、预算告警均通过 `agent:bootstrap` hook 在会话启动时自动投递，**无需外部 cron 或 scheduler**。

hook 会在 AI 首次加载 skill 时自动安装（通过 `scripts/setup-hook.js`），用户无需手动操作。

也可以手动安装：

```bash
node scripts/setup-hook.js install
```

检查是否已安装：

```bash
node scripts/setup-hook.js check
```

hook 在每次会话启动时调用 `session-check --json --update-state`，检查并注入待投递内容：

| 注入的虚拟文件 | 触发条件 |
|--------------|---------|
| `TOKEN_BUDGET_WARNING.md` | 今日花费达到预警或告警阈值 |
| `TOKEN_DAILY_REPORT.md` | 日报触发时间已到（默认 23:00+），或昨日日报未投递（次日补投） |
| `TOKEN_WEEKLY_REPORT.md` | 进入新的 ISO 周且上周周报未投递 |

### 日报触发时间

通过 `budget.json` 中的 `daily_report_hour` 配置（默认 `23`）：

- 用户在 23:00 后打开会话 → 注入当天日报
- 用户次日早上打开会话、昨日日报未投递 → 补投昨日日报
- 投递状态记录在 `report-state.json`，不会重复推送

### 备用方案：自动化模板

如果宿主环境有自己的调度系统，也可以直接使用 `automation/` 目录中的 prompt 模板：

- `daily-report.prompt.txt`
- `weekly-report.prompt.txt`
- `budget-alert.prompt.txt`

使用前需将模板中的 `{baseDir}` 替换为本 skill 的实际绝对路径。

## 手动验证

### 1. 主动查询

```bash
node scripts/token-tracker.js summary --lang zh
node scripts/token-tracker.js bill --lang zh
node scripts/token-tracker.js week --lang zh
node scripts/token-tracker.js daily-report --lang zh
node scripts/token-tracker.js weekly-report --lang zh
node scripts/token-tracker.js budget-status --lang zh
```

### 2. 历史日期查询

```bash
node scripts/token-tracker.js summary --lang zh --date 2026-03-18
node scripts/token-tracker.js daily-report --lang zh --date 2026-03-18
```

### 3. 设置预算

```bash
node scripts/token-tracker.js set-budget --amount 15 --lang zh
```

### 4. 告警测试

```bash
node scripts/token-tracker.js alert-check --lang zh --update-state
```

预期：

- 未达预警线 → `HEARTBEAT_OK`
- 接近阈值（warning）且当日未提醒 → `⚠️ Token 消耗即将超标...`
- 已超阈值（alert）且当日未提醒 → `🚨 Token 预算超标...`
- 同一天第二次执行 → `HEARTBEAT_OK`（去重生效）

### 5. Hook 自动调度测试

```bash
node scripts/token-tracker.js session-check --json --update-state
```

预期：

- 返回 JSON，含 `budgetWarning`、`dailyReport`、`weeklyReport` 三个字段
- 当前小时 >= `daily_report_hour` 且今日日报未投递 → `dailyReport.shouldSend: true`
- 次日再执行 → `dailyReport.shouldSend: false`（去重生效）
- 新的 ISO 周首次执行 → `weeklyReport.shouldSend: true`

### 6. 异常场景

| 场景 | 预期行为 |
|------|---------|
| `usage.json` 文件缺失 | 按 0 用量处理，正常输出 |
| `usage.json` JSON 损坏 | 报错，错误写入 `alert-state.json` |
| `budget.json` 值非法 | 自动回退默认值（$10 / 80%），输出中标注 |
| `report-state.json` 缺失或损坏 | 回退默认值，所有报告视为未投递 |
| 命令成功执行后 | `alert-state.json` 中残留的 `last_error` 自动清除 |

## 上线检查项

- [ ] `budget.json` 初始值适合目标用户群（当前 $15 / 80% / 23点触发日报）
- [ ] `alert-state.json` 和 `report-state.json` 发布时重置为全 null 初始状态
- [ ] Hook 自动安装正常：`node scripts/setup-hook.js check` 返回 `installed: true`
- [ ] 日报包含：总费用、主力模型、昨日对比、高峰时段（需 `hourly` 数据）
- [ ] 周报包含：7 天明细、合计、日均、最高消耗日、主力模型
- [ ] 预警和告警的两种措辞均已验证
- [ ] `session-check` 的日报/周报投递去重已验证

## 已知限制

- 日报/周报通过 hook 在会话启动时投递，不是精确的 23:59 定时；用户不开会话就不会收到（次日首次会话时补投）
- 周报为滚动 7 天窗口，非自然周（周一~周日）
- 高峰时段分析依赖 `usage.json` 中的 `hourly` 字段；若未通过 `record-session` 或支持 hourly 的 provider 写入，日报中不会显示时段信息

## 文件结构

```text
token-tracker/
├── SKILL.md                  # AI 路由指令
├── Readme.md                 # 本文档
├── usage.json                # 用量数据（自动创建和维护）
├── budget.json               # 预算配置（可修改）
├── providers.json            # 服务商 API 配置（API Key 等）
├── alert-state.json          # 告警运行时状态（自动维护）
├── report-state.json         # 日报/周报投递状态（自动维护）
├── automation/
│   ├── daily-report.prompt.txt
│   ├── weekly-report.prompt.txt
│   └── budget-alert.prompt.txt
├── scripts/
│   ├── token-tracker.js      # 核心逻辑（所有命令的唯一入口）
│   ├── setup-hook.js         # Hook 自动安装脚本（check / install）
│   └── providers/
│       ├── index.js           # 服务商注册与编排
│       ├── pricing.js         # 内置模型定价表
│       ├── http.js            # 零依赖 HTTP 客户端
│       ├── openai.js          # OpenAI Costs API
│       ├── anthropic.js       # Anthropic Usage Report API
│       ├── openrouter.js       # OpenRouter Activity + Credits API
│       ├── deepseek.js        # DeepSeek Balance API
│       ├── kimi.js            # Kimi/Moonshot Balance API
│       └── minimax.js         # MiniMax Balance API
└── hooks/openclaw/
    ├── HOOK.md
    ├── handler.js
    └── handler.ts
```
