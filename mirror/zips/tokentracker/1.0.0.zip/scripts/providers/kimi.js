'use strict';

const { request } = require('./http');

async function fetchBalance(config) {
  const url = new URL('/v1/users/me/balance', config.base_url || 'https://api.moonshot.cn');
  const res = await request(url.toString(), {
    headers: { 'Authorization': `Bearer ${config.api_key}` },
  });

  const data = res.data?.data || res.data || {};
  return {
    provider: 'kimi',
    currency: 'CNY',
    available: Number(data.available_balance || 0),
    cash: Number(data.cash_balance || 0),
    voucher: Number(data.voucher_balance || 0),
  };
}

async function fetchUsage() {
  return null;
}

module.exports = { fetchUsage, fetchBalance };
