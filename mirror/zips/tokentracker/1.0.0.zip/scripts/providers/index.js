'use strict';

const fs = require('fs');
const path = require('path');
const { calculateCost, listModels } = require('./pricing');

const SKILL_DIR = path.resolve(__dirname, '../..');
const PROVIDERS_FILE = path.join(SKILL_DIR, 'providers.json');

const PROVIDER_MODULES = {
  openai: () => require('./openai'),
  anthropic: () => require('./anthropic'),
  deepseek: () => require('./deepseek'),
  kimi: () => require('./kimi'),
  minimax: () => require('./minimax'),
  openrouter: () => require('./openrouter'),
};

function readProvidersConfig() {
  if (!fs.existsSync(PROVIDERS_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(PROVIDERS_FILE, 'utf-8'));
  } catch {
    return {};
  }
}

function writeProvidersConfig(config) {
  fs.writeFileSync(PROVIDERS_FILE, `${JSON.stringify(config, null, 2)}\n`, 'utf-8');
}

function getEnabledProviders() {
  const config = readProvidersConfig();
  return Object.entries(config)
    .filter(([, v]) => v.enabled && v.api_key)
    .map(([name, cfg]) => ({ name, ...cfg }));
}

function mergeProviderRecords(results) {
  let totalCost = 0;
  let totalIn = 0;
  let totalOut = 0;
  let totalRequests = 0;
  const models = {};
  const sources = [];

  for (const result of results) {
    if (!result) continue;
    totalCost += result.total_cost || 0;
    totalIn += result.total_tokens_in || 0;
    totalOut += result.total_tokens_out || 0;
    totalRequests += result.requests || 0;
    sources.push(result.provider);

    for (const [name, m] of Object.entries(result.models || {})) {
      if (!models[name]) {
        models[name] = { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
      }
      models[name].cost += m.cost || 0;
      models[name].tokens_in += m.tokens_in || 0;
      models[name].tokens_out += m.tokens_out || 0;
      models[name].requests += m.requests || 0;
    }
  }

  return { total_cost: totalCost, total_tokens_in: totalIn, total_tokens_out: totalOut, requests: totalRequests, models, sources };
}

async function fetchAllUsage(date) {
  const providers = getEnabledProviders();
  if (providers.length === 0) {
    return { date, results: [], merged: null, errors: [], note: 'no_providers_enabled' };
  }

  const results = [];
  const errors = [];

  await Promise.all(providers.map(async (provider) => {
    const loader = PROVIDER_MODULES[provider.name];
    if (!loader) {
      errors.push({ provider: provider.name, error: 'unsupported_provider' });
      return;
    }
    try {
      const mod = loader();
      const data = await mod.fetchUsage(provider, date);
      if (data) results.push(data);
    } catch (err) {
      errors.push({ provider: provider.name, error: err.message });
    }
  }));

  return { date, results, merged: mergeProviderRecords(results), errors };
}

async function fetchBalance(providerName) {
  const config = readProvidersConfig();
  const providerConfig = config[providerName];
  if (!providerConfig || !providerConfig.api_key) {
    throw new Error(`Provider "${providerName}" is not configured.`);
  }

  const loader = PROVIDER_MODULES[providerName];
  if (!loader) throw new Error(`Provider "${providerName}" is not supported.`);

  const mod = loader();
  if (!mod.fetchBalance) throw new Error(`Provider "${providerName}" does not support balance queries.`);

  return mod.fetchBalance(providerConfig);
}

module.exports = {
  readProvidersConfig,
  writeProvidersConfig,
  getEnabledProviders,
  fetchAllUsage,
  fetchBalance,
  calculateCost,
  listModels,
};
