'use strict';

const { request } = require('./http');
const { calculateCost } = require('./pricing');

async function fetchUsage(config, date) {
  const startingAt = `${date}T00:00:00Z`;
  const endingAt = `${date}T23:59:59Z`;

  const url = new URL('/v1/organizations/usage_report/messages', config.base_url || 'https://api.anthropic.com');
  url.searchParams.set('starting_at', startingAt);
  url.searchParams.set('ending_at', endingAt);
  url.searchParams.set('bucket_width', '1d');
  url.searchParams.set('group_by', 'model');

  const res = await request(url.toString(), {
    headers: {
      'x-api-key': config.api_key,
      'anthropic-version': '2023-06-01',
    },
  });

  const buckets = res.data?.data || [];
  let totalCost = 0;
  let totalIn = 0;
  let totalOut = 0;
  let totalRequests = 0;
  const models = {};

  for (const bucket of buckets) {
    const results = bucket.results || [];
    for (const item of results) {
      const modelName = item.model || 'unknown';
      const uncachedIn = Number(item.uncached_input_tokens || 0);
      const cachedIn = Number(item.cache_read_input_tokens || 0);
      const outputTokens = Number(item.output_tokens || 0);
      const inputTokens = uncachedIn + cachedIn;

      const pricing = calculateCost(modelName, inputTokens, outputTokens);
      const cost = pricing.cost;

      totalCost += cost;
      totalIn += inputTokens;
      totalOut += outputTokens;
      totalRequests += 1;

      if (!models[modelName]) {
        models[modelName] = { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
      }
      models[modelName].cost += cost;
      models[modelName].tokens_in += inputTokens;
      models[modelName].tokens_out += outputTokens;
      models[modelName].requests += 1;
    }
  }

  return {
    provider: 'anthropic',
    date,
    total_cost: totalCost,
    total_tokens_in: totalIn,
    total_tokens_out: totalOut,
    requests: totalRequests,
    models,
  };
}

module.exports = { fetchUsage };
