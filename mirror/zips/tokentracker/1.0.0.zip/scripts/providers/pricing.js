'use strict';

// Per-million-token pricing (USD). Updated 2026-03.
// input = cost per 1M input tokens, output = cost per 1M output tokens.
const MODEL_PRICING = {
  // OpenAI
  'gpt-4o': { input: 2.50, output: 10.00, provider: 'openai' },
  'gpt-4o-mini': { input: 0.15, output: 0.60, provider: 'openai' },
  'gpt-4.1': { input: 2.00, output: 8.00, provider: 'openai' },
  'gpt-4.1-mini': { input: 0.40, output: 1.60, provider: 'openai' },
  'gpt-4.1-nano': { input: 0.10, output: 0.40, provider: 'openai' },
  'o1': { input: 15.00, output: 60.00, provider: 'openai' },
  'o1-mini': { input: 1.10, output: 4.40, provider: 'openai' },
  'o1-pro': { input: 150.00, output: 600.00, provider: 'openai' },
  'o3': { input: 10.00, output: 40.00, provider: 'openai' },
  'o3-mini': { input: 1.10, output: 4.40, provider: 'openai' },
  'o4-mini': { input: 1.10, output: 4.40, provider: 'openai' },

  // Anthropic
  'claude-opus-4': { input: 15.00, output: 75.00, provider: 'anthropic' },
  'claude-sonnet-4': { input: 3.00, output: 15.00, provider: 'anthropic' },
  'claude-sonnet-4.5': { input: 3.00, output: 15.00, provider: 'anthropic' },
  'claude-sonnet-4.6': { input: 3.00, output: 15.00, provider: 'anthropic' },
  'claude-3.5-sonnet': { input: 3.00, output: 15.00, provider: 'anthropic' },
  'claude-3.5-haiku': { input: 0.80, output: 4.00, provider: 'anthropic' },
  'claude-3-haiku': { input: 0.25, output: 1.25, provider: 'anthropic' },

  // DeepSeek (CNY converted to USD at ~7.2 rate)
  'deepseek-chat': { input: 0.28, output: 1.10, provider: 'deepseek' },
  'deepseek-reasoner': { input: 0.55, output: 2.19, provider: 'deepseek' },
  'deepseek-v3': { input: 0.28, output: 1.10, provider: 'deepseek' },
  'deepseek-r1': { input: 0.55, output: 2.19, provider: 'deepseek' },

  // Kimi / Moonshot
  'kimi-k2.5': { input: 0.42, output: 2.20, provider: 'kimi' },
  'kimi-k2.5-turbo': { input: 0.60, output: 3.00, provider: 'kimi' },
  'kimi-k2': { input: 0.40, output: 2.00, provider: 'kimi' },
  'kimi-k2-thinking': { input: 0.47, output: 2.00, provider: 'kimi' },
  'kimi-k2-thinking-turbo': { input: 1.15, output: 8.00, provider: 'kimi' },
  'moonshot-v1-8k': { input: 0.20, output: 2.00, provider: 'kimi' },
  'moonshot-v1-32k': { input: 0.20, output: 2.00, provider: 'kimi' },
  'moonshot-v1-128k': { input: 0.84, output: 2.00, provider: 'kimi' },

  // MiniMax
  'minimax-m2.7': { input: 0.30, output: 1.20, provider: 'minimax' },
  'minimax-m2.5': { input: 0.19, output: 0.95, provider: 'minimax' },
  'minimax-m2.1': { input: 0.27, output: 0.95, provider: 'minimax' },
  'minimax-m2': { input: 0.255, output: 1.00, provider: 'minimax' },
  'minimax-01': { input: 0.20, output: 1.10, provider: 'minimax' },
  'abab6.5s': { input: 0.19, output: 0.19, provider: 'minimax' },
};

function resolveModel(modelName) {
  if (!modelName) return null;
  const key = modelName.toLowerCase().trim();
  if (MODEL_PRICING[key]) return { key, ...MODEL_PRICING[key] };

  for (const [pattern, pricing] of Object.entries(MODEL_PRICING)) {
    if (key.startsWith(pattern) || key.includes(pattern)) {
      return { key: pattern, ...pricing };
    }
  }
  return null;
}

function calculateCost(modelName, tokensIn, tokensOut) {
  const model = resolveModel(modelName);
  if (!model) return { cost: 0, matched: false, model: modelName };

  const cost = (tokensIn / 1_000_000) * model.input + (tokensOut / 1_000_000) * model.output;
  return { cost, matched: true, model: model.key, provider: model.provider };
}

function listModels(providerFilter) {
  const result = [];
  for (const [name, pricing] of Object.entries(MODEL_PRICING)) {
    if (!providerFilter || pricing.provider === providerFilter) {
      result.push({ name, ...pricing });
    }
  }
  return result;
}

module.exports = { MODEL_PRICING, resolveModel, calculateCost, listModels };
