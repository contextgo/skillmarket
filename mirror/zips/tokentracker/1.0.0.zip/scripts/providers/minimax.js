'use strict';

const { request } = require('./http');

async function fetchBalance(config) {
  const url = new URL('/v1/api/openplatform/coding_plan/remains', config.base_url || 'https://www.minimax.io');
  const res = await request(url.toString(), {
    headers: {
      'Authorization': `Bearer ${config.api_key}`,
      'Content-Type': 'application/json',
    },
  });

  const data = res.data || {};
  return {
    provider: 'minimax',
    currency: 'CNY',
    available: Number(data.total_remains || data.balance || 0),
    detail: data,
  };
}

async function fetchUsage() {
  return null;
}

module.exports = { fetchUsage, fetchBalance };
