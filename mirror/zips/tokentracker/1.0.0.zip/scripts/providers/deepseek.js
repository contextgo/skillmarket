'use strict';

const { request } = require('./http');

async function fetchBalance(config) {
  const url = new URL('/user/balance', config.base_url || 'https://api.deepseek.com');
  const res = await request(url.toString(), {
    headers: { 'Authorization': `Bearer ${config.api_key}` },
  });

  const info = res.data || {};
  return {
    provider: 'deepseek',
    currency: 'CNY',
    available: Number(info.balance_infos?.[0]?.total_balance || 0),
    granted: Number(info.balance_infos?.[0]?.granted_balance || 0),
    topped_up: Number(info.balance_infos?.[0]?.topped_up_balance || 0),
  };
}

// DeepSeek has no per-day usage API; return null to signal "use pricing table".
async function fetchUsage() {
  return null;
}

module.exports = { fetchUsage, fetchBalance };
