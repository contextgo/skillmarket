'use strict';

const { request } = require('./http');

async function fetchUsage(config, date) {
  const url = new URL('/api/v1/activity', config.base_url || 'https://openrouter.ai');
  url.searchParams.set('date', date);

  const res = await request(url.toString(), {
    headers: { 'Authorization': `Bearer ${config.api_key}` },
  });

  const items = res.data?.data || [];
  let totalCost = 0;
  let totalIn = 0;
  let totalOut = 0;
  let totalRequests = 0;
  const models = {};

  for (const item of items) {
    const modelName = item.model_permaslug || item.model || 'unknown';
    const cost = Number(item.usage || 0);
    const promptTokens = Number(item.prompt_tokens || 0);
    const completionTokens = Number(item.completion_tokens || 0);
    const requests = Number(item.request_count || 1);

    totalCost += cost;
    totalIn += promptTokens;
    totalOut += completionTokens;
    totalRequests += requests;

    if (!models[modelName]) {
      models[modelName] = { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
    }
    models[modelName].cost += cost;
    models[modelName].tokens_in += promptTokens;
    models[modelName].tokens_out += completionTokens;
    models[modelName].requests += requests;
  }

  return {
    provider: 'openrouter',
    date,
    total_cost: totalCost,
    total_tokens_in: totalIn,
    total_tokens_out: totalOut,
    requests: totalRequests,
    models,
  };
}

async function fetchBalance(config) {
  const url = new URL('/api/v1/credits', config.base_url || 'https://openrouter.ai');
  const res = await request(url.toString(), {
    headers: { 'Authorization': `Bearer ${config.api_key}` },
  });

  const data = res.data?.data || res.data || {};
  return {
    provider: 'openrouter',
    currency: 'USD',
    available: Number(data.total_credits || 0) - Number(data.total_usage || 0),
    total_credits: Number(data.total_credits || 0),
    total_usage: Number(data.total_usage || 0),
  };
}

module.exports = { fetchUsage, fetchBalance };
