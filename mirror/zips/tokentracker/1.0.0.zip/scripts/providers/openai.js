'use strict';

const { request } = require('./http');

function dateToUnix(dateStr) {
  return Math.floor(new Date(`${dateStr}T00:00:00Z`).getTime() / 1000);
}

async function fetchUsage(config, date) {
  const startTime = dateToUnix(date);
  const endTime = startTime + 86400;

  const url = new URL('/v1/organization/costs', config.base_url || 'https://api.openai.com');
  url.searchParams.set('start_time', String(startTime));
  url.searchParams.set('end_time', String(endTime));
  url.searchParams.set('bucket_width', '1d');
  url.searchParams.append('group_by[]', 'line_item');

  const res = await request(url.toString(), {
    headers: {
      'Authorization': `Bearer ${config.api_key}`,
      'Content-Type': 'application/json',
    },
  });

  const buckets = res.data?.data || [];
  let totalCost = 0;
  let totalIn = 0;
  let totalOut = 0;
  let totalRequests = 0;
  const models = {};

  for (const bucket of buckets) {
    const results = bucket.results || [];
    for (const item of results) {
      const lineItem = item.line_item || 'unknown';
      const inputTokens = Number(item.input_tokens || 0);
      const outputTokens = Number(item.output_tokens || 0);
      const cost = Number(item.amount?.value || 0);
      const requests = Number(item.num_model_requests || 0);

      totalCost += cost;
      totalIn += inputTokens;
      totalOut += outputTokens;
      totalRequests += requests;

      if (!models[lineItem]) {
        models[lineItem] = { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
      }
      models[lineItem].cost += cost;
      models[lineItem].tokens_in += inputTokens;
      models[lineItem].tokens_out += outputTokens;
      models[lineItem].requests += requests;
    }
  }

  return {
    provider: 'openai',
    date,
    total_cost: totalCost,
    total_tokens_in: totalIn,
    total_tokens_out: totalOut,
    requests: totalRequests,
    models,
  };
}

module.exports = { fetchUsage };
