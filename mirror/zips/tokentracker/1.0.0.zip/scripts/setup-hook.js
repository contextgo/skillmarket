#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const SKILL_DIR = path.resolve(__dirname, '..');
const HOOK_SOURCE = path.join(SKILL_DIR, 'hooks', 'openclaw');
const HOME = process.env.HOME || '/home/node';
const HOOK_NAME = 'token-session-check';
const HOOKS_DIR = path.join(HOME, '.openclaw', 'hooks');
const HOOK_TARGET = path.join(HOOKS_DIR, HOOK_NAME);

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function copyDir(src, dest) {
  ensureDir(dest);
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function isInstalled() {
  return fs.existsSync(HOOK_TARGET) && fs.existsSync(path.join(HOOK_TARGET, 'handler.js'));
}

function run() {
  const command = process.argv[2] || 'install';

  switch (command) {
    case 'check': {
      const installed = isInstalled();
      const payload = { installed, hookTarget: HOOK_TARGET, hookName: HOOK_NAME };
      process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
      return;
    }

    case 'install': {
      if (!fs.existsSync(HOOK_SOURCE)) {
        process.stderr.write(`Hook source not found: ${HOOK_SOURCE}\n`);
        process.exit(1);
      }

      copyDir(HOOK_SOURCE, HOOK_TARGET);

      try {
        execFileSync('openclaw', ['hooks', 'enable', HOOK_NAME], {
          encoding: 'utf-8',
          stdio: ['ignore', 'pipe', 'pipe'],
        });
      } catch {
        // openclaw CLI may not be available; the copy alone is sufficient on some setups.
      }

      const payload = { installed: true, hookTarget: HOOK_TARGET, hookName: HOOK_NAME };
      process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
      return;
    }

    default:
      process.stderr.write(`Unknown command: ${command}. Use "check" or "install".\n`);
      process.exit(1);
  }
}

run();
