#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.resolve(__dirname, '..');
const HOME = process.env.HOME || '/home/node';
const DEFAULT_BUDGET = {
  budget_usd: 10,
  alert_threshold: 0.8,
  daily_report_hour: 23,
};
const DEFAULT_ALERT_STATE = {
  last_checked_at: null,
  last_alert_date: null,
  last_alert_cost_usd: null,
  last_alert_ratio_pct: null,
  last_error: null,
};
const DEFAULT_REPORT_STATE = {
  last_daily_report_date: null,
  last_weekly_report_date: null,
};

const USAGE_FILE = path.join(SKILL_DIR, 'usage.json');

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf-8');
}

function readJsonStrict(filePath, label) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`${label} is invalid JSON: ${error.message}`);
    }
    throw new Error(`Failed to read ${label}: ${error.message}`);
  }
}

function readJsonOptional(filePath, fallback, label) {
  if (!fs.existsSync(filePath)) {
    return fallback;
  }
  return readJsonStrict(filePath, label);
}

function normalizeUsageData(rawData) {
  return {
    records: Array.isArray(rawData.records) ? rawData.records : [],
  };
}

function readUsageData() {
  const data = readJsonOptional(USAGE_FILE, { records: [] }, 'usage data');
  return {
    usageFile: USAGE_FILE,
    sourceStatus: data.records && data.records.length > 0 ? 'ok' : 'empty',
    data: normalizeUsageData(data),
  };
}

function normalizeBudget(rawBudget) {
  const warnings = [];
  const normalized = {
    budget_usd: Number(rawBudget?.budget_usd),
    alert_threshold: Number(rawBudget?.alert_threshold),
    daily_report_hour: Number(rawBudget?.daily_report_hour),
  };

  if (!Number.isFinite(normalized.budget_usd) || normalized.budget_usd <= 0) {
    warnings.push('budget_usd_invalid');
    normalized.budget_usd = DEFAULT_BUDGET.budget_usd;
  }

  if (
    !Number.isFinite(normalized.alert_threshold) ||
    normalized.alert_threshold <= 0 ||
    normalized.alert_threshold >= 1
  ) {
    warnings.push('alert_threshold_invalid');
    normalized.alert_threshold = DEFAULT_BUDGET.alert_threshold;
  }

  if (!Number.isInteger(normalized.daily_report_hour) || normalized.daily_report_hour < 0 || normalized.daily_report_hour > 23) {
    normalized.daily_report_hour = DEFAULT_BUDGET.daily_report_hour;
  }

  return { ...normalized, warnings };
}

function resolveBudgetFile() {
  return process.env.TOKEN_TRACKER_BUDGET_FILE || path.join(SKILL_DIR, 'budget.json');
}

function readBudget() {
  const budgetFile = resolveBudgetFile();
  const rawBudget = readJsonOptional(budgetFile, DEFAULT_BUDGET, 'budget config');
  return {
    budgetFile,
    ...normalizeBudget(rawBudget),
  };
}

function writeBudget(budget) {
  const normalized = normalizeBudget(budget);
  writeJson(resolveBudgetFile(), {
    budget_usd: normalized.budget_usd,
    alert_threshold: normalized.alert_threshold,
    daily_report_hour: normalized.daily_report_hour,
  });
  return normalized;
}

function readAlertState() {
  const alertStateFile = path.join(SKILL_DIR, 'alert-state.json');
  let savedState = DEFAULT_ALERT_STATE;

  if (fs.existsSync(alertStateFile)) {
    try {
      savedState = readJsonStrict(alertStateFile, 'alert state');
    } catch {
      savedState = DEFAULT_ALERT_STATE;
    }
  }

  return {
    alertStateFile,
    state: {
      ...DEFAULT_ALERT_STATE,
      ...savedState,
    },
  };
}

function writeAlertState(nextState) {
  writeJson(path.join(SKILL_DIR, 'alert-state.json'), {
    ...DEFAULT_ALERT_STATE,
    ...nextState,
  });
}

function readReportState() {
  const reportStateFile = path.join(SKILL_DIR, 'report-state.json');
  let savedState = DEFAULT_REPORT_STATE;

  if (fs.existsSync(reportStateFile)) {
    try {
      savedState = readJsonStrict(reportStateFile, 'report state');
    } catch {
      savedState = DEFAULT_REPORT_STATE;
    }
  }

  return {
    reportStateFile,
    state: {
      ...DEFAULT_REPORT_STATE,
      ...savedState,
    },
  };
}

function writeReportState(nextState) {
  writeJson(path.join(SKILL_DIR, 'report-state.json'), {
    ...DEFAULT_REPORT_STATE,
    ...nextState,
  });
}

function utcDate(dateLike) {
  return new Date(`${dateLike}T00:00:00Z`);
}

function formatUtcDate(date) {
  return date.toISOString().slice(0, 10);
}

function getToday(dateOverride) {
  return dateOverride || formatUtcDate(new Date());
}

function getIsoWeek(dateText) {
  const d = utcDate(dateText);
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

function shiftUtcDate(dateText, dayOffset) {
  const date = utcDate(dateText);
  date.setUTCDate(date.getUTCDate() + dayOffset);
  return formatUtcDate(date);
}

function getZeroRecord(date) {
  return {
    date,
    total_cost: 0,
    total_tokens_in: 0,
    total_tokens_out: 0,
    requests: 0,
    models: {},
  };
}

function getRecord(usageData, date) {
  return usageData.records.find((record) => record.date === date) || getZeroRecord(date);
}

function getRecordTotalTokens(record) {
  return Number(record.total_tokens_in || 0) + Number(record.total_tokens_out || 0);
}

function getModels(record) {
  const models = record.models && typeof record.models === 'object' ? record.models : {};
  return Object.entries(models).map(([name, value]) => {
    const entry = value && typeof value === 'object' ? value : {};
    return {
      name,
      cost: Number(entry.cost || 0),
      tokens_in: Number(entry.tokens_in || 0),
      tokens_out: Number(entry.tokens_out || 0),
      requests: Number(entry.requests || 0),
      total_tokens: Number(entry.tokens_in || 0) + Number(entry.tokens_out || 0),
    };
  });
}

function getTopModel(record) {
  const models = getModels(record).sort((left, right) => right.total_tokens - left.total_tokens);
  return models[0] || null;
}

function getHourlyPeaks(record, lang) {
  const hourly = record.hourly && typeof record.hourly === 'object' ? record.hourly : {};
  const entries = Object.entries(hourly)
    .map(([hour, value]) => {
      const entry = value && typeof value === 'object' ? value : {};
      return {
        hour: Number(hour),
        cost: Number(entry.cost || 0),
        tokens: Number(entry.tokens_in || 0) + Number(entry.tokens_out || 0),
      };
    })
    .filter((e) => e.tokens > 0)
    .sort((a, b) => b.tokens - a.tokens);

  if (entries.length === 0) return null;

  const top = entries[0];
  const threshold = top.tokens * 0.7;
  const peakHours = entries.filter((e) => e.tokens >= threshold).sort((a, b) => a.hour - b.hour);

  return { peakHours, topHour: top };
}

function formatHourRange(hours, lang) {
  if (hours.length === 0) return '';

  const sorted = hours.map((h) => h.hour).sort((a, b) => a - b);

  const ranges = [];
  let start = sorted[0];
  let end = sorted[0];
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i] === end + 1) {
      end = sorted[i];
    } else {
      ranges.push([start, end]);
      start = sorted[i];
      end = sorted[i];
    }
  }
  ranges.push([start, end]);

  const formatHour = (h) => {
    if (lang === 'zh') {
      if (h < 6) return `凌晨 ${h} 点`;
      if (h < 12) return `上午 ${h} 点`;
      if (h === 12) return '中午 12 点';
      if (h < 18) return `下午 ${h - 12} 点`;
      return `晚上 ${h - 12} 点`;
    }
    if (h === 0) return '12 AM';
    if (h < 12) return `${h} AM`;
    if (h === 12) return '12 PM';
    return `${h - 12} PM`;
  };

  return ranges
    .map(([s, e]) => (s === e ? formatHour(s) : `${formatHour(s)}~${formatHour(e + 1)}`))
    .join(lang === 'zh' ? '、' : ', ');
}

function summarizeModels(records) {
  const totals = new Map();

  for (const record of records) {
    for (const model of getModels(record)) {
      const previous = totals.get(model.name) || {
        name: model.name,
        cost: 0,
        requests: 0,
        total_tokens: 0,
      };
      previous.cost += model.cost;
      previous.requests += model.requests;
      previous.total_tokens += model.total_tokens;
      totals.set(model.name, previous);
    }
  }

  return [...totals.values()].sort((left, right) => right.total_tokens - left.total_tokens);
}

function roundToOneDecimal(value) {
  return Math.round(value * 10) / 10;
}

function formatThousands(value) {
  return new Intl.NumberFormat('en-US').format(Math.round(value));
}

function trimZeros(value) {
  return value.replace(/\.0+$/, '').replace(/(\.\d*[1-9])0+$/, '$1');
}

function formatCompactTokens(value, lang) {
  if (lang === 'zh') {
    if (value < 10000) {
      return `${formatThousands(value)}`;
    }
    if (value < 100000000) {
      return `${trimZeros(roundToOneDecimal(value / 10000).toFixed(1))} 万`;
    }
    return `${trimZeros(roundToOneDecimal(value / 100000000).toFixed(1))} 亿`;
  }

  if (value < 1000) {
    return `${formatThousands(value)}`;
  }
  if (value < 1000000) {
    return `${trimZeros(roundToOneDecimal(value / 1000).toFixed(1))}K`;
  }
  return `${trimZeros(roundToOneDecimal(value / 1000000).toFixed(1))}M`;
}

function formatPreciseCost(value) {
  return value.toFixed(4);
}

function formatApproxCost(value, lang) {
  if (!value) {
    return lang === 'zh' ? '暂无费用' : 'no cost yet';
  }

  if (value >= 10) {
    return trimZeros(value.toFixed(0));
  }
  if (value >= 1) {
    return trimZeros(value.toFixed(1));
  }
  if (value >= 0.1) {
    return trimZeros(value.toFixed(2));
  }
  return trimZeros(value.toPrecision(2));
}

function formatPercent(value) {
  return trimZeros(value.toFixed(1));
}

function formatSignedPercent(value) {
  const prefix = value > 0 ? '+' : '';
  return `${prefix}${formatPercent(value)}%`;
}

function detectLang(args) {
  return args.lang === 'en' ? 'en' : 'zh';
}

function parseArgs(argv) {
  const [command = 'summary', ...rest] = argv;
  const args = { _: [] };

  for (let index = 0; index < rest.length; index += 1) {
    const token = rest[index];
    if (token.startsWith('--')) {
      const key = token.slice(2);
      const next = rest[index + 1];
      if (!next || next.startsWith('--')) {
        args[key] = true;
      } else {
        args[key] = next;
        index += 1;
      }
    } else {
      args._.push(token);
    }
  }

  return { command, args };
}

function collectWeekRecords(usageData, endDate) {
  const end = utcDate(endDate);
  const days = [];

  for (let offset = 6; offset >= 0; offset -= 1) {
    const current = new Date(end);
    current.setUTCDate(end.getUTCDate() - offset);
    const date = formatUtcDate(current);
    days.push(getRecord(usageData, date));
  }

  return days;
}

function compareRecords(todayRecord, previousRecord) {
  const todayCost = Number(todayRecord.total_cost || 0);
  const previousCost = Number(previousRecord.total_cost || 0);
  const todayTokens = getRecordTotalTokens(todayRecord);
  const previousTokens = getRecordTotalTokens(previousRecord);

  const costDeltaAbs = todayCost - previousCost;
  const tokenDeltaAbs = todayTokens - previousTokens;
  const costDeltaPct = previousCost > 0 ? (costDeltaAbs / previousCost) * 100 : null;
  const tokenDeltaPct = previousTokens > 0 ? (tokenDeltaAbs / previousTokens) * 100 : null;

  return {
    costDeltaAbs,
    costDeltaPct,
    tokenDeltaAbs,
    tokenDeltaPct,
  };
}

function getBudgetStatus(date, budgetInfo, usageInfo) {
  const record = getRecord(usageInfo.data, date);
  const todayCost = Number(record.total_cost || 0);
  const ratio = budgetInfo.budget_usd > 0 ? todayCost / budgetInfo.budget_usd : 0;
  const alertPct = budgetInfo.alert_threshold * 100;
  const ratioPct = ratio * 100;

  let status = 'ok';
  if (ratio >= budgetInfo.alert_threshold) {
    status = 'alert';
  } else if (ratio >= budgetInfo.alert_threshold * 0.875) {
    status = 'warning';
  }

  return {
    date,
    todayCost,
    ratio,
    ratioPct,
    alertPct,
    budgetUsd: budgetInfo.budget_usd,
    alertThreshold: budgetInfo.alert_threshold,
    status,
  };
}


function renderSummary(lang, date, usageInfo) {
  const record = getRecord(usageInfo.data, date);
  const totalTokens = getRecordTotalTokens(record);
  const topModel = getTopModel(record);
  const approxCost = formatApproxCost(Number(record.total_cost || 0), lang);
  if (lang === 'zh') {
    const parts = [
      `今天截至目前共消耗了 ${formatCompactTokens(totalTokens, 'zh')} Token，${record.total_cost ? `折合约 ${approxCost} 美元。` : '暂无费用。'}`,
    ];
    if (topModel && totalTokens > 0) {
      parts.push(`其中 ${topModel.name} 占了 ${Math.round((topModel.total_tokens / totalTokens) * 100)}%。`);
    }
    return parts.join(' ');
  }

  const parts = [
    `As of now today, ${formatCompactTokens(totalTokens, 'en')} tokens have been used, ${record.total_cost ? `costing approximately $${approxCost}.` : 'with no cost yet.'}`,
  ];
  if (topModel && totalTokens > 0) {
    parts.push(`${topModel.name} accounts for ${Math.round((topModel.total_tokens / totalTokens) * 100)}% of usage.`);
  }
  return parts.join(' ');
}

function renderBill(lang, date, usageInfo) {
  const record = getRecord(usageInfo.data, date);
  const models = getModels(record);
  const totalTokens = getRecordTotalTokens(record);

  if (lang === 'zh') {
    const lines = [`今日详细账单（${date}）`, ''];
    if (models.length === 0) {
      lines.push('暂无模型明细。', '');
    } else {
      for (const model of models) {
        lines.push(`- ${model.name}`);
        lines.push(`  输入 ${formatThousands(model.tokens_in)} | 输出 ${formatThousands(model.tokens_out)} | 费用 $${formatPreciseCost(model.cost)} | ${model.requests} 次请求`);
        lines.push('');
      }
    }
    lines.push('------------');
    lines.push(`合计：${formatThousands(totalTokens)} tokens，$${formatPreciseCost(Number(record.total_cost || 0))}，${Number(record.requests || 0)} 次请求`);
    return lines.join('\n');
  }

  const lines = [`Detailed bill for ${date}`, ''];
  if (models.length === 0) {
    lines.push('No model breakdown available.', '');
  } else {
    for (const model of models) {
      lines.push(`- ${model.name}`);
      lines.push(`  In ${formatThousands(model.tokens_in)} | Out ${formatThousands(model.tokens_out)} | Cost $${formatPreciseCost(model.cost)} | ${model.requests} requests`);
      lines.push('');
    }
  }
  lines.push('------------');
  lines.push(`Total: ${formatThousands(totalTokens)} tokens, $${formatPreciseCost(Number(record.total_cost || 0))}, ${Number(record.requests || 0)} requests`);
  return lines.join('\n');
}

function renderWeek(lang, date, usageInfo) {
  const records = collectWeekRecords(usageInfo.data, date);
  const totalIn = records.reduce((sum, record) => sum + Number(record.total_tokens_in || 0), 0);
  const totalOut = records.reduce((sum, record) => sum + Number(record.total_tokens_out || 0), 0);
  const totalCost = records.reduce((sum, record) => sum + Number(record.total_cost || 0), 0);
  const totalRequests = records.reduce((sum, record) => sum + Number(record.requests || 0), 0);
  const totalTokens = totalIn + totalOut;
  const startDate = records[0]?.date || date;
  const endDate = records[records.length - 1]?.date || date;
  const avgCost = records.length ? totalCost / records.length : 0;
  const topDay = [...records].sort((left, right) => getRecordTotalTokens(right) - getRecordTotalTokens(left))[0];
  const topModel = summarizeModels(records)[0];

  if (lang === 'zh') {
    const lines = [`本周 Token 报告（${startDate} ~ ${endDate}）`, ''];
    for (const record of records) {
      lines.push(`${record.date}：${formatThousands(getRecordTotalTokens(record))} tokens，$${formatPreciseCost(Number(record.total_cost || 0))}`);
    }
    lines.push('', '------------');
    lines.push(`合计：${formatThousands(totalTokens)} tokens（输入 ${formatThousands(totalIn)} / 输出 ${formatThousands(totalOut)}）`);
    lines.push(`总费用：$${formatPreciseCost(totalCost)}`);
    lines.push(`日均费用：$${formatPreciseCost(avgCost)}`);
    lines.push(`共 ${totalRequests} 次请求`);
    lines.push(`最高消耗日：${topDay.date}（${formatThousands(getRecordTotalTokens(topDay))} tokens）`);
    lines.push(`本周主力模型：${topModel ? `${topModel.name}（${formatThousands(topModel.total_tokens)} tokens）` : '暂无数据'}`);
    return lines.join('\n');
  }

  const lines = [`Weekly token report (${startDate} ~ ${endDate})`, ''];
  for (const record of records) {
    lines.push(`${record.date}: ${formatThousands(getRecordTotalTokens(record))} tokens, $${formatPreciseCost(Number(record.total_cost || 0))}`);
  }
  lines.push('', '------------');
  lines.push(`Total: ${formatThousands(totalTokens)} tokens (in ${formatThousands(totalIn)} / out ${formatThousands(totalOut)})`);
  lines.push(`Total cost: $${formatPreciseCost(totalCost)}`);
  lines.push(`Average daily cost: $${formatPreciseCost(avgCost)}`);
  lines.push(`${totalRequests} requests`);
  lines.push(`Peak day: ${topDay.date} (${formatThousands(getRecordTotalTokens(topDay))} tokens)`);
  lines.push(`Top model this week: ${topModel ? `${topModel.name} (${formatThousands(topModel.total_tokens)} tokens)` : 'no data'}`);
  return lines.join('\n');
}

function renderBudgetStatus(lang, date, budgetInfo, usageInfo) {
  const status = getBudgetStatus(date, budgetInfo, usageInfo);

  if (lang === 'zh') {
    let statusLine = '状态：✅ 正常';
    if (status.status === 'warning') {
      statusLine = '状态：⚠️ 接近告警线';
    } else if (status.status === 'alert') {
      statusLine = '状态：🚨 已达告警阈值';
    }

    const warnings = budgetInfo.warnings.length
      ? `\n配置修正：检测到无效预算配置，已回退默认值（${budgetInfo.warnings.join(', ')}）。`
      : '';

    return [
      '今日预算状态',
      '',
      `已花费：$${formatPreciseCost(status.todayCost)}`,
      `预算上限：$${trimZeros(status.budgetUsd.toFixed(2))}`,
      `使用率：${formatPercent(status.ratioPct)}%（告警线：${formatPercent(status.alertPct)}%）`,
      statusLine,
      warnings,
      '',
      '提示：可用“设置预算 15”更新预算。',
    ]
      .filter(Boolean)
      .join('\n');
  }

  let statusLine = 'Status: OK';
  if (status.status === 'warning') {
    statusLine = 'Status: Near alert threshold';
  } else if (status.status === 'alert') {
    statusLine = 'Status: Alert threshold reached';
  }

  const warnings = budgetInfo.warnings.length
    ? `\nConfig fallback: invalid budget values were replaced with defaults (${budgetInfo.warnings.join(', ')}).`
    : '';

  return [
    'Budget status today',
    '',
    `Spent: $${formatPreciseCost(status.todayCost)}`,
    `Budget: $${trimZeros(status.budgetUsd.toFixed(2))}`,
    `Usage: ${formatPercent(status.ratioPct)}% (alert line ${formatPercent(status.alertPct)}%)`,
    statusLine,
    warnings,
    '',
    'Tip: use "set budget 15" to update the budget.',
  ]
    .filter(Boolean)
    .join('\n');
}

function renderSetBudget(lang, amount, threshold) {
  const alertPct = threshold * 100;
  const thresholdCost = amount * threshold;

  if (lang === 'zh') {
    return `预算已更新为 $${trimZeros(amount.toFixed(2))}，告警阈值 ${formatPercent(alertPct)}%（即花费 $${trimZeros(thresholdCost.toFixed(2))} 时触发）。`;
  }

  return `Budget updated to $${trimZeros(amount.toFixed(2))}. Alert threshold is ${formatPercent(alertPct)}% (triggering at $${trimZeros(thresholdCost.toFixed(2))}).`;
}

function renderDailyDelta(lang, comparison) {
  if (comparison.costDeltaPct === null) {
    return lang === 'zh' ? '昨日无可比费用数据。' : 'No comparable cost data from yesterday.';
  }

  if (lang === 'zh') {
    return `较昨日费用 ${formatSignedPercent(comparison.costDeltaPct)}，Token ${formatSignedPercent(comparison.tokenDeltaPct ?? 0)}。`;
  }

  return `Compared with yesterday: cost ${formatSignedPercent(comparison.costDeltaPct)}, tokens ${formatSignedPercent(comparison.tokenDeltaPct ?? 0)}.`;
}

function renderDailyReport(lang, date, usageInfo, budgetInfo) {
  const record = getRecord(usageInfo.data, date);
  const yesterdayRecord = getRecord(usageInfo.data, shiftUtcDate(date, -1));
  const comparison = compareRecords(record, yesterdayRecord);
  const totalTokens = getRecordTotalTokens(record);
  const topModel = getTopModel(record);
  const budgetStatus = getBudgetStatus(date, budgetInfo, usageInfo);
  const peaks = getHourlyPeaks(record, lang);

  if (lang === 'zh') {
    const peakLine = peaks
      ? `主要消耗时段：${formatHourRange(peaks.peakHours, 'zh')}`
      : null;

    return [
      `📊 Token 日报（${date}）`,
      '',
      `总消耗：${formatThousands(totalTokens)} tokens`,
      `费用：$${formatPreciseCost(Number(record.total_cost || 0))}`,
      `请求数：${Number(record.requests || 0)}`,
      `预算状态：${formatPercent(budgetStatus.ratioPct)}% / ${formatPercent(budgetStatus.alertPct)}%`,
      `较昨日：${renderDailyDelta('zh', comparison)}`,
      topModel ? `主力模型：${topModel.name}（${formatThousands(topModel.total_tokens)} tokens）` : '主力模型：暂无数据',
      peakLine,
      '',
      '提示：可用 bill 查看逐模型明细。',
    ]
      .filter(Boolean)
      .join('\n');
  }

  const peakLine = peaks
    ? `Peak hours: ${formatHourRange(peaks.peakHours, 'en')}`
    : null;

  return [
    `Token daily report (${date})`,
    '',
    `Total usage: ${formatThousands(totalTokens)} tokens`,
    `Cost: $${formatPreciseCost(Number(record.total_cost || 0))}`,
    `Requests: ${Number(record.requests || 0)}`,
    `Budget status: ${formatPercent(budgetStatus.ratioPct)}% / ${formatPercent(budgetStatus.alertPct)}%`,
    renderDailyDelta('en', comparison),
    topModel ? `Top model: ${topModel.name} (${formatThousands(topModel.total_tokens)} tokens)` : 'Top model: no data',
    peakLine,
    '',
    'Tip: use bill for the per-model breakdown.',
  ]
    .filter(Boolean)
    .join('\n');
}

function renderWeeklyReport(lang, date, usageInfo) {
  const weekly = renderWeek(lang, date, usageInfo);
  return lang === 'zh' ? `Token 周报\n\n${weekly}` : `Token weekly report\n\n${weekly}`;
}

function renderBudgetAlert(lang, status) {
  const isOverBudget = status.ratio >= 1;

  if (lang === 'zh') {
    const headline = isOverBudget ? '🚨 Token 预算超标' : '⚠️ Token 消耗即将超标';
    const detail = `今日已花费 $${formatPreciseCost(status.todayCost)} / $${trimZeros(status.budgetUsd.toFixed(2))}（${formatPercent(status.ratioPct)}%）`;
    const advice = isOverBudget ? '已超出预算上限，请立即控制用量！' : '即将触及预算上限，请注意用量。';
    return `${headline}\n\n${detail}\n${advice}`;
  }

  const headline = isOverBudget ? 'Token budget exceeded' : 'Token budget warning — approaching limit';
  const detail = `Today's spend is $${formatPreciseCost(status.todayCost)} / $${trimZeros(status.budgetUsd.toFixed(2))} (${formatPercent(status.ratioPct)}%)`;
  const advice = isOverBudget ? 'Budget has been exceeded. Please reduce usage immediately.' : 'Approaching budget limit. Please monitor usage.';
  return `${headline}\n\n${detail}\n${advice}`;
}

function renderBootstrapWarning(status) {
  const emoji = status.ratio >= 0.95 ? '🚨' : '⚠️';
  const level = status.ratio >= 0.95 ? '即将超标' : '接近上限';
  return `## ${emoji} Token 预算提醒\n\n今日已花费 **$${formatPreciseCost(status.todayCost)}** / $${trimZeros(status.budgetUsd.toFixed(2))}（**${formatPercent(status.ratioPct)}%**）\n\n当前状态：${level}，请注意本次对话的 token 用量。`;
}

function exitWithError(message, code = 1) {
  process.stderr.write(`${message}\n`);
  process.exit(code);
}

function updateStateOnError(error) {
  try {
    const { state } = readAlertState();
    writeAlertState({
      ...state,
      last_checked_at: new Date().toISOString(),
      last_error: error instanceof Error ? error.message : String(error),
    });
  } catch {
    // Ignore secondary state-write failures.
  }
}

function clearLastErrorIfNeeded(args) {
  if (!args['update-state']) {
    return;
  }
  const { state } = readAlertState();
  writeAlertState({
    ...state,
    last_checked_at: new Date().toISOString(),
    last_error: null,
  });
}

function run() {
  const { command, args } = parseArgs(process.argv.slice(2));
  const lang = detectLang(args);
  const date = getToday(args.date);

  try {
    const usageInfo = readUsageData();

    switch (command) {
      case 'summary':
        process.stdout.write(`${renderSummary(lang, date, usageInfo)}\n`);
        return;

      case 'bill':
        process.stdout.write(`${renderBill(lang, date, usageInfo)}\n`);
        return;

      case 'week':
        process.stdout.write(`${renderWeek(lang, date, usageInfo)}\n`);
        return;

      case 'budget-status': {
        const budgetInfo = readBudget();
        process.stdout.write(`${renderBudgetStatus(lang, date, budgetInfo, usageInfo)}\n`);
        return;
      }

      case 'set-budget': {
        const budgetInfo = readBudget();
        const rawAmount = args.amount || args._[0];
        const amount = Number(rawAmount);
        if (!Number.isFinite(amount) || amount <= 0) {
          exitWithError(lang === 'zh' ? '预算金额必须是大于 0 的数字。' : 'Budget amount must be a number greater than 0.');
        }
        const nextBudget = writeBudget({
          budget_usd: amount,
          alert_threshold: budgetInfo.alert_threshold,
        });
        process.stdout.write(`${renderSetBudget(lang, nextBudget.budget_usd, nextBudget.alert_threshold)}\n`);
        return;
      }

      case 'record-session': {
        const model = args.model || 'unknown';
        const tokensIn = Math.max(0, Math.round(Number(args['tokens-in']) || 0));
        const tokensOut = Math.max(0, Math.round(Number(args['tokens-out']) || 0));
        const cost = Math.max(0, Number(args.cost) || 0);

        if (tokensIn === 0 && tokensOut === 0 && cost === 0) {
          process.stdout.write(JSON.stringify({ recorded: false, reason: 'no_data' }) + '\n');
          return;
        }

        const usageData = readJsonOptional(USAGE_FILE, { records: [] }, 'usage data');
        if (!Array.isArray(usageData.records)) {
          usageData.records = [];
        }

        let dayRecord = usageData.records.find((r) => r.date === date);
        if (!dayRecord) {
          dayRecord = getZeroRecord(date);
          usageData.records.push(dayRecord);
        }

        dayRecord.total_cost = Number(dayRecord.total_cost || 0) + cost;
        dayRecord.total_tokens_in = Number(dayRecord.total_tokens_in || 0) + tokensIn;
        dayRecord.total_tokens_out = Number(dayRecord.total_tokens_out || 0) + tokensOut;
        dayRecord.requests = Number(dayRecord.requests || 0) + 1;

        if (!dayRecord.models || typeof dayRecord.models !== 'object') {
          dayRecord.models = {};
        }
        const prev = dayRecord.models[model] || { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
        dayRecord.models[model] = {
          cost: Number(prev.cost || 0) + cost,
          tokens_in: Number(prev.tokens_in || 0) + tokensIn,
          tokens_out: Number(prev.tokens_out || 0) + tokensOut,
          requests: Number(prev.requests || 0) + 1,
        };

        const currentHour = String(new Date().getHours());
        if (!dayRecord.hourly || typeof dayRecord.hourly !== 'object') {
          dayRecord.hourly = {};
        }
        const prevHour = dayRecord.hourly[currentHour] || { cost: 0, tokens_in: 0, tokens_out: 0, requests: 0 };
        dayRecord.hourly[currentHour] = {
          cost: Number(prevHour.cost || 0) + cost,
          tokens_in: Number(prevHour.tokens_in || 0) + tokensIn,
          tokens_out: Number(prevHour.tokens_out || 0) + tokensOut,
          requests: Number(prevHour.requests || 0) + 1,
        };

        writeJson(USAGE_FILE, usageData);
        process.stdout.write(JSON.stringify({ recorded: true, date, model, tokensIn, tokensOut, cost }) + '\n');
        return;
      }

      case 'alert-check': {
        const budgetInfo = readBudget();
        const status = getBudgetStatus(date, budgetInfo, usageInfo);
        const { state } = readAlertState();
        const now = new Date().toISOString();
        const alreadyAlerted = state.last_alert_date === date;
        const shouldFire = (status.status === 'alert' || status.status === 'warning') && !alreadyAlerted;
        const nextState = {
          ...state,
          last_checked_at: now,
          last_error: null,
        };

        if (!shouldFire) {
          if (args['update-state']) {
            writeAlertState(nextState);
          }
          if (args.json) {
            process.stdout.write(`${JSON.stringify({ shouldAlert: false, reason: alreadyAlerted ? 'already_alerted_today' : 'below_threshold', status }, null, 2)}\n`);
          } else {
            process.stdout.write('HEARTBEAT_OK\n');
          }
          return;
        }

        if (args['update-state']) {
          writeAlertState({
            ...nextState,
            last_alert_date: date,
            last_alert_cost_usd: status.todayCost,
            last_alert_ratio_pct: Number(formatPercent(status.ratioPct)),
          });
        }

        if (args.json) {
          process.stdout.write(`${JSON.stringify({ shouldAlert: true, message: renderBudgetAlert(lang, status), status }, null, 2)}\n`);
        } else {
          process.stdout.write(`${renderBudgetAlert(lang, status)}\n`);
        }
        return;
      }

      case 'bootstrap-warning': {
        const budgetInfo = readBudget();
        const status = getBudgetStatus(date, budgetInfo, usageInfo);
        const payload = {
          shouldWarn: status.status === 'alert' || status.status === 'warning',
          message: (status.status === 'alert' || status.status === 'warning') ? renderBootstrapWarning(status) : '',
          status,
          budgetWarnings: budgetInfo.warnings,
        };
        if (args['update-state']) {
          clearLastErrorIfNeeded(args);
        }
        if (args.json) {
          process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
        } else if (payload.shouldWarn) {
          process.stdout.write(`${payload.message}\n`);
        }
        return;
      }

      case 'session-check': {
        const budgetInfo = readBudget();
        const now = new Date();
        const currentHour = now.getHours();
        const today = date;
        const yesterday = shiftUtcDate(today, -1);
        const triggerHour = budgetInfo.daily_report_hour;

        const budgetStatus = getBudgetStatus(today, budgetInfo, usageInfo);
        const shouldWarnBudget = budgetStatus.status === 'alert' || budgetStatus.status === 'warning';
        const budgetWarning = {
          shouldWarn: shouldWarnBudget,
          message: shouldWarnBudget ? renderBootstrapWarning(budgetStatus) : '',
        };

        const { state: reportState } = readReportState();

        let dailyReport = { shouldSend: false, date: null, content: '' };
        if (currentHour >= triggerHour && reportState.last_daily_report_date !== today) {
          dailyReport = {
            shouldSend: true,
            date: today,
            content: renderDailyReport(lang, today, usageInfo, budgetInfo),
          };
        } else if (currentHour < triggerHour && reportState.last_daily_report_date !== yesterday) {
          const yesterdayRecord = getRecord(usageInfo.data, yesterday);
          const hasYesterdayData = Number(yesterdayRecord.total_cost || 0) > 0 || getRecordTotalTokens(yesterdayRecord) > 0;
          if (hasYesterdayData) {
            dailyReport = {
              shouldSend: true,
              date: yesterday,
              content: renderDailyReport(lang, yesterday, usageInfo, budgetInfo),
            };
          }
        }

        const currentWeek = getIsoWeek(today);
        const lastReportedWeek = reportState.last_weekly_report_date ? getIsoWeek(reportState.last_weekly_report_date) : null;
        let weeklyReport = { shouldSend: false, date: null, content: '' };
        if (currentWeek !== lastReportedWeek) {
          const lastSunday = shiftUtcDate(today, -(new Date(utcDate(today)).getUTCDay() || 7));
          weeklyReport = {
            shouldSend: true,
            date: lastSunday,
            content: renderWeeklyReport(lang, lastSunday, usageInfo),
          };
        }

        if (args['update-state']) {
          const nextReportState = { ...reportState };
          if (dailyReport.shouldSend) {
            nextReportState.last_daily_report_date = dailyReport.date;
          }
          if (weeklyReport.shouldSend) {
            nextReportState.last_weekly_report_date = today;
          }
          writeReportState(nextReportState);
          clearLastErrorIfNeeded(args);
        }

        const payload = { budgetWarning, dailyReport, weeklyReport };
        if (args.json) {
          process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
        } else {
          const parts = [];
          if (budgetWarning.shouldWarn) parts.push(budgetWarning.message);
          if (dailyReport.shouldSend) parts.push(dailyReport.content);
          if (weeklyReport.shouldSend) parts.push(weeklyReport.content);
          if (parts.length > 0) {
            process.stdout.write(`${parts.join('\n\n---\n\n')}\n`);
          }
        }
        return;
      }

      case 'daily-report': {
        const budgetInfo = readBudget();
        process.stdout.write(`${renderDailyReport(lang, date, usageInfo, budgetInfo)}\n`);
        return;
      }

      case 'weekly-report':
        process.stdout.write(`${renderWeeklyReport(lang, date, usageInfo)}\n`);
        return;

      case 'fetch-usage':
      case 'configure-provider':
      case 'list-providers':
      case 'provider-balance':
        return runAsyncCommand(command, args, lang, date, usageInfo);

      default:
        exitWithError(`Unknown command: ${command}`);
    }
    clearStaleError();
  } catch (error) {
    updateStateOnError(error);
    exitWithError(error instanceof Error ? error.message : String(error));
  }
}

function runAsyncCommand(command, args, lang, date, usageInfo) {
  const providers = require('./providers');

  const handler = async () => {
    switch (command) {
      case 'fetch-usage': {
        const result = await providers.fetchAllUsage(date);
        if (result.note === 'no_providers_enabled') {
          if (lang === 'zh') {
            process.stdout.write('尚未配置任何 API 服务商。请使用 configure-provider 添加。\n');
          } else {
            process.stdout.write('No providers configured. Use configure-provider to add one.\n');
          }
          return;
        }
        if (result.errors.length > 0) {
          for (const err of result.errors) {
            process.stderr.write(`[${err.provider}] ${err.error}\n`);
          }
        }
        if (result.merged) {
          const merged = result.merged;
          const record = {
            date,
            total_cost: merged.total_cost,
            total_tokens_in: merged.total_tokens_in,
            total_tokens_out: merged.total_tokens_out,
            requests: merged.requests,
            models: merged.models,
          };
          const usageData = readJsonOptional(USAGE_FILE, { records: [] }, 'usage data');
          if (!Array.isArray(usageData.records)) usageData.records = [];
          const existing = usageData.records.findIndex((r) => r.date === date);
          if (existing >= 0) {
            usageData.records[existing] = record;
          } else {
            usageData.records.push(record);
          }
          writeJson(USAGE_FILE, usageData);

          if (args.json) {
            process.stdout.write(`${JSON.stringify({ ...result, saved: true }, null, 2)}\n`);
          } else {
            const totalTokens = merged.total_tokens_in + merged.total_tokens_out;
            const sources = merged.sources.join(', ');
            if (lang === 'zh') {
              process.stdout.write(`已从 ${sources} 获取 ${date} 用量数据：${formatCompactTokens(totalTokens, 'zh')} Token，$${formatPreciseCost(merged.total_cost)}。已保存。\n`);
            } else {
              process.stdout.write(`Fetched ${date} usage from ${sources}: ${formatCompactTokens(totalTokens, 'en')} tokens, $${formatPreciseCost(merged.total_cost)}. Saved.\n`);
            }
          }
        }
        return;
      }

      case 'configure-provider': {
        const name = args.name || args._[0];
        const apiKey = args['api-key'] || args._[1];
        const baseUrl = args['base-url'];
        if (!name) {
          exitWithError(lang === 'zh' ? '请指定服务商名称（openai / anthropic / openrouter / deepseek / kimi / minimax）。' : 'Please specify a provider name (openai / anthropic / openrouter / deepseek / kimi / minimax).');
        }
        const config = providers.readProvidersConfig();
        if (!config[name]) config[name] = {};
        config[name].enabled = true;
        if (apiKey) config[name].api_key = apiKey;
        if (baseUrl) config[name].base_url = baseUrl;
        providers.writeProvidersConfig(config);
        if (lang === 'zh') {
          process.stdout.write(`服务商 ${name} 已配置${apiKey ? '（含 API Key）' : ''}。\n`);
        } else {
          process.stdout.write(`Provider ${name} configured${apiKey ? ' (API key set)' : ''}.\n`);
        }
        return;
      }

      case 'list-providers': {
        const config = providers.readProvidersConfig();
        const entries = Object.entries(config);
        if (entries.length === 0) {
          process.stdout.write(lang === 'zh' ? '尚未配置任何服务商。\n' : 'No providers configured.\n');
          return;
        }
        if (args.json) {
          process.stdout.write(`${JSON.stringify(config, null, 2)}\n`);
          return;
        }
        const lines = [lang === 'zh' ? 'API 服务商配置：' : 'Provider configuration:', ''];
        for (const [name, cfg] of entries) {
          const status = cfg.enabled && cfg.api_key ? '✅' : '❌';
          const keyHint = cfg.api_key ? `${cfg.api_key.slice(0, 8)}...` : lang === 'zh' ? '未设置 Key' : 'no key';
          lines.push(`${status} ${name}: ${keyHint}`);
        }
        process.stdout.write(`${lines.join('\n')}\n`);
        return;
      }

      case 'provider-balance': {
        const name = args.name || args._[0];
        if (!name) {
          exitWithError(lang === 'zh' ? '请指定服务商名称。' : 'Please specify a provider name.');
        }
        const balance = await providers.fetchBalance(name);
        if (args.json) {
          process.stdout.write(`${JSON.stringify(balance, null, 2)}\n`);
        } else if (lang === 'zh') {
          process.stdout.write(`${name} 账户余额：${balance.currency || 'USD'} ${balance.available}\n`);
        } else {
          process.stdout.write(`${name} balance: ${balance.currency || 'USD'} ${balance.available}\n`);
        }
        return;
      }

      default:
        break;
    }
  };

  handler().then(() => {
    clearStaleError();
  }).catch((error) => {
    updateStateOnError(error);
    exitWithError(error instanceof Error ? error.message : String(error));
  });
}

function clearStaleError() {
  try {
    const { state } = readAlertState();
    if (state.last_error) {
      writeAlertState({ ...state, last_error: null });
    }
  } catch {
    // Best-effort cleanup; don't fail the command over this.
  }
}

run();
