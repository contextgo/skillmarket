"use strict";
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const SKILL_DIR = path.resolve(__dirname, '../..');
const SCRIPT_FILE = path.join(SKILL_DIR, 'scripts', 'token-tracker.js');
const ALERT_STATE_FILE = path.join(SKILL_DIR, 'alert-state.json');
const DEFAULT_ALERT_STATE = {
  last_checked_at: null,
  last_alert_date: null,
  last_alert_cost_usd: null,
  last_alert_ratio_pct: null,
  last_error: null,
};

function recordHookError(error) {
  try {
    let currentState = DEFAULT_ALERT_STATE;

    if (fs.existsSync(ALERT_STATE_FILE)) {
      try {
        currentState = JSON.parse(fs.readFileSync(ALERT_STATE_FILE, 'utf-8'));
      } catch {
        currentState = DEFAULT_ALERT_STATE;
      }
    }

    fs.writeFileSync(
      ALERT_STATE_FILE,
      `${JSON.stringify(
        {
          ...DEFAULT_ALERT_STATE,
          ...currentState,
          last_checked_at: new Date().toISOString(),
          last_error: error instanceof Error ? `bootstrap hook: ${error.message}` : `bootstrap hook: ${String(error)}`,
        },
        null,
        2,
      )}\n`,
      'utf-8',
    );
  } catch {
    // Ignore secondary failures while recording hook diagnostics.
  }
}

const handler = async (event) => {
  if (event.type !== 'agent' || event.action !== 'bootstrap') return;
  if (!Array.isArray(event.context?.bootstrapFiles)) return;
  if ((event.sessionKey || '').includes(':subagent:')) return;

  try {
    if (!fs.existsSync(SCRIPT_FILE)) return;
    const raw = execFileSync('node', [SCRIPT_FILE, 'session-check', '--json', '--update-state'], {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    const result = JSON.parse(raw);

    if (result.budgetWarning?.shouldWarn && result.budgetWarning.message) {
      event.context.bootstrapFiles.push({
        path: 'TOKEN_BUDGET_WARNING.md',
        virtual: true,
        content: result.budgetWarning.message,
      });
    }

    if (result.dailyReport?.shouldSend && result.dailyReport.content) {
      event.context.bootstrapFiles.push({
        path: 'TOKEN_DAILY_REPORT.md',
        virtual: true,
        content: result.dailyReport.content,
      });
    }

    if (result.weeklyReport?.shouldSend && result.weeklyReport.content) {
      event.context.bootstrapFiles.push({
        path: 'TOKEN_WEEKLY_REPORT.md',
        virtual: true,
        content: result.weeklyReport.content,
      });
    }
  } catch (error) {
    recordHookError(error);
  }
};

module.exports = handler;
module.exports.default = handler;
