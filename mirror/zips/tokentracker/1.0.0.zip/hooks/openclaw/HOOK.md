---
name: token-session-check
description: "Injects budget warnings, pending daily reports, and weekly reports at session start. All logic delegated to token-tracker's deterministic script."
metadata: {"openclaw":{"emoji":"📊","events":["agent:bootstrap"]}}
---

# Token Session Check Hook

Fires on `agent:bootstrap` and delegates all checks to:

```bash
node "{baseDir}/scripts/token-tracker.js" session-check --json --update-state
```

The hook injects up to three virtual files at session start:

| Virtual file | Condition |
|-------------|-----------|
| `TOKEN_BUDGET_WARNING.md` | Today's spend has reached the warning or alert threshold |
| `TOKEN_DAILY_REPORT.md` | A daily report is due (trigger hour reached, or yesterday's report was never delivered) |
| `TOKEN_WEEKLY_REPORT.md` | A new ISO week has started and last week's report hasn't been sent |

The hook stays completely silent when nothing is due.

## Setup

Copy this hook to the managed hooks directory and enable it:

```bash
cp -r hooks/openclaw ~/.openclaw/hooks/token-session-check
openclaw hooks enable token-session-check
```

## How Scheduling Works

Since hooks fire on session start (not at fixed clock times), the script uses a **trigger hour + catch-up** pattern:

- **Daily report**: configurable via `daily_report_hour` in `budget.json` (default: 23)
  - If current hour >= trigger hour and today's report hasn't been sent → inject today's report
  - If it's a new day and yesterday's report was never sent → inject yesterday's report as catch-up
- **Weekly report**: fires on the first session of a new ISO week
- **Budget warning**: checked on every session start

State is tracked in `report-state.json` (daily/weekly) and `alert-state.json` (budget) to prevent duplicates.

## What It Does

- Fires on every new session start (`agent:bootstrap`)
- Skips sub-agent sessions
- Uses the same script and config as all other token-tracker flows
- Records hook errors in `alert-state.json` for diagnostics
- Injects virtual files only when there is something to report

## Configuration

Edit `budget.json` in the skill root:

```json
{
  "budget_usd": 15,
  "alert_threshold": 0.8,
  "daily_report_hour": 23
}
```

- `budget_usd` must be greater than `0`
- `alert_threshold` must be between `0` and `1`
- `daily_report_hour` must be `0`–`23` (default `23`, meaning reports trigger at 23:00+)

Invalid values are automatically replaced with defaults by the shared script.
