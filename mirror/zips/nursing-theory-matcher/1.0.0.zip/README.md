# Nursing Theory Matcher v4

## 当前规模
- 理论/框架/模型/方法论总数：**81**
- benchmark case 数量：**37**
- theory graph 节点：**81**
- theory graph 边：**17**

## 目录
```text
nursing-theory-matcher/
├── README.md
├── SKILL.md
├── theory_catalog.json
├── theory_synonyms.yaml
├── decision_rules.yaml
├── literature_seeds.json
├── rubric.yaml
├── theory_graph.json
├── prompt_tests.md
├── benchmark_cases.json
├── theory_selection_playbook.md
├── output_templates/
└── examples/
```
