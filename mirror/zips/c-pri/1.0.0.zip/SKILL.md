---
name: china-pri
description: 中国负责任投资（C-PRI）筛选框架。将PRI六大原则与ESG投资DAO方法论融合，适配中国A股市场特点，支持规模分层实质性评估、政策周期与康波周期共振分析、双重重要性中国化表达、洪灏量化工具集成，以及C-PRI五步筛选流程。当用户提到PRI负责任投资、ESG筛选、A股ESG、中国可持续投资、洪灏周期分析、双重重要性、尽责管理、绿色投资框架时激活。
---

# 中国负责任投资（C-PRI）技能

## 定位

将联合国PRI六大原则与ESG投资DAO方法论融合，构建适配中国A股市场特点的负责任投资筛选框架（C-PRI Framework）。

## 何时使用

- 用户需要对A股公司进行ESG/PRI实质性评估
- 用户讨论政策周期、康波周期对ESG投资的影响
- 用户进行双重重要性分析（中国情境）
- 用户需要设计尽责管理（Stewardship）策略
- 用户构建C-PRI投资组合筛选流程

## 核心文档索引

详细框架内容分布于以下参考文件，按需加载：

| 文件 | 内容 |
|------|------|
| `references/esg-dao-principles.md` | ESG Investment DAO 三原则原文（2023年7月版）+ C-PRI映射注解 |
| `references/c-pri-framework-overview.md` | 框架全貌：双轮驱动模型 + 三原则×六原则融合矩阵 |
| `references/china-materiality-assessment.md` | 双重重要性中国化表达 |
| `references/size-tiered-screening.md` | 规模分层筛选细则（S>E>G差异） |
| `references/policy-cycle-integration.md` | 政策周期 × 康波周期共振模型 |
| `references/engagement-playbook-china.md` | 中国尽责管理操作手册 |
| `references/reporting-template.md` | C-PRI报告模板 |

## 快速工作流（五步C-PRI筛选）

```
第一步：负面筛选（PRI Principle 1）→ 排除高违规风险标的
第二步：规模分层实质性评估       → 大/中/小盘差异化权重
第三步：尽责管理可行性评估        → 沟通渠道 + 治理改善空间
第四步：双重重要性验证            → 影响重要性 × 财务重要性
第五步：增量价值量化              → 社会/环境贡献 + 风险调整收益
```

详细流程见 `references/c-pri-framework-overview.md`。

## 执行原则

1. 始终优先识别用户处于五步流程的哪个阶段，针对性输出
2. 引用研究数据时注明来源（国信证券、洪灏、PRI官方文件等）
3. 所有建议须兼顾合规性（ISSB/GRI/国内披露要求）与商业可行性
4. 遇到政策相关判断，主动调用政策周期共振模型进行验证
