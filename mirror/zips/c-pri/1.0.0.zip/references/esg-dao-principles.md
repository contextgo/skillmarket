# ESG Investment Principles — ESG Investment DAO
**Version: July 26, 2023 | Open for Global Endorsement**

> 原始文件，C-PRI框架的方法论基础之一。与PRI六大原则共同构成双轮驱动模型的"DAO轮"。

---

## Preamble

We are a community of responsible investors united by a shared conviction: **finance can be a force for good.**

We believe that capital, when guided by principle, has the power to heal ecosystems, strengthen communities, and build a world worth living in. Our purpose is simple and profound:

> To invest in harmony with the Earth, to nurture a society built on care and connection, and to ensure that capital serves humanity at its highest.

This document sets out the principles that guide every investment decision we make. We invite investors everywhere — individuals, institutions, and communities — to read, adopt, and help us improve these principles over time.

---

## Principle 1 — Invest on the Basis of What Truly Matters

**We commit to thorough, honest research that looks beyond the numbers.**

### 1.1 Look at the full picture.
Financial returns matter — but so does impact. We evaluate both the financial performance of an investment and its effects on the environment, society, and governance quality. Neither dimension is optional.

### 1.2 Understand how ESG issues affect value — now and in the future.
Some risks and opportunities take years to materialize. We assess how significant ESG-related issues may affect the value of an investment over the short, medium, and long term.

### 1.3 Base decisions on credible, verified information.
We rely only on trustworthy, independently verifiable data. We form our own judgments — free from undue influence, marketing bias, or incomplete disclosure.

---

## Principle 2 — Only Back What Can Last

**We commit to investing in businesses that are built to endure.**

### 2.1 Ask: Can this business model survive the long run?
We assess whether a company can remain viable over time — commercially, operationally, and reputationally — without relying on short-term gains at the expense of long-term resilience.

### 2.2 Ask: Do the leaders think and act for the long term?
Management behavior reveals true priorities. We assess whether leaders make decisions that build lasting value, rather than optimizing for immediate results.

### 2.3 Ask: Does this business operate within planetary limits?
No business can prosper on a depleted planet. We consider whether a company's growth respects the natural boundaries of the ecosystems on which all life depends.

---

## Principle 3 — Seek Out and Reward Genuine ESG Progress

**We commit to recognizing and supporting companies that create real, positive change.**

### 3.1 Reward companies that take meaningful ESG action.
Proactive steps — reducing emissions, improving labor conditions, strengthening board oversight — create tangible value. We actively seek companies that lead rather than follow.

### 3.2 Value continuous improvement, not just current standing.
A company that consistently improves its ESG performance over time is often more valuable than one that simply scores well today. We track direction, not just position.

### 3.3 Identify opportunities where ESG value is overlooked by the market.
Markets frequently underprice the long-term value of strong ESG practice. These gaps are not just ethical opportunities — they are investment opportunities. We seek them out.

---

## Governance — How These Principles Evolve

These principles are a **living document**. They belong to no single individual or institution — they belong to the global community of responsible investors.

Commitments:
- **Transparency** — publishing all versions and amendments publicly
- **Participation** — inviting input from investors, civil society, and affected communities
- **Democratic iteration** — using an open voting mechanism to review and update these principles on an annual basis, ensuring they remain relevant, rigorous, and widely owned

---

## C-PRI 映射注解

| ESG DAO 原则 | 核心问题 | 对应PRI原则 | 中国A股适配 |
|-------------|---------|-----------|-----------|
| **P1 Truly Matters** | 真实影响 + 可验证数据 | PRI Principle 1 | 规模分层实质性评估；代理指标体系 |
| **P2 Only Back What Can Last** | 商业模式韧性 + 星球边界 | PRI Principle 1/4 | 政策周期 × 康波周期穿越能力 |
| **P3 Genuine ESG Progress** | 改善方向 > 当前评分 | PRI Principle 2/3 | 尽责管理 + 增量价值量化 |
| **Governance: Living Doc** | 民主迭代 + 透明 | PRI Principle 6 | 年度C-PRI报告 + 季度刷新机制 |

> **关键洞察（P3.2）：** "We track direction, not just position" — 与C-PRI机制1中"治理改善空间"的尽责管理逻辑高度吻合，是在G维度低分企业中寻找超额收益的理论依据。
