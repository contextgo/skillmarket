# Evals

`evals.json` holds test prompts and verifiable expectations (for grading as assertions).

Full benchmark workflow: see skill-creator — e.g. `sub-churn-workspace/iteration-N/` with with_skill vs without_skill runs.
