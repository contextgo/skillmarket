# -*- coding: utf-8 -*-
"""OPENCLAW平台通用工具函数 - 数据处理/API请求/报告生成"""
import openclaw
import pandas as pd
from datetime import datetime

def api_request(url, params):
    """OPENCLAW内置API请求（无外部网络依赖，平台内网调用）"""
    try:
        response = openclaw.api.request(url, params=params)
        return response if response else {"code": 200, "data": []}
    except Exception as e:
        openclaw.log.error(f"API请求失败：{str(e)}")
        return {"code": 500, "data": []}

def data_deduplication(data):
    """数据去重（按APPID/包名精准匹配）"""
    seen = set()
    unique_data = []
    for item in data:
        app_id = item.get("app_id") or item.get("package_name")
        if app_id and app_id not in seen:
            seen.add(app_id)
            unique_data.append(item)
    return unique_data

def clean_data(raw_data):
    """自动数据清洗"""
    cleaned = {}
    for k, v in raw_data.items():
        if isinstance(v, dict):
            cleaned[k] = {vk: vv for vk, vv in v.items() if vv}
        elif isinstance(v, list):
            cleaned[k] = [i for i in v if i]
    return cleaned

def match_dimension(data, dimension_map):
    """维度匹配映射"""
    matched = {}
    for k, v in data.items():
        matched[dimension_map.get(k, k)] = v
    return matched

def generate_report(analysis_result):
    """生成OPENCLAW标准化分析报告"""
    report = {
        "报告生成时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "分析市场": "东南亚",
        "监测品类": "SLOTS老虎机游戏",
        "TOP10竞品名单": analysis_result["competitor_list"],
        "全维度分析结果": {
            "营销情报分析": analysis_result["marketing_analysis"],
            "产品迭代监测": analysis_result["product_analysis"],
            "运营全链路分析": analysis_result["operation_analysis"]
        },
        "可落地策略建议": "基于AI提炼的核心套路，优先复用高转化素材、本地化定价、东南亚专属福利"
    }
    return report

def save_to_openclaw(report, report_type, format):
    """存储报告至OPENCLAW平台"""
    for fmt in format:
        openclaw.storage.save(f"{report_type}_{datetime.now().strftime('%Y%m%d')}.{fmt}", report)
