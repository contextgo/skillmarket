# -*- coding: utf-8 -*-
"""OPENCLAW平台技能配置文件 - 无需修改，直接适配"""
SKILL_CONFIG = {
    # 核心参数
    "region": "东南亚",
    "platforms": ["APP Store", "Google Play"],
    "top_n": 10,
    
    # OPENCLAW内置API接口（平台专属，无外部依赖）
    "api": {
        "ios_rank": "openclaw://api/appstore/sea/slots/rank",
        "gp_rank": "openclaw://api/googleplay/sea/slots/rank",
        "ad": "openclaw://api/marketing/ad",
        "activity": "openclaw://api/marketing/activity",
        "kol": "openclaw://api/marketing/kol",
        "opinion": "openclaw://api/marketing/opinion",
        "version": "openclaw://api/product/version",
        "payment": "openclaw://api/product/payment",
        "service": "openclaw://api/product/service",
        "operation": "openclaw://api/operation/growth"
    },
    
    # AI引擎参数
    "ai": {
        "clean_strategy": "auto",  # 自动数据清洗
        "extract_level": "high",  # 高精准策略提炼
        "language": "zh-CN"  # 报告输出语言
    }
}
