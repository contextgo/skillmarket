# -*- coding: utf-8 -*-
"""
OPENCLAW平台专属 - 东南亚SLOTS游戏竞品全维度智能分析Skill
严格遵循SOP流程：榜单采集→营销分析→产品监测→运营分析→报告输出
"""
import openclaw
import schedule
import time
from datetime import datetime
from config import SKILL_CONFIG
from utils import (
    data_deduplication, api_request, clean_data, 
    generate_report, save_to_openclaw
)
from ai_engine import AIRulesEngine

# 【OPENCLAW技能注册装饰器】平台强制规范
@openclaw.skill(
    skill_id="SLOTS_SKILLS_V1.0",
    name="东南亚SLOTS游戏竞品全维度智能分析Skill",
    version="1.0",
    author="OPENCLAW官方",
    description="东南亚TOP10 SLOTS游戏双平台榜单采集+营销/产品/运营全维度AI分析",
    runtime="python3.9",
    auto_execute=True  # 导入后自动执行
)
class SlotsCompetitorAnalysisSkill:
    def __init__(self):
        # 初始化配置
        self.region = SKILL_CONFIG["region"]
        self.platforms = SKILL_CONFIG["platforms"]
        self.top_n = SKILL_CONFIG["top_n"]
        self.ai_engine = AIRulesEngine()
        self.competitor_list = []  # 存储TOP10竞品名单
        self.analysis_result = {}  # 存储全维度分析结果

    def run(self):
        """【强制执行SOP流程】严格按顺序执行核心逻辑"""
        openclaw.log.info("===== 东南亚SLOTS竞品分析Skill启动 - SOP流程开始 =====")
        
        # SOP1：自动数据采集 - 双平台TOP10榜单抓取+去重
        self.sop1_collect_rank_list()
        
        # SOP2：全渠道营销情报采集+AI智能分析
        self.sop2_marketing_analysis()
        
        # SOP3：产品端迭代实时监测+关键信息提取
        self.sop3_product_monitor()
        
        # SOP4：用户增长运营全链路AI分析
        self.sop4_operation_analysis()
        
        # 输出最终报告（OPENCLAW平台标准化存储）
        self.output_final_report()
        
        # 启动7*24小时实时监测（产品迭代模块）
        self.start_24h_monitor()
        
        openclaw.log.info("===== SOP流程执行完成 - 分析报告已生成 =====")

    def sop1_collect_rank_list(self):
        """SOP1：双平台榜单采集+去重+TOP10提取"""
        openclaw.log.info("【SOP1】开始采集东南亚APP Store+Google Play SLOTS榜单")
        rank_data = []
        
        # 采集APP Store东南亚榜单
        ios_data = api_request(SKILL_CONFIG["api"]["ios_rank"], params={"region": self.region, "category": "slots"})
        rank_data.extend(ios_data.get("ranks", []))
        
        # 采集Google Play东南亚榜单
        gp_data = api_request(SKILL_CONFIG["api"]["gp_rank"], params={"region": self.region, "category": "slots"})
        rank_data.extend(gp_data.get("ranks", []))
        
        # 数据去重（按APPID/包名精准匹配）+提取TOP10
        self.competitor_list = data_deduplication(rank_data)[:self.top_n]
        openclaw.log.info(f"【SOP1】完成采集，去重后TOP10竞品：{[i['game_name'] for i in self.competitor_list]}")
        self.analysis_result["competitor_list"] = self.competitor_list

    def sop2_marketing_analysis(self):
        """SOP2：全渠道营销情报采集+AI分析"""
        openclaw.log.info("【SOP2】开始采集TOP10竞品全渠道营销情报")
        marketing_raw = {}
        
        # 按维度采集营销数据
        for competitor in self.competitor_list:
            marketing_raw[competitor["app_id"]] = {
                "ad_data": api_request(SKILL_CONFIG["api"]["ad"], params={"app_id": competitor["app_id"]}),  # 广告投放
                "activity_data": api_request(SKILL_CONFIG["api"]["activity"], params={"app_id": competitor["app_id"]}),  # 运营活动
                "kol_data": api_request(SKILL_CONFIG["api"]["kol"], params={"app_id": competitor["app_id"]}),  # KOL合作
                "public_opinion": api_request(SKILL_CONFIG["api"]["opinion"], params={"app_id": competitor["app_id"]})  # 品牌舆情
            }
        
        # AI智能分析：提炼营销节奏、渠道策略、素材打法、合作逻辑、核心套路
        self.analysis_result["marketing_analysis"] = self.ai_engine.execute(
            raw_data=marketing_raw, 
            rule_type="marketing"
        )
        openclaw.log.info("【SOP2】营销情报AI分析完成")

    def sop3_product_monitor(self):
        """SOP3：产品迭代实时监测+核心信息提取"""
        openclaw.log.info("【SOP3】开始监测TOP10竞品产品迭代数据")
        product_raw = {}
        
        for competitor in self.competitor_list:
            product_raw[competitor["app_id"]] = {
                "version_update": api_request(SKILL_CONFIG["api"]["version"], params={"app_id": competitor["app_id"]}),  # 版本更新
                "payment_system": api_request(SKILL_CONFIG["api"]["payment"], params={"app_id": competitor["app_id"]}),  # 付费体系
                "service_upgrade": api_request(SKILL_CONFIG["api"]["service"], params={"app_id": competitor["app_id"]})  # 服务升级
            }
        
        # AI分析：提取产品迭代关键调整点
        self.analysis_result["product_analysis"] = self.ai_engine.execute(
            raw_data=product_raw, 
            rule_type="product"
        )
        openclaw.log.info("【SOP3】产品迭代监测完成")

    def sop4_operation_analysis(self):
        """SOP4：用户增长全链路运营AI分析"""
        openclaw.log.info("【SOP4】开始分析TOP10竞品全链路运营策略")
        operation_raw = {}
        
        for competitor in self.competitor_list:
            operation_raw[competitor["app_id"]] = api_request(
                SKILL_CONFIG["api"]["operation"], 
                params={"app_id": competitor["app_id"], "region": self.region}
            )
        
        # AI分析：拉新→留存→促活→转化全链路策略
        self.analysis_result["operation_analysis"] = self.ai_engine.execute(
            raw_data=operation_raw, 
            rule_type="operation"
        )
        openclaw.log.info("【SOP4】运营全链路分析完成")

    def output_final_report(self):
        """输出OPENCLAW平台标准化分析报告"""
        report = generate_report(self.analysis_result)
        save_to_openclaw(report, report_type="competitor_analysis", format=["json", "md"])
        openclaw.log.info("【完成】分析报告已存储至OPENCLAW平台技能目录")

    def start_24h_monitor(self):
        """启动7*24小时产品迭代实时监测"""
        openclaw.log.info("【启动】7*24小时竞品产品迭代实时监测中...")
        # 每6小时执行一次产品监测
        schedule.every(6).hours.do(self.sop3_product_monitor)
        while True:
            schedule.run_pending()
            time.sleep(60)

# 【OPENCLAW强制执行入口】
if __name__ == "__main__":
    skill = SlotsCompetitorAnalysisSkill()
    skill.run()
