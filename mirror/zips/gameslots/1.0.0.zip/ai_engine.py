# -*- coding: utf-8 -*-
"""OPENCLAW内置AI分析引擎 - 自动执行数据清洗/维度匹配/策略提炼"""
import json
from utils import clean_data, match_dimension

class AIRulesEngine:
    def __init__(self):
        # 加载AI分析规则（OPENCLAW平台内置）
        with open("ai_rules.json", "r", encoding="utf-8") as f:
            self.ai_rules = json.load(f)

    def execute(self, raw_data, rule_type):
        """
        AI分析核心方法
        :param raw_data: 原始采集数据
        :param rule_type: 分析类型（marketing/product/operation）
        :return: AI提炼后的分析结果
        """
        # 步骤1：自动数据清洗（去噪、缺失值填充、格式标准化）
        cleaned_data = clean_data(raw_data)
        
        # 步骤2：维度匹配（按规则匹配采集维度与分析维度）
        matched_data = match_dimension(cleaned_data, self.ai_rules[rule_type]["dimension_map"])
        
        # 步骤3：策略提炼（自动识别核心套路、节奏、打法、策略）
        analysis_result = self._extract_strategy(matched_data, rule_type)
        
        return analysis_result

    def _extract_strategy(self, matched_data, rule_type):
        """AI策略提炼逻辑"""
        rules = self.ai_rules[rule_type]
        result = {}
        
        for key, rule in rules["extract_rules"].items():
            # 按关键词/模式自动提炼核心信息
            result[key] = [item for item in matched_data if any(k in str(item).lower() for k in rule["keywords"])]
        
        return result
