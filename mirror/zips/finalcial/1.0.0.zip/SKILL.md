---
name: finance_advisor
description: 该技能用于完成记账、收支情况查看任务，解决收支情况的记录与查询的问题。
  当用户提及自己的今日收支情况场景时触发。
metadata: {"clawdbot":{"emoji":"💰"}}
---

# 账单管理技能 (finance_advisor)

优先根据 4、标准业务流程 来处理用户的请求，如果标准业务流程不符合用户意图，则可自行调用函数

# 1、数据模型

Sqlite数据库表，只有一个收支情况实体

| 字段名      | 数据类型 | 约束条件                  | 字段说明                                                     |
| ----------- | -------- | ------------------------- | ------------------------------------------------------------ |
| id          | INTEGER  | PRIMARY KEY AUTOINCREMENT | 记录唯一标识，自增主键，不可修改                             |
| user_id     | TEXT     | NOT NULL                  | 用户唯一 ID，用于隔离不同用户数据                            |
| create_time | TEXT     | NOT NULL                  | 收支发生时间（格式：YYYY-MM-DD HH:MM），由 AI 传入，不依赖系统时区 |
| type        | TEXT     | NOT NULL                  | 收支类型，固定值：`收入`/`支出`                              |
| amount      | REAL     | NOT NULL                  | 收支金额（正数）                                             |
| reason      | TEXT     | DEFAULT ''                | 收支原因 / 备注，可选字段，默认为空                          |

---



# 2、前置条件

本地运行，无需其它环境

---

# 3、函数说明

## A、数据读写对象函数

创建对象

```
ai_book = AIBookkeeping()
```

对象可调用的方法如下

### 1. `add_record()`

- **功能**：新增一条收支记账记录，数据持久化存储到 SQLite 数据库
- **函数签名**：`def add_record(self, user_id: str, create_time: str, type_name: str, amount: float, reason: str = "")`
- **参数**：
  - `user_id (str)`：用户唯一 ID，用于数据隔离
  - `create_time (str)`：记账时间，格式：`YYYY-MM-DD HH:MM`，由 AI 传入，不依赖系统时区，如果用户的消息里没有完整时间，则自行获取当前时间
  - `type_name (str)`：收支类型，仅支持 `收入` / `支出`
  - `amount (float)`：收支金额（正数）
  - `reason (str, 可选)`：收支原因 / 备注，默认为空字符串
- **返回值**：`str`，操作结果提示（`记账成功` / `记账失败：xxx`）
- **备注**：纯数据写入接口，无业务逻辑，适配 Docker 部署无时区问题

### 2. `delete_record()`

- **功能**：根据记录 ID 删除指定记账数据，仅允许删除当前用户自己的记录
- **函数签名**：`def delete_record(self, user_id: str, record_id: int)`
- **参数**：
  - `user_id (str)`：用户唯一 ID，权限校验
  - `record_id (int)`：记账记录的唯一 ID（主键）
- **返回值**：`str`，操作结果提示（`删除成功` / `删除失败：无此记录`）
- **备注**：自带用户权限校验，防止越权删除他人数据

### 3. `update_record()`

- **功能**：根据记录 ID 修改指定记账数据，仅允许修改当前用户自己的记录
- **函数签名**：`def update_record(self, user_id: str, record_id: int, type_name: str, amount: float, reason: str = "")`
- **参数**：
  - `user_id (str)`：用户唯一 ID，权限校验
  - `record_id (int)`：记账记录的唯一 ID（主键）
  - `type_name (str)`：修改后的收支类型（`收入` / `支出`）
  - `amount (float)`：修改后的收支金额
  - `reason (str, 可选)`：修改后的备注信息，默认为空字符串
- **返回值**：`str`，操作结果提示（`更新成功` / `更新失败：无此记录`）
- **备注**：不修改记账时间，仅更新类型、金额、备注

### 4. `query_records()`

- **功能**：根据用户 ID + 时间范围，查询符合条件的所有记账原始数据

- **函数签名**：`def query_records(self, user_id: str, start_date: str, end_date: str)`

- **参数**：

  - `user_id (str)`：用户唯一 ID
  - `start_date (str)`：查询开始日期，格式：`YYYY-MM-DD`
  - `end_date (str)`：查询结束日期，格式：`YYYY-MM-DD`

- **返回值**：`list / str`，成功返回原始数据列表，失败返回错误提示

  ```
  # 数据格式示例
  [(1, "user_001", "2025-05-20 15:30", "支出", 25.5, "买咖啡")]
  ```

- **备注**：时间范围由 AI 传入，不依赖容器时区，返回原始数据供 AI 处理

### 5. `close()`

- **功能**：关闭数据库连接，释放资源
- **函数签名**：`def close(self)`
- **参数**：无
- **返回值**：无
- **备注**：程序结束时调用，保证数据库连接安全关闭

---

# 4、标准业务流程

## 业务流程A：记录本次收支情况并给出建议

当用户发消息时，按以下流程判断并处理：

### 步骤 1：意图判断

判断用户消息是否包含**记账意图**。判断标准（满足任一即可）：
- 包含金额数字（如 "花了 18 块"、"收入 5000"）
- 包含关键词：花了/支出/用了/买了/付了/收入/收到/赚钱/工资/进账
- 包含 "记" 或 "记账"
- 包含 "查"、"看"、"统计"、"月光"、"预算"——这些是**查询意图**

如果没有记账或查询意图，则不属于该流程

### 步骤 2：记录支出

1. 从消息中提取参数：
   - `user_id (str)`：用户唯一 ID，用于数据隔离
   - `create_time (str)`：记账时间，格式：`YYYY-MM-DD HH:MM`，由 AI 传入，不依赖系统时区，如果用户的消息里没有完整时间，则自行获取当前时间
   - `type_name (str)`：收支类型，仅支持 `收入` / `支出`
   - `amount (float)`：收支金额（正数）
   - `reason (str, 可选)`：收支原因 / 备注，默认为空字符串
   - `start_time(str)`：今日开始时间，格式：`YYYY-MM-DD HH:MM`，由 AI 传入，不依赖系统时区，如果用户的消息里没有完整时间，则自行获取今日开始时间

2. 调用函数（按顺序）：
   ```python
   ai_book.add_record(user_id ,create_time, type_name, amount, reason) # 添加收支记录
   today_state = ai_book.query_records(user_id, start_time, create_time) # 获取到目前为止的今日收支情况
    ai_book.close() # 本次业务结束，关闭数据库连接
   ```
   
3. 基于今日收支情况 `today_state`，生成对用户的客观分析与评价：

4. 回复用户确认消息（格式示例）：

   ```
   ✅ 已记录！{{日期}}
   
   今日汇总：
   	{{today_state}}
   
   {{简单的客观分析与评价}}
   ```

