import sqlite3



class AIBookkeeping:
    def __init__(self, db_name="ai_account.db"):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._create_table()

    # 创建数据表
    def _create_table(self):
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS account (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            create_time TEXT NOT NULL,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            reason TEXT DEFAULT ''
        )
        ''')
        self.conn.commit()

    # 1. 新增记录（时间由 AI 传入）
    def add_record(self, user_id: str, create_time: str, type_name: str, amount: float, reason: str = ""):
        try:
            self.cursor.execute('''
            INSERT INTO account (user_id, create_time, type, amount, reason)
            VALUES (?, ?, ?, ?, ?)
            ''', (user_id, create_time, type_name, amount, reason))
            self.conn.commit()
            return "记账成功"
        except Exception as e:
            return f"记账失败：{str(e)}"


    # 2. 删除记录
    def delete_record(self, user_id: str, record_id: int):
        try:
            self.cursor.execute('''
            DELETE FROM account WHERE id=? AND user_id=?
            ''', (record_id, user_id))
            self.conn.commit()
            return "删除成功" if self.cursor.rowcount > 0 else "删除失败：无此记录"
        except Exception as e:
            return f"删除失败：{str(e)}"

    # 3. 更新记录
    def update_record(self, user_id: str, record_id: int, type_name: str, amount: float, reason: str = ""):
        try:
            self.cursor.execute('''
            UPDATE account 
            SET type=?, amount=?, reason=? 
            WHERE id=? AND user_id=?
            ''', (type_name, amount, reason, record_id, user_id))
            self.conn.commit()
            return "更新成功" if self.cursor.rowcount > 0 else "更新失败：无此记录"
        except Exception as e:
            return f"更新失败：{str(e)}"

    # 4. 自定义时间查询
    def query_records(self, user_id: str, start_date: str, end_date: str):
        try:
            self.cursor.execute('''
            SELECT * FROM account 
            WHERE user_id=? AND create_time BETWEEN ? AND ?
            ''', (user_id, f"{start_date} 00:00", f"{end_date} 23:59"))
            return self.cursor.fetchall()
        except Exception as e:
            return f"查询失败：{str(e)}"

    # 关闭连接
    def close(self):
        self.conn.close()






# AI 调用示例
if __name__ == "__main__":
    ai_book = AIBookkeeping()

    # 1. AI 传入时间记账（彻底不碰容器时区）
    print(ai_book.add_record("user_001", "2025-05-20 15:30", "支出", 25.5, "买咖啡"))

    ai_book.add_record("user_001", "2025-05-20 15:30", "支出", 25.5, "买咖啡")
   
    # 2. AI 传入日期查询
    data = ai_book.query_records("user_001", "2025-05-20", "2025-05-20")

    print("查询数据：", data)

    # 3. 更新/删除
    if data:
        record_id = data[0][0]
        print(ai_book.update_record("user_001", record_id, "收入", 100, "红包"))
        print(ai_book.delete_record("user_001", record_id))

    ai_book.close()