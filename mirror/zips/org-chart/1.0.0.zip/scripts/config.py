# Constants and configuration for org-chart skill

import os

# Safe working directory - must be under /tmp
WORK_DIR = "/tmp/org-chart"
os.makedirs(WORK_DIR, exist_ok=True)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'.csv', '.xlsx', '.xls'}

# Layout constants
NODE_WIDTH = 2.0
NODE_HEIGHT = 0.8
LEVEL_HEIGHT = 1.5
SIBLING_SPACING = 0.5

# Image export settings
IMAGE_DPI = 150
IMAGE_FORMAT = 'png'

# Required columns in CSV/Excel
REQUIRED_COLUMNS = ['name', 'title', 'manager']

# Column name variations (case-insensitive matching)
NAME_VARIATIONS = ['name', '姓名', 'employee', 'employee_name', 'staff']
TITLE_VARIATIONS = ['title', '职位', 'position', 'job_title', 'role']
MANAGER_VARIATIONS = ['manager', '上级', 'supervisor', 'reports_to', 'parent']