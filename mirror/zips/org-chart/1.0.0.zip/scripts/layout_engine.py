"""
Tree layout engine for org-chart.
Calculates positions for nodes in a hierarchical tree structure.
"""

from typing import Dict, List, Optional, Tuple
from collections import defaultdict


class TreeNode:
    """Represents a node in the org tree."""

    def __init__(self, emp_id: str, name: str, title: str):
        self.emp_id = emp_id
        self.name = name
        self.title = title
        self.children: List['TreeNode'] = []
        self.x = 0.0
        self.y = 0.0
        self.width = 2.0
        self.height = 0.8

    def add_child(self, child: 'TreeNode'):
        self.children.append(child)


class LayoutEngine:
    """Calculates tree layout positions for org chart."""

    def __init__(self, employees: List[Dict], root_id: Optional[str],
                 node_width: float = 2.0, node_height: float = 0.8,
                 level_height: float = 1.5, sibling_spacing: float = 0.5):
        self.employees = employees
        self.root_id = root_id
        self.node_width = node_width
        self.node_height = node_height
        self.level_height = level_height
        self.sibling_spacing = sibling_spacing

        self.nodes: Dict[str, TreeNode] = {}
        self.root_node: Optional[TreeNode] = None

    def build_tree(self) -> Optional[TreeNode]:
        """Build the tree structure from employee list."""
        # Create nodes
        for emp in self.employees:
            node = TreeNode(emp['id'], emp['name'], emp['title'])
            self.nodes[emp['id']] = node

        # Link children to parents
        for emp in self.employees:
            manager_id = emp.get('manager_id')
            if manager_id and manager_id in self.nodes:
                self.nodes[manager_id].add_child(self.nodes[emp['id']])

        # Find root
        if self.root_id and self.root_id in self.nodes:
            self.root_node = self.nodes[self.root_id]

        return self.root_node

    def calculate_layout(self) -> List[TreeNode]:
        """
        Calculate x, y positions for all nodes using recursive algorithm.
        Returns list of all nodes with calculated positions.
        """
        if not self.root_node:
            return list(self.nodes.values())

        # First pass: calculate preliminary positions
        self._first_pass(self.root_node, 0)

        # Second pass: center parent above children
        self._second_pass(self.root_node)

        # Collect all nodes
        return list(self.nodes.values())

    def _first_pass(self, node: TreeNode, depth: int) -> float:
        """Recursively calculate node positions. Returns width used."""
        node.y = depth * (self.node_height + self.level_height)

        if not node.children:
            node.x = 0
            return self.node_width + self.sibling_spacing

        # Process children
        child_widths = []
        for child in node.children:
            child_widths.append(self._first_pass(child, depth + 1))

        # Layout children horizontally
        total_child_width = sum(child_widths)
        start_x = -total_child_width / 2

        for i, child in enumerate(node.children):
            child.x = start_x + sum(child_widths[:i]) + child_widths[i] / 2

        node.x = 0
        return max(self.node_width + self.sibling_spacing, total_child_width)

    def _second_pass(self, node: TreeNode, parent_x: float = 0.0):
        """Center parent above children."""
        if node.children:
            child_xs = [c.x for c in node.children]
            node.x = sum(child_xs) / len(child_xs)

        for child in node.children:
            self._second_pass(child, node.x)

    def get_connections(self) -> List[Tuple[float, float, float, float]]:
        """
        Get list of connection lines between parent and children.
        Returns: [(parent_x, parent_y, child_x, child_y), ...]
        """
        connections = []
        for node in self.nodes.values():
            if node.children:
                for child in node.children:
                    connections.append((
                        node.x, node.y + self.node_height / 2,
                        child.x, child.y - self.node_height / 2
                    ))
        return connections

    def get_bounds(self) -> Tuple[float, float, float, float]:
        """Get bounding box of all nodes: (min_x, min_y, max_x, max_y)."""
        if not self.nodes:
            return 0, 0, 0, 0

        xs = [n.x for n in self.nodes.values()]
        ys = [n.y for n in self.nodes.values()]

        min_x = min(xs) - self.node_width / 2
        max_x = max(xs) + self.node_width / 2
        min_y = min(ys) - self.node_height / 2
        max_y = max(ys) + self.node_height / 2

        return min_x, min_y, max_x, max_y