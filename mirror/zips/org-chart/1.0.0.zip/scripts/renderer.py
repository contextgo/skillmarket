"""
Renderer for org-chart using Matplotlib.
Generates PNG image of the organizational chart.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import numpy as np
from typing import List, Tuple, Optional, Dict
import os


class OrgChartRenderer:
    """Render org chart to PNG using Matplotlib."""

    def __init__(self, figure_size: Optional[Tuple[float, float]] = None,
                 dpi: int = 150, bg_color: str = 'white'):
        self.figure_size = figure_size or (16, 12)
        self.dpi = dpi
        self.bg_color = bg_color

    def render(self, nodes: List, connections: List[Tuple],
               output_path: str, title: str = "Organization Chart") -> str:
        """
        Render the org chart to a PNG file.

        Args:
            nodes: List of TreeNode objects with x, y positions
            connections: List of (parent_x, parent_y, child_x, child_y) tuples
            output_path: Path to save the PNG
            title: Chart title

        Returns:
            Path to the saved image
        """
        # Calculate bounds
        if not nodes:
            raise ValueError("No nodes to render")

        xs = [n.x for n in nodes]
        ys = [n.y for n in nodes]
        widths = [n.width for n in nodes]
        heights = [n.height for n in nodes]

        min_x = min(x - w/2 for x, w in zip(xs, widths))
        max_x = max(x + w/2 for x, w in zip(xs, widths))
        min_y = min(y - h/2 for y, h in zip(ys, heights))
        max_y = max(y + h/2 for y, h in zip(ys, heights))

        padding = 2.0
        width = max_x - min_x + padding * 2
        height = max_y - min_y + padding * 2

        # Create figure with appropriate size
        fig_width = max(self.figure_size[0], width / 2)
        fig_height = max(self.figure_size[1], height / 2)

        fig, ax = plt.subplots(figsize=(fig_width, fig_height), dpi=self.dpi)
        ax.set_facecolor(self.bg_color)

        # Draw connections first (below nodes)
        for parent_x, parent_y, child_x, child_y in connections:
            # Convert to figure coordinates
            fx1 = (parent_x - min_x + padding)
            fy1 = (parent_y - min_y + padding)
            fx2 = (child_x - min_x + padding)
            fy2 = (child_y - min_y + padding)

            # Draw connection line with elbow
            mid_y = (fy1 + fy2) / 2
            ax.plot([fx1, fx1, fx2, fx2], [fy1, mid_y, mid_y, fy2],
                    color='#555555', linewidth=1.5, zorder=1)

        # Draw nodes
        for node in nodes:
            fx = node.x - min_x + padding
            fy = node.y - min_y + padding
            fw = node.width
            fh = node.height

            # Node background
            box = FancyBboxPatch(
                (fx - fw/2, fy - fh/2), fw, fh,
                boxstyle="round,pad=0.05,rounding_size=0.2",
                facecolor='#4A90D9',
                edgecolor='#2E5A8A',
                linewidth=2,
                zorder=2
            )
            ax.add_patch(box)

            # Name text
            ax.text(fx, fy + 0.05, node.name,
                   ha='center', va='center',
                   fontsize=11, fontweight='bold',
                   color='white', zorder=3)

            # Title text
            ax.text(fx, fy - 0.2, node.title,
                   ha='center', va='center',
                   fontsize=8,
                   color='#E8F0F8', zorder=3)

        # Set axis properties
        ax.set_xlim(0, width)
        ax.set_ylim(0, height)
        ax.set_aspect('equal')
        ax.axis('off')

        # Add title
        ax.set_title(title, fontsize=16, fontweight='bold', pad=20)

        # Remove spines
        for spine in ax.spines.values():
            spine.set_visible(False)

        plt.tight_layout()

        # Save
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight',
                   facecolor=self.bg_color, edgecolor='none')
        plt.close(fig)

        return output_path

    @staticmethod
    def render_from_data(employees: List[Dict], output_path: str,
                         node_width: float = 2.0, node_height: float = 0.8) -> str:
        """
        Convenience method: render org chart directly from employee data.

        Args:
            employees: List of employee dicts with id, name, title, manager_id
            output_path: Path to save PNG
            node_width: Width of each node
            node_height: Height of each node

        Returns:
            Path to saved image
        """
        from .layout_engine import LayoutEngine

        # Find root
        root_id = None
        for emp in employees:
            if not emp.get('manager_id'):
                root_id = emp['id']
                break

        # Build layout
        engine = LayoutEngine(employees, root_id,
                             node_width=node_width,
                             node_height=node_height)
        engine.build_tree()
        nodes = engine.calculate_layout()
        connections = engine.get_connections()

        # Render
        renderer = OrgChartRenderer()
        return renderer.render(nodes, connections, output_path)