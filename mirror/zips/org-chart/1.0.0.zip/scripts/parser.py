"""
CSV/Excel parser for org-chart skill.
Extracts employee data and builds hierarchical structure.
"""

import pandas as pd
import os
from typing import Dict, List, Optional, Tuple


class OrgParser:
    """Parse CSV/Excel files and extract org structure."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self._validate_path()
        self.df = None
        self.employees = []
        self.root_id = None

    def _validate_path(self):
        """Ensure file path is within allowed directory."""
        abs_path = os.path.abspath(self.file_path)
        if not abs_path.startswith('/tmp/org-chart'):
            raise ValueError(f"Path must be under /tmp/org-chart, got: {self.file_path}")

    def parse(self) -> Tuple[List[Dict], Optional[str]]:
        """
        Parse the file and return list of employees and root employee id.
        Returns: (employees, root_id)
        """
        ext = os.path.splitext(self.file_path)[1].lower()

        if ext == '.csv':
            self.df = pd.read_csv(self.file_path)
        elif ext in ['.xlsx', '.xls']:
            self.df = pd.read_excel(self.file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        # Normalize column names
        self._normalize_columns()

        # Check required columns
        self._validate_columns()

        # Build employee list
        self._build_employees()

        # Find root (employee with no manager)
        self._find_root()

        return self.employees, self.root_id

    def _normalize_columns(self):
        """Normalize column names to standard names."""
        col_map = {}
        for col in self.df.columns:
            col_lower = col.lower().strip()
            if col_lower in ['name', '姓名', 'employee', 'employee_name', 'staff']:
                col_map[col] = 'name'
            elif col_lower in ['title', '职位', 'position', 'job_title', 'role']:
                col_map[col] = 'title'
            elif col_lower in ['manager', '上级', 'supervisor', 'reports_to', 'parent']:
                col_map[col] = 'manager'
        self.df.rename(columns=col_map, inplace=True)

    def _validate_columns(self):
        """Ensure required columns exist."""
        missing = set(['name', 'title', 'manager']) - set(self.df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}. Found: {list(self.df.columns)}")

    def _build_employees(self):
        """Build employee records from dataframe."""
        for idx, row in self.df.iterrows():
            emp = {
                'id': str(idx),
                'name': str(row['name']).strip() if pd.notna(row['name']) else '',
                'title': str(row['title']).strip() if pd.notna(row['title']) else '',
                'manager_id': None
            }

            # Handle manager reference
            manager_val = row.get('manager', None)
            if pd.notna(manager_val) and str(manager_val).strip() != '':
                # Try to find manager by name
                manager_name = str(manager_val).strip()
                # Will resolve to id after building full list
                emp['manager_name'] = manager_name
            else:
                emp['manager_name'] = None

            self.employees.append(emp)

        # Resolve manager names to IDs
        self._resolve_managers()

    def _resolve_managers(self):
        """Convert manager names to manager IDs."""
        name_to_id = {emp['name']: emp['id'] for emp in self.employees}

        for emp in self.employees:
            if emp.get('manager_name'):
                emp['manager_id'] = name_to_id.get(emp['manager_name'], None)
                del emp['manager_name']

    def _find_root(self):
        """Find the root employee (no manager)."""
        for emp in self.employees:
            if emp['manager_id'] is None and emp['name']:
                self.root_id = emp['id']
                return

    def get_data_preview(self) -> pd.DataFrame:
        """Return a copy of the data for preview."""
        return self.df.copy()

    def update_employee(self, idx: int, field: str, value: str):
        """Update a single employee field for correction."""
        if 0 <= idx < len(self.employees):
            self.employees[idx][field] = value.strip()
            # Update dataframe
            col_map = {'name': 'name', 'title': 'title', 'manager_id': 'manager'}
            if field in col_map:
                self.df.at[idx, col_map[field]] = value

    def export_csv(self, output_path: str):
        """Export corrected data to CSV."""
        self.df.to_csv(output_path, index=False)