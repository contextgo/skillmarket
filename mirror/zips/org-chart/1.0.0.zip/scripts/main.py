#!/usr/bin/env python3
"""
Org Chart Generator - CLI Entry Point (Tencent Skillhub version)
Usage: python main.py <input_file> [output_image]
"""

import sys
import os

# Add current dir to path for imports
scripts_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, scripts_dir)

from parser import OrgParser
from layout_engine import LayoutEngine
from renderer import OrgChartRenderer
import config


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print("Usage: python main.py <input_file> [output_image]")
        print("  input_file:   CSV or Excel file with org data")
        print("  output_image: Optional output path (default: org_chart.png)")
        sys.exit(1)

    # Billing: verify token before processing
    from billing import charge_user, check_plan_limits, verify, DEV_MODE
    bill_result = charge_user()
    if not bill_result.get("ok"):
        print(f"Error: {bill_result.get('error', 'Token verification failed')}")
        print(f"Please configure your token at: https://yk-global.com")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else "org_chart.png"

    # Ensure output is in safe directory
    abs_out = os.path.abspath(output_file)
    if not abs_out.startswith("/tmp/org-chart"):
        output_file = os.path.join(config.WORK_DIR, os.path.basename(output_file))
        abs_out = os.path.abspath(output_file)

    # LFI protection: enforce /tmp/org-chart boundary
    if not abs_out.startswith("/tmp/org-chart"):
        print(f"Error: output path must be inside /tmp/org-chart")
        sys.exit(1)

    try:
        # Parse file
        print(f"Parsing {input_file}...")
        parser = OrgParser(input_file)
        employees, root_id = parser.parse()
        print(f"Found {len(employees)} employees, root: {root_id}")

        # Plan check: enforce employee limits per BP
        if not DEV_MODE:
            result = verify()
            plan = result.get("plan", "free")
            allowed, reason = check_plan_limits(plan, len(employees))
            if not allowed:
                print(f"Error: {reason}")
                print(f"Upgrade at: https://yk-global.com")
                sys.exit(1)

        # Build tree layout
        print("Calculating layout...")
        engine = LayoutEngine(
            employees, root_id,
            node_width=config.NODE_WIDTH,
            node_height=config.NODE_HEIGHT,
            level_height=config.LEVEL_HEIGHT,
            sibling_spacing=config.SIBLING_SPACING
        )
        engine.build_tree()
        nodes = engine.calculate_layout()
        connections = engine.get_connections()
        print(f"Layout calculated for {len(nodes)} nodes")

        # Render to PNG
        print(f"Rendering to {output_file}...")
        renderer = OrgChartRenderer(dpi=config.IMAGE_DPI)
        result_path = renderer.render(nodes, connections, output_file)
        print(f"Done! Image saved to: {result_path}")

        return result_path

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
