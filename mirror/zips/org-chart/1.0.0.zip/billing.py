# billing.py - Tencent Skillhub Monthly Subscription Token Verification
# Org Chart Generator - yk-global token verification

import os
import requests

API_BASE = "https://api.yk-global.com/v1/verify"

# Token prefix for this skill
TOKEN_PREFIX = "ORGCHART"
DEV_MODE = os.environ.get("YK_GLOBAL_API_KEY", "") == ""


def get_token_from_header():
    """Get token from FEISHU_USER_ID env var or Authorization header."""
    # FEISHU_USER_ID serves as user identifier for yk-global
    return os.environ.get("FEISHU_USER_ID", os.environ.get("AUTHORIZATION", "")).strip()


def verify() -> dict:
    """
    Verify yk-global token.
    Uses Authorization header with Bearer token.
    Response: valid=true/false, plan, quota_remaining
    """
    token = get_token_from_header()
    if not token:
        return {"valid": False, "error": "No token provided"}

    try:
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        resp = requests.post(
            API_BASE,
            headers=headers,
            json={},
            timeout=10,
        )
        data = resp.json()
        if data.get("valid"):
            # Check token prefix
            prefix = data.get("prefix", "")
            if prefix and not prefix.startswith(TOKEN_PREFIX):
                return {"valid": False, "error": "Token not valid for this service"}
            return {
                "valid": True,
                "plan": data.get("plan", "free"),
                "quota_remaining": data.get("quota_remaining", 0),
            }
        return {"valid": False, "error": data.get("error", "Invalid token")}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def check_plan_limits(plan: str, employee_count: int) -> tuple[bool, str]:
    """
    Check if plan allows the employee count.
    Returns (allowed, reason).
    """
    limits = {
        "free": 30,
        "standard": 200,
        "pro": float("inf"),
    }
    limit = limits.get(plan, 0)
    if employee_count > limit:
        return False, f"Employee count {employee_count} exceeds {plan} plan limit of {limit}"
    return True, ""


def charge_user() -> dict:
    """Verify user has valid token. Called at main() start."""
    if DEV_MODE:
        return {"ok": True, "balance": 999.0, "reason": "dev_mode"}

    result = verify()
    if not result.get("valid"):
        return {
            "ok": False,
            "error": result.get("error", "Token verification failed"),
            "payment_url": "https://yk-global.com",
        }
    return {"ok": True, "balance": result.get("quota_remaining", 0)}
