# 组织架构图生成器 - Skill 说明

## 简介

上传 CSV/Excel 文件，AI 自动解析组织层级关系，一键生成组织架构图。

## 触发词

- 组织架构图
- org chart
- 生成架构图
- 上传员工数据
- CSV 转组织图

## 功能

### P0 功能（V1 必须）

1. **CSV/Excel 上传与解析**
   - 支持 .csv、.xlsx、.xls 格式
   - 自动识别姓名、职位、上级汇报关系列
   - 支持多种列名变体（name/姓名/employee 等）

2. **自动布局算法**
   - 树状布局算法
   - 自动居中父节点
   - 处理多层级结构

3. **PNG 导出**
   - 150 DPI 高清输出
   - 自适应画布
   - 圆角节点设计

4. **数据预览表格**
   - 解析前预览
   - 支持人工修正
   - 导出修正后数据

## 输入要求

文件格式：CSV 或 Excel (.xlsx/.xls)

必需列：
- 姓名 / name / employee
- 职位 / title / position
- 上级 / manager / supervisor

上级列填写上级员工姓名，顶级员工上级留空。

## 输出

PNG 格式组织架构图，PNG 文件路径。

## 价格

- 标准版：¥29/月
- 专业版：¥99/月

## 技术栈

- Python
- pandas（数据解析）
- openpyxl（Excel 读取）
- Matplotlib（图表渲染）

## 安全说明

- 所有路径使用 /tmp/org-chart/
- 不使用 home 目录
- 文件路径验证防注入