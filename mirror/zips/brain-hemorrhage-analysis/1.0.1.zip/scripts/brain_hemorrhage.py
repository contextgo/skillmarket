#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
脑出血原因分析科研模型 - 调用脚本
接口路径: /openapi/brainHemorrhageAnalysis (同步)
数据要求: 头颅 CT 序列（ZIP base64）
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shared_api import file_to_base64, api_post, print_response


# AI 结果映射
RESULT_MAP = {
    0: "动脉瘤型",
    1: "动静脉畸形",
    2: "烟雾病",
    3: "高血压型",
    4: "海绵状血管瘤",
    5: "其他",
}


def run(file_path: str) -> dict:
    """
    调用脑出血原因 AI 判别接口。

    Args:
        file_path: 头颅 CT ZIP 文件路径
    """
    if not os.path.isfile(file_path):
        return {"code": -1, "message": f"文件不存在: {file_path}"}

    body = {
        "fileBase64": file_to_base64(file_path),
        "fileName": os.path.basename(file_path),
    }

    resp = api_post("/openapi/brainHemorrhageAnalysis", body, timeout=180)
    print_response(resp, "脑出血原因分析结果")

    # 解读业务结果
    analysis_list = resp.get("analysisResultList", resp.get("analysisResult", {}))
    if isinstance(analysis_list, dict):
        analysis_list = [analysis_list]

    for item in analysis_list:
        status = item.get("status", "")
        status_map = {
            200: "成功", 0: "处理中", -1: "待处理",
            -2: "失败", -3: "图片不合格", -4: "推理失败", 404: "未找到"
        }
        print(f"  状态: {status_map.get(status, str(status))}")

        if status == 200:
            ai_code = item.get("aiResult", "")
            ai_str = item.get("aiResultString", "")
            reason = RESULT_MAP.get(ai_code, "未知") if ai_code != "" else "未识别"
            print(f"  AI 判别编号: {ai_code}")
            print(f"  AI 判别结果: {reason}")
            if ai_str:
                print(f"  AI 描述: {ai_str}")

    return resp


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("用法: python brain_hemorrhage.py <CT_ZIP文件路径>")
        print("  CT ZIP 需包含头颅 CT 序列")
        sys.exit(1)

    result = run(sys.argv[1])
    code = result.get("head", {}).get("code", result.get("code", -1))
    sys.exit(0 if code == 0 else 1)
