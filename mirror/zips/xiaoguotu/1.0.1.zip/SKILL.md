# 效果图提示词神器

专为小白用户打造的效果图AI提示词生成工具，**v3.0版本**重点增强中文支持，新增中文关键词库、中文场景预设、中文描述自动转换等功能，让中文用户也能轻松生成专业级英文提示词。

## 功能特点

### 核心功能
- **智能描述生成**：输入简单中文描述，自动生成完整提示词
- **中文关键词转换**：内置89项中文关键词库，自动转换为英文
- **20种场景预设**：涵盖家居、商业、户外、建筑四大类
- **10种风格模板**：现代简约、北欧、新中式、轻奢等
- **14种氛围光影**：温馨舒适、高级奢华、清新自然等
- **多平台适配**：支持Midjourney、Stable Diffusion、DALL-E等
- **负面提示词优化**：智能生成负面提示词提升质量
- **参数优化建议**：自动推荐最佳参数设置

## 快速开始

### 方式一：命令行使用

```bash
# 进入脚本目录
cd 效果图提示词神器/scripts

# 从描述生成提示词
python generator.py "现代简约客厅，无主灯设计，木地板"

# 指定风格
python generator.py "轻奢风卧室" 轻奢风格 midjourney

# 从场景预设生成
python generator.py "现代简约客厅"
```

### 方式二：Python模块调用

```python
from scripts import PromptGenerator, quick_generate

# 快速生成
result = quick_generate(
    description="现代简约客厅，无主灯设计",
    style="现代简约",
    platform="midjourney"
)
print(result["main_prompt"])

# 使用生成器
generator = PromptGenerator()
result = generator.generate_from_scene(
    scene="现代简约客厅",
    style="现代简约",
    platform="midjourney"
)
print(result["main_prompt"])
print(result["negative_prompt"])
print(result["parameters"])
```

## 场景预设

### 家居空间（8项）
| 场景 | 关键词 | 默认风格 |
|------|--------|----------|
| 现代简约客厅 | 开阔明亮/无主灯/木地板 | 现代简约 |
| 轻奢风卧室 | 高级感/金属/皮质 | 轻奢风格 |
| 北欧风厨房 | 开放式/岛台/白色橱柜 | 北欧风格 |
| 日式卫生间 | 干湿分离/木纹砖/智能马桶 | 日式风格 |
| 新中式书房 | 书架墙/书法桌/禅意 | 新中式 |
| 法式衣帽间 | 拱形门/水晶灯/岛台 | 法式风格 |
| 奶油风餐厅 | 圆桌/吊灯/绿植 | 轻奢风格 |
| 复古美式厨房 | 深色木柜/双开门冰箱 | 美式风格 |

### 商业空间（5项）
| 场景 | 关键词 |
|------|--------|
| 网红咖啡厅 | 落地窗/绿植墙/INS风 |
| 极简办公室 | 开放工位/玻璃隔断 |
| 高端餐厅 | 卡座/吊灯/酒柜 |
| 潮流零售店 | 道具陈列/打卡墙 |
| 精品酒店大堂 | 艺术装置/沙发区 |

### 户外景观（4项）
| 场景 | 关键词 |
|------|--------|
| 日式禅意庭院 | 枯山水/石灯笼/竹篱 |
| 现代屋顶花园 | 花池/休闲平台/夜景 |
| 法式庄园花园 | 对称设计/雕塑/喷泉 |
| 儿童游乐区 | 彩色地面/安全设施 |

### 建筑外观（3项）
| 场景 | 关键词 |
|------|--------|
| 现代别墅 | 玻璃幕墙/简约造型 |
| 中式合院 | 青瓦白墙/庭院深深 |
| 商业写字楼 | 玻璃幕墙/夜景亮化 |

## 风格选择

| 风格 | 英文 | 特点 |
|------|------|------|
| 现代简约 | Modern Minimalist | 简洁线条/中性色调 |
| 北欧风格 | Nordic/Scandinavian | 原木/白色/温暖 |
| 新中式 | New Chinese | 东方元素/禅意 |
| 轻奢风格 | Light Luxury | 金属/大理石/高级 |
| 工业风 | Industrial | 裸露结构/水泥/金属 |
| 日式风格 | Japanese | 榻榻米/原木/自然 |
| 美式风格 | American Classic | 温暖/舒适/大气 |
| 科技风 | Tech/Futuristic | 冷色调/线条感 |
| 法式风格 | French Romantic | 浪漫/优雅/精致 |
| 混搭风格 | Eclectic | 多风格融合 |

## 氛围光影

| 氛围 | 关键词 |
|------|--------|
| 温馨舒适 | 暖光/柔软 |
| 高级奢华 | 精致/大气 |
| 清新自然 | 明亮/绿植 |
| 科技未来 | 冷光/蓝调 |
| 浪漫唯美 | 柔光/梦幻 |
| 神秘深邃 | 暗调/阴影 |
| 活力动感 | 鲜艳/明亮 |
| 宁静禅意 | 安静/简约 |

## 平台适配

### Midjourney
```python
result = generator.generate_from_scene(
    scene="现代简约客厅",
    platform="midjourney",
    quality="high"
)
# 自动添加: --ar 16:9 --v 6 --style raw --q 2
```

### Stable Diffusion
```python
result = generator.generate_from_scene(
    scene="现代简约客厅",
    platform="stable_diffusion",
    quality="high"
)
# 推荐参数: DPM++ 2M Karras, 40步, CFG 7
```

### DALL-E / Ideogram / Flux
自动适配相应参数格式

## 目录结构

```
效果图提示词神器/
├── SKILL.md              # 本文件
├── scripts/
│   ├── __init__.py       # 模块初始化
│   ├── generator.py      # 核心生成器
│   ├── style_templates.py # 风格模板库
│   ├── chinese_keywords.py # 中文关键词转换
│   ├── negative_prompts.py # 负面提示词
│   ├── parameter_optimizer.py # 参数优化
│   └── utils.py          # 工具函数
├── templates/
│   └── prompt_templates.json # 预设模板
└── data/
    ├── scenes.json       # 场景数据
    └── keywords.json     # 关键词库
```

## 使用示例

### 示例1：生成单套提示词
```python
from scripts import PromptGenerator

generator = PromptGenerator()

# 从场景生成
result = generator.generate_from_scene(
    scene="现代简约客厅",
    style="现代简约",
    platform="midjourney"
)

print("主提示词:", result["main_prompt"])
print("负面提示词:", result["negative_prompt"])
```

### 示例2：生成多个版本对比
```python
# 生成3个不同风格变体
results = generator.generate_multiple_versions(
    scene_or_description="轻奢风卧室",
    count=3,
    platform="midjourney"
)

for i, r in enumerate(results):
    print(f"\n=== 版本 {i+1} ({r['variation_style']}) ===")
    print(r["main_prompt"])
```

### 示例3：中文描述直接生成
```python
result = generator.generate_from_description(
    description="想要一个温馨的客厅，有落地窗，铺木地板，简约风格",
    platform="midjourney"
)
```

## 进阶用法

### 自定义负面提示词
```python
from scripts import NegativePromptManager

manager = NegativePromptManager()

# 获取组合负面提示词
negative = manager.get_negative_prompt(
    platform="midjourney",
    style="轻奢风格",
    quality="high"
)

# 创建自定义组合
custom_negative = manager.create_custom_negative(
    base_platform="midjourney",
    base_style="现代简约",
    exclude_elements=[" clutter", " toys"]
)
```

### 获取参数建议
```python
from scripts import ParameterOptimizer

optimizer = ParameterOptimizer()

params = optimizer.get_parameters(
    platform="midjourney",
    quality="high",
    camera="wide_angle",
    lighting="natural_daylight"
)

print(params)
# {'platform': 'midjourney', 'quality': 'high', 
#  'camera': 'wide_angle', 'camera_description': '...',
#  'aspect_ratio': '16:9', 'quality_param': '--q 2', ...}
```

### 风格组合
```python
from scripts import StyleTemplates

templates = StyleTemplates()

# 组合风格和氛围
combo = templates.combine_style_and_atmosphere(
    style_name="轻奢风格",
    atmosphere_name="浪漫唯美"
)

print(combo["style_keywords"])
print(combo["lighting"])
```

## 关键词库

### 材质类
- 实木：黑胡桃木、白蜡木、橡木、樱桃木
- 金属：黄铜、不锈钢、铁艺
- 石材：大理石、岩板、石英石
- 布艺：丝绒、亚麻、科技布、皮质

### 家具类
- 沙发：转角沙发、模块沙发、悬浮沙发
- 床：悬浮床、地台床、皮质床
- 桌椅：餐桌、书桌、茶几

### 灯饰类
- 主灯：吊灯、吸顶灯、轨道灯
- 辅助：筒灯、射灯、灯带、壁灯
- 氛围：落地灯、台灯、星星灯

## 常见问题

### Q: 如何选择合适的宽高比？
- **室内全景**：16:9
- **建筑外观**：3:2
- **人像/垂直空间**：9:16
- **细部特写**：1:1

### Q: 质量参数怎么选？
- **快速草图**：--q 0.5 / low
- **标准质量**：--q 1 / medium
- **高品质**：--q 2 / high（推荐）
- **最高品质**：--q 2 + 多次生成 / ultra

### Q: 如何避免AI生成常见问题？
使用完整的负面提示词：
```python
result = generator.generate_from_scene(
    scene="场景",
    include_negative=True  # 默认开启
)
```

## 版本历史

- **v3.0**: 增强中文支持，新增中文关键词库、中文场景预设
- **v2.0**: 增强智能诊断，完善多平台适配
- **v1.0**: 基础功能上线

## 相关资源

- 场景数据：`data/scenes.json`
- 关键词库：`data/keywords.json`
- 预设模板：`templates/prompt_templates.json`
