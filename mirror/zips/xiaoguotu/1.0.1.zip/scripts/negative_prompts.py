#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
负面提示词管理器

提供各平台和风格的负面提示词，包括：
- 通用负面提示词
- 风格特定负面提示词
- 平台特定优化
- 自定义负面提示词组合
"""

from typing import Dict, List, Optional, Any


class NegativePromptManager:
    """负面提示词管理器"""
    
    # 通用负面提示词（适用于所有平台）
    COMMON_NEGATIVE = [
        "blurry",
        "low quality",
        "low resolution",
        "pixelated",
        "grainy",
        "noise",
        "distorted",
        "deformed",
        "disfigured",
        "bad anatomy",
        "bad proportions",
        "bad hands",
        "missing fingers",
        "extra fingers",
        "fused fingers",
        "poorly drawn",
        "amateur",
        "amateur drawing",
        "out of frame",
        "watermark",
        "text",
        "logo",
        "signature",
        "username",
        "cropped",
        "worst quality",
        "jpeg artifacts",
        "jpeg artefacts",
        "duplicate",
        "morbid",
        "mutilated",
        "mutation",
        "mutated",
        "ugly",
        "gross proportions",
        "missing arms",
        "missing legs",
        "extra limbs",
        "floating limbs",
        "disconnected limbs",
        "deformed hands",
        "unclear anatomy",
        "wrong anatomy",
        "long neck",
        "cross-eyed",
        "mutation hands",
        "mutation body"
    ]
    
    # 建筑效果图专用负面提示词
    ARCHITECTURE_NEGATIVE = [
        "furniture looks fake",
        "plastic furniture",
        "toy-like furniture",
        "render error",
        "rendering artifacts",
        "unrealistic lighting",
        "harsh shadows",
        "overexposed",
        "underexposed",
        "incorrect scale",
        "wrong proportions",
        "dwarf furniture",
        "tiny furniture",
        "oversized furniture",
        "human figure distortion",
        "people look like dolls",
        "cloned furniture",
        "repetitive elements",
        "stretched textures",
        "blurry windows",
        "reflection error",
        "daylight interior looks dark",
        "fake plants",
        "low-poly look",
        "cgi appearance",
        "3d render look",
        "unrealistic materials",
        "fake wood texture",
        "fake marble pattern"
    ]
    
    # 室内设计专用负面提示词
    INTERIOR_NEGATIVE = [
        "cramped space",
        "claustrophobic",
        "cluttered",
        "messy",
        "unorganized",
        "poor lighting",
        "dark interior",
        "dull colors",
        "mismatched furniture",
        "cheap materials",
        "plastic look",
        "synthetic materials visible",
        "visible seams",
        "poor craftsmanship",
        "amateur design",
        "outdated style",
        "old fashioned",
        "dusty",
        "worn out",
        "stained",
        "scratched surfaces",
        "damaged walls",
        "cracks in wall",
        "uneven flooring",
        "curtains look fake",
        "plants look fake",
        "decor looks cheap",
        "personal belongings visible",
        "clothes visible",
        "dishes visible",
        "unmade bed"
    ]
    
    # 风格特定负面提示词
    STYLE_NEGATIVE: Dict[str, List[str]] = {
        "现代简约": [
            "ornate details",
            "excessive decoration",
            "cluttered surfaces",
            "mismatched styles",
            "outdated fixtures",
            "heavy curtains",
            "ornate moldings",
            "frilly elements",
            "vintage items",
            "antique furniture",
            "grandfather clock",
            "clutter visible"
        ],
        "北欧风格": [
            "dark wood",
            "heavy dark furniture",
            "ornate patterns",
            "excessive ornamentation",
            "synthetic materials",
            "plastic look",
            "cluttered appearance",
            "harsh lighting",
            "cold atmosphere",
            "uncomfortable looking",
            "pile of clutter"
        ],
        "轻奢风格": [
            "cheap imitations",
            "overly gaudy gold",
            "tacky decorations",
            "mismatched materials",
            "poor craftsmanship",
            "fake marble",
            "faux finish looks fake",
            "flimsy materials",
            "low quality accessories",
            "knockoff designer items"
        ],
        "工业风": [
            "delicate decorations",
            "soft pastels",
            "ornate moldings",
            "excessive polish",
            "cluttered spaces",
            "shabby chic",
            "cozy elements",
            "soft furnishings",
            "lace details",
            "frilly curtains"
        ],
        "日式风格": [
            "loud colors",
            "western furniture",
            "excessive decoration",
            "synthetic materials",
            "cluttered spaces",
            "ornate details",
            "western style bed",
            "sofa bed visible",
            "toilet visible",
            "modern appliances visible",
            "western art prints"
        ],
        "新中式": [
            "kitschy red and gold",
            "excessive dragon motifs",
            "overly ornate Chinese decorations",
            "clashing modern elements",
            "cheap reproductions",
            "plastic bamboo",
            "fake antique furniture",
            "loud colors",
            "mismatched traditional elements"
        ],
        "法式风格": [
            "harsh modern lines",
            "industrial materials",
            "clashing colors",
            "cheap reproductions",
            "mismatched antiques",
            "plastic flowers",
            "artificial plants",
            "mass-produced furniture"
        ],
        "科技风": [
            "warm colors",
            "natural materials",
            "traditional patterns",
            "soft textures",
            "antique elements",
            "organic shapes",
            "cozy atmosphere",
            "vintage tech",
            "wooden furniture",
            "soft lighting"
        ]
    }
    
    # 平台特定负面提示词
    PLATFORM_NEGATIVE: Dict[str, List[str]] = {
        "midjourney": [
            "photo",
            "photograph",
            "real photo",
            "realistic photo",
            "camera photo",
            "自拍",
            "selfie",
            "human face",
            "human body",
            "person",
            "people",
            "ugly",
            "disfigured",
            "cropped"
        ],
        "stable_diffusion": [
            "nsfw",
            "explicit",
            "sexy",
            "nude",
            "naked",
            "human face",
            "human body",
            "person",
            "people",
            "hands",
            "text",
            "watermark",
            "signature",
            "logo"
        ],
        "dall-e": [
            "text overlay",
            "signature",
            "watermark",
            "lettering",
            "human face focus",
            "person centered",
            "portrait orientation"
        ],
        "ideogram": [
            "text",
            "lettering",
            "words",
            "numbers",
            "signature",
            "watermark",
            "logo",
            "brand name"
        ],
        "flux": [
            "text",
            "watermark",
            "signature",
            "logo",
            "deformed hands",
            "bad anatomy",
            "human face"
        ]
    }
    
    # 质量级别对应的负面提示词
    QUALITY_NEGATIVE: Dict[str, List[str]] = {
        "low": [
            "medium quality",
            "average quality",
            "low detail"
        ],
        "medium": [
            "low quality",
            "low resolution"
        ],
        "high": [],
        "ultra": [
            "medium quality",
            "average quality",
            "standard quality"
        ]
    }
    
    def __init__(self):
        """初始化负面提示词管理器"""
        self.common = self.COMMON_NEGATIVE
        self.architecture = self.ARCHITECTURE_NEGATIVE
        self.interior = self.INTERIOR_NEGATIVE
        self.style_negative = self.STYLE_NEGATIVE
        self.platform_negative = self.PLATFORM_NEGATIVE
    
    def get_negative_prompt(
        self,
        platform: str = "midjourney",
        style: str = None,
        category: str = "interior",
        quality: str = "high"
    ) -> str:
        """
        获取完整的负面提示词
        
        Args:
            platform: 目标平台
            style: 设计风格
            category: 图片类别 (interior/architecture)
            quality: 质量级别
        
        Returns:
            负面提示词字符串
        """
        parts = []
        
        # 添加通用负面提示词
        parts.extend(self.common)
        
        # 添加类别特定负面提示词
        if category == "architecture":
            parts.extend(self.architecture)
        else:
            parts.extend(self.interior)
        
        # 添加风格特定负面提示词
        if style and style in self.style_negative:
            parts.extend(self.style_negative[style])
        
        # 添加平台特定负面提示词
        if platform in self.platform_negative:
            parts.extend(self.platform_negative[platform])
        
        # 添加质量级别负面提示词
        if quality in self.QUALITY_NEGATIVE:
            parts.extend(self.QUALITY_NEGATIVE[quality])
        
        # 去重
        unique_parts = list(dict.fromkeys(parts))
        
        return ", ".join(unique_parts)
    
    def get_style_negative(self, style: str) -> str:
        """
        获取特定风格的负面提示词
        
        Args:
            style: 设计风格
        
        Returns:
            风格负面提示词字符串
        """
        if style not in self.style_negative:
            return ""
        
        return ", ".join(self.style_negative[style])
    
    def get_platform_negative(self, platform: str) -> str:
        """
        获取特定平台的负面提示词
        
        Args:
            platform: 目标平台
        
        Returns:
            平台负面提示词字符串
        """
        if platform not in self.platform_negative:
            return ", ".join(self.common)
        
        parts = list(self.common)
        parts.extend(self.platform_negative[platform])
        
        return ", ".join(list(dict.fromkeys(parts)))
    
    def add_custom_negative(
        self,
        keywords: List[str],
        scope: str = "global"
    ):
        """
        添加自定义负面提示词
        
        Args:
            keywords: 负面关键词列表
            scope: 添加范围 (global/style/platform)
        """
        if scope == "global":
            self.common.extend(keywords)
        elif scope in self.style_negative:
            self.style_negative[scope].extend(keywords)
        elif scope in self.platform_negative:
            self.platform_negative[scope].extend(keywords)
    
    def create_custom_negative(
        self,
        base_platform: str = "midjourney",
        base_style: str = None,
        custom_keywords: List[str] = None,
        exclude_elements: List[str] = None
    ) -> str:
        """
        创建自定义负面提示词
        
        Args:
            base_platform: 基础平台
            base_style: 基础风格
            custom_keywords: 自定义关键词
            exclude_elements: 需要排除的元素描述
        
        Returns:
            组合后的负面提示词
        """
        parts = []
        
        # 从基础平台获取
        parts.extend(self.common)
        if base_platform in self.platform_negative:
            parts.extend(self.platform_negative[base_platform])
        
        # 从基础风格获取
        if base_style and base_style in self.style_negative:
            parts.extend(self.style_negative[base_style])
        
        # 添加自定义关键词
        if custom_keywords:
            parts.extend(custom_keywords)
        
        # 处理排除元素（需要转换描述为负面词）
        if exclude_elements:
            for element in exclude_elements:
                parts.append(f"with {element}")
                parts.append(f"{element} visible")
                parts.append(f"too much {element}")
        
        # 去重
        unique_parts = list(dict.fromkeys(parts))
        
        return ", ".join(unique_parts)
    
    def optimize_for_reference(
        self,
        reference_style: str,
        platform: str = "midjourney"
    ) -> str:
        """
        根据参考图风格优化负面提示词
        
        Args:
            reference_style: 参考图风格
            platform: 目标平台
        
        Returns:
            优化后的负面提示词
        """
        parts = list(self.common)
        
        # 添加平台特定
        if platform in self.platform_negative:
            parts.extend(self.platform_negative[platform])
        
        # 针对参考风格，排除其他风格元素
        all_styles = set(self.style_negative.keys())
        all_styles.discard(reference_style)
        
        for style in all_styles:
            parts.extend(self.style_negative[style][:3])  # 只取前3个
        
        return ", ".join(list(dict.fromkeys(parts))[:50])  # 限制数量


# 命令行入口
if __name__ == "__main__":
    manager = NegativePromptManager()
    
    print("=" * 60)
    print("负面提示词管理器")
    print("=" * 60)
    
    # 测试各平台负面提示词
    platforms = ["midjourney", "stable_diffusion", "dall-e", "ideogram", "flux"]
    
    print("\n【各平台通用负面提示词】")
    for platform in platforms:
        np = manager.get_platform_negative(platform)
        print(f"\n{platform}:")
        print(f"  {np[:200]}..." if len(np) > 200 else f"  {np}")
    
    # 测试风格负面提示词
    print("\n【风格特定负面提示词示例】")
    for style in ["现代简约", "轻奢风格", "工业风"]:
        np = manager.get_style_negative(style)
        print(f"\n{style}:")
        print(f"  {np}")
    
    # 测试完整组合
    print("\n【完整负面提示词示例】")
    result = manager.get_negative_prompt(
        platform="midjourney",
        style="轻奢风格",
        category="interior",
        quality="high"
    )
    print(f"  长度: {len(result)} 字符")
    print(f"  内容: {result[:300]}...")
