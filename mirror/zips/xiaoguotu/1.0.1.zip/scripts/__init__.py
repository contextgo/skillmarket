"""
效果图提示词神器 - scripts 模块初始化文件

该模块提供完整的AI效果图提示词生成功能：
- 中文关键词到英文提示词的转换
- 多种风格模板支持
- 场景预设快速生成
- 负面提示词优化
- 多平台参数适配
"""

# 兼容相对导入和直接运行
try:
    from .generator import PromptGenerator
    from .style_templates import StyleTemplates
    from .chinese_keywords import ChineseKeywordConverter
    from .negative_prompts import NegativePromptManager
    from .parameter_optimizer import ParameterOptimizer
except ImportError:
    from generator import PromptGenerator
    from style_templates import StyleTemplates
    from chinese_keywords import ChineseKeywordConverter
    from negative_prompts import NegativePromptManager
    from parameter_optimizer import ParameterOptimizer

__version__ = "1.0.2"
__all__ = [
    "PromptGenerator",
    "StyleTemplates", 
    "ChineseKeywordConverter",
    "NegativePromptManager",
    "ParameterOptimizer",
]

def create_generator():
    """创建提示词生成器实例"""
    return PromptGenerator()

def quick_generate(description: str, style: str = None, platform: str = "midjourney") -> str:
    """
    快速生成提示词
    
    Args:
        description: 简短的中文描述
        style: 风格名称（可选）
        platform: 目标平台（midjourney/stable_diffusion/dall-e）
    
    Returns:
        生成的提示词
    """
    generator = PromptGenerator()
    return generator.generate_from_description(description, style, platform)
