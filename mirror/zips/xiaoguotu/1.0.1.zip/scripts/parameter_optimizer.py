#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
参数优化建议器

为各平台提供参数优化建议，包括：
- 画质参数
- 视角/构图参数
- 风格参数
- 光影参数
- 平台特定参数
"""

from typing import Dict, List, Optional, Any


class ParameterOptimizer:
    """参数优化建议器"""
    
    # 平台配置
    PLATFORMS: Dict[str, Dict[str, Any]] = {
        "midjourney": {
            "aspect_ratios": {
                "16:9": "landscape, panoramic view",
                "9:16": "portrait, vertical shot",
                "1:1": "square, balanced composition",
                "4:3": "standard, classic ratio",
                "3:2": "photo ratio, natural feel",
                "2:3": "portrait photo, tall subjects"
            },
            "quality_presets": {
                "low": "--q 0.5",
                "medium": "--q 1",
                "high": "--q 2",
                "ultra": "--q 2 --quality 1"
            },
            "style_presets": [
                "raw", "photographic", "digital art", "anime", "comic book",
                "cinematic", "fantasy art", "isometric", "line art", "3d model"
            ],
            "version_params": ["--v 5.2", "--v 6", "--v 6.1"],
            "stylize_range": (50, 1000),
            "chaos_range": (0, 100),
            "seed_support": True,
            "remix_mode": True
        },
        "stable_diffusion": {
            "sampler_presets": [
                "DPM++ 2M Karras",
                "DPM++ SDE Karras",
                "Euler a",
                "Euler",
                "DDIM",
                "PLMS",
                "UniPC"
            ],
            "steps_presets": {
                "fast": 20,
                "balanced": 30,
                "quality": 50,
                "ultra": 80
            },
            "cfg_scale_range": (1, 15),
            "recommended": {
                "portrait": {"cfg": 7, "steps": 30, "sampler": "Euler a"},
                "landscape": {"cfg": 7.5, "steps": 35, "sampler": "DPM++ 2M Karras"},
                "interior": {"cfg": 7, "steps": 40, "sampler": "DPM++ SDE Karras"},
                "architecture": {"cfg": 7.5, "steps": 45, "sampler": "DPM++ 2M Karras"}
            }
        },
        "dall-e": {
            "size_presets": ["1024x1024", "1024x1792", "1792x1024"],
            "quality_presets": ["standard", "hd"],
            "style_presets": ["vivid", "natural"],
            "no_params": True
        },
        "ideogram": {
            "aspect_ratios": {
                "1:1": "square",
                "16:9": "landscape",
                "9:16": "portrait",
                "4:3": "landscape-wide",
                "3:4": "portrait-tall"
            },
            "style_presets": [
                "REALISTIC", "DESIGN", "RENDER", "3D_MODEL", "ANIME",
                "ESCAPE_ROOM", "RETRO", "STUDIO_PHOTO", "ADVERTISEMENT",
                "ARCHITECTURE_INTERIOR", "ARCHITECTURE_EXTERIOR"
            ],
            "magic_prompt": "on"
        },
        "flux": {
            "aspect_ratios": {
                "1:1": "square",
                "16:9": "landscape",
                "9:16": "portrait",
                "4:3": "landscape-standard",
                "3:2": "landscape-photo",
                "2:3": "portrait-photo"
            },
            "quality_presets": ["auto", "high", "low"],
            "guidance_presets": {
                "fast": 1.0,
                "balanced": 3.5,
                "quality": 7.5
            }
        }
    }
    
    # 相机视角参数
    CAMERA_ANGLES: Dict[str, str] = {
        "eye_level": "eye level view, natural perspective, human eye height",
        "low_angle": "low angle shot, looking up, dramatic perspective",
        "high_angle": "high angle shot, bird's eye, overlooking view",
        "bird_eye": "bird's eye view, top-down, overhead shot, plan view",
        "dutch_angle": "dutch angle, tilted horizon, dynamic composition",
        "wide_angle": "wide angle lens, 24mm perspective, expansive view",
        "telephoto": "telephoto lens, compressed perspective, 85mm feel",
        "fisheye": "fisheye lens, ultra-wide distortion, 180 degree view",
        "macro": "macro lens, close-up detail, intimate detail shot",
        "panoramic": "panoramic view, wide establishing shot, sweeping vista"
    }
    
    # 构图类型
    COMPOSITIONS: Dict[str, str] = {
        "centered": "centered composition, symmetrical, balanced",
        "rule_of_thirds": "rule of thirds composition, off-center subject",
        "leading_lines": "leading lines composition, guided perspective",
        "frame_within": "frame within frame, layered composition",
        "negative_space": "negative space, minimal composition, breathing room",
        "symmetry": "symmetrical composition, mirror image, perfect balance",
        "golden_ratio": "golden ratio composition, natural proportions",
        "diagonal": "diagonal composition, dynamic tension, movement"
    }
    
    # 光影类型
    LIGHTING_TYPES: Dict[str, str] = {
        "natural_daylight": "natural daylight, soft shadows, overcast sky",
        "golden_hour": "golden hour lighting, warm sunset, magic hour glow",
        "blue_hour": "blue hour lighting, twilight, cool ambient",
        "studio_light": "studio lighting, professional photography, controlled light",
        "dramatic": "dramatic lighting, chiaroscuro, high contrast",
        "soft": "soft lighting, diffused light, gentle shadows",
        "rim_light": "rim lighting, edge light, silhouette accent",
        "back_light": "backlighting, silhouette, light behind subject",
        "candlelight": "candlelight ambiance, warm flickering, intimate",
        "neon": "neon lighting, colorful glow, cyberpunk atmosphere"
    }
    
    def __init__(self):
        """初始化参数优化器"""
        self.platforms = self.PLATFORMS
        self.camera_angles = self.CAMERA_ANGLES
        self.compositions = self.COMPOSITIONS
        self.lighting_types = self.LIGHTING_TYPES
    
    def get_parameters(
        self,
        platform: str = "midjourney",
        quality: str = "high",
        style: str = None,
        camera: str = None,
        composition: str = None,
        lighting: str = None
    ) -> Dict[str, Any]:
        """
        获取推荐参数
        
        Args:
            platform: 目标平台
            quality: 质量级别
            style: 设计风格
            camera: 相机视角
            composition: 构图类型
            lighting: 光影类型
        
        Returns:
            参数字典
        """
        if platform not in self.platforms:
            platform = "midjourney"
        
        platform_config = self.platforms[platform]
        
        params = {
            "platform": platform,
            "quality": quality
        }
        
        # 基础参数
        if platform == "midjourney":
            params.update(self._get_midjourney_params(quality, camera))
        elif platform == "stable_diffusion":
            params.update(self._get_stable_diffusion_params(quality, style))
        elif platform == "dall-e":
            params.update(self._get_dall_e_params(quality))
        elif platform == "ideogram":
            params.update(self._get_ideogram_params(camera))
        elif platform == "flux":
            params.update(self._get_flux_params(quality, camera))
        
        # 视角/构图/光影
        if camera and camera in self.camera_angles:
            params["camera"] = camera
            params["camera_description"] = self.camera_angles[camera]
        
        if composition and composition in self.compositions:
            params["composition"] = composition
            params["composition_description"] = self.compositions[composition]
        
        if lighting and lighting in self.lighting_types:
            params["lighting"] = lighting
            params["lighting_description"] = self.lighting_types[lighting]
        
        return params
    
    def _get_midjourney_params(self, quality: str, camera: str) -> Dict[str, Any]:
        """获取Midjourney参数"""
        config = self.platforms["midjourney"]
        
        params = {
            "aspect_ratio": "16:9",
            "aspect_description": config["aspect_ratios"]["16:9"],
            "quality_param": config["quality_presets"].get(quality, "--q 2"),
            "style_param": "--style raw",
            "version": "--v 6",
            "remix": False
        }
        
        return params
    
    def _get_stable_diffusion_params(self, quality: str, style: str) -> Dict[str, Any]:
        """获取Stable Diffusion参数"""
        config = self.platforms["stable_diffusion"]
        
        # 根据质量选择预设
        steps_key = "ultra" if quality == "ultra" else ("quality" if quality == "high" else "balanced")
        
        # 根据风格选择推荐配置
        recommended = config["recommended"].get("interior", config["recommended"]["portrait"])
        
        params = {
            "sampler": recommended["sampler"],
            "steps": config["steps_presets"][steps_key],
            "cfg_scale": recommended["cfg"],
            "denoising_strength": 0.7 if quality == "high" else 0.5
        }
        
        return params
    
    def _get_dall_e_params(self, quality: str) -> Dict[str, Any]:
        """获取DALL-E参数"""
        config = self.platforms["dall-e"]
        
        return {
            "size": "1024x1024",
            "quality": config["quality_presets"][0] if quality == "high" else config["quality_presets"][1],
            "style": config["style_presets"][0]
        }
    
    def _get_ideogram_params(self, camera: str) -> Dict[str, Any]:
        """获取Ideogram参数"""
        config = self.platforms["ideogram"]
        
        # 根据视角选择比例
        aspect = "landscape" if camera in ["wide_angle", "panoramic"] else "square"
        
        return {
            "aspect_ratio": aspect,
            "style_preset": "ARCHITECTURE_INTERIOR" if "interior" in str(camera) else "REALISTIC",
            "magic_prompt": "on"
        }
    
    def _get_flux_params(self, quality: str, camera: str) -> Dict[str, Any]:
        """获取Flux参数"""
        config = self.platforms["flux"]
        
        return {
            "aspect_ratio": "16:9",
            "quality": config["quality_presets"][1] if quality == "high" else config["quality_presets"][0],
            "guidance": config["guidance_presets"]["quality"] if quality == "high" else config["guidance_presets"]["balanced"]
        }
    
    def get_quality_tag(self, platform: str, quality: str) -> str:
        """
        获取质量参数标签
        
        Args:
            platform: 目标平台
            quality: 质量级别
        
        Returns:
            质量参数字符串
        """
        if platform not in self.platforms:
            platform = "midjourney"
        
        config = self.platforms[platform]
        
        if platform == "midjourney":
            return config["quality_presets"].get(quality, "--q 2")
        elif platform == "dall-e":
            presets = {"low": "standard", "medium": "standard", "high": "hd", "ultra": "hd"}
            return presets.get(quality, "standard")
        
        return ""
    
    def get_aspect_ratio_suggestion(
        self,
        scene_type: str,
        platform: str = "midjourney"
    ) -> Dict[str, str]:
        """
        获取场景类型的推荐宽高比
        
        Args:
            scene_type: 场景类型 (interior/architecture/landscape/detail)
            platform: 目标平台
        
        Returns:
            宽高比建议
        """
        suggestions = {
            "interior": {
                "wide": "16:9",
                "description": "客厅、卧室等空间全景"
            },
            "architecture": {
                "wide": "3:2",
                "description": "建筑外观、立面"
            },
            "landscape": {
                "wide": "16:9",
                "description": "庭院、花园等户外景观"
            },
            "detail": {
                "square": "1:1",
                "description": "材质、细部特写"
            }
        }
        
        scene_config = suggestions.get(scene_type, suggestions["interior"])
        
        return {
            "ratio": scene_config.get("wide", "16:9"),
            "description": scene_config["description"],
            "platform_specific": self.PLATFORMS.get(platform, {}).get(
                "aspect_ratios", {}
            ).get(scene_config.get("wide", "16:9"), "")
        }
    
    def get_style_params(self, style: str, platform: str = "midjourney") -> str:
        """
        获取风格特定参数
        
        Args:
            style: 设计风格
            platform: 目标平台
        
        Returns:
            风格参数字符串
        """
        if platform != "midjourney":
            return ""
        
        style_params = {
            "现代简约": "--style raw",
            "北欧风格": "--style raw",
            "轻奢风格": "--style raw",
            "工业风": "--style raw",
            "日式风格": "--style raw",
            "新中式": "--style raw",
            "法式风格": "--style raw",
            "科技风": "--style photographic",
            "美式风格": "--style raw",
            "混搭风格": "--style raw"
        }
        
        return style_params.get(style, "--style raw")
    
    def generate_parameter_string(
        self,
        platform: str,
        quality: str = "high",
        aspect_ratio: str = None,
        style: str = None,
        stylize: int = None,
        chaos: int = None
    ) -> str:
        """
        生成完整的参数字符串
        
        Args:
            platform: 目标平台
            quality: 质量级别
            aspect_ratio: 宽高比
            style: 设计风格
            stylize: 风格化程度 (MJ)
            chaos: 随机程度 (MJ)
        
        Returns:
            参数字符串
        """
        parts = []
        
        if platform == "midjourney":
            # 质量
            quality_tag = self.get_quality_tag(platform, quality)
            if quality_tag:
                parts.append(quality_tag)
            
            # 宽高比
            if aspect_ratio and aspect_ratio in self.PLATFORMS["midjourney"]["aspect_ratios"]:
                parts.append(f"--ar {aspect_ratio}")
            
            # 风格
            style_tag = self.get_style_params(style, platform)
            if style_tag:
                parts.append(style_tag)
            
            # 风格化程度
            if stylize is not None:
                parts.append(f"--s {stylize}")
            
            # 随机程度
            if chaos is not None:
                parts.append(f"--c {chaos}")
            
            # 版本
            parts.append("--v 6")
        
        elif platform == "stable_diffusion":
            # Stable Diffusion 参数以字典形式返回
            return ""
        
        elif platform == "dall-e":
            return ""
        
        return " ".join(parts)


# 命令行入口
if __name__ == "__main__":
    optimizer = ParameterOptimizer()
    
    print("=" * 60)
    print("参数优化建议器")
    print("=" * 60)
    
    # 测试各平台参数
    platforms = ["midjourney", "stable_diffusion", "dall-e", "ideogram", "flux"]
    
    print("\n【各平台参数】")
    for platform in platforms:
        params = optimizer.get_parameters(platform, quality="high")
        print(f"\n{platform}:")
        for key, value in params.items():
            print(f"  {key}: {value}")
    
    # 测试视角建议
    print("\n【视角类型】")
    for angle, desc in list(optimizer.camera_angles.items())[:5]:
        print(f"  {angle}: {desc}")
    
    # 测试构图建议
    print("\n【构图类型】")
    for comp, desc in optimizer.compositions.items():
        print(f"  {comp}: {desc}")
    
    # 测试光影建议
    print("\n【光影类型】")
    for light, desc in optimizer.lighting_types.items():
        print(f"  {light}: {desc}")
    
    # 测试参数字符串生成
    print("\n【Midjourney参数字符串】")
    param_str = optimizer.generate_parameter_string(
        platform="midjourney",
        quality="high",
        aspect_ratio="16:9",
        style="轻奢风格",
        stylize=100,
        chaos=10
    )
    print(f"  {param_str}")
