#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
效果图提示词生成器 - 核心模块

提供完整的提示词生成功能，包括：
- 从中文描述智能生成英文提示词
- 支持多种场景和风格
- 多平台适配（Midjourney、Stable Diffusion、DALL-E）
- 一键生成多个方案对比
"""

import json
import random
from typing import Dict, List, Optional, Any
try:
    from .style_templates import StyleTemplates
    from .chinese_keywords import ChineseKeywordConverter
    from .negative_prompts import NegativePromptManager
    from .parameter_optimizer import ParameterOptimizer
except ImportError:
    from style_templates import StyleTemplates
    from chinese_keywords import ChineseKeywordConverter
    from negative_prompts import NegativePromptManager
    from parameter_optimizer import ParameterOptimizer


class PromptGenerator:
    """提示词生成器核心类"""
    
    # 场景预设配置
    SCENE_PRESETS = {
        # 家居空间
        "现代简约客厅": {
            "en": "modern minimalist living room",
            "elements": ["open and bright", "no main lamp design", "wooden floor", 
                        "large windows", "simple sofa", "neutral tones"],
            "lighting": "natural daylight",
            "camera": "wide angle"
        },
        "轻奢风卧室": {
            "en": "luxurious bedroom",
            "elements": ["high-end feel", "metal elements", "leather upholstery",
                        "soft lighting", "premium materials", "designer bedside lamps"],
            "lighting": "warm ambient",
            "camera": "eye level"
        },
        "北欧风厨房": {
            "en": "Nordic style kitchen",
            "elements": ["open concept", "kitchen island", "white cabinets",
                        "natural wood", "minimalist design", "hanging pendant lights"],
            "lighting": "bright natural",
            "camera": "medium shot"
        },
        "日式卫生间": {
            "en": "Japanese style bathroom",
            "elements": ["dry-wet separation", "wood grain tiles", "smart toilet",
                        "wooden accents", "minimalist fixtures", "warm lighting"],
            "lighting": "soft warm",
            "camera": "detail shot"
        },
        "新中式书房": {
            "en": "new Chinese study room",
            "elements": ["bookshelf wall", "calligraphy desk", "zen decorations",
                        "traditional elements", "modern interpretation", "ink painting"],
            "lighting": "warm natural",
            "camera": "three-quarter view"
        },
        "法式衣帽间": {
            "en": "French walk-in closet",
            "elements": ["arched doorway", "crystal chandelier", "island display",
                        "ornate details", "soft pink tones", "vanity mirror"],
            "lighting": "elegant warm",
            "camera": "front view"
        },
        "奶油风餐厅": {
            "en": "cream style dining room",
            "elements": ["round dining table", "hanging pendant lamp", "green plants",
                        "warm cream tones", "cozy atmosphere", "wooden flooring"],
            "lighting": "warm intimate",
            "camera": "overhead shot"
        },
        "复古美式厨房": {
            "en": "vintage American kitchen",
            "elements": ["dark wood cabinets", "double door refrigerator", "classic design",
                        "farmhouse sink", "open shelving", "copper accents"],
            "lighting": "warm incandescent",
            "camera": "corner view"
        },
        
        # 商业空间
        "网红咖啡厅": {
            "en": "trendy coffee shop",
            "elements": ["floor-to-ceiling windows", "green plant wall", "Instagrammable decor",
                        "boutique feel", "comfortable seating", "artisan details"],
            "lighting": "natural plus accent",
            "camera": "wide establishing"
        },
        "极简办公室": {
            "en": "minimalist office",
            "elements": ["open workstations", "glass meeting room partitions",
                        "clean lines", "neutral palette", "modern furniture"],
            "lighting": "bright office",
            "camera": "eye level walkthrough"
        },
        "高端餐厅": {
            "en": "high-end restaurant",
            "elements": ["booth seating", "designer pendant lights", "wine display",
                        "elegant atmosphere", "premium materials", "ambient lighting"],
            "lighting": "intimate dim",
            "camera": "table setting view"
        },
        "潮流零售店": {
            "en": "trendy retail store",
            "elements": ["display merchandising", "photo wall", "brand identity",
                        "interactive displays", "bright lighting", "modern fixtures"],
            "lighting": "professional retail",
            "camera": "storefront view"
        },
        "精品酒店大堂": {
            "en": "boutique hotel lobby",
            "elements": ["art installation", "lounge seating area", "reception desk",
                        "designer furniture", "welcoming atmosphere", "premium finishes"],
            "lighting": "warm welcoming",
            "camera": "grand entrance view"
        },
        
        # 户外景观
        "日式禅意庭院": {
            "en": "Japanese zen garden",
            "elements": ["dry landscape (karesansui)", "stone lantern", "bamboo fence",
                        "raked gravel", "pruned trees", "tranquil atmosphere"],
            "lighting": "soft natural",
            "camera": "aerial overview"
        },
        "现代屋顶花园": {
            "en": "modern rooftop garden",
            "elements": ["raised flower beds", "outdoor lounge platform", "landscape lighting",
                        "city skyline view", "pergola structure", "privacy screening"],
            "lighting": "evening ambiance",
            "camera": "bird's eye"
        },
        "法式庄园花园": {
            "en": "French manor garden",
            "elements": ["symmetrical design", "sculpture features", "fountain centerpiece",
                        "manicured hedges", "gravel pathways", "classical elements"],
            "lighting": "golden hour",
            "camera": "formal perspective"
        },
        "儿童游乐区": {
            "en": "children's play area",
            "elements": ["colorful flooring", "safety features", "parent observation area",
                        "play structures", "bright colors", "rubber surfacing"],
            "lighting": "bright safe",
            "camera": "play perspective"
        },
        
        # 建筑外观
        "现代别墅外观": {
            "en": "modern villa exterior",
            "elements": ["glass curtain wall", "simple geometric form", "premium facade",
                        "landscaped entrance", "modern garage", "floating roof design"],
            "lighting": "dramatic accent",
            "camera": "exterior hero shot"
        },
        "中式合院": {
            "en": "Chinese courtyard house",
            "elements": ["gray tiles white walls", "deep courtyard", "traditional gate",
                        "landscaped garden", "covered walkway", "harmonious proportions"],
            "lighting": "warm traditional",
            "camera": "courtyard view"
        },
        "商业写字楼": {
            "en": "commercial office building",
            "elements": ["glass curtain wall", "night lighting", "modern lobby entrance",
                        "sustainable design", "public plaza", "architectural details"],
            "lighting": "dramatic night",
            "camera": "full elevation"
        }
    }
    
    def __init__(self):
        """初始化生成器"""
        self.style_templates = StyleTemplates()
        self.keyword_converter = ChineseKeywordConverter()
        self.negative_manager = NegativePromptManager()
        self.param_optimizer = ParameterOptimizer()
        
    def generate_from_description(
        self, 
        description: str, 
        style: str = None,
        platform: str = "midjourney",
        include_negative: bool = True,
        quality: str = "high"
    ) -> Dict[str, Any]:
        """
        从中文描述生成提示词
        
        Args:
            description: 中文描述
            style: 风格名称（可选）
            platform: 目标平台
            include_negative: 是否包含负面提示词
            quality: 质量级别 (low/medium/high/ultra)
        
        Returns:
            包含生成结果的字典
        """
        # 中文转英文关键词
        keywords = self.keyword_converter.convert(description)
        
        # 确定风格
        if style is None:
            detected_style = self._detect_style_from_keywords(keywords)
        else:
            detected_style = style
            
        # 获取风格模板
        style_template = self.style_templates.get_template(detected_style)
        
        # 构建主提示词
        main_prompt = self._build_prompt(
            keywords=keywords,
            style_template=style_template,
            platform=platform,
            quality=quality
        )
        
        # 生成负面提示词
        negative_prompt = self.negative_manager.get_negative_prompt(
            platform=platform,
            style=detected_style
        ) if include_negative else ""
        
        # 获取参数建议
        params = self.param_optimizer.get_parameters(
            platform=platform,
            quality=quality,
            style=detected_style
        )
        
        return {
            "success": True,
            "main_prompt": main_prompt,
            "negative_prompt": negative_prompt,
            "parameters": params,
            "detected_style": detected_style,
            "keywords": keywords,
            "platform": platform
        }
    
    def generate_from_scene(
        self,
        scene: str,
        style: str = None,
        atmosphere: str = None,
        platform: str = "midjourney",
        include_negative: bool = True,
        quality: str = "high"
    ) -> Dict[str, Any]:
        """
        从预设场景生成提示词
        
        Args:
            scene: 场景名称（如"现代简约客厅"）
            style: 风格名称（可选，会覆盖场景默认风格）
            atmosphere: 氛围类型（可选）
            platform: 目标平台
            include_negative: 是否包含负面提示词
            quality: 质量级别
        
        Returns:
            包含生成结果的字典
        """
        if scene not in self.SCENE_PRESETS:
            return {
                "success": False,
                "error": f"未知场景: {scene}",
                "available_scenes": list(self.SCENE_PRESETS.keys())
            }
        
        scene_config = self.SCENE_PRESETS[scene]
        
        # 确定风格
        final_style = style or self._get_default_style_for_scene(scene)
        
        # 获取风格模板
        style_template = self.style_templates.get_template(final_style)
        
        # 构建提示词
        main_prompt = self._build_prompt(
            keywords=scene_config["elements"],
            style_template=style_template,
            platform=platform,
            quality=quality,
            scene_en=scene_config["en"],
            lighting=atmosphere or scene_config["lighting"]
        )
        
        # 生成负面提示词
        negative_prompt = self.negative_manager.get_negative_prompt(
            platform=platform,
            style=final_style
        ) if include_negative else ""
        
        # 获取参数建议
        params = self.param_optimizer.get_parameters(
            platform=platform,
            quality=quality,
            style=final_style,
            camera=scene_config.get("camera")
        )
        
        return {
            "success": True,
            "scene": scene,
            "scene_en": scene_config["en"],
            "main_prompt": main_prompt,
            "negative_prompt": negative_prompt,
            "parameters": params,
            "style": final_style,
            "atmosphere": atmosphere or scene_config["lighting"],
            "camera": scene_config.get("camera"),
            "platform": platform
        }
    
    def generate_multiple_versions(
        self,
        scene_or_description: str,
        count: int = 3,
        platform: str = "midjourney",
        style_variations: bool = True
    ) -> List[Dict[str, Any]]:
        """
        生成多个版本的提示词
        
        Args:
            scene_or_description: 场景名称或描述
            count: 生成版本数量
            platform: 目标平台
            style_variations: 是否使用不同风格变体
        
        Returns:
            提示词列表
        """
        results = []
        
        # 判断输入类型
        is_scene = scene_or_description in self.SCENE_PRESETS
        
        if style_variations:
            # 获取可用的风格列表
            available_styles = list(self.style_templates.STYLES.keys())
            selected_styles = random.sample(
                available_styles, 
                min(count, len(available_styles))
            )
            
            for style in selected_styles:
                if is_scene:
                    result = self.generate_from_scene(
                        scene=scene_or_description,
                        style=style,
                        platform=platform
                    )
                else:
                    result = self.generate_from_description(
                        description=scene_or_description,
                        style=style,
                        platform=platform
                    )
                result["variation_style"] = style
                results.append(result)
        else:
            # 使用不同的氛围变体
            atmospheres = [
                "温馨舒适", "高级奢华", "清新自然", "科技未来", "浪漫唯美",
                "神秘深邃", "活力动感", "宁静禅意"
            ]
            selected_atmospheres = random.sample(atmospheres, min(count, len(atmospheres)))
            
            for atmosphere in selected_atmospheres:
                if is_scene:
                    result = self.generate_from_scene(
                        scene=scene_or_description,
                        atmosphere=atmosphere,
                        platform=platform
                    )
                else:
                    result = self.generate_from_description(
                        description=scene_or_description,
                        platform=platform
                    )
                result["variation_atmosphere"] = atmosphere
                results.append(result)
        
        return results
    
    def get_all_scenes(self) -> Dict[str, str]:
        """获取所有可用场景"""
        return {
            scene: config["en"] 
            for scene, config in self.SCENE_PRESETS.items()
        }
    
    def get_all_styles(self) -> List[str]:
        """获取所有可用风格"""
        return list(self.style_templates.STYLES.keys())
    
    def _build_prompt(
        self,
        keywords: List[str],
        style_template: Dict,
        platform: str,
        quality: str,
        scene_en: str = None,
        lighting: str = None
    ) -> str:
        """构建最终提示词"""
        parts = []
        
        # 场景/主体
        if scene_en:
            parts.append(scene_en)
        elif keywords:
            parts.append(", ".join(keywords[:5]))
        
        # 风格
        if style_template:
            parts.append(style_template.get("prompt_keywords", ""))
        
        # 氛围/光影
        if lighting:
            parts.append(lighting)
        
        # 质量参数
        quality_tag = self.param_optimizer.get_quality_tag(platform, quality)
        if quality_tag:
            parts.append(quality_tag)
        
        # 平台特定调整
        platform_suffix = self._get_platform_suffix(platform)
        
        return ", ".join(parts) + platform_suffix
    
    def _detect_style_from_keywords(self, keywords: List[str]) -> str:
        """根据关键词检测风格"""
        keyword_text = " ".join(keywords).lower()
        
        style_indicators = {
            "现代简约": ["简约", "简洁", "现代", "极简", "minimalist", "simple", "clean"],
            "北欧风格": ["北欧", "原木", "白色", "温暖", "Nordic", "scandinavian", "light"],
            "新中式": ["中式", "禅意", "东方", "古典", "Chinese", "zen", "traditional"],
            "轻奢风格": ["轻奢", "高级", "金属", "大理石", "luxury", "elegant", "premium"],
            "工业风": ["工业", "水泥", "裸露", "metal", "concrete", "exposed"],
            "日式风格": ["日式", "榻榻米", "原木", "Japanese", "tatami", "zen"],
            "美式风格": ["美式", "温暖", "舒适", "American", "cozy", "comfortable"],
            "科技风": ["科技", "冷色", "线条", "tech", "futuristic", "modern"],
            "法式风格": ["法式", "浪漫", "优雅", "French", "romantic", "elegant"],
        }
        
        for style, indicators in style_indicators.items():
            for indicator in indicators:
                if indicator.lower() in keyword_text:
                    return style
        
        return "现代简约"  # 默认风格
    
    def _get_default_style_for_scene(self, scene: str) -> str:
        """获取场景的默认风格"""
        style_mapping = {
            "现代简约客厅": "现代简约",
            "轻奢风卧室": "轻奢风格",
            "北欧风厨房": "北欧风格",
            "日式卫生间": "日式风格",
            "新中式书房": "新中式",
            "法式衣帽间": "法式风格",
            "奶油风餐厅": "轻奢风格",
            "复古美式厨房": "美式风格",
            "网红咖啡厅": "现代简约",
            "极简办公室": "科技风",
            "高端餐厅": "轻奢风格",
            "潮流零售店": "现代简约",
            "精品酒店大堂": "轻奢风格",
            "日式禅意庭院": "日式风格",
            "现代屋顶花园": "现代简约",
            "法式庄园花园": "法式风格",
            "儿童游乐区": "现代简约",
            "现代别墅外观": "现代简约",
            "中式合院": "新中式",
            "商业写字楼": "科技风",
        }
        return style_mapping.get(scene, "现代简约")
    
    def _get_platform_suffix(self, platform: str) -> str:
        """获取平台特定后缀"""
        suffixes = {
            "midjourney": " --ar 16:9 --v 6 --style raw --q 2",
            "stable_diffusion": "",
            "dall-e": "",
            "ideogram": " --style raw --v 2",
            "flux": " --ar 16:9 --quality high"
        }
        return suffixes.get(platform, "")
    
    def export_to_file(
        self,
        result: Dict[str, Any],
        filename: str,
        format: str = "txt"
    ) -> str:
        """
        导出提示词到文件
        
        Args:
            result: 生成结果
            filename: 文件名
            format: 输出格式 (txt/json/markdown)
        
        Returns:
            导出文件路径
        """
        if format == "json":
            content = json.dumps(result, ensure_ascii=False, indent=2)
        elif format == "markdown":
            content = self._to_markdown(result)
        else:
            content = self._to_text(result)
        
        filepath = f"{filename}.{format}"
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        
        return filepath
    
    def _to_text(self, result: Dict) -> str:
        """转换为纯文本格式"""
        lines = []
        lines.append("=" * 50)
        lines.append("效果图提示词生成结果")
        lines.append("=" * 50)
        lines.append(f"\n【主提示词】\n{result.get('main_prompt', '')}")
        
        if result.get('negative_prompt'):
            lines.append(f"\n【负面提示词】\n{result.get('negative_prompt', '')}")
        
        if result.get('parameters'):
            lines.append(f"\n【参数设置】")
            for key, value in result['parameters'].items():
                lines.append(f"  {key}: {value}")
        
        lines.append(f"\n【平台】: {result.get('platform', 'midjourney')}")
        return "\n".join(lines)
    
    def _to_markdown(self, result: Dict) -> str:
        """转换为Markdown格式"""
        md = []
        md.append("# 效果图提示词生成结果\n")
        
        if result.get('scene'):
            md.append(f"**场景**: {result['scene']} ({result.get('scene_en', '')})")
        
        md.append(f"**风格**: {result.get('style', '现代简约')}")
        md.append(f"**平台**: {result.get('platform', 'midjourney')}\n")
        
        md.append("## 主提示词\n")
        md.append(f"```\n{result.get('main_prompt', '')}\n```\n")
        
        if result.get('negative_prompt'):
            md.append("## 负面提示词\n")
            md.append(f"```\n{result.get('negative_prompt', '')}\n```\n")
        
        if result.get('parameters'):
            md.append("## 参数设置\n")
            md.append("| 参数 | 值 |")
            md.append("|------|-----|")
            for key, value in result['parameters'].items():
                md.append(f"| {key} | {value} |")
        
        return "\n".join(md)


# 命令行入口
if __name__ == "__main__":
    import sys
    
    generator = PromptGenerator()
    
    if len(sys.argv) < 2:
        print("用法:")
        print("  python generator.py <描述> [风格] [平台]")
        print("\n示例:")
        print("  python generator.py '现代简约客厅，无主灯设计'")
        print("  python generator.py '网红咖啡厅' 北欧风格 midjourney")
        print("\n可用风格:", ", ".join(generator.get_all_styles()))
        sys.exit(1)
    
    description = sys.argv[1]
    style = sys.argv[2] if len(sys.argv) > 2 else None
    platform = sys.argv[3] if len(sys.argv) > 3 else "midjourney"
    
    # 判断是场景还是描述
    if description in generator.SCENE_PRESETS:
        result = generator.generate_from_scene(description, style, platform=platform)
    else:
        result = generator.generate_from_description(description, style, platform)
    
    print("\n" + "=" * 60)
    print("生成结果")
    print("=" * 60)
    print(f"\n【主提示词】\n{result['main_prompt']}")
    print(f"\n【负面提示词】\n{result.get('negative_prompt', 'N/A')}")
    print(f"\n【参数】")
    for key, value in result.get('parameters', {}).items():
        print(f"  {key}: {value}")
