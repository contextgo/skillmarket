#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风格模板库

定义和管理各种设计风格的提示词模板，包括：
- 风格描述和特点
- 关键词映射
- 适用场景
- 组合建议
"""

from typing import Dict, List, Optional, Any


class StyleTemplates:
    """风格模板管理类"""
    
    # 完整的风格定义
    STYLES: Dict[str, Dict[str, Any]] = {
        "现代简约": {
            "name_en": "Modern Minimalist",
            "description": "简洁线条、中性色调、强调功能和空间感",
            "prompt_keywords": "modern minimalist, clean lines, neutral colors, functional design",
            "visual_elements": [
                "simple geometric forms",
                "clean surfaces",
                "hidden storage",
                "integrated appliances",
                "large windows"
            ],
            "color_palette": [
                "white", "gray", "black", "beige", "soft earth tones"
            ],
            "materials": [
                "glass", "metal", "smooth concrete", "polished stone",
                "lacquered surfaces", "natural wood"
            ],
            "lighting": "hidden LED strips, recessed lighting, natural light",
            "forbidden_elements": [
                "ornate details", "excessive decoration", "cluttered spaces",
                "mismatched styles", "outdated fixtures"
            ],
            "platform_keywords": {
                "midjourney": "modern minimalist interior, clean lines, --ar 16:9",
                "stable_diffusion": "modern minimalist, simple, clean interior",
                "dall-e": "modern minimalist interior design"
            }
        },
        
        "北欧风格": {
            "name_en": "Nordic / Scandinavian",
            "description": "原木色、白色主调、温馨舒适、自然光线",
            "prompt_keywords": "Nordic style, Scandinavian design, cozy warmth, natural light",
            "visual_elements": [
                "light wood tones",
                "white walls",
                "soft textiles",
                "plants",
                "hygge atmosphere"
            ],
            "color_palette": [
                "white", "light oak", "soft pastels", "muted greens",
                "warm grays", "natural beige"
            ],
            "materials": [
                "light oak wood", "birch", "linen", "wool", "cotton",
                "leather accents", "rattan"
            ],
            "lighting": "abundant natural light, soft pendant lamps, candles",
            "forbidden_elements": [
                "dark heavy woods", "ornate patterns", "excessive ornamentation",
                "synthetic materials", "cluttered appearance"
            ],
            "platform_keywords": {
                "midjourney": "Nordic scandinavian interior, light wood, cozy --ar 16:9",
                "stable_diffusion": "Nordic style, scandinavian, light and airy",
                "dall-e": "Scandinavian interior design"
            }
        },
        
        "新中式": {
            "name_en": "New Chinese / Neo-Chinese",
            "description": "东方元素、禅意、传统与现代融合",
            "prompt_keywords": "new Chinese style, modern Chinese, oriental aesthetics, zen atmosphere",
            "visual_elements": [
                "simplified traditional patterns",
                "ink wash painting elements",
                "scholar's garden influence",
                "bamboo accents",
                "stone features"
            ],
            "color_palette": [
                "ink black", "warm white", "muted red", "jade green",
                "gold accents", "natural wood tones"
            ],
            "materials": [
                "dark walnut", "bamboo", "mutton fat jade", "brass",
                "rice paper", "clouds and waves patterns"
            ],
            "lighting": "warm ambient, paper lanterns, indirect lighting",
            "forbidden_elements": [
                "overly ornate Chinese decorations", "kitschy red and gold",
                "clashing modern elements", "excessive dragon motifs"
            ],
            "platform_keywords": {
                "midjourney": "new Chinese interior, oriental zen, modern Chinese design --ar 16:9",
                "stable_diffusion": "new Chinese style, Chinese modern, zen",
                "dall-e": "contemporary Chinese interior design"
            }
        },
        
        "轻奢风格": {
            "name_en": "Light Luxury / Modern Luxury",
            "description": "金属元素、大理石、高级感、精致细节",
            "prompt_keywords": "light luxury, modern luxury, elegant sophistication, premium materials",
            "visual_elements": [
                "metallic accents",
                "marble surfaces",
                "designer furniture",
                "subtle glamour",
                "art pieces"
            ],
            "color_palette": [
                "soft gold", "brushed brass", "white marble", "deep navy",
                "emerald green", "champagne", "cream"
            ],
            "materials": [
                "Italian marble", "brushed gold", "high-gloss lacquer",
                "velvet", "crystal", "fine leather"
            ],
            "lighting": "designer chandeliers, accent lighting, warm ambiance",
            "forbidden_elements": [
                "cheap imitations", "overly gaudy gold", "mismatched materials",
                "poor craftsmanship", "fake marble patterns"
            ],
            "platform_keywords": {
                "midjourney": "luxury interior, marble and gold, elegant design --ar 16:9",
                "stable_diffusion": "light luxury, modern luxury, elegant interior",
                "dall-e": "luxury interior design with marble and gold"
            }
        },
        
        "工业风": {
            "name_en": "Industrial Style",
            "description": "裸露结构、水泥、金属、原始质感",
            "prompt_keywords": "industrial style, raw materials, exposed structure, urban loft",
            "visual_elements": [
                "exposed brick walls",
                "concrete floors",
                "metal pipes and ducts",
                "open floor plan",
                "warehouse aesthetic"
            ],
            "color_palette": [
                "raw concrete gray", "rust brown", "matte black",
                "exposed copper", "steel gray", "warm wood"
            ],
            "materials": [
                "exposed brick", "concrete", "black steel", "iron pipes",
                "reclaimed wood", "leather"
            ],
            "lighting": " Edison bulbs, pendant lights, track lighting",
            "forbidden_elements": [
                "delicate decorations", "soft pastels", "ornate moldings",
                "excessive polish", "cluttered spaces"
            ],
            "platform_keywords": {
                "midjourney": "industrial interior, exposed brick, urban loft --ar 16:9",
                "stable_diffusion": "industrial style, raw concrete, warehouse",
                "dall-e": "industrial style interior design"
            }
        },
        
        "日式风格": {
            "name_en": "Japanese Style",
            "description": "榻榻米、原木、自然、侘寂美学",
            "prompt_keywords": "Japanese style, tatami, wabi-sabi, zen minimalism, natural materials",
            "visual_elements": [
                "tatami mats",
                "sliding shoji doors",
                "low furniture",
                "zen garden view",
                "shoin-zukuri elements"
            ],
            "color_palette": [
                "warm wood", "rice paper white", "soft beige", "moss green",
                "charcoal gray", "natural fiber"
            ],
            "materials": [
                "tatami", " hinoki cypress", "shoji paper", "bamboo",
                "natural textiles", "ceramic"
            ],
            "lighting": "soft diffused, paper lanterns, natural shadows",
            "forbidden_elements": [
                "loud colors", "Western furniture", "excessive decoration",
                "synthetic materials", "cluttered spaces"
            ],
            "platform_keywords": {
                "midjourney": "Japanese interior, tatami room, zen aesthetic --ar 16:9",
                "stable_diffusion": "Japanese style, zen, wabi-sabi, minimal",
                "dall-e": "traditional Japanese interior design"
            }
        },
        
        "美式风格": {
            "name_en": "American Classic",
            "description": "温暖舒适、大气、经典美式元素",
            "prompt_keywords": "American classic style, warm and cozy, comfortable elegance, traditional charm",
            "visual_elements": [
                "rich wood tones",
                "comfortable upholstery",
                "classic patterns",
                "layered textures",
                "family-friendly"
            ],
            "color_palette": [
                "warm wood brown", "navy blue", "hunter green", "cream",
                "burgundy", "gold accents", "soft ivory"
            ],
            "materials": [
                "solid wood", "leather", "brass", "tropical hardwood",
                "cotton", "herringbone floors"
            ],
            "lighting": "warm and inviting, table lamps, statement chandeliers",
            "forbidden_elements": [
                "cold modern aesthetics", "minimalist design",
                "harsh lighting", "plastic materials"
            ],
            "platform_keywords": {
                "midjourney": "American classic interior, warm traditional, cozy --ar 16:9",
                "stable_diffusion": "American style, classic traditional, warm interior",
                "dall-e": "traditional American home interior design"
            }
        },
        
        "科技风": {
            "name_en": "Tech / Futuristic",
            "description": "冷色调、线条感、未来科技、智能家居",
            "prompt_keywords": "tech-inspired, futuristic, smart home, cutting-edge design, digital aesthetic",
            "visual_elements": [
                "LED strips",
                "floating elements",
                "touch interfaces",
                "transparent screens",
                "geometric patterns"
            ],
            "color_palette": [
                "electric blue", "neon cyan", "matte black", "silver chrome",
                "purple accent", "white glow"
            ],
            "materials": [
                "brushed aluminum", "carbon fiber", "transparent acrylic",
                "smart glass", "LED panels", "holographic surfaces"
            ],
            "lighting": "LED strips, accent lighting, blue ambient, glow effects",
            "forbidden_elements": [
                "warm colors", "natural materials", "traditional patterns",
                "soft textures", "antique elements"
            ],
            "platform_keywords": {
                "midjourney": "futuristic interior, tech design, smart home --ar 16:9",
                "stable_diffusion": "futuristic, tech inspired, modern digital",
                "dall-e": "futuristic interior design with technology"
            }
        },
        
        "法式风格": {
            "name_en": "French Romantic",
            "description": "浪漫优雅、精致、法式生活美学",
            "prompt_keywords": "French style, romantic elegance, Parisian chic, sophisticated charm",
            "visual_elements": [
                "curved lines",
                "ornate but refined details",
                "floral patterns",
                "antique mirrors",
                "classical moldings"
            ],
            "color_palette": [
                "soft pastels", "lavender", "rose gold", "ivory", "sage green",
                "champagne gold", "powder blue"
            ],
            "materials": [
                "gilded accents", "silk", "velvet", "limestone", "wrought iron",
                "boiserie panels", "herringbone parquet"
            ],
            "lighting": "crystal chandeliers, brass sconces, romantic ambiance",
            "forbidden_elements": [
                "harsh modern lines", "overly industrial materials",
                "clashing colors", "cheap reproductions"
            ],
            "platform_keywords": {
                "midjourney": "French style interior, Parisian elegance, romantic --ar 16:9",
                "stable_diffusion": "French style, romantic elegant, Parisian chic",
                "dall-e": "French romantic interior design"
            }
        },
        
        "混搭风格": {
            "name_en": "Eclectic / Mixed Style",
            "description": "多风格融合、创意搭配、个性表达",
            "prompt_keywords": "eclectic style, mixed design, bohemian fusion, artistic expression, collected over time",
            "visual_elements": [
                "vintage and modern mix",
                "art collection display",
                "layered patterns",
                "global influences",
                "personal treasures"
            ],
            "color_palette": [
                "rich and varied", "bold accent colors", "mixed metallics",
                "vintage tones", "artisan colors"
            ],
            "materials": [
                "mixed woods", "global textiles", "vintage finds",
                "handcrafted items", "art pieces", "antiques"
            ],
            "lighting": "eclectic fixtures, vintage lamps, statement pieces",
            "forbidden_elements": [
                "perfectly matched sets", "lack of personality",
                "overly coordinated", "cluttered without purpose"
            ],
            "platform_keywords": {
                "midjourney": "eclectic interior, mixed style, bohemian chic --ar 16:9",
                "stable_diffusion": "eclectic style, mixed design, bohemian",
                "dall-e": "eclectic interior design with mixed styles"
            }
        }
    }
    
    # 氛围预设
    ATMOSPHERES: Dict[str, Dict[str, Any]] = {
        "温馨舒适": {
            "keywords": "cozy, warm, inviting, comfortable, homey",
            "lighting": "warm lighting, fireplace glow, soft ambient",
            "colors": "warm beige, soft cream, gentle amber"
        },
        "高级奢华": {
            "keywords": "luxurious, elegant, sophisticated, premium, high-end",
            "lighting": "crystal chandeliers, accent spotlights, golden glow",
            "colors": "champagne, gold accents, deep jewel tones"
        },
        "清新自然": {
            "keywords": "fresh, natural, airy, bright, organic",
            "lighting": "abundant natural light, green plant accents",
            "colors": "soft greens, natural wood, white, sky blue"
        },
        "科技未来": {
            "keywords": "futuristic, cutting-edge, smart, digital, innovative",
            "lighting": "LED strips, blue ambient, neon accents",
            "colors": "electric blue, chrome, black, cyan"
        },
        "浪漫唯美": {
            "keywords": "romantic, dreamy, soft, ethereal, poetic",
            "lighting": "soft diffused, fairy lights, candlelight ambiance",
            "colors": "blush pink, lavender, rose gold, ivory"
        },
        "神秘深邃": {
            "keywords": "mysterious, dramatic, moody, deep, sophisticated",
            "lighting": "dramatic shadows, accent lighting, dim ambient",
            "colors": "deep navy, charcoal, emerald, burgundy"
        },
        "活力动感": {
            "keywords": "vibrant, energetic, dynamic, bold, lively",
            "lighting": "bright and cheerful, accent colors",
            "colors": "bold yellow, vibrant orange, energetic red"
        },
        "宁静禅意": {
            "keywords": "tranquil, zen, peaceful, meditative, serene",
            "lighting": "soft natural, paper lanterns, zen atmosphere",
            "colors": "neutral beige, soft gray, moss green"
        },
        "白天自然光": {
            "keywords": "bright daylight, clear, crisp, natural sun",
            "lighting": "large windows, natural daylight, no artificial",
            "colors": "pure white, natural tones, blue sky view"
        },
        "黄昏日落": {
            "keywords": "golden hour, sunset warmth, amber glow, peaceful evening",
            "lighting": "warm sunset light, golden hour, amber tones",
            "colors": "warm orange, golden yellow, soft pink, purple"
        },
        "夜晚氛围": {
            "keywords": "nighttime ambiance, evening mood, city lights",
            "lighting": "twilight glow, city light reflections, moonlight",
            "colors": "deep blue, warm window glows, starry accents"
        },
        "艺术画廊": {
            "keywords": "gallery-like, museum quality, curated, artistic",
            "lighting": "spotlight on art, track lighting, dramatic",
            "colors": "white walls, neutral backdrop, artistic pops"
        }
    }
    
    def __init__(self):
        """初始化风格模板"""
        self.styles = self.STYLES
        self.atmospheres = self.ATMOSPHERES
    
    def get_template(self, style_name: str) -> Optional[Dict[str, Any]]:
        """
        获取风格模板
        
        Args:
            style_name: 风格名称
        
        Returns:
            风格模板字典
        """
        return self.styles.get(style_name)
    
    def get_all_styles(self) -> List[str]:
        """获取所有风格名称"""
        return list(self.styles.keys())
    
    def get_style_keywords(
        self, 
        style_name: str, 
        platform: str = "midjourney"
    ) -> str:
        """
        获取特定风格和平台的关键词
        
        Args:
            style_name: 风格名称
            platform: 目标平台
        
        Returns:
            风格关键词字符串
        """
        style = self.styles.get(style_name)
        if not style:
            return ""
        
        # 优先使用平台特定关键词
        if "platform_keywords" in style:
            return style["platform_keywords"].get(platform, style["prompt_keywords"])
        
        return style["prompt_keywords"]
    
    def combine_style_and_atmosphere(
        self,
        style_name: str,
        atmosphere_name: str
    ) -> Dict[str, Any]:
        """
        组合风格和氛围
        
        Args:
            style_name: 风格名称
            atmosphere_name: 氛围名称
        
        Returns:
            组合后的提示词组件
        """
        style = self.styles.get(style_name, {})
        atmosphere = self.atmospheres.get(atmosphere_name, {})
        
        return {
            "style_keywords": style.get("prompt_keywords", ""),
            "style_elements": style.get("visual_elements", []),
            "atmosphere_keywords": atmosphere.get("keywords", ""),
            "lighting": atmosphere.get("lighting", style.get("lighting", "")),
            "colors": atmosphere.get("colors", style.get("color_palette", [])),
            "materials": style.get("materials", [])
        }
    
    def get_forbidden_elements(self, style_name: str) -> List[str]:
        """
        获取风格禁忌元素
        
        Args:
            style_name: 风格名称
        
        Returns:
            禁忌元素列表（用于负面提示词）
        """
        style = self.styles.get(style_name)
        if not style:
            return []
        return style.get("forbidden_elements", [])
    
    def get_color_palette(self, style_name: str) -> List[str]:
        """
        获取风格配色方案
        
        Args:
            style_name: 风格名称
        
        Returns:
            配色列表
        """
        style = self.styles.get(style_name)
        if not style:
            return []
        return style.get("color_palette", [])
    
    def get_material_suggestions(self, style_name: str) -> List[str]:
        """
        获取风格材质建议
        
        Args:
            style_name: 风格名称
        
        Returns:
            材质建议列表
        """
        style = self.styles.get(style_name)
        if not style:
            return []
        return style.get("materials", [])
    
    def search_styles_by_keywords(self, keywords: List[str]) -> List[str]:
        """
        根据关键词搜索匹配的风格
        
        Args:
            keywords: 搜索关键词列表
        
        Returns:
            匹配的风格名称列表
        """
        matched_styles = []
        keyword_text = " ".join(keywords).lower()
        
        for style_name, style_data in self.styles.items():
            # 检查描述
            if style_data.get("description", "").lower() in keyword_text:
                matched_styles.append(style_name)
                continue
            
            # 检查关键词
            style_keywords = style_data.get("prompt_keywords", "").lower()
            if any(kw in keyword_text for kw in style_keywords.split(", ")):
                matched_styles.append(style_name)
                continue
            
            # 检查视觉元素
            visual_elements = " ".join(style_data.get("visual_elements", [])).lower()
            if any(kw in keyword_text for kw in visual_elements.split()):
                matched_styles.append(style_name)
        
        return matched_styles


# 命令行入口
if __name__ == "__main__":
    import json
    
    templates = StyleTemplates()
    
    print("=" * 60)
    print("风格模板库")
    print("=" * 60)
    
    print("\n【可用风格】")
    for style in templates.get_all_styles():
        desc = templates.styles[style].get("description", "")
        print(f"  - {style}: {desc}")
    
    print("\n【可用氛围】")
    for atmosphere in templates.atmospheres:
        keywords = templates.atmospheres[atmosphere].get("keywords", "")
        print(f"  - {atmosphere}: {keywords}")
    
    # 测试组合
    print("\n【风格组合示例】")
    combo = templates.combine_style_and_atmosphere("轻奢风格", "浪漫唯美")
    print(json.dumps(combo, indent=2, ensure_ascii=False))
