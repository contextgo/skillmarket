#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中文关键词转换器

将中文关键词转换为英文提示词关键词，支持：
- 室内设计关键词
- 建筑外观关键词
- 软装陈设关键词
- 材质面料关键词
- 灯饰照明关键词
"""

from typing import Dict, List, Optional, Set


class ChineseKeywordConverter:
    """中文关键词到英文的转换器"""
    
    # 室内设计关键词映射
    INTERIOR_KEYWORDS: Dict[str, Dict[str, str]] = {
        # 客厅空间
        "客厅": {
            "zh": "沙发区,电视墙,茶几,窗帘,地毯,落地灯,投影幕布,隐形门,收纳柜",
            "en": {
                "沙发区": "sofa area, comfortable seating, lounge zone",
                "电视墙": "TV wall, media console, entertainment center",
                "茶几": "coffee table, side tables",
                "窗帘": "drapes, curtains, window treatments",
                "地毯": "area rug, carpet, soft flooring",
                "落地灯": "floor lamp, standing lamp",
                "投影幕布": "projector screen, home theater",
                "隐形门": "hidden door, seamless wall panel",
                "收纳柜": "storage cabinet, built-in shelving"
            }
        },
        
        # 卧室空间
        "卧室": {
            "zh": "床,衣柜,梳妆台,床头柜,床品,窗帘,飘窗",
            "en": {
                "床": "bed, comfortable mattress, upholstered bed frame",
                "衣柜": "wardrobe, closet system, clothing storage",
                "梳妆台": "vanity table, dressing table, makeup vanity",
                "床头柜": "nightstand, bedside table, floating nightstands",
                "床品": "bedding, duvet, pillows, premium linens",
                "窗帘": "window treatments, blackout curtains, sheer curtains",
                "飘窗": "bay window, window seat, window bench"
            }
        },
        
        # 厨房空间
        "厨房": {
            "zh": "橱柜,台面,岛台,电器,水槽,龙头,吊灯,地砖",
            "en": {
                "橱柜": "cabinets, cabinetry, kitchen cabinets",
                "台面": "countertop, kitchen island countertop, quartz",
                "岛台": "kitchen island, island with seating, breakfast bar",
                "电器": "appliances, built-in oven, range hood",
                "水槽": "kitchen sink, farmhouse sink, undermount sink",
                "龙头": "faucet, pull-down faucet, kitchen mixer",
                "吊灯": "pendant lights, kitchen chandelier, island lighting",
                "地砖": "floor tiles, ceramic tiles, pattern floor"
            }
        },
        
        # 卫生间空间
        "卫生间": {
            "zh": "洗手台,马桶,淋浴,浴缸,浴室柜,镜柜,地砖,壁灯",
            "en": {
                "洗手台": "bathroom vanity, sink counter, washbasin",
                "马桶": "toilet, wall-mounted toilet, smart toilet",
                "淋浴": "shower, rainfall shower head, glass enclosure",
                "浴缸": "bathtub, freestanding tub, soaking tub",
                "浴室柜": "bathroom cabinet, vanity storage",
                "镜柜": "mirror cabinet, medicine cabinet, illuminated mirror",
                "地砖": "bathroom tiles, anti-slip flooring, marble tiles",
                "壁灯": "wall sconces, vanity lighting, bathroom lamps"
            }
        },
        
        # 书房空间
        "书房": {
            "zh": "书桌,书架,书椅,台灯,地毯,窗帘",
            "en": {
                "书桌": "desk, writing desk, home office desk",
                "书架": "bookshelf, bookcase, floating shelves",
                "书椅": "desk chair, ergonomic chair, office chair",
                "台灯": "desk lamp, task lighting, reading lamp",
                "地毯": "area rug, desk mat, comfort flooring",
                "窗帘": "curtains, blinds, light filtering"
            }
        }
    }
    
    # 材质面料关键词
    MATERIAL_KEYWORDS: Dict[str, str] = {
        # 实木家具
        "黑胡桃木": "black walnut, walnut wood, dark walnut",
        "白蜡木": "ash wood, white ash, light wood",
        "橡木": "oak wood, natural oak, white oak",
        "樱桃木": "cherry wood, cherry mahogany, warm wood tone",
        "柚木": "teak wood, teak, outdoor wood",
        
        # 金属家具
        "黄铜": "brass, polished brass, golden brass",
        "不锈钢": "stainless steel, brushed steel, steel",
        "铁艺": "iron, wrought iron, black iron",
        "黑色金属": "black metal, matte black metal, powder-coated steel",
        
        # 布艺面料
        "丝绒": "velvet, plush velvet, luxurious velvet",
        "亚麻": "linen, natural linen, flax linen",
        "科技布": "performance fabric, tech fabric, microfiber",
        "皮质": "leather, genuine leather, premium leather",
        
        # 石材
        "大理石": "marble, Italian marble, Carrara marble, white marble",
        "岩板": "sintered stone, large format slab, Dekton",
        "石英石": "quartz, quartz countertop, engineered quartz",
        "奢石": "luxury stone, exotic stone, natural stone",
        
        # 木材
        "原木": "natural wood, solid wood, warm wood tones",
        "木地板": "wooden floor, hardwood floor, oak flooring",
        "木饰面": "wood veneer, wood paneling, wood accent wall",
        "木纹砖": "wood-look tile, wood grain porcelain tile"
    }
    
    # 灯饰照明关键词
    LIGHTING_KEYWORDS: Dict[str, str] = {
        # 主灯
        "吊灯": "chandelier, pendant light, statement lighting",
        "吸顶灯": "ceiling light, flush mount, semi-flush mount",
        "轨道灯": "track lighting, track lights, rail lighting",
        
        # 辅助灯
        "筒灯": "recessed lights, can lights, pot lights, downlights",
        "射灯": "spotlight, accent spotlight, directional spotlight",
        "灯带": "LED strips, light strips, cove lighting, indirect lighting",
        "壁灯": "wall sconces, wall lights, bedside wall lamps",
        
        # 氛围灯
        "落地灯": "floor lamp, standing lamp, arc floor lamp",
        "台灯": "table lamp, desk lamp, bedside lamp",
        "烛光灯": "candlelight, candle ambiance, warm candlelight",
        "星星灯": "string lights, fairy lights, twinkling lights",
        
        # 特殊效果
        "无主灯": "no overhead light, hidden lighting, indirect lighting design",
        "灯槽": "light trough, valance lighting, pelmet lighting",
        "洗墙灯": "wall washing lights, grazing effect, accent wall lighting"
    }
    
    # 家具风格关键词
    FURNITURE_KEYWORDS: Dict[str, str] = {
        # 沙发类型
        "转角沙发": "corner sofa, L-shaped sofa, sectional sofa",
        "模块沙发": "modular sofa, sectional couch, configurable sofa",
        "一字沙发": "straight sofa, sofa bed, Loveseat",
        "功能沙发": "power sofa, reclining sofa, massage sofa",
        
        # 床类型
        "悬浮床": "floating bed, platform bed, bed with hidden base",
        "地台床": "platform bed, Japanese style floor bed, tatami bed",
        "皮质床": "upholstered bed, leather bed, tufted headboard bed",
        "铁艺床": "metal bed frame, iron bed, vintage metal bed",
        
        # 桌椅类型
        "餐桌": "dining table, formal dining table, extendable dining table",
        "书桌": "desk, home office desk, standing desk",
        "茶几": "coffee table, side table, nesting tables",
        "餐椅": "dining chair, upholstered dining chair, wishbone chair"
    }
    
    # 装饰摆件关键词
    DECOR_KEYWORDS: Dict[str, str] = {
        # 挂画
        "装饰画": "decorative painting, artwork, canvas art",
        "挂毯": "wall tapestry, textile art, macrame wall hanging",
        "照片墙": "photo wall, gallery wall, picture ledge",
        "镜子": "decorative mirror, statement mirror, arched mirror",
        
        # 绿植
        "大型绿植": "large indoor plants, floor plants, statement plants",
        "多肉": "succulents, cactus, small potted plants",
        "鲜花": "fresh flowers, floral arrangement, vase with flowers",
        "干花": "dried flowers, preserved flowers, dried arrangement",
        
        # 收藏摆件
        "雕塑": "sculpture, art piece, decorative figurine",
        "摆件": "decorative objects, collectibles, accent pieces",
        "书籍": "books, book collection, literary decor",
        "乐器": "musical instrument, guitar display, piano"
    }
    
    # 建筑外观关键词
    EXTERIOR_KEYWORDS: Dict[str, str] = {
        # 屋顶系统
        "露台花园": "rooftop garden, terrace garden, outdoor terrace",
        "阳光房": "sunroom, conservatory, glass enclosure",
        "平屋顶": "flat roof, roof terrace, modern flat roof",
        "坡屋顶": "sloped roof, pitched roof, gable roof",
        
        # 立面材质
        "玻璃幕墙": "glass curtain wall, curtain wall system",
        "石材幕墙": "stone facade, stone cladding, natural stone wall",
        "金属幕墙": "metal panel facade, aluminum composite panel",
        "真石漆": "real stone paint, textured coating, stucco",
        
        # 门窗
        "落地窗": "floor-to-ceiling windows, full-height windows",
        "系统窗": "curtain wall windows, thermally broken windows",
        "窄边框": "narrow frame windows, minimal framing, slim profile",
        "中式门窗": "Chinese style windows, traditional window patterns",
        
        # 景观元素
        "泳池": "swimming pool, infinity pool, outdoor pool",
        "喷泉": "fountain, water feature, decorative fountain",
        "乔木": "trees, shade trees, ornamental trees",
        "草坪": "lawn, grass area, green lawn"
    }
    
    def __init__(self):
        """初始化转换器"""
        self._build_complete_mapping()
    
    def _build_complete_mapping(self):
        """构建完整的关键词映射表"""
        self.complete_mapping: Dict[str, str] = {}
        
        # 合并所有分类的关键词
        mappings = [
            self.MATERIAL_KEYWORDS,
            self.LIGHTING_KEYWORDS,
            self.FURNITURE_KEYWORDS,
            self.DECOR_KEYWORDS,
            self.EXTERIOR_KEYWORDS
        ]
        
        for mapping in mappings:
            self.complete_mapping.update(mapping)
        
        # 添加固定的词组转换
        self.phrase_mapping: Dict[str, str] = {
            "开阔明亮": "spacious and bright, open concept, airy",
            "无主灯设计": "hidden lighting design, no overhead lights, indirect lighting",
            "木地板": "wooden flooring, hardwood floor, oak plank floor",
            "高级感": "high-end feel, premium look, sophisticated",
            "金属元素": "metal accents, metallic details, hardware accents",
            "皮质软装": "leather upholstery, leather accents, premium fabrics",
            "开放式": "open concept, open plan, open layout",
            "白色橱柜": "white cabinets, white cabinetry, clean white kitchen",
            "干湿分离": "dry-wet separation, separated wet and dry areas",
            "智能马桶": "smart toilet, bidet toilet, electronic toilet",
            "书架墙": "bookshelf wall, floor-to-ceiling bookshelf, library wall",
            "禅意摆件": "zen decor, meditation objects, zen accessories",
            "拱形门": "arched doorway, arch door, curved arch entrance",
            "水晶灯": "crystal chandelier, crystal light fixture",
            "绿植点缀": "green plant accents, potted plants, botanical touches",
            "落地窗": "floor-to-ceiling windows, full-height windows",
            "艺术装置": "art installation, sculptural piece, artistic display",
            "枯山水": "karesansui, Japanese rock garden, zen garden",
            "对称设计": "symmetrical design, balanced layout, formal symmetry",
            "玻璃幕墙": "glass curtain wall, glass facade, curtain wall"
        }
    
    def convert(self, text: str) -> List[str]:
        """
        将中文描述转换为英文关键词列表
        
        Args:
            text: 中文描述文本
        
        Returns:
            英文关键词列表
        """
        keywords = []
        text_lower = text.lower()
        
        # 检查固定词组
        for cn_phrase, en_phrase in self.phrase_mapping.items():
            if cn_phrase.lower() in text_lower:
                keywords.append(en_phrase)
        
        # 检查单词映射
        for cn_word, en_word in self.complete_mapping.items():
            if cn_word.lower() in text_lower:
                # 避免重复添加
                if en_word not in keywords:
                    keywords.append(en_word)
        
        # 清理和去重
        keywords = self._clean_keywords(keywords)
        
        return keywords
    
    def convert_to_prompt(self, text: str, style_keywords: str = None) -> str:
        """
        将中文描述转换为完整的提示词
        
        Args:
            text: 中文描述
            style_keywords: 额外的风格关键词
        
        Returns:
            完整的英文提示词
        """
        keywords = self.convert(text)
        
        prompt_parts = []
        if keywords:
            prompt_parts.extend(keywords)
        
        if style_keywords:
            prompt_parts.append(style_keywords)
        
        return ", ".join(prompt_parts)
    
    def _clean_keywords(self, keywords: List[str]) -> List[str]:
        """清理关键词列表"""
        cleaned = []
        seen = set()
        
        for kw in keywords:
            # 跳过空字符串
            kw = kw.strip()
            if not kw:
                continue
            
            # 标准化小写
            kw_lower = kw.lower()
            
            # 避免完全重复
            if kw_lower not in seen:
                seen.add(kw_lower)
                cleaned.append(kw)
        
        return cleaned
    
    def add_custom_mapping(self, cn_word: str, en_word: str):
        """
        添加自定义关键词映射
        
        Args:
            cn_word: 中文关键词
            en_word: 英文关键词
        """
        self.complete_mapping[cn_word] = en_word
    
    def add_phrase_mapping(self, cn_phrase: str, en_phrase: str):
        """
        添加自定义词组映射
        
        Args:
            cn_phrase: 中文词组
            en_phrase: 英文词组
        """
        self.phrase_mapping[cn_phrase] = en_phrase
    
    def get_category_keywords(self, category: str) -> Dict[str, str]:
        """
        获取特定类别的关键词
        
        Args:
            category: 类别名称 (interior/material/lighting/furniture/decor/exterior)
        
        Returns:
            该类别的关键词字典
        """
        categories = {
            "interior": self.INTERIOR_KEYWORDS,
            "material": self.MATERIAL_KEYWORDS,
            "lighting": self.LIGHTING_KEYWORDS,
            "furniture": self.FURNITURE_KEYWORDS,
            "decor": self.DECOR_KEYWORDS,
            "exterior": self.EXTERIOR_KEYWORDS
        }
        return categories.get(category, {})
    
    def batch_convert(self, texts: List[str]) -> List[List[str]]:
        """
        批量转换中文描述
        
        Args:
            texts: 中文描述列表
        
        Returns:
            英文关键词列表的列表
        """
        return [self.convert(text) for text in texts]


# 命令行入口
if __name__ == "__main__":
    converter = ChineseKeywordConverter()
    
    print("=" * 60)
    print("中文关键词转换器")
    print("=" * 60)
    
    # 测试用例
    test_cases = [
        "现代简约客厅，无主灯设计，木地板",
        "轻奢风卧室，皮质软装，金属元素",
        "开放式厨房，白色橱柜，石英石台面",
        "日式禅意庭院，枯山水，石灯笼"
    ]
    
    print("\n【转换测试】")
    for text in test_cases:
        result = converter.convert(text)
        print(f"\n输入: {text}")
        print(f"输出: {', '.join(result) if result else '(未识别到关键词)'}")
    
    print("\n【类别关键词】")
    print("\n材质关键词示例:")
    for k, v in list(converter.MATERIAL_KEYWORDS.items())[:5]:
        print(f"  {k} -> {v}")
    
    print("\n灯饰关键词示例:")
    for k, v in list(converter.LIGHTING_KEYWORDS.items())[:5]:
        print(f"  {k} -> {v}")
