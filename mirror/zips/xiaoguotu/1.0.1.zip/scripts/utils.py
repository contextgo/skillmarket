#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工具函数模块

提供通用工具函数，包括：
- 文本处理
- 格式转换
- 提示词优化
- 文件操作
"""

import re
import json
import hashlib
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime


def clean_prompt(prompt: str) -> str:
    """
    清理提示词文本
    
    Args:
        prompt: 原始提示词
    
    Returns:
        清理后的提示词
    """
    # 移除多余空格
    prompt = re.sub(r'\s+', ' ', prompt)
    
    # 移除特殊字符（保留逗号、括号）
    prompt = re.sub(r'[^\w\s,\-\(\)\[\]:\.\+\/]', '', prompt)
    
    # 清理首尾空白和逗号
    prompt = prompt.strip(',').strip()
    
    return prompt


def split_prompt(prompt: str, delimiter: str = ',') -> List[str]:
    """
    分割提示词为列表
    
    Args:
        prompt: 提示词文本
        delimiter: 分隔符
    
    Returns:
        分割后的列表
    """
    parts = prompt.split(delimiter)
    return [part.strip() for part in parts if part.strip()]


def merge_prompts(*prompts: str, separator: str = ', ') -> str:
    """
    合并多个提示词
    
    Args:
        prompts: 要合并的提示词
        separator: 连接符
    
    Returns:
        合并后的提示词
    """
    parts = []
    for prompt in prompts:
        if prompt:
            parts.extend(split_prompt(prompt))
    
    return separator.join(parts)


def add_weight(prompt: str, keyword: str, weight: float = 1.0) -> str:
    """
    为关键词添加权重
    
    Args:
        prompt: 原始提示词
        keyword: 要加权的关键词
        weight: 权重值 (0.1-1.5)
    
    Returns:
        加权后的提示词
    """
    if weight == 1.0:
        return prompt
    
    # Midjourney权重格式
    if weight > 1.0:
        return prompt.replace(keyword, f"({keyword}:{weight})")
    else:
        return prompt.replace(keyword, f"({keyword})")


def remove_duplicates(prompt: str) -> str:
    """
    移除提示词中的重复关键词
    
    Args:
        prompt: 原始提示词
    
    Returns:
        去重后的提示词
    """
    parts = split_prompt(prompt)
    seen = set()
    unique_parts = []
    
    for part in parts:
        part_lower = part.lower()
        if part_lower not in seen:
            seen.add(part_lower)
            unique_parts.append(part)
    
    return ', '.join(unique_parts)


def optimize_keyword_order(prompt: str, priority_keywords: List[str] = None) -> str:
    """
    优化关键词顺序（重要关键词放前面）
    
    Args:
        prompt: 原始提示词
        priority_keywords: 优先关键词列表
    
    Returns:
        优化后的提示词
    """
    parts = split_prompt(prompt)
    
    if not priority_keywords:
        return ', '.join(parts)
    
    priority_lower = [kw.lower() for kw in priority_keywords]
    
    priority_parts = []
    other_parts = []
    
    for part in parts:
        if any(p in part.lower() for p in priority_lower):
            priority_parts.append(part)
        else:
            other_parts.append(part)
    
    return ', '.join(priority_parts + other_parts)


def extract_keywords(prompt: str) -> List[str]:
    """
    从提示词中提取关键词
    
    Args:
        prompt: 提示词文本
    
    Returns:
        关键词列表
    """
    # 移除参数部分
    prompt = re.sub(r'--\w+\s*\d*', '', prompt)
    prompt = re.sub(r'--\w+', '', prompt)
    
    return split_prompt(prompt)


def format_for_platform(
    prompt: str,
    platform: str,
    include_params: bool = True
) -> str:
    """
    格式化为特定平台格式
    
    Args:
        prompt: 提示词
        platform: 目标平台
        include_params: 是否包含参数
    
    Returns:
        格式化后的提示词
    """
    prompt = clean_prompt(prompt)
    
    if platform == "midjourney" and include_params:
        # 确保有必要的参数
        if "--ar" not in prompt and "--v" not in prompt:
            prompt += " --ar 16:9 --v 6"
    
    return prompt


def generate_prompt_hash(prompt: str) -> str:
    """
    生成提示词的哈希值
    
    Args:
        prompt: 提示词
    
    Returns:
        MD5哈希值
    """
    return hashlib.md5(prompt.encode('utf-8')).hexdigest()


def validate_prompt(prompt: str) -> Tuple[bool, List[str]]:
    """
    验证提示词的有效性
    
    Args:
        prompt: 提示词
    
    Returns:
        (是否有效, 错误信息列表)
    """
    errors = []
    
    # 检查长度
    if len(prompt) < 5:
        errors.append("提示词太短")
    elif len(prompt) > 4000:
        errors.append("提示词太长（超过4000字符）")
    
    # 检查是否为空
    if not prompt.strip():
        errors.append("提示词为空")
    
    # 检查中英文混合
    has_chinese = bool(re.search(r'[\u4e00-\u9fff]', prompt))
    if has_chinese:
        errors.append("提示词包含中文（建议转换为英文）")
    
    # 检查特殊字符
    if re.search(r'[<>{}]', prompt):
        errors.append("包含可能引起问题的特殊字符")
    
    return len(errors) == 0, errors


def create_prompt_variations(
    prompt: str,
    count: int = 3,
    preserve_core: bool = True
) -> List[str]:
    """
    创建提示词变体
    
    Args:
        prompt: 原始提示词
        count: 变体数量
        preserve_core: 是否保留核心关键词
    
    Returns:
        变体列表
    """
    parts = split_prompt(prompt)
    
    if not parts:
        return [prompt]
    
    variations = [prompt]  # 原始
    
    # 同义词替换规则
    synonyms = {
        "modern": ["contemporary", "sleek", "stylish"],
        "luxury": ["premium", "high-end", "elegant"],
        "cozy": ["comfortable", "warm", "inviting"],
        "bright": ["light-filled", "airy", "sunny"],
        "minimalist": ["simple", "clean", "uncluttered"]
    }
    
    for i in range(count - 1):
        new_parts = list(parts)
        
        # 随机替换一些词
        for j, part in enumerate(new_parts):
            part_lower = part.lower()
            for word, syns in synonyms.items():
                if word in part_lower:
                    # 随机选择一个同义词
                    import random
                    new_word = random.choice(syns)
                    new_parts[j] = re.sub(
                        rf'\b{word}\b',
                        new_word,
                        new_parts[j],
                        flags=re.IGNORECASE
                    )
                    break
        
        variations.append(', '.join(new_parts))
    
    return variations[:count]


def export_prompts(
    prompts: List[Dict[str, Any]],
    format: str = "json"
) -> str:
    """
    导出提示词
    
    Args:
        prompts: 提示词列表
        format: 导出格式 (json/markdown/text)
    
    Returns:
        导出内容
    """
    if format == "json":
        return json.dumps(prompts, ensure_ascii=False, indent=2)
    
    elif format == "markdown":
        lines = ["# 提示词导出", ""]
        lines.append(f"导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"总数: {len(prompts)}", "")
        lines.append("---", "")
        
        for i, p in enumerate(prompts, 1):
            lines.append(f"\n## 提示词 {i}")
            lines.append(f"\n**平台**: {p.get('platform', 'N/A')}")
            lines.append(f"\n**主提示词**:\n```\n{p.get('main_prompt', '')}\n```")
            
            if p.get('negative_prompt'):
                lines.append(f"\n**负面提示词**:\n```\n{p.get('negative_prompt', '')}\n```")
            
            if p.get('parameters'):
                lines.append("\n**参数**:")
                for key, value in p['parameters'].items():
                    lines.append(f"- {key}: {value}")
        
        return "\n".join(lines)
    
    else:
        lines = ["提示词导出", "=" * 50, ""]
        for i, p in enumerate(prompts, 1):
            lines.append(f"[{i}] {p.get('main_prompt', '')}")
            if i < len(prompts):
                lines.append("")
        return "\n".join(lines)


def import_prompts(content: str, format: str = "json") -> List[Dict[str, Any]]:
    """
    导入提示词
    
    Args:
        content: 导入内容
        format: 内容格式 (json/markdown/text)
    
    Returns:
        提示词列表
    """
    prompts = []
    
    if format == "json":
        try:
            prompts = json.loads(content)
        except json.JSONDecodeError:
            pass
    
    elif format == "text":
        # 简单按行分割
        for line in content.split('\n'):
            line = line.strip()
            if line and not line.startswith('#'):
                prompts.append({"main_prompt": line})
    
    return prompts


def calculate_prompt_stats(prompt: str) -> Dict[str, Any]:
    """
    计算提示词统计信息
    
    Args:
        prompt: 提示词
    
    Returns:
        统计信息字典
    """
    keywords = extract_keywords(prompt)
    
    return {
        "total_length": len(prompt),
        "keyword_count": len(keywords),
        "has_chinese": bool(re.search(r'[\u4e00-\u9fff]', prompt)),
        "has_parameters": bool(re.search(r'--\w+', prompt)),
        "word_count": len(prompt.split()),
        "hash": generate_prompt_hash(prompt)
    }


# 命令行入口
if __name__ == "__main__":
    # 测试工具函数
    test_prompt = "modern minimalist living room, clean lines, neutral colors, large windows, wooden floor, cozy sofa, floor-to-ceiling windows"
    
    print("=" * 60)
    print("工具函数测试")
    print("=" * 60)
    
    print(f"\n原始提示词:\n{test_prompt}")
    
    print(f"\n清理后:\n{clean_prompt(test_prompt + '  ,  test')}")
    
    print(f"\n提取关键词:\n{extract_keywords(test_prompt)}")
    
    print(f"\n统计信息:")
    stats = calculate_prompt_stats(test_prompt)
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print(f"\n创建变体:")
    variations = create_prompt_variations(test_prompt, count=3)
    for i, v in enumerate(variations):
        print(f"  [{i+1}] {v}")
    
    print(f"\n验证提示词:")
    valid, errors = validate_prompt(test_prompt)
    print(f"  有效: {valid}")
    if errors:
        print(f"  错误: {errors}")
