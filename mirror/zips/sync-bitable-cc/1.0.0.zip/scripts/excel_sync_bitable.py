#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
import subprocess
from datetime import datetime
import json

def infer_field_type(series):
    """自动推断字段类型"""
    # 检查是否全为空值
    if series.dropna().empty:
        return 'text'  # 空值列默认为文本类型
    
    dtype = str(series.dtype)
    if 'int' in dtype or 'float' in dtype:
        # 检查是否实际为空值列（dtype为float64但全为NaN）
        if series.isna().all():
            return 'text'
        return 'number'
    elif 'datetime' in dtype:
        return 'datetime'
    else:
        # 尝试判断是否为日期字符串
        try:
            pd.to_datetime(series.dropna().head())
            return 'datetime'
        except:
            return 'text'

def convert_excel_to_csv(excel_path, output_csv_path):
    """将Excel转换为符合aily-base要求的CSV格式"""
    # 检查文件是否存在
    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"❌ 文件不存在: {excel_path}")
    
    # 读取Excel
    try:
        df = pd.read_excel(excel_path)
    except Exception as e:
        raise Exception(f"❌ 读取Excel文件失败: {str(e)}")
    
    # 推断每个字段的类型
    field_types = {}
    for col in df.columns:
        field_types[col] = infer_field_type(df[col])
    
    # 处理日期格式
    for col, typ in field_types.items():
        if typ == 'datetime':
            df[col] = pd.to_datetime(df[col]).dt.strftime('%Y-%m-%dT%H:%M:%S+08:00')
    
    # 生成带类型的表头
    new_columns = [f"{col}:{field_types[col]}" for col in df.columns]
    df.columns = new_columns
    
    # 保存为CSV
    df.to_csv(output_csv_path, index=False, encoding='utf-8')
    print(f"✅ 已生成CSV文件: {output_csv_path}")
    print(f"📋 字段类型推断结果: {field_types}")
    return field_types

def create_new_bitable(csv_path, app_name, table_name):
    """创建新的多维表格"""
    cmd = [
        'aily-base', 'create',
        '--csv',
        '--from', csv_path,
        '--app-name', app_name,
        '--table-name', table_name
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print("✅ 新多维表格创建成功！")
        print(result.stdout)
    else:
        print("❌ 创建失败:")
        print(result.stderr)
        sys.exit(1)

def sync_to_existing_bitable(csv_path, base_url, table_name, key_field, create_missing=True):
    """同步到现有多维表格"""
    cmd = [
        'aily-base', 'sync',
        '--csv',
        '--from', csv_path,
        '--url', base_url,
        '--table-name', table_name,
        '--key', key_field
    ]
    if create_missing:
        cmd.append('--create-missing')
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print("✅ 数据同步成功！")
        print(result.stdout)
    else:
        print("❌ 同步失败:")
        print(result.stderr)
        sys.exit(1)

def export_from_bitable(base_url, table_names, output_path, no_record_id=False):
    """从多维表格导出数据"""
    cmd = [
        'aily-base', 'export',
        '--url', base_url,
        '--output', output_path
    ]
    
    # 添加表名（支持多个）
    for table_name in table_names:
        cmd.extend(['--table-name', table_name])
    
    if no_record_id:
        cmd.append('--no-record-id')
    
    print(f"📤 正在导出多维表格数据...")
    print(f"📋 表名: {', '.join(table_names)}")
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode == 0:
        # 从stdout获取完整的JSON数据
        if result.stdout and result.stdout.strip().startswith('{'):
            try:
                data = json.loads(result.stdout)
                print("✅ 数据导出成功！")
                return data
            except json.JSONDecodeError:
                pass
        
        # 如果stdout为空，从文件读取
        if os.path.exists(output_path):
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                print("✅ 数据导出成功！")
                return data
            except json.JSONDecodeError as e:
                print(f"❌ 解析文件JSON失败: {str(e)}")
                sys.exit(1)
        
        print("❌ 无法获取导出数据")
        sys.exit(1)
    else:
        print("❌ 导出失败:")
        print(result.stderr)
        sys.exit(1)

def parse_exported_json(data):
    """解析导出的JSON数据，返回DataFrame列表"""
    try:
        dfs = []
        for table in data.get('tables', []):
            table_name = table['meta']['tableName']
            
            # rows数据在table['rows']中，不在meta里
            rows = table.get('rows', [])
            
            if not rows:
                print(f"⚠️ 表 [{table_name}] 没有数据")
                continue
            
            # 将行数据转换为DataFrame
            df = pd.DataFrame(rows)
            
            # 删除_record_id列（如果存在）
            if '_record_id' in df.columns:
                df = df.drop(columns=['_record_id'])
            
            dfs.append({
                'name': table_name,
                'data': df
            })
        
        return dfs
    except Exception as e:
        print(f"❌ 解析JSON失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return []

def save_as_csv(dfs, output_path):
    """将DataFrame保存为CSV"""
    if len(dfs) == 0:
        print("❌ 没有数据可保存")
        return False
    
    # 如果只有一个表，直接保存
    if len(dfs) == 1:
        dfs[0]['data'].to_csv(output_path, index=False, encoding='utf-8')
        print(f"✅ 已保存为CSV: {output_path}")
        print(f"📊 数据行数: {len(dfs[0]['data'])}")
        print(f"📋 字段数量: {len(dfs[0]['data'].columns)}")
        return True
    
    # 如果有多个表，分别保存
    for i, df_info in enumerate(dfs):
        table_path = output_path.replace('.csv', f'_{df_info["name"]}.csv')
        df_info['data'].to_csv(table_path, index=False, encoding='utf-8')
        print(f"✅ 已保存表 [{df_info['name']}] 为CSV: {table_path}")
        print(f"   数据行数: {len(df_info['data'])}")
    
    return True

def save_as_excel(dfs, output_path, sheet_name=None):
    """将DataFrame保存为Excel"""
    if len(dfs) == 0:
        print("❌ 没有数据可保存")
        return False
    
    try:
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            for i, df_info in enumerate(dfs):
                # 如果只有一个表且有指定sheet名称，使用指定的；否则用表名
                sheet = sheet_name if (len(dfs) == 1 and sheet_name) else df_info['name']
                # Excel sheet名称最长31个字符
                sheet = sheet[:31]
                df_info['data'].to_excel(writer, sheet_name=sheet, index=False)
        
        print(f"✅ 已保存为Excel: {output_path}")
        if len(dfs) == 1:
            print(f"📊 数据行数: {len(dfs[0]['data'])}")
            print(f"📋 字段数量: {len(dfs[0]['data'].columns)}")
        else:
            print(f"📊 包含 {len(dfs)} 个工作表:")
            for df_info in dfs:
                print(f"   - {df_info['name']}: {len(df_info['data'])} 行")
        
        return True
    except Exception as e:
        print(f"❌ 保存Excel失败: {str(e)}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='Excel与飞书多维表格互转工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 导入：创建新表
  python excel_to_bitable.py --input data.xlsx --mode create --app-name "员工表" --table-name "员工列表"
  
  # 导入：同步到现有表
  python excel_to_bitable.py --input data.xlsx --mode sync --url "https://xxx.feishu.cn/base/xxx" --table-name "员工列表" --key "员工编号"
  
  # 导出：导出为CSV
  python excel_to_bitable.py --mode export --url "https://xxx.feishu.cn/base/xxx" --table-name "员工列表" --output employees.csv
  
  # 导出：导出为Excel
  python excel_to_bitable.py --mode export --url "https://xxx.feishu.cn/base/xxx" --table-name "员工列表" --output employees.xlsx --format excel
  
  # 导出：导出多个表
  python excel_to_bitable.py --mode export --url "https://xxx.feishu.cn/base/xxx" --table-name "表1" "表2" --output data.xlsx --format excel
        """
    )
    
    # 模式选择
    parser.add_argument('--mode', choices=['create', 'sync', 'export'], required=True, 
                        help='操作模式：create=创建新表，sync=同步到现有表，export=导出数据')
    
    # 导入相关参数
    parser.add_argument('--input', help='输入Excel/CSV文件路径（create/sync模式）')
    parser.add_argument('--app-name', help='新表的应用名称（create模式必填）')
    parser.add_argument('--key', help='主键字段名（sync模式必填）')
    parser.add_argument('--no-create-missing', action='store_true', help='同步时不自动插入新行')
    
    # 通用参数
    parser.add_argument('--table-name', nargs='+', help='数据表名称（export模式支持多个）')
    parser.add_argument('--url', help='目标多维表格URL（sync/export模式）')
    
    # 导出相关参数
    parser.add_argument('--output', help='输出文件路径（export模式必填）')
    parser.add_argument('--format', choices=['csv', 'excel'], default='csv', help='导出格式：csv或excel（默认csv）')
    parser.add_argument('--no-record-id', action='store_true', help='导出时不包含_record_id字段')
    parser.add_argument('--sheet-name', help='Excel工作表名称（仅format=excel时有效）')
    
    args = parser.parse_args()
    
    # 参数校验
    if args.mode in ['create', 'sync'] and not args.input:
        print("❌ create/sync模式必须提供--input参数")
        sys.exit(1)
    
    if args.mode == 'create' and not args.app_name:
        print("❌ create模式必须提供--app-name参数")
        sys.exit(1)
    
    if args.mode == 'sync' and (not args.url or not args.key):
        print("❌ sync模式必须提供--url和--key参数")
        sys.exit(1)
    
    if args.mode == 'export' and (not args.url or not args.table_name or not args.output):
        print("❌ export模式必须提供--url、--table-name和--output参数")
        sys.exit(1)
    
    # 执行操作
    if args.mode == 'create':
        # 创建新表
        temp_csv = f"/tmp/excel_to_bitable_{int(datetime.now().timestamp())}.csv"
        try:
            convert_excel_to_csv(args.input, temp_csv)
            create_new_bitable(temp_csv, args.app_name, args.table_name[0] if isinstance(args.table_name, list) else args.table_name)
        except FileNotFoundError as e:
            print(str(e))
            sys.exit(1)
        except Exception as e:
            print(f"❌ 创建多维表格失败: {str(e)}")
            sys.exit(1)
        finally:
            if os.path.exists(temp_csv):
                os.remove(temp_csv)
    
    elif args.mode == 'sync':
        # 同步到现有表
        temp_csv = f"/tmp/excel_to_bitable_{int(datetime.now().timestamp())}.csv"
        try:
            convert_excel_to_csv(args.input, temp_csv)
            sync_to_existing_bitable(
                temp_csv, 
                args.url, 
                args.table_name[0] if isinstance(args.table_name, list) else args.table_name, 
                args.key, 
                not args.no_create_missing
            )
        except FileNotFoundError as e:
            print(str(e))
            sys.exit(1)
        except Exception as e:
            print(f"❌ 同步数据失败: {str(e)}")
            sys.exit(1)
        finally:
            if os.path.exists(temp_csv):
                os.remove(temp_csv)
    
    elif args.mode == 'export':
        # 导出数据
        # 1. 导出并获取JSON数据
        data = export_from_bitable(args.url, args.table_name, args.output, args.no_record_id)
        
        # 2. 解析JSON
        dfs = parse_exported_json(data)
        
        if not dfs:
            print("❌ 没有解析到数据")
            sys.exit(1)
        
        # 3. 根据格式保存
        if args.format == 'excel':
            success = save_as_excel(dfs, args.output, args.sheet_name)
        else:
            success = save_as_csv(dfs, args.output)
        
        if not success:
            sys.exit(1)

if __name__ == "__main__":
    main()
