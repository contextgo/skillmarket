#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
爷爷吃过的咸盐 - Word报告生成器
生成完整的祖辈智慧提炼报告
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from datetime import datetime

class GrandpaWisdomReport:
    def __init__(self, grandpa_info):
        self.doc = Document()
        self.info = grandpa_info
        self.setup_styles()
    
    def setup_styles(self):
        """设置文档样式"""
        self.doc.styles['Normal'].font.name = 'Microsoft YaHei'
        self.doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        self.doc.styles['Normal'].font.size = Pt(11)
    
    def add_title(self, text, level=1):
        """添加标题"""
        p = self.doc.add_paragraph()
        if level == 1:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(text)
            run.font.size = Pt(20)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 51, 102)
        elif level == 2:
            run = p.add_run(text)
            run.font.size = Pt(14)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 102, 153)
        else:
            run = p.add_run(text)
            run.font.size = Pt(12)
            run.font.bold = True
        
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        return p
    
    def add_paragraph(self, text, bold=False, italic=False):
        """添加段落"""
        p = self.doc.add_paragraph()
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run.bold = bold
        run.italic = italic
        return p
    
    def add_quote(self, text):
        """添加引用"""
        self.doc.add_paragraph()
        p = self.doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3)
        p.paragraph_format.right_indent = Inches(0.3)
        run = p.add_run(f'"{text}"')
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run.italic = True
        run.font.color.rgb = RGBColor(80, 80, 80)
        self.doc.add_paragraph()
    
    def add_highlight(self, text):
        """添加高亮"""
        p = self.doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.2)
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run.bold = True
        run.font.color.rgb = RGBColor(0, 102, 153)
        return p
    
    def generate(self):
        """生成完整报告"""
        # 封面
        self.add_title("爷爷吃过的咸盐", level=1)
        
        grandpa_name = self.info.get("name", "祖辈")
        self.add_title(f"{grandpa_name}的人生智慧", level=2)
        self.doc.add_paragraph()
        
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"生成日期：{datetime.now().strftime('%Y年%m月%d日')}")
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(150, 150, 150)
        
        self.doc.add_page_break()
        
        # 引言
        self.add_quote("爷爷吃过的盐比你吃的饭都多")
        self.add_paragraph("这不是一句老话，而是一种智慧传承的方式。从祖辈的一生中，提炼思考、经验、态度、意义等多个维度的得与失，为孙辈现在的工作生活带来借鉴和参考价值。")
        
        # 第一部分：祖辈画像
        self.add_title("第一部分：祖辈画像", level=2)
        
        self.add_title("基本信息", level=3)
        basic_info = self.info.get("basic", {})
        for key, value in basic_info.items():
            self.add_paragraph(f"{key}：{value}")
        
        self.add_title("多面人生", level=3)
        self.add_paragraph("祖辈的人生是多面的：")
        aspects = self.info.get("aspects", [])
        for aspect in aspects:
            self.add_paragraph(f"• {aspect}")
        
        self.add_title("时代背景", level=3)
        self.add_paragraph("祖辈生活在20世纪，经历了战争与和平、贫穷与变革、传统与现代。这些经历塑造了他们独特的智慧和人生态度。")
        
        self.doc.add_page_break()
        
        # 第二部分：四大维度提炼
        self.add_title("第二部分：四大维度提炼", level=2)
        
        # 维度一：思考方式
        self.add_title("维度一：思考方式", level=3)
        
        thinking = self.info.get("thinking", {})
        for key, content in thinking.items():
            self.add_highlight(f"{key}：")
            self.add_paragraph(content.get("description", ""))
            self.add_paragraph(f"现代启示：{content.get('insight', '')}", italic=True)
            self.doc.add_paragraph()
        
        # 维度二：经验教训
        self.add_title("维度二：经验教训", level=3)
        
        lessons = self.info.get("lessons", {})
        for key, content in lessons.items():
            self.add_highlight(f"{key}：")
            self.add_paragraph(content.get("description", ""))
            self.add_paragraph(f"经验提炼：{content.get('insight', '')}", italic=True)
            self.doc.add_paragraph()
        
        # 维度三：人生态度
        self.add_title("维度三：人生态度", level=3)
        
        attitude = self.info.get("attitude", {})
        for key, content in attitude.items():
            self.add_highlight(f"{key}：")
            self.add_paragraph(content.get("description", ""))
            self.add_paragraph(f"态度提炼：{content.get('insight', '')}", italic=True)
            self.doc.add_paragraph()
        
        # 维度四：人生意义
        self.add_title("维度四：人生意义", level=3)
        
        meaning = self.info.get("meaning", {})
        for key, content in meaning.items():
            self.add_highlight(f"{key}：")
            self.add_paragraph(content.get("description", ""))
            self.add_paragraph(f"意义评估：{content.get('insight', '')}", italic=True)
            self.doc.add_paragraph()
        
        self.doc.add_page_break()
        
        # 第三部分：现代应用指南
        self.add_title("第三部分：现代应用指南", level=2)
        
        applications = self.info.get("applications", {})
        for scene, content in applications.items():
            self.add_title(scene, level=3)
            self.add_paragraph(f"祖辈智慧：{content.get('wisdom', '')}")
            self.add_paragraph("现代应用：")
            for item in content.get("items", []):
                self.add_paragraph(f"• {item}")
            self.doc.add_paragraph()
        
        self.doc.add_page_break()
        
        # 第四部分：家庭情感链接
        self.add_title("第四部分：家庭情感链接", level=2)
        
        self.add_title("与祖辈的情感链接", level=3)
        self.add_paragraph("祖辈虽然已经离开，但他们的影响依然存在。通过以下方式，我们可以与祖辈建立情感链接：")
        
        connections = self.info.get("connections", [])
        for conn in connections:
            self.add_paragraph(f"• {conn}")
        
        self.add_title("隔代人的理解", level=3)
        self.add_paragraph("隔代人之间的理解，是家族传承的重要方式。祖辈的经验是时间的沉淀，孙辈的困惑祖辈可能经历过。理解祖辈，就是理解自己的根。")
        
        # 结语
        self.doc.add_paragraph()
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("—" * 20)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.color.rgb = RGBColor(200, 200, 200)
        
        self.doc.add_paragraph()
        self.add_quote("祖辈的智慧，我们的财富。爷爷吃过的咸盐，是我们人生的指南针。")
        
        # 保存
        output_path = f"爷爷吃过的咸盐_{grandpa_name}.docx"
        self.doc.save(output_path)
        return output_path


def main():
    """主函数"""
    # 示例数据（慈敬爷爷）
    grandpa_info = {
        "name": "慈敬",
        "basic": {
            "生卒": "20世纪（70多年人生）",
            "籍贯": "农村出身，北京学徒",
            "职业": "医生（中医+西医）",
            "执业": "家里开诊所，一人公司"
        },
        "aspects": [
            "文化人：北京城见过世面，上百人会议有头有脸",
            "劳动者：挖水井、拉驴车，亲力亲为",
            "医生：方圆名人，看病比医院好得快",
            "多面手：中医西医都会，不局限于传统"
        ],
        "thinking": {
            "务实思维": {
                "description": "不局限于中医西医，只看疗效。药拆开按片卖，让病人少花钱。自己动手挖水井、拉驴车。",
                "insight": "解决问题比坚持立场更重要。不要被'应该怎么做'束缚，要关注'怎么做有效'。"
            },
            "边界思维": {
                "description": "看病没有医生上赶着追病人的。家里的病人没法治。",
                "insight": "专业的人要有专业的姿态。过度的卑微和过度的亲近，都会损害价值。"
            },
            "两面思维": {
                "description": "文化人+劳动者，脑力劳动+体力劳动，有头有脸+没有架子。",
                "insight": "不要被单一身份定义。你可以是很多面，而且每一面都是真实的你。"
            }
        },
        "lessons": {
            "实干精神": {
                "description": "十几岁学徒，做了一辈子医生。家里开诊所，挖水井、拉驴车，亲力亲为。",
                "insight": "想都是问题，做才是答案。"
            },
            "口碑至上": {
                "description": "看病讲良心，让病人少花钱。方圆一片的名人，看病比医院好得快。",
                "insight": "短期看利益，长期看口碑。"
            },
            "传承断裂": {
                "description": "家里人都没有从医，医术和经验没有完全传承。",
                "insight": "传承需要主动，不能靠自然延续。"
            }
        },
        "attitude": {
            "面对权威": {
                "description": "不论是官员还是农村百姓，都是一个待遇。和劳动同伴没有架子。",
                "insight": "对所有人平等，不因地位而区分态度。"
            },
            "面对变化": {
                "description": "从农村到北京学徒，中医西医都会，在变化的年代中没饿着。",
                "insight": "保持核心，适应形式。"
            },
            "面对自我": {
                "description": "医生救人难救己，最后应了自己的话。",
                "insight": "知道自己的局限，是最大的智慧。"
            }
        },
        "meaning": {
            "物质层面": {
                "description": "医疗工具、笔记本、书、驴车。",
                "insight": "物质会消逝，但物质背后的精神不会。"
            },
            "口碑层面": {
                "description": "方圆一片的名人，看病比医院好得快，徒弟已是专家。",
                "insight": "口碑是无形的资产，比金钱更长久。"
            },
            "精神层面": {
                "description": "实干精神、原则底线、多元身份、家传名言。",
                "insight": "精神传承，是隔代人之间最深刻的链接。"
            },
            "情感层面": {
                "description": "孙子的记忆和怀念，家族的故事，情感的纽带。",
                "insight": "情感是传承的载体，让祖辈永远活在后代心中。"
            }
        },
        "applications": {
            "职场发展": {
                "wisdom": "实干>空谈，口碑>头衔，多元>单一",
                "items": [
                    "用结果说话，不要只说不做",
                    "建立个人品牌，积累口碑",
                    "培养多元技能，不被单一岗位定义"
                ]
            },
            "创业经营": {
                "wisdom": "解决问题>坚持形式，用户价值>短期利润，适应变化>固守传统",
                "items": [
                    "关注用户真正需要什么",
                    "建立长期信任，不要杀鸡取卵",
                    "保持核心，灵活调整形式"
                ]
            },
            "人际关系": {
                "wisdom": "平等对待>区分地位，边界清晰>过度亲近，真诚相处>虚假客套",
                "items": [
                    "对所有人保持尊重",
                    "亲人之间也要有边界",
                    "真诚比技巧更重要"
                ]
            },
            "自我成长": {
                "wisdom": "多元身份>单一标签，自知之明>盲目自信，适应变化>固守舒适区",
                "items": [
                    "探索自己的多面性",
                    "知道自己的边界",
                    "持续学习，适应变化"
                ]
            }
        },
        "connections": [
            "记录故事：采访祖辈，记录他们的经历",
            "传承精神：学习祖辈的优点，在实践中应用",
            "情感表达：告诉祖辈他们的影响，让精神延续"
        ]
    }
    
    generator = GrandpaWisdomReport(grandpa_info)
    output_path = generator.generate()
    print(f"报告已生成：{output_path}")


if __name__ == "__main__":
    main()
