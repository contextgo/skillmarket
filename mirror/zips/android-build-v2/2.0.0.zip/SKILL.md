---
name: android-local-build
description: Android 项目本地构建配置管理。生成构建脚本，管理项目配置，记录构建历史。
metadata:
  openclaw:
    emoji: "📦"
---

# Android Local Build v2.0

## 功能

管理 Android 项目的本地构建配置：
- 项目配置管理
- 生成构建脚本
- 构建历史记录

## 触发条件

- "添加 Android 项目"
- "生成构建脚本"
- "查看构建历史"

## 配置

创建 `~/.android-build/config.json`：

```json
{
  "projects": [
    {
      "name": "my-project",
      "gitUrl": "https://github.com/user/repo.git",
      "branch": "master",
      "module": "app",
      "buildType": "debug"
    }
  ]
}
```

## 使用

### 命令行

```bash
python android_build.py show              # 查看配置
python android_build.py add <name> <git>  # 添加项目
python android_build.py script <name>     # 生成构建脚本
python android_build.py history <name>    # 查看构建历史
```

### 微信对话

- "添加项目 xxx，仓库是 xxx"
- "生成 xxx 的构建脚本"
- "查看构建历史"

## 输出文件

- `~/.android-build/config.json` — 项目配置
- `~/.android-build/scripts/<name>/build.sh` — 构建脚本
- `~/.android-build/history/<name>.json` — 构建历史
