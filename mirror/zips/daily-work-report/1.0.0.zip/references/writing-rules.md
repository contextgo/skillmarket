# Writing Rules

Use this file when converting raw Chinese work notes into formal written reporting.

## Core objective

Turn oral, fragmented input into clear, professional, readable Chinese while preserving facts and making later aggregation easier.

## Rewrite patterns

Convert casual phrasing into report language.

Examples:

- `今天主要搞了接口联调`
  Rewrite as: `今天重点推进了接口联调工作，已完成核心流程的联合验证。`
- `跟产品那边又对了一下需求`
  Rewrite as: `与产品侧再次对齐需求细节，明确了后续处理范围与优先级。`
- `有个问题还没完全解决`
  Rewrite as: `当前仍存在待解决问题，相关原因正在进一步排查。`
- `先把基础的东西搭起来了`
  Rewrite as: `已完成基础框架搭建，为后续功能实现提供了支撑。`

## Tone

- Professional, calm, objective.
- Concise but not telegraphic.
- Prefer action + object + result.
- Avoid slang, filler words, and emotional qualifiers.

## Formatting

- Use one top summary section plus sectioned bullets.
- Keep each work item focused on one topic.
- Split long items into one main sentence plus short supporting labels if needed.
- Leave a blank line between major sections.

## Information hierarchy

Prefer this order inside each item:

1. What was worked on
2. What action was taken
3. What progress/result was achieved
4. What coordination/risk remains

## Missing information

- If scope is clear but result is unclear, use `推进中` or `持续处理中`.
- If a blocker exists without resolution, state the blocker and mark `待跟进`.
- Do not fabricate numbers, deadlines, or achievements.

## Readability rules

- Avoid overlong sentences with many commas.
- Avoid repeating the same verb across adjacent items when alternatives are available.
- Keep nouns concrete: project name, module name, issue type, environment, partner team.
- When the user mentions collaboration, surface it explicitly.

## Summary cue extraction

At the end of the report, capture concise reusable cues such as:

- `推进 XX 项目进入联调阶段`
- `完成 XX 模块基础能力建设`
- `协同产品/测试/运维解决关键依赖`
- `识别并跟进 XX 风险点`

These lines should be short enough to reuse in weekly, monthly, or annual summaries.
