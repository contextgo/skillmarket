# Report Templates

Use these templates when the user asks for a specific presentation style.

## Standard daily report

```md
## 今日工作概述
用 2-4 句话概括今日重点、整体进展和产出方向。

## 主要工作内容
1. 事项名称：动作 + 对象 + 当前结果/进展。
2. 事项名称：动作 + 对象 + 当前结果/进展。
3. 事项名称：动作 + 对象 + 当前结果/进展。

## 问题与风险
- 风险或待确认事项
- 外部依赖或阻塞点

## 明日计划
1. 下一步动作
2. 下一步动作

## 总结沉淀
- 项目/主题 + 关键动作 + 结果
- 项目/主题 + 协同或推进价值
```

## Leader-facing version

Use when the audience is a manager or project lead.

```md
## 今日重点
概括今日围绕的核心任务、里程碑或业务事项。

## 关键进展
1. 进展事项 + 结果
2. 协同事项 + 影响
3. 风险处理 + 当前状态

## 风险与需关注事项
- 风险点
- 所需支持

## 下一步安排
1. 下一步动作
2. 预期目标
```

## Archive-friendly version

Use when the report is intended to feed future summaries.

```md
## 今日工作概述

## 事项明细
1. 项目/模块：
   工作动作：
   当前结果：
   协同对象：
   备注：

## 风险与待办

## 明日计划

## 可复用总结要点
- 本日贡献点
- 阶段推进点
- 协同支撑点
```

## Mapping daily reports to periodic summaries

When preparing future monthly, half-year, or annual summaries, map each daily item into these dimensions:

- `项目主题`：属于哪个项目、模块、专项或管理事项
- `工作动作`：完成、推进、协调、排查、优化、交付、支持
- `阶段结果`：完成了什么、推进到什么阶段、解决了什么问题
- `价值体现`：效率、质量、风险控制、跨团队协同、交付保障
- `持续事项`：后续还需要推进什么

## Annual-summary friendly phrasing

Prefer phrases that can later be merged naturally, such as:

- `持续推进`
- `完成搭建`
- `支撑上线`
- `推动对齐`
- `排查并解决`
- `沉淀规范`
- `优化流程`

Avoid daily-only wording such as:

- `今天先`
- `临时搞了`
- `顺手处理了`
- `简单看了下`
