---
name: daily-work-report
description: Convert spoken or fragmented Chinese work notes into polished, structured daily work reports with clear formatting, concise business writing, and reusable summary cues. Use when Codex needs to整理日报、润色口语化工作记录、统一书面表达、补全日报结构，或为周报、月报、半年度总结、年度总结沉淀可复用素材。
---

# Daily Work Report

Use this skill to transform rough daily notes into a readable, professional Chinese work report that can later support periodic summaries.

## Follow this workflow

1. Extract the user's raw facts.
2. Separate facts into completed work, progress, collaboration, blockers, and next actions.
3. Rewrite all content in concise written Chinese.
4. Format the result as a structured report with stable headings.
5. Preserve reusable summary cues so later reports can be aggregated into monthly, half-year, or annual summaries.

## Normalize the input

- Treat fragments, chat-style notes, voice-transcribed text, and unordered bullets as valid input.
- Preserve facts. Do not invent metrics, dates, owners, or business impact unless the user supplied them.
- Merge repeated points.
- Convert vague spoken phrasing into specific written statements where the fact is already implied.
- If information is missing but the main intent is clear, keep the wording conservative instead of asking follow-up questions.
- If a gap would materially change meaning, add a brief `待补充` note rather than guessing.

## Rewrite rules

- Use professional written Chinese.
- Prefer short sentences and explicit verbs.
- Replace conversational fillers with direct statements.
- Keep chronology and causal relationships clear.
- Highlight outcomes, deliverables, decisions, risks, and next steps.
- When the user provides only activity descriptions, infer a neutral result phrase only when it is directly supported by the input.
- Avoid exaggerated language, empty praise, and repetitive wording.

Read [references/writing-rules.md](references/writing-rules.md) when you need concrete rewriting and formatting rules.

## Default output structure

Use this structure unless the user requests another format:

### 今日工作概述

Write 2-4 sentences that summarize the main focus and overall progress of the day.

### 主要工作内容

List 3-6 items. For each item, prefer this pattern:

`1. 事项名称：动作 + 对象 + 当前结果/进展。`

When useful, extend with:

- `协同情况：`
- `产出物：`
- `影响或价值：`

### 问题与风险

State blockers, dependencies, pending confirmations, or resource constraints. If none are provided, write `暂无明显问题或风险。`

### 明日计划

List the next actions in concrete task language.

### 总结沉淀

Add 2-5 concise bullets that can be reused later for periodic summaries. Capture:

- key project/topic
- concrete contribution
- stage progress
- coordination or cross-team support
- visible result or pending milestone

Read [references/report-templates.md](references/report-templates.md) when you need alternate templates or periodic-summary mapping.

## Adaptation rules

- If the user explicitly asks for a shorter report, keep the same headings but compress each section.
- If the user asks for a leader-facing version, emphasize outcomes, risks, and next steps.
- If the user asks for a personal archive version, preserve more implementation detail and context.
- If the input spans multiple days, split by date first, then summarize each date with the same structure.
- If the input is highly technical, keep domain terms but still rewrite surrounding text into readable business Chinese.

## Style constraints

- Keep headings stable across days to make later aggregation easier.
- Use Markdown lists and spacing to improve scanability.
- Prefer Arabic numerals for enumerated work items.
- Keep terminology consistent for the same project, module, or issue.
- When dates are known, retain exact dates.
- When outputs include files, links, environments, issue IDs, or versions, preserve them exactly.

## For future periodic summaries

Whenever possible, phrase each work item so it can answer one of these later questions:

- What project or theme did the work belong to?
- What concrete action did the user take?
- What result, milestone, or progress was produced?
- What collaboration or ownership did the user demonstrate?
- What follow-up remains?

This makes daily reports easier to roll up into week, month, half-year, and annual summaries without re-reading raw notes.
