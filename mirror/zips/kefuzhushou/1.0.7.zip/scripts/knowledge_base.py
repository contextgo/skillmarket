#!/usr/bin/env python3
"""
知识库管理模块 - 全平台电商客服助手

支持商品表格、产品手册、FAQ等知识库的学习和查询。

Usage:
    python knowledge_base.py --add <文件路径>
    python knowledge_base.py --query <问题>
    python knowledge_base.py --list
"""

import argparse
import os
import json
from typing import Dict, List, Optional

# 知识库存储
KB_STORAGE_FILE = "knowledge_base.json"

# 知识库类型
KB_TYPES = ["商品表格", "产品手册", "FAQ文档", "售后政策", "官网链接"]

class KnowledgeBase:
    """知识库管理器"""
    
    def __init__(self, storage_file: str = KB_STORAGE_FILE):
        self.storage_file = storage_file
        self.kb_data: Dict[str, List] = {kb_type: [] for kb_type in KB_TYPES}
        self._load()
    
    def _load(self):
        """加载知识库"""
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r', encoding='utf-8') as f:
                    self.kb_data = json.load(f)
            except:
                pass
    
    def _save(self):
        """保存知识库"""
        with open(self.storage_file, 'w', encoding='utf-8') as f:
            json.dump(self.kb_data, f, ensure_ascii=False, indent=2)
    
    def add(self, kb_type: str, source: str, content: str = "") -> bool:
        """添加知识库条目"""
        if kb_type not in KB_TYPES:
            print(f"❌ 不支持的类型: {kb_type}")
            return False
        
        entry = {
            "source": source,
            "content": content or source,
            "type": kb_type
        }
        self.kb_data[kb_type].append(entry)
        self._save()
        print(f"✅ 已添加: [{kb_type}] {source}")
        return True
    
    def query(self, keyword: str) -> List[Dict]:
        """查询知识库"""
        results = []
        for kb_type, entries in self.kb_data.items():
            for entry in entries:
                if keyword.lower() in entry["content"].lower():
                    results.append({**entry, "kb_type": kb_type})
        return results
    
    def list_all(self):
        """列出所有知识库"""
        for kb_type in KB_TYPES:
            entries = self.kb_data.get(kb_type, [])
            if entries:
                print(f"\n【{kb_type}】({len(entries)}条)")
                for e in entries:
                    print(f"  • {e['source']}")

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 知识库管理模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --add FAQ文档 --source faq.md
  %(prog)s --add 商品表格 --source products.xlsx
  %(prog)s --query 手机
  %(prog)s --list
        """
    )
    parser.add_argument("--add", metavar="类型", help="添加知识库 (商品表格/产品手册/FAQ文档/售后政策)")
    parser.add_argument("--source", metavar="来源", help="知识库来源")
    parser.add_argument("--query", metavar="关键词", help="查询知识库")
    parser.add_argument("--list", action="store_true", help="列出所有知识库")
    
    args = parser.parse_args()
    
    kb = KnowledgeBase()
    
    if args.add:
        if not args.source:
            print("❌ 请指定 --source")
        else:
            kb.add(args.add, args.source)
    elif args.query:
        results = kb.query(args.query)
        if results:
            print(f"找到 {len(results)} 条结果:")
            for r in results:
                print(f"  [{r['kb_type']}] {r['content']}")
        else:
            print("未找到相关内容")
    elif args.list:
        kb.list_all()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
