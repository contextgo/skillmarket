#!/usr/bin/env python3
"""
订单查询模块 - 全平台电商客服助手

查询订单状态、物流信息等。

Usage:
    python order_query.py --order-id <订单号>
    python order_query.py --status <状态>
"""

import argparse
from typing import Dict, Optional

# 订单状态映射
ORDER_STATUS: Dict[str, str] = {
    "pending": "待付款",
    "paid": "已付款/待发货",
    "shipped": "已发货/运输中",
    "delivered": "已签收",
    "completed": "已完成",
    "cancelled": "已取消",
    "refunding": "退款中",
    "refunded": "已退款"
}

# 物流状态
LOGISTICS_STATUS: Dict[str, str] = {
    "in_transit": "运输中",
    "out_for_delivery": "派送中",
    "delivered": "已签收",
    "exception": "异常",
    "returned": "已退回"
}

def query_order(order_id: str) -> Optional[Dict]:
    """查询订单信息"""
    # 模拟查询，实际需要对接平台API
    return {
        "order_id": order_id,
        "status": "shipped",
        "express": "顺丰速运",
        "tracking": "SF1234567890"
    }

def get_status_text(status_code: str) -> str:
    """获取状态文字"""
    return ORDER_STATUS.get(status_code, "未知状态")

def get_logistics_info(tracking_no: str) -> Optional[Dict]:
    """获取物流信息"""
    # 模拟查询，实际需要对接物流API
    return {
        "tracking_no": tracking_no,
        "carrier": "顺丰速运",
        "current": "运输中",
        "location": "上海分拨中心",
        "time": "2024-01-15 14:30"
    }

def format_order_info(order: Dict) -> str:
    """格式化订单信息"""
    status_text = get_status_text(order.get("status", ""))
    return f"""
订单号: {order['order_id']}
状态: {status_text}
快递: {order.get('express', '未发货')}
运单号: {order.get('tracking', '无')}
"""

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 订单查询模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --order-id 20240115001     # 查询订单
  %(prog)s --track SF1234567890       # 查询物流
  %(prog)s --list-status              # 列出所有状态
        """
    )
    parser.add_argument("--order-id", metavar="订单号", help="查询订单信息")
    parser.add_argument("--track", metavar="运单号", help="查询物流信息")
    parser.add_argument("--list-status", action="store_true", help="列出所有订单状态")
    
    args = parser.parse_args()
    
    if args.order_id:
        order = query_order(args.order_id)
        if order:
            print(format_order_info(order))
        else:
            print("❌ 未找到订单")
    elif args.track:
        logistics = get_logistics_info(args.track)
        if logistics:
            print(f"""
运单号: {logistics['tracking_no']}
快递: {logistics['carrier']}
状态: {logistics['current']}
位置: {logistics['location']}
时间: {logistics['time']}
            """)
        else:
            print("❌ 未找到物流信息")
    elif args.list_status:
        print("【订单状态】")
        for code, status in ORDER_STATUS.items():
            print(f"  {code}: {status}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
