#!/usr/bin/env python3
"""
平台适配模块 - 全平台电商客服助手

支持国内外14大电商平台的接口适配和平台规则处理。

Usage:
    python platform_adapter.py --list-platforms
    python platform_adapter.py --check-rules <platform>
"""

import argparse
import sys
from typing import Dict, List, Optional

# 国内平台
DOMESTIC_PLATFORMS = [
    "淘宝", "京东", "拼多多", "抖音", "快手", "小红书"
]

# 外贸平台
FOREIGN_PLATFORMS = [
    "阿里国际站", "速卖通", "亚马逊", "eBay", 
    "Shopee", "Lazada", "Wish", "独立站"
]

# 平台规则提醒
PLATFORM_RULES: Dict[str, str] = {
    "淘宝": "回复时限要求，超时扣分",
    "京东": "咚咚响应率影响评分",
    "拼多多": "客服回复率影响活动报名",
    "亚马逊": "24小时内必须回复",
    "速卖通": "注意买家时区",
    "Shopee": "聊天分数影响店铺权重",
    "Lazada": "响应时间影响搜索排名",
}

def list_platforms() -> None:
    """列出所有支持的平台"""
    print("=" * 40)
    print("📦 国内平台 (6大)")
    print("=" * 40)
    for p in DOMESTIC_PLATFORMS:
        print(f"  • {p}")
    
    print("\n" + "=" * 40)
    print("🌐 外贸平台 (8大)")
    print("=" * 40)
    for p in FOREIGN_PLATFORMS:
        print(f"  • {p}")
    print("=" * 40)
    print(f"\n总计: {len(DOMESTIC_PLATFORMS)} + {len(FOREIGN_PLATFORMS)} = {len(DOMESTIC_PLATFORMS) + len(FOREIGN_PLATFORMS)} 平台")

def check_rules(platform: str) -> None:
    """检查平台规则"""
    rules = PLATFORM_RULES.get(platform, f"{platform} 规则请参考平台官方文档")
    print(f"[{platform}] 规则提醒: {rules}")

def get_platform_config(platform: str) -> Dict:
    """获取平台配置"""
    return {
        "name": platform,
        "rules": PLATFORM_RULES.get(platform, "无特殊规则"),
        "supported": platform in DOMESTIC_PLATFORMS + FOREIGN_PLATFORMS
    }

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 平台适配模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --list-platforms    # 列出所有支持的平台
  %(prog)s --check-rules 淘宝  # 检查淘宝平台规则
        """
    )
    parser.add_argument("--list-platforms", action="store_true", help="列出所有支持的平台")
    parser.add_argument("--check-rules", metavar="PLATFORM", help="检查指定平台的规则")
    
    args = parser.parse_args()
    
    if args.list_platforms:
        list_platforms()
    elif args.check_rules:
        check_rules(args.check_rules)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
