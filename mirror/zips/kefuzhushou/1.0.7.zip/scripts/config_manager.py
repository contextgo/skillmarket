#!/usr/bin/env python3
"""
配置管理模块 - 全平台电商客服助手

管理技能配置、平台设置、参数调整等。

Usage:
    python config_manager.py --get <key>
    python config_manager.py --set <key> <value>
    python config_manager.py --list
"""

import argparse
import json
import os
from typing import Dict, Any, Optional

# 默认配置
DEFAULT_CONFIG: Dict[str, Any] = {
    "response_delay_min": 3,
    "response_delay_max": 10,
    "auto_reply_enabled": True,
    "night_mode": False,
    "night_mode_start": 22,
    "night_mode_end": 8,
    "max_retries": 3,
    "escalation_threshold": 3,
    "language": "zh-CN",
    "log_level": "INFO"
}

CONFIG_FILE = "config.json"

class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_file: str = CONFIG_FILE):
        self.config_file = config_file
        self.config: Dict[str, Any] = DEFAULT_CONFIG.copy()
        self._load()
    
    def _load(self):
        """加载配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    self.config.update(loaded)
            except:
                pass
    
    def _save(self):
        """保存配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def get(self, key: str) -> Optional[Any]:
        """获取配置项"""
        return self.config.get(key)
    
    def set(self, key: str, value: Any) -> bool:
        """设置配置项"""
        if key in DEFAULT_CONFIG:
            self.config[key] = value
            self._save()
            print(f"✅ 已设置: {key} = {value}")
            return True
        else:
            print(f"❌ 未知配置项: {key}")
            return False
    
    def list_all(self):
        """列出所有配置"""
        print("【当前配置】")
        for key, default in DEFAULT_CONFIG.items():
            value = self.config.get(key, default)
            marker = "" if value == default else f" (默认: {default})"
            print(f"  {key}: {value}{marker}")

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 配置管理模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --get response_delay_min    # 获取配置
  %(prog)s --set auto_reply_enabled false  # 设置配置
  %(prog)s --list                      # 列出所有配置
  %(prog)s --reset                     # 重置为默认配置
        """
    )
    parser.add_argument("--get", metavar="KEY", help="获取配置项")
    parser.add_argument("--set", nargs=2, metavar=("KEY", "VALUE"), help="设置配置项")
    parser.add_argument("--list", action="store_true", help="列出所有配置")
    parser.add_argument("--reset", action="store_true", help="重置为默认配置")
    
    args = parser.parse_args()
    
    cm = ConfigManager()
    
    if args.get:
        value = cm.get(args.get)
        if value is not None:
            print(f"{args.get} = {value}")
        else:
            print(f"❌ 未找到: {args.get}")
    elif args.set:
        key, value = args.set
        # 类型转换
        if value.lower() in ('true', 'false'):
            value = value.lower() == 'true'
        elif value.isdigit():
            value = int(value)
        cm.set(key, value)
    elif args.list:
        cm.list_all()
    elif args.reset:
        cm.config = DEFAULT_CONFIG.copy()
        cm._save()
        print("✅ 已重置为默认配置")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
