#!/usr/bin/env python3
"""
售后话术模块 - 全平台电商客服助手

覆盖退换货、售后政策、常见问题等话术库。

Usage:
    python after_sales.py --query <问题>
    python after_sales.py --category <类别>
"""

import argparse
from typing import Dict, List, Optional

# 售后话术库
AFTER_SALES_SCRIPTS: Dict[str, Dict[str, str]] = {
    "退换货": {
        "policy": "本店支持7天无理由退换货（不影响二次销售），质量问题包邮退换。请联系客服获取退货地址~",
        "process": "退货流程：1.联系客服申请 → 2.获取退货地址 → 3.寄回商品 → 4.确认收货后退款"
    },
    "退款": {
        "policy": "退款申请我们会在1-3个工作日内处理，款项原路返回，请耐心等待~",
        "processing": "您的退款正在处理中，预计1-3个工作日到账，请注意查收哦~"
    },
    "保修": {
        "policy": "本店商品享有保修服务，保修期内非人为损坏可免费维修，请提供订单号和商品照片~",
        "process": "保修流程：提供订单号+商品问题描述+照片 → 客服审核 → 安排维修/换货"
    },
    "运费": {
        "policy": "质量问题运费由我们承担，请先垫付寄回，收到货后运费会退给您哦~",
        "normal": "非质量问题退换货，往返运费需买家承担~"
    },
    "发票": {
        "policy": "本店可开普通发票/增值税发票，请提供开票信息，发票随货发出或单独寄送~"
    }
}

# 常见问题回复
FAQ_SCRIPTS: Dict[str, str] = {
    "什么时候发货": "我们会在您下单后24小时内发货哦~",
    "发什么快递": "默认发{express}，部分地区可能不同~",
    "能便宜点吗": "店铺活动期间价格已经很优惠了呢~",
    "是正品吗": "本店商品100%正品保障，假一赔十~",
    "有色差吗": "实物与图片尽量保持一致，但因光线和显示器可能略有差异~"
}

def query_after_sales(category: str) -> None:
    """查询售后话术"""
    if category in AFTER_SALES_SCRIPTS:
        print(f"【{category}】")
        for key, value in AFTER_SALES_SCRIPTS[category].items():
            print(f"  {key}: {value}")
    else:
        print(f"暂无{category}相关话术")

def search_faq(query: str) -> None:
    """搜索FAQ"""
    for question, answer in FAQ_SCRIPTS.items():
        if query.lower() in question.lower():
            print(f"Q: {question}")
            print(f"A: {answer}")
            return
    print("未找到相关问题，请联系人工客服~")

def list_categories() -> None:
    """列出所有售后类别"""
    print("【售后话术类别】")
    for i, category in enumerate(AFTER_SALES_SCRIPTS.keys(), 1):
        print(f"  {i}. {category}")

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 售后话术模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --list              # 列出所有售后类别
  %(prog)s --query 退换货      # 查询退换货话术
  %(prog)s --faq 什么时候发货  # 搜索FAQ
        """
    )
    parser.add_argument("--list", action="store_true", help="列出所有售后类别")
    parser.add_argument("--query", metavar="类别", help="查询售后话术")
    parser.add_argument("--faq", metavar="问题", help="搜索FAQ")
    
    args = parser.parse_args()
    
    if args.list:
        list_categories()
    elif args.query:
        query_after_sales(args.query)
    elif args.faq:
        search_faq(args.faq)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
