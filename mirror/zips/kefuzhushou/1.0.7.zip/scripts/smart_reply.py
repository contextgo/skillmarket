#!/usr/bin/env python3
"""
智能回复模块 - 全平台电商客服助手

AI智能理解买家意图，生成专业回复话术。

Usage:
    python smart_reply.py --input <消息>
    python smart_reply.py --batch <文件>
"""

import argparse
import re
from typing import Dict, List, Optional, Tuple

# 意图识别关键词
INTENT_KEYWORDS: Dict[str, List[str]] = {
    "咨询": ["价格", "多少钱", "怎么卖", "优惠", "便宜", "折扣", "规格", "尺寸", "颜色"],
    "物流": ["发货", "快递", "物流", "到哪了", "几天到", "什么时候到", "还没收到"],
    "售后": ["坏了", "质量", "退款", "退货", "换货", "保修", "维修", "有问题"],
    "投诉": ["差评", "投诉", "态度", "不满意", "骗子", "假货", "垃圾"],
    "下单": ["下单", "购买", "买", "拍", "要", "下单"],
    "催单": ["催", "快点", "急", "很久了", "还没发货"],
    "改单": ["改地址", "改电话", "换", "换货", "换颜色", "换尺寸"],
    "确认": ["收到", "确认收货", "好用", "不错", "满意", "可以"]
}

# 情绪检测关键词
EMOTION_KEYWORDS: Dict[str, List[str]] = {
    "positive": ["谢谢", "好的", "明白", "理解", "满意", "喜欢", "不错", "好的"],
    "negative": ["垃圾", "差", "烂", "骗子", "假货", "投诉", "退款", "退货", "不要了"],
    "urgent": ["急", "快点", "赶紧", "马上", "立刻", "马上", "立刻", "紧急"]
}

# 回复话术模板
REPLY_TEMPLATES: Dict[str, str] = {
    "咨询": "您好！感谢咨询~ {answer}",
    "物流": "您好！{answer} 如有其他问题随时联系我哦~",
    "售后": "您好！非常抱歉给您带来不便，{answer} 请您放心，我们会认真处理~",
    "投诉": "亲，非常抱歉让您不满意，{answer} 希望给您满意的解决方案~",
    "下单": "好的！{answer} 期待为您服务~",
    "催单": "亲，抱歉让您久等了，{answer} 请您再稍等片刻~",
    "改单": "亲，{answer} 我帮您备注或者转人工处理~",
    "确认": "感谢亲的好评！{answer} 期待下次为您服务~"
}

def detect_intent(message: str) -> Tuple[str, float]:
    """检测买家意图"""
    message_lower = message.lower()
    scores = {}
    
    for intent, keywords in INTENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in message_lower)
        scores[intent] = score
    
    if max(scores.values()) == 0:
        return "咨询", 0.5
    
    intent = max(scores.items(), key=lambda x: x[1])
    confidence = min(intent[1] / 3, 1.0)
    return intent[0], confidence

def detect_emotion(message: str) -> str:
    """检测情绪"""
    for emotion, keywords in EMOTION_KEYWORDS.items():
        if any(kw in message for kw in keywords):
            return emotion
    return "neutral"

def generate_reply(intent: str, context: Optional[Dict] = None) -> str:
    """生成回复"""
    template = REPLY_TEMPLATES.get(intent, "感谢您的咨询，我们会尽快为您处理~")
    answer = context.get("answer", "请问还有什么可以帮您？") if context else "请问还有什么可以帮您？"
    return template.format(answer=answer)

def smart_reply(message: str, context: Optional[Dict] = None) -> Dict:
    """智能回复主函数"""
    intent, confidence = detect_intent(message)
    emotion = detect_emotion(message)
    reply = generate_reply(intent, context)
    
    return {
        "input": message,
        "intent": intent,
        "confidence": confidence,
        "emotion": emotion,
        "reply": reply,
        "escalate": emotion == "negative" and intent in ["投诉", "售后"]
    }

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 智能回复模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --input "这个手机多少钱"        # 单条消息分析
  %(prog)s --input "等了5天了还没发货"      # 催单场景
  %(prog)s --intents                         # 列出所有支持的意图类型
        """
    )
    parser.add_argument("--input", metavar="TEXT", help="输入买家消息")
    parser.add_argument("--intents", action="store_true", help="列出所有意图类型")
    
    args = parser.parse_args()
    
    if args.input:
        result = smart_reply(args.input)
        print(f"输入: {result['input']}")
        print(f"意图: {result['intent']} (置信度: {result['confidence']:.2f})")
        print(f"情绪: {result['emotion']}")
        print(f"回复: {result['reply']}")
        if result['escalate']:
            print("⚠️ 建议转人工处理")
    elif args.intents:
        print("【支持的意图类型】")
        for intent in INTENT_KEYWORDS.keys():
            print(f"  • {intent}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
