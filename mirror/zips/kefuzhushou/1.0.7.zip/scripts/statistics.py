#!/usr/bin/env python3
"""
统计分析模块 - 全平台电商客服助手

统计客服数据、响应率、问题分类等。

Usage:
    python statistics.py --daily
    python statistics.py --weekly
    python statistics.py --export <文件>
"""

import argparse
import json
from datetime import datetime, timedelta
from typing import Dict, List

# 统计数据存储
STATS_FILE = "statistics.json"

class Statistics:
    """统计管理器"""
    
    def __init__(self, stats_file: str = STATS_FILE):
        self.stats_file = stats_file
        self.data: Dict = self._load()
    
    def _load(self) -> Dict:
        """加载统计数据"""
        if __import__('os').path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return self._init_data()
    
    def _init_data(self) -> Dict:
        """初始化统计数据"""
        return {
            "total_messages": 0,
            "total_orders": 0,
            "total_refunds": 0,
            "response_time_avg": 0,
            "satisfaction_rate": 0,
            "category_stats": {},
            "daily_stats": []
        }
    
    def _save(self):
        """保存统计数据"""
        with open(self.stats_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def increment(self, key: str, value: int = 1):
        """增加计数"""
        if key in self.data:
            self.data[key] += value
        else:
            self.data[key] = value
        self._save()
    
    def record_category(self, category: str):
        """记录问题分类"""
        if "category_stats" not in self.data:
            self.data["category_stats"] = {}
        self.data["category_stats"][category] = self.data["category_stats"].get(category, 0) + 1
        self._save()
    
    def get_summary(self) -> Dict:
        """获取统计摘要"""
        return self.data.copy()
    
    def format_summary(self) -> str:
        """格式化统计摘要"""
        d = self.data
        return f"""
【客服统计摘要】
━━━━━━━━━━━━━━━━━━
总消息数: {d.get('total_messages', 0)}
总订单数: {d.get('total_orders', 0)}
退款数: {d.get('total_refunds', 0)}
平均响应: {d.get('response_time_avg', 0)}秒
满意率: {d.get('satisfaction_rate', 0)}%
━━━━━━━━━━━━━━━━━━
【问题分类TOP5】
"""
    
    def format_category_stats(self) -> str:
        """格式化分类统计"""
        categories = self.data.get("category_stats", {})
        sorted_cats = sorted(categories.items(), key=lambda x: x[1], reverse=True)[:5]
        if not sorted_cats:
            return "暂无数据"
        return "\n".join([f"  {i+1}. {cat}: {count}条" for i, (cat, count) in enumerate(sorted_cats)])

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 统计分析模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --summary          # 查看统计摘要
  %(prog)s --category         # 查看问题分类
  %(prog)s --export stats.json  # 导出统计数据
        """
    )
    parser.add_argument("--summary", action="store_true", help="查看统计摘要")
    parser.add_argument("--category", action="store_true", help="查看问题分类")
    parser.add_argument("--export", metavar="FILE", help="导出统计数据")
    
    args = parser.parse_args()
    
    stats = Statistics()
    
    if args.summary:
        print(stats.format_summary())
    elif args.category:
        print("【问题分类统计】")
        print(stats.format_category_stats())
    elif args.export:
        with open(args.export, 'w', encoding='utf-8') as f:
            json.dump(stats.get_summary(), f, ensure_ascii=False, indent=2)
        print(f"✅ 已导出到 {args.export}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
