#!/usr/bin/env python3
"""
投诉处理模块 - 全平台电商客服助手

处理买家投诉、差评安抚、情绪疏导等专业话术。

Usage:
    python complaint_handler.py --type <类型> --message <买家消息>
"""

import argparse
import re
from typing import Optional, Dict

# 投诉类型对应话术
COMPLAINT_RESPONSES: Dict[str, Dict[str, str]] = {
    "质量": {
        "standard": "非常抱歉给您带来不便，收到您关于商品质量的反馈，我们会认真核实。如有质量问题支持退换货，请问您方便拍照发给我们确认一下吗？",
        "urgent": "亲，非常抱歉！质量问题我们非常重视，马上为您安排退换货，运费我们承担，请先不要差评哦~"
    },
    "物流": {
        "standard": "亲，抱歉让您久等了，物流问题我们会尽快联系快递公司核实，也会催促尽快派送。",
        "urgent": "亲，非常抱歉物流延迟了！我这边马上联系快递催件，同时给您申请补偿，真的很对不起！"
    },
    "服务": {
        "standard": "感谢您的反馈，我们会改进服务。请问有什么可以为您解决的吗？",
        "urgent": "亲，对不起让您不满意了，我会立即反馈并改进，希望还能为您提供更好的服务~"
    },
    "差评": {
        "standard": "亲，收到您的反馈我们会认真改进，希望能有机会弥补。如有任何问题随时联系我们~",
        "urgent": "亲，抱歉给您带来不好的体验！请联系我们，承诺给您满意处理，恳请能否修改一下评价呢？"
    }
}

# 转人工场景
ESCALATION_KEYWORDS = ["退款", "改地址", "改订单", "赔偿", "报警", "投诉", "曝光"]

def analyze_complaint(message: str) -> str:
    """分析投诉类型"""
    for keyword in COMPLAINT_RESPONSES.keys():
        if keyword in message:
            return keyword
    return "服务"  # 默认

def generate_response(complaint_type: str, is_urgent: bool = False) -> str:
    """生成投诉回复"""
    level = "urgent" if is_urgent else "standard"
    return COMPLAINT_RESPONSES.get(complaint_type, {}).get(level, COMPLAINT_RESPONSES["服务"][level])

def should_escalate(message: str) -> bool:
    """判断是否需要转人工"""
    return any(kw in message for kw in ESCALATION_KEYWORDS)

def get_escalation_response() -> str:
    """获取转人工话术"""
    return "亲，这个问题我帮您转接人工客服处理，稍等片刻哦~"

def main():
    parser = argparse.ArgumentParser(
        description="全平台电商客服助手 - 投诉处理模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --type 质量 --urgent       # 质量投诉紧急回复
  %(prog)s --type 物流               # 物流问题标准回复
  %(prog)s --check-escalate 退款申请  # 检查是否需要转人工
        """
    )
    parser.add_argument("--type", choices=list(COMPLAINT_RESPONSES.keys()), help="投诉类型")
    parser.add_argument("--urgent", action="store_true", help="紧急模式")
    parser.add_argument("--message", help="买家消息内容")
    parser.add_argument("--check-escalate", metavar="TEXT", help="检查是否需要转人工")
    
    args = parser.parse_args()
    
    if args.message:
        complaint_type = analyze_complaint(args.message)
        print(f"检测类型: {complaint_type}")
        if should_escalate(args.message):
            print(f"建议: {get_escalation_response()}")
        else:
            print(f"回复: {generate_response(complaint_type, args.urgent)}")
    elif args.type:
        print(generate_response(args.type, args.urgent))
    elif args.check_escalate:
        if should_escalate(args.check_escalate):
            print("⚠️ 建议转人工处理")
        else:
            print("✅ 可以自动处理")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
