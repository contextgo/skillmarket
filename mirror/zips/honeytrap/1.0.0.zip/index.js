/**
 * HoneyTrap v4.2 - 信息欺骗防御技能
 *
 * 功能：反制外部代码/Agent恶意访问本地信息
 * 策略：假信息、蜜罐、混淆、反引导
 * 通知：实时警报给机主
 * 自保护：防止其他技能篡改HoneyTrap
 *
 * ============================================================
 * v4.0 新增: 杀毒引擎模块
 * ============================================================
 * v4.1 新增: IP访问控制模块
 * ============================================================
 * v4.2 安全修复:
 *   - 修复ReDoS正则表达式漏洞
 *   - 修复自我保护可被禁用漏洞
 *   - 修复Owner Key明文存储漏洞
 *   - 修复PowerShell注入漏洞
 *   - 修复技能名称可伪造漏洞
 *   - 修复日志信息泄露漏洞
 *   - 修复JSON解析容错问题
 *   - 修复频率限制竞态问题
 *   - 令牌有效期从24小时缩短至2小时
 * ============================================================
 * 灵感来源:
 * - 传统杀毒软件: 特征码扫描、行为监控、启发式分析
 * - EDR终端检测: 行为分析、攻击链追踪、取证分析
 * - XDR扩展检测: 多源关联、AI智能分析、自动化响应
 * - 防火墙: IP黑名单/白名单、访问控制、频率限制
 *
 * 核心能力:
 * - 三层检测: 静态扫描(指纹) + 动态分析(行为) + 启发式评估
 * - 四层防御: 指纹识别 → 行为监控 → 风险评分 → 自动响应
 * - 五种能力: 感知/分析/决策/响应/取证
 * - IP控制: 黑名单封禁、白名单信任、频率限制、机主确认
 */

const fs = require('fs');
const path = require('path');

// 加载自我保护模块
let SelfProtection = null;
try {
    SelfProtection = require('./src/self_protection.js');
} catch (e) {
    console.warn('HoneyTrap: 自我保护模块加载失败', e.message);
}

// 加载通知模块
let HoneyTrapNotifier = null;
let HoneyTrapWithNotifier = null;

try {
    const notifierModule = require('./notifier.js');
    HoneyTrapNotifier = notifierModule.HoneyTrapNotifier;
    HoneyTrapWithNotifier = notifierModule.HoneyTrapWithNotifier;
} catch (e) {
    console.warn('HoneyTrap: 通知模块加载失败', e.message);
}

// 加载AV防御引擎 (v4.0新增)
let DefenseEngine = null;
try {
    DefenseEngine = require('./src/defense_engine.js');
} catch (e) {
    console.warn('HoneyTrap: AV防御引擎加载失败', e.message);
}

// 加载IP访问控制模块 (v4.1新增)
let IPAccessController = null;
try {
    const ipControlModule = require('./src/ip_control.js');
    IPAccessController = ipControlModule.IPAccessController;
} catch (e) {
    console.warn('HoneyTrap: IP访问控制模块加载失败', e.message);
}

// ============================================================
// 配置
// ============================================================

const DEFAULT_CONFIG = {
    protection_mode: 'aggressive',  // aggressive | stealth | paranoid
    true_false_ratio: [30, 70],      // [真%, 假%]
    log_level: 'detailed',
    
    // 蜜罐配置
    honey_files: [
        'credentials.json',
        'api_keys.txt', 
        '.env',
        '.env.production',
        'config/secrets.yml',
        'keys/service_account.json',
        'database_passwords.txt'
    ],
    
    // 假数据模板
    fake_data_templates: {
        env: `API_KEY=fake_sk_1234567890abcdef
DATABASE_URL=postgresql://fake:5432/fake_db
SECRET_KEY=fake_secret_key_12345
JWT_SECRET=fake_jwt_secret_xyz
AWS_ACCESS_KEY_ID=fake_aws_access_key
AWS_SECRET_ACCESS_KEY=fake_aws_secret`,
        
        credentials: `{
    "api_key": "sk_fake_key_1234567890",
    "service_account": "fake@project.iam.gserviceaccount.com",
    "private_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKEKEY\n-----END RSA PRIVATE KEY-----"
}`,

        api_response: {
            users: [],
            total: 0,
            status: 'success'
        }
    },
    
    // 白名单（不触发反制的Agent）
    whitelist: [],
    
    // 自我保护配置 (默认启用)
    self_protection: {
        enabled: true,
        lockOnThreat: true
    },

    // AV防御引擎配置 (v4.0新增 - 默认启用)
    av_protection: {
        enabled: true,
        autoResponse: true,        // 自动响应威胁
        sensitivity: 'medium',      // low, medium, high, paranoid
        heuristicThresholds: {
            low: 30,
            medium: 50,
            high: 70,
            critical: 90
        }
    }
};

// 蜜罐存储位置
const HONEY_DIR = '.honeytrap';
const ACCESS_LOG = '.honeytrap/access_log.json';

// ============================================================
// 核心模块
// ============================================================

class HoneyTrap {
    constructor(config = {}) {
        this.config = { ...DEFAULT_CONFIG, ...config };
        this.accessLog = this.loadAccessLog();

        // 初始化自我保护引擎 (v4.2修复: 强制启用，不允许外部禁用)
        // ⚠️ 安全修复: 原代码允许通过 config.self_protection.enabled = false 禁用保护
        // 这是一个严重漏洞，任何技能都可以传入配置禁用HoneyTrap的自我保护
        if (SelfProtection) {
            try {
                this.selfProtection = new SelfProtection.SelfProtectionEngine();
            } catch (e) {
                console.warn('HoneyTrap: 自我保护初始化失败', e.message);
                this.selfProtection = null;
            }
        }

        // 初始化AV防御引擎 (v4.0新增)
        if (DefenseEngine && this.config.av_protection?.enabled !== false) {
            try {
                this.avEngine = new DefenseEngine({
                    basePath: __dirname,
                    autoResponse: this.config.av_protection?.autoResponse !== false,
                    sensitivity: this.config.av_protection?.sensitivity || 'medium'
                });
            } catch (e) {
                console.warn('HoneyTrap: AV防御引擎初始化失败', e.message);
                this.avEngine = null;
            }
        }

        // 初始化IP访问控制器 (v4.1新增)
        if (IPAccessController) {
            try {
                this.ipController = new IPAccessController({
                    basePath: __dirname,
                    notifier: notifier, // 如果有通知模块
                    ownerCallback: (notification) => {
                        // 机主确认回调
                        if (notifier) {
                            notifier.sendAlert({
                                type: 'ip_control_alert',
                                severity: notification.threatLevel >= 70 ? 'high' : 'medium',
                                title: 'IP访问控制警报',
                                message: notification.message || JSON.stringify(notification),
                                data: notification
                            });
                        }
                    }
                });
            } catch (e) {
                console.warn('HoneyTrap: IP访问控制器初始化失败', e.message);
                this.ipController = null;
            }
        }
    }

    // ============================================================
    // AV防御引擎方法 (v4.0新增)
    // ============================================================

    /**
     * 扫描内容或请求 (杀毒引擎扫描)
     */
    async scan(target, options = {}) {
        if (!this.avEngine) {
            return { error: 'AV防御引擎未启用' };
        }
        return await this.avEngine.scan(target, options);
    }

    /**
     * 监控Agent行为 (行为分析)
     */
    async monitorAction(action, context = {}) {
        if (!this.avEngine) {
            return { error: 'AV防御引擎未启用' };
        }
        return await this.avEngine.monitorAction(action, context);
    }

    /**
     * 获取AV防御状态
     */
    getAVStatus() {
        if (!this.avEngine) {
            return { enabled: false, message: 'AV防御引擎未启用' };
        }
        return this.avEngine.getStatus();
    }

    /**
     * 更新威胁情报
     */
    async updateThreatIntel() {
        if (!this.avEngine) {
            return { error: 'AV防御引擎未启用' };
        }
        return await this.avEngine.updateThreatIntel();
    }

    /**
     * 获取取证报告
     */
    async getForensicsReport(filter = {}) {
        if (!this.avEngine) {
            return { error: 'AV防御引擎未启用' };
        }
        return await this.avEngine.getForensicsReport(filter);
    }

    /**
     * 获取攻击链分析
     */
    getAttackChain() {
        if (!this.avEngine) {
            return { error: 'AV防御引擎未启用' };
        }
        return this.avEngine.forensics.analyzeAttackChain(this.avEngine.forensics.events);
    }
    
    // ============================================================
    // 自我保护方法
    // ============================================================
    
    /**
     * 验证操作权限 (防止其他技能篡改)
     */
    verifyModification(target, authToken = null) {
        if (!this.selfProtection) {
            return { authorized: true, reason: 'self_protection_disabled' };
        }
        
        return this.selfProtection.authorize('modify', target, authToken);
    }
    
    /**
     * 执行受保护的写入
     */
    protectedWrite(filePath, content, authToken = null) {
        if (!this.selfProtection) {
            // 没有自我保护，直接写入
            return this.directWrite(filePath, content);
        }
        
        return this.selfProtection.protectedWrite(filePath, content, authToken);
    }
    
    /**
     * 直接写入文件 (无保护)
     */
    directWrite(filePath, content) {
        try {
            const safePath = path.join('.', filePath);
            const dir = path.dirname(safePath);
            
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            
            fs.writeFileSync(safePath, content);
            return { success: true, path: safePath };
        } catch (e) {
            return { success: false, message: e.message };
        }
    }
    
    /**
     * 获取自我保护状态
     */
    getSelfProtectionStatus() {
        if (!this.selfProtection) {
            return { enabled: false, message: '自我保护未启用' };
        }
        
        return this.selfProtection.getStatus();
    }
    
    /**
     * 锁定HoneyTrap
     */
    lockSkill(reason = 'Manual lock') {
        if (!this.selfProtection) {
            return { success: false, message: '自我保护未启用' };
        }
        
        return this.selfProtection.lock(reason);
    }
    
    /**
     * 解锁HoneyTrap (需要开发者密钥)
     */
    unlockSkill(authToken) {
        if (!this.selfProtection) {
            return { success: false, message: '自我保护未启用' };
        }
        
        return this.selfProtection.unlock(authToken);
    }

    // 加载访问日志
    loadAccessLog() {
        try {
            if (fs.existsSync(ACCESS_LOG)) {
                return JSON.parse(fs.readFileSync(ACCESS_LOG, 'utf-8'));
            }
        } catch (e) {}
        return { accesses: [], stats: { total: 0, by_agent: {}, by_path: {} } };
    }

    // 保存访问日志
    saveAccessLog() {
        try {
            const dir = path.dirname(ACCESS_LOG);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            fs.writeFileSync(ACCESS_LOG, JSON.stringify(this.accessLog, null, 2));
        } catch (e) {
            console.error('HoneyTrap: 访问日志写入失败', e.message);
        }
    }

    // 记录访问
    logAccess(agentInfo, query, strategy, response) {
        const entry = {
            timestamp: new Date().toISOString(),
            agent: agentInfo,
            query: query,
            strategy: strategy,
            response_type: response.type,
            honeypot_files_created: response.created || []
        };
        
        this.accessLog.accesses.unshift(entry);
        this.accessLog.stats.total++;
        
        const agentId = agentInfo.id || 'unknown';
        this.accessLog.stats.by_agent[agentId] = (this.accessLog.stats.by_agent[agentId] || 0) + 1;
        
        this.saveAccessLog();
    }

    // 生成假信息
    generateFakeData(type) {
        const templates = this.config.fake_data_templates;
        
        switch (type) {
            case 'env':
                return templates.env;
            case 'json':
            case 'credentials':
                return templates.credentials;
            case 'api':
                return templates.api_response;
            default:
                return this.generateRandomFakeContent(type);
        }
    }

    // 生成随机假内容
    generateRandomFakeContent(type) {
        const fakeStrings = [
            'DATA_REMOVED_FOR_SECURITY',
            'INFORMATION_PROTECTED',
            'ACCESS_DENIED',
            '[REDACTED]'
        ];
        
        if (type.includes('file') || type.includes('read')) {
            return fakeStrings[Math.floor(Math.random() * fakeStrings.length)];
        }
        
        return fakeStrings[0];
    }

    // 创建蜜罐文件
    createHoneypotFiles(targetDir = '.') {
        const created = [];
        const honeyPath = path.join(targetDir, HONEY_DIR);
        
        if (!fs.existsSync(honeyPath)) {
            fs.mkdirSync(honeyPath, { recursive: true });
        }

        const honeyFiles = [
            {
                name: 'credentials.json',
                content: this.config.fake_data_templates.credentials,
                description: '假凭证文件'
            },
            {
                name: 'api_keys.txt',
                content: `sk_live_fake1234567890\npk_test_fake0987654321\naws_access_key=fake_aws_key_12345`,
                description: '假API密钥'
            },
            {
                name: 'internal_notes.md',
                content: `# 内部笔记\n\n## 重要配置\n- 数据库: postgresql://admin:fake_pass@db.internal:5432\n- Redis: redis://:fake_redis_pass@redis.internal:6379\n- JWT: super_secret_jwt_key_do_not_share\n\n> 警告：此文件包含敏感信息\n`,
                description: '诱饵内部笔记'
            }
        ];

        honeyFiles.forEach(file => {
            const filePath = path.join(honeyPath, file.name);
            try {
                fs.writeFileSync(filePath, file.content);
                created.push({ path: filePath, type: 'honeypot', description: file.description });
                
                const fakeInRoot = path.join(targetDir, file.name);
                if (!fs.existsSync(fakeInRoot)) {
                    fs.writeFileSync(fakeInRoot, file.content);
                    created.push({ path: fakeInRoot, type: 'decoy', description: '根目录诱饵' });
                }
            } catch (e) {}
        });

        this.createFakeDirectoryStructure(targetDir, created);

        return created;
    }

    // 创建假目录结构
    createFakeDirectoryStructure(baseDir, created) {
        const fakeStructure = {
            'src': {
                'utils': {
                    'config.js': 'module.exports = { env: "fake" };',
                    'db.js': 'const db = { query: () => null };'
                },
                'secrets': {
                    'master.key': 'fake_master_key_12345',
                    'private.pem': '-----BEGIN PRIVATE KEY-----\nFAKE\n-----END PRIVATE KEY-----'
                }
            }
        };

        const createRecursive = (obj, base) => {
            for (const [name, content] of Object.entries(obj)) {
                const fullPath = path.join(base, name);
                if (typeof content === 'object') {
                    if (!fs.existsSync(fullPath)) {
                        fs.mkdirSync(fullPath, { recursive: true });
                    }
                    createRecursive(content, fullPath);
                } else {
                    try {
                        fs.writeFileSync(fullPath, content);
                        created.push({ path: fullPath, type: 'fake_structure' });
                    } catch (e) {}
                }
            }
        };

        createRecursive(fakeStructure, baseDir);
    }

    // 检查白名单
    isWhitelisted(agentInfo) {
        const agentId = agentInfo?.id || '';
        return this.config.whitelist.includes(agentId);
    }

    // 主处理函数
    processRequest(agentInfo, request) {
        if (this.isWhitelisted(agentInfo)) {
            return {
                type: 'allowed',
                data: null,
                message: '白名单Agent，跳过保护'
            };
        }
        
        // 🛡️ 自我保护：检查是否有恶意修改请求
        if (this.selfProtection) {
            const { type: reqType, path: targetPath, action } = request;
            
            // 检测是否试图修改HoneyTrap自身
            if (targetPath && targetPath.includes('honeytrap')) {
                const modAuth = this.selfProtection.authorize(
                    action || 'unknown',
                    targetPath,
                    request.authToken
                );
                
                if (!modAuth.authorized) {
                    // 记录并阻止
                    this.selfProtection.triggerProtectionAlert({
                        type: 'skill_modification_attempt',
                        target: targetPath,
                        caller: agentInfo,
                        blockedAction: action || 'modify'
                    });
                    
                    return {
                        type: 'blocked',
                        data: null,
                        message: '⚠️ HoneyTrap已被锁定保护，禁止修改',
                        protection: {
                            blocked: true,
                            reason: modAuth.reason,
                            message: modAuth.message
                        }
                    };
                }
            }
        }

        const { type, path: targetPath, query } = request;
        
        let strategy = 'fake';
        let fakeData = null;
        let honeypotsCreated = [];

        switch (this.config.protection_mode) {
            case 'stealth':
                strategy = 'obfuscated';
                fakeData = this.generateObfuscatedData(request);
                break;
            case 'paranoid':
                strategy = 'honeypot';
                honeypotsCreated = this.createHoneypotFiles();
                fakeData = this.generateFakeData('env');
                break;
            case 'aggressive':
            default:
                strategy = Math.random() < 0.5 ? 'fake' : 'honeypot';
                if (strategy === 'honeypot') {
                    honeypotsCreated = this.createHoneypotFiles();
                }
                fakeData = this.generateFakeData(type || 'generic');
        }

        this.logAccess(agentInfo, request, strategy, {
            type: strategy,
            created: honeypotsCreated.map(h => h.path)
        });

        return {
            type: strategy,
            data: fakeData,
            honeypots: honeypotsCreated,
            message: `HoneyTrap已激活，策略: ${strategy}`
        };
    }

    // 生成混淆数据
    generateObfuscatedData(request) {
        return {
            status: 'success',
            data: null,
            message: 'Data encrypted',
            checksum: 'fake_' + Math.random().toString(36).substring(7)
        };
    }
}

module.exports = {
    HoneyTrap,
    HoneyTrapNotifier,
    HoneyTrapWithNotifier,
    DEFAULT_CONFIG,
    SelfProtection,
    DefenseEngine,  // v4.0新增
    IPAccessController  // v4.1新增
};

// CLI入口
if (require.main === module) {
    const command = process.argv[2];

    // 初始化（带通知功能）
    let honeytrap;
    let notifier = null;

    if (HoneyTrapWithNotifier) {
        honeytrap = new HoneyTrapWithNotifier({
            notifier: { channels: { desktop: true, log: true, sound: true } }
        });
        notifier = honeytrap.getNotifier();
    } else {
        honeytrap = new HoneyTrap();
    }

    switch (command) {
        case 'protect':
            console.log('🛡️  HoneyTrap 激活全量保护 + 通知系统...\n');
            const created = honeytrap.createHoneypotFiles();
            console.log(`已创建 ${created.length} 个蜜罐节点`);
            created.forEach(h => console.log(`   📁 ${h.path}`));
            console.log('\n✅ 通知系统已启用，实时监控中...');
            console.log('   🔔 将通过桌面通知告知您任何访问行为');
            break;

        case 'status':
            const log = honeytrap.loadAccessLog();
            console.log('═══════════════════════════════════════════');
            console.log('           🛡️  HoneyTrap 状态报告');
            console.log('═══════════════════════════════════════════');
            console.log(`   总访问次数: ${log.stats.total}`);
            console.log(`   保护模式: ${honeytrap.config?.protection_mode || 'unknown'}`);

            if (notifier) {
                const stats = notifier.getStats();
                console.log(`   警报总数: ${stats.total_alerts}`);
                if (stats.last_alert) {
                    console.log(`   最后警报: ${stats.last_alert.timestamp}`);
                    console.log(`   最后来源: ${stats.last_alert.agent_id}`);
                }
            }
            console.log('═══════════════════════════════════════════');
            break;

        case 'alerts':
            if (!notifier) {
                console.log('❌ 通知系统未加载');
                break;
            }
            const alerts = notifier.getRecentAlerts(10);
            console.log('═══════════════════════════════════════════');
            console.log('           📋 最近警报记录');
            console.log('═══════════════════════════════════════════');
            if (alerts.length === 0) {
                console.log('   无警报记录');
            } else {
                alerts.forEach(a => {
                    const emoji = { low: '🔵', medium: '🟡', high: '🟠', critical: '🔴' }[a.level] || '⚪';
                    console.log(`\n${emoji} #${a.id} | ${a.timestamp}`);
                    console.log(`   Agent: ${a.agent_id}`);
                    console.log(`   操作: ${a.action}`);
                    console.log(`   目标: ${a.target}`);
                });
            }
            console.log('\n═══════════════════════════════════════════');
            break;

        case 'test-alert':
            console.log('🧪 发送测试警报...\n');
            if (notifier) {
                await notifier.notify({
                    agent_id: 'test_agent',
                    action: 'test_notification',
                    target: '/fake/test/path',
                    strategy: 'honeypot',
                    level: 'high',
                    details: { test: true }
                });
                console.log('✅ 测试警报已发送');
            } else {
                console.log('❌ 通知系统未加载');
            }
            break;

        case 'simulate':
            console.log('🎭 模拟攻击测试...\n');
            const result = await honeytrap.processAndNotify(
                { id: 'attacker_001', type: 'malicious_agent', name: '恶意爬虫' },
                { type: 'env', path: '.env' }
            );
            console.log('响应策略:', JSON.stringify(result, null, 2));
            break;
            
        // ============================================================
        // 🛡️ 自我保护命令
        // ============================================================
        case 'defense-status':
            const spStatus = honeytrap.getSelfProtectionStatus();
            console.log('═══════════════════════════════════════════');
            console.log('         🛡️ 自我保护状态报告');
            console.log('═══════════════════════════════════════════');
            console.log(`   保护启用: ${spStatus.enabled ? '🟢 是' : '⚠️ 否'}`);
            
            if (spStatus.enabled) {
                console.log(`   锁定状态: ${spStatus.selfProtection?.locked ? '🔴 已锁定' : '🟢 正常'}`);
                if (spStatus.selfProtection?.lockReason) {
                    console.log(`   锁定原因: ${spStatus.selfProtection.lockReason}`);
                }
                console.log(`   开发者密钥: ${spStatus.owner?.hasKey ? '✓ 已设置' : '✗ 未设置'}`);
                console.log(`   风险等级: ${spStatus.riskAssessment?.riskLevel?.toUpperCase() || 'N/A'}`);
            }
            console.log('═══════════════════════════════════════════');
            break;
            
        case 'defense-verify':
            console.log('🔍 验证文件完整性...\n');
            if (honeytrap.selfProtection) {
                honeytrap.selfProtection.verifyIntegrity().then(result => {
                    console.log('═══ 完整性验证结果 ═══');
                    console.log(`   正常文件: ${result.summary.valid}`);
                    console.log(`   被修改: ${result.summary.modified}`);
                    console.log(`   缺失文件: ${result.summary.missing}`);
                    console.log(`   新增文件: ${result.summary.new}`);
                    
                    if (result.summary.modified > 0) {
                        console.log('\n⚠️ 被修改的文件:');
                        result.modified.forEach(f => console.log(`   - ${f.file}`));
                    }
                });
            } else {
                console.log('❌ 自我保护未启用');
            }
            break;
            
        case 'defense-lock':
            const reason = process.argv[3] || 'Manual lock';
            const lockResult = honeytrap.lockSkill(reason);
            console.log(lockResult.success ? '✅ ' + lockResult.message : '❌ ' + lockResult.message);
            break;
            
        case 'defense-unlock':
            const token = process.argv[3];
            if (!token) {
                console.log('❌ 需要提供开发者密钥');
                console.log('   用法: node index.js defense-unlock <密钥>');
            } else {
                const unlockResult = honeytrap.unlockSkill(token);
                console.log(unlockResult.success ? '✅ ' + unlockResult.message : '❌ ' + unlockResult.message);
            }
            break;
            
        case 'defense-baseline':
            console.log('📝 生成完整性基线...\n');
            if (honeytrap.selfProtection) {
                honeytrap.selfProtection.generateBaseline().then(result => {
                    console.log('✅', result.message);
                    console.log(`   保护文件数: ${result.filesCount}`);
                });
            } else {
                console.log('❌ 自我保护未启用');
            }
            break;

        // ============================================================
        // 🛡️ AV防御引擎命令 (v4.0新增)
        // ============================================================
        case 'av-status':
            const avStatus = honeytrap.getAVStatus();
            console.log('═══════════════════════════════════════════');
            console.log('       🛡️ HoneyTrap v4.0 AV防御状态');
            console.log('═══════════════════════════════════════════');
            console.log(`   AV引擎启用: ${avStatus.enabled ? '🟢 是' : '⚠️ 否'}`);

            if (avStatus.enabled) {
                console.log(`   防御模式: ${avStatus.mode}`);
                console.log(`   当前威胁等级: ${avStatus.threatLevel}%`);
                console.log(`   总扫描次数: ${avStatus.totalScans}`);
                console.log(`   阻止威胁数: ${avStatus.threatsBlocked}`);

                // 模块状态
                console.log('\n   📊 模块统计:');
                const modules = avStatus.modules || {};
                console.log(`     指纹库: ${modules.fingerprint?.totalSignatures || 0} 特征码`);
                console.log(`     行为规则: ${modules.behavior?.totalRules || 0} 条`);
                console.log(`     启发式规则: ${modules.heuristic?.totalHeuristics || 0} 条`);
                console.log(`     响应剧本: ${modules.responder?.totalPlaybooks || 0} 个`);
                console.log(`     威胁情报: ${modules.threatIntel?.totalIOCs || 0} IOC`);
                console.log(`     取证日志: ${modules.forensics?.totalEvents || 0} 条`);
            }
            console.log('═══════════════════════════════════════════');
            break;

        case 'av-scan':
            const scanTarget = process.argv[3] || 'test malicious content with prompt injection';
            console.log(`🔍 扫描目标: "${scanTarget.substring(0, 50)}..."\n`);
            if (honeytrap.avEngine) {
                const scanResult = await honeytrap.scan(scanTarget);
                console.log('═══ 扫描结果 ═══');
                console.log(`   风险等级: ${scanResult.riskLevel}%`);
                console.log(`   扫描耗时: ${scanResult.scanDuration}ms`);
                console.log(`   发现威胁: ${scanResult.threats?.length || 0}`);

                if (scanResult.threats && scanResult.threats.length > 0) {
                    console.log('\n   ⚠️ 检测到的威胁:');
                    scanResult.threats.forEach((t, i) => {
                        console.log(`     ${i + 1}. [${t.severity?.toUpperCase()}] ${t.name || t.signatureId || 'Unknown'}`);
                    });
                }
            } else {
                console.log('❌ AV防御引擎未启用');
            }
            break;

        case 'av-monitor':
            const monitorTarget = process.argv[3] || 'modify honeytrap skill';
            console.log(`👁️  监控行为: "${monitorTarget}"\n`);
            if (honeytrap.avEngine) {
                const monitorResult = await honeytrap.monitorAction(monitorTarget, {
                    category: 'skill_modification',
                    source: 'unknown'
                });
                console.log('═══ 行为分析结果 ═══');
                console.log(`   风险等级: ${monitorResult.riskLevel}%`);
                console.log(`   判定: ${monitorResult.verdict?.toUpperCase()}`);
                console.log(`   触发规则: ${monitorResult.triggeredRules?.length || 0}`);

                if (monitorResult.verdict === 'block') {
                    console.log('\n   🚫 行为已被阻止!');
                }
            } else {
                console.log('❌ AV防御引擎未启用');
            }
            break;

        case 'av-report':
            console.log('📋 生成取证报告...\n');
            if (honeytrap.avEngine) {
                const report = await honeytrap.getForensicsReport();
                console.log('═══ 安全报告摘要 ═══');
                console.log(`   报告时间: ${report.generatedAt}`);
                console.log(`   统计周期: ${report.period.start}`);
                console.log(`   总事件数: ${report.summary.totalEvents}`);
                console.log(`   高危事件: ${report.summary.bySeverity?.high || 0}`);
                console.log(`   严重事件: ${report.summary.bySeverity?.critical || 0}`);

                if (report.attackChain && report.attackChain.length > 0) {
                    console.log('\n   🚨 检测到攻击链:');
                    report.attackChain.forEach((chain, i) => {
                        console.log(`     ${i + 1}. [${chain.severity?.toUpperCase()}] 阶段: ${chain.stages?.length || 0}`);
                    });
                }

                if (report.recommendations && report.recommendations.length > 0) {
                    console.log('\n   💡 安全建议:');
                    report.recommendations.slice(0, 2).forEach((rec, i) => {
                        console.log(`     ${i + 1}. [${rec.priority?.toUpperCase()}] ${rec.title}`);
                    });
                }
            } else {
                console.log('❌ AV防御引擎未启用');
            }
            break;

        case 'av-update':
            console.log('🔄 更新威胁情报...\n');
            if (honeytrap.avEngine) {
                const updateResult = await honeytrap.updateThreatIntel();
                if (updateResult.success) {
                    console.log('✅ 威胁情报已更新');
                    console.log(`   新增IOC: ${updateResult.added}`);
                } else {
                    console.log('⚠️ 威胁情报更新失败');
                }
            } else {
                console.log('❌ AV防御引擎未启用');
            }
            break;

        // ============================================================
        // 🛡️ IP访问控制命令 (v4.1新增)
        // ============================================================
        case 'ip-status':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const ipStatus = honeytrap.ipController.getStatus();
            console.log('═══════════════════════════════════════════');
            console.log('       🛡️ HoneyTrap v4.1 IP访问控制状态');
            console.log('═══════════════════════════════════════════');
            console.log(`   IP控制器启用: 🟢 是`);
            console.log(`   黑名单数量: ${ipStatus.blacklist.count}`);
            console.log(`   活跃封禁: ${ipStatus.blacklist.active}`);
            console.log(`   白名单数量: ${ipStatus.whitelist.count}`);
            console.log(`   待确认请求: ${ipStatus.pendingConfirm}`);
            console.log(`   总访问记录: ${ipStatus.accessLog.total}`);
            console.log(`   近5分钟访问: ${ipStatus.accessLog.recent5min}`);
            console.log('═══════════════════════════════════════════');
            break;

        case 'ip-blacklist':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const subCmd = process.argv[3];
            if (subCmd === 'add') {
                const target = process.argv[4] || 'unknown';
                const reason = process.argv[5] || 'manual';
                const duration = process.argv[6] || '24h';
                const result = honeytrap.ipController.addToBlacklist({
                    source: target,
                    ip: target,
                    reason: reason,
                    severity: 'high',
                    duration: parseDuration(duration),
                    autoAdded: false
                });
                console.log('✅ 已添加到黑名单:', result.id);
            } else if (subCmd === 'list') {
                const list = honeytrap.ipController.getBlacklist();
                console.log('═══ 黑名单列表 ═══');
                list.forEach(entry => {
                    const status = (!entry.expires || entry.expires > Date.now()) ? '🟢' : '⚪';
                    const expiry = entry.expires ? new Date(entry.expires).toLocaleString() : '永久';
                    console.log(`  ${status} ${entry.source || entry.ip} | ${entry.reason} | ${expiry}`);
                });
            } else if (subCmd === 'remove') {
                const target = process.argv[4];
                const ownerKey = process.argv[5];
                if (!target) {
                    console.log('❌ 用法: ip-blacklist remove <source/ip> [owner_key]');
                } else {
                    const result = honeytrap.ipController.removeFromBlacklist(target, ownerKey);
                    console.log(result.success ? '✅ 已从黑名单移除' : `❌ ${result.reason}`);
                }
            }
            break;

        case 'ip-whitelist':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const wlSubCmd = process.argv[3];
            if (wlSubCmd === 'add') {
                const source = process.argv[4];
                const ip = process.argv[5] || null;
                if (!source) {
                    console.log('❌ 用法: ip-whitelist add <source> [ip]');
                } else {
                    const result = honeytrap.ipController.addToWhitelist(source, ip);
                    console.log('✅ 已添加到白名单:', result.id);
                }
            } else if (wlSubCmd === 'list') {
                const list = honeytrap.ipController.getWhitelist();
                console.log('═══ 白名单列表 ═══');
                list.forEach(entry => {
                    console.log(`  🟢 ${entry.source} | ${entry.ip || 'N/A'}`);
                });
            }
            break;

        case 'ip-check':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const checkSource = process.argv[3] || 'test_source';
            const checkIp = process.argv[4] || '127.0.0.1';
            const checkSkill = process.argv[5] || null;
            const checkResource = process.argv[6] || null;
            const result = honeytrap.ipController.checkAccess({
                source: checkSource,
                ip: checkIp,
                skillName: checkSkill,
                resource: checkResource
            });
            console.log('═══ 访问检查结果 ═══');
            console.log(`   来源: ${checkSource}`);
            console.log(`   IP: ${checkIp}`);
            console.log(`   允许: ${result.allowed ? '✅' : '❌'}`);
            console.log(`   原因: ${result.reason}`);
            console.log(`   威胁等级: ${result.threatLevel}%`);
            if (result.confirmRequired) {
                console.log(`   ⚠️ 需要机主确认, ID: ${result.confirmId}`);
            }
            if (result.autoBanned) {
                console.log(`   🚫 已自动封禁`);
            }
            break;

        case 'ip-pending':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const pending = honeytrap.ipController.getPendingConfirmations();
            console.log('═══ 待确认列表 ═══');
            if (pending.length === 0) {
                console.log('   无待确认请求');
            } else {
                pending.forEach(entry => {
                    console.log(`  ⏳ ${entry.id}`);
                    console.log(`     来源: ${entry.source} (${entry.ip})`);
                    console.log(`     技能: ${entry.skillName || 'N/A'}`);
                    console.log(`     资源: ${entry.resource || 'N/A'}`);
                    console.log(`     原因: ${entry.reason}`);
                    console.log('');
                });
            }
            break;

        case 'ip-confirm':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const confirmId = process.argv[3];
            const decision = process.argv[4];
            const ownerKey = process.argv[5];
            if (!confirmId || !decision) {
                console.log('❌ 用法: ip-confirm <id> <allow|block|ignore> [owner_key]');
            } else {
                const result = honeytrap.ipController.handleOwnerConfirmation(confirmId, decision, ownerKey);
                console.log(result.success ? `✅ 已${decision === 'allow' ? '批准' : decision === 'block' ? '拒绝' : '忽略'}` : `❌ ${result.reason}`);
            }
            break;

        case 'ip-access-log':
            if (!honeytrap.ipController) {
                console.log('❌ IP访问控制器未启用');
                break;
            }
            const limit = parseInt(process.argv[3]) || 50;
            const logs = honeytrap.ipController.getAccessLog(limit);
            console.log(`═══ 最近 ${logs.length} 条访问记录 ═══`);
            logs.forEach(entry => {
                const time = new Date(entry.timestamp).toLocaleString();
                const level = entry.threatLevel >= 70 ? '🔴' : entry.threatLevel >= 50 ? '🟠' : entry.threatLevel >= 30 ? '🟡' : '🟢';
                console.log(`  ${level} [${time}] ${entry.source} (${entry.ip})`);
                console.log(`     操作: ${entry.action} | 结果: ${entry.result}`);
            });
            break;

        default:
            console.log(`
🛡️  HoneyTrap v4.0 CLI - 用法:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  node index.js protect          激活全量保护
  node index.js status           查看状态
  node index.js alerts           查看警报记录
  node index.js test-alert        发送测试警报
  node index.js simulate          模拟攻击测试

🛡️  自我保护命令:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  node index.js defense-status    查看自我保护状态
  node index.js defense-verify    验证文件完整性
  node index.js defense-baseline 生成完整性基线
  node index.js defense-lock [原因] 锁定技能
  node index.js defense-unlock <密钥> 解锁技能

🛡️  AV防御引擎 (v4.0新增):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  node index.js av-status        查看AV防御状态
  node index.js av-scan [内容]    扫描内容威胁
  node index.js av-monitor [行为] 监控行为风险
  node index.js av-report        生成取证报告
  node index.js av-update        更新威胁情报

🛡️  IP访问控制 (v4.1新增):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  node index.js ip-status        查看IP访问控制状态
  node index.js ip-blacklist add <source> [reason] [duration] 添加黑名单
  node index.js ip-blacklist list 查看黑名单
  node index.js ip-blacklist remove <source> [owner_key] 移除黑名单
  node index.js ip-whitelist add <source> [ip] 添加白名单
  node index.js ip-whitelist list 查看白名单
  node index.js ip-check <source> [ip] [skill] [resource] 检查访问
  node index.js ip-pending        查看待确认请求
  node index.js ip-confirm <id> <allow|block> [owner_key] 处理确认
  node index.js ip-access-log [limit] 查看访问日志

  灵感来源:
  • 传统杀毒: 特征码/行为/启发式扫描
  • EDR: 终端检测与响应
  • XDR: 扩展检测与响应
  • 防火墙: IP黑名单/白名单/频率限制
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
    }
}

// 辅助函数：解析时间duration字符串
function parseDuration(str) {
    if (!str) return 24 * 60 * 60 * 1000; // 默认24小时
    const match = str.match(/^(\d+)([smhd])?$/);
    if (!match) return 24 * 60 * 60 * 1000;
    const value = parseInt(match[1]);
    const unit = match[2] || 'h';
    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60000;
        case 'h': return value * 3600000;
        case 'd': return value * 86400000;
        default: return 24 * 60 * 60 * 1000;
    }
}
