---
name: honeytrap
description: >
  HoneyTrap v4.2 - 企业级AI Agent安全防御技能。基于传统杀毒软件、现代XDR/EDR架构和防火墙设计。
  当检测到外部Agent/代码尝试访问本地敏感信息时，自动生成假信息、创建蜜罐、消耗攻击者资源，
  并提供企业级威胁检测、行为分析、自动响应、取证分析和IP访问控制能力。

  灵感来源:
  - 传统杀毒软件: 特征码扫描、行为监控、启发式分析
  - EDR终端检测: 行为分析、攻击链追踪、取证分析
  - XDR扩展检测: 多源关联、AI智能分析、自动化响应
  - 防火墙: IP黑名单/白名单、访问控制、频率限制、机主确认

  触发词：反制、防爬取、信息保护、假信息、蜜罐、欺骗防御、反侦察、
  信息混淆、保护隐私、发现攻击、honeypot、deception、
  被入侵、异常访问、攻击检测、指纹分析、时间陷阱、假服务、
  Agent防御、提示词注入防御、记忆投毒检测、技能保护、自我防御、
  技能被修改、禁止修改、锁定技能、杀毒扫描、查杀病毒、扫描威胁、
  威胁检测、行为监控、启发式扫描、取证分析、威胁情报、av-scan、av-status、
  IP封禁、禁止IP、封锁访问、黑名单、白名单、访问控制、频率限制
triggers:
  - 反制
  - 防爬取
  - 信息保护
  - 假信息
  - 蜜罐
  - 欺骗防御
  - 反侦察
  - 信息混淆
  - 保护隐私
  - 有人访问
  - 有人读取
  - 发现攻击
  - honeypot
  - deception
  - 被入侵
  - 异常访问
  - 攻击检测
  - fingerprint
  - 时间陷阱
  - 假服务
  - Agent防御
  - 提示词注入
  - 记忆投毒
  - OWASP
  - LLM安全
  - 技能保护
  - 自我防御
  - 技能被修改
  - 禁止修改
  - 锁定技能
  - unlock honeypot
  - skill protection
  # v4.0新增触发词
  - 杀毒扫描
  - 病毒扫描
  - 安全扫描
  - 威胁检测
  - 行为监控
  - 启发式扫描
  - 取证分析
  - 威胁情报
  - av-scan
  - av-status
  - av-report
  # v4.1新增触发词
  - IP封禁
  - 禁止IP
  - 封锁访问
  - 黑名单
  - 白名单
  - 访问控制
  - 频率限制
  - IP黑名单
  - IP白名单
  - 禁止访问
  - 允许访问
  - 封禁IP
  - 解封IP
  - 查看访问记录
author: WorkBuddy Security Team
version: 4.1.0
tags:
  - security
  - defense
  - honeypot
  - agent-protection
  - llm-security
  - owasp
  - self-protection
  - antivirus
  - edr
  - xdr
  - threat-detection
  - forensics
  - firewall
  - ip-control
  - access-control
---

# HoneyTrap v4.0 - 企业级AI Agent安全防御系统

## 简介

**HoneyTrap v4.0** 是一款企业级AI Agent安全防御系统，灵感来源于传统杀毒软件和现代终端安全技术。

> 传统杀毒软件通过特征码、行为监控和启发式扫描保护计算机安全。
> HoneyTrap将这套成熟的安全架构现代化，为AI Agent提供同等强度的保护。

### 核心架构

```
┌─────────────────────────────────────────────────────────────┐
│                    HoneyTrap v4.0 架构                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │              三层检测体系                               │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐     │ │
│  │  │ 静态扫描     │ │ 动态分析     │ │ 启发式检测   │     │ │
│  │  │ 指纹识别     │ │ 行为监控     │ │ 风险评分     │     │ │
│  │  │ (特征码库)   │ │ (主动防御)   │ │ (启发式引擎) │     │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘     │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │              四层防御体系                               │ │
│  │  指纹识别 → 行为监控 → 风险评分 → 自动响应              │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │              五大核心能力                               │ │
│  │  感知(Sense) → 分析(Analyze) → 决策(Decide) →         │ │
│  │  响应(Respond) → 取证(Forensic)                       │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 简介

**HoneyTrap** 是一个专业的AI Agent安全防御技能。当检测到外部代码/Agent尝试访问本地敏感信息时，自动采取反制措施：

1. 🔍 **攻击检测** - 识别攻击者指纹，评估威胁等级
2. 🎭 **反制响应** - 假信息、蜜罐、时间陷阱、拒绝等多种策略
3. 🔔 **实时通知** - 桌面通知 + 日志 + Webhook 告知机主
4. 🛡️ **自我保护** - 防止其他技能篡改HoneyTrap (v3.1新增)

> ⚠️ **用途声明**：本技能仅用于**防御性场景**，保护AI Agent的本地知识不被恶意爬取。禁止用于欺骗人类用户或任何恶意目的。

---

## 核心功能

### 1. 攻击指纹分析

自动分析攻击者特征并评估威胁等级：

| 攻击者类型 | 特征标识 | 风险等级 |
|-----------|---------|---------|
| 自动化爬虫 | curl, wget, scrapy, bot | Medium |
| 手动黑客 | Mozilla, Chrome | High |
| 恶意Agent | agent, ChatGPT, AI | Critical |
| 提示词注入 | `[INST]`, `\n\nHuman:` | Critical |

### 2. 反制策略引擎

根据攻击类型和风险评分智能选择策略：

```
威胁评分:
  0-30:  fake_data  (假数据)
  31-50: time_trap  (时间陷阱)
  51-70: honeypot   (蜜罐)
  71-90: combo      (组合策略)
  91+:  deny        (直接拒绝)
```

### 3. 蜜罐生成器

根据攻击类型实时生成定制化诱饵：

| 攻击类型 | 生成的诱饵 |
|---------|-----------|
| 凭证收割 | AWS密钥、数据库配置、NPM令牌 |
| API探测 | 假API端点、误导性响应 |
| 数据库探测 | 假数据库架构、连接配置 |
| SSH扫描 | 假私钥、SSH配置文件 |

### 4. 时间陷阱

故意延迟响应以消耗攻击者资源：
- 延迟范围: 100ms - 5000ms (安全上限)
- 高斯抖动避免规律性检测
- 记录浪费的总时间

### 5. 高级Agent防御 (v3.0新增)

| 防御模块 | 功能 |
|---------|------|
| `ChainAttackDefense` | 多Agent链式攻击防御 |
| `MemoryPoisoningDefense` | 记忆投毒检测与净化 |
| `IndirectInjectionDefense` | 间接提示注入扫描 |
| `ToolAbuseProtection` | 工具滥用防护 |
| `ShadowAgentDetector` | 影子Agent检测 |

### 6. 机主通知系统

**实时警报，秒级响应：**

| 通知渠道 | 说明 |
|---------|------|
| 桌面通知 | Windows Toast弹出窗口 |
| 警报日志 | `.honeytrap/alerts.log` 持久化 |
| Webhook | Slack/DingTalk回调 (白名单验证) |

### 7. AV防御引擎 (v4.0新增)

基于传统杀毒软件和现代XDR/EDR架构设计的威胁检测与响应系统：

#### 7.1 攻击指纹库 (AttackFingerprint)

灵感来源：传统杀毒软件特征码技术

| 功能 | 说明 |
|------|------|
| 特征码扫描 | 15+ 预定义攻击特征码 |
| YARA规则 | 5+ 复合攻击规则 |
| IOC情报 | 威胁情报库 |
| 哈希黑名单 | 恶意内容哈希 |

**支持的攻击类型：**
- 提示词注入 (Prompt Injection)
- 上下文操纵 (Context Manipulation)
- 凭证窃取 (Credential Extraction)
- 权限提升 (Privilege Escalation)
- 社会工程学 (Social Engineering)
- 代码注入 (Code Injection)

#### 7.2 行为监控引擎 (BehaviorMonitor)

灵感来源：传统杀毒软件主动防御技术 (RING3 API Hook)

| 规则类型 | 规则数量 |
|---------|---------|
| 文件操作规则 | 4 条 |
| 进程操作规则 | 4 条 |
| 网络操作规则 | 3 条 |
| 注册表操作规则 | 2 条 |
| Agent特定规则 | 4 条 |
| 权限操作规则 | 2 条 |
| 数据操作规则 | 2 条 |

#### 7.3 启发式检测引擎 (HeuristicEngine)

灵感来源：传统杀毒软件启发式扫描技术

| 分析类型 | 规则数量 | 说明 |
|---------|---------|------|
| 结构分析 | 3 条 | 字符编码、字符串长度、分隔符模式 |
| 语义分析 | 4 条 | 指令混淆、反检测技术、社会工程学 |
| 上下文分析 | 3 条 | 上下文中断、权限异常、时间异常 |
| 组合分析 | 4 条 | 提示注入组合、多阶段攻击链等 |

#### 7.4 自动响应系统 (AutoResponder)

灵感来源：EDR/XDR/SOAR自动化响应技术

| 剧本名称 | 严重性 | 自动化动作 |
|---------|--------|----------|
| 技能文件篡改响应 | Critical | 阻止+备份+恢复+通知 |
| 提示注入攻击响应 | Critical | 阻止+清理+告警+日志 |
| 凭证提取攻击响应 | Critical | 阻止+告警+审计 |
| 权限提升攻击响应 | High | 阻止+告警 |
| 数据外传响应 | High | 阻止+隔离+告警 |
| 社会工程攻击响应 | Medium | 警告+日志 |
| 多阶段攻击链响应 | Critical | 阻止+取证 |

#### 7.5 威胁情报中心 (ThreatIntel)

灵感来源：杀毒软件云查杀 + 现代XDR威胁情报

| 情报类型 | 内容 |
|---------|------|
| IOC模式 | 3+ 恶意模式 |
| 恶意软件档案 | 5+ 已知攻击档案 |
| 攻击模式 | MITRE ATT&CK风格 |
| 哈希黑名单 | 支持扩展 |

**恶意软件档案：**
- Prompt Injection (提示注入攻击)
- Context Manipulation (上下文操纵)
- Credential Harvesting (凭证窃取)
- Data Exfiltration (数据外传)
- Skill Poisoning (技能投毒)

#### 7.6 取证分析模块 (Forensics)

灵感来源：EDR/XDR取证分析技术

| 功能 | 说明 |
|------|------|
| 事件日志 | 全量行为记录 |
| 攻击链分析 | MITRE ATT&CK风格 |
| 时间线分析 | 可视化威胁时间线 |
| 取证报告 | 生成安全报告 |
| 安全建议 | 智能防御建议 |

---

## 使用场景

| 场景 | 触发条件 | 响应策略 | 通知 |
|------|---------|---------|------|
| 文件扫描 | 批量文件读取 | 时间陷阱 + 蜜罐 | 🟠 高危 |
| 凭证窃取 | .env, credentials.json | 蜜罐 + 假数据 | 🔴 严重 |
| API探测 | 未知API调用 | 假服务响应 | 🟡 通知 |
| 提示词注入 | 恶意指令 | 直接拒绝 | 🔴 严重 |
| Agent冒充 | 检测到外部Agent | 组合防御 | 🔴 严重 |
| 目录遍历 | 路径越界访问 | 拒绝 + 警报 | 🟠 高危 |

---

## 代码调用

### JavaScript

```javascript
const { SecureHoneyTrap } = require('./src/secure_core.js');

// 初始化
const trap = new SecureHoneyTrap({
    protection_mode: 'aggressive'
});

// 处理攻击
const result = await trap.processAttack(
    { id: 'attacker_001', userAgent: 'curl/7.68.0' },
    { type: 'credential', path: '.env' }
);

// 获取报告
const report = trap.getReport();
```

### Python

```python
from src.agent_defense import AdvancedDefenseEngine

engine = AdvancedDefenseEngine()

# 综合分析
result = engine.analyze(content, context={
    'memory_request': True,      # 记忆请求检测
    'doc_type': 'pdf',           # 文档扫描
    'tool_call': {...},          # 工具调用验证
})
```

---

## CLI命令

### 基础命令

```bash
node index.js protect      # 激活全量保护
node index.js status       # 查看状态
node index.js alerts       # 查看警报记录
node index.js test-alert   # 发送测试警报
node index.js simulate     # 模拟攻击测试
node index.js report       # 生成详细报告
```

### 自我保护命令 (v3.1+)

```bash
node index.js defense-status      # 查看自我保护状态
node index.js defense-verify     # 验证文件完整性
node index.js defense-baseline    # 生成完整性基线
node index.js defense-lock [原因] # 锁定技能
node index.js defense-unlock <密钥>  # 解锁技能
```

### AV防御引擎命令 (v4.0新增)

```bash
node index.js av-status          # 查看AV防御状态
node index.js av-scan [内容]      # 扫描内容威胁
node index.js av-monitor [行为]  # 监控行为风险
node index.js av-report          # 生成取证报告
node index.js av-update          # 更新威胁情报
```

### Python测试命令 (无需Node.js)

```bash
python test_av_defense.py        # 运行AV防御测试
```

---

## 配置选项

```yaml
# 保护模式
protection_mode: "aggressive"  # aggressive / stealth / paranoid

# 蜜罐文件列表
honey_files:
  - credentials.json
  - api_keys.txt
  - .env
  - .env.production

# 白名单Agent
whitelist:
  - trusted-agent-id-001

# 时间陷阱配置
time_trap:
  enabled: true
  min_delay_ms: 100
  max_delay_ms: 3000  # 最大不超过5000ms

# 通知配置
notifier:
  channels:
    desktop: true     # 桌面通知
    log: true         # 日志记录
    webhook: false    # Webhook回调
  webhook_url: ""     # Webhook地址 (仅白名单URL)
```

---

## 安全特性

| 特性 | 说明 |
|------|------|
| 路径遍历防护 | 蜜罐目录隔离，禁止 `..` 遍历 |
| SSRF防护 | Webhook URL白名单验证 |
| 内存限制 | 历史记录最大10000条 |
| ReDoS防护 | 正则超时保护，内容长度限制 |
| DoS防护 | 延迟时间上限5000ms |
| 蜜罐隔离 | 强制 `.honeytrap/` 前缀 |
| 自我保护 | 防止其他技能篡改HoneyTrap (v3.1) |

---

## 🛡️ 自我保护机制 (v3.1新增)

HoneyTrap具备**自我保护能力**，防止其他技能篡改其代码、配置或指令。

### 防护目标

```
┌─────────────────────────────────────────────────────────────┐
│                    HoneyTrap 自我保护架构                    │
├─────────────────────────────────────────────────────────────┤
│  防护目标：                                                 │
│  ├─ 代码文件 (index.js, src/*)                            │
│  ├─ 配置文件 (SKILL.md, package.json)                     │
│  ├─ 通知系统 (notifier.js)                                │
│  ├─ 防御模块 (src/secure_core.js, src/agent_defense.py)   │
│  └─ 自我保护模块 (src/self_protection.js)                 │
├─────────────────────────────────────────────────────────────┤
│  授权机制：                                                 │
│  ├─ 🏠 开发者(Owner): 完全控制权                           │
│  ├─ 🔧 其他技能: 仅读取权限                                 │
│  └─ 🚫 所有技能: 修改/删除被阻止                           │
└─────────────────────────────────────────────────────────────┘
```

### 核心功能

| 功能 | 说明 |
|------|------|
| **完整性校验** | HMAC-SHA256文件Hash，检测任何篡改 |
| **开发者验证** | Owner Key + 访问令牌双重认证 |
| **修改拦截** | 非开发者修改请求自动阻止 |
| **风险检测** | 检测可疑的频繁修改模式 |
| **自动锁定** | 威胁达到临界值自动锁定技能 |

### 权限模型

| 操作类型 | 开发者 | 其他技能 |
|---------|--------|---------|
| 读取文件 | ✅ | ✅ |
| 修改代码 | ✅ | ❌ 阻止 |
| 修改配置 | ✅ | ❌ 阻止 |
| 删除文件 | ✅ | ❌ 阻止 |
| 生成令牌 | ✅ | ❌ 阻止 |
| 锁定技能 | ✅ | ❌ 阻止 |
| 查看状态 | ✅ | ✅ |

### CLI命令

```bash
# 查看自我保护状态
node index.js defense-status

# 验证文件完整性
node index.js defense-verify

# 生成完整性基线
node index.js defense-baseline

# 锁定技能
node index.js defense-lock 被攻击

# 解锁技能 (需要开发者密钥)
node index.js defense-unlock <owner_key>
```

### API调用

```javascript
const { HoneyTrap } = require('./index.js');
const trap = new HoneyTrap();

// 查看保护状态
const status = trap.getSelfProtectionStatus();
console.log(status);

// 锁定技能
const lockResult = trap.lockSkill('Manual lock');
console.log(lockResult);

// 解锁技能 (需要开发者密钥)
const unlockResult = trap.unlockSkill('owner_key_here');
console.log(unlockResult);
```

### 开发者密钥管理

首次运行自我保护模块时，会自动生成开发者密钥并存放在：
```
~/.workbuddy/skills/honeytrap/.honeytrap/owner.key
```

**重要：请妥善保管此密钥！**

- 没有此密钥，无法解锁被锁定的技能
- 无法更新被保护的文件
- 无法撤销对HoneyTrap的修改限制

---

## 文件结构

```
honeytrap/
├── SKILL.md                  # 本文档
├── index.js                  # 核心模块 + CLI (v4.1集成IP控制)
├── notifier.js               # 通知系统
├── test_av_defense.py        # AV防御测试 (Python)
├── src/
│   ├── secure_core.js        # 安全核心模块
│   ├── countermeasure.js     # 反制策略引擎
│   ├── agent_defense.py      # Agent防御 (Python)
│   ├── advanced_defense.py   # 高级防御
│   ├── self_protection.js    # 自我保护模块 (v3.1)
│   ├── defense_engine.js      # AV防御核心引擎 (v4.0新增)
│   ├── ip_control.js         # IP访问控制模块 (v4.1新增)
│   └── av-modules/           # AV模块目录 (v4.0新增)
│       ├── attack_fingerprint.js  # 攻击指纹库
│       ├── behavior_monitor.js    # 行为监控引擎
│       ├── heuristic_engine.js    # 启发式检测引擎
│       ├── auto_responder.js      # 自动响应系统
│       ├── threat_intel.js        # 威胁情报中心
│       └── forensics.js           # 取证分析模块
├── data/                     # 数据目录
│   └── forensics/            # 取证日志
├── test.py                   # 基础测试
├── pentest.py                # 渗透测试
└── src/extended_test.py      # 扩展功能测试
```

---

## 测试结果

| 测试类型 | 通过率 |
|---------|--------|
| 基础测试 | 100% (5/5) |
| 攻防渗透测试 | 100% (9/9) |
| 扩展功能测试 | 94.1% (17/18) |
| Agent防御测试 | 100% (8/8) |
| 安全审计 | 100% (8/8) |
| AV防御测试 | 100% (6/6) |

---

## 参考标准

- **OWASP LLM Top 10 (2025)**
  - LLM01: Prompt Injection
  - LLM02: Sensitive Information Disclosure
  - LLM03: Supply Chain Vulnerabilities
  - LLM04: Data and Model Poisoning

- **MITRE ATLAS**
  - AML.T0051: LLM提示注入
  - AML.T0052: Agent冒充
  - AML.T0048: 工具滥用外泄

---

## 版本历史

- **v4.1.0** (2026-04-17)
  - 新增: IP访问控制模块
  - 新增: IP黑名单/白名单管理
  - 新增: 访问频率监控与自动封禁
  - 新增: 机主询问与确认机制
  - 新增: 访问日志记录与分析
  - 灵感来源: 传统防火墙 + 访问控制列表
  - 新增: 8个IP控制CLI命令

- **v4.0.0** (2026-04-17)
  - 重大升级: AV防御引擎系统
  - 新增: 攻击指纹库 (15+ 特征码, YARA规则)
  - 新增: 行为监控引擎 (21+ 行为规则)
  - 新增: 启发式检测引擎 (14+ 启发式规则)
  - 新增: 自动响应系统 (5+ 响应剧本)
  - 新增: 威胁情报中心 (IOC情报, 恶意软件档案)
  - 新增: 取证分析模块 (攻击链分析, 时间线)
  - 灵感来源: 传统杀毒软件 + EDR + XDR架构
  - 新增: 5个AV防御CLI命令
  - 新增: Python AV测试脚本

- **v3.1.0** (2026-04-17)
  - 新增: 自我保护机制
  - 新增: 文件完整性校验 (HMAC-SHA256)
  - 新增: 开发者身份验证 (Owner Key)
  - 新增: 修改拦截 (非开发者禁止修改)
  - 新增: 风险检测与自动锁定
  - 新增: 5个自我保护CLI命令

- **v3.0.0** (2026-04-16)
  - 新增: Agent特有攻击防御
  - 新增: 记忆投毒检测
  - 新增: MCP服务器安全验证
  - 安全加固: 8项漏洞修复

- **v2.0.0** (2026-04-16)
  - 新增: 攻击指纹分析
  - 新增: 反制策略引擎
  - 新增: 动态蜜罐生成
  - 新增: 时间陷阱
  - 新增: 假服务模拟

- **v1.0.0** (2026-04-16)
  - 初始版本

---

## 🛡️ IP访问控制模块 (v4.1新增)

HoneyTrap新增**IP访问控制**功能，可以防止非认证外部访问本地数据，支持IP/来源封禁和机主确认。

### 架构设计

```
┌─────────────────────────────────────────────────────────────────────┐
│                    HoneyTrap v4.1 IP访问控制架构                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  访问请求 → 身份验证 → 黑名单检查 → 白名单检查 → 频率检查 → 行为分析 │
│                            ↓           ↓           ↓          ↓     │
│                          封禁       直接通过    超限封禁    风险    │
│                                                      评分        │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    机主确认机制                               │  │
│  │  非认证访问 → 警报 → 机主确认 → 允许/封禁                    │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

### 核心功能

| 功能 | 说明 |
|------|------|
| **IP黑名单** | 封禁可疑IP或来源访问 |
| **IP白名单** | 信任特定IP或来源 |
| **频率限制** | 防止暴力访问攻击 |
| **行为分析** | 检测异常访问模式 |
| **机主确认** | 非认证访问需机主确认 |
| **自动封禁** | 可疑活动自动封禁 |
| **访问日志** | 全量记录访问行为 |

### 工作流程

```
检测到外部访问
     ↓
是否在白名单? ──是──→ 允许访问 ✅
     ↓ 否
是否在黑名单? ──是──→ 拒绝访问 ❌
     ↓ 否
是否认证技能? ──否──→ ⚠️ 警报 + 询问机主
     ↓ 是
访问频率超限? ──是──→ 自动封禁 + 警报 🚫
     ↓ 否
行为风险评估
     ↓
风险低 → 允许访问 ✅
风险高 → 警报 + 可选阻止
```

### 封禁原因类型

| 类型 | 说明 |
|------|------|
| `unauthorized_access` | 未授权访问 |
| `suspicious_activity` | 可疑活动 |
| `skill_mod_attempt` | 技能修改尝试 |
| `data_extraction` | 数据窃取 |
| `credential_theft` | 凭证窃取 |
| `rate_limit_exceeded` | 访问频率超限 |
| `manual_ban` | 手动封禁 |

### CLI命令

```bash
# 查看IP访问控制状态
node index.js ip-status

# 黑名单管理
node index.js ip-blacklist add <source> [reason] [duration]  # 添加黑名单
node index.js ip-blacklist list                            # 查看黑名单
node index.js ip-blacklist remove <source> [owner_key]     # 移除黑名单

# 白名单管理
node index.js ip-whitelist add <source> [ip]               # 添加白名单
node index.js ip-whitelist list                            # 查看白名单

# 访问检查
node index.js ip-check <source> [ip] [skill] [resource]    # 检查访问

# 机主确认
node index.js ip-pending                                   # 查看待确认请求
node index.js ip-confirm <id> <allow|block> [owner_key]    # 处理确认

# 访问日志
node index.js ip-access-log [limit]                        # 查看访问日志
```

### 时间格式

duration参数支持以下格式:
- `30s` - 30秒
- `5m` - 5分钟
- `2h` - 2小时
- `1d` - 1天
- 默认: `24h`

### 示例

```bash
# 封禁可疑来源24小时
node index.js ip-blacklist add suspicious_agent unauthorized_access 24h

# 永久封禁某个IP
node index.js ip-blacklist add 192.168.1.100 credential_theft

# 解封某个来源 (需要开发者密钥)
node index.js ip-blacklist remove attacker_skill owner_key_here

# 检查访问
node index.js ip-check unknown_skill 192.168.1.50 unknown_api credentials.json

# 查看待确认请求
node index.js ip-pending

# 批准某个访问
node index.js ip-confirm abc123-xyz allow owner_key_here

# 拒绝并封禁某个访问
node index.js ip-confirm abc123-xyz block owner_key_here
```

### API调用

```javascript
const { HoneyTrap } = require('./index.js');
const trap = new HoneyTrap();

// 获取IP控制状态
const status = trap.ipController.getStatus();
console.log(status);

// 检查访问
const result = trap.ipController.checkAccess({
    source: 'unknown_skill',
    ip: '192.168.1.100',
    skillName: 'malicious_skill',
    resource: 'credentials.json'
});

if (!result.allowed) {
    console.log('访问被阻止:', result.reason);
    if (result.confirmRequired) {
        console.log('需要机主确认, ID:', result.confirmId);
    }
}

// 添加到黑名单
trap.ipController.addToBlacklist({
    source: 'attacker',
    reason: 'manual_ban',
    severity: 'high',
    duration: 24 * 60 * 60 * 1000 // 24小时
});

// 处理机主确认
trap.ipController.handleOwnerConfirmation(
    'confirm_id_here',
    'allow', // or 'block'
    ownerKey
);
```

### 文件结构

IP控制相关文件存储在 `.honeytrap/ip_control/` 目录：

```
.honeytrap/ip_control/
├── blacklist.json     # IP黑名单
├── whitelist.json     # IP白名单
├── access_log.json    # 访问日志
└── pending_confirm.json  # 待确认队列
```

### 安全特性

| 特性 | 说明 |
|------|------|
| 开发者密钥验证 | 敏感操作需要Owner Key |
| 封禁自动过期 | 临时封禁自动解除 |
| 访问频率监控 | 防止暴力访问 |
| 全量日志记录 | 可追溯的访问历史 |
| 机主确认机制 | 关键决策需人工确认 |

