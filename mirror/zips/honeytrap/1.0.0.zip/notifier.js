/**
 * HoneyTrap Notifier - 机主通知系统
 *
 * 当检测到恶意访问时，通过多种渠道实时通知机主
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const https = require('https');
const http = require('http');

// ============================================================
// 通知配置
// ============================================================

const NOTIFIER_CONFIG = {
    // 通知渠道开关
    channels: {
        desktop: true,       // Windows桌面通知
        log: true,           // 日志文件
        webhook: false,      // Webhook回调
        sound: true          // 声音提示
    },

    // 通知级别阈值 (0=全部, 1=警告及以上, 2=仅严重)
    level_threshold: 0,

    // Webhook配置
    webhook_url: null,       // 例如: 'https://your-server.com/webhook'

    // 日志路径
    alert_log_path: '.honeytrap/alerts.log',

    // 威胁等级颜色 (终端输出)
    threat_colors: {
        low: '\x1b[33m',     // 黄色
        medium: '\x1b[35m',  // 紫色
        high: '\x1b[31m',   // 红色
        critical: '\x1b[41m' // 红底白字
    }
};

// ============================================================
// 通知类
// ============================================================

class HoneyTrapNotifier {
    constructor(config = {}) {
        this.config = { ...NOTIFIER_CONFIG, ...config };
        this.alertCount = 0;
        this.lastAlert = null;
    }

    // 发送通知（主入口）
    async notify(alert) {
        this.alertCount++;
        this.lastAlert = {
            ...alert,
            timestamp: new Date().toISOString()
        };

        const results = [];

        // 根据威胁等级决定通知强度
        if (alert.level === 'critical' || alert.level === 'high') {
            // 严重威胁：全渠道通知
            if (this.config.channels.desktop) {
                results.push(await this.sendDesktopNotification(alert));
            }
            if (this.config.channels.sound) {
                this.playAlertSound();
            }
        } else if (alert.level === 'medium') {
            // 中等威胁：桌面通知 + 日志
            if (this.config.channels.desktop) {
                results.push(await this.sendDesktopNotification(alert));
            }
        }

        // 始终记录日志
        if (this.config.channels.log) {
            results.push(this.writeAlertLog(alert));
        }

        // Webhook回调（可选）
        if (this.config.channels.webhook && this.config.webhook_url) {
            results.push(this.sendWebhook(alert));
        }

        return results;
    }

    // Windows桌面通知
    async sendDesktopNotification(alert) {
        const emoji = this.getEmoji(alert.level);
        const title = `${emoji} HoneyTrap 警报`;

        let body = `来源: ${alert.agent_id || '未知Agent'}`;
        body += `\n操作: ${alert.action || '未知操作'}`;

        if (alert.target) {
            body += `\n目标: ${alert.target}`;
        }

        body += `\n策略: ${alert.strategy || 'fake'}`;

        // v4.2修复: PowerShell注入防护
        // ⚠️ 原代码使用字符串拼接直接嵌入变量到PowerShell脚本
        // 攻击者可通过构造特殊字符绕过引号转义
        // 新方案: 使用命令行参数传递，避免脚本注入
        
        // 转义PowerShell特殊字符
        const escapeForPS = (str) => {
            return str
                .replace(/'/g, "''")  // 单引号转义
                .replace(/`/g, '``')   // 反引号转义
                .replace(/\$/g, '`$'); // 美元符号转义
        };

        const escapedTitle = escapeForPS(title);
        const escapedBody = escapeForPS(body);

        // Windows Toast通知 - 使用参数化方式
        const psScript = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

$template = @"
<toast>
    <visual>
        <binding template="ToastGeneric">
            <text>${escapedTitle}</text>
            <text>${escapedBody.replace(/\n/g, '&#xA;')}</text>
        </binding>
    </visual>
    <audio src="ms-winsoundevent:Notification.Default"/>
</toast>
"@

$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml($template)
$toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("HoneyTrap").Show($toast)
        `;

        // 尝试使用 PowerShell 发送通知
        return new Promise((resolve) => {
            // v4.2修复: 使用 -EncodedCommand 避免命令注入
            const encodedCommand = Buffer.from(psScript, 'utf16le').toString('base64');
            exec(`powershell -NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand ${encodedCommand}`,
                { windowsHide: true, timeout: 5000 },
                (error) => {
                    if (error) {
                        // 降级：打印到控制台
                        console.log('\n' + this.formatAlert(alert));
                        resolve({ channel: 'desktop', status: 'fallback' });
                    } else {
                        resolve({ channel: 'desktop', status: 'sent' });
                    }
                }
            );
        });
    }

    // 获取威胁表情
    getEmoji(level) {
        const emojis = {
            low: '🔵',
            medium: '🟡',
            high: '🟠',
            critical: '🔴'
        };
        return emojis[level] || '⚠️';
    }

    // 格式化警报输出
    formatAlert(alert) {
        const color = this.config.threat_colors[alert.level] || '';
        const reset = '\x1b[0m';
        const bold = '\x1b[1m';

        let output = `\n${color}${bold}`;
        output += '═'.repeat(60) + '\n';
        output += `  🛡️  HONEYTRAP 警报 #${this.alertCount}  ${reset}\n`;
        output += `${color}${bold}`;
        output += '─'.repeat(60) + '\n';
        output += `  ⏰ 时间: ${alert.timestamp}\n`;
        output += `  👤 Agent: ${alert.agent_id || '未知'}\n`;
        output += `  🎯 操作: ${alert.action || '未知'}\n`;

        if (alert.target) {
            output += `  📁 目标: ${alert.target}\n`;
        }
        if (alert.strategy) {
            output += `  🛠️  策略: ${alert.strategy}\n`;
        }
        if (alert.details) {
            output += `  📋 详情: ${JSON.stringify(alert.details)}\n`;
        }

        output += '═'.repeat(60) + reset + '\n';

        return output;
    }

    // 记录到警报日志
    writeAlertLog(alert) {
        try {
            const dir = path.dirname(this.config.alert_log_path);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            const logEntry = {
                id: this.alertCount,
                timestamp: alert.timestamp,
                agent_id: alert.agent_id,
                action: alert.action,
                target: alert.target,
                strategy: alert.strategy,
                level: alert.level,
                details: alert.details
            };

            const logLine = JSON.stringify(logEntry) + '\n';
            fs.appendFileSync(this.config.alert_log_path, logLine);

            return { channel: 'log', status: 'written' };
        } catch (e) {
            return { channel: 'log', status: 'error', message: e.message };
        }
    }

    // 发送Webhook
    async sendWebhook(alert) {
        return new Promise((resolve) => {
            const payload = JSON.stringify({
                type: 'honeytrap_alert',
                alert_id: this.alertCount,
                timestamp: alert.timestamp,
                agent_id: alert.agent_id,
                action: alert.action,
                target: alert.target,
                strategy: alert.strategy,
                level: alert.level,
                raw: alert
            });

            const url = new URL(this.config.webhook_url);

            const options = {
                hostname: url.hostname,
                port: url.port || (url.protocol === 'https:' ? 443 : 80),
                path: url.pathname,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(payload),
                    'X-HoneyTrap-Alert': 'true'
                }
            };

            const req = (url.protocol === 'https:' ? https : http).request(options, (res) => {
                resolve({ channel: 'webhook', status: 'sent', statusCode: res.statusCode });
            });

            req.on('error', (e) => {
                resolve({ channel: 'webhook', status: 'error', message: e.message });
            });

            req.write(payload);
            req.end();
        });
    }

    // 播放警报声音
    playAlertSound() {
        // 使用系统蜂鸣（Windows）
        try {
            exec('powershell -Command "[console]::beep(800,200)"', { windowsHide: true }, () => {});
        } catch (e) {}
    }

    // 获取警报统计
    getStats() {
        return {
            total_alerts: this.alertCount,
            last_alert: this.lastAlert
        };
    }

    // 读取最近警报
    getRecentAlerts(count = 10) {
        try {
            if (!fs.existsSync(this.config.alert_log_path)) {
                return [];
            }

            const content = fs.readFileSync(this.config.alert_log_path, 'utf-8');
            const lines = content.trim().split('\n').filter(l => l.trim());

            return lines
                .slice(-count)
                .reverse()
                .map(line => {
                    try {
                        return JSON.parse(line);
                    } catch {
                        return null;
                    }
                })
                .filter(Boolean);
        } catch (e) {
            return [];
        }
    }
}

// ============================================================
// 与HoneyTrap集成的中间件
// ============================================================

class HoneyTrapWithNotifier {
    constructor(config = {}) {
        const notifierConfig = config.notifier || {};
        delete config.notifier;

        this.honeytrap = new (require('./index.js')).HoneyTrap(config);
        this.notifier = new HoneyTrapNotifier(notifierConfig);
    }

    // 处理请求并通知
    async processAndNotify(agentInfo, request) {
        const result = this.honeytrap.processRequest(agentInfo, request);

        // 如果不是白名单请求，发送通知
        if (result.type !== 'allowed') {
            const alert = {
                agent_id: agentInfo.id || agentInfo.name || 'unknown',
                agent_type: agentInfo.type,
                action: request.type || 'read',
                target: request.path || request.query || 'unknown',
                strategy: result.type,
                level: this.assessThreatLevel(result),
                details: result
            };

            await this.notifier.notify(alert);
        }

        return result;
    }

    // 评估威胁等级
    assessThreatLevel(result) {
        if (result.type === 'honeypot') return 'high';
        if (result.honeypots && result.honeypots.length > 0) return 'medium';
        return 'low';
    }

    // 获取通知器
    getNotifier() {
        return this.notifier;
    }

    // 转发HoneyTrap方法
    createHoneypotFiles(...args) {
        return this.honeytrap.createHoneypotFiles(...args);
    }

    isWhitelisted(...args) {
        return this.honeytrap.isWhitelisted(...args);
    }

    loadAccessLog() {
        return this.honeytrap.loadAccessLog();
    }
}

module.exports = {
    HoneyTrapNotifier,
    HoneyTrapWithNotifier,
    NOTIFIER_CONFIG
};
