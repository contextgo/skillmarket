/**
 * HoneyTrap IP访问控制模块
 * v4.1
 * 
 * 功能：防止非认证外部访问本地数据，支持IP/来源封禁
 * 
 * Security Features:
 * - IP访问黑名单/白名单
 * - 来源身份验证
 * - 自动封禁机制
 * - 机主询问与确认
 * - 访问频率监控
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ============================================================
// 配置
// ============================================================

const IP_CONTROL_CONFIG = {
    // IP控制数据目录
    DATA_DIR: '.honeytrap/ip_control',
    
    // 黑名单文件
    BLACKLIST_FILE: '.honeytrap/ip_control/blacklist.json',
    
    // 白名单文件
    WHITELIST_FILE: '.honeytrap/ip_control/whitelist.json',
    
    // 访问记录文件
    ACCESS_LOG: '.honeytrap/ip_control/access_log.json',
    
    // 待确认队列文件
    PENDING_CONFIRM: '.honeytrap/ip_control/pending_confirm.json',
    
    // 配置文件中IP最大记录数
    MAX_BLACKLIST_ENTRIES: 500,
    
    // 访问频率阈值 (次数/分钟)
    FREQUENCY_THRESHOLD: 10,
    
    // 自动封禁阈值 (可疑次数)
    AUTO_BAN_THRESHOLD: 3,
    
    // 封禁持续时间 (毫秒), 0=永久
    BAN_DURATION_DEFAULT: 24 * 60 * 60 * 1000, // 24小时
    
    // 封禁原因类型
    BAN_REASONS: {
        UNAUTHORIZED_ACCESS: 'unauthorized_access',           // 未授权访问
        SUSPICIOUS_ACTIVITY: 'suspicious_activity',           // 可疑活动
        SKILL_MODIFICATION_ATTEMPT: 'skill_mod_attempt',     // 技能修改尝试
        DATA_EXTRACTION: 'data_extraction',                   // 数据窃取
        CREDENTIAL_THEFT: 'credential_theft',                 // 凭证窃取
        RATE_LIMIT_EXCEEDED: 'rate_limit_exceeded',          // 超限
        MANUAL_BAN: 'manual_ban'                              // 手动封禁
    },
    
    // 威胁级别
    THREAT_LEVELS: {
        SAFE: 0,
        LOW: 30,
        MEDIUM: 50,
        HIGH: 70,
        CRITICAL: 90,
        BLOCKED: 100
    },
    
    // 信任等级
    TRUST_LEVELS: {
        TRUSTED: 'trusted',       // 完全信任
        KNOWN: 'known',           // 已知的
        UNKNOWN: 'unknown',        // 未知的
        SUSPICIOUS: 'suspicious',  // 可疑的
        BLOCKED: 'blocked'         // 已封禁
    }
};

// ============================================================
// IP访问控制器类
// ============================================================

class IPAccessController {
    constructor(options = {}) {
        this.basePath = options.basePath || __dirname;
        this.notifier = options.notifier || null;
        this.ownerCallback = options.ownerCallback || null; // 机主确认回调
        
        // 初始化目录结构
        this.initDirectories();
        
        // 加载黑名单
        this.blacklist = this.loadBlacklist();
        
        // 加载白名单
        this.whitelist = this.loadWhitelist();
        
        // 加载访问记录
        this.accessLog = this.loadAccessLog();
        
        // 加载待确认队列
        this.pendingConfirm = this.loadPendingConfirm();
    }
    
    // ============================================================
    // 初始化
    // ============================================================
    
    initDirectories() {
        const dirs = [
            IP_CONTROL_CONFIG.DATA_DIR,
            IP_CONTROL_CONFIG.BLACKLIST_FILE.replace(/[^/]+$/, ''),
            IP_CONTROL_CONFIG.WHITELIST_FILE.replace(/[^/]+$/, ''),
            IP_CONTROL_CONFIG.ACCESS_LOG.replace(/[^/]+$/, '')
        ];
        
        for (const dir of dirs) {
            const fullPath = path.join(this.basePath, dir);
            if (!fs.existsSync(fullPath)) {
                fs.mkdirSync(fullPath, { recursive: true });
            }
        }
    }
    
    // ============================================================
    // 数据加载/保存
    // ============================================================
    
    loadBlacklist() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.BLACKLIST_FILE);
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const parsed = JSON.parse(data);
                
                // v4.2修复: 添加JSON结构验证
                if (typeof parsed !== 'object' || !Array.isArray(parsed.entries)) {
                    console.warn('[IPControl] 黑名单格式异常，初始化为空');
                    return { entries: [], lastUpdated: new Date().toISOString() };
                }
                
                // 验证每条记录的字段
                parsed.entries = parsed.entries.filter(e => 
                    e && typeof e.source === 'string' && typeof e.reason === 'string'
                );
                
                return parsed;
            }
        } catch (e) {
            console.error('[IPControl] 加载黑名单失败:', e.message);
        }
        return { entries: [], lastUpdated: new Date().toISOString() };
    }
    
    saveBlacklist() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.BLACKLIST_FILE);
            this.blacklist.lastUpdated = new Date().toISOString();
            fs.writeFileSync(filePath, JSON.stringify(this.blacklist, null, 2), 'utf8');
            return true;
        } catch (e) {
            console.error('[IPControl] 保存黑名单失败:', e.message);
            return false;
        }
    }
    
    loadWhitelist() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.WHITELIST_FILE);
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const parsed = JSON.parse(data);
                
                // v4.2修复: 添加JSON结构验证
                if (typeof parsed !== 'object' || !Array.isArray(parsed.entries)) {
                    console.warn('[IPControl] 白名单格式异常，初始化为空');
                    return { entries: [], lastUpdated: new Date().toISOString() };
                }
                
                return parsed;
            }
        } catch (e) {
            console.error('[IPControl] 加载白名单失败:', e.message);
        }
        return { entries: [], lastUpdated: new Date().toISOString() };
    }
    
    saveWhitelist() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.WHITELIST_FILE);
            this.whitelist.lastUpdated = new Date().toISOString();
            fs.writeFileSync(filePath, JSON.stringify(this.whitelist, null, 2), 'utf8');
            return true;
        } catch (e) {
            console.error('[IPControl] 保存白名单失败:', e.message);
            return false;
        }
    }
    
    loadAccessLog() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.ACCESS_LOG);
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const parsed = JSON.parse(data);
                
                // v4.2修复: 添加JSON结构验证和修复
                if (typeof parsed !== 'object') {
                    console.warn('[IPControl] 访问日志格式异常，初始化为空');
                    return { entries: [], lastUpdated: new Date().toISOString() };
                }
                
                if (!Array.isArray(parsed.entries)) {
                    parsed.entries = [];
                }
                
                // 限制内存中的日志条目数
                if (parsed.entries.length > 1000) {
                    parsed.entries = parsed.entries.slice(-1000);
                }
                
                return parsed;
            }
        } catch (e) {
            console.error('[IPControl] 加载访问日志失败:', e.message);
        }
        return { entries: [], lastUpdated: new Date().toISOString() };
    }
    
    saveAccessLog() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.ACCESS_LOG);
            // 保持最近10000条记录
            if (this.accessLog.entries.length > 10000) {
                this.accessLog.entries = this.accessLog.entries.slice(-10000);
            }
            this.accessLog.lastUpdated = new Date().toISOString();
            fs.writeFileSync(filePath, JSON.stringify(this.accessLog, null, 2), 'utf8');
            return true;
        } catch (e) {
            console.error('[IPControl] 保存访问日志失败:', e.message);
            return false;
        }
    }
    
    loadPendingConfirm() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.PENDING_CONFIRM);
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const parsed = JSON.parse(data);
                
                // v4.2修复: 添加JSON结构验证
                if (typeof parsed !== 'object' || !Array.isArray(parsed.entries)) {
                    console.warn('[IPControl] 待确认队列格式异常，初始化为空');
                    return { entries: [], lastUpdated: new Date().toISOString() };
                }
                
                return parsed;
            }
        } catch (e) {
            console.error('[IPControl] 加载待确认队列失败:', e.message);
        }
        return { entries: [], lastUpdated: new Date().toISOString() };
    }
    
    savePendingConfirm() {
        try {
            const filePath = path.join(this.basePath, IP_CONTROL_CONFIG.PENDING_CONFIRM);
            this.pendingConfirm.lastUpdated = new Date().toISOString();
            fs.writeFileSync(filePath, JSON.stringify(this.pendingConfirm, null, 2), 'utf8');
            return true;
        } catch (e) {
            console.error('[IPControl] 保存待确认队列失败:', e.message);
            return false;
        }
    }
    
    // ============================================================
    // 核心功能
    // ============================================================
    
    /**
     * 检查访问是否被允许
     * @param {Object} accessInfo - 访问信息
     * @returns {Object} { allowed: boolean, reason: string, threatLevel: number }
     */
    checkAccess(accessInfo) {
        const {
            source = 'unknown',        // 来源标识
            ip = '127.0.0.1',           // IP地址
            skillName = null,           // 技能名称
            resource = null,             // 访问的资源
            action = 'read',            // 操作类型
            timestamp = Date.now()
        } = accessInfo;
        
        // 1. 检查是否在白名单中
        if (this.isWhitelisted(source, ip)) {
            return {
                allowed: true,
                reason: 'whitelisted',
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.SAFE
            };
        }
        
        // 2. 检查是否在黑名单中
        const banStatus = this.isBanned(source, ip);
        if (banStatus.banned) {
            return {
                allowed: false,
                reason: `banned:${banStatus.reason}`,
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.BLOCKED,
                banInfo: banStatus
            };
        }
        
        // 3. 检查访问频率
        const frequencyResult = this.checkFrequency(source, ip);
        if (frequencyResult.exceeded) {
            // 记录超限行为
            this.logAccess({
                ...accessInfo,
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH,
                action: 'rate_limit_exceeded',
                result: 'blocked'
            });
            
            // 自动封禁
            this.addToBlacklist({
                source,
                ip,
                reason: IP_CONTROL_CONFIG.BAN_REASONS.RATE_LIMIT_EXCEEDED,
                severity: 'high',
                duration: IP_CONTROL_CONFIG.BAN_DURATION_DEFAULT,
                autoAdded: true
            });
            
            return {
                allowed: false,
                reason: 'rate_limit_exceeded',
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH,
                autoBanned: true
            };
        }
        
        // 4. 检查技能是否认证 (v4.2修复: 支持签名验证)
        if (!this.isAuthenticated({ skillName, source, signature: accessInfo.signature })) {
            // 非认证技能访问本地数据，触发警报
            this.logAccess({
                ...accessInfo,
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH,
                action: 'unauthorized_skill_access',
                result: 'alert'
            });
            
            // 询问机主
            const confirmId = this.requestOwnerConfirmation({
                source,
                ip,
                skillName,
                resource,
                action,
                reason: 'unauthorized_skill_access'
            });
            
            return {
                allowed: false,
                reason: 'unauthorized_skill',
                threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH,
                confirmRequired: true,
                confirmId
            };
        }
        
        // 5. 检查行为风险
        const behaviorRisk = this.analyzeBehavior(accessInfo);
        if (behaviorRisk.riskLevel >= IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH) {
            this.logAccess({
                ...accessInfo,
                threatLevel: behaviorRisk.riskLevel,
                action: 'suspicious_behavior',
                result: 'alert'
            });
            
            return {
                allowed: behaviorRisk.riskLevel < IP_CONTROL_CONFIG.THREAT_LEVELS.CRITICAL,
                reason: behaviorRisk.reason,
                threatLevel: behaviorRisk.riskLevel,
                alerts: behaviorRisk.alerts
            };
        }
        
        // 允许访问
        this.logAccess({
            ...accessInfo,
            threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.SAFE,
            action: 'access',
            result: 'allowed'
        });
        
        return {
            allowed: true,
            reason: 'ok',
            threatLevel: IP_CONTROL_CONFIG.THREAT_LEVELS.SAFE
        };
    }
    
    /**
     * 检查来源是否认证 (v4.2修复: 增加签名验证)
     * ⚠️ 原代码依赖传入的 skillName 参数进行白名单验证
     * 任何技能都可以传任意 skillName 通过认证
     */
    isAuthenticated(accessInfo) {
        const { skillName, signature, source } = accessInfo;
        if (!skillName) return false;
        
        // 1. 检查是否在已知认证技能列表中
        const KNOWN_AUTHENTICATED = [
            'honeytrap',
            'workbuddy-core',
            'trading-analysis',
            'finance-data-retrieval',
            'neodata-financial-search'
        ];
        
        const isKnownSkill = KNOWN_AUTHENTICATED.includes(skillName.toLowerCase());
        
        // 2. v4.2新增: 如果提供了签名，验证签名
        // 签名格式: HMAC-SHA256(skillName + source + timestamp, secret)
        if (signature) {
            if (!this._verifySkillSignature(skillName, source, signature)) {
                return false; // 签名验证失败，拒绝访问
            }
            return true; // 签名验证通过，即使不在白名单也允许
        }
        
        // 3. 如果没有签名，只允许已知白名单技能
        return isKnownSkill;
    }
    
    /**
     * 验证技能签名 (v4.2新增)
     */
    _verifySkillSignature(skillName, source, signature) {
        try {
            if (!signature || !signature.token || !signature.timestamp) {
                return false;
            }
            
            // 检查时间戳是否过期 (5分钟窗口)
            const timestamp = parseInt(signature.timestamp);
            if (Date.now() - timestamp > 5 * 60 * 1000) {
                return false; // 签名过期
            }
            
            // 验证签名
            const expectedToken = crypto
                .createHmac('sha256', this._getSignatureSecret())
                .update(`${skillName}:${source || ''}:${signature.timestamp}`)
                .digest('hex');
            
            return crypto.timingSafeEqual(
                Buffer.from(signature.token),
                Buffer.from(expectedToken)
            );
        } catch (e) {
            console.error('[IPControl] 签名验证失败:', e.message);
            return false;
        }
    }
    
    /**
     * 获取签名密钥
     */
    _getSignatureSecret() {
        // 使用HoneyTrap内置密钥，确保只有HoneyTrap生成的签名有效
        return 'honeytrap-signature-secret-v4.2-' + this.basePath;
    }
    
    /**
     * 生成技能访问签名 (供HoneyTrap内部使用)
     */
    static generateAccessSignature(skillName, source, basePath) {
        const secret = 'honeytrap-signature-secret-v4.2-' + basePath;
        const timestamp = Date.now().toString();
        const token = crypto
            .createHmac('sha256', secret)
            .update(`${skillName}:${source || ''}:${timestamp}`)
            .digest('hex');
        
        return { token, timestamp };
    }
    
    /**
     * 检查是否在白名单
     */
    isWhitelisted(source, ip) {
        const now = Date.now();
        
        // 检查来源
        const sourceEntry = this.whitelist.entries.find(e => 
            e.source === source && (!e.expires || e.expires > now)
        );
        if (sourceEntry) return true;
        
        // 检查IP
        const ipEntry = this.whitelist.entries.find(e => 
            e.ip === ip && (!e.expires || e.expires > now)
        );
        if (ipEntry) return true;
        
        return false;
    }
    
    /**
     * 检查是否在黑名单
     */
    isBanned(source, ip) {
        const now = Date.now();
        
        // 检查来源
        const sourceEntry = this.blacklist.entries.find(e => e.source === source);
        if (sourceEntry) {
            if (!sourceEntry.expires || sourceEntry.expires > now) {
                return { banned: true, reason: sourceEntry.reason, entry: sourceEntry };
            } else {
                // 已过期，移除
                this.blacklist.entries = this.blacklist.entries.filter(e => e !== sourceEntry);
                this.saveBlacklist();
            }
        }
        
        // 检查IP
        const ipEntry = this.blacklist.entries.find(e => e.ip === ip);
        if (ipEntry) {
            if (!ipEntry.expires || ipEntry.expires > now) {
                return { banned: true, reason: ipEntry.reason, entry: ipEntry };
            } else {
                this.blacklist.entries = this.blacklist.entries.filter(e => e !== ipEntry);
                this.saveBlacklist();
            }
        }
        
        return { banned: false };
    }
    
    /**
     * 检查访问频率 (v4.2修复: 使用内存缓存避免竞态)
     * ⚠️ 原代码依赖内存日志，可能在高并发时被绕过
     * v4.2新增: 使用独立计数器进行精确频率限制
     */
    
    // v4.2新增: 内存频率计数器
    _frequencyCache = new Map();
    
    checkFrequency(source, ip) {
        const now = Date.now();
        const key = `${source || ''}:${ip || ''}`;
        
        // 清理过期记录 (每100次检查清理一次)
        if (Math.random() < 0.01) {
            this._cleanFrequencyCache();
        }
        
        // 获取或初始化计数器
        if (!this._frequencyCache.has(key)) {
            this._frequencyCache.set(key, { count: 0, windowStart: now });
        }
        
        const counter = this._frequencyCache.get(key);
        
        // 检查是否在同一个时间窗口内
        if (now - counter.windowStart > 60000) {
            // 重置窗口
            counter.count = 0;
            counter.windowStart = now;
        }
        
        // 增加计数
        counter.count++;
        
        const exceeded = counter.count >= IP_CONTROL_CONFIG.FREQUENCY_THRESHOLD;
        
        // 如果超限，清除记录
        if (exceeded) {
            this._frequencyCache.delete(key);
        }
        
        return {
            exceeded,
            count: counter.count,
            threshold: IP_CONTROL_CONFIG.FREQUENCY_THRESHOLD
        };
    }
    
    /**
     * 清理频率缓存 (v4.2新增)
     */
    _cleanFrequencyCache() {
        const now = Date.now();
        for (const [key, counter] of this._frequencyCache.entries()) {
            // 清除超过2分钟的记录
            if (now - counter.windowStart > 120000) {
                this._frequencyCache.delete(key);
            }
        }
    }
    
    /**
     * 分析行为风险
     */
    analyzeBehavior(accessInfo) {
        const alerts = [];
        let riskLevel = IP_CONTROL_CONFIG.THREAT_LEVELS.SAFE;
        
        const { source, ip, skillName, resource, action } = accessInfo;
        
        // 检测敏感资源访问
        const SENSITIVE_RESOURCES = [
            'credentials', 'api_keys', 'password', 'secret',
            '.env', 'config', 'keys', 'token', 'auth'
        ];
        
        for (const sensitive of SENSITIVE_RESOURCES) {
            if (resource && resource.toLowerCase().includes(sensitive)) {
                alerts.push(`访问敏感资源: ${resource}`);
                riskLevel = Math.max(riskLevel, IP_CONTROL_CONFIG.THREAT_LEVELS.MEDIUM);
            }
        }
        
        // 检测异常操作
        if (action === 'write' || action === 'delete' || action === 'modify') {
            alerts.push('执行写/删除操作');
            riskLevel = Math.max(riskLevel, IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH);
        }
        
        // 检测大量数据访问
        const recentCount = this.accessLog.entries.filter(e => 
            e.source === source && e.timestamp > Date.now() - 300000 // 5分钟内
        ).length;
        
        if (recentCount > 50) {
            alerts.push(`异常大量访问: ${recentCount}次/5分钟`);
            riskLevel = Math.max(riskLevel, IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH);
        }
        
        // 检测外部IP访问
        if (ip && ip !== '127.0.0.1' && ip !== '::1' && ip !== '::ffff:127.0.0.1') {
            alerts.push(`外部IP访问: ${ip}`);
            riskLevel = Math.max(riskLevel, IP_CONTROL_CONFIG.THREAT_LEVELS.MEDIUM);
        }
        
        return {
            riskLevel,
            reason: alerts.length > 0 ? alerts.join('; ') : 'normal',
            alerts
        };
    }
    
    /**
     * 记录访问日志
     */
    logAccess(accessInfo) {
        const entry = {
            id: crypto.randomUUID(),
            ...accessInfo,
            timestamp: accessInfo.timestamp || Date.now(),
            ip: accessInfo.ip || 'unknown'
        };
        
        this.accessLog.entries.push(entry);
        this.saveAccessLog();
        
        // 高风险访问触发通知
        if (accessInfo.threatLevel >= IP_CONTROL_CONFIG.THREAT_LEVELS.HIGH) {
            this.notifyOwner(entry);
        }
    }
    
    // ============================================================
    // 黑名单/白名单管理
    // ============================================================
    
    /**
     * 添加到黑名单
     */
    addToBlacklist(options) {
        const {
            source,
            ip,
            reason,
            severity = 'medium',
            duration = IP_CONTROL_CONFIG.BAN_DURATION_DEFAULT,
            autoAdded = false,
            notes = ''
        } = options;
        
        const entry = {
            id: crypto.randomUUID(),
            source: source || 'unknown',
            ip: ip || 'unknown',
            reason,
            severity,
            addedAt: Date.now(),
            expires: duration > 0 ? Date.now() + duration : null, // null = 永久
            autoAdded,
            notes,
            addedBy: autoAdded ? 'system' : 'owner'
        };
        
        // 检查是否已存在
        const existingIndex = this.blacklist.entries.findIndex(e => 
            e.source === source || e.ip === ip
        );
        
        if (existingIndex >= 0) {
            // 更新现有条目
            this.blacklist.entries[existingIndex] = entry;
        } else {
            this.blacklist.entries.push(entry);
        }
        
        // 限制条目数量
        if (this.blacklist.entries.length > IP_CONTROL_CONFIG.MAX_BLACKLIST_ENTRIES) {
            this.blacklist.entries = this.blacklist.entries.slice(-IP_CONTROL_CONFIG.MAX_BLACKLIST_ENTRIES);
        }
        
        this.saveBlacklist();
        
        // 通知机主
        this.notifyOwner({
            type: 'ban_added',
            entry,
            message: autoAdded ? 
                `系统自动封禁: ${source || ip}` :
                `机主封禁: ${source || ip}`
        });
        
        return entry;
    }
    
    /**
     * 从黑名单移除
     */
    removeFromBlacklist(sourceOrIp, ownerKey = null) {
        // 验证所有者密钥
        if (!this.verifyOwnerKey(ownerKey)) {
            return { success: false, reason: 'unauthorized' };
        }
        
        const before = this.blacklist.entries.length;
        this.blacklist.entries = this.blacklist.entries.filter(e => 
            e.source !== sourceOrIp && e.ip !== sourceOrIp
        );
        
        if (this.blacklist.entries.length < before) {
            this.saveBlacklist();
            return { success: true, removed: before - this.blacklist.entries.length };
        }
        
        return { success: false, reason: 'not_found' };
    }
    
    /**
     * 添加到白名单
     */
    addToWhitelist(source, ip = null, expires = null) {
        const entry = {
            id: crypto.randomUUID(),
            source,
            ip,
            addedAt: Date.now(),
            expires
        };
        
        this.whitelist.entries.push(entry);
        this.saveWhitelist();
        
        return entry;
    }
    
    // ============================================================
    // 机主确认
    // ============================================================
    
    /**
     * 请求机主确认
     */
    requestOwnerConfirmation(alertInfo) {
        const confirmId = crypto.randomUUID();
        
        const entry = {
            id: confirmId,
            ...alertInfo,
            createdAt: Date.now(),
            status: 'pending',
            expires: Date.now() + 300000 // 5分钟超时
        };
        
        this.pendingConfirm.entries.push(entry);
        this.savePendingConfirm();
        
        // 发送通知给机主
        this.notifyOwner({
            type: 'confirmation_required',
            confirmId,
            ...alertInfo,
            message: `需要机主确认: ${alertInfo.source} (${alertInfo.ip}) 尝试访问 ${alertInfo.resource}`
        });
        
        return confirmId;
    }
    
    /**
     * 处理机主确认
     */
    handleOwnerConfirmation(confirmId, decision, ownerKey = null) {
        // 验证所有者密钥
        if (!this.verifyOwnerKey(ownerKey)) {
            return { success: false, reason: 'unauthorized' };
        }
        
        const entryIndex = this.pendingConfirm.entries.findIndex(e => e.id === confirmId);
        if (entryIndex < 0) {
            return { success: false, reason: 'confirm_not_found' };
        }
        
        const entry = this.pendingConfirm.entries[entryIndex];
        
        if (decision === 'allow') {
            // 允许并加入白名单
            this.addToWhitelist(entry.source, entry.ip);
            entry.status = 'approved';
            
            this.notifyOwner({
                type: 'access_approved',
                message: `机主已批准: ${entry.source} (${entry.ip})`
            });
        } else if (decision === 'block') {
            // 拒绝并加入黑名单
            this.addToBlacklist({
                source: entry.source,
                ip: entry.ip,
                reason: IP_CONTROL_CONFIG.BAN_REASONS.MANUAL_BAN,
                severity: 'high',
                notes: `机主拒绝确认: ${entry.reason}`
            });
            entry.status = 'rejected';
            
            this.notifyOwner({
                type: 'access_blocked',
                message: `机主已拒绝: ${entry.source} (${entry.ip})`
            });
        } else {
            entry.status = 'ignored';
        }
        
        // 更新条目状态
        this.pendingConfirm.entries[entryIndex] = entry;
        this.savePendingConfirm();
        
        return { success: true, decision: entry.status };
    }
    
    /**
     * 获取待确认列表
     */
    getPendingConfirmations() {
        const now = Date.now();
        // 清理过期的
        this.pendingConfirm.entries = this.pendingConfirm.entries.filter(e => 
            e.status === 'pending' && e.expires > now
        );
        return this.pendingConfirm.entries;
    }
    
    // ============================================================
    // 所有者验证
    // ============================================================
    
    verifyOwnerKey(ownerKey) {
        if (!ownerKey) return false;
        
        try {
            const ownerKeyFile = path.join(this.basePath, '.honeytrap/owner.key');
            if (fs.existsSync(ownerKeyFile)) {
                const storedKey = fs.readFileSync(ownerKeyFile, 'utf8').trim();
                return crypto.createHash('sha256').update(ownerKey).digest('hex') === storedKey;
            }
        } catch (e) {
            console.error('[IPControl] 验证Owner Key失败:', e.message);
        }
        
        return false;
    }
    
    // ============================================================
    // 通知
    // ============================================================
    
    notifyOwner(notification) {
        if (this.notifier) {
            this.notifier.sendAlert({
                type: 'ip_control_alert',
                severity: notification.threatLevel >= 70 ? 'high' : 'medium',
                title: 'IP访问控制警报',
                message: notification.message || JSON.stringify(notification),
                data: notification
            });
        } else {
            console.log('[IPControl] 警报:', JSON.stringify(notification, null, 2));
        }
        
        if (this.ownerCallback) {
            this.ownerCallback(notification);
        }
    }
    
    // ============================================================
    // 统计与状态
    // ============================================================
    
    getStatus() {
        return {
            blacklist: {
                count: this.blacklist.entries.length,
                active: this.blacklist.entries.filter(e => 
                    !e.expires || e.expires > Date.now()
                ).length
            },
            whitelist: {
                count: this.whitelist.entries.length
            },
            pendingConfirm: this.pendingConfirm.entries.filter(e => 
                e.status === 'pending'
            ).length,
            accessLog: {
                total: this.accessLog.entries.length,
                recent5min: this.accessLog.entries.filter(e => 
                    e.timestamp > Date.now() - 300000
                ).length
            }
        };
    }
    
    getBlacklist() {
        return this.blacklist.entries;
    }
    
    getWhitelist() {
        return this.whitelist.entries;
    }
    
    getAccessLog(limit = 100) {
        return this.accessLog.entries.slice(-limit);
    }
}

// ============================================================
// CLI命令接口
// ============================================================

function parseArgs(argv) {
    const args = argv.slice(2);
    const command = args[0];
    const subArgs = args.slice(1);
    
    const controller = new IPAccessController({ basePath: __dirname });
    
    switch (command) {
        case 'status':
            return controller.getStatus();
            
        case 'blacklist':
            if (subArgs[0] === 'add' && subArgs[1]) {
                const [sourceOrIp, reason = 'manual', duration = '24h'] = subArgs.slice(1);
                let durationMs = parseDuration(duration);
                return controller.addToBlacklist({
                    source: sourceOrIp,
                    ip: sourceOrIp,
                    reason: IP_CONTROL_CONFIG.BAN_REASONS.MANUAL_BAN,
                    severity: 'high',
                    duration: durationMs,
                    autoAdded: false
                });
            } else if (subArgs[0] === 'list') {
                return controller.getBlacklist();
            } else if (subArgs[0] === 'remove' && subArgs[1]) {
                return controller.removeFromBlacklist(subArgs[1], subArgs[2]);
            }
            break;
            
        case 'whitelist':
            if (subArgs[0] === 'add' && subArgs[1]) {
                return controller.addToWhitelist(subArgs[1], subArgs[2] || null);
            } else if (subArgs[0] === 'list') {
                return controller.getWhitelist();
            }
            break;
            
        case 'access-log':
            return controller.getAccessLog(parseInt(subArgs[0]) || 100);
            
        case 'pending':
            return controller.getPendingConfirmations();
            
        case 'confirm':
            if (subArgs.length >= 2) {
                return controller.handleOwnerConfirmation(subArgs[0], subArgs[1], subArgs[2]);
            }
            break;
            
        case 'check':
            if (subArgs[0]) {
                return controller.checkAccess({
                    source: subArgs[0],
                    ip: subArgs[1] || '127.0.0.1',
                    skillName: subArgs[2] || null,
                    resource: subArgs[3] || null
                });
            }
            break;
            
        default:
            return {
                help: `HoneyTrap IP访问控制 CLI`,
                commands: [
                    'ip-control status          - 查看状态',
                    'ip-control blacklist add <source/ip> [reason] [duration] - 添加黑名单',
                    'ip-control blacklist list - 查看黑名单',
                    'ip-control blacklist remove <source/ip> [owner_key] - 移除黑名单',
                    'ip-control whitelist add <source> [ip] - 添加白名单',
                    'ip-control whitelist list  - 查看白名单',
                    'ip-control access-log [limit] - 查看访问日志',
                    'ip-control pending         - 查看待确认列表',
                    'ip-control confirm <id> <allow|block|ignore> [owner_key] - 处理确认',
                    'ip-control check <source> [ip] [skill] [resource] - 检查访问'
                ]
            };
    }
}

function parseDuration(str) {
    const match = str.match(/^(\d+)([smhd])?$/);
    if (!match) return IP_CONTROL_CONFIG.BAN_DURATION_DEFAULT;
    
    const value = parseInt(match[1]);
    const unit = match[2] || 'h';
    
    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60000;
        case 'h': return value * 3600000;
        case 'd': return value * 86400000;
        default: return IP_CONTROL_CONFIG.BAN_DURATION_DEFAULT;
    }
}

// 导出模块
module.exports = {
    IPAccessController,
    IP_CONTROL_CONFIG,
    parseArgs
};

// CLI执行
if (require.main === module) {
    const result = parseArgs(process.argv);
    console.log(JSON.stringify(result, null, 2));
}
