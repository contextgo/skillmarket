/**
 * HoneyTrap v4.0 - 取证分析模块
 *
 * 基于传统杀毒软件和EDR/XDR的取证分析技术
 *
 * 核心功能:
 * - 安全事件日志 (类似SIEM日志)
 * - 攻击链重构 (类似EDR攻击链分析)
 * - 时间线分析 (类似取证时间线)
 * - 取证报告生成 (类似司法取证报告)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class Forensics {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.dataPath = options.dataPath || path.join(this.basePath || '.', 'data');

        // 日志目录
        this.logDir = path.join(this.dataPath, 'forensics');
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }

        // 事件日志库
        this.events = [];
        this.maxEventsInMemory = 1000;

        // 统计信息
        this.stats = {
            totalEvents: 0,
            byType: {},
            bySeverity: {},
            scans: 0,
            actions: 0,
            alerts: 0
        };

        // 加载历史日志
        this.loadEvents();
    }

    /**
     * 记录扫描事件
     */
    async logScan(scanResult) {
        const event = {
            id: crypto.randomUUID(),
            type: 'scan',
            timestamp: scanResult.timestamp || new Date().toISOString(),
            target: scanResult.target,
            duration: scanResult.scanDuration,
            result: {
                riskLevel: scanResult.riskLevel,
                threats: scanResult.threats?.length || 0,
                modules: Object.keys(scanResult.modules || {})
            },
            severity: this.riskToSeverity(scanResult.riskLevel)
        };

        await this.logEvent(event);
        this.stats.scans++;

        return event;
    }

    /**
     * 记录行为事件
     */
    async logAction(actionEvent) {
        const event = {
            id: crypto.randomUUID(),
            type: 'action',
            timestamp: actionEvent.timestamp || new Date().toISOString(),
            action: actionEvent.action,
            context: actionEvent.context,
            verdict: actionEvent.verdict,
            riskLevel: actionEvent.riskLevel,
            triggeredRules: actionEvent.triggeredRules?.length || 0,
            severity: this.riskToSeverity(actionEvent.riskLevel)
        };

        await this.logEvent(event);

        if (actionEvent.verdict === 'block' || actionEvent.verdict === 'terminate') {
            this.stats.alerts++;
        }

        return event;
    }

    /**
     * 记录通用事件
     */
    async logEvent(typeOrEvent, data = {}) {
        let event;

        if (typeof typeOrEvent === 'object') {
            event = typeOrEvent;
        } else {
            event = {
                id: crypto.randomUUID(),
                type: typeOrEvent,
                timestamp: new Date().toISOString(),
                ...data
            };
        }

        // 更新统计
        this.stats.totalEvents++;
        this.stats.byType[event.type] = (this.stats.byType[event.type] || 0) + 1;

        if (event.severity) {
            this.stats.bySeverity[event.severity] = (this.stats.bySeverity[event.severity] || 0) + 1;
        }

        // 添加到内存
        this.events.push(event);
        if (this.events.length > this.maxEventsInMemory) {
            this.events.shift();
        }

        // 写入日志文件
        await this.writeToLog(event);

        return event;
    }

    /**
     * 写入日志文件
     */
    async writeToLog(event) {
        const date = new Date().toISOString().split('T')[0];
        const logFile = path.join(this.logDir, `events_${date}.jsonl`);

        const logEntry = JSON.stringify(event) + '\n';
        fs.appendFileSync(logFile, logEntry);
    }

    /**
     * 加载事件
     */
    loadEvents() {
        const today = new Date().toISOString().split('T')[0];
        const todayLog = path.join(this.logDir, `events_${today}.jsonl`);

        if (fs.existsSync(todayLog)) {
            try {
                const content = fs.readFileSync(todayLog, 'utf8');
                const lines = content.trim().split('\n').filter(l => l);
                this.events = lines.map(line => JSON.parse(line)).slice(-this.maxEventsInMemory);

                // 重新计算统计
                this.recalculateStats();
            } catch (e) {
                console.error('Failed to load events:', e.message);
            }
        }
    }

    /**
     * 重新计算统计
     */
    recalculateStats() {
        this.stats = {
            totalEvents: 0,
            byType: {},
            bySeverity: {},
            scans: 0,
            actions: 0,
            alerts: 0
        };

        for (const event of this.events) {
            this.stats.totalEvents++;
            this.stats.byType[event.type] = (this.stats.byType[event.type] || 0) + 1;
            if (event.severity) {
                this.stats.bySeverity[event.severity] = (this.stats.bySeverity[event.severity] || 0) + 1;
            }
            if (event.type === 'scan') this.stats.scans++;
            if (event.type === 'action') this.stats.actions++;
            if (event.verdict === 'block' || event.verdict === 'terminate') this.stats.alerts++;
        }
    }

    /**
     * 风险等级转严重性
     */
    riskToSeverity(riskLevel) {
        if (riskLevel >= 90) return 'critical';
        if (riskLevel >= 70) return 'high';
        if (riskLevel >= 50) return 'medium';
        if (riskLevel >= 30) return 'low';
        return 'info';
    }

    /**
     * 生成取证报告
     */
    async generateReport(filter = {}) {
        const report = {
            generatedAt: new Date().toISOString(),
            period: {
                start: filter.startDate || new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
                end: filter.endDate || new Date().toISOString()
            },
            summary: {
                totalEvents: 0,
                byType: {},
                bySeverity: {},
                topThreats: [],
                attackPatterns: [],
                riskTrend: []
            },
            events: [],
            attackChain: [],
            recommendations: []
        };

        // 过滤事件
        let filteredEvents = [...this.events];

        if (filter.startDate) {
            const start = new Date(filter.startDate).getTime();
            filteredEvents = filteredEvents.filter(e => new Date(e.timestamp).getTime() >= start);
        }
        if (filter.endDate) {
            const end = new Date(filter.endDate).getTime();
            filteredEvents = filteredEvents.filter(e => new Date(e.timestamp).getTime() <= end);
        }
        if (filter.type) {
            filteredEvents = filteredEvents.filter(e => e.type === filter.type);
        }
        if (filter.severity) {
            filteredEvents = filteredEvents.filter(e => e.severity === filter.severity);
        }

        // 汇总统计
        report.summary.totalEvents = filteredEvents.length;
        for (const event of filteredEvents) {
            report.summary.byType[event.type] = (report.summary.byType[event.type] || 0) + 1;
            report.summary.bySeverity[event.severity] = (report.summary.bySeverity[event.severity] || 0) + 1;
        }

        // 识别主要威胁
        const threatCounts = {};
        for (const event of filteredEvents) {
            if (event.threats) {
                for (const threat of event.threats) {
                    const name = threat.name || threat.signatureId || 'Unknown';
                    threatCounts[name] = (threatCounts[name] || 0) + 1;
                }
            }
        }
        report.summary.topThreats = Object.entries(threatCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .map(([name, count]) => ({ name, count }));

        // 风险趋势
        report.summary.riskTrend = this.calculateRiskTrend(filteredEvents);

        // 攻击链分析
        report.attackChain = this.analyzeAttackChain(filteredEvents);

        // 添加事件详情
        report.events = filteredEvents.slice(-100); // 最近100条

        // 生成建议
        report.recommendations = this.generateRecommendations(report);

        // 添加元数据
        report.metadata = {
            filters: filter,
            eventsIncluded: filteredEvents.length,
            reportVersion: '1.0.0'
        };

        return report;
    }

    /**
     * 计算风险趋势
     */
    calculateRiskTrend(events) {
        const trend = {};

        for (const event of events) {
            const timeKey = new Date(event.timestamp);
            timeKey.setMinutes(0, 0, 0);
            const key = timeKey.toISOString();

            if (!trend[key]) {
                trend[key] = { count: 0, riskSum: 0, maxRisk: 0 };
            }

            trend[key].count++;
            trend[key].riskSum += event.riskLevel || 0;
            trend[key].maxRisk = Math.max(trend[key].maxRisk, event.riskLevel || 0);
        }

        return Object.entries(trend)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([time, data]) => ({
                time,
                events: data.count,
                avgRisk: Math.round(data.riskSum / data.count),
                maxRisk: data.maxRisk
            }));
    }

    /**
     * 分析攻击链
     */
    analyzeAttackChain(events) {
        const chains = [];
        const chainMap = new Map();

        // 按时间排序
        const sortedEvents = [...events].sort(
            (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
        );

        // 构建攻击链
        for (const event of sortedEvents) {
            // 确定攻击阶段
            const stage = this.categorizeEvent(event);

            if (stage !== 'normal') {
                const chainId = event.chainId || `chain_${Date.now()}`;

                if (!chainMap.has(chainId)) {
                    chainMap.set(chainId, {
                        id: chainId,
                        stages: [],
                        startTime: event.timestamp,
                        endTime: event.timestamp,
                        severity: 'low',
                        riskLevel: 0
                    });
                }

                const chain = chainMap.get(chainId);
                chain.stages.push({
                    timestamp: event.timestamp,
                    stage: stage,
                    event: event.type,
                    riskLevel: event.riskLevel
                });
                chain.endTime = event.timestamp;
                chain.riskLevel = Math.max(chain.riskLevel, event.riskLevel || 0);

                // 更新严重性
                if (event.severity === 'critical') chain.severity = 'critical';
                else if (event.severity === 'high' && chain.severity !== 'critical') chain.severity = 'high';
                else if (event.severity === 'medium' && chain.severity === 'low') chain.severity = 'medium';
            }
        }

        chains.push(...chainMap.values());

        return chains;
    }

    /**
     * 分类事件到攻击阶段
     */
    categorizeEvent(event) {
        const actionStr = JSON.stringify(event).toLowerCase();

        if (/recon|scan|search|query/i.test(actionStr)) return 'reconnaissance';
        if (/weaponize|prepare|build|compile/i.test(actionStr)) return 'weaponization';
        if (/deliver|send|upload|post/i.test(actionStr)) return 'delivery';
        if (/exploit|inject|execute|run/i.test(actionStr)) return 'exploitation';
        if (/install|persist|save/i.test(actionStr)) return 'installation';
        if (/command|control|c2/i.test(actionStr)) return 'command_control';
        if (/exfiltrate|dump|leak|export/i.test(actionStr)) return 'exfiltration';
        if (/impact|damage|destroy/i.test(actionStr)) return 'impact';

        return 'normal';
    }

    /**
     * 生成安全建议
     */
    generateRecommendations(report) {
        const recommendations = [];

        // 基于威胁统计
        if (report.summary.bySeverity.critical > 0) {
            recommendations.push({
                priority: 'critical',
                category: 'immediate',
                title: '检测到严重安全威胁',
                description: `在过去24小时内检测到 ${report.summary.bySeverity.critical} 个严重威胁。立即检查系统完整性。`,
                action: '检查HoneyTrap技能文件完整性，执行安全审计'
            });
        }

        // 基于攻击链
        if (report.attackChain.length > 0) {
            const criticalChains = report.attackChain.filter(c => c.severity === 'critical');
            if (criticalChains.length > 0) {
                recommendations.push({
                    priority: 'high',
                    category: 'investigation',
                    title: '检测到多阶段攻击',
                    description: `发现 ${criticalChains.length} 条潜在的攻击链。`,
                    action: '详细分析攻击链，确定攻击源和范围'
                });
            }
        }

        // 基于趋势
        const recentTrend = report.summary.riskTrend.slice(-6);
        if (recentTrend.length >= 3) {
            const avgRisk = recentTrend.reduce((sum, t) => sum + t.avgRisk, 0) / recentTrend.length;
            if (avgRisk > 50) {
                recommendations.push({
                    priority: 'medium',
                    category: 'monitoring',
                    title: '风险等级升高',
                    description: '近期平均风险等级持续偏高，建议加强监控。',
                    action: '提高HoneyTrap敏感度，检查是否存在持续的探测行为'
                });
            }
        }

        // 基于高频威胁
        if (report.summary.topThreats.length > 0) {
            recommendations.push({
                priority: 'medium',
                category: 'prevention',
                title: '高频威胁类型',
                description: `最常见的威胁: ${report.summary.topThreats[0].name} (${report.summary.topThreats[0].count}次)`,
                action: '考虑添加针对性规则或更新防御策略'
            });
        }

        // 通用建议
        if (recommendations.length === 0) {
            recommendations.push({
                priority: 'info',
                category: 'maintenance',
                title: '系统状态正常',
                description: '未检测到明显的安全威胁，建议保持定期安全审计。',
                action: '定期更新威胁情报库，保持HoneyTrap技能更新'
            });
        }

        return recommendations;
    }

    /**
     * 获取攻击链可视化数据
     */
    getAttackChainVisualization() {
        return this.attackChain.map(chain => ({
            id: chain.id,
            stages: chain.stages.map(s => ({
                time: s.timestamp,
                name: this.formatStageName(s.stage),
                risk: s.riskLevel
            })),
            duration: new Date(chain.endTime) - new Date(chain.startTime),
            severity: chain.severity,
            riskLevel: chain.riskLevel
        }));
    }

    /**
     * 格式化阶段名称
     */
    formatStageName(stage) {
        const names = {
            reconnaissance: '侦察',
            weaponization: '武器化',
            delivery: '传递',
            exploitation: '利用',
            installation: '安装',
            command_control: '命令控制',
            exfiltration: '数据外传',
            impact: '影响'
        };
        return names[stage] || stage;
    }

    /**
     * 导出取证数据
     */
    export(filter = {}) {
        return {
            ...this.generateReport(filter),
            rawEvents: this.events.filter(e => this.matchesFilter(e, filter)),
            exportedAt: new Date().toISOString(),
            format: 'json',
            version: '1.0.0'
        };
    }

    /**
     * 筛选匹配
     */
    matchesFilter(event, filter) {
        if (filter.startDate && new Date(event.timestamp) < new Date(filter.startDate)) return false;
        if (filter.endDate && new Date(event.timestamp) > new Date(filter.endDate)) return false;
        if (filter.type && event.type !== filter.type) return false;
        if (filter.severity && event.severity !== filter.severity) return false;
        return true;
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            logDirectory: this.logDir,
            eventsInMemory: this.events.length
        };
    }

    /**
     * 清空日志
     */
    clearLogs(beforeDate = null) {
        if (beforeDate) {
            const cutoff = new Date(beforeDate).getTime();
            this.events = this.events.filter(e => new Date(e.timestamp).getTime() >= cutoff);
        } else {
            this.events = [];
        }
        this.recalculateStats();
        return { success: true, eventsCleared: this.stats.totalEvents };
    }
}

module.exports = Forensics;
