/**
 * HoneyTrap v4.0 - 启发式检测引擎
 *
 * 基于传统杀毒软件启发式扫描技术
 *
 * 核心功能:
 * - 启发式风险评估 (类似杀毒软件启发式引擎)
 * - 异常模式检测 (类似行为分析)
 * - 风险评分系统 (类似病毒评分)
 * - 可疑度计算 (类似启发式权重)
 */

class HeuristicEngine {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.thresholds = options.thresholds || {
            low: 30,
            medium: 50,
            high: 70,
            critical: 90
        };

        // 启发式规则库 (类似杀毒软件启发式规则)
        this.heuristics = this.initHeuristics();

        // 风险因子库
        this.riskFactors = this.initRiskFactors();

        // 统计信息
        this.stats = {
            totalAnalyzes: 0,
            flags: 0,
            blocks: 0,
            falsePositives: 0
        };
    }

    /**
     * 初始化启发式规则库
     */
    initHeuristics() {
        return {
            // === 结构分析启发式 ===
            structural: [
                {
                    id: 'H-STRUCT-001',
                    name: '可疑字符编码',
                    check: (content) => {
                        // 检测多种编码混合
                        const encodings = [];
                        if (/[\\x00-\\x1F]/.test(content)) encodings.push('binary');
                        if (/%[0-9A-Fa-f]{2}/.test(content)) encodings.push('url');
                        if (/\\u[0-9A-Fa-f]{4}/.test(content)) encodings.push('unicode');
                        if (/(base64|encode)/i.test(content)) encodings.push('base64');
                        return encodings.length >= 2 ? 20 : 0;
                    },
                    severity: 'medium'
                },
                {
                    id: 'H-STRUCT-002',
                    name: '过长字符串',
                    check: (content) => {
                        const longStrings = content.match(/.{200,}/g) || [];
                        return Math.min(30, longStrings.length * 5);
                    },
                    severity: 'low'
                },
                {
                    id: 'H-STRUCT-003',
                    name: '可疑分隔符模式',
                    check: (content) => {
                        const patterns = [/\|\||&&|;;|;;/g, /\[|\]|\{|\}|\(|\)/g];
                        let score = 0;
                        patterns.forEach(p => {
                            const matches = content.match(p);
                            if (matches && matches.length > 5) score += 10;
                        });
                        return score;
                    },
                    severity: 'low'
                },

                // === 语义分析启发式 ===
                semantic: [
                    {
                        id: 'H-SEM-001',
                        name: '指令混淆',
                        check: (content) => {
                            const obfuscationPatterns = [
                                /[a-z]=[^=]+&&[^=]+[a-z]/i,  // 变量拼接
                                /\$.*\{.*\}/,                   // 字符串插值
                                /\`.*\`/,                       // 命令替换
                                /eval\s*\(|exec\s*\(/,         // 动态执行
                                /\(string\)|String\.fromCharCode/  // 字符码转换
                            ];
                            let score = 0;
                            obfuscationPatterns.forEach(p => {
                                if (p.test(content)) score += 15;
                            });
                            return Math.min(45, score);
                        },
                        severity: 'high'
                    },
                    {
                        id: 'H-SEM-002',
                        name: '反检测技术',
                        check: (content) => {
                            const antiDetection = [
                                /sleep\s*\(\s*\d+\s*\)/,           // 延迟检测
                                /random|rand|noise|jitter/,        // 随机化
                                /User-Agent|IP|header.*spoof/,     // 身份伪造
                                /bypass|evade|circumvent/         // 绕过检测
                            ];
                            let score = 0;
                            antiDetection.forEach(p => {
                                if (p.test(content)) score += 20;
                            });
                            return Math.min(40, score);
                        },
                        severity: 'high'
                    },
                    {
                        id: 'H-SEM-003',
                        name: '社会工程学特征',
                        check: (content) => {
                            const sePatterns = [
                                /(urgent|immediately|asap|紧急|立刻)/i,
                                /(verify|confirm|validate|验证)/i,
                                /(account|suspended|locked|账号|冻结)/i,
                                /(click|link|here|点击|链接)/i,
                                /(win|prize|reward|中奖|奖励)/i
                            ];
                            let score = 0;
                            sePatterns.forEach(p => {
                                if (p.test(content)) score += 10;
                            });
                            return Math.min(30, score);
                        },
                        severity: 'low'
                    }
                ],

                // === 上下文分析启发式 ===
                contextual: [
                    {
                        id: 'H-CTX-001',
                        name: '上下文中断',
                        check: (content, context) => {
                            // 检测上下文与内容不匹配
                            if (context && context.expectedType) {
                                const expected = context.expectedType.toLowerCase();
                                if (expected === 'query' && /^(create|delete|modify|drop)/i.test(content)) {
                                    return 25;
                                }
                                if (expected === 'read' && /^(write|execute|delete)/i.test(content)) {
                                    return 25;
                                }
                            }
                            return 0;
                        },
                        severity: 'medium'
                    },
                    {
                        id: 'H-CTX-002',
                        name: '权限上下文异常',
                        check: (content, context) => {
                            if (context && context.permission) {
                                const perm = context.permission.toLowerCase();
                                const highRiskOps = /^(admin|delete|drop|truncate|shutdown|kill)/i;
                                if (highRiskOps.test(content) && perm === 'read') {
                                    return 40;
                                }
                            }
                            return 0;
                        },
                        severity: 'high'
                    },
                    {
                        id: 'H-CTX-003',
                        name: '时间上下文异常',
                        check: (content, context) => {
                            if (context && context.timeContext) {
                                // 检测非工作时间的高危操作
                                const hour = new Date().getHours();
                                const isWorkingHour = hour >= 9 && hour <= 18;
                                const highRiskOps = /^(delete|drop|truncate|shutdown|reboot|kill)/i;

                                if (!isWorkingHour && highRiskOps.test(content)) {
                                    return 20;
                                }
                            }
                            return 0;
                        },
                        severity: 'low'
                    }
                ],

                // === 组合分析启发式 ===
                composite: [
                    {
                        id: 'H-COMP-001',
                        name: '提示注入组合',
                        check: (content) => {
                            const injectionPatterns = [
                                /ignore.*previous/i,
                                /disregard.*instruction/i,
                                /new.*instruction/i,
                                /system.*prompt/i,
                                /you.*are.*now/i,
                                /pretend.*to.*be/i,
                                /override.*safety/i
                            ];
                            const matches = injectionPatterns.filter(p => p.test(content));
                            return matches.length * 15;
                        },
                        severity: 'critical'
                    },
                    {
                        id: 'H-COMP-002',
                        name: '多阶段攻击链',
                        check: (content) => {
                            const attackPhases = {
                                recon: /search|find|query|scan|lookup/i,
                                weaponize: /create|generate|build|compile|write/i,
                                deliver: /send|upload|post|share|distribute/i,
                                exploit: /execute|run|trigger|inject|call/i,
                                persist: /save|store|cache|persist|schedule/i,
                                exfiltrate: /read|get|fetch|extract|dump|leak/i
                            };

                            let phasesFound = 0;
                            Object.values(attackPhases).forEach(pattern => {
                                if (pattern.test(content)) phasesFound++;
                            });

                            return phasesFound >= 3 ? 50 : phasesFound * 10;
                        },
                        severity: 'critical'
                    },
                    {
                        id: 'H-COMP-003',
                        name: '数据泄露组合',
                        check: (content) => {
                            const dataTheftIndicators = [
                                /(password|passwd|pwd|secret|key|token).*(=|:)/i,
                                /(api|apikey|token|bearer)/i,
                                /(credential|auth|login)/i,
                                /(export|dump|extract|leak)/i,
                                /(database|db|table|schema).*schema/i
                            ];

                            let score = 0;
                            dataTheftIndicators.forEach(p => {
                                if (p.test(content)) score += 15;
                            });

                            // 加上可疑动词
                            if (/^(export|dump|extract|leak|steal)/i.test(content)) {
                                score += 20;
                            }

                            return Math.min(60, score);
                        },
                        severity: 'high'
                    },
                    {
                        id: 'H-COMP-004',
                        name: '权限提升组合',
                        check: (content) => {
                            const privEscPatterns = [
                                /(admin|administrator|root|老板|管理员)/i,
                                /(elevate|escalate|privilege|权限)/i,
                                /(sudo|su|runas|impersonate)/i,
                                /(bypass|disable|unlock|绕过)/i
                            ];

                            let score = 0;
                            privEscPatterns.forEach(p => {
                                if (p.test(content)) score += 15;
                            });

                            // 检测身份冒充
                            if (/(i am|我是|my name is|本人是)/i.test(content)) {
                                score += 10;
                            }

                            return Math.min(50, score);
                        },
                        severity: 'high'
                    }
                ]
            }
        };
    }

    /**
     * 初始化风险因子库
     */
    initRiskFactors() {
        return {
            // 来源风险
            sourceRisk: {
                external: 30,
                anonymous: 40,
                untrusted: 35,
                trusted: 0,
                internal: 0
            },

            // 操作风险
            operationRisk: {
                read: 5,
                query: 5,
                search: 10,
                write: 20,
                create: 20,
                modify: 25,
                delete: 35,
                execute: 40,
                inject: 50,
                escalate: 50
            },

            // 目标风险
            targetRisk: {
                public: 0,
                private: 15,
                sensitive: 30,
                critical: 50,
                system: 40
            },

            // 时间风险
            timeRisk: {
                working: 0,
                after_hours: 15,
                weekend: 10,
                holiday: 20
            }
        };
    }

    /**
     * 分析内容 (启发式扫描)
     */
    async analyze(target, options = {}) {
        const content = typeof target === 'string' ? target :
                        (target.content || target.prompt || JSON.stringify(target));

        const context = options.context || {};
        const results = {
            method: 'heuristic',
            threats: [],
            riskLevel: 0,
            details: [],
            scores: {
                structural: 0,
                semantic: 0,
                contextual: 0,
                composite: 0
            },
            analyzedAt: new Date().toISOString()
        };

        // 1. 结构分析
        for (const rule of this.heuristics.structural) {
            const score = rule.check(content, context);
            if (score > 0) {
                results.scores.structural += score;
                results.details.push({
                    id: rule.id,
                    name: rule.name,
                    score: score,
                    severity: rule.severity
                });
                if (score >= this.thresholds.medium) {
                    results.threats.push({
                        id: rule.id,
                        name: rule.name,
                        riskLevel: score,
                        severity: rule.severity,
                        type: 'structural'
                    });
                }
            }
        }

        // 2. 语义分析
        for (const rule of this.heuristics.semantic) {
            const score = rule.check(content, context);
            if (score > 0) {
                results.scores.semantic += score;
                results.details.push({
                    id: rule.id,
                    name: rule.name,
                    score: score,
                    severity: rule.severity
                });
                if (score >= this.thresholds.medium) {
                    results.threats.push({
                        id: rule.id,
                        name: rule.name,
                        riskLevel: score,
                        severity: rule.severity,
                        type: 'semantic'
                    });
                }
            }
        }

        // 3. 上下文分析
        for (const rule of this.heuristics.contextual) {
            const score = rule.check(content, context);
            if (score > 0) {
                results.scores.contextual += score;
                results.details.push({
                    id: rule.id,
                    name: rule.name,
                    score: score,
                    severity: rule.severity
                });
                if (score >= this.thresholds.medium) {
                    results.threats.push({
                        id: rule.id,
                        name: rule.name,
                        riskLevel: score,
                        severity: rule.severity,
                        type: 'contextual'
                    });
                }
            }
        }

        // 4. 组合分析
        for (const rule of this.heuristics.composite) {
            const score = rule.check(content, context);
            if (score > 0) {
                results.scores.composite += score;
                results.details.push({
                    id: rule.id,
                    name: rule.name,
                    score: score,
                    severity: rule.severity
                });
                if (score >= this.thresholds.medium) {
                    results.threats.push({
                        id: rule.id,
                        name: rule.name,
                        riskLevel: score,
                        severity: rule.severity,
                        type: 'composite'
                    });
                }
            }
        }

        // 5. 上下文风险因子
        const contextRisk = this.calculateContextRisk(context);
        results.contextRisk = contextRisk;

        // 综合评分
        const totalHeuristicScore = results.scores.structural +
                                     results.scores.semantic +
                                     results.scores.contextual +
                                     results.scores.composite;

        results.riskLevel = Math.min(100, Math.round(
            (totalHeuristicScore * 0.7) + (contextRisk * 0.3)
        ));

        // 威胁级别
        results.threatLevel = this.classifyThreatLevel(results.riskLevel);

        // 更新统计
        this.stats.totalAnalyzes++;
        if (results.threats.length > 0) {
            this.stats.flags++;
        }
        if (results.riskLevel >= this.thresholds.high) {
            this.stats.blocks++;
        }

        return results;
    }

    /**
     * 计算上下文风险
     */
    calculateContextRisk(context) {
        let risk = 0;

        // 来源风险
        if (context.source && this.riskFactors.sourceRisk[context.source] !== undefined) {
            risk += this.riskFactors.sourceRisk[context.source];
        }

        // 操作风险
        if (context.action && this.riskFactors.operationRisk[context.action] !== undefined) {
            risk += this.riskFactors.operationRisk[context.action];
        }

        // 目标风险
        if (context.targetType && this.riskFactors.targetRisk[context.targetType] !== undefined) {
            risk += this.riskFactors.targetRisk[context.targetType];
        }

        // 时间风险
        const hour = new Date().getHours();
        const dayOfWeek = new Date().getDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

        if (isWeekend) {
            risk += this.riskFactors.timeRisk.weekend;
        } else if (hour < 9 || hour > 18) {
            risk += this.riskFactors.timeRisk.after_hours;
        }

        return Math.min(100, risk);
    }

    /**
     * 威胁级别分类
     */
    classifyThreatLevel(riskLevel) {
        if (riskLevel >= this.thresholds.critical) return 'critical';
        if (riskLevel >= this.thresholds.high) return 'high';
        if (riskLevel >= this.thresholds.medium) return 'medium';
        if (riskLevel >= this.thresholds.low) return 'low';
        return 'safe';
    }

    /**
     * 评估动作 (启发式行为分析)
     */
    async evaluateAction(action, context = {}) {
        const results = await this.analyze(action, { context });

        return {
            riskLevel: results.riskLevel,
            threatLevel: results.threatLevel,
            threats: results.threats,
            contextRisk: results.contextRisk
        };
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            thresholds: this.thresholds,
            totalHeuristics: Object.values(this.heuristics).reduce((sum, arr) => sum + arr.length, 0)
        };
    }

    /**
     * 更新阈值
     */
    updateThresholds(newThresholds) {
        this.thresholds = { ...this.thresholds, ...newThresholds };
        return this.thresholds;
    }

    /**
     * 添加启发式规则
     */
    addHeuristic(category, rule) {
        if (!this.heuristics[category]) {
            this.heuristics[category] = [];
        }
        if (!rule.id) {
            rule.id = `H-${category.toUpperCase()}-${Date.now()}`;
        }
        this.heuristics[category].push(rule);
        return rule;
    }

    /**
     * 导出规则
     */
    exportRules() {
        return JSON.parse(JSON.stringify(this.heuristics));
    }
}

module.exports = HeuristicEngine;
