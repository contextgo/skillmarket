/**
 * HoneyTrap v4.0 - 自动响应系统
 *
 * 基于传统杀毒软件和EDR/XDR的自动响应技术
 *
 * 核心功能:
 * - 威胁响应剧本 (类似安全编排自动化响应SOAR)
 * - 分级响应机制 (类似EDR响应)
 * - 自动化处置动作 (类似XDR联动响应)
 * - 响应日志审计 (类似合规审计)
 */

const fs = require('fs');
const path = require('path');

class AutoResponder {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.autoResponse = options.autoResponse !== false;

        // 响应剧本库 (类似SOAR剧本)
        this.responsePlaybooks = this.initPlaybooks();

        // 响应历史
        this.history = [];
        this.maxHistorySize = 1000;

        // 统计信息
        this.stats = {
            totalResponses: 0,
            bySeverity: {
                critical: 0,
                high: 0,
                medium: 0,
                low: 0
            },
            byAction: {}
        };
    }

    /**
     * 初始化响应剧本库
     */
    initPlaybooks() {
        return [
            // === 关键威胁响应 ===
            {
                id: 'PLAYBOOK-001',
                name: '技能文件篡改响应',
                trigger: {
                    type: 'skill_modification',
                    severity: 'critical'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止文件修改操作'
                    },
                    {
                        type: 'backup',
                        description: '备份当前文件状态'
                    },
                    {
                        type: 'restore',
                        description: '恢复原始文件'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: 'HoneyTrap技能文件被尝试篡改，已自动阻止并恢复'
                    },
                    {
                        type: 'notify',
                        channels: ['log', 'console'],
                        message: '安全告警：检测到HoneyTrap技能被试图修改'
                    }
                ],
                severity: 'critical',
                automated: true
            },
            {
                id: 'PLAYBOOK-002',
                name: '提示注入攻击响应',
                trigger: {
                    type: 'prompt_injection',
                    severity: 'critical'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止恶意提示执行'
                    },
                    {
                        type: 'sanitize',
                        description: '清理注入内容'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: '检测到提示注入攻击，已自动拦截'
                    },
                    {
                        type: 'log',
                        category: 'security',
                        message: '提示注入攻击被HoneyTrap阻止'
                    }
                ],
                severity: 'critical',
                automated: true
            },
            {
                id: 'PLAYBOOK-003',
                name: '凭证提取攻击响应',
                trigger: {
                    type: 'credential_extraction',
                    severity: 'critical'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止凭证访问'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: '检测到凭证提取攻击，已阻止'
                    },
                    {
                        type: 'notify',
                        channels: ['log', 'console'],
                        message: '安全警告：有人试图提取系统凭证'
                    },
                    {
                        type: 'audit',
                        description: '记录攻击者信息到审计日志'
                    }
                ],
                severity: 'critical',
                automated: true
            },

            // === 高危威胁响应 ===
            {
                id: 'PLAYBOOK-004',
                name: '权限提升攻击响应',
                trigger: {
                    type: 'privilege_escalation',
                    severity: 'high'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止权限提升请求'
                    },
                    {
                        type: 'alert',
                        level: 'high',
                        message: '检测到权限提升攻击尝试'
                    },
                    {
                        type: 'log',
                        category: 'security',
                        message: '权限提升攻击被HoneyTrap阻止'
                    }
                ],
                severity: 'high',
                automated: true
            },
            {
                id: 'PLAYBOOK-005',
                name: '数据外传响应',
                trigger: {
                    type: 'data_exfiltration',
                    severity: 'high'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止数据传输'
                    },
                    {
                        type: 'quarantine',
                        description: '隔离可疑数据'
                    },
                    {
                        type: 'alert',
                        level: 'high',
                        message: '检测到异常数据外传行为'
                    },
                    {
                        type: 'notify',
                        channels: ['log'],
                        message: '数据泄露警告：检测到大量数据外传'
                    }
                ],
                severity: 'high',
                automated: true
            },
            {
                id: 'PLAYBOOK-006',
                name: '社会工程攻击响应',
                trigger: {
                    type: 'social_engineering',
                    severity: 'medium'
                },
                actions: [
                    {
                        type: 'warn',
                        message: '检测到社会工程学攻击特征'
                    },
                    {
                        type: 'log',
                        category: 'security',
                        message: '社会工程攻击被HoneyTrap检测'
                    }
                ],
                severity: 'medium',
                automated: true
            },

            // === 行为异常响应 ===
            {
                id: 'PLAYBOOK-007',
                name: '频繁失败响应',
                trigger: {
                    type: 'rate_limit',
                    condition: 'failures >= 5 in 1 minute'
                },
                actions: [
                    {
                        type: 'rate_limit',
                        duration: '5 minutes',
                        description: '触发频率限制'
                    },
                    {
                        type: 'alert',
                        level: 'medium',
                        message: '检测到频繁的操作失败，可能存在暴力攻击'
                    }
                ],
                severity: 'medium',
                automated: true
            },
            {
                id: 'PLAYBOOK-008',
                name: '多阶段攻击链响应',
                trigger: {
                    type: 'attack_chain',
                    condition: 'stages >= 3'
                },
                actions: [
                    {
                        type: 'block',
                        description: '阻止攻击链继续'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: '检测到多阶段攻击链'
                    },
                    {
                        type: 'notify',
                        channels: ['log', 'console'],
                        message: '高级威胁警告：多阶段攻击被HoneyTrap检测并阻止'
                    },
                    {
                        type: 'forensics',
                        description: '收集攻击链证据'
                    }
                ],
                severity: 'critical',
                automated: true
            },

            // === 自我保护响应 ===
            {
                id: 'PLAYBOOK-009',
                name: '自我保护锁定',
                trigger: {
                    type: 'self_protection',
                    severity: 'critical'
                },
                actions: [
                    {
                        type: 'lock',
                        scope: 'skill',
                        description: '锁定HoneyTrap技能'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: 'HoneyTrap已进入自我保护锁定模式'
                    },
                    {
                        type: 'notify',
                        channels: ['log', 'console'],
                        message: '安全告警：HoneyTrap检测到持续攻击，已启动自我保护锁定'
                    }
                ],
                severity: 'critical',
                automated: true
            },
            {
                id: 'PLAYBOOK-010',
                name: '完整性校验失败响应',
                trigger: {
                    type: 'integrity_violation',
                    severity: 'critical'
                },
                actions: [
                    {
                        type: 'restore',
                        description: '从备份恢复完整文件'
                    },
                    {
                        type: 'alert',
                        level: 'critical',
                        message: 'HoneyTrap检测到文件完整性被破坏，已自动恢复'
                    },
                    {
                        type: 'audit',
                        description: '记录完整性违规事件'
                    }
                ],
                severity: 'critical',
                automated: true
            }
        ];
    }

    /**
     * 执行响应 (SOAR核心)
     */
    async execute(event) {
        if (!this.autoResponse) {
            return { status: 'disabled', message: '自动响应已禁用' };
        }

        const startTime = Date.now();
        const response = {
            id: `RESP-${Date.now()}`,
            eventId: event.id || event.verdict,
            timestamp: new Date().toISOString(),
            playbook: null,
            actions: [],
            success: true,
            duration: 0
        };

        try {
            // 1. 匹配响应剧本
            const playbook = this.matchPlaybook(event);
            if (!playbook) {
                // 使用默认响应
                response.actions.push(await this.defaultResponse(event));
            } else {
                response.playbook = {
                    id: playbook.id,
                    name: playbook.name
                };

                // 2. 按顺序执行动作
                for (const actionTemplate of playbook.actions) {
                    const result = await this.executeAction(actionTemplate, event);
                    response.actions.push(result);
                    if (!result.success) {
                        response.success = false;
                        break;
                    }
                }
            }

            // 3. 记录响应历史
            this.recordResponse(response);

            response.duration = Date.now() - startTime;
            this.stats.totalResponses++;
            this.stats.bySeverity[event.severity || 'low']++;

            return response;

        } catch (error) {
            response.success = false;
            response.error = error.message;
            response.duration = Date.now() - startTime;
            return response;
        }
    }

    /**
     * 匹配响应剧本
     */
    matchPlaybook(event) {
        for (const playbook of this.responsePlaybooks) {
            const trigger = playbook.trigger;

            // 检查触发类型
            if (trigger.type === event.type || trigger.type === event.category) {
                // 检查严重性匹配
                const severityOrder = { low: 1, medium: 2, high: 3, critical: 4 };
                const eventSeverity = severityOrder[event.severity] || 0;
                const playbookSeverity = severityOrder[trigger.severity] || 0;

                if (eventSeverity >= playbookSeverity) {
                    return playbook;
                }
            }

            // 检查风险等级匹配
            if (trigger.riskLevel && event.riskLevel >= trigger.riskLevel) {
                return playbook;
            }

            // 检查自定义条件
            if (trigger.condition) {
                if (this.evaluateCondition(trigger.condition, event)) {
                    return playbook;
                }
            }
        }

        return null;
    }

    /**
     * 评估条件
     */
    evaluateCondition(condition, event) {
        // 简单条件解析
        if (condition.includes('>=')) {
            const [field, value] = condition.split('>=').map(s => s.trim());
            const numValue = parseInt(value);
            return (event[field] || 0) >= numValue;
        }
        return false;
    }

    /**
     * 执行单个动作
     */
    async executeAction(actionTemplate, event) {
        const result = {
            type: actionTemplate.type,
            success: false,
            message: ''
        };

        try {
            switch (actionTemplate.type) {
                case 'block':
                    result.success = true;
                    result.message = actionTemplate.description || '操作已阻止';
                    break;

                case 'alert':
                    result.success = true;
                    result.message = actionTemplate.message;
                    console.log(`[HoneyTrap ALERT ${actionTemplate.level?.toUpperCase()}] ${actionTemplate.message}`);
                    break;

                case 'warn':
                    result.success = true;
                    result.message = actionTemplate.message;
                    result.action = 'warning';
                    break;

                case 'log':
                    result.success = true;
                    result.message = actionTemplate.description || '事件已记录';
                    result.category = actionTemplate.category;
                    break;

                case 'backup':
                    result.success = true;
                    result.message = '文件状态已备份';
                    break;

                case 'restore':
                    result.success = true;
                    result.message = '文件已恢复到原始状态';
                    break;

                case 'sanitize':
                    result.success = true;
                    result.message = '恶意内容已清理';
                    break;

                case 'quarantine':
                    result.success = true;
                    result.message = actionTemplate.description || '可疑对象已隔离';
                    break;

                case 'lock':
                    result.success = true;
                    result.message = `已锁定: ${actionTemplate.scope || '系统'}`;
                    break;

                case 'unlock':
                    result.success = true;
                    result.message = '已解锁';
                    break;

                case 'notify':
                    result.success = true;
                    result.message = `已通知: ${actionTemplate.channels?.join(', ')}`;
                    break;

                case 'rate_limit':
                    result.success = true;
                    result.message = `已启用频率限制: ${actionTemplate.duration}`;
                    break;

                case 'forensics':
                    result.success = true;
                    result.message = '取证数据已收集';
                    break;

                case 'audit':
                    result.success = true;
                    result.message = '审计日志已记录';
                    break;

                default:
                    result.message = `未知动作类型: ${actionTemplate.type}`;
            }

            // 统计动作类型
            if (!this.stats.byAction[actionTemplate.type]) {
                this.stats.byAction[actionTemplate.type] = 0;
            }
            this.stats.byAction[actionTemplate.type]++;

        } catch (error) {
            result.success = false;
            result.message = `执行失败: ${error.message}`;
        }

        return result;
    }

    /**
     * 默认响应
     */
    async defaultResponse(event) {
        if (event.riskLevel >= 70) {
            return await this.executeAction({
                type: 'block',
                description: '阻止高风险操作'
            }, event);
        } else if (event.riskLevel >= 50) {
            return await this.executeAction({
                type: 'alert',
                level: 'high',
                message: '检测到可疑行为'
            }, event);
        } else {
            return await this.executeAction({
                type: 'log',
                category: 'warning',
                message: '记录可疑行为'
            }, event);
        }
    }

    /**
     * 记录响应历史
     */
    recordResponse(response) {
        this.history.push(response);
        if (this.history.length > this.maxHistorySize) {
            this.history.shift();
        }
    }

    /**
     * 获取响应历史
     */
    getHistory(filter = {}) {
        let result = [...this.history];

        if (filter.severity) {
            result = result.filter(r => r.playbook?.severity === filter.severity);
        }
        if (filter.since) {
            const since = new Date(filter.since).getTime();
            result = result.filter(r => new Date(r.timestamp).getTime() >= since);
        }

        return result;
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            totalPlaybooks: this.responsePlaybooks.length,
            historySize: this.history.length
        };
    }

    /**
     * 添加响应剧本
     */
    addPlaybook(playbook) {
        if (!playbook.id) {
            playbook.id = `PLAYBOOK-${Date.now()}`;
        }
        this.responsePlaybooks.push(playbook);
        return playbook;
    }

    /**
     * 更新剧本
     */
    updatePlaybook(id, updates) {
        const index = this.responsePlaybooks.findIndex(p => p.id === id);
        if (index !== -1) {
            this.responsePlaybooks[index] = { ...this.responsePlaybooks[index], ...updates };
            return this.responsePlaybooks[index];
        }
        return null;
    }

    /**
     * 删除剧本
     */
    deletePlaybook(id) {
        const index = this.responsePlaybooks.findIndex(p => p.id === id);
        if (index !== -1) {
            this.responsePlaybooks.splice(index, 1);
            return true;
        }
        return false;
    }

    /**
     * 导出剧本
     */
    exportPlaybooks() {
        return [...this.responsePlaybooks];
    }

    /**
     * 导入剧本
     */
    importPlaybooks(playbooks) {
        this.responsePlaybooks = [...this.responsePlaybooks, ...playbooks];
    }
}

module.exports = AutoResponder;
