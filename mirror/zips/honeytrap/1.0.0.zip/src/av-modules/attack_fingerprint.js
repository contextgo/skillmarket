/**
 * HoneyTrap v4.0 - 攻击指纹库模块
 *
 * 基于传统杀毒软件特征码技术和YARA规则引擎
 *
 * 核心功能:
 * - 特征码数据库管理 (类似Norton病毒库)
 * - YARA规则匹配 (模式识别)
 * - 哈希黑名单 (文件哈希比对)
 * - 攻击指纹注册与查询
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class AttackFingerprint {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.dataPath = options.dataPath || path.join(this.basePath, 'data');
        this.rulesPath = options.rulesPath || path.join(this.basePath, 'rules');

        // 指纹数据库
        this.database = {
            signatures: [],      // 特征码库
            yaraRules: [],       // YARA规则
            hashBlacklist: {},   // 哈希黑名单
            iocList: {}          // IOC情报库
        };

        // 统计信息
        this.stats = {
            totalSignatures: 0,
            totalRules: 0,
            hits: 0,
            lastUpdate: null
        };

        // 初始化
        this.init();
    }

    init() {
        // 确保目录存在
        const dirs = [this.dataPath, this.rulesPath, path.join(this.dataPath, 'fingerprints')];
        dirs.forEach(dir => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });

        // 加载本地指纹库
        this.loadDatabase();

        // 如果数据库为空，初始化默认规则
        if (this.database.signatures.length === 0) {
            this.initDefaultSignatures();
        }
        if (this.database.yaraRules.length === 0) {
            this.initDefaultRules();
        }

        this.stats.totalSignatures = this.database.signatures.length;
        this.stats.totalRules = this.database.yaraRules.length;
    }

    /**
     * 初始化默认特征码库 (类似杀毒软件病毒库)
     */
    initDefaultSignatures() {
        this.database.signatures = [
            // === Agent攻击特征 ===
            {
                id: 'SIG-001',
                name: 'Prompt Injection - System Role Override',
                category: 'prompt_injection',
                severity: 'critical',
                // 修复: 使用安全正则，避免ReDoS攻击
                // 原来: 'ignore.*previous.*instruction|ignore.*all.*previous'
                // 风险: 攻击者可构造 ignore + 大量字符 + previous 导致灾难性回溯
                pattern: '(?:ignore\\s+(?:the\\s+)?(?:all\\s+)?(?:previous\\s+)?(?:instruction|instructions|directive)|you\\s+are\\s+now\\s+(?:a\\s+)?(?:different|new)|forget\\s+(?:all\\s+)?(?:previous|your))',
                patternType: 'regex',
                description: '尝试忽略或覆盖系统指令的攻击模式 (ReDoS安全版本)',
                mitreTactic: 'T1059',
                mitreTechnique: 'Command and Scripting Interpreter'
            },
            {
                id: 'SIG-002',
                name: 'Prompt Injection - Hidden Instructions',
                category: 'prompt_injection',
                severity: 'critical',
                pattern: '(hidden|secret|invisible).*(instruction|command|directive)',
                patternType: 'regex',
                description: '隐藏在正常请求中的恶意指令'
            },
            {
                id: 'SIG-003',
                name: 'Context Injection - Memory Poisoning',
                category: 'context_manipulation',
                severity: 'high',
                pattern: 'you.*are.*now.*pretend|you.*are.*a.*different',
                patternType: 'regex',
                description: '尝试改变Agent身份的上下文注入'
            },
            {
                id: 'SIG-004',
                name: 'Data Exfiltration - API Key Extraction',
                category: 'data_theft',
                severity: 'critical',
                pattern: '(api[_-]?key|secret|token|password).*(=|:).*[a-zA-Z0-9]{20,}',
                patternType: 'regex',
                description: '尝试提取敏感凭证的请求'
            },
            {
                id: 'SIG-005',
                name: 'Data Exfiltration - File System Access',
                category: 'data_theft',
                severity: 'high',
                pattern: '(read|get|fetch|download).*(\\.env|\\.pem|\\.key|credentials|\\.config)',
                patternType: 'regex',
                description: '尝试访问敏感文件'
            },
            {
                id: 'SIG-006',
                name: 'Jailbreak - Role Play Bypass',
                category: 'jailbreak',
                severity: 'high',
                pattern: 'pretend.*(to be|you are)|role.*play.*unrestricted|DAN',
                patternType: 'regex',
                description: '通过角色扮演绕过安全限制'
            },
            {
                id: 'SIG-007',
                name: 'Social Engineering - Authority Impersonation',
                category: 'social_engineering',
                severity: 'medium',
                pattern: '(i am|我是).*(admin|administrator|manager|老板|管理员)',
                patternType: 'regex',
                description: '冒充管理员或权威身份'
            },
            {
                id: 'SIG-008',
                name: 'Social Engineering - Urgency Pressure',
                category: 'social_engineering',
                severity: 'low',
                pattern: '(urgent|immediately|asap|紧急|立刻).*(required|needed|必须)',
                patternType: 'regex',
                description: '使用紧迫感的社会工程技巧'
            },
            {
                id: 'SIG-009',
                name: 'Supply Chain Attack - Code Injection',
                category: 'code_injection',
                severity: 'critical',
                pattern: 'eval\\(|exec\\(|__import__|os\\.system|subprocess',
                patternType: 'regex',
                description: '代码注入尝试'
            },
            {
                id: 'SIG-010',
                name: 'Denial of Service - Resource Exhaustion',
                category: 'dos',
                severity: 'high',
                pattern: '(infinite|loop|repeat|999999|while.*true)',
                patternType: 'regex',
                description: '可能导致资源耗尽的请求'
            },
            {
                id: 'SIG-011',
                name: 'Privilege Escalation - Skill Modification',
                category: 'privilege_escalation',
                severity: 'critical',
                pattern: '(modify|change|update|delete).*(skill|SKILL|plugin|技能)',
                patternType: 'regex',
                description: '尝试修改或删除安全技能'
            },
            {
                id: 'SIG-012',
                name: 'Lateral Movement - Cross-Context Access',
                category: 'lateral_movement',
                severity: 'high',
                pattern: '(access|get|read).*(other|another|其他).*(skill|context|workspace)',
                patternType: 'regex',
                description: '尝试跨上下文访问'
            },
            {
                id: 'SIG-013',
                name: 'Exfiltration - Memory Dump',
                category: 'data_theft',
                severity: 'critical',
                pattern: '(dump|extract|export|leak).*(memory|conversation|context|对话|记忆)',
                patternType: 'regex',
                description: '尝试提取对话记忆或上下文'
            },
            {
                id: 'SIG-014',
                name: 'Persistence - Auto-Install Malware',
                category: 'persistence',
                severity: 'critical',
                pattern: '(auto|auto).*(install|download|run)|schedule.*task.*malicious',
                patternType: 'regex',
                description: '尝试建立持久化机制'
            },
            {
                id: 'SIG-015',
                name: 'Defense Evasion - Obfuscation',
                category: 'defense_evasion',
                severity: 'medium',
                pattern: '(base64|encode|obfuscate|混淆|编码).*(command|instruction|script)',
                patternType: 'regex',
                description: '使用编码混淆恶意指令'
            }
        ];

        // 初始化哈希黑名单
        this.database.hashBlacklist = {
            // 已知恶意内容哈希
            'e3b0c44298fc1c149afbf4c8996fb924': 'Known malicious hash - empty file marker',
            // 可以添加更多
        };

        // 保存到文件
        this.saveDatabase();
    }

    /**
     * 初始化YARA规则
     */
    initDefaultRules() {
        this.database.yaraRules = [
            {
                id: 'YARA-001',
                name: 'Suspicious Multi-Stage Attack',
                category: 'composite',
                severity: 'critical',
                condition: {
                    requires: ['SIG-001', 'SIG-004'],
                    logic: 'OR'
                },
                description: '多阶段组合攻击检测'
            },
            {
                id: 'YARA-002',
                name: 'Covert Data Theft',
                category: 'composite',
                severity: 'critical',
                condition: {
                    requires: ['SIG-003', 'SIG-013'],
                    logic: 'AND'
                },
                description: '隐蔽数据窃取攻击链'
            },
            {
                id: 'YARA-003',
                name: 'Privilege Escalation Attack',
                category: 'composite',
                severity: 'critical',
                condition: {
                    requires: ['SIG-011', 'SIG-012'],
                    logic: 'OR'
                },
                description: '权限提升攻击'
            },
            {
                id: 'YARA-004',
                name: 'Social Engineering Attack',
                category: 'composite',
                severity: 'medium',
                condition: {
                    requires: ['SIG-007', 'SIG-008'],
                    logic: 'AND'
                },
                description: '社会工程学攻击组合'
            },
            {
                id: 'YARA-005',
                name: 'Advanced Persistent Threat Simulation',
                category: 'composite',
                severity: 'critical',
                condition: {
                    requires: ['SIG-001', 'SIG-003', 'SIG-009', 'SIG-014'],
                    logic: 'AND'
                },
                description: 'APT攻击模拟检测'
            }
        ];
    }

    /**
     * 扫描目标内容 (特征码匹配)
     */
    async scan(target) {
        const results = {
            method: 'fingerprint',
            matches: [],
            scannedAt: new Date().toISOString()
        };

        const content = typeof target === 'string' ? target :
                        (target.content || target.prompt || JSON.stringify(target));

        // 1. 正则特征码扫描
        for (const sig of this.database.signatures) {
            try {
                const regex = new RegExp(sig.pattern, 'gi');
                if (regex.test(content)) {
                    results.matches.push({
                        signatureId: sig.id,
                        name: sig.name,
                        category: sig.category,
                        severity: sig.severity,
                        confidence: this.calculateConfidence(sig.severity),
                        description: sig.description,
                        matchedPattern: sig.pattern,
                        mitreTactic: sig.mitreTactic
                    });
                }
            } catch (e) {
                // 忽略无效正则
            }
        }

        // 2. 哈希检查
        if (typeof content === 'string') {
            const hash = crypto.createHash('sha256').update(content).digest('hex');
            if (this.database.hashBlacklist[hash]) {
                results.matches.push({
                    type: 'hash',
                    hash: hash,
                    name: 'Known Malicious Hash',
                    severity: 'critical',
                    confidence: 100,
                    description: this.database.hashBlacklist[hash]
                });
            }
        }

        // 3. YARA复合规则检查
        const yaraMatches = this.checkYaraRules(results.matches);
        results.matches.push(...yaraMatches);

        // 去重
        results.matches = this.deduplicateMatches(results.matches);
        this.stats.hits += results.matches.length;

        return results;
    }

    /**
     * 行为指纹匹配
     */
    async matchBehavior(action) {
        const actionStr = typeof action === 'string' ? action : JSON.stringify(action);

        for (const sig of this.database.signatures) {
            try {
                const regex = new RegExp(sig.pattern, 'gi');
                if (regex.test(actionStr)) {
                    return {
                        match: true,
                        signatureId: sig.id,
                        rule: {
                            id: sig.id,
                            name: sig.name,
                            severity: sig.severity,
                            category: sig.category
                        },
                        confidence: this.calculateConfidence(sig.severity)
                    };
                }
            } catch (e) {
                // 忽略
            }
        }

        return { match: false };
    }

    /**
     * YARA复合规则检查
     */
    checkYaraRules(matches) {
        const matchedIds = new Set(matches.map(m => m.signatureId || m.type));
        const results = [];

        for (const rule of this.database.yaraRules) {
            const requiredSet = new Set(rule.condition.requires);
            let triggered = false;

            if (rule.condition.logic === 'AND') {
                triggered = [...requiredSet].every(id => matchedIds.has(id));
            } else { // OR
                triggered = [...requiredSet].some(id => matchedIds.has(id));
            }

            if (triggered) {
                results.push({
                    ruleId: rule.id,
                    name: rule.name,
                    category: rule.category,
                    severity: rule.severity,
                    confidence: 95,
                    description: rule.description,
                    type: 'yara_rule'
                });
            }
        }

        return results;
    }

    /**
     * 计算置信度
     */
    calculateConfidence(severity) {
        const levels = {
            'critical': 95,
            'high': 80,
            'medium': 60,
            'low': 40
        };
        return levels[severity] || 50;
    }

    /**
     * 去重匹配结果
     */
    deduplicateMatches(matches) {
        const seen = new Set();
        return matches.filter(m => {
            const key = m.signatureId || m.hash || m.ruleId;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    /**
     * 添加特征码
     */
    addSignature(signature) {
        if (!signature.id) {
            signature.id = `SIG-${Date.now()}`;
        }
        this.database.signatures.push(signature);
        this.stats.totalSignatures = this.database.signatures.length;
        this.saveDatabase();
        return signature;
    }

    /**
     * 添加YARA规则
     */
    addYaraRule(rule) {
        if (!rule.id) {
            rule.id = `YARA-${Date.now()}`;
        }
        this.database.yaraRules.push(rule);
        this.stats.totalRules = this.database.yaraRules.length;
        this.saveDatabase();
        return rule;
    }

    /**
     * 更新IOC列表
     */
    updateIOC(iocType, iocs) {
        this.database.iocList[iocType] = iocs;
        this.saveDatabase();
    }

    /**
     * 加载数据库
     */
    loadDatabase() {
        const dbPath = path.join(this.dataPath, 'fingerprints', 'database.json');
        if (fs.existsSync(dbPath)) {
            try {
                const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                this.database = { ...this.database, ...data };
                this.stats.lastUpdate = data.lastUpdate;
            } catch (e) {
                console.error('Failed to load fingerprint database:', e.message);
            }
        }
    }

    /**
     * 保存数据库
     */
    saveDatabase() {
        const dbPath = path.join(this.dataPath, 'fingerprints', 'database.json');
        this.database.lastUpdate = new Date().toISOString();
        this.stats.lastUpdate = this.database.lastUpdate;
        fs.writeFileSync(dbPath, JSON.stringify(this.database, null, 2));
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            hashBlacklistSize: Object.keys(this.database.hashBlacklist).length,
            iocTypes: Object.keys(this.database.iocList).length
        };
    }

    /**
     * 导出指纹库
     */
    export() {
        return {
            signatures: this.database.signatures,
            yaraRules: this.database.yaraRules,
            hashBlacklist: this.database.hashBlacklist,
            iocList: this.database.iocList,
            exportedAt: new Date().toISOString()
        };
    }

    /**
     * 导入指纹库
     */
    import(data) {
        if (data.signatures) {
            this.database.signatures = [...this.database.signatures, ...data.signatures];
        }
        if (data.yaraRules) {
            this.database.yaraRules = [...this.database.yaraRules, ...data.yaraRules];
        }
        if (data.hashBlacklist) {
            this.database.hashBlacklist = { ...this.database.hashBlacklist, ...data.hashBlacklist };
        }
        if (data.iocList) {
            this.database.iocList = { ...this.database.iocList, ...data.iocList };
        }
        this.saveDatabase();
        this.stats.totalSignatures = this.database.signatures.length;
        this.stats.totalRules = this.database.yaraRules.length;
    }
}

module.exports = AttackFingerprint;
