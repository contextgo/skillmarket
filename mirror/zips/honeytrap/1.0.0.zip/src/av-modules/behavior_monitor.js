/**
 * HoneyTrap v4.0 - 行为监控引擎
 *
 * 基于传统杀毒软件主动防御技术和EDR行为分析
 *
 * 核心功能:
 * - 实时行为监控 (类似RING3主动防御)
 * - API调用拦截 (类似API Hook)
 * - 异常行为检测 (类似启发式监控)
 * - 攻击链追踪 (类似EDR行为分析)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class BehaviorMonitor {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.sensitivity = options.sensitivity || 'medium'; // low, medium, high, paranoid

        // 敏感度配置
        this.sensitivityConfig = {
            low: { threshold: 70, alertLevel: 'high' },
            medium: { threshold: 50, alertLevel: 'medium' },
            high: { threshold: 30, alertLevel: 'low' },
            paranoid: { threshold: 10, alertLevel: 'critical' }
        };

        // 行为规则库 (类似杀毒软件行为规则)
        this.rules = this.initBehaviorRules();

        // 行为序列缓存 (用于攻击链分析)
        this.behaviorSequence = [];
        this.maxSequenceLength = 100;

        // 统计信息
        this.stats = {
            totalChecks: 0,
            alerts: 0,
            blocks: 0,
            currentRiskLevel: 0
        };
    }

    /**
     * 初始化行为规则库 (类似杀毒软件行为监控规则)
     */
    initBehaviorRules() {
        return [
            // === 文件操作类 ===
            {
                id: 'BR-FILE-001',
                category: 'file_access',
                name: '敏感文件读取',
                pattern: {
                    action: 'read',
                    target: '(password|credential|secret|key|\\.env|config|credentials)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 25,
                description: '读取敏感配置文件'
            },
            {
                id: 'BR-FILE-002',
                category: 'file_access',
                name: '系统文件修改',
                pattern: {
                    action: 'write|modify',
                    target: '(system|windows|system32|\\.dll|\\.exe)',
                    sensitivity: 'critical'
                },
                severity: 'critical',
                weight: 40,
                description: '修改系统关键文件'
            },
            {
                id: 'BR-FILE-003',
                category: 'file_access',
                name: '批量文件删除',
                pattern: {
                    action: 'delete',
                    quantity: 'multiple',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 30,
                description: '批量删除文件可能是勒索软件行为'
            },
            {
                id: 'BR-FILE-004',
                category: 'file_access',
                name: '隐藏文件创建',
                pattern: {
                    action: 'create',
                    target: '(^\\.|hidden|\\.tmp)',
                    sensitivity: 'medium'
                },
                severity: 'medium',
                weight: 15,
                description: '创建隐藏文件可能是恶意软件行为'
            },

            // === 进程操作类 ===
            {
                id: 'BR-PROC-001',
                category: 'process',
                name: '可疑进程创建',
                pattern: {
                    action: 'spawn',
                    target: '(powershell|cmd\\.exe|wscript|cscript|mshta)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 25,
                description: '创建可疑系统进程'
            },
            {
                id: 'BR-PROC-002',
                category: 'process',
                name: '进程注入检测',
                pattern: {
                    action: 'inject',
                    target: '(system|explorer|browser)',
                    sensitivity: 'critical'
                },
                severity: 'critical',
                weight: 40,
                description: '尝试注入到系统或浏览器进程'
            },
            {
                id: 'BR-PROC-003',
                category: 'process',
                name: '进程终止',
                pattern: {
                    action: 'terminate',
                    target: '(antivirus|defender|security|杀毒)',
                    sensitivity: 'critical'
                },
                severity: 'critical',
                weight: 50,
                description: '试图终止安全软件进程'
            },
            {
                id: 'BR-PROC-004',
                category: 'process',
                name: '高危命令执行',
                pattern: {
                    action: 'execute',
                    target: '(regsvr32|rundll32|msiexec|certutil)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 30,
                description: '执行高危系统命令'
            },

            // === 网络操作类 ===
            {
                id: 'BR-NET-001',
                category: 'network',
                name: '可疑外连',
                pattern: {
                    action: 'connect',
                    target: '(suspicious|unknown|external)',
                    sensitivity: 'medium'
                },
                severity: 'medium',
                weight: 20,
                description: '连接到可疑外部地址'
            },
            {
                id: 'BR-NET-002',
                category: 'network',
                name: '异常端口连接',
                pattern: {
                    action: 'connect',
                    port: '(4444|5555|6666|31337|1337)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 25,
                description: '连接到常见后门端口'
            },
            {
                id: 'BR-NET-003',
                category: 'network',
                name: '数据外传',
                pattern: {
                    action: 'send',
                    size: 'large',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 30,
                description: '大量数据外传可能意味着数据泄露'
            },

            // === 注册表操作类 ===
            {
                id: 'BR-REG-001',
                category: 'registry',
                name: '自启动注册',
                pattern: {
                    action: 'write',
                    target: '(Run|HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 25,
                description: '修改自启动注册表项'
            },
            {
                id: 'BR-REG-002',
                category: 'registry',
                name: '禁用安全软件',
                pattern: {
                    action: 'delete|disable',
                    target: '(antivirus|defender|security|center)',
                    sensitivity: 'critical'
                },
                severity: 'critical',
                weight: 50,
                description: '试图禁用安全软件'
            },

            // === Agent特定行为 ===
            {
                id: 'BR-AGENT-001',
                category: 'agent_action',
                name: '技能文件修改',
                pattern: {
                    action: 'modify',
                    target: '(skill|SKILL|\\.md|\\.js)',
                    location: '~/.workbuddy/skills'
                },
                severity: 'critical',
                weight: 45,
                description: '试图修改HoneyTrap技能文件'
            },
            {
                id: 'BR-AGENT-002',
                category: 'agent_action',
                name: '记忆文件操作',
                pattern: {
                    action: 'access|modify',
                    target: '(memory|context|\\.md)',
                    location: '~/.workbuddy'
                },
                severity: 'high',
                weight: 30,
                description: '访问或修改记忆文件'
            },
            {
                id: 'BR-AGENT-003',
                category: 'agent_action',
                name: '凭证提取',
                pattern: {
                    action: 'read|extract',
                    target: '(api_key|token|secret|credential)',
                    location: '~/.workbuddy'
                },
                severity: 'critical',
                weight: 50,
                description: '提取凭证信息'
            },
            {
                id: 'BR-AGENT-004',
                category: 'agent_action',
                name: '系统指令注入',
                pattern: {
                    action: 'inject',
                    target: '(system|prompt|instruction|directive)',
                    sensitivity: 'critical'
                },
                severity: 'critical',
                weight: 50,
                description: '注入系统指令'
            },

            // === 权限操作类 ===
            {
                id: 'BR-AUTH-001',
                category: 'authentication',
                name: '权限提升',
                pattern: {
                    action: 'escalate',
                    target: '(admin|root|administrator|管理员)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 35,
                description: '尝试提升操作权限'
            },
            {
                id: 'BR-AUTH-002',
                category: 'authentication',
                name: '身份冒充',
                pattern: {
                    action: 'impersonate',
                    target: '(developer|owner|creator|开发者)',
                    sensitivity: 'high'
                },
                severity: 'high',
                weight: 30,
                description: '冒充开发者身份'
            },

            // === 数据操作类 ===
            {
                id: 'BR-DATA-001',
                category: 'data',
                name: '批量数据查询',
                pattern: {
                    action: 'query',
                    quantity: 'bulk',
                    sensitivity: 'medium'
                },
                severity: 'medium',
                weight: 15,
                description: '批量查询数据可能意味着数据收集'
            },
            {
                id: 'BR-DATA-002',
                category: 'data',
                name: '加密通信',
                pattern: {
                    action: 'encrypt',
                    target: '(data|file|content)',
                    sensitivity: 'medium'
                },
                severity: 'medium',
                weight: 20,
                description: '加密数据可能意味着窃取或勒索'
            }
        ];
    }

    /**
     * 检查行为 (主动防御核心)
     */
    async checkAction(action, context = {}) {
        const result = {
            matchedRules: [],
            riskLevel: 0,
            details: []
        };

        // 记录行为序列
        this.recordBehavior(action, context);

        // 检查每个规则
        for (const rule of this.rules) {
            const match = this.matchRule(action, context, rule);
            if (match) {
                result.matchedRules.push({
                    id: rule.id,
                    name: rule.name,
                    category: rule.category,
                    severity: rule.severity,
                    weight: rule.weight,
                    description: rule.description,
                    matchDetails: match
                });
                result.riskLevel += rule.weight;
                result.details.push({
                    rule: rule.name,
                    reason: match
                });
            }
        }

        // 攻击链分析
        const chainAnalysis = this.analyzeAttackChain(action, context);
        if (chainAnalysis.riskBoost > 0) {
            result.riskLevel += chainAnalysis.riskBoost;
            result.attackChain = chainAnalysis;
        }

        // 限制最大风险值
        result.riskLevel = Math.min(100, result.riskLevel);

        // 更新统计
        this.stats.totalChecks++;
        if (result.matchedRules.length > 0) {
            this.stats.alerts++;
        }
        if (result.riskLevel >= this.sensitivityConfig[this.sensitivity].threshold) {
            this.stats.blocks++;
        }
        this.stats.currentRiskLevel = result.riskLevel;

        return result;
    }

    /**
     * 规则匹配 (类似API Hook的行为拦截)
     */
    matchRule(action, context, rule) {
        const actionStr = typeof action === 'string' ? action : JSON.stringify(action);
        const contextStr = JSON.stringify(context);

        // 检查操作类型
        if (rule.pattern.action) {
            const actionPatterns = rule.pattern.action.split('|');
            const hasAction = actionPatterns.some(p => {
                if (actionStr.toLowerCase().includes(p.toLowerCase())) return true;
                if (contextStr.toLowerCase().includes(p.toLowerCase())) return true;
                return false;
            });
            if (!hasAction) return false;
        }

        // 检查目标
        if (rule.pattern.target) {
            const targetPatterns = rule.pattern.target.split('|');
            const hasTarget = targetPatterns.some(p => {
                const regex = new RegExp(p, 'gi');
                return regex.test(actionStr) || regex.test(contextStr);
            });
            if (!hasTarget) return false;
        }

        // 检查位置
        if (rule.pattern.location) {
            const location = context.location || context.path || '';
            const regex = new RegExp(rule.pattern.location, 'gi');
            if (!regex.test(location)) return false;
        }

        // 检查端口
        if (rule.pattern.port) {
            const port = context.port || '';
            const regex = new RegExp(rule.pattern.port);
            if (!regex.test(port.toString())) return false;
        }

        // 所有条件匹配
        return `Matched: ${rule.category} - ${rule.name}`;
    }

    /**
     * 记录行为序列 (用于攻击链分析)
     */
    recordBehavior(action, context) {
        const entry = {
            timestamp: Date.now(),
            action: typeof action === 'string' ? action.substring(0, 200) : JSON.stringify(action).substring(0, 200),
            context: {
                category: context.category || 'unknown',
                target: context.target || 'unknown'
            }
        };

        this.behaviorSequence.push(entry);

        // 保持序列长度
        if (this.behaviorSequence.length > this.maxSequenceLength) {
            this.behaviorSequence.shift();
        }
    }

    /**
     * 攻击链分析 (类似EDR攻击链追踪)
     */
    analyzeAttackChain(currentAction, context) {
        const result = {
            chainStage: null,
            riskBoost: 0,
            indicators: []
        };

        // MITRE ATT&CK 风格攻击阶段
        const attackStages = [
            { name: 'recon', weight: 10 },
            { name: 'weaponize', weight: 15 },
            { name: 'deliver', weight: 20 },
            { name: 'exploit', weight: 30 },
            { name: 'install', weight: 40 },
            { name: 'command_control', weight: 50 },
            { name: 'execute', weight: 60 },
            { name: 'exfiltrate', weight: 70 }
        ];

        // 根据当前行为判断攻击阶段
        const actionStr = JSON.stringify(currentAction).toLowerCase();

        // 侦察阶段
        if (/read|query|list|get|search|scan/.test(actionStr)) {
            result.chainStage = 'recon';
            result.riskBoost = 5;
        }

        // 武器化/准备阶段
        if (/create|modify|write|prepare|compile/.test(actionStr)) {
            result.chainStage = 'weaponize';
            result.riskBoost = 10;
        }

        // 利用/执行阶段
        if (/execute|run|eval|exec|spawn/.test(actionStr)) {
            result.chainStage = 'execute';
            result.riskBoost = 25;
        }

        // 数据外传阶段
        if (/send|upload|exfiltrate|leak|extract/.test(actionStr)) {
            result.chainStage = 'exfiltrate';
            result.riskBoost = 35;
        }

        // 检测连续快速行为
        const recentCount = this.behaviorSequence.filter(
            b => Date.now() - b.timestamp < 5000
        ).length;

        if (recentCount > 10) {
            result.indicators.push('Rapid sequential actions detected');
            result.riskBoost += 15;
        }

        // 检测模式重复
        const actionTypes = this.behaviorSequence.slice(-10).map(b => b.context.category);
        const uniqueTypes = new Set(actionTypes);
        if (uniqueTypes.size >= 5) {
            result.indicators.push('Multi-stage attack pattern detected');
            result.riskBoost += 20;
        }

        return result;
    }

    /**
     * 评估动作风险 (启发式分析)
     */
    async evaluateAction(action, context = {}) {
        let riskLevel = 0;
        const threats = [];

        // 上下文风险评估
        if (context.source) {
            if (['external', 'unknown', 'anonymous'].includes(context.source)) {
                riskLevel += 20;
                threats.push({
                    type: 'untrusted_source',
                    level: 20,
                    description: '来自不可信来源'
                });
            }
        }

        // 操作类型风险
        const highRiskActions = ['execute', 'delete', 'modify', 'write', 'inject', 'escalate'];
        const mediumRiskActions = ['read', 'query', 'search', 'list'];

        if (highRiskActions.includes(context.action)) {
            riskLevel += 30;
        } else if (mediumRiskActions.includes(context.action)) {
            riskLevel += 10;
        }

        // 目标敏感性评估
        if (context.target) {
            const sensitiveTargets = ['credential', 'api_key', 'token', 'password', 'secret', 'skill', 'memory', 'config'];
            const hasSensitive = sensitiveTargets.some(t =>
                context.target.toLowerCase().includes(t)
            );
            if (hasSensitive) {
                riskLevel += 25;
                threats.push({
                    type: 'sensitive_target',
                    level: 25,
                    description: '访问敏感目标'
                });
            }
        }

        return {
            riskLevel: Math.min(100, riskLevel),
            threats
        };
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            sensitivity: this.sensitivity,
            threshold: this.sensitivityConfig[this.sensitivity].threshold,
            totalRules: this.rules.length,
            recentBehaviorCount: this.behaviorSequence.length
        };
    }

    /**
     * 添加自定义规则
     */
    addRule(rule) {
        if (!rule.id) {
            rule.id = `BR-CUSTOM-${Date.now()}`;
        }
        this.rules.push(rule);
        return rule;
    }

    /**
     * 获取行为序列
     */
    getBehaviorSequence() {
        return [...this.behaviorSequence];
    }

    /**
     * 清空行为序列
     */
    clearSequence() {
        this.behaviorSequence = [];
    }

    /**
     * 导出规则
     */
    exportRules() {
        return [...this.rules];
    }

    /**
     * 导入规则
     */
    importRules(rules) {
        this.rules = [...this.rules, ...rules];
    }
}

module.exports = BehaviorMonitor;
