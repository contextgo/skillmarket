/**
 * HoneyTrap v4.0 - 威胁情报中心
 *
 * 基于传统杀毒软件云查杀和现代XDR威胁情报技术
 *
 * 核心功能:
 * - 本地威胁情报库 (类似本地病毒库)
 * - IOC情报匹配 (类似云查杀)
 * - MITRE ATT&CK映射 (类似高级威胁分析)
 * - 威胁情报同步 (类似实时更新)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class ThreatIntel {
    constructor(options = {}) {
        this.basePath = options.basePath;
        this.syncInterval = options.syncInterval || 3600000; // 1小时

        // 威胁情报数据库
        this.intel = {
            iocs: {},           // IOC情报
            threatActors: {},   // 威胁组织
            malwareProfiles: {}, // 恶意软件档案
            attackPatterns: {}  // 攻击模式
        };

        // 最后同步时间
        this.lastSync = null;
        this.syncTimer = null;

        // 统计信息
        this.stats = {
            totalIOCs: 0,
            queries: 0,
            hits: 0,
            lastSync: null,
            syncErrors: 0
        };

        // 初始化情报库
        this.initIntel();
    }

    /**
     * 初始化威胁情报库
     */
    initIntel() {
        // === IOC情报库 (类似云查杀病毒库) ===
        this.intel.iocs = {
            // 已知恶意模式
            patterns: [
                {
                    id: 'IOC-PAT-001',
                    type: 'pattern',
                    pattern: '(eval|exec|__import__).*\\(.*\\)',
                    severity: 'high',
                    description: '动态代码执行模式',
                    source: 'local',
                    firstSeen: '2024-01-01'
                },
                {
                    id: 'IOC-PAT-002',
                    type: 'pattern',
                    pattern: 'base64.*decode|atob\\(btoa',
                    severity: 'medium',
                    description: 'Base64编码混淆模式',
                    source: 'local',
                    firstSeen: '2024-01-01'
                },
                {
                    id: 'IOC-PAT-003',
                    type: 'pattern',
                    pattern: '(password|secret|key|token).*=.*["\'](?!null|undefined)',
                    severity: 'high',
                    description: '硬编码凭证模式',
                    source: 'local',
                    firstSeen: '2024-01-01'
                }
            ],

            // 恶意哈希
            hashes: {
                // 可以添加已知恶意内容的哈希
            },

            // 可疑域名/IP
            networkIndicators: [
                {
                    id: 'IOC-NET-001',
                    type: 'domain',
                    value: 'evil-c2.example.com',
                    severity: 'critical',
                    description: '已知C2域名',
                    source: 'local',
                    firstSeen: '2024-01-01'
                },
                {
                    id: 'IOC-NET-002',
                    type: 'ip',
                    value: '192.0.2.0/24',
                    severity: 'high',
                    description: '测试IP段(示例)',
                    source: 'local',
                    firstSeen: '2024-01-01'
                }
            ],

            // 恶意URL模式
            urlPatterns: [
                {
                    id: 'IOC-URL-001',
                    pattern: '.*\\.tk/.*|.*\\.ml/.*|.*\\.ga/.*',
                    severity: 'medium',
                    description: '免费域名托管服务',
                    source: 'local',
                    firstSeen: '2024-01-01'
                }
            ]
        };

        // === 恶意软件档案 ===
        this.intel.malwareProfiles = {
            'prompt-injection': {
                name: '提示注入攻击',
                category: 'social_engineering',
                severity: 'critical',
                indicators: [
                    'ignore previous instructions',
                    'disregard all rules',
                    'new system prompt',
                    'you are now in developer mode'
                ],
                mitreTechniques: ['T1059'],
                mitreTactics: ['Execution', 'Persistence']
            },
            'context-manipulation': {
                name: '上下文操纵攻击',
                category: 'privilege_escalation',
                severity: 'high',
                indicators: [
                    'you are now a different AI',
                    'role play as unrestricted',
                    'ignore safety guidelines'
                ],
                mitreTechniques: ['T1566'],
                mitreTactics: ['Initial Access', 'Execution']
            },
            'credential-harvesting': {
                name: '凭证窃取攻击',
                category: 'credential_access',
                severity: 'critical',
                indicators: [
                    'extract api key',
                    'dump credentials',
                    'export passwords'
                ],
                mitreTechniques: ['T1003', 'T1552'],
                mitreTactics: ['Credential Access']
            },
            'data-exfiltration': {
                name: '数据外传攻击',
                category: 'exfiltration',
                severity: 'high',
                indicators: [
                    'send all data',
                    'export conversation',
                    'dump memory'
                ],
                mitreTechniques: ['T1041'],
                mitreTactics: ['Exfiltration']
            },
            'skill-poisoning': {
                name: '技能投毒攻击',
                category: 'defense_evasion',
                severity: 'critical',
                indicators: [
                    'modify skill file',
                    'update honeytrap',
                    'delete self-protection'
                ],
                mitreTechniques: ['T1070', 'T1562'],
                mitreTactics: ['Defense Evasion', 'Impact']
            }
        };

        // === 攻击模式库 (MITRE ATT&CK风格) ===
        this.intel.attackPatterns = {
            'APT-Prompt-Injection': {
                name: 'APT提示注入攻击链',
                stages: [
                    { step: 1, tactic: 'Initial Access', technique: 'Phishing', description: '通过钓鱼或社会工程获取访问' },
                    { step: 2, tactic: 'Execution', technique: 'User Execution', description: '诱导执行恶意提示' },
                    { step: 3, tactic: 'Persistence', technique: 'Skill Modification', description: '持久化修改技能配置' },
                    { step: 4, tactic: 'Collection', technique: 'Data from Local System', description: '收集敏感信息' },
                    { step: 5, tactic: 'Exfiltration', technique: 'Exfiltration Over C2', description: '数据外传' }
                ],
                severity: 'critical',
                mitreId: 'T1566'
            },
            'Credential-Stuffing': {
                name: '凭证填充攻击',
                stages: [
                    { step: 1, tactic: 'Credential Access', technique: 'Brute Force', description: '暴力破解凭证' },
                    { step: 2, tactic: 'Credential Access', technique: 'Credential Dumping', description: '批量导出凭证' },
                    { step: 3, tactic: 'Lateral Movement', technique: 'Use Valid Accounts', description: '横向移动' }
                ],
                severity: 'high',
                mitreId: 'T1110'
            }
        };

        this.updateStats();
    }

    /**
     * 查询威胁情报
     */
    async query(target) {
        const results = {
            method: 'threat_intel',
            matches: [],
            queryTime: new Date().toISOString(),
            intelligence: {}
        };

        const content = typeof target === 'string' ? target :
                        (target.content || target.prompt || JSON.stringify(target));

        // 1. IOC模式匹配
        const patternMatches = this.matchIOCPatterns(content);
        results.matches.push(...patternMatches);

        // 2. 哈希匹配
        const hashMatches = this.matchHashes(content);
        results.matches.push(...hashMatches);

        // 3. 恶意软件档案匹配
        const malwareMatches = this.matchMalwareProfiles(content);
        results.matches.push(...malwareMatches);

        // 4. 提取详细信息
        if (results.matches.length > 0) {
            results.intelligence = this.getDetailedIntel(results.matches);
        }

        // 更新统计
        this.stats.queries++;
        this.stats.hits += results.matches.length;

        return results;
    }

    /**
     * IOC模式匹配
     */
    matchIOCPatterns(content) {
        const matches = [];

        // 模式匹配
        for (const ioc of this.intel.iocs.patterns) {
            try {
                const regex = new RegExp(ioc.pattern, 'gi');
                if (regex.test(content)) {
                    matches.push({
                        iocId: ioc.id,
                        type: 'pattern',
                        pattern: ioc.pattern,
                        severity: ioc.severity,
                        description: ioc.description,
                        source: ioc.source
                    });
                }
            } catch (e) {
                // 忽略无效正则
            }
        }

        // URL模式匹配
        const urls = content.match(/https?:\/\/[^\s<>"\']+/gi) || [];
        for (const url of urls) {
            for (const urlPattern of this.intel.iocs.urlPatterns) {
                try {
                    const regex = new RegExp(urlPattern.pattern, 'gi');
                    if (regex.test(url)) {
                        matches.push({
                            iocId: urlPattern.id,
                            type: 'url_pattern',
                            value: url,
                            severity: urlPattern.severity,
                            description: urlPattern.description,
                            source: urlPattern.source
                        });
                    }
                } catch (e) {
                    // 忽略
                }
            }
        }

        return matches;
    }

    /**
     * 哈希匹配
     */
    matchHashes(content) {
        const matches = [];
        const hash = crypto.createHash('sha256').update(content).digest('hex');

        if (this.intel.iocs.hashes[hash]) {
            matches.push({
                iocId: 'HASH-' + hash.substring(0, 8),
                type: 'hash',
                hash: hash,
                severity: 'critical',
                description: this.intel.iocs.hashes[hash],
                source: 'local'
            });
        }

        return matches;
    }

    /**
     * 恶意软件档案匹配
     */
    matchMalwareProfiles(content) {
        const matches = [];
        const lowerContent = content.toLowerCase();

        for (const [key, profile] of Object.entries(this.intel.malwareProfiles)) {
            for (const indicator of profile.indicators) {
                if (lowerContent.includes(indicator.toLowerCase())) {
                    matches.push({
                        iocId: `MAL-${key}`,
                        type: 'malware_profile',
                        malwareType: key,
                        malwareName: profile.name,
                        category: profile.category,
                        severity: profile.severity,
                        mitreTechniques: profile.mitreTechniques,
                        mitreTactics: profile.mitreTactics,
                        matchedIndicator: indicator,
                        source: 'local'
                    });
                    break; // 每个恶意软件只匹配一次
                }
            }
        }

        return matches;
    }

    /**
     * 获取详细情报
     */
    getDetailedIntel(matches) {
        const intel = {};

        for (const match of matches) {
            if (match.type === 'malware_profile') {
                intel[match.malwareType] = {
                    ...this.intel.malwareProfiles[match.malwareType],
                    matchedIndicator: match.matchedIndicator
                };
            }

            if (match.mitreTechniques) {
                intel.attackPatterns = Object.values(this.intel.attackPatterns).filter(
                    p => p.mitreId === match.mitreTechniques?.[0]
                );
            }
        }

        return intel;
    }

    /**
     * 同步威胁情报
     */
    async sync() {
        // 在实际实现中，这里可以从外部源同步情报
        // 例如：VirusTotal, AlienVault OTX, MITRE ATT&CK等

        const syncResult = {
            timestamp: new Date().toISOString(),
            success: true,
            added: 0,
            updated: 0
        };

        try {
            // 模拟同步过程
            // 在生产环境中，这里应该调用真实的威胁情报API

            // 1. 更新IOC库
            const newIOCs = this.fetchExternalIOCs();
            if (newIOCs) {
                syncResult.added = Object.keys(newIOCs).length;
                this.mergeIOCs(newIOCs);
            }

            // 2. 更新恶意软件档案
            const newMalware = this.fetchMalwareUpdates();
            if (newMalware) {
                Object.assign(this.intel.malwareProfiles, newMalware);
            }

            // 3. 更新攻击模式
            const newPatterns = this.fetchAttackPatterns();
            if (newPatterns) {
                Object.assign(this.intel.attackPatterns, newPatterns);
            }

            this.lastSync = new Date().toISOString();
            this.stats.lastSync = this.lastSync;
            this.updateStats();

            // 保存到文件
            this.saveIntel();

            return syncResult;

        } catch (error) {
            syncResult.success = false;
            syncResult.error = error.message;
            this.stats.syncErrors++;
            return syncResult;
        }
    }

    /**
     * 模拟获取外部IOC (实际应调用真实API)
     */
    fetchExternalIOCs() {
        // 这是一个占位函数，实际实现中应该调用：
        // - VirusTotal API
        // - AlienVault OTX API
        // - MITRE ATT&CK API
        // 等威胁情报源

        return null; // 本地模式，不进行外部同步
    }

    /**
     * 模拟获取恶意软件更新
     */
    fetchMalwareUpdates() {
        return null;
    }

    /**
     * 模拟获取攻击模式更新
     */
    fetchAttackPatterns() {
        return null;
    }

    /**
     * 合并IOC
     */
    mergeIOCs(newIOCs) {
        // 合并新IOC到现有库
        Object.keys(newIOCs).forEach(category => {
            if (!this.intel.iocs[category]) {
                this.intel.iocs[category] = [];
            }
            if (Array.isArray(this.intel.iocs[category])) {
                this.intel.iocs[category] = [
                    ...this.intel.iocs[category],
                    ...newIOCs[category].filter(
                        newItem => !this.intel.iocs[category].some(
                            existing => existing.id === newItem.id
                        )
                    )
                ];
            }
        });
    }

    /**
     * 保存情报到文件
     */
    saveIntel() {
        const dataPath = path.join(this.basePath || '.', 'data', 'threat_intel.json');
        const dir = path.dirname(dataPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(dataPath, JSON.stringify(this.intel, null, 2));
    }

    /**
     * 加载情报文件
     */
    loadIntel() {
        const dataPath = path.join(this.basePath || '.', 'data', 'threat_intel.json');
        if (fs.existsSync(dataPath)) {
            try {
                const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
                Object.assign(this.intel, data);
                this.updateStats();
            } catch (e) {
                console.error('Failed to load threat intel:', e.message);
            }
        }
    }

    /**
     * 更新统计
     */
    updateStats() {
        this.stats.totalIOCs =
            (this.intel.iocs.patterns?.length || 0) +
            Object.keys(this.intel.iocs.hashes || {}).length +
            (this.intel.iocs.networkIndicators?.length || 0) +
            (this.intel.iocs.urlPatterns?.length || 0);
    }

    /**
     * 获取MITRE ATT&CK映射
     */
    getMitreMapping() {
        const mapping = {};

        for (const [key, profile] of Object.entries(this.intel.malwareProfiles)) {
            if (profile.mitreTechniques) {
                profile.mitreTechniques.forEach(technique => {
                    if (!mapping[technique]) {
                        mapping[technique] = [];
                    }
                    mapping[technique].push({
                        malware: profile.name,
                        category: profile.category,
                        severity: profile.severity
                    });
                });
            }
        }

        return mapping;
    }

    /**
     * 获取统计信息
     */
    getStats() {
        return {
            ...this.stats,
            lastSync: this.lastSync,
            intelCounts: {
                patterns: this.intel.iocs.patterns?.length || 0,
                hashes: Object.keys(this.intel.iocs.hashes || {}).length,
                networkIndicators: this.intel.iocs.networkIndicators?.length || 0,
                malwareProfiles: Object.keys(this.intel.malwareProfiles).length,
                attackPatterns: Object.keys(this.intel.attackPatterns).length
            }
        };
    }

    /**
     * 添加IOC
     */
    addIOC(category, ioc) {
        if (!this.intel.iocs[category]) {
            this.intel.iocs[category] = [];
        }
        if (!ioc.id) {
            ioc.id = `IOC-${Date.now()}`;
        }
        ioc.firstSeen = ioc.firstSeen || new Date().toISOString().split('T')[0];
        this.intel.iocs[category].push(ioc);
        this.updateStats();
        return ioc;
    }

    /**
     * 导出情报
     */
    export() {
        return {
            ...this.intel,
            exportedAt: new Date().toISOString()
        };
    }

    /**
     * 导入情报
     */
    import(data) {
        if (data.iocs) {
            this.mergeIOCs(data.iocs);
        }
        if (data.malwareProfiles) {
            Object.assign(this.intel.malwareProfiles, data.malwareProfiles);
        }
        if (data.attackPatterns) {
            Object.assign(this.intel.attackPatterns, data.attackPatterns);
        }
        this.updateStats();
    }
}

module.exports = ThreatIntel;
