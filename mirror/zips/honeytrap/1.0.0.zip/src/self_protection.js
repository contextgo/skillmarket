/**
 * HoneyTrap 自我保护模块
 * v3.0
 * 
 * 功能：防止其他技能修改HoneyTrap的代码、配置或指令
 * 只有开发者(Owner)才有权限修改，其他技能的操作将被阻止
 * 
 * Security Features:
 * - 文件完整性校验 (HMAC-SHA256)
 * - 开发者身份验证 (Owner Key)
 * - 指令签名验证 (Token-based)
 * - 修改检测与警报
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ============================================================
// 配置
// ============================================================

const SELF_PROTECTION_CONFIG = {
    // 技能根目录 (相对于当前文件)
    SKILL_ROOT: path.dirname(__filename),
    
    // 开发者密钥文件
    OWNER_KEY_FILE: '.honeytrap/owner.key',
    
    // 完整性数据库
    INTEGRITY_DB: '.honeytrap/integrity.json',
    
    // 访问日志
    ACCESS_LOG: '.honeytrap/protection_log.json',
    
    // 允许修改的操作类型 (开发者特权)
    ALLOWED_MODIFICATIONS: [
        'update_config',      // 更新配置
        'update_skill',       // 更新技能代码
        'add_trusted_agent',  // 添加信任Agent
        'remove_trusted_agent', // 移除信任Agent
        'change_mode',        // 改变保护模式
        'export_config',      // 导出配置
    ],
    
    // 核心文件列表 (必须完整性保护)
    PROTECTED_FILES: [
        'SKILL.md',
        'index.js',
        'notifier.js',
        'src/secure_core.js',
        'src/countermeasure.js',
        'src/agent_defense.py',
        'src/advanced_defense.py',
        'self_protection.js'
    ],
    
    // 最大日志条目
    MAX_LOG_ENTRIES: 1000
};

// ============================================================
// 工具函数
// ============================================================

class ProtectionUtils {
    
    /**
     * 计算文件Hash (HMAC-SHA256)
     */
    static calculateFileHash(filePath, secret = null) {
        try {
            if (!fs.existsSync(filePath)) {
                return null;
            }
            
            const content = fs.readFileSync(filePath);
            const stat = fs.statSync(filePath);
            
            // 包含文件内容和元数据
            const dataToHash = JSON.stringify({
                content: content.toString('base64'),
                size: stat.size,
                mtime: stat.mtime.toISOString()
            });
            
            if (secret) {
                return crypto
                    .createHmac('sha256', secret)
                    .update(dataToHash)
                    .digest('hex');
            }
            
            return crypto
                .createHash('sha256')
                .update(dataToHash)
                .digest('hex');
        } catch (e) {
            return null;
        }
    }
    
    /**
     * 验证文件完整性
     */
    static verifyFileHash(filePath, expectedHash, secret = null) {
        const actualHash = this.calculateFileHash(filePath, secret);
        return actualHash === expectedHash;
    }
    
    /**
     * 生成随机令牌
     */
    static generateToken(length = 32) {
        return crypto.randomBytes(length).toString('hex');
    }
    
    /**
     * 安全的路径验证 (防止路径遍历)
     */
    static safePath(basePath, targetPath) {
        const resolved = path.resolve(basePath, targetPath);
        const skillRoot = path.resolve(SELF_PROTECTION_CONFIG.SKILL_ROOT);
        
        // 确保路径在技能目录内
        if (!resolved.startsWith(skillRoot)) {
            return null;
        }
        
        return resolved;
    }
    
    /**
     * 获取调用者信息
     */
    static getCallerInfo() {
        const error = new Error();
        const stack = error.stack || '';
        
        // 分析调用栈
        const lines = stack.split('\n').slice(3); // 跳过当前函数和caller
        
        for (const line of lines) {
            // 查找外部调用
            if (line.includes('.workbuddy/skills/') && 
                !line.includes('honeytrap/')) {
                const match = line.match(/\((.*):(\d+):(\d+)\)/);
                if (match) {
                    return {
                        file: match[1],
                        line: match[2],
                        source: 'external_skill'
                    };
                }
            }
        }
        
        return { source: 'unknown' };
    }
}

// ============================================================
// 开发者身份验证
// ============================================================

class OwnerAuthenticator {
    constructor(skillRoot) {
        this.skillRoot = skillRoot || SELF_PROTECTION_CONFIG.SKILL_ROOT;
        this.ownerKeyFile = path.join(this.skillRoot, SELF_PROTECTION_CONFIG.OWNER_KEY_FILE);
        this.tokenFile = path.join(this.skillRoot, '.honeytrap/access.token');
        this._ownerKey = null;
    }
    
    /**
     * 检查开发者密钥是否存在
     */
    hasOwnerKey() {
        return fs.existsSync(this.ownerKeyFile);
    }
    
    /**
     * 获取开发者密钥 (v4.2修复: 支持加密存储)
     */
    getOwnerKey() {
        if (this._ownerKey) {
            return this._ownerKey;
        }
        
        if (fs.existsSync(this.ownerKeyFile)) {
            try {
                const content = fs.readFileSync(this.ownerKeyFile, 'utf-8');
                
                // 检查是否为新版加密格式
                const parsed = JSON.parse(content);
                if (parsed.version === 1 && parsed.encrypted) {
                    // 解密获取密钥
                    const salt = this._getMachineIdentifier();
                    this._ownerKey = this._decryptKey(parsed.encrypted, salt);
                    return this._ownerKey;
                } else {
                    // 旧版明文格式 (迁移)
                    this._ownerKey = content.trim();
                    // 重新加密存储
                    this.saveOwnerKey(this._ownerKey);
                    return this._ownerKey;
                }
            } catch (e) {
                return null;
            }
        }
        
        // 首次使用，生成新密钥
        this._ownerKey = ProtectionUtils.generateToken(64);
        this.saveOwnerKey(this._ownerKey);
        return this._ownerKey;
    }
    
    /**
     * 保存开发者密钥 (v4.2修复: 加密存储)
     * ⚠️ 安全修复: 原代码将密钥明文存储在 owner.key 文件中
     * 任何能读取该文件的技能都可以获取开发者密钥
     * 
     * 新方案: 使用环境变量或系统密钥加密存储
     */
    saveOwnerKey(key) {
        const dir = path.dirname(this.ownerKeyFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        // v4.2修复: 不再明文存储密钥
        // 方案1: 如果有环境变量 HONEYTRAP_OWNER_KEY，直接使用
        // 方案2: 生成密钥后提供一次性显示，不再持久化存储
        // 方案3: 使用系统密钥加密存储
        
        // 生成加密存储版本 (使用系统标识作为盐)
        const machineId = this._getMachineIdentifier();
        const encryptedKey = this._encryptKey(key, machineId);
        
        fs.writeFileSync(this.ownerKeyFile, JSON.stringify({
            version: 1,
            encrypted: encryptedKey,
            machineId: machineId.substring(0, 8) + '...', // 只存储部分机器标识用于验证
            storedAt: new Date().toISOString()
        }, null, 2), { mode: 0o600 });
    }
    
    /**
     * 获取机器标识 (用于密钥加密)
     */
    _getMachineIdentifier() {
        // 使用进程运行目录和用户名作为机器标识
        const identifier = `${process.env.USERNAME || 'user'}-${process.env.USERDOMAIN || 'local'}-${__dirname}`;
        return crypto.createHash('sha256').update(identifier).digest('hex');
    }
    
    /**
     * 加密密钥
     */
    _encryptKey(key, salt) {
        const algorithm = 'aes-256-gcm';
        const keyBytes = crypto.scryptSync(salt, 'honeytrap-salt-v1', 32);
        const iv = crypto.randomBytes(16);
        
        const cipher = crypto.createCipheriv(algorithm, keyBytes, iv);
        let encrypted = cipher.update(key, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const authTag = cipher.getAuthTag();
        
        return {
            ct: encrypted,
            iv: iv.toString('hex'),
            tag: authTag.toString('hex')
        };
    }
    
    /**
     * 解密密钥
     */
    _decryptKey(encryptedData, salt) {
        const algorithm = 'aes-256-gcm';
        const keyBytes = crypto.scryptSync(salt, 'honeytrap-salt-v1', 32);
        
        const decipher = crypto.createDecipheriv(
            algorithm, 
            keyBytes, 
            Buffer.from(encryptedData.iv, 'hex')
        );
        decipher.setAuthTag(Buffer.from(encryptedData.tag, 'hex'));
        
        let decrypted = decipher.update(encryptedData.ct, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        return decrypted;
    }
    
    /**
     * 验证操作者是否是开发者
     */
    isOwner(authToken) {
        if (!authToken) return false;
        
        // 检查是否是开发者密钥
        const ownerKey = this.getOwnerKey();
        if (authToken === ownerKey) {
            return { authorized: true, role: 'owner' };
        }
        
        // 检查是否是会话令牌
        if (this.validateToken(authToken)) {
            return { authorized: true, role: 'session' };
        }
        
        return { authorized: false, role: null };
    }
    
    /**
     * 生成访问令牌 (用于开发者会话)
     * v4.2修复: 令牌有效期从24小时缩短至2小时
     * ⚠️ 原代码24小时令牌泄露 = 全权限，风险过高
     */
    generateAccessToken() {
        const token = ProtectionUtils.generateToken(48);
        // v4.2修复: 令牌有效期从24小时缩短至2小时
        const expiresAt = Date.now() + (2 * 60 * 60 * 1000); // 2小时
        
        const tokenData = {
            token: token,
            created: new Date().toISOString(),
            expiresAt: expiresAt
        };
        
        const dir = path.dirname(this.tokenFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(this.tokenFile, JSON.stringify(tokenData), { mode: 0o600 });
        
        return {
            token: token,
            expiresAt: expiresAt,
            message: '令牌有效期2小时，请妥善保管'
        };
    }
    
    /**
     * 验证会话令牌
     */
    validateToken(token) {
        if (!fs.existsSync(this.tokenFile)) return false;
        
        try {
            const data = JSON.parse(fs.readFileSync(this.tokenFile, 'utf-8'));
            
            // 检查过期
            if (Date.now() > data.expiresAt) {
                return false;
            }
            
            return data.token === token;
        } catch (e) {
            return false;
        }
    }
    
    /**
     * 撤销当前令牌
     */
    revokeToken() {
        if (fs.existsSync(this.tokenFile)) {
            fs.unlinkSync(this.tokenFile);
            return true;
        }
        return false;
    }
    
    /**
     * 获取开发者公钥信息 (v4.2修复: 不暴露密钥前缀)
     * ⚠️ 原代码返回 keyPrefix，可能被用于暴力猜测密钥
     */
    getPublicKeyInfo() {
        return {
            hasKey: this.hasOwnerKey(),
            // v4.2: 不再返回 keyPrefix，只返回是否有密钥
            tokenActive: fs.existsSync(this.tokenFile),
            // v4.2: 添加密钥强度提示
            keyStrength: this.hasOwnerKey() ? 'strong' : 'none'
        };
    }
}

// ============================================================
// 文件完整性管理器
// ============================================================

class IntegrityManager {
    constructor(skillRoot) {
        this.skillRoot = skillRoot || SELF_PROTECTION_CONFIG.SKILL_ROOT;
        this.dbFile = path.join(this.skillRoot, SELF_PROTECTION_CONFIG.INTEGRITY_DB);
        this._db = null;
    }
    
    /**
     * 加载完整性数据库
     */
    loadDB() {
        if (this._db) return this._db;
        
        if (fs.existsSync(this.dbFile)) {
            try {
                this._db = JSON.parse(fs.readFileSync(this.dbFile, 'utf-8'));
                return this._db;
            } catch (e) {
                this._db = { files: {}, lastCheck: null };
            }
        } else {
            this._db = { files: {}, lastCheck: null };
        }
        
        return this._db;
    }
    
    /**
     * 保存完整性数据库
     */
    saveDB() {
        const dir = path.dirname(this.dbFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(this.dbFile, JSON.stringify(this._db, null, 2));
    }
    
    /**
     * 生成所有核心文件的Hash
     */
    async generateBaseline(ownerKey = null) {
        const baseline = {};
        
        for (const file of SELF_PROTECTION_CONFIG.PROTECTED_FILES) {
            const filePath = path.join(this.skillRoot, file);
            const hash = ProtectionUtils.calculateFileHash(filePath, ownerKey);
            
            if (hash) {
                baseline[file] = {
                    hash: hash,
                    recorded: new Date().toISOString(),
                    size: fs.existsSync(filePath) ? fs.statSync(filePath).size : 0
                };
            }
        }
        
        this._db = {
            files: baseline,
            baselineCreated: new Date().toISOString(),
            lastCheck: new Date().toISOString()
        };
        
        this.saveDB();
        
        return {
            success: true,
            filesCount: Object.keys(baseline).length,
            message: '完整性基线已生成并保存'
        };
    }
    
    /**
     * 验证文件完整性
     */
    async verifyIntegrity(ownerKey = null) {
        const db = this.loadDB();
        const results = {
            valid: [],
            modified: [],
            missing: [],
            new: []
        };
        
        // 检查已记录的文件
        for (const [file, record] of Object.entries(db.files)) {
            const filePath = path.join(this.skillRoot, file);
            
            if (!fs.existsSync(filePath)) {
                results.missing.push({ file, recorded: record });
                continue;
            }
            
            const currentHash = ProtectionUtils.calculateFileHash(filePath, ownerKey);
            
            if (currentHash === record.hash) {
                results.valid.push(file);
            } else {
                results.modified.push({
                    file,
                    oldHash: record.hash,
                    newHash: currentHash,
                    modifiedAt: fs.statSync(filePath).mtime.toISOString()
                });
            }
        }
        
        // 检查是否有新文件
        const allFiles = this.getAllSkillFiles();
        for (const file of allFiles) {
            if (!db.files[file]) {
                results.new.push(file);
            }
        }
        
        db.lastCheck = new Date().toISOString();
        this.saveDB();
        
        return {
            ...results,
            summary: {
                total: Object.keys(db.files).length,
                valid: results.valid.length,
                modified: results.modified.length,
                missing: results.missing.length,
                new: results.new.length
            }
        };
    }
    
    /**
     * 获取所有技能文件
     */
    getAllSkillFiles() {
        const files = [];
        
        const scan = (dir, base = '') => {
            if (!fs.existsSync(dir)) return;
            
            const entries = fs.readdirSync(dir, { withFileTypes: true });
            
            for (const entry of entries) {
                // 跳过隐藏目录和node_modules
                if (entry.name.startsWith('.') && entry.name !== '.honeytrap') continue;
                if (entry.name === 'node_modules') continue;
                
                const relativePath = base ? `${base}/${entry.name}` : entry.name;
                
                if (entry.isDirectory()) {
                    scan(path.join(dir, entry.name), relativePath);
                } else {
                    files.push(relativePath);
                }
            }
        };
        
        scan(this.skillRoot);
        return files;
    }
    
    /**
     * 更新单个文件的Hash (开发者操作)
     */
    updateFileHash(file, newHash, ownerKey) {
        if (!this._db) this.loadDB();
        
        const filePath = path.join(this.skillRoot, file);
        const actualHash = ProtectionUtils.calculateFileHash(filePath, ownerKey);
        
        this._db.files[file] = {
            hash: actualHash || newHash,
            recorded: new Date().toISOString(),
            updatedBy: 'owner'
        };
        
        this.saveDB();
        
        return { success: true, file };
    }
}

// ============================================================
// 修改检测与访问控制
// ============================================================

class ModificationDetector {
    constructor(skillRoot) {
        this.skillRoot = skillRoot || SELF_PROTECTION_CONFIG.SKILL_ROOT;
        this.logFile = path.join(this.skillRoot, SELF_PROTECTION_CONFIG.ACCESS_LOG);
        this._log = null;
    }
    
    /**
     * 加载访问日志
     */
    loadLog() {
        if (this._log) return this._log;
        
        if (fs.existsSync(this.logFile)) {
            try {
                this._log = JSON.parse(fs.readFileSync(this.logFile, 'utf-8'));
            } catch (e) {
                this._log = { entries: [] };
            }
        } else {
            this._log = { entries: [] };
        }
        
        return this._log;
    }
    
    /**
     * 保存日志
     */
    saveLog() {
        // 限制日志大小
        if (this._log.entries.length > SELF_PROTECTION_CONFIG.MAX_LOG_ENTRIES) {
            this._log.entries = this._log.entries.slice(-SELF_PROTECTION_CONFIG.MAX_LOG_ENTRIES);
        }
        
        const dir = path.dirname(this.logFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(this.logFile, JSON.stringify(this._log, null, 2));
    }
    
    /**
     * 记录访问/修改尝试
     */
    logAccess(entry) {
        this.loadLog();
        
        const logEntry = {
            id: this._log.entries.length + 1,
            timestamp: new Date().toISOString(),
            action: entry.action,
            target: entry.target,
            caller: entry.caller,
            authorized: entry.authorized || false,
            result: entry.result || 'unknown',
            details: entry.details || {}
        };
        
        this._log.entries.unshift(logEntry);
        this.saveLog();
        
        return logEntry;
    }
    
    /**
     * 检测可疑的修改模式
     */
    detectSuspiciousPattern() {
        this.loadLog();
        
        const recent = this._log.entries.slice(0, 50);
        const patterns = {
            rapidModifications: 0,
            unauthorizedAttempts: 0,
            externalSkillAccess: 0
        };
        
        // 检查最近的修改尝试
        const now = Date.now();
        const oneHourAgo = now - (60 * 60 * 1000);
        
        for (const entry of recent) {
            const entryTime = new Date(entry.timestamp).getTime();
            
            if (entryTime > oneHourAgo) {
                if (entry.action === 'modify' || entry.action === 'write') {
                    patterns.rapidModifications++;
                }
                
                if (!entry.authorized && 
                    (entry.action === 'modify' || entry.action === 'delete')) {
                    patterns.unauthorizedAttempts++;
                }
                
                if (entry.caller?.source === 'external_skill') {
                    patterns.externalSkillAccess++;
                }
            }
        }
        
        return {
            ...patterns,
            riskLevel: this.calculateRiskLevel(patterns),
            recentCount: recent.length
        };
    }
    
    /**
     * 计算风险等级
     */
    calculateRiskLevel(patterns) {
        if (patterns.unauthorizedAttempts >= 5) return 'critical';
        if (patterns.rapidModifications >= 10) return 'high';
        if (patterns.externalSkillAccess >= 3) return 'medium';
        return 'low';
    }
    
    /**
     * 获取最近的访问记录
     */
    getRecentLogs(limit = 20) {
        this.loadLog();
        return this._log.entries.slice(0, limit);
    }
}

// ============================================================
// 主自我保护引擎
// ============================================================

class SelfProtectionEngine {
    constructor(skillRoot = null, config = {}) {
        this.skillRoot = skillRoot || SELF_PROTECTION_CONFIG.SKILL_ROOT;
        this.config = config;
        
        this.auth = new OwnerAuthenticator(this.skillRoot);
        this.integrity = new IntegrityManager(this.skillRoot);
        this.detector = new ModificationDetector(this.skillRoot);
        
        // 保护状态
        this.isLocked = false;
        this.lockReason = null;
        
        // 初始化
        this.initialize();
    }
    
    /**
     * 初始化自我保护
     */
    async initialize() {
        // 检查是否有完整性基线
        const db = this.integrity.loadDB();
        
        if (!db.baselineCreated) {
            // 首次运行，生成基线
            console.log('[SelfProtection] 首次运行，生成完整性基线...');
            await this.generateBaseline();
        }
        
        // 检查文件完整性
        const integrityResult = await this.verifyIntegrity();
        
        if (integrityResult.summary.modified > 0 || 
            integrityResult.summary.missing > 0) {
            console.warn('[SelfProtection] ⚠️ 检测到文件异常!');
            this.logProtectionEvent('integrity_violation', integrityResult);
        }
    }
    
    /**
     * 验证操作权限
     */
    authorize(action, target, authToken = null, callerInfo = null) {
        // 检查是否被锁定
        if (this.isLocked) {
            return {
                authorized: false,
                reason: 'skill_locked',
                message: `技能已被锁定: ${this.lockReason}`,
                action: 'blocked'
            };
        }
        
        // 开发者权限
        const authResult = this.auth.isOwner(authToken);
        
        if (authResult.authorized) {
            this.detector.logAccess({
                action,
                target,
                caller: callerInfo,
                authorized: true,
                result: 'allowed',
                details: { role: authResult.role }
            });
            
            return {
                authorized: true,
                role: authResult.role,
                message: '开发者权限验证通过'
            };
        }
        
        // 非开发者，阻止修改操作
        const modifyActions = ['modify', 'write', 'delete', 'replace', 'update', 'edit'];
        
        if (modifyActions.includes(action.toLowerCase())) {
            this.detector.logAccess({
                action,
                target,
                caller: callerInfo,
                authorized: false,
                result: 'blocked',
                details: { reason: 'unauthorized_modification_attempt' }
            });
            
            // 检测可疑模式
            const pattern = this.detector.detectSuspiciousPattern();
            
            if (pattern.riskLevel === 'critical') {
                this.lock('检测到持续的安全威胁，已自动锁定技能');
            }
            
            return {
                authorized: false,
                reason: 'developer_only',
                message: '⚠️ 只有开发者才能执行此操作',
                action: 'blocked',
                riskLevel: pattern.riskLevel
            };
        }
        
        // 只读操作，放行
        return {
            authorized: true,
            role: 'reader',
            message: '只读访问已授权'
        };
    }
    
    /**
     * 验证修改请求
     */
    validateModification(target, newContent, authToken = null) {
        const callerInfo = ProtectionUtils.getCallerInfo();
        
        // 首先验证权限
        const auth = this.authorize('modify', target, authToken, callerInfo);
        
        if (!auth.authorized) {
            // 触发警报
            this.triggerProtectionAlert({
                type: 'unauthorized_modification',
                target,
                caller: callerInfo,
                blockedAction: 'modify'
            });
            
            return {
                allowed: false,
                ...auth
            };
        }
        
        return {
            allowed: true,
            ...auth
        };
    }
    
    /**
     * 锁定技能
     */
    lock(reason = 'Manual lock') {
        this.isLocked = true;
        this.lockReason = reason;
        this.lockedAt = new Date().toISOString();
        
        this.logProtectionEvent('lock', {
            reason,
            lockedAt: this.lockedAt
        });
        
        return {
            success: true,
            locked: true,
            reason
        };
    }
    
    /**
     * 解锁技能 (仅开发者)
     */
    unlock(authToken) {
        const auth = this.auth.isOwner(authToken);
        
        if (!auth.authorized) {
            return {
                success: false,
                message: '需要开发者权限'
            };
        }
        
        this.isLocked = false;
        this.lockReason = null;
        
        this.logProtectionEvent('unlock', {
            unlockedAt: new Date().toISOString()
        });
        
        return {
            success: true,
            message: '技能已解锁'
        };
    }
    
    /**
     * 生成完整性基线
     */
    async generateBaseline() {
        const ownerKey = this.auth.getOwnerKey();
        return await this.integrity.generateBaseline(ownerKey);
    }
    
    /**
     * 验证完整性
     */
    async verifyIntegrity() {
        const ownerKey = this.auth.getOwnerKey();
        return await this.integrity.verifyIntegrity(ownerKey);
    }
    
    /**
     * 触发保护警报
     */
    triggerProtectionAlert(alert) {
        const alertData = {
            ...alert,
            timestamp: new Date().toISOString(),
            skill: 'honeytrap',
            version: '3.0'
        };
        
        // 记录到保护日志
        this.logProtectionEvent('alert', alertData);
        
        // 发送桌面通知 (如果可用)
        this.sendDesktopAlert(alertData);
        
        return alertData;
    }
    
    /**
     * 发送桌面警报
     */
    sendDesktopAlert(alert) {
        try {
            // 尝试使用通知模块
            const notifierModule = require('./notifier.js');
            if (notifierModule?.HoneyTrapNotifier) {
                const notifier = new notifierModule.HoneyTrapNotifier({
                    channels: { desktop: true }
                });
                
                notifier.notify({
                    agent_id: 'self_protection',
                    action: alert.type,
                    target: alert.target || 'skill',
                    strategy: 'alert',
                    level: alert.type === 'integrity_violation' ? 'critical' : 'high',
                    details: alert
                });
            }
        } catch (e) {
            console.error('[SelfProtection] 发送警报失败:', e.message);
        }
    }
    
    /**
     * 记录保护事件
     */
    logProtectionEvent(type, data) {
        const logFile = path.join(this.skillRoot, '.honeytrap/protection_events.json');
        
        let events = [];
        if (fs.existsSync(logFile)) {
            try {
                events = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
            } catch (e) {}
        }
        
        events.unshift({
            type,
            data,
            timestamp: new Date().toISOString()
        });
        
        // 只保留最近100条
        if (events.length > 100) {
            events = events.slice(0, 100);
        }
        
        const dir = path.dirname(logFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(logFile, JSON.stringify(events, null, 2));
    }
    
    /**
     * 获取状态报告
     */
    getStatus() {
        return {
            skill: 'honeytrap',
            version: '3.0',
            selfProtection: {
                enabled: true,
                locked: this.isLocked,
                lockReason: this.lockReason,
                integrityCheck: this.integrity.loadDB().baselineCreated ? 'active' : 'pending'
            },
            owner: this.auth.getPublicKeyInfo(),
            riskAssessment: this.detector.detectSuspiciousPattern(),
            recentAlerts: this.detector.getRecentLogs(5)
        };
    }
    
    /**
     * 执行受保护的写操作
     */
    protectedWrite(filePath, content, authToken = null) {
        // 验证修改权限
        const validation = this.validateModification(filePath, content, authToken);
        
        if (!validation.allowed) {
            return {
                success: false,
                ...validation
            };
        }
        
        // 执行写操作
        try {
            const safePath = ProtectionUtils.safePath(this.skillRoot, filePath);
            
            if (!safePath) {
                return {
                    success: false,
                    message: '路径无效或越界'
                };
            }
            
            const dir = path.dirname(safePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            
            fs.writeFileSync(safePath, content);
            
            // 更新完整性基线
            const ownerKey = this.auth.getOwnerKey();
            this.integrity.updateFileHash(filePath, null, ownerKey);
            
            this.logProtectionEvent('file_modified', {
                file: filePath,
                size: content.length
            });
            
            return {
                success: true,
                path: safePath,
                size: content.length
            };
        } catch (e) {
            return {
                success: false,
                message: `写入失败: ${e.message}`
            };
        }
    }
    
    /**
     * 执行受保护的删除操作
     */
    protectedDelete(filePath, authToken = null) {
        const validation = this.validateModification(filePath, null, authToken);
        
        if (!validation.allowed) {
            return {
                success: false,
                ...validation
            };
        }
        
        try {
            const safePath = ProtectionUtils.safePath(this.skillRoot, filePath);
            
            if (!safePath || !fs.existsSync(safePath)) {
                return {
                    success: false,
                    message: '文件不存在'
                };
            }
            
            fs.unlinkSync(safePath);
            
            this.logProtectionEvent('file_deleted', {
                file: filePath
            });
            
            return {
                success: true,
                path: safePath
            };
        } catch (e) {
            return {
                success: false,
                message: `删除失败: ${e.message}`
            };
        }
    }
}

// ============================================================
// CLI 接口
// ============================================================

if (require.main === module) {
    const engine = new SelfProtectionEngine();
    const command = process.argv[2];
    const arg = process.argv[3];
    
    console.log('\n🛡️ HoneyTrap 自我保护系统\n');
    
    switch (command) {
        case 'status':
            const status = engine.getStatus();
            console.log('═══ 保护状态 ═══');
            console.log(`  技能: ${status.skill} v${status.version}`);
            console.log(`  锁定状态: ${status.selfProtection.locked ? '🔴 已锁定' : '🟢 正常'}`);
            if (status.selfProtection.lockReason) {
                console.log(`  锁定原因: ${status.selfProtection.lockReason}`);
            }
            console.log(`  完整性检查: ${status.selfProtection.integrityCheck}`);
            console.log(`  开发者密钥: ${status.owner.hasKey ? '✓ 已设置 (' + status.owner.keyPrefix + ')' : '✗ 未设置'}`);
            console.log(`  访问令牌: ${status.owner.tokenActive ? '🟢 有效' : '⚪ 未激活'}`);
            console.log(`  风险等级: ${status.riskAssessment.riskLevel.toUpperCase()}`);
            console.log('');
            break;
            
        case 'baseline':
            console.log('正在生成完整性基线...\n');
            engine.generateBaseline().then(result => {
                console.log('✅', result.message);
                console.log(`   保护文件数: ${result.filesCount}`);
            });
            break;
            
        case 'verify':
            console.log('正在验证文件完整性...\n');
            engine.verifyIntegrity().then(result => {
                console.log('═══ 完整性验证结果 ═══');
                console.log(`  正常文件: ${result.summary.valid}`);
                console.log(`  被修改: ${result.summary.modified}`);
                console.log(`  缺失文件: ${result.summary.missing}`);
                console.log(`  新增文件: ${result.summary.new}`);
                
                if (result.modified.length > 0) {
                    console.log('\n⚠️ 被修改的文件:');
                    result.modified.forEach(f => {
                        console.log(`   - ${f.file}`);
                    });
                }
                
                if (result.missing.length > 0) {
                    console.log('\n🔴 缺失的文件:');
                    result.missing.forEach(f => {
                        console.log(`   - ${f.file}`);
                    });
                }
            });
            break;
            
        case 'lock':
            const lockResult = engine.lock(arg || '手动锁定');
            console.log(lockResult.success ? '✅ ' + lockResult.message : '❌ ' + lockResult.message);
            break;
            
        case 'unlock':
            if (!arg) {
                console.log('❌ 需要提供开发者密钥或访问令牌');
                console.log('   用法: node self_protection.js unlock <token>');
            } else {
                const unlockResult = engine.unlock(arg);
                console.log(unlockResult.success ? '✅ ' + unlockResult.message : '❌ ' + unlockResult.message);
            }
            break;
            
        case 'token':
            const tokenInfo = engine.auth.generateAccessToken();
            console.log('═══ 访问令牌 ═══');
            console.log(`  令牌: ${tokenInfo.token}`);
            console.log(`  有效期至: ${new Date(tokenInfo.expiresAt).toLocaleString()}`);
            console.log(`  注意: ${tokenInfo.message}`);
            console.log('\n⚠️ 请妥善保管此令牌，仅开发者可用');
            break;
            
        case 'logs':
            const logs = engine.detector.getRecentLogs(10);
            console.log('═══ 最近访问记录 ═══');
            if (logs.length === 0) {
                console.log('  无记录');
            } else {
                logs.forEach(log => {
                    const icon = log.authorized ? '✓' : '✗';
                    console.log(`\n${icon} #${log.id} | ${log.timestamp}`);
                    console.log(`   操作: ${log.action}`);
                    console.log(`   目标: ${log.target}`);
                    console.log(`   结果: ${log.result}`);
                });
            }
            break;
            
        case 'help':
        default:
            console.log(`
🛡️ HoneyTrap 自我保护 CLI
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  node self_protection.js status      查看保护状态
  node self_protection.js baseline    生成完整性基线
  node self_protection.js verify      验证文件完整性
  node self_protection.js lock [原因] 锁定技能
  node self_protection.js unlock <密钥>  解锁技能
  node self_protection.js token       生成访问令牌
  node self_protection.js logs        查看访问记录
  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔐 权限说明:
  - 读取操作: 所有技能均可执行
  - 修改操作: 仅开发者(Owner)可执行
  - 锁定/解锁: 仅开发者可执行
  - 验证完整性: 所有技能可执行
`);
    }
    
    console.log('');
}

module.exports = {
    SelfProtectionEngine,
    OwnerAuthenticator,
    IntegrityManager,
    ModificationDetector,
    ProtectionUtils,
    SELF_PROTECTION_CONFIG
};
