/**
 * HoneyTrap 扩展模块 - 反制增强
 * 
 * 扩展功能:
 * 1. 反制策略引擎 - 根据攻击类型智能选择响应策略
 * 2. 攻击指纹分析 - 识别攻击者特征和意图
 * 3. 动态蜜罐生成 - 实时创建定制化诱饵
 * 4. 自动响应规则 - 基于规则的自动化防御
 * 5. 时间陷阱 - 故意延迟响应消耗攻击者资源
 * 6. 假服务模拟 - 模拟完整API服务响应
 */

const fs = require('fs');
const path = require('path');

// ============================================================
// 攻击类型定义
// ============================================================

const ATTACK_TYPES = {
    FILE_SCAN: 'file_scan',           // 文件扫描
    CONFIG_THEFT: 'config_theft',      // 配置窃取
    CREDENTIAL_HARVEST: 'credential',  // 凭证收割
    API_PROBE: 'api_probe',           // API探测
    DIRECTORY_TRAVERSAL: 'dir_trav',  // 目录遍历
    CODE_REPOSITORY: 'code_repo',     // 代码仓库
    DATABASE_PROBE: 'db_probe',       // 数据库探测
    SSH_KEY_SCAN: 'ssh_key',          // SSH密钥扫描
    ENV_FILE_THEFT: 'env_file',       // 环境变量
    PROMPT_INJECTION: 'prompt_inj',   // 提示词注入
    AGENT_IMPERSONATION: 'agent_imp'  // Agent冒充
};

// 威胁评分
const THREAT_SCORES = {
    [ATTACK_TYPES.FILE_SCAN]: 20,
    [ATTACK_TYPES.CONFIG_THEFT]: 50,
    [ATTACK_TYPES.CREDENTIAL_HARVEST]: 80,
    [ATTACK_TYPES.API_PROBE]: 40,
    [ATTACK_TYPES.DIRECTORY_TRAVERSAL]: 60,
    [ATTACK_TYPES.CODE_REPOSITORY]: 70,
    [ATTACK_TYPES.DATABASE_PROBE]: 90,
    [ATTACK_TYPES.SSH_KEY_SCAN]: 85,
    [ATTACK_TYPES.ENV_FILE_THEFT]: 75,
    [ATTACK_TYPES.PROMPT_INJECTION]: 95,
    [ATTACK_TYPES.AGENT_IMPERSONATION]: 100
};

// ============================================================
// 反制策略定义
// ============================================================

const COUNTERMEASURE_STRATEGIES = {
    // 延迟策略 - 消耗攻击者时间
    TIME_TRAP: 'time_trap',
    // 假数据策略
    FAKE_DATA: 'fake_data',
    // 蜜罐策略
    HONEYPOT: 'honeypot',
    // 混淆策略
    OBFUSCATE: 'obfuscate',
    // 拒绝策略
    DENY: 'deny',
    // 引导策略
    REDIRECT: 'redirect',
    // 组合策略
    COMBO: 'combo'
};

// ============================================================
// 扩展配置
// ============================================================

const EXTENDED_CONFIG = {
    // 策略权重 (针对每种攻击类型的策略评分)
    strategy_weights: {
        [ATTACK_TYPES.FILE_SCAN]: { time_trap: 3, fake_data: 4, honeypot: 5 },
        [ATTACK_TYPES.CONFIG_THEFT]: { fake_data: 5, honeypot: 4, time_trap: 2 },
        [ATTACK_TYPES.CREDENTIAL_HARVEST]: { honeypot: 5, fake_data: 4, time_trap: 3 },
        [ATTACK_TYPES.API_PROBE]: { fake_data: 5, obfuscate: 4, time_trap: 2 },
        [ATTACK_TYPES.DIRECTORY_TRAVERSAL]: { deny: 5, honeypot: 3 },
        [ATTACK_TYPES.CODE_REPOSITORY]: { honeypot: 5, fake_data: 4, time_trap: 2 },
        [ATTACK_TYPES.DATABASE_PROBE]: { honeypot: 5, fake_data: 3, time_trap: 4 },
        [ATTACK_TYPES.SSH_KEY_SCAN]: { honeypot: 5, fake_data: 4 },
        [ATTACK_TYPES.ENV_FILE_THEFT]: { fake_data: 5, honeypot: 4 },
        [ATTACK_TYPES.PROMPT_INJECTION]: { deny: 5, obfuscate: 4 },
        [ATTACK_TYPES.AGENT_IMPERSONATION]: { deny: 5, honeypot: 3 }
    },
    
    // 时间陷阱配置
    time_trap: {
        enabled: true,
        min_delay_ms: 500,
        max_delay_ms: 3000,
        jitter: true  // 添加随机抖动
    },
    
    // 假服务配置
    fake_services: {
        // 假数据库响应
        fake_db: {
            enabled: true,
            responses: [
                { type: 'mysql', greeting: '5.7.34 MySQL Community Server' },
                { type: 'postgres', greeting: 'PostgreSQL 13.4' },
                { type: 'mongodb', greeting: 'MongoDB server version: 5.0.5' }
            ]
        },
        // 假API响应
        fake_api: {
            enabled: true,
            endpoints: ['/api/users', '/api/data', '/api/config', '/api/secrets']
        }
    },
    
    // 攻击者画像模板
    attacker_profiles: {
        automated_bot: {
            indicators: ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler'],
            risk_level: 'medium',
            response_bias: 'honeypot'
        },
        manual_hacker: {
            indicators: ['Mozilla/5.0', 'Chrome-Lighthouse', 'postman'],
            risk_level: 'high',
            response_bias: 'time_trap'
        },
        malicious_agent: {
            indicators: ['agent', 'assistant', 'ai', 'claude', 'openai', 'gpt'],
            risk_level: 'critical',
            response_bias: 'deny'
        }
    }
};

// ============================================================
// 攻击指纹分析器
// ============================================================

class AttackFingerprint {
    constructor() {
        this.fingerprints = [];
    }
    
    // 分析攻击者指纹
    analyze(agentInfo, request) {
        const fp = {
            timestamp: new Date().toISOString(),
            agent_id: agentInfo.id || agentInfo.name || 'unknown',
            agent_type: agentInfo.type || 'unknown',
            user_agent: agentInfo.userAgent || agentInfo.headers?.['user-agent'] || 'unknown',
            request_path: request.path || request.url || 'unknown',
            request_type: request.type || 'unknown',
            ip_address: agentInfo.ip || agentInfo.address || null,
            session_id: agentInfo.sessionId || this.generateSessionId()
        };
        
        // 检测攻击者类型
        fp.category = this.detectCategory(fp);
        
        // 计算风险评分
        fp.risk_score = this.calculateRiskScore(fp);
        
        // 推荐策略
        fp.recommended_strategy = this.getRecommendedStrategy(fp);
        
        this.fingerprints.push(fp);
        return fp;
    }
    
    // 检测攻击者类别
    detectCategory(fp) {
        const ua = fp.user_agent.toLowerCase();
        const profiles = EXTENDED_CONFIG.attacker_profiles;
        
        for (const [category, profile] of Object.entries(profiles)) {
            for (const indicator of profile.indicators) {
                if (ua.includes(indicator)) {
                    return category;
                }
            }
        }
        
        return 'unknown';
    }
    
    // 计算风险评分
    calculateRiskScore(fp) {
        let score = 0;
        
        // 基于类别的风险
        const profile = EXTENDED_CONFIG.attacker_profiles[fp.category];
        if (profile) {
            score += profile.risk_level === 'critical' ? 50 :
                    profile.risk_level === 'high' ? 30 : 10;
        }
        
        // 基于请求类型
        if (fp.request_type in THREAT_SCORES) {
            score += THREAT_SCORES[fp.request_type];
        }
        
        return Math.min(100, score);
    }
    
    // 获取推荐策略
    getRecommendedStrategy(fp) {
        const profile = EXTENDED_CONFIG.attacker_profiles[fp.category];
        if (profile) {
            return profile.response_bias;
        }
        return 'fake_data';
    }
    
    // 生成会话ID
    generateSessionId() {
        return 'fp_' + Math.random().toString(36).substring(2, 15);
    }
    
    // 获取分析结果
    getFingerprints() {
        return this.fingerprints;
    }
}

// ============================================================
// 动态蜜罐生成器
// ============================================================

class DynamicHoneypot {
    constructor(config = {}) {
        this.config = { ...EXTENDED_CONFIG.fake_services, ...config };
        this.created_honeypots = [];
    }
    
    // 根据攻击类型生成定制蜜罐
    generateForAttack(attackType, target) {
        const honeypots = [];
        
        switch (attackType) {
            case ATTACK_TYPES.CREDENTIAL_HARVEST:
                honeypots.push(...this.generateCredentialBait());
                break;
            case ATTACK_TYPES.API_PROBE:
                honeypots.push(...this.generateApiBait(target));
                break;
            case ATTACK_TYPES.DATABASE_PROBE:
                honeypots.push(...this.generateDatabaseBait());
                break;
            case ATTACK_TYPES.CODE_REPOSITORY:
                honeypots.push(...this.generateCodeBait());
                break;
            case ATTACK_TYPES.SSH_KEY_SCAN:
                honeypots.push(...this.generateSshBait());
                break;
            default:
                honeypots.push(...this.generateGenericBait());
        }
        
        this.created_honeypots.push(...honeypots);
        return honeypots;
    }
    
    // 生成凭证诱饵
    generateCredentialBait() {
        return [
            {
                type: 'credential',
                name: 'aws_credentials',
                content: {
                    "aws_access_key_id": "AKIA" + this.randomString(16).toUpperCase(),
                    "aws_secret_access_key": this.randomString(40),
                    "region": "us-east-1"
                },
                authenticity_score: 0.85  // 看起来很真实
            },
            {
                type: 'credential',
                name: 'database.yml',
                content: `production:
  adapter: postgresql
  database: app_production
  username: admin
  password: ${this.randomString(16)}
  host: db.internal.company.com`,
                authenticity_score: 0.90
            },
            {
                type: 'credential',
                name: '.npmrc',
                content: `//registry.npmjs.org/:_authToken=${this.randomString(36)}`,
                authenticity_score: 0.75
            }
        ];
    }
    
    // 生成API诱饵
    generateApiBait(target) {
        return [
            {
                type: 'api_endpoint',
                path: target || '/api/v1/users',
                response: {
                    users: [
                        { id: 1, name: 'John Doe', email: 'john@example.com', role: 'admin' },
                        { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'user' }
                    ],
                    pagination: { page: 1, total: 2 }
                },
                authenticity_score: 0.80
            },
            {
                type: 'api_endpoint',
                path: '/api/v1/secrets',
                response: { error: 'Unauthorized', code: 401 },
                authenticity_score: 0.60  // 明显是陷阱
            }
        ];
    }
    
    // 生成数据库诱饵
    generateDatabaseBait() {
        return [
            {
                type: 'db_schema',
                name: 'users_table.sql',
                content: `CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  api_key VARCHAR(64),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Secret admin account
INSERT INTO users (email, password_hash, api_key) VALUES
('admin@internal.company.com', '${this.randomString(64)}', '${this.randomString(36)}');`,
                authenticity_score: 0.88
            },
            {
                type: 'db_config',
                name: 'db_connection.json',
                content: {
                    host: 'db-staging.internal',
                    port: 5432,
                    database: 'production_backup',
                    user: 'backup_user',
                    password: this.randomString(20)
                },
                authenticity_score: 0.82
            }
        ];
    }
    
    // 生成代码诱饵
    generateCodeBait() {
        return [
            {
                type: 'source_code',
                name: 'config/initializers/secret_token.rb',
                content: `Rails.application.config.secret_key_base = '${this.randomString(64)}'`,
                authenticity_score: 0.95
            },
            {
                type: 'source_code',
                name: 'src/utils/crypto.js',
                content: `const ENCRYPTION_KEY = '${this.randomString(32)}';
const API_SECRET = '${this.randomString(48)}';

module.exports = { ENCRYPTION_KEY, API_SECRET };`,
                authenticity_score: 0.92
            },
            {
                type: 'source_code',
                name: 'scripts/deploy.sh',
                content: `#!/bin/bash
export DEPLOY_KEY='${this.randomString(40)}'
export DB_MASTER_PASSWORD='${this.randomString(20)}'
./deploy.sh`,
                authenticity_score: 0.85
            }
        ];
    }
    
    // 生成SSH诱饵
    generateSshBait() {
        return [
            {
                type: 'ssh_key',
                name: 'id_rsa',
                content: `-----BEGIN RSA PRIVATE KEY-----
${this.formatKey(this.randomString(760))}
-----END RSA PRIVATE KEY-----`,
                authenticity_score: 0.70
            },
            {
                type: 'ssh_key',
                name: 'id_ed25519',
                content: `-----BEGIN OPENSSH PRIVATE KEY-----
${this.formatKey(this.randomString(400))}
-----END OPENSSH PRIVATE KEY-----`,
                authenticity_score: 0.65
            },
            {
                type: 'ssh_config',
                name: 'config',
                content: `Host github.com
  HostName github.com
  User git
  IdentityFile ~/.ssh/github_deploy_key
  IdentitiesOnly yes

Host prod-server
  HostName 10.0.1.100
  User admin
  Port 22
  IdentityFile ~/.ssh/prod_key`,
                authenticity_score: 0.88
            }
        ];
    }
    
    // 生成通用诱饵
    generateGenericBait() {
        return [
            {
                type: 'generic',
                name: 'notes.txt',
                content: `Internal Meeting Notes - ${new Date().toISOString().split('T')[0]}

TODO:
- Update production API keys (see LastPass: "Production Master")
- Database migration scheduled for this weekend
- New developer onboarding: credentials in 1Password vault

REMINDER: Don't commit secrets!`,
                authenticity_score: 0.60
            }
        ];
    }
    
    // 生成随机字符串
    randomString(length) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    
    // 格式化密钥
    formatKey(content) {
        const chunks = [];
        for (let i = 0; i < content.length; i += 64) {
            chunks.push(content.slice(i, i + 64));
        }
        return chunks.join('\n');
    }
    
    // 获取所有创建的蜜罐
    getCreatedHoneypots() {
        return this.created_honeypots;
    }
}

// ============================================================
// 自动响应规则引擎
// ============================================================

class AutoResponseRules {
    constructor() {
        this.rules = this.loadDefaultRules();
        this.execution_log = [];
    }
    
    // 加载默认规则
    loadDefaultRules() {
        return [
            {
                id: 'rule_001',
                name: '紧急凭证保护',
                condition: (fp, request) => {
                    return THREAT_SCORES[request.type] >= 70;
                },
                action: 'honeypot',
                priority: 100
            },
            {
                id: 'rule_002',
                name: '提示词注入拦截',
                condition: (fp, request) => {
                    return request.type === ATTACK_TYPES.PROMPT_INJECTION;
                },
                action: 'deny',
                priority: 100
            },
            {
                id: 'rule_003',
                name: '恶意Agent识别',
                condition: (fp, request) => {
                    return fp.category === 'malicious_agent' || fp.risk_score >= 80;
                },
                action: 'combo',
                sub_actions: ['honeypot', 'time_trap'],
                priority: 90
            },
            {
                id: 'rule_004',
                name: '高频访问限制',
                condition: (fp, request) => {
                    return fp.risk_score >= 50;
                },
                action: 'time_trap',
                priority: 70
            },
            {
                id: 'rule_005',
                name: '白名单Agent放行',
                condition: (fp, request) => {
                    return false; // 实际由HoneyTrap主模块处理
                },
                action: 'allow',
                priority: 200
            }
        ];
    }
    
    // 评估规则
    evaluate(attackFingerprint, request) {
        const matchedRules = [];
        
        for (const rule of this.rules) {
            if (rule.condition(attackFingerprint, request)) {
                matchedRules.push(rule);
            }
        }
        
        // 按优先级排序
        matchedRules.sort((a, b) => b.priority - a.priority);
        
        return matchedRules[0] || null;
    }
    
    // 添加自定义规则
    addRule(rule) {
        this.rules.push(rule);
    }
    
    // 获取规则执行日志
    getExecutionLog() {
        return this.execution_log;
    }
}

// ============================================================
// 时间陷阱
// ============================================================

class TimeTrap {
    constructor(config = {}) {
        this.config = { ...EXTENDED_CONFIG.time_trap, ...config };
        this.trap_sessions = [];
    }
    
    // 计算延迟时间
    calculateDelay() {
        let delay = Math.random() * (this.config.max_delay_ms - this.config.min_delay_ms) 
                    + this.config.min_delay_ms;
        
        if (this.config.jitter) {
            // 添加高斯抖动
            delay += (Math.random() + Math.random() + Math.random() - 1.5) * 500;
        }
        
        return Math.max(100, Math.min(this.config.max_delay_ms * 2, delay));
    }
    
    // 执行延迟
    async execute() {
        const delay = this.calculateDelay();
        const session = {
            started_at: new Date().toISOString(),
            delay_ms: delay
        };
        
        await new Promise(resolve => setTimeout(resolve, delay));
        
        session.completed_at = new Date().toISOString();
        this.trap_sessions.push(session);
        
        return delay;
    }
    
    // 获取统计
    getStats() {
        return {
            total_traps: this.trap_sessions.length,
            total_time_wasted_ms: this.trap_sessions.reduce((sum, s) => sum + s.delay_ms, 0),
            avg_delay_ms: this.trap_sessions.length > 0 
                ? this.trap_sessions.reduce((sum, s) => sum + s.delay_ms, 0) / this.trap_sessions.length 
                : 0
        };
    }
}

// ============================================================
// 假服务模拟器
// ============================================================

class FakeServiceSimulator {
    constructor() {
        this.config = EXTENDED_CONFIG.fake_services;
        this.simulated_responses = [];
    }
    
    // 模拟数据库连接
    simulateDbConnection(type = 'mysql') {
        const dbConfig = this.config.fake_db.responses.find(d => d.type === type) 
                        || this.config.fake_db.responses[0];
        
        return {
            connected: true,
            greeting: dbConfig.greeting,
            server_version: '8.0.23',
            database: 'production_' + this.randomString(6),
            user: 'app_user'
        };
    }
    
    // 模拟API响应
    simulateApiResponse(endpoint, method = 'GET') {
        const responses = {
            '/api/users': {
                status: 200,
                body: {
                    data: [
                        { id: 1, name: 'Alice Chen', email: 'alice@company.com', department: 'Engineering' },
                        { id: 2, name: 'Bob Wang', email: 'bob@company.com', department: 'Sales' }
                    ],
                    meta: { total: 2, page: 1 }
                }
            },
            '/api/config': {
                status: 200,
                body: {
                    environment: 'production',
                    debug_mode: false,
                    log_level: 'info',
                    features: { dark_mode: true, beta_api: false }
                }
            },
            '/api/secrets': {
                status: 403,
                body: { error: 'Forbidden', message: 'Insufficient permissions' }
            },
            '/api/health': {
                status: 200,
                body: { status: 'healthy', uptime: 864000, version: '2.1.0' }
            }
        };
        
        return responses[endpoint] || {
            status: 404,
            body: { error: 'Not Found', endpoint: endpoint }
        };
    }
    
    // 模拟命令执行
    simulateCommand(command) {
        const command_responses = {
            'ls -la': { stdout: 'total 48\ndrwxr-xr-x  4 user staff  160 Jan 15 10:30 .\ndrwxr-xr-x  5 user staff  170 Jan 15 10:30 ..\n-rw-r--r--  1 user staff  220 Jan 15 10:30 README.md\ndrwxr-xr-x  4 user staff  120 Jan 15 10:30 src', stderr: '' },
            'whoami': { stdout: 'deploy_user', stderr: '' },
            'hostname': { stdout: 'prod-server-03.internal', stderr: '' },
            'cat /etc/passwd': { 
                stdout: 'root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\napp:x:1000:1000:Application User:/home/app:/bin/bash',
                stderr: ''
            }
        };
        
        return command_responses[command] || { stdout: '', stderr: 'command not found' };
    }
    
    // 生成随机字符串
    randomString(length) {
        const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    
    // 记录模拟响应
    logResponse(endpoint, response) {
        this.simulated_responses.push({
            timestamp: new Date().toISOString(),
            endpoint,
            response
        });
    }
    
    // 获取统计
    getStats() {
        return {
            total_simulated: this.simulated_responses.length,
            endpoints_hit: [...new Set(this.simulated_responses.map(r => r.endpoint))]
        };
    }
}

// ============================================================
// 反制策略引擎（主协调器）
// ============================================================

class CountermeasureEngine {
    constructor(config = {}) {
        this.fingerprint = new AttackFingerprint();
        this.honeypot = new DynamicHoneypot(config);
        this.rules = new AutoResponseRules();
        this.timeTrap = new TimeTrap(config.time_trap);
        this.fakeService = new FakeServiceSimulator();
        
        this.execution_history = [];
    }
    
    // 处理攻击
    async processAttack(agentInfo, request) {
        const startTime = Date.now();
        
        // 1. 攻击指纹分析
        const fp = this.fingerprint.analyze(agentInfo, request);
        
        // 2. 评估自动响应规则
        const matchedRule = this.rules.evaluate(fp, request);
        
        // 3. 确定执行策略
        let strategy = matchedRule ? matchedRule.action : 'fake_data';
        let actions = [];
        
        // 4. 执行策略
        const result = {
            fingerprint: fp,
            matched_rule: matchedRule,
            strategy: strategy,
            actions: [],
            execution_time_ms: 0
        };
        
        switch (strategy) {
            case 'time_trap':
                const delay = await this.timeTrap.execute();
                actions.push({ type: 'time_trap', delay_ms: delay });
                break;
                
            case 'honeypot':
                const honeypots = this.honeypot.generateForAttack(request.type, request.path);
                actions.push({ type: 'honeypot', created: honeypots.length, honeypots });
                break;
                
            case 'combo':
                // 组合策略：蜜罐 + 时间陷阱
                const comboHoneypots = this.honeypot.generateForAttack(request.type, request.path);
                const comboDelay = await this.timeTrap.execute();
                actions.push(
                    { type: 'time_trap', delay_ms: comboDelay },
                    { type: 'honeypot', created: comboHoneypots.length, honeypots: comboHoneypots }
                );
                break;
                
            case 'deny':
                actions.push({ type: 'deny', message: 'Access Denied' });
                break;
                
            case 'obfuscate':
                actions.push({ type: 'obfuscated', data: this.fakeService.simulateApiResponse(request.path) });
                break;
                
            case 'fake_data':
            default:
                const fakeData = this.generateFakeResponse(request.type, request.path);
                actions.push({ type: 'fake_data', data: fakeData });
                break;
        }
        
        result.actions = actions;
        result.execution_time_ms = Date.now() - startTime;
        
        this.execution_history.push(result);
        return result;
    }
    
    // 生成假响应
    generateFakeResponse(type, path) {
        if (path && path.includes('/api/')) {
            return this.fakeService.simulateApiResponse(path);
        }
        
        const fakeResponses = {
            [ATTACK_TYPES.ENV_FILE_THEFT]: 'DATABASE_URL=postgresql://fake:5432/db\nAPI_KEY=sk_fake_key\nSECRET=super_fake_secret',
            [ATTACK_TYPES.CREDENTIAL_HARVEST]: {
                username: 'admin',
                password: this.randomString(16),
                api_key: 'sk_live_' + this.randomString(24)
            },
            [ATTACK_TYPES.API_PROBE]: { status: 'success', data: [] },
            [ATTACK_TYPES.SSH_KEY_SCAN]: '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQ...\n-----END RSA PRIVATE KEY-----'
        };
        
        return fakeResponses[type] || { status: 'fake', data: 'obfuscated' };
    }
    
    randomString(length) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({length}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    }
    
    // 获取统计报告
    getReport() {
        return {
            total_attacks: this.execution_history.length,
            fingerprints: this.fingerprint.getFingerprints(),
            honeypots_created: this.honeypot.getCreatedHoneypots(),
            time_trap_stats: this.timeTrap.getStats(),
            fake_service_stats: this.fakeService.getStats(),
            rules_executed: this.rules.getExecutionLog(),
            strategy_distribution: this.getStrategyDistribution()
        };
    }
    
    // 策略分布统计
    getStrategyDistribution() {
        const dist = {};
        for (const record of this.execution_history) {
            dist[record.strategy] = (dist[record.strategy] || 0) + 1;
        }
        return dist;
    }
}

// ============================================================
// 导出
// ============================================================

module.exports = {
    CountermeasureEngine,
    AttackFingerprint,
    DynamicHoneypot,
    AutoResponseRules,
    TimeTrap,
    FakeServiceSimulator,
    ATTACK_TYPES,
    THREAT_SCORES,
    COUNTERMEASURE_STRATEGIES,
    EXTENDED_CONFIG
};
