/**
 * HoneyTrap v4.0 - 杀毒引擎核心模块
 *
 * 基于传统杀毒软件和现代XDR/EDR架构设计的AI Agent防御系统
 *
 * 核心架构来源:
 * - 特征码扫描 (Norton, 卡巴斯基)
 * - 主动防御 (360, 火绒)
 * - EDR行为分析 (CrowdStrike, Microsoft Defender)
 * - XDR智能检测 (Palo Alto, 深信服)
 *
 * 技术特点:
 * - 三层检测: 静态扫描 + 动态行为分析 + 启发式检测
 * - 四层防御: 指纹识别 → 行为监控 → 风险评分 → 自动响应
 * - 五种能力: 感知/分析/决策/响应/取证
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 导入子模块
const AttackFingerprint = require('./av-modules/attack_fingerprint');
const BehaviorMonitor = require('./av-modules/behavior_monitor');
const HeuristicEngine = require('./av-modules/heuristic_engine');
const AutoResponder = require('./av-modules/auto_responder');
const ThreatIntel = require('./av-modules/threat_intel');
const Forensics = require('./av-modules/forensics');

class DefenseEngine {
    constructor(options = {}) {
        this.basePath = options.basePath || path.dirname(require.main.filename);
        this.dataPath = path.join(this.basePath, 'data');
        this.rulesPath = path.join(this.basePath, 'rules');

        // 防御状态
        this.status = {
            enabled: true,
            mode: 'normal', // normal, paranoid, learning
            lastScan: null,
            threatLevel: 0, // 0-100
            totalScans: 0,
            threatsBlocked: 0
        };

        // 威胁统计
        this.stats = {
            fingerprintHits: 0,
            behaviorAlerts: 0,
            heuristicFlags: 0,
            autoBlocks: 0,
            falsePositives: 0
        };

        // 初始化子模块
        this.initModules(options);
    }

    initModules(options) {
        // 攻击指纹库 (特征码扫描)
        this.fingerprint = new AttackFingerprint({
            basePath: this.basePath,
            dataPath: this.dataPath,
            rulesPath: this.rulesPath
        });

        // 行为监控引擎 (主动防御)
        this.behavior = new BehaviorMonitor({
            basePath: this.basePath,
            sensitivity: options.sensitivity || 'medium'
        });

        // 启发式检测引擎 (启发式扫描)
        this.heuristic = new HeuristicEngine({
            basePath: this.basePath,
            thresholds: options.heuristicThresholds || {
                low: 30,
                medium: 50,
                high: 70,
                critical: 90
            }
        });

        // 自动响应系统 (EDR响应)
        this.responder = new AutoResponder({
            basePath: this.basePath,
            autoResponse: options.autoResponse !== false
        });

        // 威胁情报中心 (云查杀)
        this.threatIntel = new ThreatIntel({
            basePath: this.basePath,
            syncInterval: options.threatIntelSync || 3600000 // 1小时
        });

        // 取证分析模块 (EDR取证)
        this.forensics = new Forensics({
            basePath: this.basePath,
            dataPath: this.dataPath
        });
    }

    /**
     * 扫描文件或内容 (静态扫描 - 特征码技术)
     */
    async scan(target, options = {}) {
        const startTime = Date.now();
        const results = {
            timestamp: new Date().toISOString(),
            target: target,
            scanDuration: 0,
            threats: [],
            riskLevel: 0,
            modules: {}
        };

        try {
            // 1. 指纹扫描 (特征码匹配)
            results.modules.fingerprint = await this.fingerprint.scan(target);

            // 2. 启发式扫描 (启发式分析)
            results.modules.heuristic = await this.heuristic.analyze(target);

            // 3. 威胁情报查询 (云查杀)
            results.modules.threatIntel = await this.threatIntel.query(target);

            // 综合风险评分
            results.riskLevel = this.calculateRiskScore(results.modules);

            // 检测到的威胁
            if (results.modules.fingerprint.matches.length > 0) {
                results.threats.push(...results.modules.fingerprint.matches);
            }
            if (results.modules.heuristic.threats.length > 0) {
                results.threats.push(...results.modules.heuristic.threats);
            }
            if (results.modules.threatIntel.matches.length > 0) {
                results.threats.push(...results.modules.threatIntel.matches);
            }

            // 记录扫描
            results.scanDuration = Date.now() - startTime;
            this.status.lastScan = new Date().toISOString();
            this.status.totalScans++;

            // 写入取证日志
            await this.forensics.logScan(results);

            return results;

        } catch (error) {
            results.error = error.message;
            results.scanDuration = Date.now() - startTime;
            return results;
        }
    }

    /**
     * 监控Agent行为 (动态扫描 - 行为分析)
     */
    async monitorAction(action, context = {}) {
        const event = {
            timestamp: new Date().toISOString(),
            action: action,
            context: context,
            riskLevel: 0,
            verdict: 'unknown',
            triggeredRules: []
        };

        try {
            // 1. 行为规则检查
            const behaviorResult = await this.behavior.checkAction(action, context);
            event.riskLevel = Math.max(event.riskLevel, behaviorResult.riskLevel);
            event.triggeredRules.push(...behaviorResult.matchedRules);

            // 2. 启发式风险评估
            const heuristicResult = await this.heuristic.evaluateAction(action, context);
            event.riskLevel = Math.max(event.riskLevel, heuristicResult.riskLevel);

            // 3. 恶意行为指纹匹配
            const fingerprintResult = await this.fingerprint.matchBehavior(action);
            if (fingerprintResult.match) {
                event.riskLevel = Math.max(event.riskLevel, fingerprintResult.confidence);
                event.triggeredRules.push(fingerprintResult.rule);
            }

            // 4. 决策判定
            event.verdict = this.makeVerdict(event.riskLevel, event.triggeredRules);

            // 5. 风险阈值更新
            this.status.threatLevel = Math.max(this.status.threatLevel, event.riskLevel);

            // 6. 自动响应
            if (event.verdict === 'block' || event.verdict === 'terminate') {
                await this.responder.execute(event);
                this.stats.autoBlocks++;
                this.status.threatsBlocked++;
            }

            // 7. 记录行为日志
            await this.forensics.logAction(event);

            // 更新统计
            if (event.riskLevel > 0) {
                this.stats.behaviorAlerts++;
            }

            return event;

        } catch (error) {
            event.error = error.message;
            event.verdict = 'error';
            return event;
        }
    }

    /**
     * 综合风险评分计算
     */
    calculateRiskScore(modules) {
        let score = 0;
        const weights = {
            fingerprint: 0.4,  // 指纹匹配权重最高
            heuristic: 0.3,   // 启发式分析权重
            threatIntel: 0.3  // 威胁情报权重
        };

        // 指纹匹配得分
        if (modules.fingerprint && modules.fingerprint.matches.length > 0) {
            const avgConfidence = modules.fingerprint.matches.reduce((sum, m) => sum + m.confidence, 0) / modules.fingerprint.matches.length;
            score += avgConfidence * weights.fingerprint;
        }

        // 启发式分析得分
        if (modules.heuristic && modules.heuristic.threats.length > 0) {
            const avgRisk = modules.heuristic.threats.reduce((sum, t) => sum + t.riskLevel, 0) / modules.heuristic.threats.length;
            score += avgRisk * weights.heuristic;
        }

        // 威胁情报匹配得分
        if (modules.threatIntel && modules.threatIntel.matches.length > 0) {
            const avgSeverity = modules.threatIntel.matches.reduce((sum, m) => sum + m.severity, 0) / modules.threatIntel.matches.length;
            score += avgSeverity * weights.threatIntel;
        }

        return Math.min(100, Math.round(score));
    }

    /**
     * 决策判定
     */
    makeVerdict(riskLevel, triggeredRules) {
        // 关键规则触发直接阻止
        const criticalRules = triggeredRules.filter(r => r.severity === 'critical' || r.severity === 'high');
        if (criticalRules.length > 0) {
            return 'block';
        }

        // 极高风险直接阻止
        if (riskLevel >= 90) {
            return 'terminate';
        }
        if (riskLevel >= 70) {
            return 'block';
        }
        if (riskLevel >= 50) {
            return 'warn';
        }
        if (riskLevel >= 30) {
            return 'monitor';
        }

        return 'allow';
    }

    /**
     * 威胁隔离
     */
    async quarantine(threat) {
        const quarantinePath = path.join(this.dataPath, 'quarantine');
        if (!fs.existsSync(quarantinePath)) {
            fs.mkdirSync(quarantinePath, { recursive: true });
        }

        const quarantineEntry = {
            id: crypto.randomUUID(),
            originalPath: threat.path,
            quarantinedAt: new Date().toISOString(),
            threatInfo: threat,
            status: 'quarantined'
        };

        const quarantineFile = path.join(quarantinePath, `${quarantineEntry.id}.json`);
        fs.writeFileSync(quarantineFile, JSON.stringify(quarantineEntry, null, 2));

        this.stats.autoBlocks++;
        await this.forensics.logEvent('THREAT_QUARANTINED', quarantineEntry);

        return quarantineEntry;
    }

    /**
     * 获取防御状态
     */
    getStatus() {
        return {
            ...this.status,
            stats: this.stats,
            modules: {
                fingerprint: this.fingerprint.getStats(),
                behavior: this.behavior.getStats(),
                heuristic: this.heuristic.getStats(),
                responder: this.responder.getStats(),
                threatIntel: this.threatIntel.getStats(),
                forensics: this.forensics.getStats()
            }
        };
    }

    /**
     * 更新威胁情报
     */
    async updateThreatIntel() {
        return await this.threatIntel.sync();
    }

    /**
     * 获取取证报告
     */
    async getForensicsReport(filter = {}) {
        return await this.forensics.generateReport(filter);
    }
}

module.exports = DefenseEngine;
