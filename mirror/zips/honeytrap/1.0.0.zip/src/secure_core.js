/**
 * HoneyTrap Secure Core - 安全加固版本
 * v3.0
 * 
 * Security Features:
 * - Path traversal prevention
 * - SSRF protection
 * - Memory limits
 * - ReDoS prevention
 * - Honeypot isolation
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ============================================================
// 安全配置
// ============================================================

const SECURITY_CONFIG = {
    MAX_CONTENT_LENGTH: 100000,        // 最大内容长度
    MAX_HISTORY_SIZE: 10000,          // 最大历史记录
    MAX_DELAY_MS: 5000,               // 最大延迟时间
    HONEYPOT_PREFIX: '.honeytrap/',   // 蜜罐目录前缀
    SAFE_PATTERNS: [                  // 安全的Webhook URL模式
        /^https:\/\/hooks\.slack\.com\//,
        /^https:\/\/oapi\.dingtalk\.com\//,
        /^https:\/\/qyapi\.weixin\.qq\.com\//
    ]
};

// ============================================================
// 安全工具函数
// ============================================================

class SecurityUtils {
    
    // 路径验证 - 防止目录遍历
    static validatePath(targetPath, baseDir = '.') {
        if (!targetPath || typeof targetPath !== 'string') {
            return path.join(baseDir, SECURITY_CONFIG.HONEYPOT_PREFIX);
        }
        
        // 规范化路径
        const normalized = path.normalize(targetPath);
        
        // 阻止绝对路径和上级目录遍历
        if (path.isAbsolute(normalized) || normalized.includes('..')) {
            console.warn('[Security] Blocked path traversal attempt:', targetPath);
            return path.join(baseDir, SECURITY_CONFIG.HONEYPOT_PREFIX);
        }
        
        // 确保在蜜罐目录内
        const fullPath = path.join(baseDir, SECURITY_CONFIG.HONEYPOT_PREFIX, normalized);
        return fullPath;
    }
    
    // URL验证 - 防止SSRF
    static validateWebhookUrl(url) {
        if (!url || typeof url !== 'string') {
            return false;
        }
        
        try {
            const parsed = new URL(url);
            
            // 仅允许HTTPS
            if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
                return false;
            }
            
            // 检查是否在白名单中
            for (const pattern of SECURITY_CONFIG.SAFE_PATTERNS) {
                if (pattern.test(url)) {
                    return true;
                }
            }
            
            // 默认拒绝不认识的URL
            console.warn('[Security] Webhook URL not in whitelist:', url);
            return false;
        } catch (e) {
            return false;
        }
    }
    
    // 内容长度限制 - 防止ReDoS
    static sanitizeContent(content, maxLength = SECURITY_CONFIG.MAX_CONTENT_LENGTH) {
        if (!content || typeof content !== 'string') {
            return '';
        }
        
        // 限制长度
        if (content.length > maxLength) {
            return content.slice(0, maxLength) + '...[TRUNCATED]';
        }
        
        // 移除控制字符
        return content.replace(/[\x00-\x1F\x7F]/g, '');
    }
    
    // 生成安全的假数据
    static generateFakeData(type, length = 32) {
        const prefix = {
            'aws_access_key': 'AKIA',
            'aws_secret_key': crypto.randomBytes(20).toString('base64'),
            'api_key': 'sk_live_' + crypto.randomBytes(16).toString('hex'),
            'jwt_secret': crypto.randomBytes(32).toString('hex'),
            'db_password': crypto.randomBytes(12).toString('base64'),
            'ssh_key': '-----BEGIN RSA PRIVATE KEY-----\n' + 
                       crypto.randomBytes(756).toString('base64').slice(0, 760) + '\n' +
                       '-----END RSA PRIVATE KEY-----'
        };
        
        if (prefix[type]) {
            return prefix[type];
        }
        
        return crypto.randomBytes(length).toString('hex');
    }
}

// ============================================================
// 蜜罐生成器 (安全版)
// ============================================================

class SecureHoneypotGenerator {
    constructor(config = {}) {
        this.config = {
            ...SECURITY_CONFIG,
            ...config
        };
        this.created = [];
    }
    
    // 生成凭证诱饵
    generateCredentialBait() {
        return {
            type: 'credential',
            files: [
                {
                    name: 'credentials.json',
                    content: JSON.stringify({
                        aws_access_key_id: SecurityUtils.generateFakeData('aws_access_key'),
                        aws_secret_access_key: SecurityUtils.generateFakeData('aws_secret_key'),
                        region: 'us-east-1'
                    }, null, 2)
                },
                {
                    name: '.env',
                    content: `DATABASE_URL=postgresql://fake:${SecurityUtils.generateFakeData('db_password')}@db.internal:5432/prod
API_KEY=${SecurityUtils.generateFakeData('api_key')}
JWT_SECRET=${SecurityUtils.generateFakeData('jwt_secret')}
AWS_ACCESS_KEY_ID=${SecurityUtils.generateFakeData('aws_access_key')}
AWS_SECRET_ACCESS_KEY=${SecurityUtils.generateFakeData('aws_secret_key')}`
                }
            ]
        };
    }
    
    // 创建蜜罐文件 (安全)
    createHoneypot(targetDir = '.') {
        const validatedDir = SecurityUtils.validatePath(targetDir);
        const bait = this.generateCredentialBait();
        const created = [];
        
        for (const file of bait.files) {
            const filePath = path.join(validatedDir, file.name);
            
            try {
                // 确保目录存在
                const dir = path.dirname(filePath);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
                
                fs.writeFileSync(filePath, file.content);
                created.push({
                    path: filePath,
                    type: 'honeypot',
                    authenticity_score: 0.85
                });
            } catch (e) {
                console.error('[Error] Failed to create honeypot:', e.message);
            }
        }
        
        this.created.push(...created);
        return created;
    }
}

// ============================================================
// 时间陷阱 (安全版)
// ============================================================

class SecureTimeTrap {
    constructor(config = {}) {
        this.config = {
            min_delay_ms: 100,
            max_delay_ms: Math.min(config.max_delay_ms || 3000, SECURITY_CONFIG.MAX_DELAY_MS),
            jitter: true
        };
        this.total_wasted_ms = 0;
    }
    
    calculateDelay() {
        let delay = Math.random() * (this.config.max_delay_ms - this.config.min_delay_ms) 
                    + this.config.min_delay_ms;
        
        // 高斯抖动
        if (this.config.jitter) {
            delay += (Math.random() + Math.random() + Math.random() - 1.5) * 500;
        }
        
        // 强制上限
        delay = Math.min(delay, SECURITY_CONFIG.MAX_DELAY_MS);
        delay = Math.max(0, delay);
        
        return Math.round(delay);
    }
    
    async execute() {
        const delay = this.calculateDelay();
        this.total_wasted_ms += delay;
        await new Promise(resolve => setTimeout(resolve, delay));
        return delay;
    }
    
    getStats() {
        return {
            total_sessions: this.created?.length || 0,
            total_time_wasted_ms: this.total_wasted_ms
        };
    }
}

// ============================================================
// 主防御引擎 (安全版)
// ============================================================

class SecureHoneyTrap {
    constructor(config = {}) {
        this.config = config;
        this.history = [];
        this.honeypot = new SecureHoneypotGenerator(config);
        this.timeTrap = new SecureTimeTrap(config);
    }
    
    // 添加历史记录 (带内存限制)
    addHistory(entry) {
        this.history.push({
            ...entry,
            timestamp: new Date().toISOString()
        });
        
        // 内存限制
        if (this.history.length > SECURITY_CONFIG.MAX_HISTORY_SIZE) {
            this.history = this.history.slice(-SECURITY_CONFIG.MAX_HISTORY_SIZE);
        }
    }
    
    // 处理攻击 (安全)
    async processAttack(agentInfo, request) {
        const startTime = Date.now();
        const result = {
            fingerprint: this.analyzeFingerprint(agentInfo, request),
            strategy: this.selectStrategy(request),
            actions: [],
            execution_time_ms: 0
        };
        
        // 执行策略
        switch (result.strategy) {
            case 'honeypot':
                const honeypots = this.honeypot.createHoneypot(request.targetDir);
                result.actions.push({ type: 'honeypot', created: honeypots });
                break;
                
            case 'time_trap':
                const delay = await this.timeTrap.execute();
                result.actions.push({ type: 'time_trap', delay_ms: delay });
                break;
                
            case 'deny':
                result.actions.push({ type: 'denied' });
                break;
                
            default:
                result.actions.push({ type: 'fake_data' });
        }
        
        result.execution_time_ms = Date.now() - startTime;
        this.addHistory(result);
        
        return result;
    }
    
    // 分析攻击者指纹
    analyzeFingerprint(agentInfo, request) {
        return {
            agent_id: SecurityUtils.sanitizeContent(agentInfo?.id || 'unknown'),
            threat_score: this.calculateThreatScore(request),
            timestamp: new Date().toISOString()
        };
    }
    
    // 计算威胁评分
    calculateThreatScore(request) {
        const highRisk = ['credential', 'env', 'secret', 'key', 'password', 'api_key'];
        const type = (request?.type || '').toLowerCase();
        
        if (highRisk.some(risk => type.includes(risk))) {
            return 80; // 高危
        }
        
        return 30; // 默认低风险
    }
    
    // 选择策略
    selectStrategy(request) {
        const score = this.calculateThreatScore(request);
        
        if (score >= 80) return 'honeypot';
        if (score >= 50) return 'time_trap';
        if (score >= 30) return 'fake_data';
        return 'allow';
    }
    
    // 获取报告
    getReport() {
        return {
            version: '3.0',
            total_attacks: this.history.length,
            honeypots_created: this.honeypot.created.length,
            time_wasted_ms: this.timeTrap.total_wasted_ms,
            memory_usage: `${this.history.length}/${SECURITY_CONFIG.MAX_HISTORY_SIZE}`
        };
    }
}

module.exports = {
    SecureHoneyTrap,
    SecureHoneypotGenerator,
    SecureTimeTrap,
    SecurityUtils,
    SECURITY_CONFIG
};
