# voice-process-helper

OpenClaw 语音服务配置助手 Skill，引导用户完成 TTS（语音回复）和 ASR（语音识别）的配置。

## 工作流程

```
用户发送语音相关消息
        │
        ├── 发送了语音/音频附件 ──────────► ASR 流程
        │                                    │
        └── 要求语音回复 ─────────────────► TTS 流程
                                             │
                                    ┌────────┴────────┐
                                    ▼                  ▼
                              已配置？              已配置？
                              │    │               │    │
                             是    否              是    否
                              │    │               │    │
                              ▼    ▼               ▼    ▼
                           直接使用  展示方案      直接使用  展示方案
                                    │                       │
                                    ▼                       ▼
                              用户选择方案            用户选择方案
                                    │                       │
                                    ▼                       ▼
                              执行安装脚本            执行安装脚本
                                    │                       │
                                    └───────┬───────────────┘
                                            ▼
                                    重启 Gateway（一次）
                                            │
                                            ▼
                                        服务就绪
```

### TTS 流程

1. 运行 `check-tts.sh` 检测就绪状态（config + 二进制 + 插件 + plugins.allow）
2. 未就绪 → 展示方案让用户选择：
   - **A1**：edge-tts-universal，智能语音回复（AI 决定哪些用语音，`tagged` 模式）
   - **A2**：edge-tts-universal，所有消息语音回复（`always` 模式）
   - **B**：腾讯云 TTS（付费）
3. 用户选择后执行 `install-tts.sh tagged|always`
4. 重启 Gateway 生效

### ASR 流程

1. 运行 `check-asr.sh` 检测就绪状态（config + whisper 二进制 + CLI entry）
2. 未就绪 → 探测机器资源，展示方案：
   - **A**：Whisper 本地识别（免费，CPU 优化版约 400MB，5~10 分钟）
   - **B**：腾讯云 ASR（付费）
3. 用户选择后执行 `install-asr.sh tiny|base`
4. 重启 Gateway 生效

## 文件结构

```
voice-process-helper/
├── SKILL.md                          ← Skill 主文件（Agent 读取的指令）
├── README.md                         ← 本文件（中文）
├── README_EN.md                      ← English README
└── scripts/
    ├── check-tts.sh                  ← TTS 就绪检测（~0.03s）
    ├── check-asr.sh                  ← ASR 就绪检测（~0.03s）
    ├── install-tts.sh                ← TTS 一键安装（参数: tagged|always）
    ├── install-asr.sh                ← ASR 一键安装（参数: tiny|base）
    ├── restart-gateway.sh            ← 重启 Gateway
    └── edge-tts-universal/
        ├── index.js                  ← TTS 插件代码（ESM）
        └── openclaw.plugin.json      ← TTS 插件清单
```

## 安装脚本

| 脚本 | 参数 | 作用 | 耗时 |
|------|------|------|------|
| `check-tts.sh` | 无 | 检测 TTS 就绪状态，返回 JSON | ~0.03 秒 |
| `check-asr.sh` | 无 | 检测 ASR 就绪状态，返回 JSON | ~0.03 秒 |
| `install-tts.sh` | `tagged` / `always` | 安装 edge-tts + ffmpeg + 部署插件 + 写配置 | ~15 秒 |
| `install-asr.sh` | `tiny` / `base` | 安装 CPU-only PyTorch + whisper + 写配置 | ~5-10 分钟 |
| `restart-gateway.sh` | 无 | pkill 旧进程 + 启动新 Gateway | ~70 秒就绪 |

设计原则：安装脚本只做安装和写配置，**不触发重启**。全部安装完成后调用 `restart-gateway.sh` 统一重启一次。

## 安装方式

将 zip 解压到 OpenClaw skills 目录：

```bash
cd /root/.openclaw/workspace/skills
unzip voice-process-helper.zip
chmod +x voice-process-helper/scripts/*.sh
```

重启 Gateway 后，发送语音消息或要求语音回复即可触发 skill。
