# voice-process-helper

OpenClaw voice service configuration skill. Guides users through setting up TTS (text-to-speech) and ASR (speech recognition).

## Workflow

```
User sends voice-related message
        │
        ├── Sends voice/audio attachment ────► ASR flow
        │                                       │
        └── Requests voice reply ────────────► TTS flow
                                                │
                                       ┌────────┴────────┐
                                       ▼                  ▼
                                 Configured?         Configured?
                                 │       │           │       │
                                Yes      No         Yes      No
                                 │       │           │       │
                                 ▼       ▼           ▼       ▼
                              Use it  Show options  Use it  Show options
                                        │                    │
                                        ▼                    ▼
                                  User selects          User selects
                                        │                    │
                                        ▼                    ▼
                                  Run install script   Run install script
                                        │                    │
                                        └───────┬────────────┘
                                                ▼
                                      Restart Gateway (once)
                                                │
                                                ▼
                                          Service ready
```

### TTS Flow

1. Run `check-tts.sh` to detect readiness (config + binaries + plugin + plugins.allow)
2. Not ready → present options:
   - **A1**: edge-tts-universal, smart voice reply (AI decides which replies need voice, `tagged` mode)
   - **A2**: edge-tts-universal, all messages as voice (`always` mode)
   - **B**: Tencent Cloud TTS (paid)
3. After user selects, run `install-tts.sh tagged|always`
4. Restart Gateway to apply

### ASR Flow

1. Run `check-asr.sh` to detect readiness (config + whisper binary + CLI entry)
2. Not ready → probe machine resources, present options:
   - **A**: Whisper local recognition (free, CPU-optimized ~400MB, 5~10 min)
   - **B**: Tencent Cloud ASR (paid)
3. After user selects, run `install-asr.sh tiny|base`
4. Restart Gateway to apply

## File Structure

```
voice-process-helper/
├── SKILL.md                          ← Skill file (read by the agent)
├── README.md                         ← Chinese README
├── README_EN.md                      ← This file (English)
└── scripts/
    ├── check-tts.sh                  ← TTS readiness check (~0.03s)
    ├── check-asr.sh                  ← ASR readiness check (~0.03s)
    ├── install-tts.sh                ← TTS one-click install (param: tagged|always)
    ├── install-asr.sh                ← ASR one-click install (param: tiny|base)
    ├── restart-gateway.sh            ← Restart Gateway
    └── edge-tts-universal/
        ├── index.js                  ← TTS plugin code (ESM)
        └── openclaw.plugin.json      ← TTS plugin manifest
```

## Scripts

| Script | Params | Purpose | Duration |
|--------|--------|---------|----------|
| `check-tts.sh` | none | Check TTS readiness, returns JSON | ~0.03s |
| `check-asr.sh` | none | Check ASR readiness, returns JSON | ~0.03s |
| `install-tts.sh` | `tagged` / `always` | Install edge-tts + ffmpeg + deploy plugin + write config | ~15s |
| `install-asr.sh` | `tiny` / `base` | Install CPU-only PyTorch + whisper + write config | ~5-10 min |
| `restart-gateway.sh` | none | pkill old process + start new Gateway | ~70s to ready |

Design principle: install scripts only install and write config — **no restart**. Call `restart-gateway.sh` once after all installations are complete.

## Installation

Extract the zip into the OpenClaw skills directory:

```bash
cd /root/.openclaw/workspace/skills
unzip voice-process-helper.zip
chmod +x voice-process-helper/scripts/*.sh
```

After restarting the Gateway, send a voice message or request a voice reply to trigger the skill.
