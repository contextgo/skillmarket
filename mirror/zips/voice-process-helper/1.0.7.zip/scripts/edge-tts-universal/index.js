/**
 * OpenClaw Plugin: edge-tts-universal
 *
 * 多通道自适应 TTS 插件，根据当前启用的 channel 决定输出音频格式：
 *
 *   feishu / telegram / whatsapp / matrix  →  OGG/Opus   (原生语音气泡)
 *   wecom                                  →  AMR        (企业微信仅支持 AMR)
 *   qqbot / slack / 其他                   →  MP3        (通用，各通道自行处理)
 *
 * 判断逻辑：
 *   1. req.target === "voice-note"（框架预算好）→ OGG（飞书等 OPUS_CHANNELS）
 *   2. req.target === "audio-file" 且 cfg 中 wecom.enabled → AMR
 *   3. 其他 → MP3
 *
 * 依赖：
 *   - edge-tts (Python):  pip3 install edge-tts --break-system-packages
 *   - ffmpeg:             apt install ffmpeg  /  brew install ffmpeg
 */

import { execSync, spawnSync } from "node:child_process";
import { readFileSync, rmSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { randomBytes } from "node:crypto";

const PROVIDER_ID  = "edge-tts-universal";
const DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural";
const DEFAULT_LANG  = "zh-CN";
// 框架只允许访问 /tmp/openclaw/ 下的媒体文件
const WORK_DIR = "/tmp/openclaw/edge-tts-universal";

// ---------------------------------------------------------------------------
// 工具函数
// ---------------------------------------------------------------------------

function cmdAvailable(cmd, args = ["--version"]) {
  try { execSync(`${cmd} ${args.join(" ")}`, { stdio: "pipe" }); return true; }
  catch { return false; }
}

// ffmpeg 用 -version（单横线），--version 会返回非零退出码
function isEdgeTtsAvailable() { return cmdAvailable("edge-tts"); }
function isFfmpegAvailable()  { return cmdAvailable("ffmpeg", ["-version"]); }

/**
 * 推断当前需要的目标格式。
 *
 * @param {"voice-note"|"audio-file"} target  - 框架根据 channel 类型预算的意图
 * @param {object} cfg                         - OpenClaw 完整配置（openclaw.json）
 * @returns {"ogg"|"amr"|"mp3"}
 */
function resolveTargetFormat(target, cfg) {
  // voice-note：飞书 / Telegram / WhatsApp / Matrix → OGG/Opus
  if (target === "voice-note") return "ogg";

  // audio-file：进一步区分 wecom 和其他
  // wecom 只接受 AMR，且不会自动转码（非 AMR 会降级为文件发送）
  const wecom = cfg?.channels?.wecom;
  if (wecom?.enabled === true) return "amr";

  // qqbot 有完整转码管线（任意格式 → SILK），mp3 最通用
  return "mp3";
}

// ---------------------------------------------------------------------------
// 文本清理
// ---------------------------------------------------------------------------

/**
 * Clean text for speech synthesis: remove emoji, special symbols, Markdown formatting,
 * URLs, and other content unsuitable for reading aloud.
 *
 * Note: OpenClaw framework has its own stripMarkdown in the TTS pipeline, but we
 * apply defensive cleaning here since plugin receives raw text in some code paths.
 *
 * @param {string} text
 * @returns {string}
 */
function sanitizeTextForSpeech(text) {
  return text
    // ── Emoji removal (Unicode property-based, covers all current & future emoji) ──
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/[\u{FE00}-\u{FE0F}]/gu, "")      // Variation Selectors
    .replace(/[\u{200D}]/gu, "")                  // Zero Width Joiner (emoji combiner)
    .replace(/[\u{20E3}]/gu, "")                  // Combining Enclosing Keycap
    .replace(/[\u{E0020}-\u{E007F}]/gu, "")      // Tag characters (flag sequences)

    // ── URL removal ──
    .replace(/https?:\/\/[^\s)]+/g, "")

    // ── Markdown formatting (defensive, framework may also strip) ──
    .replace(/```[\s\S]*?```/g, "")               // fenced code blocks (remove entirely)
    .replace(/`([^`]+)`/g, "$1")                  // inline `code` → keep content
    .replace(/\*{1,3}([^*]+)\*{1,3}/g, "$1")    // **bold**, *italic* → keep content
    .replace(/_{1,2}([^_]+)_{1,2}/g, "$1")       // __bold__, _italic_ → keep content
    .replace(/~~([^~]+)~~/g, "")                  // ~~strikethrough~~ → remove
    .replace(/^#{1,6}\s+/gm, "")                  // # headings → remove markers
    .replace(/^\s*>\s?/gm, "")                    // > blockquote → remove markers
    .replace(/^\s*[-*+]\s+/gm, "")                // - list items → remove bullets
    .replace(/^\s*\d+\.\s+/gm, "")                // 1. ordered list → remove numbers
    .replace(/^-{3,}$/gm, "")                     // --- horizontal rules → remove
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")     // [link](url) → keep text

    // ── Cleanup ──
    .replace(/\n{3,}/g, "\n\n")                   // collapse excessive newlines
    .replace(/[ \t]{2,}/g, " ")                    // collapse excessive spaces
    .trim();
}

// ---------------------------------------------------------------------------
// 各格式合成函数
// ---------------------------------------------------------------------------

/**
 * OGG/Opus：edge-tts → webm → ffmpeg → .ogg
 * 飞书 / Telegram / WhatsApp / Matrix
 */
async function synthesizeOgg({ voice, rate, pitch, volume, text, tempDir }) {
  const webmPath = join(tempDir, "speech.webm");
  const oggPath  = join(tempDir, "speech.ogg");

  if (!isFfmpegAvailable()) {
    throw new Error("ffmpeg not found; required for OGG output (feishu/telegram/whatsapp/matrix)");
  }

  const tts = spawnSync(
    "edge-tts",
    ["--voice", voice, "--text", text, "--rate", rate,
     "--pitch", pitch, "--volume", volume, "--write-media", webmPath],
    { encoding: "utf-8", timeout: 15000 }
  );
  if (tts.status !== 0) {
    throw new Error(`edge-tts failed: ${tts.stderr || tts.error?.message}`);
  }

  const ff = spawnSync(
    "ffmpeg",
    ["-y", "-i", webmPath, "-c:a", "libopus", "-b:a", "48k", oggPath],
    { encoding: "utf-8", timeout: 15000 }
  );
  if (ff.status !== 0) {
    throw new Error(`ffmpeg webm→ogg failed: ${ff.stderr || ff.error?.message}`);
  }

  const buf = readFileSync(oggPath);
  if (buf.length === 0) throw new Error("OGG output is empty");

  return { audioBuffer: buf, outputFormat: "ogg-opus", fileExtension: ".ogg", voiceCompatible: true };
}

/**
 * AMR：edge-tts → mp3 → ffmpeg → .amr (8kHz, mono, AMR-NB)
 * 企业微信仅支持 AMR 格式语音消息（最大 2 MB）
 */
async function synthesizeAmr({ voice, rate, pitch, volume, text, tempDir }) {
  const mp3Path = join(tempDir, "speech.mp3");
  const amrPath = join(tempDir, "speech.amr");

  if (!isFfmpegAvailable()) {
    throw new Error("ffmpeg not found; required for AMR output (wecom)");
  }

  const tts = spawnSync(
    "edge-tts",
    ["--voice", voice, "--text", text, "--rate", rate,
     "--pitch", pitch, "--volume", volume, "--write-media", mp3Path],
    { encoding: "utf-8", timeout: 15000 }
  );
  if (tts.status !== 0) {
    throw new Error(`edge-tts failed: ${tts.stderr || tts.error?.message}`);
  }

  // 企业微信要求：AMR-NB，8000Hz，mono，最大 2 MB
  const ff = spawnSync(
    "ffmpeg",
    ["-y", "-i", mp3Path, "-ar", "8000", "-ac", "1",
     "-c:a", "libopencore_amrnb", "-b:a", "12.2k", amrPath],
    { encoding: "utf-8", timeout: 15000 }
  );

  if (ff.status !== 0) {
    const stderr = ff.stderr || ff.error?.message || "";
    if (stderr.includes("libopencore_amrnb") || stderr.includes("Unknown encoder")) {
      throw new Error(
        "ffmpeg AMR encoder not available. Install with AMR support:\n" +
        "  Ubuntu: apt install ffmpeg  (通常已包含)\n" +
        "  或编译时加 --enable-libopencore-amrnb\n" +
        `原始错误: ${stderr.slice(0, 200)}`
      );
    }
    throw new Error(`ffmpeg mp3→amr failed: ${stderr.slice(0, 300)}`);
  }

  const buf = readFileSync(amrPath);
  if (buf.length === 0) throw new Error("AMR output is empty");

  return { audioBuffer: buf, outputFormat: "audio/amr", fileExtension: ".amr", voiceCompatible: true };
}

/**
 * MP3：edge-tts 直接输出，无需 ffmpeg
 * QQbot（自带 SILK 转码）/ Slack / 其他通道
 */
async function synthesizeMp3({ voice, rate, pitch, volume, text, tempDir }) {
  const mp3Path = join(tempDir, "speech.mp3");

  const tts = spawnSync(
    "edge-tts",
    ["--voice", voice, "--text", text, "--rate", rate,
     "--pitch", pitch, "--volume", volume, "--write-media", mp3Path],
    { encoding: "utf-8", timeout: 15000 }
  );
  if (tts.status !== 0) {
    throw new Error(`edge-tts failed: ${tts.stderr || tts.error?.message}`);
  }

  const buf = readFileSync(mp3Path);
  if (buf.length === 0) throw new Error("MP3 output is empty");

  return { audioBuffer: buf, outputFormat: "audio-24khz-48kbitrate-mono-mp3", fileExtension: ".mp3", voiceCompatible: true };
}

// ---------------------------------------------------------------------------
// Provider 构建
// ---------------------------------------------------------------------------

function buildProvider() {
  return {
    id: PROVIDER_ID,
    aliases: ["edge-tts-universal"],

    isConfigured: () => isEdgeTtsAvailable(),

    listVoices: async () => {
      try {
        const out = execSync("edge-tts --list-voices", { encoding: "utf-8", stdio: "pipe" });
        return out.split("\n")
          .filter(l => l.includes("Name:"))
          .map(l => {
            const name = l.match(/Name:\s*(\S+)/)?.[1] ?? "";
            return { id: name, name };
          });
      } catch {
        return [{ id: DEFAULT_VOICE, name: DEFAULT_VOICE }];
      }
    },

    synthesize: async (req) => {
      const cfg    = req.providerConfig ?? {};
      const voice  = cfg.voice  ?? DEFAULT_VOICE;
      const rate   = cfg.rate   ?? "+0%";
      const pitch  = cfg.pitch  ?? "+0Hz";
      const volume = cfg.volume ?? "+0%";

      const format  = resolveTargetFormat(req.target, req.cfg);
      // 使用固定工作目录而非 mkdtemp，确保路径在框架允许范围内
      if (!existsSync(WORK_DIR)) mkdirSync(WORK_DIR, { recursive: true });
      const id = randomBytes(6).toString("hex");
      const tempDir = join(WORK_DIR, id);
      mkdirSync(tempDir, { recursive: true });
      const cleanedText = sanitizeTextForSpeech(req.text);
      if (!cleanedText) {
        throw new Error("Text is empty after sanitization (all emoji/symbols?)");
      }
      const params  = { voice, rate, pitch, volume, text: cleanedText, tempDir };

      try {
        switch (format) {
          case "ogg": return await synthesizeOgg(params);
          case "amr": return await synthesizeAmr(params);
          case "mp3": return await synthesizeMp3(params);
          default:    return await synthesizeMp3(params);
        }
      } finally {
        rmSync(tempDir, { recursive: true, force: true });
      }
    },
  };
}

// ---------------------------------------------------------------------------
// 插件入口
// ---------------------------------------------------------------------------

export default function setup(api) {
  if (!isEdgeTtsAvailable()) {
    api.logger?.warn?.(
      "[edge-tts-universal] edge-tts not found, plugin disabled. " +
      "Run: pip3 install edge-tts --break-system-packages"
    );
    return;
  }
  api.registerSpeechProvider(buildProvider());
  api.logger?.info?.(
    "[edge-tts-universal] registered (ogg=feishu/telegram/whatsapp/matrix | amr=wecom | mp3=others)"
  );
}
