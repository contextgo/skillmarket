#!/usr/bin/env bash
# install-tts.sh — Install edge-tts-universal TTS service (does NOT restart Gateway)
# Usage: bash install-tts.sh <tagged|always>
set -e

TTS_AUTO="${1:?Usage: bash install-tts.sh <tagged|always>}"
if [[ "$TTS_AUTO" != "tagged" && "$TTS_AUTO" != "always" ]]; then
  echo "❌ Invalid argument: expected tagged or always, got: $TTS_AUTO" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_SRC="$SCRIPT_DIR/edge-tts-universal"
OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
PLUGIN_DST="$OPENCLAW_HOME/extensions/edge-tts-universal"
CONFIG="$OPENCLAW_HOME/openclaw.json"

echo "=== Install TTS (auto=$TTS_AUTO) ==="

# ── 1. Install dependencies ─────────────────────────────────

if command -v edge-tts &>/dev/null; then
  echo "✅ edge-tts already installed"
else
  echo "⏳ Installing edge-tts ..."
  pip3 install edge-tts --break-system-packages --no-cache-dir 2>&1 | tail -3
  command -v edge-tts &>/dev/null && echo "✅ edge-tts installed" || { echo "❌ edge-tts install failed" >&2; exit 1; }
fi

if command -v ffmpeg &>/dev/null; then
  echo "✅ ffmpeg already installed"
else
  echo "⏳ Installing ffmpeg ..."
  apt-get install -y ffmpeg 2>&1 | tail -3
  command -v ffmpeg &>/dev/null && echo "✅ ffmpeg installed" || { echo "❌ ffmpeg install failed" >&2; exit 1; }
fi

# ── 2. Deploy plugin files ──────────────────────────────────

if [[ ! -f "$PLUGIN_SRC/index.js" || ! -f "$PLUGIN_SRC/openclaw.plugin.json" ]]; then
  echo "❌ Plugin files not found: $PLUGIN_SRC/{index.js,openclaw.plugin.json}" >&2
  exit 1
fi

mkdir -p "$PLUGIN_DST"
cp "$PLUGIN_SRC/index.js" "$PLUGIN_DST/index.js"
cp "$PLUGIN_SRC/openclaw.plugin.json" "$PLUGIN_DST/openclaw.plugin.json"
echo "✅ Plugin deployed to $PLUGIN_DST"

# ── 3. Write config (direct JSON, no openclaw CLI) ──────────

python3 -c "
import json, shutil, sys
from datetime import datetime, timezone

config_path = '$CONFIG'
tts_auto = '$TTS_AUTO'

# Read
with open(config_path) as f:
    cfg = json.load(f)

# Backup
shutil.copy2(config_path, config_path + '.bak')

# Update plugins.allow
plugins = cfg.setdefault('plugins', {})
allow = plugins.get('allow', [])
if not isinstance(allow, list):
    allow = []
if 'edge-tts-universal' not in allow:
    allow.append('edge-tts-universal')
plugins['allow'] = allow

# Update TTS config
cfg.setdefault('messages', {})['tts'] = {
    'auto': tts_auto,
    'provider': 'edge-tts-universal',
    'providers': {
        'edge-tts-universal': {
            'voice': 'zh-CN-XiaoxiaoNeural',
            'lang': 'zh-CN',
        }
    }
}

# Stamp meta (same as openclaw config set)
cfg.setdefault('meta', {})['lastTouchedAt'] = datetime.now(timezone.utc).isoformat()

# Write
with open(config_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)

print(f'✅ plugins.allow: {json.dumps(allow)}')
print(f'✅ TTS config written (auto={tts_auto})')
"

echo ""
echo "=== TTS install complete ==="
echo "⚠️  Restart Gateway to apply changes"
