#!/usr/bin/env bash
# install-asr.sh — Install Whisper ASR (CPU-optimized, does NOT restart Gateway)
# Usage: bash install-asr.sh [tiny|base]
set -e

MODEL="${1:-base}"
if [[ "$MODEL" != "tiny" && "$MODEL" != "base" ]]; then
  echo "❌ Invalid argument: expected tiny or base, got: $MODEL" >&2
  exit 1
fi

OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
CONFIG="$OPENCLAW_HOME/openclaw.json"

echo "=== Install ASR (model=$MODEL) ==="

# ── 1. Install CPU-only PyTorch + openai-whisper ────────────

if command -v whisper &>/dev/null; then
  echo "✅ whisper already installed"
else
  echo "⏳ Installing CPU-only PyTorch (~200MB)..."
  pip3 install torch torchaudio --index-url https://download.pytorch.org/whl/cpu --break-system-packages --no-cache-dir 2>&1 | tail -5

  echo "⏳ Installing openai-whisper ..."
  pip3 install openai-whisper --break-system-packages --no-cache-dir 2>&1 | tail -5

  if command -v whisper &>/dev/null; then
    echo "✅ whisper installed"
  else
    echo "❌ whisper install failed" >&2
    exit 1
  fi
fi

# ── 2. Write config (direct JSON, no openclaw CLI) ──────────

python3 -c "
import json, shutil
from datetime import datetime, timezone

config_path = '$CONFIG'
model = '$MODEL'

# Read
with open(config_path) as f:
    cfg = json.load(f)

# Backup
shutil.copy2(config_path, config_path + '.bak')

# Update ASR config — use CLI entry with explicit model to avoid
# framework's hardcoded --model turbo (which downloads ~1.3GB)
tools = cfg.setdefault('tools', {})
media = tools.setdefault('media', {})
audio = media.setdefault('audio', {})
audio['enabled'] = True
audio['models'] = [{
    'type': 'cli',
    'command': 'whisper',
    'model': model,
    'args': [
        '--model', model,
        '--output_format', 'txt',
        '--output_dir', '{{OutputDir}}',
        '--verbose', 'False',
        '{{MediaPath}}'
    ]
}]

# Stamp meta
cfg.setdefault('meta', {})['lastTouchedAt'] = datetime.now(timezone.utc).isoformat()

# Write
with open(config_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)

print(f'✅ ASR config written (model={model})')
"

echo ""
echo "=== ASR install complete ==="
echo "⚠️  Restart Gateway to apply changes"
