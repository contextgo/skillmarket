#!/usr/bin/env bash
# check-tts.sh — Check TTS readiness (fast, reads config file directly)
# Exit code: 0 = ready, 1 = not configured, 2 = partially configured
# Output: JSON status report
set -e

OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
CONFIG="$OPENCLAW_HOME/openclaw.json"

python3 -c "
import json, shutil, os, sys

config_path = '$CONFIG'
openclaw_home = '$OPENCLAW_HOME'

try:
    with open(config_path) as f:
        cfg = json.load(f)
except:
    cfg = {}

tts = cfg.get('messages', {}).get('tts', {})
provider = tts.get('provider', '')
auto = tts.get('auto', '')

edge_tts = shutil.which('edge-tts') is not None
ffmpeg = shutil.which('ffmpeg') is not None
plugin = os.path.isfile(os.path.join(openclaw_home, 'extensions/edge-tts-universal/index.js'))

plugins_allow = cfg.get('plugins', {}).get('allow', [])
allow_ok = 'edge-tts-universal' in (plugins_allow if isinstance(plugins_allow, list) else [])

if provider:
    if edge_tts and ffmpeg and plugin and allow_ok:
        status, code = 'ready', 0
    else:
        status, code = 'partial', 2
else:
    status, code = 'not_configured', 1

print(json.dumps({
    'status': status,
    'provider': provider,
    'auto': auto,
    'edge_tts_installed': edge_tts,
    'ffmpeg_installed': ffmpeg,
    'plugin_deployed': plugin,
    'plugins_allow_ok': allow_ok,
}, indent=2))
sys.exit(code)
"
