#!/usr/bin/env bash
# check-asr.sh — Check ASR readiness (fast, reads config file directly)
# Exit code: 0 = ready, 1 = not configured, 2 = partially configured
# Output: JSON status report
set -e

OPENCLAW_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
CONFIG="$OPENCLAW_HOME/openclaw.json"

python3 -c "
import json, shutil, sys

config_path = '$CONFIG'

try:
    with open(config_path) as f:
        cfg = json.load(f)
except:
    cfg = {}

audio = cfg.get('tools', {}).get('media', {}).get('audio', {})
enabled = audio.get('enabled', False)
models = audio.get('models', [])
whisper = shutil.which('whisper') is not None

# Extract model info from CLI entry
model_name = ''
entry_type = ''
if isinstance(models, list) and len(models) > 0:
    entry = models[0]
    model_name = entry.get('model', '')
    entry_type = entry.get('type', 'provider')

# Ready = enabled + CLI entry with whisper binary
if enabled and whisper and model_name and entry_type == 'cli':
    status, code = 'ready', 0
elif enabled or whisper:
    status, code = 'partial', 2
else:
    status, code = 'not_configured', 1

print(json.dumps({
    'status': status,
    'config_enabled': enabled,
    'config_model': model_name,
    'entry_type': entry_type,
    'whisper_installed': whisper,
}, indent=2))
sys.exit(code)
"
