#!/usr/bin/env bash
# restart-gateway.sh — 完整重启 Gateway 使配置生效
# 用法: bash restart-gateway.sh
set -e

echo "⏳ 正在重启 Gateway，大约需要 1 分钟…"

pkill -9 -f openclaw-gateway || true
sleep 2

# 确保 openclaw 可用
if ! command -v openclaw &>/dev/null; then
  for p in "$HOME/.local/share/pnpm" /root/.local/share/pnpm /usr/local/bin; do
    [[ -x "$p/openclaw" ]] && export PATH="$p:$PATH" && break
  done
  for p in "$HOME/.nvm/versions/node"/*/bin /root/.nvm/versions/node/*/bin; do
    [[ -d "$p" ]] && export PATH="$p:$PATH" && break
  done
fi
command -v openclaw &>/dev/null || { echo "❌ openclaw 未找到" >&2; exit 1; }

nohup openclaw gateway --bind loopback --force > /tmp/openclaw-gateway.log 2>&1 &

echo "✅ Gateway 已重启（约 70 秒后完全就绪）"
