"""NoticiasCangrejo scripts package."""
