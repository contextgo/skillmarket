# -*- coding: utf-8 -*-
import sys
import io
import time
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")


def get_latest_mtime(folder: Path) -> Optional[float]:
    latest = None
    try:
        for entry in folder.rglob("*"):
            try:
                if entry.is_file():
                    mtime = entry.stat().st_mtime
                    if latest is None or mtime > latest:
                        latest = mtime
            except (PermissionError, OSError):
                continue
    except (PermissionError, OSError):
        pass
    if latest is None:
        try:
            latest = folder.stat().st_mtime
        except (PermissionError, OSError):
            pass
    return latest


def format_age(mtime: float) -> str:
    now = time.time()
    delta = now - mtime
    if delta < 3600:
        return "%d 分钟前" % int(delta // 60)
    elif delta < 86400:
        return "%d 小时前" % int(delta // 3600)
    elif delta < 86400 * 30:
        return "%d 天前" % int(delta // 86400)
    elif delta < 86400 * 365:
        return "%d 个月前" % int(delta // (86400 * 30))
    else:
        return "%.1f 年前" % (delta / (86400 * 365))


_scan_counter = [0]


def build_tree(parent: Path, max_depth: int, threshold_ts: float,
               current_depth: int = 1) -> list:
    """返回 (is_dir, path, depth, mtime, is_stale) 节点列表"""
    nodes = []
    try:
        all_entries = sorted(parent.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except (PermissionError, OSError):
        return nodes

    for entry in all_entries:
        _scan_counter[0] += 1
        print("  正在扫描 (%d): ...%s" % (_scan_counter[0], str(entry)[-55:]),
              end="\r", flush=True)
        try:
            if entry.is_dir():
                mtime = get_latest_mtime(entry)
                if mtime is None:
                    continue
                nodes.append((True, entry, current_depth, mtime, mtime < threshold_ts))
                if current_depth < max_depth:
                    nodes.extend(build_tree(entry, max_depth, threshold_ts, current_depth + 1))
            elif entry.is_file():
                mtime = entry.stat().st_mtime
                nodes.append((False, entry, current_depth, mtime, mtime < threshold_ts))
        except (PermissionError, OSError):
            continue
    return nodes


def render_tree(nodes: list):
    name_width = 50
    print("  [状][类型]  %-*s  %-16s  %s" % (name_width, "名称（缩进=层级）", "最近修改时间", "距今"))
    print("  " + "-" * 78)
    for is_dir, path, depth, mtime, is_stale in nodes:
        indent = "  " * (depth - 1)
        display_name = path.name + ("/" if is_dir else "")
        full_name = (indent + display_name)[:name_width]
        dt = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
        age = format_age(mtime)
        tag = "废" if is_stale else "活"
        kind = "文件夹" if is_dir else "文件  "
        print("  [%s][%s] %-*s  %-16s  %s" % (tag, kind, name_width, full_name, dt, age))


def get_toplevel_stale_dirs(stale_dirs: list) -> list:
    """只保留最顶层的废弃文件夹（子文件夹不单独删，rmtree 会一起删）。"""
    stale_paths = [path for _, path, *_ in stale_dirs]
    stale_paths_sorted = sorted(stale_paths, key=lambda p: len(p.parts))

    top_level = []
    for path in stale_paths_sorted:
        # 如果没有任何祖先已经在 top_level 中，则加入
        if not any(path != tp and str(path).startswith(str(tp) + "\\") for tp in top_level):
            top_level.append(path)
    return top_level


def _recycle_one(path: Path) -> bool:
    """用 Windows SHFileOperationW 把单个路径移入回收站"""
    import ctypes
    import ctypes.wintypes as wt

    class SHFILEOPSTRUCT(ctypes.Structure):
        _fields_ = [
            ("hwnd",                  wt.HWND),
            ("wFunc",                 wt.UINT),
            ("pFrom",                 ctypes.c_wchar_p),
            ("pTo",                   ctypes.c_wchar_p),
            ("fFlags",                wt.WORD),
            ("fAnyOperationsAborted", wt.BOOL),
            ("hNameMappings",         ctypes.c_void_p),
            ("lpszProgressTitle",     ctypes.c_wchar_p),
        ]

    FO_DELETE          = 0x0003
    FOF_ALLOWUNDO      = 0x0040  # 放入回收站而非永久删除
    FOF_NOCONFIRMATION = 0x0010
    FOF_SILENT         = 0x0004
    FOF_NOERRORUI      = 0x0400

    # c_wchar_p + 末尾额外 \0 = 双空字符结尾（SHFileOperation 要求）
    op = SHFILEOPSTRUCT()
    op.wFunc  = FO_DELETE
    op.pFrom  = str(path.resolve()) + "\0"
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0


def _get_targets(stale_dirs: list, stale_files: list):
    """返回 (top_dirs, orphan_files) 两个列表，避免重复删除子项"""
    top_dirs = get_toplevel_stale_dirs(
        [(True, path, depth, mtime, stale) for _, path, depth, mtime, stale in stale_dirs]
    )
    top_dir_set = set(top_dirs)
    orphan_files = [
        path for _, path, _, _, _ in stale_files
        if not any(str(path).startswith(str(td) + "\\") or path.parent == td
                   for td in top_dir_set)
    ]
    return top_dirs, orphan_files


def do_delete(stale_dirs: list, stale_files: list, recycle: bool):
    """执行删除或移入回收站"""
    top_dirs, files_to_delete = _get_targets(stale_dirs, stale_files)
    verb = "移入回收站" if recycle else "删除"

    ok_files, fail_files = 0, []
    for f in files_to_delete:
        try:
            if recycle:
                if not _recycle_one(f):
                    raise OSError("SHFileOperation 返回非零")
            else:
                f.unlink()
            ok_files += 1
        except Exception as e:
            fail_files.append((f, str(e)))

    ok_dirs, fail_dirs = 0, []
    for d in top_dirs:
        try:
            if recycle:
                if not _recycle_one(d):
                    raise OSError("SHFileOperation 返回非零")
            else:
                shutil.rmtree(d)
            ok_dirs += 1
        except Exception as e:
            fail_dirs.append((d, str(e)))

    print("\n  %s完成：" % verb)
    print("    文件夹（含内容）成功: %d 个" % ok_dirs)
    print("    独立文件      成功: %d 个" % ok_files)
    if fail_dirs:
        print("    文件夹失败: %d 个" % len(fail_dirs))
        for d, e in fail_dirs:
            print("      %s  -> %s" % (d, e))
    if fail_files:
        print("    文件失败: %d 个" % len(fail_files))
        for f, e in fail_files[:10]:
            print("      %s  -> %s" % (f, e))
        if len(fail_files) > 10:
            print("      ...（共 %d 个失败）" % len(fail_files))


def analyze_directory(target_dir: str, threshold_days: int = 90, max_depth: int = 3):
    global _scan_counter
    _scan_counter = [0]

    target = Path(target_dir)
    if not target.exists():
        print("错误：目录不存在 %s" % target_dir)
        return

    threshold_ts = time.time() - threshold_days * 86400
    threshold_date = datetime.fromtimestamp(threshold_ts).strftime("%Y-%m-%d")

    print("\n" + "=" * 78)
    print("  文件夹 & 文件使用时间分析（最大深度 %d 层）" % max_depth)
    print("  扫描目录: %s" % target_dir)
    print("  废弃阈值: %d 天（%s 之前未修改视为废弃）" % (threshold_days, threshold_date))
    print("=" * 78 + "\n")

    nodes = build_tree(target, max_depth, threshold_ts)
    print(" " * 78, end="\r")

    if not nodes:
        print("  未找到任何内容。\n")
        return

    stale_nodes  = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in nodes if s]
    active_nodes = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in nodes if not s]
    stale_dirs   = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in stale_nodes if is_dir]
    stale_files  = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in stale_nodes if not is_dir]
    active_dirs  = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in active_nodes if is_dir]
    active_files = [(is_dir, p, d, m, s) for is_dir, p, d, m, s in active_nodes if not is_dir]

    # ── 完整树形视图 ──────────────────────────────────────────────────────────
    print("[ 完整树形视图 ]  [废]=超过阈值  [活]=近期有修改\n")
    render_tree(nodes)

    # ── 汇总 ──────────────────────────────────────────────────────────────────
    print("\n" + "=" * 78)
    print("  文件夹: 共 %d 个  |  可能废弃: %d  |  近期使用: %d" % (
        len(stale_dirs) + len(active_dirs), len(stale_dirs), len(active_dirs)))
    print("  文  件: 共 %d 个  |  可能废弃: %d  |  近期使用: %d" % (
        len(stale_files) + len(active_files), len(stale_files), len(active_files)))
    print("=" * 78 + "\n")

    # ── 交互删除 ──────────────────────────────────────────────────────────────
    if not stale_nodes:
        print("  没有废弃内容，无需删除。\n")
        return

    top_dirs = get_toplevel_stale_dirs(
        [(True, p, d, m, s) for _, p, d, m, s in stale_dirs]
    )
    top_dir_set = set(top_dirs)
    orphan_files = [p for _, p, *_ in stale_files
                    if not any(str(p).startswith(str(td) + "\\") or p.parent == td
                               for td in top_dir_set)]

    print("[ 待删除预览 ]\n")
    if top_dirs:
        print("  以下文件夹将被完整删除（含其中所有内容）：")
        for d in sorted(top_dirs, key=lambda p: str(p)):
            print("    %s" % d)
    if orphan_files:
        print("  以下独立文件将被删除：")
        for f in orphan_files[:20]:
            print("    %s" % f)
        if len(orphan_files) > 20:
            print("    ...（共 %d 个文件）" % len(orphan_files))

    total_dirs  = len(top_dirs)
    total_files = len(orphan_files)
    print("\n  共涉及: %d 个文件夹（含内容），%d 个独立文件" % (total_dirs, total_files))

    try:
        print("\n  请选择操作：")
        print("    r   → 移到回收站（可从回收站恢复）")
        print("    yes → 永久删除（⚠️  不可恢复）")
        print("    其他 → 取消")
        answer = input("\n  请输入: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\n  已取消。")
        return

    if answer == "r":
        do_delete(stale_dirs, stale_files, recycle=True)
    elif answer == "yes":
        do_delete(stale_dirs, stale_files, recycle=False)
    else:
        print("\n  已取消，未删除任何内容。\n")


if __name__ == "__main__":
    dirs = []
    max_depth = 3
    threshold = 90  # 默认 90 天（3个月），可用 --days=30 改为1个月
    for arg in sys.argv[1:]:
        if arg.startswith("--depth="):
            max_depth = int(arg.split("=")[1])
        elif arg.startswith("--days="):
            threshold = int(arg.split("=")[1])
        else:
            dirs.append(arg)
    if not dirs:
        dirs = [r"F:\Program Files"]
    for d in dirs:
        analyze_directory(d, threshold_days=threshold, max_depth=max_depth)
