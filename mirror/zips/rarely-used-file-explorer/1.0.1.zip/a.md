# 扫描 C:\Program Files
python folder_usage_analyzer.py "C:\Program Files (x86)\Microsoft Visual Studio\2019"
python folder_usage_analyzer.py "F:\Program Files"



# 同时扫描多个目录
python folder_usage_analyzer.py "C:\Program Files" "D:\软件"

# 修改阈值为1年（365天）
# 编辑脚本最后一行 threshold = 365


# 默认 3个月阈值
python folder_usage_analyzer.py "F:\Program Files"

# 改为 1个月
python folder_usage_analyzer.py "F:\Program Files" --days=30

# 改为 2个月
python folder_usage_analyzer.py "F:\Program Files" --days=60

