---
name: folder-usage-analyzer
description: 扫描指定目录，按最近修改时间识别「废弃」文件和文件夹（默认超过 90 天未修改视为废弃），以树形视图展示每个节点的活跃/废弃状态，并可选择将废弃项移入回收站或永久删除。适用于清理磁盘空间、整理 Program Files、Downloads、旧项目目录、寻找长时间未使用的软件或文件、回收站清理、磁盘瘦身等场景。仅支持 Windows。关键词：废弃文件、旧文件、磁盘清理、文件夹分析、使用时间、最近修改、stale files、disk cleanup、find old folders、unused software。
---

# Folder Usage Analyzer

扫描目录树，识别长时间未修改的「废弃」文件/文件夹并可选删除。底层是 [folder_usage_analyzer.py](../../../folder_usage_analyzer.py)。

## 何时使用此 Skill

用户想要做以下任一事情时触发：

- 清理磁盘空间 / 磁盘瘦身 / 找出占空间的旧软件
- 分析某个目录（Program Files、Downloads、D 盘、旧项目目录等）哪些东西长期没动
- 识别并删除废弃的文件夹或文件
- 想要按「最近修改时间」查看某目录下的所有内容
- 想要把旧文件批量移入回收站

## 参数

- **目录路径**（必需，可多个，空格分隔）
- `--days=N`：废弃阈值天数，超过 N 天未修改视为废弃（默认 `90`）
- `--depth=N`：最大扫描层级（默认 `3`）

## 执行步骤

1. **确认目标目录**：若用户未明示目录，先询问扫描哪个路径；若有多个候选（例如"清理 C 盘和 D 盘"），逐一列出并确认
2. **构造命令**：使用 Bash 工具运行以下命令，脚本路径固定为项目根下的 `folder_usage_analyzer.py`

   ```bash
   python "f:/@Haiwen/海文娜/使用日志探索/folder_usage_analyzer.py" "<目录1>" ["<目录2>" ...] [--days=N] [--depth=N]
   ```

3. **注意非交互环境**：脚本末尾会用 `input()` 等待 `r` / `yes` / 其他 三选一。在 Claude Code 的 Bash 工具里 stdin 默认关闭，会直接抛 `EOFError` 被脚本捕获后取消。有两种处理方式：

   - **预览模式（推荐默认）**：直接运行命令，让它走到 `EOFError` 分支（输出"已取消"），把扫描结果完整展示给用户，然后**询问用户**是要 `r`（回收站）还是 `yes`（永久删除）还是放弃
   - **直接执行模式**：用户已明确表示要删除时，通过 `echo r | python ...` 或 `echo yes | python ...` 把答案从 stdin 喂进去

4. **展示结果**：把脚本 stdout 完整转给用户，重点标出：
   - 废弃文件夹/文件数量
   - 「待删除预览」中将被完整删除的顶层目录列表
   - 任何权限错误或失败项

## 安全默认

- **默认使用回收站（`r`）而不是永久删除（`yes`）**，除非用户明确说"永久删除"、"彻底删除"、"不要回收站"
- **目标是系统关键目录时警告**：扫描 `C:\Windows`、`C:\Program Files\Common Files` 等路径前提醒用户风险
- **显示将被删除的顶层目录列表**后，再要求用户二次确认才执行删除

## 示例调用

```bash
# 默认 90 天阈值扫描 Program Files
python folder_usage_analyzer.py "F:\Program Files"

# 1 个月阈值
python folder_usage_analyzer.py "C:\Users\haiwen\Downloads" --days=30

# 多目录 + 深度 4
python folder_usage_analyzer.py "D:\Projects" "E:\backup" --days=180 --depth=4

# 非交互直接移入回收站
echo r | python folder_usage_analyzer.py "F:\Program Files" --days=365
```

## 输出说明

脚本输出包含三段：

1. **完整树形视图**：每行标记 `[废]`（超阈值）或 `[活]`（近期有修改），含最近修改时间和距今时长
2. **汇总**：文件夹/文件各自的总数、废弃数、活跃数
3. **待删除预览 + 交互提示**：列出顶层将被删除的文件夹和独立文件，等待 `r` / `yes` / 其他

## 限制

- **仅 Windows**：回收站功能依赖 `ctypes.windll.shell32.SHFileOperationW`
- **需要 Python 3.x**
- 扫描大目录（几十 GB / 数百万文件）可能耗时数分钟，属正常现象
- 遇到无权限访问的目录会静默跳过
