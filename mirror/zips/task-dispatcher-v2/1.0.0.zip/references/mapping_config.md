# 任务关键词与处置人映射配置

## 映射规则说明

本文件定义了任务内容与处置人之间的匹配规则。智能体将根据任务描述中的关键词自动匹配对应的处置人。

## 映射表格式

```yaml
mappings:
  - keywords: ["关键词1", "关键词2"]
    assignee: "处置人姓名或飞书用户ID"
    description: "匹配规则说明"
    priority: "优先级 (P0/P1/P2/P3)"
  
  - keywords: ["关键词3"]
    assignee: "处置人"
    description: "说明"
    priority: "P1"
```

## 示例映射表（请根据实际业务修改）

```yaml
mappings:
  # 安全合规类任务
  - keywords: ["安全", "合规", "数据保护", "隐私", "审计", "风险"]
    assignee: "安全合规部-张三"
    description: "安全合规相关任务"
    priority: "P0"
  
  # 技术开发类任务
  - keywords: ["开发", "代码", "系统", "服务器", "数据库", "API", "接口", "技术方案"]
    assignee: "技术部-李四"
    description: "技术开发相关任务"
    priority: "P1"
  
  # 运维类任务
  - keywords: ["运维", "部署", "发布", "故障", "监控", "磁盘", "内存", "CPU"]
    assignee: "运维部-王五"
    description: "系统运维相关任务"
    priority: "P0"
  
  # 产品类任务
  - keywords: ["产品", "需求", "功能", "用户体验", "UI", "设计", "评审"]
    assignee: "产品部-赵六"
    description: "产品需求相关任务"
    priority: "P1"
  
  # 客户支持类任务
  - keywords: ["客户", "投诉", "反馈", "售后", "咨询", "问题"]
    assignee: "客服部-孙七"
    description: "客户支持相关任务"
    priority: "P2"
  
  # 行政人事类任务
  - keywords: ["会议", "备忘", "纪要", "行政", "人事", "招聘", "培训"]
    assignee: "行政人事部-周八"
    description: "行政人事相关任务"
    priority: "P2"
  
  # 财务类任务
  - keywords: ["预算", "报销", "财务", "发票", "合同", "采购"]
    assignee: "财务部-吴九"
    description: "财务相关任务"
    priority: "P2"

# 默认处置人（当没有匹配到关键词时使用）
default_assignee: "待分配"
```

## 使用说明

1. 修改上述映射表中的 `assignee` 为实际的飞书用户姓名或用户ID
2. 可以根据业务需要添加更多的关键词和处置人映射
3. 支持多个关键词映射到同一个处置人
4. 优先级用于设置飞书任务的紧急程度
