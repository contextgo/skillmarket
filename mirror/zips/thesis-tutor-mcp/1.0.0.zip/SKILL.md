---
name: thesis-tutor-mcp
description: |
  论文写作全流程AI导师 MCP 服务器。

  触发场景：需要论文选题/大纲/批注/自检/答辩问题时，调用此 MCP 工具。

  提供9个 MCP Tool：
  1. get_topic_suggestions — 根据专业+兴趣推荐题目
  2. generate_outline — 生成完整论文大纲
  3. review_chapter — 章节内容批注
  4. interpret_feedback — 解读导师反馈
  5. run_checklist — 交稿前终极检查
  6. simulate_defense — 答辩模拟+问题预测
  7. list_references — 参考文献索引
  8. get_reference — 读取参考文献
  9. get_skill_info — 获取技能元信息

  七阶段流程：选题诊断→开题报告→大纲构建→逐章辅导→自检清单→导出docx→答辩准备

  核心约束：不代写，只引导；最终以学校和导师要求为准。
metadata:
  author: 一梦繁星
  version: "1.0.0"
  created: "2026-04-21"
  tags: [thesis, academic-writing, mcp, tutor]
---

# thesis-tutor MCP

## 概述

将 thesis-tutor 技能封装为 MCP 服务器，供其他 AI Agent 通过 MCP 协议调用。

## 架构

```
AI Agent (MCP Client)
        ↓ MCP Protocol
thesis-tutor-mcp/server.py (FastMCP)
        ↓
7 Tools (Python Logic)
        ↓
references/*.md (静态文献库)
```

## 工具清单

| Tool | 用途 | 典型场景 |
|------|------|----------|
| `get_topic_suggestions` | 选题推荐 | "帮我推荐几个论文题目" |
| `generate_outline` | 大纲生成 | "帮我搭一个论文大纲" |
| `review_chapter` | 内容批注 | "帮我看看这段写得怎么样" |
| `interpret_feedback` | 解读导师反馈 | "导师说论证不充分" |
| `run_checklist` | 交稿前检查 | "帮我过一遍自检清单" |
| `simulate_defense` | 答辩模拟 | "帮我模拟答辩" |
| `list_references` | 参考文献索引 | 查询可用文献 |
| `get_reference` | 读取参考文献 | 获取某专项的详细内容 |
| `get_skill_info` | 技能元信息 | 查看版本、作者等 |

## 安装与运行

### 前置依赖

```bash
pip install fastmcp
```

### 运行方式

**开发调试模式：**
```bash
cd D:\Skill Encyclopedia\thesis-tutor-mcp
fastmcp dev server.py
```

**生产模式：**
```bash
fastmcp run server.py
```

### 注册到 OpenClaw MCP

在 OpenClaw 配置中添加：

```json
{
  "mcpServers": {
    "thesis-tutor": {
      "command": "fastmcp",
      "args": ["run", "D:/Skill Encyclopedia/thesis-tutor-mcp/server.py"]
    }
  }
}
```

## 使用示例

### 示例1：选题推荐

**MCP 调用：**
```json
{
  "tool": "get_topic_suggestions",
  "args": {
    "major": "市场营销",
    "grade": "本科",
    "interests": "直播带货",
    "require_data": false
  }
}
```

**返回：**
```json
{
  "status": "success",
  "suggestions": [
    {"rank": 1, "title": "消费者在直播间的购买意愿影响因素研究——以XXX为例", "difficulty": "中", "data_needed": "可选"},
    ...
  ],
  "next_step": "选题后，进入阶段2或阶段3"
}
```

### 示例2：自检清单

**MCP 调用：**
```json
{
  "tool": "run_checklist",
  "args": {
    "stage": "full"
  }
}
```

**返回：**
```json
{
  "status": "success",
  "message": "请按以下顺序检查：格式 → 内容 → 查重 → 答辩 → 提交",
  "checklist": {
    "format": {"title": "📐 格式检查", "items": [...]},
    "content": {"title": "📝 内容完整性", "items": [...]},
    ...
  }
}
```

### 示例3：解读导师反馈

**MCP 调用：**
```json
{
  "tool": "interpret_feedback",
  "args": {
    "feedback": "论证不够充分",
    "chapter": "第4章 实证分析"
  }
}
```

**返回：**
```json
{
  "status": "success",
  "interpretations": [{
    "matched_keyword": "论证不够充分",
    "meaning": "论点和论据之间缺乏逻辑连接",
    "actions": ["补充更多支撑数据", "增加过渡句", "增加对比论证"],
    "example": "原：直播带货效果好。改：据艾瑞咨询数据，2024年直播电商规模达2.8万亿..."
  }],
  "quick_win": "最快速的改进方式：补充更多支撑数据"
}
```

## 参考文献（内置）

| ID | 文件 | 简介 |
|----|------|------|
| checklist | checklist.md | 论文自检四维清单 |
| literature_review | literature-review.md | 文献综述写作 |
| plagiarism_guide | plagiarism-guide.md | 查重与AI检测 |
| toolchain_guide | toolchain-guide.md | 工具链与时间规划 |
| topic_selection | topic-selection.md | 选题诊断指南 |
| quantitative_research | quantitative-research.md | 量化研究全程 |
| qualitative_research | qualitative-research.md | 质性研究专项 |
| outline_templates | outline-templates.md | 多学科大纲模板 |

## 版本历史

- **v1.0.0** (2026-04-21) — 初始版本，基于 thesis-tutor v3.4 封装
