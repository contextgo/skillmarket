# thesis-tutor-mcp

论文写作辅导 MCP 服务器 - 从选题到答辩的全流程 AI 导师。

## 简介

thesis-tutor-mcp 是一个基于 MCP（Model Context Protocol）的论文写作辅导工具，提供 **7 阶段全流程辅导** 和 **8 个专项参考模块**，帮助大学生完成毕业论文。

## 功能特性

### 七阶段核心流程

| 阶段 | 名称 | 功能 |
|------|------|------|
| 1 | 选题诊断 | 推荐可行题目、评估难度 |
| 2 | 开题报告 | 研究问题、文献综述框架 |
| 3 | 大纲构建 | 生成三级大纲结构 |
| 4 | 逐章辅导 | 章节批注、修改建议 |
| 5 | 自检清单 | 格式/内容/查重检查 |
| 6 | 导出 docx | 一键导出 Word 文档 |
| 7 | 答辩准备 | 模拟答辩、问题预测 |

### 九个 MCP 工具

| 工具 | 用途 |
|------|------|
| `get_topic_suggestions` | 根据专业+兴趣推荐选题 |
| `generate_outline` | 生成论文大纲 |
| `review_chapter` | 章节内容批注 |
| `interpret_feedback` | 解读导师反馈 |
| `run_checklist` | 交稿前检查清单 |
| `simulate_defense` | 答辩模拟 |
| `list_references` | 列出可用参考文献模块 |
| `get_reference` | 读取参考文献内容 |
| `get_skill_info` | 获取技能元信息 |

### 八个专项模块

- **checklist** - 论文自检清单
- **literature_review** - 文献综述写作指南
- **plagiarism_guide** - 查重与 AI 检测应对
- **toolchain_guide** - 写作工具链推荐
- **topic_selection** - 选题探索方法
- **quantitative_research** - 量化研究方法
- **qualitative_research** - 质性研究方法
- **outline_templates** - 大纲模板库

## 安装

### 前置要求

- Python 3.10+
- fastmcp 库

### 安装依赖

```bash
pip install fastmcp
```

## 使用方法

### 方式一：作为 MCP 服务器运行

```bash
cd "D:\Skill Encyclopedia\thesis-tutor-mcp"
fastmcp run server.py
```

服务器将在 `http://127.0.0.1:8000/sse` 启动。

### 方式二：在 OpenClaw 中注册

在 OpenClaw 配置文件中添加：

```json
{
  "mcpServers": {
    "thesis-tutor": {
      "command": "fastmcp",
      "args": ["run", "D:/Skill Encyclopedia/thesis-tutor-mcp/server.py"]
    }
  }
}
```

### 方式三：直接调用 Python 函数

```python
from server import get_topic_suggestions, generate_outline

# 获取选题建议
topics = get_topic_suggestions(
    major="市场营销",
    grade="本科",
    interests="直播带货",
    require_data=False
)

# 生成大纲
outline = generate_outline(
    title="直播带货对消费者购买决策的影响研究",
    major="市场营销",
    level="本科"
)
```

## 示例对话

### 选题推荐

```
用户：我是市场营销本科，对直播带货感兴趣，帮我推荐几个论文题目

thesis-tutor：
1. 直播带货对消费者购买决策的影响研究 [难度：中]
2. KOL直播带货模式的效果评估 [难度：易]
3. 直播带货中的冲动性消费行为研究 [难度：中]
...
```

### 大纲生成

```
用户：帮我生成《直播带货对消费者购买决策的影响研究》的大纲

thesis-tutor：
第1章 绪论
  1.1 研究背景与意义
  1.2 研究目的与内容
  1.3 研究方法与技术路线
第2章 文献综述
  2.1 直播电商发展现状
  2.2 消费者购买决策理论
  ...
```

## 文件结构

```
thesis-tutor-mcp/
├── server.py              # MCP 服务器主文件
├── SKILL.md               # MCP 技能定义
├── package.json           # SkillHub 包信息
├── README.md              # 本文件
└── references/            # 专项参考文献
    ├── checklist.md
    ├── literature_review.md
    ├── outline_templates.md
    ├── plagiarism_guide.md
    ├── qualitative_research.md
    ├── quantitative_research.md
    ├── toolchain_guide.md
    └── topic_selection.md
```

## 边界说明

**thesis-tutor 能做的：**
- 提供写作思路和框架建议
- 批注已有内容、指出问题
- 解读导师反馈、给出修改方向
- 提供研究方法参考

**thesis-tutor 不能做的：**
- 代写论文内容（学术诚信底线）
- 伪造数据或实验结果
- 保证通过查重或答辩

## 作者

一梦繁星

## 许可证

MIT License
