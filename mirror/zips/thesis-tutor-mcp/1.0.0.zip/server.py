# -*- coding: utf-8 -*-
"""
thesis-tutor-mcp - 论文写作全流程导师 MCP 服务器
基于 FastMCP 构建，为 AI Agent 提供论文写作七阶段工具
"""

from pathlib import Path
from typing import Optional

try:
    from fastmcp import FastMCP
except ImportError:
    raise ImportError(
        "fastmcp 未安装。运行: pip install fastmcp\n"
        "或通过 qclaw-env skill 安装: skillhub_install install_skill openclaw"
    )

# ─── 常量 ───────────────────────────────────────────────────────────────
SKILL_DIR = Path(__file__).parent
REFERENCES_DIR = SKILL_DIR / "references"
SKILL_MD = SKILL_DIR / "SKILL.md"

# ─── 七阶段流程定义 ──────────────────────────────────────────────────────
STAGES = [
    {
        "id": 1,
        "name": "选题诊断",
        "description": "帮你找到能写下去的题目",
        "tasks": ["专业匹配", "兴趣探测", "可行性评估"],
        "output": "3-5个备选题目 + 推荐理由",
    },
    {
        "id": 2,
        "name": "开题报告",
        "description": "定好题目后，生成结构化开题文档",
        "tasks": ["研究背景", "研究意义", "文献综述", "研究方法"],
        "output": "完整开题报告文档",
    },
    {
        "id": 3,
        "name": "大纲构建",
        "description": "搭好章节结构再动笔",
        "tasks": ["章节安排", "字数分配", "逻辑验证"],
        "output": "完整论文大纲（逐章+字数）",
    },
    {
        "id": 4,
        "name": "逐章辅导",
        "description": "写哪章问哪章，像导师批注一样给修改建议",
        "tasks": ["内容批注", "逻辑诊断", "改进建议"],
        "output": "分章节反馈报告",
    },
    {
        "id": 5,
        "name": "自检清单",
        "description": "提交前四维检查",
        "tasks": ["格式检查", "内容完整性", "查重预判", "答辩准备度"],
        "output": "待办清单 + 优先级排序",
    },
    {
        "id": 6,
        "name": "导出Word",
        "description": "一键生成符合模板的规范文档",
        "tasks": ["格式套用", "目录生成", "页眉页脚"],
        "output": "可直接提交的 .docx 文件",
    },
    {
        "id": 7,
        "name": "答辩准备",
        "description": "模拟答辩，胸有成竹",
        "tasks": ["答辩模拟", "问题库练习", "PPT建议"],
        "output": "5-8道预测问题 + 答题思路",
    },
]

# ─── 参考文献目录 ───────────────────────────────────────────────────────
REFERENCE_FILES = {
    "checklist": "论文自检清单（格式/引用/逻辑/提交前）",
    "literature_review": "文献综述写作（分类框架/述评写法/研究缺口）",
    "plagiarism_guide": "查重与AI检测（降重方法/AI率控制/超标处理）",
    "toolchain_guide": "论文写作工具链（文献管理/数据分析/时间规划）",
    "topic_selection": "选题诊断指南（方向探测/可行性评估）",
    "quantitative_research": "量化研究全程（问卷设计/SPSS分析/中介效应）",
    "qualitative_research": "质性研究专项（访谈法/案例研究/扎根理论）",
    "outline_templates": "多学科大纲模板（8个学科）",
}

# ─── 初始化 MCP ─────────────────────────────────────────────────────────
mcp = FastMCP(
    "thesis-tutor",
)


# ═══════════════════════════════════════════════════════════════════════════
# 工具：选题与大纲
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool(
    name="get_topic_suggestions",
    description="根据学生专业和兴趣方向，推荐3-5个可行的论文题目",
)
def get_topic_suggestions(
    major: str,
    grade: str,
    interests: str,
    require_data: bool = False,
) -> dict:
    """
    根据专业和兴趣推荐论文题目。

    Args:
        major: 所学专业（如：市场营销、计算机科学、教育学）
        grade: 年级（本科/硕士/博士）
        interests: 对什么方向感兴趣（如：直播带货、社交媒体、AI教育）
        require_data: 是否必须用真实数据
    """
    import random

    # 演示用题目库（实际由 AI 根据上下文生成）
    topic_templates = {
        "商科": [
            "消费者在直播间的购买意愿影响因素研究——以{interest}为例",
            "{interest}对消费者购买决策的影响机制研究",
            "基于SOR模型的{interest}用户行为研究",
            "新媒体环境下{interest}的品牌传播策略研究",
            "{interest}的商业模式创新路径研究",
        ],
        "理工科": [
            "基于机器学习的{interest}预测模型研究",
            "{interest}系统的设计与实现",
            "面向{interest}的算法优化研究",
            "{interest}中的数据安全与隐私保护",
            "基于{interest}的智能化应用研究",
        ],
        "文科": [
            "{interest}的文化内涵与当代价值研究",
            "新媒体时代的{interest}传播特征研究",
            "{interest}对青少年价值观的影响研究",
            "跨文化视角下的{interest}比较研究",
            "{interest}的保护与传承路径探析",
        ],
        "教育学": [
            "基于{interest}的教学模式创新研究",
            "{interest}在高校教学中的应用效果研究",
            "大学生{interest}能力培养路径研究",
            "{interest}对学习效果的影响机制研究",
            "混合式教学中{interest}的应用研究",
        ],
        "医学": [
            "{interest}的临床应用与效果评价",
            "基于循证医学的{interest}研究",
            "{interest}对患者预后影响的多因素分析",
            "{interest}的发病机制研究进展",
            "{interest}诊疗指南的循证评价",
        ],
        "法学": [
            "{interest}的法律规制研究",
            "数字经济背景下{interest}的法律问题研究",
            "{interest}的司法实践案例分析",
            "比较法视角下的{interest}研究",
            "{interest}与个人信息保护的法律冲突",
        ],
        "经管": [
            "企业{interest}管理的优化策略研究",
            "{interest}对企业绩效的影响机制",
            "数字化转型背景下{interest}研究",
            "{interest}的风险评估与应对策略",
            "基于平衡计分卡的{interest}评价体系",
        ],
    }

    # 判断专业类别
    major_category = "商科"
    for category in topic_templates:
        if category in major or major in category:
            major_category = category
            break

    templates = topic_templates[major_category]
    suggestions = []
    for i, template in enumerate(templates[:5], 1):
        difficulty = ["易", "中", "难"][min(i - 1, 2)]
        suggestions.append({
            "rank": i,
            "title": template.format(interest=interests),
            "difficulty": difficulty,
            "data_needed": "是" if require_data else "可选",
            "reference_tips": f"建议检索关键词：{interests} + {major} + 实证研究",
        })

    return {
        "status": "success",
        "major": major,
        "major_category": major_category,
        "interests": interests,
        "grade": grade,
        "suggestions": suggestions,
        "next_step": "选题后，进入阶段2（开题报告）或阶段3（大纲构建）",
        "usage_tip": (
            "直接复制题目编号发给 thesis-tutor，例如：'我选第2个：{title}'"
        ),
    }


@mcp.tool(
    name="generate_outline",
    description="根据论文题目，生成完整的论文大纲（逐级标题+字数分配）",
)
def generate_outline(
    title: str,
    major: str,
    level: str = "本科",
    research_type: str = "实证研究",
) -> dict:
    """
    生成论文大纲模板。

    Args:
        title: 论文题目
        major: 所学专业
        level: 学历层次（本科/硕士）
        research_type: 研究类型（实证研究/案例研究/文献综述/设计研究）
    """
    # 基础大纲模板
    bachelor_outline = [
        {"chapter": "第1章 绪论", "subsections": ["1.1 研究背景", "1.2 研究意义", "1.3 研究内容与方法", "1.4 研究框架"], "words": "2000-3000"},
        {"chapter": "第2章 理论基础与文献综述", "subsections": ["2.1 核心概念界定", "2.2 理论基础", "2.3 国内外研究现状", "2.4 文献述评"], "words": "4000-5000"},
        {"chapter": "第3章 研究设计", "subsections": ["3.1 研究假设", "3.2 研究模型", "3.3 变量测量", "3.4 问卷/实验设计"], "words": "2000-3000"},
        {"chapter": "第4章 实证分析", "subsections": ["4.1 描述性统计", "4.2 信度效度检验", "4.3 相关分析", "4.4 回归分析/假设检验"], "words": "3000-4000"},
        {"chapter": "第5章 结论与展望", "subsections": ["5.1 研究结论", "5.2 实践建议", "5.3 研究局限与未来展望"], "words": "2000-2500"},
    ]

    master_outline = [
        {"chapter": "第1章 绪论", "subsections": ["1.1 研究背景与问题提出", "1.2 研究意义（理论/实践）", "1.3 研究目标与内容", "1.4 研究方法与技术路线", "1.5 研究创新点"], "words": "4000-5000"},
        {"chapter": "第2章 理论基础与文献综述", "subsections": ["2.1 核心概念界定与辨析", "2.2 理论基础与分析框架", "2.3 国内外研究现状", "2.4 研究缺口与本研究定位"], "words": "6000-8000"},
        {"chapter": "第3章 研究设计", "subsections": ["3.1 研究假设推导", "3.2 理论模型构建", "3.3 变量操作化定义", "3.4 研究方法选择与实施"], "words": "4000-5000"},
        {"chapter": "第4章 实证分析与讨论", "subsections": ["4.1 描述性统计与数据质量", "4.2 测量模型检验（信度/效度/收敛效度）", "4.3 结构模型检验（假设检验）", "4.4 稳健性检验", "4.5 结果讨论"], "words": "6000-8000"},
        {"chapter": "第5章 结论与展望", "subsections": ["5.1 主要研究结论", "5.2 理论贡献与实践启示", "5.3 研究局限与未来方向"], "words": "3000-4000"},
    ]

    case_outline = [
        {"chapter": "第1章 绪论", "subsections": ["1.1 研究背景", "1.2 研究目的与意义", "1.3 研究方法与框架"], "words": "2000-3000"},
        {"chapter": "第2章 相关理论与案例介绍", "subsections": ["2.1 核心理论概述", "2.2 案例选择依据", "2.3 案例基本情况"], "words": "4000-5000"},
        {"chapter": "第3章 案例分析", "subsections": ["3.1 案例深入剖析", "3.2 成功/失败因素", "3.3 对比分析"], "words": "4000-5000"},
        {"chapter": "第4章 启示与建议", "subsections": ["4.1 案例启示", "4.2 对策建议", "4.3 适用边界"], "words": "3000-4000"},
        {"chapter": "第5章 结论", "subsections": ["5.1 研究结论", "5.2 研究局限"], "words": "1500-2000"},
    ]

    # 选择模板
    if level == "硕士":
        outline = master_outline
    elif research_type in ["案例研究", "案例分析"]:
        outline = case_outline
    else:
        outline = bachelor_outline

    total_words = sum(
        int(w.split("-")[-1].replace("+", "").replace("000", "000"))
        for item in outline
        for w in item["words"].split("-")
    )

    return {
        "status": "success",
        "title": title,
        "major": major,
        "level": level,
        "research_type": research_type,
        "outline": outline,
        "total_words_hint": f"约 {total_words // 2}000-{total_words // 1000 * 1000} 字",
        "writing_tip": "先写第3章（研究设计），再写第2章（文献综述），最后写第1章（绪论）。",
        "next_step": "把大纲发给 thesis-tutor 开始逐章写作辅导，或说'帮我写绪论'",
    }


# ═══════════════════════════════════════════════════════════════════════════
# 工具：逐章辅导
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool(
    name="review_chapter",
    description="像导师一样批注一段论文内容，给出3-5条修改建议",
)
def review_chapter(
    chapter_title: str,
    content: str,
    context: Optional[str] = None,
) -> dict:
    """
    论文内容批注与反馈。

    Args:
        chapter_title: 章节标题（如：第3章 研究假设与模型构建）
        content: 章节内容（建议500-1500字）
        context: 上下文（可选，如：大纲、前文摘要、其他章节）
    """
    word_count = len(content)

    if word_count < 50:
        return {
            "status": "warning",
            "message": "内容太短（不足50字），难以给出有效建议。建议粘贴200字以上内容。",
            "word_count": word_count,
        }

    # 通用检查项
    checks = {
        "word_count_ok": word_count >= 500,
        "has_citation": any(marker in content for marker in ["[", "（", "(", '"', "202", "2020", "2021", "2022", "2023", "2024", "2025"]),
        "has_data": any(keyword in content for keyword in ["数据", "结果", "表明", "显示", "分析", "统计", "调查", "实验", "研究"]),
        "is_academic_tone": not any(word in content for word in ["我觉得", "我认为", "我以为", "大家知道", "不用说"]),
    }

    # 章节特定检查
    chapter_type = _detect_chapter_type(chapter_title)
    type_feedback = _get_chapter_feedback(chapter_type, content)

    # 通用问题诊断
    issues = _diagnose_common_issues(content, chapter_type)

    return {
        "status": "success",
        "chapter": chapter_title,
        "chapter_type": chapter_type,
        "word_count": word_count,
        "checks": checks,
        "issues": issues,
        "feedback": type_feedback,
        "actionable_tips": _get_actionable_tips(chapter_type, issues, checks),
        "overall_score": _calc_score(checks, issues),
    }


@mcp.tool(
    name="interpret_feedback",
    description="把导师的模糊反馈翻译成具体可执行的修改步骤",
)
def interpret_feedback(
    feedback: str,
    chapter: str,
) -> dict:
    """
    解读导师反馈。

    Args:
        feedback: 导师的原话反馈
        chapter: 涉及的章节
    """
    # 常见反馈模式 → 具体操作映射
    feedback_map = {
        "论证不够充分": {
            "meaning": "论点和论据之间缺乏逻辑连接，或论据不足以支撑论点",
            "actions": [
                "补充更多支撑数据（文献/统计/案例）",
                "在论点和论据之间增加过渡句",
                "用具体数据替代泛泛描述",
                "增加对比论证（正向+反面）",
            ],
            "example": "原：直播带货效果好。改：据艾瑞咨询数据，2024年直播电商规模达2.8万亿，同比增长18.2%，其中头部主播GMV占比超60%（来源），可见直播带货已形成规模效应。",
        },
        "逻辑不清晰": {
            "meaning": "段落之间或句子之间的逻辑关系不明确",
            "actions": [
                "检查段落内部的「总-分-总」结构",
                "增加连接词（首先、其次、然而、因此、由此可见）",
                "确保每段首句是该段主题句",
                "检查段落顺序是否符合【现象→原因→结果】的逻辑",
            ],
            "example": "增加逻辑连接词：'造成这一现象的原因有三：第一……；第二……；第三……。'",
        },
        "文献综述不够": {
            "meaning": "引用文献数量不足，或述评深度不够",
            "actions": [
                "补充近3年核心期刊文献（CNKI检索高被引）",
                "增加外文文献（SSCI/CSSCI）",
                "增加述评：评述现有研究'做了什么''缺了什么'",
                "在文献之间建立逻辑关系（而非罗列）",
            ],
            "example": "将'张三(2020)做了A研究，李四(2021)做了B研究'改为'现有研究主要从A视角（张三,2020）和B视角（李四,2021）展开，但尚无研究将两者结合，本研究试图填补这一空白。'",
        },
        "格式不对": {
            "meaning": "字体、字号、行距、引用格式不符合学校模板",
            "actions": [
                "下载学校官方论文模板",
                "对照模板逐项检查：字体(宋体小四/Times New Roman 12pt)、行距(1.5倍)、段首缩进(2字符)",
                "引用格式按GB/T 7714标准核对",
                "用'视图→导航窗格→目录'自动生成目录（非手动输入）",
            ],
            "example": "期刊格式：[序号] 作者. 题名[J]. 刊名, 年, 卷(期): 起止页码.",
        },
        "创新点不突出": {
            "meaning": "没有清晰说明本研究与已有研究的区别和贡献",
            "actions": [
                "明确写出'本研究与现有研究相比有三处创新：①……②……③……'",
                "创新可以体现在：研究视角、理论框架、研究方法、研究对象",
                "在结论章节专门用一段总结创新点",
            ],
            "example": "本研究的创新点在于：（1）视角创新——首次将A理论应用于B领域；（2）方法创新——采用混合研究设计；（3）实践创新——针对C群体提出D策略。",
        },
        "研究方法不明确": {
            "meaning": "读者不清楚你用什么方法、为什么用这个方法",
            "actions": [
                "补充说明选择该方法的依据",
                "详细描述实施步骤",
                "说明方法的优势和局限",
                "增加方法对比（为何选A而非B/C）",
            ],
            "example": "本研究采用问卷调查法，原因有三：（1）研究变量可量化；（2）需要大样本统计推断；（3）成本可控。相比之下，实验法虽能建立因果关系，但外部效度有限。",
        },
    }

    # 智能匹配
    matched_feedback = []
    for key, value in feedback_map.items():
        if key in feedback:
            matched_feedback.append({**value, "matched_keyword": key})

    if not matched_feedback:
        return {
            "status": "success",
            "chapter": chapter,
            "raw_feedback": feedback,
            "interpretation": "未能自动识别反馈类型，请参考以下通用解读：",
            "actions": [
                "① 仔细重读导师标注的位置",
                "② 问导师：'请问具体是哪个方面需要修改？我好有针对性地改'",
                "③ 通用建议：先理清思路（写下来：论点是什么→论据是什么→逻辑是否通顺），再动笔修改",
            ],
            "tip": "把导师的反馈原话发给 thesis-tutor，获取更精准的解读",
        }

    return {
        "status": "success",
        "chapter": chapter,
        "raw_feedback": feedback,
        "interpretations": matched_feedback,
        "quick_win": "最快速的改进方式：" + matched_feedback[0]["actions"][0],
        "full_guide": "发给 thesis-tutor 原文：'导师说：《 + feedback + 》，获取分步骤操作指南",
    }


# ═══════════════════════════════════════════════════════════════════════════
# 工具：自检与答辩
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool(
    name="run_checklist",
    description="论文交稿前的终极四维检查（格式/内容/查重/答辩准备）",
)
def run_checklist(
    stage: str = "full",
) -> dict:
    """
    运行论文自检清单。

    Args:
        stage: 检查维度（full=全部/format=格式/content=内容/plagiarism=查重/defense=答辩）
    """
    checklist = {
        "format": {
            "title": "📐 格式检查",
            "items": [
                {"text": "页眉页脚是否符合学校模板", "critical": True},
                {"text": "字体字号：中文宋体小四/英文Times New Roman 12pt", "critical": True},
                {"text": "行距1.5倍 + 段落首行缩进2字符", "critical": True},
                {"text": "目录自动生成（非手动输入）且页码对应", "critical": True},
                {"text": "图号/表号连续编号，图标标题位置正确", "critical": False},
                {"text": "参考文献格式符合GB/T 7714", "critical": True},
                {"text": "中英文摘要≤300字，含目的/方法/结果/结论", "critical": True},
                {"text": "关键词3-5个，与中英文对应", "critical": False},
            ],
            "tip": "最常见格式错误：目录页码不对、参考文献缺页码、图表标题位置颠倒",
        },
        "content": {
            "title": "📝 内容完整性检查",
            "items": [
                {"text": "绪论提出的研究问题在结论中有回应", "critical": True},
                {"text": "研究方法能支撑研究结论", "critical": True},
                {"text": "每章有小结，章间有过渡段落", "critical": False},
                {"text": "概念首次出现时有定义，缩写首次出现时写全称", "critical": True},
                {"text": "引用数量达标（本科≥15篇，硕士≥30篇）", "critical": True},
                {"text": "近5年文献占比≥50%，外文文献≥1/3", "critical": False},
                {"text": "无自相矛盾的论述", "critical": True},
                {"text": "致谢无错别字（尤其导师姓名）", "critical": False},
            ],
            "tip": "交稿前最易忘：致谢检查、外文文献引用格式、页眉学校名称",
        },
        "plagiarism": {
            "title": "🔍 查重风险预判",
            "items": [
                {"text": "每段超过3句连续相同表述需改写", "critical": True},
                {"text": "直接引用单次不超过50字，需加引号+标注", "critical": True},
                {"text": "参考文献本身不计入查重，但引用格式错误会计入", "critical": True},
                {"text": "表格/公式/代码如来自他人，需在表注/脚注说明", "critical": False},
                {"text": "AI生成内容比例建议≤30%（知网AIGC检测2025已升级）", "critical": True},
            ],
            "tip": "降重技巧：同义改写>语序调整>图表转换>翻译中转（但核心观点必须原创）",
        },
        "defense": {
            "title": "🎤 答辩准备度",
            "items": [
                {"text": "3-5分钟自述稿已准备，能流畅讲完", "critical": True},
                {"text": "PPT每页不超过6行，每行不超过6字", "critical": False},
                {"text": "预判答辩老师会问的5-8个问题并准备答案", "critical": True},
                {"text": "能回答'为什么选这个题目'（创新点、意义）", "critical": True},
                {"text": "能回答'用了什么方法/为什么用这个方法'", "critical": True},
                {"text": "知道自己论文的3个局限性", "critical": False},
                {"text": "格式文件、查重报告、授权书等答辩材料齐全", "critical": True},
            ],
            "tip": "答辩最常见问题：'创新点是什么''局限性有哪些''下一步研究计划'",
        },
        "submission": {
            "title": "🚀 提交前终极检查（最容易忘）",
            "items": [
                {"text": "导师看过终稿并口头/书面同意提交", "critical": True},
                {"text": "按学校要求命名文件（如'学号_姓名_论文标题.docx'）", "critical": True},
                {"text": "确认提交的是终稿（非中间版本）", "critical": True},
                {"text": "盲审要求：确认是否隐去姓名/导师信息", "critical": True},
                {"text": "开题报告、中期检查表、查重授权书等附加材料齐全", "critical": True},
                {"text": "截止日期前至少1天提交（防系统卡顿）", "critical": True},
            ],
            "tip": "每年都有学生因为'版本发错了''文件名不对''忘了附查重报告'被推迟答辩！",
        },
    }

    if stage == "full":
        return {
            "status": "success",
            "message": "请按以下顺序逐项检查：格式 → 内容 → 查重 → 答辩 → 提交",
            "checklist": checklist,
        }
    elif stage in checklist:
        return {
            "status": "success",
            "check": checklist[stage],
            "usage": f"发给 thesis-tutor：'帮我过一遍{checklist[stage]['title'].split(' ')[1]}检查'",
        }
    else:
        return {
            "status": "error",
            "message": f"未知的检查维度: {stage}。可选: full, format, content, plagiarism, defense, submission",
        }


@mcp.tool(
    name="simulate_defense",
    description="模拟论文答辩，给出3-5道预测问题并提供答题思路",
)
def simulate_defense(
    title: str,
    major: str,
    methodology: str = "问卷调查",
    has_data: bool = True,
    num_questions: int = 5,
) -> dict:
    """
    答辩模拟与问题预测。

    Args:
        title: 论文题目
        major: 所学专业
        methodology: 研究方法（问卷调查/访谈/案例研究/实验）
        has_data: 是否有数据分析结果
        num_questions: 预测问题数量（默认5道）
    """
    # 通用高频问题
    common_questions = [
        {
            "q": "为什么选这个题目？/ 研究意义是什么？",
            "difficulty": "基础",
            "answer_framework": "现实背景（现象/问题）+ 理论缺口（现有研究不足）+ 本研究价值",
            "example": "近年来直播电商蓬勃发展（现实背景），但现有研究多从平台视角出发，较少关注消费者心理层面（理论缺口），本研究从感知价值理论出发，探究消费者购买意愿的影响机制，具有理论和实践价值。",
            "tip": "控制在1-2分钟内，逻辑清晰，不要背稿",
        },
        {
            "q": "创新点是什么？",
            "difficulty": "核心",
            "answer_framework": "视角创新 / 理论创新 / 方法创新 / 实践创新（至少说1-2个）",
            "example": "本研究的创新点有二：（1）视角创新——首次将A理论应用于B场景；（2）方法创新——采用混合研究设计（问卷+访谈）弥补单一方法的局限。",
            "tip": "创新点不是越大越好，要具体、可信，说1-2个真实的即可",
        },
        {
            "q": "用了什么研究方法？/ 为什么用这个方法？",
            "difficulty": "基础",
            "answer_framework": "方法名称 + 选择依据 + 实施概况 + 方法局限",
            "example": "本研究采用问卷调查法，发放问卷X份，有效回收Y份（有效率Z%）。选择该方法的原因：（1）研究变量可量化；（2）需要大样本统计推断；（3）成本可控。本方法的局限在于难以建立严格因果关系，后续可用实验法补充验证。",
            "tip": "要能说清楚抽样方法、样本量、问卷来源",
        },
        {
            "q": "你的研究结论是什么？/ 主要发现了什么？",
            "difficulty": "核心",
            "answer_framework": "总-分结构：先说总体结论，再逐条列出具体发现",
            "example": "本研究得出以下结论：（1）感知有用性和感知趣味性正向影响购买意愿；（2）信任在感知价值与购买意愿间起中介作用；（3）沉浸体验的调节效应不显著。",
            "tip": "用数字/字母编号，清晰列出，避免说'很多''显著'这类模糊词",
        },
        {
            "q": "研究有哪些局限性？",
            "difficulty": "中等",
            "answer_framework": "承认局限 + 原因解释 + 未来改进方向",
            "example": "本研究存在以下局限：（1）样本以大学生为主，外部效度有限（受时间和经费限制）；（2）横截面数据无法揭示因果方向；（3）仅考察了部分调节变量。未来研究可扩大样本范围，采用追踪设计进一步验证。",
            "tip": "不要怕说局限性，这是学术诚信的体现；也不要说得太严重影响评委信心",
        },
        {
            "q": "你的建议是什么？（对实践/理论的启示）",
            "difficulty": "中等",
            "answer_framework": "实践建议 + 理论贡献，分条列出",
            "example": "对企业的启示：（1）应注重提升消费者的感知有用性和信任感；（2）可通过KOL推荐增强消费者沉浸体验。对理论的启示：（1）丰富了感知价值理论在直播场景的应用；（2）揭示了信任的中介机制。",
            "tip": "建议要有针对性，不能泛泛而谈，结合自己的研究发现来提",
        },
    ]

    # 根据研究方法增减特定问题
    method_questions = {
        "问卷调查": [
            {
                "q": "问卷如何设计/量表来源是什么？",
                "difficulty": "中等",
                "answer_framework": "量表来源（成熟量表/改编） + 预测试情况 + 问卷结构",
                "example": "量表主要来自Smith(2010)和Chen(2018)等成熟研究，经预测试（n=50）验证后微调。问卷包括三部分：人口统计变量（4题）、核心变量（20题）、开放题（1题），共25题。",
                "tip": "要能说出预测试结果（信度Cronbach's α值）",
            },
            {
                "q": "样本量怎么确定的？/ 做了哪些统计检验？",
                "difficulty": "中等",
                "answer_framework": "样本量依据 + 统计方法列表 + 软件工具",
                "example": "根据结构方程模型的要求，样本量需≥200（Hair, 2010标准）。本研究有效样本326份，采用SPSS 26.0和AMOS 24.0进行了描述性统计、信度分析（Cronbach's α）、探索性因子分析、KMO和Bartlett球形检验、验证性因子分析、结构方程模型分析。",
                "tip": "统计方法要说准确，不要夸大",
            },
        ],
        "访谈": [
            {
                "q": "访谈对象怎么选择的？/ 访谈了多少人？",
                "difficulty": "基础",
                "answer_framework": "选取标准 + 人数 + 编码方法",
                "example": "采用目的性抽样，选取X名有相关经历的受访者，以达到理论饱和为标准，最终访谈了X名。资料分析采用主题分析法，编码过程包括开放式编码、主轴编码、选择性编码三个阶段。",
                "tip": "编码软件可用NVivo，但要能说清楚编码过程",
            },
        ],
        "案例研究": [
            {
                "q": "为什么选择这个案例？/ 案例有什么代表性？",
                "difficulty": "基础",
                "answer_framework": "选择标准 + 案例基本情况 + 代表性说明",
                "example": "选择该案例的原因：（1）行业代表性——属于头部企业；（2）数据可得性——有公开的财务和媒体报道；（3）理论适配性——完美契合本研究的理论框架。",
                "tip": "不要说'因为好找''因为导师推荐'",
            },
        ],
    }

    # 组合问题集
    questions = list(common_questions)
    if methodology in method_questions:
        questions.extend(method_questions[methodology])

    # 如果没有数据结果，替换部分问题
    if not has_data:
        for q in questions:
            if "数据" in q["q"] or "统计" in q["q"]:
                q["q"] = "研究目前进展如何？/ 预计得出什么结论？"

    # 随机选 num_questions 道
    import random
    selected = random.sample(questions, min(num_questions, len(questions)))

    return {
        "status": "success",
        "title": title,
        "major": major,
        "methodology": methodology,
        "predicted_questions": selected,
        "defense_tips": [
            "开场白控制在3-5分钟，重点说清楚：做了什么（研究内容）+ 发现了什么（结论）",
            "PPT每页不超过6行、每行不超过6字，多用图表少用文字",
            "不会的问题：'这个问题我目前研究不够深入，感谢老师指点，我下来会进一步学习'",
            "不要和评委争论，先听清楚问题再答，语速适中",
        ],
        "next_step": "发给 thesis-tutor：'帮我模拟答辩，我是XXX题目，用XXX方法'",
    }


# ═══════════════════════════════════════════════════════════════════════════
# 工具：参考文献
# ═══════════════════════════════════════════════════════════════════════════

@mcp.tool(
    name="list_references",
    description="列出所有可用的参考文献模块，返回ID和简介",
)
def list_references() -> dict:
    """列出所有参考文献模块。"""
    return {
        "status": "success",
        "total": len(REFERENCE_FILES),
        "references": [
            {"id": key, "name": value}
            for key, value in REFERENCE_FILES.items()
        ],
        "usage": "调用 get_reference(id='xxx') 获取完整内容",
    }


@mcp.tool(
    name="get_reference",
    description="获取指定参考文献的完整内容",
)
def get_reference(ref_id: str) -> dict:
    """
    读取参考文献。

    Args:
        ref_id: 文献ID（通过 list_references 获取）
    """
    ref_path = REFERENCES_DIR / f"{ref_id}.md"

    if not ref_path.exists():
        available = list(REFERENCES_DIR.glob("*.md"))
        return {
            "status": "error",
            "message": f"未找到参考文献: {ref_id}",
            "available": [p.stem for p in available],
            "hint": "先用 list_references() 查看所有可用文献",
        }

    try:
        content = ref_path.read_text(encoding="utf-8")
        # 截取摘要（前500字）
        summary = content[:500].replace("\n", " ").strip()
        if len(content) > 500:
            summary += "……"

        return {
            "status": "success",
            "id": ref_id,
            "name": REFERENCE_FILES.get(ref_id, ref_id),
            "file": str(ref_path),
            "word_count": len(content),
            "summary": summary,
            "usage": f"完整内容已返回。如需摘要，发给 thesis-tutor 分析。",
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"读取失败: {str(e)}",
        }


@mcp.tool(
    name="get_skill_info",
    description="获取 thesis-tutor 技能的完整信息（七阶段流程、专项模块）",
)
def get_skill_info() -> dict:
    """获取 thesis-tutor 技能概览。"""
    return {
        "status": "success",
        "name": "thesis-tutor",
        "version": "3.4",
        "description": "论文写作全流程AI导师",
        "author": "一梦繁星",
        "updated": "2026-04-21",
        "stages": STAGES,
        "references": REFERENCE_FILES,
        "core_principle": "不是代写，是引导。解决的是'你不知道该说什么'，而不是'你懒得写'。",
        "key_constraints": [
            "不会直接帮你写完整章节",
            "每个阶段结束主动提示下一步",
            "导师反馈优先于工具建议",
            "最终以学校和导师要求为准",
        ],
        "quick_start": (
            "发给 thesis-tutor：'我是XX专业大四学生，要写毕业论文，完全不知道写什么'"
        ),
    }


# ═══════════════════════════════════════════════════════════════════════════
# 辅助函数
# ═══════════════════════════════════════════════════════════════════════════

def _detect_chapter_type(chapter_title: str) -> str:
    """识别章节类型。"""
    title = chapter_title.lower()
    if "绪论" in title or "前言" in title or "导论" in title:
        return "绪论"
    elif "文献综述" in title or "理论基础" in title or "相关理论" in title:
        return "文献综述"
    elif "研究假设" in title or "模型构建" in title or "研究设计" in title:
        return "研究设计"
    elif "实证" in title or "分析" in title or "结果" in title:
        return "实证分析"
    elif "结论" in title or "总结" in title or "展望" in title:
        return "结论"
    elif "摘要" in title:
        return "摘要"
    elif "致谢" in title:
        return "致谢"
    else:
        return "其他"


def _get_chapter_feedback(chapter_type: str, content: str) -> str:
    """根据章节类型返回特定反馈。"""
    tips = {
        "绪论": "绪论要点：①研究背景用'大→小'漏斗式引出研究问题；②研究意义分'理论意义'和'实践意义'分开写；③研究内容用'研究框架图'可视化。",
        "文献综述": "文献综述要点：①不是罗列文献，而是'评'——指出'做了什么''缺了什么'；②按主题/流派分类，而非按时间顺序；③在文献之间建立逻辑关系，引出本研究。",
        "研究设计": "研究设计要点：①假设要有理论依据，不能凭空捏造；②模型图要清晰（自变量→中介→因变量→调节）；③量表要有来源和预测试验证。",
        "实证分析": "数据分析要点：①先报告描述性统计；②表格要规范（三线表）；③假设检验结果要对应假设编号报告；④结合理论解释统计结果，不能只报数字。",
        "结论": "结论要点：①先总结主要发现；②联系研究问题回答'做了什么、发现了什么'；③讨论理论和实践启示；④承认局限性并提出未来方向；⑤不引入新概念。",
        "摘要": "摘要要点：①300字以内（本科）；②包含目的、方法、结果、结论四个要素；③无引用、无缩写（首次出现写全称）；④语言精炼，不用「本文」「我认为」等第一人称。",
    }
    return tips.get(chapter_type, "")


def _diagnose_common_issues(content: str, chapter_type: str) -> list:
    """诊断常见问题。"""
    issues = []
    if len(content) < 200:
        issues.append({"type": "内容过短", "severity": "high", "detail": f"该章节仅{len(content)}字，建议至少500字"})
    if any(w in content for w in ["我觉得", "我认为", "我认为", "大家知道"]):
        issues.append({"type": "口语化表达", "severity": "medium", "detail": "论文应使用学术语言，避免'我觉得''我认为'等主观表达"})
    if not any(c in content for c in ["(", "[", "（", '"', "202", "2020"]):
        issues.append({"type": "缺少引用", "severity": "high", "detail": "正文缺少文献引用，建议补充2-3篇相关文献支撑论点"})
    if "……" in content or "等等" in content:
        issues.append({"type": "不完整表述", "severity": "medium", "detail": "避免'……''等等'等不完整表述，用具体内容替代"})
    if content.count("\n\n") > len(content) / 500:
        issues.append({"type": "段落过长", "severity": "low", "detail": "部分段落可能过长，建议每段不超过300字"})
    return issues


def _get_actionable_tips(chapter_type: str, issues: list, checks: dict) -> list:
    """生成可操作的改进建议。"""
    tips = []
    if not checks["has_citation"]:
        tips.append("补充文献引用：先在CNKI检索相关研究，再用自己的话转述核心观点")
    if not checks["has_data"]:
        tips.append("补充数据支撑：加入统计数字、案例引用或文献数据")
    if not checks["is_academic_tone"]:
        tips.append("改写为学术语言：'我觉得'→'研究表明'，'很多人'→'已有研究（作者,年份）指出'")
    if any(i["type"] == "内容过短" for i in issues):
        tips.append("扩充内容：先列提纲，补充每段的论据和过渡句")
    if not tips:
        tips.append("内容质量良好！可进入下一章节写作，或发给 thesis-tutor 做详细批注")
    return tips


def _calc_score(checks: dict, issues: list) -> int:
    """计算综合评分（满分100）。"""
    score = 100
    if not checks["has_citation"]:
        score -= 20
    if not checks["has_data"]:
        score -= 15
    if not checks["is_academic_tone"]:
        score -= 15
    if not checks["word_count_ok"]:
        score -= 15
    for issue in issues:
        if issue["severity"] == "high":
            score -= 15
        elif issue["severity"] == "medium":
            score -= 8
    return max(0, score)


# ─── 启动服务器 ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    print("thesis-tutor MCP Server v3.4")
    print(f"Skill dir: {SKILL_DIR}")
    print(f"References: {REFERENCES_DIR}")
    print(f"Available refs: {len(list(REFERENCES_DIR.glob('*.md')))}")
    print()
    print("启动命令: fastmcp run server.py")
    print("调试命令: fastmcp dev server.py")
    mcp.run()
