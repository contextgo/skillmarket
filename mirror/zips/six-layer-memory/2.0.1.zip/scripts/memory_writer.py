#!/usr/bin/env python3

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional


class MemoryWriter:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.getcwd())
        self.memory_dir = self.base_dir / "memory"
        self.session_state = self.memory_dir / "SESSION-STATE.md"
        self.memory_file = self.base_dir / "MEMORY.md"
        self.today = datetime.now().strftime("%Y-%m-%d")

    def write(self, content: str, layer: str = "HOT", source: str = "system") -> int:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        handlers = {
            "HOT": self._write_session_state,
            "CURATED": self._write_daily_log,
            "COLD": self._write_decisions,
            "CLOUD": self._write_cloud_sync,
            "AUTO": self._write_auto_extract,
        }
        handler = handlers.get(layer, self._write_daily_log)
        return handler(content, source, timestamp)

    def _write_session_state(self, content: str, source: str, timestamp: str) -> int:
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        entry_type = self._detect_content_type(content)
        entry = f"[{timestamp}][{source}][{entry_type}] {content}\n"
        existing = self.session_state.read_text(encoding="utf-8") if self.session_state.exists() else "# SESSION-STATE.md - HOT Layer\n\n"
        self.session_state.write_text(existing + entry, encoding="utf-8")
        return len(entry)

    def _write_daily_log(self, content: str, source: str, timestamp: str) -> int:
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        daily_file = self.memory_dir / f"{self.today}.md"
        if not daily_file.exists():
            daily_file.write_text(f"# {self.today} 日志\n\n## 自动维护\n\n", encoding="utf-8")
        entry = f"\n[{timestamp}][{source}] {content}\n"
        with open(daily_file, "a", encoding="utf-8") as fh:
            fh.write(entry)
        return len(entry)

    def _write_decisions(self, content: str, source: str, timestamp: str) -> int:
        decisions_dir = self.memory_dir / "decisions"
        decisions_dir.mkdir(parents=True, exist_ok=True)
        decision_file = decisions_dir / f"{self.today}.md"
        if not decision_file.exists():
            decision_file.write_text(f"# {self.today} 决策记录\n\n", encoding="utf-8")
        with open(decision_file, "a", encoding="utf-8") as fh:
            fh.write(f"## {timestamp}\n- [{source}] {content}\n")
        return len(content)

    def _write_cloud_sync(self, content: str, source: str, timestamp: str) -> int:
        pending_file = self.memory_dir / "auto-extract" / ".cloud_sync_pending"
        pending_file.parent.mkdir(parents=True, exist_ok=True)
        pending = []
        if pending_file.exists():
            pending = json.loads(pending_file.read_text(encoding="utf-8"))
        pending.append({"content": content, "metadata": {"source": source, "timestamp": timestamp}, "synced": False})
        pending_file.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
        return len(content)

    def _write_auto_extract(self, content: str, source: str, timestamp: str) -> int:
        pending_file = self.memory_dir / "auto-extract" / ".mem0_pending"
        pending_file.parent.mkdir(parents=True, exist_ok=True)
        pending = []
        if pending_file.exists():
            pending = json.loads(pending_file.read_text(encoding="utf-8"))
        pending.append({"fact": content, "metadata": {"source": source, "timestamp": timestamp}, "synced": False})
        pending_file.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
        return len(content)

    def _detect_content_type(self, content: str) -> str:
        if any(kw in content for kw in ["偏好", "喜欢", "不喜欢", "要求"]):
            return "PREFERENCE"
        if any(kw in content for kw in ["决策", "决定", "选择", "方案"]):
            return "DECISION"
        if any(kw in content for kw in ["错误", "失败", "问题", "修复"]):
            return "ERROR"
        return "CONTEXT"

    def get_recent(self, layer: str = "HOT", limit: int = 10) -> List[str]:
        if layer == "HOT" and self.session_state.exists():
            return [line.strip() for line in self.session_state.read_text(encoding="utf-8").splitlines()[-limit:] if line.strip()]
        daily_file = self.memory_dir / f"{self.today}.md"
        if daily_file.exists():
            return [line.strip() for line in daily_file.read_text(encoding="utf-8").splitlines()[-limit:] if line.strip()]
        return []
