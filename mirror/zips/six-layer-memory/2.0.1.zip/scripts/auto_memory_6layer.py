#!/usr/bin/env python3

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

MEM0_CONFIG_PATH = Path.home() / ".mem0" / "config.json"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--daily", action="store_true")
    parser.add_argument("--source", default="manual")
    return parser.parse_args()


def build_paths(workspace: Path) -> Dict[str, Path]:
    memory_dir = workspace / "memory"
    curated = workspace / "MEMORY.md"
    if not curated.exists() and (memory_dir / "MEMORY.md").exists():
        curated = memory_dir / "MEMORY.md"
    slug = workspace.name.replace(".", "_")
    return {
        "workspace": workspace,
        "slug": slug,
        "memory_dir": memory_dir,
        "session": memory_dir / "SESSION-STATE.md",
        "curated": curated,
        "decisions": memory_dir / "decisions",
        "auto": memory_dir / "auto-extract",
        "raw_kb": memory_dir / "knowledge-base" / "raw",
        "state_file": memory_dir / "auto-extract" / ".six_layer_state.json",
        "mem0_pending": memory_dir / "auto-extract" / ".mem0_pending",
        "supermemory_sync": memory_dir / "auto-extract" / "supermemory_sync.py",
        "mem0_sync": memory_dir / "auto-extract" / "mem0_sync.py",
        "warm_sync": memory_dir / "lancedb_sync.py",
        "transcript_import": memory_dir / "knowledge-base" / "import_transcripts_to_lancedb.py",
        "content_kb": workspace / "content_kb",
        "content_extract": workspace / "content_kb" / "extract_knowledge.py",
        "content_generate": workspace / "content_kb" / "generate_assets.py",
        "log_file": Path(f"/tmp/memory_6layer_{slug}.log"),
        "lock_file": Path(f"/tmp/openclaw_memory_6layer_{slug}.lock"),
        "last_run": Path(f"/tmp/openclaw_memory_6layer_{slug}.last"),
    }


def log(paths: Dict[str, Path], msg: str):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}][{paths['slug']}] {msg}"
    print(line)
    with open(paths["log_file"], "a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def acquire_lock(paths: Dict[str, Path], source: str) -> bool:
    try:
        fd = os.open(str(paths["lock_file"]), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode("utf-8"))
        os.close(fd)
        return True
    except FileExistsError:
        log(paths, f"skip locked invocation: source={source}")
        return False


def release_lock(paths: Dict[str, Path]):
    try:
        paths["lock_file"].unlink(missing_ok=True)
    except Exception:
        pass


def should_skip_duplicate(paths: Dict[str, Path], source: str) -> bool:
    now = time.time()
    if paths["last_run"].exists():
        try:
            last = float(paths["last_run"].read_text(encoding="utf-8"))
            if now - last < 90 and not source.startswith("manual"):
                log(paths, f"skip duplicate invocation: source={source}")
                return True
        except Exception:
            pass
    paths["last_run"].write_text(str(now), encoding="utf-8")
    return False


def today_log(paths: Dict[str, Path]) -> Path:
    return paths["memory_dir"] / f"{datetime.now().strftime('%Y-%m-%d')}.md"


def ensure_structure(paths: Dict[str, Path]):
    paths["memory_dir"].mkdir(parents=True, exist_ok=True)
    paths["decisions"].mkdir(parents=True, exist_ok=True)
    paths["auto"].mkdir(parents=True, exist_ok=True)
    paths["raw_kb"].mkdir(parents=True, exist_ok=True)

    if not paths["session"].exists():
        paths["session"].write_text("# SESSION-STATE.md - HOT Layer\n\n", encoding="utf-8")
    if not paths["curated"].exists():
        paths["curated"].parent.mkdir(parents=True, exist_ok=True)
        paths["curated"].write_text("# MEMORY.md\n\n", encoding="utf-8")
    day_log = today_log(paths)
    if not day_log.exists():
        day_log.write_text(f"# {datetime.now().strftime('%Y-%m-%d')} 日志\n\n", encoding="utf-8")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def load_state(paths: Dict[str, Path]) -> Dict:
    if paths["state_file"].exists():
        try:
            return json.loads(paths["state_file"].read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"offsets": {}, "hashes": {}, "warm_input_mtime": 0, "content_kb_mtime": 0}


def save_state(paths: Dict[str, Path], state: Dict):
    paths["state_file"].write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def bootstrap_delta(path: Path, key: str, state: Dict) -> str:
    content = read_text(path)
    current = len(content)
    previous = state["offsets"].get(key)
    if previous is None or current < previous:
        state["offsets"][key] = current
        return ""
    state["offsets"][key] = current
    return content[previous:]


def extract_hot_entries(delta: str) -> List[str]:
    entries = []
    for line in delta.splitlines():
        line = line.strip()
        if line.startswith("[20") or any(token in line for token in ["用户：", "决定：", "项目："]):
            entries.append(line)
    return entries


def append_daily(path: Path, entries: List[str]) -> int:
    if not entries:
        return 0
    with open(path, "a", encoding="utf-8") as fh:
        fh.write("\n## [" + datetime.now().strftime("%H:%M:%S") + "] HOT 同步\n")
        for entry in entries:
            fh.write(f"- {entry}\n")
    return len(entries)


def append_cold(path: Path, entries: List[str]) -> int:
    markers = ("DECISION", "决定", "选择", "方案", "PREFERENCE", "偏好")
    selected = [entry for entry in entries if any(marker in entry for marker in markers)]
    if not selected:
        return 0
    if not path.exists():
        path.write_text(f"# {datetime.now().strftime('%Y-%m-%d')} 决策记录\n\n", encoding="utf-8")
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(f"\n## {datetime.now().strftime('%H:%M:%S')}\n")
        for entry in selected:
            fh.write(f"- {entry}\n")
    return len(selected)


def load_mem0(paths: Dict[str, Path]):
    if not MEM0_CONFIG_PATH.exists() or not paths["mem0_sync"].exists():
        return None
    spec = importlib.util.spec_from_file_location(f"mem0_sync_{paths['slug']}", paths["mem0_sync"])
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Mem0Sync(str(paths["workspace"]))


def extract_candidate_facts(content: str) -> List[str]:
    import re
    facts = []
    for pattern in [r"([^。\n]+要[^。\n]+)", r"([^。\n]+不要[^。\n]+)", r"([^。\n]+是[^。\n]+)", r"([^。\n]+不是[^。\n]+)"]:
        for match in re.findall(pattern, content):
            match = match.strip()
            if 5 < len(match) < 100 and match not in facts:
                facts.append(match)
    return facts[:20]


def queue_facts(paths: Dict[str, Path], facts: List[str], source: str) -> int:
    if not facts:
        return 0
    pending = []
    if paths["mem0_pending"].exists():
        pending = json.loads(paths["mem0_pending"].read_text(encoding="utf-8"))
    for fact in facts:
        pending.append({"fact": fact, "metadata": {"source": source, "file": str(paths["session"])}, "synced": False})
    paths["mem0_pending"].write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
    return len(facts)


def sync_auto(paths: Dict[str, Path], delta: str) -> int:
    sync = load_mem0(paths)
    if not delta.strip():
        if sync is not None:
            sync.sync_pending()
        return 0
    if sync is None:
        return queue_facts(paths, extract_candidate_facts(delta), "hot-delta")
    facts = sync.extract_and_sync(delta, metadata={"source": "hot-delta", "file": str(paths["session"])})
    sync.sync_pending()
    return len(facts)


def latest_mtime(directory: Path, pattern: str) -> float:
    files = [p.stat().st_mtime for p in directory.glob(pattern) if p.is_file()]
    return max(files) if files else 0


def sync_warm(paths: Dict[str, Path], state: Dict) -> bool:
    if paths["warm_sync"].exists() and paths["raw_kb"].exists():
        current = latest_mtime(paths["raw_kb"], "*")
        if current > state.get("warm_input_mtime", 0):
            result = subprocess.run(["python3", str(paths["warm_sync"]), "sync"], capture_output=True, text=True)
            if result.returncode == 0:
                state["warm_input_mtime"] = current
                return True
            return False
    if paths["transcript_import"].exists():
        transcript_dir = paths["workspace"] / "memory" / "knowledge-base" / "transcripts_final"
        current = latest_mtime(transcript_dir, "*.txt")
        if current > state.get("warm_input_mtime", 0):
            result = subprocess.run(["python3", str(paths["transcript_import"])], capture_output=True, text=True)
            if result.returncode == 0:
                state["warm_input_mtime"] = current
                return True
    return False


def sync_content_kb(paths: Dict[str, Path], state: Dict) -> bool:
    if not paths["content_extract"].exists() or not paths["content_generate"].exists():
        return False
    transcript_dir = paths["workspace"] / "memory" / "knowledge-base" / "transcripts_final"
    current = latest_mtime(transcript_dir, "*.txt")
    if current <= state.get("content_kb_mtime", 0):
        return False
    r1 = subprocess.run(["python3", str(paths["content_extract"])], cwd=str(paths["content_kb"]), capture_output=True, text=True)
    r2 = subprocess.run(["python3", str(paths["content_generate"])], cwd=str(paths["content_kb"]), capture_output=True, text=True)
    if r1.returncode == 0 and r2.returncode == 0:
        state["content_kb_mtime"] = current
        return True
    return False


def sync_cloud(paths: Dict[str, Path], changed: List[Path]) -> bool:
    if not changed or not paths["supermemory_sync"].exists():
        return False
    cmd = ["python3", str(paths["supermemory_sync"]), "--workspace", str(paths["workspace"])] + [str(p) for p in changed]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0


def run(workspace: str, source: str, daily: bool):
    paths = build_paths(Path(workspace).expanduser().resolve())
    if not acquire_lock(paths, source):
        return
    try:
        if should_skip_duplicate(paths, source):
            return
        ensure_structure(paths)
        state = load_state(paths)
        session_delta = bootstrap_delta(paths["session"], "session", state)
        _ = bootstrap_delta(today_log(paths), "today", state)
        entries = extract_hot_entries(session_delta)
        daily_count = append_daily(today_log(paths), entries)
        cold_count = append_cold(paths["decisions"] / f"{datetime.now().strftime('%Y-%m-%d')}.md", entries)
        auto_count = sync_auto(paths, session_delta)
        warm_count = int(sync_warm(paths, state))
        kb_count = int(sync_content_kb(paths, state))
        changed = []
        if entries:
            changed.append(paths["session"])
        if daily_count:
            changed.append(today_log(paths))
        if paths["curated"].exists():
            changed.append(paths["curated"])
        cloud_count = int(sync_cloud(paths, list(dict.fromkeys(changed))))
        save_state(paths, state)
        log(paths, f"run complete: source={source} entries={len(entries)} daily={daily_count} cold={cold_count} auto_facts={auto_count} warm={warm_count} content_kb={kb_count} cloud={cloud_count}")
    finally:
        release_lock(paths)


if __name__ == "__main__":
    args = parse_args()
    run(args.workspace, args.source, args.daily)
