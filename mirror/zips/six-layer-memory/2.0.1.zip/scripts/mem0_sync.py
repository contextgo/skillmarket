#!/usr/bin/env python3

import importlib.util
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

try:
    from mem0 import Memory
    MEM0_AVAILABLE = True
except ImportError:
    MEM0_AVAILABLE = False


class Mem0Sync:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.getcwd())
        self.memory_dir = self.base_dir / "memory"
        self.extract_dir = self.memory_dir / "auto-extract"
        self.extract_dir.mkdir(parents=True, exist_ok=True)
        self.client = None

        if MEM0_AVAILABLE:
            config_path = Path.home() / ".mem0" / "config.json"
            if config_path.exists():
                try:
                    config = json.loads(config_path.read_text(encoding="utf-8"))
                    llm_provider = config.get("llm", {}).get("provider")
                    embedder_provider = config.get("embedder", {}).get("provider")
                    needs_ollama = llm_provider == "ollama" or embedder_provider == "ollama"
                    if needs_ollama and importlib.util.find_spec("ollama") is None:
                        print("Mem0 fallback: missing Python `ollama` package")
                    else:
                        self.client = Memory.from_config(config)
                        print("Mem0 initialized")
                except Exception as exc:
                    print(f"Mem0 init failed: {exc}")

    def extract_and_sync(self, content: str, metadata: Optional[Dict] = None) -> List[str]:
        facts = self._extract_facts(content)
        if not facts:
            return []
        if self.client:
          self._sync_to_mem0(facts, metadata)
        else:
          self._save_to_pending(facts, metadata)
        return facts

    def sync_pending(self):
        pending_file = self.extract_dir / ".mem0_pending"
        if not pending_file.exists():
            return
        pending = json.loads(pending_file.read_text(encoding="utf-8"))
        if not self.client:
            return
        for item in pending:
            if item.get("synced"):
                continue
            self.client.add(item["fact"], user_id=item.get("metadata", {}).get("user_id", "default"), metadata=item.get("metadata", {}))
            item["synced"] = True
        pending_file.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")

    def _extract_facts(self, content: str) -> List[str]:
        import re
        facts = []
        patterns = [
            r"([^。\n]+要[^。\n]+)",
            r"([^。\n]+不要[^。\n]+)",
            r"([^。\n]+是[^。\n]+)",
            r"([^。\n]+不是[^。\n]+)",
        ]
        for pattern in patterns:
            for match in re.findall(pattern, content):
                match = match.strip()
                if 5 < len(match) < 100 and match not in facts:
                    facts.append(match)
        return facts[:20]

    def _sync_to_mem0(self, facts: List[str], metadata: Optional[Dict] = None):
        user_id = metadata.get("user_id", "default") if metadata else "default"
        try:
            for fact in facts:
                self.client.add(fact, user_id=user_id, metadata=metadata or {})
        except Exception:
            self._save_to_pending(facts, metadata)

    def _save_to_pending(self, facts: List[str], metadata: Optional[Dict] = None):
        pending_file = self.extract_dir / ".mem0_pending"
        pending = []
        if pending_file.exists():
            pending = json.loads(pending_file.read_text(encoding="utf-8"))
        for fact in facts:
            pending.append({
                "fact": fact,
                "metadata": metadata or {},
                "created_at": datetime.now().isoformat(),
                "synced": False,
            })
        pending_file.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
