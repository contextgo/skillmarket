#!/usr/bin/env python3

import argparse
import hashlib
import json
import re
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional

API_ADD_URL = "https://api.supermemory.ai/v3/documents"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("paths", nargs="*")
    return parser.parse_args()


def key_candidates(workspace: Path) -> List[Path]:
    memory_dir = workspace / "memory"
    return [
        memory_dir / "auto-extract" / ".supermemory_key",
        memory_dir / "supermemory" / ".supermemory_key",
        memory_dir / "supermemory" / "config",
    ]


def read_api_key(workspace: Path) -> str:
    for candidate in key_candidates(workspace):
        if not candidate.exists():
            continue
        raw = candidate.read_text(encoding="utf-8", errors="ignore").strip()
        match = re.search(r"SUPERMEMORY_API_KEY=\"?([^\"\n]+)\"?", raw)
        if match:
            return match.group(1).strip()
        if raw:
            return raw.splitlines()[-1].strip()
    return ""


def curated_file(workspace: Path) -> Optional[Path]:
    root = workspace / "MEMORY.md"
    memory = workspace / "memory" / "MEMORY.md"
    if root.exists():
        return root
    if memory.exists():
        return memory
    return None


def default_targets(workspace: Path) -> List[Path]:
    memory_dir = workspace / "memory"
    result: List[Path] = [memory_dir / "SESSION-STATE.md"]
    curated = curated_file(workspace)
    if curated is not None:
        result.append(curated)
    daily = memory_dir / f"{datetime.now().strftime('%Y-%m-%d')}.md"
    if daily.exists():
        result.append(daily)
    return result


def load_state(state_file: Path) -> Dict:
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"files": {}}


def save_state(state_file: Path, state: Dict):
    state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def add_document(content: str, api_key: str, metadata: Optional[Dict] = None) -> Dict:
    payload = {"content": content}
    if metadata:
        payload["metadata"] = metadata
    req = urllib.request.Request(
        API_ADD_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def hash_text(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def sync_file(workspace: Path, path: Path, api_key: str, state: Dict) -> bool:
    if not path.exists() or not path.is_file():
        return False
    content = path.read_text(encoding="utf-8", errors="ignore").strip()
    if len(content) < 10:
        return False
    digest = hash_text(content)
    key = str(path)
    if state["files"].get(key) == digest:
        return False
    try:
        source = path.relative_to(workspace).as_posix()
    except Exception:
        source = str(path)
    add_document(content, api_key, {"source": source, "type": "workspace-memory", "synced_at": datetime.now().isoformat()})
    state["files"][key] = digest
    return True


def main() -> int:
    args = parse_args()
    workspace = Path(args.workspace).expanduser().resolve()
    memory_dir = workspace / "memory"
    auto_dir = memory_dir / "auto-extract"
    auto_dir.mkdir(parents=True, exist_ok=True)
    state_file = auto_dir / ".supermemory_state.json"
    log_file = auto_dir / "supermemory.log"

    def log(msg: str):
        with open(log_file, "a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

    api_key = read_api_key(workspace)
    if not api_key:
        log("skip: missing supermemory key")
        return 0

    state = load_state(state_file)
    changed = 0
    targets = [Path(p).expanduser().resolve() for p in args.paths] if args.paths else default_targets(workspace)
    try:
        for target in targets:
            changed += int(sync_file(workspace, target, api_key, state))
    except urllib.error.URLError as exc:
        log(f"sync failed: {exc}")
        return 1
    except Exception as exc:
        log(f"sync failed: {exc}")
        return 1

    save_state(state_file, state)
    log(f"sync complete: changed={changed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
