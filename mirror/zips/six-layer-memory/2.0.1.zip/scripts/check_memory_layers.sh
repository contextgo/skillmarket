#!/bin/bash

set -euo pipefail

BASE_DIR="${1:-$PWD}"
MEMORY_DIR="$BASE_DIR/memory"
SESSION_FILE="$MEMORY_DIR/SESSION-STATE.md"
CURATED_FILE="$BASE_DIR/MEMORY.md"
[ ! -f "$CURATED_FILE" ] && [ -f "$MEMORY_DIR/MEMORY.md" ] && CURATED_FILE="$MEMORY_DIR/MEMORY.md"
WARM_SYNC_SCRIPT="$MEMORY_DIR/lancedb_sync.py"
[ ! -f "$WARM_SYNC_SCRIPT" ] && [ -f "$MEMORY_DIR/knowledge-base/import_transcripts_to_lancedb.py" ] && WARM_SYNC_SCRIPT="$MEMORY_DIR/knowledge-base/import_transcripts_to_lancedb.py"

echo "Six-Layer Memory Check"
echo ""

if [ -f "$SESSION_FILE" ]; then
  echo "HOT: OK ($SESSION_FILE)"
else
  echo "HOT: MISSING ($SESSION_FILE)"
fi

TODAY="$(date +%Y-%m-%d)"
if [ -f "$MEMORY_DIR/$TODAY.md" ]; then
  echo "CURATED daily: OK ($MEMORY_DIR/$TODAY.md)"
else
  echo "CURATED daily: MISSING ($MEMORY_DIR/$TODAY.md)"
fi

if [ -f "$CURATED_FILE" ]; then
  echo "CURATED memory: OK ($CURATED_FILE)"
else
  echo "CURATED memory: MISSING"
fi

if [ -d "$MEMORY_DIR/knowledge-base/lancedb" ]; then
  echo "WARM: OK ($MEMORY_DIR/knowledge-base/lancedb)"
else
  echo "WARM: MISSING ($MEMORY_DIR/knowledge-base/lancedb)"
fi

if [ -d "$MEMORY_DIR/decisions" ]; then
  echo "COLD: OK ($MEMORY_DIR/decisions)"
else
  echo "COLD: MISSING ($MEMORY_DIR/decisions)"
fi

if [ -f "$MEMORY_DIR/auto-extract/.supermemory_key" ] || [ -f "$MEMORY_DIR/supermemory/.supermemory_key" ] || [ -f "$MEMORY_DIR/supermemory/config" ]; then
  echo "CLOUD: CONFIGURED"
else
  echo "CLOUD: OPTIONAL / NOT CONFIGURED"
fi

if [ -f "$MEMORY_DIR/auto-extract/mem0_sync.py" ]; then
  echo "AUTO: CONFIGURED"
else
  echo "AUTO: OPTIONAL / NOT CONFIGURED"
fi

if [ -f "$WARM_SYNC_SCRIPT" ]; then
  echo ""
  echo "WARM sync helper: $WARM_SYNC_SCRIPT"
fi
