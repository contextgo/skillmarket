#!/bin/bash

set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: install_workspace.sh <workspace>"
  exit 1
fi

WORKSPACE="$(cd "$1" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MEMORY_DIR="$WORKSPACE/memory"
AUTO_DIR="$MEMORY_DIR/auto-extract"
RAW_DIR="$MEMORY_DIR/knowledge-base/raw"
TERMS_DIR="$MEMORY_DIR/knowledge-base/terms"
LANCEDB_DIR="$MEMORY_DIR/knowledge-base/lancedb"
DECISIONS_DIR="$MEMORY_DIR/decisions"
AGENT_MEMORY_DIR="$MEMORY_DIR/agent-memory"
SESSION_FILE="$MEMORY_DIR/SESSION-STATE.md"
CURATED_FILE="$WORKSPACE/MEMORY.md"
TODAY_LOG="$MEMORY_DIR/$(date +%Y-%m-%d).md"

mkdir -p "$AUTO_DIR" "$RAW_DIR" "$TERMS_DIR" "$LANCEDB_DIR" "$DECISIONS_DIR" "$AGENT_MEMORY_DIR"

if [ ! -f "$SESSION_FILE" ]; then
  cat > "$SESSION_FILE" <<'EOF'
# SESSION-STATE.md - HOT Layer

EOF
fi

if [ ! -f "$CURATED_FILE" ]; then
  cat > "$CURATED_FILE" <<'EOF'
# MEMORY.md

## Durable Facts

EOF
fi

if [ ! -f "$TODAY_LOG" ]; then
  cat > "$TODAY_LOG" <<EOF
# $(date +%Y-%m-%d) 日志

## 自动维护

## 对话记录

## 待办
EOF
fi

cp "$SCRIPT_DIR/auto_memory_6layer.py" "$MEMORY_DIR/auto_memory_6layer.py"
cp "$SCRIPT_DIR/supermemory_sync.py" "$AUTO_DIR/supermemory_sync.py"
cp "$SCRIPT_DIR/mem0_sync.py" "$AUTO_DIR/mem0_sync.py"
cp "$SCRIPT_DIR/memory_writer.py" "$MEMORY_DIR/memory_writer.py"
cp "$SCRIPT_DIR/check_memory_layers.sh" "$MEMORY_DIR/check_memory_layers.sh"

chmod 755 \
  "$MEMORY_DIR/auto_memory_6layer.py" \
  "$AUTO_DIR/supermemory_sync.py" \
  "$AUTO_DIR/mem0_sync.py" \
  "$MEMORY_DIR/check_memory_layers.sh"

chmod 644 "$MEMORY_DIR/memory_writer.py"
chmod 600 "$SESSION_FILE" "$CURATED_FILE"

echo "Installed proactive six-layer memory into: $WORKSPACE"
echo ""
echo "Suggested cron:"
echo "59 23 * * * /usr/bin/python3 $MEMORY_DIR/auto_memory_6layer.py --workspace $WORKSPACE --daily --source wal-daily"
echo "0 6 * * * /usr/bin/python3 $MEMORY_DIR/auto_memory_6layer.py --workspace $WORKSPACE --daily --source memory-daily-sync"
echo "*/30 * * * * /usr/bin/python3 $MEMORY_DIR/auto_memory_6layer.py --workspace $WORKSPACE --source memory-sync"
