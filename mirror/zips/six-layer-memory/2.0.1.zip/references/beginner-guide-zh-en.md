# Six-Layer Memory 新手配置手册 | Beginner Setup Guide

## 目录 | Table of Contents

1. 这是什么 | What this is
2. 六层分别做什么 | What each layer does
3. 目录结构 | Directory layout
4. 安装前准备 | Prerequisites
5. 安装步骤 | Installation
6. AUTO 层配置 | AUTO configuration
7. CLOUD 层配置 | CLOUD configuration
8. 定时任务配置 | Cron setup
9. 关机前处理 | Safe shutdown
10. 检查是否工作 | Validation
11. 常见问题 | Common problems
12. 给小白的推荐方案 | Recommended beginner path

## 1. 这是什么 | What This Is

### 中文

六层记忆系统是一套给 OpenClaw / Codex Agent 用的长期记忆架构。

它的目标不是让模型凭空记住所有聊天，而是把重要信息分层存储，让 Agent 在重启、关机、会话结束之后，仍然可以尽量保留关键上下文。

六层分别是：

- HOT：当前会话状态
- WARM：可检索知识
- COLD：结构化决策
- CURATED：长期保留记忆
- CLOUD：云端同步
- AUTO：自动抽取事实

一句话理解：

- 模型会忘
- 文件、向量库、Mem0、SuperMemory 不会随着聊天窗口关闭而消失
- 六层记忆的意义，就是把容易丢失的聊天内容变成可维护的数据

### English

The six-layer memory system is a long-term memory architecture for OpenClaw / Codex agents.

Its goal is not to make the model magically remember every chat forever. Instead, it stores important information in layers so the agent can preserve useful context across restarts, shutdowns, and new sessions.

The six layers are:

- HOT: current session state
- WARM: searchable knowledge
- COLD: structured decisions
- CURATED: durable long-term memory
- CLOUD: cloud sync
- AUTO: automatic fact extraction

Simple summary:

- the model forgets
- files, vector stores, Mem0, and SuperMemory do not disappear with the chat window
- six-layer memory turns fragile chat context into maintainable data

---

## 2. 六层分别做什么 | What Each Layer Does

### 中文

### HOT 层

文件：

- `memory/SESSION-STATE.md`

作用：

- 保存当前会话最关键的上下文
- 例如用户刚刚做出的决定、最新偏好、当前任务状态

特点：

- 写入频率高
- 内容短
- 只写最关键的信息
- 不要被“系统正常运行”这类假状态覆盖

### WARM 层

常见位置：

- `memory/knowledge-base/lancedb/`
- 或某些工作区的 `content_kb/structured/`

作用：

- 负责搜索和语义召回
- 适合放知识片段、转录、素材、结构化记录

### COLD 层

文件夹：

- `memory/decisions/`

作用：

- 记录“为什么这样做”
- 适合存架构取舍、业务决策、策略变化、关键判断

### CURATED 层

文件：

- `MEMORY.md`
- `memory/YYYY-MM-DD.md`

作用：

- `MEMORY.md`：长期稳定的事实
- `YYYY-MM-DD.md`：每日记录

最佳实践：

- `MEMORY.md` 只放长期有价值的内容
- 日志、版本号、偶发故障、一次性输出，不要全部塞进 `MEMORY.md`

### CLOUD 层

常见配置：

- `memory/auto-extract/.supermemory_key`
- 或 `memory/supermemory/config`

作用：

- 同步重要记忆到 SuperMemory
- 用于跨设备、跨会话、跨环境召回

### AUTO 层

常见文件：

- `memory/auto-extract/mem0_sync.py`
- `.mem0_pending`

作用：

- 自动从内容里抽取“值得保留的事实”
- 写入 Mem0
- 如果当下不可写，就先进待处理队列

### English

### HOT

File:

- `memory/SESSION-STATE.md`

Purpose:

- stores the most important current session context
- for example recent decisions, preference changes, and task state

### WARM

Common locations:

- `memory/knowledge-base/lancedb/`
- or `content_kb/structured/` in some workspaces

Purpose:

- semantic search and recall
- useful for transcripts, knowledge chunks, and structured content

### COLD

Folder:

- `memory/decisions/`

Purpose:

- records why something was decided
- useful for architecture choices, strategy changes, and durable reasoning

### CURATED

Files:

- `MEMORY.md`
- `memory/YYYY-MM-DD.md`

Purpose:

- `MEMORY.md` stores durable long-term facts
- daily logs store chronological notes

### CLOUD

Common config:

- `memory/auto-extract/.supermemory_key`
- or `memory/supermemory/config`

Purpose:

- syncs selected memory to SuperMemory
- useful for cross-device and cross-session recall

### AUTO

Common files:

- `memory/auto-extract/mem0_sync.py`
- `.mem0_pending`

Purpose:

- extracts durable facts automatically
- writes them to Mem0
- or queues them when immediate sync is unavailable

---

## 3. 目录结构 | Directory Layout

```text
workspace/
├── MEMORY.md
└── memory/
    ├── SESSION-STATE.md
    ├── 2026-04-16.md
    ├── decisions/
    ├── knowledge-base/
    │   ├── raw/
    │   ├── terms/
    │   └── lancedb/
    └── auto-extract/
        ├── mem0_sync.py
        ├── supermemory_sync.py
        ├── .mem0_pending
        └── .supermemory_key
```

---

## 4. 安装前准备 | Prerequisites

### 中文

建议至少准备好这些：

- 已安装 OpenClaw / Codex
- 有明确的 workspace
- Python 3
- 如果要用 AUTO：
  - `mem0ai`
  - 一个本地或远程 LLM / embedding backend
- 如果要用 CLOUD：
  - SuperMemory API Key

本地 AUTO 推荐优先级：

1. LM Studio
2. Ollama

推荐 LM Studio 的原因：

- 对小白更稳定
- 如果本地已经有聊天模型和 embedding 模型，不需要额外再跑一套 Ollama

### English

Recommended prerequisites:

- OpenClaw / Codex already installed
- a clear workspace path
- Python 3
- if using AUTO:
  - `mem0ai`
  - a working local or remote LLM / embedding backend
- if using CLOUD:
  - a SuperMemory API key

Recommended local AUTO order:

1. LM Studio
2. Ollama

---

## 5. 安装步骤 | Installation

### 中文

如果使用 skill 包里的安装脚本：

```bash
bash scripts/install_workspace.sh /你的/workspace
```

它会自动：

- 创建 `memory/` 目录结构
- 创建 `memory/SESSION-STATE.md`
- 创建 `MEMORY.md`
- 创建当日日志
- 复制主动维护脚本
- 复制 AUTO / CLOUD / 检查脚本

安装完成后，先做检查：

```bash
bash memory/check_memory_layers.sh /你的/workspace
```

### English

If you use the installer script:

```bash
bash scripts/install_workspace.sh /your/workspace
```

It will:

- create the `memory/` directory structure
- create `memory/SESSION-STATE.md`
- create `MEMORY.md`
- create today’s daily log
- copy the proactive maintenance script
- copy AUTO / CLOUD / validation scripts

Then validate:

```bash
bash memory/check_memory_layers.sh /your/workspace
```

---

## 6. AUTO 层配置 | AUTO Configuration

### 中文

AUTO 层依赖 `~/.mem0/config.json`。

推荐 LM Studio 版本配置思路：

- LLM provider：`lmstudio`
- Embedder provider：`lmstudio`
- 聊天模型指向本地 chat model
- embedding 模型指向本地 embedding model

示例：

```json
{
  "version": "v1.1",
  "llm": {
    "provider": "lmstudio",
    "config": {
      "model": "google/gemma-4-e4b",
      "temperature": 0.1,
      "lmstudio_base_url": "http://127.0.0.1:1234/v1",
      "api_key": "lm-studio",
      "lmstudio_response_format": { "type": "text" }
    }
  },
  "embedder": {
    "provider": "lmstudio",
    "config": {
      "model": "text-embedding-nomic-embed-text-v1.5",
      "lmstudio_base_url": "http://127.0.0.1:1234/v1",
      "api_key": "lm-studio",
      "embedding_dims": 768
    }
  },
  "vector_store": {
    "provider": "chroma",
    "config": {
      "path": "/Users/yourname/.mem0/chroma"
    }
  }
}
```

注意：

- 如果你配置的是 Ollama，但 Ollama 没启动，AUTO 会失败或降级
- 如果 embedding 模型不存在，AUTO 也会失败
- 如果 backend 临时不可用，事实会先进入 `.mem0_pending`

### English

AUTO depends on `~/.mem0/config.json`.

Recommended LM Studio config:

- LLM provider: `lmstudio`
- Embedder provider: `lmstudio`
- chat model points to a local chat model
- embedding model points to a local embedding model

If you use Ollama instead, make sure:

- the Ollama server is actually running
- both the chat model and embedding model exist locally

---

## 7. CLOUD 层配置 | CLOUD Configuration

### 中文

如果开启 SuperMemory，在 workspace 中放 key 文件：

- `memory/auto-extract/.supermemory_key`

内容支持两种格式：

```text
sm_xxx_your_key
```

或：

```bash
SUPERMEMORY_API_KEY="sm_xxx_your_key"
```

主动维护器通常会同步：

- `memory/SESSION-STATE.md`
- `MEMORY.md`
- 当日日志
- `.cloud_sync_pending` 中的待同步内容

### English

To enable SuperMemory, place a key file in:

- `memory/auto-extract/.supermemory_key`

Supported formats:

```text
sm_xxx_your_key
```

or:

```bash
SUPERMEMORY_API_KEY="sm_xxx_your_key"
```

The proactive runner usually syncs:

- `memory/SESSION-STATE.md`
- `MEMORY.md`
- today’s daily log
- queued `.cloud_sync_pending` items

---

## 8. 定时任务配置 | Cron Setup

### 中文

推荐最少 3 条：

```cron
59 23 * * * ~/.openclaw/scripts/wal-daily.sh >> /tmp/wal_daily.log 2>&1
0 6 * * * ~/.openclaw/scripts/memory-daily-sync.sh >> /tmp/memory_sync.log 2>&1
*/30 * * * * ~/.openclaw/scripts/memory_sync.sh >> /tmp/memory_sync_hourly.log 2>&1
```

含义：

- 每 30 分钟做一次主动维护
- 早上做一次每日维护
- 晚上做一次日终维护

### English

Recommended minimum cron:

```cron
59 23 * * * ~/.openclaw/scripts/wal-daily.sh >> /tmp/wal_daily.log 2>&1
0 6 * * * ~/.openclaw/scripts/memory-daily-sync.sh >> /tmp/memory_sync.log 2>&1
*/30 * * * * ~/.openclaw/scripts/memory_sync.sh >> /tmp/memory_sync_hourly.log 2>&1
```

Meaning:

- every 30 minutes: proactive maintenance
- morning: daily maintenance
- night: end-of-day maintenance

---

## 9. 关机前处理 | Safe Shutdown

### 中文

最稳的方式：

```bash
~/.openclaw/scripts/openclaw-safe-shutdown.sh
```

它会在关机前主动刷一遍所有工作区的记忆层。

### English

Safest option:

```bash
~/.openclaw/scripts/openclaw-safe-shutdown.sh
```

It runs one final memory flush before shutdown.

---

## 10. 如何检查有没有工作 | Validation

### 中文

先看结构：

```bash
bash memory/check_memory_layers.sh /你的/workspace
```

再看日志：

```bash
tail -f /tmp/memory_6layer_workspace.log
tail -f /tmp/memory_sync_hourly.log
tail -f memory/auto-extract/supermemory.log
```

### English

Check structure:

```bash
bash memory/check_memory_layers.sh /your/workspace
```

Check logs:

```bash
tail -f /tmp/memory_6layer_workspace.log
tail -f /tmp/memory_sync_hourly.log
tail -f memory/auto-extract/supermemory.log
```

---

## 11. 常见问题 | Common Problems

### 中文

### 问题 1：重启后还是像失忆

原因：

- 关键内容还没写盘
- 强制断电
- 重要信息只在聊天里，没有落到六层记忆

### 问题 2：AUTO 不工作

原因：

- `mem0ai` 没装
- backend 没跑
- 模型配置错

### 问题 3：CLOUD 同步失败

原因：

- key 错
- DNS / 网络不通
- 外网被限制

### English

### Problem 1: It still feels forgetful after restart

Cause:

- important content was not flushed yet
- forced shutdown
- important information stayed only in chat

### Problem 2: AUTO does not work

Cause:

- `mem0ai` missing
- backend not running
- wrong model configuration

### Problem 3: CLOUD sync fails

Cause:

- wrong key
- DNS / network issues
- outbound network blocked

---

## 12. 给小白的推荐方案 | Recommended Beginner Path

### 中文

如果你第一次搭，建议：

1. 先确保 HOT / COLD / CURATED 能工作
2. 再接 WARM
3. AUTO 优先选 LM Studio
4. CLOUD 最后再开
5. 先保证定时任务真的在跑

### English

If this is your first setup:

1. First make HOT / COLD / CURATED stable
2. Then add WARM
3. Prefer LM Studio for AUTO
4. Enable CLOUD last
5. Make sure scheduled maintenance is actually running

---

## 13. 一句话总结 | One-Sentence Summary

### 中文

六层记忆不是让模型自己永远不忘，而是把重要信息主动写进不同层，让 Agent 重启后还能继续工作。

### English

Six-layer memory does not make the model remember forever by itself; it proactively writes important information into layers so the agent can continue working after restarts.
