# six-layer-memory 2.0.1 Release Notes

## 中文版

### 更新说明

这次更新主要提升了主动六层记忆系统的可靠性和可发布性。整体仍然是同一套六层记忆模型，但安装流程、打包结构、多工作区维护方式都更清晰，普通用户更容易上手。

- 打包结构：本地目录名和线上技能名统一为 `six-layer-memory`
- 安装流程：明确为“按 workspace 安装”，避免混用主工作区和子 Agent 工作区
- 稳定性：安装脚本、主动维护脚本、Mem0 同步、SuperMemory 同步都做了公开版整理
- 文档说明：技能描述从“个人私有部署”改成“适用于 OpenClaw/Codex 的通用主动记忆系统”

### 简短介绍

把六层记忆从“被动文件结构”升级成“主动维护系统”。这个版本重点解决多 Agent 场景下的记忆持久化、定时维护、可选云同步、可选自动事实抽取，以及关机前安全刷盘。

### 详细介绍

`six-layer-memory 2.0` 不再只是创建几个文件夹，而是提供一套可运行的主动六层记忆框架。它包含安装脚本、主动维护脚本，以及对 HOT / WARM / COLD / CURATED / CLOUD / AUTO 六层的统一维护逻辑。它适合 OpenClaw / Codex 多工作区、多 Agent 场景，目标是让记忆在重启、关机、长期运行后依然尽量稳定可用。

## English

### Changelog

Improved reliability and publishability for proactive six-layer memory. This release keeps the same six-layer model but tightens installation, packaging, and multi-workspace maintenance so users can adopt it with less manual cleanup.

- Packaging: aligned the local skill folder and published skill identity under `six-layer-memory`
- Installation: clarified the per-workspace bootstrap flow and bundled script layout
- Reliability: validated installer, maintenance runner, Mem0 sync, and SuperMemory sync scripts as a reusable public package
- Documentation: tightened the skill description to focus on proactive memory maintenance instead of one personal deployment

### Short Copy

Turn six-layer memory into a proactive, per-workspace system. This version focuses on durable memory across restarts, optional SuperMemory sync, optional Mem0 fact extraction, and safer maintenance workflows for multi-agent OpenClaw setups.

### Longer Release Copy

`six-layer-memory 2.0` turns the original six-layer idea into a proactive workspace memory system. Instead of relying on passive file structure alone, it ships a reusable installer plus maintenance scripts for HOT, WARM, COLD, CURATED, CLOUD, and AUTO layers. It is designed for OpenClaw/Codex workspaces that need durable memory across restarts, per-agent isolation, optional SuperMemory cloud recall, and optional Mem0-based fact extraction.
