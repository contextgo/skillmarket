---
name: byteplan-excel
description: 根据已有的分析数据生成 Excel 报告。只输出结构化数据表格，不包含说明文字。需要先使用 byteplan-analysis skill 完成数据分析。
---

# BytePlan Excel 报告 Skill

## 概述

此 Skill 根据已有的分析数据生成 Excel 报告，**只输出结构化数据表格**：

1. **读取数据** - 从工作目录读取分析结果数据
2. **转换格式** - 将数据转换为 Excel 表格格式
3. **生成 Excel** - 使用 xlsx 库创建工作簿

**设计原则**：简洁、结构化、纯数据展示。

**前置条件**：必须先使用 [byteplan-analysis](../byteplan-analysis/SKILL.md) skill 完成数据分析。

---

## 输出规范

### 1. 文件命名

```
{分析主题}报告.xlsx
```

### 2. Sheet 结构

每个分析维度生成一个独立的 Sheet：

| Sheet 名称 | 内容 | 列结构 |
|-----------|------|--------|
| TOP3贡献要素 | 贡献最大的三个要素 | 排名、维度、要素、金额、贡献占比 |
| 费用类别贡献 | 按费用类别的贡献分析 | 费用类别、金额、贡献占比 |
| 资产类别贡献 | 按资产类别的贡献分析 | 资产类别、金额、贡献占比 |
| 分摊步骤贡献 | 按分摊步骤的贡献分析 | 分摊步骤、金额、贡献占比 |
| ... | 根据实际分析维度动态生成 | ... |

### 3. 数据格式

| 字段类型 | 格式 | 示例 |
|---------|------|------|
| 金额 | 数字，保留2位小数 | 16898.63 |
| 占比 | 数字，保留3位小数 | 0.449 |
| 排名 | 整数 | 1, 2, 3 |
| 名称 | 字符串 | 研发费用 |

### 4. 列宽设置

```javascript
// 根据内容自动设置列宽
ws["!cols"] = [
  { wch: 40 },  // 名称列
  { wch: 15 },  // 金额列
  { wch: 12 }   // 占比列
];
```

---

## 数据格式

### 输入数据结构（excel_data.json）

```json
{
  "sheets": [
    {
      "name": "TOP3贡献要素",
      "columns": ["排名", "维度", "要素", "金额", "贡献占比"],
      "data": [
        [1, "分摊步骤", "其他费用分摊", 33396.69, 0.887],
        [2, "费用类别", "研发费用", 16898.63, 0.449],
        [3, "资产类别", "固定资产-施工设备-卷扬机、升降机", 15636.13, 0.579]
      ]
    },
    {
      "name": "费用类别贡献",
      "columns": ["费用类别", "金额", "贡献占比"],
      "data": [
        ["研发费用", 16898.63, 0.449],
        ["销售费用", 13363.98, 0.355],
        ["管理费用", 6418.02, 0.170],
        ["生产成本", 966.12, 0.026]
      ]
    }
  ]
}
```

---

## 使用方法

### 方式一：命令行

```bash
# 使用默认数据文件 (excel_data.json)
cd skills/byteplan-excel
pnpm run generate -o report.xlsx

# 指定数据文件
pnpm run generate -o report.xlsx -d /path/to/data.json
```

### 方式二：Node.js 调用

```javascript
import { generateExcel } from './scripts/generate_excel.js';

generateExcel('report.xlsx', 'data.json');
```

### 方式三：直接传入数据

```javascript
import { generateExcelFromData } from './scripts/generate_excel.js';

const data = {
  sheets: [
    {
      name: "费用类别贡献",
      columns: ["费用类别", "金额", "贡献占比"],
      data: [
        ["研发费用", 16898.63, 0.449],
        ["销售费用", 13363.98, 0.355]
      ]
    }
  ]
};

generateExcelFromData('report.xlsx', data);
```

---

## 完整示例

### 1. 准备数据文件

```bash
# 从分析结果生成数据文件
# 确保 excel_data.json 包含所有必要字段
```

### 2. 生成 Excel

```bash
cd skills/byteplan-excel
pnpm run generate -o 边际分析报告.xlsx
```

### 3. 打开查看

```bash
open 边际分析报告.xlsx
```

---

## ⚠️ 重要规则

### 文件输出位置

**所有生成的 Excel 文件必须放在 BytePlan 工作目录下：**

```
~/.byteplan/workspaces/{主题}_{时间戳}/{主题}报告.xlsx
```

**❌ 错误位置：**
- `~/.openclaw/workspace/`
- `/tmp/`
- 当前任意目录

**✅ 正确位置：**
- `~/.byteplan/workspaces/边际分析_20260331_230800/边际分析报告.xlsx`

### 数据来源

Excel 数据必须来自 `byteplan-analysis` 的分析结果，不能凭空编造数据。

---

## 与其他 Skill 的关系

```
byteplan-analysis          ← 数据分析（必须先执行）
       ↓
   analysis_report.md
   analysisPlan.json
       ↓
byteplan-excel            ← 生成 Excel（读取分析结果）
       ↓
   xxx报告.xlsx
       ↓
byteplan-ppt              ← 生成 PPT（可选）
byteplan-word             ← 生成 Word（可选）
```

---

## 注意事项

- **只输出数据**：Excel 中只包含结构化数据表格，不包含说明文字、标题等
- **每个维度一个 Sheet**：不同分析维度分别放在独立的 Sheet
- **数据来源**：必须基于 byteplan-analysis 的分析结果
- **文件位置**：输出文件必须放在 BytePlan 工作目录
- **包管理器**：使用 pnpm 安装依赖