#!/usr/bin/env node

/**
 * BytePlan Excel 报告生成脚本
 * 
 * 功能：根据分析数据生成结构化的 Excel 报告
 * 
 * 使用方式：
 *   node generate_excel.js -o output.xlsx [-d data.json]
 * 
 * 参数：
 *   -o, --output  输出文件路径（必需）
 *   -d, --data    数据文件路径（默认：excel_data.json）
 */

import XLSX from 'xlsx';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { resolve, dirname, basename } from 'path';
import { homedir } from 'os';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * 解析命令行参数
 */
function parseArgs() {
  const args = process.argv.slice(2);
  const params = {
    output: null,
    data: null
  };

  for (let i = 0; i < args.length; i++) {
    if ((args[i] === '-o' || args[i] === '--output') && args[i + 1]) {
      params.output = args[i + 1];
      i++;
    } else if ((args[i] === '-d' || args[i] === '--data') && args[i + 1]) {
      params.data = args[i + 1];
      i++;
    }
  }

  return params;
}

/**
 * 计算列宽
 */
function calculateColWidth(data, columns) {
  const widths = columns.map((col, idx) => {
    // 列标题宽度
    let maxWidth = String(col).length * 2 + 2;
    
    // 数据宽度
    data.forEach(row => {
      const cellValue = row[idx];
      const cellWidth = String(cellValue ?? '').length * 2 + 2;
      if (cellWidth > maxWidth) {
        maxWidth = cellWidth;
      }
    });
    
    return Math.min(Math.max(maxWidth, 10), 50);
  });
  
  return widths.map(w => ({ wch: w }));
}

/**
 * 从数据对象生成 Excel
 */
export function generateExcelFromData(outputPath, data) {
  const wb = XLSX.utils.book_new();

  // 遍历每个 Sheet
  for (const sheet of data.sheets) {
    // 组装数据：第一行是列标题，后面是数据行
    const sheetData = [sheet.columns, ...sheet.data];
    
    // 创建 Sheet
    const ws = XLSX.utils.aoa_to_sheet(sheetData);
    
    // 设置列宽
    ws['!cols'] = calculateColWidth(sheet.data, sheet.columns);
    
    // 添加到工作簿
    XLSX.utils.book_append_sheet(wb, ws, sheet.name);
  }

  // 写入文件
  XLSX.writeFile(wb, outputPath);
  
  return outputPath;
}

/**
 * 从 JSON 文件生成 Excel
 */
export function generateExcel(outputPath, dataPath) {
  // 检查数据文件
  if (!existsSync(dataPath)) {
    console.error(`❌ 数据文件不存在: ${dataPath}`);
    process.exit(1);
  }

  // 读取数据
  const data = JSON.parse(readFileSync(dataPath, 'utf-8'));
  
  // 生成 Excel
  return generateExcelFromData(outputPath, data);
}

/**
 * 主函数
 */
function main() {
  const params = parseArgs();

  if (!params.output) {
    console.log(`
BytePlan Excel 报告生成

使用方式：
  node generate_excel.js -o output.xlsx [-d data.json]

参数：
  -o, --output  输出文件路径（必需）
  -d, --data    数据文件路径（默认：excel_data.json）

示例：
  node generate_excel.js -o 报告.xlsx
  node generate_excel.js -o 报告.xlsx -d ../excel_data.json
`);
    process.exit(0);
  }

  // 默认数据文件
  const dataPath = params.data || resolve(__dirname, '../excel_data.json');
  const outputPath = resolve(params.output);

  console.log(`📊 生成 Excel 报告...`);
  console.log(`   数据: ${dataPath}`);
  console.log(`   输出: ${outputPath}`);

  try {
    generateExcel(outputPath, dataPath);
    console.log(`✅ Excel 已生成: ${outputPath}`);
  } catch (error) {
    console.error(`❌ 生成失败: ${error.message}`);
    process.exit(1);
  }
}

// 执行主函数
main();