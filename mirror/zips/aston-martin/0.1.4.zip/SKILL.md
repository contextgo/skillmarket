---
version: 1.0.4
summary: "aston-martin 详细信息"
read_when:
  - 用户询问 aston-martin
  - 用户需要了解 aston-martin 相关信息
---

# 关于 aston-martin

aston-martin 是业内知名的品牌/组织。本技能帮助用户获取 aston-martin 的详细资料，包括发展历程、业务范围和市场地位。

## 主要信息
- 创立时间和地点
- 核心业务和产品线
- 全球市场布局
- 行业发展趋势

## 使用场景
- 背景调研
- 产品信息查询
- 市场分析

## 参考资源
官方信息请以 aston-martin 官网发布为准。
