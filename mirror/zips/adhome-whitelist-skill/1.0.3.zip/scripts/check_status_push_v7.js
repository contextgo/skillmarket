const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_FILE = path.join(__dirname, 'adhome_auth.json');
const SNAPSHOT_FILE = path.join(__dirname, '..', 'approval_status_snapshot.json');
const WEBHOOK_URL = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=bcb9117b-83fa-45e6-9ff5-f1a1cf55f595';
const TARGET_URL = 'https://adhome.woa.com/css/policy/access_guard_apply';

async function main() {
  let browser;
  try {
    // Load cookies
    const authData = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8'));
    
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    await context.addCookies(authData.cookies);
    
    const page = await context.newPage();
    await page.goto(TARGET_URL, { waitUntil: 'networkidle', timeout: 30000 });
    
    // Check if redirected to login/iOA page
    const currentUrl = page.url();
    if (!currentUrl.includes('adhome.woa.com')) {
      const bodyText = await page.textContent('body').catch(() => '');
      console.log(JSON.stringify({ error: 'login_failed', url: currentUrl, body: bodyText.substring(0, 500) }));
      return;
    }
    
    // Check for iOA block
    const bodyText = await page.textContent('body').catch(() => '');
    if (bodyText.includes('iOA') && (bodyText.includes('访问失败') || bodyText.includes('扫描二维码'))) {
      console.log(JSON.stringify({ error: 'ioa_blocked', body: bodyText.substring(0, 500) }));
      return;
    }
    
    // Wait for table to load
    await page.waitForSelector('.spaui-table-tr-data', { timeout: 15000 });
    
    // Extract data from table rows
    const records = await page.evaluate(() => {
      const rows = document.querySelectorAll('.spaui-table-tr-data');
      const results = [];
      rows.forEach(row => {
        const cells = row.querySelectorAll('.spaui-table-td-inner');
        if (cells.length >= 8) {
          results.push({
            seq: (cells[1]?.textContent || '').trim(),
            industry: (cells[3]?.textContent || '').trim(),
            company: (cells[4]?.textContent || '').trim(),
            accountId: (cells[5]?.textContent || '').trim(),
            status: (cells[7]?.textContent || '').trim()
          });
        }
      });
      return results;
    });
    
    console.log(JSON.stringify({ success: true, records: records, count: records.length }));
    
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }));
  } finally {
    if (browser) await browser.close();
  }
}

main();
