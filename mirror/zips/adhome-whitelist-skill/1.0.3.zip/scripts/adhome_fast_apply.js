/**
 * ADHome 加白申请 - 高速自动化脚本 (Playwright 原生版)
 * 
 * 直接使用 Playwright API，不经过 agent-browser 中间层
 * 目标：10-20秒完成整个表单填写
 * 
 * 使用：
 *   node adhome_fast_apply.js --config apply_data.json [--dry-run] [--headed]
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// ============================================================
// 读取参数
// ============================================================
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');
const isHeaded = args.includes('--headed');
const configIdx = args.indexOf('--config');
const configFile = configIdx >= 0 ? args[configIdx + 1] : null;

if (!configFile) {
  console.log(`
╔═══════════════════════════════════════════════════╗
║  ADHome 加白申请自动化工具                         ║
╠═══════════════════════════════════════════════════╣
║  使用方法:                                         ║
║    node adhome_fast_apply.js --config data.json   ║
║                                                    ║
║  可选参数:                                         ║
║    --dry-run   只填写不提交                        ║
║    --headed    显示浏览器窗口（调试用）              ║
╚═══════════════════════════════════════════════════╝
  `);
  process.exit(0);
}

// 加载配置
const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));
const authFile = path.join(__dirname, 'adhome_auth.json');
const userConfigFile = path.join(__dirname, 'user_config.json');

// 从 user_config.json 读取用户级配置（webhook 等）
try {
  const userConfig = JSON.parse(fs.readFileSync(userConfigFile, 'utf-8'));
  if (!config.notify_webhook && userConfig.notify_webhook) {
    config.notify_webhook = userConfig.notify_webhook;
  }
} catch(e) {
  // user_config.json 不存在时静默跳过
}

// 记录最终提交状态（用于通知）
let finalStatus = '⏸️待人工确认';

function log(msg) {
  console.log(`[${new Date().toLocaleTimeString()}] ${msg}`);
}

// ============================================================
// 工具函数：数据范围 Tab 切换
// 规则：先查「我的数据范围」，没数据就切「全部」
// ============================================================
async function switchToTabWithData(page) {
  // 先检查当前 tab（我的数据范围）有没有数据
  const hasData = await page.evaluate(() => {
    const rows = document.querySelectorAll('table tbody tr, .table-row, [class*="table-body"] tr');
    const emptyHint = document.querySelector('.empty-tip, .no-data, [class*="empty"]');
    return rows.length > 0 && !emptyHint;
  }).catch(() => true); // 出错默认有数据，不阻断

  if (!hasData) {
    log('  ↪ 「我的数据范围」无数据，切换到「全部」');
    await page.evaluate(() => {
      const tabs = document.querySelectorAll('.tab-item, [class*="tab"], [role="tab"]');
      for (const tab of tabs) {
        if (tab.textContent.trim().includes('全部')) { tab.click(); return; }
      }
    });
    await page.waitForTimeout(800);
  }
}

async function uploadFiles(page, sectionSelector, files, label) {
  const validFiles = (files || []).filter(f => fs.existsSync(f));
  if (validFiles.length === 0) return;

  const uploadedBefore = await page.$$eval(
    `${sectionSelector} .file-uploaded-file-name`,
    els => els.length
  ).catch(() => 0);

  const directInput = await page.$(`${sectionSelector} input[type="file"]`);
  if (directInput) {
    await directInput.setInputFiles(validFiles);
  } else {
    const uploadButton = await page.$(`${sectionSelector} button`);
    if (!uploadButton) {
      log(`⚠️ 未找到${label}上传按钮`);
      return;
    }

    const [chooser] = await Promise.all([
      page.waitForEvent('filechooser', { timeout: 5000 }),
      uploadButton.click()
    ]);
    await chooser.setFiles(validFiles);
  }

  await Promise.race([
    page.waitForFunction(
      ({ selector, expected }) => document.querySelectorAll(`${selector} .file-uploaded-file-name`).length >= expected,
      { selector: sectionSelector, expected: uploadedBefore + validFiles.length },
      { timeout: 20000 }
    ),
    page.waitForTimeout(6000)
  ]).catch(() => {});

  const uploadedAfter = await page.$$eval(
    `${sectionSelector} .file-uploaded-file-name`,
    els => els.length
  ).catch(() => 0);

  if (uploadedAfter > uploadedBefore) {
    log(`✅ 已上传 ${uploadedAfter - uploadedBefore} 个${label}`);
  } else {
    log(`⚠️ ${label}上传后未检测到文件列表变化，请人工复核`);
  }
}

// ============================================================
// 主流程
// ============================================================
(async () => {
  const startTime = Date.now();
  log('🚀 ADHome 加白自动化启动');
  log(`主体: ${config.mdm_name}`);
  log(`账户: ${config.account_ids.join(', ')}`);
  
  // 1. 加载 auth state
  if (!fs.existsSync(authFile)) {
    console.error('❌ 登录态文件不存在: ' + authFile);
    process.exit(1);
  }
  const authState = JSON.parse(fs.readFileSync(authFile, 'utf8'));
  
  // 2. 启动浏览器
  log('🌐 启动浏览器...');
  const browser = await chromium.launch({ 
    headless: !isHeaded,
    args: ['--no-sandbox']
  });
  
  const context = await browser.newContext({
    storageState: authState,
    viewport: { width: 1440, height: 900 },
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  });
  
  const page = await context.newPage();
  
  try {
    // ========= 开户行业预校验（可选，有 actual_industry 字段时跳过） =========
    if (config.account_ids.length > 0 && !config.actual_industry) {
      log('🔍 开户行业预校验...');
      try {
        await page.goto('https://adhome.woa.com/css/policy/channel_workbench', {
          waitUntil: 'domcontentloaded', timeout: 12000
        });
        // 智能等待：等待表格出现或超时
        await Promise.race([
          page.waitForSelector('table tbody tr, .table-row', { timeout: 2000 }),
          page.waitForTimeout(500)
        ]).catch(() => {});

        // 数据范围 tab 切换
        await switchToTabWithData(page);

        // 搜索第一个 UID 快速确认行业
        const firstUid = config.account_ids[0];
        const searchInput = await page.$('input[placeholder*="搜索"], input[placeholder*="账户"], input[placeholder*="ID"], .search-input input');
        if (searchInput) {
          await searchInput.fill(firstUid);
          await searchInput.press('Enter');
          // 智能等待：等待表格加载或超时
          await Promise.race([
            page.waitForSelector('table tbody tr', { timeout: 1500 }),
            page.waitForTimeout(800)
          ]).catch(() => {});

          // 如果「我的数据范围」搜不到,切全部再搜
          const found = await page.evaluate(() => {
            const rows = document.querySelectorAll('table tbody tr');
            return rows.length > 0;
          });
          if (!found) {
            log('  ↪ 搜索无结果，切「全部」重试');
            await page.evaluate(() => {
              const tabs = document.querySelectorAll('.tab-item, [class*="tab"], [role="tab"]');
              for (const tab of tabs) {
                if (tab.textContent.trim().includes('全部')) { tab.click(); return; }
              }
            });
            await page.waitForTimeout(300);
            await searchInput.fill(firstUid);
            await searchInput.press('Enter');
            await Promise.race([
              page.waitForSelector('table tbody tr', { timeout: 1500 }),
              page.waitForTimeout(800)
            ]).catch(() => {});
          }

          // 尝试读取开户行业列
          const detectedIndustry = await page.evaluate(() => {
            // 找表头中「开户行业」的列索引
            const headers = document.querySelectorAll('table thead th, .table-header th');
            let colIdx = -1;
            headers.forEach((h, i) => { if (h.textContent.includes('开户行业')) colIdx = i; });
            if (colIdx < 0) return null;
            const firstRow = document.querySelector('table tbody tr');
            if (!firstRow) return null;
            const cells = firstRow.querySelectorAll('td');
            return cells[colIdx] ? cells[colIdx].textContent.trim() : null;
          });

          if (detectedIndustry) {
            log(`  ✅ 检测到开户行业: ${detectedIndustry}`);
            if (config.industry && detectedIndustry !== config.industry) {
              log(`  ⚠️  开户行业「${detectedIndustry}」≠ 填写行业「${config.industry}」，请注意！`);
            }
          } else {
            log('  ℹ️  未能自动读取开户行业列（可能需手动开启自定义列）');
          }
        }
      } catch (e) {
        log('  ⚠️  开户行业预校验跳过: ' + e.message);
      }
    }

    // 3. 打开新建申请页
    log('📄 打开新建申请页...');
    await page.goto('https://adhome.woa.com/css/policy/access_guard_apply/create', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    
    // 等待表单加载
    await page.waitForSelector('.form-item-industry_id .selection-single', { timeout: 60000 });
    log('✅ 页面加载完成');
    
    // 4. 选择行业
    log('📌 选择行业: ' + config.industry);
    await page.click('.form-item-industry_id .selection-single');
    await page.waitForSelector('.form-item-industry_id .selection-results li', { timeout: 10000 });
    await page.click(`.form-item-industry_id .selection-name[data-value="${config.industry_data_value}"]`);
    
    // 等待表单根据行业展开
    await page.waitForSelector('.form-item-advertiser_industrial_identity', { timeout: 10000 });
    log('✅ 行业已选择，表单已展开');
    
    // 5. 搜索选择主体名称
    log('📌 搜索主体: ' + config.mdm_name);
    await page.click('.form-item-mdm_id .selection-single');
    await page.waitForSelector('.form-item-mdm_id .selection-search input', { state: 'visible', timeout: 10000 });
    
    // 使用原生value setter + input事件触发搜索API
    await page.evaluate((keyword) => {
      const input = document.querySelector('.form-item-mdm_id .selection-search input');
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      nativeSetter.call(input, keyword);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }, config.mdm_name);
    
    // 等待搜索结果（非selection-name结构，而是直接的li列表）
    await page.waitForFunction(() => {
      const items = document.querySelectorAll('.form-item-mdm_id .selection-results li');
      return items.length > 0;
    }, { timeout: 8000 });
    
    // 等待搜索结果稳定
    await page.waitForTimeout(200);
    
    // 选择第一个匹配结果
    await page.click('.form-item-mdm_id .selection-results li:first-child');
    await page.waitForTimeout(200);
    
    // 验证选择结果
    const selectedName = await page.evaluate(() => {
      return document.querySelector('.form-item-mdm_id .selection-single-text').textContent.trim();
    });
    log(`✅ 主体已选择: ${selectedName}`);
    
    // 6. 填写账户ID
    log('📌 填写账户ID...');
    const accountText = config.account_ids.join('\n');
    await page.fill('.form-item-account_id_list textarea', accountText);
    await page.click('.form-item-account_id_list label');
    log('✅ 账户ID已填写');
    
    // 7. 选择广告主产业身份
    log('📌 选择产业身份: ' + config.advertiser_identity);
    await page.click('.form-item-advertiser_industrial_identity .selection-single');
    await page.waitForSelector('.form-item-advertiser_industrial_identity .selection-results li', { timeout: 8000 });
    await page.click(`.form-item-advertiser_industrial_identity .selection-name[data-value="${config.advertiser_identity}"]`);
    log('✅ 产业身份已选择');
    
    // 8. 选择资本背景
    log('📌 选择资本背景: ' + config.capital_background);
    await page.click('.form-item-advertiser_capital_background .selection-single');
    await page.waitForSelector('.form-item-advertiser_capital_background .selection-results li', { timeout: 8000 });
    await page.click(`.form-item-advertiser_capital_background .selection-name[data-value="${config.capital_background}"]`);
    log('✅ 资本背景已选择');
    
    // 9. 上传资质文件（如有）
    if (config.qualification_files && config.qualification_files.length > 0) {
      log('📌 上传资质文件...');
      await uploadFiles(
        page,
        '.form-item-qualification_information_attachment_list',
        config.qualification_files,
        '资质文件'
      );
    }
    
    // 9.5 上传其他评估资质（如有）
    if (config.other_qualification_files && config.other_qualification_files.length > 0) {
      log('📌 上传其他评估资质...');
      await uploadFiles(
        page,
        '.form-item-other_qualification_attachment_list',
        config.other_qualification_files,
        '其他评估资质'
      );
    }
    
    // 10. 填写品牌名+产品名
    if (config.brand_product_name) {
      log('📌 填写品牌名+产品名: ' + config.brand_product_name);
      await page.fill('.form-item-product_brand_name input', config.brand_product_name);
    }
    
    // 11. 填写产品链接（URL 或 二维码上传）—— 如果表单没有该字段则跳过
    if (config.product_url || config.product_qrcode_file) {
      log('📌 填写产品链接...');
      const productUrlSection = await page.$('.form-item-product_url_list');
      if (productUrlSection) {
        try {
          await page.click('.form-item-product_url_list .selection-single');
          await page.waitForSelector('.form-item-product_url_list .selection-results li', { timeout: 5000 });
          // 自动判断类型：包含 url/http 则选 URL连接
          const autoType = (config.product_url && /^https?:\/\/|^url$/i.test(config.product_url_type || config.product_url)) ? 'URL连接' : (config.product_url_type || 'URL连接');
          // 使用 Playwright 原生 click（不用 evaluate click，Vue 组件需要原生事件）
          const productTypeItems = page.locator('.form-item-product_url_list .selection-results .selection-name');
          const ptCount = await productTypeItems.count();
          for (let pi = 0; pi < ptCount; pi++) {
            const text = await productTypeItems.nth(pi).textContent();
            if (text && text.trim() === autoType) {
              await productTypeItems.nth(pi).click();
              break;
            }
          }
          await page.waitForTimeout(500);
          
          if (config.product_url) {
            const urlInput = await page.$('.form-item-product_url_list input[placeholder*="URL"]');
            if (urlInput) {
              await urlInput.fill(config.product_url);
            }
            log('✅ 产品链接(URL)已填写');
          } else if (config.product_qrcode_file && fs.existsSync(config.product_qrcode_file)) {
            await uploadFiles(page, '.form-item-product_url_list', [config.product_qrcode_file], '产品二维码');
          }
        } catch (e) {
          log('⚠️ 产品链接字段操作失败，跳过: ' + e.message.substring(0, 80));
        }
      } else {
        log('ℹ️ 表单无产品链接字段，跳过');
      }
    }
    
    // 12. 上传外层素材（如有）
    if (config.material_files && config.material_files.length > 0) {
      log('📌 上传外层素材...');
      // 确保之前的下拉菜单已关闭，DOM 稳定
      await page.evaluate(() => document.body.click());
      await page.waitForTimeout(500);
      await page.evaluate(() => {
        const el = document.querySelector('.form-item-material_image_list');
        if (el) el.scrollIntoView({ block: 'center' });
      });
      await page.waitForTimeout(300);
      await uploadFiles(
        page,
        '.form-item-material_image_list',
        config.material_files,
        '素材文件'
      );
    }
    
    // 13. 填写素材落地页（URL 或 二维码上传）—— 自动判断类型
    if (config.material_landing_url || config.material_landing_qrcode_file) {
      log('📌 填写素材落地页...');
      const landingSection = await page.$('.form-item-material_landing_page_list');
      if (landingSection) {
        try {
          // 滚动到素材落地页区域确保可见
          await page.evaluate(() => {
            const el = document.querySelector('.form-item-material_landing_page_list');
            if (el) el.scrollIntoView({ block: 'center' });
          });
          await page.waitForTimeout(300);
          
          // 点击下拉框
          await page.click('.form-item-material_landing_page_list .selection-single');
          await page.waitForSelector('.form-item-material_landing_page_list .selection-results li', { timeout: 8000 });
          await page.waitForTimeout(300);
          
          // 自动判断类型
          let autoLandingType = 'URL连接';
          if (config.material_landing_url && /^https?:\/\//i.test(config.material_landing_url)) {
            autoLandingType = 'URL连接';
          }
          
          // 用 Playwright 原生定位点击选项（不用 evaluate）
          const landingTypeOption = await page.$('.form-item-material_landing_page_list .selection-results li:first-child');
          if (landingTypeOption) {
            // 尝试精确匹配，否则点第一个（通常就是 URL连接）
            const matched = await page.evaluate((type) => {
              const items = document.querySelectorAll('.form-item-material_landing_page_list .selection-results li');
              for (const item of items) {
                if (item.textContent.trim().includes(type)) {
                  item.click();
                  return true;
                }
              }
              // fallback: 也尝试 .selection-name
              const names = document.querySelectorAll('.form-item-material_landing_page_list .selection-name');
              for (const n of names) {
                if (n.textContent.trim().includes(type)) {
                  n.click();
                  return true;
                }
              }
              return false;
            }, autoLandingType);
            
            if (!matched) {
              // 最终 fallback：直接点第一个 li
              await landingTypeOption.click();
              log('  ⚠️ 未精确匹配类型，选择第一个选项');
            }
          }
          
          // 等待类型选择生效，URL 输入框出现
          await page.waitForTimeout(800);
          
          if (config.material_landing_url) {
            // 多种选择器尝试找到 URL 输入框
            let landingInput = await page.$('.form-item-material_landing_page_list input[placeholder*="URL"]');
            if (!landingInput) {
              landingInput = await page.$('.form-item-material_landing_page_list input[type="text"]');
            }
            if (landingInput) {
              // 使用原生 value setter（与主体搜索相同方式），因为 fill() 可能被组件拦截
              await page.evaluate((url) => {
                const input = document.querySelector('.form-item-material_landing_page_list input[placeholder*="URL"]') 
                  || document.querySelector('.form-item-material_landing_page_list input[type="text"]');
                if (input) {
                  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                  nativeSetter.call(input, url);
                  input.dispatchEvent(new Event('input', { bubbles: true }));
                  input.dispatchEvent(new Event('change', { bubbles: true }));
                  input.dispatchEvent(new Event('blur', { bubbles: true }));
                }
              }, config.material_landing_url);
              await page.waitForTimeout(300);
              // 验证填写结果
              const filledValue = await landingInput.inputValue();
              if (filledValue && filledValue.length > 5) {
                log('✅ 素材落地页(URL)已填写: ' + filledValue.substring(0, 50));
              } else {
                // 最后手段：click + type
                await landingInput.click();
                await landingInput.type(config.material_landing_url, { delay: 10 });
                const val2 = await landingInput.inputValue();
                log('  素材落地页 type 方式填写结果: ' + (val2 || 'EMPTY'));
              }
            } else {
              log('⚠️ 未找到素材落地页 URL 输入框');
            }
          } else if (config.material_landing_qrcode_file && fs.existsSync(config.material_landing_qrcode_file)) {
            await uploadFiles(page, '.form-item-material_landing_page_list', [config.material_landing_qrcode_file], '素材落地页二维码');
          }
        } catch (e) {
          log('⚠️ 素材落地页字段操作失败: ' + e.message.substring(0, 120));
        }
      } else {
        log('ℹ️ 表单无素材落地页字段，跳过');
      }
    }
    
    // 14. 选择投放链路
    if (config.release_links && config.release_links.length > 0) {
      log('📌 选择投放链路...');
      try {
        await page.click('.form-item-release_link_list .selection-single');
        await page.waitForSelector('.form-item-release_link_list .selection-results li', { timeout: 8000 });
        
        for (const link of config.release_links) {
          await page.evaluate((linkName) => {
            const items = document.querySelectorAll('.form-item-release_link_list .selection-name');
            for (let i = 0; i < items.length; i++) {
              if (items[i].textContent.trim() === linkName) {
                items[i].click();
                break;
              }
            }
          }, link);
        }
        // 关闭下拉框
        await page.evaluate(() => document.body.click());
        log('✅ 投放链路已选择');
      } catch (e) {
        log('⚠️ 投放链路选择失败: ' + e.message.substring(0, 80));
        await page.evaluate(() => document.body.click());
      }
    }
    
    // 15. 选择分类（spaui-select-tree 级联树）—— v3 修复版
    if (config.category_path && config.category_path.length > 0) {
      log('📌 选择分类: ' + config.category_path.join(' > '));
      try {
        // 确保之前所有下拉菜单关闭
        await page.evaluate(() => document.body.click());
        await page.waitForTimeout(800);
        
        // 滚动到分类字段并确保可见
        await page.evaluate(() => {
          const el = document.querySelector('.form-item-category_list');
          if (el) el.scrollIntoView({ block: 'center' });
        });
        await page.waitForTimeout(800);
        
        // 点击打开分类选择器（带重试）
        for (let attempt = 0; attempt < 3; attempt++) {
          await page.click('.form-item-category_list .selection-single', { timeout: 10000 });
          await page.waitForTimeout(1500);
          
          // 检查是否打开了树形选择器
          const treeOpened = await page.evaluate(() => {
            const drop = document.querySelector('.form-item-category_list .selection-drop');
            if (!drop) return false;
            const style = window.getComputedStyle(drop);
            return style.display !== 'none' && style.visibility !== 'hidden' && drop.offsetHeight > 0;
          });
          
          if (treeOpened) {
            log('  ℹ️ 树形选择器已打开 (attempt ' + (attempt+1) + ')');
            break;
          } else {
            log('  ⚠️ 树形选择器未打开 (attempt ' + (attempt+1) + ')，重试...');
            await page.evaluate(() => document.body.click());
            await page.waitForTimeout(500);
          }
        }
        
        // 等待树节点出现（增加等待时间）
        await page.waitForSelector('.form-item-category_list .spaui-tree-name', { timeout: 10000 }).catch(() => {});
        await page.waitForTimeout(2000);
        
        // 等待节点文本真正加载（非空）
        for (let w = 0; w < 10; w++) {
          const hasText = await page.evaluate(() => {
            const names = document.querySelectorAll('.form-item-category_list .spaui-tree-name');
            return Array.from(names).some(n => n.textContent.trim().length > 0);
          });
          if (hasText) break;
          await page.waitForTimeout(500);
        }
        
        // 调试：输出当前可见的树节点数和文本
        const debugTreeInfo = await page.evaluate(() => {
          const names = document.querySelectorAll('.form-item-category_list .spaui-tree-name');
          return Array.from(names).map(n => n.textContent.trim());
        });
        log('  ℹ️ 当前树节点: [' + debugTreeInfo.join(', ') + '] (共' + debugTreeInfo.length + '个)');
        
        for (let i = 0; i < config.category_path.length; i++) {
          const name = config.category_path[i];
          const isLastLevel = (i === config.category_path.length - 1);
          await page.waitForTimeout(600);
          
          try {
            let clicked = false;
            
            // 方法1: page.evaluate 获取坐标 + page.mouse.click（最可靠）
            // 先确保分类选择器下拉框在视口内
            await page.evaluate(() => {
              const drop = document.querySelector('.form-item-category_list .selection-drop');
              if (drop) drop.scrollIntoView({ block: 'center' });
            });
            await page.waitForTimeout(300);
            
            const pos = await page.evaluate((args) => {
              const { catName, isLeaf } = args;
              const items = document.querySelectorAll('.form-item-category_list .spaui-tree-name');
              // 对于叶子节点取最后一个匹配（最深列），非叶子取第一个
              let target = null;
              for (const item of items) {
                if (item.textContent.trim() === catName) {
                  if (isLeaf) {
                    target = item; // 保留最后一个匹配
                  } else {
                    target = item;
                    break; // 非叶子取第一个
                  }
                }
              }
              if (target) {
                // 叶子节点点击整个 li（包含 radio），非叶子点击 spaui-tree-name
                const el = isLeaf ? (target.closest('li') || target) : target;
                const rect = el.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                  return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, w: rect.width, h: rect.height };
                }
              }
              return null;
            }, { catName: name, isLeaf: isLastLevel });
            
            if (pos) {
              await page.mouse.click(pos.x, pos.y);
              clicked = true;
              log(`  ✅ 分类层级 [${name}] 已选 (mouse.click at ${pos.x.toFixed(0)},${pos.y.toFixed(0)}${isLastLevel ? ' leaf-li' : ''})`);
              await page.waitForTimeout(800);
            }
            
            if (!clicked) {
              // 方法2: Playwright locator
              const treeNames = page.locator('.form-item-category_list .spaui-tree-name');
              const count = await treeNames.count();
              let matchIndex = -1;
              for (let j = 0; j < count; j++) {
                const text = await treeNames.nth(j).textContent();
                if (text && text.trim() === name) {
                  if (isLastLevel) matchIndex = j;
                  else { matchIndex = j; break; }
                }
              }
              if (matchIndex >= 0) {
                if (isLastLevel) {
                  const liEl = treeNames.nth(matchIndex).locator('xpath=ancestor::li');
                  if (await liEl.count() > 0) await liEl.first().click();
                  else await treeNames.nth(matchIndex).click();
                } else {
                  await treeNames.nth(matchIndex).click();
                }
                clicked = true;
                log(`  ✅ 分类层级 [${name}] 已选 (locator, idx=${matchIndex}${isLastLevel ? ' leaf' : ''})`);
              }
            }
            
            if (!clicked) {
              log(`  ⚠️ 分类层级 [${name}] 未找到`);
            }
          } catch (e) {
            log(`  ⚠️ 分类层级 [${name}] 错误: ${e.message.substring(0, 80)}`);
          }
        }
        
        // 验证分类选择结果
        await page.waitForTimeout(500);
        const selectedCategory = await page.evaluate(() => {
          const text = document.querySelector('.form-item-category_list .selection-single-text');
          return text ? text.textContent.trim() : 'EMPTY';
        });
        
        if (selectedCategory && selectedCategory !== '请选择') {
          log(`✅ 分类已选择: ${selectedCategory}`);
        } else {
          log('⚠️ 分类选择可能未生效，当前值: ' + selectedCategory);
        }
        
        // 关闭下拉
        await page.evaluate(() => document.body.click());
        await page.waitForTimeout(300);
      } catch (e) {
        log('⚠️ 分类选择失败: ' + e.message.substring(0, 120));
        await page.evaluate(() => document.body.click());
      }
    }
    
    // 15.5 填写投放机构名称
    if (config.institution_name || config.brand_product_name) {
      const instName = config.institution_name || config.brand_product_name;
      log('📌 填写投放机构名称: ' + instName);
      await page.evaluate(() => {
        const el = document.querySelector('.form-item-organization_name');
        if (el) el.scrollIntoView({ block: 'center' });
      });
      
      await page.evaluate(() => {
        document.querySelector('.form-item-organization_name .selection-single').click();
      });
      await page.waitForSelector('.form-item-organization_name .selection-search input', { state: 'visible', timeout: 8000 });
      
      await page.evaluate((keyword) => {
        const input = document.querySelector('.form-item-organization_name .selection-search input');
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(input, keyword);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }, instName);
      
      await page.waitForFunction(() => {
        const items = document.querySelectorAll('.form-item-organization_name .selection-results li');
        return items.length > 0;
      }, { timeout: 5000 }).catch(() => {
        log('⚠️ 投放机构名称搜索无结果');
      });
      
      const orgResult = await page.$('.form-item-organization_name .selection-results li:first-child');
      if (orgResult) {
        await orgResult.click();
        log('✅ 投放机构名称已选择');
      } else {
        log('⚠️ 未找到投放机构名称匹配结果');
      }
    }
    
    // 16. 填写竞媒投放消耗
    if (config.competitive_consumption) {
      log('📌 填写竞媒消耗: ' + config.competitive_consumption);
      await page.evaluate(() => {
        document.querySelector('.form-item-competitive_media_consumption').scrollIntoView({ block: 'center' });
      });
      await page.fill('.form-item-competitive_media_consumption input', config.competitive_consumption);
    }
    
    // 17. 填写消耗预算
    if (config.cost_budget) {
      log('📌 填写消耗预算: ' + config.cost_budget);
      await page.fill('.form-item-cost_budget input', config.cost_budget);
    }
    
    // 18. 选择保证金豁免
    if (config.is_deposit_free !== undefined) {
      log('📌 选择保证金豁免...');
      await page.evaluate(() => {
        document.querySelector('.form-item-is_deposit_free').scrollIntoView({ block: 'center' });
      });
      await page.evaluate(() => {
        document.querySelector('.form-item-is_deposit_free .selection-single').click();
      });
      await page.waitForSelector('.form-item-is_deposit_free .selection-results li', { timeout: 8000 });
      await page.evaluate((val) => {
        const item = document.querySelector('.form-item-is_deposit_free .selection-name[data-value="' + val + '"]');
        if (item) item.click();
      }, config.is_deposit_free);
      await page.waitForTimeout(150);
    }
    
    // ============ 填写完成 ============
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    log(`\n✅ ═══════════════════════════════════════`);
    log(`✅ 表单填写完成！总耗时: ${elapsed} 秒`);
    log(`✅ ═══════════════════════════════════════\n`);
    
    // 截图
    const screenshotPath = path.join(__dirname, 'output', `apply_${config.mdm_name}_${Date.now()}.png`);
    await page.screenshot({ path: screenshotPath, fullPage: true });
    log(`📸 截图: ${screenshotPath}`);
    
    // 提交
    if (config.auto_submit && !isDryRun) {
      log('🔴 自动提交中...');
      await page.click('button:has-text("提交")');
      await page.waitForTimeout(2000);
      
      // 检查是否有确认对话框
      const confirmBtn = await page.$('.spaui-dialog button:has-text("确定"), .modal-dialog button:has-text("确定"), .spaui-dialog-footer button:has-text("确定"), .spaui-dialog-footer button:has-text("确认")');
      if (confirmBtn) {
        await confirmBtn.click();
        await page.waitForTimeout(2000);
      }
      
      // 再次检查是否还有弹框
      const confirmBtn2 = await page.$('.spaui-dialog button:has-text("确定"), .spaui-dialog-footer button:has-text("确认")');
      if (confirmBtn2) {
        await confirmBtn2.click();
        await page.waitForTimeout(1500);
      }
      
      // 截取提交后的页面
      const postSubmitShot = path.join(__dirname, 'output', `post_submit_${config.mdm_name}_${Date.now()}.png`);
      await page.screenshot({ path: postSubmitShot, fullPage: true });
      log(`📸 提交后截图: ${postSubmitShot}`);
      
      // 检查是否有错误提示
      const errorMsg = await page.evaluate(() => {
        const err = document.querySelector('.form-item-error, .spaui-toast-error, .error-message, [class*="error"]');
        return err ? err.textContent.trim().substring(0, 200) : null;
      });
      if (errorMsg) {
        log(`⚠️ 提交后发现错误提示: ${errorMsg}`);
        finalStatus = `❌提交失败: ${errorMsg.substring(0, 60)}`;
      } else {
        log('✅ 已提交！');
        finalStatus = '✅已自动提交';
      }
    } else {
      // ========= 信号文件等待模式 =========
      // 写等待信号文件，通知外部调用方表单已就绪
      const signalDir = '/tmp';
      const waitingFile = path.join(signalDir, 'adhome_waiting.json');
      const signalFile = path.join(signalDir, 'adhome_signal.json');
      
      // 清除旧信号
      try { fs.unlinkSync(signalFile); } catch(e) {}
      
      // 写入等待状态
      fs.writeFileSync(waitingFile, JSON.stringify({
        status: 'waiting',
        mdm_name: config.mdm_name,
        screenshot: screenshotPath,
        timestamp: Date.now()
      }));
      
      log('⏸️  填写完成，等待外部信号...');
      log(`   信号文件: ${signalFile}`);
      log('   写入 {"action":"submit"} 提交，{"action":"cancel"} 撤回');
      
      // 轮询等待信号文件（最多5分钟）
      const maxWait = 300000;
      const pollInterval = 1000;
      let waited = 0;
      let signal = null;
      
      while (waited < maxWait) {
        await page.waitForTimeout(pollInterval);
        waited += pollInterval;
        
        try {
          if (fs.existsSync(signalFile)) {
            signal = JSON.parse(fs.readFileSync(signalFile, 'utf-8'));
            log(`📨 收到信号: ${JSON.stringify(signal)}`);
            break;
          }
        } catch(e) {}
      }
      
      // 清理信号文件
      try { fs.unlinkSync(waitingFile); } catch(e) {}
      try { fs.unlinkSync(signalFile); } catch(e) {}
      
      if (signal && signal.action === 'submit') {
        log('🔴 用户确认，执行提交...');
        await page.click('button:has-text("提交")');
        await page.waitForTimeout(2000);
        
        // 检查确认对话框
        const confirmBtn = await page.$('.spaui-dialog button:has-text("确定"), .modal-dialog button:has-text("确定"), .spaui-dialog-footer button:has-text("确定"), .spaui-dialog-footer button:has-text("确认")');
        if (confirmBtn) {
          await confirmBtn.click();
          await page.waitForTimeout(2000);
        }
        const confirmBtn2 = await page.$('.spaui-dialog button:has-text("确定"), .spaui-dialog-footer button:has-text("确认")');
        if (confirmBtn2) {
          await confirmBtn2.click();
          await page.waitForTimeout(1500);
        }
        
        // 提交后截图
        const postSubmitShot = path.join(__dirname, 'output', `post_submit_${config.mdm_name}_${Date.now()}.png`);
        await page.screenshot({ path: postSubmitShot, fullPage: true });
        log(`📸 提交后截图: ${postSubmitShot}`);
        
        // 检查错误
        const errorMsg = await page.evaluate(() => {
          const err = document.querySelector('.form-item-error, .spaui-toast-error, .error-message, [class*="error"]');
          return err ? err.textContent.trim().substring(0, 200) : null;
        });
        if (errorMsg) {
          log(`⚠️ 提交后发现错误提示: ${errorMsg}`);
          finalStatus = `❌提交失败: ${errorMsg.substring(0, 60)}`;
        } else {
          log('✅ 已提交！');
          finalStatus = '✅已确认提交';
        }
      } else if (signal && signal.action === 'cancel') {
        log('🔙 用户撤回，关闭浏览器');
        finalStatus = '🔙用户撤回';
      } else {
        log('⏰ 等待超时（5分钟），关闭浏览器');
        finalStatus = '⏰等待超时';
      }
    }
    
    // 发送企微通知
    if (config.notify_webhook) {
      const https = require('https');
      const url = new URL(config.notify_webhook);
      const postData = JSON.stringify({
        msgtype: 'markdown',
        markdown: {
          content: `### 🔔 ADHome加白申请\n> **主体**: ${config.mdm_name}\n> **账户**: ${config.account_ids.join(', ')}\n> **耗时**: ${elapsed}秒\n> **状态**: ${finalStatus}\n\n请前往 [ADHome](https://adhome.woa.com/css/policy/access_guard_apply) 查看`
        }
      });
      
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      req.write(postData);
      req.end();
      log('📢 企微通知已发送');
    }
    
  } catch (err) {
    console.error('❌ 执行出错:', err.message);
    
    // 出错时也截图
    const errScreenshot = path.join(__dirname, 'output', `error_${Date.now()}.png`);
    try {
      await page.screenshot({ path: errScreenshot, fullPage: true });
      log(`📸 错误截图: ${errScreenshot}`);
    } catch(e) {}
    
    process.exit(1);
  } finally {
    await browser.close().catch(() => {});
  }
  
  log('🏁 流程结束');
})();
