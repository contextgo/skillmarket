#!/usr/bin/env python3
"""
加白预审 + 风控校验脚本（秒级执行）
用法:
  python3 precheck.py --input task.json
  python3 precheck.py --json '{"主体名称":"xxx", ...}'
  python3 precheck.py --interactive  (交互式逐项输入)

输出: 校验报告(stdout JSON) + 退出码(0=通过, 1=有错误, 2=仅警告)
"""
import json, sys, os, argparse, glob
from datetime import datetime, date
from pathlib import Path

# ── 路径 ──────────────────────────────────────────
SKILL_DIR = Path(__file__).resolve().parent.parent
REF_DIR = SKILL_DIR / "references"
CODEBOOK = REF_DIR / "adhome_codebook.json"
ADMISSION = REF_DIR / "adhome_admission_rules.json"
PREFERRED = REF_DIR / "adhome_preferred_rules.json"

# ── 加载规则库 ────────────────────────────────────
def load_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

codebook = load_json(CODEBOOK)
admission = load_json(ADMISSION)
preferred = load_json(PREFERRED)

# 索引
VALID_INDUSTRIES = {i["text"] for i in codebook["industry"]}
VALID_IDENTITIES = {i["text"] for i in codebook["advertiser_identity"]}
VALID_CAPITALS   = {i["text"] for i in codebook["capital_background"]}
VALID_LINKS      = {i["text"] for i in codebook["release_links"]}
CATEGORY_TREE    = codebook["category_tree"]

# 准入规则按 l1>l2>l3 索引
ADMISSION_INDEX = {}
for rule in admission.get("category_admission", []):
    key = f"{rule['l1']}>{rule['l2']}>{rule['l3']}"
    ADMISSION_INDEX[key] = rule

INSTITUTION_RULES = admission.get("institution_type_rules", {})
BASE_REQ = admission.get("base_requirements", {})

# ── 校验结果收集 ──────────────────────────────────
errors = []
warnings = []
info_msgs = []

def err(field, msg):
    errors.append({"level": "ERROR", "field": field, "message": msg})

def warn(field, msg):
    warnings.append({"level": "WARN", "field": field, "message": msg})

def info(field, msg):
    info_msgs.append({"level": "INFO", "field": field, "message": msg})

# ── 校验函数 ──────────────────────────────────────

def check_required(data):
    """必填字段检查
    注意：「行业」不再是必填——优先从 ADHome 人户关系表（广告主账户管理）自动获取，
    手动填写仅作为 fallback。如果既没手动填也还没查人户关系表，仅给 INFO 提示。
    """
    required = ["主体名称", "账户ID", "产业身份", "资本背景", "品牌产品名称"]
    for f in required:
        v = data.get(f)
        if not v or (isinstance(v, list) and len(v) == 0) or (isinstance(v, str) and v.strip() == ""):
            err(f, f"必填字段 [{f}] 不能为空")
    # 行业：非必填，但提示来源
    ind = data.get("行业", "")
    if not ind or (isinstance(ind, str) and ind.strip() == ""):
        info("行业", "行业字段未填写——将在模块三-B（查人户关系表）时自动获取，无需手动填")

def check_industry(data):
    """行业合法性（有值才校验，行业优先从人户关系表自动获取）"""
    ind = data.get("行业", "").strip()
    if not ind:
        return  # 未填=后续从人户关系表获取，check_required 已给 info 提示
    if ind not in VALID_INDUSTRIES:
        err("行业", f"行业 [{ind}] 不在合法列表中。合法值: {sorted(VALID_INDUSTRIES)}")

def check_identity(data):
    """产业身份合法性"""
    v = data.get("产业身份", "")
    if v and v not in VALID_IDENTITIES:
        err("产业身份", f"[{v}] 不合法。可选: {sorted(VALID_IDENTITIES)}")

def check_capital(data):
    """资本背景合法性"""
    v = data.get("资本背景", "")
    if v and v not in VALID_CAPITALS:
        err("资本背景", f"[{v}] 不合法。可选: {sorted(VALID_CAPITALS)}")

def check_release_links(data):
    """投放链路合法性"""
    links = data.get("投放链路", [])
    if isinstance(links, str):
        links = [links]
    for l in links:
        if l and l not in VALID_LINKS:
            err("投放链路", f"[{l}] 不在合法列表。可选: {sorted(VALID_LINKS)}")

def check_category(data):
    """投放类目路径合法性 + 已取消类目检查"""
    cat = data.get("投放类目", "")
    if not cat:
        return
    parts = [p.strip() for p in cat.split(">")]
    if len(parts) != 3:
        err("投放类目", f"类目路径必须是三级，格式: 一级>二级>三级，当前: [{cat}]")
        return
    l1, l2, l3 = parts
    tree = CATEGORY_TREE.get(l1)
    if not tree:
        err("投放类目", f"一级类目 [{l1}] 不存在")
        return
    l2_tree = tree.get(l2)
    if not l2_tree:
        err("投放类目", f"二级类目 [{l2}] 在 [{l1}] 下不存在")
        return
    if l3 not in l2_tree:
        err("投放类目", f"三级类目 [{l3}] 在 [{l1}>{l2}] 下不存在")
        return
    
    # 检查已取消类目
    key = f"{l1}>{l2}>{l3}"
    rule = ADMISSION_INDEX.get(key)
    if rule:
        notes = rule.get("notes", "")
        if "已取消" in notes:
            err("投放类目", f"类目 [{cat}] 已取消，不再接受投放申请")
        # 检查所有机构类型是否全部不准入
        adm = rule.get("admission", {})
        all_blocked = all(not v.get("allowed", False) for v in adm.values())
        if all_blocked and "已取消" not in notes:
            err("投放类目", f"类目 [{cat}] 所有机构类型均不准入")

def check_files(data):
    """文件存在性检查"""
    for field in ["资质文件", "素材文件", "其他资质文件"]:
        files = data.get(field, [])
        if isinstance(files, str):
            files = [files]
        for fp in files:
            if fp and not os.path.exists(fp):
                # 尝试 glob 展开
                matches = glob.glob(fp)
                if not matches:
                    err(field, f"文件不存在: {fp}")

def check_registration_years(data):
    """注册年限检查"""
    reg_date_str = data.get("营业执照注册日期", "")
    if not reg_date_str:
        warn("营业执照注册日期", "未提供注册日期，无法校验注册年限")
        return
    try:
        reg_date = datetime.strptime(reg_date_str, "%Y-%m-%d").date()
    except ValueError:
        try:
            reg_date = datetime.strptime(reg_date_str, "%Y/%m/%d").date()
        except ValueError:
            err("营业执照注册日期", f"日期格式无法解析: {reg_date_str}，请用 YYYY-MM-DD")
            return
    
    today = date.today()
    years = (today - reg_date).days / 365.25
    
    cat = data.get("投放类目", "")
    is_professional = cat.startswith("专业医疗")
    min_years = 2 if is_professional else 1
    label = "专业医疗" if is_professional else "消费医疗"
    
    if years < min_years:
        err("注册年限", f"{label}要求注册≥{min_years}年，当前仅 {years:.1f} 年（注册日: {reg_date_str}）")
    else:
        info("注册年限", f"注册 {years:.1f} 年，满足{label}≥{min_years}年要求")

def check_ad_review_expiry(data):
    """广审表有效期检查"""
    exp_str = data.get("广审表有效期", "")
    if not exp_str:
        warn("广审表有效期", "未提供广审表有效期，请确认")
        return
    try:
        exp_date = datetime.strptime(exp_str, "%Y-%m-%d").date()
    except ValueError:
        try:
            exp_date = datetime.strptime(exp_str, "%Y/%m/%d").date()
        except ValueError:
            err("广审表有效期", f"日期格式无法解析: {exp_str}")
            return
    
    today = date.today()
    days_left = (exp_date - today).days
    if days_left < 0:
        err("广审表有效期", f"广审表已过期 {abs(days_left)} 天（到期日: {exp_str}）")
    elif days_left <= 30:
        warn("广审表有效期", f"广审表将在 {days_left} 天后到期（{exp_str}），建议尽快续期")
    else:
        info("广审表有效期", f"广审表有效，剩余 {days_left} 天")

def check_industry_consistency(data):
    """开户行业一致性（仅在手动填了行业时才校验）"""
    ind = data.get("行业", "").strip()
    actual = data.get("实际开户行业", "").strip()
    if not ind:
        return  # 行业未手动填，后续从人户关系表获取，不需要一致性校验
    if actual and ind and actual != ind:
        err("行业一致性", f"填写行业 [{ind}] 与实际开户行业 [{actual}] 不一致")

def check_material_count(data):
    """外层素材数量检查"""
    files = data.get("素材文件", [])
    if isinstance(files, str):
        files = [files]
    if len(files) < 3:
        err("外层素材", f"外层素材至少需要 3 张，当前 {len(files)} 张")

def check_admission_rules(data):
    """准入规则匹配 — 核心风控逻辑"""
    cat = data.get("投放类目", "")
    if not cat:
        return
    
    parts = [p.strip() for p in cat.split(">")]
    if len(parts) != 3:
        return
    
    key = ">".join(parts)
    rule = ADMISSION_INDEX.get(key)
    if not rule:
        warn("准入规则", f"类目 [{cat}] 未找到准入规则，需人工确认")
        return
    
    # 判断机构类型
    name = data.get("主体名称", "")
    ind = data.get("行业", "")
    inst_type = guess_institution_type(name, ind)
    
    info("机构类型", f"判定为: {inst_type}")
    
    # 映射机构类型到准入规则的 key
    type_map = {
        "综合医院": "comprehensive",
        "专科医院": "specialty", 
        "门诊部": "outpatient",
        "诊所": "clinic"
    }
    type_key = type_map.get(inst_type, "specialty")
    
    adm = rule.get("admission", {}).get(type_key, {})
    allowed = adm.get("allowed", False)
    
    if not allowed:
        err("准入规则", f"类目 [{cat}] 不允许 [{inst_type}] 准入")
    else:
        info("准入规则", f"类目 [{cat}] 允许 [{inst_type}] 准入 ✓")
        extra = adm.get("extra", "")
        if extra:
            warn("准入规则-附加条件", f"{extra}")
        video = adm.get("video_account", "")
        if video and video != "准入":
            warn("视频号准入", f"视频号准入条件: {video}")
    
    # 流量准入
    traffic = rule.get("traffic", {})
    for t_key, t_label in [("MP", "朋友圈"), ("PCAD", "PCAD"), ("PCAD_non_video", "PCAD非视频号")]:
        t_val = traffic.get(t_key, "")
        if t_val and "不准入" in t_val:
            warn("流量准入", f"{t_label}: {t_val}")
        elif t_val and "附加条件" in t_val:
            warn("流量准入", f"{t_label}: {t_val}")
    
    # 必需诊疗科目
    req_depts = rule.get("required_departments", [])
    if req_depts:
        info("必需诊疗科目", f"执业许可证需包含以下科目之一: {', '.join(req_depts)}")
    
    # 风险等级
    risk = rule.get("risk_level")
    if risk:
        risk_label = {1: "高风险", 2: "中风险", 3: "低风险"}.get(risk, f"等级{risk}")
        info("风险等级", f"{risk_label}（level {risk}）")

def guess_institution_type(name, industry):
    """根据主体名称和行业判定机构类型"""
    # 诊所
    if "诊所" in name or "诊所" in industry:
        return "诊所"
    # 门诊部
    if "门诊" in name or "门诊" in industry:
        return "门诊部"
    # 综合 vs 专科
    neg_keywords = INSTITUTION_RULES.get("comprehensive_hospital", {}).get("name_keywords_negative", [])
    # 补充常见专科关键词（规则库未列全的）
    extra_specialty = ["胃肠", "肛肠", "不孕不育", "妇幼", "儿童", "心血管", "肿瘤", "结石", "康复", "精神", "心理"]
    all_specialty_kw = list(set(neg_keywords + extra_specialty))
    for kw in all_specialty_kw:
        if kw in name:
            return "专科医院"
    # 没有专科关键词 → 综合
    if "医院" in name or "综合" in industry:
        return "综合医院"
    # 兜底
    return "专科医院"

def check_base_requirements(data):
    """基础准入要求提示（行政处罚、负面舆情等 — 仅提醒，无法自动校验）"""
    name = data.get("主体名称", "")
    ind = data.get("行业", "")
    inst_type = guess_institution_type(name, ind)
    
    type_map = {
        "综合医院": "comprehensive_hospital",
        "专科医院": "specialty_hospital",
        "门诊部": "outpatient_dept",
        "诊所": "clinic"
    }
    req_key = type_map.get(inst_type, "specialty_hospital")
    reqs = BASE_REQ.get(req_key, {})
    
    if reqs:
        items = []
        for k, v in reqs.items():
            label_map = {
                "registration_years_consumer": "消费医疗注册年限",
                "registration_years_professional": "专业医疗注册年限",
                "admin_penalties_5y": "5年行政处罚",
                "admin_penalties_1y": "1年行政处罚",
                "severe_penalties": "严重处罚",
                "negative_publicity_5y": "5年负面舆情",
                "negative_publicity_1y": "1年负面舆情",
                "lawsuits_5y": "5年诉讼",
                "lawsuits_1y": "1年诉讼",
                "professional_medical_support": "专业医疗支持"
            }
            label = label_map.get(k, k)
            items.append(f"{label}: {v}")
        info("基础准入要求", f"[{inst_type}] 需满足: " + " | ".join(items))
    
    # 集团豁免提醒
    exemption = BASE_REQ.get("special_exemption", "")
    if exemption:
        info("豁免规则", exemption)

def check_preferred_rules(data):
    """择优规则匹配（生活美容/植发/体检 需要额外判断）"""
    cat = data.get("投放类目", "")
    if not cat:
        return
    
    applicable = preferred.get("applicable_categories", [])
    if cat not in applicable:
        return
    
    info("择优规则", f"类目 [{cat}] 需额外参照择优规则（集团/单店）")
    for pt in preferred.get("preferred_types", []):
        ptype = pt.get("type", "")
        info("择优规则", f"[{ptype}] — 详见 references/adhome_preferred_rules.json")

def check_account_ids(data):
    """账户ID格式检查"""
    ids = data.get("账户ID", [])
    if isinstance(ids, str):
        ids = [i.strip() for i in ids.replace(",", "\n").replace("，", "\n").split("\n") if i.strip()]
    for aid in ids:
        aid_str = str(aid).strip()
        if not aid_str.isdigit():
            err("账户ID", f"账户ID [{aid_str}] 不是纯数字")
    if ids:
        info("账户ID", f"共 {len(ids)} 个账户")

# ── 主逻辑 ────────────────────────────────────────

def run_all_checks(data):
    """执行全部校验，返回报告"""
    global errors, warnings, info_msgs
    errors, warnings, info_msgs = [], [], []
    
    check_required(data)
    check_industry(data)
    check_identity(data)
    check_capital(data)
    check_release_links(data)
    check_category(data)
    check_account_ids(data)
    check_files(data)
    check_registration_years(data)
    check_ad_review_expiry(data)
    check_industry_consistency(data)
    check_material_count(data)
    check_admission_rules(data)
    check_base_requirements(data)
    check_preferred_rules(data)
    
    passed = len(errors) == 0
    report = {
        "passed": passed,
        "has_warnings": len(warnings) > 0,
        "summary": {
            "errors": len(errors),
            "warnings": len(warnings),
            "info": len(info_msgs)
        },
        "errors": errors,
        "warnings": warnings,
        "info": info_msgs,
        "input_data": data,
        "check_time": datetime.now().isoformat()
    }
    return report

def print_report(report):
    """友好格式输出"""
    passed = report["passed"]
    s = report["summary"]
    
    print("=" * 60)
    if passed and not report["has_warnings"]:
        print("✅ 预审通过 — 可以进入填表流程")
    elif passed:
        print("⚠️  预审通过（有警告）— 建议确认后再填表")
    else:
        print("❌ 预审未通过 — 请修正以下错误")
    print(f"   错误: {s['errors']}  警告: {s['warnings']}  信息: {s['info']}")
    print("=" * 60)
    
    if report["errors"]:
        print("\n🔴 错误:")
        for e in report["errors"]:
            print(f"  [{e['field']}] {e['message']}")
    
    if report["warnings"]:
        print("\n🟡 警告:")
        for w in report["warnings"]:
            print(f"  [{w['field']}] {w['message']}")
    
    if report["info"]:
        print("\n🔵 信息:")
        for i in report["info"]:
            print(f"  [{i['field']}] {i['message']}")
    
    print()

def main():
    parser = argparse.ArgumentParser(description="加白预审+风控校验")
    parser.add_argument("--input", "-i", help="输入 JSON 文件路径")
    parser.add_argument("--json", "-j", help="直接传入 JSON 字符串")
    parser.add_argument("--output", "-o", help="输出报告到文件（JSON）")
    parser.add_argument("--quiet", "-q", action="store_true", help="仅输出 JSON，不打印友好格式")
    args = parser.parse_args()
    
    if args.json:
        data = json.loads(args.json)
    elif args.input:
        data = load_json(args.input)
    else:
        # 从 stdin 读
        raw = sys.stdin.read().strip()
        if raw:
            data = json.loads(raw)
        else:
            print("用法: python3 precheck.py --input task.json")
            print("      python3 precheck.py --json '{...}'")
            print("      echo '{...}' | python3 precheck.py")
            sys.exit(1)
    
    report = run_all_checks(data)
    
    if not args.quiet:
        print_report(report)
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        if not args.quiet:
            print(f"📄 报告已保存: {args.output}")
    
    if args.quiet:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    
    # 退出码
    if report["errors"]:
        sys.exit(1)
    elif report["warnings"]:
        sys.exit(2)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
