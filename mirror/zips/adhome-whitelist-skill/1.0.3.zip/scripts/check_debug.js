const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_FILE = path.join(__dirname, 'adhome_auth.json');
const TARGET_URL = 'https://adhome.woa.com/css/policy/access_guard_apply';

async function main() {
  let browser;
  try {
    const authData = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8'));
    
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    await context.addCookies(authData.cookies);
    
    const page = await context.newPage();
    await page.goto(TARGET_URL, { waitUntil: 'networkidle', timeout: 30000 });
    
    const currentUrl = page.url();
    const title = await page.title();
    const bodyText = await page.textContent('body').catch(() => '');
    
    // Check for any table-like elements
    const tableInfo = await page.evaluate(() => {
      const selectors = [
        '.spaui-table-tr-data',
        'table tbody tr',
        '.el-table__body tr',
        'table tr',
        '[class*="table"] tr',
        '[class*="Table"] tr'
      ];
      const result = {};
      for (const sel of selectors) {
        result[sel] = document.querySelectorAll(sel).length;
      }
      return result;
    });
    
    console.log(JSON.stringify({
      url: currentUrl,
      title: title,
      bodySnippet: bodyText.substring(0, 1000),
      tableInfo: tableInfo
    }, null, 2));
    
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }));
  } finally {
    if (browser) await browser.close();
  }
}

main();
