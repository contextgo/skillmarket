const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

(async () => {
  const authPath = path.join(__dirname, '..', '..', '..', '..', '..', '.workbuddy', 'skills', 'codebuddy-skill-1775047490342', 'scripts', 'adhome_auth.json');
  const authData = JSON.parse(fs.readFileSync('/Users/zhanglei/.workbuddy/skills/codebuddy-skill-1775047490342/scripts/adhome_auth.json', 'utf8'));
  
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  await context.addCookies(authData.cookies);
  const page = await context.newPage();
  
  try {
    await page.goto('https://adhome.woa.com/css/policy/access_guard_apply', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    const url = page.url();
    const title = await page.title();
    const bodyText = await page.evaluate(() => document.body.innerText.substring(0, 500));
    console.log(JSON.stringify({ url, title, bodySnippet: bodyText }));
  } catch (e) {
    console.log(JSON.stringify({ error: e.message }));
  } finally {
    await browser.close();
  }
})();
