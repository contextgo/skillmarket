const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_FILE = path.join(__dirname, 'adhome_auth.json');
const TARGET_URL = 'https://adhome.woa.com/css/policy/access_guard_apply';

async function main() {
  let browser;
  try {
    const authData = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8'));
    
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    await context.addCookies(authData.cookies);
    
    const page = await context.newPage();
    await page.goto(TARGET_URL, { waitUntil: 'networkidle', timeout: 30000 });
    
    const currentUrl = page.url();
    const title = await page.title();
    const bodyText = await page.textContent('body').catch(() => '');
    const bodySnippet = bodyText.substring(0, 800);
    
    // Check redirected away
    if (!currentUrl.includes('adhome.woa.com')) {
      console.log(JSON.stringify({ error: 'redirected', url: currentUrl, title, body: bodySnippet }));
      return;
    }
    
    // Check iOA block
    if (bodyText.includes('iOA') && (bodyText.includes('访问失败') || bodyText.includes('扫描二维码') || bodyText.includes('401'))) {
      console.log(JSON.stringify({ error: 'ioa_blocked', url: currentUrl, title, body: bodySnippet }));
      return;
    }
    
    // Check for OA login redirect within adhome frame
    if (bodyText.includes('passport') || bodyText.includes('登录') || title.includes('Login') || title.includes('登录')) {
      console.log(JSON.stringify({ error: 'login_required', url: currentUrl, title, body: bodySnippet }));
      return;
    }
    
    // Try multiple table selectors
    const selectors = ['.spaui-table-tr-data', 'table tbody tr', '.el-table__body tr', 'tr[data-index]'];
    let tableSelector = null;
    
    for (const sel of selectors) {
      try {
        await page.waitForSelector(sel, { timeout: 8000 });
        const count = await page.locator(sel).count();
        if (count > 0) {
          tableSelector = sel;
          break;
        }
      } catch (_) {}
    }
    
    if (!tableSelector) {
      // Take screenshot for debug
      await page.screenshot({ path: path.join(__dirname, '..', '..', '..', '..', 'adhome_diag_0412.png'), fullPage: true });
      console.log(JSON.stringify({ error: 'no_table', url: currentUrl, title, body: bodySnippet }));
      return;
    }
    
    // Extract records
    const records = await page.evaluate((sel) => {
      const rows = document.querySelectorAll(sel);
      const results = [];
      rows.forEach(row => {
        // Try spaui cells first
        let cells = row.querySelectorAll('.spaui-table-td-inner');
        if (cells.length < 8) {
          cells = row.querySelectorAll('td');
        }
        if (cells.length >= 8) {
          results.push({
            seq: (cells[1]?.textContent || '').trim(),
            industry: (cells[3]?.textContent || '').trim(),
            company: (cells[4]?.textContent || '').trim(),
            accountId: (cells[5]?.textContent || '').trim(),
            status: (cells[7]?.textContent || '').trim()
          });
        }
      });
      return results;
    }, tableSelector);
    
    console.log(JSON.stringify({ success: true, records, count: records.length, selector: tableSelector }));
    
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }));
  } finally {
    if (browser) await browser.close();
  }
}

main();
