const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_FILE = path.join(__dirname, 'adhome_auth.json');
const TARGET_URL = 'https://adhome.woa.com/css/policy/access_guard_apply';

async function main() {
  let browser;
  try {
    const authData = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8'));
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    await context.addCookies(authData.cookies);
    
    const page = await context.newPage();
    await page.goto(TARGET_URL, { waitUntil: 'networkidle', timeout: 30000 });
    
    const currentUrl = page.url();
    const title = await page.title();
    const bodyText = (await page.textContent('body').catch(() => '')).substring(0, 1000);
    
    // Check for table selectors
    const hasSpaui = await page.locator('.spaui-table-tr-data').count();
    const hasElTable = await page.locator('.el-table__body .el-table__row').count();
    const hasTbody = await page.locator('table tbody tr').count();
    
    console.log(JSON.stringify({
      url: currentUrl,
      title: title,
      bodySnippet: bodyText,
      selectors: {
        spaui_table_tr_data: hasSpaui,
        el_table_row: hasElTable,
        table_tbody_tr: hasTbody
      }
    }, null, 2));
    
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }));
  } finally {
    if (browser) await browser.close();
  }
}

main();
