# 渠道消费医疗加白 - ADHome Whitelist Skill v2

## 简介

自动完成 ADHome（adhome.woa.com）广告账户加白（机构准入评估）申请的全流程自动化工具。

**v2 新增能力：**
- ✅ 双源文档读取（企微文档 + 腾讯文档）
- ✅ 智能附件下载（MCP / PDF 兜底 / Chrome profile 链接提取）
- ✅ 分类级联选择器精确匹配（修复三列独立选择器 bug）
- ✅ ADHome Cookie 自动刷新（iOA 验证流程）
- ✅ 提交前用户确认机制
- ✅ 审批状态智能推送（状态变化检测，夜间静默）

## 安装

1. 解压 zip 到 `~/.workbuddy/skills/` 目录
2. 确保已安装 Playwright：`npx playwright install chromium`
3. 准备 Cookie 文件：
   - 企微文档：`~/.wecom-doc-cookies.json`
   - ADHome：skill 目录下 `scripts/adhome_auth.json`
4. 配置企微 Webhook（可选）

## 使用方法

直接对 AI 说：
```
加白第N行
https://docs.qq.com/sheet/xxx（或 doc.weixin.qq.com/sheet/xxx）
```

AI 会自动：
1. 识别文档类型并读取数据
2. 下载资质和素材附件
3. 填写 ADHome 表单
4. 截图给你确认后提交
5. 验证申请列表并发送企微通知

## 支持的文档类型

| 类型 | URL | 读取方式 |
|------|-----|---------|
| 企微文档 | doc.weixin.qq.com | Playwright + Cookie |
| 腾讯文档 | docs.qq.com | MCP 导出 xlsx |

## 支持的行业

医疗健康-门诊部、医疗健康-诊所、医疗健康-专业型医院、医疗健康-综合型医院、医疗健康-体检机构

## 文件结构

```
├── SKILL.md              # 核心指令文件（AI 读取）
├── README_SKILL.md       # 安装使用说明
├── scripts/
│   ├── adhome_fast_apply.js  # ADHome 自动填表脚本
│   ├── adhome_auth.json      # ADHome 登录态（不含在 zip 中）
│   ├── precheck.py           # 预审校验（可选）
│   └── output/               # 截图输出
└── references/
    ├── adhome_codebook.json      # 行业码表
    ├── adhome_category_tree.json # 分类树
    └── adhome_admission_rules.json # 准入规则
```

## 版本历史

- **v2 (2026-04-08)**：融入全部实战经验，新增腾讯文档支持、PDF 附件兜底、分类选择器修复、用户确认机制
- **v1 (2026-04-02)**：初版，支持企微文档读取、MCP 附件下载、基础填表
