# ADHome 消费医疗加白 Skill v2 — 全流程指引

> 最后更新：2026-04-20 22:52
> 基于 10+ 次实战迭代 + 本次流程改造

---

## 一、整体流程图

```
用户: "加白第N行" + 文档链接
         │
    ┌────┴────┐
    │  前置检查  │
    └────┬────┘
         │
    ┌────┴──────────────────────┐
    │ 0️⃣ Webhook 配置检查          │
    │   ├─ user_config.json 存在?  │
    │   │  ├─ YES → 读取 webhook   │
    │   │  └─ NO → 引导用户配置    │
    │   └─ 保存到 user_config.json │
    └────┬──────────────────────┘
         │
    ┌────┴──────────────────────┐
    │ 1️⃣ 识别文档类型并读取数据     │
    │   ├─ doc.weixin.qq.com       │
    │   │  → Playwright + 企微Cookie│
    │   └─ docs.qq.com             │
    │      → MCP 导出 xlsx + 解析  │
    │   ⚠️ 必须先读表头确认列映射    │
    └────┬──────────────────────┘
         │
    ┌────┴──────────────────────┐
    │ 2️⃣ 定位 / 下载素材文件       │
    │   ├─ 本地搜索 ~/Desktop/加白/ │
    │   ├─ MCP 导出（公开文档）     │
    │   ├─ page.pdf()（私密文档）   │
    │   └─ Chrome profile + 链接提取│
    └────┬──────────────────────┘
         │
    ┌────┴──────────────────────────────────┐
    │ 3️⃣ 构建 Config → 后台运行填表脚本         │
    │   • auto_submit: false（必须！）          │
    │   • 脚本填完表 → 截图 → 写信号文件 → 等待   │
    └────┬──────────────────────────────────┘
         │
    ┌────┴──────────────────────────────────┐
    │ 4️⃣ 对话框确认                             │
    │   • 展示填写内容汇总表格 + 表单截图         │
    │   • 给出两个按钮：                         │
    │     ┌──────────┐  ┌──────────┐           │
    │     │  ✅ 提交  │  │  ❌ 撤回  │           │
    │     └────┬─────┘  └────┬─────┘           │
    │          │              │                 │
    │     写信号文件       写信号文件             │
    │   {"action":"submit"}  {"action":"cancel"}│
    └────┬─────────────┬────────────────────┘
         │              │
    ┌────┴────┐   ┌────┴──────────────────┐
    │ 提交分支  │   │ 撤回分支                │
    │ 脚本点击  │   │ 关闭浏览器              │
    │ "提交"按钮│   │ 引导用户说明修改内容     │
    │ → 截图    │   │ → 修正 config → 重新填表 │
    │ → 关闭    │   └─────────────────────┘
    └────┬────┘
         │
    ┌────┴──────────────────────────────────┐
    │ 5️⃣ 验证 + 通知                            │
    │   • 检查提交后截图确认申请号出现             │
    │   • 脚本内通知：自动发送到 webhook（第1层）   │
    │   • 主流程通知：Agent 再发一条汇总（第2层）   │
    │   • 清理残留 Chromium 进程                  │
    └───────────────────────────────────────┘
```

---

## 二、各步骤详细说明

### 0️⃣ Webhook 配置检查（首次使用时触发）

| 项 | 说明 |
|----|------|
| 配置文件 | `{SKILL_DIR}/scripts/user_config.json` |
| 格式 | `{"notify_webhook": "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY"}` |
| 首次引导 | 检测不到 webhook → 提示用户提供企微群机器人 Webhook 地址 → 写入持久化 |
| 后续运行 | 自动读取，无需重复配置 |
| ⚠️ 规则 | 不同用户有不同 webhook，**严禁硬编码** |

### 1️⃣ 读取文档数据

| 文档类型 | 域名 | 读取方式 |
|----------|------|----------|
| 企微文档 | `doc.weixin.qq.com` | Playwright + `~/.wecom-doc-cookies.json` + `input.bar-label` 导航 |
| 腾讯文档 | `docs.qq.com` | mcporter → MCP `export_file` 导出 xlsx → openpyxl 解析 |

**关键规则：**
- 必须先读**表头（第1行）**确认列结构（标准 A→S vs 扩展 D→V）
- 腾讯文档 MCP 不支持企微文档，必须用 Playwright
- 企微 Cookie 访问 docs.qq.com 时部分列显示"内容隐藏"→ 必须用 MCP 导出

### 2️⃣ 定位/下载素材文件

**搜索优先级：**
1. `~/Desktop/加白/` 按主体名称关键词匹配
2. `~/Downloads/附件下载_冀豫-消费医疗2026年/附件/`
3. 找不到 → 自动下载：
   - MCP 导出（公开腾讯文档）
   - page.pdf() 兜底（私密文档 / MCP access denied）
   - Chrome profile Cookie + card-group 链接提取（docs.qq.com 附件）

### 3️⃣ 构建 Config + 填表

**Config JSON 关键字段：**
```json
{
  "mdm_name": "主体名称（过长时取前半部分）",
  "account_ids": ["ID1", "ID2"],
  "industry": "医疗健康-XXX",
  "industry_data_value": "21474838627",
  "category_path": ["消费医疗", "口腔", "口腔美容"],
  "auto_submit": false,
  ... 其他字段
}
```

**数据清洗规则：**
| 原始值 | 清洗后 | 说明 |
|--------|--------|------|
| "5K" | "5000" | K = 1000 |
| "1000/日" | "1000" | 去 "/日" 后缀 |
| D列 = 主体名称 | "品牌商" | 填表人误填 |
| 多账户ID（换行） | 数组 | 按 \n 分割 |

**执行方式：**
```
后台运行（nohup）→ 脚本填表 → 截图 → 写 /tmp/adhome_waiting.json → 轮询等待信号
```

### 4️⃣ 对话框确认（本次新增 ⭐）

**Agent 侧操作：**
1. 读取 `/tmp/adhome_waiting.json` 确认填表完成
2. 读取填表日志确认所有字段状态
3. 展示截图 + 内容汇总表格
4. 调用 `ask_followup_question` 展示两个按钮：
   - **✅ 提交** → 写 `{"action":"submit"}` 到 `/tmp/adhome_signal.json`
   - **❌ 撤回** → 写 `{"action":"cancel"}` 到 `/tmp/adhome_signal.json`
5. 等待脚本执行完成，查看结果日志

**撤回分支：**
- 关闭浏览器 → 引导用户说明哪里要改 → 修正 config → 重新走第3步

### 5️⃣ 验证 + 通知

**验证：**
- 读取提交后截图，确认申请列表中出现新申请号
- 脚本报"已提交"不代表真成功，必须看截图

**通知（两层）：**

| 层级 | 谁发 | 什么时候 | 内容 |
|------|------|----------|------|
| 第1层 | 脚本 adhome_fast_apply.js | 流程结束时 | 主体、账户、耗时、状态 |
| 第2层 | Agent（主流程） | 任务结束时 | 申请号、成功/失败、关键信息汇总 |

**通知状态：**
| 状态 | 含义 |
|------|------|
| ✅已自动提交 | auto_submit: true 直接提交成功 |
| ✅已确认提交 | 用户按钮确认后提交成功 |
| ❌提交失败 | ADHome 返回错误 |
| 🔙用户撤回 | 用户选择撤回 |
| ⏰等待超时 | 5分钟内未收到信号 |

**清理：**
- `pkill -f "ms-playwright/chromium"` 清理残留进程

---

## 三、信号文件机制说明

```
脚本填表完成
     │
     ▼
写 /tmp/adhome_waiting.json ──→ Agent 检测到 → 展示确认界面
     │
     │  轮询 /tmp/adhome_signal.json（每1秒，最多5分钟）
     │
     ▼
收到信号文件
  ├─ {"action":"submit"} → 点击提交 → 截图 → 关闭浏览器
  ├─ {"action":"cancel"} → 关闭浏览器
  └─ 超时（5分钟）      → 关闭浏览器
     │
     ▼
清理信号文件 → 发企微通知 → 退出
```

---

## 四、多行任务流程

```
用户: "加白第6行和第7行"
     │
     ▼
① 一次 Playwright/MCP 实例读取所有行数据
     │
     ▼
② 批量下载附件（MCP 可并行导出）
     │
     ▼
③ 逐行串行：
   ├─ 构建 config → 后台填表 → 等待信号
   ├─ 展示确认按钮 → 用户确认
   ├─ 提交 → 验证
   └─ 下一行...
     │
     ▼
④ 一条企微通知汇总所有行结果
```

---

## 五、ADHome Cookie 过期处理

```
脚本报错：waitForSelector timeout on .form-item-industry_id
     │
     ▼
检查错误截图 → 发现 iOA 登录页面
     │
     ▼
运行 Cookie 刷新脚本：
  • 打开 adhome.woa.com → 等 iOA 验证
  • 提示用户在手机上确认
  • waitForURL 回 adhome → 保存新 Cookie
     │
     ▼
重新运行填表脚本
```

---

## 六、可跳过的步骤（永久跳过）

- ❌ 不需要安装 agent-browser / wecom-doc skill
- ❌ 不需要运行 precheck.py 预审
- ❌ 不需要 dry-run 确认
- ❌ 不需要检查 Node/Python/Playwright 依赖
- ❌ 不需要每次手动传 webhook 地址

---

## 七、关键路径速查

| 文件 | 路径 |
|------|------|
| ADHome 登录态 | `{SKILL_DIR}/scripts/adhome_auth.json` |
| 用户配置（webhook） | `{SKILL_DIR}/scripts/user_config.json` |
| 填表脚本 | `{SKILL_DIR}/scripts/adhome_fast_apply.js` |
| 企微文档 Cookie | `~/.wecom-doc-cookies.json` |
| 腾讯文档 Cookie | `~/.workbuddy/chrome-profile-docs/` |
| 素材文件 | `~/Desktop/加白/{主体关键词}/` |
| 截图输出 | `{SKILL_DIR}/scripts/output/` |
| 信号文件（等待） | `/tmp/adhome_waiting.json` |
| 信号文件（指令） | `/tmp/adhome_signal.json` |
| mcporter | `~/.workbuddy/binaries/node/workspace/node_modules/.bin/mcporter` |
| Node.js | `~/.workbuddy/binaries/node/versions/22.12.0/bin/node` |
