# 字幕格式与脚本辅助说明

本技能附带脚本，用于提升长字幕处理、结构校验、可读性检查和结构化重建的稳定性。

## 脚本列表

### `scripts/parse_subtitles.py`
用于把字幕文件解析成结构化 JSON，便于后续批处理、翻译、校验或重建。

输出 JSON 中会保留：
- 格式类型（`srt` / `vtt`）
- `WEBVTT` 头（如适用）
- 每个字幕块的位置
- 编号或 cue id
- 时间轴
- 正文行数组
- 原始块内容
- 基础合法性标记

示例：
```bash
python scripts/parse_subtitles.py --input input.srt --output parsed.json
```

### `scripts/rebuild_subtitles.py`
用于把结构化 JSON 重新生成字幕文件。适合在逐块翻译、批量修改、人工修订后，稳定恢复为 `.srt` 或 `.vtt`。

示例：
```bash
python scripts/rebuild_subtitles.py --input parsed.json --output rebuilt.srt
```

如需覆盖格式：
```bash
python scripts/rebuild_subtitles.py --input parsed.json --output rebuilt.vtt --format vtt
```

### `scripts/validate_subtitles.py`
用于比对原字幕与输出字幕，重点检查：
- 输入输出块数是否一致
- SRT 编号是否连续
- 时间轴是否保留且格式合法
- VTT 是否保留 `WEBVTT` 头
- 每个字幕块是否至少包含两行正文（英文 + 中文）
- 最终结果是否通过完整性检查

示例：
```bash
python scripts/validate_subtitles.py --input original.srt --output bilingual.srt --report report.json
```

### `scripts/split_merge_batches.py`
用于长字幕内部批处理。

支持两种命令：

#### 切分
```bash
python scripts/split_merge_batches.py split --input input.srt --out-dir batches --batch-size 80
```

#### 合并
```bash
python scripts/split_merge_batches.py merge --batch-dir batches --output merged.srt
```

切分后会生成 `manifest.json`，记录每个批次的起止块范围，便于后续整合和核对。

### `scripts/length_check.py`
用于检查双语字幕是否存在“适合视频观看”的长度风险，重点提示：
- 单条英文过长
- 单条中文过长
- 中文字幕阅读速度过高（按字符/秒估算）
- 某个字幕块未形成完整双语两行

示例：
```bash
python scripts/length_check.py --input bilingual.srt --report length_report.json
```

也可自定义阈值：
```bash
python scripts/length_check.py --input bilingual.srt --max-cn-chars 24 --max-en-chars 52 --max-cn-cps 8.5
```

## 在技能中的推荐用法

### 稳健流程
1. 使用 `parse_subtitles.py` 解析原字幕
2. 必要时使用 `split_merge_batches.py` 切分长字幕
3. 逐块或逐批完成双语转换
4. 如经过结构化编辑，使用 `rebuild_subtitles.py` 重建字幕文件
5. 使用 `validate_subtitles.py` 检查完整性
6. 使用 `length_check.py` 检查可读性风险
7. 仅在完整性通过后交付给用户

## 注意事项

- 脚本主要解决“结构稳定”“完整性交付”“长度风险提示”“结构化重建”问题，不替代模型对上下文和翻译质量的理解
- 若校验未通过，不应直接把结果交付给用户
- 长度检查更适合做风险提醒，而不是机械地强制否决所有长句；必要时应结合语境人工复核
- 若输入字幕本身格式受损，解析脚本可能会保留错误标记，便于后续定位问题
