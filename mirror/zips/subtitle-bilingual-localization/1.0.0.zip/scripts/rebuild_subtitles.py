#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def rebuild_srt(data: dict) -> str:
    parts = []
    for i, block in enumerate(data.get('blocks', []), start=1):
        idx = block.get('index', i)
        timecode = block.get('timecode', '')
        lines = block.get('lines', [])
        body = '\n'.join([str(idx), timecode, *lines]).strip()
        parts.append(body)
    return '\n\n'.join(parts).strip() + '\n'


def rebuild_vtt(data: dict) -> str:
    header = data.get('header') or 'WEBVTT'
    parts = []
    for block in data.get('blocks', []):
        cue_id = block.get('cue_id')
        timecode = block.get('timecode', '')
        lines = block.get('lines', [])
        section = []
        if cue_id:
            section.append(str(cue_id))
        section.append(timecode)
        section.extend(lines)
        parts.append('\n'.join(section).strip())
    body = '\n\n'.join(parts).strip()
    return f"{header}\n\n{body}\n"


def main():
    parser = argparse.ArgumentParser(description='Rebuild SRT/VTT subtitle file from structured JSON.')
    parser.add_argument('--input', required=True, help='Input JSON path')
    parser.add_argument('--output', required=True, help='Output subtitle file path')
    parser.add_argument('--format', choices=['srt', 'vtt'], required=False, help='Override format if needed')
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding='utf-8'))
    fmt = args.format or data.get('format', 'srt')
    content = rebuild_vtt(data) if fmt == 'vtt' else rebuild_srt(data)
    Path(args.output).write_text(content, encoding='utf-8')
    print(json.dumps({
        'output': args.output,
        'format': fmt,
        'blocks': len(data.get('blocks', []))
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
