#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path

SRT_TIME_RE = re.compile(r"^\d{2}:\d{2}:\d{2},\d{3}\s+-->\s+\d{2}:\d{2}:\d{2},\d{3}$")
VTT_TIME_RE = re.compile(r"^(?:\d{2}:)?\d{2}:\d{2}\.\d{3}\s+-->\s+(?:\d{2}:)?\d{2}:\d{2}\.\d{3}(?:\s+.*)?$")


def normalize_text(text: str):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def split_blocks(text: str):
    text = normalize_text(text)
    lines = text.split('\n')
    blocks = []
    current = []

    def flush():
        nonlocal current
        if current and any(line.strip() for line in current):
            blocks.append('\n'.join(current).strip('\n'))
        current = []

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not current:
            if not stripped:
                i += 1
                continue
            current.append(line)
            i += 1
            continue

        current.append(line)

        if len(current) >= 2:
            first = current[0].strip()
            second = current[1].strip()
            is_srt_header = first.isdigit() and bool(SRT_TIME_RE.match(second))
            is_vtt_header = bool(VTT_TIME_RE.match(first)) or (len(current) >= 2 and bool(VTT_TIME_RE.match(second)))
            structured_block = is_srt_header or is_vtt_header
        else:
            structured_block = False

        if structured_block:
            j = i + 1
            blank_count = 0
            while j < len(lines):
                nxt = lines[j]
                nxt_stripped = nxt.strip()
                if not nxt_stripped:
                    blank_count += 1
                    j += 1
                    continue
                next_is_new_srt = nxt_stripped.isdigit() and j + 1 < len(lines) and bool(SRT_TIME_RE.match(lines[j + 1].strip()))
                next_is_new_vtt = bool(VTT_TIME_RE.match(nxt_stripped)) or (
                    j + 1 < len(lines) and bool(VTT_TIME_RE.match(lines[j + 1].strip()))
                )
                if blank_count > 0 and (next_is_new_srt or next_is_new_vtt):
                    while current and not current[-1].strip():
                        current.pop()
                    flush()
                break
            else:
                while current and not current[-1].strip():
                    current.pop()
                flush()
                i += 1
                continue

        i += 1

    flush()
    return blocks


def detect_format(text: str):
    stripped = text.lstrip()
    if stripped.startswith('WEBVTT'):
        return 'vtt'
    return 'srt'


def parse_srt(text: str):
    blocks = split_blocks(text)
    parsed = []
    for block in blocks:
        lines = normalize_text(block).split('\n')
        if len(lines) < 3:
            parsed.append({'index': None, 'timecode': None, 'content': lines, 'errors': ['block_too_short']})
            continue
        block_index = lines[0].strip()
        timecode = lines[1].strip()
        content = lines[2:]
        errors = []
        if not block_index.isdigit():
            errors.append('invalid_index')
        if not SRT_TIME_RE.match(timecode):
            errors.append('invalid_timecode')
        parsed.append({'index': int(block_index) if block_index.isdigit() else None, 'timecode': timecode, 'content': content, 'errors': errors})
    return parsed


def parse_vtt(text: str):
    normalized = normalize_text(text)
    lines = normalized.split('\n')
    errors = []
    if not lines or not lines[0].startswith('WEBVTT'):
        errors.append('missing_webvtt_header')
    body = '\n'.join(lines[1:]).strip()
    blocks = split_blocks(body)
    parsed = []
    for block in blocks:
        blines = normalize_text(block).split('\n')
        if not blines:
            continue
        cue_id = None
        timecode_line = blines[0].strip()
        content_start = 1
        if not VTT_TIME_RE.match(timecode_line):
            if len(blines) >= 2 and VTT_TIME_RE.match(blines[1].strip()):
                cue_id = blines[0].strip()
                timecode_line = blines[1].strip()
                content_start = 2
            else:
                parsed.append({'cue_id': None, 'timecode': None, 'content': blines, 'errors': ['invalid_timecode']})
                continue
        content = blines[content_start:]
        parsed.append({'cue_id': cue_id, 'timecode': timecode_line, 'content': content, 'errors': []})
    return parsed, errors


def bilingual_issues(parsed_blocks):
    issues = []
    for i, block in enumerate(parsed_blocks, start=1):
        content = [line for line in block.get('content', []) if line.strip()]
        if len(content) < 2:
            issues.append({'block': i, 'issue': 'content_less_than_2_lines'})
    return issues


def compare_counts(src_blocks, out_blocks):
    return len(src_blocks) == len(out_blocks)


def check_srt_sequence(blocks):
    issues = []
    expected = 1
    for pos, block in enumerate(blocks, start=1):
        idx = block.get('index')
        if idx != expected:
            issues.append({'block': pos, 'issue': 'non_continuous_index', 'expected': expected, 'actual': idx})
            expected = idx + 1 if isinstance(idx, int) else expected + 1
        else:
            expected += 1
    return issues


def build_report(input_text: str, output_text: str):
    fmt_in = detect_format(input_text)
    fmt_out = detect_format(output_text)
    report = {
        'input_format': fmt_in,
        'output_format': fmt_out,
        'checks': {},
        'errors': [],
        'warnings': []
    }

    if fmt_in != fmt_out:
        report['warnings'].append('format_changed')

    if fmt_in == 'srt':
        src = parse_srt(input_text)
        out = parse_srt(output_text)
        report['checks']['block_count_match'] = compare_counts(src, out)
        report['checks']['continuous_index'] = len(check_srt_sequence(out)) == 0
        report['checks']['all_timecodes_valid'] = all(not b['errors'] for b in out)
        report['checks']['bilingual_lines_present'] = len(bilingual_issues(out)) == 0
        if not report['checks']['continuous_index']:
            report['errors'].extend(check_srt_sequence(out))
        for pos, block in enumerate(out, start=1):
            for err in block['errors']:
                report['errors'].append({'block': pos, 'issue': err})
        report['warnings'].extend(bilingual_issues(out))
    else:
        src, src_errors = parse_vtt(input_text)
        out, out_errors = parse_vtt(output_text)
        report['checks']['webvtt_header_present'] = 'missing_webvtt_header' not in out_errors
        report['checks']['block_count_match'] = compare_counts(src, out)
        report['checks']['all_timecodes_valid'] = len(out_errors) == 0 and all(not b['errors'] for b in out)
        report['checks']['bilingual_lines_present'] = len(bilingual_issues(out)) == 0
        for err in out_errors:
            report['errors'].append({'issue': err})
        for pos, block in enumerate(out, start=1):
            for err in block['errors']:
                report['errors'].append({'block': pos, 'issue': err})
        report['warnings'].extend(bilingual_issues(out))

    report['checks']['passed'] = all(report['checks'].values())
    return report


def main():
    parser = argparse.ArgumentParser(description='Validate subtitle integrity and bilingual completeness.')
    parser.add_argument('--input', required=True, help='Original subtitle file path')
    parser.add_argument('--output', required=True, help='Generated subtitle file path')
    parser.add_argument('--report', required=False, help='Optional JSON report output path')
    args = parser.parse_args()

    input_text = Path(args.input).read_text(encoding='utf-8')
    output_text = Path(args.output).read_text(encoding='utf-8')
    report = build_report(input_text, output_text)

    if args.report:
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['checks'].get('passed') else 1)


if __name__ == '__main__':
    main()
