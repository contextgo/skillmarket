#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path

SRT_TIME_RE = re.compile(r"^\d{2}:\d{2}:\d{2},\d{3}\s+-->\s+\d{2}:\d{2}:\d{2},\d{3}$")
VTT_TIME_RE = re.compile(r"^(?:\d{2}:)?\d{2}:\d{2}\.\d{3}\s+-->\s+(?:\d{2}:)?\d{2}:\d{2}\.\d{3}(?:\s+.*)?$")


def normalize(text: str) -> str:
    return text.replace('\r\n', '\n').replace('\r', '\n')


def detect_format(text: str) -> str:
    return 'vtt' if text.lstrip().startswith('WEBVTT') else 'srt'


def split_blocks(text: str):
    return [b for b in normalize(text).strip().split('\n\n') if b.strip()]


def parse_srt_blocks(text: str):
    blocks = []
    for raw in split_blocks(text):
        lines = raw.split('\n')
        if len(lines) < 3:
            continue
        blocks.append({
            'index': lines[0],
            'timecode': lines[1],
            'content': lines[2:],
            'raw': raw,
        })
    return blocks


def parse_vtt_blocks(text: str):
    normalized = normalize(text)
    lines = normalized.split('\n')
    header = lines[0] if lines and lines[0].startswith('WEBVTT') else 'WEBVTT'
    body = '\n'.join(lines[1:]).strip()
    blocks = []
    for raw in [b for b in body.split('\n\n') if b.strip()]:
        blines = raw.split('\n')
        cue_id = None
        timecode = blines[0]
        content_start = 1
        if not VTT_TIME_RE.match(timecode) and len(blines) >= 2 and VTT_TIME_RE.match(blines[1]):
            cue_id = blines[0]
            timecode = blines[1]
            content_start = 2
        blocks.append({
            'cue_id': cue_id,
            'timecode': timecode,
            'content': blines[content_start:],
            'raw': raw,
        })
    return header, blocks


def write_batch_file(path: Path, fmt: str, header: str, blocks):
    if fmt == 'srt':
        content = '\n\n'.join(block['raw'] for block in blocks).strip() + '\n'
    else:
        body = '\n\n'.join(block['raw'] for block in blocks).strip()
        content = f"{header}\n\n{body}\n"
    path.write_text(content, encoding='utf-8')


def cmd_split(args):
    input_path = Path(args.input)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    text = input_path.read_text(encoding='utf-8')
    fmt = detect_format(text)

    manifest = {
        'source_file': str(input_path),
        'format': fmt,
        'batch_size': args.batch_size,
        'batches': []
    }

    if fmt == 'srt':
        blocks = parse_srt_blocks(text)
        header = None
    else:
        header, blocks = parse_vtt_blocks(text)

    for i in range(0, len(blocks), args.batch_size):
        batch_blocks = blocks[i:i + args.batch_size]
        batch_id = len(manifest['batches']) + 1
        ext = '.srt' if fmt == 'srt' else '.vtt'
        batch_name = f'batch_{batch_id:03d}{ext}'
        batch_path = out_dir / batch_name
        write_batch_file(batch_path, fmt, header, batch_blocks)
        manifest['batches'].append({
            'batch_id': batch_id,
            'filename': batch_name,
            'start_block': i + 1,
            'end_block': i + len(batch_blocks),
            'count': len(batch_blocks)
        })

    (out_dir / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def cmd_merge(args):
    batch_dir = Path(args.batch_dir)
    manifest = json.loads((batch_dir / 'manifest.json').read_text(encoding='utf-8'))
    fmt = manifest['format']
    merged_parts = []
    header = 'WEBVTT'

    for batch in manifest['batches']:
        text = (batch_dir / batch['filename']).read_text(encoding='utf-8')
        normalized = normalize(text).strip()
        if fmt == 'vtt':
            lines = normalized.split('\n')
            if lines and lines[0].startswith('WEBVTT'):
                header = lines[0]
                normalized = '\n'.join(lines[1:]).strip()
        merged_parts.append(normalized)

    if fmt == 'srt':
        merged = '\n\n'.join(part for part in merged_parts if part).strip() + '\n'
    else:
        body = '\n\n'.join(part for part in merged_parts if part).strip()
        merged = f"{header}\n\n{body}\n"

    Path(args.output).write_text(merged, encoding='utf-8')
    print(json.dumps({'output': args.output, 'format': fmt, 'batch_count': len(manifest['batches'])}, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description='Split long subtitle files into batches and merge them back safely.')
    subparsers = parser.add_subparsers(dest='command', required=True)

    split_parser = subparsers.add_parser('split')
    split_parser.add_argument('--input', required=True)
    split_parser.add_argument('--out-dir', required=True)
    split_parser.add_argument('--batch-size', type=int, default=80)
    split_parser.set_defaults(func=cmd_split)

    merge_parser = subparsers.add_parser('merge')
    merge_parser.add_argument('--batch-dir', required=True)
    merge_parser.add_argument('--output', required=True)
    merge_parser.set_defaults(func=cmd_merge)

    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
