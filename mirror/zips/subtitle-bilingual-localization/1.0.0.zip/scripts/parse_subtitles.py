#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path

VTT_TIME_RE = re.compile(r"^(?:\d{2}:)?\d{2}:\d{2}\.\d{3}\s+-->\s+(?:\d{2}:)?\d{2}:\d{2}\.\d{3}(?:\s+.*)?$")


def normalize(text: str) -> str:
    return text.replace('\r\n', '\n').replace('\r', '\n')


def detect_format(text: str) -> str:
    return 'vtt' if text.lstrip().startswith('WEBVTT') else 'srt'


def split_blocks(text: str):
    return [b for b in normalize(text).strip().split('\n\n') if b.strip()]


def parse_srt(text: str):
    blocks = []
    for pos, raw in enumerate(split_blocks(text), start=1):
        lines = raw.split('\n')
        if len(lines) < 3:
            blocks.append({
                'block_position': pos,
                'index': None,
                'timecode': None,
                'lines': lines,
                'raw': raw,
                'valid': False,
                'error': 'block_too_short'
            })
            continue
        idx = lines[0].strip()
        timecode = lines[1].strip()
        content = [line for line in lines[2:]]
        blocks.append({
            'block_position': pos,
            'index': int(idx) if idx.isdigit() else idx,
            'timecode': timecode,
            'lines': content,
            'raw': raw,
            'valid': idx.isdigit(),
            'error': None if idx.isdigit() else 'invalid_index'
        })
    return {
        'format': 'srt',
        'header': None,
        'blocks': blocks
    }


def parse_vtt(text: str):
    normalized = normalize(text)
    lines = normalized.split('\n')
    header = lines[0] if lines and lines[0].startswith('WEBVTT') else 'WEBVTT'
    body = '\n'.join(lines[1:]).strip()
    blocks = []
    for pos, raw in enumerate([b for b in body.split('\n\n') if b.strip()], start=1):
        blines = raw.split('\n')
        cue_id = None
        timecode = blines[0].strip() if blines else None
        content_start = 1
        valid = True
        error = None
        if not timecode or not VTT_TIME_RE.match(timecode):
            if len(blines) >= 2 and VTT_TIME_RE.match(blines[1].strip()):
                cue_id = blines[0].strip()
                timecode = blines[1].strip()
                content_start = 2
            else:
                valid = False
                error = 'invalid_timecode'
        blocks.append({
            'block_position': pos,
            'cue_id': cue_id,
            'timecode': timecode,
            'lines': blines[content_start:] if len(blines) >= content_start else [],
            'raw': raw,
            'valid': valid,
            'error': error
        })
    return {
        'format': 'vtt',
        'header': header,
        'blocks': blocks
    }


def main():
    parser = argparse.ArgumentParser(description='Parse subtitle files into structured JSON.')
    parser.add_argument('--input', required=True, help='Input subtitle file path')
    parser.add_argument('--output', required=True, help='Output JSON path')
    args = parser.parse_args()

    text = Path(args.input).read_text(encoding='utf-8')
    fmt = detect_format(text)
    data = parse_vtt(text) if fmt == 'vtt' else parse_srt(text)
    Path(args.output).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({
        'output': args.output,
        'format': data['format'],
        'blocks': len(data['blocks'])
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
