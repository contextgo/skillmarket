#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path

SRT_TIME_RE = re.compile(r"^(\d{2}):(\d{2}):(\d{2}),(\d{3})\s+-->\s+(\d{2}):(\d{2}):(\d{2}),(\d{3})$")
VTT_TIME_RE = re.compile(r"^(?:(\d{2}):)?(\d{2}):(\d{2})\.(\d{3})\s+-->\s+(?:(\d{2}):)?(\d{2}):(\d{2})\.(\d{3})(?:\s+.*)?$")


def normalize(text: str) -> str:
    return text.replace('\r\n', '\n').replace('\r', '\n')


def detect_format(text: str) -> str:
    return 'vtt' if text.lstrip().startswith('WEBVTT') else 'srt'


def split_blocks(text: str):
    return [b for b in normalize(text).strip().split('\n\n') if b.strip()]


def srt_ms(timecode_line: str):
    m = SRT_TIME_RE.match(timecode_line.strip())
    if not m:
        return None
    h1, m1, s1, ms1, h2, m2, s2, ms2 = map(int, m.groups())
    start = ((h1 * 60 + m1) * 60 + s1) * 1000 + ms1
    end = ((h2 * 60 + m2) * 60 + s2) * 1000 + ms2
    return start, end


def vtt_ms(timecode_line: str):
    m = VTT_TIME_RE.match(timecode_line.strip())
    if not m:
        return None
    g = m.groups()
    h1 = int(g[0] or 0)
    m1 = int(g[1]); s1 = int(g[2]); ms1 = int(g[3])
    h2 = int(g[4] or 0)
    m2 = int(g[5]); s2 = int(g[6]); ms2 = int(g[7])
    start = ((h1 * 60 + m1) * 60 + s1) * 1000 + ms1
    end = ((h2 * 60 + m2) * 60 + s2) * 1000 + ms2
    return start, end


def parse_blocks(text: str):
    fmt = detect_format(text)
    blocks = []
    if fmt == 'srt':
        for pos, raw in enumerate(split_blocks(text), start=1):
            lines = raw.split('\n')
            if len(lines) < 3:
                continue
            blocks.append({
                'block': pos,
                'id': lines[0].strip(),
                'timecode': lines[1].strip(),
                'content': [x for x in lines[2:] if x.strip()]
            })
    else:
        body = '\n'.join(normalize(text).split('\n')[1:]).strip()
        for pos, raw in enumerate([b for b in body.split('\n\n') if b.strip()], start=1):
            lines = raw.split('\n')
            if not lines:
                continue
            timecode = lines[0].strip()
            start_idx = 1
            cue_id = None
            if not VTT_TIME_RE.match(timecode) and len(lines) >= 2 and VTT_TIME_RE.match(lines[1].strip()):
                cue_id = lines[0].strip()
                timecode = lines[1].strip()
                start_idx = 2
            blocks.append({
                'block': pos,
                'id': cue_id,
                'timecode': timecode,
                'content': [x for x in lines[start_idx:] if x.strip()]
            })
    return fmt, blocks


def get_duration_seconds(fmt: str, timecode: str):
    pair = srt_ms(timecode) if fmt == 'srt' else vtt_ms(timecode)
    if not pair:
        return None
    start, end = pair
    return max((end - start) / 1000.0, 0.001)


def analyze_block(fmt: str, block: dict, max_cn_chars: int, max_en_chars: int, max_cps: float):
    content = block['content']
    english = content[0] if len(content) >= 1 else ''
    chinese = content[1] if len(content) >= 2 else ''
    duration = get_duration_seconds(fmt, block['timecode'])
    issues = []

    en_chars = len(english)
    cn_chars = len(chinese)
    cn_cps = None if duration is None else round(cn_chars / duration, 2)

    if en_chars > max_en_chars:
        issues.append({'issue': 'english_too_long', 'value': en_chars, 'threshold': max_en_chars})
    if cn_chars > max_cn_chars:
        issues.append({'issue': 'chinese_too_long', 'value': cn_chars, 'threshold': max_cn_chars})
    if cn_cps is not None and cn_cps > max_cps:
        issues.append({'issue': 'chinese_reading_speed_too_high', 'value': cn_cps, 'threshold': max_cps})
    if len(content) < 2:
        issues.append({'issue': 'bilingual_lines_missing', 'value': len(content), 'threshold': 2})

    return {
        'block': block['block'],
        'id': block['id'],
        'timecode': block['timecode'],
        'duration_seconds': duration,
        'english_chars': en_chars,
        'chinese_chars': cn_chars,
        'chinese_chars_per_second': cn_cps,
        'issues': issues,
    }


def build_report(text: str, max_cn_chars: int, max_en_chars: int, max_cps: float):
    fmt, blocks = parse_blocks(text)
    analyzed = [analyze_block(fmt, b, max_cn_chars, max_en_chars, max_cps) for b in blocks]
    risky = [b for b in analyzed if b['issues']]
    return {
        'format': fmt,
        'thresholds': {
            'max_chinese_chars_per_block': max_cn_chars,
            'max_english_chars_per_block': max_en_chars,
            'max_chinese_chars_per_second': max_cps,
        },
        'total_blocks': len(analyzed),
        'risky_blocks': len(risky),
        'passed': len(risky) == 0,
        'details': risky,
    }


def main():
    parser = argparse.ArgumentParser(description='Check subtitle length and reading-speed risks for bilingual subtitles.')
    parser.add_argument('--input', required=True, help='Bilingual subtitle file path')
    parser.add_argument('--report', required=False, help='Optional JSON report output path')
    parser.add_argument('--max-cn-chars', type=int, default=22)
    parser.add_argument('--max-en-chars', type=int, default=48)
    parser.add_argument('--max-cn-cps', type=float, default=8.0)
    args = parser.parse_args()

    text = Path(args.input).read_text(encoding='utf-8')
    report = build_report(text, args.max_cn_chars, args.max_en_chars, args.max_cn_cps)

    if args.report:
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
