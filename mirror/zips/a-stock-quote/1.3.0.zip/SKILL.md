---
name: a-stock-quote
version: 1.3.0
description: 获取A股实时行情数据，包括股票价格、涨跌幅、成交量、市值等。支持自选股管理（添加、删除、查看、一键查行情）。使用场景：用户查询A股股票实时价格、涨跌幅、行情信息时触发；用户说"自选股"、"我的股票"、"关注列表"时触发自选股管理。支持股票代码格式如600519、sh600519、sz000001、000858等。
---

# A股实时行情 & 自选股管理

通过腾讯财经API获取沪深A股实时行情，无需API Key。
## 执行流程

1. 执行 `python3 scripts/watchlist.py list` 检查自选股
2. 如果自选股为空，提醒用户添加股票（如：`python3 scripts/watchlist.py add 600519`）
3. 如果有自选股，执行 `python3 scripts/stock_quote.py --watchlist --json` 获取数据
4. 按标准格式输出


## 快速使用

脚本目录：`<skill_dir>/scripts/`

### 查行情

```bash
python3 scripts/stock_quote.py <代码> [代码2 ...]    # 查指定股票
python3 scripts/stock_quote.py --watchlist            # 查自选股行情
python3 scripts/stock_quote.py 600519 --json          # JSON输出
```

支持的代码格式：`600519` / `sh600519` / `sz000001` / `000001`

### 自选股管理

```bash
python3 scripts/watchlist.py add 600519 000001       # 添加
python3 scripts/watchlist.py remove 600519            # 删除
python3 scripts/watchlist.py list                     # 查看列表
python3 scripts/watchlist.py clear                    # 清空
```

数据存储在 `scripts/watchlist.json`，自动创建。

### 返回数据

现价、涨跌额/率、今开/最高/最低/昨收、成交量/额、换手率、振幅、市盈率、量比、总/流通市值。


### 标准输出格式

查询行情时，按以下格式输出（不使用代码块）：

```
[数据时间戳]
代码 名称 现价 涨跌幅
```

示例：

```
[04-02 16:14:51]
002361 神剑股份 17.29 +1.71%
600666 奥瑞德 6.17 -1.59%
```

- 时间戳来自接口返回的数据更新时间
- 涨跌幅带正负号，保留两位小数，末尾加%

## 数据来源

腾讯财经实时行情API（qt.gtimg.cn），免费、无需认证。
