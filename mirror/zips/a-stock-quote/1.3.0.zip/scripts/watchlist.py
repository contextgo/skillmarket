#!/usr/bin/env python3
"""自选股管理"""

import sys
import os
import json

WATCHLIST_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "watchlist.json")


def load_watchlist() -> list:
    if not os.path.exists(WATCHLIST_FILE):
        return []
    try:
        with open(WATCHLIST_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def save_watchlist(stocks: list):
    with open(WATCHLIST_FILE, "w", encoding="utf-8") as f:
        json.dump(stocks, f, ensure_ascii=False, indent=2)


def normalize_code(code: str) -> str:
    code = code.strip().lower()
    if code.startswith("sh"):
        return code[2:]
    if code.startswith("sz"):
        return code[2:]
    return code


def cmd_add(args):
    if not args:
        print("用法: watchlist.py add <代码> [代码2 ...]")
        return

    stocks = load_watchlist()
    existing = {s["code"] if isinstance(s, dict) else s for s in stocks}

    for code in args:
        norm = normalize_code(code)
        if norm in existing:
            print(f"  已存在: {norm}")
        else:
            stocks.append({"code": norm, "name": ""})
            existing.add(norm)
            print(f"  + {norm}")

    save_watchlist(stocks)
    _show_list(stocks)


def cmd_remove(args):
    if not args:
        print("用法: watchlist.py remove <代码> [代码2 ...]")
        return

    stocks = load_watchlist()
    codes_to_remove = {normalize_code(c) for c in args}
    new_stocks = []
    removed = []

    for s in stocks:
        code = s["code"] if isinstance(s, dict) else s
        if code in codes_to_remove:
            removed.append(code)
        else:
            new_stocks.append(s)

    for c in removed:
        print(f"  - {c}")

    save_watchlist(new_stocks)
    _show_list(new_stocks)


def cmd_update_names(name_map: dict):
    """更新自选股名称"""
    stocks = load_watchlist()
    changed = False
    for i, s in enumerate(stocks):
        if isinstance(s, dict):
            code = s["code"]
        else:
            code = s
            stocks[i] = {"code": code, "name": ""}
        if code in name_map and not stocks[i].get("name"):
            stocks[i]["name"] = name_map[code]
            changed = True
    if changed:
        save_watchlist(stocks)


def _show_list(stocks):
    if not stocks:
        print("自选股: (空)")
        return
    parts = []
    for s in stocks:
        if isinstance(s, dict):
            parts.append(f"{s['code']} {s['name']}".strip())
        else:
            parts.append(s)
    print(f"自选股: {', '.join(parts)}")


def cmd_list():
    stocks = load_watchlist()
    if not stocks:
        print("自选股: (空)")
        print("添加: watchlist.py add 600519 000001")
        return
    _show_list(stocks)


def cmd_clear():
    save_watchlist([])
    print("自选股已清空")


def cmd_codes():
    """输出纯代码列表"""
    stocks = load_watchlist()
    codes = [s["code"] if isinstance(s, dict) else s for s in stocks]
    print(" ".join(codes))


def main():
    if len(sys.argv) < 2:
        cmd_list()
        sys.exit(0)

    cmd = sys.argv[1].lower()
    args = sys.argv[2:]

    if cmd == "add":
        cmd_add(args)
    elif cmd in ("remove", "rm", "del"):
        cmd_remove(args)
    elif cmd in ("list", "ls"):
        cmd_list()
    elif cmd == "clear":
        cmd_clear()
    elif cmd == "codes":
        cmd_codes()
    elif cmd == "update_names":
        # 传入 JSON: watchlist.py update_names '{"002361":"神剑股份"}'
        if args:
            cmd_update_names(json.loads(args[0]))
    else:
        print(f"未知命令: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
