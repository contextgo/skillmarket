#!/usr/bin/env python3
"""A股实时行情（腾讯+新浪双源容灾，批量查询）"""

import sys
import os
import json
import urllib.request
import subprocess
from datetime import datetime

# ========== 腾讯API ==========
TENCENT_API = "https://qt.gtimg.cn/q="

TF = {
    "name": 1, "code": 2, "price": 3, "preclose": 4, "open": 5,
    "volume": 6, "timestamp": 30, "change": 31, "change_pct": 32,
    "high": 33, "low": 34, "turnover": 37, "turnover_rate": 38,
    "amplitude": 39, "mktcap": 44, "circ_mktcap": 45, "pe": 46, "vol_ratio": 43,
}

# ========== 新浪API ==========
SINA_API = "https://hq.sinajs.cn/list="
SINA_HEADERS = {
    "Referer": "https://finance.sina.com.cn",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def normalize_code(code: str) -> str:
    code = code.strip().lower().replace(" ", "")
    if code.startswith(("sh", "sz")):
        return code
    if code.startswith(("6", "5")):
        return f"sh{code}"
    elif code.startswith(("0", "3", "1")):
        return f"sz{code}"
    return code


def raw_code(norm_code: str) -> str:
    """去掉sh/sz前缀"""
    return norm_code[2:] if norm_code.startswith(("sh", "sz")) else norm_code


# ========== 市场状态 ==========

def market_status() -> str:
    """判断当前A股市场状态"""
    now = datetime.now()
    weekday = now.weekday()  # 0=Monday
    h, m = now.hour, now.minute
    t = h * 60 + m

    if weekday >= 5:
        return "休市"

    if 9*60+15 <= t < 9*60+25:
        return "集合竞价"
    if 9*60+25 <= t < 9*60+30:
        return "连续竞价准备"
    if 9*60+30 <= t <= 11*60+30:
        return "交易中"
    if 11*60+30 < t < 13*60:
        return "午间休市"
    if 13*60 <= t <= 15*60:
        return "交易中"

    return "休市"


# ========== 腾讯批量查询 ==========

def fetch_tencent_batch(codes: list[str]) -> dict[str, dict | None]:
    """腾讯API批量查询"""
    if not codes:
        return {}

    norm_codes = [normalize_code(c) for c in codes]
    url = f"{TENCENT_API}{','.join(norm_codes)}"
    req = urllib.request.Request(url)

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("gbk")
    except Exception:
        return {c: None for c in norm_codes}

    results = {}
    # 每只股票格式: v_sh600519="...~...";
    segments = raw.strip().split(";")
    for seg in segments:
        seg = seg.strip()
        if '="' not in seg or "~" not in seg:
            continue

        prefix = seg.split('="')[0]
        # 从 v_sh600519 提取 sh600519
        norm_code = prefix[2:]  # 去掉 v_
        payload = seg.split('="')[1].rstrip('"')
        f = payload.split("~")

        if len(f) < 47:
            results[norm_code] = None
            continue

        def fv(i, d=0.0):
            try:
                v = f[i].strip()
                return float(v) if v else d
            except (ValueError, IndexError):
                return d

        def fs(i, d=""):
            try:
                return f[i].strip()
            except IndexError:
                return d

        price = fv(3); preclose = fv(4)
        ts = fs(30)
        if len(ts) == 14:
            ts = f"{ts[4:6]}-{ts[6:8]} {ts[8:10]}:{ts[10:12]}:{ts[12:14]}"

        results[norm_code] = {
            "name": fs(1), "code": fs(2),
            "price": round(price, 2), "open": round(fv(5), 2),
            "high": round(fv(33), 2), "low": round(fv(34), 2),
            "preclose": round(preclose, 2),
            "change": round(price - preclose, 2),
            "change_pct": round((price - preclose) / preclose * 100, 2) if preclose else 0,
            "volume": int(fv(6)), "turnover": fv(37),
            "turnover_rate": fv(38), "amplitude": fv(39),
            "pe": fs(46, "-"), "vol_ratio": fv(43),
            "market_cap": fv(44), "circ_market_cap": fv(45),
            "timestamp": ts, "source": "tencent",
        }

    return results


# ========== 新浪单条查询（备用） ==========

def fetch_sina(code: str) -> dict | None:
    norm = normalize_code(code)
    url = f"{SINA_API}{norm}"
    req = urllib.request.Request(url, headers=SINA_HEADERS)

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("gbk")
    except Exception:
        return None

    if '"' not in raw:
        return None

    payload = raw.split('"')[1]
    f = payload.split(",")
    if len(f) < 32 or not f[0]:
        return None

    def fv(i, d=0.0):
        try:
            return float(f[i]) if f[i] else d
        except (ValueError, IndexError):
            return d

    preclose = fv(1); price = fv(3)
    change = price - preclose
    change_pct = (change / preclose * 100) if preclose else 0
    date_str = f[30] if len(f) > 30 else ""
    time_str = f[31] if len(f) > 31 else ""
    ts = f"{date_str} {time_str}" if date_str else ""

    return {
        "name": f[0], "code": raw_code(norm),
        "price": round(price, 2), "open": round(fv(2), 2),
        "high": round(fv(4), 2), "low": round(fv(5), 2),
        "preclose": round(preclose, 2),
        "change": round(change, 2), "change_pct": round(change_pct, 2),
        "volume": int(fv(8)) // 100, "turnover": fv(9) / 10000,
        "turnover_rate": 0, "amplitude": 0,
        "pe": "-", "vol_ratio": 0,
        "market_cap": 0, "circ_market_cap": 0,
        "timestamp": ts, "source": "sina",
    }


# ========== 统一查询 ==========

def fetch_quote(code: str) -> dict | None:
    """腾讯优先，失败切新浪"""
    try:
        batch = fetch_tencent_batch([code])
        norm = normalize_code(code)
        q = batch.get(norm)
        if q and q["price"] > 0:
            return q
    except Exception:
        pass

    try:
        q = fetch_sina(code)
        if q and q["price"] > 0:
            return q
    except Exception:
        pass

    return None


def fetch_quotes_batch(codes: list[str]) -> list[dict]:
    """批量查询，腾讯一次拿全部，失败的单条走新浪"""
    results = {}
    norm_map = {normalize_code(c): c for c in codes}

    try:
        tencent_results = fetch_tencent_batch(codes)
        for norm_code, q in tencent_results.items():
            if q and q["price"] > 0:
                results[norm_code] = q
    except Exception:
        pass

    # 腾讯失败的走新浪
    for norm_code in norm_map:
        if norm_code not in results:
            try:
                q = fetch_sina(norm_code)
                if q and q["price"] > 0:
                    results[norm_code] = q
            except Exception:
                pass

    # 按原始顺序返回
    ordered = []
    for norm_code in norm_map:
        if norm_code in results:
            ordered.append(results[norm_code])
    return ordered


def format_quote(q: dict) -> str:
    chg = q["change_pct"]
    sign = "+" if chg >= 0 else ""
    return f"{q['code']} {q['name']} {q['price']:.2f} {sign}{chg:.2f}%"


def update_watchlist_names(quotes: list[dict]):
    """把查到的股票名同步回自选股"""
    if not quotes:
        return
    name_map = {q["code"]: q["name"] for q in quotes if q.get("name")}
    if name_map:
        wl_script = os.path.join(SCRIPT_DIR, "watchlist.py")
        subprocess.run(
            [sys.executable, wl_script, "update_names", json.dumps(name_map, ensure_ascii=False)],
            capture_output=True,
        )


def main():
    if len(sys.argv) < 2:
        print("用法: python3 stock_quote.py <代码> [...]")
        print("       python3 stock_quote.py --watchlist")
        sys.exit(1)

    want_json = "--json" in sys.argv
    watchlist_mode = "--watchlist" in sys.argv or "-w" in sys.argv

    if watchlist_mode:
        wl_script = os.path.join(SCRIPT_DIR, "watchlist.py")
        result = subprocess.run(
            [sys.executable, wl_script, "codes"],
            capture_output=True, text=True
        )
        codes_str = result.stdout.strip()
        if not codes_str:
            print("自选股为空，watchlist.py add <代码> 添加")
            sys.exit(0)
        args = codes_str.split()
    else:
        args = [a for a in sys.argv[1:] if a not in ("--json", "--watchlist", "-w")]

    # 批量查询
    quotes = fetch_quotes_batch(args)

    if not quotes:
        print("未获取到任何数据")
        sys.exit(1)

    # 市场状态
    status = market_status()
    ts = quotes[0]["timestamp"] if quotes else ""

    # 输出
    print(f"[{ts}] {status}")
    for q in quotes:
        print(format_quote(q))

    # 同步名称到自选股
    update_watchlist_names(quotes)

    if want_json:
        print("=== JSON ===")
        print(json.dumps(quotes, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
