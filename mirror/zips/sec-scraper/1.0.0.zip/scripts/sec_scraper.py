#!/usr/bin/env python3
"""
SEC Filing Scraper - 美股EDGAR公告检索与下载工具

基于 SEC EDGAR 公开 JSON API，
支持按股票代码和日期范围搜索公告、批量下载文档、导出Excel。

用法:
    python sec_scraper.py search --ticker AAPL
    python sec_scraper.py search --ticker WETH --from 2026-01-01 --to 2026-04-23
    python sec_scraper.py search --ticker BGM --form 8-K
    python sec_scraper.py download --ticker WETH --from 2026-01-01 --output ./sec_docs
    python sec_scraper.py search --ticker BGM --format xlsx --output filings.xlsx
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SEC_BASE_URL = "https://www.sec.gov"
SEC_ARCHIVE_URL = "https://www.sec.gov/Archives/edgar/data"
SEC_TICKERS_URL = f"{SEC_BASE_URL}/files/company_tickers.json"
SEC_SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik}.json"

# Rate limit: max 10 req/s → sleep 0.11s between requests
REQUEST_INTERVAL = 0.11

USER_AGENT = (
    "WorkBuddy-SECFilingScraper/1.0 research@audit.local"
)

# Form type descriptions
FORM_DESCRIPTIONS = {
    "10-K": "年度报告",
    "10-Q": "季度报告",
    "8-K": "重大事项报告",
    "20-F": "外国公司年度报告",
    "6-K": "外国公司重大事项报告",
    "4": "内部人持股变动",
    "S-1": "招股说明书",
    "DEF 14A": "股东大会委托书",
    "10-K/A": "年度报告修正",
    "10-Q/A": "季度报告修正",
    "8-K/A": "重大事项报告修正",
    "20-F/A": "外国公司年度报告修正",
}


# ---------------------------------------------------------------------------
# Ticker → CIK mapping
# ---------------------------------------------------------------------------

_ticker_cache: Optional[Dict[str, dict]] = None


def _load_tickers() -> Dict[str, dict]:
    """Load ticker → {cik, name} mapping from SEC company_tickers.json."""
    global _ticker_cache
    if _ticker_cache is not None:
        return _ticker_cache

    import requests as _requests

    print("  加载 SEC 股票列表...", file=sys.stderr)
    _ticker_cache = {}

    try:
        resp = _requests.get(
            SEC_TICKERS_URL,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

        for _key, val in data.items():
            ticker = val.get("ticker", "").upper()
            cik_raw = val.get("cik_str", "")
            name = val.get("title", "")
            if ticker and cik_raw:
                cik_int = int(cik_raw) if not isinstance(cik_raw, int) else cik_raw
                _ticker_cache[ticker] = {
                    "cik": cik_int,
                    "cik_padded": str(cik_int).zfill(10),
                    "name": name,
                }

        print(f"  已加载 {len(_ticker_cache)} 只美股", file=sys.stderr)

    except Exception as e:
        print(f"  股票列表加载失败: {e}", file=sys.stderr)

    return _ticker_cache


def lookup_cik(ticker: str) -> Optional[dict]:
    """Look up CIK for a given ticker. Returns {cik, cik_padded, name} or None."""
    tickers = _load_tickers()
    return tickers.get(ticker.upper())


# ---------------------------------------------------------------------------
# Filing classification
# ---------------------------------------------------------------------------

def classify_form(form: str) -> Tuple[str, str]:
    """Classify a filing by its form type. Returns (form_type, description)."""
    form_upper = form.upper().strip()
    desc = FORM_DESCRIPTIONS.get(form_upper, "")
    if desc:
        return form_upper, desc

    # Pattern matching for variants
    if "10-K" in form_upper:
        return "10-K", "年度报告"
    elif "10-Q" in form_upper:
        return "10-Q", "季度报告"
    elif "8-K" in form_upper:
        return "8-K", "重大事项报告"
    elif "20-F" in form_upper:
        return "20-F", "外国公司年度报告"
    elif "6-K" in form_upper:
        return "6-K", "外国公司重大事项报告"
    elif form_upper == "4":
        return "4", "内部人持股变动"
    elif "S-1" in form_upper:
        return "S-1", "招股说明书"
    else:
        return form_upper, form


# ---------------------------------------------------------------------------
# API: Fetch filings
# ---------------------------------------------------------------------------

def fetch_filings(
    ticker: str,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    form_filter: Optional[str] = None,
    max_records: int = 0,
) -> List[dict]:
    """Fetch SEC filings for a given ticker.

    Args:
        ticker: Stock ticker symbol (e.g., 'AAPL', 'WETH')
        date_from: Start date YYYY-MM-DD
        date_to: End date YYYY-MM-DD
        form_filter: Filter by form type (e.g., '8-K', '10-K')
        max_records: Max records to return (0 = all)

    Returns:
        List of filing dicts with keys: ticker, cik, company_name, form,
        filing_date, report_date, accession_number, primary_document,
        primary_doc_description, document_url, items
    """
    import requests as _requests

    info = lookup_cik(ticker)
    if not info:
        print(f"[ERROR] 未找到 {ticker} 的CIK", file=sys.stderr)
        return []

    cik_padded = info["cik_padded"]
    company_name = info["name"]
    print(f"  查询 {ticker} ({company_name}) CIK={cik_padded}", file=sys.stderr)

    # Fetch submissions
    url = SEC_SUBMISSIONS_URL.format(cik=cik_padded)
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}

    resp = _requests.get(url, headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    recent = data.get("filings", {}).get("recent", {})

    # Parse recent filings
    accession_numbers = recent.get("accessionNumber", [])
    filing_dates = recent.get("filingDate", [])
    report_dates = recent.get("reportDate", [])
    forms = recent.get("form", [])
    primary_docs = recent.get("primaryDocument", [])
    primary_doc_descs = recent.get("primaryDocDescription", [])
    items_list = recent.get("items", [])

    filings = []
    count = 0

    for i in range(len(accession_numbers)):
        accn = accession_numbers[i]
        filing_date = filing_dates[i] if i < len(filing_dates) else ""
        report_date = report_dates[i] if i < len(report_dates) else ""
        form = forms[i] if i < len(forms) else ""
        primary_doc = primary_docs[i] if i < len(primary_docs) else ""
        primary_doc_desc = primary_doc_descs[i] if i < len(primary_doc_descs) else ""
        items = items_list[i] if i < len(items_list) else ""

        # Date filter
        if date_from and filing_date < date_from:
            continue
        if date_to and filing_date > date_to:
            continue

        # Form filter
        if form_filter and form.upper() != form_filter.upper():
            # Also match form variants like "8-K/A"
            if form_filter.upper() not in form.upper():
                continue

        # Build document URL
        accn_dashes = accn.replace("-", "")
        doc_url = ""
        if primary_doc:
            doc_url = f"{SEC_ARCHIVE_URL}/{cik_padded}/{accn_dashes}/{primary_doc}"

        # Build index URL
        index_url = f"{SEC_ARCHIVE_URL}/{cik_padded}/{accn_dashes}/"

        filings.append({
            "ticker": ticker.upper(),
            "cik": cik_padded,
            "company_name": company_name,
            "form": form,
            "form_description": classify_form(form)[1],
            "filing_date": filing_date,
            "report_date": report_date,
            "accession_number": accn,
            "primary_document": primary_doc,
            "primary_doc_description": primary_doc_desc,
            "document_url": doc_url,
            "index_url": index_url,
            "items": items,
        })

        count += 1
        if max_records > 0 and count >= max_records:
            break

    return filings


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def download_filings(
    filings: List[dict],
    output_dir: str,
    doc_types: Optional[List[str]] = None,
) -> List[str]:
    """Download filing documents to output_dir.

    Args:
        filings: List of filing dicts from fetch_filings()
        output_dir: Directory to save files
        doc_types: List of document extensions to download (default: ['.htm', '.html', '.pdf'])

    Returns:
        List of downloaded file paths
    """
    import requests as _requests

    if doc_types is None:
        doc_types = [".htm", ".html", ".pdf"]

    os.makedirs(output_dir, exist_ok=True)
    headers = {"User-Agent": USER_AGENT}
    downloaded = []

    for filing in filings:
        doc_url = filing.get("document_url", "")
        if not doc_url:
            continue

        # Check extension
        ext = Path(doc_url).suffix.lower()
        if ext not in doc_types and not any(doc_url.endswith(t) for t in doc_types):
            # Try to download anyway for .xml files that are actually HTML
            pass

        # Generate filename
        accn = filing["accession_number"]
        form = filing["form"].replace("/", "_")
        date = filing["filing_date"]
        safe_name = re.sub(r'[^\w\-_.]', '_', filing.get("primary_document", "doc"))
        filename = f"{filing['ticker']}_{date}_{form}_{safe_name}"
        filepath = os.path.join(output_dir, filename)

        if os.path.exists(filepath):
            print(f"  SKIP (exists): {filename}", file=sys.stderr)
            downloaded.append(filepath)
            continue

        try:
            resp = _requests.get(doc_url, headers=headers, timeout=30)
            resp.raise_for_status()

            with open(filepath, "wb") as f:
                f.write(resp.content)

            print(f"  OK: {filename} ({len(resp.content):,} bytes)", file=sys.stderr)
            downloaded.append(filepath)
            time.sleep(REQUEST_INTERVAL)

        except Exception as e:
            print(f"  FAIL: {filename}: {e}", file=sys.stderr)

    return downloaded


# ---------------------------------------------------------------------------
# Export to Excel
# ---------------------------------------------------------------------------

def export_xlsx(filings: List[dict], output_path: str):
    """Export filings to Excel with hyperlinks."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    except ImportError:
        print("[ERROR] openpyxl 未安装。请运行: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = Workbook()
    ws = wb.active
    ws.title = "SEC Filings"

    # Header
    headers = [
        "序号", "股票代码", "公司名称", "表格类型", "类型说明",
        "提交日期", "报告日期", "文件描述", "项目", "链接",
    ]
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = thin_border

    # Data rows
    link_font = Font(color="0563C1", underline="single")

    for i, filing in enumerate(filings, 1):
        row = i + 1
        ws.cell(row=row, column=1, value=i).border = thin_border
        ws.cell(row=row, column=2, value=filing["ticker"]).border = thin_border
        ws.cell(row=row, column=3, value=filing["company_name"]).border = thin_border
        ws.cell(row=row, column=4, value=filing["form"]).border = thin_border
        ws.cell(row=row, column=5, value=filing["form_description"]).border = thin_border
        ws.cell(row=row, column=6, value=filing["filing_date"]).border = thin_border
        ws.cell(row=row, column=7, value=filing["report_date"]).border = thin_border
        ws.cell(row=row, column=8, value=filing["primary_doc_description"]).border = thin_border
        ws.cell(row=row, column=9, value=filing.get("items", "")).border = thin_border

        # Hyperlink
        link_cell = ws.cell(row=row, column=10, value="打开")
        link_cell.hyperlink = filing.get("document_url") or filing.get("index_url", "")
        link_cell.font = link_font
        link_cell.border = thin_border

    # Column widths
    widths = [6, 10, 25, 10, 15, 12, 12, 40, 30, 8]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i)].width = w

    # Auto-filter
    ws.auto_filter.ref = ws.dimensions

    wb.save(output_path)
    print(f"  导出Excel: {output_path} ({len(filings)}条)", file=sys.stderr)


# ---------------------------------------------------------------------------
# CLI Commands
# ---------------------------------------------------------------------------

def cmd_search(args):
    """Search SEC filings."""
    filings = fetch_filings(
        ticker=args.ticker,
        date_from=args.from_date,
        date_to=args.to_date,
        form_filter=args.form,
        max_records=args.max_records,
    )

    if not filings:
        print(f"\n未找到 {args.ticker} 的公告", file=sys.stderr)
        return

    # Print results
    print(f"\n{args.ticker} 公告搜索结果 ({len(filings)}条)")
    print("=" * 80)
    for f in filings:
        print(f"  [{f['filing_date']}] {f['form']} - {f['primary_doc_description'][:60]}")
        if f.get('items'):
            print(f"    Items: {f['items'][:80]}")
        if f.get('document_url'):
            print(f"    URL: {f['document_url'][:80]}")

    # Export if requested
    if args.format == "xlsx":
        output = args.output or f"{args.ticker}_sec_filings.xlsx"
        export_xlsx(filings, output)

    # Save JSON
    json_output = args.output.replace(".xlsx", ".json") if args.output and args.format == "xlsx" else f"{args.ticker}_sec_filings.json"
    if not args.output or args.format != "xlsx":
        json_output = f"{args.ticker}_sec_filings.json"
    with open(json_output, "w", encoding="utf-8") as jf:
        json.dump(filings, jf, ensure_ascii=False, indent=2, default=str)
    print(f"  JSON已保存: {json_output}", file=sys.stderr)


def cmd_download(args):
    """Download SEC filing documents."""
    filings = fetch_filings(
        ticker=args.ticker,
        date_from=args.from_date,
        date_to=args.to_date,
        form_filter=args.form,
        max_records=args.max_records or 50,
    )

    if not filings:
        print(f"\n未找到 {args.ticker} 的公告", file=sys.stderr)
        return

    output_dir = args.output or f"./{args.ticker}_sec_docs"
    print(f"\n下载 {len(filings)} 份文档到 {output_dir}", file=sys.stderr)
    downloaded = download_filings(filings, output_dir)
    print(f"\n下载完成: {len(downloaded)}/{len(filings)} 份", file=sys.stderr)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="SEC EDGAR Filing Scraper - 美股公告检索与下载"
    )
    subparsers = parser.add_subparsers(dest="command", help="命令")

    # search
    search_parser = subparsers.add_parser("search", help="搜索SEC公告")
    search_parser.add_argument("--ticker", required=True, help="股票代码 (e.g., AAPL, WETH)")
    search_parser.add_argument("--from", dest="from_date", help="起始日期 YYYY-MM-DD")
    search_parser.add_argument("--to", dest="to_date", help="结束日期 YYYY-MM-DD")
    search_parser.add_argument("--form", help="表格类型过滤 (e.g., 8-K, 10-K)")
    search_parser.add_argument("--max-records", type=int, default=0, help="最大记录数 (0=全部)")
    search_parser.add_argument("--format", choices=["text", "xlsx"], default="text", help="输出格式")
    search_parser.add_argument("--output", help="输出文件路径")

    # download
    dl_parser = subparsers.add_parser("download", help="下载SEC公告文档")
    dl_parser.add_argument("--ticker", required=True, help="股票代码")
    dl_parser.add_argument("--from", dest="from_date", help="起始日期 YYYY-MM-DD")
    dl_parser.add_argument("--to", dest="to_date", help="结束日期 YYYY-MM-DD")
    dl_parser.add_argument("--form", help="表格类型过滤")
    dl_parser.add_argument("--max-records", type=int, default=50, help="最大下载数")
    dl_parser.add_argument("--output", help="输出目录")

    args = parser.parse_args()

    if args.command == "search":
        cmd_search(args)
    elif args.command == "download":
        cmd_download(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
