# Photo Captions

[![ClawHub](https://img.shields.io/badge/ClawHub-photo--captions-blue)](https://clawhub.ai/pfrederiksen/photo-captions)
[![Version](https://img.shields.io/badge/version-1.2.3-green)]()

An [OpenClaw](https://openclaw.ai) skill that generates platform-tuned social media captions for photography. Share a photo with context (location, camera, lens, film stock) and get captions tailored to each platform.

## Features

- 📸 **Multi-platform** — Instagram, Flickr, X/Twitter, Glass, Tumblr, Threads, Bluesky, 500px, Reddit, Facebook, VSCO, Pinterest, Substack
- 🎯 **Platform-tuned** — respects character limits, hashtag conventions, and audience tone per platform
- 🏷️ **Context-aware** — uses location, camera, lens, film stock, and subject info
- ✍️ **Voice matching** — adapts to photographer's style and brand

## Installation

```bash
clawhub install photo-captions
```

## Usage

```bash
Share a photo with context and the skill triggers automatically.
```

## Requirements

- OpenClaw agent

## License

MIT

## Links

- [ClawHub](https://clawhub.ai/pfrederiksen/photo-captions)
- [OpenClaw](https://openclaw.ai)
