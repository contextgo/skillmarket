"""
Twitter/X platform integration
"""
