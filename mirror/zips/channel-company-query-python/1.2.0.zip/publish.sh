#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd /home/gem/workspace/agent
NAME=$(node -e "console.log(require('$SCRIPT_DIR/package.json').displayName)")
VER=$(node -e "console.log(require('$SCRIPT_DIR/package.json').version)")
clawhub publish "$SCRIPT_DIR" --no-input --name "$NAME" --version "$VER"