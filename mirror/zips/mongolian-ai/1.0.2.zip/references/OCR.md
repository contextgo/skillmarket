# OCR `POST /ocr`

用于图片文字识别（默认内蒙语 `mn`）。

## 适用场景

- 用户上传图片、截图、拍照，要求识别文字
- 用户先要识别图片文字，再继续翻译或问答

## 请求体

```json
{
  "image_base64": "<图片Base64，可不带data:image前缀>",
  "language": "mn",
  "image_encoding": "jpg"
}
```

字段说明：

- `image_base64`：必填。支持纯 Base64 或 data URI（如 `data:image/jpeg;base64,...`）。
- `language`：可选，默认 `mn`。识别蒙文时保持 `mn`。
- `image_encoding`：可选，默认 `jpg`。常见值：`jpg`、`png`、`webp`、`bmp`、`tif`、`tiff`、`gif`。

## 响应提取

成功时只提取：

- `data.text`（首选，已解码文本）

可选辅助字段（不直接给用户展示，除非用户要求）：

- `data.lines`
- `data.raw`

## 辅助脚本（图片转请求字段）

可使用：

```bash
node scripts/image-to-base64.js --image ./sample.jpg --json
```

输出：

- `image_encoding`
- `image_base64`

可直接复制到 `/ocr` 请求体中。

## 输出约束（零泄漏）

- 默认最终可见回复只输出 `data.text` 原文；若使用 `mongolian-api.js ocr` 且未传 `--no-billing`，stdout 在正文后可能多一行 `[MENGGUYU_BILLING]…`（人民币扣费与余额），须向用户转述。
- 禁止输出请求体、原始 JSON、签名信息、模型信息、调试日志。
- 若用户要求“先识别再翻译”，流程应为：`/ocr` 提取文本后，再走 `/translation`。

