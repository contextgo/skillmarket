# mongolian-ai

OpenClaw Skill：中文、傳統蒙古文、西里爾蒙古文互譯，蒙文對話/創作、圖片 OCR。

## 能力

- `POST /translation`：純文字翻譯（`zh` / `mw` / `mn`，蒙蒙互譯由後台經中文中轉）
- `POST /chat/completions`：對話/創作
- `POST /ocr`：圖片 OCR（預設 `language=mn`）

## 路由優先級（每輪重判）

1. 圖片 OCR
2. 純文字翻譯
3. 中文回答蒙文
4. 蒙文回答蒙文
5. 預設蒙文對話

詳見 `references/INTERFACE-ROUTING.md`。

## 輸出規範（零洩漏）

成功後最終可見回覆只能輸出：

- `/translation` -> `data.tgtText`
- `/chat/completions` -> `response.choices[0].message.content`
- `/ocr` -> `data.text`

不得附加 JSON、工具輸出、路由解釋、模型名、token usage 等內容。

## API Key

主環境變數：`MENGGUYU_API_KEY`。發現階段不強依賴，業務調用前必須檢查。

缺失時固定提示：

```text
MENGGUYU_API_KEY 未配置。请按以下步骤操作：
1. 访问 https://mongol.open-idea.net 注册/登录账号
2. 进入后台 API Key 页面，创建并复制完整 Key（含前缀如 `1|xxxx...`）
3. 在本对话中发送以下命令配置密钥（替换为你的完整 Key）：
   openclaw config set env.MENGGUYU_API_KEY "<完整API Key>"
4. 配置后重启 Gateway 或重新开启 OpenClaw 会话，使环境变量生效
```

## 安裝與配置

```bash
clawhub install mongolian-ai
openclaw config set env.MENGGUYU_API_KEY "你的完整Key"
```

## 常用命令

```bash
# 翻譯
node scripts/mongolian-api.js translate --from zh --to mw --text "你好朋友"
node scripts/mongolian-api.js translate --from mn --to mw --text "Сайн байна уу"

# 對話
node scripts/mongolian-api.js chat --lang zh --text "中文回答我：ᠰᠠᠢᠢᠨ"

# OCR
node scripts/mongolian-api.js ocr --image ./sample.jpg --language mn
```

## 參考

- `SKILL.md`
- `references/INTERFACE-ROUTING.md`
- `references/BEHAVIOR-RULES.md`
- `references/TRANSLATION.md`
- `references/CHAT-COMPLETIONS.md`
- `references/OCR.md`
- `references/API-KEY.md`
