---
name: image-compress
description: This skill should be used whenever the user wants to compress, reduce, or optimize image files. Trigger when users say things like "compress this image", "reduce image size", "batch compress images", "convert image format", "resize and compress", "压缩图片", "批量压缩图片", "图片瘦身", "把图片压缩到XX KB以内", or ask to reduce file size of JPG/PNG/WebP/GIF files.
---

# Image Compress Skill

Compress and optimize image files with full control over quality, target file size, output format, and dimensions. Supports single images and batch directory processing.

## Supported Formats

JPEG, PNG, WebP, GIF, BMP, TIFF

## Script

The core script is located at: `scripts/compress_image.py`

Requires Pillow. If not installed, run: `pip install Pillow`

## Usage

```bash
python scripts/compress_image.py <input> [options]
```

### Key Options

| Option | Description | Default |
|--------|-------------|---------|
| `-o, --output <path>` | Output file or directory | `<name>_compressed.<ext>` next to input |
| `-q, --quality <1-95>` | JPEG/WebP quality | `85` |
| `-s, --max-size <KB>` | Target max file size in KB (auto-adjusts quality) | None |
| `-f, --format <fmt>` | Output format: `jpeg`, `png`, `webp`, `gif` | Keep original |
| `-w, --width <px>` | Resize width (preserves aspect ratio) | No resize |
| `-H, --height <px>` | Resize height (preserves aspect ratio) | No resize |
| `--batch` | Batch process all images in a directory | Off |
| `--no-overwrite` | Skip files that already exist at output path | Off |
| `-v, --verbose` | Show per-file size and quality info | Off |

## Common Workflows

### Compress a single image with quality control
```bash
python scripts/compress_image.py photo.jpg -q 80 -v
```

### Compress to a specific file size limit
```bash
python scripts/compress_image.py photo.jpg -s 200 -v
# → Automatically finds the highest quality that fits within 200 KB
```

### Convert PNG to WebP and compress
```bash
python scripts/compress_image.py image.png -f webp -q 85 -o output/
```

### Resize and compress
```bash
python scripts/compress_image.py photo.jpg -w 1920 -q 85 -o resized/
```

### Batch compress all images in a directory
```bash
python scripts/compress_image.py ./images/ --batch -q 80 -v
# → Outputs to ./images/compressed/
```

### Batch compress to target size and convert to WebP
```bash
python scripts/compress_image.py ./images/ --batch -f webp -s 300 -o ./webp_output/ -v
```

## Notes

- When the user asks to compress an image but does not specify quality or target size, default to `-q 85 -v`.
- When the user specifies a target size (e.g., "compress to under 500KB"), use `-s <KB>` which auto-finds the best quality.
- PNG compression is lossless; `-q` controls compress level, not visual quality.
- RGBA/transparent images saved as JPEG will be composited onto a white background automatically.
- Always use `-v` to show the user before/after file sizes and compression ratio.
- If Pillow is not installed, run `pip install Pillow` before executing the script.
