#!/usr/bin/env python3
"""
图片自定义压缩工具
用法:
  python compress_image.py <input> [options]

选项:
  -o, --output <path>      输出路径（文件或目录），默认在原目录生成 _compressed 文件
  -q, --quality <1-95>     JPEG/WebP 压缩质量，默认 85
  -s, --max-size <KB>      目标文件大小上限（KB），自动调节质量达到目标大小
  -f, --format <fmt>       输出格式: jpeg | png | webp | gif，默认保持原格式
  -w, --width <px>         输出宽度（保持宽高比缩放）
  -H, --height <px>        输出高度（保持宽高比缩放）
  --batch                  批量处理目录中所有图片
  --no-overwrite           跳过已存在的输出文件
  -v, --verbose            显示详细信息

示例:
  # 压缩单张图片，质量 80
  python compress_image.py photo.jpg -q 80

  # 压缩到 200KB 以内
  python compress_image.py photo.jpg -s 200

  # 批量压缩目录，转为 webp
  python compress_image.py ./images/ --batch -f webp -q 85

  # 缩放并压缩
  python compress_image.py photo.png -w 1920 -f jpeg -q 85 -o output/
"""

import argparse
import sys
import os
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("❌ 缺少依赖: Pillow")
    print("   请运行: pip install Pillow")
    sys.exit(1)

SUPPORTED_FORMATS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff", ".tif"}
FORMAT_MAP = {
    "jpeg": "JPEG",
    "jpg": "JPEG",
    "png": "PNG",
    "webp": "WEBP",
    "gif": "GIF",
}
FORMAT_EXT = {
    "JPEG": ".jpg",
    "PNG": ".png",
    "WEBP": ".webp",
    "GIF": ".gif",
}


def human_size(n_bytes: int) -> str:
    if n_bytes < 1024:
        return f"{n_bytes} B"
    elif n_bytes < 1024 ** 2:
        return f"{n_bytes/1024:.1f} KB"
    else:
        return f"{n_bytes/1024**2:.2f} MB"


def get_output_path(input_path: Path, output_arg: str | None, out_format: str | None) -> Path:
    """根据输入路径和参数推断输出路径"""
    ext = FORMAT_EXT.get(out_format, input_path.suffix) if out_format else input_path.suffix
    if not ext.startswith("."):
        ext = "." + ext

    if output_arg is None:
        return input_path.with_name(input_path.stem + "_compressed" + ext)

    out = Path(output_arg)
    if out.is_dir() or (not out.suffix and not out.exists()):
        out.mkdir(parents=True, exist_ok=True)
        return out / (input_path.stem + ext)
    return out


def compress_to_target_size(img: Image.Image, target_kb: int, out_format: str, quality_start: int = 92) -> tuple[bytes, int]:
    """二分法调节质量，使输出文件不超过 target_kb KB"""
    import io
    target_bytes = target_kb * 1024
    lo, hi = 1, quality_start
    best_data = None
    best_quality = lo

    # 先尝试最高质量
    buf = io.BytesIO()
    save_kwargs = build_save_kwargs(out_format, quality_start)
    img.save(buf, format=out_format, **save_kwargs)
    if buf.tell() <= target_bytes:
        return buf.getvalue(), quality_start

    # 二分搜索
    for _ in range(12):
        mid = (lo + hi) // 2
        buf = io.BytesIO()
        save_kwargs = build_save_kwargs(out_format, mid)
        img.save(buf, format=out_format, **save_kwargs)
        size = buf.tell()
        if size <= target_bytes:
            best_data = buf.getvalue()
            best_quality = mid
            lo = mid + 1
        else:
            hi = mid - 1
        if lo > hi:
            break

    if best_data is None:
        # 所有质量都超过目标，返回最低质量
        buf = io.BytesIO()
        save_kwargs = build_save_kwargs(out_format, 1)
        img.save(buf, format=out_format, **save_kwargs)
        best_data = buf.getvalue()
        best_quality = 1

    return best_data, best_quality


def build_save_kwargs(out_format: str, quality: int) -> dict:
    """构建 PIL save 参数"""
    kwargs = {}
    if out_format in ("JPEG", "WEBP"):
        kwargs["quality"] = quality
        kwargs["optimize"] = True
    elif out_format == "PNG":
        # PNG 无损，quality 映射到 compress_level (0-9)
        compress_level = max(0, min(9, 9 - int(quality / 11)))
        kwargs["compress_level"] = compress_level
        kwargs["optimize"] = True
    return kwargs


def resize_image(img: Image.Image, width: int | None, height: int | None) -> Image.Image:
    """按指定宽高缩放（保持宽高比）"""
    if width is None and height is None:
        return img
    orig_w, orig_h = img.size
    if width and height:
        img = img.resize((width, height), Image.LANCZOS)
    elif width:
        ratio = width / orig_w
        new_h = int(orig_h * ratio)
        img = img.resize((width, new_h), Image.LANCZOS)
    else:
        ratio = height / orig_h
        new_w = int(orig_w * ratio)
        img = img.resize((new_w, height), Image.LANCZOS)
    return img


def compress_one(
    input_path: Path,
    output_path: Path,
    quality: int,
    max_size_kb: int | None,
    out_format: str | None,
    width: int | None,
    height: int | None,
    no_overwrite: bool,
    verbose: bool,
) -> bool:
    """压缩单张图片，返回是否成功"""
    if no_overwrite and output_path.exists():
        if verbose:
            print(f"  ⏭  跳过 (已存在): {output_path}")
        return True

    try:
        img = Image.open(input_path)

        # 转换为 RGB（JPEG 不支持 RGBA/P 模式）
        target_fmt = out_format or FORMAT_MAP.get(input_path.suffix.lower().lstrip("."), "JPEG")
        if input_path.suffix.lower() in (".jpg", ".jpeg") and out_format is None:
            target_fmt = "JPEG"
        elif input_path.suffix.lower() == ".png" and out_format is None:
            target_fmt = "PNG"
        elif input_path.suffix.lower() == ".webp" and out_format is None:
            target_fmt = "WEBP"
        elif input_path.suffix.lower() == ".gif" and out_format is None:
            target_fmt = "GIF"

        # 如果目标是 JPEG 且图有透明通道，先合并到白底
        if target_fmt == "JPEG" and img.mode in ("RGBA", "LA", "P"):
            bg = Image.new("RGB", img.size, (255, 255, 255))
            if img.mode == "P":
                img = img.convert("RGBA")
            bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
            img = bg
        elif target_fmt != "PNG" and img.mode in ("P",):
            img = img.convert("RGB")

        # 缩放
        img = resize_image(img, width, height)

        orig_size = input_path.stat().st_size
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if max_size_kb is not None:
            data, used_quality = compress_to_target_size(img, max_size_kb, target_fmt, quality)
            output_path.write_bytes(data)
            new_size = len(data)
            if verbose:
                ratio = new_size / orig_size * 100
                print(f"  ✅ {input_path.name} → {output_path.name}  "
                      f"{human_size(orig_size)} → {human_size(new_size)} ({ratio:.0f}%)  "
                      f"质量={used_quality}")
        else:
            save_kwargs = build_save_kwargs(target_fmt, quality)
            img.save(output_path, format=target_fmt, **save_kwargs)
            new_size = output_path.stat().st_size
            if verbose:
                ratio = new_size / orig_size * 100
                print(f"  ✅ {input_path.name} → {output_path.name}  "
                      f"{human_size(orig_size)} → {human_size(new_size)} ({ratio:.0f}%)  "
                      f"质量={quality}")
        return True

    except Exception as e:
        print(f"  ❌ 处理失败 {input_path.name}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="图片自定义压缩工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("input", help="输入图片文件或目录")
    parser.add_argument("-o", "--output", default=None, help="输出路径（文件或目录）")
    parser.add_argument("-q", "--quality", type=int, default=85, help="JPEG/WebP 压缩质量 1-95（默认 85）")
    parser.add_argument("-s", "--max-size", type=int, default=None, metavar="KB",
                        help="目标文件大小上限（KB）")
    parser.add_argument("-f", "--format", default=None, choices=list(FORMAT_MAP.keys()),
                        help="输出格式（默认保持原格式）")
    parser.add_argument("-w", "--width", type=int, default=None, help="输出宽度（像素，保持宽高比）")
    parser.add_argument("-H", "--height", type=int, default=None, help="输出高度（像素，保持宽高比）")
    parser.add_argument("--batch", action="store_true", help="批量处理目录中所有图片")
    parser.add_argument("--no-overwrite", action="store_true", help="跳过已存在的输出文件")
    parser.add_argument("-v", "--verbose", action="store_true", help="显示详细信息")

    args = parser.parse_args()

    # 验证质量参数
    if not 1 <= args.quality <= 95:
        print("❌ 质量参数必须在 1~95 之间")
        sys.exit(1)

    out_format = FORMAT_MAP.get(args.format) if args.format else None
    input_path = Path(args.input)

    if not input_path.exists():
        print(f"❌ 输入路径不存在: {input_path}")
        sys.exit(1)

    # 批量模式
    if input_path.is_dir() or args.batch:
        if not input_path.is_dir():
            print(f"❌ --batch 模式下输入必须是目录")
            sys.exit(1)

        files = [f for f in input_path.iterdir()
                 if f.suffix.lower() in SUPPORTED_FORMATS and f.is_file()]

        if not files:
            print(f"⚠️  目录中未找到支持的图片文件: {input_path}")
            sys.exit(0)

        print(f"🖼  批量压缩 {len(files)} 张图片...")
        success = 0
        for f in sorted(files):
            ext = FORMAT_EXT.get(out_format, f.suffix) if out_format else f.suffix
            out_dir = Path(args.output) if args.output else input_path / "compressed"
            out_dir.mkdir(parents=True, exist_ok=True)
            out_file = out_dir / (f.stem + ext)
            if compress_one(f, out_file, args.quality, args.max_size, out_format,
                            args.width, args.height, args.no_overwrite, True):
                success += 1

        print(f"\n✨ 完成！成功 {success}/{len(files)} 张，输出目录: {out_dir}")

    else:
        # 单文件模式
        if input_path.suffix.lower() not in SUPPORTED_FORMATS:
            print(f"❌ 不支持的文件格式: {input_path.suffix}")
            print(f"   支持格式: {', '.join(SUPPORTED_FORMATS)}")
            sys.exit(1)

        output_path = get_output_path(input_path, args.output, out_format)
        print(f"🖼  压缩: {input_path.name}")
        success = compress_one(input_path, output_path, args.quality, args.max_size,
                               out_format, args.width, args.height, args.no_overwrite, True)
        if success:
            print(f"✨ 完成！输出: {output_path}")
        else:
            sys.exit(1)


if __name__ == "__main__":
    main()
