# Weekly-Monthly Reporter

**周报月报生成器** — 输入本周/月工作内容，AI 自动整理成结构清晰、重点突出的周报/月报，可直接发给领导。

> 一句话：纯文本粘贴 → AI 结构化 → 专业周报/月报输出

## ✨ 功能套餐

| 功能 | Free | Std ¥9.9 | Pro ¥29.9 | Max ¥99 |
|------|------|---------|-----------|---------|
| 生成次数 | 5次（不清零） | 30次/月 | 100次/月 | 不限 |
| 输入方式 | 文字粘贴 | 文字+文件 | 文字+文件+飞书任务 | 全部 |
| 输出格式 | Markdown | Markdown+Word | Markdown+Word+PDF | 全部 |
| 历史记录 | ❌ | 30天 | 6个月 | 12个月 |
| 自定义模板 | ❌ | ✅ | ✅ | ✅ |
| API访问 | ❌ | ❌ | ✅ | ✅ |

## 🚀 快速开始

### 安装

```bash
pip install -r requirements.txt
```

### 生成周报

```bash
python -m scripts.main generate \
  --content "本周完成了A项目第一阶段开发，B客户需求对接，修复了3个线上bug" \
  --api-key YOUR_TOKEN_KEY \
  --llm-key YOUR_OPENAI_KEY
```

### 生成月报

```bash
python -m scripts.main generate \
  --type monthly \
  --style detailed \
  --file monthly_work.md \
  --api-key YOUR_TOKEN_KEY
```

## 📖 使用指南

### 输入方式

**1. 文字粘贴（全部版本）**
```
--content "今天完成了XX项目..."
```

**2. 文件上传（Std及以上）**
```
--file worklog.md  # 支持 TXT 和 Markdown
```

**3. 飞书任务（Pro及以上）**
自动读取已完成的飞书任务列表作为工作内容。

### 风格选择

| 风格 | 适用场景 |
|------|----------|
| 简洁版 | 快速简报、常规更新 |
| 详细版 | 完整总结、复盘汇报 |
| 领导版 | 管理层汇报、战略汇报 |
| 自评版 | 绩效自评、述职报告 |

### 续写功能

```bash
# 接着上一份报告继续写
python -m scripts.main generate \
  --continue-from REPORT_ID \
  --content "新增的工作内容..." \
  --api-key YOUR_TOKEN_KEY
```

### 输出格式

```bash
# Markdown（直接复制）
python -m scripts.main generate -c "内容..." -k KEY

# Word 文档
python -m scripts.main generate -c "内容..." -k KEY --format word --output report.docx

# PDF 文档
python -m scripts.main generate -c "内容..." -k KEY --format pdf --output report.pdf
```

## 📊 周报结构示例

```markdown
## 本周工作总结
[核心3件事]

## 重点工作进展
- 🔴 项目A：完成了XX，正在推进XX
- 🟡 项目B：遇到XX问题，计划XX解决

## 下周工作计划
- 优先级1：...
- 优先级2：...

## 需要协调/支援的事
[如有]

## KPI达成情况
[如有]
```

## 🔧 API Key 配置

### Token Key（必须）

从 YK-Global.com 获取，格式：`RPT-WEEKLY-*`

```bash
python -m scripts.main validate -k YOUR_TOKEN_KEY
```

### LLM Key（用于生成）

用户自配，支持 OpenAI GPT-4/GPT-3.5 或兼容 API。

## 💾 本地存储

- **历史记录**：`~/.weekly_reporter/history/`
- **Token缓存**：`~/.weekly_reporter/token_cache.json`
- **上传文件**：`~/.weekly_reporter/uploads/`

## 🛠️ CLI 命令

```bash
# 生成报告
python -m scripts.main generate [选项]

# 查看历史
python -m scripts.main history -k YOUR_KEY

# 检查状态
python -m scripts.main status -k YOUR_KEY

# 验证Token
python -m scripts.main validate -k YOUR_KEY
```

## 📦 Python API

```python
from scripts.report_generator import ReportGenerator
from scripts.templates import ReportType, ReportStyle

generator = ReportGenerator(api_key="llm_key")
result = generator.generate_report(
    work_content="本周工作...",
    report_type=ReportType.WEEKLY,
    style=ReportStyle.CONCISE,
    api_key="token_key"
)

if result["success"]:
    print(result["report"])
```

## 🔌 飞书集成

| 功能 | 所需版本 |
|------|----------|
| 读取已完成任务 | Pro / Max |
| 推送消息卡片 | Max |

需要飞书开放平台应用权限配置。

## 📋 依赖

```
requests>=2.28.0
python-docx>=0.8.11
reportlab>=4.0.0
```

---

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)
