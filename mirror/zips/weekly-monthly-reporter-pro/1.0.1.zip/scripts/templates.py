"""
Report templates for Weekly-Monthly Reporter.
"""

from typing import Dict, List, Optional
from enum import Enum


class ReportStyle(Enum):
    """Report style options."""
    CONCISE = "简洁版"
    DETAILED = "详细版"
    LEADERSHIP = "领导版"
    SELF_REVIEW = "自评版"


class ReportType(Enum):
    """Report type."""
    WEEKLY = "weekly"
    MONTHLY = "monthly"


# Default templates for weekly reports
WEEKLY_TEMPLATE_CONCISE = """## 本周工作总结
{summary}

## 重点工作进展
{highlights}

## 下周工作计划
{next_week}

## 需要协调/支援的事
{support_needed}
"""

WEEKLY_TEMPLATE_DETAILED = """## 本周工作总结
{summary}

## 重点工作进展
{highlights}

## KPI达成情况
{kpi}

## 下周工作计划
{next_week}

## 需要协调/支援的事
{support_needed}

## 学习与成长
{growth}
"""

WEEKLY_TEMPLATE_LEADERSHIP = """## 📊 本周工作概览
{summary}

## 🎯 核心成果
{highlights}

## 📈 KPI追踪
{kpi}

## 🔮 下周重点规划
{next_week}

## ⚠️ 风险与挑战
{risks}

## 🤝 需要支持事项
{support_needed}
"""

WEEKLY_TEMPLATE_SELF_REVIEW = """## 本周工作总结
{summary}

## 核心成就
{highlights}

## KPI完成情况
{kpi}

## 改进空间
{improvements}

## 下周目标
{next_week}

## 学习心得
{growth}
"""

# Monthly report templates (with trend analysis)
MONTHLY_TEMPLATE_CONCISE = """## {month}月工作总结

### 本月核心成果
{summary}

### 重点工作进展
{highlights}

### 月度KPI汇总
{kpi}

### 趋势分析
{trend}

### 下月工作计划
{next_month}

### 需要协调/支援的事
{support_needed}
"""

MONTHLY_TEMPLATE_DETAILED = """## {month}月工作总结

### 📌 本月核心成果
{summary}

### 🎯 重点工作进展
{highlights}

### 📊 KPI达成情况
{kpi}

### 📈 趋势分析
{trend}

### ⚠️ 遇到的问题与解决方案
{problems}

### 🔮 下月工作计划
{next_month}

### 🤝 需要协调/支援的事
{support_needed}

### 💡 经验沉淀
{lessons}
"""

MONTHLY_TEMPLATE_LEADERSHIP = """## {month}月工作汇报

### Executive Summary
{summary}

### 核心业务进展
{highlights}

### KPI Dashboard
{kpi}

### 趋势洞察
{trend}

### 风险预警
{risks}

### 下月重点任务
{next_month}

### 资源需求
{support_needed}
"""

MONTHLY_TEMPLATE_SELF_REVIEW = """## {month}月工作总结

### 本月主要工作
{summary}

### 核心成就 (Kudos)
{highlights}

### KPI自评
{kpi}

### 成长与收获
{growth}

### 待改进之处
{improvements}

### 下月目标设定
{next_month}
"""


def get_template(report_type: ReportType, style: ReportStyle) -> str:
    """Get the appropriate template based on report type and style."""
    if report_type == ReportType.WEEKLY:
        templates = {
            ReportStyle.CONCISE: WEEKLY_TEMPLATE_CONCISE,
            ReportStyle.DETAILED: WEEKLY_TEMPLATE_DETAILED,
            ReportStyle.LEADERSHIP: WEEKLY_TEMPLATE_LEADERSHIP,
            ReportStyle.SELF_REVIEW: WEEKLY_TEMPLATE_SELF_REVIEW,
        }
    else:  # MONTHLY
        templates = {
            ReportStyle.CONCISE: MONTHLY_TEMPLATE_CONCISE,
            ReportStyle.DETAILED: MONTHLY_TEMPLATE_DETAILED,
            ReportStyle.LEADERSHIP: MONTHLY_TEMPLATE_LEADERSHIP,
            ReportStyle.SELF_REVIEW: MONTHLY_TEMPLATE_SELF_REVIEW,
        }
    
    return templates.get(style, WEEKLY_TEMPLATE_CONCISE)


def get_default_sections(report_type: ReportType) -> List[str]:
    """Get default sections for a report type."""
    if report_type == ReportType.WEEKLY:
        return ["summary", "highlights", "next_week", "support_needed"]
    else:
        return ["summary", "highlights", "kpi", "trend", "next_month", "support_needed"]


def build_prompt(work_content: str, report_type: ReportType, style: ReportStyle, 
                 previous_report: Optional[str] = None, custom_template: Optional[str] = None) -> str:
    """
    Build AI prompt for report generation.
    
    Args:
        work_content: Raw work content from user
        report_type: WEEKLY or MONTHLY
        style: Report style
        previous_report: Optional previous report for continuation
        custom_template: Optional custom template
        
    Returns:
        Formatted prompt string for AI
    """
    style_names = {
        ReportStyle.CONCISE: "简洁版",
        ReportStyle.DETAILED: "详细版",
        ReportStyle.LEADERSHIP: "领导版",
        ReportStyle.SELF_REVIEW: "自评版"
    }
    
    style_name = style_names.get(style, "简洁版")
    report_name = "周报" if report_type == ReportType.WEEKLY else "月报"
    
    prompt = f"""你是一位专业的行政助理，负责将用户的工作内容整理成结构清晰的{report_name}。

请根据以下工作内容，生成一份【{style_name}】{report_name}。

## 工作内容（原始输入）：
{work_content}

"""
    
    if previous_report:
        prompt += f"""
## 上一期{report_name}（用于追加续写）：
{previous_report}

请在上一期基础上继续，补充新的工作内容，保持风格一致。
"""

    if custom_template:
        prompt += f"""
## 自定义模板：
{custom_template}
"""
    else:
        template = get_template(report_type, style)
        prompt += f"""
## 模板结构：
{template}

请严格按上述结构生成{report_name}，内容要：
1. 突出核心成果，使用 🔴 🟡 🟢 等emoji标记优先级
2. 数据具体，尽量量化
3. 语言专业、简洁、有条理
4. {report_name}中需要体现与上期工作的衔接（如果是续写）
"""

    return prompt
