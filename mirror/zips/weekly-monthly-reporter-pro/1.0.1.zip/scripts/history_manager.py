"""
History management module for Weekly-Monthly Reporter.
Handles local JSON storage of report history.
"""

import json
import os
from pathlib import Path
from typing import List, Optional, Dict
from datetime import datetime, timedelta


class HistoryManager:
    """Manage report history storage."""
    
    def __init__(self, history_dir: Optional[Path] = None, max_days: int = 0):
        """
        Initialize history manager.
        
        Args:
            history_dir: Directory to store history (default: ~/.weekly_reporter/history)
            max_days: Maximum days to retain history (0 = no limit based on tier)
        """
        self._history_dir = history_dir or Path.home() / ".weekly_reporter" / "history"
        self._history_dir.mkdir(parents=True, exist_ok=True)
        self._index_file = self._history_dir / "index.json"
        self.max_days = max_days
        
    def _load_index(self) -> Dict:
        """Load history index."""
        if not self._index_file.exists():
            return {"reports": []}
        try:
            with open(self._index_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"reports": []}
    
    def _save_index(self, index: Dict) -> None:
        """Save history index."""
        with open(self._index_file, "w", encoding="utf-8") as f:
            json.dump(index, f, ensure_ascii=False, indent=2)
    
    def _get_report_file(self, report_id: str) -> Path:
        """Get path to report file."""
        return self._history_dir / f"{report_id}.json"
    
    def save_report(
        self,
        report: str,
        report_type: str,
        style: str,
        api_key: str,
        input_preview: str = "",
        tier: str = "RPT-WEEKLY-FREE"
    ) -> str:
        """
        Save a generated report to history.
        
        Args:
            report: Generated report content
            report_type: "weekly" or "monthly"
            style: Style used for generation
            api_key: User's API key (hashed for storage)
            input_preview: Preview of input content
            tier: User's tier for retention policy
            
        Returns:
            Report ID
        """
        import hashlib
        key_hash = hashlib.md5(api_key.encode()).hexdigest()[:12]
        
        # Generate report ID
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        report_id = f"{key_hash}_{timestamp}"
        
        # Save report data
        report_data = {
            "id": report_id,
            "created_at": datetime.now().isoformat(),
            "report_type": report_type,
            "style": style,
            "content": report,
            "input_preview": input_preview[:200] if input_preview else "",
            "tier": tier
        }
        
        report_file = self._get_report_file(report_id)
        with open(report_file, "w", encoding="utf-8") as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        # Update index
        index = self._load_index()
        index["reports"].insert(0, {
            "id": report_id,
            "created_at": report_data["created_at"],
            "report_type": report_type,
            "style": style,
            "preview": input_preview[:100] if input_preview else ""
        })
        self._save_index(index)
        
        # Cleanup old reports based on tier retention
        self._cleanup_old_reports(tier)
        
        return report_id
    
    def _cleanup_old_reports(self, tier: str) -> None:
        """Remove reports older than retention period."""
        retention_days = {
            "RPT-WEEKLY-FREE": 0,  # No history
            "RPT-WEEKLY-STD": 30,
            "RPT-WEEKLY-PRO": 180,
            "RPT-WEEKLY-MAX": 365
        }
        
        days = retention_days.get(tier, 0)
        if days == 0:
            return
        
        cutoff = datetime.now() - timedelta(days=days)
        index = self._load_index()
        valid_reports = []
        
        for report_entry in index["reports"]:
            created = datetime.fromisoformat(report_entry["created_at"])
            if created >= cutoff:
                valid_reports.append(report_entry)
            else:
                # Delete the file
                report_file = self._get_report_file(report_entry["id"])
                if report_file.exists():
                    report_file.unlink()
        
        index["reports"] = valid_reports
        self._save_index(index)
    
    def get_report(self, report_id: str) -> Optional[Dict]:
        """Get a specific report by ID."""
        report_file = self._get_report_file(report_id)
        if not report_file.exists():
            return None
        try:
            with open(report_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
    
    def list_reports(self, api_key: str, limit: int = 10, offset: int = 0) -> List[Dict]:
        """
        List reports for a user.
        
        Args:
            api_key: User's API key
            limit: Max reports to return
            offset: Offset for pagination
            
        Returns:
            List of report metadata
        """
        import hashlib
        key_hash = hashlib.md5(api_key.encode()).hexdigest()[:12]
        
        index = self._load_index()
        user_reports = [
            r for r in index["reports"] 
            if r["id"].startswith(key_hash)
        ]
        
        return user_reports[offset:offset + limit]
    
    def get_latest_report(self, api_key: str, report_type: Optional[str] = None) -> Optional[Dict]:
        """
        Get the most recent report.
        
        Args:
            api_key: User's API key
            report_type: Optional filter by type ("weekly" or "monthly")
            
        Returns:
            Latest report data or None
        """
        reports = self.list_reports(api_key, limit=100)
        
        for r in reports:
            if report_type and r.get("report_type") != report_type:
                continue
            return self.get_report(r["id"])
        
        return None
    
    def delete_report(self, report_id: str, api_key: str) -> bool:
        """
        Delete a specific report.
        
        Args:
            report_id: Report ID to delete
            api_key: User's API key (for ownership verification)
            
        Returns:
            True if deleted, False otherwise
        """
        import hashlib
        key_hash = hashlib.md5(api_key.encode()).hexdigest()[:12]
        
        if not report_id.startswith(key_hash):
            return False
        
        report_file = self._get_report_file(report_id)
        if report_file.exists():
            report_file.unlink()
        
        # Update index
        index = self._load_index()
        index["reports"] = [r for r in index["reports"] if r["id"] != report_id]
        self._save_index(index)
        
        return True
    
    def get_usage_stats(self, api_key: str) -> Dict:
        """Get usage statistics for a user."""
        import hashlib
        key_hash = hashlib.md5(api_key.encode()).hexdigest()[:12]
        
        usage_file = self._history_dir / f"{key_hash}.json"
        if usage_file.exists():
            try:
                with open(usage_file, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        
        return {"count": 0, "month": datetime.now().strftime("%Y-%m")}
