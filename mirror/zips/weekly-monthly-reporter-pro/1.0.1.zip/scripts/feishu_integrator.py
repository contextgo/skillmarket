"""
Feishu integration module for Weekly-Monthly Reporter.
Handles Feishu task reading and IM message sending.
"""

import json
from typing import Dict, List, Optional, Any


class FeishuTaskReader:
    """Read completed tasks from Feishu."""
    
    def __init__(self, feishu_token: Optional[str] = None):
        """
        Initialize Feishu task reader.
        
        Args:
            feishu_token: Feishu user access token (for task API)
        """
        self.feishu_token = feishu_token
        self._base_url = "https://open.feishu.cn/open-apis"
    
    def get_completed_tasks(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        page_size: int = 50
    ) -> List[Dict]:
        """
        Get completed tasks for the user.
        
        This is a placeholder that would integrate with Feishu Task API.
        In production, this requires OAuth and proper API setup.
        
        Args:
            start_time: ISO 8601 start time
            end_time: ISO 8601 end time
            page_size: Number of tasks to return
            
        Returns:
            List of task dictionaries
        """
        # Note: This requires actual Feishu OAuth integration
        # The actual implementation would call:
        # GET https://open.feishu.cn/open-apis/task/v2/tasks
        
        # For now, return empty list - integration requires:
        # 1. User OAuth flow to get access token
        # 2. Proper scope: task:task:readonly
        # 3. Pagination handling
        
        return []
    
    def parse_tasks_for_report(self, tasks: List[Dict]) -> str:
        """
        Parse task list into report-friendly format.
        
        Args:
            tasks: List of task dictionaries
            
        Returns:
            Formatted task list string
        """
        if not tasks:
            return "（本周无已完成任务）"
        
        lines = []
        for i, task in enumerate(tasks, 1):
            title = task.get("summary", task.get("title", "未命名任务"))
            completed_at = task.get("completed_at", "")
            if completed_at:
                from datetime import datetime
                try:
                    dt = datetime.fromisoformat(completed_at.replace("Z", "+00:00"))
                    completed_at = dt.strftime("%Y-%m-%d")
                except Exception:
                    pass
            lines.append(f"{i}. {title}（完成于: {completed_at}）")
        
        return "\n".join(lines)


class FeishuIM:
    """Send messages via Feishu IM."""
    
    def __init__(self, bot_token: Optional[str] = None):
        """
        Initialize Feishu IM client.
        
        Args:
            bot_token: Feishu bot token
        """
        self.bot_token = bot_token
        self._base_url = "https://open.feishu.cn/open-apis"
    
    def send_card_message(
        self,
        receive_id: str,
        receive_id_type: str,
        content: str,
        msg_type: str = "interactive"
    ) -> Dict:
        """
        Send an interactive card message.
        
        Args:
            receive_id: Recipient ID (open_id or chat_id)
            receive_id_type: "open_id" or "chat_id"
            content: Report content to send
            msg_type: Message type
            
        Returns:
            API response dict
        """
        # Build interactive card content
        card = self._build_report_card(content)
        
        payload = {
            "receive_id": receive_id,
            "receive_id_type": receive_id_type,
            "msg_type": "interactive",
            "content": json.dumps(card)
        }
        
        headers = {
            "Authorization": f"Bearer {self.bot_token}",
            "Content-Type": "application/json"
        }
        
        import requests
        response = requests.post(
            f"{self._base_url}/im/v1/messages",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        return response.json()
    
    def _build_report_card(self, report_content: str) -> Dict:
        """
        Build Feishu interactive card from report content.
        
        Args:
            report_content: The generated report markdown
            
        Returns:
            Card JSON structure
        """
        # Simple card with report content
        return {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": "📊 周报/月报"
                },
                "template": "blue"
            },
            "elements": [
                {
                    "tag": "markdown",
                    "content": report_content
                },
                {
                    "tag": "hr"
                },
                {
                    "tag": "note",
                    "elements": [
                        {
                            "tag": "plain_text",
                            "content": "由 Weekly-Monthly Reporter 生成"
                        }
                    ]
                }
            ]
        }


def format_feishu_task_list(tasks_response: Any) -> str:
    """
    Format Feishu task API response into work content.
    
    Args:
        tasks_response: Response from Feishu task API
        
    Returns:
        Formatted task list string
    """
    if not tasks_response:
        return ""
    
    try:
        tasks = tasks_response.get("items", tasks_response.get("data", {}).get("items", []))
    except Exception:
        return ""
    
    lines = []
    for task in tasks:
        summary = task.get("summary", "未命名任务")
        status = task.get("status", {})
        completed = status.get("completed", False)
        done_str = "✓ 已完成" if completed else "○ 进行中"
        lines.append(f"- {summary} [{done_str}]")
    
    return "\n".join(lines) if lines else ""
