"""
AI Report Generation module for Weekly-Monthly Reporter.
Handles LLM API calls for generating structured reports.
"""

import json
import time
import hashlib
import requests
from pathlib import Path
from typing import Dict, Optional, List, Tuple
from datetime import datetime

from .templates import ReportType, ReportStyle, build_prompt, get_template
from .token_validator import validate_token, check_generation_limit, TIERS


class ReportGenerator:
    """Main report generation class."""
    
    def __init__(self, api_key: Optional[str] = None, api_endpoint: Optional[str] = None, 
                 model: str = "gpt-4"):
        """
        Initialize the report generator.
        
        Args:
            api_key: LLM API key (if None, will try to load from config)
            api_endpoint: LLM API endpoint (default: OpenAI compatible)
            model: Model to use for generation
        """
        self.api_key = api_key
        self.api_endpoint = api_endpoint or "https://api.openai.com/v1/chat/completions"
        self.model = model
        
        # Load generation count from history
        self._history_dir = Path.home() / ".weekly_reporter" / "history"
        self._history_dir.mkdir(parents=True, exist_ok=True)
        
    def _load_usage(self, api_key: str) -> Tuple[int, str]:
        """Load usage count and current month for a key."""
        usage_file = self._history_dir / f"{self._get_key_hash(api_key)}.json"
        if usage_file.exists():
            try:
                with open(usage_file, "r") as f:
                    data = json.load(f)
                    current_month = datetime.now().strftime("%Y-%m")
                    if data.get("month") == current_month:
                        return data.get("count", 0), current_month
            except Exception:
                pass
        return 0, datetime.now().strftime("%Y-%m")
    
    def _save_usage(self, api_key: str, count: int, month: str) -> None:
        """Save usage count."""
        usage_file = self._history_dir / f"{self._get_key_hash(api_key)}.json"
        with open(usage_file, "w") as f:
            json.dump({"count": count, "month": month}, f)
    
    def _get_key_hash(self, api_key: str) -> str:
        """Get a hash of the API key for file naming."""
        return hashlib.md5(api_key.encode()).hexdigest()[:12]
    
    def _call_llm(self, prompt: str, temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """
        Call LLM API to generate report.
        
        Args:
            prompt: Formatted prompt
            temperature: Sampling temperature
            max_tokens: Max tokens in response
            
        Returns:
            Generated report text
        """
        if not self.api_key:
            raise ValueError("API key not configured. Please set your LLM API key.")
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "你是一位专业的行政助理，擅长整理工作内容、生成结构清晰的周报和月报。"},
                {"role": "user", "content": prompt}
            ],
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        response = requests.post(
            self.api_endpoint,
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code != 200:
            raise Exception(f"API call failed: {response.status_code} - {response.text}")
        
        data = response.json()
        return data["choices"][0]["message"]["content"]
    
    def generate_report(
        self,
        work_content: str,
        report_type: ReportType,
        style: ReportStyle,
        api_key: str,
        previous_report: Optional[str] = None,
        custom_template: Optional[str] = None
    ) -> Dict:
        """
        Generate a report from work content.
        
        Args:
            work_content: Raw work content
            report_type: WEEKLY or MONTHLY
            style: Report style
            api_key: Token for validation and usage tracking
            previous_report: Optional previous report for continuation
            custom_template: Optional custom template
            
        Returns:
            Dict with keys: success (bool), report (str), error (str or None)
        """
        # Validate token
        validation = validate_token(api_key)
        if not validation["valid"]:
            return {
                "success": False,
                "report": None,
                "error": f"Invalid API key: {validation.get('error', 'Unknown error')}"
            }
        
        # Check generation limit
        current_count, current_month = self._load_usage(api_key)
        tier = validation["tier"]
        
        if not check_generation_limit(api_key, current_count):
            return {
                "success": False,
                "report": None,
                "error": f"Generation limit reached for {tier} tier. Limit: {TIERS[tier]['generations']}/month. Please upgrade or wait until next month."
            }
        
        # Build prompt and generate
        try:
            prompt = build_prompt(work_content, report_type, style, previous_report, custom_template)
            report = self._call_llm(prompt)
            
            # Increment usage count
            self._save_usage(api_key, current_count + 1, current_month)
            
            return {
                "success": True,
                "report": report,
                "error": None,
                "usage": {
                    "tier": tier,
                    "used": current_count + 1,
                    "limit": TIERS[tier]["generations"]
                }
            }
        except Exception as e:
            return {
                "success": False,
                "report": None,
                "error": f"Report generation failed: {str(e)}"
            }
    
    def parse_work_input(self, input_data: str, input_type: str) -> str:
        """
        Parse various input formats into unified work content.
        
        Args:
            input_data: Raw input data
            input_type: Type of input ("text", "file", "feishu_task")
            
        Returns:
            Parsed work content string
        """
        if input_type == "text":
            return input_data.strip()
        elif input_type == "file":
            # File content is already read
            return input_data.strip()
        elif input_type == "feishu_task":
            # Parse Feishu task list into text format
            return self._parse_feishu_tasks(input_data)
        else:
            return input_data.strip()
    
    def _parse_feishu_tasks(self, tasks_json: str) -> str:
        """Parse Feishu task list JSON into work content format."""
        try:
            tasks = json.loads(tasks_json)
            if isinstance(tasks, list):
                lines = []
                for i, task in enumerate(tasks, 1):
                    title = task.get("summary", task.get("title", "未命名任务"))
                    status = task.get("status", "completed")
                    done = task.get("completed_at") or task.get("done", True)
                    lines.append(f"{i}. {title} - {'已完成' if done else '进行中'}")
                return "\n".join(lines)
        except json.JSONDecodeError:
            pass
        return tasks_json
