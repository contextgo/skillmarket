"""
Document generation module for Weekly-Monthly Reporter.
Generates Word (.docx) and PDF files from reports.
"""

import os
import io
from pathlib import Path
from typing import Optional
from datetime import datetime


class WordGenerator:
    """Generate Word (.docx) documents from reports."""
    
    def __init__(self):
        """Initialize Word generator."""
        self._docx_available = True
        try:
            from docx import Document
            from docx.shared import Pt, RGBColor
            self.Document = Document
            self.Pt = Pt
            self.RGBColor = RGBColor
        except ImportError:
            self._docx_available = False
    
    def generate(self, report_content: str, title: Optional[str] = None) -> bytes:
        """
        Generate Word document from report.
        
        Args:
            report_content: Report markdown content
            title: Optional document title
            
        Returns:
            Bytes of the Word document
        """
        if not self._docx_available:
            raise ImportError("python-docx is required for Word generation. Install with: pip install python-docx")
        
        doc = self.Document()
        
        # Set document style
        style = doc.styles["Normal"]
        style.font.name = "Microsoft YaHei"
        style.font.size = self.Pt(11)
        
        # Add title
        if title:
            heading = doc.add_heading(title, 0)
            heading.style.font.name = "Microsoft YaHei"
        
        # Parse markdown and convert to Word
        lines = report_content.split("\n")
        
        for line in lines:
            stripped = line.strip()
            
            if not stripped:
                doc.add_paragraph()
                continue
            
            # Headers
            if stripped.startswith("## "):
                doc.add_heading(stripped[3:], level=2)
            elif stripped.startswith("# "):
                doc.add_heading(stripped[2:], level=1)
            elif stripped.startswith("### "):
                doc.add_heading(stripped[4:], level=3)
            # List items
            elif stripped.startswith("- ") or stripped.startswith("* "):
                p = doc.add_paragraph(stripped[2:], style="List Bullet")
            elif stripped.startswith("-"):
                p = doc.add_paragraph(stripped[1:].strip(), style="List Bullet")
            # Regular text
            else:
                # Clean up markdown formatting
                clean_line = self._clean_markdown(stripped)
                doc.add_paragraph(clean_line)
        
        # Save to bytes
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        return buffer.getvalue()
    
    def _clean_markdown(self, text: str) -> str:
        """Remove or convert markdown formatting."""
        # Remove bold/italic markers
        text = text.replace("**", "").replace("*", "")
        # Remove inline code
        text = text.replace("`", "")
        return text
    
    def save(self, report_content: str, output_path: str, title: Optional[str] = None) -> str:
        """
        Generate and save Word document.
        
        Args:
            report_content: Report content
            output_path: Output file path
            title: Optional document title
            
        Returns:
            Path to saved file
        """
        content = self.generate(report_content, title)
        with open(output_path, "wb") as f:
            f.write(content)
        return output_path


class PDFGenerator:
    """Generate PDF documents from reports."""
    
    def __init__(self):
        """Initialize PDF generator."""
        self._reportlab_available = True
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import ParagraphStyle
            from reportlab.lib.units import mm
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
            from reportlab.lib.enums import TA_LEFT, TA_CENTER
            self.A4 = A4
            self.ParagraphStyle = ParagraphStyle
            self.mm = mm
            self.SimpleDocTemplate = SimpleDocTemplate
            self.Paragraph = Paragraph
            self.Spacer = Spacer
            self.HRFlowable = HRFlowable
            self.TA_LEFT = TA_LEFT
            self.TA_CENTER = TA_CENTER
        except ImportError:
            self._reportlab_available = False
    
    def generate(self, report_content: str, title: Optional[str] = None) -> bytes:
        """
        Generate PDF from report.
        
        Args:
            report_content: Report markdown content
            title: Optional document title
            
        Returns:
            Bytes of the PDF
        """
        if not self._reportlab_available:
            raise ImportError("reportlab is required for PDF generation. Install with: pip install reportlab")
        
        buffer = io.BytesIO()
        
        doc = SimpleDocTemplate(
            buffer,
            pagesize=self.A4,
            rightMargin=20*self.mm,
            leftMargin=20*self.mm,
            topMargin=20*self.mm,
            bottomMargin=20*self.mm
        )
        
        # Define styles
        styles = {
            "title": self.ParagraphStyle(
                "Title",
                fontSize=18,
                leading=24,
                alignment=self.TA_CENTER,
                spaceAfter=20
            ),
            "h1": self.ParagraphStyle(
                "H1",
                fontSize=14,
                leading=18,
                spaceBefore=15,
                spaceAfter=10,
                textColor=(51, 102, 153)
            ),
            "h2": self.ParagraphStyle(
                "H2",
                fontSize=12,
                leading=16,
                spaceBefore=12,
                spaceAfter=8,
                textColor=(51, 102, 153)
            ),
            "normal": self.ParagraphStyle(
                "Normal",
                fontSize=10,
                leading=14,
                spaceAfter=6
            ),
            "bullet": self.ParagraphStyle(
                "Bullet",
                fontSize=10,
                leading=14,
                leftIndent=20,
                spaceAfter=4
            )
        }
        
        story = []
        
        # Add title
        if title:
            story.append(self.Paragraph(title, styles["title"]))
        
        # Parse and add content
        lines = report_content.split("\n")
        for line in lines:
            stripped = line.strip()
            
            if not stripped:
                story.append(self.Spacer(1, 6))
                continue
            
            # Headers
            if stripped.startswith("## "):
                story.append(self.Paragraph(stripped[3:], styles["h2"]))
            elif stripped.startswith("# "):
                story.append(self.Paragraph(stripped[2:], styles["h1"]))
            elif stripped.startswith("### "):
                story.append(self.Paragraph(stripped[4:], styles["h2"]))
            # List items
            elif stripped.startswith("- ") or stripped.startswith("* "):
                text = self._clean_markdown(stripped[2:])
                story.append(self.Paragraph(f"• {text}", styles["bullet"]))
            elif stripped.startswith("-"):
                text = self._clean_markdown(stripped[1:].strip())
                story.append(self.Paragraph(f"• {text}", styles["bullet"]))
            # Horizontal rule
            elif stripped.startswith("---"):
                story.append(self.HRFlowable(width="100%", thickness=1, color=(200,200,200)))
                story.append(self.Spacer(1, 10))
            # Regular text
            else:
                text = self._clean_markdown(stripped)
                story.append(self.Paragraph(text, styles["normal"]))
        
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()
    
    def _clean_markdown(self, text: str) -> str:
        """Remove or convert markdown formatting."""
        text = text.replace("**", "").replace("*", "")
        text = text.replace("`", "")
        # Keep emoji but they're not supported in standard fonts
        return text
    
    def save(self, report_content: str, output_path: str, title: Optional[str] = None) -> str:
        """
        Generate and save PDF document.
        
        Args:
            report_content: Report content
            output_path: Output file path
            title: Optional document title
            
        Returns:
            Path to saved file
        """
        content = self.generate(report_content, title)
        with open(output_path, "wb") as f:
            f.write(content)
        return output_path


def generate_document(
    report_content: str,
    output_format: str,
    output_path: Optional[str] = None,
    title: Optional[str] = None
) -> bytes:
    """
    Generate document in specified format.
    
    Args:
        report_content: Report markdown content
        output_format: "word", "pdf", or "markdown"
        output_path: Optional path to save file
        title: Optional document title
        
    Returns:
        Document bytes or path to saved file
    """
    if output_format.lower() == "word":
        generator = WordGenerator()
        content = generator.generate(report_content, title)
    elif output_format.lower() == "pdf":
        generator = PDFGenerator()
        content = generator.generate(report_content, title)
    elif output_format.lower() == "markdown":
        content = report_content.encode("utf-8")
    else:
        raise ValueError(f"Unsupported format: {output_format}")
    
    if output_path:
        mode = "wb" if output_format.lower() != "markdown" else "w"
        with open(output_path, mode) as f:
            f.write(content)
        return output_path
    
    return content
