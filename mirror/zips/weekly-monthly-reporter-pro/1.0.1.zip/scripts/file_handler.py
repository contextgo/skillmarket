"""
File handling module for Weekly-Monthly Reporter.
Supports TXT and Markdown file uploads.
"""

import os
from pathlib import Path
from typing import Optional, Tuple


class FileHandler:
    """Handle file upload and parsing."""
    
    SUPPORTED_EXTENSIONS = {".txt", ".md", ".markdown"}
    MAX_FILE_SIZE = 1024 * 1024  # 1MB
    
    @classmethod
    def read_file(cls, file_path: str) -> Tuple[str, str]:
        """
        Read content from a file.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Tuple of (content, file_type)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file type not supported or file too large
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Check extension
        ext = path.suffix.lower()
        if ext not in cls.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {ext}. Supported: {cls.SUPPORTED_EXTENSIONS}")
        
        # Check size
        file_size = path.stat().st_size
        if file_size > cls.MAX_FILE_SIZE:
            raise ValueError(f"File too large: {file_size} bytes. Max: {cls.MAX_FILE_SIZE} bytes")
        
        # Read content
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            # Try with different encoding
            with open(path, "r", encoding="gbk") as f:
                content = f.read()
        
        file_type = "markdown" if ext in {".md", ".markdown"} else "text"
        
        return content, file_type
    
    @classmethod
    def validate_file(cls, file_path: str) -> Tuple[bool, str]:
        """
        Validate a file before processing.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        path = Path(file_path)
        
        if not path.exists():
            return False, f"File not found: {file_path}"
        
        ext = path.suffix.lower()
        if ext not in cls.SUPPORTED_EXTENSIONS:
            return False, f"Unsupported file type: {ext}"
        
        file_size = path.stat().st_size
        if file_size > cls.MAX_FILE_SIZE:
            return False, f"File too large: {file_size} bytes (max: {cls.MAX_FILE_SIZE})"
        
        return True, ""
    
    @classmethod
    def parse_content(cls, content: str, source_type: str) -> str:
        """
        Parse content from various sources into unified format.
        
        Args:
            content: Raw content
            source_type: Source type ("text", "markdown", "feishu_task")
            
        Returns:
            Parsed content string
        """
        if source_type == "markdown":
            # Extract text from markdown, removing headers formatting
            lines = content.split("\n")
            parsed_lines = []
            for line in lines:
                # Remove markdown headers (# and ##)
                if line.strip().startswith("#"):
                    line = line.lstrip("#").strip()
                parsed_lines.append(line)
            return "\n".join(parsed_lines)
        
        return content.strip()
    
    @classmethod
    def save_upload(cls, content: str, filename: str, upload_dir: Optional[Path] = None) -> str:
        """
        Save uploaded content to a file.
        
        Args:
            content: Content to save
            filename: Desired filename
            upload_dir: Directory to save to (default: ~/.weekly_reporter/uploads)
            
        Returns:
            Path to saved file
        """
        if upload_dir is None:
            upload_dir = Path.home() / ".weekly_reporter" / "uploads"
        
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # Sanitize filename
        safe_name = "".join(c for c in filename if c.isalnum() or c in "._-")
        if not safe_name:
            safe_name = "uploaded_file.txt"
        
        file_path = upload_dir / safe_name
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        
        return str(file_path)
