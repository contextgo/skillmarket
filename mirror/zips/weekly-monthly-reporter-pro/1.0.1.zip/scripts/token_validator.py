"""
Token validation module for Weekly-Monthly Reporter.
Validates API keys against api.yk-global.com/v1/verify
"""

import os
import time
import json
import requests
from pathlib import Path
from typing import Optional, Dict

VALIDATION_URL = "https://api.yk-global.com/v1/verify"
CACHE_DIR = Path.home() / ".weekly_reporter"
CACHE_FILE = CACHE_DIR / "token_cache.json"
CACHE_TTL = 300  # 5 minutes

# Tier definitions
TIERS = {
    "RPT-WEEKLY-FREE": {"generations": 5, "input_types": ["text"], "output_formats": ["markdown"], "history_days": 0, "custom_template": False, "api_access": False},
    "RPT-WEEKLY-STD": {"generations": 30, "input_types": ["text", "file"], "output_formats": ["markdown", "word"], "history_days": 30, "custom_template": True, "api_access": False},
    "RPT-WEEKLY-PRO": {"generations": 100, "input_types": ["text", "file", "feishu_task"], "output_formats": ["markdown", "word", "pdf"], "history_days": 180, "custom_template": True, "api_access": True},
    "RPT-WEEKLY-MAX": {"generations": -1, "input_types": ["text", "file", "feishu_task"], "output_formats": ["markdown", "word", "pdf", "feishu_card"], "history_days": 365, "custom_template": True, "api_access": True},
}


def _load_cache() -> Dict:
    """Load token cache from disk."""
    if not CACHE_FILE.exists():
        return {}
    try:
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cache(cache: Dict) -> None:
    """Save token cache to disk."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f)


def _get_cached_validation(api_key: str) -> Optional[Dict]:
    """Get cached validation result if still valid."""
    cache = _load_cache()
    if api_key in cache:
        entry = cache[api_key]
        if time.time() - entry.get("timestamp", 0) < CACHE_TTL:
            return entry.get("result")
    return None


def _cache_validation(api_key: str, result: Dict) -> None:
    """Cache validation result."""
    cache = _load_cache()
    cache[api_key] = {
        "result": result,
        "timestamp": time.time()
    }
    _save_cache(cache)


def validate_token(api_key: str) -> Dict:
    """
    Validate API token against validation server.
    
    Returns:
        Dict with keys: valid (bool), tier (str), features (dict), error (str or None)
    """
    # Check cache first
    cached = _get_cached_validation(api_key)
    if cached is not None:
        return cached
    
    # Determine tier from key prefix
    tier_name = None
    for prefix in TIERS.keys():
        if api_key.startswith(prefix):
            tier_name = prefix
            break
    
    if tier_name is None:
        result = {
            "valid": False,
            "tier": "unknown",
            "error": f"Invalid key prefix. Expected one of: {list(TIERS.keys())}"
        }
        return result
    
    # Call validation API
    try:
        headers = {"Authorization": f"Bearer {api_key}"}
        response = requests.post(VALIDATION_URL, headers=headers, json={}, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            is_valid = data.get("valid", False)
            
            if is_valid:
                result = {
                    "valid": True,
                    "tier": tier_name,
                    "features": TIERS[tier_name],
                    "error": None
                }
            else:
                result = {
                    "valid": False,
                    "tier": tier_name,
                    "error": "Token validation failed on server"
                }
        else:
            # Network/server error - degrade to FREE tier
            result = {
                "valid": True,
                "tier": "RPT-WEEKLY-FREE",
                "features": TIERS["RPT-WEEKLY-FREE"],
                "error": f"Server error ({response.status_code}), degraded to FREE tier",
                "degraded": True
            }
    except Exception as e:
        # Network/server error - degrade to FREE tier
        result = {
            "valid": True,
            "tier": "RPT-WEEKLY-FREE",
            "features": TIERS["RPT-WEEKLY-FREE"],
            "error": f"Network error, degraded to FREE tier: {str(e)}",
            "degraded": True
        }
    
    _cache_validation(api_key, result)
    return result


def check_generation_limit(api_key: str, current_count: int) -> bool:
    """
    Check if user can generate a new report.
    
    Args:
        api_key: User's API key
        current_count: Current generation count
        
    Returns:
        True if user can generate, False otherwise
    """
    validation = validate_token(api_key)
    if not validation["valid"]:
        return False
    
    limit = validation["features"]["generations"]
    if limit == -1:  # Unlimited
        return True
    
    return current_count < limit


def get_user_tier(api_key: str) -> str:
    """Get user's tier name."""
    validation = validate_token(api_key)
    return validation["tier"]
