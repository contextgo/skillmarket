#!/usr/bin/env python3
"""
Weekly-Monthly Reporter - Main CLI Entry Point

A tool to generate professional weekly/monthly reports from work content
using AI, with support for multiple output formats and Feishu integration.
"""

import sys
import json
import argparse
from pathlib import Path
from typing import Optional

from .report_generator import ReportGenerator
from .history_manager import HistoryManager
from .token_validator import validate_token, TIERS
from .templates import ReportType, ReportStyle
from .file_handler import FileHandler
from .doc_generator import generate_document


def create_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Weekly-Monthly Reporter - AI-powered report generation",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Generate command
    gen_parser = subparsers.add_parser("generate", help="Generate a new report")
    gen_parser.add_argument("--content", "-c", help="Work content directly")
    gen_parser.add_argument("--file", "-f", help="File path (TXT/MD) with work content")
    gen_parser.add_argument("--type", "-t", choices=["weekly", "monthly"], default="weekly",
                          help="Report type")
    gen_parser.add_argument("--style", "-s", choices=["concise", "detailed", "leadership", "self_review"],
                          default="concise", help="Report style")
    gen_parser.add_argument("--api-key", "-k", required=True, help="API key for validation")
    gen_parser.add_argument("--llm-key", help="LLM API key for generation")
    gen_parser.add_argument("--output", "-o", help="Output file path")
    gen_parser.add_argument("--format", choices=["markdown", "word", "pdf"], default="markdown",
                          help="Output format")
    gen_parser.add_argument("--template", help="Custom report template")
    gen_parser.add_argument("--continue-from", help="Previous report ID to continue from")
    gen_parser.add_argument("--save", action="store_true", help="Save to history")
    
    # History command
    hist_parser = subparsers.add_parser("history", help="View report history")
    hist_parser.add_argument("--api-key", "-k", required=True)
    hist_parser.add_argument("--limit", "-n", type=int, default=10)
    hist_parser.add_argument("--show", help="Show specific report ID")
    hist_parser.add_argument("--delete", help="Delete specific report ID")
    
    # Validate command
    val_parser = subparsers.add_parser("validate", help="Validate API key")
    val_parser.add_argument("--api-key", "-k", required=True)
    
    # Status command
    stat_parser = subparsers.add_parser("status", help="Check usage status")
    stat_parser.add_argument("--api-key", "-k", required=True)
    
    return parser


def cmd_generate(args) -> int:
    """Handle generate command."""
    # Validate API key first
    validation = validate_token(args.api_key)
    if not validation["valid"]:
        print(f"Error: Invalid API key - {validation.get('error', 'Unknown error')}")
        return 1
    
    print(f"Tier: {validation['tier']}")
    if validation.get('degraded'):
        print(f"Warning: {validation.get('error', 'Running in degraded mode')}")
    
    # Get work content
    work_content = ""
    if args.content:
        work_content = args.content
    elif args.file:
        try:
            work_content, _ = FileHandler.read_file(args.file)
        except Exception as e:
            print(f"Error reading file: {e}")
            return 1
    else:
        print("Error: Must provide --content or --file")
        return 1
    
    # Continue from previous report if specified
    previous_report = None
    if args.continue_from:
        history = HistoryManager()
        prev = history.get_report(args.continue_from)
        if prev:
            previous_report = prev.get("content", "")
            print(f"Continuing from report: {args.continue_from}")
        else:
            print(f"Warning: Previous report {args.continue_from} not found")
    
    # Determine report type and style
    report_type = ReportType.WEEKLY if args.type == "weekly" else ReportType.MONTHLY
    style_map = {
        "concise": ReportStyle.CONCISE,
        "detailed": ReportStyle.DETAILED,
        "leadership": ReportStyle.LEADERSHIP,
        "self_review": ReportStyle.SELF_REVIEW
    }
    style = style_map.get(args.style, ReportStyle.CONCISE)
    
    # Generate report
    generator = ReportGenerator(api_key=args.llm_key)
    
    print("Generating report...")
    result = generator.generate_report(
        work_content=work_content,
        report_type=report_type,
        style=style,
        api_key=args.api_key,
        previous_report=previous_report,
        custom_template=args.template
    )
    
    if not result["success"]:
        print(f"Error: {result['error']}")
        return 1
    
    report = result["report"]
    
    # Output report
    if args.output:
        try:
            output_format = args.format
            generate_document(report, output_format, args.output,
                            title=f"{report_type.value.title()} Report")
            print(f"Report saved to: {args.output}")
        except ImportError as e:
            print(f"Error: {e}")
            return 1
        except Exception as e:
            print(f"Error saving document: {e}")
            return 1
    else:
        print("\n" + "="*60)
        print(report)
        print("="*60)
    
    # Save to history if requested
    if args.save:
        history = HistoryManager()
        history.save_report(
            report=report,
            report_type=args.type,
            style=args.style,
            api_key=args.api_key,
            input_preview=work_content[:200],
            tier=validation["tier"]
        )
        print("Report saved to history.")
    
    # Print usage info
    if "usage" in result:
        usage = result["usage"]
        print(f"\nUsage: {usage['used']}/{usage['limit']} generations this month")
    
    return 0


def cmd_history(args) -> int:
    """Handle history command."""
    history = HistoryManager()
    
    if args.show:
        report = history.get_report(args.show)
        if not report:
            print(f"Report not found: {args.show}")
            return 1
        print("="*60)
        print(f"Type: {report.get('report_type', 'unknown')}")
        print(f"Style: {report.get('style', 'unknown')}")
        print(f"Created: {report.get('created_at', 'unknown')}")
        print("-"*60)
        print(report.get("content", ""))
        print("="*60)
        return 0
    
    if args.delete:
        success = history.delete_report(args.delete, args.api_key)
        if success:
            print(f"Deleted report: {args.delete}")
        else:
            print(f"Failed to delete report: {args.delete}")
        return 0
    
    # List reports
    reports = history.list_reports(args.api_key, limit=args.limit)
    
    if not reports:
        print("No reports found.")
        return 0
    
    print(f"Found {len(reports)} report(s):\n")
    for r in reports:
        print(f"  {r['id']}")
        print(f"    Type: {r.get('report_type', 'unknown')}")
        print(f"    Style: {r.get('style', 'unknown')}")
        print(f"    Created: {r.get('created_at', 'unknown')}")
        print()
    
    return 0


def cmd_validate(args) -> int:
    """Handle validate command."""
    result = validate_token(args.api_key)
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["valid"] else 1


def cmd_status(args) -> int:
    """Handle status command."""
    history = HistoryManager()
    validation = validate_token(args.api_key)
    
    if not validation["valid"]:
        print("Invalid API key")
        return 1
    
    usage = history.get_usage_stats(args.api_key)
    tier = validation["tier"]
    features = validation["features"]
    
    print(f"Tier: {tier}")
    print(f"Features:")
    print(f"  - Input types: {', '.join(features.get('input_types', []))}")
    print(f"  - Output formats: {', '.join(features.get('output_formats', []))}")
    print(f"  - History retention: {features.get('history_days', 0)} days")
    print(f"  - Custom templates: {'Yes' if features.get('custom_template') else 'No'}")
    print(f"  - API access: {'Yes' if features.get('api_access') else 'No'}")
    
    limit = features.get("generations", 0)
    used = usage.get("count", 0)
    month = usage.get("month", "unknown")
    
    if limit == -1:
        print(f"\nUsage this month ({month}): {used} (unlimited)")
    else:
        print(f"\nUsage this month ({month}): {used}/{limit}")
    
    return 0


def main():
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 0
    
    commands = {
        "generate": cmd_generate,
        "history": cmd_history,
        "validate": cmd_validate,
        "status": cmd_status
    }
    
    return commands.get(args.command, lambda a: 1)(args)


if __name__ == "__main__":
    sys.exit(main())
