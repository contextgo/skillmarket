# Weekly-Monthly Reporter - Skills Developer Package
__version__ = "1.0.0"
