# SKILL.md - Weekly-Monthly Reporter

A professional report generation tool that transforms raw work content into structured weekly/monthly reports using AI.

## Trigger Phrases

- "生成周报" / "周报生成" / "写周报"
- "生成月报" / "月报生成" / "写月报"
- "工作汇报" / "工作总结"
- "report generation" / "weekly report" / "monthly report"
- "续写周报" / "继续上次写"

## Capabilities

### Input Methods

| Input Type | Free | Std | Pro | Max |
|------------|------|-----|-----|-----|
| Text paste | ✅ | ✅ | ✅ | ✅ |
| File upload (TXT/MD) | ❌ | ✅ | ✅ | ✅ |
| Feishu tasks | ❌ | ❌ | ✅ | ✅ |

### Output Formats

| Format | Free | Std | Pro | Max |
|--------|------|-----|-----|-----|
| Markdown | ✅ | ✅ | ✅ | ✅ |
| Word (.docx) | ❌ | ✅ | ✅ | ✅ |
| PDF | ❌ | ❌ | ✅ | ✅ |
| Feishu card | ❌ | ❌ | ❌ | ✅ |

### Generation Limits

| Tier | Monthly Limit | History Retention |
|------|---------------|------------------|
| Free | 5 (non-reset) | ❌ |
| Std ¥9.9 | 30 | 30 days |
| Pro ¥29.9 | 100 | 6 months |
| Max ¥99 | Unlimited | 12 months |

## Usage

### CLI Commands

```bash
# Generate a weekly report
python -m scripts.main generate --content "今天完成了XX，明天计划做YY" -k YOUR_API_KEY

# Generate from file
python -m scripts.main generate --file worklog.md -k YOUR_API_KEY

# Generate monthly report in detailed style
python -m scripts.main generate --type monthly --style detailed -c "本月工作..." -k YOUR_API_KEY

# Continue from previous report
python -m scripts.main generate --continue-from REPORT_ID -c "新增工作..." -k YOUR_API_KEY

# Output to Word
python -m scripts.main generate -c "内容..." -k KEY --format word --output report.docx

# View history
python -m scripts.main history -k YOUR_API_KEY

# Check status
python -m scripts.main status -k YOUR_API_KEY

# Validate API key
python -m scripts.main validate -k YOUR_API_KEY
```

### Python API

```python
from scripts.report_generator import ReportGenerator
from scripts.templates import ReportType, ReportStyle

generator = ReportGenerator(api_key="your_llm_key")
result = generator.generate_report(
    work_content="今天完成了A项目第一阶段...",
    report_type=ReportType.WEEKLY,
    style=ReportStyle.CONCISE,
    api_key="your_token_key"
)

if result["success"]:
    print(result["report"])
```

### Report Styles

- **简洁版**: Concise summary, suitable for quick updates
- **详细版**: Comprehensive with KPI, improvements, growth sections
- **领导版**: Executive-focused with risk analysis and metrics
- **自评版**: Self-review style with achievements and improvement areas

## API Key Setup

### Token Validation Key (Required)

Get your key from YK-Global.com:
- Format: `RPT-WEEKLY-*` (RPT-WEEKLY-FREE, RPT-WEEKLY-STD, etc.)
- Validates against: `https://api.yk-global.com/v1/verify`

### LLM API Key (For Generation)

Self-configured. Supports OpenAI-compatible APIs:
- OpenAI (GPT-4, GPT-3.5)
- Custom endpoints

## File Locations

- History: `~/.weekly_reporter/history/`
- Token cache: `~/.weekly_reporter/token_cache.json`
- Uploads: `~/.weekly_reporter/uploads/`

## Error Handling

- Network errors to validation server → degrades to FREE tier (doesn't block usage)
- Generation limit reached → returns error with upgrade info
- Invalid API key → returns validation error

## Feishu Integration

### Reading Tasks (Pro/Max)

Requires Feishu OAuth token with `task:task:readonly` scope.

### Sending Messages (Max only)

Send reports as Feishu interactive cards. Requires bot token.

## Dependencies

```
requests>=2.28.0
python-docx>=0.8.11    # For Word output
reportlab>=4.0.0       # For PDF output
```
