#!/usr/bin/env python3
"""
Test suite for Weekly-Monthly Reporter.
"""

import unittest
import json
import tempfile
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

# Import modules
import sys
sys.path.insert(0, str(Path(__file__).parent))

from scripts.token_validator import validate_token, check_generation_limit, TIERS, _load_cache, _save_cache, CACHE_FILE
from scripts.templates import ReportType, ReportStyle, get_template, build_prompt
from scripts.file_handler import FileHandler
from scripts.history_manager import HistoryManager
from scripts.doc_generator import WordGenerator, PDFGenerator, generate_document


class TestTokenValidator(unittest.TestCase):
    """Test token validation functionality."""
    
    def test_tiers_exist(self):
        """Test all tiers are defined."""
        self.assertIn("RPT-WEEKLY-FREE", TIERS)
        self.assertIn("RPT-WEEKLY-STD", TIERS)
        self.assertIn("RPT-WEEKLY-PRO", TIERS)
        self.assertIn("RPT-WEEKLY-MAX", TIERS)
    
    def test_free_tier_features(self):
        """Test FREE tier has correct features."""
        free = TIERS["RPT-WEEKLY-FREE"]
        self.assertEqual(free["generations"], 5)
        self.assertEqual(free["history_days"], 0)
        self.assertFalse(free["custom_template"])
    
    def test_max_tier_unlimited(self):
        """Test MAX tier has unlimited generations."""
        max_tier = TIERS["RPT-WEEKLY-MAX"]
        self.assertEqual(max_tier["generations"], -1)
        self.assertEqual(max_tier["history_days"], 365)
    
    def test_valid_key_prefix_detection(self):
        """Test valid key prefix detection."""
        for prefix in TIERS.keys():
            with patch("requests.post") as mock_post:
                mock_post.return_value = MagicMock(status_code=200, json=lambda: {"valid": True})
                result = validate_token(f"{prefix}-testkey123")
                self.assertEqual(result["tier"], prefix)
    
    def test_invalid_key_prefix(self):
        """Test invalid key prefix detection."""
        result = validate_token("INVALID-KEY")
        self.assertFalse(result["valid"])
        self.assertIn("Invalid key prefix", result["error"])
    
    def test_network_error_degrades_to_free(self):
        """Test network error degrades to FREE tier."""
        with patch("requests.post") as mock_post:
            mock_post.side_effect = Exception("Network error")
            result = validate_token("RPT-WEEKLY-PRO-testkey")
            self.assertTrue(result["valid"])
            self.assertEqual(result["tier"], "RPT-WEEKLY-FREE")
            self.assertTrue(result.get("degraded"))


class TestTemplates(unittest.TestCase):
    """Test template functionality."""
    
    def test_get_weekly_template(self):
        """Test getting weekly template."""
        template = get_template(ReportType.WEEKLY, ReportStyle.CONCISE)
        self.assertIn("本周工作总结", template)
        self.assertIn("下周工作计划", template)
    
    def test_get_monthly_template(self):
        """Test getting monthly template."""
        template = get_template(ReportType.MONTHLY, ReportStyle.DETAILED)
        self.assertIn("本月核心成果", template)
        self.assertIn("趋势分析", template)
    
    def test_build_prompt(self):
        """Test prompt building."""
        prompt = build_prompt(
            work_content="测试工作内容",
            report_type=ReportType.WEEKLY,
            style=ReportStyle.CONCISE
        )
        self.assertIn("测试工作内容", prompt)
        self.assertIn("简洁版", prompt)
        self.assertIn("周报", prompt)
    
    def test_build_prompt_with_continuation(self):
        """Test prompt building with previous report."""
        prompt = build_prompt(
            work_content="新内容",
            report_type=ReportType.WEEKLY,
            style=ReportStyle.CONCISE,
            previous_report="上一份报告内容"
        )
        self.assertIn("新内容", prompt)
        self.assertIn("上一份报告内容", prompt)
        self.assertIn("续写", prompt)


class TestFileHandler(unittest.TestCase):
    """Test file handling functionality."""
    
    def setUp(self):
        """Create temp files for testing."""
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Clean up temp files."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_read_txt_file(self):
        """Test reading TXT file."""
        file_path = os.path.join(self.temp_dir, "test.txt")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("测试内容")
        
        content, file_type = FileHandler.read_file(file_path)
        self.assertEqual(content, "测试内容")
        self.assertEqual(file_type, "text")
    
    def test_read_markdown_file(self):
        """Test reading Markdown file."""
        file_path = os.path.join(self.temp_dir, "test.md")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("# 标题\n内容")
        
        content, file_type = FileHandler.read_file(file_path)
        self.assertIn("标题", content)
        self.assertEqual(file_type, "markdown")
    
    def test_unsupported_file_type(self):
        """Test unsupported file type raises error."""
        file_path = os.path.join(self.temp_dir, "test.pdf")
        with open(file_path, "w") as f:
            f.write("content")
        
        with self.assertRaises(ValueError) as ctx:
            FileHandler.read_file(file_path)
        self.assertIn("Unsupported", str(ctx.exception))
    
    def test_file_not_found(self):
        """Test non-existent file raises error."""
        with self.assertRaises(FileNotFoundError):
            FileHandler.read_file("/nonexistent/file.txt")
    
    def test_validate_file_success(self):
        """Test file validation success."""
        file_path = os.path.join(self.temp_dir, "test.txt")
        with open(file_path, "w") as f:
            f.write("content")
        
        valid, error = FileHandler.validate_file(file_path)
        self.assertTrue(valid)
        self.assertEqual(error, "")


class TestHistoryManager(unittest.TestCase):
    """Test history management functionality."""
    
    def setUp(self):
        """Create temp directory for history."""
        self.temp_dir = tempfile.mkdtemp()
        self.history = HistoryManager(history_dir=Path(self.temp_dir))
    
    def tearDown(self):
        """Clean up."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_save_and_get_report(self):
        """Test saving and retrieving a report."""
        report_id = self.history.save_report(
            report="# Test Report",
            report_type="weekly",
            style="concise",
            api_key="test_key_123",
            tier="RPT-WEEKLY-STD"
        )
        
        self.assertIsNotNone(report_id)
        
        report = self.history.get_report(report_id)
        self.assertIsNotNone(report)
        self.assertEqual(report["content"], "# Test Report")
        self.assertEqual(report["report_type"], "weekly")
    
    def test_list_reports(self):
        """Test listing reports."""
        self.history.save_report("Report 1", "weekly", "concise", "test_key", "STD")
        self.history.save_report("Report 2", "monthly", "detailed", "test_key", "STD")
        
        reports = self.history.list_reports("test_key")
        self.assertEqual(len(reports), 2)
    
    def test_delete_report(self):
        """Test deleting a report."""
        report_id = self.history.save_report(
            "Test", "weekly", "concise", "test_key", "STD"
        )
        
        success = self.history.delete_report(report_id, "test_key")
        self.assertTrue(success)
        
        report = self.history.get_report(report_id)
        self.assertIsNone(report)
    
    def test_delete_report_wrong_key(self):
        """Test deleting with wrong key fails."""
        report_id = self.history.save_report(
            "Test", "weekly", "concise", "test_key", "STD"
        )
        
        success = self.history.delete_report(report_id, "wrong_key")
        self.assertFalse(success)


class TestDocGenerator(unittest.TestCase):
    """Test document generation functionality."""
    
    def test_generate_markdown(self):
        """Test markdown output."""
        content = "# Test Report\n\nTest content"
        result = generate_document(content, "markdown")
        self.assertEqual(result, content.encode("utf-8"))
    
    def test_word_generation(self):
        """Test Word document generation."""
        try:
            from docx import Document
        except ImportError:
            self.skipTest("python-docx not installed")
        
        content = "# Test Report\n\n- Item 1\n- Item 2"
        result = generate_document(content, "word")
        self.assertIsInstance(result, bytes)
        self.assertGreater(len(result), 0)
    
    def test_pdf_generation(self):
        """Test PDF document generation."""
        try:
            from reportlab.pdfgen import canvas
        except ImportError:
            self.skipTest("reportlab not installed")
        
        content = "# Test Report\n\nTest content"
        result = generate_document(content, "pdf")
        self.assertIsInstance(result, bytes)
        self.assertGreater(len(result), 0)
    
    def test_unsupported_format(self):
        """Test unsupported format raises error."""
        with self.assertRaises(ValueError):
            generate_document("content", "invalid_format")


class TestReportGenerator(unittest.TestCase):
    """Test report generation (mocked)."""
    
    def test_parse_work_input_text(self):
        """Test parsing text input."""
        from scripts.report_generator import ReportGenerator
        gen = ReportGenerator()
        
        result = gen.parse_work_input("Test content", "text")
        self.assertEqual(result, "Test content")
    
    def test_parse_work_input_feishu_tasks(self):
        """Test parsing Feishu tasks."""
        from scripts.report_generator import ReportGenerator
        gen = ReportGenerator()
        
        tasks_json = json.dumps([
            {"summary": "Task 1", "completed_at": "2024-01-01T00:00:00Z"},
            {"summary": "Task 2", "done": True}
        ])
        
        result = gen.parse_work_input(tasks_json, "feishu_task")
        self.assertIn("Task 1", result)
        self.assertIn("Task 2", result)


if __name__ == "__main__":
    unittest.main()
