---
name: lobster-memory-bootstrap
description: 通用多层记忆架构初始化与维护。用于新会话启动、上下文续接、任务收尾、周期性心跳检查。提供标准化的加载顺序、写回规则、活跃任务恢复流程与长期记忆归纳流程，适用于需要稳定上下文延续的工作型 agent。
---

# Lobster Memory Bootstrap

将此技能作为“记忆系统启动器 + 运行维护器”使用，目标是让 agent 在每次会话中都能稳定完成：初始化、续接、写回、收口。

## 1) 启动序列（按顺序执行）

1. 读取 `SOUL.md`（身份与行为边界）
2. 读取 `USER.md`（协作对象与边界）
3. 读取 `memory/YYYY-MM-DD.md`（今天）
4. 读取 `memory/YYYY-MM-DD.md`（昨天）
5. 读取 `ACTIVE-TASKS.md`（如果存在）
6. 在主会话中额外读取 `MEMORY.md`

若某文件不存在：记录“缺失”，继续后续步骤，不中断启动。

## 2) 活跃任务续接

当 `ACTIVE-TASKS.md` 存在时：

1. 读取每个任务条目的 `projects/<slug>/progress.md`
2. 按“最近更新时间 + 当前对话主题匹配度”排序
3. 选出最可能续接的任务并给出：
   - 当前状态
   - 上次停点
   - 下一步建议（1~3 条）

## 3) 写回规则（每次有意义交互后执行）

- 当日进展 → 追加到 `memory/YYYY-MM-DD.md`
- 可复用结论/长期规则 → 追加到 `MEMORY.md`
- 任务状态变化 → 更新对应 `projects/<slug>/progress.md`
- 任务生命周期变化（新建/完成/挂起）→ 更新 `ACTIVE-TASKS.md`

仅写入可验证事实，禁止将推测写成既成事实。

## 4) 心跳维护（定期）

详细节奏与检查清单见：`references/heartbeat-policy.md`

执行时至少覆盖：
- 活跃任务一致性检查
- 最近工作上下文补齐
- 失效信息清理候选整理

## 5) 会话收尾

收尾时执行：

1. 将结果写入对应 `progress.md`
2. 更新 `ACTIVE-TASKS.md`（完成则移除或标记 completed）
3. 将高价值结论沉淀到 `MEMORY.md`
4. 在当日日志追加“收尾摘要 + 下一步”

## 6) 输出模板（对外汇报）

### 启动完成

```text
🧠 记忆初始化完成
- 已加载：SOUL / USER / 今日 / 昨日 / ACTIVE-TASKS / MEMORY(主会话)
- 活跃任务：<N>
- 推荐续接：<task-slug>
- 下一步：<one-line>
```

### 心跳完成

```text
💓 心跳检查完成
- 一致性：<ok|issues>
- 更新项：<count>
- 风险项：<count>
- 建议动作：<one-line>
```

### 收尾完成

```text
✅ 会话收尾完成
- 已写回：daily / progress / active-tasks / long-memory
- 完成项：<summary>
- 待续接：<summary>
```

## 7) 边界与安全

- 不跨工作区读取或写入未授权目录
- 不输出敏感原文到外部渠道
- 不将未验证信息写入长期记忆
- 无明确确认时，不执行破坏性操作

## 8) 最小目录约定

```text
workspace/
├─ SOUL.md
├─ USER.md
├─ MEMORY.md
├─ ACTIVE-TASKS.md                # 可选
├─ memory/
│  ├─ YYYY-MM-DD.md
│  └─ ...
└─ projects/
   └─ <slug>/
      └─ progress.md
```
