---
name: xiaozhi-plus
description: 控制小智智能设备（Xiaozhi）的 OpenClaw Skill。通过 REST API 向设备发送聊天消息、播放控制（音乐播放/暂停/上一曲/下一曲）、音量调节、亮度调节、主题切换、播放模式设置等指令。当用户提到"小智"、"xiaozhi"、控制智能设备、发送消息到设备、播放音乐、调节音量/亮度等时触发。
---

# xiaozhi-plus Skill

通过 OpenClaw 控制小智智能设备。

## 基础配置

- **Base URL**: `http://101.35.234.159/Xiaozhi`
- **API Path 前缀**: `/api/xiaozhi/`
- **认证**: Bearer Token

## ⚠️ 调用前必读

**每次调用需要提供：**
1. `deviceId` - 设备 MAC 地址（如 `30:ed:a0:ae:05:08`）
2. `apiKey` - API Key

**已验证可用的接口：** ✅

## API 端点

### 功能速查

| 功能 | API 端点 | 关键参数 |
|------|----------|----------|
| 发送聊天消息 | `POST /api/xiaozhi/SendChatMessage` | `message` |
| 待机 | `POST /api/xiaozhi/SendIdleMessage` | 仅 deviceId |
| 播放音乐 | `POST /api/xiaozhi/SendPlayMusicMessage` | `keywords` |
| 停止播放 | `POST /api/xiaozhi/SendStopMusicMessage` | 仅 deviceId |
| 恢复播放 | `POST /api/xiaozhi/SendResumeMusicMessage` | 仅 deviceId |
| 下一曲 | `POST /api/xiaozhi/SendPlayNextMusicMessage` | 仅 deviceId |
| 上一曲 | `POST /api/xiaozhi/SendPlayPrevMusicMessage` | 仅 deviceId |
| 播放模式 | `POST /api/xiaozhi/SendPlayerModeMessage` | `playerMode` |
| 音量调节 | `POST /api/xiaozhi/SendVolumeMessage` | `value` (0-100) |
| 亮度调节 | `POST /api/xiaozhi/SendBrightnessMessage` | `value` (0-100) |
| 主题切换 | `POST /api/xiaozhi/SendThemeMessage` | `value` (light/dark) |

## HTTP 请求格式

```
POST http://101.35.234.159/Xiaozhi/api/xiaozhi/<Endpoint>
Headers:
  Authorization: Bearer <apiKey>
  Content-Type: application/json
Body:
  { "deviceId": "xx:xx:xx:xx:xx:xx", ... }
```

## 播放模式 (playerMode)

- `SEQUENCE` - 顺序播放
- `RANDOM` - 随机播放
- `LIST_LOOP` - 列表循环
- `SINGLE_LOOP` - 单曲循环

## 设备信息

- **设备名**: 用户提供或来自记忆
- **MAC 地址**: 用户提供或来自记忆
- **API Key**: 用户提供

## 典型对话示例

- "让小智播放周杰伦的歌"
- "小智停止播放"
- "小智音量调到50"
- "让小智切换到随机播放模式"
- "小智亮度调暗一点"
