# 小智设备 API 配置

## 基础信息

- **Base URL**: `http://101.35.234.159/Xiaozhi`
- **API Path**: `/api/xiaozhi/`
- **Content-Type**: `application/json`

## 认证

请求头中需要包含：
```
Authorization: Bearer <API_KEY>
```

---

## API 端点详解

### 基础请求格式

```
POST http://101.35.234.159/Xiaozhi/api/xiaozhi/<Endpoint>
Headers:
  Authorization: Bearer <API_KEY>
  Content-Type: application/json
Body:
  { "deviceId": "AA:BB:CC:DD:EE:FF", ... }
```

---

### 1. 发送聊天消息

**POST** `/api/xiaozhi/SendChatMessage`

```json
{
  "deviceId": "设备mac地址",
  "message": "消息内容"
}
```

---

### 2. 待机

**POST** `/api/xiaozhi/SendIdleMessage`

```json
{
  "deviceId": "设备mac地址"
}
```

---

### 3. 播放音乐

**POST** `/api/xiaozhi/SendPlayMusicMessage`

```json
{
  "deviceId": "设备mac地址",
  "keywords": "歌曲名称、歌手关键词"
}
```

---

### 4. 停止播放

**POST** `/api/xiaozhi/SendStopMusicMessage`

```json
{
  "deviceId": "设备mac地址"
}
```

---

### 5. 恢复播放

**POST** `/api/xiaozhi/SendResumeMusicMessage`

```json
{
  "deviceId": "设备mac地址"
}
```

---

### 6. 播放下一曲

**POST** `/api/xiaozhi/SendPlayNextMusicMessage`

```json
{
  "deviceId": "设备mac地址"
}
```

---

### 7. 播放上一曲

**POST** `/api/xiaozhi/SendPlayPrevMusicMessage`

```json
{
  "deviceId": "设备mac地址"
}
```

---

### 8. 设置播放模式

**POST** `/api/xiaozhi/SendPlayerModeMessage`

```json
{
  "deviceId": "设备mac地址",
  "playerMode": "SEQUENCE | RANDOM | LIST_LOOP | SINGLE_LOOP"
}
```

| playerMode | 模式 |
|------------|------|
| `SEQUENCE` | 顺序播放 |
| `RANDOM` | 随机播放 |
| `LIST_LOOP` | 列表循环 |
| `SINGLE_LOOP` | 单曲循环 |

---

### 9. 音量调节

**POST** `/api/xiaozhi/SendVolumeMessage`

```json
{
  "deviceId": "设备mac地址",
  "value": 50
}
```

> `value` 范围: 0-100

---

### 10. 亮度调节

**POST** `/api/xiaozhi/SendBrightnessMessage`

```json
{
  "deviceId": "设备mac地址",
  "value": 80
}
```

> `value` 范围: 0-100

---

### 11. 主题切换

**POST** `/api/xiaozhi/SendThemeMessage`

```json
{
  "deviceId": "设备mac地址",
  "value": "light或dark"
}
```

---

## 通用响应格式

```json
{
  "code": 200,
  "type": "success",
  "message": "操作成功",
  "result": null,
  "extras": null,
  "time": "2025-08-26T10:00:00Z"
}
```

## curl 调用示例

```bash
# 播放音乐
curl -X POST "http://101.35.234.159/Xiaozhi/api/xiaozhi/SendPlayMusicMessage" \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"deviceId": "30:ed:a0:ae:05:08", "keywords": "周杰伦"}'

# 停止播放
curl -X POST "http://101.35.234.159/Xiaozhi/api/xiaozhi/SendStopMusicMessage" \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"deviceId": "30:ed:a0:ae:05:08"}'
```
