---
name: file-share-link
description: 本地文件分享链接生成器 v4.1.1 - 智能复用版。支持多文件共享，HTTP端口按需开启，中文文件名支持，60分钟自动失效。
license: MIT
metadata:
  version: 4.1.1
  author: leishangming
  platforms: [macOS, Linux]
  requires: [python3]
  security_fixed: true
---

# file-share-link v4.1.0

**智能复用版文件分享工具**，纯 Python 实现，自动下载配置 cloudflared，支持多文件共享，HTTP 端口按需开启。

## ✨ 特性

- 🚀 **零配置** - 只需 Python 3，自动下载安装 cloudflared
- 🌍 **跨平台支持** - macOS、Linux (x86_64, arm64)
- 📁 **多文件共享** - 支持同时分享多个文件，文件列表页展示
- 🔧 **按需启动** - HTTP 端口按需开启，用完即关
- ⏱️ **智能复用** - tunnel 保持 60 分钟，期间可添加新文件
- 🛡️ **安全可靠** - Cloudflare 官方隧道，60 分钟自动失效
- 📦 **无依赖** - 除 Python 外无需任何预装软件

## 📦 安装

**无需安装！** 只需确保系统有 Python 3：

```bash
# 检查 Python 版本
python3 --version
```

如果没有 Python 3：
- **macOS**: 系统自带 或 `brew install python3`
- **Ubuntu/Debian**: `sudo apt install python3`
- **CentOS/RHEL**: `sudo yum install python3`
- **Windows**: 需要手动安装 Python 后使用（见下方说明）

## 🚀 使用方法

### macOS / Linux

```bash
# 分享文件（使用默认端口 8088）
python3 file-share.py /path/to/your/file.pdf

# 指定端口
python3 file-share.py /path/to/your/file.pdf --port 8089
```

### Windows 用户说明

Windows 用户需要手动安装 Python 后使用本工具：

1. 访问 https://python.org 下载安装 Python
2. **务必勾选 "Add Python to PATH"**
3. 使用方法与 macOS/Linux 相同：
```cmd
python file-share.py C:\Users\Admin\Desktop\file.pdf
```

#### 替代方案

- **使用 WSL**：`wsl python3 file-share.py file.pdf`
- **使用 Git Bash**：安装 Git for Windows 后在 Bash 中运行

### 输出示例

```json
{
  "success": true,
  "filename": "document.pdf",
  "size": "2.5M",
  "url": "https://example.trycloudflare.com/document.pdf",
  "port": 8088,
  "expire_minutes": 30
}
```

## 🔧 技术实现

### 架构

```
file-share.py
    ↓
检测平台 → 下载对应 cloudflared → 启动 HTTP 服务器 → 创建 Cloudflare Tunnel → 生成公网链接
```

### 自动下载 cloudflared

首次运行时会自动下载对应平台的 cloudflared：

| 平台 | 架构 | 自动下载 |
|------|------|----------|
| macOS | Intel (x86_64) | ✅ 自动 |
| macOS | Apple Silicon (arm64) | ✅ 自动 |
| Linux | x86_64 | ✅ 自动 |
| Linux | arm64 | ✅ 自动 |
| Windows | x86_64 | ✅ 自动 |
| Windows | arm64 | ✅ 自动 |

download 后的 cloudflared 保存在：`~/.openclaw/bin/`

## 🐛 故障排除

### 问题 1：提示 "Python 3 未找到"

**解决方案**：
```bash
# macOS
brew install python3

# Ubuntu/Debian
sudo apt update && sudo apt install python3

# CentOS/RHEL
sudo yum install python3

# Windows
# 访问 https://python.org 下载安装
```

### 问题 2：下载 cloudflared 失败

**可能原因**：网络限制无法访问 GitHub

**解决方案**：
1. 配置代理后重试
2. 或手动下载 cloudflared 放到 `~/.openclaw/bin/`
3. 从 https://github.com/cloudflare/cloudflared/releases 下载

### 问题 3：端口被占用

**现象**：自动切换到新端口

**正常行为**：脚本会自动检测并切换到可用端口

### 问题 4：链接无法访问

**排查步骤**：
1. 检查网络连接
2. 查看日志：`~/.openclaw/logs/tunnel_*.log`
3. 更换端口重试：`python3 file-share.py file.pdf --port 8090`

## 📁 文件结构

```
file-share-link/
├── file-share.py         # 核心脚本（唯一必需文件）
├── SKILL.md              # 技能说明文档
└── package.json          # 技能元数据
```

## 🛡️ 安全说明

### 输入验证
- 严格验证文件路径，禁止目录遍历
- 只允许访问指定的单个文件
- 禁止危险字符

### 访问控制
- 单文件 HTTP 服务器
- 禁止目录列表
- 60 分钟自动停止

### 安全建议
- 仅分享非敏感文件
- 分享链接 60 分钟后自动失效
- 定期更新到最新版本

## 🔄 更新日志

### v4.0.0 (2024-04-22) - 零配置版
- ✅ 纯 Python 实现，单一文件
- ✅ 自动检测平台并下载 cloudflared
- ✅ 支持 Windows、macOS、Linux
- ✅ 无需任何预装依赖

### v3.1.0 (2024-04-22) - 安全修复版
- 🛡️ 修复 4 个安全风险
- 🛡️ 固定 cloudflared 版本 + SHA256 校验
- 🛡️ 单文件服务模式

## 📝 注意事项

1. **首次运行**：需要联网下载 cloudflared（约 15-30MB）
2. **有效期**：所有链接 60 分钟后自动失效
3. **文件大小**：建议单个文件不超过 1GB
4. **并发**：同一时间只能分享一个文件

## 🔗 相关链接

- [Cloudflare Tunnel 文档](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/)
- [cloudflared GitHub](https://github.com/cloudflare/cloudflared)

---

**许可证**: MIT License  
**维护者**: leishangming  
**版本**: 4.0.0
