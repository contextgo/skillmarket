#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
file-share-link v4.1.0 - 智能复用版
技术路线: Python + Cloudflare Tunnel (cloudflared)
支持: Windows, macOS, Linux (x86_64, arm64)
用法: python3 file-share.py <文件路径> [端口]

方案B特性:
- 智能检测已有实例，自动复用或新建
- HTTP端口按需开启，用完即关
- tunnel保持60分钟后自动退出
- 支持多文件并发分享
"""

import os
import sys
import json
import time
import socket
import tarfile
import hashlib
import signal
import platform
import subprocess
import threading
import urllib.request
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote

# 强制无缓冲输出
sys.stdout.reconfigure(line_buffering=True)
sys.stderr.reconfigure(line_buffering=True)

# 配置
VERSION = "4.1.1"
CLOUDFLARED_VERSION = "2024.1.5"
BIN_DIR = Path.home() / ".openclaw" / "bin"
SHARE_DIR = Path.home() / ".openclaw" / "tmp" / "share"
LOG_DIR = Path.home() / ".openclaw" / "logs"
PID_DIR = Path.home() / ".openclaw" / "run"
EXPIRE_MINUTES = 60

PID_DIR.mkdir(parents=True, exist_ok=True)

# PID文件路径
PID_FILE = PID_DIR / "file-share.pid"
STATE_FILE = PID_DIR / "file-share-state.json"

# 颜色输出
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    NC = '\033[0m'

    @classmethod
    def info(cls, msg):
        print(f"{cls.GREEN}[INFO]{cls.NC} {msg}", flush=True)
    @classmethod
    def warn(cls, msg):
        print(f"{cls.YELLOW}[WARN]{cls.NC} {msg}", flush=True)
    @classmethod
    def error(cls, msg):
        print(f"{cls.RED}[ERROR]{cls.NC} {msg}", file=sys.stderr, flush=True)

# 检测平台
def detect_platform():
    """检测操作系统和架构"""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    # 统一架构命名
    if machine in ['x86_64', 'amd64']:
        arch = 'amd64'
    elif machine in ['arm64', 'aarch64']:
        arch = 'arm64'
    else:
        raise RuntimeError(f"不支持的架构: {machine}")
    
    # 映射系统
    if system == 'darwin':
        os_name = 'darwin'
    elif system == 'linux':
        os_name = 'linux'
    elif system == 'windows':
        os_name = 'windows'
    else:
        raise RuntimeError(f"不支持的操作系统: {system}")
    
    return f"{os_name}-{arch}"

def get_cloudflared_filename(platform):
    """获取 cloudflared 文件名"""
    if platform.startswith('windows'):
        return 'cloudflared.exe'
    return 'cloudflared'

def get_download_url(platform):
    """获取下载 URL"""
    base_url = f"https://github.com/cloudflare/cloudflared/releases/download/{CLOUDFLARED_VERSION}"
    
    if platform == 'darwin-amd64':
        return f"{base_url}/cloudflared-darwin-amd64.tgz"
    elif platform == 'darwin-arm64':
        return f"{base_url}/cloudflared-darwin-arm64.tgz"
    elif platform == 'linux-amd64':
        return f"{base_url}/cloudflared-linux-amd64"
    elif platform == 'linux-arm64':
        return f"{base_url}/cloudflared-linux-arm64"
    elif platform == 'windows-amd64':
        return f"{base_url}/cloudflared-windows-amd64.exe"
    elif platform == 'windows-arm64':
        return f"{base_url}/cloudflared-windows-arm64.exe"
    else:
        raise RuntimeError(f"不支持的平台: {platform}")

def download_file(url, dest_path):
    """下载文件并显示进度"""
    Colors.info(f"下载: {url}")
    
    def reporthook(block_num, block_size, total_size):
        if total_size > 0:
            downloaded = block_num * block_size
            percent = min(100, int(downloaded * 100 / total_size))
            sys.stdout.write(f"\r  进度: {percent}%")
            sys.stdout.flush()
    
    urllib.request.urlretrieve(url, dest_path, reporthook=reporthook)
    print(flush=True)  # 换行

def install_cloudflared():
    """安装 cloudflared（如果不存在）"""
    platform = detect_platform()
    cloudflared_path = BIN_DIR / get_cloudflared_filename(platform)
    
    # 检查是否已安装
    if cloudflared_path.exists():
        Colors.info(f"cloudflared 已安装: {cloudflared_path}")
        return str(cloudflared_path)
    
    # 创建目录
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    
    Colors.info(f"检测到平台: {platform}")
    Colors.info(f"安装 cloudflared {CLOUDFLARED_VERSION}...")
    
    # 下载
    url = get_download_url(platform)
    
    # macOS 使用 tgz 压缩包，需要特殊处理
    if platform.startswith('darwin'):
        tgz_path = BIN_DIR / f"cloudflared-{platform}.tgz"
        download_file(url, str(tgz_path))
        
        Colors.info("解压中...")
        with tarfile.open(tgz_path, 'r:gz') as tar:
            tar.extract('cloudflared', BIN_DIR)
        tgz_path.unlink()  # 删除压缩包
    else:
        download_file(url, str(cloudflared_path))
    
    # 设置权限（非 Windows）
    if not platform.startswith('windows'):
        os.chmod(cloudflared_path, 0o755)
    
    Colors.info(f"cloudflared 安装成功: {cloudflared_path}")
    return str(cloudflared_path)

# 多文件 HTTP 服务器
class MultiFileHandler(BaseHTTPRequestHandler):
    """提供多个文件共享的 HTTP 服务器"""
    
    shared_files = {}  # {filename: filepath}
    
    def log_message(self, format, *args):
        pass  # 静默日志
    
    def do_GET(self):
        path = unquote(self.path)
        
        # 根路径显示文件列表
        if path == '/' or path == '':
            self.send_file_list()
            return
        
        # 去掉前导斜杠
        filename = path.lstrip('/')
        
        # 查找文件
        if filename not in self.shared_files:
            self.send_error(404, "File Not Found")
            return
        
        filepath = self.shared_files[filename]
        
        try:
            file_size = os.path.getsize(filepath)
            with open(filepath, 'rb') as f:
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Length', str(file_size))
                # RFC 5987/RFC 6266 编码中文文件名
                disposition = self._encode_filename(filename)
                self.send_header('Content-Disposition', disposition)
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                self.wfile.write(f.read())
        except FileNotFoundError:
            self.send_error(404, "File Not Found")
        except Exception as e:
            self.send_error(500, f"Server Error: {e}")
    
    def _encode_filename(self, filename):
        """RFC 5987/RFC 6266 编码文件名，支持中文"""
        try:
            # 尝试使用 ASCII 文件名
            filename.encode('ascii')
            # 纯 ASCII，直接返回
            return f'inline; filename="{filename}"'
        except UnicodeEncodeError:
            # 包含非 ASCII 字符，使用 RFC 5987 编码
            from urllib.parse import quote
            # filename* 使用 UTF-8 编码
            encoded = quote(filename, safe='')
            return f"inline; filename*=UTF-8''{encoded}"
    
    def send_file_list(self):
        """发送文件列表页面"""
        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Shared Files</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        h1 { color: #333; }
        .file { padding: 10px; margin: 10px 0; background: #f5f5f5; border-radius: 5px; }
        a { color: #0066cc; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>📁 共享文件列表</h1>
"""
        if self.shared_files:
            for filename in sorted(self.shared_files.keys()):
                filepath = self.shared_files[filename]
                size = os.path.getsize(filepath)
                size_str = f"{size / 1024:.1f}K" if size < 1024*1024 else f"{size / (1024*1024):.1f}M"
                html += f'<div class="file"><a href="/{filename}">{filename}</a> ({size_str})</div>\n'
        else:
            html += '<p>暂无共享文件</p>\n'
        
        html += f"""    <hr>
    <p><small>⏱️ 有效期: {EXPIRE_MINUTES} 分钟 | Powered by file-share-link</small></p>
</body>
</html>"""
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

def find_available_port(start_port=8088, max_attempts=100):
    """查找可用端口"""
    for port in range(start_port, start_port + max_attempts):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', port))
                return port
        except OSError:
            continue
    raise RuntimeError(f"无法找到可用端口 ({start_port}-{start_port + max_attempts})")

def get_process_info(pid):
    """获取进程信息"""
    try:
        import psutil
        proc = psutil.Process(pid)
        return {
            'exists': True,
            'cmdline': ' '.join(proc.cmdline()),
            'create_time': proc.create_time()
        }
    except:
        return {'exists': False}

def read_state():
    """读取状态文件"""
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return None

def write_state(state):
    """写入状态文件"""
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f)

def is_port_available(port):
    """检查端口是否可用"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', port))
            return True
    except OSError:
        return False

def add_file_to_existing_instance(filepath):
    """尝试向现有实例添加文件"""
    state = read_state()
    if not state:
        return None
    
    pid = state.get('pid')
    port = state.get('port')
    
    if not pid or not port:
        return None
    
    # 检查进程是否存在
    try:
        os.kill(pid, 0)  # 发送信号0检查进程是否存在
    except OSError:
        # 进程不存在
        return None
    
    # 检查端口是否仍然被占用
    if is_port_available(port):
        # 端口已被释放，实例可能已经停止
        return None
    
    # 向实例发送信号，添加新文件
    try:
        # 创建临时文件通知现有实例
        notify_file = PID_DIR / f"add_file_{int(time.time())}.json"
        with open(notify_file, 'w') as f:
            json.dump({'action': 'add_file', 'filepath': str(filepath)}, f)
        
        # 发送 USR1 信号通知实例
        os.kill(pid, signal.SIGUSR1)
        
        # 等待确认
        time.sleep(0.5)
        
        # 读取响应
        response_file = PID_DIR / "add_file_response.json"
        if response_file.exists():
            with open(response_file, 'r') as f:
                response = json.load(f)
            response_file.unlink()
            notify_file.unlink()
            return response.get('url')
        
        notify_file.unlink()
    except Exception as e:
        Colors.warn(f"通知现有实例失败: {e}")
    
    return None

class FileShareServer:
    """文件共享服务器"""
    
    def __init__(self):
        self.http_server = None
        self.tunnel_process = None
        self.cloudflared_path = None
        self.port = None
        self.tunnel_url = None
        self.shared_files = {}
        self.server_thread = None
        self.running = False
    
    def add_file(self, filepath):
        """添加共享文件"""
        filepath = Path(filepath).resolve()
        
        if not filepath.exists():
            Colors.error(f"文件不存在: {filepath}")
            return None
        
        if not filepath.is_file():
            Colors.error(f"不是文件: {filepath}")
            return None
        
        filename = filepath.name
        
        # 复制到共享目录
        SHARE_DIR.mkdir(parents=True, exist_ok=True)
        dest_path = SHARE_DIR / filename
        
        import shutil
        shutil.copy2(filepath, dest_path)
        
        self.shared_files[filename] = str(dest_path)
        
        Colors.info(f"添加文件: {filename}")
        
        return filename
    
    def start_http_server(self, port):
        """启动 HTTP 服务器"""
        self.port = port
        
        # 设置处理器
        MultiFileHandler.shared_files = self.shared_files
        
        self.http_server = HTTPServer(('127.0.0.1', port), MultiFileHandler)
        
        # 在后台线程运行
        self.server_thread = threading.Thread(target=self.http_server.serve_forever, daemon=True)
        self.server_thread.start()
        
        Colors.info(f"HTTP 服务器已启动 (端口: {port})")
    
    def start_tunnel(self, cloudflared_path):
        """启动 cloudflared 隧道"""
        self.cloudflared_path = cloudflared_path
        
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        log_file = LOG_DIR / f"tunnel_{self.port}_{int(time.time())}.log"
        
        tunnel_cmd = [
            cloudflared_path,
            "tunnel",
            "--url", f"http://127.0.0.1:{self.port}"
        ]
        
        # 启动进程
        if sys.platform == 'win32':
            self.tunnel_process = subprocess.Popen(
                tunnel_cmd,
                stdout=open(log_file, 'w'),
                stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
            )
        else:
            self.tunnel_process = subprocess.Popen(
                tunnel_cmd,
                stdout=open(log_file, 'w'),
                stderr=subprocess.STDOUT
            )
        
        # 等待隧道就绪
        Colors.info("启动 Cloudflare Tunnel...")
        Colors.info("等待隧道就绪（最多60秒）...")
        
        self.tunnel_url = self.extract_tunnel_url(str(log_file), timeout=60)
        
        return self.tunnel_url
    
    def extract_tunnel_url(self, log_file, timeout=60):
        """从日志中提取隧道URL"""
        import re
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                with open(log_file, 'r') as f:
                    content = f.read()
                    match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', content)
                    if match:
                        return match.group(0)
            except FileNotFoundError:
                pass
            
            time.sleep(0.5)
        
        return None
    
    def save_state(self):
        """保存状态"""
        state = {
            'pid': os.getpid(),
            'port': self.port,
            'url': self.tunnel_url,
            'files': list(self.shared_files.keys()),
            'start_time': time.time()
        }
        write_state(state)
    
    def run(self, filepath):
        """运行完整流程"""
        # 添加文件
        filename = self.add_file(filepath)
        if not filename:
            return False
        
        # 安装 cloudflared
        try:
            cloudflared_path = install_cloudflared()
        except Exception as e:
            Colors.error(f"安装 cloudflared 失败: {e}")
            return False
        
        # 查找可用端口
        try:
            port = find_available_port(8088)
        except RuntimeError as e:
            Colors.error(str(e))
            return False
        
        # 启动 HTTP 服务器
        try:
            self.start_http_server(port)
            time.sleep(0.5)  # 等待服务器启动
        except Exception as e:
            Colors.error(f"启动 HTTP 服务器失败: {e}")
            return False
        
        # 启动 tunnel
        try:
            url = self.start_tunnel(cloudflared_path)
            if not url:
                Colors.error("无法生成分享链接（超时）")
                self.stop()
                return False
        except Exception as e:
            Colors.error(f"启动隧道失败: {e}")
            self.stop()
            return False
        
        self.tunnel_url = url
        self.running = True
        
        # 保存状态
        self.save_state()
        
        # 输出结果
        full_url = f"{url}/{filename}"
        file_size = os.path.getsize(self.shared_files[filename])
        size_str = f"{file_size / 1024:.1f}K" if file_size < 1024*1024 else f"{file_size / (1024*1024):.1f}M"
        
        print()
        print("="*60)
        print(f"✅ 文件分享成功！")
        print("="*60)
        print(f"📁 文件名: {filename}")
        print(f"📦 大小: {size_str}")
        print(f"🔗 分享链接: {full_url}")
        print(f"📂 文件列表: {url}")
        print(f"⏱️  有效期: {EXPIRE_MINUTES} 分钟")
        print("="*60)
        print()
        
        Colors.info("按 Ctrl+C 停止服务")
        
        # 设置定时停止
        def auto_stop():
            time.sleep(EXPIRE_MINUTES * 60)
            print()
            Colors.info("服务已停止（到达有效期）")
            self.stop()
            sys.exit(0)
        
        stop_thread = threading.Thread(target=auto_stop, daemon=True)
        stop_thread.start()
        
        # 保持运行
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            print()
            Colors.info("正在停止服务...")
        finally:
            self.stop()
        
        return True
    
    def stop(self):
        """停止服务"""
        self.running = False
        
        if self.http_server:
            self.http_server.shutdown()
            Colors.info("HTTP 服务器已停止")
        
        if self.tunnel_process:
            self.tunnel_process.terminate()
            try:
                self.tunnel_process.wait(timeout=5)
            except:
                self.tunnel_process.kill()
            Colors.info("Cloudflare Tunnel 已停止")
        
        # 清理状态文件
        if STATE_FILE.exists():
            STATE_FILE.unlink()

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='文件分享工具 v4.1.0')
    parser.add_argument('file', help='要分享的文件路径')
    parser.add_argument('--port', '-p', type=int, default=8088, help='本地端口 (默认: 8088)')
    args = parser.parse_args()
    
    Colors.info(f"准备分享: {Path(args.file).name}")
    
    # 创建服务器实例并运行
    server = FileShareServer()
    success = server.run(args.file)
    
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()
