---
name: file-share-link
description: 本地文件分享链接生成器 v6.6.0 - 稳定版。使用 Cloudflare Tunnel 将本地文件转为 HTTPS 分享链接，30分钟自动关闭，低资源占用，支持后台运行。
license: MIT
triggers:
  - share
  - send
  - download
  - 分享
  - 发送
  - 下载
  - 文件
  - file
metadata:
  version: "6.6.0"
  author: leishangming
  platforms: [macOS, Linux]
  requires: [python3]
---

# file-share-link v6.3.0

**本地文件一键分享**，将任意文件转为 HTTPS 分享链接，支持外网访问。

## ✨ 功能

- 🚀 **一键分享** - 无需配置，输入文件路径即可生成链接
- 🔗 **HTTPS 链接** - 自动生成 `https://xxx.trycloudflare.com` 安全链接
- 🔥 **用完即焚** - 30 分钟自动关闭，保障安全
- 🔍 **链接自检** - 生成后自动验证可用性
- 🌍 **跨平台** - 支持 macOS、Linux
- 💬 **触发词** - 支持 "分享文件"、"发送文件" 等关键词触发

## 📦 安装

**无需安装**，仅需 Python 3：

```bash
python3 --version  # macOS/Linux 自带
```

## 🚀 使用

### 命令行

```bash
python3 file-share.py /path/to/file.pdf
```

### OpenClaw 触发

```
分享文件 ~/Desktop/photo.jpg
发送文件 ~/Documents/report.pdf
```

## 📋 输出示例

```
============================================================
✅ 分享成功！（30分钟后自动关闭）
============================================================
📁 report.pdf (2.3M)
🔗 https://xxx.trycloudflare.com/report.pdf
📂 列表: https://xxx.trycloudflare.com
============================================================
⏱️  剩余: 30 分钟
```

## 🔧 原理

1. 启动本地 HTTP 服务（随机端口）
2. 创建 Cloudflare Tunnel（无需账号）
3. 生成 HTTPS 分享链接
4. 30 分钟后自动清理所有资源

## ⚠️ 注意

- 首次运行自动下载 cloudflared（约 40MB）
- 链接有效期 30 分钟
- 按 Ctrl+C 可提前关闭
- 建议文件大小不超过 1GB

## 🔗 相关

- [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/)
- [cloudflared GitHub](https://github.com/cloudflare/cloudflared)

---
MIT License | @leishangming | v6.3.0
