# File Share Link v6.6.0 - 稳定版

本地文件一键分享，生成 HTTPS 链接，30分钟自动关闭。

## ✨ 特性

- 🚀 **一键分享** - 无需配置，输入文件路径即可
- 🔗 **HTTPS 链接** - 自动生成安全分享链接
- 🔥 **用完即焚** - 30 分钟自动关闭
- 🖥️ **低资源** - 仅占用 ~20MB 内存
- 🔄 **后台运行** - 支持 nohup，终端关闭不影响
- 🌍 **跨平台** - macOS、Linux

## 📦 安装

**仅需 Python 3**，无需其他依赖：

```bash
python3 --version
```

## 🚀 使用

### 方法 1: 使用 Wrapper 脚本（推荐）

```bash
# 分享文件
./share.sh ~/Desktop/photo.jpg

# 查看状态
tail -f /tmp/file-share-*.log

# 停止服务
./share.sh --stop
```

### 方法 2: 直接使用 Python

```bash
# 前台运行
python3 file-share.py ~/Desktop/photo.jpg

# 后台运行（推荐）
nohup python3 file-share.py ~/Desktop/photo.jpg > share.log 2>&1 &

# 停止服务
python3 file-share.py --stop
```

### 方法 3: OpenClaw 触发

```
分享文件 ~/Desktop/photo.jpg
发送文件 ~/Documents/report.pdf
```

## 📋 输出示例

```
============================================================
✅ 分享成功！30分钟后自动关闭
============================================================
📁 report.pdf (2.3M)
🔗 https://xxx.trycloudflare.com/report.pdf
📂 列表: https://xxx.trycloudflare.com
============================================================
⏱ 剩余: 30 分钟
```

## 🔧 原理

1. 启动本地 HTTP 服务（随机端口）
2. 创建 Cloudflare Tunnel（无需账号）
3. 生成 HTTPS 分享链接
4. 30 分钟后自动清理

## ⚠️ 注意

- 首次运行自动下载 cloudflared（约 40MB）
- 链接有效期 30 分钟
- 建议文件大小不超过 1GB

## 🔗 相关

- [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/)

---
MIT License | v6.6.0
