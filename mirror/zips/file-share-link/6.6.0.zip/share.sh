#!/bin/bash
# file-share wrapper - 自动后台运行

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="$SCRIPT_DIR/file-share.py"

# 检查参数
if [ $# -eq 0 ]; then
    echo "用法: ./share.sh <文件路径>"
    echo "      ./share.sh --stop  # 停止服务"
    exit 1
fi

# 停止命令
if [ "$1" == "--stop" ]; then
    python3 "$PYTHON_SCRIPT" --stop
    exit $?
fi

FILE_PATH="$1"

# 检查文件
if [ ! -f "$FILE_PATH" ]; then
    echo "错误: 文件不存在: $FILE_PATH"
    exit 1
fi

# 检查是否已在运行
PID_FILE="$HOME/.openclaw/run/file-share.pid"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "⚠️  已有分享服务在运行 (PID: $PID)"
        echo "   查看状态: tail -f ~/.openclaw/tmp/share/tunnel_*.log"
        echo "   停止服务: ./share.sh --stop"
        exit 1
    fi
fi

# 使用 nohup 后台运行
LOG_FILE="/tmp/file-share-$(date +%s).log"
echo "🚀 启动分享服务..."
echo "   日志: $LOG_FILE"

nohup python3 "$PYTHON_SCRIPT" "$FILE_PATH" > "$LOG_FILE" 2>&1 &
PID=$!

# 等待启动
echo "⏳ 等待服务启动..."
for i in {1..30}; do
    sleep 1
    if kill -0 $PID 2>/dev/null; then
        # 检查是否已生成链接
        if grep -q "trycloudflare.com" "$LOG_FILE" 2>/dev/null; then
            echo ""
            echo "✅ 服务已启动!"
            echo ""
            grep -A5 "分享成功" "$LOG_FILE" 2>/dev/null || tail -20 "$LOG_FILE"
            echo ""
            echo "📊 查看状态: tail -f $LOG_FILE"
            echo "🛑 停止服务: ./share.sh --stop"
            exit 0
        fi
    else
        echo "❌ 启动失败"
        tail -20 "$LOG_FILE"
        exit 1
    fi
done

echo ""
echo "⏳ 服务启动中，可能需要更长时间..."
echo "📊 查看日志: tail -f $LOG_FILE"
echo "🛑 停止服务: ./share.sh --stop"
