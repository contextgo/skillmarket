#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
file-share-link v6.6.0 - 稳定低资源版
技术路线: Cloudflare Tunnel
特点: 简单可靠、低资源占用、后台运行
"""

import os
import sys
import time
import socket
import signal
import platform
import subprocess
import threading
import urllib.request
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote
from urllib.request import urlopen

sys.stdout.reconfigure(line_buffering=True)

VERSION = "6.6.0"
TIMEOUT = 1800
BIN_DIR = Path.home() / ".openclaw" / "bin"
SHARE_DIR = Path.home() / ".openclaw" / "tmp" / "share"
PID_FILE = Path.home() / ".openclaw" / "run" / "file-share.pid"

class C:
    G, Y, R = '\033[92m', '\033[93m', '\033[91m'
    NC = '\033[0m'
    @classmethod
    def info(cls, m): print(f"{cls.G}[INFO]{cls.NC} {m}", flush=True)
    @classmethod
    def warn(cls, m): print(f"{cls.Y}[WARN]{cls.NC} {m}", flush=True)
    @classmethod
    def error(cls, m): print(f"{cls.R}[ERROR]{cls.NC} {m}", file=sys.stderr, flush=True)

def install_cf():
    import tarfile
    path = BIN_DIR / 'cloudflared'
    if path.exists(): return str(path)
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    C.info("下载 cloudflared...")
    plat = f"{platform.system().lower()}-{platform.machine().lower()}"
    plat = plat.replace('x86_64', 'amd64').replace('aarch64', 'arm64')
    urls = {
        'darwin-amd64': 'cloudflared-darwin-amd64.tgz',
        'darwin-arm64': 'cloudflared-darwin-arm64.tgz',
        'linux-amd64': 'cloudflared-linux-amd64',
        'linux-arm64': 'cloudflared-linux-arm64',
    }
    base = "https://github.com/cloudflare/cloudflared/releases/latest/download"
    fn = urls.get(plat)
    if not fn: raise RuntimeError(f"不支持: {plat}")
    url = f"{base}/{fn}"
    if plat.startswith('darwin'):
        tgz = BIN_DIR / "cf.tgz"
        urllib.request.urlretrieve(url, str(tgz))
        with tarfile.open(tgz, 'r:gz') as tar: tar.extract('cloudflared', BIN_DIR)
        tgz.unlink()
    else:
        urllib.request.urlretrieve(url, str(path))
    os.chmod(path, 0o755)
    return str(path)

def find_port(start=8088):
    for p in range(start, start+100):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', p))
                return p
        except: pass
    raise RuntimeError("无可用端口")

class Handler(BaseHTTPRequestHandler):
    files = {}
    def log_message(self, *a): pass
    def do_GET(self):
        p = unquote(self.path)
        if p == '/':
            h = "<html><body><h1>文件</h1>"
            for f in sorted(self.files):
                sz = os.path.getsize(self.files[f])
                s = f"{sz/1024/1024:.1f}M" if sz > 1024*1024 else f"{sz/1024:.1f}K"
                h += f'<p><a href="/{f}">{f}</a> ({s})</p>'
            h += "</body></html>"
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(h.encode())
            return
        f = p.lstrip('/')
        if f not in self.files:
            self.send_error(404)
            return
        try:
            with open(self.files[f], 'rb') as fd:
                self.send_response(200)
                self.send_header('Content-Length', str(os.path.getsize(self.files[f])))
                self.end_headers()
                self.wfile.write(fd.read())
        except: self.send_error(500)

class ShareService:
    def __init__(self):
        self.http = None
        self.tunnel = None
        self.running = True
    
    def start(self, filepath):
        import shutil
        import re
        
        p = Path(filepath).resolve()
        if not p.exists():
            C.error(f"文件不存在: {filepath}")
            return None
        
        # 安装 cloudflared
        cf = install_cf()
        
        # 准备文件
        SHARE_DIR.mkdir(parents=True, exist_ok=True)
        dst = SHARE_DIR / p.name
        shutil.copy2(p, dst)
        
        # 启动 HTTP (单线程，简单可靠)
        Handler.files = {p.name: str(dst)}
        port = find_port()
        self.http = HTTPServer(('127.0.0.1', port), Handler)
        http_thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        http_thread.start()
        time.sleep(1)
        
        # 启动 tunnel
        log = SHARE_DIR / f"tunnel_{int(time.time())}.log"
        self.tunnel = subprocess.Popen(
            [cf, "tunnel", "--url", f"http://127.0.0.1:{port}"],
            stdout=open(log, 'w'),
            stderr=subprocess.STDOUT
        )
        
        # 获取 URL
        url = None
        for _ in range(60):
            time.sleep(0.5)
            try:
                with open(log) as f:
                    m = re.search(r'https://[\w-]+\.trycloudflare\.com', f.read())
                    if m: url = m.group(0); break
            except: pass
        
        if not url:
            self.stop()
            return None
        
        # 等待隧道就绪 (简单等待，不复杂验证)
        time.sleep(10)
        
        file_url = f"{url}/{p.name}"
        
        # 保存 PID
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(PID_FILE, 'w') as f:
            f.write(str(os.getpid()))
        
        # 输出
        print(f"\n{'='*60}")
        print(f"✅ 分享成功！30分钟后自动关闭")
        print(f"{'='*60}")
        print(f"📁 {p.name} ({os.path.getsize(dst)/1024/1024:.1f}M)")
        print(f"🔗 {file_url}")
        print(f"📂 列表: {url}")
        print(f"{'='*60}")
        print(f"PID: {os.getpid()}")
        print(f"查看日志: tail -f {log}")
        print(f"手动停止: kill {os.getpid()}")
        
        # 简单倒计时 (单线程，无复杂逻辑)
        self.countdown()
        
        return url
    
    def countdown(self):
        try:
            for i in range(TIMEOUT, 0, -1):
                if i % 60 == 0:
                    mins = i // 60
                    print(f"\r⏱ 剩余: {mins} 分钟  ", end='', flush=True)
                time.sleep(1)
            print("\n时间到")
        except KeyboardInterrupt:
            print("\n用户停止")
        finally:
            self.stop()
    
    def stop(self):
        self.running = False
        print("正在关闭...")
        if self.tunnel:
            self.tunnel.terminate()
            try: self.tunnel.wait(timeout=5)
            except: self.tunnel.kill()
        if self.http:
            self.http.shutdown()
        if PID_FILE.exists():
            PID_FILE.unlink()
        print("已关闭")

def main():
    import argparse
    parser = argparse.ArgumentParser(description=f'v{VERSION}')
    parser.add_argument('file', help='文件路径')
    parser.add_argument('--stop', action='store_true', help='停止服务')
    args = parser.parse_args()
    
    if args.stop:
        if PID_FILE.exists():
            with open(PID_FILE) as f:
                pid = int(f.read().strip())
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"已发送停止信号到 PID {pid}")
            except:
                print("服务未运行")
            PID_FILE.unlink()
        else:
            print("服务未运行")
        return 0
    
    if not Path(args.file).exists():
        C.error(f"文件不存在: {args.file}")
        return 1
    
    # 检查是否已有运行中的服务
    if PID_FILE.exists():
        try:
            with open(PID_FILE) as f:
                pid = int(f.read().strip())
            os.kill(pid, 0)  # 检查进程是否存在
            C.warn(f"已有服务在运行 (PID: {pid})")
            C.warn(f"先停止: python3 file-share.py --stop")
            return 1
        except:
            PID_FILE.unlink()
    
    service = ShareService()
    url = service.start(args.file)
    return 0 if url else 1

if __name__ == '__main__':
    sys.exit(main())
