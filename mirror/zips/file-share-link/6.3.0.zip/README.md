# file-share-link - 本地文件分享链接生成器

## 🚀 一键安装

```bash
cd ~/.openclaw/workspace/skills/file-share-link
./install.sh
```

安装内容：
- ✅ cloudflared（自动下载最新版）
- ✅ share-file-auto.sh（核心脚本）
- ✅ SKILL.md（技能配置）

## 📋 快速使用

```bash
# 分享任意文件
~/.openclaw/workspace/skills/file-share-link/share-file-auto.sh <文件路径> [端口]

# 示例
~/.openclaw/workspace/skills/file-share-link/share-file-auto.sh /tmp/video.mp4 8088
```

## 🎯 输出格式

```json
{
  "success": true,
  "filename": "video.mp4",
  "size": "49M",
  "url": "https://xxx.trycloudflare.com/video.mp4",
  "expire_minutes": 30
}
```

## ⚠️ 注意事项

1. **链接有效期**：30 分钟（自动停止）
2. **端口选择**：避免冲突（8088, 8089, 8090...）
3. **文件大小**：无限制

## 🔧 手动停止服务

```bash
pkill -f "http.server 8088"
pkill -f "cloudflared tunnel --url http://localhost:8088"
```

---

*版本：2.0.0 | 2026-04-16*
