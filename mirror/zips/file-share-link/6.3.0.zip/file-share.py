#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
file-share-link v6.3.0 - 简化稳定版
技术路线: Cloudflare Tunnel
特点: 30分钟自动关闭、链接自检、简单易用
"""

import os
import sys
import json
import time
import socket
import signal
import platform
import subprocess
import threading
import urllib.request
import urllib.error
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote
from urllib.request import Request, urlopen

sys.stdout.reconfigure(line_buffering=True)

# 配置
VERSION = "6.3.0"
TIMEOUT = 1800  # 30分钟
BIN_DIR = Path.home() / ".openclaw" / "bin"
SHARE_DIR = Path.home() / ".openclaw" / "tmp" / "share"

# 颜色
class C:
    G, Y, R, CYAN, NC = '\033[92m', '\033[93m', '\033[91m', '\033[96m', '\033[0m'
    @classmethod
    def info(cls, m): print(f"{cls.G}[INFO]{cls.NC} {m}", flush=True)
    @classmethod
    def warn(cls, m): print(f"{cls.Y}[WARN]{cls.NC} {m}", flush=True)
    @classmethod
    def error(cls, m): print(f"{cls.R}[ERROR]{cls.NC} {m}", file=sys.stderr, flush=True)

def install_cf():
    import tarfile
    path = BIN_DIR / 'cloudflared'
    if path.exists(): return str(path)
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    C.info("下载 cloudflared...")
    plat = f"{platform.system().lower()}-{platform.machine().lower()}"
    plat = plat.replace('x86_64', 'amd64').replace('aarch64', 'arm64')
    urls = {
        'darwin-amd64': 'cloudflared-darwin-amd64.tgz',
        'darwin-arm64': 'cloudflared-darwin-arm64.tgz',
        'linux-amd64': 'cloudflared-linux-amd64',
        'linux-arm64': 'cloudflared-linux-arm64',
    }
    base = "https://github.com/cloudflare/cloudflared/releases/latest/download"
    fn = urls.get(plat)
    if not fn: raise RuntimeError(f"不支持: {plat}")
    url = f"{base}/{fn}"
    if plat.startswith('darwin'):
        tgz = BIN_DIR / "cf.tgz"
        urllib.request.urlretrieve(url, str(tgz))
        with tarfile.open(tgz, 'r:gz') as tar: tar.extract('cloudflared', BIN_DIR)
        tgz.unlink()
    else:
        urllib.request.urlretrieve(url, str(path))
    os.chmod(path, 0o755)
    return str(path)

def find_port(start=8088):
    for p in range(start, start+100):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', p))
                return p
        except: pass
    raise RuntimeError("无可用端口")

def check_link(url):
    """链接自检"""
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(req, timeout=10) as r:
            return r.status == 200
    except urllib.error.HTTPError as e:
        return e.code not in [502, 530]
    except:
        return False

class Handler(BaseHTTPRequestHandler):
    files = {}
    def log_message(self, *a): pass
    def do_GET(self):
        p = unquote(self.path)
        if p == '/':
            h = "<html><body><h1>📁 文件</h1>"
            for f in sorted(self.files):
                sz = os.path.getsize(self.files[f])
                s = f"{sz/1024/1024:.1f}M" if sz > 1024*1024 else f"{sz/1024:.1f}K"
                h += f'<p><a href="/{f}">{f}</a> ({s})</p>'
            h += "</body></html>"
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(h.encode())
            return
        f = p.lstrip('/')
        if f not in self.files:
            self.send_error(404)
            return
        try:
            with open(self.files[f], 'rb') as fd:
                self.send_response(200)
                self.send_header('Content-Length', str(os.path.getsize(self.files[f])))
                self.end_headers()
                self.wfile.write(fd.read())
        except: self.send_error(500)

def share(filepath):
    import shutil
    import re
    
    # 准备文件
    p = Path(filepath).resolve()
    if not p.exists():
        C.error(f"文件不存在: {filepath}")
        return None
    
    SHARE_DIR.mkdir(parents=True, exist_ok=True)
    dst = SHARE_DIR / p.name
    shutil.copy2(p, dst)
    C.info(f"添加: {p.name}")
    
    # 安装 cloudflared
    cf = install_cf()
    
    # 启动 HTTP
    Handler.files = {p.name: str(dst)}
    port = find_port()
    http = HTTPServer(('127.0.0.1', port), Handler)
    threading.Thread(target=http.serve_forever, daemon=True).start()
    C.info(f"HTTP 服务 (端口: {port})")
    time.sleep(0.5)
    
    # 启动 tunnel
    log = SHARE_DIR / f"tunnel_{int(time.time())}.log"
    tunnel = subprocess.Popen([cf, "tunnel", "--url", f"http://127.0.0.1:{port}"],
                               stdout=open(log, 'w'), stderr=subprocess.STDOUT)
    C.info("启动 Cloudflare 隧道...")
    
    # 获取 URL
    url = None
    for _ in range(120):
        time.sleep(0.5)
        try:
            with open(log) as f:
                m = re.search(r'https://[\w-]+\.trycloudflare\.com', f.read())
                if m: url = m.group(0); break
        except: pass
    
    if not url:
        C.error("获取链接失败")
        tunnel.terminate()
        http.shutdown()
        return None
    
    # 等待 DNS 传播
    C.info("等待链接就绪...")
    time.sleep(5)
    
    # 自检
    if check_link(url):
        C.info("✅ 链接验证通过")
    else:
        C.warn("⚠️  链接可能需要等待 DNS 传播")
    
    # 输出
    print()
    print("="*60)
    print(f"✅ 分享成功！（30分钟后自动关闭）")
    print("="*60)
    print(f"📁 {p.name} ({os.path.getsize(dst)/1024/1024:.1f}M)")
    print(f"🔗 {url}/{p.name}")
    print(f"📂 列表: {url}")
    print("="*60)
    C.info("按 Ctrl+C 立即关闭，或等待30分钟自动关闭")
    
    # 倒计时
    try:
        for i in range(TIMEOUT, 0, -1):
            if i % 60 == 0:  # 每分钟更新一次
                mins = i // 60
                print(f"\r⏱️  剩余: {mins} 分钟  ", end='', flush=True)
            time.sleep(1)
        print()
        C.info("时间到，自动关闭")
    except KeyboardInterrupt:
        print()
        C.info("用户手动关闭")
    finally:
        tunnel.terminate()
        try: tunnel.wait(timeout=5)
        except: tunnel.kill()
        http.shutdown()
        C.info("服务已停止")
    
    return url

def main():
    import argparse
    parser = argparse.ArgumentParser(description=f'v{VERSION}')
    parser.add_argument('file', help='文件路径')
    args = parser.parse_args()
    
    if not Path(args.file).exists():
        C.error(f"文件不存在: {args.file}")
        return 1
    
    share(args.file)
    return 0

if __name__ == '__main__':
    sys.exit(main())
