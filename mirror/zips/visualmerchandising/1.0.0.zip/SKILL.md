---
name: retail-display-training
description: This skill is designed for retail training department leaders to systematically design and deliver display training and learning programs. It integrates display knowledge, hands-on training, real store experience, and learning outcomes to support employees across roles (store staff, trainees, store managers, regional display leads, trainers). This skill should be triggered when users need curriculum design, training delivery, microlearning, training scripts, learning paths, exercise design, job aids, assessment tools, evaluation rubrics, results presentations, or review templates related to retail display fundamentals, color, structure, data-driven display, advanced topics, window displays, or mannequin styling.
---

# Retail Display Training & Learning Design

## Overview

This is a comprehensive retail display training and learning design skill for enterprise training departments. It helps transform display knowledge into organizational capabilities through systematic curriculum design, hands-on training delivery, real-world application, and structured learning outcomes.

**Core Purpose:** To complete the full cycle from "learning knowledge" → "building capability" → "delivering results" through structured, replicable training systems.

## Triggers & Usage Scenarios

This skill activates when users request:

**Training & Learning Context:**
- Display training programs or courses
- Curriculum planning and learning paths
- New employee display onboarding
- Trainer enablement and coaching scripts
- Microlearning and lesson design
- Team capability building

**Course Design Context:**
- Training plans and delivery proposals
- Course outlines and syllabi
- Trainer lecture scripts and teaching materials
- Exercise design and practice tasks
- Learning assessments and validation methods
- Competency rubrics and evaluation standards

**Hands-On Training Context:**
- Display techniques and methods
- Operational execution steps and checklists
- Real store scenarios and case analysis
- Common mistakes and experience lessons
- Display diagnostics and auditing tools
- Training feedback and coaching guidance

**Learning Outcomes & Evaluation:**
- Learning result presentations
- Course completion demonstrations
- Review and retrospective templates
- Certification project design
- Performance assessment rubrics
- Learning certificates and credentials

## Core Framework & Design Methodology

### Four-Dimensional Design Approach (Default Structure)

Unless otherwise specified, organize content across these four dimensions:

1. **Theory (理论)**
   - Concepts, principles, logic, frameworks, standards
   - "Know what and why"

2. **Hands-On (实操)**
   - Action decomposition, step-by-step procedures, training methods, execution tasks, key checkpoints
   - "Know how to do it"

3. **Experience (经验)**
   - Real store cases, common pitfalls, experience rules, judgment principles, lessons learned
   - "Know what can go wrong and how to adapt"

4. **Presentation (呈现)**
   - Exercise forms, result requirements, reporting templates, evaluation standards, review questions
   - "Know how to demonstrate and verify"

### Three-Stage Learning Cycle (Default Path)

For curriculum planning, learning paths, training programs, or capability building:

| Stage | Focus | Deliverable |
|-------|-------|-------------|
| **Stage 1: Theory Learning** | Knowledge input, framework understanding, baseline building | Learning materials, concept guides, theory tests |
| **Stage 2: Practice & Application** | Hands-on execution, real scenario practice, skill development | Exercises, role-plays, store-based tasks, simulations |
| **Stage 3: Results & Presentation** | Capability demonstration, work showcase, certification | Portfolio, presentations, assessments, certifications |

### Result-Oriented Design Principles

Always prioritize clarity on:
- **Learning Objectives** - What should learners achieve?
- **Applicable Roles** - Who is the target audience?
- **Learning Outcomes** - What capability will they gain?
- **Key Knowledge** - What core concepts matter?
- **Execution Tasks** - What will they practice?
- **Validation Standards** - How will success be measured?
- **Review Process** - How will we reflect and improve?

## Course Subject Areas (Default Priority Order)

When the topic is not explicitly specified, prioritize in this order:

1. **Basic Display** - Foundations, layout principles, visual hierarchy, spatial thinking
2. **Color Theory & Application** - Color psychology, color coordination, seasonal palettes, focal points
3. **Structural Display** - Composition, balance, asymmetry, depth, levels, geometric arrangement
4. **Data-Driven Display** - Metrics, performance tracking, ROI measurement, optimization
5. **Advanced Display Topics** - Promotions, special events, brand storytelling, experience design
6. **Window Displays** - Seasonal themes, attraction techniques, traffic flow design
7. **Mannequin Styling** - Outfit coordination, proportions, poses, brand expression

## Default Output Structure

When designing training content, follow this structure (adjust as needed):

### 1. Target Audience
- Clarify who this is for (new employees, store managers, trainers, etc.)

### 2. Learning Objectives / Problem Definition
- Define what problem this training solves
- State the desired outcome

### 3. Theory Section
- Explain concepts, principles, logic, frameworks, standards
- Use examples, diagrams, comparisons where helpful

### 4. Hands-On Section
- Decompose actions into clear steps
- Provide practice methods and scenarios
- Include execution checklists

### 5. Experience Section
- Share real store scenarios and lessons
- Highlight common mistakes and pitfalls
- Provide judgment principles and adaptation strategies

### 6. Presentation Section
- Define exercise forms and requirements
- Create reporting templates
- Show expected deliverables
- Explain showcase methods

### 7. Assessment & Review
- Provide evaluation checklists and rubrics
- Create scoring frameworks
- Design reflection questions
- Suggest improvement paths

## Request Type Handling (Adjust Output Emphasis)

### Knowledge Teaching Type
**Priority Output:**
- Concept explanations with examples
- Core principles and application logic
- Common misconceptions
- Practice scenarios
- Difficulty progression from basic to advanced

### Curriculum Design Type
**Priority Output:**
- Course goals and learning outcomes
- Course outline and session structure
- Teaching flow and timing
- Trainer scripts and talking points
- Practice exercises with instructions
- Validation methods and success criteria

### Learning Path Design Type
**Priority Output:**
- Stage-by-stage progression plan
- Weekly/monthly schedule and milestones
- Tasks for each stage with deliverables
- Feedback frequency and methods
- Progress checkpoints
- Completion and certification process

### Hands-On Training Type
**Priority Output:**
- Scenario-based tasks and challenges
- Detailed action decomposition with visuals
- Step-by-step execution guides
- Common issues and solutions
- Checkpoint review items
- Coaching and feedback suggestions

### Tool & Template Type
**Priority Output:**
- Copy-ready table structures
- Scoring guides and rubrics
- Checklists and audit forms
- Standard operating procedures (SOP)
- Homework templates
- Review and retrospective forms

### Results & Presentation Type
**Priority Output:**
- Presentation structure and flow
- Work/portfolio requirements
- Display and showcase methods
- Evaluation dimensions
- Certification suggestions
- Graduation ceremony ideas

### Complete Training Program Type
**Priority Output:**
- Program timeline and phases
- Learning objectives across phases
- Session-by-session curriculum
- Role responsibilities (trainer, manager, learner)
- Exercise and assignment library
- Assessment and certification pathway
- Feedback and coaching plan

## Implementation Guidelines

### For Trainers & Curriculum Designers
- Ensure outputs are immediately actionable and can be directly copied into training documents, PowerPoint slides, SOP manuals, scripts, or learning platforms
- Always include structured, modular content that separates concepts, steps, examples, and assessments
- Support both digital and in-store delivery methods

### For Trainees & Individual Learners
- Start with foundational concepts and progress to advanced applications
- Provide clear success criteria and self-assessment tools
- Emphasize "know-why" before "how-to" to build genuine understanding

### For Managers & Coaching Roles
- Include assessment rubrics, checkpoint review lists, and coaching frameworks
- Provide data-driven feedback methods and improvement planning tools
- Build in regular review cycles (weekly, monthly, quarterly)

### For Enterprise Training Systems
- Design for scalability across store locations and teams
- Ensure consistent terminology and assessment methods across the organization
- Support knowledge management and continuous improvement feedback loops

## Continuous Learning Support (Optional Enhancement)

When designing multi-month or multi-year programs, consider adding:

- **Monthly Learning Plans** - Theme, objectives, assignments, review questions
- **Weekly Touchpoints** - Check-ins, Q&A sessions, resource sharing
- **Supplementary Materials** - Reading lists, video resources, case studies, industry articles
- **Peer Learning** - Communities of practice, case sharing, cross-store collaboration
- **Certification Pathways** - Milestones, badging, credentials, career progression
- **Continuous Feedback** - 360-degree input, performance data, capability tracking

## Boundaries & Limitations

1. This skill focuses exclusively on retail display training and learning system design
2. It does not replace on-site store assessments or real-world judgment calls
3. It does not generate fake data or unsupported claims about business results
4. It does not create protected, discriminatory, or unethical content
5. It does not stop at abstract theory; default outputs include practical exercises, tools, and evaluation methods
6. It may extend to adjacent retail learning topics (e.g., general sales training) when connected to display capability
7. Outputs are designed to be directly deployable in enterprise training contexts

## Success Criteria

Outputs from this skill should satisfy:

- **Understandable** - Clear language appropriate to the audience
- **Learnable** - Concepts progress logically with practice opportunities
- **Actionable** - Exercises and tasks are concrete and executable in real stores
- **Measurable** - Success can be verified through defined checkpoints
- **Reviewable** - Built-in reflection and feedback mechanisms
- **Evaluable** - Assessment criteria and scoring guides included
- **Deployable** - Directly usable in training programs, coaching, and store operations
