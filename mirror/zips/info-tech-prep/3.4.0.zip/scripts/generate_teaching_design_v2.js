/**
 * 信息科技备课助手 - 教案生成器 v2 (Node.js版)
 * 深蓝主题 (#1F6BB7) + 九章节完整结构
 *
 * 用法:
 *   node generate_teaching_design_v2.js <output.docx>
 *   或 const { generateTeachingDesign, makeConfig } = require('./generate_teaching_design_v2.js');
 */
const {
    Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
    AlignmentType, WidthType, TableLayoutType,
    convertInchesToTwip, convertMillimetersToTwip,
    ShadingType, VerticalAlign, BorderStyle
} = require('docx');
const fs = require('fs');

// ─────────────────────────────────────────────
// 配色常量
// ─────────────────────────────────────────────
const C_PRIMARY    = '1F6BB7';  // 主色（深蓝）
const C_HEADER_BG = 'D6E4F7';  // 表头底（浅蓝）
const C_SECTION_BG = 'EEF4FB';  // 章节底
const C_BORDER     = 'A0BFE0';  // 边框
const C_TEXT       = '1A1A1A';  // 正文
const C_HINT       = '888888';  // 提示（灰色斜体）

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 创建带边框和背景的单元格
 */
function makeCell(children, opts = {}) {
    const {
        bg = null,
        width = null,
        borders = null,
        verticalAlign = VerticalAlign.CENTER,
    } = opts;
    return new TableCell({
        children,
        width: width ? { size: width, type: WidthType.PERCENTAGE } : undefined,
        shading: bg ? { type: ShadingType.CLEAR, color: 'auto', fill: bg } : undefined,
        verticalAlign,
    });
}

/**
 * 创建单元格内的段落
 */
function makePara(text, opts = {}) {
    const {
        bold = false,
        size = 22,       // docx用half-points，所以12pt=24
        color = C_TEXT,
        align = AlignmentType.LEFT,
        italic = false,
    } = opts;
    return new Paragraph({
        alignment: align,
        children: [new TextRun({ text, bold, size, color, italic, font: '微软雅黑' })],
    });
}

/**
 * 深蓝章节标题条
 */
function sectionTitle(text) {
    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        borders: {
            top: { style: BorderStyle.SINGLE, size: 4, color: C_BORDER },
            bottom: { style: BorderStyle.SINGLE, size: 4, color: C_BORDER },
            left: { style: BorderStyle.SINGLE, size: 4, color: C_BORDER },
            right: { style: BorderStyle.SINGLE, size: 4, color: C_BORDER },
        },
        rows: [new TableRow({
            children: [new TableCell({
                children: [new Paragraph({
                    alignment: AlignmentType.LEFT,
                    children: [new TextRun({ text: `  ${text}  `, bold: true, size: 24, color: 'FFFFFF', font: '微软雅黑' })],
                })],
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_PRIMARY },
            })],
        })],
    });
}

/**
 * 普通文本段落
 */
function textPara(text, opts = {}) {
    const { indent = 0, bold = false, size = 22, color = C_TEXT, italic = false } = opts;
    return new Paragraph({
        spacing: { before: 60, after: 60 },
        indent: indent ? { left: indent } : undefined,
        children: [new TextRun({ text, bold, size, color, italic, font: '微软雅黑' })],
    });
}

/**
 * 带底色的信息行
 */
function infoRow(label, value, labelBg = C_HEADER_BG) {
    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [new TableRow({
            children: [
                new TableCell({
                    children: [new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [new TextRun({ text: label, bold: true, size: 20, color: C_TEXT, font: '微软雅黑' })],
                    })],
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: labelBg },
                    width: { size: 20, type: WidthType.PERCENTAGE },
                }),
                new TableCell({
                    children: [new Paragraph({
                        children: [new TextRun({ text: value, size: 20, color: C_TEXT, font: '微软雅黑' })],
                    })],
                }),
            ],
        })],
    });
}

/**
 * 五列教学过程表
 */
function processTable(rowsData) {
    const headers = ['教学环节', '时长', '教师活动', '学生活动', '设计意图'];
    const widths = [18, 8, 34, 34, 24]; // 百分比

    const headerRow = new TableRow({
        tableHeader: true,
        children: headers.map((h, i) => new TableCell({
            children: [new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ text: h, bold: true, size: 22, color: 'FFFFFF', font: '微软雅黑' })],
            })],
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_PRIMARY },
            width: { size: widths[i], type: WidthType.PERCENTAGE },
        })),
    });

    const dataRows = rowsData.map((row, ri) => {
        const bg = ri % 2 === 0 ? 'FFFFFF' : C_SECTION_BG;
        return new TableRow({
            children: row.map((val, ci) => {
                const lines = String(val || '').split('\n');
                return new TableCell({
                    children: lines.map((line, li) =>
                        new Paragraph({
                            children: [new TextRun({ text: line, size: 20, color: C_TEXT, font: '微软雅黑' })],
                        })
                    ),
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: bg },
                    width: { size: widths[ci], type: WidthType.PERCENTAGE },
                });
            }),
        });
    });

    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [headerRow, ...dataRows],
        layout: TableLayoutType.FIXED,
    });
}

/**
 * 两列标签值表
 */
function twoColTable(rowsData) {
    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: rowsData.map(([label, value]) => new TableRow({
            children: [
                new TableCell({
                    children: [new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [new TextRun({ text: label, bold: true, size: 20, color: C_TEXT, font: '微软雅黑' })],
                    })],
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_HEADER_BG },
                    width: { size: 20, type: WidthType.PERCENTAGE },
                }),
                new TableCell({
                    children: [new Paragraph({
                        children: [new TextRun({ text: value || '', size: 20, color: C_TEXT, font: '微软雅黑' })],
                    })],
                }),
            ],
        })),
    });
}

/**
 * 板书设计表格
 */
function boardDesignTable(contentRows) {
    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
            new TableRow({
                children: [new TableCell({
                    children: contentRows.slice(0, 1).map(([main, sub]) => [
                        new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: main, bold: true, size: 32, color: C_PRIMARY, font: '微软雅黑' })],
                        }),
                        ...(sub ? [new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: sub, size: 20, color: C_HINT, italic: true, font: '微软雅黑' })],
                        })] : []),
                    ]).flat(),
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_SECTION_BG },
                })],
            }),
            new TableRow({
                children: [new TableCell({
                    children: contentRows.slice(1).map(([text, bold]) =>
                        new Paragraph({
                            children: [new TextRun({
                                text: bold ? text : `    ${text}`,
                                bold: !!bold,
                                size: bold ? 22 : 20,
                                color: bold ? C_PRIMARY : C_TEXT,
                                font: '微软雅黑',
                            })],
                        })
                    ),
                })],
            }),
        ],
    });
}

/**
 * 教学反思表格
 */
function reflectionTable(items) {
    return items.map(([title, hint]) =>
        new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [new TableRow({
                children: [
                    new TableCell({
                        children: [new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: title, bold: true, size: 20, font: '微软雅黑' })],
                        })],
                        shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_HEADER_BG },
                        width: { size: 20, type: WidthType.PERCENTAGE },
                    }),
                    new TableCell({
                        children: [
                            new Paragraph({ children: [new TextRun({ text: hint, size: 18, color: C_HINT, italic: true, font: '微软雅黑' })] }),
                            new Paragraph({ children: [new TextRun({ text: '　', size: 20, font: '微软雅黑' })] }),
                        ],
                    }),
                ],
            })],
        })
    );
}

// ─────────────────────────────────────────────
// 便捷配置函数（与Python版make_config兼容）
// ─────────────────────────────────────────────

/**
 * 构建配置字典（与Python版make_config签名一致）
 */
function makeConfig(config) {
    return config;
}

// ─────────────────────────────────────────────
// 主生成函数
// ─────────────────────────────────────────────

/**
 * 生成完整教学设计 Word 文档（深蓝主题九章节结构）
 */
async function generateTeachingDesign(config, outputPath) {
    const children = [];

    // ── 封面标题 ──
    children.push(new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [new TableRow({
            children: [new TableCell({
                children: [
                    new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [new TextRun({ text: config.title || '课题名', bold: true, size: 44, color: 'FFFFFF', font: '微软雅黑' })],
                    }),
                ],
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: C_PRIMARY },
            })],
        })],
    }));
    children.push(new Paragraph({ spacing: { before: 60, after: 60 }, children: [] }));

    // ── 一、基本信息 ──
    children.push(sectionTitle('一、基本信息'));
    const sa = config.student_analysis || {};
    children.push(twoColTable([
        ['教材版本', config.book_version || '湘科版小学信息科技'],
        ['年级学期', config.grade || ''],
        ['单元课题', config.unit || ''],
        ['课时', config.period || '1课时（40分钟）'],
        ['课型', config.class_type || '新授课'],
        ...(config.curriculum_points ? [['课标要点', config.curriculum_points]] : []),
    ]));
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 二、学情分析 ──
    children.push(sectionTitle('二、学情分析'));
    children.push(twoColTable([
        ['已有知识与技能', sa.knowledge || ''],
        ['学习习惯与认知特点', sa.habits || ''],
        ['已有生活经验', sa.experience || ''],
        ['预期学习难点', sa.difficulty || ''],
    ]));
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 三、教学目标 ──
    children.push(sectionTitle('三、教学目标'));
    const obj = config.objectives || {};
    if (obj.knowledge?.length) {
        children.push(textPara('【知识与技能】', { bold: true, color: C_PRIMARY, size: 22 }));
        obj.knowledge.forEach(t => children.push(textPara(`• ${t}`, { indent: 300 })));
    }
    if (obj.process?.length) {
        children.push(textPara('【过程与方法】', { bold: true, color: C_PRIMARY, size: 22 }));
        obj.process.forEach(t => children.push(textPara(`• ${t}`, { indent: 300 })));
    }
    if (obj.emotion?.length) {
        children.push(textPara('【情感态度与价值观】', { bold: true, color: C_PRIMARY, size: 22 }));
        obj.emotion.forEach(t => children.push(textPara(`• ${t}`, { indent: 300 })));
    }
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 四、教学重点与难点 ──
    children.push(sectionTitle('四、教学重点与难点'));
    if (config.key_points?.length) {
        children.push(textPara('教学重点：', { bold: true, color: C_PRIMARY }));
        config.key_points.forEach(p => children.push(textPara(`• ${p}`, { indent: 300 })));
    }
    if (config.difficult_points?.length) {
        children.push(textPara('教学难点：', { bold: true, color: 'FF6D00' }));
        config.difficult_points.forEach(p => children.push(textPara(`• ${p}`, { indent: 300 })));
    }
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 五、教学准备 ──
    children.push(sectionTitle('五、教学准备'));
    const prep = config.preparation || {};
    if (prep.teacher?.length) {
        children.push(textPara('教师准备：', { bold: true, color: C_PRIMARY }));
        prep.teacher.forEach(p => children.push(textPara(`• ${p}`, { indent: 300 })));
    }
    if (prep.student?.length) {
        children.push(textPara('学生准备：', { bold: true, color: C_PRIMARY }));
        prep.student.forEach(p => children.push(textPara(`• ${p}`, { indent: 300 })));
    }
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 六、教学过程 ──
    children.push(sectionTitle('六、教学过程'));
    if (config.process_summary?.length) {
        const tableRows = config.process_summary.map(p =>
            [p.环节 || '', p.时长 || '', p.教师活动 || '', p.学生活动 || '', p.设计意图 || '']
        );
        children.push(processTable(tableRows));
    }
    if (config.process_details) {
        for (const [sectionName, items] of Object.entries(config.process_details)) {
            children.push(textPara(sectionName, { bold: true, color: C_PRIMARY }));
            items.forEach(item => {
                if (item.type === 'subtitle') {
                    children.push(textPara(item.text, { bold: true, color: C_PRIMARY }));
                } else if (item.type === 'bullet') {
                    children.push(textPara(`• ${item.text}`, { indent: 300 }));
                } else {
                    children.push(textPara(item.text, { indent: 200 }));
                }
            });
        }
    }
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 七、分层作业 ──
    children.push(sectionTitle('七、分层作业'));
    const asgn = config.assignments || {};
    if (asgn.basic?.length) {
        children.push(textPara('基础任务（全体）：', { bold: true, color: C_PRIMARY }));
        asgn.basic.forEach(t => children.push(textPara(`• ${t}`, { indent: 300 })));
    }
    if (asgn.advanced?.length) {
        children.push(textPara('提升任务（学有余力）：', { bold: true, color: 'FF6D00' }));
        asgn.advanced.forEach(t => children.push(textPara(`• ${t}`, { indent: 300 })));
    }
    children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));

    // ── 八、板书设计 ──
    if (config.board_design?.length) {
        children.push(sectionTitle('八、板书设计'));
        children.push(boardDesignTable(config.board_design));
        children.push(new Paragraph({ spacing: { before: 80, after: 0 }, children: [] }));
    }

    // ── 九、教学反思 ──
    if (config.reflection?.length) {
        children.push(sectionTitle('九、教学反思'));
        reflectionTable(config.reflection).forEach(t => children.push(t));
    }

    // ── 生成文档 ──
    const doc = new Document({
        sections: [{
            properties: {
                page: {
                    size: { width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
                    margin: { top: convertInchesToTwip(0.8), bottom: convertInchesToTwip(0.8), left: convertInchesToTwip(0.8), right: convertInchesToTwip(0.8) },
                },
            },
            children,
        }],
    });

    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync(outputPath, buffer);
    console.log(`教案已生成: ${outputPath}`);
    return outputPath;
}

// ─────────────────────────────────────────────
// 主入口
// ─────────────────────────────────────────────
if (require.main === module) {
    const args = process.argv.slice(2);
    const output = args[0] || require('path').join(__dirname, 'test_teaching_design.docx');

    const testConfig = makeConfig({
        title: '推荐算法的妙用',
        grade: '五年级下册',
        unit: '第二单元第3课 推荐算法的妙用',
        period: '1课时（40分钟）',
        class_type: '新授课',
        curriculum_points: '通过实例了解推荐算法的基本原理...',
        student_analysis: {
            knowledge: '学生已学过匹配算法基本概念...',
            habits: '五年级学生活泼好动...',
            experience: '学生每天都在接触推荐算法...',
            difficulty: '理解协同过滤较抽象...',
        },
        objectives: {
            knowledge: ['了解推荐算法的定义', '能举出3个生活中的推荐算法应用'],
            process: ['能分析推荐算法的推荐依据', '体验数据分析的过程'],
            emotion: ['体会算法对生活的影响', '培养批判性思维'],
        },
        key_points: ['了解推荐算法的定义', '知道推荐算法的应用场景', '能分析推荐算法的推荐依据'],
        difficult_points: ['理解协同过滤的基本原理'],
        preparation: {
            teacher: ['准备教学课件', '准备学生平板/电脑', '设计课堂活动'],
            student: ['预习教材相关章节', '带好学习用品'],
        },
        process_summary: [
            { 环节: '情境导入', 时长: '约3′', 教师活动: '播放短视频...', 学生活动: '观看思考', 设计意图: '激发兴趣' },
            { 环节: '新知讲解', 时长: '约15′', 教师活动: '讲解原理...', 学生活动: '听讲记录', 设计意图: '建构知识' },
            { 环节: '实践探究', 时长: '约15′', 教师活动: '指导操作...', 学生活动: '动手实践', 设计意图: '做中学' },
            { 环节: '总结评价', 时长: '约7′', 教师活动: '引导总结...', 学生活动: '分享收获', 设计意图: '梳理提升' },
        ],
        assignments: {
            basic: ['完成课后练习1-3题', '举例说明推荐算法在生活中的应用'],
            advanced: ['思考：推荐算法有哪些优缺点？'],
        },
        board_design: [
            ['推荐算法的妙用', '五年级下册 第二单元'],
            ['一、什么是推荐算法：', true],
            ['根据用户的兴趣偏好，自动推荐内容的技术', false],
            ['二、推荐算法的应用：', true],
            ['购物网站、短视频、音乐APP、新闻资讯', false],
            ['三、推荐算法的原理：', true],
            ['分析用户行为 → 匹配内容 → 排序呈现', false],
        ],
        reflection: [
            ['目标达成情况', '学生对推荐算法的理解程度如何？'],
            ['课堂亮点', '哪个环节学生参与度最高？'],
            ['待改进之处', '哪些地方讲解不够清晰？'],
            ['下次改进计划', '下次如何调整教学设计？'],
        ],
    });

    generateTeachingDesign(testConfig, output).catch(err => console.error('生成失败:', err));
}

module.exports = { generateTeachingDesign, makeConfig };
