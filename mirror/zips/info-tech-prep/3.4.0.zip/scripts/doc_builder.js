/**
 * 信息科技备课助手 - Word文档生成工具 (Node.js版)
 * 使用 docx npm 库 (v9)
 *
 * 用法:
 *   const { generateTaskSheet, generateTeachingPlan } = require('./doc_builder.js');
 *   generateTaskSheet(info, outputPath);
 */
const {
    Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
    AlignmentType, BorderStyle, WidthType, TableLayoutType,
    HeadingLevel, convertInchesToTwip, convertMillimetersToTwip,
    PageOrientation, VerticalAlign, ShadingType
} = require('docx');
const fs = require('fs');

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 创建带背景色的段落
 */
function createColoredHeading(text, opts = {}) {
    const {
        fontSize = 14,
        bold = true,
        color = 'FFFFFF',
        bgColor = '1A73E8',
        leftPadding = 200,
    } = opts;

    return new Paragraph({
        spacing: { before: 100, after: 60 },
        children: [
            new TextRun({
                text: ` ${text} `,
                bold,
                size: fontSize * 2,
                color,
                font: '微软雅黑',
            }),
        ],
        shading: {
            type: ShadingType.CLEAR,
            color: 'auto',
            fill: bgColor,
        },
    });
}

/**
 * 创建普通段落
 */
function createParagraph(text, opts = {}) {
    const {
        fontSize = 12,
        bold = false,
        color = '1A233A',
        indent = 0,
        spacingBefore = 0,
        spacingAfter = 100,
        align = AlignmentType.LEFT,
        font = '微软雅黑',
    } = opts;

    return new Paragraph({
        spacing: { before: spacingBefore, after: spacingAfter },
        alignment: align,
        indent: indent ? { left: indent } : undefined,
        children: [
            new TextRun({ text, bold, size: fontSize * 2, color, font }),
        ],
    });
}

/**
 * 创建带前缀装饰的段落（如 >> 前缀）
 */
function createSectionTitle(text, icon = '>>', iconColor = '1A73E8') {
    return new Paragraph({
        spacing: { before: 120, after: 40 },
        children: [
            new TextRun({ text: `${icon} `, bold: true, size: 26, color: iconColor, font: '微软雅黑' }),
            new TextRun({ text, bold: true, size: 26, color: '1A233A', font: '微软雅黑' }),
        ],
    });
}

/**
 * 创建带颜色圆点的项目列表
 */
function createBullet(text, opts = {}) {
    const {
        fontSize = 12,
        bulletColor = '1A73E8',
        indent = 400,
        color = '1A233A',
    } = opts;

    return new Paragraph({
        spacing: { before: 0, after: 60 },
        indent: { left: indent },
        children: [
            new TextRun({ text: '● ', size: fontSize * 2, color: bulletColor, font: '微软雅黑' }),
            new TextRun({ text, size: fontSize * 2, color, font: '微软雅黑' }),
        ],
    });
}

/**
 * 创建有序编号列表
 */
function createNumberedItem(num, text, opts = {}) {
    const {
        fontSize = 12,
        numBgColor = '00BFD8',
        indent = 300,
        color = '1A233A',
    } = opts;

    return new Paragraph({
        spacing: { before: 0, after: 80 },
        indent: { left: indent },
        children: [
            new TextRun({
                text: `  ${num}  `,
                bold: true,
                size: fontSize * 2,
                color: 'FFFFFF',
                font: '微软雅黑',
            }),
            new TextRun({ text: ` ${text}`, size: fontSize * 2, color, font: '微软雅黑' }),
        ],
        shading: {
            type: ShadingType.CLEAR,
            color: 'auto',
            fill: numBgColor,
        },
    });
}

/**
 * 创建标准表格
 */
function createStdTable(headers, rows, opts = {}) {
    const {
        headerBg = '1A73E8',
        headerColor = 'FFFFFF',
        altBg = 'F0F4FF',
        fontSize = 12,
    } = opts;

    const tableRows = [];

    // 表头行
    tableRows.push(new TableRow({
        tableHeader: true,
        children: headers.map(h => new TableCell({
            children: [new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ text: h, bold: true, size: fontSize * 2, color: headerColor, font: '微软雅黑' })],
            })],
            shading: { type: ShadingType.CLEAR, color: 'auto', fill: headerBg },
            verticalAlign: VerticalAlign.CENTER,
        })),
    }));

    // 数据行
    rows.forEach((rowData, ri) => {
        const bg = ri % 2 === 0 ? altBg : 'FFFFFF';
        tableRows.push(new TableRow({
            children: (Array.isArray(rowData) ? rowData : Object.values(rowData)).map(cell => new TableCell({
                children: [new Paragraph({
                    children: [new TextRun({ text: String(cell || ''), size: fontSize * 2, color: '1A233A', font: '微软雅黑' })],
                })],
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: bg },
                verticalAlign: VerticalAlign.CENTER,
            })),
        }));
    });

    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: tableRows,
        layout: TableLayoutType.FIXED,
    });
}

/**
 * 创建信息提示框（左侧色条）
 */
function createInfoBox(text, opts = {}) {
    const {
        borderColor = '1A73E8',
        bgColor = 'EEF5FF',
        fontSize = 12,
    } = opts;

    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
            new TableRow({
                children: [
                    // 左色条
                    new TableCell({
                        children: [new Paragraph({ children: [] })],
                        width: { size: 10, type: WidthType.PERCENTAGE },
                        shading: { type: ShadingType.CLEAR, color: 'auto', fill: borderColor },
                    }),
                    // 内容格
                    new TableCell({
                        children: [new Paragraph({
                            children: [new TextRun({ text, size: fontSize * 2, color: '1A233A', font: '微软雅黑' })],
                        })],
                        shading: { type: ShadingType.CLEAR, color: 'auto', fill: bgColor },
                    }),
                ],
            }),
        ],
    });
}

// ─────────────────────────────────────────────
// 主生成函数
// ─────────────────────────────────────────────

/**
 * 生成学生任务单 Word文档
 *
 * info字段:
 *   title: 课题名
 *   grade: 年级
 *   objectives: [目标1, ...] 简短版
 *   preview: [(任务名, 任务内容), ...] 课前预习
 *   explore: [(活动名, 活动内容, 记录表头列表, 记录表行数), ...] 课堂探究
 *   knowledge: [(填空题/概念框, ...), ...] 知识整理
 *   exercises: [(题型, 题目, 选项列表或null), ...] 巩固练习
 *   extension: 课后拓展文本
 */
async function generateTaskSheet(info, outputPath) {
    const children = [];

    // 顶部标题栏
    children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0 },
        shading: { type: ShadingType.CLEAR, color: 'auto', fill: '1A73E8' },
        children: [new TextRun({
            text: `  《${info.title}》学生任务单  `,
            bold: true, size: 40, color: 'FFFFFF', font: '微软雅黑',
        })],
    }));

    // 副标题
    children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 60 },
        shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'EEF5FF' },
        children: [new TextRun({
            text: `  湘科版《信息科技》${info.grade}  `,
            size: 24, color: '1A73E8', font: '微软雅黑',
        })],
    }));

    // 学生信息行
    const infoTable = new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [new TableRow({
            children: ['班级：___________', '姓名：___________', '日期：___________'].map(label =>
                new TableCell({
                    children: [new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [new TextRun({ text: label, size: 24, font: '微软雅黑' })],
                    })],
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'F0F4FF' },
                })
            ),
        })],
    });
    children.push(infoTable);
    children.push(new Paragraph({ spacing: { before: 100, after: 0 }, children: [] }));

    // 学习目标
    children.push(createColoredHeading('【学习目标】完成本任务单后，我能够：', {
        fontSize: 14, bgColor: '0D47A1', color: 'FFFFFF'
    }));
    (info.objectives || []).slice(0, 4).forEach(obj => {
        children.push(new Paragraph({
            spacing: { before: 0, after: 40 },
            indent: { left: 300 },
            children: [
                new TextRun({ text: '  □  ', size: 24, font: '微软雅黑' }),
                new TextRun({ text: obj, size: 24, font: '微软雅黑' }),
            ],
        }));
    });
    children.push(new Paragraph({ spacing: { before: 100, after: 0 }, children: [] }));

    // 课前预习
    if (info.preview?.length) {
        children.push(createColoredHeading('【课前预习】', { fontSize: 14, bgColor: '00838F' }));
        info.preview.forEach(([taskName, taskContent]) => {
            children.push(createSectionTitle(taskName, '▶', '00838F'));
            children.push(new Paragraph({
                spacing: { before: 0, after: 0 },
                indent: { left: 400 },
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'E0F7FA' },
                children: [new TextRun({ text: taskContent, size: 24, font: '微软雅黑' })],
            }));
            // 填写空间
            for (let i = 0; i < 3; i++) {
                children.push(new Paragraph({
                    spacing: { before: 0, after: 0 },
                    indent: { left: 400 },
                    shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'FAFAFA' },
                    children: [new TextRun({ text: '我的想法：_____________________________________________', size: 22, color: '888888', font: '微软雅黑' })],
                }));
            }
        });
        children.push(new Paragraph({ spacing: { before: 100, after: 0 }, children: [] }));
    }

    // 课堂探究
    if (info.explore?.length) {
        children.push(createColoredHeading('【课堂探究】', { fontSize: 14, bgColor: '1A73E8' }));
        info.explore.forEach(([actName, actContent, tableHeaders, tableRowsN]) => {
            children.push(createSectionTitle(actName, '▶', '1A73E8'));
            children.push(new Paragraph({
                spacing: { before: 0, after: 0 },
                indent: { left: 300 },
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'EEF5FF' },
                children: [new TextRun({ text: actContent, size: 24, font: '微软雅黑' })],
            }));
            if (tableHeaders?.length && tableRowsN > 0) {
                children.push(new Paragraph({
                    spacing: { before: 60, after: 40 },
                    children: [new TextRun({ text: '记录表：', bold: true, size: 24, font: '微软雅黑' })],
                }));
                const rows = Array.from({ length: tableRowsN }, () =>
                    tableHeaders.map(() => '')
                );
                children.push(createStdTable(tableHeaders, rows, { headerBg: '1A73E8', altBg: 'F0F4FF' }));
            }
        });
        children.push(new Paragraph({ spacing: { before: 100, after: 0 }, children: [] }));
    }

    // 知识整理
    if (info.knowledge?.length) {
        children.push(createColoredHeading('【知识整理】', { fontSize: 14, bgColor: '00695C' }));
        info.knowledge.forEach(item => {
            children.push(new Paragraph({
                spacing: { before: 0, after: 80 },
                indent: { left: 400 },
                shading: { type: ShadingType.CLEAR, color: 'auto', fill: 'E8F5E9' },
                children: [new TextRun({ text: item, size: 24, font: '微软雅黑' })],
            }));
        });
    }

    // 巩固练习
    if (info.exercises?.length) {
        children.push(createColoredHeading('【巩固练习】', { fontSize: 14, bgColor: '546E7A' }));
        info.exercises.forEach(([qtype, question, options]) => {
            children.push(new Paragraph({
                spacing: { before: 80, after: 40 },
                children: [
                    new TextRun({ text: `${qtype}：`, bold: true, size: 24, font: '微软雅黑' }),
                    new TextRun({ text: question, size: 24, font: '微软雅黑' }),
                ],
            }));
            if (options?.length) {
                options.forEach(opt => {
                    children.push(new Paragraph({
                        spacing: { before: 0, after: 20 },
                        indent: { left: 600 },
                        children: [new TextRun({ text: opt, size: 24, font: '微软雅黑' })],
                    }));
                });
            }
        });
    }

    // 课后拓展
    if (info.extension) {
        children.push(createColoredHeading('【课后拓展】', { fontSize: 14, bgColor: '6A1B9A' }));
        children.push(new Paragraph({
            spacing: { before: 0, after: 60 },
            indent: { left: 300 },
            children: [new TextRun({ text: info.extension, size: 24, font: '微软雅黑' })],
        }));
    }

    // 生成文档
    const doc = new Document({
        sections: [{
            properties: {
                page: {
                    size: { width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
                    margin: { top: convertInchesToTwip(0.8), bottom: convertInchesToTwip(0.8), left: convertInchesToTwip(0.8), right: convertInchesToTwip(0.8) },
                },
            },
            children,
        }],
    });

    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync(outputPath, buffer);
    console.log(`学生任务单已生成: ${outputPath}`);
    return outputPath;
}

/**
 * 生成简易教学设计 Word文档（v1格式）
 */
async function generateTeachingPlan(info, outputPath) {
    const children = [];

    // 标题
    children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 100 },
        shading: { type: ShadingType.CLEAR, color: 'auto', fill: '1A73E8' },
        children: [new TextRun({ text: `  《${info.title}》教学设计  `, bold: true, size: 40, color: 'FFFFFF', font: '微软雅黑' })],
    }));

    // 基本信息表格
    const basicInfo = [
        ['教材版本', info.grade || ''],
        ['课题名称', info.title || ''],
        ['课时安排', info.period || ''],
        ['课型', info.classType || '新授课'],
    ];
    children.push(createStdTable(['项目', '内容'], basicInfo, { headerBg: '1A73E8', altBg: 'F0F4FF' }));
    children.push(new Paragraph({ spacing: { before: 100, after: 0 }, children: [] }));

    // 教材分析
    if (info.analysis) {
        children.push(createColoredHeading('一、教材分析', { fontSize: 14, bgColor: '1A73E8' }));
        children.push(createParagraph(info.analysis, { indent: 200 }));
    }

    // 学情分析
    if (info.students) {
        children.push(createColoredHeading('二、学情分析', { fontSize: 14, bgColor: '1A73E8' }));
        children.push(createParagraph(info.students, { indent: 200 }));
    }

    // 教学目标
    if (info.objectives?.length) {
        children.push(createColoredHeading('三、教学目标', { fontSize: 14, bgColor: '1A73E8' }));
        info.objectives.forEach(obj => children.push(createBullet(obj, { indent: 400 })));
    }

    // 教学重点难点
    if (info.keyPoints?.length || info.difficultPoints?.length) {
        children.push(createColoredHeading('四、教学重点与难点', { fontSize: 14, bgColor: '1A73E8' }));
        if (info.keyPoints?.length) {
            children.push(createSectionTitle('教学重点', '▶', '1A73E8'));
            info.keyPoints.forEach(p => children.push(createBullet(p, { indent: 500 })));
        }
        if (info.difficultPoints?.length) {
            children.push(createSectionTitle('教学难点', '▶', 'FF6D00'));
            info.difficultPoints.forEach(p => children.push(createBullet(p, { indent: 500 })));
        }
    }

    // 教学过程
    if (info.process?.length) {
        children.push(createColoredHeading('五、教学过程', { fontSize: 14, bgColor: '1A73E8' }));
        const headers = ['环节', '教师活动', '学生活动', '设计意图', '时长'];
        const rows = info.process.map(p =>
            Array.isArray(p) ? p : [p.环节 || '', p.教师活动 || '', p.学生活动 || '', p.设计意图 || '', p.时长 || '']
        );
        children.push(createStdTable(headers, rows, { headerBg: '1A73E8', altBg: 'F0F4FF' }));
    }

    // 板书设计
    if (info.board_design) {
        children.push(createColoredHeading('六、板书设计', { fontSize: 14, bgColor: '1A73E8' }));
        children.push(createParagraph(info.board_design, { indent: 200 }));
    }

    // 教学反思
    if (info.reflection) {
        children.push(createColoredHeading('七、教学反思', { fontSize: 14, bgColor: '1A73E8' }));
        children.push(createParagraph(info.reflection, { indent: 200 }));
    }

    const doc = new Document({
        sections: [{
            properties: {
                page: {
                    size: { width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
                    margin: { top: convertInchesToTwip(0.8), bottom: convertInchesToTwip(0.8), left: convertInchesToTwip(0.8), right: convertInchesToTwip(0.8) },
                },
            },
            children,
        }],
    });

    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync(outputPath, buffer);
    console.log(`教学设计已生成: ${outputPath}`);
    return outputPath;
}

module.exports = { generateTaskSheet, generateTeachingPlan, createColoredHeading, createParagraph, createSectionTitle, createBullet, createNumberedItem, createStdTable, createInfoBox };
