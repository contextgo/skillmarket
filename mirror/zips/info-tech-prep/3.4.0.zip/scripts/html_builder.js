/**
 * 信息科技备课助手 - HTML互动工具底层库 (Node.js版) v2.0
 * 新增图文并茂版知识学习区、身份证解析器互动功能
 */
const { escapeHtml } = require('querystring');

function esc(str) {
    return String(str || '').replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>').replace(/"/g, '"');
}

/**
 * 组装完整HTML文档（图文版）
 */
function assembleHTMLRich(title, tabs, contentHtml, scriptContent) {
    const tabsHtml = tabs.map((t, i) =>
        `<button class="tab-btn ${i === 0 ? 'active' : ''}" onclick="switchTab('${t.id}', this)">${esc(t.label)}</button>`
    ).join('\n    ');

    const panelsHtml = tabs.map((t, i) =>
        `<div class="main-content ${i === 0 ? 'active' : ''}" id="${t.id}">
        ${contentHtml[t.id] || ''}
    </div>`
    ).join('\n');

    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(title)} - 互动学习工具</title>
<style>
${getCSS()}
</style>
</head>
<body>

<div class="top-bar">
  <h1>🏆 ${esc(title)}</h1>
  <div class="subtitle">🧩 一起探索知识的奥秘吧！</div>
  <div class="tab-nav">
    ${tabsHtml}
  </div>
</div>

<div class="tab-panels">
${panelsHtml}
</div>

<script>
${scriptContent}
</script>
</body>
</html>`;
}

/**
 * 获取CSS样式（图文版 v2）
 */
function getCSS() {
    return `  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;700;900&display=swap');
  :root {
    --primary: #00796b; --secondary: #004d40; --accent: #ef6c00;
    --bg: #f0f7f5; --bg-card: #ffffff; --text: #1a2a2a; --text-sub: #37474f;
    --blue: #0097a7; --blue-light: #e0f7fa;
    --green: #2e7d32; --green-light: #e8f5e9;
    --orange: #ef6c00; --orange-light: #fff3e0;
    --red: #c62828; --red-light: #ffebee;
    --purple: #6a1b9a; --purple-light: #f3e5f5;
    --pink: #c2185b; --pink-light: #fce4ec;
    --teal: #00695c; --teal-light: #e0f2f1;
    --gray: #78909c;
    --shadow: 0 3px 15px rgba(0,0,0,.1);
    --shadow-lg: 0 8px 30px rgba(0,0,0,.12);
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Noto Sans SC', 'Microsoft YaHei', 'PingFang SC', sans-serif;
    background: var(--bg); color: var(--text);
    font-size: 17px; line-height: 1.7;
  }
  .top-bar {
    background: linear-gradient(135deg, var(--primary) 0%, #00897b 50%, #26a69a 100%);
    position: sticky; top: 0; z-index: 100;
    box-shadow: 0 4px 20px rgba(0,0,0,.15);
  }
  .top-bar h1 {
    color: white; font-size: 20px; padding: 14px 28px 6px;
    text-align: center; letter-spacing: 1px;
  }
  .top-bar .subtitle {
    color: rgba(255,255,255,.8); font-size: 13px; text-align: center;
    padding-bottom: 10px; letter-spacing: 2px;
  }
  .tab-nav { display: flex; overflow-x: auto; padding: 0 16px; }
  .tab-btn {
    background: transparent; border: none;
    color: rgba(255,255,255,.7); padding: 12px 24px;
    cursor: pointer; font-size: 15px; white-space: nowrap;
    border-bottom: 3px solid transparent; transition: all .3s; font-weight: 600;
  }
  .tab-btn:hover { color: white; background: rgba(255,255,255,.1); }
  .tab-btn.active { color: #fff; border-bottom-color: #fff; background: rgba(255,255,255,.2); }
  .tab-panels { padding: 0; max-width: 100%; }
  .main-content { display: none; padding: 24px 28px 40px; max-width: 1100px; margin: 0 auto; }
  .main-content.active { display: block; }

  /* === 通用卡片 === */
  .card {
    background: var(--bg-card); border-radius: 20px; padding: 24px; margin-bottom: 20px;
    box-shadow: var(--shadow); border: 1px solid rgba(0,121,107,.08);
  }
  .card:hover { box-shadow: var(--shadow-lg); }
  .card-title {
    font-size: 18px; font-weight: 900; color: var(--primary);
    margin-bottom: 16px; display: flex; align-items: center; gap: 10px;
  }
  .card-title .icon { font-size: 22px; }

  /* === Hero 区块 === */
  .hero {
    background: linear-gradient(135deg, #e0f2f1, #b2dfdb);
    border-radius: 24px; padding: 32px 28px; margin-bottom: 24px;
    border: 2px solid rgba(0,121,107,.15); text-align: center;
  }
  .hero-icon { font-size: 64px; margin-bottom: 12px; }
  .hero h2 { font-size: 26px; font-weight: 900; color: var(--secondary); margin-bottom: 10px; letter-spacing: 1px; }
  .hero p { font-size: 16px; color: var(--text-sub); max-width: 600px; margin: 0 auto; line-height: 1.8; }

  /* === 真实物品模拟卡片（v3）=== */
  .real-items-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
  .mock-card-hint { font-size: 11px; color: var(--text-sub); text-align: center; margin-top: 8px; }

  /* ① 真实身份证 */
  .id-card-mock { background: linear-gradient(145deg,#1a7a3c 0%,#0d5c28 100%); border-radius: 14px; overflow: hidden; box-shadow: 0 6px 20px rgba(13,92,40,.4); border: 3px solid #b8860b; position: relative; min-height: 220px; }
  .id-card-mock::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 60px; background: linear-gradient(135deg,#b8860b,#daa520); border-radius: 11px 11px 0 0; }
  .id-card-header { padding: 14px 16px 8px; display: flex; align-items: center; gap: 8px; position: relative; z-index: 1; }
  .id-card-emblem { width: 28px; height: 28px; background: #daa520; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 900; color: #0d5c28; border: 1.5px solid #b8860b; flex-shrink: 0; }
  .id-card-title { color: white; font-size: 13px; font-weight: 900; letter-spacing: 3px; text-shadow: 0 1px 2px rgba(0,0,0,.3); }
  .id-card-subtitle { color: rgba(255,255,255,.6); font-size: 9px; letter-spacing: 1px; margin-top: 1px; }
  .id-card-body { padding: 0 16px 14px; display: flex; gap: 12px; position: relative; z-index: 1; }
  .id-card-photo { width: 72px; height: 90px; background: #c8e6c9; border: 2px solid rgba(255,255,255,.4); border-radius: 4px; flex-shrink: 0; overflow: hidden; }
  .photo-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg,#a5d6a7,#81c784); display: flex; flex-direction: column; align-items: center; justify-content: center; }
  .photo-head { width: 28px; height: 28px; background: rgba(255,255,255,.5); border-radius: 50%; margin-bottom: 4px; }
  .photo-body { width: 36px; height: 20px; background: rgba(255,255,255,.4); border-radius: 6px 6px 0 0; }
  .id-card-fields { flex: 1; }
  .id-card-field { display: flex; align-items: baseline; gap: 6px; margin-bottom: 6px; }
  .field-label { color: rgba(255,255,255,.65); font-size: 10px; min-width: 52px; }
  .field-value { color: white; font-size: 12px; font-weight: 700; letter-spacing: 1px; }
  .id-card-number-row { background: rgba(0,0,0,.15); margin: 0 -16px -14px; padding: 10px 16px 12px; border-top: 1px solid rgba(255,255,255,.1); display: flex; align-items: center; gap: 8px; }
  .id-card-num-label { color: rgba(255,255,255,.6); font-size: 9px; letter-spacing: 1px; }
  .id-card-num { color: white; font-size: 15px; font-weight: 900; letter-spacing: 3px; font-family: 'Courier New', monospace; }

  /* ② 商品条形码 */
  .barcode-mock { background: white; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,.1); border: 2px solid #ddd; padding: 20px 16px 14px; display: flex; flex-direction: column; align-items: center; }
  .barcode-strip { display: flex; align-items: flex-end; gap: 1.5px; height: 70px; margin-bottom: 8px; }
  .bar { background: #222; border-radius: 1px; flex-shrink: 0; }
  .barcode-number { font-family: 'Courier New', monospace; font-size: 13px; letter-spacing: 2px; color: #444; font-weight: bold; margin-bottom: 4px; }
  .barcode-label { font-size: 12px; color: var(--text-sub); text-align: center; margin-top: 6px; background: #f9f9f9; width: 100%; padding: 6px; border-radius: 6px; }

  /* ③ 快递单 */
  .express-mock { background: white; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,.1); border: 2px solid #ff9800; position: relative; }
  .express-top { background: #ff9800; padding: 8px 14px; display: flex; align-items: center; justify-content: space-between; }
  .express-logo { color: white; font-size: 11px; font-weight: 900; letter-spacing: 2px; }
  .express-stamp { background: white; color: #e53935; border: 2px solid #e53935; border-radius: 4px; padding: 2px 8px; font-size: 10px; font-weight: 900; transform: rotate(-5deg); }
  .express-body { padding: 12px 14px; }
  .express-row { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
  .express-row-label { font-size: 10px; color: var(--gray); }
  .express-row-value { font-size: 12px; font-weight: 700; color: var(--text); font-family: 'Courier New', monospace; }
  .express-barcode-strip { background: white; margin: 0 -2px -2px; padding: 10px 14px; border-top: 1px dashed #eee; display: flex; align-items: center; gap: 10px; }
  .express-barcode-mini { display: flex; align-items: flex-end; gap: 1px; height: 28px; }
  .express-trace-num { font-size: 10px; color: var(--gray); font-family: 'Courier New', monospace; }

  /* ④ 学生证 */
  .student-card-mock { background: linear-gradient(145deg,#c62828 0%,#8e0000 100%); border-radius: 14px; overflow: hidden; box-shadow: 0 6px 20px rgba(198,40,40,.35); border: 3px solid #ffcdd2; position: relative; min-height: 200px; }
  .student-card-header { background: rgba(255,255,255,.12); padding: 10px 14px 6px; text-align: center; border-bottom: 1px solid rgba(255,255,255,.15); }
  .student-emblem { width: 36px; height: 36px; background: rgba(255,255,255,.2); border-radius: 50%; margin: 0 auto 4px; display: flex; align-items: center; justify-content: center; border: 1.5px solid rgba(255,255,255,.3); }
  .student-emblem-inner { width: 20px; height: 20px; background: rgba(255,255,255,.25); border-radius: 50%; }
  .student-school-name { color: white; font-size: 10px; font-weight: 900; letter-spacing: 2px; }
  .student-card-body { padding: 10px 14px 12px; }
  .student-info-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 5px; }
  .student-label { color: rgba(255,255,255,.65); font-size: 9px; min-width: 40px; }
  .student-value { color: white; font-size: 11px; font-weight: 700; }
  .student-id-row { background: rgba(0,0,0,.15); margin: 6px -14px -12px; padding: 8px 14px; display: flex; align-items: center; gap: 8px; }
  .student-id-label { color: rgba(255,255,255,.6); font-size: 9px; }
  .student-id { color: white; font-size: 13px; font-weight: 900; letter-spacing: 2px; font-family: 'Courier New', monospace; }

  /* ⑤ 邮政编码信封 */
  .postal-mock { background: white; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,.1); border: 2px solid #1976d2; position: relative; }
  .postal-top { background: #1976d2; padding: 8px 14px; display: flex; align-items: center; gap: 8px; }
  .postal-logo { color: white; font-size: 10px; font-weight: 900; letter-spacing: 2px; }
  .postal-stamp { width: 42px; height: 42px; border: 2px solid white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 9px; font-weight: 900; text-align: center; line-height: 1.2; margin-left: auto; }
  .postal-body { padding: 14px; }
  .postal-address-area { border: 1.5px solid #1976d2; border-radius: 6px; padding: 12px; margin-bottom: 10px; position: relative; }
  .postal-to-label { position: absolute; top: -10px; left: 10px; background: white; padding: 0 6px; font-size: 10px; color: #1976d2; font-weight: 900; }
  .postal-address-text { font-size: 13px; font-weight: 700; color: var(--text); line-height: 1.6; }
  .postal-code-area { display: flex; align-items: center; justify-content: flex-end; gap: 6px; }
  .postal-code-box { background: #e3f2fd; border: 1.5px solid #1976d2; border-radius: 4px; padding: 6px 12px; text-align: center; }
  .postal-code { font-size: 18px; font-weight: 900; color: #1565c0; letter-spacing: 3px; font-family: 'Courier New', monospace; }
  .postal-code-label { font-size: 9px; color: #1976d2; }

  /* === 身份证可视化 === */
  .id-visual { background: linear-gradient(135deg, #e3f2fd, #bbdefb); border-radius: 16px; padding: 24px; margin-bottom: 16px; border: 2px solid #90caf9; }
  .id-visual-title { font-size: 17px; font-weight: 900; color: #1565c0; margin-bottom: 16px; text-align: center; }
  .id-number-display {
    background: white; border-radius: 12px; padding: 16px 20px;
    display: flex; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,.08);
    margin-bottom: 16px; font-family: 'Courier New', monospace; font-size: 22px;
    font-weight: bold; letter-spacing: 2px;
  }
  .id-segment { padding: 10px 8px; text-align: center; border-right: 2px dashed #ccc; flex-shrink: 0; min-width: 52px; }
  .id-segment:last-child { border-right: none; }
  .id-segment.n1 { color: #e53935; flex: 0 0 18%; }
  .id-segment.n2 { color: #1e88e5; flex: 0 0 22%; }
  .id-segment.n3 { color: #43a047; flex: 0 0 14%; }
  .id-segment.n4 { color: #fb8c00; flex: 0 0 7%; }
  .id-segment-label { font-size: 10px; color: #666; margin-top: 4px; display: block; font-family: 'Noto Sans SC', sans-serif; letter-spacing: 0; }
  .id-legend { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
  .legend-item { background: white; border-radius: 12px; padding: 14px 16px; display: flex; align-items: flex-start; gap: 12px; box-shadow: 0 1px 4px rgba(0,0,0,.06); }
  .legend-dot { width: 12px; height: 12px; border-radius: 50%; flex-shrink: 0; margin-top: 4px; }
  .legend-text { font-size: 14px; font-weight: 700; }
  .legend-desc { font-size: 12px; color: var(--text-sub); }

  /* === 身份证解析器 === */
  .id-analyzer { background: linear-gradient(135deg, #fce4ec, #f8bbd0); border-radius: 16px; padding: 24px; margin-top: 16px; border: 2px solid #f48fb1; }
  .analyzer-title { font-size: 17px; font-weight: 900; color: var(--pink); margin-bottom: 14px; text-align: center; }
  .id-input-row { display: flex; gap: 12px; margin-bottom: 16px; }
  .id-input {
    flex: 1; padding: 12px 18px; border-radius: 12px; border: 2px solid #f48fb1;
    font-size: 20px; font-family: 'Courier New', monospace; letter-spacing: 3px;
    outline: none; transition: border .3s;
  }
  .id-input:focus { border-color: var(--pink); box-shadow: 0 0 0 3px rgba(233,30,99,.1); }
  .analyze-btn {
    padding: 12px 28px; border-radius: 12px; border: none;
    background: linear-gradient(135deg, var(--pink), #e91e63);
    color: white; font-size: 16px; font-weight: 900; cursor: pointer;
    transition: all .3s; white-space: nowrap;
  }
  .analyze-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(233,30,99,.4); }
  .id-result { display: none; background: white; border-radius: 14px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.07); }
  .id-result.show { display: block; }
  .result-row { display: flex; align-items: flex-start; gap: 12px; padding: 10px 0; border-bottom: 1px dashed #eee; font-size: 15px; }
  .result-row:last-child { border-bottom: none; }
  .result-badge { background: #fce4ec; color: var(--pink); padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: 900; flex-shrink: 0; min-width: 80px; text-align: center; }
  .result-value { font-weight: 700; color: var(--secondary); font-size: 15px; }
  .result-note { font-size: 13px; color: var(--text-sub); }
  .id-error { color: var(--red); font-size: 14px; text-align: center; padding: 10px; display: none; }

  /* === 学号规则 === */
  .rule-cards { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; }
  .rule-card { background: white; border-radius: 14px; padding: 20px; border-left: 5px solid var(--green); box-shadow: 0 2px 8px rgba(0,0,0,.06); position: relative; overflow: hidden; }
  .rule-card .rule-num { font-size: 36px; font-weight: 900; color: var(--green-light); -webkit-text-stroke: 1px var(--green); position: absolute; right: 16px; top: 8px; line-height: 1; }
  .rule-card h4 { font-size: 16px; color: var(--green); margin-bottom: 8px; font-weight: 900; }
  .rule-card p { font-size: 14px; color: var(--text-sub); line-height: 1.7; }
  .rule-card .emoji { font-size: 32px; position: absolute; right: 14px; bottom: 10px; opacity: .3; }

  /* === 拖拽区 === */
  .stats-bar {
    background: linear-gradient(135deg, var(--primary), #26a69a); color: white;
    padding: 14px 24px; border-radius: 14px; display: flex; align-items: center; gap: 16px;
    margin-bottom: 20px; box-shadow: 0 4px 15px rgba(0,121,107,.3); font-size: 16px;
  }
  .stats-bar .score { font-size: 22px; font-weight: 900; }
  .btn {
    display: inline-block; padding: 10px 24px; border-radius: 10px; border: none;
    cursor: pointer; font-size: 15px; font-weight: 700; transition: .2s;
    background: rgba(255,255,255,.3); color: white;
  }
  .btn:hover { background: rgba(255,255,255,.4); transform: translateY(-1px); }
  .drag-container { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
  .drag-pool {
    flex: 1; min-width: 200px; min-height: 100px; border: 2px dashed rgba(0,151,167,.35);
    border-radius: 16px; padding: 16px; background: var(--blue-light); transition: all .3s;
  }
  .drag-pool.over { background: #c8e6c9; border-color: var(--green); border-style: solid; }
  .drag-pool-title { font-size: 15px; color: var(--gray); margin-bottom: 12px; font-weight: 800; text-align: center; }
  .drag-chip {
    background: white; border: 2px solid rgba(0,151,167,.4); border-radius: 10px;
    padding: 10px 18px; cursor: grab; user-select: none; transition: all .2s;
    font-size: 16px; display: inline-block; margin: 5px; font-weight: 700;
    color: var(--secondary); box-shadow: 0 2px 6px rgba(0,0,0,.08);
  }
  .drag-chip:hover { transform: scale(1.06); box-shadow: 0 6px 18px rgba(0,0,0,.15); border-color: var(--blue); }
  .drag-chip.placed { background: var(--green-light); border-color: var(--green); opacity: .7; cursor: default; }
  .dropped-items { min-height: 40px; }

  /* === 选择题 === */
  .quiz-card { background: var(--bg-card); border-radius: 18px; padding: 24px; margin-bottom: 18px; box-shadow: var(--shadow); border: 1px solid rgba(0,0,0,.05); transition: all .3s; }
  .quiz-card:hover { box-shadow: var(--shadow-lg); }
  .quiz-q { font-size: 17px; margin-bottom: 18px; font-weight: 800; color: var(--secondary); display: flex; align-items: flex-start; gap: 10px; }
  .quiz-q::before { content: 'Q'; font-size: 14px; background: var(--orange); color: white; width: 26px; height: 26px; border-radius: 50%; text-align: center; line-height: 26px; flex-shrink: 0; margin-top: 1px; font-weight: 900; }
  .quiz-opts { display: flex; flex-direction: column; gap: 10px; }
  .quiz-opt { background: var(--bg); padding: 14px 20px; border-radius: 12px; cursor: pointer; transition: all .2s; border: 2px solid transparent; font-size: 15px; display: flex; align-items: center; gap: 10px; font-weight: 600; }
  .quiz-opt .opt-letter { width: 28px; height: 28px; border-radius: 50%; background: var(--blue-light); color: var(--blue); font-weight: 900; text-align: center; line-height: 28px; font-size: 14px; flex-shrink: 0; }
  .quiz-opt:hover { background: var(--blue-light); border-color: var(--blue); }
  .quiz-opt.correct { background: var(--green-light); border-color: var(--green); }
  .quiz-opt.correct .opt-letter { background: var(--green); color: white; }
  .quiz-opt.wrong { background: var(--red-light); border-color: var(--red); }
  .quiz-opt.wrong .opt-letter { background: var(--red); color: white; }
  .quiz-feedback { padding: 12px 18px; border-radius: 10px; margin-top: 14px; font-weight: 700; display: none; font-size: 14px; }
  .quiz-feedback.show { display: flex; align-items: center; gap: 8px; }
  .quiz-feedback.correct { background: var(--green-light); color: var(--green); }
  .quiz-feedback.wrong { background: var(--red-light); color: var(--red); }

  /* === 完成动画 === */
  .complete-banner { background: linear-gradient(135deg, var(--green), #43a047); color: white; border-radius: 16px; padding: 20px; text-align: center; margin-bottom: 16px; display: none; animation: popIn .5s ease; }
  .complete-banner.show { display: block; }
  @keyframes popIn { 0% { transform: scale(.8); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }

  /* === 响应式 === */
  @media (max-width: 768px) {
    .encoding-grid { grid-template-columns: repeat(2, 1fr); }
    .rule-cards, .id-legend { grid-template-columns: 1fr; }
    .id-input-row { flex-direction: column; }
    .id-number-display { font-size: 16px; overflow-x: auto; }
  }
`;
}

/**
 * 生成图文知识卡片（新版，适合小学生）
 */
function richKnowledgeCard(title, icon, sections) {
    // sections: [{type:'hero', icon, title, desc}, {type:'grid', items:[{icon, label, desc, color}]},
    //           {type:'idcard', segments:[{value, label, color}]}, {type:'analyzer'}]
    let html = '';
    for (const sec of sections) {
        if (sec.type === 'hero') {
            html += `<div class="hero">
  <div class="hero-icon">${sec.icon || '🔢'}</div>
  <h2>${esc(sec.title || title)}</h2>
  <p>${esc(sec.desc || '')}</p>
</div>`;
        } else if (sec.type === 'grid') {
            const colorMap = { food: 'food', cloth: 'cloth', home: 'home', travel: 'travel' };
            const itemsHtml = (sec.items || []).map(item => {
                const color = colorMap[item.color] || 'food';
                return `<div class="encoding-card ${color}">
  <span class="e-icon">${item.icon || '📦'}</span>
  <div class="e-title">${esc(item.label)}</div>
  <div class="e-desc">${esc(item.desc || '').replace(/\n/g, '<br>')}</div>
</div>`;
            }).join('');
            html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🎯'}</span> ${esc(sec.title || '知识卡片')}</div>
  <div class="encoding-grid">${itemsHtml}</div>
</div>`;
        } else if (sec.type === 'idcard') {
            const segs = sec.segments || [];
            const segsHtml = segs.map((s, i) =>
                `<div class="id-segment n${i+1}"><div>${esc(s.value)}</div><span class="id-segment-label">${esc(s.label)}</span></div>`
            ).join('');
            const legendHtml = segs.map((s, i) =>
                `<div class="legend-item"><div class="legend-dot" style="background:${s.color}"></div><div><div class="legend-text">${esc(s.label)}</div><div class="legend-desc">${esc(s.desc || '')}</div></div></div>`
            ).join('');
            html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🪪'}</span> ${esc(sec.title || '身份证号码结构')}</div>
  <div class="id-visual">
    <div class="id-visual-title">${esc(sec.subtitle || '')}</div>
    <div class="id-number-display">${segsHtml}</div>
    <div class="id-legend">${legendHtml}</div>
  </div>
</div>`;
        } else if (sec.type === 'analyzer') {
            html += `<div class="card">
  <div class="card-title"><span class="icon">🔍</span> 身份证号码解析器（试试看！）</div>
  <div class="id-analyzer">
    <div class="analyzer-title">🔍 身份证号码解析器（试试看！）</div>
    <div class="id-input-row">
      <input type="text" class="id-input" id="idInput" placeholder="输入18位身份证号" maxlength="18">
      <button class="analyze-btn" onclick="analyzeId()">解析！</button>
    </div>
    <div class="id-error" id="idError">请输入正确的18位身份证号码！</div>
    <div class="id-result" id="idResult">
      <div class="result-row"><div class="result-badge">地址码</div><div><div class="result-value" id="resAddr"></div><div class="result-note" id="resAddrNote"></div></div></div>
      <div class="result-row"><div class="result-badge">出生日期</div><div><div class="result-value" id="resBirth"></div><div class="result-note" id="resBirthNote"></div></div></div>
      <div class="result-row"><div class="result-badge">顺序码</div><div><div class="result-value" id="resSeq"></div><div class="result-note" id="resSeqNote"></div></div></div>
      <div class="result-row"><div class="result-badge">校验码</div><div><div class="result-value" id="resCheck"></div><div class="result-note" id="resCheckNote"></div></div></div>
    </div>
  </div>
</div>`;
        } else if (sec.type === 'rules') {
            const rulesHtml = (sec.items || []).map((r, i) =>
                `<div class="rule-card">
  <div class="rule-num">0${i+1}</div>
  <h4>${esc(r.title)}</h4>
  <p>${esc(r.desc || '')}</p>
  <div class="emoji">${r.emoji || '📌'}</div>
</div>`
            ).join('');
            html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🎓'}</span> ${esc(sec.title || '学号编码规则')}</div>
  <div class="rule-cards">${rulesHtml}</div>
</div>`;
        }
    }
    return html;
}

/**
 * 获取默认JS脚本（含身份证解析器）
 */
function getDefaultJS() {
    return `
let dragScore = 0;
let quizScore = 0;

function switchTab(tabId, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.main-content').forEach(p => p.classList.remove('active'));
    const el = document.getElementById(tabId);
    if (el) el.classList.add('active');
    if (btn) btn.classList.add('active');
}

// 身份证解析器
function analyzeId() {
    const val = document.getElementById('idInput').value.trim().toUpperCase();
    const result = document.getElementById('idResult');
    const error = document.getElementById('idError');
    error.style.display = 'none';
    result.classList.remove('show');
    if (val.length !== 18 || !/^\\d{17}[\\dXx]$/.test(val)) {
        error.style.display = 'block';
        return;
    }
    const addr = val.substring(0, 6);
    const birth = val.substring(6, 14);
    const seq = val.substring(14, 17);
    const check = val.substring(17, 18);
    const gender = parseInt(seq) % 2 === 1 ? '男' : '女';
    let birthStr = birth;
    if (/^\\d{8}$/.test(birth)) {
        birthStr = birth.substring(0,4) + '年' + birth.substring(4,6) + '月' + birth.substring(6,8) + '日';
    }
    document.getElementById('resAddr').textContent = addr;
    document.getElementById('resAddrNote').textContent = '省市县区代码';
    document.getElementById('resBirth').textContent = birthStr;
    document.getElementById('resBirthNote').textContent = '出生日期';
    document.getElementById('resSeq').textContent = seq + '（' + gender + '）';
    document.getElementById('resSeqNote').textContent = '顺序码，第17位' + (gender === '男' ? '奇数' : '偶数') + '=' + gender;
    document.getElementById('resCheck').textContent = check;
    document.getElementById('resCheckNote').textContent = check === 'X' ? 'X 代表10，校验用' : '数字0-9，校验用';
    result.classList.add('show');
}

document.addEventListener('DOMContentLoaded', function() {
    var idInput = document.getElementById('idInput');
    if (idInput) idInput.addEventListener('keypress', function(e) { if (e.key === 'Enter') analyzeId(); });
});

// 拖拽功能
const chips = document.querySelectorAll('.drag-chip');
const pools = document.querySelectorAll('.drag-pool');
chips.forEach(chip => {
    chip.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', this.dataset.category + '|' + this.dataset.id);
        this.style.opacity = '0.5';
    });
    chip.addEventListener('dragend', function() { this.style.opacity = '1'; });
});
pools.forEach(pool => {
    pool.addEventListener('dragover', function(e) { e.preventDefault(); this.classList.add('over'); });
    pool.addEventListener('dragleave', function() { this.classList.remove('over'); });
    pool.addEventListener('drop', function(e) {
        e.preventDefault();
        this.classList.remove('over');
        const data = e.dataTransfer.getData('text/plain').split('|');
        if (this.dataset.category === data[0]) {
            const chip = document.querySelector('.drag-chip[data-id="' + data[1] + '"]');
            if (chip && chip.style.display !== 'none') {
                chip.classList.add('placed');
                chip.setAttribute('draggable', 'false');
                chip.style.display = 'none';
                const div = document.createElement('div');
                div.className = 'drag-chip placed';
                div.textContent = chip.textContent;
                this.querySelector('.dropped-items').appendChild(div);
                dragScore++;
                const el = document.getElementById('dragScore');
                if (el) el.textContent = dragScore;
                if (dragScore >= 8) {
                    const cb = document.getElementById('dragComplete');
                    if (cb) cb.classList.add('show');
                }
            }
        }
    });
});

// 选择题判分
function checkAnswer(el, selected, correct, cardIndex) {
    const card = el.closest('.quiz-card');
    if (card.dataset.answered) return;
    card.dataset.answered = 'true';
    card.querySelectorAll('.quiz-opt').forEach(opt => { opt.style.pointerEvents = 'none'; });
    const fb = card.querySelector('.quiz-feedback');
    fb.className = 'quiz-feedback show';
    if (selected === correct) {
        el.classList.add('correct');
        fb.textContent = '🎉 回答正确！你真棒！';
        fb.classList.add('correct');
        quizScore++;
        const el2 = document.getElementById('quizScore');
        if (el2) el2.textContent = quizScore;
        if (quizScore >= 4) {
            const cb = document.getElementById('quizComplete');
            if (cb) setTimeout(() => cb.classList.add('show'), 500);
        }
    } else {
        el.classList.add('wrong');
        const opts = card.querySelectorAll('.quiz-opt');
        opts[correct].classList.add('correct');
        fb.textContent = '❌ 回答错误，正确答案是：' + opts[correct].textContent.replace(/^[A-D]\\s*/, '');
        fb.classList.add('wrong');
    }
}
`;
}

// ========== 旧版兼容函数 ==========
function dragChip(text, category, id) {
    return `<div class="drag-chip" draggable="true" data-category="${esc(category)}" data-id="${id}">${esc(text)}</div>`;
}

function dropZone(category, title) {
    return `<div class="drag-pool" data-category="${esc(category)}"><div class="drag-pool-title">${esc(title)}</div><div class="dropped-items"></div></div>`;
}

function quizCard(question, options, answerIdx, cardIndex) {
    const opts = (options || []).map((opt, oi) =>
        `<div class="quiz-opt" onclick="checkAnswer(this, ${oi}, ${answerIdx}, ${cardIndex})"><span class="opt-letter">${String.fromCharCode(65+oi)}</span>${esc(opt)}</div>`
    ).join('\n        ');
    return `<div class="quiz-card" data-answer="${answerIdx}">
        <div class="quiz-q">${cardIndex + 1}. ${esc(question)}</div>
        <div class="quiz-opts">${opts}</div>
        <div class="quiz-feedback"></div>
    </div>`;
}

function knowledgeCard(title, content) {
    return `<div class="card"><div class="card-title">${esc(title)}</div><div class="card-content">${esc(content || '').replace(/\n/g, '<br>')}</div></div>`;
}

function statsBar(correctId, totalId) {
    return `<div class="stats-bar"><span>得分：<span class="score"><span id="${correctId}">0</span> / <span id="${totalId}">0</span></span></span><button class="btn" onclick="location.reload()">重置</button></div>`;
}

function assembleHTML(title, tabs, contentHtml, scriptContent) {
    return assembleHTMLRich(title, tabs, contentHtml, scriptContent);
}

module.exports = {
    esc, dragChip, dropZone, quizCard, knowledgeCard, statsBar,
    assembleHTML, assembleHTMLRich, getCSS, getDefaultJS, richKnowledgeCard
};
