/**
 * 信息科技备课助手 - PPT生成工具 v2 (Node.js版)
 * 参考 CSP课件制作技能 设计规范（小学游戏化版）
 *
 * 核心改进：
 * 1. 字体：中文用 Microsoft YaHei，代码用 Consolas
 * 2. 装饰：圆角卡片、emoji、星星、彩条
 * 3. 配色：浅色/深色配对，关键词高亮
 * 4. 布局：全宽彩条标题栏 + 卡片式内容
 *
 * 用法:
 *   node generate_ppt.js <config.json> <output.pptx>
 *   或直接 require 并调用
 */
const PptxGenJS = require('pptxgenjs');
const fs = require('fs');
const path = require('path');

// ─── 主题色（小学游戏化风格）────────────────────────────
const C = {
    // 基础色
    BG:         'FFFBF0',   // 暖白底（小学版主背景）
    BG_BLUE:    'EFF6FF',   // 浅蓝底
    BG_PURPLE:  'F5F3FF',   // 浅紫底
    BG_GREEN:   'F0FDF4',   // 浅绿底
    BG_ORANGE:  'FFF7ED',   // 浅橙底
    BG_YELLOW:  'FFFBEB',   // 浅黄底
    DEEP:       '1A1A2E',   // 深蓝黑（封面/深色页背景）
    DARK:       '1E293B',   // 深灰蓝（正文深色）
    GRAY:       '64748B',   // 灰色
    GRAY2:      '94A3B8',   // 浅灰
    WHITE:      'FFFFFF',
    // 主题色
    PURPLE:     '7C3AED',
    PURPLE_L:   'DDD6FE',
    BLUE:       '2563EB',
    BLUE_L:     'DBEAFE',
    TEAL:       '0891B2',
    TEAL_L:     'CFFAFE',
    GREEN:      '059669',
    GREEN_L:    'D1FAE5',
    ORANGE:     'EA580C',
    ORANGE_L:   'FED7AA',
    PINK:       'DB2777',
    PINK_L:     'FBCFE8',
    YELLOW:     'D97706',
    YELLOW_L:   'FEF3C7',
    RED:        'DC2626',
    RED_L:      'FEE2E2',
    // 代码色
    CODBG:      'F3E8FF',   // 浅紫代码背景（避免深色渲染问题）
    CODTEXT:    '4C1D95',   // 深紫代码文字
    CODKW:      'DB2777',   // 关键字粉
    CODTY:      'D97706',   // 类型黄
    CODFN:      '0891B2',   // 函数青
    CODCM:      '6EE7B7',   // 注释绿
};

// 颜色名 → hex 映射（用于兼容用户传入的字符串颜色名）
const COLOR_NAMES = {
    PURPLE: C.PURPLE, BLUE: C.BLUE, TEAL: C.TEAL, GREEN: C.GREEN,
    ORANGE: C.ORANGE, PINK: C.PINK, YELLOW: C.YELLOW, RED: C.RED,
    GRAY: C.GRAY, DARK: C.DARK, WHITE: C.WHITE,
};
function resolveColor(name) {
    if (!name || typeof name !== 'string') return C.BLUE;
    return COLOR_NAMES[name.toUpperCase()] || name;
}

// 浅色路由：深色 → 浅色配对
const LIGHT_OF = {
    [C.PURPLE]: C.PURPLE_L, [C.BLUE]: C.BLUE_L,
    [C.TEAL]: C.TEAL_L,    [C.GREEN]: C.GREEN_L,
    [C.ORANGE]: C.ORANGE_L, [C.PINK]: C.PINK_L,
    [C.YELLOW]: C.YELLOW_L, [C.RED]: C.RED_L,
};
function lightOf(color) {
    const hex = resolveColor(color);
    return LIGHT_OF[hex] || hex;
}

// ─── 工具函数 ─────────────────────────────────────────

/**
 * 中文字符宽度估算
 * 中文字符约等于 1.5 个英文字符宽度
 * 返回值单位：英寸
 */
function cnW(text, fontSize) {
    const cn = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
    const en = text.length - cn;
    const pt = fontSize / 2;
    return (cn * 1.5 + en * 0.6) * pt / 72 + 0.15;
}

/**
 * 智能文本框 — 自动给 w 加足够余量，防止中文换行
 */
function txt(slide, text, x, y, w, h, opts) {
    const fs = opts && opts.fontSize ? opts.fontSize : 14;
    const actualW = cnW(String(text), fs);
    const finalW = Math.max(w, actualW + 0.1);
    // 合并字体默认值：中文用 Microsoft YaHei
    const finalOpts = {
        fontFace: 'Microsoft YaHei',
        ...opts,
        w: finalW,
    };
    slide.addText(text, { x, y, h, ...finalOpts });
}

/**
 * 纯文本（不自动调整宽度，用于已有足够宽度的场景）
 */
function txtRaw(slide, text, x, y, w, h, opts) {
    const finalOpts = { fontFace: 'Microsoft YaHei', ...opts };
    if (finalOpts.color) {
        finalOpts.color = resolveColor(finalOpts.color);
    }
    slide.addText(text, { x, y, w, h, ...finalOpts });
}

/**
 * 圆角矩形（填充）
 */
function rr(slide, x, y, w, h, color, radius = 0.15) {
    const col = resolveColor(color);
    slide.addShape(_pres.shapes.ROUNDED_RECTANGLE, {
        x, y, w, h, rectRadius: radius,
        fill: { color: col }, line: { color: col }
    });
}

/**
 * 圆角矩形（带边框）
 */
function rrBorder(slide, x, y, w, h, fillColor, borderColor, bw = 2, radius = 0.15) {
    const fCol = resolveColor(fillColor);
    const bCol = resolveColor(borderColor);
    slide.addShape(_pres.shapes.ROUNDED_RECTANGLE, {
        x, y, w, h, rectRadius: radius,
        fill: { color: fCol },
        line: { color: bCol, width: bw }
    });
}

/**
 * 椭圆形
 */
let _pres = null;  // 全局引用，供工具函数使用
function oval(slide, x, y, w, h, color) {
    const col = resolveColor(color);
    slide.addShape(_pres.shapes.OVAL, {
        x, y, w, h,
        fill: { color: col }, line: { color: col }
    });
}

/**
 * 矩形
 */
function rect(slide, x, y, w, h, color) {
    const col = resolveColor(color);
    slide.addShape(_pres.shapes.RECTANGLE, {
        x, y, w, h,
        fill: { color: col }, line: { color: col }
    });
}

/**
 * 代码块高度计算
 */
function calcCodeH(tokens, fs, availW) {
    fs = fs || 13;
    const text = tokens.map(t => (typeof t === 'string' ? t : (t.text || ''))).join('');
    const lines = text.split('\n').length;
    const lineH = fs * 1.25 / 72;
    return Math.max(lines * lineH + 0.50, 0.52);
}

/**
 * 代码块（小学版：浅紫底 + 深紫字 + 交通灯圆点）
 * tokens: 字符串数组或 pptxgen TextProps[]
 */
function codeBlock(slide, x, y, w, tokens, fs) {
    const h = calcCodeH(tokens, fs || 13, w - 0.3);
    // 圆角边框容器
    rrBorder(slide, x, y, w, h, C.CODBG, C.PURPLE, 1.5, 0.18);
    // 交通灯红黄绿三圆点
    [C.RED, C.YELLOW, C.GREEN].forEach((c, i) =>
        oval(slide, x + 0.18 + i * 0.26, y + 0.12, 0.15, 0.15, c)
    );
    // 代码文本
    const codeOpts = Array.isArray(tokens) && tokens[0] && typeof tokens[0] === 'object'
        ? tokens
        : [{ text: Array.isArray(tokens) ? tokens.join('') : String(tokens), options: { color: C.CODTEXT } }];
    slide.addText(codeOpts, {
        x: x + 0.15, y: y + 0.36, w: w - 0.3, h: h - 0.48,
        fontSize: fs || 13, fontFace: 'Consolas',
        color: C.CODTEXT
    });
    return h;
}

/**
 * 关键词高亮文本数组（用于代码展示页）
 */
function kwt(text, color) {
    return { text, options: { color, bold: color === C.CODKW || color === C.CODTY } };
}

/**
 * 生成PPT核心类
 *
 * config结构:
 * {
 *   topic: '课题名',
 *   grade: '四年级下册',
 *   unit: '第二单元第2课',
 *   duration: '1课时（40分钟）',
 *   objectives: [['标题','内容','颜色'], ...],
 *   intro: '情境导入文字',
 *   sections: [{title, content, points: [], icon: '💡'}, ...],
 *   activity: {title, materials: [], steps: []},
 *   summary: '方法总结',
 *   expand: ['应用1', '应用2', '应用3'],
 *   exercises: [['题型','内容','颜色'], ...],
 *   board: '板书文字',
 *   gains: [['标题','内容','颜色'], ...],
 *   homework: {required: [], optional: []}
 * }
 */
class PPTGenerator {
    constructor(config) {
        this.config = config;
        this.prs = new PptxGenJS();
        _pres = this.prs;  // 让工具函数能访问到 pres 实例
        this.prs.layout = 'LAYOUT_16x9';  // 10 x 5.625 inches
        this.W = 10;
        this.H = 5.625;
        this.PAGE_COLORS = [C.PURPLE, C.BLUE, C.TEAL, C.GREEN, C.ORANGE, C.PINK];
    }

    // ── 公共装饰函数 ────────────────────────────────────

    /** 全宽彩条标题栏 */
    titleBar(slide, title, subtitle, color) {
        const col = color || C.BLUE;
        rr(slide, 0, 0, this.W, 0.72, col, 0);
        txtRaw(slide, title, 0.4, 0, this.W - 0.8, 0.72, {
            fontSize: 22, bold: true, color: C.WHITE, valign: 'middle'
        });
        if (subtitle) {
            txtRaw(slide, subtitle, 0.4, 0, this.W - 0.8, 0.72, {
                fontSize: 11, color: 'FFFFFF', valign: 'bottom', margin: [18, 0, 0, 0]
            });
        }
    }

    /** 圆角提示条 */
    tipBar(slide, text, color) {
        const col = color || C.YELLOW;
        rrBorder(slide, 0.35, this.H - 0.36, this.W - 0.7, 0.3, lightOf(col), col, 1, 0.1);
        txtRaw(slide, '💡 ' + text, 0.55, this.H - 0.34, this.W - 1.1, 0.26, {
            fontSize: 11, color: col, bold: true, valign: 'middle'
        });
    }

    /** 数字编号圆点 */
    numBadge(slide, x, y, n, color) {
        const col = color || C.BLUE;
        rr(slide, x, y, 0.38, 0.38, col, 0.19);
        txtRaw(slide, String(n), x, y, 0.38, 0.38, {
            fontSize: 13, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
        });
    }

    // ── 第1页：封面 ──────────────────────────────────────
    _slideCover() {
        const s = this.prs.addSlide();
        s.background = { color: C.DEEP };

        // 星星装饰
        [[0.3,0.2],[1.2,0.5],[2.8,0.3],[5.5,0.4],[7.8,0.2],[8.6,0.6],
         [0.1,2.8],[0.7,4.2],[8.5,3.2],[8.2,4.5],[4.5,0.1],[6.2,5.0]].forEach(([x, y]) => {
            oval(s, x, y, 0.06, 0.06, C.WHITE);
        });

        // 彩虹拱形装饰（右侧）
        [C.PURPLE, C.BLUE, C.TEAL, C.GREEN, C.ORANGE, C.PINK].forEach((col, i) => {
            oval(s, 6.2 - i * 0.3, -0.45 - i * 0.28, 4.5 + i * 0.6, 4.5 + i * 0.6, col);
        });
        // 覆盖右侧多余部分
        rect(s, 9.5, 0, 0.5, 5.63, C.DEEP);

        const { topic, grade, unit } = this.config;

        // 顶部徽章
        rr(s, 0.3, 0.26, 2.1, 0.4, C.PURPLE, 0.2);
        txtRaw(s, '📚 信息科技', 0.3, 0.26, 2.1, 0.4, {
            fontSize: 11, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
        });

        // 主标题
        txtRaw(s, unit || '第二单元', 0.3, 0.85, 7, 0.6, {
            fontSize: 18, color: C.GRAY2
        });
        txtRaw(s, topic || '课题', 0.3, 1.45, 8, 1.2, {
            fontSize: 52, bold: true, color: C.WHITE, charSpacing: 3
        });

        // 副标题描述
        const subtitle = this.config.intro ? this.config.intro.substring(0, 40) : '探索身边的编码奥秘';
        txtRaw(s, [
            { text: '🎯 ', options: { color: C.YELLOW } },
            { text: subtitle, options: { color: C.GRAY2 } }
        ], 0.3, 2.75, 7, 0.5, { fontSize: 15 });

        // 信息卡片
        rrBorder(s, 0.3, 3.45, 3.8, 1.7, '1E1B4B', C.PURPLE, 2, 0.2);
        const cardItems = [
            { icon: '📖', label: '年级', value: grade || '四年级下册' },
            { icon: '⏱️', label: '课时', value: this.config.duration || '1课时（40分钟）' },
            { icon: '🎮', label: '主题', value: unit || '编码世界' },
        ];
        cardItems.forEach((item, i) => {
            const y = 3.55 + i * 0.5;
            rr(s, 0.48, y, 0.32, 0.32, C.PURPLE, 0.08);
            txtRaw(s, item.icon, 0.48, y, 0.32, 0.32, {
                fontSize: 13, align: 'center', valign: 'middle'
            });
            txtRaw(s, item.label + '：', 0.88, y + 0.04, 0.7, 0.24, {
                fontSize: 11, color: C.PURPLE_L
            });
            txtRaw(s, item.value, 1.58, y + 0.04, 2.3, 0.24, {
                fontSize: 11, color: C.WHITE
            });
        });

        // 右下角装饰
        rrBorder(s, 7.5, 3.3, 2.2, 1.9, '1E1B4B', C.TEAL, 1.5, 0.2);
        txtRaw(s, '🚀', 7.5, 3.38, 2.2, 0.7, {
            fontSize: 32, align: 'center', valign: 'middle'
        });
        txtRaw(s, '准备好\n探索编码世界了吗？', 7.5, 4.1, 2.2, 0.9, {
            fontSize: 10, color: C.TEAL_L, align: 'center'
        });

        // 底部条
        rr(s, 0, this.H - 0.32, this.W, 0.32, C.PURPLE, 0);
        txtRaw(s, '📚 斯帝姆创客教育中心  ·  信息科技课程  ·  游戏化趣味学习', 0, this.H - 0.32, this.W, 0.32, {
            fontSize: 10, color: 'C4B5FD', align: 'center', valign: 'middle'
        });
    }

    // ── 第2页：学习目标 ─────────────────────────────────
    _slideObjectives() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG };

        this.titleBar(s, '🎯 学习目标', '本节课的学习方向');

        const defaultObjs = [
            { title: '知识与技能', content: '了解编码的概念\n掌握身份证号、学号等编码规则', icon: '📖', color: C.BLUE },
            { title: '过程与方法', content: '通过观察分析\n发现编码的规律和特点', icon: '🔍', color: C.TEAL },
            { title: '情感与素养', content: '体会编码在生活中的价值\n培养信息科技核心素养', icon: '🌟', color: C.ORANGE },
        ];
        const objectives = this.config.objectives?.length
            ? this.config.objectives.map(([t, c, col]) => ({ title: t, content: c, icon: '📖', color: col || C.BLUE }))
            : defaultObjs;

        objectives.forEach((obj, i) => {
            const x = 0.35 + i * 3.15;
            const col = obj.color || C.PAGE_COLORS[i % 6];

            // 卡片背景
            rrBorder(s, x, 0.85, 3.0, 4.35, C.WHITE, col, 2, 0.2);

            // 顶部色条
            rr(s, x, 0.85, 3.0, 0.55, col, 0);

            // 图标+标题
            txtRaw(s, obj.icon + ' ' + obj.title, x, 0.85, 3.0, 0.55, {
                fontSize: 15, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });

            // 内容
            txtRaw(s, obj.content, x + 0.2, 1.55, 2.6, 3.4, {
                fontSize: 13, color: C.DARK, valign: 'top'
            });
        });
    }

    // ── 第3页：情境导入 ─────────────────────────────────
    _slideIntro() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG_BLUE };

        this.titleBar(s, '🌟 情境导入', '生活中的信息科技');

        // 主内容卡片
        rrBorder(s, 0.35, 0.85, this.W - 0.7, 3.9, C.WHITE, C.BLUE, 1.5, 0.2);

        const intro = this.config.intro || '在我们生活中，每个人都有一张身份证。你知道身份证上的 18 位数字分别代表什么含义吗？';
        txtRaw(s, intro, 0.6, 1.0, this.W - 1.2, 1.5, {
            fontSize: 16, color: C.DARK
        });

        // 三个问题卡片
        const questions = [
            { icon: '🪪', q: '身份证号码', tip: '18 位数字有什么规律？' },
            { icon: '🎒', q: '学生证编号', tip: '学校怎样给每个学生编号？' },
            { icon: '📦', q: '快递单号', tip: '为什么每个快递都有独一无二的号码？' },
        ];
        questions.forEach((q, i) => {
            const x = 0.55 + i * 3.05;
            rrBorder(s, x, 2.6, 2.8, 1.95, lightOf(C.BLUE), C.BLUE, 1, 0.15);
            rr(s, x + 0.9, 2.7, 1.0, 1.0, C.BLUE, 0.5);
            txtRaw(s, q.icon, x + 0.9, 2.7, 1.0, 1.0, {
                fontSize: 28, align: 'center', valign: 'middle'
            });
            txtRaw(s, q.q, x + 0.1, 3.75, 2.6, 0.38, {
                fontSize: 13, bold: true, color: C.BLUE, align: 'center'
            });
            txtRaw(s, q.tip, x + 0.1, 4.12, 2.6, 0.3, {
                fontSize: 11, color: C.GRAY, align: 'center'
            });
        });

        this.tipBar(s, '今天我们就来揭开编码的神秘面纱！');
    }

    // ── 第4-8页：新知讲解 ────────────────────────────────
    _slideSections() {
        const sections = this.config.sections || [
            {
                title: '什么是编码',
                icon: '🏷️',
                content: '编码是用数字、字母或符号，按照一定规则来表示信息的方法。',
                points: ['编码是一种信息表示方式', '每个编码都有特定的含义', '编码可以帮助我们区分不同的事物'],
            },
            {
                title: '身份证号码的秘密',
                icon: '🪪',
                content: '身份证号码是公民唯一的、终身不变的身份代码。',
                points: ['前6位：地址码（省市区）', '7-14位：出生日期码', '15-17位：顺序码', '第18位：校验码（X）'],
            },
            {
                title: '学号的编码方法',
                icon: '🎒',
                content: '学校用学号来唯一标识每个学生。',
                points: ['位数一致：所有学号长度相同', '范围确定：每个数字有固定范围', '规律易记：按入学年份、班级等编排'],
            },
        ];

        sections.slice(0, 5).forEach((sec, i) => {
            const s = this.prs.addSlide();
            s.background = { color: C.BG };
            const col = this.PAGE_COLORS[i % 6];
            const icon = sec.icon || '📖';

            this.titleBar(s, `${icon} 新知讲解 ${i + 1}：${sec.title}`, sec.title, col);

            // 内容说明卡片
            rrBorder(s, 0.35, 0.85, this.W - 0.7, 1.5, lightOf(col), col, 1.5, 0.2);
            txtRaw(s, sec.content || '', 0.6, 0.95, this.W - 1.2, 1.3, {
                fontSize: 15, color: C.DARK
            });

            // 要点列表
            (sec.points || []).slice(0, 5).forEach((point, j) => {
                const y = 2.55 + j * 0.72;
                rrBorder(s, 0.35, y, this.W - 0.7, 0.62, lightOf(col), col, 1, 0.12);
                this.numBadge(s, 0.5, y + 0.12, j + 1, col);
                txtRaw(s, point, 1.0, y + 0.14, this.W - 1.8, 0.42, {
                    fontSize: 14, color: C.DARK, valign: 'middle'
                });
            });

            this.tipBar(s, '记住这些要点，下节课会用到哦！', col);
        });
    }

    // ── 第9页：实验活动 ─────────────────────────────────
    _slideActivity() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG_GREEN };

        this.titleBar(s, '🧪 课堂活动', this.config.activity?.title || '编码小侦探', C.GREEN);

        const act = this.config.activity || {
            title: '编码小侦探',
            materials: ['白纸', '笔', '自己的学生证'],
            steps: ['观察自己的身份证号码', '将 18 位数字分组', '找出每组数字代表的含义', '小组交流分享发现'],
        };

        // 左侧：材料准备
        rrBorder(s, 0.35, 0.85, 4.4, 4.35, C.WHITE, C.GREEN, 1.5, 0.2);
        txtRaw(s, '📋 实验准备', 0.55, 0.95, 4.0, 0.4, {
            fontSize: 15, bold: true, color: C.GREEN
        });
        (act.materials || []).forEach((m, i) => {
            rrBorder(s, 0.55, 1.45 + i * 0.58, 4.0, 0.5, lightOf(C.GREEN), C.GREEN, 0.8, 0.1);
            txtRaw(s, '✅ ' + m, 0.75, 1.5 + i * 0.58, 3.6, 0.4, {
                fontSize: 13, color: C.DARK, valign: 'middle'
            });
        });

        // 右侧：实验步骤
        rrBorder(s, 5.0, 0.85, 4.65, 4.35, C.WHITE, C.TEAL, 1.5, 0.2);
        txtRaw(s, '🔢 实验步骤', 5.2, 0.95, 4.2, 0.4, {
            fontSize: 15, bold: true, color: C.TEAL
        });
        (act.steps || []).forEach((step, i) => {
            const y = 1.45 + i * 0.82;
            rr(s, 5.2, y, 0.5, 0.5, C.TEAL, 0.25);
            txtRaw(s, String(i + 1), 5.2, y, 0.5, 0.5, {
                fontSize: 16, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });
            txtRaw(s, step, 5.82, y + 0.05, 3.6, 0.7, {
                fontSize: 13, color: C.DARK, valign: 'middle'
            });
        });
    }

    // ── 第10页：方法总结 ────────────────────────────────
    _slideSummary() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG_PURPLE };

        this.titleBar(s, '🧠 方法总结', '本节知识框架', C.PURPLE);

        rrBorder(s, 0.35, 0.85, this.W - 0.7, 4.35, C.WHITE, C.PURPLE, 1.5, 0.2);

        const summary = this.config.summary || '通过本节课学习，我们了解到编码是用数字或符号，按照一定规则来表示信息的方法。不同的编码有不同的规则，但都遵循"位数一致、规则明确、便于管理"的原则。';
        txtRaw(s, summary, 0.6, 1.0, this.W - 1.2, 1.2, {
            fontSize: 15, color: C.DARK
        });

        // 总结要点
        const points = [
            { icon: '🏷️', text: '编码是用符号表示信息的方法', color: C.BLUE },
            { icon: '🪪', text: '身份证号 = 地址码 + 出生日期 + 顺序码 + 校验码', color: C.TEAL },
            { icon: '🎒', text: '学号设计要遵循：位数一致、范围确定、规律易记', color: C.GREEN },
            { icon: '🌐', text: '生活中处处有编码，方便了信息的传递与管理', color: C.ORANGE },
        ];
        points.forEach((p, i) => {
            const y = 2.3 + i * 0.68;
            rrBorder(s, 0.55, y, this.W - 1.1, 0.58, lightOf(p.color), p.color, 1, 0.1);
            rr(s, 0.7, y + 0.1, 0.38, 0.38, p.color, 0.08);
            txtRaw(s, p.icon, 0.7, y + 0.1, 0.38, 0.38, {
                fontSize: 14, align: 'center', valign: 'middle'
            });
            txtRaw(s, p.text, 1.2, y + 0.1, this.W - 2.0, 0.38, {
                fontSize: 13, color: C.DARK, valign: 'middle'
            });
        });
    }

    // ── 第11页：拓展应用 ────────────────────────────────
    _slideExpand() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG };

        this.titleBar(s, '🌈 拓展应用', '生活中的编码', C.ORANGE);

        const expands = this.config.expand?.length
            ? this.config.expand
            : ['📦 快递单号', '🎫 电影票码', '🏷️ 商品条形码', '🎫 车牌号码', '📱 手机号码', '🏠 门牌号码'];

        // 默认图标映射（用于没有emoji的条目）
        const defaultIcons = ['📚', '🏷️', '🚗', '📦', '🎫', '🏠'];

        expands.slice(0, 6).forEach((app, i) => {
            const col = this.PAGE_COLORS[i % 6];
            const x = 0.35 + (i % 3) * 3.15;
            const y = 0.9 + Math.floor(i / 3) * 2.2;

            // 尝试分离 emoji 图标和说明文字
            const emojiMatch = app.match(/^([\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\s]+)\s*(.*)$/u);
            let iconPart, labelPart;

            if (emojiMatch && emojiMatch[1]) {
                // 有emoji格式：emoji + 空格 + 文字
                iconPart = emojiMatch[1].trim();
                labelPart = emojiMatch[2] || '';
            } else {
                // 无emoji格式：使用默认图标，只显示说明文字
                iconPart = defaultIcons[i % defaultIcons.length];
                labelPart = app;
            }

            rrBorder(s, x, y, 3.0, 2.0, C.WHITE, col, 2, 0.2);

            // 顶栏：图标 + 标题
            rr(s, x, y, 3.0, 0.55, col, 0);
            txtRaw(s, iconPart + (labelPart ? ' ' + labelPart : ''), x + 0.1, y + 0.02, 2.8, 0.5, {
                fontSize: 14, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });

            // 图标大圆（只放emoji）
            rr(s, x + 1.05, y + 0.7, 0.9, 0.9, lightOf(col), 0.45);
            txtRaw(s, iconPart, x + 1.05, y + 0.7, 0.9, 0.9, {
                fontSize: 24, align: 'center', valign: 'middle'
            });

            // 说明文字（紧贴图标圆下方）
            if (labelPart) {
                txtRaw(s, labelPart, x + 0.1, y + 1.65, 2.8, 0.28, {
                    fontSize: 12, bold: true, color: col, align: 'center'
                });
            }
        });
    }

    // ── 第12页：课堂练习 ────────────────────────────────
    _slideExercise() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG_YELLOW };

        this.titleBar(s, '📝 课堂练习', '检验学习效果', C.YELLOW);

        const defaultExercises = [
            { qtype: '选择题', content: '身份证号码中，第 7-14 位表示的是？\nA. 地址码  B. 出生日期码  C. 顺序码  D. 校验码', color: C.BLUE },
            { qtype: '判断题', content: '判断正误：\n学号中可以出现两位完全相同的学号。\n（  ）', color: C.GREEN },
            { qtype: '应用题', content: '想一想：\n如果你要为自己设计一个班级编码，需要考虑哪些因素？', color: C.PINK },
        ];
        const exercises = this.config.exercises?.length
            ? this.config.exercises.map(([t, c, col]) => ({ qtype: t, content: c, color: col || C.BLUE }))
            : defaultExercises;

        exercises.forEach((ex, i) => {
            const y = 0.85 + i * 1.52;
            const col = ex.color || C.PAGE_COLORS[i % 6];

            rrBorder(s, 0.35, y, 9.3, 1.4, C.WHITE, col, 1.5, 0.15);
            rr(s, 0.35, y, 1.2, 1.4, col, 0);
            txtRaw(s, ex.qtype, 0.35, y, 1.2, 1.4, {
                fontSize: 13, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });
            txtRaw(s, ex.content, 1.65, y + 0.1, 7.8, 1.2, {
                fontSize: 13, color: C.DARK, valign: 'middle'
            });
        });
    }

    // ── 第13页：板书设计 ────────────────────────────────
    _slideBoard() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG };

        this.titleBar(s, '📋 板书设计', '本节课知识框架', C.TEAL);

        rrBorder(s, 0.35, 0.85, this.W - 0.7, 4.35, C.WHITE, C.TEAL, 1.5, 0.2);

        // 中心主题
        rr(s, 3.7, 1.0, 2.6, 0.65, C.DEEP, 0.15);
        txtRaw(s, this.config.topic || '生活中的常见编码', 3.7, 1.0, 2.6, 0.65, {
            fontSize: 13, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
        });

        // 分支卡片
        const branches = [
            { icon: '🏷️', text: '什么是编码', x: 0.6, y: 2.0, color: C.BLUE },
            { icon: '🪪', text: '身份证号\n18位编码', x: 3.6, y: 2.0, color: C.PURPLE },
            { icon: '🎒', text: '学号设计\n原则', x: 6.6, y: 2.0, color: C.GREEN },
            { icon: '🌐', text: '生活应用', x: 1.0, y: 3.6, color: C.ORANGE },
            { icon: '💡', text: '方法总结', x: 5.2, y: 3.6, color: C.TEAL },
        ];
        branches.forEach(b => {
            rrBorder(s, b.x, b.y, 2.7, 0.95, lightOf(b.color), b.color, 1.5, 0.15);
            rr(s, b.x, b.y, 0.5, 0.95, b.color, 0);
            txtRaw(s, b.icon, b.x, b.y, 0.5, 0.95, {
                fontSize: 16, align: 'center', valign: 'middle'
            });
            txtRaw(s, b.text, b.x + 0.55, b.y + 0.18, 2.0, 0.6, {
                fontSize: 12, bold: true, color: b.color
            });
        });
    }

    // ── 第14页：课堂小结 ────────────────────────────────
    _slideSummaryFinal() {
        const s = this.prs.addSlide();
        s.background = { color: C.DEEP };

        // 顶部彩条
        [C.PURPLE, C.BLUE, C.TEAL, C.GREEN, C.ORANGE, C.PINK].forEach((col, i) => {
            rect(s, i * (this.W / 6), 0, this.W / 6 + 0.01, 0.1, col);
        });

        txtRaw(s, '🌟 课堂小结', 0, 0.15, this.W, 0.6, {
            fontSize: 24, bold: true, color: C.WHITE, align: 'center'
        });

        const defaultGains = [
            { title: '什么是编码', content: '用数字/符号表示信息的方法', icon: '🏷️', color: C.BLUE },
            { title: '身份证号结构', content: '地址+日期+顺序+校验码', icon: '🪪', color: C.PURPLE },
            { title: '学号设计原则', content: '位数一致、范围确定、规律易记', icon: '🎒', color: C.GREEN },
            { title: '生活中的编码', content: '快递单号、商品条码、车牌号等', icon: '🌐', color: C.ORANGE },
        ];
        const gains = this.config.gains?.length
            ? this.config.gains.map(([t, c, col]) => ({ title: t, content: c, icon: '✅', color: col || C.BLUE }))
            : defaultGains;

        gains.forEach((g, i) => {
            const x = 0.35 + (i % 2) * 4.75;
            const y = 0.88 + Math.floor(i / 2) * 2.2;
            const col = g.color || C.PAGE_COLORS[i % 6];

            rrBorder(s, x, y, 4.55, 2.0, '0F172A', col, 2, 0.2);
            rr(s, x, y, 4.55, 0.55, col, 0);
            txtRaw(s, g.icon + ' ' + g.title, x, y, 4.55, 0.55, {
                fontSize: 14, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });
            txtRaw(s, g.content, x + 0.2, y + 0.65, 4.15, 1.15, {
                fontSize: 13, color: col
            });

            // 已掌握勾
            rr(s, x + 1.5, y + 1.62, 1.55, 0.28, col, 0.1);
            txtRaw(s, '✓ 已掌握', x + 1.5, y + 1.62, 1.55, 0.28, {
                fontSize: 10, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
            });
        });
    }

    // ── 第15页：作业布置 ────────────────────────────────
    _slideHomework() {
        const s = this.prs.addSlide();
        s.background = { color: C.BG_ORANGE };

        this.titleBar(s, '📚 作业布置', '课后任务', C.ORANGE);

        const hw = this.config.homework || {
            required: ['整理本节课笔记，完成练习册第X页', '用自己的话说一说身份证号码的含义'],
            optional: ['调查：找一找生活中还有哪些编码？', '挑战：试着为学校设计一个新生学号编码规则'],
        };

        // 必做题
        rrBorder(s, 0.35, 0.85, 4.5, 4.35, C.WHITE, C.BLUE, 1.5, 0.2);
        rr(s, 0.35, 0.85, 0.72, 0.5, C.BLUE, 0);
        txtRaw(s, '📖 必做', 0.35, 0.85, 0.72, 0.5, {
            fontSize: 12, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
        });
        txtRaw(s, '基础任务', 1.2, 0.92, 3.4, 0.38, {
            fontSize: 15, bold: true, color: C.BLUE
        });
        (hw.required || []).forEach((task, i) => {
            const y = 1.5 + i * 0.9;
            rrBorder(s, 0.55, y, 4.1, 0.78, lightOf(C.BLUE), C.BLUE, 0.8, 0.1);
            txtRaw(s, `[ ] ${task}`, 0.75, y + 0.1, 3.7, 0.58, {
                fontSize: 12, color: C.DARK, valign: 'middle'
            });
        });

        // 选做题
        rrBorder(s, 5.15, 0.85, 4.5, 4.35, C.WHITE, C.ORANGE, 1.5, 0.2);
        rr(s, 5.15, 0.85, 0.72, 0.5, C.ORANGE, 0);
        txtRaw(s, '⭐ 选做', 5.15, 0.85, 0.72, 0.5, {
            fontSize: 12, bold: true, color: C.WHITE, align: 'center', valign: 'middle'
        });
        txtRaw(s, '挑战任务', 6.0, 0.92, 3.4, 0.38, {
            fontSize: 15, bold: true, color: C.ORANGE
        });
        (hw.optional || []).forEach((task, i) => {
            const y = 1.5 + i * 0.9;
            rrBorder(s, 5.35, y, 4.1, 0.78, lightOf(C.ORANGE), C.ORANGE, 0.8, 0.1);
            txtRaw(s, `[ ] ${task}`, 5.55, y + 0.1, 3.7, 0.58, {
                fontSize: 12, color: C.DARK, valign: 'middle'
            });
        });
    }

    // ── 主生成方法 ─────────────────────────────────────
    generate(outputPath) {
        this._slideCover();
        this._slideObjectives();
        this._slideIntro();
        this._slideSections();
        this._slideActivity();
        this._slideSummary();
        this._slideExpand();
        this._slideExercise();
        this._slideBoard();
        this._slideSummaryFinal();
        this._slideHomework();

        this.prs.writeFile({ fileName: outputPath })
            .then(() => console.log(`✅ PPT已生成: ${outputPath}`))
            .catch(err => console.error('❌ 生成失败:', err));
        return outputPath;
    }

    async generateAsync(outputPath) {
        this._slideCover();
        this._slideObjectives();
        this._slideIntro();
        this._slideSections();
        this._slideActivity();
        this._slideSummary();
        this._slideExpand();
        this._slideExercise();
        this._slideBoard();
        this._slideSummaryFinal();
        this._slideHomework();
        await this.prs.writeFile({ fileName: outputPath });
        return outputPath;
    }
}

// 主入口
if (require.main === module) {
    const args = process.argv.slice(2);
    let config, output;

    if (args.length >= 2) {
        config = JSON.parse(fs.readFileSync(args[0], 'utf-8'));
        output = args[1];
    } else {
        config = {
            topic: '生活中的常见编码',
            grade: '四年级下册',
            unit: '第二单元第2课',
            activity: { title: '编码小侦探', materials: [], steps: [] },
            objectives: [],
            intro: '在我们生活中，每个人都有一张身份证。你知道身份证上的 18 位数字分别代表什么含义吗？',
            sections: [{ title: '什么是编码', content: '编码是用数字、字母或符号，按照一定规则来表示信息的方法。', points: [], icon: '🏷️' }],
            summary: '',
            expand: [],
            exercises: [],
            board: '',
            gains: [],
            homework: {},
        };
        output = path.join(__dirname, 'test_output.pptx');
    }

    const gen = new PPTGenerator(config);
    gen.generate(output);
}

module.exports = { PPTGenerator, generatePPT: (config, outputPath) => new PPTGenerator(config).generate(outputPath) };
