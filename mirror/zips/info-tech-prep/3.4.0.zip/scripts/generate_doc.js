/**
 * 信息科技备课助手 - Word文档生成入口 (Node.js版)
 * 
 * 用法:
 *   node generate_doc.js <config.json> <output.docx>
 *   或直接 require 并调用
 */
const { generateTaskSheet, generateTeachingPlan } = require('./doc_builder.js');
const fs = require('fs');
const path = require('path');

async function main() {
    const args = process.argv.slice(2);
    let info, output;

    if (args.length >= 2) {
        info = JSON.parse(fs.readFileSync(args[0], 'utf-8'));
        output = args[1];
    } else {
        // 测试模式
        info = {
            title: '推荐算法的妙用',
            grade: '五年级下册',
            objectives: [
                '能说出推荐算法的基本概念',
                '能分析推荐算法在生活中的应用',
                '体验算法对生活的影响',
            ],
            preview: [
                ['思考探索', '你平时在网上购物时，网站是如何给你推荐商品的？'],
                ['预习填空', '推荐算法是___'],
            ],
            explore: [
                ['活动一：体验推荐', '打开购物网站，体验推荐功能\n1. 观察推荐商品\n2. 分析推荐依据', ['编号', '推荐商品', '我的分析'], 4],
            ],
            knowledge: [
                '推荐算法的定义：___是指根据用户的___，为其推荐可能感兴趣的内容',
                '推荐算法的应用场景：___、___、___',
            ],
            exercises: [
                ['选择题', '下列哪个不是推荐算法的应用？', ['A. 抖音视频推荐', 'B. 淘宝商品推荐', 'C. 搜索引擎', 'D. 音乐App']],
                ['判断题', '（  ）推荐算法一定会推荐用户喜欢的内容', null],
                ['应用题', '请举例说明生活中还有哪些地方用到了推荐算法', null],
            ],
            extension: '和家长讨论：推荐算法对我们的生活有哪些影响？',
        };
        output = path.join(__dirname, 'test_task_sheet.docx');
    }

    await generateTaskSheet(info, output);
}

if (require.main === module) {
    main().catch(err => console.error('生成失败:', err));
}

module.exports = { generateTaskSheet, generateTeachingPlan };
