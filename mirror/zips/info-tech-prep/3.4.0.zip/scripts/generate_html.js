/**
 * 信息科技备课助手 - 互动HTML工具生成器 v3.5.0
 * 支持 knowledge_sections 配置结构（hero/grid/idcard/analyzer/rules）
 * 用法: node generate_html.js <config.json> <output.html>
 *       或直接 require 并调用
 */
const fs   = require('fs');
const path = require('path');
const {
  esc, assembleHTMLRich, getCSS, richKnowledgeCard, getDefaultJS
} = require('./html_builder.js');

class HTMLGenerator {
  constructor(config = {}) {
    this.config = config;
  }

  /**
   * 生成互动 HTML 文件
   * @param {string} outputPath 输出 HTML 文件路径
   */
  generate(outputPath) {
    const cfg = this.config;
    const topic   = cfg.topic || '互动学习工具';
    const tabs    = this._buildTabs();
    const content  = this._buildContent();
    const js      = this._buildJS();

    const html = assembleHTMLRich(topic, tabs, content, js);
    fs.writeFileSync(outputPath, html, 'utf-8');
    console.log('✅ HTML 已生成：' + outputPath);
  }

  /* ---------- 标签栏 ---------- */
  _buildTabs() {
    const cfg = this.config;
    const tabs = [];
    if (cfg.knowledge_sections || cfg.knowledge_title) {
      tabs.push({ id: 'tab-knowledge', label: cfg.knowledge_tab || '📖 知识学习' });
    }
    if (cfg.drag_items && cfg.categories) {
      tabs.push({ id: 'tab-drag',     label: cfg.drag_tab || '🧩 拖拽分类' });
    }
    if (cfg.quiz && cfg.quiz.length) {
      tabs.push({ id: 'tab-quiz',     label: cfg.quiz_tab || '✏️ 随堂测验' });
    }
    // 默认至少一个
    if (!tabs.length) {
      tabs.push({ id: 'tab-knowledge', label: '📖 知识学习' });
    }
    return tabs;
  }

  /* ---------- 内容区 ---------- */
  _buildContent() {
    const cfg = this.config;
    const content = {};

    /* ---- 知识学习 ---- */
    const knowledgeId = 'tab-knowledge';
    if (cfg.knowledge_sections && cfg.knowledge_sections.length) {
      // v3.5.0 新结构：支持 hero / realItems / idcard / analyzer / rules
      content[knowledgeId] = this._renderKnowledgeSections();
    } else if (cfg.knowledge_title || cfg.knowledge_content) {
      // 旧结构兼容
      content[knowledgeId] = this._renderLegacyKnowledge();
    }

    /* ---- 拖拽分类 ---- */
    if (cfg.drag_items && cfg.categories) {
      const dragId = 'tab-drag';
      content[dragId] = this._renderDragSection();
    }

    /* ---- 随堂测验 ---- */
    if (cfg.quiz && cfg.quiz.length) {
      const quizId = 'tab-quiz';
      content[quizId] = this._renderQuizSection();
    }

    return content;
  }

  /* ---- 新结构：knowledge_sections ---- */
  _renderKnowledgeSections() {
    const sections = this.config.knowledge_sections || [];
    let html = '';

    for (const sec of sections) {
      const type = sec.type || 'generic';

      if (type === 'hero') {
        // Hero 区块
        html += `<div class="hero">
  <div class="hero-icon">${sec.icon || '🔢'}</div>
  <h2>${esc(sec.title || '')}</h2>
  <p>${esc(sec.desc || '')}</p>
</div>`;
      }

      else if (type === 'realItems') {
        // 真实物品模拟卡片（图文并茂）
        const itemsHtml = (sec.items || []).map(item => {
          return `<div class="mock-card">
  <div class="mock-card-title">${esc(item.title || '')}</div>
  <div class="mock-card-body">${item.body || ''}</div>
  ${item.hint ? '<div class="mock-card-hint">' + esc(item.hint) + '</div>' : ''}
</div>`;
        }).join('');

        html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🧩'}</span> ${esc(sec.title || '生活中的编码')}</div>
  <div class="real-items-grid">${itemsHtml}</div>
</div>`;
      }

      else if (type === 'idcard') {
        // 身份证号可视化
        const segs   = sec.segments || [];
        const segsHtml = segs.map((s, i) =>
          `<div class="id-segment n${i+1}"><div>${esc(s.value)}</div><span class="id-segment-label">${esc(s.label)}</span></div>`
        ).join('');
        const legendHtml = segs.map((s, i) =>
          `<div class="legend-item"><div class="legend-dot" style="background:${s.color}"></div><div><div class="legend-text">${esc(s.label)}</div><div class="legend-desc">${esc(s.desc || '')}</div></div></div>`
        ).join('');

        html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🪪'}</span> ${esc(sec.title || '身份证号结构')}</div>
  <div class="id-visual">
    <div class="id-visual-title">${esc(sec.subtitle || '')}</div>
    <div class="id-number-display">${segsHtml}</div>
    <div class="id-legend">${legendHtml}</div>
  </div>
</div>`;
      }

      else if (type === 'analyzer') {
        // 身份证解析器
        html += `<div class="card">
  <div class="card-title"><span class="icon">🔍</span> ${esc(sec.title || '身份证号码解析器（试试看！）')}</div>
  <div class="id-analyzer">
    <div class="analyzer-title">🔍 ${esc(sec.title || '身份证号码解析器（试试看！）')}</div>
    <div class="id-input-row">
      <input type="text" class="id-input" id="idInput" placeholder="输入18位身份证号" maxlength="18">
      <button class="analyze-btn" onclick="analyzeId()">解析！</button>
    </div>
    <div class="id-error" id="idError">请输入正确的18位身份证号码！</div>
    <div class="id-result" id="idResult">
      <div class="result-row"><div class="result-badge">地址码</div><div><div class="result-value" id="resAddr"></div><div class="result-note" id="resAddrNote"></div></div></div>
      <div class="result-row"><div class="result-badge">出生日期</div><div><div class="result-value" id="resBirth"></div><div class="result-note" id="resBirthNote"></div></div></div>
      <div class="result-row"><div class="result-badge">顺序码</div><div><div class="result-value" id="resSeq"></div><div class="result-note" id="resSeqNote"></div></div></div>
      <div class="result-row"><div class="result-badge">校验码</div><div><div class="result-value" id="resCheck"></div><div class="result-note" id="resCheckNote"></div></div></div>
    </div>
  </div>
</div>`;
      }

      else if (type === 'rules') {
        // 学号规则卡片
        const rulesHtml = (sec.items || []).map((r, i) =>
          `<div class="rule-card">
  <div class="rule-num">0${i+1}</div>
  <h4>${esc(r.title)}</h4>
  <p>${esc(r.desc || '')}</p>
  <div class="emoji">${r.emoji || '📌'}</div>
</div>`
        ).join('');

        html += `<div class="card">
  <div class="card-title"><span class="icon">${sec.titleIcon || '🎓'}</span> ${esc(sec.title || '学号编码规则')}</div>
  <div class="rule-cards">${rulesHtml}</div>
</div>`;
      }

      else {
        // 通用知识卡片（旧格式兼容）
        html += `<div class="card">
  <div class="card-title">${esc(sec.title || '知识点')}</div>
  <div class="card-content">${esc(sec.content || '').replace(/\n/g, '<br>')}</div>
</div>`;
      }
    }

    return html;
  }

  /* ---- 旧结构兼容 ---- */
  _renderLegacyKnowledge() {
    const cfg = this.config;
    return richKnowledgeCard(
      cfg.knowledge_title || '本节核心知识',
      null,
      [{
        type: 'grid',
        title: '核心要点',
        items: [{ icon: '📖', label: cfg.knowledge_title || '', desc: cfg.knowledge_content || '', color: 'food' }]
      }]
    );
  }

  /* ---- 拖拽分类 ---- */
  _renderDragSection() {
    const cfg  = this.config;
    const items = cfg.drag_items || [];
    const cats  = cfg.categories || [];
    let html = `<div class="stats-bar">
  <span>🎯 拖拽得分：<span class="score"><span id="dragScore">0</span> / <span id="dragTotal">${items.length}</span></span></span>
  <span style="margin-left:auto;font-size:14px;opacity:.8">把卡片拖到对应区域</span>
</div>`;

    // 拖拽卡片池
    html += '<div class="drag-container">';
    html += '<div class="drag-pool" style="flex:0 0 auto">';
    html += '<div style="font-size:14px;color:var(--gray);margin-bottom:12px;font-weight:800;text-align:center">🧩 可拖拽卡片</div>';
    for (const item of items) {
      html += `<div class="drag-chip" draggable="true" data-category="${esc(item.category)}" data-id="${esc(item.text)}">${esc(item.text)}</div>`;
    }
    html += '</div>';

    // 分类放置区
    for (const cat of cats) {
      html += `<div class="drag-pool" data-category="${esc(cat)}">
  <div class="drag-pool-title">📂 ${esc(cat)}</div>
  <div class="dropped-items"></div>
</div>`;
    }
    html += '</div>';

    // 完成横幅
    html += `<div class="complete-banner" id="dragComplete">🎉 太棒了！你已经完成所有分类！</div>`;

    return html;
  }

  /* ---- 随堂测验 ---- */
  _renderQuizSection() {
    const cfg = this.config;
    const quiz = cfg.quiz || [];
    let html = `<div class="stats-bar">
  <span>✏️ 测验得分：<span class="score"><span id="quizScore">0</span> / <span id="quizTotal">${quiz.length}</span></span></span>
  <span style="margin-left:auto;font-size:14px;opacity:.8">每题只有一次作答机会哦</span>
</div>`;

    quiz.forEach((q, qi) => {
      const opts = (q.options || []).map((opt, oi) =>
        `<div class="quiz-opt" onclick="checkAnswer(this, ${oi}, ${q.answer}, ${qi})">
          <span class="opt-letter">${String.fromCharCode(65+oi)}</span>${esc(opt)}
        </div>`
      ).join('');

      html += `<div class="quiz-card" data-answer="${q.answer}">
  <div class="quiz-q">${qi+1}. ${esc(q.q)}</div>
  <div class="quiz-opts">${opts}</div>
  <div class="quiz-feedback"></div>
</div>`;
    });

    html += `<div class="complete-banner" id="quizComplete">🏆 恭喜你！全部答对啦！</div>`;
    return html;
  }

  /* ---- JS ---- */
  _buildJS() {
    // 基础 JS（拖拽 + 测验 + 身份证解析器）
    let js = getDefaultJS();

    // 如果配置了条码渲染，注入 renderBarcode
    const needBarcode = JSON.stringify(this.config).includes('barcode');
    if (needBarcode) {
      js += `
// 条形码渲染
function renderBarcode(containerId, totalWidth) {
  var container = document.getElementById(containerId);
  if (!container) return;
  var widths = [2,3,1,4,2,3,1,2,4,1,3,2,1,2,3,1,4,2,1,3,2,1,2,3,4,1,2,1,3,2,1,2,3,1,2,4,2,1,3,2,1,2,3,4,1,2,1,3,2];
  var used = 0, i = 0;
  while (used < totalWidth && i < widths.length) {
    var w = widths[i % widths.length];
    var h = 30 + (i % 5) * 8;
    var bar = document.createElement('div');
    bar.className = 'bar';
    bar.style.width = w + 'px';
    bar.style.height = h + 'px';
    container.appendChild(bar);
    used += w + 1.5;
    i++;
  }
}
document.querySelectorAll('.barcode-strip').forEach(function(el) {
  var w = el.classList.contains('express-barcode-mini') ? 90 : 260;
  renderBarcode(el.id, w);
});`;
    }

    return js;
  }
}

/* ========== 命令行入口 ========== */
function main() {
  const args = process.argv.slice(2);
  let config, output;

  if (args.length >= 2) {
    const cfgPath = path.resolve(args[0]);
    config = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'));
    output = path.resolve(args[1]);
  } else {
    // 测试模式
    config = {
      topic: '测试互动工具',
      knowledge_sections: [
        { type: 'hero', icon: '🔢', title: '生活中的常见编码', desc: '我们身边充满了各种数字编码，它们让生活更有秩序！' },
        { type: 'realItems', title: '生活中的编码物品', items: [
          { title: '居民身份证', body: '<div class="id-card-mock"><div class="id-card-header"><div class="id-card-emblem">★</div><div><div class="id-card-title">中华人民共和国</div><div class="id-card-subtitle">居民身份证</div></div></div><div class="id-card-body"><div class="id-card-photo"><div class="photo-placeholder"><div class="photo-head"></div><div class="photo-body"></div></div></div><div class="id-card-fields"><div class="id-card-field"><span class="field-label">姓名</span><span class="field-value">张小明</span></div><div class="id-card-field"><span class="field-label">性别</span><span class="field-value">男</span></div></div></div><div class="id-card-number-row"><span class="id-card-num-label">公民身份号码</span><span class="id-card-num">430101201505200521</span></div></div>', hint: '看！这是真实身份证的样式，号码有18位哦！' },
        ]},
      ],
      drag_items: [
        { text: '苹果',   category: '水果类' },
        { text: '白菜',   category: '蔬菜类' },
      ],
      categories: ['水果类', '蔬菜类'],
      quiz: [
        { q: '身份证有多少位？', options: ['15位', '18位', '20位', '10位'], answer: 1 },
      ],
    };
    output = path.join(__dirname, 'test_output.html');
  }

  const gen = new HTMLGenerator(config);
  gen.generate(output);
}

if (require.main === module) {
  main();
}

module.exports = { HTMLGenerator };
