# 湘科版《信息科技》备课助手 - 安装说明

## 一键安装依赖

打开命令行（PowerShell / 终端），运行：

```
C:\Python\Python313\python.exe -m pip install python-pptx python-docx pillow lxml
```

## 技能目录结构

```
~/.workbuddy/skills/湘科版信息科技备课助手/
├── SKILL.md              ← 技能主文件（AI读取此文件获得指令）
├── INSTALL.md            ← 本文件
├── scripts/
│   ├── ppt_builder.py    ← PPT课件生成工具库（含图形装饰组件）
│   ├── doc_builder.py    ← 教案 & 任务单Word生成工具库
│   └── html_builder.py   ← 互动HTML工具生成工具库
└── references/           ← 参考资料存放处
```

## 触发方式

在对话中使用以下任意关键词即可自动加载此技能：

- `湘科版备课`
- `信息科技备课`
- `xxkj`
- `制作信息科技课件`
- `信息科技教案`
- `信息科技任务单`
- `信息科技PPT`

## 使用示例

```
帮我重新制作六上第一单元活动2《系统的过程与控制》的课件和教案，
原文件在 D:\MyProgram\MyTrae_XXKJ\media\resources\grade6-1-xk\
输出到 D:\MyProgram\MyTrae_XXKJ\media\resources\grade6-1-xk-v2\
```

```
xxkj 六年级上册第二单元活动1，从零开始制作四件套
```

## 输出文件结构

```
[输出目录]/
└── 活动N-[课题名]/
    ├── [课题名]_课件.pptx          ← PPT课件（12-15页）
    ├── [课题名]_教学设计.docx       ← 教案（含教学过程表）
    ├── [课题名]_学生任务单.docx     ← 任务单（含探究表格）
    └── [课题名]_互动教学工具.html  ← 课堂互动工具
```

## 注意事项

1. **不依赖外部图片** - 所有PPT图示均由python-pptx形状绘制，无需下载图片
2. **临时脚本自动清理** - AI生成的 gen_*.py 脚本在完成后会被删除
3. **中文引号问题** - 如出现SyntaxError，用脚本扫描替换中文弯引号（SKILL.md有方案）
4. **RGBColor参数** - 每个参数必须是0x00~0xFF之间的值，不能超过255
