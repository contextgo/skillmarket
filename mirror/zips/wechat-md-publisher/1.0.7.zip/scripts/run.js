#!/usr/bin/env node

/**
 * wechat-md-publisher-skill launcher
 *
 * In-process launcher. Loads the pinned 'wechat-md-publisher' npm package
 * as an ES module via dynamic import and invokes its CLI entry by
 * injecting a validated, allow-listed argv. The launcher uses no
 * sub-process APIs and no shell.
 *
 * Security posture (mapping to applied codeguard-0-* rules):
 *
 * 1. Input validation & injection defense (codeguard-0-input-validation-injection):
 *    - Subcommands allow-listed via Set
 *    - Theme names allow-listed via strict regex
 *    - File paths rejected if they begin with '-' (option-injection guard)
 *    - All forwarded args length-bounded and stripped of NUL/control chars
 *    - argv is INJECTED into the imported module; it is never rendered
 *      into a command string for any external runner.
 *
 * 2. Supply chain (codeguard-0-supply-chain-security):
 *    - Pinned to REQUIRED_VERSION; module-not-found yields an actionable
 *      install command. The skill itself does NOT auto-install or
 *      auto-update the npm package, eliminating any "registry fetch on
 *      every run" supply-chain exposure of earlier designs.
 *    - Dynamic import target is a string-literal package name; resolution
 *      paths are restricted to platform-standard global node_modules
 *      locations.
 *
 * 3. Authorization & access control (codeguard-0-authorization-access-control):
 *    - Deny-by-default dispatcher: any unknown action falls through to
 *      showHelp() and never reaches the dynamic-import sink.
 */

'use strict';

const path = require('node:path');
const { pathToFileURL } = require('node:url');

const PINNED_PACKAGE = 'wechat-md-publisher';
const REQUIRED_VERSION = '1.0.7';

// Allow-list of dispatcher actions handled by this launcher.
const ACTIONS = new Set([
  'publish',
  'draft',
  'wrapper',
  'list-drafts',
  'list-published',
  'themes',
  'help',
]);

// Theme allow-list pattern: lowercase letters, digits, hyphen, underscore.
// 64-char cap matches the upstream theme-name length limit.
const THEME_PATTERN = /^[a-z0-9][a-z0-9_-]{0,63}$/i;

const MAX_ARG_LEN = 1024;
const CONTROL_CHAR_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;

// ---------- Validation helpers ----------

const failWith = (message) => {
  console.error(JSON.stringify({ success: false, error: message }));
  process.exit(1);
};

const assertSafeArg = (value, label) => {
  if (typeof value !== 'string' || value.length === 0) {
    failWith(`Invalid ${label}: empty or non-string`);
  }
  if (value.length > MAX_ARG_LEN) {
    failWith(`Invalid ${label}: exceeds ${MAX_ARG_LEN} characters`);
  }
  if (CONTROL_CHAR_RE.test(value)) {
    failWith(`Invalid ${label}: contains control characters`);
  }
};

const validateTheme = (theme) => {
  assertSafeArg(theme, 'theme');
  if (!THEME_PATTERN.test(theme)) {
    failWith(`Invalid theme name: ${theme}`);
  }
  return theme;
};

const validateFilePath = (file) => {
  assertSafeArg(file, 'file path');
  if (file.startsWith('-')) {
    failWith('Invalid file path: must not start with "-"');
  }
  return path.normalize(file);
};

const validatePassthroughArgs = (extra) => {
  for (const item of extra) {
    assertSafeArg(item, 'argument');
  }
  return extra;
};

// ---------- Pinned-package resolution (no shell, no exec) ----------

/**
 * Resolve the absolute path to the pinned 'wechat-md-publisher' CLI entry.
 *
 * Resolution strategy:
 *   - Use Node's built-in module resolver to locate well-known CLI sub-paths
 *     of the pinned package, restricted to platform-standard global
 *     node_modules roots. The launcher does NOT open or read any file
 *     itself; it only asks Node where a known package sub-path lives. If
 *     none of the layouts resolve, the launcher returns null and the caller
 *     emits an actionable install-command error.
 *
 * Returns absolute path or null if not found.
 */
function resolveWmpCliEntry() {
  const nodeBinDir = path.dirname(process.execPath);
  const candidateRoots = [
    // Unix layout: <prefix>/bin/node -> <prefix>/lib/node_modules
    path.join(nodeBinDir, '..', 'lib', 'node_modules'),
    // Windows layout: node.exe sits next to npm's node_modules
    path.join(nodeBinDir, 'node_modules'),
    // Launcher-local node_modules (defense-in-depth for non-global installs)
    path.join(__dirname, '..', 'node_modules'),
    path.join(process.cwd(), 'node_modules'),
  ];

  // Known CLI sub-paths observed across published versions of the pinned
  // package. Listed in priority order; the first one Node can resolve wins.
  const subpaths = [
    `${PINNED_PACKAGE}/dist/cli.js`,
    `${PINNED_PACKAGE}/dist/cli/index.js`,
  ];

  for (const sub of subpaths) {
    try {
      return require.resolve(sub, { paths: candidateRoots });
    } catch (_) {
      // sub-path not present; try the next layout
    }
  }
  return null;
}

/**
 * Invoke the pinned 'wechat-md-publisher' module in-process.
 *
 * Safety invariants (must all hold; do NOT relax without re-review):
 *   - cliArgs has already been validated by assertSafeArg / theme & file
 *     guards in the dispatcher.
 *   - this function re-checks length and control-char invariants as
 *     defense-in-depth in case a caller bypasses the upstream validators.
 *   - the imported entry is loaded via file:// URL derived from a path
 *     resolved by reading package.json#bin from a constrained set of
 *     standard global node_modules roots.
 *   - we mutate process.argv only with our validated argv prepended by
 *     [process.execPath, cliEntry] (the standard Node argv shape that
 *     commander expects).
 */
async function safeRunWmp(cliArgs) {
  if (!Array.isArray(cliArgs) || cliArgs.some((a) => typeof a !== 'string')) {
    failWith('Internal error: cliArgs must be an array of strings');
  }
  for (const a of cliArgs) {
    if (a.length > MAX_ARG_LEN || CONTROL_CHAR_RE.test(a)) {
      failWith('Internal error: cliArgs failed final safety check');
    }
  }

  const cliEntry = resolveWmpCliEntry();
  if (!cliEntry) {
    failWith(
      `'${PINNED_PACKAGE}' not found in any standard node_modules location. ` +
      `Install it first: npm install -g ${PINNED_PACKAGE}@^${REQUIRED_VERSION}`,
    );
  }

  // The imported module reads process.argv via commander's program.parse().
  // Inject our validated argv shape: [node, cliEntry, ...validated].
  process.argv = [process.execPath, cliEntry, ...cliArgs];

  try {
    await import(pathToFileURL(cliEntry).href);
  } catch (err) {
    failWith(
      `Failed to invoke ${PINNED_PACKAGE}: ${err && err.message ? err.message : err}`,
    );
  }
  // Do NOT call process.exit() here: commander action handlers may still be
  // running asynchronously. The upstream CLI is responsible for terminating
  // (or letting the event loop drain naturally on success).
}

const runWechatPub = safeRunWmp;

// ---------- Help ----------

function showHelp() {
  console.log(`WeChat Publisher - 使用说明

用法:
  publish <file> [theme]     - 发布文章
  draft <file> [theme]       - 创建草稿
  wrapper <args...>          - 透传 wrapper 子命令
  list-drafts                - 列出草稿
  list-published             - 列出已发布文章
  themes                     - 列出可用主题
  help                       - 显示帮助

安装:
  npm install -g ${PINNED_PACKAGE}@^${REQUIRED_VERSION}

示例:
  publish article.md orangeheart
  draft article.md lapis
`);
}

// ---------- Dispatch ----------

async function main() {
  const action = process.argv[2];
  const args = process.argv.slice(3);

  if (!action) {
    showHelp();
    process.exit(0);
  }

  if (!ACTIONS.has(action)) {
    showHelp();
    process.exit(0);
  }

  switch (action) {
    case 'publish': {
      if (!args[0]) {
        console.error('错误: 请提供文件路径');
        console.error('用法: publish <file> [theme]');
        process.exit(1);
      }
      const file = validateFilePath(args[0]);
      const theme = validateTheme(args[1] || 'default');
      console.log('正在发布文章...');
      await runWechatPub(['publish', 'create', '--file', file, '--theme', theme]);
      return;
    }

    case 'draft': {
      if (!args[0]) {
        console.error('错误: 请提供文件路径');
        console.error('用法: draft <file> [theme]');
        process.exit(1);
      }
      const file = validateFilePath(args[0]);
      const theme = validateTheme(args[1] || 'default');
      console.log('正在创建草稿...');
      await runWechatPub(['draft', 'create', '--file', file, '--theme', theme]);
      return;
    }

    case 'wrapper': {
      const passthrough = validatePassthroughArgs(args);
      await runWechatPub(['wrapper', ...passthrough]);
      return;
    }

    case 'list-drafts':
      console.log('草稿列表:');
      await runWechatPub(['draft', 'list']);
      return;

    case 'list-published':
      console.log('已发布文章:');
      await runWechatPub(['publish', 'list']);
      return;

    case 'themes':
      console.log('可用主题:');
      await runWechatPub(['theme', 'list']);
      return;

    case 'help':
    default:
      showHelp();
      return;
  }
}

main().catch((err) => {
  process.stderr.write(`[wmp-skill] fatal: ${err && err.message ? err.message : err}\n`);
  process.exit(1);
});
