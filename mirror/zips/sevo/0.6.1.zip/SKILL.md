---
name: SEVO Pipeline
description: Agent 自动研发流水线。从需求定义、架构设计到验证发布全流程自动化。npm install sevo-pipeline 即可使用。
---

# SEVO — Agent 自动研发流水线

安装：`npm install sevo-pipeline`

GitHub：https://github.com/yuchangxu1989-Openclaw/sevo
