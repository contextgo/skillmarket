# SEVO - 产品需求规格说明书

Codex（OpenClaw ACP Agent）| 2026-04-19

---

## 目录

1. 产品愿景与定位
2. 目标用户画像
3. 编排入口与流程编排
4. 功能需求（8 阶段 + 3 个验收阶段 + 2 个门禁 + 5 个跨阶段机制 + 1 个生命周期操作 + 4 个平台能力）
5. 非功能需求
6. 概念架构
7. 与 Self-Evolving Harness 其他模块的边界
8. Wave 规划
9. 约束与假设

## 1. 产品愿景与定位

SEVO（Spec-Execute-Verify-Operate）是面向 vibe coding 用户的 Agent 研发流水线。它把需求定义、方案约束、实现执行、独立审计、回归验证、部署发布、清洁环境验收和交付留痕收拢到同一条可追溯流水线上，让 Agent 软件研发从“能生成代码”升级为“能稳定交付结果”。SEVO 服务的核心人群是把 AI 当研发主力的人：他们要的不是一次性生成，而是每次改动都能看清目标、边界、证据和责任。

SEVO 以 npm 包（`sevo-pipeline`）形式分发，`npx sevo init` 一条命令完成环境初始化，零配置即可启动第一条研发流水线。SEVO 把 PM、UX、架构师、审计等角色的专业标准内置到流水线阶段中——单 Agent 用户也能产出 PM 质量的 spec，多 Agent 环境有专职角色则效果更好，但不是必须。

SEVO 负责研发流程本身，不负责替代具体宿主环境。宿主环境可以是 OpenClaw、其他 ACP harness，或任意支持 Agent 协作的执行框架。SEVO 定义统一的阶段、工件、门禁和验收语言。

**终局思维：以终局用户体验为目标的全自动化开发。** SEVO 流水线的终点不是「代码能跑」「测试通过」「npm 发布成功」，而是「陌生用户装上就能用、5 分钟内感受到产品的核心价值」。这是 SEVO 区别于传统 CI/CD 和 AI Coding 工具的核心差异——传统工具优化开发者体验，SEVO 优化终局用户体验。

**目标驱动 PDCA 闭环：OKR→SMART→PDCA 融入现有流程。** SEVO 的运转不是线性流水线跑一遍就结束，而是围绕终局目标的持续收敛循环。OKR→SMART→PDCA 是目标管理的核心理念，它指导 SEVO 的每一次闭环，融入到现有阶段中：

- **Pipeline 创建时（OKR 介入）**：SEVO 主动引导用户澄清需求的终局目标——「做完后，一个从没见过这个产品的人，装上 5 分钟内应该能做到什么？」锁定为 endStateGoal，拆解为 Objective + Key Results。这是 pipeline 的北极星。
- **Spec 阶段（SMART 介入）**：每个 KR 转化为具体（Specific）、可度量（Measurable）、可达成（Achievable）、相关（Relevant）、有时限（Time-bound）的 FR。FR 天然带着「服务于哪个 KR → 哪个 O → 终局目标」的溯源链。
- **Implement → Review → Verify → Deploy（PDCA 的 Do + Check）**：现有阶段不变，但每个 gate 的评估锚点升级——从「这个阶段的产出合格吗」到「这个阶段的产出在向终局目标收敛吗」。
- **Post-Release Validation（PDCA 的 Check，目标级）**：不是查 FR 清单，是查 KR 达成了没有。差距分析的对象是终局目标，不是功能列表。
- **差距 > 0（PDCA 的 Act）**：分析哪个 KR 未达成，重新 SMART 拆解，进入下一轮 pipeline 循环。
- **差距 = 0**：所有 KR 达成，Objective 达成，终局目标达成，pipeline 关闭。

现有 18 个阶段一个不改。加的是 pipeline 级别的目标元数据（endStateGoal、OKR 树、KR 达成度）和循环判定逻辑（差距分析 → 决定是否再来一轮）。Post-Release Validation Gate 是这条闭环的强制执行点。

## 2. 目标用户画像

### 2.1 Solo Founder / 独立产品操盘者

- 用 Agent 推进产品、技能、自动化系统的研发。
- 关心交付速度，也关心返工成本和线上事故。
- 需要看到每一轮改动的目标、边界、验收标准和交付证据。
- 上手路径：`npm install -g sevo-pipeline && npx sevo init && sevo project create my-app`，5 分钟内看到第一条 pipeline 的 Spec 阶段产出。

### 2.2 Agent 原生开发者

- 把 AI 作为主要编码和调试执行者。
- 需要一条能约束 Agent 的研发流程，减少“写完就算完”的假完成。
- 需要把 Spec、Contract、Implement、Review 串起来，避免需求和代码脱节。
- 上手路径：`npx sevo init` 自动发现已有 Agent 并分配角色，`sevo fr add <project> "需求描述"` 后 pipeline 自动推进，开发者只需响应阶段任务。

### 2.3 质量与架构把关者

- 负责审计需求、架构、代码质量和交付完整性。
- 需要独立视角和统一工件链路，快速判断是否通过、卡在哪里、缺什么。
- 需要把经验沉淀回系统，而不是散落在聊天记录里。
- 上手路径：`sevo status` 查看所有 pipeline 状态，门禁阶段自动派发审查任务，审查结论写入结构化工件。

### 2.4 宿主平台与外部 Agent 提供方

- 提供不同模型、不同 Agent、不同执行环境。
- 需要接入一套通用研发流水线，而不是被迫接受某个宿主的私有实现。
- 需要核心逻辑与运行时解耦，便于替换执行器、审计器、发布器。
- 上手路径：`npm install sevo-pipeline`，通过库 API 或 Adapter 接口对接自有执行环境，核心阶段语义开箱可用。

### 2.5 陌生用户首次使用旅程

一个从未见过 SEVO 的用户，完整的首次体验路径：

1. `npm install -g sevo-pipeline` — 安装 SEVO。
2. `npx sevo init` — 自动检测宿主环境、注册插件、发现 Agent 并分配角色。单 Agent 环境自动降级，所有角色由同一个 Agent 承担。
3. 重启宿主环境（如 `openclaw gateway restart`）使插件生效。
4. `sevo project create my-first-project --description "项目描述"` — 创建第一个 Project。
5. `sevo fr add my-first-project "实现用户登录功能"` — 添加第一条 FR，pipeline 自动创建并开始推进。
6. `sevo status` — 查看 pipeline 当前走到哪个阶段、卡在哪里、下一步是什么。

从步骤 1 到步骤 5 产出第一份 Spec，预计耗时不超过 5 分钟。

## 3. 编排入口与流程编排

SEVO 是所有涉及代码变更的任务的默认研发流程。任务进入 SEVO 后，系统根据任务复杂度自动选择最合适的流程路径——简单任务走最小闭环，复杂任务走完整流水线。区别在于流程路径的深度，不在于是否进入 SEVO。

### 3.1 编排范围

所有涉及代码变更的任务默认进入 SEVO 编排范围。以下条件决定流程路径的深度（Level 0/1/2+）：

- 从零新建模块或系统 → Level 2+。
- 涉及两个及以上域的边界变化 → Level 2+。
- 预估改动超过 500 行或 10 个文件 → Level 2+。
- 涉及数据模型变化 → Level 2+。
- 涉及治理规则、调度逻辑、质量门禁的变化 → Level 2+。
- 涉及发布目标或交付方式变化 → Level 1+。
- 单域中等改动 → Level 1。
- 微小改动（bug 修复、配置调整、小功能）→ Level 0。
- 用户明确要求走完整流程 → Level 2+。
- 已有项目的需求规格说明书需要改动（新增/修改/删除 FR 或 AC）→ Level 1+。

查询、聊天、配置调整等不涉及代码变更的任务不进入 SEVO。

**触发判断实现（双层策略）**：
- 主路径：LLM 语义判断。系统将任务描述提交给 LLM，由 LLM 判断任务是否命中上述条件、应归入哪个 Level，返回结构化判定结果（是否触发、Level、命中条件、判定理由）。
- 降级路径：丰富的关键词/正则匹配。当 LLM 不可用或超时时自动降级。关键词按触发条件分组（新建类、跨域类、数据模型类、治理类、spec 变更类、发布类等），覆盖中英文，匹配最高 Level。降级触发时必须在日志中显式标注 `source: keyword-fallback`。
- 设计理由：99% 的 SEVO 用户没有 KIVO 意图理解增强能力，降级策略是商用开箱即用的必要保障。关键词集合应预置足够丰富，确保 fallback 质量。

### 3.2 流程路径

SEVO 根据任务复杂度自动选择最短有效路径：

- **Level 0**：微小改动。直接进入 Implement，经过 Review、Smoke Test、Verify、Ledger 的最小闭环。
- **Level 1**：单域中等改动。从 Spec 开始，Contract 可简化，门禁不能省。
- **Level 2+**：新系统、跨域重构、大范围变更、治理层变更。走完整 8 阶段，执行两道门禁。

### 3.3 路由输出与编排启动

任务进入 SEVO 后，系统产出路由结果，至少包含：

- 目标 Project（project-slug）。
- 任务级别（Level 0/1/2+）。
- 必经阶段清单。
- 可跳过阶段及跳过理由。
- 当前轮次的验收重点。
- 需要追踪的核心工件。

路由结果直接驱动 PipelineEngine（FR-13）创建阶段执行队列并开始自动推进。PipelineEngine 通过状态机驱动 + 宿主 Adapter 触发阶段执行，不需要人工干预。

### 3.4 验收标准

- AC-3.1：相同输入任务在同一套规则下得到稳定一致的路由结果。
- AC-3.2：每个进入 SEVO 的任务都有清晰的阶段清单和跳过理由。
- AC-3.3：任何被跳过的阶段都不影响最终交付可追溯性。
- AC-3.4：路由结果直接驱动 PipelineEngine 创建阶段执行队列，不需要人工重新解释。
- AC-3.5：每个 FR 流程实例有唯一 ID，所有阶段工件可通过实例 ID 关联。
- AC-3.6：多个 Project 的 FR 流程实例并行运行时，工件目录互不干扰。
- AC-3.7：FR 流程实例状态变化可追溯，任一时刻能回答“这条 FR 的 SDD 流程走到哪了”。
- AC-3.8：pipeline 创建后，PipelineEngine 在无人工干预的情况下自动推进到第一个阶段并开始执行。

### 3.5 FR 流程实例

FR 流程实例是一次完整的 SDD 流程执行。每当用户把一条 FR 添加到某个 Project，且该 FR 命中触发条件（§3.1）并完成路由判定后，系统创建一个 FR 流程实例，绑定到目标 Project，分配唯一 ID。这里的生命周期起点需要钉死：Project 由用户创建，最小输入是名称和描述；FR 由用户添加到 Project 中，最小输入是需求描述；FR 一旦创建成功，就自动进入 Specify 阶段对应的流程准备态，并据此生成或挂接到一个 FR 流程实例。

核心属性：

- **实例 ID**：全局唯一标识，格式 `fr-<project-slug>-<yyyyMMdd>-<seq>`，如 `fr-sevo-20260420-001`。
- **Project 绑定**：每个实例归属一个 Project，实例的全部工件存放在该 Project 的目录空间内。
- **路由结果**：实例创建时确定的任务级别、必经阶段、跳过阶段。
- **当前阶段**：实例正在执行的 SDD 流程阶段。
- **工件索引**：各阶段产出工件的引用列表。

状态模型：

- **created**：实例已创建，Project 目录已初始化，尚未进入第一个阶段。
- **active**：至少一个阶段处于 active 或 blocked 状态。
- **paused**：用户或系统主动挂起，所有阶段暂停推进。
- **completed**：最终阶段（Ledger）通过，交付闭环。
- **failed**：流程因不可恢复的原因终止。

状态流转：

- created → active：第一个阶段开始执行。
- active → paused：用户主动挂起或系统检测到阻断条件。
- paused → active：恢复执行。
- active → completed：Ledger 阶段通过。
- active → failed：不可恢复的失败（如用户取消、关键依赖永久不可用）。

生命周期：

1. 任务命中触发条件，路由判定完成。
2. 创建 FR 流程实例，绑定 Project，初始化目录结构。
3. 按路由结果依次推进各阶段，每个阶段的工件归档到实例目录。
4. Ledger 阶段完成后，实例状态变为 completed，交付账本条目记录实例 ID。

并行规则：

- 同一 Project 同一时刻只允许一个 active 的 FR 流程实例。前一个实例必须 completed 或 failed 后，才能创建新实例。
- 不同 Project 的 FR 流程实例完全独立，可并行运行。

### 3.6 Project 与标准目录结构

Project 是 SEVO 管理的独立交付单元。每个 Project 拥有自己的目录空间，所有 FR 流程实例的工件在该空间内按阶段归档。

标准目录结构：

```
<workspace>/projects/<project-slug>/
├── docs/                              # 过程文档
│   ├── product-requirements.md        # 需求规格
│   ├── architecture/                  # 架构文档
│   │   ├── arc42-architecture.md      # 主架构文档
│   │   └── decisions/                 # ADR（架构决策记录）
│   └── test-cases/                    # 测试用例文档
├── src/                               # 源代码
├── tests/                             # 测试代码
├── skill/                             # Skill 定义（如有）
├── reports/                           # 评审报告、审计报告
├── artifacts/                         # 阶段产出工件（构建产物、发布包）
├── README.md
├── LICENSE
├── package.json
└── tsconfig.json
```

目录职责：

- `docs/`：过程文档。需求规格、架构设计、ADR、测试用例——描述“要做什么”和“怎么设计”。
- `src/`：源代码。实现产物——“做出来的东西”。
- `tests/`：测试代码。自动化测试——“怎么证明做对了”。
- `skill/`：Skill 定义文件。如果 Project 产出的是 Skill，定义文件放这里。
- `reports/`：质量证据。评审报告、审计报告、回归报告——“谁检查过、结论是什么”。
- `artifacts/`：阶段产出工件。构建产物、发布包、部署制品——“最终交付物”。

分类：

- 过程文档：`docs/`（描述意图和设计）。
- 结果代码：`src/`（实现产物）。
- 质量证据：`tests/` + `reports/`（验证和审计记录）。
- 交付物：`artifacts/`（可发布的最终产物）。

初始化规则：

- FR 流程实例创建时（FR-12），系统自动检查 Project 目录结构是否存在。
- 目录不存在时，按标准结构创建全部目录和占位文件。
- 目录已存在时，只补全缺失的子目录，不覆盖已有内容。

## 4. 功能需求（8 阶段 + 3 个验收阶段 + 2 个门禁 + 5 个跨阶段机制 + 1 个生命周期操作 + 4 个平台能力）

### FR-01 Spec

- **输入**：用户目标、业务背景、已有约束、历史参考材料。
- **处理**：明确问题、目标用户、范围、FR、NFR、概念架构和验收标准。
- **输出**：需求规格包（Spec Package）。
- **执行阶段**：Spec。
- **审查阶段**：Spec Review Gate（独立评审）。
- **验收标准**：
  - AC-4.1：规格书能说清做什么、给谁做、做到什么程度算完成。
  - AC-4.2：每个核心功能都有验收标准。
  - AC-4.3：概念架构覆盖对象类型、状态流转和阶段间数据流。
  - AC-4.4：规格书不写具体技术选型和实现细节。

### FR-02 Spec Review Gate

- **输入**：需求规格包（Spec Package）、路由结果、适用规则。
- **处理**：由独立评审维度检查规格完整性、阶段隔离、概念架构完整度、边界清晰度和验收标准质量，并给出通过、有条件通过、不通过三档结论。
- **输出**：规格评审包（Spec Review Bundle），包含结论、问题清单、修复要求、通过条件和是否允许进入 Contract 的门禁结果。
- **执行阶段**：Spec Review Gate（独立评审，禁止规格作者自审）。
- **门禁判定**：评审结论为通过时放行；有条件通过或不通过时阻断，直到修复并复审通过。
- **验收标准**：
  - AC-4.5：Spec 进入 Contract 前必须先经过独立评审，默认禁止规格作者自审。
  - AC-4.6：评审结果至少区分通过、有条件通过、不通过三档，并显式记录阻断问题。
  - AC-4.7：有条件通过和不通过都会阻断进入 Contract，直到阻断问题完成修复并复审通过。
  - AC-4.8：评审结论必须指向具体规格内容、缺口或越界点，不能只给抽象评价。

### FR-02a Test Case Authoring

- **触发时机**：Spec Review Gate（FR-02）通过后，与 Contract（FR-03）并行启动。
- **输入**：已通过 Spec Review Gate 的需求规格包。
- **处理**：基于需求规格中的验收标准（AC）编写测试用例，产出独立的测试用例文档。
- **输出**：测试用例文档（独立交付物）。
- **执行阶段**：Test Case Authoring。
- **并行关系**：与 FR-03 Contract 并行执行，不互相阻塞。
- **验收标准**：
  - AC-4.8a：每个高优先级 FR 的验收标准至少有一条对应测试用例。
  - AC-4.8b：测试用例作为独立文档交付，不写入需求规格或契约包。
  - AC-4.8c：初期允许极简形态，后期可专项优化扩展。

### FR-02b UX Acceptance Authoring

- **触发时机**：Spec Review Gate（FR-02）通过后，与 Contract（FR-03）、Test Case Authoring（FR-02a）并行启动。
- **输入**：已通过 Spec Review Gate 的需求规格包。
- **处理**：由 UX 角色（ux-01）编写「用户开箱即用视角」评测用例——模拟陌生用户首次使用的完整旅程，产出 markdown 检查清单（非代码测试）。
- **输出**：UX 开箱即用评测检查清单（独立交付物，存放于项目 docs/ 下）。
- **执行阶段**：UX Acceptance Authoring。
- **角色约束**：仅 UX 角色可执行，禁止开发者或产品角色代写。
- **并行关系**：与 FR-02a Test Case Authoring、FR-03 Contract 并行执行，不互相阻塞。
- **验收标准**：
  - AC-4.8d：检查清单覆盖零配置安装、首次运行、核心功能体验、错误提示友好度、文档可读性五个维度。
  - AC-4.8e：检查清单作为独立 markdown 文档交付，不写入需求规格或契约包。
  - AC-4.8f：检查清单中每个检查项有明确的通过/失败判定标准。
  - AC-4.8g：产出工件记录 authorRole 为 ux，可追溯到执行角色。

### FR-02c Commercial Acceptance Authoring

- **触发时机**：Spec Review Gate（FR-02）通过后，与 Contract（FR-03）、Test Case Authoring（FR-02a）、UX Acceptance Authoring（FR-02b）并行启动。
- **输入**：已通过 Spec Review Gate 的需求规格包。
- **处理**：由 PM 角色（pm-01）编写「商用视角」评测用例——验证商用就绪标准，产出 markdown 检查清单（非代码测试）。
- **输出**：商用评测检查清单（独立交付物，存放于项目 docs/ 下）。
- **执行阶段**：Commercial Acceptance Authoring。
- **角色约束**：仅 Product 角色可执行，禁止开发者或 UX 角色代写。
- **并行关系**：与 FR-02a、FR-02b、FR-03 并行执行，不互相阻塞。
- **验收标准**：
  - AC-4.8h：检查清单覆盖 npm 包完整性、README 营销质量、依赖安全、许可证合规、发布三平台覆盖、版本号一致性六个维度。
  - AC-4.8i：检查清单作为独立 markdown 文档交付，不写入需求规格或契约包。
  - AC-4.8j：检查清单中每个检查项有明确的通过/失败判定标准。
  - AC-4.8k：产出工件记录 authorRole 为 product，可追溯到执行角色。

### FR-03 Contract

- **输入**：已通过 Spec Review Gate 的需求规格包。
- **处理**：把需求翻译为可执行的架构方案、实现边界、阶段门禁、工作包拆分和交付顺序。
- **输出**：契约包（Contract Package），包含架构方案、实现边界、工作包拆分（含 Task 级细粒度分解）和交付顺序。
- **执行阶段**：Contract。
- **审查阶段**：Contract Review Gate（三方会审）。
- **验收标准**：
  - AC-4.9：每个高优先级 FR 都能在契约中找到对应实现承接点。
  - AC-4.10：工作包拆分后可分派、可验收、可追责。
  - AC-4.11：关键边界、风险和依赖被显式记录。
  - AC-4.12：契约包能直接驱动 Implement，不需要口头补规则。
  - AC-4.12a：每个工作包内部拆分为 Task 列表，每个 Task 粒度控制在 2-5 分钟，包含精确文件路径和预期变更描述。

### FR-04 Contract Review Gate

- **输入**：契约包（Contract Package）、关键架构决策、评审规则。
- **处理**：由产品视角、开发视角、质量视角三方并行会审，检查需求承接完整度、实现可行性、决策严谨性、扩展边界和交付波次，并形成是否允许进入 Implement 的门禁结论。
- **输出**：会审包（Contract Review Bundle），包含三方评审结论、阻断问题、修复要求、复审范围和是否允许进入 Implement 的门禁结果。
- **执行阶段**：Contract Review Gate，三方并行评审——产品维度（需求承接完整度）、开发维度（实现可行性）、质量维度（决策严谨性与质量规范）。
- **门禁判定**：三方共同放行。任一方结论为有条件通过或不通过时阻断，谁的问题未过审由谁继续复审，三方全部通过后方可进入 Implement。
- **验收标准**：
  - AC-4.13：进入 Implement 前必须完成三方并行会审，缺任一评审视角都不能放行。
  - AC-4.14：三方评审至少覆盖产品完整度、开发可行性和质量严谨性三个视角。
  - AC-4.15：任一评审结论为有条件通过或不通过时，Implement 必须被阻断，直到对应问题修复并复审通过。
  - AC-4.16：会审产出必须明确记录每个问题对应的责任工件、修复项和复审责任方。

### FR-05 Implement

- **输入**：契约包、工作包、阶段规则、验收标准。
- **处理**：按工作包逐 Task 执行实现，遵循 TDD 循环（先写覆盖目标行为的失败测试 → 实现至测试通过 → 重构），限制改动边界，记录证据，形成可审计的变更集。
- **输出**：实现包（Implementation Bundle），包含代码变更、执行记录、测试结果和偏差说明。
- **执行阶段**：Implement。
- **审查阶段**：Review（独立审查）。
- **验收标准**：
  - AC-4.17：每个工作包都有明确输入、输出、允许改动范围和验收项。
  - AC-4.18：实现过程产出证据，不允许只交代码不交说明。
  - AC-4.19：完成判定以验收结果为准，不以 Agent 自报完成为准。
  - AC-4.20：实现结果能追溯到对应 FR 和 Contract 决策。
  - AC-4.20a：每个工作包的实现遵循 TDD 循环：先写覆盖目标行为的失败测试，再写实现使测试通过，最后重构。
  - AC-4.20b：未经测试覆盖的代码变更不允许通过 Review 阶段。
  - AC-4.20f：编码 Agent 只能实现 spec 中明确定义的 FR 和 AC。觉得某功能有价值，必须先提需求变更请求，经 Specify 阶段评审写入 spec 后才能实现。

### FR-05a Systematic Debugging

- **触发时机**：Implement（FR-05）执行过程中或完成后发现非预期行为时触发，作为 Implement 和 Review 之间的可选活动。
- **输入**：实现包（或部分实现结果）、失败测试、异常日志、非预期行为描述。
- **处理**：按四阶段框架执行系统化调试——复现（在可控条件下稳定重现问题）→ 定位（缩小问题范围至具体模块或代码路径）→ 分析（确定根因，排除表面症状）→ 验证（修复后确认问题消除且未引入新问题）。
- **输出**：调试记录（Debugging Record），包含问题描述、根因分析、修复方案和验证结果。
- **执行阶段**：Systematic Debugging（Implement 内部可选活动）。
- **验收标准**：
  - AC-4.20c：调试过程遵循复现→定位→分析→验证四阶段，禁止跳过复现直接猜测修复。
  - AC-4.20d：调试结论基于证据（日志、测试结果、代码路径分析），不基于主观推测。
  - AC-4.20e：修复后的验证必须覆盖原始失败场景和相关回归路径。

### FR-06 Review

- **输入**：实现包。审计时参考 FR-02a 产出的测试用例文档（仅做参考，不代表全部审计项）。
- **处理**：由独立审查阶段审查代码质量、需求一致性、边界遵守情况和高风险点。
- **输出**：评审包（Review Bundle），包含结论、问题清单、修复要求和通过条件。
- **执行阶段**：Review，质量维度（代码质量、安全性、规范遵守）和产品维度（功能完整性、需求一致性确认）。两个维度独立评审，各自产出结论。
- **门禁判定**：两个维度共同放行。任一方结论为有条件通过或不通过时阻断，直到对应问题修复并复审通过。
- **验收标准**：
  - AC-4.21：评审者与实现者职责分离。
  - AC-4.22：评审结果至少区分通过、有条件通过、不通过。
  - AC-4.23：每个阻断问题都能指向具体工件和修复项。
  - AC-4.24：通过结论建立在证据上，不建立在主观判断上。
  - AC-4.24k：Review 阶段必须包含 spec-code 覆盖检查——从需求规格书提取全量 AC，逐条比对实现包中的代码覆盖情况，产出 AC 覆盖矩阵（AC 编号 / 覆盖状态 / 对应代码位置）。
  - AC-4.24l：AC 覆盖矩阵中任何 AC 状态为未实现或部分实现时，Review 结论必须为不通过（blocker）。代码实现只能比需求定义多，不能比需求定义少。
  - AC-4.24m：类型定义存在不等于已实现。AC 覆盖判定必须同时检查类型定义、逻辑代码和测试三层，缺任何一层视为部分实现。
  - AC-4.24n：ImplementationReviewGate 作为 Review 阶段的程序化门禁，自动从 Spec Package 提取 AC、从 Implementation Bundle 提取覆盖证据，覆盖率低于 100% 时门禁结论为 rejected。
  - AC-4.24n2：Review 阶段必须检查：代码中每个功能模块是否都能追溯到 spec 中的 FR/AC 编号。无法追溯的代码视为伪需求，必须删除或补充 spec 定义后才能通过 Review。

### FR-06a Review Fix Loop

- **触发时机**：Review（FR-06）或 Contract Review Gate（FR-04）产出评审包且结论为有条件通过或不通过时自动触发。
- **输入**：评审包（Review Bundle 或 Contract Review Bundle），包含问题清单。
- **处理**：
  1. 自动解析评审报告，提取结构化问题清单，每个问题标注严重级别（P0/P1/P2/P3）、关联的原始 FR、问题所在工件和修复建议。
  2. P0 和 P1 问题自动生成修复任务卡片（Fix Task），关联原 FR 流程实例、评审报告和问题条目。P2/P3 问题记录待办，不阻断当前批次。
  3. 修复任务按优先级排入待办队列（P0 优先于 P1），可被空闲 Agent 认领执行。
  4. 修复任务完成后，自动触发原评审维度对修复范围做定向复验（Targeted Revalidation），复验范围限定为修复涉及的工件和关联影响面，不重跑全量评审。
  5. 复验通过 → 对应问题关闭 → 系统重新评估门禁放行条件（所有 P0 关闭且 P1 关闭或豁免时放行）。复验不通过 → 问题状态回退，继续修复→复验循环。
  6. 全链路状态（评审报告 → 问题清单 → 修复任务状态 → 复验结果）在驾驶舱实时可见。
- **输出**：问题清单（Review Issue List）、修复任务卡片（Fix Task）、复验结论（Revalidation Result）。
- **执行阶段**：Review Fix Loop（Review 和 Contract Review Gate 的内置子流程）。
- **验收标准**：
  - AC-4.24a：评审结论为有条件通过或不通过时，系统在评审完成后自动解析报告并生成结构化问题清单，无需人工介入。
  - AC-4.24b：问题清单中每个条目包含严重级别（P0/P1/P2/P3）、关联 FR、问题工件定位和修复建议。
  - AC-4.24c：P0 和 P1 问题自动生成修复任务卡片，卡片关联原 FR 流程实例 ID 和评审报告引用。
  - AC-4.24d：修复任务按 P0 > P1 优先级排序进入待办队列，可被 Agent 认领执行。
  - AC-4.24e：修复任务完成后，系统自动触发原评审维度对修复范围做定向复验，复验范围不超出修复涉及的工件及其关联影响面。
  - AC-4.24f：复验通过时对应问题自动关闭；复验不通过时问题状态回退，修复→复验循环继续，直到通过或人工干预终止。
  - AC-4.24g：所有 P0 问题关闭且所有 P1 问题关闭或经人工豁免后，门禁自动重新评估并放行。
  - AC-4.24h：评审报告、问题清单、修复任务状态、复验结果的全链路状态在驾驶舱实时可见。
  - AC-4.24i：修复→复验循环有最大轮次上限（默认 3 轮），超限后升级为人工介入，防止无限循环。
  - AC-4.24j：P2/P3 问题记录为待办项，不阻断当前门禁放行，但纳入后续迭代的输入。

### FR-06b Smoke Test

- **触发时机**：Review（FR-06）通过后自动触发，在进入 Regression 之前执行。
- **输入**：通过 Review 的实现包、FR-02a 产出的测试用例文档。
- **处理**：编码 Agent 在实现环境中执行 smoke test，验证核心功能路径可用、构建产物完整、关键入口无崩溃。
- **输出**：Smoke Test 结果（Smoke Test Result），包含测试执行记录、通过/失败状态和失败原因。
- **执行阶段**：Smoke Test。
- **角色约束**：由 review 角色执行。
- **验收标准**：
  - AC-4.24o：Review 通过后，PipelineEngine 自动推进到 Smoke Test 阶段，无需主会话人肉触发。
  - AC-4.24p：Smoke Test 覆盖核心功能路径、构建产物完整性和关键入口无崩溃三个维度。
  - AC-4.24q：Smoke Test 失败时阻断后续阶段，结果中明确列出失败项和复现步骤。

### FR-06c UX Acceptance

- **触发时机**：Smoke Test（FR-06b）通过后自动触发，与 PM Commercial Review（FR-06d）并行执行。
- **输入**：通过 Smoke Test 的实现包、FR-02b 产出的 UX 开箱即用评测检查清单。
- **处理**：由 UX 角色（ux-01）按 FR-02b 产出的检查清单执行视觉验收——模拟陌生用户首次使用，逐项检查零配置安装、首次运行、核心功能体验、错误提示友好度、文档可读性。
- **输出**：UX 验收结果（UX Acceptance Result），包含逐项通过/失败状态、截图证据和改进建议。
- **执行阶段**：UX Acceptance。
- **角色约束**：仅 UX 角色可执行，禁止开发者或产品角色代执行。
- **并行关系**：与 FR-06d PM Commercial Review 并行执行，两者均通过后方可进入 Regression。
- **验收标准**：
  - AC-4.24r：Smoke Test 通过后，PipelineEngine 自动推进到 UX Acceptance 阶段，无需主会话人肉触发。
  - AC-4.24s：UX 验收按 FR-02b 产出的检查清单逐项执行，每项有明确通过/失败判定。
  - AC-4.24t：UX 验收失败时阻断进入 Regression，结果中列出失败项和改进建议。
  - AC-4.24u：产出工件记录 authorRole 为 ux，可追溯到执行角色。

### FR-06d PM Commercial Review

- **触发时机**：Smoke Test（FR-06b）通过后自动触发，与 UX Acceptance（FR-06c）并行执行。
- **输入**：通过 Smoke Test 的实现包、FR-02c 产出的商用评测检查清单、README.md、package.json。
- **处理**：由 PM 角色（pm-01）执行商用就绪评审——陌生用户开箱即用验证、spec-code 一致性检查、README 营销质量评估。
- **输出**：PM 商用评审结果（PM Commercial Review Result），包含逐项通过/失败状态、spec-code 覆盖矩阵和改进建议。
- **执行阶段**：PM Commercial Review。
- **角色约束**：仅 Product 角色可执行，禁止开发者或 UX 角色代执行。
- **并行关系**：与 FR-06c UX Acceptance 并行执行，两者均通过后方可进入 Regression。
- **验收标准**：
  - AC-4.24v：Smoke Test 通过后，PipelineEngine 自动推进到 PM Commercial Review 阶段，无需主会话人肉触发。
  - AC-4.24w：PM 评审覆盖陌生用户开箱即用验证、spec-code 一致性、README 营销质量三个维度。
  - AC-4.24x：PM 评审失败时阻断进入 Regression，结果中列出失败项和修复建议。
  - AC-4.24y：产出工件记录 authorRole 为 product，可追溯到执行角色。

### FR-07 Regression

- **输入**：通过 Review 的实现包、FR-02a 产出的测试用例文档。
- **处理**：执行回归检查，确认新增改动没有破坏既有功能、关键路径和基础约束。
- **输出**：回归包（Regression Bundle）。
- **执行阶段**：Regression。
- **审查阶段**：Regression Review（审查回归结果完整性和覆盖度）。
- **验收标准**：
  - AC-4.25：关键路径有明确回归检查结果。
  - AC-4.26：已修问题附带防复发验证。
  - AC-4.27：回归失败时能定位到受影响范围。
  - AC-4.28：回归结果进入后续 Deploy 与 Verify 的判断依据。

### FR-08 Deploy

- **输入**：通过 Regression 的交付候选版本。
- **处理**：生成发布制品，绑定版本信息、发布说明和交付目标。
- **输出**：发布包（Release Artifact）。
- **执行阶段**：Deploy。
- **审查阶段**：Deploy Review（确认发布制品与架构方案一致、版本元数据完整）。
- **验收标准**：
  - AC-4.29：发布产物可识别版本、来源和适用范围。
  - AC-4.30：发布动作与对应 Spec、Contract、Review、Regression 结果可关联。
  - AC-4.31：发布失败不会污染已通过的候选版本。
  - AC-4.32：发布结果可被 Verify 阶段直接消费。

### FR-08a Commercialization Gate（商用化门禁）

- **定位**：Deploy 之前的强制阶段。当项目配置了发布目标（npm、GitHub、ClawHub）时自动触发，确保交付物达到商用级开源标准。
- **触发条件**：项目存在 `publishTarget` 配置，且目标为 npm、ClawHub、GitHub 之一时，在进入 Deploy 前自动触发。
- **核心原则**：GitHub 独立仓库推源码（开源可读、可构建），npm 推编译产物（开箱即用）。两条渠道并存，用户既能 `npm install` 直接用，也能 clone 源码自己 build。
- **输入**：交付候选版本、发布目标配置、项目源码目录、README.md、package.json、tsconfig.json。
- **处理**：按五层标准逐层检查，任一层不通过则阻断发布。

**第一层：代码清洁度**
  1. 无硬编码路径（`/root/`、`/home/`、`~/.openclaw/` 等内部路径）。
  2. 无内部引用（内部 agent 名称、内部 API 地址、内部配置键名）。
  3. 无调试残留（`console.log` 调试输出、TODO/FIXME/HACK 注释）。
  4. 无敏感信息（API key、token、密钥文件、.env 文件）。
  5. 依赖声明完整——package.json 的 dependencies 和 peerDependencies 覆盖所有 import，无遗漏无冗余。

**第二层：包完整性**
  6. package.json 必填字段完整：name、version、description、author、license、main/exports、bin（如有 CLI）。
  7. 入口文件指向存在的文件（main/exports/bin 指向的路径必须存在）。
  8. TypeScript 项目必须有 tsconfig.json，且 `npm run build` 能成功编译。
  9. .gitignore 排除编译产物（根目录 .js、dist/、node_modules/）。
  10. .npmignore 或 package.json files 字段正确配置，npm 包只包含编译产物 + 类型声明 + 文档。

**第三层：文档质量**
  11. README.md 存在且符合营销质量标准（tagline → 痛点 → 优势 → 快速体验 → 场景 → 文档链接）。
  12. README 同时引导两类用户：npm 用户（`npm install` 快速上手）和源码用户（clone → install → build）。
  13. 配置项有文档说明（环境变量、配置文件模板、CLI 参数）。
  14. CHANGELOG.md 或 GitHub Releases 记录版本变更。
  15. LICENSE 文件存在。

**第四层：可构建性**
  16. 在干净目录中 `git clone → npm install → npm run build` 能成功完成。
  17. `npm test` 能通过（如项目有测试）。
  18. CLI 项目：`npx <包名> --help` 能正常输出。

**第五层：开箱即用**
  19. `npm install <包名>` 能成功安装。
  20. 每个核心功能有可验证的首次使用路径，且产出有意义的结果（不是空壳）。
  21. 需要外部依赖（专用 API key、第三方服务）的功能，有明确的配置引导和错误提示。

- **输出**：商用化门禁结果（Commercialization Gate Result），包含五层检查的逐项通过/失败状态、具体失败原因、修复建议。
- **执行阶段**：Commercialization Gate（Deploy 前阶段）。
- **验收标准**：
  - AC-4.32a：存在 `publishTarget` 配置时，系统在 Deploy 前自动触发商用化门禁，无需用户确认。
  - AC-4.32b：系统执行全部五层检查，不允许只做部分检查。
  - AC-4.32c：任一检查项不通过时，发布被阻断，结果中明确列出具体失败原因和修复建议。
  - AC-4.32d：用户可选择跳过该阶段，跳过决定写入 ledger，标注"用户主动跳过商用化门禁"。
  - AC-4.32e：不存在 `publishTarget` 配置时，该阶段完全不出现，不影响 Deploy 流程。
  - AC-4.32f：发布目标包含 GitHub 独立仓库时，门禁自动执行独立仓库同步——推送源码（排除编译产物），推送前排除 .gitignore 中定义的文件。
  - AC-4.32g：推送独立仓库前，扫描待推送文件中是否包含敏感内容（.env、API key、密钥文件、内部配置），发现则阻断推送并报告。
  - AC-4.32h：npm publish 和独立仓库同步作为原子操作执行——任一步骤失败则整体回滚。
  - AC-4.32i：GitHub 独立仓库只推源码（TypeScript），编译产物由 .gitignore 排除；npm 包只推编译产物 + 类型声明 + 文档。
  - AC-4.32j：第四层可构建性检查在干净临时目录中执行（模拟陌生用户环境），不依赖开发现场。
  - AC-4.32k：门禁结果包含五层检查的逐项状态，支持增量修复（修复后只重跑失败项，不重跑已通过项）。


### FR-09 Verify

- **输入**：发布包。
- **处理**：在独立、清洁或最小依赖环境中验证功能、关键 NFR 和交付可用性。
- **输出**：验证包（Verification Bundle）。
- **执行阶段**：Verify（独立环境验证，与 Implement 阶段执行者分离）。
- **审查阶段**：Verify Review（确认核心用户路径和交付可用性达标）。
- **验收标准**：
  - AC-4.33：验证环境不依赖开发现场残留。
  - AC-4.34：验证覆盖核心用户路径和关键非功能指标。
  - AC-4.35：验证结论可明确区分可交付与不可交付。
  - AC-4.36：验证失败会阻断 Ledger 的通过结论。

### FR-10 Ledger

- **输入**：FR 流程实例 ID、Spec Package、Spec Review Bundle、Contract Package、Contract Review Bundle、Implementation Bundle、Review Bundle、Regression Bundle、Release Artifact、Verification Bundle。
- **处理**：生成交付记录，串起版本、日期、范围、证据、问题、结论和经验沉淀。每条 Ledger Entry 必须关联到对应的 FR 流程实例 ID。
- **输出**：交付账本条目（Ledger Entry）。
- **执行阶段**：Ledger（系统自动汇总）。
- **审查阶段**：Ledger Review，产品维度（确认交付范围和结论准确）和架构维度（确认证据链完整和经验沉淀质量）。
- **验收标准**：
  - AC-4.37：账本条目能追溯到本轮所有关键工件。
  - AC-4.38：账本记录交付结论、责任边界和后续动作。
  - AC-4.39：经验沉淀可被后续任务复用。
  - AC-4.40：没有 Ledger Entry 的交付不算流程闭环。

### FR-11 Proactive Clarification

- **定位**：跨阶段机制。在 Spec、Contract、Implement 三个阶段内建模糊检测与主动澄清能力，确保歧义在产生阶段就地消解，而非流入下游造成返工。
- **触发条件**：任一阶段执行过程中，检测到以下模糊信号之一即触发澄清流程：
  - 验收标准缺失或不可验证。
  - 边界条件未定义（输入范围、异常路径、并发场景）。
  - 术语首次出现但未给出定义。
  - 依赖未声明（上游工件、外部服务、运行时假设）。
  - 接口契约不完整（参数、返回值、错误码缺失）。
  - 数据流向不明（谁产出、谁消费、格式是什么）。
  - 性能或资源约束缺失（超时、并发上限、存储配额）。
  - Spec 与 Contract 之间存在矛盾或不一致。
- **澄清类型分类**：每个澄清问题必须标注类型，便于收敛后按知识类型沉淀：
  - 纠偏（correction）：已有描述与事实或意图不符。
  - 方法（methodology）：如何做、用什么方法。
  - 决策（decision）：多个可选方案需要取舍。
  - 边界（boundary）：范围、限制、不做什么。
  - 经验（experience）：历史教训、已知陷阱。
  - 元认知（meta）：关于流程本身的反思。

#### FR-11.1 Spec 阶段澄清

- **输入**：正在编写或已产出的 Spec Package。
- **处理**：
  1. 扫描 Spec 内容，检测模糊信号（验收标准缺失、边界未定义、术语未解释、依赖未声明）。
  2. 对每个模糊点生成结构化澄清问题，包含：问题描述、模糊类型、影响范围、建议选项（如有）。
  3. 将澄清问题提交给需求来源方（用户或上游 Agent）。
  4. 收到澄清回复后，将收敛结论写回 Spec Package 对应位置。
- **输出**：澄清记录（Clarification Record）+ 更新后的 Spec Package。
- **验收标准**：
  - AC-4.41：Spec 产出前，所有被检测到的模糊点都已生成澄清问题或标注为已知风险。
  - AC-4.42：澄清问题包含类型标签、影响范围和上下文引用，不是孤立提问。
  - AC-4.43：澄清收敛后的结论直接写入 Spec Package，不留在对话或临时文件中。
  - AC-4.44：澄清收敛结论按知识类型沉淀（纠偏→事实、决策→ADR 候选、边界→约束条件、方法→方法论记录、经验→experience 知识（沉淀到经验库 / lessons learned）、元认知→meta 知识（沉淀到方法论 / 流程改进建议））。

#### FR-11.2 Contract 阶段澄清

- **输入**：正在编写或已产出的 Contract Package、关联的 Spec Package。
- **处理**：
  1. 扫描技术方案，检测模糊信号（接口未定义、数据流不明、性能约束缺失、模块职责重叠）。
  2. 对每个模糊点生成结构化澄清问题。
  3. 区分澄清对象：技术层面的模糊由架构阶段内部消解；需求层面的模糊上报给 Spec 来源方。
  4. 收到澄清回复后，将技术决策写入 ADR，将需求澄清回写 Spec Package。
- **输出**：澄清记录 + 更新后的 Contract Package + 相关 ADR。
- **验收标准**：
  - AC-4.45：Contract 产出前，所有被检测到的技术模糊点都已澄清或记录为待定风险。
  - AC-4.46：需求层面的模糊上报给 Spec 来源方，不由架构阶段单方面假设。
  - AC-4.47：技术决策类澄清收敛后写入 ADR，包含替代方案和取舍理由。
  - AC-4.48：Spec 与 Contract 之间的矛盾在此阶段被检测并消解，不流入 Implement。

#### FR-11.3 Implement 阶段澄清

- **输入**：Contract Package、Work Package、Task 描述。
- **处理**：
  1. 执行前检查 Task 描述完整性（目标文件、预期变更、验证步骤是否齐全）。
  2. 执行过程中发现 Spec/Contract 矛盾或未覆盖场景时，暂停实现并上报。
  3. 生成结构化澄清问题，标注阻断级别（blocking：必须等回复才能继续；non-blocking：可先按默认假设推进，但需确认）。
  4. 收到澄清回复后，更新 Task 描述或回写上游工件。
- **输出**：澄清记录 + 更新后的 Task 描述（或上游工件修正请求）。
- **验收标准**：
  - AC-4.49：Task 描述不完整时，执行者主动提问而非基于猜测开发。
  - AC-4.50：Spec/Contract 矛盾被发现时，实现暂停并上报，不自行决定以哪个为准。
  - AC-4.51：澄清问题标注阻断级别，blocking 类必须等回复，non-blocking 类可附默认假设先行。
  - AC-4.52：澄清结论回写到对应工件（Task 描述、Spec Package 或 Contract Package），不只留在执行日志中。

#### FR-11.4 实现路径

- 每个阶段的 Skill（specify/plan/implement）内置模糊检测逻辑，作为阶段执行的前置步骤或并行检查。
- 模糊检测规则可配置、可扩展，新增检测维度不需要改代码。
- 澄清流程通过阶段执行原则注入（参考 §6.6），绑定阶段而非 Agent 身份。
- 澄清记录作为阶段工件的一部分，纳入 Ledger 证据链。
- 验收标准：
  - AC-4.53：模糊检测规则可通过配置文件扩展，不需要修改 Skill 源码。
  - AC-4.54：澄清记录纳入 Ledger Entry 的证据链，可追溯每个澄清的触发点、问题、回复和收敛结论。
  - AC-4.55：澄清机制不依赖特定 Agent 身份，任何执行者进入对应阶段都自动获得澄清能力。

### FR-12 Pipeline Create

- **定位**：生命周期操作。研发流程的入口点，负责在用户已创建 Project、已添加 FR 之后，为该 FR 创建 FR 流程实例、初始化 Project 目录结构、生成路由结果。
- **输入**：任务描述、Project 标识（project-slug）、FR 描述、触发条件命中结果。
- **处理**：
  1. 校验 Project 标识合法性（命名规范、是否已存在）。
  2. 校验目标 FR 已被创建并归属到该 Project。
  3. 检查同一 Project 是否已有 active 的 FR 流程实例，有则拒绝创建。
  4. 生成实例 ID（格式见 §3.5）。
  5. 执行路由判定（§3.2），确定任务级别和必经阶段。
  6. 检查 Project 目录结构，按 §3.6 规范初始化或补全。
  7. 创建 FR 流程实例记录，状态设为 created，并使该 FR 自动进入 Specify 阶段的流程准备态。
  8. 向 PipelineEngine（FR-13）发送 pipeline-created 事件，PipelineEngine 接管后续生命周期推进。
- **输出**：FR 流程实例（含 ID、Project 绑定、路由结果、目录结构确认）。
- **执行阶段**：Pipeline Create（研发流程入口，在第一个业务阶段之前执行）。
- **验收标准**：
  - AC-4.56：每个 FR 流程实例有全局唯一 ID，格式符合 `fr-<project-slug>-<yyyyMMdd>-<seq>` 规范。
  - AC-4.57：同一 Project 已有 active 实例时，创建请求被拒绝并返回明确错误信息。
  - AC-4.58：创建完成后，Project 目录结构符合 §3.6 规范，缺失目录已补全。
  - AC-4.59：路由结果包含任务级别、必经阶段、可跳过阶段及跳过理由。
  - AC-4.60：已有 Project 目录的内容不被覆盖，只补全缺失的子目录。
  - AC-4.61：pipeline 创建完成后，PipelineEngine 自动接管并通过宿主 Adapter 触发第一个阶段的执行，用户不需要手动触发。

### FR-13 PipelineEngine（流程编排引擎）

- **定位**：SEVO 的核心运行时引擎。负责 pipeline 实例创建后的全生命周期推进——通过状态机驱动阶段流转，借助宿主 Adapter 触发阶段执行，监听阶段完成事件，评估门禁条件，决定推进或阻断。PipelineEngine 定义的是编排语义（何时推进、何时阻断、何时重试），具体的任务派发方式由宿主 Adapter 实现。
- **编排模型**：PipelineEngine 不直接调度任务。在 OpenClaw 宿主中，它通过 hook 注入 + prompt 引导的方式工作：`before_prompt_build` hook 向主会话注入「下一步该派发什么任务」的指令，主会话仍然是调度者，PipelineEngine 提供编排决策。`subagent_ended` hook 监听任务完成事件，更新 pipeline 状态，设置下一阶段的推进指令。其他宿主通过 Adapter 接口实现等效能力。
- **角色知识内置**：PipelineEngine 在派发阶段任务时，自动注入该阶段应遵循的专业标准（§6.6）。Specify 阶段注入 PM 标准的 prompt 模板和质量门禁，Review 阶段注入审计标准，Contract 阶段注入架构设计原则。单 Agent 用户也能产出专业质量的工件，多 Agent 环境有专职角色则效果更好。
- **输入**：FR-12 创建的 FR 流程实例（含路由结果、阶段队列）。
- **处理**：
  1. 接收 pipeline-created 事件，读取路由结果中的阶段队列，生成 Stage Queue。
  2. 按 Stage Queue 顺序，通过宿主 Adapter 触发当前阶段的执行。
  3. 监听阶段完成事件。
  4. 阶段完成后，自动评估该阶段的出口条件（工件是否齐全、门禁是否通过）。
  5. 出口条件满足 → 自动推进到下一阶段 → 重复步骤 2。
  6. 出口条件不满足（门禁失败）→ 自动触发 Review Fix Loop（FR-06a）→ 修复完成后重新评估。
  7. 支持并行阶段（如 FR-02a/FR-02b/FR-02c 与 FR-03 并行；FR-06c 与 FR-06d 并行）。
  8. 所有阶段完成 → Ledger 自动生成 → pipeline 实例状态变为 completed。
  9. 启动时扫描持久化状态文件，检测中断的 pipeline（Gateway 重启、主会话中断、系统 OOM），自动恢复到最后已知状态并继续推进。
  10. 多个 pipeline 竞争同一角色的 Agent 时，按先到先服务排队，不阻塞其他不竞争的阶段。用户可通过配置指定优先级。
- **输出**：pipeline 实例的完整生命周期推进记录，包含每个阶段的触发时间、完成时间、门禁结果、推进决策。
- **验收标准**：
  - AC-13.1：pipeline 创建后，PipelineEngine 在无人工干预的情况下自动通过宿主 Adapter 触发第一个阶段的执行。
  - AC-13.2：每个阶段完成后，PipelineEngine 在 30 秒内评估门禁并决定推进或阻断。
  - AC-13.3：门禁失败时，PipelineEngine 自动触发修复流程（FR-06a），修复通过后自动恢复推进。
  - AC-13.4：并行阶段（如 UX Acceptance + PM Commercial Review）同时触发，两者均通过后才推进到下一阶段。
  - AC-13.5：pipeline 推进的每一步决策（推进/阻断/重试）都有结构化记录，可在驾驶舱查看。
  - AC-13.6：PipelineEngine 的编排语义与具体宿主环境解耦——它定义「何时推进、何时阻断」，具体的任务触发方式由宿主 Adapter 实现。
  - AC-13.7：用户可以在任意时刻查询 pipeline 当前状态：走到哪个阶段、卡在哪里、下一步是什么。
  - AC-13.8：Gateway 重启后，中断的 pipeline 在 60 秒内自动恢复推进，不需要用户手动干预。
  - AC-13.9：多个 pipeline 竞争同一角色的 Agent 时，按优先级排队，不阻塞其他不竞争的阶段。

### FR-14 Package Distribution & CLI（包分发、初始化与命令行界面）

- **定位**：SEVO 的安装入口和用户交互界面。负责 npm 包分发、CLI 入口、初始化命令、插件自动注册、环境健康检查，以及 Project 管理、FR 管理、Pipeline 状态查询和手动干预的全部命令行操作。
- **包名**：`sevo-pipeline`（已发布的 npm 包名）。
- **包结构**：单包双入口——`dist/` 提供库 API（PipelineEngine、GateEngine、LedgerEngine、Adapter 等），`plugin/` 提供 OpenClaw 插件入口（register + hooks），`bin/` 提供 CLI 入口。
- **输入**：用户执行 `npm install -g sevo-pipeline` 和 CLI 命令。
- **处理**：
  1. npm 包包含 SEVO 核心库 + CLI 入口 + 内置 OpenClaw 插件。
  2. `sevo init` 执行环境检测：检测宿主环境类型（OpenClaw / 独立运行 / 其他 ACP harness）→ 生成默认配置 → 在 OpenClaw 环境中自动注册插件到 `openclaw.json` → 动态发现 Agent 并按命名规则 + runtime type 自动分类角色 → 单 Agent 环境自动启用降级模式 → 执行 doctor 检查 → 输出角色分配表和下一步指引。
  3. `sevo doctor` 检查配置完整性和环境就绪状态，每个问题附带修复建议。
  4. `sevo project create <name> [--description <desc>]` 创建 Project。
  5. `sevo project list` 列出所有 Project。
  6. `sevo fr add <project> <description>` 向 Project 添加 FR，自动触发 pipeline 创建。
  7. `sevo fr list <project>` 列出 Project 下所有 FR 及其 pipeline 状态。
  8. `sevo status [<instance-id>]` 查看 pipeline 当前状态。
  9. `sevo pause <instance-id>` 暂停 pipeline。
  10. `sevo resume <instance-id>` 恢复 pipeline。
  11. `sevo cancel <instance-id>` 取消 pipeline，状态设为 failed，取消原因记录到 Ledger。
  12. `sevo ledger [<project>]` 查看交付账本。
- **输出**：可用的 SEVO 运行环境 + 配置文件 + 插件注册 + CLI 交互能力。
- **验收标准**：
  - AC-14.1：陌生用户执行 `npm install -g sevo-pipeline` + `npx sevo init` 后，5 分钟内能创建第一个 Project 并启动第一条 pipeline。
  - AC-14.2：`sevo init` 自动检测宿主环境类型，不需要用户手动指定。
  - AC-14.3：在 OpenClaw 环境中，`sevo init` 自动注册 SEVO 插件，用户不需要手动编辑 `openclaw.json`。
  - AC-14.4：`sevo init` 生成的默认配置足以跑通完整流水线（L0 级别），不需要额外配置。
  - AC-14.5：`sevo doctor` 能检测并报告所有配置问题，每个问题附带修复建议。
  - AC-14.6：`sevo --help` 输出所有可用命令，每个命令有一句话说明。
  - AC-14.7：`sevo project create` + `sevo fr add` 后，pipeline 自动创建并开始推进，用户不需要额外操作。
  - AC-14.8：`sevo status` 能在任意时刻回答「当前走到哪了、卡在哪里、下一步是什么」。
  - AC-14.9：所有命令的错误提示可理解、可操作（告诉用户怎么修，不只是报错码）。
  - AC-14.10：CLI 不依赖特定宿主环境，在纯 Node.js 环境中可运行。
  - AC-14.11：`sevo init` 检测到 OpenClaw 未安装时，错误提示包含 OpenClaw 安装链接。
  - AC-14.12：当自动分类无法识别任何 Agent 的角色时，`sevo init` 进入交互式角色分配模式，引导用户手动指定至少一个编码角色和一个审查角色。

### FR-15 Progressive Disclosure（渐进式披露配置）

- **定位**：SEVO 的配置与定制分层模型。定义四个披露级别，用户按需逐级解锁更多控制能力。
- **处理**：

**L0 安装即用**（由 FR-14 保证）：
- `sevo init` 后零配置可用。默认阶段定义、默认门禁规则、默认路由策略、角色专业标准全部内置。
- 用户只需要 `sevo project create <name>` + `sevo fr add <project> <description>` 就能启动 pipeline。
- 单 Agent 环境自动降级：所有角色池填入同一个 agentId，流水线所有阶段由同一个 Agent 执行，质量保证降级但功能完整。
- 对未经编排的开发任务的默认处理策略为 `guide`（注入流程引导），不阻断执行。

**L1 按需配置**：
- 用户可以在配置中调整：
  - 默认路由级别阈值（多少行算 Level 1、多少行算 Level 2+）。
  - 门禁严格度（严格/标准/宽松）。
  - 通知渠道偏好。
  - 发布目标（npm / GitHub / ClawHub）。
  - 合规模式（`guide` 注入流程引导 / `auto-route` 自动为未编排的开发任务创建 pipeline 并路由进 SEVO 流程 / `off` 关闭）。

**L2 自定义阶段**：
- 用户可以添加自定义阶段（如 Security Audit、Performance Test）。
- 用户可以修改阶段顺序（在约束范围内）。
- 用户可以定义自定义门禁规则。

**L3 编程控制**：
- 用户可以通过 API 或 SDK 编程控制 pipeline 行为。
- 支持自定义 Adapter（对接非 OpenClaw 宿主）。
- 支持自定义阶段执行器（替换默认的 Skill 执行）。

- **验收标准**：
  - AC-15.1：L0 级别下，用户不需要编辑任何配置文件就能跑通完整 pipeline。
  - AC-15.2：L1 级别的配置项有完整的文档说明和默认值，修改任一配置不会破坏 pipeline 运行。
  - AC-15.3：L2 级别的自定义阶段可以插入到标准阶段序列中，且不破坏工件链和门禁逻辑。
  - AC-15.4：L3 级别的 API 覆盖 pipeline 创建、阶段查询、门禁覆写、工件读取等核心操作。
  - AC-15.5：每个级别的能力是累加的——L1 包含 L0 的全部能力，L2 包含 L1 的全部能力，以此类推。
  - AC-15.6：用户从 L0 升级到 L1 不需要重新初始化，只需编辑配置文件。

### FR-16 Onboarding Experience（开箱体验）

- **定位**：陌生用户的首次使用旅程设计。确保从 `npm install` 到「看到第一条 pipeline 跑完」的路径畅通、有意义。
- **处理**：
  1. 安装后首次运行 `sevo init`，输出欢迎信息 + 环境检测结果 + 下一步指引。
  2. 提供 `sevo demo` 命令，分两层验证：
     - `sevo demo --dry-run`：展示 pipeline 阶段流转和工件结构，用 mock 数据，不需要 LLM，验证安装正确性。
     - `sevo demo`：在有 LLM 的环境中用内置示例项目跑一条真实的 Level 0 pipeline，验证端到端可用性。
  3. demo 完成后，输出「你刚刚看到了什么」的解释 + 「如何用自己的项目」的指引。
- **验收标准**：
  - AC-16.1：陌生用户从 `npm install` 到看到第一条 pipeline 完整跑完，耗时不超过 5 分钟。
  - AC-16.2：`sevo demo --dry-run` 在无网络、无 LLM 的条件下能跑通，产出有意义的示例工件结构。
  - AC-16.3：`sevo demo` 在有 LLM 的环境中用内置示例项目跑通一条真实 Level 0 pipeline。
  - AC-16.4：demo 完成后的输出包含「你刚刚经历了什么」的解释和「下一步做什么」的指引。
  - AC-16.5：首次使用路径中的每一步都有明确的成功/失败反馈，失败时告诉用户怎么修。

### FR-17 Post-Release Validation Gate（发布后验证门禁）

- **定位**：发布完成不等于产品可用。此阶段在 Deploy/Verify 之后、Ledger 之前自动执行终局差距扫描，逐条对照 spec FR 检查产品在真实环境中是否运行并产出价值。
- **处理**：
  1. npm publish / deploy 成功后，自动触发 Post-Release Validation 阶段。
  2. 差距扫描逐条对照 spec 中所有 FR，对每条 FR 检查三个维度：代码实现了？运行态跑起来了？陌生人能用？
  3. 每条 FR 产出三种状态之一：covered（全部通过）、code-only（有代码无运行态验证）、missing（完全缺失）。
  4. 发现差距时自动生成修复任务列表，包含 FR 编号和修复描述。
  5. 差距为零才允许流水线进入 Ledger 阶段标记为 completed。
- **验收标准**：
  - AC-17.1：npm publish 成功后，流水线自动进入 post-release-validation 阶段，无需人工触发。
  - AC-17.2：差距扫描逐条对照 spec FR，输出结构化 gap analysis report，包含 totalFrs、coveredCount、codeOnlyCount、missingCount、gaps 和逐条 entries。
  - AC-17.3：发现差距（gaps > 0）时，自动生成修复任务列表（fixTasks），每条包含 frId 和 description。
  - AC-17.4：差距为零（gaps === 0）时 canComplete 为 true，流水线可进入 Ledger 阶段；差距不为零时 canComplete 为 false，流水线阻塞。
  - AC-17.5：L1/L2+ 流水线包含 post-release-validation 阶段；L0 微小改动跳过此阶段。

### FR-18 目标驱动 PDCA 闭环

- **定位**：Pipeline 级别的目标管理机制。将 OKR→SMART→PDCA 融入现有流水线阶段，为每条 pipeline 提供终局目标锁定、目标拆解、目标对齐检查和差距驱动回环能力。所有新增能力向后兼容——未传入 endStateGoal 时，pipeline 行为与现有逻辑完全一致。
- **数据结构**：
  - `EndStateGoal { description: string; lockedAt: string }` — 终局目标描述 + 锁定时间戳。
  - `KeyResult { krId: string; description: string; measure: string; threshold?: string; status: 'not-started' | 'in-progress' | 'achieved' | 'blocked' }` — 单个关键结果。
  - `ObjectiveKeyResult { objectiveId: string; description: string; keyResults: KeyResult[] }` — 目标 + 关键结果树。
  - `PdcaCycleRecord { cycle: number; triggeredBy: string[]; newTasks: string[]; result: 'converged' | 'gap-remaining' | 'escalated' }` — 单轮 PDCA 记录。
  - `PipelineInstance` 新增可选字段：`endStateGoal?: EndStateGoal; okrTree?: ObjectiveKeyResult[]; pdcaCycles?: PdcaCycleRecord[]`。
  - `PipelineCreateRequest` 新增可选字段：`endStateGoal?: EndStateGoal`。
  - `FunctionalRequirement` 新增可选字段：`tracesTo?: string`（KR 标识符）。
- **输入**：Pipeline 创建时的 endStateGoal（可选）、Spec 阶段的 FR 列表、各 Gate 的评估结果、Post-Release Validation 的差距分析结果。
- **处理**：
  1. Pipeline 创建时（FR-12），接受可选的 endStateGoal 参数。未传入时，SEVO 生成引导提示帮助用户澄清终局目标。目标一旦锁定，写入 pipeline 实例元数据，后续修改需显式操作并记录变更理由。
  2. Spec 阶段（FR-01），若 pipeline 存在 endStateGoal，从目标拆解为 Objective + Key Results（OKR 树）。每个 KR 有明确的度量标准和达成阈值。FR 从 KR 反推，每个 FR 带 tracesTo 字段溯源到对应 KR。
  3. Spec 阶段，每个 FR/AC 按 SMART 原则（具体、可度量、可达成、相关、有时限）编写。Spec Review Gate（FR-02）增加 SMART 合规性检查维度。
  4. 各 Gate 评估时（FR-02、FR-04、FR-06），若 pipeline 存在 OKR 树，额外检查当前阶段产出是否在向终局目标收敛。目标对齐检查作为可选增强维度，不改变现有 Gate 的通过/阻断逻辑。
  5. Post-Release Validation（FR-17），若 pipeline 存在 OKR 树，差距分析升级为 KR 级——按 KR 逐条检查达成度，canComplete 判定基于 KR 达成情况。无 OKR 树时 fallback 到现有 FR 级扫描。
  6. Post-Release Validation 发现 KR 级差距（gaps > 0）时，pipeline 不进入 Ledger。Post-Release Validation 阶段内部生成新工作包（针对未达成 KR 的 SMART 任务），触发 Implement→Review→Deploy→Validate 子循环。子循环在 Post-Release Validation 内部管理，不回退 pipeline 主状态机。循环直到所有 KR 达成或达到最大轮次上限。
  7. `sevo demo` 展示完整闭环：目标锁定 → OKR 拆解 → SMART 任务化 → 阶段执行（Do）→ 差距扫描（Check）→ 回环修复（Act）→ 收敛完成。
- **输出**：OKR 树（OKR Tree，挂接到 pipeline 实例元数据）、KR 级差距分析报告（KR Gap Analysis Report）、PDCA 轮次记录（PDCA Cycle Record）。
- **执行阶段**：跨阶段机制，融入 Pipeline Create、Spec、Gate、Post-Release Validation 和 PipelineEngine 的现有流程中。
- **验收标准**：
  - AC-18.1：Pipeline 创建时（FR-12）支持可选的 endStateGoal 参数。传入时写入 pipeline 实例元数据；未传入时 SEVO 输出引导提示，pipeline 正常创建，后续阶段按现有逻辑执行。
  - AC-18.2：endStateGoal 锁定后，修改需通过显式操作（如 `sevo goal update <instance-id>`），变更理由写入 pipeline 元数据的变更日志。
  - AC-18.3：Spec 阶段存在 endStateGoal 时，系统从目标拆解为 Objective + Key Results，每个 KR 包含度量标准（metric）和达成阈值（threshold）。
  - AC-18.4：OKR 树中的每个 FR 带 tracesTo 字段，值为对应 KR 的标识符，溯源链完整可查。
  - AC-18.5：Spec 阶段产出的每个 FR/AC 满足 SMART 原则——具体（指向明确行为或产出）、可度量（有量化或可验证的标准）、可达成（在当前资源和约束下可实现）、相关（溯源到 KR 或 endStateGoal）、有时限（有预期完成的阶段或轮次）。
  - AC-18.6：Spec Review Gate（FR-02）在存在 OKR 树时，评审维度增加 SMART 合规性检查。不合规的 FR/AC 作为评审问题记录，严重级别为 P1。
  - AC-18.7：各 Gate（FR-02、FR-04、FR-06）在存在 OKR 树时，评估结论中增加目标对齐度评价（aligned / drifting / misaligned），作为参考信息附加到评审包中，不改变现有通过/阻断判定逻辑。
  - AC-18.8：Post-Release Validation（FR-17）在存在 OKR 树时，差距分析按 KR 逐条执行，每条 KR 产出达成状态（achieved / partially / not-achieved）和达成度百分比。
  - AC-18.9：Post-Release Validation 的 canComplete 判定在存在 OKR 树时升级为 KR 级——所有 KR 达成时 canComplete 为 true；任一 KR 未达成时 canComplete 为 false。无 OKR 树时 fallback 到现有 FR 级扫描逻辑，行为不变。
  - AC-18.10：canComplete 为 false 且存在 OKR 树时，Post-Release Validation 阶段内生成新工作包（针对未达成的 KR 的 SMART 任务），触发一轮 Implement→Review→Deploy→Validate 子循环。子循环在 Post-Release Validation 阶段内部管理，不回退 pipeline 主状态机，避免侵入 PipelineEngine 的单向推进逻辑。
  - AC-18.11：PDCA 循环有最大轮次上限（默认 3 轮，可通过 pipeline 创建参数或项目配置覆盖），超限后升级为人工介入，防止无限循环。每轮循环记录为 PdcaCycleRecord，包含轮次编号、触发原因（未达成的 KR 列表）、新增任务和轮次结果。
  - AC-18.12：`sevo demo` 在有 LLM 的环境中展示完整 PDCA 闭环——目标锁定 → OKR 拆解 → SMART 任务化 → 阶段执行 → 差距扫描 → 回环修复 → 收敛完成，用户可观察到至少一次回环过程。
  - AC-18.13：未传入 endStateGoal 的 pipeline，所有阶段行为与 FR-18 引入前完全一致——无 OKR 拆解、无 SMART 检查、无 KR 级差距分析、无 PDCA 回环。向后兼容零破坏。
  - AC-18.14：OKR 树、KR 达成度和 PDCA 轮次记录纳入 Ledger Entry 的证据链，可在驾驶舱和交付账本中查看。

### FR-19 终局交付自动推进（Endgame Delivery Automation）

- **定位**：Pipeline 级别的交付自动化机制。Review/Audit 通过后，自动推进 README 同步、版本管理、发布、终局差距扫描和用户通知，不需要用户手动触发。解决「代码是库不是引擎」的核心断点——阶段间推进从 prompt 软约束升级为程序化硬约束。
- **触发条件**：Pipeline 的 Review 阶段（FR-06）通过且所有验收阶段（FR-06b/06c/06d）通过后，自动进入终局交付链。
- **处理**：
  1. **README 同步**：检测项目 README 是否反映本次变更的新能力。如果 README 缺少新增 FR 的描述，自动生成 README 更新任务并派发。README 更新完成后进入下一步。
  2. **版本管理**：根据变更类型自动判定版本 bump 级别（patch：bug fix；minor：新功能；major：破坏性变更）。执行版本号 bump 并更新 package.json。
  3. **发布执行**：调用宿主环境的发布 Adapter（如 npm publish + GitHub 同步 + ClawHub 同步）。发布失败时自动重试一次，仍失败则通知用户并阻断。
  4. **终局差距扫描**：发布后自动触发 Post-Release Validation（FR-17）。以 spec 全部 FR 为基准逐条对照当前实现。发现差距时自动生成修复任务，进入 PDCA 子循环（FR-18）。
  5. **差距修复循环**：差距修复任务完成后，重新进入 Review→Audit→终局交付链，循环到差距为零。
  6. **用户通知**：每个关键节点（审计通过、发布成功、差距扫描结果、最终完成）自动通知用户。通知内容包含版本号、新功能摘要、发布链接、差距状态。
  7. **阶段间推进机制**：PluginAdapter 的 hook handler 在 subagent_ended 事件中程序化调用宿主 API 派发下一阶段任务，不依赖 prompt 注入。并行阶段通过 hook handler 一次性触发所有并行任务。
- **输出**：发布结果报告（Release Report，含版本号、平台链接、差距扫描结论）、用户通知记录。
- **执行阶段**：Review 通过后自动触发，贯穿 Deploy（FR-08）→ Verify（FR-09）→ Post-Release Validation（FR-17）→ Ledger（FR-10）。
- **验收标准**：
  - AC-19.1：Review 阶段（FR-06）所有子阶段通过后，Pipeline 自动进入终局交付链，不需要用户手动触发或主会话 prompt 驱动。
  - AC-19.2：终局交付链中，README 同步阶段检测 README 是否包含本次新增 FR 的描述。缺失时自动生成 README 更新任务；README 已包含时跳过。
  - AC-19.3：版本 bump 级别根据变更类型自动判定（patch/minor/major），执行 bump 并更新 package.json。判定规则可通过项目配置覆盖。
  - AC-19.4：发布阶段调用宿主环境的 PublishAdapter 执行发布。PublishAdapter 是接口，OpenClaw 宿主实现调用 publish-release.sh；独立运行模式输出发布指令到 stdout。
  - AC-19.5：发布失败时自动重试一次（间隔 30 秒）。重试仍失败时，Pipeline 状态设为 blocked，通知用户并附带错误信息。
  - AC-19.6：发布成功后自动触发 Post-Release Validation（FR-17），以 spec 全部 FR 为基准执行差距扫描。
  - AC-19.7：差距扫描发现未覆盖的 FR 时，自动生成修复工作包并触发 Implement→Review→终局交付 子循环。子循环复用 FR-18 的 PDCA 机制，共享最大轮次上限。
  - AC-19.8：终局交付链的每个关键节点（审计通过、README 更新完成、版本 bump 完成、发布成功/失败、差距扫描结果、最终完成）通过 NotificationAdapter 自动通知用户。
  - AC-19.9：NotificationAdapter 是接口。OpenClaw 宿主实现调用飞书 API 推送；独立运行模式输出通知内容到 stdout。通知渠道通过项目配置指定。
  - AC-19.10：阶段间推进通过 PluginAdapter 的 subagent_ended hook handler 程序化触发，不依赖 prompt 注入。hook handler 检测当前完成的阶段，调用 PipelineEngine.advance() 并通过宿主 API 派发下一阶段任务。
  - AC-19.11：并行阶段（如 Test Case + UX Acceptance + Commercial Acceptance）通过 hook handler 一次性触发所有并行任务。所有并行任务完成后，hook handler 自动触发汇合点的下一阶段。
  - AC-19.12：整条终局交付链可通过项目配置关闭或部分关闭（如关闭自动发布但保留差距扫描）。未配置时默认全部启用。
  - AC-19.13：单 Agent 用户（无专职 PM/UX/审计 Agent）也能走完整终局交付链。角色知识注入（FR-15 渐进式披露）确保单 Agent 在每个阶段获得对应角色的专业标准。
  - AC-19.14：终局交付链的所有操作记录纳入 Ledger Entry 的证据链，包含 README diff、版本变更、发布结果、差距扫描报告、通知记录。
  - AC-19.15：Publish 阶段完成后、终局差距扫描之前，必须执行 liveness verification。liveness verification 读取项目的 SMART 目标配置（`pdca-liveness-config.json`），逐条执行 probe。任何 P0 probe 失败时，Publish 阶段不通过，必须修复后重新验证；P1 probe 失败时记录为待办，不阻断发布。liveness verification 的结果写入终局差距扫描报告。


### FR-20 PDCA 自动 Check

- **定位**：跨阶段机制。为每个 SEVO 管理的项目提供基于 SMART 目标配置的自动化 liveness 检查能力。通过可扩展的 probe 函数库，定期或按需验证项目功能在运行时是否真正生效，弥补代码审计只检查逻辑正确性而不检查运行时行为的盲区。
- **输入**：项目的 SMART 目标配置文件（`pdca-liveness-config.json`）。
- **处理**：
  1. 读取项目根目录下的 `pdca-liveness-config.json`，解析 SMART 目标条目列表。
  2. 逐条执行 probe 命令，收集 PASS/FAIL 结果和失败原因。
  3. 输出标准化报告（JSON + 可读 markdown），包含每条目标的 goalId、描述、probe 命令、执行结果、失败原因。
  4. P0 失败时自动创建修复任务到看板。
  5. 支持 cron 定时执行和 CLI 手动触发。
- **输出**：PDCA Check 报告（PDCA Check Report），包含逐条 PASS/FAIL 结果、失败原因和自动创建的任务列表。
- **执行阶段**：跨阶段机制，可在 Post-Release Validation（FR-17）中被 Liveness Verification Gate（AC-19.15）调用，也可独立定时执行。
- **验收标准**：
  - AC-20.1：每个项目可在项目根目录定义 `pdca-liveness-config.json`，格式为 JSON 数组，每个条目包含 goalId（唯一标识）、description（目标描述）、metric（可度量指标）、probe（可执行的 shell 命令或内置函数名）、severity（P0/P1/P2）。
  - AC-20.2：PDCA Check 脚本读取配置后逐条执行 probe，每条 probe 输出标准化结果：goalId、status（PASS/FAIL）、reason（失败原因，PASS 时为空）、executedAt（执行时间戳）。汇总报告包含 totalGoals、passCount、failCount 和逐条 entries。
  - AC-20.3：PDCA Check 支持通过 cron 定时执行（建议每日 06:00），cron 配置在 `sevo init` 时自动注册，用户可通过 `sevo config` 修改执行频率或关闭。
  - AC-20.4：任何 severity 为 P0 的 probe 失败时，PDCA Check 自动通过看板 API（`local-subagent-board.js enqueue`）创建修复任务，任务描述包含 goalId、失败原因和关联的 FR 编号。
  - AC-20.5：probe 函数库内置以下检查函数，每个函数接受参数并返回 PASS/FAIL + reason：check_log_recent（检查日志文件最近 N 分钟内有新条目）、check_sqlite（执行 SQL 查询并验证结果非空或满足条件）、check_npm_version（验证 npm 包已发布且版本号匹配）、check_file_exists（验证文件存在且非空）、check_hook_registered（验证指定 hook 在宿主配置中已注册且 import 路径可解析）。函数库可通过在配置中指定自定义 shell 命令扩展，不需要修改 PDCA Check 源码。
  - AC-20.6：新项目接入 PDCA Check 只需在项目根目录创建 `pdca-liveness-config.json` 并添加条目，不需要修改 PDCA Check 脚本或注册额外配置。

### FR-21 SMART 目标声明

- **定位**：Specify 阶段的强制质量门禁增强。要求每个 SEVO 管理的项目在 Specify 阶段声明 SMART 目标，并将目标与 FR 和 liveness probe 关联，确保每个功能需求都有可度量、可自动验证的终局验收标准。
- **输入**：项目的需求规格包（Spec Package）。
- **处理**：
  1. Specify 阶段产出 Spec Package 时，同步产出或更新项目的 SMART 目标声明。
  2. 每个 SMART 目标关联到一个或多个 FR，每个 FR 至少关联一个可度量的 liveness probe。
  3. SMART 目标在 Publish 阶段被 Liveness Verification Gate（AC-19.15）消费，驱动 PDCA Check（FR-20）执行。
  4. Spec Review Gate（FR-02）增加 SMART 目标完整性检查维度。
- **输出**：SMART 目标声明文档（作为 Spec Package 的组成部分）+ 项目的 `pdca-liveness-config.json` 初始版本。
- **执行阶段**：Specify 阶段内嵌，与 FR-01 Spec 同步执行。
- **验收标准**：
  - AC-21.1：每个 SEVO 管理的项目在 Specify 阶段必须声明 SMART 目标。每个目标包含五个维度：Specific（指向明确的功能行为或产出）、Measurable（有量化或可自动验证的指标）、Achievable（在当前资源和约束下可实现）、Relevant（溯源到项目的 endStateGoal 或 OKR 树中的 KR）、Time-bound（有预期完成的阶段或时间点）。
  - AC-21.2：每个 FR 至少关联一个可度量的 liveness probe。probe 定义写入 `pdca-liveness-config.json`，包含 goalId、关联的 FR 编号、probe 命令和预期结果。FR 与 probe 的关联关系在 Spec Package 中可追溯。
  - AC-21.3：SMART 目标在 Publish 阶段被 Liveness Verification Gate（AC-19.15）消费。Liveness Verification Gate 读取 `pdca-liveness-config.json`，调用 PDCA Check（FR-20）逐条执行 probe，根据结果决定 Publish 是否通过。
  - AC-21.4：缺少 SMART 目标的项目，Spec Review Gate（FR-02）增加一条检查维度——SMART 目标完整性。检查项包括：是否存在 SMART 目标声明、每个 FR 是否关联了 probe、probe 定义是否完整。任一检查不通过时，作为 P1 问题记录到 Spec Review Bundle，阻断进入 Contract 阶段。

### FR-22 角色-任务匹配调度约束（Role-Task Dispatch Constraint）

- **定位**：跨阶段机制。流水线每个阶段有明确的角色要求，调度器在派发阶段任务前必须校验目标 Agent 的角色标签是否匹配阶段要求，防止角色越权导致产出质量不达标。
- **角色-阶段映射（默认）**：
  - Specify（FR-01）、Spec Review Gate（FR-02）、Commercial Acceptance Authoring（FR-02c）、PM Commercial Review（FR-06d）→ Product 角色
  - UX Acceptance Authoring（FR-02b）、UX Acceptance（FR-06c）→ UX 角色
  - Contract（FR-03）、Contract Review Gate（FR-04，开发维度）→ Architect 角色
  - Implement（FR-05）、Smoke Test（FR-06b）→ Coder 角色
  - Review（FR-06）、Regression（FR-07）→ Auditor 角色
  - Deploy（FR-08）、Verify（FR-09）、Ledger（FR-10）→ 任意角色（系统自动执行或可配置）
- **输入**：阶段任务的派发请求（含目标阶段、候选 agentId）、Agent 角色注册表。
- **处理**：
  1. PipelineEngine 在通过宿主 Adapter 触发阶段执行前，查询 Agent 角色注册表，获取候选 Agent 的角色标签。
  2. 比对候选 Agent 的角色标签与当前阶段的角色要求。
  3. 角色匹配 → 正常派发。
  4. 角色不匹配 → 生成审计事件（包含阶段名、要求角色、实际角色、agentId），记录到调度审计日志。多 Agent 环境下阻断派发并提示选择正确角色的 Agent；单 Agent 环境下降级为警告，允许派发但在审计日志中标注"角色降级"。
  5. Agent 角色注册表在 `sevo init` 时自动生成（基于 Agent 命名规则和 runtime type 推断），用户可通过配置文件手动覆盖。
- **输出**：角色校验结果（通过/警告/阻断）、审计事件记录。
- **执行阶段**：跨阶段机制，嵌入 PipelineEngine（FR-13）的阶段派发逻辑中。
- **验收标准**：
  - AC-22.1：每个流水线阶段在 Stage 定义中声明所需的角色类型（requiredRole），角色类型为枚举值：product、ux、architect、coder、auditor、any。
  - AC-22.2：PipelineEngine 在派发阶段任务前，自动校验候选 Agent 的角色标签是否匹配阶段的 requiredRole。校验逻辑在宿主 Adapter 触发执行之前执行。
  - AC-22.3：角色不匹配时，系统生成结构化审计事件，包含字段：timestamp、pipelineInstanceId、stageName、requiredRole、actualRole、agentId、action（blocked/warned）。审计事件写入调度审计日志。
  - AC-22.4：多 Agent 环境下（Agent 池中存在匹配角色的 Agent），角色不匹配时阻断派发，返回错误信息并建议使用匹配角色的 Agent。
  - AC-22.5：单 Agent 环境下（Agent 池中只有一个 Agent 或无匹配角色的 Agent），角色不匹配时降级为警告，允许派发，审计事件的 action 字段标注为 warned，日志中标注"角色降级：单 Agent 环境"。
  - AC-22.6：Agent 角色注册表支持两种来源：自动推断（`sevo init` 基于 Agent 命名规则和 runtime type 生成）和手动配置（用户在 SEVO 配置文件中显式指定 agentId → role 映射）。手动配置优先级高于自动推断。
  - AC-22.7：角色-阶段映射可通过 SEVO 配置文件自定义。用户可修改任意阶段的 requiredRole，新增自定义阶段时可指定角色要求。
  - AC-22.8：`sevo init` 产出的角色分配表（已有 AC-14.12）包含每个 Agent 的推断角色和每个阶段的角色要求，用户可在此确认或修改。

## 5. 非功能需求

### 5.1 性能

- NFR-5.1：任务进入流水线后的路由判定应在秒级完成，不能把主会话卡成长任务。
- NFR-5.2：阶段门禁检查默认优先脚本化与结构化检查，减少纯人工逐项核对。
- NFR-5.3：单个工作包的状态、工件、结论查询应能快速返回，便于调度和审计。
- NFR-5.4：长流程支持增量推进，单个阶段失败不要求整条流水线从头重跑。

### 5.2 可靠性

- NFR-5.5：每个阶段都有明确输入、输出和阻断条件，避免“状态不明”。
- NFR-5.6：完成判定不能依赖聊天回复，必须依赖文件、工件或可验证结果。
- NFR-5.7：长流程状态必须持久化，主会话中断不应导致整条流水线失忆。
- NFR-5.8：阶段失败后支持修复、复审、续跑，不要求手工重建全链路上下文。

### 5.3 可扩展性

- NFR-5.9：SEVO 的阶段定义、工件定义、门禁定义与具体运行时解耦。
- NFR-5.10：支持不同类型 Agent 接入同一流程，包括 ACP agent、原生 subagent、未来独立验证器。
- NFR-5.11：支持按任务级别裁剪流程，但不破坏统一工件语言。
- NFR-5.12：新阶段规则和新门禁可以增量追加，不要求重写整套流程。

### 5.4 安全性

- NFR-5.13：审计角色与开发角色职责分离，默认禁止自审。
- NFR-5.14：高风险改动在 Implement、Review、Verify 阶段都要有加厚检查。
- NFR-5.15：账本和审计工件必须保留关键证据，便于追责和复盘。
- NFR-5.16：核心流程能力必须通用化设计，可在任意宿主环境运行。宿主特有能力通过 Adapter 接入增强核心流程，但核心流程不因缺少某个特定宿主而断裂。高价值的治理机制（执行前检查、执行后验证、上下文注入、会话边界控制）属于 SEVO 内建能力，不是宿主私有依赖。
- NFR-5.17：受保护环境中的访问和关键操作必须可追溯到具体操作者，不能只有共享口令而无身份标识。

### 5.5 NFR 验收标准

- AC-5.1：任一阶段失败时，系统能明确回答失败位置、缺失工件和下一步动作。
- AC-5.2：任一完成结论都能找到对应文件或结构化证据。
- AC-5.3：更换执行 Agent 或宿主环境后，核心阶段语义不变。
- AC-5.4：审计、验证、账本三个阶段至少有一个独立于开发执行者。
- AC-5.5：受保护环境的登录与关键操作具备可追溯的操作者标识，支持审计追责。

### 5.6 Web 驾驶舱展示层验收标准

- AC-5.6（Web 层）：项目驾驶舱至少提供 Dashboard、Projects、FR 列表、待办队列、统计分析、交付物、通知中心、交付账本等稳定入口；导航引用的页面可直达，不允许出现 404、空白落地页或无效入口。
- AC-5.7（Web 层）：Projects 页面按项目展示 FR 完成进度、健康度和最近活动，并支持从项目视角钻取到对应 FR 列表或详情。
- AC-5.8（Web 层）：登录页把说明提示、错误反馈和输入控件做清晰区分；密码输入支持显示/隐藏；错误反馈有固定位置；页面提供获取访问权限的明确指引；移动端保留简短价值说明。
- AC-5.9（Web 层）：Dashboard 首屏优先展示失败项、阻塞项、待审批项或其他当前最危险对象，并支持一键钻取；风险提示使用红色或琥珀色语义；KPI 明确时间范围，并解释健康度、完成率等容易混淆指标的关系。
- AC-5.10（Web 层）：Dashboard 中的阶段分布、风险提示和关键指标卡片可钻取到对应对象列表；长内容区域提供明确的继续阅读或滚动提示。
- AC-5.11（Web 层）：FR 列表支持按项目、阶段、更新时间等维度搜索、筛选和排序，展示结果总数；时间信息使用中文习惯的绝对或相对格式；失败、阻塞状态的视觉优先级高于普通阶段标签。
- AC-5.12（Web 层）：FR 卡片默认只暴露状态、标题、阶段、更新时间和主动作；扩展说明按需展开；AI 判断文案依据当前阶段、风险和阻断原因生成，不能对不同 FR 大量重复模板化表述。
- AC-5.13（Web 层）：每条 FR 都有详情页，至少展示阶段历史、关联交付物、评审与复验记录、当前判断和下一步动作。
- AC-5.14（Web 层）：待办队列支持按类型、优先级和等待时长筛选排序，筛选项显示计数；门禁、澄清、失败三类待办有稳定且可快速识别的视觉区分；超时待办进入更强警示态。
- AC-5.15（Web 层）：待办、FR、通知等卡片型列表把主动作固定为明确按钮或整卡点击区域，避免动作入口与说明文案混淆。
- AC-5.16（Web 层）：统计分析页面在 0 异常或 0 失败时显示正向空状态，不以占位数据冒充真实结果；关键指标支持时间趋势、基准线或目标值对比；移动端优先展示风险结论和异常项目，并支持导出。
- AC-5.17（Web 层）：交付物页面优先帮助用户找到结果；移动端首屏先呈现命中结果或结果摘要，再呈现统计和高级筛选；预览区域展示真实文档摘要，不展示占位说明。
- AC-5.18（Web 层）：交付物、账本、FR、待办、通知等长列表在结果规模增长后仍可稳定浏览，必须提供分页或虚拟滚动，并展示总数与当前筛选命中数。
- AC-5.19（Web 层）：通知中心支持按级别筛选、未读计数、时间分组和全部已读；关键通知与普通信息在结构和颜色上有明显差异；下一步以简洁动作条呈现。
- AC-5.20（Web 层）：交付账本的筛选文案和状态标签对用户一眼可懂；证据链接可点击预览；次级说明默认折叠；界面不展示开发备注或内部说明；至少提供一种适合追踪时序演进的视图。
- AC-5.21（Web 层）：移动端 375px 宽度下，FR、待办、交付物、通知、账本等页面首屏优先露出首个可处理对象或主动作；筛选器、统计卡和长说明默认可折叠；不允许横向滚动。
- AC-5.22（Web 层）：状态、优先级、未读、阶段等标签在全站使用一致的颜色语义、视觉优先级和对比度；失败、阻塞、关键、未读的视觉权重高于普通信息。
- AC-5.23（Web 层）：图标按钮、顶部操作和筛选控件具备稳定的焦点态、清晰选中态、文本语义和键盘可达性；浅色标签与文字满足可读性要求。
- AC-5.24（Web 层）：驾驶舱提供全局搜索，可跨 Project、FR、交付物、通知和账本定位对象，并展示结果类型与跳转落点。
- AC-5.25（Web 层）：登录页、仪表盘、统计页和列表页的辅助文案以短句为主，不抢主操作；空状态、零结果和异常状态的提示语可直接指导下一步动作。
- AC-5.26（Web 层）：驾驶舱支持亮色/暗色主题适配、列表密度切换和高频操作的快捷导航扩展；不因主题或输入方式变化破坏信息层级。

## 6. 概念架构

### 6.1 核心对象类型

SEVO 管理的不是“聊天消息”，而是研发过程里的标准工件和状态对象。核心对象包括：

- **Project**：独立交付单元，拥有标准目录结构（§3.6），是 FR 流程实例的归属容器。
- **FR 流程实例**：一次完整的 SDD 流程执行实例，绑定到一个 Project，承载唯一 ID、当前状态、所属阶段和全部工件引用（§3.5）。
- **Pipeline Task**：FR 流程实例内部某个阶段的具体执行单元，用来承载该阶段里要完成的一次动作，如“写 spec”“做架构设计”“编码”“执行审计”。它不等于整条 FR 生命周期，而是从属于某个 FR 流程实例的阶段执行项；一条 FR 流程实例在完整 SDD 生命周期里会产生一个或多个 Pipeline Task，二者关系是一对多。
- **Stage Record**：某个阶段的执行记录，记录输入、输出、状态、阻断原因和通过结论。
- **Spec Package**：需求规格工件集合。
- **Spec Review Bundle**：需求规格门禁评审结果集合。
- **Contract Package**：架构、实现边界、工作包规划工件集合。
- **Contract Review Bundle**：三方会审结果集合。
- **Work Package**：可派发、可验收、可追责的最小实现单元，最小字段集至少包含 `id`、`title`、`status`、`spec_ref`、`artifacts[]`、`created_at`、`updated_at`。每个 Work Package 内部拆分为 Task 列表。
- **Task**：Work Package 内部的最小执行单元，粒度 2-5 分钟，最小字段集至少包含 `id`、`work_package_ref`、`title`、`target_files[]`、`expected_changes`、`status`、`verification_steps[]`。
- **Implementation Bundle**：某个工作包或某个阶段的实现结果集合。
- **Review Bundle**：实现后独立评审与审计结论集合。
- **Review Issue**：从评审包中提取的单个问题条目，包含严重级别（P0/P1/P2/P3）、关联 FR、问题工件定位、修复建议和当前状态（open/fixing/revalidating/closed/deferred）。
- **Fix Task**：由 Review Issue 自动生成的修复任务卡片，关联原 FR 流程实例 ID、评审报告引用和问题条目，承载修复执行和复验触发。
- **Regression Bundle**：回归验证结果集合。
- **Release Artifact**：发布制品及其版本元数据。
- **Verification Bundle**：清洁环境验证结果集合。
- **Ledger Entry**：交付账本记录，关联 FR 流程实例 ID，作为一次研发闭环的最终摘要对象。
- **Clarification Record**：澄清记录，记录模糊检测触发点、澄清问题、回复内容和收敛结论，挂接到对应阶段的 Stage Record。
- **PipelineEngine**：SEVO 的核心运行时引擎，负责 pipeline 实例的全生命周期推进。读取路由结果中的阶段队列，按顺序或并行通过宿主 Adapter 触发阶段执行，监听完成事件，评估门禁，决定推进或阻断。PipelineEngine 定义编排语义，具体任务派发方式由宿主 Adapter 实现。
- **SEVO Config**：SEVO 的配置对象，承载渐进式披露的四级配置（L0 默认值 → L1 用户配置 → L2 自定义阶段 → L3 编程控制）。
- **Stage Queue**：pipeline 实例的阶段执行队列，由路由结果生成，PipelineEngine 按此队列推进。支持顺序阶段和并行阶段组。

### 6.2 阶段状态机

每个阶段至少支持以下状态：

- **pending**：等待开始。
- **active**：正在执行。
- **blocked**：被上游缺失、外部依赖或门禁失败阻断。
- **passed**：当前阶段通过。
- **failed**：当前阶段结论不通过，需要修复后重试。
- **skipped**：因任务级别裁剪而跳过。

状态流转规则：

- pending → active：前置阶段通过，且本阶段入口条件满足。
- active → passed：出口工件齐全，且本阶段验收通过。
- active → blocked：前置工件缺失、依赖未满足或门禁中断。
- active → failed：已执行但验收不通过。
- failed → active：问题修复后重新进入。
- pending → skipped：路由规则允许跳过，且跳过理由已记录。

### 6.3 阶段间数据流转

SEVO 的数据流是工件驱动，不是口头驱动：

0. PipelineEngine 接收 pipeline-created 事件，读取路由结果，生成 Stage Queue，开始自动推进。
0a. Pipeline Create 在用户已创建 Project、已新增 FR 的前提下，为该 FR 创建 FR 流程实例，绑定 Project，初始化目录结构，产出路由结果。
1. Spec 产出 Spec Package，作为 Spec Review Gate 的唯一需求输入。
2. Spec Review Gate 产出 Spec Review Bundle，决定是否允许进入 Contract。
3. Contract 产出 Contract Package 和 Work Package，作为 Contract Review Gate 与 Implement 的执行输入。
4. Contract Review Gate 产出 Contract Review Bundle，决定是否允许进入 Implement。
5. Implement 产出 Implementation Bundle，作为 Review 和 Regression 的验证基础。
6. Review 产出 Review Bundle，决定是否允许进入 Smoke Test。
   - 6a. Review 结论为有条件通过或不通过时，自动触发 Review Fix Loop：解析报告 → 生成 Review Issue → P0/P1 自动生成 Fix Task → Agent 认领修复 → 定向复验 → 问题关闭 → 门禁重新评估。循环直到放行条件满足。
   - 6b. Smoke Test 验证核心功能路径可用，通过后自动触发 UX Acceptance 和 PM Commercial Review 并行执行。
   - 6c. UX Acceptance 由 ux-01 按检查清单执行视觉验收。
   - 6d. PM Commercial Review 由 pm-01 执行商用就绪评审。UX Acceptance 和 PM Commercial Review 均通过后进入 Regression。
7. Regression 产出 Regression Bundle，决定是否允许生成 Release Artifact。
8. Deploy 产出 Release Artifact，作为 Verify 的唯一交付对象。
9. Verify 产出 Verification Bundle，决定 Ledger 是否可以写入通过结论。
10. Ledger 汇总全部关键工件，形成可查询、可复盘、可回流的交付账本。

### 6.4 核心原则

- 统一用工件交接，不靠聊天解释上下文。
- 统一用 PipelineEngine 驱动阶段推进，不靠主会话手工盯盘或人工触发下一阶段。
- 统一用阶段状态表达进展，不靠主观描述表达“差不多完成”。
- 统一用验收标准定义通过，不靠执行者自报完成。
- 统一保留证据链，方便复盘、审计和经验回流。

#### 6.4.1 通用需求与定制需求边界

SEVO 的设计必须明确区分“通用需求”和“定制需求”，前者是 SEVO 核心，后者通过 Adapter 适配。

判断标准（三问）：
1. 去掉这个能力，“研发流程闭环交付”还成立吗？不成立 = 通用。
2. 换一个完全不同的宿主环境，这个能力的接口定义需要变吗？需要变 = 定制（放 Adapter）。
3. 这个能力描述的是“做什么”还是“怎么做”？“做什么” = 通用，“怎么做” = 定制。

通用需求（SEVO 核心，任何用户/宿主都一样）：
- 流程阶段语义（Spec→Contract→Implement→Review→Regression→Deploy→Verify→Ledger）
- 阶段状态机（每个阶段的输入工件、输出工件、状态变化规则）
- 门禁逻辑（Gate 的通过/阻断判定标准）
- 工件交接协议（阶段间通过工件传递上下文）
- 阶段执行原则注入（Stage-Bound Design，每个阶段该遵循什么原则）
- 账本留痕（每次交付都有证据链）
- 审计独立性（Review 必须独立于 Implement 执行者）
- 主动澄清（模糊检测 + 结构化提问 + 收敛回写）

定制需求（因宿主配置不同而不同，通过 Adapter 适配）：
- Agent 池配置（几个 Agent、叫什么名字、用什么模型）
- 执行治理实现方式（有 hook 的宿主机械式拦截，没有的 post-execute 校验）
- 工件存储位置（本地文件系统 / 云存储 / 数据库）
- 任务调度方式（sessions_spawn / CLI / HTTP API）
- 通知渠道（飞书 / Slack / Discord / 无通知）
- 并行策略（取决于宿主 Agent 池大小和资源）

这个边界是 SEVO 通用化设计的基础约束。所有 FR 和架构决策都必须经过三问检验，确保通用部分不混入定制逻辑。

### 6.5 概念架构验收标准

- AC-6.1：任一阶段都能明确说清输入工件、输出工件和状态变化。
- AC-6.2：任一工作包都能挂接到上游 Spec 与下游 Ledger。
- AC-6.3：Spec Review Gate 和 Contract Review Gate 都有明确输入、输出和阻断语义。
- AC-6.4：跳过阶段不会造成账本断链。
- AC-6.5：状态机同时适用于 ACP agent、原生 subagent 和未来独立编排器。

### 6.6 流程阶段执行原则注入

SEVO 在派发任务时，根据任务所属的流程阶段自动注入该阶段应遵循的执行原则。原则绑定的是阶段，不是 Agent 身份——无论用户派谁来执行，只要在该阶段工作，就自动获得对应原则。

这些原则来源于经过验证的最佳实践（SDD 三阶段、wow-harness 执行治理、Karpathy Guidelines 等），由 SEVO 内建管理。

阶段与注入原则的映射：

- Spec 阶段：用户价值优先、需求完整度校验、概念-技术阶段隔离、主动澄清（模糊检测 + 结构化提问 + 收敛回写）。
- Contract 阶段（架构设计）：通用化判断标准、问题定义先行、结构设计四问、约束先于方案、最简可行架构、禁止绝对排斥宿主能力、主动澄清（技术模糊检测 + 需求矛盾上报）。
- Implement 阶段：最小改动（Surgical Changes）、最简实现（Simplicity First）、目标驱动执行（Goal-Driven）、主动澄清（不清楚就问，不猜测后开发）。
- Review / Regression 阶段：独立性（不做开发只做检查）、可验证结论（附证据）、不放过设计方向问题。
- Contract Review Gate（三方会审）：各方按自己的审查维度注入对应原则（产品视角、开发视角、质量视角）。

核心设计约束：
- 原则绑定阶段，不绑定 Agent。用户可以派任何 Agent 执行任何阶段，SEVO 不限制。
- 原则是指导而非门禁：注入后 Agent 应遵循，但不会因为违反原则而被机械式阻断（与 Session Guards 的硬拦截区分）。
- 原则集可编辑、可扩展，新增阶段或新增原则时不需要改代码。

验收标准：
- AC-6.6.1：派发 Contract 阶段任务时，执行上下文中包含架构设计执行原则，无论执行者是谁。
- AC-6.6.2：派发 Implement 阶段任务时，执行上下文中包含开发执行原则，无论执行者是谁。
- AC-6.6.3：原则集可编辑、可扩展，新增阶段或新增原则时不需要改代码。
- AC-6.6.4：原则注入失败时，任务仍可执行（降级而非阻断）。
- AC-6.6.5：用户派一个任意 Agent 执行 Contract 阶段，流程正常跑通，且该 Agent 收到架构设计原则。

## 7. 与 Self-Evolving Harness 其他模块的边界

### 7.1 与 KIVO 的边界

KIVO 负责知识、规则、意图和经验资产的编译、检索、治理与回流。SEVO 消费这些资产，但不替代 KIVO 做知识治理。

- KIVO 提供：历史规格、方法论、规则、经验、意图线索。
- SEVO 负责：把这些输入转成一次具体研发任务的流程推进与交付闭环。
- SEVO 内部的阶段规则属于流程约束，例如“Specify 阶段必须通过概念定义四问”“Contract 阶段必须经过三方会审后才能进入 Implement”。这些规则定义的是流程怎么推进、何时阻断、何时放行。
- KIVO 的 Rule Entry 属于知识治理对象，用来存档、检索、分发和追踪某条规则资产，例如某个术语的标准定义、某条方法论约束、某个经验规则的版本化记录。
- 两者层面不同：SEVO 的阶段规则是真相源，决定流程行为；KIVO 的 Rule Entry 是知识管理与分发载体，可以引用 SEVO 规则，但不改写 SEVO 的流程语义。
- 边界结论：KIVO 管“知道什么”，SEVO 管“如何把一次研发任务做完”。

### 7.2 与 AEO 的边界

AEO 负责度量 Agent 效果、发现漂移、诊断根因、推动优化。SEVO 负责把一次研发任务执行完并沉淀账本。

- AEO 关注：阶段耗时、失败分布、Agent 表现、质量漂移。
- SEVO 关注：阶段工件、门禁结论、交付闭环。
- 边界结论：AEO 管“做得怎么样”，SEVO 管“按什么流程做完”。

### 7.3 与 Claw Design 的边界

Claw Design 是面向设计产物生成与交付的独立产品。SEVO 可以作为其研发流水线，但不吞并其业务能力。

- Claw Design 负责：图表、PPT、海报、架构图等设计产物能力。
- SEVO 负责：Claw Design 自身功能研发时的规格、实现、审计、验证和交付记录。
- 边界结论：Claw Design 是被研发的产品，SEVO 是研发该产品时使用的流水线。

### 7.4 与宿主环境的边界

- 宿主环境负责：Agent 运行、工具接入、消息调度、执行沙箱。
- SEVO 负责：阶段语义、工件语言、门禁逻辑、验收闭环。
- 边界结论：SEVO 先定义通用流程，再由宿主做适配，不把流程写死到某个目录结构、hook 协议或单一平台实现里。
- 推荐适配模式：宿主环境支持 git worktree 时，Implement 阶段在独立 worktree 中执行，主分支不受影响。worktree 隔离支持多工作包并行开发，失败时可直接丢弃 worktree 回滚，不污染主工作区。

## 8. Wave 规划

### Wave 1：最小可用闭环

目标：先把“能闭环交付”跑通。

范围：

- 支持 8 阶段的最小语义定义和 2 个关键门禁。
- 支持 FR 流程实例创建、Project 目录自动初始化和路由判定。
- 支持 Level 0 / Level 1 / Level 2+ 路由。
- FR-13 PipelineEngine 最小实现：顺序推进 + 门禁评估 + 单项目。不含并行阶段、不含多项目调度。
- FR-14 Package Distribution & CLI：npm install + sevo init + 插件注册 + 核心命令集（init / project create / fr add / status）。
- 支持 Spec、Spec Review Gate、Contract、Contract Review Gate、Implement、Review、Regression、Verify、Ledger 的基础工件。
- 支持工作包级证据记录与独立评审。
- 支持账本落盘与可追溯引用。

验收：

- 陌生用户 `npm install` + `sevo init` 后，5 分钟内能创建 Project、添加 FR、看到 pipeline 自动推进到 Spec 阶段并产出 Spec Package。
- 一条中等复杂度研发任务可完整走完，从 Pipeline Create 到 Ledger。
- 任一阶段都能拿出对应工件。
- 最终交付有 Ledger Entry，关联到 FR 流程实例 ID。

### Wave 2：增强治理与自动化

目标：把“能跑”升级为“跑得稳、查得快”。

范围：

- FR-15 Progressive Disclosure（L1/L2 配置能力）。
- FR-16 Onboarding Experience（demo 命令）。
- FR-14 补充命令：pause / resume / cancel / ledger。
- 路由判定自动化。
- 门禁检查脚本化。
- 评审修复闭环自动化（Review Fix Loop）。
- 风险分级与验证厚度联动。
- 长流程持久化编排。
- 审计与验证模板标准化。

验收：

- 长流程不依赖主会话手工盯盘。
- 阻断原因和缺失工件可结构化输出。
- Review / Regression / Verify 的结论格式统一。

### Wave 3：完整产品化

目标：把 SEVO 做成独立、可移植、可接入多宿主的通用研发流水线。

范围：

- FR-15 L3 编程控制、多宿主 Adapter SDK。
- 支持多运行时适配层。
- 支持统一账本查询、复盘与经验回流接口。
- 支持更多交付目标和发布形态。
- 支持将阶段效果数据回流到 AEO，将经验沉淀回流到 KIVO。

验收：

- 同一套 SEVO 语义可在多个宿主环境复用。
- 账本、审计、验证三类工件可以被外部系统消费。
- 流水线能力不依赖某个宿主私有实现才能成立。

## 9. 约束与假设

### 9.1 约束

- SEVO 先定义通用研发流程，不预设某个唯一宿主。
- SEVO 输出的是规格语言、阶段语言和工件语言，不直接等同某种技术栈。
- 任何“完成”结论都要有可验证工件支撑。
- 审查与实现阶段默认分离，高风险改动不能只靠实现阶段执行者自证。
- 长流程需要状态持久化，不能依赖主会话长期占线。

### 9.2 假设

- 宿主环境能够提供最基本的文件读写、任务派发和结果回收能力。
- 每个阶段至少能落一个可读工件，而不是只有口头说明。
- 团队或系统愿意为质量闭环付出额外成本，而不是只追求最快生成。
- 用户接受按任务级别裁剪流程，但不接受没有证据链的交付。

### 9.3 非目标

- SEVO 不负责替代 IDE、代码编辑器或具体模型提供商。
- SEVO 不负责定义业务产品本身的全部功能细节，那是具体产品 spec 的职责。
- SEVO 不负责知识库治理、效果运营或设计产物生成本身，这些分别属于 KIVO、AEO、Claw Design。

### 9.4 进度透明约束

- 项目进度必须对用户实时可见，禁止用户需要主动追问才能知道进展。
- 每个 FR 的完成状态（已完成/未完成）必须在项目驾驶舱实时展示。
- 任务完成、阶段推进、进度变化时，必须通过 IM 主动通知用户。
- 进度汇报以 spec 中全部 FR 为分母，已实现 FR 为分子；禁止用内部分期偷换完成度口径。
- 只有 spec 中所有 FR 全部实现并通过审计，才能汇报「项目完成」。
- 驾驶舱作为用户主入口时，首页首屏优先暴露当前最危险 FR、最紧急待办和关键异常，不把可处理对象藏在统计卡和长文案之后。

### 9.5 Web 驾驶舱边界

- Web 驾驶舱负责项目、FR、待办、通知、交付物、账本等对象的展示、筛选、钻取、告警和处理入口。
- 只影响页面信息架构、视觉表达、交互效率和访问体验的问题，归入 Web 展示层，不改变 SEVO 核心流程引擎语义。
- Web 层必须忠实呈现核心流程工件与状态，不允许用占位内容、无效页面或不可点击证据链接掩盖真实能力缺口。
- Web 层的搜索、分页、排序、响应式、可访问性和主题能力属于体验能力，不改变 FR 流程实例、门禁和工件的定义边界。

### 9.6 Specify 阶段质量门禁

#### 概念定义四问（Specify 阶段强制）

spec 中出现的每个名词实体（会成为系统中的对象、状态机、UI 元素的东西），必须能回答四个问题：

1. 它的存在解决了什么问题？（存在理由）
2. 用它的人是谁？（使用者）
3. 如何使用？（交互方式）
4. 使用的边界是什么？（scope，什么情况下不适用）

回答不了任何一个 = 概念模糊 = 不能作为功能实体写进 spec。

补充规则：

- 品牌词/营销词可以出现在产品名称中，但不能作为功能实体出现在 FR 定义里。
- 发现概念模糊时，先停下来定义清楚，再继续写 FR。
- 违反 = Specify 阶段门禁不通过，需返工。

定位：SEVO 是研发基础设施，所有工程流程约束都沉淀在 SEVO 中。角色（如 pm-01）可以引用 SEVO 的规则，但规则本体在 SEVO。

### 9.7 总体验收标准

- AC-9.1：文档完整覆盖产品定位、用户、8 阶段 FR、2 个关键门禁、NFR、概念架构、模块边界、Wave 规划和约束。
- AC-9.2：文档内容不依赖某个宿主私有实现才能成立。
- AC-9.3：读者可以据此进入后续 Spec Review 和 Contract 设计，不需要额外口头补课。
- AC-9.4：文档正文不含修订痕迹、过程噪音和 AI 套话。

