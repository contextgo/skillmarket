#!/usr/bin/env python3
"""
Reporter module - 生成 Markdown 报告和 CSV 导出
"""

from pathlib import Path
from typing import Dict, List
import pandas as pd


def generate_markdown_report(comparison: Dict, stats: Dict,
                              left_name: str, right_name: str,
                              output_path: str) -> str:
    """生成 Markdown 格式的差异分析报告"""
    lines = []
    lines.append("# 数据对比报告")
    lines.append("")
    lines.append("## 摘要统计")
    lines.append("")
    lines.append(f"| 指标 | 值 |")
    lines.append(f"|------|-----|")
    lines.append(f"| 匹配行数 | {stats['matched']} |")
    lines.append(f"| 纯匹配行（无差异） | {stats['pure_matched']} |")
    lines.append(f"| 差异行数 | {stats['diff_count']} |")
    lines.append(f"| 仅左文件 | {stats['only_left']} |")
    lines.append(f"| 仅右文件 | {stats['only_right']} |")
    lines.append(f"| 匹配率 | {stats['match_rate']:.1%} |")
    if stats['amount_diff'] != 0:
        lines.append(f"| 金额差异合计 | {stats['amount_diff']:.2f} |")
    lines.append("")
    lines.append("## 差异分类")
    lines.append("")

    # 按差异类型分类
    diff_groups = {}
    for item in comparison["matched"]:
        if item.get("is_diff"):
            detail = item.get("diff_detail", {})
            for col, vals in detail.items():
                col_key = col
                if col_key not in diff_groups:
                    diff_groups[col_key] = []
                diff_groups[col_key].append({
                    "key": item.get("key", item.get("row_index")),
                    "left_val": vals.get("left", ""),
                    "right_val": vals.get("right", "")
                })

    for col, items in diff_groups.items():
        lines.append(f"### 列: {col} ({len(items)} 条差异)")
        lines.append("")
        lines.append(f"| 关联键 | 左文件值 | 右文件值 |")
        lines.append(f"|--------|---------|---------|")
        for d in items[:20]:  # 最多显示20条
            lines.append(f"| {d['key']} | {d['left_val']} | {d['right_val']} |")
        if len(items) > 20:
            lines.append(f"_...还有 {len(items) - 20} 条未显示_")
        lines.append("")

    # 仅左文件记录
    if stats['only_left'] > 0:
        lines.append("## 仅左文件（未在右文件中找到）")
        lines.append("")
        lines.append(f"共 **{stats['only_left']}** 条记录只在左文件中存在：")
        lines.append("")
        left_df = comparison["left_df"]
        cols = left_df.columns.tolist()[:6]  # 最多显示6列
        lines.append(f"| {' | '.join(cols)} |")
        lines.append(f"| {' | '.join(['---'] * len(cols))} |")
        for idx in comparison["only_left"][:20]:
            row = left_df.iloc[idx]
            vals = [str(row.get(c, ""))[:30] for c in cols]
            lines.append(f"| {' | '.join(vals)} |")
        if len(comparison["only_left"]) > 20:
            lines.append(f"_...还有 {len(comparison['only_left']) - 20} 条_")
        lines.append("")

    # 仅右文件记录
    if stats['only_right'] > 0:
        lines.append("## 仅右文件（未在左文件中找到）")
        lines.append("")
        lines.append(f"共 **{stats['only_right']}** 条记录只在右文件中存在：")
        lines.append("")
        right_df = comparison["right_df"]
        cols = right_df.columns.tolist()[:6]
        lines.append(f"| {' | '.join(cols)} |")
        lines.append(f"| {' | '.join(['---'] * len(cols))} |")
        for idx in comparison["only_right"][:20]:
            row = right_df.iloc[idx]
            vals = [str(row.get(c, ""))[:30] for c in cols]
            lines.append(f"| {' | '.join(vals)} |")
        if len(comparison["only_right"]) > 20:
            lines.append(f"_...还有 {len(comparison['only_right']) - 20} 条_")
        lines.append("")

    # AI 解读
    lines.append("## AI 差异解读")
    lines.append("")
    lines.append("> 以下为基于差异模式的推测原因，实际原因需结合业务确认：")
    lines.append("")

    if diff_groups:
        sample_col = list(diff_groups.keys())[0]
        sample_count = len(diff_groups[sample_col])
        lines.append(f"- **{sample_col}** 列存在 {sample_count} 条差异，")
        lines.append("  可能原因：数据录入时间差、部分更新未同步、计算口径不一致")
    else:
        lines.append("- 未发现显著列值差异，差异主要来自记录缺失")

    lines.append("")
    lines.append("---")
    lines.append(f"*报告生成时间: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}*")

    content = "\n".join(lines)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    return content


def export_diff_csv(comparison: Dict, output_path: str) -> None:
    """导出差异结果到 CSV"""
    rows = []

    # 匹配的差异行
    for item in comparison["matched"]:
        if item.get("is_diff"):
            key = item.get("key", "")
            diff_detail = item.get("diff_detail", {})
            for col, vals in diff_detail.items():
                rows.append({
                    "类型": "列值差异",
                    "关联键": key,
                    "列名": col,
                    "左文件值": str(vals.get("left", "")),
                    "右文件值": str(vals.get("right", ""))
                })

    # 仅左
    left_df = comparison["left_df"]
    for idx in comparison["only_left"]:
        row = left_df.iloc[idx]
        rows.append({
            "类型": "仅左文件",
            "关联键": idx,
            "列名": "",
            "左文件值": "存在",
            "右文件值": "不存在"
        })

    # 仅右
    right_df = comparison["right_df"]
    for idx in comparison["only_right"]:
        row = right_df.iloc[idx]
        rows.append({
            "类型": "仅右文件",
            "关联键": idx,
            "列名": "",
            "左文件值": "不存在",
            "右文件值": "存在"
        })

    if rows:
        df = pd.DataFrame(rows)
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False, encoding="utf-8-sig")