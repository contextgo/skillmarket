# 数据对比引擎（Data Compare Engine）

AI 驱动的数据文件对比工具，快速找出两个文件之间的差异。

## 功能说明

### 1. 双文件上传 & 解析
- 支持 CSV / XLSX 上传两个文件
- pandas 读取，自动识别编码
- 文件路径存在 `/tmp/data-compare-engine/` 目录

### 2. AI 自动列匹配
- 用户自带 API Key（OPENAI_API_KEY / ANTHROPIC_API_KEY 等，环境变量传入）
- AI 自动判断两个文件的对应列（相同含义的列）
- 支持手动指定 Join Key 列

### 3. 数据对比
- 精确匹配：完全匹配 / 仅左文件 / 仅右文件 / 金额差异
- 输出：完全匹配行数 / 差异行数 / 差异占比 / 金额差异合计
- 支持指定金额列，计算差异金额

### 4. 差异分析报告
- Markdown 格式输出
- 包含：差异统计摘要、AI 解读差异原因、按组分类的差异明细
- 支持导出 CSV 差异结果

## 快速开始

```bash
# 安装依赖
pip install -r scripts/requirements.txt

# 运行
python run.py --left left_file.csv --right right_file.csv
```

## 参数说明

| 参数 | 说明 |
|------|------|
| --left | 左文件路径（CSV/XLSX） |
| --right | 右文件路径（CSV/XLSX） |
| --join-key | 手动指定 Join Key 列（逗号分隔多列） |
| --amount-col | 金额列名，用于计算差异金额 |
| --output | 输出报告路径（默认 diff_report.md） |
| --export-csv | 导出 CSV 差异结果路径 |
| --ai-model | AI 模型：openai 或 anthropic（默认 openai） |
| --skip-ai-match | 跳过 AI 列匹配，仅使用手动 Join Key |

## 适用场景

- 银行对账单核对
- 财务报表比对
- 库存数据校验
- 订单数据核对

## 计费说明

Token 验证：POST https://api.yk-global.com/v1/verify

| 套餐 | 价格 | 次数 | 每次最大行数 |
|------|------|------|-------------|
| Free | 免费 | 10次体验 | 200行 |
| Pro | ¥29/月 | 50次/月 | 5,000行 |
| Enterprise | ¥99/月 | 无限次 | 无限制 |

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)