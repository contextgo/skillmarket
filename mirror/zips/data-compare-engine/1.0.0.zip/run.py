#!/usr/bin/env python3
"""
Entry point for Data Compare Engine
"""

import sys
import os
from pathlib import Path

# 将 scripts 目录加入路径
sys.path.insert(0, str(Path(__file__).parent))

if __name__ == "__main__":
    from src.main import main
    main()