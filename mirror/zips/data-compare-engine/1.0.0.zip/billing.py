#!/usr/bin/env python3
"""
Billing module for Data Compare Engine - 腾讯版月付
"""

import os
import requests

API_VERIFY = "https://api.yk-global.com/v1/verify"
TIMEOUT = 10

# Free: 10次体验，每次最多200行
FREE_TOTAL_USES = 10
FREE_MAX_ROWS = 200

# Pro ¥29/月：每月50次，每次最多5,000行
PRO_MAX_USES_PER_MONTH = 50
PRO_MAX_ROWS = 5000

# Enterprise ¥99/月：无限次
ENTERPRISE_MAX_ROWS = float('inf')


def get_token():
    """获取 YK_TOKEN"""
    return os.environ.get("YK_TOKEN", "").strip()


def check_balance(api_key: str = None) -> dict:
    """检查余额 / 配额"""
    token = api_key or get_token()

    if not token:
        # Dev mode
        return {"balance": 999.0, "tier": "free", "message": "Dev mode"}

    try:
        resp = requests.get(
            API_VERIFY,
            params={"token": token},
            timeout=TIMEOUT
        )
        if resp.status_code == 200:
            data = resp.json()
            return {
                "balance": data.get("balance", 0.0),
                "tier": data.get("tier", "free"),
                "message": "OK"
            }
        else:
            return {"balance": 0.0, "tier": "free", "message": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"balance": 0.0, "tier": "free", "message": str(e)}


def charge_user(api_key: str = None) -> dict:
    """扣减配额 / 计费"""
    token = api_key or get_token()

    if not token:
        # Dev mode - 不阻断
        return {"success": True, "balance": 999.0, "tier": "free", "message": "Dev mode"}

    try:
        resp = requests.post(
            API_VERIFY,
            json={"token": token, "action": "charge"},
            timeout=TIMEOUT
        )
        if resp.status_code == 200:
            data = resp.json()
            return {
                "success": data.get("success", False),
                "balance": data.get("balance", 0.0),
                "tier": data.get("tier", "free"),
                "message": data.get("message", "OK")
            }
        else:
            return {"success": False, "balance": 0.0, "tier": "free", "message": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"success": False, "balance": 0.0, "tier": "free", "message": str(e)}