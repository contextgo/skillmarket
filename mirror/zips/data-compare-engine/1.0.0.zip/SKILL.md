# 数据对比引擎（Data Compare Engine）

AI 驱动的数据文件对比工具，快速找出两个文件之间的差异。

## 功能

### 1. 双文件上传 & 解析
- 支持 CSV / XLSX 上传两个文件
- pandas 读取，自动识别编码
- 用户上传后保存到 `/tmp/data-compare-engine/`

### 2. AI 自动列匹配
- 用户自带 API Key（OPENAI_API_KEY / ANTHROPIC_API_KEY 等，环境变量传入）
- AI 自动判断两个文件的对应列（相同含义的列）
- 支持手动指定 Join Key 列

### 3. 数据对比
- 精确匹配：完全匹配 / 仅左文件 / 仅右文件 / 金额差异
- 输出：完全匹配行数 / 差异行数 / 差异占比 / 金额差异合计
- 支持指定金额列，计算差异金额

### 4. 差异分析报告
- Markdown 格式输出
- 包含：差异统计摘要、AI 解读差异原因、按组分类的差异明细
- 支持导出 CSV 差异结果

## 使用方法

```bash
pip install -r scripts/requirements.txt
python run.py --left left_file.csv --right right_file.csv
```

## 计费

Token 验证：POST https://api.yk-global.com/v1/verify

| 套餐 | 价格 | 次数 | 每次最大行数 |
|------|------|------|-------------|
| Free | 免费 | 10次体验 | 200行 |
| Pro | ¥29/月 | 50次/月 | 5,000行 |
| Enterprise | ¥99/月 | 无限次 | 无限制 |

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)

## 环境变量

- `OPENAI_API_KEY` - OpenAI API Key（可选）
- `ANTHROPIC_API_KEY` - Anthropic API Key（可选）
- `YK_TOKEN` - 妙搭计费 Token