#!/usr/bin/env python3
"""
Comparator module - 数据对比核心逻辑
"""

from typing import List, Optional, Dict, Tuple
import pandas as pd
import numpy as np


def normalize_key(key_val) -> str:
    """规范化关联键值"""
    return str(key_val).strip().lower()


def compare_data(left_df: pd.DataFrame,
                 right_df: pd.DataFrame,
                 join_keys: Optional[List[str]] = None,
                 column_mapping: Optional[Dict[str, str]] = None,
                 amount_col: Optional[str] = None) -> Dict:
    """
    对比两个数据集
    返回结构:
    {
        "matched": [row_ids],
        "only_left": [row_ids],
        "only_right": [row_ids],
        "amount_diff": float,
        "matched_rows": [...],  # 匹配的详细行数据
        "diff_rows": [...],     # 差异行详情
    }
    """
    if join_keys:
        # 使用 Join Key 进行匹配
        result = compare_by_key(left_df, right_df, join_keys, column_mapping, amount_col)
    else:
        # 行对行比较（顺序相同）
        result = compare_row_by_row(left_df, right_df, column_mapping, amount_col)

    return result


def compare_by_key(left_df: pd.DataFrame,
                   right_df: pd.DataFrame,
                   join_keys: List[str],
                   column_mapping: Optional[Dict[str, str]] = None,
                   amount_col: Optional[str] = None) -> Dict:
    """基于 Join Key 进行匹配对比"""
    # 构建 key -> row 索引的映射
    left_keys = {}
    for idx, row in left_df.iterrows():
        key = "|".join(str(row[k]).strip().lower() for k in join_keys)
        if key not in left_keys:
            left_keys[key] = []
        left_keys[key].append(idx)

    right_keys = {}
    for idx, row in right_df.iterrows():
        key = "|".join(str(row[k]).strip().lower() for k in join_keys)
        if key not in right_keys:
            right_keys[key] = []
        right_keys[key].append(idx)

    matched = []
    only_left = []
    only_right = []
    amount_diff = 0.0

    # 处理左文件
    for key, left_indices in left_keys.items():
        if key in right_keys:
            right_indices = right_keys[key]
            # 一对多匹配：取第一行
            left_idx = left_indices[0]
            right_idx = right_indices[0]

            # 检查列值差异
            left_row = left_df.iloc[left_idx]
            right_row = right_df.iloc[right_idx]

            is_diff = False
            diff_detail = {}

            if column_mapping:
                for left_col, right_col in column_mapping.items():
                    if left_col in left_row and right_col in right_row:
                        if str(left_row[left_col]) != str(right_row[right_col]):
                            is_diff = True
                            diff_detail[left_col] = {
                                "left": left_row[left_col],
                                "right": right_row[right_col]
                            }

            # 检查金额差异
            if amount_col and amount_col in left_row and amount_col in right_row:
                try:
                    left_amt = float(str(left_row[amount_col]).replace(',', '').replace('¥', '').replace('$', ''))
                    right_amt = float(str(right_row[amount_col]).replace(',', '').replace('¥', '').replace('$', ''))
                    if abs(left_amt - right_amt) > 0.01:
                        is_diff = True
                        diff_detail[amount_col] = {
                            "left": left_amt,
                            "right": right_amt
                        }
                        amount_diff += (left_amt - right_amt)
                except ValueError:
                    pass

            if is_diff:
                matched.append({
                    "key": key,
                    "left_idx": int(left_idx),
                    "right_idx": int(right_idx),
                    "is_diff": True,
                    "diff_detail": diff_detail
                })
            else:
                matched.append({
                    "key": key,
                    "left_idx": int(left_idx),
                    "right_idx": int(right_idx),
                    "is_diff": False
                })

            # 移除已匹配的右记录
            right_keys[key] = right_indices[1:]
            if not right_keys[key]:
                del right_keys[key]
        else:
            for idx in left_indices:
                only_left.append(int(idx))

    # 剩余的右文件记录
    for key, right_indices in right_keys.items():
        for idx in right_indices:
            only_right.append(int(idx))

    return {
        "matched": matched,
        "only_left": only_left,
        "only_right": only_right,
        "amount_diff": amount_diff,
        "left_df": left_df,
        "right_df": right_df,
        "join_keys": join_keys,
        "column_mapping": column_mapping or {}
    }


def compare_row_by_row(left_df: pd.DataFrame,
                        right_df: pd.DataFrame,
                        column_mapping: Optional[Dict[str, str]] = None,
                        amount_col: Optional[str] = None) -> Dict:
    """行对行比较（无 Join Key 时使用）"""
    n = min(len(left_df), len(right_df))
    matched = []
    amount_diff = 0.0

    for i in range(n):
        left_row = left_df.iloc[i]
        right_row = right_df.iloc[i]

        is_diff = False
        diff_detail = {}

        if column_mapping:
            for left_col, right_col in column_mapping.items():
                if left_col in left_row and right_col in right_row:
                    if str(left_row[left_col]) != str(right_row[right_col]):
                        is_diff = True
                        diff_detail[left_col] = {
                            "left": left_row[left_col],
                            "right": right_row[right_col]
                        }

        if amount_col and amount_col in left_row and amount_col in right_row:
            try:
                left_amt = float(str(left_row[amount_col]).replace(',', '').replace('¥', '').replace('$', ''))
                right_amt = float(str(right_row[amount_col]).replace(',', '').replace('¥', '').replace('$', ''))
                if abs(left_amt - right_amt) > 0.01:
                    is_diff = True
                    amount_diff += (left_amt - right_amt)
            except ValueError:
                pass

        matched.append({
            "row_index": i,
            "is_diff": is_diff,
            "diff_detail": diff_detail
        })

    only_left = list(range(n, len(left_df)))
    only_right = list(range(n, len(right_df)))

    return {
        "matched": matched,
        "only_left": only_left,
        "only_right": only_right,
        "amount_diff": amount_diff,
        "left_df": left_df,
        "right_df": right_df,
        "join_keys": None,
        "column_mapping": column_mapping or {}
    }


def compute_diff_stats(comparison: Dict) -> Dict:
    """计算差异统计"""
    matched = comparison["matched"]
    only_left = comparison["only_left"]
    only_right = comparison["only_right"]

    total_matched = len(matched)
    diff_count = sum(1 for m in matched if m.get("is_diff", False))
    pure_matched_count = total_matched - diff_count

    total_rows = total_matched + len(only_left) + len(only_right)
    match_rate = (pure_matched_count / total_rows * 100) if total_rows > 0 else 0.0

    return {
        "matched": total_matched,
        "pure_matched": pure_matched_count,
        "diff_count": diff_count,
        "only_left": len(only_left),
        "only_right": len(only_right),
        "total_diff": diff_count + len(only_left) + len(only_right),
        "match_rate": pure_matched_count / total_rows if total_rows > 0 else 0.0,
        "amount_diff": comparison["amount_diff"]
    }