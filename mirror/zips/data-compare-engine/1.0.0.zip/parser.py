#!/usr/bin/env python3
"""
Parser module - 读取并解析 CSV/XLSX 文件
"""

import os
import chardet
from pathlib import Path
import pandas as pd


def detect_encoding(file_path: str) -> str:
    """自动检测文件编码"""
    try:
        with open(file_path, 'rb') as f:
            raw = f.read(10000)
        result = chardet.detect(raw)
        return result.get('encoding', 'utf-8') or 'utf-8'
    except Exception:
        return 'utf-8'


def read_file(file_path: str, sheet_index: int = 0) -> tuple:
    """
    读取文件，返回 (DataFrame, raw_data)
    支持 CSV 和 XLSX
    """
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == '.csv':
        encoding = detect_encoding(str(path))
        df = pd.read_csv(str(path), encoding=encoding, dtype=str, keep_default_na=False)
    elif suffix in ('.xlsx', '.xls'):
        df = pd.read_excel(str(path), sheet_name=sheet_index, dtype=str, keep_default_na=False)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")

    # 清理列名空格
    df.columns = [str(c).strip() for c in df.columns]
    # 清理数据空格
    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

    return df, df


def validate_file(file_path: str) -> dict:
    """验证文件是否可读"""
    path = Path(file_path)
    if not path.exists():
        return {"valid": False, "message": "File not found"}
    if path.stat().st_size == 0:
        return {"valid": False, "message": "File is empty"}

    suffix = path.suffix.lower()
    if suffix not in ('.csv', '.xlsx', '.xls'):
        return {"valid": False, "message": f"Unsupported format: {suffix}"}

    try:
        read_file(file_path)
        return {"valid": True, "message": "OK"}
    except Exception as e:
        return {"valid": False, "message": str(e)}