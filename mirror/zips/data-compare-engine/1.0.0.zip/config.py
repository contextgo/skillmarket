#!/usr/bin/env python3
"""
配置模块
"""

# Free: 10次体验，每次最多200行
FREE_TOTAL_USES = 10
FREE_MAX_ROWS = 200

# Pro: ¥29/月，每月50次，每次最多5000行
PRO_MAX_USES_PER_MONTH = 50
PRO_MAX_ROWS = 5000

# Enterprise: ¥99/月，无限次
ENTERPRISE_MAX_ROWS = float('inf')