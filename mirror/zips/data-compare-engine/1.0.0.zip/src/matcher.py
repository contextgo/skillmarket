#!/usr/bin/env python3
"""
Column Matcher - AI 自动列匹配
"""

import os
import json
from typing import List, Optional, Dict


def build_match_prompt(left_cols: List[str], right_cols: List[str]) -> str:
    """构建列匹配提示词"""
    prompt = f"""你是一个数据对比助手。需要判断两个数据集的列之间的对应关系。

左文件列名: {json.dumps(left_cols, ensure_ascii=False)}
右文件列名: {json.dumps(right_cols, ensure_ascii=False)}

请判断哪些列含义相同，可以对应起来。
返回 JSON 格式：
{{
  "mappings": [
    {{"left": "左列名", "right": "右列名", "confidence": 0.95}},
    ...
  ],
  "join_keys": ["列名1", "列名2"],
  "reason": "说明"
}}

规则：
- 只返回有对应关系的列
- join_keys 是可以作为关联键的列（如ID、编号、日期等）
- confidence 表示匹配置信度 (0-1)
"""
    return prompt


def call_openai(prompt: str) -> str:
    """调用 OpenAI API"""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set")

    import requests
    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0
        },
        timeout=30
    )
    if resp.status_code != 200:
        raise RuntimeError(f"OpenAI API error: {resp.status_code} {resp.text}")
    data = resp.json()
    return data["choices"][0]["message"]["content"]


def call_anthropic(prompt: str) -> str:
    """调用 Anthropic API"""
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set")

    import requests
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        },
        json={
            "model": "claude-3-haiku-20240307",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": prompt}]
        },
        timeout=30
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Anthropic API error: {resp.status_code} {resp.text}")
    data = resp.json()
    return data["content"][0]["text"]


def match_columns_ai(left_cols: List[str], right_cols: List[str],
                     model: str = "openai") -> Optional[Dict[str, str]]:
    """
    使用 AI 自动匹配两个文件的对应列
    返回: {左列名: 右列名} 或 None
    """
    prompt = build_match_prompt(left_cols, right_cols)

    try:
        if model == "openai":
            raw = call_openai(prompt)
        elif model == "anthropic":
            raw = call_anthropic(prompt)
        else:
            raise ValueError(f"Unknown model: {model}")
    except Exception as e:
        raise RuntimeError(f"AI column matching failed: {e}")

    # 解析 JSON
    import json as _json
    try:
        # 尝试提取 JSON 块
        text = raw.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
        result = _json.loads(text.strip())
    except Exception:
        raise ValueError(f"Failed to parse AI response as JSON: {raw[:200]}")

    mappings = result.get("mappings", [])
    column_mapping = {}
    for m in mappings:
        left_col = m.get("left", "")
        right_col = m.get("right", "")
        if left_col and right_col:
            column_mapping[left_col] = right_col

    return column_mapping if column_mapping else None


def suggest_join_keys(left_cols: List[str], right_cols: List[str]) -> List[str]:
    """建议可用的 Join Key 列"""
    common = set(left_cols) & set(right_cols)
    # 优先选择看起来像 ID、编号、日期的列
    priority_keywords = ['id', 'no', '编号', '日期', 'date', 'code', '编码', 'key']
    candidates = []
    for col in common:
        col_lower = col.lower()
        if any(kw in col_lower for kw in priority_keywords):
            candidates.append(col)
    if not candidates and common:
        candidates = [list(common)[0]]
    return candidates