#!/usr/bin/env python3
"""
Data Compare Engine - V1
两个文件上传 + AI 自动列匹配 + 数据对比 + 差异分析报告
"""

import sys
import os
import argparse
from pathlib import Path

# 目录
BASE_DIR = Path("/tmp/data-compare-engine")
BASE_DIR.mkdir(parents=True, exist_ok=True)

from .config import FREE_TOTAL_USES
from .parser import read_file, validate_file
from .matcher import match_columns_ai, suggest_join_keys
from .comparator import compare_data, compute_diff_stats
from .reporter import generate_markdown_report, export_diff_csv
from .billing import charge_user

__version__ = "1.0.0"


def main():
    parser = argparse.ArgumentParser(
        description="Data Compare Engine - AI-powered file comparison tool"
    )
    parser.add_argument("--left", help="Path to left (primary) file")
    parser.add_argument("--right", help="Path to right (secondary) file")
    parser.add_argument("--left-sheet", default=0, type=int, help="Sheet index for xlsx (default 0)")
    parser.add_argument("--right-sheet", default=0, type=int, help="Sheet index for xlsx (default 0)")
    parser.add_argument("--left-name", default="左文件", help="Display name for left file")
    parser.add_argument("--right-name", default="右文件", help="Display name for right file")
    parser.add_argument("--join-key", help="Manual join key column name (comma for multiple)")
    parser.add_argument("--amount-col", help="Amount column name for diff calculation")
    parser.add_argument("--output", default="diff_report.md", help="Output report path")
    parser.add_argument("--export-csv", help="Export diff results to CSV path")
    parser.add_argument("--ai-model", default="openai", choices=["openai", "anthropic"],
                        help="AI model for column matching")
    parser.add_argument("--skip-ai-match", action="store_true",
                        help="Skip AI column matching, use manual join key only")

    args = parser.parse_args()

    # Billing check
    result = charge_user(api_key=os.environ.get("YK_TOKEN"))
    if not result["success"]:
        print(f"[Billing] {result.get('message', 'Billing check failed')}")
        # Dev mode or free tier - allow limited usage

    # 参数校验
    if not args.left or not args.right:
        # 交互式输入
        left_path = input("请输入左文件路径（CSV/XLSX）: ").strip().strip('"')
        right_path = input("请输入右文件路径（CSV/XLSX）: ").strip().strip('"')
        args.left = left_path
        args.right = right_path

    # 安全校验 - 只允许字母、数字、点、下划线、短横线
    for path_arg in [args.left, args.right]:
        safe_name = os.path.basename(path_arg)
        if not all(c.isalnum() or c in '._-' for c in safe_name):
            print(f"[Error] 文件名包含非法字符: {safe_name}")
            print("只允许: a-z A-Z 0-9 . _ -")
            sys.exit(1)

    # 读取文件
    print(f"[Step 1] 读取文件...")
    try:
        left_df, left_raw = read_file(args.left, sheet_index=args.left_sheet)
        right_df, right_raw = read_file(args.right, sheet_index=args.right_sheet)
    except Exception as e:
        print(f"[Error] 文件读取失败: {e}")
        sys.exit(1)

    print(f"  左文件: {len(left_df)} 行 x {len(left_df.columns)} 列")
    print(f"  右文件: {len(right_df)} 行 x {len(right_df.columns)} 列")

    # 列匹配
    print(f"[Step 2] 列匹配...")
    if args.skip_ai_match:
        column_mapping = None
    else:
        try:
            column_mapping = match_columns_ai(
                left_df.columns.tolist(),
                right_df.columns.tolist(),
                model=args.ai_model
            )
            print(f"  AI 匹配结果: {column_mapping}")
        except Exception as e:
            print(f"[Warning] AI 匹配失败，使用手动模式: {e}")
            column_mapping = None

    # Join Key 指定
    join_keys = None
    if args.join_key:
        join_keys = [k.strip() for k in args.join_key.split(",")]
        print(f"  使用手动 Join Key: {join_keys}")

    if not join_keys and column_mapping:
        # 从 mapping 中提取 join key
        # 如果两文件有共同的列名，优先用作 join key
        common = set(left_df.columns) & set(right_df.columns)
        if common:
            join_keys = [list(common)[0]]
            print(f"  自动检测 Join Key: {join_keys}")

    # 数据对比
    print(f"[Step 3] 数据对比...")
    try:
        comparison = compare_data(
            left_df, right_df,
            join_keys=join_keys,
            column_mapping=column_mapping,
            amount_col=args.amount_col
        )
    except Exception as e:
        print(f"[Error] 对比失败: {e}")
        sys.exit(1)

    stats = compute_diff_stats(comparison)
    print(f"  匹配行: {stats['matched']}")
    print(f"  仅左: {stats['only_left']}")
    print(f"  仅右: {stats['only_right']}")
    print(f"  金额差异: {stats['amount_diff']}")

    # 生成报告
    print(f"[Step 4] 生成报告...")
    report_path = BASE_DIR / args.output
    try:
        generate_markdown_report(
            comparison, stats,
            left_name=args.left_name,
            right_name=args.right_name,
            output_path=str(report_path)
        )
        print(f"  报告已生成: {report_path}")
    except Exception as e:
        print(f"[Error] 报告生成失败: {e}")
        sys.exit(1)

    # CSV 导出
    if args.export_csv:
        try:
            export_diff_csv(comparison, args.export_csv)
            print(f"  差异结果已导出: {args.export_csv}")
        except Exception as e:
            print(f"[Warning] CSV 导出失败: {e}")

    print("\n=== 对比完成 ===")
    print(f"匹配率: {stats['match_rate']:.1%}")
    print(f"差异行数: {stats['total_diff']}")
    if stats['amount_diff'] != 0:
        print(f"金额差异合计: {stats['amount_diff']}")
    print(f"报告: {report_path}")


if __name__ == "__main__":
    main()