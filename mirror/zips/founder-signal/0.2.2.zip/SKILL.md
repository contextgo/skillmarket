---
name: founder-signal
version: "0.2.2"
description: >
  Founder Signal turns verified Reddit and V2EX evidence into a small, reviewable signal package
  for founders evaluating product demand and positioning across one or more configured
  product profiles.
  Use this skill when the user wants founder research from Reddit or V2EX evidence, a scored
  review artifact, or a Draft page generated from verified candidate discussions.
  This skill depends on the canonical draft-cli skill. Draft is the default founder
  review surface, so Founder Signal emits a Draft-ready public publish intent whenever
  an Action Card exists. Public Draft publication requires explicit confirmation before
  the downstream draft-cli skill is invoked.
metadata:
  clawdis:
    author: innosage-llc
    emoji: "📡"
    dependencies:
      - name: "toliuweijing/draft-cli"
        type: "other"
        url: "https://clawhub.ai/toliuweijing/draft-cli"
    requires:
      bins:
        - "bash"
        - "python3"
        - "draft"
    install:
      - id: "npm"
        kind: "node"
        package: "@innosage/draft-cli"
        bins:
          - "draft"
        label: "Install draft-cli (npm)"
---

# Founder Signal OpenClaw Skill

Use this skill to turn verified Reddit and V2EX evidence into a small, reviewable signal package
for founders evaluating product demand and positioning across one or more configured
product profiles.

## Founder Signal Invariant

No saved verified snapshot means no scoring and no draft.

Every run must persist a run folder before later steps execute so failures still leave
traceable artifacts. The skill should only score verified evidence and should only
prepare a Draft handoff after `daily-review.md` exists for the selected profile.
Actual public Draft publication requires explicit founder confirmation.

## Setup Contract

After installation, ask the founder for one canonical Founder Signal JSON config,
validate it, then import it into an internal runtime profile. Do not ask the founder
to hand-edit `profiles/*.json` unless they explicitly want to debug the runtime.

Recommended flow:

1. Share or fill `founder-signal.config.example.json`.
2. Validate it:

```bash
python3 -m founder_signal doctor --config founder-signal.config.json
```

3. Import it:

```bash
python3 -m founder_signal config import founder-signal.config.json
```

4. Run it:

```bash
python3 -m founder_signal run --config founder-signal.config.json
```

The shell shortcut is also valid:

```bash
bash scripts/run_founder_signal_once.sh --config founder-signal.config.json
```

Canonical config requirements:

- `profile_id`
- `product_name`
- `product_one_liner`
- `target_audience`
- `keywords`
- `scoring_terms`
- `platforms`
- `discovery_mode`
- `max_candidates`
- `draft.require_confirmation_before_public_publish: true`

Reject legacy user-facing fields such as `subreddits`, `seed_reddit_urls`,
`excluded_reddit_urls`, or any `draft_publish_command` escape hatch in canonical setup
JSON. The import step writes an internal runtime profile under `profiles/` plus a
normalized canonical copy under `config-imports/`.

## Inputs

- one canonical Founder Signal config JSON during setup
- one or more active imported product profiles from `profiles/*.json`
- optional `--profile <profile_id>` selection for single-profile runs
- platform configuration from the canonical `platforms` object or existing internal legacy profiles
- deterministic Reddit/Eddrit research discovery from profile communities,
  `keywords`, and scoring terms; discovery always runs before configured Reddit hints
- optional Reddit `discovery_mode: live` using subreddit new feeds with age/comment
  filtering and product-term matching
- V2EX discovery through SOV2EX, search, node latest pages, or configured seed topics; third-party discovery is candidate-finding only
- optional platform `excluded_urls` or legacy `excluded_reddit_urls` to suppress known old candidates
- `history_ttl_days` to expire old private repeat-candidate exclusions
- optional `verified_evidence_snapshots` when a Claw/browser agent has verified a source post but automated fetch is blocked

## Draft Publish Handoff

Founder Signal depends on the canonical `draft-cli` skill for public Draft page
publication. Draft handoff preparation is on by default: when Founder Signal creates
`daily-review.md`, it also writes `draft-publish-intent.json` next to
`daily-review.md` and does not hardcode Draft CLI subcommands. The intent contains the
artifact path, title, profile, public visibility request, and
`requires_confirmation: true`.

The agent must not invoke `draft-cli` public publish immediately after the intent is
written. It must first show the founder what would become public, or clearly point to
`daily-review.md`, then ask for explicit publish approval. This prevents unused public
Draft pages from occupying cloud storage and keeps the public boundary reviewable.

The `draft-cli` skill is the source of truth for daemon readiness, page creation,
append/patch behavior, public publishing, invite codes, and Draft URL extraction.

## E2E Verification Playbook

When the founder asks for an end-to-end verification run, the agent must deliver a
public Draft URL or clearly report E2E incomplete.

1. Enable the target profiles.
2. Use the built-in discovery phase. Do not start from placeholder URLs.
3. Try the normal Eddrit search/listing and post mirror paths first.
4. If the mirror is blocked, use browser/manual verification and add
   `verified_evidence_snapshots` to the profile:

```json
{
  "platform": "reddit",
  "source_url": "https://www.reddit.com/r/ChatGPT/comments/abc123/real_slug/",
  "verification_method": "agent_browser",
  "verified_by": "openclaw-agent",
  "text_snapshot": "Copy the relevant source post text observed by the agent here."
}
```

The snapshot must be real source text from the source post, not invented content.
Placeholder URLs such as `POST_ID`, `REAL_ID`, `SUB`, `/slug/`, or V2EX placeholder topic IDs are invalid and must
not be used. Founder Signal treats `verified_read_via_agent_browser` and
`verified_read_via_manual_snapshot` as verified reads only after the snapshot is
persisted.

Run E2E checks with:

```bash
python3 -m founder_signal run --config founder-signal.config.json --require-action-card --require-publish-intent
```

When the run creates `draft-publish-intent.json`, inspect its `requires_confirmation`
field. If it is `true`, show the founder the public-boundary summary and ask for
approval before invoking the required `draft-cli` skill. After approval, publish
`daily-review.md` publicly and return the resulting public Draft URL to the founder.
This Draft handoff preparation is part of normal Founder Signal operation, but the
public publish action is confirmation-gated.

## Outputs

- `runs/<RUN_ID>/run.json`
- `runs/<RUN_ID>/REPORT.md`
- `runs/<RUN_ID>/profiles/<profile_id>/run.json`
- `runs/<RUN_ID>/profiles/<profile_id>/REPORT.md`
- `runs/<RUN_ID>/profiles/<profile_id>/evidence/`
- `runs/<RUN_ID>/profiles/<profile_id>/outputs/candidates.json`
- `runs/<RUN_ID>/profiles/<profile_id>/selected-candidate.json` when a verified
  candidate is selected
- `runs/<RUN_ID>/profiles/<profile_id>/daily-review.md` when an Action Card is generated
- `runs/<RUN_ID>/profiles/<profile_id>/draft-publish-intent.json` when public Draft
  publishing is prepared and awaiting confirmation
- `state/past-candidates.json` as private local candidate history used to avoid repeat
  candidates in future runs

Action Cards use `Source platform` and `Source URL` labels and must not expose private local evidence paths in Draft-bound Markdown.
## Manual Execution

```bash
python3 -m founder_signal doctor --config founder-signal.config.json
python3 -m founder_signal config import founder-signal.config.json
python3 -m founder_signal run --config founder-signal.config.json
bash scripts/run_founder_signal_once.sh
bash scripts/run_founder_signal_once.sh --profile draft
bash scripts/run_founder_signal_once.sh --config founder-signal.config.json --require-action-card --require-publish-intent
```

Without `--profile`, the runner processes all enabled profiles.

## Bundled Runtime Payload

This published skill package includes the minimum local runtime payload needed to run
from the installed skill directory:

- `scripts/run_founder_signal_once.sh`
- `src/founder_signal/`
- `founder-signal.config.example.json`
- `profiles/README.md`
- `profiles/draft.example.json`

Before a real run, create one canonical config JSON, validate it, and import it. No
Draft publish settings file is required; Draft review is part of the default flow, but
public publication always remains confirmation-gated.

## Runtime Order

1. Load either all enabled profiles or one selected profile.
2. For each profile, run enabled platform adapters, skipping profile exclusions and previous local candidate history before capping, then consider configured hints and verified snapshot fallbacks.
3. Save evidence from mirror or verified snapshot fallback, enforce the verified-read
   gate, score only verified candidates, and optionally generate an Action Card.
4. Write a public Draft publish intent whenever `daily-review.md` exists, marked as
   requiring confirmation before public publish.

Eddrit search/listing and post mirror pages are the Reddit read layer. V2EX discovery providers are never the verified evidence source; verified V2EX reads use the original `https://www.v2ex.com/t/<topic_id>` topic URL or future official API reads. Browser/manual fallback remains a verified snapshot path when automated reads are blocked.
