"""Draft publish intent handoff for Founder Signal daily reviews."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

_DAILY_REVIEW_FILENAME = "daily-review.md"
_PUBLISH_INTENT_FILENAME = "draft-publish-intent.json"


@dataclass(frozen=True)
class DraftPublishIntent:
    path: Path
    daily_review_path: Path
    visibility: str
    title: str
    requires_confirmation: bool


def write_public_draft_publish_intent(
    *,
    run_dir: Path,
    profile_id: str,
) -> DraftPublishIntent:
    """Write the public Draft publish intent consumed by the draft-cli skill.

    The intent prepares the Draft handoff but does not authorize a downstream agent to
    publish without an explicit publish-time confirmation.
    """
    daily_review_path = run_dir / _DAILY_REVIEW_FILENAME
    if not daily_review_path.exists():
        raise FileNotFoundError(f"Daily review not found: {daily_review_path}")
    title = _derive_page_title(daily_review_path=daily_review_path, profile_id=profile_id)
    intent_path = run_dir / _PUBLISH_INTENT_FILENAME
    payload = {
        "intent": "publish_markdown_to_draft",
        "artifact_type": "founder_signal_action_card",
        "visibility": "public",
        "profile_id": profile_id,
        "title": title,
        "daily_review_path": str(daily_review_path),
        "draft_cli_skill": "toliuweijing/draft-cli",
        "requires_confirmation": True,
        "confirmation_prompt": (
            "Review daily-review.md and confirm before publishing this Founder Signal "
            "Action Card as a public Draft page."
        ),
        "status": "requested",
    }
    intent_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return DraftPublishIntent(
        path=intent_path,
        daily_review_path=daily_review_path,
        visibility="public",
        title=title,
        requires_confirmation=True,
    )


def _derive_page_title(*, daily_review_path: Path, profile_id: str) -> str:
    for line in daily_review_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            heading = stripped.lstrip("#").strip()
            if heading:
                return heading
    return f"Founder Signal Daily Review ({profile_id})"
