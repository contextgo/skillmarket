"""Command-line entrypoint for Founder Signal."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import run_once
from .report import write_failed_marker, write_report
from .setup import doctor_user_config, import_user_config, render_doctor_report


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except Exception as exc:
        print(f"Founder Signal error: {exc}", file=sys.stderr)
        return 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python3 -m founder_signal")
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor_parser = subparsers.add_parser("doctor", help="Validate a canonical Founder Signal config JSON.")
    doctor_parser.add_argument("--config", required=True, help="Path to founder-signal.config.json")
    doctor_parser.add_argument(
        "--root-dir",
        default=".",
        help="Founder Signal root directory where profiles/ and runs/ live.",
    )
    doctor_parser.set_defaults(func=_doctor_command)

    config_parser = subparsers.add_parser("config", help="Config management helpers.")
    config_subparsers = config_parser.add_subparsers(dest="config_command", required=True)
    config_import = config_subparsers.add_parser(
        "import",
        help="Validate and save a canonical Founder Signal config into profiles/.",
    )
    config_import.add_argument("config_path", help="Path to founder-signal.config.json")
    config_import.add_argument(
        "--root-dir",
        default=".",
        help="Founder Signal root directory where profiles/ and runs/ live.",
    )
    config_import.set_defaults(func=_config_import_command)

    run_parser = subparsers.add_parser("run", help="Run Founder Signal once.")
    run_parser.add_argument("--profile", help="Run only the selected profile_id.")
    run_parser.add_argument("--config", help="Validate and import this config before running.")
    run_parser.add_argument("--require-action-card", action="store_true")
    run_parser.add_argument("--require-publish-intent", action="store_true")
    run_parser.add_argument("--require-all-profiles", action="store_true")
    run_parser.add_argument(
        "--root-dir",
        default=".",
        help="Founder Signal root directory where profiles/ and runs/ live.",
    )
    run_parser.set_defaults(func=_run_command)
    return parser


def _doctor_command(args: argparse.Namespace) -> int:
    root_dir = Path(args.root_dir).resolve()
    config_path = Path(args.config).resolve()
    result = doctor_user_config(root_dir=root_dir, config_path=config_path)
    print(render_doctor_report(result, config_path=config_path), end="")
    return 0


def _config_import_command(args: argparse.Namespace) -> int:
    root_dir = Path(args.root_dir).resolve()
    config_path = Path(args.config_path).resolve()
    imported = import_user_config(root_dir=root_dir, config_path=config_path)
    print(f"Imported profile: {imported.profile_id}")
    print(f"Profile path: {imported.profile_path}")
    print(f"Saved canonical config copy: {imported.normalized_config_path}")
    print(f"Next command: python3 -m founder_signal run --profile {imported.profile_id}")
    return 0


def _run_command(args: argparse.Namespace) -> int:
    root_dir = Path(args.root_dir).resolve()
    selected_profile_id = args.profile
    if args.config:
        imported = import_user_config(root_dir=root_dir, config_path=Path(args.config).resolve())
        if selected_profile_id and selected_profile_id != imported.profile_id:
            raise ValueError(
                f"--profile {selected_profile_id} does not match imported config profile_id {imported.profile_id}."
            )
        selected_profile_id = imported.profile_id

    run_dir = _next_run_dir(root_dir)
    run_dir.mkdir(parents=True, exist_ok=False)
    result = run_once(
        root_dir=root_dir,
        run_dir=run_dir,
        selected_profile_id=selected_profile_id,
    )
    failures = _required_failures(
        result=result,
        require_action_card=bool(args.require_action_card),
        require_publish_intent=bool(args.require_publish_intent),
        require_all_profiles=bool(args.require_all_profiles),
    )
    if failures:
        result["status"] = "failed"
        result["next_step"] = "provide_verified_evidence_and_retry_e2e"
        result["failures"] = list(dict.fromkeys([str(item) for item in result.get("failures", [])] + failures))
        result["error"] = "; ".join(failures)
        (run_dir / "run.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        write_report(run_dir=run_dir, artifact=result)
        write_failed_marker(run_dir=run_dir, artifact=result)
    print(json.dumps(result, indent=2))
    return 1 if result.get("status") == "failed" else 0


def _required_failures(
    *,
    result: dict,
    require_action_card: bool,
    require_publish_intent: bool,
    require_all_profiles: bool,
) -> list[str]:
    failures: list[str] = []
    profile_results = result.get("profile_results") or []
    if require_action_card and not result.get("action_card_generated"):
        failures.append("required Action Card was not generated")
    if require_publish_intent and not result.get("draft_publish_requested"):
        failures.append("required Draft publish intent was not generated")
    if require_all_profiles:
        if not profile_results:
            failures.append("required profile checks found no profile results")
        for item in profile_results:
            profile_id = item.get("profile_id") or "unknown"
            if require_action_card and not item.get("action_card_generated"):
                failures.append(f"{profile_id}: required Action Card was not generated")
            if require_publish_intent and not item.get("draft_publish_requested"):
                failures.append(f"{profile_id}: required Draft publish intent was not generated")
    return failures


def _next_run_dir(root_dir: Path) -> Path:
    runs_dir = root_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)
    while True:
        candidate = runs_dir / _run_timestamp()
        if not candidate.exists():
            return candidate


def _run_timestamp() -> str:
    from datetime import datetime

    return datetime.now().strftime("%Y-%m-%d-%H%M%S")


if __name__ == "__main__":
    raise SystemExit(main())
