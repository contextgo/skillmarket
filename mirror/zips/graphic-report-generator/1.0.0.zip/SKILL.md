---
name: graphic-report-generator
description: "This skill should be used when the user asks to generate a graphic-rich, visually polished HTML report, guide, analysis document, or knowledge article. Trigger phrases include '整理成图文并茂的文档', '生成图文解读报告', '制作可视化报告', '整理成知识手册'. It provides the UI template, output paths, and step-by-step workflow for producing professional HTML documents that match the established design system."
version: "1.0.0"
author: "范奇"
tags:
  - 文档生成
  - HTML报告
  - 可视化
  - 产品知识库
icon: "📊"
---

# Graphic Report Generator

## Overview

当用户请求生成图文并茂的 HTML 文档时，按照本 skill 规定的模板、路径和工作流执行，确保输出风格统一、存放位置规范。

**模板支持双主题切换**：内置白色版/暗黑版，点击右上角 ☀️/🌙 按钮即可切换，无需用户选择。

## UI 模板（必须使用）

模板文件路径：
```
~/.workbuddy/skills/graphic-report-generator/assets/ui-template.html
```

该模板的核心设计特点：

| 元素 | 样式 |
|------|------|
| 背景色 | `#f8fafc` 浅灰白 |
| 主色调 | `#1a56db` 蓝色 |
| Hero 区 | 深蓝渐变（`#0f172a → #1e3a8a → #1d4ed8`）+ 装饰圆形 |
| 卡片 | 白色背景 + 圆角 16px + 边框 + 轻微阴影 |
| 表格 | 蓝色表头（`#e8f0fe`）+ hover 高亮行 |
| 标签/徽章 | 语义色背景 + 圆角胶囊 |
| 数字/时间轴 | 深色代码区（`#0f172a`）+ 语法高亮 |
| 字体栈 | `-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif` |

**使用模板时：**
1. 读取 `assets/ui-template.html`，提取其完整 `<style>` 块
2. 将内容填充到模板的 `<body>` 中，保留 `<style>` 块原样
3. 如需新增可视化组件（流程图、对比表格、时间轴等），参照模板中已有组件的 CSS 写法
4. 不要自创暗色系、霓虹色、或与模板不一致的 UI 风格

## 输出路径（必须遵守）

| 用途 | 路径 |
|------|------|
| 知识库主目录 | `/Users/macwoos/Desktop/范奇工作文档/20260407workbuddy/` |
| 图文报告存放目录 | `/Users/macwoos/Desktop/范奇工作文档/20260407workbuddy/客户问题解读报告/` |

**工作流：**
1. 生成 HTML 文件后，同步保存到上述两个路径：
   - 本地：`/Users/macwoos/WorkBuddy/Claw/<文件名>.html`
   - 知识库：`/Users/macwoos/Desktop/范奇工作文档/20260407workbuddy/客户问题解读报告/<中文标题>.html`
2. 完成后用 `preview_url` 打开本地文件供用户预览
3. 更新记忆：`/Users/macwoos/WorkBuddy/Claw/.workbuddy/memory/YYYY-MM-DD.md`

## 生成流程

### Step 1：理解内容
- 读取用户提供或引用的原始文档（PRD、问题记录、需求说明等）
- 梳理核心知识点、问题点、解决方案
- 确定文档结构和信息层次

### Step 2：规划视觉组件
根据内容类型选用以下组件（全部定义在模板中）：

| 组件 | 适用场景 | CSS class |
|------|----------|-----------|
| `flow`（流程图） | 展示系统架构、工作流程、数据流向 | `.flow` `.flow-node` `.flow-arrow` |
| `purpose-grid`（用途卡片） | 对比多个并列概念或方案 | `.purpose-card` `.purpose-card.max/default/tx` |
| `kind-grid`（类型网格） | 展示不同类型/模式的对比 | `.kind-card` `.kind-badge` |
| `timeline-vis`（时间轴） | 展示时间序列、分时数据 | `.tl-bar` `.tl-seg` |
| `stack-vis`（层级可视化） | 展示优先级、堆叠关系 | `.stack-row` `.stack-bar` |
| `rule-grid`（规则卡片） | 展示注意事项、警告、特殊规则 | `.rule-card` `.rule-card.warn/info/danger/success` |
| `iog-banner`（横幅） | 重要概念/功能介绍模块 | `.iog-banner` |
| `field-table`（字段表） | 展示结构化字段定义 | `.field-table` |
| `json-example`（代码块） | JSON 示例、配置代码 | `.json-example` |

### Step 3：编写 HTML
1. 使用模板的 `<style>` 块（从 `assets/ui-template.html` 读取）
2. 编写 Hero 区（标题 + 简介 + 标签）
3. 按逻辑章节组织内容，每个章节使用 `section` + `section-header`
4. 内容中的代码片段用深色代码区包裹，字段名用 `field-name`（蓝色 monospace）
5. 完成后设置合适的 `<title>` 标签

### Step 4：保存与预览
1. 保存到本地：`/Users/macwoos/WorkBuddy/Claw/<英文名>-<日期>.html`
2. 复制到知识库：`客户问题解读报告/<中文标题>.html`
3. 用 `preview_url` 打开本地 HTML 供预览

## 命名规范

- **文件名**：使用英文短横线分隔，如 `argo-ocpp-integration-report.html`
- **文档标题（Hero 内）**：中文，如 `Argo OCPP 集成测试问题解读`
- **标签（Hero Tags）**：简洁短语，如 `🔌 LB2.0` `⚡ PV 2.1` `⚠️ 集成问题`

## 常见触发短语

以下任何一种表达都应触发本 skill：
- "把某个文档整理为图文并茂的文档"
- "生成图文解读报告"
- "整理成知识手册"
- "帮我做一个可视化报告"
- "把这个做成图文并茂的"
- "生成一份图文报告"
- "制作知识库文档"
