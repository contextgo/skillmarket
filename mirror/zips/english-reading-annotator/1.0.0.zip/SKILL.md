---
name: english-reading-annotator
description: 处理英语阅读文本，生成带词汇高亮、段落大意、词汇表和主题文体分析的完整HTML文件。当用户提及"英语阅读"、"阅读理解"、"完形填空"、"七选五"、"阅读材料"、"英语文本处理"、"词汇标注"、"段落大意"、"阅读文本生成HTML"等关键词时触发此技能。支持图片OCR识别、多篇文章合并或分开生成、阅读题答案解析等功能。
---

# 英语阅读文本标注器

将英语阅读文本转换为专业格式的HTML学习材料，包含词汇高亮、段落大意、词汇表和主题文体分析。

## 触发场景

当用户需要：
- 处理英语阅读文本生成学习材料
- 对英语文章进行词汇标注和段落分析
- 制作英语阅读理解题目的解析材料
- 处理完形填空或七选五并补全文本
- 从图片中提取英语文本并标注

## 适用题型范围

### ✅ 支持的题型

| 题型 | 处理方式 |
|------|---------|
| 阅读理解 A/B/C/D | 词汇标注 + 段落大意 + 答案解析 |
| 七选五 | 补全答案 + 词汇标注 |
| 完形填空 | 补全答案 + 词汇标注 |
| 语法填空 | 补全答案 + 语法考点分析 |
| 短文改错 | 标注错误 + 语法分析 |

### ❌ 不支持的题型

| 题型 | 原因 |
|------|------|
| 听力理解 | 无音频处理能力（听力原文可单独处理） |
| 书面表达/写作 | 无需词汇标注（范文可单独处理） |
| 单词拼写/词汇运用 | 不适用本文本处理模式 |
| 口语测试 | 无音频处理能力 |

### 边界情况处理

**当文档包含不支持题型时**：

自动识别并过滤，在处理开始时一条消息告知即可，无需等待确认，直接继续：

```
📋 已识别：✅ 阅读A/B/C/D · ✅ 七选五 · ✅ 完形填空 · ✅ 语法填空
⏭️ 已跳过：听力（无音频）· 写作（无需标注）
→ 开始处理...
```

## 核心功能

### 1. 输入处理

**文本输入**：直接接收用户提供的英语文本

**图片输入**：先使用OCR工具将图片转为文本，再进行处理

**docx文件输入**：使用 pandoc 转换为 markdown（推荐）
```bash
pandoc input.docx -t markdown -o output.md
```
- pandoc 安装路径：`$LOCALAPPDATA/Pandoc/pandoc.exe`
- 输出干净文本，保留段落结构和表格

**doc文件输入**（旧版Word格式）：
- `.doc` 是旧版Word二进制格式（OLE复合文档），python-docx 不支持
- **推荐方案**：让用户用 Word 另存为 `.docx` 格式，再按上述方式处理
- **备选方案**：使用 UTF-16LE 直接提取二进制文本
  ```python
  with open(filepath, 'rb') as f:
      data = f.read()
  
  # UTF-16LE 解码提取文本
  i, current, text_parts = 0, [], []
  while i < len(data) - 1:
      low_byte, high_byte = data[i], data[i + 1]
      if high_byte == 0 and 32 <= low_byte <= 126:
          current.append(chr(low_byte))
          i += 2
      elif len(current) > 10:
          text_parts.append(''.join(current))
          current = []
          i += 1
      else:
          current = []
          i += 1
  
  full_text = '\n'.join(text_parts)
  ```

**多篇文章**：检测到多篇文章时，先询问用户是要合并成一个HTML还是生成多个独立HTML文件，再按要求处理

### 2. 特殊题型处理

**阅读理解题**：
- 在文章末尾添加答案解析区域
- 格式：题目 → 答案 → 解析
- **解析必须包含**：
  1. **答案依据**：引用原文中支持正确答案的关键句子或段落
  2. **推理过程**：解释如何从原文推导出正确答案
  3. **排除理由**：简要说明其他选项为何错误（可选，视题目难度而定）
- **引用原文规则**：
  - 直接引用原文关键句，用引号标注
  - 引用内容过长时，用 `...` 省略中间部分
  - 指明引用内容的段落位置（如"根据第二段"、"由第三段可知"）
- 示例见下方模板

**完形填空/七选五/语法填空**：
- 如果提供了答案，按答案补全文本
- 如果未提供答案，由AI完成题目并补全文本
- 补全后再进行词汇标注和格式化

**答案还原格式**：

将答案直接还原到原文空格处，使用 `<u>` 标签加下划线。

**格式要求**：`<u>题目编号 + 答案</u>`

| 题型 | 格式示例 |
|------|---------|
| 七选五 | `<u>36. F. That means good grammar and no spelling mistakes.</u>` |
| 完形填空 | `<u>41. C won</u>` |
| 语法填空 | `<u>56. engineering</u>` 或 `<u>57. a</u>` |

**注意事项**：
- 七选五格式：题目编号 + 选项字母 + 答案内容（如 `36. F. That means...`）
- 完形填空格式：题目编号 + 选项字母 + 答案单词（如 `41. C won`）
- 语法填空格式：题目编号 + 答案（如 `56. engineering`）
- 直接使用 `<u>` 标签，不要添加 `class="filled-blank"` 等额外属性
- 不要使用淡蓝色背景和深蓝色边框标注补全内容

**答案解析区格式**（七选五/完形填空/语法填空）：

答案解析使用 `<p class="question-text">` 格式，不使用 `<u>` 标签：

```html
<div class="question-item">
    <p class="question-text">36. E. Not only does this cafe serve up drinks, it also serves up smiles.</p>
    <div class="answer-box">
        <p class="explanation"><strong>解题思路：</strong>空前提到...</p>
    </div>
</div>
```

**区分两种格式**：
| 位置 | 格式 |
|------|------|
| 段落内答案还原 | 使用 `<u>` 标签（如 `<u>36. F. That means...</u>`） |
| 答案解析区标题 | 使用 `<p class="question-text">答案</p>`，无 `<u>` 标签 |

### 3. 词汇判定标准

**只有B2及以上难度的词汇/短语才执行词汇高亮**。

**⚠️ 核心原则：宁多勿少。不确定是否为B2级别时，默认标注。**

#### B2级别词汇类型（应标注）：

| 类型 | 说明 | 示例 |
|------|------|------|
| 抽象名词 | 表示概念、状态的名词 | habitat, restoration, indication, achievement, reflection |
| 学术词汇 | 学术、科研相关 | specimen, hypothesis, methodology, ecosystem |
| 情感/心理词汇 | 描述情感、心理状态 | defensive, sensitive, motivated, demotivated |
| 动作/变化动词 | 非日常动作动词 | ease, restore, investigate, demonstrate |
| 形容词（性质） | 描述性质、特征 | vital, conventional, alternative, holistic |
| 社会/制度词汇 | 社会、制度相关 | agreement, approval, community, requirement |
| 科技/专业词汇 | 科技、专业领域 | acupuncture, chiropractic, engineering |
| 固定搭配 | 常见搭配短语 | vital role, endangered species, mental focus |

#### B2示例词汇（必须标注）：
- **名词**：habitat, restoration, indication, achievement, reflection, specimen, ecosystem, agreement, approval
- **动词**：ease, restore, investigate, demonstrate, fulfill, approach
- **形容词**：vital, conventional, alternative, holistic, sensitive, defensive, invasive, functional
- **副词**：increasingly, particularly, generally

#### C1/C2级别（高级词汇）：
- C1：ephemeral, ubiquitous, paradigm, sophisticated
- C2：serendipity, unprecedented

#### 习语和固定搭配：
- break new ground, in the wake of, shine through, lay on of hands

**注意**：A1-A2级别的基础词汇（如 book, happy, go, run 等）不进行高亮处理。

## 输出格式规范

生成完整可运行的HTML文件，结构如下：

### 内容结构

```
原文段落（带编号、词汇高亮）
└── 段落大意（英语关键词 + 中文大意，加粗+酒红色）
    └── 段落词汇表（3栏流式布局）
        └── 词汇项：词汇/短语 | 词性 | 中文释义

主题语境与文体类型分析区
├── 主题语境：人与社会/人与自然/人与自我
└── 文体类型：记叙文/说明文/议论文等

署名区
└── 制作者：仙游金石中学 戴元守
```

### 样式规范

**整体容器**：
- 白色背景 + 轻微阴影
- 内边距 40px，合理外边距

**原文区**：
- 字体 25px，行高 1.8
- 段落两端对齐
- 段落编号用阿拉伯数字

**词汇高亮色**（同一词汇保持一致）：
- 浅蓝 #e3f2fd
- 浅绿 #e8f5e9  
- 浅紫 #f3e5f5
- 浅黄 #fff3e0

**七选五/完形填空/语法填空答案还原**：

将答案直接还原到原文空格处，使用 `<u>` 标签加下划线。格式要求：

| 题型 | 格式示例 |
|------|---------|
| 七选五 | `<u>36. F. That means good grammar and no spelling mistakes.</u>` |
| 完形填空 | `<u>41. C won</u>` |
| 语法填空 | `<u>56. engineering</u>` |

**段落大意**：
- 字体 28px
- 加粗 + 酒红色 (#800020)
- 不使用斜体
- **格式要求**：1-3个英语关键词 + 中文段落大意
- 示例：`【Introduction. 本文介绍了...】` 或 `【Main Idea. 本段主要讲述...】`

**词汇表区**：
- 字体 28px，行高 1.5
- 3栏流式布局，栏间距适中
- 整体右缩进 4 字符
- 不添加"词汇表"标题，直接展示词汇项
- 词汇项内边距 5px、带圆角
- 背景色与原文高亮对应

**主题文体分析区**：
- 标题：27px、加粗、带下边框
- 内容：15px、行高 2、两端对齐

**响应式适配**：
- 使用 `clamp()` 函数实现自适应字号
- `overflow-x: hidden` 确保无横向滚动条
- 容器宽度 100%，自适应屏幕
- 词汇表使用 `auto-fit` 自动调整列数
- 文本自动换行，防止溢出

**响应式断点**：
- 768px 以下：单栏布局，减小边距
- 480px 以下：进一步优化移动端显示

**署名区**：
- 位于页面底部
- 字体 14px，灰色 (#666)
- 居中显示，带顶部分隔线

## 执行流程

### 核心原则
- **默认合并输出**：所有文章放入单个HTML，一条消息告知即开始，不等确认
- **解题前置**：七选五/完形/语法填空先统一解题，再逐篇标注生成
- **一次写入**：所有HTML片段在内存中攒好，最后一次性写入文件
- **不中断询问**：题型自动识别过滤，直接跑到底

---

### 第一步：输入转换

1. docx → pandoc 转 markdown：`pandoc input.docx -t markdown -o temp.md`
   pandoc 路径：`C:\Users\daiyu\AppData\Local\Pandoc\pandoc.exe`
2. 图片 → OCR 提取文本
3. 纯文本 → 直接使用

---

### 第二步：题型识别（告知即过）

自动识别并过滤，一条消息带过，不等确认，立即继续处理：

```
📋 ✅ 阅读A/B/C/D · ✅ 七选五 · ✅ 完形填空 · ✅ 语法填空
⏭️ 已跳过：听力 · 写作
→ 合并模式，开始处理...
```

---

### 第三步：统一解题

**逐篇处理之前，先集中完成所有需要补全的题目：**

- 七选五（36-40）：阅读全文和选项，选出最佳答案
- 完形填空（41-55）：阅读全文和选项，选出最佳答案  
- 语法填空（56-65）：根据语法规则填入正确形式
- 答案暂存，供后续生成HTML时直接使用
- 阅读理解题在逐篇处理时同步解答

---

### 第四步：逐篇生成HTML片段

对每篇文章独立处理，片段暂存内存，**不写临时文件**：

```
循环处理每篇文章：
  1. 从原文提取该篇文本
  2. 识别B2及以上词汇，分配四色高亮（蓝/绿/紫/黄轮换）
  3. 提取每段英文关键词 + 中文段落大意
  4. 生成原文HTML（含词汇高亮 + 段落大意 + 段落词汇表）
  5. 生成答案解析区（阅读题）/ 填入已解答案（七选五/完形/语法）
  6. 生成主题语境与文体分析
  7. 追加片段到内存缓存，继续下一篇
```

---

### 第五步：一次性写入最终HTML

所有篇章处理完后，按顺序一次写入：

1. HTML 头部（doctype + 完整CSS + 完整JS）
2. 试卷标题 `<h1>`
3. 所有文章片段（用 `<hr class="divider">` 分隔）
4. 全卷核心词汇汇总表（去重合并，`id="vocab-summary"`）
5. 署名区：`制作者：仙游金石中学 戴元守`
6. 右侧缩放按钮 `<div class="zoom-controls">`
7. 底部导航栏 `<nav class="bottom-nav">`
8. 关闭标签

### 篇章ID规范

| 篇章 | id |
|------|-----|
| 阅读理解 A | `reading-a` |
| 阅读理解 B | `reading-b` |
| 阅读理解 C | `reading-c` |
| 阅读理解 D | `reading-d` |
| 七选五 | `seven-five` |
| 完形填空 | `cloze` |
| 语法填空 | `grammar` |
| 词汇汇总 | `vocab-summary` |

### 输出位置

HTML 与源文件同目录同名（后缀改为 .html）。

## HTML模板

### 模板使用说明

使用单一HTML文件结构，CSS和JS在 `<head>` 中声明一次，各篇文章的HTML片段依次放入 `<body>`，最后统一署名。

**结构示例**：
```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>英语试卷</title>
    <style>
        /* CSS样式只声明一次 */
    </style>
</head>
<body>
    <div class="container">
        <h1 class="main-title">试卷标题</h1>
        
        <!-- 文章A -->
        <section class="article-section">
            <h2 class="section-header">阅读理解 A</h2>
            <!-- 文章A内容 -->
        </section>
        
        <hr class="divider">
        
        <!-- 文章B -->
        <section class="article-section">
            <h2 class="section-header">阅读理解 B</h2>
            <!-- 文章B内容 -->
        </section>
        
        <!-- 更多文章... -->
        
        <!-- 署名只出现一次 -->
        <div class="signature">制作者：仙游金石中学 戴元守</div>
    </div>
</body>
</html>
```

### 单篇文章HTML模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title>英语阅读材料</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            width: 100%;
            overflow-x: hidden;
        }
        
        body {
            font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
            background-color: #f5f5f5;
            padding: clamp(10px, 2vw, 20px);
            line-height: 1.6;
            min-height: 100vh;
        }
        
        /* 缩放时调整基础字体大小 */
        :root {
            --base-font-size: 24px;
        }
        
        .container {
            max-width: 100%;
            width: 100%;
            margin: 0 auto;
            background: white;
            padding: clamp(20px, 4vw, 40px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 8px;
            padding-bottom: 80px;
        }
        
        .main-title {
            font-size: calc(var(--base-font-size) * 1.8);
            font-weight: bold;
            text-align: center;
            margin-bottom: 30px;
            color: #1a237e;
            border-bottom: 3px solid #1a237e;
            padding-bottom: 15px;
        }
        
        .main-subtitle {
            font-size: calc(var(--base-font-size) * 1.25);
            font-weight: normal;
        }
        
        .section-header {
            font-size: calc(var(--base-font-size) * 1.5);
            font-weight: bold;
            text-align: center;
            margin: 40px 0 25px 0;
            color: #1a237e;
            background: linear-gradient(90deg, transparent, #e3f2fd, transparent);
            padding: 12px 0;
        }
        
        .paragraph {
            font-size: var(--base-font-size);
            line-height: 1.8;
            text-align: justify;
            margin-bottom: 20px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        .paragraph-num {
            font-weight: bold;
            margin-right: 8px;
        }
        
        .highlight-blue {
            background-color: #e3f2fd;
            padding: 2px 4px;
            border-radius: 3px;
        }
        
        .highlight-green {
            background-color: #e8f5e9;
            padding: 2px 4px;
            border-radius: 3px;
        }
        
        .highlight-purple {
            background-color: #f3e5f5;
            padding: 2px 4px;
            border-radius: 3px;
        }
        
        .highlight-yellow {
            background-color: #fff3e0;
            padding: 2px 4px;
            border-radius: 3px;
        }
        
        .paragraph-summary {
            font-size: calc(var(--base-font-size) * 1.1);
            font-weight: bold;
            color: #800020;
            margin: clamp(10px, 1.5vw, 15px) 0 clamp(8px, 1vw, 10px) 0;
        }
        
        .vocab-section {
            margin-left: clamp(1em, 4vw, 4em);
            margin-bottom: clamp(20px, 3vw, 30px);
        }
        
        .vocab-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: clamp(10px, 1.5vw, 15px);
            font-size: var(--base-font-size);
            line-height: 1.5;
        }
        
        .vocab-item {
            padding: 5px;
            border-radius: 4px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        /* 阅读理解答案解析区 */
        .questions-section {
            margin-top: 30px;
            padding: 25px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        
        .questions-title {
            font-size: calc(var(--base-font-size) * 1.4);
            font-weight: bold;
            color: #2980b9;
            margin-bottom: 20px;
        }
        
        .question-item {
            margin-bottom: 25px;
            padding: 15px;
            background: white;
            border-radius: 6px;
            border-left: 4px solid #3498db;
        }
        
        .question-text {
            font-size: calc(var(--base-font-size) * 1.1);
            font-weight: bold;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .options {
            font-size: calc(var(--base-font-size) * 1.05);
            margin-bottom: 15px;
            padding-left: 20px;
        }
        
        .options p {
            margin: 5px 0;
        }
        
        .answer-box {
            background: #e8f5e9;
            padding: 15px;
            border-radius: 6px;
            margin-top: 10px;
        }
        
        .answer-label {
            font-weight: bold;
            color: #27ae60;
            font-size: calc(var(--base-font-size) * 1.05);
        }
        
        .explanation {
            font-size: var(--base-font-size);
            line-height: 1.8;
            margin-top: 10px;
            color: #555;
        }
        
        .key-words {
            background: #fff3e0;
            padding: 8px 12px;
            border-radius: 4px;
            margin-top: 8px;
            font-size: calc(var(--base-font-size) * 0.95);
        }
        
        .reading-answers {
            margin-top: 30px;
            padding: 20px;
            background-color: #fafafa;
            border-radius: 8px;
            border-left: 4px solid #800020;
        }
        
        .reading-answers-title {
            font-size: calc(var(--base-font-size) * 1.25);
            font-weight: bold;
            margin-bottom: 15px;
            color: #333;
        }
        
        .answer-text {
            font-size: var(--base-font-size);
            color: #800020;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .explanation-text {
            font-size: calc(var(--base-font-size) * 0.95);
            color: #555;
            line-height: 1.6;
        }
        
        .analysis-section {
            margin-top: clamp(25px, 4vw, 40px);
            padding-top: clamp(15px, 2vw, 20px);
            border-top: 2px solid #e0e0e0;
        }
        
        .analysis-title {
            font-size: calc(var(--base-font-size) * 1.2);
            font-weight: bold;
            padding-bottom: 10px;
            border-bottom: 1px solid #ccc;
            margin-bottom: clamp(15px, 2vw, 20px);
        }
        
        .analysis-content {
            font-size: calc(var(--base-font-size) * 0.9);
            line-height: 2;
            text-align: justify;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        .analysis-content h4 {
            font-size: calc(var(--base-font-size) * 0.95);
            margin: 15px 0 10px 0;
        }
        
        .divider {
            margin: 50px 0;
            border: none;
            border-top: 3px double #1a237e;
        }
        
        /* 底部篇章导航 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(26, 35, 126, 0.9);
            backdrop-filter: blur(8px);
            padding: 12px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            box-shadow: 0 -3px 15px rgba(0,0,0,0.15);
            z-index: 1000;
        }
        
        .bottom-nav a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 18px;
            background: rgba(255,255,255,0.12);
            transition: all 0.3s ease;
            white-space: nowrap;
            font-weight: 500;
        }
        
        .bottom-nav a:hover {
            background: rgba(255,255,255,0.25);
            transform: translateY(-2px);
        }
        
        .bottom-nav a.active {
            background: rgba(255,255,255,0.95);
            color: #1a237e;
            font-weight: bold;
        }
        
        /* 右侧缩放按钮 */
        .zoom-controls {
            position: fixed;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            flex-direction: column;
            gap: 12px;
            z-index: 1000;
        }
        
        .zoom-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid rgba(26, 35, 126, 0.3);
            background: rgba(255, 255, 255, 0.95);
            color: #1a237e;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 3px 10px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .zoom-btn:hover {
            background: rgba(26, 35, 126, 0.1);
            border-color: rgba(26, 35, 126, 0.5);
            transform: scale(1.08);
        }
        
        .zoom-btn:active {
            transform: scale(0.95);
        }
        
        /* 响应式媒体查询 */
        @media screen and (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .container {
                padding: 15px;
                border-radius: 6px;
            }
            
            .vocab-grid {
                grid-template-columns: 1fr;
            }
            
            .bottom-nav {
                padding: 10px 12px;
                gap: 8px;
            }
            
            .bottom-nav a {
                padding: 8px 14px;
                font-size: 14px;
            }
            
            .zoom-controls {
                right: 10px;
            }
            
            .zoom-btn {
                width: 40px;
                height: 40px;
                font-size: 22px;
            }
        }
        
        @media screen and (max-width: 480px) {
            .container {
                padding: 12px;
            }
            
            .paragraph {
                line-height: 1.7;
            }
            
            .vocab-section {
                margin-left: 0;
            }
        }
        
        /* 打印样式优化 */
        @media print {
            body {
                padding: 0;
                background: white;
            }
            
            .container {
                box-shadow: none;
                padding: 20px;
            }
            
            .bottom-nav, .zoom-controls {
                display: none;
            }
        }
        
        /* 署名区样式 */
        .signature {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            font-size: calc(var(--base-font-size) * 0.9);
            color: #666;
        }
        
        /* 词汇汇总表 */
        .vocab-summary-text {
            font-size: var(--base-font-size);
            line-height: 1.8;
        }
    </style>
    <script>
        // 缩放功能 - 通过CSS变量调整字体大小
        let currentZoom = 150;
        const maxZoom = 600;
        const minZoom = 50;
        const step = 15;
        const baseFontSize = 24;
        
        // 页面加载时应用默认缩放
        document.addEventListener('DOMContentLoaded', function() {
            applyZoom();
        });
        
        function applyZoom() {
            const newSize = baseFontSize * (currentZoom / 100);
            document.documentElement.style.setProperty('--base-font-size', newSize + 'px');
        }
        
        function updateZoom(delta) {
            const newZoom = Math.max(minZoom, Math.min(maxZoom, currentZoom + delta * step));
            if (newZoom !== currentZoom) {
                currentZoom = newZoom;
                const newSize = baseFontSize * (currentZoom / 100);
                document.documentElement.style.setProperty('--base-font-size', newSize + 'px');
            }
        }
        
        // 平滑滚动到指定章节
        function scrollToSection(id) {
            const element = document.getElementById(id);
            if (element) {
                const navHeight = document.querySelector('.bottom-nav').offsetHeight;
                const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
                window.scrollTo({
                    top: elementPosition - navHeight - 20,
                    behavior: 'smooth'
                });
            }
        }
        
        // 更新导航高亮
        function updateNavHighlight() {
            const sections = document.querySelectorAll('[id]');
            const navLinks = document.querySelectorAll('.bottom-nav a');
            let currentSection = '';
            
            sections.forEach(section => {
                const rect = section.getBoundingClientRect();
                if (rect.top <= 150) {
                    currentSection = section.id;
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === '#' + currentSection) {
                    link.classList.add('active');
                }
            });
        }
        
        window.addEventListener('scroll', updateNavHighlight);
        document.addEventListener('DOMContentLoaded', updateNavHighlight);
    </script>
</head>
<body>
    <div class="container">
        <h1 class="main-title">英语阅读材料<br><span class="main-subtitle">副标题</span></h1>
        
        <!-- 各篇章通过id进行导航定位 -->
        <!-- <h2 class="section-header" id="reading-a">阅读理解 A 篇</h2> -->
        <!-- <h2 class="section-header" id="reading-b">阅读理解 B 篇</h2> -->
        <!-- 以此类推... -->
        
        <!-- 段落内容 -->
        
        <!-- ====== 七选五/完形填空/语法填空答案还原格式示例 ====== -->
        <!-- 七选五：题目编号 + 选项字母 + 答案内容 -->
        <!-- <p class="paragraph"><span class="paragraph-num">①</span>This is the original text <u>36. F. That means good grammar and no spelling mistakes.</u> and continues here.</p> -->
        
        <!-- 完形填空：题目编号 + 选项字母 + 答案单词 -->
        <!-- <p class="paragraph"><span class="paragraph-num">①</span>When I was a teenager, a neighborhood friend <u>41. C won</u> a marathon race.</p> -->
        
        <!-- 语法填空：题目编号 + 答案 -->
        <!-- <p class="paragraph"><span class="paragraph-num">①</span>The latest <u>56. engineering</u> techniques are applied to create this structure.</p> -->
        
        <!-- ⚠️ 注意：直接使用 <u> 标签，不要添加 class="filled-blank" 等额外属性 -->
        
         <!-- 段落大意 -->
         <!-- <div class="paragraph-summary">【Main Idea. 段落大意内容】</div> -->
        
        <!-- 词汇表 -->
        <!-- <div class="vocab-section">
            <div class="vocab-grid">
                <div class="vocab-item highlight-blue">sophisticated | adj. 复杂的；精密的</div>
            </div>
        </div> -->
        
        <!-- 阅读理解答案解析（仅阅读题需要） -->
        <!-- <div class="questions-section">
            <h3 class="questions-title">阅读理解题目与解析</h3>
            <div class="question-item">
                <p class="question-text">21. What is the main purpose of the project?</p>
                <div class="options">
                    <p>A. Option A</p>
                    <p>B. Option B</p>
                    <p>C. Option C</p>
                    <p>D. Option D</p>
                </div>
                <div class="answer-box">
                    <p class="answer-label">答案：D</p>
                    <p class="explanation"><strong>解题思路：</strong>根据原文...</p>
                    <p class="key-words">关键词定位：...</p>
                </div>
            </div>
        </div> -->
        
        <!-- 主题文体分析 -->
        <!-- <div class="analysis-section">
            <div class="analysis-title">主题语境与文体分析</div>
            <div class="analysis-content">
                <h4>主题语境：人与社会</h4>
                <p>本文属于...</p>
                <h4>文体类型：说明文</h4>
                <p>本文是...</p>
            </div>
        </div> -->
        
        <!-- 词汇汇总表（合并模式在最后添加） -->
        <!-- <h2 class="section-header" id="vocab-summary">全卷核心词汇汇总表</h2> -->
        
        <!-- 署名 -->
        <div class="signature">制作者：仙游金石中学 戴元守</div>
    </div>
    
    <!-- 右侧缩放按钮 -->
    <div class="zoom-controls">
        <button class="zoom-btn" onclick="updateZoom(1)" title="放大">+</button>
        <button class="zoom-btn" onclick="updateZoom(-1)" title="缩小">−</button>
    </div>
    
    <!-- 底部篇章导航（合并模式添加） -->
    <!-- <nav class="bottom-nav">
        <a href="#reading-a" onclick="scrollToSection('reading-a'); return false;">阅读A篇</a>
        <a href="#reading-b" onclick="scrollToSection('reading-b'); return false;">阅读B篇</a>
        <a href="#seven-five" onclick="scrollToSection('seven-five'); return false;">七选五</a>
        <a href="#cloze" onclick="scrollToSection('cloze'); return false;">完形填空</a>
        <a href="#grammar" onclick="scrollToSection('grammar'); return false;">语法填空</a>
    </nav> -->
</body>
</html>
```

## 注意事项

### 必须遵守

- **文章顺序必须与附件一致**
- **默认合并输出**：所有文章生成单个HTML，不等确认
- **解题前置**：七选五/完形/语法填空先统一解题，再逐篇处理
- **一次写入**：HTML片段暂存内存，最后一次性写文件，不生成临时文件
- **逐篇处理**：一篇一篇处理，避免上下文过载
- **必须添加导航和缩放按钮**：每个篇章标题带 id，底部导航栏 + 右侧缩放按钮
- 样式内嵌在head标签中
- 署名放在文档末尾：`制作者：仙游金石中学 戴元守`

### 质量要求

- 词汇高亮色在原文和词汇表中保持一致
- 确保浏览器直接打开即可呈现预期效果
- 每篇文章的处理质量保持一致
- 缩放和导航功能必须正常工作

### 处理技巧

- 如果文章内容很长，分段读取处理
- 使用临时变量存储已完成的HTML片段
- 最后统一合并，避免反复修改同一文件

## 示例调用

**输入**：
```
请处理以下英语阅读文本：
[粘贴文本内容]
```

**输出**：
完整HTML文件（可直接在浏览器打开）
