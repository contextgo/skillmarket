#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高情商职场沟通 - 话术生成辅助脚本

功能：
1. 场景识别：根据用户输入识别场景类型
2. 环境识别：识别职场环境类型
3. 话术推荐：根据场景推荐合适的话术

使用方法：
    python generate_response.py --scenario "领导批评" --environment "互联网"
    python generate_response.py --input "领导今天批评我工作失误"
"""

import argparse
import json
import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class ScenarioType(Enum):
    """场景类型枚举"""
    LEADER = "leader"           # 面对领导
    COLLEAGUE = "colleague"     # 面对同事
    SUBORDINATE = "subordinate" # 面对下属
    GOVERNMENT = "government"   # 体制内专属
    CRISIS = "crisis"           # 危机社交
    UNKNOWN = "unknown"


class EnvironmentType(Enum):
    """职场环境类型枚举"""
    GOVERNMENT = "government"     # 体制内/国企
    INTERNET = "internet"         # 互联网大厂
    FOREIGN = "foreign"           # 外企
    GENERAL = "general"           # 通用职场


@dataclass
class GuidingQuestion:
    """引导问题数据结构"""
    dimension: str        # 维度名称
    priority: int         # 优先级（0最高）
    question: str         # 引导问题
    detect_keywords: list  # 检测关键词（用户已提供则不需要问）
    scenario_types: list   # 适用场景类型


@dataclass
class Scenario:
    """场景数据结构"""
    id: str
    name: str
    type: ScenarioType
    difficulty: str
    keywords: List[str]
    template: str


# 场景关键词映射
SCENARIO_KEYWORDS = {
    # 面对领导场景
    "S01": {
        "name": "领导批评、问责、挑错",
        "type": ScenarioType.LEADER,
        "keywords": ["批评", "问责", "挑错", "失误", "被骂", "挨批", "责备", "训斥"],
        "difficulty": "⭐⭐⭐"
    },
    "S02": {
        "name": "领导临时加任务、加班",
        "type": ScenarioType.LEADER,
        "keywords": ["临时加任务", "加班", "加活", "紧急任务", "下班前"],
        "difficulty": "⭐⭐"
    },
    "S03": {
        "name": "领导画饼、模糊指令",
        "type": ScenarioType.LEADER,
        "keywords": ["画饼", "模糊指令", "口头承诺", "不确定", "看着办"],
        "difficulty": "⭐⭐⭐"
    },
    "S04": {
        "name": "领导甩锅、推卸责任",
        "type": ScenarioType.LEADER,
        "keywords": ["甩锅", "推卸责任", "背锅", "责任不清"],
        "difficulty": "⭐⭐⭐⭐"
    },
    "S05": {
        "name": "汇报工作、展示成果",
        "type": ScenarioType.LEADER,
        "keywords": ["汇报工作", "展示成果", "汇报进展", "周报", "月报"],
        "difficulty": "⭐⭐"
    },
    "S06": {
        "name": "申请资源、提困难",
        "type": ScenarioType.LEADER,
        "keywords": ["申请资源", "提困难", "要人", "要预算", "需要支持"],
        "difficulty": "⭐⭐⭐"
    },
    "S07": {
        "name": "升职加薪沟通",
        "type": ScenarioType.LEADER,
        "keywords": ["升职", "加薪", "涨工资", "晋升", "提薪"],
        "difficulty": "⭐⭐⭐⭐"
    },
    # 面对同事场景
    "S08": {
        "name": "拒绝不合理求助",
        "type": ScenarioType.COLLEAGUE,
        "keywords": ["求助", "帮忙", "请求", "同事找", "拒绝同事", "拒绝帮忙", "拒绝不合理", "不想帮"],
        "difficulty": "⭐⭐"
    },
    "S09": {
        "name": "同事甩锅、推卸工作",
        "type": ScenarioType.COLLEAGUE,
        "keywords": ["同事甩锅", "推卸工作", "推活"],
        "difficulty": "⭐⭐⭐"
    },
    "S10": {
        "name": "同事抱怨、负能量",
        "type": ScenarioType.COLLEAGUE,
        "keywords": ["抱怨", "负能量", "吐槽", "诉苦"],
        "difficulty": "⭐⭐"
    },
    "S11": {
        "name": "同事抢功、越界",
        "type": ScenarioType.COLLEAGUE,
        "keywords": ["抢功", "越界", "抢功劳", "插手"],
        "difficulty": "⭐⭐⭐"
    },
    "S12": {
        "name": "协作冲突、意见不合",
        "type": ScenarioType.COLLEAGUE,
        "keywords": ["冲突", "意见不合", "争执", "分歧", "争论"],
        "difficulty": "⭐⭐⭐"
    },
    # 面对下属场景
    "S13": {
        "name": "批评但不打击",
        "type": ScenarioType.SUBORDINATE,
        "keywords": ["批评下属", "指导下属", "纠正下属"],
        "difficulty": "⭐⭐⭐"
    },
    "S14": {
        "name": "布置任务、激励",
        "type": ScenarioType.SUBORDINATE,
        "keywords": ["布置任务", "分配工作", "激励", "安排工作"],
        "difficulty": "⭐⭐"
    },
    "S15": {
        "name": "处理下属情绪问题",
        "type": ScenarioType.SUBORDINATE,
        "keywords": ["下属情绪", "员工情绪", "下属状态"],
        "difficulty": "⭐⭐⭐"
    },
    # 体制内场景
    "S16": {
        "name": "开会表态、发言",
        "type": ScenarioType.GOVERNMENT,
        "keywords": ["开会表态", "会议发言", "会上说", "表态"],
        "difficulty": "⭐⭐"
    },
    "S17": {
        "name": "领导问话打太极",
        "type": ScenarioType.GOVERNMENT,
        "keywords": ["打太极", "领导问话", "被问", "敏感问题"],
        "difficulty": "⭐⭐⭐⭐"
    },
    "S18": {
        "name": "推活不伤人、保身",
        "type": ScenarioType.GOVERNMENT,
        "keywords": ["推活", "推事", "不接活"],
        "difficulty": "⭐⭐⭐"
    },
    "S19": {
        "name": "酒桌应酬场面话",
        "type": ScenarioType.GOVERNMENT,
        "keywords": ["酒桌", "应酬", "敬酒", "饭局", "场面话"],
        "difficulty": "⭐⭐⭐"
    },
    # 危机场景
    "S20": {
        "name": "道歉不卑微",
        "type": ScenarioType.CRISIS,
        "keywords": ["道歉", "说对不起", "认错"],
        "difficulty": "⭐⭐"
    },
    "S21": {
        "name": "化解尴尬、圆场",
        "type": ScenarioType.CRISIS,
        "keywords": ["尴尬", "圆场", "化解", "冷场"],
        "difficulty": "⭐⭐⭐"
    },
    "S22": {
        "name": "被当众刁难",
        "type": ScenarioType.CRISIS,
        "keywords": ["刁难", "当众质疑", "被针对", "被怼"],
        "difficulty": "⭐⭐⭐⭐"
    },
    "S23": {
        "name": "拒绝邀约、请假",
        "type": ScenarioType.CRISIS,
        "keywords": ["拒绝邀约", "请假", "不去", "有事"],
        "difficulty": "⭐⭐"
    },
}

# 引导问题库 - 按场景类型分类
GUIDING_QUESTIONS = {
    # P0: 职场环境（所有场景通用）
    "P0_environment": {
        "dimension": "职场环境",
        "priority": 0,
        "question": "你在什么类型的单位？（体制内/国企、互联网大厂、外企、还是普通企业）",
        "detect_keywords": ["机关", "事业单位", "国企", "编制", "体制内", "体制", "政府", "局里", "单位", "互联网", "大厂", "创业公司", "外企", "跨国", "私企", "民企", "中小企业", "传统行业"],
        "scenario_types": ["leader", "colleague", "subordinate", "government", "crisis"]
    },
    # P1: 对方身份
    "P1_target_identity": {
        "dimension": "对方身份",
        "priority": 1,
        "question": "对方是你的直属领导、跨级领导、还是平级同事？",
        "detect_keywords": ["直属", "跨级", "一把手", "二把手", "主管", "经理", "总监", "老总", "处长", "科长", "部长", "主任", "同事", "平级", "同级"],
        "scenario_types": ["leader", "colleague"]
    },
    # P1: 沟通渠道/公开程度
    "P1_channel": {
        "dimension": "沟通渠道",
        "priority": 1,
        "question": "是一对一私下沟通，还是有其他人在场？",
        "detect_keywords": ["当面", "私下", "一对一", "当众", "公开", "会议", "群里", "微信", "邮件", "电话", "部门会", "全员", "周会"],
        "scenario_types": ["leader", "colleague", "subordinate", "government", "crisis"]
    },
    # P2: 你的职位层级
    "P2_position": {
        "dimension": "你的职位",
        "priority": 2,
        "question": "你是基层员工还是带团队的管理者？",
        "detect_keywords": ["员工", "专员", "主管", "经理", "总监", "组长", "负责人", "管理者", "中层", "高管", "普通员工"],
        "scenario_types": ["leader", "colleague", "government"]
    },
    # P2: 对方性格
    "P2_personality": {
        "dimension": "对方性格",
        "priority": 2,
        "question": "对方平时是什么性格？强势型还是比较温和？",
        "detect_keywords": ["强势", "温和", "严厉", "好说话", "敏感", "直接", "含蓄", "暴躁", "冷静"],
        "scenario_types": ["leader", "colleague"]
    },
    # P2: 紧急程度
    "P2_urgency": {
        "dimension": "紧急程度",
        "priority": 2,
        "question": "是需要马上回复，还是可以准备一下？",
        "detect_keywords": ["马上", "紧急", "立刻", "急", "现在", "今晚", "来得及", "准备"],
        "scenario_types": ["leader", "colleague", "crisis"]
    },
    # 场景特有引导问题
    "S04_evidence": {
        "dimension": "书面证据",
        "priority": 1,
        "question": "你有书面证据吗？（邮件、聊天记录、会议纪要等）",
        "detect_keywords": ["证据", "记录", "截图", "邮件", "纪要", "聊天", "文字", "书面"],
        "scenario_types": ["leader", "colleague"]
    },
    "S07_contribution": {
        "dimension": "你的贡献",
        "priority": 1,
        "question": "过去一年你取得了什么突出的成果？",
        "detect_keywords": ["成果", "业绩", "完成", "达标", "超出", "增长", "提升", "贡献"],
        "scenario_types": ["leader"]
    },
    "S09_evidence": {
        "dimension": "分工证据",
        "priority": 1,
        "question": "你们之前的分工有书面记录吗？还是口头约定的？",
        "detect_keywords": ["分工", "书面", "记录", "口头", "约定", "明确"],
        "scenario_types": ["colleague"]
    },
    "S10_target": {
        "dimension": "抱怨对象",
        "priority": 1,
        "question": "TA在抱怨什么？领导、公司、还是其他同事？",
        "detect_keywords": ["抱怨领导", "吐槽公司", "说同事", "抱怨工作", "吐槽领导"],
        "scenario_types": ["colleague"]
    },
}


# 各场景推荐引导问题顺序
SCENARIO_GUIDING_ORDER = {
    "S01": ["P0_environment", "P1_channel"],
    "S02": ["P0_environment", "P1_target_identity"],
    "S03": ["P0_environment", "P2_urgency"],
    "S04": ["P0_environment", "S04_evidence"],
    "S05": ["P0_environment", "P1_target_identity"],
    "S06": ["P0_environment", "P2_urgency"],
    "S07": ["P0_environment", "S07_contribution"],
    "S08": ["P0_environment", "P1_channel"],
    "S09": ["P0_environment", "S09_evidence"],
    "S10": ["S10_target", "P1_channel"],
    "S11": ["P0_environment", "S04_evidence"],
    "S12": ["P0_environment", "P1_target_identity"],
    "S13": ["P0_environment", "P1_channel"],
    "S14": ["P0_environment", "P1_channel"],
    "S15": ["P2_urgency", "P0_environment"],
    "S16": ["P1_channel", "P1_target_identity"],
    "S17": ["P1_channel", "P1_target_identity"],
    "S18": ["P1_target_identity", "P2_position"],
    "S19": ["P1_channel", "P1_target_identity"],
    "S20": ["P0_environment", "P1_channel"],
    "S21": ["P1_channel", "P0_environment"],
    "S22": ["P0_environment", "P1_channel"],
    "S23": ["P0_environment", "P1_target_identity"],
}


# 环境关键词映射
ENVIRONMENT_KEYWORDS = {
    EnvironmentType.GOVERNMENT: [
        "机关", "事业单位", "国企", "编制", "体制内", "体制", "政府",
        "局里", "单位", "系统内", "编制内", "公务员", "事业单位"
    ],
    EnvironmentType.INTERNET: [
        "互联网", "大厂", "创业公司", "产品", "运营", "开发",
        "OKR", "迭代", "复盘", "对齐", "落地", "闭环"
    ],
    EnvironmentType.FOREIGN: [
        "外企", "跨国", "英文", "国外", "跨国公司", "海外",
        "MNC", "global", "international"
    ],
}


def identify_scenario(text: str) -> Tuple[Optional[str], float]:
    """
    识别文本对应的场景
    
    Args:
        text: 用户输入的文本
        
    Returns:
        (场景ID, 匹配置信度)
    """
    text = text.lower()
    best_match = None
    best_score = 0.0
    
    for scenario_id, scenario_data in SCENARIO_KEYWORDS.items():
        score = 0.0
        exact_matches = 0
        for keyword in scenario_data["keywords"]:
            if keyword in text:
                # 精确匹配加分（权重更高）
                score += 1.5
                exact_matches += 1
            else:
                # 模糊匹配（仅检查关键词长度>=2的子串匹配，降低权重）
                if len(keyword) >= 2:
                    for word in text:
                        if len(word) >= 2 and (keyword[:2] in word or word[:2] in keyword):
                            score += 0.15
                            break
        
        # 归一化（基于精确匹配比例为主）
        score = (exact_matches * 1.5 + score * 0.5) / len(scenario_data["keywords"])
        
        if score > best_score:
            best_score = score
            best_match = scenario_id
    
    return best_match, best_score


def identify_environment(text: str) -> EnvironmentType:
    """
    识别职场环境类型（多维度评分，选最优）
    
    Args:
        text: 用户输入的文本
        
    Returns:
        职场环境类型
    """
    text = text.lower()
    
    # 具体环境类型优先级权重（越具体越优先）
    env_weight = {
        EnvironmentType.GOVERNMENT: 1.3,  # 体制内关键词很具体
        EnvironmentType.FOREIGN: 1.3,      # 外企关键词很具体
        EnvironmentType.INTERNET: 1.0,      # 互联网关键词较通用
        EnvironmentType.GENERAL: 0.5,       # 默认
    }
    
    best_env = EnvironmentType.GENERAL
    best_score = 0
    
    for env_type, keywords in ENVIRONMENT_KEYWORDS.items():
        score = 0
        for keyword in keywords:
            if keyword.lower() in text:
                score += len(keyword)
        # 应用环境类型权重
        weighted_score = score * env_weight.get(env_type, 1.0)
        if weighted_score > best_score:
            best_score = weighted_score
            best_env = env_type
    
    return best_env


def get_template_for_scenario(scenario_id: str, environment: EnvironmentType) -> Dict:
    """
    获取场景对应的模板
    
    Args:
        scenario_id: 场景ID
        environment: 职场环境类型
        
    Returns:
        模板数据字典
    """
    if scenario_id not in SCENARIO_KEYWORDS:
        return {}
    
    scenario = SCENARIO_KEYWORDS[scenario_id]
    
    # 根据环境调整模板
    templates = {
        "general": get_general_template(scenario_id),
        "government": get_government_template(scenario_id),
        "internet": get_internet_template(scenario_id),
        "foreign": get_foreign_template(scenario_id),
    }
    
    env_key = environment.value if environment.value in templates else "general"
    
    return {
        "scenario_id": scenario_id,
        "scenario_name": scenario["name"],
        "scenario_type": scenario["type"].value,
        "difficulty": scenario["difficulty"],
        "environment": environment.value,
        "templates": templates.get(env_key, templates["general"]),
    }


def get_general_template(scenario_id: str) -> List[str]:
    """获取通用环境模板"""
    templates = {
        "S01": [
            "领导您说得对，这事确实是我考虑不周。问题出在...，我已经总结了教训，下一步会...，请您放心，类似问题不会再发生。",
            "好的，这个问题我认领。会后我会认真复盘，拿出改进方案，及时向您汇报。",
        ],
        "S02": [
            "收到。领导，这事比较急的话，我先把手头XX工作放一放，优先处理这个，您看可以吗？",
            "领导，这个任务我明白重要性。不过今晚确实有安排了，能否明天一早我第一时间处理？",
        ],
        "S08": [
            "这事我挺想帮忙的，不过手头确实有急活走不开，你看要不找找XX？或者等我忙完这段？",
            "这个我确实不擅长，不过我可以帮你问问XX，你看怎么样？",
        ],
    }
    return templates.get(scenario_id, ["请参考 references/ 目录下的详细话术库。"])


def get_government_template(scenario_id: str) -> List[str]:
    """获取体制内环境模板"""
    templates = {
        "S01": [
            "领导批评得对，这件事我确实存在...的问题，回去后我会认真反思，吸取教训，按您的要求抓好整改，确保不再出现类似问题。",
        ],
        "S16": [
            "我完全同意领导的分析和部署，下一步我们将认真贯彻落实，确保...",
            "领导的意见我完全赞同。在此基础上，我补充一点：...，请各位领导批评指正。",
        ],
        "S18": [
            "领导，这个工作的专业性比较强，建议由XX部门牵头，我们可以配合支持。",
            "领导，目前手头有XX急活，这个工作可能需要协调一下优先级，您看我先做哪个？",
        ],
    }
    return templates.get(scenario_id, get_general_template(scenario_id))


def get_internet_template(scenario_id: str) -> List[str]:
    """获取互联网环境模板"""
    templates = {
        "S01": [
            "感谢领导的反馈，这个问题确实存在。我已经复盘了原因，主要是...，后续改进方案是...，预计...时间可以看到效果。",
        ],
        "S02": [
            "收到。我理解的目标是...，预计XX时间交付，中间会同步进展。目前排期已满，需要协调优先级。",
        ],
        "S05": [
            "XX项目进展汇报：整体进度XX%，核心成果是...，目前遇到的挑战是...，下一步计划...，预计...时间交付。",
        ],
    }
    return templates.get(scenario_id, get_general_template(scenario_id))


def get_foreign_template(scenario_id: str) -> List[str]:
    """获取外企环境模板"""
    templates = {
        "S01": [
            "I take full responsibility for this issue. I've already taken steps to address it, and I'll make sure it doesn't happen again.",
        ],
        "S02": [
            "I understand this is urgent. I can prioritize this task, but I may need some support on my other deliverables.",
        ],
    }
    return templates.get(scenario_id, get_general_template(scenario_id))


def analyze_input_completeness(text: str, scenario_id: str = None) -> Dict:
    """
    分析用户输入的完整度，确定哪些关键维度缺失
    
    Args:
        text: 用户输入的文本
        scenario_id: 已识别的场景ID（可选）
        
    Returns:
        {
            "completeness_score": float,    # 完整度 0-1
            "missing_dimensions": list,       # 缺失的维度名称
            "guiding_questions": list,        # 推荐的引导问题
            "should_ask": bool,               # 是否需要追问
            "ask_round": int,                 # 当前应该第几轮
        }
    """
    text_lower = text.lower()
    detected_dimensions = set()
    
    # 检测已提供的维度
    for q_key, q_data in GUIDING_QUESTIONS.items():
        for keyword in q_data["detect_keywords"]:
            if keyword.lower() in text_lower:
                detected_dimensions.add(q_key)
                break
    
    # 确定场景推荐引导问题
    if scenario_id and scenario_id in SCENARIO_GUIDING_ORDER:
        recommended_order = SCENARIO_GUIDING_ORDER[scenario_id]
    else:
        # 默认推荐顺序
        recommended_order = ["P0_environment", "P1_channel"]
    
    # 计算缺失维度
    missing = []
    guiding_qs = []
    for q_key in recommended_order:
        if q_key not in detected_dimensions:
            q_data = GUIDING_QUESTIONS[q_key]
            # 检查是否适用于当前场景
            scenario_type = SCENARIO_KEYWORDS.get(scenario_id, {}).get("type", None)
            if scenario_type and scenario_type.value in q_data["scenario_types"]:
                missing.append(q_data["dimension"])
                guiding_qs.append(q_data["question"])
    
    # 计算完整度
    total_recommended = len(recommended_order)
    detected_count = sum(1 for q in recommended_order if q in detected_dimensions)
    completeness = detected_count / total_recommended if total_recommended > 0 else 0.0
    
    # 判断是否需要追问
    should_ask = completeness < 0.5 and len(guiding_qs) > 0
    
    # 估算当前轮次
    if completeness >= 0.5:
        ask_round = 3  # 信息基本充足，直接给结果
    elif completeness >= 0.25:
        ask_round = 2  # 有部分信息，最多再问一轮
    else:
        ask_round = 1  # 信息很少，开始第一轮追问
    
    return {
        "completeness_score": round(completeness, 2),
        "detected_dimensions": list(detected_dimensions),
        "missing_dimensions": missing,
        "guiding_questions": guiding_qs[:2],  # 最多返回2个问题
        "should_ask": should_ask,
        "ask_round": ask_round,
    }


def format_guiding_questions(questions: list, scenario_name: str = "", round_num: int = 1) -> str:
    """
    格式化引导问题，生成自然的对话式追问
    
    Args:
        questions: 引导问题列表
        scenario_name: 已识别的场景名称
        round_num: 当前轮次
        
    Returns:
        格式化的引导话术
    """
    if not questions:
        return ""
    
    # 构建自然引导话术
    if round_num == 1:
        if scenario_name:
            opening = f"我理解你是在遇到**{scenario_name}**的情况。"
        else:
            opening = "为了给你更精准的建议，"
        
        if len(questions) == 1:
            return f"{opening}想确认一个小细节：\n\n{questions[0]}"
        else:
            return f"{opening}想确认两个小细节：\n\n1. {questions[0]}\n2. {questions[1]}"
    elif round_num == 2:
        if len(questions) == 1:
            return f"再确认一个细节：{questions[0]}"
        else:
            return f"还有两个小问题：\n1. {questions[0]}\n2. {questions[1]}"
    else:
        # 第3轮，给出兜底话术
        return ""


def generate_response(text: str, ask_round: int = 1, max_rounds: int = 3) -> Dict:
    """
    根据用户输入生成回应建议（含引导逻辑）
    
    Args:
        text: 用户输入的文本
        ask_round: 当前追问轮次
        max_rounds: 最大追问轮数
        
    Returns:
        回应建议字典
    """
    # 识别场景
    scenario_id, confidence = identify_scenario(text)
    
    # 识别环境
    environment = identify_environment(text)
    
    # 分析输入完整度
    scenario_name = SCENARIO_KEYWORDS.get(scenario_id, {}).get("name", "")
    completeness = analyze_input_completeness(text, scenario_id)
    
    # 获取模板
    template_data = get_template_for_scenario(scenario_id, environment) if scenario_id else {}
    
    # 判断是否需要追问
    need_guiding = completeness["should_ask"] and ask_round < max_rounds
    
    # 格式化引导问题
    guiding_text = ""
    if need_guiding:
        guiding_text = format_guiding_questions(
            completeness["guiding_questions"],
            scenario_name,
            ask_round
        )
    elif ask_round == max_rounds or completeness["completeness_score"] >= 0.5:
        # 第3轮或信息充足，给出话术 + 兜底提示
        if completeness["missing_dimensions"]:
            guiding_text = f"以下是基于目前信息的建议。如果你能告诉我{completeness['missing_dimensions'][0]}等细节，我可以帮你调整得更精准。"
    
    return {
        "input": text,
        "ask_round": ask_round,
        "completeness": completeness,
        "need_guiding": need_guiding,
        "guiding_text": guiding_text,
        "identified_scenario": {
            "id": scenario_id,
            "name": scenario_name if scenario_name else "未识别",
            "confidence": round(confidence, 2),
        },
        "identified_environment": {
            "type": environment.value,
            "name": {
                "government": "体制内/国企",
                "internet": "互联网大厂",
                "foreign": "外企/国际化",
                "general": "通用职场",
            }.get(environment.value, "通用职场"),
        },
        "templates": template_data.get("templates", []),
        "reference_file": f"references/scenarios_{template_data.get('scenario_type', 'crisis')}.md",
    }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="高情商职场沟通 - 话术生成辅助脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python generate_response.py --input "领导今天批评我工作失误"
  python generate_response.py --scenario "S01" --environment "互联网"
  python generate_response.py --list-scenarios
        """
    )
    
    parser.add_argument(
        "--input", "-i",
        type=str,
        help="用户输入的文本，自动识别场景和环境"
    )
    
    parser.add_argument(
        "--scenario", "-s",
        type=str,
        help="指定场景ID（如S01、S02等）"
    )
    
    parser.add_argument(
        "--environment", "-e",
        type=str,
        choices=["government", "internet", "foreign", "general"],
        help="指定职场环境类型"
    )
    
    parser.add_argument(
        "--list-scenarios",
        action="store_true",
        help="列出所有场景"
    )
    
    parser.add_argument(
        "--output", "-o",
        type=str,
        choices=["json", "text"],
        default="text",
        help="输出格式"
    )
    
    parser.add_argument(
        "--round", "-r",
        type=int,
        default=1,
        help="当前追问轮次（1-3）"
    )
    
    parser.add_argument(
        "--analyze", "-a",
        action="store_true",
        help="仅分析输入完整度，不生成话术"
    )
    
    args = parser.parse_args()
    
    # 列出所有场景
    if args.list_scenarios:
        print("\n=== 所有场景列表 ===\n")
        current_type = None
        for scenario_id, scenario_data in SCENARIO_KEYWORDS.items():
            if scenario_data["type"] != current_type:
                current_type = scenario_data["type"]
                print(f"\n【{current_type.value.upper()}】")
            print(f"  {scenario_id}: {scenario_data['name']} {scenario_data['difficulty']}")
        print()
        return
    
    # 指定场景和环境
    if args.scenario and args.environment:
        env = EnvironmentType(args.environment)
        result = get_template_for_scenario(args.scenario, env)
        result["input"] = f"指定场景: {args.scenario}, 环境: {args.environment}"
        result["need_guiding"] = False
        result["completeness"] = {"completeness_score": 1.0, "missing_dimensions": []}
    # 仅分析完整度
    elif args.input and args.analyze:
        scenario_id, confidence = identify_scenario(args.input)
        scenario_name = SCENARIO_KEYWORDS.get(scenario_id, {}).get("name", "")
        completeness = analyze_input_completeness(args.input, scenario_id)
        environment = identify_environment(args.input)
        
        result = {
            "input": args.input,
            "identified_scenario": {"id": scenario_id, "name": scenario_name, "confidence": round(confidence, 2)},
            "identified_environment": {"type": environment.value, "name": {"government": "体制内/国企", "internet": "互联网大厂", "foreign": "外企/国际化", "general": "通用职场"}.get(environment.value, "通用职场")},
            "completeness": completeness,
            "need_guiding": completeness["should_ask"],
            "guiding_text": format_guiding_questions(completeness["guiding_questions"], scenario_name, 1),
        }
    # 自动识别
    elif args.input:
        round_num = args.round if hasattr(args, 'round') and args.round else 1
        result = generate_response(args.input, ask_round=round_num)
    else:
        parser.print_help()
        return
    
    # 输出结果
    if args.output == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("\n" + "="*60)
        print("高情商职场沟通 - 话术建议")
        print("="*60)
        
        if result.get("identified_scenario"):
            scenario = result["identified_scenario"]
            print(f"\n【识别场景】{scenario.get('name', '未识别')} (置信度: {scenario.get('confidence', 0):.0%})")
        
        if result.get("identified_environment"):
            env = result["identified_environment"]
            print(f"【职场环境】{env.get('name', '通用职场')}")
        
        if result.get("completeness"):
            comp = result["completeness"]
            print(f"【信息完整度】{comp.get('completeness_score', 0):.0%} (第{result.get('ask_round', 1)}轮)")
            if comp.get("missing_dimensions"):
                print(f"【缺失维度】{', '.join(comp['missing_dimensions'])}")
        
        if result.get("need_guiding") and result.get("guiding_text"):
            print(f"\n【建议追问】\n{result['guiding_text']}")
            print("\n（用户回答后再次调用，进入下一轮）")
        
        if not result.get("need_guiding") and result.get("guiding_text"):
            print(f"\n【提示】{result['guiding_text']}")
        
        if result.get("templates") and not result.get("need_guiding"):
            print("\n【推荐话术】\n")
            for i, template in enumerate(result["templates"], 1):
                print(f"话术{i}:\n{template}\n")
        
        if result.get("reference_file"):
            print(f"\n【详细话术库】请参考: {result['reference_file']}")
        
        print("="*60 + "\n")


if __name__ == "__main__":
    main()
