#!/bin/bash
# wechat-public-article-bomber - 全自动公众号爆文创作工具
# Version: 2.1
# Update: 2026-04-16 新增微信公众平台AI内容合规检测引擎，自动优化高风险内容，应对2026年4月最新封禁政策
# Usage: ./wechat-public-article-bomber.sh "文章主题"

set -e

# 加载环境变量
if [ -f "/root/.openclaw/workspace/.env" ]; then
    source /root/.openclaw/workspace/.env
fi

# 检查依赖
check_dependency() {
    if [ ! -d "/root/.openclaw/workspace/skills/$1" ]; then
        echo "❌ 缺少依赖技能: $1"
        echo "请先运行: skillhub install $1"
        exit 1
    fi
}

check_dependency "wechat-mp-cn"
check_dependency "wechat-publisher"
check_dependency "image-generate"
check_dependency "content-creator-cn"
check_dependency "humanizer"
check_dependency "skill-refiner"

THEME="$1"
if [ -z "$THEME" ]; then
    echo "Usage: $0 \"文章主题\""
    exit 1
fi

echo "🚀 启动全自动公众号爆文创作"
echo "📝 主题: $THEME"
echo "========================================"

# 1. 创建工作目录
TIMESTAMP=$(date +%s)
WORKDIR="/root/.openclaw/workspace/wechat-public-article-bomber-work/$TIMESTAMP"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "📂 工作目录: $WORKDIR"

# 2. 调用 content-creator-cn 生成初稿
echo "🔍 Step 1/6: 创作初稿..."
# 生成初稿
cat > prompt.txt <<EOF
请创作一篇关于《$THEME》的公众号爆文，要求：
1. 标题吸引眼球，有点击率
2. 内容结构清晰，逻辑通顺
3. 口语化表达，有亲和力
4. 字数不少于1500字
5. 包含案例、数据、观点三个部分
6. 结尾有总结和互动引导
EOF
# 调用AI生成初稿
python /root/.openclaw/workspace/skills/content-creator-cn/scripts/generate.py "$(cat prompt.txt)" > content.md

# 3. humanizer 去AI化
echo "🧹 Step 2/6: 消除AI痕迹..."
python /root/.openclaw/workspace/skills/humanizer/scripts/humanize.py content.md > content_humanized.md
mv content_humanized.md content.md

# 4. skill-refiner 精炼内容
echo "✨ Step 3/7: 精炼内容..."
python /root/.openclaw/workspace/skills/skill-refiner/scripts/refine.py content.md > content_refined.md
mv content_refined.md content.md

# 3.5 合规检测优化（应对微信2026年4月AI内容封禁政策）
echo "🛡️ Step 4/7: 微信公众平台合规检测优化..."
cat > compliance.js << 'EOF'
const fs = require('fs');
const content = fs.readFileSync('content.md', 'utf8');

// 敏感词库（包含AI专项封禁词）
const SENSITIVE_WORDS = [
  'ChatGPT', 'GPT', 'GPT-4', 'GPT-4o', 'OpenAI',
  '大模型', 'AI生成', '人工智能生成', 'AI写作', 'AI创作', 'AI自动生成',
  'AI绘画', 'AI生成内容', 'AI写文章', 'AI生成图片', '人工智能写作',
  '最高级', '最佳', '顶级', '第一', '唯一', '国家级', '全网第一'
];

// AI内容特征词
const AI_FEATURES = [
  '首先', '其次', '最后', '综上所述', '总的来说', '需要注意的是',
  '值得一提的是', '一般来说', '通常情况下', '根据相关研究', '据统计'
];

// 自动合规优化
let optimized = content;
// 1. 替换AI相关敏感词
for (const word of SENSITIVE_WORDS) {
  const regex = new RegExp(word, 'g');
  optimized = optimized.replace(regex, '智能工具');
}
// 2. 增加个人化表述提升原创度
const personalAdditions = [
  '我个人觉得', '根据我的实际使用经验', '我最近发现',
  '我亲测有效', '分享一下我的看法', '我自己用了很久'
];
const randomAdd = personalAdditions[Math.floor(Math.random() * personalAdditions.length)];
const firstParaEnd = optimized.indexOf('\n\n');
if (firstParaEnd > -1) {
  optimized = optimized.slice(0, firstParaEnd) + `\n${randomAdd}，` + optimized.slice(firstParaEnd);
}
// 3. 随机删除部分AI特征表述
for (const feature of AI_FEATURES) {
  if (Math.random() > 0.6) {
    optimized = optimized.replace(new RegExp(feature + '，?', 'g'), '');
  }
}

fs.writeFileSync('content.md', optimized, 'utf8');
console.log('✅ 合规优化完成：已自动替换敏感词、提升原创度、消除AI特征');
EOF
node compliance.js
rm -f compliance.js

# 5. 生成图片
echo "🖼️  Step 5/7: 生成封面和插图..."
# 封面
COVER_IMAGE="cover_${TIMESTAMP}_0.png"
python /root/.openclaw/workspace/skills/image-generate/scripts/image_generate.py "公众号封面图 $THEME"
mv ./*.png "$COVER_IMAGE"

# 6. 创建Markdown文件并发布
echo "📄 Step 6/7: 组装文章..."
cat > article.md <<EOF
---
title: $THEME
cover: $PWD/$COVER_IMAGE
---

$(cat content.md)
EOF

echo "🚀 Step 7/7: 发布到公众号草稿箱..."
cd /root/.openclaw/workspace/skills/wechat-publisher
./scripts/publish.sh "$WORKDIR/article.md"

echo "========================================"
echo "✅ 创作完成！请前往公众号后台草稿箱查看。"
echo "📁 工作目录: $WORKDIR"
