---
name: CurrConv
description: "Convert currencies with live exchange rates and trend comparisons. Use when converting currencies, checking rates, tracking rate trends."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["currency","converter","exchange","rate","money","finance","forex","international"]
categories: ["Finance", "Utility"]
---
# CurrConv

Personal finance toolkit for recording transactions, categorizing expenses, tracking balances, analyzing spending trends, forecasting budgets, and generating financial reports. All data is stored locally in timestamped log files.

## Commands

### Core Finance Commands

| Command | Description |
|---------|-------------|
| `currconv record <input>` | Record a financial transaction or entry. Without arguments, shows recent records. |
| `currconv categorize <input>` | Categorize a transaction (e.g., food, transport, entertainment). Without arguments, shows recent categorizations. |
| `currconv balance <input>` | Log a balance snapshot or account balance update. Without arguments, shows recent balance entries. |
| `currconv trend <input>` | Record a spending or income trend observation. Without arguments, shows recent trend entries. |
| `currconv forecast <input>` | Log a financial forecast or projection. Without arguments, shows recent forecasts. |
| `currconv export-report <input>` | Generate or log an export report entry. Without arguments, shows recent export reports. |
| `currconv budget-check <input>` | Record a budget check or budget status note. Without arguments, shows recent budget checks. |
| `currconv summary <input>` | Log a financial summary or period recap. Without arguments, shows recent summaries. |
| `currconv alert <input>` | Set or record a financial alert (e.g., overspending warning). Without arguments, shows recent alerts. |
| `currconv history <input>` | Log or view transaction history notes. Without arguments, shows recent history entries. |
| `currconv compare <input>` | Record a comparison between periods, accounts, or categories. Without arguments, shows recent comparisons. |
| `currconv tax-note <input>` | Log a tax-related note or deduction reminder. Without arguments, shows recent tax notes. |

### Utility Commands

| Command | Description |
|---------|-------------|
| `currconv stats` | Show summary statistics across all log categories (entry counts, data size, first entry date). |
| `currconv export <format>` | Export all data in `json`, `csv`, or `txt` format. Output saved to the data directory. |
| `currconv search <term>` | Search across all log files for a keyword or phrase (case-insensitive). |
| `currconv recent` | Show the 20 most recent entries from the activity history log. |
| `currconv status` | Health check — shows version, data directory, total entries, disk usage, and last activity. |
| `currconv help` | Display all available commands and usage information. |
| `currconv version` | Show the current version (v2.0.0). |

## Data Storage

All data is stored in `~/.local/share/currconv/` as plain-text log files:

- Each command category has its own `.log` file (e.g., `record.log`, `balance.log`, `tax-note.log`)
- Entries are timestamped in `YYYY-MM-DD HH:MM|value` format
- A central `history.log` tracks all activity across commands
- Export files are saved as `export.json`, `export.csv`, or `export.txt` in the same directory

## Requirements

- Bash 4.0+ (uses `set -euo pipefail`)
- Standard Unix utilities: `date`, `wc`, `du`, `head`, `tail`, `grep`, `cut`
- No external API keys or network access required
- No additional dependencies to install

## When to Use

1. **Tracking daily expenses** — Use `record` and `categorize` to log every transaction with categories for later analysis.
2. **Monitoring account balances** — Use `balance` to snapshot your bank or wallet balances over time and spot discrepancies.
3. **Budget planning and forecasting** — Use `forecast` and `budget-check` to project future spending and verify you're staying within limits.
4. **Tax season preparation** — Use `tax-note` to capture deduction-eligible expenses and tax reminders throughout the year.
5. **Periodic financial reviews** — Use `summary`, `trend`, and `compare` to review spending patterns across weeks, months, or categories.

## Examples

### Record a transaction and categorize it
```bash
currconv record "Coffee shop $4.50"
currconv categorize "Coffee shop $4.50 — food"
```

### Check your balance and set a budget alert
```bash
currconv balance "Checking account: $2,340.00"
currconv budget-check "March food budget: $180/$300 used"
currconv alert "Food spending at 60% of monthly budget"
```

### Log a tax note and export all data
```bash
currconv tax-note "Home office deduction — desk purchase $450"
currconv export json
currconv export csv
```

### Search and review activity
```bash
currconv search "coffee"
currconv recent
currconv stats
currconv status
```

### Compare periods and forecast
```bash
currconv compare "Feb vs Mar food spending: $280 vs $310"
currconv trend "Food spending up 10% month-over-month"
currconv forecast "April food budget should be $320 based on trend"
currconv summary "Q1 total spending: $4,200 across all categories"
```

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
