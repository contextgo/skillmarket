# 成长档案结构与状态字段

本文件定义雷克斯｜GTM 搭档的成长档案（memory）结构。每次建档、桥接、复盘后，必须按本文件定义的字段写回。

---

## 一、成长档案的本质

成长档案不是聊天记录，而是结构化的用户成长状态快照。

它解决的核心问题：
- 用户再次进入时，系统不从零开始
- 复盘时能结合用户的岗位背景和桥接判断做差异化解释
- 每次复盘积累为可查看的成长轨迹

**WorkBuddy 实现方式：** 将成长档案写入当前工作空间的 `.workbuddy/memory/` 目录下，以 `GTM_growth_profile.md` 文件存储。不依赖全量对话历史，只存结构化摘要。

---

## 二、5 个核心数据对象

### 对象 1：UserProfile（用户基础信息）

```yaml
userId: [自动生成或用户名]
userName: [用户称呼]
currentRoleRaw: [用户原始岗位描述]
sourceRoleType: 内容类 / 销售类 / 产品类
yearsOfExperience: [工作年限]
mainDailyWork: [最常做的工作描述]
workPatternTags: [工作习惯标签]
transitionMotivation: [转向 GTM 的动机]
selfPerceivedStrength: [用户自述顺手的部分]
selfPerceivedBlock: [用户自述容易卡住的部分]
onboardingSummary: [建档摘要，2-3句]
```

### 对象 2：BridgeAssessment（岗位桥接判断）

```yaml
bridgeCompleted: true / false
transitionFeasibilityLevel: 可行性较高 / 可行性中等 / 可行性待观察
transferableStrengths:
  - [优势1]
  - [优势2]
keyGaps:
  - [关键短板1]
  - [关键短板2（如有）]
primaryGrowthFocus: [主优先补齐方向]
secondaryGrowthFocus: [次优先补齐方向]
bridgeTags:
  source_role_type: 内容类 / 销售类 / 产品类
  gap_tags: [gap标签列表]
  strength_tags: [strength标签列表]
bridgeAssessmentSummary: [桥接判断摘要，3-4句]
bridgeLastUpdatedAt: [日期]
```

### 对象 3：ReflectionRecord（单次复盘记录）

每次复盘生成一条，追加存储：

```yaml
reflectionId: [自增ID]
reflectionDate: [日期]
eventType: 汇报类 / 协同类 / 方案类 / 推进类
eventSummary: [事件描述，2-3句]
eventGoal: [用户目标]
userActionSummary: [用户动作]
resultFeedbackSummary: [结果与反馈]
mainExposedIssue: [主要暴露的问题]
relatedCapabilityPrimary: [主要关联能力]
relatedCapabilitySecondary: [次要关联能力，如有]
actionSuggestionSummary: [下一步改进动作]
followUpStatus: pending / resolved / dropped
```

### 对象 4：GrowthState（成长状态摘要）

```yaml
reflectionRecordCount: [累计复盘次数]
lastReflectionDate: [最近复盘日期]
repeatedIssueTags: [高频重复问题标签]
recentReflectionSummary: [最近1-3次复盘要点]
currentPrimaryFocus: [当前主要成长方向]
currentSecondaryFocus: [当前次要成长方向]
stageReviewAvailable: true / false
```

### 对象 5：UIFlowState（流程状态）

```yaml
isFirstVisit: true / false
onboardingCompleted: true / false
bridgeCompleted: true / false
currentFlowStage: welcome / onboarding / bridge_assessment / reflection / stage_review
currentPromptModule: prompt_onboarding / prompt_bridge / prompt_reflection
readyForReflection: true / false
readyForStageReview: true / false
```

---

## 三、流程状态推进规则

```
初始状态:
  isFirstVisit = true
  onboardingCompleted = false
  bridgeCompleted = false
  currentFlowStage = welcome

建档中:
  currentFlowStage = onboarding

建档完成 → 进入桥接:
  onboardingCompleted = true
  currentFlowStage = bridge_assessment

桥接完成 → 进入复盘:
  bridgeCompleted = true
  readyForReflection = true
  currentFlowStage = reflection

复盘中:
  currentFlowStage = reflection

累计复盘 ≥ 5 次（预留）:
  stageReviewAvailable = true
  readyForStageReview = true
```

---

## 四、GTM 底层能力框架（后台映射用）

以下 5 项能力作为后台判断兜底，不直接展示给用户：

1. **用户与市场理解能力** — 能否理解真实用户需求和市场变化
2. **产品理解与价值提炼能力** — 能否把产品翻译成用户/市场语言
3. **结构化表达与信息输出能力** — 能否把复杂信息整理成清晰判断
4. **跨部门协同与推进能力** — 能否推动跨团队目标达成
5. **商业判断与优先级能力** — 能否连接动作与业务目标

复盘时，`relatedCapabilityPrimary` 和 `relatedCapabilitySecondary` 从以上 5 项中选取，但前台不用直接说"你的能力3不足"，而是翻译成岗位语言。

---

## 五、成长档案文件模板

在 `.workbuddy/memory/GTM_growth_profile.md` 中存储，格式如下：

```markdown
# GTM 成长档案

更新时间：[YYYY-MM-DD]

## 用户基础信息
- 岗位：[currentRoleRaw]
- 来源岗位类型：[sourceRoleType]
- 工作年限：[yearsOfExperience]
- 转型动机：[transitionMotivation]

## 桥接判断摘要
- 可行性：[transitionFeasibilityLevel]
- 可迁移优势：[transferableStrengths]
- 关键差距：[keyGaps]
- 主优先方向：[primaryGrowthFocus]
- 次优先方向：[secondaryGrowthFocus]
- 桥接摘要：[bridgeAssessmentSummary]

## 成长状态
- 累计复盘次数：[reflectionRecordCount]
- 最近复盘日期：[lastReflectionDate]
- 高频问题标签：[repeatedIssueTags]
- 当前重点方向：[currentPrimaryFocus]

## 最近复盘记录
[最近 1-3 条 ReflectionRecord，追加展示]

## 流程状态
- 建档完成：[onboardingCompleted]
- 桥接完成：[bridgeCompleted]
- 可进入阶段总结：[stageReviewAvailable]
```
