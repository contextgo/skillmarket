# 🏷️ Text Classifier Pro

> AI 驱动的文本分类打标工具 — 上传文本/CSV，AI 自动分类，输出结构化标签 + 置信度

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![License](https://img.shields.io/badge/License-Proprietary-red.svg)

## ✨ 功能特性

### 📥 输入方式
- **纯文本粘贴** — 直接在文本框输入，每行一条
- **TXT 文件** — 自动解析，每行一条
- **CSV 文件** — pandas 自动识别文本列，支持 GBK/UTF-8 编码

### 🏷️ 预设分类模板（开箱即用）

| 分类器 | 说明 |
|--------|------|
| 意图分类 | 咨询 / 投诉 / 退款 / 合作 |
| 情感分类 | 正面 / 中性 / 负面 |
| 行业分类 | 金融 / 医疗 / 教育 / 零售 / 制造 |
| 风险分类 | 合规 / 违规 / 可疑 |
| 优先级分类 | 高 / 中 / 低 |
| 内容分类 | 新闻 / 广告 / UGC / 垃圾 |

### 🤖 AI 分类
- 支持 OpenAI GPT-3.5 / GPT-4 / GPT-4 Turbo
- 自定义分类标签 + 自定义 Prompt
- 返回分类标签 + 置信度（套餐相关）

### 📤 输出格式
- 🖥️ **屏幕显示** — Markdown 表格
- 📄 **CSV** — Excel 友好 UTF-8 编码
- 📊 **Excel** — xlsx 格式
- 📋 **JSON** — 完整结构化数据

---

## 💰 套餐价格

| 功能 | FREE | STD ¥9.9 | PRO ¥29.9 | MAX ¥99 |
|------|------|---------|-----------|---------|
| 分类次数 | 20次（不清零） | 200次/天 | 2000次/天 | 不限 |
| 输入方式 | 文字粘贴 | 文字+文件 | 文字+文件+API | 全部 |
| 预设分类器 | 3种 | 10种 | 50种 | 不限 |
| 自定义分类 | ❌ | ✅ | ✅ | ✅ |
| 批量处理 | ❌ | ✅ 50条 | ✅ 500条 | ✅ 5000条 |
| 置信度显示 | ❌ | ✅ | ✅ | ✅ |
| 历史记录 | ❌ | 7天 | 90天 | 365天 |
| API 访问 | ❌ | ❌ | ✅ | ✅ |

---

## 🚀 快速开始

### 环境要求
- Python 3.8+
- OpenAI API Key

### 安装

```bash
cd /home/gem/workspace/agent/workspace/text-classifier
pip install -r requirements.txt
```

### 启动 Web 界面

```bash
python scripts/web_app.py
```

访问 **http://localhost:5000**

### 命令行使用

```bash
# 单条文本分类
python -m scripts.classifier \
  --text "这个产品很好用" \
  --classifier "情感分类" \
  --api-key "sk-your-key"

# CSV 文件批量分类
python -m scripts.classifier \
  --file reviews.csv \
  --classifier "情感分类" \
  --api-key "sk-your-key" \
  --output csv \
  --output-path results.csv

# 自定义标签
python -m scripts.classifier \
  --text "紧急问题" \
  --custom-labels "高,中,低" \
  --custom-prompt "请判断以下问题的优先级" \
  --api-key "sk-your-key"
```

### Python API

```python
from scripts.classifier import (
    validate_token, classify_text, classify_batch,
    parse_csv, format_results_markdown,
    export_csv, export_json
)

# 验证 License Token
tier = validate_token("TEXT-CLS-PRO-xxxx")
print(f"当前套餐: {tier}")

# 单条分类
result = classify_text(
    text="产品非常好用，物流也很快",
    classifier_name="情感分类",
    api_key="sk-...",
    show_confidence=True
)
print(result)
# {'label': '正面', 'confidence': 0.85, 'raw': '正面', 'classifier': '情感分类', 'text_preview': '产品非常好用...'}

# 批量分类
results = classify_batch(
    texts=["很好", "一般", "很差"],
    classifier_name="情感分类",
    api_key="sk-...",
    show_confidence=True
)

# 格式化输出
print(format_results_markdown(results, show_confidence=True))
```

---

## 📁 项目结构

```
text-classifier/
├── scripts/
│   ├── __init__.py
│   ├── classifier.py      # 核心分类逻辑、Token 验证、文件解析、导入导出
│   └── web_app.py         # Flask Web 界面
├── SKILL.md               # 技能说明文档
├── README.md              # 本文档
├── requirements.txt       # Python 依赖
└── test_text_classifier.py # 单元测试
```

---

## 🔧 配置说明

### 环境变量

| 变量 | 说明 |
|------|------|
| `OPENAI_API_KEY` | OpenAI API Key（可替代命令行参数） |
| `SECRET_KEY` | Flask 密钥 |
| `PORT` | Web 服务端口（默认 5000） |

### Token 验证

验证接口：`POST https://api.yk-global.com/v1/verify`

```
Authorization: Bearer {api_key}
Content-Type: application/json
Body: {}

Response: {"valid": "TEXT-CLS-PRO"}
```

支持的 Token 前缀：
- `TEXT-CLS-FREE` — 免费版
- `TEXT-CLS-STD` — 标准版
- `TEXT-CLS-PRO` — 专业版
- `TEXT-CLS-MAX` — 旗舰版

> 网络错误自动降级 FREE，不阻断使用

---

## 🧪 测试

```bash
cd /home/gem/workspace/agent/workspace/text-classifier
pip install pytest pandas openpyxl
pytest test_text_classifier.py -v
```

---

## 📝 更新日志

### v1.0.0 (2026-04-21)
- 初始版本
- 支持 6 大预设分类模板
- 支持自定义标签和 Prompt
- CSV/TXT 文件解析
- 多格式导出（CSV/Excel/JSON）
- Token 验证与套餐限制
- Web 界面

---

## 📞 支持

如有问题或建议，请访问 [YK-Global.com](https://yk-global.com)

---

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)
