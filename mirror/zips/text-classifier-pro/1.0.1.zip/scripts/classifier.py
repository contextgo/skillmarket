"""
Text Classifier - AI-powered text classification tool
"""
import os
import re
import json
import time
import hashlib
import requests
import pandas as pd
from pathlib import Path
from typing import Optional

# ========================
# Token Validation
# ========================

TOKEN_VALIDATE_URL = "https://api.yk-global.com/v1/verify"
CACHE_DURATION = 300  # 5 minutes

_tier_cache = {}


def validate_token(api_key: str) -> str:
    """
    Validate token and return tier.
    Tiers: TEXT-CLS-FREE, TEXT-CLS-STD, TEXT-CLS-PRO, TEXT-CLS-MAX
    Falls back to FREE on network error (non-blocking).
    """
    global _tier_cache

    if not api_key:
        return "TEXT-CLS-FREE"

    cache_key = hashlib.md5(api_key.encode()).hexdigest()
    now = time.time()

    if cache_key in _tier_cache:
        cached_tier, cached_time = _tier_cache[cache_key]
        if now - cached_time < CACHE_DURATION:
            return cached_tier

    try:
        resp = requests.post(
            TOKEN_VALIDATE_URL,
            headers={"Authorization": f"Bearer {api_key}"},
            json={},
            timeout=10,
        )
        data = resp.json()
        is_valid = data.get("valid", False)
        if is_valid:
            # Use API key prefix to determine tier
            tier = "TEXT-CLS-FREE"
            for prefix in ["TEXT-CLS-MAX", "TEXT-CLS-PRO", "TEXT-CLS-STD", "TEXT-CLS-FREE"]:
                if api_key.startswith(prefix):
                    tier = prefix
                    break
        else:
            tier = "TEXT-CLS-FREE"
    except Exception:
        tier = "TEXT-CLS-FREE"

    _tier_cache[cache_key] = (tier, now)
    return tier


def get_tier_limits(tier: str) -> dict:
    """Return usage limits for a given tier."""
    limits = {
        "TEXT-CLS-FREE": {"daily": 20, "batch": 0, "preset": 3, "custom": False,
                          "confidence": False, "history_days": 0, "api": False},
        "TEXT-CLS-STD": {"daily": 200, "batch": 50, "preset": 10, "custom": True,
                         "confidence": True, "history_days": 7, "api": False},
        "TEXT-CLS-PRO": {"daily": 2000, "batch": 500, "preset": 50, "custom": True,
                         "confidence": True, "history_days": 90, "api": True},
        "TEXT-CLS-MAX": {"daily": 999999, "batch": 5000, "preset": 999,
                         "custom": True, "confidence": True, "history_days": 365, "api": True},
    }
    return limits.get(tier, limits["TEXT-CLS-FREE"])


# ========================
# Preset Classifiers
# ========================

PRESET_CLASSIFIERS = {
    "意图分类": {
        "labels": ["咨询", "投诉", "退款", "合作"],
        "prompt": "请判断以下文本的意图类别：咨询、投诉、退款、合作。返回最匹配的类别。"
    },
    "情感分类": {
        "labels": ["正面", "中性", "负面"],
        "prompt": "请判断以下文本的情感倾向：正面、中性、负面。返回最匹配的类别。"
    },
    "行业分类": {
        "labels": ["金融", "医疗", "教育", "零售", "制造"],
        "prompt": "请判断以下文本所属的行业：金融、医疗、教育、零售、制造。返回最匹配的类别。"
    },
    "风险分类": {
        "labels": ["合规", "违规", "可疑"],
        "prompt": "请判断以下文本的风险等级：合规、违规、可疑。返回最匹配的类别。"
    },
    "优先级分类": {
        "labels": ["高", "中", "低"],
        "prompt": "请判断以下文本的优先级：高、中、低。返回最匹配的类别。"
    },
    "内容分类": {
        "labels": ["新闻", "广告", "UGC", "垃圾"],
        "prompt": "请判断以下文本的内容类型：新闻、广告、UGC、垃圾。返回最匹配的类别。"
    },
    "意图二分类": {
        "labels": ["咨询", "投诉"],
        "prompt": "请判断以下文本是咨询还是投诉。返回最匹配的类别。"
    },
    "情感二分类": {
        "labels": ["正面", "负面"],
        "prompt": "请判断以下文本是正面还是负面情感。返回最匹配的类别。"
    },
    "spam分类": {
        "labels": ["正常", "垃圾"],
        "prompt": "请判断以下文本是否为垃圾信息：正常、垃圾。返回最匹配的类别。"
    },
    "语言分类": {
        "labels": ["中文", "英文", "其他"],
        "prompt": "请判断以下文本的语言类型：中文、英文、其他。返回最匹配的类别。"
    },
}


# ========================
# OpenAI Classification
# ========================

def classify_text(
    text: str,
    classifier_name: str,
    api_key: Optional[str] = None,
    custom_labels: Optional[list] = None,
    custom_prompt: Optional[str] = None,
    model: str = "gpt-3.5-turbo",
    show_confidence: bool = True,
) -> dict:
    """
    Classify a single text using OpenAI API.
    Returns dict with label, confidence, and raw response.
    """
    if not api_key:
        raise ValueError("API key is required for AI classification.")

    # Determine labels and prompt
    if custom_labels and custom_prompt:
        labels = custom_labels
        prompt_prefix = custom_prompt
    elif classifier_name in PRESET_CLASSIFIERS:
        cfg = PRESET_CLASSIFIERS[classifier_name]
        labels = cfg["labels"]
        prompt_prefix = cfg["prompt"]
    else:
        labels = list(PRESET_CLASSIFIERS.keys())
        prompt_prefix = "请对以下文本进行分类。"

    # Build prompt
    labels_str = "、".join(labels)
    full_prompt = f"{prompt_prefix}\n\n文本：{text}\n\n可选类别：{labels_str}\n\n请只返回一个类别名称，不要其他解释。"

    try:
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": full_prompt}],
                "temperature": 0.1,
                "max_tokens": 50,
            },
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
        raw = result["choices"][0]["message"]["content"].strip()

        # Parse response - extract label
        matched_label = None
        for label in labels:
            if label in raw:
                matched_label = label
                break

        if not matched_label:
            matched_label = raw.strip()

        # Estimate confidence (mock - real confidence would need logprobs)
        confidence = 0.85 if matched_label in labels else 0.5

        return {
            "label": matched_label,
            "confidence": confidence if show_confidence else None,
            "raw": raw,
            "classifier": classifier_name,
            "text_preview": text[:100],
        }
    except Exception as e:
        raise RuntimeError(f"Classification failed: {e}")


def classify_batch(
    texts: list,
    classifier_name: str,
    api_key: Optional[str] = None,
    custom_labels: Optional[list] = None,
    custom_prompt: Optional[str] = None,
    model: str = "gpt-3.5-turbo",
    show_confidence: bool = True,
    batch_limit: int = 50,
) -> list:
    """Classify multiple texts with rate limiting."""
    results = []
    for i, text in enumerate(texts[:batch_limit]):
        try:
            result = classify_text(
                text,
                classifier_name,
                api_key,
                custom_labels,
                custom_prompt,
                model,
                show_confidence,
            )
            results.append(result)
        except Exception as e:
            results.append({
                "label": "ERROR",
                "confidence": None,
                "raw": str(e),
                "classifier": classifier_name,
                "text_preview": text[:100],
            })
        # Simple rate limit - 5 req/sec
        if i < len(texts) - 1:
            time.sleep(0.2)
    return results


# ========================
# File Parsing
# ========================

def parse_txt(file_path: str) -> list:
    """Parse TXT file, return list of texts."""
    with open(file_path, "r", encoding="utf-8") as f:
        lines = [l.strip() for l in f if l.strip()]
    return lines


def parse_csv(file_path: str, text_column: str = None, encoding: str = "utf-8") -> list:
    """Parse CSV file using pandas. Returns list of texts."""
    try:
        df = pd.read_csv(file_path, encoding=encoding)
    except Exception:
        # Try different encodings
        for enc in ["gbk", "gb2312", "latin1"]:
            try:
                df = pd.read_csv(file_path, encoding=enc)
                break
            except Exception:
                continue
        else:
            raise ValueError(f"Could not parse CSV file: {file_path}")

    if text_column:
        if text_column not in df.columns:
            raise ValueError(f"Column '{text_column}' not found. Available: {list(df.columns)}")
        return df[text_column].dropna().astype(str).tolist()
    else:
        # Use first text-like column
        for col in df.columns:
            if df[col].dtype == "object":
                return df[col].dropna().astype(str).tolist()
        raise ValueError("No text column found in CSV.")


# ========================
# Output Formatting
# ========================

def format_results_markdown(results: list, show_confidence: bool = True) -> str:
    """Format results as a Markdown table."""
    if not results:
        return "No results to display."

    header = "| # | 文本预览 | 分类结果"
    sep = "|---|-----------|----------"
    if show_confidence and results[0].get("confidence") is not None:
        header += " | 置信度"
        sep += "|----------"

    lines = [header, sep]
    for i, r in enumerate(results, 1):
        preview = r.get("text_preview", "")[:40]
        label = r.get("label", "N/A")
        line = f"| {i} | {preview} | {label}"
        if show_confidence and r.get("confidence") is not None:
            conf = r.get("confidence", 0)
            line += f" | {conf:.0%}"
        lines.append(line)

    return "\n".join(lines)


def export_csv(results: list, output_path: str):
    """Export results to CSV."""
    df = pd.DataFrame(results)
    df.to_csv(output_path, index=False, encoding="utf-8-sig")


def export_excel(results: list, output_path: str):
    """Export results to Excel."""
    df = pd.DataFrame(results)
    df.to_excel(output_path, index=False, engine="openpyxl")


def export_json(results: list, output_path: str):
    """Export results to JSON."""
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)


# ========================
# History Management
# ========================

def save_history(results: list, tier: str, history_dir: str = "./history"):
    """Save classification history to file."""
    limits = get_tier_limits(tier)
    days = limits["history_days"]

    if days == 0:
        return  # No history for this tier

    Path(history_dir).mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    filename = f"{history_dir}/classification_{ts}.json"

    with open(filename, "w", encoding="utf-8") as f:
        json.dump({
            "timestamp": ts,
            "tier": tier,
            "results": results,
        }, f, ensure_ascii=False, indent=2)


# ========================
# CLI Interface
# ========================

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Text Classifier CLI")
    parser.add_argument("--text", type=str, help="Single text to classify")
    parser.add_argument("--file", type=str, help="TXT or CSV file to classify")
    parser.add_argument("--csv-column", type=str, help="Column name for CSV text field")
    parser.add_argument("--classifier", type=str, default="情感分类",
                        help="Preset classifier name")
    parser.add_argument("--custom-labels", type=str, help="Comma-separated custom labels")
    parser.add_argument("--custom-prompt", type=str, help="Custom classification prompt")
    parser.add_argument("--api-key", type=str, default=os.getenv("OPENAI_API_KEY"),
                        help="OpenAI API key")
    parser.add_argument("--model", type=str, default="gpt-3.5-turbo")
    parser.add_argument("--no-confidence", action="store_true")
    parser.add_argument("--output", type=str, choices=["screen", "csv", "excel", "json"],
                        default="screen")
    parser.add_argument("--output-path", type=str)
    parser.add_argument("--batch-limit", type=int, default=50)
    parser.add_argument("--token", type=str, help="License token for tier validation")

    args = parser.parse_args()

    # Validate token
    tier = validate_token(args.token) if args.token else "TEXT-CLS-FREE"
    limits = get_tier_limits(tier)

    print(f"[Text Classifier] Tier: {tier} | Daily limit: {limits['daily']}")

    # Collect texts
    texts = []
    if args.text:
        texts = [args.text]
    elif args.file:
        ext = Path(args.file).suffix.lower()
        if ext == ".txt":
            texts = parse_txt(args.file)
        elif ext == ".csv":
            texts = parse_csv(args.file, args.csv_column)
        else:
            print(f"Unsupported file type: {ext}")
            return
    else:
        print("Please provide --text or --file")
        return

    # Check batch limit
    batch_limit = min(len(texts), limits.get("batch", 0) if limits.get("batch", 0) > 0 else len(texts))
    if len(texts) > batch_limit and batch_limit > 0:
        print(f"Batch limit reached ({batch_limit}). Truncating.")
        texts = texts[:batch_limit]

    # Prepare custom labels
    custom_labels = [l.strip() for l in args.custom_labels.split(",")] if args.custom_labels else None
    show_confidence = not args.no_confidence and limits.get("confidence", False)

    # Classify
    if len(texts) == 1:
        result = classify_text(
            texts[0],
            args.classifier,
            args.api_key,
            custom_labels,
            args.custom_prompt,
            args.model,
            show_confidence,
        )
        results = [result]
    else:
        results = classify_batch(
            texts,
            args.classifier,
            args.api_key,
            custom_labels,
            args.custom_prompt,
            args.model,
            show_confidence,
            args.batch_limit,
        )

    # Save history
    save_history(results, tier)

    # Output
    if args.output == "screen":
        print(f"\n{format_results_markdown(results, show_confidence)}\n")
    elif args.output == "csv":
        path = args.output_path or "results.csv"
        export_csv(results, path)
        print(f"Exported to {path}")
    elif args.output == "excel":
        path = args.output_path or "results.xlsx"
        export_excel(results, path)
        print(f"Exported to {path}")
    elif args.output == "json":
        path = args.output_path or "results.json"
        export_json(results, path)
        print(f"Exported to {path}")


if __name__ == "__main__":
    main()
