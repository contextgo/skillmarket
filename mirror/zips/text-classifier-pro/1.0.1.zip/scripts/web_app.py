"""
Text Classifier Web App (Flask)
"""
import os
import io
import json
from pathlib import Path
from flask import Flask, request, jsonify, render_template_string
from werkzeug.utils import secure_filename
from scripts.classifier import (
    validate_token, get_tier_limits, classify_text, classify_batch,
    parse_txt, parse_csv, format_results_markdown,
    export_csv, export_excel, export_json, save_history,
    PRESET_CLASSIFIERS,
)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16MB
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "text-classifier-secret")

SESSION_COUNTS = {}  # {api_key_hash: count}


def get_session_count(api_key: str) -> int:
    """Track daily classification count per user (simple in-memory)."""
    import hashlib
    key = hashlib.md5((api_key or "").encode()).hexdigest()
    return SESSION_COUNTS.get(key, 0)


def increment_count(api_key: str):
    import hashlib
    key = hashlib.md5((api_key or "").encode()).hexdigest()
    SESSION_COUNTS[key] = SESSION_COUNTS.get(key, 0) + 1


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>Text Classifier · 文本分类打标器</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background: #f5f6fa; color: #333; max-width: 900px; margin: 0 auto; padding: 20px; }
  h1 { text-align: center; color: #2c3e50; margin: 20px 0; }
  .card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 16px;
          box-shadow: 0 2px 8px rgba(0,0,0,.08); }
  .tier-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 13px;
                font-weight: 600; }
  .tier-FREE { background: #e8f5e9; color: #2e7d32; }
  .tier-STD { background: #e3f2fd; color: #1565c0; }
  .tier-PRO { background: #ede7f6; color: #7b1fa2; }
  .tier-MAX { background: #fff3e0; color: #e65100; }
  label { font-weight: 600; display: block; margin: 12px 0 6px; color: #555; }
  input, select, textarea { width: 100%; padding: 10px 12px; border: 1.5px solid #ddd; border-radius: 8px;
                             font-size: 15px; transition: border .2s; }
  input:focus, select:focus, textarea:focus { outline: none; border-color: #4f46e5; }
  textarea { height: 120px; resize: vertical; }
  .btn { display: inline-block; padding: 12px 24px; background: #4f46e5; color: white;
         border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer;
         transition: background .2s; width: 100%; margin-top: 16px; }
  .btn:hover { background: #4338ca; }
  .btn:disabled { background: #9ca3af; cursor: not-allowed; }
  .results { background: #f8f9fc; border-radius: 8px; padding: 16px; margin-top: 20px;
              overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th { background: #4f46e5; color: white; padding: 10px; text-align: left; }
  td { padding: 8px 10px; border-bottom: 1px solid #eee; }
  tr:hover td { background: #f0f0f8; }
  .alert { padding: 12px; border-radius: 8px; margin: 12px 0; }
  .alert-error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
  .alert-success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
  .row { display: flex; gap: 12px; }
  .col { flex: 1; }
  .presets { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
  .preset-tag { padding: 3px 10px; background: #e0e7ff; color: #3730a3; border-radius: 20px;
                font-size: 12px; cursor: pointer; }
  .preset-tag:hover { background: #c7d2fe; }
  .count-badge { font-size: 12px; color: #888; margin-left: 8px; }
  .footer { text-align: center; color: #aaa; font-size: 13px; margin: 24px 0; }
  .footer a { color: #4f46e5; text-decoration: none; }
</style>
</head>
<body>
<h1>🏷️ Text Classifier</h1>
<div class="card">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <span>当前套餐</span>
    <span class="tier-badge tier-{{ tier_class }}">{{ tier }}</span>
  </div>
  <div style="margin-top:8px; font-size:13px; color:#666;">
    剩余次数: <strong>{{ remaining }}</strong>
  </div>
</div>

<div class="card">
  <form method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col">
        <label>API Key (OpenAI)</label>
        <input type="password" name="api_key" placeholder="sk-..." value="{{ api_key or '' }}">
        <label>License Token</label>
        <input type="text" name="license_token" placeholder="TEXT-CLS-XXX" value="{{ license_token or '' }}">
      </div>
      <div class="col">
        <label>分类器</label>
        <select name="classifier">
          {% for name in classifiers %}
          <option value="{{ name }}" {% if classifier == name %}selected{% endif %}>{{ name }}</option>
          {% endfor %}
        </select>
        <label>模型</label>
        <select name="model">
          <option value="gpt-3.5-turbo" {% if model == 'gpt-3.5-turbo' %}selected{% endif %}>GPT-3.5</option>
          <option value="gpt-4" {% if model == 'gpt-4' %}selected{% endif %}>GPT-4</option>
          <option value="gpt-4-turbo" {% if model == 'gpt-4-turbo' %}selected{% endif %}>GPT-4 Turbo</option>
        </select>
      </div>
    </div>

    <label>输入文本 (每行一条)</label>
    <textarea name="text" placeholder="在此粘贴文本，每行一条...">{{ text or '' }}</textarea>

    <label>或上传文件</label>
    <input type="file" name="file" accept=".txt,.csv">

    <div class="row" style="margin-top:12px;">
      <div class="col">
        <label>自定义标签 (逗号分隔)</label>
        <input type="text" name="custom_labels" placeholder="标签1,标签2,标签3">
      </div>
      <div class="col">
        <label>导出格式</label>
        <select name="export_format">
          <option value="screen">屏幕显示</option>
          <option value="csv">CSV</option>
          <option value="excel">Excel</option>
          <option value="json">JSON</option>
        </select>
      </div>
    </div>

    <div style="margin-top:4px;">
      <label style="display:inline;">预设分类器:</label>
      <div class="presets">
        {% for name in classifiers %}
        <span class="preset-tag" onclick="document.querySelector('[name=classifier]').value='{{ name }}'">{{ name }}</span>
        {% endfor %}
      </div>
    </div>

    <button type="submit" class="btn">开始分类</button>
  </form>
</div>

{% if error %}
<div class="alert alert-error">{{ error }}</div>
{% endif %}

{% if results %}
<div class="card">
  <h3 style="margin-bottom:12px;">📊 分类结果 ({{ results|length }} 条)</h3>
  {% if export_format == 'screen' %}
  <div class="results">
    {{ results|safe }}
  </div>
  {% else %}
  <div class="alert alert-success">✅ 已导出为 {{ export_format|upper }} 格式</div>
  {% endif %}
</div>
{% endif %}

<div class="footer">
  Text Classifier Pro · 如需购买收费版，请访问 <a href="https://yk-global.com" target="_blank">YK-Global.com</a>
</div>
</body>
</html>
"""


@app.route("/", methods=["GET", "POST"])
def index():
    import hashlib
    error = None
    results = None
    api_key = request.form.get("api_key", "")
    license_token = request.form.get("license_token", "")
    classifier = request.form.get("classifier", "情感分类")
    model = request.form.get("model", "gpt-3.5-turbo")
    text = request.form.get("text", "")
    custom_labels_str = request.form.get("custom_labels", "")
    export_format = request.form.get("export_format", "screen")
    text_column = None

    # Determine tier
    tier = validate_token(license_token) if license_token else "TEXT-CLS-FREE"
    limits = get_tier_limits(tier)

    # Count check
    current_count = get_session_count(license_token)
    remaining = max(0, limits["daily"] - current_count)

    if request.method == "POST":
        if not api_key:
            error = "请输入 OpenAI API Key"
        else:
            # Parse texts
            texts = []
            uploaded_file = request.files.get("file")
            if uploaded_file and uploaded_file.filename:
                filename = secure_filename(uploaded_file.filename)
                ext = Path(filename).suffix.lower()
                if ext == ".txt":
                    content = uploaded_file.read().decode("utf-8")
                    texts = [l.strip() for l in content.split("\n") if l.strip()]
                elif ext == ".csv":
                    # Save temp file
                    temp_path = f"/tmp/{filename}"
                    uploaded_file.save(temp_path)
                    try:
                        texts = parse_csv(temp_path, text_column)
                    finally:
                        os.unlink(temp_path)
                else:
                    error = "仅支持 TXT 和 CSV 文件"
            elif text:
                texts = [t.strip() for t in text.split("\n") if t.strip()]
            else:
                error = "请输入文本或上传文件"

            if error is None and texts:
                # Check batch limit
                batch_limit = limits.get("batch", 0)
                if batch_limit > 0 and len(texts) > batch_limit:
                    texts = texts[:batch_limit]
                    error = f"批量限制: 已截断至前 {batch_limit} 条"

                # Check count
                if current_count >= limits["daily"]:
                    error = "今日分类次数已达上限，请升级套餐"
                else:
                    custom_labels = [l.strip() for l in custom_labels_str.split(",") if l.strip()] if custom_labels_str else None
                    show_conf = limits.get("confidence", False)

                    try:
                        if len(texts) == 1:
                            result = classify_text(
                                texts[0], classifier, api_key,
                                custom_labels, None, model, show_conf
                            )
                            results = [result]
                        else:
                            results = classify_batch(
                                texts, classifier, api_key,
                                custom_labels, None, model, show_conf,
                                limits.get("batch", 50)
                            )
                        increment_count(license_token)

                        if export_format == "screen":
                            results = format_results_markdown(results, show_conf)
                        else:
                            suffix = export_format
                            export_path = f"/tmp/results.{suffix}"
                            if export_format == "csv":
                                export_csv(results, export_path)
                            elif export_format == "excel":
                                export_excel(results, export_path)
                            elif export_format == "json":
                                export_json(results, export_path)
                            save_history(results, tier)

                            # Return download
                            from flask import send_file
                            return send_file(
                                export_path,
                                as_attachment=True,
                                download_name=f"classification_results.{suffix}"
                            )
                    except Exception as e:
                        error = f"分类失败: {e}"

    tier_class = tier.split("-")[-1].upper()
    remaining = max(0, limits["daily"] - get_session_count(license_token))

    return render_template_string(
        HTML_TEMPLATE,
        tier=tier,
        tier_class=tier_class,
        remaining=remaining,
        classifiers=list(PRESET_CLASSIFIERS.keys()),
        api_key=api_key,
        license_token=license_token,
        classifier=classifier,
        model=model,
        text=text,
        error=error,
        results=results,
        export_format=export_format,
    )


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
