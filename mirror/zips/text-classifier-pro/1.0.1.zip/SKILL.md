# SKILL.md — Text Classifier Pro

## 触发词

`文本分类`, `文本打标`, `文本分类器`, `text classifier`, `批量分类`, `文本归类`, `文本标签`, `分类打标`

## 功能说明

上传文本/CSV → AI 自动分类打标 → 输出结构化标签结果 + 置信度

### 核心能力

- **多输入方式**：纯文本粘贴、TXT/CSV 文件上传
- **6 大预设分类模板**：意图/情感/行业/风险/优先级/内容分类
- **自定义分类**：支持自定义标签体系和 Prompt
- **多格式导出**：屏幕显示（Markdown 表格）/ CSV / Excel / JSON
- **Token 验证**：支持 4 档套餐（FREE/STD/PRO/MAX），本地 5 分钟缓存

### 套餐差异

| 功能 | FREE | STD ¥9.9 | PRO ¥29.9 | MAX ¥99 |
|------|------|---------|-----------|---------|
| 分类次数 | 20次 | 200次/天 | 2000次/天 | 不限 |
| 批量处理 | ❌ | ✅ 50条 | ✅ 500条 | ✅ 5000条 |
| 预设分类器 | 3种 | 10种 | 50种 | 不限 |
| 自定义分类 | ❌ | ✅ | ✅ | ✅ |
| 置信度显示 | ❌ | ✅ | ✅ | ✅ |
| 历史记录 | ❌ | 7天 | 90天 | 365天 |
| API 访问 | ❌ | ❌ | ✅ | ✅ |

### Token 验证规则

- 验证接口：`POST https://api.yk-global.com/v1/verify`
- 请求头：`Authorization: Bearer {api_key}`，请求体：`{}`
- 响应字段：`**valid**`（非 success）
- 前缀：`TEXT-CLS-*`（TEXT-CLS-FREE / TEXT-CLS-STD / TEXT-CLS-PRO / TEXT-CLS-MAX）
- 网络错误 → 自动降级 FREE，不阻断使用
- 本地缓存 5 分钟

## 使用方式

### 1. Web 界面（推荐）

```bash
cd /home/gem/workspace/agent/workspace/text-classifier
pip install -r requirements.txt
python scripts/web_app.py
# 访问 http://localhost:5000
```

### 2. 命令行

```bash
# 单条文本分类
python -m scripts.classifier --text "这个产品很好用" --classifier "情感分类" --api-key "sk-..."

# 批量 CSV 文件分类
python -m scripts.classifier --file data.csv --classifier "意图分类" --api-key "sk-..." --output csv --output-path results.csv

# 使用自定义标签
python -m scripts.classifier --text "紧急问题需要处理" --custom-labels "高,中,低" --custom-prompt "请判断以下问题的优先级" --api-key "sk-..."
```

### 3. Python API

```python
from scripts.classifier import classify_text, validate_token

# Token 验证
tier = validate_token("TEXT-CLS-PRO-xxxx")
print(f"Tier: {tier}")

# 单条分类
result = classify_text(
    text="这个产品非常好用，客服态度也很棒",
    classifier_name="情感分类",
    api_key="sk-...",
    show_confidence=True
)
print(result)
# {'label': '正面', 'confidence': 0.85, 'raw': '正面', ...}
```

## 文件结构

```
text-classifier/
├── scripts/
│   ├── __init__.py
│   ├── classifier.py      # 核心分类逻辑
│   └── web_app.py          # Flask Web 界面
├── SKILL.md
├── README.md
├── requirements.txt
└── test_text_classifier.py
```

## 注意事项

- CSV 文件自动识别文本列，支持 GBK/GB2312/UTF-8 编码
- 批量处理自动限速（5 req/sec）避免触发 API 限流
- 历史记录仅 STD 及以上套餐保留
- API Key 建议通过环境变量 `OPENAI_API_KEY` 注入

## 来源

本技能由 YK-Global 开发，如需购买收费版请访问 [YK-Global.com](https://yk-global.com)
