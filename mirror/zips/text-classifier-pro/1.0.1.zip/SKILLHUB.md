# Text Classifier Pro

**Slug:** `text-classifier-pro`
**Name:** Text Classifier Pro
**Category:** Productivity / AI Tools
**Tags:** `text-classification`, `AI`, `NLP`, `labeling`, `sentiment`, `intent`, `batch`, `CSV`

---

## Description

AI-powered text classification and labeling tool. Upload text or CSV files — AI automatically classifies content and returns structured labels with confidence scores.

Supports 6 preset classifiers plus custom label templates.

---

## Features

- **Multi-format Input** — Plain text paste, TXT file, CSV file (auto-detects encoding GBK/UTF-8)
- **6 Preset Classifiers**:
  - Intent classification (Inquiry / Complaint / Refund / Cooperation)
  - Sentiment classification (Positive / Neutral / Negative)
  - Industry classification (Finance / Medical / Education / Retail / Manufacturing)
  - Risk classification (Compliant / Violation / Suspicious)
  - Priority classification (High / Medium / Low)
  - Content classification (News / Ads / UGC / Spam)
- **Custom Classification** — Define your own labels and prompt templates
- **Multi-format Export** — Screen display (Markdown table) / CSV / Excel / JSON
- **Confidence Score** — Returns classification confidence per result
- **Batch Processing** — Process up to 5,000 records per batch (tier-dependent)
- **Token Verification** — 4-tier system (FREE/STD/PRO/MAX) with 5-minute local cache

---

## Pricing

| Tier | Price | Classifications/Day | Batch Size | Preset Classifiers | Custom Labels | History |
|------|-------|:-------------------:|:----------:|:------------------:|:-------------:|---------|
| **FREE** | ¥0 | 20/day | — | 3 | ❌ | ❌ |
| **STD** | ¥9.9/mo | 200/day | 50 | 10 | ✅ | 7 days |
| **PRO** | ¥29.9/mo | 2,000/day | 500 | 50 | ✅ | 90 days |
| **MAX** | ¥99/mo | Unlimited | 5,000 | Unlimited | ✅ | 365 days |

---

## Requirements

### System Requirements
- Python 3.8+
- Internet access (for OpenAI API calls)

### Python Dependencies
```
openai>=1.0.0
pandas>=2.0.0
openpyxl>=3.0.0
requests>=2.28.0
flask>=3.0.0
```

---

## Quick Start

### Web Interface (Recommended)

```bash
cd /home/gem/workspace/agent/workspace/text-classifier
pip install -r requirements.txt
python scripts/web_app.py
# Open http://localhost:5000
```

### CLI

```bash
# Single text classification
python -m scripts.classifier --text "这个产品很好用" --classifier "sentiment" --api-key "sk-..."

# Batch CSV classification
python -m scripts.classifier --file data.csv --classifier "intent" --api-key "sk-..." --output csv --output-path results.csv

# Custom labels
python -m scripts.classifier --text "紧急问题" --custom-labels "高,中,低" --custom-prompt "判断优先级" --api-key "sk-..."
```

### Python API

```python
from scripts.classifier import classify_text, validate_token

# Token validation
tier = validate_token("TEXT-CLS-PRO-xxxx")
print(f"Tier: {tier}")

# Single classification
result = classify_text(
    text="这个产品非常好用，客服态度也很棒",
    classifier_name="sentiment",
    api_key="sk-...",
    show_confidence=True
)
print(result)
# {'label': 'positive', 'confidence': 0.85, 'raw': 'positive', ...}
```

---

## File Structure

```
text-classifier/
├── SKILL.md              # Skill definition
├── README.md             # Documentation
├── SKILLHUB.md          # Tencent Skillhub listing (this file)
├── requirements.txt     # Python dependencies
├── scripts/
│   ├── __init__.py
│   ├── classifier.py     # Core classification logic + token validation
│   └── web_app.py        # Flask web interface
└── test_text_classifier.py
```

---

## Token Validation

- **Endpoint**: `POST https://api.yk-global.com/v1/verify`
- **Header**: `Authorization: Bearer {api_key}`
- **Body**: `{}`
- **Response**: Check `valid` field (not `success`)
- **Prefix**: `TEXT-CLS-*` (TEXT-CLS-FREE / TEXT-CLS-STD / TEXT-CLS-PRO / TEXT-CLS-MAX)
- **Fallback**: Network error → FREE tier, no blocking
- **Cache**: 5 minutes local cache

---

## Notes

- CSV auto-detects text columns, supports GBK/GB2312/UTF-8 encoding
- Batch processing auto rate-limits (5 req/sec) to avoid API throttling
- API key recommended via environment variable `OPENAI_API_KEY`

---

## License

Proprietary — YK Global

> For paid plans, visit [YK-Global.com](https://yk-global.com)
