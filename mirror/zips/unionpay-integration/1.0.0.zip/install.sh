#!/bin/bash
# 银联支付集成 Skill 安装脚本
# Copyright: China UnionPay Co., Ltd.

set -e

SKILL_NAME="unionpay-integration"
SKILL_DIR="$HOME/.openclaw/workspace/skills/$SKILL_NAME"

echo ""
echo "═══════════════════════════════════════════════════"
echo "  银联支付集成 Skill"
echo "  UnionPay Integration"
echo "═══════════════════════════════════════════════════"
echo ""
echo "  内容版权：中国银联股份有限公司"
echo "  客服咨询：95516"
echo ""
echo "═══════════════════════════════════════════════════"
echo ""

# 检查目录是否存在
if [ -d "$SKILL_DIR" ]; then
  echo "📁 Skill 目录已存在，正在更新..."
else
  echo "📁 创建 Skill 目录..."
  mkdir -p "$SKILL_DIR"
fi

# 复制文件
echo "📄 安装 SKILL.md..."
cat > "$SKILL_DIR/SKILL.md" << 'SKILL_EOF'
---
name: unionpay-integration
display_name: 银联支付集成
description: 中国银联签约支付解决方案接入最佳实践。涵盖App支付、H5支付、JSAPI支付、Native支付等全场景产品选型与集成指导。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：中国银联
homepage: https://open.unionpay.com/
tags:
  - 银联支付
  - 支付集成
  - 签约支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 银联支付集成

> **版权声明**：本 Skill 内容来源于中国银联官方开放平台文档，版权归属中国银联所有

## 简介

中国银联签约支付解决方案接入最佳实践。

## 支付产品

| 产品 | 场景 |
|------|------|
| 签约支付 | 银行卡签约后扣款 |
| App支付 | 原生iOS/Android App |
| H5支付 | 手机浏览器H5 |
| Native支付 | 商家二维码 |

## 快速决策树

```
用户咨询银联支付
        |
        +-- 签约支付？ --> 签约支付
        +-- App支付？ --> App支付
        +-- H5支付？ --> H5支付
        +-- 扫码？ --> Native支付
```

## SDK下载

访问：https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=3

## 版权声明

- **版权归属**：中国银联股份有限公司
- **客服热线**：95516
- **开放平台**：https://open.unionpay.com

SKILL_EOF

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ 安装完成！"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📚 使用说明："
echo ""
echo "  当用户提到以下关键词时自动触发："
echo "    - 接入银联支付、集成银联支付"
echo "    - 签约支付、银行卡支付"
echo "    - App支付、H5支付"
echo "    - Native支付、云闪付"
echo ""
echo "📖 完整文档请阅读："
echo "    $SKILL_DIR/SKILL.md"
echo ""
echo "═══════════════════════════════════════════════════"
