---
name: unionpay-integration
display_name: 银联支付集成
description: 中国银联签约支付解决方案接入最佳实践。涵盖App支付、H5支付、JSAPI支付、Native支付、订单退款等全场景产品选型与集成指导。银联签约支付是用户在签约方授权完成银行卡签约绑定后，通过支付密码、人脸验证等方式完成用户核身，从签约卡片完成扣款的支付产品。
version: 1.0.0
author: 整合者：叶建国 | 内容版权：中国银联
homepage: https://open.unionpay.com/
tags:
  - 银联支付
  - 支付集成
  - 签约支付
  - 云闪付
  - 银行卡支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 银联支付集成

> **版权声明**：本 Skill 内容来源于中国银联官方开放平台文档，版权归属中国银联所有。如有疑问可咨询银联客服
> 
> **Source**: 中国银联开放平台
> **Copyright**: China UnionPay Co., Ltd.

---

## 简介

中国银联签约支付解决方案接入最佳实践。银联签约支付是用户在签约方授权完成银行卡签约绑定后，支付时由签约方根据与用户约定的验证要素，通过签约方支付密码、人脸验证等方式完成用户核身后，从签约卡片完成扣款。

**适用场景**：当用户提到"接入银联支付"、"集成银联支付"、"对接银联"、"银联收款"、"加个银联支付"、"银联签约"、"银行卡支付"、"云闪付"、"银联SDK"、"银联API"时使用此 Skill。

**不适用场景**：不用于支付宝支付、微信支付、抖音支付等第三方支付场景。

---

## 支付产品一览

银联提供以下支付产品：

| 产品 | 场景 | 文档入口 |
|------|------|----------|
| 签约支付 | 用户银行卡签约后扣款 | [银联签约支付](https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301) |
| App支付 | 原生iOS/Android App内支付 | [App支付文档](https://open.unionpay.com) |
| H5支付 | 手机浏览器H5页面支付 | [H5支付文档](https://open.unionpay.com) |
| JSAPI支付 | 微信/支付宝小程序内支付 | [JSAPI文档](https://open.unionpay.com) |
| Native支付 | 商家生成二维码，用户扫码支付 | [Native文档](https://open.unionpay.com) |

---

## 接入路由表

根据用户的业务场景，路由到对应的产品文档：

| 场景 | 推荐产品 | 接入方式 | 文档 |
|------|----------|----------|------|
| 银行卡签约后自动扣款 | 签约支付 | API/H5 | [签约支付](https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301) |
| 原生App支付（iOS/Android） | App支付 | App SDK | [App支付](https://open.unionpay.com) |
| 手机浏览器H5支付 | H5支付 | H5页面 | [H5支付](https://open.unionpay.com) |
| 商家二维码用户扫码 | Native支付 | 二维码 | [Native支付](https://open.unionpay.com) |

---

## 快速决策树

```
用户咨询银联支付接入
        |
        +-- 银行卡签约扣款？
        |       +-- 用户授权银行卡后扣款 --> 签约支付
        |
        +-- App支付？
        |       +-- 原生iOS/Android App --> App支付
        |
        +-- H5支付？
        |       +-- 手机浏览器H5 --> H5支付
        |
        +-- 扫码支付？
                +-- 商家二维码，用户扫码 --> Native支付
```

---

## 场景关键词匹配

| 关键词 | 路由产品 |
|--------|----------|
| 银联支付、接入银联、集成银联、银联收款、银联签约 | 签约支付 |
| 银行卡支付、银行卡扣款、自动扣款、签约扣款 | 签约支付 |
| App支付、iOS支付、Android支付、原生App | App支付 |
| H5支付、WAP支付、手机网页支付、移动端网页 | H5支付 |
| Native支付、二维码支付、扫码支付、商家二维码 | Native支付 |
| 云闪付、云闪付SDK、银联SDK | 签约支付/App支付 |

---

## 银联签约支付接入指南

### 产品概述

银联签约支付解决方案是用户在签约方授权完成银行卡签约绑定后，支付时由签约方根据与用户约定的验证要素，通过签约方支付密码、人脸验证等方式完成用户核身后，从签约卡片完成扣款。

**应用场景**：线上小额高频交易场景的商户
- 交通出行
- 外卖订餐
- 电商购物
- 校园支付

**已支持商户**：快手、得物、天府通等

### SDK下载

| 版本 | 下载链接 |
|------|----------|
| H5模式 | [点击下载（H5模式）](https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=3) |
| API模式 | [点击下载（API模式）](https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=3) |
| API模式JSON版 | [点击下载（API模式JSON版）](https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=3) |

### SDK目录结构

```
uas_uag_demo
  │
  ├src.main.java
  │  ├com.unionpay.uas.demo      # 示例代码目录
  │  │  ├cloudpayplatform        # 云网项目业务
  │  │  └DemoUAG.java            # 网关使用示例
  │  └com.unionpay.uas.sdk       # SDK核心类
  │     ├AesUtils.java           # AES算法工具
  │     ├CertUtil.java           # 证书管理
  │     ├HttpsUtil.java          # HTTP通讯
  │     ├SDKConfig.java          # 配置类
  │     └UasService.java         # 服务类
  │
  ├src.main.resources
  │  ├uas_sdk.properties        # 配置文件【重要】
  │  └log4j.properties           # 日志配置
  │
  └lib                           # 依赖包
     └uas_uag_sdk-1.3.0.jar      # 核心SDK
```

### 核心配置 (uas_sdk.properties)

```properties
# 测试环境配置
acpsdk.frontTransUrl=https://gateway-test.95516.com/gateway/api/frontTransReq.do
acpsdk.backTransUrl=https://gateway-test.95516.com/gateway/api/backTransReq.do
acpsdk.queryUrl=https://gateway-test.95516.com/gateway/api/queryTrans.do
acpsdk.signMethod=01    # 01=RSA, 02=国密
acpsdk.version=5.1.0    # 版本号

# 证书配置
acpsdk.signCert.path=/path/to/your/signCert.pfx
acpsdk.signCert.password=your_password
acpsdk.validateCert.path=/path/to/unionpay/validateCert.cer
```

---

## 澄清话术

当用户描述模糊时：

```
请确认您的业务场景：

1. 银行卡签约支付
   - 用户授权绑定银行卡后自动扣款
   - 适用：交通出行、外卖、电商、校园等高频场景
   - 需要：签约 + 扣款两步流程

2. App支付
   - 原生 iOS/Android App 内调用银联支付
   - 适用：自营App电商

3. H5支付
   - 手机浏览器 H5 页面内支付
   - 适用：移动端网页电商

4. Native支付
   - 商家生成二维码，用户扫码
   - 适用：线下扫码场景

请描述您的具体业务场景？
```

---

## 接入准备

### 1. 注册商户号

前往 [银联开放平台](https://open.unionpay.com/) 注册商户账号

### 2. 获取必要参数

| 参数 | 说明 | 获取方式 |
|------|------|----------|
| merId | 商户号 | 商户平台申请 |
| signCertPath | 签名证书路径 | 商户平台下载 |
| signCertPwd | 签名证书密码 | 商户平台设置 |
| validateCertPath | 验签证书路径 | 银联分发 |
| acpsdk.frontTransUrl | 前台交易地址 | 配置文件 |

### 3. SDK集成 (Java示例)

```java
// 1. 加载配置
SDKConfig.getConfig().loadPropertiesFromPath("/path/to/uas_sdk.properties");

// 2. 构建请求
Map<String, String> params = new HashMap<>();
params.put("version", "5.1.0");
params.put("encoding", "UTF-8");
params.put("signMethod", "01");
params.put("txnType", "01");           // 交易类型
params.put("txnSubType", "01");         // 交易子类
params.put("bizType", "000201");        // 业务类型
params.put("channelType", "07");        // 渠道类型
params.put("merId", "898340183988888"); // 商户号
params.put("orderId", "20260404210001"); // 订单号
params.put("txnAmt", "1000");            // 金额（分）
params.put("currencyCode", "156");       // 币种
params.put("txnTime", "20260404210000"); // 交易时间

// 3. 签名
Map<String, String> signedParams = SDKUtil.sign(params);

// 4. 发送请求
String result = HttpsUtil.post(SDKConfig.getConfig().getBackTransUrl(), signedParams);

// 5. 验签并解析结果
if (SDKUtil.verify(result)) {
    // 处理返回结果
}
```

---

## 文档资源

| 资源 | 链接 |
|------|------|
| 商户文档中心 | https://open.unionpay.com/ |
| 银联签约支付 | https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301 |
| SDK下载 | https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=3 |
| 接口文档 | https://open.unionpay.com/tjweb/acproduct/list?apiSvcId=3301&index=4 |

---

## 注意事项

- 本产品**需要商户入网**后方可使用，个人无法直接接入
- 业务咨询和接入问题请查阅 [银联开放平台](https://open.unionpay.com/) 或联系官方客服
- 测试阶段建议开发者优先使用沙箱环境（测试环境）
- 本文档链接均指向银联在线文档，内容会动态更新，编写代码前务必阅读最新版本

---

## 版权声明

本 Skill 的内容来源于 **中国银联** 官方开放平台文档。

- **版权归属**：中国银联股份有限公司
- **客服热线**：95516
- **官方网站**：https://www.unionpay.com
- **开放平台**：https://open.unionpay.com
- **商户平台**：https://merchant.unionpay.com

本整合版仅作技术学习交流使用，原始内容由银联官方维护和更新。如有任何疑问或需要商业支持，请直接联系银联官方客服。

---

## 更新日志

### v1.0.0 (2026-04-04)
- 整合银联签约支付商户文档中心内容
- 适配 SkillHub 格式规范
- 添加版权声明和SDK信息