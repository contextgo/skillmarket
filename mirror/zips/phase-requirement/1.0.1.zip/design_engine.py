#!/usr/bin/env python3
"""
Phase Design Engine - 精简版
用途：辅助查询L4布局层和L5模块层知识库
保留命令：match_layout, get_page_layout, read_ref

Usage: python3 design_engine.py <command> [args...] [--json]
"""

import json
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent

# ═══════════════════════════════════════════════════════════════
# L4 - 7种标准布局
# ═══════════════════════════════════════════════════════════════

LAYOUTS = {
    "LayoutPage-1": {
        "name": "顶栏 + 内容区",
        "desc": "顶部Header + 主体Content，无侧边栏",
        "typical_systems": ["企业官网", "产品营销页", "门户首页", "登录页"],
        "structure": {
            "header": {"height": "64px", "content": "Logo + 主导航 + 用户信息"},
            "content": {"margin": "24px", "max_width": "1400px"}
        }
    },
    "LayoutPage-2": {
        "name": "侧边栏 + 顶栏 + 内容区",
        "desc": "左侧固定侧边栏(240px) + 顶部Header + 主体Content",
        "typical_systems": ["OA系统", "CRM系统", "ERP系统", "HRM系统", "管理后台"],
        "structure": {
            "sidebar": {"width": "240px", "position": "fixed", "content": "Logo + 菜单导航"},
            "header": {"height": "64px", "content": "面包屑 + 页面标题 + 操作按钮"},
            "content": {"margin_left": "240px", "padding": "24px"}
        }
    },
    "LayoutPage-3": {
        "name": "左侧固定 + 右侧内容",
        "desc": "左侧固定区域 + 右侧可滚动内容区",
        "typical_systems": ["文档页面", "详情页", "配置页", "设置页"],
        "structure": {
            "left_panel": {"width": "280px", "position": "fixed", "content": "目录/导航"},
            "content": {"margin_left": "280px", "padding": "24px"}
        }
    },
    "LayoutPage-4": {
        "name": "多标签页布局",
        "desc": "侧边栏 + 顶部标签页 + 内容区",
        "typical_systems": ["重型后台", "复杂表单", "多视图切换", "ERP详情页"],
        "structure": {
            "sidebar": {"width": "240px", "content": "主导航"},
            "tabs": {"height": "48px", "content": "标签页切换"},
            "content": {"margin_left": "240px", "padding": "24px"}
        }
    },
    "LayoutPage-5": {
        "name": "数据看板布局",
        "desc": "侧边栏 + 顶部筛选 + 多图表卡片区",
        "typical_systems": ["Dashboard", "BI分析", "数据可视化", "监控看板"],
        "structure": {
            "sidebar": {"width": "240px", "content": "导航菜单"},
            "filter_bar": {"height": "64px", "content": "筛选条件"},
            "dashboard": {"margin_left": "240px", "padding": "24px", "grid": "2-4列"}
        }
    },
    "LayoutPage-6": {
        "name": "卡片式布局",
        "desc": "侧边栏 + 卡片网格内容区",
        "typical_systems": ["应用门户", "功能导航", "轻量级后台", "首页入口"],
        "structure": {
            "sidebar": {"width": "240px", "content": "导航"},
            "content": {"margin_left": "240px", "padding": "24px", "grid": "3-4列卡片"}
        }
    },
    "LayoutPage-7": {
        "name": "混合布局",
        "desc": "多种布局组合，灵活配置",
        "typical_systems": ["复杂门户", "定制化首页", "综合管理系统"],
        "structure": {
            "custom": "根据需求灵活组合上述布局"
        }
    }
}

# ═══════════════════════════════════════════════════════════════
# 页面类型映射
# ═══════════════════════════════════════════════════════════════

PAGE_TYPES = {
    "dashboard": {
        "name": "Dashboard/数据看板",
        "layout": "LayoutPage-5",
        "sections": ["筛选区", "KPI卡片区", "图表区", "数据表格区"]
    },
    "list_table": {
        "name": "列表页/表格页",
        "layout": "LayoutPage-2",
        "sections": ["头部区", "筛选区", "表格区", "分页区"]
    },
    "form": {
        "name": "表单页",
        "layout": "LayoutPage-2",
        "sections": ["头部区", "表单区", "操作区"]
    },
    "detail": {
        "name": "详情页",
        "layout": "LayoutPage-2",
        "sections": ["头部区", "详情卡片区", "关联列表区"]
    },
    "detail_group": {
        "name": "分组详情页",
        "layout": "LayoutPage-4",
        "sections": ["头部区", "标签页导航", "分组内容区"]
    },
    "portal": {
        "name": "门户首页",
        "layout": "LayoutPage-1",
        "sections": ["导航区", "Banner区", "内容卡片区", "页脚区"]
    }
}

# ═══════════════════════════════════════════════════════════════
# 系统类型 → 布局/页面映射
# ═══════════════════════════════════════════════════════════════

SYSTEM_MAPPINGS = {
    "crm": {
        "name": "CRM/销售系统",
        "layout": "LayoutPage-2",
        "pages": ["客户列表", "客户详情", "商机看板", "报表分析"],
        "keywords": ["客户", "销售", "商机", "线索", "跟进", "CRM"]
    },
    "oa": {
        "name": "OA/审批系统",
        "layout": "LayoutPage-2",
        "pages": ["审批列表", "审批详情", "发起审批", "我的待办"],
        "keywords": ["审批", "流程", "待办", "OA", "办公", "申请"]
    },
    "erp": {
        "name": "ERP/库存系统",
        "layout": "LayoutPage-2",
        "pages": ["采购列表", "订单详情", "库存看板", "报表中心"],
        "keywords": ["采购", "订单", "库存", "ERP", "供应链", "生产"]
    },
    "hrm": {
        "name": "HRM/人事系统",
        "layout": "LayoutPage-2",
        "pages": ["员工列表", "员工详情", "考勤表", "绩效评估"],
        "keywords": ["员工", "人事", "考勤", "绩效", "招聘", "HRM"]
    },
    "bi": {
        "name": "BI/数据平台",
        "layout": "LayoutPage-5",
        "pages": ["数据看板", "报表列表", "分析页"],
        "keywords": ["数据", "报表", "分析", "图表", "BI", "统计"]
    },
    "cms": {
        "name": "CMS/内容系统",
        "layout": "LayoutPage-2",
        "pages": ["内容列表", "内容详情", "发布表单"],
        "keywords": ["内容", "文章", "发布", "CMS", "媒体", "资讯"]
    },
    "portal": {
        "name": "门户/官网",
        "layout": "LayoutPage-1",
        "pages": ["门户首页", "资讯列表", "资讯详情"],
        "keywords": ["门户", "官网", "首页", "展示", "品牌", "营销"]
    }
}

# ═══════════════════════════════════════════════════════════════
# Commands
# ═══════════════════════════════════════════════════════════════

def cmd_match_layout(user_input):
    """
    根据用户输入快速匹配推荐布局
    Usage: python3 design_engine.py match_layout "CRM系统"
    """
    user_input = user_input.lower()
    
    # 匹配系统类型
    for sys_key, sys_info in SYSTEM_MAPPINGS.items():
        for keyword in sys_info["keywords"]:
            if keyword in user_input:
                return {
                    "system_type": sys_info["name"],
                    "recommended_layout": sys_info["layout"],
                    "typical_pages": sys_info["pages"],
                    "confidence": "high"
                }
    
    # 匹配布局关键词
    if any(kw in user_input for kw in ["dashboard", "看板", "数据", "图表", "分析", "统计"]):
        return {
            "recommended_layout": "LayoutPage-5",
            "reason": "数据可视化场景推荐使用看板布局",
            "typical_systems": ["BI系统", "Dashboard", "监控看板"],
            "confidence": "high"
        }
    
    if any(kw in user_input for kw in ["管理后台", "系统", "列表", "表格", "表单"]):
        return {
            "recommended_layout": "LayoutPage-2",
            "reason": "管理后台场景推荐使用侧边栏布局",
            "typical_systems": ["OA", "CRM", "ERP", "HRM"],
            "confidence": "medium"
        }
    
    if any(kw in user_input for kw in ["门户", "官网", "首页", "展示"]):
        return {
            "recommended_layout": "LayoutPage-1",
            "reason": "门户展示场景推荐使用上下布局",
            "typical_systems": ["企业官网", "产品门户"],
            "confidence": "medium"
        }
    
    # 默认推荐
    return {
        "recommended_layout": "LayoutPage-2",
        "reason": "默认推荐管理后台常用布局",
        "typical_systems": ["通用管理系统"],
        "confidence": "low"
    }

def cmd_get_page_layout(page_type):
    """
    获取指定页面类型的布局规范
    Usage: python3 design_engine.py get_page_layout "list_table"
    """
    page_type = page_type.lower().replace("-", "_")
    
    if page_type in PAGE_TYPES:
        info = PAGE_TYPES[page_type]
        layout_key = info["layout"]
        layout_info = LAYOUTS.get(layout_key, {})
        
        return {
            "page_type": info["name"],
            "layout": layout_key,
            "layout_name": layout_info.get("name"),
            "layout_desc": layout_info.get("desc"),
            "sections": info["sections"],
            "structure": layout_info.get("structure")
        }
    
    # 返回所有可用的页面类型
    return {
        "error": f"Unknown page type: {page_type}",
        "available_types": list(PAGE_TYPES.keys())
    }

def cmd_get_layout_info(layout_key):
    """
    获取布局详细信息
    Usage: python3 design_engine.py get_layout_info "LayoutPage-2"
    """
    if layout_key in LAYOUTS:
        return {
            "layout_key": layout_key,
            **LAYOUTS[layout_key]
        }
    
    return {
        "error": f"Unknown layout: {layout_key}",
        "available_layouts": list(LAYOUTS.keys())
    }

def cmd_list_layouts():
    """
    列出所有可用布局
    Usage: python3 design_engine.py list_layouts
    """
    return {
        "layouts": [
            {
                "key": key,
                "name": info["name"],
                "typical_systems": info["typical_systems"]
            }
            for key, info in LAYOUTS.items()
        ]
    }

def cmd_read_ref(doc_name):
    """
    读取参考文档内容
    Usage: python3 design_engine.py read_ref "00-page-layouts.md"
    """
    # 搜索路径
    search_paths = [
        BASE_DIR / "L4-Layouts-designer" / "references" / doc_name,
        BASE_DIR / "L5-Module-designer" / "references" / doc_name,
    ]
    
    for path in search_paths:
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            return {
                "file": doc_name,
                "path": str(path.relative_to(BASE_DIR)),
                "size": len(content),
                "lines": content.count('\n'),
                "content_preview": content[:1000] + "..." if len(content) > 1000 else content
            }
    
    # 列出可用文档
    available_docs = []
    for ref_dir in [BASE_DIR / "L4-Layouts-designer" / "references",
                    BASE_DIR / "L5-Module-designer" / "references"]:
        if ref_dir.exists():
            available_docs.extend([f.name for f in ref_dir.glob("*.md")])
    
    return {
        "error": f"Document not found: {doc_name}",
        "available_docs": sorted(available_docs)
    }

def cmd_list_refs(layer=None):
    """
    列出所有参考文档
    Usage: python3 design_engine.py list_refs [L4|L5]
    """
    refs = {}
    
    layers = ["L4", "L5"] if layer is None else [layer.upper()]
    
    for lyr in layers:
        dir_map = {
            "L4": BASE_DIR / "L4-Layouts-designer" / "references",
            "L5": BASE_DIR / "L5-Module-designer" / "references"
        }
        
        ref_dir = dir_map.get(lyr)
        if ref_dir and ref_dir.exists():
            refs[lyr] = sorted([f.name for f in ref_dir.glob("*.md")])
    
    return refs

# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

COMMANDS = {
    "match_layout": cmd_match_layout,
    "get_page_layout": cmd_get_page_layout,
    "get_layout_info": cmd_get_layout_info,
    "list_layouts": cmd_list_layouts,
    "read_ref": cmd_read_ref,
    "list_refs": cmd_list_refs,
}

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 design_engine.py <command> [args...] [--json]")
        print("\nAvailable commands:")
        for cmd in COMMANDS:
            print(f"  - {cmd}")
        print("\nExamples:")
        print('  python3 design_engine.py match_layout "CRM系统"')
        print('  python3 design_engine.py get_page_layout "list_table"')
        print('  python3 design_engine.py read_ref "component_tokens.md"')
        sys.exit(1)
    
    command = sys.argv[1]
    args = sys.argv[2:]
    
    # Check for --json flag
    output_json = "--json" in args
    args = [a for a in args if a != "--json"]
    
    if command not in COMMANDS:
        print(f"Unknown command: {command}")
        print(f"Available: {', '.join(COMMANDS.keys())}")
        sys.exit(1)
    
    func = COMMANDS[command]
    
    try:
        if args:
            result = func(*args)
        else:
            result = func()
        
        if output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            # Pretty print
            if isinstance(result, dict):
                for key, value in result.items():
                    if isinstance(value, list):
                        print(f"\n{key}:")
                        for item in value:
                            print(f"  - {item}")
                    elif isinstance(value, dict):
                        print(f"\n{key}:")
                        for k, v in value.items():
                            print(f"  {k}: {v}")
                    else:
                        print(f"{key}: {value}")
            else:
                print(result)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
