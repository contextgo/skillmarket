# L5-Module-designer 模块设计层

name: L5-module-designer
description: 负责区域级模块设计，提供BEM命名规范、四层容器结构和模块HTML模板

---

## 核心职责

本技能专注于**区域级（Section Level）**设计，负责：

1. **定义模块结构** → 规划区域内的模块组成
2. **应用BEM命名** → 为模块和元素提供标准化命名
3. **选择组件令牌** → 在模块中放置合适的组件
4. **描述字段规范** → 定义模块内的数据字段
5. **输出模块模板** → 提供可复用的HTML模板

---

## 四层容器结构

```
Page（页面层）
  └── Section（区域层）- 页面的大块分区
        └── Block（模块层）- 功能独立的组件组合
              └── Element（元素层）- 最小可复用单元
```

### 层级说明

| 层级 | 命名示例 | 说明 | 类比 |
|-----|---------|------|------|
| Page | `.page-dashboard` | 整个页面 | 房子 |
| Section | `.header-section` | 页面区域 | 房间 |
| Block | `.filter-module` | 功能模块 | 家具 |
| Element | `.filter-module__input` | 模块元素 | 抽屉 |

---

## BEM命名规范

### 命名规则

```css
/* Block（模块） */
.filter-module { }

/* Element（元素）- 双下划线连接 */
.filter-module__header { }
.filter-module__body { }
.filter-module__footer { }

/* Modifier（修饰符）- 双横线连接 */
.filter-module--collapsed { }
.filter-module__btn--primary { }
.filter-module__btn--disabled { }
```

### 命名原则

1. **语义化**：名称反映功能和用途，而非外观
   ```css
   /* 好的命名 */
   .user-card { }
   .search-form { }
   
   /* 避免 */
   .blue-box { }
   .big-text { }
   ```

2. **单一职责**：每个Block只负责一个功能
   ```css
   /* 好的拆分 */
   .filter-module { }  /* 筛选功能 */
   .list-module { }    /* 列表功能 */
   
   /* 避免 */
   .filter-and-list { }  /* 职责混杂 */
   ```

3. **独立性**：Block可独立存在，不依赖上下文
   ```css
   /* 好的设计 */
   .filter-module { }  /* 可以在任何页面使用 */
   
   /* 避免 */
   .user-page .filter { }  /* 依赖特定页面 */
   ```

---

## 标准区域与模块

### 1. 头部区域（Header Section）

**典型模块**：
- `.page-header` - 页面标题模块
- `.breadcrumb-module` - 面包屑导航模块
- `.page-actions` - 页面操作模块

**组件令牌示例**：
```
NAV::Breadcrumb::default → 面包屑导航
GEN::Button::primary → 新建/主要操作按钮
GEN::Typography::title::h1 → 页面标题
```

### 2. 筛选区域（Filter Section）

**典型模块**：
- `.filter-module` - 筛选条件模块
- `.search-module` - 搜索模块
- `.toolbar-module` - 工具栏模块（筛选+操作）

**组件令牌示例**：
```
ENT::Input::search → 搜索输入框
ENT::Select::single → 下拉选择器
GEN::Button::default → 查询/重置按钮
```

### 3. 内容区域（Content Section）

**典型模块**：
- `.table-module` - 数据表格模块
- `.card-list-module` - 卡片列表模块
- `.detail-module` - 详情展示模块
- `.form-module` - 表单模块

**组件令牌示例**：
```
DISP::Table::selection → 可选择表格
DISP::Card::basic → 信息卡片
ENT::Form::vertical → 垂直表单
```

### 4. 操作区域（Action Section）

**典型模块**：
- `.pagination-module` - 分页模块
- `.batch-actions` - 批量操作模块
- `.form-actions` - 表单提交模块

**组件令牌示例**：
```
DISP::Pagination::default → 分页器
GEN::Button::group → 操作按钮组
FB::Modal::confirm → 确认弹窗
```

---

## 模块模板库

模块模板库位于 `references/module-templates.md`，提供标准化的HTML结构模板。

### 使用方式

1. **选择模块类型** → 从模板库选择合适的模块模板
2. **配置参数** → 根据需求调整模块参数
3. **放置令牌** → 在模块容器中放置组件令牌
4. **输出结构** → 生成最终的BEM结构+组件令牌

### 模板示例

```yaml
模块: filter-module
用途: 筛选条件区域
参数:
  has_search: true        # 是否显示搜索框
  has_filter: true        # 是否显示筛选条件
  has_action: true        # 是否显示操作按钮
  filter_count: 3         # 筛选项数量
  
BEM结构:
  Block: .filter-module
  Elements:
    - .filter-module__search-container
    - .filter-module__filter-container
    - .filter-module__action-container
    
组件令牌:
  - ENT::Input::search → .filter-module__search-input
  - ENT::Select::single → .filter-module__select
  - GEN::Button::primary → .filter-module__btn--primary
```

---

## 字段描述规范

### 字段结构

```yaml
字段名: [name]
显示名: [label]
数据类型: [string/number/date/enum/boolean]
组件令牌: [token]
必填: [true/false]
默认值: [value]
校验规则:
  - 规则1
  - 规则2
业务说明: [description]
```

### 字段示例

```yaml
字段名: customer_name
显示名: 客户名称
数据类型: string
组件令牌: ENT::Input::text
必填: true
校验规则:
  - 最大长度: 100
  - 不能为空
业务说明: 客户的公司名称或个人姓名
```

---

## 组件令牌与BEM映射

### 映射原则

组件令牌描述「是什么」，BEM命名描述「在哪里」。映射表提供参考，但不限制灵活性。

### 示例映射

| 组件令牌 | 推荐BEM容器 | 说明 |
|---------|------------|------|
| `GEN::Button::primary` | `.xxx-module__btn--primary` | 主按钮 |
| `ENT::Input::text` | `.xxx-module__input` | 文本输入框 |
| `DISP::Table::selection` | `.xxx-module__table` | 可选择表格 |
| `NAV::Breadcrumb::default` | `.breadcrumb-module__nav` | 面包屑导航 |

### 灵活放置

同一组件令牌可放置在不同容器中：

```yaml
# 场景1：表格内操作
组件令牌: GEN::Button::link
BEM容器: .table-module__action-btn

# 场景2：表单提交
组件令牌: GEN::Button::primary  
BEM容器: .form-module__submit-btn

# 场景3：页面头部
组件令牌: GEN::Button::primary
BEM容器: .page-header__action-btn
```

---

## 输出规范

### 模块设计输出格式

```markdown
## 模块详细设计

### 区域: [区域名称]

#### 模块容器（BEM）
- **父级容器**：[Section级容器]
- **模块容器**：[Block级容器]
- **子容器列表**：
  - [Element级容器1]
  - [Element级容器2]

#### 组件令牌清单
| 序号 | 组件令牌 | 用途 | BEM容器 | 配置 |
|-----|---------|------|--------|------|
| 1 | [token] | [说明] | [bem] | [props] |

#### 字段说明
| 字段名 | 显示名 | 类型 | 组件令牌 | 必填 | 说明 |
|-------|-------|------|---------|------|------|
| [name] | [label] | [type] | [token] | [req] | [desc] |

#### 交互说明
- **交互1**：[描述]
- **交互2**：[描述]
```

---

## 参考文档

- `references/bem-naming.md` - BEM命名规范详解
- `references/module-structure.md` - 四层容器结构
- `references/module-templates.md` - 模块HTML模板库
- `references/module-best-practices.md` - 最佳实践
- `../design-system/component-tokens.md` - 组件令牌系统（D2C规则）
- `../design-system/design-decisions.md` - 设计决策依据
