# 标准模块库

## 1. 概述

本文档定义了常用的标准模块容器,提供可直接复用的模块设计规范。

---

## 2. 头部模块 (`.header-module`)

### 2.1 模块描述

页面头部区域,包含标题、描述和操作按钮。

### 2.2 结构

```
.header-module
├── .header-module__title-container
│   ├── .header-module__title
│   └── .header-module__subtitle
└── .header-module__action-container
    └── .header-module__action-btn
```

### 2.3 命名规范

```css
.header-module                  /* 块: 头部模块 */
.header-module__title-container  /* 元素: 标题容器 */
.header-module__title           /* 元素: 标题 */
.header-module__subtitle        /* 元素: 副标题 */
.header-module__action-container/* 元素: 操作容器 */
.header-module__action-btn      /* 元素: 操作按钮 */
```

### 2.4 设计参数

| 属性 | 值 |
|-----|-----|
| 高度 | 64px |
| 背景色 | #FFFFFF |
| 内边距 | 16px |
| 元素间距 | 16px |
| 底部边框 | 1px solid #F0F0F0 |

### 2.5 变体

```css
.header-module--compact   /* 紧凑模式: 高度48px */
.header-module--expanded  /* 展开模式: 高度96px */
.header-module--bordered  /* 带边框模式 */
```

### 2.6 响应式

```css
@media (max-width: 768px) {
  .header-module {
    padding: 12px;
  }
  
  .header-module__title {
    font-size: 16px;
  }
}
```

### 2.7 使用示例

```html
<header class="header-module">
  <div class="header-module__title-container">
    <h1 class="header-module__title">用户列表</h1>
    <p class="header-module__subtitle">管理系统用户信息</p>
  </div>
  
  <div class="header-module__action-container">
    <button class="btn btn--primary header-module__action-btn">添加用户</button>
    <button class="btn btn--secondary header-module__action-btn">批量导出</button>
  </div>
</header>
```

---

## 3. 筛选模块 (`.filter-module`)

### 3.1 模块描述

提供搜索和筛选功能的区域。

### 3.2 结构

```
.filter-module
├── .filter-module__search-container
│   └── .filter-module__search-input
├── .filter-module__select-container
│   └── .filter-module__select
├── .filter-module__date-container
│   └── .filter-module__date-picker
└── .filter-module__tag-container
    └── .filter-module__tag
```

### 3.3 命名规范

```css
.filter-module                  /* 块: 筛选模块 */
.filter-module__search-container /* 元素: 搜索容器 */
.filter-module__search-input    /* 元素: 搜索输入框 */
.filter-module__select-container/* 元素: 选择器容器 */
.filter-module__select          /* 元素: 选择器 */
.filter-module__date-container  /* 元素: 日期容器 */
.filter-module__date-picker     /* 元素: 日期选择器 */
.filter-module__tag-container   /* 元素: 标签容器 */
.filter-module__tag             /* 元素: 标签 */
```

### 3.4 设计参数

| 属性 | 值 |
|-----|-----|
| 背景色 | #FFFFFF |
| 内边距 | 16px |
| 元素间距 | 12px |
| 圆角 | 8px |

### 3.5 标准组件

#### 3.5.1 搜索框

```html
<div class="filter-module__search-container">
  <input type="text" class="filter-module__search-input" placeholder="搜索...">
</div>
```

#### 3.5.2 下拉选择器

```html
<div class="filter-module__select-container">
  <select class="filter-module__select">
    <option value="">所有部门</option>
    <option value="tech">技术部</option>
    <option value="product">产品部</option>
  </select>
</div>
```

#### 3.5.3 日期范围

```html
<div class="filter-module__date-container">
  <input type="date" class="filter-module__date-picker">
</div>
```

#### 3.5.4 标签筛选

```html
<div class="filter-module__tag-container">
  <span class="filter-module__tag filter-module__tag--active">全部</span>
  <span class="filter-module__tag">活跃</span>
  <span class="filter-module__tag">禁用</span>
</div>
```

### 3.6 响应式

```css
@media (max-width: 768px) {
  .filter-module {
    padding: 12px;
  }
  
  .filter-module__container {
    flex-direction: column;
  }
  
  .filter-module__container > * {
    width: 100%;
  }
}
```

### 3.7 使用示例

```html
<section class="filter-module">
  <div class="filter-module__search-container">
    <input type="text" class="filter-module__search-input" placeholder="搜索用户名、邮箱...">
  </div>
  
  <div class="filter-module__select-container">
    <select class="filter-module__select">
      <option value="">所有部门</option>
      <option value="tech">技术部</option>
      <option value="product">产品部</option>
    </select>
  </div>
  
  <div class="filter-module__tag-container">
    <span class="filter-module__tag filter-module__tag--active">全部</span>
    <span class="filter-module__tag">活跃</span>
    <span class="filter-module__tag">禁用</span>
  </div>
</section>
```

---

## 4. 列表模块 (`.list-module`)

### 4.1 模块描述

展示列表数据的区域,支持多种列表项类型。

### 4.2 结构

```
.list-module
└── .list-item
    ├── .list-item__left-container
    │   ├── .list-item__checkbox
    │   ├── .list-item__drag-handle
    │   └── .list-item__status
    ├── .list-item__main-container
    │   ├── .list-item__title
    │   ├── .list-item__desc
    │   └── .list-item__meta
    └── .list-item__right-container
        ├── .list-item__primary-btn
        └── .list-item__more-menu
```

### 4.3 命名规范

```css
.list-module                    /* 块: 列表模块 */
.list-item                      /* 块: 列表项 */
.list-item__left-container      /* 元素: 左侧容器 */
.list-item__checkbox            /* 元素: 选择框 */
.list-item__drag-handle         /* 元素: 拖拽手柄 */
.list-item__status              /* 元素: 状态 */
.list-item__main-container      /* 元素: 主内容容器 */
.list-item__title               /* 元素: 标题 */
.list-item__desc                /* 元素: 描述 */
.list-item__meta                /* 元素: 元信息 */
.list-item__right-container     /* 元素: 右侧容器 */
.list-item__primary-btn         /* 元素: 主要按钮 */
.list-item__more-menu           /* 元素: 更多菜单 */
```

### 4.4 设计参数

| 属性 | 紧凑型 | 标准型 |
|-----|-------|-------|
| 行高 | 72px | 88px |
| 内边距 | 16px | 20px |
| 分割线 | 1px solid #F0F0F0 | 1px solid #F0F0F0 |
| 悬停背景 | #FAFAFA | #FAFAFA |

### 4.5 列表项变体

```css
.list-item--compact    /* 紧凑模式: 高度72px */
.list-item--expanded   /* 展开模式: 高度88px */
.list-item--selected   /* 选中状态 */
.list-item--disabled   /* 禁用状态 */
.list-item--loading    /* 加载状态 */
```

### 4.6 列表项状态

```css
.list-item--selected {
  background-color: #E6F7FF;
  border-color: #1890FF;
}

.list-item--disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.list-item--loading {
  /* 加载中样式 */
}
```

### 4.7 使用示例

```html
<main class="list-module">
  <div class="list-item list-item--selected">
    <div class="list-item__left-container">
      <input type="checkbox" class="list-item__checkbox">
      <span class="list-item__status status--success"></span>
    </div>
    
    <div class="list-item__main-container">
      <h3 class="list-item__title">张三</h3>
      <p class="list-item__desc">高级工程师 | 技术部</p>
      <div class="list-item__meta">
        <span class="list-item__meta-item">入职时间: 2023-01-15</span>
        <span class="list-item__meta-item">工号: EMP001</span>
      </div>
    </div>
    
    <div class="list-item__right-container">
      <button class="btn btn--icon list-item__primary-btn">编辑</button>
      <button class="btn btn--icon list-item__more-menu">更多</button>
    </div>
  </div>
</main>
```

---

## 5. 分页模块 (`.pagination-module`)

### 5.1 模块描述

分页控件所在的区域,提供页码跳转和分页信息。

### 5.2 结构

```
.pagination-module
├── .pagination-module__prev-btn
├── .pagination-module__page-numbers
│   └── .pagination-module__page-number
├── .pagination-module__next-btn
├── .pagination-module__info
│   ├── .pagination-module__total
│   └── .pagination-module__page-size
└── .pagination-module__jump-container
    └── .pagination-module__jump-input
```

### 5.3 命名规范

```css
.pagination-module                  /* 块: 分页模块 */
.pagination-module__prev-btn        /* 元素: 上一页按钮 */
.pagination-module__page-numbers    /* 元素: 页码容器 */
.pagination-module__page-number     /* 元素: 页码 */
.pagination-module__next-btn        /* 元素: 下一页按钮 */
.pagination-module__info            /* 元素: 分页信息 */
.pagination-module__total           /* 元素: 总条数 */
.pagination-module__page-size       /* 元素: 每页条数 */
.pagination-module__jump-container  /* 元素: 跳转容器 */
.pagination-module__jump-input       /* 元素: 跳转输入框 */
```

### 5.4 设计参数

| 属性 | 值 |
|-----|-----|
| 对齐方式 | 居中或右对齐 |
| 页数显示 | 最多显示7个页码 |
| 页码大小 | 32px |
| 页码圆角 | 4px |

### 5.5 分页样式

```css
.pagination-module__page-number {
  width: 32px;
  height: 32px;
  border-radius: 4px;
  border: 1px solid #D9D9D9;
  background-color: #FFFFFF;
  color: #262626;
}

.pagination-module__page-number--active {
  background-color: #1890FF;
  border-color: #1890FF;
  color: #FFFFFF;
}

.pagination-module__page-number:hover {
  border-color: #1890FF;
  color: #1890FF;
}
```

### 5.6 使用示例

```html
<footer class="pagination-module">
  <div class="pagination-module__info">
    共50条, 每页20条
  </div>
  
  <div class="pagination-module__page-numbers">
    <button class="pagination-module__prev-btn">上一页</button>
    <span class="pagination-module__page-number">1</span>
    <span class="pagination-module__page-number pagination-module__page-number--active">2</span>
    <span class="pagination-module__page-number">3</span>
    <span class="pagination-module__page-number">...</span>
    <span class="pagination-module__page-number">10</span>
    <button class="pagination-module__next-btn">下一页</button>
  </div>
  
  <div class="pagination-module__jump-container">
    跳至
    <input type="number" class="pagination-module__jump-input">
    页
  </div>
</footer>
```

---

## 6. 空状态模块 (`.empty-module`)

### 6.1 模块描述

列表无数据时展示的空状态区域。

### 6.2 结构

```
.empty-module
├── .empty-module__icon
├── .empty-module__title
├── .empty-module__description
└── .empty-module__action
```

### 6.3 命名规范

```css
.empty-module              /* 块: 空状态模块 */
.empty-module__icon       /* 元素: 空状态图标 */
.empty-module__title      /* 元素: 空状态标题 */
.empty-module__description/* 元素: 空状态描述 */
.empty-module__action     /* 元素: 操作按钮 */
```

### 6.4 设计参数

| 属性 | 值 |
|-----|-----|
| 最小高度 | 200px |
| 内边距 | 40px |
| 图标尺寸 | 80px |
| 标题字体 | 16px/500 |
| 描述字体 | 14px/颜色:#8C8C8C |

### 6.5 使用示例

```html
<div class="empty-module">
  <div class="empty-module__icon">
    <!-- 空状态图标 -->
  </div>
  <h3 class="empty-module__title">暂无数据</h3>
  <p class="empty-module__description">还没有任何用户,点击下方按钮添加</p>
  <button class="btn btn--primary empty-module__action">添加用户</button>
</div>
```

---

## 7. 加载状态模块 (`.loading-module`)

### 7.1 模块描述

数据加载时展示的加载状态区域。

### 7.2 结构

```
.loading-module
└── .loading-module__spinner
```

### 7.3 设计参数

| 属性 | 值 |
|-----|-----|
| 最小高度 | 200px |
| 加载器尺寸 | 40px |
| 背景色 | #FFFFFF |

### 7.4 使用示例

```html
<div class="loading-module">
  <div class="loading-module__spinner"></div>
</div>
```

---

## 8. 模块组合示例

### 8.1 完整列表页面

```html
<div class="list-page">
  <!-- 头部模块 -->
  <header class="header-module">
    <div class="header-module__title-container">
      <h1 class="header-module__title">用户列表</h1>
    </div>
    <div class="header-module__action-container">
      <button class="btn btn--primary">添加用户</button>
    </div>
  </header>
  
  <!-- 筛选模块 -->
  <section class="filter-module">
    <div class="filter-module__search-container">
      <input type="text" class="filter-module__search-input" placeholder="搜索...">
    </div>
    <div class="filter-module__select-container">
      <select class="filter-module__select">
        <option value="">所有部门</option>
      </select>
    </div>
  </section>
  
  <!-- 列表模块 -->
  <main class="list-module">
    <div class="list-item">
      <!-- 列表项内容 -->
    </div>
  </main>
  
  <!-- 分页模块 -->
  <footer class="pagination-module">
    <!-- 分页内容 -->
  </footer>
</div>
```

---

## 9. 模块扩展指南

### 9.1 自定义模块

基于标准模块创建自定义模块:

1. 保持命名规范
2. 遵循设计Token
3. 考虑复用性
4. 完善文档说明

### 9.2 模块变体

使用修饰符创建模块变体:

```css
.custom-module--variant-1
.custom-module--variant-2
```

### 9.3 模块组合

将多个标准模块组合成复杂场景:

```
页面
├── 头部模块
├── 筛选模块
├── 列表模块
│   ├── 空状态模块 (无数据时)
│   └── 加载状态模块 (加载中)
└── 分页模块
```

---

## 10. 模块验收清单

### 10.1 命名检查

- [ ] 遵循BEM命名规范
- [ ] 命名具有语义化
- [ ] 命名保持一致性

### 10.2 结构检查

- [ ] 模块结构清晰
- [ ] 嵌套层次合理
- [ ] 模块职责明确

### 10.3 样式检查

- [ ] 使用设计Token
- [ ] 响应式适配完整
- [ ] 变体状态完整

### 10.4 可复用性检查

- [ ] 模块可独立使用
- [ ] 模块可组合使用
- [ ] 模块易于扩展

---

**版本**: 1.0.0  
**最后更新**: 2025-03-23
