# 模块设计最佳实践

## 1. 设计原则

### 1.1 核心原则

模块设计应遵循以下核心原则:

- **单一职责**: 每个模块只负责一个功能
- **开闭原则**: 对扩展开放,对修改关闭
- **依赖倒置**: 依赖抽象而非具体实现
- **接口隔离**: 模块接口最小化

### 1.2 设计目标

- **可复用性**: 模块可在不同场景复用
- **可维护性**: 模块易于理解和修改
- **可扩展性**: 模块易于添加新功能
- **可测试性**: 模块易于单元测试

---

## 2. 模块设计流程

### 2.1 需求分析

**步骤1: 识别功能模块**

```
输入: 页面功能需求
输出: 功能模块列表
```

**示例**:
- 用户列表页 → 头部模块、筛选模块、列表模块、分页模块
- 表单页 → 标题模块、表单模块、提交模块

**步骤2: 确定模块边界**

```
明确每个模块的:
- 职责范围
- 输入输出
- 依赖关系
```

**步骤3: 模块优先级排序**

```
P0: 核心功能模块
P1: 重要功能模块
P2: 辅助功能模块
```

### 2.2 模块设计

**步骤1: 设计模块结构**

```
模块层次:
页面底层
├── 父级容器
│   ├── 模块容器
│   └── 子容器
```

**步骤2: 应用命名规范**

```css
遵循BEM规范:
.{module-name}          /* 块 */
.{module-name}__element /* 元素 */
.{module-name}--modifier/* 修饰符 */
```

**步骤3: 定义设计参数**

```
布局参数:
- 布局方式
- 间距
- 内边距

样式参数:
- 颜色
- 字体
- 圆角

交互参数:
- 悬停状态
- 激活状态
- 禁用状态
```

**步骤4: 响应式设计**

```
断点:
- 移动端: < 768px
- 平板: 768px - 1024px
- 桌面: > 1024px

适配规则:
- 布局变化
- 间距调整
- 元素显示/隐藏
```

### 2.3 模块验证

**检查清单**:

- [ ] 模块职责明确
- [ ] 模块边界清晰
- [ ] 命名规范统一
- [ ] 设计参数合理
- [ ] 响应式适配完整
- [ ] 变体状态完整
- [ ] 可复用性良好

---

## 3. 模块设计模式

### 3.1 容器模式

**描述**: 使用容器包装子元素,提供统一的布局和样式。

**示例**:

```html
<div class="header-module">
  <div class="header-module__title-container">
    <h1 class="header-module__title">标题</h1>
  </div>
  <div class="header-module__action-container">
    <button class="btn">按钮</button>
  </div>
</div>
```

**优点**:
- 统一的布局
- 清晰的结构
- 易于维护

**适用场景**: 头部、侧边栏、底部等固定区域

---

### 3.2 列表模式

**描述**: 使用重复的列表项容器展示同类型数据。

**示例**:

```html
<div class="list-module">
  <div class="list-item">
    <div class="list-item__left">
      <input type="checkbox">
    </div>
    <div class="list-item__main">
      <h3 class="list-item__title">标题</h3>
      <p class="list-item__desc">描述</p>
    </div>
    <div class="list-item__right">
      <button class="btn">编辑</button>
    </div>
  </div>
</div>
```

**优点**:
- 统一的列表项样式
- 易于批量操作
- 支持变体状态

**适用场景**: 列表页、表格、卡片列表

---

### 3.3 表单模式

**描述**: 使用表单容器包装表单元素,提供统一的表单样式。

**示例**:

```html
<div class="form-module">
  <div class="form-group">
    <label class="form-group__label">用户名</label>
    <input type="text" class="form-group__input">
    <span class="form-group__error">错误信息</span>
  </div>
  <div class="form-group">
    <label class="form-group__label">密码</label>
    <input type="password" class="form-group__input">
  </div>
</div>
```

**优点**:
- 统一的表单样式
- 内置错误提示
- 易于表单验证

**适用场景**: 表单页、弹窗表单

---

### 3.4 卡片模式

**描述**: 使用卡片容器包装内容,提供独立的内容块。

**示例**:

```html
<div class="card card--shadow">
  <div class="card__header">
    <h3 class="card__title">卡片标题</h3>
  </div>
  <div class="card__body">
    <p class="card__text">卡片内容</p>
  </div>
  <div class="card__footer">
    <button class="btn">确定</button>
  </div>
</div>
```

**优点**:
- 独立的内容块
- 统一的卡片样式
- 易于组合使用

**适用场景**: 卡片列表、信息展示、详情页

---

## 4. 模块复用策略

### 4.1 级别1: 完全复用

**描述**: 模块无需修改即可在不同场景使用。

**示例**: 头部模块、分页模块

**优点**: 开发效率高
**缺点**: 灵活性低

### 4.2 级别2: 配置复用

**描述**: 通过配置参数调整模块行为。

**示例**: 列表模块(通过变体控制布局)

```html
<div class="list-item list-item--compact">紧凑模式</div>
<div class="list-item list-item--expanded">展开模式</div>
```

**优点**: 灵活性高
**缺点**: 需要设计多个变体

### 4.3 级别3: 继承复用

**描述**: 继承基础模块,扩展自定义功能。

**示例**: 自定义列表项继承基础列表项

```css
.custom-list-item {
  /* 继承基础样式 */
  @extend .list-item;
  
  /* 扩展自定义样式 */
  background-color: #F0F0F0;
}
```

**优点**: 可扩展性强
**缺点**: 需要维护继承关系

### 4.4 级别4: 组合复用

**描述**: 组合多个基础模块,构建复杂场景。

**示例**: 用户管理页面 = 头部模块 + 筛选模块 + 列表模块 + 分页模块

**优点**: 灵活性最高
**缺点**: 组合复杂度高

---

## 5. 模块性能优化

### 5.1 减少嵌套

**优化前**:

```html
<div class="list-page">
  <div class="list-page__container">
    <div class="list-page__list">
      <div class="list-page__list__item">
        <!-- 内容 -->
      </div>
    </div>
  </div>
</div>
```

**优化后**:

```html
<div class="list-page">
  <div class="list-module">
    <div class="list-item">
      <!-- 内容 -->
    </div>
  </div>
</div>
```

### 5.2 避免过度修饰符

**优化前**:

```css
.list-item--selected--large--primary
.list-item--selected--small--secondary
```

**优化后**:

```css
.list-item--selected
.list-item--large
.list-item--primary
```

### 5.3 使用CSS变量

**优化前**:

```css
.list-item {
  padding: 16px;
  background-color: #FFFFFF;
  border: 1px solid #F0F0F0;
}

.list-item--selected {
  background-color: #E6F7FF;
  border-color: #1890FF;
}
```

**优化后**:

```css
.list-item {
  padding: var(--spacing-md);
  background-color: var(--color-bg-white);
  border: 1px solid var(--color-border-light);
}

.list-item--selected {
  background-color: var(--color-primary-bg);
  border-color: var(--color-primary);
}
```

---

## 6. 模块可访问性

### 6.1 语义化标签

**推荐**:

```html
<!-- ✅ 使用语义化标签 -->
<header class="header-module">
  <h1 class="header-module__title">标题</h1>
</header>

<main class="list-module">
  <article class="list-item">
    <h3 class="list-item__title">标题</h3>
  </article>
</main>
```

### 6.2 ARIA标签

**推荐**:

```html
<!-- 添加ARIA标签 -->
<div class="list-item" role="listitem">
  <button class="btn" aria-label="编辑">编辑</button>
</div>
```

### 6.3 键盘导航

**推荐**:

```css
/* 支持键盘导航 */
.list-item:focus {
  outline: 2px solid #1890FF;
  outline-offset: 2px;
}
```

---

## 7. 模块测试

### 7.1 单元测试

**测试点**:

- 模块渲染正确
- 样式正确应用
- 变体状态正确
- 响应式适配正确

### 7.2 集成测试

**测试点**:

- 模块组合正确
- 模块间通信正确
- 数据流转正确

### 7.3 视觉回归测试

**测试点**:

- 视觉样式一致
- 无意外变化
- 响应式正确

---

## 8. 模块文档

### 8.1 文档内容

每个模块应包含以下文档:

1. **模块描述**: 模块的功能和用途
2. **结构图**: 模块的HTML结构
3. **命名规范**: BEM命名规则
4. **设计参数**: 布局、样式、交互参数
5. **使用示例**: 实际使用代码
6. **变体说明**: 各种变体状态
7. **响应式规则**: 不同断点的适配规则

### 8.2 文档格式

```markdown
# 模块名称

## 模块描述
简要描述模块的功能和用途

## 模块结构
```
模块层次结构图
```

## 命名规范
BEM命名规则

## 设计参数
| 属性 | 值 |
|-----|-----|
| 属性1 | 值1 |

## 使用示例
实际使用代码

## 变体说明
各种变体状态

## 响应式规则
不同断点的适配规则
```

---

## 9. 模块维护

### 9.1 版本管理

```
v1.0.0: 初始版本
v1.0.1: 修复bug
v1.1.0: 新增功能
v2.0.0: 重大更新
```

### 9.2 变更日志

```
## [1.0.1] - 2025-03-23
### 修复
- 修复列表项悬停状态不正确的问题

## [1.1.0] - 2025-03-20
### 新增
- 新增列表项紧凑模式变体
- 新增列表项加载状态
```

### 9.3 弃用策略

```
1. 标记为弃用
2. 提供替代方案
3. 保留一段时间
4. 移除弃用代码
```

---

## 10. 模块验收清单

### 10.1 设计验收

- [ ] 模块职责明确
- [ ] 模块边界清晰
- [ ] 命名规范统一
- [ ] 设计参数合理
- [ ] 响应式适配完整
- [ ] 变体状态完整

### 10.2 实现验收

- [ ] 代码结构清晰
- [ ] 样式正确应用
- [ ] 性能优化到位
- [ ] 可访问性良好
- [ ] 测试覆盖完整

### 10.3 文档验收

- [ ] 文档内容完整
- [ ] 示例代码正确
- [ ] 图表清晰易懂
- [ ] 变更日志完整

---

## 11. 常见问题

### 11.1 模块过深嵌套怎么办?

**解决方案**:
- 重新设计模块结构
- 使用扁平化设计
- 提取公共模块

### 11.2 模块样式冲突怎么办?

**解决方案**:
- 检查BEM命名规范
- 使用CSS模块化
- 检查优先级

### 11.3 模块复用性差怎么办?

**解决方案**:
- 减少特定场景耦合
- 使用配置参数
- 提供变体状态

### 11.4 模块响应式复杂怎么办?

**解决方案**:
- 简化响应式规则
- 使用组件库
- 提供移动端专用模块

---

## 12. 总结

模块设计是前端工程化的核心,遵循最佳实践可以:

1. **提高开发效率**: 通过模块复用减少重复工作
2. **提升代码质量**: 统一的规范和标准
3. **降低维护成本**: 清晰的结构和文档
4. **增强团队协作**: 统一的设计语言

---

**版本**: 1.0.0  
**最后更新**: 2025-03-23
