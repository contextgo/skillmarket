# 设计Token系统

## 1. 概述

### 1.1 定义

设计Token是设计系统中语义化的变量,用于维护设计的一致性。包括颜色、间距、字体、圆角等设计基础元素。

### 1.2 优势

- **一致性**: 确保整个系统的视觉一致性
- **可维护性**: 修改Token即可全局更新
- **可扩展性**: 易于添加新的Token
- **跨平台**: 可在不同平台(CSS、Flutter、React Native等)使用

---

## 2. 颜色Token

### 2.1 主色系统

```css
/* 主色 */
--color-primary: #1890FF;
--color-primary-hover: #40A9FF;
--color-primary-active: #096DD9;
--color-primary-bg: #E6F7FF;
--color-primary-border: #91D5FF;

/* 成功色 */
--color-success: #52C41A;
--color-success-hover: #73D13D;
--color-success-active: #389E0D;
--color-success-bg: #F6FFED;
--color-success-border: #B7EB8F;

/* 警告色 */
--color-warning: #FAAD14;
--color-warning-hover: #FFD666;
--color-warning-active: #D48806;
--color-warning-bg: #FFFBE6;
--color-warning-border: #FFE58F;

/* 错误色 */
--color-error: #FF4D4F;
--color-error-hover: #FF7875;
--color-error-active: #D9363E;
--color-error-bg: #FFF2F0;
--color-error-border: #FFCCC7;

/* 信息色 */
--color-info: #1890FF;
--color-info-hover: #40A9FF;
--color-info-active: #096DD9;
--color-info-bg: #E6F7FF;
--color-info-border: #91D5FF;
```

### 2.2 中性色系统

```css
/* 文字颜色 */
--color-text-primary: #262626;      /* 主要文字 */
--color-text-secondary: #595959;    /* 次要文字 */
--color-text-tertiary: #8C8C8C;     /* 辅助文字 */
--color-text-disabled: #BFBFBF;     /* 禁用文字 */

/* 边框颜色 */
--color-border-base: #D9D9D9;       /* 基础边框 */
--color-border-light: #F0F0F0;      /* 浅色边框 */
--color-border-lighter: #FAFAFA;    /* 更浅边框 */
--color-border-dark: #262626;       /* 深色边框 */

/* 背景颜色 */
--color-bg-base: #F5F5F5;           /* 基础背景 */
--color-bg-light: #FAFAFA;          /* 浅色背景 */
--color-bg-white: #FFFFFF;          /* 白色背景 */
--color-bg-overlay: rgba(0, 0, 0, 0.45); /* 遮罩背景 */
```

### 2.3 功能色

```css
/* 链接色 */
--color-link: #1890FF;
--color-link-hover: #40A9FF;
--color-link-active: #096DD9;

/* 高亮色 */
--color-highlight: #E6F7FF;
--color-highlight-border: #91D5FF;

/* 分割线 */
--color-divider: #F0F0F0;
```

### 2.4 状态指示色

```css
.status--success {
  color: var(--color-success);
  background-color: var(--color-success-bg);
  border-color: var(--color-success-border);
}

.status--warning {
  color: var(--color-warning);
  background-color: var(--color-warning-bg);
  border-color: var(--color-warning-border);
}

.status--error {
  color: var(--color-error);
  background-color: var(--color-error-bg);
  border-color: var(--color-error-border);
}

.status--info {
  color: var(--color-info);
  background-color: var(--color-info-bg);
  border-color: var(--color-info-border);
}

.status--disabled {
  color: var(--color-text-disabled);
  background-color: var(--color-bg-light);
}
```

---

## 3. 间距Token

### 3.1 基础间距

```css
/* 8px倍数系统 */
--spacing-xs: 4px;     /* 超小间距 */
--spacing-sm: 8px;     /* 小间距 */
--spacing-md: 16px;    /* 中间距 */
--spacing-lg: 24px;    /* 大间距 */
--spacing-xl: 32px;    /* 超大间距 */
--spacing-xxl: 48px;   /* 特大间距 */
```

### 3.2 模块间距

```css
/* 模块容器间距 */
--module-gap-sm: 16px;
--module-gap-md: 24px;
--module-gap-lg: 32px;

/* 元素间距 */
--element-gap-xs: 4px;
--element-gap-sm: 8px;
--element-gap-md: 12px;
--element-gap-lg: 16px;
```

### 3.3 容器内边距

```css
/* 页面容器内边距 */
--page-padding: 24px;
--page-padding-mobile: 12px;

/* 模块容器内边距 */
--module-padding: 24px;
--module-padding-compact: 16px;
--module-padding-expanded: 32px;

/* 卡片内边距 */
--card-padding: 24px;
--card-padding-compact: 16px;
--card-padding-expanded: 32px;
```

### 3.4 按钮间距

```css
/* 按钮间距 */
--button-gap: 12px;
--button-group-gap: 8px;
```

---

## 4. 字体Token

### 4.1 字体大小

```css
/* 字体大小 */
--font-size-xs: 12px;     /* 超小字体 */
--font-size-sm: 14px;     /* 小字体 */
--font-size-md: 16px;     /* 中字体 */
--font-size-lg: 18px;     /* 大字体 */
--font-size-xl: 20px;     /* 超大字体 */
--font-size-xxl: 24px;    /* 标题字体 */
--font-size-xxxl: 30px;   /* 大标题字体 */
```

### 4.2 字体粗细

```css
/* 字体粗细 */
--font-weight-light: 300;
--font-weight-regular: 400;
--font-weight-medium: 500;
--font-weight-semibold: 600;
--font-weight-bold: 700;
```

### 4.3 行高

```css
/* 行高 */
--line-height-xs: 1.2;
--line-height-sm: 1.4;
--line-height-md: 1.5;
--line-height-lg: 1.6;
--line-height-xl: 1.8;
```

### 4.4 字体家族

```css
/* 字体家族 */
--font-family-base: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
--font-family-code: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
```

### 4.5 字体应用示例

```css
/* 标题 */
.typography__h1 {
  font-size: var(--font-size-xxl);
  font-weight: var(--font-weight-bold);
  line-height: var(--line-height-md);
  color: var(--color-text-primary);
}

.typography__h2 {
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-semibold);
  line-height: var(--line-height-md);
  color: var(--color-text-primary);
}

/* 正文 */
.typography__body {
  font-size: var(--font-size-md);
  font-weight: var(--font-weight-regular);
  line-height: var(--line-height-lg);
  color: var(--color-text-primary);
}

/* 辅助文本 */
.typography__secondary {
  font-size: var(--font-size-sm);
  font-weight: var(--font-weight-regular);
  line-height: var(--line-height-md);
  color: var(--color-text-secondary);
}
```

---

## 5. 圆角Token

```css
/* 圆角 */
--border-radius-xs: 2px;   /* 超小圆角 */
--border-radius-sm: 4px;   /* 小圆角 */
--border-radius-md: 8px;   /* 中圆角 */
--border-radius-lg: 12px;  /* 大圆角 */
--border-radius-xl: 16px;  /* 超大圆角 */
--border-radius-circle: 50%; /* 圆形 */
```

### 5.1 圆角应用示例

```css
/* 按钮 */
.btn--small {
  border-radius: var(--border-radius-sm);
}

.btn--medium {
  border-radius: var(--border-radius-md);
}

/* 卡片 */
.card {
  border-radius: var(--border-radius-lg);
}

/* 头像 */
.avatar {
  border-radius: var(--border-radius-circle);
}
```

---

## 6. 阴影Token

```css
/* 阴影 */
--shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.08);      /* 小阴影 */
--shadow-md: 0 4px 12px rgba(0, 0, 0, 0.12);     /* 中阴影 */
--shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.16);     /* 大阴影 */
--shadow-xl: 0 16px 48px rgba(0, 0, 0, 0.20);   /* 超大阴影 */

/* 内阴影 */
--shadow-inner: inset 0 2px 4px rgba(0, 0, 0, 0.06);

/* 悬停阴影 */
--shadow-hover: 0 6px 16px rgba(0, 0, 0, 0.15);

/* 激活阴影 */
--shadow-active: 0 2px 6px rgba(0, 0, 0, 0.10);
```

### 6.1 阴影应用示例

```css
/* 卡片阴影 */
.card--shadow-sm {
  box-shadow: var(--shadow-sm);
}

.card--shadow-md {
  box-shadow: var(--shadow-md);
}

/* 弹窗阴影 */
.modal {
  box-shadow: var(--shadow-lg);
}

/* 下拉菜单阴影 */
.dropdown-menu {
  box-shadow: var(--shadow-md);
}
```

---

## 7. 过渡Token

```css
/* 过渡时长 */
--transition-duration-fast: 150ms;
--transition-duration-base: 200ms;
--transition-duration-slow: 300ms;

/* 过渡缓动 */
--transition-ease-in: cubic-bezier(0.42, 0, 1, 1);
--transition-ease-out: cubic-bezier(0, 0, 0.58, 1);
--transition-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);

/* 过渡组合 */
--transition-fast: all var(--transition-duration-fast) var(--transition-ease-in-out);
--transition-base: all var(--transition-duration-base) var(--transition-ease-in-out);
--transition-slow: all var(--transition-duration-slow) var(--transition-ease-in-out);
```

### 7.1 过渡应用示例

```css
/* 按钮过渡 */
.btn {
  transition: var(--transition-base);
}

.btn:hover {
  background-color: var(--color-primary-hover);
}

/* 输入框过渡 */
.input {
  transition: var(--transition-base);
}

.input:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px var(--color-primary-bg);
}
```

---

## 8. Z-index Token

```css
/* 层级 */
--z-index-dropdown: 1000;      /* 下拉菜单 */
--z-index-sticky: 1020;        /* 吸顶元素 */
--z-index-fixed: 1030;          /* 固定定位 */
--z-index-modal-backdrop: 1040;/* 弹窗遮罩 */
--z-index-modal: 1050;         /* 弹窗 */
--z-index-popover: 1060;       /* 气泡卡片 */
--z-index-tooltip: 1070;       /* 提示框 */
```

---

## 9. 断点Token

```css
/* 断点 */
--breakpoint-xs: 480px;        /* 超小屏幕 */
--breakpoint-sm: 576px;        /* 小屏幕 */
--breakpoint-md: 768px;        /* 平板 */
--breakpoint-lg: 992px;        /* 桌面 */
--breakpoint-xl: 1200px;       /* 大桌面 */
--breakpoint-xxl: 1600px;      /* 超大桌面 */

/* 媒体查询 */
@media (max-width: var(--breakpoint-md)) {
  /* 移动端样式 */
}

@media (min-width: var(--breakpoint-md)) {
  /* 平板样式 */
}

@media (min-width: var(--breakpoint-lg)) {
  /* 桌面样式 */
}
```

---

## 10. Token使用最佳实践

### 10.1 命名规范

```css
/* ✅ 推荐: 语义化命名 */
--color-primary: #1890FF;
--spacing-md: 16px;
--font-size-md: 16px;

/* ❌ 避免: 直接使用值或非语义化命名 */
--blue: #1890FF;
--spacing16: 16px;
--size16: 16px;
```

### 10.2 Token层级

```css
/* 基础Token */
--color-blue-50: #E6F7FF;
--color-blue-500: #1890FF;
--color-blue-600: #096DD9;

/* 语义Token */
--color-primary: var(--color-blue-500);
--color-primary-hover: var(--color-blue-400);
--color-primary-active: var(--color-blue-600);
```

### 10.3 覆盖规则

```css
/* 全局Token */
:root {
  --color-primary: #1890FF;
}

/* 特定场景覆盖 */
.component--custom {
  --color-primary: #722ED1; /* 紫色主题 */
}
```

---

## 11. Token验收清单

### 11.1 完整性检查

- [ ] 颜色Token完整
- [ ] 间距Token完整
- [ ] 字体Token完整
- [ ] 圆角Token完整
- [ ] 阴影Token完整
- [ ] 过渡Token完整
- [ ] 层级Token完整

### 11.2 一致性检查

- [ ] 间距遵循8px倍数
- [ ] 颜色使用语义化命名
- [ ] 字体大小符合设计规范
- [ ] 所有Token有明确用途

### 11.3 可维护性检查

- [ ] Token命名清晰
- [ ] Token分层合理
- [ ] Token易于扩展
- [ ] Token文档完整

---

**版本**: 1.0.0  
**最后更新**: 2025-03-23
