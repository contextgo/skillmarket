# 模块HTML模板库

> 提供标准化的模块HTML结构模板，解决BEM命名在下游HTML生成中的执行问题

---

## 使用说明

### 模板结构

每个模块模板包含以下部分：

1. **模块命名** - BEM Block名称
2. **标准HTML结构** - 基础HTML模板
3. **可配置参数** - YAML格式参数说明
4. **组件令牌映射** - 推荐放置的组件令牌
5. **使用示例** - 完整配置示例

### 使用流程

```
Step 1: 选择模块类型 → 从本库选择合适的模板
Step 2: 配置参数 → 根据需求调整模块参数
Step 3: 映射令牌 → 在模块容器中放置组件令牌
Step 4: 输出设计 → 生成BEM结构 + 组件令牌清单
```

---

## 筛选模块（Filter Module）

### 模块命名
- **Block**: `.filter-module`
- **用途**: 页面筛选条件区域

### 标准HTML结构

```html
<div class="filter-module">
  <!-- 搜索区 -->
  <div class="filter-module__search-container">
    <input class="filter-module__search-input" type="text" placeholder="搜索关键词...">
    <button class="filter-module__search-btn">
      <i class="fa-solid fa-magnifying-glass"></i>
    </button>
  </div>
  
  <!-- 筛选区 -->
  <div class="filter-module__filter-container">
    <div class="filter-module__filter-item">
      <label class="filter-module__filter-label">状态</label>
      <select class="filter-module__filter-select">
        <option value="">全部</option>
        <option value="active">启用</option>
        <option value="inactive">禁用</option>
      </select>
    </div>
  </div>
  
  <!-- 操作区 -->
  <div class="filter-module__action-container">
    <button class="filter-module__btn filter-module__btn--primary">查询</button>
    <button class="filter-module__btn">重置</button>
  </div>
</div>
```

### 可配置参数

```yaml
filter-module:
  has_search: true          # 是否显示搜索框
  has_filter: true          # 是否显示筛选条件
  has_action: true          # 是否显示操作按钮
  filter_count: 3           # 筛选项数量（1-5）
  filter_layout: "horizontal"  # 布局方向: horizontal/vertical
```

### 组件令牌映射

| 元素 | BEM类名 | 推荐组件令牌 |
|-----|--------|-------------|
| 搜索输入框 | `.filter-module__search-input` | `ENT::Input::search` |
| 搜索按钮 | `.filter-module__search-btn` | `GEN::Button::default` |
| 筛选标签 | `.filter-module__filter-label` | `GEN::Typography::text` |
| 筛选下拉 | `.filter-module__filter-select` | `ENT::Select::single` |
| 查询按钮 | `.filter-module__btn--primary` | `GEN::Button::primary` |
| 重置按钮 | `.filter-module__btn` | `GEN::Button::default` |

### 使用示例

```yaml
模块: filter-module
参数:
  has_search: true
  has_filter: true
  has_action: true
  filter_count: 2
  filter_layout: "horizontal"

组件令牌分配:
  - ENT::Input::search → .filter-module__search-input
  - ENT::Select::single → .filter-module__filter-select
  - GEN::Button::primary → .filter-module__btn--primary
  - GEN::Button::default → .filter-module__btn
```

---

## 表格模块（Table Module）

### 模块命名
- **Block**: `.table-module`
- **用途**: 数据表格展示区域

### 标准HTML结构

```html
<div class="table-module">
  <!-- 表格头部 -->
  <div class="table-module__header">
    <h3 class="table-module__title">数据列表</h3>
    <div class="table-module__actions">
      <button class="table-module__btn">批量删除</button>
      <button class="table-module__btn table-module__btn--primary">导出</button>
    </div>
  </div>
  
  <!-- 表格主体 -->
  <div class="table-module__body">
    <table class="table-module__table">
      <thead class="table-module__thead">
        <tr>
          <th class="table-module__th"><input type="checkbox"></th>
          <th class="table-module__th">名称</th>
          <th class="table-module__th">状态</th>
          <th class="table-module__th">操作</th>
        </tr>
      </thead>
      <tbody class="table-module__tbody">
        <tr class="table-module__tr">
          <td class="table-module__td"><input type="checkbox"></td>
          <td class="table-module__td">数据项1</td>
          <td class="table-module__td"><span class="table-module__tag">启用</span></td>
          <td class="table-module__td">
            <a class="table-module__action">编辑</a>
            <a class="table-module__action">删除</a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  
  <!-- 表格底部 -->
  <div class="table-module__footer">
    <div class="table-module__pagination">
      <!-- 分页组件 -->
    </div>
  </div>
</div>
```

### 可配置参数

```yaml
table-module:
  has_header: true          # 是否显示头部
  has_selection: true       # 是否支持批量选择
  has_actions: true         # 是否显示操作列
  has_pagination: true      # 是否显示分页
  action_type: "link"       # 操作类型: link/button/icon
```

### 组件令牌映射

| 元素 | BEM类名 | 推荐组件令牌 |
|-----|--------|-------------|
| 表格 | `.table-module__table` | `DISP::Table::selection` |
| 批量按钮 | `.table-module__btn` | `GEN::Button::default` |
| 主按钮 | `.table-module__btn--primary` | `GEN::Button::primary` |
| 状态标签 | `.table-module__tag` | `GEN::Tag::success/error` |
| 操作链接 | `.table-module__action` | `GEN::Button::link` |
| 分页器 | `.table-module__pagination` | `DISP::Pagination::default` |

---

## 表单模块（Form Module）

### 模块命名
- **Block**: `.form-module`
- **用途**: 数据录入表单区域

### 标准HTML结构

```html
<div class="form-module">
  <!-- 表单头部 -->
  <div class="form-module__header">
    <h3 class="form-module__title">基本信息</h3>
  </div>
  
  <!-- 表单主体 -->
  <div class="form-module__body">
    <div class="form-module__row">
      <div class="form-module__item">
        <label class="form-module__label">
          <span class="form-module__required">*</span>名称
        </label>
        <div class="form-module__input-wrap">
          <input class="form-module__input" type="text" placeholder="请输入">
        </div>
      </div>
      <div class="form-module__item">
        <label class="form-module__label">状态</label>
        <div class="form-module__input-wrap">
          <select class="form-module__select">
            <option>启用</option>
            <option>禁用</option>
          </select>
        </div>
      </div>
    </div>
  </div>
  
  <!-- 表单底部 -->
  <div class="form-module__footer">
    <button class="form-module__btn">取消</button>
    <button class="form-module__btn form-module__btn--primary">保存</button>
  </div>
</div>
```

### 可配置参数

```yaml
form-module:
  layout: "horizontal"      # 布局: horizontal/vertical/inline
  columns: 2                # 列数: 1/2/3
  has_header: true          # 是否显示头部
  has_footer: true          # 是否显示底部操作
  label_width: "120px"      # 标签宽度
```

### 组件令牌映射

| 元素 | BEM类名 | 推荐组件令牌 |
|-----|--------|-------------|
| 文本输入 | `.form-module__input` | `ENT::Input::text` |
| 下拉选择 | `.form-module__select` | `ENT::Select::single` |
| 保存按钮 | `.form-module__btn--primary` | `GEN::Button::primary` |
| 取消按钮 | `.form-module__btn` | `GEN::Button::default` |

---

## 详情模块（Detail Module）

### 模块命名
- **Block**: `.detail-module`
- **用途**: 信息详情展示区域

### 标准HTML结构

```html
<div class="detail-module">
  <!-- 详情头部 -->
  <div class="detail-module__header">
    <h2 class="detail-module__title">详情标题</h2>
    <div class="detail-module__actions">
      <button class="detail-module__btn">编辑</button>
    </div>
  </div>
  
  <!-- 详情主体 -->
  <div class="detail-module__body">
    <div class="detail-module__section">
      <h4 class="detail-module__section-title">基础信息</h4>
      <div class="detail-module__grid">
        <div class="detail-module__item">
          <span class="detail-module__label">名称：</span>
          <span class="detail-module__value">张三</span>
        </div>
        <div class="detail-module__item">
          <span class="detail-module__label">状态：</span>
          <span class="detail-module__value">
            <span class="detail-module__tag">启用</span>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
```

### 可配置参数

```yaml
detail-module:
  layout: "grid"            # 布局: grid/list
  columns: 2                # 网格列数
  has_sections: true        # 是否分组展示
  has_actions: true         # 是否显示操作按钮
```

---

## 页面头部模块（Page Header Module）

### 模块命名
- **Block**: `.page-header`
- **用途**: 页面标题和操作区域

### 标准HTML结构

```html
<div class="page-header">
  <!-- 面包屑 -->
  <div class="page-header__breadcrumb">
    <span class="page-header__breadcrumb-item">首页</span>
    <span class="page-header__breadcrumb-separator">/</span>
    <span class="page-header__breadcrumb-item">当前页面</span>
  </div>
  
  <!-- 标题区 -->
  <div class="page-header__main">
    <h1 class="page-header__title">页面标题</h1>
    <div class="page-header__actions">
      <button class="page-header__btn page-header__btn--primary">
        <i class="fa-solid fa-plus"></i> 新建
      </button>
    </div>
  </div>
</div>
```

### 可配置参数

```yaml
page-header:
  has_breadcrumb: true      # 是否显示面包屑
  has_actions: true         # 是否显示操作按钮
  action_count: 1           # 操作按钮数量
```

### 组件令牌映射

| 元素 | BEM类名 | 推荐组件令牌 |
|-----|--------|-------------|
| 面包屑 | `.page-header__breadcrumb` | `NAV::Breadcrumb::default` |
| 标题 | `.page-header__title` | `GEN::Typography::title::h1` |
| 主按钮 | `.page-header__btn--primary` | `GEN::Button::primary` |

---

## 卡片列表模块（Card List Module）

### 模块命名
- **Block**: `.card-list-module`
- **用途**: 卡片式数据展示

### 标准HTML结构

```html
<div class="card-list-module">
  <div class="card-list-module__grid">
    <div class="card-list-module__card">
      <div class="card-list-module__card-header">
        <h4 class="card-list-module__card-title">卡片标题</h4>
        <span class="card-list-module__card-tag">标签</span>
      </div>
      <div class="card-list-module__card-body">
        <p class="card-list-module__card-desc">卡片描述内容...</p>
      </div>
      <div class="card-list-module__card-footer">
        <a class="card-list-module__card-action">查看详情</a>
      </div>
    </div>
  </div>
</div>
```

### 可配置参数

```yaml
card-list-module:
  columns: 3                # 列数: 2/3/4
  has_tag: true             # 是否显示标签
  has_actions: true         # 是否显示操作
```

---

## 模块选择速查表

| 场景 | 推荐模块 | Block名称 |
|-----|---------|----------|
| 筛选查询区域 | 筛选模块 | `.filter-module` |
| 数据表格展示 | 表格模块 | `.table-module` |
| 数据录入编辑 | 表单模块 | `.form-module` |
| 信息详情查看 | 详情模块 | `.detail-module` |
| 页面标题区域 | 页面头部模块 | `.page-header` |
| 卡片式列表 | 卡片列表模块 | `.card-list-module` |

---

## 最佳实践

### 1. 模块粒度

- **一个模块 = 一个功能单元**
- 避免过大（包含过多功能）
- 避免过小（拆散紧密相关的功能）

### 2. 命名一致性

- 使用语义化命名，而非外观描述
- 保持命名风格统一（kebab-case）
- 避免缩写，保持可读性

### 3. 令牌映射

- 参考映射表，但不强制绑定
- 根据实际需求灵活调整
- 保持语义一致性

### 4. 响应式考虑

- 模块应支持响应式布局
- 关键模块提供断点配置
- 保持核心功能在各尺寸可用
