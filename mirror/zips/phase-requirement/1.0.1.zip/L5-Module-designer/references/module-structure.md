# 模块容器结构设计

## 1. 工程化思维概述

### 1.1 设计理念

本规范采用工程化思维,强调层级化、模块化、标准化的设计方法,确保设计系统的一致性与可维护性。

### 1.2 核心原则

- **层级化**: 清晰的容器层次结构
- **模块化**: 功能独立的模块容器
- **标准化**: 统一的命名和参数规范
- **可复用**: 模块设计考虑复用场景

---

## 2. 整体容器架构

### 2.1 四层容器结构

```
页面底层
├── 父级容器层
│   ├── 头部模块
│   ├── 筛选模块
│   ├── 列表主体模块
│   └── 分页模块
└── 子容器层 (位于各模块内部)
    ├── 列表项容器
    ├── 操作容器
    └── 内容容器
```

### 2.2 容器职责

| 层级 | 名称 | 职责 | 命名示例 |
|-----|------|------|---------|
| Level 1 | 页面底层 | 包含所有页面内容 | `.list-page` |
| Level 2 | 父级容器 | 主要区域容器 | `.list-container` |
| Level 3 | 模块容器 | 功能模块容器 | `.header-module` |
| Level 4 | 子容器 | 模块内部子容器 | `.list-item` |

---

## 3. 页面底层

### 3.1 定义

整个页面的最外层容器,包含所有内容。

### 3.2 命名规范

```
.{page-name}-page
```

**示例**:
- `.list-page` - 列表页面
- `.form-page` - 表单页面
- `.dashboard-page` - 仪表板页面

### 3.3 设计参数

- **宽度**: 自适应,最大宽度1200px
- **对齐**: 水平居中
- **背景色**: `#F5F5F5`
- **内边距**: `24px`

### 3.4 响应式规则

```css
.list-page {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
  background-color: #F5F5F5;
}

@media (max-width: 768px) {
  .list-page {
    padding: 12px;
  }
}
```

---

## 4. 父级容器层

### 4.1 定义

页面底层内包含的主要区域容器,分为几个模块容器。

### 4.2 命名规范

```
.{page-name}-container
```

**示例**:
- `.list-container` - 列表主容器
- `.form-container` - 表单主容器

### 4.3 常见父级容器

#### 4.3.1 头部模块容器 (`.header-module`)

**职责**: 页面标题和操作按钮所在的区域

**结构**:
```
.header-module
├── .header-module__title-container (标题区域)
│   ├── .header-module__title (主标题)
│   └── .header-module__subtitle (副标题/描述)
└── .header-module__action-container (操作区域)
    ├── .header-module__action-btn (操作按钮)
    └── .header-module__action-menu (操作菜单)
```

**设计参数**:
- 高度: 64px
- 背景色: `#FFFFFF`
- 内边距: 16px
- 元素间距: 16px

#### 4.3.2 筛选模块容器 (`.filter-module`)

**职责**: 提供搜索和筛选功能的区域

**结构**:
```
.filter-module
├── .filter-module__search-container (搜索区域)
│   └── .filter-module__search-input (搜索框)
├── .filter-module__select-container (下拉筛选区域)
│   └── .filter-module__select (下拉选择器)
└── .filter-module__tag-container (标签筛选区域)
    └── .filter-module__tag (标签)
```

**标准组件**:
- 搜索框 `.filter-module__search-input`
- 下拉筛选器 `.filter-module__select`
- 标签筛选 `.filter-module__tag`
- 日期范围 `.filter-module__date-range`

**响应式规则**:
- 桌面端: 水平排列,间距12px
- 移动端: 垂直堆叠,间距8px

#### 4.3.3 列表模块容器 (`.list-module`)

**职责**: 展示列表数据的区域

**结构**:
```
.list-module
└── .list-item (列表项)
    ├── .list-item__left-container (左侧操作区)
    │   ├── .list-item__checkbox (选择框)
    │   ├── .list-item__drag-handle (拖拽手柄)
    │   └── .list-item__status (状态指示器)
    ├── .list-item__main-container (主要内容区)
    │   ├── .list-item__title (标题行)
    │   ├── .list-item__desc (描述行)
    │   └── .list-item__meta (元信息行)
    └── .list-item__right-container (右侧操作区)
        ├── .list-item__primary-btn (主要操作按钮)
        └── .list-item__more-menu (更多操作菜单)
```

**设计参数**:
- 行高: 72px (紧凑型) 或 88px (标准型)
- 内边距: 16px
- 分割线: `1px solid #F0F0F0`
- 悬停状态: `background-color: #FAFAFA`

**列表项变体**:
```css
.list-item--compact    /* 紧凑模式 */
.list-item--expanded   /* 展开模式 */
.list-item--selected   /* 选中状态 */
.list-item--disabled   /* 禁用状态 */
```

#### 4.3.4 分页模块容器 (`.pagination-module`)

**职责**: 分页控件所在的区域

**结构**:
```
.pagination-module
├── .pagination-module__prev-btn (上一页)
├── .pagination-module__page-numbers (页码容器)
│   ├── .pagination-module__page-number (页码)
│   └── .pagination-module__page-number--active (当前页)
├── .pagination-module__next-btn (下一页)
├── .pagination-module__info (分页信息)
│   ├── .pagination-module__total (总条数)
│   └── .pagination-module__page-size (每页条数)
└── .pagination-module__jump-container (跳转容器)
    └── .pagination-module__jump-input (跳转输入框)
```

**设计参数**:
- 对齐方式: 居中或右对齐
- 页数显示: 最多显示7个页码
- 跳转输入框: 可选配置

---

## 5. 子容器层

### 5.1 定义

模块内的子级容器,用于组织模块内部的元素。

### 5.2 列表项容器 (`.list-item`)

**结构示例**:

```html
<div class="list-item list-item--selected">
  <div class="list-item__left-container">
    <input type="checkbox" class="list-item__checkbox">
    <span class="list-item__status status--success"></span>
  </div>
  
  <div class="list-item__main-container">
    <h3 class="list-item__title">张三</h3>
    <p class="list-item__desc">高级工程师 | 技术部</p>
    <div class="list-item__meta">
      <span class="list-item__meta-item">入职时间: 2023-01-15</span>
      <span class="list-item__meta-item">工号: EMP001</span>
    </div>
  </div>
  
  <div class="list-item__right-container">
    <button class="btn btn--icon list-item__action-btn">编辑</button>
    <button class="btn btn--icon list-item__action-btn">删除</button>
  </div>
</div>
```

### 5.3 其他常见子容器

#### 5.3.1 标题容器 (`.title-container`)
- 主标题
- 副标题
- 描述信息

#### 5.3.2 操作容器 (`.action-container`)
- 主要操作按钮
- 次要操作按钮
- 更多操作菜单

#### 5.3.3 信息容器 (`.info-container`)
- 统计信息
- 状态信息
- 元数据

---

## 6. 容器层次示例

### 6.1 列表页面完整结构

```html
<div class="list-page">
  <!-- Level 1: 页面底层 -->
  
  <header class="header-module">
    <!-- Level 2: 父级容器 - 头部模块 -->
    
    <div class="header-module__title-container">
      <!-- Level 3: 子容器 - 标题容器 -->
      <h1 class="header-module__title">用户列表</h1>
      <span class="header-module__subtitle">管理系统用户信息</span>
    </div>
    
    <div class="header-module__action-container">
      <!-- Level 3: 子容器 - 操作容器 -->
      <button class="btn btn--primary header-module__action-btn">添加用户</button>
      <button class="btn btn--secondary header-module__action-btn">批量导出</button>
    </div>
  </header>
  
  <section class="filter-module">
    <!-- Level 2: 父级容器 - 筛选模块 -->
    
    <div class="filter-module__search-container">
      <input type="text" class="filter-module__search-input" placeholder="搜索用户名、邮箱...">
    </div>
    
    <div class="filter-module__select-container">
      <select class="filter-module__select">
        <option value="">所有部门</option>
        <option value="tech">技术部</option>
        <option value="product">产品部</option>
      </select>
    </div>
    
    <div class="filter-module__tag-container">
      <span class="filter-module__tag">活跃</span>
      <span class="filter-module__tag">禁用</span>
    </div>
  </section>
  
  <main class="list-module">
    <!-- Level 2: 父级容器 - 列表模块 -->
    
    <div class="list-item list-item--selected">
      <!-- Level 3: 子容器 - 列表项 -->
      
      <div class="list-item__left-container">
        <!-- Level 4: 子容器 - 左侧操作区 -->
        <input type="checkbox" class="list-item__checkbox">
        <span class="list-item__status status--success"></span>
      </div>
      
      <div class="list-item__main-container">
        <!-- Level 4: 子容器 - 主要内容区 -->
        <h3 class="list-item__title">张三</h3>
        <p class="list-item__desc">高级工程师 | 技术部</p>
      </div>
      
      <div class="list-item__right-container">
        <!-- Level 4: 子容器 - 右侧操作区 -->
        <button class="btn btn--icon list-item__action-btn">编辑</button>
        <button class="btn btn--icon list-item__action-btn">删除</button>
      </div>
    </div>
  </main>
  
  <footer class="pagination-module">
    <!-- Level 2: 父级容器 - 分页模块 -->
    <div class="pagination-module__info">
      共50条, 每页20条
    </div>
    <div class="pagination-module__page-numbers">
      <span class="pagination-module__page-number">1</span>
      <span class="pagination-module__page-number pagination-module__page-number--active">2</span>
      <span class="pagination-module__page-number">3</span>
    </div>
  </footer>
</div>
```

---

## 7. 容器设计原则

### 7.1 层次原则

- 容器层次不超过4层
- 每层职责明确,避免交叉
- 父容器不直接操作子容器的内部元素

### 7.2 独立性原则

- 模块容器功能独立
- 减少模块间的依赖
- 模块可单独测试和维护

### 7.3 可复用性原则

- 模块设计考虑复用场景
- 避免过度定制化
- 使用修饰符处理变体

### 7.4 扩展性原则

- 预留扩展空间
- 使用灵活的布局方式
- 支持模块动态增删

---

## 8. 验收清单

### 8.1 结构检查

- [ ] 容器层次清晰,不超过4层
- [ ] 每层容器职责明确
- [ ] 模块边界划分合理

### 8.2 命名检查

- [ ] 遵循BEM命名规范
- [ ] 命名具有语义化
- [ ] 命名保持一致性

### 8.3 参数检查

- [ ] 间距符合设计Token
- [ ] 响应式规则完整
- [ ] 变体状态定义完整

### 8.4 可维护性检查

- [ ] 模块可独立维护
- [ ] 代码结构清晰
- [ ] 易于扩展和修改

---

**版本**: 1.0.0  
**最后更新**: 2025-03-23
