# BEM命名规范

## 1. BEM概述

### 1.1 定义

BEM (Block Element Modifier) 是一种CSS命名方法论,用于创建可复用的组件和代码共享。

### 1.2 核心概念

- **Block (块)**: 独立的实体,有意义且独立
- **Element (元素)**: 块的一部分,没有独立意义
- **Modifier (修饰符)**: 块或元素的标志,改变外观或行为

### 1.3 命名规则

| 类型 | 命名 | 示例 |
|-----|------|------|
| Block | `.block-name` | `.list-page`, `.header-module` |
| Element | `.block-name__element-name` | `.list-page__title`, `.header-module__action-btn` |
| Modifier | `.block-name--modifier-name` | `.list-item--selected`, `.btn--primary` |

---

## 2. Block (块)

### 2.1 定义

块是页面上独立的、可复用的组件,可以嵌套在其他块中。

### 2.2 命名规则

```
.{block-name}
```

**规则**:
- 使用小写字母
- 多个单词使用连字符 `-` 连接
- 具有语义化命名

### 2.3 常见块示例

#### 2.3.1 页面级块

```css
.list-page        /* 列表页面 */
.form-page        /* 表单页面 */
.dashboard-page   /* 仪表板页面 */
.detail-page      /* 详情页面 */
```

#### 2.3.2 模块级块

```css
.header-module    /* 头部模块 */
.filter-module    /* 筛选模块 */
.list-module      /* 列表模块 */
.pagination-module /* 分页模块 */
```

#### 2.3.3 组件级块

```css
.btn              /* 按钮 */
.card             /* 卡片 */
.modal            /* 弹窗 */
.drawer           /* 抽屉 */
.input            /* 输入框 */
```

### 2.4 块的使用

```html
<!-- 块可以独立存在 -->
<div class="header-module">
  <h1 class="header-module__title">标题</h1>
</div>

<!-- 块可以嵌套 -->
<div class="list-page">
  <div class="header-module">
    <h1 class="header-module__title">标题</h1>
  </div>
  <div class="list-module">
    <!-- 列表内容 -->
  </div>
</div>
```

---

## 3. Element (元素)

### 3.1 定义

元素是块的组成部分,没有独立的意义,只能存在于块的上下文中。

### 3.2 命名规则

```
.{block-name}__{element-name}
```

**规则**:
- 使用双下划线 `__` 连接块名和元素名
- 元素名使用小写字母
- 多个单词使用连字符 `-` 连接

### 3.3 元素示例

#### 3.3.1 头部模块元素

```css
.header-module                      /* 块 */
.header-module__title-container      /* 元素: 标题容器 */
.header-module__title               /* 元素: 标题 */
.header-module__subtitle            /* 元素: 副标题 */
.header-module__action-container    /* 元素: 操作容器 */
.header-module__action-btn          /* 元素: 操作按钮 */
```

#### 3.3.2 列表项元素

```css
.list-item                    /* 块 */
.list-item__left-container     /* 元素: 左侧容器 */
.list-item__checkbox           /* 元素: 选择框 */
.list-item__status             /* 元素: 状态 */
.list-item__main-container     /* 元素: 主内容容器 */
.list-item__title              /* 元素: 标题 */
.list-item__desc               /* 元素: 描述 */
.list-item__right-container    /* 元素: 右侧容器 */
.list-item__action-btn         /* 元素: 操作按钮 */
```

#### 3.3.3 按钮元素

```css
.btn                    /* 块 */
.btn__icon              /* 元素: 图标 */
.btn__text              /* 元素: 文本 */
.btn__badge             /* 元素: 徽章 */
```

### 3.4 元素的使用

```html
<div class="list-item">
  <!-- 元素必须存在于块的上下文中 -->
  <div class="list-item__left-container">
    <input type="checkbox" class="list-item__checkbox">
  </div>
  
  <div class="list-item__main-container">
    <h3 class="list-item__title">标题</h3>
    <p class="list-item__desc">描述</p>
  </div>
</div>
```

### 3.5 元素嵌套原则

**禁止**: 元素嵌套元素

```html
<!-- ❌ 错误: 元素嵌套元素 -->
<div class="list-item">
  <div class="list-item__main-container">
    <div class="list-item__main-container__title">标题</div>
  </div>
</div>
```

**正确**: 块嵌套元素

```html
<!-- ✅ 正确: 块嵌套元素 -->
<div class="list-item">
  <div class="list-item__main-container">
    <h3 class="list-item__title">标题</h3>
  </div>
</div>
```

---

## 4. Modifier (修饰符)

### 4.1 定义

修饰符是块或元素的标志,用于改变其外观或行为,如状态、大小、颜色等。

### 4.2 命名规则

```
.{block-name}--{modifier-name}
.{block-name}__{element-name}--{modifier-name}
```

**规则**:
- 使用双连字符 `--` 连接块/元素名和修饰符名
- 修饰符名使用小写字母
- 多个单词使用连字符 `-` 连接

### 4.3 修饰符类型

#### 4.3.1 状态修饰符

```css
.list-item--selected   /* 选中状态 */
.list-item--disabled   /* 禁用状态 */
.list-item--loading    /* 加载状态 */
.list-item--error      /* 错误状态 */
```

#### 4.3.2 尺寸修饰符

```css
.btn--small            /* 小尺寸 */
.btn--medium           /* 中尺寸 */
.btn--large            /* 大尺寸 */
.input--compact        /* 紧凑型 */
```

#### 4.3.3 颜色修饰符

```css
.btn--primary          /* 主要按钮 */
.btn--secondary        /* 次要按钮 */
.btn--success          /* 成功按钮 */
.btn--danger           /* 危险按钮 */
.btn--warning          /* 警告按钮 */
```

#### 4.3.4 布局修饰符

```css
.list-item--compact    /* 紧凑模式 */
.list-item--expanded   /* 展开模式 */
.card--horizontal      /* 水平布局 */
.card--vertical        /* 垂直布局 */
```

### 4.5 修饰符的使用

```html
<!-- 块修饰符 -->
<div class="list-item list-item--selected">
  <div class="list-item__title">标题</div>
</div>

<!-- 元素修饰符 -->
<div class="list-item">
  <button class="btn btn--primary">主要按钮</button>
</div>

<!-- 多个修饰符 -->
<div class="list-item list-item--selected list-item--disabled">
  <div class="list-item__title">标题</div>
</div>
```

### 4.6 修饰符的CSS实现

```css
/* 基础样式 */
.list-item {
  padding: 16px;
  background-color: #FFFFFF;
  border: 1px solid #F0F0F0;
}

/* 修饰符样式 */
.list-item--selected {
  background-color: #E6F7FF;
  border-color: #1890FF;
}

.list-item--disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* 元素修饰符 */
.list-item__title {
  font-size: 16px;
  font-weight: 500;
}

.list-item__title--large {
  font-size: 18px;
  font-weight: 600;
}
```

---

## 5. BEM最佳实践

### 5.1 命名原则

#### 5.1.1 语义化

```css
/* ✅ 语义化 */
.header-module
.list-item
.btn-primary

/* ❌ 非语义化 */
.box1
.div-red
.style-blue
```

#### 5.1.2 简洁性

```css
/* ✅ 简洁 */
.header-module__title
.list-item__title

/* ❌ 冗长 */
.header-module-title-text-container
.list-item-main-content-area-title-text
```

#### 5.1.3 一致性

```css
/* ✅ 一致 */
.header-module__title
.header-module__subtitle
.header-module__description

/* ❌ 不一致 */
.header-module__title
.header-module_subtitle
.header-module-desc
```

### 5.2 结构原则

#### 5.2.1 避免过深嵌套

```html
<!-- ✅ 推荐: 扁平结构 -->
<div class="list-item">
  <div class="list-item__title">标题</div>
  <div class="list-item__desc">描述</div>
</div>

<!-- ❌ 避免: 过深嵌套 -->
<div class="list-item">
  <div class="list-item__container">
    <div class="list-item__wrapper">
      <div class="list-item__content">
        <div class="list-item__title">标题</div>
      </div>
    </div>
  </div>
</div>
```

#### 5.2.2 避免元素嵌套元素

```html
<!-- ✅ 正确: 块嵌套元素 -->
<div class="list-item">
  <h3 class="list-item__title">标题</h3>
  <p class="list-item__desc">描述</p>
</div>

<!-- ❌ 错误: 元素嵌套元素 -->
<div class="list-item">
  <div class="list-item__container">
    <div class="list-item__container__title">标题</div>
  </div>
</div>
```

### 5.3 修饰符使用原则

#### 5.3.1 修饰符不覆盖基础样式

```css
/* ✅ 正确: 修饰符只覆盖变化的属性 */
.list-item {
  padding: 16px;
  background-color: #FFFFFF;
}

.list-item--selected {
  background-color: #E6F7FF;
}

/* ❌ 错误: 修饰符重复基础样式 */
.list-item--selected {
  padding: 16px;
  background-color: #E6F7FF;
}
```

#### 5.3.2 使用布尔修饰符

```css
/* ✅ 推荐: 布尔修饰符 */
.list-item--selected
.list-item--disabled
.list-item--loading

/* ⚠️ 谨慎使用: 键值修饰符 */
.list-item--size-small
.list-item--color-blue
```

---

## 6. 常见BEM模式

### 6.1 页面级BEM

```html
<div class="list-page">
  <header class="header-module">
    <div class="header-module__title-container">
      <h1 class="header-module__title">用户列表</h1>
    </div>
  </header>
  
  <main class="list-module">
    <div class="list-item list-item--selected">
      <h3 class="list-item__title">张三</h3>
    </div>
  </main>
</div>
```

### 6.2 组件级BEM

```html
<div class="card card--shadow">
  <div class="card__header">
    <h3 class="card__title">卡片标题</h3>
  </div>
  <div class="card__body">
    <p class="card__text">卡片内容</p>
  </div>
  <div class="card__footer">
    <button class="btn btn--primary">确定</button>
    <button class="btn btn--secondary">取消</button>
  </div>
</div>
```

### 6.3 表单元素BEM

```html
<div class="form-group">
  <label class="form-group__label">用户名</label>
  <input type="text" class="input input--medium" placeholder="请输入用户名">
  <span class="form-group__error">用户名不能为空</span>
</div>
```

---

## 7. BEM与其他命名方法对比

### 7.1 BEM vs 传统命名

| 特性 | BEM | 传统命名 |
|-----|-----|---------|
| 可读性 | 高 | 低 |
| 可维护性 | 高 | 低 |
| 复用性 | 高 | 低 |
| 命名冲突 | 少 | 多 |

### 7.2 命名示例对比

```css
/* 传统命名 */
.header .title
.header .button
.header .button.primary

/* BEM命名 */
.header-module__title
.header-module__action-btn
.btn--primary
```

---

## 8. BEM验收清单

### 8.1 命名检查

- [ ] 使用小写字母
- [ ] 使用连字符连接多个单词
- [ ] 元素使用双下划线
- [ ] 修饰符使用双连字符
- [ ] 命名具有语义化

### 8.2 结构检查

- [ ] 块独立存在
- [ ] 元素存在于块的上下文中
- [ ] 避免元素嵌套元素
- [ ] 避免过深嵌套(不超过4层)

### 8.3 修饰符检查

- [ ] 修饰符只覆盖变化的属性
- [ ] 优先使用布尔修饰符
- [ ] 修饰符命名清晰明确

### 8.4 一致性检查

- [ ] 命名风格一致
- [ ] 元素命名模式一致
- [ ] 修饰符命名模式一致

---

## 9. BEM工具和资源

### 9.1 工具

- [BEM Linter](https://github.com/ilyabirman/bem-lint) - BEM命名检查工具
- [BEM Designer](https://github.com/igoradamenko/bem-designer) - BEM设计工具

### 9.2 参考资源

- [BEM官方文档](https://bem.info/methodology/)
- [Ant Design BEM规范](https://github.com/ant-design/ant-design/wiki/BEM-CSS-Naming-Convention)

---

**版本**: 1.0.0  
**最后更新**: 2025-03-23
