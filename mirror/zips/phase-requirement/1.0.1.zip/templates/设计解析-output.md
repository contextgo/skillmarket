# 设计解析文档

> 由 phase-design Skill 自动生成，输入为需求解析.md

## 1. 项目概述

| 属性 | 内容 |
|------|------|
| 项目名称 | {名称} |
| 需求摘要 | {一句话概括} |
| 设计系统 | {FTDesign / AntDesign / 招商红} |
| 布局方案 | {LayoutPage-1/2/3/4} |
| 页面总数 | {N个} |
| 复杂度 | {轻量/中型/重型} |

---

## 2. 布局方案 (L3)

### 主布局

| 属性 | 选择 | 原因 |
|------|------|------|
| 布局类型 | {LayoutPage-X} | {选择理由} |
| 侧边栏 | {固定/可收缩/无} | {依据} |
| 顶栏 | {有/无} | {依据} |
| 导航项数 | {N个} | {≤9，7±2法则} |

### 栅格系统

- 栅格列数：24栏
- 页面内边距：24px
- 模块间距：16px / 24px
- 响应式断点：{断点列表}

---

## 3. 页面清单 (L5)

### 3.1 {页面名称1}

| 属性 | 内容 |
|------|------|
| 页面类型 | {list_table / dashboard / form / detail / ...} |
| 所属模块 | {模块名} |
| 布局规格 | {参考 L3 布局文档} |
| 核心组件 | {组件列表} |

**模块组成**：
```
├── {区域1，如：筛选区} → {组件，如：Input + Select + Button}
├── {区域2，如：数据区} → {组件，如：Table + Pagination}
└── {区域3，如：操作区} → {组件，如：Button + Modal}
```

### 3.2 {页面名称2}
...

---

## 4. 模块规范 (L4)

### BEM 命名规范

- Block：`.search-bar` / `.data-table` / `.form-section`
- Element：`.search-bar__input` / `.search-bar__button`
- Modifier：`.data-table--striped` / `.button--primary`

### 四层容器结构

```
Page → Section → Module → Component
```
- 容器嵌套不超过4层

---

## 5. UI 系统选型 (L6)

### 设计系统：{FTDesign / AntDesign / 招商红}

| Token 类别 | 值 |
|-----------|-----|
| 品牌色 | {#005DEB / #1890ff / #C8102E} |
| 功能色-成功 | {色值} |
| 功能色-警告 | {色值} |
| 功能色-错误 | {色值} |
| 功能色-信息 | {色值} |
| 主字体 | {font-family} |
| 基础字号 | {14px} |
| 基础间距 | {8px} |
| 圆角 | {small: 4px / medium: 8px / large: 12px} |

### CSS 变量前缀

- FTDesign：`--ft-` 前缀，`ft-` 类名前缀
- AntDesign：`--ant-` 前缀，`ant-` 类名前缀
- 招商红：`--zsh-` 前缀，`zsh-` 类名前缀

---

## 6. 禁止规则

- [x] 禁止图标使用功能色（用 `--ft-text-secondary`）
- [x] 禁止直接写死色值（用CSS变量）
- [x] 禁止导航项超过9个
- [x] 禁止功能色作为按钮选中状态（统一用品牌色）
- [x] 禁止元素嵌套元素（BEM规范）
- [x] 禁止容器层次超过4层

---

## 7. SPEC JSON（供下游 HTML 生成使用）

### 全局 SPEC
```json
{"global": {"theme": {"primaryColor": "#005DEB", "fontFamily": "system-ui"}, "spacing": {"baseUnit": 8, "pagePadding": 24}}}
```

### 页面 SPEC 列表
```json
[
  {
    "page": "{页面名}",
    "type": "{list_table}",
    "layout": "{LayoutPage-2}",
    "regions": [
      {"region": "SearchBar", "layout": "flex", "gap": 8, "components": ["Input::search", "Select", "Button::primary"]},
      {"region": "DataTable", "components": ["Table::default", "Pagination"]},
      {"region": "Actions", "components": ["Button::primary", "Modal"]}
    ]
  }
]
```
