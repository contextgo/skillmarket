# [页面名称] 设计方案

> 生成时间：[YYYY-MM-DD HH:mm:ss]  
> 设计阶段：phase-design  
> 版本：v1.0

---

## 页面信息

| 项目 | 内容 |
|-----|------|
| **页面名称** | [页面名称] |
| **页面类型** | [类型编号.类型名称] |
| **布局模式** | [LayoutPage-X] |
| **优先级** | [P0/P1/P2] |
| **设计系统** | [FTDesign/AntDesign/招商红] |

---

## 页面描述

### 功能描述
[详细描述该页面的主要功能和业务价值]

### 使用场景
- [场景1：谁会在什么情况下使用这个页面]
- [场景2：主要的业务流程节点]

### 设计要点
- [设计要点1：信息层级、视觉重点]
- [设计要点2：交互逻辑、用户体验考虑]

---

## 整体页面布局结构

```
┌─────────────────────────────────────────────────────────┐
│  LayoutPage-[X]                                          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │            Header Section（头部区域）             │   │
│  │  [页面标题 + 面包屑 + 全局操作]                    │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │           Filter Section（筛选区域）             │   │
│  │  [搜索框 + 筛选条件 + 批量操作]                    │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │          Content Section（内容区域）             │   │
│  │  [数据表格/卡片列表/详情信息/表单]                 │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │          Action Section（操作区域）              │   │
│  │  [分页器/底部按钮/悬浮操作]                        │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 区域划分说明

| 区域 | 区域ID | 用途 | 尺寸 |
|-----|-------|------|------|
| 头部区域 | header-section | 页面标题、面包屑、全局操作 | 高度自适应 |
| 筛选区域 | filter-section | 搜索、筛选条件、批量操作 | 高度自适应 |
| 内容区域 | content-section | 核心内容展示 | 自适应填充 |
| 操作区域 | action-section | 分页、提交按钮 | 高度自适应 |

---

## 区域详细设计

### 区域 1: 头部区域（Header Section）

#### 设计意图
- **功能定位**：[该区域在页面中的作用]
- **交互逻辑**：[用户的操作流程]
- **视觉风格**：[布局、色彩、层次要求]

#### 模块容器（BEM）
```
Section（区域层）
└── Block（模块层）
    └── Element（元素层）
```

- **Section级容器**：`.header-section`
- **Block级模块**：`.page-header`
- **Element级元素**：
  - `.page-header__breadcrumb` - 面包屑容器
  - `.page-header__title` - 页面标题
  - `.page-header__actions` - 操作按钮容器

#### 组件令牌清单

| 序号 | 组件令牌 | 用途 | BEM容器 | 配置参数 |
|-----|---------|------|--------|---------|
| 1 | `NAV::Breadcrumb::default` | 面包屑导航 | `.page-header__breadcrumb` | - |
| 2 | `GEN::Typography::title::h1` | 页面标题 | `.page-header__title` | - |
| 3 | `GEN::Button::primary` | 新建按钮 | `.page-header__btn--primary` | icon: plus |
| 4 | `GEN::Icon::plus` | 添加图标 | `.page-header__btn--primary i` | - |

#### 字段说明
| 字段名 | 显示名 | 数据类型 | 组件令牌 | 必填 | 业务说明 |
|-------|-------|---------|---------|------|---------|
| [字段名] | [显示名] | [string/number/date] | [token] | [是/否] | [说明] |

---

### 区域 2: 筛选区域（Filter Section）

#### 设计意图
- **功能定位**：[数据筛选和查询功能]
- **交互逻辑**：[输入→查询→刷新列表]
- **视觉风格**：[紧凑布局、统一间距]

#### 模块容器（BEM）
- **Section级容器**：`.filter-section`
- **Block级模块**：`.filter-module`
- **Element级元素**：
  - `.filter-module__search-container` - 搜索容器
  - `.filter-module__filter-container` - 筛选容器
  - `.filter-module__action-container` - 操作容器

#### 组件令牌清单

| 序号 | 组件令牌 | 用途 | BEM容器 | 配置参数 |
|-----|---------|------|--------|---------|
| 1 | `ENT::Input::search` | 搜索框 | `.filter-module__search-input` | placeholder: "搜索..." |
| 2 | `ENT::Select::single` | 状态下拉 | `.filter-module__filter-select` | options: [...] |
| 3 | `GEN::Button::primary` | 查询按钮 | `.filter-module__btn--primary` | - |
| 4 | `GEN::Button::default` | 重置按钮 | `.filter-module__btn` | - |

#### 字段说明
| 字段名 | 显示名 | 数据类型 | 组件令牌 | 必填 | 业务说明 |
|-------|-------|---------|---------|------|---------|
| keyword | 关键词 | string | ENT::Input::search | 否 | 支持模糊搜索 |
| status | 状态 | enum | ENT::Select::single | 否 | 启用/禁用 |

---

### 区域 3: 内容区域（Content Section）

#### 设计意图
- **功能定位**：[核心数据展示区域]
- **交互逻辑**：[查看、选择、操作数据]
- **视觉风格**：[清晰表格、合理留白]

#### 模块容器（BEM）
- **Section级容器**：`.content-section`
- **Block级模块**：`.table-module`
- **Element级元素**：
  - `.table-module__header` - 表格头部
  - `.table-module__body` - 表格主体
  - `.table-module__footer` - 表格底部

#### 组件令牌清单

| 序号 | 组件令牌 | 用途 | BEM容器 | 配置参数 |
|-----|---------|------|--------|---------|
| 1 | `DISP::Table::selection` | 数据表格 | `.table-module__table` | rowSelection: true |
| 2 | `GEN::Tag::success` | 状态标签（启用） | `.table-module__tag--success` | - |
| 3 | `GEN::Tag::default` | 状态标签（禁用） | `.table-module__tag--default` | - |
| 4 | `GEN::Button::link` | 编辑链接 | `.table-module__action--edit` | - |
| 5 | `GEN::Button::link-danger` | 删除链接 | `.table-module__action--delete` | - |

#### 字段说明

| 字段名 | 显示名 | 数据类型 | 组件令牌 | 必填 | 业务说明 |
|-------|-------|---------|---------|------|---------|
| id | ID | number | - | - | 主键，表格隐藏 |
| name | 名称 | string | DISP::Table::Column::text | 是 | 核心字段 |
| status | 状态 | enum | DISP::Table::Column::tag | 是 | 启用/禁用 |
| created_at | 创建时间 | datetime | DISP::Table::Column::datetime | 否 | 格式化显示 |
| actions | 操作 | actions | DISP::Table::Column::actions | 否 | 编辑/删除 |

#### 表格列配置

| 列名 | 数据字段 | 宽度 | 对齐 | 排序 | 说明 |
|-----|---------|------|-----|------|------|
| 选择框 | - | 50px | center | 否 | 批量选择 |
| 名称 | name | auto | left | 是 | 主键字段 |
| 状态 | status | 100px | center | 是 | 标签展示 |
| 创建时间 | created_at | 180px | center | 是 | 时间格式 |
| 操作 | actions | 150px | center | 否 | 操作按钮 |

---

### 区域 4: 操作区域（Action Section）

#### 设计意图
- **功能定位**：[分页和批量操作]
- **交互逻辑**：[分页切换、批量操作确认]
- **视觉风格**：[底部固定或跟随内容]

#### 模块容器（BEM）
- **Section级容器**：`.action-section`
- **Block级模块**：`.pagination-module`
- **Element级元素**：
  - `.pagination-module__info` - 分页信息
  - `.pagination-module__controls` - 分页控制

#### 组件令牌清单

| 序号 | 组件令牌 | 用途 | BEM容器 | 配置参数 |
|-----|---------|------|--------|---------|
| 1 | `DISP::Pagination::default` | 分页器 | `.pagination-module` | pageSize: 20 |
| 2 | `GEN::Typography::text::secondary` | 分页信息 | `.pagination-module__info` | - |

#### 交互说明
- **分页切换**：切换页码时刷新列表数据
- **页码大小**：支持 20/50/100 条/页切换
- **批量操作**：先选择行，再执行批量操作

---

## 组件令牌汇总

### 按区域汇总

#### 头部区域
| 区域 | 组件令牌 | 用途 | BEM容器 |
|-----|---------|------|--------|
| 头部区域 | `NAV::Breadcrumb::default` | 面包屑导航 | `.page-header__breadcrumb` |
| 头部区域 | `GEN::Typography::title::h1` | 页面标题 | `.page-header__title` |
| 头部区域 | `GEN::Button::primary` | 新建按钮 | `.page-header__btn--primary` |

#### 筛选区域
| 区域 | 组件令牌 | 用途 | BEM容器 |
|-----|---------|------|--------|
| 筛选区域 | `ENT::Input::search` | 搜索框 | `.filter-module__search-input` |
| 筛选区域 | `ENT::Select::single` | 状态下拉 | `.filter-module__filter-select` |
| 筛选区域 | `GEN::Button::primary` | 查询按钮 | `.filter-module__btn--primary` |
| 筛选区域 | `GEN::Button::default` | 重置按钮 | `.filter-module__btn` |

#### 内容区域
| 区域 | 组件令牌 | 用途 | BEM容器 |
|-----|---------|------|--------|
| 内容区域 | `DISP::Table::selection` | 数据表格 | `.table-module__table` |
| 内容区域 | `GEN::Tag::success` | 启用状态标签 | `.table-module__tag--success` |
| 内容区域 | `GEN::Tag::default` | 禁用状态标签 | `.table-module__tag--default` |
| 内容区域 | `GEN::Button::link` | 编辑操作 | `.table-module__action--edit` |
| 内容区域 | `GEN::Button::link-danger` | 删除操作 | `.table-module__action--delete` |

#### 操作区域
| 区域 | 组件令牌 | 用途 | BEM容器 |
|-----|---------|------|--------|
| 操作区域 | `DISP::Pagination::default` | 分页器 | `.pagination-module` |

### 按类别汇总

| 类别 | 组件令牌数量 | 令牌列表 |
|-----|-------------|---------|
| GEN（通用） | X个 | [列出所有GEN令牌] |
| ENT（录入） | X个 | [列出所有ENT令牌] |
| DISP（展示） | X个 | [列出所有DISP令牌] |
| NAV（导航） | X个 | [列出所有NAV令牌] |

---

## 页面关系

### 页面导航关系

```
上级页面
└──> [当前页面]（本设计）
     ├──> [子页面1]
     ├──> [子页面2]
     └──> [子页面3]
```

### 页面流转说明

| 流向 | 目标页面 | 触发方式 | 携带参数 |
|-----|---------|---------|---------|
| 进入 | [来源页面] | 菜单点击/跳转 | - |
| 退出 | [详情页面] | 点击行/查看按钮 | id |
| 退出 | [编辑页面] | 点击编辑按钮 | id, mode=edit |
| 退出 | [新建页面] | 点击新建按钮 | mode=create |

---

## 设计规范

### 布局规范
- 侧边栏宽度：240px（固定）
- 内容区边距：24px
- 区域间距：16px
- 栅格列数：24列

### 间距规范
- 模块内间距：16px
- 元素间距：8px/12px
- 表单行间距：24px

### 色彩规范
- 主色：[设计系统主色]
- 背景色：#FFFFFF
- 边框色：#E6E8EC
- 文字色：#39485E（主）/#8A94A6（次）

### 响应式规范
- xl (≥1920px)：完整展示
- lg (≥1440px)：标准桌面
- md (≥1024px)：侧边栏可收起
- sm (<1024px)：简化布局

---

## 附录

### 参考文档
- [L4-Layouts-designer/references/00-page-layouts.md] - 7种标准布局
- [L4-Layouts-designer/references/component_tokens.md] - 组件令牌系统
- [L5-Module-designer/references/module-templates.md] - 模块HTML模板

### 变更记录
| 版本 | 日期 | 变更内容 | 作者 |
|-----|------|---------|------|
| v1.0 | [日期] | 初始设计 | [作者] |
