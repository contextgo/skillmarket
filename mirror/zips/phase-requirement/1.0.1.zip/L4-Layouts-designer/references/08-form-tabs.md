# 审批详情弹窗

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 审批详情弹窗 (Approval Detail Modal) |
| **应用场景** | 审批流程 - 查看申请详情并进行审批操作 |
| **核心功能** | 展示申请内容详情、审批进度跟踪、快速审批 |
| **设计目标** | 左右分栏布局，左侧内容详情高度可调整，右侧审批流程固定，实现高效审批决策 |

---

## 🏗️ 模块层

### 1. 弹窗头部
- 申请标题：【2023-04权数据#1】短信模板
- 状态标签：审批中（橙色）、已通过（绿色）、已驳回（红色）
- 关闭按钮（右上角）

### 2. 内容区域（左侧主区域）
- **申请详情**
  - 提交者信息：头像、姓名、提交时间
  - 申请描述：文本展示区域（灰色背景，可高度调整）
  - 提示文字："申请的内容呈现区域 高度可调整"

### 3. 审批操作区（左侧底部）
- **审批结果**：单选框（通过/驳回）
- **审批意见**：文本域输入框（带字数限制 0/500）
- **操作按钮**：取消、确定

### 4. 流程跟踪区（右侧固定）
- **流程平台**标题
- 时间线展示审批流程：
  - 当前节点：蓝色图标 + 节点名称 + 操作提示
  - 已完成节点：绿色图标 + 节点名称 + 操作人 + 操作时间
  - 已驳回节点：红色图标 + 驳回原因 + 操作人 + 操作时间（突出显示）
  - 待处理节点：灰色图标 + 节点名称 + 处理人

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Modal,            // 对话框
  Form,             // 表单
  Radio,            // 单选框
  Input,            // 输入框
  Button,           // 按钮
  Timeline,         // 时间线
  Avatar,           // 头像
  Tag,              // 标签
  Space,            // 间距
  message,          // 消息提示
} from 'antd';
```

### 使用示例

#### 完整审批弹窗结构

```jsx
const [form] = Form.useForm();
const [open, setOpen] = useState(false);
const [loading, setLoading] = useState(false);

const handleApproval = async () => {
  try {
    const values = await form.validateFields();
    setLoading(true);
    await submitApproval(values);
    message.success('审批成功');
    setOpen(false);
    form.resetFields();
  } catch (error) {
    console.error('提交失败:', error);
  } finally {
    setLoading(false);
  }
};

<Modal
  title={
    <Space>
      【2023-04权数据#1】短信模板
      <Tag color="orange">审批中</Tag>
    </Space>
  }
  open={open}
  onCancel={() => setOpen(false)}
  footer={null}
  width={1000}
  destroyOnClose
>
  <div style={{ display: 'flex', gap: 24 }}>
    {/* 左侧：申请详情 + 审批操作 */}
    <div style={{ flex: 1 }}>
      {/* 申请详情区域 */}
      <div style={{ marginBottom: 24 }}>
        <h3 style={{ marginBottom: 16 }}>审批详情</h3>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
          <Avatar size={32} src={applicantAvatar} />
          <div style={{ marginLeft: 12 }}>
            <div style={{ fontWeight: 500 }}>{applicantName}</div>
            <div style={{ fontSize: 12, color: '#8892A2' }}>
              申请时间：{applicationTime}
            </div>
          </div>
        </div>

        {/* 申请内容展示区（可调整高度） */}
        <div
          style={{
            background: '#F3F4F5',
            padding: 16,
            borderRadius: 2,
            minHeight: 200,
            color: '#6C788B',
            textAlign: 'center',
            lineHeight: '200px',
          }}
        >
          申请的内容呈现区域<br />高度可调整
        </div>
      </div>

      {/* 审批操作区 */}
      <div style={{ borderTop: '1px solid #DADDE2', paddingTop: 24 }}>
        <h3 style={{ marginBottom: 16 }}>审批处理</h3>
        <Form
          form={form}
          layout="vertical"
          initialValues={{ result: 'pass' }}
        >
          <Form.Item
            label="处理意见"
            name="result"
            rules={[{ required: true, message: '请选择处理结果' }]}
          >
            <Radio.Group>
              <Radio value="pass">通过</Radio>
              <Radio value="reject">驳回</Radio>
            </Radio.Group>
          </Form.Item>

          <Form.Item
            label="审批意见"
            name="comment"
            rules={[{ required: true, message: '请输入审批意见' }]}
          >
            <Input.TextArea
              rows={4}
              placeholder="请填写审批意见"
              maxLength={500}
              showCount
            />
          </Form.Item>

          <Form.Item style={{ marginBottom: 0 }}>
            <Space>
              <Button onClick={() => setOpen(false)}>取消</Button>
              <Button type="primary" loading={loading} onClick={handleApproval}>
                确定
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </div>
    </div>

    {/* 右侧：流程跟踪 */}
    <div
      style={{
        width: 280,
        borderLeft: '1px solid #DADDE2',
        paddingLeft: 24,
      }}
    >
      <h3 style={{ marginBottom: 16 }}>流程平台</h3>
      <Timeline
        items={[
          {
            color: 'blue',
            children: (
              <div>
                <div style={{ fontWeight: 500, color: '#005DEB' }}>
                  主管v012345
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  待你的仓储批复该审批
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  09-03 10:18:50
                </div>
              </div>
            ),
          },
          {
            color: 'red',
            children: (
              <div>
                <div style={{ fontWeight: 500, color: '#D63C3B' }}>
                  审核v012011
                  <Tag color="error" style={{ marginLeft: 8 }}>已驳回</Tag>
                </div>
                <div style={{ fontSize: 12, color: '#D63C3B' }}>
                  审批事由缺少影印人员打印
                </div>
                <div style={{ fontSize: 12, color: '#D63C3B' }}>
                  审批原因：申请文档不全备
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  09-03 10:18:50
                </div>
              </div>
            ),
          },
          {
            color: 'blue',
            children: (
              <div>
                <div style={{ fontWeight: 500, color: '#005DEB' }}>
                  主管v012345
                  <a href="#" style={{ marginLeft: 8, fontSize: 12 }}>撤回流程</a>
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  提交分行办公室
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  09-03 10:18:50
                </div>
              </div>
            ),
          },
          {
            color: 'gray',
            children: (
              <div>
                <div style={{ fontWeight: 500, color: '#C7CDD5' }}>
                  张兰三v123456
                </div>
                <div style={{ fontSize: 12, color: '#8892A2' }}>
                  待行办发批复私人副行分公章
                </div>
              </div>
            ),
          },
          {
            color: 'gray',
            children: (
              <div style={{ fontWeight: 500, color: '#C7CDD5' }}>
                张兰
              </div>
            ),
          },
        ]}
      />
    </div>
  </div>
</Modal>
```

---

## 📐 布局层

### 弹窗布局结构（左右分栏）

```
┌────────────────────────────────────────────────────────────┐
│  【2023-04权数据#1】短信模板  [审批中]            [×]      │
├────────────────────────────────────┬───────────────────────┤
│                                    │                       │
│  ┌──────────────────────────────┐ │  流程平台             │
│  │ 审批详情                     │ │                       │
│  │                              │ │  ● 主管v012345       │
│  │ [头像] 申请人                │ │    待你的仓储批复...  │
│  │        申请时间              │ │    09-03 10:18:50     │
│  │                              │ │                       │
│  │ ┌──────────────────────────┐│ │  ● 审核v012011       │
│  │ │ 申请的内容呈现区域       ││ │    已驳回             │
│  │ │ 高度可调整               ││ │    审批原因...        │
│  │ │                          ││ │                       │
│  │ └──────────────────────────┘│ │  ● 主管v012345       │
│  └──────────────────────────────┘ │    提交分行办公室     │
│                                    │    撤回流程           │
│  ───────────────────────────────   │                       │
│                                    │  ○ 张兰三v123456     │
│  ┌──────────────────────────────┐ │    待行办发批复...    │
│  │ 审批处理                     │ │                       │
│  │                              │ │  ○ 张兰              │
│  │ 处理意见  ○ 通过  ○ 驳回    │ │                       │
│  │                              │ │                       │
│  │ 审批意见                     │ │                       │
│  │ ┌──────────────────────────┐│ │                       │
│  │ │ [文本域输入框]           ││ │                       │
│  │ │                 0 / 500  ││ │                       │
│  │ └──────────────────────────┘│ │                       │
│  │                              │ │                       │
│  │  [取消]  [确定]              │ │                       │
│  └──────────────────────────────┘ │                       │
└────────────────────────────────────┴───────────────────────┘
```

### 尺寸规范

| 元素 | 尺寸 | 说明 |
|-----|------|------|
| **弹窗宽度** | 1000px | 左右分栏需要更宽空间 |
| **左侧主区域** | flex: 1 | 自适应宽度 |
| **右侧流程区** | 280px | 固定宽度 |
| **申请内容区** | min-height: 200px | 可调整高度 |
| **文本域行数** | 4行 | 审批意见输入 |

---

## 🎨 设计规范

### 颜色规范

| 状态 | 颜色变量 | 十六进制 | 用途 |
|-----|---------|---------|------|
| **审批中** | `--ft-warning-color` | #E78E2A | 标签、时间线节点 |
| **已通过** | `--ft-success-color` | #00885A | 标签、时间线节点 |
| **已驳回** | `--ft-error-color` | #D63C3B | 标签、时间线节点、错误提示 |
| **待处理** | `--ft-grey-5` | #C7CDD5 | 时间线灰色节点 |
| **当前节点** | `--ft-brand-color` | #005DEB | 时间线蓝色节点 |

### 时间线节点样式

- **当前节点**：蓝色实心圆 + 蓝色文字 + 操作提示
- **已完成节点**：绿色实心圆 + 黑色文字 + 操作信息
- **已驳回节点**：红色实心圆 + 红色文字 + 驳回原因（红色背景高亮）
- **待处理节点**：灰色空心圆 + 灰色文字

### 字体规范

| 元素 | 字号 | 字重 | 颜色 |
|-----|-----|------|------|
| **弹窗标题** | 16px | 600 | #39485E |
| **模块标题** | 14px | 600 | #39485E |
| **节点名称** | 14px | 500 | 根据状态变化 |
| **操作信息** | 12px | 400 | #8892A2 |
| **时间信息** | 12px | 400 | #8892A2 |

---

## 🎯 交互状态

### 1. 审批结果切换
- 选择"通过"：提交按钮正常可点击
- 选择"驳回"：必须填写驳回原因，否则提交按钮不可用

### 2. 提交状态
```jsx
const handleApproval = async () => {
  try {
    const values = await form.validateFields();
    setLoading(true);
    
    // 提交审批
    await submitApproval({
      applicationId: application.id,
      result: values.result,
      comment: values.comment,
    });
    
    message.success(values.result === 'pass' ? '审批通过' : '已驳回');
    setOpen(false);
    refreshList(); // 刷新列表
  } catch (error) {
    message.error('提交失败，请重试');
  } finally {
    setLoading(false);
  }
};
```

### 3. 撤回流程
```jsx
const handleRevoke = async (nodeId) => {
  Modal.confirm({
    title: '确认撤回流程?',
    content: '撤回后将返回上一步骤，是否继续?',
    onOk: async () => {
      await revokeApproval(nodeId);
      message.success('已撤回');
      refreshTimeline();
    },
  });
};
```

### 4. 申请内容区域调整
```jsx
// 支持拖拽调整高度
<Resizable
  defaultSize={{ height: 200 }}
  minHeight={150}
  maxHeight={500}
  enable={{ bottom: true }}
>
  <div className="application-content">
    {applicationContent}
  </div>
</Resizable>
```

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/form_tabs/tabs_form.png`

![审批详情弹窗](../../8-Reference-picture/references/form-tabs/tabs-form.png)

**设计要点**:
1. ✅ **左右分栏布局**：左侧主内容区 + 右侧流程跟踪固定宽度
2. ✅ **标题区**：申请标题 + 状态标签（审批中/已通过/已驳回）
3. ✅ **申请详情区**：
   - 申请人头像 + 姓名 + 提交时间
   - 申请内容展示区（灰色背景，可调整高度）
4. ✅ **审批操作区**（左侧底部）：
   - 处理意见：单选框（通过/驳回）
   - 审批意见：文本域输入框（0/500 字数限制）
   - 操作按钮：取消、确定
5. ✅ **流程跟踪区**（右侧固定）：
   - 时间线展示所有审批节点
   - 不同状态用不同颜色标识（蓝色/绿色/红色/灰色）
   - 已驳回节点突出显示驳回原因
   - 当前节点支持"撤回流程"操作

---

## ✅ 设计检查清单

- [ ] 弹窗宽度是否设置为 1000px（左右分栏需要更宽）
- [ ] 左侧主区域是否包含：申请详情区 + 审批操作区
- [ ] 右侧流程区是否固定 280px 宽度
- [ ] 申请内容展示区是否支持高度调整
- [ ] 时间线是否正确显示不同状态的节点（蓝色/绿色/红色/灰色）
- [ ] 已驳回节点是否突出显示驳回原因
- [ ] 审批意见输入框是否有字数限制（500字）
- [ ] 提交按钮是否有 loading 状态
- [ ] 选择"驳回"时是否强制要求填写驳回原因
- [ ] 关闭弹窗时是否重置表单数据
