# 消息列表页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 列表页 (Message List) |
| **应用场景** | 消息中心 - 集中展示各类消息 |
| **核心功能** | 展示系统消息、通知、提醒 |
| **设计目标** | 集中展示各类消息,方便用户查看历史消息,采用列表形式利于消息筛选和管理 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑导航
- 页面标题
- 全部已读按钮

### 2. 侧边栏模块
- 导航菜单

### 3. 列表模块
- 消息列表项
- 未读标识
- 消息类型图标
- 消息标题、内容、时间

### 4. 分页模块
- 分页器

---

## 🧩 组件层

```jsx
import { List, Badge, Avatar, Button, Space, Tag } from 'antd';

<Card
  title="消息中心"
  extra={
    <Button onClick={handleMarkAllRead}>全部已读</Button>
  }
>
  <List
    dataSource={messages}
    renderItem={(item) => (
      <List.Item
        key={item.id}
        style={{
          backgroundColor: item.isRead ? '#fff' : '#f0f5ff',
          padding: '16px',
          borderRadius: '4px',
          marginBottom: '8px',
        }}
        extra={
          !item.isRead && <Badge status="processing" text="未读" />
        }
      >
        <List.Item.Meta
          avatar={
            <Avatar 
              icon={getIconByType(item.type)} 
              style={{ backgroundColor: getColorByType(item.type) }}
            />
          }
          title={
            <Space>
              <span style={{ fontWeight: item.isRead ? 400 : 600 }}>
                {item.title}
              </span>
              <Tag color={getTagColor(item.type)}>
                {item.typeName}
              </Tag>
            </Space>
          }
          description={
            <>
              <div style={{ 
                marginBottom: 8,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}>
                {item.content}
              </div>
              <span style={{ color: '#999', fontSize: 12 }}>
                {item.createTime}
              </span>
            </>
          }
        />
        <Space>
          {!item.isRead && (
            <Button type="link" size="small" onClick={() => handleMarkRead(item.id)}>
              标记已读
            </Button>
          )}
          <Button type="link" size="small" onClick={() => handleView(item)}>
            查看详情
          </Button>
          <Button 
            type="link" 
            size="small" 
            danger
            onClick={() => handleDelete(item.id)}
          >
            删除
          </Button>
        </Space>
      </List.Item>
    )}
  />

  <Pagination
    current={page}
    pageSize={pageSize}
    total={total}
    onChange={handlePageChange}
    showTotal={(total) => `共 ${total} 条消息`}
    style={{ marginTop: 16, textAlign: 'right' }}
  />
</Card>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 消息中心)   [全部已读]   │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ [图标] 消息标题  [未读]   │  │
│  Sider    │  │        消息内容摘要       │  │
│  200px    │  │        2026-01-16 10:00  │  │
│           │  │        [查看] [删除]      │  │
│           │  ├───────────────────────────┤  │
│           │  │ [图标] 消息标题           │  │
│           │  │        消息内容摘要       │  │
│           │  │        2026-01-15 15:30  │  │
│           │  │        [查看] [删除]      │  │
│           │  └───────────────────────────┘  │
│           │  分页器                         │
└───────────┴─────────────────────────────────┘
```

---

## 🎨 设计规范

### 未读消息标识
- 背景色: #f0f5ff (浅蓝色)
- 标题字重: 600 (加粗)
- 右侧徽标: Badge组件

### 消息类型图标

| 类型 | 图标 | 颜色 |
|-----|-----|------|
| **系统通知** | BellOutlined | #1890ff |
| **审批通知** | CheckCircleOutlined | #52c41a |
| **提醒** | ClockCircleOutlined | #faad14 |
| **警告** | WarningOutlined | #ff4d4f |

### 列表项尺寸
- 内边距: 16px
- 间距: 8px
- 圆角: 4px

---

## 🎯 交互状态

### 批量操作
```jsx
<Space style={{ marginBottom: 16 }}>
  <Button onClick={handleMarkAllRead}>全部已读</Button>
  <Button danger onClick={handleDeleteAll}>清空消息</Button>
</Space>
```

### 筛选
```jsx
<Space style={{ marginBottom: 16 }}>
  <Select
    placeholder="消息类型"
    options={[
      { label: '全部', value: 'all' },
      { label: '系统通知', value: 'system' },
      { label: '审批通知', value: 'approval' },
      { label: '提醒', value: 'reminder' },
    ]}
    onChange={handleTypeChange}
    style={{ width: 150 }}
  />
  <Select
    placeholder="状态"
    options={[
      { label: '全部', value: 'all' },
      { label: '未读', value: 'unread' },
      { label: '已读', value: 'read' },
    ]}
    onChange={handleStatusChange}
    style={{ width: 120 }}
  />
</Space>
```

---

## 🖼️ 效果图参考

![消息列表页](../../8-Reference-picture/references/list-message/message-list.png)

**设计要点**:
- 未读消息背景色区分
- 消息类型图标和标签
- 操作按钮(标记已读、查看、删除)
- 全部已读按钮

---

## ✅ 设计检查清单

- [ ] 未读消息是否有视觉区分
- [ ] 消息类型是否有图标标识
- [ ] 是否提供全部已读功能
- [ ] 是否支持消息筛选
- [ ] 是否显示消息时间
- [ ] 长消息内容是否有省略处理
- [ ] 是否提供查看详情入口
- [ ] 删除操作是否有确认
