# 分步表单页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 表单页 (Step Form) |
| **应用场景** | 高级创建 - 创建复杂内容 |
| **核心功能** | 多步骤引导,分阶段输入 |
| **设计目标** | 分步骤引导降低操作复杂度,确保输入完整性和准确性 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑
- 页面标题

### 2. 侧边栏模块
- 导航菜单

### 3. 分步骤表单模块
- 步骤指示器(Steps)
- 当前步骤表单
- 上一步/下一步按钮

### 4. 操作模块
- 上一步按钮
- 下一步/提交按钮
- 取消按钮

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Steps,            // 步骤条
  Form,             // 表单
  Card,             // 卡片
  Button,           // 按钮
  Input,            // 输入框
  Select,           // 下拉选择
  DatePicker,       // 日期选择
  InputNumber,      // 数字输入
  Radio,            // 单选框
  Space,            // 间距
  message,          // 消息提示
} from 'antd';
```

### 使用示例

#### 完整分步表单结构

```jsx
const [current, setCurrent] = useState(0);
const [form] = Form.useForm();
const [loading, setLoading] = useState(false);
const [formData, setFormData] = useState({});

// 步骤配置
const steps = [
  {
    key: 'basic',
    title: '基本信息',
    description: '填写内容基础信息',
  },
  {
    key: 'content',
    title: '内容设置',
    description: '编辑内容详情',
  },
  {
    key: 'publish',
    title: '发布配置',
    description: '设置发布规则',
  },
];

// 下一步处理
const handleNext = async () => {
  try {
    const values = await form.validateFields();
    setFormData({ ...formData, ...values });
    setCurrent(current + 1);
  } catch (error) {
    console.error('验证失败:', error);
  }
};

// 上一步处理
const handlePrev = () => {
  setCurrent(current - 1);
};

// 最终提交
const handleSubmit = async () => {
  try {
    const values = await form.validateFields();
    const finalData = { ...formData, ...values };
    setLoading(true);
    
    await submitForm(finalData);
    message.success('提交成功');
    // 跳转到结果页或列表页
  } catch (error) {
    message.error('提交失败，请重试');
  } finally {
    setLoading(false);
  }
};

// 步骤内容组件
const StepContent = () => {
  switch (current) {
    case 0:
      return <Step1BasicInfo />;
    case 1:
      return <Step2ContentSetting />;
    case 2:
      return <Step3PublishConfig />;
    default:
      return null;
  }
};

// 主渲染
<div className="step-form-container">
  {/* 步骤指示器 */}
  <Steps
    current={current}
    items={steps}
    style={{ marginBottom: 24 }}
  />

  {/* 表单内容区 */}
  <Card>
    <Form
      form={form}
      layout="vertical"
      initialValues={formData}
    >
      <StepContent />
    </Form>
  </Card>

  {/* 操作按钮区 */}
  <Space style={{ marginTop: 24 }}>
    {current > 0 && (
      <Button onClick={handlePrev}>
        上一步
      </Button>
    )}
    {current < steps.length - 1 && (
      <Button type="primary" onClick={handleNext}>
        下一步
      </Button>
    )}
    {current === steps.length - 1 && (
      <Button type="primary" onClick={handleSubmit} loading={loading}>
        提交
      </Button>
    )}
    <Button onClick={handleCancel}>取消</Button>
  </Space>
</div>
```

#### 第一步：基本信息（Step 1）

```jsx
const Step1BasicInfo = () => (
  <>
    <Form.Item
      label="内容标题"
      name="title"
      rules={[{ required: true, message: '请输入内容标题' }]}
    >
      <Input placeholder="请输入内容标题" maxLength={50} showCount />
    </Form.Item>

    <Form.Item
      label="内容分类"
      name="category"
      rules={[{ required: true, message: '请选择内容分类' }]}
    >
      <Select
        placeholder="请选择分类"
        options={[
          { value: 'news', label: '新闻资讯' },
          { value: 'notice', label: '通知公告' },
          { value: 'policy', label: '政策文件' },
        ]}
      />
    </Form.Item>

    <Form.Item
      label="作者"
      name="author"
      rules={[{ required: true, message: '请输入作者姓名' }]}
    >
      <Input placeholder="请输入作者姓名" />
    </Form.Item>

    <Form.Item
      label="关键词"
      name="keywords"
    >
      <Input placeholder="请输入关键词，多个关键词用逗号分隔" />
    </Form.Item>
  </>
);
```

#### 第二步：内容设置（Step 2）

```jsx
const Step2ContentSetting = () => (
  <>
    <Form.Item
      label="内容摘要"
      name="summary"
      rules={[{ required: true, message: '请输入内容摘要' }]}
    >
      <Input.TextArea
        rows={4}
        placeholder="请输入内容摘要"
        maxLength={200}
        showCount
      />
    </Form.Item>

    <Form.Item
      label="正文内容"
      name="content"
      rules={[{ required: true, message: '请输入正文内容' }]}
    >
      <Input.TextArea
        rows={10}
        placeholder="请输入正文内容"
        maxLength={5000}
        showCount
      />
    </Form.Item>

    <Form.Item
      label="附件上传"
      name="attachments"
    >
      <Upload {...uploadProps}>
        <Button icon={<UploadOutlined />}>上传附件</Button>
      </Upload>
    </Form.Item>
  </>
);
```

#### 第三步：发布配置（Step 3）

```jsx
const Step3PublishConfig = () => (
  <>
    <Form.Item
      label="发布时间"
      name="publishTime"
      rules={[{ required: true, message: '请选择发布时间' }]}
    >
      <DatePicker
        showTime
        format="YYYY-MM-DD HH:mm:ss"
        style={{ width: '100%' }}
        placeholder="请选择发布时间"
      />
    </Form.Item>

    <Form.Item
      label="可见范围"
      name="visibility"
      rules={[{ required: true, message: '请选择可见范围' }]}
    >
      <Radio.Group>
        <Radio value="public">公开</Radio>
        <Radio value="internal">内部</Radio>
        <Radio value="private">私密</Radio>
      </Radio.Group>
    </Form.Item>

    <Form.Item
      label="是否置顶"
      name="pinned"
      valuePropName="checked"
    >
      <Switch checkedChildren="是" unCheckedChildren="否" />
    </Form.Item>

    <Form.Item
      label="排序权重"
      name="weight"
    >
      <InputNumber
        min={0}
        max={999}
        placeholder="数字越大越靠前"
        style={{ width: '100%' }}
      />
    </Form.Item>

    <Alert
      message="确认提交前请仔细核对所有信息"
      type="info"
      showIcon
      style={{ marginTop: 16 }}
    />
  </>
);
```

#### 步骤切换时数据保留

```jsx
// 使用 useEffect 在切换步骤时保存当前表单数据
useEffect(() => {
  if (current > 0) {
    // 获取当前表单值
    const currentValues = form.getFieldsValue();
    setFormData({ ...formData, ...currentValues });
  }
}, [current]);

// 切换步骤时恢复表单数据
useEffect(() => {
  form.setFieldsValue(formData);
}, [current, formData]);
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 标题)                     │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ Steps (步骤指示器)        │  │
│           │  │ ① 基本信息 → ② 内容设置   │  │
│  Sider    │  └───────────────────────────┘  │
│  200px    │  ┌───────────────────────────┐  │
│           │  │ Card (当前步骤表单)       │  │
│           │  │                           │  │
│           │  │ [当前步骤的表单字段]      │  │
│           │  │                           │  │
│           │  └───────────────────────────┘  │
│           │  [上一步] [下一步/提交]         │
└───────────┴─────────────────────────────────┘
```

---

## 🎨 设计规范

### 步骤数量
- **建议**: 3-5步
- **最佳**: 3-4步（用户注意力最集中）
- **避免**: 超过6步（降低用户耐心，增加放弃率）

### 步骤命名
- **简洁明了**：2-4个字（如"基本信息"、"内容设置"）
- **名词短语**：避免使用完整句子
- **分类清晰**：步骤之间逻辑连贯、互不重叠

### 步骤指示器样式（FTdesign 规范）

#### 圆形图标规格
| 属性 | 尺寸/颜色 | 说明 |
|-----|----------|------|
| **圆形直径** | 32px | 比默认更大，视觉更突出 |
| **图标大小** | 16px | 步骤编号或完成图标 |
| **连接线高度** | 2px | 步骤之间的连接线 |
| **外发光效果** | 8px blur | 当前步骤带品牌色光晕 |

#### 步骤状态颜色

```css
/* 已完成步骤 */
.ant-steps-item-finish .ant-steps-item-icon {
  background-color: var(--ft-brand-color) !important;  /* #005DEB */
  border-color: var(--ft-brand-color) !important;
  box-shadow: 0 0 8px rgba(0, 93, 235, 0.3) !important; /* 蓝色光晕 */
}

/* 当前步骤 */
.ant-steps-item-process .ant-steps-item-icon {
  background-color: var(--ft-brand-color) !important;
  border-color: var(--ft-brand-color) !important;
  box-shadow: 0 0 12px rgba(0, 93, 235, 0.5) !important; /* 更强的光晕 */
}

/* 等待步骤 */
.ant-steps-item-wait .ant-steps-item-icon {
  background-color: #FFFFFF !important;
  border-color: var(--ft-grey-4) !important; /* #C7CDD5 */
}

/* 连接线 */
.ant-steps-item-finish > .ant-steps-item-container > .ant-steps-item-tail::after {
  background-color: var(--ft-brand-color) !important;
}

.ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-tail::after {
  background-color: var(--ft-grey-3) !important; /* #DADDE2 */
}
```

### 每步表单字段数量
- **推荐**: 5-8个字段
- **最佳**: 4-6个字段（减少单步认知负担）
- **避免**: 超过10个字段（应考虑拆分步骤）

### 表单布局
- **垂直布局**: `layout="vertical"`（推荐，标签上置）
- **标签宽度**: 自适应
- **输入框高度**: 32px（默认）
- **文本域行数**: 4-10行（根据内容长度）

### 尺寸规范
| 元素 | 尺寸 | 说明 |
|-----|------|------|
| **步骤指示器高度** | 80px | 包含图标 + 标题 + 描述 |
| **步骤图标圆形** | 32px | 直径（比 Ant Design 默认大） |
| **步骤连接线高度** | 2px | 连接线粗细 |
| **表单卡片内边距** | 24px | Card padding |
| **表单项间距** | 24px | Form.Item margin-bottom |
| **按钮区上边距** | 24px | 与表单的间距 |

### 颜色规范
| 状态 | 背景色 | 边框色 | 文字色 | 光晕效果 |
|-----|--------|--------|--------|---------|
| **已完成** | #005DEB | #005DEB | #005DEB | 0 0 8px rgba(0,93,235,0.3) |
| **当前步骤** | #005DEB | #005DEB | #005DEB | 0 0 12px rgba(0,93,235,0.5) |
| **未完成** | #FFFFFF | #C7CDD5 | #8892A2 | 无 |

### 字体规范
| 元素 | 字号 | 字重 | 颜色 |
|-----|-----|------|------|
| **步骤标题** | 14px | 500 | #39485E（当前）/#8892A2（未完成） |
| **步骤描述** | 12px | 400 | #8892A2 |
| **步骤编号** | 14px | 600 | #FFFFFF（完成）/#8892A2（未完成） |

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/form_steps/step_form.png`

![分步表单页](../../8-Reference-picture/references/form-steps/step-form.png)

**设计要点**:

### 1. 步骤指示器（顶部）
- ✅ **32px 圆形图标**：比默认更大，视觉更突出
- ✅ **品牌色光晕效果**：当前步骤和已完成步骤带蓝色外发光
- ✅ **三步结构**：
  - 第一步：基本信息（已完成，蓝色 ✓）
  - 第二步：内容设置（当前步骤，蓝色数字 + 强光晕）
  - 第三步：发布配置（未完成，灰色）

### 2. 左侧导航（可选）
- ✅ **固定侧边栏**：240px 宽度
- ✅ **浅色背景**：#FFFFFF
- ✅ **菜单项**：内容列表（当前激活状态高亮）

### 3. 表单内容区（主区域）
- ✅ **白色卡片容器**：24px 内边距 + 2px 圆角
- ✅ **垂直表单布局**：标签上置，输入框下置
- ✅ **字段示例**（当前步骤：内容设置）：
  - 内容标题：Input 输入框
  - 内容分类：Select 下拉选择
  - 作者：Input 输入框
  - 正文内容：TextArea 文本域（多行）

### 4. 操作按钮区（底部）
- ✅ **左对齐布局**：按钮组左对齐
- ✅ **按钮顺序**：[上一步] [下一步] [取消]
- ✅ **按钮样式**：
  - 下一步/提交：主按钮（蓝色背景）
  - 上一步：默认按钮（白色背景 + 灰色边框）
  - 取消：默认按钮

### 5. 响应式交互
- ✅ **首步隐藏"上一步"**：第一步不显示"上一步"按钮
- ✅ **末步变"提交"**：最后一步"下一步"变为"提交"
- ✅ **数据保留**：切换步骤时保留已填数据
- ✅ **验证提示**：当前步骤未通过验证时，禁止下一步

### 6. 视觉细节
- ✅ **步骤连接线**：已完成步骤间用蓝色实线连接
- ✅ **未完成连接线**：未完成步骤间用灰色虚线连接
- ✅ **焦点状态**：输入框获得焦点时显示蓝色边框 + 浅蓝阴影
- ✅ **必填标识**：必填字段标签前显示红色星号

---

## 🎯 交互状态详解

### 1. 步骤切换逻辑

```jsx
const handleNext = async () => {
  try {
    // 验证当前步骤的表单字段
    const values = await form.validateFields();
    
    // 保存当前步骤数据
    setFormData({ ...formData, ...values });
    
    // 进入下一步
    setCurrent(current + 1);
    
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (error) {
    console.error('验证失败:', error);
    message.warning('请完善必填项后再继续');
  }
};
```

### 2. 中途保存草稿

```jsx
const handleSaveDraft = async () => {
  try {
    const currentValues = form.getFieldsValue();
    const draftData = { ...formData, ...currentValues };
    
    await saveDraft(draftData);
    message.success('草稿已保存');
  } catch (error) {
    message.error('保存失败，请重试');
  }
};

// 在每一步都显示"保存草稿"按钮
<Button onClick={handleSaveDraft}>保存草稿</Button>
```

### 3. 最后一步确认

```jsx
// 第三步：发布配置（最后一步）
const Step3PublishConfig = () => (
  <>
    {/* 表单字段 */}
    <Form.Item label="发布时间" name="publishTime">
      <DatePicker showTime />
    </Form.Item>
    
    {/* 数据预览卡片 */}
    <Card 
      title="数据确认"
      style={{ marginTop: 24, background: '#F3F4F5' }}
    >
      <Descriptions column={1} size="small">
        <Descriptions.Item label="内容标题">
          {formData.title}
        </Descriptions.Item>
        <Descriptions.Item label="内容分类">
          {formData.category}
        </Descriptions.Item>
        <Descriptions.Item label="作者">
          {formData.author}
        </Descriptions.Item>
      </Descriptions>
    </Card>
    
    <Alert
      message="确认提交前请仔细核对所有信息"
      type="info"
      showIcon
      style={{ marginTop: 16 }}
    />
  </>
);
```

### 4. 步骤跳转（可选）

```jsx
// 允许点击已完成的步骤直接跳转
<Steps
  current={current}
  items={steps}
  onChange={(step) => {
    // 只允许跳转到已完成的步骤
    if (step < current) {
      setCurrent(step);
    }
  }}
  style={{ marginBottom: 24 }}
/>
```

---

## ✅ 设计检查清单

### 步骤指示器
- [ ] 步骤数量是否在 3-5 步之间
- [ ] 步骤圆形图标是否为 32px（比默认大）
- [ ] 当前步骤和已完成步骤是否带品牌色光晕效果
- [ ] 已完成步骤是否显示蓝色勾选图标（✓）
- [ ] 步骤连接线颜色是否正确（已完成：蓝色，未完成：灰色）
- [ ] 步骤标题是否简洁明了（2-4个字）

### 表单内容
- [ ] 每步表单字段数量是否在 5-8 个之间
- [ ] 表单是否使用垂直布局（`layout="vertical"`）
- [ ] 必填字段是否有红色星号标识
- [ ] 输入框是否有 placeholder 提示
- [ ] 长文本输入是否有字数限制和计数

### 步骤切换
- [ ] 点击"下一步"时是否验证当前步骤表单
- [ ] 切换步骤时是否保留已填数据
- [ ] 首步是否隐藏"上一步"按钮
- [ ] 末步"下一步"按钮是否变为"提交"按钮
- [ ] 切换步骤后是否自动滚动到顶部

### 数据保存
- [ ] 是否支持中途保存草稿
- [ ] 最后一步是否有数据总览确认
- [ ] 提交按钮是否有 loading 状态
- [ ] 提交成功后是否跳转到结果页

### 交互体验
- [ ] 点击已完成步骤是否可以跳转返回（可选）
- [ ] 输入框获得焦点时是否显示蓝色边框 + 浅蓝阴影
- [ ] 验证失败时是否显示清晰的错误提示
- [ ] 关闭或取消时是否提示保存草稿（如有修改）

### 视觉一致性
- [ ] 步骤指示器样式是否符合 FTdesign 规范
- [ ] 表单卡片圆角是否为 2px
- [ ] 按钮颜色是否使用品牌色（#005DEB）
- [ ] 输入框高度是否统一为 32px

---

## 📚 相关页面模板

- **标准表单页**：06_form_standard.md（单页表单，无步骤）
- **弹窗表单**：05_form_modal.md（弹窗中的表单）
- **审批详情弹窗**：08_form_tabs.md（审批流程 + 时间线）
- **操作结果页**：13_result.md（提交成功后的结果页）
