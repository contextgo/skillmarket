# 完整详情页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 详情页 (Complete Detail) |
| **应用场景** | 查看复杂内容详情 - 多模块展示 |
| **核心功能** | 展示完整信息,多模块分组 |
| **设计目标** | 多分组多列布局使信息清晰分类,便于全面了解内容 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑
- 标题
- 返回按钮

### 2. 侧边栏模块
- 导航菜单

### 3. 详情展示模块
- 多个Card分组
- 每组使用 Descriptions

### 4. 分组展示模块
- 基本信息
- 扩展信息
- 关联信息

---

## 🧩 组件层

```jsx
<Space direction="vertical" size="large" style={{ width: '100%' }}>
  <Card title="基本信息" extra={<Button type="primary">编辑</Button>}>
    <Descriptions column={2} bordered>
      <Descriptions.Item label="标题">{detail.title}</Descriptions.Item>
      <Descriptions.Item label="分类">{detail.category}</Descriptions.Item>
      <Descriptions.Item label="状态">{detail.status}</Descriptions.Item>
      <Descriptions.Item label="创建时间">{detail.createTime}</Descriptions.Item>
    </Descriptions>
  </Card>

  <Card title="内容信息">
    <Descriptions column={1} bordered>
      <Descriptions.Item label="正文">
        <div dangerouslySetInnerHTML={{ __html: detail.content }} />
      </Descriptions.Item>
      <Descriptions.Item label="标签">
        {detail.tags.map(tag => <Tag key={tag}>{tag}</Tag>)}
      </Descriptions.Item>
    </Descriptions>
  </Card>

  <Card title="操作记录">
    <Table
      dataSource={detail.logs}
      columns={[
        { title: '操作人', dataIndex: 'operator' },
        { title: '操作类型', dataIndex: 'action' },
        { title: '操作时间', dataIndex: 'time' },
      ]}
      pagination={false}
      size="small"
    />
  </Card>
</Space>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 标题)        [返回]       │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ Card: 基本信息   [编辑]   │  │
│  Sider    │  │ Descriptions (2列)        │  │
│  200px    │  └───────────────────────────┘  │
│           │  ┌───────────────────────────┐  │
│           │  │ Card: 内容信息            │  │
│           │  │ Descriptions (1列)        │  │
│           │  └───────────────────────────┘  │
│           │  ┌───────────────────────────┐  │
│           │  │ Card: 操作记录            │  │
│           │  │ Table (列表)              │  │
│           │  └───────────────────────────┘  │
└───────────┴─────────────────────────────────┘
```

---

## 🖼️ 效果图参考

![完整详情页](../../8-Reference-picture/references/detail-complete/complete-detail.png)

**设计要点**:
- 多个Card分组
- 每组独立标题
- 垂直排列,间距24px

---

## ✅ 设计检查清单

- [ ] 信息是否合理分组
- [ ] 每组是否有清晰标题
- [ ] 模块间距是否合适
- [ ] 长文本是否有折叠/展开
- [ ] 关联数据是否清晰展示
