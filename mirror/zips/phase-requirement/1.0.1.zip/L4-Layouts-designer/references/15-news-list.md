# News List - 资讯列表页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | News List (资讯列表/内容列表) |
| **应用场景** | 用户浏览、搜索、筛选内容列表 |
| **核心功能** | 展示内容列表、多维度筛选、搜索、分页浏览 |
| **设计目标** | 让用户快速找到并查看所需内容 |

---

## 🏗️ 模块层

### 1. 页头模块 (Header)
- 系统Logo/品牌标识
- 主导航菜单（横向排列）
- 全局搜索框
- 用户操作区（登录/注册）
- **高度**: 64px
- **背景**: 白色，底部边框分隔

### 2. 二级导航模块 (Sub Navigation)
- 内容分类快捷入口
- 搜索框（带筛选下拉）
- **高度**: 80-100px
- **背景**: 渐变背景（蓝紫色系）

### 3. 筛选模块 (Filter Bar)
- **基础筛选**: 分类、状态、排序方式
- **高级筛选**: 时间范围、关键词等
- **快捷筛选标签**: 常用筛选条件快捷入口
- **布局**: 横向排列，支持折叠展开

### 4. 内容列表模块 (Content List)
- **左侧主区域**: 内容列表（占据主要宽度，约 70%）
  - 列表项卡片式展示
  - 每条内容包含：标题、摘要、分类标签、发布时间、浏览量等元信息
  - 状态指示器
  - 操作按钮
- **右侧边栏**: 辅助信息区（固定宽度，约 30%）
  - 推荐内容列表
  - 快捷入口

### 5. 分页模块 (Pagination)
- 页码导航（居中显示）
- 每页显示数量选择
- 总条数统计
- 跳转到指定页

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Layout,           // 布局框架
  Card,             // 卡片容器
  List,             // 列表组件
  Row, Col,         // 栅格布局
  Button,           // 按钮
  Badge,            // 徽标
  Tag,              // 标签
  Select,           // 选择器
  Input,            // 输入框
  DatePicker,       // 日期选择
  Pagination,       // 分页
  Empty,            // 空状态
  Menu,             // 导航菜单
  Tooltip,          // 提示
  Tabs,             // 标签页
} from 'antd';
```

### 使用示例

#### 内容列表项
```jsx
<List
  itemLayout="vertical"
  dataSource={contentList}
  renderItem={item => (
    <List.Item
      className="content-item"
      actions={[
        <Button type="primary" size="small">查看</Button>
      ]}
    >
      <div className="content-header">
        <div className={`status-dot ${getStatusClass(item)}`} />
        <Tag color={getCategoryColor(item.category)}>{item.categoryName}</Tag>
        <span className="publish-time">{formatDate(item.publishTime)}</span>
      </div>
      <List.Item.Meta
        title={<a href={`/content/${item.id}`}>{item.title}</a>}
        description={item.summary}
      />
      <div className="content-footer">
        <span><i className="ri-eye-line" /> {item.viewCount}</span>
        <span><i classNameri-time-line" /> {item.publishTime}</span>
      </div>
    </List.Item>
  )}
/>
```

#### 筛选栏
```jsx
<div className="filter-bar">
  <Row gutter={16}>
    <Col span={4}>
      <Select placeholder="全部分类" style={{ width: '100%' }}>
        <Option value="">全部分类</Option>
        <Option value="category1">分类一</Option>
        <Option value="category2">分类二</Option>
        <Option value="category3">分类三</Option>
      </Select>
    </Col>
    <Col span={4}>
      <Select placeholder="全部状态" style={{ width: '100%' }}>
        <Option value="">全部状态</Option>
        <Option value="active">进行中</Option>
        <Option value="completed">已完成</Option>
      </Select>
    </Col>
    <Col span={4}>
      <Select placeholder="排序方式" style={{ width: '100%' }}>
        <Option value="time-desc">发布时间（最新）</Option>
        <Option value="time-asc">发布时间（最早）</Option>
        <Option value="view-desc">浏览量（最多）</Option>
      </Select>
    </Col>
    <Col span={4}>
      <Button icon={<FilterOutlined />}>高级筛选</Button>
    </Col>
    <Col span={4}>
      <Button onClick={resetFilters}>重置</Button>
      <Button type="primary" onClick={applyFilters}>应用</Button>
    </Col>
  </Row>
</div>
```

#### 快捷筛选标签
```jsx
<div className="quick-filters">
  <Tabs type="card">
    <TabPane tab="全部" key="all" />
    <TabPane tab="进行中" key="active" />
    <TabPane tab="今日发布" key="today" />
    <TabPane tab="本周发布" key="week" />
  </Tabs>
</div>
```

#### 右侧辅助模块
```jsx
<div className="sidebar-right">
  {/* 推荐内容 */}
  <Card 
    title="推荐内容" 
    size="small"
    extra={<a href="#">更多</a>}
  >
    <List
      dataSource={recommendList}
      renderItem={(item, index) => (
        <List.Item>
          <List.Item.Meta
            avatar={
              <Badge 
                count={index + 1} 
                style={{ 
                  backgroundColor: index < 3 ? '#ff4d4f' : '#d9d9d9' 
                }} 
              />
            }
            title={<a href={`/content/${item.id}`}>{item.title}</a>}
            description={`${item.viewCount} 浏览`}
          />
        </List.Item>
      )}
    />
  </Card>
  
  {/* 快捷入口 */}
  <Card 
    title="快捷入口" 
    size="small"
  >
    <div className="quick-actions">
      {actions.map(action => (
        <Button 
          key={action.key}
          type="dashed"
          block
          icon={action.icon}
        >
          {action.label}
        </Button>
      ))}
    </div>
  </Card>
</div>
```

---

## 📐 布局层

### 整体布局结构

```
┌─────────────────────────────────────────────────────────────────────────┐
│  页头 (Header 64px)                                                      │
│  [Logo]  [首页] [内容中心] [解决方案] [关于我们]    [搜索框]  [登录]      │
├─────────────────────────────────────────────────────────────────────────┤
│  二级导航 (Sub Nav 80-100px)                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐│
│  │  [全部] [分类一] [分类二] [分类三] [分类四]                          ││
│  │  [搜索框 ▼] [热门标签]                                               ││
│  │  渐变背景（蓝紫色）                                                  ││
│  └─────────────────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────────────────┤
│  筛选模块 (Filter Bar)                                                   │
│  [分类▼] [状态▼] [排序▼] [高级筛选] [重置] [应用筛选]                   │
├─────────────────────────────────────────────────────────────────────────┤
│  快捷筛选标签 (Quick Filters)                                            │
│  [全部] [进行中] [今日发布] [本周发布]                                  │
├─────────────────────────────────────────────────────────┬───────────────┤
│  内容列表模块 (Content List)                             │  右侧边栏      │
│  ┌───────────────────────────────────────────────────┐  │  ┌─────────┐  │
│  │ ●                                                   │  │  │ 推荐内容 │  │
│  │ [分类一] 内容标题                                    │  │  │ 1 标题   │  │
│  │ 发布时间 · 👁 1,256                                  │  │  │ 2 标题   │  │
│  │ [查看]                                              │  │  │ 3 标题   │  │
│  ├───────────────────────────────────────────────────┤  │  │ ...     │  │
│  │ ●                                                   │  │  ├─────────┤  │
│  │ [分类二] 内容标题                                    │  │  │ 快捷入口 │  │
│  │ 发布时间 · 👁 2,341                                  │  │  │ [按钮1]  │  │
│  │ [查看]                                              │  │  │ [按钮2]  │  │
│  ├───────────────────────────────────────────────────┤  │  │ ...     │  │
│  │ ...                                               │  │  └─────────┘  │
│  │                                                   │  │               │
│  │ 共找到 25 条内容                                  │  │               │
│  └───────────────────────────────────────────────────┘  └───────────────┘
├─────────────────────────────────────────────────────────────────────────┤
│  分页模块 (Pagination)                                                   │
│  [<] [1] [2] [3] ... [10] [>]  [每页 10 条] [跳转到 __ 页]              │
└─────────────────────────────────────────────────────────────────────────┘
```

### 响应式设计

| 屏幕尺寸 | 布局方式 | 说明 |
|---------|---------|------|
| **大屏 (>1200px)** | 左侧列表 + 右侧边栏 | 双栏布局，右侧边栏固定320px |
| **中屏 (768-1200px)** | 单列列表 | 隐藏右侧边栏，全宽展示列表 |
| **小屏 (<768px)** | 单列列表 + 折叠筛选 | 筛选栏折叠，卡片式布局 |

### 栅格布局
- 主内容区使用 24 栅格系统
- 左侧列表: `col={16}` (约 66%)
- 右侧边栏: `col={8}` (约 33%)
- 间距: `gutter={24}`
- 内边距: `padding: 24px`

---

## 🎨 设计规范

### 尺寸规范
| 元素 | 尺寸 |
|-----|------|
| 页头高度 | 64px |
| 二级导航高度 | 80-100px |
| 筛选栏高度 | auto (自适应) |
| 列表项间距 | 16px |
| 卡片内边距 | 20px |
| 右侧边栏宽度 | 320px |
| 分页高度 | 56px |

### 颜色规范
| 用途 | 颜色值 |
|-----|--------|
| 主色 | #1890ff |
| 成功色 | #52c41a |
| 警告色 | #faad14 |
| 错误色 | #f5222d |
| 文本色(标题) | rgba(0, 0, 0, 0.85) |
| 次要文本 | rgba(0, 0, 0, 0.45) |
| 边框色 | #f0f0f0 |
| 背景色 | #f5f7fa |
| 渐变起始 | #667eea |
| 渐变结束 | #764ba2 |

### 状态颜色
| 状态 | 颜色 |
|-----|------|
| 未读/新 | #1890ff (蓝色) |
| 已读/完成 | #52c41a (绿色) |
| 进行中 | #faad14 (橙色) |
| 紧急/重要 | #f5222d (红色) |

### 分类颜色
| 分类 | 颜色 |
|-----|------|
| 分类一 | #ff4d4f (红色) |
| 分类二 | #faad14 (橙色) |
| 分类三 | #1890ff (蓝色) |
| 分类四 | #52c41a (绿色) |
| 分类五 | #722ed1 (紫色) |

### 字体规范
| 元素 | 字号 | 字重 |
|-----|------|------|
| 页面标题 | 24px | 600 |
| 内容标题 | 16px | 500 |
| 正文 | 14px | 400 |
| 辅助文字 | 12px | 400 |
| 数字统计 | 14px | 500 |

---

## 🖼️ 效果图参考

> 参考图片: 企业门户列表页

**页面特征分析**:
1. **顶部导航**: Logo + 主导航菜单 + 搜索框 + 用户操作
2. **二级导航**: 内容分类标签 + 搜索筛选 + 热门标签云
3. **筛选区域**: 多维度筛选条件组合
4. **快捷筛选**: 横向标签页形式的快捷入口
5. **内容列表**: 卡片式列表，包含标题、摘要、元信息、操作按钮
6. **右侧边栏**: 推荐内容、快捷入口
7. **分页**: 底部居中分页组件

**关键设计元素**:
- 蓝紫色渐变背景的二级导航
- 白色卡片式内容列表项
- 彩色分类标签
- 圆形状态指示器
- 推荐内容排行标识

---

## ✅ 设计检查清单

- [ ] 页头是否包含Logo、导航、搜索、用户操作
- [ ] 二级导航是否使用渐变背景（蓝紫色）
- [ ] 筛选栏是否包含分类、状态、排序
- [ ] 快捷筛选标签是否包含常用筛选条件
- [ ] 内容列表项是否显示状态指示器
- [ ] 重要内容是否有醒目标识
- [ ] 内容卡片是否包含标题、摘要、分类、时间、浏览量
- [ ] 右侧边栏是否包含推荐内容和快捷入口
- [ ] 推荐排行前三名是否有特殊颜色标识
- [ ] 分页组件是否在底部居中
- [ ] 响应式布局是否适配移动端
- [ ] 空状态是否有友好提示和重置按钮

---

## 🔧 交互说明

### 筛选交互
1. 选择筛选条件 → 点击"应用筛选" → 列表更新并显示Loading
2. 点击快捷标签 → 自动应用对应筛选条件并高亮当前标签
3. 点击"重置" → 清空所有筛选条件并刷新列表
4. 点击"高级筛选" → 展开更多筛选条件面板

### 列表交互
1. 点击内容标题 → 进入内容详情页
2. 点击"查看"按钮 → 进入详情页
3. 悬停列表项 → 背景色变化，显示操作按钮
4. 分页切换 → 平滑滚动到列表顶部并更新内容

### 状态反馈
1. 筛选中 → Skeleton 骨架屏 Loading 状态
2. 无结果 → Empty 空状态组件，提供重置按钮
3. 操作成功 → Message 成功提示
4. 操作失败 → Message 错误提示
5. 网络错误 → Result 错误页面或重试按钮

---

## 📱 移动端适配

### 布局调整
- 页头变为汉堡菜单 + Logo + 搜索图标
- 二级导航变为横向滚动标签
- 筛选栏变为抽屉式展开
- 右侧边栏隐藏或折叠到底部
- 列表项变为全宽卡片式布局

### 交互调整
- 左右滑动切换筛选标签
- 下拉刷新列表
- 上拉加载更多（无限滚动）
- 底部固定快捷操作栏

---

## 📊 数据格式

### 内容数据结构
```typescript
interface ContentItem {
  id: string;              // 内容ID
  title: string;           // 标题
  summary: string;         // 摘要
  category: string;        // 分类代码
  categoryName: string;    // 分类名称
  publishTime: string;     // 发布时间
  viewCount: number;       // 浏览量
  status: string;          // 状态
}
```

---

## 📚 相关文档

- [首页设计 - 01_dashboard](01-dashboard.md)
