# 实时通知浮窗

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 浮窗 (Notification Popover) |
| **应用场景** | 实时通知 - 及时推送重要消息 |
| **核心功能** | 实时推送系统动态或关键信息 |
| **设计目标** | 实时推送重要通知,及时告知用户系统动态,确保用户不错过重要消息 |

---

## 🏗️ 模块层

### 1. 页头模块
- 铃铛图标
- 未读数量徽标

### 2. 列表模块
- 最近通知列表(5-10条)
- 通知标题、时间
- 未读标识

### 3. 操作模块
- 全部已读按钮
- 查看全部按钮

---

## 🧩 组件层

```jsx
import { Badge, Popover, List, Button, Space, Divider } from 'antd';
import { BellOutlined } from '@ant-design/icons';

const NotificationPanel = () => (
  <div style={{ width: 360 }}>
    {/* 头部 */}
    <div style={{ 
      padding: '12px 16px', 
      display: 'flex', 
      justifyContent: 'space-between',
      alignItems: 'center',
    }}>
      <span style={{ fontWeight: 600 }}>通知</span>
      <Button type="link" size="small" onClick={handleMarkAllRead}>
        全部已读
      </Button>
    </div>

    <Divider style={{ margin: 0 }} />

    {/* 通知列表 */}
    <List
      dataSource={notifications}
      renderItem={(item) => (
        <List.Item
          key={item.id}
          style={{
            padding: '12px 16px',
            cursor: 'pointer',
            backgroundColor: item.isRead ? '#fff' : '#f0f5ff',
          }}
          onClick={() => handleNotificationClick(item)}
        >
          <List.Item.Meta
            avatar={
              !item.isRead && (
                <Badge status="processing" />
              )
            }
            title={
              <span style={{ 
                fontSize: 14,
                fontWeight: item.isRead ? 400 : 600,
              }}>
                {item.title}
              </span>
            }
            description={
              <span style={{ fontSize: 12, color: '#999' }}>
                {item.time}
              </span>
            }
          />
        </List.Item>
      )}
      style={{ maxHeight: 400, overflowY: 'auto' }}
    />

    <Divider style={{ margin: 0 }} />

    {/* 底部 */}
    <div style={{ padding: '12px 16px', textAlign: 'center' }}>
      <Button type="link" onClick={handleViewAll}>
        查看全部通知
      </Button>
    </div>
  </div>
);

// 使用Popover
<Popover
  content={<NotificationPanel />}
  trigger="click"
  placement="bottomRight"
  overlayStyle={{ paddingTop: 8 }}
>
  <Badge count={unreadCount} offset={[0, 4]}>
    <BellOutlined style={{ fontSize: 18, cursor: 'pointer' }} />
  </Badge>
</Popover>
```

---

## 📐 布局层

```
┌─ Header ──────────────────────────────┐
│  [Logo]  [导航]          [@] [🔔5]   │
└───────────────────────────┬───────────┘
                            │
                            ▼
              ┌──────────────────────┐
              │ 通知      [全部已读] │
              ├──────────────────────┤
              │ ● 消息标题           │
              │   2分钟前            │
              ├──────────────────────┤
              │ ● 消息标题           │
              │   10分钟前           │
              ├──────────────────────┤
              │   消息标题 (已读)    │
              │   1小时前            │
              ├──────────────────────┤
              │  [查看全部通知]      │
              └──────────────────────┘
```

---

## 🎨 设计规范

### 浮窗尺寸
- 宽度: 360px
- 最大高度: 500px (列表区最大400px)
- 列表项高度: 自适应

### 未读标识
- 徽标颜色: #1890ff
- 未读背景: #f0f5ff
- 未读字重: 600

### 列表项
- 内边距: 12px 16px
- hover背景: #fafafa
- 光标: pointer

---

## 🎯 交互状态

### 实时推送
使用WebSocket或轮询实现实时通知:

```jsx
useEffect(() => {
  const ws = new WebSocket('ws://api.example.com/notifications');
  
  ws.onmessage = (event) => {
    const notification = JSON.parse(event.data);
    
    // 更新通知列表
    setNotifications(prev => [notification, ...prev]);
    
    // 显示桌面通知(可选)
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(notification.title, {
        body: notification.content,
        icon: '/logo.png',
      });
    }
  };

  return () => ws.close();
}, []);
```

### 消息提示音
```jsx
const playNotificationSound = () => {
  const audio = new Audio('/notification.mp3');
  audio.play();
};
```

---

## 🖼️ 效果图参考

![实时通知浮窗](../../8-Reference-picture/references/notification/notification-popover.png)

**设计要点**:
- 页头铃铛图标 + 未读数量徽标
- 点击展开浮窗
- 列表显示最近5-10条通知
- 未读通知背景色区分
- 底部"查看全部"链接

---

## ✅ 设计检查清单

- [ ] 铃铛图标是否显眼
- [ ] 未读数量是否实时更新
- [ ] 浮窗位置是否合适(右上角)
- [ ] 列表是否限制显示数量
- [ ] 未读通知是否有视觉区分
- [ ] 点击通知是否跳转详情
- [ ] 是否提供"查看全部"入口
- [ ] 是否支持"全部已读"
- [ ] 浮窗是否可滚动(通知较多时)
- [ ] 点击外部是否关闭浮窗
