# 抽屉详情

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 详情页 (Drawer Detail) |
| **应用场景** | 完整审批(抽屉) - 侧边弹出详情 |
| **核心功能** | 不离开当前页面查看详情 |
| **设计目标** | 提供详细流程节点和处理表单,确保审批完整性 |

---

## 🏗️ 模块层

### 1. 详情模块
- 基本信息展示

### 2. 流程节点模块
- 流程步骤展示(Steps)
- 当前节点标识

### 3. 处理表单模块
- 审批表单
- 操作按钮

---

## 🧩 组件层

```jsx
import { Drawer, Descriptions, Steps, Form, Radio, Input, Button, Space } from 'antd';

<Drawer
  title="审批详情"
  open={open}
  onClose={handleClose}
  width={720}
>
  {/* 基本信息 */}
  <Card title="基本信息" size="small" style={{ marginBottom: 24 }}>
    <Descriptions column={1} size="small">
      <Descriptions.Item label="流程标题">{detail.title}</Descriptions.Item>
      <Descriptions.Item label="发起人">{detail.creator}</Descriptions.Item>
      <Descriptions.Item label="发起时间">{detail.createTime}</Descriptions.Item>
    </Descriptions>
  </Card>

  {/* 流程节点 */}
  <Card title="流程进度" size="small" style={{ marginBottom: 24 }}>
    <Steps
      direction="vertical"
      current={detail.currentStep}
      items={detail.steps.map(step => ({
        title: step.title,
        description: step.description,
        status: step.status,
      }))}
    />
  </Card>

  {/* 审批表单 */}
  <Card title="审批处理" size="small">
    <Form layout="vertical">
      <Form.Item label="审批结果" name="result" rules={[{ required: true }]}>
        <Radio.Group>
          <Radio value="pass">通过</Radio>
          <Radio value="reject">驳回</Radio>
        </Radio.Group>
      </Form.Item>
      <Form.Item label="审批意见" name="comment" rules={[{ required: true }]}>
        <Input.TextArea rows={4} placeholder="请输入审批意见" />
      </Form.Item>
    </Form>
  </Card>

  {/* 底部操作 */}
  <div style={{ textAlign: 'right', marginTop: 24 }}>
    <Space>
      <Button onClick={handleClose}>取消</Button>
      <Button type="primary" onClick={handleSubmit} loading={loading}>
        提交
      </Button>
    </Space>
  </div>
</Drawer>
```

---

## 📐 布局层

```
┌──────────────────────────────────┐
│  审批详情                    [×]│
├──────────────────────────────────┤
│  ┌────────────────────────────┐ │
│  │ Card: 基本信息             │ │
│  │ Descriptions               │ │
│  └────────────────────────────┘ │
│  ┌────────────────────────────┐ │
│  │ Card: 流程进度             │ │
│  │ Steps (垂直)               │ │
│  │ ① 发起                     │ │
│  │ ② 审批中 (当前)            │ │
│  │ ③ 完成                     │ │
│  └────────────────────────────┘ │
│  ┌────────────────────────────┐ │
│  │ Card: 审批处理             │ │
│  │ [通过/驳回] Radio          │ │
│  │ [审批意见] TextArea        │ │
│  └────────────────────────────┘ │
│                                  │
│           [取消]  [提交]         │
└──────────────────────────────────┘
```

---

## 🎨 设计规范

### 抽屉宽度
- 简单详情: 480px
- 标准详情: 720px
- 复杂详情: 900px

### 流程步骤
- 使用垂直Steps
- 当前步骤高亮
- 已完成步骤标记

---

## 🖼️ 效果图参考

![抽屉详情](../../8-Reference-picture/references/detail-drawer/drawer-detail.png)

**设计要点**:
- 右侧抽屉弹出
- 流程步骤垂直展示
- 底部固定操作按钮

---

## ✅ 设计检查清单

- [ ] 抽屉宽度是否合适
- [ ] 流程步骤是否清晰
- [ ] 表单验证是否完整
- [ ] 提交按钮是否有loading状态
- [ ] 关闭时是否有未保存提示
