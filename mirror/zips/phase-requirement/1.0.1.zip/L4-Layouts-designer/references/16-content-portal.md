# Content Portal - 内容门户首页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | Content Portal (内容门户首页) |
| **应用场景** | 内容聚合平台首页，展示各类内容、文章、资讯等 |
| **核心功能** | 内容聚合展示、分类浏览、搜索、用户互动 |
| **设计目标** | 打造视觉吸引力强、信息层次清晰的内容浏览体验 |

---

## 🏗️ 模块层

### 1. 页头模块 (Header)
- **品牌标识区**: Logo + 网站名称
- **主导航菜单**: 横向排列的导航项
- **用户操作区**: 搜索图标、消息通知、用户头像
- **高度**: 60px
- **背景**: 白色，底部细边框分隔

### 2. 横幅/ Hero 模块 (Hero Banner)
- **背景**: 蓝紫色渐变模糊背景（玻璃拟态效果）
- **左侧内容区**: 
  - 栏目名称
  - 日期显示
  - 内容列表（编号形式，两列布局）
  - 每条内容：序号 + 标题（单行省略）
- **右侧图片区**:
  - 大幅特色图片展示
  - 图片标题/说明文字
- **高度**: 280-320px
- **布局**: 左右分栏（左侧 60%，右侧 40%）

### 3. 快捷入口模块 (Quick Actions)
- **布局**: 横向排列的图标按钮组
- **内容**: 图标 + 文字描述，简洁卡片式
- **主按钮**: 突出显示的主要操作按钮

### 4. 内容分类导航模块 (Category Nav)
- **标题**: 内容区域标题
- **分类标签**: 横向排列的分类选项
- **样式**: 标签页形式，当前选中项高亮显示
- **位置**: 内容列表上方

### 5. 内容列表模块 (Content Grid)
- **布局**: 双列卡片网格（Grid Layout）
- **卡片结构**:
  - 顶部：分类标签 + 标题（两行显示）
  - 中部：缩略图（16:9 比例）
  - 底部：摘要文字（3-4行，多行省略）
  - 元信息：发布时间、浏览量等
- **交互**: 悬停卡片上浮阴影效果
- **间距**: 卡片间距 24px

### 6. 分页/加载更多模块 (Pagination)
- 加载更多按钮或页码导航
- 位于内容列表底部

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Layout,           // 布局框架
  Card,             // 卡片容器
  Row, Col,         // 栅格布局
  Button,           // 按钮
  Badge,            // 徽标
  Tag,              // 标签
  Tabs,             // 标签页
  List,             // 列表
  Avatar,           // 头像
  Divider,          // 分隔线
  Tooltip,          // 提示
} from 'antd';
```

### 使用示例

#### 页头导航
```jsx
<Header className="site-header">
  <div className="header-left">
    <div className="logo">
      <img src="/logo.png" alt="Logo" />
      <span className="site-name">网站名称</span>
    </div>
    <Menu mode="horizontal" className="main-nav">
      <Menu.Item key="home">首页</Menu.Item>
      <Menu.Item key="content1">内容分类一</Menu.Item>
      <Menu.Item key="content2">内容分类二</Menu.Item>
      <Menu.Item key="content3">内容分类三</Menu.Item>
      <Menu.Item key="about">关于我们</Menu.Item>
    </Menu>
  </div>
  <div className="header-right">
    <Badge count={5} size="small">
      <BellOutlined className="icon-btn" />
    </Badge>
    <Badge count={3} size="small">
      <MessageOutlined className="icon-btn" />
    </Badge>
    <SearchOutlined className="icon-btn" />
    <Avatar src="/user-avatar.jpg" />
  </div>
</Header>
```

#### Hero Banner 区域
```jsx
<div className="hero-banner">
  <Row gutter={24}>
    <Col span={14}>
      <div className="hero-content">
        <div className="section-header">
          <h2>栏目名称</h2>
          <span className="date">2024年01月01日 星期一</span>
        </div>
        <Row gutter={16}>
          <Col span={12}>
            <List
              dataSource={leftContent}
              renderItem={(item, index) => (
                <List.Item className="content-item-compact">
                  <span className="content-number">{String(index + 1).padStart(2, '0')}</span>
                  <span className="content-title">{item.title}</span>
                </List.Item>
              )}
            />
          </Col>
          <Col span={12}>
            <List
              dataSource={rightContent}
              renderItem={(item, index) => (
                <List.Item className="content-item-compact">
                  <span className="content-number">{String(index + 5).padStart(2, '0')}</span>
                  <span className="content-title">{item.title}</span>
                </List.Item>
              )}
            />
          </Col>
        </Row>
      </div>
    </Col>
    <Col span={10}>
      <div className="hero-image">
        <img src="/featured-image.jpg" alt="特色内容" />
        <div className="image-caption">
          特色内容标题说明
        </div>
      </div>
    </Col>
  </Row>
</div>
```

#### 快捷入口
```jsx
<div className="quick-actions-bar">
  <Row gutter={24} justify="center">
    <Col>
      <div className="action-item">
        <div className="action-icon">
          <SearchOutlined />
        </div>
        <div className="action-text">
          <div className="action-title">功能入口一</div>
          <div className="action-desc">功能描述</div>
        </div>
      </div>
    </Col>
    <Col>
      <div className="action-item">
        <div className="action-icon">
          <RocketOutlined />
        </div>
        <div className="action-text">
          <div className="action-title">功能入口二</div>
          <div className="action-desc">功能描述</div>
        </div>
      </div>
    </Col>
    <Col>
      <div className="action-item">
        <div className="action-icon">
          <RiseOutlined />
        </div>
        <div className="action-text">
          <div className="action-title">功能入口三</div>
          <div className="action-desc">功能描述</div>
        </div>
      </div>
    </Col>
    <Col>
      <Button type="primary" size="large" className="main-action-btn">
        主要操作按钮
      </Button>
    </Col>
  </Row>
</div>
```

#### 分类导航 + 内容卡片
```jsx
<div className="content-section">
  <div className="section-header">
    <h2 className="section-title">内容区域标题</h2>
    <Tabs 
      activeKey={activeCategory}
      onChange={setActiveCategory}
      className="category-tabs"
    >
      <TabPane tab="全部" key="all" />
      <TabPane tab="分类一" key="category1" />
      <TabPane tab="分类二" key="category2" />
      <TabPane tab="分类三" key="category3" />
      <TabPane tab="分类四" key="category4" />
    </Tabs>
  </div>
  
  <Row gutter={[24, 24]}>
    {contentList.map(item => (
      <Col span={12} key={item.id}>
        <Card 
          className="content-card"
          hoverable
          cover={<img alt={item.title} src={item.cover} />}
        >
          <div className="card-header">
            <Tag color="#1890ff" className="category-tag">
              <FireOutlined /> {item.category}
            </Tag>
            <h3 className="card-title">{item.title}</h3>
          </div>
          <p className="card-summary">{item.summary}</p>
          <div className="card-footer">
            <span className="publish-time">{item.time}</span>
            <span className="view-count">
              <EyeOutlined /> {item.views}
            </span>
          </div>
        </Card>
      </Col>
    ))}
  </Row>
</div>
```

---

## 📐 布局层

### 整体布局结构

```
┌─────────────────────────────────────────────────────────────────────────┐
│  页头 (Header 60px)                                                      │
│  [Logo]  [首页] [分类一] [分类二] [分类三] ...    [🔔] [💬] [🔍] [头像]│
├─────────────────────────────────────────────────────────────────────────┤
│  Hero Banner (280-320px)                                                 │
│  ┌─────────────────────────────────────┬─────────────────────────────┐  │
│  │  栏目名称                    日期   │                             │  │
│  │                                     │    ┌─────────────────────┐  │  │
│  │  01 内容标题一                      │    │                     │  │  │
│  │  02 内容标题二                      │    │    特色图片         │  │  │
│  │  03 内容标题三                      │    │                     │  │  │
│  │  04 内容标题四                      │    │    图片标题说明     │  │  │
│  │  05 内容标题五                      │    │                     │  │  │
│  │  06 内容标题六                      │    │                     │  │  │
│  │  07 内容标题七                      │    └─────────────────────┘  │  │
│  │  08 内容标题八                      │                             │  │
│  └─────────────────────────────────────┴─────────────────────────────┘  │
│  渐变模糊背景（蓝紫色系）                                                  │
├─────────────────────────────────────────────────────────────────────────┤
│  快捷入口 (Quick Actions)                                                │
│  [🔍 功能入口一]  [🚀 功能入口二]  [📈 功能入口三]  [主要操作按钮]       │
├─────────────────────────────────────────────────────────────────────────┤
│  内容区域 (Content Section)                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐│
│  │  内容区域标题    [全部] [分类一] [分类二] [分类三] [分类四]         ││
│  ├─────────────────────────────────┬───────────────────────────────────┤│
│  │  ┌─────────────────────────┐    │  ┌─────────────────────────┐     ││
│  │  │ [标签 内容标题...]      │    │  │ [标签 内容标题...]      │     ││
│  │  │                         │    │  │                         │     ││
│  │  │  [缩略图]               │    │  │  [缩略图]               │     ││
│  │  │                         │    │  │                         │     ││
│  │  │ 内容摘要文字...         │    │  │ 内容摘要文字...         │     ││
│  │  │                         │    │  │                         │     ││
│  │  │ 发布时间                │    │  │ 发布时间                │     ││
│  │  └─────────────────────────┘    │  └─────────────────────────┘     ││
│  ├─────────────────────────────────┼───────────────────────────────────┤│
│  │  ┌─────────────────────────┐    │  ┌─────────────────────────┐     ││
│  │  │ [标签 内容标题...]      │    │  │ [标签 内容标题...]      │     ││
│  │  └─────────────────────────┘    │  └─────────────────────────┘     ││
│  └─────────────────────────────────┴───────────────────────────────────┘│
├─────────────────────────────────────────────────────────────────────────┤
│  分页/加载更多                                                           │
│  [加载更多] 或 [<] [1] [2] [3] ... [>]                                   │
└─────────────────────────────────────────────────────────────────────────┘
```

### 响应式设计

| 屏幕尺寸 | 布局方式 | 说明 |
|---------|---------|------|
| **大屏 (>1200px)** | 双列卡片 + 完整导航 | Hero区域左右分栏，内容双列展示 |
| **中屏 (768-1200px)** | 双列卡片 + 折叠导航 | 导航菜单折叠，Hero区域上下堆叠 |
| **小屏 (<768px)** | 单列卡片 + 汉堡菜单 | 单列布局，卡片全宽展示 |

### 栅格布局
- 主内容区使用 24 栅格系统
- 内容卡片: `col={12}` (双列布局)
- Hero区域: 左 `col={14}` + 右 `col={10}`
- 间距: `gutter={[24, 24]}`
- 内边距: `padding: 0 24px`
- 最大宽度: 1200px (居中)

---

## 🎨 设计规范

### 尺寸规范
| 元素 | 尺寸 |
|-----|------|
| 页头高度 | 60px |
| Hero区域高度 | 280-320px |
| 快捷入口高度 | 80px |
| 内容卡片间距 | 24px |
| 卡片圆角 | 8px |
| 缩略图比例 | 16:9 |
| 最大内容宽度 | 1200px |

### 颜色规范
| 用途 | 颜色值 |
|-----|--------|
| 品牌主色 | #1890ff (蓝色) |
| 品牌辅助色 | #40a9ff (浅蓝) |
| 渐变起始 | #667eea (蓝紫) |
| 渐变结束 | #764ba2 (深紫) |
| 文本色(标题) | #1a1a1a |
| 次要文本 | #666666 |
| 辅助文字 | #999999 |
| 边框色 | #e8e8e8 |
| 背景色 | #f5f5f5 |
| 卡片背景 | #ffffff |

### 字体规范
| 元素 | 字号 | 字重 |
|-----|------|------|
| Logo文字 | 24px | 700 |
| 导航菜单 | 14px | 400 |
| Hero标题 | 20px | 600 |
| 内容序号 | 14px | 600 |
| 卡片标题 | 16px | 600 |
| 卡片摘要 | 14px | 400 |
| 辅助信息 | 12px | 400 |

### 阴影规范
| 场景 | 阴影值 |
|-----|--------|
| 卡片默认 | 0 2px 8px rgba(0,0,0,0.06) |
| 卡片悬停 | 0 8px 24px rgba(0,0,0,0.12) |
| 页头 | 0 2px 4px rgba(0,0,0,0.05) |

---

## 🖼️ 效果图参考

> 参考图片: 内容门户首页

**页面特征分析**:
1. **顶部导航**: Logo + 主导航菜单 + 用户操作图标
2. **Hero区域**: 蓝紫色渐变模糊背景，左右分栏布局
3. **内容列表**: 编号式紧凑列表，两列排列
4. **特色图片**: 右侧大幅展示，带标题说明
5. **快捷入口**: 图标+文字组合，主按钮突出
6. **分类导航**: 标签页形式，选中状态高亮
7. **内容卡片**: 双列网格，缩略图+标题+摘要结构
8. **视觉风格**: 现代简洁，品牌色贯穿，玻璃拟态效果

**关键设计元素**:
- 品牌色贯穿全页
- 蓝紫色渐变背景营造视觉层次
- 编号式内容列表
- 双列卡片网格布局
- 悬停阴影增强交互感

---

## ✅ 设计检查清单

- [ ] 页头是否包含Logo、主导航、用户操作区
- [ ] Hero区域是否使用蓝紫色渐变背景
- [ ] Hero区域是否为左右分栏布局
- [ ] 内容列表是否使用编号形式
- [ ] 右侧是否展示大幅特色图片
- [ ] 快捷入口是否包含图标+文字
- [ ] 主操作按钮是否突出显示
- [ ] 分类导航是否使用标签页形式
- [ ] 当前选中标签是否高亮显示
- [ ] 内容卡片是否为双列网格布局
- [ ] 卡片是否包含缩略图、标题、摘要
- [ ] 卡片悬停是否有阴影效果
- [ ] 响应式布局是否适配移动端
- [ ] 最大内容宽度是否限制在1200px

---

## 🔧 交互说明

### 导航交互
1. 主导航悬停 → 文字颜色变化或下划线
2. 当前页面导航 → 高亮显示
3. 用户图标点击 → 下拉菜单（个人中心、设置、退出）

### Hero区域交互
1. 内容标题悬停 → 文字变色，显示完整标题Tooltip
2. 特色图片悬停 → 轻微放大效果
3. 图片点击 → 进入详情页

### 快捷入口交互
1. 图标悬停 → 上浮动画 + 阴影增强
2. 主按钮悬停 → 背景色加深
3. 点击按钮 → 执行对应操作

### 内容卡片交互
1. 卡片悬停 → 上浮 + 阴影增强
2. 缩略图悬停 → 轻微放大
3. 标题点击 → 进入详情页
4. 分类标签点击 → 筛选对应分类内容

### 分类标签交互
1. 标签点击 → 切换内容列表
2. 当前标签 → 高亮背景
3. 切换动画 → 内容淡入淡出

---

## 📱 移动端适配

### 布局调整
- 页头变为：Logo + 汉堡菜单 + 搜索图标
- Hero区域变为：上下堆叠（内容列表在上，图片在下）
- 内容列表变为：单列显示
- 快捷入口变为：横向滚动或2x2网格
- 内容卡片变为：单列全宽展示
- 分类标签变为：横向滚动

### 交互调整
- 左右滑动切换分类标签
- 下拉刷新内容列表
- 上拉加载更多（无限滚动）
- 点击卡片进入详情页

---

## 📊 数据格式

### 内容数据结构
```typescript
interface ContentItem {
  id: string;              // 内容ID
  title: string;           // 标题
  summary: string;         // 摘要
  category: string;        // 分类
  cover: string;           // 封面图URL
  publishTime: string;     // 发布时间
  views: number;           // 浏览量
}

interface HeroContentItem {
  id: string;
  title: string;
  url: string;
}

interface FeaturedContent {
  image: string;
  title: string;
  description: string;
  url: string;
}
```

---

## 🎨 视觉风格指南

### 玻璃拟态效果 (Glassmorphism)
```css
.hero-banner {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.9) 0%, rgba(118, 75, 162, 0.9) 100%);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}
```

### 卡片悬停效果
```css
.content-card {
  transition: all 0.3s ease;
}

.content-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}
```

### 文字省略处理
```css
.content-title {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
```

---

## 📚 相关文档

- [首页设计 - 01_dashboard](01-dashboard.md)
- [资讯列表页设计 - 02_news_list](15-news-list.md)
