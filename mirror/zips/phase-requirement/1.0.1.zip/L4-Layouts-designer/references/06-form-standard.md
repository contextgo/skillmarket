# 标准表单页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 表单页 (Standard Form) |
| **应用场景** | 标准创建 - 创建常规内容 |
| **核心功能** | 完整页面表单,支持复杂字段 |
| **设计目标** | 简洁布局和集中组件,方便输入少量数据,保障创建易用性 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑导航
- 页面标题

### 2. 侧边栏模块
- 导航菜单

### 3. 表单模块
- 表单字段(垂直布局)
- 表单验证

### 4. 操作模块
- 提交按钮
- 取消按钮

---

## 🧩 组件层

```jsx
<Form
  form={form}
  layout="vertical"
  onFinish={handleSubmit}
>
  <Card>
    <Form.Item label="标题" name="title" rules={[{ required: true }]}>
      <Input placeholder="请输入标题" maxLength={100} showCount />
    </Form.Item>

    <Form.Item label="分类" name="category" rules={[{ required: true }]}>
      <Select placeholder="请选择分类" options={categoryOptions} />
    </Form.Item>

    <Form.Item label="发布时间" name="publishTime">
      <DatePicker showTime style={{ width: '100%' }} />
    </Form.Item>

    <Form.Item label="内容" name="content" rules={[{ required: true }]}>
      <Input.TextArea rows={8} placeholder="请输入内容" />
    </Form.Item>

    <Form.Item label="状态" name="status">
      <Radio.Group>
        <Radio value="draft">草稿</Radio>
        <Radio value="published">发布</Radio>
      </Radio.Group>
    </Form.Item>
  </Card>

  <Space style={{ marginTop: 16 }}>
    <Button type="primary" htmlType="submit" loading={loading}>
      提交
    </Button>
    <Button onClick={handleCancel}>取消</Button>
  </Space>
</Form>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 标题)                     │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ Card (表单容器)           │  │
│  Sider    │  │                           │  │
│  200px    │  │ [标题输入框]              │  │
│           │  │ [分类选择器]              │  │
│           │  │ [日期选择器]              │  │
│           │  │ [内容文本域]              │  │
│           │  │ [状态单选]                │  │
│           │  │                           │  │
│           │  └───────────────────────────┘  │
│           │  [取消] [提交]                  │
└───────────┴─────────────────────────────────┘
```

---

## 🖼️ 效果图参考

![标准表单页](../../8-Reference-picture/references/form-standard/standard-create.png)

**设计要点**:
- 单列垂直布局
- 表单宽度: 最大800px
- 字段间距: 24px
- 底部固定操作按钮

---

## ✅ 设计检查清单

- [ ] 表单宽度是否限制(避免过宽)
- [ ] 表单标签是否左对齐
- [ ] 操作按钮是否固定在底部
- [ ] 取消操作是否有确认
- [ ] 表单字段是否有验证规则
