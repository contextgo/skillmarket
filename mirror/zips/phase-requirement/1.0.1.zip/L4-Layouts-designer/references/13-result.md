# 操作结果页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 结果页 (Result Page) |
| **应用场景** | 操作结果反馈 - 成功/失败状态展示 |
| **核心功能** | 清晰反馈操作结果,引导下一步操作 |
| **设计目标** | 清晰展示状态和引导下一步操作,保障用户操作流程的连贯性和明确性 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑(可选)

### 2. 侧边栏模块
- 导航菜单

### 3. 状态展示模块
- 状态图标(成功/失败/警告/信息)
- 状态标题
- 状态描述

### 4. 操作引导模块
- 引导按钮
- 返回首页
- 查看详情

---

## 🧩 组件层

```jsx
import { Result, Button } from 'antd';

// 成功状态
<Result
  status="success"
  title="提交成功!"
  subTitle="您的申请已提交,流程编号: 20260116001,预计3个工作日内完成审批。"
  extra={[
    <Button type="primary" key="detail" onClick={handleViewDetail}>
      查看详情
    </Button>,
    <Button key="back" onClick={handleBack}>
      返回列表
    </Button>,
  ]}
/>

// 失败状态
<Result
  status="error"
  title="提交失败"
  subTitle="请检查并修改以下信息后重新提交。"
  extra={[
    <Button type="primary" key="retry" onClick={handleRetry}>
      重新提交
    </Button>,
    <Button key="back" onClick={handleBack}>
      返回
    </Button>,
  ]}
>
  <div className="desc">
    <Paragraph>
      <Text strong style={{ fontSize: 16 }}>
        提交失败原因:
      </Text>
    </Paragraph>
    <Paragraph>
      <CloseCircleOutlined style={{ color: 'red' }} /> 标题不能为空
    </Paragraph>
    <Paragraph>
      <CloseCircleOutlined style={{ color: 'red' }} /> 分类未选择
    </Paragraph>
  </div>
</Result>

// 警告状态
<Result
  status="warning"
  title="存在风险项"
  subTitle="检测到以下问题,建议处理后再提交。"
  extra={[
    <Button type="primary" key="continue" onClick={handleContinue}>
      继续提交
    </Button>,
    <Button key="fix" onClick={handleFix}>
      返回修改
    </Button>,
  ]}
/>

// 信息状态
<Result
  status="info"
  title="审批中"
  subTitle="您的申请正在审批中,请耐心等待。"
  extra={[
    <Button type="primary" key="home">
      返回首页
    </Button>,
  ]}
/>

// 404状态
<Result
  status="404"
  title="404"
  subTitle="抱歉,您访问的页面不存在。"
  extra={[
    <Button type="primary" onClick={() => navigate('/')}>
      返回首页
    </Button>
  ]}
/>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (可选)                              │
├───────────┬─────────────────────────────────┤
│           │                                 │
│           │        ┌─────────┐             │
│  Sider    │        │  图标   │             │
│  200px    │        └─────────┘             │
│           │                                 │
│           │      [ 状态标题 ]               │
│           │                                 │
│           │      状态描述文字               │
│           │                                 │
│           │   [主操作] [次要操作]           │
│           │                                 │
└───────────┴─────────────────────────────────┘
```

---

## 🎨 设计规范

### 状态类型

| 状态 | 图标颜色 | 使用场景 |
|-----|---------|---------|
| **success** | 绿色 | 操作成功 |
| **error** | 红色 | 操作失败 |
| **warning** | 橙色 | 警告提示 |
| **info** | 蓝色 | 信息提示 |
| **404** | 灰色 | 页面不存在 |
| **403** | 灰色 | 无权限 |
| **500** | 灰色 | 服务器错误 |

### 文案规范
- **标题**: 简洁明了(4-10字)
- **描述**: 补充说明(20-50字)
- **按钮**: 动词开头(如"查看详情"、"返回列表")

### 按钮配置
- **主按钮**: type="primary" (1个)
- **次要按钮**: type="default" (1-2个)
- **按钮顺序**: 主要操作在前

---

## 🎯 交互状态

### 自动跳转
某些场景下可以设置自动跳转:

```jsx
useEffect(() => {
  const timer = setTimeout(() => {
    navigate('/list');
  }, 3000);
  return () => clearTimeout(timer);
}, []);

<Result
  status="success"
  title="提交成功!"
  subTitle="3秒后自动返回列表页..."
/>
```

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/result/`

### 成功状态页
![成功状态页](../../8-Reference-picture/references/result/success.png)

**设计要点**:
- 绿色成功图标
- 标题: "提交成功!"
- 描述: 流程编号和预计时间
- 按钮: 查看详情(主)、返回列表(次)

### 失败状态页
![失败状态页](../../8-Reference-picture/references/result/error.png)

**设计要点**:
- 红色失败图标
- 标题: "提交失败"
- 描述: 失败原因列表
- 按钮: 重新提交(主)、返回(次)

---

## ✅ 设计检查清单

- [ ] 状态图标是否清晰醒目
- [ ] 标题是否简洁明了
- [ ] 描述是否提供足够信息
- [ ] 操作按钮是否明确
- [ ] 主次按钮是否区分明显
- [ ] 是否提供返回路径
- [ ] 失败状态是否说明原因
- [ ] 成功状态是否提供下一步操作
