# 表格视图列表页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 列表页 (Table View) |
| **应用场景** | 角色列表、用户列表、流程总览、内容库等 |
| **核心功能** | 展示结构化数据,支持筛选、搜索、批量操作 |
| **设计目标** | 高密度展示数据,便于批量操作和分析,提高数据管理效率 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑导航
- 页面标题

### 2. 侧边栏模块
- 导航菜单 (固定宽度: 240px, FTdesign 规范)

### 3. 筛选模块
- 搜索框 (Input.Search)
- 下拉筛选 (Select)
- 日期筛选 (DatePicker)
- 复选框筛选 (Checkbox)

### 4. 操作模块
- 新建按钮 (主按钮)
- 导出按钮
- 批量操作按钮 (批量删除、批量导出等)

### 5. 数据展示模块
- 数据表格 (Table)
- 行选择器 (Checkbox)
- 状态标签 (Tag/Badge)
- 行操作按钮 (编辑、删除、查看)

### 6. 分页模块
- 分页器 (Pagination)
- 总数显示
- 每页条数切换

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Table,            // 数据表格
  Input,            // 输入框/搜索框
  Select,           // 下拉选择
  DatePicker,       // 日期选择
  Button,           // 按钮
  Tag,              // 标签
  Badge,            // 徽标
  Space,            // 间距
  Checkbox,         // 复选框
  Popconfirm,       // 气泡确认框
  Dropdown,         // 下拉菜单
  Menu,             // 菜单
} from 'antd';
```

### 使用示例

#### 筛选区域
```jsx
<Space size="middle" style={{ marginBottom: 16 }}>
  <Input.Search 
    placeholder="搜索标题/关键词" 
    onSearch={handleSearch}
    style={{ width: 280 }}
  />
  <Select
    placeholder="选择分类"
    options={categoryOptions}
    style={{ width: 200 }}
    onChange={handleCategoryChange}
  />
  <DatePicker.RangePicker 
    onChange={handleDateChange}
  />
  <Button type="primary" icon={<SearchOutlined />}>
    查询
  </Button>
  <Button onClick={handleReset}>
    重置
  </Button>
</Space>
```

#### 操作区域
```jsx
<Space size="middle" style={{ marginBottom: 16 }}>
  <Button type="primary" icon={<PlusOutlined />}>
    新建
  </Button>
  <Button icon={<ExportOutlined />}>
    导出
  </Button>
  <Button 
    danger 
    disabled={selectedRowKeys.length === 0}
  >
    批量删除
  </Button>
</Space>
```

#### 数据表格
```jsx
<Table
  rowSelection={{
    selectedRowKeys,
    onChange: setSelectedRowKeys,
  }}
  columns={[
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      width: 200,
    },
    {
      title: '分类',
      dataIndex: 'category',
      key: 'category',
      width: 120,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status) => {
        const color = status === '已发布' ? 'green' : 'orange';
        return <Tag color={color}>{status}</Tag>;
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 180,
      sorter: true,
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 180,
      render: (_, record) => (
        <Space size="small">
          <a onClick={() => handleView(record)}>查看</a>
          <a onClick={() => handleEdit(record)}>编辑</a>
          <Popconfirm
            title="确定删除吗?"
            onConfirm={() => handleDelete(record)}
          >
            <a style={{ color: '#ff4d4f' }}>删除</a>
          </Popconfirm>
        </Space>
      ),
    },
  ]}
  dataSource={dataSource}
  pagination={{
    current: page,
    pageSize: pageSize,
    total: total,
    showSizeChanger: true,
    showQuickJumper: true,
    showTotal: (total) => `共 ${total} 条`,
    pageSizeOptions: [10, 20, 50, 100],
  }}
  loading={loading}
  onChange={handleTableChange}
  scroll={{ x: 1200 }}
/>
```

---

## 📐 布局层

### 整体布局结构

```
┌─────────────────────────────────────────────┐
│  Header (页头: 面包屑 + 标题)               │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ 筛选区域                  │  │
│           │  │ 搜索框 | 下拉 | 日期      │  │
│  侧边栏   │  └───────────────────────────┘  │
│  Sider    │  ┌───────────────────────────┐  │
│  200px    │  │ 操作区域                  │  │
│           │  │ 新建 | 导出 | 批量操作    │  │
│           │  └───────────────────────────┘  │
│           │  ┌───────────────────────────┐  │
│           │  │                           │  │
│           │  │   数据表格 (Table)        │  │
│           │  │                           │  │
│           │  └───────────────────────────┘  │
│           │  ┌───────────────────────────┐  │
│           │  │ 分页器                    │  │
│           │  └───────────────────────────┘  │
└───────────┴─────────────────────────────────┘
```

### 响应式设计

| 屏幕尺寸 | 布局方式 | 说明 |
|---------|---------|------|
| **大屏 (>1200px)** | 筛选区域单行展示 | 表格显示所有列 |
| **中屏 (768-1200px)** | 筛选区域换行 | 表格隐藏次要列 |
| **小屏 (<768px)** | 切换为卡片列表 | 表格水平滚动 |

### 栅格布局
- 主内容区padding: 24px
- 筛选区与操作区间距: 16px
- 表格与分页器间距: 16px

---

## 🎨 设计规范

### 尺寸规范
- **表格行高**: 48px (推荐)
- **操作列宽度**: 150-200px
- **搜索框宽度**: 280px
- **下拉选择宽度**: 200px
- **按钮高度**: 32px (默认)

### 表格列宽建议
| 列类型 | 建议宽度 |
|-------|---------|
| 复选框 | 60px |
| 序号 | 80px |
| 短文本 (如状态) | 100-120px |
| 中等文本 (如标题) | 200-300px |
| 日期时间 | 180px |
| 操作列 | 150-200px |

### 颜色规范
- **表格边框**: #f0f0f0
- **表头背景**: #fafafa
- **hover行背景**: #f5f5f5
- **选中行背景**: #e6f7ff

### 字体规范
- **表头**: 14px / font-weight: 600
- **表格内容**: 14px / font-weight: 400

---

## 🎯 交互状态

### 1. 空状态
```jsx
<Table
  locale={{
    emptyText: (
      <Empty
        description="暂无数据"
        image={Empty.PRESENTED_IMAGE_SIMPLE}
      >
        <Button type="primary" icon={<PlusOutlined />}>
          新建第一条数据
        </Button>
      </Empty>
    ),
  }}
/>
```

### 2. 加载状态
- 使用 `loading={true}` 属性
- 显示骨架屏

### 3. 错误状态
- 显示错误提示
- 提供重试按钮

### 4. 批量操作状态
- 选中行数提示
- 批量操作按钮根据选中状态启用/禁用

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/list_table/`

### 角色列表示例
![角色列表效果图](../../8-Reference-picture/references/list-table/role-list.png)

**页面结构**:
- 页头模块: 面包屑 + "角色管理"标题
- 筛选模块: 搜索框 + 状态筛选
- 操作模块: 新建角色按钮
- 数据展示: 表格 (角色名称、权限数、用户数、状态、操作)
- 分页模块: 显示总数和分页器

### 用户列表示例
![用户列表效果图](../../8-Reference-picture/references/list-table/user-list.png)

**页面结构**:
- 筛选模块: 搜索框 + 角色筛选 + 状态筛选
- 操作模块: 新建用户 + 批量导出
- 数据展示: 表格 (用户名、邮箱、角色、状态、创建时间、操作)
- 批量选择: 支持行选择器

### 流程总览示例
![流程总览效果图](../../8-Reference-picture/references/list-table/workflow-list.png)

**页面结构**:
- 筛选模块: 搜索框 + 流程类型 + 状态筛选 + 日期范围
- 操作模块: 发起流程 + 导出
- 数据展示: 表格 (流程标题、类型、发起人、当前节点、状态、时间、操作)
- 状态标签: 使用不同颜色的 Tag 组件

### 内容库示例
![内容库效果图](../../8-Reference-picture/references/list-table/content-list.png)

**页面结构**:
- 筛选模块: 搜索框 + 分类 + 状态 + 日期范围
- 操作模块: 新建内容 + 批量删除
- 数据展示: 表格 (标题、分类、作者、状态、发布时间、操作)
- 支持排序: 点击表头排序

---

## ✅ 设计检查清单

- [ ] 表格是否支持行选择(批量操作场景)
- [ ] 操作列是否固定在右侧
- [ ] 是否提供搜索和筛选功能
- [ ] 分页器是否显示总数
- [ ] 是否提供每页条数切换
- [ ] 空状态是否有引导操作
- [ ] 加载状态是否使用 loading 属性
- [ ] 删除操作是否有二次确认
- [ ] 表格宽度超出时是否可横向滚动
- [ ] 响应式布局是否适配移动端
