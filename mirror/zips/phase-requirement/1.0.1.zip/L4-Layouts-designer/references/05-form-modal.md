# 弹窗表单

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 弹窗表单页 |
| **应用场景** | 权限配置、用户分配、用户编辑、轻量创建、快速审批 |
| **核心功能** | 快速创建/编辑单条记录,不离开当前页面 |
| **设计目标** | 减少干扰,便捷完成单一输入任务,提升操作速度 |

---

## 🏗️ 模块层

### 1. 弹窗模块
- 弹窗标题
- 关闭按钮
- 遮罩层

### 2. 表单模块
- 表单字段 (Input、Select、DatePicker等)
- 表单验证提示

### 3. 操作模块
- 确定按钮 (主按钮)
- 取消按钮

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Modal,            // 对话框
  Form,             // 表单
  Input,            // 输入框
  Select,           // 下拉选择
  DatePicker,       // 日期选择
  Radio,            // 单选框
  Checkbox,         // 复选框
  Switch,           // 开关
  InputNumber,      // 数字输入
  Button,           // 按钮
  Space,            // 间距
  Upload,           // 上传
  message,          // 消息提示
} from 'antd';
```

### 使用示例

#### 基础弹窗表单 (用户编辑)
```jsx
const [form] = Form.useForm();
const [open, setOpen] = useState(false);
const [loading, setLoading] = useState(false);

const handleOk = async () => {
  try {
    const values = await form.validateFields();
    setLoading(true);
    await updateUser(values);
    message.success('保存成功');
    setOpen(false);
    form.resetFields();
  } catch (error) {
    console.error('验证失败:', error);
  } finally {
    setLoading(false);
  }
};

<Modal
  title="编辑用户"
  open={open}
  onOk={handleOk}
  onCancel={() => setOpen(false)}
  confirmLoading={loading}
  width={600}
  destroyOnClose
>
  <Form
    form={form}
    layout="vertical"
    initialValues={initialValues}
  >
    <Form.Item
      label="用户名"
      name="username"
      rules={[{ required: true, message: '请输入用户名' }]}
    >
      <Input placeholder="请输入用户名" />
    </Form.Item>

    <Form.Item
      label="邮箱"
      name="email"
      rules={[
        { required: true, message: '请输入邮箱' },
        { type: 'email', message: '邮箱格式不正确' },
      ]}
    >
      <Input placeholder="请输入邮箱" />
    </Form.Item>

    <Form.Item
      label="角色"
      name="role"
      rules={[{ required: true, message: '请选择角色' }]}
    >
      <Select
        placeholder="请选择角色"
        options={roleOptions}
      />
    </Form.Item>

    <Form.Item
      label="状态"
      name="status"
      valuePropName="checked"
    >
      <Switch checkedChildren="启用" unCheckedChildren="禁用" />
    </Form.Item>
  </Form>
</Modal>
```

#### 权限配置弹窗 (树形选择)
```jsx
<Modal
  title="权限配置"
  open={open}
  onOk={handleOk}
  onCancel={handleCancel}
  width={800}
>
  <Form form={form} layout="vertical">
    <Form.Item
      label="角色名称"
      name="roleName"
    >
      <Input disabled />
    </Form.Item>

    <Form.Item
      label="权限配置"
      name="permissions"
    >
      <Tree
        checkable
        treeData={permissionTree}
        checkedKeys={checkedKeys}
        onCheck={setCheckedKeys}
      />
    </Form.Item>
  </Form>
</Modal>
```

#### 用户分配弹窗 (穿梭框)
```jsx
<Modal
  title="分配用户"
  open={open}
  onOk={handleOk}
  onCancel={handleCancel}
  width={900}
>
  <Transfer
    dataSource={allUsers}
    targetKeys={selectedUsers}
    onChange={setSelectedUsers}
    render={(item) => item.title}
    showSearch
    listStyle={{
      width: 400,
      height: 400,
    }}
    titles={['未分配用户', '已分配用户']}
  />
</Modal>
```

#### 快速审批弹窗
```jsx
<Modal
  title="快速审批"
  open={open}
  onOk={handleOk}
  onCancel={handleCancel}
  width={500}
>
  <Form form={form} layout="vertical">
    <Form.Item
      label="审批结果"
      name="result"
      rules={[{ required: true, message: '请选择审批结果' }]}
    >
      <Radio.Group>
        <Radio value="pass">通过</Radio>
        <Radio value="reject">驳回</Radio>
      </Radio.Group>
    </Form.Item>

    <Form.Item
      label="审批意见"
      name="comment"
      rules={[{ required: true, message: '请输入审批意见' }]}
    >
      <Input.TextArea
        rows={4}
        placeholder="请输入审批意见"
        maxLength={200}
        showCount
      />
    </Form.Item>
  </Form>
</Modal>
```

#### 轻量创建弹窗
```jsx
<Modal
  title="新建内容"
  open={open}
  onOk={handleOk}
  onCancel={handleCancel}
  width={600}
>
  <Form form={form} layout="vertical">
    <Form.Item
      label="标题"
      name="title"
      rules={[{ required: true, message: '请输入标题' }]}
    >
      <Input placeholder="请输入标题" maxLength={50} showCount />
    </Form.Item>

    <Form.Item
      label="分类"
      name="category"
      rules={[{ required: true, message: '请选择分类' }]}
    >
      <Select placeholder="请选择分类" options={categoryOptions} />
    </Form.Item>

    <Form.Item
      label="发布时间"
      name="publishTime"
    >
      <DatePicker showTime style={{ width: '100%' }} />
    </Form.Item>

    <Form.Item
      label="内容"
      name="content"
      rules={[{ required: true, message: '请输入内容' }]}
    >
      <Input.TextArea
        rows={6}
        placeholder="请输入内容"
        maxLength={500}
        showCount
      />
    </Form.Item>
  </Form>
</Modal>
```

---

## 📐 布局层

### 弹窗布局结构

```
┌─────────────────────────────────────┐
│  标题                          [×]  │
├─────────────────────────────────────┤
│                                     │
│  ┌───────────────────────────────┐ │
│  │ 表单字段 1 (label)            │ │
│  │ [输入框]                      │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌───────────────────────────────┐ │
│  │ 表单字段 2 (label)            │ │
│  │ [下拉选择]                    │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌───────────────────────────────┐ │
│  │ 表单字段 3 (label)            │ │
│  │ [文本域]                      │ │
│  └───────────────────────────────┘ │
│                                     │
├─────────────────────────────────────┤
│              [取消]  [确定]         │
└─────────────────────────────────────┘
```

### 弹窗宽度规范

| 表单复杂度 | 建议宽度 | 适用场景 |
|-----------|---------|---------|
| **简单表单** | 500px | 2-3个字段 |
| **标准表单** | 600px | 4-6个字段 |
| **复杂表单** | 800px | 7+个字段或需要双列布局 |
| **特殊场景** | 900px+ | 穿梭框、树形选择等 |

---

## 🎨 设计规范

### 尺寸规范
- **弹窗标题高度**: 55px
- **弹窗内边距**: 24px
- **表单项间距**: 24px
- **底部按钮区高度**: 56px

### 表单布局
- **垂直布局**: `layout="vertical"` (推荐)
- **标签宽度**: 自适应
- **输入框高度**: 32px (默认)
- **文本域行数**: 4-6行

### 颜色规范
- **遮罩层**: rgba(0, 0, 0, 0.45)
- **弹窗背景**: #ffffff
- **边框**: #f0f0f0

### 字体规范
- **弹窗标题**: 16px / font-weight: 600
- **表单标签**: 14px / font-weight: 400
- **输入文字**: 14px

---

## 🎯 交互状态

### 1. 表单验证
- 实时验证: 失焦时验证
- 错误提示: 字段下方显示红色提示文字
- 必填标识: 标签前显示红色星号

### 2. 提交状态
- 提交中: 确定按钮显示loading状态
- 提交成功: 显示成功提示,关闭弹窗
- 提交失败: 显示错误提示,保持弹窗打开

### 3. 关闭确认
```jsx
<Modal
  title="编辑用户"
  open={open}
  onCancel={() => {
    if (form.isFieldsTouched()) {
      Modal.confirm({
        title: '确认关闭?',
        content: '当前有未保存的内容,确定要关闭吗?',
        onOk: () => {
          setOpen(false);
          form.resetFields();
        },
      });
    } else {
      setOpen(false);
    }
  }}
>
  {/* 表单内容 */}
</Modal>
```

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/form_modal/`

### 用户编辑弹窗
![用户编辑弹窗](../../8-Reference-picture/references/form-modal/user-edit.png)

**设计要点**:
- 标题: "编辑用户"
- 字段: 用户名、邮箱、角色、状态
- 底部: 取消、确定按钮

### 权限配置弹窗
![权限配置弹窗](../../8-Reference-picture/references/form-modal/permission-config.png)

**设计要点**:
- 宽度: 800px (树形选择需要更宽)
- 使用树形复选框
- 支持全选/取消全选

### 用户分配弹窗
![用户分配弹窗](../../8-Reference-picture/references/form-modal/user-assign.png)

**设计要点**:
- 宽度: 900px
- 使用穿梭框(Transfer)组件
- 左右分栏布局
- 支持搜索

### 快速审批弹窗
![快速审批弹窗](../../8-Reference-picture/references/form-modal/quick-approval.png)

**设计要点**:
- 宽度: 500px
- 单选按钮: 通过/驳回
- 审批意见: 文本域
- 字数限制: 200字

### 轻量创建弹窗
![轻量创建弹窗](../../8-Reference-picture/references/form-modal/quick-create.png)

**设计要点**:
- 宽度: 600px
- 字段: 标题、分类、发布时间、内容
- 标题限制: 50字
- 内容限制: 500字

---

## ✅ 设计检查清单

- [ ] 弹窗宽度是否合适(不要太宽或太窄)
- [ ] 表单是否使用垂直布局
- [ ] 必填字段是否有红色星号标识
- [ ] 是否有表单验证规则
- [ ] 提交按钮是否有loading状态
- [ ] 是否使用 `destroyOnClose` (关闭时销毁)
- [ ] 关闭时是否重置表单
- [ ] 有修改时关闭是否有二次确认
- [ ] 输入框是否有placeholder提示
- [ ] 长文本输入是否有字数限制和计数
