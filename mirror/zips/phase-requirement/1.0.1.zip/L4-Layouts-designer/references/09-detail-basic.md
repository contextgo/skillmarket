# 基础详情页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 详情页 (Basic Detail) |
| **应用场景** | 查看简单内容详情 - 核心信息展示 |
| **核心功能** | 展示单条记录的详细信息 |
| **设计目标** | 多列布局快速展示基本信息,满足基本查看需求 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑导航
- 页面标题
- 返回按钮

### 2. 侧边栏模块
- 导航菜单

### 3. 详情展示模块
- 描述列表(Descriptions)
- 字段展示

### 4. 操作模块(可选)
- 编辑按钮
- 删除按钮
- 其他操作按钮

---

## 🧩 组件层

```jsx
import { Descriptions, Card, Button, Space, Tag } from 'antd';

<Card
  title="基本信息"
  extra={
    <Space>
      <Button type="primary" icon={<EditOutlined />}>编辑</Button>
      <Button danger icon={<DeleteOutlined />}>删除</Button>
    </Space>
  }
>
  <Descriptions column={2} bordered>
    <Descriptions.Item label="标题">
      {detail.title}
    </Descriptions.Item>
    <Descriptions.Item label="分类">
      <Tag color="blue">{detail.category}</Tag>
    </Descriptions.Item>
    <Descriptions.Item label="状态">
      <Badge status={statusMap[detail.status]} text={detail.status} />
    </Descriptions.Item>
    <Descriptions.Item label="创建时间">
      {detail.createTime}
    </Descriptions.Item>
    <Descriptions.Item label="创建人">
      {detail.creator}
    </Descriptions.Item>
    <Descriptions.Item label="最后更新">
      {detail.updateTime}
    </Descriptions.Item>
    <Descriptions.Item label="描述" span={2}>
      {detail.description}
    </Descriptions.Item>
  </Descriptions>
</Card>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 标题)        [返回]       │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ Card: 基本信息   [编辑]   │  │
│  Sider    │  ├───────────────────────────┤  │
│  200px    │  │ Descriptions (2列)        │  │
│           │  │ ┌─────────┬─────────────┐ │  │
│           │  │ │标题     │分类         │ │  │
│           │  │ ├─────────┼─────────────┤ │  │
│           │  │ │状态     │创建时间     │ │  │
│           │  │ ├─────────┴─────────────┤ │  │
│           │  │ │描述 (跨2列)           │ │  │
│           │  │ └───────────────────────┘ │  │
│           │  └───────────────────────────┘  │
└───────────┴─────────────────────────────────┘
```

---

## 🎨 设计规范

### 列数配置
- 简单详情: 2列
- 字段较多: 3列
- 移动端: 1列

### Descriptions配置
```jsx
<Descriptions
  column={{ xs: 1, sm: 2, md: 2, lg: 3 }}  // 响应式列数
  bordered                                   // 带边框
  size="middle"                              // 中等尺寸
/>
```

### 字段排列
- 重要字段在前
- 长文本字段使用 `span` 跨列

---

## 🖼️ 效果图参考

![基础详情页](../../8-Reference-picture/references/detail-basic/basic-detail.png)

**设计要点**:
- 使用 Descriptions 组件
- 2列布局
- 边框分隔
- 右上角操作按钮

---

## ✅ 设计检查清单

- [ ] 是否使用 Descriptions 组件
- [ ] 列数是否响应式适配
- [ ] 长文本是否跨列显示
- [ ] 是否提供返回按钮
- [ ] 操作按钮位置是否合理
