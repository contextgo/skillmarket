# Ant Design 布局与栅格系统

## 🏗️ 布局组件

### Layout - 整体布局

**核心组件**：
- `Layout` - 布局容器
- `Layout.Header` - 顶部布局
- `Layout.Sider` - 侧边栏
- `Layout.Content` - 内容区域
- `Layout.Footer` - 底部布局

---

## 📐 标准布局模式

### 1. 经典布局（推荐）

**结构**：顶部 + 左侧导航 + 内容区

```jsx
<Layout style={{ minHeight: '100vh' }}>
  <Layout.Header style={{ 
    background: '#ffffff',
    height: 64,
    padding: '0 24px',
    boxShadow: '0 1px 4px rgba(0,0,0,0.08)'
  }}>
    顶部导航
  </Layout.Header>
  
  <Layout>
    <Layout.Sider
      width={200}
      collapsible
      style={{ background: '#ffffff' }}
    >
      侧边菜单
    </Layout.Sider>
    
    <Layout.Content style={{ 
      margin: '24px 16px',
      padding: 24,
      background: '#ffffff'
    }}>
      主内容区
    </Layout.Content>
  </Layout>
</Layout>
```

**尺寸规范**：
- Header高度：64px
- Sider宽度：200px（可折叠到80px）
- Content padding：24px
- Content margin：24px 16px

**适用场景**：
- 后台管理系统
- 数据平台
- 内容管理系统

### 2. 顶部导航布局

**结构**：顶部导航 + 内容区

```jsx
<Layout style={{ minHeight: '100vh' }}>
  <Layout.Header style={{ 
    background: '#001529',
    height: 64,
  }}>
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <div style={{ width: 200 }}>Logo</div>
      <Menu mode="horizontal" theme="dark">
        菜单项
      </Menu>
    </div>
  </Layout.Header>
  
  <Layout.Content style={{ 
    padding: '24px 48px',
    background: '#f0f2f5'
  }}>
    主内容区
  </Layout.Content>
  
  <Layout.Footer style={{ 
    textAlign: 'center',
    background: '#f0f2f5'
  }}>
    底部信息
  </Layout.Footer>
</Layout>
```

**适用场景**：
- 官网
- 门户网站
- 功能较少的系统

### 3. 侧边布局

**结构**：左侧导航 + 内容区（无顶部）

```jsx
<Layout style={{ minHeight: '100vh' }}>
  <Layout.Sider
    width={256}
    style={{ background: '#001529' }}
  >
    <div style={{ height: 64, padding: '0 24px' }}>
      Logo
    </div>
    <Menu mode="inline" theme="dark">
      菜单项
    </Menu>
  </Layout.Sider>
  
  <Layout>
    <Layout.Content style={{ 
      margin: 24,
      padding: 24,
      background: '#ffffff'
    }}>
      主内容区
    </Layout.Content>
  </Layout>
</Layout>
```

**适用场景**：
- 专注内容的应用
- 文档网站

---

## 📏 栅格系统 (Grid)

### 24栅格系统

**核心概念**：
- 一行分为24等份
- 通过`span`指定占用列数
- 支持响应式布局

### 基础用法

```jsx
import { Row, Col } from 'antd';

<Row>
  <Col span={12}>左侧 (50%)</Col>
  <Col span={12}>右侧 (50%)</Col>
</Row>

<Row>
  <Col span={8}>左侧 (33.33%)</Col>
  <Col span={8}>中间 (33.33%)</Col>
  <Col span={8}>右侧 (33.33%)</Col>
</Row>

<Row>
  <Col span={6}>侧边栏 (25%)</Col>
  <Col span={18}>主内容 (75%)</Col>
</Row>
```

### 间距 (Gutter)

**水平间距**：
```jsx
<Row gutter={16}>
  <Col span={12}>列1</Col>
  <Col span={12}>列2</Col>
</Row>
// 列间距：16px
```

**水平和垂直间距**：
```jsx
<Row gutter={[16, 16]}>
  <Col span={12}>列1</Col>
  <Col span={12}>列2</Col>
  <Col span={12}>列3</Col>
  <Col span={12}>列4</Col>
</Row>
// 水平间距：16px
// 垂直间距：16px
```

**推荐间距**：
- 小间距：`gutter={8}`
- 标准间距：`gutter={16}` （推荐）
- 大间距：`gutter={24}`

### 偏移 (Offset)

```jsx
<Row>
  <Col span={8}>列1</Col>
  <Col span={8} offset={8}>列2（偏移8格）</Col>
</Row>
```

### 排序 (Order)

```jsx
<Row>
  <Col span={6} order={4}>1 (显示在第4位)</Col>
  <Col span={6} order={3}>2 (显示在第3位)</Col>
  <Col span={6} order={2}>3 (显示在第2位)</Col>
  <Col span={6} order={1}>4 (显示在第1位)</Col>
</Row>
```

---

## 📱 响应式布局

### 响应式断点

| 断点 | 屏幕宽度 | 设备类型 | 说明 |
|-----|---------|---------|------|
| **xs** | <576px | 手机竖屏 | 超小屏 |
| **sm** | ≥576px | 手机横屏 | 小屏 |
| **md** | ≥768px | 平板 | 中屏 |
| **lg** | ≥992px | 桌面 | 大屏 |
| **xl** | ≥1200px | 大桌面 | 超大屏 |
| **xxl** | ≥1600px | 超大桌面 | 超超大屏 |

### 响应式栅格

```jsx
<Row gutter={[16, 16]}>
  <Col xs={24} sm={12} md={8} lg={6} xl={6} xxl={4}>
    响应式列1
  </Col>
  <Col xs={24} sm={12} md={8} lg={6} xl={6} xxl={4}>
    响应式列2
  </Col>
  <Col xs={24} sm={12} md={8} lg={6} xl={6} xxl={4}>
    响应式列3
  </Col>
  <Col xs={24} sm={12} md={8} lg={6} xl={6} xxl={4}>
    响应式列4
  </Col>
</Row>
```

**说明**：
- xs (手机)：每列占满屏 (24/24 = 100%)
- sm (手机横屏)：每列占一半 (12/24 = 50%)
- md (平板)：每列占1/3 (8/24 = 33.33%)
- lg (桌面)：每列占1/4 (6/24 = 25%)
- xxl (超大屏)：每列占1/6 (4/24 = 16.67%)

### 常见布局模式

#### 1. 两栏布局（主次分明）

```jsx
<Row gutter={16}>
  <Col xs={24} lg={6}>
    侧边栏
  </Col>
  <Col xs={24} lg={18}>
    主内容
  </Col>
</Row>
```

**移动端**：上下布局（侧边栏在上）
**桌面端**：左右布局（侧边栏在左）

#### 2. 三栏布局

```jsx
<Row gutter={[16, 16]}>
  <Col xs={24} sm={12} md={8}>
    列1
  </Col>
  <Col xs={24} sm={12} md={8}>
    列2
  </Col>
  <Col xs={24} sm={24} md={8}>
    列3
  </Col>
</Row>
```

**手机竖屏**：单列
**手机横屏/平板**：两列
**桌面**：三列

#### 3. 卡片网格布局

```jsx
<Row gutter={[16, 16]}>
  {data.map((item) => (
    <Col 
      key={item.id}
      xs={24}
      sm={12}
      md={8}
      lg={6}
      xl={6}
      xxl={4}
    >
      <Card>
        {item.content}
      </Card>
    </Col>
  ))}
</Row>
```

**响应式显示**：
- 手机：1列
- 手机横屏：2列
- 平板：3列
- 桌面：4列
- 超大屏：6列

---

## 📦 容器宽度

### 标准容器宽度

| 断点 | 容器宽度 | 左右边距 |
|-----|---------|---------|
| xs | 100% | 16px |
| sm | 540px | 自动居中 |
| md | 720px | 自动居中 |
| lg | 960px | 自动居中 |
| xl | 1140px | 自动居中 |
| xxl | 1320px | 自动居中 |

### 实现方式

```jsx
<div style={{
  maxWidth: 1200,
  margin: '0 auto',
  padding: '0 24px',
}}>
  内容区域
</div>
```

### 全宽布局

```jsx
<div style={{
  width: '100%',
  padding: '0 48px',
}}>
  全宽内容
</div>
```

---

## 🎯 布局规范

### 1. 页面边距

**标准边距**：24px

```jsx
<Layout.Content style={{ padding: 24 }}>
  主内容
</Layout.Content>
```

**不同屏幕边距**：

```jsx
<div style={{
  padding: window.innerWidth < 768 ? 16 : 24
}}>
  内容
</div>
```

### 2. 卡片间距

**标准间距**：16px

```jsx
<Row gutter={[16, 16]}>
  <Col span={12}>
    <Card>卡片1</Card>
  </Col>
  <Col span={12}>
    <Card>卡片2</Card>
  </Col>
</Row>
```

### 3. 模块间距

**标准间距**：24px

```jsx
<div style={{ marginBottom: 24 }}>
  <Card title="模块1">内容1</Card>
</div>

<div style={{ marginBottom: 24 }}>
  <Card title="模块2">内容2</Card>
</div>
```

### 4. 内容区域内边距

**标准内边距**：24px

```jsx
<Card bodyStyle={{ padding: 24 }}>
  卡片内容
</Card>
```

**紧凑模式**：16px

```jsx
<Card bodyStyle={{ padding: 16 }}>
  卡片内容（紧凑）
</Card>
```

---

## 🔧 实用布局模式

### 1. Sticky头部

```jsx
<Layout.Header style={{
  position: 'sticky',
  top: 0,
  zIndex: 1,
  width: '100%',
  background: '#ffffff',
  boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
}}>
  Sticky Header
</Layout.Header>
```

### 2. 固定侧边栏

```jsx
<Layout.Sider
  style={{
    overflow: 'auto',
    height: '100vh',
    position: 'fixed',
    left: 0,
    top: 0,
    bottom: 0,
  }}
>
  固定侧边栏
</Layout.Sider>

<Layout style={{ marginLeft: 200 }}>
  <Layout.Content>
    主内容（滚动）
  </Layout.Content>
</Layout>
```

### 3. 居中容器

```jsx
// 水平居中
<div style={{
  maxWidth: 1200,
  margin: '0 auto',
  padding: '0 24px',
}}>
  内容
</div>

// 垂直水平居中
<div style={{
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh',
}}>
  内容
</div>
```

### 4. 两端对齐

```jsx
<div style={{
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}}>
  <div>左侧内容</div>
  <div>右侧内容</div>
</div>
```

### 5. 等高列

```jsx
<Row gutter={16} style={{ display: 'flex' }}>
  <Col span={12} style={{ display: 'flex' }}>
    <Card style={{ width: '100%' }}>
      内容1
    </Card>
  </Col>
  <Col span={12} style={{ display: 'flex' }}>
    <Card style={{ width: '100%' }}>
      内容2（等高）
    </Card>
  </Col>
</Row>
```

---

## 📐 Flex布局

### 基础用法

```jsx
<div style={{ display: 'flex' }}>
  <div>项目1</div>
  <div>项目2</div>
  <div>项目3</div>
</div>
```

### 对齐方式

**水平对齐**：
```jsx
// 左对齐（默认）
<div style={{ display: 'flex', justifyContent: 'flex-start' }}>

// 居中对齐
<div style={{ display: 'flex', justifyContent: 'center' }}>

// 右对齐
<div style={{ display: 'flex', justifyContent: 'flex-end' }}>

// 两端对齐
<div style={{ display: 'flex', justifyContent: 'space-between' }}>

// 分散对齐
<div style={{ display: 'flex', justifyContent: 'space-around' }}>
```

**垂直对齐**：
```jsx
// 顶部对齐（默认）
<div style={{ display: 'flex', alignItems: 'flex-start' }}>

// 居中对齐
<div style={{ display: 'flex', alignItems: 'center' }}>

// 底部对齐
<div style={{ display: 'flex', alignItems: 'flex-end' }}>

// 拉伸（等高）
<div style={{ display: 'flex', alignItems: 'stretch' }}>
```

### 方向

```jsx
// 水平（默认）
<div style={{ display: 'flex', flexDirection: 'row' }}>

// 垂直
<div style={{ display: 'flex', flexDirection: 'column' }}>

// 水平反向
<div style={{ display: 'flex', flexDirection: 'row-reverse' }}>

// 垂直反向
<div style={{ display: 'flex', flexDirection: 'column-reverse' }}>
```

### 换行

```jsx
// 不换行（默认）
<div style={{ display: 'flex', flexWrap: 'nowrap' }}>

// 换行
<div style={{ display: 'flex', flexWrap: 'wrap' }}>
```

### Space组件（推荐）

```jsx
// 水平排列
<Space>
  <Button>按钮1</Button>
  <Button>按钮2</Button>
  <Button>按钮3</Button>
</Space>

// 垂直排列
<Space direction="vertical" style={{ width: '100%' }}>
  <Card>卡片1</Card>
  <Card>卡片2</Card>
</Space>

// 自定义间距
<Space size={24}>
  <Button>按钮1</Button>
  <Button>按钮2</Button>
</Space>
```

---

## 💡 最佳实践

### 1. 移动端优先

```jsx
// ✅ 推荐：从小屏开始
<Col xs={24} md={12} lg={8}>

// ❌ 不推荐：从大屏开始
<Col lg={8} md={12} xs={24}>
```

### 2. 使用gutter而非margin

```jsx
// ✅ 推荐
<Row gutter={16}>
  <Col span={12}>内容1</Col>
  <Col span={12}>内容2</Col>
</Row>

// ❌ 不推荐
<Row>
  <Col span={12} style={{ paddingRight: 8 }}>内容1</Col>
  <Col span={12} style={{ paddingLeft: 8 }}>内容2</Col>
</Row>
```

### 3. 保持间距一致

```jsx
// 全局统一使用16px或24px
<Row gutter={16}>      // 卡片间距
<Space size={16}>      // 按钮间距
<div style={{ marginBottom: 16 }}>  // 模块间距
```

### 4. 响应式隐藏

```jsx
// 小屏隐藏
<Col xs={0} md={8}>
  侧边栏（移动端隐藏）
</Col>

// 或使用CSS
<div style={{ 
  display: window.innerWidth < 768 ? 'none' : 'block'
}}>
  桌面端内容
</div>
```

---

## ✅ 布局检查清单

### 整体布局
- [ ] 是否选择了合适的布局模式？
- [ ] Header高度是否为64px？
- [ ] Sider宽度是否合理（推荐200px）？
- [ ] Content padding是否为24px？

### 栅格系统
- [ ] 是否使用了24栅格系统？
- [ ] gutter是否统一（推荐16px）？
- [ ] 响应式断点是否合理？
- [ ] 移动端是否友好？

### 间距
- [ ] 页面边距是否统一？
- [ ] 卡片间距是否一致？
- [ ] 模块间距是否合理？
- [ ] 是否避免了过于拥挤？

### 响应式
- [ ] 是否考虑了所有断点？
- [ ] 移动端是否可用？
- [ ] 平板端是否正常？
- [ ] 是否有内容溢出？

---

**文档版本**: v1.0  
**更新时间**: 2026-01-16  
**基于**: Ant Design 5.x Layout & Grid System
