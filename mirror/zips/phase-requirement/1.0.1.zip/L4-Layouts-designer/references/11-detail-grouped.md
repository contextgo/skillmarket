# 分组详情页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 详情页 (Grouped Detail) |
| **应用场景** | 对比查看多维度内容数据 |
| **核心功能** | 标签页切换不同维度信息 |
| **设计目标** | 选项卡切换不同分组,利于数据对比分析 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑
- 标题

### 2. 侧边栏模块
- 导航菜单

### 3. 详情展示模块
- 顶部基本信息(固定展示)

### 4. 导航标签模块
- Tabs标签页
- 每个标签展示不同维度信息

### 5. 信息分组模块
- 基本信息标签
- 内容信息标签
- 操作记录标签

---

## 🧩 组件层

```jsx
<Space direction="vertical" size="large" style={{ width: '100%' }}>
  {/* 顶部基本信息 */}
  <Card>
    <Descriptions column={3}>
      <Descriptions.Item label="标题">{detail.title}</Descriptions.Item>
      <Descriptions.Item label="状态">{detail.status}</Descriptions.Item>
      <Descriptions.Item label="创建时间">{detail.createTime}</Descriptions.Item>
    </Descriptions>
  </Card>

  {/* 标签页详情 */}
  <Card>
    <Tabs
      items={[
        {
          key: 'basic',
          label: '基本信息',
          children: (
            <Descriptions column={2} bordered>
              <Descriptions.Item label="分类">{detail.category}</Descriptions.Item>
              <Descriptions.Item label="作者">{detail.author}</Descriptions.Item>
              <Descriptions.Item label="标签" span={2}>
                {detail.tags.map(tag => <Tag key={tag}>{tag}</Tag>)}
              </Descriptions.Item>
            </Descriptions>
          ),
        },
        {
          key: 'content',
          label: '内容信息',
          children: (
            <div dangerouslySetInnerHTML={{ __html: detail.content }} />
          ),
        },
        {
          key: 'logs',
          label: '操作记录',
          children: (
            <Table
              dataSource={detail.logs}
              columns={logColumns}
              pagination={false}
            />
          ),
        },
      ]}
    />
  </Card>
</Space>
```

---

## 📐 布局层

```
┌─────────────────────────────────────────────┐
│  Header (面包屑 + 标题)                     │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ Card: 顶部基本信息(固定) │  │
│  Sider    │  │ Descriptions (3列)        │  │
│  200px    │  └───────────────────────────┘  │
│           │  ┌───────────────────────────┐  │
│           │  │ Card                      │  │
│           │  │ [基本][内容][记录] Tabs   │  │
│           │  ├───────────────────────────┤  │
│           │  │ 当前标签的详情内容        │  │
│           │  │                           │  │
│           │  └───────────────────────────┘  │
└───────────┴─────────────────────────────────┘
```

---

## 🖼️ 效果图参考

![分组详情页](../../8-Reference-picture/references/detail-grouped/grouped-detail.png)

**设计要点**:
- 顶部固定核心信息
- 标签页切换不同维度
- 适合信息量大的场景

---

## ✅ 设计检查清单

- [ ] 顶部是否展示核心信息
- [ ] 标签分类是否清晰合理
- [ ] 标签数量是否适中(3-6个)
- [ ] 切换标签是否流畅
- [ ] 是否有默认打开的标签
