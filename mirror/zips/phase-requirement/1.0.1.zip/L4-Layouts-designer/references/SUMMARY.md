# 页面设计参考知识库汇总

> 基于"内容管理类系统-效果图汇总.docx"整理的完整页面设计参考

---

## 📊 页面类型统计

| 页面类型 | 数量 | 参考文档 |
|---------|-----|---------|
| Dashboard | 1 | 01_dashboard.md |
| 列表页 | 3 | 02_list_table.md, 03_list_card.md, 04_list_message.md |
| 表单页 | 4 | 05_form_modal.md, 06_form_standard.md, 07_form_steps.md, 08_form_tabs.md |
| 详情页 | 4 | 09_detail_basic.md, 10_detail_complete.md, 11_detail_grouped.md, 12_detail_drawer.md |
| 结果页 | 1 | 13_result.md |
| 特殊页面 | 1 | 14_notification.md |
| **合计** | **14** | - |

---

## 🗂️ 按业务模块分类

### 1. 系统概览层 (1个页面)

#### 1.1 控制台首页
- **页面类型**: Dashboard
- **参考文档**: [01_dashboard.md](./01-dashboard.md)
- **核心功能**: 数据统计、快捷入口、内容列表
- **Ant Design组件**: Card, Statistic, Table, Button, Row/Col
- **效果图**: `assets/dashboard/console_overview.png`

---

### 2. 权限管理层 (5个页面)

#### 2.1 角色管理
- **页面类型**: 列表页(表格视图)
- **参考文档**: [02_list_table.md](./02-list-table.md)
- **核心功能**: 角色列表展示、筛选、操作
- **Ant Design组件**: Table, Input.Search, Select, Button
- **效果图**: `assets/list_table/role_list.png`

#### 2.2 权限配置
- **页面类型**: 弹窗表单
- **参考文档**: [05_form_modal.md](./05-form-modal.md)
- **核心功能**: 为角色分配权限(树形选择)
- **Ant Design组件**: Modal, Form, Tree, Checkbox
- **效果图**: `assets/form_modal/permission_config.png`

#### 2.3 用户分配
- **页面类型**: 弹窗表单
- **参考文档**: [05_form_modal.md](./05-form-modal.md)
- **核心功能**: 为角色分配用户(穿梭框)
- **Ant Design组件**: Modal, Transfer
- **效果图**: `assets/form_modal/user_assign.png`

#### 2.4 用户管理
- **页面类型**: 列表页(表格视图)
- **参考文档**: [02_list_table.md](./02-list-table.md)
- **核心功能**: 用户列表展示、筛选、操作
- **Ant Design组件**: Table, Input.Search, Select, Button
- **效果图**: `assets/list_table/user_list.png`

#### 2.5 用户编辑
- **页面类型**: 弹窗表单
- **参考文档**: [05_form_modal.md](./05-form-modal.md)
- **核心功能**: 编辑用户信息
- **Ant Design组件**: Modal, Form, Input, Select, Switch
- **效果图**: `assets/form_modal/user_edit.png`

---

### 3. 流程中心 (7个页面)

#### 3.1 流程总览 - 表格视图
- **页面类型**: 列表页(表格视图)
- **参考文档**: [02_list_table.md](./02-list-table.md)
- **核心功能**: 高密度展示流程数据
- **Ant Design组件**: Table, Input.Search, Select, DatePicker, Tag
- **效果图**: `assets/list_table/workflow_list.png`

#### 3.2 流程总览 - 卡片视图
- **页面类型**: 列表页(卡片视图)
- **参考文档**: [03_list_card.md](./03-list-card.md)
- **核心功能**: 可视化展示流程信息
- **Ant Design组件**: Card, Row/Col, Tag, Dropdown
- **效果图**: `assets/list_card/workflow_card.png`

#### 3.3 快速审批
- **页面类型**: 弹窗表单
- **参考文档**: [05_form_modal.md](./05-form-modal.md)
- **核心功能**: 快速处理审批任务
- **Ant Design组件**: Modal, Form, Radio, Input.TextArea
- **效果图**: `assets/form_modal/quick_approval.png`

#### 3.4 完整审批
- **页面类型**: 抽屉详情
- **参考文档**: [12_detail_drawer.md](./12-detail-drawer.md)
- **核心功能**: 查看详细流程节点和处理
- **Ant Design组件**: Drawer, Descriptions, Steps, Form
- **效果图**: `assets/detail_drawer/drawer_detail.png`

#### 3.5 审批详情
- **页面类型**: 详情页(完整页面)
- **参考文档**: [09_detail_basic.md](./09-detail-basic.md)
- **核心功能**: 完整页面展示审批详情
- **Ant Design组件**: Card, Descriptions, Steps
- **效果图**: `assets/detail_basic/basic_detail.png`

#### 3.6 审批成功状态
- **页面类型**: 结果页
- **参考文档**: [13_result.md](./13-result.md)
- **核心功能**: 审批成功反馈
- **Ant Design组件**: Result (status="success")
- **效果图**: `assets/result/success.png`

#### 3.7 审批失败状态
- **页面类型**: 结果页
- **参考文档**: [13_result.md](./13-result.md)
- **核心功能**: 审批失败反馈
- **Ant Design组件**: Result (status="error")
- **效果图**: `assets/result/error.png`

---

### 4. 内容中心 (11个页面)

#### 4.1 内容库 - 表格视图
- **页面类型**: 列表页(表格视图)
- **参考文档**: [02_list_table.md](./02-list-table.md)
- **核心功能**: 结构化数据管理
- **Ant Design组件**: Table, Input.Search, Select, DatePicker
- **效果图**: `assets/list_table/content_list.png`

#### 4.2 内容库 - 卡片视图
- **页面类型**: 列表页(卡片视图)
- **参考文档**: [03_list_card.md](./03-list-card.md)
- **核心功能**: 内容预览
- **Ant Design组件**: Card, Row/Col, Image, Tag
- **效果图**: `assets/list_card/content_card.png`

#### 4.3 轻量创建
- **页面类型**: 弹窗表单
- **参考文档**: [05_form_modal.md](./05-form-modal.md)
- **核心功能**: 快速创建简单内容
- **Ant Design组件**: Modal, Form, Input, Select, DatePicker
- **效果图**: `assets/form_modal/quick_create.png`

#### 4.4 标准创建
- **页面类型**: 标准表单页
- **参考文档**: [06_form_standard.md](./06-form-standard.md)
- **核心功能**: 创建常规内容
- **Ant Design组件**: Form, Input, Select, DatePicker, Radio
- **效果图**: `assets/form_standard/standard_create.png`

#### 4.5 高级创建
- **页面类型**: 分步表单页
- **参考文档**: [07_form_steps.md](./07-form-steps.md)
- **核心功能**: 分步骤创建复杂内容
- **Ant Design组件**: Steps, Form, Button
- **效果图**: `assets/form_steps/step_form.png`

#### 4.6 专业创建
- **页面类型**: 多标签表单页
- **参考文档**: [08_form_tabs.md](./08-form-tabs.md)
- **核心功能**: 多标签分类创建
- **Ant Design组件**: Tabs, Form, Card
- **效果图**: `assets/form_tabs/tabs_form.png`

#### 4.7 基础详情
- **页面类型**: 基础详情页
- **参考文档**: [09_detail_basic.md](./09-detail-basic.md)
- **核心功能**: 查看核心信息
- **Ant Design组件**: Card, Descriptions, Button
- **效果图**: `assets/detail_basic/basic_detail.png`

#### 4.8 完整详情
- **页面类型**: 完整详情页
- **参考文档**: [10_detail_complete.md](./10-detail-complete.md)
- **核心功能**: 多模块展示完整信息
- **Ant Design组件**: Card, Descriptions, Table
- **效果图**: `assets/detail_complete/complete_detail.png`

#### 4.9 分组详情
- **页面类型**: 分组详情页
- **参考文档**: [11_detail_grouped.md](./11-detail-grouped.md)
- **核心功能**: 标签页切换多维度数据
- **Ant Design组件**: Tabs, Descriptions, Table
- **效果图**: `assets/detail_grouped/grouped_detail.png`

#### 4.10 操作结果 - 成功
- **页面类型**: 结果页
- **参考文档**: [13_result.md](./13-result.md)
- **核心功能**: 操作成功反馈
- **Ant Design组件**: Result (status="success")
- **效果图**: `assets/result/success.png`

#### 4.11 操作结果 - 失败
- **页面类型**: 结果页
- **参考文档**: [13_result.md](./13-result.md)
- **核心功能**: 操作失败反馈
- **Ant Design组件**: Result (status="error")
- **效果图**: `assets/result/error.png`

---

### 5. 通知系统 (2个页面)

#### 5.1 实时通知
- **页面类型**: 浮窗
- **参考文档**: [14_notification.md](./14-notification.md)
- **核心功能**: 实时推送通知
- **Ant Design组件**: Popover, Badge, List, Button
- **效果图**: `assets/notification/notification_popover.png`

#### 5.2 消息中心
- **页面类型**: 列表页(消息列表)
- **参考文档**: [04_list_message.md](./04-list-message.md)
- **核心功能**: 集中展示历史消息
- **Ant Design组件**: List, Badge, Avatar, Tag, Pagination
- **效果图**: `assets/list_message/message_list.png`

---

## 🧩 Ant Design组件使用频率统计

| 组件 | 使用次数 | 主要应用场景 |
|-----|---------|-------------|
| **Card** | 14 | 容器、分组 |
| **Button** | 14 | 操作按钮 |
| **Form** | 9 | 表单输入 |
| **Table** | 5 | 数据列表 |
| **Descriptions** | 5 | 详情展示 |
| **Input** | 8 | 文本输入、搜索 |
| **Select** | 7 | 下拉选择 |
| **Modal** | 5 | 弹窗 |
| **Tag** | 7 | 标签标识 |
| **Steps** | 3 | 流程步骤 |
| **Tabs** | 2 | 标签切换 |
| **Result** | 2 | 结果反馈 |
| **List** | 2 | 列表展示 |
| **Drawer** | 1 | 抽屉详情 |
| **Popover** | 1 | 浮窗 |

---

## 📐 设计规范汇总

### 布局规范
- **侧边栏宽度**: 240px (FTdesign 规范)
- **主内容区padding**: 24px
- **卡片间距**: 16px
- **模块间距**: 24px

### 组件规范
- **按钮高度**: 32px
- **输入框高度**: 32px
- **表格行高**: 48px
- **表单项间距**: 24px

### 响应式断点
| 屏幕尺寸 | 宽度范围 | 布局方式 |
|---------|---------|---------|
| **xs** | <576px | 单列布局 |
| **sm** | 576-768px | 单列/双列 |
| **md** | 768-992px | 双列/三列 |
| **lg** | 992-1200px | 三列/四列 |
| **xl** | 1200-1600px | 四列 |
| **xxl** | >1600px | 六列 |

---

## 🎯 快速查找指南

### 按功能查找

| 功能需求 | 推荐页面类型 | 参考文档 |
|---------|------------|---------|
| 展示数据列表 | 表格视图列表页 | 02_list_table.md |
| 内容预览展示 | 卡片视图列表页 | 03_list_card.md |
| 快速创建/编辑 | 弹窗表单 | 05_form_modal.md |
| 标准创建 | 标准表单页 | 06_form_standard.md |
| 复杂创建 | 分步表单 | 07_form_steps.md |
| 多类型数据创建 | 多标签表单 | 08_form_tabs.md |
| 查看详情 | 基础详情页 | 09_detail_basic.md |
| 完整信息展示 | 完整详情页 | 10_detail_complete.md |
| 多维度数据对比 | 分组详情页 | 11_detail_grouped.md |
| 快速查看详情 | 抽屉详情 | 12_detail_drawer.md |
| 操作反馈 | 结果页 | 13_result.md |
| 实时通知 | 通知浮窗 | 14_notification.md |

---

## ✅ 知识库使用流程

### 第一步:识别需求
根据PRD文档,识别页面类型和功能需求。

### 第二步:查找参考
在本汇总文档中,根据业务模块或功能需求找到对应的参考文档。

### 第三步:查看详情
打开参考文档,查看:
- 模块层结构
- Ant Design组件使用
- 布局结构
- 设计规范
- 效果图参考

### 第四步:生成设计方案
参考知识库内容,结合实际需求,生成具体的设计方案。

---

## 📝 更新日志

- **2026-01-16**: 初始化知识库,包含14个页面类型参考文档
