# 卡片视图列表页

## 📋 页面信息

| 属性 | 说明 |
|-----|------|
| **页面类型** | 列表页 (Card View) |
| **应用场景** | 流程总览(卡片模式)、内容库(内容预览) |
| **核心功能** | 可视化展示内容,强调视觉效果和内容预览 |
| **设计目标** | 突出可视化效果,灵活布局,适配移动设备,利于直观了解内容 |

---

## 🏗️ 模块层

### 1. 页头模块
- 面包屑导航
- 页面标题
- 视图切换按钮 (表格/卡片)

### 2. 侧边栏模块
- 导航菜单 (固定宽度: 200px)

### 3. 筛选模块
- 搜索框
- 下拉筛选
- 视图切换 (Table/Card)

### 4. 操作模块
- 新建按钮
- 其他操作按钮

### 5. 数据展示模块
- 卡片网格布局 (Card Grid)
- 卡片内容 (封面图、标题、描述、标签、操作)

### 6. 分页模块
- 分页器
- 总数显示

---

## 🧩 组件层 (Ant Design)

### 核心组件

```jsx
import {
  Card,             // 卡片
  Row, Col,         // 栅格布局
  Input,            // 输入框
  Select,           // 下拉选择
  Button,           // 按钮
  Tag,              // 标签
  Badge,            // 徽标
  Space,            // 间距
  Pagination,       // 分页
  Image,            // 图片
  Dropdown,         // 下拉菜单
  Menu,             // 菜单
  SegmentedControl, // 分段控制器(视图切换)
} from 'antd';
```

### 使用示例

#### 视图切换
```jsx
<Space size="middle" style={{ marginBottom: 16 }}>
  <Input.Search 
    placeholder="搜索" 
    style={{ width: 280 }}
  />
  <Select
    placeholder="选择分类"
    options={categoryOptions}
    style={{ width: 200 }}
  />
  <Segmented
    options={[
      { label: '表格', value: 'table', icon: <TableOutlined /> },
      { label: '卡片', value: 'card', icon: <AppstoreOutlined /> },
    ]}
    value={viewMode}
    onChange={setViewMode}
  />
</Space>
```

#### 卡片网格布局
```jsx
<Row gutter={[16, 16]}>
  {dataSource.map((item) => (
    <Col xs={24} sm={12} md={8} lg={6} xl={6} key={item.id}>
      <Card
        hoverable
        cover={
          <Image
            alt={item.title}
            src={item.cover}
            height={180}
            style={{ objectFit: 'cover' }}
          />
        }
        actions={[
          <EyeOutlined key="view" onClick={() => handleView(item)} />,
          <EditOutlined key="edit" onClick={() => handleEdit(item)} />,
          <DeleteOutlined 
            key="delete" 
            onClick={() => handleDelete(item)}
            style={{ color: '#ff4d4f' }}
          />,
        ]}
      >
        <Card.Meta
          title={
            <div style={{ 
              overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              whiteSpace: 'nowrap' 
            }}>
              {item.title}
            </div>
          }
          description={
            <>
              <div style={{
                height: 40,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                marginBottom: 8,
              }}>
                {item.description}
              </div>
              <Space size={[0, 8]} wrap>
                <Tag color={item.statusColor}>{item.status}</Tag>
                <Tag>{item.category}</Tag>
              </Space>
              <div style={{ marginTop: 8, color: '#999', fontSize: 12 }}>
                {item.createTime}
              </div>
            </>
          }
        />
      </Card>
    </Col>
  ))}
</Row>

<Pagination
  current={page}
  pageSize={pageSize}
  total={total}
  showTotal={(total) => `共 ${total} 条`}
  onChange={handlePageChange}
  style={{ marginTop: 24, textAlign: 'right' }}
/>
```

#### 无封面图的卡片 (流程总览)
```jsx
<Row gutter={[16, 16]}>
  {dataSource.map((item) => (
    <Col xs={24} sm={12} md={8} lg={6} key={item.id}>
      <Card
        hoverable
        extra={
          <Dropdown menu={{ items: menuItems }}>
            <MoreOutlined />
          </Dropdown>
        }
      >
        <Space direction="vertical" size="small" style={{ width: '100%' }}>
          <div style={{ fontSize: 16, fontWeight: 600 }}>
            {item.title}
          </div>
          <div style={{ color: '#999' }}>
            发起人: {item.creator}
          </div>
          <div style={{ color: '#999' }}>
            当前节点: {item.currentNode}
          </div>
          <div>
            <Tag color={item.statusColor}>{item.status}</Tag>
          </div>
          <div style={{ color: '#999', fontSize: 12 }}>
            {item.createTime}
          </div>
        </Space>
      </Card>
    </Col>
  ))}
</Row>
```

---

## 📐 布局层

### 整体布局结构

```
┌─────────────────────────────────────────────┐
│  Header (页头: 面包屑 + 标题)               │
├───────────┬─────────────────────────────────┤
│           │  ┌───────────────────────────┐  │
│           │  │ 筛选区域 + 视图切换       │  │
│           │  └───────────────────────────┘  │
│  侧边栏   │  ┌───────────────────────────┐  │
│  Sider    │  │ 操作区域 (新建按钮等)     │  │
│  200px    │  └───────────────────────────┘  │
│           │  ┌─────┬─────┬─────┬─────┐    │
│           │  │Card │Card │Card │Card │    │
│           │  ├─────┼─────┼─────┼─────┤    │
│           │  │Card │Card │Card │Card │    │
│           │  └─────┴─────┴─────┴─────┘    │
│           │  ┌───────────────────────────┐  │
│           │  │ 分页器                    │  │
│           │  └───────────────────────────┘  │
└───────────┴─────────────────────────────────┘
```

### 响应式设计

| 屏幕尺寸 | 每行卡片数 | Col配置 |
|---------|----------|---------|
| **超大屏 (>1600px)** | 6列 | `<Col xxl={4}>` |
| **大屏 (1200-1600px)** | 4列 | `<Col xl={6}>` |
| **中屏 (992-1200px)** | 3列 | `<Col lg={8}>` |
| **平板 (768-992px)** | 2列 | `<Col md={12}>` |
| **手机 (<768px)** | 1列 | `<Col xs={24}>` |

### 卡片间距
- 水平间距: 16px
- 垂直间距: 16px
- 使用 `gutter={[16, 16]}`

---

## 🎨 设计规范

### 尺寸规范
- **卡片宽度**: 自适应 (由栅格系统控制)
- **封面图高度**: 180px
- **卡片内边距**: 16px
- **卡片圆角**: 8px
- **卡片阴影**: `box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03)`

### 内容规范
- **标题**: 单行显示,超出显示省略号
- **描述**: 2行显示,超出显示省略号
- **标签**: 最多显示3个
- **日期格式**: YYYY-MM-DD HH:mm

### 颜色规范
- **卡片背景**: #ffffff
- **hover状态**: `box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09)`
- **边框**: #f0f0f0

### 字体规范
- **卡片标题**: 16px / font-weight: 600
- **描述文字**: 14px / font-weight: 400
- **辅助信息**: 12px / color: #999

---

## 🎯 交互状态

### 1. 空状态
```jsx
{dataSource.length === 0 ? (
  <Empty
    description="暂无内容"
    image={Empty.PRESENTED_IMAGE_SIMPLE}
    style={{ marginTop: 60 }}
  >
    <Button type="primary" icon={<PlusOutlined />}>
      新建内容
    </Button>
  </Empty>
) : (
  <Row gutter={[16, 16]}>
    {/* 卡片列表 */}
  </Row>
)}
```

### 2. 加载状态
```jsx
<Row gutter={[16, 16]}>
  {loading ? (
    Array(8).fill(null).map((_, index) => (
      <Col xs={24} sm={12} md={8} lg={6} key={index}>
        <Card loading />
      </Col>
    ))
  ) : (
    dataSource.map((item) => (
      <Col xs={24} sm={12} md={8} lg={6} key={item.id}>
        <Card>{/* 卡片内容 */}</Card>
      </Col>
    ))
  )}
</Row>
```

### 3. hover交互
- 卡片整体hover: 阴影加深,轻微上移
- 底部操作图标hover: 颜色变化

---

## 🖼️ 效果图参考

> 效果图路径: `references/assets/list_card/`

### 流程总览(卡片视图)
![流程总览卡片视图](../../8-Reference-picture/references/list-card/workflow-card.png)

**设计要点**:
- 无封面图,强调文本信息
- 显示: 标题、发起人、当前节点、状态、时间
- 右上角下拉菜单提供操作入口
- 状态使用不同颜色的Tag标识

### 内容库(卡片视图)
![内容库卡片视图](../../8-Reference-picture/references/list-card/content-card.png)

**设计要点**:
- 顶部封面图 (高度180px)
- 标题单行显示
- 描述2行显示
- 底部标签和时间
- 底部操作栏: 查看、编辑、删除

---

## ✅ 设计检查清单

- [ ] 是否提供表格/卡片视图切换
- [ ] 卡片是否有hover效果
- [ ] 标题和描述是否有文本溢出处理
- [ ] 是否适配不同屏幕尺寸 (响应式)
- [ ] 封面图是否有加载失败处理
- [ ] 空状态是否有引导操作
- [ ] 加载状态是否使用骨架屏
- [ ] 删除操作是否有二次确认
- [ ] 卡片操作是否易于点击 (移动端)
- [ ] 分页器是否在合适位置
