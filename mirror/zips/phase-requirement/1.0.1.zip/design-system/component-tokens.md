# 组件库令牌系统 (Component Tokens)

> 用于设计方案与前端开发之间的组件标准化通信
>
> **技术栈说明**：令牌映射到**纯 HTML + CSS（FTdesign 原生类名）+ Font Awesome 6.4.0**，零框架依赖

## 令牌格式

```
[组件类别]::[组件名称]::[变体/配置]
```

## 类别速查表

| 前缀 | 类别 | 说明 |
|------|------|------|
| `GEN::` | General | 通用组件 |
| `LAY::` | Layout | 布局组件 |
| `NAV::` | Navigation | 导航组件 |
| `ENT::` | Entry | 数据录入 |
| `DISP::` | Display | 数据展示 |
| `FB::` | Feedback | 反馈组件 |

---

## 一、通用组件 (GEN)

### Button 按钮

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `GEN::Button::primary` | 主按钮 | `ft-btn ft-btn-primary` |
| `GEN::Button::default` | 默认按钮 | `ft-btn ft-btn-default` |
| `GEN::Button::danger` | 危险按钮 | `ft-btn ft-btn-danger` |
| `GEN::Button::ghost` | 幽灵按钮 | `ft-btn ft-btn-ghost` |
| `GEN::Button::text` | 文字按钮 | `ft-btn ft-btn-text` |
| `GEN::Button::link` | 链接按钮 | `ft-link-btn` |
| `GEN::Button::link-danger` | 危险链接按钮 | `ft-link-btn ft-link-danger` |
| `GEN::Button::loading` | 加载中按钮 | `ft-btn ft-btn-primary ft-btn-loading` |
| `GEN::Button::primary::sm` | 小号主按钮（高24px） | `ft-btn ft-btn-primary ft-btn-sm` |
| `GEN::Button::primary::lg` | 大号主按钮（高40px） | `ft-btn ft-btn-primary ft-btn-lg` |
| `GEN::Button::group` | 按钮组 | `ft-btn-group` |

### Tag 状态标签

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `GEN::Tag::success` | 成功/启用 | `ft-tag ft-tag-success` |
| `GEN::Tag::warning` | 警告/待处理 | `ft-tag ft-tag-warning` |
| `GEN::Tag::error` | 错误/禁用 | `ft-tag ft-tag-error` |
| `GEN::Tag::info` | 信息/进行中 | `ft-tag ft-tag-info` |
| `GEN::Tag::default` | 默认/草稿 | `ft-tag ft-tag-default` |

### Avatar 头像

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `GEN::Avatar::text` | 文字头像 | `ft-avatar` |
| `GEN::Avatar::image` | 图片头像 | `ft-avatar`（内含 `<img>`） |
| `GEN::Avatar::sm` | 小头像 | `ft-avatar ft-avatar-sm` |
| `GEN::Avatar::lg` | 大头像 | `ft-avatar ft-avatar-lg` |
| `GEN::Avatar::group` | 头像组 | `ft-avatar-group` |

### Badge 徽标

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `GEN::Badge::count` | 数字徽标 | `ft-badge-count` |
| `GEN::Badge::dot` | 点状徽标 | `ft-badge-dot` |
| `GEN::Badge::status-success` | 成功状态圆点 | `ft-badge-status ft-badge-status-success` |
| `GEN::Badge::status-warning` | 警告状态圆点 | `ft-badge-status ft-badge-status-warning` |
| `GEN::Badge::status-error` | 错误状态圆点 | `ft-badge-status ft-badge-status-error` |
| `GEN::Badge::status-default` | 停止状态圆点 | `ft-badge-status ft-badge-status-default` |

### Divider 分割线

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `GEN::Divider::horizontal` | 水平分割线 | `ft-divider` |
| `GEN::Divider::vertical` | 垂直分割线 | `ft-divider-v` |

### Icon 图标

| 令牌 | 说明 | Font Awesome 类名 |
|------|------|----------------|
| `GEN::Icon::plus` | 添加 | `fa-solid fa-plus` |
| `GEN::Icon::edit` | 编辑 | `fa-solid fa-pen-to-square` |
| `GEN::Icon::delete` | 删除 | `fa-solid fa-trash-can` |
| `GEN::Icon::search` | 搜索 | `fa-solid fa-magnifying-glass` |
| `GEN::Icon::download` | 下载 | `fa-solid fa-download` |
| `GEN::Icon::upload` | 上传 | `fa-solid fa-upload` |
| `GEN::Icon::filter` | 筛选 | `fa-solid fa-filter` |
| `GEN::Icon::refresh` | 刷新 | `fa-solid fa-rotate` |
| `GEN::Icon::more` | 更多 | `fa-solid fa-ellipsis` |
| `GEN::Icon::arrow-down` | 向下箭头 | `fa-solid fa-chevron-down` |
| `GEN::Icon::arrow-up` | 向上箭头 | `fa-solid fa-chevron-up` |
| `GEN::Icon::arrow-left` | 向左箭头 | `fa-solid fa-chevron-left` |
| `GEN::Icon::arrow-right` | 向右箭头 | `fa-solid fa-chevron-right` |
| `GEN::Icon::close` | 关闭 | `fa-solid fa-xmark` |
| `GEN::Icon::check` | 确认 | `fa-solid fa-check` |

### Typography 文本排版

| 令牌 | 说明 | HTML 结构 |
|------|------|-----------|
| `GEN::Typography::title::h1` | 一级标题 | `<h1 class="page-title">` |
| `GEN::Typography::title::h2` | 二级标题 | `<h2 class="section-title">` |
| `GEN::Typography::title::h3` | 三级标题 | `<h3 class="block-title">` |
| `GEN::Typography::text` | 正文文本 | `<span>` / `<p>` |
| `GEN::Typography::text::secondary` | 次要文本 | `<span class="text-secondary">` |
| `GEN::Typography::text::danger` | 错误文本 | `<span class="text-danger">` |
| `GEN::Typography::link` | 文本链接 | `<a class="ft-link">` |

---

## 二、布局组件 (LAY)

| 令牌 | 说明 | 关键 CSS |
|------|------|---------|
| `LAY::Sidebar::fixed` | 固定侧边栏（240px） | `ft-sidebar`（`position:fixed; width:240px`） |
| `LAY::Main::default` | 主内容区 | `ft-main`（`margin-left:240px`） |
| `LAY::Toolbar::default` | 工具栏（筛选+操作） | `ft-toolbar`（含 `ft-filter-area` + `ft-action-area`） |
| `LAY::Grid::2col` | 2列网格 | `display:grid; grid-template-columns:1fr 1fr; gap:16px` |
| `LAY::Grid::3col` | 3列网格 | `display:grid; grid-template-columns:repeat(3,1fr); gap:16px` |
| `LAY::Grid::4col` | 4列网格 | `display:grid; grid-template-columns:repeat(4,1fr); gap:16px` |
| `LAY::Space::horizontal` | 水平间距 | `display:flex; gap:8px; align-items:center` |
| `LAY::Space::vertical` | 垂直间距 | `display:flex; flex-direction:column; gap:8px` |
| `LAY::Divider::horizontal` | 水平分割线 | `ft-divider` |
| `LAY::Divider::vertical` | 垂直分割线 | `ft-divider-v` |
| `LAY::Detail::label-value` | 标签-值对 | `detail-item`（含 `detail-label` + `detail-value`） |
| `LAY::Detail::section` | 分组区块 | `detail-section`（含 `section-title`） |

---

## 三、导航组件 (NAV)

### Menu 侧边栏菜单

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `NAV::Menu::sidebar` | 侧边栏导航整体 | `ft-sidebar`（含 `sidebar-logo` + `sidebar-nav`） |
| `NAV::Menu::sidebar-item` | 菜单项 | `nav-item`（含 `fa-solid fa-xxx` 图标 + `<span>`） |
| `NAV::Menu::sidebar-item-active` | 激活菜单项 | `nav-item active`（左侧2px品牌色火柴棍） |

### Breadcrumb 面包屑

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `NAV::Breadcrumb::default` | 面包屑导航 | `page-breadcrumb`（`fa-solid fa-chevron-right` 分隔） |

### Tabs 标签页

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `NAV::Tabs::default` | 默认标签页 | `ft-tabs`（`ft-tabs-bar` + `ft-tab.active` + `ft-tab-panel.active`） |
| `NAV::Tabs::card` | 卡片式标签 | `ft-tabs card` |
| `NAV::Tabs::with-badge` | 带徽标标签 | `ft-tab`（内含 `ft-tab-badge`） |

### Pagination 分页器

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `NAV::Pagination::default` | 标准分页器 | `ft-pagination`（含 `ft-page-info` + `ft-page-btn.active`） |

### Steps 步骤条

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `NAV::Steps::default` | 水平步骤条 | `ft-steps`（`ft-step.done` + `ft-step.active` + `ft-step`） |
| `NAV::Steps::error` | 错误状态步骤 | `ft-step error` |

---

## 四、数据录入组件 (ENT)

### Input 输入框

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::Input::default` | 基础输入框 | `ft-input no-icon` |
| `ENT::Input::search` | 搜索框（带图标） | `ft-input-wrapper`（含 `fa-solid fa-magnifying-glass ft-input-icon` + `ft-input`） |
| `ENT::Input::error` | 错误状态输入框 | `ft-input no-icon error` |
| `ENT::Input::warning` | 警告状态输入框 | `ft-input no-icon warning` |
| `ENT::Input::disabled` | 禁用输入框 | `ft-input no-icon`（`disabled` 属性） |
| `ENT::Input::number` | 数字输入框 | `ft-input no-icon`（`type="number"`） |
| `ENT::Input::password` | 密码输入框 | `ft-input no-icon`（`type="password"`） |
| `ENT::Input::clear` | 可清空输入框 | `ft-input-wrapper`（含清除图标按钮） |

### Textarea 多行文本

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::Textarea::default` | 多行文本域 | `ft-textarea` |

### Select 选择器

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::Select::default` | 基础选择器 | `ft-select`（含 `fa-solid fa-chevron-down ft-select-arrow`） |
| `ENT::Select::multiple` | 多选选择器 | `ft-select ft-select-multiple` |
| `ENT::Select::search` | 可搜索选择器 | `ft-select`（内含搜索 input） |

### DatePicker 日期选择

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::DatePicker::default` | 日期选择 | `ft-input no-icon`（`type="date"`） |
| `ENT::DatePicker::range` | 日期范围 | 两个 `ft-input` + 连字符 |
| `ENT::DatePicker::datetime` | 日期时间 | `ft-input no-icon`（`type="datetime-local"`） |

### Upload 上传

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::Upload::button` | 按钮触发上传 | `ft-upload-btn`（`input[type=file]` 隐藏，`label` 触发） |
| `ENT::Upload::dragger` | 拖拽上传区域 | `ft-upload-dragger`（拖入时加 `dragover`） |
| `ENT::Upload::list` | 文件列表 | `ft-upload-list`（含 `ft-upload-item`，上传中加 `uploading`） |
| `ENT::Upload::picture` | 图片卡片上传 | `ft-upload-picture-group`（含 `ft-upload-picture-item` + `ft-upload-picture-add`） |

### 表单与选择控件

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `ENT::Form::default` | 标准表单 | `ft-form`（含 `ft-form-item` + `ft-label` + `ft-form-control`） |
| `ENT::Form::required` | 必填表单项 | `ft-label ft-label-required`（前缀 `*`） |
| `ENT::Form::row` | 多列表单行 | `ft-form-row`（2列布局） |
| `ENT::Checkbox::default` | 复选框 | `ft-checkbox`（含 `ft-checkbox-box`） |
| `ENT::Checkbox::group` | 复选框组 | `ft-checkbox-group` |
| `ENT::Radio::group` | 单选框组 | `ft-radio-group`（含 `ft-radio` + `ft-radio-circle`） |
| `ENT::Switch::on` | 开关（开） | `ft-switch-track on`（含 `ft-switch-thumb`） |
| `ENT::Switch::off` | 开关（关） | `ft-switch-track`（无 `on`） |
| `ENT::Slider::default` | 滑动条 | `ft-slider`（`input[type=range]`） |

---

## 五、数据展示组件 (DISP)

### Table 表格

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `DISP::Table::default` | 基础表格 | `ft-table` |
| `DISP::Table::selection` | 带复选框表格 | `ft-table`（第一列含 `input[type=checkbox]`） |
| `DISP::Table::bordered` | 全边框表格 | `ft-table ft-table-bordered` |
| `DISP::Table::compact` | 紧凑表格（行高32px） | `ft-table ft-table-compact` |
| `DISP::Table::striped` | 斑马纹表格 | `ft-table ft-table-striped` |
| `DISP::Table::sortable` | 可排序列 | `ft-th-sort`（含 `ft-sort-icons`） |
| `DISP::Table::filterable` | 可筛选列 | `ft-th-filter`（含 `ft-filter-icon.active`） |
| `DISP::Table::fixed-header` | 固定表头 | `ft-table-wrapper`（`max-height+overflow-y:auto`）+ `ft-table-fixed-header` |
| `DISP::Table::action-col` | 操作列 | `ft-table-action`（文本按钮 + `ft-divider-v` 分隔） |

### Card 卡片

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `DISP::Card::default` | 内容卡片 | `page-content` |
| `DISP::Card::header` | 页面头部卡片 | `page-header`（含 `page-breadcrumb` + `page-title`） |
| `DISP::Card::stat` | 统计数据卡片 | `stat-card`（含 `stat-icon` + `stat-value` + `stat-label`） |

### Statistic 统计数值

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `DISP::Statistic::default` | 统计数值 | `ft-statistic`（含 `ft-statistic-title` + `ft-statistic-number` + `ft-statistic-suffix`） |
| `DISP::Statistic::trend-up` | 上升趋势 | `ft-statistic-trend up`（含 `fa-solid fa-arrow-up`） |
| `DISP::Statistic::trend-down` | 下降趋势 | `ft-statistic-trend down`（含 `fa-solid fa-arrow-down`） |

### Progress 进度条

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `DISP::Progress::default` | 进度条 | `ft-progress`（含 `ft-progress-track` + `ft-progress-bar`，`style="width:N%"`） |
| `DISP::Progress::success` | 成功进度条 | `ft-progress-bar success` |
| `DISP::Progress::warning` | 警告进度条 | `ft-progress-bar warning` |

### Chart 图表（ECharts）

> CDN（国内首选 BootCDN）：`https://cdn.bootcdn.net/ajax/libs/echarts/5.4.3/echarts.min.js`
> FTdesign 色板：`['#005DEB','#00A870','#FF9C00','#E34D59','#0052D9','#7B61FF','#14C9C9']`

| 令牌 | ECharts type | 关键配置 | 适用场景 |
|------|-------------|---------|---------|
| `DISP::Chart::bar` | `type:'bar'` | `barMaxWidth:32, barBorderRadius:[4,4,0,0]` | 对比/排行 |
| `DISP::Chart::bar-h` | `type:'bar'`（横向） | xAxis/yAxis 互换 | 排行榜 |
| `DISP::Chart::line` | `type:'line'` | `smooth:true, symbolSize:6` | 趋势/时序 |
| `DISP::Chart::line-area` | `type:'line'` + `areaStyle:{opacity:0.15}` | 渐变填充 | 累计趋势 |
| `DISP::Chart::pie` | `type:'pie'` | `radius:['40%','65%']` | 占比分析 |
| `DISP::Chart::bar-stack` | `type:'bar'` + `stack:'total'` | 堆叠分组 | 多维对比 |

**图表卡片结构**：`content-card chart-card`（三段式：`card-header` + `chart-body` + `chart-footer`）

### 其他展示组件

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `DISP::Descriptions::2col` | 2列描述列表 | `ft-descriptions`（含 `ft-desc-item` = `ft-desc-label` + `ft-desc-value`） |
| `DISP::Descriptions::3col` | 3列描述列表 | `ft-descriptions col-3` |
| `DISP::Descriptions::1col` | 1列描述列表 | `ft-descriptions col-1` |
| `DISP::Timeline::default` | 时间轴 | `ft-timeline`（含 `ft-timeline-item` = `ft-timeline-dot` + `ft-timeline-time` + `ft-timeline-title`） |
| `DISP::Timeline::success` | 成功节点 | `ft-timeline-dot success` |
| `DISP::Timeline::error` | 错误节点 | `ft-timeline-dot error` |
| `DISP::Empty::default` | 暂无数据 | `ft-empty`（`fa-solid fa-inbox ft-empty-icon`） |
| `DISP::Empty::developing` | 开发中 | `ft-empty`（`fa-solid fa-wrench ft-empty-icon--warning`） |
| `DISP::Empty::notfound` | 未找到 | `ft-empty`（`fa-solid fa-magnifying-glass ft-empty-icon--error`） |
| `DISP::Empty::error` | 加载失败 | `ft-empty`（`fa-solid fa-circle-exclamation ft-empty-icon--error`） |

---

## 六、反馈组件 (FB)

### Modal 对话框

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Modal::default` | 标准对话框 | `ft-modal-overlay`（含 `ft-modal` = `ft-modal-header` + `ft-modal-body` + `ft-modal-footer`） |
| `FB::Modal::confirm` | 确认对话框 | `ft-modal`（含确认/取消按钮） |
| `FB::Modal::sm` | 小尺寸对话框 | `ft-modal ft-modal-sm`（480px） |
| `FB::Modal::lg` | 大尺寸对话框 | `ft-modal ft-modal-lg`（800px） |

### Drawer 抽屉

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Drawer::default` | 右侧抽屉（480px） | `ft-drawer-overlay`（含 `ft-drawer` = `ft-drawer-header` + `ft-drawer-body` + `ft-drawer-footer`） |
| `FB::Drawer::sm` | 小抽屉（360px） | `ft-drawer ft-drawer-sm` |
| `FB::Drawer::lg` | 大抽屉（600px） | `ft-drawer ft-drawer-lg` |

### Alert 警告提示

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Alert::success` | 成功提示 | `ft-alert ft-alert-success`（`fa-solid fa-circle-check`） |
| `FB::Alert::warning` | 警告提示 | `ft-alert ft-alert-warning`（`fa-solid fa-circle-exclamation`） |
| `FB::Alert::error` | 错误提示 | `ft-alert ft-alert-error`（`fa-solid fa-circle-xmark`） |
| `FB::Alert::info` | 信息提示 | `ft-alert ft-alert-info`（`fa-solid fa-circle-info`） |

### Toast / Message 消息

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Toast::success` | 成功消息 | `ft-toast ft-toast-success`（`fa-solid fa-check`） |
| `FB::Toast::error` | 错误消息 | `ft-toast ft-toast-error`（`fa-solid fa-circle-exclamation`） |
| `FB::Toast::warning` | 警告消息 | `ft-toast ft-toast-warning` |
| `FB::Toast::info` | 信息消息 | `ft-toast ft-toast-info` |

### Loading 加载中

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Loading::page` | 页面加载 | `ft-loading`（含 `ft-spinner` + `ft-loading-text`） |
| `FB::Loading::inline` | 内联加载 | `ft-spinner ft-spinner-sm` |
| `FB::Loading::overlay` | 覆盖层加载 | `ft-loading-overlay`（`position:relative` 父容器） |

### Popconfirm / Tooltip

| 令牌 | 说明 | 关键 class |
|------|------|-----------|
| `FB::Popconfirm::default` | 气泡确认 | `ft-popconfirm`（含确认/取消按钮） |
| `FB::Tooltip::default` | 文字提示 | `ft-tooltip`（`data-tooltip` 属性） |

---

## 使用示例

### 设计方案中使用令牌

```markdown
### 筛选区域
- 令牌：`ENT::Input::search`（关键词搜索框）
- 令牌：`ENT::Select::default`（状态筛选下拉）
- 令牌：`ENT::DatePicker::range`（日期范围选择）
- 令牌：`GEN::Button::primary`（查询按钮）
- 令牌：`GEN::Button::default`（重置按钮）

### 操作区域
- 令牌：`GEN::Button::primary`（新建按钮，含 fa-solid fa-plus 图标）
- 令牌：`GEN::Button::default`（导出按钮）
- 令牌：`GEN::Button::link-danger`（批量删除）

### 数据表格
- 令牌：`DISP::Table::selection`（带复选框表格）
- 令牌：`DISP::Table::action-col`（操作列）
- 令牌：`GEN::Tag::success` / `GEN::Tag::error`（状态标签）

### 分页
- 令牌：`NAV::Pagination::default`
```

### 令牌解析速查

| 组件令牌 | 解析结果 |
|---------|---------|
| `DISP::Table::selection` | `<table class="ft-table">` 第一列加 `<input type="checkbox">` |
| `ENT::Input::search` | `.ft-input-wrapper` 含 `.ft-input-icon(fa-solid fa-magnifying-glass)` + `.ft-input` |
| `GEN::Button::primary` | `<button class="ft-btn ft-btn-primary">` |
| `NAV::Pagination::default` | `<div class="ft-pagination">` |
| `GEN::Tag::success` | `<span class="ft-tag ft-tag-success">` |
| `LAY::Toolbar::default` | `.ft-toolbar` 含 `.ft-filter-area` + `.ft-action-area` |
| `FB::Alert::warning` | `.ft-alert.ft-alert-warning` 含图标+标题+描述 |
| `NAV::Tabs::default` | `.ft-tabs-bar` 含多个 `.ft-tab`，激活项加 `.active` |
| `NAV::Steps::default` | `.ft-steps` 含 `.ft-step.done` / `.ft-step.active` / `.ft-step` |
| `ENT::Switch::on` | `.ft-switch-track.on` 含 `.ft-switch-thumb` |
| `DISP::Progress::default` | `.ft-progress-track` 内 `.ft-progress-bar`（`style="width:N%"`） |
| `FB::Drawer::default` | `.ft-drawer-overlay` + `.ft-drawer`（含 header/body/footer） |
| `DISP::Descriptions::2col` | `.ft-descriptions` 含多个 `.ft-desc-item` |
| `DISP::Timeline::default` | `ul.ft-timeline` 含多个 `li.ft-timeline-item` |
| `GEN::Avatar::text` | `<div class="ft-avatar">姓</div>` |
| `FB::Loading::page` | `.ft-loading` 含 `.ft-spinner` |
| `FB::Modal::default` | `.ft-modal-overlay` + `.ft-modal` |
| `ENT::Upload::dragger` | `.ft-upload-dragger`（拖入时加 `dragover`） |
