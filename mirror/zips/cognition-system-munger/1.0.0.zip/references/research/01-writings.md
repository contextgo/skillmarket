# Charlie Munger 著作与系统性表达研究

> 调研时间：2026年1月
> 信息源优先级：一手（演讲transcript、Berkshire年报、Berkshire年会）> 二手（Poor Charlie's Almanack、书评）

---

## 一、核心著作

### 1.1 《Poor Charlie's Almanack》（穷查理宝典）

**基本信息**
- 编者：Peter D. Kaufman
- 首次出版：2005年
- 扩展版：2008年（第三版，532页）
- 2023年由Stripe Press再版
- 书名致敬：本杰明·富兰克林的《Poor Richard's Almanack》

**收录的十一篇演讲**
1. Harvard-Westlake School Commencement（1986）
2. **USC Business School - "A Lesson on Elementary, Worldly Wisdom"**（1994）
3. Stanford Law School - "A Lesson in Elementary, Worldly Wisdom, Revisited"（1996）
4. "Practical Thought About Practical Thought?"（1996）
5. Harvard Law School Class of 1948 - "The Need for More Multidisciplinary Skills"（1998）
6. Foundation Financial Officers Group（1998）
7. Philanthropy Roundtable（2000）
8. "The Great Financial Scandal of 2003"（2000）
9. UC Santa Barbara - "Academic Economics"（2003）
10. **USC Law School Commencement Address**（2007，新增）
11. **"The Psychology of Human Misjudgment"**（2005更新版，原版1995）

### 1.2 《Seeking Wisdom: From Darwin to Munger》

**作者**：Peter Bevelin
- 2007年出版
- 提炼芒格与巴菲特的核心思想
- 核心理念：如何减少遇到问题的概率，而非被动应对

### 1.3 其他相关

- Berkshire Hathaway 年报（1978-2023）
- Daily Journal Corporation 年报与年会发言
- 未结集出版的大量演讲transcript

---

## 二、五大核心概念深度解析

### 2.1 多元思维模型（Mental Models / Latticework of Mental Models）

**核心定义**
> "You have to learn all the big ideas in the key disciplines in a way that they're in a mental latticework in your head and you automatically use them for the rest of your life."
> — USC Law School Commencement, 2007

芒格将多元思维模型称为"俗世智慧"（Elementary Worldly Wisdom），强调用**不同学科的重要理论**构建认知框架，避免"铁锤人倾向"。

**关键来源学科**
| 学科 | 核心模型 |
|------|----------|
| 数学 | 复利、概率论、排列组合、决策树 |
| 心理学 | 认知偏差、激励反应、社会认同 |
| 经济学 | 机会成本、供需关系、护城河 |
| 物理学 | 临界点、均衡、熵增 |
| 生物学 | 进化论、适者生存 |
| 工程学 | 冗余设计、安全边际、失效模式 |
| 哲学 | 第一性原理、证伪主义 |

**芒格的估计**
- 掌握80-90个重要模型，就能解决人生90%的问题
- "If you do that, I solemnly promise you that one day you'll be walking down the street and you'll think 'my heavenly days, I'm now one of the few competent people in my whole age cohort.'"

**实践方法**
1. 跨学科学习：每年学习一个新学科的基础知识
2. 建立"格子架"：将模型相互关联，形成网络
3. 持续实践：不使用就会遗忘

**经典比喻**
> "To the man with a hammer, every problem looks pretty much like a nail."
> — 所有问题都是钉子

---

### 2.2 逆向思考（Inversion）

**核心定义**
> "All I want to know is where I'm going to die, so I'll never go there."
> — Berkshire Hathaway Annual Meeting

逆向思考源自数学家雅各布·布隆门撒尔（Jakob Bernoulli），芒格将其发扬光大。

**方法论**
1. **正向思考**：问"如何成功？" → 答案往往复杂
2. **逆向思考**：问"如何失败？" → 答案更清晰 → 避免失败路径

**USC 1994演讲中的经典阐述**
> "Think forwards and backwards — Invert, always invert!"

**投资应用**
```
投资"必亏清单"：
- 追涨杀跌
- 使用杠杆
- 听消息炒股
- 不懂装懂
- 频繁交易
- 忽视风险
→ 反着做
```

**人生应用**
- 先写"痛苦清单"，砍掉恶习，幸福自来
- 想幸福？先研究什么导致痛苦，然后避免

**芒格原话**
> "If I knew where I was going to die, I would never go there."

---

### 2.3 能力圈（Circle of Competence）

**核心定义**
知道自己理解什么、不理解什么，只在有概率优势的地方行动。

**芒格在USC 1994演讲中的阐述**
> "Stay within a well-defined circle of competence."

**关键原则**
1. **边界比大小更重要** — 明确边界，即使圈子小也有价值
2. **不懂就放弃** — 不懂装懂是最大风险
3. **持续扩展** — 能力圈可以慢慢扩大

**评估标准**
- 能用一句话讲清核心竞争力
- 能看懂行业底层逻辑
- 能预判5年行业格局

**巴菲特/芒格案例**
- 错过互联网泡沫 → 因不在能力圈内
- 躲过2000年科技股崩盘 → 因坚守能力圈

**芒格2023年股东大会原话**
> "We're not so smart, but we kind of know where the edge of our smartness is... That is a very important part of practical intelligence."

---

### 2.4 Lollapalooza效应（鲁拉帕路萨效应）

**词源**
"Lollapalooza"是美国俚语，意为"超乎寻常的、令人印象深刻的事物"。

**核心定义**
> "When you get two or three of these tendencies operating at the same time in the same direction, you often get a Lollapalooza effect—a very extreme result."
> — The Psychology of Human Misjudgment, 1995

**本质**
多种心理偏误/行为倾向**同向叠加**时，产生**非线性放大**效应，而非简单的1+1=2。

**关键特征**
| 特征 | 说明 |
|------|------|
| 多因素叠加 | 至少2-4个强大力量同时作用 |
| 同向共振 | 所有因素指向同一方向 |
| 非线性放大 | 效果远超线性叠加，类似核爆临界质量 |
| 极端结果 | 非理性决策，巨大成功或灾难性失败 |

**芒格经典案例：特百惠派对**

| 心理偏误 | 作用 |
|----------|------|
| 社会认同 | 邻居都在买 |
| 稀缺性 | 限时优惠 |
| 承诺一致性 | 之前答应参加 |
| 互惠原则 | 提供免费试用 |
| 权威 | 派对主持人推荐 |
| 激励驱动 | 销售提成 |

→ 六种偏误共同作用，使消费者做出冲动购买决策

**负向案例：公开拍卖**
- 社会认同（看别人竞标）
- 互惠倾向
- 承诺一致性
- 损失厌恶（"必须拿下"）
→ 芒格建议：**避开公开拍卖**

**正向案例：匿名戒酒协会（AA）**
- 利用社会认同（周围都是成功戒酒的人）
- 承诺一致性
- 互惠支持
→ 50%戒酒率，在其他方法都失败的情况下

**投资与商业应用**
```
正向应用（寻找机会）：
当一家公司同时具备多重利好：
- 技术趋势红利
- 管理层激励到位
- 竞争对手失误
- 估值便宜
→ Lollapalooza效应 = 爆炸性增长

负向应用（规避风险）：
拍卖会同时触发从众、稀缺、竞争心理
→ 主动规避
```

---

### 2.5 人类误判心理学（25种心理倾向）

**来源**
1995年哈佛大学演讲《The Psychology of Human Misjudgment》，后收入《Poor Charlie's Almanack》。

**核心前提**
> "We can't change the world. The only thing we can change is ourselves, by trying to get a better understanding of our own messed-up wiring."

---

#### 完整25种心理倾向列表

| # | 心理倾向 | 核心机制 | 投资应对 |
|---|----------|----------|----------|
| 1 | **奖励/惩罚超级反应倾向** | 激励超级力量，改变认知和行为 | 检查激励结构，警惕代理人问题 |
| 2 | **喜爱/热爱倾向** | 忽视所爱之物的缺点 | 客观评估，不因喜欢CEO而买股票 |
| 3 | **厌恶/仇恨倾向** | 忽视厌恶对象的优点 | 避免因讨厌而错失好机会 |
| 4 | **怀疑/回避倾向** | 快速消除怀疑，导致仓促决策 | 抵制快速下结论的冲动 |
| 5 | **避免不一致性倾向** | 抗拒改变，死守既有结论 | 愿意修正"最爱的想法" |
| 6 | **好奇心倾向** | 求知欲有益，但教育结束后消退 | 保持终身学习 |
| 7 | **康德式公平倾向** | 要求对等公平 | 接受适度的"不公平"以换取更大利益 |
| 8 | **羡慕/嫉妒倾向** | 巴菲特："驱动世界的不是贪婪，是嫉妒" | 关注自身目标，不与他人比较 |
| 9 | **回馈倾向** | 自动回报恩惠 | 警惕小恩惠导致大承诺 |
| 10 | **简单联想影响倾向** | 容易被关联物操控 | 区分真实原因与表面关联 |
| 11 | **简单心理否认倾向** | 否认痛苦现实 | 正视问题而非扭曲现实 |
| 12 | **过度自恋倾向** | 90%司机认为驾驶技术高于平均 | 诚实评估自己 |
| 13 | **过度乐观倾向** | 成功后更加乐观 | 用概率论对抗愚蠢乐观 |
| 14 | **剥夺超级反应倾向** | 失去的痛苦大于得到的快乐 | 避免频繁查看账户 |
| 15 | **社会认同倾向** | 羊群效应、随大流 | 学会在别人错误时独立思考 |
| 16 | **对比错误反应倾向** | 相对比较而非绝对判断 | 建立绝对标准 |
| 17 | **压力影响倾向** | 压力下决策退化 | 重大决策避免高压状态 |
| 18 | **易得性加权倾向** | 重视容易想到的信息 | 建立清单和系统 |
| 19 | **用进废退倾向** | 不使用则技能衰退 | 定期练习和复习 |
| 20 | **药物影响倾向** | 损害理性判断 | 自律，远离成瘾物质 |
| 21 | **衰老影响倾向** | 年龄导致认知衰退 | 保持思维活跃 |
| 22 | **权威影响倾向** | 盲目服从权威 | 质疑权威，即使是专家 |
| 23 | **废话倾向** | 浪费时间在无意义信息上 | 过滤噪音，聚焦本质 |
| 24 | **理由合理化倾向** | 需要理由才服从 | 给决策提供充分理由 |
| 25+ | **Lollapalooza效应** | 多倾向叠加 → 极端结果 | 系统性检视所有偏误 |

---

#### 关键心理倾向详解

**1. 奖励/惩罚超级反应倾向（Reward and Punishment Superresponse Tendency）**

芒格最强调的倾向之一。

> "Show me the incentive and I will show you the outcome."

**案例**
- 联邦快递：按小时付薪 → 低效；按班次付薪 → 问题解决
- 施乐复印机：新机器卖得差 → 销售佣金制度偏向旧机器

**投资含义**
- 经纪人推荐高佣金产品
- 基金经理频繁交易赚手续费
- 管理层为短期EPS做决策

---

**15. 社会认同倾向（Social-Proof Tendency）**

> "Herd mentality - people tend to think and act like those around us."

**触发条件**
- 困惑时
- 压力下
- 两者兼具时

**投资含义**
- 追涨杀跌
- 泡沫形成与破裂
- "隔壁老王赚钱了我也得买"

**应对**
> "One of the most important skills you can foster is learning to ignore the examples of others when they are wrong."

---

**14. 剥夺超级反应倾向（Deprival-Superreaction Tendency）**

即行为金融学的"损失厌恶"。

> "Losses feel far worse than equivalent gains feel good."

**投资含义**
- 拿亏卖赚（卖出赚钱的、持有亏损的）
- 止损困难
- 过度保守

---

**12. 过度自恋倾向（Excessive Self-Regard Tendency）**

> "We all think we're above average."

**表现**
- 高估自己能力
- 低估风险
- 归功于己、归咎于人

---

**5. 避免不一致性倾向（Inconsistency-Avoidance Tendency）**

> "The brain of man conserves programming spaces by being reluctant to change."

**表现**
- 不愿承认错误
- 坚守失败的策略
- 维持糟糕的关系/工作

**芒格的建议**
> "Continually challenge and willingly amend your 'best-loved ideas.'"

---

#### 心理倾向的解药

| 倾向 | 解药 |
|------|------|
| 奖励超级反应 | 检查激励结构，特别是代理人的 |
| 社会认同 | 培养独立思考能力 |
| 损失厌恶 | 建立系统化投资规则 |
| 过度自恋 | 用检察官视角审视自己，而非辩护律师 |
| 避免不一致 | 欢迎反面证据，主动寻找"证伪" |

---

## 三、反复出现≥3次的核心论点

### 3.1 "避免愚蠢比追求聪明更重要"

> "It is remarkable how much long-term advantage people like us have gotten by trying to be consistently not stupid, instead of trying to be very intelligent."
> — Poor Charlie's Almanack

**出现场景**
- USC 1994演讲
- Berkshire Hathaway 年会
- Daily Journal 年会
- 多次采访

**核心逻辑**
- 避免重大错误 → 复利效应 → 长期优势
- 追求聪明 → 更多风险 → 可能犯更大错误

---

### 3.2 "每天比昨天聪明一点"

> "Spend each day trying to be a little wiser than you were when you woke up."
> — USC Law School Commencement, 2007

**出现场景**
- USC Law School 2007毕业演讲
- Berkshire Hathaway 年会
- 多本传记和采访

**实践方法**
- 大量阅读
- 终身学习
- 从他人错误中学习（ vicarious learning）

---

### 3.3 "能力圈边界比大小更重要"

> "Stay within a well-defined circle of competence."
> — Poor Charlie's Almanack

**出现场景**
- USC 1994演讲
- Berkshire Hathaway 年会
- Daily Journal 年会

**延伸**
- 不知道边界在哪 = 在能力圈外
- 投资决策只在能力圈内

---

### 3.4 "诚实是最好的策略"

> "Honesty is the best policy... If you tell the truth, you don't have to remember anything."
> — Multiple speeches

**出现场景**
- USC Law School 2007毕业演讲
- Berkshire Hathaway 年会
- Daily Journal 年会

**核心观点**
- 信任是最高效的商业模式
- 品格是最重要的资产
- "配得上"原则

---

### 3.5 "逆向思考，总是逆向思考"

> "Invert, always invert."
> — Multiple speeches

**出现场景**
- USC 1994演讲
- Stanford Law School 1996演讲
- 多次投资场合

**应用**
- 投资：先想如何亏损
- 商业：先想如何失败
- 人生：先想如何痛苦

---

### 3.6 "复利是世界第八大奇迹"

> "Compound interest is the eighth wonder of the world."
> — Multiple speeches (attributed to Einstein)

**出现场景**
- Poor Charlie's Almanack
- Berkshire Hathaway 年会
- 多次采访

**投资含义**
- 长期持有
- 不打断复利
- 避免重大亏损

---

### 3.7 "简单，但不容易"

> "Simple, but not easy."

**出现场景**
- 多次演讲
- Berkshire Hathaway 年会

**核心含义**
- 道理简单 → 执行困难
- 需要纪律、耐心、情绪控制

---

### 3.8 "不要愚弄自己"

> "Above all, never fool yourself, and remember that you are the easiest person to fool."
> — USC 1994 speech

**出现场景**
- USC 1994演讲
- Poor Charlie's Almanack
- 多次引用

---

## 四、自创术语体系

### 4.1 Mental Models（思维模型/格栅模型）

**定义**：来自不同学科的基本原理，构成认知框架
**出处**：1994 USC演讲，Poor Charlie's Almanack
**相关术语**：
- Latticework of Mental Models（格栅式思维模型）
- Elementary Worldly Wisdom（俗世智慧）

### 4.2 Lollapalooza Effect

**定义**：多心理倾向同向叠加产生的极端非线性效果
**出处**：1995哈佛演讲《The Psychology of Human Misjudgment》
**相关术语**：
- Tendency confluence（倾向汇合）
- Extreme outcome（极端结果）

### 4.3 Inversion（逆向思考）

**定义**：从问题反面出发思考的思维方法
**出处**：数学家雅各布·布隆门撒尔，芒格发扬光大
**相关术语**：
- Invert, always invert（逆向，总是逆向）
- Backwards thinking（逆向思维）

### 4.4 Circle of Competence（能力圈）

**定义**：个人真正理解的领域边界
**出处**：多次演讲
**相关术语**：
- Edge of smartness（智慧边界）
- Deworsification（反向多样化，讽刺过度分散）

### 4.5 Misjudgment Psychology（误判心理学）

**定义**：人类系统性认知偏差的完整分类
**出处**：1995哈佛演讲，Poor Charlie's Almanack
**相关术语**：
- 25 biases（25种偏误）
- Tendency（倾向）

### 4.6 Other Key Terms

| 术语 | 中文 | 定义 | 出处 |
|------|------|------|------|
| Moat | 护城河 | 持久竞争优势 | Berkshire哲学 |
| Margin of Safety | 安全边际 | 内在价值与价格之差 | Graham传承 |
| Focus Investing | 集中投资 | 重仓少数高置信度机会 | Berkshire哲学 |
| Hammers Syndrome | 锤子综合症 | 只有锤子时看什么都像钉子 | 多次演讲 |

---

## 五、主要演讲与语录

### 5.1 USC Business School 1994 - "A Lesson on Elementary, Worldly Wisdom"

**核心内容**
- 多元思维模型框架
- 逆向思考方法
- Lollapalooza效应介绍
- 投资实践建议

**经典语录**
> "You've got to have models in your head and you've got to array your experience—both vicarious and direct—on this latticework of models."

---

### 5.2 Harvard 1995 - "The Psychology of Human Misjudgment"

**核心内容**
- 25种人类误判心理倾向
- 每个倾向的解药
- Lollapalooza效应详解
- 特百惠派对、AA、公开拍卖案例

**经典语录**
> "When you get two or three of these tendencies operating at the same time in the same direction, you often get a Lollapalooza effect."

---

### 5.3 USC Law School 2007 - Commencement Address

**核心内容**
- 智慧获取是道德责任
- 终身学习的重要性
- "配得上"原则
- 逆向思考
- 可靠性、客观性
- 信任是文明的最高成就

**经典语录**
> "To get what you want, deserve what you want."

> "Acquiring wisdom is a moral duty."

> "The highest reach of civilization is a seamless system of trust among all parties concerned."

---

### 5.4 Daily Journal Annual Meetings

**核心内容**
- 对中国投资的看法
- 对加密货币的批评
- 对传统媒体的担忧
- 对AI的态度

**2023年经典语录**
> "Just hold the godd--- stock."（关于伯克希尔遗产规划）

---

### 5.5 Berkshire Hathaway Annual Meetings (with Buffett)

**核心特点**
- 每年5月第一个周六
- 超过5小时的问答
- 全球投资者朝圣

**芒格常用语**
> "I have nothing to add."（巴菲特发言后的经典回应）

> "Think more about it. You're smart and I'm right."

---

## 六、投资原则清单（Poor Charlie's Almanack）

### Risk（风险）
- 评估所有投资从测量风险开始，特别是声誉风险
- 坚持适当的安全边际
- 避免与品格可疑的人交易
- 避免重大错误；远离永久性资本损失

### Independence（独立性）
- 客观理性需要独立思考
- 别人同意或不同意你，不代表你是对或错
- 模仿羊群只会导致回归均值

### Preparation（准备）
- 唯一获胜之道：工作、工作、工作、工作
- 培养终身自我学习者
- 在主要学术学科中培养思维模型流利度

### Intellectual Humility（智力谦逊）
- 承认自己不知道是智慧的开始
- 留在明确界定的能力圈内
- 识别和调和反证
- 最重要的：不要愚弄自己

### Analytic Rigor（分析严谨）
- 使用科学方法和有效清单
- 区分价值与价格、进步与活动、财富与规模
- 记住显而易见的比掌握深奥的更好
- 做业务分析师，而非市场分析师
- 正向和反向思考

### Allocation（配置）
- 适当配置资本是投资者头号工作
- 好想法稀少——概率有利时，重仓下注
- 不要"爱上"一项投资

### Patience（耐心）
- 抵制人类行动的天然偏见
- 复利是世界第八大奇迹，不要不必要地打断它
- 享受过程，因为过程就是生活所在

### Decisiveness（决断）
- 当适当情况出现时，果断行动
- 他人恐惧时贪婪，他人贪婪时恐惧
- 机会不常来，来了就抓住

### Change（变化）
- 与变化共处，接受不可消除的复杂性
- 不断挑战并愿意修正"最爱的想法"
- 即使不喜欢也要承认现实

### Focus（专注）
- 保持简单，记住你要做什么
- 记住声誉和诚信是你最有价值的资产
- 不要被细节淹没而忽略显而易见的事

---

## 七、核心哲学总结

### 7.1 人生与投资的基本原则

> **Preparation. Discipline. Patience. Decisiveness.**

### 7.2 芒格的人生操作系统

1. **配得上** — 要得到什么，先让自己配得上
2. **智慧是道德责任** — 终身学习是义务
3. **跨学科思维** — 掌握多学科的大思想
4. **逆向思考** — 先想如何失败，再避免
5. **诚实可靠** — 信任是最高效的商业模式
6. **避免愚蠢** — 比追求聪明更重要
7. **耐心等待** — 复利需要时间
8. **认识自己** — 了解心理偏误，避免被自己愚弄

### 7.3 一句话总结

> "Spend each day trying to be a little wiser than you were when you woke up."
> — Charlie Munger

---

## 八、信息源索引

### 一手来源
- Poor Charlie's Almanack (2005, 2008, 2023)
- Berkshire Hathaway Annual Letters (1978-2023)
- Speech Transcripts: USC 1994, Harvard 1995, Stanford 1996, USC Law 2007
- Daily Journal Annual Meetings (transcripts available)

### 二手来源
- Peter Bevelin, Seeking Wisdom: From Darwin to Munger (2007)
- Janet Lowe, Damn Right! Behind the Scenes with Berkshire Hathaway Billionaire Charlie Munger (2000)
- David Clark, Tao of Charlie Munger (2017)

### 主要网站
- poorcharliesalmanack.com（官方）
- Berkshire Hathaway Investor Relations

---

*本文件为Charlie Munger系统性表达的调研汇总，涵盖其核心著作、概念、演讲和投资原则。*
