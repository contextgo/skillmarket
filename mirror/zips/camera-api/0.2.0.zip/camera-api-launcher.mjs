#!/usr/bin/env node

import { runSkillCli } from "./tivs-cli.js";

const args = process.argv.slice(2);
const provider = process.env.TIVS_PROVIDER;
const appId = process.env.TIVS_APP_ID;
const token = process.env.TIVS_TOKEN;

if (!appId || !token) {
  console.error("TIVS_APP_ID and TIVS_TOKEN are required.");
  process.exit(1);
}

const forwardedArgs = [...args];

if (provider) {
  forwardedArgs.push("--provider", provider);
}

forwardedArgs.push("--app-id", appId, "--token", token);

try {
  await runSkillCli(forwardedArgs);
} catch (error) {
  console.error("TIVS camera skill launcher failed:", error);
  process.exit(1);
}
