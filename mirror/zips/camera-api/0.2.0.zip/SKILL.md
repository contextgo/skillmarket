---
name: camera-api
description:
  通过本地 CLI 查询 TIVS 设备相关信息。包括设备列表，设备截图等能力。用户提出摄像头等设备查询查看需求时使用。
metadata: {"openclaw":{"requires":{"bins":["node"],"env":["TIVS_TOKEN","TIVS_APP_ID"]},"primaryEnv":"TIVS_TOKEN"}}
---

# My Camera API Skill

## 作用

通过本地 CLI 查询 TIVS 设备相关信息，包括设备列表和设备截图记录。

运行入口为 `camera-api-launcher.mjs`，由 launcher 读取运行环境变量，并直接调用 `tivs-cli.js` 导出的设备查询入口。

## 环境变量

- 运行前需要提供 `TIVS_APP_ID`、`TIVS_TOKEN`
- 建议由部署方通过受控环境变量注入凭据
- launcher 读取运行环境变量，主 bundle `tivs-cli.js` 不直接读取环境变量
- 环境变量仅用于向固定域名 `https://openapi-cn01.tange365.com` 发起认证后的设备查询请求

## 能力清单

### 设备列表

- 命令：`node ./camera-api-launcher.mjs devices list --json`
- 用途：获取当前账号下的设备列表
- 返回：设备 ID、名称、在线状态等结构化字段

### 设备截图

- 命令：`node ./camera-api-launcher.mjs devices screenshot <deviceId> --json`
- 用途：查询指定设备的截图记录，返回截图时间和图片地址
- 返回：截图时间戳、时间文本、图片地址
- 说明：最新截图通常可取返回数组中的 `items[0]`

## 异常处理

- 缺少认证变量时，提示补充 `TIVS_APP_ID` 和 `TIVS_TOKEN`
- CLI 或 API 报错时，直接返回错误信息
- 无结果时，明确说明未查询到数据
- 截图列表为空时，明确说明该设备暂无截图记录

