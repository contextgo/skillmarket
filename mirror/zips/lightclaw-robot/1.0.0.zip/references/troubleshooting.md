# 故障排查速查表

| 现象 | 定位 / 处置 |
|---|---|
| 端口看不到监听 | 查 `logs/qrobotclaw.log` 启动阶段 Traceback；最常见是 `data/.config.yaml` YAML 语法错 |
| `No module named 'opuslib_next'` | `pip install opuslib_next==1.1.6`，并确认 `requirements.txt` 已包含该依赖 |
| 设备 WS 连接异常 | 确认 OpenClaw Responses API 已启用，`llm.base_url` 可达 |
| OTA 接口 curl 连接拒绝 | 进程没跑起来，前台启动看报错 |
| OTA 响应不含 `websocket.url` | `server.websocket` 字段未配置或被覆盖成空 |
| WebSocket 不是 101 | Nginx 反代时没带 `Upgrade`/`Connection` 头 |
| 设备连上但不识别 | `vad.threshold` 可降到 0.3；检查 `asr.*` 凭据 |
| 设备回复很久 | 日志里看 `LLM 返回 (Xms)`；若 > 5s 检查 LLM 上游网关状态 |
| TTS 返回空音频 | `tts.*` 凭据错误或腾讯云账户欠费 |
| 设备一直"聆听中" | 确认 `用户:` 之后立刻有 `首句送 TTS`，缺失则 TTS 合成失败 |
| Opus 解码报错 | 设备 hello 里的 `sample_rate` 与 `tts.sample_rate` 不一致；保持双方都 16000 |

## 快速诊断命令

```bash
sudo systemctl status qrobotclaw
sudo journalctl -u qrobotclaw -f
grep -E '用户|助手|LLM|TTS|工具|WS 连接' /opt/qrobotclaw/logs/qrobotclaw.log | tail -50
curl -X POST http://127.0.0.1:8003/openclaw/ota/ \
     -H "Device-Id: aa:bb:cc:dd:ee:ff" -H "Client-Id: debug" -d '{}'
```
