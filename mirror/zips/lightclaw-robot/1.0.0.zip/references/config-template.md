# 配置模板

用户配置文件路径：`/opt/qrobotclaw/data/.config.yaml`。该文件会深合并覆盖 `config.yaml` 默认配置。

## 完整模板

```yaml
server:
  ip: 0.0.0.0
  ws_port: 8000
  http_port: 8003
  websocket: ws://REPLACE_WITH_PUBLIC_IP:8000/openclaw/v1/
  vision_explain: http://REPLACE_WITH_PUBLIC_IP:8003/mcp/vision/explain

llm:
  base_url: http://127.0.0.1:REPLACE_WITH_OPENCLAW_PORT
  api_key: REPLACE_WITH_OPENCLAW_API_KEY
  agent_id: openclaw:main
  timeout: 300

asr:
  appid: "REPLACE_WITH_TENCENT_APPID"
  secret_id: REPLACE_WITH_TENCENT_SECRET_ID
  secret_key: REPLACE_WITH_TENCENT_SECRET_KEY

tts:
  appid: "REPLACE_WITH_TENCENT_APPID"
  secret_id: REPLACE_WITH_TENCENT_SECRET_ID
  secret_key: REPLACE_WITH_TENCENT_SECRET_KEY
  voice: "101027"
  sample_rate: 16000
  region: ap-guangzhou

vad:
  threshold: 0.5
  threshold_low: 0.3
  model_path: models/silero_vad.onnx
  min_silence_duration_ms: 200

log:
  level: DEBUG

exit_commands:
  - "退出"
  - "关闭"
  - "结束对话"
  - "再见"
  - "拜拜"

# 设备端系统提示词（发送给 OpenClaw 的系统指令）
system_prompt: |
  你是一个运行在智能硬件终端上的语音助手，用户通过语音与你交流，你的回复会被TTS语音合成后播放给用户。

  输出要求：
  - 只输出纯文本，禁止使用任何格式化标记
  - 回复简洁，控制在两三句话以内
  - 用口语化表达，像面对面聊天一样自然
  - 数字用汉字读法表述
```

## 必须替换的占位符

| 占位符 | 说明 |
|---|---|
| `REPLACE_WITH_PUBLIC_IP` | 本机对外 IP 或域名 |
| `REPLACE_WITH_OPENCLAW_PORT` | OpenClaw 网关端口 |
| `REPLACE_WITH_OPENCLAW_API_KEY` | OpenClaw 网关 API key |
| `REPLACE_WITH_TENCENT_APPID` | 腾讯云 ASR/TTS AppID |
| `REPLACE_WITH_TENCENT_SECRET_ID` | 腾讯云 SecretId |
| `REPLACE_WITH_TENCENT_SECRET_KEY` | 腾讯云 SecretKey |

## 写入命令

```bash
sudo mkdir -p /opt/qrobotclaw/data
sudo tee /opt/qrobotclaw/data/.config.yaml > /dev/null <<'YAML'
# 将上述模板内容粘贴此处，替换占位符
YAML
```
