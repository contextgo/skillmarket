# 日志关键字说明

日志格式：`时间(毫秒) 等级 [TAG] 文件:行号 消息`

## 关键日志关键字

| 日志关键字 | 含义 |
|---|---|
| `🔌 新 WS 连接 device_id=...` | 设备接入 |
| `← hello` / `← listen` | 收到设备 JSON 消息 |
| `👤 用户: ...` | ASR 识别结果 |
| `🤖 LLM 调用 depth=0 ...` / `🤖 LLM 返回 (Xms)` | LLM 请求耗时 |
| `⚡ 首句送 TTS, 距 LLM 调用 XXms` | 流式 TTS 首字节延迟 |
| `🔧 [i/n] tool_name args=...` | 工具调用 |
| `🗣️ 助手: ...` | 最终助手文本 |
| `🔊 流式 TTS 播放结束` | 一轮回复结束 |
| `🔌 WS 连接关闭 ... code=...` | 设备断开 |

## 实时观察

```bash
sudo journalctl -u qrobotclaw -f     # systemd
tail -f /opt/qrobotclaw/logs/qrobotclaw.log  # 直接文件
```

## 只看对话要点

```bash
grep -E '用户|助手|LLM|TTS|工具|WS 连接' /opt/qrobotclaw/logs/qrobotclaw.log | tail -50
```
