# Nginx HTTPS 反代

设备端走公网时强烈建议 HTTPS / WSS。

## Nginx 配置

```nginx
server {
    listen 443 ssl http2;
    server_name your.domain.com;
    ssl_certificate     /etc/letsencrypt/live/your.domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your.domain.com/privkey.pem;

    location /openclaw/v1/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }
}

server {
    listen 8443 ssl http2;
    server_name your.domain.com;
    ssl_certificate     /etc/letsencrypt/live/your.domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your.domain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8003;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        client_max_body_size 20m;
    }
}
```

关键点：
- WebSocket 路径必须带上 `Upgrade` 和 `Connection` 头
- `proxy_read_timeout` 设大（600s），避免语音通道超时断连

## 对应配置修改

`/opt/openclaw/data/.config.yaml` 中的 `server.websocket` 和 `server.vision_explain` 改为：

```yaml
server:
  websocket: wss://your.domain.com/openclaw/v1/
  vision_explain: https://your.domain.com:8443/mcp/vision/explain
```

## 生效

```bash
sudo systemctl reload nginx && sudo systemctl restart openclaw
```
