---
name: we-merge-dev-to-test
description: 自动将当前 dev 开发分支（如 dev_addTips_lihb_20260331）合并到对应的 test 测试分支（如 test_addTips_lihb_20260331）。当用户让你把 dev 分支合并到 test 分支时使用。
---

# 自动合并 dev 到 test 分支技能

这个技能帮助用户将当前的 `dev` 系列分支代码，自动合并到对于的 `test` 系列分支中，并推送到远程仓库。

## 执行步骤

你需要使用终端（运行 bash 命令）执行以下步骤：

1. **获取当前分支名**：
   运行 `git branch --show-current`。
   如果当前分支名不是以 `dev` 开头甚至不在 dev 分支上，请告诉用户必须在需要合并的 dev 分支上执行此操作。
   如果以 `dev` 开头，提取其后缀名，拼接成目标 `test` 分支名（例如将 `dev_` 前缀替换为 `test_`，如 `dev_addTips_lihb_20260331` -> `test_addTips_lihb_20260331`）。

2. **检查工作区状态**：
   运行 `git status -s`。如果有未提交的修改，提醒用户先提交或者暂存修改，并暂停合并操作（等待用户处理后再继续）。

3. **执行合并流程**：
   在终端中执行以下 git 命令。注意：如果遇到报错或者合并冲突，请立即停止后续操作，并告知用户错误信息让其手动处理。
   
   执行过程（假设当前分支为 dev_xxx，目标分支为 test_xxx）：
   ```bash
   # 获取最新远端更新
   git fetch origin

   # 切换到 test 分支。如果在本地不存在但远端存在，下面的命令会基于远端 test 创建并切换。
   git checkout test_xxx
   
   # 拉取 test 分支的最新代码
   git pull origin test_xxx
   
   # 选择合并 dev 分支
   git merge dev_xxx
   
   # 将这部分合并结果推送到远端仓库
   git push origin test_xxx
   
   # 完成后切换回原来的 dev 分支
   git checkout dev_xxx
   ```
   **注意**：如果有任何一行命令执行失败（比如 test 分支不存在且远端也没有，或者 pull/merge 产生错误），请立刻终止流程向用户报错，并且**不要**执行后面的操作（比如不要在错误状态下 push）。如果 test 分支确实不存在，询问用户是否需要新建拉取该分支。

4. **报告结果**：
   成功合并并推送后，向用户报告“合并成功，已推送到远端，并为您切换回了原开发分支”。
