#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SpringBoot通用组件
功能：合并统一响应、异常处理、AOP日志、用户上下文拦截器、响应处理Advice

@author: wql
@date: 2026-04-17
"""

import os
import re
import sys
import json
import urllib.request
import urllib.error
from datetime import datetime


class SpringBootCommon:

    DEFAULT_VERSIONS = {
        "3.5": {
            "fastjson": "2.0.61",
            "commons_lang3": "3.20.0",
            "commons_io": "2.21.0",
            "lombok": "1.18.30"
        },
        "3.2": {
            "fastjson": "2.0.61",
            "commons_lang3": "3.20.0",
            "commons_io": "2.21.0",
            "lombok": "1.18.30"
        },
        "3.1": {
            "fastjson": "2.0.61",
            "commons_lang3": "3.20.0",
            "commons_io": "2.21.0",
            "lombok": "1.18.30"
        },
        "2.7": {
            "fastjson": "2.0.61",
            "commons_lang3": "3.20.0",
            "commons_io": "2.21.0",
            "lombok": "1.18.30"
        }
    }

    MAVEN_CENTRAL_API = "https://repo.maven.apache.org/maven2"

    def __init__(self, artifact_id: str, package_name: str, project_name: str = None, spring_boot_version: str = None, **kwargs):
        if not artifact_id or not package_name:
            raise ValueError("artifactId和packageName不能为空")

        self.artifact_id = artifact_id
        self.package_name = package_name
        self.project_name = project_name or artifact_id
        self.author = kwargs.get("author", "wql")
        self.create_time = datetime.now().strftime("%Y-%m-%d")

        self.project_dir = os.getcwd()
        self.pom_path = os.path.join(self.project_dir, "pom.xml")

        self.spring_boot_version = self._detect_spring_boot_version() if spring_boot_version is None else spring_boot_version
        self.servlet_package = "jakarta.servlet" if self.spring_boot_version.startswith("3") else "javax.servlet"

        version_key = self.spring_boot_version.split(".")[0] + "." + self.spring_boot_version.split(".")[1]
        if version_key not in self.DEFAULT_VERSIONS:
            version_key = "3.5"

        print(f"检测到SpringBoot版本: {self.spring_boot_version}")

        user_fastjson = kwargs.get("fastjsonVersion")
        user_commons_lang3 = kwargs.get("commonsLang3Version")
        user_commons_io = kwargs.get("commonsIoVersion")

        self.versions = {
            "fastjson": user_fastjson,
            "commons_lang3": user_commons_lang3,
            "commons_io": user_commons_io,
            "lombok": self.DEFAULT_VERSIONS["3.5"]["lombok"]
        }

        self._resolve_versions()

        package_path = package_name.replace(".", os.sep)
        self.src_main_java = os.path.join(self.project_dir, "src", "main", "java", package_path)

    def _detect_spring_boot_version(self) -> str:
        print("检测SpringBoot版本...")
        if not os.path.exists(self.pom_path):
            print("警告: pom.xml不存在，使用默认版本3.5")
            return "3.5"

        try:
            with open(self.pom_path, "r", encoding="utf-8") as f:
                content = f.read()

            spring_boot_version_pattern = r'<parent>.*?<artifactId>spring-boot-starter-parent</artifactId>.*?<version>([\d.]+)</version>.*?</parent>'
            match = re.search(spring_boot_version_pattern, content, re.DOTALL)
            if match:
                version = match.group(1)
                print(f"从pom.xml检测到SpringBoot版本: {version}")
                return version

            parent_version_pattern = r'<parent>.*?<artifactId>spring-boot-dependencies</artifactId>.*?<version>([\d.]+)</version>.*?</parent>'
            match = re.search(parent_version_pattern, content, re.DOTALL)
            if match:
                version = match.group(1)
                print(f"从pom.xml检测到SpringBoot版本: {version}")
                return version

        except Exception as e:
            print(f"检测版本失败: {e}，使用默认版本3.5")

        return "3.5"

    def _fetch_latest_version(self, group_id: str, artifact_id: str) -> str:
        try:
            url = f"{self.MAVEN_CENTRAL_API}/{group_id.replace('.', '/')}/{artifact_id}/maven-metadata.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as response:
                content = response.read().decode("utf-8")

            release_match = re.search(r'<release>([\d.]+)</release>', content)
            if release_match:
                return release_match.group(1)

            latest_match = re.search(r'<latest>([\d.]+)</latest>', content)
            if latest_match:
                return latest_match.group(1)

            versions = re.findall(r'<version>([\d.]+)</version>', content)
            if versions:
                return versions[-1]

        except Exception:
            pass

        return None

    def _is_version_compatible(self, version: str, spring_boot_major: int) -> bool:
        try:
            major = int(version.split(".")[0])
            return major >= 2
        except Exception:
            return True

    def _resolve_versions(self):
        print("解析依赖版本...")

        has_network = self._check_network()

        if has_network:
            print("网络可用，搜索最新稳定版本...")
            for dep in ["fastjson", "commons_lang3", "commons_io"]:
                group_id, artifact_id = self._get_maven_coords(dep)
                if self.versions[dep] is None:
                    latest = self._fetch_latest_version(group_id, artifact_id)
                    if latest and self._is_version_compatible(latest, int(self.spring_boot_version.split(".")[0])):
                        self.versions[dep] = latest
                        print(f"  {artifact_id}: {latest} (在线)")
                    else:
                        self.versions[dep] = self.DEFAULT_VERSIONS["3.5"][dep]
                        print(f"  {artifact_id}: {self.versions[dep]} (默认)")
                else:
                    print(f"  {artifact_id}: {self.versions[dep]} (用户指定)")
            print(f"  lombok: {self.versions['lombok']} (默认)")
        else:
            print("网络不可用，使用默认版本...")
            for dep in ["fastjson", "commons_lang3", "commons_io"]:
                if self.versions[dep] is None:
                    self.versions[dep] = self.DEFAULT_VERSIONS["3.5"][dep]
                    print(f"  {dep}: {self.versions[dep]}")
                else:
                    print(f"  {dep}: {self.versions[dep]} (用户指定)")
            print(f"  lombok: {self.versions['lombok']} (默认)")

    def _check_network(self) -> bool:
        try:
            req = urllib.request.Request("https://repo.maven.apache.org/maven2", headers={"User-Agent": "Mozilla/5.0"})
            urllib.request.urlopen(req, timeout=3)
            return True
        except Exception:
            return False

    def _get_maven_coords(self, dep: str):
        coords = {
            "fastjson": ("com.alibaba.fastjson2", "fastjson2"),
            "commons_lang3": ("org.apache.commons", "commons-lang3"),
            "commons_io": ("commons-io", "commons-io")
        }
        return coords.get(dep, (dep, dep))

    def generate(self):
        print(f"开始添加通用组件...")
        print(f"项目: {self.project_name}")
        print(f"包名: {self.package_name}")
        print(f"版本信息: fastjson={self.versions['fastjson']}, commons-lang3={self.versions['commons_lang3']}, commons-io={self.versions['commons_io']}, lombok={self.versions['lombok']}")

        self._update_pom_xml()
        self._ensure_package_structure()

        self._generate_result_code()
        self._generate_result()
        self._generate_request_utils()
        self._generate_user_context()

        self._generate_biz_exception()
        self._generate_global_exception_handler()

        self._generate_user_context_interceptor()
        self._generate_web_mvc_config()

        self._generate_show_log_annotation()
        self._generate_show_log_aspect()
        self._generate_result_advice()

        print(f"\n[OK] 通用组件添加成功!")
        print(f"更新文件:")
        print(f"  - pom.xml")
        print(f"生成文件:")
        print(f"  - constant/ResultCode.java")
        print(f"  - common/Result.java")
        print(f"  - util/RequestUtils.java")
        print(f"  - util/UserContext.java")
        print(f"  - exception/BizException.java")
        print(f"  - exception/GlobalExceptionHandler.java")
        print(f"  - interceptor/UserContextInterceptor.java")
        print(f"  - config/WebMvcConfig.java")
        print(f"  - annotation/ShowLog.java")
        print(f"  - aspect/ShowLogAspect.java")
        print(f"  - advice/ResultAdvice.java")

    def _update_pom_xml(self):
        print("更新pom.xml...")

        if not os.path.exists(self.pom_path):
            print("错误: pom.xml不存在，请先运行springboot-init")
            sys.exit(1)

        with open(self.pom_path, "r", encoding="utf-8") as f:
            content = f.read()

        fastjson_dep = f'''
        <dependency>
            <groupId>com.alibaba.fastjson2</groupId>
            <artifactId>fastjson2</artifactId>
            <version>${{fastjson.version}}</version>
        </dependency>'''

        commons_lang3_dep = f'''
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
            <version>${{commons-lang3.version}}</version>
        </dependency>'''

        commons_io_dep = f'''
        <dependency>
            <groupId>commons-io</groupId>
            <artifactId>commons-io</artifactId>
            <version>${{commons-io.version}}</version>
        </dependency>'''

        lombok_dep = f'''
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>${{lombok.version}}</version>
            <scope>provided</scope>
        </dependency>'''

        if "lombok" not in content or 'artifactId>lombok</artifactId>' not in content:
            content = content.replace("</dependencies>", lombok_dep + "\n    </dependencies>")

        if "fastjson2" not in content:
            content = content.replace("</dependencies>", fastjson_dep + "\n    </dependencies>")

        if "commons-lang3" not in content:
            content = content.replace("</dependencies>", commons_lang3_dep + "\n    </dependencies>")

        if "commons-io" not in content:
            content = content.replace("</dependencies>", commons_io_dep + "\n    </dependencies>")

        # 检查并写入4个版本属性到 <properties> 标签内
        properties_to_add = {
            'fastjson.version': self.versions['fastjson'],
            'commons-lang3.version': self.versions['commons_lang3'],
            'commons-io.version': self.versions['commons_io'],
            'lombok.version': self.versions['lombok']
        }

        for prop_name, prop_value in properties_to_add.items():
            if f'<{prop_name}>' not in content:
                # 在 </properties> 前插入版本属性定义
                prop_line = f'        <{prop_name}>{prop_value}</{prop_name}>\n    </properties>'
                content = content.replace('</properties>', prop_line, 1)

        with open(self.pom_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _ensure_package_structure(self):
        dirs = [
            os.path.join(self.src_main_java, "constant"),
            os.path.join(self.src_main_java, "common"),
            os.path.join(self.src_main_java, "util"),
            os.path.join(self.src_main_java, "exception"),
            os.path.join(self.src_main_java, "interceptor"),
            os.path.join(self.src_main_java, "config"),
            os.path.join(self.src_main_java, "annotation"),
            os.path.join(self.src_main_java, "aspect"),
            os.path.join(self.src_main_java, "advice"),
        ]
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)

    def _generate_result_code(self):
        print("生成ResultCode常量类...")
        content = f'''package {self.package_name}.constant;

/**
 * 响应码常量类
 * 定义系统统一响应状态码
 *
 * @author {self.author}
 * @date {self.create_time}
 */
public class ResultCode {{

    public static final Integer SUCCESS = 200;

    public static final Integer FAIL = 500;
}}
'''
        file_path = os.path.join(self.src_main_java, "constant", "ResultCode.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_result(self):
        print("生成Result统一响应类...")
        content = f'''package {self.package_name}.common;

import {self.package_name}.constant.ResultCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一响应类
 * 用于封装API统一返回格式
 *
 * @param <T> 数据类型
 * @author {self.author}
 * @date {self.create_time}
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {{

    private Integer code;

    private String message;

    private T data;

    private String requestId;

    public static <T> Result<T> success() {{
        return new Result<>(ResultCode.SUCCESS, "success", null, null);
    }}

    public static <T> Result<T> success(T data) {{
        return new Result<>(ResultCode.SUCCESS, "success", data, null);
    }}

    public static <T> Result<T> success(String message, T data) {{
        return new Result<>(ResultCode.SUCCESS, message, data, null);
    }}

    public static <T> Result<T> fail() {{
        return new Result<>(ResultCode.FAIL, "fail", null, null);
    }}

    public static <T> Result<T> fail(String message) {{
        return new Result<>(ResultCode.FAIL, message, null, null);
    }}

    public static <T> Result<T> fail(Integer code, String message) {{
        return new Result<>(code, message, null, null);
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "common", "Result.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_request_utils(self):
        print("生成RequestUtils工具类...")
        servlet = self.servlet_package
        content = f'''package {self.package_name}.util;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import {servlet}.http.HttpServletRequest;
import java.util.Objects;

/**
 * Request工具类
 * 获取当前请求的HttpServletRequest对象
 *
 * @author {self.author}
 * @date {self.create_time}
 */
public class RequestUtils {{

    public static HttpServletRequest getRequest() {{
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (Objects.isNull(attributes)) {{
            return null;
        }}
        return attributes.getRequest();
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "util", "RequestUtils.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_user_context(self):
        print("生成UserContext工具类...")
        content = f'''package {self.package_name}.util;

import java.util.Objects;
import java.util.UUID;

/**
 * 用户上下文工具类
 * 基于ThreadLocal实现用户上下文管理，存储用户ID和请求ID
 *
 * @author {self.author}
 * @date {self.create_time}
 */
public class UserContext {{

    public static final String USER_ID_KEY = "x-user";

    public static final String REQUEST_ID_KEY = "x-request-id";

    private static final ThreadLocal<UserInfo> USER_INFO = ThreadLocal.withInitial(() -> new UserInfo());

    public static void setUserId(String userId) {{
        if (Objects.isNull(userId)) {{
            USER_INFO.get().setUserId("");
        }} else {{
            USER_INFO.get().setUserId(userId);
        }}
    }}

    public static String getUserId() {{
        return USER_INFO.get().getUserId();
    }}

    public static String getUserCode() {{
        return USER_INFO.get().getUserId();
    }}

    public static void setRequestId(String requestId) {{
        if (Objects.nonNull(requestId)) {{
            USER_INFO.get().setRequestId(requestId);
        }}
    }}

    public static String getRequestId() {{
        return USER_INFO.get().getRequestId();
    }}

    public static String generateRequestId() {{
        return UUID.randomUUID().toString();
    }}

    public static void clear() {{
        USER_INFO.remove();
    }}

    public static class UserInfo {{

        private String userId;

        private String requestId;

        public UserInfo() {{
        }}

        public String getUserId() {{
            return userId;
        }}

        public void setUserId(String userId) {{
            this.userId = userId;
        }}

        public String getRequestId() {{
            return requestId;
        }}

        public void setRequestId(String requestId) {{
            this.requestId = requestId;
        }}
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "util", "UserContext.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_biz_exception(self):
        print("生成BizException业务异常类...")
        content = f'''package {self.package_name}.exception;

import {self.package_name}.constant.ResultCode;
import lombok.Getter;

/**
 * 业务异常类
 * 用于处理业务逻辑中的异常情况
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Getter
public class BizException extends RuntimeException {{

    private final Integer code;

    private final String message;

    public BizException(String message) {{
        super(message);
        this.code = ResultCode.FAIL;
        this.message = message;
    }}

    public BizException(Integer code, String message) {{
        super(message);
        this.code = code;
        this.message = message;
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "exception", "BizException.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_global_exception_handler(self):
        print("生成GlobalExceptionHandler全局异常处理器...")
        content = f'''package {self.package_name}.exception;

import {self.package_name}.common.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Objects;

/**
 * 全局异常处理器
 * 统一处理业务异常和系统异常
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {{

    @ExceptionHandler(BizException.class)
    public Result<Void> handleBizException(BizException e) {{
        if (Objects.nonNull(e)) {{
            log.error("业务异常: {{}}", e.getMessage());
            return Result.fail(e.getCode(), e.getMessage());
        }}
        return Result.fail("系统异常");
    }}

    @ExceptionHandler(Exception.class)
    public Result<Void> handleException(Exception e) {{
        if (Objects.nonNull(e)) {{
            log.error("系统异常", e);
            return Result.fail("系统异常");
        }}
        return Result.fail("系统异常");
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "exception", "GlobalExceptionHandler.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_user_context_interceptor(self):
        print("生成UserContextInterceptor用户上下文拦截器...")
        servlet = self.servlet_package
        content = f'''package {self.package_name}.interceptor;

import {self.package_name}.util.UserContext;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import {servlet}.http.HttpServletRequest;
import {servlet}.http.HttpServletResponse;

import java.util.Objects;

/**
 * 用户上下文拦截器
 * 从请求头提取用户ID和请求ID存入UserContext
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Component
public class UserContextInterceptor implements HandlerInterceptor {{

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {{
        if (Objects.nonNull(request)) {{
            String userId = request.getHeader(UserContext.USER_ID_KEY);
            UserContext.setUserId(userId);

            String requestId = request.getHeader(UserContext.REQUEST_ID_KEY);
            if (Objects.isNull(requestId)) {{
                requestId = UserContext.generateRequestId();
            }}
            UserContext.setRequestId(requestId);
        }}
        return true;
    }}

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {{
        UserContext.clear();
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "interceptor", "UserContextInterceptor.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_web_mvc_config(self):
        print("生成WebMvcConfig配置类...")
        content = f'''package {self.package_name}.config;

import {self.package_name}.interceptor.UserContextInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Objects;

/**
 * WebMvc配置类
 * 配置拦截器和静态资源路径
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {{

    @Autowired
    private UserContextInterceptor userContextInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {{
        if (Objects.nonNull(userContextInterceptor)) {{
            registry.addInterceptor(userContextInterceptor)
                    .addPathPatterns("/**")
                    .excludePathPatterns("/doc.html", "/webjars/**", "/swagger-resources/**");
        }}
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "config", "WebMvcConfig.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_show_log_annotation(self):
        print("生成ShowLog注解...")
        content = f'''package {self.package_name}.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 日志打印注解
 * 标注在方法上，自动打印方法调用日志
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ShowLog {{

    String value();

    boolean printArgs() default true;

    boolean printResult() default true;
}}
'''
        file_path = os.path.join(self.src_main_java, "annotation", "ShowLog.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_show_log_aspect(self):
        print("生成ShowLogAspect日志切面...")
        servlet = self.servlet_package
        content = f'''package {self.package_name}.aspect;

import {self.package_name}.annotation.ShowLog;
import {self.package_name}.util.UserContext;
import com.alibaba.fastjson2.JSON;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 日志切面
 * 实现方法调用日志打印功能，支持分条打印入参和返回结果
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Slf4j
@Aspect
@Component
public class ShowLogAspect {{

    @Pointcut("@annotation({self.package_name}.annotation.ShowLog)")
    public void pointcut() {{
    }}

    /**
     * 环绕通知，处理方法调用前后的日志打印
     *
     * @param joinPoint 连接点
     * @return 方法执行结果
     * @throws Throwable 方法执行抛出的异常
     */
    @Around("pointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {{
        if (Objects.isNull(joinPoint)) {{
            return null;
        }}

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        if (Objects.isNull(signature)) {{
            return joinPoint.proceed();
        }}

        Method method = signature.getMethod();
        if (Objects.isNull(method)) {{
            return joinPoint.proceed();
        }}

        ShowLog showLog = method.getAnnotation(ShowLog.class);
        if (Objects.isNull(showLog)) {{
            return joinPoint.proceed();
        }}

        // 从上下文中获取userid和requestid
        String userId = UserContext.getUserId();
        String requestId = UserContext.getRequestId();
        String annotationValue = showLog.value();

        // 打印入参日志
        if (showLog.printArgs()) {{
            String argsJson = buildArgsJson(joinPoint);
            log.info("-->>[{{}}][{{}}][{{}}]入参[{{}}]", userId, requestId, annotationValue, argsJson);
        }}

        long startTime = System.currentTimeMillis();
        Object result = null;
        boolean success = false;

        try {{
            result = joinPoint.proceed();
            success = true;
        }} catch (Throwable throwable) {{
            // 异常情况，打印返回日志（成功标记为false）
            long costTime = System.currentTimeMillis() - startTime;
            String resultJson = buildResultJson(throwable);
            log.info("<<--[{{}}][{{}}][{{}}]方法返回[{{}}][{{}}]方法耗时[{{}}]", 
                    userId, requestId, annotationValue, resultJson, false, costTime);
            throw throwable;
        }}

        // 方法正常返回，打印返回日志
        long costTime = System.currentTimeMillis() - startTime;
        if (showLog.printResult()) {{
            String resultJson = buildResultJson(result);
            log.info("<<--[{{}}][{{}}][{{}}]方法返回[{{}}][{{}}]方法耗时[{{}}]", 
                    userId, requestId, annotationValue, resultJson, success, costTime);
        }}

        return result;
    }}

    /**
     * 构建方法入参的JSON字符串
     *
     * @param joinPoint 连接点
     * @return 入参JSON字符串
     */
    private String buildArgsJson(ProceedingJoinPoint joinPoint) {{
        Object[] args = joinPoint.getArgs();
        if (Objects.isNull(args) || args.length == 0) {{
            return "";
        }}

        List<Object> filteredArgs = new ArrayList<>();
        for (Object arg : args) {{
            if (Objects.nonNull(arg) 
                    && !(arg instanceof {servlet}.http.HttpServletRequest) 
                    && !(arg instanceof {servlet}.http.HttpServletResponse)) {{
                filteredArgs.add(arg);
            }}
        }}

        if (filteredArgs.isEmpty()) {{
            return "";
        }}

        return JSON.toJSONString(filteredArgs);
    }}

    /**
     * 构建方法返回结果的JSON字符串
     * 对于字符串类型，直接返回原值，不做JSON序列化包装
     *
     * @param result 方法返回结果
     * @return 返回结果JSON字符串
     */
    private String buildResultJson(Object result) {{
        if (Objects.isNull(result)) {{
            return null;
        }}

        // 如果是字符串类型，直接返回原值（null返回"null"，空串返回""，有值返回原值）
        if (result instanceof String) {{
            return (String) result;
        }}

        // 如果是Throwable类型（异常情况），返回异常信息
        if (result instanceof Throwable) {{
            Throwable throwable = (Throwable) result;
            return throwable.getMessage() != null ? throwable.getMessage() : throwable.getClass().getName();
        }}

        return JSON.toJSONString(result);
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "aspect", "ShowLogAspect.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_result_advice(self):
        print("生成ResultAdvice响应处理Advice...")
        content = f'''package {self.package_name}.advice;

import {self.package_name}.common.Result;
import {self.package_name}.util.UserContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.Objects;

/**
 * 响应处理Advice
 * 实现ResponseBodyAdvice接口，为Result自动填充requestId
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Slf4j
@RestControllerAdvice
public class ResultAdvice implements ResponseBodyAdvice<Result<?>> {{

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {{
        if (Objects.isNull(returnType)) {{
            return false;
        }}
        Class<?> parameterType = returnType.getParameterType();
        return Objects.nonNull(parameterType) && Result.class.isAssignableFrom(parameterType);
    }}

    @Override
    public Result<?> beforeBodyWrite(Result<?> body, MethodParameter returnType, MediaType selectedContentType,
                                     Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                     ServerHttpRequest request, ServerHttpResponse response) {{
        if (Objects.nonNull(body)) {{
            String requestId = UserContext.getRequestId();
            if (Objects.nonNull(requestId)) {{
                body.setRequestId(requestId);
            }}
        }}
        return body;
    }}
}}
'''
        file_path = os.path.join(self.src_main_java, "advice", "ResultAdvice.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)


def main():
    if len(sys.argv) < 3:
        print("用法: python common.py <artifactId> <packageName> [projectName] [author] [fastjsonVersion] [commonsLang3Version] [commonsIoVersion]")
        print("")
        print("参数说明:")
        print("  artifactId          - 项目artifactId (必填)")
        print("  packageName         - 主包名 (必填)")
        print("  projectName         - 项目名称 (可选,默认使用artifactId)")
        print("  author              - 作者信息 (可选,默认wql)")
        print("  fastjsonVersion     - fastjson版本 (可选,不填则自动搜索或使用默认)")
        print("  commonsLang3Version - commons-lang3版本 (可选,不填则自动搜索或使用默认)")
        print("  commonsIoVersion    - commons-io版本 (可选,不填则自动搜索或使用默认)")
        print("")
        print("说明: SpringBoot版本自动从pom.xml检测")
        print("")
        print("示例:")
        print("  python common.py demo com.example")
        print("  python common.py demo com.example Demo wql")
        print("  python common.py demo com.example Demo wql 2.0.43 3.14.0 2.15.1")
        sys.exit(1)

    artifact_id = sys.argv[1]
    package_name = sys.argv[2]
    project_name = sys.argv[3] if len(sys.argv) > 3 else None
    author = sys.argv[4] if len(sys.argv) > 4 else "wql"

    kwargs = {"author": author}
    if len(sys.argv) > 5:
        kwargs["fastjsonVersion"] = sys.argv[5]
    if len(sys.argv) > 6:
        kwargs["commonsLang3Version"] = sys.argv[6]
    if len(sys.argv) > 7:
        kwargs["commonsIoVersion"] = sys.argv[7]

    common = SpringBootCommon(artifact_id, package_name, project_name, **kwargs)
    common.generate()


if __name__ == "__main__":
    main()
