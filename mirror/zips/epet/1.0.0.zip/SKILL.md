---
name: ePet
description: >
  ePet 是 WorkBuddy 和 CodeBuddy 的桌面电子宠物搭档。它以透明悬浮窗驻留在屏幕角落，
  通过 Hook 机制自动感知 AI 任务进度，提供实时计时、完成通知（马里奥金币音效 + 粒子烟花）、
  投喂互动、情绪系统等功能。
  当用户提到以下关键词时使用此 skill：
  "ePet"、"电子宠物"、"桌面宠物"、"office pet"、"办公宠物"、"pet"、"宠物搭档"、
  "安装宠物"、"启动宠物"、"喂宠物"、"宠物状态"、"宠物心情"。
  也适用于用户要求安装、配置、排错、自定义或扩展 ePet 的场景。
allowed-tools:
  - Bash
  - Read
---

# ePet — WorkBuddy & CodeBuddy 的桌面电子宠物

## 概述

ePet 是一款基于 Electron 的桌面电子宠物应用。它悬浮在 macOS 屏幕角落，以 Dynamic Island 风格的透明胶囊形态存在，通过 Hook 与 AI 助手深度联动——自动追踪任务进度、显示完成通知、播放 8-bit 音效、触发粒子烟花庆祝。

**GitHub**: https://github.com/calvin9999/Office-pet.git
**服务地址**: `http://127.0.0.1:13121`
**数据目录**: `~/.office-pet-stats/`
**Hook 配置**:
- WorkBuddy: `~/.workbuddy/settings.json`
- CodeBuddy: `~/.codebuddy/settings.json`

---

## 安装

### 方式一：一键安装（推荐）

用户只需对 WorkBuddy 说：

```
请安装这个应用 https://github.com/calvin9999/Office-pet.git
```

WorkBuddy 执行以下步骤：

```bash
# 1. 克隆项目
cd ~ && git clone https://github.com/calvin9999/Office-pet.git office-pet

# 2. 安装依赖
cd ~/office-pet && npm install

# 3. 安装 Hook + 注册 Skill + 设置开机启动
bash install.sh

# 4. 启动
bash start.sh
```

### 方式二：已有项目目录时

```bash
cd ~/office-pet
npm install
bash install.sh
```

### 方式三：仅安装 Hook（远程开发环境）

如果 Pet 已在本地 Mac 运行，远程环境只需写入 Hook：

```bash
bash ~/office-pet/install-hooks.sh 127.0.0.1
```

---

## 核心功能

| 功能 | 说明 |
|------|------|
| 🐾 10 只宠物 | 赛博狼 Rex、琥珀狐 Amber、奶油猫 Mochi 等，Canvas 2D 实时渲染 |
| ⏱️ 实时计时 | AI 对话自动计时，显示在宠物旁边 |
| 📊 T 计数器 | 今日对话轮次可视化（如 T7 = 今天完成了 7 轮） |
| 🔔 完成通知 | 气泡通知 + 马里奥金币旋律 + 像素粒子爆裂 |
| ✨ 呼吸粒子 | 三颗金色粒子以随机节奏闪烁，赋予生命感 |
| 🖱️ 物理拖拽 | 可拖拽宠物到任意位置，松手有惯性 + 边缘反弹 |
| 🍪 投喂系统 | 每完成一轮对话获得一份零食可喂宠物 |
| 🎭 情绪系统 | 连续互动心情好，冷落会伤心 |
| 💖 触摸互动 | 点击宠物会被挤扁弹回 + 冒出爱心 |

---

## 日常操作

### 快捷脚本（推荐）

```bash
bash ~/office-pet/scripts/pet-ctl.sh <command>
```

| 命令 | 作用 |
|------|------|
| `start` | 启动宠物 |
| `stop` | 停止宠物 |
| `restart` | 重启宠物 |
| `status` | 完整状态报告（统计/心情/解锁/零食） |
| `feed` | 喂一份零食 |
| `test` | 模拟完整的开始→完成任务周期 |
| `autostart enable/disable/status` | 管理开机自启 |
| `log` | 查看最近日志 |

### 手动 API 调用

```bash
# 健康检查
curl http://127.0.0.1:13121/health

# 查看今日统计
curl http://127.0.0.1:13121/daily-stats

# 查看心情
curl http://127.0.0.1:13121/mood

# 模拟任务开始
curl "http://127.0.0.1:13121/start?workspace_label=test&description=测试任务"

# 模拟任务完成通知
curl -X POST http://127.0.0.1:13121/notify \
  -H "Content-Type: application/json" \
  -d '{"title":"ePet","message":"任务完成！","type":"done"}'

# 喂零食
curl -X POST http://127.0.0.1:13121/feed

# 查看已解锁宠物
curl http://127.0.0.1:13121/unlocks
```

---

## Hook 机制

ePet 通过 Hook 监听 WorkBuddy/CodeBuddy 的生命周期事件：

| 事件 | 脚本 | 行为 |
|------|------|------|
| `UserPromptSubmit` | `hooks/on_start.sh` | 创建会话、开始计时 |
| `PreToolUse` | `hooks/on_tool_use.sh` | 标记 waiting_approval |
| `PostToolUse` | `hooks/on_tool_done.sh` | 恢复 running 状态 |
| `Stop` | `hooks/on_finish.sh` | 结束计时、弹出通知、播放音效 |

Hook 配置会同时写入 WorkBuddy 和 CodeBuddy 的 settings.json，无需用户手动配置。

---

## 排错

| 问题 | 解决方案 |
|------|----------|
| 端口 13121 被占 | `lsof -ti :13121 \| xargs kill`，然后 `bash start.sh` |
| Hook 没触发 | 检查 `~/.workbuddy/settings.json` 中 hooks 字段；执行 `bash install-hooks.sh` |
| 看不到宠物 | 检查是否全屏应用覆盖；宠物使用 floating 窗口层级 |
| 没有声音 | 检查 macOS 音频权限和系统音量 |
| 启动报错 ipcMain undefined | 确保启动时 `ELECTRON_RUN_AS_NODE` 环境变量为空：`ELECTRON_RUN_AS_NODE= npm start` |
| 数据丢失 | 统计数据存储在 `~/.office-pet-stats/`，不随应用删除 |

---

## 项目结构

```
office-pet/
├── main.js              # Electron 主进程 + Express 服务
├── preload.js           # IPC bridge
├── renderer/
│   ├── index.html       # 界面
│   ├── app.js           # 前端逻辑
│   ├── style.css        # 样式
│   ├── pets.js          # 宠物定义（解锁条件）
│   ├── pets-1.js        # 宠物绘制（第一组）
│   ├── pets-2.js        # 宠物绘制（第二组）
│   └── fonts/           # Fira Code + Audiowide 字体
├── hooks/               # Hook bash 脚本
├── src/license.js       # License 授权逻辑
├── certs/               # HTTPS 证书
├── scripts/             # pet-ctl.sh 等工具脚本
├── skill/               # 本文件所在目录
├── install.sh           # 完整安装脚本
├── install-hooks.sh     # 仅安装 Hook
├── start.sh / stop.sh   # 启停脚本
└── package.json
```
