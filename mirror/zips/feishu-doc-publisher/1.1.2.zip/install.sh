#!/bin/bash

# ============================================================
# 飞书文档发布器 — 安装脚本
# ============================================================
#
# 用法：
#   bash install.sh
#   bash install.sh --app-id <id> --app-secret <secret>
#
# 功能：
#   1. 检查 Node.js 环境
#   2. 安装 npm 依赖
#   3. 交互式配置飞书凭证（写入 ~/.config/feishu-doc-publisher/.env）
#   4. 安装 skill 到 ~/.openclaw/skills/

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # 恢复默认

SKILL_NAME="feishu-doc-publisher"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_DIR="$HOME/.config/$SKILL_NAME"
CONFIG_ENV="$CONFIG_DIR/.env"
OPENCLAW_SKILLS_DIR="$HOME/.openclaw/skills"
INSTALL_TARGET="$OPENCLAW_SKILLS_DIR/$SKILL_NAME"

# ============================================================
# 工具函数
# ============================================================

info()    { echo -e "${BLUE}ℹ${NC}  $1"; }
success() { echo -e "${GREEN}✅${NC} $1"; }
warn()    { echo -e "${YELLOW}⚠️${NC}  $1"; }
error()   { echo -e "${RED}❌${NC} $1"; }

header() {
  echo ""
  echo -e "${CYAN}${BOLD}═══════════════════════════════════════════${NC}"
  echo -e "${CYAN}${BOLD}  $1${NC}"
  echo -e "${CYAN}${BOLD}═══════════════════════════════════════════${NC}"
  echo ""
}

# ============================================================
# 参数解析
# ============================================================

APP_ID=""
APP_SECRET=""
SKIP_CONFIG=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --app-id)     APP_ID="$2";      shift 2 ;;
    --app-secret) APP_SECRET="$2";  shift 2 ;;
    --skip-config) SKIP_CONFIG=true; shift ;;
    -h|--help)
      echo "用法: bash install.sh [选项]"
      echo ""
      echo "选项:"
      echo "  --app-id <id>        飞书应用 App ID"
      echo "  --app-secret <secret> 飞书应用 App Secret"
      echo "  --skip-config        跳过凭证配置"
      echo "  -h, --help           显示帮助信息"
      exit 0
      ;;
    *) error "未知参数: $1"; exit 1 ;;
  esac
done

# ============================================================
# 主流程
# ============================================================

header "飞书文档发布器 — 安装向导"

# ----- 1. 检查 Node.js -----
info "检查 Node.js 环境..."

if ! command -v node &> /dev/null; then
  error "未找到 Node.js，请先安装 Node.js (>= 18)"
  echo "  推荐安装方式："
  echo "    macOS:  brew install node"
  echo "    Linux:  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs"
  exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//')
NODE_MAJOR=$(echo "$NODE_VERSION" | cut -d. -f1)

if [ "$NODE_MAJOR" -lt 18 ]; then
  warn "Node.js 版本 $NODE_VERSION 过低，建议升级到 18+（需要 fetch API）"
else
  success "Node.js $NODE_VERSION"
fi

# ----- 2. 安装 npm 依赖 -----
info "安装 npm 依赖..."

if [ -f "$SCRIPT_DIR/package.json" ]; then
  (cd "$SCRIPT_DIR" && npm install --production --silent 2>&1)
  success "npm 依赖安装完成"
else
  error "未找到 package.json，请确保在 skill 目录中运行"
  exit 1
fi

# ----- 3. 配置飞书凭证 -----
if [ "$SKIP_CONFIG" = false ]; then
  header "配置飞书应用凭证"

  # 检查是否已有全局配置
  if [ -f "$CONFIG_ENV" ]; then
    info "检测到已有全局配置: $CONFIG_ENV"
    echo ""
    # 读取已有值（隐藏 secret 中间部分）
    EXISTING_ID=$(grep '^FEISHU_APP_ID=' "$CONFIG_ENV" 2>/dev/null | cut -d= -f2-)
    EXISTING_SECRET=$(grep '^FEISHU_APP_SECRET=' "$CONFIG_ENV" 2>/dev/null | cut -d= -f2-)
    if [ -n "$EXISTING_ID" ]; then
      echo -e "  当前 App ID:     ${GREEN}$EXISTING_ID${NC}"
    fi
    if [ -n "$EXISTING_SECRET" ]; then
      MASKED="${EXISTING_SECRET:0:4}****${EXISTING_SECRET: -4}"
      echo -e "  当前 App Secret: ${GREEN}$MASKED${NC}"
    fi
    echo ""

    read -p "是否重新配置？(y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
      success "保留已有配置"
      APP_ID="$EXISTING_ID"
      APP_SECRET="$EXISTING_SECRET"
    fi
  fi

  # 如果还没有有效的凭证，进入交互式配置
  if [ -z "$APP_ID" ] || [ -z "$APP_SECRET" ]; then
    echo -e "请在飞书开放平台获取应用凭证："
    echo -e "  ${CYAN}https://open.feishu.cn/app${NC}"
    echo ""

    if [ -z "$APP_ID" ]; then
      read -p "请输入 FEISHU_APP_ID: " APP_ID
    fi
    if [ -z "$APP_SECRET" ]; then
      read -s -p "请输入 FEISHU_APP_SECRET: " APP_SECRET
      echo ""
    fi

    if [ -z "$APP_ID" ] || [ -z "$APP_SECRET" ]; then
      warn "凭证未配置完整，跳过写入"
      warn "后续可手动创建 $CONFIG_ENV"
    else
      # 写入全局配置
      mkdir -p "$CONFIG_DIR"
      cat > "$CONFIG_ENV" << EOF
FEISHU_APP_ID=$APP_ID
FEISHU_APP_SECRET=$APP_SECRET
EOF
      chmod 600 "$CONFIG_ENV"
      success "凭证已写入: $CONFIG_ENV"
    fi
  fi
fi

# ----- 4. 安装到 OpenClaw skills 目录 -----
header "安装到 OpenClaw"

if [ -d "$OPENCLAW_SKILLS_DIR" ] || command -v openclaw &> /dev/null; then
  info "安装 skill 到 $INSTALL_TARGET ..."

  # 如果目标已存在且不是符号链接，先备份
  if [ -e "$INSTALL_TARGET" ] && [ ! -L "$INSTALL_TARGET" ]; then
    BACKUP="$INSTALL_TARGET.bak.$(date +%Y%m%d%H%M%S)"
    warn "已有安装目录，备份到 $BACKUP"
    mv "$INSTALL_TARGET" "$BACKUP"
  fi

  # 创建 skills 目录
  mkdir -p "$OPENCLAW_SKILLS_DIR"

  # 使用符号链接，方便开发时实时更新
  if [ -L "$INSTALL_TARGET" ]; then
    rm "$INSTALL_TARGET"
  fi
  ln -s "$SCRIPT_DIR" "$INSTALL_TARGET"
  success "已创建符号链接: $INSTALL_TARGET → $SCRIPT_DIR"
else
  info "未检测到 OpenClaw 环境，跳过 skill 安装"
  echo "  如需手动安装，请执行："
  echo -e "  ${CYAN}mkdir -p $OPENCLAW_SKILLS_DIR && ln -s $SCRIPT_DIR $INSTALL_TARGET${NC}"
fi

# ----- 5. 验证 -----
header "验证安装"

# 快速验证脚本能否加载
if node -e "require('$SCRIPT_DIR/scripts/publish.js')" 2>/dev/null; then
  # 上面会因为缺少参数而 exit(1)，所以用另一种方式验证
  true
fi

# 验证 dotenv 是否安装
if node -e "require('dotenv')" --prefix "$SCRIPT_DIR" 2>/dev/null; then
  success "dotenv 模块正常"
else
  warn "dotenv 模块未找到，环境变量需要手动设置"
fi

# 验证凭证
if [ -n "$APP_ID" ] && [ -n "$APP_SECRET" ]; then
  info "测试飞书 API 连通性..."
  # 通过环境变量传递凭证，避免在命令行中暴露或插值注入
  TOKEN_RESULT=$(FEISHU_APP_ID="$APP_ID" FEISHU_APP_SECRET="$APP_SECRET" node -e "
    (async () => {
      try {
        const resp = await fetch('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ app_id: process.env.FEISHU_APP_ID, app_secret: process.env.FEISHU_APP_SECRET })
        });
        const data = await resp.json();
        if (data.code === 0) {
          console.log('OK');
        } else {
          console.log('FAIL:' + data.msg);
        }
      } catch (e) {
        console.log('FAIL:' + e.message);
      }
    })();
  " 2>/dev/null)

  if [ "$TOKEN_RESULT" = "OK" ]; then
    success "飞书 API 连通正常"
  else
    FAIL_MSG=$(echo "$TOKEN_RESULT" | sed 's/FAIL://')
    warn "飞书 API 连通失败: $FAIL_MSG"
    echo "  请检查 App ID 和 App Secret 是否正确"
  fi
else
  warn "未配置凭证，跳过 API 验证"
fi

# ----- 完成 -----
header "安装完成 🎉"

echo -e "  ${BOLD}使用方式：${NC}"
echo ""
echo -e "  ${CYAN}node $SCRIPT_DIR/scripts/publish.js <markdown_file>${NC}"
echo ""
echo -e "  ${BOLD}配置文件：${NC}"
echo -e "  全局配置: ${GREEN}$CONFIG_ENV${NC}"
echo ""

if [ -L "$INSTALL_TARGET" ]; then
  echo -e "  ${BOLD}OpenClaw：${NC}"
  echo -e "  已安装到 ${GREEN}$INSTALL_TARGET${NC}"
  echo "  重启 OpenClaw 后即可通过自然语言调用"
  echo ""
fi

echo -e "  ${BOLD}更多信息：${NC}"
echo "  查看 SKILL.md 获取完整文档"
echo ""
