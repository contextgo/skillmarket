#!/usr/bin/env node

/**
 * 飞书文档发布脚本 — OpenClaw Skill
 *
 * 将 Markdown 文件发布为飞书在线文档，完整支持表格等复杂结构。
 *
 * 用法：
 *   node publish.js <markdown_file>
 *   node publish.js <markdown_file> --title "自定义标题"
 *   node publish.js <markdown_file> --folder <folder_token>
 */

const path = require('path');
const os = require('os');
const feishuApi = require('./feishu-api');
const localFile = require('./local-file');

// ============================================================
// 环境变量加载（优先级：全局配置 > 项目目录 > 已有环境变量）
// ============================================================

const GLOBAL_CONFIG_DIR = path.join(os.homedir(), '.config', 'feishu-doc-publisher');
const GLOBAL_ENV_PATH = path.join(GLOBAL_CONFIG_DIR, '.env');

try {
  const dotenv = require('dotenv');

  // 1. 优先加载全局配置 ~/.config/feishu-doc-publisher/.env
  if (localFile.fileExists(GLOBAL_ENV_PATH)) {
    dotenv.config({ path: GLOBAL_ENV_PATH });
    console.log(`🔑 已加载全局配置: ${GLOBAL_ENV_PATH}`);
  }

  // 2. 再加载项目目录下的 .env（不覆盖全局配置中已有的变量）
  const localEnvPath = path.join(process.cwd(), '.env');
  if (localFile.fileExists(localEnvPath)) {
    dotenv.config({ path: localEnvPath });
    console.log(`🔑 已加载项目配置: ${localEnvPath}`);
  }
} catch (_) {
  // dotenv 未安装时静默跳过
}

// ============================================================
// 配置
// ============================================================

const FEISHU_APP_ID = process.env.FEISHU_APP_ID;
const FEISHU_APP_SECRET = process.env.FEISHU_APP_SECRET;

if (!FEISHU_APP_ID || !FEISHU_APP_SECRET) {
  console.error('❌ 缺少环境变量 FEISHU_APP_ID 或 FEISHU_APP_SECRET');
  console.error('');
  console.error('   请在以下任一位置配置飞书应用凭证：');
  console.error(`   1. 全局配置: ${GLOBAL_ENV_PATH}`);
  console.error(`   2. 项目目录: ${path.join(process.cwd(), '.env')}`);
  console.error('   3. 系统环境变量');
  console.error('');
  console.error('   .env 文件格式：');
  console.error('   FEISHU_APP_ID=cli_xxxxxxxxx');
  console.error('   FEISHU_APP_SECRET=xxxxxxxxxxxxxxxx');
  process.exit(1);
}

// ============================================================
// 参数解析
// ============================================================

function parseArgs() {
  const args = process.argv.slice(2);
  const result = { filePath: null, title: null, folderToken: '' };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--title' && args[i + 1]) {
      result.title = args[++i];
    } else if (args[i] === '--folder' && args[i + 1]) {
      result.folderToken = args[++i];
    } else if (!args[i].startsWith('--')) {
      result.filePath = args[i];
    }
  }

  if (!result.filePath) {
    console.error('❌ 用法: node publish.js <markdown_file> [--title "标题"] [--folder <token>]');
    process.exit(1);
  }

  // 支持相对路径
  result.filePath = localFile.resolvePath(result.filePath);

  if (!localFile.fileExists(result.filePath)) {
    console.error(`❌ 文件不存在: ${result.filePath}`);
    process.exit(1);
  }

  return result;
}

// ============================================================
// 表格重建逻辑
// ============================================================

let _idSeq = 0;
function shortId(prefix) {
  return `${prefix}_${++_idSeq}`;
}

/**
 * 从 convert 返回的 block 中重建表格的 descendant 请求体。
 *
 * convert API 返回的表格 cell ID 格式为 rowXXXcolYYY（超长），
 * 该格式在 descendant 接口中会被拒绝，
 * 因此需要用简短的自定义临时 ID 重建整个表格结构。
 */
function rebuildTableForDescendant(tableBlock, blockMap) {
  const tableId = shortId('tbl');
  const descendants = [];
  const rowSize = tableBlock.table?.property?.row_size || 0;
  const colSize = tableBlock.table?.property?.column_size || 0;

  const newTableBlock = {
    block_id: tableId,
    block_type: 31,
    table: { property: { row_size: rowSize, column_size: colSize } },
    children: [],
  };

  const cellIds = tableBlock.children || [];
  for (const origCellId of cellIds) {
    const newCellId = shortId('cel');
    newTableBlock.children.push(newCellId);

    const origCell = blockMap[origCellId];
    const cellTextBlocks = [];

    if (origCell?.children) {
      for (const textBlockId of origCell.children) {
        const origText = blockMap[textBlockId];
        if (origText) {
          const newTextId = shortId('txt');
          cellTextBlocks.push(newTextId);

          const textBlock = { block_id: newTextId, block_type: origText.block_type };

          // 根据 block_type 设置对应字段
          const typeFieldMap = {
            2: 'text', 12: 'bullet', 13: 'ordered', 17: 'todo', 15: 'quote',
          };
          const fieldName = typeFieldMap[origText.block_type];
          if (fieldName && origText[fieldName]) {
            textBlock[fieldName] = {
              elements: origText[fieldName].elements.map(cleanTextElement),
            };
          } else {
            // 回退为普通文本
            textBlock.block_type = 2;
            textBlock.text = { elements: [{ text_run: { content: '' } }] };
          }

          descendants.push(textBlock);
        }
      }
    }

    // 如果 cell 没有内容，填一个空文本
    if (cellTextBlocks.length === 0) {
      const emptyId = shortId('txt');
      cellTextBlocks.push(emptyId);
      descendants.push({
        block_id: emptyId,
        block_type: 2,
        text: { elements: [{ text_run: { content: '' } }] },
      });
    }

    descendants.push({
      block_id: newCellId,
      block_type: 32,
      table_cell: {},
      children: cellTextBlocks,
    });
  }

  descendants.unshift(newTableBlock);
  return { children_id: [tableId], descendants };
}

function cleanTextElement(elem) {
  if (!elem.text_run) return elem;
  const result = { text_run: { content: elem.text_run.content } };
  const style = elem.text_run.text_element_style;
  if (style) {
    const s = {};
    if (style.bold) s.bold = true;
    if (style.italic) s.italic = true;
    if (style.strikethrough) s.strikethrough = true;
    if (style.underline) s.underline = true;
    if (style.inline_code) s.inline_code = true;
    if (style.link) s.link = style.link;
    if (Object.keys(s).length > 0) result.text_run.text_element_style = s;
  }
  return result;
}

function cleanBlockForChildren(block) {
  const cleaned = { ...block };
  delete cleaned.parent_id;
  delete cleaned.block_id;
  return cleaned;
}

// ============================================================
// 表格纯文本回退
// ============================================================

function tableToTextBlocks(tableBlock, blockMap) {
  const cellIds = tableBlock.children || [];
  const colSize = tableBlock.table?.property?.column_size || 1;
  const rows = [];
  let currentRow = [];

  for (const cellId of cellIds) {
    const cell = blockMap[cellId];
    let cellText = '';
    if (cell?.children) {
      for (const textId of cell.children) {
        const tb = blockMap[textId];
        if (tb?.text?.elements) {
          cellText += tb.text.elements.map((e) => e.text_run?.content || '').join('');
        }
      }
    }
    currentRow.push(cellText);
    if (currentRow.length === colSize) {
      rows.push(currentRow);
      currentRow = [];
    }
  }

  return rows.map((row) => ({
    block_type: 2,
    text: { elements: [{ text_run: { content: row.join(' | ') } }] },
  }));
}

// ============================================================
// 主流程
// ============================================================



async function main() {
  const { filePath, title: customTitle, folderToken } = parseArgs();

  // 读取 Markdown 文件
  const mdContent = localFile.readMarkdownContent(filePath);
  console.log(`📄 读取文件: ${path.basename(filePath)} (${mdContent.length} 字符)`);

  // 提取标题
  const titleMatch = mdContent.match(/^#\s+(.*)/m);
  const title = customTitle || (titleMatch ? titleMatch[1].trim() : path.basename(filePath, '.md'));
  const bodyContent = mdContent.replace(/^#\s+.*\n*/, '');
  console.log(`📝 文档标题: ${title}`);

  // 获取 token
  const token = await feishuApi.getTenantAccessToken(FEISHU_APP_ID, FEISHU_APP_SECRET);
  console.log('✅ 获取 tenant_access_token 成功');

  // 步骤1：convert Markdown → blocks
  console.log('🔄 转换 Markdown...');
  const { blocks, first_level_block_ids, block_id_to_image_urls } = await feishuApi.convertMarkdownToBlocks(token, bodyContent);
  console.log(`✅ 转换成功: ${blocks.length} 个 block, ${first_level_block_ids.length} 个顶层块`);

  const blockMap = {};
  for (const b of blocks) blockMap[b.block_id] = b;

  // 构建图片映射表
  const imageUrlMap = {};
  if (block_id_to_image_urls && block_id_to_image_urls.length > 0) {
    for (const item of block_id_to_image_urls) {
      imageUrlMap[item.block_id] = item.image_url;
    }
  }

  const tableCount = first_level_block_ids.filter((id) => blockMap[id]?.block_type === 31).length;
  console.log(`📋 包含 ${tableCount} 个表格`);

  // 步骤2：创建文档
  const documentId = await feishuApi.createDocument(token, title, folderToken);
  console.log(`✅ 文档创建成功: ${documentId}`);

  // 步骤3：分组插入
  console.log('📝 开始插入内容...');
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  let insertIndex = 0;
  let successCount = 0;
  let failCount = 0;
  let simpleBatch = [];

  async function flushSimpleBatch() {
    if (simpleBatch.length === 0) return;
    const batchBlocks = simpleBatch.map(cleanBlockForChildren);
    try {
      await feishuApi.insertChildren(token, documentId, documentId, batchBlocks, insertIndex);
      insertIndex += batchBlocks.length;
      successCount += batchBlocks.length;
    } catch (err) {
      // 逐个重试
      for (const block of batchBlocks) {
        try {
          await feishuApi.insertChildren(token, documentId, documentId, [block], insertIndex);
          insertIndex++;
          successCount++;
        } catch (_) {
          failCount++;
        }
        await delay(100);
      }
    }
    simpleBatch = [];
    await delay(200);
  }

  for (const blockId of first_level_block_ids) {
    const block = blockMap[blockId];
    if (!block) continue;

    if (block.block_type === 31) {
      await flushSimpleBatch();

      try {
        const { children_id, descendants } = rebuildTableForDescendant(block, blockMap);
        await feishuApi.insertDescendant(token, documentId, documentId, children_id, descendants, insertIndex);
        insertIndex++;
        successCount++;
      } catch (err) {
        failCount++;
        // 回退为纯文本
        try {
          const fb = tableToTextBlocks(block, blockMap);
          await feishuApi.insertChildren(token, documentId, documentId, fb, insertIndex);
          insertIndex += fb.length;
        } catch (_) { /* 忽略 */ }
      }
      await delay(300);
    } else if (block.block_type === 27) {
      await flushSimpleBatch();

      try {
        const respData = await feishuApi.insertChildren(token, documentId, documentId, [cleanBlockForChildren(block)], insertIndex);
        insertIndex++;
        successCount++;

        if (respData.data && respData.data.children && respData.data.children.length > 0) {
          const newBlockId = respData.data.children[0].block_id;
          const imgUrl = imageUrlMap[blockId];
          if (imgUrl) {
            const imgPath = path.resolve(path.dirname(filePath), imgUrl);
            if (localFile.fileExists(imgPath)) {
              console.log(`📸 上传图片: ${imgPath}`);
              const fileToken = await feishuApi.uploadImageData(token, newBlockId, localFile.readBinaryFile(imgPath));
              await feishuApi.updateBlockImage(token, documentId, newBlockId, fileToken);
            } else {
              console.warn(`⚠️ 图片文件不存在，无法上传: ${imgPath}`);
            }
          }
        }
      } catch (err) {
        console.error(`❌ 处理图片块失败: ${err.message}`);
        failCount++;
      }
      await delay(300);
    } else {
      simpleBatch.push(block);
    }
  }

  await flushSimpleBatch();

  // 输出结果（结构化，方便 AI agent 解析）
  console.log('');
  console.log('✅ 文档发布完成');
  console.log(`📄 文档标题: ${title}`);
  console.log(`📄 文档 ID: ${documentId}`);
  console.log(`🔗 文档链接: https://feishu.cn/docx/${documentId}`);
  console.log(`📊 成功: ${successCount}, 失败: ${failCount}`);
}

main().catch((err) => {
  console.error(`❌ 发布失败: ${err.message}`);
  process.exit(1);
});
