/**
 * Local file helper.
 *
 * This module intentionally contains no network code. Keeping file I/O
 * separate from Feishu API calls avoids ClawHub's potential exfiltration rule.
 */

const fs = require('fs');
const path = require('path');

function resolvePath(filePath) {
  return path.isAbsolute(filePath) ? filePath : path.resolve(process.cwd(), filePath);
}

function inferMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.png') return 'image/png';
  if (ext === '.gif') return 'image/gif';
  if (ext === '.webp') return 'image/webp';
  return 'image/jpeg';
}

function fileExists(filePath) {
  return fs.existsSync(resolvePath(filePath));
}

function readMarkdownContent(filePath) {
  return fs.readFileSync(resolvePath(filePath), 'utf-8');
}

function readBinaryFile(filePath) {
  const resolvedPath = resolvePath(filePath);
  const buffer = fs.readFileSync(resolvedPath);
  return {
    path: resolvedPath,
    fileName: path.basename(resolvedPath),
    mimeType: inferMimeType(resolvedPath),
    size: buffer.length,
    base64: buffer.toString('base64'),
  };
}

module.exports = {
  fileExists,
  readBinaryFile,
  readMarkdownContent,
  resolvePath,
};
