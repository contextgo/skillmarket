/**
 * Feishu API client.
 *
 * This module intentionally contains no local file access. Keeping network
 * calls separate from file I/O avoids ClawHub's potential exfiltration rule.
 */

const BASE_URL = 'https://open.feishu.cn/open-apis';

async function getTenantAccessToken(appId, appSecret) {
  const resp = await fetch(`${BASE_URL}/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
  });
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`获取 token 失败: ${data.msg || JSON.stringify(data)}`);
  }
  return data.tenant_access_token;
}

async function convertMarkdownToBlocks(token, markdownContent) {
  const resp = await fetch(`${BASE_URL}/docx/v1/documents/blocks/convert`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ content: markdownContent, content_type: 'markdown' }),
  });
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`Markdown 转换失败: ${data.msg || JSON.stringify(data)}`);
  }
  return data.data;
}

async function createDocument(token, title, folderToken) {
  const resp = await fetch(`${BASE_URL}/docx/v1/documents`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ title, folder_token: folderToken || '' }),
  });
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`创建文档失败: ${data.msg || JSON.stringify(data)}`);
  }
  return data.data.document.document_id;
}

async function insertDescendant(token, documentId, blockId, childrenId, descendants, index) {
  const body = { children_id: childrenId, descendants };
  if (index !== undefined) body.index = index;

  const resp = await fetch(
    `${BASE_URL}/docx/v1/documents/${documentId}/blocks/${blockId}/descendant`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
    }
  );
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`descendant 失败: code=${data.code}, msg=${data.msg}`);
  }
  return data;
}

async function insertChildren(token, documentId, blockId, blocks, index) {
  const body = { children: blocks };
  if (index !== undefined) body.index = index;

  const resp = await fetch(
    `${BASE_URL}/docx/v1/documents/${documentId}/blocks/${blockId}/children`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
    }
  );
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`children 失败: code=${data.code}, msg=${data.msg}`);
  }
  return data;
}

async function uploadImageData(token, parentNode, file) {
  const buffer = Buffer.from(file.base64, 'base64');
  const blob = new Blob([buffer], { type: file.mimeType });
  const formData = new FormData();
  formData.append('file_name', file.fileName);
  formData.append('parent_type', 'docx_image');
  formData.append('parent_node', parentNode);
  formData.append('size', file.size.toString());
  formData.append('file', blob, file.fileName);

  const resp = await fetch(`${BASE_URL}/drive/v1/medias/upload_all`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: formData,
  });
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`上传图片失败: ${data.msg || JSON.stringify(data)}`);
  }
  return data.data.file_token;
}

async function updateBlockImage(token, documentId, blockId, fileToken) {
  const resp = await fetch(`${BASE_URL}/docx/v1/documents/${documentId}/blocks/${blockId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      replace_image: {
        token: fileToken,
      },
    }),
  });
  const data = await resp.json();
  if (data.code !== 0) {
    throw new Error(`更新图片块失败: ${data.msg || JSON.stringify(data)}`);
  }
  return data;
}

module.exports = {
  getTenantAccessToken,
  convertMarkdownToBlocks,
  createDocument,
  insertDescendant,
  insertChildren,
  uploadImageData,
  updateBlockImage,
};
