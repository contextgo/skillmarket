# Feishu Doc Publisher (飞书文档发布工具)

这是一个基于 Node.js 的 OpenClaw Skill 脚本工具，用于将本地的 Markdown 文件自动转换并发布为飞书在线文档（DocX）。

## 特性

- 🚀 **自动化发布**: 一键将 Markdown 转换为飞书在线文档。
- 📊 **复杂结构支持**: 完整支持 Markdown 表格、列表、代码块等复杂富文本结构。
- 🔐 **灵活的凭证管理**: 支持通过全局配置、项目本地配置或系统环境变量加载飞书应用凭证。
- 🛡️ **安全合规**: 代码结构经过优化，符合严格的静态安全分析标准。

## 安装

```bash
# 安装依赖
npm install
```

## 配置

本工具需要飞书自建应用的 `FEISHU_APP_ID` 和 `FEISHU_APP_SECRET`。你可以通过以下任一方式配置环境变量：

1. **全局配置 (推荐)**: 
   在 `~/.config/feishu-doc-publisher/.env` 文件中配置。
2. **项目目录配置**: 
   在当前项目根目录的 `.env` 文件中配置。
3. **系统环境变量**: 
   直接在终端中导出相应的环境变量。

`.env` 文件格式如下：
```env
FEISHU_APP_ID=cli_xxxxxxxxx
FEISHU_APP_SECRET=xxxxxxxxxxxxxxxx
```

## 用法

基本用法：
```bash
node scripts/publish.js <markdown_file_path>
```

指定自定义文档标题：
```bash
node scripts/publish.js <markdown_file_path> --title "你的自定义标题"
```

发布到指定的飞书知识库目录（需要提供 Folder Token）：
```bash
node scripts/publish.js <markdown_file_path> --folder <folder_token>
```

## 注意事项

- 本工具依赖飞书的 Open API，确保你的飞书应用已经开启了相关的文档读写权限。
- 在大量包含超大表格的 Markdown 文件转换中，脚本具备完善的自动重试和降级策略（回退为纯文本表格），以保证最终文档创建成功。
