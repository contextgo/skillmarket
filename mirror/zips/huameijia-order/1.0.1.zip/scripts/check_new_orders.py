#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
定时查询最新订单脚本
每5分钟执行一次，检测是否有新订单
"""

import os
import sys
import json
import time
from datetime import datetime, timedelta

# 添加脚本目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from xiangbin_api import query_orders

# 状态文件路径
STATE_FILE = os.path.join(os.path.dirname(__file__), ".order_state.json")


def load_last_state():
    """加载上次查询状态"""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"last_check": None, "last_order_id": None}


def save_state(state):
    """保存查询状态"""
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False)


def format_order(order):
    """格式化订单信息"""
    lines = [
        f"订单号: {order.get('orderId', 'N/A')}",
        f"收货人: {order.get('receiverName', 'N/A')}",
        f"手机号: {order.get('receiverMobile', 'N/A')}",
        f"地址: {order.get('receiverState', '')}{order.get('receiverCity', '')}{order.get('receiverDistrict', '')}{order.get('receiverAddress', '')}",
        f"金额: ¥{order.get('orderAmount', 0)}",
        f"送达时间: {order.get('sendTime', 'N/A')} {order.get('sh', 0):02d}:{order.get('sm', 0):02d}",
        f"备注: {order.get('remark', '无')}",
    ]
    return "\n".join(lines)


def check_new_orders():
    """检查新订单"""
    state = load_last_state()

    # 查询最近订单（近7天）
    today = datetime.now()
    start_date = (today - timedelta(days=7)).strftime("%Y-%m-%d")
    end_date = today.strftime("%Y-%m-%d")

    result = query_orders(page=1, page_size=50, start_date=start_date, end_date=end_date)

    if result.get("code") != 1:
        print(f"[ERROR] 查询失败: {result.get('msg', '未知错误')}")
        return []

    orders = result.get("data", {}).get("list", [])
    if not orders:
        return []

    # 获取上次已知的最新订单ID
    last_order_id = state.get("last_order_id")

    # 找出新订单（假设订单按时间倒序排列）
    new_orders = []
    for order in orders:
        order_id = str(order.get("orderId", ""))
        if order_id and order_id != last_order_id:
            new_orders.append(order)
        else:
            break

    # 更新状态
    if orders:
        state["last_order_id"] = str(orders[0].get("orderId", ""))
    state["last_check"] = int(time.time())
    save_state(state)

    return new_orders


def main():
    """主函数"""
    try:
        new_orders = check_new_orders()
        if new_orders:
            print(f"发现 {len(new_orders)} 个新订单！")
            print("=" * 40)
            for i, order in enumerate(new_orders, 1):
                print(f"\n【新订单 {i}】")
                print(format_order(order))
                print("-" * 40)
            # 返回非0状态码表示有新订单，方便外部脚本判断
            return 1
        else:
            print("暂无新订单")
            return 0
    except Exception as e:
        print(f"[ERROR] 检查订单时出错: {e}")
        return 2


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)