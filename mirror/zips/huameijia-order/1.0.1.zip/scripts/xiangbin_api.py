#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
香槟玫瑰鲜花平台 API 调用库
https://xcx.xiangbinmeigui.com/api/Platform/Take
"""

import os
import time
import random
import string
import hashlib
import json
import urllib.request
import urllib.parse


API_URL = "https://xcx.xiangbinmeigui.com/api/Platform/Take"

APPID = os.environ.get("XBMG_APPID", "")
SECRET = os.environ.get("XBMG_SECRET", "")


def _check_config():
    if not APPID or not SECRET:
        raise ValueError("环境变量 XBMG_APPID 或 XBMG_SECRET 未设置")


def generate_sign(params: dict) -> str:
    """
    生成 MD5 签名
    1. 参数按 key 的 ASCII 升序排列
    2. 拼接 key=value& 格式
    3. 末尾追加 secret=密钥
    4. MD5 加密后转大写
    """
    sorted_keys = sorted(params.keys())
    parts = []
    for k in sorted_keys:
        v = params[k]
        if isinstance(v, (list, dict)):
            v = json.dumps(v, ensure_ascii=False)
        parts.append(f"{k}={v}")
    query_str = "&".join(parts) + f"&secret={SECRET}"
    return hashlib.md5(query_str.encode("utf-8")).hexdigest().upper()


def _build_sys_params():
    """构建系统级参数"""
    nonce = "".join(random.choices(string.ascii_letters + string.digits, k=16))
    return {
        "appid": APPID,
        "timestamp": str(int(time.time())),
        "nonce": nonce,
    }


def _post(params: dict, data: dict = None):
    """发送 POST 请求"""
    _check_config()

    sys_params = _build_sys_params()

    # 合并所有参数（含 data 序列化）
    all_params = dict(sys_params)
    if data is not None:
        all_params["act"] = params.get("act", "")
        all_params["data"] = json.dumps(data, ensure_ascii=False)
    else:
        for k, v in params.items():
            if k != "sign":
                all_params[k] = v

    # 生成签名
    all_params["sign"] = generate_sign(all_params)

    # 发送请求
    body = urllib.parse.urlencode(all_params).encode("utf-8")
    req = urllib.request.Request(API_URL, data=body, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")

    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def add_order(
    rsid: int,
    sid: int,
    send_time: str,
    order_id: str,
    order_amount: float,
    buyer_mobile: str,
    send_type: int,
    receiver_name: str,
    receiver_mobile: str,
    receiver_address: str,
    receiver_city: str,
    receiver_district: str,
    receiver_state: str,
    remark: str = "",
    card: str = "",
    sh: int = 0,
    sm: int = 0,
    hh: int = 0,
    mm: int = 0,
    products: list = None,
) -> dict:
    """
    下单接口
    act = AddOrder
    """
    if products is None:
        products = []

    data = {
        "rsid": rsid,
        "sid": sid,
        "sendTime": send_time,
        "orderId": order_id,
        "orderAmount": order_amount,
        "buyerMobile": str(buyer_mobile),
        "sendType": send_type,
        "receiverName": receiver_name,
        "receiverMobile": str(receiver_mobile),
        "receiverAddress": receiver_address,
        "receiverCity": receiver_city,
        "receiverDistrict": receiver_district,
        "receiverState": receiver_state,
        "remark": remark,
        "card": card,
        "sh": sh,
        "sm": sm,
        "hh": hh,
        "mm": mm,
        "products": products,
    }

    return _post({"act": "AddOrder"}, data)


def query_orders(
    page: int = 1,
    page_size: int = 100,
    start_date: str = None,
    end_date: str = None,
) -> dict:
    """
    订单查询接口
    act = OrderQuery
    """
    if start_date is None:
        # 默认查近30天
        start_date = "2020-01-01"
    if end_date is None:
        end_date = "2030-01-01"

    data = {
        "pageNumber": page,
        "pageSize": page_size,
        "st": start_date,
        "et": end_date,
    }

    return _post({"act": "OrderQuery"}, data)


def order_send(tid: int) -> dict:
    """
    订单配送接口
    act = OrderSend
    """
    data = {"tid": tid}
    return _post({"act": "OrderSend"}, data)


if __name__ == "__main__":
    # 测试：查询订单
    print("测试查询订单...")
    result = query_orders()
    print(json.dumps(result, ensure_ascii=False, indent=2))