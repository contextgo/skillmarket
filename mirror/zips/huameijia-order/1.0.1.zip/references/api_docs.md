# 香槟玫瑰鲜花平台 API 文档

## 接口地址

```
POST https://xcx.xiangbinmeigui.com/api/Platform/Take
```

---

## 系统级参数

所有请求必须包含以下参数：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| appid | string | 是 | 应用标识，用于标识调用方身份 |
| timestamp | long | 是 | 时间戳（秒级，10位数字），防止请求重放 |
| nonce | string | 是 | 随机字符串，增强签名安全性 |
| sign | string | 是 | MD5签名（大写），验证请求合法性 |

---

## 签名生成步骤

1. **参数排序**：将所有请求参数（不包括 sign）按参数名的字典序（ASCII码）升序排列
2. **构建查询字符串**：将排序后的参数拼接成 `key=value&` 的格式
3. **拼接密钥**：在查询字符串末尾添加 `secret=平台密钥`
4. **MD5加密**：对拼接后的字符串进行 MD5 加密
5. **转大写**：将 MD5 结果转换为大写字符串，即为最终签名

### 签名示例

假设参数为：
```
appid=5809063816854D32A031014BB0F0D883
nonce=abc123
timestamp=1745824000
act=OrderQuery
```

排序后：
```
act=OrderQuery&appid=5809063816854D32A031014BB0F0D883&nonce=abc123&timestamp=1745824000
```

拼接密钥：
```
act=OrderQuery&appid=5809063816854D32A031014BB0F0D883&nonce=abc123&timestamp=1745824000&secret=9999
```

MD5 加密后转大写：
```
sign = MD5(上述字符串).toUpperCase()
```

---

## 业务接口

### 1. 下单接口

**act**: `AddOrder`

**请求参数**（data 字段的 JSON 内容）：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| rsid | int | 是 | 门店ID |
| sid | int | 是 | 店铺ID |
| sendTime | string | 是 | 送达日期，格式：YYYY-MM-DD |
| orderId | string | 是 | 订单号 |
| orderAmount | float | 是 | 订单金额 |
| buyerMobile | string | 是 | 买家手机号 |
| sendType | int | 是 | 配送方式：1=配送，2=自取 |
| receiverName | string | 是 | 收货人姓名 |
| receiverMobile | string | 是 | 收货人手机号 |
| receiverAddress | string | 是 | 收货地址 |
| receiverCity | string | 是 | 收货城市 |
| receiverDistrict | string | 是 | 收货区县 |
| receiverState | string | 是 | 收货省份 |
| remark | string | 否 | 备注 |
| card | string | 否 | 贺卡内容 |
| sh | int | 否 | 送达时间-时 |
| sm | int | 否 | 送达时间-分 |
| hh | int | 否 | 送达时间-时（备用） |
| mm | int | 否 | 送达时间-分（备用） |
| products | array | 是 | 商品列表 |

**products 结构**：

| 字段 | 类型 | 说明 |
|------|------|------|
| name | string | 商品名称 |
| num | int | 数量 |
| price | float | 单价 |
| path | string | 商品图片URL |

**请求示例**：
```json
{
  "rsid": 99,
  "sid": 88,
  "sendTime": "2020-9-9",
  "orderId": "123",
  "orderAmount": 100,
  "buyerMobile": "136",
  "sendType": 1,
  "receiverName": "张三",
  "receiverMobile": "139",
  "receiverAddress": "地址",
  "receiverCity": "深圳",
  "receiverDistrict": "罗湖",
  "receiverState": "广东",
  "remark": "备注",
  "card": "贺卡",
  "sh": 10,
  "sm": 30,
  "products": [
    {
      "name": "11支玫瑰",
      "num": 1,
      "price": 100,
      "path": "https://..."
    }
  ]
}
```

---

### 2. 订单查询接口

**act**: `OrderQuery`

**请求参数**（data 字段的 JSON 内容）：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| pageNumber | int | 是 | 页码，从1开始 |
| pageSize | int | 是 | 每页数量 |
| st | string | 是 | 开始日期，格式：YYYY-MM-DD |
| et | string | 是 | 结束日期，格式：YYYY-MM-DD |

**请求示例**：
```json
{
  "pageNumber": 1,
  "pageSize": 100,
  "st": "2020-1-1",
  "et": "2030-1-1"
}
```

---

### 3. 订单配送接口

**act**: `OrderSend`

**请求参数**（data 字段的 JSON 内容）：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| tid | int | 是 | 订单ID |

**请求示例**：
```json
{
  "tid": 1
}
```

---

## 返回结果格式

```json
{
  "code": 1,
  "msg": "success",
  "data": {}
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码：1表示成功，其他表示失败 |
| msg | string | 响应消息 |
| data | object | 响应数据，内容根据接口不同而变化 |

---

## 注意事项

1. **参数类型**：所有参数必须为字符串类型（timestamp 除外）
2. **时间戳**：使用秒级时间戳（10位数字）
3. **随机字符串**：nonce 用于防止重放攻击，建议使用16位随机字符串
4. **密钥保管**：secret 密钥请妥善保管，不要泄露
5. **签名验证**：服务端会验证签名，签名错误会返回失败