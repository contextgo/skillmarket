---
name: xiangbin-flower-api
description: 花美家AI花店鲜花平台 API 技能。提供下单、订单查询、订单配送等接口调用能力，支持 MD5 签名生成。当用户提到鲜花下单、订单查询、订单配送等场景时使用此技能。
---

# 鲜花平台 API 技能

## 快速开始

本技能封装鲜花平台（xcx.xiangbinmeigui.com）的全部 API 接口。

### 核心文件

| 文件 | 用途 |
|------|------|
| `scripts/xiangbin_api.py` | API 调用核心库（签名、下单、查询、配送） |
| `references/api_docs.md` | 完整 API 接口文档 |

### 环境变量（需要咨询用户获取，并保存环境变量）

| 变量名 | 说明 |
|--------|------|
| `XBMG_APPID` | 应用标识 |
| `XBMG_SECRET` | 平台密钥 |

---

## 接口地址

```
POST https://xcx.xiangbinmeigui.com/api/Platform/Take
```

## 系统级参数（所有请求必带）

| 参数 | 类型 | 说明 |
|------|------|------|
| appid | string | 应用标识，从环境变量 `XBMG_APPID` 读取 |
| timestamp | long | 秒级时间戳（10位），当前时间秒数 |
| nonce | string | 随机字符串（建议16位） |
| sign | string | MD5签名（大写），见下方签名规则 |

## 签名生成规则

1. 将所有请求参数（不含 sign）按参数名 ASCII 升序排列
2. 拼接为 `key=value&` 格式
3. 末尾添加 `secret=密钥`（从环境变量 `XBMG_SECRET` 读取）
4. 对整体做 MD5 加密，结果转大写

**参考实现**：直接使用 `scripts/xiangbin_api.py` 中的 `generate_sign()` 函数，无需手动计算。

---

## 业务接口

### 1. 下单接口

```python
from scripts.xiangbin_api import add_order

result = add_order(
    rsid=99,
    sid=88,
    send_time="2020-9-9",
    order_id="123",
    order_amount=100,
    buyer_mobile="136",
    send_type=1,       # 1=配送, 2=自取
    receiver_name="张三",
    receiver_mobile="139",
    receiver_address="地址",
    receiver_city="深圳",
    receiver_district="罗湖",
    receiver_state="广东",
    remark="备注",
    card="贺卡",
    sh=10,sm=30,hh=12, mm=30,      # 送达时间：10:30-12:30
    products=[
        {"name": "11支玫瑰", "num": 1, "price": 100, "path": "https://..."}
    ]
)
```

### 2. 订单查询接口

```python
from scripts.xiangbin_api import query_orders

# 查询最近订单（默认查近30天）
result = query_orders(page=1, page_size=100)

# 自定义时间范围
result = query_orders(page=1, page_size=100, start_date="2025-01-01", end_date="2025-12-31")
```

### 3. 订单配送接口

```python
from scripts.xiangbin_api import order_send

result = order_send(tid=1)  # tid 为订单号
```

---

## 返回结果格式

```json
{
  "code": 1,   // 1=成功，其他=失败
  "msg": "success",
  "data": {}
}
```

---

## 定时查询配置

每 5 分钟自动查询最新订单并通知用户。详见 `references/cron_config.md`。