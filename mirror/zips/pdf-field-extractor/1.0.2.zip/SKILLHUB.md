# PDF Field Extractor

**Slug:** `pdf-field-extractor`
**Name:** PDF Field Extractor
**Category:** Productivity / Document Processing
**Tags:** `pdf`, `extraction`, `AI`, `invoice`, `contract`, `Excel`, `JSON`, `OCR`, `batch`

---

## Description

AI-powered PDF structured data extraction — extract key fields from invoices, contracts, receipts, bank statements, and more into Excel or JSON format.

**Supported document types:** Invoice, Contract, Receipt, Bank Statement, Business License, ID Card, Express Waybill, Generic Document.

---

## Features

- **Multi-format PDF Support** — Native PDF, scanned PDF (OCR), OFD, XML electronic invoices
- **Auto Document Type Detection** — Identifies invoice / contract / receipt / bank statement / license / ID / waybill / generic
- **AI Field Extraction** — Model-agnostic (OpenAI-compatible), user provides their own API key
- **OCR for Scanned PDFs** — Tesseract-based OCR with Chinese/English/Japanese/Korean support
- **Batch Processing** — Process multiple PDFs simultaneously with parallel workers
- **Dual Output Formats** — Excel (.xlsx) and JSON with structured field mapping
- **Feishu Native** — Push extraction results to Feishu channels

---

## Pricing

| Tier | Price | Pages/Mo | Doc Types | Output |
|------|-------|:--------:|-----------|--------|
| **FREE** | ¥0 | 10 | Invoice only | Text |
| **Basic** | ¥9.9/mo | 200 | 4 types | Excel |
| **Standard** | ¥29/mo | 1,000 | All types | Excel + batch |
| **Pro** | ¥69/mo | Unlimited | All types | JSON + priority |
| **Enterprise** | ¥149/mo | Unlimited | All types | Multi-lang OCR + custom templates |

---

## Requirements

### System Requirements
- Python 3.8+
- Tesseract OCR (for scanned PDFs)

### Python Dependencies
```
pymupdf>=1.23.0
pdfplumber>=0.10.0
pytesseract>=0.3.10
pandas>=2.0.0
openpyxl>=3.0.0
Pillow>=10.0.0
requests>=2.28.0
```

### System-level Dependencies
**Tesseract OCR** (Ubuntu/Debian):
```bash
sudo apt install tesseract-ocr tesseract-ocr-chi-sim tesseract-ocr-jpn tesseract-ocr-kor
```

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt
# Install Tesseract OCR (Ubuntu)
sudo apt install tesseract-ocr tesseract-ocr-chi-sim

# Extract from PDF
python scripts/pdf_extractor.py document.pdf --doc-type invoice --output result.xlsx

# Batch process
python scripts/batch_processor.py --input ./invoices/ --doc-type invoice --output ./results/
```

---

## Core Modules

### PDF Text Extraction (`scripts/pdf_extractor.py`)
- **PyMuPDF**: High-speed text extraction from native PDFs
- **pdfplumber**: Table structure preservation
- **Auto-detection**: Text layer vs scanned PDF → triggers OCR if needed

```python
from scripts.pdf_extractor import extract_pdf_text

text, tables, is_scanned = extract_pdf_text("document.pdf")
```

### OCR Processing (`scripts/ocr_processor.py`)
- **pytesseract**: Local OCR engine, multi-language support
- **Image preprocessing**: Denoise + contrast enhancement

```python
from scripts.ocr_processor import process_ocr

ocr_text = process_ocr(image_path, lang="chi_sim+eng")
```

### AI Field Extraction (`scripts/field_extractor.py`)
- **Model-agnostic**: OpenAI-compatible API format
- **User-owned API key**: Key stored in user environment, not stored by skill

```python
from scripts.field_extractor import extract_fields

fields = extract_fields(
    text="Invoice No: 12345678\nDate: 2024-01-01\nAmount: 1000.00",
    doc_type="invoice",
    api_key="sk-xxx",           # User's own API key
    model="gpt-4o",
)
```

### Document Type Detection (`scripts/doc_type_identifier.py`)
- **Auto-identify**: invoice / contract / license / ID card / receipt / bank_statement / express / generic
- **Keyword + AI hybrid**

```python
doc_type = identify_doc_type(text)
# Returns: "invoice" | "contract" | "license" | "id_card" | "receipt" | "bank_statement" | "express" | "generic"
```

### Output Generation (`scripts/output_generator.py`)
```python
from scripts.output_generator import generate_excel, generate_json

generate_excel(fields, "output.xlsx")
generate_json(fields, "output.json")
```

---

## Supported Document Types

| Type | Key Fields Extracted |
|------|---------------------|
| Invoice (VAT) | Invoice code, number, date, amount, tax, buyer/seller, tax ID |
| Contract | Parties, date, amount, payment terms, breach clauses |
| Receipt | Merchant, date, amount, payment method |
| Bank Statement | Transaction date, description, debit, credit, balance |
| Business License | Company name, legal representative, registered capital |
| ID Card | Name, gender, nationality, address, ID number |
| Express Waybill | Sender, receiver, weight, shipping fee |
| Generic | User-specified custom fields |

---

## Batch Processing

```python
from scripts.batch_processor import process_batch

results = process_batch(
    pdf_files=["doc1.pdf", "doc2.pdf", "doc3.pdf"],
    doc_type="invoice",
    api_key="sk-xxx",
    max_workers=4,
)
generate_excel(results, "batch_output.xlsx")
```

---

## File Structure

```
pdf-field-extractor/
├── SKILL.md              # Skill definition
├── README.md            # Documentation
├── SKILLHUB.md          # Tencent Skillhub listing (this file)
├── requirements.txt     # Python dependencies
└── scripts/
    ├── pdf_extractor.py      # PDF text extraction
    ├── ocr_processor.py      # OCR for scanned PDFs
    ├── field_extractor.py    # AI field extraction
    ├── doc_type_identifier.py # Document type detection
    ├── output_generator.py   # Excel/JSON output
    ├── batch_processor.py    # Batch processing
    └── tier_config.py        # Tier limits
```

---

## FAQ

| Question | Answer |
|----------|--------|
| How to handle scanned PDFs? | Auto-detects text layer absence → triggers Tesseract OCR automatically |
| API key configuration? | User configures in their own environment; skill does not store keys |
| Output formats? | Excel (.xlsx) and JSON; batch mode defaults to Excel |
| OCR accuracy? | Ensure 300dpi+ image clarity; supports Chinese, English, Japanese, Korean |

> For paid plans, visit [YK-Global.com](https://yk-global.com)
