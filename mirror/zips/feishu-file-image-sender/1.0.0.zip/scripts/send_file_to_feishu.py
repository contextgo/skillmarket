#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
飞书文件传输脚本
用法: python send_file_to_feishu.py <文件路径> <user_open_id>
依赖: requests (需安装: pip install requests)
配置文件位置: ~/.openclaw/openclaw.json
"""

import sys
import json
import os
import requests
from pathlib import Path
from requests_toolbelt import MultipartEncoder

# 飞书 API 端点
TOKEN_URL = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
UPLOAD_FILE_URL = "https://open.feishu.cn/open-apis/im/v1/files"
UPLOAD_IMAGE_URL = "https://open.feishu.cn/open-apis/im/v1/images"
SEND_MSG_URL = "https://open.feishu.cn/open-apis/im/v1/messages"

# 文件大小限制 (30 MB)
MAX_FILE_SIZE = 30 * 1024 * 1024
# 图片大小限制 (10 MB)
MAX_IMAGE_SIZE = 10 * 1024 * 1024

# 扩展名到飞书文件类型的映射
EXTENSION_TO_TYPE = {
    # 音频
    '.opus': 'opus',
    # 视频
    '.mp4': 'mp4',
    # 文档
    '.pdf': 'pdf',
    '.doc': 'doc',
    '.docx': 'doc',      # docx 也映射为 doc
    '.xls': 'xls',
    '.xlsx': 'xls',      # xlsx 映射为 xls
    '.ppt': 'ppt',
    '.pptx': 'ppt',      # pptx 映射为 ppt
}

IMAGE_TYPE = [".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".ico", ".tiff", ".heic"]

def load_config(account_name):
    """读取 ~/.openclaw/openclaw.json 并返回飞书 app_id, app_secret"""
    home_dir = os.path.expanduser("~")
    config_dir = os.path.join(home_dir, ".openclaw")
    config_path = os.path.join(config_dir, "openclaw.json")
    
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    channels = config.get("channels")
    if not channels:
        raise KeyError("配置文件中缺少 'channels' 字段")
    
    feishu = channels.get("feishu")
    if not feishu:
        raise KeyError("配置文件中 'channels' 下缺少 'feishu' 字段")
    if not feishu.get("accounts"):
        app_id = feishu.get("appId")
        app_secret = feishu.get("appSecret")
    else:
        app_id = feishu.get("accounts").get(account_name).get("appId")
        app_secret = feishu.get("accounts").get(account_name).get("appSecret")
    
    if not app_id or not app_secret:
        raise KeyError("飞书配置中缺少 appId 或 appSecret")
    
    return app_id, app_secret

def get_file_type(file_path):
    """
    根据文件扩展名判断飞书文件类型
    返回: 'opus', 'mp4', 'pdf', 'doc', 'xls', 'ppt', 或默认 'stream'
    """
    ext = Path(file_path).suffix.lower()
    if ext in IMAGE_TYPE:
        return "image"
    file_type = EXTENSION_TO_TYPE.get(ext, 'stream')
    return file_type

def get_tenant_access_token(app_id, app_secret):
    """获取 tenant_access_token"""
    payload = {
        "app_id": app_id,
        "app_secret": app_secret
    }
    resp = requests.post(TOKEN_URL, json=payload, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    if data.get("code") != 0:
        raise Exception(f"获取 token 失败: {data.get('msg')}")
    return data["tenant_access_token"]

def upload_file(token, file_path):
    """上传文件到飞书，返回 file_key"""
    file_type = get_file_type(file_path)
    
    with open(file_path, 'rb') as f:
        form = {'file_type': file_type,
        'file_name': os.path.basename(file_path),
        'file':  (os.path.basename(file_path), f)} 
        multi_form = MultipartEncoder(form)
        headers = {
            "Authorization": f"Bearer {token}",
        }
        headers['Content-Type'] = multi_form.content_type
        resp = requests.post(UPLOAD_FILE_URL, headers=headers, data=multi_form, timeout=60)
        resp.raise_for_status()
        result = resp.json()
        if result.get("code") != 0:
            raise Exception(f"上传文件失败: {result.get('msg')}")
        file_key = result.get("data", {}).get("file_key")
        if not file_key:
            raise Exception("上传响应中未找到 file_key")
        return file_key

def upload_image(token, file_path):
    with open(file_path, 'rb') as f:
        form = {
                'image_type': "message",
                'image':  f
            } 
        multi_form = MultipartEncoder(form)
        headers = {
            "Authorization": f"Bearer {token}",
        }
        headers['Content-Type'] = multi_form.content_type
        resp = requests.post(UPLOAD_IMAGE_URL, headers=headers, data=multi_form, timeout=60)
        resp.raise_for_status()
        result = resp.json()
        if result.get("code") != 0:
            raise Exception(f"上传图片失败: {result.get('msg')}")
        image_key = result.get("data", {}).get("image_key")
        if not image_key:
            raise Exception("上传响应中未找到 image_key")
        return image_key


def send_file_message(token, user_open_id, file_key, file_type):
    """发送文件消息给指定用户"""
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    if file_type == "image":
        msg_type = "image"
    elif file_type == "mp4":
        msg_type = "media"
    elif file_type == "opus":
        msg_type = "audio"
    else:
        msg_type = "file"
    if msg_type == "image":
        content = json.dumps({"image_key": file_key})
    else:
        content = json.dumps({"file_key": file_key})

    payload = {
        "receive_id": user_open_id,
        "msg_type": msg_type,
        "content": content
    }
    params = {"receive_id_type":"open_id"}
    resp = requests.post(SEND_MSG_URL, headers=headers, params=params, data=json.dumps(payload), timeout=30)
    resp.raise_for_status()
    result = resp.json()
    if result.get("code") != 0:
        raise Exception(f"发送消息失败: {result.get('msg')}")
    return result


def main():
    if len(sys.argv) != 4:
        print(json.dumps({"success": False, "error": "用法: python send_file_to_feishu.py "
                                                     "<文件路径> <user_open_id> <account_name>"}))
        sys.exit(1)

    file_path = sys.argv[1]
    user_open_id = sys.argv[2]
    account_name = sys.argv[3]

    # 1. 读取配置
    try:
        app_id, app_secret = load_config(account_name)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"读取配置失败: {str(e)}"}))
        sys.exit(1)

    # 2. 检查文件是否存在
    if not os.path.exists(file_path):
        print(json.dumps({"success": False, "error": f"文件不存在: {file_path}"}))
        sys.exit(1)

    # 3. 判断文件类型（打印日志或可选验证，但不阻止上传）
    file_type = get_file_type(file_path)
    # print(f"文件类型为{file_type}")

    max_size = MAX_FILE_SIZE if file_type == 'image' else MAX_FILE_SIZE

    # 4. 检查文件大小
    file_size = os.path.getsize(file_path)

    if file_size > max_size:
        print(json.dumps({"success": False, "error": f"文件大小 {file_size} 超大小限制"}))
        sys.exit(1)


    # 5. 获取 token
    try:
        token = get_tenant_access_token(app_id, app_secret)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"获取 access_token 失败: {str(e)}"}))
        sys.exit(1)

    # 6. 上传文件
    try:
        if file_type == 'image':
            file_key = upload_image(token, file_path)
        else:
            file_key = upload_file(token, file_path)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"上传文件失败: {str(e)}"}))
        sys.exit(1)

    # 8. 发送消息
    try:
        send_result = send_file_message(token, user_open_id, file_key, file_type)
        print(json.dumps({
            "success": True,
            "file_key": file_key,
            "file_type": file_type,
            "message": "文件已发送",
            "send_response": send_result
        }))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "file_key": file_key,
            "error": f"发送消息失败: {str(e)}"
        }))
        sys.exit(1)

if __name__ == "__main__":
    main()