---
name: feishu-file-sender
description: 将本地文件发送给飞书用户。上传文件并发送消息。用户发送图片，发送文件时调用。需要 openclaw.json 中配置飞书 appId 与 appSecret。
---

# 飞书文件发送技能

## 功能

- 接收用户提供的**文件路径**、**目标用户的 open_id**和**当前飞书账户对应openclaw.json中channel配置的account名称**
- 通过飞书 IM 发送文件消息给目标用户
- 输出结构化的 JSON 结果（成功或失败）


## 调用方式

OpenClaw 执行本技能时，应使用以下命令模板：

```bash
python scripts/send_file_image_to_feishu.py <文件路径> <user_open_id> <account_name>
```

## 依赖

- Python 3.6+
- `requests` 库（若未安装，执行 `pip install requests`）