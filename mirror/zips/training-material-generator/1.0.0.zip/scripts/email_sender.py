#!/usr/bin/env python3
"""
培训材料邮件发送脚本
支持：培训通知、材料分发、考核通知等场景
支持附件发送（Word文档等）
"""

import sys
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
from datetime import datetime


# ==================== 邮件模板 ====================

EMAIL_TEMPLATES = {
    "training_notification": """
{recipient_name}您好，

{company_name}将于近期组织以下培训，请准时参加：

📚 培训名称：{training_name}
🎯 培训目标：{training_objective}
📅 培训时间：{training_time}
📍 培训地点：{training_location}
👤 培训讲师：{trainer}
⏰ 培训时长：{duration}

📋 培训大纲及预习材料已随邮件附上，请提前阅读。

如有时间冲突，请提前与培训负责人沟通。

此致
{company_name}培训部
{contact_email}
    """,

    "material_distribution": """
{recipient_name}您好，

以下是{training_name}的培训材料，请查收：

📦 包含材料：
{material_list}

📌 使用说明：
1. 请在培训前完成预习
2. 培训中请携带电子版或纸质版材料
3. 如有问题，请联系培训负责人

祝学习顺利！

此致
{company_name}培训部
    """,

    "exam_notification": """
{recipient_name}您好，

{training_name}培训考核安排如下：

📝 考核名称：{exam_title}
📅 考核时间：{exam_time}
📍 考核地点：{exam_location}
⏰ 考核时长：{duration}分钟
✅ 及格分数：{passing_score}分

📌 注意事项：
1. 请携带身份证件参加考核
2. 考核为闭卷形式，请勿携带参考资料
3. 请提前10分钟到达考场

考核范围和复习要点已随邮件附上。

此致
{company_name}培训部
    """,

    "training_reminder": """
{recipient_name}您好，

温馨提醒：{training_name}培训即将开始！

📅 培训时间：{training_time}
📍 培训地点：{training_location}
👤 培训讲师：{trainer}

请做好以下准备：
1. 完成预习材料的阅读
2. 携带笔记本电脑（如需实操）
3. 准备好个人疑问，课堂上互动讨论

期待您的参与！

此致
{company_name}培训部
    """
}


def send_email(smtp_config, recipient, subject, body, is_html=False, attachments=None):
    """
    发送邮件
    smtp_config: SMTP配置字典
    recipient: 收件人邮箱
    subject: 邮件主题
    body: 邮件正文
    is_html: 是否HTML格式
    attachments: 附件文件路径列表
    """
    try:
        msg = MIMEMultipart()
        msg['From'] = f"{smtp_config.get('sender_name', '')} <{smtp_config['sender_email']}>"
        msg['To'] = recipient
        msg['Subject'] = subject

        # 邮件正文
        if is_html:
            msg.attach(MIMEText(body, 'html', 'utf-8'))
        else:
            msg.attach(MIMEText(body, 'plain', 'utf-8'))

        # 添加附件
        if attachments:
            for file_path in attachments:
                file_path = Path(file_path)
                if not file_path.exists():
                    print(f"警告: 附件不存在，已跳过: {file_path}")
                    continue

                with open(file_path, 'rb') as f:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(f.read())

                encoders.encode_base64(part)

                # 处理中文文件名
                filename = file_path.name
                try:
                    part.add_header(
                        'Content-Disposition',
                        'attachment',
                        filename=('utf-8', '', filename)
                    )
                except Exception:
                    part.add_header('Content-Disposition', 'attachment', filename=filename)

                msg.attach(part)

        # 连接 SMTP 服务器
        use_ssl = smtp_config.get('use_ssl', False)
        smtp_port = smtp_config.get('smtp_port', 465 if use_ssl else 587)

        if use_ssl:
            server = smtplib.SMTP_SSL(smtp_config['smtp_server'], smtp_port)
        else:
            server = smtplib.SMTP(smtp_config['smtp_server'], smtp_port)
            server.starttls()

        server.login(smtp_config['username'], smtp_config['password'])
        server.sendmail(smtp_config['sender_email'], recipient, msg.as_string())
        server.quit()

        return {"success": True, "message": f"邮件已发送至 {recipient}"}

    except Exception as e:
        return {"success": False, "error": str(e)}


def generate_email_content(template_name, data):
    """根据模板生成邮件内容"""
    if template_name not in EMAIL_TEMPLATES:
        return {"error": f"未找到模板: {template_name}，可用模板: {', '.join(EMAIL_TEMPLATES.keys())}"}

    template = EMAIL_TEMPLATES[template_name]
    content = template
    for key, value in data.items():
        placeholder = "{" + key + "}"
        content = content.replace(placeholder, str(value))

    return {"content": content.strip()}


def main():
    if len(sys.argv) < 2:
        print("培训材料邮件发送工具")
        print("用法：")
        print("  生成邮件: python email_sender.py generate <template_name> <data_json_file>")
        print("  发送邮件: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file> [attachment1] [attachment2] ...")
        print("\n可用模板：")
        for name, tmpl in EMAIL_TEMPLATES.items():
            print(f"  - {name}")
        sys.exit(1)

    action = sys.argv[1]

    if action == "generate":
        if len(sys.argv) < 4:
            print("用法: python email_sender.py generate <template_name> <data_json_file>")
            sys.exit(1)

        template_name = sys.argv[2]
        data_file = sys.argv[3]

        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        result = generate_email_content(template_name, data)

        if 'error' in result:
            print(f"错误: {result['error']}")
            sys.exit(1)
        else:
            print(result['content'])

    elif action == "send":
        if len(sys.argv) < 6:
            print("用法: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file> [attachment1] [attachment2] ...")
            sys.exit(1)

        smtp_config_file = sys.argv[2]
        recipient = sys.argv[3]
        subject = sys.argv[4]
        body_file = sys.argv[5]
        attachments = sys.argv[6:] if len(sys.argv) > 6 else None

        with open(smtp_config_file, 'r', encoding='utf-8') as f:
            smtp_config = json.load(f)

        with open(body_file, 'r', encoding='utf-8') as f:
            body = f.read()

        result = send_email(smtp_config, recipient, subject, body, attachments=attachments)

        if result['success']:
            print(result['message'])
        else:
            print(f"发送失败: {result['error']}")
            sys.exit(1)

    else:
        print(f"未知操作: {action}")
        sys.exit(1)


if __name__ == "__main__":
    main()
