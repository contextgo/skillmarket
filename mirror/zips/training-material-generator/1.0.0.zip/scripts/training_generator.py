#!/usr/bin/env python3
"""
培训材料生成核心脚本
支持：培训大纲、培训讲义、操作手册、案例分析、测试题、学习笔记模板
"""

import sys
import json
import argparse
from datetime import datetime
from pathlib import Path


# ==================== 培训大纲模板 ====================

OUTLINE_TEMPLATE = {
    "structure": {
        "cover": ["培训项目名称", "培训对象", "培训时长", "编制日期", "编制人/部门"],
        "objectives": {
            "knowledge": "知识目标：学员应掌握的核心概念和理论",
            "skill": "技能目标：学员应具备的实际操作能力",
            "attitude": "态度目标：学员应形成的工作理念和价值观"
        },
        "modules": {
            "module_template": {
                "module_id": "M01",
                "module_name": "模块名称",
                "duration_hours": 2,
                "learning_points": ["要点1", "要点2", "要点3"],
                "teaching_method": "讲授/实操/讨论/案例",
                "assessment": "考核方式"
            }
        },
        "schedule": "课时安排表",
        "resources": "教学资源清单",
        "assessment_plan": "考核方案"
    }
}


# ==================== 讲义模板 ====================

LECTURE_TEMPLATE = {
    "structure": {
        "header": ["模块标题", "学习目标", "预计学时", "前置知识"],
        "sections": {
            "overview": "模块概述（200-300字，概括本模块核心内容和学习价值）",
            "key_concepts": {
                "concept_template": {
                    "name": "概念名称",
                    "definition": "定义与解释",
                    "example": "实际案例/代码示例",
                    "tips": "注意事项/常见误区"
                }
            },
            "hands_on": {
                "step_template": {
                    "step_num": 1,
                    "action": "操作步骤描述",
                    "expected_result": "预期结果",
                    "troubleshooting": "常见问题及解决方案"
                }
            },
            "exercises": {
                "exercise_template": {
                    "type": "练习类型（填空/选择/实操/讨论）",
                    "question": "练习题目",
                    "hint": "提示",
                    "answer": "参考答案"
                }
            },
            "summary": "本模块要点回顾",
            "extended_reading": "延伸阅读推荐"
        }
    }
}


# ==================== 操作手册模板 ====================

MANUAL_TEMPLATE = {
    "structure": {
        "cover": ["手册名称", "适用系统版本", "编制日期", "版本号"],
        "toc": "目录",
        "overview": {
            "purpose": "手册用途说明",
            "audience": "目标读者",
            "prerequisites": "使用前提条件"
        },
        "process_overview": "操作流程总览图（文字描述）",
        "procedures": {
            "procedure_template": {
                "proc_id": "P01",
                "proc_name": "操作名称",
                "objective": "操作目的",
                "steps": [
                    {
                        "step_num": 1,
                        "action": "详细操作描述",
                        "screenshot_note": "截图位置标注",
                        "expected": "预期结果",
                        "tips": "注意事项"
                    }
                ],
                "verification": "验证操作是否成功的标准"
            }
        },
        "faq": {
            "faq_template": {
                "question": "常见问题描述",
                "cause": "原因分析",
                "solution": "解决步骤"
            }
        },
        "error_handling": "异常处理流程",
        "checklist": "操作检查清单"
    }
}


# ==================== 案例分析模板 ====================

CASE_TEMPLATE = {
    "structure": {
        "case_header": {
            "case_id": "CASE-001",
            "title": "案例标题",
            "type": "成功案例/失败案例/情景模拟/故障排查",
            "difficulty": "初级/中级/高级",
            "domain": "业务领域",
            "duration_min": 30,
            "target_audience": "适用培训对象"
        },
        "background": "案例背景介绍（300-500字，交代时间、人物、环境、起因）",
        "challenge": {
            "description": "问题/挑战描述",
            "key_factors": ["关键因素1", "关键因素2", "关键因素3"],
            "constraints": "约束条件"
        },
        "decision_points": [
            {
                "point_id": "D1",
                "situation": "决策情境描述",
                "options": ["选项A", "选项B", "选项C"],
                "analysis": "各选项利弊分析",
                "recommended": "推荐选项及理由"
            }
        ],
        "outcome": {
            "actual_result": "实际结果",
            "lessons_learned": ["经验教训1", "经验教训2"],
            "best_practices": ["最佳实践1", "最佳实践2"]
        },
        "discussion": {
            "questions": [
                "如果你是当事人，你会如何决策？",
                "这个案例中最大的风险点是什么？",
                "如何避免类似问题再次发生？"
            ],
            "key_takeaway": "核心要点总结"
        }
    }
}


# ==================== 测试题模板 ====================

QUIZ_TEMPLATE = {
    "structure": {
        "exam_header": {
            "exam_title": "测试标题",
            "total_score": 100,
            "duration_min": 60,
            "passing_score": 60,
            "related_module": "关联培训模块"
        },
        "questions": {
            "single_choice": {
                "template": {
                    "id": "SC01",
                    "question": "题目文本",
                    "options": ["A. 选项1", "B. 选项2", "C. 选项3", "D. 选项4"],
                    "answer": "A",
                    "explanation": "答案解析",
                    "difficulty": "基础/中级/高级",
                    "knowledge_point": "考察知识点"
                }
            },
            "multiple_choice": {
                "template": {
                    "id": "MC01",
                    "question": "题目文本",
                    "options": ["A. 选项1", "B. 选项2", "C. 选项3", "D. 选项4"],
                    "answer": ["A", "C"],
                    "explanation": "答案解析",
                    "difficulty": "基础/中级/高级",
                    "knowledge_point": "考察知识点"
                }
            },
            "true_false": {
                "template": {
                    "id": "TF01",
                    "question": "判断题文本",
                    "answer": True,
                    "explanation": "答案解析",
                    "difficulty": "基础/中级/高级",
                    "knowledge_point": "考察知识点"
                }
            },
            "short_answer": {
                "template": {
                    "id": "SA01",
                    "question": "简答题文本",
                    "answer": "参考答案",
                    "scoring_criteria": "评分标准（分点描述）",
                    "difficulty": "基础/中级/高级",
                    "knowledge_point": "考察知识点"
                }
            },
            "practical": {
                "template": {
                    "id": "PR01",
                    "question": "实操题描述",
                    "requirements": ["要求1", "要求2"],
                    "scoring_criteria": "评分标准",
                    "expected_output": "预期输出/结果",
                    "difficulty": "基础/中级/高级",
                    "knowledge_point": "考察知识点"
                }
            }
        }
    }
}


# ==================== 学习笔记模板 ====================

NOTES_TEMPLATE = {
    "cornell": {
        "structure": {
            "header": ["课程名称", "日期", "讲师", "模块"],
            "cue_column": "线索/关键词列（左侧1/3）",
            "notes_column": "笔记内容列（右侧2/3）",
            "summary_section": "底部总结区"
        }
    },
    "mindmap_style": {
        "structure": {
            "center_topic": "核心主题",
            "branches": ["分支1", "分支2", "分支3"],
            "details": "各分支下的详细内容",
            "connections": "分支间的关联关系"
        }
    },
    "practical_log": {
        "structure": {
            "exercise_name": "实操项目名称",
            "steps_taken": "操作步骤记录",
            "problems_encountered": "遇到的问题",
            "solutions_found": "解决方案",
            "key_learnings": "关键收获",
            "todo_next": "下一步计划"
        }
    }
}


# ==================== 生成函数 ====================

def generate_outline(params):
    """生成培训大纲"""
    result = {
        "type": "outline",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "training_name": params.get("training_name", "培训项目"),
            "target_audience": params.get("target_audience", "待定"),
            "duration": params.get("duration", "待定"),
            "objectives": {
                "knowledge": params.get("knowledge_objective", ""),
                "skill": params.get("skill_objective", ""),
                "attitude": params.get("attitude_objective", "")
            },
            "modules": params.get("modules", []),
            "assessment_plan": params.get("assessment_plan", ""),
        },
        "template": OUTLINE_TEMPLATE
    }
    return result


def generate_lecture(params):
    """生成培训讲义"""
    result = {
        "type": "lecture",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "module_name": params.get("module_name", "模块"),
            "learning_objectives": params.get("learning_objectives", []),
            "duration_hours": params.get("duration_hours", 2),
            "prerequisites": params.get("prerequisites", ""),
            "overview": params.get("overview", ""),
            "key_concepts": params.get("key_concepts", []),
            "hands_on_steps": params.get("hands_on_steps", []),
            "exercises": params.get("exercises", []),
            "summary": params.get("summary", ""),
            "extended_reading": params.get("extended_reading", [])
        },
        "template": LECTURE_TEMPLATE
    }
    return result


def generate_manual(params):
    """生成操作手册"""
    result = {
        "type": "manual",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "manual_name": params.get("manual_name", "操作手册"),
            "system_version": params.get("system_version", ""),
            "purpose": params.get("purpose", ""),
            "audience": params.get("audience", ""),
            "prerequisites": params.get("prerequisites", []),
            "process_overview": params.get("process_overview", ""),
            "procedures": params.get("procedures", []),
            "faq": params.get("faq", []),
            "error_handling": params.get("error_handling", ""),
            "checklist": params.get("checklist", [])
        },
        "template": MANUAL_TEMPLATE
    }
    return result


def generate_case(params):
    """生成案例分析"""
    result = {
        "type": "case",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "case_title": params.get("case_title", "案例"),
            "case_type": params.get("case_type", "情景模拟"),
            "difficulty": params.get("difficulty", "中级"),
            "domain": params.get("domain", ""),
            "background": params.get("background", ""),
            "challenge": params.get("challenge", {}),
            "decision_points": params.get("decision_points", []),
            "outcome": params.get("outcome", {}),
            "discussion": params.get("discussion", {})
        },
        "template": CASE_TEMPLATE
    }
    return result


def generate_quiz(params):
    """生成测试题"""
    result = {
        "type": "quiz",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "exam_title": params.get("exam_title", "培训测试"),
            "total_score": params.get("total_score", 100),
            "duration_min": params.get("duration_min", 60),
            "passing_score": params.get("passing_score", 60),
            "questions": {
                "single_choice": params.get("single_choice", []),
                "multiple_choice": params.get("multiple_choice", []),
                "true_false": params.get("true_false", []),
                "short_answer": params.get("short_answer", []),
                "practical": params.get("practical", [])
            }
        },
        "template": QUIZ_TEMPLATE
    }
    return result


def generate_notes_template(params):
    """生成学习笔记模板"""
    result = {
        "type": "notes_template",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {
            "template_type": params.get("template_type", "cornell"),
            "course_name": params.get("course_name", ""),
            "config": params.get("config", {})
        },
        "template": NOTES_TEMPLATE
    }
    return result


# ==================== 模板查询 ====================

def get_template(material_type):
    """获取指定类型的模板结构"""
    templates = {
        "outline": OUTLINE_TEMPLATE,
        "lecture": LECTURE_TEMPLATE,
        "manual": MANUAL_TEMPLATE,
        "case": CASE_TEMPLATE,
        "quiz": QUIZ_TEMPLATE,
        "notes": NOTES_TEMPLATE
    }
    return templates.get(material_type, {"error": f"未知材料类型: {material_type}，支持类型: {', '.join(templates.keys())}"})


def list_templates():
    """列出所有可用模板"""
    return {
        "outline": "培训大纲 - 结构化培训课程规划",
        "lecture": "培训讲义 - 逐模块详细讲义内容",
        "manual": "操作手册 - 标准化SOP操作文档",
        "case": "案例分析 - 教学案例与讨论材料",
        "quiz": "培训测试 - 考核测试题及答案",
        "notes": "学习笔记 - 结构化笔记模板"
    }


# ==================== 主入口 ====================

def main():
    parser = argparse.ArgumentParser(description="培训材料生成工具")
    parser.add_argument("action", choices=["generate", "template", "list"],
                        help="操作：generate=生成材料, template=查看模板, list=列出类型")
    parser.add_argument("--type", "-t", help="材料类型：outline/lecture/manual/case/quiz/notes")
    parser.add_argument("--params", "-p", help="参数JSON文件路径")
    parser.add_argument("--output", "-o", help="输出JSON文件路径")

    args = parser.parse_args()

    if args.action == "list":
        templates = list_templates()
        print("可用培训材料类型：")
        for t, desc in templates.items():
            print(f"  {t:10s} - {desc}")
        return

    if args.action == "template":
        if not args.type:
            print("请指定 --type 参数")
            sys.exit(1)
        result = get_template(args.type)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.action == "generate":
        if not args.type:
            print("请指定 --type 参数")
            sys.exit(1)

        params = {}
        if args.params:
            with open(args.params, 'r', encoding='utf-8') as f:
                params = json.load(f)

        generators = {
            "outline": generate_outline,
            "lecture": generate_lecture,
            "manual": generate_manual,
            "case": generate_case,
            "quiz": generate_quiz,
            "notes": generate_notes_template
        }

        if args.type not in generators:
            print(f"未知类型: {args.type}，支持: {', '.join(generators.keys())}")
            sys.exit(1)

        result = generators[args.type](params)
        output_json = json.dumps(result, ensure_ascii=False, indent=2)

        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output_json)
            print(f"已生成: {args.output}")
        else:
            print(output_json)


if __name__ == "__main__":
    main()
