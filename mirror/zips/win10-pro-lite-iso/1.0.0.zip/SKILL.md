---
name: win10-pro-lite-iso
description: Build and iteratively refine a stable, lightly stripped Windows 10 Pro 22H2 ISO. Use when an AI assistant needs to customize install.wim, author unattended setup files, enable the built-in Administrator account, trim apps and services, rebuild a bootable ISO, and validate the result in VirtualBox while prioritizing install stability over aggressive stripping.
---

# Win10 Pro Lite ISO

Build a stable Windows 10 Pro deployment image first. Strip less during offline servicing, push cosmetic cleanup to first logon, and treat VM validation as mandatory.

## Target

Use this skill when the goal is:
- a single-index `Windows 10 Pro 22H2` image
- built-in `Administrator`
- no normal-user creation in OOBE
- light debloat for long-term daily use
- clean desktop and Start menu
- predictable ISO rebuild and VM verification

Read [references/v7-validation-notes.md](references/v7-validation-notes.md) before continuing an existing iteration so you inherit the latest known-good and known-bad behaviors.

If the runner is not Codex, use [references/universal-ai-playbook.md](references/universal-ai-playbook.md) as the handoff guide. `agents/openai.yaml` is optional UI metadata and can be ignored by other AI systems.

## Build Rules

Lock the image to `Index 1` and export or preserve it as a single-index `install.wim`.

Keep the image conservative:
- remove consumer apps according to [references/appx-removal-list.md](references/appx-removal-list.md)
- keep update stack, servicing stack, `.NET`, `Windows Installer`, core networking, WMI, RPC, printing, language resources, and repair paths intact
- keep `Security Center` and `SmartScreen` binaries unless the user explicitly accepts higher risk

Do not disable these Defender boot drivers during offline servicing:
- `WdBoot`
- `WdFilter`
- `WdNisDrv`

Treat those three as installation-risk items. Earlier iterations that disabled them too early caused very slow or stuck behavior around the `Start Services` phase.

## Safe Unattend Pattern

Use [scripts/autounattend.xml](scripts/autounattend.xml) as the baseline:
- `windowsPE`: zh-CN locale, `/IMAGE/INDEX = 1`, generic Pro key if setup needs edition disambiguation
- `specialize`: locale fallback, time zone, owner and organization
- `oobeSystem`: `AutoLogon` to `Administrator`, blank `AdministratorPassword`, and hidden OOBE pages

Keep partitioning manual by default.

Do not hardcode:
- `WillWipeDisk=true`
- `DiskID=0` plus forced `PartitionID`
- fixed GPT-only disk layout

Those settings are fine only when the user explicitly wants a destructive fully unattended install. For a reusable general skill, they are too risky.

Do not rely on `SkipMachineOOBE` and `SkipUserOOBE` as the primary strategy. Treat them as legacy compatibility levers, not the main design.

## First-Run Execution Model

Split first-run work into two layers.

`scripts/SetupComplete.cmd`
- enable `Administrator`
- clear the Administrator password
- mark password as non-expiring
- seed blank autologon registry values
- disable hibernation
- set machine-level policies
- register a `RunOnce` fallback for finalize

`scripts/FinalizeAdministrator.ps1`
- run from the `RunOnce` entry seeded by `SetupComplete.cmd`
- keep a completion marker so it does not re-run endlessly
- do user-profile cleanup and shell cleanup
- disable only service-level security noise, not boot-critical drivers
- remove leftover shortcuts and Start entries
- restore hidden-file defaults
- hide Task View

Keep the primary handoff in `SetupComplete.cmd` by writing a `RunOnce` entry. Earlier iterations that launched the heavy finalize step directly from `FirstLogonCommands` could hold the user on a black post-logon screen before the desktop appeared.

## Offline Servicing Pattern

Use [scripts/build-iso.ps1](scripts/build-iso.ps1) to automate the full pipeline.

Default flow:
1. Copy source media to a working directory.
2. Replace root `autounattend.xml`.
3. Mount `sources\install.wim` for `Index 1`.
4. Remove only the safest provisioned apps offline.
5. Copy `SetupComplete.cmd`, `FinalizeAdministrator.cmd`, and `FinalizeAdministrator.ps1` into `Windows\Setup\Scripts`.
6. Copy `assets/LayoutModification.xml` into `Users\Default\AppData\Local\Microsoft\Windows\Shell`.
7. Unmount with commit.
8. Export to a single-index `install.wim`.
9. Rebuild a BIOS+UEFI bootable ISO.

`build-iso.ps1` prefers `oscdimg.exe` when available, but it also includes a built-in IMAPI2FS fallback so ADK is optional rather than mandatory.

When building from a clean UUP or original ISO source, keep offline Appx removal extremely conservative until the image is revalidated in VirtualBox. A broader offline removal pass later caused first-boot failure in `WinDeploy -> oobe\setup.exe` with `0x8007001F`.

## UI Cleanup Targets

Treat these as separate jobs. Disabling a service does not guarantee that its visible entry disappears.

Windows Security:
- hide the Settings page with `SettingsPageVisibility`
- disable `SecurityHealth` startup entry
- remove current-user `SecHealthUI` package if present
- remove obvious Start-menu shortcuts
- verify manually because residue may persist on some builds

OneDrive:
- uninstall with `OneDriveSetup.exe /uninstall`
- remove Run entries
- unpin the Explorer namespace tree
- delete leftover shortcuts and folders
- verify manually because first-sign-in recreation is common

Explorer polish:
- `Hidden=2`
- `ShowSuperHidden=0`
- `HideFileExt=1`
- `ShowTaskViewButton=0`

Expect hidden-file cleanup to fully show up only after Explorer refresh or the first shell restart.

## Validation Gates

Run [scripts/validate.ps1](scripts/validate.ps1) inside a fresh VM to cover the easy machine-readable gates.

Do not call a build successful until all of these are checked on a fresh virtual disk:
1. Setup parses `autounattend.xml` without answer-file errors.
2. Setup reaches the partition screen and installs normally.
3. The machine enters `Administrator` without creating another user.
4. No unexpected password prompt blocks entry.
5. `Camera` is removed if requested.
6. Hidden files are not shown by default after Explorer refresh.
7. `hiberfil.sys` is absent and hibernation is off.
8. `Windows Security` residue is manually checked.
9. `OneDrive` residue is manually checked.

Always use a fresh virtual disk for each meaningful build to avoid false positives from earlier test installs.

## Current Status

At the current `v7` checkpoint:
- the build pipeline now clears read-only flags copied from ISO media before mounting `install.wim`
- the heavy first-logon cleanup is no longer launched directly from `FirstLogonCommands`
- setup still targets the built-in `Administrator` account without prompting for a password
- the conservative offline-servicing path remains intact
- the skill package validates cleanly as a reusable AI-facing skill

Still not fully solved:
- a full fresh-VM desktop validation of the `v7` build is still pending
- Start-menu consumer-app residue still needs explicit re-check after the latest handoff change
- `Windows Security` visibility still needs a fresh re-check on the newest build

Treat full fresh-VM desktop validation, Windows Security residue, and Start-menu residue as the current top priorities.

## File Map

```text
win10-pro-lite-iso/
  SKILL.md
  agents/
    openai.yaml
  assets/
    LayoutModification.xml
  references/
    appx-removal-list.md
    v3-validation-notes.md
    v5-validation-notes.md
    v6-validation-notes.md
    v7-validation-notes.md
    universal-ai-playbook.md
  scripts/
    autounattend.xml
    build-iso.ps1
    validate.ps1
    SetupComplete.cmd
    FinalizeAdministrator.cmd
    FinalizeAdministrator.ps1
```
