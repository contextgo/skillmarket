# 全球民生健康新闻来源参考

## 一、国际组织（核心权威来源）

### 卫生健康类

| 机构 | 英文名 | 网址 | 核心内容 |
|------|--------|------|----------|
| 世界卫生组织 | WHO | who.int/news-room | 疫情通报、卫生紧急事件 |
| 世界粮食计划署 | WFP | wfp.org/news | 粮食安全、饥饿危机 |
| 联合国粮农组织 | FAO | fao.org/news | 粮食农业、食品安全 |
| 联合国难民署 | UNHCR | unhcr.org/news | 难民、人道主义危机 |
| 联合国人道协调厅 | UNOCHA | unocha.org/publications | 人道主义局势报告 |
| 国际移民组织 | IOM | iom.int/news | 移民与流离失所 |

### 区域卫生组织

| 机构 | 覆盖区域 | 网址 |
|------|----------|------|
| WHO东地中海区域 | 中东 | emro.who.int |
| WHO东南亚区域 | 东南亚 | who.int/southeastasia |
| WHO欧洲区域 | 欧洲 | who.int/europe |
| 泛美卫生组织 | 美洲 | paho.org |

---

## 二、中国官方来源

### 卫生健康

| 机构 | 网址 | 特色内容 |
|------|------|----------|
| 国家卫健委 | nhc.gov.cn | 疫情防控、医改政策 |
| 国家疾控局 | ndca.gov.cn | 传染病防治 |
| 中国疾控中心 | chinacdc.cn | 疫情监测、预警 |
| 中医药管理局 | satcm.gov.cn | 中医药政策 |

### 时政要闻

| 媒体 | 网址 | 特色内容 |
|------|------|----------|
| 新华社 | xinhuanet.com | 权威快讯、多语种 |
| 央视新闻 | news.cctv.com | 视频新闻 |
| 人民日报 | people.com.cn | 时政要闻 |
| 中国日报 | chinadaily.com.cn | 英文新闻 |

### 地方新闻

| 媒体 | 网址 | 覆盖 |
|------|------|------|
| 新浪新闻 | news.sina.com.cn | 综合门户 |
| 腾讯新闻 | news.qq.com | 社交热点 |
| 澎湃新闻 | thepaper.cn | 深度报道 |
| 财新网 | caixin.com | 财经深度 |

---

## 三、美国新闻源

### 主流媒体

| 媒体 | 网址 | 医疗健康特色 |
|------|------|--------------|
| Reuters Health | reuters.com/health | 全球医疗新闻 |
| AP Health | apnews.com/hub/health | 美国医疗政策 |
| KFF Health News | kffhealthnews.org | 医疗政策深度分析 |
| STAT News | statnews.com | 生物科技与健康 |

### 政府来源

| 机构 | 网址 | 内容 |
|------|------|------|
| FDA | fda.gov/news-events | 药品器械审批 |
| CDC | cdc.gov | 疾病防控指南 |
| CMS | cms.gov | 医保政策 |
| HHS | hhs.gov | 卫生与公共服务 |

---

## 四、欧洲新闻源

### 欧盟机构

| 机构 | 网址 | 内容 |
|------|------|------|
| 欧盟委员会 | ec.europa.eu | 欧盟政策、经济 |
| 欧洲央行 | ecb.europa.eu | 经济金融政策 |
| 欧洲疾控中心 | ecdc.europa.eu | 传染病监测 |

### 主流媒体

| 媒体 | 国家 | 网址 |
|------|------|------|
| BBC News | 英国 | bbc.com/news |
| The Guardian | 英国 | theguardian.com |
| Le Monde | 法国 | lemonde.fr |
| Der Spiegel | 德国 | spiegel.de |
| El País | 西班牙 | elpais.com |

---

## 五、中东新闻源

### 地区媒体

| 媒体 | 国家 | 网址 |
|------|------|------|
| Al Jazeera | 卡塔尔 | aljazeera.com |
| Arab News | 沙特 | arabnews.com |
| The National | 阿联酋 | thenationalnews.com |

### 国际媒体中东站

| 媒体 | 网址 |
|------|------|
| BBC Middle East | bbc.com/news/middle_east |
| Reuters Middle East | reuters.com/world/middle-east |

---

## 六、俄罗斯新闻源

### 官方媒体

| 媒体 | 网址 | 特色 |
|------|------|------|
| TASS | tass.com | 官方通讯社 |
| RT | rt.com | 俄英语新闻 |
| Russia Today | rt.com | 国际视角 |

### 政府门户

| 机构 | 网址 |
|------|------|
| 俄罗斯政府 | government.ru/en/ |

---

## 七、东南亚新闻源

### 主流媒体

| 媒体 | 国家 | 网址 |
|------|------|------|
| Straits Times | 新加坡 | straitstimes.com |
| Bangkok Post | 泰国 | bangkokpost.com |
| Jakarta Post | 印尼 | thejakartapost.com |
| Vietnam News | 越南 | vietnamnews.vn |

---

## 八、全球新闻聚合

### 综合性新闻聚合

| 平台 | 网址 | 特色 |
|------|------|------|
| Google News | news.google.com | 实时聚合 |
| Bing News | bing.com/news | 搜索聚合 |
| NewsNow | newsnow.com | 英美欧快讯 |

### 专业新闻聚合

| 平台 | 网址 | 特色 |
|------|------|------|
| ReliefWeb | reliefweb.int | 人道主义新闻 |
| HealthMap | healthmap.org | 全球疫情地图 |
| Promed Mail | promedmail.org | 传染病监测 |

---

## 九、搜索关键词模板

### 民生健康主题

```
# 粮食安全
"food security" OR "food crisis" OR "acute hunger" 2026
全球粮食危机 饥饿 粮食不安全

# 医疗政策
"healthcare reform" OR "health insurance" OR "drug approval" 2026
医疗改革 医保 药品审批

# 人道主义
"humanitarian crisis" OR "refugee" OR "displaced" 2026
人道主义危机 难民 流离失所

# 疫情防控
"outbreak" OR "epidemic" OR "pandemic" 2026
疫情 传染病 防控

# 社会保障
"social welfare" OR "pension" OR "medicaid" 2026
社会保障 养老金 福利
```

### 地区限定

```
# 时间限定
after:2026-04-28 [topic]
2026年4月 OR 2026年5月 [topic]

# 来源限定
site:who.int [topic]
site:reuters.com [region] [topic]

# 组合搜索
site:who.int OR site:un.org "health emergency" [region]
```