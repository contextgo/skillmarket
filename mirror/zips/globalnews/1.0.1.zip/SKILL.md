---
name: global-news
description: 全球热点时事新闻抓取 Skill。用于获取全球各国/地区的热点新闻，支持民生、健康、生命安全等主题的中外文对照翻译。支持覆盖中国、美国、欧洲、中东、日韩、东南亚、美洲、俄罗斯等地区。当用户询问国际新闻、全球热点、民生健康、时事翻译、或指定地区新闻时触发此 Skill。
author: qingwen
version: "2.0"
tags:
  - news
  - international
  - breaking-news
  - current-events
  - translation
  - livelihood
  - health
  - bilingual
---

# Global News Fetcher Skill

抓取全球热点时事新闻，支持多地区覆盖与中英文对照翻译。

## 支持的地区

| 地区 | 英文关键词 | 中文搜索词 |
|------|-----------|-----------|
| 中国 | China news | 民生、健康、政策 |
| 美国 | US news, America news | 医保、医疗费用 |
| 欧洲 | Europe news, EU news | 医疗改革、老龄化 |
| 中东 | Middle East news | 人道主义、卫生危机 |
| 日韩 | Japan Korea news | 健康、防疫 |
| 东南亚 | Southeast Asia news | 传染病、疫情 |
| 俄罗斯 | Russia news | 社会保障、福利 |
| 全球 | global breaking news | 粮食危机、流行病 |

## 主题分类

### 民生类 (Livelihood)
- 粮食安全 Food Security
- 社会保障 Social Welfare
- 住房 Housing
- 就业 Employment
- 通胀 Inflation

### 健康类 (Health)
- 医疗改革 Healthcare Reform
- 医保政策 Health Insurance
- 疫情动态 Epidemic Updates
- 药品审批 Drug Approval
- 医疗突破 Medical Breakthrough

### 生命安全类 (Life Safety)
- 人道主义危机 Humanitarian Crisis
- 冲突伤亡 Conflict Casualties
- 自然灾害 Natural Disasters
- 食品安全 Food Safety
- 环境健康 Environmental Health

## 工作流程

### 1. 需求解析

接收用户请求，提取：
- 目标地区（可多选，默认全部）
- 主题类型（民生/健康/生命安全）
- 语言偏好（中英对照/仅中文/仅英文）
- 返回数量（默认 8-10 条）
- 时间范围（今日/本周/本月）

### 2. 搜索策略

使用 `WebSearch` 工具，按优先级搜索：

```bash
# 高热度民生健康新闻搜索模板
healthcare OR "public health" OR "food security" OR welfare [地区] [时间]
breaking news [主题] April 2026 OR May 2026
global humanitarian OR crisis [主题] 2026

# 中文搜索
[地区] 民生 健康 热点 [时间]
```

### 3. 详情抓取

使用 `WebFetch` 工具获取新闻详情：
- 提取关键数据（人数、金额、比例）
- 识别受影响群体
- 记录政策措施或行动呼吁

### 4. 中英文对照格式化

将新闻格式化为统一的双语结构：

```markdown
## 🌍 全球民生健康热点新闻

**数据更新时间**: [YYYY-MM-DD HH:mm]
**覆盖区域**: [地区列表]
**主题**: [主题类型]

---

### N️⃣ 【[地区]】[中文标题]

**English Title**: [English Title]

**中文摘要**: 
[200-300字中文摘要，突出与民众息息相关的内容]

**English Summary**:
[200-300字英文摘要]

**来源 | Source**: [媒体名称]
**链接 | URL**: [URL]
```

### 5. 热度评估

对每条新闻进行热度评估（⭐表示）：

| 热度 | 指标 |
|------|------|
| ⭐⭐⭐⭐⭐ | 涉及数亿人、全球性危机、重大政策突破 |
| ⭐⭐⭐⭐ | 区域性重大事件、数十万人受影响 |
| ⭐⭐⭐ | 地方性事件、数万人受影响 |

## 输出模板

### 完整报告模板

```markdown
# 🌍 全球民生健康热点新闻集（第X期）

**数据更新时间**: YYYY年MM月DD日 HH:mm
**覆盖区域**: [区域列表]
**主题**: [主题类型]

---

## 🔴 头条热点

### N️⃣ 【[地区]】[标题]
[中英文对照内容]

---

## 📊 区域热点

### N️⃣ 【[地区]】[标题]
[中英文对照内容]

---

## 📈 新闻热度指数

| 排名 | 新闻标题 | 热度 | 区域 |
|------|----------|------|------|
| 🔥N | [标题] | ⭐⭐⭐⭐⭐ | [地区] |

---

## 🔍 主题分布

```
[可视化图表]
```

---

> 💡 温馨提示: 点击各新闻链接可获取完整报道。
```

### 快速响应模板

当用户请求简短回答时：

```markdown
### [地区] - [标题]
- 🕐 [发布时间]
- 📰 [来源]
- 🔗 [链接]
- 📝 [中文摘要]
- EN: [英文摘要]
```

## 核心新闻源

### 国际组织
| 机构 | 网址 | 用途 |
|------|------|------|
| WHO | who.int | 卫生紧急事件、疫情 |
| WFP | wfp.org | 粮食安全 |
| FAO | fao.org | 粮食农业 |
| UNHCR | unhcr.org | 难民人道主义 |
| UNOCHA | unocha.org | 人道主义协调 |

### 中国官方
| 媒体 | 网址 | 用途 |
|------|------|------|
| 国家卫健委 | nhc.gov.cn | 疫情防控 |
| 新华社 | xinhuanet.com | 官方新闻 |
| 央视新闻 | news.cctv.com | 时政要闻 |

### 美国媒体
| 媒体 | 网址 | 用途 |
|------|------|------|
| Reuters | reuters.com | 国际快讯 |
| AP News | apnews.com | 突发新闻 |
| KFF | kff.org | 医疗政策 |

### 欧洲媒体
| 媒体 | 网址 | 用途 |
|------|------|------|
| BBC | bbc.com | 全球新闻 |
| EU Commission | ec.europa.eu | 欧盟政策 |

### 俄罗斯媒体
| 媒体 | 网址 | 用途 |
|------|------|------|
| TASS | tass.com | 官方通讯社 |
| RT | rt.com | 俄英语新闻 |

## 翻译规则

### 标题翻译
- 保持简洁，15-25字
- 使用中英文标点区分
- 人名地名保留原文

### 摘要翻译
- 直译为主，意译为辅
- 保留关键数据和术语
- 避免过度归化

### 专业术语对照

| 中文 | English |
|------|---------|
| 急性粮食不安全 | Acute Food Insecurity |
| 孕产妇死亡率 | Maternal Mortality Rate |
| 基因疗法 | Gene Therapy |
| 医疗补助 | Medicaid |
| 联邦医疗保险 | Medicare |
| 平价医疗法案 | Affordable Care Act (ACA) |
| 人道主义走廊 | Humanitarian Corridor |
| 疫苗可预防疾病 | Vaccine-Preventable Diseases |
| 虫媒传染病 | Vector-Borne Diseases |
| 肠道传染病 | Intestinal Infectious Diseases |

## 注意事项

1. **时效性优先**：优先获取 48 小时内新闻，头条不超过 7 天
2. **民生关联**：选择与普通人生活密切相关的内容
3. **数据准确**：核实关键数字，注明数据来源和日期
4. **平衡覆盖**：各地区新闻数量相对均衡
5. **避免重复**：同事件多来源时选择最权威或最新版本

## 错误处理

| 情况 | 处理方式 |
|------|----------|
| 搜索无结果 | 扩大关键词，尝试 "breaking news" 或地区变体 |
| 链接失效 | 跳过并使用搜索摘要，保持信息来源标注 |
| 内容抓取失败 | 仅返回搜索标题和摘要，标注"详情待查" |
| 翻译困难 | 保留原文，标注"[翻译待确认]" |
| 数量不足 | 补充相关主题新闻，确保至少 5 条 |

## 交互建议

完成抓取后，可询问用户：

- 是否需要生成特定地区的专题报告？
- 是否需要将新闻导出为文档？
- 是否需要定期推送（如每日/每周）？
