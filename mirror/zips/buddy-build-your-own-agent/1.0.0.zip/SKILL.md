---
name: build-your-own-agent
trigger_terms: |
  手搓, 从零构建, build your own agent, 不用框架, pure python agent, agent原理, agent底层, agent内部实现,
  ReAct循环, tool_use, 工具调用, agent循环, agent记忆, agent规划, 多agent协作, agent架构,
  进入第X关, 继续学习, 下一关, 回顾, 速通, 挑战模式, 导师引导, 自由探索,
  claude api agent, anthropic agent tutorial, agent from scratch, 裸写agent, 手写agent,
  agent课程, agent教程, 学习agent开发, agent入门, agent进阶, agent实战,
  build-your-own-x, agent基础, agent核心, agent设计模式, 自进化agent,
  状态机agent, 任务规划, 工具注册, 消息压缩, 向量记忆, 经验池, agent评估
description: |
  渐进式 Agent 构建课程。10关从80行极简Agent到自进化Agent，纯 Python + Claude API，不用框架。

  **触发场景**（满足任一即触发）：
  1. 用户想从零手搓 Agent（"手搓Agent"、"裸写agent"、"从零构建"）
  2. 用户想学 Agent 原理（"Agent底层实现"、"ReAct循环怎么写"）
  3. 用户正在学习中求助（"这一关怎么做"、"检查我的代码"）
  4. 用户查询进度/规划（"我的进度"、"agent学习路线"）

  **不用于**：
  - 用框架快速创建 Agent（LangChain/CrewAI/AutoGen） → agent-creator
  - 测试已有 Agent 质量 → agent-benchmark
  - 学习 Skill 开发 → skill-creator
  - 搭建部署环境 / Docker / API Key 问题
  - 通用编程问题（Python基础、Web开发）
  - AI Agent 行业分析 / 商业模式

  **核心能力**：
  1. 10关渐进式课程（心智模型→自进化Agent）
  2. 4种教学模式（自由探索/导师引导/挑战模式/速通）
  3. 11个参考实现文件（每关完整代码+设计决策）
  4. 进度追踪系统
---

# Build Your Own Agent 🏗️

_灵感来自 GitHub 39万星项目 [Build Your Own X](https://github.com/danistefanovic/build-your-own-x)_

**核心理念**：不用框架，不抄模板，从第一性原理手搓每一个 Agent。
> 100行代码 + 强理解 > 1000行框架 + 弱理解

---

## 触发规则

满足以下**任一**场景时触发。详见 frontmatter description 中的触发场景和不用于列表。

**A. 开始/继续学习** — "手搓Agent" / "进入第X关" / "下一关" / "速通"

**B. 学习过程中求助** — "这一关怎么做" / "给我提示" / "检查我的代码"

**C. 已学知识应用** — "用这个原理做一个XX" / "扩展第X关"

**D. 进度与规划** — "我的进度" / "agent学习路线"

---

## 进度管理

首次使用时，读取 `~/.workbuddy/skills/build-your-own-agent/progress.md`。
文件不存在则初始化为第0关（未开始）。每次完成一关后更新进度文件。

---

## 十关概览

> 每关的完整参考实现在 `references/0X-xxx.md`，按需读取对应文件。

| 关 | 名称 | 目标 | 核心组件 |
|----|------|------|---------|
| 0 | 心智模型 | 理解Agent vs LLM | 四大支柱概念 |
| 1 | 80行极简Agent | 第一个能跑的Agent | ReAct循环 |
| 2 | 工具系统 | 通用工具注册 | 装饰器+Schema生成+沙盒 |
| 3 | 记忆系统 | 三层记忆 | 工作/短期/长期记忆 |
| 4 | 规划系统 | 先规划再执行 | 任务分解+依赖分析+重规划 |
| 5 | 多工具Agent | 5+工具研究助手 | 搜索/文件/计算/HTTP |
| 6 | 错误处理 | 生产级鲁棒性 | 重试/超时/降级/成本控制 |
| 7 | 状态机Agent | 可预测工作流 | 状态定义/转换/持久化 |
| 8 | 多Agent协作 | 团队协作 | 顺序/并行/层级模式 |
| 9 | 评估与优化 | 数据驱动优化 | 成功率/延迟/幻觉率/A-B测试 |
| 10 | 自进化Agent | 从经验中学习 | 经验池+规则提取+Prompt自动优化 |

**依赖关系**：
```
0 → 1 → 2 ── 3 → 5 → 6 → 4 → 7 → 8 → 9 → 10
```

**建议节奏**：第0-1关(1天) → 第2-3关(2-3天) → 第4-6关(3-5天) → 第7-8关(5-7天) → 第9-10关(5-7天)

---

## 教学交互模式

用户进入某关时，询问学习模式并严格按对应协议执行：

| 模式 | 触发词 | 行为 |
|------|--------|------|
| **自由探索** | "自由探索" / 默认 | 展示目标+代码骨架（留空），用户自己填，遇到问题引导 |
| **导师引导** | "带我" / "教我" / "手把手" | 讲原理(类比) → 设计思路(伪代码) → 完整代码(逐行解释) → 练习题 |
| **挑战模式** | "挑战" / "考试" / "独立" | 只给任务描述+验收标准，不给代码。完成后点评+给参考答案对比 |
| **速通模式** | "速通" / "快速过" | 每关只展示核心代码+关键设计决策，跳过练习 |

### 关卡开始/通过/进度查询输出格式

详见 `references/output_formats.md`。

---

## Gotchas（常见陷阱）

8个常见陷阱（max_iterations无限循环、tool_result关联、eval安全、上下文撑爆、多Agent污染、向量持久化、工具描述、自退化）见 `references/gotchas.md`。

---

## 与其他Skill的关系

| 维度 | build-your-own-agent | agent-creator |
|------|---------------------|---------------|
| 目标 | 理解原理 | 快速创建 |
| 方式 | 手写每一行 | 框架生成 |
| 适用 | 想深入理解Agent的人 | 需要快速产出的人 |
| 关系 | **先学原理** → **再用框架提效** | 完成第1-5关后使用更得心应手 |

---

## 参考资料

- `references/00-mindset.md` — Agent vs LLM 深度对比
- `references/01-minimal-agent.md` — 80行Agent完整实现
- `references/02-tool-system.md` — 工具注册系统
- `references/03-memory-system.md` — 三层记忆系统
- `references/04-planning-system.md` — 规划系统
- `references/05-multi-tool-agent.md` — 多工具Agent
- `references/06-resilience.md` — 错误处理与鲁棒性
- `references/07-state-machine.md` — 状态机Agent
- `references/08-multi-agent.md` — 多Agent协作
- `references/09-evaluation.md` — 评估与优化
- `references/10-self-evolving.md` — 自进化Agent
