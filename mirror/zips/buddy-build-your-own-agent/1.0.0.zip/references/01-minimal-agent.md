# 第1关参考答案：80行极简Agent

## 完整代码（逐行注释）

```python
"""
第1关：80行极简Agent
目标：用纯Python + Claude API构建第一个能跑的Agent
核心原理：ReAct循环（Reasoning + Acting）
"""

import anthropic
import json

client = anthropic.Anthropic()

# ========================
# 第一步：定义工具
# ========================
# 每个工具包含：名称、描述、输入参数的JSON Schema
# LLM根据描述决定何时调用哪个工具

def calculate(expression: str) -> str:
    """安全地计算数学表达式"""
    # 注意：生产环境不要用eval！这里仅作学习演示
    # 生产环境应该用 ast.literal_eval 或 math 库
    try:
        # 只允许数学操作
        allowed = set("0123456789+-*/().% ")
        if not all(c in allowed for c in expression):
            return "Error: 不允许的字符"
        result = eval(expression)
        return str(result)
    except Exception as e:
        return f"Error: {e}"


def finish(answer: str) -> str:
    """任务完成，返回最终答案"""
    # 这是一个特殊的"终止工具"
    # 当Agent认为自己完成了任务，就调用这个工具
    return answer


# 工具Schema定义 — 这是LLM理解工具的唯一途径
tools = [
    {
        "name": "calculate",
        "description": "计算数学表达式。当需要做任何数学运算时使用。",
        "input_schema": {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "数学表达式，如 '2 + 2' 或 '(10 * 5) / 2'"
                }
            },
            "required": ["expression"]
        }
    },
    {
        "name": "finish",
        "description": "当你得出最终答案时调用此工具。不要再做其他计算。",
        "input_schema": {
            "type": "object",
            "properties": {
                "answer": {
                    "type": "string",
                    "description": "最终答案"
                }
            },
            "required": ["answer"]
        }
    }
]


# ========================
# 第二步：工具执行器
# ========================

def execute_tool(name: str, inputs: dict) -> str:
    """根据工具名称分发到对应的实现函数"""
    if name == "calculate":
        return calculate(inputs["expression"])
    elif name == "finish":
        return finish(inputs["answer"])
    else:
        return f"Error: 未知工具 '{name}'"


# ========================
# 第三步：Agent核心循环（最关键的部分）
# ========================

def run_agent(user_message: str, max_iterations: int = 10) -> str:
    """
    Agent的主循环 — 这就是ReAct模式的本质
    
    工作原理：
    1. 把用户消息发给LLM
    2. LLM决定：是直接回答？还是调用工具？
    3. 如果调用工具 → 执行工具 → 把结果反馈给LLM → 回到步骤1
    4. 如果直接回答 → 返回结果
    5. 如果超过最大迭代次数 → 强制终止
    """
    messages = [{"role": "user", "content": user_message}]
    
    # 系统提示 — 定义Agent的角色和行为规则
    system_prompt = """你是一个数学助手。使用 calculate 工具进行计算。
当你得出最终答案时，使用 finish 工具返回答案。
重要：必须调用 finish 工具返回答案，不要直接回复文本。"""
    
    for iteration in range(max_iterations):
        print(f"\n--- 迭代 {iteration + 1}/{max_iterations} ---")
        
        # 调用Claude API
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            system=system_prompt,
            messages=messages,
            tools=tools
        )
        
        # 检查LLM的响应类型
        if response.stop_reason == "tool_use":
            # LLM想要调用工具
            for block in response.content:
                if block.type == "tool_use":
                    print(f"🔧 调用工具: {block.name}({block.input})")
                    
                    # 特殊处理：finish工具表示任务完成
                    if block.name == "finish":
                        print(f"✅ 最终答案: {block.input['answer']}")
                        return block.input["answer"]
                    
                    # 执行工具
                    result = execute_tool(block.name, block.input)
                    print(f"📊 工具结果: {result}")
                    
                    # 把工具调用和结果添加到消息历史
                    # 这一步很关键：LLM需要看到工具的结果才能继续推理
                    messages.append({"role": "assistant", "content": response.content})
                    messages.append({
                        "role": "user",
                        "content": [{
                            "type": "tool_result",
                            "tool_use_id": block.id,  # 必须关联！
                            "content": result
                        }]
                    })
        elif response.stop_reason == "end_turn":
            # LLM直接给出了文本回答（没调用工具）
            text = next((b.text for b in response.content if hasattr(b, 'text')), "")
            print(f"💬 直接回答: {text}")
            return text
        else:
            print(f"⚠️ 意外停止原因: {response.stop_reason}")
            return f"Agent异常终止: {response.stop_reason}"
    
    return "⚠️ 达到最大迭代次数，Agent未能完成任务"


# ========================
# 第四步：运行测试
# ========================

if __name__ == "__main__":
    test_cases = [
        "What is (1847 * 23) + (512 / 4)?",      # 复合运算
        "Calculate 2**10 and then multiply by 3",   # 多步运算
        "What is 15% of 2340?",                     # 百分比
    ]
    
    for question in test_cases:
        print(f"\n{'='*50}")
        print(f"❓ 问题: {question}")
        print(f"{'='*50}")
        answer = run_agent(question)
        print(f"\n🎯 最终结果: {answer}")
```

## 核心原理图解

```
用户提问
  │
  ▼
┌─────────────────────────────┐
│  Claude API（带工具定义）    │
│  ┌───────────────────────┐  │
│  │  LLM 思考：           │  │
│  │  需要计算吗？         │  │
│  │  → 是：调用calculate  │  │
│  │  → 否：调用finish     │  │
│  └───────────────────────┘  │
└──────────────┬──────────────┘
               │
       ┌───────┴───────┐
       │ stop_reason?  │
       └───┬───────┬───┘
           │       │
    tool_use    end_turn
           │       │
           ▼       ▼
    ┌──────────┐  返回
    │ 执行工具  │  文本
    │ 得到结果  │
    └────┬─────┘
         │
         │ 把结果加到messages
         │
         └───────→ 回到顶部 ──→ 循环！
```

## 关键知识点

### 1. stop_reason 的三种状态
- `tool_use`：LLM想调用工具（最常见的情况）
- `end_turn`：LLM认为可以结束了，直接给文本回答
- `max_tokens`：输出被截断了（通常是bug，需要处理）

### 2. tool_use 块结构
```json
{
  "type": "tool_use",
  "id": "toolu_xxx",          // 唯一ID，tool_result必须关联
  "name": "calculate",         // 工具名
  "input": {"expression": "..."} // 工具参数
}
```

### 3. tool_result 必须关联 tool_use_id
这是初学者最容易犯错的地方！如果不关联，LLM会混乱。

### 4. max_iterations 防止无限循环
Agent可能在某些情况下反复调用工具（比如计算结果又触发新的计算），必须设置上限。

## 练习扩展

完成基础版本后，试试这些挑战：

1. **添加新工具**：添加一个 `search_web` 工具（可以用假的模拟数据）
2. **错误恢复**：当工具返回"Error"时，让Agent能自己处理错误
3. **对话历史**：支持多轮对话（用户可以追问）
4. **可视化日志**：用emoji和颜色让Agent的思考过程更好看
