# 第3关：记忆系统 - 完整参考实现

## 核心原理

LLM 本身是无状态的——每次调用都是全新的。Agent 要"记住"东西，靠的是把历史信息塞进 prompt。

这关实现三层记忆：

```
工作记忆（Working Memory）
  → 当前对话的消息列表，直接传给 LLM
  → 容量有限（token 窗口），会"过期"

短期记忆（Short-term Memory）  
  → 近期会话的摘要，保留关键信息
  → 滑动窗口，最近5轮对话摘要

长期记忆（Long-term Memory）
  → 跨会话的知识库，向量检索
  → 持久化到磁盘，永远不丢
```

---

## 完整实现

```python
"""
三层记忆系统
- 工作记忆：当前对话上下文（messages列表）
- 短期记忆：近期会话摘要（滑动窗口）
- 长期记忆：跨会话知识（向量检索）
"""
import json
import os
import hashlib
from datetime import datetime
from typing import Optional

class WorkingMemory:
    """工作记忆 — 当前会话的消息列表"""
    
    def __init__(self, max_messages: int = 50):
        self.messages: list[dict] = []
        self.max_messages = max_messages
    
    def add(self, role: str, content: str):
        """添加消息（支持 user/assistant/tool 角色）"""
        self.messages.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
        })
    
    def get_recent(self, n: int = 10) -> list[dict]:
        """获取最近n条消息"""
        return self.messages[-n:]
    
    def clear(self):
        """清空工作记忆"""
        self.messages.clear()
    
    def count(self) -> int:
        return len(self.messages)
    
    def estimate_tokens(self) -> int:
        """粗略估算token数（1个中文字≈2token，1个英文词≈1.3token）"""
        total_chars = sum(len(m.get("content", "")) for m in self.messages)
        return int(total_chars * 1.5)


class ShortTermMemory:
    """短期记忆 — 近期会话摘要，滑动窗口"""
    
    def __init__(self, max_summaries: int = 10, max_tokens_per_summary: int = 500):
        self.summaries: list[dict] = []
        self.max_summaries = max_summaries
        self.max_tokens = max_tokens_per_summary
    
    def add(self, summary: str, metadata: dict | None = None):
        """添加一轮对话的摘要"""
        entry = {
            "summary": summary,
            "metadata": metadata or {},
            "timestamp": datetime.now().isoformat(),
        }
        self.summaries.append(entry)
        
        # 滑动窗口：超出容量时丢弃最旧的
        if len(self.summaries) > self.max_summaries:
            self.summaries.pop(0)
    
    def get_context(self, n: int = 3) -> list[str]:
        """获取最近n条摘要"""
        return [s["summary"] for s in self.summaries[-n:]]
    
    def get_all(self) -> list[dict]:
        return self.summaries


class LongTermMemory:
    """长期记忆 — 基于关键字的简单检索（无向量库依赖版）
    
    注意：生产环境建议用 FAISS 或 ChromaDB 做向量检索。
    这里用关键字匹配做简化版，原理一样。
    """
    
    def __init__(self, storage_path: str = "long_term_memory.json"):
        self.storage_path = storage_path
        self.memories: list[dict] = []
        self._load()
    
    def _load(self):
        """从磁盘加载记忆"""
        if os.path.exists(self.storage_path):
            with open(self.storage_path, "r", encoding="utf-8") as f:
                self.memories = json.load(f)
    
    def _save(self):
        """保存记忆到磁盘"""
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(self.memories, f, ensure_ascii=False, indent=2)
    
    def store(self, content: str, metadata: dict | None = None):
        """存储一条记忆"""
        entry = {
            "content": content,
            "metadata": metadata or {},
            "timestamp": datetime.now().isoformat(),
            # 简化版：用关键字做索引（生产环境用 embedding）
            "keywords": self._extract_keywords(content),
        }
        self.memories.append(entry)
        self._save()
    
    def search(self, query: str, top_k: int = 3) -> list[dict]:
        """检索与query最相关的top_k条记忆"""
        query_keywords = self._extract_keywords(query)
        scored = []
        
        for memory in self.memories:
            # 计算关键词重叠度作为相关度分数
            overlap = len(set(query_keywords) & set(memory["keywords"]))
            if overlap > 0:
                scored.append((memory, overlap))
        
        # 按相关度排序
        scored.sort(key=lambda x: x[1], reverse=True)
        return [item[0] for item in scored[:top_k]]
    
    def _extract_keywords(self, text: str) -> list[str]:
        """提取关键词（简化版：按空格和标点分割）"""
        import re
        # 中英文分词
        words = re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z]+', text.lower())
        # 过滤太短的词
        return [w for w in words if len(w) >= 2]
    
    def count(self) -> int:
        return len(self.memories)


class MemoryManager:
    """记忆管理器 — 统一管理三层记忆"""
    
    def __init__(
        self,
        long_term_path: str = "long_term_memory.json",
        max_working_messages: int = 50,
        max_short_term_summaries: int = 10,
    ):
        self.working = WorkingMemory(max_messages=max_working_messages)
        self.short_term = ShortTermMemory(max_summaries=max_short_term_summaries)
        self.long_term = LongTermMemory(storage_path=long_term_path)
    
    def add_message(self, role: str, content: str):
        """添加一条消息到工作记忆"""
        self.working.add(role, content)
    
    def get_full_context(self, query: str = "", max_tokens: int = 8000) -> str:
        """
        构建完整上下文（传给LLM的prompt前缀）
        
        组合策略：
        1. 长期记忆相关内容（最省空间，最持久）
        2. 短期记忆摘要（最近几次对话的要点）
        3. 工作记忆（当前对话的原始消息）
        """
        parts = []
        estimated_tokens = 0
        
        # 1. 长期记忆
        if query:
            lt_memories = self.long_term.search(query, top_k=3)
            if lt_memories:
                lt_text = "\n".join(f"- {m['content']}" for m in lt_memories)
                parts.append(f"[相关历史记忆]\n{lt_text}")
                estimated_tokens += len(lt_text) * 2
        
        # 2. 短期记忆
        st_summaries = self.short_term.get_context(n=3)
        if st_summaries:
            st_text = "\n".join(f"- {s}" for s in st_summaries)
            parts.append(f"[近期对话摘要]\n{st_text}")
            estimated_tokens += len(st_text) * 2
        
        # 3. 工作记忆
        recent = self.working.get_recent(n=20)
        if recent:
            wm_text = "\n".join(f"{m['role']}: {m['content']}" for m in recent)
            parts.append(f"[当前对话]\n{wm_text}")
            estimated_tokens += len(wm_text) * 2
        
        return "\n\n".join(parts)
    
    def end_conversation(self, summary: str):
        """结束一轮对话：将工作记忆摘要存入短期和长期记忆"""
        # 存入短期记忆
        self.short_term.add(summary)
        
        # 存入长期记忆（提取关键信息）
        if len(summary) > 10:  # 过滤太短的摘要
            self.long_term.store(summary, {
                "source": "conversation_summary",
                "message_count": self.working.count(),
            })
        
        # 清空工作记忆
        self.working.clear()
    
    def get_status(self) -> dict:
        """获取记忆系统状态"""
        return {
            "working_memory": {
                "messages": self.working.count(),
                "estimated_tokens": self.working.estimate_tokens(),
            },
            "short_term": {
                "summaries": len(self.short_term.summaries),
            },
            "long_term": {
                "total_memories": self.long_term.count(),
            },
        }


# ===== 使用示例 =====

if __name__ == "__main__":
    mm = MemoryManager(long_term_path="test_memory.json")
    
    # 模拟一次对话
    mm.add_message("user", "我想学习Python")
    mm.add_message("assistant", "好的！Python是一门很好的入门语言。")
    mm.add_message("user", "推荐一些学习资源")
    mm.add_message("assistant", "推荐：1. Python官方教程 2. Automate the Boring Stuff")
    
    # 查看上下文
    print("=== 完整上下文 ===")
    print(mm.get_full_context("Python学习"))
    
    # 结束对话，存入记忆
    mm.end_conversation("用户想学Python，推荐了官方教程和ATBS两本书")
    
    # 新的对话
    mm.add_message("user", "之前推荐的那本书叫什么来着？")
    print("\n=== 新对话上下文（带记忆检索） ===")
    print(mm.get_full_context("推荐的书"))
    
    # 查看状态
    print("\n=== 记忆状态 ===")
    print(json.dumps(mm.get_status(), indent=2))
    
    # 清理测试文件
    if os.path.exists("test_memory.json"):
        os.remove("test_memory.json")
```

---

## 关键设计决策

### 1. 为什么不用向量数据库做第一版？

向量数据库（FAISS/ChromaDB）需要额外的依赖和 embedding API。
先用关键词匹配做简化版，**架构一样**，只是把 `search()` 里的匹配逻辑替换成余弦相似度即可升级。

```python
# 简化版（本关）：关键词重叠度
overlap = len(set(query_kw) & set(memory_kw))

# 升级版（第5关）：余弦相似度
similarity = cosine_similarity(query_embedding, memory_embedding)
```

### 2. 工作记忆的溢出策略

| 策略 | 优点 | 缺点 |
|------|------|------|
| 直接截断 | 简单 | 丢失开头信息 |
| 滑动窗口 | 保留最近 | 丢失早期但重要的 |
| 摘要压缩 | 保留要点 | 摘要本身有损失 |
| **混合**（推荐） | 兼顾新旧 | 实现稍复杂 |

### 3. 什么时候该 end_conversation？

- Agent 完成一个完整任务后
- 对话轮次超过阈值（如20轮）
- 用户明确切换话题时

---

## 练习题

1. **消息压缩器**：当工作记忆超过 max_messages 时，自动将旧消息压缩为摘要
2. **记忆重要性评分**：给每条长期记忆加一个 importance 分数，重要记忆不会被滑动窗口丢弃
3. **对话去重**：在存入长期记忆前，检查是否已有相似记忆，避免重复存储
