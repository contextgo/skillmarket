# 第8关：多Agent协作 - 完整参考实现

## 核心原理

单个Agent的能力天花板 = LLM能力 + 工具数量 + prompt质量。

突破天花板的办法：**让多个Agent各司其职，互相协作**。

三种协作模式：
```
1. 顺序管道（Pipeline）
   Researcher → Writer → Editor
   每个Agent的输出是下一个的输入

2. 并行执行（Parallel）
   Analyst_A ─┐
   Analyst_B ─┼→ Synthesizer
   Analyst_C ─┘
   多个Agent同时工作，结果合并

3. 层级委派（Hierarchical）
   Manager → 分配任务给 Worker_A / Worker_B / Worker_C
   一个"管理者"Agent统筹全局
```

---

## 完整实现

```python
"""
多Agent协作系统
核心概念：
  Agent: 有独立角色和工具的智能体
  Message: Agent间通信的消息
  Pipeline: 顺序执行多个Agent
  ParallelExecutor: 并行执行多个Agent
  HierarchicalManager: 层级委派管理
"""
import json
import time
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed


# ============================================================
# 基础组件：Agent基类和消息
# ============================================================

@dataclass
class Message:
    """Agent间通信的消息"""
    sender: str
    receiver: str
    content: str
    metadata: dict = field(default_factory=dict)
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            from datetime import datetime
            self.timestamp = datetime.now().isoformat()


class BaseAgent:
    """Agent基类 — 所有Agent的统一接口"""
    
    def __init__(self, name: str, role: str, system_prompt: str = ""):
        self.name = name
        self.role = role
        self.system_prompt = system_prompt
        self.inbox: list[Message] = []
        self.outbox: list[Message] = []
    
    def receive(self, message: Message):
        """接收消息"""
        self.inbox.append(message)
    
    def send(self, receiver: str, content: str, metadata: dict = None) -> Message:
        """发送消息"""
        msg = Message(
            sender=self.name, receiver=receiver,
            content=content, metadata=metadata or {}
        )
        self.outbox.append(msg)
        return msg
    
    def process(self, input_data: str) -> str:
        """
        处理输入，返回输出
        子类必须实现此方法
        """
        raise NotImplementedError
    
    def __repr__(self):
        return f"Agent({self.name}, {self.role})"


# ============================================================
# 模式1：顺序管道（Pipeline）
# ============================================================

class Pipeline:
    """顺序管道 — Agent A → B → C → ..."""
    
    def __init__(self, name: str = "Pipeline"):
        self.name = name
        self.agents: list[BaseAgent] = []
        self.execution_log: list[dict] = []
    
    def add(self, agent: BaseAgent):
        """添加Agent到管道"""
        self.agents.append(agent)
        return self
    
    def run(self, initial_input: str) -> dict:
        """按顺序执行所有Agent"""
        current_output = initial_input
        
        for i, agent in enumerate(self.agents):
            start_time = time.time()
            
            try:
                current_output = agent.process(current_output)
                status = "success"
            except Exception as e:
                current_output = f"[ERROR in {agent.name}] {e}"
                status = "failed"
            
            elapsed = time.time() - start_time
            self.execution_log.append({
                "step": i + 1,
                "agent": agent.name,
                "role": agent.role,
                "input_preview": current_output[:200] if current_output else "",
                "output_preview": current_output[:200] if current_output else "",
                "status": status,
                "elapsed_seconds": round(elapsed, 2),
            })
            
            print(f"  Step {i+1}: {agent.name} ({agent.role}) - {status} ({elapsed:.1f}s)")
            
            if status == "failed":
                break
        
        return {
            "final_output": current_output,
            "steps_completed": len([l for l in self.execution_log if l["status"] == "success"]),
            "total_steps": len(self.agents),
            "log": self.execution_log,
        }


# ============================================================
# 模式2：并行执行（Parallel）
# ============================================================

class ParallelExecutor:
    """并行执行 — 多个Agent同时工作"""
    
    def __init__(self, name: str = "Parallel", max_workers: int = 4):
        self.name = name
        self.workers: list[tuple[BaseAgent, str]] = []  # (agent, input)
        self.max_workers = max_workers
    
    def add_worker(self, agent: BaseAgent, task_input: str):
        """添加并行任务"""
        self.workers.append((agent, task_input))
        return self
    
    def run(self) -> dict:
        """并行执行所有任务"""
        results = {}
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_agent = {
                executor.submit(agent.process, task_input): (agent, task_input)
                for agent, task_input in self.workers
            }
            
            for future in as_completed(future_to_agent):
                agent, task_input = future_to_agent[future]
                try:
                    result = future.result()
                    results[agent.name] = {"status": "success", "result": result}
                except Exception as e:
                    results[agent.name] = {"status": "failed", "error": str(e)}
        
        return results


# ============================================================
# 模式3：层级委派（Hierarchical）
# ============================================================

class HierarchicalManager(BaseAgent):
    """层级管理者Agent — 分配任务、合并结果"""
    
    def __init__(self, name: str = "Manager", workers: list[BaseAgent] = None):
        super().__init__(name, "Manager", "你是一个团队管理者，负责分析任务并分配给合适的团队成员。")
        self.workers = workers or []
    
    def add_worker(self, agent: BaseAgent):
        self.workers.append(agent)
    
    def process(self, task: str) -> str:
        """分析任务并分配给合适的worker"""
        # 1. 分析任务，决定分配给谁
        assignments = self._analyze_and_assign(task)
        
        print(f"  [Manager] 任务分配: {json.dumps(assignments, ensure_ascii=False)}")
        
        # 2. 执行分配的任务
        results = {}
        for agent_name, subtask in assignments.items():
            worker = next((w for w in self.workers if w.name == agent_name), None)
            if worker:
                results[agent_name] = worker.process(subtask)
        
        # 3. 合并结果
        final = self._synthesize(results)
        return final
    
    def _analyze_and_assign(self, task: str) -> dict[str, str]:
        """分析任务并分配（简化版，实际用LLM）"""
        assignments = {}
        for worker in self.workers:
            assignments[worker.name] = f"关于'{task}'的{worker.role}工作"
        return assignments
    
    def _synthesize(self, results: dict[str, str]) -> str:
        """合并所有worker的结果"""
        parts = []
        for name, result in results.items():
            parts.append(f"## {name} 的贡献\n{result}")
        return "\n\n".join(parts)


# ============================================================
# 实战：研究团队
# ============================================================

class MockAgent(BaseAgent):
    """模拟Agent（实际项目中替换为调用LLM的Agent）"""
    
    def process(self, input_data: str) -> str:
        return f"[{self.name}] 基于 '{input_data[:50]}...' 生成了{self.role}内容。"


def demo_research_team():
    """演示：研究团队协作完成一份报告"""
    
    # 创建团队成员
    researcher = MockAgent("Researcher", "信息收集与整理")
    analyst = MockAgent("Analyst", "深度数据分析")
    writer = MockAgent("Writer", "报告撰写")
    reviewer = MockAgent("Reviewer", "质量审查")
    
    # ===== 模式1：顺序管道 =====
    print("=== 顺序管道模式 ===")
    pipeline = Pipeline("Research Pipeline")
    pipeline.add(researcher).add(analyst).add(writer).add(reviewer)
    result = pipeline.run("研究2026年AI Agent的发展趋势")
    print(f"\n最终输出: {result['final_output'][:100]}...")
    
    # ===== 模式2：并行分析 =====
    print("\n=== 并行执行模式 ===")
    parallel = ParallelExecutor("Multi-Analyst", max_workers=3)
    parallel.add_worker(
        MockAgent("TechAnalyst", "技术分析"),
        "分析Agent的技术架构趋势"
    ).add_worker(
        MockAgent("MarketAnalyst", "市场分析"),
        "分析Agent的市场接受度"
    ).add_worker(
        MockAgent("EthicsAnalyst", "伦理分析"),
        "分析Agent的伦理挑战"
    )
    results = parallel.run()
    for name, data in results.items():
        print(f"  {name}: {data['status']}")
    
    # ===== 模式3：层级委派 =====
    print("\n=== 层级委派模式 ===")
    manager = HierarchicalManager("PM", [researcher, analyst, writer])
    result = manager.process("撰写一份AI Agent行业研究报告")
    print(f"\n最终输出: {result[:200]}...")


if __name__ == "__main__":
    demo_research_team()
```

---

## 关键设计决策

### 1. 三种模式的选择

| 模式 | 通信量 | 并行度 | 复杂度 | 适用场景 |
|------|-------|--------|--------|---------|
| 顺序 | 低 | 无 | 低 | 有明确步骤的流程 |
| 并行 | 中 | 高 | 中 | 独立维度同时分析 |
| 层级 | 高 | 中 | 高 | 复杂任务需要灵活分配 |

### 2. 为什么需要 Message 抽象？

直接函数调用也行，但 Message 带来的好处：
- **可审计**：每条消息有时间戳和元数据
- **可异步**：消息可以排队等待
- **可调试**：消息日志是排错利器

---

## 练习题

1. **消息总线**：实现一个 MessageBus 类，Agent 不直接通信，而是通过 Bus 转发
2. **动态组队**：Manager 根据任务类型，从 Agent 池中动态选择合适的成员
3. **Agent 间协商**：两个 Agent 意见不一致时，引入"辩论"机制解决冲突
