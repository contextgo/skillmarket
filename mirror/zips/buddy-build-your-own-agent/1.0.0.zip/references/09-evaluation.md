# 第9关：评估与优化 - 完整参考实现

## 核心原理

"你无法改进你无法衡量的东西。" — Peter Drucker

Agent 评估系统回答三个问题：
1. **做得好吗？**（成功率、准确率）
2. **快不快？**（延迟、迭代次数）
3. **贵不贵？**（Token消耗、成本）

---

## 完整实现

```python
"""
Agent评估系统 — 数据驱动优化
核心组件：
  1. AgentEvaluator: 运行测试并收集指标
  2. TestSetGenerator: 自动生成测试用例
  3. ReportGenerator: 生成可视化评估报告
  4. ABComparator: A/B对比不同版本
"""
import json
import time
import statistics
from dataclasses import dataclass, field, asdict
from typing import Callable, Any
from datetime import datetime


# ============================================================
# 1. 评估框架
# ============================================================

@dataclass
class EvaluationResult:
    """单次评估结果"""
    test_id: str
    prompt: str
    expected: str
    actual: str
    success: bool
    iterations: int          # Agent循环次数
    latency_ms: float        # 响应时间（毫秒）
    tokens_used: int         # Token消耗
    tools_called: list[str]  # 调用了哪些工具
    error: str = ""          # 错误信息
    notes: str = ""          # 评估者备注


@dataclass
class MetricsSummary:
    """指标汇总"""
    total_tests: int = 0
    success_count: int = 0
    success_rate: float = 0.0
    avg_iterations: float = 0.0
    avg_latency_ms: float = 0.0
    avg_tokens: float = 0.0
    p50_latency: float = 0.0
    p95_latency: float = 0.0
    tool_accuracy: float = 0.0
    total_cost_usd: float = 0.0


class AgentEvaluator:
    """Agent评估器"""
    
    def __init__(self, agent_fn: Callable, judge_fn: Callable = None):
        """
        agent_fn: 被测试的Agent函数 (prompt: str) -> str
        judge_fn: 判断Agent输出是否正确 (actual: str, expected: str) -> bool
                  如果不提供，用简单的字符串包含判断
        """
        self.agent_fn = agent_fn
        self.judge_fn = judge_fn or self._default_judge
    
    def _default_judge(self, actual: str, expected: str) -> bool:
        """默认判断：期望输出的关键内容是否出现在实际输出中"""
        # 提取期望中的关键词
        keywords = [w for w in expected.split() if len(w) > 2]
        matches = sum(1 for kw in keywords if kw.lower() in actual.lower())
        return matches >= len(keywords) * 0.5  # 50%关键词匹配即算通过
    
    def run_test(self, test_id: str, prompt: str, expected: str,
                 track_tokens: bool = False) -> EvaluationResult:
        """运行单个测试"""
        start = time.time()
        iterations = 0
        tools_called = []
        
        try:
            # 调用Agent
            actual = self.agent_fn(prompt)
            
            # 简单追踪：如果actual包含"iteration"信息就提取
            # （实际项目中需要在Agent内部埋点统计）
            
        except Exception as e:
            actual = ""
            return EvaluationResult(
                test_id=test_id, prompt=prompt, expected=expected,
                actual=actual, success=False,
                iterations=iterations,
                latency_ms=(time.time() - start) * 1000,
                tokens_used=0, tools_called=tools_called,
                error=str(e),
            )
        
        latency = (time.time() - start) * 1000
        
        # 判断是否通过
        success = self.judge_fn(actual, expected)
        
        return EvaluationResult(
            test_id=test_id, prompt=prompt, expected=expected,
            actual=actual, success=success,
            iterations=iterations, latency_ms=latency,
            tokens_used=0, tools_called=tools_called,
        )
    
    def run_suite(self, test_cases: list[dict]) -> tuple[list[EvaluationResult], MetricsSummary]:
        """运行完整测试套件"""
        results = []
        
        for tc in test_cases:
            result = self.run_test(
                test_id=tc["id"],
                prompt=tc["prompt"],
                expected=tc["expected"],
            )
            results.append(result)
            status = "✅" if result.success else "❌"
            print(f"  {status} [{tc['id']}] {result.latency_ms:.0f}ms")
        
        summary = self._compute_summary(results)
        return results, summary
    
    def _compute_summary(self, results: list[EvaluationResult]) -> MetricsSummary:
        """计算汇总指标"""
        if not results:
            return MetricsSummary()
        
        successes = [r for r in results if r.success]
        latencies = [r.latency_ms for r in results]
        
        sorted_latencies = sorted(latencies)
        p50 = sorted_latencies[len(sorted_latencies) // 2]
        p95_idx = int(len(sorted_latencies) * 0.95)
        p95 = sorted_latencies[min(p95_idx, len(sorted_latencies) - 1)]
        
        return MetricsSummary(
            total_tests=len(results),
            success_count=len(successes),
            success_rate=len(successes) / len(results) * 100,
            avg_iterations=statistics.mean([r.iterations for r in results]) if results else 0,
            avg_latency_ms=statistics.mean(latencies) if latencies else 0,
            avg_tokens=statistics.mean([r.tokens_used for r in results]) if results else 0,
            p50_latency=p50,
            p95_latency=p95,
        )


# ============================================================
# 2. 测试用例生成器
# ============================================================

class TestSetGenerator:
    """自动生成测试用例"""
    
    def __init__(self, categories: list[str] = None):
        self.categories = categories or [
            "math", "search", "file_ops", "reasoning", "multi_step"
        ]
    
    def generate(self, count: int = 10) -> list[dict]:
        """
        生成测试用例
        实际项目中用LLM生成，这里用模板
        """
        templates = {
            "math": [
                {"id": "math_1", "prompt": "计算 (1847 * 23) + (512 / 4)", "expected": "42541"},
                {"id": "math_2", "prompt": "2的10次方等于多少", "expected": "1024"},
                {"id": "math_3", "prompt": "一个商品原价200元，打8折后再减30元，最终价格？", "expected": "130"},
            ],
            "reasoning": [
                {"id": "reason_1", "prompt": "如果所有A都是B，所有B都是C，那么所有A都是什么？", "expected": "C"},
                {"id": "reason_2", "prompt": "一个房间里有3盏灯和3个开关，每个开关控制一盏灯。你只能进房间一次，怎么确定每个开关对应哪盏灯？", "expected": "先开1号开关等10分钟，关掉1号打开2号，进房间：亮的=2号，热的=1号，冷的=3号"},
            ],
            "multi_step": [
                {"id": "multi_1", "prompt": "搜索Python最新版本号，然后用这个版本号写一个版本说明文件", "expected": "文件中应包含Python版本号"},
                {"id": "multi_2", "prompt": "帮我搜索AI Agent的定义，整理成3个要点，保存到agent_def.md", "expected": "文件应包含3个要点"},
            ],
        }
        
        # 收集测试用例
        tests = []
        for cat in self.categories:
            if cat in templates:
                tests.extend(templates[cat])
        
        return tests[:count]


# ============================================================
# 3. 评估报告生成器
# ============================================================

class ReportGenerator:
    """生成Markdown格式的评估报告"""
    
    def generate(self, results: list[EvaluationResult], summary: MetricsSummary,
                 version: str = "1.0") -> str:
        """生成完整报告"""
        lines = [
            f"# Agent 评估报告 v{version}",
            f"",
            f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"",
            "## 总览",
            "",
            f"| 指标 | 值 | 目标 | 达标 |",
            f"|------|-----|------|------|",
            f"| 成功率 | {summary.success_rate:.1f}% | > 90% | {'✅' if summary.success_rate > 90 else '❌'} |",
            f"| 平均延迟 | {summary.avg_latency_ms:.0f}ms | < 5000ms | {'✅' if summary.avg_latency_ms < 5000 else '❌'} |",
            f"| P95延迟 | {summary.p95_latency:.0f}ms | < 10000ms | {'✅' if summary.p95_latency < 10000 else '❌'} |",
            f"| 平均迭代 | {summary.avg_iterations:.1f} | 2-5 | {'✅' if 2 <= summary.avg_iterations <= 5 else '⚠️'} |",
            f"| 测试总数 | {summary.total_tests} | - | - |",
            "",
            "## 详细结果",
            "",
        ]
        
        for r in results:
            status = "✅ PASS" if r.success else "❌ FAIL"
            lines.append(f"### [{r.test_id}] {status}")
            lines.append(f"- **Prompt**: {r.prompt[:100]}")
            if r.error:
                lines.append(f"- **Error**: {r.error}")
            lines.append(f"- **Latency**: {r.latency_ms:.0f}ms")
            lines.append("")
        
        # 失败分析
        failures = [r for r in results if not r.success]
        if failures:
            lines.append("## 失败分析")
            lines.append("")
            for f in failures:
                lines.append(f"- **{f.test_id}**: {f.error or '输出不符合预期'}")
            lines.append("")
        
        # 改进建议
        lines.append("## 改进建议")
        lines.append("")
        if summary.success_rate < 90:
            lines.append("1. 成功率低于90% — 检查失败用例的共同模式，可能是工具描述不够清晰")
        if summary.p95_latency > 10000:
            lines.append("2. P95延迟过高 — 考虑优化工具调用链或减少不必要的LLM调用")
        if summary.avg_iterations > 5:
            lines.append("3. 平均迭代次数偏高 — Agent可能在"来回"调用工具，检查规划系统")
        if not failures:
            lines.append("所有测试通过！可以考虑增加更多边界用例。")
        
        return "\n".join(lines)


# ============================================================
# 4. A/B对比
# ============================================================

class ABComparator:
    """A/B测试对比两个版本的Agent"""
    
    def __init__(self, agent_a_fn: Callable, agent_b_fn: Callable, judge_fn: Callable = None):
        self.agent_a = agent_a_fn
        self.agent_b = agent_b_fn
        self.judge = judge_fn
    
    def compare(self, test_cases: list[dict]) -> dict:
        """对比两个版本"""
        evaluator_a = AgentEvaluator(self.agent_a, self.judge)
        evaluator_b = AgentEvaluator(self.agent_b, self.judge)
        
        results_a, summary_a = evaluator_a.run_suite(test_cases)
        results_b, summary_b = evaluator_b.run_suite(test_cases)
        
        return {
            "version_a": asdict(summary_a),
            "version_b": asdict(summary_b),
            "delta": {
                "success_rate": summary_b.success_rate - summary_a.success_rate,
                "avg_latency_ms": summary_b.avg_latency_ms - summary_a.avg_latency_ms,
            },
            "winner": "A" if summary_a.success_rate > summary_b.success_rate else
                      "B" if summary_b.success_rate > summary_a.success_rate else "Tie",
            "per_test": [
                {
                    "id": tc["id"],
                    "a_pass": results_a[i].success,
                    "b_pass": results_b[i].success,
                    "a_latency": results_a[i].latency_ms,
                    "b_latency": results_b[i].latency_ms,
                }
                for i, tc in enumerate(test_cases)
            ],
        }


# ===== 使用示例 =====

if __name__ == "__main__":
    print("=== Agent 评估系统 ===\n")
    
    # 模拟Agent
    def mock_agent(prompt: str) -> str:
        if "计算" in prompt or "数学" in prompt:
            return "计算结果是 42541"
        return f"关于'{prompt}'的分析结果..."
    
    def mock_agent_v2(prompt: str) -> str:
        if "计算" in prompt or "数学" in prompt:
            return "经过计算，(1847 * 23) + (512 / 4) = 42541"
        return f"深入分析'{prompt}'后，得出以下结论..."
    
    # 生成测试集
    gen = TestSetGenerator(["math", "reasoning", "multi_step"])
    tests = gen.generate(5)
    print(f"生成了 {len(tests)} 个测试用例\n")
    
    # 运行评估
    evaluator = AgentEvaluator(mock_agent)
    results, summary = evaluator.run_suite(tests)
    
    # 生成报告
    reporter = ReportGenerator()
    report = reporter.generate(results, summary)
    print(report)
    
    # A/B对比
    print("\n=== A/B对比 ===")
    comparator = ABComparator(mock_agent, mock_agent_v2)
    comparison = comparator.compare(tests[:3])
    print(f"获胜方: {comparison['winner']}")
    print(f"成功率差异: {comparison['delta']['success_rate']:.1f}%")
```

---

## 关键设计决策

### 1. 评估指标的"黄金三角"

```
        成功率
         /\
        /  \
       /    \
      /  平衡  \
     /   区域   \
    /____________\
  延迟 ←--------→ 成本
```

三者互相制约：
- 想提高成功率 → 可能增加迭代次数 → 成本上升
- 想降低延迟 → 可能跳过一些步骤 → 成功率下降
- 想降低成本 → 用小模型 → 成功率可能下降

评估的意义不是"全部最优"，而是找到**可接受的平衡点**。

### 2. 测试用例的质量 > 数量

10个好测试用例 > 100个随意生成的测试用例。

好测试用例覆盖：
- 常见场景（80%）
- 边界情况（15%）
- 异常情况（5%）

---

## 练习题

1. **自动化Judge**：用LLM代替 `_default_judge`，让判断更智能
2. **回归测试**：修改Agent后自动跑一遍测试集，确保没有"回退"
3. **评估Dashboard**：用HTML生成可视化仪表板（成功率折线图、延迟分布图）
