# 第10关：自进化Agent - 完整参考实现

## 核心原理

这关是整个课程的**终极Boss**——让Agent能从自己的经验中学习，越用越聪明。

三层架构（借鉴 OpenSpace 自进化系统）：

```
执行层（Execution Layer）
  Agent完成具体任务，记录过程和结果
  
    ↓ 经验沉淀
  
记忆层（Memory Layer）
  从成功/失败中提取模式 → 经验库（experience_pool）
  成功模式 → "这个工具组合在XX场景很有效"
  失败模式 → "遇到XX情况时，不要用YY方法"
  
    ↓ 规则提取
  
进化层（Evolution Layer）
  更新系统提示词（System Prompt Optimization）
  优化工具选择策略（Tool Selection Learning）
  改进规划模板（Plan Template Refinement）
```

---

## 完整实现

```python
"""
自进化Agent — 从经验中学习，越用越聪明
三层架构：执行 → 沉淀 → 进化
"""
import json
import os
import re
from dataclasses import dataclass, field, asdict
from typing import Optional
from datetime import datetime
from collections import Counter


# ============================================================
# 第一层：经验记录器
# ============================================================

@dataclass
class ExecutionRecord:
    """一次任务执行的完整记录"""
    task_id: str
    task_description: str
    tools_used: list[str]
    tool_sequence: list[str]    # 工具调用的顺序
    iterations: int
    success: bool
    final_output: str
    error: str = ""
    context: dict = field(default_factory=dict)
    timestamp: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()


class ExperienceRecorder:
    """经验记录器 — 记录每次执行的详细信息"""
    
    def __init__(self, storage_path: str = "experience_pool.json"):
        self.storage_path = storage_path
        self.records: list[ExecutionRecord] = []
        self._load()
    
    def _load(self):
        if os.path.exists(self.storage_path):
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.records = [ExecutionRecord(**r) for r in data]
    
    def _save(self):
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump([asdict(r) for r in self.records], f, ensure_ascii=False, indent=2)
    
    def record(self, record: ExecutionRecord):
        """记录一次执行"""
        self.records.append(record)
        self._save()
    
    def get_recent(self, n: int = 20) -> list[ExecutionRecord]:
        return self.records[-n:]
    
    def get_successes(self) -> list[ExecutionRecord]:
        return [r for r in self.records if r.success]
    
    def get_failures(self) -> list[ExecutionRecord]:
        return [r for r in self.records if not r.success]
    
    def get_by_tool(self, tool_name: str) -> list[ExecutionRecord]:
        return [r for r in self.records if tool_name in r.tools_used]
    
    def stats(self) -> dict:
        total = len(self.records)
        if total == 0:
            return {"total": 0}
        
        successes = [r for r in self.records if r.success]
        tool_counter = Counter()
        for r in self.records:
            for t in r.tools_used:
                tool_counter[t] += 1
        
        return {
            "total": total,
            "successes": len(successes),
            "success_rate": len(successes) / total * 100,
            "most_used_tools": tool_counter.most_common(5),
            "avg_iterations": sum(r.iterations for r in self.records) / total,
        }


# ============================================================
# 第二层：经验提取器
# ============================================================

@dataclass
class ExperiencePattern:
    """从经验中提取的模式"""
    pattern_type: str  # "success_pattern" | "failure_pattern" | "tool_preference"
    description: str
    trigger_condition: str  # 什么情况下适用
    action: str             # 应该做什么（或不做什么）
    confidence: float       # 置信度 0-1
    evidence_count: int     # 支持这个模式的案例数
    source_records: list[str] = field(default_factory=list)  # 来源记录ID


class ExperienceExtractor:
    """经验提取器 — 从执行记录中提取可复用的模式"""
    
    def __init__(self, recorder: ExperienceRecorder):
        self.recorder = recorder
    
    def extract_patterns(self) -> list[ExperiencePattern]:
        """从所有记录中提取模式"""
        patterns = []
        patterns.extend(self._extract_success_patterns())
        patterns.extend(self._extract_failure_patterns())
        patterns.extend(self._extract_tool_preferences())
        return sorted(patterns, key=lambda p: p.confidence, reverse=True)
    
    def _extract_success_patterns(self) -> list[ExperiencePattern]:
        """从成功案例中提取模式"""
        successes = self.recorder.get_successes()
        if len(successes) < 3:
            return []
        
        # 分析成功案例中的工具组合
        tool_combo_counter = Counter()
        for record in successes:
            combo = tuple(sorted(set(record.tool_sequence)))
            if len(combo) >= 2:
                tool_combo_counter[combo] += 1
        
        patterns = []
        for combo, count in tool_combo_counter.most_common(3):
            if count >= 2:
                patterns.append(ExperiencePattern(
                    pattern_type="success_pattern",
                    description=f"工具组合 {' → '.join(combo)} 在成功案例中出现{count}次",
                    trigger_condition=f"任务需要多步处理时",
                    action=f"按 {' → '.join(combo)} 的顺序使用工具",
                    confidence=min(count / len(successes) * 2, 0.95),
                    evidence_count=count,
                ))
        
        return patterns
    
    def _extract_failure_patterns(self) -> list[ExperiencePattern]:
        """从失败案例中提取模式"""
        failures = self.recorder.get_failures()
        if len(failures) < 2:
            return []
        
        patterns = []
        
        # 找出失败案例中重复出现的工具
        tool_counter = Counter()
        for record in failures:
            for tool in record.tools_used:
                tool_counter[tool] += 1
        
        for tool, count in tool_counter.most_common(3):
            if count >= 2:
                # 检查这个工具在成功案例中的表现
                successes_with_tool = [
                    r for r in self.recorder.get_successes() if tool in r.tools_used
                ]
                if len(successes_with_tool) < count:
                    patterns.append(ExperiencePattern(
                        pattern_type="failure_pattern",
                        description=f"工具 '{tool}' 在失败案例中出现{count}次，可能是问题源头",
                        trigger_condition=f"需要使用 '{tool}' 时",
                        action=f"优先考虑替代工具，或确保输入参数正确",
                        confidence=min(count / len(failures), 0.9),
                        evidence_count=count,
                    ))
        
        return patterns
    
    def _extract_tool_preferences(self) -> list[ExperiencePattern]:
        """提取工具使用偏好"""
        records = self.recorder.records
        if len(records) < 5:
            return []
        
        patterns = []
        
        # 统计每种任务类型下最有效的工具
        task_tool_success = {}  # {task_keyword: {tool: success_count}}
        
        for record in records:
            keywords = re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z]+', record.task_description.lower())
            keywords = [k for k in keywords if len(k) >= 2]
            
            for kw in keywords[:3]:  # 取前3个关键词
                if kw not in task_tool_success:
                    task_tool_success[kw] = Counter()
                
                for tool in record.tools_used:
                    if record.success:
                        task_tool_success[kw][tool] += 1
        
        # 找出高频成功的工具-任务配对
        for keyword, tool_counts in task_tool_success.items():
            if len(tool_counts) >= 2:
                best_tool, best_count = tool_counts.most_common(1)[0]
                total = sum(tool_counts.values())
                if best_count / total >= 0.6:  # 60%以上成功率
                    patterns.append(ExperiencePattern(
                        pattern_type="tool_preference",
                        description=f"处理'{keyword}'类任务时，'{best_tool}'最有效({best_count}/{total})",
                        trigger_condition=f"任务描述中包含'{keyword}'",
                        action=f"优先使用 '{best_tool}'",
                        confidence=best_count / total,
                        evidence_count=best_count,
                    ))
        
        return patterns


# ============================================================
# 第三层：进化引擎
# ============================================================

class EvolutionEngine:
    """进化引擎 — 将经验模式转化为Agent的改进"""
    
    def __init__(self, recorder: ExperienceRecorder):
        self.recorder = recorder
        self.extractor = ExperienceExtractor(recorder)
        self.current_system_prompt = ""
        self.evolution_log: list[dict] = []
    
    def evolve(self) -> dict:
        """
        执行一次进化：
        1. 提取模式
        2. 生成改进建议
        3. 返回更新后的系统提示词片段
        """
        patterns = self.extractor.extract_patterns()
        
        if not patterns:
            return {
                "evolved": False,
                "reason": "经验不足，至少需要5条执行记录（含3条成功）",
            }
        
        # 生成系统提示词改进片段
        prompt_additions = self._generate_prompt_additions(patterns)
        
        evolution = {
            "evolved": True,
            "patterns_found": len(patterns),
            "top_patterns": [
                {"type": p.pattern_type, "description": p.description, "confidence": p.confidence}
                for p in patterns[:5]
            ],
            "prompt_additions": prompt_additions,
            "stats": self.recorder.stats(),
            "timestamp": datetime.now().isoformat(),
        }
        
        self.evolution_log.append(evolution)
        return evolution
    
    def _generate_prompt_additions(self, patterns: list[ExperiencePattern]) -> str:
        """将模式转化为系统提示词片段"""
        sections = []
        
        # 成功模式 → 加到提示词的"推荐做法"部分
        success_patterns = [p for p in patterns if p.pattern_type == "success_pattern"]
        if success_patterns:
            lines = ["## 基于经验的推荐做法"]
            for p in success_patterns:
                lines.append(f"- {p.description}")
            sections.append("\n".join(lines))
        
        # 失败模式 → 加到提示词的"注意事项"部分
        failure_patterns = [p for p in patterns if p.pattern_type == "failure_pattern"]
        if failure_patterns:
            lines = ["## 基于经验的注意事项"]
            for p in failure_patterns:
                lines.append(f"- {p.action}")
            sections.append("\n".join(lines))
        
        # 工具偏好 → 加到提示词的"工具选择指南"部分
        tool_prefs = [p for p in patterns if p.pattern_type == "tool_preference"]
        if tool_prefs:
            lines = ["## 工具选择指南（基于历史数据）"]
            for p in tool_prefs:
                lines.append(f"- {p.description}")
            sections.append("\n".join(lines))
        
        return "\n\n".join(sections)
    
    def get_evolution_history(self) -> list[dict]:
        """获取进化历史"""
        return self.evolution_log


# ============================================================
# 自进化Agent（整合三层）
# ============================================================

class SelfEvolvingAgent:
    """自进化Agent — 整合执行、记录、进化"""
    
    def __init__(self, base_system_prompt: str, experience_path: str = "experience_pool.json"):
        self.base_system_prompt = base_system_prompt
        self.recorder = ExperienceRecorder(experience_path)
        self.evolution_engine = EvolutionEngine(self.recorder)
        self.learned_additions = ""
        self._auto_evolve_interval = 10  # 每执行10次任务自动进化一次
        self._execution_count = 0
    
    def run(self, task: str) -> str:
        """执行任务（带经验记录）"""
        task_id = f"task_{len(self.recorder.records) + 1}"
        
        # 构建增强版的系统提示词
        enhanced_prompt = self.base_system_prompt
        if self.learned_additions:
            enhanced_prompt += "\n\n" + self.learned_additions
        
        # 执行任务（模拟）
        tools_used = ["search", "calculate"]  # 模拟工具使用
        success = True  # 模拟成功
        output = f"[模拟] 完成任务: {task}"
        
        # 记录执行
        record = ExecutionRecord(
            task_id=task_id,
            task_description=task,
            tools_used=tools_used,
            tool_sequence=tools_used,
            iterations=3,
            success=success,
            final_output=output,
        )
        self.recorder.record(record)
        self._execution_count += 1
        
        # 自动进化检查
        if self._execution_count % self._auto_evolve_interval == 0:
            print(f"\n🧬 [Auto-Evolve] 已执行{self._execution_count}次任务，触发自动进化...")
            self.evolve()
        
        return output
    
    def evolve(self) -> dict:
        """手动触发进化"""
        result = self.evolution_engine.evolve()
        if result["evolved"]:
            self.learned_additions = result["prompt_additions"]
            print(f"🧬 进化完成！发现{result['patterns_found']}个模式")
            for p in result["top_patterns"]:
                print(f"  - [{p['type']}] {p['description']} (置信度: {p['confidence']:.2f})")
        return result
    
    def get_stats(self) -> dict:
        return self.recorder.stats()


# ===== 使用示例 =====

if __name__ == "__main__":
    print("=== 自进化Agent ===\n")
    
    agent = SelfEvolvingAgent(
        base_system_prompt="你是一个研究助手Agent。",
        experience_path="test_experience.json",
    )
    
    # 模拟执行一批任务
    test_tasks = [
        "搜索Python教程",
        "计算 123 * 456",
        "写一份AI报告",
        "分析数据趋势",
        "搜索机器学习资料",
        "计算利润率",
        "整理会议笔记",
        "搜索最新的AI论文",
        "生成销售报告",
        "计算同比增长",
        "搜索Agent框架对比",
    ]
    
    for task in test_tasks:
        agent.run(task)
    
    # 触发进化
    print("\n=== 触发进化 ===")
    result = agent.evolve()
    
    if result["evolved"]:
        print(f"\n=== 进化后的提示词补充 ===")
        print(result["prompt_additions"])
    
    print(f"\n=== Agent统计 ===")
    stats = agent.get_stats()
    print(json.dumps(stats, indent=2, ensure_ascii=False))
    
    # 清理
    if os.path.exists("test_experience.json"):
        os.remove("test_experience.json")
```

---

## 关键设计决策

### 1. 为什么不直接让LLM自己修改自己的prompt？

危险！LLM修改自己的prompt可能导致"漂移"——越改越偏，最终不可控。

安全的做法：
- **保留基线prompt**：永远不动原始版本
- **经验是"建议"而非"指令"**：learned_additions 是附加的，可以随时移除
- **A/B测试**：进化后的版本和基线对比，确保没有退化

### 2. 经验池的"遗忘机制"

记忆越多 ≠ 越好。需要定期清理：
- 太老的经验（>30天）降权
- 置信度太低的模式删除
- 互相矛盾的模式需要人工审核

### 3. 三层架构的本质

```
执行层 → "做了什么" → 记录
记忆层 → "学到了什么" → 模式
进化层 → "怎么改进" → 规则
```

这和人类学习是一样的：
- 做题 → 总结错题本 → 优化学习方法

---

## 🎓 课程总结

恭喜你完成了全部10关！

从80行极简Agent到自进化系统，你已经理解了Agent的**全部核心组件**：

| 组件 | 关卡 | 核心能力 |
|------|------|---------|
| ReAct循环 | 第1关 | Agent的基本运转方式 |
| 工具系统 | 第2关 | 让Agent能做事 |
| 记忆系统 | 第3关 | 让Agent能记住 |
| 规划系统 | 第4关 | 让Agent能规划 |
| 多工具整合 | 第5关 | 完整的实用Agent |
| 鲁棒性 | 第6关 | 生产级可靠性 |
| 状态机 | 第7关 | 可控的工作流 |
| 多Agent | 第8关 | 团队协作 |
| 评估 | 第9关 | 数据驱动优化 |
| 自进化 | 第10关 | 从经验中学习 |

**下一步**：用 `agent-creator` 把学到的原理用框架快速实现，提效！

---

## 练习题

1. **完整自进化循环**：实现"执行→评估→进化→重新执行"的闭环，验证进化后成功率确实提升
2. **对抗退化**：设计机制检测"进化后反而变差"的情况，自动回滚
3. **跨Agent知识迁移**：一个Agent的经验能被另一个同类Agent复用
