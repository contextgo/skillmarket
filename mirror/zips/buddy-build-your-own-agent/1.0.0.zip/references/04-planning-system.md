# 第4关：规划系统 - 完整参考实现

## 核心原理

没有规划的 Agent 像一个"想到什么做什么"的人——可能最后做了很多，但偏离目标。

规划系统让 Agent 先"想清楚再动手"：

```
Plan-then-Execute 模式：
  用户任务 → [分解为子任务] → 按顺序执行 → 汇总结果

Adaptive Planning 模式：
  用户任务 → [规划] → 执行一步 → [检查：需要调整吗？]
    → 是 → 重新规划 → 继续
    → 否 → 执行下一步
```

---

## 完整实现

```python
"""
规划系统 — 让Agent先想清楚再动手
核心组件：
  1. TaskDecomposer: 大任务 → 子任务列表
  2. DependencyAnalyzer: 子任务间的前后关系
  3. PlanExecutor: 按依赖顺序执行
  4. AdaptivePlanner: 执行中动态调整
"""
import json
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SubTask:
    """子任务数据结构"""
    id: int
    name: str
    description: str
    depends_on: list[int] = field(default_factory=list)
    status: str = "pending"  # pending | running | done | failed | skipped
    result: str = ""
    error: str = ""


class PlanParser:
    """解析LLM输出的规划JSON"""
    
    @staticmethod
    def parse(response_text: str) -> list[SubTask]:
        """从LLM响应中提取子任务列表"""
        # 尝试提取JSON块
        json_match = re.search(r'\{[\s\S]*"subtasks"[\s\S]*\}', response_text)
        if not json_match:
            raise ValueError("无法从LLM响应中提取规划JSON")
        
        data = json.loads(json_match.group())
        tasks = []
        
        for item in data["subtasks"]:
            tasks.append(SubTask(
                id=item["id"],
                name=item.get("name", f"Task {item['id']}"),
                description=item["description"],
                depends_on=item.get("depends_on", []),
            ))
        
        return tasks


class DependencyAnalyzer:
    """分析子任务间的依赖关系"""
    
    @staticmethod
    def topological_sort(tasks: list[SubTask]) -> list[SubTask]:
        """
        拓扑排序：按依赖关系排列执行顺序
        
        原理：如果任务B依赖任务A，那么A必须在B之前执行。
        类似大学排课：先修课必须在后修课之前。
        """
        # 构建邻接表
        task_map = {t.id: t for t in tasks}
        in_degree = {t.id: len(t.depends_on) for t in tasks}
        graph = {t.id: [] for t in tasks}
        
        for task in tasks:
            for dep_id in task.depends_on:
                if dep_id in graph:
                    graph[dep_id].append(task.id)
        
        # Kahn算法
        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        sorted_tasks = []
        
        while queue:
            current = queue.pop(0)
            sorted_tasks.append(task_map[current])
            
            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        
        if len(sorted_tasks) != len(tasks):
            raise ValueError("检测到循环依赖！请检查子任务的depends_on设置")
        
        return sorted_tasks
    
    @staticmethod
    def find_parallel_groups(tasks: list[SubTask]) -> list[list[SubTask]]:
        """找出可以并行执行的子任务组"""
        sorted_tasks = DependencyAnalyzer.topological_sort(tasks)
        task_map = {t.id: t for t in tasks}
        
        groups = []
        completed = set()
        
        while len(completed) < len(tasks):
            # 找出所有依赖都已完成的任务
            ready = [
                task_map[tid] for tid in [t.id for t in tasks]
                if tid not in completed
                and all(dep in completed for dep in task_map[tid].depends_on)
            ]
            if not ready:
                break
            groups.append(ready)
            completed.update(t.id for t in ready)
        
        return groups


class PlanExecutor:
    """按计划执行子任务"""
    
    def __init__(self, agent_execute_fn):
        """
        agent_execute_fn: 执行单个子任务的函数
            def execute(description: str, context: str) -> str
        """
        self.agent_execute = agent_execute_fn
    
    def execute_plan(self, tasks: list[SubTask]) -> dict:
        """按拓扑排序执行所有子任务"""
        task_map = {t.id: t for t in tasks}
        sorted_tasks = DependencyAnalyzer.topological_sort(tasks)
        results = {}
        
        for task in sorted_tasks:
            task.status = "running"
            
            # 收集依赖任务的结果作为上下文
            context = ""
            if task.depends_on:
                dep_results = [
                    f"[Task {dep_id}] {task_map[dep_id].name}: {task_map[dep_id].result}"
                    for dep_id in task.depends_on
                    if task_map[dep_id].status == "done"
                ]
                context = "\n".join(dep_results)
            
            try:
                task.result = self.agent_execute(task.description, context)
                task.status = "done"
                results[task.id] = task.result
            except Exception as e:
                task.status = "failed"
                task.error = str(e)
                results[task.id] = f"FAILED: {e}"
                # 不中断——标记失败，继续执行无依赖的任务
        
        return results


class AdaptivePlanner:
    """自适应规划器 — 执行中动态调整计划"""
    
    def __init__(self, agent_execute_fn, replan_fn):
        """
        replan_fn: 重新规划的函数
            def replan(original_plan, completed, failed, current_task_result) -> list[SubTask]
        """
        self.executor = PlanExecutor(agent_execute_fn)
        self.replan = replan_fn
        self.max_replans = 3
    
    def execute_adaptive(self, tasks: list[SubTask]) -> dict:
        """带重规划能力的执行"""
        replan_count = 0
        
        while replan_count <= self.max_replans:
            # 先执行当前计划
            results = {}
            task_map = {t.id: t for t in tasks}
            sorted_tasks = DependencyAnalyzer.topological_sort(tasks)
            
            failed_tasks = []
            
            for task in sorted_tasks:
                task.status = "running"
                context = ""
                if task.depends_on:
                    dep_results = [
                        f"[Task {dep_id}]: {task_map[dep_id].result}"
                        for dep_id in task.depends_on
                    ]
                    context = "\n".join(dep_results)
                
                try:
                    task.result = self.agent_execute(task.description, context)
                    task.status = "done"
                    results[task.id] = task.result
                except Exception as e:
                    task.status = "failed"
                    task.error = str(e)
                    failed_tasks.append(task)
            
            # 如果有失败的任务，尝试重规划
            if failed_tasks and replan_count < self.max_replans:
                print(f"[Replan #{replan_count + 1}] {len(failed_tasks)} tasks failed, replanning...")
                completed = [t for t in tasks if t.status == "done"]
                tasks = self.replan(tasks, completed, failed_tasks)
                replan_count += 1
            else:
                break
        
        return results


# ===== 模拟使用 =====

if __name__ == "__main__":
    # 模拟 LLM 的任务分解输出
    mock_plan_response = '''
    {
        "subtasks": [
            {"id": 1, "name": "搜索信息", "description": "搜索AI Agent的最新发展趋势", "depends_on": []},
            {"id": 2, "name": "整理资料", "description": "整理搜索结果，提取关键信息", "depends_on": [1]},
            {"id": 3, "name": "搜索竞品", "description": "搜索主流Agent框架对比", "depends_on": []},
            {"id": 4, "name": "写报告", "description": "基于整理的信息撰写研究报告", "depends_on": [2, 3]},
            {"id": 5, "name": "审核", "description": "审核报告质量和准确性", "depends_on": [4]}
        ]
    }
    '''
    
    # 解析规划
    tasks = PlanParser.parse(mock_plan_response)
    print("=== 解析的子任务 ===")
    for t in tasks:
        deps = f" (依赖: {t.depends_on})" if t.depends_on else ""
        print(f"  {t.id}. {t.name}: {t.description}{deps}")
    
    # 分析依赖
    print("\n=== 执行顺序（拓扑排序） ===")
    sorted_tasks = DependencyAnalyzer.topological_sort(tasks)
    for t in sorted_tasks:
        print(f"  → {t.id}. {t.name}")
    
    # 找并行组
    print("\n=== 可并行执行的组 ===")
    groups = DependencyAnalyzer.find_parallel_groups(tasks)
    for i, group in enumerate(groups):
        print(f"  组{i+1}: {[t.name for t in group]}")
    
    # 模拟执行
    def mock_execute(description: str, context: str) -> str:
        return f"[模拟结果] 完成了: {description[:30]}..."
    
    executor = PlanExecutor(mock_execute)
    print("\n=== 执行结果 ===")
    results = executor.execute_plan(tasks)
    for task_id, result in results.items():
        print(f"  Task {task_id}: {result}")
```

---

## 关键设计决策

### 1. 为什么用拓扑排序？

子任务之间可能形成复杂的依赖图。拓扑排序保证：
- 被依赖的任务一定先执行
- 没有依赖的任务可以并行执行
- 能检测循环依赖（提示错误）

这和大学的"先修课"系统是同一个算法。

### 2. 失败不中断

注意 `execute_plan` 里：一个子任务失败时，**不会中断整个计划**。
只会标记为 failed，然后继续执行不依赖它的其他任务。

这是生产环境的标准做法——不要因为一个步骤失败就浪费其他可以成功的工作。

### 3. 自适应规划 vs 固定规划

| 模式 | 适用场景 | 代价 |
|------|---------|------|
| 固定规划 | 流程明确、步骤可预测 | 无法应对意外 |
| 自适应规划 | 探索性任务、结果不确定 | 额外 LLM 调用成本 |

---

## 练习题

1. **上下文传递**：修改 execute_plan，让每个子任务都能看到所有已完成任务的摘要（不只是直接依赖的）
2. **优先级调度**：给子任务加 priority 字段，高优先级任务优先执行
3. **人机协同**：在关键节点（如"审核"任务）暂停，等待人工确认后再继续
