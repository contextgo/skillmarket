# 第5关：多工具Agent - 完整参考实现

## 核心原理

前几关我们分别实现了：循环（第1关）、工具注册（第2关）、记忆（第3关）、规划（第4关）。
这关把它们整合成一个**完整的、能实际使用的Agent**。

目标：构建一个"研究助手"——给它一个主题，它能：
1. 搜索网页信息
2. 读取和生成文件
3. 进行数据计算
4. 自动选择最合适的工具组合完成任务

---

## 完整实现

```python
"""
研究助手Agent — 多工具整合实战
组合：ReAct循环 + ToolRegistry + MemoryManager + 简单规划
"""
import os
import json
import re
import math
from datetime import datetime
# 复用前几关的组件（这里内联简化版）
from typing import Callable

# ============================================================
# 第一部分：工具系统（来自第2关，简化版）
# ============================================================

class ToolRegistry:
    def __init__(self):
        self._tools = {}
    
    def register(self, name=None, description=None):
        def decorator(func):
            tool_name = name or func.__name__
            tool_desc = description or func.__doc__ or f"Call {tool_name}"
            
            import inspect
            sig = inspect.signature(func)
            props = {}
            required = []
            for pname, param in sig.parameters.items():
                if pname == "self": continue
                ptype = str(param.annotation) if param.annotation != inspect.Parameter.empty else "string"
                props[pname] = {"type": "string", "description": f"{pname} parameter"}
                if param.default is inspect.Parameter.empty:
                    required.append(pname)
            
            self._tools[tool_name] = {
                "function": func,
                "schema": {
                    "name": tool_name,
                    "description": tool_desc,
                    "input_schema": {"type": "object", "properties": props, "required": required}
                }
            }
            return func
        return decorator
    
    def get_schemas(self):
        return [t["schema"] for t in self._tools.values()]
    
    def execute(self, name, inputs):
        if name not in self._tools:
            return f"Error: Unknown tool '{name}'. Available: {list(self._tools.keys())}"
        try:
            return str(self._tools[name]["function"](**inputs))
        except Exception as e:
            return f"Error executing {name}: {e}"


# ============================================================
# 第二部分：注册研究助手需要的工具
# ============================================================

registry = ToolRegistry()

@registry.register(description="计算数学表达式。支持加减乘除、幂运算等。输入格式：expression=数学表达式字符串（幂运算用**）")
def calculate(expression: str) -> str:
    allowed = set("0123456789+-*/().% ")
    if not all(c in allowed for c in expression):
        return "Error: Invalid characters"
    try:
        return str(eval(expression, {"__builtins__": {}}, {"math": math}))
    except Exception as e:
        return f"Error: {e}"

@registry.register(description="搜索网页获取信息。输入：query=搜索关键词, num_results=结果数量(默认3)")
def web_search(query: str, num_results: str = "3") -> str:
    n = int(num_results) if num_results.isdigit() else 3
    # 模拟搜索结果（实际项目中替换为API）
    return json.dumps([
        {"title": f"{query} - 搜索结果{i+1}", "snippet": f"关于{query}的相关信息..."}
        for i in range(n)
    ], ensure_ascii=False, indent=2)

@registry.register(description="读取本地文件内容。输入：file_path=文件路径")
def read_file_tool(file_path: str) -> str:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
            return content[:5000] if len(content) > 5000 else content  # 截断过长内容
    except FileNotFoundError:
        return f"Error: File not found: {file_path}"
    except Exception as e:
        return f"Error: {e}"

@registry.register(description="将内容写入本地文件。输入：file_path=文件路径, content=要写入的内容")
def write_file_tool(file_path: str, content: str) -> str:
    try:
        os.makedirs(os.path.dirname(file_path) if os.path.dirname(file_path) else ".", exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Successfully wrote to {file_path}"
    except Exception as e:
        return f"Error: {e}"

@registry.register(description="获取当前日期和时间信息。无需输入参数。")
def get_datetime() -> str:
    now = datetime.now()
    return json.dumps({
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "weekday": ["周一","周二","周三","周四","周五","周六","周日"][now.weekday()],
        "iso": now.isoformat(),
    }, ensure_ascii=False)

@registry.register(description="提取文本中的关键信息。输入：text=要提取的文本, info_type=提取类型(如'summary','key_points','numbers','names')")
def extract_info(text: str, info_type: str = "summary") -> str:
    """简单的文本信息提取"""
    if info_type == "summary":
        return f"[摘要] {text[:200]}..."
    elif info_type == "key_points":
        sentences = re.split(r'[。！？\.\!\?]', text)
        points = [s.strip() for s in sentences if len(s.strip()) > 10][:5]
        return "\n".join(f"- {p}" for p in points)
    elif info_type == "numbers":
        numbers = re.findall(r'\d+\.?\d*', text)
        return f"发现的数字: {numbers}"
    else:
        return f"Unknown info_type: {info_type}"


# ============================================================
# 第三部分：ReAct Agent 循环（来自第1关，增强版）
# ============================================================

class ReActAgent:
    """ReAct循环Agent — 带记忆和工具选择"""
    
    def __init__(self, registry: ToolRegistry, system_prompt: str = ""):
        self.registry = registry
        self.system_prompt = system_prompt
        self.conversation_history = []
        self.tool_call_log = []
    
    def run(self, user_message: str, max_iterations: int = 15, verbose: bool = True) -> str:
        """
        运行Agent主循环
        
        增强点（相比第1关）：
        1. System prompt 引导工具选择
        2. 工具调用日志（用于后续分析优化）
        3. 更好的错误处理
        """
        # 构建system prompt
        system = self.system_prompt or self._default_system_prompt()
        
        messages = [{"role": "user", "content": user_message}]
        
        for iteration in range(max_iterations):
            if verbose:
                print(f"\n--- Iteration {iteration + 1} ---")
            
            try:
                # 调用LLM（这里用模拟，实际替换为API调用）
                response = self._call_llm(system, messages)
                
                if response["stop_reason"] == "tool_use":
                    tool_calls = response["tool_calls"]
                    
                    for tc in tool_calls:
                        tool_name = tc["name"]
                        tool_input = tc["input"]
                        
                        if verbose:
                            print(f"  Tool call: {tool_name}({json.dumps(tool_input, ensure_ascii=False)})")
                        
                        # 记录工具调用
                        self.tool_call_log.append({
                            "iteration": iteration,
                            "tool": tool_name,
                            "input": tool_input,
                            "timestamp": datetime.now().isoformat(),
                        })
                        
                        # 执行工具
                        result = self.registry.execute(tool_name, tool_input)
                        
                        if verbose:
                            result_preview = result[:200] if len(result) > 200 else result
                            print(f"  Result: {result_preview}")
                        
                        # 将工具结果加入消息
                        messages.append({"role": "assistant", "content": json.dumps([tc])})
                        messages.append({"role": "user", "content": json.dumps([
                            {"type": "tool_result", "tool_use_id": tc["id"], "content": result}
                        ])})
                
                elif response["stop_reason"] == "end_turn":
                    final_text = response["text"]
                    if verbose:
                        print(f"  Final answer: {final_text[:300]}...")
                    return final_text
                
            except Exception as e:
                if verbose:
                    print(f"  Error in iteration {iteration + 1}: {e}")
                # 把错误信息反馈给LLM，让它自己决定怎么办
                messages.append({"role": "user", "content": f"上一个操作出错了：{e}。请换个方式尝试。"})
        
        return "Agent达到最大迭代次数，未能完成任务。"
    
    def _default_system_prompt(self) -> str:
        tool_list = "\n".join(
            f"- {schema['name']}: {schema['description']}"
            for schema in self.registry.get_schemas()
        )
        return f"""你是一个研究助手Agent。你可以使用以下工具：

{tool_list}

工作方式：
1. 分析用户的需求
2. 选择最合适的工具（或组合使用多个工具）
3. 根据工具结果继续思考或给出最终答案
4. 如果一个工具失败，尝试其他方法

注意：
- 只在需要时调用工具，不要滥用
- 优先使用最直接的方法
- 给出清晰、结构化的最终答案"""

    def _call_llm(self, system: str, messages: list) -> dict:
        """
        调用LLM（模拟实现）
        实际项目中替换为:
          import anthropic
          client = anthropic.Anthropic()
          response = client.messages.create(...)
        """
        # 这里返回一个模拟的"需要调用工具"的响应
        # 实际项目中，这是真正的API调用
        return {
            "stop_reason": "end_turn",
            "text": f"[模拟] 收到{len(messages)}条消息，需要实际接入Claude API。",
            "tool_calls": []
        }
    
    def get_tool_stats(self) -> dict:
        """获取工具使用统计"""
        from collections import Counter
        tool_counts = Counter(t["tool"] for t in self.tool_call_log)
        return {
            "total_calls": len(self.tool_call_log),
            "by_tool": dict(tool_counts),
        }


# ============================================================
# 第四部分：使用示例
# ============================================================

if __name__ == "__main__":
    print("=== 研究助手Agent ===\n")
    print("已注册工具:")
    for schema in registry.get_schemas():
        print(f"  - {schema['name']}: {schema['description'][:50]}...")
    
    agent = ReActAgent(registry)
    
    # 测试场景1：需要多个工具协作
    print("\n" + "="*50)
    print("测试：研究助手应该能自动选择合适的工具")
    print("="*50)
    
    # 注意：这里需要实际接入Claude API才能看到完整效果
    # result = agent.run("帮我研究一下2026年AI Agent的发展趋势，写一份简要报告保存到report.md")
```

---

## 关键设计决策

### 1. System Prompt 是工具选择的"大脑"

LLM 不会随机调用工具——它根据 system prompt 里的工具描述来决定。
所以工具描述的质量**直接决定工具选择准确率**。

好的描述 = 功能 + 何时用 + 输入输出格式

### 2. 工具选择准确率 > 80% 的秘诀

| 做法 | 效果 |
|------|------|
| 工具描述包含具体示例 | ⬆️ 提升准确率 |
| 工具职责不重叠 | ⬆️ 减少混淆 |
| 工具数量控制在5-8个 | ⬆️ 避免选择困难 |
| System prompt 说明优先级 | ⬆️ 指导选择 |

### 3. 为什么不直接用 LangChain Tools？

LangChain 已经封装好了这些工具。但手搓一遍你会理解：
- 工具描述如何影响 LLM 的选择
- 工具执行的安全边界在哪里
- 多工具组合时可能出什么问题

理解了底层，用框架时才能"知其所以然"。

---

## 练习题

1. **接入真实API**：把 `_call_llm` 替换为实际的 Claude API 调用
2. **添加网页抓取工具**：用 requests + BeautifulSoup 实现真实的网页内容提取
3. **工具使用统计面板**：记录每次工具调用的成功率、延迟，找出最常被误用的工具
