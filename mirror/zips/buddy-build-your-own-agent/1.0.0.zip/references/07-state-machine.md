# 第7关：状态机Agent - 完整参考实现

## 核心原理

ReAct循环是"自由飞翔"——Agent想到什么做什么，没有约束。
状态机是"轨道交通"——Agent只能在预设的轨道上行驶，行为可预测。

适用场景：
- 客服流程（接单→查询→解决→评价）
- 审批流程（提交→审核→批准/拒绝）
- 数据处理 pipeline（采集→清洗→转换→存储）

---

## 完整实现

```python
"""
状态机Agent — 用有限状态机管理Agent工作流
核心概念：
  State（状态）：Agent当前处于什么阶段
  Transition（转换）：什么条件下从A状态到B状态
  Action（动作）：进入每个状态时做什么
"""
import json
import enum
from dataclasses import dataclass, field
from typing import Callable, Optional
from datetime import datetime


class StateType(enum.Enum):
    """状态类型"""
    INITIAL = "initial"      # 初始状态
    PROCESSING = "processing" # 处理中
    WAITING = "waiting"       # 等待输入
    SUCCESS = "success"       # 成功终态
    FAILED = "failed"         # 失败终态


@dataclass
class State:
    """状态定义"""
    name: str
    type: StateType = StateType.PROCESSING
    on_enter: Optional[Callable] = None   # 进入状态时执行
    on_exit: Optional[Callable] = None    # 离开状态时执行


@dataclass
class Transition:
    """状态转换规则"""
    from_state: str
    to_state: str
    condition: Callable    # 判断是否触发转换
    action: Optional[Callable] = None  # 转换时执行的动作
    priority: int = 0      # 优先级（高优先级先匹配）


class StateMachineAgent:
    """状态机Agent"""
    
    def __init__(self, name: str = "StateMachineAgent"):
        self.name = name
        self.states: dict[str, State] = {}
        self.transitions: list[Transition] = []
        self.current_state: Optional[State] = None
        self.history: list[dict] = []
        self.context: dict = {}  # 跨状态共享的数据
        self._initial_state: str = ""
    
    def add_state(self, name: str, state_type=StateType.PROCESSING,
                  on_enter=None, on_exit=None):
        """添加状态"""
        self.states[name] = State(
            name=name, type=state_type,
            on_enter=on_enter, on_exit=on_exit
        )
        if state_type == StateType.INITIAL:
            self._initial_state = name
        return self  # 链式调用
    
    def add_transition(self, from_state: str, to_state: str,
                       condition: Callable, action=None, priority=0):
        """添加转换规则"""
        self.transitions.append(Transition(
            from_state=from_state, to_state=to_state,
            condition=condition, action=action, priority=priority
        ))
        # 按优先级排序
        self.transitions.sort(key=lambda t: t.priority, reverse=True)
        return self
    
    def start(self, initial_context: dict = None):
        """启动状态机"""
        if not self._initial_state:
            raise ValueError("No initial state defined")
        
        self.context = initial_context or {}
        self.history.clear()
        self._enter_state(self._initial_state)
    
    def process(self, input_data: dict = None) -> str:
        """
        处理一次输入，执行状态转换
        
        这是状态机的核心循环：
        1. 检查所有从当前状态出发的转换条件
        2. 匹配到就执行转换
        3. 到达终态时停止
        """
        if self.current_state is None:
            raise RuntimeError("Agent not started. Call start() first.")
        
        self.context.update(input_data or {})
        
        while True:
            current_name = self.current_state.name
            
            # 终态检查
            if self.current_state.type in (StateType.SUCCESS, StateType.FAILED):
                return self._generate_response()
            
            # 查找匹配的转换
            matched = None
            for trans in self.transitions:
                if trans.from_state == current_name:
                    if trans.condition(self.context):
                        matched = trans
                        break
            
            if matched is None:
                # 没有匹配的转换 → 等待输入
                self.current_state.type = StateType.WAITING
                return self._generate_response()
            
            # 执行转换
            self._do_transition(matched)
    
    def _enter_state(self, state_name: str):
        """进入新状态"""
        self.current_state = self.states[state_name]
        self.history.append({
            "state": state_name,
            "timestamp": datetime.now().isoformat(),
            "type": "enter",
        })
        
        if self.current_state.on_enter:
            self.current_state.on_enter(self.context)
    
    def _exit_state(self):
        """离开当前状态"""
        if self.current_state and self.current_state.on_exit:
            self.current_state.on_exit(self.context)
        self.history[-1]["exit_time"] = datetime.now().isoformat()
    
    def _do_transition(self, transition: Transition):
        """执行状态转换"""
        self._exit_state()
        
        if transition.action:
            transition.action(self.context)
        
        self.history.append({
            "from": transition.from_state,
            "to": transition.to_state,
            "timestamp": datetime.now().isoformat(),
            "type": "transition",
        })
        
        self._enter_state(transition.to_state)
    
    def _generate_response(self) -> str:
        """生成当前状态的响应"""
        state = self.current_state
        if state.type == StateType.WAITING:
            return f"[{state.name}] 等待输入..."
        elif state.type == StateType.SUCCESS:
            return f"[完成] {self.context.get('result', '任务已完成')}"
        elif state.type == StateType.FAILED:
            return f"[失败] {self.context.get('error', '任务执行失败')}"
        return f"[{state.name}] 处理中..."
    
    def get_state_diagram(self) -> str:
        """生成Mermaid状态图"""
        lines = ["```mermaid", "stateDiagram-v2"]
        
        # 状态定义
        for name, state in self.states.items():
            if state.type == StateType.INITIAL:
                lines.append(f"    [*] --> {name}")
            elif state.type == StateType.SUCCESS:
                lines.append(f"    {name} --> [*] : 完成")
            elif state.type == StateType.FAILED:
                lines.append(f"    {name} --> [*] : 失败")
        
        # 转换
        for trans in self.transitions:
            lines.append(f"    {trans.from_state} --> {trans.to_state}")
        
        lines.append("```")
        return "\n".join(lines)
    
    def save_state(self, filepath: str):
        """保存状态（断点续跑）"""
        state_data = {
            "current_state": self.current_state.name if self.current_state else None,
            "context": self.context,
            "history": self.history,
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state_data, f, ensure_ascii=False, indent=2)
    
    def load_state(self, filepath: str):
        """恢复状态"""
        with open(filepath, "r", encoding="utf-8") as f:
            state_data = json.load(f)
        self.context = state_data["context"]
        self.history = state_data["history"]
        if state_data["current_state"]:
            self._enter_state(state_data["current_state"])


# ===== 实战：客服Agent =====

def build_customer_service_agent() -> StateMachineAgent:
    """构建客服状态机Agent"""
    agent = StateMachineAgent(name="CustomerService")
    
    # 1. 定义状态
    agent.add_state("receive", StateType.INITIAL,
        on_enter=lambda ctx: ctx.update({"greeted": True}))
    agent.add_state("classify")
    agent.add_state("query_order")
    agent.add_state("refund")
    agent.add_state("complaint")
    agent.add_state("human_transfer")
    agent.add_state("resolved", StateType.SUCCESS)
    agent.add_state("failed", StateType.FAILED)
    
    # 2. 定义转换规则
    agent.add_transition("receive", "classify",
        condition=lambda ctx: ctx.get("user_input") is not None)
    
    agent.add_transition("classify", "query_order",
        condition=lambda ctx: "订单" in ctx.get("user_input", ""),
        priority=2)
    agent.add_transition("classify", "refund",
        condition=lambda ctx: "退款" in ctx.get("user_input", "") or "退货" in ctx.get("user_input", ""),
        priority=2)
    agent.add_transition("classify", "complaint",
        condition=lambda ctx: "投诉" in ctx.get("user_input", ""),
        priority=2)
    agent.add_transition("classify", "human_transfer",
        condition=lambda ctx: "人工" in ctx.get("user_input", ""),
        priority=3)
    
    agent.add_transition("query_order", "resolved",
        condition=lambda ctx: ctx.get("order_info") is not None)
    agent.add_transition("refund", "resolved",
        condition=lambda ctx: ctx.get("refund_status") == "processed")
    agent.add_transition("complaint", "human_transfer",
        condition=lambda ctx: ctx.get("severity") == "high")
    agent.add_transition("complaint", "resolved",
        condition=lambda ctx: ctx.get("resolution") is not None)
    
    return agent


if __name__ == "__main__":
    agent = build_customer_service_agent()
    
    print("=== 客服Agent 状态图 ===")
    print(agent.get_state_diagram())
    
    print("\n=== 模拟对话 ===")
    agent.start()
    
    # 场景1：查询订单
    result = agent.process({"user_input": "我想查一下我的订单状态"})
    print(f"输入: 查订单 → 状态: {agent.current_state.name}")
    
    # 模拟订单查询完成
    agent.context["order_info"] = "订单#12345，已发货"
    result = agent.process()
    print(f"结果: {result}")
    
    # 场景2：转人工
    agent2 = build_customer_service_agent()
    agent2.start()
    agent2.process({"user_input": "我要人工客服"})
    print(f"\n输入: 转人工 → 状态: {agent2.current_state.name}")
    
    # 保存和恢复
    agent3 = build_customer_service_agent()
    agent3.start()
    agent3.process({"user_input": "我想查一下我的订单"})
    agent3.save_state("agent_state.json")
    print(f"\n保存状态: {agent3.current_state.name}")
    
    # 新会话恢复
    agent4 = build_customer_service_agent()
    agent4.load_state("agent_state.json")
    print(f"恢复状态: {agent4.current_state.name}")
    
    # 清理
    import os
    if os.path.exists("agent_state.json"):
        os.remove("agent_state.json")
```

---

## 关键设计决策

### 1. 状态机 vs ReAct 的选择

| 场景 | 推荐方案 | 原因 |
|------|---------|------|
| 流程固定、步骤明确 | 状态机 | 可预测、可审计 |
| 需要创造性、步骤不确定 | ReAct | 灵活、自适应 |
| 混合型 | 状态机内嵌ReAct | 每个状态里用ReAct处理 |

### 2. 断点续跑

状态机的天然优势——当前状态就是一个"存档点"。
保存 `current_state + context`，下次加载就能从断点继续。

---

## 练习题

1. **子状态机**：在 "query_order" 状态内嵌一个子状态机（验证身份→查询→返回结果）
2. **超时自动转换**：等待输入超过30秒自动转到"超时"状态
3. **状态恢复后的上下文提示**：恢复断点时，自动生成"你上次做到了XX，继续吗？"的提示
