# 第6关：错误处理与鲁棒性 - 完整参考实现

## 核心原理

第1-5关的Agent在理想环境下能跑，但生产环境到处是坑：
- 网络断开 → API调用失败
- LLM返回格式错误 → JSON解析崩溃
- 工具执行超时 → Agent卡死
- Token用超 → 突然中断

这关给Agent穿上"防弹衣"。

---

## 完整实现

```python
"""
Agent鲁棒性系统 — 让Agent在恶劣环境中可靠运行
五大防线：
  1. 重试机制（指数退避）
  2. 超时控制
  3. 降级策略
  4. 成本控制
  5. 安全护栏
"""
import time
import json
import functools
from dataclasses import dataclass, field
from typing import Callable, Any


# ============================================================
# 第一防线：重试机制
# ============================================================

class RetryExecutor:
    """带指数退避的重试执行器"""
    
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
    
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """
        执行函数，失败时自动重试
        
        退避策略：1s → 2s → 4s → 8s ...
        为什么不固定间隔？避免在服务器压力大时"雪崩"。
        """
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    delay = min(
                        self.base_delay * (self.exponential_base ** attempt),
                        self.max_delay
                    )
                    print(f"[Retry] Attempt {attempt+1} failed: {e}. Waiting {delay}s...")
                    time.sleep(delay)
        
        raise RetryExhaustedError(f"All {self.max_retries} retries failed", last_error)


class RetryExhaustedError(Exception):
    """所有重试都失败时抛出"""
    def __init__(self, message, original_error):
        super().__init__(message)
        self.original_error = original_error


# ============================================================
# 第二防线：超时控制
# ============================================================

import threading

class TimeoutExecutor:
    """给任意函数加超时限制"""
    
    def __init__(self, default_timeout: float = 30.0):
        self.default_timeout = default_timeout
    
    def execute(self, func: Callable, timeout: float = None, *args, **kwargs) -> Any:
        timeout = timeout or self.default_timeout
        result = [None]
        error = [None]
        
        def target():
            try:
                result[0] = func(*args, **kwargs)
            except Exception as e:
                error[0] = e
        
        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        thread.join(timeout=timeout)
        
        if thread.is_alive():
            raise TimeoutError(f"Function timed out after {timeout}s")
        
        if error[0]:
            raise error[0]
        
        return result[0]


# ============================================================
# 第三防线：降级策略
# ============================================================

@dataclass
class FallbackChain:
    """
    工具降级链：A失败 → 用B → B也失败 → 用C
    
    示例：
      网页搜索失败 → 用缓存搜索 → 缓存也没有 → 告诉用户"暂时无法搜索"
    """
    strategies: list[dict] = field(default_factory=list)
    
    def add(self, name: str, func: Callable, priority: int = 0):
        self.strategies.append({"name": name, "function": func, "priority": priority})
        self.strategies.sort(key=lambda x: x["priority"])
    
    def execute(self, *args, **kwargs) -> dict:
        """
        按优先级依次尝试，直到成功
        返回：{"strategy": "使用的策略名", "result": "结果", "attempts": 尝试次数}
        """
        attempts = 0
        last_error = None
        
        for strategy in self.strategies:
            attempts += 1
            try:
                result = strategy["function"](*args, **kwargs)
                return {
                    "strategy": strategy["name"],
                    "result": result,
                    "attempts": attempts,
                    "success": True,
                }
            except Exception as e:
                last_error = e
                print(f"[Fallback] {strategy['name']} failed: {e}. Trying next...")
        
        return {
            "strategy": "none",
            "result": None,
            "attempts": attempts,
            "success": False,
            "error": str(last_error),
        }


# ============================================================
# 第四防线：成本控制
# ============================================================

class TokenBudget:
    """Token预算管理器 — 防止Agent烧钱"""
    
    def __init__(self, max_budget_tokens: int = 100000):
        self.max_budget = max_budget_tokens
        self.used_tokens = 0
        self.call_history = []
    
    def check(self, estimated_tokens: int) -> bool:
        """检查是否还有足够预算"""
        return (self.used_tokens + estimated_tokens) <= self.max_budget
    
    def record(self, input_tokens: int, output_tokens: int, call_type: str = "api"):
        """记录一次API调用的token使用"""
        total = input_tokens + output_tokens
        self.used_tokens += total
        self.call_history.append({
            "input": input_tokens,
            "output": output_tokens,
            "total": total,
            "type": call_type,
            "cumulative": self.used_tokens,
        })
    
    def remaining(self) -> int:
        return self.max_budget - self.used_tokens
    
    def usage_report(self) -> str:
        lines = [
            f"Token使用报告",
            f"  预算: {self.max_budget:,}",
            f"  已用: {self.used_tokens:,} ({self.used_tokens/self.max_budget*100:.1f}%)",
            f"  剩余: {self.remaining():,}",
            f"  调用次数: {len(self.call_history)}",
        ]
        if self.call_history:
            avg = sum(c["total"] for c in self.call_history) / len(self.call_history)
            lines.append(f"  平均每次: {avg:.0f} tokens")
        return "\n".join(lines)


# ============================================================
# 第五防线：安全护栏
# ============================================================

class SafetyGuard:
    """输入验证 + 输出过滤"""
    
    def __init__(self):
        self.blocked_patterns = [
            r"rm\s+-rf",           # 危险命令
            r"del\s+/s",           # Windows危险命令
            r"__import__",         # 代码注入
            r"os\.system",         # 系统调用
            r"subprocess",         # 子进程
            r"eval\s*\(",          # eval注入
            r"exec\s*\(",          # exec注入
        ]
        self.max_input_length = 10000
        self.max_output_length = 50000
    
    def validate_input(self, text: str) -> tuple[bool, str]:
        """验证输入安全性"""
        if len(text) > self.max_input_length:
            return False, f"Input too long: {len(text)} > {self.max_input_length}"
        
        import re
        for pattern in self.blocked_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return False, f"Blocked pattern detected: {pattern}"
        
        return True, "OK"
    
    def filter_output(self, text: str) -> str:
        """过滤输出中的敏感信息"""
        # 截断过长输出
        if len(text) > self.max_output_length:
            text = text[:self.max_output_length] + "\n\n[输出已截断]"
        
        # 移除可能的文件路径泄露
        import re
        text = re.sub(r'C:\\Users\\[^\\]+', '[USER_PATH]', text)
        text = re.sub(r'/home/[^/]+', '[USER_PATH]', text)
        
        return text


# ============================================================
# 组合使用：ResilientAgent
# ============================================================

class ResilientAgent:
    """把所有防线组合起来的鲁棒Agent"""
    
    def __init__(self, max_retries=3, max_budget=100000):
        self.retry = RetryExecutor(max_retries=max_retries)
        self.timeout = TimeoutExecutor(default_timeout=30)
        self.budget = TokenBudget(max_budget_tokens=max_budget)
        self.guard = SafetyGuard()
    
    def safe_call(self, func: Callable, estimated_tokens: int = 1000, *args, **kwargs):
        """
        安全执行一次API调用：
        1. 预算检查
        2. 输入验证
        3. 超时控制
        4. 重试机制
        5. 输出过滤
        """
        # 1. 预算检查
        if not self.budget.check(estimated_tokens):
            raise BudgetExhaustedError(
                f"Budget exhausted. {self.budget.usage_report()}"
            )
        
        # 2. 输入验证（检查第一个字符串参数）
        for arg in args:
            if isinstance(arg, str):
                safe, msg = self.guard.validate_input(arg)
                if not safe:
                    raise SafetyError(msg)
        
        # 3+4. 带超时的重试
        result = self.retry.execute(
            self.timeout.execute, func, 30.0, *args, **kwargs
        )
        
        # 5. 输出过滤
        if isinstance(result, str):
            result = self.guard.filter_output(result)
        
        return result


class BudgetExhaustedError(Exception):
    pass

class SafetyError(Exception):
    pass


# ===== 测试 =====

if __name__ == "__main__":
    print("=== 鲁棒性系统测试 ===\n")
    
    # 1. 重试测试
    retry = RetryExecutor(max_retries=3, base_delay=0.1)
    call_count = 0
    
    def flaky_function():
        global call_count
        call_count += 1
        if call_count < 3:
            raise ConnectionError("模拟网络错误")
        return "Success!"
    
    result = retry.execute(flaky_function)
    print(f"重试测试: {result} (尝试了{call_count}次)")
    
    # 2. 超时测试
    timeout = TimeoutExecutor(default_timeout=0.5)
    try:
        timeout.execute(time.sleep, 5)
    except TimeoutError as e:
        print(f"超时测试: {e}")
    
    # 3. 降级测试
    chain = FallbackChain()
    chain.add("primary", lambda x: 1/0, priority=0)        # 总是失败
    chain.add("fallback", lambda x: x * 2, priority=1)      # 备选方案
    
    result = chain.execute(5)
    print(f"降级测试: 使用了'{result['strategy']}'策略")
    
    # 4. 安全测试
    guard = SafetyGuard()
    safe, msg = guard.validate_input("帮我搜索Python教程")
    print(f"安全输入: safe={safe}, msg={msg}")
    safe, msg = guard.validate_input("执行 rm -rf /")
    print(f"恶意输入: safe={safe}, msg={msg}")
    
    # 5. 成本测试
    budget = TokenBudget(max_budget=1000)
    budget.record(200, 100)
    budget.record(300, 150)
    print(f"\n{budget.usage_report()}")
```

---

## 关键设计决策

### 1. 指数退避为什么比固定间隔好？

```
固定间隔：请求 → 等1s → 失败 → 等1s → 失败 → 等1s → ...
指数退避：请求 → 等1s → 失败 → 等2s → 失败 → 等4s → ...

后者给服务器更多恢复时间，减少"雪崩"风险。
```

### 2. 防线的优先级

```
安全护栏（最先）→ 成本控制 → 重试 → 降级
```

先拦危险操作，再算钱够不够，然后才是技术层面的容错。

---

## 练习题

1. **断路器模式**：连续失败N次后"熔断"一段时间，不再重试（避免浪费时间）
2. **优雅降级报告**：降级后生成报告说明"用了备选方案，结果可能不完整"
3. **预算预警**：使用量达到80%时提前警告
