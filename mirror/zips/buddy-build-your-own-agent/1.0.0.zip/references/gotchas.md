# Build Your Own Agent — 常见陷阱 (Gotchas)

| # | 陷阱 | 规避 |
|---|------|------|
| 1 | `max_iterations` 没设 → 无限循环 | 永远设上限，推荐5-10 |
| 2 | tool_result 没关联 tool_use_id | 严格一对一映射 |
| 3 | 用 eval() 执行用户输入 | ast.literal_eval 或 math 库 |
| 4 | 长对话撑爆上下文窗口 | 消息压缩或滑动窗口 |
| 5 | 多Agent消息互相污染 | 每个Agent维护独立上下文 |
| 6 | 向量库没持久化到磁盘 | faiss.write_index / read_index |
| 7 | 工具描述不清晰导致LLM乱调用 | 描述含：功能+何时用+输出格式 |
| 8 | 自进化导致prompt越改越差 | 保留基线版本，A/B测试验证 |
