# 第2关：工具系统 - 完整参考实现

## 核心原理

第1关的工具是硬编码在代码里的——每次加工具都要改三处（定义、Schema、执行逻辑）。
这关的目标是做到"**写一个函数 = 注册一个工具**"。

关键设计思想：**装饰器 + 反射**

Python 的 `inspect` 模块能读取函数签名（参数名、类型注解），我们利用这一点自动生成 Claude 需要的 JSON Schema。

---

## 完整实现

```python
"""
工具注册系统 — 从函数到工具，一行搞定
核心思路：装饰器收集函数信息，反射自动生成Schema
"""
import inspect
import json
import functools
from typing import Any, Callable, get_type_hints

# Python 类型 → JSON Schema 类型 的映射
TYPE_MAP = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}

class ToolRegistry:
    """通用工具注册器 — 装饰器模式"""
    
    def __init__(self):
        self._tools: dict[str, dict] = {}
    
    def register(self, name: str | None = None, description: str | None = None):
        """
        装饰器：将普通函数注册为Agent可调用的工具
        
        用法：
            registry = ToolRegistry()
            
            @registry.register(description="计算两个数的和")
            def add(a: int, b: int) -> int:
                return a + b
        """
        def decorator(func: Callable):
            # 工具名称：优先用参数指定的，否则用函数名
            tool_name = name or func.__name__
            tool_desc = description or (func.__doc__ or f"Call {tool_name}")
            
            # 从函数签名提取参数信息
            sig = inspect.signature(func)
            type_hints = get_type_hints(func) if hasattr(func, '__annotations__') else {}
            
            properties = {}
            required = []
            
            for param_name, param in sig.parameters.items():
                # 跳过 self 参数（如果是方法）
                if param_name == "self":
                    continue
                
                # 推断参数类型
                param_type = type_hints.get(param_name, str)
                json_type = TYPE_MAP.get(param_type, "string")
                
                # 推断是否必填（无默认值 = 必填）
                if param.default is inspect.Parameter.empty:
                    required.append(param_name)
                
                properties[param_name] = {
                    "type": json_type,
                    "description": f"The {param_name} parameter"
                }
            
            # 构建完整的工具Schema（Claude API格式）
            schema = {
                "name": tool_name,
                "description": tool_desc,
                "input_schema": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                }
            }
            
            # 存储工具信息
            self._tools[tool_name] = {
                "function": func,
                "schema": schema,
                "name": tool_name,
            }
            
            return func
        
        return decorator
    
    def get_schemas(self) -> list[dict]:
        """获取所有工具的Schema列表（传给Claude API用）"""
        return [t["schema"] for t in self._tools.values()]
    
    def execute(self, tool_name: str, inputs: dict) -> str:
        """
        执行指定工具
        
        安全设计：
        1. 工具不存在时返回友好错误（不抛异常）
        2. 参数缺失时返回参数列表
        3. 执行异常时返回错误信息（不崩溃）
        """
        if tool_name not in self._tools:
            available = ", ".join(self._tools.keys())
            return f"Error: Tool '{tool_name}' not found. Available: {available}"
        
        try:
            result = self._tools[tool_name]["function"](**inputs)
            return str(result)
        except TypeError as e:
            # 参数错误
            func = self._tools[tool_name]["function"]
            sig = inspect.signature(func)
            return f"Error: Invalid arguments for {tool_name}. Expected: {list(sig.parameters.keys())}. Got: {inputs}. Detail: {e}"
        except Exception as e:
            return f"Error: Tool execution failed. {type(e).__name__}: {e}"


# ===== 使用示例 =====

if __name__ == "__main__":
    registry = ToolRegistry()
    
    @registry.register(description="计算数学表达式。支持加减乘除和幂运算。")
    def calculate(expression: str) -> float:
        """安全的数学计算器"""
        # 只允许数学字符，防止代码注入
        # 注意：Python 用 ** 表示幂运算，^ 是异或（bitwise XOR）
        import math
        allowed = set("0123456789+-*/().% ")
        if not all(c in allowed for c in expression):
            return "Error: Invalid characters in expression"
        try:
            result = eval(expression, {"__builtins__": {}}, {"math": math})
            return result
        except Exception as e:
            return f"Error: {e}"
    
    @registry.register(description="搜素网页信息。返回相关搜索结果摘要。")
    def web_search(query: str, num_results: int = 3) -> str:
        """模拟网页搜索（实际项目中替换为API调用）"""
        # 这里是模拟实现
        results = [
            f"Result 1: {query} - 相关信息摘要...",
            f"Result 2: {query} - 更多相关信息...",
            f"Result 3: {query} - 补充信息...",
        ]
        return "\n".join(results[:num_results])
    
    @registry.register(description="读取指定文件的内容")
    def read_file(file_path: str) -> str:
        """读取文件内容"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except FileNotFoundError:
            return f"Error: File not found: {file_path}"
        except Exception as e:
            return f"Error: {e}"
    
    @registry.register(description="将内容写入指定文件")
    def write_file(file_path: str, content: str) -> str:
        """写入文件"""
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
            return f"Successfully wrote {len(content)} characters to {file_path}"
        except Exception as e:
            return f"Error: {e}"
    
    # 测试
    print("=== 工具Schema ===")
    for schema in registry.get_schemas():
        print(json.dumps(schema, indent=2, ensure_ascii=False))
    
    print("\n=== 执行测试 ===")
    print(f"calculate: {registry.execute('calculate', {'expression': '(1847 * 23) + (512 / 4)'})}")
    print(f"web_search: {registry.execute('web_search', {'query': 'AI Agent'})}")
    print(f"not_found: {registry.execute('not_exist', {'a': 1})}")
    print(f"bad_args: {registry.execute('calculate', {'wrong_param': 42})}")
```

---

## 关键设计决策

### 1. 为什么用装饰器？

```python
# 不用装饰器（第1关的方式）—— 每次加工具要改三处
tools = [{"name": "calc", ...}]  # 1. 定义Schema
def execute_tool(name, inputs):  # 2. 加执行分支
    if name == "calc": ...
# 3. 在tools列表里注册

# 用装饰器（本关）—— 只写一个函数
@registry.register(description="计算数学表达式")
def calculate(expression: str) -> float:
    return eval(expression)
# Schema自动生成，执行自动注册
```

### 2. 安全设计三原则

| 风险 | 防御 | 代码体现 |
|------|------|---------|
| 工具不存在 | 友好错误 + 列出可用工具 | `execute()` 开头检查 |
| 参数错误 | 显示期望参数 | `TypeError` 捕获 |
| 代码注入 | 白名单字符 | `calculate()` 里的 `allowed` |

### 3. 类型推断的局限

Python 是动态语言，类型注解经常缺失。当类型推断不出来时，默认用 `string`。
这是合理的：宁可让 LLM 多传一个字符串再转换，也好过 Schema 错误导致调用失败。

---

## 练习题

1. **扩展类型映射**：添加对 `Optional[int]`（可为空整数）和 `list[str]`（字符串列表）的支持
2. **工具超时**：给 `execute()` 加一个 `timeout` 参数，超时自动返回错误
3. **工具分组**：实现 `registry.group("math")` 功能，让工具可以按类别组织
