#!/usr/bin/env python3
"""
睡眠记忆整合脚本 — 模拟人类睡眠时的记忆整理过程
功能：短期→长期记忆转移、新旧知识关联、规律发现、经验强化、记忆遗忘

用法:
  python3 consolidate.py          # 执行一次完整的睡眠整合
  python3 consolidate.py stats    # 查看经验统计
  python3 consolidate.py pending  # 查看待解决清单
  python3 consolidate.py insights # 查看已发现的规律
  python3 consolidate.py add --task "xxx" --lesson "yyy"  # 手动添加经验
"""

import sys
import os
import json
import time
import argparse
from collections import Counter
from datetime import datetime, timedelta

BASE_DIR = os.path.expanduser("~/.unified-mind")
DATA_DIR = os.path.join(BASE_DIR, "data")

SENSORS_FILE = os.path.join(DATA_DIR, "sensor.json")
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")
INSIGHTS_FILE = os.path.join(BASE_DIR, "INSIGHTS.md")
PATTERNS_FILE = os.path.join(DATA_DIR, "patterns.json")
PENDING_FILE = os.path.join(DATA_DIR, "pending.json")


def load_json(path, default=None):
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return default if default is not None else {}


def atomic_write(path, data):
    tmp = path + ".tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if isinstance(data, str):
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(data)
    else:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)
        print("[INFO] 数据目录已创建")
        return False
    return True


def consolidate():
    """执行一次完整的睡眠整合"""
    if not ensure_data_dir():
        print("[WARN] 数据目录不存在，请先运行 init.py")
        return

    sensor = load_json(SENSORS_FILE, {"records": [], "preferences": []})
    memory = load_json(MEMORY_FILE, {"short_term": [], "long_term": [], "rules": []})
    patterns = load_json(PATTERNS_FILE, {"patterns": []})
    pending = load_json(PENDING_FILE, {"problems": []})

    records = sensor.get("records", [])
    long_term = memory.get("long_term", [])
    rules = memory.get("rules", [])

    print("=" * 50)
    print("睡眠记忆整合 — 开始")
    print("=" * 50)
    print(f"短期记忆: {len(records)}条")
    print(f"长期记忆: {len(long_term)}条")
    print(f"已知规则: {len(rules)}条")
    print(f"已知模式: {len(patterns.get('patterns', []))}个")
    print(f"待解决清单: {len(pending.get('problems', []))}项")
    print()

    # ① 短期→长期记忆转移
    promoted = 0
    for record in records[-20:]:  # 最近20条记录
        task = record.get("task", "")
        result = record.get("result", "")
        timestamp = record.get("timestamp", "")

        # 判断是否值得转移到长期记忆
        if result == "success":
            # 成功的任务，转移
            existing = [lt for lt in long_term if lt.get("task") == task]
            if not existing:
                long_term.append({
                    "task": task,
                    "result": result,
                    "timestamp": timestamp,
                    "retained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "reference_count": 1,
                })
                promoted += 1
            else:
                # 已存在，增加引用计数
                for lt in existing:
                    lt["reference_count"] = lt.get("reference_count", 1) + 1
        elif result == "failure":
            # 失败的任务也转移（作为反面经验）
            existing = [lt for lt in long_term
                        if lt.get("task") == task and lt.get("result") == "failure"]
            if not existing:
                long_term.append({
                    "task": task,
                    "result": result,
                    "timestamp": timestamp,
                    "retained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "reference_count": 1,
                })
                promoted += 1

    print(f"[记忆转移] 从短期转移到长期: {promoted}条")

    # ② 新旧知识关联
    if len(records) >= 3:
        recent_tasks = [r.get("task", "") for r in records[-10:] if r.get("task")]
        task_words = []
        for task in recent_tasks:
            # 简单分词（中文按字符，英文按空格）
            words = task.split()
            task_words.extend(words)

        # 找高频关键词
        word_counts = Counter(task_words)
        high_freq = [(w, c) for w, c in word_counts.most_common(5) if c >= 2]

        if high_freq:
            associations = []
            for word, count in high_freq:
                related = [t for t in recent_tasks if word in t]
                if len(related) >= 2:
                    associations.append(f"  - 「{word}」出现在{len(related)}个任务中: {', '.join(related[:3])}")

            if associations:
                print(f"[知识关联] 发现关联:")
                for a in associations:
                    print(a)

    # ③ 规律发现
    if len(records) >= 5:
        task_types = [r.get("task", "unknown") for r in records[-30:]]
        type_counts = Counter(task_types)

        # 提取通用模式（按前缀归类）
        prefixes = Counter()
        for task in task_types:
            # 取任务名的前几个字符作为模式
            prefix = task[:min(6, len(task))]
            prefixes[prefix] += 1

        frequent = [(p, c) for p, c in type_counts.most_common(5) if c >= 2]
        if frequent:
            print(f"[规律发现] 高频任务类型:")
            for name, count in frequent:
                pct = count / len(task_types) * 100
                # 计算成功率
                success = sum(1 for r in records[-30:]
                             if r.get("task") == name and r.get("result") == "success")
                total = sum(1 for r in records[-30:] if r.get("task") == name)
                rate = success / total * 100 if total > 0 else 0
                print(f"  - {name}: {count}次 ({pct:.0f}%), 成功率{rate:.0f}%")

    # ④ 重要经验强化
    # 提升高频成功方案的优先级
    success_records = [r for r in records if r.get("result") == "success"]
    success_counts = Counter(r.get("task", "") for r in success_records[-50:])
    top_success = success_counts.most_common(3)

    if top_success:
        print(f"[经验强化] 最可靠的任务类型:")
        for name, count in top_success:
            print(f"  - {name}: 成功{count}次")

    # ⑤ 无价值记忆遗忘
    # 压缩长期记忆，只保留最近的和引用次数高的
    cutoff_date = (datetime.now() - timedelta(days=30)).isoformat()[:10]
    before = len(long_term)
    long_term = [lt for lt in long_term
                 if lt.get("reference_count", 1) >= 3
                 or (lt.get("timestamp", "") >= cutoff_date)
                 or lt.get("result") == "success"]
    forgotten = before - len(long_term)
    # 限制总数
    if len(long_term) > 100:
        # 按引用次数排序，保留前100
        long_term.sort(key=lambda x: x.get("reference_count", 1), reverse=True)
        long_term = long_term[:100]
        forgotten += before - 100

    if forgotten > 0:
        print(f"[记忆遗忘] 压缩/遗忘: {forgotten}条旧记忆")

    # ⑥ 更新模式库
    existing_patterns = {p["name"]: p for p in patterns.get("patterns", [])}
    for record in records[-30:]:
        task = record.get("task", "")
        result = record.get("result", "")
        if result == "failure" and task:
            # 失败的任务，检查是否应该记录为模式
            if task not in existing_patterns:
                # 简单记录
                existing_patterns[f"失败-{task}"] = {
                    "name": f"失败-{task}",
                    "signature": [task, "failure"],
                    "solution": "待分析",
                    "confidence": 0.5,
                    "times_seen": 1,
                }
            else:
                existing_patterns[f"失败-{task}"]["times_seen"] = \
                    existing_patterns[f"失败-{task}"].get("times_seen", 0) + 1

    patterns["patterns"] = list(existing_patterns.values())

    # 保存更新
    memory["long_term"] = long_term[-100:]  # 最多保留100条
    atomic_write(MEMORY_FILE, memory)
    atomic_write(PATTERNS_FILE, patterns)

    # 生成洞察报告
    insights = generate_insights(sensor, memory, patterns, pending)
    atomic_write(INSIGHTS_FILE, insights)

    print()
    print("=" * 50)
    print("睡眠记忆整合 — 完成")
    print(f"洞察报告已生成: {INSIGHTS_FILE}")
    print("=" * 50)


def generate_insights(sensor, memory, patterns, pending):
    """生成洞察报告"""
    records = sensor.get("records", [])
    prefs = sensor.get("preferences", [])
    long_term = memory.get("long_term", [])
    rules = memory.get("rules", [])

    lines = ["# 睡眠整合报告", ""]
    lines.append(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")

    # 高频需求
    if records:
        task_types = [r.get("task", "unknown") for r in records[-30:]]
        type_counts = Counter(task_types)
        frequent = [(p, c) for p, c in type_counts.most_common(5) if c >= 2]

        if frequent:
            lines.append("## 高频需求")
            for name, count in frequent:
                pct = count / len(task_types) * 100
                lines.append(f"- {name}: {count}次 ({pct:.0f}%)")
            lines.append("")

    # 发现的规律
    lines.append("## 发现的规律")
    # 从偏好中提取
    non_persona = [p for p in prefs if p.get("type") != "persona"]
    if non_persona:
        for p in non_persona[-5:]:
            lines.append(f"- {p.get('key', '?')}: {p.get('value', '?')}")
    else:
        lines.append("- 暂无足够数据")
    lines.append("")

    # 经验强化
    success_records = [r for r in records if r.get("result") == "success"]
    if success_records:
        success_counts = Counter(r.get("task", "") for r in success_records[-30:])
        top = success_counts.most_common(3)
        lines.append("## 经验强化")
        for name, count in top:
            lines.append(f"- [强化] {name}（最近成功{count}次）")
        lines.append("")

    # 待解决清单
    problems = pending.get("problems", [])
    if problems:
        lines.append("## 待解决清单")
        for p in problems[:5]:
            status = p.get("status", "thinking")
            attempts = p.get("attempts", 0)
            lines.append(f"- [{status}] {p.get('description', '?')}")
            lines.append(f"  已尝试{attempts}次 | 创建于{p.get('created', '?')}")
        lines.append("")

    # 已知规则
    if rules:
        lines.append("## 已提取的通用规则")
        for r in rules[:10]:
            trigger = r.get("trigger", "?")
            check = r.get("check", "?")
            lines.append(f"- 触发: {trigger}")
            lines.append(f"  检查: {check}")
        lines.append("")

    lines.append("状态: 就绪")

    return "\n".join(lines)


def cmd_stats():
    """查看经验统计"""
    sensor = load_json(SENSORS_FILE, {"records": [], "preferences": []})
    memory = load_json(MEMORY_FILE, {"long_term": []})
    patterns = load_json(PATTERNS_FILE, {"patterns": []})

    records = sensor.get("records", [])
    success = sum(1 for r in records if r.get("result") == "success")
    failure = sum(1 for r in records if r.get("result") == "failure")

    print("=" * 50)
    print("经验直觉统计")
    print("=" * 50)
    print(f"总任务数: {len(records)}")
    print(f"成功: {success} | 失败: {failure}")
    print(f"成功率: {success / len(records) * 100:.1f}%" if records else "成功率: N/A")
    print(f"长期记忆: {len(memory.get('long_term', []))}条")
    print(f"已知模式: {len(patterns.get('patterns', []))}个")

    # 最近任务
    if records:
        print(f"\n最近5条记录:")
        for r in records[-5:]:
            icon = "OK" if r.get("result") == "success" else "FAIL"
            print(f"  [{icon}] {r.get('task', '?')} ({r.get('timestamp', '?')})")


def cmd_pending():
    """查看待解决清单"""
    pending = load_json(PENDING_FILE, {"problems": []})
    problems = pending.get("problems", [])

    print("=" * 50)
    print("待解决清单")
    print("=" * 50)

    if not problems:
        print("没有待解决的问题")
        return

    for i, p in enumerate(problems):
        status = p.get("status", "thinking")
        desc = p.get("description", "?")
        attempts = p.get("attempts", 0)
        created = p.get("created", "?")
        context = ", ".join(p.get("related_context", []))
        print(f"\n  {i + 1}. [{status}] {desc}")
        print(f"     尝试: {attempts}次 | 创建: {created}")
        if context:
            print(f"     关联: {context}")


def cmd_insights():
    """查看已发现的规律"""
    if os.path.exists(INSIGHTS_FILE):
        with open(INSIGHTS_FILE, 'r', encoding='utf-8') as f:
            print(f.read())
    else:
        print("暂无洞察报告，请先运行 consolidate")


def cmd_add(args):
    """手动添加一条经验"""
    sensor_path = SENSORS_FILE
    sensor = load_json(sensor_path, {"records": [], "preferences": []})

    sensor.setdefault("records", []).append({
        "task": args.task,
        "result": args.result or "success",
        "lesson": args.lesson or "",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": "manual",
    })

    # 保留最近200条
    sensor["records"] = sensor["records"][-200:]
    atomic_write(sensor_path, sensor)

    print(f"[OK] 已添加经验: {args.task}" + (f" — {args.lesson}" if args.lesson else ""))


def main():
    parser = argparse.ArgumentParser(
        description="睡眠记忆整合",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("stats", help="查看经验统计")
    sub.add_parser("pending", help="查看待解决清单")
    sub.add_parser("insights", help="查看已发现的规律")

    add = sub.add_parser("add", help="手动添加经验")
    add.add_argument("--task", required=True, help="任务名称")
    add.add_argument("--result", default="success", choices=["success", "failure"])
    add.add_argument("--lesson", default="", help="经验教训")

    args = parser.parse_args()

    if not args.command or args.command == "default":
        consolidate()
    elif args.command == "stats":
        cmd_stats()
    elif args.command == "pending":
        cmd_pending()
    elif args.command == "insights":
        cmd_insights()
    elif args.command == "add":
        cmd_add(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
