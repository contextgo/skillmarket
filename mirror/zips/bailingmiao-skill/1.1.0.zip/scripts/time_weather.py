#!/usr/bin/env python3
"""
时间天气引擎 — 中国传统历法系统
二十四节气、农历、传统节日、天气生成
"""

import random
import math
from datetime import datetime, timedelta
from typing import Optional, Dict, List


# ============================================================
# 二十四节气
# ============================================================

JIEQI = [
    ("小寒", 1, 6), ("大寒", 1, 20), ("立春", 2, 4), ("雨水", 2, 19),
    ("惊蛰", 3, 6), ("春分", 3, 21), ("清明", 4, 5), ("谷雨", 4, 20),
    ("立夏", 5, 6), ("小满", 5, 21), ("芒种", 6, 6), ("夏至", 6, 21),
    ("小暑", 7, 7), ("大暑", 7, 23), ("立秋", 8, 7), ("处暑", 8, 23),
    ("白露", 9, 8), ("秋分", 9, 23), ("寒露", 10, 8), ("霜降", 10, 23),
    ("立冬", 11, 7), ("小雪", 11, 22), ("大雪", 12, 7), ("冬至", 12, 22),
]

# 节气描述（大傩世界风格）
JIEQI_DESC = {
    "小寒": "数九寒天开始，滴水成冰", "大寒": "最冷时节，万物闭塞",
    "立春": "春气始至，万物复苏", "雨水": "春雨润物，百草萌生",
    "惊蛰": "春雷初响，蛰虫惊动", "春分": "昼夜等长，春意正浓",
    "清明": "天朗气清，踏青时节", "谷雨": "雨生百谷，春播正忙",
    "立夏": "夏日初长，万物繁茂", "小满": "麦穗初齐，蚕茧结成",
    "芒种": "忙种忙收，颗粒归仓", "夏至": "日长至极，阴阳相争",
    "小暑": "温风至，蟋蟀居壁", "大暑": "酷热难耐，万物蒸腾",
    "立秋": "秋风起，凉意生", "处暑": "暑气止，秋凉来",
    "白露": "露凝白，秋意深", "秋分": "昼夜再等，秋收时节",
    "寒露": "寒露降，鸿雁来", "霜降": "霜始降，草木黄",
    "立冬": "冬始至，万物藏", "小雪": "初雪飘，天地白",
    "大雪": "雪纷飞，封山门", "冬至": "日短至极，一阳生",
}

SEASON_NAMES = ["春天", "夏天", "秋天", "冬天"]
SEASON_MAP = {3: "春天", 4: "春天", 5: "春天", 6: "夏天",
              7: "夏天", 8: "夏天", 9: "秋天", 10: "秋天", 11: "秋天",
              12: "冬天", 1: "冬天", 2: "冬天"}

# 传统节日
FESTIVALS = {
    (1, 1): ("元旦", "新年伊始，万象更新"),
    (1, 15): ("元宵节", "花灯如昼，圆月高悬"),
    (3, 3): ("上巳节", "祓禊祈福，春游踏青"),
    (5, 5): ("端午节", "龙舟竞渡，艾草悬门"),
    (7, 7): ("七夕节", "鹊桥相会，乞巧望月"),
    (7, 15): ("中元节", "祭祀先人，慎终追远"),
    (8, 15): ("中秋节", "月圆人团圆，桂花飘香"),
    (9, 9): ("重阳节", "登高望远，饮菊花酒"),
    (12, 30): ("除夕", "辞旧迎新，阖家团圆"),
}


def _lunar_approx(month: int, day: int) -> str:
    """粗略的农历日期估算"""
    # 简化的农历推算（不是精确的，但用于叙事足够）
    lunar_month_names = ["正月", "二月", "三月", "四月", "五月", "六月",
                         "七月", "八月", "九月", "十月", "冬月", "腊月"]
    # 简单的偏移表（每年不同，这里用固定偏移模拟）
    offsets = [30, 59, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19]
    days_so_far = sum(offsets[:min(month - 1, 12)]) + day
    lunar_day = ((days_so_far - 1) % 29) + 1  # 农历大月30天
    lunar_month = ((days_so_far - 1) // 29) + 1
    lunar_month = ((lunar_month - 1) % 12) + 1
    return f"{lunar_month_names[lunar_month - 1]}{lunar_day}"


def get_current_jieqi(month: int, day: int) -> tuple:
    """获取当前节气"""
    for name, m, d in JIEQI:
        if month == m and day >= d:
            next_name, _, next_d = JIEQI[(JIEQI.index((name, m, d)) + 1) % len(JIEQI)]
            progress = (day - d) / (next_d - d) if next_d > d else 0.5
            return name, JIEQI_DESC.get(name, ""), progress
    # 最后一个节气到年底
    return JIEQI[-1][0], JIEQI_DESC.get(JIEQI[-1][0], ""), 0.8


def get_season(month: int) -> str:
    return SEASON_MAP.get(month, "春天")


def get_festivals(month: int, day: int) -> list:
    """获取当天的节日"""
    return [(name, desc) for (m, d), (name, desc) in FESTIVALS.items()
            if m == month and d == day]


# ============================================================
# 时间引擎
# ============================================================

class TimeEngine:
    """中国传统历法引擎"""

    def __init__(self, saved: dict = None):
        if saved:
            self.story_day = saved.get("story_day", 0)
            self.start_date = saved.get("start_date", datetime.now().isoformat())
        else:
            self.story_day = 0
            self.start_date = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "story_day": self.story_day,
            "start_date": self.start_date,
        }

    def advance_days(self, n: int):
        """推进故事天数"""
        self.story_day += n

    def get_time_summary(self) -> dict:
        """获取完整的时间信息"""
        now = datetime.now()
        # 模拟故事内日期：从春天开始
        start = datetime.fromisoformat(self.start_date)
        elapsed = (now - start).days
        sim_month = ((elapsed % 365) // 30) % 12 + 3  # 从3月开始（春天）
        sim_day = ((elapsed % 365) % 30) + 1
        sim_year = 2024 + (elapsed // 365)

        season = get_season(sim_month)
        lunar_date = _lunar_approx(sim_month, sim_day)
        jieqi, jieqi_desc, jieqi_progress = get_current_jieqi(sim_month, sim_day)

        festivals = get_festivals(sim_month, sim_day)
        festival_descs = [f"{name}（{desc}）" for name, desc in festivals]

        return {
            "story_day": self.story_day,
            "sim_year": sim_year,
            "sim_month": sim_month,
            "sim_day": sim_day,
            "lunar_date": lunar_date,
            "season_name": season,
            "jieqi": jieqi,
            "jieqi_desc": jieqi_desc,
            "jieqi_progress": jieqi_progress,
            "festivals": festivals,
            "festival_descs": festival_descs,
            "is_new_year": sim_month in (1, 2) and sim_day <= 3,
        }

    def get_season(self) -> str:
        now = datetime.now()
        start = datetime.fromisoformat(self.start_date)
        elapsed = (now - start).days
        sim_month = ((elapsed % 365) // 30) % 12 + 3
        return get_season(sim_month)

    def get_current_jieqi(self) -> tuple:
        now = datetime.now()
        start = datetime.fromisoformat(self.start_date)
        elapsed = (now - start).days
        sim_month = ((elapsed % 365) // 30) % 12 + 3
        sim_day = ((elapsed % 365) % 30) + 1
        return get_current_jieqi(sim_month, sim_day)


# ============================================================
# 天气引擎
# ============================================================

WEATHER_POOL = {
    "spring": [
        ("晴", "温暖(18°C)", "春风拂面，桃李花开", {}, 0.30),
        ("多云", "凉爽(15°C)", "云层时聚时散，偶有阳光", {}, 0.25),
        ("小雨", "微凉(14°C)", "春雨绵绵，润物无声", {"danger_mod": 0.05}, 0.20),
        ("雷雨", "闷热(20°C)", "春雷滚滚，电闪雷鸣", {"danger_mod": 0.15}, 0.10),
        ("大风", "凉(12°C)", "东风呼啸，飞沙走石", {"danger_mod": 0.10}, 0.10),
        ("阴", "阴冷(13°C)", "天色阴沉，不见日影", {"danger_mod": 0.03}, 0.05),
    ],
    "夏天": [
        ("晴", "炎热(32°C)", "烈日当空，蝉鸣阵阵", {}, 0.20),
        ("多云", "闷热(30°C)", "乌云堆积，闷热难当", {}, 0.20),
        ("暴雨", "凉爽(22°C)", "暴雨如注，河道暴涨", {"danger_mod": 0.15}, 0.15),
        ("雷暴", "阴冷(18°C)", "电光划破天幕，暴雨倾盆", {"danger_mod": 0.20}, 0.12),
        ("大风", "凉爽(25°C)", "热风卷地，飞沙走石", {"danger_mod": 0.10}, 0.13),
        ("小雨", "温暖(28°C)", "阵雨忽至，转瞬即晴", {}, 0.10),
        ("酷热", "酷热(38°C)", "日头毒辣，滴水如蒸", {"mood_mod": -5}, 0.10),
    ],
    "autumn": [
        ("晴", "凉爽(18°C)", "秋高气爽，天蓝如洗", {}, 0.30),
        ("多云", "微凉(15°C)", "秋云朵朵，天高云淡", {}, 0.25),
        ("小雨", "凉(13°C)", "秋雨连绵，梧桐叶落", {"danger_mod": 0.05}, 0.20),
        ("阴", "阴冷(12°C)", "天色阴沉，秋风萧瑟", {"danger_mod": 0.03}, 0.15),
        ("大风", "冷(8°C)", "西风萧瑟，落叶纷飞", {"danger_mod": 0.10}, 0.10),
    ],
    "winter": [
        ("晴", "寒冷(5°C)", "天寒地冻，日色惨白", {}, 0.20),
        ("多云", "阴冷(2°C)", "厚云密布，天色灰暗", {}, 0.25),
        ("小雪", "冷(-1°C)", "初雪飘落，银装素裹", {"danger_mod": 0.10}, 0.20),
        ("大雪", "严寒(-5°C)", "鹅毛大雪，天地苍茫", {"danger_mod": 0.20}, 0.15),
        ("阴", "阴冷(0°C)", "朔风凛冽，滴水成冰", {"danger_mod": 0.05}, 0.15),
        ("大风", "极冷(-8°C)", "北风呼啸，滴水成冰", {"danger_mod": 0.15}, 0.15),
        ("暴雪", "酷寒(-10°C)", "风雪交加，寸步难行", {"danger_mod": 0.30, "extreme": True}, 0.05),
    ],
}

# 异常天气（大傩世界特色）
ANOMALOUS_WEATHER = [
    ("血雨", "天上降下红色的雨，所有人都不安", {"danger_mod": 0.25, "mood_mod": -10, "extreme": True}, 0.008),
    ("黑雾", "浓黑的大雾笼罩山谷，能见度不足三丈", {"danger_mod": 0.20, "mood_mod": -8, "extreme": True}, 0.010),
    ("灵气紊乱", "空气中有一种说不出的异样，修炼效率大变", {"mood_mod": -3, "danger_mod": 0.05}, 0.015),
    ("天降陨石", "天上掉下了奇怪的石头，砸出一个大坑", {"danger_mod": 0.30, "extreme": True}, 0.005),
    ("逆温", "山谷里温度突然倒转，热气在下面冷气在上面", {"danger_mod": 0.10}, 0.008),
    ("极光", "夜空中出现了奇异的彩色光芒，所有人都在看", {"mood_mod": 5}, 0.003),
]


class WeatherEngine:
    """大傩世界天气引擎"""

    def __init__(self, saved: dict = None):
        self.today_weather = None
        if saved:
            self.today_weather = saved.get("today_weather")

    def to_dict(self) -> dict:
        return {"today_weather": self.today_weather}

    def generate_weather(self, season: str, jieqi: str = "", world_pressure: float = 0.0) -> dict:
        """生成今日天气"""
        season_key = {"春天": "spring", "夏天": "summer", "秋天": "autumn", "冬天": "winter"}.get(season, "spring")
        pool = WEATHER_POOL.get(season_key, WEATHER_POOL["spring"])

        # 权重选择天气
        weights = [w[4] for w in pool]
        weather = random.choices(pool, weights=weights, k=1)[0]

        name, temperature, desc, mods, _ = weather
        result = {
            "name": name, "temperature": temperature, "desc": desc,
        }
        result.update(mods)

        # 世界压力影响异常天气概率
        anomaly_mult = 1.0 + world_pressure * 2.0
        if random.random() < 0.012 * anomaly_mult:
            # 触发异常天气
            anomaly = random.choices(ANOMALOUS_WEATHER, k=1)[0]
            an_name, an_desc, an_mods, an_prob = anomaly
            if random.random() < an_prob * anomaly_mult:
                result = {
                    "name": an_name, "temperature": temperature,
                    "desc": an_desc, "extreme": an_mods.get("extreme", False),
                }
                result.update(an_mods)

        self.today_weather = result
        return result
