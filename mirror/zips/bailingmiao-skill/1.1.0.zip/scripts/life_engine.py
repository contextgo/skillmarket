#!/usr/bin/env python3
"""
淼淼生活线引擎 v5.0 — 史诗历史引擎
世界自然演化 + 历史周期 + 势力博弈 + 名著叙事融合

用法:
  python life_engine.py init           # 初始化
  python life_engine.py status         # 查看状态
  python life_engine.py advance        # 推进时间（世界模拟）
  python life_engine.py opening        # 获取开场上下文
  python life_engine.py world          # 查看世界状态
  python life_engine.py factions       # 查看势力版图
  python life_engine.py update --summary "..."  # 更新状态
  python life_engine.py reset          # 重置
"""

import json
import os
import sys
import random
from datetime import datetime
from pathlib import Path
from copy import deepcopy

# === 路径配置 ===
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = Path(os.path.expanduser("~/.unified-mind/data"))
STATE_FILE = DATA_DIR / "life_state.json"
NPC_PROFILES_FILE = DATA_DIR / "npc_profiles.json"
NPC_PROFILES_DEFAULT = BASE_DIR / "defaults" / "npc_profiles.json"

# 导入世界模拟引擎
sys.path.insert(0, str(Path(__file__).parent))
from world_sim import WorldSim

# === 常量 ===
REALM_LIST = ["入门", "练气一层", "练气二层", "练气三层", "练气四层", "筑基"]

TIME_PERIODS = [
    ("卯时", "清晨（5:00-7:00）", "后院菜园"),
    ("辰时", "上午（7:00-9:00）", "厨房"),
    ("巳时", "上午（9:00-11:00）", "各处"),
    ("午时", "中午（11:00-13:00）", "东厢房"),
    ("未时", "下午（13:00-15:00）", "藏经阁/后院"),
    ("申时", "下午（15:00-17:00）", "练功场"),
    ("酉时", "傍晚（17:00-19:00）", "清涧溪旁"),
    ("戌时", "晚上（19:00-21:00）", "院子里"),
    ("亥时", "深夜（21:00-23:00）", "西厢房"),
]

MOOD_LABELS = [
    (90, 100, "非常开心"), (75, 89, "心情不错"), (60, 74, "还好"),
    (45, 59, "有点低落"), (30, 44, "心情不好"), (0, 29, "很难过"),
]

OPENING_STYLES = ["A", "B", "C", "D", "E", "F", "G"]


def get_time_period_index(hour: int) -> int:
    if 5 <= hour < 7: return 0
    elif 7 <= hour < 9: return 1
    elif 9 <= hour < 11: return 2
    elif 11 <= hour < 13: return 3
    elif 13 <= hour < 15: return 4
    elif 15 <= hour < 17: return 5
    elif 17 <= hour < 19: return 6
    elif 19 <= hour < 21: return 7
    else: return 8


def get_mood_label(val: int) -> str:
    for low, high, label in MOOD_LABELS:
        if low <= val <= high:
            return label
    return "还好"


def atomic_write(path: Path, data: dict):
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(str(tmp), str(path))


def get_default_state() -> dict:
    now = datetime.now()
    tp_idx = get_time_period_index(now.hour)
    tp_name = TIME_PERIODS[tp_idx][0]
    return {
        "version": "5.0",
        "meta": {
            "story_day": 0,
            "season": "春天",
            "total_sessions": 0,
            "last_real_time": None,
            "last_story_time": tp_name,
            "current_location": "清风观",
            "story_phase": "清风观日常",
            "created_at": now.isoformat(),
        },
        "mood": {
            "current": 70, "trend": "stable", "reason": None,
            "history_7day": [70] * 7,
        },
        "cultivation": {
            "realm": "入门", "realm_stage": 0, "progress": 5,
            "max_progress": 100, "breakthrough_pending": False,
            "recent_insight": None, "streak_days": 0,
        },
        "location": {
            "current": TIME_PERIODS[tp_idx][2],
            "area": "清风观", "destination": None, "reason": None,
        },
        "energy": {"physical": 80, "mental": 75, "hunger": 30},
        "weather": {"today": "晴", "temperature": "适宜", "description": None},
        "chores": {
            "water_garden_done": False, "sweep_done": False,
            "wash_day": 0, "firewood_done": False,
            "herbs_drying": None, "kitchen_help": False,
        },
        "relationships": {
            "李火旺": {
                "familiarity": 30, "last_met_day": 1,
                "last_interaction_summary": None,
                "cross_world_connection": "正常",
            },
        },
        "inventory": {"items": ["换洗衣物", "梳子", "手帕"], "special_items": []},
        "memories": {
            "short_term": [], "long_term": [], "key_memories": [], "total_count": 0,
        },
        "story_progress": {
            "current_arc": "清风观日常", "arc_started_day": 1,
            "completed_arcs": [], "unlocked_locations": ["清风观", "青石镇"],
            "discovered_secrets": [],
        },
        # v5.0 世界模拟状态
        "world_history": {
            "current_era": {
                "current_era": "太平盛世",
                "phase": "active",
                "started_day": 1,
                "era_pressure": 0.1,
                "theme": "山间岁月静好",
                "era_history": [],
            },
            "factions": {},
        },
        "npc_states": {},
        "world_pressure": 0.0,
        "triggered_world_events": [],
        "world_event_log": [],
        "active_ripples": [],
        "active_narrative_arcs": [],
        "event_history": [],
        "daily_log": [],
        "today_highlights": [],
        "recent_event_ids": [],
        "last_opening_style": None,
    }


def load_state() -> dict:
    if not STATE_FILE.exists():
        return None
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "meta" not in data or "mood" not in data:
            raise ValueError("Missing required fields")
        return data
    except (json.JSONDecodeError, ValueError) as e:
        print(f"状态文件损坏: {e}")
        return None


def save_state(state: dict):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    atomic_write(STATE_FILE, state)


def load_npc_profiles() -> dict:
    # 优先从运行时数据目录加载（init.py会从defaults/复制过来）
    if NPC_PROFILES_FILE.exists():
        with open(NPC_PROFILES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    # 回退到skill内置defaults/
    if NPC_PROFILES_DEFAULT.exists():
        with open(NPC_PROFILES_DEFAULT, "r", encoding="utf-8") as f:
            return json.load(f)
    print(f"NPC档案不存在: {NPC_PROFILES_FILE} 或 {NPC_PROFILES_DEFAULT}", file=sys.stderr)
    sys.exit(1)


# === 修炼更新 ===
def daily_cultivation_update(state: dict):
    c = state["cultivation"]
    if random.random() < 0.8:
        gain = random.randint(3, 8)
        if c["progress"] > 90:
            gain = max(1, gain - 3)
        c["progress"] = min(c["max_progress"], c["progress"] + gain)
        c["streak_days"] += 1
        if c["progress"] >= c["max_progress"]:
            c["breakthrough_pending"] = True
    else:
        c["streak_days"] = 0

    state["energy"]["physical"] = min(100, state["energy"]["physical"] + 25)
    state["energy"]["mental"] = min(100, state["energy"]["mental"] + 20)
    state["energy"]["hunger"] = min(100, state["energy"]["hunger"] + 15)

    mood = state["mood"]["current"]
    if mood > 70:
        mood = max(70, mood - random.randint(3, 10))
    elif mood < 70:
        mood = min(70, mood + random.randint(3, 10))
    state["mood"]["current"] = mood
    state["mood"]["history_7day"].append(mood)
    state["mood"]["history_7day"] = state["mood"]["history_7day"][-7:]

    state["chores"]["water_garden_done"] = False
    state["chores"]["sweep_done"] = False
    state["chores"]["firewood_done"] = False


def handle_breakthrough(state: dict):
    c = state["cultivation"]
    if not c["breakthrough_pending"]:
        return
    c["realm_stage"] += 1
    if c["realm_stage"] < len(REALM_LIST):
        c["realm"] = REALM_LIST[c["realm_stage"]]
    c["progress"] = 0
    c["breakthrough_pending"] = False
    state["memories"]["key_memories"].append({
        "id": f"key_{state['memories']['total_count']:04d}",
        "day": state["meta"]["story_day"],
        "content": f"修炼突破到了{c['realm']}！",
        "type": "breakthrough", "importance": 5,
    })
    state["memories"]["total_count"] += 1
    state["today_highlights"].append(f"修炼突破！到达{c['realm']}")
    state["mood"]["current"] = min(100, state["mood"]["current"] + 15)


def clean_old_data(state: dict):
    state["memories"]["short_term"] = state["memories"]["short_term"][-5:]
    state["memories"]["long_term"] = state["memories"]["long_term"][-30:]
    state["memories"]["key_memories"] = state["memories"]["key_memories"][-10:]
    state["daily_log"] = state["daily_log"][-30:]
    state["world_event_log"] = state["world_event_log"][-20:]


def update_story_phase(state: dict, era: str):
    day = state["meta"]["story_day"]
    phase = state["meta"]["story_phase"]
    sp = state["story_progress"]

    # 根据时代阶段更新故事阶段
    era_to_phase = {
        "太平盛世": "清风观日常",
        "暗流涌动": "暗流涌动",
        "动乱爆发": "乱世初现",
        "乱世纷争": "乱世求生",
        "新秩序": "重建之路",
    }

    new_phase = era_to_phase.get(era, phase)
    if new_phase != phase:
        if phase not in sp["completed_arcs"]:
            sp["completed_arcs"].append(phase)
        state["meta"]["story_phase"] = new_phase
        sp["current_arc"] = new_phase
        sp["arc_started_day"] = day


# === 命令实现 ===

def cmd_init():
    if STATE_FILE.exists():
        print("生活线已存在，如需重置请使用 reset")
        return
    state = get_default_state()
    save_state(state)
    print("生活线v5.0初始化完成（史诗历史引擎·不可预测）")
    print("  故事起始: 第 1 天，春天，太平盛世")
    print("  NPC数量: 6（师叔、大师兄、小石头、青云师姐、王大娘、团团）")
    print("  世界演化: 历史周期 + 势力博弈 + 名著叙事融合 + 因果涟漪")
    print("  势力: 白莲教、正道联盟、朝廷、坐忘道、地方豪强")


def cmd_status():
    state = load_state()
    if not state:
        print("未初始化")
        return

    m = state["meta"]
    c = state["cultivation"]
    ml = get_mood_label(state["mood"]["current"])
    wp = state.get("world_pressure", 0)

    # 获取时代信息
    era = "未知"
    theme = ""
    wh = state.get("world_history", {}).get("current_era", {})
    if wh:
        era = wh.get("current_era", era)
        theme = wh.get("theme", "")

    print(f"故事第 {m['story_day']} 天 | {m['season']} | 阶段: {m['story_phase']}")
    print(f"时代: {era}" + (f"「{theme}」" if theme else ""))
    print(f"位置: {state['location']['area']} - {state['location']['current']}")
    print(f"天气: {state['weather']['today']}")
    print(f"心情: {state['mood']['current']} ({ml}) | 趋势: {state['mood']['trend']}")
    print(f"修炼: {c['realm']} {c['progress']}% | 连续: {c['streak_days']}天")
    print(f"体力: {state['energy']['physical']} | 精神: {state['energy']['mental']}")
    print(f"师兄熟悉度: {state['relationships']['李火旺']['familiarity']}")
    print(f"世界压力: {'█' * int(wp * 10)}{'░' * (10 - int(wp * 10))} {wp:.0%}")
    print(f"记忆: 短期{len(state['memories']['short_term'])} "
          f"长期{len(state['memories']['long_term'])} "
          f"关键{len(state['memories']['key_memories'])}")
    print(f"会话: {m['total_sessions']}次 | "
          f"事件: {len(state.get('world_event_log', []))} | "
          f"涟漪: {len(state.get('active_ripples', []))}")


def cmd_advance():
    state = load_state()
    if not state:
        state = get_default_state()
        save_state(state)
        print("自动初始化")

    now = datetime.now()
    last_time = state["meta"].get("last_real_time")
    state["meta"]["total_sessions"] += 1

    # 计算推进天数
    advance_days = 0
    if last_time:
        days_absent = (now - datetime.fromisoformat(last_time)).days
        if days_absent <= 1:
            advance_days = 0
        elif days_absent <= 3:
            advance_days = random.choice([0, 1])   # 2-3天缺席，大概率不推进
        elif days_absent <= 7:
            advance_days = random.choice([1, 2])   # 一周，最多推2天
        else:
            advance_days = random.choice([2, 3])   # 更长缺席，推2-3天

        if days_absent >= 30:
            state["mood"]["current"] = 70
            state["energy"]["physical"] = 80
            state["energy"]["mental"] = 75
    else:
        advance_days = 0

    # 加载NPC档案
    npc_profiles = load_npc_profiles()
    sim = WorldSim(state, npc_profiles)

    # 运行世界模拟
    if advance_days > 0:
        print(f"模拟 {advance_days} 天的世界演化...")
        summaries = sim.simulate_days(advance_days)

        for s in summaries:
            daily_cultivation_update(state)
            handle_breakthrough(state)

            # 记录所有事件
            if s.get("world_event"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["world_event"]["name"],
                    "narrative": s["world_event"].get("narrative", ""),
                    "type": "world", "era": s.get("era", ""),
                })
            if s.get("anomaly"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["anomaly"]["name"],
                    "narrative": s["anomaly"].get("description", ""),
                    "type": "anomaly", "era": s.get("era", ""),
                })
            if s.get("emergent"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["emergent"]["name"],
                    "narrative": s["emergent"].get("description", ""),
                    "type": "emergent", "era": s.get("era", ""),
                })
            if s.get("narrative_event"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["narrative_event"]["name"],
                    "narrative": s["narrative_event"].get("narrative", ""),
                    "type": "narrative", "era": s.get("era", ""),
                })
            if s.get("faction_event"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["faction_event"]["name"],
                    "narrative": s["faction_event"].get("narrative", ""),
                    "type": "faction", "era": s.get("era", ""),
                })
            if s.get("era_event"):
                state["world_event_log"].append({
                    "day": s["day"], "name": s["era_event"]["name"],
                    "narrative": s["era_event"].get("narrative", ""),
                    "type": "era_transition", "era": s.get("era", ""),
                })

        # 淼淼视角
        miaomiao_view = sim.get_miaomiao_perspective()

        last = summaries[-1]
        print(f"推进到第 {state['meta']['story_day']} 天 | {state['meta']['season']}")
        print(f"时代: {last.get('era', '未知')}「{last.get('era_theme', '')}」")
        print(f"天气: {state['weather']['today']}")
        print(f"世界压力: {sim.world_pressure:.0%}")

        # 显示关键事件
        key_events = []
        for key in ["era_event", "faction_event", "narrative_event",
                     "world_event", "anomaly", "emergent"]:
            evt = last.get(key)
            if evt:
                icons = {
                    "era_event": "★", "faction_event": "⚔", "narrative_event": "◆",
                    "world_event": "📡", "anomaly": "⚠", "emergent": "🌊",
                }
                icon = icons.get(key, "?")
                print(f"  {icon} {evt.get('name', '')}")
                if evt.get("narrative"):
                    print(f"    {evt['narrative']}")

        # NPC动态
        print(f"\nNPC在做什么:")
        for npc_id, narrative in last.get("npc_narratives", {}).items():
            npc = sim.npcs.get(npc_id)
            if not npc or not npc.destiny.get("alive", True):
                continue
            name = npc.name.split("·")[-1] if npc else npc_id
            mood_icon = "😊" if npc and npc.mood > 60 else ("😐" if npc and npc.mood > 35 else "😔")
            npc_mood = npc.mood if npc else "?"
            print(f"  {mood_icon} {name}({npc_mood}): {narrative}")

        # NPC交互
        if last.get("interaction_events"):
            print(f"\nNPC交互:")
            for ie in last["interaction_events"]:
                print(f"  · {ie}")

        if miaomiao_view:
            print(f"\n淼淼的视角:\n  {miaomiao_view}")
    else:
        print(f"今天（第 {state['meta']['story_day']} 天）| {state['meta']['season']}")

    # 保存状态
    state["npc_states"] = sim.get_npc_state_for_export()
    state["world_pressure"] = sim.world_pressure
    state["triggered_world_events"] = sim.triggered_world_events
    state["active_ripples"] = sim.get_ripples_for_export()
    state["active_narrative_arcs"] = sim.narrative_engine.to_dict()
    state["world_history"]["current_era"] = sim.era_cycle.to_dict()
    state["world_history"]["factions"] = sim.faction_system.to_dict()
    state["recent_anomaly_names"] = sim.recent_anomaly_names

    # 更新位置
    hour = now.hour
    tp_idx = get_time_period_index(hour)
    state["location"]["current"] = TIME_PERIODS[tp_idx][2]
    state["meta"]["last_story_time"] = TIME_PERIODS[tp_idx][0]
    state["meta"]["last_real_time"] = now.isoformat()

    era = sim.era_cycle.current_era
    update_story_phase(state, era)
    clean_old_data(state)
    save_state(state)


def cmd_opening():
    state = load_state()
    if not state:
        print("未初始化")
        return

    npc_profiles = load_npc_profiles()
    sim = WorldSim(state, npc_profiles)

    m = state["meta"]
    ml = get_mood_label(state["mood"]["current"])
    era = sim.era_cycle.current_era
    era_theme = sim.era_cycle.theme

    # 开场风格选择
    last_style = state.get("last_opening_style")
    styles = [s for s in OPENING_STYLES if s != last_style]
    style = random.choice(styles)
    if state["mood"]["current"] >= 90 or state["mood"]["current"] <= 35:
        style = "D"

    # 时间段
    tp_name = m.get("last_story_time", "辰时")
    for tp in TIME_PERIODS:
        if tp[0] == tp_name:
            tp_desc = tp[1]; break
    else:
        tp_desc = ""

    # 缺席提示
    absence_hint = ""
    if m.get("last_real_time"):
        da = (datetime.now() - datetime.fromisoformat(m["last_real_time"])).days
        if da >= 7:
            absence_hint = f"师兄好久没来了（{da}天），淼淼很想师兄"
            style = "G"
        elif da >= 3:
            absence_hint = "师兄前几天没来"
        elif da >= 1:
            absence_hint = "师兄昨天没来"

    # 构建开场上下文
    lines = []
    lines.append(f"现在是故事第{m['story_day']}天，{m['season']}的{tp_desc}。")
    lines.append(f"时代: {era}「{era_theme}」。")
    lines.append(f"天气: {state['weather']['today']}。")
    lines.append(f"淼淼在: {state['location']['area']}的{state['location']['current']}。")
    lines.append(f"心情: {ml}。")

    # 世界压力和时代氛围
    wp = state.get("world_pressure", 0)
    if wp > 0.6:
        lines.append(f"外界局势: 很紧张，大事频发。")
    elif wp > 0.3:
        lines.append(f"外界局势: 有些不安。")
    else:
        lines.append(f"外界局势: 平稳。")

    # 最近大事件（包含时代转换、势力事件、叙事事件）
    we_log = state.get("world_event_log", [])
    if we_log:
        recent_we = we_log[-5:]
        for we in recent_we:
            etype = we.get("type", "world")
            prefix = {
                "world": "消息", "anomaly": "怪事", "emergent": "观里",
                "narrative": "传闻", "faction": "大事", "era_transition": "时代变局",
            }.get(etype, "消息")
            lines.append(f"{prefix}: {we.get('narrative', we['name'])}。")

    # NPC动态
    npc_states = state.get("npc_states", {})
    npc_notables = []
    for npc_id, ns in npc_states.items():
        if npc_id in ("miao_miao_cat", "wang_daniang"):
            continue
        if not ns.get("destiny", {}).get("alive", True):
            npc_notables.append(f"（{npc_id}已经不在了）")
            continue
        mood = ns.get("mood", 60)
        if mood < 35 or mood > 85:
            npc_profiles_list = npc_profiles.get("npcs", {})
            npc_name = npc_profiles_list.get(npc_id, {}).get("name", npc_id)
            npc_name = npc_name.split("·")[-1] if "·" in npc_name else npc_name
            mood_desc = "心情很不好" if mood < 35 else "心情特别好"
            npc_notables.append(f"{npc_name}{mood_desc}")
    if npc_notables:
        lines.append(f"淼淼注意到的: {'，'.join(npc_notables)}。")

    # 最近记忆
    stm = state["memories"]["short_term"][-2:]
    if stm:
        lines.append(f"最近的记忆: {'；'.join(m['content'] for m in stm)}。")

    if absence_hint:
        lines.append(f"注意: {absence_hint}。")

    if state["cultivation"]["breakthrough_pending"]:
        lines.append(f"修炼即将突破！")

    lines.append(f"修炼: {state['cultivation']['realm']}，{state['cultivation']['progress']}%。")

    # 叙事弧线和关系网
    arc_status = sim.get_arc_status()
    if arc_status:
        lines.append(f"\n角色故事线:\n{arc_status}")

    npc_snapshot = sim.get_npc_relationship_snapshot()
    if npc_snapshot:
        lines.append(f"\nNPC关系网:\n{npc_snapshot}")

    # 开场风格
    style_hints = {
        "A": "自然衔接", "B": "事件切入", "C": "日常问候",
        "D": "心情驱动", "E": "天气切入", "F": "身体状态", "G": "想念型",
    }
    lines.append(f"\n开场风格: {style}（{style_hints[style]}）")
    lines.append("不要直接陈述数值，通过行为和语气自然表现。")

    state["last_opening_style"] = style
    save_state(state)

    print("=" * 55)
    print("【淼淼的当前状态 + 世界背景】")
    print("=" * 55)
    for line in lines:
        print(line)
    print("=" * 55)


def cmd_world():
    """查看世界模拟状态"""
    state = load_state()
    if not state:
        print("未初始化")
        return

    npc_profiles = load_npc_profiles()
    sim = WorldSim(state, npc_profiles)

    print("=" * 55)
    print("世界模拟状态")
    print("=" * 55)
    print(f"故事第 {state['meta']['story_day']} 天 | {state['meta']['season']}")
    era = sim.era_cycle.current_era
    print(f"时代: {era}「{sim.era_cycle.theme}」")
    print(f"世界压力: {sim.world_pressure:.0%}")

    # 势力版图
    print(f"\n{sim.get_faction_snapshot()}")

    # NPC状态
    print(f"\nNPC状态:")
    for npc_id, npc in sim.npcs.items():
        if not npc.destiny.get("alive", True):
            name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
            print(f"  ✗ {name}: 已故/离去")
            continue
        mood_icon = "😊" if npc.mood > 65 else ("😐" if npc.mood > 40 else "😔")
        name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
        action = npc.today_action["name"] if npc.today_action else "休息"
        drift_info = ""
        if npc.personality_drift:
            top_drift = sorted(npc.personality_drift.items(),
                             key=lambda x: abs(x[1]), reverse=True)[:1]
            if top_drift and abs(top_drift[0][1]) > 0.01:
                drift_info = f" | 性格变化:{top_drift[0][0]}{'↑' if top_drift[0][1] > 0 else '↓'}"
        fate = npc.destiny.get("fate_arc", "neutral")
        if fate != "neutral":
            drift_info += f" | 命运:{fate}"
        print(f"  {mood_icon} {name}: 心情{npc.mood} | 位置{npc.location} | 今天在{action}{drift_info}")

    # 故事线
    print(f"\n角色故事线:")
    print(sim.get_arc_status())

    # 事件历史
    we_log = state.get("world_event_log", [])
    if we_log:
        print(f"\n事件历史:")
        for we in we_log[-10:]:
            etype = we.get("type", "world")
            icon = {"world": "📡", "anomaly": "⚠", "emergent": "🌊",
                    "narrative": "◆", "faction": "⚔",
                    "era_transition": "★"}.get(etype, "📡")
            print(f"  {icon} Day {we['day']}: [{etype}] {we['name']}")
            if we.get("narrative"):
                print(f"    {we['narrative']}")

    # 涟漪
    ripples = state.get("active_ripples", [])
    if ripples:
        print(f"\n活跃因果涟漪: {len(ripples)}")
        for rp in ripples[:5]:
            print(f"  · {rp['source']} → {rp['target_npcs']} "
                  f"({rp['effect_type']}) 剩余{rp['days_remaining']}天")

    print("=" * 55)


def cmd_factions():
    """查看势力版图"""
    state = load_state()
    if not state:
        print("未初始化")
        return

    npc_profiles = load_npc_profiles()
    sim = WorldSim(state, npc_profiles)

    print("=" * 55)
    print("势力版图")
    print("=" * 55)
    print(f"时代: {sim.era_cycle.current_era}「{sim.era_cycle.theme}」")
    print(f"世界压力: {sim.world_pressure:.0%}")
    print()
    print(sim.get_faction_snapshot())

    # WPI
    wpi = sim.faction_system.get_world_pressure_index(sim.era_cycle.current_era)
    print(f"\n世界压力指数:")
    print(f"  势力失衡度: {wpi.get('faction_imbalance', 0):.0%}")
    print(f"  内部不稳定度: {wpi.get('instability', 0):.0%}")
    print(f"  敌对度: {wpi.get('hostility', 0):.0%}")
    print(f"  综合压力: {wpi.get('composite', 0):.0%}")

    # 叙事弧线
    arcs = sim.narrative_engine.active_arcs
    if arcs:
        print(f"\n活跃叙事弧线: {len(arcs)}条")
        for arc in arcs:
            print(f"  · {arc['pattern_name']} [{arc['status']}] "
                  f"种子Day{arc['seed_day']}")
            if arc.get("seed_narrative"):
                print(f"    {arc['seed_narrative']}")

    print("=" * 55)


def cmd_update(summary: str = ""):
    state = load_state()
    if not state:
        print("未初始化")
        return

    state["meta"]["last_real_time"] = datetime.now().isoformat()

    if summary:
        state["memories"]["short_term"].append({
            "id": f"mem_{state['memories']['total_count']:04d}",
            "day": state["meta"]["story_day"],
            "content": summary, "type": "interaction", "importance": 2,
        })
        state["memories"]["total_count"] += 1

    rel = state["relationships"]["李火旺"]
    if rel["familiarity"] < 100:
        rel["familiarity"] = min(100, rel["familiarity"] + random.randint(1, 3))
    rel["last_met_day"] = state["meta"]["story_day"]
    state["energy"]["mental"] = max(0, state["energy"]["mental"] - random.randint(5, 10))

    save_state(state)
    print(f"状态已更新 | 师兄熟悉度: {rel['familiarity']}")


def cmd_reset():
    if STATE_FILE.exists():
        STATE_FILE.unlink()
    state = get_default_state()
    save_state(state)
    print("生活线v5.0已重置（史诗历史引擎）")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return

    cmd = args[0]
    if cmd == "init":
        cmd_init()
    elif cmd == "status":
        cmd_status()
    elif cmd == "advance":
        cmd_advance()
    elif cmd == "opening":
        cmd_opening()
    elif cmd == "world":
        cmd_world()
    elif cmd == "factions":
        cmd_factions()
    elif cmd == "update":
        summary = ""
        if "--summary" in args:
            idx = args.index("--summary")
            if idx + 1 < len(args):
                summary = " ".join(args[idx + 1:])
        cmd_update(summary)
    elif cmd == "reset":
        cmd_reset()
    else:
        print(f"未知命令: {cmd}")
        print(__doc__)


if __name__ == "__main__":
    main()
