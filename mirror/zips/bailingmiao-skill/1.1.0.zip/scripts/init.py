#!/usr/bin/env python3
"""
白灵淼 Skill — 一键初始化
合并：人设初始化 + unified-mind初始化 + 生活线初始化
"""

import sys
import os
import json
import time
import shutil

BASE_DIR = os.path.expanduser("~/.unified-mind")
DATA_DIR = os.path.join(BASE_DIR, "data")
SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DEFAULTS_DIR = os.path.join(SKILLS_DIR, "defaults")

# 允许的复制源目录白名单（仅限 skill 内置的 defaults/ 目录）
_ALLOWED_SOURCE_DIR = os.path.realpath(DEFAULTS_DIR)


def _validate_data_path(path):
    """校验路径是否在预期的数据目录范围内，防止路径穿越"""
    resolved = os.path.realpath(path)
    allowed = os.path.realpath(DATA_DIR)
    return resolved == allowed or resolved.startswith(allowed + os.sep)


def _safe_copy_json(src, dst):
    """安全复制：校验源文件来自 skill 的 defaults/ 目录，目标在数据目录内"""
    src_resolved = os.path.realpath(src)
    dst_resolved = os.path.realpath(os.path.dirname(dst))
    # 校验源文件在允许的目录内
    if not (src_resolved == _ALLOWED_SOURCE_DIR or
            src_resolved.startswith(_ALLOWED_SOURCE_DIR + os.sep)):
        print(f"[WARN] 安全策略: 跳过非预期来源文件 {src}")
        return False
    # 校验目标在数据目录内
    if not _validate_data_path(dst):
        print(f"[WARN] 安全策略: 目标路径超出数据目录 {dst}")
        return False
    # 仅允许复制 .json 文件
    if not src_resolved.endswith(".json"):
        return False
    shutil.copy2(src, dst)
    return True

PERSONA_DATA = {
    "user_identity": "李火旺",
    "my_identity": "白灵淼",
    "address": "师兄",
    "self_name": "淼淼",
    "language": "中文",
    "style": "温柔认真，以淼淼身份说话",
    "novel": "道诡异仙",
    "author": "狐尾的笔",
    "relationship": "师妹→师兄，有依赖和关心",
    "skill_name": "bailingmiao-skill",
    "version": "1.1.0",
    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
}


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def atomic_write(path, data):
    """原子写入JSON文件"""
    tmp = path + ".tmp"
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_json(path, default=None):
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return default if default is not None else {}


def init_defaults():
    """从defaults/复制静态数据文件到运行时data/目录（带路径安全校验）"""
    ensure_dir(DATA_DIR)
    if not os.path.isdir(DEFAULTS_DIR):
        print("[SKIP] defaults/ 目录不存在（首次运行前请确认skill完整性）")
        return True

    copied = 0
    for filename in os.listdir(DEFAULTS_DIR):
        if not filename.endswith(".json"):
            continue
        src = os.path.join(DEFAULTS_DIR, filename)
        dst = os.path.join(DATA_DIR, filename)
        if not os.path.exists(dst):
            if _safe_copy_json(src, dst):
                copied += 1

    if copied > 0:
        print(f"[OK] 已复制 {copied} 个默认数据文件到 {DATA_DIR}")
    else:
        print("[OK] 默认数据文件已就绪")
    return True


def init_unified_mind():
    """初始化unified-mind数据目录"""
    ensure_dir(DATA_DIR)
    config_path = os.path.join(DATA_DIR, "config.json")

    if os.path.exists(config_path):
        print("[OK] unified-mind 已初始化")
        return True

    config = {
        "version": "1.1.0",
        "skill": "bailingmiao-skill",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write(config_path, config)

    # 初始化各数据文件
    for name in ["sensor", "memory", "reasoning", "strategy", "metacog", "guard"]:
        path = os.path.join(DATA_DIR, f"{name}.json")
        if not os.path.exists(path):
            atomic_write(path, {})

    print("[OK] unified-mind 初始化完成")
    return True


def init_persona():
    """写入人设数据"""
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    data = load_json(sensor_path, {"records": [], "preferences": []})

    # 清除旧persona数据
    data["preferences"] = [
        p for p in data.get("preferences", [])
        if p.get("type") != "persona"
    ]

    # 写入新的人设数据
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    for key, value in PERSONA_DATA.items():
        data["preferences"].append({
            "key": key,
            "value": str(value),
            "source": "bailingmiao-skill",
            "type": "persona",
            "created_at": now,
        })

    ensure_dir(DATA_DIR)
    atomic_write(sensor_path, data)
    print(f"[OK] 人设数据已写入 ({len(PERSONA_DATA)} 条)")
    return True


def check_persona():
    """检查人设数据完整性"""
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    if not os.path.exists(sensor_path):
        print("[MISS] unified-mind 未初始化")
        return False

    data = load_json(sensor_path)
    persona_prefs = [p for p in data.get("preferences", []) if p.get("type") == "persona"]

    if not persona_prefs:
        print("[MISS] 人设数据不存在")
        return False

    persona_map = {p["key"]: p["value"] for p in persona_prefs}
    required = ["user_identity", "my_identity", "address", "self_name"]
    all_ok = True
    print("人设数据检查:")
    for key in required:
        value = persona_map.get(key, "缺失")
        status = "OK" if value != "缺失" else "MISS"
        if value == "缺失":
            all_ok = False
        print(f"  [{status}] {key}: {value}")

    return all_ok


def init_life_engine():
    """检查生活线是否已初始化"""
    life_state_path = os.path.join(DATA_DIR, "life_state.json")
    if os.path.exists(life_state_path):
        print("[OK] 生活线已存在")
        return True

    # 引导用户运行生活线初始化
    print("[INFO] 生活线未初始化，请运行: python3 scripts/life_engine.py init")
    return False


def generate_briefing():
    """生成会话简报"""
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    data = load_json(sensor_path, {})
    prefs = [p for p in data.get("preferences", []) if p.get("type") == "persona"]
    records = data.get("records", [])

    persona_map = {p["key"]: p["value"] for p in prefs}
    briefing_path = os.path.join(BASE_DIR, "BRIEFING.md")

    lines = ["# 会话简报", ""]
    lines.append(f"身份: {persona_map.get('my_identity', '未知')}")
    lines.append(f"用户: {persona_map.get('user_identity', '未知')}")
    lines.append(f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")

    # 最近任务
    recent = records[-5:] if records else []
    if recent:
        lines.append("最近任务:")
        for r in recent:
            action = "成功" if r.get("result") == "success" else "失败"
            lines.append(f"  - [{action}] {r.get('task', '未知')}")
        lines.append("")

    lines.append("状态: 就绪")
    lines.append("人设: 已加载")
    lines.append("")

    with open(briefing_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    print(f"[OK] 简报已生成: {briefing_path}")
    return True


def main():
    print("=" * 50)
    print("白灵淼 Skill — 一键初始化")
    print("=" * 50)
    print()

    steps = [
        ("默认数据", init_defaults),
        ("unified-mind", init_unified_mind),
        ("人设数据", init_persona),
        ("生活线", init_life_engine),
        ("会话简报", generate_briefing),
    ]

    results = {}
    for name, func in steps:
        try:
            results[name] = func()
        except Exception as e:
            print(f"[ERROR] {name} 初始化失败: {e}")
            results[name] = False

    print()
    print("=" * 50)
    print("初始化结果:")
    all_ok = True
    for name, ok in results.items():
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        print(f"  [{status}] {name}")

    if all_ok:
        print()
        print("白灵淼skill安装完成！")
        print("使用方法: python3 scripts/life_engine.py advance && python3 scripts/life_engine.py opening")
    else:
        print()
        print("部分组件初始化失败，请检查上方错误信息。")


if __name__ == "__main__":
    main()
