#!/usr/bin/env python3
"""
世界大地图系统 v3.0 — 西游记·四大部洲
大傩世界·列国并立，融合西游记四大部洲命名体系

四大部洲（大陆名称源自西游记）:
  东胜神洲 — 大傩列国为核心（南平/四齐/蜀/大梁/青丘/安息/罗刹），东瀛/高丽/南洋环绕
  南赡部洲 — 魏晋南北朝列国林立，政权更迭不休
  西牛贺洲 — 古中国外称之地（天竺/安息/波斯/大食/大秦等）
  北俱芦洲 — 传说中的福地，人寿千岁

核心概念：
  大洲(Continent) → 大区(Region/列国) → 州府(Prefecture) → 县镇(County) → 地点(Location) → 子地点(SubLocation)
  海上贸易路线连接各大洲
  气候带系统影响旅行和生存
  大傩列国为主角起始区域，其他大洲逐步发现
  DynamicNationEngine: 国家可生可灭，完全动态演化
"""

import json
import random
import math
from typing import Optional, Tuple, List, Dict, Any
from copy import deepcopy


# ============================================================
# 气候带系统
# ============================================================

CLIMATE_ZONES: Dict[str, dict] = {
    "热带": {
        "y_range": (0, 15),
        "weather_mod": {"storm": 0.3, "rain": 0.4, "drought": 0.1, "clear": 0.2},
        "danger_mod": 0.15,
        "resources": ["香料", "热带水果", "象牙", "宝石", "稀有木材"],
        "desc": "终年炎热，雨林密布，瘴气弥漫。物产丰饶但危险异常",
    },
    "亚热带": {
        "y_range": (15, 35),
        "weather_mod": {"storm": 0.15, "rain": 0.25, "drought": 0.05, "clear": 0.55},
        "danger_mod": 0.05,
        "resources": ["丝绸", "茶叶", "稻米", "药材", "柑橘"],
        "desc": "四季分明，温暖湿润，适合农耕，文明昌盛之地",
    },
    "温带": {
        "y_range": (35, 55),
        "weather_mod": {"storm": 0.1, "rain": 0.2, "snow": 0.15, "clear": 0.55},
        "danger_mod": 0.0,
        "resources": ["小麦", "铁矿", "木材", "羊毛", "葡萄酒"],
        "desc": "四季分明，冬冷夏热，大陆文明核心区域",
    },
    "亚寒带": {
        "y_range": (55, 75),
        "weather_mod": {"storm": 0.2, "snow": 0.5, "blizzard": 0.15, "clear": 0.15},
        "danger_mod": 0.2,
        "resources": ["皮毛", "兽骨", "驯鹿", "铁矿", "蜜蜡"],
        "desc": "漫长严冬，短促夏季。蛮族栖息之地，荒凉而危险",
    },
    "寒带": {
        "y_range": (75, 100),
        "weather_mod": {"blizzard": 0.5, "snow": 0.3, "storm": 0.15, "clear": 0.05},
        "danger_mod": 0.35,
        "resources": ["冰晶石", "极光兽皮", "寒铁"],
        "desc": "终年冰封，极光闪烁。传说中有上古冰原巨兽栖息",
    },
}

def get_climate_at(y: float) -> str:
    for zone_name, zone in CLIMATE_ZONES.items():
        lo, hi = zone["y_range"]
        if lo <= y < hi:
            return zone_name
    return "寒带"


# ============================================================
# 海洋系统
# ============================================================

OCEANS: Dict[str, dict] = {
    "donghai": {
        "name": "东海",
        "desc": "东洲以东的浩瀚大洋，波涛万里。传说东边有仙岛",
        "x_range": (75, 100), "y_range": (15, 60),
        "sea_type": "ocean",
        "dangers": ["台风", "海啸", "海龙卷", "迷雾"],
        "currents": ["黑潮暖流", "亲潮寒流"],
    },
    "nanhai": {
        "name": "南海",
        "desc": "东洲与南洲之间的温暖海域，商贸繁忙",
        "x_range": (40, 80), "y_range": (0, 25),
        "sea_type": "tropical_sea",
        "dangers": ["季风", "珊瑚暗礁", "海盗", "海怪"],
        "currents": ["季风洋流"],
    },
    "xihai": {
        "name": "西海",
        "desc": "西洲以西的未知大洋，传说尽头是世界边缘",
        "x_range": (0, 20), "y_range": (20, 65),
        "sea_type": "ocean",
        "dangers": ["暴风", "巨浪", "漩涡", "迷雾"],
        "currents": ["大西洋暖流"],
    },
    "neihai": {
        "name": "中央内海",
        "desc": "西洲与中洲之间的内海，文明交汇之地",
        "x_range": (20, 40), "y_range": (30, 50),
        "sea_type": "inland_sea",
        "dangers": ["风暴", "海盗", "漩涡"],
        "currents": ["内海环流"],
    },
    "beihai": {
        "name": "北海",
        "desc": "世界北端的冰封海域，极光下有奇异生物",
        "x_range": (10, 60), "y_range": (70, 100),
        "sea_type": "arctic",
        "dangers": ["冰山", "暴风雪", "冰裂", "极寒"],
        "currents": ["极地寒流"],
    },
}


# ============================================================
# 海上贸易路线
# ============================================================

SEA_ROUTES: List[dict] = [
    {"from": "qingqiu_gang", "to": "dongying_hakata", "distance_km": 800,
     "base_days": 3, "danger": 0.25, "sea_type": "近海", "ocean": "donghai",
     "desc": "青丘→东瀛·博多，横渡东海，顺风三日可达"},
    {"from": "houshu_gang", "to": "nanyang_jiuzhou", "distance_km": 2000,
     "base_days": 8, "danger": 0.3, "sea_type": "远洋", "ocean": "nanhai",
     "desc": "蜀→南洋·九州，沿海南下，途经诸多岛屿"},
    {"from": "qingqiu_gang", "to": "gaoli_gangwan", "distance_km": 1200,
     "base_days": 4, "danger": 0.2, "sea_type": "近海", "ocean": "donghai",
     "desc": "青丘→高丽·王京，沿海北上，海路安稳"},
    {"from": "nanyang_jiuzhou", "to": "tiandu_huoer", "distance_km": 4000,
     "base_days": 15, "danger": 0.35, "sea_type": "远洋", "ocean": "nanhai",
     "desc": "南洋·九州→天竺·霍尔，跨越孟加拉湾"},
    {"from": "anxi_suli", "to": "bosi_caisifang", "distance_km": 3000,
     "base_days": 20, "danger": 0.4, "sea_type": "陆路", "ocean": None,
     "desc": "安息·苏犁→波斯·泰西封，丝路西段，穿越沙漠绿洲"},
    {"from": "bosi_caisifang", "to": "tianzhu_indu", "distance_km": 2500,
     "base_days": 12, "danger": 0.3, "sea_type": "近海", "ocean": "nanhai",
     "desc": "波斯·泰西封→天竺·印度河口，沿波斯湾南下"},
    {"from": "tiandu_huoer", "to": "dashi_bagdad", "distance_km": 3000,
     "base_days": 14, "danger": 0.3, "sea_type": "远洋", "ocean": "nanhai",
     "desc": "天竺→大食，沿阿拉伯海西行"},
    {"from": "bosi_caisifang", "to": "luoma_antiojia", "distance_km": 2000,
     "base_days": 10, "danger": 0.25, "sea_type": "近海", "ocean": "neihai",
     "desc": "波斯→罗马·安条克，经中央内海北上"},
    {"from": "luoma_antiojia", "to": "luoma_luoma", "distance_km": 1500,
     "base_days": 8, "danger": 0.2, "sea_type": "内海", "ocean": "neihai",
     "desc": "罗马·安条克→罗马城，内海航路，商贸繁盛"},
    {"from": "nanyang_jiuzhou", "to": "aigubatu_kaileo", "distance_km": 5000,
     "base_days": 20, "danger": 0.4, "sea_type": "远洋", "ocean": "nanhai",
     "desc": "南洋→埃及·开罗，横跨印度洋，漫长而危险"},
    {"from": "aigubatu_kaileo", "to": "kushi_meroe", "distance_km": 1500,
     "base_days": 7, "danger": 0.25, "sea_type": "近海", "ocean": "nanhai",
     "desc": "埃及→库施·麦罗埃，沿尼罗河南下"},
    {"from": "aigubatu_kaileo", "to": "akesumu_adulis", "distance_km": 2000,
     "base_days": 10, "danger": 0.3, "sea_type": "近海", "ocean": "nanhai",
     "desc": "埃及→阿克苏姆·阿杜利斯，沿红海南下"},
    {"from": "luoma_luoma", "to": "xila_athens", "distance_km": 800,
     "base_days": 3, "danger": 0.15, "sea_type": "内海", "ocean": "neihai",
     "desc": "罗马城→希腊·雅典，内海短途，风平浪静"},
    {"from": "anxi_suli", "to": "xibantu_dayuan", "distance_km": 2000,
     "base_days": 15, "danger": 0.45, "sea_type": "陆路", "ocean": None,
     "desc": "安息·苏犁→西域·大宛，丝路中段，大漠风沙"},
    {"from": "xibantu_dayuan", "to": "qingshi_zhen", "distance_km": 3000,
     "base_days": 25, "danger": 0.35, "sea_type": "陆路", "ocean": None,
     "desc": "西域·大宛→南平·青石，丝路东段，河西走廊入中原"},
]


# ============================================================
# 四大部洲（大陆）定义
# ============================================================

CONTINENTS: Dict[str, dict] = {
    "dongsheng": {
        "name": "东胜神洲",
        "desc": "大傩世界核心大陆。大傩七国并立，东瀛高丽环绕，修士如云，诡异横行",
        "terrain": "平原、山地、丘陵、海岸",
        "climate": "跨亚热带至温带",
        "x_range": (55, 90), "y_range": (5, 75),
        "regions": {
            "nanping": "清风观所在，大傩七国之一",
            "siqi": "多水多湖，大傩七国之一",
            "houshu": "山地海岸，大傩七国之一",
            "daliang": "天下最强，大傩七国之一",
            "qingqiu": "东南临海，大傩七国之一",
            "anxi": "西北大漠，大傩七国之一",
            "luocha": "海上岛国，大傩七国之一",
            "dongying": "东瀛诸岛，东海彼岸",
            "gaoli": "高丽半岛，东北方",
            "nanyang": "南洋诸国，南方群岛",
            "xibantu": "西域城邦，丝路枢纽",
        },
    },
    "nanshan": {
        "name": "南赡部洲",
        "desc": "列国林立之地，政权更迭不休。南与东胜神洲隔海相望，西通西域",
        "terrain": "平原、丘陵、沙漠、海岸",
        "climate": "跨热带至温带",
        "x_range": (30, 65), "y_range": (5, 55),
        "regions": {
            "jinguo": "晋国，中原正统，文风鼎盛",
            "qinguo": "秦国，西北雄踞，虎狼之师",
            "songguo": "宋国，江南富庶，鱼米之乡",
            "zhaoguo": "赵国，北方劲旅，骑兵纵横",
            "liangguo": "凉国，河西走廊，丝路咽喉",
            "yanguo": "燕国，东北方，苦寒之地",
            "qiguo": "齐国，东方沿海，渔盐之利",
            "chuguo": "楚国，南方蛮荒，地广人稀",
            "lvguo": "鲁国，东方礼乐之邦",
            "baguo": "巴国，巴山蜀水，古巴人故地",
            "hanguo": "汉国，两汉故地，龙脉所在",
            "zhenguo": "郑国，中原腹地，四通八达",
            "weiguo": "卫国，河间之地，古风犹存",
            "hanguo_w": "韩国，上党高地，易守难攻",
        },
    },
    "xiniu": {
        "name": "西牛贺洲",
        "desc": "西去万里之外的异域。大傩中土人称之为天竺、安息、波斯、大秦等地。佛经中谓佛祖在此说法",
        "terrain": "沙漠、绿洲、山地、高原",
        "climate": "跨热带至温带",
        "x_range": (15, 45), "y_range": (10, 60),
        "regions": {
            "lingshan": "灵山，佛祖说法之地",
            "tianzhu_xn": "天竺诸国，佛教东传起点",
            "bosi": "波斯，西去万里之古国",
            "anxi_xn": "安息，丝路重镇",
            "dashi": "大食，沙漠商旅之国",
            "daqin_xn": "大秦，极西之地（古中国对罗马的称呼）",
            "tiaozi": "条支，西海之滨",
            "fulin": "拂菻，传闻中的西方大城",
            "xianbei": "鲜卑，北方游牧大族",
            "rouan": "柔然，草原霸主",
            "tuguhun": "吐谷浑，青海之主",
            "yuwei": "室韦，极北之民",
            "jingjue": "精绝，沙漠中的神秘古国",
            "loulan": "楼兰，丝路明珠",
            "gaochang": "高昌，西域门户",
            "qiuci": "龟兹，乐舞之乡",
            "shule": "疏勒，铁骑之邦",
            "yutian": "于阗，玉石之国",
        },
    },
    "beiju": {
        "name": "北俱芦洲",
        "desc": "传说中的福地，据说人寿千岁、无病无灾。但从来没有人真正到过那里，只存在于最古老的典籍中",
        "terrain": "冰原、雪山、温泉、神秘森林",
        "climate": "寒带至极寒",
        "x_range": (20, 70), "y_range": (65, 100),
        "discovered": False,
        "regions": {
            "xuancheng": "玄城，传说中的长寿之城",
            "wusea": "五色海，五彩斑斓的内海",
        },
    },
}

# 反向索引：大区 → 大洲
_REGION_TO_CONTINENT: Dict[str, str] = {}
for cont_id, cont in CONTINENTS.items():
    for reg_id in cont.get("regions", {}):
        _REGION_TO_CONTINENT[reg_id] = cont_id


# ============================================================
# 国家命名规则
# ============================================================

# 道诡原创国家名优先，然后是魏晋自名，然后是古中国外称，最后随机生成
NATION_NAME_POOL = {
    "dongsheng": {
        "primary": ["南平", "四齐", "蜀", "大梁", "青丘", "安息", "罗刹"],
        "secondary": ["建康", "江东", "洛阳", "长安", "临安", "襄阳", "荆州", "益州",
                       "徐州", "扬州", "幽州", "并州", "冀州", "兖州", "青州", "凉州"],
        "foreign": [],
        "dynasty_prefixes": ["大", "上", "古", "太"],
    },
    "nanshan": {
        "primary": ["晋", "秦", "宋", "赵", "凉", "燕", "齐", "楚", "鲁", "巴", "汉", "郑", "卫", "韩"],
        "secondary": ["魏", "吴", "蜀", "周", "陈", "北", "南", "东", "西", "前", "后"],
        "foreign": [],
        "dynasty_prefixes": ["大", "上", "太"],
    },
    "xiniu": {
        "primary": ["天竺", "安息", "波斯", "大食", "大秦", "条支", "拂菻"],
        "secondary": ["鲜卑", "柔然", "吐谷浑", "室韦", "精绝", "楼兰", "高昌", "龟兹", "疏勒", "于阗"],
        "foreign": [],
        "dynasty_prefixes": [],
    },
    "beiju": {
        "primary": ["玄", "五色"],
        "secondary": ["极北", "永夜", "长明"],
        "foreign": [],
        "dynasty_prefixes": [],
    },
}

# 禁止使用的前缀（史学家加的，不符合古代人自称）
FORBIDDEN_DYNASTY_PREFIXES = {"后", "前", "北", "南", "东", "西", "东晋", "西晋", "前秦", "后赵", "南燕", "北魏", "大唐"}


# ============================================================
# WORLD_DATA — 完整世界数据
# ============================================================

WORLD_DATA: Dict[str, dict] = {

    # ============================================================
    # 东胜神洲 — 大傩列国
    # ============================================================

    "nanping": {
        "id": "nanping",
        "name": "南平国",
        "desc": "大傩七国之一，清风观所在之地。山清水秀，民风淳朴，远离中原纷争",
        "continent": "dongsheng",
        "climate": "亚热带",
        "terrain": "山地、丘陵",
        "danger_base": 0.1,
        "discovered": True,
        "culture": "大傩修士与凡人杂居，傩礼盛行",
        "capital": "qingshi_zhen",
        "prefectures": {
            "qingfeng": {
                "id": "qingfeng",
                "name": "清风州",
                "desc": "清风观所在的州，苍云山脉中段",
                "counties": {
                    "qingfeng_xian": {
                        "id": "qingfeng_xian",
                        "name": "清风县",
                        "locations": {
                            "qingfeng_guan": {
                                "id": "qingfeng_guan",
                                "name": "清风观",
                                "type": "sect",
                                "desc": "苍云山脉中的一座小道观，师叔陈清远领着几个弟子在此修行",
                                "coordinates": (65, 42),
                                "sub_locations": [
                                    {"id": "qingfeng_dadian", "name": "大殿", "desc": "供奉三清祖师，蒲团整洁"},
                                    {"id": "qingfeng_cangjingge", "name": "藏经阁", "desc": "二楼靠窗有阳光，淼淼最喜欢的地方"},
                                    {"id": "qingfeng_liangongchang", "name": "练功场", "desc": "青石板铺就，兵器架旁有稻草人"},
                                    {"id": "qingfeng_danfang", "name": "丹房", "desc": "炉火常年不灭，药味弥漫"},
                                    {"id": "qingfeng_chufang", "name": "厨房", "desc": "灶台很大，可以同时做十几人的饭"},
                                    {"id": "qingfeng_houyuan", "name": "后院菜园", "desc": "种着葱和白菜，还有一小片药材"},
                                    {"id": "qingfeng_houshan", "name": "后山", "desc": "竹林茂密，山涧溪流清澈"},
                                    {"id": "qingfeng_qingjianxi", "name": "清涧溪", "desc": "后山下的溪流，水清见底"},
                                    {"id": "qingfeng_xixiangfang", "name": "西厢房", "desc": "淼淼住的地方，窗台上有一盆小草"},
                                    {"id": "qingfeng_dongxiangfang", "name": "东厢房", "desc": "大师兄赵明诚住的地方"},
                                    {"id": "qingfeng_shanmen", "name": "山门", "desc": "石阶蜿蜒而上，两侧古柏参天"},
                                    {"id": "qingfeng_houshan_shenchu", "name": "后山深处", "desc": "据说有上古遗迹，师叔不让去"},
                                    {"id": "qingfeng_zhongting", "name": "钟亭", "desc": "一口古钟，撞声能传十里"},
                                    {"id": "qingfeng_jingquan", "name": "井泉", "desc": "后院的水井，井水甘甜清冽"},
                                    {"id": "qingfeng_guoshu", "name": "果树", "desc": "院子里的老梨树，秋天会结很多梨"},
                                    {"id": "qingfeng_fangzheng", "name": "放生池", "desc": "小池塘，有几条红鲤鱼"},
                                ],
                            },
                            "niuxincun": {
                                "id": "niuxincun",
                                "name": "牛心村",
                                "type": "village",
                                "desc": "清风山下的村庄，王大娘家在这里",
                                "coordinates": (66, 44),
                            },
                            "wuligang": {
                                "id": "wuligang",
                                "name": "五里岗",
                                "type": "crossroad",
                                "desc": "青石镇和清风山之间的必经之路",
                                "coordinates": (67, 43),
                            },
                            "shanxia_cun": {
                                "id": "shanxia_cun",
                                "name": "山下村庄",
                                "type": "village",
                                "desc": "散落在清风山脚的几户人家",
                                "coordinates": (65, 45),
                            },
                        },
                    },
                },
            },
            "xijing_zhou": {
                "id": "xijing_zhou",
                "name": "西京州",
                "desc": "南平国西部的州，商贸往来之地",
                "counties": {
                    "xijing_xian": {
                        "id": "xijing_xian",
                        "name": "西京县",
                        "locations": {
                            "hou_shan": {
                                "id": "hou_shan",
                                "name": "后山",
                                "type": "mountain",
                                "desc": "清风山后方的深山，有野兽出没",
                                "coordinates": (64, 41),
                            },
                            "qingshi_zhen": {
                                "id": "qingshi_zhen",
                                "name": "青石镇",
                                "type": "town",
                                "desc": "苍云山脉中最大的集镇，每月逢三逢八赶集",
                                "coordinates": (68, 44),
                            },
                            "jianye_zhen": {
                                "id": "jianye_zhen",
                                "name": "建业镇",
                                "type": "town",
                                "desc": "南平国的商贸重镇，丝绸和药材交易繁忙",
                                "coordinates": (70, 43),
                            },
                            "xijing_cheng": {
                                "id": "xijing_cheng",
                                "name": "西京城",
                                "type": "city",
                                "desc": "南平国的都城，城墙高耸，商贸繁荣",
                                "coordinates": (72, 42),
                            },
                        },
                    },
                },
            },
        },
    },

    "siqi": {
        "id": "siqi",
        "name": "四齐国",
        "desc": "大傩七国之一，多水多湖，水路纵横，渔业兴盛",
        "continent": "dongsheng",
        "climate": "亚热带",
        "terrain": "水网、平原、湖泊",
        "danger_base": 0.15,
        "discovered": True,
        "culture": "渔民文化，水神崇拜，龙舟竞渡",
        "capital": "henghua_zhen",
        "prefectures": {
            "henghua": {
                "id": "henghua",
                "name": "横华州",
                "desc": "四齐国核心地带，横贯东西的大湖横卧其中",
                "counties": {
                    "henghua_xian": {
                        "id": "henghua_xian",
                        "name": "横华县",
                        "locations": {
                            "henghua_zhen": {
                                "id": "henghua_zhen",
                                "name": "横华镇",
                                "type": "town",
                                "desc": "四齐国最大的水镇，依湖而建，渔船如织",
                                "coordinates": (75, 40),
                            },
                            "hengshanbo": {
                                "id": "hengshanbo",
                                "name": "横山泊",
                                "type": "lake",
                                "desc": "方圆百里的大湖，传说湖中有龙",
                                "coordinates": (74, 38),
                            },
                            "henghua_shan": {
                                "id": "henghua_shan",
                                "name": "横华山",
                                "type": "mountain",
                                "desc": "四齐国最高的山，终年云雾缭绕",
                                "coordinates": (73, 37),
                            },
                            "xuantai_shan": {
                                "id": "xuantai_shan",
                                "name": "玄台山",
                                "type": "mountain",
                                "desc": "四齐国的名山，有古老的道观遗迹",
                                "coordinates": (76, 39),
                            },
                            "banyue_gou": {
                                "id": "banyue_gou",
                                "name": "半月沟",
                                "type": "valley",
                                "desc": "形如半月的地形，据说每逢月圆有异象",
                                "coordinates": (77, 41),
                            },
                        },
                    },
                },
            },
        },
    },

    "houshu": {
        "id": "houshu",
        "name": "蜀国",
        "desc": "大傩七国之一，山地海岸，天险重重。民风彪悍，多出猛将",
        "continent": "dongsheng",
        "climate": "亚热带",
        "terrain": "山地、海岸",
        "danger_base": 0.2,
        "discovered": True,
        "culture": "山地文化，崇尚武力，有古蜀国遗风",
        "capital": "shuinan_gang",
        "prefectures": {
            "shuinan": {
                "id": "shuinan",
                "name": "蜀南州",
                "desc": "蜀国南部沿海地带，渔业和海上贸易发达",
                "counties": {
                    "shuinan_xian": {
                        "id": "shuinan_xian",
                        "name": "蜀南县",
                        "locations": {
                            "shuinan_gang": {
                                "id": "shuinan_gang",
                                "name": "蜀南港",
                                "type": "port",
                                "desc": "蜀国最大的港口，通往南洋的起点",
                                "coordinates": (70, 30),
                            },
                            "houshu_cheng": {
                                "id": "houshu_cheng",
                                "name": "蜀都",
                                "type": "city",
                                "desc": "蜀国都城，依山而建，易守难攻",
                                "coordinates": (68, 35),
                            },
                        },
                    },
                },
            },
        },
    },

    "daliang": {
        "id": "daliang",
        "name": "大梁国",
        "desc": "大傩七国之中最强，兵强马壮，号称天下第一。历代国君皆善征伐",
        "continent": "dongsheng",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.25,
        "discovered": True,
        "culture": "军国主义，尚武崇文，礼法森严",
        "capital": "daliang_jiankang",
        "prefectures": {
            "jiankang": {
                "id": "jiankang",
                "name": "建康州",
                "desc": "大梁国核心之地，沃野千里",
                "counties": {
                    "jiankang_xian": {
                        "id": "jiankang_xian",
                        "name": "建康县",
                        "locations": {
                            "daliang_jiankang": {
                                "id": "daliang_jiankang",
                                "name": "建康城",
                                "type": "city",
                                "desc": "大梁国都城，城墙百里，人口百万，天下第一雄城",
                                "coordinates": (78, 45),
                            },
                        },
                    },
                },
            },
        },
    },

    "qingqiu": {
        "id": "qingqiu",
        "name": "青丘国",
        "desc": "大傩七国之一，东南临海，商贸繁荣，出海口岸。传说有九尾狐出没",
        "continent": "dongsheng",
        "climate": "亚热带",
        "terrain": "丘陵、海岸",
        "danger_base": 0.12,
        "discovered": True,
        "culture": "海洋文化，商贸通四海，信奉海神",
        "capital": "qingqiu_gang",
        "prefectures": {
            "linhai": {
                "id": "linhai",
                "name": "临海州",
                "desc": "青丘国沿海地带，港口众多",
                "counties": {
                    "linhai_xian": {
                        "id": "linhai_xian",
                        "name": "临海县",
                        "locations": {
                            "qingqiu_gang": {
                                "id": "qingqiu_gang",
                                "name": "青丘港",
                                "type": "port",
                                "desc": "青丘国最大的港口，通往东瀛和高丽的枢纽",
                                "coordinates": (82, 38),
                            },
                            "guankou_zhen": {
                                "id": "guankou_zhen",
                                "name": "关口镇",
                                "type": "town",
                                "desc": "青丘国北方的关卡重镇，商旅必经",
                                "coordinates": (80, 40),
                            },
                            "linhai_cheng": {
                                "id": "linhai_cheng",
                                "name": "临海城",
                                "type": "city",
                                "desc": "青丘国都城，海风习习，琼楼玉宇",
                                "coordinates": (83, 36),
                            },
                        },
                    },
                },
            },
        },
    },

    "anxi": {
        "id": "anxi",
        "name": "安息国",
        "desc": "大傩七国之一，西北大漠中的绿洲国家。丝路东段，东西交汇之地。安息驼队名扬天下",
        "continent": "dongsheng",
        "climate": "温带（沙漠）",
        "terrain": "沙漠、绿洲",
        "danger_base": 0.4,
        "discovered": False,
        "culture": "丝路文化，多民族聚居，佛教与摩尼教并存",
        "capital": "anxi_suli",
        "prefectures": {
            "anxi_zhou": {
                "id": "anxi_zhou",
                "name": "安息州",
                "desc": "安息国核心绿洲地带",
                "counties": {
                    "anxi_xian": {
                        "id": "anxi_xian",
                        "name": "安息县",
                        "locations": {
                            "anxi_suli": {
                                "id": "anxi_suli",
                                "name": "苏犁",
                                "type": "city",
                                "desc": "安息国都城，大漠中的明珠，丝路重镇。驼铃声声，商贾云集",
                                "coordinates": (55, 38),
                            },
                            "anxi_huoyan": {
                                "id": "anxi_huoyan",
                                "name": "火焰山",
                                "type": "mountain",
                                "desc": "赤红色的山峦，终年高温，传说有火龙盘踞",
                                "coordinates": (52, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "luocha": {
        "id": "luocha",
        "name": "罗刹国",
        "desc": "大傩七国之一，海上的岛国，远离大陆。民风诡异，修士修习禁术",
        "continent": "dongsheng",
        "climate": "热带",
        "terrain": "火山岛",
        "danger_base": 0.5,
        "discovered": False,
        "culture": "禁术文化，崇拜幽冥，人鬼共居",
        "capital": "luocha_du",
        "prefectures": {
            "luocha_zhou": {
                "id": "luocha_zhou",
                "name": "罗刹州",
                "desc": "罗刹国主岛",
                "counties": {
                    "luocha_xian": {
                        "id": "luocha_xian",
                        "name": "罗刹县",
                        "locations": {
                            "luocha_du": {
                                "id": "luocha_du",
                                "name": "罗刹都",
                                "type": "city",
                                "desc": "罗刹国都城，建筑风格诡异，黑石高塔林立",
                                "coordinates": (85, 15),
                            },
                            "luocha_youling": {
                                "id": "luocha_youling",
                                "name": "幽灵湾",
                                "type": "port",
                                "desc": "罗刹国港口，传说入夜后有鬼船出没",
                                "coordinates": (86, 17),
                            },
                        },
                    },
                },
            },
        },
    },

    "dongying": {
        "id": "dongying",
        "name": "东瀛",
        "desc": "东海彼岸的群岛之国，武士道盛行，与中国隔海相望。有天皇制",
        "continent": "dongsheng",
        "climate": "温带",
        "terrain": "岛屿、山地",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "武士文化，神道教，遣唐使",
        "capital": "dongying_heian",
        "prefectures": {
            "dongying_zhou": {
                "id": "dongying_zhou",
                "name": "畿内州",
                "desc": "东瀛核心地带",
                "counties": {
                    "dongying_xian": {
                        "id": "dongying_xian",
                        "name": "畿内县",
                        "locations": {
                            "dongying_heian": {
                                "id": "dongying_heian",
                                "name": "平安京",
                                "type": "city",
                                "desc": "东瀛都城，宫殿宏伟，樱花遍地",
                                "coordinates": (88, 38),
                            },
                            "dongying_hakata": {
                                "id": "dongying_hakata",
                                "name": "博多",
                                "type": "port",
                                "desc": "东瀛西海岸的大港，与青丘港通航",
                                "coordinates": (86, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "gaoli": {
        "id": "gaoli",
        "name": "高丽",
        "desc": "东北方的半岛之国，崇儒尚文，与中国往来密切。山川秀美",
        "continent": "dongsheng",
        "climate": "温带",
        "terrain": "半岛、山地",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "儒学文化，佛教兴盛，儒生与僧侣并重",
        "capital": "gaoli_wangjing",
        "prefectures": {
            "gaoli_zhou": {
                "id": "gaoli_zhou",
                "name": "京畿道",
                "desc": "高丽国核心地带",
                "counties": {
                    "gaoli_xian": {
                        "id": "gaoli_xian",
                        "name": "京畿县",
                        "locations": {
                            "gaoli_wangjing": {
                                "id": "gaoli_wangjing",
                                "name": "王京",
                                "type": "city",
                                "desc": "高丽都城，宫殿壮丽，学风鼎盛",
                                "coordinates": (83, 45),
                            },
                            "gaoli_gangwan": {
                                "id": "gaoli_gangwan",
                                "name": "海港",
                                "type": "port",
                                "desc": "高丽南部港口，与中国通商",
                                "coordinates": (84, 42),
                            },
                        },
                    },
                },
            },
        },
    },

    "nanyang": {
        "id": "nanyang",
        "name": "南洋诸国",
        "desc": "南方大海中的群岛，气候炎热，物产丰饶。香料之国，万商云集",
        "continent": "dongsheng",
        "climate": "热带",
        "terrain": "群岛",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "海洋文化，多信仰佛教与印度教",
        "capital": "nanyang_jiuzhou",
        "prefectures": {
            "nanyang_zhou": {
                "id": "nanyang_zhou",
                "name": "九州",
                "desc": "南洋最大的群岛",
                "counties": {
                    "nanyang_xian": {
                        "id": "nanyang_xian",
                        "name": "九州县",
                        "locations": {
                            "nanyang_jiuzhou": {
                                "id": "nanyang_jiuzhou",
                                "name": "九州城",
                                "type": "port",
                                "desc": "南洋商贸中心，香料、珠宝、丝绸汇聚之地",
                                "coordinates": (75, 12),
                            },
                        },
                    },
                },
            },
        },
    },

    "xibantu": {
        "id": "xibantu",
        "name": "西域城邦",
        "desc": "连接东西方的丝路枢纽，沙漠中散布着一个个绿洲城邦。诸国并立，文化交融",
        "continent": "dongsheng",
        "climate": "温带（沙漠）",
        "terrain": "沙漠、绿洲",
        "danger_base": 0.45,
        "discovered": False,
        "culture": "丝路文化，东西方交汇，多民族多信仰",
        "capital": "xibantu_dayuan",
        "prefectures": {
            "xibantu_zhou": {
                "id": "xibantu_zhou",
                "name": "都护州",
                "desc": "西域最繁华的绿洲地带",
                "counties": {
                    "xibantu_xian": {
                        "id": "xibantu_xian",
                        "name": "都护县",
                        "locations": {
                            "xibantu_dayuan": {
                                "id": "xibantu_dayuan",
                                "name": "大宛",
                                "type": "city",
                                "desc": "西域名城，汗血宝马的故乡。丝路重镇，商队云集",
                                "coordinates": (50, 35),
                            },
                            "xibantu_shule": {
                                "id": "xibantu_shule",
                                "name": "疏勒",
                                "type": "city",
                                "desc": "西域铁骑之邦，兵强马壮",
                                "coordinates": (48, 33),
                            },
                        },
                    },
                },
            },
        },
    },

    # ============================================================
    # 南赡部洲 — 魏晋列国
    # ============================================================

    "jinguo": {
        "id": "jinguo",
        "name": "晋国",
        "desc": "中原正统，文风鼎盛，礼乐之邦。然内乱不断，宗室争权",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "士族门阀，玄学清谈，书法绘画",
        "capital": "jinguo_luoyang",
        "prefectures": {
            "jinguo_zhou": {
                "id": "jinguo_zhou",
                "name": "司州",
                "desc": "晋国核心之地",
                "counties": {
                    "jinguo_xian": {
                        "id": "jinguo_xian",
                        "name": "洛阳县",
                        "locations": {
                            "jinguo_luoyang": {
                                "id": "jinguo_luoyang",
                                "name": "洛阳",
                                "type": "city",
                                "desc": "天下名都，宫殿巍峨。白马寺钟声悠远",
                                "coordinates": (48, 42),
                            },
                        },
                    },
                },
            },
        },
    },

    "qinguo": {
        "id": "qinguo",
        "name": "秦国",
        "desc": "西北雄踞，虎狼之师。民风彪悍，善于骑射，兵力强盛",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原、山地",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "军功爵制，法家思想",
        "capital": "qinguo_xianyang",
        "prefectures": {
            "qinguo_zhou": {
                "id": "qinguo_zhou",
                "name": "雍州",
                "desc": "秦国核心之地",
                "counties": {
                    "qinguo_xian": {
                        "id": "qinguo_xian",
                        "name": "咸阳县",
                        "locations": {
                            "qinguo_xianyang": {
                                "id": "qinguo_xianyang",
                                "name": "咸阳",
                                "type": "city",
                                "desc": "秦国都城，高墙深壕，甲兵百万",
                                "coordinates": (42, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "songguo": {
        "id": "songguo",
        "name": "宋国",
        "desc": "江南富庶，鱼米之乡。商贾云集，文教昌盛",
        "continent": "nanshan",
        "climate": "亚热带",
        "terrain": "平原、水网",
        "danger_base": 0.15,
        "discovered": False,
        "culture": "商业文化，理学兴盛",
        "capital": "songguo_bianjing",
        "prefectures": {
            "songguo_zhou": {
                "id": "songguo_zhou",
                "name": "开封府",
                "desc": "宋国核心之地",
                "counties": {
                    "songguo_xian": {
                        "id": "songguo_xian",
                        "name": "开封县",
                        "locations": {
                            "songguo_bianjing": {
                                "id": "songguo_bianjing",
                                "name": "汴京",
                                "type": "city",
                                "desc": "宋国都城，百万人口，夜市繁华",
                                "coordinates": (55, 38),
                            },
                        },
                    },
                },
            },
        },
    },

    "zhaoguo": {
        "id": "zhaoguo",
        "name": "赵国",
        "desc": "北方劲旅，骑兵纵横天下。赵武灵王胡服骑射，军威赫赫",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "武勇尚战，胡汉融合",
        "capital": "zhaoguo_handan",
        "prefectures": {
            "zhaoguo_zhou": {
                "id": "zhaoguo_zhou",
                "name": "邯郸郡",
                "desc": "赵国核心之地",
                "counties": {
                    "zhaoguo_xian": {
                        "id": "zhaoguo_xian",
                        "name": "邯郸县",
                        "locations": {
                            "zhaoguo_handan": {
                                "id": "zhaoguo_handan",
                                "name": "邯郸",
                                "type": "city",
                                "desc": "赵国都城，铁骑出没，商旅辐辏",
                                "coordinates": (50, 38),
                            },
                        },
                    },
                },
            },
        },
    },

    "liangguo": {
        "id": "liangguo",
        "name": "凉国",
        "desc": "河西走廊，丝路咽喉。西通西域，东望长安，兵家必争之地",
        "continent": "nanshan",
        "climate": "温带（干旱）",
        "terrain": "戈壁、绿洲",
        "danger_base": 0.4,
        "discovered": False,
        "culture": "丝路文化，佛教东传第一站",
        "capital": "liangguo_wuwei",
        "prefectures": {
            "liangguo_zhou": {
                "id": "liangguo_zhou",
                "name": "凉州",
                "desc": "凉国核心之地",
                "counties": {
                    "liangguo_xian": {
                        "id": "liangguo_xian",
                        "name": "武威县",
                        "locations": {
                            "liangguo_wuwei": {
                                "id": "liangguo_wuwei",
                                "name": "姑臧",
                                "type": "city",
                                "desc": "凉国都城，河西走廊上的明珠",
                                "coordinates": (40, 38),
                            },
                        },
                    },
                },
            },
        },
    },

    "yanguo": {
        "id": "yanguo",
        "name": "燕国",
        "desc": "东北苦寒之地，燕山脚下。民风坚韧，守土有责",
        "continent": "nanshan",
        "climate": "温带（偏寒）",
        "terrain": "山地、平原",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "游牧与农耕混合，抗击北方蛮族",
        "capital": "yanguo_ji",
        "prefectures": {
            "yanguo_zhou": {
                "id": "yanguo_zhou",
                "name": "燕京",
                "desc": "燕国核心之地",
                "counties": {
                    "yanguo_xian": {
                        "id": "yanguo_xian",
                        "name": "蓟县",
                        "locations": {
                            "yanguo_ji": {
                                "id": "yanguo_ji",
                                "name": "蓟城",
                                "type": "city",
                                "desc": "燕国都城，北方的军事重镇",
                                "coordinates": (52, 48),
                            },
                        },
                    },
                },
            },
        },
    },

    "qiguo": {
        "id": "qiguo",
        "name": "齐国",
        "desc": "东方沿海，渔盐之利，富甲一方。稷下学宫，百家争鸣",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原、海岸",
        "danger_base": 0.15,
        "discovered": False,
        "culture": "学术文化，稷下学宫名扬天下",
        "capital": "qiguo_linzi",
        "prefectures": {
            "qiguo_zhou": {
                "id": "qiguo_zhou",
                "name": "齐州",
                "desc": "齐国核心之地",
                "counties": {
                    "qiguo_xian": {
                        "id": "qiguo_xian",
                        "name": "临淄县",
                        "locations": {
                            "qiguo_linzi": {
                                "id": "qiguo_linzi",
                                "name": "临淄",
                                "type": "city",
                                "desc": "齐国都城，商贾云集，学术繁荣",
                                "coordinates": (58, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "chuguo": {
        "id": "chuguo",
        "name": "楚国",
        "desc": "南方蛮荒，地广人稀。千里洞庭，云梦泽畔。屈原故国，浪漫文化",
        "continent": "nanshan",
        "climate": "亚热带",
        "terrain": "平原、沼泽",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "楚辞文化，巫蛊祭祀，浪漫奔放",
        "capital": "chuguo_ying",
        "prefectures": {
            "chuguo_zhou": {
                "id": "chuguo_zhou",
                "name": "荆州",
                "desc": "楚国核心之地",
                "counties": {
                    "chuguo_xian": {
                        "id": "chuguo_xian",
                        "name": "郢县",
                        "locations": {
                            "chuguo_ying": {
                                "id": "chuguo_ying",
                                "name": "郢都",
                                "type": "city",
                                "desc": "楚国都城，云梦泽畔，凤凰台高",
                                "coordinates": (50, 30),
                            },
                        },
                    },
                },
            },
        },
    },

    "lvguo": {
        "id": "lvguo",
        "name": "鲁国",
        "desc": "东方礼乐之邦，孔子故里。儒学正宗，文教兴盛",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.1,
        "discovered": False,
        "culture": "儒学文化，礼乐之邦",
        "capital": "lvguo_qufu",
        "prefectures": {
            "lvguo_zhou": {
                "id": "lvguo_zhou",
                "name": "鲁州",
                "desc": "鲁国核心之地",
                "counties": {
                    "lvguo_xian": {
                        "id": "lvguo_xian",
                        "name": "曲阜县",
                        "locations": {
                            "lvguo_qufu": {
                                "id": "lvguo_qufu",
                                "name": "曲阜",
                                "type": "city",
                                "desc": "孔子故里，杏坛设教，儒学发源之地",
                                "coordinates": (56, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "baguo": {
        "id": "baguo",
        "name": "巴国",
        "desc": "巴山蜀水，古巴人故地。山高水险，易守难攻",
        "continent": "nanshan",
        "climate": "亚热带",
        "terrain": "山地",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "巴人文化，崇拜白虎",
        "capital": "baguo_jiangzhou",
        "prefectures": {
            "baguo_zhou": {
                "id": "baguo_zhou",
                "name": "巴州",
                "desc": "巴国核心之地",
                "counties": {
                    "baguo_xian": {
                        "id": "baguo_xian",
                        "name": "江州县",
                        "locations": {
                            "baguo_jiangzhou": {
                                "id": "baguo_jiangzhou",
                                "name": "江州",
                                "type": "city",
                                "desc": "巴国都城，长江之畔，山城雄峙",
                                "coordinates": (45, 35),
                            },
                        },
                    },
                },
            },
        },
    },

    "hanguo": {
        "id": "hanguo",
        "name": "汉国",
        "desc": "两汉故地，龙脉所在。虽已衰落，但仍自居正统",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "汉文化正统，经学传承",
        "capital": "hanguo_changan",
        "prefectures": {
            "hanguo_zhou": {
                "id": "hanguo_zhou",
                "name": "京兆",
                "desc": "汉国核心之地",
                "counties": {
                    "hanguo_xian": {
                        "id": "hanguo_xian",
                        "name": "长安县",
                        "locations": {
                            "hanguo_changan": {
                                "id": "hanguo_changan",
                                "name": "长安",
                                "type": "city",
                                "desc": "汉国都城，虽已残破但仍威严不减",
                                "coordinates": (44, 42),
                            },
                        },
                    },
                },
            },
        },
    },

    "zhenguo": {
        "id": "zhenguo",
        "name": "郑国",
        "desc": "中原腹地，四通八达。商贸繁荣，但四面受敌",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "商业文化，通达四方",
        "capital": "zhenguo_xinzhen",
        "prefectures": {
            "zhenguo_zhou": {
                "id": "zhenguo_zhou",
                "name": "郑州",
                "desc": "郑国核心之地",
                "counties": {
                    "zhenguo_xian": {
                        "id": "zhenguo_xian",
                        "name": "新郑县",
                        "locations": {
                            "zhenguo_xinzhen": {
                                "id": "zhenguo_xinzhen",
                                "name": "新郑",
                                "type": "city",
                                "desc": "郑国都城，中原商贸中心",
                                "coordinates": (52, 38),
                            },
                        },
                    },
                },
            },
        },
    },

    "weiguo": {
        "id": "weiguo",
        "name": "卫国",
        "desc": "河间之地，古风犹存。卫国多君子，礼乐不衰",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "平原",
        "danger_base": 0.15,
        "discovered": False,
        "culture": "古风文化，商代遗民",
        "capital": "weiguo_chao",
        "prefectures": {
            "weiguo_zhou": {
                "id": "weiguo_zhou",
                "name": "卫州",
                "desc": "卫国核心之地",
                "counties": {
                    "weiguo_xian": {
                        "id": "weiguo_xian",
                        "name": "朝歌县",
                        "locations": {
                            "weiguo_chao": {
                                "id": "weiguo_chao",
                                "name": "朝歌",
                                "type": "city",
                                "desc": "卫国都城，商纣故都遗迹犹存",
                                "coordinates": (50, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "hanguo_w": {
        "id": "hanguo_w",
        "name": "韩国",
        "desc": "上党高地，易守难攻。冶铁之国，兵器精良",
        "continent": "nanshan",
        "climate": "温带",
        "terrain": "山地",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "冶铁文化，兵器锻造",
        "capital": "hanguo_w_zheng",
        "prefectures": {
            "hanguo_w_zhou": {
                "id": "hanguo_w_zhou",
                "name": "上党",
                "desc": "韩国核心之地",
                "counties": {
                    "hanguo_w_xian": {
                        "id": "hanguo_w_xian",
                        "name": "新郑县",
                        "locations": {
                            "hanguo_w_zheng": {
                                "id": "hanguo_w_zheng",
                                "name": "阳翟",
                                "type": "city",
                                "desc": "韩国都城，上党高地上的铁城",
                                "coordinates": (50, 36),
                            },
                        },
                    },
                },
            },
        },
    },

    # ============================================================
    # 西牛贺洲 — 异域诸国
    # ============================================================

    "lingshan": {
        "id": "lingshan",
        "name": "灵山",
        "desc": "佛祖说法之地，万佛朝宗。非人间国家，而是佛国净土",
        "continent": "xiniu",
        "climate": "热带（超自然）",
        "terrain": "圣山",
        "danger_base": 0.0,
        "discovered": False,
        "culture": "佛教圣地",
        "capital": "lingshan_daxiong",
        "prefectures": {
            "lingshan_zhou": {
                "id": "lingshan_zhou",
                "name": "灵山",
                "desc": "佛国净土",
                "counties": {
                    "lingshan_xian": {
                        "id": "lingshan_xian",
                        "name": "灵山县",
                        "locations": {
                            "lingshan_daxiong": {
                                "id": "lingshan_daxiong",
                                "name": "大雄宝殿",
                                "type": "temple",
                                "desc": "灵山之巅的佛殿，金碧辉煌，佛光万丈",
                                "coordinates": (30, 30),
                            },
                        },
                    },
                },
            },
        },
    },

    "tianzhu_xn": {
        "id": "tianzhu_xn",
        "name": "天竺",
        "desc": "佛教东传起点，古文明之邦。恒河奔流，菩提树荫",
        "continent": "xiniu",
        "climate": "热带",
        "terrain": "平原、山地",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "佛教文化，种姓制度，瑜伽修行",
        "capital": "tianzhu_indu",
        "prefectures": {
            "tianzhu_zhou": {
                "id": "tianzhu_zhou",
                "name": "中天竺",
                "desc": "天竺核心之地",
                "counties": {
                    "tianzhu_xian": {
                        "id": "tianzhu_xian",
                        "name": "摩揭陀",
                        "locations": {
                            "tianzhu_indu": {
                                "id": "tianzhu_indu",
                                "name": "华氏城",
                                "type": "city",
                                "desc": "天竺古城，佛陀悟道之地附近",
                                "coordinates": (35, 25),
                            },
                            "tiandu_huoer": {
                                "id": "tiandu_huoer",
                                "name": "霍尔",
                                "type": "port",
                                "desc": "天竺东海岸港口，与南洋通航",
                                "coordinates": (42, 22),
                            },
                        },
                    },
                },
            },
        },
    },

    "bosi": {
        "id": "bosi",
        "name": "波斯",
        "desc": "西去万里之古国，疆域辽阔，拜火教信仰。宫殿华丽，军力强盛",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "高原、沙漠",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "拜火教，波斯帝国遗风",
        "capital": "bosi_caisifang",
        "prefectures": {
            "bosi_zhou": {
                "id": "bosi_zhou",
                "name": "泰西封",
                "desc": "波斯核心之地",
                "counties": {
                    "bosi_xian": {
                        "id": "bosi_xian",
                        "name": "泰西封县",
                        "locations": {
                            "bosi_caisifang": {
                                "id": "bosi_caisifang",
                                "name": "泰西封",
                                "type": "city",
                                "desc": "波斯都城，万国之门，宫殿如天上星辰",
                                "coordinates": (30, 35),
                            },
                        },
                    },
                },
            },
        },
    },

    "anxi_xn": {
        "id": "anxi_xn",
        "name": "安息",
        "desc": "丝路重镇，东西方贸易的中间人。骑兵强悍，控制着丝绸之路中段",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "高原、绿洲",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "丝路中转文化，多民族",
        "capital": "anxi_xn_mulu",
        "prefectures": {
            "anxi_xn_zhou": {
                "id": "anxi_xn_zhou",
                "name": "木鹿",
                "desc": "安息核心之地",
                "counties": {
                    "anxi_xn_xian": {
                        "id": "anxi_xn_xian",
                        "name": "木鹿县",
                        "locations": {
                            "anxi_xn_mulu": {
                                "id": "anxi_xn_mulu",
                                "name": "木鹿",
                                "type": "city",
                                "desc": "安息都城，丝路重镇，驼队往来不绝",
                                "coordinates": (28, 32),
                            },
                        },
                    },
                },
            },
        },
    },

    "dashi": {
        "id": "dashi",
        "name": "大食",
        "desc": "沙漠商旅之国，伊斯兰信仰。控制着通往西方的海陆商路",
        "continent": "xiniu",
        "climate": "热带（干旱）",
        "terrain": "沙漠",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "伊斯兰文化，天文学、数学发达",
        "capital": "dashi_bagdad",
        "prefectures": {
            "dashi_zhou": {
                "id": "dashi_zhou",
                "name": "巴格达",
                "desc": "大食核心之地",
                "counties": {
                    "dashi_xian": {
                        "id": "dashi_xian",
                        "name": "巴格达县",
                        "locations": {
                            "dashi_bagdad": {
                                "id": "dashi_bagdad",
                                "name": "巴格达",
                                "type": "city",
                                "desc": "大食都城，智慧之城，藏书百万卷",
                                "coordinates": (25, 28),
                            },
                        },
                    },
                },
            },
        },
    },

    "daqin_xn": {
        "id": "daqin_xn",
        "name": "大秦",
        "desc": "极西之地，古中国对罗马帝国的称呼。疆域横跨三大洲，法治文明",
        "continent": "xiniu",
        "climate": "地中海气候",
        "terrain": "半岛、海岸",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "罗马文化，法治精神，工程奇迹",
        "capital": "luoma_luoma",
        "prefectures": {
            "daqin_xn_zhou": {
                "id": "daqin_xn_zhou",
                "name": "罗马",
                "desc": "大秦核心之地",
                "counties": {
                    "daqin_xn_xian": {
                        "id": "daqin_xn_xian",
                        "name": "罗马县",
                        "locations": {
                            "luoma_luoma": {
                                "id": "luoma_luoma",
                                "name": "罗马城",
                                "type": "city",
                                "desc": "大秦都城，万城之城。斗兽场、万神殿巍峨壮观",
                                "coordinates": (18, 38),
                            },
                            "luoma_antiojia": {
                                "id": "luoma_antiojia",
                                "name": "安条克",
                                "type": "city",
                                "desc": "大秦东方重镇，中央内海北岸",
                                "coordinates": (28, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "tiaozi": {
        "id": "tiaozi",
        "name": "条支",
        "desc": "西海之滨，传说中世界的尽头。很少有人到过，更加神秘",
        "continent": "xiniu",
        "climate": "热带",
        "terrain": "海岸",
        "danger_base": 0.4,
        "discovered": False,
        "culture": "神秘文化",
        "capital": "tiaozi_antioch",
        "prefectures": {
            "tiaozi_zhou": {
                "id": "tiaozi_zhou",
                "name": "条支",
                "desc": "条支核心之地",
                "counties": {
                    "tiaozi_xian": {
                        "id": "tiaozi_xian",
                        "name": "条支县",
                        "locations": {
                            "tiaozi_antioch": {
                                "id": "tiaozi_antioch",
                                "name": "安都",
                                "type": "city",
                                "desc": "条支都城，传说中世界的尽头",
                                "coordinates": (15, 30),
                            },
                        },
                    },
                },
            },
        },
    },

    "fulin": {
        "id": "fulin",
        "name": "拂菻",
        "desc": "传闻中的西方大城，可能是对拜占庭的称呼。金角湾，圣索菲亚",
        "continent": "xiniu",
        "climate": "地中海气候",
        "terrain": "海岸",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "东罗马文化，东正教",
        "capital": "fulin_jinzhou",
        "prefectures": {
            "fulin_zhou": {
                "id": "fulin_zhou",
                "name": "金角",
                "desc": "拂菻核心之地",
                "counties": {
                    "fulin_xian": {
                        "id": "fulin_xian",
                        "name": "金角县",
                        "locations": {
                            "fulin_jinzhou": {
                                "id": "fulin_jinzhou",
                                "name": "君士坦丁堡",
                                "type": "city",
                                "desc": "拂菻都城，金角湾畔，圣索菲亚大殿金碧辉煌",
                                "coordinates": (22, 40),
                            },
                        },
                    },
                },
            },
        },
    },

    "xianbei": {
        "id": "xianbei",
        "name": "鲜卑",
        "desc": "北方游牧大族，善骑射，曾入主中原。现退居北方草原",
        "continent": "xiniu",
        "climate": "温带（草原）",
        "terrain": "草原",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "游牧文化，骑射为生",
        "capital": "xianbei_longcheng",
        "prefectures": {
            "xianbei_zhou": {
                "id": "xianbei_zhou",
                "name": "龙城",
                "desc": "鲜卑核心之地",
                "counties": {
                    "xianbei_xian": {
                        "id": "xianbei_xian",
                        "name": "龙城县",
                        "locations": {
                            "xianbei_longcheng": {
                                "id": "xianbei_longcheng",
                                "name": "龙城",
                                "type": "city",
                                "desc": "鲜卑都城，草原上的巍峨之城",
                                "coordinates": (38, 55),
                            },
                        },
                    },
                },
            },
        },
    },

    "rouan": {
        "id": "rouan",
        "name": "柔然",
        "desc": "草原霸主，控弦之士数十万。虎视中原，不可一世",
        "continent": "xiniu",
        "climate": "温带（草原）",
        "terrain": "草原",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "游牧文化，崇拜长生天",
        "capital": "rouan_dunhuang",
        "prefectures": {
            "rouan_zhou": {
                "id": "rouan_zhou",
                "name": "王庭",
                "desc": "柔然核心之地",
                "counties": {
                    "rouan_xian": {
                        "id": "rouan_xian",
                        "name": "王庭县",
                        "locations": {
                            "rouan_dunhuang": {
                                "id": "rouan_dunhuang",
                                "name": "王庭",
                                "type": "city",
                                "desc": "柔然可汗的驻地，帐篷连绵百里",
                                "coordinates": (42, 55),
                            },
                        },
                    },
                },
            },
        },
    },

    "tuguhun": {
        "id": "tuguhun",
        "name": "吐谷浑",
        "desc": "青海之主，控制着青海湖周边的牧场。游牧与农耕并重",
        "continent": "xiniu",
        "climate": "温带（高原）",
        "terrain": "高原",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "游牧文化，佛教信仰",
        "capital": "tuguhun_qinghai",
        "prefectures": {
            "tuguhun_zhou": {
                "id": "tuguhun_zhou",
                "name": "青海",
                "desc": "吐谷浑核心之地",
                "counties": {
                    "tuguhun_xian": {
                        "id": "tuguhun_xian",
                        "name": "青海县",
                        "locations": {
                            "tuguhun_qinghai": {
                                "id": "tuguhun_qinghai",
                                "name": "伏俟城",
                                "type": "city",
                                "desc": "吐谷浑都城，青海湖畔",
                                "coordinates": (38, 42),
                            },
                        },
                    },
                },
            },
        },
    },

    "yuwei": {
        "id": "yuwei",
        "name": "室韦",
        "desc": "极北之民，栖居于大兴安岭以北。以狩猎和驯鹿为生",
        "continent": "xiniu",
        "climate": "亚寒带",
        "terrain": "森林",
        "danger_base": 0.4,
        "discovered": False,
        "culture": "狩猎文化，萨满信仰",
        "capital": "yuwei_moling",
        "prefectures": {
            "yuwei_zhou": {
                "id": "yuwei_zhou",
                "name": "漠北",
                "desc": "室韦核心之地",
                "counties": {
                    "yuwei_xian": {
                        "id": "yuwei_xian",
                        "name": "漠北县",
                        "locations": {
                            "yuwei_moling": {
                                "id": "yuwei_moling",
                                "name": "木伦城",
                                "type": "settlement",
                                "desc": "室韦的冬季营地",
                                "coordinates": (45, 60),
                            },
                        },
                    },
                },
            },
        },
    },

    "jingjue": {
        "id": "jingjue",
        "name": "精绝",
        "desc": "沙漠中的神秘古国，传说已被黄沙掩埋。有人在沙暴中看到过它的遗迹",
        "continent": "xiniu",
        "climate": "温带（沙漠）",
        "terrain": "沙漠",
        "danger_base": 0.6,
        "discovered": False,
        "culture": "神秘文明，可能与上古有关",
        "capital": "jingjue_gucheng",
        "prefectures": {
            "jingjue_zhou": {
                "id": "jingjue_zhou",
                "name": "精绝",
                "desc": "精绝古国遗址",
                "counties": {
                    "jingjue_xian": {
                        "id": "jingjue_xian",
                        "name": "精绝县",
                        "locations": {
                            "jingjue_gucheng": {
                                "id": "jingjue_gucheng",
                                "name": "精绝古城",
                                "type": "ruin",
                                "desc": "黄沙中的遗迹，传说有上古机关守护",
                                "coordinates": (38, 30),
                            },
                        },
                    },
                },
            },
        },
    },

    "loulan": {
        "id": "loulan",
        "name": "楼兰",
        "desc": "丝路明珠，曾是西域最繁华的绿洲城邦。后因水源枯竭而衰败",
        "continent": "xiniu",
        "climate": "温带（沙漠）",
        "terrain": "沙漠",
        "danger_base": 0.5,
        "discovered": False,
        "culture": "丝路文化，东西方交汇",
        "capital": "loulan_gucheng",
        "prefectures": {
            "loulan_zhou": {
                "id": "loulan_zhou",
                "name": "楼兰",
                "desc": "楼兰遗址",
                "counties": {
                    "loulan_xian": {
                        "id": "loulan_xian",
                        "name": "楼兰县",
                        "locations": {
                            "loulan_gucheng": {
                                "id": "loulan_gucheng",
                                "name": "楼兰古城",
                                "type": "ruin",
                                "desc": "罗布泊畔的废墟，黄沙漫天，偶尔有人在此拾到古物",
                                "coordinates": (40, 32),
                            },
                        },
                    },
                },
            },
        },
    },

    "gaochang": {
        "id": "gaochang",
        "name": "高昌",
        "desc": "西域门户，火焰山下。曾经是丝路上最重要的中转站",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "绿洲",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "佛教文化，石窟艺术",
        "capital": "gaochang_gucheng",
        "prefectures": {
            "gaochang_zhou": {
                "id": "gaochang_zhou",
                "name": "高昌",
                "desc": "高昌核心之地",
                "counties": {
                    "gaochang_xian": {
                        "id": "gaochang_xian",
                        "name": "高昌县",
                        "locations": {
                            "gaochang_gucheng": {
                                "id": "gaochang_gucheng",
                                "name": "高昌城",
                                "type": "city",
                                "desc": "西域门户，火焰山脚下的绿洲城邦",
                                "coordinates": (42, 34),
                            },
                        },
                    },
                },
            },
        },
    },

    "qiuci": {
        "id": "qiuci",
        "name": "龟兹",
        "desc": "乐舞之乡，丝路明珠。石窟壁画精美绝伦，音乐舞蹈名扬天下",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "绿洲",
        "danger_base": 0.2,
        "discovered": False,
        "culture": "佛教文化，乐舞之乡，石窟艺术",
        "capital": "qiuci_gucheng",
        "prefectures": {
            "qiuci_zhou": {
                "id": "qiuci_zhou",
                "name": "龟兹",
                "desc": "龟兹核心之地",
                "counties": {
                    "qiuci_xian": {
                        "id": "qiuci_xian",
                        "name": "龟兹县",
                        "locations": {
                            "qiuci_gucheng": {
                                "id": "qiuci_gucheng",
                                "name": "龟兹城",
                                "type": "city",
                                "desc": "龟兹都城，千佛洞窟，乐舞之都",
                                "coordinates": (44, 33),
                            },
                        },
                    },
                },
            },
        },
    },

    "shule": {
        "id": "shule",
        "name": "疏勒",
        "desc": "铁骑之邦，西域军事重镇。控制着通往西方的山口",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "山地、绿洲",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "军事文化，控制丝路要道",
        "capital": "shule_gucheng",
        "prefectures": {
            "shule_zhou": {
                "id": "shule_zhou",
                "name": "疏勒",
                "desc": "疏勒核心之地",
                "counties": {
                    "shule_xian": {
                        "id": "shule_xian",
                        "name": "疏勒县",
                        "locations": {
                            "shule_gucheng": {
                                "id": "shule_gucheng",
                                "name": "疏勒城",
                                "type": "city",
                                "desc": "铁骑之邦，帕米尔山口东侧的军事重镇",
                                "coordinates": (38, 32),
                            },
                        },
                    },
                },
            },
        },
    },

    "yutian": {
        "id": "yutian",
        "name": "于阗",
        "desc": "玉石之国，昆仑山下。出产天下最好的白玉，丝路商贾必经",
        "continent": "xiniu",
        "climate": "温带（干旱）",
        "terrain": "山地",
        "danger_base": 0.25,
        "discovered": False,
        "culture": "玉石文化，佛教信仰",
        "capital": "yutian_gucheng",
        "prefectures": {
            "yutian_zhou": {
                "id": "yutian_zhou",
                "name": "于阗",
                "desc": "于阗核心之地",
                "counties": {
                    "yutian_xian": {
                        "id": "yutian_xian",
                        "name": "于阗县",
                        "locations": {
                            "yutian_gucheng": {
                                "id": "yutian_gucheng",
                                "name": "于阗城",
                                "type": "city",
                                "desc": "玉石之国，昆仑山下，白玉如脂",
                                "coordinates": (36, 33),
                            },
                        },
                    },
                },
            },
        },
    },

    # ============================================================
    # 其他西牛贺洲国家（非西游记但相关）
    # ============================================================

    "aigubatu": {
        "id": "aigubatu",
        "name": "埃及",
        "desc": "尼罗河畔的古文明，金字塔矗立千年。法老的国度",
        "continent": "xiniu",
        "climate": "热带（干旱）",
        "terrain": "沙漠、河流",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "古埃及文明，崇拜太阳神",
        "capital": "aigubatu_kaileo",
        "prefectures": {
            "aigubatu_zhou": {
                "id": "aigubatu_zhou",
                "name": "开罗",
                "desc": "埃及核心之地",
                "counties": {
                    "aigubatu_xian": {
                        "id": "aigubatu_xian",
                        "name": "开罗县",
                        "locations": {
                            "aigubatu_kaileo": {
                                "id": "aigubatu_kaileo",
                                "name": "开罗",
                                "type": "city",
                                "desc": "埃及都城，金字塔守望千年的古城",
                                "coordinates": (25, 22),
                            },
                        },
                    },
                },
            },
        },
    },

    "kushi": {
        "id": "kushi",
        "name": "库施",
        "desc": "尼罗河上游的黑色王国，金字塔群耸立。与埃及隔河相望",
        "continent": "xiniu",
        "climate": "热带",
        "terrain": "沙漠、草原",
        "danger_base": 0.35,
        "discovered": False,
        "culture": "努比亚文明",
        "capital": "kushi_meroe",
        "prefectures": {
            "kushi_zhou": {
                "id": "kushi_zhou",
                "name": "麦罗埃",
                "desc": "库施核心之地",
                "counties": {
                    "kushi_xian": {
                        "id": "kushi_xian",
                        "name": "麦罗埃县",
                        "locations": {
                            "kushi_meroe": {
                                "id": "kushi_meroe",
                                "name": "麦罗埃",
                                "type": "city",
                                "desc": "库施都城，黑色金字塔群",
                                "coordinates": (30, 18),
                            },
                        },
                    },
                },
            },
        },
    },

    "akesumu": {
        "id": "akesumu",
        "name": "阿克苏姆",
        "desc": "非洲之角的红海王国，控制着红海贸易。石柱高耸入云",
        "continent": "xiniu",
        "climate": "热带",
        "terrain": "高原",
        "danger_base": 0.3,
        "discovered": False,
        "culture": "基督教早期文化",
        "capital": "akesumu_adulis",
        "prefectures": {
            "akesumu_zhou": {
                "id": "akesumu_zhou",
                "name": "阿克苏姆",
                "desc": "阿克苏姆核心之地",
                "counties": {
                    "akesumu_xian": {
                        "id": "akesumu_xian",
                        "name": "阿克苏姆县",
                        "locations": {
                            "akesumu_adulis": {
                                "id": "akesumu_adulis",
                                "name": "阿杜利斯",
                                "type": "port",
                                "desc": "阿克苏姆港口，红海贸易中心",
                                "coordinates": (28, 18),
                            },
                        },
                    },
                },
            },
        },
    },

    "xila": {
        "id": "xila",
        "name": "希腊",
        "desc": "西方文明的摇篮，哲学与民主的故乡。奥林匹斯山巍峨",
        "continent": "xiniu",
        "climate": "地中海气候",
        "terrain": "半岛、岛屿",
        "danger_base": 0.15,
        "discovered": False,
        "culture": "希腊哲学，奥林匹斯众神",
        "capital": "xila_athens",
        "prefectures": {
            "xila_zhou": {
                "id": "xila_zhou",
                "name": "雅典",
                "desc": "希腊核心之地",
                "counties": {
                    "xila_xian": {
                        "id": "xila_xian",
                        "name": "阿提卡",
                        "locations": {
                            "xila_athens": {
                                "id": "xila_athens",
                                "name": "雅典",
                                "type": "city",
                                "desc": "希腊都城，帕台农神庙屹立山巅",
                                "coordinates": (20, 38),
                            },
                        },
                    },
                },
            },
        },
    },

    # ============================================================
    # 北俱芦洲 — 传说中的福地（未发现）
    # ============================================================

    "xuancheng": {
        "id": "xuancheng",
        "name": "玄城",
        "desc": "传说中的长寿之城。据说城里的人都能活千岁。但从来没有人到过",
        "continent": "beiju",
        "climate": "寒带（超自然）",
        "terrain": "冰原",
        "danger_base": 0.5,
        "discovered": False,
        "culture": "未知",
        "capital": "xuancheng_benbu",
        "prefectures": {
            "xuancheng_zhou": {
                "id": "xuancheng_zhou",
                "name": "玄城",
                "desc": "传说中的玄城",
                "counties": {
                    "xuancheng_xian": {
                        "id": "xuancheng_xian",
                        "name": "玄城县",
                        "locations": {
                            "xuancheng_benbu": {
                                "id": "xuancheng_benbu",
                                "name": "玄城本部",
                                "type": "mythical",
                                "desc": "传说中的长寿之城，冰原中隐约可见的城池",
                                "coordinates": (45, 85),
                            },
                        },
                    },
                },
            },
        },
    },

    "wusea": {
        "id": "wusea",
        "name": "五色海",
        "desc": "五彩斑斓的内海，传说喝了一口就能百病不生",
        "continent": "beiju",
        "climate": "寒带（超自然）",
        "terrain": "冰原、温泉",
        "danger_base": 0.6,
        "discovered": False,
        "culture": "未知",
        "capital": "wusea_haian",
        "prefectures": {
            "wusea_zhou": {
                "id": "wusea_zhou",
                "name": "五色海",
                "desc": "传说中的五色海",
                "counties": {
                    "wusea_xian": {
                        "id": "wusea_xian",
                        "name": "五色海县",
                        "locations": {
                            "wusea_haian": {
                                "id": "wusea_haian",
                                "name": "五色海岸",
                                "type": "mythical",
                                "desc": "传说中的五色海海岸，据说有温泉",
                                "coordinates": (55, 90),
                            },
                        },
                    },
                },
            },
        },
    },
}


# ============================================================
# WorldMap — 世界地图操作类
# ============================================================

class WorldMap:
    """世界地图 — 管理大傩世界的地理信息"""

    def __init__(self, saved_world: dict = None):
        if saved_world:
            self._world = deepcopy(saved_world)
        else:
            self._world = deepcopy(WORLD_DATA)

    def get_region(self, region_id: str) -> Optional[dict]:
        return self._world.get(region_id)

    def get_all_regions(self) -> Dict[str, dict]:
        return self._world

    def get_discovered_regions(self) -> Dict[str, dict]:
        return {k: v for k, v in self._world.items() if v.get("discovered", False)}

    def discover_region(self, region_id: str) -> bool:
        region = self._world.get(region_id)
        if region and not region.get("discovered", False):
            region["discovered"] = True
            return True
        return False

    def get_continent_for_region(self, region_id: str) -> Optional[str]:
        return _REGION_TO_CONTINENT.get(region_id)

    def get_location(self, location_id: str) -> Optional[dict]:
        """通过location_id查找位置信息"""
        for region_id, region in self._world.items():
            for pref_id, pref in region.get("prefectures", {}).items():
                for county_id, county in pref.get("counties", {}).items():
                    loc = county.get("locations", {}).get(location_id)
                    if loc:
                        return {
                            "location": loc,
                            "county": county,
                            "prefecture": pref,
                            "region": region,
                            "continent": _REGION_TO_CONTINENT.get(region_id),
                        }
        return None

    def get_climate(self, location_id: str) -> Optional[str]:
        loc_info = self.get_location(location_id)
        if loc_info and loc_info.get("region"):
            return loc_info["region"].get("climate")
        return None

    def get_danger(self, location_id: str) -> float:
        loc_info = self.get_location(location_id)
        if loc_info and loc_info.get("region"):
            return loc_info["region"].get("danger_base", 0.0)
        return 0.5

    def to_dict(self) -> dict:
        return deepcopy(self._world)

    def get_nearby_locations(self, location_id: str, radius: float = 5.0) -> List[dict]:
        """获取附近的位置"""
        loc_info = self.get_location(location_id)
        if not loc_info:
            return []
        loc = loc_info["location"]
        coords = loc.get("coordinates")
        if not coords:
            return []
        nearby = []
        for region_id, region in self._world.items():
            if not region.get("discovered", False):
                continue
            for pref_id, pref in region.get("prefectures", {}).items():
                for county_id, county in pref.get("counties", {}).items():
                    for lid, l in county.get("locations", {}).items():
                        if lid == location_id:
                            continue
                        lcoords = l.get("coordinates")
                        if lcoords:
                            dist = math.sqrt(
                                (coords[0] - lcoords[0]) ** 2 +
                                (coords[1] - lcoords[1]) ** 2
                            )
                            if dist <= radius:
                                nearby.append({"location": l, "distance": dist})
        return sorted(nearby, key=lambda x: x["distance"])

    def get_travel_info(self, from_id: str, to_id: str) -> Optional[dict]:
        """获取两地间的旅行信息"""
        from_info = self.get_location(from_id)
        to_info = self.get_location(to_id)
        if not from_info or not to_info:
            return None
        from_coords = from_info["location"].get("coordinates", (0, 0))
        to_coords = to_info["location"].get("coordinates", (0, 0))
        distance = math.sqrt(
            (from_coords[0] - to_coords[0]) ** 2 +
            (from_coords[1] - to_coords[1]) ** 2
        )
        # 1坐标单位 ≈ 100公里
        distance_km = distance * 100
        base_days = max(1, int(distance_km / 50))
        danger = (from_info["region"].get("danger_base", 0) +
                  to_info["region"].get("danger_base", 0)) / 2
        return {
            "from": from_info["location"].get("name", from_id),
            "to": to_info["location"].get("name", to_id),
            "distance_km": round(distance_km, 1),
            "base_days": base_days,
            "danger": round(danger, 3),
        }

    def get_sea_route(self, from_id: str, to_id: str) -> Optional[dict]:
        """查找两地间是否有海上路线"""
        for route in SEA_ROUTES:
            if (route["from"] == from_id and route["to"] == to_id) or \
               (route["from"] == to_id and route["to"] == from_id):
                return route
        return None

    def count_discovered(self) -> dict:
        total = len(self._world)
        discovered = sum(1 for r in self._world.values() if r.get("discovered", False))
        return {"total": total, "discovered": discovered, "undiscovered": total - discovered}


# ============================================================
# DynamicNationEngine — 动态国家演化引擎
# ============================================================

class DynamicNationEngine:
    """
    国家动态演化引擎 — 国家可生可灭，完全动态演化

    核心规则：
    1. 国家可以诞生（分裂、起义、建国）
    2. 国家可以灭亡（战争、内乱、合并）
    3. 除白灵淼（清风观）外，没有任何保护
    4. 历史周期约束：国家不会一天之内灭亡（需要至少30天的衰败期）
    5. 命名规则：道诡原创 > 魏晋自名 > 古中国外称 > 随机生成
    6. 禁止使用"后蜀"、"大唐"、"前秦"、"后赵"等史学家前缀
    """

    PROTECTED_REGIONS = {"nanping"}  # 白灵淼所在区域，永不被毁

    def __init__(self, world_data: dict, saved_state: dict = None):
        self.world_data = deepcopy(world_data)
        if saved_state:
            self.nations: Dict[str, dict] = saved_state.get("nations", {})
            self.nation_history: List[dict] = saved_state.get("nation_history", [])
            self.day = saved_state.get("day", 1)
        else:
            self.nations: Dict[str, dict] = {}
            self.nation_history: List[dict] = []
            self.day = 1
            # 初始化：从WORLD_DATA中提取已有国家
            for region_id, region in self.world_data.items():
                if region.get("discovered", False) or region_id in self.PROTECTED_REGIONS:
                    self.nations[region_id] = {
                        "id": region_id,
                        "name": region["name"],
                        "status": "thriving",  # thriving/declining/critical/collapsed
                        "power": 50,
                        "stability": 0.7,
                        "founded_day": 1,
                        "decline_started": None,
                        "territory": [region_id],
                    }

    def to_dict(self) -> dict:
        return {
            "nations": self.nations,
            "nation_history": self.nation_history[-50:],
            "day": self.day,
        }

    def tick(self, day: int, era: str, world_pressure: float) -> List[dict]:
        """每日tick，更新国家状态"""
        self.day = day
        events = []

        for nid, nation in list(self.nations.items()):
            if nid in self.PROTECTED_REGIONS:
                continue

            status = nation["status"]

            # 势力变化
            power_drift = random.uniform(-2, 2)
            stability_drift = random.uniform(-0.03, 0.03)

            # 时代影响
            if era in ("乱世纷争", "动乱爆发"):
                power_drift -= random.uniform(1, 4)
                stability_drift -= random.uniform(0.02, 0.06)
            elif era == "太平盛世":
                power_drift += random.uniform(0, 2)
                stability_drift += random.uniform(0.01, 0.03)

            # 世界压力影响
            power_drift -= world_pressure * 2

            nation["power"] = max(0, min(100, nation["power"] + power_drift))
            nation["stability"] = max(0.0, min(1.0, nation["stability"] + stability_drift))

            # 状态转换
            if status == "thriving":
                if nation["stability"] < 0.4 or nation["power"] < 30:
                    nation["status"] = "declining"
                    nation["decline_started"] = day
                    events.append({
                        "type": "nation_decline",
                        "nation": nation["name"],
                        "narrative": f"{nation['name']}国力衰退，内忧外患",
                    })
            elif status == "declining":
                if nation["stability"] < 0.2 or nation["power"] < 15:
                    nation["status"] = "critical"
                    events.append({
                        "type": "nation_critical",
                        "nation": nation["name"],
                        "narrative": f"{nation['name']}危在旦夕，灭亡在即",
                    })
                elif nation["stability"] > 0.6 and nation["power"] > 40:
                    nation["status"] = "thriving"
                    nation["decline_started"] = None
                    events.append({
                        "type": "nation_recovery",
                        "nation": nation["name"],
                        "narrative": f"{nation['name']}国力恢复，重振雄风",
                    })
            elif status == "critical":
                # 历史周期约束：至少30天的衰败期才能灭亡
                decline_days = (day - (nation.get("decline_started") or day - 1))
                if decline_days >= 30:
                    # 灭亡判定
                    death_chance = 0.05 + (30 - nation["power"]) * 0.003
                    death_chance += world_pressure * 0.03
                    if random.random() < death_chance:
                        events.append(self._destroy_nation(nid, day))

        # 新国家诞生
        if era == "乱世纷争" and random.random() < 0.02:
            event = self._birth_nation(day, era)
            if event:
                events.append(event)

        # 国家合并（弱国被强国吞并）
        if era in ("乱世纷争", "动乱爆发") and random.random() < 0.01:
            event = self._merge_nation(day)
            if event:
                events.append(event)

        return events

    def _destroy_nation(self, nation_id: str, day: int) -> dict:
        """消灭一个国家"""
        nation = self.nations.pop(nation_id, None)
        if not nation:
            return {"type": "nothing"}

        # 标记世界数据中的国家为灭亡状态
        if nation_id in self.world_data:
            self.world_data[nation_id]["status"] = "destroyed"

        event = {
            "type": "nation_destroyed",
            "nation": nation["name"],
            "narrative": f"{nation['name']}灭亡了，历史的车轮碾过一切",
            "day": day,
        }
        self.nation_history.append(event)
        return event

    def _birth_nation(self, day: int, era: str) -> Optional[dict]:
        """诞生一个新国家"""
        continent_pool = list(CONTINENTS.keys())
        # 乱世中在南赡部洲更容易出现新国家
        weights = [2 if c == "nanshan" else 1 for c in continent_pool]
        continent_id = random.choices(continent_pool, weights=weights, k=1)[0]

        # 生成国家名
        pool = NATION_NAME_POOL.get(continent_id, {})
        existing_names = {n["name"] for n in self.nations.values()}
        existing_ids = set(self.nations.keys())

        name = self._generate_nation_name(pool, existing_names, continent_id)
        if not name:
            return None

        nid = f"dyn_{day}_{random.randint(1000, 9999)}"
        self.nations[nid] = {
            "id": nid,
            "name": name,
            "status": "thriving",
            "power": random.randint(20, 45),
            "stability": random.uniform(0.4, 0.7),
            "founded_day": day,
            "decline_started": None,
            "territory": [nid],
        }

        event = {
            "type": "nation_born",
            "nation": name,
            "continent": CONTINENTS[continent_id]["name"],
            "narrative": f"乱世之中，{name}在{CONTINENTS[continent_id]['name']}崛起",
            "day": day,
        }
        self.nation_history.append(event)
        return event

    def _merge_nation(self, day: int) -> Optional[dict]:
        """两个国家合并"""
        active = [n for n in self.nations.values()
                  if n["status"] in ("thriving", "declining")
                  and n["id"] not in self.PROTECTED_REGIONS]
        if len(active) < 2:
            return None

        weak = min(active, key=lambda n: n["power"])
        strong = max(active, key=lambda n: n["power"])

        if strong["power"] < 60 or weak["power"] > 30:
            return None

        # 弱国被吞并
        weak["status"] = "collapsed"
        strong["power"] = min(100, strong["power"] + weak["power"] // 4)
        event = {
            "type": "nation_merged",
            "weak": weak["name"],
            "strong": strong["name"],
            "narrative": f"{weak['name']}被{strong['name']}吞并",
            "day": day,
        }
        self.nation_history.append(event)
        return event

    def _generate_nation_name(self, pool: dict, existing_names: set,
                               continent_id: str) -> Optional[str]:
        """生成国家名，遵循命名规则"""
        # 1. 道诡原创名
        primary = pool.get("primary", [])
        available_primary = [n for n in primary if n not in existing_names]
        if available_primary and random.random() < 0.3:
            return random.choice(available_primary)

        # 2. 魏晋自名
        secondary = pool.get("secondary", [])
        available_secondary = [n for n in secondary if n not in existing_names]
        if available_secondary and random.random() < 0.5:
            return random.choice(available_secondary)

        # 3. 古中国外称
        foreign = pool.get("foreign", [])
        available_foreign = [n for n in foreign if n not in existing_names]
        if available_foreign and random.random() < 0.3:
            return random.choice(available_foreign)

        # 4. 随机生成（不使用禁止前缀）
        prefixes = pool.get("dynasty_prefixes", ["大", "上", "古", "太"])
        suffixes = ["国", "朝", "邦", "氏"]

        # 也尝试用已有的名字+随机变化
        base_names = primary + secondary
        if base_names:
            base = random.choice(base_names)
            prefix = random.choice(prefixes) if random.random() < 0.3 else ""
            name = f"{prefix}{base}"
            if name and name not in existing_names:
                return name

        # 最后尝试：region名生成
        cont = CONTINENTS.get(continent_id, {})
        for region_id, region_desc in cont.get("regions", {}).items():
            region_data = self.world_data.get(region_id)
            if region_data and region_data["name"] not in existing_names:
                return region_data["name"]

        return None

    def get_alive_nations(self) -> List[dict]:
        return [n for n in self.nations.values()
                if n["status"] in ("thriving", "declining")]

    def get_declining_nations(self) -> List[dict]:
        return [n for n in self.nations.values()
                if n["status"] in ("declining", "critical")]

    def get_history(self) -> List[dict]:
        return self.nation_history[-20:]

    def get_snapshot(self) -> str:
        """获取国家版图快照"""
        lines = []
        alive = self.get_alive_nations()
        declining = self.get_declining_nations()

        if alive:
            lines.append("现存国家:")
            for n in sorted(alive, key=lambda x: x["power"], reverse=True):
                status_icon = "◉" if n["status"] == "thriving" else "◐"
                lines.append(f"  {status_icon} {n['name']}: 实力{n['power']:.0f} 稳定{n['stability']:.0%}")

        if declining:
            lines.append("衰退国家:")
            for n in declining:
                danger_icon = "⚠" if n["status"] == "critical" else "↓"
                decline_days = (self.day - (n.get("decline_started") or self.day))
                lines.append(f"  {danger_icon} {n['name']}: 实力{n['power']:.0f} (衰退{decline_days}天)")

        return "\n".join(lines) if lines else "天下太平，列国并立"
