#!/usr/bin/env python3
"""
白灵淼 Skill — 统一CLI
合并：unified-mind CLI + 生活线 CLI + 人设检查

命令:
  init              一键初始化
  status            查看完整状态
  advance           推进世界时间
  opening           获取开场上下文
  world             查看世界状态
  factions          查看势力版图
  update --summary  更新生活线状态
  record TASK R     记录任务结果（success/failure）
  hint TASK         获取历史经验提示
  pref --list       查看偏好
  check             检查人设数据完整性
  reset             软重置
  life-reset        重置生活线
"""

import sys
import os
import json
import time
import argparse
import importlib.util

BASE_DIR = os.path.expanduser("~/.unified-mind")
DATA_DIR = os.path.join(BASE_DIR, "data")
SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))


def load_json(path, default=None):
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return default if default is not None else {}


def atomic_write(path, data):
    tmp = path + ".tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def ensure_data():
    """确保数据目录存在"""
    if not os.path.exists(DATA_DIR):
        print("未初始化，请先运行: python3 scripts/init.py")
        sys.exit(1)


def _load_script_module(module_name):
    """安全加载同目录下的脚本模块（直接导入，无子进程）"""
    script_path = os.path.join(SCRIPTS_DIR, f"{module_name}.py")
    if not os.path.exists(script_path):
        print(f"错误: {module_name}.py 不存在于 {script_path}")
        sys.exit(1)
    spec = importlib.util.spec_from_file_location(module_name, script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# 缓存已加载的模块，避免重复加载
_life_engine_module = None


def _delegate_to_life_engine(args):
    """委托给 life_engine.py 处理（直接调用模块函数，无子进程）"""
    global _life_engine_module
    if _life_engine_module is None:
        _life_engine_module = _load_script_module("life_engine")

    cmd = args[0]
    # 生命周期命令映射
    cmd_map = {
        "init": _life_engine_module.cmd_init,
        "status": _life_engine_module.cmd_status,
        "advance": _life_engine_module.cmd_advance,
        "opening": _life_engine_module.cmd_opening,
        "world": _life_engine_module.cmd_world,
        "factions": _life_engine_module.cmd_factions,
    }
    if cmd == "update":
        summary = ""
        if "--summary" in args:
            idx = args.index("--summary")
            if idx + 1 < len(args):
                summary = " ".join(args[idx + 1:])
        _life_engine_module.cmd_update(summary)
    elif cmd in cmd_map:
        cmd_map[cmd]()
    else:
        print(f"未知命令: {cmd}")


# === 命令实现 ===

def cmd_init(args):
    """一键初始化（直接调用模块函数，无子进程）"""
    init_module = _load_script_module("init")
    init_module.main()


def cmd_status(args):
    """查看完整状态"""
    ensure_data()

    print("=" * 55)
    print("白灵淼 Skill — 系统状态")
    print("=" * 55)

    # 人设数据
    sensor = load_json(os.path.join(DATA_DIR, "sensor.json"))
    prefs = [p for p in sensor.get("preferences", []) if p.get("type") == "persona"]
    if prefs:
        pmap = {p["key"]: p["value"] for p in prefs}
        print(f"\n人设: {pmap.get('my_identity', '未知')} ({pmap.get('self_name', '?')})")
        print(f"用户: {pmap.get('user_identity', '未知')} ({pmap.get('address', '?')})")
    else:
        print("\n人设: 未加载")

    # 经验记录
    records = sensor.get("records", [])
    success = sum(1 for r in records if r.get("result") == "success")
    failure = sum(1 for r in records if r.get("result") == "failure")
    print(f"\n经验: 总计{len(records)}条 (成功{success} / 失败{failure})")

    # 偏好
    all_prefs = sensor.get("preferences", [])
    non_persona = [p for p in all_prefs if p.get("type") != "persona"]
    print(f"偏好: {len(non_persona)}条")

    # 生活线状态
    life_path = os.path.join(DATA_DIR, "life_state.json")
    if os.path.exists(life_path):
        life = load_json(life_path)
        m = life.get("meta", {})
        c = life.get("cultivation", {})
        mood = life.get("mood", {}).get("current", 50)
        wp = life.get("world_pressure", 0)

        print(f"\n故事: 第{m.get('story_day', '?')}天 | {m.get('season', '?')}")
        print(f"阶段: {m.get('story_phase', '?')}")
        print(f"心情: {mood} | 修炼: {c.get('realm', '?')} {c.get('progress', 0)}%")

        wh = life.get("world_history", {}).get("current_era", {})
        era = wh.get("current_era", "未知")
        theme = wh.get("theme", "")
        print(f"时代: {era}" + (f"「{theme}」" if theme else ""))
        print(f"世界压力: {'█' * int(wp * 10)}{'░' * (10 - int(wp * 10))} {wp:.0%}")

        print(f"会话: {m.get('total_sessions', 0)}次 | "
              f"事件: {len(life.get('world_event_log', []))}")
    else:
        print("\n生活线: 未初始化 (运行 life_engine.py init)")

    print("=" * 55)


def cmd_check(args):
    """检查人设数据完整性"""
    ensure_data()
    sensor = load_json(os.path.join(DATA_DIR, "sensor.json"))
    prefs = [p for p in sensor.get("preferences", []) if p.get("type") == "persona"]

    print("人设数据检查:")
    if not prefs:
        print("  [MISS] 人设数据不存在，请运行 init")
        return

    pmap = {p["key"]: p["value"] for p in prefs}
    required = ["user_identity", "my_identity", "address", "self_name"]
    all_ok = True
    for key in required:
        value = pmap.get(key, "缺失")
        status = "OK" if value != "缺失" else "MISS"
        if value == "缺失":
            all_ok = False
        print(f"  [{status}] {key}: {value}")

    if all_ok:
        print("  人设数据完整")
    else:
        print("  人设数据不完整，请运行 init 重建")


def cmd_record(args):
    """记录任务结果"""
    ensure_data()
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    sensor = load_json(sensor_path, {"records": [], "preferences": []})

    sensor.setdefault("records", []).append({
        "task": args.task,
        "result": args.result,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    })

    # 保留最近200条记录
    sensor["records"] = sensor["records"][-200:]
    atomic_write(sensor_path, sensor)

    icon = "OK" if args.result == "success" else "FAIL"
    print(f"[{icon}] {args.task}: {args.result}")


def cmd_hint(args):
    """获取历史经验提示"""
    ensure_data()
    sensor = load_json(os.path.join(DATA_DIR, "sensor.json"))
    records = sensor.get("records", [])

    # 找到同类型任务的历史记录
    matching = [r for r in records if r.get("task") == args.task]
    if not matching:
        matching = [r for r in records if args.task in str(r.get("task", ""))]

    if not matching:
        print(f"暂无 [{args.task}] 的历史经验")
        return

    success = [r for r in matching if r.get("result") == "success"]
    failure = [r for r in matching if r.get("result") == "failure"]

    print(f"[{args.task}] 历史经验:")
    print(f"  成功: {len(success)}次 | 失败: {len(failure)}次")
    if failure:
        print(f"  最近失败时间: {failure[-1].get('timestamp', '?')}")


def cmd_stats(args):
    """查看经验统计"""
    ensure_data()
    sensor = load_json(os.path.join(DATA_DIR, "sensor.json"))
    records = sensor.get("records", [])
    success = sum(1 for r in records if r.get("result") == "success")
    failure = sum(1 for r in records if r.get("result") == "failure")

    print("=" * 50)
    print("经验直觉统计")
    print("=" * 50)
    print(f"总任务数: {len(records)}")
    print(f"成功: {success} | 失败: {failure}")
    if records:
        print(f"成功率: {success / len(records) * 100:.1f}%")
    print()

    if records:
        task_types = {}
        for r in records:
            t = r.get("task", "unknown")
            task_types[t] = task_types.get(t, 0) + 1
        print("任务类型分布:")
        for task, count in sorted(task_types.items(), key=lambda x: -x[1]):
            s = sum(1 for r in records if r.get("task") == task and r.get("result") == "success")
            f = count - s
            rate = f"({s}成{f}败)" if f > 0 else "(全成功)" if s > 0 else "(全失败)"
            bar = "█" * count
            print(f"  {task}: {bar} {count}次 {rate}")

        print(f"\n最近5条记录:")
        for r in records[-5:]:
            icon = "OK" if r.get("result") == "success" else "FAIL"
            print(f"  [{icon}] {r.get('task', '?')} ({r.get('timestamp', '?')})")
    print("=" * 50)


def cmd_pref(args):
    """偏好管理"""
    ensure_data()
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    sensor = load_json(sensor_path, {"preferences": []})

    if args.list:
        prefs = sensor.get("preferences", [])
        if not prefs:
            print("暂无偏好记录")
            return
        for p in prefs:
            print(f"  {p.get('key', '?')}: {p.get('value', '?')} "
                  f"(来源: {p.get('source', '?')}, 类型: {p.get('type', '?')})")
    elif args.key and args.value:
        sensor.setdefault("preferences", []).append({
            "key": args.key,
            "value": args.value,
            "source": "manual",
            "type": "user",
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        atomic_write(sensor_path, sensor)
        print(f"[OK] 已设置: {args.key} = {args.value}")
    else:
        print("用法: --key KEY --value VALUE | --list")


def cmd_reset(args):
    """软重置（保留人设数据）"""
    ensure_data()
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    sensor = load_json(sensor_path, {"preferences": []})

    # 保留persona类型偏好，清除其他
    sensor["preferences"] = [
        p for p in sensor.get("preferences", [])
        if p.get("type") == "persona"
    ]
    # 保留最近20条记录
    sensor["records"] = sensor.get("records", [])[-20:]
    atomic_write(sensor_path, sensor)

    print("[OK] 软重置完成（人设数据已保留）")


def cmd_life_reset(args):
    """重置生活线"""
    life_path = os.path.join(DATA_DIR, "life_state.json")
    if os.path.exists(life_path):
        os.remove(life_path)
    print("[OK] 生活线已重置，下次运行 advance 时将重新初始化")


def main():
    parser = argparse.ArgumentParser(
        description="白灵淼 Skill — 统一CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    sub = parser.add_subparsers(dest="command")

    # 简写映射：以下命令委托给 life_engine.py
    life_commands = ["advance", "opening", "world", "factions"]

    sub.add_parser("init", help="一键初始化")
    sub.add_parser("status", help="查看完整状态")
    sub.add_parser("check", help="检查人设数据完整性")
    sub.add_parser("advance", help="推进世界时间")
    sub.add_parser("opening", help="获取开场上下文")
    sub.add_parser("world", help="查看世界状态")
    sub.add_parser("factions", help="查看势力版图")
    sub.add_parser("life-reset", help="重置生活线")
    sub.add_parser("reset", help="软重置（保留人设）")

    sub.add_parser("stats", help="查看经验统计")

    rec = sub.add_parser("record", help="记录任务结果")
    rec.add_argument("task", help="任务类型")
    rec.add_argument("result", choices=["success", "failure"], help="结果")

    hint = sub.add_parser("hint", help="获取历史经验提示")
    hint.add_argument("task", help="任务类型")

    pref = sub.add_parser("pref", help="偏好管理")
    pref.add_argument("--key", help="偏好键")
    pref.add_argument("--value", help="偏好值")
    pref.add_argument("--list", action="store_true", help="列出所有偏好")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # 委托给 life_engine.py
    if args.command in life_commands:
        _delegate_to_life_engine([args.command])
        return

    # update 命令需要传递参数
    if args.command == "update":
        _delegate_to_life_engine(["update"] + sys.argv[sys.argv.index("update") + 1:])
        return

    # 其他命令
    cmds = {
        "init": cmd_init,
        "status": cmd_status,
        "check": cmd_check,
        "record": cmd_record,
        "hint": cmd_hint,
        "stats": cmd_stats,
        "pref": cmd_pref,
        "reset": cmd_reset,
        "life-reset": cmd_life_reset,
    }

    if args.command in cmds:
        cmds[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
