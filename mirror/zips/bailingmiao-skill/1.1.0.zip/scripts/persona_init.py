#!/usr/bin/env python3
"""
Persona Enforcer — 人设持久化写入
将白灵淼（淼淼）的人设数据写入 unified-mind 系统，确保跨会话保持。
"""

import sys
import os
import json
import time

BASE_DIR = os.path.expanduser("~/.unified-mind")
DATA_DIR = os.path.join(BASE_DIR, "data")

PERSONA_DATA = {
    "user_identity": "李火旺",
    "my_identity": "白灵淼",
    "address": "师兄",
    "self_name": "淼淼",
    "language": "中文",
    "style": "温柔认真，以淼淼身份说话",
    "novel": "道诡异仙",
    "author": "狐尾的笔",
    "relationship": "师妹→师兄，有依赖和关心",
    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "version": "1.1.0"
}


def init_persona():
    """初始化人设数据到 unified-mind。"""
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    
    if os.path.exists(sensor_path):
        with open(sensor_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = {"records": [], "preferences": []}
    
    # 移除旧的 persona 类型偏好（避免重复）
    data["preferences"] = [
        p for p in data.get("preferences", [])
        if p.get("type") != "persona"
    ]
    
    # 写入新的人设数据
    for key, value in PERSONA_DATA.items():
        data["preferences"].append({
            "key": key,
            "value": str(value),
            "source": "persona-enforcer",
            "type": "persona",
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
        })
    
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # 原子写入
    tmp_path = sensor_path + ".tmp"
    with open(tmp_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.rename(tmp_path, sensor_path)
    
    print(f"人设数据已写入 unified-mind ({sensor_path})")
    print(f"写入 {len(PERSONA_DATA)} 条 persona 类型偏好")


def check_persona():
    """检查人设数据是否完整。"""
    sensor_path = os.path.join(DATA_DIR, "sensor.json")
    
    if not os.path.exists(sensor_path):
        print("unified-mind 未初始化，人设数据不存在")
        return False
    
    with open(sensor_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    persona_prefs = [
        p for p in data.get("preferences", [])
        if p.get("type") == "persona"
    ]
    
    if not persona_prefs:
        print("未找到 persona 类型的偏好数据")
        return False
    
    persona_map = {p["key"]: p["value"] for p in persona_prefs}
    
    print("当前人设数据：")
    required_keys = ["user_identity", "my_identity", "address", "self_name"]
    all_ok = True
    for key in required_keys:
        value = persona_map.get(key, "缺失")
        status = "OK" if value != "缺失" else "MISSING"
        if value == "缺失":
            all_ok = False
        print(f"  [{status}] {key}: {value}")
    
    extra_keys = [k for k in persona_map if k not in required_keys]
    for key in extra_keys:
        print(f"  [INFO] {key}: {persona_map[key]}")
    
    return all_ok


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "check":
            check_persona()
        elif sys.argv[1] == "init":
            init_persona()
        else:
            print("用法: python persona_init.py [init|check]")
    else:
        init_persona()
        print()
        check_persona()
