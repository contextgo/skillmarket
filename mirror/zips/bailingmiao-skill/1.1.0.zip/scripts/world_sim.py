#!/usr/bin/env python3
"""
世界模拟引擎 v5.0 — 史诗历史引擎
参考地球五千年历史 + 世界名著叙事结构，融合推演出大事件和时代背景

核心模块：
1. EraCycle — 历史周期系统（太平→暗流→动乱→乱世→新秩序→...）
2. FactionSystem — 势力博弈系统（多势力动态博弈）
3. NarrativeEngine — 叙事融合引擎（从名著模式中生成叙事弧线）
4. EventCascade — 事件级联系统（大事件的因果链）
5. DestinySystem — NPC命运系统（个人在时代中的命运涌现）
"""

import json
import random
import re
from pathlib import Path
from typing import Optional
from copy import deepcopy

NPC_PROFILES_FILE = Path(__file__).parent.parent / "defaults" / "npc_profiles.json"

# ============================================================
# 叙事组件库（保留v4.0的，用于NPC日常叙事）
# ============================================================

MANNERS = [
    "认认真真地", "偷偷摸摸地", "慢悠悠地", "急急忙忙地",
    "一声不吭地", "哼着小曲", "皱着眉头", "乐呵呵地",
    "小心翼翼地", "大大咧咧地", "若有所思地", "鬼鬼祟祟地",
    "闷闷不乐地", "精神抖擞地", "无精打采地", "专心致志地",
    "歪着头", "鼓着腮帮子", "低着头", "挺着胸",
]

EMOTIONS = [
    "看起来心情不错", "好像有点心事", "脸上带着笑",
    "眉头微皱", "嘴角挂着笑", "一脸严肃",
    "眼圈有点红", "精神很好", "看起来很累",
    "眼睛亮亮的", "表情有点复杂", "若有所思",
    "嘴角往下撇", "神色慌张", "很专注的样子",
]

DETAILS = [
    "衣服上沾了泥", "被风吹乱了头发", "手上有伤",
    "脸上有墨迹", "鞋子湿了", "指甲缝里有泥",
    "身上有药味", "嘴角沾着东西", "眼睛有点肿",
    "看起来比昨天瘦了", "换了一件新衣服", "手上拿着个东西",
    "头发上沾了叶子", "袖子卷得老高", "脸上还带着汗",
]

CONSEQUENCES = [
    "结果还不错", "弄得一团糟", "无功而返", "效果出人意料地好",
    "中途出了点岔子", "最后才搞定", "好像没什么效果",
    "搞得挺好的", "弄得挺像那么回事", "搞了一半放弃了",
    "第一次搞居然成了", "折腾了好久才完事", "简单利落",
]

TIME_MODS = [
    "一大早", "天不亮", "天还没亮", "到了中午",
    "下午", "傍晚", "天快黑了", "大半夜",
    "一整天", "大半个下午", "一上午", "天刚亮",
]

LOCATION_MODS = {
    "练功场": ["练功场上", "青石板地上", "兵器架旁边", "院子里", "练功场角落"],
    "丹房": ["丹房里", "丹房门口", "后山半坡上", "丹房后面"],
    "藏经阁": ["藏经阁二楼", "藏经阁里", "一楼书架间", "角落里", "窗户边"],
    "厨房": ["厨房里", "灶台前", "后厨", "柴火旁", "水缸边"],
    "后院": ["后院菜园", "后院", "井边", "菜地旁", "篱笆边"],
    "前殿": ["前殿", "三清像前", "大殿里", "蒲团上", "殿门口"],
    "后山": ["后山", "竹林里", "山涧旁", "半山腰", "溪流边"],
    "西厢房": ["西厢房", "房间里", "窗边", "自己房里", "门口"],
    "东厢房": ["东厢房", "房间里", "门口", "廊下"],
    "院子里": ["院子里", "院子中间", "老槐树下", "台阶上", "墙根下"],
    "山门": ["山门", "山门口", "石阶上", "山门里面"],
    "各处": ["到处", "观里", "上上下下", "各处走动"],
    "清风观": ["观里", "观内", "观中"],
    "青石镇": ["青石镇", "镇上", "集市", "街上", "镇子东头"],
    "山下村庄": ["山下村庄", "村口", "王大娘家", "村子里"],
    "外地": ["外面", "不知道哪里", "很远的地方"],
}

# ============================================================
# 叙事模式库 — 从世界名著中提取的叙事结构
# ============================================================

NARRATIVE_PATTERNS = {
    "tragic_reversal": {
        "name": "命运反转",
        "desc": "看似美好的局面突然翻转，隐藏的真相揭露",
        "era_tendency": ["暗流涌动", "动乱爆发"],
        "weight": 8,
        "catalyst_templates": [
            "{faction_a}和{faction_b}的联盟突然破裂，{detail}",
            "一个被所有人信任的人暴露了真实身份——{detail}",
            "本以为已经解决的威胁其实只是冰山一角，{detail}",
            "清风观附近的一个势力内部发生了血腥清洗，{detail}",
        ],
        "detail_pool": [
            "原因是{treason_type}",
            "{npc}发现了关键的证据",
            "一场夜袭改变了局势",
            "一个秘密的信件被截获",
            "有人临死前说出了真相",
        ],
        "treason_pool": [
            "利益分配不均", "有人的家人被绑架了", "信仰的分歧",
            "一个古老的誓言被违背", "外部势力的挑拨",
        ],
        "impact": "high",
    },
    "heros_journey": {
        "name": "英雄之旅",
        "desc": "平凡人被卷入不平凡的事件，经历考验后蜕变",
        "era_tendency": ["动乱爆发", "乱世纷争"],
        "weight": 7,
        "catalyst_templates": [
            "{npc}被迫离开了清风观，{detail}",
            "一个看似普通的{person}突然展现出惊人的力量，{detail}",
            "在{place}的一次偶遇改变了一切，{detail}",
        ],
        "detail_pool": [
            "带着一个危险的任务出发了",
            "在绝境中突破了修炼瓶颈",
            "遇到了一位神秘的导师",
            "发现了一件改变命运的宝物",
        ],
        "person_pool": ["散修", "游方道士", "乞丐", "猎户", "书生", "小孩"],
        "place_pool": ["青石镇", "后山深处", "山洞", "溪边", "藏经阁二楼"],
        "impact": "medium",
    },
    "family_rise_fall": {
        "name": "兴衰更替",
        "desc": "一个群体从鼎盛走向衰落，内部矛盾是主因",
        "era_tendency": ["暗流涌动", "太平盛世"],
        "weight": 6,
        "catalyst_templates": [
            "{faction}内部爆发了严重的分歧，{detail}",
            "曾经强大的{faction}开始显露疲态，{detail}",
            "{faction}的{leader}突然病倒了，群龙无首，{detail}",
        ],
        "detail_pool": [
            "两派人马几乎要兵戎相见",
            "年轻一代开始质疑老一辈的决定",
            "资源分配引发了激烈的争端",
            "一个关键人物的离去让一切动摇",
        ],
        "impact": "high",
    },
    "power_struggle": {
        "name": "权力角逐",
        "desc": "多个势力争夺主导权，联盟不断变化",
        "era_tendency": ["暗流涌动", "动乱爆发", "乱世纷争"],
        "weight": 9,
        "catalyst_templates": [
            "{faction_a}向{faction_b}发起了挑战，{detail}",
            "三方势力在{place}展开博弈，{detail}",
            "{faction}暗中拉拢了几个小势力，局势突然变得复杂",
            "一个关键的{resource}成为各方争夺的焦点，{detail}",
        ],
        "detail_pool": [
            "战争的阴影笼罩了整个苍云山脉",
            "盟友变成了对手",
            "暗杀和阴谋不断",
            "各方都在积蓄力量，等待时机",
        ],
        "resource_pool": ["灵石矿脉", "修炼圣地", "上古遗宝", "交通要道"],
        "impact": "high",
    },
    "heroes_emerge": {
        "name": "乱世出豪杰",
        "desc": "混乱的时代催生各路英雄和枭雄",
        "era_tendency": ["乱世纷争"],
        "weight": 8,
        "catalyst_templates": [
            "一个不知名的{person}在{place}一战成名，{detail}",
            "乱世中，一位被称为{title}的人物横空出世，{detail}",
            "多个散修联合起来组成了新的势力，{detail}",
        ],
        "detail_pool": [
            "以一人之力击退了数十名敌人",
            "据说修炼了某种失传已久的功法",
            "收拢了大量流民，建立了新的据点",
            "成为各方势力争相拉拢的对象",
        ],
        "title_pool": ["疯道士", "白衣剑客", "铁面判官", "笑面虎", "无影人", "赤手仙"],
        "impact": "medium",
    },
    "betrayal": {
        "name": "背叛与忠诚",
        "desc": "信任的人背叛，或被迫在忠诚与利益间选择",
        "era_tendency": ["暗流涌动", "动乱爆发", "乱世纷争"],
        "weight": 9,
        "catalyst_templates": [
            "{faction}的一个核心人物倒戈了，{detail}",
            "一封密信揭露了{faction}内部的叛徒，{detail}",
            "在关键时刻，{npc}做出了出人意料的选择，{detail}",
        ],
        "detail_pool": [
            "带走了大量的秘密和资源",
            "原因至今成谜",
            "有人说是被胁迫的，有人说是主动的",
            "这件事在{place}引起了巨大的震动",
        ],
        "impact": "high",
    },
    "plague_faith": {
        "name": "灾厄与信仰",
        "desc": "大灾难改变社会结构，信仰动摇或复兴",
        "era_tendency": ["乱世纷争", "动乱爆发"],
        "weight": 5,
        "catalyst_templates": [
            "{place}爆发了{disaster}，{detail}",
            "一种奇怪的{symptom}在{place}蔓延，{detail}",
            "天降{phenomenon}，{detail}",
        ],
        "disaster_pool": ["瘟疫", "虫灾", "旱灾", "洪灾", "灵气紊乱"],
        "symptom_pool": ["怪病", "疯病", "修为暴走", "记忆丧失"],
        "phenomenon_pool": ["血雨", "黑雾", "地裂", "持续数日的雷暴"],
        "detail_pool": [
            "人心惶惶，白莲教趁机传教",
            "师叔让大家不要外出",
            "有人说是天谴，有人说是人为",
            "附近的村庄几乎空了",
        ],
        "impact": "high",
    },
    "exile_return": {
        "name": "流亡与归途",
        "desc": "被迫离开家园，在流浪中获得力量，最终回归",
        "era_tendency": ["动乱爆发", "乱世纷争"],
        "weight": 6,
        "catalyst_templates": [
            "{npc}离开了清风观，{detail}",
            "一群{person}从远方流浪到清风山附近，{detail}",
            "有人在{place}发现了一个被遗弃的{settlement}，{detail}",
        ],
        "person_pool": ["难民", "散修", "落魄的商人", "逃亡的官员"],
        "settlement_pool": ["村落", "道观", "山寨", "矿洞"],
        "detail_pool": [
            "带着重要的情报离开",
            "说外面已经完全变了样",
            "请求在这里暂住",
            "里面有一些令人不安的痕迹",
        ],
        "impact": "medium",
    },
    "forbidden_secret": {
        "name": "禁忌与秘密",
        "desc": "一个被禁止的秘密改变一切",
        "era_tendency": ["太平盛世", "暗流涌动"],
        "weight": 7,
        "catalyst_templates": [
            "{npc}在{place}发现了一个不可告人的秘密，{detail}",
            "清风观地下好像有什么东西，{detail}",
            "一封多年前的信被发现了，{detail}",
        ],
        "detail_pool": [
            "但{npc}不敢告诉任何人",
            "师叔知道后沉默了很久",
            "这个秘密牵涉到{faction}",
            "之后几天{npc}的行为变得很反常",
        ],
        "impact": "medium",
    },
    "revenge_redemption": {
        "name": "复仇与救赎",
        "desc": "不公正的遭遇引发复仇，最终走向救赎或毁灭",
        "era_tendency": ["乱世纷争", "动乱爆发"],
        "weight": 6,
        "catalyst_templates": [
            "一个带着仇恨的人来到了{place}，{detail}",
            "{faction}过去的一桩旧案被翻了出来，{detail}",
            "有人在寻找当年害他{crime}的凶手，{detail}",
        ],
        "crime_pool": ["灭门", "夺基", "夺宝", "陷害"],
        "detail_pool": [
            "整个{place}都笼罩在不安中",
            "这件事牵扯到了好几个势力",
            "真相远比想象的复杂",
            "师叔的脸色变得很难看",
        ],
        "impact": "medium",
    },
}


# ============================================================
# 历史周期系统
# ============================================================

ERA_PHASES = {
    "太平盛世": {
        "narrative_themes": [
            "风调雨顺的年月", "修炼的好时节", "各派相安无事",
            "难得的太平", "山间岁月静好",
        ],
        "world_pressure_drift": -0.001,  # 压力极缓慢下降
        "min_duration": 60,     # 太平至少60天，好好享受日常
        "max_duration": 200,    # 太平可以持续很久
        "transition_to": {
            "暗流涌动": 0.65,   # 最可能转入暗流
            "动乱爆发": 0.05,   # 极小概率突变
            "太平盛世": 0.30,   # 继续太平概率提高
        },
    },
    "暗流涌动": {
        "narrative_themes": [
            "山雨欲来风满楼", "不安的种子在发芽", "表面平静暗流涌动",
            "有人开始为未来担忧", "夜里的脚步声变多了",
        ],
        "world_pressure_drift": 0.003,   # 压力更缓慢上升
        "min_duration": 40,     # 暗流也要酝酿
        "max_duration": 120,
        "transition_to": {
            "动乱爆发": 0.4,
            "乱世纷争": 0.08,
            "太平盛世": 0.15,  # 有可能恢复太平
            "暗流涌动": 0.37,  # 持续更久
        },
    },
    "动乱爆发": {
        "narrative_themes": [
            "天下大乱", "烽火四起", "秩序崩塌",
            "流民遍野", "平静的日子结束了",
        ],
        "world_pressure_drift": 0.015,   # 压力快速上升
        "min_duration": 15,
        "max_duration": 60,
        "transition_to": {
            "乱世纷争": 0.6,
            "新秩序": 0.15,
            "动乱爆发": 0.25,
        },
    },
    "乱世纷争": {
        "narrative_themes": [
            "群雄割据", "弱肉强食", "英雄与枭雄并起",
            "活着就是最大的幸运", "在这个世道，谁也不信谁",
        ],
        "world_pressure_drift": 0.003,
        "min_duration": 40,
        "max_duration": 150,
        "transition_to": {
            "新秩序": 0.5,
            "太平盛世": 0.1,  # 极小概率直接恢复太平
            "乱世纷争": 0.4,
        },
    },
    "新秩序": {
        "narrative_themes": [
            "新的时代开始了", "废墟上重建", "秩序的代价",
            "有人欢喜有人愁", "天下初定",
        ],
        "world_pressure_drift": -0.008,
        "min_duration": 20,
        "max_duration": 60,
        "transition_to": {
            "太平盛世": 0.6,
            "暗流涌动": 0.25,
            "新秩序": 0.15,
        },
    },
}


class EraCycle:
    """历史周期系统 — 驱动大时代的走向"""

    def __init__(self, current_day: int, saved: dict = None):
        if saved:
            self.current_era = saved.get("current_era", "太平盛世")
            self.phase = saved.get("phase", "active")
            self.started_day = saved.get("started_day", 1)
            self.era_pressure = saved.get("era_pressure", 0.1)
            self.theme = saved.get("theme", "山间岁月静好")
            self.era_history = saved.get("era_history", [])
        else:
            self.current_era = "太平盛世"
            self.phase = "active"
            self.started_day = current_day
            self.era_pressure = 0.1
            self.theme = random.choice(ERA_PHASES["太平盛世"]["narrative_themes"])
            self.era_history = []

    def to_dict(self) -> dict:
        return {
            "current_era": self.current_era,
            "phase": self.phase,
            "started_day": self.started_day,
            "era_pressure": self.era_pressure,
            "theme": self.theme,
            "era_history": self.era_history,
        }

    def tick(self, day: int, wpi: dict) -> Optional[dict]:
        """每日tick，检查时代转换——由世界内部指标虚拟驱动，非写死概率"""
        duration = day - self.started_day
        phase_config = ERA_PHASES[self.current_era]

        # 压力漂移：基础漂移 + 世间扰动
        self.era_pressure += phase_config["world_pressure_drift"]
        self.era_pressure += random.uniform(-0.003, 0.003)
        # 世界压力会推高时代压力（正反馈）
        composite = wpi.get("composite", 0)
        self.era_pressure += composite * 0.002
        self.era_pressure = max(0.0, min(1.0, self.era_pressure))

        # 检查是否应该转换——最短持续期
        if duration < phase_config["min_duration"]:
            return None

        # ====== 虚拟演化：转换概率从世界状态涌现，不是固定值 ======
        # 基础概率（历史有惯性，但有内在矛盾推动变化）
        base_prob = 0.004

        # 因素1：时间压力——持续时间越长，转变可能性越大
        time_ratio = duration / phase_config["max_duration"]
        if time_ratio > 0.5:
            base_prob += 0.003 * (time_ratio - 0.5) / 0.5
        if time_ratio > 0.7:
            base_prob += 0.005 * (time_ratio - 0.7) / 0.3
        if time_ratio > 1.0:
            base_prob += 0.015 * min(time_ratio - 1.0, 1.0)

        # 因素2：世界压力指数——压力越高，转变动力越强
        base_prob += composite * 0.015

        # 因素3：时代压力——该时代内在积累的压力
        base_prob += self.era_pressure * 0.010

        # 因素4：历史惯性——如果之前的时代历史显示周期律在加速/减速
        if len(self.era_history) >= 2:
            recent_durations = [
                h.get("ended_day", 0) - h.get("started_day", 0)
                for h in self.era_history[-3:]
                if h.get("ended_day") and h.get("started_day")
            ]
            if recent_durations:
                avg_duration = sum(recent_durations) / len(recent_durations)
                # 周期加速（越转越快，类似历史晚期）
                if avg_duration < 50:
                    base_prob += 0.005
                # 周期稳定
                elif avg_duration > 120:
                    base_prob -= 0.002

        # 黑天鹅：极小概率的剧变
        if random.random() < 0.0005:
            base_prob += 0.05  # 突然大幅提高转变概率

        base_prob = max(0.0, min(0.08, base_prob))  # 上限8%/天

        if random.random() > base_prob:
            return None

        # ====== 虚拟演化：转换目标从世界状态计算，不是固定权重表 ======
        # 时代转换逻辑：由当前状态决定"引力方向"
        # 定义每个时代对世界压力的"需求方向"
        era_pressure_need = {
            "太平盛世": -0.3,   # 需要低压力才能维持
            "暗流涌动": 0.1,    # 中低压力
            "动乱爆发": 0.6,    # 高压力
            "乱世纷争": 0.4,    # 中高压力
            "新秩序": -0.1,     # 压力在下降
        }

        # 定义时代之间的"距离"——越近越容易转
        era_proximity = {
            "太平盛世": {"暗流涌动": 1.0, "动乱爆发": 0.2, "乱世纷争": 0.1, "新秩序": 0.3},
            "暗流涌动": {"太平盛世": 0.8, "动乱爆发": 1.0, "乱世纷争": 0.3, "新秩序": 0.2},
            "动乱爆发": {"暗流涌动": 0.4, "乱世纷争": 1.0, "新秩序": 0.3, "太平盛世": 0.05},
            "乱世纷争": {"动乱爆发": 0.5, "新秩序": 1.0, "太平盛世": 0.1, "暗流涌动": 0.2},
            "新秩序": {"太平盛世": 1.0, "暗流涌动": 0.5, "乱世纷争": 0.1, "动乱爆发": 0.05},
        }

        # 计算每个候选时代的吸引力
        candidates = {}
        for target_era in ERA_PHASES:
            if target_era == self.current_era:
                continue
            # 基础邻近度
            prox = era_proximity.get(self.current_era, {}).get(target_era, 0.1)
            # 压力匹配度：世界压力越接近目标时代的需求，吸引力越大
            pressure_need = era_pressure_need.get(target_era, 0)
            pressure_match = 1.0 - abs(composite - pressure_need)
            pressure_match = max(0.0, pressure_match)
            # 时代压力匹配
            era_p_need = era_pressure_need.get(target_era, 0)
            era_p_match = 1.0 - abs(self.era_pressure - (era_p_need + 0.5))
            era_p_match = max(0.0, era_p_match)
            # 综合吸引力 = 邻近度 * 0.4 + 压力匹配 * 0.35 + 时代压力匹配 * 0.25
            attraction = prox * 0.4 + pressure_match * 0.35 + era_p_match * 0.25
            candidates[target_era] = max(0.01, attraction)

        targets = list(candidates.keys())
        weights = list(candidates.values())

        new_era = random.choices(targets, weights=weights, k=1)[0]

        # 执行转换
        old_era = self.current_era
        old_era_obj = {
            "name": old_era,
            "started_day": self.started_day,
            "ended_day": day,
        }
        self.era_history.append(old_era_obj)

        self.current_era = new_era
        self.started_day = day
        self.phase = "active"
        self.theme = random.choice(ERA_PHASES[new_era]["narrative_themes"])

        # ====== 动态生成时代转换叙事——不是固定模板 ======
        narrative = self._generate_transition_narrative(old_era, new_era, composite)

        return {
            "type": "era_transition",
            "name": f"时代转换：{old_era} → {new_era}",
            "old_era": old_era,
            "new_era": new_era,
            "narrative": narrative,
            "impact": "high",
        }

    def _generate_transition_narrative(self, old_era: str, new_era: str,
                                        pressure: float) -> str:
        """根据世界状态动态生成时代转换叙事"""
        # 转换方向判断
        chaos_order = {"太平盛世": 0, "暗流涌动": 1, "动乱爆发": 2, "乱世纷争": 3, "新秩序": 4}
        old_level = chaos_order.get(old_era, 0)
        new_level = chaos_order.get(new_era, 0)

        if new_level > old_level:
            # 走向混乱
            direction = "chaos"
        elif new_level < old_level and new_era != "新秩序":
            # 走向秩序
            direction = "order"
        elif new_era == "新秩序":
            direction = "rebuild"
        else:
            direction = "chaos"

        # 压力强度影响叙事的紧迫感
        if pressure > 0.6:
            intensity = "acute"
        elif pressure > 0.3:
            intensity = "moderate"
        else:
            intensity = "gradual"

        # 混沌方向叙事
        chaos_narratives = {
            "acute": [
                "天变了。一夜之间，整个苍云山脉都笼罩在一种说不出的恐惧里，连空气都不对劲了。",
                "出大事了——诡异的事越来越多，修士们开始疯狂地往山里涌，能跑的都在跑。",
                "就好像有什么东西撕开了天幕，大傩世界的规则在崩塌，所有人都能感觉到。",
            ],
            "moderate": [
                "最近不太平了。远处传来的消息一个比一个让人不安，师叔的脸色越来越难看。",
                "不知道从什么时候起，清风观外面变得不一样了。路过的人少了，但每一个都很慌张。",
                "山雨欲来——有些东西正在改变，虽然还没到门口，但已经能闻到那股子味道了。",
            ],
            "gradual": [
                "太平的日子好像有点不对劲了，说不清哪里不对，就是觉得不太踏实。",
                "风里开始有了不安的味道，虽然还没有什么事发生，但师叔最近总是皱着眉头。",
            ],
        }

        order_narratives = {
            "acute": [
                "好像有人力挽狂澜了——但这并不意味着安全，代价也许比乱世本身更沉重。",
                "秩序回来了，但回来的方式让人发寒。有时候，规矩比混乱更可怕。",
            ],
            "moderate": [
                "风声好像小了一些。虽然大家还是小心翼翼的，但至少能喘口气了。",
                "不知道是谁在收拾这个烂摊子，但至少天没继续黑下去。",
            ],
            "gradual": [
                "好像……日子慢慢好了一点？也许只是错觉吧。",
                "不知道是不是错觉，外面好像没那么吓人了。但也没人敢放松。",
            ],
        }

        rebuild_narratives = {
            "acute": [
                "战火烧过的地方一片狼藉，但有人在废墟里站起来了。虽然代价惨重，但好像能看到一点光了。",
                "大傩世界在自我修复——或者说，在用一种残忍的方式重新开始。活下来的人，各有各的伤。",
            ],
            "moderate": [
                "乱世的尾巴还在，但已经有人在收拾了。有人修墙，有人修心。",
                "好像终于有人能把这堆烂摊子捡起来了。虽然到处都是伤疤，但至少不用每天担惊受怕了。",
            ],
            "gradual": [
                "不知不觉间，好像没那么乱了。日子还是在过，虽然跟以前不一样了。",
                "清风观的院子里又有了笑声——很轻，很小，但确实有了。",
            ],
        }

        if direction == "chaos":
            return random.choice(chaos_narratives.get(intensity, chaos_narratives["moderate"]))
        elif direction == "rebuild":
            return random.choice(rebuild_narratives.get(intensity, rebuild_narratives["moderate"]))
        else:
            return random.choice(order_narratives.get(intensity, order_narratives["moderate"]))


# ============================================================
# 势力系统
# ============================================================

class Faction:
    """一个势力"""

    def __init__(self, fid: str, data: dict):
        self.id = fid
        self.name = data["name"]
        self.ftype = data.get("type", "sect")
        self.power = data.get("power", 50)
        self.territory = data.get("territory", [])
        self.stance = data.get("stance", "neutral")
        self.internal_stability = data.get("internal_stability", 0.5)
        self.leader = data.get("leader", "未知")
        self.agenda = data.get("agenda", "")
        self.allies = data.get("allies", [])
        self.enemies = data.get("enemies", [])
        self.status = data.get("status", "active")  # active/declining/collapsed/rising

    def to_dict(self) -> dict:
        return {
            "name": self.name, "type": self.ftype, "power": self.power,
            "territory": self.territory, "stance": self.stance,
            "internal_stability": round(self.internal_stability, 3),
            "leader": self.leader, "agenda": self.agenda,
            "allies": self.allies, "enemies": self.enemies,
            "status": self.status,
        }


class FactionSystem:
    """势力博弈系统"""

    def __init__(self, saved_factions: dict = None):
        self.factions: dict[str, Faction] = {}

        # 默认势力——符合《道诡异仙》大傩世界特色
        default_factions = {
            "qingfeng_guan": {
                "name": "清风观", "type": "small_sect", "power": 15,
                "territory": ["清风山", "青石镇"], "stance": "neutral",
                "internal_stability": 0.8, "leader": "陈清远",
                "agenda": "躲避乱世，守护弟子",
                "allies": [], "enemies": [], "status": "active",
            },
            "bailian_jiao": {
                "name": "白莲教", "type": "cult", "power": 55,
                "territory": ["南方", "苍云山脉南部"], "stance": "expansionist",
                "internal_stability": 0.6, "leader": "教主（未知）",
                "agenda": "寻找圣女，以血祭通天，颠覆大傩秩序",
                "allies": [], "enemies": ["zhengdao_lianmeng", "chaoting"],
                "status": "active",
            },
            "zhengdao_lianmeng": {
                "name": "正道联盟", "type": "alliance", "power": 75,
                "territory": ["中原", "北方"], "stance": "conservative",
                "internal_stability": 0.5, "leader": "盟主（多人）",
                "agenda": "镇压诡异，维持人道秩序",
                "allies": ["chaoting"], "enemies": ["bailian_jiao", "zuowang_dao"],
                "status": "active",
            },
            "chaoting": {
                "name": "朝廷", "type": "government", "power": 65,
                "territory": ["全国"], "stance": "weakening",
                "internal_stability": 0.4, "leader": "皇帝",
                "agenda": "以傩礼镇国运，维持凡人统治",
                "allies": ["zhengdao_lianmeng"], "enemies": ["bailian_jiao"],
                "status": "active",
            },
            "zuowang_dao": {
                "name": "坐忘道", "type": "shadow", "power": 35,
                "territory": ["隐藏"], "stance": "chaotic",
                "internal_stability": 0.9, "leader": "道主（未知）",
                "agenda": "以疯癫入道，混乱即秩序",
                "allies": [], "enemies": ["zhengdao_lianmeng"],
                "status": "active",
            },
            "difang_haoqiang": {
                "name": "地方豪强", "type": "warlords", "power": 25,
                "territory": ["各处分散"], "stance": "opportunistic",
                "internal_stability": 0.3, "leader": "多位",
                "agenda": "趁诡异横行之际扩张势力",
                "allies": [], "enemies": [],
                "status": "active",
            },
        }

        if saved_factions:
            for fid, fdata in saved_factions.items():
                self.factions[fid] = Faction(fid, fdata)
        else:
            for fid, fdata in default_factions.items():
                self.factions[fid] = Faction(fid, fdata)

    def to_dict(self) -> dict:
        return {fid: f.to_dict() for fid, f in self.factions.items()}

    def _generate_faction_name(self) -> str:
        """基于《道诡异仙》世界观生成势力名称——诡异、疯癫、傩文化"""
        # 道诡异仙风格前缀：融合大傩世界、诡异修行、疯癫信仰
        prefixes = [
            # 傩文化/驱邪
            "大傩", "司命", "渡厄", "驱邪", "镇煞", "封魔", "逐疫", "祭傩",
            # 诡异修行
            "五仙", "心素", "两仪", "归虚", "六道", "尸解", "异化", "谵妄",
            "妄念", "呓语", "诡道", "魔障", "混沌", "虚无", "寂灭", "瞳渊",
            # 疯癫/扭曲
            "疯癫", "癫狂", "迷惘", "疯魔", "狂乱", "偏执", "执念", "痴迷",
            # 邪道/暗面
            "血祭", "炼狱", "堕魔", "鬼修", "天劫", "灰烬", "残魂", "噬梦",
            # 天地异象
            "三灾", "九厄", "灾劫", "苦海", "无间", "渊冥", "幽都", "彼岸",
            # 超脱/神秘
            "忘忧", "坐忘", "无为", "天道", "轮回", "涅槃", "太虚", "玄牝",
            # 地域特色（大傩世界地名风格）
            "苍梧", "昆仑", "蓬莱", "酆都", "罗浮", "青城", "茅山", "阁皂",
        ]
        # 道诡异仙风格后缀：不仅仅是门派，还有诡异组织形态
        suffixes = [
            # 传统
            "门", "帮", "阁", "寨", "会", "堂", "堡", "谷", "宫", "洞",
            "派", "宗", "殿", "轩", "楼",
            # 诡异特色
            "窟", "域", "渊", "境", "道", "界", "墟", "冢", "狱", "壇",
            "塔", "穴", "巢", "阵", "祠",
        ]
        existing_names = {f.name for f in self.factions.values()}
        # Try random combinations until we find a unique name
        for _ in range(100):
            name = random.choice(prefixes) + random.choice(suffixes)
            if name not in existing_names:
                return name
        # Extremely unlikely fallback: add a number suffix
        base = random.choice(prefixes) + random.choice(suffixes)
        counter = 2
        while f"{base}{counter}" in existing_names:
            counter += 1
        return f"{base}{counter}"

    def tick(self, era: str, day: int) -> Optional[dict]:
        """每10天进行一次势力博弈"""
        if day % 10 != 0:
            return None

        events = []

        # 势力内部稳定性变化
        for fid, faction in self.factions.items():
            if faction.status != "active":
                continue

            # 内部稳定性漂移
            drift = random.uniform(-0.05, 0.05)

            # 乱世中稳定性下降
            if era in ("动乱爆发", "乱世纷争"):
                drift -= random.uniform(0.02, 0.08)

            # 太平中稳定性回升
            if era == "太平盛世":
                drift += random.uniform(0.01, 0.04)

            faction.internal_stability = max(0.0, min(1.0,
                faction.internal_stability + drift))

            # 内部崩溃
            if faction.internal_stability < 0.1 and random.random() < 0.3:
                faction.status = "declining"
                events.append({
                    "type": "faction_event",
                    "name": f"{faction.name}内乱",
                    "narrative": f"听说{faction.name}内部出了大问题，"
                                f"好像有人在争夺权力",
                    "impact": "medium",
                    "affected_factions": [fid],
                })

        # 势力实力变化
        for fid, faction in self.factions.items():
            power_drift = random.uniform(-3, 3)

            if era == "太平盛世":
                power_drift += random.uniform(0, 2)
            elif era == "乱世纷争":
                power_drift += random.uniform(-5, 5)

            faction.power = max(0, min(100, faction.power + power_drift))

        # 联盟变化（乱世中联盟更不稳定）
        if era in ("乱世纷争", "动乱爆发") and random.random() < 0.15:
            active_factions = [f for f in self.factions.values()
                              if f.status == "active" and f.id != "qingfeng_guan"]
            if len(active_factions) >= 2:
                a, b = random.sample(active_factions, 2)

                if b.id in a.allies and random.random() < 0.3:
                    a.allies.remove(b.id)
                    if a.id in b.allies:
                        b.allies.remove(a.id)
                    events.append({
                        "type": "faction_event",
                        "name": "联盟破裂",
                        "narrative": f"听说{a.name}和{b.name}的关系破裂了，"
                                    f"不知道发生了什么",
                        "impact": "medium",
                        "affected_factions": [a.id, b.id],
                    })
                elif random.random() < 0.2:
                    a.allies.append(b.id)
                    b.allies.append(a.id)
                    events.append({
                        "type": "faction_event",
                        "name": "新的结盟",
                        "narrative": f"有消息说{a.name}和{b.name}结成了联盟，"
                                    f"不知道意味着什么",
                        "impact": "medium",
                        "affected_factions": [a.id, b.id],
                    })

        # 新势力涌现（乱世中概率更高）
        if era == "乱世纷争" and random.random() < 0.08:
            new_id = f"new_faction_{day}"
            new_name = self._generate_faction_name()
            # 新势力类型和首领符合道诡异仙特色
            emerging_types = [
                ("cult", "异教", ["散修", "疯道士", "逃犯", "自称神降之人"]),
                ("shadow", "暗派", ["逃亡修士", "被逐弟子", "自称通灵者", "坐忘道弃徒"]),
                ("sect", "小门派", ["散修", "落魄道人", "自称得道者", "走投无路的修士"]),
                ("warlords", "武装", ["逃兵", "流民头目", "自称天命之人", "被诡异追杀的幸存者"]),
            ]
            etype, etype_desc, leaders = random.choice(emerging_types)
            # 势力野心也符合道诡异仙语境
            agenda_pool = [
                "在这诡异横行的世道里求一条活路",
                "据说找到了一种对抗诡异的方法",
                "以疯癫修行，声称能看见别人看不见的东西",
                "声称得到了某个死去大能的传承",
                "收拢被诡异害了家的人，要向天讨个公道",
                "说要在这乱世里建一个不惧诡异的庇护所",
            ]
            self.factions[new_id] = Faction(new_id, {
                "name": new_name, "type": "emerging",
                "power": random.randint(10, 40),
                "territory": [f"苍云山脉{random.choice(['东部','西部','北部','南部','中部'])}"],
                "stance": random.choice(["expansionist", "neutral", "opportunistic"]),
                "internal_stability": random.uniform(0.4, 0.8),
                "leader": f"{random.choice(leaders)}",
                "agenda": random.choice(agenda_pool),
                "status": "rising",
            })
            events.append({
                "type": "faction_event",
                "name": "新势力崛起",
                "narrative": f"听说有一个叫{new_name}的新势力在苍云山脉出现了，"
                           f"不知道是什么来头",
                "impact": "medium",
                "affected_factions": [new_id],
            })

        # 生成清风观的影响事件（势力博弈对清风观的渗透）
        qingfeng = self.factions.get("qingfeng_guan")
        if qingfeng and events:
            # 选一个最近的势力事件，检查是否影响清风观
            for evt in events:
                if evt["impact"] == "high" or (evt["impact"] == "medium"
                                               and random.random() < 0.3):
                    return self._generate_local_impact(evt, era, day)

        return None

    def _generate_local_impact(self, global_event: dict, era: str,
                                day: int) -> dict:
        """将全局势力事件转化为清风观附近的本地影响"""
        impact_templates = {
            "faction_event": [
                "王大娘带来了一个让人不安的消息：{detail}",
                "大师兄从青石镇回来，脸色很不好，说{detail}",
                "师叔让大家今天不要下山，因为{detail}",
                "有个逃难的人跑到了山门口，说{detail}",
                "青云师姐听说了一些事情，跟师叔谈了好久，好像是关于{detail}",
            ],
            "era_transition": [
                "山下的气氛变了。{detail}",
                "王大娘说最近外面不太平，{detail}",
            ],
        }

        evt_type = global_event.get("type", "faction_event")
        templates = impact_templates.get(evt_type, impact_templates["faction_event"])

        detail = global_event.get("narrative", "外面出了事")

        return {
            "type": "local_impact",
            "name": f"远方的影响：{global_event.get('name', '未知')}",
            "narrative": random.choice(templates).format(detail=detail),
            "impact": "medium",
            "source_event": global_event.get("name"),
        }

    def get_world_pressure_index(self, era: str) -> dict:
        """计算世界压力指数"""
        active = [f for f in self.factions.values() if f.status == "active"]

        if not active:
            return {"composite": 0.0}

        powers = sorted([f.power for f in active], reverse=True)

        # 势力失衡度
        if len(powers) >= 2:
            imbalance = abs(powers[0] - powers[1]) / max(powers[0], 1)
        else:
            imbalance = 0.5

        # 内部不稳定度
        avg_stability = sum(f.internal_stability for f in active) / len(active)
        instability = 1.0 - avg_stability

        # 敌对关系数
        total_enemies = sum(len(f.enemies) for f in active)

        composite = (
            imbalance * 0.3 +
            instability * 0.3 +
            min(total_enemies / 10, 1.0) * 0.2 +
            (0.5 if era in ("动乱爆发", "乱世纷争") else
             0.3 if era == "暗流涌动" else 0.1) * 0.2
        )
        composite = max(0.0, min(1.0, composite + random.uniform(-0.02, 0.02)))

        return {
            "faction_imbalance": round(imbalance, 3),
            "instability": round(instability, 3),
            "hostility": min(total_enemies / 10, 1.0),
            "composite": round(composite, 3),
        }


# ============================================================
# 叙事融合引擎
# ============================================================

class NarrativeEngine:
    """叙事弧线管理 — 从名著模式中生成并推进叙事"""

    def __init__(self, saved_arcs: list = None):
        self.active_arcs: list[dict] = saved_arcs or []
        self.arc_counter = len(self.active_arcs)

    def to_dict(self) -> list:
        return self.active_arcs

    def tick(self, day: int, era: str, npcs: dict,
             factions: dict) -> Optional[dict]:
        """检查叙事种子的生长，可能生成新事件"""

        # 可能萌生新的叙事弧线（太平盛世大幅降低概率）
        spawn_prob = 0.08
        if era == "太平盛世":
            spawn_prob = 0.02   # 太平时很少萌生叙事弧线
        elif era == "暗流涌动":
            spawn_prob = 0.05
        if random.random() < spawn_prob:
            new_arc = self._try_spawn_arc(day, era, npcs, factions)
            if new_arc:
                self.active_arcs.append(new_arc)
                return {
                    "type": "narrative_seed",
                    "name": f"叙事种子：{new_arc['pattern_name']}",
                    "narrative": new_arc.get("seed_narrative", ""),
                    "impact": "low",
                }

        # 推进现有弧线
        for arc in self.active_arcs:
            if arc["status"] != "active":
                continue

            arc_day = day - arc["seed_day"]
            catalyst_range = arc.get("catalyst_day_range", [10, 50])
            climax_range = arc.get("climax_day_range", [30, 100])

            # 催化阶段
            if catalyst_range[0] <= arc_day <= catalyst_range[1]:
                if random.random() < 0.1:  # 每天约10%
                    event = self._generate_catalyst_event(arc, day, era, npcs, factions)
                    if event:
                        arc["status"] = "catalyzing"
                        return event

            # 高潮阶段
            if arc_day >= climax_range[0]:
                if random.random() < 0.06:
                    event = self._generate_climax_event(arc, day, era, npcs, factions)
                    if event:
                        arc["status"] = "climax"
                        return event

        # 清理已完成的弧线
        self.active_arcs = [a for a in self.active_arcs if a["status"] != "resolved"]

        return None

    def _try_spawn_arc(self, day: int, era: str, npcs: dict,
                       factions: dict) -> Optional[dict]:
        """尝试萌生一个新的叙事弧线"""
        # 选择适合当前时代的叙事模式
        candidates = []
        for pid, pattern in NARRATIVE_PATTERNS.items():
            if era in pattern.get("era_tendency", []):
                candidates.append((pid, pattern))

        if not candidates:
            candidates = list(NARRATIVE_PATTERNS.items())

        # 加权随机选择
        pids = [c[0] for c in candidates]
        weights = [c[1].get("weight", 5) for c in candidates]
        chosen_pid = random.choices(pids, weights=weights, k=1)[0]
        pattern = NARRATIVE_PATTERNS[chosen_pid]

        self.arc_counter += 1
        arc_id = f"NA_{self.arc_counter:03d}"

        # 选择涉及的NPC
        npc_ids = list(npcs.keys())
        involved = random.sample(npc_ids, min(random.randint(1, 3), len(npc_ids)))

        # 生成种子叙事
        seed_narratives = {
            "tragic_reversal": "最近{npc}好像察觉到了什么不对劲的地方，但又说不清楚",
            "heros_journey": "{npc}最近变得有些不同了，好像在酝酿什么",
            "family_rise_fall": "观里的气氛最近有些微妙，大家说话都小心翼翼的",
            "power_struggle": "外面传来消息说几个势力之间出了问题，不知道会不会影响到这里",
            "heroes_emerge": "有人说起了一个从未听说过的人，据说做了件很了不起的事",
            "betrayal": "师叔最近特别警惕，好像在防备什么",
            "plague_faith": "远方传来了一些让人不安的传闻",
            "exile_return": "有人在山门外徘徊了很久，看起来很疲惫",
            "forbidden_secret": "{npc}最近总是去{place}，不知道在找什么",
            "revenge_redemption": "最近有些陌生的面孔出现在青石镇，看起来不太友善",
        }

        narrative = seed_narratives.get(chosen_pid, "空气中弥漫着一股不安的味道")

        # 替换模板变量
        if involved:
            npc = npcs.get(involved[0])
            if npc:
                npc_name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
                narrative = narrative.replace("{npc}", npc_name)

        narrative = narrative.replace("{place}", random.choice(
            ["藏经阁", "后山", "丹房后面", "井边", "老槐树下"]))

        return {
            "id": arc_id,
            "pattern": chosen_pid,
            "pattern_name": pattern["name"],
            "status": "active",
            "involved_npcs": involved,
            "seed_narrative": narrative,
            "seed_day": day,
            "catalyst_day_range": [day + random.randint(5, 20),
                                   day + random.randint(15, 50)],
            "climax_day_range": [day + random.randint(20, 60),
                                 day + random.randint(50, 120)],
        }

    def _generate_catalyst_event(self, arc: dict, day: int, era: str,
                                  npcs: dict, factions: dict = None) -> Optional[dict]:
        """生成催化事件——叙事弧线开始加速"""
        pattern = NARRATIVE_PATTERNS.get(arc["pattern"], {})
        templates = pattern.get("catalyst_templates", [])

        if not templates:
            return None

        template = random.choice(templates)
        narrative = self._fill_arc_template(template, arc, npcs, factions)

        return {
            "type": "narrative_catalyst",
            "name": f"叙事催化：{arc['pattern_name']}",
            "narrative": narrative,
            "impact": pattern.get("impact", "medium"),
            "arc_id": arc["id"],
        }

    def _generate_climax_event(self, arc: dict, day: int, era: str,
                                npcs: dict, factions: dict) -> Optional[dict]:
        """生成高潮事件——叙事弧线的关键时刻"""
        pattern = NARRATIVE_PATTERNS.get(arc["pattern"], {})

        # Prefer dedicated climax_templates if available
        templates = pattern.get("climax_templates", [])
        if templates:
            template = random.choice(templates)
            narrative = self._fill_arc_template(template, arc, npcs, factions)
        else:
            # Fall back to catalyst templates but make them more dramatic
            catalyst_templates = pattern.get("catalyst_templates", [])
            if not catalyst_templates:
                return None

            template = random.choice(catalyst_templates)
            base_narrative = self._fill_arc_template(template, arc, npcs, factions)

            # Add dramatic intensifiers and consequences
            intensifiers = [
                "事态急转直下——",
                "局势骤然升级——",
                "一切在那一刻爆发了——",
                "命运终于露出了它的真面目——",
                "所有人的命运都被改写了——",
            ]
            consequences = [
                "这一切再也无法回头了。",
                "从此以后，一切都不同了。",
                "清风观的命运被永远改变了。",
                "没有人能预料到事情会变成这样。",
                "这一切的后果，还要很久才能看清。",
            ]
            narrative = random.choice(intensifiers) + base_narrative + random.choice(consequences)

        arc["status"] = "resolved"

        return {
            "type": "narrative_climax",
            "name": f"叙事高潮：{arc['pattern_name']}",
            "narrative": narrative,
            "impact": "high",
            "arc_id": arc["id"],
        }

    def _fill_arc_template(self, template: str, arc: dict, npcs: dict,
                            factions: dict = None) -> str:
        """填充叙事模板"""
        result = template

        # Build dynamic faction name lists from actual faction system
        if factions:
            faction_names = [f["name"] for f in factions.values()
                           if f.get("name") != "清风观" and f.get("status") == "active"]
            if not faction_names:
                faction_names = ["白莲教", "正道联盟", "朝廷", "坐忘道", "地方豪强"]
        else:
            faction_names = ["白莲教", "正道联盟", "朝廷", "坐忘道", "地方豪强"]

        # 替换faction
        result = result.replace("{faction}", random.choice(faction_names))
        if len(faction_names) >= 2:
            a_b = random.sample(faction_names, 2)
            result = result.replace("{faction_a}", a_b[0])
            result = result.replace("{faction_b}", a_b[1])
        else:
            result = result.replace("{faction_a}", faction_names[0])
            result = result.replace("{faction_b}", "某个大门派")

        # 替换NPC
        involved = arc.get("involved_npcs", [])
        if involved:
            npc = npcs.get(involved[0])
            if npc:
                npc_name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
                result = result.replace("{npc}", npc_name)

        # 替换pool变量
        def replace_pool(match):
            key = match.group(1)
            pattern_data = NARRATIVE_PATTERNS.get(arc["pattern"], {})
            pools = {
                "detail": pattern_data.get("detail_pool", ["..."]),
                "treason": pattern_data.get("treason_pool", ["..."]),
                "treason_type": pattern_data.get("treason_pool", ["..."]),
                "person": pattern_data.get("person_pool", ["人"]),
                "place": pattern_data.get("place_pool", ["某处"]),
                "title": pattern_data.get("title_pool", ["高手"]),
                "resource": pattern_data.get("resource_pool", ["宝物"]),
                "disaster": pattern_data.get("disaster_pool", ["灾难"]),
                "symptom": pattern_data.get("symptom_pool", ["怪病"]),
                "phenomenon": pattern_data.get("phenomenon_pool", ["异象"]),
                "crime": pattern_data.get("crime_pool", ["罪行"]),
                "leader": ["掌门", "长老", "教主", "盟主"],
                "settlement": pattern_data.get("settlement_pool", ["据点"]),
            }
            pool = pools.get(key, ["..."])
            return random.choice(pool) if pool else "..."

        result = re.sub(r'\{(\w+)\}', replace_pool, result)
        return result


# ============================================================
# 异常事件池（保留v4.0的，但增强）
# ============================================================

ANOMALY_EVENTS = [
    {
        "name": "奇怪的鸟飞过",
        "tpl": "{npc}看到一只从来没见过的{adj}的鸟从头顶飞过，{reaction}",
        "npc": ["师叔", "大师兄", "青云师姐", "小石头"],
        "adj": ["火红羽毛", "银白", "漆黑如墨", "翠绿", "金色", "三只眼睛", "体型巨大"],
        "reaction": ["不知道是什么品种", "追了好远没追上", "第二天又出现了", "之后再也没有见过"],
    },
    {
        "name": "不速之客",
        "tpl": "一个{adj}的{person}在山门外徘徊了好久，{result}",
        "adj": ["衣衫褴褛", "穿着华丽", "满脸胡子", "非常年轻", "很老了", "浑身是伤"],
        "person": ["男人", "女人", "道士", "和尚", "猎人", "商人"],
        "result": ["最后又走了", "师叔出去跟他说了句话", "留下了一样东西就走了", "倒在山门口被人发现了", "天黑后才离开"],
    },
    {
        "name": "奇怪的声音",
        "tpl": "半夜{location}传来奇怪的声音，像{sound}，{reaction}",
        "location": ["后山", "竹林", "丹房方向", "山门", "地下"],
        "sound": ["有人在哭", "野兽低吼", "金属碰撞", "念经声", "风铃声", "水滴声", "石头摩擦"],
        "reaction": ["第二天去查看什么都没有", "师叔的脸色变得很差", "小石头吓得不敢出房门", "之后几天又出现了几次", "大师兄拿着刀出去巡视了一圈"],
    },
    {
        "name": "团团的异常行为",
        "tpl": "团团今天{behavior}，{reaction}",
        "behavior": ["一直盯着一个方向一动不动", "突然跑出去了好远", "浑身炸毛冲着后山低吼",
                     "叼来一个奇怪的东西", "一夜没回来", "对着空气扑", "趴在师叔门口不肯走"],
        "reaction": ["大家都有点担心", "谁也没在意", "师叔看了它一眼什么都没说",
                     "小石头觉得好玩追着它跑", "之后几天团团一直很不安"],
    },
    {
        "name": "物品异常",
        "tpl": "{who}发现{object}不见了，后来在{place}找到了，{detail}",
        "who": ["师叔", "青云师姐", "大师兄", "淼淼"],
        "object": ["一本书", "一瓶药", "一个法器", "一封信", "一把钥匙", "一块玉佩", "一卷帛书"],
        "place": ["后山", "柴房角落", "团团的窝里", "藏经阁二楼", "小石头床底下",
                  "井边", "老槐树的树洞里", "丹房暗格中"],
        "detail": ["上面有奇怪的字", "好像被人动过", "多了一张纸条", "位置跟之前不一样了", "旁边有一些灰尘的痕迹"],
    },
    {
        "name": "天气异常",
        "tpl": "今天天气很奇怪——{weather}",
        "weather": ["明明是晴天却下了几滴雨", "突然刮了一阵很温暖的风",
                     "天边出现了奇怪的云", "大晴天的局部在下雪",
                     "打了一个很响的雷但没下雨", "日头是绿色的", "风里带着一股甜味",
                     "天空出现了一圈光晕"],
    },
    {
        "name": "灵气异动",
        "tpl": "{who}感觉到今天的灵气{desc}，{reaction}",
        "who": ["师叔", "青云师姐", "大师兄"],
        "desc": ["比平时浓了好多", "流动方向变了", "突然变得很混乱",
                 "好像被什么东西吸引着往一个方向涌", "有一瞬间完全消失了",
                 "带着一股说不出的寒意"],
        "reaction": ["师叔让大家今天不要修炼", "观察了一整天也没弄明白",
                     "拿出了罗盘测算", "在观里走了一圈做记号"],
    },
    {
        "name": "梦中启示",
        "tpl": "{who}昨晚做了一个很奇怪的梦，{reaction}",
        "who": ["师叔", "青云师姐", "大师兄", "小石头"],
        "reaction": ["但不愿意跟别人说", "说了一些让人听不懂的话",
                     "醒来后心情很不好", "醒来后一直在发呆",
                     "画了一些奇怪的符号", "跟师叔说了好久"],
    },
    {
        "name": "植物异常",
        "tpl": "后院{plant}今天{change}，{reaction}",
        "plant": ["菜园里的菜", "老槐树", "后山的竹林", "墙角的野花", "井边的草", "丹房前的灵草"],
        "change": ["突然开了一大堆花", "一夜之间长高了不少", "叶子全部变了颜色",
                   "枯萎了一半", "发出了淡淡的光", "变得特别茂盛"],
        "reaction": ["师叔看了一眼什么都没说", "小石头觉得好玩摘了一把",
                     "青云师姐查了书说不出个所以然", "第二天又恢复了正常"],
    },
    {
        "name": "外来消息",
        "tpl": "王大娘带来了一个消息：{news}，{reaction}",
        "news": ["隔壁村有人失踪了", "官府在招兵", "听说南方发大水了",
                 "有个大门派在收弟子", "山那边发现了一个洞",
                 "有人在卖很便宜的灵石", "路上遇到了仙人", "某个地方闹鬼了",
                 "听说朝廷换了皇帝", "有商队从很远的地方来了",
                 "有人在找一种稀有的药材"],
        "reaction": ["师叔听完脸色变了", "大家议论了好久", "谁也没当回事",
                     "大师兄若有所思", "小石头想去看看被师叔骂了"],
    },
    {
        "name": "动物异常",
        "tpl": "今天{animal}出现在观附近，{behavior}，{reaction}",
        "animal": ["一只鹿", "一群乌鸦", "一条蛇", "一只狐狸", "一群蜜蜂",
                   "一只白鹤", "几只野兔", "一只黑猫"],
        "behavior": ["看起来不怕人", "围着一个地方转圈", "从山上跑下来又跑回去了",
                     "死在路边", "看起来受了伤", "在观门口待了一天",
                     "叼着什么东西"],
        "reaction": ["师叔说这是不祥之兆", "小石头想抓来养", "青云师姐说以前从没见过",
                     "团团冲着它炸毛", "大家看了半天也不知道怎么回事"],
    },
    {
        "name": "遗迹发现",
        "tpl": "{who}在{place}发现了一些{adj}的痕迹，{reaction}",
        "who": ["大师兄", "小石头", "青云师姐", "王大娘"],
        "place": ["后山深处", "溪流上游", "山洞里", "崖壁上", "古树下", "井底"],
        "adj": ["很古老", "像是某种阵法", "人为刻画", "非常规整", "不像是自然形成", "血红色的"],
        "reaction": ["师叔去看了之后沉默了很久", "大家都不敢靠近", "小石头用手摸了摸什么都没发生",
                     "大师兄说感觉很不好", "之后师叔让大家不要再去那里"],
    },
    {
        "name": "修为异常",
        "tpl": "{who}今天修炼时{desc}，{reaction}",
        "who": ["师叔", "大师兄", "青云师姐"],
        "desc": ["突然突破了", "走火了", "功法好像出了问题",
                 "感觉到一股陌生的力量", "灵气完全凝不起来了",
                 "听到了一个声音"],
        "reaction": ["师叔让大家不要声张", "把自己关在房间里",
                     "跟师叔谈了很久", "之后的几天状态都不太好"],
    },
    {
        "name": "有人来访",
        "tpl": "今天来了一个{adj}的{role}，{desc}",
        "adj": ["很年轻", "很老", "很奇怪", "很和善", "很冷漠", "带着伤"],
        "role": ["道士", "修士", "商人", "书生", "猎户", "尼姑", "小孩"],
        "desc": ["向师叔请教了几个问题就走了", "说是路过借点水喝",
                 "跟师叔说了好久的话", "留下了一样东西",
                 "说了一些很奇怪的话", "看了看观里的格局就走了",
                 "好像是来找人的但没找到"],
    },
    {
        "name": "意外发现",
        "tpl": "{who}在{place}{discover}，{reaction}",
        "who": ["小石头", "大师兄", "青云师姐"],
        "place": ["柴房", "后院", "后山", "溪边", "藏经阁", "丹房后面"],
        "discover": ["发现了一个暗格", "找到了一封信", "发现墙上有字",
                     "发现地上的石头排列很奇怪", "翻到了一张旧地图",
                     "发现地板是空的", "找到了一具白骨"],
        "reaction": ["不敢告诉别人", "偷偷告诉了师姐", "师叔知道后表情很复杂",
                     "大家都很害怕", "之后的几天谁也不敢去那里"],
    },
    {
        "name": "灵脉感应",
        "tpl": "今天清风观附近的灵脉{change}，{reaction}",
        "change": ["突然变强了", "好像移动了", "出现了一个新的分支",
                   "跟平时完全不一样", "有一瞬间断了"],
        "reaction": ["师叔在观里走了一圈做记号", "所有人的修炼效率都变了",
                     "丹房里的药材生长速度变快了", "团团一直盯着一个方向"],
    },
    {
        "name": "时空错觉",
        "tpl": "{who}今天{desc}，{reaction}",
        "who": ["小石头", "大师兄", "青云师姐", "师叔"],
        "desc": ["说看到了不属于这里的东西", "说好像听到了有人在叫他的名字",
                 "走了一段路发现自己回到了原地", "说刚才明明是白天怎么天黑了"],
        "reaction": ["大家觉得他太累了", "师叔的表情变得很严肃",
                     "之后几天那个人都有些恍惚", "谁也没放在心上"],
    },
]


# ============================================================
# 因果涟漪系统（增强版）
# ============================================================

class Ripple:
    def __init__(self, source: str, target_npcs: list, effect_type: str,
                 magnitude: float, decay_days: int):
        self.source = source
        self.target_npcs = target_npcs
        self.effect_type = effect_type
        self.magnitude = magnitude
        self.decay_days = decay_days
        self.days_remaining = decay_days

    def get_effect(self) -> float:
        if self.days_remaining <= 0:
            return 0
        return self.magnitude * (self.days_remaining / self.decay_days)

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "target_npcs": self.target_npcs,
            "effect_type": self.effect_type,
            "magnitude": self.magnitude,
            "decay_days": self.decay_days,
            "days_remaining": self.days_remaining,
        }


# ============================================================
# NPC 智能体（增强版 - 加入命运系统）
# ============================================================

class NPCClone:
    def __init__(self, profile: dict):
        self.id = profile["id"]
        self.name = profile["name"]
        self.role = profile["role"]
        self.personality = dict(profile["personality"])
        self.mood_base = profile.get("mood_base", 60)
        self.mood = self.mood_base
        self.energy = 80
        self.default_location = profile.get("default_location", "清风观")
        self.location = self.default_location
        self.today_action = None
        self.today_narrative = None
        self.streak_same_action = 0
        self.last_action_name = None
        self.personality_drift: dict[str, float] = {}

        # v5.0 命运系统
        self.destiny = {
            "fate_arc": "neutral",
            "life_stage": "stable",
            "external_pressure": 0.0,
            "internal_conflict": 0.0,
            "alive": True,
        }

        self.relationships = {}
        for other_id, rel in profile.get("relationships", {}).items():
            self.relationships[other_id] = {
                "affinity": rel["affinity"],
                "dynamic": rel["dynamic"],
            }

        self.activities = deepcopy(profile.get("activities", []))
        self.arc = profile.get("arc", {})

    def daily_reset(self):
        self.energy = min(100, self.energy + 25)
        diff = self.mood_base - self.mood
        self.mood += int(diff * 0.15)
        self.mood = max(0, min(100, self.mood))
        self.today_action = None
        self.today_narrative = None

        # Personality drift decay (2% per day)
        decayed_traits = []
        for trait in list(self.personality_drift.keys()):
            self.personality_drift[trait] *= 0.98
            if abs(self.personality_drift[trait]) < 0.001:
                decayed_traits.append(trait)
        for trait in decayed_traits:
            del self.personality_drift[trait]

    def get_effective_personality(self) -> dict:
        result = dict(self.personality)
        for trait, drift in self.personality_drift.items():
            if trait in result:
                result[trait] = max(0, min(1, result[trait] + drift))
        return result

    def apply_experience(self, event_type: str, magnitude: float):
        drift_map = {
            "trauma": {"胆小": 0.03, "调皮": -0.01, "沉默": 0.02, "隐忍": 0.01},
            "success": {"稳重": 0.02, "自卑": -0.02, "自信": 0.02, "抱负": 0.01},
            "loss": {"沉默": 0.02, "活力": -0.01, "焦虑": 0.02},
            "bond": {"善良": 0.01, "护短": 0.01, "温柔": 0.01},
            "discovery": {"好奇": 0.02, "抱负": 0.01, "智慧": 0.01},
            "conflict": {"焦虑": 0.02, "严厉": 0.01, "沉默": 0.01},
            "wonder": {"好奇": 0.03, "调皮": 0.01},
        }
        drifts = drift_map.get(event_type, {})
        for trait, delta in drifts.items():
            current = self.personality_drift.get(trait, 0)
            self.personality_drift[trait] = current + delta * magnitude

    def choose_action(self, day: int, season: str, weather: str,
                      world_pressure: float = 0.0,
                      era: str = "太平盛世") -> dict:
        eff_p = self.get_effective_personality()
        candidates = []

        for act in self.activities:
            weight = act.get("weight", 10)

            cond = act.get("condition", {})
            if cond.get("min_day", 0) > day:
                continue
            if "random_low" in cond and random.random() > cond["random_low"]:
                continue

            if weather in ("暴雨", "大雪", "酷暑"):
                if act["location"] not in ("前殿", "东厢房", "西厢房", "丹房"):
                    weight *= 0.3

            for trait, factor in act.get("traits_boost", {}).items():
                trait_val = eff_p.get(trait, 0.5)
                weight *= (1.0 + (trait_val - 0.5) * factor)

            if self.mood < 30:
                if act.get("effects", {}).get("mood", 0) < -5:
                    weight *= 0.4
                else:
                    weight *= 1.2
            elif self.mood > 85:
                weight *= 1.1

            # 外部压力和时代影响
            if era in ("动乱爆发", "乱世纷争"):
                if any(t in act["name"] for t in ("修炼", "练刀", "巡视", "练功", "指导")):
                    weight *= 1.8
                if any(t in act["name"] for t in ("偷吃", "捣乱", "抓虫", "晒太阳")):
                    weight *= 0.3
            elif world_pressure > 0.5:
                if any(t in act["name"] for t in ("修炼", "练刀", "巡视", "练功", "指导")):
                    weight *= 1.5
                if any(t in act["name"] for t in ("偷吃", "捣乱", "抓虫", "晒太阳")):
                    weight *= 0.4

            if self.last_action_name == act["name"]:
                self.streak_same_action += 1
                weight *= max(0.15, 1.0 / (self.streak_same_action * 0.9))
            else:
                self.streak_same_action = 0

            candidates.append((act, max(weight, 0.05)))

        if not candidates:
            return self._fallback_action()

        total = sum(w for _, w in candidates)
        r = random.uniform(0, total)
        cumulative = 0
        for act, w in candidates:
            cumulative += w
            if r <= cumulative:
                self.today_action = act
                self.last_action_name = act["name"]
                return act

        chosen = candidates[-1]
        self.today_action = chosen[0]
        self.last_action_name = chosen[0]["name"]
        return chosen[0]

    def _fallback_action(self):
        fb = [
            {"name": "在院子里闲逛", "location": "院子里", "effects": {"mood": 0, "energy": -3}},
            {"name": "发呆", "location": self.location, "effects": {"mood": -2}},
            {"name": "休息", "location": self.default_location, "effects": {"mood": 2, "energy": 10}},
            {"name": "在房间里待着", "location": self.default_location, "effects": {"mood": 1}},
        ]
        act = random.choice(fb)
        self.today_action = act
        self.last_action_name = act["name"]
        return act

    def execute_action(self, action: dict):
        effects = action.get("effects", {})
        mood_fx = effects.get("mood", 0) + random.randint(-4, 4)
        self.mood = max(0, min(100, self.mood + mood_fx))
        self.energy = max(0, min(100, self.energy + effects.get("energy", 0)))
        if action.get("location"):
            self.location = action["location"]
        self.today_narrative = self._compose_narrative(action)

    def _compose_narrative(self, action: dict) -> str:
        name = self.name.split("·")[-1] if "·" in self.name else self.name
        base = action.get("narrative", "")

        if base and random.random() < 0.3:
            manner = random.choice(MANNERS)
            if base.startswith(name):
                return f"{name}{manner}{base[len(name):]}"
            return f"{name}{manner}{base}"

        loc = action.get("location", self.location)
        loc_opts = LOCATION_MODS.get(loc, [loc])

        structure = random.choice(["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8"])

        if structure == "S1":
            return f"{name}{random.choice(MANNERS)}在{random.choice(loc_opts)}{action['name']}"
        elif structure == "S2":
            return f"{random.choice(TIME_MODS)}{name}{action['name']}，{random.choice(EMOTIONS)}"
        elif structure == "S3":
            return f"{name}今天{action['name']}，{random.choice(DETAILS)}"
        elif structure == "S4":
            return f"{name}{action['name']}，{random.choice(CONSEQUENCES)}"
        elif structure == "S5":
            return f"在{random.choice(loc_opts)}，{name}{random.choice(MANNERS)}{action['name']}，{random.choice(EMOTIONS)}"
        elif structure == "S6":
            return f"{random.choice(TIME_MODS)}看到{name}在{random.choice(loc_opts)}{action['name']}，{random.choice(DETAILS)}"
        elif structure == "S7":
            return f"{name}去了{random.choice(loc_opts)}{action['name']}，{random.choice(CONSEQUENCES)}，{random.choice(EMOTIONS)}"
        elif structure == "S8":
            return f"{name}在{random.choice(loc_opts)}{action['name']}"

        return f"{name}{action['name']}"


# ============================================================
# 世界模拟器 v5.0
# ============================================================

class WorldSim:
    """世界模拟引擎 v5.0 — 史诗历史引擎"""

    def __init__(self, state: dict, npc_profiles: dict):
        self.state = state
        self.day = state["meta"]["story_day"]
        self.npcs: dict[str, NPCClone] = {}
        self.world_timeline = npc_profiles.get("world_events_timeline", [])

        # v5.0 新系统
        wh = state.get("world_history", {})
        self.era_cycle = EraCycle(self.day, wh.get("current_era"))
        self.faction_system = FactionSystem(wh.get("factions"))
        self.narrative_engine = NarrativeEngine(state.get("active_narrative_arcs"))

        # v4.0 兼容
        self.world_pressure = state.get("world_pressure", 0.0)
        self.triggered_world_events: list[str] = state.get("triggered_world_events", [])
        self.recent_anomaly_names: list[str] = state.get("recent_anomaly_names", [])
        self.ripples: list[Ripple] = []

        # 初始化NPC
        for npc_id, profile in npc_profiles.get("npcs", {}).items():
            npc = NPCClone(profile)
            saved = state.get("npc_states", {}).get(npc_id)
            if saved:
                npc.mood = saved.get("mood", npc.mood_base)
                npc.energy = saved.get("energy", 80)
                npc.location = saved.get("location", npc.default_location)
                npc.last_action_name = saved.get("last_action_name")
                npc.streak_same_action = saved.get("streak_same_action", 0)
                npc.personality_drift = saved.get("personality_drift", {})
                if saved.get("destiny"):
                    npc.destiny.update(saved["destiny"])
                if saved.get("relationships"):
                    for k, v in saved["relationships"].items():
                        if k in npc.relationships:
                            npc.relationships[k]["affinity"] = v.get("affinity",
                                npc.relationships[k]["affinity"])
            self.npcs[npc_id] = npc

        # 恢复涟漪
        for rd in state.get("active_ripples", []):
            self.ripples.append(Ripple(
                source=rd["source"],
                target_npcs=rd["target_npcs"],
                effect_type=rd["effect_type"],
                magnitude=rd["magnitude"],
                decay_days=rd["decay_days"],
            ))
            self.ripples[-1].days_remaining = rd.get("days_remaining", rd["decay_days"])

    def simulate_day(self) -> dict:
        """模拟一天的世界演化"""
        self.day += 1
        events = []

        season = self._get_season(self.day)
        weather = self._generate_weather(season)
        era = self.era_cycle.current_era

        # 世界压力指数
        wpi = self.faction_system.get_world_pressure_index(era)
        self.world_pressure = wpi["composite"]

        # 1. 历史周期tick
        era_event = self.era_cycle.tick(self.day, wpi)
        if era_event:
            events.append(era_event)
            era = self.era_cycle.current_era

        # 2. 势力博弈tick（每10天）
        faction_event = self.faction_system.tick(era, self.day)
        if faction_event:
            events.append(faction_event)

        # 3. 叙事引擎tick
        narrative_event = self.narrative_engine.tick(
            self.day, era, self.npcs, self.faction_system.to_dict())
        if narrative_event:
            events.append(narrative_event)

        # 4. 应用活跃涟漪
        self._apply_ripples()

        # 5. 世界背景事件（v4.0兼容）
        world_evt = self._check_world_events()
        if world_evt:
            events.append(world_evt)

        # 6. 异常注入
        anomaly = self._inject_anomaly(season)
        if anomaly:
            events.append(anomaly)

        # 7. 涌现事件
        emergent = self._generate_emergent(season, weather, era)
        if emergent:
            events.append(emergent)

        # 8. NPC决策并行动
        npc_narratives = {}
        for npc_id, npc in self.npcs.items():
            if not npc.destiny["alive"]:
                npc_narratives[npc_id] = f"{npc.name}已经不在了"
                continue
            npc.daily_reset()
            action = npc.choose_action(self.day, season, weather,
                                       self.world_pressure, era)
            npc.execute_action(action)
            npc_narratives[npc_id] = npc.today_narrative

        # 9. NPC交互检测
        interaction_events = self._detect_interactions()
        events.extend(interaction_events)

        # 10. 世界事件影响NPC
        if world_evt:
            self._apply_world_event_effects(world_evt)

        # 11. 更新全局状态
        self.state["meta"]["story_day"] = self.day
        self.state["meta"]["season"] = season
        self.state["weather"]["today"] = weather

        # 12. 日志
        all_event_names = []
        for e in events:
            etype = e.get("type", "unknown")
            ename = e.get("name", "")
            all_event_names.append(f"[{etype}]{ename}")

        log_entry = {
            "day": self.day,
            "weather": weather,
            "era": era,
            "world_pressure": round(self.world_pressure, 3),
            "npc_activities": {nid: npc.today_action["name"] if npc.today_action else "休息"
                              for nid, npc in self.npcs.items()},
            "events": all_event_names,
            "interaction_events": [e["description"] for e in interaction_events],
            "narratives": npc_narratives,
        }
        self.state.setdefault("daily_log", []).append(log_entry)

        # 13. 衰减涟漪
        self._decay_ripples()

        return {
            "day": self.day,
            "weather": weather,
            "era": era,
            "era_theme": self.era_cycle.theme,
            "world_event": world_evt,
            "anomaly": anomaly,
            "emergent": emergent,
            "narrative_event": narrative_event,
            "faction_event": faction_event,
            "era_event": era_event,
            "npc_narratives": npc_narratives,
            "interaction_events": interaction_events,
            "world_pressure": self.world_pressure,
        }

    def simulate_days(self, n_days: int) -> list:
        summaries = []
        for _ in range(n_days):
            summaries.append(self.simulate_day())
        return summaries

    # ----------------------------------------------------------
    # === 涟漪系统 ===
    # ----------------------------------------------------------
    def _apply_ripples(self):
        for ripple in self.ripples:
            if ripple.days_remaining <= 0:
                continue
            fx = ripple.get_effect()
            for npc_id in ripple.target_npcs:
                npc = self.npcs.get(npc_id)
                if not npc:
                    continue
                if ripple.effect_type == "mood":
                    npc.mood = max(0, min(100, npc.mood + int(fx * 5)))
                elif ripple.effect_type == "anxiety":
                    npc.personality_drift["焦虑"] = npc.personality_drift.get("焦虑", 0) + fx * 0.005
                elif ripple.effect_type == "curiosity":
                    npc.personality_drift["好奇"] = npc.personality_drift.get("好奇", 0) + fx * 0.003

    def _decay_ripples(self):
        for r in self.ripples:
            r.days_remaining -= 1
        self.ripples = [r for r in self.ripples if r.days_remaining > 0]

    def add_ripple(self, source: str, target_npcs: list, effect_type: str,
                   magnitude: float, decay_days: int):
        self.ripples.append(Ripple(source, target_npcs, effect_type, magnitude, decay_days))

    # ----------------------------------------------------------
    # === 异常注入 ===
    # ----------------------------------------------------------
    def _inject_anomaly(self, season: str) -> Optional[dict]:
        era = self.era_cycle.current_era
        # 太平盛世几乎不会有异常，事件必须有因果
        base_prob = 0.015
        if era == "太平盛世":
            base_prob = 0.008   # 太平时极少异常
        elif era == "暗流涌动":
            base_prob = 0.02
        elif era in ("动乱爆发", "乱世纷争"):
            base_prob = 0.04
        prob = base_prob + self.world_pressure * 0.015
        if season == "冬天":
            prob += 0.01
        if self.day > 50:
            prob += 0.01

        if random.random() > prob:
            return None

        # 过滤最近用过的异常事件，避免重复
        available_anomalies = [a for a in ANOMALY_EVENTS
                              if a["name"] not in self.recent_anomaly_names]
        if not available_anomalies:
            available_anomalies = ANOMALY_EVENTS

        anomaly = random.choice(available_anomalies)
        # 记录已使用的异常事件名称，5天内不重复
        self.recent_anomaly_names.append(anomaly["name"])
        self.recent_anomaly_names = [n for n in self.recent_anomaly_names
                                      if n != anomaly["name"]][-5:]
        desc = self._fill_template(anomaly["tpl"], anomaly)

        npc_ids = [nid for nid in self.npcs if nid not in ("miao_miao_cat", "wang_daniang")]
        affected = random.sample(npc_ids, min(random.randint(1, 3), len(npc_ids)))

        result = {
            "type": "anomaly",
            "name": anomaly["name"],
            "description": desc,
            "affected_npcs": affected,
        }

        for nid in affected:
            npc = self.npcs.get(nid)
            if npc:
                npc.mood += random.randint(-5, 5)

        self.add_ripple(
            source=f"anomaly_{anomaly['name']}_{self.day}",
            target_npcs=affected,
            effect_type=random.choice(["mood", "anxiety", "curiosity"]),
            magnitude=random.uniform(0.3, 0.8),
            decay_days=random.randint(2, 6),
        )

        if random.random() < 0.2:
            for nid in affected:
                npc = self.npcs.get(nid)
                if npc:
                    npc.apply_experience("wonder", random.uniform(0.3, 0.7))

        return result

    # ----------------------------------------------------------
    # === 涌现事件 ===
    # ----------------------------------------------------------
    def _generate_emergent(self, season: str, weather: str,
                            era: str) -> Optional[dict]:
        emerged = None

        # 涌现事件的总控：太平盛世概率减半
        # "不能为了事件而事件"——只在条件充分时才触发
        era_modifier = 1.0
        if era == "太平盛世":
            era_modifier = 0.4  # 太平时涌现事件大幅减少
        elif era == "暗流涌动":
            era_modifier = 0.7

        shishu = self.npcs.get("shishu")
        if (shishu and self.world_pressure > 0.4 and shishu.mood < 45 
            and random.random() < 0.10 * era_modifier):
            pool = [
                "师叔今天把所有人都叫到前殿，表情很严肃，说了好多话",
                "师叔在山门设了一些东西，说最近不太平",
                "师叔一大早就出门了，说要去看看外面的情况",
                "师叔把自己关在丹房里不出来，谁也不知道发生了什么",
                "师叔让大师兄加强了夜间巡视，连小石头都被安排了值班",
                "师叔翻出了很多年前的东西，在院子里摆了一地",
            ]
            emerged = {"type": "emergent", "name": "师叔的应对",
                       "description": random.choice(pool)}
            self.world_pressure = min(1.0, self.world_pressure + 0.03)

        if not emerged:
            xst = self.npcs.get("xiaoshitou")
            qy = self.npcs.get("qingyun")
            if xst and qy:
                aff = xst.relationships.get("qingyun", {}).get("affinity", 50)
                if aff < 30 and random.random() < 0.08 * era_modifier:
                    pool = [
                        "小石头把青云师姐的东西弄坏了，青云师姐气了好久",
                        "小石头偷了青云师姐的东西，被逮了个正着",
                        "小石头又闯祸了，这次连大师兄都不帮他说话了",
                        "小石头往青云师姐的茶里放了盐，被发现了",
                    ]
                    emerged = {"type": "emergent", "name": "小石头和青云师姐的冲突",
                               "description": random.choice(pool)}

        if not emerged and weather in ("暴雨", "大雪", "酷暑"):
            if random.random() < 0.10 * era_modifier:
                pools = {
                    "暴雨": [
                        "下了一整天暴雨，后院淹了，大家忙了好久才排完水",
                        "暴雨把后山的路冲毁了，大师兄花了一天修路",
                        "雨太大了，厨房的屋顶漏了，师叔让大家一起修补",
                        "暴雨中闪电劈中了后山一棵老树，烧了一个大洞",
                    ],
                    "大雪": [
                        "下了好大一场雪，院子里积了一尺厚，小石头高兴坏了",
                        "雪太大封了山，王大娘上不来，观里粮食开始紧张",
                        "大雪压断了院子里的一棵老树枝，差点砸到人",
                        "大师兄一大早去铲雪，铲了一条路从山门到厨房",
                    ],
                    "酷暑": [
                        "太热了，小石头中暑了，青云师姐照顾了他一天",
                        "酷暑导致井水干了一半，大家只能省着用水",
                        "天气太热什么都干不了，大家躲在屋里扇扇子",
                        "师叔在丹房里炼了一炉防暑的药，给每个人都发了一份",
                    ],
                }
                pool = pools.get(weather, [])
                if pool:
                    emerged = {"type": "emergent", "name": "恶劣天气影响",
                               "description": random.choice(pool)}

        if not emerged:
            zmc = self.npcs.get("zhao_mingcheng")
            if zmc and zmc.mood < 35 and random.random() < 0.06 * era_modifier:
                pool = [
                    "大师兄今天一个人在后山待了很久，回来的时候眼圈红红的",
                    "大师兄练刀练到很晚，手都磨破了，谁劝都不听",
                    "大师兄跟师叔说想下山去看看，被师叔拒绝了",
                    "大师兄今天话格外少，连小石头跟他说话都不理",
                    "大师兄把所有人都赶回房间，自己一个人守了一夜山门",
                ]
                emerged = {"type": "emergent", "name": "大师兄状态异常",
                           "description": random.choice(pool)}

        if not emerged and len(self.ripples) >= 3 and random.random() < 0.08 * era_modifier:
            affected = set()
            for r in self.ripples:
                affected.update(r.target_npcs)
            if len(affected) >= 3:
                pool = [
                    "观里的气氛最近很奇怪，大家都不太说话",
                    "好几个人的状态都不太对，师叔让大家早点休息",
                    "今天观里特别安静，连小石头都没捣乱",
                    "不知道为什么，今天大家看彼此的眼神都有些警惕",
                    "几个人同时做了类似的噩梦，但谁也不愿意细说",
                ]
                emerged = {"type": "emergent", "name": "集体氛围异常",
                           "description": random.choice(pool)}

        if not emerged:
            cat = self.npcs.get("miao_miao_cat")
            if cat and random.random() < 0.03 * era_modifier:
                pool = [
                    "团团今天突然冲着后山大叫了好几声，声音很凄厉",
                    "团团一直蹲在师叔的门口不肯走，好像在守着什么",
                    "团团今天不吃东西，趴在一个地方一动不动，眼睛半睁半闭",
                    "半夜听到团团在屋顶上跑来跑去，好像在追什么东西",
                    "团团叼来了一块很奇怪的石头，上面有花纹，师叔看了一眼收走了",
                ]
                emerged = {"type": "emergent", "name": "团团的灵性感应",
                           "description": random.choice(pool)}

        if not emerged:
            if self.day > 30 and random.random() < 0.025 * era_modifier:
                npc_list = [n for nid, n in self.npcs.items()
                           if nid in ("qingyun", "zhao_mingcheng", "shishu") and n.mood > 60]
                if npc_list:
                    npc = random.choice(npc_list)
                    name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
                    pool = [
                        f"{name}今天修炼时有了一些感悟，看起来很高兴",
                        f"{name}修炼的时候身上好像有微光闪了一下，但一眨眼就没了",
                        f"{name}说最近修炼比以前顺了，不知道是不是错觉",
                        f"{name}修炼到了很晚，出来的时候表情很复杂",
                    ]
                    emerged = {"type": "emergent", "name": "修炼进展",
                               "description": random.choice(pool)}
                    npc.apply_experience("success", 0.5)

        # v5.0: 时代相关的涌现事件
        if not emerged and era == "乱世纷争" and random.random() < 0.06:
            pool = [
                "又有难民从山下经过了，这次比上次更多，看起来更惨",
                "远处传来了打斗的声音，大师兄说有人在山那边交战",
                "王大娘上来了，带着哭腔说村子出事了",
                "有人在青石镇看到了修士打架，死了好几个人",
                "师叔今天很早就把山门关了，让大家不要出去",
                "一群穿着不同门派服饰的人从山路上经过，个个带着伤",
            ]
            emerged = {"type": "emergent", "name": "乱世影响",
                       "description": random.choice(pool)}

        return emerged

    # ----------------------------------------------------------
    # === 模板填充 ===
    # ----------------------------------------------------------
    def _fill_template(self, template: str, data: dict) -> str:
        result = template
        placeholders = re.findall(r'\{(\w+)\}', template)
        for ph in placeholders:
            if ph in data and isinstance(data[ph], list):
                result = result.replace(f"{{{ph}}}", random.choice(data[ph]))
                continue
            if f"{ph}s" in data and isinstance(data[f"{ph}s"], list):
                result = result.replace(f"{{{ph}}}", random.choice(data[f"{ph}s"]))
                continue
            if f"{ph}_pool" in data and isinstance(data[f"{ph}_pool"], list):
                result = result.replace(f"{{{ph}}}", random.choice(data[f"{ph}_pool"]))
                continue
        return result

    # ----------------------------------------------------------
    # === 世界事件 ===
    # ----------------------------------------------------------
    def _check_world_events(self) -> Optional[dict]:
        for we in self.world_timeline:
            if we["id"] in self.triggered_world_events:
                continue
            if self.day < we["min_day"] or self.day > we["max_day"]:
                continue
            if random.random() < we.get("probability", 0.05):
                self.triggered_world_events.append(we["id"])
                impact = we.get("impact", "low")
                if impact == "high":
                    self.world_pressure = min(1.0, self.world_pressure + random.uniform(0.15, 0.25))
                elif impact == "medium":
                    self.world_pressure = min(1.0, self.world_pressure + random.uniform(0.08, 0.15))

                npc_fx = we.get("trigger_npc_effect", {})
                for nid in npc_fx:
                    self.add_ripple(
                        source=f"world_{we['id']}",
                        target_npcs=[nid],
                        effect_type="anxiety" if npc_fx[nid].get("mood", 0) < 0 else "mood",
                        magnitude=abs(npc_fx[nid].get("mood", 0)) / 15,
                        decay_days=random.randint(5, 15),
                    )
                return we
        return None

    def _apply_world_event_effects(self, event: dict):
        for npc_id, effects in event.get("trigger_npc_effect", {}).items():
            npc = self.npcs.get(npc_id)
            if not npc:
                continue
            npc.mood = max(0, min(100, npc.mood + effects.get("mood", 0)))
            if effects.get("behavior") == "increased_vigilance":
                npc.personality_drift["焦虑"] = npc.personality_drift.get("焦虑", 0) + 0.02
            elif effects.get("behavior") == "increased_training":
                npc.personality_drift["勤勉"] = npc.personality_drift.get("勤勉", 0) + 0.02

    # ----------------------------------------------------------
    # === NPC交互 ===
    # ----------------------------------------------------------
    def _detect_interactions(self) -> list:
        """NPC社交交互——基于性格、关系和共同经历自然涌现，不是简单位置碰撞"""
        events = []
        alive_npcs = [(nid, npc) for nid, npc in self.npcs.items()
                      if npc.destiny.get("alive", True) and npc.today_action]

        for i, (id_a, npc_a) in enumerate(alive_npcs):
            for id_b, npc_b in alive_npcs[i + 1:]:
                # === 虚拟演化：交互概率由多种因素自然涌现 ===

                # 因素1：位置接近度（仍为基础因素，但不是唯一因素）
                same_location = npc_a.location == npc_b.location
                nearby_location = False
                location_proximity = {
                    "练功场": ["院子里", "后院"],
                    "前殿": ["院子里", "山门"],
                    "丹房": ["后山", "后院"],
                    "藏经阁": ["西厢房", "东厢房"],
                    "厨房": ["后院", "西厢房"],
                    "后院": ["厨房", "院子里", "练功场", "丹房"],
                    "院子里": ["后院", "前殿", "练功场"],
                    "后山": ["丹房", "山门"],
                    "山门": ["前殿", "后山"],
                    "西厢房": ["东厢房", "藏经阁"],
                    "东厢房": ["西厢房", "藏经阁"],
                }
                if not same_location:
                    nearby_locs = location_proximity.get(npc_a.location, [])
                    if npc_b.location in nearby_locs:
                        nearby_location = True

                if not same_location and not nearby_location:
                    # 不在同一位置也不在附近，概率极低
                    if random.random() > 0.02:
                        continue

                # 因素2：关系亲和度——关系越好越容易互动
                aff_ab = npc_a.relationships.get(id_b, {}).get("affinity", 50)
                rel_modifier = aff_ab / 100.0  # 0~1

                # 因素3：性格互补性——互补性格更容易产生交互
                eff_a = npc_a.get_effective_personality()
                eff_b = npc_b.get_effective_personality()
                # 找共同高特质——有共鸣
                common_high = 0
                for trait in set(eff_a.keys()) & set(eff_b.keys()):
                    if eff_a[trait] > 0.7 and eff_b[trait] > 0.7:
                        common_high += 1
                # 找互补特质——有吸引
                complementary = 0
                complementary_pairs = [
                    ("严厉", "调皮"), ("温柔", "胆小"), ("勤勉", "自卑"),
                    ("护短", "善良"), ("隐忍", "抱负"), ("智慧", "好奇"),
                ]
                for t1, t2 in complementary_pairs:
                    if (eff_a.get(t1, 0) > 0.6 and eff_b.get(t2, 0) > 0.6) or \
                       (eff_a.get(t2, 0) > 0.6 and eff_b.get(t1, 0) > 0.6):
                        complementary += 1

                personality_mod = 0.5 + common_high * 0.1 + complementary * 0.15

                # 因素4：世界压力——乱世中人更倾向抱团或冲突
                era = self.era_cycle.current_era if hasattr(self, 'era_cycle') else "太平盛世"
                pressure_mod = 1.0
                if era in ("动乱爆发", "乱世纷争"):
                    # 乱世中：关系好的更容易互动（抱团），关系差的也更容易冲突
                    if aff_ab > 60:
                        pressure_mod = 1.5
                    elif aff_ab < 30:
                        pressure_mod = 1.3
                    else:
                        pressure_mod = 0.9

                # 因素5：共同经历涟漪——如果两人都被同一个涟漪影响，更容易互动
                shared_ripple = 0
                for ripple in self.ripples:
                    if id_a in ripple.target_npcs and id_b in ripple.target_npcs:
                        shared_ripple += 1
                ripple_mod = 1.0 + shared_ripple * 0.2

                # 综合交互概率
                base_prob = 0.3 if same_location else 0.08
                final_prob = base_prob * rel_modifier * personality_mod * pressure_mod * ripple_mod
                final_prob = max(0.01, min(0.85, final_prob))

                if random.random() > final_prob:
                    continue

                # === 根据关系深度和性格生成自然交互 ===
                if aff_ab > 70:
                    # 亲密关系：互动丰富，基于共同高特质
                    trait_based = []
                    if eff_a.get("温柔", 0) > 0.6 or eff_b.get("温柔", 0) > 0.6:
                        trait_based.extend([
                            f"{npc_a.name.split('·')[-1]}给{npc_b.name.split('·')[-1]}带了点东西，两人说了好久的话",
                            f"{npc_a.name.split('·')[-1]}帮{npc_b.name.split('·')[-1]}做了一件事，谁也没多说什么",
                        ])
                    if eff_a.get("护短", 0) > 0.6 or eff_b.get("护短", 0) > 0.6:
                        trait_based.extend([
                            f"{npc_a.name.split('·')[-1]}发现{npc_b.name.split('·')[-1]}不太对劲，一直跟在后面没走",
                        ])
                    if not trait_based:
                        trait_based = [
                            f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}聊得很开心",
                            f"{npc_a.name.split('·')[-1]}帮{npc_b.name.split('·')[-1]}做事情",
                        ]
                    templates = trait_based
                    delta = random.randint(1, 3)
                elif aff_ab > 40:
                    templates = [
                        f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}说了几句话",
                        f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}打了个招呼",
                    ]
                    delta = random.randint(-1, 2)
                elif aff_ab > 20:
                    # 关系差的：交互内容和性格有关
                    if eff_a.get("胆小", 0) > 0.5 or eff_b.get("胆小", 0) > 0.5:
                        templates = [
                            f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}碰了面，气氛有点尴尬",
                            f"{npc_a.name.split('·')[-1]}看到{npc_b.name.split('·')[-1]}就绕开了",
                        ]
                    else:
                        templates = [
                            f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}尴尬地碰面了",
                        ]
                    delta = random.randint(-2, 0)
                else:
                    # 敌对：基于性格产生不同类型的冲突
                    if eff_a.get("严厉", 0) > 0.6 and eff_b.get("调皮", 0) > 0.6:
                        templates = [
                            f"{npc_a.name.split('·')[-1]}训了{npc_b.name.split('·')[-1]}一顿，{npc_b.name.split('·')[-1]}瘪着嘴不服气",
                        ]
                    elif eff_a.get("护短", 0) > 0.6:
                        templates = [
                            f"{npc_a.name.split('·')[-1]}挡在前面不让{npc_b.name.split('·')[-1]}靠近",
                        ]
                    else:
                        templates = [
                            f"{npc_a.name.split('·')[-1]}和{npc_b.name.split('·')[-1]}好像吵了几句",
                            f"{npc_a.name.split('·')[-1]}故意绕开了{npc_b.name.split('·')[-1]}",
                        ]
                    delta = random.randint(-5, -1)

                events.append({
                    "type": "interaction",
                    "description": random.choice(templates),
                    "npcs": [id_a, id_b],
                })

                # 更新关系——但变化幅度受性格影响
                # 开放性格更容易改善关系，封闭性格关系更难变
                openness_a = 1.0 - eff_a.get("沉默", 0.5)
                openness_b = 1.0 - eff_b.get("沉默", 0.5)
                openness = (openness_a + openness_b) / 2
                actual_delta = int(delta * (0.5 + openness))

                if id_b in npc_a.relationships:
                    npc_a.relationships[id_b]["affinity"] = max(0, min(100,
                        npc_a.relationships[id_b]["affinity"] + actual_delta))
                if id_a in npc_b.relationships:
                    npc_b.relationships[id_a]["affinity"] = max(0, min(100,
                        npc_b.relationships[id_a]["affinity"] + actual_delta))

                # 交互后性格微调——互动会影响人
                if delta > 0:
                    npc_a.apply_experience("bond", 0.3)
                    npc_b.apply_experience("bond", 0.3)
                elif delta < -2:
                    npc_a.apply_experience("conflict", 0.3)
                    npc_b.apply_experience("conflict", 0.3)

        return events

    # ----------------------------------------------------------
    # === 天气和季节 ===
    # ----------------------------------------------------------
    def _get_season(self, day: int) -> str:
        # 每90天换一个季节
        season_idx = (day - 1) // 90
        seasons = ["春天", "夏天", "秋天", "冬天"]
        return seasons[season_idx % 4]

    def _generate_weather(self, season: str) -> str:
        weights = {
            "春天": {"晴": 40, "多云": 25, "阴": 15, "小雨": 12, "大雨": 5, "暴雨": 2, "大风": 1},
            "夏天": {"晴": 35, "多云": 20, "阴": 10, "小雨": 10, "大雨": 10, "暴雨": 8, "酷暑": 5, "雷暴": 2},
            "秋天": {"晴": 45, "多云": 25, "阴": 15, "小雨": 8, "大风": 5, "大雨": 2},
            "冬天": {"晴": 30, "多云": 20, "阴": 20, "小雨": 5, "大雪": 15, "大风": 8, "酷寒": 2},
        }
        era = self.era_cycle.current_era if hasattr(self, 'era_cycle') else "太平盛世"
        if era in ("动乱爆发", "乱世纷争"):
            # 乱世天气更极端
            w = weights.get(season, weights["春天"])
            bad_weather = {"暴雨": w.get("暴雨", 0) + 5, "大雨": w.get("大雨", 0) + 5}
            w.update(bad_weather)

        w = weights.get(season, weights["春天"])
        weathers = list(w.keys())
        ws = list(w.values())
        return random.choices(weathers, weights=ws, k=1)[0]

    # ----------------------------------------------------------
    # === 导出 ===
    # ----------------------------------------------------------
    def get_npc_state_for_export(self) -> dict:
        result = {}
        for nid, npc in self.npcs.items():
            result[nid] = {
                "mood": npc.mood, "energy": npc.energy,
                "location": npc.location, "last_action_name": npc.last_action_name,
                "streak_same_action": npc.streak_same_action,
                "personality_drift": npc.personality_drift,
                "destiny": npc.destiny,
                "relationships": {k: {"affinity": v["affinity"]}
                                  for k, v in npc.relationships.items()},
            }
        return result

    def get_ripples_for_export(self) -> list:
        return [r.to_dict() for r in self.ripples]

    def get_miaomiao_perspective(self) -> Optional[str]:
        era = self.era_cycle.current_era
        wp = self.world_pressure

        if wp > 0.6:
            perspectives = [
                "最近大家都很紧张，淼淼也不知道发生了什么，只知道师兄不在身边的时候心里特别慌",
                "观里的气氛越来越不对了，师叔的脸色一天比一天难看",
            ]
        elif wp > 0.3:
            perspectives = [
                "外面好像出了什么事，大家说话都小心翼翼的",
                "师叔最近好像在想什么心事，叫了好几声才应",
            ]
        else:
            perspectives = [
                "今天是个不错的日子，团团趴在院子里晒太阳",
                "后山的竹子又长高了一些，风吹过来沙沙响",
                "厨房飘来好香的味道，不知道今天吃什么",
            ]

        return random.choice(perspectives)

    def get_arc_status(self) -> str:
        era = self.era_cycle.current_era
        theme = self.era_cycle.theme
        lines = [f"当前时代: {era}（{theme}）"]

        if self.narrative_engine.active_arcs:
            lines.append(f"活跃叙事弧线: {len(self.narrative_engine.active_arcs)}条")
            for arc in self.narrative_engine.active_arcs[:3]:
                lines.append(f"  · {arc['pattern_name']} - {arc['status']}")

        return "\n".join(lines)

    def get_npc_relationship_snapshot(self) -> str:
        lines = []
        alive_npcs = [(nid, npc) for nid, npc in self.npcs.items()
                      if npc.destiny.get("alive", True)]
        for nid, npc in alive_npcs:
            name = npc.name.split("·")[-1] if "·" in npc.name else npc.name
            rels = []
            for other_id, rel in npc.relationships.items():
                other = self.npcs.get(other_id)
                if other and other.destiny.get("alive", True):
                    other_name = other.name.split("·")[-1] if "·" in other.name else other.name
                    aff = rel["affinity"]
                    icon = "♥" if aff > 70 else ("○" if aff > 40 else "✗")
                    rels.append(f"{other_name}{icon}{aff}")
            if rels:
                lines.append(f"{name}: {' '.join(rels)}")
        return "\n".join(lines)

    def get_faction_snapshot(self) -> str:
        lines = ["势力版图:"]
        for fid, f in self.faction_system.factions.items():
            if f.status != "active":
                continue
            power_bar = "█" * int(f.power / 5) + "░" * (20 - int(f.power / 5))
            status_icon = "🟢" if f.status == "rising" else ("🟡" if f.status == "active" else "🔴")
            lines.append(f"  {status_icon} {f.name}: {power_bar} {f.power} "
                        f"[稳定性:{f.internal_stability:.0%}]")
            if f.allies:
                allies = [self.faction_system.factions.get(a, Faction(a, {"name": a})).name
                         for a in f.allies
                         if a in self.faction_system.factions]
                if allies:
                    lines.append(f"    盟友: {'、'.join(allies)}")
            if f.enemies:
                enemies = [self.faction_system.factions.get(e, Faction(e, {"name": e})).name
                          for e in f.enemies
                          if e in self.faction_system.factions]
                if enemies:
                    lines.append(f"    敌对: {'、'.join(enemies)}")
        return "\n".join(lines)
