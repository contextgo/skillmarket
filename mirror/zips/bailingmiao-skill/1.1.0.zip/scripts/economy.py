#!/usr/bin/env python3
"""
经济引擎 — 大傩世界物品与交易系统
物品数据库、库存管理、物价浮动

EconomyEngine: 管理经济状态、物价、通胀
Inventory: 管理角色物品栏
"""

import random
from typing import Optional, Dict, List, Any
from copy import deepcopy


# ============================================================
# 物品数据库
# ============================================================

ITEM_DB: Dict[str, dict] = {
    # === 食物 ===
    "rice": {
        "id": "rice", "name": "稻米", "category": "食物",
        "base_price": 2, "unit": "斤",
        "desc": "南方主食，白花花的米粒",
        "tradeable": True,
    },
    "wheat": {
        "id": "wheat", "name": "小麦", "category": "食物",
        "base_price": 1.5, "unit": "斤",
        "desc": "北方主食，磨成面粉做馒头面条",
        "tradeable": True,
    },
    "salt": {
        "id": "salt", "name": "食盐", "category": "食物",
        "base_price": 5, "unit": "斤",
        "desc": "生活必需品，官盐价格稳定",
        "tradeable": True,
    },
    "tea": {
        "id": "tea", "name": "茶叶", "category": "食物",
        "base_price": 10, "unit": "两",
        "desc": "清风山附近的好茶，清香回甘",
        "tradeable": True,
    },
    "wine": {
        "id": "wine", "name": "米酒", "category": "食物",
        "base_price": 8, "unit": "壶",
        "desc": "农家自酿的米酒，后劲不小",
        "tradeable": True,
    },
    "dried_meat": {
        "id": "dried_meat", "name": "腊肉", "category": "食物",
        "base_price": 15, "unit": "斤",
        "desc": "腌制风干的肉，能保存很久",
        "tradeable": True,
    },
    "medicinal_food": {
        "id": "medicinal_food", "name": "药膳", "category": "食物",
        "base_price": 30, "unit": "碗",
        "desc": "加了药材的粥，养生补气",
        "tradeable": True,
    },

    # === 药材 ===
    "herb_common": {
        "id": "herb_common", "name": "普通药材", "category": "药材",
        "base_price": 5, "unit": "束",
        "desc": "常见的草药，清热解毒",
        "tradeable": True,
    },
    "herb_rare": {
        "id": "herb_rare", "name": "稀有药材", "category": "药材",
        "base_price": 50, "unit": "株",
        "desc": "深山中才能采到的药材，效果显著",
        "tradeable": True,
    },
    "ginseng": {
        "id": "ginseng", "name": "人参", "category": "药材",
        "base_price": 200, "unit": "株",
        "desc": "百年老参，大补元气",
        "tradeable": True,
    },
    "lingzhi": {
        "id": "lingzhi", "name": "灵芝", "category": "药材",
        "base_price": 150, "unit": "朵",
        "desc": "千年灵芝，传说能起死回生",
        "tradeable": True,
    },
    "pills_common": {
        "id": "pills_common", "name": "普通丹药", "category": "丹药",
        "base_price": 20, "unit": "颗",
        "desc": "清风观的入门丹药，疗伤补气",
        "tradeable": True,
    },
    "pills_advanced": {
        "id": "pills_advanced", "name": "高级丹药", "category": "丹药",
        "base_price": 100, "unit": "颗",
        "desc": "需要特殊材料的丹药，效果远超普通丹药",
        "tradeable": True,
    },
    "qingxin_san": {
        "id": "qingxin_san", "name": "清心散", "category": "丹药",
        "base_price": 50, "unit": "包",
        "desc": "安神定志，修炼时服用可减少走火入魔的风险",
        "tradeable": True,
    },

    # === 材料与工具 ===
    "iron": {
        "id": "iron", "name": "铁器", "category": "材料",
        "base_price": 20, "unit": "件",
        "desc": "铁打的器具，刀剑犁耙",
        "tradeable": True,
    },
    "cloth": {
        "id": "cloth", "name": "布匹", "category": "材料",
        "base_price": 8, "unit": "匹",
        "desc": "棉布麻布，做衣服用的",
        "tradeable": True,
    },
    "silk": {
        "id": "silk", "name": "丝绸", "category": "材料",
        "base_price": 50, "unit": "匹",
        "desc": "南平特产，光滑细腻，价比金银",
        "tradeable": True,
    },
    "timber": {
        "id": "timber", "name": "木材", "category": "材料",
        "base_price": 3, "unit": "根",
        "desc": "山上的木头，建房修桥造船都用得上",
        "tradeable": True,
    },
    "charcoal": {
        "id": "charcoal", "name": "木炭", "category": "材料",
        "base_price": 2, "unit": "筐",
        "desc": "烧饭取暖用的炭",
        "tradeable": True,
    },

    # === 武器与防具 ===
    "sword_common": {
        "id": "sword_common", "name": "普通铁剑", "category": "武器",
        "base_price": 100, "unit": "把",
        "desc": "铁匠铺打的铁剑，普通修士的标配",
        "tradeable": True,
    },
    "talisman": {
        "id": "talisman", "name": "符箓", "category": "法器",
        "base_price": 30, "unit": "张",
        "desc": "画了符咒的黄色纸片，驱邪避凶",
        "tradeable": True,
    },
    "talisman_advanced": {
        "id": "talisman_advanced", "name": "高级符箓", "category": "法器",
        "base_price": 200, "unit": "张",
        "desc": "需要修士亲手绘制的高级符箓，威力不俗",
        "tradeable": True,
    },

    # === 日用品 ===
    "soap": {
        "id": "soap", "name": "皂角", "category": "日用品",
        "base_price": 1, "unit": "个",
        "desc": "洗衣服用的皂角",
        "tradeable": True,
    },
    "candle": {
        "id": "candle", "name": "蜡烛", "category": "日用品",
        "base_price": 2, "unit": "支",
        "desc": "照明用，一晚上能烧完一支",
        "tradeable": True,
    },
    "incense": {
        "id": "incense", "name": "线香", "category": "日用品",
        "base_price": 3, "unit": "把",
        "desc": "敬神用的线香，清香袅袅",
        "tradeable": True,
    },
    "brush": {
        "id": "brush", "name": "毛笔", "category": "日用品",
        "base_price": 5, "unit": "支",
        "desc": "狼毫笔，写字画画用",
        "tradeable": True,
    },
    "paper": {
        "id": "paper", "name": "宣纸", "category": "日用品",
        "base_price": 2, "unit": "张",
        "desc": "写字画符用的纸张",
        "tradeable": True,
    },

    # === 特殊物品（不可交易） ===
    "qingfeng_token": {
        "id": "qingfeng_token", "name": "清风观令牌", "category": "特殊",
        "base_price": 0, "unit": "块",
        "desc": "清风观的身份令牌，不可出售",
        "tradeable": False,
    },
    "miao_miao_hairpin": {
        "id": "miao_miao_hairpin", "name": "淼淼的发簪", "category": "特殊",
        "base_price": 0, "unit": "支",
        "desc": "淼淼最珍贵的物品，一支素银发簪",
        "tradeable": False,
    },
}

# 物品分类
ITEM_CATEGORIES = {
    "食物": ["rice", "wheat", "salt", "tea", "wine", "dried_meat", "medicinal_food"],
    "药材": ["herb_common", "herb_rare", "ginseng", "lingzhi"],
    "丹药": ["pills_common", "pills_advanced", "qingxin_san"],
    "材料": ["iron", "cloth", "silk", "timber", "charcoal"],
    "武器": ["sword_common"],
    "法器": ["talisman", "talisman_advanced"],
    "日用品": ["soap", "candle", "incense", "brush", "paper"],
    "特殊": ["qingfeng_token", "miao_miao_hairpin"],
}


# ============================================================
# EconomyEngine — 经济引擎
# ============================================================

class EconomyEngine:
    """
    经济引擎 — 管理物价浮动和交易

    物价受以下因素影响：
    1. 时代：太平物价低，乱世物价高
    2. 世界压力：压力越高，物资越紧缺
    3. 季节：春夏粮价低，秋冬粮价高
    4. 随机波动：日常小幅涨跌
    """

    def __init__(self, saved: dict = None):
        if saved:
            self.inflation = saved.get("inflation", 1.0)
            self.price_history = saved.get("price_history", {})
            self.market_events = saved.get("market_events", [])
        else:
            self.inflation = 1.0
            self.price_history = {}
            self.market_events = []

    def tick(self, era: str, world_pressure: float) -> Optional[dict]:
        """每日tick，更新经济状态"""
        # 通胀率漂移
        base_inflation = 1.0

        # 时代影响
        era_inflation = {
            "太平盛世": 0.95,
            "暗流涌动": 1.05,
            "动乱爆发": 1.20,
            "乱世纷争": 1.40,
            "新秩序": 1.10,
        }
        base_inflation *= era_inflation.get(era, 1.0)

        # 世界压力影响
        base_inflation *= (1.0 + world_pressure * 0.5)

        # 缓慢趋向目标（不是瞬间变化）
        self.inflation += (base_inflation - self.inflation) * 0.05
        self.inflation += random.uniform(-0.02, 0.02)
        self.inflation = max(0.5, min(3.0, self.inflation))

        # 随机市场事件
        event = None
        if random.random() < 0.03:
            event = self._generate_market_event()
            if event:
                self.market_events.append(event)
                self.market_events = self.market_events[-20:]

        return event

    def get_price(self, item_id: str) -> Optional[float]:
        """获取物品当前价格"""
        item = ITEM_DB.get(item_id)
        if not item:
            return None
        return round(item["base_price"] * self.inflation, 2)

    def get_item_info(self, item_id: str) -> Optional[dict]:
        """获取物品完整信息（含当前价格）"""
        item = ITEM_DB.get(item_id)
        if not item:
            return None
        info = deepcopy(item)
        info["current_price"] = self.get_price(item_id)
        return info

    def buy(self, item_id: str, qty: int, silver: float) -> dict:
        """尝试购买物品"""
        price = self.get_price(item_id)
        if price is None:
            return {"success": False, "reason": "物品不存在"}
        total_cost = price * qty
        if silver < total_cost:
            return {"success": False, "reason": f"银两不足（需要{total_cost:.1f}两，现有{silver:.1f}两）"}
        return {
            "success": True,
            "item_id": item_id,
            "qty": qty,
            "total_cost": round(total_cost, 2),
            "change": round(silver - total_cost, 2),
        }

    def sell(self, item_id: str, qty: int) -> dict:
        """出售物品"""
        price = self.get_price(item_id)
        if price is None:
            return {"success": False, "reason": "物品不存在"}
        # 出售价为买入价的70%
        sell_price = price * 0.7
        total_income = sell_price * qty
        return {
            "success": True,
            "item_id": item_id,
            "qty": qty,
            "total_income": round(total_income, 2),
            "unit_price": round(sell_price, 2),
        }

    def _generate_market_event(self) -> Optional[dict]:
        """生成市场事件"""
        events = [
            {"name": "粮价上涨", "desc": "青石镇的粮食涨价了，据说是因为收成不好",
             "effect": {"rice": 1.2, "wheat": 1.15}},
            {"name": "药材紧缺", "desc": "最近进山的药农少了，药材价格飞涨",
             "effect": {"herb_common": 1.3, "herb_rare": 1.25}},
            {"name": "铁器降价", "desc": "大梁国运来了一批铁器，价格便宜了不少",
             "effect": {"iron": 0.8}},
            {"name": "丝绸畅销", "desc": "四齐国的丝绸被东瀛商人抢购一空",
             "effect": {"silk": 1.4}},
            {"name": "丹药抢手", "desc": "乱世之中丹药比金银还值钱",
             "effect": {"pills_common": 1.3, "pills_advanced": 1.5}},
            {"name": "商队到来", "desc": "西域商队带来了稀有的香料和宝石",
             "effect": {"herb_rare": 0.85, "ginseng": 0.9}},
        ]
        event = random.choice(events)
        event["day"] = 0  # 由调用者设置
        return event

    def to_dict(self) -> dict:
        return {
            "inflation": round(self.inflation, 4),
            "price_history": self.price_history,
            "market_events": self.market_events[-10:],
        }

    def get_market_summary(self) -> str:
        """获取市场概况"""
        lines = []
        lines.append(f"通胀率: {self.inflation:.0%}")

        # 常见物品价格
        common_items = ["rice", "herb_common", "pills_common", "iron", "cloth"]
        lines.append("常见物价:")
        for item_id in common_items:
            item = ITEM_DB.get(item_id)
            if item:
                price = self.get_price(item_id)
                lines.append(f"  {item['name']}: {price:.1f}文/{item['unit']}")

        return "\n".join(lines)


# ============================================================
# Inventory — 物品栏
# ============================================================

class Inventory:
    """角色物品栏管理"""

    def __init__(self, saved: dict = None):
        if saved:
            self.items: Dict[str, int] = saved.get("items", {})
            self.special_items: List[dict] = saved.get("special_items", [])
        else:
            self.items = {}  # item_id → 数量
            self.special_items = []  # 特殊物品列表

    def add_item(self, item_id: str, qty: int = 1) -> bool:
        """添加物品"""
        if item_id not in ITEM_DB:
            return False
        self.items[item_id] = self.items.get(item_id, 0) + qty
        return True

    def remove_item(self, item_id: str, qty: int = 1) -> bool:
        """移除物品"""
        current = self.items.get(item_id, 0)
        if current < qty:
            return False
        self.items[item_id] = current - qty
        if self.items[item_id] <= 0:
            del self.items[item_id]
        return True

    def has_item(self, item_id: str, qty: int = 1) -> bool:
        """检查是否有足够的物品"""
        return self.items.get(item_id, 0) >= qty

    def get_qty(self, item_id: str) -> int:
        """获取物品数量"""
        return self.items.get(item_id, 0)

    def add_special(self, item: dict):
        """添加特殊物品"""
        self.special_items.append(item)

    def remove_special(self, item_id: str) -> bool:
        """移除特殊物品"""
        for i, item in enumerate(self.special_items):
            if item.get("id") == item_id:
                self.special_items.pop(i)
                return True
        return False

    def get_all_items(self) -> Dict[str, int]:
        """获取所有普通物品"""
        return dict(self.items)

    def get_display_list(self) -> List[str]:
        """获取物品展示列表"""
        result = []
        for item_id, qty in self.items.items():
            item = ITEM_DB.get(item_id)
            if item:
                result.append(f"{item['name']} × {qty}")
        for special in self.special_items:
            result.append(f"★ {special.get('name', '未知物品')}")
        return result if result else ["空空如也"]

    def get_weight(self) -> float:
        """计算物品总重量（简化版）"""
        # 每个物品基础重量
        weight_map = {
            "食物": 0.5, "药材": 0.1, "丹药": 0.05,
            "材料": 2.0, "武器": 5.0, "法器": 0.2,
            "日用品": 0.3, "特殊": 0,
        }
        total = 0.0
        for item_id, qty in self.items.items():
            item = ITEM_DB.get(item_id)
            if item:
                total += weight_map.get(item["category"], 0.5) * qty
        return round(total, 1)

    def to_dict(self) -> dict:
        return {
            "items": dict(self.items),
            "special_items": self.special_items,
        }
