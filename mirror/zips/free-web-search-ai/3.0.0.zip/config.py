# Tavily
TAVILY_API_KEY = "your-api-key"

# SearXNG
SEARXNG_URL = "http://localhost:8080/search"

# 限制
MAX_RESULTS = 20
MAX_CRAWL = 5
MAX_CONTENT = 3000
TIMEOUT = 3
CACHE_TTL = 300
CACHE_DIR = "/tmp/free-web-search-cache"
MAX_RETRIES = 3
CONCURRENT_CRAWL = 3
LOG_LEVEL = "INFO"
LOG_FILE = "/tmp/free-web-search.log"
