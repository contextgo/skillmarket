def classify_query(q):
    if any(x in q.lower() for x in ["代码", "github", "报错", "python"]): return "tech"
    if any(x in q.lower() for x in ["价格", "多少钱", "购买"]): return "commerce"
    return "general"
