import os, json, time, hashlib, sqlite3
from config import CACHE_TTL, CACHE_DIR

os.makedirs(CACHE_DIR, exist_ok=True)
DB_PATH = os.path.join(CACHE_DIR, "cache.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, timestamp REAL, ttl INTEGER)")
    conn.commit()
    conn.close()

def get_cache(key):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        key_hash = hashlib.md5(key.encode()).hexdigest()
        cursor.execute("SELECT value, timestamp, ttl FROM cache WHERE key=?", (key_hash,))
        row = cursor.fetchone()
        conn.close()
        if row:
            value, timestamp, ttl = row
            if time.time() - timestamp < ttl:
                return json.loads(value)
    except:
        pass
    return None

def set_cache(key, value, ttl=None):
    if ttl is None: ttl = CACHE_TTL
    try:
        conn = sqlite3.connect(DB_PATH)
        key_hash = hashlib.md5(key.encode()).hexdigest()
        conn.execute("INSERT OR REPLACE INTO cache (key, value, timestamp, ttl) VALUES (?, ?, ?, ?)", (key_hash, json.dumps(value, ensure_ascii=False), time.time(), ttl))
        conn.commit()
        conn.close()
    except:
        pass

init_db()
