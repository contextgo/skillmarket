def deduplicate(results):
    seen = set()
    output = []
    for r in results:
        if r["url"] not in seen:
            seen.add(r["url"])
            output.append(r)
    return output
