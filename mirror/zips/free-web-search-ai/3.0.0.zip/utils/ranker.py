def merge_and_rank(tavily_res, searxng_res):
    combined = []
    for r in tavily_res.get("results", []):
        r["score"] = 0.9
        combined.append(r)
    for r in searxng_res:
        combined.append(r)
    return sorted(combined, key=lambda x: x.get("score", 0.5), reverse=True)
