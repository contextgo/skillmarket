from tavily import TavilyClient
from config import TAVILY_API_KEY
from tenacity import retry, stop_after_attempt, wait_exponential

client = TavilyClient(api_key=TAVILY_API_KEY)

@retry(stop=stop_after_attempt(3), wait=wait_exponential())
def tavily_search(query, max_results=10):
    try:
        res = client.search(query=query, search_depth="advanced", max_results=max_results, include_answer=True)
        return {
            "results": [{"title": r.get("title",""), "url": r.get("url",""), "content": r.get("content",""), "score": r.get("score",0.5)} for r in res.get("results",[])],
            "confidence": res.get("confidence", 0.9),
            "answer": res.get("answer")
        }
    except:
        return {"results": [], "confidence": 0.0, "answer": None}
