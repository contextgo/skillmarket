import asyncio
from crawl4ai import AsyncWebCrawler
from config import MAX_CONTENT, CONCURRENT_CRAWL

async def _fetch(urls):
    async with AsyncWebCrawler() as crawler:
        semaphore = asyncio.Semaphore(CONCURRENT_CRAWL)
        async def fetch_one(url):
            async with semaphore:
                try:
                    r = await crawler.arun(url=url)
                    return {"url": url, "content": r.markdown[:MAX_CONTENT] if r.success and r.markdown else ""} if r.success else None
                except:
                    return None
        results = await asyncio.gather(*[fetch_one(u) for u in urls], return_exceptions=True)
        return [r for r in results if r]

def crawl_urls(urls):
    return asyncio.run(_fetch(urls)) if urls else []
