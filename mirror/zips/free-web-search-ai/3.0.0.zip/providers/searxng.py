import requests
from config import SEARXNG_URL, TIMEOUT

ENGINES_MAP = {"general": "baidu,bing", "tech": "github,stackexchange", "commerce": "bing,baidu"}

def searxng_search(query, q_type="general", max_results=10):
    try:
        res = requests.get(SEARXNG_URL, params={"q": query, "format": "json", "engines": ENGINES_MAP.get(q_type, "bing")}, timeout=TIMEOUT)
        return [{"title": r.get("title",""), "url": r.get("url",""), "content": r.get("content",""), "score": 0.6} for r in res.json().get("results",[])[:max_results]]
    except:
        return []
