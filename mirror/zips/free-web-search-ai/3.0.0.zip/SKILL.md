# Free Web Search AI v3.0 - 智能搜索（Perplexity 模式）

## 功能特性

本技能提供企业级智能搜索解决方案，采用 Perplexity 模式：

### 核心功能
- **多引擎搜索**：Tavily（AI 理解）+ SearXNG（隐私搜索）
- **智能分类**：自动识别 tech/commerce/news/academic/howto 查询类型
- **并发抓取**：使用 Crawl4AI 异步并发抓取网页，提速 3-5 倍
- **语义去重**：基于 SentenceTransformer 向量相似度去重
- **加权排序**：域名权威性 + 内容质量综合评分
- **SQLite 缓存**：支持过期时间、自动清理
- **自动重试**：3 次指数退避重试机制
- **详细日志**：完整的搜索过程日志记录

### 技术架构
```
用户查询 → Tavily 搜索 → 查询分类 → SearXNG 补充 → 去重 → 排序 → 并发抓取 → 生成答案 → 缓存
```

## 使用方法

### 基础搜索
```bash
python3 main.py "Python 异步编程"
```

### 技术搜索
```bash
python3 main.py "github actions 报错 timeout"
```

### 商业搜索
```bash
python3 main.py "iPhone 15 价格 对比"
```

## 配置说明

编辑 `config.py`：
```python
TAVILY_API_KEY = "your-api-key"  # Tavily API 密钥
SEARXNG_URL = "http://localhost:8080/search"  # SearXNG 服务地址
MAX_CRAWL = 5  # 最大抓取 URL 数
CONCURRENT_CRAWL = 3  # 并发抓取数
CACHE_TTL = 300  # 缓存过期时间（秒）
```

## 依赖安装

```bash
pip install -r requirements.txt
```

## SearXNG 部署

```bash
docker run -d -p 8080:8080 searxng/searxng
```

## 版本历史

### v3.0.0 (2026-03-24) - Perplexity 模式
- ✅ 多引擎搜索 + 智能调度
- ✅ 并发抓取（asyncio.gather）
- ✅ 语义去重（SentenceTransformer）
- ✅ 加权排序（域名权威性 + 内容质量）
- ✅ SQLite 缓存（支持过期时间）
- ✅ 自动重试（tenacity）
- ✅ 日志记录

### v2.0.0 - 基础版本
- Tavily + SearXNG 双引擎
- 基础缓存功能

### v1.0.0 - 初始版本
- 单一 Tavily 引擎

## 性能对比

| 版本 | 搜索耗时 | 结果质量 | 并发数 |
|------|---------|---------|--------|
| v1.0 | 5-8 秒 | ⭐⭐⭐ | 1 |
| v2.0 | 3-5 秒 | ⭐⭐⭐⭐ | 1 |
| v3.0 | 1-3 秒 | ⭐⭐⭐⭐⭐ | 3 |

## 常见问题

**Q: 为什么需要 SearXNG？**
A: Tavily 结果不足时，SearXNG 提供补充搜索结果，确保 coverage。

**Q: 缓存多久过期？**
A: 默认 300 秒（5 分钟），可在 config.py 调整。

**Q: 并发抓取会封 IP 吗？**
A: CONCURRENT_CRAWL 默认为 3，已做限流保护。

## 作者

brucetangc

## 许可证

MIT License
