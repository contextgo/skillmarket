#!/usr/bin/env python3
"""Free Web Search v3.0 - Perplexity 模式"""

import logging
import argparse
from datetime import datetime
from config import MAX_RESULTS, MAX_CRAWL, LOG_LEVEL, LOG_FILE
from providers.tavily import tavily_search
from providers.searxng import searxng_search
from providers.crawl4ai import crawl_urls
from utils.classifier import classify_query
from utils.dedup import deduplicate
from utils.ranker import merge_and_rank
from utils.cache import get_cache, set_cache

logging.basicConfig(level=getattr(logging, LOG_LEVEL), format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def need_searxng(tavily_res):
    return tavily_res.get("confidence", 0) < 0.8 or len(tavily_res.get("results", [])) < 3

def run(query: str):
    start_time = datetime.now()
    logger.info(f"搜索：{query}")
    
    cache = get_cache(query)
    if cache:
        return {"result": cache, "from_cache": True}
    
    tavily_res = tavily_search(query, MAX_RESULTS)
    q_type, _ = classify_query(query)
    
    if need_searxng(tavily_res):
        sx_res = searxng_search(query, q_type, MAX_RESULTS)
        results = merge_and_rank(tavily_res, sx_res)
    else:
        results = tavily_res.get("results", [])
    
    results = deduplicate(results)
    urls = [r["url"] for r in results[:MAX_CRAWL]]
    contents = crawl_urls(urls) if urls else []
    
    final = tavily_res.get("answer") or "\n\n".join([c.get("content", "")[:500] for c in contents[:3]]) or "未找到信息"
    set_cache(query, final)
    
    return {
        "result": final,
        "from_cache": False,
        "elapsed": (datetime.now() - start_time).total_seconds()
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Free Web Search v3.0")
    parser.add_argument("query", type=str, help="搜索查询")
    args = parser.parse_args()
    
    result = run(args.query)
    print(f"\n结果：{result['result']}")
    print(f"耗时：{result['elapsed']:.2f}秒")
