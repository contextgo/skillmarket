# CLS Environment Configuration

This document contains the CLS (Cloud Log Service) topic mapping for all environments of the Training & Certification (培训认证) platform.

## How to Update

When a new CLS topic is provisioned or an existing one changes, update the corresponding entry in the table below. Each environment is uniquely identified by a combination of **Site** (domestic/international) and **Environment** (test/prod/gray).

## Environment Mapping

### Domestic (国内) — Region: `ap-guangzhou`

| Environment Key | Display Name | Region | Topic ID | Description |
|---|---|---|---|---|
| `domestic_test` | 国内测试 | `ap-guangzhou` | `58d165d7-81c0-4d1c-b91e-41bae4df77a9` | 国内测试环境日志，用于开发和测试阶段问题排查 |
| `domestic_prod` | 国内生产 | `ap-guangzhou` | `5b962eb2-75ed-4ebb-9575-1c8bd12d1bde` | 国内正式生产环境日志，线上问题排查使用 |
| `domestic_gray` | 国内灰度 | `ap-guangzhou` | `ff716f84-0cc2-4411-9a70-b1cd099ff8b6` | 国内灰度/预发布环境日志，灰度发布验证使用 |

### International (国际) — Region: `ap-singapore`

| Environment Key | Display Name | Region | Topic ID | Description |
|---|---|---|---|---|
| `intl_test` | 国际测试 | `ap-singapore` | `32c91c6e-691c-4d4d-96b7-ba7f6f735dcf` | 国际站测试环境日志 |
| `intl_prod` | 国际生产 | `ap-singapore` | `d4274882-f7a8-43cc-b7fb-0b12c018fbb5` | 国际站正式生产环境日志 |
| `intl_gray` | 国际灰度 | `ap-singapore` | `a5b0f47a-00e0-44f0-9c16-1cf5cbecc436` | 国际站灰度/预发布环境日志 |

## User Language → Environment Mapping

The following terms map to environment keys:

### Site Resolution
| User Input | Site | Region |
|---|---|---|
| 国内, domestic, 内网 | domestic | `ap-guangzhou` |
| 国际, international, 海外, intl, 外网 | intl | `ap-singapore` |
| _(not specified)_ | domestic | `ap-guangzhou` |

### Environment Resolution
| User Input | Environment |
|---|---|
| 测试, test, dev, 开发 | test |
| 生产, prod, production, 线上, 正式 | prod |
| 灰度, gray, canary, 预发布, grey | gray |
| _(not specified)_ | prod |

### Combined Resolution Example
- "国内生产" → `domestic_prod` → Region: `ap-guangzhou`, Topic: `5b962eb2-75ed-4ebb-9575-1c8bd12d1bde`
- "国际测试" → `intl_test` → Region: `ap-singapore`, Topic: `32c91c6e-691c-4d4d-96b7-ba7f6f735dcf`
- "灰度" (no site) → `domestic_gray` → Region: `ap-guangzhou`, Topic: `ff716f84-0cc2-4411-9a70-b1cd099ff8b6`
- "线上" (no site) → `domestic_prod` → Region: `ap-guangzhou`, Topic: `5b962eb2-75ed-4ebb-9575-1c8bd12d1bde`

## CLS MCP Tools Reference

The following CLS MCP Server tools are available for log investigation:

### SearchLog
Search logs with query parameters. Key parameters:
- `Region` (required): Region code, e.g., `ap-guangzhou`
- `TopicId`: Target topic ID
- `From` / `To` (required): Timestamps in milliseconds
- `Query` (required): Search query string (CLS syntax)
- `Limit`: Number of results (default 1, max 1000)
- `Sort`: `asc` or `desc` (default `desc`)

### DescribeLogContext
Fetch log context (surrounding lines) for a specific log entry. Key parameters:
- `Region` (required): Region code
- `TopicId` (required): Topic ID
- `Time` (required): Log entry timestamp in ms (from SearchLog results)
- `PkgId` (required): Package ID (from SearchLog results)
- `PkgLogId` (required): Package log ID (from SearchLog results)
- `PrevLogs`: Lines before (default 10)
- `NextLogs`: Lines after (default 10)

### TextToSearchLogQuery
Convert natural language to CLS query syntax. Key parameters:
- `Text` (required): Natural language description
- `Region` (required): Region code
- `TopicId` (required): Topic ID

### ConvertTimeStringToTimestamp
Convert time string to millisecond timestamp. Key parameters:
- `timeString` (required): ISO 8601 format recommended, e.g., `2026-03-24T10:30:00.000Z`
- `timeZone`: Default `Asia/Shanghai`

### ConvertTimestampToTimeString
Convert timestamp back to readable time string. Use without `timestamp` parameter to get current time.
