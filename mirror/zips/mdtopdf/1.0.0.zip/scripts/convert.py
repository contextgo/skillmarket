#!/usr/bin/env python3
"""
Markdown to PDF converter using md2pdf with professional styling.

Usage:
    python convert.py <input.md> [output.pdf] [--css <path>] [--title <title>]

If output is not specified, it defaults to the input filename with .pdf extension.
If --css is not specified, the bundled markdown.css is used.
"""

import argparse
import sys
from pathlib import Path


def find_bundled_css() -> Path:
    script_dir = Path(__file__).resolve().parent
    css_path = script_dir.parent / "assets" / "markdown.css"
    if not css_path.exists():
        print(f"Warning: Bundled CSS not found at {css_path}", file=sys.stderr)
    return css_path


def convert(md_path: str, pdf_path: str | None, css_path: str | None, title: str | None) -> str:
    # Lazy import to provide clear error message with install instructions
    try:
        from md2pdf.core import md2pdf
    except ImportError:
        print(
            "Error: md2pdf is not installed. Install it with:\n"
            "  pip install md2pdf\n"
            "Note: WeasyPrint requires system dependencies. On macOS:\n"
            "  brew install cairo pango gdk-pixbuf libffi\n"
            "On Ubuntu/Debian:\n"
            "  sudo apt install libpango-1.0-0 libpangocairo-1.0-0 "
            "libgdk-pixbuf2.0-0 libffi-dev shared-mime-info",
            file=sys.stderr,
        )
        sys.exit(1)

    md_file = Path(md_path).resolve()
    if not md_file.exists():
        print(f"Error: Input file not found: {md_file}", file=sys.stderr)
        sys.exit(1)

    out_file = Path(pdf_path).resolve() if pdf_path else md_file.with_suffix(".pdf")
    css_file = Path(css_path).resolve() if css_path else find_bundled_css()
    md_content = md_file.read_text(encoding="utf-8")

    if title and not md_content.lstrip().startswith("# "):
        md_content = f"# {title}\n\n{md_content}"

    extras = [
        "tables",
        "pymdownx.superfences",
        "pymdownx.betterem",
        "pymdownx.magiclink",
        "footnotes",
        "smarty",
    ]

    print(f"Converting: {md_file.name} -> {out_file.name}")
    if css_file.exists():
        print(f"Using CSS:  {css_file}")

    try:
        md2pdf(
            pdf=out_file,
            raw=md_content,
            css=css_file if css_file.exists() else None,
            base_url=md_file.parent,
            extras=extras,
        )
    except Exception as e:
        print(f"Error during conversion: {e}", file=sys.stderr)
        sys.exit(1)

    if out_file.exists():
        size_kb = out_file.stat().st_size / 1024
        print(f"Success:   {out_file} ({size_kb:.1f} KB)")
        return str(out_file)
    else:
        print("Error: PDF file was not created", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="Convert Markdown to PDF with professional styling"
    )
    parser.add_argument("input", help="Input Markdown file path")
    parser.add_argument("output", nargs="?", help="Output PDF file path (default: same name as input)")
    parser.add_argument("--css", help="Custom CSS file path (default: bundled markdown.css)")
    parser.add_argument("--title", help="Document title (injected as H1 if not present in content)")
    args = parser.parse_args()

    convert(args.input, args.output, args.css, args.title)


if __name__ == "__main__":
    main()
