# Source Patterns

## Recommended search queries

Replace placeholders such as `{year}`, `{major_code}`, `{major_name}`, `{school}`, `{province}`, `{city}`, and `{subject}` with the user's actual constraints.

- `site:edu.cn {year} 调剂 {major_code}`
- `site:edu.cn {year} 调剂 {major_name}`
- `site:edu.cn {year} {school} 调剂 公告`
- `site:edu.cn {year} {school} 研究生院 调剂`
- `site:edu.cn {year} {school} {major_code} 调剂`
- `site:edu.cn {year} {major_name} 英语一 数学一 调剂`
- `site:edu.cn {year} {major_name} 英语二 数学二 调剂`
- `site:edu.cn {year} {major_name} 408 调剂`
- `site:edu.cn {year} {major_name} 396 调剂`
- `site:edu.cn {year} {province} {major_name} 调剂`
- `site:yz.chsi.com.cn {year} 调剂 {major_name}`
- `site:edu.cn {year_minus_1} {school} {major_name} 调剂`
- `site:edu.cn {year_minus_1} {school} 复试名单 {major_name}`
- `site:edu.cn {year_minus_1} {school} 拟录取名单 {major_name}`

Use school-domain queries after you discover a candidate university. Prefer the graduate-school domain first, then the college or department domain.

## Official page types to look for

- current-year 调剂公告, 调剂通知, or 调剂工作办法
- college-level or department-level 调剂 notice for the target major
- current-year 招生专业目录 and 初试科目 table
- 复试名单, 复试成绩公示, 拟录取名单, or 拟录取公示
- prior-year 调剂公告 with explicit wording such as `缺额`, `调剂名额`, `接收调剂`, or `余额`
- rules that state `原报考专业相同或相近`, `初试科目相同或相近`, or a specific subject requirement

## Field checklist

Collect these fields when available:

| field | notes |
|---|---|
| school | university name |
| college | admitting department |
| region | province or city |
| major | code plus name, or direction |
| subject_requirement | user's requested subject filter |
| subject_match | `明确匹配`, `间接匹配`, `明确不匹配`, or `待确认` |
| current_plan | current-year planned enrollment |
| first_choice | current-year first-choice admitted count |
| vacancy | current-year transfer quota or computed gap |
| prev_min_score | prior-year minimum score with label |
| status | `当前可申报` or `重点关注` |
| sources | official links |

## Subject-match labels

Use these labels consistently:

- `明确匹配`: current official source directly confirms the required subjects or an explicitly compatible rule
- `间接匹配`: only older official catalogs, indirect official evidence, or broad wording support the match
- `明确不匹配`: official source shows a conflicting subject setup or transfer restriction
- `待确认`: school accepts transfer students but current official evidence is insufficient to judge

## Markdown skeleton

```md
# 2026 年考研调剂检索：085406 控制工程 / 华东地区

> 更新日期：2026-04-03
> 检索条件：085406 控制工程；地区偏好为上海 / 江苏 / 浙江
> 科目约束：英语二 + 数学二；不接受明显不兼容的自命题专业课
> 方法说明：最终表格仅保留官方来源可以直接支持的事实；缺失字段写“未说明”

## 当前可申报

| 学校 | 学院 | 专业/方向 | 科目匹配 | 2026 计划招生 | 2026 一志愿录取 | 2026 调剂名额/缺口 | 2025 分数参考 | 状态 |
|---|---|---|---|---:|---:|---:|---|---|
| 示例大学 | 自动化学院 | 085406 控制工程 | 明确匹配 | 20 | 16 | 4 | 2025 拟录取最低分 324 | 当前可申报 |

### 示例大学

- 官方页面发布时间：2026-04-02
- 调剂状态：发布了学院层面的调剂公告，并明确说明接收 085406 控制工程
- 科目判断：公告要求初试科目相同或相近；结合当年专业目录可确认英语二 + 数学二可申报
- 名额判断：公告写明调剂名额 4 人
- 分数参考：2025 年拟录取名单中该方向最低分为 324
- 风险提示：专业课为自命题时，仍需以学院复试细则中的说明为准

**来源**
- https://...
- https://...

## 重点关注

| 学校 | 学院 | 2025 调剂证据 | 2025 分数参考 | 当前判断 | 备注 |
|---|---|---|---|---|---|
| 示例大学 | 机械工程学院 | 2025 年发布过控制工程调剂公告 | 2025 复试名单分数参考 312 | 重点关注 | 截至 2026-04-03 尚未查到 2026 公告 |
```

## Wording rules

Use precise labels:

- `拟录取最低分` only when the official page is a `拟录取名单` or final admission list
- `复试名单分数参考` when the source is a `复试名单` or score notice
- `未说明` when the official source does not disclose the field
- `间接匹配` when the current-year official source does not directly confirm compatibility
- `当前可申报` only when the school has a current official transfer notice or explicit quota and no known compatibility conflict
