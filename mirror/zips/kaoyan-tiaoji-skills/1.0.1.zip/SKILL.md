---
name: kaoyan-tiaoji-research
description: Research and summarize official Chinese postgraduate transfer (考研调剂) opportunities across majors and regions. Use when Codex needs to find, compare, or verify 调剂 options by exam year, major code, major name, direction, city, province, school tier, or exam-subject combination; judge whether a school currently accepts transfer students; evaluate subject compatibility such as 英语一/英语二, 数学一/数学二, 301/302, 396, 408, or self-set papers; collect current-year quotas, planned enrollment, first-choice admissions, vacancies, and prior-year score references; and produce a source-linked shortlist, watchlist, or Markdown brief from official pages.
---

# Kaoyan Tiaoji Research

Use this skill to turn a vague 考研调剂 request into a source-linked school list built from official sources.

## Quick start

- Lock the user's exam year, target major, preferred regions, school-tier preference, subject constraints, and output format before searching.
- Infer only the minimum safe defaults when the user leaves fields unspecified, and state each assumption explicitly.
- Read `references/source-patterns.md` when you need search query patterns, field definitions, status labels, or the Markdown skeleton.

## Workflow

### 1. Lock the request

Confirm or infer these fields before searching:

- exam year; always write the final deliverable with an absolute date such as `2026-04-03`
- major code and major name, if known
- target direction, research area, or study track, if relevant
- preferred provinces, cities, or geographic exclusions
- school-quality preference, such as `985/211`, `双一流`, `普通一本`, `地区优先`, or `院校层次不限`
- exam-subject constraints, such as `英语一 + 数学一`, `英语二 + 数学二`, `408`, `396`, `自命题专业课`, or `只接受相同初试科目`
- desired output shape, such as a Markdown table, ranked shortlist, or watchlist

If the user omits a field, infer the narrowest reasonable assumption from context and surface it in the write-up.

### 2. Search official sources first

Search in this order:

1. university graduate-school sites
2. admitting college or department sites
3. official `中国研究生招生信息网`, provincial education-exam authorities, or university admission portals
4. Ministry or provincial education pages when they directly host the notice or catalog

Use commercial aggregation sites only to discover candidate schools. Do not cite them for final facts.

Read `references/source-patterns.md` for query patterns and the official page types to collect.

### 3. Judge subject compatibility carefully

Treat subject compatibility as a filter that depends on the user's actual constraints. For each school, assign exactly one label:

- `明确匹配`: the current official source directly confirms the same or accepted subject combination
- `间接匹配`: only older official catalogs, indirect official evidence, or broad wording suggests compatibility
- `明确不匹配`: the official source shows a conflicting subject setup or a transfer restriction
- `待确认`: the school accepts transfer students, but the current official source does not reveal enough to judge

Common subject checks include:

- `201 英语一 + 301 数学一`
- `204 英语二 + 302 数学二`
- `396 经济类联考`
- `408 计算机学科专业基础`
- `自命题专业课代码是否一致或相近`
- `是否要求原报考专业相同/相近`

If the current-year catalog is image-only, inaccessible, or too vague, do not overstate certainty. Prefer `间接匹配` or `待确认` over speculation.

### 4. Extract only defensible numbers

For each school, try to collect:

- school and admitting college
- region
- major code, major name, and direction
- subject compatibility label
- current-year planned enrollment
- current-year first-choice admitted count, if officially disclosed
- current-year transfer quota or defensible vacancy count
- prior-year minimum score or score range, with the source type clearly labeled
- official source links

Apply these rules:

- If a field is absent from the official page, write `未说明`
- Compute `缺口 = 计划招生 - 已录取一志愿` only when both inputs are official and clearly comparable
- If a page merely says `接受调剂` with no number, keep the vacancy field as `未说明`
- If a prior-year page is only a `复试名单` or score notice, label the score as `复试名单分数参考` instead of `拟录取最低分`
- If the major name appears similar but the code differs, flag the mismatch explicitly rather than merging the records

### 5. Rank schools by actionability

Split results into at least two buckets:

- `当前可申报`: schools with a current official 调剂 notice or explicit transfer quota, and no known compatibility conflict
- `重点关注`: schools that fit the user's region or tier preference and have prior-year transfer evidence or strong current-year signals, but have not yet published enough current-year detail

When useful, assign an execution priority such as `A / B / C` or `高优先 / 中优先 / 低优先`.

### 6. Write the Markdown deliverable

Produce a concise Markdown file with:

- a title containing exam year plus major code or direction
- update date and what was checked on that date
- a short methodology note explaining that only official pages were used for final facts
- a table for currently confirmed options
- short notes per school covering compatibility, quotas, score references, and caveats
- a watchlist section for likely schools that still need current-year confirmation
- source links under each school or in a dedicated source column

Use the template in `references/source-patterns.md` as the default structure.

## Output standards

- Prefer official links over copied text
- Include exact dates such as `2026-04-03`
- Distinguish `明确匹配` from `间接匹配`
- Keep unsupported guesses out of the table
- Say exactly what was checked on the current date when the search is time-sensitive
- Mark image-only, PDF-only, or inaccessible official pages as evidence limitations
- Prioritize correctness over completeness for graduate-admissions research
