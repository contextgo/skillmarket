# Bloom's Taxonomy Quick Reference

Use this file as a compact decision aid when turning concept-learning requests into notes, explanations, and study prompts.

## The Six Levels

| Level | Goal | Common verbs | Typical note contribution |
| --- | --- | --- | --- |
| Remember | Recall facts and terms | define, list, name, identify, label | glossary, one-line definitions, key facts |
| Understand | Explain meaning | explain, summarize, classify, describe, paraphrase | plain-language explanation, intuition, short summary |
| Apply | Use the idea in context | use, solve, demonstrate, choose, implement | worked example, use case, mini exercise |
| Analyze | Break apart and compare | compare, distinguish, organize, infer, relate | contrast section, structure/mechanism breakdown |
| Evaluate | Judge quality or fit | assess, critique, justify, defend, prioritize | tradeoffs, strengths, limits, failure cases |
| Create | Make something new | design, compose, generate, adapt, formulate | synthesis prompt, analogy creation, note rewrite |

## Prompt Patterns

### Remember

- "X 是什么？"
- "列出这个概念的关键术语"
- "给我一个最短定义"

### Understand

- "用通俗的话解释"
- "帮我理解这个概念"
- "总结这部分知识"

### Apply

- "举个实际例子"
- "这个概念怎么用？"
- "给我一道练习题"

### Analyze

- "它和 Y 有什么区别？"
- "拆开讲讲它的组成和关系"
- "为什么会这样运作？"

### Evaluate

- "这个方法好在哪里，局限在哪里？"
- "什么时候适合用，什么时候不适合？"
- "两种方案哪个更合理？"

### Create

- "帮我把它改写成自己的笔记"
- "基于这个概念设计一个例子"
- "用这个知识搭一个学习框架"

## How To Reflect Each Level In Notes

- Remember: include a short definition or key facts section.
- Understand: include a plain-language explanation and intuitive framing.
- Apply: include examples, scenarios, or mini exercises.
- Analyze: include comparisons, components, dependencies, or boundaries.
- Evaluate: include tradeoffs, judgments, caveats, or decision criteria.
- Create: include prompts that ask the learner to generate something new.

## Early Stop Rule For "是什么"

If the user only asks what something is and does not signal deeper study intent, stop early:
- give a one-line definition
- explain it in plain language
- give one concrete example
- optionally suggest one next-step direction

Do not force the full six-level progression unless the user asks to learn, review, compare, practice, or build notes.
