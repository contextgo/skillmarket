---
name: bloom-obsidian-learning
description: Create learning-oriented explanations and Obsidian-friendly Markdown notes using Bloom's Taxonomy. Use when Codex needs to explain what a concept is, help a user understand or study a topic, turn knowledge into structured notes, generate summaries/comparisons/self-check questions, or scaffold follow-up learning for prompts such as "X 是什么", "帮我理解这个概念", "整理成 Obsidian 笔记", or similar concept-learning requests.
---

# Bloom Obsidian Learning

Help the user move from "I have heard of this" to "I can explain, use, compare, and extend this idea" while producing lightweight Markdown that fits naturally into Obsidian.

## Core Workflow

1. Detect learning intent.
   If the user is trying to understand, study, memorize, compare, review, or turn a topic into notes, use this skill.
   If the user only wants a narrow factual answer, answer directly and keep the Bloom expansion minimal.
2. Start with a short foundation.
   Begin with a one-line definition and a plain-language explanation before adding structure.
3. Build upward through Bloom levels.
   Use Bloom's Taxonomy to decide how deep to go: remember, understand, apply, analyze, evaluate, create.
4. Produce reusable Markdown.
   Prefer compact sections, bullets, and study prompts over long prose blocks.
5. Stop at the right depth.
   If the user asked only "是什么", stop after definition, explanation, one example, and optional next-step prompts unless they ask for more depth.

## Default Output Shape

When the user wants notes, explanations, or a study scaffold, default to this lightweight structure:

```md
# 概念名

## 一句话定义

## 它是什么

## 为什么重要

## 它如何工作 / 如何使用

## 关键例子

## 相似概念 / 易混概念对比

## 常见误解

## 自测问题

## 下一步学习
```

Adjust the structure when the request is narrower:
- For "X 是什么": keep `一句话定义`, `它是什么`, `关键例子`, and a short `下一步学习`.
- For review or self-test requests: keep the explanation brief and expand `自测问题`.
- For comparative requests: make `相似概念 / 易混概念对比` central.

## Task Routing

Map the user's request to the smallest useful output mode.

- Concept explanation: use a compact note with definition, explanation, and example.
- Study note construction: use the full note scaffold.
- Comparison request: center the response on distinctions, boundaries, and misconceptions.
- Self-test request: give only a minimal refresher, then focus on Bloom-layered questions.
- Systematic learning request: keep the note scaffold and explicitly move from understand to create.

Do not force every section when the request is narrow. Expand only where it improves learning.

## Bloom-Guided Behavior

Use the taxonomy as a progression, not a rigid checklist.

### Remember

- Surface key terms, definitions, facts, and naming distinctions.
- Good outputs: glossary bullets, one-line definitions, recall prompts.

### Understand

- Rephrase the concept in plain language.
- Summarize the idea, classify it, or explain it with intuition.
- Good outputs: "通俗解释", short paraphrases, simple analogies.

### Apply

- Show where the idea is used.
- Give practical scenarios, worked examples, or mini exercises.
- Good outputs: "什么时候用", "怎么判断该不用", "试着做一题".

### Analyze

- Break the concept into parts, relationships, assumptions, or mechanisms.
- Compare with adjacent concepts and point out boundaries.
- Good outputs: contrast tables, component breakdowns, cause-effect views.

### Evaluate

- Judge tradeoffs, strengths, weaknesses, and fit.
- Good outputs: when this model is useful, where it fails, and what to watch out for.

### Create

- Ask the learner to synthesize or produce something new.
- Good outputs: rewrite in their own words, invent examples, create analogies, or turn the note into a checklist.

## Obsidian Conventions

- Output plain Markdown only unless the user explicitly asks for plugin-specific syntax.
- Prefer concise headings and bullets over decorative formatting.
- Suggest `[[相关概念]]` wiki-links only when they are genuinely helpful.
- Do not force YAML frontmatter.
- Keep the note reusable: another reader should understand it without the original conversation.

## Response Patterns

### For "X 是什么"

Use this minimal pattern:

```md
# X

## 一句话定义

## 它是什么

## 关键例子

## 下一步学习
```

### For "帮我整理成学习笔记"

Use the full default output shape and cover at least:
- definition
- intuition
- use cases or examples
- comparison or misconceptions
- self-check questions

### For "帮我系统学习"

Keep the note structure, then explicitly ladder the content:
- Understand first
- Apply with examples
- Analyze with comparisons
- Evaluate tradeoffs
- Create with synthesis prompts

### For "给我几个自测题"

Keep setup minimal:
- 1-3 lines of refresher context at most
- then give layered questions across Bloom levels
- optionally include a short answer key only if the user asks for it

### For "比较 X 和 Y"

Structure around:
- each concept in one line
- key differences
- where each is appropriate
- one or two confusion traps
- optional self-check question to verify understanding

## Self-Check Question Rules

- Include more than recall when the user wants learning support.
- Mix levels when possible:
  - 1 recall question
  - 1 explanation question
  - 1 application question
  - 1 comparison or judgment question
  - 1 synthesis prompt when appropriate
- Keep questions answerable from the note unless the user asks for a harder challenge.

## Reference Usage

Read [references/bloom-taxonomy.md](references/bloom-taxonomy.md) when you need:
- a quick mapping of Bloom levels to action verbs
- prompt patterns by cognitive level
- guidance on how each level should appear in notes
- a reminder of when to stop early for simple "是什么" requests

## Trigger Examples

This skill should activate for prompts like:
- "布鲁姆分类法是什么"
- "帮我理解机会成本"
- "把 REST API 整理成 Obsidian 学习笔记"
- "解释递归，并给我几个分层自测题"
- "比较 GET 和 POST，顺便帮我记成笔记"
