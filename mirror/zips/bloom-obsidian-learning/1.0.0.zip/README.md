# bloom-obsidian-learning

A Codex skill for explaining concepts with Bloom's Taxonomy and turning them into Obsidian-friendly study notes.

## What This Skill Does

This skill helps Codex:

- explain a concept in plain language
- organize learning from basic understanding to deeper application
- generate lightweight Markdown notes suitable for Obsidian
- create comparisons, misconceptions, self-check questions, and next-step study prompts

It is especially useful for prompts like:

- `X 是什么`
- `帮我理解这个概念`
- `整理成 Obsidian 笔记`
- `给我几个自测题`
- `比较 X 和 Y，顺便记成笔记`

## Files

- `SKILL.md`: core skill instructions
- `references/bloom-taxonomy.md`: compact Bloom taxonomy reference
- `agents/openai.yaml`: UI metadata for the skill

## Installation

Install the skill into your Codex skills directory, for example:

```bash
cp -R bloom-obsidian-learning "${CODEX_HOME:-$HOME/.codex}/skills/"
```

Then restart Codex to pick up the new skill.

## Example Prompt

```text
解释下“深度学习”
```

## Example Output

```md
# 深度学习

## 一句话定义

深度学习是机器学习的一类方法，它用多层神经网络从数据中自动学习特征和规律，用来完成分类、预测、生成等任务。

## 它是什么

如果把传统编程理解为“人先写好规则，再让程序执行”，那深度学习更像是“给模型大量数据和目标，让它自己学出规则”。

它之所以叫“深度”，不是因为更高深，而是因为模型里通常有很多层。每一层都会把输入数据做一步抽象处理，前面的层学简单特征，后面的层学更复杂的模式。

比如看图片时：
- 前面几层可能学边缘、颜色、纹理
- 中间几层可能学眼睛、鼻子、轮廓
- 后面几层可能学“这是一只猫”

## 为什么重要

深度学习厉害的地方在于，它特别擅长处理复杂数据，尤其是：
- 图像
- 语音
- 文本
- 视频
- 高维传感器数据

很多现代 AI 应用都建立在它上面，比如：
- 人脸识别
- 语音助手
- 机器翻译
- 推荐系统
- 大语言模型

## 它如何工作 / 如何使用

一个很粗的流程是：

1. 准备数据
   比如图片、文本、语音，外加对应标签或训练目标。
2. 搭建神经网络
   选择网络结构，比如全连接网络、卷积网络、Transformer。
3. 前向传播
   把输入送进模型，得到预测结果。
4. 计算误差
   比较预测结果和真实答案差多少。
5. 反向传播 + 参数更新
   根据误差调整网络里的参数，让下次预测更准。
6. 重复训练
   反复看数据、不断调整，直到模型效果足够好。

## 关键例子

例子：识别一张图片里是不是猫。

- 输入：大量“猫”和“不是猫”的图片
- 训练后：模型会逐渐学会什么样的视觉特征更像猫
- 最终：给它一张新图片，它可以输出“是猫”的概率

再比如大语言模型：
- 输入：海量文本
- 训练目标：预测下一个词
- 结果：模型学会语言模式、知识关联和表达方式

## 相似概念 / 易混概念对比

`人工智能`、`机器学习`、`深度学习` 的关系可以这样看：

- 人工智能：大范围，目标是让机器表现出智能
- 机器学习：人工智能的一种实现方式，让机器从数据中学习
- 深度学习：机器学习的一种，强调多层神经网络

可以记成：

`人工智能 > 机器学习 > 深度学习`

## 常见误解

- “深度学习就是 AI 的全部”
  不是。它只是 AI 里的一个重要分支。
- “层数越多越好”
  不是。更深的模型不一定更好，还可能更难训练、更耗资源。
- “只要数据多就一定成功”
  不是。数据质量、模型结构、训练方式都很重要。
- “深度学习真的像人脑一样思考”
  不完全是。它借用了“神经网络”这个灵感，但和真实人脑差别很大。

## 自测问题

- 深度学习和机器学习是什么关系？
- 为什么“深度”这个词和网络层数有关？
- 图像识别任务中，前层和后层通常分别学什么？
- 为什么深度学习特别适合图像、语音、文本这类数据？
- 如果一个深度学习模型效果不好，可能只靠“加更多层”解决吗？为什么？

## 下一步学习

如果你想继续往下学，比较自然的顺序是：

1. 先理解 `[[机器学习]]` 和 `[[神经网络]]`
2. 再看 `损失函数`、`梯度下降`、`反向传播`
3. 然后区分常见模型：
   `CNN`、`RNN`、`Transformer`
4. 最后再进入应用：
   计算机视觉、自然语言处理、语音识别
```

## Notes

This repository intentionally includes a `README.md` because it is meant to be shared on GitHub. The skill itself remains defined by `SKILL.md` and its reference files.
