#!/usr/bin/env bash
# bump-and-publish.sh
# Auto-bumps the patch version in SKILL.md, appends a changelog entry,
# and publishes to ClawHub. Run from the skill folder after any change.
#
# Usage:
#   ./bump-and-publish.sh                         # prompts for changelog message
#   ./bump-and-publish.sh "Added X dork category" # non-interactive
#   ./bump-and-publish.sh --dry-run               # preview only, no publish

set -euo pipefail

SKILL_FILE="$(dirname "$0")/SKILL.md"
SLUG="google-dorks"
NAME="Precision Web Search"
TAGS="latest"
DRY_RUN=false
CHANGELOG_MSG=""

# ── Parse args ──────────────────────────────────────────────────────────────
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
    *) CHANGELOG_MSG="$arg" ;;
  esac
done

# ── Sanity check ─────────────────────────────────────────────────────────────
if [[ ! -f "$SKILL_FILE" ]]; then
  echo "✗  SKILL.md not found at $SKILL_FILE"
  exit 1
fi

if ! command -v clawhub &>/dev/null; then
  echo "✗  clawhub CLI not found. Install it: npm i -g clawhub"
  exit 1
fi

# ── Read current version from frontmatter ────────────────────────────────────
CURRENT_VERSION=$(grep -m1 '^version:' "$SKILL_FILE" | sed 's/version: *//' | tr -d '[:space:]"')

if [[ -z "$CURRENT_VERSION" ]]; then
  echo "✗  No 'version:' field found in SKILL.md frontmatter."
  echo "    Add one: version: 1.1.0"
  exit 1
fi

# ── Bump patch version ───────────────────────────────────────────────────────
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"
PATCH=$((PATCH + 1))
NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
TODAY=$(date +%Y-%m-%d)

echo "📦  Current version : $CURRENT_VERSION"
echo "🔼  New version     : $NEW_VERSION"
echo "📅  Date            : $TODAY"

# ── Prompt for changelog message if not provided ─────────────────────────────
if [[ -z "$CHANGELOG_MSG" ]]; then
  echo ""
  echo "📝  Changelog message (describe what changed — leave blank for default):"
  read -r CHANGELOG_MSG
fi

if [[ -z "$CHANGELOG_MSG" ]]; then
  CHANGELOG_MSG="Skill update — see SKILL.md for details"
fi

echo "📝  Changelog       : $CHANGELOG_MSG"

if $DRY_RUN; then
  echo ""
  echo "🔍  Dry run — no files written, no publish."
  echo "    Would write version $NEW_VERSION to SKILL.md and publish to ClawHub."
  exit 0
fi

# ── Update version in frontmatter ───────────────────────────────────────────
sed -i "s/^version: .*/version: $NEW_VERSION/" "$SKILL_FILE"

# ── Prepend changelog entry ──────────────────────────────────────────────────
# Inserts the new entry directly after the "newest entry first" header line
CHANGELOG_ENTRY="### [$NEW_VERSION] — $TODAY\n$CHANGELOG_MSG"

# Use python for reliable multi-line sed across Linux/macOS
python3 - <<PYEOF
import re

with open("$SKILL_FILE", "r") as f:
    content = f.read()

marker = "Format: \`## [version] — YYYY-MM-DD\` · newest entry first."
entry = "\n\n### [$NEW_VERSION] — $TODAY\n$CHANGELOG_MSG"

if marker in content:
    content = content.replace(marker, marker + entry, 1)
else:
    print("⚠️  Changelog marker not found — appending entry at end of file.")
    content = content.rstrip() + "\n\n### [$NEW_VERSION] — $TODAY\n$CHANGELOG_MSG\n"

with open("$SKILL_FILE", "w") as f:
    f.write(content)

print("✓  SKILL.md updated.")
PYEOF

# ── Publish to ClawHub ───────────────────────────────────────────────────────
echo ""
echo "🚀  Publishing to ClawHub..."
clawhub publish "$(dirname "$0")" \
  --slug "$SLUG" \
  --name "$NAME" \
  --version "$NEW_VERSION" \
  --changelog "$CHANGELOG_MSG" \
  --tags "$TAGS"

echo ""
echo "✓  Published: $NAME v$NEW_VERSION → clawhub.ai/samaritanoc/$SLUG"
