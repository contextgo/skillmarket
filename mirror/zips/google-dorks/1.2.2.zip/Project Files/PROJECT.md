# Google Dorks for OSINT — Project Context

Read this file first at the start of every session before touching any skill files.

---

## What This Is

A structured Google dorking skill for OpenClaw agents. Teaches agents to build
targeted search queries for OSINT investigations instead of plain keyword searches.

Published on ClawHub as a public skill under the SamaritanOC account.

---

## File Locations

| File | Path |
|---|---|
| Skill files (live) | `/mnt/samaritan-data/Skills/google-dorks/` |
| Agent-facing skill | `/mnt/samaritan-data/Skills/google-dorks/SKILL.md` |
| Extended dork library | `/mnt/samaritan-data/Skills/google-dorks/dorks-reference.md` |
| Bump & publish script | `/mnt/samaritan-data/Skills/google-dorks/bump-and-publish.sh` |
| Project context files | `/mnt/samaritan-data/Skills/google-dorks/Project Files/` |

---

## ClawHub

| Field | Value |
|---|---|
| Skill slug | `google-dorks` |
| Display name | `Precision Web Search` |
| ClawHub URL | https://clawhub.ai/samaritanoc/google-dorks |
| Owner account | `@SamaritanOC` |
| Tags | `latest` |

---

## Two-Layer Architecture

**Layer 1 — `SKILL.md`**
The agent-facing file. Loaded into context on every invocation. Contains:
- When-to-use instructions
- Two-track execution protocol (Track 1: web_search/Brave, Track 2: browser + Google)
- Curated dork templates across 17 categories
- Operator quick reference table
- Pointer to dorks-reference.md for extended queries
- Changelog (bottom of file — human/UI facing, not agent-critical)

**Layer 2 — `dorks-reference.md`**
Extended library of 700+ dorks across 13 sections. Agents read this only when
SKILL.md templates return insufficient results or a niche category is needed.
Never modify this file for routine updates — it is the reference corpus.

---

## Two-Track Execution Protocol

| Track | Tool | When |
|---|---|---|
| Track 1 | `web_search` (Brave) | Always try first |
| Track 2 | Browser + Google | When Track 1 returns < 3 useful results |

Track 2 is required for operators Brave does not support:
`cache:` `related:` `AROUND(n)` `before:` `after:`

---

## Publishing Workflow

**Automated (preferred):**
```bash
cd /mnt/samaritan-data/Skills/google-dorks
./bump-and-publish.sh "Description of what changed"
```
The script: reads current version → bumps patch → inserts changelog entry →
runs `clawhub publish` with correct flags automatically.

**Manual publish command:**
```bash
clawhub publish /mnt/samaritan-data/Skills/google-dorks \
  --slug google-dorks \
  --name "Precision Web Search" \
  --version <NEW_VERSION> \
  --changelog "<what changed>" \
  --tags latest
```

**Dry run (preview without publishing):**
```bash
./bump-and-publish.sh --dry-run
```

---

## Versioning Rules

- Format: `MAJOR.MINOR.PATCH` (semver)
- Bump **patch** for dork additions, fixes, compatibility updates
- Bump **minor** for new categories or significant structural changes
- Bump **major** for breaking changes to the protocol or architecture
- Version lives in SKILL.md frontmatter (`version:` field)
- Changelog lives at the bottom of SKILL.md and in `PUBLISH-HISTORY.md`

---

## OpenClaw Compatibility

| Field | Value |
|---|---|
| Current target | OpenClaw v2026.3.24 |
| ClawHub CLI | v0.9.0 |
| Node floor | 22.14+ |
| Authenticated as | `@SamaritanOC` on Samaritan machine |

**Compatibility checks to run on each new OpenClaw release:**
1. Check release notes for changes to: skill frontmatter schema, Control UI skill dialog fields, CLI publish flags, `requirements:` handling
2. Verify `homepage:`, `requirements:`, `version:`, and `name:` fields still match expected schema
3. Run `clawhub whoami` to confirm auth is still valid before publishing

---

## What NOT to Do

- Do not modify `dorks-reference.md` for routine skill updates
- Do not push to a git repo — ClawHub is the publish target, not GitHub
- Do not bump version manually in frontmatter — use `bump-and-publish.sh`
- Do not run `openclaw skills publish` — that command does not exist; use `clawhub publish`
- Do not assume `clawhub` and `openclaw` CLI commands are interchangeable
- Do not deliver Project Files updates without PUBLISH-HISTORY.md included — it is always part of the same operation, never separate
