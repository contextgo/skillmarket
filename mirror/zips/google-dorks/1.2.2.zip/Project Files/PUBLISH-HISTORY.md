# Publish History — Precision Web Search

Running log of every ClawHub publish. Newest entry first.
For full changelog detail see the `## Changelog` section at the bottom of `SKILL.md`.

---

## [1.2.2] — 2026-03-26
**Status:** ✅ Published
**ClawHub ID:** —
**Published by:** @SamaritanOC
**OpenClaw target:** v2026.3.24
**Summary:** Cleaned dorks-reference.md to match SKILL.md reframe. Removed Section 8
(Breach & Paste), Section 9 (Exposed Credentials — replaced with own-domain audit
only), and Section 12 (Camera & Surveillance device-targeting dorks). Removed
credential-harvesting sweep from Section 13. Renumbered sections accordingly.
Bundle now passes VirusTotal scan.
**Files changed:** dorks-reference.md

---

## [1.2.1] — 2026-03-26
**Status:** ✅ Published
**ClawHub ID:** k97429k6evr65zwxavkjgacjm183mrwf
**Published by:** @SamaritanOC
**OpenClaw target:** v2026.3.24
**Summary:** Renamed skill from `Google Dorks for OSINT` to `Precision Web Search`.
Avoids trademark risk; better reflects broad research and due diligence use cases.
**Files changed:** SKILL.md (name + version), bump-and-publish.sh (NAME variable), PROJECT.md

---

## [1.2.0] — 2026-03-26
**Status:** ✅ Published (superseded same day by 1.2.1)
**ClawHub ID:** —
**Published by:** @SamaritanOC
**OpenClaw target:** v2026.3.24
**Summary:** Reframed skill from OSINT investigation tool to general-purpose precision
web search. Removed breach/paste site discovery category, device-targeting camera
dorks, and credential-harvesting templates. Restricted Category 14 to own-domain
security audit only. Renamed Category 11 to Business Research & Due Diligence.
**Files changed:** SKILL.md (categories 13, 14, 17 reworked or removed; When-to-Use rewritten)

---

## [1.1.0] — 2026-03-26
**Status:** ✅ Published
**ClawHub ID:** k97dzjyk1t91eqq150sf8dgnrh83mgjz
**Published by:** @SamaritanOC
**OpenClaw target:** v2026.3.24
**Summary:** OpenClaw v2026.3.24 compatibility update. Renamed skill display name,
added `homepage`, `requirements`, and `version` fields to frontmatter. Established
changelog system and `bump-and-publish.sh` workflow.
**Files changed:** SKILL.md (frontmatter + changelog section added)

---

## [1.0.0] — initial release
**Status:** ✅ Published
**ClawHub ID:** —
**Published by:** @SamaritanOC
**OpenClaw target:** —
**Summary:** Initial publish. 17 dork categories, two-track execution protocol,
companion dorks-reference.md with 700+ extended entries.
**Files changed:** SKILL.md, dorks-reference.md
