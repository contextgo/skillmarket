Synthesized from public metadata; upstream archive unavailable. Homepage: https://clawhub.ai/skipzhang/weather-pro-v1
