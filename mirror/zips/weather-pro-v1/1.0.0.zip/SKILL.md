---
name: Weather Pro V1
description: "Weather + forecast skill"
metadata:
  synthetic_archive: true
  source: public-metadata-placeholder
---

# Weather Pro V1

This archive was synthesized from public SkillHub / ClawHub metadata because the upstream zip package was unavailable during mirroring.

## Metadata

- slug: `weather-pro-v1`
- version: `1.0.0`
- owner: `skipzhang`
- homepage: https://clawhub.ai/skipzhang/weather-pro-v1
- category: ``
- downloads: `0`
- stars: `0`
- installs: `0`

## Description

Weather + forecast skill

## Note

If the upstream package becomes available later, you can replace this synthesized archive with the original zip.
