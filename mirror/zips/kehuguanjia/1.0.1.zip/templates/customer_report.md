# 客户画像分析报告

**客户姓名**：{{customer_name}}
**公司名称**：{{company}}
**报告时间**：{{report_date}}

---

## 基本信息

| 项目 | 内容 |
|------|------|
| 客户姓名 | {{name}} |
| 公司名称 | {{company}} |
| 职位 | {{position}} |
| 联系方式 | {{phone}} / {{email}} |
| 预算范围 | {{budget}} |
| 客户来源 | {{source}} |

---

## 画像分析

### 性格特征

**类型**：{{personality_type}}
**置信度**：{{personality_confidence}}%
**特征描述**：{{personality_description}}

### 核心关注点

**优先级**：{{concern_priority}}

| 关注点 | 权重 | 客户表现 |
|--------|------|----------|
| {{concern_1}} | {{weight_1}} | {{evidence_1}} |
| {{concern_2}} | {{weight_2}} | {{evidence_2}} |

### 决策分析

**决策层级**：{{decision_level}}
**决策速度**：{{decision_speed}}
**预估周期**：约{{decision_days}}天

---

## 成交预测

**概率评估**：{{probability}}%
**等级**：{{probability_level}}

### 有利因素
{{positive_factors}}

### 风险因素
{{risk_factors}}

---

## 沟通策略

### 推荐风格
**风格类型**：{{strategy_style}}

### 建议动作
1. {{strategy_action_1}}
2. {{strategy_action_2}}
3. {{strategy_action_3}}

### 避免事项
- {{strategy_avoid_1}}
- {{strategy_avoid_2}}

### 跟进建议
{{followup_tips}}

### 推荐话题
- {{topic_1}}
- {{topic_2}}

---

## 跟进记录

### 最近跟进

| 日期 | 内容 | 销售人员 |
|------|------|----------|
| {{date_1}} | {{note_1}} | {{sales_1}} |
| {{date_2}} | {{note_2}} | {{sales_2}} |
| {{date_3}} | {{note_3}} | {{sales_3}} |

---

## 关键节点

- **首次接触**：{{first_contact_date}}
- **需求确认**：{{qualified_date}}
- **方案提交**：{{proposal_date}}
- **报价**：{{quoted_date}}
- **异议处理**：{{objection_date}}

---

## 备注

{{additional_notes}}

---

*本报告由销售客户管家自动生成*
