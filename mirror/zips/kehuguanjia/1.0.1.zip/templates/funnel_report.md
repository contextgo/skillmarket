# 销售漏斗分析报告

**生成时间**：{{report_date}}
**统计周期**：{{period}}

---

## 📊 各阶段客户分布

| 阶段 | 客户数 | 占比 | 柱状图 | 平均预算 |
|------|--------|------|--------|----------|
| 潜在客户 | {{potential_count}} | {{potential_percent}}% | {{potential_bar}} | {{potential_avg}}万 |
| 初步接触 | {{initial_count}} | {{initial_percent}}% | {{initial_bar}} | {{initial_avg}}万 |
| 需求确认 | {{qualified_count}} | {{qualified_percent}}% | {{qualified_bar}} | {{qualified_avg}}万 |
| 方案报价 | {{proposal_count}} | {{proposal_percent}}% | {{proposal_bar}} | {{proposal_avg}}万 |
| 商务谈判 | {{negotiation_count}} | {{negotiation_percent}}% | {{negotiation_bar}} | {{negotiation_avg}}万 |
| 成交 | {{closed_count}} | {{closed_percent}}% | {{closed_bar}} | {{closed_avg}}万 |

---

## 📈 阶段转化率

| 阶段转化 | 转化数量 | 转化率 | 状态 |
|----------|----------|--------|------|
| 潜在→初步接触 | {{convert_1_from}}→{{convert_1_to}} | {{convert_1_rate}}% | {{convert_1_status}} |
| 初步→需求确认 | {{convert_2_from}}→{{convert_2_to}} | {{convert_2_rate}}% | {{convert_2_status}} |
| 需求→方案报价 | {{convert_3_from}}→{{convert_3_to}} | {{convert_3_rate}}% | {{convert_3_status}} |
| 方案→商务谈判 | {{convert_4_from}}→{{convert_4_to}} | {{convert_4_rate}}% | {{convert_4_status}} |
| 商务→成交 | {{convert_5_from}}→{{convert_5_to}} | {{convert_5_rate}}% | {{convert_5_status}} |

**图例**：✅ 良好(≥50%) | ⚠️ 需关注(30-50%) | 🔴 需改进(<30%)

---

## 💰 管道价值预测

| 指标 | 数值 |
|------|------|
| 总管道价值 | {{total_pipeline}}万 |
| 加权管道价值 | {{weighted_pipeline}}万 |
| 谈判阶段客户 | {{negotiation_customers}}个 |
| 预计成交 | {{estimated_deals}}单 |
| 综合转化概率 | {{conversion_probability}}% |

---

## ⚠️ 瓶颈预警

### {{bottleneck_1_name}}
- **阶段转化**：{{bottleneck_1_transition}}
- **当前转化率**：{{bottleneck_1_rate}}%
- **影响客户数**：{{bottleneck_1_impact}}人
- **建议措施**：{{bottleneck_1_suggestion}}

### {{bottleneck_2_name}}
- **阶段转化**：{{bottleneck_2_transition}}
- **当前转化率**：{{bottleneck_2_rate}}%
- **影响客户数**：{{bottleneck_2_impact}}人
- **建议措施**：{{bottleneck_2_suggestion}}

---

## 💡 优化建议

### 短期建议
1. {{short_term_1}}
2. {{short_term_2}}

### 中期建议
1. {{mid_term_1}}
2. {{mid_term_2}}

### 长期建议
1. {{long_term_1}}
2. {{long_term_2}}

---

## 📉 漏斗可视化

```
潜在客户     {{potential_bar}}
初步接触     {{initial_bar}}
需求确认     {{qualified_bar}}
方案报价     {{proposal_bar}}
商务谈判     {{negotiation_bar}}
成交         {{closed_bar}}
```

---

*本报告由销售客户管家自动生成*
