# 业绩统计报告

**生成时间**：{{report_date}}
**统计周期**：{{period}}

---

## 📊 个人业绩

| 指标 | 本期 | 上期 | 环比 |
|------|------|------|------|
| 成交单数 | {{deals_count}}单 | {{deals_count_last}}单 | {{deals_change}}% |
| 成交金额 | {{total_amount}}万 | {{total_amount_last}}万 | {{amount_change}}% |
| 新增客户 | {{new_customers}}个 | {{new_customers_last}}个 | {{customers_change}}% |
| 跟进次数 | {{followup_count}}次 | {{followup_count_last}}次 | {{followup_change}}% |
| 回款金额 | {{received_amount}}万 | {{received_amount_last}}万 | {{received_change}}% |
| 客单价 | {{avg_deal_size}}万 | {{avg_deal_size_last}}万 | {{avg_change}}% |

---

## 🏆 成交明细

| 客户 | 公司 | 产品 | 金额 | 签约日期 |
|------|------|------|------|----------|
| {{deal_1_customer}} | {{deal_1_company}} | {{deal_1_product}} | {{deal_1_amount}}万 | {{deal_1_date}} |
| {{deal_2_customer}} | {{deal_2_company}} | {{deal_2_product}} | {{deal_2_amount}}万 | {{deal_2_date}} |
| {{deal_3_customer}} | {{deal_3_company}} | {{deal_3_product}} | {{deal_3_amount}}万 | {{deal_3_date}} |

---

## 📈 趋势分析

### 成交量趋势
{{deals_trend_chart}}

### 金额趋势
{{amount_trend_chart}}

---

## 👥 团队排名（团队模式）

| 排名 | 姓名 | 成交单数 | 成交金额 | 完成率 |
|------|------|----------|----------|--------|
| 1 | {{rank1_name}} | {{rank1_deals}}单 | {{rank1_amount}}万 | {{rank1_rate}}% |
| 2 | {{rank2_name}} | {{rank2_deals}}单 | {{rank2_amount}}万 | {{rank2_rate}}% |
| 3 | {{rank3_name}} | {{rank3_deals}}单 | {{rank3_amount}}万 | {{rank3_rate}}% |

---

## 🎯 目标完成情况

| 指标 | 目标 | 实际 | 完成率 |
|------|------|------|--------|
| 成交金额 | {{target_amount}}万 | {{actual_amount}}万 | {{amount_completion}}% |
| 成交单数 | {{target_deals}}单 | {{actual_deals}}单 | {{deals_completion}}% |
| 新增客户 | {{target_customers}}个 | {{actual_customers}}个 | {{customers_completion}}% |
| 回款金额 | {{target_received}}万 | {{actual_received}}万 | {{received_completion}}% |

---

## 💰 回款统计

| 指标 | 数值 |
|------|------|
| 已回款 | {{received_amount}}万 |
| 待回款 | {{pending_amount}}万 |
| 逾期回款 | {{overdue_amount}}万 |
| 回款率 | {{received_rate}}% |

---

## 💡 改进建议

1. {{suggestion_1}}
2. {{suggestion_2}}
3. {{suggestion_3}}

---

*本报告由销售客户管家自动生成*
