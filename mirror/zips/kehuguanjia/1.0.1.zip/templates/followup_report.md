# 跟进工作报告

**生成时间**：{{report_date}}
**统计周期**：{{period}}

---

## 📊 统计概览

| 指标 | 数值 |
|------|------|
| 待跟进总数 | {{total_pending}} |
| 今日紧急 | {{urgent_count}} |
| 今日常规 | {{normal_count}} |
| 超时未跟进 | {{overdue_count}} |
| 本周计划 | {{future_count}} |

---

## 🔥 今日紧急任务

| 客户 | 公司 | 阶段 | 预算 | 建议 |
|------|------|------|------|------|
| {{urgent_name_1}} | {{urgent_company_1}} | {{urgent_stage_1}} | {{urgent_budget_1}} | {{urgent_suggestion_1}} |
| {{urgent_name_2}} | {{urgent_company_2}} | {{urgent_stage_2}} | {{urgent_budget_2}} | {{urgent_suggestion_2}} |

---

## 📋 今日待办

| 客户 | 公司 | 上次联系 | 建议 |
|------|------|----------|------|
| {{normal_name_1}} | {{normal_company_1}} | {{normal_last_1}} | {{normal_suggestion_1}} |
| {{normal_name_2}} | {{normal_company_2}} | {{normal_last_2}} | {{normal_suggestion_2}} |

---

## ⚠️ 超时预警

| 客户 | 公司 | 超时天数 | 最后联系 | 建议 |
|------|------|----------|----------|------|
| {{overdue_name_1}} | {{overdue_company_1}} | {{overdue_days_1}} | {{overdue_last_1}} | {{overdue_suggestion_1}} |
| {{overdue_name_2}} | {{overdue_company_2}} | {{overdue_days_2}} | {{overdue_last_2}} | {{overdue_suggestion_2}} |

---

## 📆 本周计划

| 日期 | 客户 | 公司 | 计划事项 |
|------|------|------|----------|
| {{future_date_1}} | {{future_name_1}} | {{future_company_1}} | {{future_plan_1}} |
| {{future_date_2}} | {{future_name_2}} | {{future_company_2}} | {{future_plan_2}} |

---

## 💡 优化建议

1. {{suggestion_1}}
2. {{suggestion_2}}
3. {{suggestion_3}}

---

*本报告由销售客户管家自动生成*
