#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话术模板库模块
提供各类销售场景的话术模板，支持根据客户画像个性化推荐
"""

import json
import os
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime


class ObjectionType:
    """异议类型"""
    PRICE = "price"           # 价格类
    CONSIDER = "consider"     # 考虑类
    COMPETITOR = "competitor" # 竞品类
    TIME = "time"             # 时间类
    REFUSE = "refuse"         # 拒绝类


class ScenarioType:
    """场景类型"""
    FIRST_CONTACT = "first_contact"       # 初次接触
    NEEDS_DISCOVERY = "needs_discovery"   # 需求挖掘
    QUOTING = "quoting"                   # 报价
    OBJECTION = "objection"               # 异议处理
    CLOSING = "closing"                   # 促单
    MAINTENANCE = "maintenance"           # 客户维护


class ScriptGenerator:
    """话术生成器"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self._load_templates()
    
    def _load_templates(self):
        """加载话术模板"""
        # 内置模板
        self.templates = {
            # 初次接触话术
            ScenarioType.FIRST_CONTACT: {
                "direct": {
                    "title": "直接型开场",
                    "template": "您好，我是{company}的销售顾问{name}。了解到贵公司在{industry}领域发展迅速，今天特意联系您，不知道是否方便聊几句？",
                    "适用画像": "果断型",
                    "要点": ["简洁明了", "快速切入主题", "尊重对方时间"]
                },
                "consultant": {
                    "title": "顾问型开场",
                    "template": "{name}您好，我是张三。我注意到咱们{industry}行业最近有几个趋势...（分享行业洞察）。想跟您请教一下，您这边目前在这方面有什么规划或者困扰吗？",
                    "适用画像": "分析型",
                    "要点": ["展现专业度", "以请教姿态切入", "引发兴趣"]
                },
                "relationship": {
                    "title": "关系型开场",
                    "template": "{name}，上次交流受益匪浅。今天特意来跟您汇报一下我们最新的研究成果，同时也想听听您这段时间的新想法。",
                    "适用画像": "关系型",
                    "要点": ["延续关系", "提供价值", "温和切入"]
                }
            },
            
            # 需求挖掘话术
            ScenarioType.NEEDS_DISCOVERY: {
                "spin_s": {
                    "title": "SPIN-S现状问题",
                    "template": "{name}，您现在团队规模有多大？平时客户管理是怎么做的？目前的客户跟进流程是怎样的？有什么让您觉得不太顺畅的地方吗？",
                    "要点": ["了解现状", "建立对话基础", "寻找切入点"]
                },
                "spin_p": {
                    "title": "SPIN-P痛点问题",
                    "template": "那在客户量增加的情况下，您觉得最难处理的是什么？如果这个问题不解决，对业务会有什么影响？",
                    "要点": ["挖掘痛点", "强调问题严重性", "为方案铺垫"]
                },
                "spin_i": {
                    "title": "SPIN-I影响问题",
                    "template": "这种情况大概持续多久了？每个月光是处理这类问题，大概需要投入多少人力和时间？",
                    "要点": ["量化影响", "加深认知", "创造紧迫感"]
                },
                "spin_n": {
                    "title": "SPIN-N需求问题",
                    "template": "如果有一套方案能帮您解决这些问题，您觉得最希望改善的是哪方面？假设效果达到预期，您愿意投入多少资源来推进这件事？",
                    "要点": ["引导解决方案", "了解预算意愿", "为报价铺垫"]
                }
            },
            
            # 报价话术
            ScenarioType.QUOTING: {
                "direct": {
                    "title": "直接报价型",
                    "template": "{name}，经过评估，我们这套方案的报价是{price}万。这个价格包含了{features}。",
                    "要点": ["清晰明确", "强调价值", "不过度解释"]
                },
                "value_guide": {
                    "title": "价值引导型",
                    "template": "{name}，在给您报价之前，我想先确认一下，您最看重的是哪些方面？根据您刚才说的，我们推荐方案A。这个方案在{highlight}方面特别突出，能够帮您{benefit}。总投入{price}万，但相比方案B，三年下来能帮您节省{ saving}万的成本。",
                    "要点": ["先了解需求", "针对性推荐", "强调性价比"]
                },
                "tiered": {
                    "title": "分层报价型",
                    "template": "{name}，我们有三个方案供您选择：基础版{price1}万，适合{scene1}；标准版{price2}万，包含{features2}；高级版{price3}万，全面满足{demand}。您可以先了解一下，等您确定方向后，我们可以详细聊。",
                    "要点": ["提供选择", "不过度推销", "让客户主导"]
                }
            },
            
            # 促单话术
            ScenarioType.CLOSING: {
                "direct": {
                    "title": "直接型",
                    "template": "{name}，我们今天就把合同签了吧。我这边已经准备好了，您看还有什么顾虑吗？",
                    "适用画像": "果断型",
                    "要点": ["直接邀请成交", "确认最后顾虑", "推动决策"]
                },
                "urgency": {
                    "title": "紧迫感型",
                    "template": "{name}，这个优惠价格到这个月底就结束了。如果您今天确定，我可以帮您申请保留这个优惠。",
                    "适用画像": "犹豫型",
                    "要点": ["制造紧迫感", "限时优惠", "降低决策难度"]
                },
                "alternative": {
                    "title": "选择成交型",
                    "template": "{name}，您看是今天签合同还是我们先安排个产品体验？体验满意的话，咱们再确定合作细节。",
                    "适用画像": "分析型",
                    "要点": ["提供过渡方案", "降低决策压力", "保持跟进"]
                },
                "assumption": {
                    "title": "假设成交型",
                    "template": "{name}，我看您对方案挺满意的，要不这样，我先把合同发您，您看是今天签还是明天方便？",
                    "适用画像": "关系型",
                    "要点": ["默认同意", "提供时间选择", "自然过渡"]
                }
            },
            
            # 客户维护话术
            ScenarioType.MAINTENANCE: {
                "periodic": {
                    "title": "定期回访",
                    "template": "{name}，您好！上次合作后一直想找机会感谢您。咱们产品用着还顺手吗？有什么需要我们支持的地方随时说。",
                    "要点": ["表达感谢", "关心使用情况", "保持联系"]
                },
                "value": {
                    "title": "价值推送",
                    "template": "{name}，有个好消息想第一时间告诉您！我们最近升级了{service}功能，据说能帮您提升{metric}%。您这边什么时候方便，我给您详细讲讲？",
                    "要点": ["提供增量价值", "引发二次需求", "创造见面机会"]
                },
                "feedback": {
                    "title": "意见征集",
                    "template": "{name}，想打扰您几分钟做个回访。我们一直在优化产品，很想知道您使用过程中的真实感受，方便说几点建议吗？",
                    "要点": ["展现改进态度", "增强参与感", "收集反馈"]
                }
            }
        }
        
        # 异议处理模板
        self.objection_templates = {
            ObjectionType.PRICE: {
                "keywords": ["贵", "贵了", "太贵", "便宜", "优惠", "打折", "降价", "便宜点"],
                "value_comparison": {
                    "title": "价值对比法",
                    "适用画像": "分析型",
                    "template": "{name}，我理解您对价格的顾虑。咱们来算一笔账：我们的设备比竞品贵{percent}%，但故障率低{failure_rate}%。这意味着每年维修成本省{saving}万。加上停机损失，一年至少省{total}万。设备用{years}年，相当于省{total_saving}万。现在多花{diff}万，后面省{total_saving}万，您觉得值不值？",
                    "要点": ["承认价格确实高", "用数据对比", "引导客户算账"]
                },
                "cost_breakdown": {
                    "title": "成本分解法",
                    "适用画像": "关系型",
                    "template": "{name}，其实我也知道这笔投入不小。但您想想，这里面包含了{feature1}、{feature2}、{feature3}。这样算下来，每个月的投入其实只有{monthly}元，还不到您请一个助理月薪的三分之一。",
                    "要点": ["分解成本构成", "强调包含内容", "换算成小单位"]
                },
                "roi": {
                    "title": "投资回报法",
                    "适用画像": "犹豫型",
                    "template": "{name}，咱们买这个东西不是为了省钱，而是为了赚钱。您算过没有，如果这套方案能帮您提升{efficiency}%的效率，意味着每个月多创造{value}价值？投入是{price}，回报是{value}，ROI超过{roi}%，您说值不值？",
                    "要点": ["强调投资回报", "量化收益", "计算ROI"]
                },
                "tie_to_deal": {
                    "title": "优惠成交挂钩法",
                    "template": "{name}，价格方面我确实能给到一定的优惠。但我想先确认一下，除了价格之外，咱们还有其他顾虑吗？如果今天这些问题都能解决的话，我可以帮您申请一下特殊优惠。您看还有什么需要我这边配合的？",
                    "要点": ["不轻易让步", "将优惠与成交挂钩", "了解真实顾虑"]
                }
            },
            
            ObjectionType.CONSIDER: {
                "keywords": ["考虑", "想想", "商量", "再想想", "商量一下"],
                "direct": {
                    "title": "直接询问顾虑",
                    "template": "{name}，我理解您需要时间考虑。不过我想请教一下，除了今天聊的这些，还有什么您担心的吗？如果您告诉我真正顾虑的是什么，我可以针对性地给您更多信息，这样您做决定也会更踏实一些。",
                    "要点": ["不回避", "主动询问", "针对性解决"]
                },
                "timeline": {
                    "title": "确认决策时间线",
                    "template": "{name}，当然要慎重考虑。我想问一下，您大概什么时候会做这个决定？我这边可以给您准备一份详细的对比分析资料，您在考虑的时候可以作为参考。同时也想提醒您，这个优惠到这个月底就结束了。",
                    "要点": ["确认时间节点", "提供辅助材料", "适度制造紧迫"]
                },
                "address_concerns": {
                    "title": "逐条解决法",
                    "template": "{name}，您说要考虑考虑，我很理解。能不能跟我透个底，主要是在哪些方面需要再想想？是我说得不够清楚，还是有其他的顾虑？您说一个，我帮您分析分析。",
                    "要点": ["逐条确认顾虑", "当场解答", "推动决策"]
                }
            },
            
            ObjectionType.COMPETITOR: {
                "keywords": ["别人", "竞品", "对比", "XX公司", "其他家"],
                "compare": {
                    "title": "竞品对比话术",
                    "template": "{name}，有对比是好事，买东西就是要货比三家。我想请教一下，您对比的主要是哪些方面？我们跟XX的区别主要在{points}，您看这些方面对您重要吗？我觉得最终选谁不重要，关键是选到最适合自己的。",
                    "要点": ["不贬低竞品", "了解对比维度", "强调适合自己"]
                },
                "differentiate": {
                    "title": "差异化优势",
                    "template": "{name}，感谢您告诉我还在对比其他家，这说明您确实在认真选择。我很想了解一下，在您对比的这些方案中，最打动您的是什么？这样我能更有针对性地给您展示我们的优势。",
                    "要点": ["了解竞品优势", "寻找差异化点", "针对性呈现"]
                }
            },
            
            ObjectionType.TIME: {
                "keywords": ["没时间", "忙", "下次", "改天", "回头"],
                "respect_time": {
                    "title": "尊重时间型",
                    "template": "{name}，我理解您时间宝贵，我不会耽误您太久。给我三分钟，如果说完您觉得没价值，我立刻挂电话。如果对您有帮助，咱们再约时间详聊，怎么样？",
                    "要点": ["尊重对方时间", "设定预期", "给选择权"]
                },
                "efficient": {
                    "title": "高效沟通型",
                    "template": "{name}，您这么忙还愿意接我电话，说明您对这个事还是有兴趣的。我就简单问一句：除了时间问题，还有其他让您犹豫的地方吗？如果没有，我们可以先把这个框架定下来，后面细节再慢慢敲。",
                    "要点": ["确认真正原因", "简化方案", "先框架后细节"]
                },
                "schedule": {
                    "title": "预约时间型",
                    "template": "{name}，完全理解。那这样，您什么时候方便？我这边记一下，到时候我提前给您发个消息，您要是有空我们就聊两句，没空也没关系，您先忙。",
                    "要点": ["主动约时间", "保持友好态度", "不放弃跟进"]
                }
            },
            
            ObjectionType.REFUSE: {
                "keywords": ["不要", "不需要", "算了", "别打了", "不考虑"],
                "gentle": {
                    "title": "温和确认型",
                    "template": "{name}，我听到您说暂时不需要，不想浪费您时间。不过我想确认一下，是因为目前真的不需要，还是说我们的产品没有解决到您的问题？如果是后者，我很想改进一下。",
                    "要点": ["不强行推销", "了解拒绝原因", "保持友好关系"]
                },
                "future": {
                    "title": "未来机会型",
                    "template": "{name}，完全理解。那这样，我把我们的资料发您邮箱，您先留着，万一以后有需要可以随时联系我。或者我们可以加个微信，以后有合适的活动我第一时间通知您。",
                    "要点": ["留下联系方式", "保持弱连接", "为未来铺垫"]
                }
            }
        }
        
        # 尝试加载自定义模板
        custom_file = os.path.join(self.data_dir, "custom_scripts.json")
        if os.path.exists(custom_file):
            try:
                with open(custom_file, 'r', encoding='utf-8') as f:
                    custom = json.load(f)
                    self._merge_custom_templates(custom)
            except:
                pass
    
    def _merge_custom_templates(self, custom_templates: Dict):
        """合并自定义模板"""
        for key, value in custom_templates.items():
            if key in self.templates:
                self.templates[key].update(value)
            else:
                self.templates[key] = value
    
    def get_script(self, scenario: str, customer_profile: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """
        获取话术
        
        Args:
            scenario: 场景类型或关键词
            customer_profile: 客户画像（可选）
            **kwargs: 填充变量
            
        Returns:
            话术信息
        """
        scenario = scenario.lower().strip()
        
        # 首先尝试精确匹配场景
        if scenario in [s.lower() for s in self.templates.keys()]:
            for key in self.templates.keys():
                if key.lower() == scenario:
                    return self._build_script(key, self.templates[key], customer_profile, kwargs)
        
        # 尝试关键词匹配异议处理
        for obj_type, templates in self.objection_templates.items():
            if any(kw in scenario for kw in templates.get("keywords", [])):
                # 根据画像选择最佳话术
                selected = self._select_objection_script(obj_type, customer_profile, templates)
                return self._build_script(f"异议_{obj_type}", selected, customer_profile, kwargs)
        
        # 默认返回引导
        return {
            "scenario": scenario,
            "script": "请描述您需要的话术场景，如：初次接触、需求挖掘、报价、异议处理、促单、维护等",
            "available_scenarios": list(self.templates.keys()),
            "examples": [
                "/话术 初次接触",
                "/话术 报价",
                "/话术 处理太贵了",
                "/话术 促单"
            ]
        }
    
    def _select_objection_script(self, obj_type: str, profile: Optional[Dict], templates: Dict) -> Dict:
        """根据客户画像选择异议处理话术"""
        if not profile:
            return templates.get("value_comparison", templates.get(list(templates.keys())[1]))
        
        personality = profile.get("personality", {}).get("type", "分析型")
        
        # 定价类异议有多种处理方式
        if obj_type == ObjectionType.PRICE:
            selection_map = {
                "分析型": "value_comparison",
                "关系型": "cost_breakdown",
                "犹豫型": "roi",
                "果断型": "tie_to_deal"
            }
            method = selection_map.get(personality, "value_comparison")
            return templates.get(method, templates.get("value_comparison"))
        
        # 其他异议返回第一个有效模板
        for key in ["direct", "compare", "gentle"]:
            if key in templates:
                return templates[key]
        
        return templates
    
    def _build_script(self, scenario: str, template: Dict, profile: Optional[Dict], kwargs: Dict) -> Dict[str, Any]:
        """构建话术"""
        # 获取填充变量
        if not kwargs and profile:
            kwargs = {
                "name": profile.get("name", "客户"),
                "company": profile.get("company", ""),
                "industry": profile.get("industry", ""),
                "product": profile.get("requirement", "")
            }
        
        template_text = template.get("template", "")
        try:
            script = template_text.format(**kwargs)
        except KeyError:
            script = template_text
        
        return {
            "scenario": scenario,
            "title": template.get("title", ""),
            "script": script,
            "适用画像": template.get("适用画像", "通用"),
            "要点": template.get("要点", []),
            "usage_tips": self._generate_tips(template)
        }
    
    def _generate_tips(self, template: Dict) -> List[str]:
        """生成使用提示"""
        tips = []
        points = template.get("要点", [])
        
        for point in points:
            tips.append(f"• {point}")
        
        # 根据场景添加通用提示
        scenario = template.get("title", "")
        if "价值" in scenario or "回报" in scenario:
            tips.append("• 用数据说话时要有底气，提前准备好数字")
        if "顾虑" in scenario or "异议" in scenario:
            tips.append("• 先认同客户，再引导，避免对立")
        
        return tips
    
    def handle_objection(self, objection_text: str, customer_profile: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """
        处理异议
        
        Args:
            objection_text: 客户异议描述
            customer_profile: 客户画像
            **kwargs: 其他参数
            
        Returns:
            处理话术和要点
        """
        objection_lower = objection_text.lower()
        
        # 识别异议类型
        obj_type = None
        for otype, templates in self.objection_templates.items():
            if any(kw in objection_lower for kw in templates.get("keywords", [])):
                obj_type = otype
                break
        
        if not obj_type:
            return {
                "objection": objection_text,
                "type": "未知",
                "script": "感谢您的反馈，请具体说明您的顾虑，我会针对性地为您解答。",
                "tips": ["先认同客户感受", "了解具体顾虑", "针对性回应"]
            }
        
        # 获取对应类型的话术
        templates = self.objection_templates.get(obj_type, {})
        selected = self._select_objection_script(obj_type, customer_profile, templates)
        
        type_names = {
            ObjectionType.PRICE: "价格类",
            ObjectionType.CONSIDER: "考虑类",
            ObjectionType.COMPETITOR: "竞品类",
            ObjectionType.TIME: "时间类",
            ObjectionType.REFUSE: "拒绝类"
        }
        
        script_info = self._build_script(f"异议处理_{obj_type}", selected, customer_profile, kwargs)
        
        return {
            "objection": objection_text,
            "type": type_names.get(obj_type, "未知"),
            "script": script_info["script"],
            "title": script_info["title"],
            "tips": script_info["要点"]
        }
    
    def search_templates(self, keyword: str) -> List[Dict]:
        """搜索模板"""
        keyword = keyword.lower()
        results = []
        
        # 搜索场景模板
        for scenario, templates in self.templates.items():
            for key, template in templates.items():
                if keyword in scenario.lower() or keyword in template.get("title", "").lower():
                    results.append({
                        "type": "场景",
                        "scenario": scenario,
                        "title": template.get("title"),
                        "适用画像": template.get("适用画像", "通用")
                    })
        
        # 搜索异议处理
        for obj_type, templates in self.objection_templates.items():
            for key, template in templates.items():
                if keyword in template.get("title", "").lower():
                    results.append({
                        "type": "异议处理",
                        "objection_type": obj_type,
                        "title": template.get("title"),
                        "适用画像": template.get("适用画像", "通用")
                    })
        
        return results
    
    def list_scenarios(self) -> Dict[str, List[str]]:
        """列出所有场景"""
        return {
            "场景话术": [
                f"{k}: {list(v.keys())}" for k, v in self.templates.items()
            ],
            "异议处理": [
                f"{k}: {t.get('title', k)}" for k, t in self.objection_templates.items()
            ]
        }
    
    def save_custom_script(self, name: str, script_data: Dict) -> bool:
        """保存自定义话术"""
        custom_file = os.path.join(self.data_dir, "custom_scripts.json")
        
        custom_scripts = {}
        if os.path.exists(custom_file):
            try:
                with open(custom_file, 'r', encoding='utf-8') as f:
                    custom_scripts = json.load(f)
            except:
                pass
        
        custom_scripts[name] = script_data
        
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            with open(custom_file, 'w', encoding='utf-8') as f:
                json.dump(custom_scripts, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False


def generate_script_text(scenario: str, customer_name: str = "王总", **kwargs) -> str:
    """
    快速生成话术文本（便捷函数）
    
    Args:
        scenario: 场景类型
        customer_name: 客户姓名
        **kwargs: 其他填充参数
        
    Returns:
        格式化的话术文本
    """
    generator = ScriptGenerator()
    result = generator.get_script(scenario, kwargs)
    
    if "script" in result:
        return f"💬 {result.get('title', scenario)} - {customer_name}\n\n{result['script']}\n\n【要点】\n" + "\n".join([f"✅ {t}" for t in result.get("要点", [])])
    else:
        return result.get("script", "无法生成话术，请尝试其他场景")


if __name__ == "__main__":
    # 测试代码
    generator = ScriptGenerator()
    
    # 测试场景话术
    print("=" * 50)
    print("📝 场景话术测试")
    print("=" * 50)
    
    result = generator.get_script("初次接触", {"name": "王总", "company": "XX科技"})
    print(f"\n【{result['title']}】")
    print(result['script'])
    print(f"适用画像: {result['适用画像']}")
    print(f"要点: {', '.join(result['要点'])}")
    
    # 测试异议处理
    print("\n" + "=" * 50)
    print("💬 异议处理测试 - '太贵了'")
    print("=" * 50)
    
    result = generator.handle_objection("太贵了", {"personality": {"type": "分析型"}})
    print(f"\n异议类型: {result['type']}")
    print(f"处理方法: {result['title']}")
    print(f"\n处理话术:")
    print(result['script'])
    print(f"\n要点: {', '.join(result['tips'])}")
