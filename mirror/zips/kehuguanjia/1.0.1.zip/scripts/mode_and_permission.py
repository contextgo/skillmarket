#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模式切换、权限管理、撞单检测、公海池模块
支持个人/团队模式智能切换、权限控制、撞单检测、公海池管理
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any


class ModeManager:
    """模式管理器"""
    
    DATA_DIR = "data"
    SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
    
    MODE_PERSONAL = "personal"
    MODE_TEAM = "team"
    
    def __init__(self):
        self.settings = self._load_settings()
    
    def _load_settings(self) -> Dict:
        """加载设置"""
        if os.path.exists(self.SETTINGS_FILE):
            try:
                with open(self.SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"mode": self.MODE_PERSONAL}
    
    def _save_settings(self) -> bool:
        """保存设置"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def get_mode(self) -> str:
        """获取当前模式"""
        return self.settings.get("mode", self.MODE_PERSONAL)
    
    def switch_mode(self, mode: str) -> Tuple[bool, str]:
        """切换模式"""
        if mode not in [self.MODE_PERSONAL, self.MODE_TEAM]:
            return False, "无效的模式"
        
        self.settings["mode"] = mode
        if self._save_settings():
            return True, f"已切换到{'团队' if mode == self.MODE_TEAM else '个人'}模式"
        return False, "切换失败"
    
    def get_mode_info(self) -> Dict:
        """获取模式信息"""
        mode = self.get_mode()
        return {
            "mode": mode,
            "mode_name": "团队模式" if mode == self.MODE_TEAM else "个人模式",
            "features": self._get_mode_features(mode)
        }
    
    def _get_mode_features(self, mode: str) -> List[str]:
        """获取模式功能列表"""
        base_features = [
            "客户档案管理",
            "跟进提醒",
            "客户画像分析",
            "话术生成器",
            "销售漏斗"
        ]
        
        if mode == self.MODE_TEAM:
            return base_features + [
                "团队协作",
                "客户分配",
                "飞书文档共享",
                "撞单检测",
                "公海池",
                "团队业绩",
                "权限管理"
            ]
        return base_features


class CollisionDetector:
    """撞单检测器"""
    
    DATA_DIR = "data"
    
    def __init__(self):
        self.customers = self._load_customers()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def check_collision(self, customer_info: Dict, exclude_user: str = None) -> List[Dict]:
        """
        检测撞单
        
        Args:
            customer_info: 客户信息
            exclude_user: 排除的用户ID
            
        Returns:
            疑似撞单列表
        """
        collisions = []
        
        name = customer_info.get("name", "").strip()
        company = customer_info.get("company", "").strip()
        phone = customer_info.get("phone", "").strip()
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            # 排除自己
            if exclude_user and customer.get("created_by") == exclude_user:
                continue
            
            reasons = []
            
            # 姓名匹配
            if name and customer.get("name") == name:
                reasons.append(f"同名客户")
            
            # 公司匹配
            if company and customer.get("company") == company:
                reasons.append(f"同公司: {company}")
            
            # 电话匹配
            if phone and customer.get("phone") == phone:
                reasons.append(f"同电话")
            
            if reasons:
                collisions.append({
                    "customer_id": customer.get("id"),
                    "customer_name": customer.get("name"),
                    "company": customer.get("company"),
                    "phone": customer.get("phone"),
                    "assigned_to": customer.get("assignee"),
                    "assigned_name": customer.get("assignee_name"),
                    "created_by": customer.get("created_by"),
                    "collision_reasons": reasons,
                    "stage": customer.get("stage"),
                    "last_contact": customer.get("last_contact", "")[:10] if customer.get("last_contact") else None
                })
        
        return collisions
    
    def get_all_collisions(self) -> List[Dict]:
        """获取所有疑似撞单"""
        all_names = {}
        all_companies = {}
        all_phones = {}
        
        # 收集所有数据
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            name = customer.get("name", "")
            company = customer.get("company", "")
            phone = customer.get("phone", "")
            
            if name:
                if name not in all_names:
                    all_names[name] = []
                all_names[name].append(customer)
            
            if company:
                if company not in all_companies:
                    all_companies[company] = []
                all_companies[company].append(customer)
            
            if phone:
                if phone not in all_phones:
                    all_phones[phone] = []
                all_phones[phone].append(customer)
        
        # 找出重复
        collisions = []
        seen = set()
        
        for source, customers in all_names.items():
            if len(customers) > 1:
                for c in customers:
                    key = c.get("id")
                    if key not in seen:
                        collisions.append({
                            "customer": c,
                            "collision_type": "同名",
                            "collision_value": source,
                            "related": [cust for cust in customers if cust.get("id") != key]
                        })
                        seen.add(key)
        
        for source, customers in all_companies.items():
            if len(customers) > 1:
                for c in customers:
                    key = c.get("id")
                    if key not in seen:
                        collisions.append({
                            "customer": c,
                            "collision_type": "同公司",
                            "collision_value": source,
                            "related": [cust for cust in customers if cust.get("id") != key]
                        })
                        seen.add(key)
        
        return collisions


class PublicPool:
    """公海池管理"""
    
    DATA_DIR = "data"
    PUBLIC_POOL_FILE = os.path.join(DATA_DIR, "public_pool.json")
    
    # 公海池配置
    AUTO_POOL_DAYS = 30  # 超过30天未跟进自动入公海
    MAX_UNCLAIM_DAYS = 7  # 公海客户最多保留7天
    
    def __init__(self):
        self.pool = self._load_pool()
        self.customers = self._load_customers()
    
    def _load_pool(self) -> List[Dict]:
        """加载公海池"""
        if os.path.exists(self.PUBLIC_POOL_FILE):
            try:
                with open(self.PUBLIC_POOL_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_pool(self) -> bool:
        """保存公海池"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.PUBLIC_POOL_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.pool, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def _save_customers(self) -> bool:
        """保存客户数据"""
        try:
            with open(os.path.join(self.DATA_DIR, "customers.json"), 'w', encoding='utf-8') as f:
                json.dump(self.customers, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def add_to_pool(self, customer_id: str, reason: str = "") -> Tuple[bool, str]:
        """客户加入公海池"""
        for customer in self.customers:
            if customer.get("id") == customer_id:
                # 移除负责人
                customer["assignee"] = None
                customer["assignee_name"] = None
                customer["is_public"] = True
                customer["pooled_at"] = datetime.now().isoformat()
                customer["pool_reason"] = reason
                
                # 从销售人员移出
                if "contracts" in customer:
                    # 保留合同关联
                    pass
                
                # 添加到公海池
                pool_entry = {
                    "customer_id": customer_id,
                    "customer_name": customer.get("name"),
                    "company": customer.get("company"),
                    "pooled_at": datetime.now().isoformat(),
                    "pool_reason": reason,
                    "previous_owner": customer.get("assignee"),
                    "status": "available"
                }
                
                # 移除已有记录
                self.pool = [p for p in self.pool if p.get("customer_id") != customer_id]
                self.pool.append(pool_entry)
                
                self._save_customers()
                self._save_pool()
                return True, "客户已移入公海池"
        
        return False, "客户不存在"
    
    def auto_pool_long_idle(self) -> List[str]:
        """自动将长期未跟进的客户移入公海池"""
        now = datetime.now()
        pooled = []
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            if customer.get("is_public"):
                continue
            if customer.get("stage") == "成交":
                continue
            
            last_contact = customer.get("last_contact")
            if not last_contact:
                created_at = customer.get("created_at", "")
                if created_at:
                    try:
                        created_date = datetime.fromisoformat(created_at)
                        if (now - created_date).days > self.AUTO_POOL_DAYS:
                            success, msg = self.add_to_pool(customer.get("id"), "长期未跟进")
                            if success:
                                pooled.append(customer.get("name"))
                    except:
                        pass
            else:
                try:
                    last_date = datetime.fromisoformat(last_contact)
                    if (now - last_date).days > self.AUTO_POOL_DAYS:
                        success, msg = self.add_to_pool(customer.get("id"), "长期未跟进")
                        if success:
                            pooled.append(customer.get("name"))
                except:
                    pass
        
        return pooled
    
    def claim_customer(self, customer_id: str, user_id: str, user_name: str) -> Tuple[bool, str]:
        """认领公海客户"""
        for i, entry in enumerate(self.pool):
            if entry.get("customer_id") == customer_id:
                if entry.get("status") != "available":
                    return False, "该客户已被认领"
                
                # 更新客户信息
                for j, customer in enumerate(self.customers):
                    if customer.get("id") == customer_id:
                        self.customers[j]["assignee"] = user_id
                        self.customers[j]["assignee_name"] = user_name
                        self.customers[j]["is_public"] = False
                        self.customers[j]["claimed_at"] = datetime.now().isoformat()
                        self.customers[j]["claimed_by"] = user_id
                        break
                
                # 更新公海池记录
                self.pool[i]["status"] = "claimed"
                self.pool[i]["claimed_by"] = user_id
                self.pool[i]["claimed_by_name"] = user_name
                self.pool[i]["claimed_at"] = datetime.now().isoformat()
                
                self._save_customers()
                self._save_pool()
                return True, f"已认领客户: {entry.get('customer_name')}"
        
        return False, "客户不在公海池中"
    
    def get_pool_customers(self, filters: Dict = None) -> List[Dict]:
        """获取公海客户列表"""
        available = [p for p in self.pool if p.get("status") == "available"]
        
        if filters:
            if filters.get("min_budget"):
                available = [p for p in available 
                           if self._get_customer_budget(p.get("customer_id")) >= filters["min_budget"]]
            
            if filters.get("search"):
                keyword = filters["search"].lower()
                available = [p for p in available 
                           if keyword in p.get("customer_name", "").lower()
                           or keyword in p.get("company", "").lower()]
        
        return sorted(available, key=lambda x: x.get("pooled_at", ""), reverse=True)
    
    def _get_customer_budget(self, customer_id: str) -> float:
        """获取客户预算"""
        for customer in self.customers:
            if customer.get("id") == customer_id:
                return customer.get("budget_value", 0)
        return 0


def generate_mode_report() -> str:
    """生成模式报告"""
    mode_mgr = ModeManager()
    pool_mgr = PublicPool()
    collision_mgr = CollisionDetector()
    
    mode_info = mode_mgr.get_mode_info()
    pool_customers = pool_mgr.get_pool_customers()
    collisions = collision_mgr.get_all_collisions()
    
    lines = [
        "⚙️ 模式与协作报告",
        "=" * 50,
        "",
        f"【当前模式】{mode_info['mode_name']}",
        f"可用功能：{', '.join(mode_info['features'][:5])}...",
        "",
        f"【公海池】",
        f"  待认领客户：{len(pool_customers)}个",
        "",
        f"【撞单预警】",
        f"  疑似撞单：{len(collisions)}对",
        ""
    ]
    
    return "\n".join(lines)


if __name__ == "__main__":
    print(generate_mode_report())
