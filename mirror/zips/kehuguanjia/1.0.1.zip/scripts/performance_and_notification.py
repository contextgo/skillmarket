#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
业绩核算、通知机制、自定义字段、合规隐私模块
支持个人/团队业绩统计、通知提醒、自定义字段配置、隐私合规管理
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any


class PerformanceCalculator:
    """业绩核算器"""
    
    DATA_DIR = "data"
    
    def __init__(self):
        self.customers = self._load_customers()
        self.contracts = self._load_contracts()
        self.returns = self._load_returns()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_contracts(self) -> List[Dict]:
        """加载合同数据"""
        file_path = os.path.join(self.DATA_DIR, "contracts.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_returns(self) -> List[Dict]:
        """加载回款数据"""
        file_path = os.path.join(self.DATA_DIR, "returns.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def calculate_personal_performance(self, user_id: str = None, period: str = "month") -> Dict:
        """
        计算个人业绩
        
        Args:
            user_id: 用户ID
            period: 统计周期 (month/quarter/year)
        """
        now = datetime.now()
        
        # 计算时间范围
        if period == "month":
            start_date = now.replace(day=1, hour=0, minute=0, second=0)
            end_date = (start_date + timedelta(days=32)).replace(day=1)
        elif period == "quarter":
            quarter = (now.month - 1) // 3
            start_date = now.replace(month=quarter * 3 + 1, day=1, hour=0, minute=0, second=0)
            end_date = (start_date + timedelta(days=95)).replace(day=1)
        else:  # year
            start_date = now.replace(month=1, day=1, hour=0, minute=0, second=0)
            end_date = now.replace(month=12, day=31)
        
        # 统计成交
        deals = []
        total_amount = 0
        new_customers = 0
        followups = 0
        
        for contract in self.contracts:
            if user_id and contract.get("created_by") != user_id:
                continue
            
            signed_date = contract.get("signed_date", "")
            if signed_date:
                try:
                    signed = datetime.fromisoformat(signed_date)
                    if start_date <= signed < end_date:
                        deals.append(contract)
                        total_amount += contract.get("amount", 0)
                except:
                    pass
        
        # 统计新增客户
        for customer in self.customers:
            if user_id and customer.get("created_by") != user_id:
                continue
            if customer.get("is_deleted"):
                continue
            
            created_at = customer.get("created_at", "")
            if created_at:
                try:
                    created = datetime.fromisoformat(created_at)
                    if start_date <= created < end_date:
                        new_customers += 1
                except:
                    pass
            
            followups += customer.get("follow_up_count", 0)
        
        # 回款统计
        received_amount = 0
        for ret in self.returns:
            if user_id and ret.get("created_by") != user_id:
                continue
            return_date = ret.get("return_date", "")
            if return_date:
                try:
                    rd = datetime.fromisoformat(return_date)
                    if start_date <= rd < end_date:
                        received_amount += ret.get("amount", 0)
                except:
                    pass
        
        return {
            "user_id": user_id or "personal",
            "period": period,
            "period_name": self._get_period_name(period, start_date),
            "deals_count": len(deals),
            "total_amount": total_amount,
            "new_customers": new_customers,
            "total_followups": followups,
            "received_amount": received_amount,
            "pending_amount": total_amount - received_amount,
            "average_deal_size": total_amount / len(deals) if deals else 0
        }
    
    def _get_period_name(self, period: str, start_date: datetime) -> str:
        """获取周期名称"""
        if period == "month":
            return start_date.strftime("%Y年%m月")
        elif period == "quarter":
            quarter = (start_date.month - 1) // 3 + 1
            return f"{start_date.year}年Q{quarter}"
        else:
            return f"{start_date.year}年"
    
    def calculate_team_performance(self, period: str = "month") -> List[Dict]:
        """计算团队业绩"""
        # 从团队数据获取成员
        team_file = os.path.join(self.DATA_DIR, "team.json")
        members = []
        
        if os.path.exists(team_file):
            try:
                with open(team_file, 'r', encoding='utf-8') as f:
                    team_data = json.load(f)
                    members = team_data.get("members", [])
            except:
                pass
        
        results = []
        for member in members:
            perf = self.calculate_personal_performance(member.get("id"), period)
            perf["user_name"] = member.get("name")
            results.append(perf)
        
        # 按业绩排序
        results.sort(key=lambda x: x["total_amount"], reverse=True)
        
        return results
    
    def generate_performance_report(self, period: str = "month") -> str:
        """生成业绩报告"""
        personal = self.calculate_personal_performance(period=period)
        team = self.calculate_team_performance(period)
        
        lines = [
            "📊 业绩统计报告",
            "=" * 50,
            f"统计周期：{personal['period_name']}",
            ""
        ]
        
        # 个人业绩
        lines.extend([
            "【个人业绩】",
            f"  成交单数：{personal['deals_count']}单",
            f"  成交金额：{personal['total_amount']:.1f}万",
            f"  新增客户：{personal['new_customers']}个",
            f"  跟进次数：{personal['total_followups']}次",
            f"  回款金额：{personal['received_amount']:.1f}万",
            f"  客单价：{personal['average_deal_size']:.1f}万",
            ""
        ])
        
        # 团队业绩
        if team:
            lines.append("【团队排名】")
            for i, member in enumerate(team, 1):
                lines.append(f"  {i}. {member.get('user_name', '未知')}")
                lines.append(f"     成交：{member['deals_count']}单 | {member['total_amount']:.1f}万")
            lines.append("")
        
        return "\n".join(lines)


class NotificationManager:
    """通知管理器"""
    
    DATA_DIR = "data"
    NOTIFICATIONS_FILE = os.path.join(DATA_DIR, "notifications.json")
    
    NOTIF_TYPE_FOLLOWUP = "followup"       # 跟进提醒
    NOTIF_TYPE_RETURN = "return"           # 回款提醒
    NOTIF_TYPE_OVERDUE = "overdue"         # 超时提醒
    NOTIF_TYPE_COLLISION = "collision"     # 撞单提醒
    NOTIF_TYPE_SYSTEM = "system"           # 系统通知
    
    def __init__(self):
        self.notifications = self._load_notifications()
        self.settings = self._load_settings()
    
    def _load_notifications(self) -> List[Dict]:
        """加载通知"""
        if os.path.exists(self.NOTIFICATIONS_FILE):
            try:
                with open(self.NOTIFICATIONS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_settings(self) -> Dict:
        """加载设置"""
        file_path = os.path.join(self.DATA_DIR, "settings.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"notifications_enabled": True}
    
    def _save_notifications(self) -> bool:
        """保存通知"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.NOTIFICATIONS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.notifications, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def add_notification(self, notif_type: str, title: str, content: str, 
                        user_id: str = None, related_id: str = None) -> Dict:
        """添加通知"""
        notification = {
            "id": f"notif_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "type": notif_type,
            "title": title,
            "content": content,
            "user_id": user_id,
            "related_id": related_id,
            "status": "unread",
            "created_at": datetime.now().isoformat()
        }
        
        self.notifications.append(notification)
        self._save_notifications()
        return notification
    
    def get_unread_notifications(self, user_id: str = None) -> List[Dict]:
        """获取未读通知"""
        unread = [n for n in self.notifications if n.get("status") == "unread"]
        
        if user_id:
            unread = [n for n in unread if n.get("user_id") == user_id or not n.get("user_id")]
        
        return sorted(unread, key=lambda x: x.get("created_at", ""), reverse=True)
    
    def mark_as_read(self, notification_id: str) -> bool:
        """标记已读"""
        for i, n in enumerate(self.notifications):
            if n.get("id") == notification_id:
                self.notifications[i]["status"] = "read"
                self.notifications[i]["read_at"] = datetime.now().isoformat()
                self._save_notifications()
                return True
        return False
    
    def generate_followup_reminder(self, customer_name: str, company: str, due_date: str) -> Dict:
        """生成跟进提醒"""
        return self.add_notification(
            self.NOTIF_TYPE_FOLLOWUP,
            "📅 跟进提醒",
            f"客户 {customer_name}（{company}）需要跟进，到期日：{due_date}"
        )
    
    def generate_return_reminder(self, customer_name: str, amount: float, due_date: str) -> Dict:
        """生成回款提醒"""
        return self.add_notification(
            self.NOTIF_TYPE_RETURN,
            "💰 回款提醒",
            f"客户 {customer_name} 的回款 {amount:.1f}万将于 {due_date} 到期"
        )


class CustomFieldManager:
    """自定义字段管理器"""
    
    DATA_DIR = "data"
    CUSTOM_FIELDS_FILE = os.path.join(DATA_DIR, "custom_fields.json")
    
    # 预定义字段类型
    FIELD_TYPES = [
        "text",       # 文本
        "number",     # 数字
        "date",       # 日期
        "select",     # 下拉选择
        "multiselect",# 多选
        "checkbox",   # 多选框
        "textarea"   # 多行文本
    ]
    
    def __init__(self):
        self.fields = self._load_fields()
    
    def _load_fields(self) -> Dict:
        """加载自定义字段"""
        if os.path.exists(self.CUSTOM_FIELDS_FILE):
            try:
                with open(self.CUSTOM_FIELDS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"customer": [], "contract": [], "task": []}
    
    def _save_fields(self) -> bool:
        """保存自定义字段"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.CUSTOM_FIELDS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.fields, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def add_field(self, entity_type: str, field_info: Dict) -> Tuple[bool, Dict]:
        """
        添加自定义字段
        
        Args:
            entity_type: 实体类型 (customer/contract/task)
            field_info: 字段信息
        """
        if entity_type not in self.fields:
            return False, {"error": "不支持的实体类型"}
        
        field = {
            "id": f"field_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "name": field_info.get("name", ""),
            "label": field_info.get("label", ""),
            "type": field_info.get("type", "text"),
            "required": field_info.get("required", False),
            "options": field_info.get("options", []),  # 选择类字段的选项
            "default_value": field_info.get("default_value", ""),
            "placeholder": field_info.get("placeholder", ""),
            "sort_order": len(self.fields[entity_type])
        }
        
        self.fields[entity_type].append(field)
        if self._save_fields():
            return True, field
        return False, {"error": "保存失败"}
    
    def get_fields(self, entity_type: str) -> List[Dict]:
        """获取实体类型的自定义字段"""
        return self.fields.get(entity_type, [])
    
    def validate_field_value(self, field_id: str, value: Any, entity_type: str) -> Tuple[bool, str]:
        """验证字段值"""
        fields = self.get_fields(entity_type)
        field = None
        
        for f in fields:
            if f.get("id") == field_id:
                field = f
                break
        
        if not field:
            return False, "字段不存在"
        
        # 必填检查
        if field.get("required") and not value:
            return False, f"{field.get('label')}为必填项"
        
        # 类型检查
        field_type = field.get("type")
        if field_type == "number" and value:
            try:
                float(value)
            except:
                return False, f"{field.get('label')}必须为数字"
        
        return True, ""


class PrivacyCompliance:
    """隐私合规管理"""
    
    DATA_DIR = "data"
    
    # 合规数据类型
    SENSITIVE_FIELDS = [
        "phone", "email", "id_card", "bank_account", "address", "birthday"
    ]
    
    def __init__(self):
        self.settings = self._load_settings()
    
    def _load_settings(self) -> Dict:
        """加载设置"""
        file_path = os.path.join(self.DATA_DIR, "privacy_settings.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {
            "mask_enabled": True,           # 是否启用脱敏显示
            "mask_phone": True,             # 电话脱敏
            "mask_email": True,             # 邮箱脱敏
            "audit_log_enabled": True,      # 审计日志
            "retention_days": 365           # 数据保留天数
        }
    
    def mask_phone(self, phone: str) -> str:
        """电话脱敏"""
        if not phone or len(phone) < 7:
            return phone
        return phone[:3] + "****" + phone[-4:]
    
    def mask_email(self, email: str) -> str:
        """邮箱脱敏"""
        if not email or "@" not in email:
            return email
        parts = email.split("@")
        name = parts[0]
        domain = parts[1] if len(parts) > 1 else ""
        
        if len(name) <= 2:
            masked_name = name[0] + "*"
        else:
            masked_name = name[0] + "*" * (len(name) - 2) + name[-1]
        
        return masked_name + "@" + domain
    
    def mask_customer(self, customer: Dict) -> Dict:
        """客户信息脱敏"""
        masked = customer.copy()
        
        if self.settings.get("mask_phone"):
            if "phone" in masked:
                masked["phone"] = self.mask_phone(masked["phone"])
        
        if self.settings.get("mask_email"):
            if "email" in masked:
                masked["email"] = self.mask_email(masked["email"])
        
        return masked
    
    def record_access(self, user_id: str, action: str, resource: str, resource_id: str):
        """记录访问日志"""
        log_file = os.path.join(self.DATA_DIR, "access_log.json")
        logs = []
        
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
            except:
                pass
        
        log_entry = {
            "id": f"log_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "user_id": user_id,
            "action": action,
            "resource": resource,
            "resource_id": resource_id,
            "ip_address": "",  # 实际使用时应获取
            "timestamp": datetime.now().isoformat()
        }
        
        logs.append(log_entry)
        
        # 保留最近1000条
        logs = logs[-1000:]
        
        try:
            with open(log_file, 'w', encoding='utf-8') as f:
                json.dump(logs, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def export_compliance_report(self) -> str:
        """生成合规报告"""
        lines = [
            "🔒 数据合规报告",
            "=" * 50,
            f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "",
            "【设置状态】",
            f"  脱敏显示：{'已启用' if self.settings.get('mask_enabled') else '已禁用'}",
            f"  电话脱敏：{'已启用' if self.settings.get('mask_phone') else '已禁用'}",
            f"  邮箱脱敏：{'已启用' if self.settings.get('mask_email') else '已禁用'}",
            f"  审计日志：{'已启用' if self.settings.get('audit_log_enabled') else '已禁用'}",
            f"  数据保留：{self.settings.get('retention_days', 365)}天",
            ""
        ]
        
        # 访问统计
        log_file = os.path.join(self.DATA_DIR, "access_log.json")
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
                lines.append(f"【访问统计】")
                lines.append(f"  总访问次数：{len(logs)}次")
                lines.append("")
            except:
                pass
        
        return "\n".join(lines)


if __name__ == "__main__":
    calc = PerformanceCalculator()
    print(calc.generate_performance_report("month"))
