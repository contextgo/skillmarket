#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
团队协作模块
支持团队模式下客户分配、飞书文档共享、团队业绩查看等功能
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any


class TeamRole:
    """团队角色"""
    ADMIN = "admin"           # 管理员
    MANAGER = "manager"       # 销售经理
    SALES = "sales"          # 销售人员
    VIEWER = "viewer"        # 查看者


class Permission:
    """权限定义"""
    # 客户管理
    CAN_VIEW_ALL_CUSTOMERS = "view_all_customers"
    CAN_ASSIGN_CUSTOMERS = "assign_customers"
    CAN_TRANSFER_CUSTOMERS = "transfer_customers"
    CAN_DELETE_CUSTOMERS = "delete_customers"
    
    # 合同管理
    CAN_VIEW_ALL_CONTRACTS = "view_all_contracts"
    CAN_SIGN_CONTRACTS = "sign_contracts"
    
    # 数据管理
    CAN_EXPORT_DATA = "export_data"
    CAN_IMPORT_DATA = "import_data"
    CAN_VIEW_ANALYTICS = "view_analytics"
    
    # 团队管理
    CAN_MANAGE_MEMBERS = "manage_members"
    CAN_VIEW_TEAM_PERFORMANCE = "view_team_performance"


class RolePermissions:
    """角色权限映射"""
    PERMISSIONS = {
        TeamRole.ADMIN: [
            Permission.CAN_VIEW_ALL_CUSTOMERS,
            Permission.CAN_ASSIGN_CUSTOMERS,
            Permission.CAN_TRANSFER_CUSTOMERS,
            Permission.CAN_DELETE_CUSTOMERS,
            Permission.CAN_VIEW_ALL_CONTRACTS,
            Permission.CAN_SIGN_CONTRACTS,
            Permission.CAN_EXPORT_DATA,
            Permission.CAN_IMPORT_DATA,
            Permission.CAN_VIEW_ANALYTICS,
            Permission.CAN_MANAGE_MEMBERS,
            Permission.CAN_VIEW_TEAM_PERFORMANCE
        ],
        TeamRole.MANAGER: [
            Permission.CAN_VIEW_ALL_CUSTOMERS,
            Permission.CAN_ASSIGN_CUSTOMERS,
            Permission.CAN_TRANSFER_CUSTOMERS,
            Permission.CAN_VIEW_ALL_CONTRACTS,
            Permission.CAN_SIGN_CONTRACTS,
            Permission.CAN_EXPORT_DATA,
            Permission.CAN_VIEW_ANALYTICS,
            Permission.CAN_VIEW_TEAM_PERFORMANCE
        ],
        TeamRole.SALES: [
            Permission.CAN_VIEW_ALL_CONTRACTS,
            Permission.CAN_SIGN_CONTRACTS,
            Permission.CAN_EXPORT_DATA
        ],
        TeamRole.VIEWER: []
    }


class TeamManager:
    """团队管理器"""
    
    DATA_DIR = "data"
    TEAM_FILE = os.path.join(DATA_DIR, "team.json")
    SHARES_FILE = os.path.join(DATA_DIR, "shares.json")
    
    def __init__(self, current_user_id: str = "system"):
        self.current_user_id = current_user_id
        self.team = self._load_team()
        self.shares = self._load_shares()
        self.customers = self._load_customers()
    
    def _load_team(self) -> Dict:
        """加载团队数据"""
        if os.path.exists(self.TEAM_FILE):
            try:
                with open(self.TEAM_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "members": [],
            "settings": {
                "public_pool_enabled": True,
                "collision_detection": True,
                "auto_assign": False
            }
        }
    
    def _load_shares(self) -> List[Dict]:
        """加载分享记录"""
        if os.path.exists(self.SHARES_FILE):
            try:
                with open(self.SHARES_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_team(self) -> bool:
        """保存团队数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.TEAM_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.team, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def _save_shares(self) -> bool:
        """保存分享记录"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.SHARES_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.shares, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def has_permission(self, user_id: str, permission: str) -> bool:
        """检查用户权限"""
        member = self._get_member(user_id)
        if not member:
            return False
        
        role = member.get("role", TeamRole.VIEWER)
        return permission in RolePermissions.PERMISSIONS.get(role, [])
    
    def _get_member(self, user_id: str) -> Optional[Dict]:
        """获取成员信息"""
        for member in self.team.get("members", []):
            if member.get("id") == user_id:
                return member
        return None
    
    def add_member(self, member_info: Dict) -> Tuple[bool, Dict]:
        """添加团队成员"""
        member_id = member_info.get("id", f"user_{datetime.now().strftime('%Y%m%d%H%M%S')}")
        
        # 检查是否已存在
        if self._get_member(member_id):
            return False, {"error": "成员已存在"}
        
        member = {
            "id": member_id,
            "name": member_info.get("name", ""),
            "role": member_info.get("role", TeamRole.SALES),
            "email": member_info.get("email", ""),
            "phone": member_info.get("phone", ""),
            "status": "active",
            "joined_at": datetime.now().isoformat(),
            "customers_count": 0,
            "performance": {
                "total_deals": 0,
                "total_amount": 0,
                "monthly_deals": 0,
                "monthly_amount": 0
            }
        }
        
        self.team["members"].append(member)
        if self._save_team():
            return True, member
        return False, {"error": "保存失败"}
    
    def assign_customer(self, customer_id: str, assignee_id: str) -> Tuple[bool, str]:
        """分配客户"""
        # 权限检查
        if not self.has_permission(self.current_user_id, Permission.CAN_ASSIGN_CUSTOMERS):
            return False, "无分配权限"
        
        # 查找客户
        customer = None
        for i, c in enumerate(self.customers):
            if c.get("id") == customer_id or c.get("name") == customer_id:
                customer = c
                break
        
        if not customer:
            return False, "客户不存在"
        
        # 检查目标成员
        assignee = self._get_member(assignee_id)
        if not assignee:
            return False, "目标成员不存在"
        
        # 记录原负责人
        old_assignee = customer.get("assignee")
        
        # 更新客户
        for i, c in enumerate(self.customers):
            if c.get("id") == customer_id:
                self.customers[i]["assignee"] = assignee_id
                self.customers[i]["assignee_name"] = assignee.get("name")
                self.customers[i]["assigned_at"] = datetime.now().isoformat()
                self.customers[i]["assigned_by"] = self.current_user_id
                break
        
        # 记录转让历史
        transfer_record = {
            "customer_id": customer_id,
            "customer_name": customer.get("name"),
            "from": old_assignee,
            "to": assignee_id,
            "transferred_at": datetime.now().isoformat(),
            "transferred_by": self.current_user_id
        }
        self._add_transfer_history(transfer_record)
        
        # 保存客户数据
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(os.path.join(self.DATA_DIR, "customers.json"), 'w', encoding='utf-8') as f:
                json.dump(self.customers, f, ensure_ascii=False, indent=2)
            return True, f"已分配给{assignee.get('name')}"
        except:
            return False, "保存失败"
    
    def _add_transfer_history(self, record: Dict):
        """添加转让历史"""
        history_file = os.path.join(self.DATA_DIR, "transfer_history.json")
        history = []
        
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    history = json.load(f)
            except:
                pass
        
        history.append(record)
        
        try:
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(history, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def share_to_lark(self, customer_id: str, lark_doc_id: str = None) -> Tuple[bool, Dict]:
        """
        分享到飞书文档
        
        Args:
            customer_id: 客户ID
            lark_doc_id: 飞书文档ID（可选）
            
        Returns:
            (成功标志, 结果信息)
        """
        customer = None
        for c in self.customers:
            if c.get("id") == customer_id or c.get("name") == customer_id:
                customer = c
                break
        
        if not customer:
            return False, {"error": "客户不存在"}
        
        # 生成分享记录
        share_record = {
            "id": f"share_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "customer_id": customer.get("id"),
            "customer_name": customer.get("name"),
            "content_type": "customer_profile",
            "lark_doc_id": lark_doc_id,
            "shared_by": self.current_user_id,
            "shared_at": datetime.now().isoformat(),
            "share_link": f"https://feishu.cn/docx/{lark_doc_id}" if lark_doc_id else None
        }
        
        self.shares.append(share_record)
        self._save_shares()
        
        return True, share_record
    
    def generate_share_content(self, customer_id: str, include_notes: bool = True) -> str:
        """生成分享内容"""
        customer = None
        for c in self.customers:
            if c.get("id") == customer_id or c.get("name") == customer_id:
                customer = c
                break
        
        if not customer:
            return "客户不存在"
        
        lines = [
            f"# {customer.get('name')} - 客户档案",
            "",
            "## 基本信息",
            f"- 公司：{customer.get('company', '')}",
            f"- 职位：{customer.get('position', '')}",
            f"- 联系方式：{customer.get('phone', '')} / {customer.get('email', '')}",
            f"- 预算：{customer.get('budget', '')}",
            "",
            "## 销售信息",
            f"- 当前阶段：{customer.get('stage', '')}",
            f"- 优先级：{customer.get('priority', '')}",
            f"- 购买意向：{customer.get('purchase_intent', '')}",
            f"- 决策层级：{customer.get('decision_maker', '')}",
            ""
        ]
        
        # 跟进记录
        if include_notes:
            notes = customer.get("notes", [])
            if notes:
                lines.extend([
                    "## 跟进记录",
                    ""
                ])
                for note in notes[-10:]:  # 最近10条
                    note_time = note.get("created_at", "")[:10]
                    note_content = note.get("content", "")
                    lines.append(f"**{note_time}**：{note_content}")
                lines.append("")
        
        # 添加分隔
        lines.extend([
            "---",
            f"最后更新：{customer.get('updated_at', '')[:10]}",
            f"负责人：{customer.get('assignee_name', '未分配')}"
        ])
        
        return "\n".join(lines)
    
    def get_team_performance(self) -> Dict[str, Any]:
        """获取团队业绩"""
        # 按负责人统计
        member_stats = {}
        
        for member in self.team.get("members", []):
            member_stats[member.get("id")] = {
                "name": member.get("name"),
                "role": member.get("role"),
                "total_customers": 0,
                "active_customers": 0,
                "total_pipeline": 0,
                "stage_distribution": {},
                "monthly_new": 0
            }
        
        now = datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0)
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            assignee = customer.get("assignee")
            if not assignee:
                continue
            
            if assignee not in member_stats:
                continue
            
            stats = member_stats[assignee]
            stats["total_customers"] += 1
            
            stage = customer.get("stage", "")
            stats["stage_distribution"][stage] = stats["stage_distribution"].get(stage, 0) + 1
            
            budget = customer.get("budget_value", 0)
            stats["total_pipeline"] += budget
            
            if stage not in ["成交", "已流失"]:
                stats["active_customers"] += 1
            
            # 本月新增
            created_at = customer.get("created_at", "")
            if created_at:
                try:
                    if datetime.fromisoformat(created_at) >= month_start:
                        stats["monthly_new"] += 1
                except:
                    pass
        
        # 排序
        sorted_stats = sorted(
            member_stats.items(),
            key=lambda x: x[1]["total_pipeline"],
            reverse=True
        )
        
        return {
            "period": f"{month_start.strftime('%Y-%m')}月",
            "members": [v for _, v in sorted_stats],
            "team_summary": {
                "total_members": len(self.team.get("members", [])),
                "total_customers": sum(s["total_customers"] for s in member_stats.values()),
                "total_pipeline": sum(s["total_pipeline"] for s in member_stats.values())
            }
        }
    
    def get_assigned_customers(self, user_id: str) -> List[Dict]:
        """获取用户负责的客户列表"""
        customers = []
        for c in self.customers:
            if c.get("is_deleted"):
                continue
            if c.get("assignee") == user_id:
                customers.append(c)
        return customers
    
    def check_collision(self, customer_name: str = None, company: str = None, exclude_user: str = None) -> List[Dict]:
        """
        检测撞单
        
        Args:
            customer_name: 客户姓名
            company: 公司名称
            exclude_user: 排除的用户ID
            
        Returns:
            疑似撞单列表
        """
        collisions = []
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            # 排除自己
            if exclude_user and customer.get("assignee") == exclude_user:
                continue
            
            # 检查是否撞单
            is_collision = False
            reasons = []
            
            if customer_name and customer.get("name") == customer_name:
                is_collision = True
                reasons.append("同名客户")
            
            if company and customer.get("company") == company:
                is_collision = True
                reasons.append("同公司客户")
            
            if is_collision:
                collisions.append({
                    "customer_id": customer.get("id"),
                    "customer_name": customer.get("name"),
                    "company": customer.get("company"),
                    "assigned_to": customer.get("assignee"),
                    "assigned_name": customer.get("assignee_name"),
                    "collision_reasons": reasons
                })
        
        return collisions


def generate_team_report() -> str:
    """生成团队报告"""
    manager = TeamManager()
    performance = manager.get_team_performance()
    
    lines = [
        "👥 团队业绩报告",
        "=" * 50,
        f"统计周期：{performance['period']}",
        ""
    ]
    
    # 团队汇总
    summary = performance["team_summary"]
    lines.extend([
        "【团队概览】",
        f"  团队成员：{summary['total_members']}人",
        f"  客户总数：{summary['total_customers']}个",
        f"  管道总额：{summary['total_pipeline']:.1f}万",
        ""
    ])
    
    # 成员业绩
    lines.append("【成员业绩排行】")
    for i, member in enumerate(performance["members"], 1):
        lines.append(f"  {i}. {member['name']}（{member['role']}）")
        lines.append(f"     客户：{member['total_customers']}个 | 活跃：{member['active_customers']}个")
        lines.append(f"     管道：{member['total_pipeline']:.1f}万 | 本月新增：{member['monthly_new']}个")
        lines.append("")
    
    return "\n".join(lines)


if __name__ == "__main__":
    # 测试代码
    print(generate_team_report())
