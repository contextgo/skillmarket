#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
客户档案管理核心模块
提供客户档案的增删改查、搜索、导入导出等基础功能
"""

import json
import os
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum


class StageEnum(Enum):
    """销售阶段枚举"""
    POTENTIAL = "潜在客户"
    INITIAL = "初步接触"
    QUALIFIED = "需求确认"
    QUOTING = "报价"
    NEGOTIATING = "谈判"
    CLOSED = "成交"
    LOST = "流失"


class PriorityEnum(Enum):
    """优先级枚举"""
    HIGH = "高"
    MEDIUM = "中"
    LOW = "低"


class CustomerManager:
    """客户档案管理核心类"""
    
    # 数据存储路径
    DATA_DIR = "data"
    CUSTOMERS_FILE = os.path.join(DATA_DIR, "customers.json")
    
    # 字段定义
    REQUIRED_FIELDS = ["name"]
    OPTIONAL_FIELDS = [
        "company", "position", "phone", "email", "requirement",
        "budget", "decision_maker", "purchase_intent", "stage",
        "next_follow_up", "priority", "tags", "notes", "reminders",
        "custom_fields", "source", "competitors", "contracts",
        "last_contact", "follow_up_count", "created_by"
    ]
    
    def __init__(self, mode: str = "personal"):
        """
        初始化客户管理器
        
        Args:
            mode: 运行模式 "personal"(个人模式) 或 "team"(团队模式)
        """
        self.mode = mode
        self.customers = self._load_customers()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        if os.path.exists(self.CUSTOMERS_FILE):
            try:
                with open(self.CUSTOMERS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
                    return data.get("customers", [])
            except (json.JSONDecodeError, IOError):
                return []
        return []
    
    def _save_customers(self) -> bool:
        """保存客户数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.CUSTOMERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.customers, f, ensure_ascii=False, indent=2)
            return True
        except IOError as e:
            print(f"保存失败: {e}")
            return False
    
    def _generate_id(self) -> str:
        """生成唯一客户ID"""
        return f"cust_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.customers) + 1}"
    
    def _parse_budget(self, budget_str: str) -> float:
        """解析预算金额"""
        if not budget_str:
            return 0.0
        try:
            # 去除逗号、空格
            budget_str = budget_str.replace(",", "").replace(" ", "")
            # 判断单位
            if "万" in budget_str:
                return float(budget_str.replace("万", ""))
            elif "千" in budget_str:
                return float(budget_str.replace("千", "")) / 10
            elif "元" in budget_str:
                return float(budget_str.replace("元", "")) / 10000
            else:
                return float(budget_str)
        except (ValueError, AttributeError):
            return 0.0
    
    def add_customer(self, info: Dict, user_id: Optional[str] = None) -> Tuple[bool, Dict]:
        """
        添加新客户
        
        Args:
            info: 客户信息字典
            user_id: 用户ID（团队模式必填）
            
        Returns:
            (成功标志, 客户信息/错误信息)
        """
        # 验证必填字段
        if "name" not in info or not info["name"].strip():
            return False, {"error": "客户姓名不能为空"}
        
        # 检查重复客户（同姓名+同公司）
        existing = self._find_duplicate(info.get("name"), info.get("company"))
        if existing:
            return False, {
                "error": "可能存在重复客户",
                "duplicate": existing,
                "suggestion": "是否要更新现有客户信息？"
            }
        
        # 构建客户记录
        customer = {
            "id": self._generate_id(),
            "name": info["name"].strip(),
            "company": info.get("company", "").strip(),
            "position": info.get("position", "").strip(),
            "phone": info.get("phone", "").strip(),
            "email": info.get("email", "").strip(),
            "requirement": info.get("requirement", "").strip(),
            "budget": info.get("budget", ""),
            "budget_value": self._parse_budget(info.get("budget", "")),
            "decision_maker": info.get("decision_maker", ""),  # 高/中/低
            "purchase_intent": info.get("purchase_intent", ""),  # 强/中/弱
            "stage": info.get("stage", StageEnum.POTENTIAL.value),
            "next_follow_up": info.get("next_follow_up"),
            "priority": info.get("priority", PriorityEnum.MEDIUM.value),
            "tags": info.get("tags", []),
            "notes": [],
            "reminders": [],
            "custom_fields": info.get("custom_fields", {}),
            "source": info.get("source", ""),  # 客户来源
            "competitors": info.get("competitors", []),  # 竞品
            "contracts": [],  # 关联合同
            "last_contact": None,
            "follow_up_count": 0,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "created_by": user_id or "personal",
            "is_deleted": False
        }
        
        self.customers.append(customer)
        if self._save_customers():
            return True, customer
        return False, {"error": "保存客户信息失败"}
    
    def update_customer(self, customer_id: str, updates: Dict, user_id: Optional[str] = None) -> Tuple[bool, Dict]:
        """
        更新客户信息
        
        Args:
            customer_id: 客户ID或姓名
            updates: 更新字段
            user_id: 用户ID（团队模式）
            
        Returns:
            (成功标志, 结果信息)
        """
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                if customer.get("is_deleted"):
                    return False, {"error": "客户已被删除"}
                
                # 团队模式权限检查
                if self.mode == "team" and user_id:
                    if customer.get("created_by") != user_id and customer.get("assignee") != user_id:
                        return False, {"error": "无权限修改此客户"}
                
                # 更新字段
                allowed_fields = [
                    "company", "position", "phone", "email", "requirement",
                    "budget", "decision_maker", "purchase_intent", "stage",
                    "next_follow_up", "priority", "tags", "custom_fields",
                    "source", "competitors"
                ]
                
                for key, value in updates.items():
                    if key in allowed_fields:
                        if key == "budget":
                            customer[key] = value
                            customer["budget_value"] = self._parse_budget(value)
                        elif key == "tags" and isinstance(value, list):
                            customer[key].extend([t for t in value if t not in customer[key]])
                        elif key == "custom_fields" and isinstance(value, dict):
                            customer[key].update(value)
                        else:
                            customer[key] = value
                
                customer["updated_at"] = datetime.now().isoformat()
                
                if self._save_customers():
                    return True, customer
                return False, {"error": "保存更新失败"}
        
        return False, {"error": "未找到客户"}
    
    def _find_duplicate(self, name: str, company: str) -> Optional[Dict]:
        """查找可能重复的客户"""
        if not name:
            return None
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            if customer.get("name") == name:
                if not company or customer.get("company") == company:
                    return customer
        return None
    
    def search_customers(self, keyword: str, filters: Optional[Dict] = None) -> List[Dict]:
        """
        搜索客户
        
        Args:
            keyword: 搜索关键词
            filters: 筛选条件
            
        Returns:
            匹配的客户列表
        """
        results = []
        keyword_lower = keyword.lower().strip() if keyword else ""
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            matched = False
            
            # 关键词匹配
            if keyword_lower:
                search_fields = [
                    "name", "company", "position", "requirement", 
                    "phone", "email", "tags"
                ]
                for field in search_fields:
                    value = customer.get(field, "")
                    if value and keyword_lower in str(value).lower():
                        matched = True
                        break
            else:
                matched = True
            
            # 筛选条件
            if matched and filters:
                for key, value in filters.items():
                    if key == "stage" and customer.get("stage") != value:
                        matched = False
                        break
                    elif key == "priority" and customer.get("priority") != value:
                        matched = False
                        break
                    elif key == "source" and customer.get("source") != value:
                        matched = False
                        break
                    elif key == "tags" and not any(t in customer.get("tags", []) for t in value):
                        matched = False
                        break
            
            if matched:
                results.append(customer)
        
        return results
    
    def get_customer(self, identifier: str, user_id: Optional[str] = None) -> Optional[Dict]:
        """获取单个客户详情"""
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            if customer.get("id") == identifier or customer.get("name") == identifier:
                # 团队模式权限检查
                if self.mode == "team" and user_id:
                    if customer.get("created_by") != user_id and customer.get("assignee") != user_id:
                        if not customer.get("is_public", False):
                            return None
                return customer
        return None
    
    def delete_customer(self, customer_id: str, user_id: Optional[str] = None, soft: bool = True) -> Tuple[bool, str]:
        """
        删除客户
        
        Args:
            customer_id: 客户ID
            user_id: 用户ID（团队模式）
            soft: 是否软删除
            
        Returns:
            (成功标志, 消息)
        """
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                # 团队模式权限检查
                if self.mode == "team" and user_id:
                    if customer.get("created_by") != user_id:
                        return False, "无权限删除此客户"
                
                if soft:
                    self.customers[i]["is_deleted"] = True
                    self.customers[i]["deleted_at"] = datetime.now().isoformat()
                    self.customers[i]["deleted_by"] = user_id or "personal"
                else:
                    self.customers.pop(i)
                
                if self._save_customers():
                    return True, "删除成功" if soft else "永久删除成功"
                return False, "保存失败"
        
        return False, "未找到客户"
    
    def get_all_customers(self, include_deleted: bool = False, user_id: Optional[str] = None) -> List[Dict]:
        """获取所有客户列表"""
        results = []
        for customer in self.customers:
            if not include_deleted and customer.get("is_deleted"):
                continue
            if self.mode == "team" and user_id:
                if customer.get("created_by") != user_id and customer.get("assignee") != user_id:
                    if not customer.get("is_public", False):
                        continue
            results.append(customer)
        return results
    
    def add_note(self, customer_id: str, note: str, user_id: Optional[str] = None) -> Tuple[bool, Dict]:
        """添加跟进记录"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                note_entry = {
                    "id": f"note_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    "content": note,
                    "created_at": datetime.now().isoformat(),
                    "created_by": user_id or "personal"
                }
                self.customers[i]["notes"].append(note_entry)
                self.customers[i]["last_contact"] = datetime.now().isoformat()
                self.customers[i]["follow_up_count"] = self.customers[i].get("follow_up_count", 0) + 1
                self.customers[i]["updated_at"] = datetime.now().isoformat()
                
                if self._save_customers():
                    return True, note_entry
                return False, {"error": "保存失败"}
        return False, {"error": "未找到客户"}
    
    def add_reminder(self, customer_id: str, reminder: Dict) -> Tuple[bool, Dict]:
        """添加提醒"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                reminder_entry = {
                    "id": f"remind_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    "title": reminder.get("title", ""),
                    "content": reminder.get("content", ""),
                    "remind_at": reminder.get("remind_at"),
                    "status": "pending",
                    "created_at": datetime.now().isoformat()
                }
                self.customers[i]["reminders"].append(reminder_entry)
                self.customers[i]["updated_at"] = datetime.now().isoformat()
                
                if self._save_customers():
                    return True, reminder_entry
                return False, {"error": "保存失败"}
        return False, {"error": "未找到客户"}
    
    def get_statistics(self) -> Dict:
        """获取客户统计信息"""
        total = len([c for c in self.customers if not c.get("is_deleted")])
        
        # 按阶段统计
        stage_stats = {}
        for stage in StageEnum:
            stage_stats[stage.value] = len([
                c for c in self.customers 
                if not c.get("is_deleted") and c.get("stage") == stage.value
            ])
        
        # 按优先级统计
        priority_stats = {}
        for priority in PriorityEnum:
            priority_stats[priority.value] = len([
                c for c in self.customers 
                if not c.get("is_deleted") and c.get("priority") == priority.value
            ])
        
        # 总预算
        total_budget = sum([
            c.get("budget_value", 0) 
            for c in self.customers 
            if not c.get("is_deleted")
        ])
        
        # 本月新增
        now = datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0)
        this_month_new = len([
            c for c in self.customers 
            if not c.get("is_deleted") and 
            datetime.fromisoformat(c.get("created_at", now.isoformat())) >= month_start
        ])
        
        return {
            "total": total,
            "by_stage": stage_stats,
            "by_priority": priority_stats,
            "total_budget": f"{total_budget:.1f}万",
            "this_month_new": this_month_new
        }
    
    def export_data(self) -> str:
        """导出所有客户数据为JSON字符串"""
        active_customers = [c for c in self.customers if not c.get("is_deleted")]
        return json.dumps({
            "export_time": datetime.now().isoformat(),
            "total_count": len(active_customers),
            "customers": active_customers
        }, ensure_ascii=False, indent=2)
    
    def import_data(self, json_str: str, merge: bool = True) -> Tuple[int, int, List[str]]:
        """
        导入客户数据
        
        Args:
            json_str: JSON数据字符串
            merge: 是否合并（True追加，False覆盖）
            
        Returns:
            (成功数, 失败数, 错误列表)
        """
        try:
            data = json.loads(json_str)
            customers_to_import = data.get("customers", data) if isinstance(data, dict) else data
            
            if not isinstance(customers_to_import, list):
                return 0, 1, ["数据格式错误：期望客户列表"]
            
            success_count = 0
            error_list = []
            
            if not merge:
                self.customers = []
            
            for idx, cust in enumerate(customers_to_import):
                try:
                    if "name" not in cust or not cust["name"]:
                        error_list.append(f"第{idx+1}条：缺少客户姓名")
                        continue
                    
                    # 保留原有ID避免重复
                    new_customer = cust.copy()
                    if "id" not in new_customer:
                        new_customer["id"] = self._generate_id()
                    new_customer["created_at"] = cust.get("created_at", datetime.now().isoformat())
                    new_customer["updated_at"] = datetime.now().isoformat()
                    new_customer["is_deleted"] = False
                    
                    self.customers.append(new_customer)
                    success_count += 1
                except Exception as e:
                    error_list.append(f"第{idx+1}条：{str(e)}")
            
            self._save_customers()
            return success_count, len(customers_to_import) - success_count, error_list
            
        except json.JSONDecodeError as e:
            return 0, 1, [f"JSON解析错误: {str(e)}"]


def parse_customer_info(text: str) -> Dict:
    """
    从自然语言中解析客户信息
    
    Args:
        text: 用户输入的文本
        
    Returns:
        解析出的客户信息字典
    """
    info = {}
    text = text.strip()
    
    # 提取姓名（通常在"叫"、"是"之后）
    name_patterns = [
        r'(?:叫|是|客户姓名[:：]?)\s*([^\s，,。]+)',
        r'^([^\s，,。]+?)[，,]',
        r'记录一下[，,]?\s*([^\s，,。]+?)[，,]'
    ]
    for pattern in name_patterns:
        match = re.search(pattern, text)
        if match:
            info["name"] = match.group(1).strip()
            break
    
    # 提取公司
    company_patterns = [
        r'([^\s公司]+公司)',
        r'([^\s企业]+企业)',
        r'([^\s集团]+集团)',
        r'公司[:：]?\s*([^\s，,。]+)'
    ]
    for pattern in company_patterns:
        match = re.search(pattern, text)
        if match:
            company = match.group(1) if not match.group(1).startswith('公司') else match.group(1)
            info["company"] = company.strip()
            break
    
    # 提取职位
    position_patterns = [
        r'([^\s]+?)(?:总|经理|总监|主管|负责人)',
        r'职位[:：]?\s*([^\s，,。]+)'
    ]
    for pattern in position_patterns:
        match = re.search(pattern, text)
        if match:
            info["position"] = match.group(0).strip()
            break
    
    # 提取预算
    budget_match = re.search(r'(\d+(?:\.\d+)?)\s*(万|千|元)', text)
    if budget_match:
        amount = budget_match.group(1)
        unit = budget_match.group(2)
        if unit == "万":
            info["budget"] = f"{amount}万"
        elif unit == "千":
            info["budget"] = f"{amount}千"
        else:
            info["budget"] = f"{amount}元"
    
    # 提取需求
    requirement_patterns = [
        r'需求[:：]?\s*([^，,。]+)',
        r'(?:采购|购买|需要|想要)\s*([^，,。]+)',
        r'([^\s]+?(?:电脑|软件|服务|设备|系统))'
    ]
    for pattern in requirement_patterns:
        match = re.search(pattern, text)
        if match:
            info["requirement"] = match.group(1).strip()
            break
    
    # 提取联系方式
    phone_match = re.search(r'1[3-9]\d{9}', text)
    if phone_match:
        info["phone"] = phone_match.group(0)
    
    email_match = re.search(r'[\w.-]+@[\w.-]+\.\w+', text)
    if email_match:
        info["email"] = email_match.group(0)
    
    # 提取跟进时间
    followup_patterns = [
        r'(?:下周|下个月|明天|今天|本周)(\S*)',
        r'(?:周|日)\s*(\d+)',
        r'跟进[:：]?\s*([^，,。]+)'
    ]
    for pattern in followup_patterns:
        match = re.search(pattern, text)
        if match:
            info["next_follow_up_note"] = match.group(1).strip()
            break
    
    return info


if __name__ == "__main__":
    # 测试代码
    cm = CustomerManager()
    
    # 测试添加客户
    success, result = cm.add_customer({
        "name": "王总",
        "company": "XX科技",
        "position": "采购经理",
        "budget": "80万",
        "requirement": "500台电脑"
    })
    print(f"添加客户: {success}, {result}")
    
    # 测试解析
    info = parse_customer_info("记录一下，王总，XX科技公司采购经理，有500台电脑采购需求，预算80万")
    print(f"解析结果: {info}")
