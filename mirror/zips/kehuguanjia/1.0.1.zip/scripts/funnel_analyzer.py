#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
销售漏斗分析模块
提供销售管道各阶段的数据分析和可视化
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict


class SalesFunnel:
    """销售漏斗分析器"""
    
    # 标准销售阶段
    STAGES = [
        "潜在客户",      # 刚获取的线索
        "初步接触",      # 已建立联系
        "需求确认",      # 确认了需求
        "方案报价",      # 已提供方案或报价
        "商务谈判",      # 正在进行商务谈判
        "成交"          # 已经成交
    ]
    
    # 丢失阶段
    LOST_STAGE = "已流失"
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self.customers = self._load_customers()
        self.stage_weights = {
            "潜在客户": 0.05,
            "初步接触": 0.15,
            "需求确认": 0.30,
            "方案报价": 0.50,
            "商务谈判": 0.75,
            "成交": 1.0
        }
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.data_dir, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def reload_data(self):
        """重新加载数据"""
        self.customers = self._load_customers()
    
    def count_by_stage(self) -> Dict[str, int]:
        """统计各阶段客户数量"""
        counts = defaultdict(int)
        lost_count = 0
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            stage = customer.get("stage", "潜在客户")
            if stage == self.LOST_STAGE:
                lost_count += 1
            else:
                counts[stage] += 1
        
        # 确保所有阶段都有值
        result = {stage: counts.get(stage, 0) for stage in self.STAGES}
        result[self.LOST_STAGE] = lost_count
        
        return result
    
    def calculate_conversion_rates(self, stage_counts: Dict[str, int]) -> Dict[str, Dict]:
        """计算阶段转化率"""
        conversions = {}
        
        for i in range(len(self.STAGES) - 1):
            current_stage = self.STAGES[i]
            next_stage = self.STAGES[i + 1]
            
            current_count = stage_counts.get(current_stage, 0)
            next_count = stage_counts.get(next_stage, 0)
            
            if current_count > 0:
                rate = (next_count / current_count) * 100
            else:
                rate = 0
            
            conversions[f"{current_stage}→{next_stage}"] = {
                "from": current_stage,
                "to": next_stage,
                "from_count": current_count,
                "to_count": next_count,
                "rate": f"{rate:.1f}%",
                "rate_value": rate
            }
        
        return conversions
    
    def calculate_stage_value(self) -> Dict[str, float]:
        """计算各阶段客户价值"""
        stage_values = defaultdict(float)
        stage_counts = defaultdict(int)
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            stage = customer.get("stage", "潜在客户")
            budget = customer.get("budget_value", 0)
            
            stage_values[stage] += budget
            stage_counts[stage] += 1
        
        # 计算平均值
        avg_values = {}
        for stage in self.STAGES + [self.LOST_STAGE]:
            count = stage_counts.get(stage, 0)
            if count > 0:
                avg_values[stage] = stage_values.get(stage, 0) / count
            else:
                avg_values[stage] = 0
        
        return {
            "total": {stage: stage_values.get(stage, 0) for stage in self.STAGES + [self.LOST_STAGE]},
            "average": avg_values
        }
    
    def estimate_pipeline_value(self) -> Dict[str, Any]:
        """估算管道价值"""
        total_value = 0
        weighted_value = 0
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            stage = customer.get("stage", "潜在客户")
            if stage == self.LOST_STAGE:
                continue
            
            budget = customer.get("budget_value", 0)
            total_value += budget
            weighted_value += budget * self.stage_weights.get(stage, 0)
        
        return {
            "total_pipeline": f"{total_value:.1f}万",
            "weighted_pipeline": f"{weighted_value:.1f}万",
            "estimated_deals": len([c for c in self.customers 
                                    if not c.get("is_deleted") and 
                                    c.get("stage") == "商务谈判"]),
            "probability": f"{weighted_value / total_value * 100:.0f}%" if total_value > 0 else "0%"
        }
    
    def get_trend_analysis(self, days: int = 30) -> Dict[str, Any]:
        """分析趋势"""
        now = datetime.now()
        start_date = now - timedelta(days=days)
        
        # 按日期统计新增客户
        daily_new = defaultdict(int)
        daily_conversions = defaultdict(lambda: defaultdict(int))
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            created_at = customer.get("created_at", "")
            if created_at:
                try:
                    created_date = datetime.fromisoformat(created_at).date()
                    if start_date.date() <= created_date <= now.date():
                        daily_new[created_date.isoformat()] += 1
                except:
                    pass
            
            # 跟踪阶段变化
            notes = customer.get("notes", [])
            for note in notes:
                note_type = note.get("type", "")
                if note_type == "stage_change":
                    note_date = note.get("created_at", "")[:10]
                    old_stage = note.get("old_stage", "")
                    new_stage = note.get("new_stage", "")
                    if old_stage and new_stage:
                        daily_conversions[note_date][f"{old_stage}→{new_stage}"] += 1
        
        return {
            "period": f"最近{days}天",
            "daily_new": dict(daily_new),
            "total_new": sum(daily_new.values()),
            "conversions": {k: dict(v) for k, v in daily_conversions.items()}
        }
    
    def identify_bottlenecks(self, conversion_rates: Dict[str, Dict]) -> List[Dict]:
        """识别瓶颈"""
        bottlenecks = []
        
        for key, data in conversion_rates.items():
            rate = data["rate_value"]
            
            if rate < 10:
                severity = "严重"
            elif rate < 30:
                severity = "较重"
            elif rate < 50:
                severity = "一般"
            else:
                continue
            
            bottlenecks.append({
                "stage_transition": key,
                "current_rate": f"{rate:.1f}%",
                "severity": severity,
                "from_count": data["from_count"],
                "to_count": data["to_count"],
                "suggestion": self._generate_bottleneck_suggestion(key, rate)
            })
        
        # 按严重程度排序
        severity_order = {"严重": 0, "较重": 1, "一般": 2}
        bottlenecks.sort(key=lambda x: severity_order.get(x["severity"], 3))
        
        return bottlenecks
    
    def _generate_bottleneck_suggestion(self, transition: str, rate: float) -> str:
        """生成瓶颈优化建议"""
        suggestions = {
            "潜在客户→初步接触": "加强首次触达效率，优化开场话术，提高回复率",
            "初步接触→需求确认": "深入挖掘需求，展现专业价值，建立信任关系",
            "需求确认→方案报价": "加快方案准备速度，提高方案针对性和专业度",
            "方案报价→商务谈判": "强化方案优势展示，有效处理价格异议",
            "商务谈判→成交": "优化商务条款，加快合同签署流程"
        }
        return suggestions.get(transition, "分析此阶段的常见障碍，针对性提升")
    
    def generate_report(self) -> str:
        """生成漏斗报告"""
        stage_counts = self.count_by_stage()
        conversion_rates = self.calculate_conversion_rates(stage_counts)
        stage_value = self.calculate_stage_value()
        pipeline = self.estimate_pipeline_value()
        bottlenecks = self.identify_bottlenecks(conversion_rates)
        
        # 构建报告
        lines = [
            "📊 销售漏斗看板",
            "=" * 50,
            f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
            ""
        ]
        
        # 阶段分布
        lines.append("【各阶段客户分布】")
        lines.append("-" * 40)
        max_count = max(stage_counts.values()) if stage_counts.values() and max(stage_counts.values()) > 0 else 1
        
        for stage in self.STAGES:
            count = stage_counts.get(stage, 0)
            bar_length = int(count / max_count * 15)
            bar = "█" * bar_length + "░" * (15 - bar_length)
            total = stage_value["total"].get(stage, 0)
            avg = stage_value["average"].get(stage, 0)
            
            lines.append(f"{stage:<8} {bar} {count:>3}人  {total:>8.1f}万  (均{avg:.1f}万)")
        
        lost = stage_counts.get(self.LOST_STAGE, 0)
        if lost > 0:
            lines.append(f"{self.LOST_STAGE:<8} {'░' * 15} {lost:>3}人")
        
        lines.append("")
        
        # 转化率
        lines.append("【阶段转化率】")
        lines.append("-" * 40)
        for key, data in conversion_rates.items():
            parts = key.split("→")
            rate = data["rate"]
            if data["rate_value"] < 30:
                indicator = "⚠️"
            elif data["rate_value"] >= 50:
                indicator = "✅"
            else:
                indicator = "📊"
            lines.append(f"{indicator} {parts[0]:<8} → {parts[1]:<8}  {data['from_count']:>2}→{data['to_count']:>2}  {rate}")
        
        lines.append("")
        
        # 管道价值
        lines.append("【管道价值预测】")
        lines.append("-" * 40)
        lines.append(f"  总管道价值：{pipeline['total_pipeline']}")
        lines.append(f"  加权价值：{pipeline['weighted_pipeline']}（按阶段概率加权）")
        lines.append(f"  谈判阶段客户：{pipeline['estimated_deals']}个")
        lines.append(f"  综合转化概率：{pipeline['probability']}")
        
        # 瓶颈分析
        if bottlenecks:
            lines.append("")
            lines.append("⚠️ 瓶颈预警")
            lines.append("-" * 40)
            for bp in bottlenecks[:3]:
                lines.append(f"  [{bp['severity']}] {bp['stage_transition']} 转化率{bp['current_rate']}")
                lines.append(f"      建议：{bp['suggestion']}")
        
        # 优化建议
        lines.append("")
        lines.append("💡 优化建议")
        lines.append("-" * 40)
        
        total = sum(stage_counts.values())
        if total == 0:
            lines.append("  📝 暂无客户数据，建议先添加客户信息")
        else:
            # 基于漏斗形状给出建议
            early = stage_counts.get("潜在客户", 0)
            if early / total > 0.5:
                lines.append("  📝 潜在客户较多，建议加强早期转化工作")
            
            deal_count = stage_counts.get("成交", 0)
            if deal_count == 0:
                lines.append("  💡 暂无成交客户，重点关注商务谈判阶段客户")
            
            late_count = stage_counts.get("方案报价", 0) + stage_counts.get("商务谈判", 0)
            if late_count > 3:
                lines.append("  💡 后期客户较多，可加快报价和谈判节奏")
        
        return "\n".join(lines)
    
    def generate_visual_chart(self) -> Dict[str, Any]:
        """生成可视化图表数据"""
        stage_counts = self.count_by_stage()
        conversion_rates = self.calculate_conversion_rates(stage_counts)
        
        # 构建漏斗数据
        funnel_data = []
        max_count = max(stage_counts.values()) if stage_counts.values() and max(stage_counts.values()) > 0 else 1
        
        for stage in self.STAGES:
            count = stage_counts.get(stage, 0)
            funnel_data.append({
                "stage": stage,
                "count": count,
                "percentage": f"{count / max_count * 100:.0f}%" if max_count > 0 else "0%",
                "width": int(count / max_count * 100) if max_count > 0 else 0
            })
        
        return {
            "funnel": funnel_data,
            "conversions": [
                {
                    "transition": k,
                    "rate": v["rate"],
                    "from_to": f"{v['from_count']}→{v['to_count']}"
                }
                for k, v in conversion_rates.items()
            ]
        }


def get_funnel_summary() -> Dict[str, Any]:
    """获取漏斗摘要"""
    funnel = SalesFunnel()
    funnel.reload_data()
    
    return {
        "stages": funnel.count_by_stage(),
        "pipeline": funnel.estimate_pipeline_value(),
        "report": funnel.generate_report()
    }


if __name__ == "__main__":
    # 测试代码
    funnel = SalesFunnel()
    print(funnel.generate_report())
