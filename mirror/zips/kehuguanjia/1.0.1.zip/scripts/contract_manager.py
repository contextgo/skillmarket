#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
合同与回款管理模块
支持合同信息记录、回款进度跟踪、逾期提醒等功能
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum


class ContractStatus(Enum):
    """合同状态"""
    DRAFT = "草稿"
    PENDING_SIGN = "待签署"
    EFFECTIVE = "已生效"
    COMPLETED = "已完成"
    TERMINATED = "已终止"
    CANCELLED = "已取消"


class ReturnStatus(Enum):
    """回款状态"""
    PENDING = "待回款"
    PARTIAL = "部分回款"
    COMPLETED = "已完成"
    OVERDUE = "已逾期"


class ContractManager:
    """合同管理器"""
    
    DATA_DIR = "data"
    CONTRACTS_FILE = os.path.join(DATA_DIR, "contracts.json")
    RETURNS_FILE = os.path.join(DATA_DIR, "returns.json")
    
    def __init__(self):
        self.contracts = self._load_contracts()
        self.returns = self._load_returns()
        self.customers = self._load_customers()
    
    def _load_contracts(self) -> List[Dict]:
        """加载合同数据"""
        if os.path.exists(self.CONTRACTS_FILE):
            try:
                with open(self.CONTRACTS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_returns(self) -> List[Dict]:
        """加载回款数据"""
        if os.path.exists(self.RETURNS_FILE):
            try:
                with open(self.RETURNS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_contracts(self) -> bool:
        """保存合同数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.CONTRACTS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.contracts, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def _save_returns(self) -> bool:
        """保存回款数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.RETURNS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.returns, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def create_contract(self, contract_info: Dict) -> Tuple[bool, Dict]:
        """
        创建合同
        
        Args:
            contract_info: 合同信息
            
        Returns:
            (成功标志, 合同信息)
        """
        contract = {
            "id": f"contract_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "contract_no": contract_info.get("contract_no", ""),
            "customer_id": contract_info.get("customer_id", ""),
            "customer_name": contract_info.get("customer_name", ""),
            "company": contract_info.get("company", ""),
            "amount": float(contract_info.get("amount", 0)),
            "signed_date": contract_info.get("signed_date", ""),
            "start_date": contract_info.get("start_date", ""),
            "end_date": contract_info.get("end_date", ""),
            "status": contract_info.get("status", ContractStatus.DRAFT.value),
            "payment_terms": contract_info.get("payment_terms", ""),
            "products": contract_info.get("products", []),
            "attachments": contract_info.get("attachments", []),
            "created_by": contract_info.get("user_id", "system"),
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "signed_by": None,
            "signed_at": None,
            "remarks": contract_info.get("remarks", "")
        }
        
        self.contracts.append(contract)
        
        # 关联客户
        if contract["customer_id"]:
            self._link_to_customer(contract["customer_id"], contract["id"])
        
        if self._save_contracts():
            return True, contract
        return False, {"error": "保存失败"}
    
    def _link_to_customer(self, customer_id: str, contract_id: str):
        """关联合同到客户"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id:
                if "contracts" not in customer:
                    customer["contracts"] = []
                if contract_id not in customer["contracts"]:
                    customer["contracts"].append(contract_id)
                
                # 更新客户阶段为成交
                if customer.get("stage") not in ["成交", "已完成", "已流失"]:
                    customer["stage"] = "成交"
                
                try:
                    with open(os.path.join(self.DATA_DIR, "customers.json"), 'w', encoding='utf-8') as f:
                        json.dump(self.customers, f, ensure_ascii=False, indent=2)
                except:
                    pass
                break
    
    def get_contract(self, contract_id: str) -> Optional[Dict]:
        """获取合同详情"""
        for contract in self.contracts:
            if contract.get("id") == contract_id or contract.get("contract_no") == contract_id:
                # 添加回款信息
                contract["payment_info"] = self._get_payment_info(contract_id)
                return contract
        return None
    
    def _get_payment_info(self, contract_id: str) -> Dict:
        """获取合同回款信息"""
        related_returns = [r for r in self.returns if r.get("contract_id") == contract_id]
        
        total_amount = 0
        for c in self.contracts:
            if c.get("id") == contract_id:
                total_amount = c.get("amount", 0)
                break
        
        total_paid = sum(r.get("amount", 0) for r in related_returns)
        total_pending = total_amount - total_paid
        
        return {
            "total_amount": total_amount,
            "total_paid": total_paid,
            "total_pending": total_pending,
            "paid_rate": f"{total_paid / total_amount * 100:.1f}%" if total_amount > 0 else "0%",
            "payment_schedule": related_returns
        }
    
    def update_contract_status(self, contract_id: str, status: str) -> Tuple[bool, str]:
        """更新合同状态"""
        for i, contract in enumerate(self.contracts):
            if contract.get("id") == contract_id or contract.get("contract_no") == contract_id:
                self.contracts[i]["status"] = status
                self.contracts[i]["updated_at"] = datetime.now().isoformat()
                
                if status == ContractStatus.EFFECTIVE.value:
                    self.contracts[i]["signed_at"] = datetime.now().isoformat()
                
                if self._save_contracts():
                    return True, f"状态已更新为{status}"
                return False, "保存失败"
        return False, "未找到合同"
    
    def add_return_record(self, return_info: Dict) -> Tuple[bool, Dict]:
        """
        添加回款记录
        
        Args:
            return_info: 回款信息
            
        Returns:
            (成功标志, 回款记录)
        """
        record = {
            "id": f"return_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "contract_id": return_info.get("contract_id", ""),
            "amount": float(return_info.get("amount", 0)),
            "return_date": return_info.get("return_date", ""),
            "payment_method": return_info.get("payment_method", ""),
            "invoice_no": return_info.get("invoice_no", ""),
            "status": return_info.get("status", ReturnStatus.PARTIAL.value),
            "remarks": return_info.get("remarks", ""),
            "created_by": return_info.get("user_id", "system"),
            "created_at": datetime.now().isoformat()
        }
        
        self.returns.append(record)
        
        # 检查是否已完成回款
        contract_id = return_info.get("contract_id", "")
        if self._check_return_complete(contract_id):
            self.update_contract_status(contract_id, ContractStatus.COMPLETED.value)
            # 更新回款状态
            for r in self.returns:
                if r.get("contract_id") == contract_id:
                    r["status"] = ReturnStatus.COMPLETED.value
        
        if self._save_returns():
            return True, record
        return False, {"error": "保存失败"}
    
    def _check_return_complete(self, contract_id: str) -> bool:
        """检查回款是否完成"""
        contract = None
        for c in self.contracts:
            if c.get("id") == contract_id:
                contract = c
                break
        
        if not contract:
            return False
        
        total_amount = contract.get("amount", 0)
        total_paid = sum(
            r.get("amount", 0) 
            for r in self.returns 
            if r.get("contract_id") == contract_id
        )
        
        return total_paid >= total_amount
    
    def get_returns_by_contract(self, contract_id: str) -> List[Dict]:
        """获取合同的所有回款记录"""
        return [r for r in self.returns if r.get("contract_id") == contract_id]
    
    def get_overdue_returns(self, days: int = 0) -> List[Dict]:
        """
        获取逾期回款
        
        Args:
            days: 逾期天数（0表示当天逾期）
            
        Returns:
            逾期回款列表
        """
        overdue = []
        now = datetime.now().date()
        
        for record in self.returns:
            if record.get("status") == ReturnStatus.COMPLETED.value:
                continue
            
            due_date_str = record.get("return_date", "")
            if not due_date_str:
                continue
            
            try:
                due_date = datetime.fromisoformat(due_date_str).date()
                days_overdue = (now - due_date).days
                
                if days_overdue >= days:
                    contract = self._find_contract(record.get("contract_id"))
                    overdue.append({
                        "return_id": record.get("id"),
                        "contract_id": record.get("contract_id"),
                        "contract_no": contract.get("contract_no", "") if contract else "",
                        "customer_name": contract.get("customer_name", "") if contract else "",
                        "amount": record.get("amount"),
                        "due_date": due_date_str,
                        "days_overdue": days_overdue,
                        "payment_method": record.get("payment_method", ""),
                        "invoice_no": record.get("invoice_no", "")
                    })
            except:
                continue
        
        return sorted(overdue, key=lambda x: x["days_overdue"], reverse=True)
    
    def _find_contract(self, contract_id: str) -> Optional[Dict]:
        """查找合同"""
        for c in self.contracts:
            if c.get("id") == contract_id:
                return c
        return None
    
    def get_return_schedule(self, contract_id: str) -> List[Dict]:
        """获取回款计划"""
        contract = self._find_contract(contract_id)
        if not contract:
            return []
        
        # 生成回款计划
        plan = []
        signed_date = contract.get("signed_date", "")
        amount = contract.get("amount", 0)
        payment_terms = contract.get("payment_terms", "")
        
        if payment_terms:
            # 按约定生成分期计划
            if "3331" in payment_terms or "3-3-3-1" in payment_terms:
                # 示例：签约30%，到货30%，验收30%，质保10%
                schedule = [
                    ("签约款", 0.3, 0),
                    ("到货款", 0.3, 30),
                    ("验收款", 0.3, 60),
                    ("质保金", 0.1, 90)
                ]
            elif "82" in payment_terms or "8-2" in payment_terms:
                schedule = [
                    ("首款", 0.8, 0),
                    ("尾款", 0.2, 30)
                ]
            else:
                schedule = [("全额", 1.0, 0)]
            
            for name, ratio, days in schedule:
                plan.append({
                    "stage": name,
                    "amount": amount * ratio,
                    "due_days": days,
                    "status": "已到期" if days <= 0 else f"签约后{days}天"
                })
        
        # 添加已回款记录
        returns = self.get_returns_by_contract(contract_id)
        paid = sum(r.get("amount", 0) for r in returns)
        
        return {
            "contract": contract,
            "plan": plan,
            "total_amount": amount,
            "total_paid": paid,
            "total_pending": amount - paid
        }
    
    def get_summary(self) -> Dict[str, Any]:
        """获取合同汇总"""
        now = datetime.now().date()
        
        # 合同统计
        contract_stats = {
            "total": len(self.contracts),
            "by_status": {},
            "total_amount": 0,
            "signed_amount": 0
        }
        
        for c in self.contracts:
            status = c.get("status", "")
            contract_stats["by_status"][status] = contract_stats["by_status"].get(status, 0) + 1
            contract_stats["total_amount"] += c.get("amount", 0)
            if status == ContractStatus.EFFECTIVE.value:
                contract_stats["signed_amount"] += c.get("amount", 0)
        
        # 回款统计
        return_stats = {
            "total": len(self.returns),
            "total_amount": 0,
            "overdue_count": 0,
            "overdue_amount": 0
        }
        
        for r in self.returns:
            return_stats["total_amount"] += r.get("amount", 0)
            if r.get("status") == ReturnStatus.OVERDUE.value:
                return_stats["overdue_count"] += 1
                return_stats["overdue_amount"] += r.get("amount", 0)
        
        return {
            "contracts": contract_stats,
            "returns": return_stats
        }


def generate_contract_report() -> str:
    """生成合同报告"""
    manager = ContractManager()
    summary = manager.get_summary()
    overdue = manager.get_overdue_returns()
    
    lines = [
        "📄 合同与回款报告",
        "=" * 50,
        f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
        ""
    ]
    
    # 合同概览
    cs = summary["contracts"]
    lines.extend([
        "【合同概览】",
        f"  合同总数：{cs['total']}份",
        f"  合同总金额：{cs['total_amount']:.1f}万",
        f"  已生效金额：{cs['signed_amount']:.1f}万",
        ""
    ])
    
    # 回款概览
    rs = summary["returns"]
    lines.extend([
        "【回款概览】",
        f"  回款笔数：{rs['total']}笔",
        f"  回款总额：{rs['total_amount']:.1f}万",
        f"  逾期笔数：{rs['overdue_count']}笔",
        f"  逾期金额：{rs['overdue_amount']:.1f}万",
        ""
    ])
    
    # 逾期详情
    if overdue:
        lines.append("⚠️ 逾期回款详情")
        lines.append("-" * 40)
        for item in overdue[:5]:
            lines.append(f"  {item['customer_name']} - {item['amount']:.1f}万")
            lines.append(f"    逾期：{item['days_overdue']}天 | 到期日：{item['due_date'][:10]}")
        lines.append("")
    
    return "\n".join(lines)


if __name__ == "__main__":
    print(generate_contract_report())
