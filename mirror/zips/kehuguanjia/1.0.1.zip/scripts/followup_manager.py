#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
跟进提醒管理模块
提供跟进任务管理、提醒设置、超时预警等功能
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum


class TaskPriority(Enum):
    """任务优先级"""
    URGENT = "紧急"      # 超时3天以上
    HIGH = "高"          # 今天待办
    NORMAL = "常规"      # 本周待办
    LOW = "低"           # 未来待办


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "待跟进"
    IN_PROGRESS = "跟进中"
    COMPLETED = "已完成"
    CANCELLED = "已取消"
    OVERDUE = "已超时"


class FollowUpManager:
    """跟进管理类"""
    
    DATA_DIR = "data"
    TASKS_FILE = os.path.join(DATA_DIR, "followup_tasks.json")
    CUSTOMERS_FILE = os.path.join(DATA_DIR, "customers.json")
    REMINDERS_FILE = os.path.join(DATA_DIR, "reminders.json")
    
    def __init__(self):
        self.customers = self._load_customers()
        self.tasks = self._load_tasks()
        self.reminders = self._load_reminders()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        if os.path.exists(self.CUSTOMERS_FILE):
            try:
                with open(self.CUSTOMERS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_tasks(self) -> List[Dict]:
        """加载跟进任务"""
        if os.path.exists(self.TASKS_FILE):
            try:
                with open(self.TASKS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_reminders(self) -> List[Dict]:
        """加载提醒"""
        if os.path.exists(self.REMINDERS_FILE):
            try:
                with open(self.REMINDERS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_tasks(self) -> bool:
        """保存任务"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.TASKS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.tasks, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def _save_reminders(self) -> bool:
        """保存提醒"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.REMINDERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.reminders, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def reload_data(self):
        """重新加载数据"""
        self.customers = self._load_customers()
        self.tasks = self._load_tasks()
        self.reminders = self._load_reminders()
    
    def get_today_tasks(self) -> Dict[str, List[Dict]]:
        """
        获取今日跟进任务
        
        Returns:
            分类的任务列表
        """
        today = datetime.now().date()
        today_str = today.isoformat()
        urgent = []
        normal = []
        future = []
        overdue = []
        
        # 从客户中提取跟进任务
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            next_follow = customer.get("next_follow_up")
            if not next_follow:
                continue
            
            try:
                next_date = datetime.fromisoformat(next_follow).date()
                days_diff = (next_date - today).days
                
                task = {
                    "customer_id": customer.get("id"),
                    "name": customer.get("name"),
                    "company": customer.get("company"),
                    "plan_date": next_follow[:10],
                    "last_contact": customer.get("last_contact", "")[:10] if customer.get("last_contact") else None,
                    "last_talk": customer.get("last_talk_summary", "无记录"),
                    "stage": customer.get("stage"),
                    "priority": customer.get("priority", "中"),
                    "suggestion": self._generate_suggestion(customer),
                    "contact_info": customer.get("phone", ""),
                    "budget": customer.get("budget", "")
                }
                
                if days_diff < 0:
                    # 超时任务
                    overdue.append(task)
                elif days_diff == 0:
                    # 今天任务
                    if customer.get("priority") == "高" or customer.get("stage") == "谈判":
                        urgent.append(task)
                    else:
                        normal.append(task)
                elif days_diff <= 7:
                    # 本周任务
                    future.append(task)
                    
            except (ValueError, TypeError):
                continue
        
        # 从手动创建的任务中获取
        for task in self.tasks:
            if task.get("status") == TaskStatus.COMPLETED.value:
                continue
            
            task_date = task.get("due_date", "")[:10]
            if not task_date:
                continue
            
            try:
                task_date_obj = datetime.fromisoformat(task_date).date()
                days_diff = (task_date_obj - today).days
                
                if days_diff < 0:
                    overdue.append({
                        "task_id": task.get("id"),
                        "name": task.get("title"),
                        "customer_name": task.get("customer_name", ""),
                        "content": task.get("content", ""),
                        "due_date": task_date,
                        "priority": task.get("priority", "中"),
                        "is_manual": True
                    })
                elif days_diff == 0:
                    normal.append({
                        "task_id": task.get("id"),
                        "name": task.get("title"),
                        "customer_name": task.get("customer_name", ""),
                        "content": task.get("content", ""),
                        "due_date": task_date,
                        "priority": task.get("priority", "中"),
                        "is_manual": True
                    })
            except (ValueError, TypeError):
                continue
        
        # 按优先级排序
        urgent.sort(key=lambda x: x.get("stage", ""), reverse=True)
        normal.sort(key=lambda x: (x.get("priority", "中"), x.get("due_date", "")))
        future.sort(key=lambda x: x.get("due_date", ""))
        overdue.sort(key=lambda x: x.get("last_contact", ""), reverse=True)
        
        return {
            "urgent": urgent,
            "normal": normal,
            "future": future,
            "overdue": overdue
        }
    
    def _generate_suggestion(self, customer: Dict) -> str:
        """根据客户情况生成跟进建议"""
        stage = customer.get("stage", "潜在客户")
        last_contact = customer.get("last_contact")
        personality = customer.get("personality_type", "")
        concerns = customer.get("concerns", [])
        
        suggestions = []
        
        # 基于阶段建议
        stage_suggestions = {
            "潜在客户": "了解客户需求，介绍产品价值",
            "初步接触": "确认需求细节，预约进一步沟通",
            "需求确认": "提供针对性方案，深入挖掘痛点",
            "报价": "确认客户对价格的反馈，解决异议",
            "谈判": "推动决策，争取签约",
            "成交": "处理签约细节，确保顺利交付"
        }
        suggestions.append(stage_suggestions.get(stage, "保持跟进"))
        
        # 基于最后联系时间
        if last_contact:
            try:
                days = (datetime.now() - datetime.fromisoformat(last_contact)).days
                if days > 14:
                    suggestions.append(f"已{days}天未联系，建议主动关心近况")
                elif days > 7:
                    suggestions.append(f"上周联系过，了解下进展")
            except:
                pass
        
        # 基于关注点建议
        if concerns:
            suggestions.append(f"客户关注{concerns[0] if concerns else '产品'}，可重点介绍")
        
        return "；".join(suggestions) if suggestions else "主动联系客户，了解最新需求"
    
    def create_task(self, task_info: Dict) -> Tuple[bool, Dict]:
        """创建跟进任务"""
        task = {
            "id": f"task_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "title": task_info.get("title", ""),
            "content": task_info.get("content", ""),
            "customer_id": task_info.get("customer_id", ""),
            "customer_name": task_info.get("customer_name", ""),
            "due_date": task_info.get("due_date", ""),
            "priority": task_info.get("priority", "中"),
            "status": TaskStatus.PENDING.value,
            "created_at": datetime.now().isoformat(),
            "completed_at": None,
            "created_by": task_info.get("user_id", "system")
        }
        
        self.tasks.append(task)
        if self._save_tasks():
            return True, task
        return False, {"error": "保存任务失败"}
    
    def complete_task(self, task_id: str, notes: str = "") -> Tuple[bool, str]:
        """完成任务"""
        for i, task in enumerate(self.tasks):
            if task.get("id") == task_id:
                self.tasks[i]["status"] = TaskStatus.COMPLETED.value
                self.tasks[i]["completed_at"] = datetime.now().isoformat()
                self.tasks[i]["completion_notes"] = notes
                
                # 同时更新客户跟进时间
                customer_id = task.get("customer_id")
                if customer_id:
                    self._update_customer_contact(customer_id)
                
                if self._save_tasks():
                    return True, "任务已完成"
                return False, "保存失败"
        return False, "未找到任务"
    
    def _update_customer_contact(self, customer_id: str):
        """更新客户最后联系时间"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id:
                self.customers[i]["last_contact"] = datetime.now().isoformat()
                self.customers[i]["updated_at"] = datetime.now().isoformat()
                
                # 保存客户数据
                try:
                    os.makedirs(self.DATA_DIR, exist_ok=True)
                    with open(self.CUSTOMERS_FILE, 'w', encoding='utf-8') as f:
                        json.dump(self.customers, f, ensure_ascii=False, indent=2)
                except:
                    pass
                break
    
    def set_reminder(self, reminder_info: Dict) -> Tuple[bool, Dict]:
        """设置提醒"""
        reminder = {
            "id": f"remind_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "customer_id": reminder_info.get("customer_id", ""),
            "customer_name": reminder_info.get("customer_name", ""),
            "title": reminder_info.get("title", ""),
            "content": reminder_info.get("content", ""),
            "remind_at": reminder_info.get("remind_at", ""),
            "remind_type": reminder_info.get("remind_type", "once"),  # once, daily, weekly
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "triggered_at": None
        }
        
        self.reminders.append(reminder)
        if self._save_reminders():
            return True, reminder
        return False, {"error": "保存提醒失败"}
    
    def get_pending_reminders(self) -> List[Dict]:
        """获取待触发的提醒"""
        now = datetime.now()
        pending = []
        
        for reminder in self.reminders:
            if reminder.get("status") != "pending":
                continue
            
            remind_at = reminder.get("remind_at")
            if not remind_at:
                continue
            
            try:
                remind_time = datetime.fromisoformat(remind_at)
                if remind_time <= now:
                    pending.append(reminder)
            except:
                continue
        
        return pending
    
    def check_overdue_customers(self, threshold_days: int = 14) -> List[Dict]:
        """检查超时未跟进的客户"""
        now = datetime.now()
        overdue_customers = []
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            last_contact = customer.get("last_contact")
            if not last_contact:
                # 从未跟进过
                created_at = customer.get("created_at", "")
                if created_at:
                    try:
                        created_date = datetime.fromisoformat(created_at).date()
                        if (now.date() - created_date).days > threshold_days:
                            overdue_customers.append({
                                "customer_id": customer.get("id"),
                                "name": customer.get("name"),
                                "company": customer.get("company"),
                                "days_since_create": (now.date() - created_date).days,
                                "reason": "新客户超过{}天未跟进".format(threshold_days)
                            })
                    except:
                        pass
                continue
            
            try:
                last_date = datetime.fromisoformat(last_contact).date()
                days_since = (now.date() - last_date).days
                
                if days_since > threshold_days:
                    overdue_customers.append({
                        "customer_id": customer.get("id"),
                        "name": customer.get("name"),
                        "company": customer.get("company"),
                        "days_since_contact": days_since,
                        "last_contact": last_contact[:10],
                        "stage": customer.get("stage"),
                        "budget": customer.get("budget", ""),
                        "reason": "超过{}天未联系".format(threshold_days)
                    })
            except:
                continue
        
        return sorted(overdue_customers, key=lambda x: x.get("days_since_contact", 0), reverse=True)
    
    def get_followup_report(self) -> str:
        """生成跟进报告（格式化文本）"""
        tasks = self.get_today_tasks()
        overdue = self.check_overdue_customers()
        
        lines = [
            "📅 跟进工作报告",
            "=" * 40,
            f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
            ""
        ]
        
        # 超时预警
        if tasks.get("overdue") or overdue:
            lines.append("⚠️ 超时预警")
            lines.append("-" * 20)
            if tasks.get("overdue"):
                for item in tasks["overdue"][:5]:
                    if item.get("is_manual"):
                        lines.append(f"  📋 {item['name']} (超时)")
                        lines.append(f"     {item['content']}")
                    else:
                        lines.append(f"  👤 {item['name']} - {item['company']}")
                        lines.append(f"     上次联系：{item.get('last_contact', '未知')}")
                        lines.append(f"     建议：{item.get('suggestion', '')}")
                    lines.append("")
            if overdue:
                for item in overdue[:5]:
                    lines.append(f"  ⏰ {item['name']} - {item.get('reason', '')}")
            lines.append("")
        
        # 今日紧急
        if tasks.get("urgent"):
            lines.append("🔥 今日紧急")
            lines.append("-" * 20)
            for item in tasks["urgent"]:
                lines.append(f"  ⭐ {item['name']} - {item['company']}")
                lines.append(f"     阶段：{item.get('stage', '')} | 预算：{item.get('budget', '')}")
                lines.append(f"     建议：{item.get('suggestion', '')}")
                lines.append("")
            lines.append("")
        
        # 今日待办
        if tasks.get("normal"):
            lines.append("📋 今日待办")
            lines.append("-" * 20)
            for item in tasks["normal"]:
                if item.get("is_manual"):
                    lines.append(f"  📝 {item['name']}")
                    lines.append(f"     {item['content']}")
                else:
                    lines.append(f"  👤 {item['name']} - {item['company']}")
                    lines.append(f"     建议：{item.get('suggestion', '')}")
                lines.append("")
            lines.append("")
        
        # 本周计划
        if tasks.get("future"):
            lines.append("📆 本周计划")
            lines.append("-" * 20)
            for item in tasks["future"][:5]:
                lines.append(f"  📅 {item.get('plan_date', '')} | {item['name']} - {item['company']}")
            if len(tasks["future"]) > 5:
                lines.append(f"  ... 还有{len(tasks['future']) - 5}个任务")
            lines.append("")
        
        # 统计
        total_pending = len(tasks.get("urgent", [])) + len(tasks.get("normal", []))
        total_overdue = len(tasks.get("overdue", [])) + len(overdue)
        
        lines.extend([
            "📊 统计概览",
            "-" * 20,
            f"  待跟进：{total_pending}个",
            f"  超时未跟进：{total_overdue}个",
            f"  本周计划：{len(tasks.get('future', []))}个"
        ])
        
        return "\n".join(lines)


def parse_followup_schedule(text: str) -> Dict[str, Any]:
    """
    解析跟进时间安排
    
    Args:
        text: 自然语言描述
        
    Returns:
        解析出的日期信息
    """
    today = datetime.now()
    result = {
        "parsed_date": None,
        "date_type": None,
        "confidence": 0
    }
    
    text = text.lower()
    
    # 今天/明天
    if "今天" in text or "今日" in text:
        result["parsed_date"] = today.date().isoformat()
        result["date_type"] = "today"
        result["confidence"] = 95
    elif "明天" in text or "明日" in text:
        result["parsed_date"] = (today + timedelta(days=1)).date().isoformat()
        result["date_type"] = "tomorrow"
        result["confidence"] = 95
    
    # 本周/下周
    elif "本周" in text:
        result["date_type"] = "this_week"
        result["confidence"] = 80
    elif "下周" in text:
        result["date_type"] = "next_week"
        result["confidence"] = 80
    
    # 月份
    elif "月底" in text or "月末" in text:
        # 计算本月最后一天
        if today.month == 12:
            last_day = today.replace(day=31, month=12)
        else:
            next_month = today.replace(day=28, month=today.month + 1)
            last_day = next_month - timedelta(days=1)
        result["parsed_date"] = last_day.date().isoformat()
        result["date_type"] = "month_end"
        result["confidence"] = 85
    elif "月中" in text:
        result["parsed_date"] = today.replace(day=15).date().isoformat()
        result["date_type"] = "mid_month"
        result["confidence"] = 80
    
    # 具体星期
    weekdays = {
        "周一": 0, "星期一": 0,
        "周二": 1, "星期二": 1,
        "周三": 2, "星期三": 2,
        "周四": 3, "星期四": 3,
        "周五": 4, "星期五": 4,
        "周六": 5, "星期六": 5,
        "周日": 6, "星期天": 6, "周日": 6
    }
    
    for weekday_name, weekday_num in weekdays.items():
        if weekday_name in text:
            current_weekday = today.weekday()
            days_ahead = weekday_num - current_weekday
            if days_ahead <= 0:
                days_ahead += 7  # 下一周
            target_date = today + timedelta(days=days_ahead)
            result["parsed_date"] = target_date.date().isoformat()
            result["date_type"] = "weekday"
            result["confidence"] = 90
            break
    
    # 具体日期数字
    date_match = None
    for pattern in [
        r'(\d+)号',
        r'(\d+)日',
        r'(\d+)/(\d+)',
        r'(\d+)-(\d+)'
    ]:
        import re
        match = re.search(pattern, text)
        if match:
            if len(match.groups()) == 2:
                month, day = int(match.group(1)), int(match.group(2))
                try:
                    result["parsed_date"] = today.replace(month=month, day=day).date().isoformat()
                    result["date_type"] = "specific"
                    result["confidence"] = 85
                except:
                    pass
            else:
                day = int(match.group(1))
                try:
                    result["parsed_date"] = today.replace(day=day).date().isoformat()
                    result["date_type"] = "specific"
                    result["confidence"] = 80
                except:
                    pass
            break
    
    return result


if __name__ == "__main__":
    # 测试代码
    manager = FollowUpManager()
    print(manager.get_followup_report())
