#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
销售客户管家 - 主入口模块
整合所有功能模块，提供统一的接口
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any

# 导入各功能模块
from customer_manager import CustomerManager, parse_customer_info
from customer_profile import CustomerProfiler
from followup_manager import FollowUpManager, parse_followup_schedule
from script_templates import ScriptGenerator
from funnel_analyzer import SalesFunnel
from team_collaboration import TeamManager
from contract_manager import ContractManager
from channel_tracker import ChannelTracker, CompetitionManager
from data_manager import DataManager
from mode_and_permission import ModeManager, CollisionDetector, PublicPool
from performance_and_notification import PerformanceCalculator, NotificationManager, CustomFieldManager, PrivacyCompliance


class SalesCustomerManager:
    """销售客户管家主类"""
    
    def __init__(self, user_id: str = None, mode: str = None):
        """
        初始化销售客户管家
        
        Args:
            user_id: 当前用户ID
            mode: 运行模式 (personal/team)，None则自动检测
        """
        self.user_id = user_id or "personal"
        
        # 模式管理
        self.mode_manager = ModeManager()
        if mode:
            self.mode_manager.switch_mode(mode)
        
        current_mode = self.mode_manager.get_mode()
        
        # 初始化各模块
        self.customer_manager = CustomerManager(current_mode)
        self.profiler = CustomerProfiler()
        self.followup_manager = FollowUpManager()
        self.script_generator = ScriptGenerator()
        self.funnel = SalesFunnel()
        self.team_manager = TeamManager(self.user_id)
        self.contract_manager = ContractManager()
        self.channel_tracker = ChannelTracker()
        self.competition_manager = CompetitionManager()
        self.data_manager = DataManager()
        self.collision_detector = CollisionDetector()
        self.public_pool = PublicPool()
        self.performance = PerformanceCalculator()
        self.notification = NotificationManager()
        self.custom_field = CustomFieldManager()
        self.privacy = PrivacyCompliance()
    
    # ============ 客户管理 ============
    
    def add_customer(self, customer_info: Dict) -> Dict:
        """添加客户"""
        return self.customer_manager.add_customer(customer_info, self.user_id)
    
    def update_customer(self, customer_id: str, updates: Dict) -> Dict:
        """更新客户"""
        return self.customer_manager.update_customer(customer_id, updates, self.user_id)
    
    def search_customers(self, keyword: str = "", filters: Dict = None) -> List[Dict]:
        """搜索客户"""
        return self.customer_manager.search_customers(keyword, filters)
    
    def get_customer(self, customer_id: str) -> Optional[Dict]:
        """获取客户详情"""
        customer = self.customer_manager.get_customer(customer_id, self.user_id)
        if customer and self.privacy.settings.get("mask_enabled"):
            return self.privacy.mask_customer(customer)
        return customer
    
    def delete_customer(self, customer_id: str) -> Dict:
        """删除客户"""
        return self.customer_manager.delete_customer(customer_id, self.user_id)
    
    def parse_and_add_customer(self, text: str) -> Dict:
        """解析文本并添加客户"""
        info = parse_customer_info(text)
        info["created_by"] = self.user_id
        return self.add_customer(info)
    
    # ============ 跟进管理 ============
    
    def get_today_followups(self) -> Dict:
        """获取今日跟进任务"""
        return self.followup_manager.get_today_tasks()
    
    def add_followup_note(self, customer_id: str, note: str) -> Dict:
        """添加跟进记录"""
        return self.customer_manager.add_note(customer_id, note, self.user_id)
    
    def create_task(self, task_info: Dict) -> Dict:
        """创建任务"""
        return self.followup_manager.create_task(task_info)
    
    def complete_task(self, task_id: str, notes: str = "") -> Dict:
        """完成任务"""
        return self.followup_manager.complete_task(task_id, notes)
    
    # ============ 客户画像 ============
    
    def analyze_customer(self, customer_id: str) -> Dict:
        """分析客户画像"""
        return self.profiler.analyze(customer_id)
    
    def get_customer_report(self, customer_id: str) -> str:
        """获取客户画像报告"""
        return self.profiler.generate_report(customer_id)
    
    # ============ 话术生成 ============
    
    def get_script(self, scenario: str, customer_id: str = None) -> Dict:
        """获取话术"""
        customer_profile = None
        if customer_id:
            customer = self.customer_manager.get_customer(customer_id)
            if customer:
                customer_profile = self.profiler.analyze(customer_id)
        return self.script_generator.get_script(scenario, customer_profile)
    
    def handle_objection(self, objection: str, customer_id: str = None) -> Dict:
        """处理异议"""
        customer_profile = None
        if customer_id:
            customer = self.customer_manager.get_customer(customer_id)
            if customer:
                customer_profile = self.profiler.analyze(customer_id)
        return self.script_generator.handle_objection(objection, customer_profile)
    
    # ============ 销售漏斗 ============
    
    def get_funnel_report(self) -> str:
        """获取漏斗报告"""
        self.funnel.reload_data()
        return self.funnel.generate_report()
    
    def get_funnel_stats(self) -> Dict:
        """获取漏斗统计"""
        self.funnel.reload_data()
        return {
            "stages": self.funnel.count_by_stage(),
            "pipeline": self.funnel.estimate_pipeline_value(),
            "bottlenecks": self.funnel.identify_bottlenecks(
                self.funnel.calculate_conversion_rates(self.funnel.count_by_stage())
            )
        }
    
    # ============ 团队协作 ============
    
    def assign_customer(self, customer_id: str, assignee_id: str) -> Dict:
        """分配客户"""
        return self.team_manager.assign_customer(customer_id, assignee_id)
    
    def check_collision(self, customer_info: Dict) -> List[Dict]:
        """检测撞单"""
        return self.collision_detector.check_collision(customer_info, self.user_id)
    
    def claim_from_pool(self, customer_id: str) -> Dict:
        """认领公海客户"""
        success, msg = self.public_pool.claim_customer(customer_id, self.user_id, self.user_id)
        return {"success": success, "message": msg}
    
    def get_team_performance(self) -> str:
        """获取团队业绩"""
        return self.team_manager.get_team_performance()
    
    # ============ 合同管理 ============
    
    def create_contract(self, contract_info: Dict) -> Dict:
        """创建合同"""
        return self.contract_manager.create_contract(contract_info)
    
    def add_return(self, return_info: Dict) -> Dict:
        """添加回款"""
        return self.contract_manager.add_return_record(return_info)
    
    def get_overdue_returns(self) -> List[Dict]:
        """获取逾期回款"""
        return self.contract_manager.get_overdue_returns()
    
    # ============ 数据管理 ============
    
    def export_data(self, data_type: str = "all") -> Dict:
        """导出数据"""
        success, result = self.data_manager.export_data(data_type)
        return {"success": success, "file_path": result}
    
    def import_data(self, file_path: str, merge: bool = True) -> Dict:
        """导入数据"""
        s, f, e = self.data_manager.import_data(file_path, merge)
        return {"success": s > 0, "imported": s, "failed": f, "errors": e}
    
    def backup_data(self) -> Dict:
        """备份数据"""
        success, path = self.data_manager.backup()
        return {"success": success, "path": path}
    
    # ============ 统计报表 ============
    
    def get_statistics(self) -> Dict:
        """获取统计概览"""
        return self.customer_manager.get_statistics()
    
    def get_performance_report(self, period: str = "month") -> str:
        """获取业绩报告"""
        return self.performance.generate_performance_report(period)
    
    def get_channel_report(self) -> str:
        """获取渠道报告"""
        return self.channel_tracker.compare_channels()
    
    # ============ 帮助 ============
    
    def get_help(self, module: str = None) -> str:
        """获取帮助信息"""
        helps = {
            "customer": """
📋 客户管理命令：
- /记录客户 xxx - 记录新客户
- /查客户 xxx - 搜索客户
- /所有客户 - 查看所有客户
- /更新客户 xxx - 更新客户信息
- /删除客户 xxx - 删除客户
""",
            "followup": """
⏰ 跟进管理命令：
- /今日跟进 - 查看今日跟进任务
- /跟进清单 - 查看所有待跟进
- /添加记录 xxx - 添加跟进记录
- /设置提醒 xxx - 设置跟进提醒
""",
            "profile": """
🔍 客户画像命令：
- /客户画像 xxx - 分析客户画像
- /分析客户 xxx - 生成详细分析报告
""",
            "script": """
💬 话术命令：
- /话术 xxx - 获取场景话术
- /异议处理 xxx - 处理客户异议
- /推荐话术 - 获取话术推荐
""",
            "funnel": """
📊 漏斗命令：
- /漏斗 - 查看销售漏斗
- /销售漏斗 - 查看漏斗详情
- /pipeline - 查看管道情况
""",
            "contract": """
📄 合同命令：
- /合同 xxx - 查看合同
- /添加合同 - 添加新合同
- /回款 xxx - 查看回款
- /逾期 - 查看逾期回款
""",
            "team": """
👥 团队命令：
- /分配客户 xxx - 分配客户
- /撞单检测 xxx - 检测撞单
- /公海 - 查看公海池
- /认领 xxx - 认领公海客户
- /团队业绩 - 查看团队业绩
""",
            "data": """
💾 数据命令：
- /导出 - 导出所有数据
- /导入 - 导入数据
- /备份 - 备份数据
- /统计 - 查看数据统计
""",
            "performance": """
📈 业绩命令：
- /业绩 - 查看个人业绩
- /月报 - 查看月度报告
- /季报 - 查看季度报告
- /年报 - 查看年度报告
"""
        }
        
        if module and module in helps:
            return helps[module]
        
        return """
🤖 销售客户管家 - 帮助指南

【核心功能】
📋 客户管理 - 记录、搜索、跟进客户
⏰ 跟进提醒 - 智能提醒、任务管理
🔍 客户画像 - 分析性格、预测成交
💬 话术生成 - 场景话术、异议处理
📊 销售漏斗 - 管道分析、瓶颈识别
📄 合同管理 - 合同签署、回款跟踪
👥 团队协作 - 客户分配、撞单检测
💾 数据管理 - 导入导出、备份恢复

【常用命令】
/记录客户 - 添加新客户
/查客户 - 搜索客户
/今日跟进 - 查看今日任务
/客户画像 - 分析客户
/话术 - 获取话术
/漏斗 - 查看销售漏斗
/业绩 - 查看业绩
/帮助 - 显示此帮助

输入 /帮助 + 功能名 可查看详细帮助
如：/帮助 客户管理
"""
    
    # ============ 快捷方法 ============
    
    def handle_command(self, command: str, params: str = "") -> Dict:
        """
        处理命令
        
        Args:
            command: 命令类型
            params: 命令参数
            
        Returns:
            处理结果
        """
        command = command.lower().strip()
        params = params.strip() if params else ""
        
        # 客户管理
        if command in ["记录客户", "add_customer", "add"]:
            return self.parse_and_add_customer(params)
        
        if command in ["查客户", "search", "find"]:
            customers = self.search_customers(params)
            return {"success": True, "count": len(customers), "customers": customers}
        
        if command in ["客户", "customer", "info"]:
            customer = self.get_customer(params)
            return {"success": bool(customer), "customer": customer}
        
        # 跟进
        if command in ["今日跟进", "today", "followup_today"]:
            tasks = self.get_today_followups()
            return {"success": True, "tasks": tasks}
        
        if command in ["添加记录", "add_note", "跟进"]:
            # 格式: 客户名|记录内容
            parts = params.split("|")
            if len(parts) == 2:
                return self.add_followup_note(parts[0], parts[1])
            return {"success": False, "message": "格式: 客户名|记录内容"}
        
        # 画像
        if command in ["画像", "profile", "analyze"]:
            report = self.get_customer_report(params)
            return {"success": True, "report": report}
        
        # 话术
        if command in ["话术", "script"]:
            result = self.get_script(params)
            return {"success": True, "script": result}
        
        if command in ["异议", "objection"]:
            result = self.handle_objection(params)
            return {"success": True, "result": result}
        
        # 漏斗
        if command in ["漏斗", "funnel", "pipeline"]:
            report = self.get_funnel_report()
            return {"success": True, "report": report}
        
        # 统计
        if command in ["统计", "stats", "statistics"]:
            stats = self.get_statistics()
            return {"success": True, "stats": stats}
        
        # 业绩
        if command in ["业绩", "performance"]:
            report = self.get_performance_report()
            return {"success": True, "report": report}
        
        # 帮助
        if command in ["帮助", "help"]:
            help_text = self.get_help()
            return {"success": True, "help": help_text}
        
        return {"success": False, "message": f"未知命令: {command}"}


def create_manager(user_id: str = None, mode: str = None) -> SalesCustomerManager:
    """创建管理器实例"""
    return SalesCustomerManager(user_id, mode)


if __name__ == "__main__":
    # 命令行测试
    manager = SalesCustomerManager()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        params = sys.argv[2] if len(sys.argv) > 2 else ""
        result = manager.handle_command(command, params)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("销售客户管家")
        print("=" * 50)
        print(manager.get_help())
