#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据导入导出与备份模块
支持数据的导入、导出、备份、恢复等功能
"""

import json
import os
import shutil
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any


class DataManager:
    """数据管理器"""
    
    DATA_DIR = "data"
    BACKUP_DIR = os.path.join(DATA_DIR, "backups")
    
    # 支持的数据类型
    DATA_TYPES = [
        "customers",      # 客户数据
        "contracts",      # 合同数据
        "returns",        # 回款数据
        "tasks",          # 任务数据
        "reminders",      # 提醒数据
        "team",           # 团队数据
        "channels",       # 渠道数据
        "competitors",    # 竞品数据
        "custom_scripts",  # 自定义话术
        "settings"        # 设置
    ]
    
    def __init__(self):
        os.makedirs(self.DATA_DIR, exist_ok=True)
        os.makedirs(self.BACKUP_DIR, exist_ok=True)
    
    def export_data(self, data_type: str = "all", file_path: str = None) -> Tuple[bool, str]:
        """
        导出数据
        
        Args:
            data_type: 数据类型（all或具体类型）
            file_path: 输出文件路径
            
        Returns:
            (成功标志, 文件路径/错误信息)
        """
        if data_type == "all":
            return self._export_all(file_path)
        elif data_type in self.DATA_TYPES:
            return self._export_single(data_type, file_path)
        else:
            return False, f"不支持的数据类型: {data_type}"
    
    def _export_all(self, file_path: str = None) -> Tuple[bool, str]:
        """导出所有数据"""
        if file_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = os.path.join(self.DATA_DIR, f"export_all_{timestamp}.json")
        
        all_data = {}
        
        for data_type in self.DATA_TYPES:
            file_name = f"{data_type}.json"
            full_path = os.path.join(self.DATA_DIR, file_name)
            
            if os.path.exists(full_path):
                try:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        all_data[data_type] = json.load(f)
                except:
                    all_data[data_type] = None
        
        export_data = {
            "export_time": datetime.now().isoformat(),
            "version": "1.0",
            "data": all_data
        }
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            return True, file_path
        except Exception as e:
            return False, f"导出失败: {str(e)}"
    
    def _export_single(self, data_type: str, file_path: str = None) -> Tuple[bool, str]:
        """导出单类数据"""
        if file_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = os.path.join(self.DATA_DIR, f"{data_type}_{timestamp}.json")
        
        file_name = f"{data_type}.json"
        full_path = os.path.join(self.DATA_DIR, file_name)
        
        if not os.path.exists(full_path):
            return False, f"数据文件不存在: {file_name}"
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "export_time": datetime.now().isoformat(),
                    "data_type": data_type,
                    "data": data
                }, f, ensure_ascii=False, indent=2)
            
            return True, file_path
        except Exception as e:
            return False, f"导出失败: {str(e)}"
    
    def import_data(self, file_path: str, merge: bool = True) -> Tuple[int, int, List[str]]:
        """
        导入数据
        
        Args:
            file_path: 导入文件路径
            merge: 是否合并（True追加，False覆盖）
            
        Returns:
            (成功数, 失败数, 错误列表)
        """
        if not os.path.exists(file_path):
            return 0, 0, ["文件不存在"]
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
        except json.JSONDecodeError:
            return 0, 0, ["文件格式错误，不是有效的JSON"]
        except Exception as e:
            return 0, 0, [f"读取文件失败: {str(e)}"]
        
        errors = []
        success_count = 0
        fail_count = 0
        
        # 处理导出格式
        if "data" in import_data:
            # 全量导出格式
            data_dict = import_data["data"]
            for data_type, data in data_dict.items():
                if data is None:
                    continue
                
                s, f, e = self._import_single_data(data_type, data, merge)
                success_count += s
                fail_count += f
                errors.extend(e)
        else:
            # 单类型数据格式
            data_type = import_data.get("data_type", "unknown")
            data = import_data.get("data", import_data)
            
            if isinstance(data, list):
                s, f, e = self._import_single_data(data_type, data, merge)
                success_count += s
                fail_count += f
                errors.extend(e)
        
        return success_count, fail_count, errors
    
    def _import_single_data(self, data_type: str, data: Any, merge: bool) -> Tuple[int, int, List[str]]:
        """导入单类数据"""
        if data_type not in self.DATA_TYPES:
            return 0, 1, [f"不支持的数据类型: {data_type}"]
        
        file_path = os.path.join(self.DATA_DIR, f"{data_type}.json")
        existing_data = []
        
        if os.path.exists(file_path) and merge:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
            except:
                pass
        
        if merge:
            if isinstance(existing_data, list) and isinstance(data, list):
                # 合并列表数据
                existing_ids = {item.get("id") for item in existing_data if isinstance(item, dict)}
                for item in data:
                    if isinstance(item, dict) and item.get("id") not in existing_ids:
                        existing_data.append(item)
                final_data = existing_data
            else:
                final_data = data if data else existing_data
        else:
            final_data = data
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(final_data, f, ensure_ascii=False, indent=2)
            return len(data) if isinstance(data, list) else 1, 0, []
        except Exception as e:
            return 0, 1, [f"保存失败: {str(e)}"]
    
    def backup(self, backup_name: str = None) -> Tuple[bool, str]:
        """
        创建备份
        
        Args:
            backup_name: 备份名称
            
        Returns:
            (成功标志, 备份路径)
        """
        if backup_name is None:
            backup_name = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        backup_path = os.path.join(self.BACKUP_DIR, backup_name)
        
        try:
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)
            
            shutil.copytree(self.DATA_DIR, backup_path)
            return True, backup_path
        except Exception as e:
            return False, f"备份失败: {str(e)}"
    
    def restore(self, backup_name: str, target_dir: str = None) -> Tuple[bool, str]:
        """
        恢复备份
        
        Args:
            backup_name: 备份名称
            target_dir: 目标目录（默认恢复到data目录）
            
        Returns:
            (成功标志, 消息)
        """
        backup_path = os.path.join(self.BACKUP_DIR, backup_name)
        
        if not os.path.exists(backup_path):
            return False, "备份不存在"
        
        if target_dir is None:
            target_dir = self.DATA_DIR
        
        try:
            # 先备份当前数据
            temp_backup = f"{self.DATA_DIR}_temp"
            if os.path.exists(self.DATA_DIR):
                shutil.copytree(self.DATA_DIR, temp_backup)
            
            # 恢复数据
            if os.path.exists(target_dir):
                shutil.rmtree(target_dir)
            shutil.copytree(backup_path, target_dir)
            
            # 删除临时备份
            if os.path.exists(temp_backup):
                shutil.rmtree(temp_backup)
            
            return True, "恢复成功"
        except Exception as e:
            return False, f"恢复失败: {str(e)}"
    
    def list_backups(self) -> List[Dict]:
        """列出所有备份"""
        backups = []
        
        if not os.path.exists(self.BACKUP_DIR):
            return backups
        
        for name in os.listdir(self.BACKUP_DIR):
            backup_path = os.path.join(self.BACKUP_DIR, name)
            if os.path.isdir(backup_path):
                # 计算备份大小
                total_size = sum(
                    os.path.getsize(os.path.join(dirpath, filename))
                    for dirpath, _, filenames in os.walk(backup_path)
                    for filename in filenames
                )
                
                backups.append({
                    "name": name,
                    "path": backup_path,
                    "size": f"{total_size / 1024:.1f}KB",
                    "created": datetime.fromtimestamp(os.path.getctime(backup_path)).isoformat()
                })
        
        # 按时间排序
        backups.sort(key=lambda x: x["created"], reverse=True)
        return backups
    
    def delete_backup(self, backup_name: str) -> Tuple[bool, str]:
        """删除备份"""
        backup_path = os.path.join(self.BACKUP_DIR, backup_name)
        
        if not os.path.exists(backup_path):
            return False, "备份不存在"
        
        try:
            shutil.rmtree(backup_path)
            return True, "删除成功"
        except Exception as e:
            return False, f"删除失败: {str(e)}"
    
    def get_data_stats(self) -> Dict[str, Any]:
        """获取数据统计"""
        stats = {}
        
        for data_type in self.DATA_TYPES:
            file_path = os.path.join(self.DATA_DIR, f"{data_type}.json")
            
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    if isinstance(data, list):
                        count = len(data)
                    elif isinstance(data, dict):
                        count = len(data.get("data", data))
                    else:
                        count = 0
                    
                    file_size = os.path.getsize(file_path)
                    stats[data_type] = {
                        "count": count,
                        "size": f"{file_size / 1024:.1f}KB"
                    }
                except:
                    stats[data_type] = {"count": 0, "size": "0KB"}
            else:
                stats[data_type] = {"count": 0, "size": "0KB"}
        
        return stats


def export_all() -> str:
    """便捷导出函数"""
    manager = DataManager()
    success, result = manager.export_data("all")
    if success:
        return f"✅ 数据已导出到: {result}"
    return f"❌ 导出失败: {result}"


def import_from_file(file_path: str, merge: bool = True) -> str:
    """便捷导入函数"""
    manager = DataManager()
    s, f, e = manager.import_data(file_path, merge)
    
    if f == 0:
        return f"✅ 导入成功，共导入{s}条数据"
    return f"⚠️ 导入完成，{s}条成功，{f}条失败。错误: {', '.join(e[:3])}"


def create_backup() -> str:
    """便捷备份函数"""
    manager = DataManager()
    success, result = manager.backup()
    if success:
        return f"✅ 备份已创建: {result}"
    return f"❌ 备份失败: {result}"


if __name__ == "__main__":
    manager = DataManager()
    print("数据统计:")
    stats = manager.get_data_stats()
    for k, v in stats.items():
        print(f"  {k}: {v['count']}条 ({v['size']})")
