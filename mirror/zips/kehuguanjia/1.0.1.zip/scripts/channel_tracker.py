#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
渠道追踪与数据分析模块
支持客户来源分析、渠道转化分析、ROI计算等功能
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict


class ChannelTracker:
    """渠道追踪器"""
    
    DATA_DIR = "data"
    CHANNELS_FILE = os.path.join(DATA_DIR, "channels.json")
    
    # 预定义渠道类型
    DEFAULT_CHANNELS = [
        "线上推广",      # 网络广告、SEM等
        "线下活动",      # 展会、地推等
        "转介绍",        # 客户推荐
        "电话营销",      # 外呼
        "自然流量",      # 自然来访
        "合作伙伴",      # 渠道合作
        "社交媒体",      # 微信、抖音等
        "其他"           # 其他来源
    ]
    
    def __init__(self):
        self.channels = self._load_channels()
        self.customers = self._load_customers()
    
    def _load_channels(self) -> Dict:
        """加载渠道配置"""
        if os.path.exists(self.CHANNELS_FILE):
            try:
                with open(self.CHANNELS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "channels": {ch: {"name": ch, "enabled": True} for ch in self.DEFAULT_CHANNELS},
            "cost_data": {},  # 渠道成本数据
            "campaigns": []   # 营销活动
        }
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_channels(self) -> bool:
        """保存渠道数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.CHANNELS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.channels, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def add_channel_cost(self, channel: str, cost: float, period: str = None) -> bool:
        """
        添加渠道成本
        
        Args:
            channel: 渠道名称
            cost: 成本金额
            period: 周期（月份，格式YYYY-MM）
        """
        if period is None:
            period = datetime.now().strftime("%Y-%m")
        
        if "cost_data" not in self.channels:
            self.channels["cost_data"] = {}
        
        if period not in self.channels["cost_data"]:
            self.channels["cost_data"][period] = {}
        
        if channel not in self.channels["cost_data"][period]:
            self.channels["cost_data"][period][channel] = 0
        
        self.channels["cost_data"][period][channel] += cost
        return self._save_channels()
    
    def get_channel_stats(self, period: str = None) -> Dict[str, Any]:
        """
        获取渠道统计数据
        
        Args:
            period: 统计周期（月份）
        """
        if period is None:
            period = datetime.now().strftime("%Y-%m")
        
        # 统计各渠道客户数
        channel_customers = defaultdict(lambda: {"count": 0, "budget": 0, "deals": 0, "amount": 0})
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            source = customer.get("source", "其他")
            budget = customer.get("budget_value", 0)
            stage = customer.get("stage", "")
            
            channel_customers[source]["count"] += 1
            channel_customers[source]["budget"] += budget
            
            if stage == "成交":
                channel_customers[source]["deals"] += 1
                channel_customers[source]["amount"] += budget
        
        # 获取渠道成本
        cost_data = self.channels.get("cost_data", {}).get(period, {})
        
        # 计算ROI
        results = []
        for channel, stats in channel_customers.items():
            cost = cost_data.get(channel, 0)
            revenue = stats["amount"]
            
            if cost > 0:
                roi = (revenue - cost) / cost * 100
                cpa = cost / stats["count"] if stats["count"] > 0 else 0
                conversion = stats["deals"] / stats["count"] * 100 if stats["count"] > 0 else 0
            else:
                roi = 0
                cpa = 0
                conversion = 0
            
            results.append({
                "channel": channel,
                "customers": stats["count"],
                "budget": stats["budget"],
                "deals": stats["deals"],
                "revenue": revenue,
                "cost": cost,
                "roi": f"{roi:.1f}%",
                "cpa": f"{cpa:.1f}万",  # 获客成本
                "conversion": f"{conversion:.1f}%"
            })
        
        # 按成交金额排序
        results.sort(key=lambda x: x["revenue"], reverse=True)
        
        return {
            "period": period,
            "channels": results,
            "total": {
                "customers": sum(r["customers"] for r in results),
                "deals": sum(r["deals"] for r in results),
                "revenue": sum(r["revenue"] for r in results),
                "cost": sum(r["cost"] for r in results)
            }
        }
    
    def get_conversion_funnel(self, channel: str = None) -> Dict[str, Any]:
        """
        获取渠道转化漏斗
        
        Args:
            channel: 筛选特定渠道
        """
        stages = ["潜在客户", "初步接触", "需求确认", "方案报价", "商务谈判", "成交"]
        funnel = {stage: 0 for stage in stages}
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            if channel and customer.get("source") != channel:
                continue
            
            stage = customer.get("stage", "")
            if stage in funnel:
                funnel[stage] += 1
        
        # 计算转化率
        conversion_rates = []
        for i in range(len(stages) - 1):
            current = funnel[stages[i]]
            next_val = funnel[stages[i + 1]]
            rate = (next_val / current * 100) if current > 0 else 0
            conversion_rates.append({
                "from": stages[i],
                "to": stages[i + 1],
                "rate": f"{rate:.1f}%"
            })
        
        return {
            "channel": channel or "全部",
            "funnel": funnel,
            "conversion_rates": conversion_rates
        }
    
    def compare_channels(self, period: str = None) -> str:
        """生成渠道对比报告"""
        stats = self.get_channel_stats(period)
        
        lines = [
            "📈 渠道分析报告",
            "=" * 50,
            f"统计周期：{stats['period']}",
            ""
        ]
        
        # 总览
        total = stats["total"]
        lines.extend([
            "【总体概览】",
            f"  总客户数：{total['customers']}个",
            f"  总成交数：{total['deals']}单",
            f"  总收入：{total['revenue']:.1f}万",
            f"  总成本：{total['cost']:.1f}万",
            f"  综合ROI：{((total['revenue'] - total['cost']) / total['cost'] * 100) if total['cost'] > 0 else 0:.1f}%",
            ""
        ])
        
        # 渠道明细
        lines.append("【渠道表现】")
        for ch in stats["channels"]:
            lines.append(f"  {ch['channel']}")
            lines.append(f"    客户：{ch['customers']}个 | 成交：{ch['deals']}单")
            lines.append(f"    收入：{ch['revenue']:.1f}万 | 成本：{ch['cost']:.1f}万")
            lines.append(f"    ROI：{ch['roi']} | CPA：{ch['cpa']} | 转化：{ch['conversion']}")
            lines.append("")
        
        return "\n".join(lines)


class CompetitionManager:
    """竞品管理器"""
    
    DATA_DIR = "data"
    COMPETITORS_FILE = os.path.join(DATA_DIR, "competitors.json")
    
    def __init__(self):
        self.competitors = self._load_competitors()
        self.customers = self._load_customers()
    
    def _load_competitors(self) -> List[Dict]:
        """加载竞品数据"""
        if os.path.exists(self.COMPETITORS_FILE):
            try:
                with open(self.COMPETITORS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.DATA_DIR, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_competitors(self) -> bool:
        """保存竞品数据"""
        try:
            os.makedirs(self.DATA_DIR, exist_ok=True)
            with open(self.COMPETITORS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.competitors, f, ensure_ascii=False, indent=2)
            return True
        except:
            return False
    
    def add_competitor(self, info: Dict) -> Tuple[bool, Dict]:
        """添加竞品信息"""
        competitor = {
            "id": f"comp_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "name": info.get("name", ""),
            "products": info.get("products", []),
            "strengths": info.get("strengths", []),  # 优势
            "weaknesses": info.get("weaknesses", []),  # 劣势
            "pricing": info.get("pricing", ""),  # 定价
            "market_share": info.get("market_share", ""),  # 市场份额
            "target_customers": info.get("target_customers", ""),  # 目标客户
            "notes": info.get("notes", ""),
            "created_at": datetime.now().isoformat()
        }
        
        self.competitors.append(competitor)
        if self._save_competitors():
            return True, competitor
        return False, {"error": "保存失败"}
    
    def get_competitor_analysis(self, competitor_name: str = None) -> Dict:
        """获取竞品分析"""
        if competitor_name:
            for c in self.competitors:
                if competitor_name.lower() in c.get("name", "").lower():
                    return c
            return None
        
        return self.competitors
    
    def record_competitor_win(self, customer_id: str, competitor: str, notes: str = "") -> bool:
        """记录竞品赢单"""
        for i, c in enumerate(self.customers):
            if c.get("id") == customer_id:
                if "competitor_history" not in self.customers[i]:
                    self.customers[i]["competitor_history"] = []
                
                self.customers[i]["competitor_history"].append({
                    "competitor": competitor,
                    "result": "win",
                    "notes": notes,
                    "date": datetime.now().isoformat()
                })
                
                try:
                    with open(os.path.join(self.DATA_DIR, "customers.json"), 'w', encoding='utf-8') as f:
                        json.dump(self.customers, f, ensure_ascii=False, indent=2)
                    return True
                except:
                    pass
                break
        return False
    
    def get_competitive_stats(self) -> Dict:
        """获取竞品统计"""
        # 统计竞品出现次数和胜率
        competitor_stats = defaultdict(lambda: {"total": 0, "wins": 0, "losses": 0})
        
        for customer in self.customers:
            if customer.get("is_deleted"):
                continue
            
            competitors = customer.get("competitors", [])
            history = customer.get("competitor_history", [])
            
            for comp in competitors:
                competitor_stats[comp]["total"] += 1
            
            for h in history:
                comp = h.get("competitor", "")
                result = h.get("result", "")
                if comp in competitor_stats:
                    if result == "win":
                        competitor_stats[comp]["wins"] += 1
                    else:
                        competitor_stats[comp]["losses"] += 1
        
        results = []
        for name, stats in competitor_stats.items():
            total = stats["total"]
            win_rate = (stats["wins"] / total * 100) if total > 0 else 0
            results.append({
                "name": name,
                "encounters": total,
                "wins": stats["wins"],
                "losses": stats["losses"],
                "win_rate": f"{win_rate:.1f}%"
            })
        
        results.sort(key=lambda x: x["encounters"], reverse=True)
        
        return {"competitors": results}
    
    def generate_competitive_report(self) -> str:
        """生成竞品对比报告"""
        stats = self.get_competitive_stats()
        
        lines = [
            "🏆 竞品分析报告",
            "=" * 50,
            ""
        ]
        
        if not stats["competitors"]:
            lines.append("暂无竞品对战记录")
            return "\n".join(lines)
        
        lines.append("【竞品对战统计】")
        for comp in stats["competitors"]:
            lines.append(f"  {comp['name']}")
            lines.append(f"    对战：{comp['encounters']}次 | 赢：{comp['wins']} | 输：{comp['losses']}")
            lines.append(f"    胜率：{comp['win_rate']}")
            lines.append("")
        
        return "\n".join(lines)


def generate_channel_report() -> str:
    """生成渠道报告"""
    tracker = ChannelTracker()
    return tracker.compare_channels()


def generate_competition_report() -> str:
    """生成竞品报告"""
    manager = CompetitionManager()
    return manager.generate_competitive_report()


if __name__ == "__main__":
    print(generate_channel_report())
    print("\n" + generate_competition_report())
