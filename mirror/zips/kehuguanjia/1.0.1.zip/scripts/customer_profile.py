#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
客户画像分析模块
基于客户沟通记录和行为数据，生成客户画像和沟通策略建议
"""

import json
import os
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from collections import Counter


class PersonalityType:
    """性格类型定义"""
    ANALYTICAL = "分析型"      # 注重数据，理性决策
    DECISIVE = "果断型"         # 决策快速，喜欢直接
    HESITANT = "犹豫型"         # 决策缓慢，爱纠结
    RELATIONSHIP = "关系型"     # 重视信任，感性决策


class ConcernType:
    """关注点类型"""
    PRICE = "价格"
    QUALITY = "品质"
    SERVICE = "服务"
    BRAND = "品牌"


class CustomerProfiler:
    """客户画像分析器"""
    
    # 性格特征关键词
    PERSONALITY_KEYWORDS = {
        PersonalityType.DECISIVE: [
            "赶紧", "快点", "马上", "尽快", "立刻", "速度", "效率",
            "直接", "干脆", "痛快点", "别磨叽"
        ],
        PersonalityType.HESITANT: [
            "考虑", "想想", "商量", "纠结", "犹豫", "对比", "看看再说",
            "再看看", "不着急", "慢慢来", "再说"
        ],
        PersonalityType.ANALYTICAL: [
            "数据", "参数", "指标", "分析", "对比", "研究", "评估",
            "详细", "具体", "报告", "方案", "细节"
        ],
        PersonalityType.RELATIONSHIP: [
            "信任", "关系", "朋友", "熟悉", "了解", "靠谱", "放心",
            "人情", "面子", "交情", "认识"
        ]
    }
    
    # 关注点关键词
    CONCERN_KEYWORDS = {
        ConcernType.PRICE: ["价格", "贵", "便宜", "费用", "钱", "成本", "预算", "性价比", "划算", "优惠", "折扣"],
        ConcernType.QUALITY: ["质量", "品质", "好", "差", "靠谱", "稳定", "性能", "功能", "效果"],
        ConcernType.SERVICE: ["服务", "售后", "保障", "支持", "响应", "及时", "态度", "维护"],
        ConcernType.BRAND: ["品牌", "名气", "知名", "口碑", "影响力", "案例", "公司", "资质"]
    }
    
    # 决策速度关键词
    DECISION_SPEED_KEYWORDS = {
        "快": ["下周", "月底", "尽快", "马上", "最近", "抓紧", "着急", "加急"],
        "慢": ["慢慢", "不急", "再看看", "观望", "等等", "以后", "将来", "考虑中"]
    }
    
    # 决策权重级关键词
    DECISION_MAKER_KEYWORDS = {
        "高": ["老板", "总经理", "董事长", "自己决定", "能做主", "说了算", "我定"],
        "中": ["可以", "建议", "推荐", "帮忙", "协调", "推动"],
        "低": ["请示", "汇报", "开会", "讨论", "审批", "流程", "上面"]
    }
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self.customers = self._load_customers()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        file_path = os.path.join(self.data_dir, "customers.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def analyze(self, customer_id: str) -> Dict[str, Any]:
        """
        分析客户画像
        
        Args:
            customer_id: 客户ID或姓名
            
        Returns:
            画像分析结果
        """
        # 查找客户
        customer = None
        for c in self.customers:
            if c.get("id") == customer_id or c.get("name") == customer_id:
                customer = c
                break
        
        if not customer:
            return {"error": "未找到客户"}
        
        # 获取沟通记录
        notes = customer.get("notes", [])
        
        # 分析各维度
        personality = self._analyze_personality(notes)
        concerns = self._analyze_concerns(notes)
        decision_speed = self._analyze_decision_speed(notes)
        decision_maker = self._analyze_decision_maker(notes, customer)
        probability = self._calculate_probability(customer, personality, concerns)
        strategy = self._generate_strategy(personality, concerns, decision_speed)
        
        return {
            "customer_id": customer.get("id"),
            "name": customer.get("name"),
            "company": customer.get("company"),
            "analyzed_at": datetime.now().isoformat(),
            "personality": personality,
            "concerns": concerns,
            "decision_speed": decision_speed,
            "decision_maker_level": decision_maker,
            "probability": probability,
            "strategy": strategy,
            "insights": self._generate_insights(customer, notes, personality, concerns)
        }
    
    def _analyze_personality(self, notes: List[Dict]) -> Dict[str, Any]:
        """分析性格特征"""
        if not notes:
            return {
                "type": "未知",
                "confidence": 0,
                "evidence": [],
                "description": "暂无足够数据进行性格分析"
            }
        
        # 合并所有沟通内容
        all_text = " ".join([
            note.get("content", "") 
            for note in notes 
            if note.get("content")
        ]).lower()
        
        # 统计各类型关键词出现次数
        scores = {}
        for ptype, keywords in self.PERSONALITY_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in all_text)
            scores[ptype] = count
        
        # 确定最匹配的类型
        if not scores or max(scores.values()) == 0:
            return {
                "type": "中立型",
                "confidence": 50,
                "evidence": [],
                "description": "沟通风格较为平衡，需更多信息判断"
            }
        
        max_type = max(scores, key=scores.get)
        max_score = scores[max_type]
        total = sum(scores.values())
        confidence = min(int(max_score / total * 100), 95) if total > 0 else 50
        
        # 获取证据
        evidence = []
        for kw in self.PERSONALITY_KEYWORDS[max_type]:
            if kw in all_text:
                evidence.append(kw)
        
        descriptions = {
            PersonalityType.ANALYTICAL: "注重数据和逻辑，喜欢详细对比后再决策",
            PersonalityType.DECISIVE: "决策风格直接快速，喜欢简洁高效的沟通",
            PersonalityType.HESITANT: "决策相对谨慎，需要更多时间和案例支持",
            PersonalityType.RELATIONSHIP: "重视信任和关系，需要建立良好的沟通氛围"
        }
        
        return {
            "type": max_type,
            "confidence": confidence + 20,  # 有证据时加分
            "evidence": evidence[:5],  # 最多5条证据
            "description": descriptions.get(max_type, "")
        }
    
    def _analyze_concerns(self, notes: List[Dict]) -> Dict[str, Any]:
        """分析关注点优先级"""
        if not notes:
            return {
                "priority": [],
                "description": "暂无足够数据判断关注点"
            }
        
        all_text = " ".join([
            note.get("content", "") 
            for note in notes 
            if note.get("content")
        ])
        
        # 统计各关注点出现频次
        concern_scores = {}
        for ctype, keywords in self.CONCERN_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in all_text)
            concern_scores[ctype] = count
        
        # 按分数排序
        sorted_concerns = sorted(
            concern_scores.items(), 
            key=lambda x: x[1], 
            reverse=True
        )
        
        # 提取有分数的关注点
        priority = [
            {"type": ctype, "score": score, "keyword": self.CONCERN_KEYWORDS[ctype][0]}
            for ctype, score in sorted_concerns
            if score > 0
        ]
        
        return {
            "priority": priority[:4],  # 最多4个
            "top_priority": priority[0]["type"] if priority else "未知",
            "description": self._describe_concerns(priority)
        }
    
    def _describe_concerns(self, concerns: List[Dict]) -> str:
        """描述关注点"""
        if not concerns:
            return "客户关注点尚不明确"
        
        types = [c["type"] for c in concerns]
        priority_str = " > ".join(types)
        
        descriptions = {
            "价格": "价格敏感型客户，建议强调性价比和投资回报",
            "品质": "品质导向型客户，建议突出产品优势和案例",
            "服务": "服务导向型客户，建议强调售后保障和支持",
            "品牌": "品牌导向型客户，建议展示品牌实力和口碑"
        }
        
        desc_parts = [descriptions.get(t, "") for t in types if t in descriptions]
        return f"优先级：{priority_str}。{' '.join(desc_parts)}"
    
    def _analyze_decision_speed(self, notes: List[Dict]) -> Dict[str, Any]:
        """分析决策速度"""
        if not notes:
            return {
                "speed": "中",
                "estimated_days": 30,
                "description": "暂无足够数据预估决策周期"
            }
        
        all_text = " ".join([
            note.get("content", "") 
            for note in notes 
            if note.get("content")
        ])
        
        fast_indicators = sum(1 for kw in self.DECISION_SPEED_KEYWORDS["快"] if kw in all_text)
        slow_indicators = sum(1 for kw in self.DECISION_SPEED_KEYWORDS["慢"] if kw in all_text)
        
        if fast_indicators > slow_indicators:
            return {
                "speed": "快",
                "estimated_days": 14,
                "description": "客户决策较为迅速，建议把握时机趁热打铁"
            }
        elif slow_indicators > fast_indicators:
            return {
                "speed": "慢",
                "estimated_days": 60,
                "description": "客户决策相对谨慎，需要耐心跟进，保持定期沟通"
            }
        else:
            return {
                "speed": "中",
                "estimated_days": 30,
                "description": "决策节奏正常，保持常规跟进节奏"
            }
    
    def _analyze_decision_maker(self, notes: List[Dict], customer: Dict) -> Dict[str, Any]:
        """分析决策层级"""
        # 首先检查客户资料中的信息
        dm_level = customer.get("decision_maker", "")
        if dm_level:
            levels = {"高": 3, "中": 2, "低": 1}
            return {
                "level": dm_level,
                "score": levels.get(dm_level, 2),
                "description": self._get_dm_description(dm_level)
            }
        
        # 从沟通记录中分析
        if not notes:
            return {
                "level": "中",
                "score": 2,
                "description": "决策层级信息不足，需进一步确认"
            }
        
        all_text = " ".join([
            note.get("content", "") 
            for note in notes 
            if note.get("content")
        ])
        
        scores = {}
        for level, keywords in self.DECISION_MAKER_KEYWORDS.items():
            scores[level] = sum(1 for kw in keywords if kw in all_text)
        
        if not scores or max(scores.values()) == 0:
            return {
                "level": "中",
                "score": 2,
                "description": "决策层级信息不明确，需进一步了解"
            }
        
        max_level = max(scores, key=scores.get)
        return {
            "level": max_level,
            "score": {"高": 3, "中": 2, "低": 1}.get(max_level, 2),
            "description": self._get_dm_description(max_level)
        }
    
    def _get_dm_description(self, level: str) -> str:
        """获取决策层级描述"""
        descriptions = {
            "高": "客户具有最终决策权，可以直接推动成交",
            "中": "客户有一定影响力，但可能需要向上级汇报",
            "低": "客户可能需要请示他人，需要协助其内部推动"
        }
        return descriptions.get(level, "")
    
    def _calculate_probability(self, customer: Dict, personality: Dict, concerns: Dict) -> Dict[str, Any]:
        """计算成交概率"""
        base_prob = 30  # 基础概率
        
        # 预算明确性
        budget = customer.get("budget_value", 0)
        if budget > 0:
            base_prob += 10
        if budget > 50:
            base_prob += 10
        if budget > 100:
            base_prob += 5
        
        # 需求明确性
        requirement = customer.get("requirement", "")
        if requirement:
            base_prob += 10
        
        # 跟进次数
        follow_count = customer.get("follow_up_count", 0)
        if follow_count >= 3:
            base_prob += 10
        elif follow_count >= 1:
            base_prob += 5
        
        # 决策层级
        dm_level = personality.get("decision_maker_level", {}).get("level", "中")
        if dm_level == "高":
            base_prob += 15
        elif dm_level == "低":
            base_prob -= 10
        
        # 性格因素
        ptype = personality.get("type", "未知")
        if ptype == "果断型":
            base_prob += 10
        elif ptype == "犹豫型":
            base_prob -= 5
        
        # 客户阶段
        stage = customer.get("stage", "潜在客户")
        stage_scores = {
            "成交": 50, "谈判": 30, "报价": 20, 
            "需求确认": 10, "初步接触": 5, "潜在客户": 0
        }
        base_prob += stage_scores.get(stage, 0)
        
        # 确保在合理范围内
        final_prob = max(5, min(95, base_prob))
        
        # 生成说明
        factors = []
        if budget > 0:
            factors.append("预算明确")
        if follow_count >= 3:
            factors.append("多次跟进")
        if dm_level == "高":
            factors.append("决策权高")
        if requirement:
            factors.append("需求清晰")
        if ptype == "果断型":
            factors.append("决策风格果断")
        
        return {
            "probability": final_prob,
            "level": "高" if final_prob >= 70 else ("中" if final_prob >= 40 else "低"),
            "factors": factors if factors else ["需进一步了解"],
            "description": self._describe_probability(final_prob)
        }
    
    def _describe_probability(self, prob: int) -> str:
        """描述成交概率"""
        if prob >= 80:
            return "成交可能性很高，是重点跟进对象"
        elif prob >= 60:
            return "成交可能性较高，需要持续跟进保持势头"
        elif prob >= 40:
            return "成交可能性中等，需要挖掘更多信息"
        elif prob >= 20:
            return "成交可能性较低，需要分析障碍因素"
        else:
            return "成交可能性很低，建议评估是否值得继续投入"
    
    def _generate_strategy(self, personality: Dict, concerns: Dict, decision_speed: Dict) -> Dict[str, Any]:
        """生成沟通策略"""
        ptype = personality.get("type", "分析型")
        top_concern = concerns.get("top_priority", "品质")
        
        # 根据性格选择策略
        personality_strategies = {
            PersonalityType.ANALYTICAL: {
                "style": "顾问型",
                "do": ["提供详细数据和技术参数", "做专业的对比分析表", "安排产品演示", "给足决策时间"],
                "dont": ["夸大其词", "催促决策", "只谈价格"]
            },
            PersonalityType.DECISIVE: {
                "style": "直接型",
                "do": ["直接给出方案和结论", "快速响应需求", "适当给些优惠促成", "简化流程"],
                "dont": ["绕弯子", "过度解释", "反复确认"]
            },
            PersonalityType.HESITANT: {
                "style": "引导型",
                "do": ["多给成功案例增强信心", "适当制造紧迫感", "分步骤引导决策", "提供试用体验"],
                "dont": ["施加太大压力", "频繁催促", "否定客户顾虑"]
            },
            PersonalityType.RELATIONSHIP: {
                "style": "关系型",
                "do": ["先建立信任关系", "强调长期合作价值", "个性化服务", "保持真诚沟通"],
                "dont": ["过度推销", "急于求成", "过于商业化"]
            }
        }
        
        base_strategy = personality_strategies.get(ptype, personality_strategies[PersonalityType.ANALYTICAL])
        
        # 根据关注点调整
        concern_adjustments = {
            ConcernType.PRICE: ["强调性价比和投资回报", "提供优惠方案"],
            ConcernType.QUALITY: ["突出产品技术优势", "提供质量保证"],
            ConcernType.SERVICE: ["强调售后服务承诺", "展示服务案例"],
            ConcernType.BRAND: ["展示品牌实力和口碑", "提供权威背书"]
        }
        
        # 根据决策速度调整
        speed_adjustments = {
            "快": ["趁热打铁，抓紧推进", "可以适当让步促成"],
            "中": ["保持正常跟进节奏", "按部就班推进"],
            "慢": ["耐心维护，定期关心", "提供更多信息辅助决策"]
        }
        
        return {
            "style": base_strategy["style"],
            "recommended_actions": base_strategy["do"] + concern_adjustments.get(top_concern, []),
            "avoid_actions": base_strategy["dont"],
            "follow_up_tips": speed_adjustments.get(decision_speed.get("speed", "中"), speed_adjustments["中"]),
            "suggested_topics": self._suggest_topics(ptype, top_concern)
        }
    
    def _suggest_topics(self, personality: str, concern: str) -> List[str]:
        """建议话题"""
        topics = []
        
        if personality == PersonalityType.ANALYTICAL:
            topics.extend(["行业数据分析报告", "竞品对比资料", "技术白皮书"])
        elif personality == PersonalityType.DECISIVE:
            topics.extend(["快速解决方案", "限时优惠", "成功案例概览"])
        elif personality == PersonalityType.HESITANT:
            topics.extend(["客户成功案例", "试用体验安排", "分期付款方案"])
        elif personality == PersonalityType.RELATIONSHIP:
            topics.extend(["长期合作模式", "增值服务", "定制化方案"])
        
        if concern == ConcernType.PRICE:
            topics.append("投资回报计算器")
        elif concern == ConcernType.QUALITY:
            topics.append("产品质量认证")
        elif concern == ConcernType.SERVICE:
            topics.append("服务等级协议")
        elif concern == ConcernType.BRAND:
            topics.append("品牌合作案例")
        
        return topics[:5]
    
    def _generate_insights(self, customer: Dict, notes: List[Dict], personality: Dict, concerns: Dict) -> List[str]:
        """生成洞察"""
        insights = []
        
        # 基于客户基本信息
        if customer.get("budget_value", 0) > 100:
            insights.append("💰 大客户，重点关注，决策链可能较长")
        elif customer.get("budget_value", 0) > 50:
            insights.append("💵 中大型客户，值得投入精力跟进")
        
        # 基于跟进情况
        last_contact = customer.get("last_contact")
        if last_contact:
            try:
                days = (datetime.now() - datetime.fromisoformat(last_contact)).days
                if days > 14:
                    insights.append(f"⚠️ 已{days}天未跟进，建议尽快联系")
                elif days > 7:
                    insights.append(f"📅 已{days}天未跟进，记得保持联系")
            except:
                pass
        
        follow_count = customer.get("follow_up_count", 0)
        if follow_count == 0:
            insights.append("🆕 新客户，首次跟进印象很重要")
        elif follow_count >= 5:
            insights.append("🤝 老客户，已有多次深入沟通")
        
        # 基于性格
        ptype = personality.get("type", "")
        if ptype == "犹豫型":
            insights.append("🧐 客户决策谨慎，建议提供更多成功案例")
        elif ptype == "果断型":
            insights.append("⚡ 客户风格直接，沟通效率要高")
        
        # 基于沟通记录分析
        if len(notes) >= 3:
            insights.append("📝 已有多次深入沟通，是重点意向客户")
        elif len(notes) == 1:
            insights.append("💡 首次跟进，建议多了解客户需求")
        
        return insights
    
    def generate_report(self, customer_id: str) -> str:
        """生成画像分析报告（格式化文本）"""
        analysis = self.analyze(customer_id)
        
        if "error" in analysis:
            return f"❌ {analysis['error']}"
        
        lines = [
            f"🔍 客户画像分析 - {analysis['name']}",
            "=" * 40,
            "",
            f"【基本信息】",
            f"  公司：{analysis.get('company', '未知')}",
            f"  分析时间：{analysis.get('analyzed_at', '')[:10]}",
            "",
            f"【性格特征】{analysis['personality']['type']}",
            f"  {analysis['personality']['description']}",
            f"  置信度：{analysis['personality']['confidence']}%",
            f"  沟通关键词：{', '.join(analysis['personality'].get('evidence', [])) or '暂无'}",
            "",
            f"【核心关注】",
            f"  优先级：{' > '.join([c['type'] for c in analysis['concerns'].get('priority', [])]) or '未知'}",
            f"  {analysis['concerns'].get('description', '')}",
            "",
            f"【决策分析】",
            f"  决策层级：{analysis['decision_maker_level']['level']}",
            f"  {analysis['decision_maker_level']['description']}",
            f"  决策速度：{analysis['decision_speed']['speed']}",
            f"  预估周期：约{analysis['decision_speed'].get('estimated_days', 30)}天",
            "",
            f"【成交预测】{analysis['probability']['probability']}%（{analysis['probability']['level']}）",
            f"  {analysis['probability']['description']}",
            f"  有利因素：{', '.join(analysis['probability'].get('factors', []))}",
            "",
            f"【沟通策略】",
            f"  推荐风格：{analysis['strategy']['style']}",
            f"  建议动作：",
        ]
        
        for action in analysis['strategy'].get('recommended_actions', [])[:5]:
            lines.append(f"    • {action}")
        
        lines.extend([
            "",
            f"【跟进建议】",
            f"  {analysis['strategy'].get('follow_up_tips', '')}",
            ""
        ])
        
        # 洞察
        if analysis.get('insights'):
            lines.append("【关键洞察】")
            for insight in analysis['insights']:
                lines.append(f"  {insight}")
            lines.append("")
        
        return "\n".join(lines)


def quick_analyze(notes_text: str) -> Dict[str, Any]:
    """
    快速分析（无需加载客户数据）
    
    Args:
        notes_text: 沟通记录文本
        
    Returns:
        简要分析结果
    """
    profiler = CustomerProfiler()
    
    # 构建虚拟客户记录
    mock_notes = [{"content": notes_text, "created_at": datetime.now().isoformat()}]
    
    # 分析性格
    personality = profiler._analyze_personality(mock_notes)
    concerns = profiler._analyze_concerns(mock_notes)
    decision_speed = profiler._analyze_decision_speed(mock_notes)
    
    return {
        "personality": personality,
        "concerns": concerns,
        "decision_speed": decision_speed,
        "strategy": profiler._generate_strategy(personality, concerns, decision_speed)
    }


if __name__ == "__main__":
    # 测试代码
    import sys
    
    if len(sys.argv) > 1:
        customer_id = sys.argv[1]
        profiler = CustomerProfiler()
        print(profiler.generate_report(customer_id))
    else:
        # 快速分析测试
        test_text = "王总说这周要考虑一下，价格确实有点贵，之前对比了其他家的产品，不过对我们的品牌还是比较认可的，说下周给我答复"
        result = quick_analyze(test_text)
        print("快速分析结果:")
        print(f"性格：{result['personality']['type']}")
        print(f"关注点：{result['concerns'].get('top_priority', '未知')}")
        print(f"决策速度：{result['decision_speed']['speed']}")
        print(f"策略风格：{result['strategy']['style']}")
