# 销售客户管家

> 🤖 专为企业销售团队打造的智能客户管理助手

## 快速开始

### 安装

本技能基于 OpenClaw 框架开发，可直接安装使用：

1. 下载技能 ZIP 文件
2. 解压到 `.skills/sales-customer-manager/` 目录
3. 重启 Agent 即可使用

### 基本使用

```
/记录客户 王总，XX科技公司采购经理，预算80万
/查客户 王总
/今日跟进
/客户画像 王总
/话术 报价
/漏斗
```

## 目录结构

```
sales-customer-manager/
├── SKILL.md                 # 技能说明文档
├── README.md                # 本文件
├── scripts/                 # 核心脚本
│   ├── main.py             # 主入口
│   ├── customer_manager.py # 客户管理
│   ├── customer_profile.py # 客户画像
│   ├── followup_manager.py # 跟进管理
│   ├── script_templates.py # 话术模板
│   ├── funnel_analyzer.py  # 漏斗分析
│   ├── team_collaboration.py# 团队协作
│   ├── contract_manager.py # 合同管理
│   ├── channel_tracker.py  # 渠道追踪
│   ├── data_manager.py     # 数据管理
│   ├── mode_and_permission.py # 模式与权限
│   └── performance_and_notification.py # 业绩与通知
├── templates/              # 报告模板
│   ├── customer_report.md
│   ├── followup_report.md
│   ├── funnel_report.md
│   └── performance_report.md
├── data/                   # 数据存储（运行时生成）
│   ├── customers.json
│   ├── contracts.json
│   └── ...
└── references/             # 参考资料
    ├── customer_persona.md
    ├── objection_handling.md
    └── sales_templates.md
```

## 功能概览

| 模块 | 功能 | 触发命令 |
|------|------|----------|
| 客户档案 | 添加、查询、更新客户 | `/记录客户`, `/查客户` |
| 跟进提醒 | 任务管理、超时预警 | `/今日跟进`, `/提醒` |
| 客户画像 | 性格分析、成交预测 | `/客户画像`, `/分析` |
| 话术生成 | 场景话术、异议处理 | `/话术`, `/异议处理` |
| 销售漏斗 | 管道分析、瓶颈识别 | `/漏斗`, `/pipeline` |
| 合同管理 | 合同记录、回款跟踪 | `/合同`, `/回款` |
| 团队协作 | 客户分配、业绩排行 | `/团队`, `/分配` |
| 数据管理 | 导入导出、备份恢复 | `/导出`, `/导入` |

## API 接口

### Python API

```python
from main import SalesCustomerManager

# 创建实例
manager = SalesCustomerManager(user_id="user123", mode="personal")

# 添加客户
result = manager.add_customer({
    "name": "王总",
    "company": "XX科技",
    "budget": "80万"
})

# 查询客户
customers = manager.search_customers("王")

# 获取今日跟进
tasks = manager.get_today_followups()

# 生成话术
script = manager.get_script("初次接触")

# 查看漏斗
report = manager.get_funnel_report()
```

### 命令行接口

```bash
# 查看帮助
python scripts/main.py help

# 添加客户
python scripts/main.py add_customer "王总，XX科技"

# 搜索客户
python scripts/main.py search "王"

# 查看漏斗
python scripts/main.py funnel
```

## 数据格式

### 客户数据 (customers.json)

```json
{
  "id": "cust_20240425_001",
  "name": "王总",
  "company": "XX科技",
  "position": "采购经理",
  "phone": "13800138000",
  "email": "wang@xxtech.com",
  "budget": "80万",
  "budget_value": 80.0,
  "requirement": "500台电脑",
  "stage": "报价",
  "priority": "高",
  "decision_maker": "高",
  "purchase_intent": "强",
  "source": "线上推广",
  "competitors": ["竞品A", "竞品B"],
  "tags": ["大客户", "重点"],
  "notes": [],
  "assignee": "user123",
  "assignee_name": "张三",
  "created_at": "2024-04-25T10:00:00",
  "updated_at": "2024-04-25T10:00:00",
  "last_contact": "2024-04-24T15:30:00",
  "follow_up_count": 5
}
```

### 合同数据 (contracts.json)

```json
{
  "id": "contract_20240425_001",
  "contract_no": "HT202404001",
  "customer_id": "cust_20240425_001",
  "customer_name": "王总",
  "company": "XX科技",
  "amount": 80.0,
  "signed_date": "2024-04-25",
  "status": "已生效",
  "payment_terms": "3331",
  "created_by": "user123",
  "created_at": "2024-04-25T10:00:00"
}
```

## 配置选项

在 `data/settings.json` 中配置：

```json
{
  "mode": "personal",
  "notifications_enabled": true,
  "followup_reminder_days": 7,
  "overdue_threshold_days": 14,
  "public_pool_enabled": true,
  "collision_detection": true
}
```

## 隐私与合规

- ✅ 敏感信息自动脱敏
- ✅ 操作日志完整记录
- ✅ 数据导出需确认
- ✅ 支持数据备份恢复

## 常见问题

**Q: 如何切换个人/团队模式？**
A: 使用 `/个人模式` 或 `/团队模式` 命令切换

**Q: 数据保存在哪里？**
A: 数据保存在 `data/` 目录下，建议定期备份

**Q: 支持导入现有数据吗？**
A: 支持，使用 `/导入` 命令，可导入 JSON 或 CSV 格式

## 许可证

MIT License

## 版本历史

- **v1.0.2** (2025-01-15): 脚本优化与功能增强
- **v1.0.1** (2024-04-25): 新增团队协作、合同管理、数据管理等18个高级模块
- **v1.0.0** (2024-04-25): 初始版本，包含6大基础功能
