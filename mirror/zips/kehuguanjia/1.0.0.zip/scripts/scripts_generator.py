#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话术生成器 - 快速查找和生成销售话术
"""

import json
import os
import re

# 话术模板
SALES_TEMPLATES = {
    "初次接触": {
        "直接型": [
            "您好，我是XX公司的销售顾问张三。了解到贵公司在发展过程中可能需要一些支持，今天特意联系您，不知道是否方便聊几句？",
            "您好王总，我是XX公司的李经理。看到贵公司最近的发展动态，想跟您分享一些可能对您有帮助的信息。"
        ],
        "顾问型": [
            "王总您好，我是张三。我注意到咱们行业最近有几个趋势...（分享行业洞察）。想跟您请教一下，您这边目前在这方面有什么规划或者困扰吗？",
            "李总，我一直在关注咱们这个领域的发展。最近发现了一个很有意思的趋势...想跟您探讨一下这可能对咱们意味着什么。"
        ],
        "关系型": [
            "李总，上次交流受益匪浅。今天特意来跟您汇报一下我们最新的研究成果，同时也想听听您这段时间的新想法。",
            "王总您好，上次您分享的那个观点我一直记在心里。今天特意来拜访，想当面请教几个问题。"
        ]
    },
    "需求挖掘": {
        "spins": [
            "王总，您现在团队规模有多大？平时客户管理是怎么做的？",
            "那在客户量增加的情况下，您觉得最难处理的是什么？",
            "这种情况大概持续多久了？",
            "如果有一套方案能帮您解决这些问题，您觉得最希望改善的是哪方面？"
        ]
    },
    "报价": {
        "直接报价": [
            "王总，经过评估，我们这套方案的报价是XX万。这个价格包含了...（列举价值）。"
        ],
        "价值引导": [
            "王总，在给您报价之前，我想先确认一下，您最看重的是哪些方面？（等待回答）根据您刚才说的，我们推荐方案A。"
        ],
        "分层报价": [
            "王总，我们有三个方案供您选择：基础版XX万、标准版XX万、高级版XX万。您可以先了解一下。"
        ]
    },
    "异议处理": {
        "太贵": {
            "value_comparison": """王总，我理解您对价格的顾虑。咱们来算一笔账：
- 我们的设备比竞品贵10%，但故障率低50%
- 这意味着每年维修成本省3万
- 加上停机损失，一年至少省8万
- 设备用5年，相当于省40万
- 现在多花8万，后面省40万，您觉得值不值？""",
            "cost_breakdown": """王总，其实我也知道这笔投入不小。但您想想，这里面包含了...（分解各项成本）这样算下来，每个月的投入其实只有XX元，还不到您请一个助理月薪的三分之一。""",
            "roi": """王总，咱们买这个东西不是为了省钱，而是为了赚钱。您算过没有，如果这套方案能帮您提升20%的效率，意味着每个月多创造XX价值？投入是XX，回报是XX，ROI超过300%，您说值不值？"""
        },
        "考虑": {
            "direct": """王总，我理解您需要时间考虑。不过我想请教一下，除了今天聊的这些，还有什么您担心的吗？如果您告诉我真正顾虑的是什么，我可以针对性地给您更多信息，这样您做决定也会更踏实一些。""",
            "timeline": """王总，当然要慎重考虑。我想问一下，您大概什么时候会做这个决定？我这边可以给您准备一份详细的对比分析资料。同时也想提醒您，这个优惠到这个月底就结束了。"""
        },
        "竞品": {
            "compare": """李总，有对比是好事，买东西就是要货比三家。我想请教一下，您对比的主要是哪些方面？我们跟XX的区别主要在XX和XX，您看这些方面对您重要吗？我觉得最终选谁不重要，关键是选到最适合自己的。"""
        },
        "商量": {
            "strategy": """完全理解，这么重要的事情确实需要商量。我想请教一下：1. 最终拍板的是哪位？2. 商量的时候主要看哪些方面？3. 我这边有什么资料可以帮您跟领导汇报的？"""
        }
    },
    "促单": {
        "直接型": "王总，如果没有什么问题的话，我们今天就把合同签了吧。",
        "紧迫感": "王总，这个优惠价格到这个月底就结束了。如果您今天确定，我可以帮您申请保留这个优惠。",
        "假设成交": "王总，如果没有什么问题，我们就开始准备合同了？您这边合同审批需要多久？",
        "优惠促单": "王总，如果您今天能确定的话，我可以向公司申请额外的XX优惠，这是能给到您的最大支持了。",
        "风险转移": "王总，我们提供30天无理由退款保障。如果您使用后不满意，我们可以全额退款。您完全可以放心尝试。"
    },
    "维护": {
        "回访": "王总，上次合作后一直想找机会跟您沟通一下。不知道咱们这边的使用体验怎么样？有什么需要我们支持的吗？",
        "关系": "王总，最近看到一篇文章，觉得跟您分享可能会有价值...您有什么想法随时跟我交流。",
        "追加": "王总，最近我们推出了XX功能/产品，感觉跟您这边的需求很匹配。想找个时间跟您详细介绍一下，您方便吗？"
    }
}


def search_script(keyword: str, style: str = None) -> dict:
    """搜索话术模板"""
    keyword = keyword.lower()
    results = []
    
    # 匹配关键词
    for category, templates in SALES_TEMPLATES.items():
        if keyword in category.lower():
            results.append({"category": category, "templates": templates})
            continue
        
        # 深入搜索
        if isinstance(templates, dict):
            for sub_category, contents in templates.items():
                if keyword in sub_category.lower() or keyword in str(contents).lower():
                    results.append({"category": category, "sub_category": sub_category, "templates": contents})
    
    return results


def get_script(category: str, sub_category: str = None, style: str = None) -> dict:
    """获取指定话术"""
    templates = SALES_TEMPLATES.get(category, {})
    
    if sub_category and isinstance(templates, dict):
        templates = templates.get(sub_category, {})
    
    if style and isinstance(templates, dict):
        scripts = templates.get(style, [])
    elif isinstance(templates, dict):
        # 返回第一个子分类的内容
        first_key = list(templates.keys())[0] if templates else None
        scripts = templates.get(first_key, []) if first_key else []
    else:
        scripts = templates if isinstance(templates, list) else [templates]
    
    return {
        "category": category,
        "sub_category": sub_category,
        "scripts": scripts if isinstance(scripts, list) else [scripts]
    }


def format_script_response(category: str, script: str, style: str = None, tips: list = None) -> str:
    """格式化话术响应"""
    lines = [f"💬 {category}话术"]
    if style:
        lines.append(f"【风格】{style}\n")
    
    lines.append("【话术】")
    lines.append(script)
    
    if tips:
        lines.append("\n【要点】")
        for tip in tips:
            lines.append(f"✅ {tip}")
    
    return "\n".join(lines)


def get_objection_response(objection_type: str, method: str = None) -> dict:
    """获取异议处理话术"""
    objections = SALES_TEMPLATES.get("异议处理", {})
    
    # 匹配异议类型
    matched_key = None
    for key in objections.keys():
        if key in objection_type.lower():
            matched_key = key
            break
    
    if not matched_key:
        return {"error": f"未找到异议类型：{objection_type}"}
    
    templates = objections[matched_key]
    
    if method and method in templates:
        return {
            "type": matched_key,
            "method": method,
            "script": templates[method],
            "tips": ["承认问题，不回避", "用数据说话", "引导客户自己算账"]
        }
    elif method:
        return {
            "error": f"未找到方法：{method}",
            "available_methods": list(templates.keys())
        }
    else:
        # 返回所有方法
        return {
            "type": matched_key,
            "methods": list(templates.keys()),
            "recommended": list(templates.keys())[0] if templates else None,
            "scripts": templates
        }


# 入口函数
def handle_script_request(intent: str, params: dict) -> str:
    """处理话术请求"""
    keyword = params.get("keyword", "")
    style = params.get("style", "")
    objection = params.get("objection", "")
    method = params.get("method", "")
    
    if objection:
        # 异议处理
        response = get_objection_response(objection, method)
        if "error" in response:
            return response["error"]
        
        lines = [f"💬 异议处理话术 - \"{objection}\""]
        if response.get("method"):
            lines.append(f"【方法】{response['method']}")
        lines.append("\n【话术】")
        lines.append(response["script"])
        if response.get("tips"):
            lines.append("\n【要点】")
            for tip in response["tips"]:
                lines.append(f"✅ {tip}")
        return "\n".join(lines)
    
    elif keyword:
        # 搜索话术
        results = search_script(keyword)
        if not results:
            return f"未找到与「{keyword}」相关的话术，请尝试其他关键词。"
        
        lines = [f"🔍 搜索「{keyword}」相关话术：\n"]
        for result in results:
            lines.append(f"【{result['category']}】")
            if isinstance(result.get("templates"), dict):
                for sub, scripts in result["templates"].items():
                    lines.append(f"  - {sub}")
            elif isinstance(result.get("templates"), list):
                lines.append(f"  - {len(result['templates'])}条")
        return "\n".join(lines)
    
    else:
        # 返回可用类别
        lines = ["💬 话术生成器 - 可用场景：\n"]
        for category in SALES_TEMPLATES.keys():
            lines.append(f"  📌 {category}")
        lines.append("\n使用 /话术 [场景] 获取对应话术")
        lines.append("使用 /异议处理 [问题] 获取异议处理方案")
        return "\n".join(lines)


if __name__ == "__main__":
    # 测试
    print("=== 话术生成器测试 ===\n")
    
    # 测试异议处理
    result = get_objection_response("太贵了")
    print(f"异议类型: {result.get('type')}")
    print(f"可用方法: {result.get('methods')}")
    print()
    
    # 测试获取话术
    script = get_script("初次接触", style="直接型")
    print(f"场景: {script['category']}")
    print(f"话术: {script['scripts'][0]}")
