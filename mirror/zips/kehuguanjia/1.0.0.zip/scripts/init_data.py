#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
初始化示例数据
"""

import json
import os
from datetime import datetime, timedelta


def create_sample_data():
    """创建示例客户数据"""
    
    today = datetime.now()
    
    customers = [
        {
            "id": "cust_001",
            "name": "王建国",
            "company": "XX科技有限公司",
            "position": "采购总监",
            "phone": "138****5678",
            "email": "wangjg@xxtech.com",
            "requirement": "采购500台办公电脑，替换现有设备",
            "budget": "80万",
            "decision_power": "高",
            "intention": "强",
            "stage": "谈判",
            "last_contact": (today - timedelta(days=2)).isoformat(),
            "last_talk_summary": "价格78万，老板审批中",
            "next_follow_up": (today + timedelta(days=1)).isoformat(),
            "follow_suggestion": "询问老板审批进度，提醒优惠截止日期",
            "status": "等老板审批",
            "priority": "高",
            "tags": ["大客户", "长期合作"],
            "created_at": (today - timedelta(days=30)).isoformat(),
            "updated_at": today.isoformat(),
            "follow_up_count": 8,
            "notes": [
                {"date": (today - timedelta(days=30)).isoformat(), "content": "初次电话沟通，客户有明确采购需求"},
                {"date": (today - timedelta(days=25)).isoformat(), "content": "上门拜访，展示产品方案"},
                {"date": (today - timedelta(days=15)).isoformat(), "content": "发送详细报价单78万"},
                {"date": (today - timedelta(days=7)).isoformat(), "content": "客户反馈价格偏高，需要内部讨论"},
                {"date": (today - timedelta(days=2)).isoformat(), "content": "再次沟通，同意78万，需老板审批"}
            ]
        },
        {
            "id": "cust_002",
            "name": "李明",
            "company": "YY贸易集团",
            "position": "总经理",
            "phone": "139****1234",
            "email": "liming@yytrade.com",
            "requirement": "CRM系统采购",
            "budget": "50万",
            "decision_power": "高",
            "intention": "中",
            "stage": "需求确认",
            "last_contact": (today - timedelta(days=5)).isoformat(),
            "last_talk_summary": "发送产品手册，对比竞品中",
            "next_follow_up": (today + timedelta(days=2)).isoformat(),
            "follow_suggestion": "询问对比结果，突出差异化优势",
            "status": "对比竞品",
            "priority": "中",
            "tags": ["新客户"],
            "created_at": (today - timedelta(days=20)).isoformat(),
            "updated_at": today.isoformat(),
            "follow_up_count": 4,
            "notes": [
                {"date": (today - timedelta(days=20)).isoformat(), "content": "行业展会认识，有CRM需求"},
                {"date": (today - timedelta(days=15)).isoformat(), "content": "电话沟通需求，需求比较明确"},
                {"date": (today - timedelta(days=5)).isoformat(), "content": "发送产品资料和报价"}
            ]
        },
        {
            "id": "cust_003",
            "name": "张伟",
            "company": "ZZ实业集团",
            "position": "IT经理",
            "phone": "137****9876",
            "email": "zhangwei@zzgroup.com",
            "requirement": "服务器升级改造",
            "budget": "120万",
            "decision_power": "中",
            "intention": "弱",
            "stage": "初步接触",
            "last_contact": (today - timedelta(days=20)).isoformat(),
            "last_talk_summary": "初次电话，简单了解需求",
            "next_follow_up": None,
            "follow_suggestion": "需要持续跟进，了解更多需求细节",
            "status": "未明确意向",
            "priority": "低",
            "tags": ["长期跟进"],
            "created_at": (today - timedelta(days=25)).isoformat(),
            "updated_at": today.isoformat(),
            "follow_up_count": 1,
            "notes": [
                {"date": (today - timedelta(days=20)).isoformat(), "content": "行业论坛认识，交换名片"}
            ]
        },
        {
            "id": "cust_004",
            "name": "陈芳",
            "company": "AA电子科技",
            "position": "行政主管",
            "phone": "136****5432",
            "requirement": "办公设备采购",
            "budget": "30万",
            "decision_power": "低",
            "intention": "中",
            "stage": "报价",
            "last_contact": (today - timedelta(days=3)).isoformat(),
            "last_talk_summary": "已发报价，等待领导确认",
            "next_follow_up": (today + timedelta(days=4)).isoformat(),
            "follow_suggestion": "确认领导意见，解答疑问",
            "status": "等领导确认",
            "priority": "中",
            "tags": ["中小客户"],
            "created_at": (today - timedelta(days=15)).isoformat(),
            "updated_at": today.isoformat(),
            "follow_up_count": 3,
            "notes": [
                {"date": (today - timedelta(days=15)).isoformat(), "content": "客户主动来电咨询"},
                {"date": (today - timedelta(days=10)).isoformat(), "content": "上门测量和方案沟通"},
                {"date": (today - timedelta(days=3)).isoformat(), "content": "发送正式报价30万"}
            ]
        },
        {
            "id": "cust_005",
            "name": "刘强",
            "company": "BB制造有限公司",
            "position": "采购经理",
            "phone": "135****8765",
            "email": "liuqiang@bbmade.com",
            "requirement": "生产线设备采购",
            "budget": "200万",
            "decision_power": "高",
            "intention": "强",
            "stage": "成交",
            "last_contact": (today - timedelta(days=1)).isoformat(),
            "last_talk_summary": "合同已签，预付款已到账",
            "next_follow_up": (today + timedelta(days=7)).isoformat(),
            "follow_suggestion": "安排生产和交付事宜",
            "status": "合同签订",
            "priority": "高",
            "tags": ["大客户", "成交"],
            "created_at": (today - timedelta(days=60)).isoformat(),
            "updated_at": today.isoformat(),
            "follow_up_count": 15,
            "notes": [
                {"date": (today - timedelta(days=60)).isoformat(), "content": "项目招标启动"},
                {"date": (today - timedelta(days=45)).isoformat(), "content": "参与投标"},
                {"date": (today - timedelta(days=30)).isoformat(), "content": "中标通知"},
                {"date": (today - timedelta(days=10)).isoformat(), "content": "商务谈判"},
                {"date": (today - timedelta(days=1)).isoformat(), "content": "合同签订"}
            ]
        }
    ]
    
    return customers


def save_data():
    """保存示例数据"""
    os.makedirs("data", exist_ok=True)
    
    customers = create_sample_data()
    
    with open("data/customers.json", "w", encoding="utf-8") as f:
        json.dump(customers, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 已创建 {len(customers)} 条示例客户数据")
    print("📁 数据文件: data/customers.json")
    
    # 统计
    stage_counts = {}
    for c in customers:
        stage = c.get("stage", "未知")
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
    
    print("\n📊 各阶段客户数：")
    for stage, count in stage_counts.items():
        print(f"  {stage}: {count}")


if __name__ == "__main__":
    save_data()
