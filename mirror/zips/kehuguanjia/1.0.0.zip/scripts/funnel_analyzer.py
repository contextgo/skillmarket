#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
销售漏斗分析脚本
"""

import json
from typing import Dict, List
from datetime import datetime


class FunnelAnalyzer:
    """销售漏斗分析器"""
    
    # 销售阶段定义
    STAGES = [
        "潜在客户",
        "初步接触", 
        "需求确认",
        "报价",
        "谈判",
        "成交"
    ]
    
    def __init__(self, customers: List[Dict]):
        self.customers = customers
    
    def count_by_stage(self) -> Dict[str, int]:
        """统计各阶段客户数量"""
        counts = {stage: 0 for stage in self.STAGES}
        
        for customer in self.customers:
            stage = customer.get("stage", "潜在客户")
            if stage in counts:
                counts[stage] += 1
            else:
                counts["潜在客户"] += 1
        
        return counts
    
    def calculate_conversion_rates(self, stage_counts: Dict[str, int]) -> Dict[str, str]:
        """计算阶段转化率"""
        rates = {}
        
        for i in range(len(self.STAGES) - 1):
            current = self.STAGES[i]
            next_stage = self.STAGES[i + 1]
            
            current_count = stage_counts.get(current, 0)
            next_count = stage_counts.get(next_stage, 0)
            
            if current_count > 0:
                rate = (next_count / current_count) * 100
                rates[f"{current}→{next_stage}"] = f"{rate:.0f}%"
            else:
                rates[f"{current}→{next_stage}"] = "0%"
        
        return rates
    
    def estimate_pipeline_value(self) -> Dict[str, any]:
        """估算管道价值"""
        active_value = 0
        for customer in self.customers:
            stage = customer.get("stage", "潜在客户")
            budget_str = customer.get("budget", "0")
            
            # 解析预算
            try:
                budget = float(budget_str.replace("万", "").replace("元", "").replace(",", ""))
                if "万" not in budget_str and budget < 1000:
                    budget *= 10000  # 元转万
            except:
                budget = 0
            
            # 只计算活跃阶段的客户
            if stage in ["报价", "谈判"]:
                active_value += budget
        
        return {
            "active_pipeline": f"{active_value}万",
            "estimated_deals": len([c for c in self.customers if c.get("stage") == "谈判"]),
            "estimated_value": f"{active_value * 0.3:.0f}-{active_value * 0.5:.0f}万"  # 30%-50%转化
        }
    
    def get_recommendations(self, stage_counts: Dict[str, int], conversion_rates: Dict[str, str]) -> List[str]:
        """生成优化建议"""
        recommendations = []
        
        # 分析瓶颈
        low_conversion = []
        for key, rate in conversion_rates.items():
            try:
                rate_value = float(rate.replace("%", ""))
                if rate_value < 50:
                    parts = key.split("→")
                    low_conversion.append((parts[0], parts[1], rate_value))
            except:
                pass
        
        if low_conversion:
            recommendations.append(f"⚠️ {low_conversion[0][0]}→{low_conversion[0][1]} 转化率较低({low_conversion[0][2]:.0f}%)，建议加强此阶段跟进")
        
        # 分析客户分布
        total = sum(stage_counts.values())
        if total == 0:
            recommendations.append("📝 暂无客户数据，建议先添加客户信息")
            return recommendations
        
        potential = stage_counts.get("潜在客户", 0)
        if potential / total > 0.5:
            recommendations.append("📝 潜在客户较多，建议加强转化工作")
        
        # 成交建议
        deal_count = stage_counts.get("成交", 0)
        if deal_count == 0:
            recommendations.append("💡 暂无成交客户，重点关注谈判阶段客户，推进转化")
        
        return recommendations if recommendations else ["✅ 各阶段分布正常，保持跟进节奏"]
    
    def generate_report(self) -> str:
        """生成漏斗报告"""
        stage_counts = self.count_by_stage()
        conversion_rates = self.calculate_conversion_rates(stage_counts)
        pipeline = self.estimate_pipeline_value()
        recommendations = self.get_recommendations(stage_counts, conversion_rates)
        
        # 构建报告
        lines = ["📊 销售漏斗看板\n"]
        
        # 阶段统计
        lines.append("【各阶段客户数】")
        max_count = max(stage_counts.values()) if stage_counts.values() else 1
        
        stage_labels = {
            "潜在客户": "潜在客户",
            "初步接触": "初步接触",
            "需求确认": "需求确认",
            "报价": "报价阶段",
            "谈判": "谈判阶段",
            "成交": "成交"
        }
        
        for stage in self.STAGES:
            count = stage_counts[stage]
            bar_length = int(count / max_count * 12) if max_count > 0 else 0
            bar = "█" * bar_length + "░" * (12 - bar_length)
            label = stage_labels.get(stage, stage)
            lines.append(f"{label:　<8} {bar} {count}人")
        
        lines.append("")
        
        # 转化率
        lines.append("【转化率】")
        for key, rate in conversion_rates.items():
            lines.append(f"  {key}：{rate}")
        
        lines.append("")
        
        # 预测
        lines.append("【预测】")
        lines.append(f"  活跃管道：{pipeline['active_pipeline']}")
        lines.append(f"  预计成交：{pipeline['estimated_deals']}单")
        lines.append(f"  预计金额：{pipeline['estimated_value']}")
        
        lines.append("")
        
        # 建议
        lines.append("【建议】")
        for rec in recommendations:
            lines.append(f"  {rec}")
        
        return "\n".join(lines)


def format_funnel_visual(stage_counts: Dict[str, int]) -> str:
    """格式化漏斗可视化"""
    max_count = max(stage_counts.values()) if stage_counts.values() else 1
    
    lines = ["📊 销售漏斗\n"]
    
    for stage in FunnelAnalyzer.STAGES:
        count = stage_counts[stage]
        # 计算宽度（漏斗形状）
        width = int(20 * count / max_count) if max_count > 0 else 0
        if width < 2:
            width = 2
        bar = "█" * width
        lines.append(f"{stage:　<6} {bar:　<20} {count}")
    
    return "\n".join(lines)


if __name__ == "__main__":
    # 测试数据
    test_customers = [
        {"name": "王总", "stage": "潜在客户", "budget": "80万"},
        {"name": "李总", "stage": "初步接触", "budget": "50万"},
        {"name": "张总", "stage": "需求确认", "budget": "100万"},
        {"name": "赵总", "stage": "报价", "budget": "60万"},
        {"name": "刘总", "stage": "谈判", "budget": "120万"},
        {"name": "陈总", "stage": "成交", "budget": "80万"},
    ]
    
    analyzer = FunnelAnalyzer(test_customers)
    print(analyzer.generate_report())
