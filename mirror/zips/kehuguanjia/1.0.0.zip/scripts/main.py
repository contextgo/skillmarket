#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
销售客户管家 - 主脚本
提供客户档案管理、跟进提醒、客户画像分析、话术生成等功能
"""

import json
import re
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

# 数据存储路径
DATA_DIR = "data"
CUSTOMERS_FILE = os.path.join(DATA_DIR, "customers.json")

class CustomerManager:
    """客户管理核心类"""
    
    def __init__(self):
        self.customers = self._load_customers()
    
    def _load_customers(self) -> List[Dict]:
        """加载客户数据"""
        if os.path.exists(CUSTOMERS_FILE):
            try:
                with open(CUSTOMERS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _save_customers(self):
        """保存客户数据"""
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(CUSTOMERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.customers, f, ensure_ascii=False, indent=2)
    
    def add_customer(self, info: Dict) -> Dict:
        """添加新客户"""
        customer = {
            "id": f"cust_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "follow_up_count": 0,
            "last_contact": None,
            "next_follow_up": None,
            "stage": "潜在客户",
            "tags": [],
            "notes": [],
            "reminders": []
        }
        customer.update(info)
        self.customers.append(customer)
        self._save_customers()
        return customer
    
    def update_customer(self, customer_id: str, updates: Dict) -> Optional[Dict]:
        """更新客户信息"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                self.customers[i].update(updates)
                self.customers[i]["updated_at"] = datetime.now().isoformat()
                self._save_customers()
                return self.customers[i]
        return None
    
    def search_customers(self, keyword: str) -> List[Dict]:
        """模糊搜索客户"""
        if not keyword:
            return self.customers
        
        keyword_lower = keyword.lower()
        results = []
        for customer in self.customers:
            # 搜索多个字段
            search_fields = ["name", "company", "position", "requirement", "phone", "email"]
            for field in search_fields:
                value = customer.get(field, "")
                if value and keyword_lower in str(value).lower():
                    results.append(customer)
                    break
        return results
    
    def get_customer(self, identifier: str) -> Optional[Dict]:
        """获取单个客户"""
        for customer in self.customers:
            if customer.get("id") == identifier or customer.get("name") == identifier:
                return customer
        return None
    
    def delete_customer(self, customer_id: str) -> bool:
        """删除客户"""
        for i, customer in enumerate(self.customers):
            if customer.get("id") == customer_id or customer.get("name") == customer_id:
                self.customers.pop(i)
                self._save_customers()
                return True
        return False


class CustomerAnalyzer:
    """客户画像分析类"""
    
    @staticmethod
    def analyze(notes: List[Dict]) -> Dict:
        """分析客户画像"""
        if not notes:
            return {
                "personality": "未知",
                "concerns": [],
                "decision_speed": "未知",
                "probability": "未知",
                "strategy": []
            }
        
        # 简单分析逻辑
        text = " ".join([n.get("content", "") for n in notes])
        
        # 性格分析
        personality = "分析型"
        if any(w in text for w in ["赶紧", "快", "马上", "尽快"]):
            personality = "果断型"
        elif any(w in text for w in ["考虑", "想想", "商量"]):
            personality = "犹豫型"
        elif any(w in text for w in ["信任", "关系", "朋友"]):
            personality = "关系型"
        
        # 关注点分析
        concerns = []
        if any(w in text for w in ["价格", "贵", "便宜", "费用"]):
            concerns.append("价格")
        if any(w in text for w in ["质量", "品质", "好"]):
            concerns.append("品质")
        if any(w in text for w in ["服务", "售后", "保障"]):
            concerns.append("服务")
        
        # 决策速度
        decision_speed = "中"
        if any(w in text for w in ["下周", "月底", "很快"]):
            decision_speed = "快"
        elif any(w in text for w in ["慢慢", "再看看", "不着急"]):
            decision_speed = "慢"
        
        # 成交概率（简化计算）
        probability = 50
        if "预算" in str(notes):
            probability += 15
        if "有决策权" in text or "老板" in text:
            probability += 15
        if any(w in text for w in ["需求", "需要", "想"]):
            probability += 10
        probability = min(probability, 95)
        
        return {
            "personality": personality,
            "concerns": concerns if concerns else ["其他"],
            "decision_speed": decision_speed,
            "probability": probability,
            "strategy": CustomerAnalyzer._generate_strategy(personality, concerns)
        }
    
    @staticmethod
    def _generate_strategy(personality: str, concerns: List) -> List[str]:
        """生成沟通策略"""
        strategies = {
            "分析型": [
                "多提供技术参数对比表",
                "用数据支撑观点",
                "给足决策时间",
                "可以安排产品演示"
            ],
            "果断型": [
                "直接给出方案",
                "不要绕弯子",
                "快速响应需求",
                "适当给些优惠促成"
            ],
            "犹豫型": [
                "多给成功案例",
                "增强购买信心",
                "适当制造紧迫感",
                "分解决策步骤"
            ],
            "关系型": [
                "先建立信任关系",
                "强调长期合作价值",
                "不要过度推销",
                "提供个性化服务"
            ]
        }
        return strategies.get(personality, strategies["分析型"])


class FunnelAnalyzer:
    """销售漏斗分析类"""
    
    STAGES = ["潜在客户", "初步接触", "需求确认", "报价", "谈判", "成交"]
    
    def __init__(self, customers: List[Dict]):
        self.customers = customers
    
    def analyze(self) -> Dict:
        """分析销售漏斗"""
        stage_counts = {stage: 0 for stage in self.STAGES}
        
        for customer in self.customers:
            stage = customer.get("stage", "潜在客户")
            if stage in stage_counts:
                stage_counts[stage] += 1
            else:
                stage_counts["潜在客户"] += 1
        
        # 计算转化率
        conversion_rates = {}
        for i in range(len(self.STAGES) - 1):
            current = self.STAGES[i]
            next_stage = self.STAGES[i + 1]
            current_count = stage_counts.get(current, 0)
            next_count = stage_counts.get(next_stage, 0)
            
            if current_count > 0:
                rate = (next_count / current_count) * 100
                conversion_rates[f"{current}→{next_stage}"] = f"{rate:.0f}%"
            else:
                conversion_rates[f"{current}→{next_stage}"] = "0%"
        
        # 预测成交
        deal_count = stage_counts.get("成交", 0)
        pipeline_value = sum([
            int(c.get("budget", "0").replace("万", "").replace("元", "").replace(",", "") or "0")
            for c in self.customers
            if c.get("stage") in ["报价", "谈判"]
        ])
        
        return {
            "stage_counts": stage_counts,
            "conversion_rates": conversion_rates,
            "prediction": {
                "deal_count": f"{deal_count}-{deal_count + 2}单",
                "estimated_value": f"{pipeline_value}-{pipeline_value * 2}万"
            }
        }


class FollowUpManager:
    """跟进管理类"""
    
    def __init__(self, customers: List[Dict]):
        self.customers = customers
    
    def get_today_followups(self) -> Dict:
        """获取今日跟进任务"""
        today = datetime.now().date()
        urgent = []
        normal = []
        overdue = []
        
        for customer in self.customers:
            # 检查是否超期
            last_contact = customer.get("last_contact")
            if last_contact:
                try:
                    last_date = datetime.fromisoformat(last_contact).date()
                    days_since = (today - last_date).days
                    if days_since > 14:
                        overdue.append({
                            "name": customer.get("name"),
                            "company": customer.get("company"),
                            "days": days_since,
                            "last_talk": customer.get("last_talk_summary", "无记录")
                        })
                except:
                    pass
            
            # 检查今日任务
            next_follow = customer.get("next_follow_up")
            if next_follow:
                try:
                    next_date = datetime.fromisoformat(next_follow).date()
                    if next_date <= today:
                        item = {
                            "name": customer.get("name"),
                            "company": customer.get("company"),
                            "last_talk": customer.get("last_talk_summary", "无记录"),
                            "status": customer.get("status", "待跟进"),
                            "suggestion": customer.get("follow_suggestion", "主动联系客户")
                        }
                        if customer.get("priority") == "高":
                            urgent.append(item)
                        else:
                            normal.append(item)
                except:
                    pass
        
        return {
            "urgent": urgent,
            "normal": normal,
            "overdue": overdue
        }


class ScriptGenerator:
    """话术生成类"""
    
    TEMPLATES = {
        "太贵了": {
            "value_comparison": """王总，我理解您对价格的顾虑。咱们来算一笔账：
- 我们的设备比竞品贵10%，但故障率低50%
- 这意味着每年维修成本省3万
- 加上停机损失，一年至少省8万
- 设备用5年，相当于省40万
- 现在多花8万，后面省40万，您觉得值不值？""",
            "cost_breakdown": """王总，其实我也知道这笔投入不小。但您想想，这里面包含了...
（分解各项成本）
这样算下来，每个月的投入其实只有XX元，还不到您请一个助理月薪的三分之一。""",
            "roi": """王总，咱们买这个东西不是为了省钱，而是为了赚钱。您算过没有，
如果这套方案能帮您提升20%的效率，意味着每个月多创造XX价值？
投入是XX，回报是XX，ROI超过300%，您说值不值？"""
        },
        "考虑": {
            "direct": """王总，我理解您需要时间考虑。不过我想请教一下，
除了今天聊的这些，还有什么您担心的吗？
如果您告诉我真正顾虑的是什么，我可以针对性地给您更多信息，
这样您做决定也会更踏实一些。""",
            "timeline": """王总，当然要慎重考虑。我想问一下，您大概什么时候会做这个决定？
我这边可以给您准备一份详细的对比分析资料，您在考虑的时候可以作为参考。
同时也想提醒您，这个优惠到这个月底就结束了。"""
        },
        "竞品": {
            "compare": """李总，有对比是好事，买东西就是要货比三家。我想请教一下，
您对比的主要是哪些方面？
我们跟XX的区别主要在XX和XX，您看这些方面对您重要吗？
我觉得最终选谁不重要，关键是选到最适合自己的。"""
        }
    }
    
    @classmethod
    def get_script(cls, scenario: str, customer_profile: Optional[Dict] = None) -> Dict:
        """获取话术"""
        scenario = scenario.lower()
        
        # 匹配场景
        for key, templates in cls.TEMPLATES.items():
            if key in scenario:
                # 根据客户画像选择合适的模板
                if customer_profile:
                    personality = customer_profile.get("personality", "分析型")
                    if personality == "分析型":
                        method = "value_comparison"
                    elif personality == "关系型":
                        method = "cost_breakdown"
                    else:
                        method = list(templates.keys())[0]
                else:
                    method = list(templates.keys())[0]
                
                return {
                    "scenario": key,
                    "method": method,
                    "script": templates[method],
                    "key_points": [
                        "承认问题，不回避",
                        "用数据说话",
                        "引导客户自己算账"
                    ]
                }
        
        return {
            "scenario": scenario,
            "script": "请描述您需要的话术场景，我会为您生成。",
            "key_points": []
        }


# 工具函数：解析用户输入
def parse_customer_info(text: str) -> Dict:
    """从用户输入中解析客户信息"""
    info = {}
    
    # 姓名（通常在句首或"记录一下"后）
    name_match = re.search(r'[，,]([^，,，]+?)(?:，|,|$)', text)
    if name_match:
        potential_name = name_match.group(1).strip()
        if len(potential_name) <= 5:
            info["name"] = potential_name
    
    # 公司
    company_patterns = [
        r'([^\s公司]+公司)',
        r'([^\s企业]+企业)',
        r'([^\s集团]+集团)'
    ]
    for pattern in company_patterns:
        match = re.search(pattern, text)
        if match:
            info["company"] = match.group(1)
            break
    
    # 职位
    position_match = re.search(r'([^\s]+(?:经理|总监|总经理|副总|主管|负责人|老板))', text)
    if position_match:
        info["position"] = position_match.group(1)
    
    # 预算
    budget_match = re.search(r'(\d+)\s*(?:万|元|千)', text)
    if budget_match:
        amount = int(budget_match.group(1))
        unit = budget_match.group(2)
        info["budget"] = f"{amount}{unit}" if "万" in unit or "千" in unit else f"{amount/10000}万"
    
    # 需求
    need_match = re.search(r'(?:需求|采购|想买|要|需要).*?(\d+.+)', text)
    if need_match:
        info["requirement"] = need_match.group(1).strip()
    
    # 下次跟进
    date_patterns = [
        (r'下周[一二三四五六日]', _parse_weekday),
        (r'(\d+)月(\d+)日', _parse_date),
        (r'今天|明天|后天', _parse_relative)
    ]
    for pattern, parser in date_patterns:
        match = re.search(pattern, text)
        if match:
            info["next_follow_up"] = parser(match)
            break
    
    return info


def _parse_weekday(match) -> str:
    """解析下周几"""
    weekdays = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 7, "天": 7}
    weekday = weekdays.get(match.group(0)[-1], 0)
    today = datetime.now()
    days_ahead = weekday - today.weekday()
    if days_ahead <= 0:
        days_ahead += 7
    target_date = today + timedelta(days=days_ahead)
    return target_date.isoformat()


def _parse_date(match) -> str:
    """解析月日"""
    month, day = int(match.group(1)), int(match.group(2))
    year = datetime.now().year
    return datetime(year, month, day).isoformat()


def _parse_relative(match) -> str:
    """解析相对日期"""
    text = match.group(0)
    if "明天" in text:
        delta = 1
    elif "后天" in text:
        delta = 2
    else:
        delta = 0
    return (datetime.now() + timedelta(days=delta)).isoformat()


# 格式化输出
def format_customer_card(customer: Dict) -> str:
    """格式化客户卡片"""
    card = ["✅ 已记录客户档案\n"]
    card.append(f"【客户】{customer.get('name', '未知')}")
    card.append(f"【公司】{customer.get('company', '未知')}")
    card.append(f"【职位】{customer.get('position', '未知')}")
    
    if customer.get('requirement'):
        card.append(f"【需求】{customer.get('requirement')}")
    if customer.get('budget'):
        card.append(f"【预算】{customer.get('budget')}")
    if customer.get('decision_power'):
        card.append(f"【决策权】{customer.get('decision_power')}")
    if customer.get('intention'):
        card.append(f"【意向】{customer.get('intention')}")
    if customer.get('next_follow_up'):
        card.append(f"【下一步】{customer.get('next_follow_up')}")
    if customer.get('next_follow_up'):
        card.append("【提醒】已设置跟进提醒")
    
    return "\n".join(card)


def format_followup_list(followups: Dict) -> str:
    """格式化跟进清单"""
    lines = ["📅 今日跟进清单\n"]
    
    if followups.get("urgent"):
        lines.append("【紧急】")
        for item in followups["urgent"]:
            lines.append(f"- {item['name']} - {item['company']}")
            lines.append(f"  上次：{item.get('last_talk', '无记录')}")
            lines.append(f"  状态：{item.get('status', '待跟进')}")
            lines.append(f"  建议：{item.get('suggestion', '')}")
        lines.append("")
    
    if followups.get("normal"):
        lines.append("【常规】")
        for item in followups["normal"]:
            lines.append(f"- {item['name']} - {item['company']}")
            lines.append(f"  上次：{item.get('last_talk', '无记录')}")
            lines.append(f"  状态：{item.get('status', '待跟进')}")
            lines.append(f"  建议：{item.get('suggestion', '')}")
        lines.append("")
    
    if followups.get("overdue"):
        lines.append("⚠️ 超时预警")
        for item in followups["overdue"]:
            lines.append(f"- {item['name']} - {item['company']}，已超{item['days']}天未联系，建议尽快跟进")
    
    return "\n".join(lines)


def format_persona_analysis(customer: Dict, analysis: Dict) -> str:
    """格式化画像分析"""
    lines = [f"🔍 客户画像分析 - {customer.get('name', '未知')}\n"]
    lines.append(f"【性格特征】{analysis.get('personality', '未知')}")
    lines.append("【核心关注】" + " > ".join(analysis.get('concerns', [])))
    lines.append(f"【成交预测】{analysis.get('probability', '?')}%")
    lines.append("【沟通建议】")
    for i, s in enumerate(analysis.get('strategy', []), 1):
        lines.append(f"{i}. {s}")
    return "\n".join(lines)


def format_funnel(funnel_data: Dict) -> str:
    """格式化漏斗数据"""
    lines = ["📊 销售漏斗看板\n"]
    lines.append("【各阶段客户数】")
    
    max_count = max(funnel_data["stage_counts"].values()) if funnel_data["stage_counts"].values() else 1
    
    stage_map = {
        "潜在客户": "潜在客户",
        "初步接触": "初步接触",
        "需求确认": "需求确认",
        "报价": "报价阶段",
        "谈判": "谈判阶段",
        "成交": "成交"
    }
    
    for stage in FunnelAnalyzer.STAGES:
        count = funnel_data["stage_counts"].get(stage, 0)
        bar = "█" * int(count / max_count * 10) if max_count > 0 else ""
        lines.append(f"{stage_map.get(stage, stage):　<8} {bar} {count}人")
    
    lines.append("\n【转化率】")
    for stage, rate in funnel_data["conversion_rates"].items():
        lines.append(f"{stage}：{rate}")
    
    lines.append("\n【预测】")
    pred = funnel_data["prediction"]
    lines.append(f"- 本月预计成交：{pred['deal_count']}")
    lines.append(f"- 预计金额：{pred['estimated_value']}")
    lines.append("- 建议：关注报价和谈判阶段客户，重点推进转化")
    
    return "\n".join(lines)


# 主入口（测试用）
if __name__ == "__main__":
    print("销售客户管家 v1.0")
    print("使用 skill_load 工具加载此技能后，通过对话交互使用")
