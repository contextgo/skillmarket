---
name: pqi-evaluation
description: This skill should be used when users need to evaluate pavement quality according to JTG 5210-2018 standard, calculate PQI (Pavement Quality Index) and its sub-indicators (PCI, RQI, RDI, SRI, PBI, PSSI), generate evaluation reports, or analyze road condition data. It handles asphalt concrete and cement concrete pavements for various road grades.
---

# PQI 路面技术状况评价 Skill

依据《公路技术状况评定标准》JTG 5210-2018，自动计算路面技术状况指数 PQI 及其各分项指标。

## 功能概述

本 Skill 提供完整的路面技术状况评价能力：

1. **PQI 综合评价** - 计算路面技术状况综合指数
2. **分项指标计算**:
   - PCI (路面损坏状况指数)
   - RQI (路面行驶质量指数) 
   - RDI (路面车辙深度指数) - 仅沥青路面
   - SRI (路面抗滑性能指数)
   - PBI (路面跳车指数)
   - PSSI (路面结构强度指数) - 不参与 PQI 计算
3. **自动生成报告** - 输出格式化的评定报告

## 支持的路面类型和等级

| 路面类型 | 公路等级 | 参与计算的指标 |
|---------|---------|---------------|
| 沥青混凝土 | 高速/一级 | PCI, RQI, RDI, PBI, SRI |
| 沥青混凝土 | 二级/三级/四级 | PCI, RQI |
| 水泥混凝土 | 高速/一级 | PCI, RQI, PBI, SRI |
| 水泥混凝土 | 二级/三级/四级 | PCI, RQI |

## 使用方法

### 方式一：使用脚本直接计算

```bash
python scripts/pqi_evaluator.py [输入CSV路径]
```

如果不提供路径，默认使用 `assets/PQI输入数据模板.csv`

### 方式二：作为模块导入

```python
from scripts.pqi_evaluator import PQIEvaluator

evaluator = PQIEvaluator()
raw_data = evaluator.load_csv_data("data.csv")
params = evaluator.parse_input_data(raw_data)
results = evaluator.run_evaluation(params)
report_text, output_path = evaluator.generate_report()
```

## 输入数据格式

CSV 文件格式（参考 `assets/PQI输入数据模板.csv`）：

| 字段 | 数值 | 单位 | 备注 |
|-----|------|-----|------|
| 路线名称 | G318 | | |
| 桩号段 | K1200+000~K1201+000 | | |
| 路面类型 | 沥青混凝土 | | 或"水泥混凝土" |
| 公路等级 | 高速公路 | | |
| 检测长度 | 1000 | m | |
| 行车道宽度 | 3.75 | m | |
| 国际平整度指数IRI | 2.5 | m/km | RQI用 |
| 平均车辙深度RD | 8 | mm | RDI用(沥青) |
| 横向力系数SFC | 45 | | SRI用 |
| 龟裂_轻度 | 10 | m² | PCI损坏数据 |
| 龟裂_中度 | 5 | m² | PCI损坏数据 |
| ... | ... | ... | ... |

## 输出结果

评价报告包含：
- 工程基本信息
- PQI 权重系数配置
- 各分项指标详细计算过程
- PQI 综合计算结果和等级评定
- ASCII 条形图可视化
- 养护对策建议

## 评价等级标准

| 等级 | 分值范围 | 养护对策 |
|-----|---------|---------|
| 优 | 90~100 | 日常养护 |
| 良 | 80~89 | 预防性养护 |
| 中 | 70~79 | 中修罩面 |
| 次 | 60~69 | 大修工程 |
| 差 | 0~59 | 改扩建/重建 |

## 文件结构

```
pqi-evaluation/
├── SKILL.md                    # 本文件
├── scripts/
│   ├── pqi_evaluator.py        # 主评价程序
│   ├── pci_module.py           # PCI计算模块
│   ├── rqi_module.py           # RQI计算模块
│   ├── rdi_module.py           # RDI计算模块
│   ├── sri_module.py           # SRI计算模块
│   ├── pbi_module.py           # PBI计算模块
│   └── pssi_module.py          # PSSI计算模块
├── assets/
│   ├── PQI输入数据模板.csv      # 沥青路面输入模板
│   └── PQI输入数据模板_水泥.csv # 水泥路面输入模板
└── references/
    └── jtg_5210_2018_summary.md # 规范摘要
```

## 规范依据

- 《公路技术状况评定标准》JTG 5210-2018
- 表 7.4.3 PQI 权重系数
- 表 7.4.5-1 沥青路面损坏类型及权重
- 表 7.4.5-2 水泥路面损坏类型及权重
- 式 7.4.4~7.4.12 各指标计算公式
