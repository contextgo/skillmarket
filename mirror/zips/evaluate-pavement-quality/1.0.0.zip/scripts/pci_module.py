# -*- coding: utf-8 -*-
"""
PCI（路面损坏状况指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》

PCI = 100 - a0 * DR^a1

其中：
  DR（损坏率）= Σ(损坏换算面积) / 调查面积 × 100%
  a0, a1: 模型参数，随路面类型变化
"""

import json
import os

# ============================================================
# 模型参数 (JTG 5210-2018 表4.3.2-1/2)
# ============================================================
MODEL_PARAMS = {
    "沥青混凝土": {"a0": 15.00, "a1": 0.412},
    "水泥混凝土": {"a0": 10.66, "a1": 0.461},
}

# ============================================================
# 损坏类型权重系数 (依据JTG 5210-2018 规范表7.4.5-1/2)
# ============================================================
DAMAGE_WEIGHTS = {
    # ===== 沥青路面损坏类型 (表7.4.5-1) =====
    "沥青": {
        # 损坏类型: {轻度权重, 中度权重(若有), 重度权重, 计量单位, 长度→面积换算系数}
        "龟裂":           {"light": 0.60, "medium": 0.80, "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "块状裂缝":       {"light": 0.60,                "heavy": 0.80,
                           "unit": "area",   "convert": 1.0},
        "纵向裂缝":       {"light": 0.60,                "heavy": 1.00,
                           "unit": "length", "convert": 0.2},  # 长度×0.2m → 面积
        "横向裂缝":       {"light": 0.60,                "heavy": 1.00,
                           "unit": "length", "convert": 0.5},  # 长度×0.5m → 面积
        "坑槽":           {"light": 0.60,                "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "车辙":           {"light": 0.60,                "heavy": 1.00,
                           "unit": "length", "convert": 0.5},  # 长度×0.5m → 面积
        "波浪拥包":       {"light": 0.60,                "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "松散":           {"light": 0.60,                "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "泛油":           {"light": 0.20,                "heavy": None,
                           "unit": "area",   "convert": 1.0},  # 仅单级
        "修补":           {"light": 0.10,                "heavy": None,
                           "unit": "mixed",  "convert": 0.2},  # 面积或长度×0.2m
    },
    # ===== 水泥混凝土路面损坏类型 (表7.4.5-2) =====
    "水泥": {
        "破碎板":         {"light": 0.80,                "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "裂缝":           {"light": 0.60, "medium": 0.80, "heavy": 1.00,
                           "unit": "length", "convert": 1.0},  # 长度×1.0m → 面积
        "板角断裂":       {"light": 0.60, "medium": 0.80, "heavy": 1.00,
                           "unit": "area",   "convert": 1.0},
        "错台":           {"light": 0.60,                "heavy": 1.00,
                           "unit": "length", "convert": 1.0},  # 长度×1.0m → 面积
        "唧泥":           {"light": 1.00,                "heavy": None,
                           "unit": "length", "convert": 1.0},  # 仅单级
        "边角剥落":       {"light": 0.60,                "heavy": 1.00,
                           "unit": "length", "convert": 1.0},  # 长度×1.0m → 面积
        "接缝料损坏":     {"light": 0.40,                "heavy": 0.60,
                           "unit": "length", "convert": 1.0},  # 长度×1.0m → 面积
        "坑洞":           {"light": 1.00,                "heavy": None,
                           "unit": "area",   "convert": 1.0},  # 仅单级
        "拱起":           {"light": 1.00,                "heavy": None,
                           "unit": "area",   "convert": 1.0},  # 仅单级
        "露骨":           {"light": 0.30,                "heavy": None,
                           "unit": "area",   "convert": 1.0},  # 仅单级
        "修补":           {"light": 0.10,                "heavy": None,
                           "unit": "mixed",  "convert": 0.2},  # 面积或长度×0.2m
    }
}


class PCICalculator:
    """路面损坏状况指数(PCI)计算器"""
    
    def __init__(self, pavement_type="沥青混凝土"):
        """
        初始化PCI计算器
        
        Args:
            pavement_type: 路面类型 ('沥青混凝土' 或 '水泥混凝土')
        """
        if "沥青" in pavement_type:
            self.pavement_key = "沥青"
            self.damage_types = DAMAGE_WEIGHTS["沥青"]
        else:
            self.pavement_key = "水泥"
            self.damage_types = DAMAGE_WEIGHTS["水泥"]
        
        params_key = "沥青混凝土" if "沥青" in pavement_type else "水泥混凝土"
        self.a0 = MODEL_PARAMS[params_key]["a0"]
        self.a1 = MODEL_PARAMS[params_key]["a1"]
    
    def calculate_DR(self, damage_data, lane_width, survey_length):
        """
        计算损坏率DR
        
        Args:
            damage_data: 损坏数据字典 {损坏名: {light: 数值, heavy: 数值}}
            lane_width: 行车道宽度(m)
            survey_length: 调查长度(m)
            
        Returns:
            DR: 损坏率(%), detail: 各损坏项的换算面积明细
        """
        survey_area = lane_width * survey_length  # 调查总面积 (m²)
        total_equivalent_area = 0.0
        detail = {}
        
        for damage_name, values in damage_data.items():
            if damage_name not in self.damage_types:
                continue  # 忽略未知的损坏类型
            
            weight_info = self.damage_types[damage_name]
            light_val  = values.get("light", 0) or 0
            medium_val = values.get("medium", 0) or 0
            heavy_val  = values.get("heavy", 0) or 0

            # 计算换算面积
            convert_factor = weight_info["convert"]
            
            if weight_info["unit"] == "area":
                light_area  = light_val * (weight_info["light"] or 0)
                medium_area = medium_val * (weight_info.get("medium") or 0)
                heavy_area  = heavy_val * (weight_info["heavy"] or 0)
            elif weight_info["unit"] in ["length", "mixed"]:
                light_area  = light_val * convert_factor * (weight_info["light"] or 0)
                medium_area = medium_val * convert_factor * (weight_info.get("medium") or 0)
                heavy_area  = heavy_val * convert_factor * (weight_info["heavy"] or 0)
            else:
                light_area  = 0
                medium_area = 0
                heavy_area  = 0
            
            item_total = light_area + medium_area + heavy_area
            total_equivalent_area += item_total
            
            detail[damage_name] = {
                "light_raw": light_val,
                "medium_raw": medium_val,
                "heavy_raw": heavy_val,
                "light_equiv": round(light_area, 2),
                "medium_equiv": round(medium_area, 2),
                "heavy_equiv": round(heavy_area, 2),
                "item_total": round(item_total, 2)
            }
        
        DR = (total_equivalent_area / survey_area) * 100 if survey_area > 0 else 0
        
        return round(DR, 3), detail, survey_area
    
    def calculate_PCI(self, damage_data, lane_width, survey_length):
        """
        计算PCI值
        
        Args:
            damage_data: 损坏数据字典
            lane_width: 行车道宽度(m)
            survey_length: 调查长度(m)
            
        Returns:
            dict: 包含PCI值、DR值、明细和等级
        """
        DR, detail, survey_area = self.calculate_DR(damage_data, lane_width, survey_length)
        
        # PCI = 100 - a0 * DR^a1
        if DR > 0:
            PCI = 100 - self.a0 * (DR ** self.a1)
        else:
            PCI = 100.0
        
        # 限制范围 0~100
        PCI = max(0, min(100, round(PCI, 1)))
        
        grade = self._get_grade(PCI)
        
        return {
            "PCI": PCI,
            "DR": round(DR, 2),
            "model_params": {"a0": self.a0, "a1": self.a1},
            "damage_detail": detail,
            "survey_area_m2": round(survey_area, 2),
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade)
        }
    
    @staticmethod
    def _get_grade(value):
        """获取评价等级"""
        if value >= 90: return "优"
        elif value >= 80: return "良"
        elif value >= 70: return "中"
        elif value >= 60: return "次"
        else: return "差"
    
    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {"优": "极好", "良": "良好", "中": "中等", "次": "较差", "差": "很差"}
        return desc_map.get(grade, "未知")
    
    def get_calculation_text(self, result):
        """生成计算过程文本"""
        lines = []
        lines.append("═" * 55)
        lines.append("  一、PCI（路面损坏状况指数）计算过程")
        lines.append("═" * 55)
        lines.append("")
        lines.append(f"  【模型参数】 a₀={result['model_params']['a0']}, a₁={result['model_params']['a1']}")
        lines.append(f"  【调查面积】 {result['survey_area_m2']} m² ({self._lane_w}m × {self._len}m)")
        lines.append("")
        lines.append("  ┌────────────┬────────┬────────┬────────┬──────────┬──────────┬──────────┬─────────┐")
        lines.append("  │  损坏类型   │ 轻度值 │ 中度值 │ 重度值 │ 轻度换算  │ 中度换算  │ 重度换算  │  合计   │")
        lines.append("  ├────────────┼────────┼────────┼────────┼──────────┼──────────┼──────────┼─────────┤")
        
        for name, d in result['damage_detail'].items():
            lines.append(f"  │ {name:^10s} │ {d['light_raw']:>6} │ {d['medium_raw']:>6} │ {d['heavy_raw']:>6} │ "
                        f"{d['light_equiv']:>8.2f} │ {d['medium_equiv']:>8.2f} │ {d['heavy_equiv']:>8.2f} │ {d['item_total']:>7.2f} │")
        
        total = sum(d['item_total'] for d in result['damage_detail'].values())
        lines.append("  ├────────────┴────────┴────────┴────────┴──────────┴──────────┴──────────┴─────────┤")
        lines.append(f"  │ {'合计':^12s}                                                          │ {total:>7.2f} │")
        lines.append("  └─────────────────────────────────────────────────────────────────────────────────────┘")
        lines.append("")
        lines.append(f"  【损坏率 DR】 = {total:.2f} / {result['survey_area_m2']:.2f} × 100% = {result['DR']:.2f}%")
        lines.append("")
        lines.append(f"  【计算公式】 PCI = 100 − a₀ × DR^a₁")
        lines.append(f"             PCI = 100 − {result['model_params']['a0']} × {result['DR']:.2f}^{result['model_params']['a1']}")
        dr_power = result['DR'] ** result['model_params']['a1']
        lines.append(f"                 = 100 − {result['model_params']['a0']} × {dr_power:.4f}")
        subtract = result['model_params']['a0'] * dr_power
        lines.append(f"                 = 100 − {subtract:.2f}")
        lines.append(f"                 = {result['PCI']:.1f}")
        lines.append("")
        lines.append(f"  ★ PCI = {result['PCI']:.1f}  →  评价等级：【{result['grade']}】{result['grade_desc']}")
        lines.append("")
        
        return "\n".join(lines)


# 测试入口
if __name__ == "__main__":
    # 示例数据测试
    calc = PCICalculator("沥青混凝土")
    
    damage_data = {
        "龟裂":     {"light": 15.0, "heavy": 5.0},    # m²
        "横向裂缝": {"light": 120.0, "heavy": 35.0},   # m
        "纵向裂缝": {"light": 85.0, "heavy": 20.0},    # m
        "坑槽":     {"light": 2.0, "heavy": 0.8},      # m²
        "修补":     {"light": 10.0, "heavy": 0},       # m²
    }
    
    result = calc.calculate_PCI(damage_data, lane_width=3.75, survey_length=2000)
    
    calc._lane_w = 3.75
    calc._len = 2000
    print(calc.get_calculation_text(result))
