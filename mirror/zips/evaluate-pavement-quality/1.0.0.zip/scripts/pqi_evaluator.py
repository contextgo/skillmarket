# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║     JTG 5210-2018 路面技术状况评定系统 - PQI综合评价程序      ║
║                                                              ║
║  功能：导入路面检测数据，自动计算PQI及各分项指标，输出评价报告 ║
║  用法：python pqi_evaluator.py [输入CSV路径]                   ║
╚══════════════════════════════════════════════════════════════╝

依据规范：《公路技术状况评定标准》JTG 5210-2018

作者：CodeBuddy Engineering Tools
日期：2026-04
"""

import os
import sys
import csv
import json
from datetime import datetime

# 添加模块路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.pci_module import PCICalculator
from modules.rqi_module import RQICalculator
from modules.rdi_module import RDICalculator
from modules.sri_module import SRICalculator
from modules.pbi_module import PBICalculator
from modules.pssi_module import PSSICalculator


# ============================================================
# 权重系数配置 (JTG 5210-2018 表7.4.3)
# PQI = w_PCI*PCI + w_RQI*RQI + w_RDI*RDI + w_PBI*PBI + w_SRI*SRI
# 注：SRI与路面磨耗指数PWI二取一；PSSI不参与PQI计算(式7.4.4)
# ============================================================
WEIGHT_CONFIG = {
    "沥青混凝土": {
        "高速": {"PCI": 0.35, "RQI": 0.30, "RDI": 0.15, "PBI": 0.10, "SRI": 0.10},
        "一级": {"PCI": 0.35, "RQI": 0.30, "RDI": 0.15, "PBI": 0.10, "SRI": 0.10},
        "二级": {"PCI": 0.60, "RQI": 0.40, "RDI": 0.00, "PBI": 0.00, "SRI": 0.00},
        "三级": {"PCI": 0.60, "RQI": 0.40, "RDI": 0.00, "PBI": 0.00, "SRI": 0.00},
        "四级": {"PCI": 0.60, "RQI": 0.40, "RDI": 0.00, "PBI": 0.00, "SRI": 0.00},
    },
    "水泥混凝土": {
        "高速": {"PCI": 0.50, "RQI": 0.30, "PBI": 0.10, "SRI": 0.10},
        "一级": {"PCI": 0.50, "RQI": 0.30, "PBI": 0.10, "SRI": 0.10},
        "二级": {"PCI": 0.60, "RQI": 0.40, "PBI": 0.00, "SRI": 0.00},
        "三级": {"PCI": 0.60, "RQI": 0.40, "PBI": 0.00, "SRI": 0.00},
        "四级": {"PCI": 0.60, "RQI": 0.40, "PBI": 0.00, "SRI": 0.00},
    }
}


class PQIEvaluator:
    """PQI综合评价器"""
    
    def __init__(self):
        self.pci_calc = None
        self.rqi_calc = RQICalculator()
        self.rdi_calc = RDICalculator()
        self.sri_calc = SRICalculator()
        self.pbi_calc = PBICalculator()
        self.pssi_calc = PSSICalculator()
        self.results = {}
        
    def load_csv_data(self, csv_path):
        """
        从CSV文件加载检测数据
        
        CSV格式说明：
          第一行为表头（中文）
          基础信息行 + 损坏数据行 + 其他检测参数行
          
        Returns:
            dict: 解析后的数据字典
        """
        data = {}
        
        with open(csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            # 获取实际列名（去除首尾空白）
            fieldnames = [name.strip() for name in reader.fieldnames] if reader.fieldnames else []
            
            for row in reader:
                # 清理row中的key
                cleaned_row = {k.strip(): v for k, v in row.items() if k is not None}
                
                key = cleaned_row.get('字段', '').strip()
                value = cleaned_row.get('数值', '').strip()
                unit = cleaned_row.get('单位', '') or ''
                note = cleaned_row.get('备注', '') or ''
                if isinstance(unit, str):
                    unit = unit.strip()
                if isinstance(note, str):
                    note = note.strip()
                
                if not key or key.startswith('#'):
                    continue
                
                data[key] = {"value": value, "unit": unit, "note": note}
        
        return data
    
    def parse_input_data(self, raw_data):
        """
        解析原始数据为结构化格式
        
        Args:
            raw_data: 从CSV读取的原始数据
            
        Returns:
            dict: 结构化的输入参数
        """
        def get_val(key):
            if key in raw_data:
                return raw_data[key]["value"]
            return ""
        
        def get_float(key, default=0.0):
            try:
                v = get_val(key)
                return float(v) if v else default
            except:
                return default
        
        def get_int(key, default=0):
            try:
                v = get_val(key)
                return int(float(v)) if v else default
            except:
                return default
        
        # ===== 基础信息 =====
        params = {
            "road_name": get_val("路线名称"),
            "section_id": get_val("桩号段"),
            "pavement_type": get_val("路面类型"),
            "road_grade": get_val("公路等级"),
            "lane_width": get_float("行车道宽度", 3.75),
            "survey_length": get_float("检测长度", 1000),
            "survey_date": get_val("检测日期"),
            
            # RQI输入
            "IRI": get_float("国际平整度指数IRI"),
            
            # RDI输入 (仅沥青)
            "RD": get_float("平均车辙深度RD"),
            
            # SRI输入
            "SFC": get_float("横向力系数SFC"),
            
            # PBI输入（表7.4.9 跳车扣分标准，单位：处）
            "bounce_data": {
                "light":  get_int("跳车_轻度", 0),
                "medium": get_int("跳车_中度", 0),
                "heavy":  get_int("跳车_重度", 0),
            },

            # PSSI输入（附录C 式C.0.1 + 第7.4.12条，不参与PQI）
            "pssi_data": {
                "Ne":             get_float("累计当量轴载Ne", 0),
                "l_measured":     get_float("实测代表弯沉l", 0),
                "surface_type":   get_val("面层类型") or "沥青混凝土",
                "structure_type": get_val("基层结构类型") or "半刚性基层",
            },
        }
        
        # ===== 损坏数据 (PCI用) —— 对应JTG 5210-2018 表7.4.5-1/2 =====
        # 沥青路面损坏类型（表7.4.5-1）
        damage_types_asphalt = [
            ("龟裂_轻度", "龟裂_中度", "龟裂_重度"),
            ("块状裂缝_轻度", None, "块状裂缝_重度"),
            ("纵向裂缝_轻度", None, "纵向裂缝_重度"),
            ("横向裂缝_轻度", None, "横向裂缝_重度"),
            ("坑槽_轻度", None, "坑槽_重度"),
            ("车辙_轻度", None, "车辙_重度"),
            ("波浪拥包_轻度", None, "波浪拥包_重度"),
            ("松散_轻度", None, "松散_重度"),
            ("泛油", None, None),           # 单级
            ("修补_轻度", None, "修补_重度"),
        ]
        
        # 水泥混凝土路面损坏类型（表7.4.5-2）
        damage_types_cement = [
            ("破碎板_轻度", None, "破碎板_重度"),
            ("裂缝_轻度", "裂缝_中度", "裂缝_重度"),
            ("板角断裂_轻度", "板角断裂_中度", "板角断裂_重度"),
            ("错台_轻度", None, "错台_重度"),
            ("唧泥", None, None),             # 单级
            ("边角剥落_轻度", None, "边角剥落_重度"),
            ("接缝料损坏_轻度", None, "接缝料损坏_重度"),
            ("坑洞", None, None),              # 单级
            ("拱起", None, None),              # 单级
            ("露骨", None, None),              # 单级
            ("修补_轻度", None, "修补_重度"),
        ]
        
        # 根据路面类型选择损坏类型列表
        ptype = params["pavement_type"]
        if "沥青" in ptype:
            damage_list = damage_types_asphalt
        else:
            damage_list = damage_types_cement
        
        damage_data = {}
        for light_key, medium_key, heavy_key in damage_list:
            base_name = light_key.replace("_轻度", "").replace("_中度", "").replace("_重度", "")
            entry = {
                "light": get_float(light_key, 0),
                "medium": get_float(medium_key, 0) if medium_key else 0,
                "heavy": get_float(heavy_key, 0) if heavy_key else 0,
            }
            damage_data[base_name] = entry
        
        params["damage_data"] = damage_data
        
        return params
    
    def run_evaluation(self, params):
        """
        执行完整的PQI评价计算
        
        Args:
            params: 结构化输入参数
            
        Returns:
            dict: 完整的评价结果
        """
        pavement_type = params["pavement_type"]
        road_grade = params["road_grade"].replace("公路", "").strip()
        
        # 获取权重
        type_key = "沥青混凝土" if "沥青" in pavement_type else "水泥混凝土"
        grade_key = road_grade if road_grade in WEIGHT_CONFIG[type_key] else "二级"
        weights = WEIGHT_CONFIG[type_key][grade_key]
        
        results = {
            "basic_info": {
                "road_name": params["road_name"],
                "section_id": params["section_id"],
                "pavement_type": pavement_type,
                "road_grade": params["road_grade"],
                "lane_width": params["lane_width"],
                "survey_length": params["survey_length"],
                "survey_date": params["survey_date"],
            },
            "weights": weights,
            "items": {},
            "pqi": None,
            "grade": None,
        }
        
        # ---- 1. PCI 计算 ----
        self.pci_calc = PCICalculator(pavement_type)
        pci_result = self.pci_calc.calculate_PCI(
            params["damage_data"], 
            params["lane_width"], 
            params["survey_length"]
        )
        # 保存引用用于文本生成
        self.pci_calc._lane_w = params["lane_width"]
        self.pci_calc._len = params["survey_length"]
        results["items"]["PCI"] = pci_result
        
        # ---- 2. RQI 计算 (式7.4.7, 按公路等级选择参数) ----
        rqi_result = self.rqi_calc.calculate_RQI(params["IRI"], params.get("road_grade", "高速公路"))
        results["items"]["RQI"] = rqi_result
        
        # ---- 3. RDI 计算 (仅沥青路面) ----
        if "沥青" in pavement_type and weights.get("RDI", 0) > 0:
            rdi_result = self.rdi_calc.calculate_RDI(params["RD"])
            results["items"]["RDI"] = rdi_result
        
        # ---- 4. SRI 计算 ----
        sri_result = self.sri_calc.calculate_SRI(params["SFC"])
        results["items"]["SRI"] = sri_result
        
        # ---- 5. PBI 计算 (表7.4.9 跳车扣分标准) ----
        bounce_data = params.get("bounce_data", {"light": 0, "medium": 0, "heavy": 0})
        total_bounce = bounce_data["light"] + bounce_data["medium"] + bounce_data["heavy"]
        if weights.get("PBI", 0) > 0 and total_bounce > 0:
            pbi_result = self.pbi_calc.calculate_PBI(bounce_data)
            results["items"]["PBI"] = pbi_result
        elif weights.get("PBI", 0) > 0 and total_bounce == 0:
            # 无跳车时取满分
            pbi_result = self.pbi_calc.calculate_PBI({"light": 0, "medium": 0, "heavy": 0})
            results["items"]["PBI"] = pbi_result

        # ---- 6. PSSI 计算 (式7.4.12, 不参与PQI，单独评定) ----
        pssi_params = params.get("pssi_data", {})
        Ne = pssi_params.get("Ne", 0)
        l_measured = pssi_params.get("l_measured", 0)
        if Ne > 0 and l_measured > 0:
            pssi_result = self.pssi_calc.calculate_full(
                Ne=Ne,
                l_measured=l_measured,
                road_grade=params.get("road_grade", "高速公路"),
                surface_type=pssi_params.get("surface_type", "沥青混凝土"),
                structure_type=pssi_params.get("structure_type", "半刚性基层")
            )
            results["items"]["PSSI"] = pssi_result
        
        # ---- 6. PQI 综合计算 ----
        pqi_sum = 0.0
        pqi_detail = {}
        for item_name, item_result in results["items"].items():
            w = weights.get(item_name, 0)
            if w > 0:
                contribution = w * item_result[list(item_result.keys())[0]]  # 取值
                pqi_sum += contribution
                pqi_detail[item_name] = {
                    "value": item_result[list(item_result.keys())[0]],
                    "weight": w,
                    "contribution": round(contribution, 2)
                }
        
        results["PQI"] = round(pqi_sum, 1)
        results["detail"] = pqi_detail
        results["grade"] = self._get_grade(results["PQI"])
        results["grade_desc"] = self._get_grade_desc(results["grade"])
        
        self.results = results
        return results
    
    @staticmethod
    def _get_grade(value):
        if value >= 90: return "优"
        elif value >= 80: return "良"
        elif value >= 70: return "中"
        elif value >= 60: return "次"
        else: return "差"
    
    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {"优": "极好", "良": "良好", "中": "中等", "次": "较差", "差": "很差"}
        return desc_map.get(grade, "未知")
    
    def generate_report(self, output_path=None):
        """
        生成完整的评定报告（txt格式）
        """
        lines = []
        r = self.results
        
        # ===== 报告头部 =====
        lines.append("")
        lines.append("╔" + "═" * 62 + "╗")
        lines.append("║" + "  公路技术状况评定报告".center(56) + "║")
        lines.append("║" + "  （JTG 5210-2018）".center(56) + "║")
        lines.append("╚" + "═" * 62 + "╝")
        lines.append("")
        
        # ===== 一、工程基本信息 =====
        lines.append("┌" + "─" * 58 + "┐")
        lines.append("│" + "  一、工程基本信息".center(52) + "│")
        lines.append("└" + "─" * 58 + "┘")
        info = r['basic_info']
        lines.append(f"  路线名称：{info['road_name']}")
        lines.append(f"  检测桩号：{info['section_id']}")
        lines.append(f"  路面类型：{info['pavement_type']}")
        lines.append(f"  公路等级：{info['road_grade']}")
        lines.append(f"  行车道宽度：{info['lane_width']} m")
        lines.append(f"  检测长度：{info['survey_length']} m")
        lines.append(f"  检测日期：{info['survey_date']}")
        lines.append("")
        
        # ===== 二、权重系数 =====
        lines.append("┌" + "─" * 58 + "┐")
        lines.append("│" + "  二、PQI权重系数配置".center(52) + "│")
        lines.append("└" + "─" * 58 + "┘")
        weight_text = "  ".join([f"{k}={v:.2f}" for k, v in r['weights'].items() if v > 0])
        lines.append(f"  权重分配 → {weight_text}")
        lines.append("")
        
        # ===== 三~六、各分项计算过程 =====
        if 'PCI' in r['items']:
            lines.append(self.pci_calc.get_calculation_text(r['items']['PCI']))
        
        if 'RQI' in r['items']:
            lines.append(self.rqi_calc.get_calculation_text(r['items']['RQI']))
        
        if 'RDI' in r['items']:
            lines.append(self.rdi_calc.get_calculation_text(r['items']['RDI']))
        
        if 'SRI' in r['items']:
            lines.append(self.sri_calc.get_calculation_text(r['items']['SRI']))
        
        if 'PBI' in r['items']:
            lines.append(self.pbi_calc.get_calculation_text(r['items']['PBI']))
        
        # PSSI单独评定（式7.4.4: 不参与PQI）
        if 'PSSI' in r['items']:
            lines.append(self.pssi_calc.get_calculation_text(r['items']['PSSI']))
        
        # ===== 七、PQI综合评价结果 =====
        lines.append("═" * 58)
        lines.append("  七、PQI综合评价结果")
        lines.append("═" * 58)
        lines.append("")
        lines.append("  【综合计算公式】")
        items_str = " + ".join([f"{r['weights'][k]}×{r['detail'][k]['value']:.1f}" 
                               for k in r['detail']])
        lines.append(f"  PQI = {items_str}")
        lines.append(f"      = {r['PQI']:.1f}")
        lines.append("")
        
        # 可视化条形图 (ASCII)
        lines.append("  ┌──────────────────────────────────────────────┐")
        lines.append("  │         各指标评分条形图                     │")
        lines.append("  ├──────────────────────────────────────────────┤")
        
        bar_max_len = 35
        for item_name, detail in r['detail'].items():
            val = detail['value']
            bar_len = int(val / 100 * bar_max_len)
            bar = "█" * bar_len + "░" * (bar_max_len - bar_len)
            w = detail['weight']
            contrib = detail['contribution']
            lines.append(f"  │ {item_name}: {bar} {val:>5.1f}  (w={w:.2f}, ×={contrib:.2f})")
        
        # PQI总评
        pqi_val = r['PQI']
        bar_len = int(pqi_val / 100 * bar_max_len)
        bar = "█" * bar_len + "░" * (bar_max_len - bar_len)
        lines.append(f"  ├──────────────────────────────────────────────┤")
        lines.append(f"  │ PQI : {bar} {pqi_val:>5.1f}  【{r['grade']}】{r['grade_desc']}")
        lines.append("  └──────────────────────────────────────────────┘")
        lines.append("")
        
        # 等级判定标准参考
        lines.append("  ┌──────────────────────────────────────────────┐")
        lines.append("  │  评价等级标准                                │")
        lines.append("  ├──────┬──────────┬───────────────────────────┤")
        lines.append("  │ 等级 │ 分值范围  │ 养护对策建议              │")
        lines.append("  ├──────┼──────────┼───────────────────────────┤")
        grade_advice = [
            (" 优 ", "90~100", "日常养护，保持现状"),
            (" 良 ", "80~89", "预防性养护，小修保养"),
            (" 中 ", "70~79", "中修罩面/局部修补"),
            (" 次 ", "60~69", "大修或专项工程"),
            (" 差 ", "0~59", "改扩建或重建"),
        ]
        for g, rng, advice in grade_advice:
            marker = "★" if g.strip() == r['grade'] else " "
            lines.append(f"  │{marker}{g} │ {rng}   │ {advice:<23s} │")
        lines.append("  └──────┴──────────┴───────────────────────────┘")
        lines.append("")
        
        # ===== 八、养护建议 =====
        lines.append("═" * 58)
        lines.append("  八、养护建议")
        lines.append("═" * 58)
        lines.append(self._generate_maintenance_advice())
        lines.append("")
        
        # ===== 报告尾部 =====
        lines.append("-" * 58)
        lines.append(f"  报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("  依据规范：JTG 5210-2018《公路技术状况评定标准》")
        lines.append("-" * 58)
        
        report_text = "\n".join(lines)
        
        # 写入文件
        if output_path is None:
            os.makedirs('output', exist_ok=True)
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            output_path = f'output/PQI评定报告_{timestamp}.txt'
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(f"\n[OK] 评定报告已生成：{output_path}\n")
        print(report_text)
        
        return report_text, output_path
    
    def _generate_maintenance_advice(self):
        """根据各项指标生养护建议"""
        r = self.results
        advice_lines = []
        
        items = r.get('items', {})
        
        # 分析各分项
        weak_items = []  # 低于80的项
        good_items = []  # 高于90的项
        
        for name, result in items.items():
            val = result[name]  # 主值
            if val < 70:
                weak_items.append((name, val, "急需处治"))
            elif val < 80:
                weak_items.append((name, val, "建议改善"))
            elif val >= 90:
                good_items.append((name, val))
        
        # PQI总体判断
        pqi = r['PQI']
        grade = r['grade']
        
        if grade == "优":
            advice_lines.append("  总体评价：路面技术状况优良。")
            advice_lines.append("  建议：执行日常巡查保洁和预防性养护即可。")
        elif grade == "良":
            advice_lines.append("  总体评价：路面技术状况良好。")
            advice_lines.append("  建议：加强日常养护，关注薄弱环节的发展趋势。")
        elif grade == "中":
            advice_lines.append("  总体评价：路面技术状况中等，需要安排中修计划。")
            if weak_items:
                for item, val, level in weak_items:
                    advice_lines.append(f"  · {item}={val:.1f}({level}) — 应优先处理")
            advice_lines.append("  建议：编制下年度中修工程计划。")
        elif grade == "次":
            advice_lines.append("  总体评价：路面技术状况较差，需安排大修或专项工程。")
            if weak_items:
                for item, val, level in weak_items:
                    advice_lines.append(f"  · {item}={val:.1f}({level}) — 重点处治目标")
            advice_lines.append("  建议：尽快开展详细调查，制定大修方案。")
        else:  # 差
            advice_lines.append("  ★★★ 路面技术状况很差，建议立即启动改扩建或重建程序！")
            advice_lines.append("  各项指标严重偏低，存在安全隐患，需紧急处置。")
        
        return "\n".join(advice_lines)


# ============================================================
# 主程序入口
# ============================================================
def main():
    import sys
    import io
    # 设置控制台输出为UTF-8编码（解决Windows中文/特殊字符显示问题）
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    
    print("=" * 60)
    print("  JTG 5210-2018 路面技术状况PQI评定系统")
    print("=" * 60)
    print()
    
    # 确定输入文件路径
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
    else:
        # 默认使用data目录下的模板文件
        csv_path = os.path.join(os.path.dirname(__file__), 'data', 'PQI输入数据.csv')
    
    # 检查文件是否存在
    if not os.path.exists(csv_path):
        print(f"[ERROR] 错误：找不到输入文件 '{csv_path}'")
        print(f"\n请按以下步骤操作：\n  1. 打开 data/PQI输入数据模板.csv\n  "
              f"2. 填写检测数据\n  3. 另存为PQI输入数据.csv\n  "
              f"4. 重新运行本程序\n")
        # 尝试查找模板
        template = os.path.join(os.path.dirname(__file__), 'data', 'PQI输入数据模板.csv')
        if os.path.exists(template):
            print(f"  [TEMPLATE] 输入数据模板位置：{template}")
        sys.exit(1)
    
    print(f"[INFO] 正在读取数据文件：{csv_path}")

    # 执行评价
    evaluator = PQIEvaluator()

    # 加载数据
    raw_data = evaluator.load_csv_data(csv_path)
    print(f"[OK] 成功加载 {len(raw_data)} 个数据项\n")

    # 解析数据
    params = evaluator.parse_input_data(raw_data)

    # 计算评价
    print("[CALC] 开始计算各分项指标...")
    results = evaluator.run_evaluation(params)

    print("\n[RESULT] 计算结果摘要：")
    print(f"  {'指标':<8} {'得分':>8} {'等级':>6} {'权重':>6} {'贡献值':>8}")
    print(f"  {'-'*40}")
    for name, detail in results.get('detail', {}).items():
        print(f"  {name:<8} {detail['value']:>7.1f} {results['items'][name]['grade']:>6} "
              f"{results['weights'][name]:>5.2f} {detail['contribution']:>7.2f}")
    print(f"  {'-'*40}")
    print(f"  {'PQI':<8} {results['PQI']:>7.1f} {results['grade']:>6}")
    
    # 生成报告
    print("\n[OUTPUT] 正在生成评定报告...")
    report_text, output_path = evaluator.generate_report()
    
    return results


if __name__ == "__main__":
    main()
