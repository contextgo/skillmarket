# -*- coding: utf-8 -*-
"""
RDI（路面车辙深度指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》第7.4.8条

计算公式 (式 7.4.8) —— 三段分段线性函数：

            { 100 - a0 * RD            (RD <= RDa)
    RDI =   { 90 - a1 * (RD - RDa)     (RDA < RD <= RDb)
            { 0                        (RD > RDb)

其中：
  RD  -- 车辙深度 (mm)
  RDa -- 车辙深度参数, 采用 10.0
  RDb -- 车辙深度参数, 采用 40.0
  a0  -- 模型参数, 采用 1.0
  a1  -- 模型参数, 采用 3.0

仅适用于沥青路面！
"""


class RDICalculator:
    """路面车辙深度指数(RDI)计算器 - 仅适用于沥青路面"""

    # ============================================================
    # 规范参数 (JTG 5210-2018 式7.4.8)
    # ============================================================
    RD_A = 10.0       # 车辙深度参数 RDa (mm), 第一/二段分界点
    RD_B = 40.0       # 车辙深度参数 RDb (mm), 第二/三段分界点
    A0 = 1.0          # 第一段模型参数
    A1 = 3.0          # 第二段模型参数

    def calculate_RDI(self, RD):
        """
        根据平均车辙深度RD计算RDI

        Args:
            RD: 平均车辙深度 (mm)，通常范围 0~50+

        Returns:
            dict: 包含RDI值、输入RD、等级等
        """
        RD = float(RD)

        # ---- 分段函数处理 (式7.4.8) ----
        if RD <= self.RD_A:
            # 第一段: RDI = 100 - a0 * RD
            RDI = 100.0 - self.A0 * RD
            segment = 1
            note = f"第一段: RD({RD:.1f}) <= RDa({self.RD_A}), RDI = 100 - {self.A0}*{RD:.1f}"
        elif RD <= self.RD_B:
            # 第二段: RDI = 90 - a1 * (RD - RDa)
            RDI = 90.0 - self.A1 * (RD - self.RD_A)
            segment = 2
            note = f"第二段: RDa < RD({RD:.1f}) <= RDb({self.RD_B}), " \
                   f"RDI = 90 - {self.A1}*(RD-{self.RD_A})"
        else:
            # 第三段: RDI = 0
            RDI = 0.0
            segment = 3
            note = f"第三段: RD({RD:.1f}) > RDb({self.RD_B}), RDI = 0"

        RDI = max(0.0, min(100.0, round(RDI, 1)))
        grade = self._get_grade(RDI)

        return {
            "RDI": RDI,
            "RD": round(RD, 2),
            "segment": segment,
            "model_params": {
                "a0": self.A0,
                "a1": self.A1,
                "rd_a": self.RD_A,
                "rd_b": self.RD_B,
            },
            "calc_note": note,
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade)
        }

    @staticmethod
    def _get_grade(value):
        if value >= 90: return "优"
        elif value >= 80: return "良"
        elif value >= 70: return "中"
        elif value >= 60: return "次"
        else: return "差"

    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {"优": "极好", "良": "良好", "中": "中等", "次": "较差", "差": "很差"}
        return desc_map.get(grade, "未知")

    def get_calculation_text(self, result):
        """生成计算过程文本"""
        lines = []
        lines.append("=" * 55)
        lines.append("  三、RDI（路面车辙深度指数）计算过程")
        lines.append("=" * 55)
        lines.append("")
        lines.append("  [依据] JTG 5210-2018 第7.4.8条 式(7.4.8)")
        lines.append("")
        lines.append(f"  [模型参数] a0={self.A0}, a1={self.A1}, "
                     f"RD_a={self.RD_A}mm, RD_b={self.RD_B}mm")
        lines.append(f"  [检测数据]  RD = {result['RD']} mm (平均车辙深度)")
        lines.append("")

        rd_val = result['RD']
        seg = result['segment']

        if seg == 1:
            lines.append("  [分段公式] 第一段: RD <= RDa")
            lines.append("             RDI = 100 - a0 * RD")
            rdi_calc = 100 - self.A0 * rd_val
            lines.append(f"             RDI = 100 - {self.A0} x {rd_val}")
            lines.append(f"                 = 100 - {self.A0 * rd_val:.1f}")
            lines.append(f"                 = {result['RDI']:.1f}")
        elif seg == 2:
            lines.append("  [分段公式] 第二段: RDa < RD <= RDb")
            lines.append("             RDI = 90 - a1 * (RD - RDa)")
            diff = rd_val - self.RD_A
            rdi_calc = 90 - self.A1 * diff
            lines.append(f"             RDI = 90 - {self.A1} x ({rd_val:.1f} - {self.RD_A})")
            lines.append(f"                 = 90 - {self.A1} x {diff:.1f}")
            lines.append(f"                 = 90 - {self.A1 * diff:.1f}")
            lines.append(f"                 = {result['RDI']:.1f}")
        else:
            lines.append("  [分段公式] 第三段: RD > RDb")
            lines.append("             RDI = 0")
            lines.append(f"             RDI = 0")

        lines.append("")
        lines.append(f"  [计算说明] {result['calc_note']}")
        lines.append("")
        lines.append(f"  * RDI = {result['RDI']:.1f}  ->  评价等级：【{result['grade']}】{result['grade_desc']}")
        lines.append("")
        lines.append("  [参考标准 - 式7.4.8]")
        lines.append("    RD <= 10mm :  RDI = 100-1.0*RD  (第一段)")
        lines.append("    10< RD<=40:  RDI = 90-3.0*(RD-10)  (第二段)")
        lines.append("    RD > 40mm :  RDI = 0  (第三段, 需铣刨重铺)")
        lines.append("")

        return "\n".join(lines)


if __name__ == "__main__":
    import sys, io
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    calc = RDICalculator()

    # 测试三段不同情况
    for label, rd in [("小车辙 RD=6mm (第一段)", 6.0),
                       ("中车辙 RD=12.5mm (第二段)", 12.5),
                       ("大车辙 RD=25mm (第二段)", 25.0),
                       ("严重 RD=45mm (第三段)", 45.0)]:
        result = calc.calculate_RDI(rd)
        print(f"=== {label} ===")
        print(calc.get_calculation_text(result))
