# -*- coding: utf-8 -*-
"""
SRI（路面抗滑性能指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》第7.4.11条 式(7.4.11)

计算公式：
              100 - SRI_min
    SRI = ──────────────────────  +  SRI_min          (式7.4.11)
           1 + a0 x e^(a1 x SFC)

其中：
  SFC     —— 横向力系数（SCRIM测定值）
  SRI_min —— 标定参数，采用 35.0
  a0      —— 模型参数，采用 28.6
  a1      —— 模型参数，采用 -0.105

注：SFC越大，抗滑性能越好（a1为负值）
"""

import math


class SRICalculator:
    """路面抗滑性能指数(SRI)计算器"""

    # 规范模型参数 (式7.4.11)
    A0 = 28.6        # 模型参数 a0
    A1 = -0.105      # 模型参数 a1
    SRI_MIN = 35.0   # 标定参数 SRI_min（下限偏移量）

    def calculate_SRI(self, SFC):
        """
        根据横向力系数SFC计算SRI

        Args:
            SFC: 横向力系数，通常范围 0~65

        Returns:
            dict: 包含SRI值、输入SFC、模型参数、等级等
        """
        a0 = self.A0
        a1 = self.A1
        sri_min = self.SRI_MIN

        # 式(7.4.11): SRI = (100 - SRI_min) / (1 + a0 * e^(a1 * SFC)) + SRI_min
        exponent = math.exp(a1 * SFC)
        denominator = 1.0 + a0 * exponent
        SRI = (100.0 - sri_min) / denominator + sri_min

        # 限制范围 0~100
        SRI = max(0.0, min(100.0, round(SRI, 1)))

        grade = self._get_grade(SRI)

        return {
            "SRI": SRI,
            "SFC": round(SFC, 1),
            "model_params": {"a0": a0, "a1": a1, "SRI_min": sri_min},
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade)
        }

    @staticmethod
    def _get_grade(value):
        if value >= 90:
            return "优"
        elif value >= 80:
            return "良"
        elif value >= 70:
            return "中"
        elif value >= 60:
            return "次"
        else:
            return "差"

    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {
            "优": "极好", "良": "良好", "中": "中等",
            "次": "较差", "差": "很差"
        }
        return desc_map.get(grade, "未知")

    def get_calculation_text(self, result):
        """生成计算过程文本（符合工程计算书格式）"""
        SFC = result['SFC']
        a0 = result['model_params']['a0']
        a1 = result['model_params']['a1']
        sri_min = result['model_params']['SRI_min']

        lines = []
        lines.append("=" * 58)
        lines.append("  四、SRI（路面抗滑性能指数）计算过程")
        lines.append("      依据：JTG 5210-2018 第7.4.11条 式(7.4.11)")
        lines.append("=" * 58)
        lines.append("")
        lines.append(f"  【模型参数】 a0={a0}, a1={a1}, SRI_min={sri_min}")
        lines.append(f"  【检测数据】 SFC = {SFC} (横向力系数)")
        lines.append("")
        lines.append("  【计算公式】 (式7.4.11)")
        lines.append("")
        lines.append(f"                 100 - {sri_min}")
        lines.append(f"    SRI = ────────────────────────  +  {sri_min}")
        lines.append(f"           1 + {a0} x e^({a1} x SFC)")
        lines.append("")

        # 分步计算
        exponent = math.exp(a1 * SFC)
        denom = 1.0 + a0 * exponent
        numerator = 100.0 - sri_min

        lines.append("  【分步计算】")
        lines.append(f"    第一步: 指数项 e^({a1} x {SFC}) = e^{a1*SFC:.3f} = {exponent:.6f}")
        lines.append(f"    第二步: 分母 1 + {a0} x {exponent:.6f} = {denom:.6f}")
        lines.append(
            f"    第三步: SRI = ({numerator:.1f}/{denom:.4f}) + {sri_min}"
            f" = {numerator/denom:.2f} + {sri_min} = {result['SRI']:.1f}"
        )
        lines.append("")
        lines.append(f"  ★ SRI = {result['SRI']:.1f}  --> 评价等级：【{result['grade']}】{result['grade_desc']}")
        lines.append("")

        # 参考标准说明
        lines.append("  【技术状况分级标准】")
        lines.append("    优 : SRI >= 90   (SFC >= 48)")
        lines.append("    良 : 80 <= SRI < 90  (SFC 40~47)")
        lines.append("    中 : 70 <= SRI < 80  (SFC 33~39)")
        lines.append("    次 : 60 <= SRI < 70  (SFC 28~32)")
        lines.append("    差 : SRI < 60       (SFC < 28)")
        lines.append("")

        return "\n".join(lines)


if __name__ == "__main__":
    calc = SRICalculator()

    print("=" * 60)
    print("  SRI 模块单元测试 - 验证规范式(7.4.11)算法正确性")
    print("=" * 60)
    print()

    # 测试1：中等抗滑性能
    print("--- 测试1: SFC=45.0 (中等抗滑) ---")
    r1 = calc.calculate_SRI(SFC=45.0)
    print(calc.get_calculation_text(r1))

    # 测试2：良好抗滑性能
    print("--- 测试2: SFC=52.0 (良好抗滑) ---")
    r2 = calc.calculate_SRI(SFC=52.0)
    print(calc.get_calculation_text(r2))

    # 测试3：极差抗滑性能
    print("--- 测试3: SFC=15.0 (极差抗滑) ---")
    r3 = calc.calculate_SRI(SFC=15.0)
    print(calc.get_calculation_text(r3))
