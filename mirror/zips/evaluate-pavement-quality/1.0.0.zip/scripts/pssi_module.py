# -*- coding: utf-8 -*-
"""
PSSI（路面结构强度指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》

一、路面弯沉标准值计算 (附录C 式C.0.1)：
    l0 = 600 x Ne^(-Ac) x As x Ab

    其中：
      Ne —— 累计当量轴载次数（次）
      Ac —— 公路技术等级系数：
             高速、一级公路取 1.0
             二级公路取 1.1
             三级、四级公路取 1.2
      As —— 路面面层类型系数：
             沥青混凝土面层取 1.0
             热拌和冷拌沥青碎石、沥青贯入式（含上拌下贯式）、
             沥青表面处治取 1.1
      Ab —— 路面结构类型系数：
             半刚性基层沥青路面取 1.0
             柔性基层沥青路面取 1.6

二、PSSI计算 (第7.4.12条 式7.4.12-1 和 式7.4.12-2)：

    SSR = l0 / l                          (7.4.12-2)

              100
    PSSI = ─────────────                  (7.4.12-1)
           1 + a0 x e^(a1 x SSR)

    其中：
      SSR —— 路面结构强度系数（Pavement Structure Strength Ratio）
      l0  —— 路面弯沉标准值（0.01mm），按式(C.0.1)计算
      l   —— 路面实测代表弯沉（0.01mm）
      a0  —— 模型参数，采用 15.71
      a1  —— 模型参数，采用 -5.19

三、重要说明 (式7.4.4):
    PSSI应依据检测数据单独评定，不参与PQI综合计算！
"""

import math


class PSSICalculator:
    """路面结构强度指数(PSSI)计算器"""

    # 规范模型参数 (式7.4.12-1)
    A0 = 15.71       # 模型参数 a0
    A1 = -5.19       # 模型参数 a1

    # 公路等级系数 Ac (式C.0.1)
    AC_COEFF = {
        "高速": 1.0,   # 高速公路
        "一级": 1.0,   # 一级公路
        "二级": 1.1,   # 二级公路
        "三级": 1.2,   # 三级公路
        "四级": 1.2,   # 四级公路
    }

    # 面层类型系数 As (式C.0.1)
    AS_COEFF = {
        "沥青混凝土":     1.0,
        "热拌沥青碎石":     1.1,
        "冷拌沥青碎石":     1.1,
        "沥青贯入式":       1.1,
        "上拌下贯式":       1.1,
        "沥青表面处治":     1.1,
    }

    # 结构类型系数 Ab (式C.0.1)
    AB_COEFF = {
        "半刚性基层": 1.0,
        "柔性基层":   1.6,
    }

    def calc_deflection_standard(self, Ne, road_grade="高速公路",
                                 surface_type="沥青混凝土",
                                 structure_type="半刚性基层"):
        """
        计算路面弯沉标准值 l0 (式C.0.1)

        Args:
            Ne:            累计当量轴载次数（次）
            road_grade:    公路等级（高速/一级/二级/三级/四级）
            surface_type:  面层类型（沥青混凝土/热拌沥青碎石/...）
            structure_type: 结构类型（半刚性基层/柔性基层）

        Returns:
            dict: 包含l0及各中间参数
        """
        # 提取系数
        rc = str(road_grade).strip()
        Ac = self._get_Ac(rc)
        As = self._get_As(surface_type)
        Ab = self._get_Ab(structure_type)

        # 式(C.0.1): l0 = 600 * Ne^(-Ac) * As * Ab
        l0 = 600.0 * (Ne ** (-Ac)) * As * Ab

        return {
            "l0": round(l0, 6),
            "Ne": int(Ne),
            "Ac": Ac,
            "As": As,
            "Ab": Ab,
            "road_grade": rc,
            "surface_type": surface_type,
            "structure_type": structure_type,
        }

    def calculate_PSSI(self, l_measured, l0):
        """
        根据实测代表弯沉和弯沉标准值计算PSSI

        Args:
            l_measured: 路面实测代表弯沉 (0.01mm)
            l0:         路面弯沉标准值 (0.01mm)，由calc_deflection_standard()计算

        Returns:
            dict: 含PSSI、SSR、各参数及等级
        """
        a0 = self.A0
        a1 = self.A1

        # 式(7.4.12-2): SSR = l0 / l
        if l_measured <= 0:
            return {
                "PSSI": 100.0,
                "SSR": None,
                "l0": l0,
                "l_measured": l_measured,
                "model_params": {"a0": a0, "a1": a1},
                "grade": "优",
                "grade_desc": "极好",
                "note": "实测弯沉为0或负值，取满分"
            }

        SSR = l0 / l_measured

        # 式(7.4.12-1): PSSI = 100 / (1 + a0 * e^(a1 * SSR))
        exponent = math.exp(a1 * SSR)
        denominator = 1.0 + a0 * exponent
        PSSI = 100.0 / denominator

        # 限制范围 0~100
        PSSI = max(0.0, min(100.0, round(PSSI, 1)))
        SSR_rounded = round(SSR, 3)

        grade = self._get_grade(PSSI)

        return {
            "PSSI": PSSI,
            "SSR": SSR_rounded,
            "l0": l0,
            "l_measured": l_measured,
            "model_params": {"a0": a0, "a1": a1},
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade),
        }

    def calculate_full(self, Ne, l_measured, road_grade="高速公路",
                      surface_type="沥青混凝土", structure_type="半刚性基层"):
        """一步完成：先算l0，再算PSSI"""
        l0_result = self.calc_deflection_standard(Ne, road_grade, surface_type, structure_type)
        pssi_result = self.calculate_PSSI(l_measured, l0_result["l0"])
        pssi_result["l0_detail"] = l0_result
        return pssi_result

    @staticmethod
    def _get_Ac(road_grade):
        for key in PSSICalculator.AC_COEFF:
            if key in road_grade:
                return PSSICalculator.AC_COEFF[key]
        return 1.2  # 默认三级/四级

    @staticmethod
    def _get_As(surface_type):
        for key in PSSICalculator.AS_COEFF:
            if key in surface_type:
                return PSSICalculator.AS_COEFF[key]
        return 1.0  # 默认沥青混凝土

    @staticmethod
    def _get_Ab(structure_type):
        for key in PSSICalculator.AB_COEFF:
            if key in structure_type:
                return PSSICalculator.AB_COEFF[key]
        return 1.0  # 默认半刚性

    @staticmethod
    def _get_grade(value):
        if value >= 90:
            return "优"
        elif value >= 80:
            return "良"
        elif value >= 70:
            return "中"
        elif value >= 60:
            return "次"
        else:
            return "差"

    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {
            "优": "极好", "良": "良好", "中": "中等",
            "次": "较差", "差": "很差"
        }
        return desc_map.get(grade, "未知")

    def get_calculation_text(self, result):
        """生成PSSI计算过程文本（含弯沉标准值和PSSI完整计算链）"""
        lines = []
        lines.append("=" * 62)
        lines.append("  六、PSSI（路面结构强度指数）计算过程")
        lines.append("      依据：JTG 5210-2018 附录C 式(C.0.1) + 第7.4.12条")
        lines.append("=" * 62)
        lines.append("")
        lines.append("  【注】PSSI依据检测数据单独评定，不参与PQI综合计算（式7.4.4）")
        lines.append("")

        # 第一部分：弯沉标准值 l0 计算
        l0_d = result.get("l0_detail", {})
        if not l0_d:
            lines.append(f"  [输入] 弯沉标准值 l0 = {result.get('l0', '?')} (0.01mm)")
            lines.append(f"  [输入] 实测代表弯沉 l = {result['l_measured']} (0.01mm)")
        else:
            lines.append("  ┌──────────────────────────────────────────────┐")
            lines.append("  │  一、路面弯沉标准值 l0 计算 (式C.0.1)         │")
            lines.append("  └──────────────────────────────────────────────┘")
            lines.append("")
            lines.append(f"  【基础参数】")
            lines.append(f"    累计当量轴载次数 Ne = {l0_d['Ne']:,} 次")
            lines.append(f"    公路等级: {l0_d['road_grade']}")
            lines.append(f"    面层类型: {l0_d['surface_type']}")
            lines.append(f"    基层结构: {l0_d['structure_type']}")
            lines.append(f"  【修正系数】")
            lines.append(f"    Ac (等级系数) = {l0_d['Ac']}")
            lines.append(f"    As (面层系数) = {l0_d['As']}")
            lines.append(f"    Ab (结构系数) = {l0_d['Ab']}")
            lines.append("")
            lines.append("  【计算公式】 (C.0.1)")
            lines.append(f"    l0 = 600 x Ne^(-Ac) x As x Ab")
            Ne = l0_d['Ne']
            lines.append(
                f"       = 600 x {Ne:,}^({-l0_d['Ac']}) "
                f"x {l0_d['As']} x {l0_d['Ab']}"
            )
            ne_pow = Ne ** (-l0_d['Ac'])
            lines.append(f"       = 600 x {ne_pow:.8e} "
                        f"x {l0_d['As']} x {l0_d['Ab']}")
            lines.append(f"       = {l0_d['l0']:.6f} (0.01mm)")
            lines.append("")
            lines.append(f"  ★ 弯沉标准值 l0 = {l0_d['l0']:.6f} (0.01mm)")
            lines.append("")

        # 第二部分：PSSI 计算
        l0_val = l0_d.get('l0', result.get('l0', '?')) if l0_d else result.get('l0', '?')
        a0 = result['model_params']['a0']
        a1 = result['model_params']['a1']

        lines.append("  ┌──────────────────────────────────────────────┐")
        lines.append("  │  二、PSSI 计算 (式7.4.12-1 / 7.4.12-2)       │")
        lines.append("  └──────────────────────────────────────────────┘")
        lines.append("")
        lines.append(f"  【检测数据】 实测代表弯沉 l = {result['l_measured']} (0.01mm)")
        lines.append(f"  【模型参数】 a0={a0}, a1={a1}")
        lines.append("")

        if result['SSR'] is not None:
            lines.append("  [第一步] 计算结构强度系数 SSR (式7.4.12-2)")
            lines.append(f"           SSR = l0 / l = {l0_val} / {result['l_measured']} "
                       f"= {result['SSR']}")
            lines.append("")

            SSR = result['SSR']
            lines.append("  [第二步] 计算PSSI (式7.4.12-1)")
            lines.append(f"                    100")
            lines.append(f"    PSSI = ────────────────────────")
            lines.append(f"           1 + {a0} x e^({a1} x SSR)")
            lines.append("")

            exponent = math.exp(a1 * SSR)
            denom = 1.0 + a0 * exponent
            lines.append(
                f"           = 100 / (1 + {a0} x e^({a1 * SSR:.3f}))"
            )
            lines.append(f"           = 100 / (1 + {a0} x {exponent:.8f})")
            lines.append(f"           = 100 / {denom:.8f}")
            lines.append(f"           = {result['PSSI']:.1f}")

        lines.append("")
        lines.append(
            f"  ★ PSSI = {result['PSSI']:.1f}  --> "
            f"评价等级：【{result['grade']}】{result['grade_desc']}"
        )
        lines.append("")

        lines.append("  【参考标准说明】")
        lines.append("    SSR >= 1.0 : 路面强度充足，PSSI >= 90 (优)")
        lines.append("    SSR ~0.8  : 强度略不足，PSSI约 75~85")
        lines.append("    SSR < 0.6  : 强度严重不足，需补强 (差)")
        lines.append("")

        return "\n".join(lines)


if __name__ == "__main__":
    calc = PSSICalculator()

    print("=" * 65)
    print("  PSSI 模块单元测试")
    print("  验证: 式(C.0.1) 弯沉标准值 + 式(7.4.12) PSSI计算")
    print("=" * 65)
    print()

    # 测试1：典型高速公路工况（强度充足）
    print("--- 测试1: 高速公路, Ne=1500万次, 实测l=22 (0.01mm) ---")
    r1 = calc.calculate_full(
        Ne=15000000, l_measured=22,
        road_grade="高速公路",
        surface_type="沥青混凝土",
        structure_type="半刚性基层"
    )
    print(calc.get_calculation_text(r1))

    # 测试2：柔性基层，强度略低
    print("--- 测试2: 一级公路 柔性基层, Ne=800万次, 实测l=38 ---")
    r2 = calc.calculate_full(
        Ne=8000000, l_measured=38,
        road_grade="一级公路",
        surface_type="沥青混凝土",
        structure_type="柔性基层"
    )
    print(calc.get_calculation_text(r2))

    # 测试3：二级公路，强度不足
    print("--- 测试3: 二级公路, Ne=200万次, 实测l=55 ---")
    r3 = calc.calculate_full(
        Ne=2000000, l_measured=55,
        road_grade="二级公路",
        surface_type="沥青表面处治",
        structure_type="半刚性基层"
    )
    print(calc.get_calculation_text(r3))
