# -*- coding: utf-8 -*-
"""
RQI（路面行驶质量指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》第7.4.7条 式(7.4.7)

计算公式：
    RQI = 100 / (1 + a0 * exp(a1 * IRI))

其中：
  IRI —— 国际平整度指数 (m/km)
  a0  —— 高速公路和一级公路采用 0.026，其他等级公路采用 0.0185
  a1  —— 高速公路和一级公路采用 0.65，其他等级公路采用 0.58
"""

import math


class RQICalculator:
    """路面行驶质量指数(RQI)计算器"""

    # 规范模型参数 (式7.4.7)
    # key: 公路等级分类 (highway / other)
    MODEL_PARAMS = {
        "highway": {"a0": 0.026, "a1": 0.65},   # 高速公路、一级公路
        "other":    {"a0": 0.0185, "a1": 0.58},  # 二级、三级、四级公路
    }

    def __init__(self):
        self._params = None   # 当前使用的参数组

    def _select_params(self, road_class):
        """根据公路等级选择模型参数"""
        rc = str(road_class).strip()
        if any(k in rc for k in ["高速", "一级"]):
            return self.MODEL_PARAMS["highway"]
        else:
            return self.MODEL_PARAMS["other"]

    def calculate_RQI(self, IRI, road_class="高速公路"):
        """
        根据IRI和公路等级计算RQI

        Args:
            IRI:        国际平整度指数 (m/km)，通常范围 0~15
            road_class: 公路等级字符串 (如"高速公路"/"二级公路")

        Returns:
            dict: 包含RQI值、输入IRI、模型参数、等级等
        """
        self._params = self._select_params(road_class)
        a0 = self._params["a0"]
        a1 = self._params["a1"]

        # 式(7.4.7): RQI = 100 / (1 + a0 * e^(a1 * IRI))
        exponent = math.exp(a1 * IRI)
        denominator = 1.0 + a0 * exponent
        RQI = 100.0 / denominator

        # 限制范围 0~100
        RQI = max(0.0, min(100.0, round(RQI, 1)))

        grade = self._get_grade(RQI)

        return {
            "RQI": RQI,
            "IRI": round(IRI, 2),
            "road_class": road_class,
            "model_params": {"a0": a0, "a1": a1},
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade)
        }

    @staticmethod
    def _get_grade(value):
        if value >= 90:
            return "优"
        elif value >= 80:
            return "良"
        elif value >= 70:
            return "中"
        elif value >= 60:
            return "次"
        else:
            return "差"

    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {
            "优": "极好", "良": "良好", "中": "中等",
            "次": "较差", "差": "很差"
        }
        return desc_map.get(grade, "未知")

    def get_calculation_text(self, result):
        """生成计算过程文本（符合工程计算书格式）"""
        IRI = result['IRI']
        a0 = result['model_params']['a0']
        a1 = result['model_params']['a1']
        road_cls = result.get('road_class', '未知')

        lines = []
        lines.append("=" * 58)
        lines.append("  二、RQI（路面行驶质量指数）计算过程")
        lines.append("      依据：JTG 5210-2018 第7.4.7条 式(7.4.7)")
        lines.append("=" * 58)
        lines.append("")
        lines.append(f"  【公路等级】 {road_cls}")
        lines.append(f"  【检测数据】 IRI = {IRI} m/km")
        lines.append("")
        lines.append("  【计算公式】")
        lines.append("                    100")
        lines.append("    RQI = ─────────────────────")
        lines.append(f"           1 + {a0} x e^({a1} x IRI)")
        lines.append("")

        # 分步计算
        exponent = math.exp(a1 * IRI)
        denom = 1.0 + a0 * exponent

        lines.append("  【分步计算】")
        lines.append(f"    第一步: 指数项 e^({a1} x {IRI}) = e^{a1 * IRI:.4f} = {exponent:.4f}")
        lines.append(f"    第二步: 分母 1 + {a0} x {exponent:.4f} = {denom:.6f}")
        lines.append(f"    第三步: RQI = 100 / {denom:.6f} = {result['RQI']:.1f}")
        lines.append("")
        lines.append(f"  ★ RQI = {result['RQI']:.1f}  --> 评价等级：【{result['grade']}】{result['grade_desc']}")
        lines.append("")

        # 参考标准说明
        lines.append("  【技术状况分级标准】")
        lines.append("    优 : RQI >= 90")
        lines.append("    良 : 80 <= RQI < 90")
        lines.append("    中 : 70 <= RQI < 80")
        lines.append("    次 : 60 <= RQI < 70")
        lines.append("    差 : RQI < 60")
        lines.append("")

        return "\n".join(lines)


if __name__ == "__main__":
    calc = RQICalculator()

    print("=" * 60)
    print("  RQI 模块单元测试 - 验证规范式(7.4.7)算法正确性")
    print("=" * 60)
    print()

    # 测试1：高速公路 + 小IRI
    print("--- 测试1: 高速公路 IRI=2.85 m/km ---")
    r1 = calc.calculate_RQI(IRI=2.85, road_class="高速公路")
    print(calc.get_calculation_text(r1))

    # 测试2：高速公路 + 大IRI
    print("--- 测试2: 高速公路 IRI=5.20 m/km ---")
    r2 = calc.calculate_RQI(IRI=5.20, road_class="高速公路")
    print(calc.get_calculation_text(r2))

    # 测试3：二级公路 + 中等IRI（不同参数）
    print("--- 测试3: 二级公路 IRI=3.50 m/km ---")
    r3 = calc.calculate_RQI(IRI=3.50, road_class="二级公路")
    print(calc.get_calculation_text(r3))
