# -*- coding: utf-8 -*-
"""
PBI（路面跳车指数）计算模块
依据：JTG 5210-2018《公路技术状况评定标准》第7.4.9条

计算公式 (式 7.4.9)：
    PBI = 100 − Σ(ni × ai) / PBi

其中：
  PBi —— 调查路段的路面跳车总数（处）
  ni  —— 第 i 类程度路面跳车的单位扣分
  ai  —— 第 i 类程度路面跳车数量（处）
  i0  —— 路面跳车类型总数，取 3

表 7.4.9 路面跳车扣分标准：
  类型1(轻度)：单位扣分 = 0
  类型2(中度)：单位扣分 = 25
  类型3(重度)：单位扣分 = 50

计量单位：处（数量）
"""


class PBICalculator:
    """路面跳车指数(PBI)计算器"""

    # ============================================================
    # 表 7.4.9 路面跳车扣分标准 (JTG 5210-2018)
    # ============================================================
    BOUNCE_DEDUCTION = {
        "light":  { "name": "轻度",   "score":  0 },
        "medium": { "name": "中度",   "score": 25 },
        "heavy":  { "name": "重度",   "score": 50 },
    }

    # 跳车类型总数 i0
    TYPE_COUNT = 3

    # PBI下限值
    PBI_MIN = 60.0

    def calculate_PBI(self, bounce_data):
        """
        根据各程度跳车数量计算PBI

        Args:
            bounce_data: dict, 各程度跳车数量 {"light": N1, "medium": N2, "heavy": N3}
                         数量单位为"处"

        Returns:
            dict: 包含PBI值、明细数据、等级等
        """
        light_count  = int(bounce_data.get("light",  0) or 0)
        medium_count = int(bounce_data.get("medium", 0) or 0)
        heavy_count  = int(bounce_data.get("heavy",  0) or 0)

        # 各程度扣分计算
        light_deduction  = light_count * self.BOUNCE_DEDUCTION["light"]["score"]
        medium_deduction = medium_count * self.BOUNCE_DEDUCTION["medium"]["score"]
        heavy_deduction  = heavy_count * self.BOUNCE_DEDUCTION["heavy"]["score"]

        total_deduction = light_deduction + medium_deduction + heavy_deduction  # sum(ni*ai)
        total_bounce    = light_count + medium_count + heavy_count             # PBi

        if total_bounce <= 0 or total_deduction <= 0:
            # 无跳车时 PBI 取满分
            PBI = 100.0
            calc_note = "调查路段无跳车现象，PBI取满分"
        else:
            # PBI = 100 − Σ(ni×ai) / PBi
            PBI = 100.0 - total_deduction / total_bounce
            calc_note = f"正常计算(sum(ni*ai)={total_deduction}, PBi={total_bounce}处)"

        # 应用下限约束
        if PBI < self.PBI_MIN:
            PBI = self.PBI_MIN
            note = f"PBI低于下限{self.PBI_MIN}，取下限值"
        else:
            note = calc_note

        PBI = max(0.0, min(100.0, round(PBI, 1)))
        grade = self._get_grade(PBI)

        return {
            "PBI": PBI,
            "bounce_detail": {
                "light":  {"count": light_count,  "deduction": light_deduction},
                "medium": {"count": medium_count, "deduction": medium_deduction},
                "heavy":  {"count": heavy_count,  "deduction": heavy_deduction},
            },
            "total_bounce": total_bounce,
            "total_deduction": total_deduction,
            "calc_note": note,
            "grade": grade,
            "grade_desc": self._get_grade_desc(grade)
        }

    @staticmethod
    def _get_grade(value):
        if value >= 90: return "优"
        elif value >= 80: return "良"
        elif value >= 70: return "中"
        elif value >= 60: return "次"
        else: return "差"

    @staticmethod
    def _get_grade_desc(grade):
        desc_map = {"优": "极好", "良": "良好", "中": "中等", "次": "较差", "差": "很差"}
        return desc_map.get(grade, "未知")

    def get_calculation_text(self, result):
        """生成计算过程文本"""
        lines = []
        lines.append("=" * 55)
        lines.append("  五、PBI（路面跳车指数）计算过程")
        lines.append("=" * 55)
        lines.append("")
        lines.append("  【依据】 JTG 5210-2018 第7.4.9条 式(7.4.9)")
        lines.append("")

        d = result['bounce_detail']
        lines.append("  +----------+----------+----------+----------+")
        lines.append("  |  跳车程度   |  数量(处) |  单位扣分  |  扣分小计  |")
        lines.append("  +----------+----------+----------+----------+")
        lines.append(f"  |   轻度    |  {d['light']['count']:>6}  |     0    | "
                     f"{d['light']['deduction']:>6}  |")
        lines.append(f"  |   中度    |  {d['medium']['count']:>6}  |    25    | "
                     f"{d['medium']['deduction']:>6}  |")
        lines.append(f"  |   重度    |  {d['heavy']['count']:>6}  |    50    | "
                     f"{d['heavy']['deduction']:>6}  |")
        lines.append("  +----------+----------+----------+----------+")
        lines.append(f"  |   合计    |  {result['total_bounce']:>6}  |     --    | "
                     f"{result['total_deduction']:>6}  |")
        lines.append("  +----------------------------------------------+")
        lines.append("")

        tb = result['total_bounce']
        td = result['total_deduction']

        lines.append(f"  【计算说明】 {result['calc_note']}")
        lines.append("")
        lines.append("  【计算公式】 PBI = 100 - sum(ni * ai) / PBi")
        if tb > 0 and td > 0:
            deduction_ratio = td / tb
            lines.append(f"             PBI = 100 - {td} / {tb}")
            lines.append(f"                 = 100 - {deduction_ratio:.2f}")
            lines.append(f"                 = {result['PBI']:.1f}")
        else:
            lines.append("             PBi = 0 或无扣分 --> PBI = 100（满分）")

        lines.append("")
        lines.append(f"  * PBI = {result['PBI']:.1f}  ->  评价等级：【{result['grade']}】{result['grade_desc']}")
        lines.append("")
        lines.append("  [参考标准 - 表7.4.9 路面跳车扣分标准]")
        lines.append("    轻度跳车：单位扣分 0 分/处")
        lines.append("    中度跳车：单位扣分 25 分/处")
        lines.append("    重度跳车：单位扣分 50 分/处")
        lines.append("    PBI >= 90  ->优  |  80~89 ->良  |  70~79 ->中  |  60~69 ->次  |  <60 ->差")
        lines.append("")

        return "\n".join(lines)


if __name__ == "__main__":
    import sys, io
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    calc = PBICalculator()
    r1 = calc.calculate_PBI({"light": 10, "medium": 3, "heavy": 1})
    print(calc.get_calculation_text(r1))
    print("\n---\n")
    r2 = calc.calculate_PBI({"light": 0, "medium": 0, "heavy": 0})
    print(calc.get_calculation_text(r2))
