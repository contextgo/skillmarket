# -*- coding: utf-8 -*-
"""
PC Security - HTML Report Generator
生成自包含的安全扫描 HTML 报告（内联 CSS/JS）
使用: python pcsecscript/generate_report.py [历史扫描JSON路径]
"""
import io, sys, json, os, random, string
from datetime import datetime
from pathlib import Path
from typing import Optional

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

def load_scan_data(json_path: Optional[str] = None) -> dict:
    """加载扫描数据"""
    if json_path and os.path.isfile(json_path):
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    # 自动查找最新扫描
    # 历史目录：优先使用 WORKBUDDY 路径，回退到 ~/.workbuddy
    workbuddy = Path(os.environ.get("WORKBUDDY_DIR", str(Path.home() / ".workbuddy")))
    history_dir = workbuddy / "security-scan" / "history"
    if history_dir.exists():
        scans = sorted(history_dir.glob("scan_*.json"), key=os.path.getmtime, reverse=True)
        if scans:
            with open(scans[0], "r", encoding="utf-8") as f:
                return json.load(f)

    return {}


def get_risk_color(severity: str) -> str:
    colors = {
        "critical": "#dc2626",
        "high": "#f97316",
        "medium": "#eab308",
        "low": "#3b82f6",
        "info": "#6b7280"
    }
    return colors.get(severity, "#6b7280")


def get_risk_label(severity: str) -> str:
    labels = {"critical": "🔴 紧急", "high": "🟠 高危", "medium": "🟡 中危", "low": "🔵 低危", "info": "⚪ 信息"}
    return labels.get(severity, "⚪ 未知")


def make_chart_config(data: list, label: str, color: str) -> dict:
    """生成 Chart.js 配置"""
    return {
        "type": "bar",
        "data": {
            "labels": [d.get("label", "") for d in data],
            "datasets": [{
                "label": label,
                "data": [d.get("value", 0) for d in data],
                "backgroundColor": color,
                "borderRadius": 4
            }]
        },
        "options": {
            "responsive": True,
            "maintainAspectRatio": True,
            "plugins": {
                "legend": {"display": False},
                "tooltip": {"enabled": True}
            },
            "scales": {
                "y": {"beginAtZero": True, "grid": {"color": "#374151"}},
                "x": {"grid": {"display": False}}
            }
        }
    }


def generate_report_html(scan_data: dict, comparison_data: Optional[dict] = None) -> str:
    """生成完整的 HTML 报告"""
    summary = scan_data.get("summary", {})
    issues = scan_data.get("issues", [])
    processes = scan_data.get("processes", [])
    external_conns = scan_data.get("external_connections", [])
    temp_files = scan_data.get("temp_files", [])
    run_items = scan_data.get("run_items", [])
    scan_time = summary.get("scan_time", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    # 时间同步检查
    time_check = scan_data.get("time_check", {})
    time_warn_html = ""
    if time_check.get("warning"):
        time_warn_html = f"""
<div class="card" style="border-color:#dc2626;background:#1f1515;">
  <div style="display:flex;align-items:center;gap:12px;">
    <span style="font-size:28px;">⏰</span>
    <div>
      <div style="color:#fca5a5;font-weight:700;font-size:15px;margin-bottom:4px;">⚠️ 系统时间严重偏差警告</div>
      <div style="color:#d1d5db;font-size:13px;line-height:1.7;">
        <b>本地时间：</b>{time_check.get('local_time', '未知')} &nbsp;|&nbsp;
        <b>网络时间：</b>{time_check.get('internet_time', '未知')}<br>
        <b>偏差：</b>{time_check.get('offset_readable', '未知')} &nbsp;(
        <b style="color:#fca5a5;">差异 {abs(time_check.get('offset_seconds', 0) / 86400):.1f} 天</b>）<br><br>
        {time_check.get('warning', '')}
      </div>
    </div>
  </div>
</div>"""
    elif time_check.get("synced") and time_check.get("internet_time"):
        time_warn_html = f"""
<div class="card" style="border-color:#22c55e;background:#0f1f14;">
  <div style="display:flex;align-items:center;gap:12px;">
    <span style="font-size:22px;">✅</span>
    <div style="color:#86efac;font-size:13px;">
      时间同步正常 &nbsp;|&nbsp; 本地: {time_check.get('local_time','')} &nbsp;|&nbsp;
      网络: {time_check.get('internet_time','')} &nbsp;|&nbsp;
      偏差: {time_check.get('offset_readable','')}
    </div>
  </div>
</div>"""

    # 风险评分
    risk_score = 100
    risk_score -= len([i for i in issues if i.get("severity") == "critical"]) * 20
    risk_score -= len([i for i in issues if i.get("severity") == "high"]) * 10
    risk_score -= len([i for i in issues if i.get("severity") == "medium"]) * 5
    risk_score = max(0, min(100, risk_score))

    if risk_score >= 85:
        risk_level = "🟢 安全"
        risk_color = "#22c55e"
    elif risk_score >= 60:
        risk_level = "🟡 良好"
        risk_color = "#eab308"
    elif risk_score >= 30:
        risk_level = "🟠 风险"
        risk_color = "#f97316"
    else:
        risk_level = "🔴 危险"
        risk_color = "#dc2626"

    # 历史对比数据
    comp = comparison_data or {}

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PC 安全扫描报告 - {scan_time[:10]}</title>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}

body {{
  font-family: -apple-system, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  background: #0f1117;
  color: #e5e7eb;
  line-height: 1.6;
  padding: 24px;
}}

.container {{ max-width: 1100px; margin: 0 auto; }}

.header {{
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 32px;
  padding-bottom: 20px;
  border-bottom: 1px solid #1f2937;
}}

.header h1 {{
  font-size: 24px;
  font-weight: 700;
  color: #f9fafb;
}}

.header .time {{
  font-size: 14px;
  color: #9ca3af;
}}

.card {{
  background: #1a1d27;
  border: 1px solid #2d3748;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
}}

.card h2 {{
  font-size: 16px;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid #2d3748;
}}

/* 分数圆环 */
.score-section {{
  display: flex;
  align-items: center;
  gap: 48px;
}}

.score-ring {{
  position: relative;
  width: 160px;
  height: 160px;
  flex-shrink: 0;
}}

.score-ring svg {{ transform: rotate(-90deg); }}

.score-ring circle {{
  fill: none;
  stroke-width: 12;
}}

.score-ring .bg {{ stroke: #2d3748; }}
.score-ring .fg {{
  stroke: {risk_color};
  stroke-linecap: round;
  stroke-dasharray: 408;
  stroke-dashoffset: {int(408 * (100 - risk_score) / 100)};
  transition: stroke-dashoffset 1s ease;
}}

.score-center {{
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}}

.score-center .num {{
  font-size: 42px;
  font-weight: 800;
  color: {risk_color};
  line-height: 1;
}}

.score-center .label {{
  font-size: 14px;
  color: #9ca3af;
  margin-top: 4px;
}}

.score-meta {{
  flex: 1;
}}

.score-meta h3 {{
  font-size: 20px;
  color: {risk_color};
  margin-bottom: 16px;
}}

.meta-grid {{
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}}

.meta-item {{
  background: #111827;
  border-radius: 8px;
  padding: 12px 16px;
}}

.meta-item .val {{
  font-size: 24px;
  font-weight: 700;
  color: #f9fafb;
}}

.meta-item .lbl {{
  font-size: 12px;
  color: #6b7280;
  margin-top: 2px;
}}

/* 对比栏 */
.comparison-bar {{
  display: flex;
  gap: 24px;
  flex-wrap: wrap;
  margin-top: 12px;
}}

.comp-item {{
  background: #111827;
  border-radius: 8px;
  padding: 10px 16px;
  font-size: 14px;
}}

.comp-item .arrow {{ margin: 0 4px; }}
.pos {{ color: #22c55e; }}
.neg {{ color: #dc2626; }}
.neu {{ color: #6b7280; }}

/* 问题列表 */
.issues-grid {{
  display: grid;
  gap: 12px;
}}

.issue-item {{
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 14px;
  border-radius: 8px;
  border: 1px solid #2d3748;
  background: #111827;
  transition: border-color 0.2s;
}}

.issue-item:hover {{ border-color: #4b5563; }}

.issue-icon {{
  font-size: 18px;
  flex-shrink: 0;
  margin-top: 2px;
}}

.issue-body {{ flex: 1; }}

.issue-body .title {{
  font-size: 14px;
  font-weight: 600;
  color: #f3f4f6;
  margin-bottom: 4px;
}}

.issue-body .detail {{
  font-size: 12px;
  color: #6b7280;
  margin-bottom: 8px;
}}

.issue-body .rec {{
  font-size: 13px;
  color: #d1d5db;
  padding: 8px 12px;
  background: #1f2937;
  border-radius: 6px;
  border-left: 3px solid #4b5563;
}}

.no-issues {{
  text-align: center;
  padding: 40px;
  color: #22c55e;
  font-size: 18px;
}}

/* 进程表格 */
.data-table {{
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}}

.data-table th {{
  background: #111827;
  color: #9ca3af;
  font-weight: 600;
  text-align: left;
  padding: 10px 12px;
  border-bottom: 1px solid #2d3748;
  font-size: 12px;
  text-transform: uppercase;
}}

.data-table td {{
  padding: 8px 12px;
  border-bottom: 1px solid #1f2937;
  color: #d1d5db;
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}}

.data-table tr:hover td {{ background: #1f2937; }}

.tag {{
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
}}

.tag-red {{ background: #7f1d1d; color: #fca5a5; }}
.tag-orange {{ background: #7c2d12; color: #fdba74; }}
.tag-yellow {{ background: #713f12; color: #fde047; }}
.tag-green {{ background: #14532d; color: #86efac; }}
.tag-blue {{ background: #1e3a5f; color: #93c5fd; }}

.status-ok {{ color: #22c55e; font-size: 14px; }}
.status-warn {{ color: #f97316; font-size: 14px; }}
.status-error {{ color: #dc2626; font-size: 14px; }}

/* 图 */
.chart-wrap {{
  max-width: 500px;
  margin: 0 auto;
}}

/* 页脚 */
.footer {{
  text-align: center;
  padding: 24px;
  color: #4b5563;
  font-size: 12px;
  border-top: 1px solid #1f2937;
  margin-top: 32px;
}}

.badge-list {{
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 20px;
}}

.badge {{
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 600;
}}

.nav-tabs {{
  display: flex;
  gap: 8px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}}

.tab-btn {{
  padding: 8px 18px;
  border: 1px solid #2d3748;
  background: #1a1d27;
  color: #9ca3af;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.2s;
}}

.tab-btn:hover, .tab-btn.active {{
  background: #2563eb;
  color: #fff;
  border-color: #2563eb;
}}

.tab-content {{ display: none; }}
.tab-content.active {{ display: block; }}

.highlight-box {{
  background: #111827;
  border: 1px solid #2d3748;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
}}

.highlight-box h4 {{
  font-size: 13px;
  color: #9ca3af;
  margin-bottom: 8px;
}}

.highlight-box .val {{
  font-size: 32px;
  font-weight: 800;
}}

.changes-list {{
  display: grid;
  gap: 8px;
}}

.change-item {{
  padding: 10px 14px;
  border-radius: 6px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 8px;
}}

.change-bad {{ background: #7f1d1d; color: #fca5a5; }}
.change-good {{ background: #14532d; color: #86efac; }}
.change-neutral {{ background: #1f2937; color: #9ca3af; }}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <div>
    <h1>🛡️ PC 安全扫描报告</h1>
    <div class="time">扫描时间：{scan_time} &nbsp;|&nbsp; 深度扫描</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:12px;color:#6b7280">Windows 11 专业版</div>
    <div style="font-size:12px;color:#6b7280">Build 26200</div>
  </div>
</div>

<!-- 时间同步警告（如果有） -->
{time_warn_html}

<!-- 风险评分 -->
  <div class="score-section">
    <div class="score-ring">
      <svg width="160" height="160">
        <circle class="bg" cx="80" cy="80" r="65"/>
        <circle class="fg" cx="80" cy="80" r="65"/>
      </svg>
      <div class="score-center">
        <div class="num">{risk_score}</div>
        <div class="label">安全评分</div>
      </div>
    </div>
    <div class="score-meta">
      <h3>{risk_level}</h3>
      <div class="meta-grid">
        <div class="meta-item">
          <div class="val" style="color: #dc2626;">{len([i for i in issues if i.get('severity')=='critical'])}</div>
          <div class="lbl">🔴 紧急问题</div>
        </div>
        <div class="meta-item">
          <div class="val" style="color: #f97316;">{len([i for i in issues if i.get('severity')=='high'])}</div>
          <div class="lbl">🟠 高危问题</div>
        </div>
        <div class="meta-item">
          <div class="val" style="color: #eab308;">{len([i for i in issues if i.get('severity')=='medium'])}</div>
          <div class="lbl">🟡 中危问题</div>
        </div>
        <div class="meta-item">
          <div class="val">{summary.get('total_processes', 0)}</div>
          <div class="lbl">进程总数</div>
        </div>
        <div class="meta-item">
          <div class="val">{summary.get('external_connections', 0)}</div>
          <div class="lbl">外部连接</div>
        </div>
        <div class="meta-item">
          <div class="val">{summary.get('temp_suspicious_files', 0)}</div>
          <div class="lbl">可疑文件</div>
        </div>
      </div>
    </div>
  </div>
</div>
"""

    # 历史对比（如果有）
    if comp.get("available"):
        html += f"""
<div class="card">
  <h2>📊 历史对比（vs {comp.get('prev_time', '')}）</h2>
  <div class="changes-list">
"""
        for key, label, cls in [
            ("process_change", "进程数变化", ""),
            ("external_conn_change", "外部连接变化", ""),
            ("issue_change", "问题数量变化", ""),
            ("temp_file_change", "可疑文件变化", ""),
        ]:
            val = comp.get(key, 0)
            if val > 0:
                html += f'<div class="change-item change-bad">⬆️ {label}: <strong>+{val}</strong></div>\n'
            elif val < 0:
                html += f'<div class="change-item change-good">⬇️ {label}: <strong>{val}</strong></div>\n'
            else:
                html += f'<div class="change-item change-neutral">➡️ {label}: <strong>无变化</strong></div>\n'

        if comp.get("new_external_ips"):
            html += f'<div class="change-item change-bad">🆕 新增外部IP: {", ".join(comp["new_external_ips"])}</div>\n'
        if comp.get("new_issues"):
            html += f'<div class="change-item change-bad">🆕 新发现问题: {len(comp["new_issues"])} 项</div>\n'
        if comp.get("resolved_issues"):
            html += f'<div class="change-item change-good">✅ 已解决问题: {len(comp["resolved_issues"])} 项</div>\n'

        html += "</div></div>\n"

    # 导航标签
    html += """
<div class="nav-tabs">
  <button class="tab-btn active" onclick="showTab('issues')">⚠️ 发现问题</button>
  <button class="tab-btn" onclick="showTab('processes')">🖥️ 进程概览</button>
  <button class="tab-btn" onclick="showTab('network')">🌐 网络连接</button>
  <button class="tab-btn" onclick="showTab('startup')">🚀 自启动</button>
  <button class="tab-btn" onclick="showTab('temp')">📁 可疑文件</button>
</div>
"""

    # === 问题 tab ===
    html += '<div id="tab-issues" class="tab-content active"><div class="card"><h2>⚠️ 安全问题与建议</h2>'
    if issues:
        html += '<div class="issues-grid">'
        for issue in issues:
            sev = issue.get("severity", "low")
            icon = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}.get(sev, "⚪")
            html += f"""
        <div class="issue-item">
          <div class="issue-icon">{icon}</div>
          <div class="issue-body">
            <div class="title">{icon} {issue.get('title', '未知问题')}</div>
            <div class="detail">{issue.get('detail', '')}</div>
            <div class="rec">💡 {issue.get('recommendation', '建议手动检查并处理')}</div>
          </div>
        </div>"""
        html += '</div>'
    else:
        html += '<div class="no-issues">✅ 未发现安全问题，系统运行正常！</div>'
    html += '</div></div>'

    # === 进程 tab ===
    top_procs = sorted(processes, key=lambda x: x.get("cpu", 0), reverse=True)[:15]
    html += '<div id="tab-processes" class="tab-content"><div class="card"><h2>🖥️ 高CPU占用进程 TOP15</h2>'
    if top_procs:
        html += '<table class="data-table"><thead><tr><th>#</th><th>进程名</th><th>PID</th><th>CPU%</th><th>内存MB</th><th>线程</th><th>签名</th></tr></thead><tbody>'
        for i, p in enumerate(top_procs, 1):
            cpu = p.get("cpu", 0)
            cpu_tag = 'tag-red' if cpu > 80 else 'tag-orange' if cpu > 50 else 'tag-yellow'
            exe = p.get("exe", "")
            sig_status = "✅" if exe and os.path.isfile(exe) else "⚠️"
            html += f"""<tr>
              <td>{i}</td>
              <td><b>{p.get('name','')}</b></td>
              <td>{p.get('pid','')}</td>
              <td><span class="tag {cpu_tag}">{cpu}%</span></td>
              <td>{p.get('mem_mb','')}</td>
              <td>{p.get('threads','')}</td>
              <td>{sig_status}</td>
            </tr>"""
        html += '</tbody></table>'
    html += '</div></div>'

    # === 网络 tab ===
    html += '<div id="tab-network" class="tab-content"><div class="card"><h2>🌐 外部活动连接</h2>'
    if external_conns:
        html += '<table class="data-table"><thead><tr><th>协议</th><th>本地地址</th><th>远程地址</th><th>主机名</th><th>PID</th><th>状态</th></tr></thead><tbody>'
        for c in external_conns:
            html += f"""<tr>
              <td><span class="tag tag-blue">TCP</span></td>
              <td>{c.get('laddr','')}</td>
              <td>{c.get('raddr','')}</td>
              <td><b>{c.get('hostname','未知')}</b></td>
              <td>{c.get('pid','')}</td>
              <td><span class="tag tag-yellow">{c.get('state','')}</span></td>
            </tr>"""
        html += '</tbody></table>'
    else:
        html += '<div class="no-issues">✅ 未发现外部网络连接</div>'
    html += '</div></div>'

    # === 自启动 tab ===
    html += '<div id="tab-startup" class="tab-content"><div class="card"><h2>🚀 自启动项列表</h2>'
    if run_items:
        html += '<table class="data-table"><thead><tr><th>名称</th><th>注册表路径</th><th>执行命令</th></tr></thead><tbody>'
        for item in run_items[:20]:
            cmd = item.get("command", "")
            is_suspicious = any(t in cmd.lower() for t in ["temp", "download", "tmp", "appdata\\local"])
            flag = "⚠️" if is_suspicious else "✅"
            html += f"""<tr>
              <td>{flag} <b>{item.get('name','')}</b></td>
              <td style="font-size:12px;color:#6b7280">{item.get('path','')}</td>
              <td style="font-size:12px" title="{cmd}">{cmd[:80]}{'...' if len(cmd)>80 else ''}</td>
            </tr>"""
        html += '</tbody></table>'
    else:
        html += '<div class="no-issues">⚠️ 未检测到自启动项（可能为扫描权限不足）</div>'
    html += '</div></div>'

    # === 可疑文件 tab ===
    html += '<div id="tab-temp" class="tab-content"><div class="card"><h2>📁 Temp目录可疑文件（7天内修改）</h2>'
    if temp_files:
        html += '<table class="data-table"><thead><tr><th>文件名</th><th>路径</th><th>大小</th><th>修改时间</th><th>建议</th></tr></thead><tbody>'
        for tf in temp_files:
            html += f"""<tr>
              <td><b>{tf.get('name','')}</b></td>
              <td style="font-size:11px;color:#6b7280" title="{tf.get('file','')}">{tf.get('file','')[:60]}</td>
              <td>{tf.get('size_kb','')} KB</td>
              <td>{tf.get('modified','')}</td>
              <td><span class="tag tag-yellow">建议排查</span></td>
            </tr>"""
        html += '</tbody></table>'
    else:
        html += '<div class="no-issues">✅ Temp目录未发现近期可疑可执行文件</div>'
    html += '</div></div>'

    html += f"""
<div class="footer">
  <p>本报告由 WorkBuddy PC Security Scan Skill 自动生成 &nbsp;|&nbsp; {scan_time}</p>
  <p>⚠️ 本报告仅供安全参考，不能替代专业安全软件的全盘扫描</p>
  <p style="color:#fca5a5;font-weight:600;margin-top:8px;">📋 扫描结果，不代表任何安全意见和建议，仅供参考！</p>
</div>

</div>

<script>
function showTab(name) {{
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  event.target.classList.add('active');
}}
</script>
</body>
</html>"""

    return html


def main():
    json_path = sys.argv[1] if len(sys.argv) > 1 else None
    scan_data = load_scan_data(json_path)

    if not scan_data:
        print("[ERROR] 未找到扫描数据，请先运行深度扫描: python scripts/deep_scan.py")
        sys.exit(1)

    # 生成HTML
    html = generate_report_html(scan_data)

    # 保存
    report_dir = Path(__file__).parent.parent / "reports"
    report_dir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = report_dir / f"security_report_{ts}.html"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[✓] 报告已生成: {report_path}")
    print(f"[✓] 共 {len(scan_data.get('issues', []))} 个问题，{len(scan_data.get('processes', []))} 个进程")
    return str(report_path)


if __name__ == "__main__":
    main()
