# -*- coding: utf-8 -*-
"""
PC Security - Auto Fix Recommendations Generator
根据扫描发现的问题，自动生成修复命令和操作指引
"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

from datetime import datetime
from pathlib import Path

ISSUE_FIX_DB = {
    # === 杀毒软件 ===
    "defender_disabled": {
        "severity": "critical",
        "title": "Windows Defender 已禁用",
        "diagnosis": "实时保护被关闭，系统失去主要防线",
        "fix_commands": [
            "Set-MpPreference -DisableRealtimeMonitoring $false",
            "Set-MpPreference -DisableIOAVProtection $false",
            "Write-Host '已启用 Defender 实时保护，请重启电脑确保生效'"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行上述命令",
        "manual_step": "设置 → 更新和安全 → Windows 安全 → 病毒与威胁防护 → 管理设置 → 实时保护 → 开启",
        "url": "ms-settings:windowsdefender"
    },
    "defender_outdated": {
        "severity": "medium",
        "title": "病毒库超过7天未更新",
        "diagnosis": "病毒库过时，新威胁无法识别",
        "fix_commands": [
            "Update-MpSignature -Online",
            "Get-MpComputerStatus | Select-Object AntivirusSignatureLastUpdated"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行更新命令",
        "manual_step": "Windows 安全中心 → 检查威胁和安全防护更新",
        "url": None
    },
    "no_antivirus": {
        "severity": "critical",
        "title": "未检测到任何杀毒软件",
        "diagnosis": "系统完全没有实时防护，极度危险",
        "fix_commands": [
            "Write-Host '强烈建议安装杀毒软件：'",
            "Write-Host '1. Windows Defender（系统自带，已内置）'",
            "Write-Host '2. Malwarebytes Free: https://www.malwarebytes.com/'",
            "Write-Host '3. ESET Free: https://www.eset.com/'"
        ],
        "fix_description": "立即安装杀毒软件，建议 Windows Defender + Malwarebytes 组合",
        "manual_step": "设置 → 隐私与安全 → Windows 安全 → 病毒与威胁防护",
        "url": "ms-settings:windowsdefender"
    },

    # === 防火墙 ===
    "firewall_disabled": {
        "severity": "high",
        "title": "防火墙未完全启用",
        "diagnosis": "部分网络配置文件的防火墙被关闭，增加攻击面",
        "fix_commands": [
            "Set-NetFirewallProfile -Profile Domain -Enabled True",
            "Set-NetFirewallProfile -Profile Private -Enabled True",
            "Set-NetFirewallProfile -Profile Public -Enabled True",
            "Get-NetFirewallProfile | Select-Object Name, Enabled"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行上述命令启用所有防火墙",
        "manual_step": "控制面板 → 系统和安全 → Windows Defender 防火墙 → 启用或关闭",
        "url": "control.exe /name Microsoft.WindowsFirewall"
    },
    "open_suspicious_port": {
        "severity": "high",
        "title": "发现可疑开放端口",
        "diagnosis": "非标准端口或未知服务在监听，存在被利用风险",
        "fix_commands": [
            "## 查看详细端口信息：",
            "Get-NetTCPConnection -LocalPort <端口号> | Format-List",
            "## 查找对应进程：",
            "Get-Process -Id <PID> | Select-Object Name, Path",
            "## 如确认无用，可禁用相关服务：",
            "Stop-Service -Name '<服务名>' -Force",
            "Set-Service -Name '<服务名>' -StartupType Disabled"
        ],
        "fix_description": "根据扫描结果中显示的端口和进程，手动确认是否为预期服务",
        "manual_step": "控制面板 → 系统和安全 → Windows Defender 防火墙 → 高级设置 → 入站规则",
        "url": None
    },

    # === SMBv1 ===
    "smb1_enabled": {
        "severity": "critical",
        "title": "SMBv1 协议已启用（永恒之蓝漏洞）",
        "diagnosis": "SMBv1 是 WannaCry 等勒索软件的主要攻击向量",
        "fix_commands": [
            "Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart",
            "Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force",
            "Write-Host 'SMBv1 已禁用，建议重启电脑'"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行上述命令后重启电脑",
        "manual_step": "控制面板 → 程序 → 启用或关闭 Windows 功能 → 取消勾选 SMB 1.0/CIFS 文件共享支持",
        "url": "control.exe /name ProgramsAndFeatures"
    },

    # === RDP ===
    "rdp_enabled": {
        "severity": "high",
        "title": "远程桌面（RDP）已启用",
        "diagnosis": "RDP 是暴力破解和横向渗透的常见入口点",
        "fix_commands": [
            "Set-ItemProperty -Path 'HKLM:\\System\\CurrentControlSet\\Control\\Terminal Server' -Name 'fDenyTSConnections' -Value 1",
            "Disable-NetFirewallRule -DisplayGroup 'Remote Desktop'",
            "Write-Host 'RDP 已禁用'"
        ],
        "fix_description": "如确实需要 RDP，确保使用强密码 + 网络级认证（NLA）+ 非默认端口",
        "manual_step": "设置 → 系统 → 远程桌面 → 关闭",
        "url": "ms-settings:remotedesktop"
    },

    # === UAC ===
    "uac_disabled": {
        "severity": "high",
        "title": "UAC（用户账户控制）已禁用",
        "diagnosis": "恶意软件可在无提示的情况下获得管理员权限",
        "fix_commands": [
            "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name 'EnableLUA' -Value 1",
            "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name 'ConsentPromptBehaviorAdmin' -Value 2"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行上述命令后重启电脑",
        "manual_step": "控制面板 → 用户账户 → 用户账户 → 更改用户账户控制设置 → 设为"始终通知"",
        "url": "control.exe /name UserAccounts"
    },

    # === Guest 账户 ===
    "guest_enabled": {
        "severity": "medium",
        "title": "Guest 来宾账户未禁用",
        "diagnosis": "来宾账户可被用于绕过本地安全策略",
        "fix_commands": [
            "Disable-LocalUser -Name 'Guest'",
            "Write-Host 'Guest 账户已禁用'"
        ],
        "fix_description": "以管理员身份运行 PowerShell，执行上述命令",
        "manual_step": "计算机管理 → 本地用户和组 → 用户 → Guest → 属性 → 账户已禁用",
        "url": "compmgmt.msc"
    },

    # === 未知管理员账户 ===
    "unknown_admin": {
        "severity": "high",
        "title": "发现未知管理员账户",
        "diagnosis": "存在非标准的管理员账户，可能是后门账户",
        "fix_commands": [
            "## 查看所有本地管理员：",
            "Get-LocalGroupMember -Group 'Administrators'",
            "## 如需禁用可疑账户（替换<账户名>）：",
            "Disable-LocalUser -Name '<账户名>'",
            "## 或删除（谨慎！）：",
            "Remove-LocalUser -Name '<账户名>'"
        ],
        "fix_description": "首先确认该账户是否为本人创建，疑似后门时立即禁用并报告",
        "manual_step": "计算机管理 → 本地用户和组 → 用户 → 检查所有管理员账户",
        "url": "compmgmt.msc"
    },

    # === 可疑自启动项 ===
    "suspicious_startup": {
        "severity": "high",
        "title": "发现可疑自启动项",
        "diagnosis": "自启动路径包含 Temp/Download 等可疑目录，可能是木马",
        "fix_commands": [
            "## 查看自启动项详情：",
            "Get-ItemProperty 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run'",
            "## 如确认可疑，禁用（替换<项名>）：",
            "Remove-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run' -Name '<项名>'",
            "## 或彻底删除：",
            "Remove-Item -Path '<完整路径>' -Force"
        ],
        "fix_description": "在删除前先确认该程序是否为正常软件，必要时先备份",
        "manual_step": "任务管理器 → 启动 → 禁用可疑项",
        "url": "taskmgr.exe#Startup"
    },

    # === 可疑外部连接 ===
    "external_connection": {
        "severity": "high",
        "title": "发现可疑外部网络连接",
        "diagnosis": "存在到未知IP的长期连接，可能是远控木马或数据外传",
        "fix_commands": [
            "## 查看连接详情（替换<PID>）：",
            "Get-Process -Id <PID> | Select-Object Name, Path",
            "## 查看网络连接：",
            "netstat -ano | findstr '<IP>'",
            "## 如确认恶意，可终止进程（替换<PID>）：",
            "Stop-Process -Id <PID> -Force"
        ],
        "fix_description": "确认连接是否为正常软件行为（如云同步、聊天软件），非正常立即断网杀毒",
        "manual_step": "netstat -ano 查看可疑连接 → 定位PID → 任务管理器终止进程",
        "url": None
    },

    # === Temp 可疑文件 ===
    "temp_executable": {
        "severity": "medium",
        "title": "Temp目录存在近期修改的可执行文件",
        "diagnosis": "Temp目录中出现新程序可能是下载式木马",
        "fix_commands": [
            "## 先隔离（移动到隔离文件夹，勿直接删除）：",
            "New-Item -ItemType Directory -Path 'C:\\Quarantine' -Force",
            "Move-Item -Path '<文件路径>' -Destination 'C:\\Quarantine\\<filename>' -Force",
            "## 然后使用 Defender 扫描：",
            "Start-MpScan -ScanPath 'C:\\Quarantine'"
        ],
        "fix_description": "将可疑文件移到隔离文件夹，用杀毒软件扫描后再决定是否删除",
        "manual_step": "打开文件所在位置 → 不要直接运行 → 先用杀毒软件扫描",
        "url": None
    },

    # === 未打补丁 ===
    "missing_patches": {
        "severity": "medium",
        "title": "安全补丁长期未更新",
        "diagnosis": "超过3个月无安全更新，存在已公开漏洞利用风险",
        "fix_commands": [
            "## 手动检查更新：",
            "Start-Process ms-settings:windowsupdate",
            "## 或运行：",
            "Install-Module PSWindowsUpdate -Force",
            "Get-WindowsUpdate -Install -AcceptAll"
        ],
        "fix_description": "打开 Windows 更新安装所有待处理的安全更新，重启电脑",
        "manual_step": "设置 → Windows 更新 → 检查更新",
        "url": "ms-settings:windowsupdate"
    },
}


def generate_fixes(scan_issues: list, scan_config: dict) -> dict:
    """根据扫描问题生成修复方案"""
    fixes = {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "issues_fixed": [],
        "critical": [],
        "high": [],
        "medium": [],
        "all_commands": []
    }

    # 匹配问题到修复方案
    for issue in scan_issues:
        category = issue.get("category", "")
        severity = issue.get("severity", "low")
        title = issue.get("title", "")

        fix_key = None

        # 精确匹配
        if "defender" in title.lower() or "杀毒" in title:
            if "禁用" in title or "关闭" in title:
                fix_key = "defender_disabled"
            elif "过期" in title or "旧" in title:
                fix_key = "defender_outdated"
        elif "防火墙" in title and ("关闭" in title or "禁用" in title or "未开" in title):
            fix_key = "firewall_disabled"
        elif "SMB" in title or "永恒之蓝" in title:
            fix_key = "smb1_enabled"
        elif "RDP" in title or "远程桌面" in title and "启用" in title:
            fix_key = "rdp_enabled"
        elif "UAC" in title and ("关闭" in title or "禁用" in title):
            fix_key = "uac_disabled"
        elif "Guest" in title or "来宾" in title:
            fix_key = "guest_enabled"
        elif "管理员" in title and ("未知" in title or "可疑" in title):
            fix_key = "unknown_admin"
        elif category == "startup" or "自启动" in title:
            fix_key = "suspicious_startup"
        elif category == "network" or "外部连接" in title or "外部IP" in title:
            fix_key = "external_connection"
        elif category == "file" or "Temp" in title:
            fix_key = "temp_executable"
        elif "补丁" in title or "更新" in title:
            fix_key = "missing_patches"

        if fix_key and fix_key in ISSUE_FIX_DB:
            fix = ISSUE_FIX_DB[fix_key]
            fix_entry = {
                **issue,
                "fix_key": fix_key,
                "fix": fix,
                "commands": fix.get("fix_commands", []),
                "manual_step": fix.get("manual_step", ""),
                "url": fix.get("url", "")
            }
            fixes["issues_fixed"].append(fix_entry)
            fixes["all_commands"].extend(fix.get("fix_commands", []))

            if fix["severity"] == "critical":
                fixes["critical"].append(fix_entry)
            elif fix["severity"] == "high":
                fixes["high"].append(fix_entry)
            else:
                fixes["medium"].append(fix_entry)

    return fixes


def format_fixes_text(fixes: dict) -> str:
    """将修复方案格式化为可读文本"""
    lines = []
    lines.append("=" * 60)
    lines.append("  🔧 PC 安全问题修复方案")
    lines.append("=" * 60)
    lines.append(f"生成时间: {fixes['generated_at']}")
    lines.append(f"共 {len(fixes['issues_fixed'])} 个问题有对应修复方案")
    lines.append("")

    if fixes["critical"]:
        lines.append("🔴 紧急修复（立即处理）")
        lines.append("-" * 40)
        for item in fixes["critical"]:
            lines.append(f"\n⚠️ {item['title']}")
            lines.append(f"  问题: {item.get('detail', '')}")
            lines.append(f"  诊断: {item['fix']['diagnosis']}")
            lines.append("  修复命令:")
            for cmd in item["commands"]:
                lines.append(f"    > {cmd}")
            if item["manual_step"]:
                lines.append(f"  手动操作: {item['manual_step']}")
            if item["url"]:
                lines.append(f"  快捷入口: {item['url']}")
        lines.append("")

    if fixes["high"]:
        lines.append("🟠 高风险修复")
        lines.append("-" * 40)
        for item in fixes["high"]:
            lines.append(f"\n⚠️ {item['title']}")
            lines.append(f"  问题: {item.get('detail', '')}")
            lines.append(f"  诊断: {item['fix']['diagnosis']}")
            lines.append("  修复命令:")
            for cmd in item["commands"]:
                lines.append(f"    > {cmd}")
            if item["manual_step"]:
                lines.append(f"  手动操作: {item['manual_step']}")
        lines.append("")

    if fixes["medium"]:
        lines.append("🟡 中等风险修复")
        lines.append("-" * 40)
        for item in fixes["medium"]:
            lines.append(f"\n⚡ {item['title']}")
            lines.append(f"  诊断: {item['fix']['diagnosis']}")
            lines.append("  修复步骤: {item['manual_step']}")
        lines.append("")

    lines.append("")
    lines.append("=" * 60)
    lines.append("⚠️ 免责声明：运行修复命令前，请确认理解其作用。")
    lines.append("   如有疑问，请咨询专业人员。")
    lines.append("=" * 60)

    return "\n".join(lines)


if __name__ == "__main__":
    # 测试
    test_issues = [
        {"severity": "critical", "category": "config", "title": "SMBv1 协议已启用", "detail": "EnableSMB1Protocol=True"},
        {"severity": "high", "category": "config", "title": "RDP 已启用", "detail": "fDenyTSConnections=0"},
    ]
    fixes = generate_fixes(test_issues, {})
    print(format_fixes_text(fixes))
