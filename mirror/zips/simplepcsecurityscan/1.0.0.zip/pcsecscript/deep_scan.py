# -*- coding: utf-8 -*-
"""
PC Security Scanner - Deep Security Analysis
Windows 电脑深度安全扫描脚本
依赖：pip install psutil
运行方式：python pcsecscript/deep_scan.py
"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import subprocess
import json
import os
import hashlib
import socket
import struct
import time as time_module
from datetime import datetime
from pathlib import Path


try:
    import psutil
except ImportError:
    print("[ERROR] 需要安装 psutil: pip install psutil")
    sys.exit(1)

# ============ 配置 ============
REPORT_DIR = Path(__file__).parent.parent / "reports"
REPORT_DIR.mkdir(exist_ok=True)

# 历史目录：优先使用 WORKBUDDY 路径，回退到 ~/.workbuddy
WORKBUDDY_DIR = Path(os.environ.get("WORKBUDDY_DIR", str(Path.home() / ".workbuddy")))
HISTORY_DIR = WORKBUDDY_DIR / "security-scan" / "history"
HISTORY_DIR.mkdir(parents=True, exist_ok=True)

# 已知的可疑端口（非常用端口）
SUSPICIOUS_LOW_PORTS = {31337, 4444, 5555, 6666, 6667, 7777, 8888, 12345, 54321}

# 信任的发行商白名单（部分）
TRUSTED_SIGNERS = {
    "Microsoft Windows", "Microsoft Corporation", "Google LLC", "Tencent Technology",
    "Adobe Inc.", "Apple Inc.", "Intel Corporation", "NVIDIA Corporation",
    "Realtek Semiconductor", "Razer Inc."
}


# ============ 工具函数 ============

def get_internet_time() -> tuple:
    """
    通过 NTP 协议获取互联网 UTC 时间。
    返回 (internet_dt, offset_seconds, error_msg)
    offset_seconds = internet_time - local_time（正数表示本地慢于网络）
    """
    NTP_SERVERS = ["time.google.com", "time.cloudflare.com", "pool.ntp.org"]
    NTP_EPOCH = 2208988800  # 1900-01-01 00:00:00 到 1970-01-01 的秒数

    for server in NTP_SERVERS:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(4)
            # NTP Mode 3 (client) request packet (48 bytes, all zero)
            packet = b'\x1b' + b'\x00' * 47
            sock.sendto(packet, (server, 123))
            recv_data, _ = sock.recvfrom(48)
            sock.close()

            # 解析 NTP 响应：偏移量 40-43 为整数秒，44-47 为小数秒
            int_part = struct.unpack("!I", recv_data[40:44])[0]
            frac_part = struct.unpack("!I", recv_data[44:48])[0]
            ntp_seconds = int_part + frac_part / 2**32
            internet_ts = ntp_seconds - NTP_EPOCH
            from datetime import timezone
            internet_dt = datetime.fromtimestamp(internet_ts, tz=timezone.utc)
            local_dt = datetime.now(tz=timezone.utc)
            offset = (internet_dt - local_dt).total_seconds()
            return internet_dt, offset, None
        except Exception:
            continue

    # NTP 全部失败，尝试 HTTP 备选方案
    try:
        import urllib.request
        from datetime import timezone
        req = urllib.request.Request("https://www.google.com",
                                     headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            date_str = resp.headers.get("Date", "")
            internet_dt = datetime.strptime(date_str, "%a, %d %b %Y %H:%M:%S %Z").replace(tzinfo=timezone.utc)
            local_dt = datetime.now(tz=timezone.utc)
            offset = (internet_dt - local_dt).total_seconds()
            return internet_dt, offset, None
    except Exception:
        pass

    return None, 0, "无法连接 NTP 服务器，请检查网络"


def check_time_sync() -> dict:
    """
    检查本地时间与互联网时间的同步状态。
    误差超过 7 天（604800 秒）时标记为异常。
    """
    result = {
        "synced": True,
        "local_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "internet_time": None,
        "offset_seconds": 0,
        "offset_readable": "正常",
        "warning": None,
    }

    internet_dt, offset, err = get_internet_time()
    result["offset_seconds"] = round(offset, 1)

    if err:
        result["warning"] = f"⚠️ 无法获取网络时间：{err}，时间同步检查已跳过"
        return result

    result["internet_time"] = internet_dt.strftime("%Y-%m-%d %H:%M:%S (UTC)")

    # 转为可读
    abs_off = abs(offset)
    days = int(abs_off // 86400)
    hours = int((abs_off % 86400) // 3600)
    mins = int((abs_off % 3600) // 60)
    direction = "慢" if offset > 0 else "快"
    result["offset_readable"] = f"本地时间比网络时间{direction} {days}天{hours}时{mins}分"

    if abs_off > 604800:  # 7 days
        result["synced"] = False
        days_diff = round(abs_off / 86400, 1)
        result["warning"] = (
            f"⚠️ 系统时间严重偏差：本地时间与互联网时间相差约 {days_diff} 天！"
            " 这可能导致证书验证失败、加密操作异常、软件更新检查失败等问题。"
            " 请立即同步系统时间（控制面板 → 日期和时间 → 互联网时间 → 立即更新）。"
        )

    return result


def run_powershell(script: str) -> str:
    """执行 PowerShell 命令并返回输出"""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, timeout=60, encoding="utf-8", errors="replace"
        )
        return result.stdout + result.stderr
    except Exception as e:
        return f"[ERROR] {e}"


def compute_file_hash(filepath: str) -> str:
    """计算文件 SHA256 哈希"""
    try:
        h = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def get_process_info() -> list:
    """获取所有进程信息"""
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'exe', 'cpu_percent',
                                      'memory_info', 'create_time', 'num_threads']):
        try:
            pinfo = proc.info
            exe = pinfo['exe'] or ""
            processes.append({
                "pid": pinfo['pid'],
                "name": pinfo['name'],
                "exe": exe,
                "cpu": round(pinfo['cpu_percent'] or 0, 2),
                "mem_mb": round((pinfo['memory_info'].rss / 1024 / 1024), 1),
                "create_time": datetime.fromtimestamp(pinfo['create_time']).strftime("%Y-%m-%d %H:%M") if pinfo['create_time'] else "",
                "threads": pinfo['num_threads'],
                "hash": compute_file_hash(exe) if exe and os.path.isfile(exe) else ""
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return processes


def check_digital_signature(exe_path: str) -> dict:
    """检查可执行文件数字签名"""
    if not exe_path or not os.path.isfile(exe_path):
        return {"signed": False, "signer": "", "valid": False}

    script = f'''
    $sig = Get-AuthenticodeSignature -FilePath "{exe_path.replace('"', '`"')}"
    if ($sig.Status -eq "Valid") {{
        Write-Output "SIGNED|VALID|($($sig.SignerCertificate.Subject))"
    }} elseif ($sig.Status -eq "NotSigned") {{
        Write-Output "UNSIGNED|N/A|N/A"
    }} else {{
        Write-Output "INVALID|$($sig.Status)|N/A"
    }}
    '''
    output = run_powershell(script).strip()
    if "SIGNED|VALID|" in output:
        parts = output.split("|")
        signer = parts[2].strip("()") if len(parts) > 2 else ""
        return {"signed": True, "signer": signer, "valid": True}
    elif "UNSIGNED" in output:
        return {"signed": False, "signer": "", "valid": False}
    else:
        return {"signed": False, "signer": "", "valid": False}


def get_network_connections() -> list:
    """获取活动网络连接"""
    connections = []
    for conn in psutil.net_connections(kind='inet'):
        try:
            if conn.raddr:
                connections.append({
                    "proto": "TCP",
                    "laddr": f"{conn.laddr.ip}:{conn.laddr.port}",
                    "raddr": f"{conn.raddr.ip}:{conn.raddr.port}",
                    "state": str(conn.status),
                    "pid": conn.pid
                })
        except Exception:
            continue
    return connections


def check_established_external(conns: list) -> list:
    """检查是否有可疑的外部连接"""
    suspicious = []
    for conn in conns:
        if conn.get("state") == "ESTABLISHED":
            try:
                ip = conn["raddr"].split(":")[0]
                # 跳过本地和内网IP
                if ip.startswith(("127.", "10.", "172.16.", "172.17.",
                                  "172.18.", "172.19.", "172.20.", "172.21.",
                                  "172.22.", "172.23.", "172.24.", "172.25.",
                                  "172.26.", "172.27.", "172.28.", "172.29.",
                                  "172.30.", "172.31.", "192.168.", "::1")):
                    continue
                # 尝试反向DNS解析
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except Exception:
                    hostname = "未知"
                suspicious.append({**conn, "hostname": hostname, "ip": ip})
            except Exception:
                continue
    return suspicious


def scan_temp_executables() -> list:
    """扫描 Temp 目录中最近修改的可执行文件"""
    suspicious = []
    temp_paths = [
        os.path.join(os.environ.get("TEMP", ""), ""),
        os.path.join(os.environ.get("TMP", ""), ""),
        Path.home() / "Downloads",
        Path.home() / "AppData" / "Local" / "Temp"
    ]
    for temp in temp_paths:
        if not os.path.isdir(temp):
            continue
        try:
            for root, dirs, files in os.walk(temp):
                for f in files:
                    if f.lower().endswith((".exe", ".dll", ".bat", ".ps1", ".vbs", ".js", ".jar")):
                        fp = os.path.join(root, f)
                        try:
                            age_days = (datetime.now() - datetime.fromtimestamp(
                                os.path.getmtime(fp))).days
                            if age_days <= 7:
                                size_kb = round(os.path.getsize(fp) / 1024, 1)
                                suspicious.append({
                                    "file": fp,
                                    "name": f,
                                    "size_kb": size_kb,
                                    "age_days": age_days,
                                    "modified": datetime.fromtimestamp(
                                        os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M")
                                })
                        except Exception:
                            continue
        except Exception:
            continue
    return suspicious


def scan_registry_run() -> list:
    """扫描注册表自启动项"""
    run_keys = [
        r"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
        r"HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
        r"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
    ]
    items = []
    for key in run_keys:
        script = f'''
        $vals = Get-ItemProperty "{key}" -ErrorAction SilentlyContinue
        if ($vals) {{
            $vals.PSObject.Properties | Where-Object {{$_.Name -notlike "PS*"}} | ForEach-Object {{
                Write-Output "$($_.Name)|||{key}|||$($_.Value)"
            }}
        }}
        '''
        output = run_powershell(script)
        for line in output.strip().split("\n"):
            if line.strip() and "|||" in line:
                parts = line.strip().split("|||")
                if len(parts) >= 3:
                    items.append({
                        "name": parts[0],
                        "path": key,
                        "command": parts[2]
                    })
    return items


def analyze_issues(processes: list, connections: list, temp_files: list,
                   run_items: list, external_conns: list, sig_results: dict) -> dict:
    """综合分析，生成发现列表"""
    issues = []

    # 1. 无签名的高CPU进程
    for p in processes:
        if p["cpu"] > 50:
            exe = p["exe"]
            if not exe:
                issues.append({
                    "severity": "medium",
                    "category": "process",
                    "title": f"高CPU进程（无路径）: {p['name']}",
                    "detail": f"PID: {p['pid']}, CPU: {p['cpu']}%, 内存: {p['mem_mb']}MB",
                    "recommendation": "确认该进程是否为预期进程，否则建议终止并使用杀毒软件扫描"
                })
            elif os.path.isfile(exe):
                sig = sig_results.get(exe, {})
                if not sig.get("signed"):
                    issues.append({
                        "severity": "high",
                        "category": "process",
                        "title": f"高CPU无签名进程: {p['name']}",
                        "detail": f"PID: {p['pid']}, CPU: {p['cpu']}%, 路径: {exe}",
                        "recommendation": "⚠️ 该进程无数字签名且CPU占用高，建议立即使用杀毒软件扫描"
                    })

    # 2. 异常外部连接
    if external_conns:
        for conn in external_conns[:5]:
            issues.append({
                "severity": "high",
                "category": "network",
                "title": f"可疑外部连接: {conn['ip']}",
                "detail": f"进程PID: {conn['pid']}, 目标: {conn['hostname']}, 状态: {conn['state']}",
                "recommendation": f"确认与 {conn['ip']} 的连接是否为预期行为，如非预期建议断网并杀毒"
            })

    # 3. Temp目录可疑文件
    if temp_files:
        for tf in temp_files[:5]:
            issues.append({
                "severity": "medium",
                "category": "file",
                "title": f"Temp目录新可执行文件: {tf['name']}",
                "detail": f"路径: {tf['file']}, 大小: {tf['size_kb']}KB, 修改: {tf['modified']}",
                "recommendation": "如非预期安装程序，建议删除该文件并全盘杀毒"
            })

    # 4. 异常自启动项（无签名）
    for item in run_items:
        cmd = item.get("command", "")
        if any(t in cmd.lower() for t in ["temp", "download", "tmp", "appdata\\local\\temp"]):
            sig = sig_results.get(cmd.split()[0] if cmd else "", {})
            if not sig.get("signed"):
                issues.append({
                    "severity": "high",
                    "category": "startup",
                    "title": f"可疑自启动项: {item['name']}",
                    "detail": f"注册表路径: {item['path']}, 命令: {cmd}",
                    "recommendation": "⚠️ 自启动项位于可疑路径且无签名，建议禁用并排查"
                })

    return issues


def generate_summary(processes: list, connections: list, external_conns: list,
                     temp_files: list, run_items: list, issues: list) -> dict:
    """生成扫描摘要"""
    return {
        "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_processes": len(processes),
        "high_cpu_processes": len([p for p in processes if p["cpu"] > 50]),
        "network_connections": len(connections),
        "external_connections": len(external_conns),
        "temp_suspicious_files": len(temp_files),
        "startup_items": len(run_items),
        "issues_found": len(issues),
        "high_issues": len([i for i in issues if i["severity"] == "high"]),
        "medium_issues": len([i for i in issues if i["severity"] == "medium"]),
        "low_issues": len([i for i in issues if i["severity"] == "low"]),
    }


# ============ 主扫描流程 ============

def deep_scan() -> dict:
    """执行深度扫描"""
    print("[*] 开始深度安全扫描...")
    results = {}

    print("[0/6] 检查时间同步状态...")
    time_check = check_time_sync()
    results["time_check"] = time_check
    if time_check.get("warning"):
        print(f"    ⚠️ {time_check['warning'][:60]}...")
    else:
        print(f"    ✅ 时间同步正常，偏差: {time_check.get('offset_readable', '正常')}")

    print("[1/6] 采集进程信息...")
    processes = get_process_info()
    results["processes"] = processes
    print(f"    采集到 {len(processes)} 个进程")

    print("[2/6] 采集网络连接...")
    connections = get_network_connections()
    external = check_established_external(connections)
    results["connections"] = connections
    results["external_connections"] = external
    print(f"    {len(connections)} 个连接，{len(external)} 个外部连接")

    print("[3/6] 扫描 Temp 目录可疑文件...")
    temp_files = scan_temp_executables()
    results["temp_files"] = temp_files
    print(f"    发现 {len(temp_files)} 个近期修改的可执行文件")

    print("[4/6] 扫描注册表自启动项...")
    run_items = scan_registry_run()
    results["run_items"] = run_items
    print(f"    发现 {len(run_items)} 个自启动项")

    print("[5/6] 检查数字签名（高风险进程）...")
    sig_results = {}
    high_cpu_procs = [p for p in processes if p["cpu"] > 30 and p["exe"]]
    for p in high_cpu_procs[:20]:
        exe = p["exe"]
        if exe and os.path.isfile(exe):
            sig_results[exe] = check_digital_signature(exe)
    results["signatures"] = sig_results
    print(f"    检查了 {len(sig_results)} 个文件签名")

    print("[6/6] 综合分析...")
    issues = analyze_issues(processes, connections, temp_files, run_items, external, sig_results)
    results["issues"] = issues
    results["summary"] = generate_summary(processes, connections, external, temp_files, run_items, issues)

    print(f"\n[✓] 扫描完成，发现 {len(issues)} 个问题")
    return results


def save_results(results: dict, scan_type: str = "deep") -> str:
    """保存扫描结果到历史目录"""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = HISTORY_DIR / f"scan_{scan_type}_{ts}.json"
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 维护历史文件（保留最近30份）
    all_scans = sorted(HISTORY_DIR.glob("scan_*.json"), key=os.path.getmtime, reverse=True)
    for old in all_scans[30:]:
        old.unlink(missing_ok=True)

    return str(filepath)


def compare_with_history(current: dict) -> dict:
    """与上次扫描结果对比"""
    all_scans = sorted(HISTORY_DIR.glob("scan_*.json"), key=os.path.getmtime, reverse=True)
    if len(all_scans) < 2:
        return {"available": False, "reason": "历史数据不足（少于2份）"}

    prev_path = all_scans[1]
    try:
        with open(prev_path, "r", encoding="utf-8") as f:
            prev = json.load(f)
    except Exception:
        return {"available": False, "reason": "无法读取历史文件"}

    curr_summary = current.get("summary", {})
    prev_summary = prev.get("summary", {})

    changes = {
        "available": True,
        "previous_scan": prev_path.name,
        "prev_time": prev.get("summary", {}).get("scan_time", ""),
        "curr_time": curr_summary.get("scan_time", ""),
        "process_change": curr_summary.get("total_processes", 0) - prev_summary.get("total_processes", 0),
        "external_conn_change": curr_summary.get("external_connections", 0) - prev_summary.get("external_connections", 0),
        "issue_change": curr_summary.get("issues_found", 0) - prev_summary.get("issues_found", 0),
        "temp_file_change": curr_summary.get("temp_suspicious_files", 0) - prev_summary.get("temp_suspicious_files", 0),
    }

    # 新出现的外部连接
    curr_external = {c["ip"] for c in current.get("external_connections", [])}
    prev_external = {c["ip"] for c in prev.get("external_connections", [])}
    changes["new_external_ips"] = list(curr_external - prev_external)
    changes["removed_external_ips"] = list(prev_external - curr_external)

    # 新出现的问题
    curr_issues = {(i["category"], i["title"]) for i in current.get("issues", [])}
    prev_issues = {(i["category"], i["title"]) for i in prev.get("issues", [])}
    changes["new_issues"] = list(curr_issues - prev_issues)
    changes["resolved_issues"] = list(prev_issues - curr_issues)

    return changes


if __name__ == "__main__":
    print("=" * 50)
    print("  PC Security Deep Scan")
    print("=" * 50)
    results = deep_scan()
    save_results(results)
    comparison = compare_with_history(results)

    print("\n--- 历史对比 ---")
    if comparison.get("available"):
        print(f"对比时间: {comparison['prev_time']} vs {comparison['curr_time']}")
        print(f"进程数变化: {comparison['process_change']:+d}")
        print(f"外部连接变化: {comparison['external_conn_change']:+d}")
        print(f"问题数量变化: {comparison['issue_change']:+d}")
        if comparison.get("new_external_ips"):
            print(f"⚠️ 新增外部IP: {comparison['new_external_ips']}")
        if comparison.get("new_issues"):
            print(f"⚠️ 新发现问题: {len(comparison['new_issues'])} 项")
        if comparison.get("resolved_issues"):
            print(f"✓ 已解决问题: {len(comparison['resolved_issues'])} 项")
    else:
        print(f"无法对比: {comparison.get('reason', '')}")

    print(f"\n历史记录已保存至: {HISTORY_DIR}")
