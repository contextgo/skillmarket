---
name: pc-security-scan
description: >
  Windows 电脑安全扫描与体检。支持漏洞、木马、可疑程序、不安全配置检测，
  深度扫描（含哈希/签名/外部连接），历史对比，HTML报告导出，定时体检。
  触发词：安全扫描、电脑体检、查漏洞、查木马、扫毒、检测电脑安全、系统安全检查、
  电脑有没有问题、扫描我的电脑、深度扫描、全面体检、安全报告。
  适用系统：Windows（PowerShell + Python 3）。
---

# PC Security Scan — Windows 电脑安全扫描

对 Windows 系统执行全面的本地安全扫描，支持浅层扫描、深度扫描、历史对比、HTML 报告导出和定时体检。

> **⚠️ 注意**：本扫描基于 Windows 原生工具和 Python（psutil），属于安全检查，**不能替代专业杀毒软件**。

---

## 功能概览

| 功能 | 说明 |
|------|------|
| 🟢 快速扫描 | PowerShell 原生命令，10+ 安全维度 |
| 🔬 深度扫描 | Python 脚本：哈希/签名/网络/文件分析 |
| 📊 历史对比 | 与上次扫描对比，发现配置变化 |
| 📄 HTML 报告 | 完整可视化报告，含图表和分 tab 展示 |
| ⏰ 定时体检 | 自动创建每周/每月体检自动化任务 |

---

## 执行方式

### 方式一：快速扫描（日常使用）

用户说"安全扫描"、"电脑体检"时，执行 Step 1-10 的 PowerShell 命令，无需 Python。

### 方式二：深度扫描（发现问题/生成报告时使用）

用户说"深度扫描"、"全面体检"、"安全报告"时：

```powershell
# 获取 Python 路径（兼容 WorkBuddy 和直接安装的 Python）
$PYTHON = if (Test-Path "$env:USERPROFILE\.workbuddy\binaries\python\versions\3.13.12\python.exe") {
    "$env:USERPROFILE\.workbuddy\binaries\python\versions\3.13.12\python.exe"
} else { "python" }

# 1. 运行深度扫描
powershell -NoProfile -Command "& `$PYTHON `"$PSScriptRoot\pcsecscript\deep_scan.py`""

# 2. 生成 HTML 报告
powershell -NoProfile -Command "& `$PYTHON `"$PSScriptRoot\pcsecscript\generate_report.py`""

# 3. 生成修复建议
powershell -NoProfile -Command "& `$PYTHON `"$PSScriptRoot\pcsecscript\auto_fix.py`""
```

### 方式三：定时体检

用户说"每周体检"、"每月扫描"、"设置自动体检"时，使用 `automation_update` tool 创建自动化任务：
- **每周体检**：FREQ=WEEKLY;BYDAY=SA;BYHOUR=10;BYMINUTE=0（每周六上午10点）
- **每月体检**：FREQ=MONTHLY（每月1号）
- Prompt 内容：执行深度扫描 + 生成 HTML 报告
- 产物路径：`{skill_dir}\pcsecscript\`（相对于本 Skill 目录）

---

## 快速扫描流程（PowerShell）

### Step 1：系统基础信息
```powershell
whoami
Get-WmiObject Win32_OperatingSystem | Select-Object Caption, BuildNumber, OSArchitecture | Format-List
```

### Step 2：杀毒软件
```powershell
Get-MpComputerStatus | Select-Object AntivirusEnabled, RealTimeProtectionEnabled, AntivirusSignatureLastUpdated, AntivirusSignatureVersion | Format-List
Get-WmiObject -Namespace root\SecurityCenter2 -Class AntiVirusProduct | Select-Object displayName, productState, timestamp | Format-List
```
**判断**：AntivirusEnabled + RealTimeProtectionEnabled = True → ✅；无杀毒软件 → 🔴 紧急

### Step 3：防火墙
```powershell
Get-NetFirewallProfile | Select-Object Name, Enabled | Format-Table -AutoSize
Get-NetTCPConnection | Where-Object {$_.State -eq 'Listen'} | Select-Object LocalAddress, LocalPort, OwningProcess | Sort-Object LocalPort
```

### Step 4：可疑进程
```powershell
Get-Process | Where-Object {$_.CPU -gt 100} | Select-Object Name, Id, CPU, @{N='Mem(MB)';E={[math]::Round($_.WorkingSet64/1MB,1)}}, Path | Sort-Object CPU -Descending | Select-Object -First 20 | Format-Table -AutoSize
```

### Step 5：自启动项
```powershell
Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location, User | Format-Table -AutoSize
```

### Step 6：计划任务
```powershell
Get-ScheduledTask | Where-Object {$_.State -ne 'Disabled'} | Select-Object TaskName, State, TaskPath | Select-Object -First 50 | Format-Table -AutoSize
```

### Step 7：系统安全配置
```powershell
# UAC
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" | Select-Object EnableLUA, ConsentPromptBehaviorAdmin | Format-List

# RDP
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" | Select-Object fDenyTSConnections

# SMBv1
Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol, EnableSMB2Protocol | Format-List
```

### Step 8：用户账户
```powershell
Get-CimInstance Win32_UserAccount | Where-Object {$_.LocalAccount -eq $true} | Select-Object Name, Disabled, Description | Format-Table -AutoSize
```

### Step 9：安全补丁
```powershell
Get-WmiObject -Class Win32_QuickFixEngineering | Sort-Object InstalledOn -Descending | Select-Object -First 10 Description, HotFixID, InstalledOn | Format-Table -AutoSize
```

### Step 10：远程控制软件
```powershell
Get-Service | Where-Object {$_.Status -eq "Running" -and $_.DisplayName -match "teamviewer|anydesk|vnc|logmein"} | Select-Object Name, DisplayName | Format-Table -AutoSize
```

---

## 深度扫描说明（Python）

`pcsecscript/deep_scan.py` 执行以下分析：

| 模块 | 内容 |
|------|------|
| 时间同步检查 | 启动时自动查询 NTP 服务器（Google/Cloudflare/官方NTP池），与本地时间对比；偏差超过 7 天则在报告中醒目警告 |
| 进程分析 | 采集所有进程 CPU/内存/路径/SHA256哈希 |
| 签名检查 | 对高 CPU 进程进行 Authenticode 数字签名验证 |
| 网络分析 | 采集所有 TCP 连接，识别外部（非内网）连接 |
| Temp 扫描 | 扫描 Temp/Download 目录中 7 天内修改的可执行文件 |
| 注册表扫描 | 采集 HKLM/HKCU 所有自启动项 |
| 综合分析 | 按严重程度分类问题（critical/high/medium/low） |
| 历史对比 | 与上次扫描对比，发现新增/消失的风险项 |

---

## 自动修复建议

发现安全问题后，运行 `pcsecscript/auto_fix.py` 生成修复方案：

```powershell
# 获取 Python 并运行（兼容 WorkBuddy 和系统 Python）
$PYTHON = if (Test-Path "$env:USERPROFILE\.workbuddy\binaries\python\versions\3.13.12\python.exe") {
    "$env:USERPROFILE\.workbuddy\binaries\python\versions\3.13.12\python.exe"
} else { "python" }
powershell -NoProfile -Command "& `$PYTHON `"$PSScriptRoot\pcsecscript\auto_fix.py`""
```

已内置以下问题的修复命令：

| 问题类型 | 修复内容 |
|----------|----------|
| Windows Defender 已禁用 | 启用实时保护 |
| 防火墙未开启 | 启用三网防火墙 |
| SMBv1 启用（永恒之蓝） | 禁用 SMBv1 协议 |
| RDP 已开启 | 禁用远程桌面 |
| UAC 已禁用 | 恢复 UAC 设置 |
| Guest 账户未禁用 | 禁用 Guest 账户 |
| 可疑自启动项 | 定位并提供删除命令 |
| 可疑外部连接 | 定位进程并提供断网方案 |
| Temp 可执行文件 | 隔离+杀毒扫描 |
| 安全补丁过期 | 打开 Windows 更新 |

---

## 历史对比说明

深度扫描结果自动保存在：
`~/.workbuddy/security-scan/history/scan_*.json`

对比内容：
- 进程数变化
- 外部连接变化（新增/消失的外部 IP）
- 问题数量变化（新增/已解决的问题）
- 可疑文件变化

---

## HTML 报告说明

运行 `pcsecscript/generate_report.py` 生成自包含的 HTML 报告，包含：
- ⏰ 时间同步警告（启动时自动比对 NTP 时间，偏差 >7 天显示红色醒目警告）
- 🛡️ 安全评分圆环（0-100分）
- 📊 历史对比图表
- ⚠️ 问题列表（按严重程度分级）
- 🖥️ 进程 CPU 占用 TOP15
- 🌐 外部网络连接详情
- 🚀 自启动项列表（可疑项标红）
- 📁 Temp 目录可疑文件

报告保存在：`{skill_dir}\reports\`（相对于本 Skill 目录）

---

## 免责声明

本扫描基于 PowerShell / Python psutil 原生命令，仅提供**参考性安全评估**，不能替代：
1. Windows Defender 离线扫描
2. Malwarebytes / ESET 等专业杀软的深度扫描
3. 如有疑似木马，请备份数据后重装系统

---

## 踩坑经验

（以下由 AI 在实际使用中自动积累，请勿手动删除）



> **注意**：本扫描基于 Windows 原生工具（PowerShell / WMI），属于浅层安全检查，**无法替代专业杀毒软件**（如 Malwarebytes、ESET）。如需深度检测，请运行专业杀毒软件全盘扫描。

## 扫描维度

本 Skill 覆盖以下安全维度：

| 编号 | 维度 | 说明 |
|------|------|------|
| 1 | 🛡️ 杀毒软件状态 | Defender 是否启用、病毒库是否最新 |
| 2 | 🔥 防火墙状态 | 三网（域/专用/公用）防火墙是否启用 |
| 3 | 🚪 开放端口 | 监听端口是否异常（非标准端口、非系统服务端口） |
| 4 | 🕵️ 可疑进程 | CPU/内存占用异常的进程 |
| 5 | 🚀 自启动项 | 注册表/启动文件夹中的自启动程序 |
| 6 | ⏰ 计划任务 | 可疑的定时任务 |
| 7 | 🔐 系统安全配置 | UAC、RDP、SMBv1、Admin 账户等 |
| 8 | 👤 用户账户 | 多余管理员账户、Guest 是否禁用 |
| 9 | 🩹 安全补丁 | 最近安全更新是否安装 |
| 10 | 💻 远程控制软件 | TeamViewer/VNC/AnyDesk 等是否运行 |

## 执行步骤

### Step 1：系统基础信息

```powershell
whoami
Get-WmiObject Win32_OperatingSystem | Select-Object Caption, BuildNumber, OSArchitecture
```

获取当前用户名和系统版本。

---

### Step 2：杀毒软件状态

```powershell
Get-MpComputerStatus | Select-Object AntivirusEnabled, RealTimeProtectionEnabled, AntivirusSignatureLastUpdated, AntivirusSignatureVersion | Format-List
Get-WmiObject -Namespace root\SecurityCenter2 -Class AntiVirusProduct | Select-Object displayName, productState, timestamp | Format-List
```

**判断标准**：
- `AntivirusEnabled = True` → ✅ 杀毒软件已启用
- `RealTimeProtectionEnabled = True` → ✅ 实时保护已启用
- 病毒库更新超过 7 天 → ⚠️ 建议更新
- 未检测到任何杀毒软件 → 🔴 高风险

---

### Step 3：防火墙状态

```powershell
Get-NetFirewallProfile | Select-Object Name, Enabled | Format-Table -AutoSize
Get-NetTCPConnection | Where-Object {$_.State -eq 'Listen'} | Select-Object LocalAddress, LocalPort, OwningProcess | Sort-Object LocalPort
```

**判断标准**：
- 三种网络配置文件的 `Enabled` 应全为 `True`
- 开放端口：低于 1024 的端口需确认为系统服务；高位端口（>49152）若无对应进程名需警惕

---

### Step 4：可疑进程（高 CPU/内存）

```powershell
Get-Process | Where-Object {$_.CPU -gt 100} | Select-Object Name, Id, CPU, @{N='Mem(MB)';E={[math]::Round($_.WorkingSet64/1MB,1)}}, Path | Sort-Object CPU -Descending | Select-Object -First 20 | Format-Table -AutoSize
```

**判断标准**：
- 无数字签名或路径指向 `Temp` / `AppData\Local\Temp` / `Downloads` 的进程 → 🔴 需进一步排查
- 已知正常软件（浏览器、IDE、WorkBuddy）占用高 CPU → ✅ 属正常现象

---

### Step 5：自启动项

```powershell
Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location, User | Format-Table -AutoSize
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" 2>$null | Format-Table -AutoSize
Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" 2>$null | Format-Table -AutoSize
```

**判断标准**：
- 自启动项应全部来自可信来源（系统自带、知名字软件）
- 路径含 `Temp`、`Download`、`未知目录` 的自启动项 → 🔴 需排查

---

### Step 6：计划任务（可疑）

```powershell
Get-ScheduledTask | Where-Object {$_.State -ne 'Disabled'} | Select-Object TaskName, State, TaskPath | Select-Object -First 50 | Format-Table -AutoSize
```

**判断标准**：
- 名称含乱码、未知字符的任务 → 🔴 需排查
- 路径为 `C:\Users\<用户名>\AppData\Local\` 的用户计划任务 → ⚠️ 需确认来源
- 微软官方任务（`\Microsoft\`）→ ✅ 通常安全

---

### Step 7：系统安全配置

#### UAC（用户账户控制）
```powershell
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" | Select-Object EnableLUA, ConsentPromptBehaviorAdmin, FilterAdministratorToken | Format-List
```
- `EnableLUA = 1` → ✅ 已启用
- `ConsentPromptBehaviorAdmin = 2`（默认）或 `3`（始终通知）→ ✅ 安全

#### 远程桌面（RDP）
```powershell
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" | Select-Object fDenyTSConnections
```
- `fDenyTSConnections = 1` → ✅ RDP 已禁用（安全）
- `fDenyTSConnections = 0` → 🔴 RDP 已开启，需评估风险

#### SMBv1 协议（永恒之蓝漏洞）
```powershell
Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol, EnableSMB2Protocol | Format-List
```
- `EnableSMB1Protocol = False` → ✅ 已禁用
- `EnableSMB1Protocol = True` → 🔴 高危漏洞，需立即禁用

---

### Step 8：用户账户

```powershell
Get-CimInstance Win32_UserAccount | Where-Object {$_.LocalAccount -eq $true} | Select-Object Name, Disabled, PasswordRequired, Description | Format-Table -AutoSize
```

**判断标准**：
- `Administrator` / `Guest` 账户应为 `Disabled = True`
- 存在未知本地管理员账户 → 🔴 需排查
- `guofe`（当前用户）账户应为 `Disabled = False` → ✅ 正常

---

### Step 9：安全补丁

```powershell
Get-WmiObject -Class Win32_QuickFixEngineering | Sort-Object InstalledOn -Descending | Select-Object -First 10 Description, HotFixID, InstalledOn | Format-Table -AutoSize
```

**判断标准**：
- 最近 30 天内有安全更新记录 → ✅ 系统更新正常
- 无任何安全更新记录超过 3 个月 → ⚠️ 建议运行 Windows Update

---

### Step 10：远程控制软件

```powershell
Get-Service | Where-Object {$_.Status -eq "Running" -and $_.DisplayName -match "teamviewer|anydesk|vnc|teamviewer|logmein|supremo|rmgrp"} | Select-Object Name, DisplayName, Status | Format-Table -AutoSize
Get-Process | Where-Object {$_.ProcessName -match "teamviewer|anydesk|vnc|teamviewer|logmein|supremo"} | Select-Object Name, Id, Path | Format-Table -AutoSize
```

**判断标准**：
- 如用户未安装此类软件但检测到相关进程 → 🔴 需立即排查
- 如用户正常使用远程协助 → ✅ 属正常，需确认来源可信

---

## 输出格式

扫描完成后，按以下格式整理结果：

### 安全总评

```
🟢 安全状况良好  /  🟡 发现若干风险项  /  🔴 存在高危问题
```

### 各维度结果

| 维度 | 状态 | 说明 |
|------|------|------|
| 杀毒软件 | ✅/⚠️/🔴 | ... |
| 防火墙 | ✅/⚠️/🔴 | ... |
| 开放端口 | ✅/⚠️/🔴 | ... |
| 可疑进程 | ✅/⚠️/🔴 | ... |
| 自启动项 | ✅/⚠️/🔴 | ... |
| 计划任务 | ✅/⚠️/🔴 | ... |
| 系统安全配置 | ✅/⚠️/🔴 | ... |
| 用户账户 | ✅/⚠️/🔴 | ... |
| 安全补丁 | ✅/⚠️/🔴 | ... |
| 远程控制软件 | ✅/⚠️/🔴 | ... |

### 建议操作

按严重程度列出修复建议。

---

## 进阶扫描（可选）

如用户需要更深度检测，可执行：

### a) 事件日志（需管理员权限）
```powershell
# 最近登录失败事件（需提升权限，如权限不足则跳过）
Get-WinEvent -LogName 'Security' -MaxEvents 20 -FilterHashtable @{Id=4625} 2>$null | Select-Object TimeCreated, Id, Message | Format-List
```

### b) 最近修改的可执行文件
```powershell
Get-ChildItem "C:\Users\$env:USERNAME\AppData\Local\Temp" -Recurse -Include *.exe,*.dll,*.bat,*.ps1 -ErrorAction SilentlyContinue | Where-Object {$_.LastWriteTime -gt (Get-Date).AddDays(-7)} | Select-Object FullName, LastWriteTime | Sort-Object LastWriteTime -Descending | Select-Object -First 20
```

### c) 异常网络连接（ESTABLISHED 状态）
```powershell
Get-NetTCPConnection | Where-Object {$_.State -eq 'Established'} | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, OwningProcess | Select-Object -First 20 | Format-Table -AutoSize
```

---

## 免责声明

本扫描基于 Windows 原生命令，仅提供系统安全状态的**参考性评估**，不能替代专业安全软件的全盘扫描。如发现高危问题，请：
1. 使用 Windows Defender 离线扫描
2. 使用 Malwarebytes Anti-Malware 进行补充扫描
3. 如有疑似木马，备份重要数据后重装系统

---

## 踩坑经验

（以下由 AI 在实际使用中自动积累，请勿手动删除）

