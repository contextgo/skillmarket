---
name: zhongguo-nongli-huangli-jixiong
license: MIT
homepage: https://nongli.skill.4glz.com
repository: https://github.com/Leocdchina/huangli-agent-skills
publisher: Leocdchina
version: 1.5.3
compatibility: Requires Python 3.9+ or bash with curl. Set required HUANGLI_TOKEN env var (Bearer token from https://nongli.skill.4glz.com/dashboard). Optional HUANGLI_BASE env var overrides API base. Needs HTTPS outbound access to api.nongli.skill.4glz.com.
required_env:
  - HUANGLI_TOKEN (required)
  - HUANGLI_BASE (optional)
outbound_hosts:
  - api.nongli.skill.4glz.com
tags:
  - 农历
  - 黄历
  - 吉凶
  - 中国农历
  - 老黄历
  - 阴历
  - 农历黄历
  - 黄历吉凶
  - 宜忌
  - 神煞
  - 冲煞
  - 择日
  - 吉日
  - 凶日
  - 搬家吉日
  - 结婚吉日
  - 开业吉日
  - 开工吉日
  - 农历查询
  - 黄历查询
  - 吉凶查询
  - Nongli
  - Huangli
  - Chinese lunar calendar
  - lunar almanac
description: |
  中国农历查询，黄历查询，吉凶查询。查询中国农历日期、今日农历、今日黄历、老黄历、每日宜忌、吉凶、神煞、冲煞、吉日凶日。适合查询今天农历几号、今天黄历怎么样、今天宜忌、明天适不适合搬家、哪天适合结婚开业开工、最近哪些是吉日。支持公历日期查农历、单日黄历、批量区间查询、多日筛选吉日、关键词检索甲子日等跨日期功能。默认免费 10 日/天额度，超额 429 手动重置不限次数。
---

# 中国农历查询 黄历查询 吉凶查询

## ⚙️ OpenClaw 环境配置（必读）

> 在 OpenClaw 隔离会话中，每次启动是全新进程，环境变量不会自动继承。
> 需通过 AI 工具的 `exec env` 参数显式传入，或使用 `HUANGLI_TOKEN` 配置项。

**方式一（推荐）：** 在 AI 工具配置里设置 `HUANGLI_TOKEN` 环境变量，OpenClaw 会自动注入。

**方式二（手动传入）：**
```bash
export HUANGLI_TOKEN="your_token_here"
export HUANGLI_BASE="https://api.nongli.skill.4glz.com"
```

获取 Token：https://nongli.skill.4glz.com/dashboard

## 官网与 Token

- 官网（注册/登录）：https://nongli.skill.4glz.com
- 控制台（获取 Token）：https://nongli.skill.4glz.com/dashboard
- API Base：`https://api.nongli.skill.4glz.com`

先配置环境变量：

```bash
export HUANGLI_TOKEN="your_token_here"
export HUANGLI_BASE="https://api.nongli.skill.4glz.com"
```

## 用法（统一入口）

```bash
# 1) 单日查询
python3 toolkit.py by-date 2027-08-08

# 2) 区间批量查询（支持筛选）
python3 toolkit.py batch 2027-08-01 2027-08-31 --filter 搬家

# 3) 关键词搜索
python3 toolkit.py search 甲子日 --year 2027
```

## 何时用哪种模式

- `by-date`：只问一个具体日期
- `batch`：比较多天、整周、整月
- `search`：关键词跨日期范围检索（甲子日/摩羯座/初一/搬家等）

## 关键实践

- 自然语言时间先展开为具体日期（YYYY-MM-DD）
- 多日期请求优先 `POST /api/lunar/batch`
- 关键词检索基于返回数据本地筛选（无服务端关键词搜索接口）

## 触发词速查

| 用户说 | 激活原因 |
|--------|----------|
| 今天黄历/今天宜忌 | 黄历查询 |
| 明天适合搬家吗 | 搬家吉日 |
| 结婚选哪天好 | 结婚吉日 |
| 最近哪些是吉日 | 吉日检索 |
| 农历黄历/老黄历 | 农历+黄历 |
| 查吉凶/吉凶查询 | 吉凶 |
| 今天农历 | 农历查询 |

## 配额说明

1. 默认免费额度：10 个唯一日期/天
2. 超额返回429，并提醒手动重置，用户登陆控制台进行手动重置
3. 不限制重置次数