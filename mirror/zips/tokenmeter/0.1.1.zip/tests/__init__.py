"""Tests for tokenmeter."""
