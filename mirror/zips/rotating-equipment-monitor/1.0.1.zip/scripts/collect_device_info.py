#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
collect_device_info.py
C-IDMS 智能设备管理系统 - 旋转设备基本信息采集汇总工具
版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷
官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn

此脚本用于：
1. 以 JSON 格式接收已收集的设备信息
2. 验证必填字段完整性
3. 输出设备信息汇总报告
4. 推荐适用的振动评估标准和分级限值

用法（从 JSON 文件）：
    python scripts/collect_device_info.py --input device_info.json

用法（从命令行参数）：
    python scripts/collect_device_info.py \
        --name "循环水泵P-101A" \
        --type "泵" \
        --speed 1480 \
        --power 110 \
        --bearing-type "滚动轴承" \
        --installation "卧式"
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path


# 设备类型与推荐适用标准映射
STANDARDS_BY_TYPE = {
    "泵": {
        "primary": "ISO 20816-3:2022 / GB/T 41850.1-2024",
        "shaft": "ISO 7919-3",
        "condition": "GB/T 19873.3-2019",
        "notes": "泵类设备通常使用外壳振动速度（mm/s RMS）作为主评估参数",
    },
    "风机": {
        "primary": "ISO 20816-3:2022 / GB/T 41850.1-2024",
        "shaft": "ISO 7919-3",
        "condition": "GB/T 19873.3-2019",
        "notes": "风机叶片不平衡是主要故障源，重点关注1X分量",
    },
    "压缩机": {
        "primary": "ISO 20816-4:2018 / ISO 20816-6:2016",
        "shaft": "ISO 7919-4",
        "condition": "GB/T 19873.3-2019 / API 670",
        "notes": "压缩机推荐同时监测轴振位移（μm pp）和壳体振动速度",
    },
    "电机": {
        "primary": "ISO 20816-3:2022 / GB/T 41850.1-2024",
        "shaft": "ISO 7919-3",
        "condition": "GB/T 19873.3-2019",
        "notes": "电机需关注电磁频率（2×电源频率=100Hz）引起的振动",
    },
    "汽轮机": {
        "primary": "ISO 20816-2:2017 / ISO 7919-2",
        "shaft": "GB/T 11348.2-2012",
        "condition": "GB/T 19873.3-2019",
        "notes": "汽轮机必须同时监测轴振（位移）和瓦振（速度/加速度）",
    },
    "减速机": {
        "primary": "ISO 20816-3:2022",
        "shaft": "—",
        "condition": "GB/T 19873.3-2019",
        "notes": "减速机重点关注齿轮啮合频率（GMF = 齿数×转速/60）",
    },
}

# 功率-振动等级分类（ISO 20816-3）
def get_vibration_zone_limits(power_kw: float, bearing_type: str) -> dict:
    """根据功率和轴承类型返回振动速度分区限值（mm/s RMS）"""
    if bearing_type == "滑动轴承":
        # 滑动轴承机器（通常大型机组）
        if power_kw > 300:
            return {"A": 2.8, "B": 5.3, "C": 8.5, "unit": "mm/s RMS (壳体)", "standard": "ISO 20816-3 Class I"}
        else:
            return {"A": 2.3, "B": 4.5, "C": 7.1, "unit": "mm/s RMS (壳体)", "standard": "ISO 20816-3 Class II"}
    else:
        # 滚动轴承机器
        if power_kw > 300:
            return {"A": 2.8, "B": 5.3, "C": 8.5, "unit": "mm/s RMS", "standard": "ISO 20816-3 Class I"}
        elif power_kw >= 15:
            return {"A": 2.3, "B": 4.5, "C": 7.1, "unit": "mm/s RMS", "standard": "ISO 20816-3 Class II"}
        else:
            return {"A": 1.4, "B": 2.8, "C": 4.5, "unit": "mm/s RMS", "standard": "ISO 20816-3 Class III (小型机)"}


def validate_device_info(info: dict) -> list[str]:
    """验证设备信息完整性，返回缺失字段列表"""
    required_fields = {
        "device_name": "设备名称",
        "device_type": "设备类型",
        "rated_speed": "额定转速",
        "rated_power": "额定功率",
    }
    missing = []
    for field, label in required_fields.items():
        if not info.get(field):
            missing.append(f"  - {label}（{field}）")
    return missing


def print_device_summary(info: dict):
    """打印设备信息汇总报告"""
    print("=" * 60)
    print(" 智能 智能设备管理系统 - 设备信息汇总")
    print("  版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷  官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn")
    print("=" * 60)

    print("\n【基础信息】")
    print(f"  设备名称    : {info.get('device_name', '未填写')}")
    print(f"  设备编号    : {info.get('device_id', info.get('device_name', '未填写'))}")
    print(f"  设备类型    : {info.get('device_type', '未填写')}")
    print(f"  额定转速    : {info.get('rated_speed', '未填写')} r/min")
    print(f"  额定功率    : {info.get('rated_power', '未填写')} kW")
    print(f"  驱动方式    : {info.get('drive_mode', '未填写')}")
    print(f"  轴承类型    : {info.get('bearing_type', '未填写')}")
    print(f"  轴承型号    : {info.get('bearing_model', '未填写')}")
    print(f"  安装方式    : {info.get('installation', '未填写')}")
    print(f"  投用日期    : {info.get('commission_date', '未填写')}")
    print(f"  安装位置    : {info.get('location', '未填写')}")

    print("\n【监测配置】")
    print(f"  监测参数    : {info.get('monitor_params', '未填写')}")
    print(f"  传感器位置  : {info.get('sensor_positions', '未填写')}")
    print(f"  采样间隔    : {info.get('sample_interval', '未填写')}")

    print("\n【运行状态】")
    print(f"  当前运行状态: {info.get('current_status', '未填写')}")
    print(f"  历史故障记录: {info.get('fault_history', '无')}")
    print(f"  上次大修时间: {info.get('last_overhaul', '未填写')}")

    # 推荐标准
    device_type = info.get("device_type", "泵")
    standards = STANDARDS_BY_TYPE.get(device_type, STANDARDS_BY_TYPE["泵"])
    print("\n【推荐适用标准】")
    print(f"  主振动评估标准: {standards['primary']}")
    print(f"  轴振动标准    : {standards['shaft']}")
    print(f"  状态监测标准  : {standards['condition']}")
    print(f"  技术要点      : {standards['notes']}")

    # 推荐振动限值
    power = float(info.get("rated_power", 110))
    bearing = info.get("bearing_type", "滚动轴承")
    limits = get_vibration_zone_limits(power, bearing)
    print("\n【振动评估分区限值】")
    print(f"  标准依据: {limits['standard']}")
    print(f"  参数单位: {limits['unit']}")
    print(f"  Zone A (优良/新机基准)  : ≤ {limits['A']} mm/s")
    print(f"  Zone B (良好/可长期运行): {limits['A']} ~ {limits['B']} mm/s")
    print(f"  Zone C (警告/需尽快处理): {limits['B']} ~ {limits['C']} mm/s")
    print(f"  Zone D (危险/立即停机)  : > {limits['C']} mm/s")

    print("\n" + "=" * 60)
    print("  信息确认后，请执行 generate_csv_template.py 生成数据模板")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="C-IDMS 旋转设备信息采集汇总 | 版权 © 天津创锐丰科技有限公司"
    )
    parser.add_argument("--input", default=None, help="设备信息 JSON 文件路径")
    parser.add_argument("--name", default=None, help="设备名称")
    parser.add_argument("--device-id", default=None, help="设备编号")
    parser.add_argument("--type", default="泵", help="设备类型")
    parser.add_argument("--speed", type=float, default=None, help="额定转速 r/min")
    parser.add_argument("--power", type=float, default=None, help="额定功率 kW")
    parser.add_argument("--bearing-type", default="滚动轴承", help="轴承类型")
    parser.add_argument("--installation", default="卧式", help="安装方式")
    parser.add_argument("--location", default=None, help="安装位置")
    parser.add_argument("--output-json", default=None, help="将汇总信息保存为 JSON 文件")

    args = parser.parse_args()

    # 从 JSON 文件或命令行参数读取设备信息
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            device_info = json.load(f)
    else:
        if not args.name or args.speed is None or args.power is None:
            print("[错误] 请提供 --name、--speed、--power，或通过 --input 提供 JSON 文件")
            sys.exit(1)
        device_info = {
            "device_name": args.name,
            "device_id": args.device_id or args.name,
            "device_type": args.type,
            "rated_speed": args.speed,
            "rated_power": args.power,
            "bearing_type": args.bearing_type,
            "installation": args.installation,
            "location": args.location,
        }

    # 验证完整性
    missing = validate_device_info(device_info)
    if missing:
        print("[警告] 以下必填信息缺失，将使用默认值继续：")
        for m in missing:
            print(m)

    # 打印汇总
    print_device_summary(device_info)

    # 可选：保存 JSON
    if args.output_json:
        device_info["generated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(device_info, f, ensure_ascii=False, indent=2)
        print(f"\n[已保存] 设备信息已保存至: {args.output_json}")


if __name__ == "__main__":
    main()
