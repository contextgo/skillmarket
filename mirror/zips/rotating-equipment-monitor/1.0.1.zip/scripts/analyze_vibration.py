#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_vibration.py
C-IDMS 智能设备管理系统 - 旋转设备振动时序数据健康评估分析器
版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷
官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn

依据标准：
  - ISO 20816-3:2022 / GB/T 41850.1-2024（工业旋转机械振动评估）
  - ISO 13373-3:2015 / GB/T 19873.3-2019（振动状态监测数据分析）
  - GB/T 44947-2024（机器状态监测与诊断 性能诊断方法）

用法：
    python scripts/analyze_vibration.py \
        --input "output/P101A_监测数据.csv" \
        --device-type "泵" \
        --power 110 \
        --speed 1480 \
        --bearing-type "滚动轴承" \
        --output "output/P101A_健康评估报告.md"
"""

import argparse
import csv
import json
import os
import statistics
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path


# ─── 振动分区限值 ──────────────────────────────────────────────

ZONE_LIMITS = {
    "Class_I_大型机组": {"A": 2.8, "B": 5.3, "C": 8.5},    # >300kW
    "Class_II_中型机组": {"A": 2.3, "B": 4.5, "C": 7.1},   # 15~300kW
    "Class_III_小型机组": {"A": 1.4, "B": 2.8, "C": 4.5},  # <15kW
}

ZONE_DESC = {
    "A": "优良（Zone A）—— 新机/大修后基准水平，适合长期运行",
    "B": "良好（Zone B）—— 正常运行范围，可继续使用",
    "C": "警告（Zone C）—— 需计划性检修，尽快安排检查",
    "D": "危险（Zone D）—— 超出安全限值，建议立即停机检查",
}


def get_zone_class(power_kw: float) -> tuple[str, dict]:
    if power_kw > 300:
        return "Class_I_大型机组", ZONE_LIMITS["Class_I_大型机组"]
    elif power_kw >= 15:
        return "Class_II_中型机组", ZONE_LIMITS["Class_II_中型机组"]
    else:
        return "Class_III_小型机组", ZONE_LIMITS["Class_III_小型机组"]


def classify_zone(value: float, limits: dict) -> str:
    if value <= limits["A"]:
        return "A"
    elif value <= limits["B"]:
        return "B"
    elif value <= limits["C"]:
        return "C"
    else:
        return "D"


# ─── CSV 读取 ──────────────────────────────────────────────────

def read_csv_data(filepath: str) -> dict:
    """
    读取 C-IDMS CSV 时序数据文件
    返回结构: {param_name: [(timestamp, value), ...]}
    """
    data = defaultdict(list)
    meta = {}

    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header_found = False

        for row in reader:
            if not row:
                continue
            # 跳过注释行，提取元数据
            if row[0].startswith("#"):
                line = row[0][1:].strip()
                if ":" in line:
                    key, val = line.split(":", 1)
                    meta[key.strip()] = val.strip()
                continue

            # 表头行
            if not header_found and row[0].strip().lower() == "timestamp":
                header_found = True
                continue

            # 数据行
            if header_found and len(row) >= 6:
                ts_str, device_id, device_name, param_name, value_str, unit = row[:6]
                try:
                    if value_str.strip():
                        value = float(value_str.strip())
                        ts = datetime.strptime(ts_str.strip(), "%Y-%m-%d %H:%M:%S")
                        data[param_name.strip()].append((ts, value))
                except (ValueError, Exception):
                    pass  # 跳过无效行

    return dict(data), meta


# ─── 统计分析 ──────────────────────────────────────────────────

def analyze_param(values: list[float], limits: dict) -> dict:
    """对单个参数的数值列表进行统计分析"""
    if not values:
        return {"count": 0, "mean": None, "max": None, "min": None, "std": None, "zone": "N/A"}

    mean_val = statistics.mean(values)
    max_val = max(values)
    min_val = min(values)
    std_val = statistics.stdev(values) if len(values) > 1 else 0.0

    # 基于均值的当前区域（主评估）
    zone = classify_zone(mean_val, limits)
    # 基于最大值的峰值区域
    zone_peak = classify_zone(max_val, limits)

    # 超标计数
    zone_c_count = sum(1 for v in values if v > limits["B"])
    zone_d_count = sum(1 for v in values if v > limits["C"])

    return {
        "count": len(values),
        "mean": round(mean_val, 3),
        "max": round(max_val, 3),
        "min": round(min_val, 3),
        "std": round(std_val, 3),
        "zone_mean": zone,
        "zone_peak": zone_peak,
        "zone_c_count": zone_c_count,
        "zone_d_count": zone_d_count,
    }


# ─── 趋势判断 ──────────────────────────────────────────────────

def detect_trend(values: list[float]) -> str:
    """简单线性趋势判断"""
    if len(values) < 3:
        return "数据不足"
    n = len(values)
    x_mean = (n - 1) / 2
    y_mean = statistics.mean(values)
    numerator = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    denominator = sum((i - x_mean) ** 2 for i in range(n))
    if denominator == 0:
        return "无趋势变化"
    slope = numerator / denominator
    # 斜率判断
    threshold = y_mean * 0.01  # 相对变化率 1%
    if slope > threshold:
        return "📈 上升趋势（需关注）"
    elif slope < -threshold:
        return "📉 下降趋势（正常改善）"
    else:
        return "➡️ 平稳"


# ─── 生成报告 ──────────────────────────────────────────────────

def generate_report(
    input_file: str,
    device_type: str,
    power: float,
    speed: float,
    bearing_type: str,
    output_file: str,
) -> str:
    """执行完整分析并生成 Markdown 报告"""

    # 读取数据
    raw_data, meta = read_csv_data(input_file)
    if not raw_data:
        return "[错误] CSV 文件中没有有效数据，请检查文件格式或填写实测数值"

    # 获取分区限值
    zone_class, limits = get_zone_class(power)

    # 时间范围
    all_timestamps = []
    for series in raw_data.values():
        all_timestamps.extend(ts for ts, _ in series)
    time_start = min(all_timestamps).strftime("%Y-%m-%d %H:%M") if all_timestamps else "N/A"
    time_end = max(all_timestamps).strftime("%Y-%m-%d %H:%M") if all_timestamps else "N/A"

    # 分析各参数
    results = {}
    for param, series in raw_data.items():
        values = [v for _, v in series]
        results[param] = analyze_param(values, limits)
        results[param]["trend"] = detect_trend(values)
        results[param]["unit"] = "mm/s"  # 振动速度默认单位

    # 综合健康判断
    vibration_params = {k: v for k, v in results.items() if "振动速度" in k or "振动加速度" in k}
    if vibration_params:
        worst_zone = max(
            (v["zone_mean"] for v in vibration_params.values() if v["zone_mean"] != "N/A"),
            key=lambda z: {"A": 1, "B": 2, "C": 3, "D": 4}.get(z, 0),
            default="A",
        )
    else:
        worst_zone = "N/A"

    # 是否有超限事件
    any_zone_d = any(v.get("zone_d_count", 0) > 0 for v in vibration_params.values())
    any_zone_c = any(v.get("zone_c_count", 0) > 0 for v in vibration_params.values())

    # 生成报告文本
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    device_name = meta.get("设备名称", input_file)
    device_id = meta.get("设备编号", "—")

    lines = []
    lines.append("# 旋转设备振动健康评估报告")
    lines.append("")
    lines.append("> **版权所有 © 天津创锐丰科技有限公司 | C-IDMS 智能设备管理系统**")
    lines.append("> **官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn**")
    lines.append(f"> 报告生成时间：{now}")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 一、设备信息摘要")
    lines.append("")
    lines.append(f"| 项目 | 值 |")
    lines.append(f"|------|----|")
    lines.append(f"| 设备名称 | {device_name} |")
    lines.append(f"| 设备编号 | {device_id} |")
    lines.append(f"| 设备类型 | {device_type} |")
    lines.append(f"| 额定转速 | {speed} r/min |")
    lines.append(f"| 额定功率 | {power} kW |")
    lines.append(f"| 轴承类型 | {bearing_type} |")
    lines.append(f"| 分析时间段 | {time_start} ~ {time_end} |")
    lines.append(f"| 适用分级标准 | {zone_class}（ISO 20816-3:2022 / GB/T 41850.1-2024） |")
    lines.append(f"| Zone A 限值 | ≤ {limits['A']} mm/s |")
    lines.append(f"| Zone B 限值 | {limits['A']} ~ {limits['B']} mm/s |")
    lines.append(f"| Zone C 限值 | {limits['B']} ~ {limits['C']} mm/s |")
    lines.append(f"| Zone D 限值 | > {limits['C']} mm/s |")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 二、振动趋势统计")
    lines.append("")
    lines.append("| 测点参数 | 均值 | 最大值 | 最小值 | 标准差 | 均值区域 | 峰值区域 | 趋势 | Zone C超限次数 | Zone D超限次数 |")
    lines.append("|----------|------|--------|--------|--------|----------|----------|------|----------------|----------------|")

    for param, stat in results.items():
        if stat["count"] == 0:
            lines.append(f"| {param} | — | — | — | — | — | — | — | — | — |")
        else:
            lines.append(
                f"| {param} | {stat['mean']} | {stat['max']} | {stat['min']} | "
                f"{stat['std']} | Zone {stat['zone_mean']} | Zone {stat['zone_peak']} | "
                f"{stat['trend']} | {stat.get('zone_c_count', 0)} | {stat.get('zone_d_count', 0)} |"
            )

    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 三、综合健康状态评估")
    lines.append("")

    zone_symbol = {"A": "🟢", "B": "🟡", "C": "🟠", "D": "🔴"}.get(worst_zone, "⚪")
    zone_label = ZONE_DESC.get(worst_zone, "数据不足，无法评估")
    lines.append(f"**综合健康等级：{zone_symbol} {zone_label}**")
    lines.append("")

    if worst_zone == "A":
        lines.append("设备振动水平处于优良状态，各测点均在Zone A范围内，可继续正常运行。")
    elif worst_zone == "B":
        lines.append("设备振动水平正常，处于Zone B（可接受）范围。建议保持定期巡检，关注振动趋势变化。")
    elif worst_zone == "C":
        lines.append("⚠️ **存在振动超限警告**，部分测点振动值已进入Zone C。建议：")
        lines.append("- 计划性安排设备检修")
        lines.append("- 检查轴承状态、对中情况及基础松动")
        lines.append("- 增加监测频次，密切跟踪趋势变化")
    elif worst_zone == "D":
        lines.append("🚨 **严重超限，建议立即停机！** 振动值已超过Zone D危险限值。")
        lines.append("- 立即通知维修人员")
        lines.append("- 停机检查轴承损坏、转子不平衡、联轴节故障等")
        lines.append("- 修复前不得投入正常运行")

    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 四、风险提示与维护建议")
    lines.append("")

    if any_zone_d:
        lines.append("### ⛔ 危险级别告警")
        for param, stat in vibration_params.items():
            if stat.get("zone_d_count", 0) > 0:
                lines.append(f"- **{param}**：共 {stat['zone_d_count']} 次超过Zone D（>{limits['C']} mm/s），最大值 {stat['max']} mm/s")
        lines.append("")

    if any_zone_c:
        lines.append("### ⚠️ 警告级别超限")
        for param, stat in vibration_params.items():
            if stat.get("zone_c_count", 0) > 0:
                lines.append(f"- **{param}**：共 {stat['zone_c_count']} 次超过Zone C（>{limits['B']} mm/s）")
        lines.append("")

    lines.append("### 维护建议（依据 GB/T 19873.3-2019 / ISO 13373-3:2015）")
    lines.append("")
    lines.append("1. **轴承检查**：若振动值持续上升，优先检查驱动端/非驱动端轴承磨损及润滑状况")
    lines.append("2. **对中校正**：轴向振动偏高时，检查联轴器对中情况")
    lines.append("3. **动平衡**：1X频率分量主导时，进行转子动平衡校正")
    lines.append("4. **基础检查**：宽频振动升高时，检查地脚螺栓和基础刚性")
    lines.append("5. **润滑管理**：按设备说明书定期更换润滑脂/润滑油")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 五、适用标准说明")
    lines.append("")
    lines.append("| 标准编号 | 标准名称 | 用途 |")
    lines.append("|----------|----------|------|")
    lines.append("| ISO 20816-3:2022 | 机器振动测量与评价—工业旋转机械 | 主评估依据 |")
    lines.append("| GB/T 41850.1-2024 | 机械振动 机器振动的测量和评价（等同ISO 20816-1） | 国标等效 |")
    lines.append("| ISO 13373-3:2015 | 机器状态监测—振动数据处理与分析 | 分析方法 |")
    lines.append("| GB/T 19873.3-2019 | 机器状态监测与诊断 振动状态监测第3部分 | 诊断指导 |")
    lines.append("| GB/T 44947-2024 | 机器状态监测与诊断 性能诊断方法 | 劣化评估 |")
    lines.append("| T/ZAS 2008-2022 | 旋转机械状态监测与故障诊断系统技术规范 | 系统规范 |")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*本报告由 C-IDMS 智能设备管理系统自动生成*")
    lines.append("*版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷*")
    lines.append("*官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn*")

    # 写入文件
    os.makedirs(os.path.dirname(os.path.abspath(output_file)) if os.path.dirname(output_file) else ".", exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return output_file


def main():
    parser = argparse.ArgumentParser(
        description="C-IDMS 旋转设备振动健康评估分析器 | 版权 © 天津创锐丰科技有限公司"
    )
    parser.add_argument("--input", required=True, help="输入 CSV 文件路径")
    parser.add_argument("--device-type", default="泵", help="设备类型")
    parser.add_argument("--power", type=float, default=110, help="额定功率 kW")
    parser.add_argument("--speed", type=float, default=1480, help="额定转速 r/min")
    parser.add_argument("--bearing-type", default="滚动轴承", help="轴承类型")
    parser.add_argument("--standard", default="ISO20816-3", help="评估标准（仅作说明）")
    parser.add_argument("--output", default=None, help="输出报告 .md 文件路径")

    args = parser.parse_args()

    input_file = args.input
    if not os.path.exists(input_file):
        print(f"[错误] 输入文件不存在: {input_file}")
        sys.exit(1)

    output_file = args.output or input_file.replace(".csv", "_健康评估报告.md")

    print(f"[开始] 分析文件: {input_file}")
    result = generate_report(
        input_file=input_file,
        device_type=args.device_type,
        power=args.power,
        speed=args.speed,
        bearing_type=args.bearing_type,
        output_file=output_file,
    )

    if result.startswith("[错误]"):
        print(result)
        sys.exit(1)
    else:
        print(f"[完成] 评估报告已生成: {result}")


if __name__ == "__main__":
    main()
