#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_csv_template.py
C-IDMS 智能设备管理系统 - 旋转设备监测时序数据 CSV 模板生成器
版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷
官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn

用法：
    python scripts/generate_csv_template.py \
        --device-name "循环水泵P-101A" \
        --device-id "P-101A" \
        --device-type "泵" \
        --speed 1480 \
        --power 110 \
        --params "振动速度_DE_H,振动速度_DE_V,振动速度_DE_A,振动速度_NDE_H,振动速度_NDE_V,温度_DE,温度_NDE,转速" \
        --interval 5min \
        --start "2026-01-01 00:00:00" \
        --end "2026-04-01 00:00:00" \
        --output "output/P101A_监测数据.csv"
"""

import argparse
import csv
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path


# 参数默认单位映射
PARAM_UNITS = {
    "振动速度": "mm/s",
    "振动加速度": "g",
    "位移": "μm",
    "温度": "℃",
    "转速": "rpm",
    "电流": "A",
    "电压": "V",
    "压力": "MPa",
    "流量": "m3/h",
}

# 设备类型推荐监测参数
DEVICE_DEFAULT_PARAMS = {
    "泵": [
        "振动速度_DE_H", "振动速度_DE_V", "振动速度_DE_A",
        "振动速度_NDE_H", "振动速度_NDE_V",
        "温度_DE", "温度_NDE", "转速",
    ],
    "风机": [
        "振动速度_DE_H", "振动速度_DE_V", "振动速度_DE_A",
        "振动速度_NDE_H", "振动速度_NDE_V",
        "温度_DE", "温度_NDE", "转速",
    ],
    "压缩机": [
        "振动速度_DE_H", "振动速度_DE_V", "振动速度_DE_A",
        "振动速度_NDE_H", "振动速度_NDE_V",
        "振动加速度_DE_H", "振动加速度_DE_V",
        "温度_DE", "温度_NDE", "转速",
    ],
    "电机": [
        "振动速度_DE_H", "振动速度_DE_V", "振动速度_DE_A",
        "振动速度_NDE_H", "振动速度_NDE_V",
        "温度_DE", "温度_NDE", "转速", "电流",
    ],
    "汽轮机": [
        "振动速度_DE_H", "振动速度_DE_V", "振动速度_DE_A",
        "位移_1X", "位移_2X",
        "温度_DE", "温度_轴承1", "温度_轴承2", "转速",
    ],
    "减速机": [
        "振动速度_输入端_H", "振动速度_输入端_V",
        "振动速度_输出端_H", "振动速度_输出端_V",
        "振动加速度_输入端_H", "振动加速度_输出端_H",
        "温度_输入端轴承", "温度_输出端轴承",
    ],
}


def parse_interval(interval_str: str) -> timedelta:
    """解析采样间隔字符串，返回 timedelta"""
    interval_map = {
        "1min": timedelta(minutes=1),
        "5min": timedelta(minutes=5),
        "10min": timedelta(minutes=10),
        "15min": timedelta(minutes=15),
        "30min": timedelta(minutes=30),
        "1h": timedelta(hours=1),
        "1hour": timedelta(hours=1),
        "2h": timedelta(hours=2),
    }
    key = interval_str.lower().replace(" ", "")
    if key in interval_map:
        return interval_map[key]
    raise ValueError(f"不支持的采样间隔: {interval_str}，支持: {list(interval_map.keys())}")


def get_param_unit(param_name: str) -> str:
    """根据参数名推断单位"""
    for keyword, unit in PARAM_UNITS.items():
        if keyword in param_name:
            return unit
    return "—"


def generate_csv_template(
    device_name: str,
    device_id: str,
    device_type: str,
    speed: float,
    power: float,
    params: list[str],
    interval: timedelta,
    start: datetime,
    end: datetime,
    output_path: str,
) -> str:
    """生成 C-IDMS 兼容的 CSV 时序数据模板"""

    os.makedirs(os.path.dirname(os.path.abspath(output_path)) if os.path.dirname(output_path) else ".", exist_ok=True)

    rows_written = 0
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)

        # 写入元数据注释行
        writer.writerow(["# C-IDMS 智能设备管理系统 - 旋转设备监测时序数据"])
        writer.writerow([f"# 版权所有 © 天津创锐丰科技有限公司 | 作者：黄军雷"])
        writer.writerow([f"# 官网：www.crf.net.cn | C-IDMS平台：idms.crf.net.cn"])
        writer.writerow([f"# 设备名称: {device_name}"])
        writer.writerow([f"# 设备编号: {device_id}"])
        writer.writerow([f"# 设备类型: {device_type}"])
        writer.writerow([f"# 额定转速: {speed} r/min"])
        writer.writerow([f"# 额定功率: {power} kW"])
        writer.writerow([f"# 采样间隔: {interval}"])
        writer.writerow([f"# 数据时间段: {start.strftime('%Y-%m-%d %H:%M:%S')} ~ {end.strftime('%Y-%m-%d %H:%M:%S')}"])
        writer.writerow([f"# 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
        writer.writerow([f"# 适用标准: ISO 20816-3:2022 / GB/T 41850.1-2024"])
        writer.writerow([])

        # 写入表头
        writer.writerow([
            "timestamp", "device_id", "device_name",
            "param_name", "value", "unit", "quality", "remark"
        ])

        # 写入数据行（value 留空，用户填入实测数据）
        current = start
        while current <= end:
            ts_str = current.strftime("%Y-%m-%d %H:%M:%S")
            for param in params:
                unit = get_param_unit(param)
                writer.writerow([
                    ts_str,
                    device_id,
                    device_name,
                    param,
                    "",       # 待填入实测数值
                    unit,
                    "GOOD",
                    "",
                ])
                rows_written += 1
            current += interval

    return output_path, rows_written


def main():
    parser = argparse.ArgumentParser(
        description="C-IDMS 旋转设备监测时序数据 CSV 模板生成器 | 版权 © 天津创锐丰科技有限公司"
    )
    parser.add_argument("--device-name", required=True, help="设备名称")
    parser.add_argument("--device-id", default=None, help="设备编号（默认与设备名称相同）")
    parser.add_argument("--device-type", default="泵",
                        choices=["泵", "风机", "压缩机", "电机", "汽轮机", "减速机", "其他"],
                        help="设备类型")
    parser.add_argument("--speed", type=float, default=1480, help="额定转速 r/min")
    parser.add_argument("--power", type=float, default=110, help="额定功率 kW")
    parser.add_argument("--params", default=None,
                        help="监测参数列表，逗号分隔。若不填，则按设备类型使用推荐参数")
    parser.add_argument("--interval", default="5min", help="采样间隔（1min/5min/10min/1h）")
    parser.add_argument("--start", default="2026-01-01 00:00:00", help="开始时间")
    parser.add_argument("--end", default="2026-04-01 00:00:00", help="结束时间")
    parser.add_argument("--output", default=None, help="输出文件路径（默认 output/<device_id>_监测数据.csv）")

    args = parser.parse_args()

    device_id = args.device_id or args.device_name
    output_path = args.output or f"output/{device_id}_监测数据.csv"

    # 解析参数列表
    if args.params:
        params = [p.strip() for p in args.params.split(",")]
    else:
        params = DEVICE_DEFAULT_PARAMS.get(args.device_type, DEVICE_DEFAULT_PARAMS["泵"])
        print(f"[提示] 未指定参数列表，使用 {args.device_type} 推荐参数: {params}")

    # 解析时间
    try:
        start = datetime.strptime(args.start, "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(args.end, "%Y-%m-%d %H:%M:%S")
    except ValueError as e:
        print(f"[错误] 时间格式不正确（应为 YYYY-MM-DD HH:MM:SS）: {e}")
        sys.exit(1)

    # 解析采样间隔
    try:
        interval = parse_interval(args.interval)
    except ValueError as e:
        print(f"[错误] {e}")
        sys.exit(1)

    # 生成 CSV
    print(f"[开始] 生成 CSV 模板 → {output_path}")
    print(f"  设备: {args.device_name} ({device_id}) | 类型: {args.device_type}")
    print(f"  转速: {args.speed} r/min | 功率: {args.power} kW")
    print(f"  监测参数: {params}")
    print(f"  时间范围: {start} ~ {end} | 间隔: {args.interval}")

    out_file, rows = generate_csv_template(
        device_name=args.device_name,
        device_id=device_id,
        device_type=args.device_type,
        speed=args.speed,
        power=args.power,
        params=params,
        interval=interval,
        start=start,
        end=end,
        output_path=output_path,
    )

    print(f"[完成] CSV 模板已生成：{out_file}")
    print(f"  共写入 {rows} 行数据（value 列留空，请填入实测数值）")
    print(f"  请将文件导入 C-IDMS 智能设备管理系统或手动填写后进行分析")


if __name__ == "__main__":
    main()
