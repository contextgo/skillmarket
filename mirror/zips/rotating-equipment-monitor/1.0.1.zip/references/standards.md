# 旋转设备状态监测相关国内外标准汇总

> 版权所有 © 天津创锐丰科技有限公司 | C-IDMS 智能设备管理系统  
> 本文档整理了适用于旋转设备状态监测、振动评估与故障诊断的主要国内外标准

---

## 一、国际标准（ISO）

### 1.1 ISO 20816 系列 — 机器振动的测量和评价
> 为 ISO 10816（壳体振动）和 ISO 7919（轴振动）的整合升级版本

| 标准编号 | 版本 | 名称 | 适用范围 |
|----------|------|------|----------|
| **ISO 20816-1:2016** | 2016 | Mechanical vibration — Measurement and evaluation of machine vibration — Part 1: General guidelines | 总则，适用所有旋转机械 |
| **ISO 20816-2:2017** | 2017 | Part 2: Land-based gas turbines, steam turbines and generators in excess of 40 MW | 大型汽轮机、燃气轮机（>40MW） |
| **ISO 20816-3:2022** | 2022 | Part 3: Industrial machinery with a power above 15 kW and operating speeds between 120 r/min and 15000 r/min | **工业通用机器（15kW~）**，**最常用** |
| **ISO 20816-4:2018** | 2018 | Part 4: Gas turbine driven sets excluding aircraft derivatives | 燃气轮机组（非航空） |
| **ISO 20816-5:2021** | 2021 | Part 5: Machine sets in hydraulic power generating and pump-storage plants | 水电站机组 |
| **ISO 20816-6:2016** | 2016 | Part 6: Reciprocating machines with power ratings above 100 kW | 往复式机器（>100kW） |
| **ISO 20816-7:2024** | 2024 | Part 7: Rotodynamic pumps for industrial applications | 工业用旋转动力泵（专用） |
| **ISO 20816-8:2018** | 2018 | Part 8: Reciprocating compressor systems | 往复式压缩机系统 |
| **ISO 20816-9:2020** | 2020 | Part 9: Gear units | 齿轮箱 |

---

### 1.2 ISO 7919 系列 — 转轴径向振动测量和评价（轴振动/位移）

| 标准编号 | 名称 | 适用范围 |
|----------|------|----------|
| ISO 7919-1:1996 | General guidelines | 总则 |
| ISO 7919-2:2001 | Land-based steam turbines and generators over 50 MW | 大型汽轮发电机 |
| ISO 7919-3:1996 | Coupled industrial machines | 工业联轴机器 |
| ISO 7919-4:1996 | Gas turbine driven sets | 燃气轮机组 |
| ISO 7919-5:2005 | Machine sets in hydraulic power plants | 水电机组 |

> **注**：ISO 7919 用于转轴径向位移测量（μm peak-to-peak），ISO 20816 用于壳体振动速度（mm/s RMS）

---

### 1.3 ISO 10816 系列 — 在非旋转部件上测量评价机器振动（旧版）
> 已被 ISO 20816 系列逐步替代，但仍在广泛使用

| 标准编号 | 名称 |
|----------|------|
| ISO 10816-1:1995 | General guidelines |
| ISO 10816-3:2009 | Industrial machinery 15~300 kW（常用参考） |
| ISO 10816-6:1995 | Reciprocating machines >100 kW |

---

### 1.4 ISO 13373 系列 — 机器状态监测与诊断（振动）

| 标准编号 | 版本 | 名称 | 用途 |
|----------|------|------|------|
| **ISO 13373-1:2002** | 2002 | General procedures | 振动状态监测通用规程 |
| **ISO 13373-2:2016** | 2016 | Processing, analysis and presentation of vibration data | 振动数据处理、分析、展示 |
| **ISO 13373-3:2015** | 2015 | Guidelines for vibration diagnosis | 振动故障诊断指南 |
| **ISO 13373-5:2020** | 2020 | Balancing | 动平衡监测 |
| **ISO 13373-7:2020** | 2020 | Diagnostic techniques for machine sets in hydraulic power plants | 水电机组诊断 |
| **ISO 13373-9:2017** | 2017 | Diagnostic techniques for electric motors | 电机振动诊断 |

---

### 1.5 其他相关国际标准

| 标准编号 | 名称 | 用途 |
|----------|------|------|
| ISO 13379-1:2012 | Data interpretation and diagnostics techniques — General guidelines | 数据解读与诊断通用指南 |
| ISO 13380:2002 | General guidelines for condition monitoring by performance analysis | 性能分析状态监测通用指南 |
| ISO 13381-1:2015 | Prognostics — General guidelines | 预测性维护通用指南 |
| ISO 14694:2003 | Industrial fans — Specifications for balance quality | 工业风机平衡质量规范 |
| API 670 (2014) | Machinery Protection Systems | 石化行业机械保护系统（广泛参考） |
| API 686 (2009) | Recommended Practice for Machinery Installation | 机械安装推荐规范 |

---

## 二、中国国家标准（GB/T）

### 2.1 振动测量与评价

| 标准编号 | 版本 | 名称 | 对应国际标准 |
|----------|------|------|-------------|
| **GB/T 41850.1-2024** | 2024 | 机械振动 机器振动的测量和评价 第1部分：总则 | 等同 ISO 20816-1:2016 |
| **GB/T 11348.1-2012** | 2012 | 机械振动 旋转机械转轴径向振动的测量和评定 第1部分：总则 | 等同 ISO 7919-1 |
| **GB/T 11348.2-2012** | 2012 | 第2部分：额定功率大于50MW、额定转速在1500r/min、1800r/min、3000r/min或3600r/min陆地安装的汽轮机和发电机 | 等同 ISO 7919-2 |
| **GB/T 11348.3-2011** | 2011 | 第3部分：联轴的工业机器 | 等同 ISO 7919-3 |
| **GB/T 11347-2020** | 2020 | 机械振动 旋转和往复机械的振动状态监测 第1部分：总则 | 等同 ISO 13373-1 |
| **GB/T 6075.3-2011** | 2011 | 机械振动 在非旋转部件上测量评价机器的振动 第3部分：额定功率大于15kW额定转速在120r/min至15000r/min之间的在现场测量的工业机器 | 等同 ISO 10816-3 |

---

### 2.2 状态监测与故障诊断

| 标准编号 | 版本 | 名称 |
|----------|------|------|
| **GB/T 19873.1-2005** | 2005 | 机器状态监测与诊断 振动状态监测 第1部分：总则 |
| **GB/T 19873.2-2009** | 2009 | 第2部分：振动数据采集 |
| **GB/T 19873.3-2019** | 2019 | 第3部分：振动诊断指南（**推荐用于故障分析**） |
| **GB/T 44947-2024** | 2024 | 机器状态监测与诊断 性能诊断方法（**最新国标**） |
| **GB/T 25739-2010** | 2010 | 机器状态监测与诊断 数据解释和诊断技术 总则 |
| **GB/T 29149-2012** | 2012 | 机器状态监测与诊断 预测性维护通则 |
| **GB/T 32333-2015** | 2015 | 旋转机械用振动分析仪 |

---

### 2.3 轴承相关标准

| 标准编号 | 名称 |
|----------|------|
| GB/T 24610-2019 | 滚动轴承 振动测量方法 |
| GB/T 4604-2006 | 滚动轴承 径向内部游隙 |
| GB/T 6391-2010 | 滚动轴承 额定动载荷和额定寿命 |

---

## 三、行业标准与团体标准

| 标准编号 | 名称 | 适用范围 |
|----------|------|----------|
| **T/ZAS 2008-2022** | 旋转机械状态监测与故障诊断系统技术规范 | 系统建设与集成规范 |
| **HG/T 3211-2016** | 化工用泵机组振动标准 | 化工行业泵类设备 |
| **JB/T 8662-2012** | 通用机械用减速机振动标准 | 减速机 |
| **GB 50319-2013** | 建筑设备监控系统工程技术规范 | 楼宇设备监控 |

---

## 四、标准选用指南

根据设备类型选择主要评估标准：

```
泵（离心泵/轴流泵）
  → 主标准：ISO 20816-3:2022 / GB/T 41850.1-2024
  → 轴振：ISO 7919-3（若配轴振传感器）
  → 诊断：GB/T 19873.3-2019

风机（离心/轴流）
  → 主标准：ISO 20816-3:2022
  → 平衡：ISO 14694:2003

压缩机（离心式）
  → 主标准：ISO 20816-3:2022 / API 670
  → 轴振：ISO 7919-3

压缩机（往复式）
  → 主标准：ISO 20816-6:2016

电机
  → 主标准：ISO 20816-3:2022
  → 专项：ISO 13373-9:2017（电机振动诊断）

汽轮机
  → 主标准：ISO 20816-2:2017
  → 轴振：ISO 7919-2 / GB/T 11348.2-2012

齿轮箱/减速机
  → 主标准：ISO 20816-9:2020
```

---

*本文档由 C-IDMS 智能设备管理系统技能包生成*  
*版权所有 © 天津创锐丰科技有限公司*
