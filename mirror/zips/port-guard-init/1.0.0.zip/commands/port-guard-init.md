请使用已安装的 `port-guard-init` Skill 初始化当前项目的端口治理规则。

要求：

1. 先定位 Skill 目录中的 `scripts/portguard_init.py`。
2. 在当前项目根目录执行初始化。
3. 项目端口以当前项目已有配置为准，不要强制写死统一端口。
4. 如果当前项目没有端口配置，则生成 `config/dev_ports.env`。
5. 生成项目内的：
   - `config/dev_ports.env`
   - `scripts/stop_dev.bat`
   - `scripts/start_dev.bat`
   - `scripts/restart_dev.bat`
   - `scripts/port_guard.ps1`
   - `.cursor/rules/port-management.mdc`
   - `.claude/settings.json`
   - `CLAUDE.md`
   - `README_PORT_GUARD.md`
6. 初始化完成后，后续自测必须通过 `scripts/restart_dev.bat`。
7. 端口占用时必须清理旧进程，不允许自动换端口。
8. Skill 包自身不得上传、复制或生成任何二进制文件；目标项目中生成的脚本必须是纯文本写入。

如果需要手动执行，可以运行：

```bash
python %USERPROFILE%\.claude\skills\port-guard-init\scripts\portguard_init.py --project . --app-type auto
```
