from __future__ import annotations

import shutil
from pathlib import Path


def main() -> None:
    src = Path(__file__).resolve().parent
    home = Path.home()
    skill_dst = home / ".claude" / "skills" / "port-guard-init"
    cmd_dst_dir = home / ".claude" / "commands"
    cmd_dst = cmd_dst_dir / "port-guard-init.md"

    if skill_dst.exists():
        shutil.rmtree(skill_dst)
    shutil.copytree(src, skill_dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    cmd_dst_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src / "commands" / "port-guard-init.md", cmd_dst)

    print("PortGuard Skill installed:")
    print(f"  Skill: {skill_dst}")
    print(f"  Command: {cmd_dst}")
    print("Restart Claude Code, then use /port-guard-init in a project.")


if __name__ == "__main__":
    main()
