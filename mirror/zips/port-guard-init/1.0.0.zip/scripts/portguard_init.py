from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, Iterable, Optional

ALLOWED_SKILL_FILE_SUFFIXES = {".md", ".py"}


def read_text_safe(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        try:
            return path.read_text(encoding="utf-8-sig")
        except Exception:
            return ""


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def parse_env_file(path: Path) -> Dict[str, str]:
    result: Dict[str, str] = {}
    if not path.exists():
        return result
    for line in read_text_safe(path).splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def detect_port_in_text(text: str, keys: Iterable[str]) -> Optional[int]:
    for key in keys:
        patterns = [
            rf"{re.escape(key)}\s*=\s*[\"']?(\d{{2,5}})[\"']?",
            rf"{re.escape(key)}\s*:\s*[\"']?(\d{{2,5}})[\"']?",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                return int(match.group(1))
    return None


def detect_project_type(project: Path) -> str:
    if (project / "app.py").exists():
        app_py = read_text_safe(project / "app.py")
        if "streamlit" in app_py.lower() or "st." in app_py:
            return "streamlit"

    if (project / "package.json").exists():
        pkg = read_text_safe(project / "package.json").lower()
        if "vite" in pkg:
            if any((project / name).exists() for name in ["main.py", "app.py"]):
                return "fullstack"
            return "frontend"

    for py in list(project.glob("*.py"))[:20]:
        text = read_text_safe(py)
        if "FastAPI(" in text or "from fastapi" in text:
            return "fastapi"

    return "generic"


def collect_existing_ports(project: Path) -> Dict[str, int]:
    ports: Dict[str, int] = {}

    env_candidates = [
        project / "config" / "dev_ports.env",
        project / ".env.development",
        project / ".env",
    ]
    for env_path in env_candidates:
        env = parse_env_file(env_path)
        for key, value in env.items():
            if "PORT" in key.upper() and value.isdigit():
                k = key.upper()
                if "BACKEND" in k or "API" in k:
                    ports.setdefault("backend", int(value))
                elif "FRONTEND" in k or "VITE" in k:
                    ports.setdefault("frontend", int(value))
                elif "APP" in k or "STREAMLIT" in k or k == "PORT":
                    ports.setdefault("app", int(value))

    for vite_name in ["vite.config.ts", "vite.config.js", "vite.config.mts", "vite.config.mjs"]:
        path = project / vite_name
        if path.exists():
            port = detect_port_in_text(read_text_safe(path), ["port"])
            if port:
                ports.setdefault("frontend", port)

    streamlit_cfg = project / ".streamlit" / "config.toml"
    if streamlit_cfg.exists():
        port = detect_port_in_text(read_text_safe(streamlit_cfg), ["port"])
        if port:
            ports.setdefault("app", port)

    for name in ["README.md", "run.bat", "start.bat"]:
        path = project / name
        if path.exists():
            text = read_text_safe(path)
            if "streamlit" in text.lower():
                m = re.search(r"--server\.port\s+(\d{2,5})", text)
                if m:
                    ports.setdefault("app", int(m.group(1)))
            m = re.search(r"--port\s+(\d{2,5})", text)
            if m and "backend" not in ports:
                ports.setdefault("backend", int(m.group(1)))
    return ports


def build_dev_ports_env(app_type: str, ports: Dict[str, int], args: argparse.Namespace) -> str:
    if args.app_port:
        ports["app"] = args.app_port
    if args.backend_port:
        ports["backend"] = args.backend_port
    if args.frontend_port:
        ports["frontend"] = args.frontend_port

    if app_type == "auto":
        app_type = "generic"

    if app_type == "streamlit":
        app_port = ports.get("app", 8501)
        return f"""# PortGuard project port configuration
APP_TYPE=streamlit
APP_PORT={app_port}
DEV_PORTS={app_port}
HOST=127.0.0.1
"""
    if app_type == "fastapi":
        backend_port = ports.get("backend", ports.get("app", 8000))
        return f"""# PortGuard project port configuration
APP_TYPE=fastapi
BACKEND_PORT={backend_port}
BACKEND_APP=main:app
DEV_PORTS={backend_port}
HOST=127.0.0.1
"""
    if app_type == "frontend":
        frontend_port = ports.get("frontend", 5173)
        return f"""# PortGuard project port configuration
APP_TYPE=frontend
FRONTEND_PORT={frontend_port}
DEV_PORTS={frontend_port}
HOST=127.0.0.1
"""
    if app_type == "fullstack":
        backend_port = ports.get("backend", 8000)
        frontend_port = ports.get("frontend", 5173)
        return f"""# PortGuard project port configuration
APP_TYPE=fullstack
BACKEND_PORT={backend_port}
FRONTEND_PORT={frontend_port}
BACKEND_APP=main:app
DEV_PORTS={backend_port},{frontend_port}
API_BASE_URL=http://127.0.0.1:{backend_port}
FRONTEND_URL=http://127.0.0.1:{frontend_port}
HOST=127.0.0.1
"""

    app_port = ports.get("app", ports.get("backend", 8000))
    return f"""# PortGuard project port configuration
APP_TYPE=generic
APP_PORT={app_port}
DEV_PORTS={app_port}
HOST=127.0.0.1
# If generic start cannot infer your project command, edit scripts/start_dev.bat once.
"""


def stop_dev_bat() -> str:
    return r'''@echo off
chcp 65001 >nul
cd /d %~dp0\..

set "PORT_FILE=config\dev_ports.env"

if not exist "%PORT_FILE%" (
    echo 未找到 %PORT_FILE%
    echo 请先运行 PortGuard 初始化，生成 config\dev_ports.env
    exit /b 1
)

for /f "usebackq tokens=1,* delims==" %%A in ("%PORT_FILE%") do (
    if not "%%A"=="" if not "%%A:~0,1"=="#" set "%%A=%%B"
)

if "%DEV_PORTS%"=="" (
    echo config\dev_ports.env 中未配置 DEV_PORTS
    exit /b 1
)

echo 当前项目端口：%DEV_PORTS%
echo 正在清理项目端口...

for %%P in (%DEV_PORTS:,= %) do (
    call :kill_port %%P
)

echo 项目端口清理完成。
exit /b 0

:kill_port
set "PORT=%1"
echo 检查端口 %PORT% ...

for /f "tokens=5" %%I in ('netstat -ano ^| findstr /R /C:":%PORT% .*LISTENING"') do (
    echo 端口 %PORT% 被 PID %%I 占用，正在结束进程...
    taskkill /PID %%I /F >nul 2>&1
)

exit /b 0
'''


def start_dev_bat() -> str:
    return r'''@echo off
chcp 65001 >nul
cd /d %~dp0\..

set "PORT_FILE=config\dev_ports.env"

if not exist "%PORT_FILE%" (
    echo 未找到 %PORT_FILE%
    exit /b 1
)

for /f "usebackq tokens=1,* delims==" %%A in ("%PORT_FILE%") do (
    if not "%%A"=="" if not "%%A:~0,1"=="#" set "%%A=%%B"
)

if "%HOST%"=="" set "HOST=127.0.0.1"

echo PortGuard 启动项目类型：%APP_TYPE%

if /I "%APP_TYPE%"=="streamlit" goto start_streamlit
if /I "%APP_TYPE%"=="fastapi" goto start_fastapi
if /I "%APP_TYPE%"=="frontend" goto start_frontend
if /I "%APP_TYPE%"=="fullstack" goto start_fullstack
if /I "%APP_TYPE%"=="generic" goto start_generic

echo 未知 APP_TYPE：%APP_TYPE%
exit /b 1

:start_streamlit
if "%APP_PORT%"=="" (
    echo APP_PORT 未配置
    exit /b 1
)
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate
if exist requirements.txt pip install -r requirements.txt
streamlit run app.py --server.port %APP_PORT% --server.address %HOST%
exit /b %errorlevel%

:start_fastapi
if "%BACKEND_PORT%"=="" (
    echo BACKEND_PORT 未配置
    exit /b 1
)
if "%BACKEND_APP%"=="" set "BACKEND_APP=main:app"
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate
if exist requirements.txt pip install -r requirements.txt
uvicorn %BACKEND_APP% --host %HOST% --port %BACKEND_PORT%
exit /b %errorlevel%

:start_frontend
if "%FRONTEND_PORT%"=="" (
    echo FRONTEND_PORT 未配置
    exit /b 1
)
if exist package.json npm install
npm run dev -- --host %HOST% --port %FRONTEND_PORT% --strictPort
exit /b %errorlevel%

:start_fullstack
if "%BACKEND_PORT%"=="" (
    echo BACKEND_PORT 未配置
    exit /b 1
)
if "%FRONTEND_PORT%"=="" (
    echo FRONTEND_PORT 未配置
    exit /b 1
)
if "%BACKEND_APP%"=="" set "BACKEND_APP=main:app"
start "PortGuard Backend" cmd /k "cd /d %cd% && if not exist .venv python -m venv .venv && call .venv\Scripts\activate && if exist requirements.txt pip install -r requirements.txt && uvicorn %BACKEND_APP% --host %HOST% --port %BACKEND_PORT%"
start "PortGuard Frontend" cmd /k "cd /d %cd% && if exist package.json npm install && npm run dev -- --host %HOST% --port %FRONTEND_PORT% --strictPort"
exit /b 0

:start_generic
if "%APP_PORT%"=="" (
    echo APP_PORT 未配置
    exit /b 1
)
echo generic 项目无法自动确定启动命令。
echo 请编辑 scripts\start_dev.bat 中的 :start_generic 部分，写入你的项目启动命令。
echo 端口必须使用 config\dev_ports.env 中配置的 APP_PORT=%APP_PORT%。
exit /b 1
'''


def restart_dev_bat() -> str:
    return r'''@echo off
chcp 65001 >nul
cd /d %~dp0\..

call scripts\stop_dev.bat
if errorlevel 1 exit /b 1

call scripts\start_dev.bat
exit /b %errorlevel%
'''


def port_guard_ps1() -> str:
    return r'''# PortGuard Claude Code hook helper.
# Blocks common naked dev-server commands so agents use scripts\restart_dev.bat.

$inputText = [Console]::In.ReadToEnd()
$lower = $inputText.ToLowerInvariant()

$dangerPatterns = @(
  "streamlit run app.py",
  "npm run dev",
  "uvicorn ",
  "python app.py",
  "vite --port"
)

$allowedPatterns = @(
  "scripts\\restart_dev.bat",
  "scripts/restart_dev.bat",
  "scripts\\stop_dev.bat",
  "scripts/stop_dev.bat",
  "scripts\\start_dev.bat",
  "scripts/start_dev.bat"
)

$usesAllowed = $false
foreach ($p in $allowedPatterns) {
  if ($lower.Contains($p)) { $usesAllowed = $true }
}

foreach ($p in $dangerPatterns) {
  if ($lower.Contains($p) -and -not $usesAllowed) {
    Write-Error "PortGuard blocked naked dev-server command. Use scripts\\restart_dev.bat and project ports from config\\dev_ports.env."
    exit 2
  }
}

exit 0
'''


def cursor_rule() -> str:
    return """---
description: PortGuard 项目端口治理规则，防止 AI 自测时乱换端口
globs: \"**/*\"
alwaysApply: true
---

# PortGuard 端口治理规则

本项目端口必须以 `config/dev_ports.env` 为准。

## 强制要求

1. 不允许自动更换端口。
2. 不允许因为端口占用而改用新端口。
3. 自测前必须读取 `config/dev_ports.env`。
4. 启动或自测必须通过 `scripts/restart_dev.bat`。
5. 如果端口被占用，必须运行 `scripts/stop_dev.bat` 清理旧进程。
6. 不允许直接运行裸命令，例如：
   - `streamlit run app.py`
   - `npm run dev`
   - `uvicorn main:app`
   - `python app.py`
7. 不允许临时修改前端 API 地址或后端监听端口来绕过问题。
8. 不允许在代码中硬编码临时端口，例如 8001、8002、5174、8502。
9. 如果端口无法释放，必须停止并报告错误。

## 自测流程

```bat
scripts\restart_dev.bat
```
"""


def claude_settings_json() -> str:
    data = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Bash",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "powershell.exe -ExecutionPolicy Bypass -File scripts/port_guard.ps1"
                        }
                    ]
                }
            ]
        }
    }
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def claude_md_block() -> str:
    return r"""

<!-- PORTGUARD_START -->
# PortGuard 项目端口治理规则

本项目已经接入 PortGuard。

## 核心原则

- 不要求所有项目使用同一个端口。
- 当前项目端口必须以 `config/dev_ports.env` 为准。
- Claude Code / Cursor 自测时不得自动换端口。
- 如果端口被占用，必须清理旧进程，而不是改用新端口。

## 强制要求

1. 每次启动前必须读取 `config/dev_ports.env`。
2. 每次自测必须使用：

```bat
scripts\restart_dev.bat
```

3. 不允许直接运行裸启动命令，例如：

```text
streamlit run app.py
npm run dev
uvicorn main:app
python app.py
```

4. 不允许因为端口占用而改用 8001、8502、5174 等临时端口。
5. 不允许临时修改前端 API 地址或后端监听端口来让测试通过。
6. 如果端口无法释放，必须停止并报告错误。

<!-- PORTGUARD_END -->
"""


def readme_port_guard() -> str:
    return r"""# PortGuard 项目端口治理说明

本项目已接入 PortGuard。

## 目的

防止 AI 编码工具在自测时出现：

```text
旧服务没关闭 → 端口被占用 → AI 自动换端口 → 前端和后端地址不一致
```

## 当前项目端口配置

端口配置文件：

```text
config/dev_ports.env
```

## 启动方式

禁止手动裸启动服务。

必须使用：

```bat
scripts\restart_dev.bat
```

## 停止服务

```bat
scripts\stop_dev.bat
```

## 规则

1. 项目端口以 `config/dev_ports.env` 为准。
2. 不允许自动换端口。
3. 端口被占用时，必须清理旧进程。
4. 不允许临时改 API 地址或启动端口。
5. 自测失败时先检查旧进程和端口，而不是修改代码绕过。
"""


def append_or_replace_portguard_block(path: Path) -> None:
    block = claude_md_block()
    if path.exists():
        text = read_text_safe(path)
        pattern = r"\n?<!-- PORTGUARD_START -->.*?<!-- PORTGUARD_END -->\n?"
        if re.search(pattern, text, flags=re.DOTALL):
            text = re.sub(pattern, "\n" + block.strip() + "\n", text, flags=re.DOTALL)
        else:
            text = text.rstrip() + "\n" + block
    else:
        text = block.lstrip()
    write_text(path, text)


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize PortGuard in a project.")
    parser.add_argument("--project", default=".", help="Target project path")
    parser.add_argument("--app-type", default="auto", choices=["auto", "streamlit", "fastapi", "frontend", "fullstack", "generic"])
    parser.add_argument("--app-port", type=int, default=None)
    parser.add_argument("--backend-port", type=int, default=None)
    parser.add_argument("--frontend-port", type=int, default=None)
    parser.add_argument("--no-hook", action="store_true", help="Do not create .claude/settings.json hook")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    project.mkdir(parents=True, exist_ok=True)

    app_type = args.app_type
    if app_type == "auto":
        app_type = detect_project_type(project)

    ports = collect_existing_ports(project)

    write_text(project / "config" / "dev_ports.env", build_dev_ports_env(app_type, ports, args))
    write_text(project / "scripts" / "stop_dev.bat", stop_dev_bat())
    write_text(project / "scripts" / "start_dev.bat", start_dev_bat())
    write_text(project / "scripts" / "restart_dev.bat", restart_dev_bat())
    write_text(project / "scripts" / "port_guard.ps1", port_guard_ps1())
    write_text(project / ".cursor" / "rules" / "port-management.mdc", cursor_rule())
    if not args.no_hook:
        write_text(project / ".claude" / "settings.json", claude_settings_json())
    append_or_replace_portguard_block(project / "CLAUDE.md")
    write_text(project / "README_PORT_GUARD.md", readme_port_guard())

    print("PortGuard initialized successfully.")
    print(f"Project: {project}")
    print(f"Detected app type: {app_type}")
    print("Generated:")
    for rel in [
        "config/dev_ports.env",
        "scripts/stop_dev.bat",
        "scripts/start_dev.bat",
        "scripts/restart_dev.bat",
        "scripts/port_guard.ps1",
        ".cursor/rules/port-management.mdc",
        ".claude/settings.json" if not args.no_hook else None,
        "CLAUDE.md",
        "README_PORT_GUARD.md",
    ]:
        if rel:
            print(f"  - {rel}")
    print("Next self-test command: scripts\\restart_dev.bat")


if __name__ == "__main__":
    main()
