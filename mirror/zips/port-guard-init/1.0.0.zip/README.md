# PortGuard Init Skill

这是一个自包含的 Claude Code / Cursor 项目端口治理 Skill。

它的目标是：在当前项目里生成统一的端口配置、启动脚本、停止脚本、重启脚本和 AI 编码规则，避免 AI 自测时因为端口占用而自动换端口。

## 为什么这一版不包含 .bat 文件？

部分 Skill 上传平台会拦截 `.bat`、`.ps1` 等脚本扩展。为兼容这些平台，本 Skill 包自身不携带 `.bat` 或 `.ps1` 文件。

需要的 Windows 脚本会由 `scripts/portguard_init.py` 在目标项目中按文本方式生成。

## 安装

把整个 `port-guard-init` 文件夹安装到 Claude Skills 目录：

```text
%USERPROFILE%\.claude\skills\port-guard-init
```

如果要支持 `/port-guard-init` 斜杠命令，可以执行：

```bash
python install.py
```

它会把 `commands/port-guard-init.md` 复制到：

```text
%USERPROFILE%\.claude\commands\port-guard-init.md
```

## 使用

在项目根目录打开 Claude Code，输入：

```text
/port-guard-init
```

或手动执行：

```bash
python %USERPROFILE%\.claude\skills\port-guard-init\scripts\portguard_init.py --project . --app-type auto
```
