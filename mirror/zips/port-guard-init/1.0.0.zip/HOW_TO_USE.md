# PortGuard 使用说明

## 1. 初始化当前项目

进入项目根目录后执行：

```text
/port-guard-init
```

如果需要明确指定项目类型，可以告诉 Claude：

```text
/port-guard-init 这是 Streamlit 项目，端口用 8501
```

或：

```text
/port-guard-init 这是前后端分离项目，后端 8010，前端 5180
```

## 2. 初始化后生成什么

```text
config/dev_ports.env
scripts/stop_dev.bat
scripts/start_dev.bat
scripts/restart_dev.bat
scripts/port_guard.ps1
.cursor/rules/port-management.mdc
.claude/settings.json
CLAUDE.md
README_PORT_GUARD.md
```

## 3. 后续怎么要求 AI

对 Claude / Cursor 说：

```text
本项目已经接入 PortGuard。请读取 config/dev_ports.env、CLAUDE.md 和 .cursor/rules/port-management.mdc。所有自测必须通过 scripts/restart_dev.bat，不允许自动换端口。
```
