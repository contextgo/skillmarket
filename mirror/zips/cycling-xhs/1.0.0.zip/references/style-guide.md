# 配图风格详细规范

## 一、手绘涂鸦风格（骑行攻略类）

### 基础参数
```
基础前缀: Hand-drawn doodle on textured white paper with visible grain
配色: green and orange marker coloring
比例: vertical 3:4
尾缀: --style raw --v 6
```

### 氛围关键词
- 自然场景: peaceful, serene, tranquil, refreshing, invigorating
- 人文场景: historic, cultural, atmospheric, poetic
- 安全提醒: clear, informative, poster style

### 构图要素
- 粗黑色轮廓线 (thick black outlines)
- 手绘涂鸦质感 (hand-drawn doodle texture)
- 可见纸张纹理 (visible grain)
- 绿色/橙色 marker 上色
- 装饰元素: 水波纹、树叶、小花、光束、小鸟等

### 标题格式
```
Title "中文标题" in bold green/orange marker top-left
Subtitle "副标题" in smaller orange/green text
```

### 4张标准配图结构

| 图序 | 内容 | 标题色 | 要素 |
|------|------|--------|------|
| 封面 | 路线最具代表性的场景+路线名 | green | 路线名+副标题+装饰 |
| 路书 | 手绘地图: 起点→分段→终点+信息徽章 | green | 地标icon+里程+难度+特色标注 |
| 场景A | 精华段/最美景观 | orange | 景观描述+拍照氛围 |
| 场景B | 次精华/特色场景(古镇/田园/湖景等) | green或orange | 氛围描述+文化/自然元素 |

### 特殊场景提示词模板

**手绘地图:**
```
Hand-drawn doodle illustrated map on textured white paper with grain,
green and orange marker coloring, vertical 3:4.
A [linear/loop] route from [起点] to [终点].
Hand-drawn dotted green line [going upward/clockwise].
Key sections with icons and labels.
Info badges: "全程XXkm" "难度XX" "特色标注".
Title "XX路书" in bold green marker.
--style raw --v 6
```

**安全提醒卡片:**
```
Hand-drawn doodle on textured white paper with grain,
green and orange marker coloring, vertical 3:4.
An illustrated safety tips card with hand-drawn icons.
[2-4] warning sections in a grid, each with icon + text.
Each section in a rounded rectangle with orange warning border.
Title "⚠️ 骑行安全须知" in bold orange marker at top.
--style raw --v 6
```

---

## 二、产品卡片九宫格风格（产品横评类）

### 基础参数
```
比例: ar 3:4 (竖版)
尾缀: --style raw --v 6.1
配色: 橙/黄/青多彩混搭为主，活泼明快
```

### 混搭风格策略
| 内容子类型 | 视觉风格 |
|------------|----------|
| 横评对比 | 暗黑科技风 (dark tech) |
| 选购指南 | 日系简约风 (Japanese minimalist) |
| 装备单品 | 杂志大片风 (magazine editorial) |
| 科普知识 | 3D工业风 (3D industrial) |
| 旗舰评测 | 赛道海报风 (racing poster) |

### 九宫格布局规范
```
背景: #FAFAFA (近白)
网格: 3×3
间隙: 6px 细白间隙
外圆角: 24px
内卡片圆角: 16px
阴影: 柔和阴影 (soft shadow, 0 6px 24px rgba(0,0,0,0.08))
中心卡片: 视觉核心，渐变背景突出主题
```

### 卡片内容规范
- 产品参数卡片感强，数据可视化优先
- 微细节丰富: 纹理/渐变/小图标点缀
- 30px半透明品牌色圆环 + 白色LOGO右上角
- 加粗中文无衬线字体
- 每张卡片含: 品牌名 + 车型名 + 核心参数(2-3个) + 价格

### 九宫格标准布局（8车+封面）
```
[Card 1] [Card 2] [Card 3]
[Card 4] [Card 5] [Card 6]  ← Card 5 = 封面(中心核心位)
[Card 7] [Card 8] [Card 9]
```

### 品牌配色参考
| 品牌 | 配色 |
|------|------|
| XDS 喜德盛 | 紫/绿 |
| CAMP 坎普 | 蓝 |
| GIANT 捷安特 | 深蓝 |
| TRINX 千里达 | 青/蓝绿 |
| MERIDA 美利达 | 蓝 |
| PARDUS 瑞豹 | 红/白 |

---

## 三、通用规范

### 必须遵守
- 比例始终为 ar 3:4（竖版）
- 不在提示词中写尺寸标注（如 "(30px)"）
- 不使用左侧色条边框（left edge 4px solid）
- 标题和副标题使用中文，描述使用英文

### 内容原则
- 默认四季通用，不预设季节色彩（除非用户指定）
- 攻略类默认不含秋季元素（银杏写为"高大茂密"而非"金黄"）
- 如需体现季节，以表格形式列出四季体验而非锁定某季节
