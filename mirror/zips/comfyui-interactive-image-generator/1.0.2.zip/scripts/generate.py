"""
ComfyUI Interactive Image Generator
=====================================
ComfyUI 本地生图技能核心脚本。

功能：
- 动态读取本地模板 JSON，自动解析节点参数
- 动态扫描 checkpoints / loras 目录，自动选择模型
- 支持文生图、图生图两种模式
- 构建完整 ComfyUI workflow JSON 并提交执行

用法示例：
  python generate.py --prompt "a cute crab on sandy beach"
  python generate.py --prompt "..." --template "生图模板1"
  python generate.py --prompt "..." --size 768x512 --steps 30 --cfg 8.0 --seed 42
  python generate.py --prompt "..." --img2img "C:/path/to/image.png" --denoise 0.7
"""

import argparse
import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

# ─────────────────────────────────────────────
# 路径配置（用户本地 ComfyUI 目录）
# ─────────────────────────────────────────────
COMFYUI_USER = Path.home() / "Documents" / "ComfyUI"
COMFYUI_MODELS = COMFYUI_USER / "models"
COMFYUI_OUTPUT = COMFYUI_USER / "output"
COMFYUI_WORKFLOWS = COMFYUI_USER / "user" / "default" / "workflows"

COMFYUI_HOST = "127.0.0.1"
COMFYUI_PORT = 8000
API_BASE = f"http://{COMFYUI_HOST}:{COMFYUI_PORT}"

# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────

def log(msg: str) -> None:
    print(f"[ComfyUI] {msg}", flush=True)


def http_post(path: str, data: dict) -> dict:
    url = f"{API_BASE}{path}"
    body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        raise Exception(f"HTTP {e.code}: {error_body}")


def http_get(path: str) -> dict:
    url = f"{API_BASE}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise Exception(f"HTTP {e.code}")


# ─────────────────────────────────────────────
# 动态模型检测（自动读取本地目录）
# ─────────────────────────────────────────────

def find_checkpoints() -> list[dict]:
    """动态扫描 checkpoints 目录，返回所有可用模型。"""
    checkpoints = []
    paths = [
        COMFYUI_MODELS / "checkpoints",
        COMFYUI_MODELS / "stable_diffusion",
    ]
    for base in paths:
        if not base.exists():
            continue
        for f in base.iterdir():
            if f.suffix.lower() in (".safetensors", ".ckpt", ".pth"):
                checkpoints.append({
                    "name": f.name,
                    "path": str(f),
                    "size": f.stat().st_size,
                })
    return checkpoints


def find_loras() -> list[str]:
    """动态扫描 loras 目录，返回所有 LoRA 文件名。"""
    loras = []
    lora_dir = COMFYUI_MODELS / "loras"
    if lora_dir.exists():
        for f in lora_dir.iterdir():
            if f.suffix.lower() in (".safetensors", ".ckpt", ".pth"):
                loras.append(f.name)
    return loras


def find_best_checkpoint(checkpoints: list[dict]) -> dict:
    """自动选择最佳 checkpoint：优先 SD 1.5，否则用第一个。"""
    if not checkpoints:
        raise Exception(
            f"No checkpoints found. Please put model files in:\n"
            f"  {COMFYUI_MODELS / 'checkpoints'}"
        )
    sd15 = [c for c in checkpoints
            if any(k in c["name"].lower()
                   for k in ["sd15", "v1-5", "1.5", "stable_diffusion_1.5"])]
    if sd15:
        log(f"Auto-select SD 1.5: {sd15[0]['name']}")
        return sd15[0]
    log(f"No SD 1.5 found, using: {checkpoints[0]['name']}")
    return checkpoints[0]


# ─────────────────────────────────────────────
# 动态模板检测（自动读取本地 JSON 文件）
# ─────────────────────────────────────────────

def list_templates() -> list[dict]:
    """扫描 workflows 目录，返回所有可用模板。"""
    if not COMFYUI_WORKFLOWS.exists():
        return []
    return [{"name": f.stem, "path": str(f)}
            for f in COMFYUI_WORKFLOWS.iterdir()
            if f.suffix.lower() == ".json"]


def load_template(path: str) -> dict:
    """读取模板 JSON，返回工作流 dict。"""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _get_widget_values(node: dict) -> list:
    """安全获取节点的 widgets_values（兼容缺失情况）。"""
    return node.get("widgets_values") or []


def _find_widget_input_index(node: dict, name: str) -> int | None:
    """
    查找节点中指定 name 的 widget 输入在 widgets_values 中的索引。
    inputs 是 list，每个元素有 name/link/widget 字段。
    link=null 表示是直接 widget 输入，其值在 widgets_values 中。
    """
    inputs = node.get("inputs", [])
    if not isinstance(inputs, list):
        return None
    widget_idx = 0
    for inp in inputs:
        if not isinstance(inp, dict):
            continue
        link = inp.get("link")
        widget = inp.get("widget")
        # link=null 表示这个输入是 widget 输入
        if link is None and widget:
            if inp.get("name") == name:
                return widget_idx
            widget_idx += 1
    return None


def _safe_get(node: dict, name: str, default=None):
    """从节点的 widgets_values 中获取指定名称的值。"""
    idx = _find_widget_input_index(node, name)
    if idx is None:
        return default
    wv = _get_widget_values(node)
    try:
        return wv[idx]
    except IndexError:
        return default


def parse_template_workflow(wf: dict) -> dict:
    """
    从模板 JSON 解析关键参数。

    遍历所有节点，根据 class_type 提取各参数：
    - checkpoint_name: CheckpointLoaderSimple / widgets_values[0]
    - lora_name/strength: LoraLoader / widgets_values[0,1,2]
    - positive/negative prompt: CLIPTextEncode / widgets_values[0]
    - width/height: EmptyLatentImage / widgets_values[0,1]
    - steps/cfg/sampler/seed: KSampler / widgets_values[0,2,3,4]
    - filename_prefix: SaveImage / widgets_values[0]
    """
    params = {
        "checkpoint_name": None,
        "lora_name": None,
        "lora_strength_model": 1.0,
        "lora_strength_clip": 1.0,
        "positive_prompt": "",
        "negative_prompt": "",
        "width": 512,
        "height": 512,
        "steps": 20,
        "cfg": 7.0,
        "sampler_name": "euler",
        "seed": -1,
        "filename_prefix": "comfyui_output",
    }

    nodes = wf.get("nodes", [])
    if isinstance(nodes, dict):
        nodes = list(nodes.values())
    if not isinstance(nodes, list):
        return params

    clip_encode_prompts = []

    for node in nodes:
        ntype = node.get("type", "")
        wv = _get_widget_values(node)

        if ntype == "CheckpointLoaderSimple":
            params["checkpoint_name"] = str(wv[0]) if wv else None

        elif ntype == "LoraLoader":
            params["lora_name"] = str(wv[0]) if len(wv) > 0 else None
            params["lora_strength_model"] = float(wv[1]) if len(wv) > 1 else 1.0
            params["lora_strength_clip"] = float(wv[2]) if len(wv) > 2 else 1.0

        elif ntype == "CLIPTextEncode":
            text = str(wv[0]) if wv else ""
            if text and text not in ("None", ""):
                clip_encode_prompts.append(text)

        elif ntype == "EmptyLatentImage":
            params["width"] = int(wv[0]) if len(wv) > 0 else 512
            params["height"] = int(wv[1]) if len(wv) > 1 else 512

        elif ntype == "KSampler":
            if len(wv) > 0:
                sv = wv[0]
                if isinstance(sv, (int, float)) and sv >= 0:
                    params["seed"] = int(sv)
            params["steps"] = int(wv[2]) if len(wv) > 2 else 20
            params["cfg"] = float(wv[3]) if len(wv) > 3 else 7.0
            params["sampler_name"] = str(wv[4]) if len(wv) > 4 else "euler"

        elif ntype == "SaveImage":
            params["filename_prefix"] = str(wv[0]) if wv else "comfyui_output"

    # CLIPTextEncode: 第一个为正向，第二个及以后为负向
    if clip_encode_prompts:
        params["positive_prompt"] = clip_encode_prompts[0]
        if len(clip_encode_prompts) > 1:
            params["negative_prompt"] = " ".join(clip_encode_prompts[1:])

    return params


# ─────────────────────────────────────────────
# 工作流构建（根据参数动态生成）
# ─────────────────────────────────────────────

def parse_size(size_str: str) -> tuple[int, int]:
    """解析 '512x512'、'768x512'。"""
    try:
        w, h = size_str.lower().split("x")
        return int(w), int(h)
    except (ValueError, AttributeError):
        return 512, 512


def size_presets(size_str: str) -> tuple[int, int]:
    """解析尺寸快捷键：1:1、16:9、9:16 等。"""
    presets = {
        "1:1": (512, 512),
        "3:4": (384, 512),
        "4:3": (512, 384),
        "9:16": (512, 768),
        "16:9": (768, 512),
    }
    return presets.get(size_str, parse_size(size_str))


def build_workflow(
    prompt: str,
    negative_prompt: str,
    width: int,
    height: int,
    steps: int,
    cfg: float,
    seed: int,
    sampler_name: str,
    checkpoint_name: str,
    lora_name: str | None = None,
    lora_strength_model: float = 1.0,
    lora_strength_clip: float = 1.0,
    img2img_image_path: str | None = None,
    denoise: float = 1.0,
    filename_prefix: str = "comfyui_output",
) -> dict:
    """
    构建完整的 ComfyUI workflow JSON。

    节点 ID 分配（无 LoRA，无 img2img）：
      1  CheckpointLoaderSimple
      4  EmptyLatentImage
      5  CLIPTextEncode (positive)
      6  CLIPTextEncode (negative)
      7  KSampler
      8  VAEDecode
      9  SaveImage

    有 LoRA 时在 1 和 5 之间插入节点 2=LoraLoader，
    img2img 时用节点 2=LoadImage + 3=VAEEncode 替代节点 4，
    两者都有时 1→LoraLoader→LoadImage→VAEEncode→...。

    链接：
      无 LoRA:  1.MODEL→7, 1.CLIP→5, 1.CLIP→6, 1.VAE→8
      有 LoRA:  1.MODEL→2, 1.CLIP→2, 2.MODEL→7, 2.CLIP→5, 2.CLIP→6, 1.VAE→8
      txt2img: 4.LATENT→7
      img2img: 3.LATENT→7, KSampler.denoise < 1.0
    """
    wf = {}
    nid = 1  # 当前可用节点 ID

    # ── 1. CheckpointLoaderSimple ──────────────────────────────────────────
    wf[str(nid)] = {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {"ckpt_name": checkpoint_name}
    }
    ckpt_id = nid; nid += 1

    # ── LoRA 节点（若有）────────────────────────────────────────────────────
    model_src = str(ckpt_id)   # 最终给 KSampler 的 model 来源
    clip_src = str(ckpt_id)    # 最终给 CLIPTextEncode 的 clip 来源

    if lora_name:
        wf[str(nid)] = {
            "class_type": "LoraLoader",
            "inputs": {
                "model": [str(ckpt_id), 0],
                "clip": [str(ckpt_id), 1],
                "lora_name": lora_name,
                "strength_model": lora_strength_model,
                "strength_clip": lora_strength_clip,
            }
        }
        model_src = str(nid)
        clip_src = str(nid)
        nid += 1

    # ── img2img 节点（若有）────────────────────────────────────────────────
    latent_src = None          # 最终给 KSampler 的 latent_image 来源
    vae_src = str(ckpt_id)     # VAE 来源（始终来自 Checkpoint）

    if img2img_image_path:
        # LoadImage
        wf[str(nid)] = {
            "class_type": "LoadImage",
            "inputs": {"image": os.path.basename(img2img_image_path)}
        }
        img_load_id = str(nid); nid += 1

        # VAEEncode
        wf[str(nid)] = {
            "class_type": "VAEEncode",
            "inputs": {
                "pixels": [img_load_id, 0],
                "vae": [vae_src, 2]
            }
        }
        latent_src = str(nid); nid += 1
    else:
        # EmptyLatentImage
        wf[str(nid)] = {
            "class_type": "EmptyLatentImage",
            "inputs": {"width": width, "height": height, "batch_size": 1}
        }
        latent_src = str(nid); nid += 1

    # ── CLIPTextEncode (positive) ────────────────────────────────────────────
    wf[str(nid)] = {
        "class_type": "CLIPTextEncode",
        "inputs": {
            "text": prompt,
            "clip": [clip_src, 1]
        }
    }
    positive_id = str(nid); nid += 1

    # ── CLIPTextEncode (negative) ───────────────────────────────────────────
    neg_text = negative_prompt or (
        "blurry, low quality, ugly, deformed, text, watermark, "
        "cropped, worst quality, jpeg artifacts"
    )
    wf[str(nid)] = {
        "class_type": "CLIPTextEncode",
        "inputs": {
            "text": neg_text,
            "clip": [clip_src, 1]
        }
    }
    negative_id = str(nid); nid += 1

    # ── KSampler ────────────────────────────────────────────────────────────
    wf[str(nid)] = {
        "class_type": "KSampler",
        "inputs": {
            "seed": seed if seed >= 0 else 42,
            "steps": steps,
            "cfg": cfg,
            "sampler_name": sampler_name,
            "scheduler": "normal",
            "denoise": denoise,
            "model": [model_src, 0],
            "positive": [positive_id, 0],
            "negative": [negative_id, 0],
            "latent_image": [latent_src, 0],
        }
    }
    sampler_id = str(nid); nid += 1

    # ── VAEDecode ───────────────────────────────────────────────────────────
    wf[str(nid)] = {
        "class_type": "VAEDecode",
        "inputs": {
            "samples": [sampler_id, 0],
            "vae": [vae_src, 2]
        }
    }
    decode_id = str(nid); nid += 1

    # ── SaveImage ───────────────────────────────────────────────────────────
    wf[str(nid)] = {
        "class_type": "SaveImage",
        "inputs": {
            "filename_prefix": filename_prefix,
            "images": [decode_id, 0]
        }
    }

    return wf


# ─────────────────────────────────────────────
# ComfyUI 服务检测与生成
# ─────────────────────────────────────────────

def check_server() -> bool:
    try:
        http_get("/system_stats")
        return True
    except Exception:
        return False


def upload_image(image_path: str) -> bool:
    """上传图片到 ComfyUI（用于 img2img）。"""
    try:
        with open(image_path, "rb") as f:
            image_data = f.read()
        filename = os.path.basename(image_path)
        import mimetypes
        mime = mimetypes.guess_type(image_path)[0] or "image/png"
        url = f"{API_BASE}/upload/image"
        from urllib.request import Request
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="image"; filename="{filename}"\r\n'
            f"Content-Type: {mime}\r\n\r\n"
        ).encode() + image_data + f"\r\n--{boundary}--".encode()
        req = Request(url, data=body,
                      headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            log(f"Upload result: {result}")
            return True
    except Exception as e:
        log(f"Upload failed: {e}")
        return False


def generate(
    prompt: str,
    negative_prompt: str | None = None,
    template_path: str | None = None,
    size: str = "512x512",
    steps: int | None = None,
    cfg: float | None = None,
    seed: int | None = None,
    sampler_name: str | None = None,
    img2img_image: str | None = None,
    denoise: float = 1.0,
    checkpoint_name: str | None = None,
    lora_name: str | None = None,
    lora_strength_model: float = 1.0,
    lora_strength_clip: float = 1.0,
) -> str:
    """
    主生成函数。

    参数优先级：用户指定 > 模板读取 > 自动检测/默认值
    """
    # 1. 检查服务
    if not check_server():
        raise Exception(
            "ComfyUI is not running. Please start ComfyUI desktop app\n"
            f"  and make sure it is listening on {COMFYUI_HOST}:{COMFYUI_PORT}"
        )

    # 2. 检测模型
    checkpoints = find_checkpoints()
    log(f"Found {len(checkpoints)} checkpoint(s): {[c['name'] for c in checkpoints]}")

    # 3. 检测 LoRA
    available_loras = find_loras()
    log(f"Found {len(available_loras)} LoRA(s): {available_loras}")

    # 4. 解析模板（如指定）
    tpl_params = None
    if template_path:
        log(f"Loading template: {template_path}")
        wf_json = load_template(template_path)
        tpl_params = parse_template_workflow(wf_json)
        log(f"Template params: {tpl_params}")

    # 5. 确定最终参数（用户参数 > 模板参数 > 默认值）
    final_checkpoint = checkpoint_name or (
        tpl_params["checkpoint_name"] if tpl_params else None
    )
    if not final_checkpoint:
        chosen = find_best_checkpoint(checkpoints)
        final_checkpoint = chosen["name"]

    final_lora = lora_name or (
        tpl_params["lora_name"] if tpl_params else None
    )
    if final_lora and final_lora not in available_loras:
        log(f"LoRA '{final_lora}' not found locally, skipping")
        final_lora = None

    # 尺寸：用户指定优先，否则用模板的
    if ":" in size:
        final_width, final_height = size_presets(size)
    else:
        final_width, final_height = parse_size(size)

    # 如果用户没指定 size 且有模板，用模板尺寸（避免模板总是 512x512）
    # 但如果用户显式传了 size 则用用户的
    if tpl_params and size == "512x512":
        # 只有默认512时用模板尺寸
        final_width = tpl_params["width"]
        final_height = tpl_params["height"]

    final_steps = steps if steps is not None else (
        tpl_params["steps"] if tpl_params else 20
    )
    final_cfg = cfg if cfg is not None else (
        tpl_params["cfg"] if tpl_params else 7.0
    )
    final_seed = seed if seed is not None else (
        tpl_params["seed"] if tpl_params else -1
    )
    final_sampler = sampler_name or (
        tpl_params["sampler_name"] if tpl_params else "euler"
    )
    final_positive = prompt or (
        tpl_params["positive_prompt"] if tpl_params else "a beautiful photo"
    )
    final_negative = negative_prompt or (
        tpl_params["negative_prompt"] if tpl_params else None
    )
    filename_prefix = (
        tpl_params["filename_prefix"] if tpl_params else "comfyui_output"
    )

    log(f"Checkpoint: {final_checkpoint}")
    if final_lora:
        log(f"LoRA: {final_lora} (model={lora_strength_model}, clip={lora_strength_clip})")
    log(f"Size: {final_width}x{final_height}, Steps: {final_steps}, CFG: {final_cfg}")
    log(f"Seed: {final_seed}, Sampler: {final_sampler}")

    # 6. 上传图片（如 img2img）
    if img2img_image:
        log(f"Uploading img2img image: {img2img_image}")
        upload_image(img2img_image)

    # 7. 构建工作流
    workflow = build_workflow(
        prompt=final_positive,
        negative_prompt=final_negative,
        width=final_width,
        height=final_height,
        steps=final_steps,
        cfg=final_cfg,
        seed=final_seed,
        sampler_name=final_sampler,
        checkpoint_name=final_checkpoint,
        lora_name=final_lora,
        lora_strength_model=lora_strength_model,
        lora_strength_clip=lora_strength_clip,
        img2img_image_path=img2img_image,
        denoise=denoise,
        filename_prefix=filename_prefix,
    )

    # 8. 提交任务
    log("Submitting job to ComfyUI...")
    result = http_post("/prompt", {"prompt": workflow})
    prompt_id = result.get("prompt_id")
    if not prompt_id:
        raise Exception(f"Failed to submit job: {result}")

    log(f"Job submitted: {prompt_id}")

    # 9. 轮询等待完成
    log("Waiting for generation to complete...")
    start = time.time()
    while True:
        time.sleep(5)
        try:
            history = http_get(f"/history/{prompt_id}")
            item = history.get(prompt_id)
            if item and item.get("status", {}).get("completed"):
                elapsed = time.time() - start
                log(f"Done in {elapsed:.1f}s")
                outputs = item.get("outputs", {})
                for nid, ndata in outputs.items():
                    imgs = ndata.get("images", [])
                    if imgs:
                        fname = imgs[0]["filename"]
                        for d in [COMFYUI_OUTPUT, COMFYUI_USER]:
                            ipath = d / fname
                            if ipath.exists():
                                return str(ipath.resolve())
                        return fname
                raise Exception(f"No output images found: {outputs}")
        except Exception as e:
            if "404" not in str(e) and "not found" not in str(e).lower():
                raise
            elapsed = time.time() - start
            if elapsed > 600:
                raise Exception(f"Timeout after 10 min for {prompt_id}")
            log(f"Still running... ({elapsed:.0f}s)")


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="ComfyUI Interactive Image Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate.py -p "a cute crab on sandy beach"
  python generate.py -p "..." --template "生图模板1"
  python generate.py -p "..." --size 768x512 --steps 30 --cfg 8.0 --seed 42
  python generate.py -p "..." --img2img "C:/img.png" --denoise 0.7
  python generate.py -p "..." --checkpoint "v1-5-pruned-emaonly.safetensors" \\
    --lora "EndminPenguin_Ilv01_50.safetensors"
        """
    )
    parser.add_argument("-p", "--prompt", required=True, help="Positive prompt")
    parser.add_argument("-n", "--negative", default=None, help="Negative prompt")
    parser.add_argument("-t", "--template", default=None,
                        help="Template name (reads from workflows dir)")
    parser.add_argument("-s", "--size", default="512x512",
                        help="Size: 512x512 / 768x512 / 1:1 / 16:9 / 9:16")
    parser.add_argument("--steps", type=int, default=None, help="Sampling steps")
    parser.add_argument("--cfg", type=float, default=None, help="CFG scale")
    parser.add_argument("--seed", type=int, default=None, help="Seed (-1=random)")
    parser.add_argument("--sampler", default=None, help="Sampler (default: euler)")
    parser.add_argument("--checkpoint", default=None, help="Checkpoint filename")
    parser.add_argument("--lora", default=None, help="LoRA filename")
    parser.add_argument("--lora-strength-model", type=float, default=1.0,
                        help="LoRA model strength (default 1.0)")
    parser.add_argument("--lora-strength-clip", type=float, default=1.0,
                        help="LoRA clip strength (default 1.0)")
    parser.add_argument("--img2img", default=None, help="img2img input image path")
    parser.add_argument("--denoise", type=float, default=1.0,
                        help="img2img denoise 0.0-1.0 (default 1.0)")

    args = parser.parse_args()

    # 解析模板路径
    template_path = None
    if args.template:
        tpl_file = COMFYUI_WORKFLOWS / f"{args.template}.json"
        if not tpl_file.exists():
            tpl_file = Path(args.template)
        if tpl_file.exists():
            template_path = str(tpl_file)
        else:
            log(f"WARNING: Template not found: {args.template}")

    # 列出可用资源
    templates = list_templates()
    if templates:
        log(f"Available templates: {[t['name'] for t in templates]}")
    else:
        log("No templates found in workflows directory")

    cpts = find_checkpoints()
    log(f"Available checkpoints: {[c['name'] for c in cpts]}")

    try:
        output_path = generate(
            prompt=args.prompt,
            negative_prompt=args.negative,
            template_path=template_path,
            size=args.size,
            steps=args.steps,
            cfg=args.cfg,
            seed=args.seed,
            sampler_name=args.sampler,
            checkpoint_name=args.checkpoint,
            lora_name=args.lora,
            lora_strength_model=args.lora_strength_model,
            lora_strength_clip=args.lora_strength_clip,
            img2img_image=args.img2img,
            denoise=args.denoise,
        )
        print(f"OUTPUT_PATH:{output_path}")
    except Exception as e:
        print(f"ERROR:{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
