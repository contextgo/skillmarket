# 接口：区域公海退回

HTTP 方法：PUT
接口路径：/rest/data/v2.0/xobjects/territory/actions/release

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| objectApiKey | String | 是 | 目标实体的 API Key（如 `account`、`lead`） | 从 `neocrm metadata:objects` 获取，或根据业务场景确定 |
| ids | Array<Long> | 是 | 要退回的记录 ID 列表 | 从 `neocrm data:query` 结果中取 `id` 字段 |
| releaseReason | Integer | 否 | 退回原因枚举值 | 询问用户 |
| releaseReasonContent | String | 否 | 退回原因详情 | 询问用户 |

## 响应说明

返回 `batchData` 数组，每个元素代表一组相同状态的结果：

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | `200` 表示成功，其他表示失败 |
| errorInfo | String | 失败原因（成功时为空） |
| data.dataList | Array | 该状态对应的记录 ID 列表 |
| data.count | Integer | 该状态对应的记录数量 |

顶层 `code` 含义：
- `200` / `0` / `null`：全部成功
- `3101007`：部分成功（需遍历 `batchData` 查看明细）
- 其他：全部失败

## 调用示例

```bash
neocrm api:put /rest/data/v2.0/xobjects/territory/actions/release \
  -d '{"objectApiKey":"account","ids":[2160286071981259,2160286071981255],"releaseReason":1,"releaseReasonContent":"长期无进展"}'
```
