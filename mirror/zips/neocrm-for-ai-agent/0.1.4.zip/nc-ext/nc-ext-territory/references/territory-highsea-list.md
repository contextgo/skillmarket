# 接口：查询区域公海分组

HTTP 方法：POST
接口路径：/rest/data/v2.0/xobjects/territory/actions/highSeaList

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| objectApiKey | String | 是 | 目标实体的 API Key（如 `account`、`lead`） | 从 `neocrm metadata:objects` 获取，或根据业务场景确定 |

## 响应说明

成功时 `data` 字段为数组，每个元素包含：

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公海分组 ID |
| name | String | 公海分组名称 |

## 调用示例

```bash
neocrm api:post /rest/data/v2.0/xobjects/territory/actions/highSeaList \
  -d '{"objectApiKey":"account"}'
```
