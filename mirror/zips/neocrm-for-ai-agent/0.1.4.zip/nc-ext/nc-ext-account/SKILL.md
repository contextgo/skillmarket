---
name: nc-ext-account
version: "1.0"
description: |
  销售易 CRM 客户（Account）的个性化操作场景。
  当用户需要废弃客户、合并重复客户时使用。退回公海参见 nc-ext-territory。
layer: ext
entity: account
dependencies:
  - nc-base
  - nc-common
related:
  - nc-ext-opportunity
  - nc-ext-territory
---

# 客户扩展操作

## 使用的命令

| 命令 | 用途 | 参数说明 |
|------|------|---------|
| `neocrm data:query` | 查询客户/联系人/商机/活动记录 | `neocrm data:query --help` |
| `neocrm data:get` | 获取客户详情 | `neocrm data:get --help` |
| `neocrm api:patch` | 废弃客户 | 参见 references/account-close.md |
| `neocrm api:post` | 合并客户 | 参见 references/account-merge.md |

---

## 场景列表

| 场景 | 说明 |
|------|------|
| 废弃客户 | 将客户标记为废弃，停止后续跟进 |
| 合并客户 | 将两条重复客户数据合并为一条 |

---

## 场景：废弃客户

### 触发条件

用户确认某个客户已无商业价值，需要将其标记为废弃，停止后续跟进。

### 不适用场景

- 客户有进行中的商机（建议先处理商机再废弃）
- 客户有未完成的合同
- 用户只是想暂停跟进或转移负责人（参见 nc-common 转移负责人）

### 所需输入

- 目标客户（从用户上下文中识别客户名称或 ID）

### 业务流程

确认目标客户后（`neocrm data:query`），向用户展示客户基本信息（`neocrm data:get`）。告知用户废弃后该客户将无法继续跟进，询问是否确认废弃。用户确认后执行废弃操作（`neocrm api:patch`，参见 references/account-close.md），客户状态变更为已废弃。

### 异常处理

- 找不到客户时，引导用户确认客户名称
- 找到多条匹配客户时，展示列表让用户确认
- 废弃失败时，说明原因（如客户有未完成的关联业务）

### 输出格式

- 废弃成功的确认信息
- 客户名称和废弃时间

---

## 场景：合并客户

### 触发条件

用户发现系统中存在两条重复的客户记录，需要将其合并为一条。

### 不适用场景

- 用户只是想更新客户信息（参见 nc-common 编辑记录）
- 用户想删除某个客户（参见废弃客户场景）

### 所需输入

- 主客户（合并后保留的客户）
- 被合并客户（合并后将被删除的客户）
- 合并后主客户需要更新的字段（可选，由用户决定）

### 业务流程

确认主客户和被合并客户（`neocrm data:query`），分别展示两条记录的基本信息（`neocrm data:get`）供用户核对。询问用户合并后主客户是否需要更新某些字段（如客户名称），如需要则通过 `neocrm metadata:describe -o account` 获取字段定义后收集用户输入。

向用户明确说明：合并后被合并客户将被删除，操作不可逆。获得用户确认后执行合并（`neocrm api:post`，参见 references/account-merge.md）。

### 异常处理

- 找不到目标客户时，引导用户确认客户名称
- 找到多条匹配客户时，展示列表让用户确认
- 合并失败时，说明原因，停止操作并询问用户如何处理

### 输出格式

- 合并成功的确认信息
- 保留的主客户名称和 ID
