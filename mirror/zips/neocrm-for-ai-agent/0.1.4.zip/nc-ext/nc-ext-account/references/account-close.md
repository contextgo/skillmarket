# 接口：废弃客户

HTTP 方法：PATCH
接口路径：/rest/data/v2.0/xobjects/account/actions/close

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| accountId | string | 是 | 目标客户的系统 ID | 从 `neocrm data:query` 结果中取 `id` 字段 |

## 响应说明

成功时返回：
- `code`：`"200"` 表示成功
- `msg`：`"OK"`
- `data`：null

## 调用示例

```bash
neocrm api:patch /rest/data/v2.0/xobjects/account/actions/close \
  -d '{"accountId":"<accountId>"}'
```
