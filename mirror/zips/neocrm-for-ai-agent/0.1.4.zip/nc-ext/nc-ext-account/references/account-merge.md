# 接口：合并客户

HTTP 方法：POST
接口路径：/rest/data/v2.0/xobjects/account/actions/merge

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| tAId | number | 是 | 主客户 ID（合并后保留的客户） | 从 `neocrm data:query` 结果中取 `id` 字段 |
| oAId | number | 是 | 被合并客户 ID（合并后将被删除） | 从 `neocrm data:query` 结果中取 `id` 字段 |
| paramMap | object | 是 | 合并后主客户需要更新的字段键值对 | 通过 `neocrm metadata:describe -o account` 获取字段定义，由用户确认需要更新的字段和值 |

## 响应说明

成功时返回：
- `code`：`"200"` 表示成功
- `msg`：`"OK"`
- `data`：null

## 注意事项

- `tAId` 是合并后保留的主客户，`oAId` 是被合并后删除的客户，操作不可逆，执行前必须向用户明确说明
- `paramMap` 中只需传入需要变更的字段，不需要变更的字段不传

## 调用示例

```bash
neocrm api:post /rest/data/v2.0/xobjects/account/actions/merge \
  -d '{"tAId":<主客户ID>,"oAId":<被合并客户ID>,"paramMap":{"accountName":"合并后客户名称"}}'
```
