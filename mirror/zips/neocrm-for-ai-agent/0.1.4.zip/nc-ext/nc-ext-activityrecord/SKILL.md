---
name: nc-ext-activityrecord
version: "1.0"
description: |
  销售易 CRM 活动记录（ActivityRecord）的个性化操作场景。
  当用户需要为商机、客户等业务对象创建跟进记录（如记录电话沟通、添加跟进等）时使用。
layer: ext
entity: activityrecord
dependencies:
  - nc-base
  - nc-common
related:
  - nc-ext-opportunity
  - nc-ext-account
---

# 活动记录扩展操作

## 使用的命令

| 命令 | 用途 | 参数说明 |
|------|------|---------|
| `neocrm data:query` | 查询关联的业务数据（商机/客户等） | `neocrm data:query --help` |
| `neocrm data:create` | 创建活动记录 | `neocrm data:create --help` |
| `neocrm metadata:describe` | 获取活动记录字段定义 | `neocrm metadata:describe -o activityrecord` |
| `neocrm metadata:busitype` | 获取活动类型枚举值 | `neocrm metadata:busitype -o activityrecord` |

---

## 场景列表

| 场景 | 说明 |
|------|------|
| 创建活动记录 | 为业务对象（商机/客户等）创建跟进记录 |

---

## 场景：创建活动记录

### 触发条件

用户明确表示要为某个业务对象（如商机、客户）创建跟进记录、活动记录，或记录一次电话沟通等互动行为。

### 不适用场景

- 用户只是想查询已有的活动记录（参见 nc-common 查询记录）
- 用户想修改已有的活动记录（参见 nc-common 编辑记录）
- 用户想删除活动记录

### 所需输入

- 关联的业务对象类型（商机/客户等）
- 关联的业务数据（从用户上下文中识别名称或 ID）
- 活动类型（从枚举列表中选择）
- 活动内容（用户描述的跟进内容）

### 关键字段说明

创建活动记录时，以下字段需要特殊处理：

| 字段 | 必填 | 说明 | 取值方式 |
|------|------|------|----------|
| `type` | 是 | 活动类型（电话等） | 通过 `neocrm metadata:busitype -o activityrecord` 查询枚举值 |
| `belongId` | 是 | 关联的业务对象 ID | 通过 `neocrm metadata:objects` 获取对应实体的 `objectId` |
| `groupId` | 是 | 关联数据的分组 ID | 通过 `neocrm data:get` 获取关联业务数据的 `innerGroupId` 字段 |
| `itemId` | 是 | 关联的业务数据 ID | 通过 `neocrm data:get` 获取关联业务数据的 `id` 字段|

其他字段定义通过 `neocrm metadata:describe -o activityrecord` 查询获取。

### 业务流程

1. 确认关联的业务对象类型和目标数据（`neocrm data:query`）
2. 获取活动类型枚举列表（`neocrm metadata:busitype -o activityrecord`），展示给用户选择
3. 获取活动记录字段定义（`neocrm metadata:describe -o activityrecord`），收集用户输入的活动内容
4. 从关联业务数据中提取关键字段值：
   - `belongId` ← 通过 `neocrm metadata:objects` 获取对应实体的 `objectId`
   - `groupId` ← 通过 `neocrm data:get` 获取关联业务数据的 `innerGroupId` 字段
   - `itemId` ← 通过 `neocrm data:get` 获取关联业务数据的 `id`

   **⚠️ 前置校验（禁止跳过）：** 执行创建命令前，必须确认 `groupId` 已获取且不为空。如果 `data:get` 返回的 `innerGroupId` 为空或不存在，立即停止并告知用户："关联记录缺少 innerGroupId，无法创建活动记录，请确认关联的业务数据是否正确。"禁止在 groupId 为空时继续执行创建。

5. 向用户确认创建信息，确认后执行创建（`neocrm data:create -o activityrecord`）

### 异常处理

- 找不到关联业务数据时，引导用户确认名称或 ID
- 找到多条匹配数据时，展示列表让用户确认
- 活动类型未选择时，提示用户从枚举列表中选择
- 创建失败时，展示失败原因，停止操作并询问用户如何处理

### 输出格式

- 创建成功的确认信息
- 活动记录的关键信息（活动类型、关联对象、创建时间）
