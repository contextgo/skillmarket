---
name: nc-ext-schedule
version: "1.0"
description: |
  销售易 CRM 日程（Schedule）的个性化操作场景。
  当用户需要创建日程，并可选地关联到任意业务对象（客户、商机、线索等）时使用。
layer: ext
entity: schedule
dependencies:
  - nc-base
  - nc-common
related:
  - nc-ext-opportunity
  - nc-ext-account
---

# 日程扩展操作

## 使用的命令

| 命令 | 用途 | 参数说明 |
|------|------|---------|
| `neocrm metadata:objects` | 获取租户所有实体列表 | `neocrm metadata:objects --help` |
| `neocrm metadata:describe` | 获取实体字段定义 | `neocrm metadata:describe --help` |
| `neocrm data:query` | 查询关联对象 | `neocrm data:query --help` |
| `neocrm data:get` | 获取日程详情 | `neocrm data:get --help` |
| `neocrm api:post` | 创建协同日程 | 参见 references/schedule-create.md |

---

## 场景列表

| 场景 | 说明 |
|------|------|
| 创建关联日程 | 创建日程，可选关联到任意业务对象 |

---

## 场景：创建关联日程

### 触发条件

用户需要创建一个日程，并可选地将日程与某个业务对象关联（如客户、商机、线索或其他任意实体记录）。

### 不适用场景

- 用户只是查询已有日程

### 所需输入

- 日程标题
- 开始时间和结束时间（支持自然语言，如"明天下午3点"）
- 关联对象（可选，从用户上下文中识别实体类型和记录名称）
- 参与人（默认为当前用户，可指定其他人）
- 地址（可选）

### 业务流程

收集日程的基本信息。如需关联业务对象，按以下步骤操作：

1. 通过 `neocrm metadata:objects` 获取租户所有实体列表
2. 根据用户描述（如"客户"、"商机"、"自定义1"等）在结果的 `label` 字段中匹配对应实体，记录其 `apiKey` 和 `objectId`。无法匹配时询问用户
3. 用 `neocrm data:query -q "SELECT id FROM <apiKey> WHERE ..."` 查询具体记录，获取记录 `id` 作为 `entityObjectId`
4. 步骤 2 中获取的 `objectId` 作为 `entityBelongId`

通过 `neocrm auth:whoami` 获取当前用户 ID。向用户展示将要创建的日程内容，确认后创建日程（`neocrm api:post`，参见 references/schedule-create.md）。

注意：协同日程必须使用专用接口创建，不能使用 `neocrm data:create`，否则会报参数错误。

### 异常处理

- 时间解析失败时，请用户提供更明确的时间
- 关联对象找不到时，引导用户确认名称
- 创建失败时，说明原因

### 输出格式

- 日程创建成功的确认信息
- 日程标题、时间、地址、参与人、关联对象
