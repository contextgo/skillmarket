# 接口：创建日程

HTTP 方法：POST
接口路径：/rest/data/v2.0/xobjects/schedule/actions/createScheduleWithMember

注意：日程必须使用此专用接口创建，不能使用 `neocrm data:create`，否则报参数错误。

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| name | string | 是 | 日程名称 | 询问用户 |
| startDate | number | 是 | 开始时间（毫秒时间戳），重复日程须为首次发生的开始时间 | 根据用户输入的自然语言时间转换 |
| endDate | number | 是 | 结束时间（毫秒时间戳），重复日程须为首次发生的结束时间 | 根据用户输入的自然语言时间转换 |
| isAllDay | number | 是 | 是否全天（0=否，1=是） | 询问用户，默认 0 |
| isRecur | number | 是 | 是否重复事件（0=否，1=是） | 询问用户，默认 0 |
| members | string | 是 | 日程成员 ID，多人用半角逗号分隔 | 通过 `neocrm auth:whoami` 获取当前用户 ID；其他参与人通过 `neocrm data:query` 查询 |
| description | string | 否 | 日程描述 | 询问用户 |
| address | string | 否 | 地址 | 询问用户 |
| entityBelongId | number | 否 | 关联对象的 objectId（注意：这是实体的 objectId，不是记录的 entityType 或记录 ID） | 通过 `neocrm metadata:objects` 获取，从结果中找到对应 apiKey 的 `objectId` 字段 |
| entityObjectId | number | 否 | 关联数据 ID，即具体记录的 ID | 从 `neocrm data:query` 结果中取关联记录的 `id` 字段 |
| isPrivate | number | 否 | 是否私密（0=否，1=是） | 询问用户，默认 0 |
| type | number | 否 | 日程类型 ID | 通过 `neocrm metadata:describe -o schedule` 获取 type 字段的可选值 |
| reminder | number | 否 | 开始提醒时间（距离开始时间的秒数） | 询问用户 |
| allowJoin | number | 否 | 是否允许成员邀请参与人（0=否，1=是） | 询问用户，默认 0 |
| frequency | number | 否 | 重复频率（0=否，1=按天，2=按周，3=按月，4=按年），仅 isRecur=1 时需要 | 询问用户 |
| Interval | number | 否 | 重复间隔（如每2天），仅 isRecur=1 时需要 | 询问用户 |
| recurStopCo | number | 否 | 中止条件（0=无，1=永不截止，2=按时间截止），仅 isRecur=1 时需要 | 询问用户 |
| recurStopValue | number | 否 | 中止条件值（毫秒时间戳），仅 recurStopCo=2 时需要 | 根据用户输入转换 |
| finalFinishTime | number | 否 | 最终结束时间（毫秒时间戳） | 根据用户输入转换 |
| day | string | 否 | 每月X号发生（如"10"），按月/年重复时必填 | 询问用户 |
| week | string | 否 | 每周X发生（如"3"=周三），按周重复时必填 | 询问用户 |
| month | string | 否 | 每年X月发生（如"1"），按年重复时必填 | 询问用户 |

## 响应说明

成功时返回：
- `code`：200 表示成功
- `result.scheduleId`：新建日程的系统 ID

## 调用示例

```bash
neocrm api:post /rest/data/v2.0/xobjects/schedule/actions/createScheduleWithMember \
  -d '{"name":"月度总结会议","startDate":1732154400000,"endDate":1732156200000,"isAllDay":0,"isRecur":0,"members":"<userId>","entityBelongId":<objectId>,"entityObjectId":<recordId>}'
```
