---
name: nc-ext-feed
version: "1.0"
description: |
  销售易 CRM 社交动态（Story）的个性化操作场景。
  当用户需要在工作圈发布动态、或在客户/商机等对象下发布动态时使用。
layer: ext
dependencies:
  - nc-base
  - nc-common
related:
  - nc-ext-account
  - nc-ext-opportunity
---

# 社交动态扩展操作

## 使用的命令

| 命令 | 用途 | 参数说明 |
|------|------|---------|
| `neocrm data:query` | 查询关联对象 | `neocrm data:query --help` |
| `neocrm data:get` | 获取关联对象详情 | `neocrm data:get --help` |
| `neocrm api:post` | 发布动态 | 参见 references/social-story-create.md |

---

## 场景列表

| 场景 | 说明 |
|------|------|
| 发布动态 | 在工作圈或对象下发布文本动态 |

---

## 场景：发布动态

### 触发条件

用户需要在工作圈发布一条动态，或在某个客户、商机等业务对象下发布动态。

### 不适用场景

- 用户要求发送消息或通知给特定人（不是动态功能）
- 用户要求修改或删除已有动态

### 所需输入

- 动态内容（从用户上下文中识别）
- 发布位置：工作圈（默认）或指定对象下（从用户上下文中识别）

### 业务流程

收集动态内容，判断发布位置：

**工作圈发布：** 通过 `neocrm auth:whoami` 获取当前用户 ID，向用户确认动态内容后发布（`neocrm api:post`，参见 references/social-story-create.md）。

**对象下发布：** 确认目标对象（`neocrm data:query`），通过 `neocrm metadata:objects` 获取对应实体的 `objectId`（作为 `belongId`），记录的 `id` 作为 `objectId`。通过 `neocrm auth:whoami` 获取当前用户 ID。向用户确认动态内容和发布位置后发布（`neocrm api:post`，参见 references/social-story-create.md）。

注意：当前仅支持纯文本动态。文件和图片动态需要先通过文件上传接口上传，CLI 暂不支持文件上传，如用户需要发送文件或图片动态，告知用户当前不支持。

### 异常处理

- 关联对象找不到时，引导用户确认名称
- 发布失败时，说明原因

### 输出格式

- 发布成功的确认信息
- 动态内容摘要和发布位置
