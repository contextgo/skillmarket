# 接口：发布动态

HTTP 方法：POST
接口路径：/rest/data/v2.0/social/story

## 请求参数

| 参数名 | 类型 | 是否必填 | 说明 | 获取方式 |
|--------|------|---------|------|---------|
| content | string | 是 | 动态内容 | 询问用户 |
| belongId | number | 否 | 对象 ID，为空时表示在工作圈发送 | 通过 `neocrm metadata:objects` 获取对应实体的 `objectId` 字段 |
| objectId | number | 否 | 对象数据 ID，与 belongId 组合表示在对象下发送 | 从 `neocrm data:query` 结果中取关联对象的 `id` 字段 |
| userId | number | 否 | 动态发送人 | 通过 `neocrm auth:whoami` 获取当前用户 ID |
| uploadFileType | number | 否 | 附件类型：空=纯文本，0=普通文件，1=图片 | 根据用户提供的附件类型判断 |
| fileDescription | string | 否 | 文件或图片的描述 | 询问用户 |
| fileInfo | object | 否 | 上传的文件信息（uploadFileType=0 时），每次一个文件 | 文件需先通过文件上传接口上传，取返回的 fileUrl、fileLength、fileName |
| imageFiles | array | 否 | 上传的图片信息数组（uploadFileType=1 时），最多 9 张 | 图片需先通过文件上传接口上传，取返回的 fileUrl、fileLength、fileName、filePixels |

## fileInfo 结构（普通文件）

| 字段 | 类型 | 说明 |
|------|------|------|
| fileUrl | string | 文件 URL（上传后获取） |
| fileLength | string | 文件大小（字节） |
| fileName | string | 文件名 |

## imageFiles 数组元素结构（图片）

| 字段 | 类型 | 说明 |
|------|------|------|
| fileUrl | string | 图片 URL（上传后获取） |
| fileLength | string | 文件大小（字节） |
| fileName | string | 文件名 |
| filePixels | object | 图片尺寸信息，包含 small、origin、large 三个尺寸的 width 和 height |

## 响应说明

成功时返回：
- `code`：200 表示成功
- `result.data`：新建动态的系统 ID

## 调用示例

```bash
neocrm api:post /rest/data/v2.0/social/story \
  -d '{"content":"动态内容","userId":<userId>}'
```

在对象下发布动态：
```bash
neocrm api:post /rest/data/v2.0/social/story \
  -d '{"content":"动态内容","userId":<userId>,"belongId":<objectId>,"objectId":<recordId>}'
```
