---
name: metadata-describe
description: |
  neocrm metadata:describe 接口协议。获取指定实体的完整字段定义。
  必须先写文件验证完整后再使用。
---

# metadata:describe 接口协议

## 命令

```
neocrm metadata:describe -o <entityApiKey>
```

`<entityApiKey>` 为 `metadata:objects` 返回的 `apiKey`，如 `account`、`contact`、`opportunity`、`lead` 等。

## 返回结构

```json
{
  "fields": [
    {
      "apiKey": "accountName",
      "label": "客户名称",
      "type": "text",
      "referTo": null,
      "required": false,
      "createable": true,
      "updateable": true,
      "sortable": true,
      "queryable": true,
      "defaultValue": null,
      "helpText": null,
      "description": null,
      "enabled": true,
      "maxLength": 100,
      "minLength": 0,
      "precision": null,
      "scale": null,
      "selectitem": null,
      "businessCategory": null,
      "stageRequired": null,
      "position": 0,
      "dependentPropertyName": null,
      "lookupFilter": null,
      "enableCheckrule": false,
      "enableDuplicateRule": false,
      "fieldType": "normal"
    },
    {
      "apiKey": "ownerId",
      "label": "所属人",
      "type": "owner",
      "referTo": { "apiKey": "user" },
      "required": true,
      "createable": false,
      "updateable": false,
      "sortable": true,
      "queryable": true,
      "defaultValue": null,
      "helpText": null,
      "description": null,
      "enabled": true,
      "maxLength": null,
      "minLength": null,
      "precision": null,
      "scale": null,
      "selectitem": null,
      "businessCategory": null,
      "stageRequired": null,
      "position": 0,
      "dependentPropertyName": null,
      "lookupFilter": null,
      "enableCheckrule": false,
      "enableDuplicateRule": false,
      "fieldType": "normal"
    },
    {
      "apiKey": "industry",
      "label": "行业",
      "type": "picklist",
      "referTo": null,
      "required": false,
      "createable": true,
      "updateable": true,
      "sortable": true,
      "queryable": true,
      "defaultValue": null,
      "helpText": null,
      "description": null,
      "enabled": true,
      "maxLength": null,
      "minLength": null,
      "precision": null,
      "scale": null,
      "selectitem": [
        { "value": "1", "label": "互联网" },
        { "value": "2", "label": "金融" },
        { "value": "3", "label": "制造业" }
      ],
      "businessCategory": null,
      "stageRequired": null,
      "position": 0,
      "dependentPropertyName": null,
      "lookupFilter": null,
      "enableCheckrule": false,
      "enableDuplicateRule": false,
      "fieldType": "normal"
    }
  ]
}
```

## 字段结构说明

每个字段是一个 JSON 对象，包含以下属性：

### 核心属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `apiKey` | string | **字段唯一标识**，XOQL 中使用此名称，**禁止猜测** |
| `label` | string | 字段的中文显示名称，用于人类阅读和调试 |
| `type` | string | 字段数据类型，见下方"字段类型参考表" |
| `referTo` | object \| null | 当 `type=reference` 或 `type=owner` 时，指明关联到的实体，格式为 `{ apiKey: "entityName" }`；否则为 null |

### 操作控制属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `required` | boolean | 是否必填（全局） |
| `createable` | boolean | 创建时是否可写入 |
| `updateable` | boolean | 更新时是否可修改 |
| `sortable` | boolean | 是否可用于 ORDER BY |
| `queryable` | boolean | 是否可用于 WHERE 条件 |

> **重要**：`sortable: false` 或 `queryable: false` 的字段，XOQL 中不能用于排序或过滤。强行使用会报错 `no such column`。

### 值约束属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `maxLength` | number \| null | 文本最大长度 |
| `minLength` | number \| null | 文本最小长度 |
| `precision` | number \| null | 数值总精度（小数点前+后总位数） |
| `scale` | number \| null | 数值小数精度（小数位数） |
| `defaultValue` | any \| null | 默认值 |

### 枚举字段属性（type=picklist / multipicklist）

| 属性 | 类型 | 说明 |
|------|------|------|
| `selectitem` | array \| null | 可选值列表，每项为 `{ value, label }` 结构 |

> `selectitem` 是枚举字段的可选值来源。**禁止硬编码枚举值**，必须从 describe 结果的 `selectitem` 中取。

### 其他属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `helpText` | string \| null | 字段帮助提示 |
| `description` | string \| null | 字段描述 |
| `enabled` | boolean | 字段是否启用 |
| `stageRequired` | string \| null | 在特定业务阶段才必填 |
| `position` | number | 字段在表单中的顺序 |
| `dependentPropertyName` | string \| null | 字段依赖的其他字段 |
| `lookupFilter` | string \| null | 查找过滤条件 |
| `fieldType` | string | 字段类型变体：`normal` = 普通，`formula_date` = 日期公式等 |

## 字段类型参考表

| type 值 | 中文名 | XOQL 值写法示例 | 对应场景 |
|---------|--------|----------------|---------|
| `text` | 单行文本 | `'文本内容'` | 名称、标题等 |
| `textarea` | 多行文本 | `'文本内容'` | 备注、描述 |
| `richtext` | 富文本 | `'HTML内容'` | 富文本内容 |
| `picklist` | 下拉单选 | `'value值'` | 枚举选择 |
| `multipicklist` | 下拉多选 | `'value1;value2'` | 多选枚举 |
| `currency` | 货币金额 | `200000` | 金额字段（不带货币符号） |
| `float` / `double` | 数值/小数 | `123.45` | 科学数值 |
| `integer` | 整数 | `100` | 整数字段 |
| `boolean` | 布尔 | `true` / `false` | 是否xxx字段 |
| `date` | 日期 | `1776211200000` | 日期。显示为 ISO 字符串（`2026-04-15`），存储和传入值必须为毫秒时间戳 |
| `datetime` | 日期时间 | `1776215718000` | 日期时间。显示为 ISO 字符串（`2026-04-15T10:30:00+08:00`），存储和传入值必须为毫秒时间戳 |
| `time` | 时间 | `13:53:00` | 时间（不含日期） |
| `reference` | Lookup关联 | `'921913753305571'` | 关联到其他实体的ID |
| `owner` | 负责人 | `'921913753305571'` | 记录负责人，固定关联 user 实体，可查询可排序 |
| `autonumber` | 自动编号 | 系统生成 | 不可写 |
| `formula_*` | 公式字段 | 不可写 | 只读 |
| `email` | 邮箱 | `'xxx@domain.com'` | 邮箱地址 |
| `phone` | 电话 | `'+86-138-0000-0000'` | 电话号码 |
| `url` | 网址 | `'https://...'` | URL |
| `percent` | 百分比 | `0.15` | 百分比（存小数如0.15表示15%） |
| `image` | 图片 | 系统处理 | 图片附件 |
| `doc` | 文档 | 系统处理 | 文档附件 |

> **重要**：currency/float/integer 等数值类型在 XOQL 中不加分号，直接写数字。

> **date/datetime 格式规则**：CRM 查询到结果中 date/datetime 类型显示的时候转换为 ISO 日期字符串（如 `2026-04-15`），但**创建/更新/查询时传入值必须为毫秒时间戳**（如 `new Date("2026-04-15").getTime()` = `1776211200000`）

## reference 字段说明

`type=reference` 的字段存储目标实体的 record ID（字符串）。关联字段的 referTo 对象指明了可以关联到哪个实体。

常见 reference 字段（account 实体的典型字段）：

| apiKey | label | referTo | 说明 |
|--------|-------|---------|------|
| `createdBy` | 创建人 | `{ apiKey: "user" }` | 创建人 |
| `updatedBy` | 更新人 | `{ apiKey: "user" }` | 更新人 |
| `accountId` | 客户 | `{ apiKey: "account" }` | 关联客户 |
| `contactId` | 联系人 | `{ apiKey: "contact" }` | 关联联系人 |
| `leadId` | 线索 | `{ apiKey: "lead" }` | 关联线索 |
| `dimDepart` | 所属部门 | `{ apiKey: "department" }` | 部门维度 |
| `dimArea` | 所属区域 | `{ apiKey: "territory" }` | 区域维度 |

## owner 字段说明

`type=owner` 的字段是特殊类型，专门用于存储记录负责人。与 `reference` 的区别：

| 对比项 | owner | reference |
|--------|-------|-----------|
| type 值 | `"owner"` | `"reference"` |
| referTo 固定指向 | `{ apiKey: "user" }` | 任意实体 |
| 用途 | 记录负责人 | 关联其他业务对象 |
| 字段名 | 固定为 `ownerId` | 自定义 |

常见 owner 字段：

| apiKey | label | type | referTo | 说明 |
|--------|-------|------|---------|------|
| `ownerId` | 所属人/负责人 | `owner` | `{ apiKey: "user" }` | 记录负责人，可查询、可排序 |

## 完整性保障

> **核心原则**：必须使用可靠的输出捕获方式确保接口返回值完整。验证只是最后的保险手段。

### 第一优先：可靠的输出获取

**必须先写到临时文件**（禁止通过管道直接传递给 `ConvertFrom-Json` 或 `jq`）：

```powershell
neocrm metadata:describe -o account > "$env:TEMP\_nc_describe.json"
$content = Get-Content "$env:TEMP\_nc_describe.json" -Raw
```

**禁止**：
- ❌ 通过管道直接传给 `ConvertFrom-Json`（PowerShell 对超大 JSON 静默截断，不报错但数据丢失）
- ❌ 通过管道直接传给 `jq`（截断的 JSON 导致 jq 解析出空结果或报错）

**超长输出（>50KB）或含中文参数时推荐用 Node.js 脚本**：

```javascript
const { execSync } = require('child_process');
const result = execSync('neocrm metadata:describe -o account', { encoding: 'utf-8', maxBuffer: 50 * 1024 * 1024 });
const data = JSON.parse(result);
// 处理 data.fields ...
```

### 第二优先：结果验证（保险手段）

**Step 1 - JSON 结构完整性：** 末尾必须是 `}` 或 `]`。

**Step 2 - fields 数组存在：** `"fields"\s*:\s*\[`

**Step 3 - 字段数量合理性：** apiKey 出现次数 > 10

**Step 4 - 解析后字段不为 null：** PowerShell `ConvertFrom-Json` 截断后顶层字段存在但嵌套字段为 `$null`，必须显式检查 `$json.data.fields` 是否为 `$null`

**Step 5 - 验证失败处理：** 停止所有后续操作，告知用户

## 字段映射正确步骤

1. 调用 `metadata:describe`，验证输出完整（见上方验证流程）
2. 从已验证的完整内容中，按 `label` 搜索中文需求对应的字段
3. 记录 apiKey、type、referTo（reference/owner 字段）
4. **禁止反向操作**：不许先猜 apiKey，再填入映射表

```powershell
# 正确示例：先从文件找 label，再取 apiKey
$content = Get-Content "$env:TEMP\_nc_describe_account.json" -Raw
# 找"客户名称"对应的 apiKey
if ($content -match '"label"\s*:\s*"客户名称"') {
    # 从该字段对象中提取 apiKey
    $apiKey = [regex]::Match($content, '"label"\s*:\s*"客户名称"[^{]*"apiKey"\s*:\s*"([^"]+)"').Groups[1].Value
    Write-Host "客户名称 → $apiKey"
}
```

## 典型 response 规模

- account 实体：约 200~400 个字段（含大量 customItem）
- 输出 JSON 行数：约 5000~20000 行
- 文件大小：通常 500KB~3MB

> **PowerShell 注意**：PowerShell 的 `ConvertFrom-Json` 对超大 JSON（> 1MB）存在截断行为，建议始终用"先写文件 → 从文件读取 → 正则提取"的方式处理，`ConvertFrom-Json` 仅用于小文件或已验证完整的文件。
