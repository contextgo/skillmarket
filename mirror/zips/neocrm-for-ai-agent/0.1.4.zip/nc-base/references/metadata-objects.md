---
name: metadata-objects
description: |
  neocrm metadata:objects 接口协议。获取租户所有实体（标准 + 自定义）的元数据列表。
  必须先写文件验证完整后再使用。
---

# metadata:objects 接口协议

## 命令

```
neocrm metadata:objects
```

## 返回结构（实测 v2.3）

```json
{
  "code": "0",
  "msg": "成功",
  "data": {
    "totalSize": 1135,
    "count": 1135,
    "records": [
      {
        "apiKey": "account",
        "label": "客户",
        "objectId": 1,
        "objectType": 2,
        "active": true,
        "custom": false,
        "enableBusitype": true,
        "enableCheckrule": true,
        "enableScriptExecutor": true,
        "detail": false,
        "archived": false,
        "description": null,
        "iconId": 3
      },
      {
        "apiKey": "customEntity598__c",
        "label": "软件开发日记",
        "objectId": 3938126146163866,
        "objectType": 2,
        "active": true,
        "custom": true,
        "enableBusitype": true,
        "enableCheckrule": true,
        "enableScriptExecutor": true,
        "detail": false,
        "archived": false,
        "description": "自定义实体888",
        "iconId": null
      }
    ]
  }
}
```

## 关键字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `apiKey` | string | 实体的唯一标识，用于 `data:query -o <apiKey>` 和 `metadata:describe -o <apiKey>` |
| `label` | string | 实体的中文显示名称（用户友好） |
| `objectId` | number | 实体在系统内的唯一 ID（数字，非字符串），`metadata:describe` 等接口需要此字段 |
| `objectType` | number | 实体类型：`2` = 业务对象（含标准+自定义），其他值待补充 |
| `active` | boolean | 是否启用；`false` 的实体通常不可操作 |
| `custom` | boolean | `true` = 自定义实体，`false` = 标准实体 |
| `detail` | boolean | `true` = 子实体（主子关系中的子表），`false` = 主实体 |
| `archived` | boolean | 是否已归档 |
| `enableBusitype` | boolean | 是否启用业务类型 |
| `enableCheckrule` | boolean | 是否启用校验规则 |
| `enableScriptExecutor` | boolean | 是否支持脚本执行 |
| `description` | string | 实体描述，可能为 null |

## objectType 补充说明

| 值 | 含义 | 示例 |
|----|------|------|
| `1` | 标准业务对象 | account（客户）、contact（联系人）、opportunity（商机）、lead（线索）等 |
| `2` | 自定义业务对象 | 自定义实体，通常 apiKey 以 `__c` 结尾 |
| `3` | 审批流对象 | businessCategory=2 的审批类自定义实体 |

> **注意**：`objectType=2` 包含标准业务对象（如 account、contact）和自定义业务对象。区分标准/自定义用 `custom` 字段（`custom: false` = 标准，`custom: true` = 自定义），不要通过 apiKey 是否以 `__c` 结尾来判断。

## 完整性保障

> **核心原则**：必须使用可靠的输出捕获方式确保接口返回值完整。验证只是最后的保险手段。

### 第一优先：可靠的输出获取

**必须先写到临时文件**（禁止通过管道直接传递给 `ConvertFrom-Json` 或 `jq`）：

```powershell
neocrm metadata:objects > "$env:TEMP\_nc_objects.json"
$content = Get-Content "$env:TEMP\_nc_objects.json" -Raw
```

**禁止**：
- ❌ 通过管道直接传给 `ConvertFrom-Json`（PowerShell 对超大 JSON 静默截断，不报错但数据丢失）
- ❌ 通过管道直接传给 `jq`（截断的 JSON 导致 jq 解析出空结果或报错）

**超长输出（>50KB）或含中文参数时推荐用 Node.js 脚本**：

```javascript
const { execSync } = require('child_process');
const fs = require('fs');
const result = execSync('neocrm metadata:objects', { encoding: 'utf-8', maxBuffer: 50 * 1024 * 1024 });
const full = JSON.parse(result);
const records = full.data.records; // 注意：是 data.records 不是 objectList
```

### 第二优先：结果验证（保险手段）

**Step 1 - JSON 结构完整性：** 末尾必须是 `}` 或 `]`

**Step 2 - code=0：** `"code"\s*:\s*"0"` 表示成功

**Step 3 - data.records 数组存在：** `"records"\s*:\s*\[`

**Step 4 - 记录数合理性：** `totalSize` 和 `count` 应 > 0，两者应相等

**Step 5 - 解析后 records 不为空：** `full.data.records && full.data.records.length > 0`

**Step 6 - 验证失败处理：** 停止所有后续操作，告知用户

## 查找目标实体的正确步骤

1. 调用 `metadata:objects`，验证输出完整（见上方验证流程）
2. 从已验证的完整文件中搜索 `label` 字段（中文名称模糊匹配）
3. 找到匹配实体后，记录 `apiKey` 和 `objectId`
4. **禁止凭 apiKey 名称猜测其 label**，必须从 `metadata:objects` 的 label 列表中查找

```powershell
# 错误做法：直接猜 apiKey = "account" 而不查 metadata:objects
# neocrm metadata:describe -o account

# 正确做法：
# Step 1: 找到 label = "客户" 对应的 apiKey
$content = Get-Content "$env:TEMP\_nc_objects.json" -Raw
# 在 content 中搜索 label 包含"客户"的实体
$lines = $content -split '\n'
$lines | Where-Object { $_ -match '客户' } | ForEach-Object {
    $apiKey = [regex]::Match($_, '"apiKey"\s*:\s*"([^"]+)"').Groups[1].Value
    Write-Host "found: $apiKey"
}
```

## 缓存策略

- 验证通过后，提取简化版实体列表（apiKey、label、objectId、objectType、active）写入 `memory/neocrm-entity-cache.json`
- 之后直接读缓存文件，不再调用 `metadata:objects`
- 业务异常时（目标实体找不到）或用户要求时删除缓存重新获取

## 典型 response 规模

- 标准租户：约 1000~1200 个实体（含大量自定义 entity）
- 输出 JSON 行数：约 3000~8000 行
- 文件大小：通常 300KB~1.5MB
