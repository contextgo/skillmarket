---
name: neo-skills-for-agent
version: "1.0"
description: |
  NeoCRM AI Agent Skill Pack。让 AI Agent 通过自然语言操作销售易 CRM。支持对任意实体的查询、创建、编辑、锁定、解锁等通用操作，以及客户、商机、线索、日程、活动记录、公海池、社交动态等场景的个性化操作。
  当用户需要通过 AI Agent 操作 NeoCRM 时安装此 skill pack。
  执行任何操作前必须先阅读并遵守 nc-base/SKILL.md 的所有规范。
---

# NeoCRM Skill Pack

本 skill pack 采用三层结构外加一个技能工作台，平台会自动扫描所有子目录并分别加载各 skill：

- `nc-base/`：基础层，AI Agent 通用行为规范，所有其他 skill 的依赖
- `nc-common/`：通用操作层，查询、创建、编辑、转移、锁定、解锁等跨实体标准操作
- `nc-ext/nc-ext-*/`：扩展操作层，各实体的个性化场景，持续扩展中
- `nc-skillbench/`：自定义技能工作台，借助工作台技能可以引导用户生成自己基于 neocrm 命令的个性化技能

## 当前已有的扩展操作

| Skill | 覆盖场景 |
|-------|---------|
| `nc-ext-account` | 废弃客户、合并客户 |
| `nc-ext-activityrecord` | 创建活动记录（跟进记录） |
| `nc-ext-feed` | 发布工作圈 / 对象下动态 |
| `nc-ext-opportunity` | 超时未跟进商机查询 |
| `nc-ext-schedule` | 创建关联日程 |
| `nc-ext-territory` | 公海领取线索、公海领取客户、退回公海 |
| `nc-ext-visit-prepare` | 拜访前准备（客户/商机/线索三入口） |
