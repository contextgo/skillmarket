---
name: nc-common
version: "1.5"
description: |
  NeoCRM 通用操作层。包含适用于所有实体的标准操作：查询记录、创建记录、编辑记录、转移负责人、锁定记录、解锁记录。
  当用户需要对任意 CRM 实体执行这些标准操作时使用。遵守 nc-base 规范。
layer: common
dependencies:
  - nc-base
---

# 通用操作层

## 总纲

### 强制检查

执行[nc-base](../nc-base/SKILL.md)中的强制检查

### 黄金法则

所有操作必须遵守 [nc-base](../nc-base/SKILL.md) 的黄金法则：
- 先 describe，再操作
- 禁止硬编码字段名
- 写操作展示再确认
- 失败即停

---

### 命令速查

| 命令 | 用途 |
|------|------|
| `neocrm data:query` | 查询记录列表（XOQL），用 `-d` 传查询条件 JSON |
| `neocrm data:get` | 查询单条记录 |
| `neocrm data:create` | 创建记录，用 `-v` 传字段值 JSON |
| `neocrm data:update` | 更新记录，用 `-v` 传字段值 JSON |
| `neocrm data:lock` | 锁定记录（用 `-r` 传记录 ID） |
| `neocrm data:unlock` | 解锁记录（用 `-r` 传记录 ID） |
| `neocrm metadata:describe` | 获取实体字段定义 |
| `neocrm metadata:busitype` | 获取业务类型列表 |
| `neocrm metadata:objects` | 获取当前租户所有实体列表 |
| `neocrm auth:whoami` | 获取当前用户信息 |
| `neocrm auth:login` | 登录 NeoCRM，需 `-c <clientId>` 参数 |

**`-v` / `-d` 参数的 data 包装：**

所有写操作的 JSON 必须包装在 `data` 字段下：

```json
// 正确
{ "data": { "accountName": "销售易", "money": 100000 } }

// 错误
{ "accountName": "销售易", "money": 100000 }
```

---

### 强制执行顺序

所有操作共用以下统一框架，**禁止跳过任何步骤**：

```
Step 1. metadata:describe        → 获取字段定义（必须先执行）
Step 2. 构建字段映射表           → 按 label 搜索每个字段，记录 apiKey / type / 用途
Step 3. 构造接口调用             → 仅使用映射表中的 apiKey
Step 4. 执行 data:* 命令
Step 5. 展示结果 / 对比          → 查询展示解析后结果；写操作展示完整待确认数据
Step 6. 写操作确认               → 用户确认后才真正执行（创建/更新/删除）
```

---

### 字段映射表规范

字段映射表规范详见 [nc-base](../nc-base/SKILL.md) 的"强制字段映射步骤"，nc-common 各操作章节不再重复。执行时直接引用 nc-base 的定义。

---

### 展示规范

**查询结果展示（Step 5 查询场景）**

- 禁止直接展示 ID，必须通过 `data:get` 解析为可读名称
- 选取最有价值的字段（通常 5 个以内），不盲目列出全部
- 关联字段（reference / owner）只展示名称，不展示原始 ID

❌ 错误：`客户ID: 2786478989087903`（用户看不懂）
✅ 正确：`客户：仁科互联科技有限公司，负责人：张三`

**写操作前确认（Step 6 写操作场景）**

展示完整的待确认数据，等用户回复后再执行。不同操作有不同要求：

| 操作 | 确认内容 |
|------|---------|
| 创建 | 全部字段值 + 业务类型 |
| 更新 | 字段名 + 修改前值 → 修改后值 对比表 |
| 转移负责人 | 当前负责人 → 新负责人 |
| 锁定 | 确认目标记录 + 锁定效果说明 |
| 解锁 | 确认目标记录 + 解锁效果说明 |

---

### 异常处理通用规则

- **成功判断标准**：`code` 字段是判断操作是否成功的唯一标准。当 `code` 不是 `"200"` 时，无论 `errorInfo` 是否为 null、`data` 是否有内容，都视为操作失败
- 查询类失败：可调整条件后重试
- 字段名错误：重新 describe，按 label 搜索正确的 apiKey，禁止继续猜测
- 权限不足：告知用户，停止操作
- 写操作失败：告知原因，停止操作，不重试，不绕过

各操作的特殊异常见各章节。

---

## 单个接口说明

### 查询记录

#### 使用的命令

```
neocrm data:query  -q "<XOQL>"
neocrm data:get    -o <entity> -i <id>
```

#### 业务流程

**Step 1. describe** → 获取字段定义

**Step 2. 构建映射表** → SELECT 字段 + WHERE 条件字段

**Step 3. 构造 XOQL**

```
SELECT <apiKey列表> FROM <entity> WHERE <条件> ORDER BY id DESC LIMIT <偏移>,<数量>
```

**Step 4. 执行查询**

**Step 5. 解析并展示** → reference/owner 字段通过 `data:get` 获取名称

**Step 6. 分页判断** → 如返回满 100 条，询问用户是否继续

#### 特殊异常

- 找到多条记录：展示列表，让用户确认目标
- 找到零条记录：告知用户，引导确认查询条件

---

### 创建记录

#### 使用的命令

```
neocrm data:create  -o <entity> -n <name>
                      [--dim-depart <id>]
                      [--entity-type <id>]
                      [--user-id <id>]
                      --object-id <id>
                      -v '<json>'
```

> **`--object-id` 是必填参数**：虽然 `-o` 指定了实体 API Key，但 `data:create` 仍需要 `--object-id`（实体的数字 ID）。通过 `neocrm metadata:objects` 获取目标实体的 `objectId`。

#### 业务流程

**Step 1. describe** → 获取必填字段和字段类型

**Step 2. 构建映射表** → WRITE 字段（仅用户要修改的字段），记录 apiKey / type / selectitem

**Step 2.5 类型校验** → 根据字段类型转换值格式（必须执行）：

| 字段类型 | 值格式要求 | 错误示例 | 正确示例 |
|---------|-----------|---------|---------|
| `date` | 毫秒时间戳（Long） | `"2026-04-15"` | `1776211200000` |
| `datetime` | 毫秒时间戳（Long） | `"2026-04-15T10:30:00"` | `1776215400000` |
| `picklist` | `selectitem.value` | `"互联网"`（label） | `"1"`（value） |
| `reference` / `owner` | 字符串 ID | `921913753305571`（数字） | `"921913753305571"` |

**Step 3. 获取系统参数**

| 参数 | 获取方式 |
|------|---------|
| `--dim-depart` | `neocrm auth:whoami` → departmentId |
| `--entity-type` | `neocrm metadata:busitype -o <entity>` → 用户选择 |
| `--user-id` | `neocrm auth:whoami` → id |
| `--object-id` | `neocrm metadata:objects` → 目标实体的 objectId |

**Step 4. 确认必填字段** → 映射表中 `required: true` 且 `createable: true` 的字段，若用户未提供，逐一询问

**Step 5. 展示创建数据** → 完整字段值 + 业务类型，用户确认

**Step 6. 执行创建**

#### 特殊异常

- 业务类型不确定：展示 `metadata:busitype` 结果，让用户选择
- 必要信息缺失：列出缺失字段，逐一询问
- `字段数据类型不匹配`：检查 Step 2.5 类型校验，确认 `date`/`datetime` 传的是毫秒时间戳，`picklist` 传的是 value 而非 label

#### 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `Missing required flag object-id` | 未传 `--object-id` | 从 `metadata:objects` 获取 `objectId` 并传入 |
| `字段数据类型不匹配:xxx` | `date`/`datetime` 传了字符串 | 改为毫秒时间戳（`new Date("2026-04-15").getTime()`） |
| `--values 参数必须为合法的 JSON 格式` | JSON 含中文且编码错误 | 用 Node.js 脚本中转，避免 PowerShell 编码问题 |

---

### 编辑记录

#### 使用的命令

```
neocrm data:update  -o <entity> -i <id> -v '<json>'
```

`-v` 的 JSON 必须包装在 `data` 字段下（见总纲命令速查）。

#### 业务流程

**Step 1. describe**

**Step 2. 构建映射表** → WRITE 字段（仅用户要修改的字段）

**Step 3. 查询当前值** → `data:query` + `data:get` 获取现有数据

**Step 4. 展示修改对比** → 修改前值 → 修改后值，用户确认

**Step 5. 执行更新**

#### 特殊异常

- 目标记录不存在：引导用户确认名称或 ID
- 匹配多条记录：展示列表，让用户确认

---

### 转移负责人

#### 使用的命令

```
neocrm data:update  -o <entity> -i <id> -v '<json>'
```

转移负责人本质是 `data:update` 修改 `ownerId` 字段。

#### 业务流程

**Step 1. describe**

**Step 2. 确认目标记录** → `data:query` + `data:get` 展示当前负责人名称

**Step 3. 确认新负责人** → `data:query` user 实体查找，或用户直接指定 ID

**Step 4. 展示转移信息** → 当前负责人 → 新负责人，用户确认

**Step 5. 执行更新（写入 ownerId）**

#### 特殊异常

- 目标用户不存在：引导用户确认姓名或工号
- 权限不足：告知用户

---

### 锁定记录

#### 使用的命令

```
neocrm data:lock  -o <entity> -r <id>
```

注意：lock 用 `-r` 传记录 ID，不是 `-i`。

#### 业务流程

**Step 1. 确认目标记录** → `data:query` 找到记录，展示关键信息

**Step 2. 说明锁定效果** → 锁定后记录无法被编辑，用户确认

**Step 3. 执行锁定**

#### 特殊异常

- 记录已锁定：告知用户，无需重复操作

---

### 解锁记录

#### 使用的命令

```
neocrm data:unlock  -o <entity> -r <id>
```

注意：unlock 用 `-r` 传记录 ID，不是 `-i`。

#### 业务流程

**Step 1. 确认目标记录** → `data:query` 找到记录

**Step 2. 说明解锁效果** → 解锁后记录可重新编辑，用户确认

**Step 3. 执行解锁**

#### 特殊异常

- 记录未锁定：告知用户，无需操作

---

## 参考信息

### metadata:objects

用途：当不确定实体的 `-o` 参数值时，先用此命令查，返回的 `apiKey` 即为 `-o` 参数值，`objectId` 创建时可能用到。

完整字段说明和验证流程见 [nc-base/references/metadata-objects.md](../nc-base/references/metadata-objects.md)。

### metadata:describe

字段定义（含 apiKey、label、type、referTo、selectitem 等）的完整结构说明和验证流程见 [nc-base/references/metadata-describe.md](../nc-base/references/metadata-describe.md)。

### metadata:busitype 返回结构

返回该实体的所有业务类型，每个含：

| 属性 | 用途 |
|------|------|
| `id` | 即 `--entity-type` 参数的值，创建时填这个 |
| `label` | 中文名 |
| `active` | 是否启用 |
| `custom` | 是否租户自定义业务类型 |

每个实体的 busitype 列表完全独立，entityType 不能跨实体复用。

> **业务类型**：必须通过 `neocrm metadata:busitype -o <entity>` 获取枚举值（禁止 data:query 查询）。

### XOQL 语法要点（通用约束）

```
SELECT <字段> FROM <实体Key> WHERE <条件> ORDER BY id DESC LIMIT 偏移,数量
```

- **不支持** `SELECT *`，必须逐字段列出
- **不支持** 中间模糊匹配 `'%关键词%'`，只支持后置 `'关键词%'`
- **每次最多 100 条**（满 100 条时询问是否继续翻页）
- **字段类型详情**（含 date/datetime 格式、picklist WHERE 写法等）见 metadata-describe 参考文档

全模糊搜索替代方案：
1. 先 `LIMIT 0, 100` 取出，代码端过滤
2. 多后置通配符：`name LIKE '张%' OR name LIKE '李%'`

### 用户与部门查询

**获取当前登录用户信息**：
```powershell
neocrm auth:whoami
```
返回字段：id（用于 `--user-id`）、departmentId（用于 `--dim-depart`）、name、email、phone、tenantId、tenantName

**查询用户（按 ID，用于查看详情或转移负责人）**：
```
neocrm data:query -q "select name, email, mobile, departmentId from user where id='<userId>' limit 1"
```

**查询用户（按名称，用于不确定 ID 的场景）**：
```
neocrm data:query -q "select id, name, email, mobile, departmentId from user where name='张三' limit 1"
```

**查询部门（按 ID 获取部门名称，用于展示）**：
```
neocrm data:query -q "select name, parentId from department where id='<departmentId>' limit 1"
```
