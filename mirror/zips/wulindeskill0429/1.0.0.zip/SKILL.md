---
name: wulin-html-template
version: 1.3.0
author: wulin
description: |
  将文档内容一键转换为 BTN（贝泰妮集团）品牌风格的单文件 HTML 全屏幻灯片。
  内置品牌规范（Logo/配色/字体/组件），透明悬浮 UI 控件，支持键盘翻页、
  拖拽排序、全屏模式。适用于工作汇报、方案演示、会议材料等场景。
  触发词：生成HTML幻灯片、帮我做一个HTML演示文稿、用这个模板、BTN模板。
---

# 武林的 HTML 模板（v1.3.0）

将任意文档内容转换为 BTN（贝泰妮集团）品牌风格的单文件 HTML 演示文稿。

> **路径说明**：`{SKILL_DIR}` 为本 skill 所在目录的绝对占位符，运行时由 WorkBuddy 自动替换为实际安装路径。所有图片资源已内置在 `assets/images/` 目录下，**无需用户额外提供**。

## 📦 文件清单

| 路径 | 大小 | 用途 |
|------|------|------|
| `SKILL.md` | 7KB | 技能入口（本文件） |
| `references/part1-system-prompt.md` | 37KB | ★ 风格框架系统提示（CSS/组件/动画/JS） |
| `references/part2-user-prompt.md` | 5.5KB | ★ 文档转换规则与内容占位符 |
| `assets/images/标题页背景图.png` | 171K | 封面/致谢页全幅背景图 |
| `assets/images/正文背景图_去水印.png` | 59K | 正文页背景图（含顶栏+底栏+Logo区） |
| `assets/images/标题页、章节页、结束页logo参考图.png` | 46K | 白色透明版 Logo（封面/章节/目录/致谢用） |
| `assets/images/正文页logo参考图.png` | 113K | 蓝色版 Logo（正文页背景图已含，备用） |
| `assets/lean-ai-share.html` | 121KB | 金标准参考源码（31张完整幻灯片，供 AI 学习风格） |
| `brain/退货分拣标准调整.html` | 48KB | 示例输出产物（展示最终效果，路径使用 `{SKILL_DIR}` 占位符） |

## 🚀 快速开始（给使用者）

1. **提供文档内容**：把你的 Word/PDF/文本内容发给 AI
2. **说明需求**：「用武林 HTML 模板做一个幻灯片」或「生成 BTN 风格 HTML 演示文稿」
3. **等待生成**：AI 会自动读取本技能的风格框架和转换规则，输出完整 HTML 文件
4. **预览与调整**：浏览器打开即可预览，支持键盘翻页（←→）、F 全屏、⚙️ 排序编辑

**无需安装任何依赖，无需准备图片素材，开箱即用。**

## 品牌固定值（无需确认，直接使用）

| 内容 | 值 |
|------|-----|
| 公司简称 | BTN |
| 中文全称 | 贝泰妮集团（5字） |
| 英文名 | BOTANEE GROUP（2词） |
| 部门/活动标签 | 集团物流部（封面 .org-tag） |
| 全局主色 | #0154BC（--blue） |
| 辅色 | #90D0FD（--blue-light） |
| 竖条色 | #00B0F0（--blue-bar） |

Logo 规范（按页面类型区分）：
- **标题页**：白色透明版 Logo
  - 图片：`{SKILL_DIR}/assets/images/标题页、章节页、结束页logo参考图.png`
  - 定位：底部水平居中（absolute, bottom: 40px, left: 50%, transform: translateX(-50%)）
  - 高度：60px
- **章节页**：白色透明版 Logo + ┐ 形白色边框
  - 图片：`{SKILL_DIR}/assets/images/标题页、章节页、结束页logo参考图.png`
  - 布局：Logo 放在左侧 .chap-logo-wrapper 容器内，容器带 ┐ 形边框（上边+左边+下边）
  - 容器尺寸：180px × 130px
- **结束页**：白色透明版 Logo
  - 图片：`{SKILL_DIR}/assets/images/标题页、章节页、结束页logo参考图.png`
  - 定位：右下角（absolute, bottom: 28px, right: 36px）
  - 高度：52px
- **正文页**：蓝色版 Logo
  - 图片：`{SKILL_DIR}/assets/images/正文页logo参考图.png`
  - 定位：左上角（absolute, top: 16px, left: 20px）
  - 高度：40px
- **目录页**：白色透明版 Logo（与章节页同款）
  - 图片：`{SKILL_DIR}/assets/images/标题页、章节页、结束页logo参考图.png`
  - 定位：左侧面板内左上角（absolute, top: 28px, left: 32px）
  - 高度：36px; opacity: 0.92

## 视觉特征（对齐 PPT 模板）

- 封面：全幅背景图（标题页背景图.png，cover 填充居中），白色文字，白色透明 Logo 底部居中
- 章节页：纯蓝 #0154BC 实心背景，左右横向布局（左侧 Logo + ┐ 形边框，右侧章节标题 + 装饰线 + 要点）
- 结束页：蓝色渐变背景（#0154BC → #0170e0），白色文字，白色透明 Logo 右下角
- 正文页：去水印背景图（`正文背景图_去水印.png`，cover 填充居中），背景图自带顶栏蓝条、底栏蓝条、左上角 BTN Logo 区域；内容区通过 padding 安全区域避让这些保留元素
- 目录页：左右分栏布局，左侧品牌蓝渐变面板铺满（含 Logo、标题"目录 CONTENTS"、副标题），右侧浅蓝白渐变面板铺满（含章节目录列表）；使用 `align-items: stretch; justify-content: stretch;` 确保两侧完全填满幻灯片

## 适用场景

- 用户提供了文档并要求生成 HTML 演示文稿
- 用户引用「武林的 HTML 模板」「这个风格」「BTN 模板」等关键词
- 用户说「生成幻灯片」「做一个演示页面」「转成 HTML」

## 工作流程

### 第一步：读取参考文件

按顺序读取以下两个参考文件，将完整内容加载到上下文中：

1. `references/part1-system-prompt.md` — 风格框架系统提示（CSS变量、双Logo规范、竖条装饰、14种组件、动画、JS逻辑）
2. `references/part2-user-prompt.md` — 文档喂入用户提示（转换规则和内容占位符）

### 第二步：组装完整提示词并发送给 AI

将两部分内容组合，末尾附上用户提供的文档内容，作为用户消息发送给 AI（无需系统提示）。

### 第三步：输出与展示

- 将 AI 返回的完整 HTML 保存到 `brain/` 目录
- 使用 `preview_url` 工具直接展示效果
- 告知用户保存路径

> **注**：生成的 HTML 中所有图片路径使用 `{SKILL_DIR}` 占位符，WorkBuddy 运行时会自动替换为实际安装路径。`brain/` 目录下的示例文件同样使用此机制。

## 模板参考文件

| 文件 | 内容 |
|------|------|
| `references/part1-system-prompt.md` | 完整风格框架 System Prompt |
| `references/part2-user-prompt.md` | 文档喂入提示词模板 |
| `assets/lean-ai-share.html` | 原始模板参考（31张幻灯片完整源码） |

## 输出质量要求

- 生成完整可运行的单文件 HTML
- Logo 按页面类型使用对应版本（白色透明版 / 蓝色版）
- 正文页使用去水印背景图（`正文背景图_去水印.png`），**不添加**额外的 .side-bar 竖条、.top-bar 顶栏、.logo-area（背景图已包含这些装饰）
- 正文页内容区必须通过 padding 避让背景图保留区域（顶栏+Logo区、底栏），确保文字不与装饰重叠

### UI 控件规范（透明悬浮风格）
- **右下角导航栏**：透明悬浮设计，无背景框/无边框/无阴影，仅显示页码计数器 + 全屏按钮⛶；翻页箭头和圆点隐藏（功能由键盘←→提供）；hover 时微亮
- **右上角设置按钮⚙️**：透明微模糊小胶囊样式（rgba(255,255,255,0.15)+blur(8px)），与全屏按钮统一视觉语言；全屏时自动隐藏（opacity:0+pointer-events:none）
- **排序面板**：居中毛玻璃弹窗，支持拖拽排序/单页删除/撤回删除/重置顺序/localStorage持久化
- **全屏模式**：F/f 进入/退出，ESC 退出；导航栏切换为 .nav-minimal 同样透明风格

- 内容页带 .section-label 章节标签（如 "Chapter 01"）
- 幻灯片数量建议 20~35 张

## ⚠️ 硬性要求：布局安全检查

**所有页面必须确保图案（背景图、装饰元素）和文字（标题、副标题、正文）不重叠，不影响观感。**

常见重叠场景及解决方案：

| 场景 | 问题 | 解决方案 |
|------|------|----------|
| 封面页 Logo 与标题文字重叠 | Logo 在文字区域内 | 使用 flex column 布局，Logo 放在 .slide-inner 底部，padding-bottom 预留空间 |
| 章节页 Logo 边框与内容重叠 | Logo 边框遮挡文字 | 确保 .slide-content padding-left ≥ 100px，Logo 与文字区域保持间距 |
| 正文页内容与背景图装饰重叠 | 文字覆盖到背景图的顶栏/Logo/底栏区域 | 确保 .slide-content padding-top ≥ calc(7% + 24px)，padding-left ≥ max(8%, 72px)，padding-bottom ≥ 80px |

**如果遇到可能导致重叠的情况，必须：**
1. 先提出问题，描述重叠风险
2. 提供 2-3 种调整方案供用户选择
3. 获得用户确认后再执行

---

## 📋 SkillHub 发布信息

- **版本**：v1.3.0
- **品牌**：BTN（贝泰妮集团）— 品牌值已锁定，不支持自定义替换
- **兼容性**：Windows / macOS / Linux（图片文件名含中文，建议 Windows 环境使用）
- **依赖**：无外部依赖，所有资源内置（4张图片 + 1份参考源码）
- **总大小**：约 632KB（远小于 SkillHub 10MB 上限）
