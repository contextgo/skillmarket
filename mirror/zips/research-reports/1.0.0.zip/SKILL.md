---
name: research-reports
description: '查询个股或行业的机构研报观点、评级统计、调研记录、财报摘要，以及个股和市场异动的深度归因分析。当用户想了解券商观点、机构调研情况、股价异动原因或A股重要事件时触发。Use when: "券商对XX股票怎么看", "XX股票被机构调研了吗", "XX今天为什么大涨". Calls tools: guessStockCode, stkResearch, researchRatingStats, stockInstResearchStats, queryStkFinReportSummary, stkEventAnalysis, stkPriceFluctReason, aShareMarketEvents, aSharePriceFluctInfo.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 研究与研报

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

聚合机构研究视角，覆盖：
- **个股研报观点**：券商分析师对特定股票的最新研究观点
- **研报评级统计**：买入/增持/中性/减持评级分布及目标价
- **机构调研统计**：上市公司近期被机构调研情况
- **财报摘要**：上市公司财报关键数据与摘要
- **个股大事解读**：影响股价的重要事件深度解读
- **个股异动归因**：近期股价异常波动的原因分析
- **A股市场事件**：宏观、行业、公司层面的重要事件汇总

## 触发场景

- "券商对 XX 股票怎么看？目标价是多少？"
- "XX 股票最近有没有被机构调研？"
- "XX 公司最近发布了什么重要公告？"
- "XX 股票今天为什么大涨/大跌？"
- "最近一周 A 股有哪些重要事件？"

## 执行步骤

### 场景 A：个股研报综合查询（并行调用）

```json
调用工具: guessStockCode
参数: { "query": "<股票名称或代码>" }
```

解析出代码后并行调用：

```json
调用工具: stkResearch
参数: {
  "query": "<股票代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}

调用工具: researchRatingStats
参数: {
  "query": "<股票代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}

调用工具: stockInstResearchStats
参数: {
  "query": "<股票代码或名称>",
  "dateRange": "近90天",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}
```

### 场景 B：财报摘要查询

```json
调用工具: queryStkFinReportSummary
参数: {
  "query": "<股票名称或相关自然语言描述>",
  "maxCnt": "3",
  "relevance": "0.66"
}
```

### 场景 C：个股事件与异动归因（并行调用）

```json
调用工具: stkEventAnalysis
参数: {
  "query": "<股票名称或代码，或事件描述>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "3"
}

调用工具: stkPriceFluctReason
参数: {
  "query": "<股票代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "3"
}
```

### 场景 D：A 股市场重要事件

```json
调用工具: aShareMarketEvents
参数: {
  "query": "<股票/行业/板块/事件名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

### 场景 E：A 股异动消息汇总

```json
调用工具: aSharePriceFluctInfo
参数: {
  "query": "<股票/ETF/板块代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

## 整合输出建议

1. **评级分布** —— 来自 `researchRatingStats`
2. **最新研报观点** —— 来自 `stkResearch`
3. **机构调研情况** —— 来自 `stockInstResearchStats`
4. **近期重要事件** —— 来自 `stkEventAnalysis`
5. **异动原因解读** —— 来自 `stkPriceFluctReason`

## 注意事项

- 研报存在滞后性，发布日期越近参考价值越高。
- `aShareMarketEvents` 的 `query` 为空时返回全市场重要事件。
