---
name: flight-price-lookup
description: >
  查询国内外航班机票价格，支持按日期范围比价、筛选低价时段。
  当用户提到"查机票"、"机票价格"、"航班查询"、"什么时候便宜"、"低价机票"、
  "机票比价"或需要查询某航线未来一段时间的价格走势时触发。
  本 skill 使用 browser-action 自动化操作携程网页版，滚动浏览多日期的价格日历，
  汇总低于用户指定阈值（如 500 元）的低价日期并输出结构化表格。
---

# 机票价格查询 Skill

通过自动化浏览器查询携程机票价格日历，找出指定航线在用户给定时间段内价格低于阈值的日期。

## 适用场景

- 用户想查某航线（如北京到香港）未来一段时间（如三个月）的机票价格
- 用户想知道哪些日期机票最便宜
- 用户指定了价格上限（如低于500元），想找出符合条件的日期

## 前置依赖

- `catdesk-browser` skill 已内置可用，无需额外安装
- 使用路径：`~/.catpaw/bin/catdesk browser-action`

## 工作流程

### 1. 确认查询参数

从用户消息中提取以下信息，缺失时主动询问：

| 参数 | 说明 | 示例 |
|------|------|------|
| `departure` | 出发城市，使用三字码（如 BJS）或城市名 | 北京(BJS) |
| `arrival` | 到达城市，使用三字码（如 HKG）或城市名 | 中国香港(HKG) |
| `start_date` | 查询起始日期 | 2026-05-02（今天） |
| `end_date` | 查询结束日期 | 2026-08-02（约三个月） |
| `threshold` | 价格阈值（元），低于此值的日期才记录 | 500 |

**城市代码速查：**
- 北京：BJS
- 上海：SHA 或 PVG
- 中国香港：HKG
- 中国台北：TPE
- 广州：CAN
- 深圳：SZX
- 成都：CTU
- 杭州：HGH
- 其他城市可先用城市名搜索，查看 URL 中的代码

### 2. 构造携程查询 URL

携程国内/国际机票列表页 URL 格式：

```
https://flights.ctrip.com/online/list/oneway-{departure}-{arrival}?depdate={date}&cabin=Y_S_C_F
```

其中：
- `{departure}` / `{arrival}`：城市三字码（大写）
- `{date}`：日期格式 `YYYY-MM-DD`
- `cabin=Y_S_C_F`：经济舱+超经舱+商务舱+头等舱（获取最低价）

### 3. 查询多日价格日历

携程页面会在顶部横条显示前后数日的最低价格。通过切换不同日期，可以滚动采集整个时间段的价格。

**推荐采样策略：**
- 第一天：`start_date`
- 之后每隔 5-7 天采样一个日期，直到 `end_date`
- 如果某段出现低价，可增加该段附近的采样密度

**具体操作：**

```bash
# 1. 导航到目标日期的携程查询页
~/.catpaw/bin/catdesk browser-action '{"action":"navigate","url":"https://flights.ctrip.com/online/list/oneway-BJS-HKG?depdate=2026-06-15&cabin=Y_S_C_F"}'

# 2. 等待页面加载并获取价格日历
sleep 4
~/.catpaw/bin/catdesk browser-action '{"action":"snapshot","interactive":true}'
```

### 4. 从 Snapshot 中提取价格信息

Snapshot 的 `listitem` 中会显示类似：`06-12周五¥440`、`06-15周一¥416低`

从中解析出日期和价格：
- 日期格式：`MM-DD`（需补上年份）
- 价格：`¥` 后面的数字
- "低" 标记表示该周附近最低

**提取规则：**
- 只记录价格 <= threshold 的日期
- 如果价格为数字但含有额外文字（如"起"、含税等），提取纯数字部分
- 注意区分不同航司的价格，取显示的最低价即可

### 5. 汇总并输出结果

将所有采样日期中低于阈值的日期汇总为表格：

```
| 日期 | 星期 | 最低价格 | 备注 |
|------|------|----------|------|
| 2026-06-08 | 周一 | ¥342 | 最低价 |
| 2026-06-10 | 周三 | ¥421 | 低价 |
```

**输出建议：**
- 按价格从低到高排序
- 标注最低价和次低价
- 如果低价集中在某个月份，给出出行建议
- 提醒用户价格为携程显示的最低价不含税费，实际价格以预订页为准

## 完整示例

用户说："帮我查下北京到香港接下来三个月 500 块以下的机票"

执行流程：

```bash
# 采样 5月初
~/.catpaw/bin/catdesk browser-action '{"action":"navigate","url":"https://flights.ctrip.com/online/list/oneway-BJS-HKG?depdate=2026-05-10&cabin=Y_S_C_F"}'
sleep 4
~/.catpaw/bin/catdesk browser-action '{"action":"snapshot","interactive":true}'

# 记录低于500的日期

# 采样 5月中旬
~/.catpaw/bin/catdesk browser-action '{"action":"navigate","url":"https://flights.ctrip.com/online/list/oneway-BJS-HKG?depdate=2026-05-20&cabin=Y_S_C_F"}'
sleep 4
~/.catpaw/bin/catdesk browser-action '{"action":"snapshot","interactive":true}'

# 记录低于500的日期

# 继续采样6月、7月、8月...
# ...

# 最后汇总输出表格
```

## 注意事项

1. **Browser session 是持久的**：同一个会话中多个 `navigate` 会用同一个 tab，无需关闭
2. **Snapshot refs 有效期**：每次 `navigate` 后需重新 `snapshot` 获取新 refs
3. **价格是实时的**：携程页面价格可能变化，查询结果仅代表查询时刻的价格
4. **价格不含税费**：显示价格通常为机票票面价，不含机场建设费、燃油附加费等
5. **低价标记"低"**：携程会在价格条中标注该周附近最低价的日期，可作为快速参考
6. **异常处理**：
   - 如果页面加载失败（如验证码），尝试换一个日期再试
   - 如果某日期价格显示"售罄"或"--"，记录为无票，继续查询其他日期
