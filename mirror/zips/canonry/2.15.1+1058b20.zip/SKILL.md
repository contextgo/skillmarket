---
name: Canonry Setup
description: "Agent-first AEO operating platform."
metadata:
  synthetic_archive: true
  source: public-metadata-placeholder
---

# Canonry Setup

This archive was synthesized from public SkillHub / ClawHub metadata because the upstream zip package was unavailable during mirroring.

## Metadata

- slug: `canonry`
- version: `2.15.1+1058b20`
- owner: `arberx`
- homepage: https://api.skillhub.cn/arberx/canonry
- category: ``
- downloads: `596`
- stars: `1`
- installs: `0`

## Description

Agent-first AEO operating platform.

## Note

If the upstream package becomes available later, you can replace this synthesized archive with the original zip.
