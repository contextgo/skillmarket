Synthesized from public metadata; upstream archive unavailable. Homepage: https://api.skillhub.cn/arberx/canonry
