# 命令参考

## 环境初始化

```bash
uv venv
.\.venv\Scripts\Activate.ps1
copy .env.example .env
```

## 安装检查与引导

```bash
uv run python scripts/check_windows_install.py --json
uv run python scripts/bootstrap_admin.py --json
uv run python scripts/configure_default_models.py --json
```

`configure_default_models.py` 可选参数：

```bash
uv run python scripts/configure_default_models.py ^
  --embedding-model bge-m3 ^
  --chat-model qwen2-7b-instruct ^
  --rerank-model bge-reranker-v2-m3 ^
  --api-base http://host.docker.internal:8080/v1 ^
  --json
```

## 数据集管理 (`datasets.py`)

```bash
# 列出所有知识库
uv run python scripts/datasets.py list --json

# 查看单个知识库详情（使用默认或指定 ID）
uv run python scripts/datasets.py info DATASET_ID --json

# 创建知识库
uv run python scripts/datasets.py create "名称" --description "描述" --json

# 删除知识库（需用户确认）
uv run python scripts/datasets.py delete --ids id1,id2 --json
```

## 文档上传与管理 (`upload.py`)

```bash
# 上传文件到知识库
uv run python scripts/upload.py DATASET_ID /path/to/file.pdf --json

# 列出知识库中的文档
uv run python scripts/upload.py list DATASET_ID --json

# 删除文档
uv run python scripts/upload.py delete DATASET_ID --ids doc1,doc2 --json
```

## 文档解析

```bash
# 发起解析
uv run python scripts/parse.py DATASET_ID DOC_ID1 [DOC_ID2 ...] --json

# 查看解析状态
uv run python scripts/parse_status.py DATASET_ID --json

# 停止解析并查看当前状态快照
uv run python scripts/stop_parse_documents.py DATASET_ID DOC_ID1 [DOC_ID2 ...] --json

# 按文档 ID 筛选状态
uv run python scripts/parse_status.py DATASET_ID --doc-ids DOC_ID1,DOC_ID2 --json
```

## 更新操作

```bash
# 更新知识库
uv run python scripts/update_dataset.py DATASET_ID --name "新名称" --description "新描述" --json

# 更新 parser_config（chunk_token_num 等）
uv run python scripts/update_dataset.py DATASET_ID --parser-config "@_parser_config.json" --json

# 更新文档
uv run python scripts/update_document.py DATASET_ID DOC_ID --name "新文档名" --json

# 启用/禁用文档
uv run python scripts/update_document.py DATASET_ID DOC_ID --enabled 1 --json
```

## 检索

```bash
# 基础检索
uv run python scripts/search.py "查询文本" --json
uv run python scripts/search.py "查询文本" DATASET_ID --json

# 指定多个数据集和文档
uv run python scripts/search.py --dataset-ids ID1,ID2 --doc-ids DOC1,DOC2 "查询文本" --json

# 检索测试模式
uv run python scripts/search.py --retrieval-test --kb-id DATASET_ID "查询文本" --json

# 高级参数
uv run python scripts/search.py "查询文本" --top-k 10 --threshold 0.3 --keyword --json
```

## 模型与对话

```bash
# 列出可用模型
uv run python scripts/list_models.py --json

# 创建对话（绑定知识库与模型）
uv run python scripts/create_chat.py "知识库问答" --dataset-ids DATASET_ID --llm-id qwen2-7b-instruct --rerank-id bge-reranker-v2-m3 --json
```
