# Windows 开箱即用流程

## 0. 初始化 uv 环境

```bash
uv venv
.\.venv\Scripts\Activate.ps1
```

## 1. 安装检查

确保 Docker Desktop 已启动，并且 RAGFlow 容器正在运行。

```bash
uv run python scripts/check_windows_install.py
```

若检查失败，请先处理容器或端口问题，再继续。

## 2. 初始化管理员与 API Key

脚本会自动：

- 使用容器内 `crypt` 加密密码
- 注册管理员（若已存在会自动继续）
- 登录并生成 API Token
- 将 `RAGFLOW_API_URL` / `RAGFLOW_API_KEY` 写入 `.env`

```bash
uv run python scripts/bootstrap_admin.py --json
```

## 3. 配置默认模型

该脚本会添加并设置默认模型（Embedding/Chat/Rerank）：

```bash
uv run python scripts/configure_default_models.py --json
```

如需指定模型名或本地模型网关地址：

```bash
uv run python scripts/configure_default_models.py ^
  --embedding-model bge-m3 ^
  --chat-model qwen2-7b-instruct ^
  --rerank-model bge-reranker-v2-m3 ^
  --api-base http://host.docker.internal:8080/v1 ^
  --json
```

## 4. 创建知识库与上传解析

```bash
uv run python scripts/datasets.py create "新手知识库" --json
uv run python scripts/upload.py DATASET_ID C:\path\to\file.pdf --json
uv run python scripts/parse.py DATASET_ID DOC_ID --json
uv run python scripts/parse_status.py DATASET_ID --json
```

## 5. 创建对话并检索

创建对话（可绑定知识库与模型）：

```bash
uv run python scripts/create_chat.py "新手问答对话" ^
  --dataset-ids DATASET_ID ^
  --llm-id qwen2-7b-instruct ^
  --rerank-id bge-reranker-v2-m3 ^
  --json
```

检索测试：

```bash
uv run python scripts/search.py "总结知识库重点" DATASET_ID --json
```
