# 异常问题处理指南 (Troubleshooting Guide)

本指南旨在记录 RAGFlow 技能包在实际运行过程中可能遇到的异常问题、排查思路及解决办法。我们将持续更新此文档以增强系统的健壮性。

---

## 1. 嵌入报错：`input (X tokens) is too large to process`

### 问题背景
在上传文件并触发解析后，如果文档分块（chunk）过大，超过了 Embedding API 服务的物理批处理限制（例如 vLLM/TGI 默认通常为 512 tokens），解析任务会失败。

**错误信息示例：**
```text
[ERROR]Generate embedding error:Error code: 500 - {'error': {
    'code': 500, 
    'message': 'input (549 tokens) is too large to process. increase the physical batch size (current batch size: 512)', 
    'type': 'server_error'
}}
```

### 排查步骤
1. **检查知识库配置**：查看当前知识库的 `chunk_token_num`（分块 token 数上限）。
   ```bash
   uv run python scripts/datasets.py info <dataset_id> --json
   ```
2. **确认 API 限制**：根据报错信息确认 Embedding 服务的限制（如上例中的 512）。

### 解决办法
将知识库的 `chunk_token_num` 调小。建议设为 Embedding API 物理限制的 **50%~60%**。

**操作步骤：**
1. 创建或编辑 `_parser_config.json` 文件：
   ```json
   {"chunk_token_num": 256}
   ```
2. 使用 `update_dataset.py` 更新配置：
   ```bash
   uv run python scripts/update_dataset.py <dataset_id> --parser-config "@_parser_config.json" --json
   ```
3. **关键点**：修改后需**删除旧文档并重新上传解析**，新配置才会对文件生效。

---

## 如何贡献
如果您在使用过程中遇到了新的异常问题并找到了解决方法，欢迎按照以下格式添加到本指南中：
1. **问题描述/背景**（包含具体的错误日志）
2. **排查思路**
3. **解决方案**（优先提供脚本操作命令）
