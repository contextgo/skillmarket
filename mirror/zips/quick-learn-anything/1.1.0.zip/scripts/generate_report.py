#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速认知新事物 - Word报告生成器 v1.1.0
根据八步认知框架生成结构化的Word文档

使用方法:
    python generate_report.py <json文件> [输出路径]
    python generate_report.py --demo [输出路径]

示例:
    python generate_report.py data.json 输出.docx
    python generate_report.py --demo F35认知报告.docx
"""

import sys
import json
import argparse
from datetime import datetime
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.style import WD_STYLE_TYPE
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
except ImportError:
    print("❌ 请先安装依赖: pip install python-docx")
    print("   运行: pip install python-docx")
    sys.exit(1)


def set_cell_border(cell, **kwargs):
    """设置单元格边框"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = tcPr.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcPr.append(element)
            element.set(qn('w:val'), 'single')
            element.set(qn('w:sz'), str(edge_data.get('sz', 4)))
            element.set(qn('w:space'), '0')
            element.set(qn('w:color'), edge_data.get('color', '000000'))


def set_run_font(run, font_name='Microsoft YaHei', font_size=11, bold=False, color=None):
    """设置字体样式"""
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    run.font.size = Pt(font_size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def create_cover(doc, title, subtitle, date_str, version="v1.1.0"):
    """创建封面"""
    # 空行
    for _ in range(4):
        doc.add_paragraph()
    
    # 版本标识
    version_para = doc.add_paragraph()
    version_run = version_para.add_run(f"快速认知新事物 {version}")
    set_run_font(version_run, font_size=10, color=(128, 128, 128))
    version_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    for _ in range(3):
        doc.add_paragraph()
    
    # 主标题
    title_para = doc.add_paragraph()
    title_run = title_para.add_run(title)
    set_run_font(title_run, font_size=32, bold=True, color=(0, 51, 102))
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    doc.add_paragraph()
    
    # 副标题
    subtitle_para = doc.add_paragraph()
    subtitle_run = subtitle_para.add_run(subtitle)
    set_run_font(subtitle_run, font_size=16, color=(102, 102, 102))
    subtitle_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    for _ in range(6):
        doc.add_paragraph()
    
    # 分隔线
    line_para = doc.add_paragraph()
    line_para.add_run("━" * 30)
    line_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 日期
    date_para = doc.add_paragraph()
    date_run = date_para.add_run(date_str)
    set_run_font(date_run, font_size=12, color=(128, 128, 128))
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    doc.add_paragraph()
    
    # 技能标识
    skill_para = doc.add_paragraph()
    skill_run = skill_para.add_run("由 quick-learn-anything 技能生成")
    set_run_font(skill_run, font_size=9, color=(180, 180, 180))
    skill_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 分页
    doc.add_page_break()


def add_heading_custom(doc, text, level=1):
    """添加自定义标题"""
    heading = doc.add_heading(level=level)
    run = heading.add_run(text)
    
    if level == 1:
        set_run_font(run, font_size=20, bold=True, color=(0, 51, 102))
        # 添加底部边框效果
        heading.paragraph_format.space_after = Pt(12)
    elif level == 2:
        set_run_font(run, font_size=16, bold=True, color=(0, 102, 153))
        heading.paragraph_format.space_before = Pt(12)
        heading.paragraph_format.space_after = Pt(8)
    else:
        set_run_font(run, font_size=13, bold=True, color=(51, 51, 51))
        heading.paragraph_format.space_before = Pt(8)
        heading.paragraph_format.space_after = Pt(4)
    
    return heading


def add_info_box(doc, title, content, box_type="info"):
    """添加信息框"""
    colors = {
        "info": (0, 102, 204),
        "analogy": (0, 153, 76),
        "warning": (204, 102, 0),
        "tip": (102, 0, 204)
    }
    color = colors.get(box_type, (0, 102, 204))
    
    # 空行
    doc.add_paragraph()
    
    # 标题
    title_para = doc.add_paragraph()
    title_run = title_para.add_run(f"【{title}】")
    set_run_font(title_run, font_size=12, bold=True, color=color)
    
    # 内容
    if isinstance(content, list):
        for item in content:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(item), font_size=11)
            para.paragraph_format.left_indent = Inches(0.25)
    else:
        content_para = doc.add_paragraph()
        set_run_font(content_para.add_run(content), font_size=11)
        content_para.paragraph_format.left_indent = Inches(0.25)
    
    # 空行
    doc.add_paragraph()


def add_step_section(doc, step_num, step_name, content, analogy, examples=None):
    """添加八步中的每一步"""
    # 步骤标题
    heading = add_heading_custom(doc, f"第{step_num}步：{step_name}", level=2)
    
    # 内容
    if content:
        para = doc.add_paragraph()
        set_run_font(para.add_run(content), font_size=11)
        para.paragraph_format.line_spacing = 1.5
        para.paragraph_format.space_after = Pt(8)
    
    # 类比（使用绿色信息框）
    if analogy:
        add_info_box(doc, "类比理解", analogy, box_type="analogy")
    
    # 示例
    if examples:
        add_info_box(doc, "示例", examples, box_type="tip")
    
    # 分隔
    doc.add_paragraph()


def create_analogy_table(doc, subject, user_background, analogies):
    """创建类比对照表"""
    add_heading_custom(doc, "类比对照表", level=2)
    
    # 说明文字
    para = doc.add_paragraph()
    set_run_font(para.add_run(f"基于【{user_background}】背景理解【{subject}】"), font_size=11)
    para.paragraph_format.space_after = Pt(12)
    
    # 创建表格
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 设置表格宽度
    table.autofit = False
    table.allow_autofit = False
    table.columns[0].width = Inches(2.0)
    table.columns[1].width = Inches(2.0)
    table.columns[2].width = Inches(2.5)
    
    # 表头
    hdr_cells = table.rows[0].cells
    headers = ['新事物要素', '类比物', '相似点']
    for i, header in enumerate(headers):
        hdr_cells[i].text = header
        for paragraph in hdr_cells[i].paragraphs:
            for run in paragraph.runs:
                set_run_font(run, font_size=11, bold=True, color=(255, 255, 255))
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        # 设置表头背景色
        shading_elm = OxmlElement('w:shd')
        shading_elm.set(qn('w:fill'), '4472C4')
        hdr_cells[i]._tc.get_or_add_tcPr().append(shading_elm)
    
    # 添加数据行
    for item in analogies:
        row_cells = table.add_row().cells
        row_cells[0].text = item.get('element', '')
        row_cells[1].text = item.get('analogy', '')
        row_cells[2].text = item.get('similarity', '')
        
        # 设置单元格样式
        for cell in row_cells:
            for paragraph in cell.paragraphs:
                set_run_font(paragraph.runs[0] if paragraph.runs else paragraph.add_run(), font_size=10)
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    
    doc.add_paragraph()


def create_scenario_table(doc, scenarios):
    """创建应用场景表格"""
    if not scenarios:
        return
    
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 表头
    hdr_cells = table.rows[0].cells
    headers = ['场景', '用途', '价值']
    for i, header in enumerate(headers):
        hdr_cells[i].text = header
        for paragraph in hdr_cells[i].paragraphs:
            for run in paragraph.runs:
                set_run_font(run, font_size=11, bold=True, color=(255, 255, 255))
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        shading_elm = OxmlElement('w:shd')
        shading_elm.set(qn('w:fill'), '70AD47')
        hdr_cells[i]._tc.get_or_add_tcPr().append(shading_elm)
    
    # 数据行
    for scenario in scenarios:
        row_cells = table.add_row().cells
        row_cells[0].text = scenario.get('scene', '')
        row_cells[1].text = scenario.get('usage', '')
        row_cells[2].text = scenario.get('value', '')


def create_summary_section(doc, key_points):
    """创建核心要点总结"""
    add_heading_custom(doc, "核心要点", level=2)
    
    for i, point in enumerate(key_points, 1):
        para = doc.add_paragraph(style='List Number')
        set_run_font(para.add_run(point), font_size=11)
        para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def generate_report(data, output_path):
    """生成完整的认知报告"""
    doc = Document()
    
    # 设置页面边距
    sections = doc.sections
    for section in sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = 'Microsoft YaHei'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    style.font.size = Pt(11)
    
    # 提取数据
    subject = data.get('subject', '未知事物')
    user_background = data.get('user_background', '通用背景')
    date_str = data.get('date', datetime.now().strftime('%Y年%m月%d日'))
    
    # 1. 封面
    create_cover(
        doc,
        f"《{subject}》",
        f"认知报告 —— 基于【{user_background}】视角的类比理解",
        date_str
    )
    
    # 2. 目录（可选）
    if data.get('include_toc', True):
        add_heading_custom(doc, "目录", level=1)
        toc_items = [
            "一、执行摘要",
            "二、九步认知详解",
            "三、类比对照表",
            "四、应用场景",
            "五、总结与行动"
        ]
        for item in toc_items:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(item), font_size=11)
        doc.add_page_break()
    
    # 3. 执行摘要
    add_heading_custom(doc, "一、执行摘要", level=1)
    
    # 一句话定义
    one_liner = data.get('one_liner', '')
    if one_liner:
        add_info_box(doc, "一句话定义", one_liner, box_type="info")
    
    # 核心类比
    core_analogy = data.get('core_analogy', '')
    if core_analogy:
        add_info_box(doc, "核心类比", core_analogy, box_type="analogy")
    
    # 关键要点
    key_points = data.get('key_points', [])
    if key_points:
        create_summary_section(doc, key_points)
    
    doc.add_page_break()
    
    # 4. 九步详细解析
    add_heading_custom(doc, "二、九步认知详解", level=1)
    doc.add_paragraph()
    
    steps = [
        ("一", "是什么 —— 一句话定义", 
         data.get('step1_content', ''), data.get('step1_analogy', ''),
         data.get('step1_examples', [])),
        ("二", "由什么构成 —— 拆解组成要素", 
         data.get('step2_content', ''), data.get('step2_analogy', ''),
         data.get('step2_examples', [])),
        ("三", "怎么运行 —— 工作机制", 
         data.get('step3_content', ''), data.get('step3_analogy', ''),
         data.get('step3_examples', [])),
        ("四", "怎么变化 —— 动态特性", 
         data.get('step4_content', ''), data.get('step4_analogy', ''),
         data.get('step4_examples', [])),
        ("五", "跟外界关系 —— 生态系统", 
         data.get('step5_content', ''), data.get('step5_analogy', ''),
         data.get('step5_examples', [])),
        ("六", "有什么用 —— 价值与意义", 
         data.get('step6_content', ''), data.get('step6_analogy', ''),
         data.get('step6_examples', [])),
        ("七", "怎么用 —— 操作方法", 
         data.get('step7_content', ''), data.get('step7_analogy', ''),
         data.get('step7_examples', [])),
        ("八", "有什么问题 —— 局限与风险", 
         data.get('step8_content', ''), data.get('step8_analogy', ''),
         data.get('step8_examples', [])),
        ("九", "历史文明价值 —— 历史脉络与文化意义", 
         data.get('step9_content', ''), data.get('step9_analogy', ''),
         data.get('step9_examples', [])),
    ]
    
    for step_num, step_name, content, analogy, examples in steps:
        if content or analogy:  # 只添加有内容的步骤
            add_step_section(doc, step_num, step_name, content, analogy, examples)
    
    doc.add_page_break()
    
    # 5. 类比对照表
    analogies = data.get('analogies', [])
    if analogies:
        create_analogy_table(doc, subject, user_background, analogies)
        doc.add_page_break()
    
    # 6. 应用场景
    add_heading_custom(doc, "三、应用场景", level=1)
    
    # 适用场景
    applicable = data.get('applicable_scenarios', [])
    scenarios_data = data.get('scenarios_table', [])
    
    if scenarios_data:
        add_heading_custom(doc, "适用场景", level=2)
        create_scenario_table(doc, scenarios_data)
        doc.add_paragraph()
    elif applicable:
        add_heading_custom(doc, "适用场景", level=2)
        for scenario in applicable:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(scenario), font_size=11)
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 不适用场景
    not_applicable = data.get('not_applicable_scenarios', [])
    if not_applicable:
        add_heading_custom(doc, "不适用场景", level=2)
        for scenario in not_applicable:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(scenario), font_size=11)
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 使用建议
    suggestions = data.get('suggestions', [])
    if suggestions:
        add_heading_custom(doc, "使用建议", level=2)
        for suggestion in suggestions:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(suggestion), font_size=11)
            para.paragraph_format.line_spacing = 1.5
    
    doc.add_page_break()
    
    # 7. 总结与行动
    add_heading_custom(doc, "四、总结与下一步", level=1)
    
    # 核心要点总结
    summary_points = data.get('summary_points', [])
    if summary_points:
        create_summary_section(doc, summary_points)
    
    # 下一步行动
    next_steps = data.get('next_steps', [])
    if next_steps:
        add_heading_custom(doc, "下一步行动", level=2)
        for i, step in enumerate(next_steps, 1):
            para = doc.add_paragraph(style='List Number')
            set_run_font(para.add_run(step), font_size=11)
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 延伸阅读
    resources = data.get('resources', [])
    if resources:
        add_heading_custom(doc, "延伸阅读", level=2)
        for resource in resources:
            para = doc.add_paragraph(style='List Bullet')
            set_run_font(para.add_run(resource), font_size=11)
            para.paragraph_format.line_spacing = 1.5
    
    # 页脚
    doc.add_paragraph()
    doc.add_paragraph()
    footer_para = doc.add_paragraph()
    footer_run = footer_para.add_run("━" * 40)
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    footer_text = doc.add_paragraph()
    footer_text_run = footer_text.add_run(f"本文档由 quick-learn-anything 技能生成 | {date_str}")
    set_run_font(footer_text_run, font_size=9, color=(180, 180, 180))
    footer_text.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 保存文档
    doc.save(output_path)
    print(f"✅ 认知报告已生成: {output_path}")
    print(f"   主题: {subject}")
    print(f"   视角: {user_background}")
    print(f"   日期: {date_str}")


def create_demo_data():
    """创建演示数据（F-35战斗机示例）"""
    return {
        "subject": "F-35战斗机",
        "user_background": "养猪的农民",
        "date": "2026年04月04日",
        "one_liner": "F-35战斗机是一种多用途隐形战斗机，用于在空中作战、对地攻击和侦察任务中取得优势。",
        "core_analogy": "就像你养的一头全能型种猪——它不仅能配种（空战），还能长得快（对地攻击），还能抗病（侦察能力），而且特别'低调'（隐形），不容易被发现。",
        "key_points": [
            "隐形设计：雷达很难发现它，就像黑猪在黑夜中很难被看见",
            "多功能：一架飞机干多种活，就像一头母猪又能生又能奶",
            "智能化：内置大量传感器和电脑，就像给猪装了健康监测设备"
        ],
        "step1_content": "F-35战斗机是一种多用途隐形战斗机，用于在空中作战、对地攻击和侦察任务中取得优势。它是目前世界上最先进的战斗机之一，由美国洛克希德·马丁公司研制。",
        "step1_analogy": "就像你养的一头全能型种猪——它不仅能配种（空战），还能长得快（对地攻击），还能抗病（侦察能力），而且特别'低调'（隐形），不容易被发现。",
        "step2_content": "F-35主要由以下部分组成：隐身外形（让雷达波散射）、发动机F135（提供超强推力）、航电系统（处理各种信息的大脑）、武器舱（携带导弹和炸弹）、头盔显示器（看到哪里信息就显示到哪里）。",
        "step2_analogy": "这些部件就像养猪场的各个功能区：猪舍（机身）、饲料系统（发动机）、管理系统（航电）、繁殖区（武器）、监控设备（头盔），相互配合才能高效运转。",
        "step3_content": "F-35的运行机制：接收任务指令→起飞巡航→用传感器探测目标→锁定并攻击→返航降落。整个过程高度自动化，飞行员主要做决策而不是操作。",
        "step3_analogy": "就像养猪的流程：制定喂养计划→把猪赶出来→观察猪的状态→发现问题及时处理→晚上把猪赶回圈里。",
        "step4_content": "F-35会根据不同情况切换模式：发现敌机时进入战斗模式，被雷达照射时启动电子干扰，燃料不足时必须返航。",
        "step4_analogy": "就像猪在不同情况下的状态：饿了要喂食、病了要治疗、长大了要出栏。",
        "step5_content": "上游：洛克希德·马丁公司（制造商）、美国军方（资金）。下游：空军/海军/海军陆战队（使用者）。平行：F-22、歼-20、苏-57等竞争对手。",
        "step5_analogy": "就像养猪产业链：种猪场提供种猪（上游）、屠宰场收购肉猪（下游）、其他养猪户是竞争对手。",
        "step6_content": "F-35解决了老飞机容易被发现、一种飞机只能干一种活、飞行员信息太多看不过来等问题。应用场景包括空中格斗、对地轰炸、侦察监视等。",
        "step6_analogy": "就像一头好种猪能解决繁殖率低、生长慢、易生病等问题，带来更好的经济效益。",
        "step7_content": "使用F-35需要经过严格训练，掌握起飞、巡航、作战、返航等流程。最佳实践包括保持隐身状态、与预警机配合、充分利用头盔显示器等。",
        "step7_analogy": "就像养猪需要学习喂养、防疫、繁殖等技术，还要积累经验才能养好。",
        "step8_content": "F-35的局限包括造价昂贵（每架约8000万美元）、维护复杂、载弹量受限。风险包括被先进雷达发现、电子战干扰等。",
        "step8_analogy": "就像一头天价种猪，买起来贵、养起来精贵、一次只能配有限的几头母猪，还有可能生病或配种失败。",
        "step9_content": "F-35代表了人类航空技术的巅峰，是第五代战斗机的典型代表。它诞生于21世纪初，体现了信息化战争时代对'网络中心战'的需求。从历史视角看，它延续了从螺旋桨到喷气式、从肉眼观瞄到雷达制导、从单一功能到多用途的演进脉络。F-35不仅是武器，更是技术文明的结晶，展现了人类在材料科学、航空工程、信息技术等领域的最高成就。",
        "step9_analogy": "就像养猪业从散养到规模化、从传统到智能化的发展历程，F-35代表了军事航空领域的'现代化养殖场'——高度集成、科技密集、系统复杂。",        
        "analogies": [
            {"element": "隐身外形", "analogy": "遮阳网", "similarity": "遮挡视线，不易被发现"},
            {"element": "发动机F135", "analogy": "优质饲料", "similarity": "提供强大动力/能量"},
            {"element": "航电系统", "analogy": "养猪管理软件", "similarity": "自动记录、智能决策"},
            {"element": "武器舱", "analogy": "猪肚子里的猪崽", "similarity": "藏在内部不显眼"},
            {"element": "头盔显示器", "analogy": "智能项圈", "similarity": "走到哪数据跟到哪"}
        ],
        "applicable_scenarios": ["空中格斗", "对地轰炸", "侦察监视", "编队作战"],
        "not_applicable_scenarios": ["近距离狗斗（不如专门设计的战机）", "低成本任务（杀鸡不用牛刀）"],
        "suggestions": ["与预警机、卫星配合，信息共享", "保持隐身状态，不轻易开启雷达", "充分利用头盔显示器的功能"],
        "summary_points": [
            "F-35是目前最先进的战斗机之一，集多种功能于一身",
            "隐形设计是其最大特点，让敌人难以发现",
            "价格昂贵、维护复杂，但作战效能极高",
            "用养猪的视角看，是'高科技+高投入+高回报'的典型"
        ],
        "next_steps": [
            "深入了解F-35的发动机技术",
            "对比F-35与其他战机的优劣",
            "了解隐身技术的原理",
            "关注F-35在实战中的表现"
        ],
        "resources": [
            "《F-35闪电II：世界最先进的战斗机》",
            "洛克希德·马丁官方技术手册",
            "军事科普频道相关视频",
            "航空知识杂志专题报道"
        ]
    }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='快速认知新事物 - Word报告生成器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  python generate_report.py data.json
  python generate_report.py data.json 输出.docx
  python generate_report.py --demo
  python generate_report.py --demo F35认知报告.docx
        '''
    )
    parser.add_argument('input', nargs='?', help='输入JSON文件路径')
    parser.add_argument('output', nargs='?', help='输出Word文档路径')
    parser.add_argument('--demo', action='store_true', help='使用演示数据生成示例报告')
    
    args = parser.parse_args()
    
    if args.demo:
        # 使用演示数据
        data = create_demo_data()
        output_path = args.output or "F35战斗机认知报告_养猪视角.docx"
        generate_report(data, output_path)
    elif args.input:
        # 读取JSON数据
        json_file = args.input
        output_path = args.output or f"{Path(json_file).stem}_认知报告.docx"
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            generate_report(data, output_path)
        except FileNotFoundError:
            print(f"❌ 错误: 找不到文件 '{json_file}'")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"❌ 错误: JSON格式不正确 - {e}")
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
