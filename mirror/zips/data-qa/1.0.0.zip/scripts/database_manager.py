#!/usr/bin/env python3
"""
数据库管理模块
负责数据库连接、建库建表、CRUD操作、索引管理等
数据库存储在 ~/.workbuddy/data/data-qa/ 目录下，与技能目录完全隔离
"""

import os
import sqlite3
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from contextlib import contextmanager


class DatabaseManager:
    """数据库管理器 - 处理所有数据库操作"""
    
    def __init__(self):
        """初始化数据库管理器"""
        # 数据库根目录：完全脱离技能目录
        self.db_root = Path.home() / ".workbuddy" / "data" / "data-qa"
        self.db_root.mkdir(parents=True, exist_ok=True)
        
        # 元数据库：存储数据库、表结构信息
        self.meta_db_path = self.db_root / "metadata.db"
        self._init_metadata_db()
    
    def _init_metadata_db(self):
        """初始化元数据库"""
        with sqlite3.connect(self.meta_db_path) as conn:
            cursor = conn.cursor()
            
            # 数据库信息表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS databases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    db_name TEXT UNIQUE NOT NULL,
                    db_type TEXT DEFAULT 'personal_data',
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # 表结构信息表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tables (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    db_name TEXT NOT NULL,
                    table_name TEXT NOT NULL,
                    schema_json TEXT NOT NULL,
                    primary_key TEXT NOT NULL,
                    unique_fields TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(db_name, table_name)
                )
            """)
            
            conn.commit()
    
    def get_db_path(self, db_name: str) -> Path:
        """获取数据库文件路径"""
        return self.db_root / f"{db_name}.db"
    
    @contextmanager
    def get_connection(self, db_name: str):
        """获取数据库连接（上下文管理器）"""
        db_path = self.get_db_path(db_name)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def create_database(self, db_name: str, description: str = "") -> bool:
        """
        创建新数据库
        
        Args:
            db_name: 数据库名称
            description: 数据库描述
            
        Returns:
            bool: 是否创建成功
        """
        try:
            # 记录到元数据库
            with sqlite3.connect(self.meta_db_path) as meta_conn:
                cursor = meta_conn.cursor()
                cursor.execute("""
                    INSERT OR IGNORE INTO databases (db_name, description)
                    VALUES (?, ?)
                """, (db_name, description))
                meta_conn.commit()
            
            # 创建实际数据库文件（通过连接自动创建）
            with self.get_connection(db_name) as conn:
                # 启用外键支持
                conn.execute("PRAGMA foreign_keys = ON")
            
            return True
        except Exception as e:
            print(f"创建数据库失败: {e}")
            return False
    
    def create_table(self, db_name: str, table_name: str, 
                     schema: Dict[str, str], primary_key: str,
                     unique_fields: List[str] = None) -> bool:
        """
        创建数据表
        
        Args:
            db_name: 数据库名称
            table_name: 表名称
            schema: 字段定义 {字段名: 字段类型}
            primary_key: 主键字段名
            unique_fields: 唯一性约束字段列表
            
        Returns:
            bool: 是否创建成功
        """
        try:
            # 构建建表SQL
            columns = []
            for field_name, field_type in schema.items():
                if field_name == primary_key:
                    columns.append(f"{field_name} {field_type} PRIMARY KEY")
                else:
                    columns.append(f"{field_name} {field_type}")
            
            # 添加唯一约束
            if unique_fields:
                unique_str = ", ".join(unique_fields)
                columns.append(f"UNIQUE({unique_str})")
            
            create_sql = f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    {', '.join(columns)}
                )
            """
            
            # 创建索引
            index_sqls = []
            for field in schema.keys():
                if field in ['record_time', 'tag', 'category', 'amount']:
                    index_sqls.append(f"""
                        CREATE INDEX IF NOT EXISTS idx_{table_name}_{field} 
                        ON {table_name}({field})
                    """)
            
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                cursor.execute(create_sql)
                for idx_sql in index_sqls:
                    cursor.execute(idx_sql)
            
            # 记录表结构到元数据库
            with sqlite3.connect(self.meta_db_path) as meta_conn:
                cursor = meta_conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO tables 
                    (db_name, table_name, schema_json, primary_key, unique_fields)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    db_name, 
                    table_name, 
                    json.dumps(schema, ensure_ascii=False),
                    primary_key,
                    json.dumps(unique_fields or [], ensure_ascii=False)
                ))
                meta_conn.commit()
            
            return True
        except Exception as e:
            print(f"创建表失败: {e}")
            return False
    
    def generate_primary_key(self, data: Dict[str, Any]) -> str:
        """
        生成主键
        根据数据内容自动生成唯一主键
        
        Args:
            data: 数据字典
            
        Returns:
            str: 主键值
        """
        # 核心字段组合生成唯一标识
        key_fields = []
        
        # 时间字段
        if 'record_time' in data:
            key_fields.append(str(data['record_time']))
        elif 'date' in data:
            key_fields.append(str(data['date']))
        
        # 标签/类别字段
        if 'tag' in data:
            key_fields.append(str(data['tag']))
        elif 'category' in data:
            key_fields.append(str(data['category']))
        
        # 金额字段
        if 'amount' in data:
            key_fields.append(str(data['amount']))
        
        # 商户/来源字段
        if 'merchant' in data:
            key_fields.append(str(data['merchant']))
        elif 'source' in data:
            key_fields.append(str(data['source']))
        
        # 使用MD5生成固定长度主键
        key_str = "|".join(key_fields)
        return hashlib.md5(key_str.encode('utf-8')).hexdigest()[:16]
    
    def check_duplicate(self, db_name: str, table_name: str, 
                        data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """
        检查数据是否重复
        
        Args:
            db_name: 数据库名称
            table_name: 表名称
            data: 待检查数据
            
        Returns:
            Tuple[bool, Optional[str]]: (是否重复, 重复记录的主键)
        """
        try:
            # 生成待检查数据的主键
            primary_key = self.generate_primary_key(data)
            
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                
                # 检查主键是否已存在
                cursor.execute(f"""
                    SELECT id FROM {table_name} WHERE id = ?
                """, (primary_key,))
                
                if cursor.fetchone():
                    return True, primary_key
                
                # 检查核心唯一字段组合
                conditions = []
                params = []
                
                if 'record_time' in data:
                    conditions.append("record_time = ?")
                    params.append(data['record_time'])
                elif 'date' in data:
                    conditions.append("date = ?")
                    params.append(data['date'])
                
                if 'amount' in data:
                    conditions.append("amount = ?")
                    params.append(data['amount'])
                
                if 'tag' in data:
                    conditions.append("tag = ?")
                    params.append(data['tag'])
                elif 'category' in data:
                    conditions.append("category = ?")
                    params.append(data['category'])
                
                if conditions:
                    query = f"""
                        SELECT id FROM {table_name} 
                        WHERE {' AND '.join(conditions)}
                        LIMIT 1
                    """
                    cursor.execute(query, params)
                    result = cursor.fetchone()
                    if result:
                        return True, result['id']
            
            return False, None
        except Exception as e:
            print(f"查重失败: {e}")
            return False, None
    
    def insert_data(self, db_name: str, table_name: str, 
                    data: Dict[str, Any], check_duplicate: bool = True) -> Tuple[bool, str]:
        """
        插入数据
        
        Args:
            db_name: 数据库名称
            table_name: 表名称
            data: 待插入数据
            check_duplicate: 是否检查重复
            
        Returns:
            Tuple[bool, str]: (是否成功, 消息/主键)
        """
        try:
            # 生成主键
            primary_key = self.generate_primary_key(data)
            data['id'] = primary_key
            
            # 检查重复
            if check_duplicate:
                is_dup, dup_id = self.check_duplicate(db_name, table_name, data)
                if is_dup:
                    return False, f"DUPLICATE:{dup_id}"
            
            # 添加元数据
            data['created_at'] = datetime.now().isoformat()
            data['updated_at'] = datetime.now().isoformat()
            
            # 构建插入SQL
            fields = list(data.keys())
            placeholders = ', '.join(['?' for _ in fields])
            values = [data[f] for f in fields]
            
            insert_sql = f"""
                INSERT INTO {table_name} ({', '.join(fields)})
                VALUES ({placeholders})
            """
            
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                cursor.execute(insert_sql, values)
            
            return True, primary_key
        except Exception as e:
            return False, f"INSERT_ERROR:{str(e)}"
    
    def query_data(self, db_name: str, table_name: str,
                   conditions: Dict[str, Any] = None,
                   order_by: str = None,
                   limit: int = None) -> List[Dict[str, Any]]:
        """
        查询数据
        
        Args:
            db_name: 数据库名称
            table_name: 表名称
            conditions: 查询条件
            order_by: 排序字段
            limit: 限制条数
            
        Returns:
            List[Dict]: 查询结果列表
        """
        try:
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                
                # 构建查询SQL
                if conditions:
                    where_clauses = []
                    params = []
                    for key, value in conditions.items():
                        if isinstance(value, tuple) and len(value) == 2:
                            # 范围查询 (field, ('>=', value))
                            op, val = value
                            where_clauses.append(f"{key} {op} ?")
                            params.append(val)
                        else:
                            where_clauses.append(f"{key} = ?")
                            params.append(value)
                    
                    where_sql = " WHERE " + " AND ".join(where_clauses)
                else:
                    where_sql = ""
                    params = []
                
                query = f"SELECT * FROM {table_name}{where_sql}"
                
                if order_by:
                    query += f" ORDER BY {order_by}"
                
                if limit:
                    query += f" LIMIT {limit}"
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                return [dict(row) for row in rows]
        except Exception as e:
            print(f"查询失败: {e}")
            return []
    
    def aggregate_data(self, db_name: str, table_name: str,
                       agg_func: str, field: str,
                       conditions: Dict[str, Any] = None) -> Optional[float]:
        """
        聚合查询
        
        Args:
            db_name: 数据库名称
            table_name: 表名称
            agg_func: 聚合函数 (SUM, AVG, MAX, MIN, COUNT)
            field: 聚合字段
            conditions: 查询条件
            
        Returns:
            Optional[float]: 聚合结果
        """
        try:
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                
                if conditions:
                    where_clauses = []
                    params = []
                    for key, value in conditions.items():
                        where_clauses.append(f"{key} = ?")
                        params.append(value)
                    where_sql = " WHERE " + " AND ".join(where_clauses)
                else:
                    where_sql = ""
                    params = []
                
                query = f"SELECT {agg_func}({field}) as result FROM {table_name}{where_sql}"
                cursor.execute(query, params)
                row = cursor.fetchone()
                
                return row['result'] if row and row['result'] else 0.0
        except Exception as e:
            print(f"聚合查询失败: {e}")
            return None
    
    def get_table_list(self, db_name: str) -> List[str]:
        """获取数据库中所有表名"""
        try:
            with self.get_connection(db_name) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name NOT LIKE 'sqlite_%'
                """)
                return [row['name'] for row in cursor.fetchall()]
        except Exception as e:
            print(f"获取表列表失败: {e}")
            return []
    
    def get_databases(self) -> List[Dict[str, Any]]:
        """获取所有数据库列表"""
        try:
            with sqlite3.connect(self.meta_db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM databases ORDER BY created_at DESC")
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            print(f"获取数据库列表失败: {e}")
            return []


# 单例模式
_db_manager = None

def get_db_manager() -> DatabaseManager:
    """获取数据库管理器实例"""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager()
    return _db_manager


if __name__ == "__main__":
    # 测试代码
    db_mgr = get_db_manager()
    
    # 创建测试数据库
    db_mgr.create_database("test_personal", "个人消费数据")
    
    # 创建测试表
    schema = {
        "id": "TEXT",
        "record_time": "TEXT",
        "amount": "REAL",
        "tag": "TEXT",
        "category": "TEXT",
        "merchant": "TEXT",
        "note": "TEXT",
        "created_at": "TEXT",
        "updated_at": "TEXT"
    }
    db_mgr.create_table("test_personal", "consumption", schema, "id", 
                        ["record_time", "amount", "tag"])
    
    # 插入测试数据
    test_data = {
        "record_time": "2024-01-15",
        "amount": 35.0,
        "tag": "餐饮美食",
        "category": "日常就餐",
        "merchant": "肯德基",
        "note": "午餐"
    }
    success, result = db_mgr.insert_data("test_personal", "consumption", test_data)
    print(f"插入结果: {success}, {result}")
    
    # 重复插入测试
    success, result = db_mgr.insert_data("test_personal", "consumption", test_data)
    print(f"重复插入结果: {success}, {result}")
