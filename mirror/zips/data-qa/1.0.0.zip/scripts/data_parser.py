#!/usr/bin/env python3
"""
数据解析模块
负责解析多种格式的数据输入：文字、OCR图片、Excel、CSV、语音等
"""

import re
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class ParsedRecord:
    """解析后的数据记录"""
    record_time: str
    amount: Optional[float]
    tag: str
    category: Optional[str]
    merchant: Optional[str]
    note: Optional[str]
    source_type: str  # 数据来源类型
    raw_data: Dict[str, Any]  # 原始解析数据


class TextDataParser:
    """文字/语音数据解析器"""
    
    # 金额匹配正则
    AMOUNT_PATTERNS = [
        r'(\d+(?:\.\d{1,2})?)\s*元',
        r'花费?了?\s*(\d+(?:\.\d{1,2})?)',
        r'支出\s*(\d+(?:\.\d{1,2})?)',
        r'消费\s*(\d+(?:\.\d{1,2})?)',
        r'(\d+(?:\.\d{1,2})?)\s*块',
    ]
    
    # 时间匹配正则
    TIME_PATTERNS = [
        (r'今天', 'today'),
        (r'昨天', 'yesterday'),
        (r'前天', 'day_before_yesterday'),
        (r'(\d{1,2})月(\d{1,2})日?', 'date_md'),
        (r'(\d{4})[-年](\d{1,2})[-月](\d{1,2})', 'date_ymd'),
    ]
    
    # 标签关键词映射
    TAG_KEYWORDS = {
        '餐饮美食': ['吃饭', '餐厅', '外卖', '聚餐', '火锅', '烧烤', '肯德基', '麦当劳', 
                   '星巴克', '奶茶', '咖啡', '午餐', '晚餐', '早餐', '请客', '饭局'],
        '交通出行': ['打车', '地铁', '公交', '高铁', '飞机', '加油', '停车', '滴滴', 
                   '出租车', '地铁', '火车票', '机票', '油费', '保养'],
        '居家日用': ['超市', '购物', '日用品', '买菜', '水果', '零食', '纸巾', '洗发水',
                   '洗衣液', '超市', '便利店', '杂货'],
        '医疗健康': ['医院', '药店', '看病', '买药', '体检', '挂号', '医疗费', '药费'],
        '休闲娱乐': ['电影', '游戏', 'KTV', '旅游', '景点', '门票', '会员', '充值',
                   '娱乐', '休闲', '放松'],
        '水电缴费': ['电费', '水费', '燃气费', '物业费', '宽带费', '话费', '缴费'],
    }
    
    def parse(self, text: str) -> Optional[ParsedRecord]:
        """
        解析文字输入
        
        Args:
            text: 用户输入的文字
            
        Returns:
            ParsedRecord: 解析后的记录
        """
        text = text.strip()
        if not text:
            return None
        
        # 提取金额
        amount = self._extract_amount(text)
        
        # 提取时间
        record_time = self._extract_time(text)
        
        # 识别标签
        tag, category = self._extract_tag(text)
        
        # 提取商户/备注
        merchant, note = self._extract_merchant_and_note(text)
        
        return ParsedRecord(
            record_time=record_time,
            amount=amount,
            tag=tag,
            category=category,
            merchant=merchant,
            note=note,
            source_type='text',
            raw_data={'input_text': text}
        )
    
    def _extract_amount(self, text: str) -> Optional[float]:
        """提取金额"""
        for pattern in self.AMOUNT_PATTERNS:
            match = re.search(pattern, text)
            if match:
                try:
                    return float(match.group(1))
                except ValueError:
                    continue
        return None
    
    def _extract_time(self, text: str) -> str:
        """提取时间"""
        today = datetime.now()
        
        for pattern, pattern_type in self.TIME_PATTERNS:
            match = re.search(pattern, text)
            if match:
                if pattern_type == 'today':
                    return today.strftime('%Y-%m-%d')
                elif pattern_type == 'yesterday':
                    return (today - timedelta(days=1)).strftime('%Y-%m-%d')
                elif pattern_type == 'day_before_yesterday':
                    return (today - timedelta(days=2)).strftime('%Y-%m-%d')
                elif pattern_type == 'date_md':
                    month = int(match.group(1))
                    day = int(match.group(2))
                    return today.replace(month=month, day=day).strftime('%Y-%m-%d')
                elif pattern_type == 'date_ymd':
                    year = int(match.group(1))
                    month = int(match.group(2))
                    day = int(match.group(3))
                    return f"{year:04d}-{month:02d}-{day:02d}"
        
        # 默认返回今天
        return today.strftime('%Y-%m-%d')
    
    def _extract_tag(self, text: str) -> Tuple[str, Optional[str]]:
        """提取标签"""
        for tag, keywords in self.TAG_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    # 尝试识别二级分类
                    category = self._extract_category(text, tag)
                    return tag, category
        
        # 默认标签
        return '其他', None
    
    def _extract_category(self, text: str, parent_tag: str) -> Optional[str]:
        """提取二级分类"""
        category_keywords = {
            '餐饮美食': {
                '日常就餐': ['午餐', '晚餐', '早餐', '简餐'],
                '商务宴请': ['请客', '商务', '招待', '应酬'],
                '家庭聚餐': ['家宴', '家庭', '聚餐', '团圆'],
                '外卖快餐': ['外卖', '快餐', '便当'],
            },
            '交通出行': {
                '公共交通': ['地铁', '公交', '火车'],
                '打车出行': ['打车', '滴滴', '出租车'],
                '私家车': ['加油', '停车', '保养', '维修'],
                '长途出行': ['飞机', '高铁', '机票'],
            }
        }
        
        if parent_tag in category_keywords:
            for category, keywords in category_keywords[parent_tag].items():
                for keyword in keywords:
                    if keyword in text:
                        return category
        
        return None
    
    def _extract_merchant_and_note(self, text: str) -> Tuple[Optional[str], Optional[str]]:
        """提取商户和备注信息"""
        # 常见商户关键词
        common_merchants = [
            '肯德基', '麦当劳', '星巴克', '瑞幸', '喜茶', '奈雪',
            '盒马', '山姆', '沃尔玛', '家乐福', '永辉',
            '滴滴', '高德', '美团', '饿了么', '淘宝', '京东',
        ]
        
        merchant = None
        for m in common_merchants:
            if m in text:
                merchant = m
                break
        
        # 其他信息作为备注
        note = None
        if '，' in text or ',' in text:
            parts = re.split(r'[，,]', text)
            if len(parts) > 1:
                note = parts[-1].strip()
        
        return merchant, note


class OCRDataParser:
    """OCR图片数据解析器"""
    
    def parse(self, ocr_text: str, image_type: str = 'receipt') -> Optional[ParsedRecord]:
        """
        解析OCR识别结果
        
        Args:
            ocr_text: OCR识别出的文字
            image_type: 图片类型 (receipt, invoice, screenshot)
            
        Returns:
            ParsedRecord: 解析后的记录
        """
        # 提取金额
        amount = self._extract_amount_from_ocr(ocr_text)
        
        # 提取时间
        record_time = self._extract_time_from_ocr(ocr_text)
        
        # 识别商户
        merchant = self._extract_merchant_from_ocr(ocr_text)
        
        # 自动识别标签
        tag = self._classify_by_merchant(merchant, ocr_text)
        
        # 提取备注
        note = self._extract_note_from_ocr(ocr_text)
        
        return ParsedRecord(
            record_time=record_time,
            amount=amount,
            tag=tag,
            category=None,
            merchant=merchant,
            note=note,
            source_type='ocr',
            raw_data={'ocr_text': ocr_text, 'image_type': image_type}
        )
    
    def _extract_amount_from_ocr(self, text: str) -> Optional[float]:
        """从OCR文本中提取金额"""
        # 匹配常见金额格式
        patterns = [
            r'(?:金额|总价|合计|总计|实付|支付)[:：\s]*[￥¥]?\s*(\d+(?:,\d{3})*(?:\.\d{1,2})?)',
            r'[￥¥]\s*(\d+(?:,\d{3})*(?:\.\d{1,2})?)',
            r'(?:RMB|CNY)\s*(\d+(?:,\d{3})*(?:\.\d{1,2})?)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            if matches:
                # 取最大的金额（通常是总价）
                amounts = [float(m.replace(',', '')) for m in matches]
                return max(amounts)
        
        return None
    
    def _extract_time_from_ocr(self, text: str) -> str:
        """从OCR文本中提取时间"""
        # 匹配日期时间格式
        patterns = [
            r'(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})',
            r'(\d{1,2})[-/](\d{1,2})[-/](\d{4})',
            r'(\d{4})(\d{2})(\d{2})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                groups = match.groups()
                if len(groups[0]) == 4:  # YYYY开头
                    return f"{groups[0]}-{int(groups[1]):02d}-{int(groups[2]):02d}"
                else:  # MM/DD/YYYY格式
                    return f"{groups[2]}-{int(groups[0]):02d}-{int(groups[1]):02d}"
        
        return datetime.now().strftime('%Y-%m-%d')
    
    def _extract_merchant_from_ocr(self, text: str) -> Optional[str]:
        """从OCR文本中提取商户名称"""
        # 匹配常见商户前缀
        patterns = [
            r'商户名称[:：\s]*(\S+)',
            r'店名[:：\s]*(\S+)',
            r'商家[:：\s]*(\S+)',
            r'(?:欢迎光临|感谢您的光临)(\S+)[,，]?',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        return None
    
    def _classify_by_merchant(self, merchant: Optional[str], text: str) -> str:
        """根据商户识别标签"""
        merchant_tags = {
            '餐饮美食': ['肯德基', '麦当劳', '星巴克', '餐厅', '饭店', '火锅', '烧烤', '奶茶'],
            '交通出行': ['滴滴', '出租车', '地铁', '加油', '停车'],
            '居家日用': ['超市', '便利店', '商场', '购物'],
            '医疗健康': ['医院', '药店', '诊所'],
        }
        
        if merchant:
            for tag, keywords in merchant_tags.items():
                for kw in keywords:
                    if kw in merchant or kw in text:
                        return tag
        
        return '其他'
    
    def _extract_note_from_ocr(self, text: str) -> Optional[str]:
        """从OCR文本中提取备注"""
        # 提取商品列表作为备注
        lines = text.split('\n')
        items = [line.strip() for line in lines if line.strip() and len(line.strip()) < 20]
        if items:
            return '、'.join(items[:5])  # 取前5项
        return None


class ExcelCSVParser:
    """Excel/CSV数据解析器"""
    
    # 字段映射规则
    FIELD_MAPPINGS = {
        'time': ['时间', '日期', 'date', 'time', '消费日期', '记录时间'],
        'amount': ['金额', '支出', '消费', 'amount', 'money', 'price', '费用'],
        'tag': ['类别', '分类', '类型', 'tag', 'category', 'type'],
        'merchant': ['商户', '商家', '店铺', 'merchant', 'store', 'seller'],
        'note': ['备注', '说明', 'note', 'description', 'memo'],
    }
    
    def parse_excel(self, file_path: str) -> List[ParsedRecord]:
        """
        解析Excel文件
        
        Args:
            file_path: Excel文件路径
            
        Returns:
            List[ParsedRecord]: 解析后的记录列表
        """
        try:
            import openpyxl
            
            wb = openpyxl.load_workbook(file_path)
            records = []
            
            for sheet in wb.worksheets:
                rows = list(sheet.iter_rows(values_only=True))
                if not rows:
                    continue
                
                # 第一行作为表头
                headers = [str(h).strip() if h else '' for h in rows[0]]
                field_map = self._map_fields(headers)
                
                # 解析数据行
                for row in rows[1:]:
                    record = self._parse_row(row, field_map, headers, 'excel')
                    if record:
                        records.append(record)
            
            return records
        except ImportError:
            print("请安装openpyxl: pip install openpyxl")
            return []
        except Exception as e:
            print(f"解析Excel失败: {e}")
            return []
    
    def parse_csv(self, file_path: str, encoding: str = 'utf-8') -> List[ParsedRecord]:
        """
        解析CSV文件
        
        Args:
            file_path: CSV文件路径
            encoding: 文件编码
            
        Returns:
            List[ParsedRecord]: 解析后的记录列表
        """
        try:
            import csv
            
            records = []
            
            # 尝试不同编码
            encodings = [encoding, 'utf-8', 'gbk', 'gb2312', 'utf-8-sig']
            
            for enc in encodings:
                try:
                    with open(file_path, 'r', encoding=enc) as f:
                        # 自动检测分隔符
                        sample = f.read(1024)
                        f.seek(0)
                        
                        delimiter = ','
                        if ';' in sample:
                            delimiter = ';'
                        elif '\t' in sample:
                            delimiter = '\t'
                        
                        reader = csv.reader(f, delimiter=delimiter)
                        rows = list(reader)
                        
                        if not rows:
                            continue
                        
                        # 第一行作为表头
                        headers = [h.strip() if h else '' for h in rows[0]]
                        field_map = self._map_fields(headers)
                        
                        # 解析数据行
                        for row in rows[1:]:
                            record = self._parse_row(row, field_map, headers, 'csv')
                            if record:
                                records.append(record)
                        
                        break  # 成功解析，跳出编码循环
                except UnicodeDecodeError:
                    continue
            
            return records
        except Exception as e:
            print(f"解析CSV失败: {e}")
            return []
    
    def _map_fields(self, headers: List[str]) -> Dict[str, int]:
        """映射表头到标准字段"""
        field_map = {}
        
        for std_field, possible_names in self.FIELD_MAPPINGS.items():
            for i, header in enumerate(headers):
                if any(name in header for name in possible_names):
                    field_map[std_field] = i
                    break
        
        return field_map
    
    def _parse_row(self, row: Tuple, field_map: Dict[str, int], 
                   headers: List[str], source_type: str) -> Optional[ParsedRecord]:
        """解析单行数据"""
        try:
            # 获取字段值
            time_idx = field_map.get('time', -1)
            amount_idx = field_map.get('amount', -1)
            tag_idx = field_map.get('tag', -1)
            merchant_idx = field_map.get('merchant', -1)
            note_idx = field_map.get('note', -1)
            
            # 解析时间
            if time_idx >= 0 and time_idx < len(row):
                record_time = self._normalize_time(str(row[time_idx]))
            else:
                record_time = datetime.now().strftime('%Y-%m-%d')
            
            # 解析金额
            amount = None
            if amount_idx >= 0 and amount_idx < len(row):
                amount_str = str(row[amount_idx]).replace(',', '').replace('￥', '').replace('¥', '')
                try:
                    amount = float(amount_str)
                except ValueError:
                    pass
            
            # 解析标签
            tag = '其他'
            if tag_idx >= 0 and tag_idx < len(row) and row[tag_idx]:
                tag = str(row[tag_idx]).strip()
            
            # 解析商户
            merchant = None
            if merchant_idx >= 0 and merchant_idx < len(row) and row[merchant_idx]:
                merchant = str(row[merchant_idx]).strip()
            
            # 解析备注
            note = None
            if note_idx >= 0 and note_idx < len(row) and row[note_idx]:
                note = str(row[note_idx]).strip()
            
            return ParsedRecord(
                record_time=record_time,
                amount=amount,
                tag=tag,
                category=None,
                merchant=merchant,
                note=note,
                source_type=source_type,
                raw_data={'row_data': row, 'headers': headers}
            )
        except Exception as e:
            print(f"解析行失败: {e}")
            return None
    
    def _normalize_time(self, time_str: str) -> str:
        """标准化时间格式"""
        formats = [
            '%Y-%m-%d',
            '%Y/%m/%d',
            '%Y年%m月%d日',
            '%m-%d',
            '%m/%d',
        ]
        
        for fmt in formats:
            try:
                dt = datetime.strptime(time_str.strip(), fmt)
                if dt.year == 1900:  # 没有年份，使用当前年
                    dt = dt.replace(year=datetime.now().year)
                return dt.strftime('%Y-%m-%d')
            except ValueError:
                continue
        
        return datetime.now().strftime('%Y-%m-%d')


class DataParser:
    """统一数据解析入口"""
    
    def __init__(self):
        self.text_parser = TextDataParser()
        self.ocr_parser = OCRDataParser()
        self.file_parser = ExcelCSVParser()
    
    def parse_text(self, text: str) -> Optional[ParsedRecord]:
        """解析文字输入"""
        return self.text_parser.parse(text)
    
    def parse_ocr(self, ocr_text: str, image_type: str = 'receipt') -> Optional[ParsedRecord]:
        """解析OCR结果"""
        return self.ocr_parser.parse(ocr_text, image_type)
    
    def parse_excel(self, file_path: str) -> List[ParsedRecord]:
        """解析Excel文件"""
        return self.file_parser.parse_excel(file_path)
    
    def parse_csv(self, file_path: str) -> List[ParsedRecord]:
        """解析CSV文件"""
        return self.file_parser.parse_csv(file_path)
    
    def to_db_record(self, parsed: ParsedRecord) -> Dict[str, Any]:
        """转换为数据库存储格式"""
        return {
            'record_time': parsed.record_time,
            'amount': parsed.amount,
            'tag': parsed.tag,
            'category': parsed.category,
            'merchant': parsed.merchant,
            'note': parsed.note,
            'source_type': parsed.source_type,
            'raw_data': json.dumps(parsed.raw_data, ensure_ascii=False),
        }


# 单例
_parser = None

def get_parser() -> DataParser:
    """获取解析器实例"""
    global _parser
    if _parser is None:
        _parser = DataParser()
    return _parser


if __name__ == "__main__":
    parser = get_parser()
    
    # 测试文字解析
    test_text = "昨天在肯德基吃午饭花了35元，和同事一起"
    result = parser.parse_text(test_text)
    if result:
        print(f"文字解析结果: {result}")
    
    # 测试OCR解析
    ocr_text = """
    肯德基餐厅
    消费日期: 2024-01-15
    金额: ￥35.00
    商品: 午餐套餐
    """
    result = parser.parse_ocr(ocr_text)
    if result:
        print(f"OCR解析结果: {result}")
