#!/usr/bin/env python3
"""
数据去重模块
负责重复数据检测、处理和提示
"""

import json
import hashlib
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class DuplicateCheckResult:
    """重复检查结果"""
    is_duplicate: bool
    duplicate_id: Optional[str]
    similarity: float
    existing_record: Optional[Dict[str, Any]]
    message: str


class DeduplicationEngine:
    """去重引擎"""
    
    def __init__(self, similarity_threshold: float = 0.85):
        """
        初始化去重引擎
        
        Args:
            similarity_threshold: 相似度阈值（默认0.85）
        """
        self.similarity_threshold = similarity_threshold
    
    def check_duplicate(self, new_data: Dict[str, Any],
                       existing_records: List[Dict[str, Any]]) -> DuplicateCheckResult:
        """
        检查数据是否重复
        
        Args:
            new_data: 待检查的新数据
            existing_records: 已有记录列表
            
        Returns:
            DuplicateCheckResult: 检查结果
        """
        if not existing_records:
            return DuplicateCheckResult(
                is_duplicate=False,
                duplicate_id=None,
                similarity=0.0,
                existing_record=None,
                message=""
            )
        
        # 精确匹配（主键或唯一字段）
        exact_match = self._exact_match_check(new_data, existing_records)
        if exact_match:
            return DuplicateCheckResult(
                is_duplicate=True,
                duplicate_id=exact_match['id'],
                similarity=1.0,
                existing_record=exact_match,
                message=f"发现完全重复的数据（ID: {exact_match['id']}）"
            )
        
        # 模糊匹配（相似度检查）
        fuzzy_match = self._fuzzy_match_check(new_data, existing_records)
        if fuzzy_match and fuzzy_match[1] >= self.similarity_threshold:
            return DuplicateCheckResult(
                is_duplicate=True,
                duplicate_id=fuzzy_match[0]['id'],
                similarity=fuzzy_match[1],
                existing_record=fuzzy_match[0],
                message=f"发现高度相似的数据（相似度: {fuzzy_match[1]:.1%}）"
            )
        
        return DuplicateCheckResult(
            is_duplicate=False,
            duplicate_id=None,
            similarity=fuzzy_match[1] if fuzzy_match else 0.0,
            existing_record=None,
            message=""
        )
    
    def _exact_match_check(self, new_data: Dict[str, Any],
                          existing_records: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        精确匹配检查
        
        检查核心字段是否完全一致：
        - 时间（record_time/date）
        - 金额（amount）
        - 标签（tag/category）
        - 商户（merchant/source）
        """
        new_time = new_data.get('record_time') or new_data.get('date', '')
        new_amount = float(new_data.get('amount', 0) or 0)
        new_tag = new_data.get('tag') or new_data.get('category', '')
        new_merchant = new_data.get('merchant') or new_data.get('source', '')
        
        for record in existing_records:
            # 检查主键是否相同
            if 'id' in new_data and 'id' in record:
                if new_data['id'] == record['id']:
                    return record
            
            # 检查核心字段
            rec_time = record.get('record_time') or record.get('date', '')
            rec_amount = float(record.get('amount', 0) or 0)
            rec_tag = record.get('tag') or record.get('category', '')
            rec_merchant = record.get('merchant') or record.get('source', '')
            
            # 时间、金额、标签完全相同视为重复
            if (rec_time == new_time and 
                abs(rec_amount - new_amount) < 0.01 and
                rec_tag == new_tag):
                return record
        
        return None
    
    def _fuzzy_match_check(self, new_data: Dict[str, Any],
                          existing_records: List[Dict[str, Any]]) -> Optional[Tuple[Dict[str, Any], float]]:
        """
        模糊匹配检查
        
        计算数据相似度，返回最相似的记录及其相似度
        """
        best_match = None
        best_similarity = 0.0
        
        for record in existing_records:
            similarity = self._calculate_similarity(new_data, record)
            if similarity > best_similarity:
                best_similarity = similarity
                best_match = record
        
        return (best_match, best_similarity) if best_match else None
    
    def _calculate_similarity(self, data1: Dict[str, Any], 
                               data2: Dict[str, Any]) -> float:
        """
        计算两条数据的相似度
        
        基于以下字段计算：
        - 时间（权重30%）：同一天得满分
        - 金额（权重30%）：差额在10%以内得满分
        - 标签（权重20%）：相同得满分
        - 商户（权重20%）：相同得满分
        """
        weights = {
            'time': 0.30,
            'amount': 0.30,
            'tag': 0.20,
            'merchant': 0.20
        }
        
        scores = {}
        
        # 时间相似度
        time1 = data1.get('record_time') or data1.get('date', '')
        time2 = data2.get('record_time') or data2.get('date', '')
        if time1 == time2:
            scores['time'] = 1.0
        elif time1[:7] == time2[:7]:  # 同一个月
            scores['time'] = 0.5
        else:
            scores['time'] = 0.0
        
        # 金额相似度
        amount1 = float(data1.get('amount', 0) or 0)
        amount2 = float(data2.get('amount', 0) or 0)
        if amount1 > 0 and amount2 > 0:
            diff_ratio = abs(amount1 - amount2) / max(amount1, amount2)
            scores['amount'] = max(0, 1 - diff_ratio * 10)  # 10%差异内给高分
        else:
            scores['amount'] = 1.0 if amount1 == amount2 else 0.0
        
        # 标签相似度
        tag1 = data1.get('tag') or data1.get('category', '')
        tag2 = data2.get('tag') or data2.get('category', '')
        scores['tag'] = 1.0 if tag1 == tag2 else 0.0
        
        # 商户相似度
        merchant1 = data1.get('merchant') or data1.get('source', '')
        merchant2 = data2.get('merchant') or data2.get('source', '')
        scores['merchant'] = 1.0 if merchant1 == merchant2 else 0.0
        
        # 计算加权相似度
        total_similarity = sum(scores.get(k, 0) * w for k, w in weights.items())
        return total_similarity
    
    def format_duplicate_warning(self, result: DuplicateCheckResult) -> str:
        """
        格式化重复警告信息
        
        Args:
            result: 重复检查结果
            
        Returns:
            str: 警告信息
        """
        if not result.is_duplicate:
            return ""
        
        existing = result.existing_record
        if not existing:
            return "检测到可能的重复数据"
        
        lines = [
            "⚠️ 检测到重复数据",
            "",
            "已存在的数据：",
            f"  📅 时间: {existing.get('record_time', existing.get('date', '未知'))}",
            f"  🏷️ 标签: {existing.get('tag', existing.get('category', '未知'))}",
            f"  💰 金额: {float(existing.get('amount', 0) or 0):,.2f} 元",
        ]
        
        if existing.get('merchant'):
            lines.append(f"  🏪 商户: {existing['merchant']}")
        
        if existing.get('note'):
            lines.append(f"  📝 备注: {existing['note'][:30]}...")
        
        lines.extend([
            "",
            f"相似度: {result.similarity:.1%}",
            "",
            "是否仍然要录入这条数据？",
        ])
        
        return "\n".join(lines)
    
    def batch_check(self, new_records: List[Dict[str, Any]],
                   existing_records: List[Dict[str, Any]]) -> List[Tuple[Dict[str, Any], DuplicateCheckResult]]:
        """
        批量检查重复
        
        Args:
            new_records: 新记录列表
            existing_records: 已有记录列表
            
        Returns:
            List: (新记录, 检查结果) 列表
        """
        results = []
        for record in new_records:
            check_result = self.check_duplicate(record, existing_records)
            results.append((record, check_result))
        return results
    
    def generate_fingerprint(self, data: Dict[str, Any]) -> str:
        """
        生成数据指纹（用于快速查重）
        
        Args:
            data: 数据字典
            
        Returns:
            str: 数据指纹
        """
        # 提取核心字段
        fingerprint_parts = []
        
        time_field = data.get('record_time') or data.get('date', '')
        fingerprint_parts.append(str(time_field))
        
        amount_field = float(data.get('amount', 0) or 0)
        fingerprint_parts.append(f"{amount_field:.2f}")
        
        tag_field = data.get('tag') or data.get('category', '')
        fingerprint_parts.append(str(tag_field))
        
        # 生成MD5指纹
        fingerprint_str = "|".join(fingerprint_parts)
        return hashlib.md5(fingerprint_str.encode('utf-8')).hexdigest()[:12]


class DuplicateHandler:
    """重复数据处理器"""
    
    def __init__(self):
        self.engine = DeduplicationEngine()
    
    def process_insert(self, new_data: Dict[str, Any],
                      existing_records: List[Dict[str, Any]],
                      force_insert: bool = False) -> Tuple[bool, str]:
        """
        处理数据插入（带重复检查）
        
        Args:
            new_data: 新数据
            existing_records: 已有记录
            force_insert: 是否强制插入（忽略重复）
            
        Returns:
            Tuple[bool, str]: (是否插入, 消息)
        """
        result = self.engine.check_duplicate(new_data, existing_records)
        
        if result.is_duplicate and not force_insert:
            warning = self.engine.format_duplicate_warning(result)
            return False, warning
        
        return True, ""
    
    def process_batch_insert(self, new_records: List[Dict[str, Any]],
                             existing_records: List[Dict[str, Any]],
                             auto_skip: bool = True) -> Tuple[List[Dict[str, Any]], 
                                                               List[Dict[str, Any]],
                                                               List[str]]:
        """
        批量处理数据插入
        
        Args:
            new_records: 新记录列表
            existing_records: 已有记录
            auto_skip: 是否自动跳过重复
            
        Returns:
            Tuple: (待插入记录, 重复记录, 提示信息)
        """
        to_insert = []
        duplicates = []
        messages = []
        
        check_results = self.engine.batch_check(new_records, existing_records)
        
        for record, result in check_results:
            if result.is_duplicate:
                duplicates.append(record)
                if auto_skip:
                    messages.append(f"跳过重复记录: {result.message}")
            else:
                to_insert.append(record)
        
        return to_insert, duplicates, messages


# 单例
_engine = None

def get_deduplication_engine() -> DeduplicationEngine:
    """获取去重引擎实例"""
    global _engine
    if _engine is None:
        _engine = DeduplicationEngine()
    return _engine


_handler = None

def get_duplicate_handler() -> DuplicateHandler:
    """获取重复数据处理器实例"""
    global _handler
    if _handler is None:
        _handler = DuplicateHandler()
    return _handler


if __name__ == "__main__":
    # 测试去重功能
    engine = get_deduplication_engine()
    
    existing = [
        {
            'id': '001',
            'record_time': '2024-01-15',
            'amount': 35.0,
            'tag': '餐饮美食',
            'merchant': '肯德基',
            'note': '午餐'
        },
        {
            'id': '002',
            'record_time': '2024-01-16',
            'amount': 50.0,
            'tag': '交通出行',
            'merchant': '滴滴',
            'note': '打车回家'
        }
    ]
    
    # 测试完全重复
    new1 = {
        'record_time': '2024-01-15',
        'amount': 35.0,
        'tag': '餐饮美食',
        'merchant': '肯德基',
        'note': '午餐'
    }
    result1 = engine.check_duplicate(new1, existing)
    print(f"完全重复检查: {result1}")
    print(engine.format_duplicate_warning(result1))
    
    # 测试相似数据
    new2 = {
        'record_time': '2024-01-15',
        'amount': 36.0,  # 金额略有不同
        'tag': '餐饮美食',
        'merchant': '肯德基',
        'note': '午餐'
    }
    result2 = engine.check_duplicate(new2, existing)
    print(f"\n相似数据检查: {result2}")
    print(engine.format_duplicate_warning(result2))
    
    # 测试不重复数据
    new3 = {
        'record_time': '2024-01-20',
        'amount': 100.0,
        'tag': '休闲娱乐',
        'merchant': '电影院',
        'note': '看电影'
    }
    result3 = engine.check_duplicate(new3, existing)
    print(f"\n新数据检查: is_duplicate={result3.is_duplicate}")
