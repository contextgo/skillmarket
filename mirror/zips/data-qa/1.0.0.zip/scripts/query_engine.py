#!/usr/bin/env python3
"""
查询引擎模块
负责语义解析、查询构建、统计运算、图表生成
"""

import re
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class QueryType(Enum):
    """查询类型"""
    SINGLE = "single"           # 单条查询
    LIST = "list"               # 列表查询
    AGGREGATE = "aggregate"     # 聚合查询
    COMPARISON = "comparison"   # 对比查询
    TREND = "trend"             # 趋势查询
    CHART = "chart"             # 图表生成
    ANALYSIS = "analysis"       # 智能分析


class AggFunction(Enum):
    """聚合函数"""
    SUM = "SUM"
    AVG = "AVG"
    MAX = "MAX"
    MIN = "MIN"
    COUNT = "COUNT"


@dataclass
class QueryIntent:
    """查询意图"""
    query_type: QueryType
    time_range: Dict[str, str]  # {start: '2024-01-01', end: '2024-01-31'}
    tags: List[str]
    agg_function: Optional[AggFunction]
    chart_type: Optional[str]   # line, bar, pie
    conditions: Dict[str, Any]
    original_text: str


class SemanticParser:
    """语义解析器 - 将自然语言转换为查询意图"""
    
    # 时间关键词映射
    TIME_KEYWORDS = {
        '今天': {'type': 'single', 'days': 0},
        '昨天': {'type': 'single', 'days': -1},
        '前天': {'type': 'single', 'days': -2},
        '本周': {'type': 'range', 'days': -7, 'end': 0},
        '上周': {'type': 'range', 'days': -14, 'end': -7},
        '本月': {'type': 'range_month', 'offset': 0},
        '上月': {'type': 'range_month', 'offset': -1},
        '今年': {'type': 'range_year', 'offset': 0},
        '去年': {'type': 'range_year', 'offset': -1},
        '最近7天': {'type': 'range', 'days': -7, 'end': 0},
        '最近30天': {'type': 'range', 'days': -30, 'end': 0},
    }
    
    # 标签关键词映射
    TAG_KEYWORDS = {
        '餐饮美食': ['吃饭', '餐饮', '就餐', '餐费', '吃', '饭'],
        '交通出行': ['交通', '出行', '路费', '车费'],
        '居家日用': ['日用', '居家', '生活', '用品'],
        '医疗健康': ['医疗', '健康', '看病', '医药'],
        '休闲娱乐': ['娱乐', '休闲', '玩乐', '放松'],
        '水电缴费': ['水电', '缴费', '物业', '宽带'],
    }
    
    # 聚合关键词映射
    AGG_KEYWORDS = {
        AggFunction.SUM: ['总共', '一共', '合计', '总计', '多少钱', '总和', '累计'],
        AggFunction.AVG: ['平均', '均值', '大概', '一般'],
        AggFunction.MAX: ['最大', '最多', '最高', '最贵'],
        AggFunction.MIN: ['最小', '最少', '最低', '最便宜'],
        AggFunction.COUNT: ['多少次', '多少笔', '次数', '笔数'],
    }
    
    # 图表关键词映射
    CHART_KEYWORDS = {
        'line': ['趋势图', '走势图', '折线图', '变化趋势'],
        'bar': ['柱状图', '对比图', '条形图', '比较'],
        'pie': ['饼图', '占比', '比例', '分布'],
    }
    
    def parse(self, text: str) -> QueryIntent:
        """
        解析查询意图
        
        Args:
            text: 用户查询文本
            
        Returns:
            QueryIntent: 查询意图
        """
        text = text.strip()
        
        # 解析时间范围
        time_range = self._parse_time(text)
        
        # 解析标签
        tags = self._parse_tags(text)
        
        # 解析聚合函数
        agg_function = self._parse_agg_function(text)
        
        # 解析图表类型
        chart_type = self._parse_chart_type(text)
        
        # 确定查询类型
        query_type = self._determine_query_type(text, agg_function, chart_type)
        
        # 解析其他条件
        conditions = self._parse_conditions(text)
        
        return QueryIntent(
            query_type=query_type,
            time_range=time_range,
            tags=tags,
            agg_function=agg_function,
            chart_type=chart_type,
            conditions=conditions,
            original_text=text
        )
    
    def _parse_time(self, text: str) -> Dict[str, str]:
        """解析时间范围"""
        today = datetime.now()
        
        for keyword, config in self.TIME_KEYWORDS.items():
            if keyword in text:
                if config['type'] == 'single':
                    target_date = today + timedelta(days=config['days'])
                    date_str = target_date.strftime('%Y-%m-%d')
                    return {'start': date_str, 'end': date_str}
                
                elif config['type'] == 'range':
                    start_date = today + timedelta(days=config['days'])
                    end_date = today + timedelta(days=config.get('end', 0))
                    return {
                        'start': start_date.strftime('%Y-%m-%d'),
                        'end': end_date.strftime('%Y-%m-%d')
                    }
                
                elif config['type'] == 'range_month':
                    # 计算目标月份
                    offset = config['offset']
                    target_month = today.month + offset
                    target_year = today.year
                    while target_month < 1:
                        target_month += 12
                        target_year -= 1
                    while target_month > 12:
                        target_month -= 12
                        target_year += 1
                    
                    start_date = datetime(target_year, target_month, 1)
                    if target_month == 12:
                        end_date = datetime(target_year + 1, 1, 1) - timedelta(days=1)
                    else:
                        end_date = datetime(target_year, target_month + 1, 1) - timedelta(days=1)
                    
                    return {
                        'start': start_date.strftime('%Y-%m-%d'),
                        'end': end_date.strftime('%Y-%m-%d')
                    }
                
                elif config['type'] == 'range_year':
                    offset = config['offset']
                    target_year = today.year + offset
                    return {
                        'start': f"{target_year}-01-01",
                        'end': f"{target_year}-12-31"
                    }
        
        # 默认返回本月
        start_date = datetime(today.year, today.month, 1)
        if today.month == 12:
            end_date = datetime(today.year + 1, 1, 1) - timedelta(days=1)
        else:
            end_date = datetime(today.year, today.month + 1, 1) - timedelta(days=1)
        
        return {
            'start': start_date.strftime('%Y-%m-%d'),
            'end': end_date.strftime('%Y-%m-%d')
        }
    
    def _parse_tags(self, text: str) -> List[str]:
        """解析标签"""
        tags = []
        
        for tag, keywords in self.TAG_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    tags.append(tag)
                    break
        
        return tags
    
    def _parse_agg_function(self, text: str) -> Optional[AggFunction]:
        """解析聚合函数"""
        for func, keywords in self.AGG_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    return func
        
        return None
    
    def _parse_chart_type(self, text: str) -> Optional[str]:
        """解析图表类型"""
        for chart_type, keywords in self.CHART_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    return chart_type
        
        return None
    
    def _determine_query_type(self, text: str, agg_func: Optional[AggFunction],
                              chart_type: Optional[str]) -> QueryType:
        """确定查询类型"""
        if chart_type:
            return QueryType.CHART
        
        if '分析' in text or '建议' in text or '怎么样' in text:
            return QueryType.ANALYSIS
        
        if '比' in text or '对比' in text or '同期' in text:
            return QueryType.COMPARISON
        
        if '趋势' in text or '走势' in text or '变化' in text:
            return QueryType.TREND
        
        if agg_func:
            return QueryType.AGGREGATE
        
        if '列表' in text or '明细' in text or '记录' in text:
            return QueryType.LIST
        
        return QueryType.SINGLE
    
    def _parse_conditions(self, text: str) -> Dict[str, Any]:
        """解析其他条件"""
        conditions = {}
        
        # 解析金额范围
        amount_match = re.search(r'(\d+)元以上', text)
        if amount_match:
            conditions['amount_min'] = float(amount_match.group(1))
        
        amount_match = re.search(r'(\d+)元以下', text)
        if amount_match:
            conditions['amount_max'] = float(amount_match.group(1))
        
        return conditions


class StatisticsEngine:
    """统计运算引擎"""
    
    def calculate(self, data: List[Dict[str, Any]], 
                  agg_func: AggFunction, field: str = 'amount') -> float:
        """
        执行聚合计算
        
        Args:
            data: 数据列表
            agg_func: 聚合函数
            field: 计算字段
            
        Returns:
            float: 计算结果
        """
        values = [float(d.get(field, 0) or 0) for d in data if d.get(field)]
        
        if not values:
            return 0.0
        
        if agg_func == AggFunction.SUM:
            return sum(values)
        elif agg_func == AggFunction.AVG:
            return sum(values) / len(values)
        elif agg_func == AggFunction.MAX:
            return max(values)
        elif agg_func == AggFunction.MIN:
            return min(values)
        elif agg_func == AggFunction.COUNT:
            return len(values)
        
        return 0.0
    
    def calculate_mom(self, current: float, previous: float) -> Tuple[float, str]:
        """
        计算环比
        
        Args:
            current: 本期值
            previous: 上期值
            
        Returns:
            Tuple[float, str]: (变化率, 描述)
        """
        if previous == 0:
            return (0.0, "上期无数据")
        
        change_rate = (current - previous) / previous * 100
        direction = "增长" if change_rate > 0 else "下降"
        return (change_rate, f"{direction} {abs(change_rate):.1f}%")
    
    def calculate_yoy(self, current: float, same_period_last_year: float) -> Tuple[float, str]:
        """
        计算同比
        
        Args:
            current: 本期值
            same_period_last_year: 去年同期值
            
        Returns:
            Tuple[float, str]: (变化率, 描述)
        """
        return self.calculate_mom(current, same_period_last_year)
    
    def group_by(self, data: List[Dict[str, Any]], 
                 group_field: str, agg_func: AggFunction = AggFunction.SUM,
                 value_field: str = 'amount') -> Dict[str, float]:
        """
        分组聚合
        
        Args:
            data: 数据列表
            group_field: 分组字段
            agg_func: 聚合函数
            value_field: 值字段
            
        Returns:
            Dict[str, float]: 分组结果
        """
        groups = {}
        for item in data:
            key = str(item.get(group_field, '其他'))
            if key not in groups:
                groups[key] = []
            if item.get(value_field):
                groups[key].append(float(item[value_field]))
        
        result = {}
        for key, values in groups.items():
            if not values:
                result[key] = 0.0
            elif agg_func == AggFunction.SUM:
                result[key] = sum(values)
            elif agg_func == AggFunction.AVG:
                result[key] = sum(values) / len(values)
            elif agg_func == AggFunction.MAX:
                result[key] = max(values)
            elif agg_func == AggFunction.MIN:
                result[key] = min(values)
            elif agg_func == AggFunction.COUNT:
                result[key] = len(values)
        
        return result


class ChartGenerator:
    """图表生成器"""
    
    def generate_line_chart(self, data: Dict[str, float], 
                           title: str = "趋势图") -> str:
        """
        生成折线图（文本形式）
        
        Args:
            data: {日期: 数值} 字典
            title: 图表标题
            
        Returns:
            str: 文本图表
        """
        if not data:
            return "无数据"
        
        lines = [f"\n📈 {title}", "=" * 40]
        
        # 找出最大值用于缩放
        max_val = max(data.values()) if data else 1
        
        for label, value in sorted(data.items()):
            bar_length = int((value / max_val) * 20) if max_val > 0 else 0
            bar = "█" * bar_length
            lines.append(f"{label:10s} │{bar:20s} {value:,.2f}")
        
        lines.append("=" * 40)
        return "\n".join(lines)
    
    def generate_bar_chart(self, data: Dict[str, float], 
                          title: str = "对比图") -> str:
        """
        生成柱状图（文本形式）
        
        Args:
            data: {类别: 数值} 字典
            title: 图表标题
            
        Returns:
            str: 文本图表
        """
        if not data:
            return "无数据"
        
        lines = [f"\n📊 {title}", "=" * 40]
        
        max_val = max(data.values()) if data else 1
        max_label_len = max(len(str(k)) for k in data.keys())
        
        for label, value in sorted(data.items(), key=lambda x: x[1], reverse=True):
            bar_length = int((value / max_val) * 15) if max_val > 0 else 0
            bar = "█" * bar_length
            lines.append(f"{str(label):{max_label_len}s} │{bar:15s} {value:,.2f}")
        
        lines.append("=" * 40)
        return "\n".join(lines)
    
    def generate_pie_chart(self, data: Dict[str, float], 
                          title: str = "占比分布") -> str:
        """
        生成饼图（文本形式）
        
        Args:
            data: {类别: 数值} 字典
            title: 图表标题
            
        Returns:
            str: 文本图表
        """
        if not data:
            return "无数据"
        
        total = sum(data.values())
        if total == 0:
            return "总值为0，无法计算占比"
        
        lines = [f"\n🥧 {title}", "=" * 40]
        
        sorted_data = sorted(data.items(), key=lambda x: x[1], reverse=True)
        
        for label, value in sorted_data:
            percentage = (value / total) * 100
            lines.append(f"{str(label):15s} {percentage:5.1f}%  ({value:,.2f})")
        
        lines.append("-" * 40)
        lines.append(f"{'合计':15s} 100.0%  ({total:,.2f})")
        lines.append("=" * 40)
        
        return "\n".join(lines)


class AnalysisEngine:
    """智能分析引擎"""
    
    def analyze_spending(self, data: List[Dict[str, Any]], 
                        time_range: Dict[str, str]) -> str:
        """
        分析消费情况
        
        Args:
            data: 消费数据列表
            time_range: 时间范围
            
        Returns:
            str: 分析报告
        """
        if not data:
            return "该时间段内无数据"
        
        # 基础统计
        total = sum(float(d.get('amount', 0) or 0) for d in data)
        count = len(data)
        avg = total / count if count > 0 else 0
        max_record = max(data, key=lambda x: float(x.get('amount', 0) or 0))
        
        # 按标签分组
        tag_spending = {}
        for d in data:
            tag = d.get('tag', '其他')
            amount = float(d.get('amount', 0) or 0)
            tag_spending[tag] = tag_spending.get(tag, 0) + amount
        
        # 找出最大支出类别
        top_tag = max(tag_spending.items(), key=lambda x: x[1]) if tag_spending else ('', 0)
        top_tag_pct = (top_tag[1] / total * 100) if total > 0 else 0
        
        # 生成分析文本
        lines = [
            f"📊 消费分析报告（{time_range['start']} 至 {time_range['end']}）",
            "",
            f"💰 总支出：{total:,.2f} 元",
            f"📝 交易笔数：{count} 笔",
            f"📈 平均每笔：{avg:,.2f} 元",
            f"🔝 最大单笔：{float(max_record.get('amount', 0)):,.2f} 元（{max_record.get('tag', '')}）",
            "",
            "📋 支出构成：",
        ]
        
        for tag, amount in sorted(tag_spending.items(), key=lambda x: x[1], reverse=True):
            pct = (amount / total * 100) if total > 0 else 0
            lines.append(f"  • {tag}: {amount:,.2f} 元 ({pct:.1f}%)")
        
        lines.extend([
            "",
            f"💡 分析建议：",
            f"  • 最大支出类别为「{top_tag[0]}」，占总支出的 {top_tag_pct:.1f}%",
        ])
        
        if top_tag_pct > 50:
            lines.append(f"  • 「{top_tag[0]}」支出占比较高，建议适当控制")
        
        if avg > 200:
            lines.append(f"  • 平均每笔消费较高，可关注是否有大额非必要支出")
        
        return "\n".join(lines)
    
    def detect_anomalies(self, data: List[Dict[str, Any]]) -> List[str]:
        """
        检测异常消费
        
        Args:
            data: 消费数据列表
            
        Returns:
            List[str]: 异常提示列表
        """
        if len(data) < 5:
            return []
        
        anomalies = []
        amounts = [float(d.get('amount', 0) or 0) for d in data]
        avg = sum(amounts) / len(amounts)
        std = (sum((x - avg) ** 2 for x in amounts) / len(amounts)) ** 0.5
        
        for d in data:
            amount = float(d.get('amount', 0) or 0)
            if amount > avg + 3 * std:  # 3倍标准差
                anomalies.append(
                    f"{d.get('record_time', '')} 有一笔 {amount:,.2f} 元的消费，"
                    f"明显高于平均水平（{avg:,.2f} 元）"
                )
        
        return anomalies


class QueryEngine:
    """统一查询引擎入口"""
    
    def __init__(self):
        self.parser = SemanticParser()
        self.statistics = StatisticsEngine()
        self.chart_gen = ChartGenerator()
        self.analysis = AnalysisEngine()
    
    def parse_query(self, text: str) -> QueryIntent:
        """解析查询"""
        return self.parser.parse(text)
    
    def build_conditions(self, intent: QueryIntent) -> Dict[str, Any]:
        """构建查询条件"""
        conditions = {}
        
        # 时间范围
        if intent.time_range:
            conditions['record_time'] = (
                ('>=', intent.time_range['start']),
                ('<=', intent.time_range['end'])
            )
        
        # 标签
        if intent.tags:
            conditions['tag'] = intent.tags[0]  # 简化处理
        
        # 其他条件
        conditions.update(intent.conditions)
        
        return conditions
    
    def format_result(self, intent: QueryIntent, data: Any) -> str:
        """格式化查询结果"""
        if intent.query_type == QueryType.AGGREGATE and intent.agg_function:
            return f"查询结果：{float(data):,.2f} 元"
        
        elif intent.query_type == QueryType.CHART:
            return data  # 图表已格式化为文本
        
        elif intent.query_type == QueryType.ANALYSIS:
            return data
        
        elif intent.query_type == QueryType.LIST:
            if not data:
                return "未找到相关记录"
            
            lines = ["查询结果："]
            for item in data:
                lines.append(
                    f"  • {item.get('record_time', '')} "
                    f"{item.get('tag', '')} "
                    f"{float(item.get('amount', 0) or 0):,.2f}元"
                    f"{' - ' + item.get('note', '') if item.get('note') else ''}"
                )
            return "\n".join(lines)
        
        else:
            if isinstance(data, list):
                if not data:
                    return "未找到相关记录"
                total = sum(float(d.get('amount', 0) or 0) for d in data)
                return f"共 {len(data)} 条记录，总计 {total:,.2f} 元"
            return str(data)


# 单例
_engine = None

def get_query_engine() -> QueryEngine:
    """获取查询引擎实例"""
    global _engine
    if _engine is None:
        _engine = QueryEngine()
    return _engine


if __name__ == "__main__":
    engine = get_query_engine()
    
    # 测试查询解析
    test_queries = [
        "这个月吃饭花了多少钱",
        "上周交通支出明细",
        "生成月度消费趋势图",
        "分析我的消费习惯",
    ]
    
    for query in test_queries:
        intent = engine.parse_query(query)
        print(f"\n查询: {query}")
        print(f"类型: {intent.query_type.value}")
        print(f"时间: {intent.time_range}")
        print(f"标签: {intent.tags}")
        print(f"聚合: {intent.agg_function.value if intent.agg_function else None}")
        print(f"图表: {intent.chart_type}")
