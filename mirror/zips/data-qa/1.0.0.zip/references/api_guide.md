# 内部 API 使用指南

## 概述

本文档描述 Skill 内部模块之间的 API 调用规范。

## 数据库管理 API (database_manager.py)

### DatabaseManager 类

#### 初始化

```python
from scripts.database_manager import get_db_manager

db_mgr = get_db_manager()
```

#### 创建数据库

```python
success = db_mgr.create_database(
    db_name="personal_consumption",
    description="个人消费数据"
)
```

#### 创建数据表

```python
schema = {
    "id": "TEXT",
    "record_time": "TEXT",
    "amount": "REAL",
    "tag": "TEXT",
    "category": "TEXT",
    "merchant": "TEXT",
    "note": "TEXT",
    "source_type": "TEXT",
    "raw_data": "TEXT",
    "created_at": "TEXT",
    "updated_at": "TEXT"
}

success = db_mgr.create_table(
    db_name="personal_consumption",
    table_name="consumption",
    schema=schema,
    primary_key="id",
    unique_fields=["record_time", "amount", "tag"]
)
```

#### 插入数据

```python
result, message = db_mgr.insert_data(
    db_name="personal_consumption",
    table_name="consumption",
    data={
        "record_time": "2024-01-15",
        "amount": 35.0,
        "tag": "餐饮美食",
        "merchant": "肯德基"
    },
    check_duplicate=True
)

# result: True/False
# message: 主键ID 或 错误信息（如 DUPLICATE:xxx 表示重复）
```

#### 查询数据

```python
records = db_mgr.query_data(
    db_name="personal_consumption",
    table_name="consumption",
    conditions={
        "tag": "餐饮美食",
        "record_time": (">=", "2024-01-01")  # 范围查询
    },
    order_by="record_time DESC",
    limit=100
)
```

#### 聚合查询

```python
result = db_mgr.aggregate_data(
    db_name="personal_consumption",
    table_name="consumption",
    agg_func="SUM",
    field="amount",
    conditions={"tag": "餐饮美食"}
)
```

## 数据解析 API (data_parser.py)

### DataParser 类

#### 初始化

```python
from scripts.data_parser import get_parser

parser = get_parser()
```

#### 解析文字

```python
from scripts.data_parser import ParsedRecord

result: ParsedRecord = parser.parse_text("昨天吃饭花了35元")

# result 属性:
# - record_time: 日期
# - amount: 金额
# - tag: 一级标签
# - category: 二级分类
# - merchant: 商户
# - note: 备注
# - source_type: "text"
# - raw_data: 原始数据
```

#### 解析 OCR

```python
result: ParsedRecord = parser.parse_ocr(
    ocr_text="肯德基餐厅 金额：35元",
    image_type="receipt"
)
```

#### 解析 Excel

```python
records: List[ParsedRecord] = parser.parse_excel("/path/to/file.xlsx")
```

#### 解析 CSV

```python
records: List[ParsedRecord] = parser.parse_csv("/path/to/file.csv")
```

#### 转换为数据库记录

```python
db_record = parser.to_db_record(parsed_record)
# 返回: Dict[str, Any] 可直接入库
```

## 查询引擎 API (query_engine.py)

### QueryEngine 类

#### 初始化

```python
from scripts.query_engine import get_query_engine

engine = get_query_engine()
```

#### 解析查询

```python
from scripts.query_engine import QueryIntent

intent: QueryIntent = engine.parse_query("这个月吃饭花了多少钱")

# intent 属性:
# - query_type: 查询类型
# - time_range: 时间范围
# - tags: 标签列表
# - agg_function: 聚合函数
# - chart_type: 图表类型
# - conditions: 其他条件
```

#### 统计运算

```python
from scripts.query_engine import get_query_engine, AggFunction

engine = get_query_engine()

# 聚合计算
total = engine.statistics.calculate(
    data=records,
    agg_func=AggFunction.SUM,
    field="amount"
)

# 环比计算
change_rate, description = engine.statistics.calculate_mom(
    current=1000.0,
    previous=800.0
)
```

#### 生成图表

```python
# 折线图
chart = engine.chart_gen.generate_line_chart(
    data={"2024-01-01": 100, "2024-01-02": 150},
    title="日消费趋势"
)

# 柱状图
chart = engine.chart_gen.generate_bar_chart(
    data={"餐饮": 500, "交通": 300, "购物": 200},
    title="各类别消费对比"
)

# 饼图
chart = engine.chart_gen.generate_pie_chart(
    data={"餐饮": 500, "交通": 300, "购物": 200},
    title="消费占比"
)
```

#### 智能分析

```python
analysis = engine.analysis.analyze_spending(
    data=records,
    time_range={"start": "2024-01-01", "end": "2024-01-31"}
)
```

## 去重 API (deduplication.py)

### DeduplicationEngine 类

#### 初始化

```python
from scripts.deduplication import get_deduplication_engine

engine = get_deduplication_engine()
```

#### 检查重复

```python
from scripts.deduplication import DuplicateCheckResult

result: DuplicateCheckResult = engine.check_duplicate(
    new_data=new_record,
    existing_records=existing_records
)

# result 属性:
# - is_duplicate: 是否重复
# - duplicate_id: 重复记录ID
# - similarity: 相似度
# - existing_record: 重复记录详情
# - message: 提示信息
```

#### 批量检查

```python
results = engine.batch_check(
    new_records=new_records,
    existing_records=existing_records
)
# 返回: List[Tuple[新记录, 检查结果]]
```

#### 格式化警告

```python
warning_text = engine.format_duplicate_warning(result)
```

### DuplicateHandler 类

#### 处理插入

```python
from scripts.deduplication import get_duplicate_handler

handler = get_duplicate_handler()

should_insert, message = handler.process_insert(
    new_data=new_record,
    existing_records=existing_records,
    force_insert=False  # 是否强制插入
)
```

#### 批量处理

```python
to_insert, duplicates, messages = handler.process_batch_insert(
    new_records=new_records,
    existing_records=existing_records,
    auto_skip=True  # 自动跳过重复
)
```

## 使用示例

### 完整数据录入流程

```python
from scripts.data_parser import get_parser
from scripts.database_manager import get_db_manager
from scripts.deduplication import get_duplicate_handler

# 1. 解析用户输入
parser = get_parser()
parsed = parser.parse_text("昨天在肯德基吃了午饭，35元")
record = parser.to_db_record(parsed)

# 2. 检查重复
db_mgr = get_db_manager()
existing = db_mgr.query_data(
    db_name="personal_consumption",
    table_name="consumption",
    conditions={"record_time": record["record_time"]}
)

handler = get_duplicate_handler()
should_insert, message = handler.process_insert(record, existing)

if not should_insert:
    print(f"发现重复数据: {message}")
else:
    # 3. 插入数据
    success, result = db_mgr.insert_data(
        db_name="personal_consumption",
        table_name="consumption",
        data=record
    )
    if success:
        print(f"数据录入成功，ID: {result}")
```

### 完整数据查询流程

```python
from scripts.query_engine import get_query_engine
from scripts.database_manager import get_db_manager

# 1. 解析查询意图
engine = get_query_engine()
intent = engine.parse_query("这个月吃饭花了多少钱")

# 2. 构建查询条件
conditions = engine.build_conditions(intent)

# 3. 查询数据
db_mgr = get_db_manager()
records = db_mgr.query_data(
    db_name="personal_consumption",
    table_name="consumption",
    conditions=conditions
)

# 4. 执行统计
if intent.agg_function:
    result = engine.statistics.calculate(
        data=records,
        agg_func=intent.agg_function,
        field="amount"
    )
    print(f"查询结果: {result:.2f} 元")

# 5. 格式化输出
output = engine.format_result(intent, result)
print(output)
```

## 错误处理

所有 API 都遵循以下错误处理规范：

1. **返回值**: 成功返回数据，失败返回 None 或空列表
2. **异常捕获**: 内部捕获异常并打印错误信息
3. **错误类型**: 
   - `DUPLICATE:xxx` - 重复数据错误
   - `INSERT_ERROR:xxx` - 插入错误
   - 其他错误直接返回错误信息
