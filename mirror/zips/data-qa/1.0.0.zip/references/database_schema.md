# 数据库结构参考

## 概述

数据存储采用 SQLite 数据库，默认存储路径：`~/.workbuddy/data/data-qa/`

数据库设计原则：
- **物理隔离**：数据库文件与 Skill 代码完全分离
- **自动建库建表**：AI 根据数据内容自动决策数据库结构
- **唯一性保障**：强制主键 + 唯一性校验，杜绝重复数据

## 元数据库 (metadata.db)

用于存储数据库和表的结构信息。

### 表: databases

存储所有数据数据库的信息。

| 字段 | 类型 | 说明 |
|-----|------|------|
| id | INTEGER | 主键，自增 |
| db_name | TEXT | 数据库名称（唯一） |
| db_type | TEXT | 数据库类型（默认: personal_data） |
| description | TEXT | 数据库描述 |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |

### 表: tables

存储所有数据表的结构信息。

| 字段 | 类型 | 说明 |
|-----|------|------|
| id | INTEGER | 主键，自增 |
| db_name | TEXT | 所属数据库 |
| table_name | TEXT | 表名 |
| schema_json | TEXT | 表结构 JSON |
| primary_key | TEXT | 主键字段 |
| unique_fields | TEXT | 唯一字段 JSON 数组 |
| created_at | TIMESTAMP | 创建时间 |

## 业务数据库

### 命名规范

- 个人消费数据: `personal_consumption.db`
- 经营数据: `business_data.db`
- 业绩数据: `performance_data.db`

### 消费数据表 (consumption)

适用于个人消费记账场景。

| 字段 | 类型 | 说明 |
|-----|------|------|
| id | TEXT | 主键，MD5 生成 |
| record_time | TEXT | 记录日期 (YYYY-MM-DD) |
| amount | REAL | 金额 |
| tag | TEXT | 一级标签 |
| category | TEXT | 二级分类 |
| merchant | TEXT | 商户名称 |
| note | TEXT | 备注 |
| source_type | TEXT | 数据来源 (text/ocr/excel/csv) |
| raw_data | TEXT | 原始数据 JSON |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |

### 索引设计

```sql
-- 时间索引
CREATE INDEX idx_consumption_time ON consumption(record_time);

-- 标签索引
CREATE INDEX idx_consumption_tag ON consumption(tag);

-- 金额索引（用于范围查询）
CREATE INDEX idx_consumption_amount ON consumption(amount);
```

## 主键生成规则

主键根据以下核心字段生成 MD5 摘要：
1. 时间字段 (record_time)
2. 金额字段 (amount)
3. 标签字段 (tag)
4. 商户字段 (merchant)

取 MD5 前 16 位作为唯一标识。

## 唯一性校验规则

### 精确匹配（视为重复）
- 时间完全相同 AND
- 金额差值 < 0.01 AND
- 标签完全相同

### 模糊匹配（提示用户）
- 相似度 >= 85% 时提示可能重复

相似度计算权重：
- 时间匹配：30%
- 金额匹配：30%
- 标签匹配：20%
- 商户匹配：20%
