# 桌面整理工具 (Desktop Organizer)

## 简介

一个小巧实用的 Windows 桌面文件自动分类整理工具，基于 Python + tkinter 开发，无需安装额外依赖。

## 功能特性

- **自动扫描**：启动即扫描桌面，智能识别所有文件
- **8 大分类**：图片、文档、视频、音乐、压缩包、程序、代码、字体
- **整理预览**：执行前清晰展示每个文件的去向，确认后再操作
- **一键整理**：自动在桌面创建分类文件夹并移动文件
- **安全保留**：快捷方式（.lnk）和文件夹不会被移动
- **撤销恢复**：支持撤销最近 10 次整理操作

## 触发关键词

以下任意表述均可触发本工具：

- 整理桌面
- 桌面文件整理
- 桌面很乱
- 整理我的桌面
- 整理文件夹
- 桌面太乱了
- 文件太多了

## 使用方式

### 方式一：直接运行（推荐）

双击桌面「桌面整理工具」文件夹中的 **`启动.bat`** 即可运行。

### 方式二：命令行启动

```bash
python "E:\desktop\桌面整理工具\desktop_organizer.py"
```

### 方式三：通过 WorkBuddy 对话触发

在 WorkBuddy 中直接说"整理桌面"，AI 会帮你启动并引导操作。

## 工作流程

1. **启动** → 自动扫描桌面所有文件
2. **预览** → 左侧树形列表展示分类结果
3. **确认** → 点击「一键整理」，弹出确认对话框
4. **执行** → 文件自动移动到对应分类文件夹
5. **完成** → 可随时点击「撤销整理」恢复原位

## 文件分类规则

| 分类 | 文件扩展名 |
|------|-----------|
| 🖼️ 图片 | .jpg, .png, .gif, .bmp, .webp, .svg, .ico, .tiff, .raw, .heic |
| 📄 文档 | .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .txt, .md, .csv, .rtf |
| 🎬 视频 | .mp4, .avi, .mkv, .mov, .wmv, .flv, .webm, .rmvb |
| 🎵 音乐 | .mp3, .wav, .flac, .aac, .ogg, .wma, .m4a, .ape |
| 📦 压缩包 | .zip, .rar, .7z, .tar, .gz, .bz2, .iso |
| ⚙️ 程序 | .exe, .msi, .apk, .dmg, .bat, .cmd, .sh |
| 💻 代码 | .py, .js, .ts, .html, .css, .java, .cpp, .go, .rs, .json, .xml |
| 🔤 字体 | .ttf, .otf, .woff, .woff2 |

> 未匹配的文件归入「📂 其他」分类。

## 依赖说明

- Python 3.x 内置模块：`tkinter`, `shutil`, `pathlib`, `json`, `threading`
- 无需安装任何第三方依赖

## 数据存储

- 操作历史保存在：`C:\Users\Administrator\.desktop_organizer_history.json`
- 支持撤销最近 10 次整理操作

## 文件清单

```
桌面整理工具/
├── desktop_organizer.py  # 主程序
├── 启动.bat              # 一键启动脚本
└── SKILL.md             # 本文件
```
