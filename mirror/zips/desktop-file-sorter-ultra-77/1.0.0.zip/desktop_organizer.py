"""
桌面整理工具 - Desktop Organizer
一个小巧的桌面文件自动分类整理工具
"""

import os
import shutil
import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime
import threading

# ==================== 文件分类规则 ====================
FILE_CATEGORIES = {
    "🖼️ 图片": [
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp",
        ".svg", ".ico", ".tiff", ".tif", ".heic", ".raw"
    ],
    "📄 文档": [
        ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
        ".txt", ".md", ".csv", ".odt", ".ods", ".odp", ".rtf", ".wps"
    ],
    "🎬 视频": [
        ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm",
        ".m4v", ".rmvb", ".3gp", ".ts", ".m2ts"
    ],
    "🎵 音乐": [
        ".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma",
        ".m4a", ".ape", ".opus", ".mid", ".midi"
    ],
    "📦 压缩包": [
        ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2",
        ".xz", ".iso", ".cab", ".tgz"
    ],
    "⚙️ 程序": [
        ".exe", ".msi", ".apk", ".dmg", ".pkg", ".deb",
        ".rpm", ".appimage", ".bat", ".cmd", ".sh"
    ],
    "💻 代码": [
        ".py", ".js", ".ts", ".html", ".css", ".java", ".cpp",
        ".c", ".h", ".go", ".rs", ".php", ".rb", ".swift", ".kt",
        ".json", ".xml", ".yaml", ".yml", ".toml", ".ini", ".cfg"
    ],
    "🔤 字体": [
        ".ttf", ".otf", ".woff", ".woff2", ".eot", ".fon"
    ],
}

HISTORY_FILE = os.path.join(os.path.expanduser("~"), ".desktop_organizer_history.json")


# ==================== 核心逻辑 ====================
def get_desktop_path():
    """获取桌面路径"""
    return os.path.join(os.path.expanduser("~"), "Desktop")


def get_file_category(filename):
    """根据文件扩展名判断分类"""
    ext = Path(filename).suffix.lower()
    for category, extensions in FILE_CATEGORIES.items():
        if ext in extensions:
            return category
    return "📂 其他"


def scan_desktop(desktop_path):
    """扫描桌面文件，返回分类结果"""
    results = {}
    skipped = []

    if not os.path.exists(desktop_path):
        return results, skipped

    for item in os.listdir(desktop_path):
        full_path = os.path.join(desktop_path, item)
        # 跳过文件夹、快捷方式
        if os.path.isdir(full_path):
            skipped.append(item)
            continue
        # 跳过 .lnk 快捷方式
        if item.lower().endswith(".lnk"):
            skipped.append(item)
            continue

        category = get_file_category(item)
        if category not in results:
            results[category] = []
        results[category].append({
            "name": item,
            "path": full_path,
            "size": os.path.getsize(full_path),
            "modified": datetime.fromtimestamp(os.path.getmtime(full_path)).strftime("%Y-%m-%d %H:%M"),
        })

    return results, skipped


def do_organize(desktop_path, scan_results, progress_callback=None):
    """执行整理操作，返回操作记录"""
    history = []
    total = sum(len(files) for files in scan_results.values())
    done = 0

    for category, files in scan_results.items():
        # 清理分类名中的 emoji，用作文件夹名
        folder_name = category.split(" ", 1)[-1] if " " in category else category
        target_dir = os.path.join(desktop_path, folder_name)

        for file_info in files:
            src = file_info["path"]
            if not os.path.exists(src):
                done += 1
                continue

            os.makedirs(target_dir, exist_ok=True)
            dst = os.path.join(target_dir, file_info["name"])

            # 处理同名文件
            if os.path.exists(dst):
                base, ext = os.path.splitext(file_info["name"])
                timestamp = datetime.now().strftime("%H%M%S")
                dst = os.path.join(target_dir, f"{base}_{timestamp}{ext}")

            shutil.move(src, dst)
            history.append({"src": dst, "dst": src})  # 撤销时反向操作
            done += 1

            if progress_callback:
                progress_callback(done, total)

    # 保存历史记录
    save_history(history)
    return history


def save_history(history):
    """保存操作历史"""
    data = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "operations": history
    }
    try:
        all_history = []
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                all_history = json.load(f)
        all_history.insert(0, data)
        all_history = all_history[:10]  # 只保留最近10次
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(all_history, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def load_history():
    """加载操作历史"""
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def do_undo(operations):
    """撤销整理操作"""
    errors = []
    for op in operations:
        src, dst = op["src"], op["dst"]
        try:
            if os.path.exists(src):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.move(src, dst)
        except Exception as e:
            errors.append(f"{os.path.basename(src)}: {e}")
    return errors


def format_size(size_bytes):
    """格式化文件大小"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / 1024 / 1024:.1f} MB"
    else:
        return f"{size_bytes / 1024 / 1024 / 1024:.1f} GB"


# ==================== GUI 界面 ====================
class DesktopOrganizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🗂️ 桌面整理工具")
        self.root.geometry("800x580")
        self.root.resizable(True, True)
        self.root.minsize(700, 500)

        # 颜色主题
        self.colors = {
            "bg": "#F5F6FA",
            "card": "#FFFFFF",
            "primary": "#4A6CF7",
            "primary_hover": "#3A5CE5",
            "danger": "#FF4757",
            "success": "#2ED573",
            "text": "#2C3E50",
            "text_light": "#7F8C8D",
            "border": "#E8ECF0",
            "header_bg": "#4A6CF7",
        }

        self.desktop_path = get_desktop_path()
        self.scan_results = {}
        self.last_history = None

        self._setup_styles()
        self._build_ui()
        self._scan()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        c = self.colors

        style.configure("TFrame", background=c["bg"])
        style.configure("Card.TFrame", background=c["card"])
        style.configure("Header.TFrame", background=c["header_bg"])

        style.configure("TLabel",
                        background=c["bg"],
                        foreground=c["text"],
                        font=("Microsoft YaHei UI", 10))
        style.configure("Card.TLabel",
                        background=c["card"],
                        foreground=c["text"],
                        font=("Microsoft YaHei UI", 10))
        style.configure("Title.TLabel",
                        background=c["header_bg"],
                        foreground="white",
                        font=("Microsoft YaHei UI", 16, "bold"))
        style.configure("Subtitle.TLabel",
                        background=c["header_bg"],
                        foreground="#C8D6FF",
                        font=("Microsoft YaHei UI", 9))
        style.configure("CategoryName.TLabel",
                        background=c["card"],
                        foreground=c["text"],
                        font=("Microsoft YaHei UI", 11, "bold"))
        style.configure("Count.TLabel",
                        background=c["card"],
                        foreground=c["primary"],
                        font=("Microsoft YaHei UI", 9))
        style.configure("Light.TLabel",
                        background=c["bg"],
                        foreground=c["text_light"],
                        font=("Microsoft YaHei UI", 9))

        style.configure("Primary.TButton",
                        background=c["primary"],
                        foreground="white",
                        font=("Microsoft YaHei UI", 10, "bold"),
                        padding=(16, 8),
                        relief="flat",
                        borderwidth=0)
        style.map("Primary.TButton",
                  background=[("active", c["primary_hover"]), ("pressed", c["primary_hover"])])

        style.configure("Danger.TButton",
                        background=c["danger"],
                        foreground="white",
                        font=("Microsoft YaHei UI", 10),
                        padding=(12, 8),
                        relief="flat",
                        borderwidth=0)
        style.map("Danger.TButton",
                  background=[("active", "#E84050"), ("pressed", "#E84050")])

        style.configure("Secondary.TButton",
                        background=c["border"],
                        foreground=c["text"],
                        font=("Microsoft YaHei UI", 10),
                        padding=(12, 8),
                        relief="flat",
                        borderwidth=0)
        style.map("Secondary.TButton",
                  background=[("active", "#D5DAE0"), ("pressed", "#D5DAE0")])

        style.configure("Treeview",
                        background=c["card"],
                        foreground=c["text"],
                        fieldbackground=c["card"],
                        rowheight=26,
                        font=("Microsoft YaHei UI", 9))
        style.configure("Treeview.Heading",
                        background=c["border"],
                        foreground=c["text"],
                        font=("Microsoft YaHei UI", 9, "bold"),
                        relief="flat")
        style.map("Treeview",
                  background=[("selected", "#EEF2FF")],
                  foreground=[("selected", c["primary"])])

        style.configure("TProgressbar",
                        troughcolor=c["border"],
                        background=c["primary"],
                        thickness=6)

    def _build_ui(self):
        c = self.colors
        self.root.configure(bg=c["bg"])

        # ---- 顶部 Header ----
        header = ttk.Frame(self.root, style="Header.TFrame")
        header.pack(fill="x")

        header_inner = ttk.Frame(header, style="Header.TFrame")
        header_inner.pack(fill="x", padx=20, pady=12)

        ttk.Label(header_inner, text="🗂️ 桌面整理工具", style="Title.TLabel").pack(side="left")

        right_header = ttk.Frame(header_inner, style="Header.TFrame")
        right_header.pack(side="right", fill="y")

        self.path_var = tk.StringVar(value=self.desktop_path)
        ttk.Label(right_header,
                  textvariable=self.path_var,
                  style="Subtitle.TLabel").pack(anchor="e")

        btn_frame = ttk.Frame(header_inner, style="Header.TFrame")
        btn_frame.pack(side="right", padx=(0, 16))

        change_btn = tk.Button(btn_frame, text="📂 更改路径",
                               bg="#6B83F9", fg="white",
                               relief="flat", cursor="hand2",
                               font=("Microsoft YaHei UI", 9),
                               padx=8, pady=4,
                               command=self._change_path)
        change_btn.pack()

        # ---- 主体区域 ----
        main = ttk.Frame(self.root, style="TFrame")
        main.pack(fill="both", expand=True, padx=16, pady=12)

        # 左侧：分类预览
        left = ttk.Frame(main, style="TFrame")
        left.pack(side="left", fill="both", expand=True)

        # 分类标题行
        title_row = ttk.Frame(left, style="TFrame")
        title_row.pack(fill="x", pady=(0, 8))

        ttk.Label(title_row, text="📋 整理预览",
                  font=("Microsoft YaHei UI", 12, "bold"),
                  background=c["bg"], foreground=c["text"]).pack(side="left")

        self.file_count_label = ttk.Label(title_row, text="",
                                          style="Light.TLabel")
        self.file_count_label.pack(side="left", padx=(8, 0))

        # 树形列表
        tree_frame = ttk.Frame(left, style="Card.TFrame")
        tree_frame.pack(fill="both", expand=True)

        # 给树形框加圆角感觉
        tree_border = tk.Frame(tree_frame, bg=c["border"], bd=1, relief="flat")
        tree_border.pack(fill="both", expand=True, padx=1, pady=1)

        self.tree = ttk.Treeview(tree_border,
                                 columns=("size", "modified"),
                                 show="tree headings",
                                 selectmode="extended")
        self.tree.heading("#0", text="文件名")
        self.tree.heading("size", text="大小")
        self.tree.heading("modified", text="修改时间")
        self.tree.column("#0", width=300, minwidth=200)
        self.tree.column("size", width=80, anchor="center")
        self.tree.column("modified", width=130, anchor="center")

        scrollbar = ttk.Scrollbar(tree_border, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 右侧：操作面板
        right = ttk.Frame(main, style="TFrame", width=180)
        right.pack(side="right", fill="y", padx=(12, 0))
        right.pack_propagate(False)

        # 统计卡片
        stats_card = tk.Frame(right, bg=c["card"], bd=0, relief="flat",
                              highlightbackground=c["border"], highlightthickness=1)
        stats_card.pack(fill="x", pady=(0, 12))

        tk.Label(stats_card, text="📊 统计",
                 bg=c["card"], fg=c["text"],
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 4))

        self.stats_frame = tk.Frame(stats_card, bg=c["card"])
        self.stats_frame.pack(fill="x", padx=12, pady=(0, 10))

        # 操作按钮卡片
        btn_card = tk.Frame(right, bg=c["card"], bd=0, relief="flat",
                            highlightbackground=c["border"], highlightthickness=1)
        btn_card.pack(fill="x", pady=(0, 12))

        tk.Label(btn_card, text="⚡ 操作",
                 bg=c["card"], fg=c["text"],
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 8))

        self.organize_btn = tk.Button(btn_card,
                                      text="✨ 一键整理",
                                      bg=c["primary"], fg="white",
                                      relief="flat", cursor="hand2",
                                      font=("Microsoft YaHei UI", 10, "bold"),
                                      padx=8, pady=8,
                                      width=16,
                                      command=self._organize)
        self.organize_btn.pack(padx=12, pady=(0, 8))

        self.rescan_btn = tk.Button(btn_card,
                                    text="🔄 重新扫描",
                                    bg=c["border"], fg=c["text"],
                                    relief="flat", cursor="hand2",
                                    font=("Microsoft YaHei UI", 9),
                                    padx=8, pady=6,
                                    width=16,
                                    command=self._scan)
        self.rescan_btn.pack(padx=12, pady=(0, 8))

        self.undo_btn = tk.Button(btn_card,
                                  text="↩️ 撤销整理",
                                  bg="#FF6B7A", fg="white",
                                  relief="flat", cursor="hand2",
                                  font=("Microsoft YaHei UI", 9),
                                  padx=8, pady=6,
                                  width=16,
                                  state="disabled",
                                  command=self._undo)
        self.undo_btn.pack(padx=12, pady=(0, 12))

        # 进度条
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(right,
                                            variable=self.progress_var,
                                            maximum=100,
                                            style="TProgressbar")
        self.progress_bar.pack(fill="x", pady=(0, 4))
        self.progress_label = ttk.Label(right, text="", style="Light.TLabel")
        self.progress_label.pack()

        # ---- 底部状态栏 ----
        status_bar = tk.Frame(self.root, bg=c["border"], height=28)
        status_bar.pack(fill="x", side="bottom")
        status_bar.pack_propagate(False)

        self.status_var = tk.StringVar(value="就绪")
        tk.Label(status_bar,
                 textvariable=self.status_var,
                 bg=c["border"], fg=c["text_light"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=12, pady=6)

    def _scan(self):
        """扫描桌面"""
        self.status_var.set("正在扫描桌面...")
        self.organize_btn.config(state="disabled")

        def run():
            results, skipped = scan_desktop(self.desktop_path)
            self.scan_results = results
            self.root.after(0, lambda: self._update_tree(results, skipped))

        threading.Thread(target=run, daemon=True).start()

    def _update_tree(self, results, skipped):
        """更新树形视图"""
        # 清空
        for item in self.tree.get_children():
            self.tree.delete(item)

        total_files = 0
        total_size = 0

        for category, files in sorted(results.items()):
            cat_size = sum(f["size"] for f in files)
            total_size += cat_size
            total_files += len(files)

            parent = self.tree.insert("", "end",
                                      text=f"{category}  ({len(files)} 个文件)",
                                      values=(format_size(cat_size), ""),
                                      open=True,
                                      tags=("category",))

            for f in sorted(files, key=lambda x: x["name"].lower()):
                self.tree.insert(parent, "end",
                                 text=f"    {f['name']}",
                                 values=(format_size(f["size"]), f["modified"]),
                                 tags=("file",))

        self.tree.tag_configure("category", font=("Microsoft YaHei UI", 9, "bold"))
        self.tree.tag_configure("file", font=("Microsoft YaHei UI", 9))

        # 更新统计
        self.file_count_label.config(text=f"共 {total_files} 个文件")
        self._update_stats(results, total_files, total_size)

        # 跳过提示
        status = f"扫描完成：{total_files} 个文件，{len(skipped)} 个文件夹/快捷方式已跳过"
        self.status_var.set(status)

        if total_files > 0:
            self.organize_btn.config(state="normal")
        else:
            self.organize_btn.config(state="disabled")
            self.status_var.set("桌面很干净，没有需要整理的文件 ✨")

    def _update_stats(self, results, total_files, total_size):
        """更新统计面板"""
        for widget in self.stats_frame.winfo_children():
            widget.destroy()

        c = self.colors

        # 总文件数
        row = tk.Frame(self.stats_frame, bg=c["card"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text="文件总数", bg=c["card"], fg=c["text_light"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        tk.Label(row, text=str(total_files), bg=c["card"], fg=c["primary"],
                 font=("Microsoft YaHei UI", 9, "bold")).pack(side="right")

        # 总大小
        row2 = tk.Frame(self.stats_frame, bg=c["card"])
        row2.pack(fill="x", pady=2)
        tk.Label(row2, text="总大小", bg=c["card"], fg=c["text_light"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        tk.Label(row2, text=format_size(total_size), bg=c["card"], fg=c["primary"],
                 font=("Microsoft YaHei UI", 9, "bold")).pack(side="right")

        # 分类数
        row3 = tk.Frame(self.stats_frame, bg=c["card"])
        row3.pack(fill="x", pady=2)
        tk.Label(row3, text="分类数", bg=c["card"], fg=c["text_light"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        tk.Label(row3, text=str(len(results)), bg=c["card"], fg=c["primary"],
                 font=("Microsoft YaHei UI", 9, "bold")).pack(side="right")

    def _organize(self):
        """执行整理"""
        if not self.scan_results:
            messagebox.showinfo("提示", "没有需要整理的文件")
            return

        total = sum(len(f) for f in self.scan_results.values())
        msg = f"即将把桌面上的 {total} 个文件整理到对应分类文件夹中。\n\n整理后可以通过「撤销整理」恢复原位。\n\n确定要继续吗？"

        if not messagebox.askyesno("确认整理", msg, icon="question"):
            return

        self.organize_btn.config(state="disabled")
        self.rescan_btn.config(state="disabled")
        self.progress_var.set(0)
        self.status_var.set("整理中...")

        def run():
            def on_progress(done, total):
                pct = done / total * 100
                self.root.after(0, lambda: self.progress_var.set(pct))
                self.root.after(0, lambda: self.progress_label.config(
                    text=f"{done}/{total}"))

            history = do_organize(self.desktop_path, self.scan_results, on_progress)
            self.last_history = history
            self.root.after(0, self._on_organize_done)

        threading.Thread(target=run, daemon=True).start()

    def _on_organize_done(self):
        """整理完成回调"""
        self.progress_var.set(100)
        self.rescan_btn.config(state="normal")
        self.undo_btn.config(state="normal")
        self.status_var.set("✅ 整理完成！桌面已整洁")
        messagebox.showinfo("整理完成", "🎉 桌面整理完成！\n\n如需恢复，点击「撤销整理」按钮。")
        self._scan()

    def _undo(self):
        """撤销整理"""
        history = load_history()
        if not history:
            messagebox.showinfo("提示", "没有可撤销的操作记录")
            return

        last = history[0]
        time_str = last.get("time", "未知时间")
        ops = last.get("operations", [])

        if not messagebox.askyesno("确认撤销",
                                   f"将撤销 {time_str} 的整理操作（共 {len(ops)} 个文件）\n\n确定吗？"):
            return

        self.undo_btn.config(state="disabled")
        errors = do_undo(ops)

        if errors:
            messagebox.showwarning("部分撤销失败",
                                   f"大部分文件已恢复，以下文件撤销失败：\n\n" + "\n".join(errors[:5]))
        else:
            messagebox.showinfo("撤销完成", "✅ 已成功恢复所有文件到桌面！")

        self.status_var.set("撤销完成，重新扫描中...")
        self._scan()

    def _change_path(self):
        """更改整理路径"""
        new_path = filedialog.askdirectory(
            title="选择要整理的文件夹",
            initialdir=self.desktop_path
        )
        if new_path:
            self.desktop_path = new_path
            self.path_var.set(new_path)
            self._scan()


# ==================== 入口 ====================
def main():
    root = tk.Tk()
    root.configure(bg="#F5F6FA")

    # 设置 DPI 感知（Windows）
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    app = DesktopOrganizerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
