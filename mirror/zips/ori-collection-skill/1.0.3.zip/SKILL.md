---
name: ori-collection-skill
description: >
  腾讯健康组学平台 AI 模型公共应用 - ORI Collection (Nextflow) 导入与运行助手。
  ORI 是由腾讯生命科学实验室自主研发的蛋白质设计系统，包括蛋白质序列生成、结构与功能预测等系列模型。
  本 Skill 支持用户查看、导入并运行 ORI Collection 公共应用（及其子应用）。
  仅当用户明确要求运行、导入或查看 ORI Collection 相关应用时触发。
  触发词: ORI, ORI Collection, 蛋白质设计, 蛋白质生成, PGM, USM, ESMFold, 蛋白质折叠,
  蛋白质溶解性, 蛋白质热稳定性, 信号肽预测, USMFold, ORI-PGM, ORI-USM, xFold
---

# 腾讯健康-组学平台-ORI 蛋白序列生成预测模型

## 应用信息

| 字段            | 值                                                    |
| --------------- | ----------------------------------------------------- |
| **应用名称**    | ORI Collection (Nextflow)                             |
| **AppId**       | c798f9c0-cd28-446c-b8e4-3ec30ec1a7ff                  |
| **PublicAppId** | publicapp-nf-ori-collection                           |
| **应用类型**    | NEXTFLOW                                              |
| **分组类型**    | APP_COLLECTION（合集，包含多个子应用）                |
| **标签**        | AI 模型 (TagId: 3e497318-03ef-4483-838b-5c592d78d362) |

## 应用简介

ORI（Ontology Reinforcement Iteration）由腾讯生命科学实验室研发的自主迭代式 AI 蛋白质设计系统，可高效从头设计用户所需生物功能、性质的蛋白质。包含以下核心流程：

1. **蛋白质生成流程（ORI-PGM）** — 基于 ORI-PGM 模型的蛋白质生成
2. **蛋白质特性预测系列流程（ORI-USM）** — 溶解性/热稳定性/信号肽预测
3. **蛋白质结构预测系列流程（xFold）** — USMFold / ESMFold 蛋白质折叠预测

## 前置规则（触发本 Skill 时必须遵守）

1. **仅当用户明确要求运行、导入或查看 ORI Collection 相关应用时触发**，禁止主动推荐
2. **调用前必须查阅 `./references/omics-api-reference.md`** 获取参数定义，禁止凭记忆猜测
3. **所有命令通过 `./scripts/tccli_runner.sh` 执行**，禁止自行拼接 tccli 命令
4. **仅允许 omics 产品 API**，禁止调用 cvm/cos/iam 等其他产品
5. **缺少必选参数时禁止执行、禁止编造 ID**，必须先调用上游 API 获取或向用户追问
6. **所有相对路径以 SKILL.md 所在目录为基准**
7. **本 Skill 仅服务于 ORI Collection 应用**，不允许用户通过本 Skill 操作其他公共应用
8. **查询公共应用时必须按 AppTags 中的 TagName 过滤**，仅展示标签为「AI 模型」的应用，隐藏其他分类
9. **执行 `RunApplication` 前必须先向用户汇总运行任务信息（应用、项目、环境、参数模板、运行参数等）并获得明确确认**，禁止直接投递

---

## 允许的操作范围

| 操作                | API                            | 说明                     |
| ------------------- | ------------------------------ | ------------------------ |
| 查询公共应用/子应用 | **DescribePublicApplications** | 查询应用信息或子应用列表 |
| 导入应用到项目      | **ImportCommonApplication**    | 将应用导入项目           |
| 运行应用            | **RunApplication**             | 投递任务                 |
| 查询项目列表        | **DescribeProjects**           | 获取用户项目供选择       |
| 查询环境列表        | **DescribeEnvironments**       | 获取可用环境             |
| 查询项目应用        | **DescribeApplications**       | 检查应用是否已导入       |
| 查询参数模板        | **DescribeInputTemplates**     | 获取运行参数模板列表     |
| 获取模板内容        | **GetInputTemplateFile**       | 获取参数模板 JSON        |

---

## 调用流程

**本应用是合集类型（APP_COLLECTION）**，必须先引导用户选择子应用，再进行导入和运行。

### 完整流程（触发后按顺序执行）

#### 第 1 步：查询子应用列表

1. 调用 `DescribePublicApplications`，传 `--ParentAppId "c798f9c0-cd28-446c-b8e4-3ec30ec1a7ff"`
2. **过滤** — 仅保留 AppTags 中 TagName === "AI 模型" 的应用
3. **展示列表** — 以编号+表格形式展示子应用，供用户选择：
   ```
   ORI Collection 包含以下子应用，请选择您需要使用的：
   ① <子应用名称1> — <简要描述>
   ② <子应用名称2> — <简要描述>
   ...
   ```
4. **等待用户确认** — 用户选择具体子应用后，进入第 2 步

#### 第 2 步：确认导入

用户确认子应用后，询问：

```
您选择了「<子应用名称>」，需要将它导入到项目中进行使用吗？
```

- 用户确认 → 进入第 3 步
- 用户拒绝 → 结束流程

#### 第 3 步：导入应用到项目

1. **查询项目列表** — `DescribeProjects`，若多个项目则让用户选择
2. **检查是否已导入** — `DescribeApplications`（传入 ProjectId），对项目中的现有应用做两层判定：
   - **严格同名（优先级最高）** — 名称与目标子应用名**完全相等**（例如子应用名 `ORI-PGM`，项目中存在应用名恰好为 `ORI-PGM` 的应用）
   - **相似/模糊匹配** — 名称**包含**目标子应用名（例如 `ORI-PGM_test_1`、`my_ORI-PGM_v2`）
3. **若存在严格同名的应用** — 由于 `ImportCommonApplication` 要求应用名在项目内唯一，**禁止直接再次导入**。必须向用户确认后续行为：

   ```
   项目中已存在同名应用「<同名应用名称>」（<ApplicationId>），无法以相同名称再次导入。请选择：
   A. 使用已有应用 — 直接复用该应用运行
   B. 重命名后导入 — 我以新名称导入一份新的应用副本（请提供新名称，或让我建议一个）
   C. 取消导入 — 结束本次流程
   ```

   - 用户选择 A → 记录该应用的 ApplicationId，跳转第 4 步
   - 用户选择 B → 引导用户提供新名称（如未提供，可建议形如 `<原名>_v2`、`<原名>_<日期>` 的候选，待用户确认后使用），再走下方导入流程
   - 用户选择 C → 终止流程
4. **若仅存在相似但非同名的应用**（不存在严格同名项）— 向用户列出这些相关应用，并提供选择：

   ```
   项目中已存在以下与该公共应用相关的应用（非同名）：
   ① <应用名称1> (app-xxx1)
   ② <应用名称2> (app-xxx2)
   请选择：
   A. 使用已有应用 — 选择上方某个应用直接运行
   B. 以默认名称导入 — 按官方名称导入一份新副本
   C. 自定义名称导入 — 由您提供新名称再导入
   ```

   - 用户选择 A → 记录其 ApplicationId，跳转第 4 步
   - 用户选择 B / C → 继续下方导入流程（B 使用默认名；C 使用用户提供的新名称）
5. **若不存在任何匹配应用** — 直接进入下方导入流程
6. **查询公共应用详情** — 获取选定子应用的 `CommonAppUuid`
7. **导入应用** — `ImportCommonApplication`：
   - `--CommonAppUuid` — 子应用的 UUID
   - `--CommonAppNewName` — 用户自定义名称（**若项目中已有严格同名应用，则此字段必须为用户确认的新名称**）
   - `--ProjectId` — 用户选择的项目 ID
   - `--Type` — `NEXTFLOW`
   - `--NextflowVersion` — 通过查询获取支持的版本
8. **记录 ApplicationId** — 导入成功后获取的应用 ID，供后续运行使用

#### 第 4 步：运行应用

导入成功（或用户选择使用已有应用）后，进入运行准备流程：

1. **查询环境** — `DescribeEnvironments`，若多个可用环境则让用户选择
2. **获取参数模板列表** — `DescribeInputTemplates`（**必须同时传入 ProjectId 和 ApplicationId**，即应用所在项目的 ID 与应用 ID）→ 获取全部模板
3. **展示模板列表，由用户选择** — **禁止自行选择模板**，必须向用户展示所有可用模板，让用户决定：
   ```
   该应用有以下运行参数模板，请选择您要使用的：
   ① <模板名称1> — <描述>
   ② <模板名称2> — <描述>
   ...
   ```
4. **获取模板内容** — 用户选择后，调用 `GetInputTemplateFile`（**必须同时传入 ProjectId 和用户选择的 InputTemplateId**）→ 获取参数 JSON
5. **确认参数** — 向用户展示参数模板内容，询问是否需要修改
6. **编码输入** — 通过 `bash ./scripts/encode_input.sh '<参数JSON>'` 编码为 InputBase64
7. **执行前最终确认** — 向用户汇总本次运行的完整信息，等待用户明确确认后再投递：

   ```
   即将投递以下任务，请确认：

     • 应用：<子应用名称>（<ApplicationId>）
     • 项目：<项目名>（<ProjectId>）
     • 环境：<环境名>（<EnvironmentId>）
     • 参数模板：<模板名>（<InputTemplateId>）
     • 运行参数（摘要）：<关键参数 JSON 片段>
     • 运行名称：<Name>

   确认无误请回复「确认 / 继续」；如需调整，请告诉我要改什么。
   ```

   - 用户确认 → 进入下一步投递
   - 用户要求修改 → 回到对应步骤调整（换环境 / 换模板 / 改参数），再次确认
   - 用户拒绝 → 终止流程，不执行投递

8. **投递任务** — 查阅 `omics-api-reference.md`，通过 `tccli_runner.sh` 执行 `RunApplication`
9. **返回结果** — 提示用户：
   ```
   ✅ 任务已投递！批次 ID: run-xxx
   ⏱️ 组学分析通常需要 30 分钟到数小时。你可以随时对我说：
     • "查看 run-xxx 状态" — 查询最新进度
     • "run-xxx 跑完了吗" — 快速检查是否完成
     • "下载 run-xxx 日志" — 获取执行日志
   ```

---

## 查询公共应用时的过滤规则

调用 `DescribePublicApplications` 后，**必须**对返回结果进行过滤：

```
对返回的 Applications 列表中的每个应用：
  检查 AppTags 数组中是否存在 TagName === "AI 模型"
  如果不存在该标签 → 从结果中移除，不展示给用户
```

**禁止**向用户展示非「AI 模型」分类的公共应用。

---

## 参数模板（动态获取）

**禁止使用硬编码的参数列表。** 参数信息必须通过以下方式动态获取，确保始终与平台最新数据一致。

### 获取方式一：从公共应用文档中提取（推荐，导入前使用）

1. 调用 `DescribePublicApplications` 查询本应用（或子应用）
2. 从返回结果的 `Documentation` 字段中提取「参数说明」章节
3. 将提取到的参数表格展示给用户

```
DescribePublicApplications 返回 → Applications[].Documentation → 解析 Markdown → 提取参数表格
```

### 获取方式二：从运行参数模板中提取（导入后使用）

应用导入到项目后，可通过参数模板 API 获取实际可运行的参数：

1. 调用 `DescribeInputTemplates`（传入 ProjectId 和 ApplicationId）→ 获取模板列表
2. 调用 `GetInputTemplateFile`（传入 ProjectId 和 InputTemplateId）→ 获取模板 JSON 内容
3. 解析模板内容，展示各参数的键名、默认值

```
DescribeInputTemplates → InputTemplates[] → GetInputTemplateFile → Content(JSON) → 解析展示
```

### 使用优先级

| 场景                       | 获取方式 | 说明                    |
| -------------------------- | -------- | ----------------------- |
| 用户询问应用参数（导入前） | 方式一   | 从 Documentation 提取   |
| 用户准备运行应用（导入后） | 方式二   | 从参数模板获取实际 JSON |
| 用户需要参数示例           | 方式二   | 模板中包含默认值和示例  |

---

## 计算资源说明

本应用支持 GPU 资源（T4 及以上），可通过 config 指定：

- `process.resourceLabels = ["gpuType":"GPU型号", "gpuCount": "GPU数量"]`

---

## 任务状态说明

> 投递任务后若用户询问进度/状态，**必须**按照 `./references/run-group-status-mapping.md` 中的规则解读和展示批次状态。本 Skill 不重复定义状态枚举映射。

---

## Resources

| 文档/脚本        | 路径                                  | 说明                   |
| ---------------- | ------------------------------------- | ---------------------- |
| **API 参数参考** | `./references/omics-api-reference.md` | **每次调用前必须查阅** |
| **批次状态映射** | `./references/run-group-status-mapping.md` | DescribeRunGroups 结果解读 |
| **错误处理指南** | `./references/error-handling.md`      | API 返回错误时查阅     |
| **任务生命周期** | `./references/task-lifecycle.md`      | 需了解状态机时         |
| **命令执行器**   | `./scripts/tccli_runner.sh`           | 所有 API 调用的入口    |
| **输入编码**     | `./scripts/encode_input.sh`           | 编码输入参数           |
