# Constraints

## preservation_manifest

```yaml
required_objects:
  business_decisions_count: 141
  fatal_constraints_count: 33
  non_fatal_constraints_count: 151
  use_cases_count: 35
  semantic_locks_count: 12
  preconditions_count: 4
  evidence_quality_rules_count: 2
  traceback_scenarios_count: 5

```
