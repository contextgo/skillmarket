# 公司内部框架说明配置指南

本目录用于存放贵公司的内部框架使用文档，使 AI 在进行技术方案设计和代码开发时，能优先参考公司内部规范，而非通用框架文档。

---

## 为什么需要配置

通用框架（Spring MVC、Dubbo、Redis 等）的使用方式往往与公司内部经过封装的版本存在差异。例如：

- 公司内部 RPC 框架对 Dubbo 进行了二次封装，注解不同
- 公司 Redis 客户端统一封装了资源获取/释放逻辑
- 公司配置平台有特定的 API 和刷新机制

未配置公司说明时，AI 将使用通用框架文档，可能产生不符合公司规范的代码。

---

## 配置步骤

### 步骤 1：准备文档文件

将公司框架使用说明（Markdown 格式）放入本目录 `references/company-frameworks/`。

**建议文档结构：**

```markdown
# [框架名称] 使用说明

## 快速参考

### 核心注解/API
...

### 典型使用示例
...

### 常见陷阱与禁止行为
...

### 资源管理规范
...
```

### 步骤 2：填写 `index.yaml`

编辑 `references/company-frameworks/index.yaml`：

```yaml
frameworks:
  - name: "公司内部RPC框架 XxxRPC"
    file: "references/company-frameworks/xxx-rpc-guide.md"
    trigger_keywords:
      - "@XxxService"
      - "@XxxReference"
      - "XxxRpcClient"
      - "XxxStub"

  - name: "公司内部KV存储 XxxKV"
    file: "references/company-frameworks/xxx-kv-guide.md"
    trigger_keywords:
      - "XxxKvClient"
      - "XxxKvTemplate"
      - "kvGet"
      - "kvSet"

  - name: "公司内部配置平台 XxxConfig"
    file: "references/company-frameworks/xxx-config-guide.md"
    trigger_keywords:
      - "@XxxConfigValue"
      - "XxxConfigClient"
      - "refreshConfig"

  - name: "公司内部对象存储 XxxOSS"
    file: "references/company-frameworks/xxx-oss-guide.md"
    trigger_keywords:
      - "XxxOssClient"
      - "ossUpload"
      - "ossDownload"
```

### 步骤 3：验证配置

配置完成后，在 AI 对话中说：

```
请检查 references/company-frameworks/index.yaml 是否已正确配置
```

AI 将读取 `index.yaml` 并列出已识别的框架及触发关键词。

---

## AI 的加载行为

在阶段三（技术方案生成）和阶段五（执行开发）开始前，AI 将：

1. 读取 `references/company-frameworks/index.yaml`
2. 扫描当前技术方案/需求中是否出现任一 `trigger_keywords`
3. 若命中：**优先读取公司说明文档**，再参考通用框架文档（通用文档作为补充）
4. 若未命中：直接读取通用框架文档

**优先级**：公司说明 > 通用框架说明 > AI 模型推断

---

## 注意事项

1. `file` 路径相对于 skill 根目录，例如 `references/company-frameworks/xxx.md`
2. 若文档文件不存在，AI 将跳过该条目并给出警告
3. `trigger_keywords` 支持精确字符串匹配（区分大小写）
4. 一个文档可对应多个关键词，一个关键词也可出现在多个文档中
5. 公司文档请勿包含敏感信息（密钥、内网地址等）

---

## 示例：常见公司框架类型

| 框架类型 | 触发关键词示例 |
|---------|--------------|
| 内部 RPC 框架 | `@InternalService`, `@InternalRef`, `InternalClient` |
| 内部 KV 存储 | `KvClient`, `kvGet`, `kvSet`, `kvDel` |
| 内部消息队列 | `MsgPublisher`, `@MsgConsumer`, `sendMsg` |
| 内部配置平台 | `@ConfigValue`, `ConfigManager`, `refreshConfig` |
| 内部对象存储 | `OssClient`, `ossUpload`, `getOssUrl` |
| 内部监控上报 | `Monitor.report`, `InternalMonitor`, `MetricClient` |
| 内部权限框架 | `@AuthCheck`, `PermissionService`, `hasPermission` |

