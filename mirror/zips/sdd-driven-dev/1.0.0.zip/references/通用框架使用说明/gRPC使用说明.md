# gRPC 使用说明

## ⚠️ proto Field Number 规则（RPC 合约核心约束，必读）

> Protocol Buffers 序列化依赖 field number，而非字段名。违反以下规则将导致数据解析错误、服务不可用。

### 规则一：field number 不可删除、不可修改、不可复用

```protobuf
// ❌ 禁止：删除字段（即使字段废弃，也只能注释/保留，不可删除 field number）
message UserResponse {
    int64 user_id = 1;
    // string user_name = 2;  ← 不可直接删除，需用 reserved 保留
    int32 status = 3;
}

// ✅ 正确：废弃字段时使用 reserved
message UserResponse {
    reserved 2;               // 保留 field number 2，防止复用
    reserved "user_name";     // 保留字段名，防止误用
    int64 user_id = 1;
    int32 status = 3;
}
```

### 规则二：新增字段必须使用新的递增 field number

```protobuf
// ✅ 正确：新增字段追加到末尾，field number 递增
message UserResponse {
    int64 user_id = 1;    // 原有，不动
    int32 status = 3;     // 原有，不动（2 已 reserved）
    string email = 4;     // 新增，使用 max(现有field_number)+1
    int32 age = 5;        // 新增
}
```

### 规则三：不可修改字段类型（不兼容类型互转）

```protobuf
// ❌ 禁止：将 int32 改为 string（类型不兼容）
int32 status = 3;    // 原有
// string status = 3;  ← 不得修改类型

// ✅ 允许：部分兼容类型转换（谨慎使用）
// int32 <-> int64 在 Proto3 中可以兼容（因为 wire type 相同）
// 但仍建议新增字段，不修改存量字段
```

### 规则四：存量字段语义不可修改

```protobuf
// ❌ 禁止：复用 field number 表达不同语义
// 原来 status = 3 表示用户状态（1=正常 2=禁用）
// 不得修改为 3 = type（用户类型）

// ✅ 正确：保留原字段，新增字段
int32 status = 3;     // 保留原语义
int32 user_type = 6;  // 新增字段表达新语义
```

---

## 快速参考

### proto 文件规范

```protobuf
syntax = "proto3";

package com.example.user;

option java_package = "com.example.user.proto";
option java_outer_classname = "UserProto";
option java_multiple_files = true;

// 消息定义（所有字段有默认值，proto3 无 required）
message GetUserRequest {
    int64 user_id = 1;
    string trace_id = 2;
}

message GetUserResponse {
    int64 user_id = 1;
    string user_name = 2;
    int32 status = 3;
    repeated string tags = 4;   // 列表类型
    map<string, string> extra = 5; // 字典类型
}

// 服务定义
service UserService {
    rpc GetUser(GetUserRequest) returns (GetUserResponse);
    rpc ListUsers(ListUsersRequest) returns (stream GetUserResponse);  // 服务端流式
    rpc BatchCreate(stream CreateUserRequest) returns (CreateUserResponse); // 客户端流式
}
```

---

## 代码生成（Maven）

```xml
<!-- pom.xml -->
<dependencies>
    <dependency>
        <groupId>io.grpc</groupId>
        <artifactId>grpc-netty-shaded</artifactId>
        <version>1.58.0</version>
    </dependency>
    <dependency>
        <groupId>io.grpc</groupId>
        <artifactId>grpc-protobuf</artifactId>
        <version>1.58.0</version>
    </dependency>
    <dependency>
        <groupId>io.grpc</groupId>
        <artifactId>grpc-stub</artifactId>
        <version>1.58.0</version>
    </dependency>
</dependencies>

<build>
    <extensions>
        <extension>
            <groupId>kr.motd.maven</groupId>
            <artifactId>os-maven-plugin</artifactId>
        </extension>
    </extensions>
    <plugins>
        <plugin>
            <groupId>org.xolstice.maven.plugins</groupId>
            <artifactId>protobuf-maven-plugin</artifactId>
            <configuration>
                <protocArtifact>com.google.protobuf:protoc:3.24.0:exe:${os.detected.classifier}</protocArtifact>
                <pluginId>grpc-java</pluginId>
                <pluginArtifact>io.grpc:protoc-gen-grpc-java:1.58.0:exe:${os.detected.classifier}</pluginArtifact>
            </configuration>
        </plugin>
    </plugins>
</build>
```

---

## 服务实现（Spring Boot + grpc-spring-boot-starter）

```java
// 服务端实现
@GrpcService
public class UserServiceGrpcImpl extends UserServiceGrpc.UserServiceImplBase {

    private static final Logger log = LoggerFactory.getLogger(UserServiceGrpcImpl.class);

    @Autowired
    private UserDomainService userDomainService;

    @Override
    public void getUser(GetUserRequest request, StreamObserver<GetUserResponse> responseObserver) {
        try {
            UserDTO user = userDomainService.getById(request.getUserId());
            GetUserResponse response = GetUserResponse.newBuilder()
                    .setUserId(user.getUserId())
                    .setUserName(user.getUserName())
                    .setStatus(user.getStatus())
                    .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        } catch (Exception e) {
            log.error("gRPC getUser 失败: userId={}", request.getUserId(), e);
            responseObserver.onError(
                Status.INTERNAL.withDescription("服务内部错误").asRuntimeException()
            );
        }
    }
}

// 客户端调用
@Component
public class UserGrpcClient {

    @GrpcClient("user-service")  // 对应 application.yml 中的服务名
    private UserServiceGrpc.UserServiceBlockingStub userServiceStub;

    public GetUserResponse getUser(long userId) {
        GetUserRequest request = GetUserRequest.newBuilder()
                .setUserId(userId)
                .build();
        try {
            return userServiceStub
                .withDeadlineAfter(3, TimeUnit.SECONDS)  // 必须设置超时
                .getUser(request);
        } catch (StatusRuntimeException e) {
            log.error("gRPC 调用失败: status={}", e.getStatus(), e);
            throw new ServiceException("用户服务暂时不可用");
        }
    }
}
```

---

## 拦截器

```java
// 服务端拦截器（如认证）
public class AuthServerInterceptor implements ServerInterceptor {

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call,
            Metadata headers,
            ServerCallHandler<ReqT, RespT> next) {
        String token = headers.get(Metadata.Key.of("authorization", Metadata.ASCII_STRING_MARSHALLER));
        if (!isValid(token)) {
            call.close(Status.UNAUTHENTICATED.withDescription("无效 token"), new Metadata());
            return new ServerCall.Listener<>() {};
        }
        return next.startCall(call, headers);
    }
}

// 客户端拦截器（如链路追踪）
public class TraceClientInterceptor implements ClientInterceptor {

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(
            MethodDescriptor<ReqT, RespT> method,
            CallOptions callOptions,
            Channel next) {
        return new ForwardingClientCall.SimpleForwardingClientCall<>(next.newCall(method, callOptions)) {
            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                headers.put(Metadata.Key.of("trace-id", Metadata.ASCII_STRING_MARSHALLER), generateTraceId());
                super.start(responseListener, headers);
            }
        };
    }
}
```

---

## gRPC Status Code 速查

| Status | 含义 | 适用场景 |
|--------|------|---------|
| `OK` | 成功 | |
| `INVALID_ARGUMENT` | 参数非法 | 参数校验失败 |
| `NOT_FOUND` | 资源不存在 | 查询不存在的资源 |
| `ALREADY_EXISTS` | 资源已存在 | 重复创建 |
| `PERMISSION_DENIED` | 权限不足 | 无权操作 |
| `UNAUTHENTICATED` | 未认证 | 缺少或无效 token |
| `RESOURCE_EXHAUSTED` | 资源耗尽 | 限流 |
| `UNAVAILABLE` | 服务不可用 | 可重试 |
| `INTERNAL` | 内部错误 | 未知服务端错误 |
| `DEADLINE_EXCEEDED` | 超时 | 请求超过 deadline |

---

## 常见陷阱与禁止行为

1. **禁止删除或复用 field number**，必须用 `reserved` 保留已废弃的编号和字段名
2. **禁止不设置 Deadline**（超时），所有客户端调用必须 `.withDeadlineAfter()`
3. **禁止在 `onError` 后再调用 `onNext` 或 `onCompleted`**
4. **流式调用必须处理背压**，避免客户端/服务端队列溢出
5. **proto3 所有字段有默认值（0/""）**，不能用 `null` 判断字段是否存在，需用 `hasField()`（仅 proto3 with `optional` 关键字支持）
6. **禁止在 proto 文件中嵌套过深**，建议最多 3 层嵌套，复杂结构拆分为独立 message

