# MyBatis-Plus 使用说明

## 快速参考

### 核心注解

| 注解 | 作用 | 示例 |
|------|------|------|
| `@TableName` | 映射表名 | `@TableName("user")` |
| `@TableId` | 主键标识 | `@TableId(type = IdType.AUTO)` |
| `@TableField` | 字段映射 | `@TableField("user_name")` |
| `@TableLogic` | 逻辑删除 | `@TableLogic` |
| `@Version` | 乐观锁 | `@Version` |
| `@TableField(exist = false)` | 非数据库字段 | 排除字段映射 |

### IdType 选项

| 类型 | 说明 |
|------|------|
| `AUTO` | 数据库自增 |
| `ASSIGN_ID` | 雪花算法（默认，Long/String） |
| `ASSIGN_UUID` | UUID |
| `INPUT` | 手动赋值 |

---

## Entity 定义

```java
@Data
@TableName("user")
public class UserDO {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("user_name")
    private String userName;

    private String email;

    private Integer status;

    @Version
    private Integer version;  // 乐观锁字段

    @TableLogic
    private Integer deleted;  // 逻辑删除：0正常 1删除

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
```

---

## Mapper 定义

```java
@Mapper
public interface UserMapper extends BaseMapper<UserDO> {
    // 继承 BaseMapper 即获得：insert/deleteById/updateById/selectById
    // selectList/selectPage/selectCount 等基础能力

    // 自定义复杂 SQL
    @Select("SELECT * FROM user WHERE status = #{status} AND deleted = 0")
    List<UserDO> selectByStatus(@Param("status") Integer status);
}
```

---

## 条件构造器（LambdaQueryWrapper）

### 基本用法

```java
// 等于
LambdaQueryWrapper<UserDO> wrapper = new LambdaQueryWrapper<UserDO>()
    .eq(UserDO::getStatus, 1)
    .eq(UserDO::getDeleted, 0);

// 多条件
LambdaQueryWrapper<UserDO> wrapper = new LambdaQueryWrapper<UserDO>()
    .eq(UserDO::getStatus, 1)
    .like(UserDO::getUserName, keyword)
    .between(UserDO::getCreateTime, startTime, endTime)
    .orderByDesc(UserDO::getCreateTime);

// 条件为空时不加该条件（推荐）
LambdaQueryWrapper<UserDO> wrapper = new LambdaQueryWrapper<UserDO>()
    .eq(StringUtils.isNotBlank(keyword), UserDO::getUserName, keyword)
    .eq(status != null, UserDO::getStatus, status);
```

### 常用方法速查

| 方法 | SQL | 说明 |
|------|-----|------|
| `eq(col, val)` | `col = val` | 等于 |
| `ne(col, val)` | `col != val` | 不等于 |
| `gt(col, val)` | `col > val` | 大于 |
| `ge(col, val)` | `col >= val` | 大于等于 |
| `lt(col, val)` | `col < val` | 小于 |
| `le(col, val)` | `col <= val` | 小于等于 |
| `like(col, val)` | `col LIKE %val%` | 模糊查询 |
| `likeRight(col, val)` | `col LIKE val%` | 前缀匹配（可走索引） |
| `in(col, list)` | `col IN (...)` | in 查询 |
| `between(col, v1, v2)` | `col BETWEEN v1 AND v2` | 区间查询 |
| `isNull(col)` | `col IS NULL` | 为空 |
| `isNotNull(col)` | `col IS NOT NULL` | 不为空 |
| `orderByDesc(col)` | `ORDER BY col DESC` | 降序 |
| `last(sql)` | 追加 SQL 片段 | 谨慎使用，防 SQL 注入 |

---

## 分页查询

```java
// 配置分页插件（Spring Boot）
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}

// 分页查询
Page<UserDO> page = new Page<>(pageNum, pageSize);  // 页码从1开始
LambdaQueryWrapper<UserDO> wrapper = new LambdaQueryWrapper<UserDO>()
    .eq(UserDO::getStatus, 1);
IPage<UserDO> result = userMapper.selectPage(page, wrapper);

// 获取结果
List<UserDO> records = result.getRecords();    // 当前页数据
long total = result.getTotal();                // 总记录数
long pages = result.getPages();               // 总页数
```

---

## 乐观锁

```java
// 1. 实体上加 @Version
@Version
private Integer version;

// 2. 注册乐观锁插件
interceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());

// 3. 更新时自动校验并递增 version
// 注意：必须先查出含 version 的实体，再更新，否则不生效
UserDO user = userMapper.selectById(id);  // 查出带 version 的对象
user.setStatus(newStatus);
int rows = userMapper.updateById(user);    // version 自动校验和递增
if (rows == 0) {
    throw new BusinessException("数据已被其他操作修改，请重试");
}
```

**关键规则：**
- `updateById` 时必须携带 `version` 字段，否则乐观锁不生效
- 返回 `0` 表示版本冲突，应向上层抛出可重试异常

---

## 逻辑删除

```java
// 全局配置（application.yml）
mybatis-plus:
  global-config:
    db-config:
      logic-delete-field: deleted   # 全局逻辑删除字段名
      logic-delete-value: 1         # 删除值
      logic-not-delete-value: 0     # 未删除值

// 实体上加 @TableLogic（若已全局配置则可省略注解）
@TableLogic
private Integer deleted;

// 之后 deleteById 会自动变成 UPDATE ... SET deleted=1
// selectList/selectPage 等查询会自动追加 WHERE deleted=0
```

**常见陷阱：**
- 自定义 SQL 不会自动追加 `deleted=0` 条件，需手动添加
- 联表查询时注意主表和关联表都需要加逻辑删除条件

---

## 批量插入

```java
// 方式一：saveBatch（需继承 ServiceImpl）
// ServiceImpl 的 saveBatch 会分批次执行，默认 1000 条一批
userService.saveBatch(userList, 500);  // 每批500条

// 方式二：自定义 XML，insert into ... values (?,?),(?,?)
// 性能更好，适合大批量

// 方式三：InjectionSqlRunner（MP 3.x）
```

**性能注意：**
- `BaseMapper.insert` 循环调用性能极差，禁止在大批量场景使用
- `saveBatch` 在连接串加 `rewriteBatchedStatements=true` 时性能大幅提升
- 超过 1000 条必须分批，避免单条 SQL 过大

---

## 更新操作

```java
// 根据 ID 更新（只更新非空字段）
UserDO user = new UserDO();
user.setId(1L);
user.setStatus(2);
userMapper.updateById(user);  // 只更新 status 字段

// 条件更新
LambdaUpdateWrapper<UserDO> wrapper = new LambdaUpdateWrapper<UserDO>()
    .eq(UserDO::getStatus, 1)
    .set(UserDO::getStatus, 2)
    .set(UserDO::getUpdateTime, LocalDateTime.now());
userMapper.update(null, wrapper);

// 注意：updateById 对于 null 字段不更新；若要更新为 null，需用 UpdateWrapper.set()
```

---

## 常见陷阱与禁止行为

1. **禁止 `new LambdaQueryWrapper<>()` 不传泛型**，会导致字段引用无法推断
2. **禁止在条件构造器中写 `1=1`**，MP 会自动处理空条件
3. **`last("LIMIT 1")` 有 SQL 注入风险**，若内容来自外部输入务必检查
4. **`in(col, emptyList)` 会生成 `IN ()` 报语法错误**，需先判空
5. **乐观锁必须先查再更**，直接 `new` 对象设 `id` 后 `updateById` 不会触发版本校验
6. **逻辑删除后数据仍在库中**，唯一索引字段需特殊处理（如：`deleted` 改为 `deleted_at` 时间戳）

