# Spring MVC 使用说明

## 快速参考

### 核心注解

| 注解 | 作用 | 说明 |
|------|------|------|
| `@RestController` | 类级别，返回 JSON | = `@Controller` + `@ResponseBody` |
| `@RequestMapping` | 映射 URL | 可用于类和方法 |
| `@GetMapping` / `@PostMapping` 等 | HTTP 方法快捷注解 | 推荐用法 |
| `@PathVariable` | 路径参数绑定 | `/users/{id}` |
| `@RequestParam` | 查询参数绑定 | `?name=xxx` |
| `@RequestBody` | 请求体绑定（JSON → 对象） | POST/PUT 常用 |
| `@RequestHeader` | 请求头绑定 | |
| `@ResponseStatus` | 设置响应状态码 | |
| `@ExceptionHandler` | 局部异常处理 | 在 Controller 类内 |
| `@ControllerAdvice` | 全局异常处理 | 配合 `@ExceptionHandler` |
| `@CrossOrigin` | 跨域（方法/类级别） | 生产环境建议用全局配置 |

---

## Controller 开发规范

### 1. 标准结构

```java
@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;  // 推荐构造函数注入
    }

    @GetMapping("/{id}")
    public Result<UserVO> getUser(@PathVariable Long id) {
        return Result.ok(userService.getUserById(id));
    }

    @PostMapping
    public Result<Long> createUser(@RequestBody @Valid CreateUserReq req) {
        return Result.ok(userService.createUser(req));
    }
}
```

### 2. 参数绑定

```java
// 路径参数（必填）
@GetMapping("/{id}")
public Result<UserVO> get(@PathVariable Long id) { ... }

// 查询参数（可选，带默认值）
@GetMapping
public Result<List<UserVO>> list(
    @RequestParam(defaultValue = "1") int page,
    @RequestParam(defaultValue = "20") int size
) { ... }

// 请求体（JSON，推荐配合 @Valid 做参数校验）
@PostMapping
public Result<Long> create(@RequestBody @Valid CreateUserReq req) { ... }

// 混合：路径 + 请求体
@PutMapping("/{id}")
public Result<Void> update(@PathVariable Long id, @RequestBody @Valid UpdateUserReq req) { ... }
```

### 3. 参数校验

```java
// 在 DTO 上加 Bean Validation 注解
public class CreateUserReq {
    @NotBlank(message = "用户名不能为空")
    private String username;

    @Email(message = "邮箱格式错误")
    private String email;

    @Min(value = 0, message = "年龄不能为负数")
    private Integer age;
}

// 在 Controller 参数上加 @Valid 或 @Validated
@PostMapping
public Result<Long> create(@RequestBody @Valid CreateUserReq req) { ... }
```

---

## Filter（过滤器）

### 注册方式

```java
// 方式一：@Component + 实现 Filter
@Component
@Order(1)  // 数字越小优先级越高
public class LogFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // 前置逻辑
        chain.doFilter(request, response);
        // 后置逻辑
    }
}

// 方式二：FilterRegistrationBean（更灵活，可指定 URL 模式）
@Bean
public FilterRegistrationBean<LogFilter> logFilter() {
    FilterRegistrationBean<LogFilter> bean = new FilterRegistrationBean<>();
    bean.setFilter(new LogFilter());
    bean.addUrlPatterns("/api/*");
    bean.setOrder(1);
    return bean;
}
```

### 与 Interceptor 的区别

| 特性 | Filter | Interceptor |
|------|--------|-------------|
| 规范 | Servlet 规范 | Spring MVC 规范 |
| 依赖注入 | 需要额外配置 | 原生支持 `@Autowired` |
| 访问 Handler 信息 | 不支持 | 支持 |
| 适用场景 | 跨域、日志、编码 | 鉴权、权限、业务前置 |

---

## Interceptor（拦截器）

```java
@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        // 前置拦截，返回 false 则中断
        String token = request.getHeader("Authorization");
        if (!isValid(token)) {
            response.setStatus(401);
            return false;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        // 方法执行后，视图渲染前
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception ex) throws Exception {
        // 完全结束后（资源清理）
    }
}

// 注册拦截器
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Autowired
    private AuthInterceptor authInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/public/**");
    }
}
```

---

## 全局异常处理

```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // 业务异常
    @ExceptionHandler(BusinessException.class)
    public Result<Void> handleBusiness(BusinessException e) {
        log.error("业务异常: code={}, message={}", e.getCode(), e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    }

    // 参数校验失败（@Valid）
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValidation(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));
        log.error("参数校验失败: {}", msg);
        return Result.fail(ErrorCode.PARAM_ERROR, msg);
    }

    // 兜底异常（必须有，防止内部细节泄露）
    @ExceptionHandler(Exception.class)
    public Result<Void> handleUnknown(Exception e) {
        log.error("未知异常", e);
        return Result.fail(ErrorCode.SYSTEM_ERROR, "系统繁忙，请稍后重试");
    }
}
```

**关键规则：**
- 兜底 `Exception.class` 必须有，且只打 `error` 日志
- 业务异常不得透传内部堆栈给客户端
- 参数校验失败返回 400，不要返回 500

---

## 跨域配置（CORS）

```java
// 全局配置（推荐生产使用）
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOriginPatterns("https://*.example.com")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

**常见陷阱：**
- `allowCredentials(true)` 时不能用 `allowedOrigins("*")`，必须用 `allowedOriginPatterns`
- 生产环境禁止 `allowedOriginPatterns("*")`

---

## 常见陷阱与禁止行为

1. **禁止在 Controller 层写业务逻辑**，应委托 Service 处理
2. **禁止捕获异常后不处理**（空 catch 块），至少打 error 日志
3. **禁止直接返回 Entity 对象**，应用 VO/DTO 隔离，避免字段泄露
4. **禁止在 Controller 直接操作 DB**，必须经过 Service 层
5. **`@Transactional` 不要加在 Controller 上**，事务应在 Service 层管理
6. **避免在 Filter 中读取 `HttpServletRequest.getInputStream()`**，一旦读取后 Controller 无法再读，需要包装 Request

