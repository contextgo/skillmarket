# Redis 使用说明

## 快速参考

### 客户端选型

| 客户端 | 说明 | 推荐场景 |
|--------|------|---------|
| `RedisTemplate` | Spring 封装，支持各种数据类型 | 通用场景，业务层首选 |
| `StringRedisTemplate` | `RedisTemplate<String,String>` 的快捷版 | key/value 均为字符串 |
| `Jedis` | 同步阻塞，连接池管理需手动配置 | 需要 Pipeline/Lua 的特殊场景 |
| `Lettuce` | 异步、线程安全，Spring Boot 默认 | 高并发异步场景 |

> **优先使用 `RedisTemplate` 或公司封装的统一 Redis 客户端，不要在业务层直接 `new JedisPool` 或直接操作原生 `Jedis` 连接。**

---

## RedisTemplate 基本操作

### 配置

```java
// Spring Boot 自动配置，application.yml
spring:
  redis:
    host: localhost
    port: 6379
    password: ""
    database: 0
    lettuce:
      pool:
        max-active: 20
        max-idle: 10
        min-idle: 5
        max-wait: 2000ms

// 自定义序列化（推荐，避免乱码）
@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        return template;
    }
}
```

### 常用操作

```java
// String
redisTemplate.opsForValue().set("key", "value");
redisTemplate.opsForValue().set("key", "value", 30, TimeUnit.MINUTES);  // 带过期时间
String val = (String) redisTemplate.opsForValue().get("key");
redisTemplate.opsForValue().increment("counter", 1);  // 原子自增

// Hash
redisTemplate.opsForHash().put("hash_key", "field", "value");
Map<Object, Object> map = redisTemplate.opsForHash().entries("hash_key");

// List
redisTemplate.opsForList().rightPush("list_key", "value");
List<Object> list = redisTemplate.opsForList().range("list_key", 0, -1);

// Set
redisTemplate.opsForSet().add("set_key", "v1", "v2", "v3");
Boolean isMember = redisTemplate.opsForSet().isMember("set_key", "v1");

// ZSet（有序集合）
redisTemplate.opsForZSet().add("zset_key", "member", 1.0);
Set<Object> top10 = redisTemplate.opsForZSet().reverseRange("zset_key", 0, 9);

// TTL 操作
redisTemplate.expire("key", 60, TimeUnit.SECONDS);
Long ttl = redisTemplate.getExpire("key", TimeUnit.SECONDS);
Boolean exists = redisTemplate.hasKey("key");
redisTemplate.delete("key");
redisTemplate.delete(Arrays.asList("key1", "key2"));
```

---

## 分布式锁

### 方式一：Redisson（推荐，生产级别）

```java
// 依赖：redisson-spring-boot-starter
@Autowired
private RedissonClient redissonClient;

public void doWithLock(String lockKey) {
    RLock lock = redissonClient.getLock(lockKey);
    try {
        // 尝试加锁：等待3秒，持有30秒自动释放
        boolean acquired = lock.tryLock(3, 30, TimeUnit.SECONDS);
        if (!acquired) {
            throw new BusinessException("获取锁失败，请稍后重试");
        }
        // 业务逻辑
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new BusinessException("加锁被中断");
    } finally {
        if (lock.isHeldByCurrentThread()) {
            lock.unlock();  // 必须在 finally 中释放，且判断是否持有
        }
    }
}
```

### 方式二：SET NX EX（轻量实现）

```java
// 使用 RedisTemplate 的 setIfAbsent
String lockKey = "lock:order:" + orderId;
String lockValue = UUID.randomUUID().toString();
Boolean acquired = redisTemplate.opsForValue()
    .setIfAbsent(lockKey, lockValue, 30, TimeUnit.SECONDS);

if (Boolean.TRUE.equals(acquired)) {
    try {
        // 业务逻辑
    } finally {
        // 释放锁时必须验证 value，防止误删他人锁（需用 Lua 保证原子性）
        releaseLockWithLua(lockKey, lockValue);
    }
}

private void releaseLockWithLua(String key, String value) {
    String script = "if redis.call('get', KEYS[1]) == ARGV[1] then " +
                    "return redis.call('del', KEYS[1]) else return 0 end";
    redisTemplate.execute(
        new DefaultRedisScript<>(script, Long.class),
        Collections.singletonList(key),
        value
    );
}
```

**分布式锁关键规则：**
- 锁必须有过期时间，防止死锁
- 释放时必须验证 value 是否为自己设置的（原子操作，用 Lua）
- `finally` 中释放前判断 `isHeldByCurrentThread()`（Redisson）
- 不要在锁持有期间进行耗时 I/O 操作，防止锁超时续期问题

---

## Lua 脚本

```java
// 原子性：检查并更新（CAS）
String script = "local val = redis.call('get', KEYS[1])\n" +
                "if val == ARGV[1] then\n" +
                "    redis.call('set', KEYS[1], ARGV[2])\n" +
                "    return 1\n" +
                "else\n" +
                "    return 0\n" +
                "end";

Long result = redisTemplate.execute(
    new DefaultRedisScript<>(script, Long.class),
    Collections.singletonList("myKey"),   // KEYS
    "expectedValue", "newValue"           // ARGV
);
```

**Lua 脚本规则：**
- Lua 脚本在 Redis 单线程中执行，具有原子性
- 脚本应短小，禁止在 Lua 中执行耗时操作
- 生产环境优先使用 `EVALSHA`（先 SCRIPT LOAD，后 EVALSHA）减少网络传输

---

## Pipeline（批量操作）

```java
// 批量写入，减少网络往返
List<Object> results = redisTemplate.executePipelined(
    new RedisCallback<Object>() {
        @Override
        public Object doInRedis(RedisConnection connection) throws DataAccessException {
            StringRedisConnection conn = (StringRedisConnection) connection;
            for (String key : keys) {
                conn.get(key);
            }
            return null;  // 必须返回 null，结果通过方法返回值获取
        }
    }
);
```

**Pipeline 注意：**
- Pipeline 不保证原子性，与 Lua 不同
- 不适合需要根据中间结果决定下一步操作的场景
- 集群模式下 Pipeline 只能对同一个 slot 的 key 生效

---

## TTL 设计规范

```java
// 推荐：集中管理 TTL 常量，避免魔法值
public class CacheTtlConstants {
    public static final long USER_INFO_TTL_SECONDS = 3600;        // 1小时
    public static final long SESSION_TTL_SECONDS = 86400;          // 1天
    public static final long HOT_DATA_TTL_SECONDS = 300;           // 5分钟
}

// 使用时引用常量
redisTemplate.opsForValue().set("user:" + userId, userInfo,
    CacheTtlConstants.USER_INFO_TTL_SECONDS, TimeUnit.SECONDS);
```

---

## 资源管理规范（直接使用 Jedis 时）

> **业务层通常不应直接使用 Jedis，应通过 RedisTemplate 或公司封装的客户端**。若确有必要（如需要 Pipeline、特殊命令），必须遵守以下规范：

```java
// 必须使用 try-with-resources 或 try/finally 保证连接归还
JedisPool jedisPool = ...; // 来自 Spring Bean，不要自己 new

// 方式一：try-with-resources（推荐）
try (Jedis jedis = jedisPool.getResource()) {
    jedis.set("key", "value");
}

// 方式二：try/finally
Jedis jedis = null;
try {
    jedis = jedisPool.getResource();
    jedis.set("key", "value");
} finally {
    if (jedis != null) {
        jedis.close();  // 归还到连接池，不是真正关闭连接
    }
}
```

**禁止行为：**
- 禁止不归还连接（无 `close()`/`try-with-resources`）
- 禁止在业务层 `new JedisPool()`，必须使用 Spring 容器管理的实例
- 禁止在 `finally` 中直接 `close()` 不判空（NPE 风险）

---

## 常见陷阱

1. **缓存穿透**：key 不存在时每次都打 DB，需对空值也设 TTL 缓存（或用布隆过滤器）
2. **缓存雪崩**：大量 key 同时过期，需在 TTL 上加随机偏移量
3. **缓存击穿**：热点 key 过期时大量并发请求击穿到 DB，需加互斥锁或逻辑过期
4. **`Boolean.TRUE.equals(result)` 而非 `result == true`**：Redis 操作返回 `Boolean` 可能为 `null`
5. **序列化兼容性**：更改 value 对象字段后老数据反序列化可能失败，需注意版本兼容
6. **Key 命名**：建议 `业务:模块:id` 格式，如 `user:info:12345`，便于管理和清理

