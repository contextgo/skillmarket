# Thrift 使用说明

## ⚠️ Field ID 规则（RPC 合约核心约束，必读）

> Thrift 序列化依赖 field id（整数标识符），而非字段名。违反以下规则将导致序列化/反序列化错误。

### 规则一：field id 不可删除、不可修改、不可复用

```thrift
// ❌ 禁止：删除字段
struct UserResponse {
    1: required i64 user_id,
    // 2: string user_name  ← 不可直接删除，需用 optional 保留或注释说明
    3: i32 status,
}

// ✅ 正确：废弃字段保留定义，注释说明已废弃
struct UserResponse {
    1: required i64 user_id,
    2: optional string user_name,  // DEPRECATED: 已废弃，保留 field id 防止复用
    3: i32 status,
}
```

### 规则二：新增字段必须使用新的递增 field id，且标记为 optional

```thrift
// ✅ 正确：新增字段追加到末尾，field id 递增，标记 optional
struct UserResponse {
    1: required i64 user_id,   // 原有，不动
    3: i32 status,              // 原有，不动（2 已废弃保留）
    4: optional string email,   // 新增，field id = max+1，必须 optional
    5: optional i32 age,        // 新增
}
```

### 规则三：不可修改存量字段类型

```thrift
// ❌ 禁止：修改字段类型（i32 -> i64 在某些情况下不兼容）
1: required i32 status,   // 原有
// 1: required i64 status  ← 不得修改类型

// ✅ 正确：保留原字段，新增字段
1: required i32 status,          // 保留原字段
6: optional i64 status_v2,       // 新增字段承载新语义
```

### 规则四：存量字段语义不可修改

```thrift
// ❌ 禁止：复用 field id 表达不同语义
// 原来 field 3 = status（1=正常 2=禁用）
// 不得修改为 field 3 = type（用户类型）

// ✅ 正确：保留原字段，新增字段
3: i32 status,       // 保留原语义
7: optional i32 user_type,  // 新增字段
```

---

## IDL 基础语法

### 数据类型

| Thrift 类型 | 说明 | 对应 Java |
|-------------|------|---------|
| `bool` | 布尔 | `boolean` |
| `byte` | 8位有符号整数 | `byte` |
| `i16` | 16位有符号整数 | `short` |
| `i32` | 32位有符号整数 | `int` |
| `i64` | 64位有符号整数 | `long` |
| `double` | 64位浮点 | `double` |
| `string` | UTF-8字符串 | `String` |
| `binary` | 二进制 | `ByteBuffer` |
| `list<T>` | 列表 | `List<T>` |
| `set<T>` | 集合 | `Set<T>` |
| `map<K,V>` | 字典 | `Map<K,V>` |

### IDL 示例

```thrift
namespace java com.example.user

// 枚举
enum UserStatus {
    NORMAL = 1,
    DISABLED = 2,
}

// 结构体
struct UserDTO {
    1: required i64 user_id,
    2: required string user_name,
    3: optional i32 status,
    4: optional string email,
    5: optional list<string> tags,
}

// 请求/响应
struct GetUserRequest {
    1: required i64 user_id,
    2: optional string trace_id,
}

struct GetUserResponse {
    1: required i32 code,        // 0=成功
    2: optional string message,
    3: optional UserDTO data,
}

// 异常
exception UserNotFoundException {
    1: required i32 code,
    2: required string message,
}

// 服务
service UserService {
    GetUserResponse getUser(1: GetUserRequest request) throws (1: UserNotFoundException e),
    list<UserDTO> listUsers(1: list<i64> user_ids),
}
```

---

## Java 代码生成

```bash
# 生成 Java 代码
thrift --gen java -out src/main/java user.thrift

# 或使用 Maven 插件
```

```xml
<!-- pom.xml -->
<plugin>
    <groupId>org.apache.thrift.tools</groupId>
    <artifactId>maven-thrift-plugin</artifactId>
    <version>0.1.11</version>
    <configuration>
        <thriftExecutable>thrift</thriftExecutable>
    </configuration>
    <executions>
        <execution>
            <id>thrift-sources</id>
            <phase>generate-sources</phase>
            <goals>
                <goal>compile</goal>
            </goals>
        </execution>
    </executions>
</plugin>
```

---

## 服务实现

```java
// 实现生成的 Iface 接口
public class UserServiceImpl implements UserService.Iface {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public GetUserResponse getUser(GetUserRequest request) throws UserNotFoundException, TException {
        try {
            UserDTO user = userDomainService.getById(request.getUserId());
            if (user == null) {
                throw new UserNotFoundException()
                    .setCode(404)
                    .setMessage("用户不存在: " + request.getUserId());
            }
            return new GetUserResponse()
                .setCode(0)
                .setData(user);
        } catch (UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("getUser 失败: userId={}", request.getUserId(), e);
            return new GetUserResponse()
                .setCode(500)
                .setMessage("服务内部错误");
        }
    }
}
```

---

## 服务端启动

```java
// 简单服务端示例
public class ThriftServer {

    public static void main(String[] args) throws TException {
        UserService.Processor<UserServiceImpl> processor =
            new UserService.Processor<>(new UserServiceImpl());

        TServerTransport serverTransport = new TServerSocket(9090);
        TThreadPoolServer.Args serverArgs = new TThreadPoolServer.Args(serverTransport)
            .processor(processor)
            .protocolFactory(new TBinaryProtocol.Factory())
            .minWorkerThreads(10)
            .maxWorkerThreads(100);

        TServer server = new TThreadPoolServer(serverArgs);
        server.serve();
    }
}
```

---

## 客户端调用（资源管理，必须正确释放）

```java
// ✅ 正确：使用 try-with-resources 或 try/finally 管理连接
public GetUserResponse getUser(long userId) {
    TTransport transport = new TSocket("localhost", 9090, 3000);  // 3秒超时
    try {
        transport.open();
        TProtocol protocol = new TBinaryProtocol(transport);
        UserService.Client client = new UserService.Client(protocol);

        GetUserRequest request = new GetUserRequest().setUserId(userId);
        return client.getUser(request);

    } catch (UserNotFoundException e) {
        log.warn("用户不存在: userId={}", userId);
        throw new BusinessException(404, "用户不存在");
    } catch (TException e) {
        log.error("Thrift 调用失败: userId={}", userId, e);
        throw new ServiceException("用户服务暂时不可用");
    } finally {
        if (transport.isOpen()) {
            transport.close();  // 必须在 finally 中关闭
        }
    }
}

// ✅ 推荐：使用连接池（生产环境）
// 使用 Apache Commons Pool 或您组织自定义的 Thrift 连接池
// 避免每次请求都创建新连接
```

---

## 传输层与协议层选择

| 传输层 | 说明 | 推荐场景 |
|--------|------|---------|
| `TSocket` | TCP socket，同步阻塞 | 简单场景 |
| `TFramedTransport` | 带帧的 socket，用于非阻塞 I/O | 配合 TNonblockingServer |
| `THttpClient` | HTTP 传输 | 跨防火墙 |

| 协议层 | 说明 | 推荐场景 |
|--------|------|---------|
| `TBinaryProtocol` | 二进制，高效 | 内网通信 |
| `TCompactProtocol` | 压缩二进制，更省空间 | 网络带宽敏感 |
| `TJSONProtocol` | JSON 格式 | 调试/HTTP 传输 |

> **客户端与服务端必须使用相同的传输层和协议层，否则无法通信。**

---

## 常见陷阱与禁止行为

1. **禁止删除或复用 field id**，废弃字段保留定义并注释，新增字段递增追加
2. **禁止新增 required 字段**（会导致旧版本反序列化失败），新增字段必须用 `optional`
3. **禁止客户端不释放连接**，必须 `transport.close()` 且放在 `finally` 中
4. **生产环境禁止不使用连接池**，每次新建连接性能极差
5. **禁止在 IDL 中使用 Java 关键字作为字段名**（如 `class`、`interface`）
6. **异常类型必须在 IDL 中定义**，未定义的异常在 Consumer 侧会被包装为 `TApplicationException`
7. **禁止修改枚举值对应的整数**（会破坏序列化兼容性）

