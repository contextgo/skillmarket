# Dubbo RPC 使用说明

## ⚠️ 字段有序规则（RPC 合约核心约束，必读）

> 本节是 Dubbo RPC 开发中最重要的约束，违反将导致序列化兼容性问题，影响线上服务。

### 规则一：接口字段不可删除、不可重命名、不可修改类型

```java
// ❌ 禁止：删除字段
// 原始接口
public class UserDTO {
    private Long userId;
    private String userName;  // 不得删除此字段
    private Integer status;
}

// ❌ 禁止：重命名字段（若依赖 JSON/Hessian 序列化，字段名变化会导致反序列化失败）
private String name;  // 原来是 userName，不得改名

// ❌ 禁止：修改字段类型（Integer -> Long 在某些序列化下兼容，但仍有风险）
private Long status;  // 原来是 Integer，不得改类型
```

### 规则二：新增字段必须追加到末尾，且加默认值

```java
// ✅ 正确：在末尾新增字段
public class UserDTO {
    private Long userId;        // 原有字段，不动
    private String userName;    // 原有字段，不动
    private Integer status;     // 原有字段，不动
    // ↓ 新增字段必须在末尾，并设置默认值
    private String email = "";  // 新增，有默认值
    private Integer age = 0;    // 新增，有默认值
}
```

### 规则三：存量字段语义不可修改

```java
// ❌ 禁止：修改存量字段语义
// 原来 status: 1=正常 2=禁用
// 不得改成 status: 1=VIP 2=普通用户

// ✅ 正确：保留老字段，新增字段承载新语义
public class UserDTO {
    private Integer status;       // 保留原语义：1=正常 2=禁用
    private Integer userType = 0; // 新增：0=普通 1=VIP（新语义在新字段）
}
```

### 版本不兼容的处理方式

当接口变更不兼容时（如必须修改字段名），应：
1. 新增接口方法（保留旧方法），如 `getUserV2()`
2. 或使用 Dubbo 版本号机制（`version = "2.0.0"`）隔离新旧版本
3. 旧版本接口待调用方全部升级后才能下线

---

## 快速参考

### 核心注解

| 注解 | 作用 | 说明 |
|------|------|------|
| `@DubboService` | 发布服务（服务端） | 替代旧版 `@Service` |
| `@DubboReference` | 引用服务（客户端） | 替代旧版 `@Reference` |
| `@Method` | 方法级配置 | 超时、重试等 |

---

## 服务发布（Provider）

```java
// 接口定义（通常在独立的 API 模块中）
public interface UserService {
    UserDTO getUserById(Long userId);
    List<UserDTO> listUsers(UserQueryReq req);
}

// 实现（在 Provider 服务中）
@DubboService(
    version = "1.0.0",
    group = "user-group",
    timeout = 3000,       // 超时 3 秒
    retries = 0           // 重试次数（建议非幂等接口设为 0）
)
public class UserServiceImpl implements UserService {

    @Override
    public UserDTO getUserById(Long userId) {
        // 业务逻辑
    }
}
```

---

## 服务调用（Consumer）

```java
@Component
public class UserFacade {

    @DubboReference(
        version = "1.0.0",
        group = "user-group",
        timeout = 3000,
        retries = 0,          // 重试次数（非幂等接口必须设为 0）
        check = false         // 启动时不检查 Provider 是否存在
    )
    private UserService userService;

    public UserDTO getUser(Long userId) {
        try {
            return userService.getUserById(userId);
        } catch (RpcException e) {
            log.error("RPC 调用失败: userId={}", userId, e);
            // 根据业务决定：降级/抛出/返回默认值
            throw new ServiceException("用户服务暂时不可用");
        }
    }
}
```

---

## 配置（application.yml）

```yaml
dubbo:
  application:
    name: my-service
  registry:
    address: nacos://127.0.0.1:8848  # 或 zookeeper://127.0.0.1:2181
  protocol:
    name: dubbo
    port: 20880
  provider:
    timeout: 3000
    retries: 0      # 生产环境建议全局设 0，避免非幂等重复调用
  consumer:
    timeout: 3000
    check: false
```

---

## 版本与分组

```java
// 版本：用于接口升级时灰度切换
@DubboService(version = "2.0.0")    // Provider 发布新版
@DubboReference(version = "2.0.0")  // Consumer 升级到新版

// 分组：同一接口的不同实现（如不同业务线）
@DubboService(group = "groupA")
@DubboReference(group = "groupA")

// 广播调用（所有 Provider 都执行）
@DubboReference(cluster = "broadcast")
```

---

## 泛化调用（无接口调用）

```java
// 泛化引用（无需引入 API jar）
@DubboReference(interfaceName = "com.example.UserService", generic = true)
private GenericService genericService;

// 泛化调用
Object result = genericService.$invoke(
    "getUserById",                    // 方法名
    new String[]{"java.lang.Long"},   // 参数类型
    new Object[]{1001L}               // 参数值
);
```

---

## 异常处理规范

```java
// Dubbo 的异常处理特殊性：
// 1. Provider 侧的非 RuntimeException 会被包装为 RuntimeException 传到 Consumer
// 2. 自定义业务异常若需传到 Consumer，必须放在接口所在的 API 模块中（Consumer 能加载到）

// ✅ 正确：自定义异常放在 API 模块
// api 模块中
public class BusinessException extends RuntimeException {
    private final int code;
    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }
}

// ✅ 正确：Provider 抛出，Consumer 捕获
try {
    return userService.getUserById(userId);
} catch (BusinessException e) {
    // 捕获业务异常，处理具体错误码
} catch (RpcException e) {
    // 捕获 RPC 框架异常（网络超时、连接失败等）
    log.error("RPC 调用异常", e);
}
```

---

## 过滤器（Filter）

```java
// 自定义过滤器（Provider 和 Consumer 均可）
@Activate(group = {PROVIDER, CONSUMER})
public class LogFilter implements Filter {

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        long start = System.currentTimeMillis();
        try {
            Result result = invoker.invoke(invocation);
            log.info("RPC 调用成功: method={}, cost={}ms",
                invocation.getMethodName(), System.currentTimeMillis() - start);
            return result;
        } catch (RpcException e) {
            log.error("RPC 调用失败: method={}", invocation.getMethodName(), e);
            throw e;
        }
    }
}

// 注册：resources/META-INF/dubbo/org.apache.dubbo.rpc.Filter
// log=com.example.LogFilter
```

---

## 常见陷阱与禁止行为

1. **禁止非幂等接口设置 `retries > 0`**，重试会导致数据重复
2. **禁止在 Provider 接口中直接暴露 Entity（DB 对象）**，应使用 DTO 隔离
3. **禁止删除或修改已发布接口的字段**，只能新增并追加到末尾
4. **禁止在接口 DTO 中使用非序列化的类型**（如 `Optional`、`Stream`）
5. **禁止 `check = true` 在生产环境**（会导致启动时找不到 Provider 而失败）
6. **接口方法返回值不建议使用基本类型**（`int/long`），建议用包装类（`Integer/Long`），避免 null 解包 NPE

