# sdd-driven-dev — Claude Code 指令文件

**语言规则**：必须始终使用**中文**与用户交互。所有输出、提示、报告、文档均使用中文。

## 概述

本项目使用 **sdd-driven-dev** 工具，基于需求文档驱动 AI 完成需求开发；可选结合既有 SDD 知识库加速分析。此文件配置 Claude Code 遵循六阶段工作流。

## IDE 模式：Claude Code

在 Claude Code 模式下：
- 使用终端命令探索代码：`grep -rn`、`find`、`cat`、`head`、`tail`、`wc -l`
- 使用 `sed -n 'START,ENDp' FILE` 读取指定行范围
- 使用 `cat > file << 'EOF'` 或直接文件写入创建文件
- 使用 `mkdir -p` 创建目录
- 每个阶段结束后打印摘要并等待用户确认
- 不依赖 Plan 模式或 Cursor 特有工具

## 触发

当用户说 "执行AI开发需求工作流程"、"基于SDD文档开发需求" 或类似指令时：

1. 读取本 skill 目录下的 `prompts/01_阶段一_PRD获取.md`
2. 设置 IDE 模式为 `claude-code`
3. **向用户确认当前需求目录 `REQ_ROOT`**（必需），并按需确认可选知识库变量：
   - `KB_NAME`（可选）：知识库名称（业务系统名）
   - `KB_ROOT`（可选）：知识库根目录路径
   - `KB_QUICK_REF`（可选）：快速参考文档路径（含 SDD 路径、规范文档路径、经验沉淀路径）
4. 遵循六阶段工作流

可选工具：
- "提交AI开发workflow反馈" → 读取 `prompts/工具_feedback.md`
- "上报SDD缺口" → 读取 `prompts/工具_SDD缺口上报.md`
- "分析测试提的bug" → 读取 `prompts/工具_测试Bug分析总结上报.md`
- "执行AI自动CR" → 读取 `prompts/工具_AI自动CR.md`

## 配置

工作流开始时确认：
- **当前需求目录（REQ_ROOT）**：用户确认；若用户未指定，默认 `./docs/sdd-kb/ai-dev-requests/{年}/{月}/{需求名称}/`
- **知识库根目录（KB_ROOT）**：可选，未提供时默认 `./docs/sdd-kb/`
- **Skill 目录**：从 CLAUDE.md 位置自动检测

## 代码探索命令（Claude Code）

替代 Cursor 的 `codebase_search`/`grep`/`glob_file_search`：

```bash
# 搜索业务逻辑模式
grep -rn "模式" --include="*.java" --include="*.py" --include="*.go" --include="*.ts" .

# 按名称查找文件
find . -name "*Controller*" -o -name "*Handler*" -o -name "*router*"

# 读取指定行范围（带行号）
cat -n path/to/file | sed -n '10,30p'

# 统计匹配数
grep -rc "pattern" --include="*.java" . | grep -v ":0$"
```

## 阶段切换

每个阶段完成后输出：
```
═══════════════════════════════════════
阶段 N 已完成。[输出摘要]
准备进入阶段 N+1：[阶段名称]
请输入"继续"或提供反馈。
═══════════════════════════════════════
```

等待用户输入后继续。

## 工作流阶段

六个阶段：
1. PRD 获取（确认 `REQ_ROOT` + 获取本地 PRD 文档；知识库上下文可选）
2. 需求分析与代码探索（循环，产出改动点清单）
3. 技术方案生成（与改动点逐项对应，框架按需加载）
4. 人工校验与技术方案迭代（人工驱动，循环执行）
5. 执行开发（自动循环，接口冲突时必须暂停）
6. 开发结果验证（按需执行）

每个阶段读取 `prompts/` 目录中对应的提示词文件。

## 框架加载规则（Claude Code）

阶段三、阶段五命中框架组件时：
1. 先读 `references/company-frameworks/index.yaml`
2. 命中 → 加载对应公司框架说明
3. 未命中 → 读 `references/通用框架使用说明/` 下对应文件

## 说明

- `prompts/` 中的所有提示词文件在 Cursor 和 Claude Code 之间共享
- 唯一区别是代码探索方式和阶段切换方式
- 技术方案格式、改动点清单、产物目录结构在两种 IDE 下完全一致
