#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Word文档转Markdown工具

功能：
1. 提取Word文档（.docx）中的文本内容
2. 提取并保存图片文件（支持段落和表格单元格中的图片）
3. 保持图片在文档中的原始位置
4. 生成包含图片分析的完整版Markdown文档
5. 使用多模态能力识别图片内容（需要在调用时传入图片分析结果）
6. 支持表格转换，表格单元格中的图片会在表格后统一显示

使用方法：
    python word_to_markdown.py <word_file> <output_dir> [--image-analysis <json_file>]

参数：
    word_file: Word文档路径（.docx格式）
    output_dir: 输出目录（Markdown文件和提取的图片将保存在此目录）
    --image-analysis: 可选的图片分析JSON文件路径（包含图片识别结果）

输出：
    - <word_file_basename>.md: Markdown文档（包含文本和图片引用，图片分析将在阶段一的图片分析步骤中添加）
    - prd_extracted/: 提取的图片目录（转换完成后自动清理中间文件，只保留图片）
"""

import zipfile
import xml.etree.ElementTree as ET
import os
import sys
import json
import shutil
import argparse
from pathlib import Path


def extract_word_content(docx_path, output_dir):
    """
    提取Word文档内容，保持图片位置
    
    Args:
        docx_path: Word文档路径
        output_dir: 输出目录
        
    Returns:
        list: 内容项列表，每个项包含text和images
    """
    # 创建输出目录
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    
    # 解压docx文件（防止 Zip Slip：校验所有成员路径在目标目录内）
    output_dir_resolved = os.path.realpath(output_dir)
    with zipfile.ZipFile(docx_path, 'r') as zip_ref:
        for member in zip_ref.namelist():
            member_path = os.path.realpath(os.path.join(output_dir_resolved, member))
            if not member_path.startswith(output_dir_resolved + os.sep):
                raise ValueError(f"非法 zip 路径，拒绝解压: {member}")
        zip_ref.extractall(output_dir)
    
    # 读取主文档内容
    document_xml = os.path.join(output_dir, "word/document.xml")
    tree = ET.parse(document_xml)
    root = tree.getroot()
    
    # 定义命名空间
    ns = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
        'pic': 'http://schemas.openxmlformats.org/drawingml/2006/picture',
        'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    }
    
    # 读取关系文件，找到图片ID和文件名的映射
    rels_xml = os.path.join(output_dir, "word/_rels/document.xml.rels")
    image_rels = {}
    if os.path.exists(rels_xml):
        rels_tree = ET.parse(rels_xml)
        rels_root = rels_tree.getroot()
        for rel in rels_root.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
            if 'image' in rel.get('Type', ''):
                rel_id = rel.get('Id')
                target = rel.get('Target')
                if target:
                    image_rels[rel_id] = os.path.basename(target)
    
    # 提取内容，保持图片位置
    content_items = []
    
    # 获取文档主体（body）的直接子元素
    body = root.find('.//w:body', ns)
    if body is None:
        body = root
    
    # 遍历body的直接子元素（段落和表格）
    for elem in body:
        # 处理段落（只处理顶层的段落，不包括表格单元格内的段落）
        if elem.tag.endswith('}p'):
            # 检查段落中是否有图片
            drawings = elem.findall('.//w:drawing', ns)
            images_in_para = []
            
            for drawing in drawings:
                blip = drawing.find('.//a:blip', ns)
                if blip is not None:
                    embed_id = blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
                    if embed_id and embed_id in image_rels:
                        image_file = image_rels[embed_id]
                        images_in_para.append(image_file)
            
            # 提取文本
            para_text = []
            for t in elem.findall('.//w:t', ns):
                if t.text:
                    para_text.append(t.text)
            
            text = ''.join(para_text).strip()
            
            # 如果段落有文本或图片，添加到内容列表
            if text or images_in_para:
                content_items.append({
                    'type': 'paragraph',
                    'text': text,
                    'images': images_in_para
                })
        
        # 处理表格（只处理顶层的表格）
        elif elem.tag.endswith('}tbl'):
            table_rows = []
            rows = elem.findall('.//w:tr', ns)
            
            for row in rows:
                cells = row.findall('.//w:tc', ns)
                row_data = []
                
                for cell in cells:
                    # 提取单元格文本
                    cell_text_parts = []
                    cell_images = []
                    
                    # 遍历单元格中的所有段落
                    for para in cell.findall('.//w:p', ns):
                        # 提取段落文本
                        for t in para.findall('.//w:t', ns):
                            if t.text:
                                cell_text_parts.append(t.text)
                        
                        # 检查段落中是否有图片
                        drawings = para.findall('.//w:drawing', ns)
                        for drawing in drawings:
                            blip = drawing.find('.//a:blip', ns)
                            if blip is not None:
                                embed_id = blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
                                if embed_id and embed_id in image_rels:
                                    image_file = image_rels[embed_id]
                                    cell_images.append(image_file)
                    
                    cell_text = ''.join(cell_text_parts).strip()
                    
                    # 单元格内容：文本 + 图片编号标记
                    cell_content = cell_text
                    if cell_images:
                        # 如果有图片，在文本后添加图片编号标记（如 [图片一]、[图片二]）
                        # 编号会在生成Markdown时统一分配
                        cell_content = {
                            'text': cell_text,
                            'images': cell_images
                        }
                    else:
                        cell_content = {
                            'text': cell_text,
                            'images': []
                        }
                    
                    row_data.append(cell_content)
                
                if row_data:
                    table_rows.append(row_data)
            
            # 如果有表格行，添加到内容列表
            if table_rows:
                content_items.append({
                    'type': 'table',
                    'rows': table_rows,
                    'images': []  # 表格中的图片已经在单元格中标记了
                })
    
    # 收集所有图片（包括表格中的）
    all_images = set()
    for item in content_items:
        if item['type'] == 'paragraph':
            all_images.update(item['images'])
        elif item['type'] == 'table':
            # 从表格单元格中提取图片
            for row in item['rows']:
                for cell in row:
                    if isinstance(cell, dict) and cell.get('images'):
                        all_images.update(cell['images'])
    
    # 复制图片到输出目录（方便引用）
    media_dir = os.path.join(output_dir, "word/media")
    if os.path.exists(media_dir):
        for img_file in os.listdir(media_dir):
            if img_file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                src = os.path.join(media_dir, img_file)
                dst = os.path.join(output_dir, img_file)
                shutil.copy2(src, dst)
    
    return content_items, output_dir


def generate_markdown(content_items, output_dir, docx_basename, image_analysis=None):
    """
    生成完整版Markdown文档
    
    Args:
        content_items: 内容项列表
        output_dir: 输出目录
        docx_basename: Word文档基础名称（不含扩展名）
        image_analysis: 图片分析字典，格式：{image_filename: {title: str, description: str}}
    """
    md_content = [f"# {docx_basename} PRD文档\n\n"]
    md_content.append("> 本文档由AI自动从Word文档提取并转换，包含文本内容和图片引用，图片保持在原始位置\n")
    md_content.append("> 注意：图片分析将在阶段一的图片分析步骤中由AI多模态能力识别后添加\n\n")
    
    # 中文数字映射
    chinese_numbers = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', 
                      '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十',
                      '二十一', '二十二', '二十三', '二十四', '二十五', '二十六', '二十七', '二十八', '二十九', '三十']
    
    # 第一步：收集所有图片（包括段落和表格中的），并分配全局编号
    global_image_counter = 0
    image_to_label = {}  # 图片文件名 -> 全局编号标签（如"图片一"）
    
    for item in content_items:
        if item['type'] == 'paragraph':
            # 段落中的图片
            for img in item['images']:
                if img not in image_to_label:
                    label = f"图片{chinese_numbers[global_image_counter % len(chinese_numbers)]}"
                    image_to_label[img] = label
                    global_image_counter += 1
        elif item['type'] == 'table':
            # 表格中的图片
            for row in item['rows']:
                for cell in row:
                    if isinstance(cell, dict) and cell.get('images'):
                        for img in cell['images']:
                            if img not in image_to_label:
                                label = f"图片{chinese_numbers[global_image_counter % len(chinese_numbers)]}"
                                image_to_label[img] = label
                                global_image_counter += 1
    
    # 第二步：生成Markdown内容
    for item in content_items:
        if item['type'] == 'paragraph':
            # 处理段落
            # 先输出文本（如果有）
            if item['text']:
                md_content.append(f"{item['text']}\n\n")
            
            # 然后在文本后插入图片和分析（如果有）- 保持原始位置
            if item['images']:
                for img in item['images']:
                    md_content.append(f"![{img}](prd_extracted/{img})\n\n")
                    
                    # 添加图片分析（如果有）
                    if image_analysis and img in image_analysis:
                        analysis = image_analysis[img]
                        md_content.append(f"**图片分析：{analysis.get('title', img)}**\n\n")
                        md_content.append(f"{analysis.get('description', '')}\n\n")
                        
                        # 添加与文本的关联说明
                        if 'context' in analysis:
                            md_content.append(f"**与文本的关联：** {analysis['context']}\n\n")
        
        elif item['type'] == 'table':
            # 处理表格
            rows = item['rows']
            if not rows:
                continue
            
            # 收集当前表格中的所有图片（使用全局编号）
            table_images = []
            
            # 生成Markdown表格
            md_content.append("\n")
            
            # 表头（第一行作为表头）
            header_row = rows[0]
            clean_header = []
            for cell in header_row:
                if isinstance(cell, dict):
                    cell_text = cell.get('text', '').strip()
                    if cell.get('images'):
                        # 使用全局编号
                        labels = [image_to_label[img] for img in cell['images'] if img in image_to_label]
                        table_images.extend([(img, image_to_label[img]) for img in cell['images'] if img in image_to_label])
                        if labels:
                            cell_text = f"{cell_text} [{', '.join(labels)}]" if cell_text else f"[{', '.join(labels)}]"
                    clean_header.append(cell_text or ' ')
                else:
                    clean_header.append(str(cell).strip() or ' ')
            
            md_content.append("| " + " | ".join(clean_header) + " |\n")
            md_content.append("| " + " | ".join(["---"] * len(header_row)) + " |\n")
            
            # 数据行（从第二行开始，如果有的话）
            if len(rows) > 1:
                for row in rows[1:]:
                    clean_row = []
                    for cell in row:
                        if isinstance(cell, dict):
                            cell_text = cell.get('text', '').strip()
                            if cell.get('images'):
                                # 使用全局编号
                                labels = [image_to_label[img] for img in cell['images'] if img in image_to_label]
                                table_images.extend([(img, image_to_label[img]) for img in cell['images'] if img in image_to_label])
                                if labels:
                                    cell_text = f"{cell_text} [{', '.join(labels)}]" if cell_text else f"[{', '.join(labels)}]"
                            clean_row.append(cell_text or ' ')
                        else:
                            clean_row.append(str(cell).strip() or ' ')
                    
                    md_content.append("| " + " | ".join(clean_row) + " |\n")
            
            md_content.append("\n")
            
            # 在表格后显示当前表格中的所有图片及其编号引用（去重）
            if table_images:
                # 去重但保持顺序
                seen = set()
                unique_table_images = []
                for img, label in table_images:
                    if img not in seen:
                        seen.add(img)
                        unique_table_images.append((img, label))
                
                md_content.append("**表格中的图片：**\n\n")
                for img, label in unique_table_images:
                    md_content.append(f"**[{label}]** ![{img}](prd_extracted/{img})\n\n")
                    
                    # 添加图片分析（如果有）
                    if image_analysis and img in image_analysis:
                        analysis = image_analysis[img]
                        md_content.append(f"**图片分析：{analysis.get('title', img)}**\n\n")
                        md_content.append(f"{analysis.get('description', '')}\n\n")
                        
                        # 添加与文本的关联说明
                        if 'context' in analysis:
                            md_content.append(f"**与文本的关联：** {analysis['context']}\n\n")
    
    # 保存Markdown文件（只生成一个文档）
    md_file = os.path.join(os.path.dirname(output_dir), f"{docx_basename}.md")
    with open(md_file, 'w', encoding='utf-8') as f:
        f.write(''.join(md_content))
    
    return md_file


def load_image_analysis(json_file):
    """加载图片分析JSON文件"""
    if json_file and os.path.exists(json_file):
        with open(json_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def cleanup_extracted_dir(output_dir):
    """
    清理提取目录，只保留图片文件
    
    Args:
        output_dir: 输出目录路径
    """
    if not os.path.exists(output_dir):
        return
    
    # 保留的图片扩展名
    image_extensions = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp')
    
    # 遍历目录，删除非图片文件和所有子目录
    # 注意：图片文件已经在extract_word_content中复制到output_dir根目录了
    items_to_process = list(os.listdir(output_dir))
    
    for item in items_to_process:
        item_path = os.path.join(output_dir, item)
        
        if os.path.isdir(item_path):
            # 删除所有子目录（word/, _rels/等）
            try:
                shutil.rmtree(item_path)
            except Exception as e:
                print(f"警告：无法删除目录 {item_path}: {e}", file=sys.stderr)
        elif os.path.isfile(item_path):
            # 删除非图片文件
            if not item.lower().endswith(image_extensions):
                try:
                    os.remove(item_path)
                except Exception as e:
                    print(f"警告：无法删除文件 {item_path}: {e}", file=sys.stderr)
    
    print(f"已清理中间文件，只保留图片在目录: {output_dir}")


def main():
    parser = argparse.ArgumentParser(description='Word文档转Markdown工具')
    parser.add_argument('word_file', help='Word文档路径（.docx格式）')
    parser.add_argument('output_dir', help='输出目录')
    parser.add_argument('--image-analysis', help='图片分析JSON文件路径（可选）')
    
    args = parser.parse_args()
    
    # 检查Word文件是否存在
    if not os.path.exists(args.word_file):
        print(f"错误：Word文件不存在: {args.word_file}", file=sys.stderr)
        sys.exit(1)
    
    # 获取Word文档基础名称
    docx_basename = Path(args.word_file).stem
    
    # 提取Word内容
    print(f"正在提取Word文档内容: {args.word_file}")
    content_items, extracted_dir = extract_word_content(args.word_file, args.output_dir)
    print(f"提取完成，共 {len(content_items)} 个内容项")
    
    # 加载图片分析（如果有）
    image_analysis = None
    if args.image_analysis:
        image_analysis = load_image_analysis(args.image_analysis)
        if image_analysis:
            print(f"已加载图片分析: {len(image_analysis)} 张图片")
    
    # 生成Markdown（只生成一个文档）
    md_file = generate_markdown(content_items, extracted_dir, docx_basename, image_analysis)
    print(f"Markdown文件已生成: {md_file}")
    
    # 清理提取目录，只保留图片文件
    cleanup_extracted_dir(extracted_dir)
    
    # 统计信息
    paragraph_count = len([item for item in content_items if item['type'] == 'paragraph' and item['text']])
    table_count = len([item for item in content_items if item['type'] == 'table'])
    
    # 统计图片数量
    image_count = 0
    for item in content_items:
        if item['type'] == 'paragraph':
            image_count += len(item['images'])
        elif item['type'] == 'table':
            # 从表格中提取图片
            for row in item['rows']:
                for cell in row:
                    if isinstance(cell, dict) and cell.get('images'):
                        image_count += len(cell['images'])
    
    print(f"\n统计信息:")
    print(f"  - 文本段落数: {paragraph_count}")
    print(f"  - 表格数量: {table_count}")
    print(f"  - 图片数量: {image_count}")
    print(f"  - 图片目录: {extracted_dir}（已清理中间文件，只保留图片）")


if __name__ == '__main__':
    main()
