# sdd-driven-dev

基于需求文档驱动的 AI 需求开发工作流（通用版）。可选结合 SDD 知识库，但不要求与 `sdd-builder` 系统级自动串联；推荐由人工在合适时机衔接。支持通用主流框架，并可通过 `references/company-frameworks/` 扩展公司内部框架说明。

## 功能概述

通过 **需求分析 → 技术方案生成 → 人工校验 → 执行开发 → 开发结果验证** 的六阶段流程，确保开发方案符合业务预期。若已有 SDD 文档可直接复用；若没有，也可直接基于 PRD 执行。

## 安装步骤

### 步骤 1：将 skill 放入项目或全局 skills 目录

```
# 项目级
.cursor/skills/sdd-driven-dev/

# 个人全局
~/.cursor/skills/sdd-driven-dev/
```

### 步骤 2：准备知识库（可选）

若你希望结合 SDD 加速分析，可准备知识库工程并包含：
- SDD 文档目录
- 快速参考文档（`ai-quick-reference.md`），记录 SDD 路径、规范文档路径、经验沉淀路径
- 默认固定目录建议：`./docs/sdd-kb/`（即 `KB_ROOT`）

若不使用知识库，也可直接开始：在阶段一提供 `REQ_ROOT` 与 PRD 文件路径即可（默认 `REQ_ROOT` 为 `./docs/sdd-kb/ai-dev-requests/{年}/{月}/{需求名称}/`）。

### 步骤 3：配置公司内部框架说明（可选但推荐）

将贵公司的内部框架使用文档放入 `references/company-frameworks/` 目录，并填写 `index.yaml`：

```yaml
frameworks:
  - name: "公司内部RPC框架"
    file: "references/company-frameworks/xxx-rpc-guide.md"
    trigger_keywords: ["@XxxService", "@XxxReference", "XxxClient"]
  - name: "公司内部KV存储"
    file: "references/company-frameworks/xxx-kv-guide.md"
    trigger_keywords: ["XxxKvClient", "kvGet", "kvSet"]
```

配置后，AI 在阶段三/阶段五遇到对应组件时，将优先读取公司说明，再参考通用框架文档。

**详细说明见** [`references/company-frameworks/SETUP.md`](references/company-frameworks/SETUP.md)

### 步骤 4：触发工作流

在 AI 对话中说出以下任意关键词：

- `执行AI开发需求工作流程`
- `基于SDD文档开发需求`
- `AI开发需求`
- `需求开发工作流程`

## 六阶段流程

| 阶段 | 名称 | 模式 |
|------|------|------|
| 一 | PRD 获取 | 半自动 |
| 二 | 需求分析与代码探索 | 循环+人工确认 |
| 三 | 技术方案生成 | 全自动 |
| 四 | 人工校验与技术方案迭代 | 人工驱动 |
| 五 | 执行开发 | 自动循环 |
| 六 | 开发结果验证 | 按需执行 |

## 内置工具

| 工具 | 触发方式 | 输出 |
|------|---------|------|
| 反馈上报 | `提交反馈` | 优先 `${KB_ROOT}/skill-feedback/`，无 `KB_ROOT` 则 `${REQ_ROOT}/feedback/` |
| SDD 缺口清单 | 阶段四自动 / 手动触发 | 本地 `${REQ_ROOT}/SDD缺口清单.md`（有 `KB_ROOT` 时额外归档到 `${KB_ROOT}/sdd-gaps/`） |
| 测试 Bug 分析 | `分析测试提的bug` | 本地 `${REQ_ROOT}/测试Bug分析总结.md`（有 `KB_ROOT` 时额外归档到 `${KB_ROOT}/bug-summaries/`） |
| AI 自动 CR | `执行AI自动CR` | `${REQ_ROOT}/AI-CR报告.md` |
| 测试 Case 验证 | `测试Case验证` | `${REQ_ROOT}/测试Case验证报告.md` |

## 通用框架使用说明

`references/通用框架使用说明/` 内置以下文档：

- Spring MVC
- MyBatis-Plus
- Redis
- 消息队列（RocketMQ + Kafka）
- Dubbo（含 RPC 字段有序规则）
- gRPC（含 proto field number 规则）
- Thrift（含 field id 规则）
