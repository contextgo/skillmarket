# 配置模板

以下以 2 个 agent 为例（`main` 和 `agent-b`），可扩展至更多。

## openclaw.json 关键片段

```json5
{
  // ── 1. Agent 定义 ──
  "agents": {
    "list": [
      {
        "id": "main",
        "default": true,
        "name": "虾头",
        "workspace": "C:\\Users\\you\\.openclaw\\workspace"
      },
      {
        "id": "agent-b",
        "name": "小助手",
        "workspace": "C:\\Users\\you\\.openclaw\\workspace-agent-b"
      }
    ]
  },

  // ── 2. 飞书多账号配置 ──
  "channels": {
    "feishu": {
      "enabled": true,
      "connectionMode": "websocket",
      "requireMention": true,           // 群聊需 @机器人 才回复
      "defaultAccount": "main",         // 默认账号

      // 每个飞书应用一组凭据
      "accounts": {
        "main": {
          "appId": "cli_aaaaaaa",        // 飞书应用 AppID
          "appSecret": "xxxxxx",         // 飞书应用 AppSecret
          "name": "虾头"
        },
        "agent-b": {
          "appId": "cli_bbbbbbb",
          "appSecret": "yyyyyy",
          "name": "小助手"
        },
        // 共享的访问控制策略（放在 "default" 账号下）
        "default": {
          "dmPolicy": "allowlist",
          "allowFrom": [
            "ou_your_open_id"            // 允许私聊的用户
          ],
          "groupPolicy": "allowlist",
          "groupAllowFrom": [
            "ou_your_open_id"            // 允许在群聊中触发的用户
          ]
        }
      },

      // 群聊配置（可选，按群 ID 覆盖）
      "groups": {
        "*": {
          "enabled": true                // 通配：所有群都启用
        }
      }
    }
  },

  // ── 3. 绑定规则：飞书账号 → Agent ──
  "bindings": [
    {
      "agentId": "main",
      "match": {
        "channel": "feishu",
        "accountId": "main"
      }
    },
    {
      "agentId": "agent-b",
      "match": {
        "channel": "feishu",
        "accountId": "agent-b"
      }
    }
  ],

  // ── 4. 插件配置 ──
  "plugins": {
    "entries": {
      "openclaw-lark": {
        "enabled": true                  // 必须启用
      }
    },
    "allow": ["openclaw-lark"]
  }
}
```

## 绑定规则说明

路由优先级（从高到低）：

1. **peer 匹配** — 指定 chat_id / user_id 精确匹配
2. **accountId 匹配** — 按飞书账号绑定（本方案使用）
3. **channel 匹配** — 整个飞书渠道
4. **默认 agent** — `agents.list` 中 `default: true` 的

每个 binding 使用 `match.accountId` 匹配飞书账号，不同飞书应用的事件由各自的 WebSocket 连接接收，通过 `accountId` 区分。

## 扩展到 3+ 个 Agent

只需：
1. 创建新飞书应用，记录 AppID/Secret
2. 在 `agents.list` 添加新 agent
3. 在 `channels.feishu.accounts` 添加新账号
4. 在 `bindings` 添加新绑定
5. `openclaw gateway restart`
