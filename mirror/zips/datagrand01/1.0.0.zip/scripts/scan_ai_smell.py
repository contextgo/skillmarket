#!/usr/bin/env python3
"""
AI 味快速扫描脚本

用途：对一段文本进行快速的 AI 味关键词扫描，辅助 AI 做自检。
这不是替代 AI 的人工判断，而是帮他快速定位潜在问题。

使用方法：
  python scan_ai_smell.py <文本文件路径>
  或
  echo "要扫描的文本" | python scan_ai_smell.py -

输出：JSON 格式的扫描结果，包含命中的类别、位置、具体词句。
"""

import sys
import json
import re

# AI 味词库（按类别组织，与 anti-ai-patterns.md 对应）
PATTERNS = {
    "A_开头套路": [
        r"在这个(快速变化|快节奏|充满不确定性|信息爆炸|数字化)的时代",
        r"你是否也曾",
        r"你是否发现",
        r"不知道从什么时候开始",
        r"最近.{0,10}一词频繁出现",
        r"随着.{0,20}的(发展|普及|到来|兴起)",
        r"在当今(社会|时代)",
        r"提到.{0,10}，你会想到什么",
        r"相信大家都(听说过|知道)",
        r"无疑是.{0,20}年最.{0,5}的话题之一",
    ],
    "B_过渡粘合剂": [
        r"值得一提的是",
        r"不难发现",
        r"归根结底",
        r"那么接下来",
        r"与此同时",
        r"事实上",
        r"进一步来说",
        r"从另一个角度看",
        r"毋庸置疑",
        r"总的来说",
    ],
    "C_结尾套路": [
        r"希望.{0,10}对你.{0,5}(有所)?帮助",
        r"评论区(告诉我|见|留言)",
        r"别忘了点赞",
        r"让我们一起",
        r"路漫漫其修远兮",
        r"未来已来",
        r"与君共勉",
        r"愿我们都能",
    ],
    "E1_商业黑话": [
        r"赋能",
        r"闭环",
        r"底层逻辑",
        r"颗粒度",
        r"打法",
        r"抓手",
        r"拉通",
        r"对齐",
        r"盘一盘",
        r"长期主义",
    ],
    "E2_假金句句式": [
        r"不是.{1,20}，而是.{1,20}。.{0,100}不是.{1,20}，而是",  # 连续"不是X而是Y"
    ],
    "F_伪引用": [
        r"据相关研究表明",
        r"有数据显示",
        r"研究发现",
        r"专家认为",
        r"业内人士指出",
        r"众所周知",
        r"大家都知道",
        r"早在.{0,5}年",
        r"超过\d+%的人",
        r"根据一项调查",
    ],
}


def scan_text(text: str) -> dict:
    """扫描文本，返回按类别组织的命中结果"""
    results = {
        "total_hits": 0,
        "categories": {},
        "severity": "clean",  # clean / minor / serious / severe
    }
    
    for category, patterns in PATTERNS.items():
        hits = []
        for pattern in patterns:
            for match in re.finditer(pattern, text):
                # 找出这次命中所在的段落（以换行为界）
                start = match.start()
                # 往前找最近的换行或开头
                line_start = text.rfind('\n', 0, start) + 1
                line_end = text.find('\n', start)
                if line_end == -1:
                    line_end = len(text)
                context = text[line_start:line_end].strip()
                
                hits.append({
                    "matched": match.group(),
                    "position": start,
                    "context": context[:100] + ("..." if len(context) > 100 else ""),
                })
        
        if hits:
            results["categories"][category] = {
                "count": len(hits),
                "hits": hits,
            }
            results["total_hits"] += len(hits)
    
    # 评估严重程度
    if results["total_hits"] == 0:
        results["severity"] = "clean"
    elif "F_伪引用" in results["categories"]:
        results["severity"] = "severe"  # 伪引用最严重
    elif results["total_hits"] >= 5:
        results["severity"] = "serious"
    else:
        results["severity"] = "minor"
    
    return results


def format_report(results: dict) -> str:
    """格式化输出人类友好的报告"""
    lines = []
    lines.append("=" * 60)
    lines.append("AI 味扫描报告")
    lines.append("=" * 60)
    lines.append(f"总命中数: {results['total_hits']}")
    lines.append(f"严重程度: {results['severity'].upper()}")
    lines.append("")
    
    if results["total_hits"] == 0:
        lines.append("✓ 未检测到常见 AI 味模式。")
        lines.append("")
        lines.append("注意：本脚本只扫描关键词，")
        lines.append("更深层的 AI 味（结构套路、语感问题）需要 AI 人工判断。")
        return "\n".join(lines)
    
    for category, data in results["categories"].items():
        lines.append(f"【{category}】 - {data['count']} 处")
        for hit in data["hits"]:
            lines.append(f"  ❌ 命中: \"{hit['matched']}\"")
            lines.append(f"     上下文: {hit['context']}")
        lines.append("")
    
    lines.append("-" * 60)
    lines.append("建议：")
    if "F_伪引用" in results["categories"]:
        lines.append("⚠ 严重问题：存在伪引用。必须补充具体来源或删除。")
    if "E1_商业黑话" in results["categories"]:
        lines.append("⚠ 存在商业黑话，考虑替换为具体表达。")
    if "A_开头套路" in results["categories"] or "C_结尾套路" in results["categories"]:
        lines.append("⚠ 开头/结尾有套路，需要重写。")
    if "B_过渡粘合剂" in results["categories"]:
        lines.append("ℹ AI 过渡词较多，考虑直接删除或改为硬切。")
    
    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("用法: python scan_ai_smell.py <文件路径>")
        print("      或: echo '文本' | python scan_ai_smell.py -")
        sys.exit(1)
    
    if sys.argv[1] == "-":
        text = sys.stdin.read()
    else:
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            text = f.read()
    
    results = scan_text(text)
    
    # 如果有 --json 参数，输出 JSON
    if "--json" in sys.argv:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print(format_report(results))


if __name__ == "__main__":
    main()
