---
name: work-request-prompter
description: Generate precise, business-matched execution prompts from vague workplace requests. Use when a user describes a daily work task, urgent boss request, report, spreadsheet, research brief, policy scan, meeting material, analysis, summary, or presentation need and wants a reusable method, search prompt, execution prompt, or workflow prompt that helps them find the right content and produce a useful deliverable.
---

# Work Request Prompter

## Purpose

Transform an informal workplace request into a clear execution prompt that another AI agent, researcher, analyst, or coworker can follow. Optimize for practical business delivery: define the goal, lock the scope, design the structure, gather information, clean it, analyze it, conclude, and check quality.

## Core Workflow

Use this sequence for every request:

1. **Clarify the business goal**
   Identify who will use the result, what decision or action it supports, the expected deliverable, the deadline, and the required depth.

2. **Define the scope and data standard**
   Specify geography, time range, organization type, industry, source requirements, inclusion/exclusion rules, and what counts as valid evidence.

3. **Design the output frame first**
   Draft the table fields, report outline, slide structure, tags, scoring dimensions, or comparison matrix before collecting material.

4. **Plan targeted collection**
   Convert the scope into search paths, keywords, official sources, internal sources, public datasets, interview questions, or document lists.

5. **Normalize and clean**
   Require consistent names, dates, units, categories, source links, deduplication, status labels, and missing-field handling.

6. **Analyze for business use**
   Ask for grouping, ranking, prioritization, opportunity/risk labels, applicability to the user's business, and concise findings.

7. **Generate conclusions and next actions**
   Require a short executive summary, key findings, recommended actions, caveats, and follow-up data gaps.

8. **Add delivery checks**
   Include checks for source reliability, consistency, completeness, expired information, formatting, and whether a busy stakeholder can understand the result quickly.

## Output Requirements

Answer in Chinese unless the user requests another language.

Produce a ready-to-copy prompt, not only an explanation. The prompt must be tailored to the user's task and should include:

- Role: the expert persona needed for the task.
- Background: restate the workplace situation and business objective.
- Scope: define boundaries and assumptions.
- Deliverable: specify exact file/report/table/slide output.
- Method: use the 8-step workflow above.
- Source strategy: list concrete source types and keyword patterns when research is needed.
- Output structure: include table fields or report sections.
- Quality rules: source, data, formatting, and usability checks.
- Clarifying questions: include only the few questions that materially affect the result; otherwise state reasonable assumptions.

If the user asks for "方法论", explain the generalized steps first, then provide the reusable prompt template.

If the user gives a concrete task, generate a task-specific prompt directly. Do not make the user fill a long template unless the task is too ambiguous to proceed.

## Business Adaptation Heuristics

Map the request to the likely deliverable:

- "Excel", "清单", "数据", "名单": create field schema, data source rules, normalization rules, and summary sheet requirements.
- "汇报", "PPT", "明天要用": create executive summary, slide outline, speaker logic, evidence list, and fast-priority scope.
- "政策", "扶持", "补贴", "申报": require official sources, policy validity, eligibility, amount, deadline, application route, and risk notes.
- "竞品", "市场", "行业": require comparison dimensions, market segmentation, evidence sources, and insight summary.
- "会议", "访谈", "调研": require objective, question list, respondent/source selection, synthesis framework, and decision output.
- "复盘", "总结", "周报": require facts, progress, blockers, impact, next steps, and responsibility/date fields.

For more detailed prompt patterns and examples, load `references/prompt-patterns.md` only when useful.
