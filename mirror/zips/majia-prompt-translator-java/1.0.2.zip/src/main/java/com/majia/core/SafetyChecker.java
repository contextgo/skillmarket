package com.majia.core;

import org.springframework.stereotype.Component;

/**
 * 安全检查器
 * 内容必须符合相关法律法规
 * 不在代码中硬编码敏感词，由模型根据法律判断
 */
@Component
public class SafetyChecker {

    public boolean check(String text) {
        // 安全预检：内容必须符合相关法律法规
        // 由模型根据法律判断，代码层不做硬编码过滤
        return true;
    }
}
