﻿package com.majia;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.*;

public class MajiaLocal {
    private String sp;
    private Path rulesPath, prefsPath, historyPath;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Yaml yaml = new Yaml();
    private Map<String, Object> prefs = new HashMap<>();
    private Map<String, Object> config = new HashMap<>();

    public MajiaLocal(String storagePath) throws IOException {
        this.sp = (storagePath==null||storagePath.isEmpty()) ? findPath() : storagePath;
        this.rulesPath = Paths.get(sp,"rules");
        this.prefsPath = Paths.get(sp,"preferences");
        this.historyPath = Paths.get(sp,"history");
        Files.createDirectories(rulesPath); Files.createDirectories(prefsPath); Files.createDirectories(historyPath);
        loadPrefs(); loadConfig();
    }

    private String findPath() throws IOException {
        for (String f : new String[]{"SKILL.md","../SKILL.md"}) {
            if (Files.exists(Paths.get(f))) {
                String c = new String(Files.readAllBytes(Paths.get(f)));
                Matcher m = Pattern.compile("(?m)^storage_path:\\s*(.+)$").matcher(c);
                if (m.find()) return m.group(1).trim();
            }
        }
        return "./storage";
    }

    private void loadPrefs() throws IOException {
        File pf = prefsPath.resolve("preferences.json").toFile();
        if (pf.exists()) prefs = mapper.readValue(pf, Map.class);
        else { prefs.put("domain_history", new ArrayList<>()); prefs.put("updated",""); prefs.put("last_session",""); }
    }

    private void loadConfig() throws IOException {
        File cf = Paths.get(sp,"config.json").toFile();
        if (cf.exists()) config = mapper.readValue(cf, Map.class);
        else { config.put("api", new HashMap<>()); ((Map)config.get("api")).put("enabled",false); }
    }

    @SuppressWarnings("unchecked")
    private String[] classify(String t) {
        Map<String, Integer> sc = new HashMap<>();
        try {
            for (File f : Files.list(rulesPath).toArray(File[]::new)) {
                if (!f.getName().endsWith(".yaml")) continue;
                Map<String, Object> c = yaml.load(new FileReader(f));
                if (c==null) continue;
                List<String> kws = (List<String>)c.getOrDefault("keywords", Collections.emptyList());
                int s=0; for (String k: kws) if (t.contains(k)) s++;
                if (s>0) sc.put((String)c.getOrDefault("name",f.getName().replace(".yaml","")), s);
            }
        } catch (IOException e) {}
        if (!sc.isEmpty()) {
            String best = Collections.max(sc.entrySet(), Map.Entry.comparingByValue()).getKey();
            int total = sc.values().stream().mapToInt(Integer::intValue).sum();
            return new String[]{best, String.format("%.0f", (double)sc.get(best)/total*100)};
        }
        return new String[]{"通用", "50"};
    }

    @SuppressWarnings("unchecked")
    private List<Map<String,Object>> rag(String q, String d) {
        List<Map<String,Object>> r = new ArrayList<>();
        try {
            for (File f : Files.list(rulesPath).toArray(File[]::new)) {
                if (!f.getName().endsWith(".yaml")) continue;
                Map<String, Object> c = yaml.load(new FileReader(f));
                if (c==null) continue;
                double s = 0;
                for (String k : (List<String>)c.getOrDefault("keywords", Collections.emptyList())) if (q.contains(k)) s+=0.3;
                Map<String,String> terms = (Map<String,String>)c.get("terminology");
                if (terms!=null) for (String t : terms.keySet()) if (q.contains(t)) s+=0.2;
                s = Math.min(s, 1.0);
                if (s>=0.3) { Map<String,Object> m = new HashMap<>(); m.put("file",f.getName()); m.put("content",c); m.put("score",s); r.add(m); }
            }
        } catch (IOException e) {}
        r.sort((a,b) -> Double.compare((Double)b.get("score"),(Double)a.get("score")));
        return r.subList(0, Math.min(3, r.size()));
    }

    private String buildContext(String inp, String d, List<Map<String,Object>> rs) {
        StringBuilder sb = new StringBuilder();
        sb.append("你是马甲系统，用户输入：").append(inp).append("\n识别领域：").append(d);
        if (!rs.isEmpty()) {
            sb.append("\n相关规则：");
            for (int i=0;i<Math.min(2,rs.size());i++) {
                Map<String,Object> c = (Map<String,Object>)rs.get(i).get("content");
                if (c.containsKey("terminology")) sb.append("\n术语：").append(c.get("terminology"));
                Map<String,Object> qs = (Map<String,Object>)c.get("questions");
                if (qs!=null && qs.containsKey("must_have")) {
                    List<String> must = (List<String>)qs.get("must_have");
                    sb.append("\n追问：").append(String.join(", ", must.subList(0, Math.min(3, must.size()))));
                }
            }
        }
        sb.append("\n直接回应，不使用表格。");
        return sb.toString();
    }

    private String callApi(String ctx) {
        Map<String,Object> api = (Map<String,Object>)config.getOrDefault("api", new HashMap<>());
        if (!(Boolean)api.getOrDefault("enabled",false)) return "[未配置API]\n\n"+ctx;
        try {
            String url = api.get("base_url") + "/chat/completions";
            String body = String.format("{\"model\":\"%s\",\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}],\"temperature\":0.7,\"max_tokens\":1024}",
                api.getOrDefault("model","gpt-4"), ctx.replace("\"","\\\"").replace("\n","\\n"));
            HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type","application/json");
            conn.setRequestProperty("Authorization","Bearer "+api.get("api_key"));
            conn.setDoOutput(true);
            conn.getOutputStream().write(body.getBytes("UTF-8"));
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"));
            StringBuilder resp = new StringBuilder(); String line;
            while ((line=br.readLine())!=null) resp.append(line);
            br.close();
            return resp.toString();
        } catch (Exception e) { return "API错误："+e.getMessage(); }
    }

    @SuppressWarnings("unchecked")
    private void savePrefs(String d, String sid) {
        List<String> hist = (List<String>)prefs.get("domain_history");
        if (!hist.contains(d)) hist.add(d);
        prefs.put("updated", LocalDateTime.now().toString());
        prefs.put("last_session", sid);
        try { mapper.writeValue(prefsPath.resolve("preferences.json").toFile(), prefs); } catch (IOException e) {}
    }

    public ObjectNode process(String inp) throws IOException {
        ObjectNode result = mapper.createObjectNode();
        String[] cl = classify(inp);
        String d = cl[0]; double conf = Double.parseDouble(cl[1])/100.0;
        List<Map<String,Object>> rs = rag(inp, d);
        String res = callApi(buildContext(inp, d, rs));
        String sid = UUID.randomUUID().toString();
        savePrefs(d, sid);
        result.put("status","success"); result.put("session_id",sid); result.put("domain",d);
        result.put("confidence",conf); result.put("response",res); result.put("rules",rs.size());
        return result;
    }

    @SuppressWarnings("unchecked")
    public Map<String,Object> parse(String text) throws IOException {
        String sid = LocalDateTime.now().toString().replace(":","-").substring(0,19);
        List<String> u = new ArrayList<>(), a = new ArrayList<>();
        Matcher um = Pattern.compile("^(用户|User|我)[:：]\\s*(.*)$", Pattern.MULTILINE).matcher(text);
        while (um.find()) u.add(um.group(2));
        Matcher am = Pattern.compile("^(AI|助手|Assistant|马甲)[:：]\\s*(.*)$", Pattern.MULTILINE).matcher(text);
        while (am.find()) a.add(am.group(2));
        List<String> blocks = new ArrayList<>();
        Matcher bm = Pattern.compile("```[\\w]*\\n([\\s\\S]*?)```").matcher(text);
        while (bm.find()) { String b=bm.group(1).trim(); if(b.length()>20) blocks.add(b); }
        Map<String,Object> data = new HashMap<>();
        data.put("id", sid); data.put("timestamp", LocalDateTime.now().toString());
        data.put("user_turns", u.size()); data.put("ai_turns", a.size());
        data.put("user_last", u.isEmpty()?"":u.get(u.size()-1));
        data.put("ai_last", a.isEmpty()?"":a.get(a.size()-1));
        data.put("full_text", text);
        mapper.writeValue(historyPath.resolve(sid+".json").toFile(), data);
        for (int i=0;i<blocks.size();i++) Files.write(rulesPath.resolve("rule-"+sid+"-"+i+".md"), blocks.get(i).getBytes());
        return data;
    }

    public Map<String,Object> getPrefs() { return prefs; }

    public static void main(String[] args) throws IOException {
        MajiaLocal m = new MajiaLocal(null);
        System.out.println("马甲系统 Java 本地版");
        System.out.println("输入 quit 退出");
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("> ");
            String inp = sc.nextLine().trim();
            if (inp.isEmpty()) continue;
            if (inp.equalsIgnoreCase("quit")) break;
            ObjectNode r = m.process(inp);
            System.out.println("["+r.get("domain")+"|"+r.get("confidence")+"|规则:"+r.get("rules")+"]\n"+r.get("response"));
        }
    }
}
