package com.majia.core;

import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 领域分类器
 * 不硬编码任何具体领域，从已存储的 domains/*.yaml 中动态加载关键词
 */
@Component
public class DomainClassifier {

    private double confidence = 0.5;
    private String domainsPath = "./domains";
    private final Yaml yaml = new Yaml();

    /**
     * 动态分类领域
     * 从本地 domains/ 文件夹读取所有领域规则，通过关键词匹配判断当前输入属于哪个领域
     */
    public String classify(String text) {
        File dir = new File(domainsPath);
        if (!dir.exists() || !dir.isDirectory()) {
            confidence = 0.5;
            return "通用";
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".yaml"));
        if (files == null || files.length == 0) {
            confidence = 0.5;
            return "通用";
        }

        Map<String, Integer> scores = new HashMap<>();

        for (File file : files) {
            try (FileReader reader = new FileReader(file)) {
                Map<String, Object> content = yaml.load(reader);
                if (content == null) continue;

                String domainName = (String) content.getOrDefault("name", file.getName().replace(".yaml", ""));
                @SuppressWarnings("unchecked")
                List<String> keywords = (List<String>) content.get("keywords");
                if (keywords == null) continue;

                int score = 0;
                for (String keyword : keywords) {
                    if (text.contains(keyword)) {
                        score++;
                    }
                }
                if (score > 0) {
                    scores.put(domainName, score);
                }
            } catch (IOException e) {
                // 跳过读取失败的文件
            }
        }

        if (!scores.isEmpty()) {
            String bestDomain = scores.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("通用");

            int total = scores.values().stream().mapToInt(Integer::intValue).sum();
            confidence = (double) scores.get(bestDomain) / total;
            return bestDomain;
        }

        confidence = 0.5;
        return "通用";
    }

    public double getConfidence() {
        return confidence;
    }

    public void setDomainsPath(String domainsPath) {
        this.domainsPath = domainsPath;
    }
}
