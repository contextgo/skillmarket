package com.majia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 马甲系统启动类
 */
@SpringBootApplication
public class MajiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MajiaApplication.class, args);
    }
}
