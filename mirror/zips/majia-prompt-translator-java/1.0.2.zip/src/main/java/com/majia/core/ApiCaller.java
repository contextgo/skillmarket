package com.majia.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.majia.model.Domain;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * API 调用器
 * 支持 OpenAI 兼容接口（openai / deepseek / zhipu / moonshot / 自定义）
 * 负责组装最小化上下文，减少 Token 消耗
 */
@Component
public class ApiCaller {

    @Value("${majia.api.enabled:false}")
    private boolean apiEnabled;

    @Value("${majia.api.base-url:https://api.openai.com/v1}")
    private String baseUrl;

    @Value("${majia.api.api-key:}")
    private String apiKey;

    @Value("${majia.api.model:gpt-4}")
    private String model;

    @Value("${majia.api.timeout:60}")
    private int timeout;

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 组装最小化上下文并调用模型
     * 只传必要内容，减少 Token 消耗
     */
    public String call(String userInput, String domain, List<Domain> rules) {
        // 组装最小化上下文（代码层）
        String context = buildContext(userInput, domain, rules);

        if (!apiEnabled) {
            // 未配置 API，输出结构化上下文，供用户复制到 AI 助手使用
            return "[未配置API，请将以下内容复制到你的AI助手]\n\n" + context;
        }

        return callApi(context);
    }

    /**
     * 快车道调用（热启动）
     * 只注入极短的偏好包，Token消耗约 50-100
     */
    public String callFastLane(String userInput, String preferencePack) {
        String context = "用户输入：" + userInput + "\n偏好包：" + preferencePack + "\n请直接输出结果，简洁为主。";

        if (!apiEnabled) {
            return "[未配置API]\n\n" + context;
        }

        return callApiFast(context);
    }

    /**
     * 代码层组装最小化上下文
     * 只传与当前请求相关的术语和追问建议，不传整个规则文件
     */
    private String buildContext(String userInput, String domain, List<Domain> rules) {
        StringBuilder sb = new StringBuilder();
        sb.append("你是马甲系统，一个专业的意图翻译专家。\n");
        sb.append("用户输入：").append(userInput).append("\n");
        sb.append("识别领域：").append(domain).append("\n");

        if (rules != null && !rules.isEmpty()) {
            sb.append("相关规则（仅供参考）：\n");
            int count = 0;
            for (Domain rule : rules) {
                if (count >= 2) break; // 最多传 2 条，控制 Token
                if (rule.getContent() != null) {
                    Object terms = rule.getContent().get("terminology");
                    if (terms != null) {
                        sb.append("术语对照：").append(terms).append("\n");
                    }
                    Object questions = rule.getContent().get("questions");
                    if (questions != null) {
                        sb.append("建议追问：").append(questions).append("\n");
                    }
                }
                count++;
            }
        }

        sb.append("请直接回应用户需求，输出专业提示词或可行性建议。不使用表格格式。");
        return sb.toString();
    }

    /**
     * 发起 HTTP 请求调用 API（OpenAI 兼容接口）
     */
    private String callApi(String context) {
        try {
            String endpoint = baseUrl.replaceAll("/$", "") + "/chat/completions";
            URL url = new URL(endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            conn.setConnectTimeout(timeout * 1000);
            conn.setReadTimeout(timeout * 1000);
            conn.setDoOutput(true);

            // 构建请求体
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("model", model);
            payload.put("temperature", 0.7);
            payload.put("max_tokens", 1024);
            ArrayNode messages = payload.putArray("messages");
            ObjectNode userMsg = messages.addObject();
            userMsg.put("role", "user");
            userMsg.put("content", context);

            byte[] body = objectMapper.writeValueAsBytes(payload);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
            }

            int status = conn.getResponseCode();
            InputStream is = status >= 200 && status < 300
                ? conn.getInputStream()
                : conn.getErrorStream();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8))) {
                StringBuilder resp = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    resp.append(line);
                }
                if (status >= 200 && status < 300) {
                    ObjectNode result = (ObjectNode) objectMapper.readTree(resp.toString());
                    return result.path("choices").get(0).path("message").path("content").asText();
                } else {
                    return "API调用失败（HTTP " + status + "）：" + resp;
                }
            }
        } catch (Exception e) {
            return "API调用失败：" + e.getMessage();
        }
    }

    /**
     * 快车道 HTTP 请求调用（更低Token消耗）
     */
    private String callApiFast(String context) {
        try {
            String endpoint = baseUrl.replaceAll("/$", "") + "/chat/completions";
            URL url = new URL(endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            conn.setConnectTimeout(timeout * 1000);
            conn.setReadTimeout(timeout * 1000);
            conn.setDoOutput(true);

            // 构建请求体（快车道使用更低max_tokens）
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("model", model);
            payload.put("temperature", 0.7);
            payload.put("max_tokens", 256);  // 快车道用更少Token
            ArrayNode messages = payload.putArray("messages");
            ObjectNode userMsg = messages.addObject();
            userMsg.put("role", "user");
            userMsg.put("content", context);

            byte[] body = objectMapper.writeValueAsBytes(payload);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
            }

            int status = conn.getResponseCode();
            InputStream is = status >= 200 && status < 300
                ? conn.getInputStream()
                : conn.getErrorStream();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8))) {
                StringBuilder resp = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    resp.append(line);
                }
                if (status >= 200 && status < 300) {
                    ObjectNode result = (ObjectNode) objectMapper.readTree(resp.toString());
                    return result.path("choices").get(0).path("message").path("content").asText();
                } else {
                    return "API调用失败（HTTP " + status + "）：" + resp;
                }
            }
        } catch (Exception e) {
            return "API调用失败：" + e.getMessage();
        }
    }
}
