package com.majia.model;

import java.util.Map;

/**
 * 领域规则模型
 */
public class Domain {
    private String name;
    private String domain;
    private Map<String, Object> content;
    private double score;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDomain() { return domain; }
    public void setDomain(String domain) { this.domain = domain; }

    public Map<String, Object> getContent() { return content; }
    public void setContent(Map<String, Object> content) { this.content = content; }

    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
}
