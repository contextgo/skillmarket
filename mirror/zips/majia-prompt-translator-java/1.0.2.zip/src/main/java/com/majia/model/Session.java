package com.majia.model;

import java.util.List;

/**
 * 会话模型
 */
public class Session {
    private String id;
    private String createdAt;
    private String currentDomain;
    private List<String> previousDomains;
    private String lastActivity;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getCurrentDomain() { return currentDomain; }
    public void setCurrentDomain(String currentDomain) { this.currentDomain = currentDomain; }

    public List<String> getPreviousDomains() { return previousDomains; }
    public void setPreviousDomains(List<String> previousDomains) { this.previousDomains = previousDomains; }

    public String getLastActivity() { return lastActivity; }
    public void setLastActivity(String lastActivity) { this.lastActivity = lastActivity; }
}
