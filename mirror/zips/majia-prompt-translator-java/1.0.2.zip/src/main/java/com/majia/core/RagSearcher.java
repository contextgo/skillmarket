package com.majia.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.majia.model.Domain;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * RAG 检索器
 */
@Component
public class RagSearcher {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Yaml yaml = new Yaml();

    private String domainsPath = "./domains";
    private int topK = 5;
    private double minScore = 0.6;

    /**
     * 检索指定领域的规则
     */
    public List<Domain> search(String query, String domain) {
        List<Domain> results = new ArrayList<>();
        File dir = new File(domainsPath);

        if (!dir.exists()) {
            return results;
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".yaml"));
        if (files == null) {
            return results;
        }

        for (File file : files) {
            try (FileReader reader = new FileReader(file)) {
                Map<String, Object> content = yaml.load(reader);
                double score = calculateRelevance(query, content);

                if (score >= minScore) {
                    Domain d = new Domain();
                    d.setName((String) content.get("name"));
                    d.setDomain((String) content.get("domain"));
                    d.setContent(content);
                    d.setScore(score);
                    results.add(d);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // 按分数排序
        results.sort((a, b) -> Double.compare(b.getScore(), a.getScore()));

        // 返回 topK
        return results.subList(0, Math.min(results.size(), topK));
    }

    /**
     * 全局检索
     */
    public ArrayNode searchAll(String keyword) {
        ArrayNode results = objectMapper.createArrayNode();
        File dir = new File(domainsPath);

        if (!dir.exists()) {
            return results;
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".yaml"));
        if (files == null) {
            return results;
        }

        for (File file : files) {
            try (FileReader reader = new FileReader(file)) {
                Map<String, Object> content = yaml.load(reader);
                String contentStr = objectMapper.writeValueAsString(content);

                if (contentStr.toLowerCase().contains(keyword.toLowerCase())) {
                    ObjectNode node = objectMapper.createObjectNode();
                    node.put("file", file.getName());
                    node.put("content", contentStr);
                    results.add(node);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return results;
    }

    private double calculateRelevance(String query, Map<String, Object> content) {
        double score = 0.0;
        String queryLower = query.toLowerCase();

        // 检查术语对照
        if (content.containsKey("terminology")) {
            Map<String, Object> terms = (Map<String, Object>) content.get("terminology");
            for (String key : terms.keySet()) {
                if (queryLower.contains(key.toLowerCase())) {
                    score += 0.3;
                }
            }
        }

        // 检查问题引导
        if (content.containsKey("questions")) {
            Map<String, Object> questions = (Map<String, Object>) content.get("questions");
            if (questions.containsKey("must_have")) {
                List<String> mustHave = (List<String>) questions.get("must_have");
                for (String q : mustHave) {
                    if (queryLower.contains(q.toLowerCase())) {
                        score += 0.2;
                    }
                }
            }
        }

        return Math.min(score, 1.0);
    }

    // Getters and Setters
    public void setDomainsPath(String domainsPath) {
        this.domainsPath = domainsPath;
    }

    public void setTopK(int topK) {
        this.topK = topK;
    }

    public void setMinScore(double minScore) {
        this.minScore = minScore;
    }
}
