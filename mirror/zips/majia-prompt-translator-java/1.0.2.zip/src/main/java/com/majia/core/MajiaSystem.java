package com.majia.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.majia.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 马甲系统核心类
 */
@Component
public class MajiaSystem {

    @Autowired
    private DomainClassifier domainClassifier;

    @Autowired
    private RagSearcher ragSearcher;

    @Autowired
    private SafetyChecker safetyChecker;

    @Autowired
    private ApiCaller apiCaller;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    private String storagePath = "./storage";
    private String domainsPath = "./domains";

    /**
     * 处理用户输入 - 缓存决策流程
     *
     * 决策树：
     * 1. 是否为老用户？（有本地缓存记录）
     * 2. 是否为同领域请求？
     * 3. 老用户+同领域 → 快车道流程
     * 4. 新用户 或 切换领域 → 完整流程
     */
    public ObjectNode process(String userInput, String sessionId) {
        ObjectNode result = objectMapper.createObjectNode();

        // 安全检查
        if (!safetyChecker.check(userInput)) {
            result.put("status", "rejected");
            result.put("reason", "内容违反安全规则");
            return result;
        }

        // 获取或创建会话
        Session session = getOrCreateSession(sessionId);

        // 记录提问
        logQuestion(userInput, session);

        // 领域分类
        String domain = domainClassifier.classify(userInput);
        double confidence = domainClassifier.getConfidence();

        // 缓存决策
        boolean isWarm = isWarmUser();
        boolean isSameDomain = isSameDomain(session, domain);

        if (isWarm && isSameDomain) {
            // 快车道：老用户 + 同领域
            return fastLaneProcess(userInput, domain, session, result);
        } else {
            // 完整流程：新用户 或 切换领域
            return fullProcess(userInput, domain, session, confidence, result);
        }
    }

    /**
     * 快车道流程（热启动）
     * 只注入极短的个性化偏好词，Token消耗约 50-100
     */
    private ObjectNode fastLaneProcess(String userInput, String domain,
                                       Session session, ObjectNode result) {
        // 1. 构建偏好包
        String preferencePack = buildPreferencePack(domain);

        // 2. 组装最小化上下文
        String context = buildFastContext(userInput, preferencePack);

        // 3. 调用模型
        String response = apiCaller.callFastLane(userInput, preferencePack);

        // 4. 更新会话
        session.setCurrentDomain(domain);
        session.setLastActivity(LocalDateTime.now().toString());
        updateSession(session);

        // 5. 构建返回
        result.put("status", "success");
        result.put("sessionId", session.getId());
        result.put("domain", domain);
        result.put("confidence", 0.95);
        result.put("response", response);
        result.put("rulesLoaded", 0);
        result.put("cacheMode", "fast_lane");
        result.put("tokenMode", "fast_lane");

        return result;
    }

    /**
     * 完整流程（冷启动/领域切换）
     * 消耗约 500-1000 Token
     */
    private ObjectNode fullProcess(String userInput, String domain, Session session,
                                  double confidence, ObjectNode result) {
        // 1. RAG 检索
        List<Domain> rules = ragSearcher.search(userInput, domain);

        // 2. 调用 API
        String response = apiCaller.call(userInput, domain, rules);

        // 3. 更新会话和偏好
        session.setCurrentDomain(domain);
        session.setLastActivity(LocalDateTime.now().toString());
        updateSession(session);
        updatePreferences(domain);

        // 4. 构建返回
        result.put("status", "success");
        result.put("sessionId", session.getId());
        result.put("domain", domain);
        result.put("confidence", confidence);
        result.put("response", response);
        result.put("rulesLoaded", rules.size());
        result.put("cacheMode", "full_process");
        result.put("tokenMode", "full");

        return result;
    }

    /**
     * 判断是否为老用户
     * 标准：是否进行过本地缓存（手动启动/自动写入）
     */
    private boolean isWarmUser() {
        File storageDir = new File(storagePath);
        File domainsDir = new File(domainsPath);
        File prefFile = new File(storageDir, "preferences.json");
        File logFile = new File(storageDir, "questions.json");

        // 检查偏好记录
        if (prefFile.exists()) {
            try {
                ObjectNode prefs = (ObjectNode) objectMapper.readValue(prefFile, ObjectNode.class);
                if (prefs.has("preferredDomains") && prefs.get("preferredDomains").size() > 0) {
                    return true;
                }
            } catch (IOException e) {
                // ignore
            }
        }

        // 检查规则文件
        File[] yamlFiles = domainsDir.listFiles((d, name) -> name.endsWith(".yaml"));
        if (yamlFiles != null && yamlFiles.length > 0) {
            return true;
        }

        // 检查问答记录
        if (logFile.exists()) {
            return true;
        }

        return false;
    }

    /**
     * 判断是否为同领域请求
     */
    private boolean isSameDomain(Session session, String domain) {
        String current = session.getCurrentDomain();
        return current != null && current.equals(domain) && !"通用".equals(domain);
    }

    /**
     * 构建领域偏好包
     * 只包含极短的关键偏好词，不超过100字符
     */
    private String buildPreferencePack(String domain) {
        StringBuilder pack = new StringBuilder();
        File storageDir = new File(storagePath);
        File prefFile = new File(storageDir, "preferences.json");

        if (!prefFile.exists()) {
            return "领域：" + domain + "（首次使用）";
        }

        try {
            ObjectNode prefs = (ObjectNode) objectMapper.readValue(prefFile, ObjectNode.class);

            // 领域偏好
            if (prefs.has("preferredDomains")) {
                var preferred = prefs.get("preferredDomains");
                if (preferred.isArray()) {
                    for (var d : preferred) {
                        if (d.asText().equals(domain)) {
                            pack.append("常用领域：").append(domain);
                            break;
                        }
                    }
                }
            }

            // 风格偏好
            if (prefs.has("stylePreferences") && prefs.get("stylePreferences").has(domain)) {
                if (pack.length() > 0) pack.append(" | ");
                pack.append("风格：").append(prefs.get("stylePreferences").get(domain).asText());
            }

        } catch (IOException e) {
            // ignore
        }

        if (pack.length() == 0) {
            return "领域：" + domain + "（首次使用）";
        }

        return pack.toString();
    }

    /**
     * 构建快车道上下文
     * 只传必要内容，Token消耗极低
     */
    private String buildFastContext(String userInput, String preferencePack) {
        return "用户输入：" + userInput + "\n偏好包：" + preferencePack + "\n请直接输出结果，简洁为主。";
    }

    /**
     * 检索规则
     */
    public List<ObjectNode> search(String keyword) {
        return ragSearcher.searchAll(keyword);
    }

    /**
     * 获取系统状态
     */
    public ObjectNode getStatus() {
        ObjectNode status = objectMapper.createObjectNode();

        File domainsDir = new File(domainsPath);
        File storageDir = new File(storagePath);

        int domainCount = domainsDir.listFiles((d, name) -> name.endsWith(".yaml")) != null
            ? Objects.requireNonNull(domainsDir.listFiles((d, name) -> name.endsWith(".yaml"))).length
            : 0;

        status.put("domainsCount", domainCount);
        status.put("sessionsCount", sessions.size());

        return status;
    }

    private Session getOrCreateSession(String sessionId) {
        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = UUID.randomUUID().toString();
        }

        return sessions.computeIfAbsent(sessionId, id -> {
            Session session = new Session();
            session.setId(id);
            session.setCreatedAt(LocalDateTime.now().toString());
            session.setCurrentDomain("通用");
            session.setPreviousDomains(new ArrayList<>());
            return session;
        });
    }

    private void logQuestion(String question, Session session) {
        File storageDir = new File(storagePath);
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        File logFile = new File(storageDir, "questions.json");
        try {
            List<Object> logs = new ArrayList<>();
            if (logFile.exists()) {
                Object list = objectMapper.readValue(logFile, List.class);
                logs.addAll((Collection<?>) list);
            }

            ObjectNode entry = objectMapper.createObjectNode();
            entry.put("id", UUID.randomUUID().toString());
            entry.put("timestamp", LocalDateTime.now().toString());
            entry.put("question", question);
            entry.put("sessionId", session.getId());
            entry.put("domain", session.getCurrentDomain());
            logs.add(entry);

            objectMapper.writeValue(logFile, logs);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateSession(Session session) {
        sessions.put(session.getId(), session);
    }

    private void updatePreferences(String domain) {
        File storageDir = new File(storagePath);
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        File prefFile = new File(storageDir, "preferences.json");
        try {
            ObjectNode prefs = objectMapper.createObjectNode();
            if (prefFile.exists()) {
                prefs = (ObjectNode) objectMapper.readValue(prefFile, ObjectNode.class);
            }

            prefs.put("updatedAt", LocalDateTime.now().toString());

            objectMapper.writeValue(prefFile, prefs);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Getters and Setters
    public void setStoragePath(String storagePath) {
        this.storagePath = storagePath;
    }

    public void setDomainsPath(String domainsPath) {
        this.domainsPath = domainsPath;
    }
}
