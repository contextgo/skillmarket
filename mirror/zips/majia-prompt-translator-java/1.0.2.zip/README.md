# 马甲系统 Java 版本

版本：2.0
状态：完整功能版

## 功能介绍

Java 版本的马甲系统，提供企业级稳定性和扩展性。

### 核心功能

- **非技术层伪专家**：像 WorkBuddy 召唤专家一样，解决认知翻译问题
- **动态领域归纳**：按需生成领域规则，零预设
- **RAG 智能检索**：代码层执行，大幅减少 Token 消耗
- **会话状态追踪**：支持同一对话中的领域切换
- **REST API 接口**：支持 HTTP 调用
- **自定义 API**：支持用户使用自己的模型 API

### 技术特性

- Java 17+
- Spring Boot 3.x
- Maven 构建
- 支持打包为 JAR 独立运行

## 目录结构

```
java/
├── pom.xml                    ← Maven 配置
├── src/
│   └── main/
│       ├── java/com/majia/
│       │   ├── MajiaApplication.java
│       │   └── core/
│       │       ├── MajiaSystem.java
│       │       ├── DomainClassifier.java
│       │       ├── RagSearcher.java
│       │       └── SafetyChecker.java
│       └── resources/
│           ├── application.yaml
│           └── domains/
├── domains/                   ← 领域规则（YAML）
├── storage/                   ← 数据存储（JSON）
└── README.md                  ← 本文件
```

## 部署方法

### 环境要求

- Java 17 或更高版本
- Maven 3.8+

### 安装步骤

**第一步：编译打包**

```bash
cd <你的java版本目录>
mvn clean package
```

**第二步：配置**

编辑 src/main/resources/application.yaml 文件。

**第三步：运行**

```bash
# 开发模式运行
mvn spring-boot:run

# 或者运行 JAR 包
java -jar target/majia-2.0.jar
```

## API 配置

### 支持的模型提供商

- openai
- claude
- deepseek
- zhipu
- moonshot
- 自定义（需提供 base_url）

### 配置示例

```yaml
majia:
  api:
    provider: "deepseek"
    base-url: "https://api.deepseek.com/v1"
    api-key: "${DEEPSEEK_API_KEY}"
    model: "deepseek-chat"
    enabled: true
```

### 环境变量

API 密钥建议使用环境变量：

```bash
export API_KEY="your-api-key"
java -jar majia-2.0.jar
```

## 使用方法

### API 接口

**处理用户输入**

```http
POST /api/majia/process
Content-Type: application/json

{
  "input": "最近工作压力大，心情不好",
  "sessionId": "可选的会话ID"
}
```

**检索规则**

```http
GET /api/majia/search?keyword=工作压力
```

### 返回格式

```json
{
  "status": "success",
  "sessionId": "uuid",
  "domain": "心理咨询",
  "confidence": 0.85,
  "response": "根据你的描述...",
  "rulesLoaded": 1
}
```

## 与其他版本的区别

| 维度 | SKILL版 | Python版 | Java版 |
|---|---|---|---|
| 运行方式 | AI平台插件 | 命令行 | REST API |
| Token优化 | 自动RAG | 手动RAG | 代码层执行 |
| API支持 | 无 | 可选 | 完整支持 |
| 适用场景 | 即插即用 | 本地开发 | 企业部署 |

## 更新日志

- 2026-04-12：1.0 版本发布
- 2026-04-12：2.0 版本，增加API配置，重构定位

文档结束
