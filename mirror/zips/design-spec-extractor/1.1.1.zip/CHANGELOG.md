# design-spec-extractor skill 更新日志

## 2026-04-07 - v1.3.0 自动化脚本增强

### 新增功能
- **一键生成脚本**：新增 `scripts/generate_design_spec.py`，支持从图片或网页链接直接生成 `analysis.json`、`design_spec.md`、`design_spec.html`、`design_spec.pptx`
- **HTML 模板**：新增 `templates/design_spec_report.html.j2`，输出响应式在线规范文档，支持目录导航、色值复制、打印友好
- **PPTX 导出**：通过 `python-pptx` 自动生成 8 页结构化设计规范演示文稿
- **网页抓取增强**：支持静态 HTML/CSS 抓取，并可在安装 Playwright 后启用网页截图和 computed styles 采集

### 文件更新
- **SKILL.md**：加入自动化脚本入口、运行命令、失败回退与输出目录约定
- **skill.json**：升级到 1.3.0，增加 runtime 入口与自动化输出能力描述
- **README.md**：补充安装说明、一键命令示例、输出文件结构
- **requirements.txt**：新增 Python 依赖清单
- **scripts/generate_design_spec.py**：新增统一自动化执行脚本
- **templates/design_spec_report.html.j2**：新增 HTML 模板

### 自动化输出特性
- 图片自动提取主色板与基础版式信息
- 网页自动抓取颜色、字体候选、组件与布局线索
- 同时沉淀 JSON、Markdown、HTML、PPTX 四类结果，便于继续加工
- 对动态网页、字体识别、像素级布局提供明确的低置信度或回退说明

## 2026-04-07 - v1.2.0 触发逻辑优化

### 新增功能
- **触发词精修**：明确 13 个核心触发词与建议补充触发词
- **执行逻辑清晰化**：从松散描述升级为结构化执行步骤
- **Web 默认输出**：未指定格式时默认生成在线规范文档

### 文件更新
- **SKILL.md**：更新 triggerWords、场景边界与输出规则
- **skill.json**：更新版本至 1.2.0，补充中英文 triggerWords
- **README.md**：重写定位、示例与边界说明
