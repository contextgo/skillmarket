# 字体排版指南

## 字体分类

### 1. 衬线字体 (Serif)

| 字体 | 特点 | 适用场景 |
|------|------|---------|
| Times New Roman | 经典、正式 | 正文、书籍、学术 |
| Georgia | 现代衬线、可读性好 | 网页正文 |
| 宋体 | 中文传统衬线 | 中文正文、正式文档 |
| 思源宋体 | 现代中文衬线 | 中文正文 |

### 2. 无衬线字体 (Sans-Serif)

| 字体 | 特点 | 适用场景 |
|------|------|---------|
| Arial | 通用、清晰 | 界面、演示 |
| Helvetica | 简洁、现代 | 高端品牌、标志 |
| Inter | 专为屏幕设计 | 数字产品UI |
| 思源黑体 | 中文无衬线首选 | 中文界面 |

### 3. 等宽字体 (Monospace)

| 字体 | 特点 | 适用场景 |
|------|------|---------|
| Consolas | 清晰、编程友好 | 代码展示 |
| JetBrains Mono | 现代等宽 | 开发文档 |
| Source Code Pro | 优雅可读 | 技术文档 |

### 4. 手写/装饰字体

| 字体 | 特点 | 适用场景 |
|------|------|---------|
| Pacifico | 圆润手写 | 儿童、娱乐 |
| Lobster | 优雅草书 | 创意项目 |

## 字体配对原则

### 安全配对方案

```
标题: Georgia + 正文: Calibri
标题: Arial Black + 正文: Arial
标题: Trebuchet MS + 正文: Verdana
标题: 思源黑体 + 正文: 思源宋体
```

### 字体数量控制

- **最少**：2种字体（标题 + 正文）
- **推荐**：3种字体（标题 + 正文 + 代码）
- **避免**：超过4种字体

## 类型层级 (Type Scale)

### 黄金比例缩放

| 级别 | 字号 | 用途 |
|------|------|------|
| Display | 48-72px | 大标题、Hero |
| H1 | 32-36px | 页面标题 |
| H2 | 24-28px | 章节标题 |
| H3 | 18-20px | 小节标题 |
| Body | 14-16px | 正文 |
| Small | 12-13px | 辅助文字 |
| Caption | 10-11px | 注释、标签 |

### 行高设置

```css
/* 紧凑行高 - 标题 */
line-height: 1.2 - 1.4;

/* 标准行高 - 正文 */
line-height: 1.5 - 1.75;

/* 宽松行高 - 诗歌、引用 */
line-height: 1.8 - 2.0;
```

### 字间距设置

```css
/* 标题字间距 - 收紧 */
letter-spacing: -0.5px 到 0px;

/* 正文字间距 - 标准 */
letter-spacing: 0px;

/* 大写文字 - 放宽 */
letter-spacing: 1-3px;
```

## 字体加载策略

### 1. 系统字体栈

```css
font-family: -apple-system, BlinkMacSystemFont, 
             "Segoe UI", Roboto, "Helvetica Neue", Arial, 
             sans-serif;
```

### 2. 中文优化

```css
font-family: "PingFang SC", "Microsoft YaHei", 
             "Hiragino Sans GB", sans-serif;
```

### 3. Google Fonts 加载

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
```

## 字体识别技巧

### 通过视觉特征识别

1. **衬线 vs 无衬线**：观察笔画的收尾
2. **x-height**：小写字母高度
3. **字重变化**：粗体/细体风格
4. **数字样式**：等宽/比例

### 常见字体特征

- **Inter**：宽松的x-height、圆润的角
- **Roboto**：机械感、开敞的字母间距
- **SF Pro**：Apple生态专用、完美的几何
- **Noto Sans**：Google字体、覆盖所有语言
