# 设计系统规范参考

## 设计系统组成

### 1. 设计令牌 (Design Tokens)

设计系统的基础原子值，跨平台复用。

```json
{
  "color": {
    "primary": "#3B82F6",
    "secondary": "#1E293B",
    "accent": "#F59E0B",
    "background": "#FFFFFF",
    "text": "#1F2937"
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "xxl": "48px"
  },
  "borderRadius": {
    "sm": "4px",
    "md": "8px",
    "lg": "12px",
    "full": "9999px"
  },
  "typography": {
    "fontFamily": {
      "heading": "Inter",
      "body": "Inter"
    },
    "fontSize": {
      "xs": "12px",
      "sm": "14px",
      "md": "16px",
      "lg": "18px",
      "xl": "24px",
      "2xl": "32px"
    }
  }
}
```

### 2. 组件模式 (Component Patterns)

可复用的UI组件规范。

#### 按钮 (Button)

```css
.btn {
  padding: 8px 16px;
  border-radius: 8px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.btn-primary {
  background: var(--color-primary);
  color: white;
}

.btn-secondary {
  background: transparent;
  border: 1px solid var(--color-secondary);
}
```

#### 卡片 (Card)

```css
.card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  padding: 24px;
}
```

#### 输入框 (Input)

```css
.input {
  padding: 10px 14px;
  border: 1px solid #E5E7EB;
  border-radius: 8px;
  font-size: 14px;
}

.input:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}
```

### 3. 布局规范 (Layout)

#### 栅格系统

```css
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 24px;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin: -12px;
}

.col {
  padding: 12px;
}

.col-12 { flex: 0 0 100%; }
.col-6  { flex: 0 0 50%; }
.col-4  { flex: 0 0 33.333%; }
.col-3  { flex: 0 0 25%; }
```

#### 响应式断点

```css
/* Mobile First */
@media (min-width: 640px) { .sm\: ... }
@media (min-width: 768px) { .md\: ... }
@media (min-width: 1024px) { .lg\: ... }
@media (min-width: 1280px) { .xl\: ... }
```

### 4. 设计原则

#### 一致性 (Consistency)

- 统一的设计语言
- 标准化组件和行为
- 跨平台体验一致

#### 可用性 (Usability)

- 清晰的视觉层次
- 直观的交互反馈
- 适当的错误处理

#### 效率 (Efficiency)

- 减少用户操作步骤
- 智能默认设置
- 快捷操作支持

#### 可访问性 (Accessibility)

- WCAG 2.1 AA标准
- 键盘导航支持
- 屏幕阅读器兼容

## 生成的设计系统文档结构

### 封面
- 项目名称
- 版本号
- 生成日期
- 作者

### 目录
- 可点击跳转

### 色板
- 主色及变体
- 辅助色及变体
- 功能色（成功/警告/错误）
- 中性色（灰阶）

### 字体
- 字体家族
- 字号层级
- 字重使用
- 行高设置

### 布局
- 栅格配置
- 间距规范
- 响应式断点

### 组件
- 按钮样式
- 表单元素
- 卡片设计
- 导航模式

### 设计原则
- 核心原则
- 使用建议
- 注意事项

### 附录
- 完整色值表
- CSS变量定义
- 设计资源下载