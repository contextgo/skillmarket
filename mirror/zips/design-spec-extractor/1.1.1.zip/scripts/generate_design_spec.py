from __future__ import annotations

import argparse
import colorsys
import json
import math
import re
import shutil
import sys
import textwrap
from collections import Counter
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader, select_autoescape
from PIL import Image, ImageStat

try:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
    from pptx.util import Inches, Pt

    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

try:
    from playwright.sync_api import sync_playwright

    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
HTML_TEMPLATE = "design_spec_report.html.j2"
HEX_RE = re.compile(r"#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b")
RGB_RE = re.compile(r"rgba?\(([^\)]+)\)")
FONT_RE = re.compile(r"font-family\s*:\s*([^;}{]+)", re.IGNORECASE)
SIZE_RE = re.compile(r"(?:margin|padding|gap|border-radius|font-size|line-height|max-width|min-width|width)\s*:\s*([^;}{]+)", re.IGNORECASE)
NUMBER_RE = re.compile(r"(\d+(?:\.\d+)?)px")


class ExtractionError(RuntimeError):
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate HTML/PPT design spec documents from an image or a webpage URL."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--image", help="Local image path or image URL")
    source.add_argument("--url", help="Web page URL or image URL")
    parser.add_argument(
        "--format",
        choices=["html", "pptx", "both"],
        default="both",
        help="Output format. Defaults to both.",
    )
    parser.add_argument("--title", help="Document title. Defaults to inferred source title.")
    parser.add_argument(
        "--output-dir",
        help="Output directory. Defaults to ./design-spec-output/<timestamp_slug>",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=20,
        help="Network timeout in seconds. Defaults to 20.",
    )
    parser.add_argument(
        "--prefer-browser",
        action="store_true",
        help="Prefer Playwright screenshot and computed-style extraction when available.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        source_value = args.image or args.url
        source_title = args.title or infer_title_from_source(source_value)
        output_dir = prepare_output_dir(args.output_dir, source_title, timestamp)

        if args.image:
            analysis = analyze_image_source(args.image, source_title, output_dir, args.timeout)
        else:
            analysis = analyze_url_source(
                args.url,
                source_title,
                output_dir,
                args.timeout,
                args.prefer_browser,
            )

        analysis["meta"]["requested_format"] = args.format
        markdown_path = write_markdown(analysis, output_dir)
        analysis_path = output_dir / "analysis.json"
        analysis_path.write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")

        generated: list[Path] = [analysis_path, markdown_path]
        if args.format in {"html", "both"}:
            generated.append(render_html(analysis, output_dir))
        if args.format in {"pptx", "both"}:
            generated.append(render_pptx(analysis, output_dir))

        print("生成完成：")
        for item in generated:
            print(str(item))
        return 0
    except ExtractionError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"[ERROR] 未预期异常：{exc}", file=sys.stderr)
        return 1


def infer_title_from_source(source: str) -> str:
    if is_url(source):
        parsed = urlparse(source)
        stem = parsed.netloc or parsed.path.rsplit("/", 1)[-1]
        stem = stem.replace("www.", "")
        return f"{stem} 设计规范"
    return f"{Path(source).stem} 设计规范"


def prepare_output_dir(custom_dir: str | None, title: str, timestamp: str) -> Path:
    if custom_dir:
        target = Path(custom_dir).expanduser().resolve()
    else:
        safe_title = slugify(title)[:48] or "design-spec"
        target = Path.cwd() / "design-spec-output" / f"{timestamp}_{safe_title}"
    target.mkdir(parents=True, exist_ok=True)
    return target


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-")
    return value or "design-spec"


def is_url(value: str) -> bool:
    return value.startswith("http://") or value.startswith("https://")


def analyze_image_source(source: str, title: str, output_dir: Path, timeout: int) -> dict[str, Any]:
    preview_path = copy_or_download_image(source, output_dir, timeout)
    color_tokens, image_metrics = extract_palette_from_image(preview_path)
    style = infer_style_from_palette(color_tokens, image_metrics, source_type="image")
    typography = build_typography_section([], source_type="image")
    layout = build_image_layout_section(preview_path)
    components = build_components_section([], source_type="image")
    principles = build_principles(style, color_tokens, typography, layout, components)

    return build_analysis(
        title=title,
        source_type="image",
        source_value=source,
        preview_path=preview_path,
        style=style,
        color_tokens=color_tokens,
        typography=typography,
        layout=layout,
        components=components,
        principles=principles,
        limitations=[
            "当前来源为单张图片，字体名称与像素级间距以启发式推断为主，建议人工复核。",
            "如果截图裁剪过多或清晰度不足，组件与布局章节会更偏概括性。",
        ],
        evidence_summary=[
            f"基于图片预览 {preview_path.name} 自动提取主色板与画面亮度/饱和度分布。",
            "通过图像尺寸、横纵比例和视觉密度做基础布局判断。",
        ],
    )


def analyze_url_source(
    url: str,
    title: str,
    output_dir: Path,
    timeout: int,
    prefer_browser: bool,
) -> dict[str, Any]:
    page_data = fetch_page_data(url, output_dir, timeout, prefer_browser)
    css_palette = extract_colors_from_css_sources(page_data["css_texts"], page_data.get("computed_colors", []))
    font_candidates = extract_font_candidates(page_data["css_texts"], page_data.get("computed_fonts", []))
    color_tokens: list[dict[str, Any]] = []

    if page_data.get("preview_path"):
        image_tokens, image_metrics = extract_palette_from_image(Path(page_data["preview_path"]))
        color_tokens = merge_color_tokens(css_palette, image_tokens)
    else:
        image_metrics = {"width": 0, "height": 0, "avg_saturation": 0.2, "contrast": 0.4}
        color_tokens = normalize_css_color_tokens(css_palette)

    if not color_tokens:
        raise ExtractionError("未能从网页中提取到足够的颜色线索，请改用截图或提供可访问的页面。")

    style = infer_style_from_page(page_data, color_tokens, image_metrics)
    typography = build_typography_section(font_candidates, source_type="web")
    layout = build_web_layout_section(page_data)
    components = build_components_section(page_data["component_counts"], source_type="web")
    principles = build_principles(style, color_tokens, typography, layout, components)

    limitations: list[str] = []
    if not page_data.get("used_browser"):
        limitations.append("当前未启用浏览器渲染，仅基于 HTML/CSS 抓取线索，动态样式可能有遗漏。")
    if not page_data.get("preview_path"):
        limitations.append("当前没有网页截图，预览图与基于视觉的颜色提取已跳过。")
    limitations.extend(
        [
            "网页字体与字号层级来自样式线索，仍建议在浏览器开发者工具中做最终确认。",
            "复杂动画、滚动交互和状态机逻辑不在本次静态规范自动化范围内。",
        ]
    )

    evidence_summary = [
        f"抓取页面标题：{page_data['title'] or title}",
        f"采集 CSS/内联样式 {page_data['css_source_count']} 份，提取颜色与字体线索。",
        f"识别语义/结构组件 {sum(page_data['component_counts'].values())} 项。",
    ]
    if page_data.get("used_browser"):
        evidence_summary.append("已使用 Playwright 截图与 computed styles，网页视觉证据更完整。")

    return build_analysis(
        title=page_data["title"] or title,
        source_type="webpage",
        source_value=url,
        preview_path=Path(page_data["preview_path"]) if page_data.get("preview_path") else None,
        style=style,
        color_tokens=color_tokens,
        typography=typography,
        layout=layout,
        components=components,
        principles=principles,
        limitations=limitations,
        evidence_summary=evidence_summary,
    )


def fetch_page_data(
    url: str,
    output_dir: Path,
    timeout: int,
    prefer_browser: bool,
) -> dict[str, Any]:
    headers = {"User-Agent": USER_AGENT}
    html = ""
    title = ""
    description = ""
    preview_path: str | None = None
    css_texts: list[str] = []
    computed_fonts: list[str] = []
    computed_colors: list[str] = []
    used_browser = False

    if prefer_browser and PLAYWRIGHT_AVAILABLE:
        try:
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(headless=True)
                page = browser.new_page(viewport={"width": 1440, "height": 1200})
                page.goto(url, wait_until="networkidle", timeout=timeout * 1000)
                title = page.title()
                html = page.content()
                preview = output_dir / "source_preview.png"
                page.screenshot(path=str(preview), full_page=True)
                preview_path = str(preview)
                probe = page.evaluate(
                    """
                    () => {
                      const root = getComputedStyle(document.documentElement);
                      const body = getComputedStyle(document.body);
                      const firstButton = document.querySelector('button, [role="button"], .btn, .button');
                      const buttonStyles = firstButton ? getComputedStyle(firstButton) : null;
                      const headings = Array.from(document.querySelectorAll('h1, h2, h3')).slice(0, 3).map((node) => {
                        const style = getComputedStyle(node);
                        return {
                          tag: node.tagName.toLowerCase(),
                          fontSize: style.fontSize,
                          fontFamily: style.fontFamily,
                          fontWeight: style.fontWeight,
                          color: style.color,
                        };
                      });
                      return {
                        bodyFont: body.fontFamily,
                        bodyColor: body.color,
                        bodyBg: body.backgroundColor,
                        buttonColor: buttonStyles ? buttonStyles.backgroundColor : null,
                        buttonText: buttonStyles ? buttonStyles.color : null,
                        headings,
                      };
                    }
                    """
                )
                browser.close()
                used_browser = True
                computed_fonts = [probe.get("bodyFont", "")]
                computed_colors = [
                    probe.get("bodyColor", ""),
                    probe.get("bodyBg", ""),
                    probe.get("buttonColor", ""),
                    probe.get("buttonText", ""),
                ] + [item.get("color", "") for item in probe.get("headings", [])]
                heading_fonts = [item.get("fontFamily", "") for item in probe.get("headings", [])]
                computed_fonts.extend(heading_fonts)
        except Exception:
            used_browser = False

    if not html:
        response = requests.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()
        response.encoding = response.encoding or response.apparent_encoding or "utf-8"
        html = response.text

    soup = BeautifulSoup(html, "html.parser")
    title = title or (soup.title.string.strip() if soup.title and soup.title.string else "")
    description_tag = soup.find("meta", attrs={"name": "description"})
    if description_tag:
        description = description_tag.get("content", "").strip()

    css_texts.extend(tag.get_text(" ", strip=True) for tag in soup.find_all("style"))
    css_texts.extend(extract_inline_style_strings(soup))
    css_texts.extend(fetch_linked_stylesheets(url, soup, headers, timeout))

    component_counts = count_components(soup)
    semantic_tags = summarize_semantic_tags(soup)
    structure_hints = summarize_structure_hints(soup)
    raw_size_values = collect_size_values(css_texts)

    return {
        "url": url,
        "title": title,
        "description": description,
        "preview_path": preview_path,
        "used_browser": used_browser,
        "css_texts": css_texts,
        "css_source_count": len(css_texts),
        "computed_fonts": [item for item in computed_fonts if item],
        "computed_colors": [item for item in computed_colors if item],
        "component_counts": component_counts,
        "semantic_tags": semantic_tags,
        "structure_hints": structure_hints,
        "size_values": raw_size_values,
    }


def extract_inline_style_strings(soup: BeautifulSoup) -> list[str]:
    values = []
    for node in soup.find_all(style=True):
        style_value = node.get("style", "").strip()
        if style_value:
            values.append(style_value)
    return values


def fetch_linked_stylesheets(
    page_url: str,
    soup: BeautifulSoup,
    headers: dict[str, str],
    timeout: int,
    limit: int = 6,
) -> list[str]:
    results: list[str] = []
    links = soup.find_all("link", rel=lambda value: value and "stylesheet" in value.lower())
    for link in links[:limit]:
        href = link.get("href")
        if not href:
            continue
        css_url = urljoin(page_url, href)
        try:
            response = requests.get(css_url, headers=headers, timeout=timeout)
            response.raise_for_status()
            response.encoding = response.encoding or response.apparent_encoding or "utf-8"
            results.append(response.text)
        except Exception:
            continue
    return results


def copy_or_download_image(source: str, output_dir: Path, timeout: int) -> Path:
    if is_url(source):
        response = requests.get(source, headers={"User-Agent": USER_AGENT}, timeout=timeout)
        response.raise_for_status()
        suffix = guess_image_suffix(source, response.headers.get("Content-Type", ""))
        target = output_dir / f"source_preview{suffix}"
        target.write_bytes(response.content)
        return target

    local_path = Path(source).expanduser().resolve()
    if not local_path.exists():
        raise ExtractionError(f"图片不存在：{local_path}")
    target = output_dir / f"source_preview{local_path.suffix or '.png'}"
    shutil.copy2(local_path, target)
    return target


def guess_image_suffix(url: str, content_type: str) -> str:
    parsed = urlparse(url)
    if Path(parsed.path).suffix:
        return Path(parsed.path).suffix
    mapping = {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/webp": ".webp",
        "image/gif": ".gif",
    }
    return mapping.get(content_type.split(";")[0].strip().lower(), ".png")


def extract_palette_from_image(image_path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    with Image.open(image_path) as image:
        image = image.convert("RGB")
        width, height = image.size
        reduced = image.copy()
        reduced.thumbnail((320, 320))
        quantized = reduced.quantize(colors=8, method=Image.MEDIANCUT)
        counts = Counter(quantized.getdata())
        palette = quantized.getpalette() or []
        total = sum(counts.values()) or 1

        tokens: list[dict[str, Any]] = []
        for palette_index, count in counts.most_common():
            base = palette_index * 3
            rgb = tuple(palette[base : base + 3])
            if len(rgb) != 3:
                continue
            token = build_color_token(rgb, count / total)
            if token:
                tokens.append(token)

        stat = ImageStat.Stat(reduced)
        avg_rgb = tuple(int(channel) for channel in stat.mean[:3])
        avg_saturation = average_saturation(tokens)
        contrast = estimate_contrast(tokens)
        metrics = {
            "width": width,
            "height": height,
            "average_rgb": avg_rgb,
            "avg_saturation": avg_saturation,
            "contrast": contrast,
        }
        tokens = assign_color_roles(tokens)
        return tokens, metrics


def build_color_token(rgb: tuple[int, int, int], usage_ratio: float) -> dict[str, Any] | None:
    if usage_ratio <= 0:
        return None
    normalized = tuple(max(0, min(255, int(value))) for value in rgb)
    hex_value = rgb_to_hex(normalized)
    hue, saturation, value = colorsys.rgb_to_hsv(*(channel / 255 for channel in normalized))
    luminance = relative_luminance(normalized)
    return {
        "hex": hex_value,
        "rgb": list(normalized),
        "usage_ratio": round(float(usage_ratio), 4),
        "hue": round(hue * 360, 1),
        "saturation": round(float(saturation), 4),
        "value": round(float(value), 4),
        "luminance": round(float(luminance), 4),
        "name": hex_value,
        "role": "supporting",
        "role_label": "辅助色",
        "description": "来自主视觉聚类的颜色样本。",
    }


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#%02X%02X%02X" % rgb


def relative_luminance(rgb: tuple[int, int, int]) -> float:
    channels = []
    for value in rgb:
        channel = value / 255
        channels.append(channel / 12.92 if channel <= 0.03928 else ((channel + 0.055) / 1.055) ** 2.4)
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def average_saturation(tokens: list[dict[str, Any]]) -> float:
    if not tokens:
        return 0.0
    total = sum(token["usage_ratio"] for token in tokens) or 1
    return sum(token["saturation"] * token["usage_ratio"] for token in tokens) / total


def estimate_contrast(tokens: list[dict[str, Any]]) -> float:
    if len(tokens) < 2:
        return 0.0
    luminances = [token["luminance"] for token in tokens]
    return max(luminances) - min(luminances)


def assign_color_roles(tokens: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not tokens:
        return tokens

    deduped: dict[str, dict[str, Any]] = {}
    for token in tokens:
        existing = deduped.get(token["hex"])
        if existing:
            existing["usage_ratio"] = round(existing["usage_ratio"] + token["usage_ratio"], 4)
        else:
            deduped[token["hex"]] = dict(token)
    items = sorted(deduped.values(), key=lambda item: item["usage_ratio"], reverse=True)

    background = max(items, key=lambda item: (item["usage_ratio"], item["luminance"]))
    text = min(items, key=lambda item: item["luminance"])
    colorful = [item for item in items if item["saturation"] >= 0.16 and item["hex"] not in {background['hex'], text['hex']}]
    neutrals = [item for item in items if item["saturation"] < 0.16 and item["hex"] not in {background['hex'], text['hex']}]

    primary = colorful[0] if colorful else next((item for item in items if item["hex"] not in {background['hex'], text['hex']}), background)
    secondary = next((item for item in colorful[1:] if item["hex"] != primary["hex"]), None)
    if not secondary:
        secondary = next((item for item in neutrals if item["hex"] not in {background['hex'], text['hex'], primary['hex']}), None)
    accent = max(
        (item for item in items if item["hex"] not in {background['hex'], text['hex'], primary['hex']}),
        key=lambda item: item["saturation"],
        default=primary,
    )
    border = next((item for item in neutrals if item["hex"] not in {background['hex'], text['hex']}), background)

    mapping = [
        (background, "background", "背景色", "承担大面积底色与留白。"),
        (text, "text", "文本色", "适合正文与高可读信息。"),
        (primary, "primary", "主色", "优先用于主按钮、主标题或主品牌色。"),
        (secondary, "secondary", "辅助色", "作为主色的补充层级。"),
        (accent, "accent", "强调色", "用于CTA、链接或关键状态强调。"),
        (border, "border", "边框色", "适合分割线、弱边框与容器描边。"),
    ]

    seen: set[str] = set()
    ordered: list[dict[str, Any]] = []
    for candidate, role, role_label, description in mapping:
        if not candidate or candidate["hex"] in seen:
            continue
        candidate = dict(candidate)
        candidate["role"] = role
        candidate["role_label"] = role_label
        candidate["name"] = f"{role_label} {candidate['hex']}"
        candidate["description"] = description
        candidate["text_color"] = pick_text_color(tuple(candidate["rgb"]))
        ordered.append(candidate)
        seen.add(candidate["hex"])

    for token in items:
        if token["hex"] in seen:
            continue
        token = dict(token)
        token["role"] = "supporting"
        token["role_label"] = "补充色"
        token["name"] = f"补充色 {token['hex']}"
        token["description"] = "在截图或页面中出现的辅助色样本。"
        token["text_color"] = pick_text_color(tuple(token["rgb"]))
        ordered.append(token)

    return ordered


def pick_text_color(rgb: tuple[int, int, int]) -> str:
    return "#0F172A" if relative_luminance(rgb) > 0.42 else "#FFFFFF"


def normalize_css_color_tokens(color_values: list[str]) -> list[dict[str, Any]]:
    tokens: list[dict[str, Any]] = []
    counts = Counter(color_values)
    total = sum(counts.values()) or 1
    for value, count in counts.most_common():
        rgb = parse_color_to_rgb(value)
        if not rgb:
            continue
        tokens.append(build_color_token(rgb, count / total))
    return assign_color_roles([token for token in tokens if token])


def extract_colors_from_css_sources(css_texts: list[str], computed_colors: list[str]) -> list[str]:
    raw_values: list[str] = []
    for css in css_texts:
        raw_values.extend(HEX_RE.findall(css))
        raw_values.extend(f"rgb({match})" for match in RGB_RE.findall(css))
    raw_values.extend(computed_colors)
    normalized = [normalize_color_string(value) for value in raw_values]
    filtered = [value for value in normalized if value and value.lower() not in {"transparent", "inherit", "currentcolor", "none"}]
    return filtered


def normalize_color_string(value: str) -> str:
    value = value.strip().strip('"').strip("'")
    if not value:
        return ""
    if value.startswith("#") and len(value) == 4:
        return "#" + "".join(char * 2 for char in value[1:]).upper()
    if value.startswith("#"):
        return value.upper()
    return value


def parse_color_to_rgb(value: str) -> tuple[int, int, int] | None:
    value = value.strip()
    if value.startswith("#"):
        cleaned = value.lstrip("#")
        if len(cleaned) == 3:
            cleaned = "".join(char * 2 for char in cleaned)
        if len(cleaned) != 6:
            return None
        return tuple(int(cleaned[index : index + 2], 16) for index in (0, 2, 4))
    match = RGB_RE.search(value)
    if not match:
        return None
    parts = [segment.strip() for segment in match.group(1).split(",")]
    if len(parts) < 3:
        return None
    try:
        return tuple(max(0, min(255, int(float(part)))) for part in parts[:3])
    except ValueError:
        return None


def merge_color_tokens(css_tokens: list[str], image_tokens: list[dict[str, Any]]) -> list[dict[str, Any]]:
    base: dict[str, dict[str, Any]] = {}
    css_counts = Counter(css_tokens)
    total = sum(css_counts.values()) or 1
    for value, count in css_counts.items():
        rgb = parse_color_to_rgb(value)
        if not rgb:
            continue
        base[rgb_to_hex(rgb)] = build_color_token(rgb, count / total)

    for token in image_tokens:
        existing = base.get(token["hex"])
        if existing:
            existing["usage_ratio"] = round(existing["usage_ratio"] + token["usage_ratio"] * 0.5, 4)
        else:
            blended = dict(token)
            blended["usage_ratio"] = round(token["usage_ratio"] * 0.7, 4)
            base[token["hex"]] = blended

    merged = sorted(base.values(), key=lambda item: item["usage_ratio"], reverse=True)
    return assign_color_roles(merged)


def extract_font_candidates(css_texts: list[str], computed_fonts: list[str]) -> list[str]:
    candidates: list[str] = []
    for css in css_texts:
        candidates.extend(FONT_RE.findall(css))
    candidates.extend(computed_fonts)
    cleaned: list[str] = []
    for candidate in candidates:
        chunks = [piece.strip().strip('"').strip("'") for piece in candidate.split(",")]
        for chunk in chunks:
            if not chunk:
                continue
            lowered = chunk.lower()
            if lowered in {"inherit", "unset", "initial"}:
                continue
            cleaned.append(chunk)
    ordered: list[str] = []
    seen: set[str] = set()
    for item in cleaned:
        if item.lower() in seen:
            continue
        seen.add(item.lower())
        ordered.append(item)
    return ordered[:8]


def build_typography_section(font_candidates: list[str], source_type: str) -> dict[str, Any]:
    heading_family = font_candidates[0] if font_candidates else "需人工确认（推荐先看 H1/H2 实际截图）"
    body_family = font_candidates[1] if len(font_candidates) > 1 else (font_candidates[0] if font_candidates else "需人工确认（倾向无衬线系统字体）")
    confidence = "medium" if font_candidates else "low"
    if source_type == "image":
        confidence = "low"

    summary = (
        "网页来源已结合 CSS/computed styles 提取字体候选，可直接作为二次梳理起点。"
        if font_candidates and source_type == "web"
        else "当前字体章节以启发式推断与候选描述为主，适合快速沉淀，不建议直接当作品牌字体定稿。"
    )

    return {
        "confidence": confidence,
        "summary": summary,
        "heading": {
            "family": heading_family,
            "weight": "600-700 倾向",
            "confidence": confidence,
        },
        "body": {
            "family": body_family,
            "weight": "400-500 倾向",
            "confidence": confidence,
        },
        "scale": [
            "标题层建议保持 2-3 级，避免过密层级导致信息噪声。",
            "正文与辅助说明建议形成 14/16/20 或类似递进关系。",
            "如果来源是网页，可继续在浏览器中核对实际字号、行高与字重。",
        ],
    }


def build_image_layout_section(preview_path: Path) -> dict[str, Any]:
    with Image.open(preview_path) as image:
        width, height = image.size
    ratio = round(width / height, 2) if height else 0
    orientation = "横向" if ratio > 1.15 else "纵向" if ratio < 0.9 else "接近方形"
    structure = [
        f"当前截图为 {orientation} 画幅，分辨率约 {width}×{height}。",
        "自动化脚本更擅长识别整体版式节奏与色彩分层，精确栅格需人工复核。",
    ]
    spacing = [
        "建议把主要版块间距抽象为 24/32/40 一组节奏，再根据截图复核。",
        "如果要继续产品化，建议补充多张页面截图后再统一整理间距 token。",
    ]
    return {
        "confidence": "low",
        "summary": "单张截图场景下，布局章节以版式趋势和节奏建议为主。",
        "structure": structure,
        "spacing": spacing,
        "breakpoints": ["当前输入不足以高置信度推断响应式断点，建议补充网页链接或多尺寸截图。"],
    }


def build_web_layout_section(page_data: dict[str, Any]) -> dict[str, Any]:
    structure = page_data["semantic_tags"] + page_data["structure_hints"]
    if not structure:
        structure = ["未发现明显语义标签，页面结构主要依赖 div/class 组织。"]

    sizes = page_data["size_values"]
    size_summary = summarize_sizes(sizes)
    breakpoints = [
        "如果页面存在移动端/桌面端双态，请在浏览器中进一步检查断点与折叠逻辑。",
        "自动化抓取优先记录容器宽度、padding/gap 和 max-width 线索。",
    ]
    return {
        "confidence": "medium" if sizes or structure else "low",
        "summary": "结合 DOM 结构和 CSS 尺寸线索，给出容器、栅格与间距的快速落版建议。",
        "structure": structure,
        "spacing": size_summary,
        "breakpoints": breakpoints,
    }


def summarize_sizes(values: list[int]) -> list[str]:
    if not values:
        return ["当前页面未抓到稳定的 margin/padding/gap 数值，建议用浏览器开发者工具二次确认。"]
    counts = Counter(values)
    common = [f"高频尺寸：{size}px（出现 {count} 次）" for size, count in counts.most_common(5)]
    if len(counts) >= 3:
        ordered = sorted(counts)[:6]
        common.append("可优先考虑整理为 spacing token：" + " / ".join(f"{size}px" for size in ordered))
    return common


def count_components(soup: BeautifulSoup) -> dict[str, int]:
    mapping = {
        "按钮": len(soup.select("button, [role='button'], .btn, .button, a[class*='btn']")),
        "输入框": len(soup.select("input, textarea, select")),
        "卡片": len(soup.select("[class*='card'], article, .panel")),
        "导航": len(soup.select("nav, header, [class*='nav'], [class*='menu']")),
        "标签": len(soup.select("[class*='tag'], [class*='badge'], [class*='chip']")),
        "弹窗": len(soup.select("dialog, [class*='modal'], [class*='drawer'], [role='dialog']")),
        "表格": len(soup.select("table")),
        "CTA 区块": len(soup.select("section [class*='cta'], [class*='hero'], [class*='banner']")),
    }
    return {key: value for key, value in mapping.items() if value > 0}


def summarize_semantic_tags(soup: BeautifulSoup) -> list[str]:
    tags = []
    for tag_name in ["header", "nav", "main", "section", "aside", "footer"]:
        count = len(soup.find_all(tag_name))
        if count:
            tags.append(f"页面包含 {count} 个 <{tag_name}> 语义分区。")
    return tags


def summarize_structure_hints(soup: BeautifulSoup) -> list[str]:
    hints = []
    section_count = len(soup.find_all(["section", "article"]))
    heading_count = len(soup.find_all(["h1", "h2", "h3"]))
    if section_count:
        hints.append(f"识别到 {section_count} 个 section/article，可视为主要内容切片。")
    if heading_count:
        hints.append(f"识别到 {heading_count} 个标题节点，信息层级相对清晰。")
    if soup.select_one("table"):
        hints.append("页面存在表格结构，偏信息型或后台型布局。")
    return hints


def collect_size_values(css_texts: list[str]) -> list[int]:
    values: list[int] = []
    for css in css_texts:
        for size_match in NUMBER_RE.findall(css):
            try:
                value = int(float(size_match))
            except ValueError:
                continue
            if 1 <= value <= 1600:
                values.append(value)
    return values


def build_components_section(component_counts: dict[str, int], source_type: str) -> dict[str, Any]:
    if not component_counts:
        summary = "当前输入未提供稳定组件证据，建议补充更完整页面或多张界面截图。"
        items = [
            {
                "name": "组件证据不足",
                "description": "自动化脚本未从当前来源中提取到足够的组件模式。",
                "evidence": "建议补充多页面或页面链接",
            }
        ]
        return {"confidence": "low", "summary": summary, "items": items}

    items = []
    for name, count in component_counts.items():
        items.append(
            {
                "name": name,
                "description": f"检测到 {count} 处相关节点，可继续抽象为该组件的尺寸、状态与使用规范。",
                "evidence": f"DOM/结构计数：{count}",
            }
        )
    confidence = "medium" if source_type == "web" else "low"
    return {
        "confidence": confidence,
        "summary": "优先输出高频结构组件，方便后续继续补状态和尺寸规则。",
        "items": items,
    }


def infer_style_from_palette(
    color_tokens: list[dict[str, Any]], metrics: dict[str, Any], source_type: str,
) -> dict[str, Any]:
    saturation = metrics.get("avg_saturation", 0.0)
    contrast = metrics.get("contrast", 0.0)
    primary = next((token for token in color_tokens if token["role"] == "primary"), color_tokens[0])
    keywords = ["现代"]
    evidence = [
        f"主色 {primary['hex']}，平均饱和度约 {saturation:.2f}。",
        f"画面对比跨度约 {contrast:.2f}。",
    ]

    if saturation < 0.18:
        keywords.append("克制")
    if contrast >= 0.55:
        keywords.append("高对比")
    if 180 <= primary["hue"] <= 250:
        keywords.append("科技感")
        keywords.append("B端专业")
    elif primary["saturation"] >= 0.5 and primary["hue"] <= 60:
        keywords.append("营销导向")
    else:
        keywords.append("信息理性")

    summary = (
        "整体风格偏 {0}，以 {1} 为主要视觉锚点，通过 {2} 建立信息层级。".format(
            "、".join(dict.fromkeys(keywords)),
            primary["hex"],
            "留白与色彩反差" if contrast >= 0.45 else "稳定的色彩节奏",
        )
    )
    confidence = "medium" if source_type == "image" else "high"
    return {
        "keywords": list(dict.fromkeys(keywords)),
        "summary": summary,
        "confidence": confidence,
        "evidence": evidence,
    }


def infer_style_from_page(
    page_data: dict[str, Any],
    color_tokens: list[dict[str, Any]],
    metrics: dict[str, Any],
) -> dict[str, Any]:
    style = infer_style_from_palette(color_tokens, metrics, source_type="web")
    keywords = style["keywords"][:]
    title = (page_data.get("title") or "").lower()
    components_total = sum(page_data["component_counts"].values())
    if any(word in title for word in ["dashboard", "admin", "console", "manage"]):
        keywords.append("后台控制台")
    if page_data["component_counts"].get("表格") or page_data["component_counts"].get("输入框"):
        keywords.append("功能型界面")
    if page_data["component_counts"].get("CTA 区块"):
        keywords.append("品牌展示")
    if components_total >= 8 and "营销导向" not in keywords:
        keywords.append("组件驱动")

    style["keywords"] = list(dict.fromkeys(keywords))
    style["summary"] = (
        f"页面风格偏 {'、'.join(style['keywords'])}，结合页面标题、组件密度与颜色体系，可作为后续设计系统抽象的初稿。"
    )
    style["confidence"] = "high" if page_data.get("used_browser") else "medium"
    style["evidence"].extend(
        [
            f"页面标题：{page_data.get('title') or '未识别'}。",
            f"组件节点总数：{components_total}。",
        ]
    )
    return style


def build_principles(
    style: dict[str, Any],
    color_tokens: list[dict[str, Any]],
    typography: dict[str, Any],
    layout: dict[str, Any],
    components: dict[str, Any],
) -> list[str]:
    primary = next((token for token in color_tokens if token["role"] == "primary"), color_tokens[0])
    background = next((token for token in color_tokens if token["role"] == "background"), color_tokens[0])
    text_token = next((token for token in color_tokens if token["role"] == "text"), color_tokens[-1])
    principles = [
        f"优先以 {background['hex']} + {text_token['hex']} 建立基础对比，再用 {primary['hex']} 承担操作与品牌锚点。",
        "把自动提取到的颜色与组件结果整理为 token，再进入设计系统或前端变量层会更稳。",
        f"标题倾向 {typography['heading']['family']}，正文倾向 {typography['body']['family']}，建议最终在真实界面中补齐字号与行高。",
        f"布局层当前总结为：{layout['summary']}",
        f"组件层当前总结为：{components['summary']}",
        f"风格关键词为 {', '.join(style['keywords'])}，说明这套设计更适合沿着统一视觉语言持续扩展。",
    ]
    return principles


def build_analysis(
    *,
    title: str,
    source_type: str,
    source_value: str,
    preview_path: Path | None,
    style: dict[str, Any],
    color_tokens: list[dict[str, Any]],
    typography: dict[str, Any],
    layout: dict[str, Any],
    components: dict[str, Any],
    principles: list[str],
    limitations: list[str],
    evidence_summary: list[str],
) -> dict[str, Any]:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    overview_summary = (
        "本次自动化提取优先基于真实图片/网页证据，先沉淀颜色、字体候选、布局线索和组件模式，再输出为可继续维护的设计规范文件。"
    )
    return {
        "meta": {
            "title": title,
            "generated_at": generated_at,
            "source_type": source_type,
            "source_value": source_value,
            "requested_format": "both",
        },
        "overview": {
            "summary": overview_summary,
            "evidence_summary": evidence_summary,
        },
        "style": style,
        "colors": {
            "confidence": "high" if source_type == "image" else ("high" if any(token['role'] == 'primary' for token in color_tokens) else "medium"),
            "summary": "优先保留主色、背景色、文本色和强调色，方便直接沉淀为设计 token。",
            "tokens": color_tokens,
        },
        "typography": typography,
        "layout": layout,
        "components": components,
        "principles": principles,
        "limitations": limitations,
        "assets": {
            "preview_relative": preview_path.name if preview_path else None,
            "preview_absolute": str(preview_path) if preview_path else None,
        },
    }


def write_markdown(analysis: dict[str, Any], output_dir: Path) -> Path:
    lines = [
        f"# {analysis['meta']['title']}",
        "",
        "## 项目概览",
        analysis["overview"]["summary"],
        "",
        f"- 来源类型：{analysis['meta']['source_type']}",
        f"- 原始输入：{analysis['meta']['source_value']}",
        f"- 生成时间：{analysis['meta']['generated_at']}",
        "",
        "## 风格摘要",
        f"关键词：{'、'.join(analysis['style']['keywords'])}",
        "",
        analysis["style"]["summary"],
        "",
        "## 配色规范",
    ]
    for token in analysis["colors"]["tokens"]:
        lines.append(
            f"- {token['role_label']}：{token['hex']}（占比约 {token['usage_ratio'] * 100:.1f}%）——{token['description']}"
        )
    lines.extend([
        "",
        "## 字体规范",
        f"- 标题：{analysis['typography']['heading']['family']}（{analysis['typography']['heading']['weight']}）",
        f"- 正文：{analysis['typography']['body']['family']}（{analysis['typography']['body']['weight']}）",
        "",
        "## 布局规范",
    ])
    for item in analysis["layout"]["structure"] + analysis["layout"]["spacing"]:
        lines.append(f"- {item}")
    lines.extend(["", "## 组件模式"])
    for item in analysis["components"]["items"]:
        lines.append(f"- {item['name']}：{item['description']}（{item['evidence']}）")
    lines.extend(["", "## 设计原则"])
    for principle in analysis["principles"]:
        lines.append(f"- {principle}")
    lines.extend(["", "## 限制说明"])
    for item in analysis["limitations"]:
        lines.append(f"- {item}")

    target = output_dir / "design_spec.md"
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def render_html(analysis: dict[str, Any], output_dir: Path) -> Path:
    template_dir = Path(__file__).resolve().parent.parent / "templates"
    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template(HTML_TEMPLATE)
    theme = build_theme(analysis["colors"]["tokens"])
    html = template.render(analysis=analysis, theme=theme)
    target = output_dir / "design_spec.html"
    target.write_text(html, encoding="utf-8")
    return target


def build_theme(tokens: list[dict[str, Any]]) -> dict[str, str]:
    lookup = {token["role"]: token for token in tokens}
    background = lookup.get("background", tokens[0])
    primary = lookup.get("primary", tokens[min(1, len(tokens) - 1)])
    accent = lookup.get("accent", primary)
    text = lookup.get("text", tokens[-1])
    border = lookup.get("border", background)
    return {
        "background": adjust_color(background["hex"], 0.97),
        "panel": "#FFFFFF",
        "text": text["hex"],
        "muted": mix_hex(text["hex"], background["hex"], 0.55),
        "border": mix_hex(border["hex"], background["hex"], 0.5),
        "primary": primary["hex"],
        "accent": accent["hex"],
    }


def adjust_color(hex_value: str, factor: float) -> str:
    rgb = parse_color_to_rgb(hex_value)
    if not rgb:
        return hex_value
    adjusted = tuple(max(0, min(255, int(channel * factor))) for channel in rgb)
    return rgb_to_hex(adjusted)


def mix_hex(hex_a: str, hex_b: str, ratio: float) -> str:
    rgb_a = parse_color_to_rgb(hex_a) or (15, 23, 42)
    rgb_b = parse_color_to_rgb(hex_b) or (248, 250, 252)
    mixed = tuple(int(rgb_a[index] * ratio + rgb_b[index] * (1 - ratio)) for index in range(3))
    return rgb_to_hex(mixed)


def render_pptx(analysis: dict[str, Any], output_dir: Path) -> Path:
    if not PPTX_AVAILABLE:
        raise ExtractionError("未安装 python-pptx，无法生成 PPTX。请先执行 pip install -r requirements.txt")

    presentation = Presentation()
    presentation.slide_width = Inches(13.333)
    presentation.slide_height = Inches(7.5)
    theme = build_theme(analysis["colors"]["tokens"])

    add_cover_slide(presentation, analysis, theme)
    add_overview_slide(presentation, analysis, theme)
    add_style_slide(presentation, analysis, theme)
    add_color_slide(presentation, analysis, theme)
    add_typography_slide(presentation, analysis, theme)
    add_layout_slide(presentation, analysis, theme)
    add_component_slide(presentation, analysis, theme)
    add_principles_slide(presentation, analysis, theme)

    target = output_dir / "design_spec.pptx"
    presentation.save(str(target))
    return target


def add_cover_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])
    fill_background(slide, theme["background"])
    add_text_box(slide, 0.8, 0.7, 8.5, 1.0, analysis["meta"]["title"], 30, bold=True, color=theme["text"])
    add_text_box(slide, 0.8, 1.8, 6.5, 0.8, "Design Spec Extractor Automation", 14, color=theme["primary"])
    add_text_box(
        slide,
        0.8,
        2.4,
        6.8,
        1.6,
        analysis["style"]["summary"],
        18,
        color=theme["text"],
    )
    add_text_box(
        slide,
        0.8,
        6.5,
        5.4,
        0.4,
        f"{analysis['meta']['generated_at']} · 来源：{analysis['meta']['source_type']}",
        11,
        color=theme["muted"],
    )
    add_preview_image(slide, analysis, 8.4, 0.8, 4.1, 5.5)


def add_overview_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "项目概览", analysis["overview"]["summary"], theme)
    y = 1.8
    for item in analysis["overview"]["evidence_summary"]:
        add_bullet_row(slide, item, theme, y)
        y += 0.55


def add_style_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "风格摘要", analysis["style"]["summary"], theme)
    add_text_box(slide, 0.8, 2.0, 4.0, 0.4, "关键词", 14, bold=True, color=theme["primary"])
    add_text_box(slide, 0.8, 2.4, 5.8, 1.0, "、".join(analysis["style"]["keywords"]), 20, color=theme["text"])
    add_text_box(slide, 7.0, 2.0, 5.2, 0.4, "证据", 14, bold=True, color=theme["primary"])
    y = 2.45
    for item in analysis["style"]["evidence"][:5]:
        add_bullet_row(slide, item, theme, y, x=7.0, width=5.2)
        y += 0.5


def add_color_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "配色规范", analysis["colors"]["summary"], theme)
    tokens = analysis["colors"]["tokens"][:6]
    x_positions = [0.8, 3.0, 5.2, 7.4, 9.6, 11.1]
    widths = [1.8, 1.8, 1.8, 1.8, 1.2, 1.2]
    for index, token in enumerate(tokens):
        x = x_positions[index]
        width = widths[index]
        add_color_card(slide, token, x, 2.2, width, 2.5)


def add_typography_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "字体规范", analysis["typography"]["summary"], theme)
    add_info_block(slide, "标题倾向", analysis["typography"]["heading"]["family"], 0.8, 2.0, 5.8, 1.3, theme)
    add_info_block(slide, "正文倾向", analysis["typography"]["body"]["family"], 7.0, 2.0, 5.5, 1.3, theme)
    y = 3.9
    for item in analysis["typography"]["scale"][:4]:
        add_bullet_row(slide, item, theme, y, width=11.7)
        y += 0.55


def add_layout_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "布局规范", analysis["layout"]["summary"], theme)
    add_text_box(slide, 0.8, 2.0, 4.0, 0.4, "结构/栅格", 14, bold=True, color=theme["primary"])
    y = 2.4
    for item in analysis["layout"]["structure"][:4]:
        add_bullet_row(slide, item, theme, y, width=5.4)
        y += 0.5
    add_text_box(slide, 7.0, 2.0, 4.0, 0.4, "间距/断点", 14, bold=True, color=theme["primary"])
    y = 2.4
    for item in (analysis["layout"]["spacing"] + analysis["layout"]["breakpoints"])[:5]:
        add_bullet_row(slide, item, theme, y, x=7.0, width=5.3)
        y += 0.5


def add_component_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "组件模式", analysis["components"]["summary"], theme)
    cards = analysis["components"]["items"][:4]
    positions = [(0.8, 2.1), (6.9, 2.1), (0.8, 4.2), (6.9, 4.2)]
    for item, (x, y) in zip(cards, positions):
        add_info_block(slide, item["name"], item["description"], x, y, 5.4, 1.5, theme, subtitle=item["evidence"])


def add_principles_slide(presentation: Presentation, analysis: dict[str, Any], theme: dict[str, str]) -> None:
    slide = new_content_slide(presentation, "设计原则与限制", "把观察沉淀为可复用规则，同时保留自动化推断的边界。", theme)
    y = 1.9
    for item in analysis["principles"][:4]:
        add_bullet_row(slide, item, theme, y, width=11.7)
        y += 0.55
    add_text_box(slide, 0.8, 4.6, 3.5, 0.35, "限制说明", 13, bold=True, color=theme["primary"])
    y = 4.95
    for item in analysis["limitations"][:3]:
        add_bullet_row(slide, item, theme, y, width=11.7)
        y += 0.48


def new_content_slide(
    presentation: Presentation,
    title: str,
    subtitle: str,
    theme: dict[str, str],
):
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])
    fill_background(slide, "#FFFFFF")
    add_text_box(slide, 0.8, 0.5, 8.0, 0.6, title, 24, bold=True, color=theme["text"])
    add_text_box(slide, 0.8, 1.05, 11.7, 0.7, subtitle, 12, color=theme["muted"])
    add_line(slide, 0.8, 1.55, 12.2, theme["border"])
    return slide


def fill_background(slide, hex_value: str) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*parse_color_to_rgb(hex_value))


def add_text_box(
    slide,
    left: float,
    top: float,
    width: float,
    height: float,
    text: str,
    font_size: int,
    *,
    bold: bool = False,
    color: str = "#0F172A",
) -> None:
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    text_frame = box.text_frame
    text_frame.clear()
    paragraph = text_frame.paragraphs[0]
    paragraph.text = text
    paragraph.font.size = Pt(font_size)
    paragraph.font.bold = bold
    paragraph.font.color.rgb = RGBColor(*parse_color_to_rgb(color))
    paragraph.font.name = "Microsoft YaHei"
    text_frame.word_wrap = True


def add_line(slide, left: float, top: float, width: float, color: str) -> None:
    line = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Inches(left),
        Inches(top),
        Inches(width),
        Inches(0.03),
    )
    line.fill.solid()
    line.fill.fore_color.rgb = RGBColor(*parse_color_to_rgb(color))
    line.line.fill.background()


def add_bullet_row(
    slide,
    text: str,
    theme: dict[str, str],
    top: float,
    *,
    x: float = 0.8,
    width: float = 5.6,
) -> None:
    bullet = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.OVAL, Inches(x), Inches(top + 0.12), Inches(0.12), Inches(0.12))
    bullet.fill.solid()
    bullet.fill.fore_color.rgb = RGBColor(*parse_color_to_rgb(theme["primary"]))
    bullet.line.fill.background()
    add_text_box(slide, x + 0.22, top, width, 0.4, text, 12, color=theme["text"])


def add_info_block(
    slide,
    title: str,
    body: str,
    left: float,
    top: float,
    width: float,
    height: float,
    theme: dict[str, str],
    *,
    subtitle: str | None = None,
) -> None:
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(left),
        Inches(top),
        Inches(width),
        Inches(height),
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*parse_color_to_rgb("#F8FAFC"))
    shape.line.color.rgb = RGBColor(*parse_color_to_rgb(theme["border"]))
    add_text_box(slide, left + 0.18, top + 0.12, width - 0.36, 0.3, title, 13, bold=True, color=theme["primary"])
    add_text_box(slide, left + 0.18, top + 0.46, width - 0.36, height - 0.58, body, 12, color=theme["text"])
    if subtitle:
        add_text_box(slide, left + 0.18, top + height - 0.32, width - 0.36, 0.2, subtitle, 10, color=theme["muted"])


def add_preview_image(slide, analysis: dict[str, Any], left: float, top: float, width: float, height: float) -> None:
    preview = analysis["assets"].get("preview_absolute")
    if not preview:
        add_info_block(slide, "无预览图", "当前来源未生成可嵌入截图。", left, top, width, 1.2, build_theme(analysis["colors"]["tokens"]))
        return
    slide.shapes.add_picture(preview, Inches(left), Inches(top), Inches(width), Inches(height))


def add_color_card(slide, token: dict[str, Any], left: float, top: float, width: float, height: float) -> None:
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(left),
        Inches(top),
        Inches(width),
        Inches(height),
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*token["rgb"])
    shape.line.fill.background()
    text_color = token.get("text_color", "#FFFFFF")
    add_text_box(slide, left + 0.14, top + 0.18, width - 0.28, 0.4, token["role_label"], 12, bold=True, color=text_color)
    add_text_box(slide, left + 0.14, top + 0.52, width - 0.28, 0.4, token["hex"], 11, color=text_color)
    add_text_box(slide, left + 0.14, top + 1.85, width - 0.28, 0.28, f"{token['usage_ratio'] * 100:.1f}%", 10, color=text_color)


if __name__ == "__main__":
    raise SystemExit(main())
