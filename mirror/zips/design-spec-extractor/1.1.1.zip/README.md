# Design Spec Extractor

## 定位

这个 Skill 用来把图片、截图、设计稿或网页链接中的视觉信息整理为结构化设计规范，适合沉淀设计系统、设计语言、规范文档、评审材料。现在它不只是一份流程说明，还内置了一套 Python 自动化脚本，可以直接生成 HTML / PPTX 交付物。

## 适用输入

- 本地图片或截图
- 图片 URL
- 网页 URL
- 多张设计稿组合输入（建议先逐一生成，再合并整理）

## 默认输出

如果用户没有指定输出格式，默认生成在线 HTML 规范文档；如果用户明确要汇报或评审材料，则生成设计规范 PPTX。脚本还会同步输出 `analysis.json` 与 `design_spec.md`，方便继续人工补充。

## 推荐触发词

- 提取设计规范
- 分析设计稿
- 设计规范生成
- 设计语言提取
- 设计系统文档
- 设计风格分析
- 设计配色方案
- 设计字体规范
- 设计布局规范
- 设计原理总结
- 图片风格分析
- 设计规范文档
- 设计规范Web
- 生成设计规范PPT
- 生成设计规范HTML

## 快速安装

在 Skill 目录执行：

```bash
python -m pip install -r requirements.txt
playwright install chromium
```

说明：`playwright install chromium` 不是强制步骤；如果不安装，网页分析会退化为 HTML/CSS 线索提取，但图片与静态网页流程仍可运行。

## 一键生成命令

### 1）从本地截图生成 HTML + PPTX

```bash
python scripts/generate_design_spec.py --image C:/path/to/ui.png --format both
```

### 2）从网页链接生成 HTML

```bash
python scripts/generate_design_spec.py --url https://stripe.com --format html --prefer-browser
```

### 3）自定义标题与输出目录

```bash
python scripts/generate_design_spec.py --url https://example.com --format both --title "品牌官网设计规范" --output-dir C:/temp/design-spec-output
```

## 输出文件

脚本默认会在当前目录创建 `design-spec-output/<timestamp_slug>/`，并生成：

- `analysis.json`：结构化分析结果
- `design_spec.md`：Markdown 文档
- `design_spec.html`：响应式 Web 文档
- `design_spec.pptx`：PPTX 演示文稿
- `source_preview.*`：原始预览图或网页截图

## 自动化执行流程

### 1. 判断任务类型

先确认用户目标是提取设计规范，而不是普通审美点评、法律规范整理或设计转代码。

### 2. 识别输入

识别是本地图片、图片 URL、网页 URL 还是多源输入，并统一成可分析的视觉证据。

### 3. 提取证据

- 图片：提取主色板、亮度/饱和度分布、画幅信息
- 网页：抓取 HTML/CSS，必要时用 Playwright 截图并补充 computed styles

### 4. 结构化分析

输出统一 JSON 结构，覆盖风格、配色、字体、布局、组件和设计原则。

### 5. 渲染交付物

- HTML：使用 Jinja2 模板生成响应式在线文档
- PPTX：使用 python-pptx 生成评审/汇报稿

### 6. 质量回退

如果网页动态内容无法访问，脚本会自动退化到 HTML/CSS 线索提取；如果字体无法高置信度识别，会明确标注为候选或需人工确认。

## 示例

### 示例 1：网页链接转在线规范文档

输入：帮我提取这个页面的设计规范，输出成 Web 文档 https://stripe.com

输出：结构化设计规范 + 在线 HTML 文档

### 示例 2：截图转规范 PPT

输入：分析这张设计稿的配色、字体和布局，生成设计规范 PPT

输出：自动生成的 `design_spec.pptx`

### 示例 3：多图归纳统一规范

输入：我有 3 张后台页面截图，帮我整理成设计系统文档

输出：建议逐张运行脚本生成 JSON/HTML，再合并共性规范与差异说明

## 边界

- 网页需要登录时，优先要求用户提供截图。
- 图片过糊时，不强行输出精确规范。
- 只有局部组件时，只输出局部规范，不冒充完整设计系统。
- 如果用户目标是把设计稿转成代码，应切换到 design-to-code 类能力。
- 如果是复杂前端应用且未安装浏览器运行时，网页样式提取会偏保守。
