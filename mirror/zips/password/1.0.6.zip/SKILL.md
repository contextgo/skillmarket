---
name: password
version: "2.0.0"
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
license: MIT-0
tags: [password, tool, utility]
description: "Manage passwords with generation, strength checks, and storage. Use when creating credentials, auditing strength, rotating secrets, checking breaches."
---

# Password

Password v2.0.0 — a security toolkit for recording and tracking password-related operations. Each command logs timestamped entries to local files, supports searching across all entries, exporting in multiple formats, and reviewing activity history. All data is stored locally with no network access required.

## Commands

| Command | Description |
|---------|-------------|
| `password generate <input>` | Record a generate entry (no args: show recent generate entries) |
| `password check-strength <input>` | Record a check-strength entry (no args: show recent entries) |
| `password rotate <input>` | Record a rotate entry (no args: show recent rotate entries) |
| `password audit <input>` | Record an audit entry (no args: show recent audit entries) |
| `password store <input>` | Record a store entry (no args: show recent store entries) |
| `password retrieve <input>` | Record a retrieve entry (no args: show recent retrieve entries) |
| `password expire <input>` | Record an expire entry (no args: show recent expire entries) |
| `password policy <input>` | Record a policy entry (no args: show recent policy entries) |
| `password report <input>` | Record a report entry (no args: show recent report entries) |
| `password hash <input>` | Record a hash entry (no args: show recent hash entries) |
| `password verify <input>` | Record a verify entry (no args: show recent verify entries) |
| `password revoke <input>` | Record a revoke entry (no args: show recent revoke entries) |
| `password stats` | Show summary statistics across all log files |
| `password export <fmt>` | Export all data in `json`, `csv`, or `txt` format |
| `password search <term>` | Search all entries for a keyword (case-insensitive) |
| `password recent` | Show the 20 most recent history entries |
| `password status` | Show health check (version, data dir, entry count, disk usage, last activity) |
| `password help` | Show usage information |
| `password version` | Show version (v2.0.0) |

## Data Storage

All data is stored locally in `~/.local/share/password/`:

- **`{command}.log`** — One file per command (e.g., `generate.log`, `audit.log`, `rotate.log`, `store.log`). Each line is `timestamp|value`.
- **`history.log`** — Unified activity log with timestamps for every recorded action.
- **`export.{json|csv|txt}`** — Generated export files:
  - **JSON** — Array of `{type, time, value}` objects
  - **CSV** — Header row `type,time,value` followed by data rows
  - **TXT** — Sections grouped by command name with all entries

The `stats` command reads all `.log` files and reports per-file entry counts, total count, disk usage, and the timestamp of the earliest entry. The `search` command performs case-insensitive grep across all log files and displays matches grouped by category.

## Requirements

- **bash 4+** (uses `local`, `set -euo pipefail`)
- Standard POSIX utilities: `date`, `wc`, `du`, `tail`, `head`, `grep`, `sed`, `basename`, `cat`, `cut`
- No external dependencies, no API keys, no network access

## When to Use

1. **Logging password generation events** — Record each time a password is generated with `password generate <description>` to maintain an audit trail.
2. **Tracking password rotations** — Use `password rotate <service>` to log when credentials are rotated for specific services or accounts.
3. **Auditing password policies** — Record audit and policy entries to document security reviews and policy changes over time.
4. **Reviewing security activity** — Use `password recent` to see the last 20 actions, or `password search <term>` to find specific entries across all categories.
5. **Exporting security logs** — Use `password export json` to generate a structured export of all password-related activity for compliance or external analysis.

## Examples

```bash
# Record a password generation event
password generate "Created 32-char password for prod-db"
#   [Password] generate: Created 32-char password for prod-db
#   Saved. Total generate entries: 1

# Record a rotation event
password rotate "Rotated API key for payment-gateway"
#   [Password] rotate: Rotated API key for payment-gateway
#   Saved. Total rotate entries: 1

# Check recent generate entries (no arguments shows history)
password generate
# Recent generate entries:
#   2025-03-18 14:30|Created 32-char password for prod-db

# Record an audit finding
password audit "All service accounts reviewed - 3 expired credentials found"

# Search for entries related to "prod"
password search prod
# Searching for: prod
#   --- generate ---
#     2025-03-18 14:30|Created 32-char password for prod-db

# View summary statistics
password stats
# === Password Stats ===
#   generate: 1 entries
#   rotate: 1 entries
#   audit: 1 entries
#   ---
#   Total: 3 entries
#   Data size: 4.0K
#   Since: 03-18 14:30

# Health check
password status
# === Password Status ===
#   Version: v2.0.0
#   Data dir: /home/user/.local/share/password
#   Entries: 3 total
#   Disk: 4.0K
#   Last activity: 03-18 14:35 audit: All service accounts reviewed
#   Status: OK

# Export all data as JSON
password export json
# Exported to /home/user/.local/share/password/export.json (256 bytes)
```

## Output

All results are printed to stdout. Every action that records data also appends to `history.log` for unified tracking. Export files are written to the data directory.

## Configuration

The data directory defaults to `~/.local/share/password/`. It is created automatically on first run.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
