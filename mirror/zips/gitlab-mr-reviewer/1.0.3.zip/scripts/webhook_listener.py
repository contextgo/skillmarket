#!/usr/bin/env python3
"""
GitLab Webhook Listener → OpenClaw Bridge

Receives GitLab MR webhook events and triggers the gitlab-mr-reviewer skill
via OpenClaw's /hooks/agent API.

Usage:
    python webhook_listener.py --port 18800
    python webhook_listener.py --port 18800 --secret "your-webhook-secret"

GitLab webhook configuration:
    URL:    http://your-server:18800/webhook
    Secret: (optional, recommended)
    Trigger: Merge Request Events, Push Events

Environment variables:
    GITLAB_WEBHOOK_SECRET    — Webhook secret token (alternative to --secret)
    OPENCLAW_GATEWAY_URL     — OpenClaw gateway base URL (default: http://127.0.0.1:18789)
    OPENCLAW_HOOK_PATH       — OpenClaw hooks base path (default: /webhooks/gitlab)
    OPENCLAW_HOOK_TOKEN      — Token for webhook endpoint
"""

import argparse
import hmac
import json
import os
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Optional
import urllib.request
import urllib.error
from context_config import get_config_value, load_context_config, resolve_value

DEFAULT_TRIGGER_ACTIONS = {"open", "reopen", "update"}
DEFAULT_PUSH_REVIEW_BRANCHES = {"main", "master", "develop", "dev"}


def _to_set(value: Any, default: set[str]) -> set[str]:
    if value in (None, ""):
        return set(default)
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, (list, tuple, set)):
        items = [str(item).strip() for item in value]
    else:
        return set(default)
    return {item for item in items if item}


def _to_list(value: Any, default: list[str]) -> list[str]:
    if value in (None, ""):
        return list(default)
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, (list, tuple)):
        items = [str(item).strip() for item in value]
    else:
        return list(default)
    return [item for item in items if item]


def _to_int(value: Any, default: int) -> int:
    if value in (None, ""):
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _to_bool(value: Any, default: bool) -> bool:
    if value in (None, ""):
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return default


def _normalize_channel(value: Any) -> str:
    """OpenClaw currently only accepts channel='last'."""
    normalized = str(value or "").strip().lower()
    return "last" if normalized != "last" else normalized


def trigger_openclaw_review(gateway_url: str, hook_path: str, token: str,
                            mr_id: int, mr_title: str, author: str,
                            target_branch: str, source_branch: str,
                            project_name: str, sender_name: str,
                            wake_mode: str, deliver: bool,
                            channel: str, timeout_sec: int,
                            review_language: str, notify_feishu: bool,
                            severity_threshold: str,
                            force_publish_gitlab: bool,
                            force_notify_feishu: bool):
    """Call OpenClaw webhook/agent endpoint to trigger the gitlab-mr-reviewer skill."""
    language = (review_language or "zh").lower()
    enforce_chinese = language in {"zh", "zh-cn", "cn", "chinese", "中文"}
    language_requirement = (
        "输出要求: 审查结论、行内评论、总结报告必须使用中文；禁止输出英文审查结果。"
        if enforce_chinese
        else "输出要求: 按配置语言输出审查结论、行内评论和总结报告。"
    )
    report_requirement = (
        "格式要求: 不得简化审查结果和报告结构；必须保留完整审查结论、风险分级、问题列表与建议。"
    )
    skill_tone_requirement = (
        "说明: 仅允许将 skill 的表达方式做机器化简洁，不得简化审查内容本身。"
    )
    notification_requirement = (
        f"通知要求: 审查完成后必须调用 scripts/feishu_notifier.py 发送飞书通知，并按阈值 {severity_threshold} 判断重点风险。"
        if (force_notify_feishu or notify_feishu)
        else "通知要求: 未开启强制通知且未配置飞书 webhook，可跳过飞书通知。"
    )
    publish_requirement = (
        "发布要求: 必须发布 GitLab 审查结果（优先行内评论，失败则回退 MR 总结评论）。"
        if force_publish_gitlab
        else "发布要求: 按常规流程发布 GitLab 审查结果。"
    )
    publish_dedup_requirement = (
        "去重要求: 同一次 webhook 任务只允许发布 1 次 MR 总结评论；禁止重复发布第二条总结评论。"
    )
    publish_encoding_requirement = (
        "编码要求: 发布到 GitLab 的评论必须是 UTF-8 中文可读文本，禁止发布乱码（如 ???）。"
    )
    receipt_requirement = (
        "回执要求: 在最终回复中必须给出发送回执：gitlab_publish=success|fail，feishu_notify=success|fail，"
        "并附失败原因；禁止只输出分析结论。"
    )
    hook_semantic = (
        "触发语义: 这是 System Hook GitLab 自动触发任务，等价于『审核 MR #"
        f"{mr_id} 并通知飞书』。"
    )
    notify_config_requirement = (
        "如果未读取到飞书 webhook 配置，必须明确报错并提示补齐配置；不允许静默跳过。"
        if force_notify_feishu and not notify_feishu
        else ""
    )
    message = (
        f"审核 MR #{mr_id} 并通知飞书\n"
        f"项目: {project_name}\n"
        f"标题: {mr_title}\n"
        f"作者: {author}\n"
        f"分支: {source_branch} -> {target_branch}\n"
        "要求: 使用 gitlab-mr-reviewer 完成审查并输出结论。\n"
        f"{hook_semantic}\n"
        f"{language_requirement}\n"
        f"{report_requirement}\n"
        f"{skill_tone_requirement}\n"
        f"{publish_requirement}\n"
        f"{publish_dedup_requirement}\n"
        f"{publish_encoding_requirement}\n"
        f"{notification_requirement}\n"
        f"{receipt_requirement}"
    )
    if notify_config_requirement:
        message = f"{message}\n{notify_config_requirement}"
    normalized_channel = _normalize_channel(channel)
    payload_dict = {
        "message": message,
        "name": sender_name,
        "wakeMode": wake_mode,
        "deliver": deliver,
        "channel": normalized_channel,
    }
    payload = json.dumps(payload_dict).encode()

    url = f"{gateway_url.rstrip('/')}{hook_path}/agent"
    req = urllib.request.Request(url, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            status = resp.getcode()
            body = resp.read().decode("utf-8", errors="replace")
        print(f"[openclaw] MR !{mr_id} → skill triggered (status={status})")
        print(f"[openclaw] response: {body[:500]}")
        return status, body
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        if exc.code == 400 and "channel must be last" in body.lower() and normalized_channel != "last":
            retry_payload = dict(payload_dict)
            retry_payload["channel"] = "last"
            retry_req = urllib.request.Request(url, data=json.dumps(retry_payload).encode(), method="POST")
            retry_req.add_header("Content-Type", "application/json")
            retry_req.add_header("Authorization", f"Bearer {token}")
            try:
                with urllib.request.urlopen(retry_req, timeout=timeout_sec) as retry_resp:
                    status = retry_resp.getcode()
                    retry_body = retry_resp.read().decode("utf-8", errors="replace")
                print(f"[openclaw] MR !{mr_id} → retried with channel=last (status={status})")
                print(f"[openclaw] response: {retry_body[:500]}")
                return status, retry_body
            except Exception as retry_exc:
                print(f"[openclaw] MR !{mr_id} → retry failed: {retry_exc}")
        print(f"[openclaw] MR !{mr_id} → trigger failed (status={exc.code}): {body[:500]}")
        return exc.code, body
    except Exception as exc:
        print(f"[openclaw] MR !{mr_id} → trigger error: {exc}")
        return 502, str(exc)

class WebhookHandler(BaseHTTPRequestHandler):
    secret: Optional[str] = None
    gateway_url: str = "http://127.0.0.1:18789"
    hook_path: str = "/webhooks/gitlab"
    hook_token: str = ""
    base_branch: str = "main"
    listen_path: str = "/webhook"
    listen_aliases: set[str] = {"/webhooks/gitlab"}
    health_path: str = "/health"
    max_payload_bytes: int = 5 * 1024 * 1024
    enable_mr_events: bool = True
    enable_push_events: bool = True
    mr_trigger_actions: set[str] = set(DEFAULT_TRIGGER_ACTIONS)
    mr_required_state: str = "opened"
    mr_skip_tags: list[str] = ["[skip-review]"]
    push_review_branches: set[str] = set(DEFAULT_PUSH_REVIEW_BRANCHES)
    openclaw_sender_name: str = "GitLab"
    openclaw_wake_mode: str = "now"
    openclaw_deliver: bool = True
    openclaw_channel: str = "last"
    openclaw_timeout_sec: int = 30
    review_language: str = "zh"
    review_severity_threshold: str = "high"
    feishu_webhook_configured: bool = False
    force_publish_gitlab: bool = True
    force_notify_feishu: bool = True

    def do_POST(self):
        request_path = self.path.split("?", 1)[0].rstrip("/")
        allowed_paths = {self.listen_path, *self.listen_aliases}
        if request_path not in allowed_paths:
            self.send_error(404)
            return

        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0 or content_length > self.max_payload_bytes:
            self.send_error(400, "Invalid content length")
            return

        payload = self.rfile.read(content_length)

        if self.secret:
            sig = self.headers.get("X-Gitlab-Token", "")
            if not hmac.compare_digest(sig, self.secret):
                self.send_error(403, "Invalid token")
                return

        event = self.headers.get("X-Gitlab-Event", "")

        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            self.send_error(400, "Invalid JSON")
            return

        if event == "Merge Request Hook" and self.enable_mr_events:
            self._handle_mr_event(data)
        elif event == "Push Hook" and self.enable_push_events:
            self._handle_push_event(data)
        else:
            self._respond(200, {"status": "ignored", "reason": f"event={event}"})

    def _handle_mr_event(self, data: dict):
        attrs = data.get("object_attributes", {})
        action = attrs.get("action", "")
        mr_id = attrs.get("iid")
        mr_title = attrs.get("title", "")
        state = attrs.get("state", "")
        target_branch = attrs.get("target_branch") or self.base_branch
        source_branch = attrs.get("source_branch", "")
        author = data.get("user", {}).get("name", "unknown")
        project_name = data.get("project", {}).get("path_with_namespace", "")

        lowered_title = (mr_title or "").lower()
        if any(tag.lower() in lowered_title for tag in self.mr_skip_tags):
            self._respond(200, {"status": "skipped", "reason": "title_skip_review_tag", "mr_id": mr_id})
            return

        state_allowed = (not self.mr_required_state) or (state == self.mr_required_state)
        if action not in self.mr_trigger_actions or not state_allowed:
            self._respond(200, {"status": "skipped", "action": action, "state": state})
            return
        if self.force_notify_feishu and not self.feishu_webhook_configured:
            error_msg = "forceNotifyFeishuOnWebhook=true but notifications.feishuWebhookUrl is empty"
            print(f"[webhook] MR !{mr_id} trigger blocked: {error_msg}")
            self._respond(500, {"status": "error", "reason": "feishu_webhook_missing", "detail": error_msg, "mr_id": mr_id})
            return

        print(f"[webhook] MR !{mr_id} '{mr_title}' action={action} → triggering OpenClaw skill")
        thread = threading.Thread(
            target=trigger_openclaw_review,
            args=(self.gateway_url, self.hook_path, self.hook_token, mr_id,
                  mr_title, author, target_branch, source_branch, project_name,
                  self.openclaw_sender_name, self.openclaw_wake_mode,
                  self.openclaw_deliver, self.openclaw_channel,
                  self.openclaw_timeout_sec, self.review_language,
                  self.feishu_webhook_configured, self.review_severity_threshold,
                  self.force_publish_gitlab, self.force_notify_feishu),
            daemon=True,
        )
        thread.start()
        self._respond(200, {"status": "accepted", "mr_id": mr_id})

    def _handle_push_event(self, data: dict):
        ref = data.get("ref", "")
        branch = ref.replace("refs/heads/", "")
        if branch not in self.push_review_branches:
            self._respond(200, {"status": "skipped", "reason": f"push to {branch}, not in review branches"})
            return

        commits = data.get("commits", [])
        if not commits:
            self._respond(200, {"status": "skipped", "reason": "no commits"})
            return

        project_name = data.get("project", {}).get("path_with_namespace", "")
        author = data.get("user_name", "unknown")
        commit_count = len(commits)
        last_commit_msg = commits[-1].get("message", "").split("\n")[0] if commits else ""

        message = (
            f"收到 push 事件，请检查 {project_name} 的 {branch} 分支最新 {commit_count} 个提交\n"
            f"最新提交: {last_commit_msg}\n"
            f"推送者: {author}"
        )
        normalized_channel = _normalize_channel(self.openclaw_channel)
        payload = json.dumps({
            "message": message,
            "name": self.openclaw_sender_name,
            "wakeMode": self.openclaw_wake_mode,
            "deliver": self.openclaw_deliver,
            "channel": normalized_channel,
        }).encode()

        url = f"{self.gateway_url.rstrip('/')}{self.hook_path}/agent"
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {self.hook_token}")

        try:
            with urllib.request.urlopen(req, timeout=self.openclaw_timeout_sec) as resp:
                status = resp.getcode()
                body = resp.read().decode("utf-8", errors="replace")
            print(f"[openclaw] push {branch} → notified (status={status})")
            self._respond(200, {"status": "accepted", "branch": branch})
        except Exception as exc:
            print(f"[openclaw] push {branch} → notify failed: {exc}")
            self._respond(502, {"status": "error", "error": str(exc)})

    def do_GET(self):
        if self.path == self.health_path:
            self._respond(200, {"status": "ok"})
        else:
            self.send_error(404)

    def _respond(self, code: int, body: dict):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(body).encode())

    def log_message(self, format, *args):
        print(f"[http] {format % args}")


def main():
    parser = argparse.ArgumentParser(description="GitLab Webhook → OpenClaw Bridge")
    parser.add_argument("--port", type=int, help="Listen port (default from reviewer.config.json: webhookListener.port)")
    parser.add_argument("--context-file", help="JSON config path (default: ../reviewer.config.json)")
    parser.add_argument("--secret", help="GitLab webhook secret token")
    parser.add_argument("--gateway-url", help="OpenClaw gateway URL")
    parser.add_argument("--hook-path", help="OpenClaw hooks base path")
    parser.add_argument("--hook-token", help="OpenClaw hook token")
    parser.add_argument("--base-branch", help="Default base branch")
    args = parser.parse_args()
    cfg = load_context_config(args.context_file)
    listener_cfg = get_config_value(cfg, "webhookListener", {})
    openclaw_cfg = get_config_value(cfg, "openclaw", {})
    review_cfg = get_config_value(cfg, "review", {})
    notifications_cfg = get_config_value(cfg, "notifications", {})

    WebhookHandler.secret = resolve_value(
        args.secret,
        get_config_value(openclaw_cfg, "gitlabWebhookSecret"),
        "GITLAB_WEBHOOK_SECRET",
        "",
    )
    WebhookHandler.gateway_url = resolve_value(
        args.gateway_url,
        get_config_value(openclaw_cfg, "gatewayUrl"),
        "OPENCLAW_GATEWAY_URL",
        "http://127.0.0.1:18789",
    )
    WebhookHandler.hook_path = resolve_value(
        args.hook_path,
        get_config_value(openclaw_cfg, "hookPath"),
        "OPENCLAW_HOOK_PATH",
        "/webhooks/gitlab",
    ).rstrip("/")
    WebhookHandler.hook_token = resolve_value(
        args.hook_token,
        get_config_value(openclaw_cfg, "hookToken"),
        "OPENCLAW_HOOK_TOKEN",
        "",
    )
    WebhookHandler.base_branch = resolve_value(
        args.base_branch,
        get_config_value(cfg, "gitlab.defaultBaseBranch"),
        "GITLAB_DEFAULT_BASE_BRANCH",
        "main",
    )
    WebhookHandler.listen_path = str(get_config_value(listener_cfg, "listenPath", "/webhook")).rstrip("/") or "/webhook"
    WebhookHandler.health_path = str(get_config_value(listener_cfg, "healthPath", "/health"))
    WebhookHandler.max_payload_bytes = _to_int(get_config_value(listener_cfg, "maxPayloadBytes"), 5 * 1024 * 1024)
    WebhookHandler.enable_mr_events = _to_bool(get_config_value(listener_cfg, "enableMergeRequestEvents"), True)
    WebhookHandler.enable_push_events = _to_bool(get_config_value(listener_cfg, "enablePushEvents"), True)
    WebhookHandler.mr_trigger_actions = _to_set(get_config_value(listener_cfg, "mrTriggerActions"), DEFAULT_TRIGGER_ACTIONS)
    WebhookHandler.mr_required_state = str(get_config_value(listener_cfg, "mrRequiredState", "opened"))
    WebhookHandler.mr_skip_tags = _to_list(get_config_value(listener_cfg, "mrSkipTitleTags"), ["[skip-review]"])
    WebhookHandler.push_review_branches = _to_set(get_config_value(listener_cfg, "pushReviewBranches"), DEFAULT_PUSH_REVIEW_BRANCHES)
    WebhookHandler.openclaw_sender_name = str(get_config_value(listener_cfg, "openclawSenderName", "GitLab"))
    WebhookHandler.openclaw_wake_mode = str(get_config_value(listener_cfg, "openclawWakeMode", "now"))
    WebhookHandler.openclaw_deliver = _to_bool(get_config_value(listener_cfg, "openclawDeliver"), True)
    WebhookHandler.openclaw_channel = _normalize_channel(get_config_value(listener_cfg, "openclawChannel", "last"))
    alias_list = _to_list(get_config_value(listener_cfg, "listenAliases"), ["/webhooks/gitlab"])
    WebhookHandler.listen_aliases = {a.rstrip("/") or "/" for a in alias_list}
    WebhookHandler.openclaw_timeout_sec = _to_int(get_config_value(listener_cfg, "openclawTimeoutSec"), 30)
    WebhookHandler.review_language = str(get_config_value(review_cfg, "language", "zh"))
    WebhookHandler.review_severity_threshold = str(get_config_value(review_cfg, "severityThreshold", "high"))
    feishu_webhook_url = get_config_value(notifications_cfg, "feishuWebhookUrl", "") or os.environ.get("FEISHU_WEBHOOK_URL", "")
    WebhookHandler.feishu_webhook_configured = bool(feishu_webhook_url)
    WebhookHandler.force_publish_gitlab = _to_bool(get_config_value(listener_cfg, "forcePublishGitlabOnWebhook"), True)
    WebhookHandler.force_notify_feishu = _to_bool(get_config_value(listener_cfg, "forceNotifyFeishuOnWebhook"), True)
    listen_port = _to_int(resolve_value(args.port, get_config_value(listener_cfg, "port"), "GITLAB_WEBHOOK_PORT", 18800), 18800)

    if not WebhookHandler.hook_token:
        print("[webhook] WARNING: No OPENCLAW_HOOK_TOKEN set, API calls will fail")

    server = HTTPServer(("0.0.0.0", listen_port), WebhookHandler)
    print(f"[webhook] Listening on 0.0.0.0:{listen_port}{WebhookHandler.listen_path}")
    print(f"[webhook] Webhook listen aliases: {sorted(WebhookHandler.listen_aliases)}")
    print(f"[webhook] OpenClaw gateway: {WebhookHandler.gateway_url}")
    print(f"[webhook] OpenClaw hook endpoint: {WebhookHandler.hook_path}/agent")
    print(f"[webhook] OpenClaw channel: {WebhookHandler.openclaw_channel}")
    print(f"[webhook] Review language: {WebhookHandler.review_language}")
    print(f"[webhook] Feishu webhook configured: {WebhookHandler.feishu_webhook_configured}")
    print(f"[webhook] Force publish GitLab on webhook: {WebhookHandler.force_publish_gitlab}")
    print(f"[webhook] Force notify Feishu on webhook: {WebhookHandler.force_notify_feishu}")
    if WebhookHandler.force_notify_feishu and not WebhookHandler.feishu_webhook_configured:
        print("[webhook] ERROR: forceNotifyFeishuOnWebhook=true but Feishu webhook is missing; MR webhook will be rejected")
    if WebhookHandler.secret:
        print("[webhook] GitLab secret token verification enabled")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[webhook] Shutting down")
        server.server_close()


if __name__ == "__main__":
    main()
