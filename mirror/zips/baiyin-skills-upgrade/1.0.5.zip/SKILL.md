---
name: baiyin-skills-upgrade
version: 1.0.5
description: 
  为百音 skills 提供统一的版本检查、中文升级询问、自动更新配置、暂缓提醒和本地覆盖升级流程。被其他 `baiyin-*` skill 的前导检查引用。
allowed-tools:
  - Bash
  - Read
  - Write
  - AskUserQuestion
---

# /baiyin-skills-upgrade

统一处理 `skill/` 目录下百音技能的升级流程。

适用范围：

- `skill/baiyin-video-skill`
- `skill/baiyin-image-generate-skill`
- `skill/baiyin-music-generate`
- `skill/baiyin-voice-generate-skill`
- `skill/baiyin-cover-sing-skill`
- `skill/baiyin-cover-train-skill`
- `skill/baiyin-digital-human-lipsync`
- `skill/baiyin-track-separation-skill`

## 内联升级流程

当其他百音 skill 的前导检查输出：

```text
UPGRADE_AVAILABLE <old> <new> <slug>
```

时，执行下面流程。

### 第 1 步：定位 skill 根目录

```bash
ROOT_DIR="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
TARGET_SKILL_DIR="$ROOT_DIR/skill/<slug>"
```

要求：

- 目标目录必须存在
- 目标目录下必须有 `SKILL.md` 和 `_meta.json`
- 不对 `baiyin-skills-upgrade` 自身做递归升级

如果目标目录不存在或元数据损坏：

- 直接继续当前任务
- 不要阻塞用户当前请求

### 第 2 步：检查自动更新配置

优先读取统一配置：

```bash
AUTO_UPGRADE=$(bash "$ROOT_DIR/skill/bin/baiyin-skill-config" get auto_upgrade 2>/dev/null || echo "false")
UPDATE_CHECK=$(bash "$ROOT_DIR/skill/bin/baiyin-skill-config" get update_check 2>/dev/null || echo "true")
echo "AUTO_UPGRADE=$AUTO_UPGRADE"
echo "UPDATE_CHECK=$UPDATE_CHECK"
```

规则：

- 如果 `UPDATE_CHECK=false`：直接继续当前任务，不再追问
- 如果 `AUTO_UPGRADE=true`：跳过询问，直接进入第 4 步

### 第 3 步：中文询问用户是否升级

如果宿主支持 `AskUserQuestion`，使用中文四选一：

- `立即更新`
- `以后自动更新`
- `暂不更新`
- `不再提醒`

建议文案：

- 问题：`检测到百音技能 <slug> 有新版本（当前 v<old>，最新 v<new>），是否现在更新？`

如果宿主不支持 `AskUserQuestion`，直接使用纯文本中文提问：

```text
检测到百音技能 <slug> 有新版本（当前 v<old>，最新 v<new>）。
请回复：1 立即更新 / 2 以后自动更新 / 3 暂不更新 / 4 不再提醒。
```

选项处理：

- `立即更新`：进入第 4 步
- `以后自动更新`：
  ```bash
  bash "$ROOT_DIR/skill/bin/baiyin-skill-config" set auto_upgrade true
  ```
  然后进入第 4 步
- `暂不更新`：
  ```bash
  LEVEL=$(bash "$ROOT_DIR/skill/bin/baiyin-skill-config" snooze "<slug>" "<new>")
  ```
  按 `LEVEL` 提示中文文案：
  - `1`：`已暂缓提醒 24 小时。`
  - `2`：`已暂缓提醒 48 小时。`
  - `3`：`已暂缓提醒 7 天。`
  然后继续当前任务
- `不再提醒`：
  ```bash
  bash "$ROOT_DIR/skill/bin/baiyin-skill-config" set update_check false
  ```
  提示：`已关闭百音技能版本提醒，可稍后手动重新开启。`
  然后继续当前任务

### 第 4 步：执行升级

调用统一升级脚本：

```bash
bash "$ROOT_DIR/skill/bin/baiyin-skill-upgrade" "$TARGET_SKILL_DIR" "<new>"
```

成功时输出形如：

```text
UPGRADED <old> <new> <slug>
```

失败时输出形如：

```text
UPGRADE_FAILED <slug> <reason>
```

### 第 5 步：升级成功后的用户提示

如果升级成功，向用户输出中文摘要：

```text
百音技能 <slug> 已更新：v<old> -> v<new>

更新完成，已继续执行你刚才的任务。
```

如果刚才选择的是“以后自动更新”，补一句：

```text
已开启百音技能自动更新，后续检测到新版本会自动安装。
```

### 第 6 步：升级失败后的处理

如果输出 `UPGRADE_FAILED`：

- 告诉用户：`百音技能 <slug> 更新失败，已保留本地旧版本，继续执行当前任务。`
- 不要求用户重新输入之前的业务参数
- 不要因为升级失败终止当前业务流程

## 独立使用

当用户直接调用 `/baiyin-skills-upgrade` 时：

1. 枚举 `skill/` 目录下全部 `baiyin-*`
2. 对每个 skill 执行：
   ```bash
   bash "$ROOT_DIR/skill/bin/baiyin-skill-update-check" "$ROOT_DIR/skill/<slug>"
   ```
3. 对返回 `UPGRADE_AVAILABLE` 的 skill，逐个按上面的中文流程询问和升级
4. 对返回 `UP_TO_DATE`、`SNOOZED`、`CHECK_DISABLED` 的 skill，不重复打扰用户

输出建议：

```text
百音技能检查完成。

- 可更新：<n> 个
- 已是最新：<n> 个
- 已暂缓提醒：<n> 个
- 已关闭提醒：<n> 个
```

## 实现约束

- 不要自己拼接未知的 SkillHub HTTP 接口
- 优先复用本地 `skillhub` CLI
- 所有面向用户的提示必须使用中文
- 业务 skill 自身不负责写升级逻辑，只负责调用统一前导和本升级 skill
