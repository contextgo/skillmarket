#!/usr/bin/env python3
import sys
import argparse
import os

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
except ImportError:
    print("Error: 'python-pptx' is not installed. Please run 'pip install python-pptx' first.")
    sys.exit(1)

def generate_ppt(outline_text, output_path):
    """
    Generate a PPT from a Markdown-like outline.
    Format:
    # Page Title 1
    - Point 1
    - Point 2

    # Page Title 2
    - Point 1
    """
    prs = Presentation()

    # Title Slide
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    title.text = "自动生成的 PPT"
    subtitle.text = "由 JoyGen PPT 生成技能驱动"

    lines = outline_text.strip().split('\n')
    current_slide = None
    current_content = []

    def add_content_slide(title_text, points):
        if not title_text:
            return
        bullet_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(bullet_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        body_shape = shapes.placeholders[1]

        title_shape.text = title_text
        tf = body_shape.text_frame
        for point in points:
            p = tf.add_paragraph()
            p.text = point
            p.level = 0

    current_title = ""
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('#'):
            # New Slide
            if current_title:
                add_content_slide(current_title, current_content)
            current_title = line.lstrip('#').strip()
            current_content = []
        elif line.startswith('-'):
            current_content.append(line.lstrip('-').strip())
        else:
            current_content.append(line)

    # Add the last slide
    if current_title:
        add_content_slide(current_title, current_content)

    prs.save(output_path)
    print(f"PPT successfully saved to {output_path}")

def main():
    parser = argparse.ArgumentParser(description="PPT 生成脚本")
    parser.add_argument("--outline", help="包含 PPT 提纲的 Markdown 文件路径")
    parser.add_argument("--text", help="直接输入 PPT 提纲内容文本")
    parser.add_argument("--output", default="presentation.pptx", help="输出文件路径")

    args = parser.parse_args()

    outline_content = ""
    if args.outline:
        if os.path.exists(args.outline):
            with open(args.outline, 'r', encoding='utf-8') as f:
                outline_content = f.read()
        else:
            print(f"Error: Outline file {args.outline} not found.")
            sys.exit(1)
    elif args.text:
        outline_content = args.text
    else:
        # Default example if no input provided
        outline_content = """
# 欢迎使用 PPT 生成工具
- 简单、高效、自动。
- 支持 Markdown 格式输入。

# 项目背景
- 该技能由 JoyGen 驱动。
- 帮助用户快速将创意转化为演示文稿。
"""

    generate_ppt(outline_content, args.output)

if __name__ == "__main__":
    main()
