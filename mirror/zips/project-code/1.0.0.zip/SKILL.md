---
name: ppt-generator
description: 幻灯片(PPT)生成工具。当用户需要根据文本、大纲或内容生成 PPT 演示文稿、制作演示文稿时使用。
---

# PPT 生成

这是一个用于快速生成 PPT 演示文稿的技能。它可以根据用户输入的大纲、要点或详细内容，通过自动化脚本生成专业的 PPT。

## 使用场景

- 快速根据会议纪要生成 PPT。
- 自动化生成产品介绍演示文稿。
- 将课程大纲转换为 PPT 幻灯片。

## 使用说明

### 1. 准备内容

按以下格式提供 PPT 的内容：

```markdown
# 页面 1: [标题]
- [正文点 1]
- [正文点 2]

# 页面 2: [标题]
- [正文点 1]
- [正文点 2]
```

### 2. 生成 PPT

使用 `scripts/generate_ppt.py` 生成文件：

```bash
# 首先安装依赖
pip install python-pptx

# 运行脚本
python public/ppt-generator/scripts/generate_ppt.py --outline "outline.md" --output "my_presentation.pptx"
```

### 3. 查看输出

生成的 `my_presentation.pptx` 文件可以直接在 PowerPoint、WPS 或 Google Slides 中打开。

## 资源

- **scripts/**: 包含核心 Python 生成逻辑。
- **assets/**: 存放 PPT 模板 (.pptx)（可选）。
- **references/**: 存放 python-pptx API 手册或示例。
