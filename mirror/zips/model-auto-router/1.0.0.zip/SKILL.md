---
name: model-router
description: >
  根据任务需求动态选择最适合的 AI 模型并调用。当用户需要调用 AI 模型完成任务、
  询问"用哪个模型"、"帮我调用模型"、"选个合适的模型"时触发。
  实时拉取模型列表，用两级分类（关键词快判 + 仅对陌生模型联网搜索）构建分类表，
  结果在会话内缓存复用，兼顾速度与准确性。
---

# Model Router 技能（OpenClaw /model 版）

## 概述

**目标：又快又准地从 OpenClaw 可用模型中选出最合适的模型。**

- **快**：关键词覆盖 80%+ 常见模型，无需搜索；会话内缓存，二次路由零开销
- **准**：陌生模型并行联网搜索后归类，不靠猜

模型来源：OpenClaw `/model` 命令识别到的模型列表，无需外部 API。

---

## 完整执行流程

```
本次会话已有分类缓存？
    YES → 直接跳到 Step 3 路由
    NO  → Step 1 → Step 2 → Step 3
```

---

## Step 1：获取当前可用模型列表

**检查对话上下文**：若用户已在此次会话中运行过 `/model`，直接从上下文中读取模型列表，无需重复获取。

**若模型列表不在上下文中**，提示用户：

```
请在 OpenClaw 中运行 /model 命令，然后将输出结果粘贴到这里。
```

从 `/model` 输出中提取所有可用模型 ID，得到模型集合。

---

## Step 2：两级分类，构建分类表

### 第一级：关键词快判（毫秒级，无需搜索）

按以下规则**从上到下**匹配，首次命中即归类：

```
模型 ID 匹配规则（优先级从高到低）                    归类
─────────────────────────────────────────────────────────────
含 embed / embedding                                → EMBED

含 o1 / o3 / o4（独立词或前缀）                    → STRONG_REASON
含 kimi / moonshot                                  → STRONG_REASON
含 deepseek-r / deepseek-reasoner                   → STRONG_REASON
含 nemotron 且含 70b / 120b / 340b                  → STRONG_REASON

含 gpt-4o / gpt-4-turbo / gpt-4.5                  → TOP_GENERAL
含 claude-3-opus / claude-3-5 / claude-4            → TOP_GENERAL
含 gemini-1.5-pro / gemini-2 / gemini-exp           → TOP_GENERAL

含 minimax 且含 m2.7 / m3 / pro / large            → CREATIVE

含 glm-5 / glm-z1 / glm-4-plus                     → CHINESE_ADVANCED
含 glm-4.7 / glm-4-air（非 :free）                 → CHINESE_ADVANCED
含 glm-4（其余） / yuanbao / hunyuan               → CHINESE_GENERAL
含 qwen-max / qwen-plus / qwen-turbo                → CHINESE_GENERAL

含 minimax 且含 m2.5 / m2.0                        → BALANCED
含 gpt-3.5 / gpt-4o-mini                           → BALANCED
含 llama-3 / mistral / mixtral（无 embed）          → BALANCED

含 :free 且含 air / lite / flash / mini / nano      → FAST_FREE
含 :free（其余，非 embed）                          → FAST_FREE
```

未命中任何规则 → 进入第二级。

### 第二级：联网搜索（仅对未命中的陌生模型，并行执行）

对每个未归类模型，并行执行 `web_search`：

```
搜索词："{model_id}" AI model capabilities benchmark
```

从结果提取：参数规模、擅长任务、官方定位；据此归类。
信息不足时默认归入 `BALANCED`。

### 输出分类表并缓存

```
📋 模型分类表（已缓存，本次会话复用）

STRONG_REASON  : model-a, model-b
TOP_GENERAL    : model-c
CREATIVE       : model-d
CHINESE_ADV    : model-e, model-f
CHINESE_GEN    : model-g
BALANCED       : model-h
FAST_FREE      : model-i
EMBED          : model-j

⚡ 关键词快判：N 个 ｜ 联网搜索：M 个 ｜ 共 N+M 个模型
```

> **缓存失效条件**：用户明确说模型列表有变化，或重新运行 `/model` 发现列表不同。

---

## Step 3：任务分析与路由

### 快速判断任务维度

| 维度 | 判断方式 |
|------|----------|
| 语言 | 中文为主 / 英文为主 / 混合 |
| 复杂度 | 简单（单轮） / 中等 / 复杂（多步推理） |
| 任务类型 | 代码·数学·推理 / 创意写作 / 对话·问答 / 向量化 / 综合 |
| 成本敏感 | 用户提到"省钱/免费/快" → 是；默认否 |

### 路由映射

```
任务特征                          → 首选桶           → 兜底桶
──────────────────────────────────────────────────────────────
向量化 / embedding                → EMBED            → 无
代码 / 数学 / 多步推理 / Agent    → STRONG_REASON    → TOP_GENERAL
英文复杂分析                      → STRONG_REASON    → TOP_GENERAL
明确要求最强效果                  → TOP_GENERAL      → STRONG_REASON
创意写作 / 小说 / 剧本 / 长文     → CREATIVE         → BALANCED
中文复杂分析 / 报告 / 摘要        → CHINESE_ADV      → STRONG_REASON
中文日常对话 / 翻译 / 简单问答    → CHINESE_GEN      → CHINESE_ADV
成本优先 / 简单任务 / 批量处理    → FAST_FREE        → BALANCED
其余均衡任务                      → BALANCED         → CHINESE_GEN
```

### 桶内选模型规则

1. 非成本敏感 → 优先付费（无 `:free`）
2. 成本敏感 → 优先 `:free`
3. 同桶同等条件 → 参数更大 / 版本更新的优先
4. 仍然并列 → 选第一个

目标桶为空时，自动降级到兜底桶，并告知用户。

**用户已明确指定模型时：跳过路由，直接使用。**

---

## Step 4：输出路由结果 + 切换指令

```
🎯 推荐模型：`模型名称`
📋 路由依据：[任务类型] → [目标桶] → [一句话选择理由]
💰 成本：免费 / 付费
⚡ 分类来源：关键词快判 / 联网搜索

▶ 在 OpenClaw 中运行以下命令切换模型：
  /model 模型名称
```

若目标桶有多个候选，可附上备选列表：

```
🔁 同桶备选（效果相近）：model-x, model-y
```

---

## 注意事项

- **EMBED 桶隔离**：嵌入模型不参与对话路由，对话模型不参与嵌入请求
- **缓存机制**：分类表在会话内复用，不重复拉取和搜索
- **用户覆盖**：用户明确指定模型时直接采纳，不强制路由