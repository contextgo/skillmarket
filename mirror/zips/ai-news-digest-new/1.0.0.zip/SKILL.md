---
name: ai_global_intelligence_radar
description: Periodically collect, verify, classify, score, and summarize global AI development signals across models, policy, research, open source, infrastructure, capital, and applications.
version: 1.0.0
metadata:
  openclaw:
    emoji: "🌐"
    envVars:
      - name: AI_RADAR_OUTPUT_DIR
        required: false
        description: Optional local directory for saving briefings, source logs, and CSV/JSON exports.
      - name: AI_RADAR_LANGUAGE
        required: false
        description: Optional output language. Default is zh-CN.
      - name: AI_RADAR_REGION_FOCUS
        required: false
        description: Optional comma-separated region focus, for example global,US,EU,China,UK,Japan,Korea,Singapore,MiddleEast.
      - name: AI_RADAR_FEISHU_WEBHOOK
        required: false
        description: Optional Feishu/Lark webhook for delivery if the agent has permission to use it.
      - name: AI_RADAR_SLACK_WEBHOOK
        required: false
        description: Optional Slack webhook for delivery if the agent has permission to use it.
---

# AI Global Intelligence Radar Skill

## Purpose

Use this skill to build and maintain a recurring global AI intelligence radar. The goal is not to collect random AI news, but to transform global signals into decision-grade intelligence for opportunity identification, risk monitoring, and strategic planning.

This skill should be used when the user asks for:

- daily, weekly, monthly, or quarterly AI development briefings;
- monitoring global AI models, products, policies, regulations, funding, research, open source, infrastructure, chips, data centers, cloud, and commercial adoption;
- maintaining an AI intelligence database, watchlist, or decision dashboard;
- identifying business opportunities from AI capability improvements, cost reductions, regulatory shifts, capital flows, or adoption inflection points.

Default output language: Simplified Chinese (`zh-CN`). Keep key entity names and source titles in their original language when useful.

## Core operating principles

1. Treat all current AI information as time-sensitive. Always verify recent facts with fresh sources rather than relying on memory.
2. Prefer primary sources for high-impact claims: company blogs, model/system cards, official docs, government/regulator pages, official conference pages, papers, earnings releases, benchmark pages, and public datasets.
3. Use reputable secondary sources for context and interpretation, but label them as secondary.
4. Every non-obvious factual claim in the briefing must have a source URL, publisher, publication date, and event date if available.
5. Separate facts, interpretation, and speculation. Use labels: `Confirmed`, `Likely`, `Rumor/Unverified`, `Analysis`.
6. Deduplicate the same event across multiple outlets. Keep the primary source plus one strong secondary source when helpful.
7. For major or market-moving items, verify with at least two independent sources when possible.
8. Avoid long verbatim quotations. Summarize in your own words and include short quotes only when they are essential.
9. Do not include confidential, private, or credential-bearing information in outputs.
10. The final product should answer: `What changed? Why does it matter? Who is affected? What should we monitor or do next?`

## Intelligence categories

Classify every collected signal into one primary category and, if needed, secondary tags.

### 1. Macro AI trend and global index

Track global AI development indicators, national competitiveness, adoption, investment, model capability trends, compute trends, training/inference costs, talent, patents, publications, and long-cycle datasets.

Representative source types:

- Stanford AI Index
- Our World in Data AI pages
- OECD AI Policy Observatory
- Epoch AI
- national AI strategy reports
- major consulting/research institute reports when methodology is clear

### 2. Frontier models and AI products

Track new model releases, model updates, multimodal capability, reasoning, coding, agents, voice, video, robotics, memory, personalization, enterprise features, API updates, pricing, context window, latency, throughput, tool use, and safety/system cards.

Representative source types:

- official AI lab/company newsrooms, blogs, docs, changelogs, model cards, system cards, API docs
- OpenAI, Anthropic, Google DeepMind, Meta AI, Microsoft, xAI, Mistral, Cohere, Perplexity, DeepSeek, Alibaba Qwen, Moonshot/Kimi, Zhipu, MiniMax, Baidu, Tencent, ByteDance, Huawei and other relevant labs/vendors
- Artificial Analysis, LMArena, OpenRouter, Hugging Face model pages, benchmark repositories

### 3. Policy, regulation, governance, and geopolitics

Track AI laws, executive orders, implementation guidance, safety institutes, standards, export controls, data/privacy rules, copyright/litigation, public procurement, national compute initiatives, and sector-specific AI governance.

Regions to monitor:

- United States
- European Union
- China
- United Kingdom
- Canada
- Japan
- South Korea
- Singapore
- India
- Middle East, especially UAE and Saudi Arabia
- other countries when there is a major AI policy shift

Representative source types:

- official government and regulator pages
- NIST, NSF, FTC, FCC, White House/AI.gov, US Congress where relevant
- European Commission, European AI Office, EU AI Act implementation resources
- China CAC, MIIT, State Council, National Data Administration, CAICT
- OECD, UNESCO, ISO/IEC, national AI safety institutes

### 4. Research, papers, and academic conferences

Track technical breakthroughs likely to influence industry within 3–12 months.

Topics:

- model architecture, post-training, reasoning, agents, tool use, memory
- retrieval, long-context, synthetic data, evaluation, alignment, interpretability
- multimodal, video, audio, 3D, robotics, embodied AI, world models
- AI for science, medicine, materials, biology, climate, cybersecurity
- efficient inference, distillation, quantization, serving systems

Representative source types:

- arXiv categories: cs.AI, cs.LG, cs.CL, cs.CV, cs.RO, stat.ML
- Papers with Code or similar SOTA trackers
- NeurIPS, ICML, ICLR, ACL, EMNLP, CVPR, ICCV/ECCV, SIGGRAPH, RSS, CoRL
- official lab papers and technical reports

### 5. Open source ecosystem and developer tooling

Track open models, datasets, evals, agent frameworks, RAG tools, model serving, inference engines, vector databases, observability, coding agents, workflow automation, and fast-growing repositories.

Representative source types:

- GitHub Trending and GitHub topics
- Hugging Face trending models/datasets/spaces
- release notes from key open-source projects
- developer communities, but only after verifying claims through repositories or official docs

### 6. Compute, chips, cloud, and data centers

Track GPU supply, AI accelerators, cloud capacity, data center construction, energy, liquid cooling, sovereign AI clouds, inference infrastructure, networking, storage, and cost-per-token trends.

Representative source types:

- NVIDIA, AMD, Intel, cloud provider announcements, semiconductor company investor materials
- AWS, Azure, Google Cloud, Oracle Cloud, CoreWeave, Lambda, Together, Fireworks, Cerebras, Groq and similar providers
- credible semiconductor, cloud, and data-center analyst sources
- earnings calls and regulatory filings when relevant

### 7. Capital, startups, and M&A

Track funding rounds, valuations, acquisitions, IPO signals, revenue traction, enterprise adoption, startup maps, sector rotation, and investor theses.

Representative source types:

- Crunchbase, PitchBook, CB Insights, Dealroom where available
- company announcements
- reputable business/tech media
- SEC filings or exchange announcements when relevant
- China-focused sources such as 36Kr, IT桔子, 投中, 清科, 甲子光年, 晚点, 钛媒体 when appropriate

### 8. Applications and commercialization

Track adoption in major verticals and business workflows.

Priority verticals:

- software engineering and coding agents
- customer support, sales, marketing, and operations
- education and training
- healthcare, pharma, and life sciences
- finance, insurance, legal, compliance
- manufacturing, logistics, robotics, autonomous systems
- media, entertainment, games, video, music, design
- government and public-sector AI

### 9. China AI ecosystem

Track Chinese AI labs, model releases, policy, chips, cloud, applications, enterprise adoption, education, open-source models, and investment.

Representative source types:

- official ministries and regulators: CAC, MIIT, National Data Administration, State Council
- CAICT and relevant industry alliances
- company blogs and model pages: Alibaba Qwen, DeepSeek, Moonshot/Kimi, Zhipu, MiniMax, Baidu, Tencent, ByteDance, Huawei and others
- credible Chinese tech/business media: 机器之心, 量子位, 36氪, 晚点, 甲子光年, 钛媒体, 雷峰网, AI科技评论, InfoQ中文

### 10. Risk, safety, security, and misuse

Track AI safety incidents, model misuse, cyber risks, data leakage, copyright lawsuits, hallucination failures, evaluation failures, system vulnerabilities, agent failures, regulatory penalties, and enterprise compliance risks.

Representative source types:

- official incident reports and security advisories
- regulator enforcement actions
- AI safety institute publications
- peer-reviewed or credible technical reports
- reputable security vendors and vulnerability databases

## Run modes and cadence

Determine run mode from the user message or scheduled-task prompt.

### Daily brief

Use when the task asks for `daily`, `今日`, `日报`, `morning brief`, or a 24-hour/36-hour scan.

Default scope:

- look back 24 hours; extend to 36 hours for global timezone coverage;
- collect 10–20 noteworthy signals;
- prioritize P0 and P1 items;
- include a compact source log.

### Weekly brief

Use when the task asks for `weekly`, `周报`, or week-in-review.

Default scope:

- look back 7 days;
- synthesize trends rather than listing every item;
- compare model leaderboard/pricing changes if available;
- identify 3–7 strategic implications and follow-up questions.

### Monthly review

Use when the task asks for `monthly`, `月报`, `月度`, or landscape review.

Default scope:

- look back one calendar month;
- summarize structural changes across capability, cost, policy, infrastructure, capital, and adoption;
- include a watchlist and opportunity map.

### Quarterly strategic report

Use when the task asks for `quarterly`, `季度`, `Q1/Q2/Q3/Q4`, or board/strategy update.

Default scope:

- look back one calendar quarter;
- produce a strategic narrative, market map, risk map, and recommended bets;
- explicitly distinguish short-term tactical opportunities from long-term strategic shifts.

## Collection workflow

For each run:

1. Establish the run context:
   - current date and timezone;
   - run mode and lookback window;
   - language and region focus;
   - output destination if specified.
2. Generate search baskets by category:
   - frontier models and product launches;
   - policy and regulation;
   - research and papers;
   - open source and developer tools;
   - compute/chips/cloud/data centers;
   - capital/startups/M&A;
   - commercialization and vertical applications;
   - China AI ecosystem;
   - risk, safety, security, and legal.
3. Search fresh sources. Start with primary sources when possible, then use secondary sources for interpretation.
4. Extract each candidate item into the signal schema below.
5. Deduplicate and merge related items.
6. Score each signal for impact, urgency, confidence, and business relevance.
7. Select final items based on priority and strategic relevance.
8. Write the briefing using the correct output template.
9. Include a source log and a follow-up watchlist.
10. If writing to files is allowed, save both a human-readable Markdown briefing and a machine-readable JSON/CSV signal log.

## Signal schema

Use this schema internally for every item. For saved outputs, preserve these fields as JSON or CSV when possible.

```json
{
  "collected_at": "ISO-8601 timestamp",
  "run_mode": "daily | weekly | monthly | quarterly | ad_hoc",
  "lookback_window": "24h | 36h | 7d | 1m | 1q | custom",
  "event_date": "YYYY-MM-DD or unknown",
  "source_publish_date": "YYYY-MM-DD or unknown",
  "region": "Global | US | EU | China | UK | Japan | Korea | Singapore | Middle East | Other",
  "category": "macro | models | policy | research | open_source | infrastructure | capital | applications | china | risk",
  "entity": "company, institution, model, product, regulator, project, or paper",
  "title": "short item title",
  "summary_cn": "1-3 sentence Chinese summary",
  "original_claim": "concise original claim in source language if useful",
  "source_name": "publisher or organization",
  "source_url": "URL",
  "source_type": "primary | secondary | benchmark | paper | database | community",
  "confidence": "high | medium | low",
  "verification_status": "confirmed | likely | unverified | analysis",
  "impact_score": 1,
  "urgency_score": 1,
  "business_relevance_score": 1,
  "priority": "P0 | P1 | P2 | P3",
  "opportunity": "specific opportunity or none",
  "risk": "specific risk or none",
  "recommended_action": "monitor | analyze | contact | test | invest_watch | ignore",
  "tags": ["agent", "policy", "pricing", "chip", "China", "open-source"]
}
```

## Scoring rules

### Impact score

- 5: materially changes AI capability, cost, regulation, market structure, or competitive dynamics.
- 4: important for a major category, company, region, or customer segment.
- 3: meaningful but limited to a submarket or technical niche.
- 2: useful context but not strategically urgent.
- 1: low signal, routine update, or weak relevance.

### Urgency score

- 5: requires action or decision within 24–72 hours.
- 4: should be reviewed this week.
- 3: should be monitored in the next month.
- 2: background context.
- 1: archive only.

### Business relevance score

- 5: directly affects product strategy, investment, partnership, sales, compliance, or infrastructure planning.
- 4: likely to affect one major business workstream.
- 3: potentially relevant but needs further validation.
- 2: indirect relevance.
- 1: low relevance.

### Priority

- P0: impact >= 5 or urgent regulatory/security/market event.
- P1: impact >= 4 or business relevance >= 4.
- P2: relevant trend or technical development worth monitoring.
- P3: background item; include only in source log unless the run has spare capacity.

## Daily brief template

```markdown
# 全球AI雷达｜Daily Brief｜YYYY-MM-DD

## 0. Executive Summary
- 今日最重要变化：...
- 对业务最可能产生影响的信号：...
- 需要立即跟进的事项：...

## 1. Top Signals
| Priority | Category | Entity | What changed | Why it matters | Action | Sources |
|---|---|---|---|---|---|---|
| P0/P1 | ... | ... | ... | ... | ... | ... |

## 2. Model & Product Watch
- ...

## 3. Policy & Regulation Watch
- ...

## 4. Research / Open Source / Infrastructure
- ...

## 5. Capital & Commercialization
- ...

## 6. China AI Watch
- ...

## 7. Risk / Safety / Legal
- ...

## 8. Follow-up Watchlist
| Item | Why monitor | Next check | Owner/Action |
|---|---|---|---|

## 9. Source Log
| Source | Date | Type | Category | Note |
|---|---:|---|---|---|
```

## Weekly brief template

```markdown
# 全球AI雷达｜Weekly Brief｜YYYY-MM-DD to YYYY-MM-DD

## 0. One-page Takeaway
用 5–8 条要点总结本周全球AI的结构性变化。

## 1. 本周趋势判断
| Trend | Evidence | Confidence | Business implication |
|---|---|---|---|

## 2. Top 10 Signals
| Rank | Priority | Category | Entity | Signal | Impact | Recommended action | Sources |
|---:|---|---|---|---|---|---|---|

## 3. Frontier Model / Agent / Product Landscape
- Capability changes:
- Pricing or latency changes:
- Enterprise adoption signals:

## 4. Policy / Governance / Legal
- US:
- EU:
- China:
- Other regions:

## 5. Research and Open Source
- Papers to read:
- Repositories to test:
- Benchmarks/evals to monitor:

## 6. Infrastructure and Compute
- Chips/cloud/data centers:
- Cost and supply signals:

## 7. Capital and Startup Map
- Funding/M&A:
- New company/product categories:
- Watchlist:

## 8. Opportunities and Risks
| Opportunity/Risk | Trigger | Who benefits | Who is threatened | Next step |
|---|---|---|---|---|

## 9. Source Log
```

## Monthly review template

```markdown
# 全球AI雷达｜Monthly Strategic Review｜YYYY-MM

## 1. Strategic Summary
本月最重要的 3–5 个结构性变化。

## 2. Capability Curve
模型、Agent、多模态、视频、机器人、AI for Science 等能力变化。

## 3. Cost Curve
训练/推理/部署/云资源/芯片供应相关变化。

## 4. Regulation Curve
美国、欧盟、中国及其他重点地区政策变化。

## 5. Capital and Startup Curve
融资、并购、估值、热门赛道、失败信号。

## 6. Commercial Adoption Curve
企业采用、行业案例、采购、ROI、生产化障碍。

## 7. China vs Global Comparison
中国与全球在模型、算力、应用、政策、资本上的相对变化。

## 8. Opportunity Map
| Opportunity | Evidence | Timing | Required capability | Risk | Suggested next step |
|---|---|---|---|---|---|

## 9. Watchlist for Next Month
```

## Quarterly strategic report template

```markdown
# 全球AI雷达｜Quarterly Strategic Report｜YYYY QX

## 1. Board-level Summary

## 2. Global Competitive Landscape

## 3. Technology Inflection Points

## 4. Policy and Geopolitical Risk

## 5. Infrastructure and Cost Structure

## 6. Capital and Startup Ecosystem

## 7. Vertical Adoption and Business Opportunities

## 8. China / US / EU / Other Regional Comparison

## 9. Strategic Bets
| Bet | Rationale | Time horizon | Upside | Risk | Evidence | Next step |
|---|---|---|---|---|---|---|

## 10. Appendix: Source Log and Signal Database Summary
```

## Recommended source portfolio

Use this list as a starting point. Do not treat it as exhaustive. Add or remove sources based on the user's business domain.

### Global dashboards and datasets

- Stanford AI Index
- Our World in Data: Artificial Intelligence
- OECD AI Policy Observatory
- Epoch AI
- AI.gov where relevant for US official AI initiatives
- European Commission / European AI Office
- China CAC, MIIT, National Data Administration, CAICT

### Model and benchmark trackers

- Official company/lab blogs and docs
- Artificial Analysis
- LMArena
- OpenRouter model pages
- Hugging Face trending models/datasets/spaces
- Papers with Code or comparable SOTA trackers

### Research

- arXiv: cs.AI, cs.LG, cs.CL, cs.CV, cs.RO, stat.ML
- NeurIPS, ICML, ICLR, ACL, EMNLP, CVPR, ICCV/ECCV, SIGGRAPH, RSS, CoRL
- Official technical reports from leading labs

### Open source and developer ecosystem

- GitHub Trending
- GitHub releases for important repositories
- Hugging Face
- major framework/project release notes

### Capital and business

- Crunchbase
- PitchBook
- CB Insights
- Dealroom
- The Information, Financial Times, Wall Street Journal, Bloomberg, Reuters, TechCrunch, VentureBeat, The Verge, Semafor, Stratechery, Ben Thompson, Latent Space, The Batch, SemiAnalysis where available and appropriate
- Chinese business/tech media: 36氪, 晚点, 甲子光年, 钛媒体, 机器之心, 量子位, 雷峰网, InfoQ中文, AI科技评论

## Query patterns

Use these as search seeds. Adapt them to the run date, region, and category.

### Daily search seeds

- `AI model release OR model update last 24 hours`
- `frontier AI model pricing API latency benchmark latest`
- `AI regulation policy guidance announcement latest`
- `AI startup funding acquisition latest`
- `AI chip GPU data center cloud announcement latest`
- `arXiv LLM agent reasoning multimodal new paper`
- `Hugging Face trending model today`
- `GitHub trending AI agent RAG LLM inference`
- `中国 人工智能 大模型 政策 融资 发布 最新`
- `AI safety security incident lawsuit copyright latest`

### Weekly search seeds

- `AI weekly recap models regulation funding research`
- `LLM benchmark leaderboard changes this week`
- `AI infrastructure GPU cloud data center weekly news`
- `AI venture funding this week generative AI agents`
- `中国 AI 大模型 周报 政策 融资 开源`

### Monthly search seeds

- `AI market map monthly report models agents infrastructure regulation`
- `AI VC trends monthly generative AI agents infrastructure`
- `AI policy monthly update US EU China`
- `AI benchmark model pricing monthly changes`

## Output and file-saving rules

If the user or environment allows writing files:

1. Save Markdown briefs under:
   - `${AI_RADAR_OUTPUT_DIR}/briefs/YYYY-MM-DD-daily.md`
   - `${AI_RADAR_OUTPUT_DIR}/briefs/YYYY-WW-weekly.md`
   - `${AI_RADAR_OUTPUT_DIR}/briefs/YYYY-MM-monthly.md`
   - `${AI_RADAR_OUTPUT_DIR}/briefs/YYYY-QX-quarterly.md`
2. Save machine-readable signal logs under:
   - `${AI_RADAR_OUTPUT_DIR}/signals/YYYY-MM-DD-signals.json`
   - `${AI_RADAR_OUTPUT_DIR}/signals/YYYY-MM-DD-signals.csv`
3. If `AI_RADAR_OUTPUT_DIR` is not set, return the briefing in chat and include the source log.
4. Never overwrite an existing briefing without asking, unless the scheduled task explicitly says to update the same file.

## Quality-control checklist

Before returning a briefing, check:

- [ ] Is the run window clearly stated?
- [ ] Are exact dates used instead of vague wording like “recently”?
- [ ] Are primary sources used for major claims where possible?
- [ ] Are rumors or unclear claims labeled as unverified?
- [ ] Are source URLs and publication dates recorded?
- [ ] Are duplicate stories merged?
- [ ] Does each P0/P1 item explain business impact?
- [ ] Does the briefing include recommended actions or watchlist items?
- [ ] Are China, US, EU, and global perspectives balanced according to the user's focus?
- [ ] Are long quotations avoided?

## Example scheduled-task prompts

### Daily brief prompt

```text
Use the ai_global_intelligence_radar skill. Produce today's Global AI Radar Daily Brief in Simplified Chinese. Look back 36 hours. Prioritize frontier model releases, AI policy/regulation, AI infrastructure, China AI ecosystem, capital/startup activity, and risks. Include source URLs, publication dates, confidence labels, impact/urgency scores, and a follow-up watchlist.
```

### Weekly brief prompt

```text
Use the ai_global_intelligence_radar skill. Produce this week's Global AI Radar Weekly Brief in Simplified Chinese. Look back 7 days. Focus on structural shifts rather than a long news list. Include top 10 signals, model/product landscape, policy changes, research/open-source items to test, infrastructure/cost changes, capital/startup map, opportunities, risks, and source log.
```

### Monthly review prompt

```text
Use the ai_global_intelligence_radar skill. Produce the monthly Global AI Strategic Review in Simplified Chinese. Cover capability curve, cost curve, regulation curve, capital/startup curve, commercialization curve, China vs global comparison, opportunity map, risk map, and next-month watchlist. Use sourced facts and separate facts from analysis.
```

### Quarterly strategic report prompt

```text
Use the ai_global_intelligence_radar skill. Produce a quarterly strategic report on global AI development in Simplified Chinese. Build a board-level summary, competitive landscape, technology inflection points, policy/geopolitical risks, infrastructure/cost structure, capital ecosystem, vertical adoption, China/US/EU comparison, strategic bets, and appendix source log.
```

## Example OpenClaw cron commands

These examples assume the user's default timezone is `America/Los_Angeles`. Replace the timezone, channel, and recipient as needed.

### Weekday daily brief at 07:30

```bash
openclaw cron add \
  --name "AI Radar Daily Brief" \
  --cron "30 7 * * 1-5" \
  --tz "America/Los_Angeles" \
  --session isolated \
  --message "Use the ai_global_intelligence_radar skill. Produce today's Global AI Radar Daily Brief in Simplified Chinese. Look back 36 hours. Include source URLs, publication dates, confidence labels, impact/urgency scores, and a follow-up watchlist." \
  --announce
```

### Weekly brief every Monday at 08:30

```bash
openclaw cron add \
  --name "AI Radar Weekly Brief" \
  --cron "30 8 * * 1" \
  --tz "America/Los_Angeles" \
  --session isolated \
  --message "Use the ai_global_intelligence_radar skill. Produce this week's Global AI Radar Weekly Brief in Simplified Chinese. Look back 7 days. Focus on structural shifts, top 10 signals, opportunities, risks, and source log." \
  --announce
```

### Monthly review on the first day of each month at 09:00

```bash
openclaw cron add \
  --name "AI Radar Monthly Strategic Review" \
  --cron "0 9 1 * *" \
  --tz "America/Los_Angeles" \
  --session isolated \
  --message "Use the ai_global_intelligence_radar skill. Produce the monthly Global AI Strategic Review in Simplified Chinese for the previous calendar month. Include capability curve, cost curve, regulation curve, capital/startup curve, commercialization curve, China vs global comparison, opportunity map, risk map, and next-month watchlist." \
  --announce
```

### Quarterly report on Jan/Apr/Jul/Oct 1 at 09:30

```bash
openclaw cron add \
  --name "AI Radar Quarterly Strategic Report" \
  --cron "30 9 1 1,4,7,10 *" \
  --tz "America/Los_Angeles" \
  --session isolated \
  --message "Use the ai_global_intelligence_radar skill. Produce a quarterly strategic report on global AI development in Simplified Chinese for the previous calendar quarter. Include board-level summary, technology inflection points, policy/geopolitical risks, infrastructure/cost structure, capital ecosystem, vertical adoption, regional comparison, strategic bets, and appendix source log." \
  --announce
```

## Failure handling

If fresh web/source access is unavailable:

1. State that live verification is unavailable.
2. Do not present time-sensitive claims as current.
3. Produce only a methodology/template or summarize from known saved source logs.
4. Ask the user to rerun after restoring source access only if live current information is required.

If sources conflict:

1. Present the conflict explicitly.
2. Prefer primary sources over secondary interpretations.
3. Include both sides when the disagreement is material.
4. Mark the item as `medium` or `low` confidence until resolved.

If a high-impact item cannot be verified:

1. Do not include it as a top confirmed signal.
2. Put it in `Rumor/Unverified Watch` with a clear caveat.
3. Add it to the follow-up watchlist.
