#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Seedance 1.0 Pro 文生视频生成器
支持纯文本生成视频，使用正确的API格式
"""

import sys
import json
import time
import requests
import argparse
import os
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

class Seedance10ProGenerator:
    """Seedance 1.0 Pro 视频生成器"""
    
    def __init__(self, config_path=None):
        """
        初始化视频生成器
        
        Args:
            config_path: 配置文件路径，如果为None则使用默认路径
        """
        # 确定配置文件路径
        if config_path is None:
            # 使用技能目录中的config.json
            script_dir = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(script_dir, 'config.json')
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 从配置中获取API Key
        self.api_key = self.config.get('api_key')
        
        if not self.api_key:
            raise ValueError("配置文件中缺少api_key，请在config.json中配置API Key")
        
        # API配置
        self.create_task_url = "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # 默认模型
        self.model = "doubao-seedance-1-0-pro-fast-251015"
    
    def load_config(self, config_path):
        """
        加载配置文件
        
        Args:
            config_path: 配置文件路径
            
        Returns:
            dict: 配置字典
        """
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"❌ 配置文件不存在: {config_path}")
            print("请创建config.json文件，格式如下:")
            print('''
{
  "api_key": "你的火山引擎API Key"
}
''')
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"❌ 配置文件格式错误: {e}")
            sys.exit(1)
    
    def create_text_to_video_task(self, prompt, duration=5, resolution="1080p", 
                                 camera_fixed=False, watermark=True):
        """
        创建文生视频任务
        
        Args:
            prompt: 文本提示词
            duration: 视频时长（秒），4-12
            resolution: 分辨率，如"1080p"
            camera_fixed: 相机是否固定
            watermark: 是否添加水印
            
        Returns:
            str: 任务ID，失败返回None
        """
        print("🎬 创建文生视频任务...")
        print(f"  提示词: {prompt}")
        print(f"  时长: {duration}秒")
        print(f"  分辨率: {resolution}")
        print(f"  相机固定: {camera_fixed}")
        print(f"  水印: {watermark}")
        
        # 构建请求体
        payload = {
            "model": self.model,
            "content": [
                {
                    "type": "text",
                    "text": f"{prompt} --resolution {resolution} --duration {duration} --camerafixed {str(camera_fixed).lower()} --watermark {str(watermark).lower()}"
                }
            ]
        }
        
        print("\n📝 请求体:")
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        
        try:
            response = requests.post(
                self.create_task_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            print(f"\n📥 响应状态码: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                print("📝 响应内容:")
                print(json.dumps(result, ensure_ascii=False, indent=2))
                
                # 提取任务ID
                if "id" in result:
                    task_id = result["id"]
                    print(f"\n✅ 视频生成任务已创建")
                    print(f"  任务ID: {task_id}")
                    return task_id
                else:
                    print("❌ 响应中未找到任务ID")
                    return None
            else:
                print(f"❌ 创建任务失败")
                error_text = response.text
                print(f"  错误信息: {error_text}")
                
                # 解析错误信息
                try:
                    error_data = json.loads(error_text)
                    if "error" in error_data:
                        error_msg = error_data["error"].get("message", "")
                        print(f"\n💡 错误详情: {error_msg}")
                except:
                    pass
                    
                return None
                
        except Exception as e:
            print(f"❌ 创建视频任务时出错: {e}")
            return None
    
    def check_task_status(self, task_id):
        """
        查询任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息，失败返回None
        """
        if not task_id:
            print("❌ 任务ID为空")
            return None
        
        poll_url = f"{self.create_task_url}/{task_id}"
        
        print(f"\n🔍 查询任务状态: {task_id}")
        
        try:
            response = requests.get(poll_url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                print("📝 任务状态:")
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return result
            else:
                print(f"❌ 查询任务状态失败 - 状态码: {response.status_code}")
                print(f"响应: {response.text[:200]}")
                return None
                
        except Exception as e:
            print(f"❌ 查询任务状态时出错: {e}")
            return None
    
    def download_video(self, video_url, output_path):
        """
        下载视频文件
        
        Args:
            video_url: 视频URL
            output_path: 输出文件路径
            
        Returns:
            bool: 是否下载成功
        """
        try:
            print(f"\n📥 开始下载视频...")
            print(f"  视频URL: {video_url[:100]}...")
            print(f"  保存到: {output_path}")
            
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(video_url, headers=headers, stream=True, timeout=60)
            
            if response.status_code == 200:
                # 确保输出目录存在
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                
                # 下载文件
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(output_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            # 显示进度
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f'  下载进度: {percent:.1f}% ({downloaded}/{total_size} bytes)', end='\r')
                
                print(f'\n✅ 视频下载完成！')
                print(f'  文件大小: {os.path.getsize(output_path)} bytes')
                return True
            else:
                print(f'❌ 下载失败 - 状态码: {response.status_code}')
                return False
                
        except Exception as e:
            print(f'❌ 下载视频时出错: {str(e)}')
            return False
    
    def poll_and_download(self, task_id, output_path, max_attempts=60, interval=10):
        """
        轮询任务状态并下载视频
        
        Args:
            task_id: 任务ID
            output_path: 输出文件路径
            max_attempts: 最大轮询次数
            interval: 轮询间隔（秒）
            
        Returns:
            bool: 是否成功下载
        """
        print(f"\n⏳ 开始轮询任务状态: {task_id}")
        print(f"  最大轮询次数: {max_attempts}，间隔: {interval}秒")
        
        for attempt in range(1, max_attempts + 1):
            print(f"\n第{attempt}次轮询...")
            
            # 查询任务状态
            result = self.check_task_status(task_id)
            
            if not result:
                print("❌ 获取任务状态失败")
                return False
            
            status = result.get('status', 'unknown')
            print(f"  任务状态: {status}")
            
            if status == 'succeeded':
                print("✅ 视频生成成功！")
                
                # 提取视频URL
                video_url = None
                if 'content' in result and 'video_url' in result['content']:
                    video_url = result['content']['video_url']
                elif 'output' in result and 'video_url' in result['output']:
                    video_url = result['output']['video_url']
                
                if video_url:
                    print(f"🎬 找到视频URL")
                    
                    # 显示视频信息
                    print("\n📊 视频信息:")
                    print(f"  时长: {result.get('duration', 'N/A')}秒")
                    print(f"  分辨率: {result.get('resolution', 'N/A')}")
                    print(f"  宽高比: {result.get('ratio', 'N/A')}")
                    print(f"  帧率: {result.get('framespersecond', 'N/A')} fps")
                    
                    # 下载视频
                    return self.download_video(video_url, output_path)
                else:
                    print("❌ 任务成功但没有找到视频URL")
                    print("完整响应:", json.dumps(result, ensure_ascii=False, indent=2))
                    return False
                    
            elif status == 'failed':
                print("❌ 视频生成失败")
                if 'error' in result:
                    error = result['error']
                    print(f"  错误代码: {error.get('code')}")
                    print(f"  错误信息: {error.get('message')}")
                return False
                
            elif status == 'running':
                print("⏳ 视频生成中...")
            else:
                print(f"📝 未知状态: {status}")
            
            # 如果不是最后一次尝试，等待间隔时间
            if attempt < max_attempts:
                print(f"等待{interval}秒后继续轮询...")
                time.sleep(interval)
        
        print(f"⚠️ 达到最大轮询次数({max_attempts})，任务可能仍在处理中")
        return False

def main():
    parser = argparse.ArgumentParser(description='Seedance 1.0 Pro 文生视频生成器')
    parser.add_argument('prompt', help='文本提示词')
    parser.add_argument('--duration', type=int, default=5, help='视频时长（4-12秒，默认5秒）')
    parser.add_argument('--resolution', default='1080p', help='分辨率（默认1080p）')
    parser.add_argument('--camera-fixed', action='store_true', help='相机固定（默认False）')
    parser.add_argument('--no-watermark', action='store_true', help='不添加水印（默认添加）')
    parser.add_argument('--output', '-o', default=None, help='输出文件路径（默认：桌面/提示词_视频.mp4）')
    parser.add_argument('--poll', action='store_true', help='自动轮询并下载视频')
    parser.add_argument('--max-attempts', type=int, default=60, help='最大轮询次数（默认60）')
    parser.add_argument('--interval', type=int, default=10, help='轮询间隔秒数（默认10）')
    
    args = parser.parse_args()
    
    # 创建生成器实例
    generator = Seedance10ProGenerator()
    
    # 创建视频任务
    task_id = generator.create_text_to_video_task(
        prompt=args.prompt,
        duration=args.duration,
        resolution=args.resolution,
        camera_fixed=args.camera_fixed,
        watermark=not args.no_watermark
    )
    
    if not task_id:
        print("❌ 创建视频任务失败")
        return
    
    # 确定输出路径
    if args.output:
        output_path = args.output
    else:
        # 使用桌面路径
        desktop = Path.home() / "Desktop"
        # 清理提示词用于文件名
        safe_prompt = "".join(c for c in args.prompt[:50] if c.isalnum() or c in (' ', '-', '_')).strip()
        if not safe_prompt:
            safe_prompt = "video"
        output_path = str(desktop / f"{safe_prompt}_{args.duration}s.mp4")
    
    print(f"\n🎯 输出路径: {output_path}")
    
    # 如果指定了自动轮询，则轮询并下载
    if args.poll:
        print("\n" + "="*50)
        print("开始自动轮询并下载视频")
        print("="*50)
        
        success = generator.poll_and_download(
            task_id=task_id,
            output_path=output_path,
            max_attempts=args.max_attempts,
            interval=args.interval
        )
        
        if success:
            print(f"\n🎉 视频生成并下载完成！")
            print(f"文件位置: {output_path}")
        else:
            print(f"\n❌ 视频生成或下载失败")
    else:
        print(f"\n📋 任务已创建，任务ID: {task_id}")
        print("你可以使用以下命令查询任务状态:")
        print(f"python {sys.argv[0]} --check {task_id}")
        print("\n或者手动查询:")
        print(f'curl -X GET "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/{task_id}" \\')
        print('  -H "Content-Type: application/json" \\')
        print(f'  -H "Authorization: Bearer YOUR_API_KEY"')

if __name__ == '__main__':
    main()