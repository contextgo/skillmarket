---
name: seedance-video-generator
description: 使用火山引擎 Seedance 1.0 Pro API 生成视频。支持文生视频功能，自动轮询和下载。
allowed-tools: Bash(python *)
---

# Seedance 1.0 Pro 视频生成技能

## 功能
使用火山引擎的 Seedance 1.0 Pro API 生成高质量视频，支持纯文本生成视频功能。

## 首次使用配置

### 1. 创建配置文件

在技能目录中创建 `config.json` 文件：

```json
{
  "api_key": "你的火山引擎API Key",
  "model": "doubao-seedance-1-0-pro-fast-251015"
}
```

### 2. 配置说明

- **api_key**: 火山引擎API Key（必需）
- **model**: 模型ID（必需），默认使用 `doubao-seedance-1-0-pro-fast-251015`

### 3. 获取API Key

1. 访问火山引擎控制台：https://console.volcengine.com/
2. 注册并登录账号
3. 在API Key管理中创建或获取API Key
4. 确保账户有足够的额度使用Seedance 1.0 Pro模型

## 主要脚本

### 1. seedance_1_0_pro_generator.py - 主生成脚本
一键生成视频，支持自动轮询和下载。

### 2. check_task.py - 任务状态查询脚本
查询任意任务状态，支持自动下载。

## 使用方法

### 基本用法（自动轮询并下载）
```bash
# 生成5秒视频
python seedance_1_0_pro_generator.py "美丽的风景，阳光明媚" --poll

# 生成12秒视频，不添加水印
python seedance_1_0_pro_generator.py "抽象的几何形状流动" --duration 12 --no-watermark --poll

# 生成8秒视频，指定输出路径
python seedance_1_0_pro_generator.py "无人机穿越城市" --duration 8 --output "/path/to/video.mp4" --poll
```

### 仅创建任务（不自动下载）
```bash
python seedance_1_0_pro_generator.py "测试视频"
```

### 查询任务状态
```bash
# 查询任务状态
python check_task.py cgt-20260402093149-2zthw

# 查询并自动下载
python check_task.py cgt-20260402093149-2zthw --download
```

## 参数说明

### seedance_1_0_pro_generator.py

| 参数 | 缩写 | 默认值 | 说明 |
|------|------|--------|------|
| `prompt` | - | 必需 | 文本提示词 |
| `--duration` | - | 5 | 视频时长（4-12秒） |
| `--resolution` | - | 1080p | 分辨率 |
| `--camera-fixed` | - | False | 相机是否固定 |
| `--no-watermark` | - | False | 不添加水印 |
| `--output` | `-o` | 自动生成 | 输出文件路径 |
| `--poll` | - | False | 自动轮询并下载视频 |
| `--max-attempts` | - | 60 | 最大轮询次数 |
| `--interval` | - | 10 | 轮询间隔秒数 |

### check_task.py

| 参数 | 缩写 | 默认值 | 说明 |
|------|------|--------|------|
| `task_id` | - | 必需 | 任务ID |
| `--download` | `-d` | False | 如果任务成功，自动下载视频 |
| `--output` | `-o` | 自动生成 | 输出文件路径 |

## 示例

### 示例1：生成抽象艺术视频
```bash
python seedance_1_0_pro_generator.py \
  "抽象的几何形状流动，彩色粒子在深色背景中舞动，光影渐变，动态纹理" \
  --duration 12 \
  --no-watermark \
  --poll
```

### 示例2：生成风景视频
```bash
python seedance_1_0_pro_generator.py \
  "冬日的杭州西湖，雪花纷纷扬扬飘落，湖面结冰，远处雷峰塔" \
  --duration 8 \
  --poll
```

### 示例3：生成科技感视频
```bash
python seedance_1_0_pro_generator.py \
  "未来城市，飞行汽车穿梭，霓虹灯光，赛博朋克风格" \
  --duration 10 \
  --camera-fixed \
  --poll
```

## 工作流程

1. **创建任务**: 调用API创建视频生成任务
2. **异步处理**: 轮询任务状态，等待生成完成（通常2-5分钟）
3. **下载视频**: 自动下载生成的视频到指定位置

## 注意事项

- 首次使用前必须配置 `config.json` 文件
- 视频生成是异步的，通常需要2-5分钟
- 建议使用桌面路径保存视频
- 支持MP4格式输出，1080p分辨率
- 默认视频时长为5秒，支持4-12秒
- 默认添加火山引擎水印，可使用`--no-watermark`关闭

## 错误处理

如果遇到以下错误：

1. **配置文件不存在**: 创建 `config.json` 文件并配置API Key
2. **API Key无效**: 检查API Key是否正确
3. **账户限制**: 火山引擎账户可能达到推理限制，需要调整"安全体验模式"
4. **网络错误**: 检查网络连接和防火墙设置

## API文档

- 火山引擎控制台: https://console.volcengine.com/
- API文档: https://www.volcengine.com/docs/
- Seedance模型介绍: https://www.volcengine.com/docs/82377/1234567

## 更新日志

### v1.0.0 (2026-04-02)
- 初始版本发布
- 支持Seedance 1.0 Pro文生视频功能
- 支持自动轮询和下载
- 完善的错误处理机制
- 详细的参数配置支持