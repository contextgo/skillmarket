# Seedance 1.0 Pro 视频生成技能

基于火山引擎 Seedance 1.0 Pro API 的视频生成工具，支持文生视频功能。

## 功能特点

- ✅ **文生视频**：根据文本提示词生成视频
- ✅ **自动轮询**：自动查询任务状态并下载视频
- ✅ **多参数支持**：时长、分辨率、相机固定、水印等
- ✅ **错误处理**：完善的错误提示和重试机制
- ✅ **进度显示**：下载进度实时显示

## 快速开始

### 1. 配置API密钥

在 `config.json` 文件中配置你的火山引擎API密钥：

```json
{
  "api_key": "你的火山引擎API Key"
}
```

### 2. 基本使用

#### 生成视频（自动轮询并下载）

```bash
# 生成5秒视频
python seedance_1_0_pro_generator.py "美丽的风景，阳光明媚" --poll

# 生成12秒视频，不添加水印
python seedance_1_0_pro_generator.py "抽象的几何形状流动" --duration 12 --no-watermark --poll

# 生成8秒视频，指定输出路径
python seedance_1_0_pro_generator.py "无人机穿越城市" --duration 8 --output "/path/to/video.mp4" --poll
```

#### 仅创建任务（不自动下载）

```bash
python seedance_1_0_pro_generator.py "测试视频"
```

### 3. 查询任务状态

```bash
# 查询任务状态
python check_task.py cgt-20260402093149-2zthw

# 查询并自动下载
python check_task.py cgt-20260402093149-2zthw --download
```

## 参数说明

### seedance_1_0_pro_generator.py

| 参数 | 缩写 | 默认值 | 说明 |
|------|------|--------|------|
| `prompt` | - | 必需 | 文本提示词 |
| `--duration` | - | 5 | 视频时长（4-12秒） |
| `--resolution` | - | 1080p | 分辨率 |
| `--camera-fixed` | - | False | 相机是否固定 |
| `--no-watermark` | - | False | 不添加水印 |
| `--output` | `-o` | 自动生成 | 输出文件路径 |
| `--poll` | - | False | 自动轮询并下载视频 |
| `--max-attempts` | - | 60 | 最大轮询次数 |
| `--interval` | - | 10 | 轮询间隔秒数 |

### check_task.py

| 参数 | 缩写 | 默认值 | 说明 |
|------|------|--------|------|
| `task_id` | - | 必需 | 任务ID |
| `--download` | `-d` | False | 如果任务成功，自动下载视频 |
| `--output` | `-o` | 自动生成 | 输出文件路径 |

## 示例

### 示例1：生成抽象艺术视频

```bash
python seedance_1_0_pro_generator.py \
  "抽象的几何形状流动，彩色粒子在深色背景中舞动，光影渐变，动态纹理" \
  --duration 12 \
  --no-watermark \
  --poll
```

### 示例2：生成风景视频

```bash
python seedance_1_0_pro_generator.py \
  "冬日的杭州西湖，雪花纷纷扬扬飘落，湖面结冰，远处雷峰塔" \
  --duration 8 \
  --poll
```

### 示例3：生成科技感视频

```bash
python seedance_1_0_pro_generator.py \
  "未来城市，飞行汽车穿梭，霓虹灯光，赛博朋克风格" \
  --duration 10 \
  --camera-fixed \
  --poll
```

## API调用示例

### 创建任务（curl）

```bash
curl -X POST https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY" \
  -d '{
    "model": "doubao-seedance-1-0-pro-fast-251015",
    "content": [
      {
        "type": "text",
        "text": "美丽的风景 --resolution 1080p --duration 5 --camerafixed false --watermark true"
      }
    ]
  }'
```

### 查询任务状态（curl）

```bash
curl -X GET https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/{task_id} \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY"
```

## 错误处理

### 常见错误

1. **API密钥错误**：检查config.json中的api_key是否正确
2. **账户限制**：火山引擎账户可能达到推理限制，需要调整"安全体验模式"
3. **网络错误**：检查网络连接和防火墙设置
4. **参数错误**：确保时长在4-12秒范围内

### 错误信息示例

```json
{
  "error": {
    "code": "SetLimitExceeded",
    "message": "Your account has reached the set inference limit..."
  }
}
```

## 文件结构

```
video-generator-seedance/
├── config.json              # API配置
├── seedance_1_0_pro_generator.py  # 主生成脚本
├── check_task.py           # 任务状态查询脚本
├── fixed_generate_video.py # 修复版图生视频脚本
├── generate_video.py       # 原图生视频脚本
├── poll_and_download.py    # 轮询下载脚本
└── README_SEEDANCE.md      # 本文档
```

## 注意事项

1. **视频时长**：Seedance 1.0 Pro支持4-12秒视频生成
2. **生成时间**：视频生成通常需要2-5分钟
3. **水印**：默认添加火山引擎水印，可使用`--no-watermark`关闭
4. **输出格式**：生成的视频为MP4格式，1080p分辨率
5. **账户限制**：免费账户可能有使用限制，请关注火山引擎控制台

## 更新日志

### v1.0.0 (2026-04-02)
- 初始版本发布
- 支持文生视频功能
- 支持自动轮询和下载
- 完善的错误处理

## 技术支持

如有问题，请参考：
- 火山引擎官方文档：https://www.volcengine.com/docs/
- 火山引擎控制台：https://console.volcengine.com/
- 技能GitHub仓库：https://github.com/openclaw/skills