# 安装说明

## 快速安装

1. 将本技能包解压到OpenClaw的skills目录
2. 配置API密钥
3. 开始使用

## 详细步骤

### 1. 解压技能包
```bash
# 假设技能包在桌面
cd ~/.openclaw/workspace/skills
unzip ~/Desktop/seedance-video-generator.zip
```

### 2. 配置API密钥
```bash
cd seedance-video-generator
# 编辑配置文件
nano config.json
```

将`YOUR_VOLCENGINE_API_KEY_HERE`替换为你的火山引擎API密钥：
```json
{
  "api_key": "你的实际API密钥",
  "model": "doubao-seedance-1-0-pro-fast-251015"
}
```

### 3. 获取API密钥
1. 访问火山引擎控制台：https://console.volcengine.com/
2. 注册并登录账号
3. 在"API密钥管理"中创建新的API密钥
4. 复制API密钥到config.json文件中

### 4. 测试安装
```bash
# 测试脚本是否正常工作
python3 seedance_1_0_pro_generator.py --help
python3 check_task.py --help
```

## 系统要求

- Python 3.7+
- requests库（通常已预装）
- 火山引擎账户和API密钥
- OpenClaw 1.0.0或更高版本

## 故障排除

### 1. Python找不到
```bash
# 检查Python版本
python3 --version

# 如果未安装Python，请先安装
# macOS: brew install python
# Ubuntu: sudo apt install python3 python3-pip
```

### 2. requests库缺失
```bash
pip3 install requests
```

### 3. API密钥错误
- 检查config.json文件格式
- 确认API密钥是否正确
- 确保火山引擎账户有足够的额度

### 4. 权限问题
```bash
# 给脚本添加执行权限
chmod +x seedance_1_0_pro_generator.py
chmod +x check_task.py
```

## 更新技能

当有新版本发布时：
1. 备份你的config.json文件
2. 删除旧版本技能目录
3. 解压新版本技能包
4. 恢复config.json文件

## 支持

如有问题，请参考：
- SKILL.md - 详细使用说明
- README_SEEDANCE.md - 完整文档
- 火山引擎官方文档：https://www.volcengine.com/docs/