#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
查询Seedance视频生成任务状态
"""

import sys
import json
import requests
import argparse
import os

def load_config(config_path=None):
    """加载配置文件"""
    if config_path is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(script_dir, 'config.json')
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ 配置文件不存在: {config_path}")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ 配置文件格式错误: {e}")
        return None

def check_task_status(task_id, api_key):
    """
    查询任务状态
    
    Args:
        task_id: 任务ID
        api_key: API密钥
        
    Returns:
        dict: 任务状态信息，失败返回None
    """
    url = f"https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/{task_id}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    print(f"🔍 查询任务状态: {task_id}")
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            return result
        else:
            print(f"❌ 查询任务状态失败 - 状态码: {response.status_code}")
            print(f"响应: {response.text[:200]}")
            return None
            
    except Exception as e:
        print(f"❌ 查询任务状态时出错: {e}")
        return None

def download_video(video_url, output_path, api_key):
    """
    下载视频文件
    
    Args:
        video_url: 视频URL
        output_path: 输出文件路径
        api_key: API密钥
        
    Returns:
        bool: 是否下载成功
    """
    try:
        print(f"\n📥 开始下载视频...")
        print(f"  视频URL: {video_url[:100]}...")
        print(f"  保存到: {output_path}")
        
        headers = {
            'Authorization': f'Bearer {api_key}'
        }
        
        response = requests.get(video_url, headers=headers, stream=True, timeout=60)
        
        if response.status_code == 200:
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # 下载文件
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        # 显示进度
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            print(f'  下载进度: {percent:.1f}% ({downloaded}/{total_size} bytes)', end='\r')
            
            print(f'\n✅ 视频下载完成！')
            print(f'  文件大小: {os.path.getsize(output_path)} bytes')
            return True
        else:
            print(f'❌ 下载失败 - 状态码: {response.status_code}')
            return False
            
    except Exception as e:
        print(f'❌ 下载视频时出错: {str(e)}')
        return False

def main():
    parser = argparse.ArgumentParser(description='查询Seedance视频生成任务状态')
    parser.add_argument('task_id', help='任务ID')
    parser.add_argument('--download', '-d', action='store_true', help='如果任务成功，自动下载视频')
    parser.add_argument('--output', '-o', default=None, help='输出文件路径（默认：桌面/任务ID.mp4）')
    
    args = parser.parse_args()
    
    # 加载配置
    config = load_config()
    if not config:
        return
    
    api_key = config.get('api_key')
    if not api_key:
        print("❌ 配置文件中缺少api_key")
        return
    
    # 查询任务状态
    result = check_task_status(args.task_id, api_key)
    
    if not result:
        return
    
    # 打印任务状态
    print("\n📊 任务状态详情:")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
    status = result.get('status', 'unknown')
    print(f"\n📈 任务状态: {status}")
    
    if status == 'succeeded':
        print("✅ 视频生成成功！")
        
        # 显示视频信息
        print("\n🎬 视频信息:")
        print(f"  模型: {result.get('model', 'N/A')}")
        print(f"  时长: {result.get('duration', 'N/A')}秒")
        print(f"  分辨率: {result.get('resolution', 'N/A')}")
        print(f"  宽高比: {result.get('ratio', 'N/A')}")
        print(f"  帧率: {result.get('framespersecond', 'N/A')} fps")
        
        # 提取视频URL
        video_url = None
        if 'content' in result and 'video_url' in result['content']:
            video_url = result['content']['video_url']
        elif 'output' in result and 'video_url' in result['output']:
            video_url = result['output']['video_url']
        
        if video_url:
            print(f"\n🔗 视频URL: {video_url[:100]}...")
            
            # 如果指定了下载，则下载视频
            if args.download:
                # 确定输出路径
                if args.output:
                    output_path = args.output
                else:
                    # 使用桌面路径
                    import os
                    from pathlib import Path
                    desktop = Path.home() / "Desktop"
                    output_path = str(desktop / f"{args.task_id}.mp4")
                
                print(f"\n📥 开始下载视频到: {output_path}")
                success = download_video(video_url, output_path, api_key)
                
                if success:
                    print(f"\n🎉 视频下载完成！")
                    print(f"文件位置: {output_path}")
                else:
                    print(f"\n❌ 视频下载失败")
            else:
                print("\n💡 提示: 使用 --download 参数自动下载视频")
        else:
            print("❌ 任务成功但没有找到视频URL")
            
    elif status == 'failed':
        print("❌ 视频生成失败")
        if 'error' in result:
            error = result['error']
            print(f"  错误代码: {error.get('code')}")
            print(f"  错误信息: {error.get('message')}")
            
    elif status == 'running':
        print("⏳ 视频正在生成中...")
        print("建议等待几分钟后再查询")
        
    else:
        print(f"📝 未知状态: {status}")

if __name__ == '__main__':
    main()