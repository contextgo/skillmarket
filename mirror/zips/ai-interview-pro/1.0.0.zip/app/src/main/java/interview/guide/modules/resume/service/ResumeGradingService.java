package interview.guide.modules.resume.service;

import interview.guide.common.ai.StructuredOutputInvoker;
import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.modules.interview.model.ResumeAnalysisResponse;
import interview.guide.modules.interview.model.ResumeAnalysisResponse.ScoreDetail;
import interview.guide.modules.interview.model.ResumeAnalysisResponse.Suggestion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简历评分服务
 * 使用Spring AI调用LLM对简历进行评分和建议
 */
@Service
public class ResumeGradingService {
    
    private static final Logger log = LoggerFactory.getLogger(ResumeGradingService.class);
    
    private final ChatClient chatClient;
    private final PromptTemplate systemPromptTemplate;
    private final PromptTemplate userPromptTemplate;
    private final BeanOutputConverter<ResumeAnalysisResponseDTO> outputConverter;
    private final StructuredOutputInvoker structuredOutputInvoker;
    
    // 中间DTO用于接收AI响应
    private record ResumeAnalysisResponseDTO(
        int overallScore,
        ScoreDetailDTO scoreDetail,
        String summary,
        List<String> strengths,
        List<SuggestionDTO> suggestions
    ) {}
    
    private record ScoreDetailDTO(
        int contentScore,
        int structureScore,
        int skillMatchScore,
        int expressionScore,
        int projectScore
    ) {}
    
    private record SuggestionDTO(
        String category,
        String priority,
        String issue,
        String recommendation
    ) {}
    
    public ResumeGradingService(
            ChatClient.Builder chatClientBuilder,
            StructuredOutputInvoker structuredOutputInvoker,
            @Value("classpath:prompts/resume-analysis-system.st") Resource systemPromptResource,
            @Value("classpath:prompts/resume-analysis-user.st") Resource userPromptResource) throws IOException {
        this.chatClient = chatClientBuilder.build();
        this.structuredOutputInvoker = structuredOutputInvoker;
        this.systemPromptTemplate = new PromptTemplate(systemPromptResource.getContentAsString(StandardCharsets.UTF_8));
        this.userPromptTemplate = new PromptTemplate(userPromptResource.getContentAsString(StandardCharsets.UTF_8));
        this.outputConverter = new BeanOutputConverter<>(ResumeAnalysisResponseDTO.class);
    }
    
    /**
     * 分析简历并返回评分和建议
     * 
     * @param resumeText 简历文本内容
     * @return 分析结果
     */
    public ResumeAnalysisResponse analyzeResume(String resumeText) {
        log.info("开始分析简历，文本长度: {} 字符", resumeText.length());
        
        try {
            // 加载系统提示词
            String systemPrompt = systemPromptTemplate.render();
            
            // 加载用户提示词并填充变量
            Map<String, Object> variables = new HashMap<>();
            variables.put("resumeText", resumeText);
            String userPrompt = userPromptTemplate.render(variables);
            
            // 添加格式指令到系统提示词
            String systemPromptWithFormat = systemPrompt + "\n\n" + outputConverter.getFormat();
            
            // 调用AI
            ResumeAnalysisResponseDTO dto;
            try {
                dto = structuredOutputInvoker.invoke(
                    chatClient,
                    systemPromptWithFormat,
                    userPrompt,
                    outputConverter,
                    ErrorCode.RESUME_ANALYSIS_FAILED,
                    "简历分析失败：",
                    "简历分析",
                    log
                );
                                
                // 验证和清理数据
                dto = validateAndCleanDTO(dto);
                                
                log.debug("AI 响应解析成功：overallScore={}", dto.overallScore());
            } catch (Exception e) {
                log.error("简历分析AI调用失败: {}", e.getMessage(), e);
                throw new BusinessException(ErrorCode.RESUME_ANALYSIS_FAILED, "简历分析失败：" + e.getMessage());
            }
            
            // 转换为业务对象
            ResumeAnalysisResponse result = convertToResponse(dto, resumeText);
            log.info("简历分析完成，总分: {}", result.overallScore());
            
            return result;
            
        } catch (Exception e) {
            log.error("简历分析失败: {}", e.getMessage(), e);
            return createErrorResponse(resumeText, e.getMessage());
        }
    }
    
    /**
     * 验证和清理 AI 返回的 DTO，确保数据格式正确
     */
    private ResumeAnalysisResponseDTO validateAndCleanDTO(ResumeAnalysisResponseDTO dto) {
        if (dto == null) {
            throw new BusinessException(ErrorCode.RESUME_ANALYSIS_FAILED, "AI 返回空响应");
        }
        
        // 清理 strengths 数组，移除包含非法字符的元素
        if (dto.strengths() != null) {
            List<String> cleanedStrengths = dto.strengths().stream()
                .filter(s -> s != null && !s.trim().isEmpty())
                .map(s -> {
                    // 移除可能导致 JSON 解析失败的字符
                    return s.replaceAll("[\r\n\t]", " ")
                            .replaceAll("\\{+", "")
                            .replaceAll("}+", "")
                            .trim();
                })
                .toList();
            
            // 确保 strengths 不超过合理数量（5-8 个）
            if (cleanedStrengths.size() > 10) {
                cleanedStrengths = cleanedStrengths.subList(0, 10);
            }
            
            return new ResumeAnalysisResponseDTO(
                dto.overallScore(),
                dto.scoreDetail(),
                dto.summary() != null ? dto.summary().replaceAll("[\r\n\t]", " ") : "",
                cleanedStrengths,
                dto.suggestions()
            );
        }
        
        return dto;
    }
    
    /**
     * 转换 DTO 为业务对象
     */
    private ResumeAnalysisResponse convertToResponse(ResumeAnalysisResponseDTO dto, String originalText) {
        ScoreDetail scoreDetail = new ScoreDetail(
            dto.scoreDetail().contentScore(),
            dto.scoreDetail().structureScore(),
            dto.scoreDetail().skillMatchScore(),
            dto.scoreDetail().expressionScore(),
            dto.scoreDetail().projectScore()
        );
            
        // 清理和验证 suggestions
        List<Suggestion> suggestions = dto.suggestions() != null ? dto.suggestions().stream()
            .filter(s -> s != null && s.category() != null && !s.category().trim().isEmpty())
            .map(s -> new Suggestion(
                s.category().replaceAll("[\r\n\t]", " ").trim(),
                s.priority() != null ? s.priority() : "中",
                s.issue() != null ? s.issue().replaceAll("[\r\n\t]", " ").trim() : "",
                s.recommendation() != null ? s.recommendation().replaceAll("[\r\n\t]", " ").trim() : ""
            ))
            .toList() : List.of();
            
        // 限制 suggestions 数量
        if (suggestions.size() > 15) {
            suggestions = suggestions.subList(0, 15);
        }
            
        return new ResumeAnalysisResponse(
            dto.overallScore(),
            scoreDetail,
            dto.summary() != null ? dto.summary() : "",
            dto.strengths() != null ? dto.strengths() : List.of(),
            suggestions,
            originalText
        );
    }
    
    /**
     * 创建错误响应
     */
    private ResumeAnalysisResponse createErrorResponse(String originalText, String errorMessage) {
        return new ResumeAnalysisResponse(
            0,
            new ScoreDetail(0, 0, 0, 0, 0),
            "分析过程中出现错误: " + errorMessage,
            List.of(),
            List.of(new Suggestion(
                "系统",
                "高",
                "AI分析服务暂时不可用",
                "请稍后重试，或检查AI服务是否正常运行"
            )),
            originalText
        );
    }
}
