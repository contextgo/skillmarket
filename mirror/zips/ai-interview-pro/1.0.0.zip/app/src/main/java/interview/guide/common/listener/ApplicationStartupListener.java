package interview.guide.common.listener;

import interview.guide.common.constant.AsyncTaskStreamConstants;
import interview.guide.common.model.AsyncTaskStatus;
import interview.guide.modules.interview.model.InterviewSessionEntity;
import interview.guide.modules.interview.repository.InterviewSessionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 应用启动时的数据清理监听器
 * 清理所有处于"评估中"状态的面试会话，重置为初始状态
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApplicationStartupListener {

    private final InterviewSessionRepository sessionRepository;

    /**
     * 应用完全启动后执行清理
     */
    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        log.info("\n\n═══════════════════════════════════════════════════════════");
        log.info("开始检查并清理启动时的残留评估任务...");
        log.info("═══════════════════════════════════════════════════════════\n");

        try {
            // 1. 清理数据库中卡住的评估任务
            cleanupDatabase();

            // 2. 清理 Redis Stream 中的 pending 消息
            cleanupRedisStreams();

            log.info("\n═══════════════════════════════════════════════════════════");
            log.info("✅ 启动清理完成！");
            log.info("═══════════════════════════════════════════════════════════\n");
        } catch (Exception e) {
            log.error("❌ 启动清理失败：{}", e.getMessage(), e);
        }
    }

    /**
     * 清理数据库中卡住的评估任务
     */
    private void cleanupDatabase() {
        log.info("【1/2】检查数据库中的评估任务...");

        List<InterviewSessionEntity> stuckSessions = sessionRepository.findAll().stream()
            .filter(session -> session.getEvaluateStatus() != null && 
                              session.getEvaluateStatus() != AsyncTaskStatus.COMPLETED &&
                              session.getEvaluateStatus() != AsyncTaskStatus.FAILED)
            .toList();

        if (stuckSessions.isEmpty()) {
            log.info("✓ 未发现卡住的评估任务");
        } else {
            log.warn("⚠ 发现 {} 个卡住的评估任务:", stuckSessions.size());
            
            for (InterviewSessionEntity session : stuckSessions) {
                log.warn("  - Session ID: {}, 当前状态：{}", 
                    session.getSessionId(), 
                    session.getEvaluateStatus());
                
                // 重置评估状态为 null (未评估)
                session.setEvaluateStatus(null);
                session.setEvaluateError(null);
                sessionRepository.save(session);
                
                log.info("  ✓ 已重置为未评估状态");
            }
            
            log.info("✓ 数据库清理完成，重置了 {} 个会话", stuckSessions.size());
        }
    }

    /**
     * 清理 Redis Stream 中的所有 pending 消息
     * 注意：Redisson 4.0 API 限制，无法直接删除 pending 消息
     * 建议：通过重启 Consumer 来自动处理 pending 消息
     */
    private void cleanupRedisStreams() {
        log.info("\n【2/2】检查 Redis Stream 队列...");
        log.info("ℹ️  Redisson 4.0 不支持直接删除 pending 消息");
        log.info("✓ 建议：Consumer 重启后会自动处理积压的消息");
        log.info("\n💡 提示：如需彻底清理，可手动执行以下 Redis 命令:");
        log.info("   XGROUP DESTROYCONSUMER <stream-key> <group-name> <consumer-name>");
        log.info("   或重启所有 Consumer 服务\n");
    }
}
