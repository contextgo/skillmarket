package interview.guide.common.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.net.URI;

/**
 * S3 客户端配置（用于 RustFS/MinIO）
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class S3Config {

    private final StorageConfigProperties storageConfig;

    @Bean
    public S3Client s3Client() {
        AwsBasicCredentials credentials = AwsBasicCredentials.create(
            storageConfig.getAccessKey(),
            storageConfig.getSecretKey()
        );

        S3Client client = S3Client.builder()
            .endpointOverride(URI.create(storageConfig.getEndpoint()))
            .region(Region.of(storageConfig.getRegion()))
            .credentialsProvider(StaticCredentialsProvider.create(credentials))
                .forcePathStyle(true) // 关键配置：使用路径风格访问，否则 SDK 会使用虚拟主机风格（`bucket.endpoint`）导致 DNS 解析失败
            .build();
        
        // 确保 bucket 存在
        ensureBucketExists(client, storageConfig.getBucket());
        
        return client;
    }
    
    /**
     * 确保存储桶存在
     */
    private void ensureBucketExists(S3Client client, String bucketName) {
        try {
            client.headBucket(request -> request.bucket(bucketName));
            log.info("存储桶已存在：{}", bucketName);
        } catch (software.amazon.awssdk.services.s3.model.NoSuchBucketException e) {
            log.info("存储桶不存在，正在创建：{}", bucketName);
            client.createBucket(request -> request.bucket(bucketName));
            log.info("存储桶创建成功：{}", bucketName);
        } catch (Exception e) {
            log.error("检查或创建存储桶失败：{} - {}", bucketName, e.getMessage(), e);
        }
    }
}
