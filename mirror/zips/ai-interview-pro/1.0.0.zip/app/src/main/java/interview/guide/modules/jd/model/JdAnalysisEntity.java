package interview.guide.modules.jd.model;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * 岗位 JD 分析实体类
 */
@Data
@Entity
@Table(name = "jd_analyses", indexes = {
    @Index(name = "idx_company", columnList = "company_name"),
    @Index(name = "idx_position", columnList = "position")
})
public class JdAnalysisEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 公司名称
     */
    @Column(length = 100)
    private String companyName;

    /**
     * 岗位名称
     */
    @Column(nullable = false, length = 100)
    private String position;

    /**
     * 原始 JD 文本
     */
    @Column(nullable = false, columnDefinition = "TEXT")
    private String jdText;

    /**
     * 分析报告（JSON 格式）
     */
    @Column(columnDefinition = "TEXT")
    private String analysisReport;

    /**
     * 关键技能列表（JSON 数组）
     */
    @Column(columnDefinition = "TEXT")
    private String keySkills;

    /**
     * 薪资范围
     */
    @Column(length = 50)
    private String salaryRange;

    /**
     * 工作经验要求
     */
    @Column(length = 500)
    private String experienceRequirement;

    /**
     * 学历要求
     */
    @Column(length = 500)
    private String educationRequirement;

    /**
     * 匹配度分数（如果有简历）
     */
    @Column(precision = 5)
    private Double matchScore;

    /**
     * 用户 ID（关联到具体用户，可选）
     */
    @Column
    private Long userId;

    /**
     * 创建时间
     */
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;
}
