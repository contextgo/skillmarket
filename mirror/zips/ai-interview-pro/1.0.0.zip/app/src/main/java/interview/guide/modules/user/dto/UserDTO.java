package interview.guide.modules.user.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 用户信息 DTO
 */
@Data
public class UserDTO {

    private Long id;
    
    private String username;
    
    private String email;
    
    private String phone;
    
    private String avatarUrl;
    
    private String status; // ACTIVE, DISABLED, LOCKED
    
    private LocalDateTime lastLoginAt;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    private List<String> roles;
}
