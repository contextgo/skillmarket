package interview.guide.modules.interview.listener;

import interview.guide.common.async.AbstractStreamConsumer;
import interview.guide.common.constant.AsyncTaskStreamConstants;
import interview.guide.common.model.AsyncTaskStatus;
import interview.guide.infrastructure.redis.RedisService;
import interview.guide.modules.interview.model.InterviewAnswerEntity;
import interview.guide.modules.interview.model.InterviewQuestionDTO;
import interview.guide.modules.interview.model.InterviewReportDTO;
import interview.guide.modules.interview.model.InterviewSessionEntity;
import interview.guide.modules.interview.model.dto.MultiDimensionEvaluationReport;
import interview.guide.modules.interview.repository.InterviewAnswerRepository;
import interview.guide.modules.interview.repository.InterviewSessionRepository;
import interview.guide.modules.interview.service.AnswerEvaluationService;
import interview.guide.modules.interview.service.InterviewPersistenceService;
import interview.guide.modules.interview.service.MultiDimensionEvaluationService;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.stream.StreamMessageId;
import org.springframework.stereotype.Component;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 面试多维度重新评估 Stream 消费者
 * 负责从 Redis Stream 消费消息并执行多维度评估（技术专家、HR 经理、架构师）
 */
@Slf4j
@Component
public class MultiDimensionReevaluateConsumer extends AbstractStreamConsumer<MultiDimensionReevaluateConsumer.ReevaluatePayload> {

    private final InterviewSessionRepository sessionRepository;
    private final AnswerEvaluationService evaluationService;
    private final MultiDimensionEvaluationService multiDimensionEvaluationService;
    private final InterviewPersistenceService persistenceService;
    private final ObjectMapper objectMapper;
    private final InterviewAnswerRepository answerRepository;

    public MultiDimensionReevaluateConsumer(
        RedisService redisService,
        InterviewSessionRepository sessionRepository,
        AnswerEvaluationService evaluationService,
        MultiDimensionEvaluationService multiDimensionEvaluationService,
        InterviewPersistenceService persistenceService,
        ObjectMapper objectMapper,
        InterviewAnswerRepository answerRepository
    ) {
        super(redisService);
        this.sessionRepository = sessionRepository;
        this.evaluationService = evaluationService;
        this.multiDimensionEvaluationService = multiDimensionEvaluationService;
        this.persistenceService = persistenceService;
        this.objectMapper = objectMapper;
        this.answerRepository = answerRepository;
    }

    record ReevaluatePayload(String sessionId, String resumeSummary, List<InterviewQuestionDTO> questions, boolean enableMultiDimension) {}

    @Override
    protected String taskDisplayName() {
        return "多维度重新评估";
    }

    @Override
    protected String streamKey() {
        return AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_STREAM_KEY;
    }

    @Override
    protected String groupName() {
        return AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_GROUP_NAME;
    }

    @Override
    protected String consumerPrefix() {
        return AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_CONSUMER_PREFIX;
    }

    @Override
    protected String threadName() {
        return "reevaluate-consumer";
    }

    @Override
    protected ReevaluatePayload parsePayload(StreamMessageId messageId, Map<String, String> data) {
        String sessionId = data.get(AsyncTaskStreamConstants.FIELD_SESSION_ID);
        String resumeSummary = data.get("resumeSummary");
        String questionsJson = data.get("questionsJson");
        
        if (sessionId == null || resumeSummary == null || questionsJson == null) {
            log.warn("消息格式错误，跳过：messageId={}", messageId);
            return null;
        }
        
        // 解析是否开启多维度评估
        boolean enableMultiDimension = Boolean.parseBoolean(data.getOrDefault("enableMultiDimension", "false"));
        
        try {
            // 清理 JSON 中的特殊字符（零宽空格、控制字符等）
            questionsJson = questionsJson.replaceAll("\\p{Cntrl}", "")
                                          .replaceAll("\\u200B", "")  // 零宽空格
                                          .replaceAll("\\u200C", "")  // 零宽非连接符
                                          .replaceAll("\\u200D", "")  // 零宽连接符
                                          .replaceAll("\\uFEFF", ""); // BOM 标记
            
            // 先打印 JSON 内容，方便调试
            log.debug("解析 questionsJson: {}", questionsJson);
            
            List<InterviewQuestionDTO> questions = objectMapper.readValue(
                questionsJson,
                new TypeReference<List<InterviewQuestionDTO>>() {}
            );
            return new ReevaluatePayload(sessionId, resumeSummary, questions, enableMultiDimension);
        } catch (Exception e) {
            log.error("解析问题列表失败：messageId={}, error={}, questionsJson={}", messageId, e.getMessage(), questionsJson, e);
            return null;
        }
    }

    @Override
    protected String payloadIdentifier(ReevaluatePayload payload) {
        return "sessionId=" + payload.sessionId();
    }

    @Override
    protected void markProcessing(ReevaluatePayload payload) {
        updateEvaluateStatus(payload.sessionId(), AsyncTaskStatus.PROCESSING, null);
    }

    @Override
    protected void processBusiness(ReevaluatePayload payload) {
        String sessionId = payload.sessionId();
        
        // 验证会话是否存在
        Optional<InterviewSessionEntity> sessionOpt = sessionRepository.findBySessionIdWithResume(sessionId);
        if (sessionOpt.isEmpty()) {
            log.warn("会话已被删除，跳过评估任务：sessionId={}", sessionId);
            return;
        }

        InterviewSessionEntity session = sessionOpt.get();
        
        log.info("开始重新评估：sessionId={}, 题目数={}, enableMultiDimension={}", sessionId, payload.questions().size(), payload.enableMultiDimension());
        
        try {
            // 1. 先执行普通评估（获取每题评分、参考答案）
            log.info("步骤 1: 开始普通评估：sessionId={}", sessionId);
            InterviewReportDTO report = evaluationService.evaluateInterview(
                sessionId, 
                session.getResume().getResumeText(), 
                payload.questions()
            );
            
            log.info("步骤 1 完成：report.questionDetails 大小={}", 
                report != null && report.questionDetails() != null ? report.questionDetails().size() : "null");
            
            // 2. 根据选项选择保存方式
            if (payload.enableMultiDimension()) {
                log.info("步骤 2: 开始多维度评估：sessionId={}", sessionId);
                
                // 保存基础评估结果（包含三个维度简评）
                saveQuestionEvaluations(sessionId, report);
                
                // 执行多维度评估（技术专家、HR 经理、架构师）
                MultiDimensionEvaluationReport multiDimensionReport = multiDimensionEvaluationService.evaluateMultiDimension(
                    sessionId, 
                    payload.resumeSummary(), 
                    payload.questions()
                );
                
                // 保存多维度评估报告到数据库
                saveEvaluationReport(sessionId, multiDimensionReport);
                
                // 多维度评估服务已经保存了每题的三维评分到答案表，直接从答案表读取分数更新到 questionsJson
                log.info("准备从答案表读取分数更新 questionsJson: sessionId={}", sessionId);
                updateQuestionScoresFromAnswers(sessionId);
                
                log.info("多维度重新评估完成：sessionId={}, 技术得分={}, HR 得分={}, 架构师得分={}, 综合得分={}", 
                    sessionId, 
                    multiDimensionReport.getTechnicalScore(), 
                    multiDimensionReport.getHrScore(), 
                    multiDimensionReport.getArchitectScore(),
                    multiDimensionReport.getOverallScore());
            } else {
                log.info("未勾选多维度评估，仅执行基础评估：sessionId={}", sessionId);
                // 只保存基础评估结果（不包含三个维度）
                saveBasicEvaluation(sessionId, report);
                
                // 不勾选多维度时，总分生成后立即标记为已完成
                updateEvaluateStatus(sessionId, AsyncTaskStatus.COMPLETED, null);
                log.info("重新评估任务完成：sessionId={}", sessionId);
            }
                
        } catch (Exception e) {
            log.error("重新评估失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
            throw new RuntimeException("重新评估失败：" + e.getMessage(), e);
        }
    }

    @Override
    protected void markCompleted(ReevaluatePayload payload) {
        updateEvaluateStatus(payload.sessionId(), AsyncTaskStatus.COMPLETED, null);
        log.info("重新评估任务完成：sessionId={}", payload.sessionId());
    }

    @Override
    protected void markFailed(ReevaluatePayload payload, String error) {
        updateEvaluateStatus(payload.sessionId(), AsyncTaskStatus.FAILED, error);
        log.error("重新评估任务失败：sessionId={}, error={}", payload.sessionId(), error);
    }

    @Override
    protected void retryMessage(ReevaluatePayload payload, int retryCount) {
        String sessionId = payload.sessionId();
        try {
            Map<String, String> message = Map.of(
                AsyncTaskStreamConstants.FIELD_SESSION_ID, sessionId,
                "resumeSummary", payload.resumeSummary(),
                "questionsJson", objectMapper.writeValueAsString(payload.questions()),
                "enableMultiDimension", String.valueOf(payload.enableMultiDimension()),
                AsyncTaskStreamConstants.FIELD_RETRY_COUNT, String.valueOf(retryCount)
            );

            redisService().streamAdd(
                AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_STREAM_KEY,
                message,
                AsyncTaskStreamConstants.STREAM_MAX_LEN
            );
            log.info("重新评估任务已重新入队：sessionId={}, retryCount={}", sessionId, retryCount);

        } catch (Exception e) {
            log.error("重试入队失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
            updateEvaluateStatus(sessionId, AsyncTaskStatus.FAILED, truncateError("重试入队失败：" + e.getMessage()));
        }
    }

    /**
     * 更新评估状态
     */
    private void updateEvaluateStatus(String sessionId, AsyncTaskStatus status, String error) {
        try {
            sessionRepository.findBySessionId(sessionId).ifPresent(session -> {
                session.setEvaluateStatus(status);
                session.setEvaluateError(error);
                sessionRepository.save(session);
                log.debug("评估状态已更新：sessionId={}, status={}", sessionId, status);
            });
        } catch (Exception e) {
            log.error("更新评估状态失败：sessionId={}, status={}, error={}", sessionId, status, e.getMessage(), e);
        }
    }

    /**
     * 从答案表读取三维综合分，更新到 questionsJson
     */
    private void updateQuestionScoresFromAnswers(String sessionId) {
        try {
            log.info("开始从答案表更新三维综合分到 questionsJson: sessionId={}", sessionId);
            
            sessionRepository.findBySessionId(sessionId).ifPresent(session -> {
                try {
                    String questionsJson = session.getQuestionsJson();
                    if (questionsJson == null) {
                        log.warn("questionsJson 为空，跳过更新：sessionId={}", sessionId);
                        return;
                    }
                    
                    // 清理特殊字符
                    questionsJson = questionsJson.replaceAll("\\p{Cntrl}", "")
                                                  .replaceAll("\\u200B", "")
                                                  .replaceAll("\\u200C", "")
                                                  .replaceAll("\\u200D", "")
                                                  .replaceAll("\\uFEFF", "");
                    
                    List<InterviewQuestionDTO> questions = objectMapper.readValue(
                        questionsJson,
                        new TypeReference<List<InterviewQuestionDTO>>() {}
                    );
                    
                    // 从答案表读取最新的分数（包含三维综合分）
                    List<InterviewAnswerEntity> answers = answerRepository.findBySession_SessionIdOrderByQuestionIndex(sessionId);
                    log.info("找到答案记录数：sessionId={}, count={}", sessionId, answers.size());
                    for (InterviewAnswerEntity answer : answers) {
                        int index = answer.getQuestionIndex();
                        if (index >= 0 && index < questions.size()) {
                            InterviewQuestionDTO question = questions.get(index);
                            log.info("读取答案分数：sessionId={}, questionIndex={}, score={}, technical={}, hr={}, architect={}",
                                sessionId, index, answer.getScore(), answer.getTechnicalScore(), answer.getHrScore(), answer.getArchitectScore());
                            // 使用 withEvaluation 方法更新 score、feedback 和三个维度
                            questions.set(index, question.withEvaluation(
                                answer.getScore(),
                                answer.getFeedback() != null ? answer.getFeedback() : question.feedback(),
                                answer.getTechnicalScore() != null 
                                    ? new InterviewQuestionDTO.DimensionScore(answer.getTechnicalScore(), answer.getTechnicalFeedback() != null ? answer.getTechnicalFeedback() : "")
                                    : question.technicalExpert(),
                                answer.getHrScore() != null 
                                    ? new InterviewQuestionDTO.DimensionScore(answer.getHrScore(), answer.getHrFeedback() != null ? answer.getHrFeedback() : "")
                                    : question.hrManager(),
                                answer.getArchitectScore() != null 
                                    ? new InterviewQuestionDTO.DimensionScore(answer.getArchitectScore(), answer.getArchitectFeedback() != null ? answer.getArchitectFeedback() : "")
                                    : question.architect()
                            ));
                            log.debug("更新第{}题分数：sessionId={}, score={}, technical={}, hr={}, architect={}",
                                index + 1, sessionId, answer.getScore(),
                                answer.getTechnicalScore(), answer.getHrScore(), answer.getArchitectScore());
                        }
                    }
                    
                    session.setQuestionsJson(objectMapper.writeValueAsString(questions));
                    sessionRepository.save(session);
                    log.info("已从答案表更新三维综合分到 questionsJson: sessionId={}, 题目数={}", sessionId, answers.size());
                    
                } catch (Exception e) {
                    log.error("从答案表更新分数失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error("从答案表更新分数失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
        }
    }

    /**
     * 保存基础评估结果到数据库（不包含三个维度）
     */
    private void saveBasicEvaluation(String sessionId, InterviewReportDTO report) {
        try {
            log.info("开始保存基础评估结果：sessionId={}, questionDetails 大小={}", 
                sessionId, report.questionDetails() != null ? report.questionDetails().size() : "null");
            
            sessionRepository.findBySessionId(sessionId).ifPresent(session -> {
                try {
                    // 更新整体评分
                    Integer overallScore = report.overallScore();
                    session.setOverallScore(overallScore);
                    
                    // 保存整体反馈
                    session.setOverallFeedback(report.overallFeedback());
                    
                    // 保存 strengths 和 improvements
                    String strengthsJson = objectMapper.writeValueAsString(report.strengths());
                    session.setStrengthsJson(strengthsJson);
                    
                    String improvementsJson = objectMapper.writeValueAsString(report.improvements());
                    session.setImprovementsJson(improvementsJson);
                    
                    // 保存每题的基础评估结果（仅分数和反馈，不包含三个维度）
                    log.info("检查 questionDetails: sessionId={}, isEmpty={}, isNull={}", 
                        sessionId, 
                        report.questionDetails() == null ? "null" : report.questionDetails().isEmpty());
                    
                    if (report.questionDetails() != null && !report.questionDetails().isEmpty()) {
                        // 更新每道题的评分和反馈到 questionsJson
                        String questionsJson = session.getQuestionsJson();
                        // 清理特殊字符
                        if (questionsJson != null) {
                            questionsJson = questionsJson.replaceAll("\\p{Cntrl}", "")
                                                          .replaceAll("\\u200B", "")
                                                          .replaceAll("\\u200C", "")
                                                          .replaceAll("\\u200D", "")
                                                          .replaceAll("\\uFEFF", "");
                        }
                        List<InterviewQuestionDTO> questions = objectMapper.readValue(
                            questionsJson,
                            new TypeReference<List<InterviewQuestionDTO>>() {}
                        );
                        
                        // 构建参考答案映射
                        java.util.Map<Integer, InterviewReportDTO.ReferenceAnswer> answerMap = new java.util.HashMap<>();
                        if (report.referenceAnswers() != null) {
                            for (InterviewReportDTO.ReferenceAnswer ra : report.referenceAnswers()) {
                                answerMap.put(ra.questionIndex(), ra);
                            }
                        }
                        
                        // 更新每题的分数和反馈（不包含三个维度）
                        for (InterviewReportDTO.QuestionEvaluation qe : report.questionDetails()) {
                            int index = qe.questionIndex();
                            if (index >= 0 && index < questions.size()) {
                                InterviewQuestionDTO question = questions.get(index);
                                // 只更新 score 和 feedback，不更新三个维度
                                questions.set(index, question.withEvaluation(
                                    qe.score(), 
                                    qe.feedback(),
                                    null,  // 技术专家维度
                                    null,  // HR 维度
                                    null   // 架构师维度
                                ));
                            }
                        }
                        
                        // 保存更新后的问题列表
                        session.setQuestionsJson(objectMapper.writeValueAsString(questions));
                    }
                    
                    sessionRepository.save(session);
                    log.info("基础评估结果已保存：sessionId={}, overallScore={}, 题目数={}", 
                        sessionId, overallScore, report.questionDetails().size());
                    
                } catch (Exception e) {
                    log.error("保存基础评估结果失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error("保存基础评估结果失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
        }
    }

    /**
     * 保存每题的评估结果到数据库
     */
    private void saveQuestionEvaluations(String sessionId, InterviewReportDTO report) {
        try {
            log.info("开始保存每题评估结果：sessionId={}, questionDetails 大小={}", 
                sessionId, report.questionDetails() != null ? report.questionDetails().size() : "null");
            
            sessionRepository.findBySessionId(sessionId).ifPresent(session -> {
                try {
                    // 更新整体评分（来自 AnswerEvaluationService 的计算结果）
                    Integer overallScore = report.overallScore();
                    session.setOverallScore(overallScore);
                    
                    // 保存整体反馈
                    session.setOverallFeedback(report.overallFeedback());
                    
                    // 保存 strengths 和 improvements
                    String strengthsJson = objectMapper.writeValueAsString(report.strengths());
                    session.setStrengthsJson(strengthsJson);
                    
                    String improvementsJson = objectMapper.writeValueAsString(report.improvements());
                    session.setImprovementsJson(improvementsJson);
                    
                    // 保存每题的评估结果（包含单题评分、反馈）
                    log.info("检查 questionDetails: sessionId={}, isEmpty={}, isNull={}", 
                        sessionId, 
                        report.questionDetails() == null ? "null" : report.questionDetails().isEmpty());
                    
                    if (report.questionDetails() != null && !report.questionDetails().isEmpty()) {
                        // 更新每道题的评分和反馈到 questionsJson
                        String questionsJson = session.getQuestionsJson();
                        // 清理特殊字符
                        if (questionsJson != null) {
                            questionsJson = questionsJson.replaceAll("\\p{Cntrl}", "")
                                                          .replaceAll("\\u200B", "")
                                                          .replaceAll("\\u200C", "")
                                                          .replaceAll("\\u200D", "")
                                                          .replaceAll("\\uFEFF", "");
                        }
                        List<InterviewQuestionDTO> questions = objectMapper.readValue(
                            questionsJson,
                            new TypeReference<List<InterviewQuestionDTO>>() {}
                        );
                        
                        // 构建参考答案映射
                        java.util.Map<Integer, InterviewReportDTO.ReferenceAnswer> answerMap = new java.util.HashMap<>();
                        if (report.referenceAnswers() != null) {
                            for (InterviewReportDTO.ReferenceAnswer ra : report.referenceAnswers()) {
                                answerMap.put(ra.questionIndex(), ra);
                            }
                        }
                        
                        // 更新每题的分数和反馈（包括三个维度）
                        for (InterviewReportDTO.QuestionEvaluation qe : report.questionDetails()) {
                            int index = qe.questionIndex();
                            if (index >= 0 && index < questions.size()) {
                                InterviewQuestionDTO question = questions.get(index);
                                // 使用 withEvaluation 方法更新 score、feedback 和三个维度
                                questions.set(index, question.withEvaluation(
                                    qe.score(), 
                                    qe.feedback(),
                                    new InterviewQuestionDTO.DimensionScore(
                                        qe.technicalExpert() != null ? qe.technicalExpert().score() : 0,
                                        qe.technicalExpert() != null ? qe.technicalExpert().feedback() : ""
                                    ),
                                    new InterviewQuestionDTO.DimensionScore(
                                        qe.hrManager() != null ? qe.hrManager().score() : 0,
                                        qe.hrManager() != null ? qe.hrManager().feedback() : ""
                                    ),
                                    new InterviewQuestionDTO.DimensionScore(
                                        qe.architect() != null ? qe.architect().score() : 0,
                                        qe.architect() != null ? qe.architect().feedback() : ""
                                    )
                                ));
                            }
                        }
                        
                        // 保存更新后的问题列表
                        session.setQuestionsJson(objectMapper.writeValueAsString(questions));
                        
                        // 新增：保存每题的基础评估结果到 interview_answers 表
                        log.info("开始保存每题答案到数据库：sessionId={}, 题目数={}", 
                            sessionId, report.questionDetails().size());
                        
                        // 查询已存在的答案，建立索引
                        List<InterviewAnswerEntity> existingAnswers = answerRepository.findBySession_SessionIdOrderByQuestionIndex(sessionId);
                        java.util.Map<Integer, InterviewAnswerEntity> existingAnswerMap = existingAnswers.stream()
                            .collect(java.util.stream.Collectors.toMap(
                                InterviewAnswerEntity::getQuestionIndex,
                                a -> a,
                                (a1, a2) -> a1
                            ));
                        
                        // 构建参考答案映射
                        java.util.Map<Integer, InterviewReportDTO.ReferenceAnswer> refAnswerMap = new java.util.HashMap<>();
                        if (report.referenceAnswers() != null) {
                            for (InterviewReportDTO.ReferenceAnswer ra : report.referenceAnswers()) {
                                refAnswerMap.put(ra.questionIndex(), ra);
                            }
                        }
                        
                        List<InterviewAnswerEntity> answersToSave = new java.util.ArrayList<>();
                        
                        // 遍历所有评估结果，更新或创建答案记录
                        for (InterviewReportDTO.QuestionEvaluation eval : report.questionDetails()) {
                            InterviewAnswerEntity answer = existingAnswerMap.get(eval.questionIndex());
                            
                            if (answer == null) {
                                // 未回答的题目，创建新记录
                                answer = new InterviewAnswerEntity();
                                answer.setSession(session);
                                answer.setQuestionIndex(eval.questionIndex());
                                answer.setQuestion(eval.question());
                                answer.setCategory(eval.category());
                                answer.setUserAnswer(eval.userAnswer());
                                log.debug("为题目 {} 创建答案记录", eval.questionIndex());
                            } else {
                                log.debug("更新题目 {} 的答案记录，原分数={}, 新分数={}", 
                                    eval.questionIndex(), answer.getScore(), eval.score());
                            }
                            
                            // 更新评分和反馈
                            answer.setScore(eval.score());
                            answer.setFeedback(eval.feedback());
                            
                            // 设置参考答案和关键点
                            InterviewReportDTO.ReferenceAnswer refAns = refAnswerMap.get(eval.questionIndex());
                            if (refAns != null) {
                                answer.setReferenceAnswer(refAns.referenceAnswer());
                                if (refAns.keyPoints() != null && !refAns.keyPoints().isEmpty()) {
                                    try {
                                        answer.setKeyPointsJson(objectMapper.writeValueAsString(refAns.keyPoints()));
                                    } catch (Exception e) {
                                        log.error("序列化 keyPoints 失败：{}", e.getMessage());
                                    }
                                }
                            }
                            
                            answersToSave.add(answer);
                        }
                        
                        if (!answersToSave.isEmpty()) {
                            answerRepository.saveAll(answersToSave);
                            log.info("基础评估答案已保存到数据库：sessionId={}, 答案数={}", 
                                sessionId, answersToSave.size());
                        }
                    }
                    
                    sessionRepository.save(session);
                    log.info("每题评估结果已保存：sessionId={}, overallScore={}, 题目数={}", 
                        sessionId, overallScore, report.questionDetails().size());
                    
                } catch (Exception e) {
                    log.error("保存每题评估结果失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error("保存每题评估结果失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
        }
    }

    /**
     * 保存评估报告到数据库
     */
    private void saveEvaluationReport(String sessionId, MultiDimensionEvaluationReport report) {
        try {
            sessionRepository.findBySessionId(sessionId).ifPresent(session -> {
                try {
                    // 更新综合得分（三维加权平均）
                    session.setOverallScore(report.getOverallScore());
                    
                    // 将多维度报告转换为 JSON 保存
                    String reportJson = objectMapper.writeValueAsString(report);
                    session.setMultiDimensionReportJson(reportJson);
                    
                    // 保存 strengths 和 improvements
                    String strengthsJson = objectMapper.writeValueAsString(report.getStrengths());
                    session.setStrengthsJson(strengthsJson);
                    
                    String improvementsJson = objectMapper.writeValueAsString(report.getImprovements());
                    session.setImprovementsJson(improvementsJson);
                    
                    sessionRepository.save(session);
                    log.info("多维度评估报告已保存：sessionId={}", sessionId);
                    
                } catch (Exception e) {
                    log.error("保存评估报告失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error("保存评估报告失败：sessionId={}, error={}", sessionId, e.getMessage(), e);
        }
    }
}
