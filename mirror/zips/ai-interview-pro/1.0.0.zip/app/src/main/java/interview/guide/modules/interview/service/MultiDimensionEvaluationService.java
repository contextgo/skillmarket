package interview.guide.modules.interview.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.modules.interview.model.InterviewQuestionDTO;
import interview.guide.modules.interview.model.dto.MultiDimensionEvaluationReport;
import interview.guide.modules.interview.service.AnswerEvaluationService;
import interview.guide.modules.interview.service.InterviewPersistenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * 多维度面试评估服务
 * 从技术专家、HR 经理、架构师三个维度进行全面评估
 */
@Slf4j
@Service
public class MultiDimensionEvaluationService {

    private final ChatClient chatClient;
    private final InterviewPersistenceService persistenceService;
    
    // 懒加载提示词模板和转换器
    private PromptTemplate technicalSystemPrompt;
    private PromptTemplate technicalUserPrompt;
    private BeanOutputConverter<TechnicalEvaluationDTO> technicalConverter;
    
    private PromptTemplate hrSystemPrompt;
    private PromptTemplate hrUserPrompt;
    private BeanOutputConverter<HREvaluationDTO> hrConverter;
    
    private PromptTemplate architectSystemPrompt;
    private PromptTemplate architectUserPrompt;
    private BeanOutputConverter<ArchitectEvaluationDTO> architectConverter;

    public MultiDimensionEvaluationService(ChatClient.Builder chatClientBuilder, InterviewPersistenceService persistenceService) {
        this.chatClient = chatClientBuilder.build();
        this.persistenceService = persistenceService;
        initPromptsAndConverters();
    }
    
    /**
     * 初始化提示词模板和转换器
     */
    private void initPromptsAndConverters() {
        try {
            var classLoader = Thread.currentThread().getContextClassLoader();
            
            // 技术专家维度
            var techSysResource = classLoader.getResource("prompts/interview-evaluation-technical.st");
            var techUserResource = classLoader.getResource("prompts/interview-evaluation-user.st");
            this.technicalSystemPrompt = new PromptTemplate(new String(techSysResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.technicalUserPrompt = new PromptTemplate(new String(techUserResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.technicalConverter = new BeanOutputConverter<>(TechnicalEvaluationDTO.class);
            
            // HR 经理维度
            var hrSysResource = classLoader.getResource("prompts/interview-evaluation-hr.st");
            var hrUserResource = classLoader.getResource("prompts/interview-evaluation-user.st");
            this.hrSystemPrompt = new PromptTemplate(new String(hrSysResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.hrUserPrompt = new PromptTemplate(new String(hrUserResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.hrConverter = new BeanOutputConverter<>(HREvaluationDTO.class);
            
            // 架构师维度
            var archSysResource = classLoader.getResource("prompts/interview-evaluation-architect.st");
            var archUserResource = classLoader.getResource("prompts/interview-evaluation-user.st");
            this.architectSystemPrompt = new PromptTemplate(new String(archSysResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.architectUserPrompt = new PromptTemplate(new String(archUserResource.openStream().readAllBytes(), StandardCharsets.UTF_8));
            this.architectConverter = new BeanOutputConverter<>(ArchitectEvaluationDTO.class);
            
        } catch (IOException e) {
            throw new RuntimeException("加载提示词模板失败", e);
        }
    }

    /**
     * 执行多维度评估
     */
    public MultiDimensionEvaluationReport evaluateMultiDimension(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        log.info("========== 开始多维度评估 ==========");
        log.info("会话 ID: {}, 题目数：{}", sessionId, questions.size());
        log.info("======================================");
        
        try {
            // 对每题单独进行多维度评估
            for (int i = 0; i < questions.size(); i++) {
                InterviewQuestionDTO question = questions.get(i);
                long questionStartTime = System.currentTimeMillis();
                
                log.info("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                log.info("【第 {}/{} 题】类别：{}", i + 1, questions.size(), question.category());
                log.info("题目：{}", question.question().substring(0, Math.min(50, question.question().length())) + "...");
                log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                
                // 1. 技术专家视角评估
                log.info("┌─ 正在进行【技术专家】评估...");
                TechnicalEvaluationDTO technicalEval = evaluateTechnicalForQuestion(sessionId, resumeSummary, List.of(question));
                log.info("└─ 【技术专家】评估完成 - 得分：{}/100", technicalEval.technicalScore());
                
                // 2. HR 经理视角评估
                log.info("┌─ 正在进行【HR 经理】评估...");
                HREvaluationDTO hrEval = evaluateHRForQuestion(sessionId, resumeSummary, List.of(question));
                log.info("└─ 【HR 经理】评估完成 - 得分：{}/100", hrEval.hrScore());
                
                // 3. 架构师视角评估
                log.info("┌─ 正在进行【架构师】评估...");
                ArchitectEvaluationDTO architectEval = evaluateArchitectForQuestion(sessionId, resumeSummary, List.of(question));
                log.info("└─ 【架构师】评估完成 - 得分：{}/100", architectEval.architectScore());
                
                // 4. 保存每题的维度评分到数据库
                log.info("正在保存第 {} 题维度评分到数据库...", i + 1);
                saveQuestionDimensionScores(sessionId, i, technicalEval, hrEval, architectEval);
                
                long questionEndTime = System.currentTimeMillis();
                log.info("✓ 第 {} 题评估完成，耗时：{}ms\n", i + 1, (questionEndTime - questionStartTime));
            }
            
            log.info("\n═══════════════════════════════════════════");
            log.info("所有题目评估完成，开始整体综合评估...");
            log.info("═══════════════════════════════════════════");
            
            // 5. 整体评估所有题目，生成综合报告
            log.info("┌─ 正在进行【技术专家】整体评估...");
            TechnicalEvaluationDTO overallTechnical = evaluateTechnical(sessionId, resumeSummary, questions);
            log.info("└─ 【技术专家】整体评估完成");
            
            log.info("┌─ 正在进行【HR 经理】整体评估...");
            HREvaluationDTO overallHr = evaluateHR(sessionId, resumeSummary, questions);
            log.info("└─ 【HR 经理】整体评估完成");
            
            log.info("┌─ 正在进行【架构师】整体评估...");
            ArchitectEvaluationDTO overallArchitect = evaluateArchitect(sessionId, resumeSummary, questions);
            log.info("└─ 【架构师】整体评估完成");
            
            // 6. 汇总生成综合报告
            MultiDimensionEvaluationReport report = mergeEvaluations(
                sessionId, questions, overallTechnical, overallHr, overallArchitect);
            
            log.info("\n★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★");
            log.info("多维度评估完成！");
            log.info("会话 ID: {}", sessionId);
            log.info("总得分：{}/100", report.getOverallScore());
            log.info("技术得分：{}/100", report.getTechnicalScore());
            log.info("HR 得分：{}/100", report.getHrScore());
            log.info("架构师得分：{}/100", report.getArchitectScore());
            log.info("★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★");
            
            return report;
            
        } catch (BusinessException e) {
            log.error("\n❌ 多维度评估失败 (业务异常): {}", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("\n❌ 多维度评估失败 (系统异常): {}", e.getMessage(), e);
            throw new BusinessException(ErrorCode.INTERVIEW_EVALUATION_FAILED, 
                "多维度评估失败：" + e.getMessage());
        }
    }

    private TechnicalEvaluationDTO evaluateTechnical(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = technicalSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = technicalUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + technicalConverter.getFormat();
            
            TechnicalEvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, technicalConverter, "技术专家评估");
            
            return dto != null ? dto : createDefaultTechnicalEvaluation();
            
        } catch (Exception e) {
            log.warn("技术专家评估失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultTechnicalEvaluation();
        }
    }

    private TechnicalEvaluationDTO evaluateTechnicalForQuestion(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = technicalSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = technicalUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + technicalConverter.getFormat();
            
            TechnicalEvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, technicalConverter, "技术专家评估 (单题)");
            
            return dto != null ? dto : createDefaultTechnicalEvaluation();
            
        } catch (Exception e) {
            log.warn("技术专家评估 (单题) 失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultTechnicalEvaluation();
        }
    }

    private HREvaluationDTO evaluateHR(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = hrSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = hrUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + hrConverter.getFormat();
            
            HREvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, hrConverter, "HR 经理评估");
            
            return dto != null ? dto : createDefaultHREvaluation();
            
        } catch (Exception e) {
            log.warn("HR 经理评估失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultHREvaluation();
        }
    }

    private HREvaluationDTO evaluateHRForQuestion(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = hrSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = hrUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + hrConverter.getFormat();
            
            HREvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, hrConverter, "HR 经理评估 (单题)");
            
            return dto != null ? dto : createDefaultHREvaluation();
            
        } catch (Exception e) {
            log.warn("HR 经理评估 (单题) 失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultHREvaluation();
        }
    }

    private ArchitectEvaluationDTO evaluateArchitect(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = architectSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = architectUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + architectConverter.getFormat();
            
            ArchitectEvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, architectConverter, "架构师评估");
            
            return dto != null ? dto : createDefaultArchitectEvaluation();
            
        } catch (Exception e) {
            log.warn("架构师评估失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultArchitectEvaluation();
        }
    }

    private ArchitectEvaluationDTO evaluateArchitectForQuestion(
            String sessionId,
            String resumeSummary,
            List<InterviewQuestionDTO> questions) {
        
        try {
            String systemPrompt = architectSystemPrompt.render();
            Map<String, Object> variables = buildCommonVariables(resumeSummary, questions);
            String userPrompt = architectUserPrompt.render(variables);
            String systemPromptWithFormat = systemPrompt + "\n\n" + architectConverter.getFormat();
            
            ArchitectEvaluationDTO dto = invokeAI(
                sessionId, systemPromptWithFormat, userPrompt, architectConverter, "架构师评估 (单题)");
            
            return dto != null ? dto : createDefaultArchitectEvaluation();
            
        } catch (Exception e) {
            log.warn("架构师评估 (单题) 失败，使用默认评价：sessionId={}, error={}", sessionId, e.getMessage());
            return createDefaultArchitectEvaluation();
        }
    }

    private <T> T invokeAI(String sessionId, String systemPrompt, String userPrompt, 
                          BeanOutputConverter<T> converter, String evalType) {
        try {
            // 调用 AI 获取原始响应
            String rawResponse = chatClient.prompt()
                .system(systemPrompt)
                .user(userPrompt)
                .call()
                .content();
            
            // 清理 Markdown 代码块标记
            if (rawResponse != null) {
                rawResponse = rawResponse.replaceAll("```json\\s*", "")
                                        .replaceAll("```\\s*", "")
                                        .trim();
            }
            
            // 使用 converter 解析清理后的 JSON
            T result = converter.convert(rawResponse);
            log.debug("{}完成：sessionId={}", evalType, sessionId);
            return result;
        } catch (Exception e) {
            log.error("{}失败：sessionId={}, error={}", evalType, sessionId, e.getMessage(), e);
            return null;
        }
    }

    private Map<String, Object> buildCommonVariables(String resumeSummary, List<InterviewQuestionDTO> questions) {
        Map<String, Object> variables = new HashMap<>();
        variables.put("resumeText", resumeSummary);
        variables.put("qaRecords", buildQARecords(questions));
        return variables;
    }

    private String buildQARecords(List<InterviewQuestionDTO> questions) {
        StringBuilder sb = new StringBuilder();
        for (InterviewQuestionDTO q : questions) {
            sb.append(String.format("问题%d [%s]: %s\n", 
                q.questionIndex() + 1, q.category(), q.question()));
            sb.append(String.format("回答：%s\n\n", 
                q.userAnswer() != null ? q.userAnswer() : "(未回答)"));
        }
        return sb.toString();
    }

    private MultiDimensionEvaluationReport mergeEvaluations(
            String sessionId,
            List<InterviewQuestionDTO> questions,
            TechnicalEvaluationDTO technical,
            HREvaluationDTO hr,
            ArchitectEvaluationDTO architect) {
        
        MultiDimensionEvaluationReport report = new MultiDimensionEvaluationReport();
        report.setSessionId(sessionId);
        report.setTotalQuestions(questions.size());
        
        // 计算综合得分（加权平均）
        int overallScore = (int) Math.round(
            technical.technicalScore() * 0.4 + 
            hr.hrScore() * 0.3 + 
            architect.architectScore() * 0.3);
        
        report.setOverallScore(overallScore);
        
        // 技术维度
        report.setTechnicalScore(technical.technicalScore());
        report.setTechnicalFeedback(technical.technicalFeedback());
        report.setTechnicalSummary(buildTechnicalSummary(technical));  // 新增：生成技术维度总结
        report.setTechnicalStrengths(technical.technicalStrengths());
        report.setTechnicalWeaknesses(technical.technicalWeaknesses());
        report.setKnowledgeGaps(technical.knowledgeGaps());
        report.setDepthAnalysis(technical.depthAnalysis());
        
        // HR 维度
        report.setHrScore(hr.hrScore());
        report.setHrFeedback(hr.hrFeedback());
        report.setHrSummary(buildHrSummary(hr));  // 新增：生成 HR 维度总结
        report.setCommunicationStrengths(hr.communicationStrengths());
        report.setSoftSkillsGaps(hr.softSkillsGaps());
        report.setLearningPotential(hr.learningPotential());
        report.setCultureFit(hr.cultureFit());
        report.setCareerAdvice(hr.careerAdvice());
        
        // 架构师维度
        report.setArchitectScore(architect.architectScore());
        report.setArchitectFeedback(architect.architectFeedback());
        report.setArchitectSummary(buildArchitectSummary(architect));  // 新增：生成架构师维度总结
        report.setSystemDesignAbility(String.join("; ", architect.designStrengths()));
        report.setTechnicalDepth(architect.technicalDepth());
        report.setEngineeringPractice(architect.engineeringPractice());
        report.setInnovationPotential(architect.innovationAndTradeoff());
        report.setRecommendedLevel(architect.recommendedLevel());
        
        // 综合评语
        report.setOverallFeedback(buildOverallFeedback(technical, hr, architect));
        report.setStrengths(mergeStrengths(technical, hr, architect));
        report.setImprovements(mergeImprovements(technical, hr, architect));
        
        return report;
    }

    /**
     * 保存每题的维度评分到数据库
     */
    private void saveQuestionDimensionScores(
            String sessionId,
            int questionIndex,
            TechnicalEvaluationDTO technical,
            HREvaluationDTO hr,
            ArchitectEvaluationDTO architect) {
        
        try {
            log.info("开始保存第{}题维度评分：sessionId={}, technical={}, hr={}, architect={}", 
                questionIndex + 1, sessionId, technical.technicalScore(), hr.hrScore(), architect.architectScore());
            
            // 查找对应的答案记录（使用 JOIN FETCH 避免懒加载问题）
            var answerOpt = persistenceService.findAnswerWithSessionBySessionIdAndIndex(sessionId, questionIndex);
            if (answerOpt.isPresent()) {
                var answer = answerOpt.get();
                log.info("找到答案记录：id={}, questionIndex={}", answer.getId(), answer.getQuestionIndex());
                
                // 设置维度评分和反馈
                answer.setTechnicalScore(technical.technicalScore());
                answer.setTechnicalFeedback(technical.technicalFeedback());
                answer.setHrScore(hr.hrScore());
                answer.setHrFeedback(hr.hrFeedback());
                answer.setArchitectScore(architect.architectScore());
                answer.setArchitectFeedback(architect.architectFeedback());
                
                // 计算综合得分并更新普通评分
                int overallScore = (int) Math.round(
                    technical.technicalScore() * 0.4 + 
                    hr.hrScore() * 0.3 + 
                    architect.architectScore() * 0.3);
                answer.setScore(overallScore);
                
                log.info("准备保存：technicalScore={}, hrScore={}, architectScore={}, score={}", 
                    answer.getTechnicalScore(), answer.getHrScore(), answer.getArchitectScore(), answer.getScore());
                
                // 保存更新
                persistenceService.saveAnswer(answer);
                log.info("已保存第{}题维度评分：sessionId={}, technical={}, hr={}, architect={}", 
                    questionIndex + 1, sessionId, technical.technicalScore(), hr.hrScore(), architect.architectScore());
            } else {
                log.warn("未找到答案记录，跳过维度评分保存：sessionId={}, questionIndex={}", sessionId, questionIndex);
            }
        } catch (Exception e) {
            log.error("保存维度评分失败：sessionId={}, questionIndex={}, error={}", sessionId, questionIndex, e.getMessage(), e);
        }
    }

    private String buildOverallFeedback(TechnicalEvaluationDTO technical, 
                                       HREvaluationDTO hr, 
                                       ArchitectEvaluationDTO architect) {
        StringBuilder sb = new StringBuilder();
        sb.append("【技术能力】").append(technical.technicalFeedback()).append("\n\n");
        sb.append("【综合素质】").append(hr.hrFeedback()).append("\n\n");
        sb.append("【架构潜力】").append(architect.architectFeedback());
        return sb.toString();
    }

    /**
     * 生成技术维度总结
     */
    private String buildTechnicalSummary(TechnicalEvaluationDTO technical) {
        StringBuilder sb = new StringBuilder();
        sb.append(technical.technicalFeedback());
        if (technical.depthAnalysis() != null && !technical.depthAnalysis().isBlank()) {
            sb.append(" ").append(technical.depthAnalysis());
        }
        return sb.toString();
    }

    /**
     * 生成 HR 维度总结
     */
    private String buildHrSummary(HREvaluationDTO hr) {
        StringBuilder sb = new StringBuilder();
        sb.append(hr.hrFeedback());
        if (hr.learningPotential() != null && !hr.learningPotential().isBlank()) {
            sb.append(" ").append(hr.learningPotential());
        }
        return sb.toString();
    }

    /**
     * 生成架构师维度总结
     */
    private String buildArchitectSummary(ArchitectEvaluationDTO architect) {
        StringBuilder sb = new StringBuilder();
        sb.append(architect.architectFeedback());
        if (architect.technicalDepth() != null && !architect.technicalDepth().isBlank()) {
            sb.append(" ").append(architect.technicalDepth());
        }
        return sb.toString();
    }

    private List<String> mergeStrengths(TechnicalEvaluationDTO technical, 
                                       HREvaluationDTO hr, 
                                       ArchitectEvaluationDTO architect) {
        Set<String> strengths = new LinkedHashSet<>();
        if (technical.technicalStrengths() != null) {
            strengths.addAll(technical.technicalStrengths().stream().limit(3).toList());
        }
        if (hr.communicationStrengths() != null) {
            strengths.addAll(hr.communicationStrengths().stream().limit(2).toList());
        }
        if (architect.designStrengths() != null) {
            strengths.addAll(architect.designStrengths().stream().limit(3).toList());
        }
        return strengths.stream().limit(8).toList();
    }

    private List<String> mergeImprovements(TechnicalEvaluationDTO technical, 
                                          HREvaluationDTO hr, 
                                          ArchitectEvaluationDTO architect) {
        Set<String> improvements = new LinkedHashSet<>();
        if (technical.technicalWeaknesses() != null) {
            improvements.addAll(technical.technicalWeaknesses().stream().limit(3).toList());
        }
        if (hr.softSkillsGaps() != null) {
            improvements.addAll(hr.softSkillsGaps().stream().limit(2).toList());
        }
        if (architect.designWeaknesses() != null) {
            improvements.addAll(architect.designWeaknesses().stream().limit(3).toList());
        }
        if (architect.engineeringPractice() != null && !architect.engineeringPractice().isBlank()) {
            improvements.add("工程实践：" + architect.engineeringPractice());
        }
        return improvements.stream().limit(8).toList();
    }

    private TechnicalEvaluationDTO createDefaultTechnicalEvaluation() {
        return new TechnicalEvaluationDTO(
            75,
            "候选人展现了基本的技术能力。",
            List.of("基础概念清晰"),
            List.of("需要进一步提升深度"),
            List.of(),
            "具备一定的技术深度，建议继续加强底层原理学习。"
        );
    }

    private HREvaluationDTO createDefaultHREvaluation() {
        return new HREvaluationDTO(
            75,
            "候选人沟通能力良好，态度积极。",
            List.of("表达清晰"),
            List.of(),
            "学习能力较强，有成长潜力。",
            "与团队文化匹配度较高。",
            "建议在技术领域持续深耕，提升综合能力。"
        );
    }

    private ArchitectEvaluationDTO createDefaultArchitectEvaluation() {
        return new ArchitectEvaluationDTO(
            75,
            "候选人具备一定的系统设计能力。",
            List.of("基本设计能力尚可"),
            List.of("技术深度一般，有工程化意识"),
            "具备一定创新思维",
            "中级工程师",
            "具备一定创新思维",
            "中级工程师"
        );
    }

    // ==================== DTO Classes ====================

    public record TechnicalEvaluationDTO(
        Integer technicalScore,
        String technicalFeedback,
        List<String> technicalStrengths,
        List<String> technicalWeaknesses,
        List<String> knowledgeGaps,
        String depthAnalysis
    ) {}

    public record HREvaluationDTO(
        Integer hrScore,
        String hrFeedback,
        List<String> communicationStrengths,
        List<String> softSkillsGaps,
        String learningPotential,
        String cultureFit,
        String careerAdvice
    ) {}

    public record ArchitectEvaluationDTO(
        Integer architectScore,
        String architectFeedback,
        List<String> designStrengths,
        List<String> designWeaknesses,
        String technicalDepth,
        String engineeringPractice,
        String innovationAndTradeoff,
        String recommendedLevel
    ) {}
}