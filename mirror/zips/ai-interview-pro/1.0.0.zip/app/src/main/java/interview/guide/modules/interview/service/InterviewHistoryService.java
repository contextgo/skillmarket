package interview.guide.modules.interview.service;

import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.common.constant.AsyncTaskStreamConstants;
import interview.guide.infrastructure.export.PdfExportService;
import interview.guide.infrastructure.mapper.InterviewMapper;
import interview.guide.modules.interview.model.InterviewAnswerEntity;
import interview.guide.modules.interview.model.InterviewDetailDTO;
import interview.guide.modules.interview.model.InterviewQuestionDTO;
import interview.guide.modules.interview.model.InterviewSessionEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 面试历史服务
 * 获取面试会话详情和导出面试报告
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InterviewHistoryService {

    private final InterviewPersistenceService interviewPersistenceService;
    private final PdfExportService pdfExportService;
    private final ObjectMapper objectMapper;
    private final InterviewMapper interviewMapper;
    private final RedisTemplate<String, String> redisTemplate;

    /**
     * 获取面试会话详情
     */
    public InterviewDetailDTO getInterviewDetail(String sessionId) {
        Optional<InterviewSessionEntity> sessionOpt = interviewPersistenceService.findBySessionId(sessionId);
        if (sessionOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.INTERVIEW_SESSION_NOT_FOUND);
        }
    
        InterviewSessionEntity session = sessionOpt.get();
    
        // 解析 JSON 字段
        List<Object> questions = parseJson(session.getQuestionsJson(), new TypeReference<>() {});
        List<String> strengths = parseJson(session.getStrengthsJson(), new TypeReference<>() {});
        List<String> improvements = parseJson(session.getImprovementsJson(), new TypeReference<>() {});
        List<Object> referenceAnswers = parseJson(session.getReferenceAnswersJson(), new TypeReference<>() {});
            
        // 解析多维度报告（如果存在）
        Map<String, Object> multiDimensionReport = null;
        if (session.getMultiDimensionReportJson() != null) {
            multiDimensionReport = parseJson(session.getMultiDimensionReportJson(), new TypeReference<>() {});
            log.info("找到多维度报告：sessionId={}, technicalScore={}, hrScore={}, architectScore={}, technicalSummary={}, hrSummary={}, architectSummary={}", 
                sessionId,
                multiDimensionReport != null ? multiDimensionReport.get("technicalScore") : "null",
                multiDimensionReport != null ? multiDimensionReport.get("hrScore") : "null",
                multiDimensionReport != null ? multiDimensionReport.get("architectScore") : "null",
                multiDimensionReport != null ? multiDimensionReport.get("technicalSummary") : "null",
                multiDimensionReport != null ? multiDimensionReport.get("hrSummary") : "null",
                multiDimensionReport != null ? multiDimensionReport.get("architectSummary") : "null"
            );
        } else {
            log.info("未找到多维度报告：sessionId={}", sessionId);
        }
    
        // 解析所有题目（用于构建完整的答案列表）
        List<InterviewQuestionDTO> allQuestions = parseJson(
            session.getQuestionsJson(),
                new TypeReference<>() {
                }
        );
    
        // 构建答案详情列表（包含所有题目，未回答的也要显示）
        // 手动查询答案记录，避免懒加载问题
        List<InterviewAnswerEntity> answers = interviewPersistenceService.findAnswersBySessionId(sessionId);
        List<InterviewDetailDTO.AnswerDetailDTO> answerList = buildAnswerDetailList(
            allQuestions,
            answers
        );
    
        // 使用 MapStruct 组装最终 DTO
        return interviewMapper.toDetailDTO(
            session,
            questions,
            strengths,
            improvements,
            referenceAnswers,
            answerList,
            multiDimensionReport,
            session.getEnableMultiDimension()
        );
    }

    /**
     * 构建答案详情列表（包含所有题目）
     * 对于用户已回答的题目使用答案数据，对于未回答的题目构建空答案
     */
    private List<InterviewDetailDTO.AnswerDetailDTO> buildAnswerDetailList(
        List<InterviewQuestionDTO> allQuestions,
        List<InterviewAnswerEntity> answers
    ) {
        if (allQuestions == null || allQuestions.isEmpty()) {
            // 如果没有题目数据，回退到仅显示已回答的题目
            return interviewMapper.toAnswerDetailDTOList(answers, this::extractKeyPoints);
        }

        // 将答案按 questionIndex 索引
        java.util.Map<Integer, InterviewAnswerEntity> answerMap = answers.stream()
            .collect(java.util.stream.Collectors.toMap(
                InterviewAnswerEntity::getQuestionIndex,
                a -> a,
                (a1, a2) -> a1  // 如果有重复，取第一个
            ));

        // 遍历所有题目，构建完整的答案详情列表
        log.info("开始构建答案详情列表：题目数={}, 答案数={}", allQuestions.size(), answers.size());
        return allQuestions.stream()
            .map(question -> {
                InterviewAnswerEntity answer = answerMap.get(question.questionIndex());
                if (answer != null) {
                    log.info("题目 {} - 答案存在：questionIndex={}, userAnswer长度={}, score={}, feedback长度={}",
                        question.questionIndex(), 
                        answer.getQuestionIndex(),
                        answer.getUserAnswer() != null ? answer.getUserAnswer().length() : 0,
                        answer.getScore(),
                        answer.getFeedback() != null ? answer.getFeedback().length() : 0);
                    // 用户已回答，使用答案数据 + 问题中的三个维度
                    return new InterviewDetailDTO.AnswerDetailDTO(
                        answer.getQuestionIndex(),
                        answer.getQuestion(),
                        answer.getCategory(),
                        answer.getUserAnswer(),
                        answer.getScore() != null ? answer.getScore() : 0,
                        answer.getFeedback(),
                        question.technicalExpert() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.technicalExpert().score(), 
                                question.technicalExpert().feedback())
                            : null,
                        question.hrManager() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.hrManager().score(), 
                                question.hrManager().feedback())
                            : null,
                        question.architect() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.architect().score(), 
                                question.architect().feedback())
                            : null,
                        answer.getReferenceAnswer(),
                        extractKeyPoints(answer),
                        null   // answeredAt
                    );
                } else {
                    log.warn("题目 {} - 答案不存在：questionIndex={}", question.questionIndex());
                    // 用户未回答，构建空答案
                    return new InterviewDetailDTO.AnswerDetailDTO(
                        question.questionIndex(),
                        question.question(),
                        question.category(),
                        null,  // userAnswer
                        question.score() != null ? question.score() : 0,  // score
                        question.feedback(),  // feedback
                        question.technicalExpert() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.technicalExpert().score(), 
                                question.technicalExpert().feedback())
                            : null,
                        question.hrManager() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.hrManager().score(), 
                                question.hrManager().feedback())
                            : null,
                        question.architect() != null 
                            ? new InterviewDetailDTO.AnswerDetailDTO.DimensionScore(
                                question.architect().score(), 
                                question.architect().feedback())
                            : null,
                        null,  // referenceAnswer
                        null,  // keyPoints
                        null   // answeredAt
                    );
                }
            })
            .toList();
    }

    /**
     * 从 JSON 提取 keyPoints
     */
    private List<String> extractKeyPoints(InterviewAnswerEntity answer) {
        return parseJson(answer.getKeyPointsJson(), new TypeReference<>() {});
    }

    /**
     * 通用 JSON 解析方法
     */
    private <T> T parseJson(String json, TypeReference<T> typeRef) {
        if (json == null) {
            return null;
        }
        try {
            return objectMapper.readValue(json, typeRef);
        } catch (JacksonException e) {
            log.error("解析 JSON 失败", e);
            return null;
        }
    }

    /**
     * 导出面试报告为 PDF
     */
    public byte[] exportInterviewPdf(String sessionId) {
        Optional<InterviewSessionEntity> sessionOpt = interviewPersistenceService.findBySessionId(sessionId);
        if (sessionOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.INTERVIEW_SESSION_NOT_FOUND);
        }

        InterviewSessionEntity session = sessionOpt.get();
        try {
            return pdfExportService.exportInterviewReport(session);
        } catch (Exception e) {
            log.error("导出 PDF 失败：sessionId={}", sessionId, e);
            throw new BusinessException(ErrorCode.EXPORT_PDF_FAILED, "导出 PDF 失败：" + e.getMessage());
        }
    }

    /**
     * 重新评估面试（异步）
     * 将评估任务发送到 Redis Stream，由消费者处理
     */
    public void reevaluateInterview(String sessionId, String resumeSummary, List<InterviewQuestionDTO> questions, boolean enableMultiDimension) {
        try {
            // 构建评估任务数据
            Map<String, String> taskData = new HashMap<>();
            taskData.put(AsyncTaskStreamConstants.FIELD_SESSION_ID, sessionId);
            taskData.put("resumeSummary", resumeSummary);
            taskData.put("enableMultiDimension", String.valueOf(enableMultiDimension));
            
            // 将问题列表转换为 JSON 字符串
            String questionsJson = objectMapper.writeValueAsString(questions);
            taskData.put("questionsJson", questionsJson);
            
            // 根据选项发送到不同的 Redis Stream
            if (enableMultiDimension) {
                // 发送到多维度重新评估 Redis Stream
                MapRecord<String, String, String> record = MapRecord.create(
                    AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_STREAM_KEY, taskData);
                redisTemplate.opsForStream().add(record);
                log.info("已发送多维度重新评估任务到 Redis Stream: sessionId={}", sessionId);
            } else {
                // TODO: 发送到单维度评估 Stream（如果需要支持）
                log.warn("当前不支持单维度评估，默认使用多维度评估：sessionId={}", sessionId);
                MapRecord<String, String, String> record = MapRecord.create(
                    AsyncTaskStreamConstants.INTERVIEW_REEVALUATE_STREAM_KEY, taskData);
                redisTemplate.opsForStream().add(record);
            }
            
        } catch (Exception e) {
            log.error("发送重新评估任务失败：sessionId={}", sessionId, e);
            throw new BusinessException(ErrorCode.INTERVIEW_REEVALUATION_FAILED, "发送重新评估任务失败：" + e.getMessage());
        }
    }
    
    /**
     * 重新评估面试（异步）- 向后兼容版本
     */
    public void reevaluateInterview(String sessionId, String resumeSummary, List<InterviewQuestionDTO> questions) {
        reevaluateInterview(sessionId, resumeSummary, questions, true);
    }
}