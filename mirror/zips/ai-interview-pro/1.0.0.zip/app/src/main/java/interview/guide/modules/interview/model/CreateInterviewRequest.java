package interview.guide.modules.interview.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * 创建面试会话请求
 */
public record CreateInterviewRequest(
    @NotBlank(message = "简历文本不能为空")
    String resumeText,      // 简历文本内容

    String jobDescription, // 岗位 JD 描述

    @Min(value = 3, message = "题目数量最少 3 题")
    @Max(value = 20, message = "题目数量最多 20 题")
    int questionCount,      // 面试题目数量 (3-20)

    @Min(value = 0, message = "追问数量最少 0 个")
    @Max(value = 3, message = "追问数量最多 3 个")
    Integer followUpCount,  // 每个主问题的追问数量 (0-3)，默认为 1

    Boolean enableMultiDimension,  // 是否开启多维度评估，默认为 true

    @NotNull(message = "简历 ID 不能为空")
    Long resumeId,          // 简历 ID（用于持久化关联）

    Boolean forceCreate     // 是否强制创建新会话（忽略未完成的会话），默认为 false
) {}