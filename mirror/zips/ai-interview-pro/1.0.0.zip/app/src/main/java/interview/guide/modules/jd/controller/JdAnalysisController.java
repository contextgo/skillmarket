package interview.guide.modules.jd.controller;

import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.common.result.Result;
import interview.guide.modules.jd.dto.JdAnalysisRequest;
import interview.guide.modules.jd.dto.JdAnalysisResponse;
import interview.guide.modules.jd.model.JdAnalysisEntity;
import interview.guide.modules.jd.service.JdAnalysisService;
import interview.guide.modules.user.entity.User;
import interview.guide.modules.user.repository.UserRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * JD 分析控制器
 */
@RestController
@RequestMapping("/api/jd-analysis")
@RequiredArgsConstructor
public class JdAnalysisController {

    private final JdAnalysisService jdAnalysisService;
    private final UserRepository userRepository;

    /**
     * 分析岗位 JD
     */
    @PostMapping("/analyze")
    public ResponseEntity<Result<JdAnalysisResponse>> analyzeJd(
            @Valid @RequestBody JdAnalysisRequest request) {
        
        // 获取当前用户
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User currentUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new BusinessException(ErrorCode.UNAUTHORIZED, "用户不存在或已过期，请重新登录"));
        
        JdAnalysisResponse result = jdAnalysisService.analyzeJd(request, currentUser);
        return ResponseEntity.ok(Result.success(result));
    }

    /**
     * 获取用户的分析历史
     */
    @GetMapping("/history")
    public ResponseEntity<Result<List<JdAnalysisEntity>>> getAnalysisHistory() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User currentUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new BusinessException(ErrorCode.UNAUTHORIZED, "用户不存在或已过期，请重新登录"));
        
        List<JdAnalysisEntity> history = jdAnalysisService.getUserAnalysisHistory(currentUser.getId());
        return ResponseEntity.ok(Result.success(history));
    }

    /**
     * 根据 ID 获取分析详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<Result<JdAnalysisEntity>> getAnalysisDetail(@PathVariable Long id) {
        // TODO: 添加权限验证，确保只能查看自己的分析记录
        JdAnalysisEntity analysis = jdAnalysisService.getUserAnalysisHistory(0L).stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("未找到该分析记录"));
        
        return ResponseEntity.ok(Result.success(analysis));
    }
}
