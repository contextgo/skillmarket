package interview.guide.modules.jd.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.modules.jd.dto.JdAnalysisRequest;
import interview.guide.modules.jd.dto.JdAnalysisResponse;
import interview.guide.modules.jd.dto.JdAnalysisResponse.MatchAnalysis;
import interview.guide.modules.jd.model.JdAnalysisEntity;
import interview.guide.modules.jd.repository.JdAnalysisRepository;
import interview.guide.modules.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;

/**
 * JD 分析服务
 */
@Slf4j
@Service
public class JdAnalysisService {

    private final JdAnalysisRepository jdAnalysisRepository;
    private final ChatModel chatModel;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public JdAnalysisService(JdAnalysisRepository jdAnalysisRepository, ChatModel chatModel) {
        this.jdAnalysisRepository = jdAnalysisRepository;
        this.chatModel = chatModel;
    }

    /**
     * 分析岗位 JD
     */
    @Transactional
    public JdAnalysisResponse analyzeJd(JdAnalysisRequest request, User currentUser) {
        log.info("开始分析岗位 JD: {} - {}", request.getCompanyName(), request.getPosition());
        
        // 1. 校验 JD 内容质量
        validateJdTextQuality(request.getJdText());

        // 2. 构建 AI 提示词
        String systemPrompt = buildSystemPrompt(request.isEnableMatchAnalysis());
        String userPrompt = buildUserPrompt(request);

        try {
            // 调用 AI 进行分析
            List<Message> messages = List.of(
                new SystemMessage(systemPrompt),
                new UserMessage(userPrompt)
            );
            Prompt prompt = new Prompt(messages);
            ChatResponse response = chatModel.call(prompt);

            String analysisContent = response.getResult().getOutput().getText();
            log.info("AI 返回的原始内容：{}", analysisContent.substring(0, Math.min(500, analysisContent.length())) + "...");
            
            // 解析 AI 返回的结果
            JdAnalysisResponse analysisResult = parseAnalysisResult(analysisContent);
            
            // 设置基本信息
            analysisResult.setCompanyName(request.getCompanyName());
            analysisResult.setPosition(request.getPosition());
            
            // 如果进行了匹配分析，确保 matchScore 和 matchAnalysis 都存在
            if (request.isEnableMatchAnalysis() && request.getResumeText() != null) {
                MatchAnalysis matchAnalysis = analysisResult.getMatchAnalysis();
                
                // 检查是否包含 matchAnalysis
                if (matchAnalysis == null) {
                    log.warn("AI 未返回 matchAnalysis 字段，创建默认值");
                    matchAnalysis = new MatchAnalysis();
                    matchAnalysis.setMatchScore(0);
                    matchAnalysis.setStrengths(List.of());
                    matchAnalysis.setWeaknesses(List.of());
                    matchAnalysis.setImprovementSuggestions(List.of());
                    analysisResult.setMatchAnalysis(matchAnalysis);
                }
                
                // 确保顶层 matchScore 与 matchAnalysis 中的分数一致
                if (matchAnalysis.getMatchScore() != null) {
                    analysisResult.setMatchScore(matchAnalysis.getMatchScore().doubleValue());
                    log.info("✅ JD 匹配分析完成：matchScore={}, strengths={}, weaknesses={}, suggestions={}", 
                        matchAnalysis.getMatchScore(), 
                        matchAnalysis.getStrengths() != null ? matchAnalysis.getStrengths().size() : 0,
                        matchAnalysis.getWeaknesses() != null ? matchAnalysis.getWeaknesses().size() : 0,
                        matchAnalysis.getImprovementSuggestions() != null ? matchAnalysis.getImprovementSuggestions().size() : 0);
                } else {
                    log.warn("⚠️ matchAnalysis 中缺少 matchScore 字段，使用默认值 0");
                    matchAnalysis.setMatchScore(0);
                    analysisResult.setMatchScore(0.0);
                }
                
                // 打印完整的匹配分析信息
                log.info("📊 完整匹配分析：{}", objectMapper.writeValueAsString(matchAnalysis));
            }

            // 保存到数据库
            saveAnalysis(request, analysisResult, currentUser.getId());

            log.info("岗位 JD 分析完成：{}", request.getPosition());
            return analysisResult;

        } catch (Exception e) {
            log.error("JD 分析失败", e);
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "JD 分析失败：" + e.getMessage());
        }
    }

    /**
     * 获取用户的分析历史
     */
    @Transactional(readOnly = true)
    public List<JdAnalysisEntity> getUserAnalysisHistory(Long userId) {
        return jdAnalysisRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    /**
     * 保存分析结果
     */
    private void saveAnalysis(JdAnalysisRequest request, JdAnalysisResponse result, Long userId) {
        JdAnalysisEntity entity = new JdAnalysisEntity();
        entity.setCompanyName(request.getCompanyName());
        entity.setPosition(request.getPosition());
        entity.setJdText(request.getJdText());
        
        try {
            entity.setAnalysisReport(objectMapper.writeValueAsString(result));
        } catch (JsonProcessingException e) {
            log.warn("序列化分析报告失败", e);
        }

        entity.setKeySkills(String.join(",", result.getKeySkills() != null ? result.getKeySkills() : List.of()));
        entity.setSalaryRange(result.getSalaryRange());
        entity.setExperienceRequirement(result.getExperienceRequirement());
        entity.setEducationRequirement(result.getEducationRequirement());
        entity.setMatchScore(result.getMatchScore());
        entity.setUserId(userId);

        jdAnalysisRepository.save(entity);
    }

    /**
     * 构建系统提示词
     */
    private String buildSystemPrompt(boolean includeMatchAnalysis) {
        // 从文件中读取提示词模板
        try {
            Resource resource = new ClassPathResource("prompts/jd-analysis-prompt.txt");
            String template = StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
            
            // 如果不包含匹配分析，移除 matchAnalysis 相关部分
            if (!includeMatchAnalysis) {
                int matchAnalysisStart = template.indexOf("\"matchAnalysis\": {");
                if (matchAnalysisStart > 0) {
                    int matchAnalysisEnd = findClosingBrace(template, matchAnalysisStart);
                    template = template.substring(0, matchAnalysisStart) + template.substring(matchAnalysisEnd + 1);
                }
            }
            
            return template;
        } catch (IOException e) {
            log.error("读取提示词模板失败", e);
            throw new RuntimeException("提示词模板加载失败");
        }
    }

    /**
     * 校验 JD 文本质量，检测是否为有效内容
     */
    private void validateJdTextQuality(String jdText) {
        if (jdText == null || jdText.trim().isEmpty()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "JD 内容不能为空");
        }

        // 移除所有空白字符后的有效内容长度
        String normalizedText = jdText.replaceAll("\\s+", " ").trim();
        
        // 1. 检查文本长度
        if (normalizedText.length() < 20) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "JD 内容太短，请输入有效的岗位描述");
        }

        // 2. 检测乱码特征
        int totalChars = normalizedText.length();
        int validCharCount = 0;
        int chineseCharCount = 0;
        int englishCharCount = 0;
        int numberCharCount = 0;
        int punctuationCount = 0;
        int suspiciousCharCount = 0; // 可疑字符（乱码特征）

        for (char c : normalizedText.toCharArray()) {
            if (Character.isLetter(c) || Character.isDigit(c) || Character.isWhitespace(c)) {
                if (Character.UnicodeBlock.of(c) == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS) {
                    chineseCharCount++;
                } else if (Character.isLetter(c)) {
                    englishCharCount++;
                } else if (Character.isDigit(c)) {
                    numberCharCount++;
                }
                validCharCount++;
            } else if (Character.isISOControl(c)) {
                // 控制字符（乱码特征）
                suspiciousCharCount++;
            } else if (!Character.isWhitespace(c) && !Character.isLetterOrDigit(c)) {
                // 标点符号
                punctuationCount++;
            }
        }

        // 3. 计算乱码比例
        double validRatio = (double) validCharCount / totalChars;
        double suspiciousRatio = (double) suspiciousCharCount / totalChars;
        
        // 4. 判断是否为有效文本
        if (validRatio < 0.6) {
            log.warn("JD 内容质量过低，有效字符比例：{:.2f}%", validRatio * 100);
            throw new BusinessException(ErrorCode.BAD_REQUEST, 
                "检测到 JD 内容可能包含乱码或无效字符，请输入有效的岗位描述文本");
        }

        if (suspiciousRatio > 0.3) {
            log.warn("JD 内容包含过多控制字符，比例：{:.2f}%", suspiciousRatio * 100);
            throw new BusinessException(ErrorCode.BAD_REQUEST, 
                "JD 内容包含过多不可见字符，请清理后重新输入");
        }

        // 5. 检查是否包含基本的 JD 结构
        boolean hasChinese = chineseCharCount > 0;
        boolean hasEnglish = englishCharCount > 0;
        boolean hasNumbers = numberCharCount > 0;
        
        // 如果完全没有中文、英文或数字，可能是乱码
        if (!hasChinese && !hasEnglish && !hasNumbers) {
            log.warn("JD 内容不包含任何有效字符");
            throw new BusinessException(ErrorCode.BAD_REQUEST, 
                "JD 内容不包含有效文字，请输入有效的岗位描述");
        }

        log.info("JD 内容质量校验通过：总字符={}, 有效字符={:.2f}%, 中文={}, 英文={}, 数字={}",
            totalChars, validRatio * 100, chineseCharCount, englishCharCount, numberCharCount);
    }

    /**
     * 构建用户提示词
     */
    private String buildUserPrompt(JdAnalysisRequest request) {
        StringBuilder prompt = new StringBuilder();
        
        prompt.append("公司名称：%s\n".formatted(request.getCompanyName() != null ? request.getCompanyName() : "未提供"));
        prompt.append("岗位名称：%s\n\n".formatted(request.getPosition()));
        prompt.append("【岗位 JD】\n%s\n\n".formatted(request.getJdText()));

        if (request.isEnableMatchAnalysis() && request.getResumeText() != null) {
            prompt.append("\n【候选人简历】\n%s\n\n".formatted(request.getResumeText()));
            prompt.append("请结合以上简历信息，进行人岗匹配分析，并在返回结果中包含 matchScore（匹配分数 0-100）和 matchAnalysis（匹配分析文字说明）字段。\n");
        }

        prompt.append("\n请对该岗位进行全面分析，返回结构化的 JSON 结果。");

        return prompt.toString();
    }

    /**
     * 解析 AI 返回的分析结果，增强容错能力
     */
    private JdAnalysisResponse parseAnalysisResult(String content) {
        try {
            // 提取JSON内容（支持多种格式）
            String jsonContent = extractJsonContent(content);
            
            // 如果提取失败，尝试直接解析原始内容
            if (jsonContent == null || jsonContent.isEmpty()) {
                jsonContent = content;
            }
            
            // 尝试解析
            return objectMapper.readValue(jsonContent, JdAnalysisResponse.class);
            
        } catch (Exception e) {
            log.warn("首次JSON解析失败，尝试修复并重试", e);
            
            // 第二次尝试：尝试修复常见的JSON格式问题
            try {
                String repairedJson = repairMalformedJson(content);
                return objectMapper.readValue(repairedJson, JdAnalysisResponse.class);
            } catch (Exception ex) {
                log.error("JSON解析失败，返回默认值", ex);
                throw new RuntimeException("无法解析AI返回结果，请稍后重试");
            }
        }
    }
    
    /**
     * 提取JSON内容，支持多种标记格式
     */
    private String extractJsonContent(String content) {
        if (content == null) return null;
        
        String text = content.trim();
        
        // 查找第一个{的位置
        int start = text.indexOf('{');
        if (start < 0) return null;
        
        // 查找最后一个}
        int end = findLastMatchingBrace(text, start);
        if (end < 0) return null;
        
        return text.substring(start, end + 1);
    }
    
    /**
     * 找到最后一个匹配的大括号位置
     */
    private int findLastMatchingBrace(String str, int startIndex) {
        int braceCount = 0;
        for (int i = startIndex; i < str.length(); i++) {
            if (str.charAt(i) == '{') {
                braceCount++;
            } else if (str.charAt(i) == '}') {
                braceCount--;
                if (braceCount == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * 修复损坏的JSON字符串
     */
    private String repairMalformedJson(String json) {
        // 移除注释
        json = json.replaceAll("//.*?$", "").replaceAll("/\\*.*?\\*/", "");
        
        // 修复未闭合的引号
        json = json.replace("'", "\"");
        
        // 移除末尾的逗号
        json = json.replaceAll(",(?=\\s*[}\\]])", "");
        
        // 查找最外层的JSON对象
        int start = json.indexOf('{');
        if (start >= 0) {
            int end = findLastMatchingBrace(json, start);
            if (end > start) {
                json = json.substring(start, end + 1);
            }
        }
        
        return json;
    }

    /**
     * 找到匹配的右大括号位置
     */
    private int findClosingBrace(String str, int startIndex) {
        int braceCount = 0;
        for (int i = startIndex; i < str.length(); i++) {
            if (str.charAt(i) == '{') {
                braceCount++;
            } else if (str.charAt(i) == '}') {
                braceCount--;
                if (braceCount == 0) {
                    return i;
                }
            }
        }
        return str.length() - 1;
    }

    /**
     * 提取匹配分析
     */
    private String extractMatchAnalysis(String content) {
        // 从完整分析中提取匹配相关的部分
        return "请查看详细的分析报告中的匹配度说明";
    }
}
