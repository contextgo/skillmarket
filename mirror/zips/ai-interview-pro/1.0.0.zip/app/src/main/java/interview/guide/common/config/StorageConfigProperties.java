package interview.guide.common.config;

import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * RustFS (S3 兼容) 存储配置属性
 */
@Slf4j
@Data
@Component
@ConfigurationProperties(prefix = "app.storage")
public class StorageConfigProperties {

    private String endpoint;
    private String accessKey;
    private String secretKey;
    private String bucket;
    private String region = "us-east-1";

    @PostConstruct
    public void init() {
        log.info("=========================================");
        log.info("存储配置加载:");
        log.info("  Endpoint: {}", endpoint);
        log.info("  AccessKey: {}", accessKey != null ? accessKey.substring(0, Math.min(8, accessKey.length())) + "***" : "null");
        log.info("  SecretKey: {}", secretKey != null ? secretKey.substring(0, Math.min(8, secretKey.length())) + "***" : "null");
        log.info("  Bucket: {}", bucket);
        log.info("  Region: {}", region);
        log.info("=========================================");
    }
}
