package interview.guide.modules.user.service;

import interview.guide.modules.user.dto.CreateUserRequest;
import interview.guide.modules.user.dto.LoginRequest;
import interview.guide.modules.user.dto.LoginResponse;
import interview.guide.modules.user.dto.RegisterRequest;
import interview.guide.modules.user.entity.User;
import interview.guide.modules.user.repository.UserRepository;
import interview.guide.modules.user.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

/**
 * 认证服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;
    private final UserDetailsService userDetailsService;
    private final UserRepository userRepository;
    private final interview.guide.modules.user.repository.RoleRepository roleRepository;
    private final org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    /**
     * 用户登录
     */
    public LoginResponse login(LoginRequest request) {
        log.info("用户登录：{}", request.getUsername());
        log.info("输入的密码：{}", request.getPassword());
        log.info("密码长度：{}", request.getPassword() != null ? request.getPassword().length() : 0);
        
        // 认证
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getUsername(),
                request.getPassword()
            )
        );
        
        // 设置安全上下文
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        // 加载用户详情
        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
        
        // 生成 JWT Token
        String token = jwtTokenProvider.generateToken(userDetails);
        
        // 获取用户信息
        User user = userRepository.findByUsername(request.getUsername()).orElseThrow();
        
        // 构建响应
        var roles = user.getRoles().stream()
            .map(role -> role.getName())
            .collect(Collectors.toList());
            
        var permissions = user.getRoles().stream()
            .flatMap(role -> role.getPermissions().stream())
            .map(permission -> permission.getName())
            .collect(Collectors.toList());
        
        var userInfo = new LoginResponse.UserInfo(
            user.getId(),
            user.getUsername(),
            user.getEmail(),
            user.getAvatarUrl(),
            roles,
            permissions
        );
        
        return new LoginResponse(
            token,
            "Bearer",
            86400000L, // 24 小时
            userInfo
        );
    }

    /**
     * 用户注册
     */
    @org.springframework.transaction.annotation.Transactional
    public LoginResponse register(RegisterRequest request) {
        log.info("用户注册：{}", request.getUsername());
        
        // 检查用户名是否已存在
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("用户名已存在");
        }
        
        // 检查手机号是否已存在
        if (userRepository.existsByPhone(request.getPhone())) {
            throw new RuntimeException("手机号已被使用");
        }
        
        // 创建用户
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setPhone(request.getPhone());
        user.setEmail(request.getEmail());
        user.setStatus(User.UserStatus.ACTIVE);
        
        // 分配普通用户角色
        var userRole = roleRepository.findByName("ROLE_USER")
            .orElseThrow(() -> new RuntimeException("未找到角色：ROLE_USER"));
        user.getRoles().add(userRole);
        
        User savedUser = userRepository.save(user);
        log.info("用户注册成功：{}", savedUser.getUsername());
        
        // 自动生成 Token 并返回（自动登录）
        UserDetails userDetails = userDetailsService.loadUserByUsername(savedUser.getUsername());
        String token = jwtTokenProvider.generateToken(userDetails);
        
        var roles = savedUser.getRoles().stream()
            .map(role -> role.getName())
            .collect(Collectors.toList());
            
        var permissions = savedUser.getRoles().stream()
            .flatMap(role -> role.getPermissions().stream())
            .map(permission -> permission.getName())
            .collect(Collectors.toList());
        
        var userInfo = new LoginResponse.UserInfo(
            savedUser.getId(),
            savedUser.getUsername(),
            savedUser.getEmail(),
            savedUser.getAvatarUrl(),
            roles,
            permissions
        );
        
        return new LoginResponse(
            token,
            "Bearer",
            86400000L,
            userInfo
        );
    }

    /**
     * 用户登出（客户端删除 Token 即可，服务端可记录黑名单）
     */
    public void logout() {
        SecurityContextHolder.clearContext();
        log.info("用户登出");
    }
}
