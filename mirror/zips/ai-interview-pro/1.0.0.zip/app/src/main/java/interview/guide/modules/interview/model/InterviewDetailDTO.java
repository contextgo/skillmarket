package interview.guide.modules.interview.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 面试详情DTO
 */
public record InterviewDetailDTO(
    Long id,
    String sessionId,
    Integer totalQuestions,
    String status,
    String evaluateStatus,
    String evaluateError,
    Integer overallScore,
    String overallFeedback,
    LocalDateTime createdAt,
    LocalDateTime completedAt,
    List<Object> questions,
    List<String> strengths,
    List<String> improvements,
    List<Object> referenceAnswers,
    List<AnswerDetailDTO> answers,
    Boolean enableMultiDimension,  // 是否开启了多维度评估
    Map<String, Object> multiDimensionReport
) {
    /**
     * 答案详情 DTO
     */
    public record AnswerDetailDTO(
        Integer questionIndex,
        String question,
        String category,
        String userAnswer,
        Integer score,
        String feedback,
        DimensionScore technicalExpert,  // 技术专家维度
        DimensionScore hrManager,        // HR 经理维度
        DimensionScore architect,        // 架构师维度
        String referenceAnswer,
        List<String> keyPoints,
        LocalDateTime answeredAt
    ) {
        /**
         * 单维度评分
         */
        public record DimensionScore(
            int score,
            String feedback
        ) {}
    }
}

