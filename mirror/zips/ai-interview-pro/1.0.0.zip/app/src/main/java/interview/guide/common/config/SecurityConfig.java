package interview.guide.common.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfigurationSource;

import jakarta.servlet.DispatcherType;

/**
 * Spring Security 配置
 * 用于放行 API 接口，允许跨域访问
 */
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final CorsConfigurationSource corsConfigurationSource;
    private final interview.guide.modules.user.security.JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // 禁用 CSRF（API 不需要）
                .csrf(csrf -> csrf.disable())

                // 配置 CORS
                .cors(cors -> cors.configurationSource(corsConfigurationSource))

                // 配置授权规则
                .authorizeHttpRequests(auth -> auth
                        // 放行 ASYNC 分发类型的请求（关键修复：避免异步请求重复鉴权）
                        .dispatcherTypeMatchers(DispatcherType.ASYNC).permitAll()
                        
                        // 公开接口 - 无需认证
                        .requestMatchers(
                            "/api/auth/**",           // 认证相关接口
                            "/api/public/**"          // 公开接口
                        ).permitAll()
                        
                        // Swagger UI 和 API 文档
                        .requestMatchers(
                            "/swagger-ui/**",
                            "/swagger-ui.html",
                            "/v3/api-docs/**",
                            "/swagger-resources/**"
                        ).permitAll()
                        
                        // Actuator 健康检查
                        .requestMatchers(
                            "/actuator/**",
                            "/actuator/health"
                        ).permitAll()
                        
                        // 静态资源
                        .requestMatchers(
                            "/favicon.ico",
                            "/**/*.png",
                            "/**/*.gif",
                            "/**/*.svg",
                            "/**/*.jpg",
                            "/**/*.html",
                            "/**/*.css",
                            "/**/*.js"
                        ).permitAll()
                        
                        // 管理员专用接口
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        
                        // 其他所有 API 需要认证
                        .requestMatchers("/api/**").authenticated()
                        
                        // 其他所有请求需要认证
                        .anyRequest().authenticated()
                )

                // 禁用 Session（使用 JWT，无状态）
                .sessionManagement(session -> 
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                
                // 禁用 HTTP Basic
                .httpBasic(basic -> basic.disable())
                
                // 添加 JWT 过滤器
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}

