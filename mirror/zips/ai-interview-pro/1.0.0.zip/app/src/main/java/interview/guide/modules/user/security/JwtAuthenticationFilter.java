package interview.guide.modules.user.security;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * JWT 认证过滤器
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtTokenProvider jwtTokenProvider;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, 
                                    HttpServletResponse response, 
                                    FilterChain filterChain) throws ServletException, IOException {
        String requestURI = request.getRequestURI();
        log.debug("处理请求：{} {}", request.getMethod(), requestURI);
        
        // 关键修复：异步请求直接放行，无需处理 token，避免 SecurityContext 丢失导致的重复鉴权
        if (DispatcherType.ASYNC.equals(request.getDispatcherType())) {
            log.debug("ASYNC 分发类型，快速放行：{}", requestURI);
            filterChain.doFilter(request, response);
            return;
        }
        
        try {
            String jwt = getJwtFromRequest(request);
            
            if (StringUtils.hasText(jwt)) {
                log.debug("从请求中提取到 JWT Token，前 20 个字符：{}", jwt.substring(0, Math.min(20, jwt.length())));
                try {
                    String username = jwtTokenProvider.getUsernameFromToken(jwt);
                    
                    if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                        
                        if (jwtTokenProvider.validateToken(jwt, userDetails)) {
                            UsernamePasswordAuthenticationToken authentication = 
                                new UsernamePasswordAuthenticationToken(
                                    userDetails,
                                    null,
                                    userDetails.getAuthorities()
                                );
                            
                            authentication.setDetails(
                                new WebAuthenticationDetailsSource().buildDetails(request)
                            );
                            
                            SecurityContextHolder.getContext().setAuthentication(authentication);
                            log.debug("设置安全上下文的认证用户：{}, 请求路径：{}", username, requestURI);
                        } else {
                            log.warn("JWT Token 验证失败，用户：{}", username);
                        }
                    }
                } catch (ExpiredJwtException e) {
                    log.warn("JWT Token 已过期");
                } catch (MalformedJwtException e) {
                    log.warn("无效的 JWT Token");
                } catch (Exception e) {
                    log.error("JWT 验证失败", e);
                }
            } else {
                log.debug("请求中未提取到 JWT Token，请求路径：{}", requestURI);
            }
        } catch (Exception ex) {
            log.error("无法设置用户认证信息，请求路径：{}", requestURI, ex);
        }
        
        filterChain.doFilter(request, response);
    }

    /**
     * 从请求中提取 JWT Token
     */
    private String getJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        
        return null;
    }
}
