package interview.guide.common.config;

import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import java.io.File;
import java.util.Properties;

/**
 * .env 文件加载器 - 在 Spring Boot 启动最早期加载环境变量
 */
public class EnvFileApplicationContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    private final PropertiesPropertySourceLoader loader = new PropertiesPropertySourceLoader();

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        loadEnvFile(applicationContext.getEnvironment());
    }

    private void loadEnvFile(org.springframework.core.env.ConfigurableEnvironment environment) {
        try {
            // 尝试加载项目根目录的 .env 文件
            String userDir = System.getProperty("user.dir");
            File envFile = new File(userDir, ".env");

            // 如果当前目录找不到，尝试上一级目录（适用于从 app 子目录启动的情况）
            if (!envFile.exists()) {
                File parentDir = new File(userDir).getParentFile();
                if (parentDir != null) {
                    envFile = new File(parentDir, ".env");
                }
            }

            if (envFile.exists()) {
                Resource resource = new FileSystemResource(envFile);
                var propertySources = loader.load(".env", resource);

                // 合并所有属性到一个 Properties 对象
                Properties props = new Properties();
                for (var propertySource : propertySources) {
                    var source = propertySource.getSource();
                    if (source instanceof Properties) {
                        props.putAll((Properties) source);
                    }
                }

                // 1. 添加到 Spring 环境的最前面（高优先级）
                environment.getPropertySources().addFirst(new PropertiesPropertySource("env-file", props));

                // 2. 同时设置为系统属性（供 Spring AI 等框架使用）
                for (String key : props.stringPropertyNames()) {
                    String value = props.getProperty(key);
                    if (System.getProperty(key) == null && System.getenv(key) == null) {
                        System.setProperty(key, value);
                    }
                }
                
                // 3. 特别处理：为 Spring AI 设置 spring.ai.openai.api-key 系统属性
                String apiKey = props.getProperty("AI_BAILIAN_API_KEY");
                if (apiKey != null && !apiKey.trim().isEmpty()) {
                    System.setProperty("spring.ai.openai.api-key", apiKey);
                    System.out.println("✅ 已设置 spring.ai.openai.api-key=" + apiKey.substring(0, Math.min(15, apiKey.length())) + "...");
                }

                System.out.println("✅ 已加载 .env 配置文件：" + envFile.getAbsolutePath());
            } else {
                System.out.println("⚠️  未找到 .env 文件，将使用 application.yml 中的默认配置");
            }
        } catch (Exception e) {
            System.err.println("❌ 加载 .env 文件失败：" + e.getMessage());
            e.printStackTrace();
        }
    }
}
