package interview.guide.modules.interview;

import interview.guide.common.annotation.RateLimit;
import interview.guide.common.exception.BusinessException;
import interview.guide.common.exception.ErrorCode;
import interview.guide.common.result.Result;
import interview.guide.modules.interview.model.*;
import interview.guide.modules.interview.service.InterviewHistoryService;
import interview.guide.modules.interview.service.InterviewPersistenceService;
import interview.guide.modules.interview.service.InterviewSessionService;
import interview.guide.modules.interview.service.MultiDimensionEvaluationService;
import interview.guide.modules.interview.model.dto.MultiDimensionEvaluationReport;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 面试控制器
 * 提供模拟面试相关的API接口
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class InterviewController {
    
    private final InterviewSessionService sessionService;
    private final InterviewHistoryService historyService;
    private final InterviewPersistenceService persistenceService;
    private final MultiDimensionEvaluationService multiDimensionEvaluationService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * 创建面试会话
     */
    @PostMapping("/api/interview/sessions")
    @RateLimit(dimensions = {RateLimit.Dimension.GLOBAL, RateLimit.Dimension.IP}, count = 5)
    public Result<InterviewSessionDTO> createSession(@RequestBody CreateInterviewRequest request) {
        log.info("创建面试会话，题目数量: {}", request.questionCount());
        InterviewSessionDTO session = sessionService.createSession(request);
        return Result.success(session);
    }
    
    /**
     * 获取会话信息
     */
    @GetMapping("/api/interview/sessions/{sessionId}")
    public Result<InterviewSessionDTO> getSession(@PathVariable String sessionId) {
        InterviewSessionDTO session = sessionService.getSession(sessionId);
        return Result.success(session);
    }
    
    /**
     * 获取当前问题
     */
    @GetMapping("/api/interview/sessions/{sessionId}/question")
    public Result<Map<String, Object>> getCurrentQuestion(@PathVariable String sessionId) {
        return Result.success(sessionService.getCurrentQuestionResponse(sessionId));
    }
    
    /**
     * 提交答案
     */
    @PostMapping("/api/interview/sessions/{sessionId}/answers")
    @RateLimit(dimensions = {RateLimit.Dimension.GLOBAL}, count = 10)
    public Result<SubmitAnswerResponse> submitAnswer(
            @PathVariable String sessionId,
            @RequestBody Map<String, Object> body) {
        Integer questionIndex = (Integer) body.get("questionIndex");
        String answer = (String) body.get("answer");
        log.info("提交答案: 会话{}, 问题{}", sessionId, questionIndex);
        SubmitAnswerRequest request = new SubmitAnswerRequest(sessionId, questionIndex, answer);
        SubmitAnswerResponse response = sessionService.submitAnswer(request);
        return Result.success(response);
    }
    
    /**
     * 生成面试报告
     */
    @GetMapping("/api/interview/sessions/{sessionId}/report")
    public Result<InterviewReportDTO> getReport(@PathVariable String sessionId) {
        log.info("生成面试报告: {}", sessionId);
        InterviewReportDTO report = sessionService.generateReport(sessionId);
        return Result.success(report);
    }
    
    /**
     * 查找未完成的面试会话
     * GET /api/interview/sessions/unfinished/{resumeId}
     */
    @GetMapping("/api/interview/sessions/unfinished/{resumeId}")
    public Result<InterviewSessionDTO> findUnfinishedSession(@PathVariable Long resumeId) {
        return Result.success(sessionService.findUnfinishedSessionOrThrow(resumeId));
    }
    
    /**
     * 暂存答案（不进入下一题）
     */
    @PutMapping("/api/interview/sessions/{sessionId}/answers")
    public Result<Void> saveAnswer(
            @PathVariable String sessionId,
            @RequestBody Map<String, Object> body) {
        Integer questionIndex = (Integer) body.get("questionIndex");
        String answer = (String) body.get("answer");
        log.info("暂存答案: 会话{}, 问题{}", sessionId, questionIndex);
        SubmitAnswerRequest request = new SubmitAnswerRequest(sessionId, questionIndex, answer);
        sessionService.saveAnswer(request);
        return Result.success(null);
    }
    
    /**
     * 提前交卷
     */
    @PostMapping("/api/interview/sessions/{sessionId}/complete")
    public Result<Void> completeInterview(@PathVariable String sessionId, @RequestBody(required = false) Map<String, Object> body) {
        log.info("提前交卷：{}", sessionId);
        sessionService.completeInterview(sessionId, true);
            
        // 异步触发多维度评估
        try {
            InterviewSessionEntity session = persistenceService.findBySessionId(sessionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.INTERVIEW_SESSION_NOT_FOUND, "面试会话不存在"));
                
            String resumeText = session.getResume().getResumeText();
            String resumeSummary = resumeText.length() > 500 
                ? resumeText.substring(0, 500) + "..." 
                : resumeText;
                
            List<InterviewQuestionDTO> questions = objectMapper.readValue(
                session.getQuestionsJson(),
                new TypeReference<>() {}
            );
                
            // 从请求体中获取是否开启多维度评估的选项，默认为 true
            boolean enableMultiDimension = true;
            if (body != null && body.containsKey("enableMultiDimension")) {
                enableMultiDimension = Boolean.parseBoolean(body.get("enableMultiDimension").toString());
            }
                
            historyService.reevaluateInterview(sessionId, resumeSummary, questions, enableMultiDimension);
            log.info("已触发多维度评估：{}, enableMultiDimension={}", sessionId, enableMultiDimension);
        } catch (Exception e) {
            log.error("触发多维度评估失败：{}", sessionId, e);
        }
            
        return Result.success(null);
    }
    
    /**
     * 获取面试会话详情
     * GET /api/interview/sessions/{sessionId}/details
     */
    @GetMapping("/api/interview/sessions/{sessionId}/details")
    public Result<InterviewDetailDTO> getInterviewDetail(@PathVariable String sessionId) {
        InterviewDetailDTO detail = historyService.getInterviewDetail(sessionId);
        return Result.success(detail);
    }
    
    /**
     * 导出面试报告为PDF
     */
    @GetMapping("/api/interview/sessions/{sessionId}/export")
    public ResponseEntity<byte[]> exportInterviewPdf(@PathVariable String sessionId) {
        try {
            byte[] pdfBytes = historyService.exportInterviewPdf(sessionId);
            String filename = URLEncoder.encode("模拟面试报告_" + sessionId + ".pdf", 
                StandardCharsets.UTF_8);
            
            return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename*=UTF-8''" + filename)
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
        } catch (Exception e) {
            log.error("导出PDF失败", e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * 删除面试会话
     */
    @DeleteMapping("/api/interview/sessions/{sessionId}")
    public Result<Void> deleteInterview(@PathVariable String sessionId) {
        log.info("删除面试会话：{}", sessionId);
        persistenceService.deleteSessionBySessionId(sessionId);
        return Result.success(null);
    }
    
    /**
     * 获取多维度评估报告（360 度评估）
     * GET /api/interview/sessions/{sessionId}/multi-dimension-report
     */
    @GetMapping("/api/interview/sessions/{sessionId}/multi-dimension-report")
    public Result<MultiDimensionEvaluationReport> getMultiDimensionReport(@PathVariable String sessionId) {
        log.info("获取多维度评估报告：{}", sessionId);
        
        try {
            // 从数据库获取面试数据
            InterviewSessionEntity session = persistenceService.findBySessionId(sessionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.INTERVIEW_SESSION_NOT_FOUND, "面试会话不存在"));
            
            // 获取简历文本
            String resumeText = session.getResume().getResumeText();
            String resumeSummary = resumeText.length() > 500 
                ? resumeText.substring(0, 500) + "..." 
                : resumeText;
            
            // 获取问题列表
            List<InterviewQuestionDTO> questions = objectMapper.readValue(
                session.getQuestionsJson(),
                new TypeReference<>() {}
            );
            
            // 执行多维度评估
            MultiDimensionEvaluationReport report = multiDimensionEvaluationService.evaluateMultiDimension(
                sessionId, resumeSummary, questions);
            
            return Result.success(report);
            
        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("获取多维度评估报告失败：{}", sessionId, e);
            return Result.error("获取评估报告失败：" + e.getMessage());
        }
    }
    
    /**
     * 重新评估面试
     * POST /api/interview/sessions/{sessionId}/reevaluate
     */
    @PostMapping("/api/interview/sessions/{sessionId}/reevaluate")
    public Result<Void> reevaluateInterview(@PathVariable String sessionId, @RequestBody(required = false) Map<String, Object> body) {
        log.info("重新评估面试：{}", sessionId);
        
        try {
            // 从数据库获取面试数据
            InterviewSessionEntity session = persistenceService.findBySessionId(sessionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.INTERVIEW_SESSION_NOT_FOUND, "面试会话不存在"));
            
            // 获取简历文本
            String resumeText = session.getResume().getResumeText();
            String resumeSummary = resumeText.length() > 500 
                ? resumeText.substring(0, 500) + "..." 
                : resumeText;
            
            // 获取问题列表
            List<InterviewQuestionDTO> questions = objectMapper.readValue(
                session.getQuestionsJson(),
                new TypeReference<>() {}
            );
            
            // 从请求体中获取是否开启多维度评估的选项，默认为 true
            boolean enableMultiDimension = true;
            if (body != null && body.containsKey("enableMultiDimension")) {
                enableMultiDimension = Boolean.parseBoolean(body.get("enableMultiDimension").toString());
            }
            
            // 异步执行多维度评估（通过 Redis Stream）
            historyService.reevaluateInterview(sessionId, resumeSummary, questions, enableMultiDimension);
            
            return Result.success(null);
            
        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("重新评估面试失败：{}", sessionId, e);
            return Result.error("重新评估失败：" + e.getMessage());
        }
    }
}