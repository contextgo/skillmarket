package interview.guide;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * AI Interview Platform - Main Application
 * 智能 AI 面试官平台 - 主启动类
 */
@Slf4j
@SpringBootApplication
public class App {

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
        printSuccessBanner();
    }

    /**
     * 打印启动成功的 ASCII 艺术画
     */
    private static void printSuccessBanner() {
        log.info("""
                
                ╔═══════════════════════════════════════════════════════════╗
                ║                                                           ║
                ║   🎉  AI Interview Platform Started Successfully!         ║
                ║       智能 AI 面试官平台启动成功！                            ║
                ║                                                           ║
                ║   🌐 Frontend:  http://localhost:5173                     ║
                ║   🔧 Backend:   http://localhost:8080                     ║
                ║   📦 MinIO:     http://localhost:9001                     ║
                ║   🗄️  PostgreSQL: localhost:5432                          ║
                ║   💾 Redis:      localhost:6379                           ║
                ║                                                           ║
                ║   Happy Coding! 💻                                        ║
                ║                                                           ║
                ╚═══════════════════════════════════════════════════════════╝
                """);
    }
}
