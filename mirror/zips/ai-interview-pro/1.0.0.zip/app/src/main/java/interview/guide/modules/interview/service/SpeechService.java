package interview.guide.modules.interview.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * 语音服务接口
 */
public interface SpeechService {

    /**
     * 语音识别 - 将音频转换为文字
     * @param audioFile 音频文件
     * @return 识别的文字内容
     */
    String recognizeSpeech(MultipartFile audioFile);

    /**
     * 语音合成 - 将文字转换为语音
     * @param text 文字内容
     * @return 音频数据（OGG 格式）
     */
    byte[] synthesizeSpeech(String text);
}
