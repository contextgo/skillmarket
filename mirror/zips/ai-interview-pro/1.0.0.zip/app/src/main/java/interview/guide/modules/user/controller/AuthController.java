package interview.guide.modules.user.controller;

import interview.guide.common.result.Result;
import interview.guide.modules.user.dto.LoginRequest;
import interview.guide.modules.user.dto.LoginResponse;
import interview.guide.modules.user.dto.RegisterRequest;
import interview.guide.modules.user.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * 认证控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {

    private final AuthService authService;

    /**
     * 用户登录
     */
    @PostMapping("/login")
    public Result<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        try {
            log.info("收到登录请求，用户名：{}", request.getUsername());
            LoginResponse response = authService.login(request);
            log.info("用户 {} 登录成功", request.getUsername());
            return Result.success(response);
        } catch (org.springframework.security.authentication.BadCredentialsException e) {
            log.error("登录失败：用户名或密码错误", e);
            return Result.error("用户名或密码错误");
        } catch (org.springframework.security.core.userdetails.UsernameNotFoundException e) {
            log.error("登录失败：用户不存在", e);
            return Result.error("用户不存在");
        } catch (Exception e) {
            log.error("登录失败，异常类型：{}, 消息：{}", e.getClass().getName(), e.getMessage(), e);
            return Result.error("登录失败：" + e.getMessage());
        }
    }

    /**
     * 用户注册
     */
    @PostMapping("/register")
    public Result<LoginResponse> register(@Valid @RequestBody RegisterRequest request) {
        try {
            LoginResponse response = authService.register(request);
            return Result.success(response);
        } catch (Exception e) {
            log.error("注册失败", e);
            return Result.error(e.getMessage());
        }
    }

    /**
     * 用户登出
     */
    @PostMapping("/logout")
    public Result<Void> logout() {
        authService.logout();
        return Result.success(null);
    }

    /**
     * 获取当前登录用户信息
     */
    @GetMapping("/me")
    public Result<LoginResponse.UserInfo> getCurrentUser() {
        // TODO: 从 SecurityContext 获取当前用户
        return Result.success(null);
    }
}
