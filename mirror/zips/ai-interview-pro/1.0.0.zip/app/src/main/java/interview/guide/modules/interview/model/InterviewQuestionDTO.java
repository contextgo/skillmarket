package interview.guide.modules.interview.model;

import tools.jackson.databind.annotation.JsonSerialize;

/**
 * 面试问题 DTO
 */
public record InterviewQuestionDTO(
    int questionIndex,
    String question,
    QuestionType type,
    String category,      // 问题类别：项目经历、Java 基础、集合、并发、MySQL、Redis、Spring、SpringBoot
    String userAnswer,    // 用户回答
    Integer score,        // 单题得分 (0-100)
    String feedback,      // 单题反馈
    DimensionScore technicalExpert,  // 技术专家维度评分
    DimensionScore hrManager,        // HR 经理维度评分
    DimensionScore architect,        // 架构师维度评分
    boolean isFollowUp,   // 是否为追问
    Integer parentQuestionIndex // 追问关联的主问题索引
) {
    
    /**
     * 单维度评分
     */
    public record DimensionScore(
        int score,
        String feedback
    ) {}
    public enum QuestionType {
        PROJECT,          // 项目经历
        JAVA_BASIC,       // Java基础
        JAVA_COLLECTION,  // Java集合
        JAVA_CONCURRENT,  // Java并发
        MYSQL,            // MySQL
        REDIS,            // Redis
        SPRING,           // Spring
        SPRING_BOOT       // Spring Boot
    }
    
    /**
     * 创建新问题（未回答状态）
     */
    public static InterviewQuestionDTO create(int index, String question, QuestionType type, String category) {
        return new InterviewQuestionDTO(index, question, type, category, null, null, null, null, null, null, false, null);
    }

    /**
     * 创建新问题（支持追问标记）
     */
    public static InterviewQuestionDTO create(
            int index,
            String question,
            QuestionType type,
            String category,
            boolean isFollowUp,
            Integer parentQuestionIndex) {
        return new InterviewQuestionDTO(index, question, type, category, null, null, null, null, null, null, isFollowUp, parentQuestionIndex);
    }
    
    /**
     * 添加用户回答
     */
    public InterviewQuestionDTO withAnswer(String answer) {
        return new InterviewQuestionDTO(
            questionIndex, question, type, category, answer, score, feedback, null, null, null, isFollowUp, parentQuestionIndex);
    }
    
    /**
     * 添加评分和反馈（包括三个维度的评分）
     */
    public InterviewQuestionDTO withEvaluation(
            int score, 
            String feedback,
            DimensionScore technicalExpert,
            DimensionScore hrManager,
            DimensionScore architect) {
        return new InterviewQuestionDTO(
            questionIndex, question, type, category, userAnswer, score, feedback, 
            technicalExpert, hrManager, architect, isFollowUp, parentQuestionIndex);
    }
    
    /**
     * 添加完整的评估结果（包括分数、反馈、参考答案、关键点）
     */
    public InterviewQuestionDTO withScoreAndFeedback(
            int score, 
            String feedback, 
            String referenceAnswer,
            java.util.List<String> keyPoints) {
        // 注意：当前 record 没有 referenceAnswer 和 keyPoints 字段，需要扩展 record
        // 临时方案：只更新 score 和 feedback
        return new InterviewQuestionDTO(
            questionIndex, question, type, category, userAnswer, score, feedback, null, null, null, isFollowUp, parentQuestionIndex);
    }
}
