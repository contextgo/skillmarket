package interview.guide.modules.interview.service.impl;

import interview.guide.modules.interview.service.SpeechService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * 语音服务实现类
 * 集成阿里云百炼平台的语音识别（STT）和语音合成（TTS）能力
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SpeechServiceImpl implements SpeechService {

    @Value("${ai.bailian.api-key:}")
    private String apiKey;

    /**
     * 语音识别 - 使用阿里云智能语音交互（HTTP API 方式）
     */
    @Override
    public String recognizeSpeech(MultipartFile audioFile) {
        try {
            log.info("开始语音识别，文件大小：{} bytes", audioFile.getSize());
            
            // 将音频文件转换为 Base64
            byte[] audioBytes = audioFile.getBytes();
            String audioBase64 = Base64.getEncoder().encodeToString(audioBytes);
            
            // 构建请求体
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> input = new HashMap<>();
            input.put("audio", audioBase64);
            requestBody.put("input", input);
            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("format", "webm");
            parameters.put("model", "paraformer-realtime-8k-v1");
            requestBody.put("parameters", parameters);
            
            // 设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + apiKey);
            headers.set("X-DashScope-WorkSpace", "service-account-default");
            
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            
            // 调用阿里云百炼 API
            RestTemplate restTemplate = new RestTemplate();
            String url = "https://dashscope.aliyuncs.com/api/v1/services/audio/asr/transcription";
            
            String response = restTemplate.postForObject(url, entity, String.class);
            
            if (response != null && response.contains("output")) {
                // 解析响应 JSON（简化处理）
                int start = response.indexOf("\"text\":\"") + 8;
                int end = response.indexOf("\"", start);
                if (start > 7 && end > start) {
                    String recognizedText = response.substring(start, end)
                        .replace("\\n", "\n")
                        .replace("\\u0020", " ");
                    log.info("语音识别成功，识别结果：{}", recognizedText);
                    return recognizedText;
                }
            }
            
            log.warn("API 返回格式异常，使用默认提示文本");
            return "语音识别服务暂时不可用，请稍后重试。";
            
        } catch (Exception e) {
            log.error("语音识别失败", e);
            throw new RuntimeException("语音识别失败：" + e.getMessage(), e);
        }
    }

    /**
     * 语音合成 - 使用阿里云智能语音合成（HTTP API 方式）
     */
    @Override
    public byte[] synthesizeSpeech(String text) {
        try {
            if (text == null || text.trim().isEmpty()) {
                log.warn("合成文本为空");
                return new byte[0];
            }
            
            log.info("开始语音合成，文本长度：{}", text.length());
            
            // 构建请求体
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> input = new HashMap<>();
            input.put("text", text);
            requestBody.put("input", input);
            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("voice", "xiaoyun");
            requestBody.put("parameters", parameters);
            
            // 设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + apiKey);
            headers.set("X-DashScope-WorkSpace", "service-account-default");
            
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            
            // 调用阿里云百炼 API
            RestTemplate restTemplate = new RestTemplate();
            String url = "https://dashscope.aliyuncs.com/api/v1/services/audio/tts/synthesis";
            
            byte[] audioData = restTemplate.postForObject(url, entity, byte[].class);
            
            if (audioData != null && audioData.length > 0) {
                log.info("语音合成成功，音频大小：{} bytes", audioData.length);
                return audioData;
            } else {
                log.warn("API 返回空音频数据");
                return new byte[0];
            }
            
        } catch (Exception e) {
            log.error("语音合成失败", e);
            throw new RuntimeException("语音合成失败：" + e.getMessage(), e);
        }
    }

    /**
     * 保存临时文件
     */
    private File saveTempFile(MultipartFile file) throws Exception {
        File tempFile = File.createTempFile("speech_", ".webm");
        tempFile.deleteOnExit();
        
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(file.getBytes());
        }
        
        log.info("临时文件已保存：{}, 大小：{} bytes", tempFile.getAbsolutePath(), tempFile.length());
        return tempFile;
    }
}
