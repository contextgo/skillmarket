package interview.guide.modules.user.service;

import interview.guide.modules.user.dto.CreateUserRequest;
import interview.guide.modules.user.dto.UserDTO;
import interview.guide.modules.user.entity.Role;
import interview.guide.modules.user.entity.User;
import interview.guide.modules.user.repository.RoleRepository;
import interview.guide.modules.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 用户管理服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * 获取所有用户
     */
    @Transactional(readOnly = true)
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    /**
     * 根据 ID 获取用户
     */
    @Transactional(readOnly = true)
    public UserDTO getUserById(Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("用户不存在：" + id));
        return convertToDTO(user);
    }

    /**
     * 创建用户
     */
    @Transactional
    public UserDTO createUser(CreateUserRequest request) {
        log.info("创建用户：{}", request.getUsername());
        
        // 检查用户名是否已存在
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("用户名已存在：" + request.getUsername());
        }
        
        // 检查邮箱是否已存在
        if (request.getEmail() != null && userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("邮箱已被使用：" + request.getEmail());
        }
        
        // 创建用户
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setAvatarUrl(request.getAvatarUrl());
        user.setStatus(User.UserStatus.ACTIVE);
        
        // 默认分配普通用户角色
        Role userRole = roleRepository.findByName("ROLE_USER")
            .orElseThrow(() -> new RuntimeException("未找到角色：ROLE_USER"));
        user.getRoles().add(userRole);
        
        User savedUser = userRepository.save(user);
        log.info("用户创建成功：{}", savedUser.getUsername());
        
        return convertToDTO(savedUser);
    }

    /**
     * 更新用户状态
     */
    @Transactional
    public UserDTO updateUserStatus(Long id, User.UserStatus status) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("用户不存在：" + id));
        
        user.setStatus(status);
        User updatedUser = userRepository.save(user);
        
        log.info("用户状态更新：{} -> {}", user.getUsername(), status);
        return convertToDTO(updatedUser);
    }

    /**
     * 删除用户
     */
    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("用户不存在：" + id));
        
        userRepository.delete(user);
        log.info("用户删除成功：{}", user.getUsername());
    }

    /**
     * 转换为用户 DTO
     */
    private UserDTO convertToDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setAvatarUrl(user.getAvatarUrl());
        dto.setStatus(user.getStatus().name());
        dto.setLastLoginAt(user.getLastLoginAt());
        dto.setCreatedAt(user.getCreatedAt());
        dto.setUpdatedAt(user.getUpdatedAt());
        
        List<String> roles = user.getRoles().stream()
            .map(Role::getName)
            .collect(Collectors.toList());
        dto.setRoles(roles);
        
        return dto;
    }
}
