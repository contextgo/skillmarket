package interview.guide.modules.jd.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * JD 分析请求 DTO
 */
@Data
public class JdAnalysisRequest {

    /**
     * 公司名称（可选）
     */
    private String companyName;

    /**
     * 岗位名称
     */
    @NotBlank(message = "岗位名称不能为空")
    private String position;

    /**
     * JD 文本内容
     */
    @NotBlank(message = "JD 内容不能为空")
    private String jdText;

    /**
     * 简历文本（可选，用于匹配分析）
     */
    private String resumeText;

    /**
     * 是否进行匹配分析
     */
    private Boolean enableMatchAnalysis = false;

    public boolean isEnableMatchAnalysis() {
        return enableMatchAnalysis != null && enableMatchAnalysis;
    }
}
