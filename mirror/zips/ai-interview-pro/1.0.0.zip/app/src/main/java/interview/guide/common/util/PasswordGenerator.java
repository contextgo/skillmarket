package interview.guide.common.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * 密码生成器 - 用于生成 BCrypt hash
 * 运行方式：在应用启动时会自动执行，生成 admin123 的 hash 并打印到控制台
 */
public class PasswordGenerator implements org.springframework.boot.CommandLineRunner {
    
    @Override
    public void run(String... args) throws Exception {
        PasswordEncoder encoder = new BCryptPasswordEncoder(10);
        String rawPassword = "admin123";
        String hash = encoder.encode(rawPassword);
        
        System.out.println("===========================================");
        System.out.println("生成的 BCrypt Hash:");
        System.out.println("密码：" + rawPassword);
        System.out.println("Hash: " + hash);
        System.out.println("===========================================");
        System.out.println("SQL 更新语句:");
        System.out.println("UPDATE users SET password_hash = '" + hash + "' WHERE username = 'admin';");
        System.out.println("===========================================");
    }
}
