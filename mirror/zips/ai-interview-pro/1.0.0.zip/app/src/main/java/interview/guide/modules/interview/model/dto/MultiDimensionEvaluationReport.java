package interview.guide.modules.interview.model.dto;

import lombok.Data;
import java.util.List;

/**
 * 多维度面试评估报告
 */
@Data
public class MultiDimensionEvaluationReport {
    
    /**
     * 基础信息
     */
    private String sessionId;
    private Integer totalQuestions;
    private Integer overallScore;
    
    /**
     * 技术专家维度
     */
    private Integer technicalScore;
    private String technicalFeedback;
    private String technicalSummary;  // 新增：技术维度总结
    private List<String> technicalStrengths;
    private List<String> technicalWeaknesses;
    private List<String> knowledgeGaps;
    private String depthAnalysis;
    
    /**
     * HR 经理维度
     */
    private Integer hrScore;
    private String hrFeedback;
    private String hrSummary;  // 新增：HR 维度总结
    private List<String> communicationStrengths;
    private List<String> softSkillsGaps;
    private String learningPotential;
    private String cultureFit;
    private String careerAdvice;
    
    /**
     * 架构师维度
     */
    private Integer architectScore;
    private String architectFeedback;
    private String architectSummary;  // 新增：架构师维度总结
    private String systemDesignAbility;
    private String technicalDepth;
    private String engineeringPractice;
    private String innovationPotential;
    private String recommendedLevel;
    
    /**
     * 综合评价
     */
    private String overallFeedback;
    private List<String> strengths;
    private List<String> improvements;
}
