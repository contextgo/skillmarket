package interview.guide.common.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * .env 配置文件加载器
 * 自动加载项目根目录的 .env 文件
 */
@Configuration
public class DotenvConfig {
    
    private static final Logger log = LoggerFactory.getLogger(DotenvConfig.class);

    @Bean
    public PropertySource<?> dotenvPropertySource() {
        Properties props = new Properties();
        
        // 尝试加载项目根目录的 .env 文件
        File dotenvFile = new File(System.getProperty("user.dir"), ".env");
        log.info("正在查找 .env 文件：{}", dotenvFile.getAbsolutePath());
        
        if (dotenvFile.exists()) {
            log.info("找到 .env 文件：{}", dotenvFile.getAbsolutePath());
            try (FileReader reader = new FileReader(dotenvFile)) {
                props.load(reader);
                log.info("成功加载 .env 文件，包含 {} 个配置项", props.size());
                
                // 打印 API Key 的前缀用于调试
                String apiKey = props.getProperty("AI_BAILIAN_API_KEY");
                if (apiKey != null && !apiKey.isEmpty()) {
                    log.info("API Key 已加载：{}...", apiKey.substring(0, Math.min(10, apiKey.length())));
                } else {
                    log.warn("API Key 未找到或为空！");
                }
            } catch (IOException e) {
                log.error("加载 .env 文件失败：{}", e.getMessage());
            }
        } else {
            log.warn(".env 文件不存在：{}", dotenvFile.getAbsolutePath());
        }
        
        // 如果根目录没有，尝试在 app 目录下查找
        if (props.isEmpty()) {
            File appDotenvFile = new File(System.getProperty("user.dir") + "/app", ".env");
            log.info("尝试在 app 目录查找 .env 文件：{}", appDotenvFile.getAbsolutePath());
            
            if (appDotenvFile.exists()) {
                log.info("找到 app/.env 文件：{}", appDotenvFile.getAbsolutePath());
                try (FileReader reader = new FileReader(appDotenvFile)) {
                    props.load(reader);
                    log.info("成功加载 app/.env 文件，包含 {} 个配置项", props.size());
                } catch (IOException e) {
                    log.error("加载 app/.env 文件失败：{}", e.getMessage());
                }
            } else {
                log.warn("app/.env 文件也不存在：{}", appDotenvFile.getAbsolutePath());
            }
        }
        
        if (!props.isEmpty()) {
            Map<String, Object> envMap = new HashMap<>();
            for (String key : props.stringPropertyNames()) {
                envMap.put(key, props.getProperty(key));
            }
            log.info("注册 {} 个环境变量到 Spring Environment", envMap.size());
            return new MapPropertySource("dotenv", envMap);
        }
        
        log.warn("未能加载任何 .env 文件，将使用 application.yml 中的默认值");
        return null;
    }
}
