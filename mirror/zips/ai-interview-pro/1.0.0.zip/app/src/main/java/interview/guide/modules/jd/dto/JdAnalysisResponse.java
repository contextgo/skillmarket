package interview.guide.modules.jd.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * JD 分析响应 DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JdAnalysisResponse {

    private Long id;
    private String companyName;
    private String position;
    private String analysisReport;
    private List<String> keySkills;
    private String salaryRange;
    private String experienceRequirement;
    private String educationRequirement;
    private Double matchScore;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MatchAnalysis {
        private Integer matchScore;
        private List<String> strengths;
        private List<String> weaknesses;
        private List<String> improvementSuggestions;
    }
    
    private MatchAnalysis matchAnalysis;
    
    // 分析报告的详细结构
    private JobDescription jobDescription;
    private RequirementAnalysis requirementAnalysis;
    private SkillAnalysis skillAnalysis;
    private InterviewPreparation interviewPreparation;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class JobDescription {
        private String overview;
        private List<String> responsibilities;
        private String workLocation;
        private String department;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RequirementAnalysis {
        private String experienceYears;
        private String educationLevel;
        private String major;
        private List<String> hardRequirements;
        private List<String> softSkills;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SkillAnalysis {
        private List<String> technicalSkills;
        private List<String> toolSkills;
        private List<String> languageSkills;
        private List<String> recommendedSkills;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InterviewPreparation {
        private List<String> possibleQuestions;
        private List<String> preparationSuggestions;
        private List<String> resumeOptimizationTips;
    }
}
