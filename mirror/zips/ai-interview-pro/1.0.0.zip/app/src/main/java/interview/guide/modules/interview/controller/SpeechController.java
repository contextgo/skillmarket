package interview.guide.modules.interview.controller;

import interview.guide.common.result.Result;
import interview.guide.modules.interview.service.SpeechService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

/**
 * 语音功能控制器
 * 提供语音识别（STT）和语音合成（TTS）功能
 */
@Slf4j
@RestController
@RequestMapping("/api/interview/speech")
@RequiredArgsConstructor
public class SpeechController {

    private final SpeechService speechService;

    /**
     * 语音识别 - 将音频转换为文字
     * POST /api/interview/speech/to-text
     */
    @PostMapping(value = "/to-text", consumes = "multipart/form-data")
    public Result<Map<String, Object>> speechToText(@RequestParam("audio") MultipartFile audioFile) {
        try {
            log.info("接收到语音识别请求，文件大小：{} bytes", audioFile.getSize());
            
            // 调用语音识别服务
            String recognizedText = speechService.recognizeSpeech(audioFile);
            
            Map<String, Object> response = new HashMap<>();
            response.put("text", recognizedText);
            response.put("duration", audioFile.getSize() / 16000.0); // 估算时长
            
            log.info("语音识别成功，识别结果长度：{}", recognizedText.length());
            
            return Result.success(response);
        } catch (Exception e) {
            log.error("语音识别失败", e);
            return Result.error("语音识别失败：" + e.getMessage());
        }
    }

    /**
     * 语音合成 - 将文字转换为语音
     * POST /api/interview/speech/to-speech
     */
    @PostMapping(value = "/to-speech", produces = "audio/ogg")
    public byte[] textToSpeech(@RequestBody Map<String, String> request) {
        try {
            String text = request.get("text");
            log.info("接收到语音合成请求，文本长度：{}", text != null ? text.length() : 0);
            
            // 调用语音合成服务
            byte[] audioData = speechService.synthesizeSpeech(text);
            
            log.info("语音合成成功，音频大小：{} bytes", audioData.length);
            
            return audioData;
        } catch (Exception e) {
            log.error("语音合成失败", e);
            // 返回空音频数据
            return new byte[0];
        }
    }
}
