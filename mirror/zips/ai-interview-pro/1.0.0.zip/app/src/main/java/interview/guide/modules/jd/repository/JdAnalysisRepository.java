package interview.guide.modules.jd.repository;

import interview.guide.modules.jd.model.JdAnalysisEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JD 分析 Repository
 */
@Repository
public interface JdAnalysisRepository extends JpaRepository<JdAnalysisEntity, Long> {

    /**
     * 根据用户 ID 查找所有分析记录
     */
    List<JdAnalysisEntity> findByUserIdOrderByCreatedAtDesc(Long userId);

    /**
     * 根据岗位名称搜索
     */
    List<JdAnalysisEntity> findByPositionContainingOrderByCreatedAtDesc(String position);
}
