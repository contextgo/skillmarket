# AI Interview Platform Skill

## Overview

智能 AI 面试官平台 - 基于大语言模型的简历分析和模拟面试系统。这是一个全栈应用，集成了简历分析、模拟面试和知识库管理功能，利用 Spring AI 2.0、PostgreSQL + pgvector、Redis 和 React 构建。

**技术栈**: Java 21, Spring Boot 4.0, Spring AI 2.0, PostgreSQL + pgvector, Redis, React 18.3, TypeScript, Vite, Tailwind CSS

---

## Project Structure

```
interview-guide/
├── app/                              # 后端应用 (Spring Boot)
│   ├── src/main/java/interview/guide/
│   │   ├── App.java                  # 主启动类
│   │   ├── common/                   # 通用模块
│   │   │   ├── config/               # 配置类
│   │   │   ├── exception/            # 异常处理
│   │   │   └── result/               # 统一响应
│   │   ├── infrastructure/           # 基础设施
│   │   │   ├── export/               # PDF 导出
│   │   │   ├── file/                 # 文件处理
│   │   │   ├── redis/                # Redis 服务
│   │   │   └── storage/              # 对象存储
│   │   └── modules/                  # 业务模块
│   │       ├── interview/            # 面试模块
│   │       ├── jd/                   # 职位描述模块
│   │       ├── knowledgebase/        # 知识库模块
│   │       ├── resume/               # 简历模块
│   │       └── user/                 # 用户模块
│   └── src/main/resources/
│       ├── application.yml           # 应用配置
│       └── prompts/                  # AI 提示词模板
│
├── frontend/                         # 前端应用 (React + TypeScript)
│   ├── src/
│   │   ├── api/                      # API 接口
│   │   ├── components/               # 公共组件
│   │   ├── pages/                    # 页面组件
│   │   ├── types/                    # 类型定义
│   │   └── utils/                    # 工具函数
│   ├── package.json
│   └── vite.config.ts
│
├── docker/                           # Docker 配置文件
├── docker-compose.yml                # Docker Compose 配置
└── README.md
```

---

## Core Features

### 1. Resume Management (简历管理)
- **Multi-format Parsing**: Support for PDF, DOCX, DOC, TXT formats
- **Async Processing**: Redis Stream-based async resume analysis with real-time progress tracking
- **Status Flow**: `PENDING` → `PROCESSING` → `COMPLETED` / `FAILED`
- **Auto-retry**: Built-in failure retry mechanism (max 3 attempts)
- **Duplicate Detection**: Content hash-based duplicate detection
- **PDF Export**: One-click export of AI analysis results to structured PDF reports

### 2. Mock Interview (模拟面试)
- **Personalized Questions**: AI-generated interview questions based on resume content
- **Smart Follow-up**: Configurable multi-round follow-up questions (default: 1)
- **Batch Evaluation**: Innovative batch evaluation strategy to prevent token overflow
- **Summary Reports**: Secondary aggregation of evaluation results with improvement suggestions
- **PDF Export**: Async generation and export of detailed interview assessment reports

### 3. Knowledge Base (知识库管理)
- **Document Processing**: Auto-upload, chunking, and async vectorization of PDF, DOCX, Markdown files
- **RAG Retrieval**: Vector database integration for Retrieval-Augmented Generation
- **Streaming Response**: Server-Sent Events (SSE) based typewriter-style streaming responses
- **Smart Q&A**: Knowledge base-driven intelligent Q&A with statistics

### 4. User Authentication (用户认证)
- JWT-based authentication system
- Secure password hashing
- Session management with Redis

---

## Architecture Patterns

### Async Processing Flow
```
Upload Request → Save File → Send Message to Redis Stream → Return Immediately
                                        ↓
                                Consumer Processes Message
                                        ↓
                            Execute Analysis/Vectorization Task
                                        ↓
                                Update Database Status
                                        ↓
                            Frontend Polls for Latest Status
```

### Technology Stack Decisions

| Component | Choice | Rationale |
|-----------|--------|-----------|
| Database | PostgreSQL + pgvector | Single database for both relational and vector data, simplified architecture |
| Message Queue | Redis Stream | Lightweight alternative to Kafka/RabbitMQ, lower operational overhead |
| Object Storage | MinIO (S3-compatible) | Self-hosted, S3 API compatible, easy to switch to cloud providers |
| Build Tool | Gradle | Modern build tool with better dependency management |
| Frontend Framework | React 18 + TypeScript | Type safety, component reusability, large ecosystem |
| Styling | Tailwind CSS 4 | Utility-first CSS framework, rapid UI development |

---

## Development Setup

### Prerequisites

| Dependency | Version | Required |
|------------|---------|----------|
| JDK | 21+ | Yes |
| Node.js | 18+ | Yes |
| PostgreSQL | 14+ | Yes |
| pgvector extension | - | Yes |
| Redis | 6+ | Yes |
| S3-compatible storage | - | Yes (MinIO recommended) |

### Quick Start with Docker (Recommended)

```bash
# 1. Clone repository
git clone https://github.com/Snailclimb/interview-guide.git
cd interview-guide

# 2. Configure environment variables
cp .env.example .env
# Edit .env and set your AI_BAILIAN_API_KEY

# 3. Start all services
docker-compose up -d --build

# 4. Access services
# Frontend: http://localhost
# Backend API: http://localhost:8080
# MinIO Console: http://localhost:9001 (minioadmin/minioadmin)
```

### Manual Setup

#### Backend Setup

```bash
# 1. Create database
psql -U postgres
CREATE DATABASE interview_guide;
CREATE EXTENSION vector;

# 2. Set environment variables
export AI_BAILIAN_API_KEY=your_api_key

# 3. Configure application.yml
# Edit app/src/main/resources/application.yml with your database credentials

# 4. Run backend
./gradlew bootRun
# Backend starts at http://localhost:8080
```

#### Frontend Setup

```bash
cd frontend
pnpm install
pnpm dev
# Frontend starts at http://localhost:5173
```

### Key Configuration

**application.yml** (Critical Settings):
```yaml
spring:
  datasource:
    url: jdbc:postgresql://${POSTGRES_HOST:localhost}:${POSTGRES_PORT:5432}/${POSTGRES_DB:interview_guide}
    username: ${POSTGRES_USER:postgres}
    password: ${POSTGRES_PASSWORD:123456}
  
  jpa:
    hibernate:
      ddl-auto: create  # First run: create, then change to update
  
  ai:
    vectorstore:
      pgvector:
        initialize-schema: true  # Dev: true, Prod: false

app:
  interview:
    follow-up-count: ${APP_INTERVIEW_FOLLOW_UP_COUNT:1}
    evaluation:
      batch-size: ${APP_INTERVIEW_EVALUATION_BATCH_SIZE:8}
  storage:
    endpoint: ${APP_STORAGE_ENDPOINT:http://localhost:9000}
    access-key: ${APP_STORAGE_ACCESS_KEY:minioadmin}
    secret-key: ${APP_STORAGE_SECRET_KEY:minioadmin}
    bucket: ${APP_STORAGE_BUCKET:interview-guide}
```

---

## Common Issues & Solutions

### Issue 1: Database Tables Not Created / Data Loss
**Problem**: JPA `ddl-auto` configuration issue

**Solution**:
```yaml
# First startup - use 'create' to generate tables
jpa:
  hibernate:
    ddl-auto: create

# After tables are created - change to 'update' to preserve data
jpa:
  hibernate:
    ddl-auto: update
```

**Warning**: Always change back to `update` after first run, otherwise all data will be deleted on restart!

### Issue 2: Vector Store Table Missing
**Problem**: When `initialize-schema: false`, Spring AI won't auto-create `vector_store` table

**Solution**:
```yaml
spring:
  ai:
    vectorstore:
      pgvector:
        initialize-schema: true  # Set to true in dev environment
```

For production, set to `false` and manage schema manually.

### Issue 3: Resume Analysis Fails
**Problem**: Analysis stuck or failing

**Troubleshooting**:
1. Verify `AI_BAILIAN_API_KEY` is correctly configured
2. Check Redis connection and Stream Consumer status
3. Review backend logs for error messages
4. Ensure Alibaba Cloud DashScope API key is valid

### Issue 4: Resume Stuck in "Processing" State
**Problem**: Status remains `PROCESSING` indefinitely

**Troubleshooting**:
1. Check Redis connectivity: `redis-cli ping`
2. Verify Stream consumer is running
3. Check backend logs for consumer errors
4. Restart the application if needed

### Issue 5: PDF Export Chinese Character Issues
**Problem**: Chinese characters not displaying correctly in exported PDFs

**Solution**:
- Font file location: `app/src/main/resources/fonts/ZhuqueFangsong-Regular.ttf`
- Verify iText dependencies are correctly included
- Check font loading logs during startup

---

## API Endpoints Overview

### Resume Module
- `POST /api/resumes/upload` - Upload resume for analysis
- `GET /api/resumes/{id}` - Get resume analysis details
- `GET /api/resumes/{id}/report` - Export PDF report
- `DELETE /api/resumes/{id}` - Delete resume

### Interview Module
- `POST /api/interviews/start` - Start mock interview session
- `POST /api/interviews/{id}/answer` - Submit answer
- `GET /api/interviews/{id}` - Get interview details
- `POST /api/interviews/{id}/export` - Export interview report

### Knowledge Base Module
- `POST /api/knowledge/documents` - Upload document
- `POST /api/knowledge/chat` - Chat with knowledge base (SSE)
- `GET /api/knowledge/statistics` - Get knowledge base statistics

### User Module
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/users/profile` - Get user profile

---

## Deployment Guide

### Docker Deployment

The project provides complete Docker support with one-command deployment:

```bash
# Start all services (frontend, backend, database, middleware)
docker-compose up -d --build

# View service status
docker-compose ps

# View backend logs
docker-compose logs -f app

# Stop all services
docker-compose down

# Clean up unused images
docker image prune -f
```

### Service Ports

| Service | URL | Default Credentials | Description |
|---------|-----|-------------------|-------------|
| Frontend | http://localhost | - | User interface |
| Backend API | http://localhost:8080 | - | REST API / Swagger |
| MinIO Console | http://localhost:9001 | minioadmin/minioadmin | Object storage management |
| MinIO API | localhost:9000 | - | S3-compatible API |
| PostgreSQL | localhost:5432 | postgres/password | Database with pgvector |
| Redis | localhost:6379 | - | Cache & message queue |

### Environment Variables (.env)

Required variables:
```bash
AI_BAILIAN_API_KEY=your_api_key_here
AI_MODEL=qwen-plus  # Optional, default: qwen-plus
APP_INTERVIEW_FOLLOW_UP_COUNT=1  # Optional, default: 1
APP_INTERVIEW_EVALUATION_BATCH_SIZE=8  # Optional, default: 8
```

---

## Testing

### Backend Testing
```bash
./gradlew test
```

### Frontend Testing
```bash
cd frontend
pnpm build  # Build for production
```

---

## Contributing Guidelines

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## License

AGPL-3.0 License - If you provide the software as a network service, you must make the modified source code available to users.

---

## Use Cases

| User Role | Use Case |
|-----------|----------|
| Job Seekers | Upload resumes for AI analysis, practice mock interviews |
| HR/Recruiters | Batch analyze resumes, evaluate candidate capabilities |
| Training Organizations | Provide interview training services, manage knowledge bases |

---

## Additional Resources

- **Architecture Diagram**: See `README.md` for detailed system architecture
- **Tutorial**: Comprehensive guide available at [JavaGuide Interview Guide](https://javaguide.cn/zhuanlan/interview-guide.html) (paid content)
- **Issue Tracker**: Report bugs and request features via GitHub Issues

---

## Skill Usage Instructions

This skill can be used to:
1. Understand the project structure and architecture
2. Set up development environment (Docker or manual)
3. Troubleshoot common issues
4. Deploy the application using Docker
5. Configure AI models and external services
6. Implement new features following existing patterns
7. Debug async processing flows
8. Extend knowledge base functionality

When working with this codebase:
- Always check `application.yml` for configuration issues first
- Verify Redis and PostgreSQL connectivity for async task problems
- Use Docker Compose for quick local development setup
- Follow the existing module structure when adding new features
- Test PDF exports with Chinese characters carefully
- Monitor Redis Stream consumers for stuck tasks
