
import { motion } from 'framer-motion';
import { ClipboardPaste } from 'lucide-react';

interface JobDescriptionPanelProps {
  jobDescription: string;
  onJobDescriptionChange: (jd: string) => void;
}

export default function JobDescriptionPanel({ jobDescription, onJobDescriptionChange }: JobDescriptionPanelProps) {

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      onJobDescriptionChange(text);
    } catch (err) {
      console.error('Failed to read clipboard contents: ', err);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onJobDescriptionChange(e.target.value);
  };

  return (
    <motion.div
      className="bg-white dark:bg-slate-800 rounded-2xl p-6 my-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
          <ClipboardPaste className="w-5 h-5" />
          <span className="font-semibold">岗位JD描述</span>
        </div>
        <motion.button
          onClick={handlePaste}
          className="px-4 py-2 border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-600 transition-all disabled:opacity-50 flex items-center gap-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <ClipboardPaste className="w-4 h-4" />
          粘贴岗位描述
        </motion.button>
      </div>
      <textarea
        value={jobDescription}
        onChange={handleChange}
        placeholder="在这里输入或粘贴岗位JD描述，AI面试官会根据岗位要求进行提问..."
        className="w-full h-40 p-4 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 focus:outline-none transition-colors"
      />
    </motion.div>
  );
}
