import { Navigate } from 'react-router-dom';
import { isAuthenticated } from '../api/auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * 认证守卫组件
 * 只有已登录用户才能访问，否则跳转到登录页
 */
export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const authenticated = isAuthenticated();

  if (!authenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}
