import { AnimatePresence, motion } from 'framer-motion';
import type { InterviewSession } from '../types/interview';
import JobDescriptionPanel from './JobDescriptionPanel';
import { FileText } from 'lucide-react'; // Import an icon for the resume preview

interface InterviewConfigPanelProps {
  questionCount: number;
  followUpCount: number;
  enableMultiDimension: boolean;
  onQuestionCountChange: (count: number) => void;
  onFollowUpCountChange: (count: number) => void;
  onEnableMultiDimensionChange: (enabled: boolean) => void;
  jobDescription: string;
  onJobDescriptionChange: (jd: string) => void;
  onStart: () => void;
  isCreating: boolean;
  checkingUnfinished: boolean;
  unfinishedSession: InterviewSession | null;
  onContinueUnfinished: () => void;
  onStartNew: () => void;
  resumeText: string;
  onBack: () => void;
  error?: string;
}

/**
 * 面试配置面板组件
 */
export default function InterviewConfigPanel({
  questionCount,
  followUpCount,
  enableMultiDimension,
  onQuestionCountChange,
  onFollowUpCountChange,
  onEnableMultiDimensionChange,
  jobDescription,
  onJobDescriptionChange,
  onStart,
  isCreating,
  checkingUnfinished,
  unfinishedSession,
  onContinueUnfinished,
  onStartNew,
  resumeText,
  onBack,
  error
}: InterviewConfigPanelProps) {
  const questionCounts = [6, 8, 10, 12, 15];
  const followUpCounts = [0, 1, 2]; // 0=无追问，1=1 个追问，2=2 个追问

  return (
      <motion.div
      className="max-w-2xl mx-auto px-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
          <div
              className="bg-white dark:bg-slate-800 rounded-2xl p-6 md:p-8 shadow-sm dark:shadow-slate-900/50 border border-slate-100 dark:border-slate-700">
              <h2 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                  <div
                      className="w-10 h-10 bg-primary-100 dark:bg-primary-900/50 rounded-xl flex items-center justify-center">
                      <svg className="w-5 h-5 text-primary-600 dark:text-primary-400" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
              <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2"/>
              <circle cx="12" cy="12" r="2" fill="currentColor"/>
            </svg>
          </div>
          面试配置
        </h2>

        {/* 未完成面试提示 */}
        <AnimatePresence>
          {checkingUnfinished && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-xl text-blue-700 dark:text-blue-400 text-sm text-center"
            >
              <div className="flex items-center justify-center gap-2">
                  <motion.div
                  className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                />
                正在检查是否有未完成的面试...
              </div>
            </motion.div>
          )}

          {unfinishedSession && !checkingUnfinished && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-6 p-5 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/30 dark:to-orange-900/30 border-2 border-amber-200 dark:border-amber-800 rounded-xl"
            >
              <div className="flex items-start gap-3 mb-4">
                  <div
                      className="w-8 h-8 bg-amber-100 dark:bg-amber-900/50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <svg className="w-5 h-5 text-amber-600 dark:text-amber-400" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div className="flex-1">
                    <h3 className="font-semibold text-amber-900 dark:text-amber-300 mb-1">检测到未完成的模拟面试</h3>
                    <p className="text-xs md:text-sm text-amber-700 dark:text-amber-400">
                    已完成 {unfinishedSession.currentQuestionIndex} / {unfinishedSession.totalQuestions} 题
                  </p>
                </div>
              </div>
              <div className="flex gap-3 flex-wrap">
                <motion.button
                  onClick={onContinueUnfinished}
                  className="flex-1 min-w-[120px] px-4 py-2.5 md:py-3 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors text-sm md:text-base"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  继续完成
                </motion.button>
                <motion.button
                  onClick={onStartNew}
                  className="flex-1 min-w-[120px] px-4 py-2.5 md:py-3 bg-white dark:bg-slate-700 border border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-400 rounded-lg font-medium hover:bg-amber-50 dark:hover:bg-amber-900/30 transition-colors text-sm md:text-base"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  开始新的
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-6">
          <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
              题目数量
            </label>
            <div className="grid grid-cols-5 gap-2 md:gap-3">
              {questionCounts.map((count) => (
                <motion.button
                  key={count}
                  onClick={() => onQuestionCountChange(count)}
                  className={`px-2 md:px-4 py-2 md:py-3 rounded-xl font-medium transition-all text-sm md:text-base ${
                    questionCount === count
                      ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/30'
                        : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {count}
                </motion.button>
              ))}
            </div>
          </div>

          <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
              每个主问题的追问数量
            </label>
            <div className="grid grid-cols-3 gap-2 md:gap-3">
              {followUpCounts.map((count) => (
                <motion.button
                  key={count}
                  onClick={() => onFollowUpCountChange(count)}
                  className={`px-2 md:px-4 py-2 md:py-3 rounded-xl font-medium transition-all text-sm md:text-base ${
                    followUpCount === count
                      ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/30'
                        : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {count === 0 ? '无追问' : `${count}个追问`}
                </motion.button>
              ))}
            </div>
          </div>

          <motion.div
            className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/30 dark:to-blue-900/30 border-2 border-purple-200 dark:border-purple-800 rounded-xl p-5"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-start gap-3">
              <div className="flex items-center h-5">
                <input
                  type="checkbox"
                  id="enableMultiDimension"
                  checked={enableMultiDimension}
                  onChange={(e) => onEnableMultiDimensionChange(e.target.checked)}
                  className="w-4 h-4 md:w-5 md:h-5 text-primary-600 bg-slate-100 dark:bg-slate-700 border-purple-300 dark:border-purple-600 rounded focus:ring-primary-500 focus:ring-2 cursor-pointer"
                />
              </div>
              <div className="flex-1">
                <label htmlFor="enableMultiDimension" className="font-semibold text-purple-900 dark:text-purple-300 cursor-pointer text-sm md:text-base">
                  开启多维度评估
                </label>
                <p className="text-xs text-purple-700 dark:text-purple-400 mt-1">
                  从技术专家、HR 经理、架构师三个维度进行全面评估，提供更详细的反馈建议
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            className="bg-white dark:bg-slate-800 rounded-2xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                <FileText className="w-5 h-5" />
                <span className="font-semibold">简历预览（前500字）</span>
              </div>
            </div>
            <textarea
              value={resumeText.substring(0, 500) + (resumeText.length > 500 ? '...' : '')}
              readOnly
              className="w-full h-32 md:h-40 p-3 md:p-4 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 focus:outline-none transition-colors resize-none text-sm md:text-base"
            />
          </motion.div>

          <JobDescriptionPanel jobDescription={jobDescription} onJobDescriptionChange={onJobDescriptionChange} />

            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
            题目分布：项目经历(20%) + MySQL(20%) + Redis(20%) + Java基础/集合/并发(30%) + Spring(10%)
          </p>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-6 p-3 md:p-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-xl text-red-600 dark:text-red-400 text-xs md:text-sm"
              >
                ⚠️ {error}
              </motion.div>
            )}
          </AnimatePresence>

            <div className="flex justify-center gap-3 md:gap-4 flex-wrap">
                <motion.button
              onClick={onBack}
              className="px-4 md:px-6 py-2.5 md:py-3 border border-slate-200 dark:border-slate-600 rounded-xl text-sm md:text-base font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition-all flex-1 md:flex-none min-w-[100px]"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              ← 返回
            </motion.button>
            <motion.button
              onClick={onStart}
              disabled={isCreating}
              className="px-6 md:px-8 py-2.5 md:py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl text-sm md:text-base font-semibold shadow-lg shadow-primary-500/30 hover:shadow-xl transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2 flex-1 md:flex-none min-w-[140px]"
              whileHover={{ scale: isCreating ? 1 : 1.02, y: isCreating ? 0 : -1 }}
              whileTap={{ scale: isCreating ? 1 : 0.98 }}
            >
              {isCreating ? (
                <>
                    <motion.span
                    className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  />
                  正在生成题目...
                </>
              ) : (
                <>
                  开始面试 →
                </>
              )}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}