import {Link, Outlet, useLocation, useNavigate} from 'react-router-dom';
import {motion, AnimatePresence} from 'framer-motion';
import {ChevronRight, Database, FileStack, LogOut, MessageSquare, Moon, Sparkles, Sun, Upload, Users, Briefcase, Menu, X} from 'lucide-react';
import {useTheme} from '../hooks/useTheme';
import {getLocalUser, logout} from '../api/auth';
import {useState} from 'react';

interface NavItem {
  id: string;
  path: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description?: string;
}

interface NavGroup {
  id: string;
  title: string;
  items: NavItem[];
}

export default function Layout() {
  const location = useLocation();
  const currentPath = location.pathname;
  const navigate = useNavigate();
    const {theme, toggleTheme} = useTheme();
    const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // 获取当前用户信息
  const user = getLocalUser();

  // 按业务模块组织的导航项
  const navGroups: NavGroup[] = [
    {
      id: 'analysis',
      title: '岗位分析',
      items: [
        { id: 'jd-analysis', path: '/app/jd-analysis', label: 'JD 解析', icon: Briefcase, description: '智能分析岗位 JD' },
      ],
    },
    {
      id: 'career',
      title: '简历与面试',
      items: [
        { id: 'upload', path: '/app/upload', label: '上传简历', icon: Upload, description: 'AI 分析简历' },
        { id: 'resumes', path: '/app/history', label: '简历库', icon: FileStack, description: '管理所有简历' },
        { id: 'interviews', path: '/app/interviews', label: '面试记录', icon: Users, description: '查看面试历史' },
      ],
    },
    {
      id: 'knowledge',
      title: '知识库',
      items: [
        { id: 'kb-manage', path: '/app/knowledgebase', label: '知识库管理', icon: Database, description: '管理知识文档' },
        { id: 'chat', path: '/app/knowledgebase/chat', label: '问答助手', icon: MessageSquare, description: '基于知识库问答' },
      ],
    },
  ];

  // 判断当前页面是否匹配导航项
  const isActive = (path: string) => {
    if (path === '/app/upload') {
      return currentPath === '/app/upload' || currentPath === '/app';
    }
    if (path === '/app/knowledgebase') {
      return currentPath === '/app/knowledgebase' || currentPath === '/app/knowledgebase/upload';
    }
    return currentPath.startsWith(path);
  };

  /**
   * 处理登出
   */
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
      <div
          className="flex min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 dark:from-slate-900 dark:to-slate-800">
      {/* 移动端汉堡菜单按钮 */}
          <button
              className="md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-white dark:bg-slate-800 shadow-lg"
              onClick={() => setSidebarOpen(!sidebarOpen)}
          >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

      {/* 遮罩层 */}
          <AnimatePresence>
              {sidebarOpen && (
                  <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="md:hidden fixed inset-0 bg-black/50 z-40"
                      onClick={() => setSidebarOpen(false)}
                  />
              )}
          </AnimatePresence>

      {/* 左侧边栏 */}
          <aside
              className={`w-64 bg-white dark:bg-slate-900 border-r border-slate-100 dark:border-slate-700 fixed h-screen left-0 top-0 z-50 flex flex-col transform transition-transform duration-300 md:translate-x-0 ${
                  sidebarOpen ? 'translate-x-0' : '-translate-x-full'
              }`}>
        {/* Logo */}
              <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <Link to="/app/upload" className="flex items-center gap-3" onClick={() => setSidebarOpen(false)}>
            <img src="/logo.jpg" alt="智面先锋 Logo" className="w-10 h-10 rounded-xl object-cover shadow-lg" />
            <div>
                <span
                    className="text-lg font-bold text-slate-800 dark:text-white tracking-tight block">智面先锋</span>
                <span className="text-xs text-slate-400 dark:text-slate-500">AI Interview</span>
            </div>
          </Link>
        </div>

              {/* 主题切换按钮 */}
              <div className="px-4 pb-2">
                  <button
                      onClick={toggleTheme}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                      {theme === 'dark' ? (
                          <>
                              <Sun className="w-4 h-4"/>
                              <span className="text-sm font-medium">浅色模式</span>
                          </>
                      ) : (
                          <>
                              <Moon className="w-4 h-4"/>
                              <span className="text-sm font-medium">深色模式</span>
                          </>
                      )}
                  </button>
              </div>

        {/* 导航菜单 */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-6">
            {navGroups.map((group) => (
              <div key={group.id}>
                {/* 分组标题 */}
                <div className="px-3 mb-2">
                  <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                    {group.title}
                  </span>
                </div>
                {/* 分组下的导航项 */}
                <div className="space-y-1">
                  {group.items.map((item) => {
                    const active = isActive(item.path);
                    return (
                      <Link
                        key={item.id}
                        to={item.path}
                        onClick={() => setSidebarOpen(false)}
                        className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200
                          ${active
                            ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400'
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                          }`}
                      >
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors
                          ${active
                            ? 'bg-primary-100 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:bg-slate-200 dark:group-hover:bg-slate-700 group-hover:text-slate-700 dark:group-hover:text-white'
                          }`}
                        >
                          <item.icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className={`text-sm block ${active ? 'font-semibold' : 'font-medium'}`}>
                            {item.label}
                          </span>
                          {item.description && (
                              <span className="text-xs text-slate-400 dark:text-slate-500 truncate block">
                              {item.description}
                            </span>
                          )}
                        </div>
                        {active && (
                          <ChevronRight className="w-4 h-4 text-primary-400" />
                        )}
                      </Link>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </nav>

        {/* 底部信息 */}
              <div className="p-4 border-t border-slate-100 dark:border-slate-700 space-y-3">
      
          {/* 登出按钮 */}
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 transition-colors"
          >
            <LogOut className="w-4 h-4"/>
            <span className="text-sm font-medium">退出登录</span>
          </button>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="flex-1 md:ml-64 p-4 md:p-10 min-h-screen overflow-y-auto pt-20 md:pt-10">
        <motion.div
          key={currentPath}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Outlet />
        </motion.div>
      </main>
    </div>
  );
}
