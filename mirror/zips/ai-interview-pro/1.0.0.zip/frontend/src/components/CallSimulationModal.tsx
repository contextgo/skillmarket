import {useEffect, useMemo, useRef, useState} from 'react';
import {motion, AnimatePresence} from 'framer-motion';
import {Mic, MicOff, PhoneOff, Volume2, VolumeX} from 'lucide-react';
import {request} from '../api/request';

type SpeechRecognitionCtor = new () => SpeechRecognition;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

interface CallSimulationModalProps {
  open: boolean;
  onClose: () => void;
  lastInterviewerText: string;
  onSendTranscript: (text: string) => void;
}

export default function CallSimulationModal({
  open,
  onClose,
  lastInterviewerText,
  onSendTranscript,
}: CallSimulationModalProps) {
  const recognitionCtor = useMemo(() => (typeof window === 'undefined' ? null : getSpeechRecognitionCtor()), []);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const [isListening, setIsListening] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [finalText, setFinalText] = useState('');
  const [error, setError] = useState<string>('');
  const [muted, setMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [speechRate, setSpeechRate] = useState(1);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [tick, setTick] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const hasSpeechSupport = !!recognitionCtor;

  const callSeconds = useMemo(() => {
    if (!startedAt) return 0;
    return Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
  }, [startedAt, tick]);

  const callTime = useMemo(() => {
    const mm = String(Math.floor(callSeconds / 60)).padStart(2, '0');
    const ss = String(callSeconds % 60).padStart(2, '0');
    return `${mm}:${ss}`;
  }, [callSeconds]);

  const stopRecognition = () => {
    const r = recognitionRef.current;
    recognitionRef.current = null;
    if (r) {
      try {
        r.onresult = null;
        r.onerror = null;
        r.onend = null;
        r.stop();
      } catch {
        // ignore
      }
    }
    setIsListening(false);
  };

  const startRecognition = () => {
    console.log('[CallModal] 尝试启动语音识别...');
    console.log('[CallModal] recognitionCtor:', recognitionCtor);
      
    if (!recognitionCtor) {
      console.error('[CallModal] 浏览器不支持语音识别');
      setError('当前浏览器不支持语音识别 (SpeechRecognition),请使用 Chrome 或 Edge 浏览器');
      return;
    }
    setError('');
    setInterimText('');
    setFinalText('');
  
    const r = new recognitionCtor();
    recognitionRef.current = r;
    r.continuous = true;
    r.interimResults = true;
    r.lang = 'zh-CN';
  
    console.log('[CallModal] 创建识别实例，配置:', { 
      continuous: r.continuous, 
      interimResults: r.interimResults, 
      lang: r.lang 
    });
    
    // 使用 addEventListener 替代 onstart（修复 TS 类型错误）
    r.addEventListener('start', () => {
      console.log('[CallModal] ✅ 语音识别已启动');
    });
  
    r.onresult = (event: SpeechRecognitionEvent) => {
      console.log('[CallModal] 📝 识别结果:', event);
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const text = res[0]?.transcript ?? '';
        const confidence = res[0]?.confidence ?? 0;
        console.log(`[CallModal] 片段 ${i}:`, { 
          text, 
          confidence, 
          isFinal: res.isFinal 
        });
        if (res.isFinal) final += text;
        else interim += text;
      }
      setInterimText(interim.trim());
      if (final.trim()) {
        setFinalText(final.trim());
      }
    };
  
    r.onerror = (e: SpeechRecognitionErrorEvent) => {
      console.error('[CallModal] ❌ 识别错误:', e);
      const msg =
        e.error === 'not-allowed'
          ? '麦克风权限被拒绝，请在浏览器权限中允许麦克风后重试'
          : e.error === 'no-speech'
            ? '没有检测到语音，请再试一次'
            : `语音识别出错：${e.error}`;
      setError(msg);
      stopRecognition();
    };
  
    r.onend = () => {
      console.log('[CallModal] 🔚 语音识别结束');
      setIsListening(false);
    };
  
    try {
      console.log('[CallModal] 调用 r.start()...');
      r.start();
      console.log('[CallModal] ✅ 已成功启动录音');
      setIsListening(true);
    } catch (err) {
      console.error('[CallModal] ❌ 启动失败:', err);
      setError('无法启动语音识别，请重试或更换浏览器');
      stopRecognition();
    }
  };

  const speak = (text: string) => {
    if (!speakerOn) return;
    if (typeof window === 'undefined') return;
    if (!('speechSynthesis' in window)) return;
    const t = text.trim();
    if (!t) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(t);
      u.lang = 'zh-CN';
      u.rate = speechRate;
      u.pitch = 1;
      u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    if (!open) return;
    setStartedAt(Date.now());
    setTick(0);
    const id = window.setInterval(() => setTick((t) => t + 1), 1000);
    return () => window.clearInterval(id);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    if (!speakerOn) return;
    speak(lastInterviewerText);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, lastInterviewerText, speakerOn, speechRate]);

  useEffect(() => {
    if (!open) {
      stopRecognition();
      setInterimText('');
      setFinalText('');
      setError('');
      setMuted(false);
      setSpeakerOn(true);
      setSpeechRate(1);
      setStartedAt(null);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch {
          // ignore
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleHangup = () => {
    stopRecognition();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
    }
    onClose();
  };

  const handleToggleListen = () => {
    if (muted) return;
    if (isListening) stopRecognition();
    else startRecognition();
  };

  const handleSend = () => {
    const text = (finalText || interimText).trim();
    if (!text) return;
    stopRecognition();
    onSendTranscript(text);
    setInterimText('');
    setFinalText('');
  };

  const handleToggleRate = () => {
    const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0] as const;
    const idx = rates.findIndex((r) => r === speechRate);
    const next = rates[(idx + 1) % rates.length] ?? 1;
    setSpeechRate(next);
    if (speakerOn && lastInterviewerText.trim()) speak(lastInterviewerText);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleHangup}
        >
          <motion.div
            className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden"
            initial={{ scale: 0.98, y: 10, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.98, y: 10, opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">通话中</div>
                  <div className="text-xl font-bold text-slate-900 dark:text-white">AI 面试官</div>
                  <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">{callTime}</div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleToggleRate}
                    className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-sm font-semibold"
                    aria-label="调整语速"
                    title="调整语速"
                  >
                    语速 x{speechRate.toFixed(1)}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSpeakerOn((v) => !v)}
                    className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center"
                    aria-label={speakerOn ? '关闭扬声器' : '开启扬声器'}
                  >
                    {speakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMuted((v) => !v);
                      stopRecognition();
                    }}
                    className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center"
                    aria-label={muted ? '取消静音' : '静音'}
                  >
                    {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="mt-6 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-4">
                <div className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">面试官</div>
                <div className="text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {lastInterviewerText || '...'}
                </div>
              </div>

              <div className="mt-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-sm font-semibold text-slate-700 dark:text-slate-200">你正在说</div>
                  {!hasSpeechSupport && (
                    <span className="text-xs text-amber-600 dark:text-amber-400">浏览器不支持语音识别</span>
                  )}
                </div>
                <div className="min-h-[56px] text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {(finalText || interimText) ? (finalText || interimText) : '点击下方麦克风开始说话'}
                </div>
                {error && <div className="mt-3 text-sm text-rose-600 dark:text-rose-400">{error}</div>}
              </div>
            </div>

            <div className="p-6 pt-0">
              <div className="flex items-center justify-center gap-4">
                <motion.button
                  type="button"
                  onClick={handleToggleListen}
                  disabled={!hasSpeechSupport || muted}
                  className="w-14 h-14 rounded-2xl bg-primary-500 text-white hover:bg-primary-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                  whileTap={{ scale: 0.96 }}
                  aria-label={isListening ? '停止说话' : '开始说话'}
                >
                  {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </motion.button>

                <motion.button
                  type="button"
                  onClick={handleSend}
                  disabled={!(finalText || interimText).trim()}
                  className="px-5 py-3 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
                  whileTap={{ scale: 0.98 }}
                >
                  发送
                </motion.button>

                <motion.button
                  type="button"
                  onClick={handleHangup}
                  className="w-14 h-14 rounded-2xl bg-rose-500 text-white hover:bg-rose-600 flex items-center justify-center"
                  whileTap={{ scale: 0.96 }}
                  aria-label="挂断"
                >
                  <PhoneOff className="w-6 h-6" />
                </motion.button>
              </div>
              <div className="mt-3 text-center text-xs text-slate-500 dark:text-slate-400">
                小提示：说完后点“发送”，或先停止麦克风再发送。
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

