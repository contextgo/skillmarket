import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { InterviewQuestion, InterviewSession } from '../types/interview';
import { Send, Mic, MicOff, Sparkles, User, Volume2, VolumeX } from 'lucide-react';
import { request } from '../api/request';

type SpeechRecognitionCtor = new () => SpeechRecognition;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

interface Message {
  type: 'interviewer' | 'user';
  content: string;
  category?: string;
  questionIndex?: number;
  isTyping?: boolean;
}

interface ImmersiveInterviewPanelProps {
  session: InterviewSession;
  currentQuestion: InterviewQuestion | null;
  messages: Message[];
  answer: string;
  onAnswerChange: (answer: string) => void;
  onSubmit: () => void;
  onCompleteEarly: () => void;
  isSubmitting: boolean;
  showCompleteConfirm: boolean;
  onShowCompleteConfirm: (show: boolean) => void;
  isTyping?: boolean;
}

/**
 * 沉浸式面试面板组件 - 类似豆包的通话体验
 */
export default function ImmersiveInterviewPanel({
  session,
  currentQuestion,
  messages,
  answer,
  onAnswerChange,
  onSubmit,
  isSubmitting,
  showCompleteConfirm,
  onShowCompleteConfirm,
  isTyping = false
}: ImmersiveInterviewPanelProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showScrollHint, setShowScrollHint] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  // Web Speech API refs
  const recognitionCtor = useRef<SpeechRecognitionCtor | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [hasSpeechSupport, setHasSpeechSupport] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [finalText, setFinalText] = useState('');
  const [speechError, setSpeechError] = useState<string>('');
  const [speakerOn, setSpeakerOn] = useState(true);
  const [speechRate, setSpeechRate] = useState(1);

  // 检测浏览器是否支持语音识别
  useEffect(() => {
    const ctor = getSpeechRecognitionCtor();
    recognitionCtor.current = ctor;
    setHasSpeechSupport(!!ctor);
    console.log('[Speech] 浏览器支持情况:', !!ctor, 'Constructor:', ctor);
    
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  // 自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    
    // 显示滚动提示（当有新消息且不在底部时）
    const container = document.getElementById('messages-container');
    if (container) {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isAtBottom = scrollTop + clientHeight >= scrollHeight - 100;
      setShowScrollHint(!isAtBottom && messages.length > 2);
    }
  }, [messages]);

  const progress = session && currentQuestion 
    ? ((currentQuestion.questionIndex + 1) / session.totalQuestions) * 100 
    : 0;

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      onSubmit();
    }
  };

  // 启动录音（使用 MediaRecorder 录制音频）
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        handleAudioToText(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (error) {
      console.error('获取麦克风权限失败:', error);
      alert('无法访问麦克风，请检查浏览器权限设置');
    }
  };

  // 停止录音
  const stopRecording = () => {
    if (mediaRecorder && isRecording && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  // 启动 Web Speech API 语音识别
  const startSpeechRecognition = () => {
    console.log('[Speech] 尝试启动语音识别...');
    if (!recognitionCtor.current) {
      console.error('[Speech] 浏览器不支持语音识别');
      setSpeechError('当前浏览器不支持语音识别，请使用 Chrome、Edge 或其他支持的浏览器');
      return;
    }
    
    setSpeechError('');
    setInterimText('');
    setFinalText('');
    
    const r = new recognitionCtor.current();
    recognitionRef.current = r;
    
    r.continuous = true;
    r.interimResults = true;
    r.lang = 'zh-CN';
    
    console.log('[Speech] 创建识别实例，配置:', { continuous: r.continuous, interimResults: r.interimResults, lang: r.lang });
    
    // 使用 addEventListener 替代 onstart（修复 TS 类型错误）
    r.addEventListener('start', () => {
      console.log('[Speech] 语音识别已启动');
    });
    
    r.onresult = (event: SpeechRecognitionEvent) => {
      console.log('[Speech] 识别结果:', event);
      let interim = '';
      let final = '';
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const text = res[0]?.transcript ?? '';
        const confidence = res[0]?.confidence ?? 0;
        console.log(`[Speech] 片段 ${i}:`, { text, confidence, isFinal: res.isFinal });
        if (res.isFinal) {
          final += text;
        } else {
          interim += text;
        }
      }
      
      setInterimText(interim.trim());
      if (final.trim()) {
        setFinalText(final.trim());
      }
    };
    
    r.onerror = (e: SpeechRecognitionErrorEvent) => {
      console.error('[Speech] 识别错误:', e);
      const msg =
        e.error === 'not-allowed'
          ? '麦克风权限被拒绝，请在浏览器权限中允许麦克风后重试'
          : e.error === 'no-speech'
            ? '没有检测到语音，请再试一次'
            : `语音识别出错：${e.error}`;
      setSpeechError(msg);
      stopSpeechRecognition();
    };
    
    r.onend = () => {
      console.log('[Speech] 语音识别结束');
      setIsRecording(false);
    };
    
    try {
      r.start();
      console.log('[Speech] 已成功启动录音');
      setIsRecording(true);
    } catch (err) {
      console.error('[Speech] 启动失败:', err);
      setSpeechError('无法启动语音识别，请重试或更换浏览器');
      stopSpeechRecognition();
    }
  };
  
  // 停止 Web Speech API 语音识别
  const stopSpeechRecognition = () => {
    const r = recognitionRef.current;
    recognitionRef.current = null;
    
    if (r) {
      try {
        r.onresult = null;
        r.onerror = null;
        r.onend = null;
        r.stop();
      } catch {
        // ignore
      }
    }
    setIsRecording(false);
  };
  
  // 切换录音状态
  const toggleRecording = () => {
    if (isRecording) {
      stopSpeechRecognition();
    } else {
      startSpeechRecognition();
    }
  };
  
  // 发送识别结果
  const handleSendTranscript = () => {
    const text = (finalText || interimText).trim();
    if (!text) return;
    
    stopSpeechRecognition();
    onAnswerChange(text);
    setInterimText('');
    setFinalText('');
  };

  // 将音频转换为文字（使用 Web Speech API 进行实时识别）
  const handleAudioToText = async (_audioBlob: Blob) => {
    // 不使用后端 API，直接使用 Web Speech API 的识别结果
    // 这个方法在 startSpeechRecognition 中已经处理了
    console.log('Web Speech API 已处理语音识别，无需调用后端 API');
  };

  // 文字转语音播放（使用浏览器原生 API）
  const handleTextToSpeech = async (text: string) => {
    if (!speakerOn) return;
    if (typeof window === 'undefined') return;
    if (!('speechSynthesis' in window)) return;
    
    const t = text.trim();
    if (!t) return;
    
    try {
      console.log('准备播放语音:', t.substring(0, 50) + '...');
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(t);
      u.lang = 'zh-CN';
      u.rate = speechRate;
      u.pitch = 1;
      u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch (error) {
      console.error('语音合成失败:', error);
    }
  };
  
  // 切换语速
  const handleToggleRate = () => {
    const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0] as const;
    const idx = rates.findIndex((r) => r === speechRate);
    const next = rates[(idx + 1) % rates.length] ?? 1;
    setSpeechRate(next);
    
    // 如果有最新消息，用新语速重新播放
    const latestMessage = messages[messages.length - 1];
    if (latestMessage && latestMessage.type === 'interviewer') {
      handleTextToSpeech(latestMessage.content);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* 动态背景效果 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/4 w-full h-full bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-1/2 -right-1/4 w-full h-full bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* 顶部进度栏 */}
      <motion.div 
        className="relative z-10 bg-white/5 backdrop-blur-xl border-b border-white/10 px-6 py-4"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-white/80 text-sm font-medium">AI 面试官在线</span>
            </div>
            <div className="h-4 w-px bg-white/20" />
            <span className="text-white/60 text-sm">
              题目 {currentQuestion ? currentQuestion.questionIndex + 1 : 0} / {session.totalQuestions}
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-white/80 text-sm font-semibold">{Math.round(progress)}%</div>
              <div className="text-white/40 text-xs">完成度</div>
            </div>
            <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </div>
      </motion.div>

      {/* 主内容区 */}
      <div className="flex-1 relative z-10 flex max-w-5xl mx-auto w-full">
        {/* AI 虚拟形象区域 - 左侧 */}
        <motion.div 
          className="hidden lg:flex w-80 flex-col items-center justify-center p-8 border-r border-white/10"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
        >
          {/* AI 形象 */}
          <div className="relative mb-6">
            <div className="absolute inset-0 bg-purple-500/30 rounded-full blur-2xl animate-pulse" />
            <div className="relative w-32 h-32 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center shadow-2xl shadow-purple-500/50">
              <Sparkles className="w-16 h-16 text-white" />
            </div>
            
            {/* 说话时的声波动画 */}
            {isTyping && (
              <div className="absolute -inset-4">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute inset-0 border-2 border-purple-500/30 rounded-full"
                    initial={{ scale: 1, opacity: 0.5 }}
                    animate={{ scale: 1.5, opacity: 0 }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity, 
                      delay: i * 0.3,
                      ease: "easeOut"
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          
          <div className="text-center space-y-2">
            <h3 className="text-white text-xl font-bold">AI 面试官</h3>
            <p className="text-white/50 text-sm">智能面试助手</p>
            {isTyping && (
              <motion.div 
                className="flex items-center justify-center gap-1 mt-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <span className="text-purple-400 text-xs">正在思考</span>
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-1.5 h-1.5 bg-purple-400 rounded-full"
                    animate={{ y: [0, -5, 0] }}
                    transition={{ 
                      duration: 0.6, 
                      repeat: Infinity, 
                      delay: i * 0.15 
                    }}
                  />
                ))}
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* 对话区域 - 右侧 */}
        <div className="flex-1 flex flex-col min-h-0">
          {/* 消息列表 */}
          <div 
            id="messages-container"
            className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent"
          >
            <AnimatePresence mode="popLayout">
              {messages.map((msg, index) => (
                <MessageBubble 
                  key={index} 
                  message={msg} 
                  isLatest={index === messages.length - 1}
                />
              ))}
              
              {isTyping && (
                <TypingIndicator />
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
            
            {/* 滚动到底部提示 */}
            {showScrollHint && (
              <motion.button
                onClick={() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })}
                className="fixed bottom-48 right-8 bg-purple-500 text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg hover:bg-purple-600 transition-colors z-50"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
              >
                最新消息
              </motion.button>
            )}
          </div>

          {/* 输入区域 */}
          <motion.div 
            className="border-t border-white/10 p-6 bg-black/20 backdrop-blur-xl"
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <textarea
                  value={answer}
                  onChange={(e) => onAnswerChange(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="输入你的回答... (Cmd/Ctrl + Enter 提交)"
                  className="w-full h-24 px-6 py-4 bg-white/5 border border-white/20 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-transparent resize-none text-white placeholder-white/30 backdrop-blur-sm transition-all"
                  disabled={isSubmitting}
                />
                <div className="absolute bottom-3 right-3 text-white/30 text-xs">
                  Cmd/Ctrl + Enter 提交
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <motion.button
                  onClick={onSubmit}
                  disabled={!answer.trim() || isSubmitting}
                  className="px-8 py-4 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-2xl font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  whileHover={{ scale: isSubmitting || !answer.trim() ? 1 : 1.05 }}
                  whileTap={{ scale: isSubmitting || !answer.trim() ? 1 : 0.95 }}
                >
                  {isSubmitting ? (
                    <>
                      <motion.div
                        className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      />
                      提交中
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      提交
                    </>
                  )}
                </motion.button>
                
                <motion.button
                  onClick={() => onShowCompleteConfirm(true)}
                  disabled={isSubmitting}
                  className="px-8 py-3 bg-white/10 text-white/70 rounded-2xl font-medium hover:bg-white/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm backdrop-blur-sm border border-white/10"
                  whileHover={{ scale: isSubmitting ? 1 : 1.05 }}
                  whileTap={{ scale: isSubmitting ? 1 : 0.95 }}
                >
                  提前交卷
                </motion.button>
              </div>
            </div>
            
            {/* 语音功能控制区 */}
            <div className="mt-4 space-y-3">
              {/* 语音识别结果显示 */}
              {(finalText || interimText) && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/10"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm font-semibold text-white/80">识别结果</div>
                    {!hasSpeechSupport && (
                      <span className="text-xs text-amber-400">浏览器不支持语音识别</span>
                    )}
                  </div>
                  <div className="text-white/90 leading-relaxed whitespace-pre-wrap min-h-[40px]">
                    {finalText || interimText}
                  </div>
                  {speechError && (
                    <div className="mt-2 text-sm text-rose-400">{speechError}</div>
                  )}
                </motion.div>
              )}
              
              {/* 语音控制按钮 */}
              <div className="flex items-center justify-center gap-3">
                {/* 麦克风开关 */}
                <motion.button
                  onClick={toggleRecording}
                  disabled={!hasSpeechSupport}
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                    isRecording
                      ? 'bg-red-500 text-white shadow-lg shadow-red-500/50 animate-pulse'
                      : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                  whileTap={{ scale: 0.95 }}
                  title={isRecording ? '停止语音输入' : '开始语音输入'}
                >
                  {isRecording ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </motion.button>
                
                {/* 发送按钮 */}
                <motion.button
                  onClick={handleSendTranscript}
                  disabled={!(finalText || interimText).trim()}
                  className="px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-2xl font-semibold hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-purple-500/30"
                  whileTap={{ scale: 0.98 }}
                >
                  发送
                </motion.button>
                
                {/* 扬声器开关 */}
                <motion.button
                  onClick={() => setSpeakerOn((v) => !v)}
                  className="w-14 h-14 rounded-2xl bg-white/10 text-white hover:bg-white/20 border border-white/10 flex items-center justify-center transition-all"
                  whileTap={{ scale: 0.95 }}
                  title={speakerOn ? '关闭语音播放' : '开启语音播放'}
                >
                  {speakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
                </motion.button>
                
                {/* 语速调节 */}
                <motion.button
                  onClick={handleToggleRate}
                  className="px-4 py-3 bg-white/10 text-white hover:bg-white/20 rounded-2xl font-medium border border-white/10 transition-all text-sm"
                  whileTap={{ scale: 0.95 }}
                  title="切换语速"
                >
                  语速 x{speechRate.toFixed(1)}
                </motion.button>
              </div>
              
              <div className="text-center text-xs text-white/40">
                {isRecording ? '🔴 正在录音... 说完后点击“发送"' : '点击麦克风开始语音输入'}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

// 消息气泡组件
function MessageBubble({ message, isLatest }: { message: Message; isLatest: boolean }) {
  if (message.type === 'interviewer') {
    return (
      <motion.div
        initial={{ opacity: 0, x: -30, scale: 0.95 }}
        animate={{ opacity: 1, x: 0, scale: 1 }}
        exit={{ opacity: 0, x: -30, scale: 0.95 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="flex items-start gap-4"
      >
        <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/30">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 max-w-[85%]">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-purple-300 text-sm font-semibold">AI 面试官</span>
            {message.category && (
              <span className="px-3 py-1 bg-purple-500/20 text-purple-300 text-xs rounded-full border border-purple-500/30">
                {message.category}
              </span>
            )}
            {isLatest && (
              <span className="text-white/30 text-xs">最新</span>
            )}
          </div>
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl rounded-tl-none p-5 text-white/90 leading-relaxed border border-white/10 shadow-xl">
            {message.content}
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 30, scale: 0.95 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 30, scale: 0.95 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex items-start gap-4 justify-end"
    >
      <div className="flex-1 max-w-[85%]">
        <div className="flex items-center justify-end gap-2 mb-2">
          <span className="text-blue-300 text-sm font-semibold">我</span>
        </div>
        <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl rounded-tr-none p-5 text-white leading-relaxed shadow-xl shadow-blue-500/20">
          {message.content}
        </div>
      </div>
      <div className="w-10 h-10 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
        <User className="w-5 h-5 text-white" />
      </div>
    </motion.div>
  );
}

// 打字机指示器
function TypingIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex items-start gap-4"
    >
      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
        <Sparkles className="w-5 h-5 text-white" />
      </div>
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl rounded-tl-none p-4 border border-white/10">
        <div className="flex gap-1">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="w-2 h-2 bg-purple-400 rounded-full"
              animate={{ y: [0, -6, 0], opacity: [0.5, 1, 0.5] }}
              transition={{ 
                duration: 0.6, 
                repeat: Infinity, 
                delay: i * 0.15,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
