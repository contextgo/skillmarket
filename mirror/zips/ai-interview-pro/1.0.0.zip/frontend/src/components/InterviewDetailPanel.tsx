import {useMemo, useState} from 'react';
import {AnimatePresence, motion} from 'framer-motion';
import {getScoreColor, calculateOverallScore} from '../utils/score';
import type {InterviewDetail} from '../api/history';

interface InterviewDetailPanelProps {
  interview: InterviewDetail;
}

/**
 * 面试详情面板组件
 */
export default function InterviewDetailPanel({ interview }: InterviewDetailPanelProps) {
  // 默认展开所有题目
  const [expandedQuestions, setExpandedQuestions] = useState<Set<number>>(() => {
    const allIndices = new Set<number>();
    if (interview.answers) {
      interview.answers.forEach((_, idx) => allIndices.add(idx));
    }
    return allIndices;
  });

  const toggleQuestion = (index: number) => {
    setExpandedQuestions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  // 计算圆环进度和总分 - 完全使用前端实时计算
  const { displayScore, scorePercent, circumference, strokeDashoffset } = useMemo(() => {
    // 多维度模式下，实时计算三维综合分；普通模式下使用数据库中的 AI 总分
    const score = calculateOverallScore(interview);
    
    const percent = score !== null ? (score / 100) * 100 : 0;
    const circ = 2 * Math.PI * 54; // r=54
    const offset = circ - (percent / 100) * circ;
    
    return { 
      displayScore: score, 
      scorePercent: percent, 
      circumference: circ, 
      strokeDashoffset: offset 
    };
  }, [interview]);

  return (
      <motion.div
      className="space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* 评分卡片 */}
        <ScoreCard
        score={displayScore}
        feedback={interview.overallFeedback}
        scorePercent={scorePercent}
        circumference={circumference}
        strokeDashoffset={strokeDashoffset}
      />

      {/* 多维度评分条 */}
      <DimensionScoresBar interview={interview} />

      {/* 表现优势 */}
      {interview.strengths && interview.strengths.length > 0 && (
        <StrengthsSection strengths={interview.strengths} />
      )}

      {/* 改进建议 */}
      {interview.improvements && interview.improvements.length > 0 && (
        <ImprovementsSection improvements={interview.improvements} />
      )}

      {/* 问答记录详情 */}
        <QuestionsSection
        answers={interview.answers || []}
        expandedQuestions={expandedQuestions}
        toggleQuestion={toggleQuestion}
        enableMultiDimension={interview.enableMultiDimension}
      />
    </motion.div>
  );
}

// 多维度评分条组件
function DimensionScoresBar({ interview }: { interview: InterviewDetail }) {
  // 只有明确开启了多维度评估才显示
  if (!interview.enableMultiDimension) {
    return null;
  }
  
  // 优先使用 multiDimensionReport，如果没有则从 answers 中计算
  const dimensionScores = useMemo(() => {
    // 检查是否有多维度报告
    if (interview.multiDimensionReport) {
      const report = interview.multiDimensionReport;
      return [
        {
          name: '技术专家',
          role: 'Technical Expert',
          score: report.technicalScore,
          summary: report.technicalSummary || '暂无技术维度评价',
          gradient: 'from-blue-500 to-cyan-500',
          bgColor: 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 dark:from-blue-500/30 dark:to-cyan-500/30',
          borderColor: 'border-blue-200 dark:border-blue-800',
          textColor: 'text-blue-600 dark:text-blue-400',
          icon: (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )
        },
        {
          name: 'HR 经理',
          role: 'HR Manager',
          score: report.hrScore,
          summary: report.hrSummary || '暂无 HR 维度评价',
          gradient: 'from-purple-500 to-pink-500',
          bgColor: 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 dark:from-purple-500/30 dark:to-pink-500/30',
          borderColor: 'border-purple-200 dark:border-purple-800',
          textColor: 'text-purple-600 dark:text-purple-400',
          icon: (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
              <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M16 3.13C16.8604 3.35031 17.623 3.85071 18.1676 4.55232C18.7122 5.25392 19.0078 6.11684 19.0078 7.005C19.0078 7.89316 18.7122 8.75608 18.1676 9.45768C17.623 10.1593 16.8604 10.6597 16 10.88" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )
        },
        {
          name: '架构师',
          role: 'Architect',
          score: report.architectScore,
          summary: report.architectSummary || '暂无架构师维度评价',
          gradient: 'from-orange-500 to-red-500',
          bgColor: 'bg-gradient-to-r from-orange-500/20 to-red-500/20 dark:from-orange-500/30 dark:to-red-500/30',
          borderColor: 'border-orange-200 dark:border-orange-800',
          textColor: 'text-orange-600 dark:text-orange-400',
          icon: (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
              <rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
              <rect x="14" y="14" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
              <path d="M3 14H10V17H14V21H3V14Z" stroke="currentColor" strokeWidth="2"/>
            </svg>
          )
        }
      ];
    }
    
    // 如果没有多维度报告，则从 answers 中计算（向后兼容）
    if (!interview.answers || interview.answers.length === 0) {
      return null;
    }

    let technicalTotal = 0;
    let hrTotal = 0;
    let architectTotal = 0;
    let technicalFeedbacks: string[] = [];
    let hrFeedbacks: string[] = [];
    let architectFeedbacks: string[] = [];

    interview.answers.forEach(answer => {
      if (answer.technicalExpert) {
        technicalTotal += answer.technicalExpert.score;
        if (answer.technicalExpert.feedback) {
          technicalFeedbacks.push(answer.technicalExpert.feedback);
        }
      }
      if (answer.hrManager) {
        hrTotal += answer.hrManager.score;
        if (answer.hrManager.feedback) {
          hrFeedbacks.push(answer.hrManager.feedback);
        }
      }
      if (answer.architect) {
        architectTotal += answer.architect.score;
        if (answer.architect.feedback) {
          architectFeedbacks.push(answer.architect.feedback);
        }
      }
    });

    const count = interview.answers.length;
    if (count === 0) return null;

    // 计算各维度平均分
    const technicalAvg = Math.round(technicalTotal / count);
    const hrAvg = Math.round(hrTotal / count);
    const architectAvg = Math.round(architectTotal / count);

    // 汇总反馈（取前 3 条）
    const technicalSummary = technicalFeedbacks.slice(0, 3).join('\n\n');
    const hrSummary = hrFeedbacks.slice(0, 3).join('\n\n');
    const architectSummary = architectFeedbacks.slice(0, 3).join('\n\n');

    return [
      {
        name: '技术专家',
        role: 'Technical Expert',
        score: technicalAvg,
        summary: technicalSummary || '暂无技术维度评价',
        gradient: 'from-blue-500 to-cyan-500',
        bgColor: 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 dark:from-blue-500/30 dark:to-cyan-500/30',
        borderColor: 'border-blue-200 dark:border-blue-800',
        textColor: 'text-blue-600 dark:text-blue-400',
        icon: (
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        )
      },
      {
        name: 'HR 经理',
        role: 'HR Manager',
        score: hrAvg,
        summary: hrSummary || '暂无 HR 维度评价',
        gradient: 'from-purple-500 to-pink-500',
        bgColor: 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 dark:from-purple-500/30 dark:to-pink-500/30',
        borderColor: 'border-purple-200 dark:border-purple-800',
        textColor: 'text-purple-600 dark:text-purple-400',
        icon: (
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
            <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
            <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M16 3.13C16.8604 3.35031 17.623 3.85071 18.1676 4.55232C18.7122 5.25392 19.0078 6.11684 19.0078 7.005C19.0078 7.89316 18.7122 8.75608 18.1676 9.45768C17.623 10.1593 16.8604 10.6597 16 10.88" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        )
      },
      {
        name: '架构师',
        role: 'Architect',
        score: architectAvg,
        summary: architectSummary || '暂无架构师维度评价',
        gradient: 'from-orange-500 to-red-500',
        bgColor: 'bg-gradient-to-r from-orange-500/20 to-red-500/20 dark:from-orange-500/30 dark:to-red-500/30',
        borderColor: 'border-orange-200 dark:border-orange-800',
        textColor: 'text-orange-600 dark:text-orange-400',
        icon: (
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
            <rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
            <rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
            <rect x="14" y="14" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
            <path d="M3 14H10V17H14V21H3V14Z" stroke="currentColor" strokeWidth="2"/>
          </svg>
        )
      }
    ];
  }, [interview.multiDimensionReport, interview.answers, interview.enableMultiDimension]);

  if (!dimensionScores) {
    return null;
  }

  return (
    <motion.div
      className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
    >
      <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2">
        <svg className="w-5 h-5 text-primary-500" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        多维度评估
      </h4>
      
      <div className="grid gap-4 md:grid-cols-3">
        {dimensionScores.map((dim, index) => (
          <motion.div
            key={dim.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 + index * 0.1 }}
            className={`${dim.bgColor} ${dim.borderColor} rounded-xl p-4 border`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`flex items-center gap-2 ${dim.textColor}`}>
                {dim.icon}
                <span className="font-bold text-sm">{dim.name}</span>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r ${dim.gradient} text-white`}>
                {dim.score}分
              </span>
            </div>
            
            {/* 进度条 */}
            <div className="relative h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mb-4">
              <motion.div
                className={`absolute left-0 top-0 h-full bg-gradient-to-r ${dim.gradient}`}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(dim.score, 100)}%` }}
                transition={{ duration: 1, delay: 0.3 + index * 0.1 }}
              />
            </div>
            
            {/* 维度总结 */}
            <div className="mt-3">
              <p className={`text-xs font-medium ${dim.textColor} mb-2 flex items-center gap-1`}>
                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none">
                  <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                维度总结
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-line">
                {dim.summary}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

// 评分卡片组件
function ScoreCard({
  score,
  feedback,
  // scorePercent, // 暂时未使用
  circumference,
  strokeDashoffset
}: {
  score: number | null;
  feedback: string | null;
  scorePercent: number;
  circumference: number;
  strokeDashoffset: number;
}) {
  return (
    <div className="bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 rounded-2xl p-8 text-white">
      <div className="flex flex-col items-center text-center">
        {/* 圆环进度条 */}
        <div className="relative w-32 h-32 mb-6">
          <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
            <circle
              cx="60"
              cy="60"
              r="54"
              stroke="rgba(255,255,255,0.2)"
              strokeWidth="8"
              fill="none"
            />
            <motion.circle
              cx="60"
              cy="60"
              r="54"
              stroke="white"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.span
              className="text-4xl font-bold"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              {score ?? '-'}
            </motion.span>
            <span className="text-sm text-white/70">总分</span>
          </div>
        </div>

        <h3 className="text-2xl font-bold mb-3">面试评估</h3>
        <p className="text-white/90 max-w-2xl leading-relaxed">
          {feedback || '表现良好，展示了扎实的技术基础。'}
        </p>
      </div>
    </div>
  );
}

// 优势部分组件
function StrengthsSection({ strengths }: { strengths: string[] }) {
  return (
      <motion.div
          className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
        <h4 className="font-semibold text-emerald-600 dark:text-emerald-400 mb-4 flex items-center gap-2">
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <polyline points="22,4 12,14.01 9,11.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        表现优势
      </h4>
      <ul className="space-y-3">
        {strengths.map((s: string, i: number) => (
            <li key={i} className="text-slate-700 dark:text-slate-300 flex items-start gap-3">
            <span className="w-2 h-2 bg-primary-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>{s}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

// 改进建议部分组件
function ImprovementsSection({ improvements }: { improvements: string[] }) {
  return (
      <motion.div
          className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
        <h4 className="font-semibold text-amber-600 dark:text-amber-400 mb-4 flex items-center gap-2">
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
          <line x1="12" y1="8" x2="12" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          <line x1="12" y1="16" x2="12.01" y2="16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        </svg>
        改进建议
      </h4>
      <ul className="space-y-3">
        {improvements.map((s: string, i: number) => (
            <li key={i} className="text-slate-700 dark:text-slate-300 flex items-start gap-3">
            <span className="w-2 h-2 bg-amber-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>{s}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

// 问答部分组件
function QuestionsSection({
  answers,
  expandedQuestions,
  toggleQuestion,
  enableMultiDimension
}: {
  answers: any[];
  expandedQuestions: Set<number>;
  toggleQuestion: (index: number) => void;
  enableMultiDimension?: boolean;
}) {
  return (
    <div>
      <h4 className="font-semibold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
        <svg className="w-5 h-5 text-primary-500" viewBox="0 0 24 24" fill="none">
          <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        问答记录详情
      </h4>

      <div className="space-y-4">
        {answers.map((answer, idx) => (
          <QuestionCard
            key={idx}
            answer={answer}
            index={idx}
            isExpanded={expandedQuestions.has(idx)}
            onToggle={() => toggleQuestion(idx)}
            enableMultiDimension={enableMultiDimension}
          />
        ))}
      </div>
    </div>
  );
}

// 三维度评分组件
function DimensionScores({ answer }: { answer: any }) {
  if (!answer.technicalExpert && !answer.hrManager && !answer.architect) {
    return null;
  }

  const dimensions = [
    {
      name: '技术专家',
      role: 'Technical Expert',
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      gradient: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20',
      borderColor: 'border-blue-200 dark:border-blue-800',
      scoreColor: 'text-blue-600 dark:text-blue-400',
      data: answer.technicalExpert
    },
    {
      name: 'HR 经理',
      role: 'HR Manager',
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
          <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
          <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M16 3.13C16.8604 3.35031 17.623 3.85071 18.1676 4.55232C18.7122 5.25392 19.0078 6.11684 19.0078 7.005C19.0078 7.89316 18.7122 8.75608 18.1676 9.45768C17.623 10.1593 16.8604 10.6597 16 10.88" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      gradient: 'from-purple-500 to-pink-500',
      bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20',
      borderColor: 'border-purple-200 dark:border-purple-800',
      scoreColor: 'text-purple-600 dark:text-purple-400',
      data: answer.hrManager
    },
    {
      name: '架构师',
      role: 'Architect',
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
          <rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
          <rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
          <rect x="14" y="14" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
          <path d="M3 14H10V17H14V21H3V14Z" stroke="currentColor" strokeWidth="2"/>
        </svg>
      ),
      gradient: 'from-orange-500 to-red-500',
      bgColor: 'bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20',
      borderColor: 'border-orange-200 dark:border-orange-800',
      scoreColor: 'text-orange-600 dark:text-orange-400',
      data: answer.architect
    }
  ];

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-600 dark:text-slate-400 font-medium flex items-center gap-2">
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        多维度评估
      </p>
      
      <div className="grid gap-4">
        {dimensions.map((dim, index) => (
          <motion.div
            key={dim.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`${dim.bgColor} ${dim.borderColor} rounded-xl p-5 border shadow-sm`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`flex items-center gap-3`}>
                <div className={`p-2 bg-gradient-to-br ${dim.gradient} rounded-lg text-white`}>
                  {dim.icon}
                </div>
                <div>
                  <h4 className={`font-bold ${dim.scoreColor}`}>{dim.name}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{dim.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-4 py-2 rounded-full text-sm font-bold bg-gradient-to-r ${dim.gradient} text-white shadow-md`}>
                  {dim.data?.score ?? '-'}分
                </span>
              </div>
            </div>
            <p className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed pl-[52px]">
              {dim.data?.feedback || '暂无评价'}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// 问题卡片组件
function QuestionCard({
  answer,
  index,
  isExpanded,
  onToggle,
  enableMultiDimension
}: {
  answer: any;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
  enableMultiDimension?: boolean;
}) {
  // 计算单题分数：如果有多维度评分，使用三维综合分；否则使用基础评分
  const calculateScore = () => {
    // 只有开启多维度评估时才使用三维综合分
    if (enableMultiDimension && (answer.technicalExpert || answer.hrManager || answer.architect)) {
      // 有多维度评估时，计算三维综合分
      const technicalScore = answer.technicalExpert?.score ?? 0;
      const hrScore = answer.hrManager?.score ?? 0;
      const architectScore = answer.architect?.score ?? 0;
      
      // 综合分 = 技术 40% + HR 30% + 架构师 30%
      return Math.round(technicalScore * 0.4 + hrScore * 0.3 + architectScore * 0.3);
    } else {
      // 无多维度评估时，使用基础评分
      return answer.score ?? 0;
    }
  };
  
  const displayedScore = calculateScore();
  
  return (
      <motion.div
          className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm overflow-hidden"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 + index * 0.05 }}
    >
      {/* 问题头部 */}
        <div
            className="px-5 py-4 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          <span
              className="w-8 h-8 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg flex items-center justify-center text-sm font-semibold">
            {answer.questionIndex + 1}
          </span>
          <span
              className="px-3 py-1 bg-primary-50 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 text-xs font-medium rounded-full">
            {answer.category || '综合'}
          </span>
          <span className={`font-semibold ${getScoreColor(displayedScore, [80, 60])}`}>
            得分：{displayedScore}
          </span>
        </div>
          <motion.svg
          className="w-5 h-5 text-slate-400"
          animate={{ rotate: isExpanded ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          viewBox="0 0 24 24"
          fill="none"
        >
          <polyline points="6,9 12,15 18,9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </motion.svg>
      </div>

      {/* 问题内容 */}
      <div className="px-5 pb-2">
        <p className="text-slate-800 dark:text-white font-medium leading-relaxed">{answer.question}</p>
      </div>

      {/* 展开内容 */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-4">
              {/* 你的回答 */}
              <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-4">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-1">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  你的回答
                </p>
                <p className={`leading-relaxed ${
                  !answer.userAnswer || answer.userAnswer === '不知道' 
                    ? 'text-red-500 font-medium'
                      : 'text-slate-700 dark:text-slate-300'
                }`}>
                  "{answer.userAnswer || '(未回答)'}"
                </p>
              </div>

              {/* AI 深度评价 */}
              {answer.feedback && (
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2 font-medium">
                    <svg className="w-4 h-4 text-primary-500" viewBox="0 0 24 24" fill="none">
                      <path d="M3 3V21H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M18 9L12 15L9 12L3 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    AI 综合评价
                  </p>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed pl-6">{answer.feedback}</p>
                </div>
              )}

              {/* 三维度评分 - 只有开启多维度评估才显示 */}
              {enableMultiDimension && <DimensionScores answer={answer} />}
                            
              {/* 参考答案 */}
              {answer.referenceAnswer && (
                  <div
                      className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-4 border border-slate-100 dark:border-slate-600">
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-3 flex items-center gap-2 font-medium">
                    <svg className="w-4 h-4 text-primary-500" viewBox="0 0 24 24" fill="none">
                      <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="2"/>
                      <path d="M9 12H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M12 9V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    参考答案
                  </p>
                    <div
                        className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">{answer.referenceAnswer}</div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
