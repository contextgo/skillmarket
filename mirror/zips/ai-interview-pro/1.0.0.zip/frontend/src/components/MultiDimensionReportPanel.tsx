import { useState } from 'react';
import { motion } from 'framer-motion';
import { getScoreColor } from '../utils/score';

// 定义多维度报告数据类型
export interface MultiDimensionReport {
  sessionId: string;
  totalQuestions: number;
  overallScore: number;
  
  // 技术专家维度
  technicalScore: number;
  technicalFeedback: string;
  technicalStrengths: string[];
  technicalWeaknesses: string[];
  knowledgeGaps: string[];
  depthAnalysis: string;
  
  // HR 经理维度
  hrScore: number;
  hrFeedback: string;
  communicationStrengths: string[];
  softSkillsGaps: string[];
  learningPotential: string;
  cultureFit: string;
  careerAdvice: string;
  
  // 架构师维度
  architectScore: number;
  architectFeedback: string;
  systemDesignAbility: string;
  technicalDepth: string;
  engineeringPractice: string;
  innovationPotential: string;
  recommendedLevel: string;
  
  // 综合评价
  overallFeedback: string;
  strengths: string[];
  improvements: string[];
}

interface MultiDimensionReportPanelProps {
  report: MultiDimensionReport;
}

/**
 * 多维度评估报告面板（360 度评估）
 */
export default function MultiDimensionReportPanel({ report }: MultiDimensionReportPanelProps) {
  const [activeTab, setActiveTab] = useState<'overall' | 'technical' | 'hr' | 'architect'>('overall');

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* 顶部标签页切换 */}
      <div className="flex gap-2 border-b border-slate-200 dark:border-slate-700">
        <TabButton 
          active={activeTab === 'overall'} 
          onClick={() => setActiveTab('overall')}
          icon="📊"
          label="综合评估"
        />
        <TabButton 
          active={activeTab === 'technical'} 
          onClick={() => setActiveTab('technical')}
          icon="💻"
          label="技术专家"
        />
        <TabButton 
          active={activeTab === 'hr'} 
          onClick={() => setActiveTab('hr')}
          icon="👥"
          label="HR 经理"
        />
        <TabButton 
          active={activeTab === 'architect'} 
          onClick={() => setActiveTab('architect')}
          icon="🏗️"
          label="架构师"
        />
      </div>

      {/* 综合评分概览 */}
      <OverallScoreCard report={report} />

      {/* 根据标签页显示不同维度的内容 */}
      {activeTab === 'overall' && <OverallContent report={report} />}
      {activeTab === 'technical' && <TechnicalContent report={report} />}
      {activeTab === 'hr' && <HRContent report={report} />}
      {activeTab === 'architect' && <ArchitectContent report={report} />}
    </motion.div>
  );
}

// 标签页按钮
function TabButton({ active, onClick, icon, label }: { 
  active: boolean; 
  onClick: () => void; 
  icon: string; 
  label: string 
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-t-lg font-medium transition-all flex items-center gap-2 ${
        active 
          ? 'bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 border-b-2 border-purple-600' 
          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
      }`}
    >
      <span>{icon}</span>
      <span>{label}</span>
    </button>
  );
}

// 综合评分卡片
function OverallScoreCard({ report }: { report: MultiDimensionReport }) {
  return (
    <div className={`bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 rounded-2xl p-8 text-white shadow-xl`}>
      <div className="flex flex-col md:flex-row gap-8 items-center">
        {/* 总分圆环 */}
        <div className="relative w-40 h-40 flex-shrink-0">
          <svg className="w-40 h-40 transform -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="54" stroke="rgba(255,255,255,0.2)" strokeWidth="8" fill="none" />
            <motion.circle
              cx="60"
              cy="60"
              r="54"
              stroke="white"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 54}
              initial={{ strokeDashoffset: 2 * Math.PI * 54 }}
              animate={{ strokeDashoffset: 2 * Math.PI * 54 * (1 - report.overallScore / 100) }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-5xl font-bold">{report.overallScore}</span>
            <span className="text-sm opacity-80">综合得分</span>
          </div>
        </div>

        {/* 三个维度得分 */}
        <div className="flex-1 grid grid-cols-3 gap-4 w-full">
          <DimensionScoreCard 
            icon="💻" 
            label="技术专家" 
            score={report.technicalScore} 
            color="from-blue-500 to-cyan-500"
          />
          <DimensionScoreCard 
            icon="👥" 
            label="HR 经理" 
            score={report.hrScore} 
            color="from-green-500 to-emerald-500"
          />
          <DimensionScoreCard 
            icon="🏗️" 
            label="架构师" 
            score={report.architectScore} 
            color="from-purple-500 to-pink-500"
          />
        </div>
      </div>

      {/* 推荐职级 */}
      <div className="mt-6 pt-6 border-t border-white/20">
        <div className="flex items-center justify-between">
          <span className="opacity-80">推荐职级</span>
          <span className="text-xl font-bold bg-white/20 px-4 py-2 rounded-lg">
            {report.recommendedLevel || '待定'}
          </span>
        </div>
      </div>
    </div>
  );
}

// 维度得分卡片
function DimensionScoreCard({ icon, label, score, color }: {
  icon: string;
  label: string;
  score: number;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-xl p-4 text-center shadow-lg`}>
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-xs opacity-80 mb-1">{label}</div>
      <div className="text-3xl font-bold">{score}</div>
    </div>
  );
}

// 综合评估内容
function OverallContent({ report }: { report: MultiDimensionReport }) {
  return (
    <>
      {/* 综合评语 */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <span>📝</span>
          综合评语
        </h3>
        <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
          {report.overallFeedback || '暂无综合评语'}
        </p>
      </div>

      {/* 优势与改进 */}
      <div className="grid md:grid-cols-2 gap-4">
        <StrengthsCard strengths={report.strengths} />
        <ImprovementsCard improvements={report.improvements} />
      </div>
    </>
  );
}

// 技术专家维度内容
function TechnicalContent({ report }: { report: MultiDimensionReport }) {
  return (
    <>
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <span>💻</span>
          技术专家评价
        </h3>
        <p className="text-slate-700 dark:text-slate-300 leading-relaxed mb-6">
          {report.technicalFeedback}
        </p>
        
        <h4 className="font-medium mb-3">技术优势</h4>
        <ul className="space-y-2 mb-6">
          {report.technicalStrengths.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
              <span className="text-green-500 mt-1">✓</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>

        <h4 className="font-medium mb-3">待提升领域</h4>
        <ul className="space-y-2 mb-6">
          {report.technicalWeaknesses.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
              <span className="text-amber-500 mt-1">!</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>

        <h4 className="font-medium mb-3">知识盲区</h4>
        <div className="flex flex-wrap gap-2">
          {report.knowledgeGaps.map((item, i) => (
            <span key={i} className="px-3 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-full text-sm">
              {item}
            </span>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
          <h4 className="font-medium mb-2">深度分析</h4>
          <p className="text-slate-700 dark:text-slate-300">{report.depthAnalysis}</p>
        </div>
      </div>
    </>
  );
}

// HR 经理维度内容
function HRContent({ report }: { report: MultiDimensionReport }) {
  return (
    <>
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <span>👥</span>
          HR 经理评价
        </h3>
        <p className="text-slate-700 dark:text-slate-300 leading-relaxed mb-6">
          {report.hrFeedback}
        </p>

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div>
            <h4 className="font-medium mb-3">沟通优势</h4>
            <ul className="space-y-2">
              {report.communicationStrengths.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-3">软技能不足</h4>
            <ul className="space-y-2">
              {report.softSkillsGaps.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                  <span className="text-amber-500 mt-1">!</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-4">
          <InfoBlock label="学习潜力" value={report.learningPotential} />
          <InfoBlock label="文化匹配度" value={report.cultureFit} />
          <InfoBlock label="职业建议" value={report.careerAdvice} icon="💡" />
        </div>
      </div>
    </>
  );
}

// 架构师维度内容
function ArchitectContent({ report }: { report: MultiDimensionReport }) {
  return (
    <>
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <span>🏗️</span>
          架构师评价
        </h3>
        <p className="text-slate-700 dark:text-slate-300 leading-relaxed mb-6">
          {report.architectFeedback}
        </p>

        <div className="space-y-4">
          <InfoBlock label="系统设计能力" value={report.systemDesignAbility} icon="🎯" />
          <InfoBlock label="技术深度" value={report.technicalDepth} icon="📚" />
          <InfoBlock label="工程实践" value={report.engineeringPractice} icon="⚙️" />
          <InfoBlock label="创新潜力" value={report.innovationPotential} icon="🚀" />
        </div>

        <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <span className="font-medium">推荐职级</span>
            <span className="text-lg font-bold text-purple-600 dark:text-purple-400">
              {report.recommendedLevel}
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

// 优势卡片
function StrengthsCard({ strengths }: { strengths: string[] }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
      <h3 className="font-semibold text-green-600 dark:text-green-400 mb-4 flex items-center gap-2">
        <span>✓</span>
        综合优势
      </h3>
      <ul className="space-y-2">
        {strengths.map((item, i) => (
          <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
            <span className="text-green-500 mt-1">✓</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// 改进建议卡片
function ImprovementsCard({ improvements }: { improvements: string[] }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">
      <h3 className="font-semibold text-amber-600 dark:text-amber-400 mb-4 flex items-center gap-2">
        <span>!</span>
        改进建议
      </h3>
      <ul className="space-y-2">
        {improvements.map((item, i) => (
          <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
            <span className="text-amber-500 mt-1">!</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// 信息块组件
function InfoBlock({ label, value, icon }: { label: string; value: string; icon?: string }) {
  return (
    <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
      <div className="flex items-center gap-2 mb-2">
        {icon && <span>{icon}</span>}
        <span className="font-medium text-slate-700 dark:text-slate-300">{label}</span>
      </div>
      <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">{value}</p>
    </div>
  );
}
