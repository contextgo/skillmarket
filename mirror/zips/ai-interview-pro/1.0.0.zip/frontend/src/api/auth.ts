import { request } from './request';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  phone: string;
  email?: string;
}

export interface UserInfo {
  id: number;
  username: string;
  email: string | null;
  avatarUrl: string | null;
  roles: string[];
  permissions: string[];
}

export interface LoginResponse {
  token: string;
  type: string;
  expiresIn: number;
  user: UserInfo;
}

export interface UserDTO {
  id: number;
  username: string;
  email: string | null;
  phone: string | null;
  avatarUrl: string | null;
  status: 'ACTIVE' | 'DISABLED' | 'LOCKED';
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
  roles: string[];
}

export interface CreateUserRequest {
  username: string;
  password: string;
  email?: string;
  phone?: string;
  avatarUrl?: string;
}

export const authApi = {
  /**
   * 用户登录
   */
  async login(data: LoginRequest): Promise<LoginResponse> {
    return request.post<LoginResponse>('/api/auth/login', data);
  },

  /**
   * 用户注册
   */
  async register(data: RegisterRequest): Promise<LoginResponse> {
    return request.post<LoginResponse>('/api/auth/register', data);
  },

  /**
   * 用户登出
   */
  async logout(): Promise<void> {
    return request.post<void>('/api/auth/logout');
  },

  /**
   * 获取当前用户信息
   */
  async getCurrentUser(): Promise<UserInfo> {
    return request.get<UserInfo>('/api/auth/me');
  },
};

export const userApi = {
  /**
   * 获取所有用户（管理员）
   */
  async getAllUsers(): Promise<UserDTO[]> {
    return request.get<UserDTO[]>('/api/admin/users');
  },

  /**
   * 根据 ID 获取用户
   */
  async getUserById(id: number): Promise<UserDTO> {
    return request.get<UserDTO>(`/api/admin/users/${id}`);
  },

  /**
   * 创建用户
   */
  async createUser(data: CreateUserRequest): Promise<UserDTO> {
    return request.post<UserDTO>('/api/admin/users', data);
  },

  /**
   * 更新用户状态
   */
  async updateUserStatus(id: number, status: 'ACTIVE' | 'DISABLED' | 'LOCKED'): Promise<UserDTO> {
    return request.put<UserDTO>(`/api/admin/users/${id}/status?status=${status}`);
  },

  /**
   * 删除用户
   */
  async deleteUser(id: number): Promise<void> {
    return request.delete(`/api/admin/users/${id}`);
  },
};

/**
 * 本地存储键名
 */
const TOKEN_KEY = 'auth_token';
const USER_KEY = 'user_info';

/**
 * 检查是否已认证
 */
export function isAuthenticated(): boolean {
  const token = localStorage.getItem(TOKEN_KEY);
  return !!token;
}

/**
 * 获取本地存储的用户信息
 */
export function getLocalUser(): UserInfo | null {
  const userStr = localStorage.getItem(USER_KEY);
  if (!userStr) return null;
  try {
    return JSON.parse(userStr) as UserInfo;
  } catch (e) {
    console.error('解析用户信息失败', e);
    return null;
  }
}

/**
 * 保存 Token 和用户信息到本地存储
 */
export function saveAuth(token: string, user: UserInfo): void {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

/**
 * 清除认证信息
 */
export function logout(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  window.location.href = '/login';
}

/**
 * 获取 Token
 */
export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}
