import { request } from './request';
import type { UploadResponse } from '../types/resume';

export const resumeApi = {
  /**
   * 上传简历并获取分析结果
   */
  async uploadAndAnalyze(file: File): Promise<UploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      return await request.upload<UploadResponse>('/api/resumes/upload', formData);
    } catch (error) {
      console.error('[Resume API] Upload failed:', error);
      // 如果是 JSON 解析错误，可能是后端返回了错误格式
      if (error instanceof Error && error.message.includes('JSON')) {
        throw new Error('服务器响应格式错误，请刷新页面后重试');
      }
      throw error;
    }
  },

  /**
   * 健康检查
   */
  async healthCheck(): Promise<{ status: string; service: string }> {
    return request.get('/api/resumes/health');
  },
};
