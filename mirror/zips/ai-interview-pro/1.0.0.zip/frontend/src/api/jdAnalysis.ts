import request from './request';

/**
 * JD 分析请求参数
 */
export interface JdAnalysisRequest {
  companyName?: string;
  position: string;
  jdText: string;
  resumeText?: string;
  enableMatchAnalysis?: boolean;
}

/**
 * JD 分析响应
 */
export interface JdAnalysisResponse {
  id?: number;
  companyName?: string;
  position: string;
  jobDescription?: {
    overview: string;
    responsibilities: string[];
    workLocation?: string;
    department?: string;
  };
  requirementAnalysis?: {
    experienceYears: string;
    educationLevel: string;
    major?: string;
    hardRequirements: string[];
    softSkills: string[];
  };
  skillAnalysis?: {
    technicalSkills: string[];
    toolSkills: string[];
    languageSkills: string[];
    recommendedSkills: string[];
  };
  interviewPreparation?: {
    possibleQuestions: string[];
    preparationSuggestions: string[];
    resumeOptimizationTips: string[];
  };
  salaryRange?: string;
  experienceRequirement?: string;
  educationRequirement?: string;
  keySkills?: string[];
  matchScore?: number;
  matchAnalysis?: {
    matchScore: number;
    strengths: string[];
    weaknesses: string[];
    improvementSuggestions: string[];
  };
}

/**
 * JD 分析历史记录
 */
export interface JdAnalysisHistory {
  id: number;
  companyName?: string;
  position: string;
  createdAt: string;
  matchScore?: number;
}

/**
 * 分析岗位 JD
 */
export const analyzeJd = async (data: JdAnalysisRequest): Promise<JdAnalysisResponse> => {
  return request.post<JdAnalysisResponse>('/api/jd-analysis/analyze', data);
};

/**
 * 获取分析历史
 */
export const getAnalysisHistory = async (): Promise<JdAnalysisHistory[]> => {
  return request.get<JdAnalysisHistory[]>('/api/jd-analysis/history');
};

/**
 * 获取分析详情
 */
export const getAnalysisDetail = async (id: number): Promise<JdAnalysisResponse> => {
  return request.get<JdAnalysisResponse>(`/api/jd-analysis/${id}`);
};
