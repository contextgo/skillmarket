import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText, Briefcase, Sparkles, Send, Loader2, CheckCircle2, AlertCircle, Upload, FileCheck } from 'lucide-react';
import { analyzeJd, getAnalysisHistory } from '../api/jdAnalysis';
import { resumeApi } from '../api/resume';
import { getErrorMessage } from '../api/request';
import type { JdAnalysisRequest, JdAnalysisResponse } from '../api/jdAnalysis';

export default function JdAnalysisPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<JdAnalysisRequest>({
    position: '',
    jdText: '',
    companyName: '',
    enableMatchAnalysis: false,
  });
  const [loading, setLoading] = useState(false);
  const [analyzeStatus, setAnalyzeStatus] = useState<'PENDING' | 'PROCESSING' | 'STARTED' | null>(null);
  const [result, setResult] = useState<JdAnalysisResponse | null>(null);
  const [error, setError] = useState('');
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [uploadingResume, setUploadingResume] = useState(false);
  const [resumeId, setResumeId] = useState<number | null>(null);
  const [resumeText, setResumeText] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 检查用户是否登录
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    if (!token) {
      setError('请先登录系统后再使用 JD 分析功能');
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 检查登录状态
    const token = localStorage.getItem('auth_token');
    if (!token) {
      setError('请先登录系统后再使用 JD 分析功能');
      navigate('/login');
      return;
    }
    
    console.log('[JD Analysis] 开始提交表单数据:', formData);
    setError('');
    setLoading(true);

    try {
      setAnalyzeStatus('STARTED');
      // 如果启用了匹配分析且上传了简历，需要包含简历文本
      const requestData = { ...formData };
      if (formData.enableMatchAnalysis && resumeText) {
        requestData.resumeText = resumeText;
        console.log('[JD Analysis] 启用了匹配分析，包含简历文本，长度:', resumeText.length);
      }
      console.log('[JD Analysis] 发送 API 请求:', requestData);
      const response = await analyzeJd(requestData);
      console.log('[JD Analysis] API 响应:', JSON.stringify(response, null, 2));
      setResult(response);
      setAnalyzeStatus(null);
    } catch (err) {
      console.error('[JD Analysis] 请求失败:', err);
      const errorMsg = getErrorMessage(err);
      setError(errorMsg);
      // 如果是 401 错误，跳转到登录页
      if (errorMsg.includes('登录') || errorMsg.includes('token') || errorMsg.includes('认证')) {
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResumeUpload = async (file: File) => {
    setUploadingResume(true);
    setError('');

    try {
      const data = await resumeApi.uploadAndAnalyze(file);
      if (!data.storage || !data.storage.resumeId) {
        throw new Error('简历上传失败，请重试');
      }
      setResumeId(data.storage.resumeId);
      setResumeFile(file);
      // 如果返回了分析结果，保存简历文本
      if (data.analysis && data.analysis.originalText) {
        setResumeText(data.analysis.originalText);
        console.log('[JD Analysis] 简历文本已保存:', data.analysis.originalText.substring(0, 100) + '...');
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setUploadingResume(false);
    }
  };

  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleResumeUpload(file);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center text-white shadow-lg">
            <Briefcase className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
              岗位 JD 解析
            </h1>
            <p className="text-slate-600 dark:text-slate-400">
              AI 智能分析岗位要求，生成专业分析报告
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 左侧：输入表单 */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* 公司名称 */}
              <div>
                <label htmlFor="companyName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  公司名称（可选）
                </label>
                <input
                  id="companyName"
                  name="companyName"
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  placeholder="例如：阿里巴巴、腾讯"
                />
              </div>

              {/* 岗位名称 */}
              <div>
                <label htmlFor="position" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  岗位名称 <span className="text-red-500">*</span>
                </label>
                <input
                  id="position"
                  name="position"
                  type="text"
                  required
                  value={formData.position}
                  onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                  placeholder="例如：Java 开发工程师、产品经理"
                />
              </div>

              {/* JD 文本 */}
              <div>
                <label htmlFor="jdText" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  岗位 JD 内容 <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="jdText"
                  name="jdText"
                  required
                  value={formData.jdText}
                  onChange={(e) => setFormData({ ...formData, jdText: e.target.value })}
                  rows={10}
                  className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
                  placeholder="请粘贴完整的岗位描述（JD）内容..."
                />
              </div>

              {/* 匹配分析选项 */}
              <div className="flex items-center gap-2 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800">
                <input
                  type="checkbox"
                  id="matchAnalysis"
                  checked={formData.enableMatchAnalysis}
                  onChange={(e) => setFormData({ ...formData, enableMatchAnalysis: e.target.checked })}
                  className="w-4 h-4 text-primary-500 rounded focus:ring-primary-500"
                />
                <label htmlFor="matchAnalysis" className="text-sm text-slate-700 dark:text-slate-300 cursor-pointer flex-1">
                  <span className="font-medium">启用人岗匹配分析</span>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    启用后可以上传个人简历，AI 将分析你与岗位的匹配度
                  </p>
                </label>
              </div>

              {/* 简历上传区域（仅在启用匹配分析时显示） */}
              {formData.enableMatchAnalysis && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="p-4 bg-green-50 dark:bg-green-900/20 rounded-xl border border-green-100 dark:border-green-800"
                >
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    上传个人简历
                    {resumeFile && (
                      <span className="ml-2 text-green-600 dark:text-green-400 text-xs">
                        ✓ 已上传：{resumeFile.name}
                      </span>
                    )}
                  </label>
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-green-300 dark:border-green-700 rounded-lg p-6 text-center cursor-pointer hover:border-green-500 dark:hover:border-green-600 transition-colors"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf,.doc,.docx,.txt"
                      onChange={onFileSelect}
                      className="hidden"
                    />
                    {uploadingResume ? (
                      <div className="flex items-center justify-center gap-2 text-slate-600 dark:text-slate-400">
                        <Loader2 className="w-6 h-6 animate-spin" />
                        <span>正在上传简历...</span>
                      </div>
                    ) : resumeFile ? (
                      <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400">
                        <FileCheck className="w-8 h-8" />
                        <span className="text-sm">点击更换简历</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2 text-slate-600 dark:text-slate-400">
                        <Upload className="w-8 h-8" />
                        <div>
                          <p className="text-sm font-medium">点击上传简历</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            支持 PDF, DOCX, TXT 格式，最大 10MB
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* 提交按钮 */}
              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white rounded-xl font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-primary-500/30"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>正在分析...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>开始分析</span>
                  </>
                )}
              </button>

              {/* 错误提示 */}
              {error && (
                <div className="flex items-start gap-2 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
                  {error.includes('登录') && (
                    <button
                      onClick={() => navigate('/login')}
                      className="ml-auto text-sm text-primary-500 hover:text-primary-600 font-medium"
                    >
                      去登录
                    </button>
                  )}
                </div>
              )}
            </form>
          </div>
        </motion.div>

        {/* 右侧：分析结果 */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-1"
        >
          {result ? (
            <AnalysisResult result={result} />
          ) : (
            <div className="h-full bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-6 flex items-center justify-center">
              <div className="text-center">
                <FileText className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400">
                  在左侧输入岗位 JD 后点击"开始分析"<br />即可在此查看专业的分析报告
                </p>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

// 分析结果展示组件
function AnalysisResult({ result }: { result: JdAnalysisResponse }) {
  // 检查是否有匹配分数
  const hasMatchScore = result.matchScore !== undefined && result.matchScore !== null;
  const hasMatchAnalysis = result.matchAnalysis !== undefined && result.matchAnalysis !== null;
  
  console.log('[AnalysisResult] matchScore:', result.matchScore);
  console.log('[AnalysisResult] matchAnalysis:', result.matchAnalysis);
  console.log('[AnalysisResult] hasMatchScore:', hasMatchScore, 'hasMatchAnalysis:', hasMatchAnalysis);
  
  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-6 space-y-6">
      {/* 匹配分数（如果有） */}
      {(hasMatchScore || hasMatchAnalysis) && (
        <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl border border-green-200 dark:border-green-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-green-800 dark:text-green-300">人岗匹配度</span>
            <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
          </div>
          {hasMatchScore && (
            <div className="text-3xl font-bold text-green-700 dark:text-green-300 mb-2">
              {(result.matchScore ?? 0).toFixed(1)}%
            </div>
          )}
          {hasMatchAnalysis && result.matchAnalysis && (
            <div className="space-y-2">
              {result.matchAnalysis.strengths && result.matchAnalysis.strengths.length > 0 && (
                <div>
                  <h4 className="text-xs font-medium text-green-700 dark:text-green-400 mb-1">✓ 优势</h4>
                  <ul className="text-sm text-green-600 dark:text-green-300 space-y-0.5">
                    {result.matchAnalysis.strengths.map((item, index) => (
                      <li key={index}>• {item}</li>
                    ))}
                  </ul>
                </div>
              )}
              {result.matchAnalysis.weaknesses && result.matchAnalysis.weaknesses.length > 0 && (
                <div>
                  <h4 className="text-xs font-medium text-green-700 dark:text-green-400 mb-1">⚠ 待提升</h4>
                  <ul className="text-sm text-green-600 dark:text-green-300 space-y-0.5">
                    {result.matchAnalysis.weaknesses.map((item, index) => (
                      <li key={index}>• {item}</li>
                    ))}
                  </ul>
                </div>
              )}
              {result.matchAnalysis.improvementSuggestions && result.matchAnalysis.improvementSuggestions.length > 0 && (
                <div>
                  <h4 className="text-xs font-medium text-green-700 dark:text-green-400 mb-1">💡 建议</h4>
                  <ul className="text-sm text-green-600 dark:text-green-300 space-y-0.5">
                    {result.matchAnalysis.improvementSuggestions.map((item, index) => (
                      <li key={index}>• {item}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 岗位概述 */}
      {result.jobDescription && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-primary-500" />
            岗位概述
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {result.jobDescription.overview}
          </p>
          {result.jobDescription.responsibilities && result.jobDescription.responsibilities.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">主要职责</h4>
              <ul className="space-y-1">
                {result.jobDescription.responsibilities.map((item, index) => (
                  <li key={index} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                    <span className="text-primary-500 mt-1">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* 任职要求 */}
      {result.requirementAnalysis && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary-500" />
            任职要求
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">经验要求</div>
              <div className="text-sm font-medium text-slate-800 dark:text-white">{result.requirementAnalysis.experienceYears}</div>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">学历要求</div>
              <div className="text-sm font-medium text-slate-800 dark:text-white">{result.requirementAnalysis.educationLevel}</div>
            </div>
          </div>
          {result.requirementAnalysis.hardRequirements && result.requirementAnalysis.hardRequirements.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">硬性要求</h4>
              <ul className="space-y-1">
                {result.requirementAnalysis.hardRequirements.map((item, index) => (
                  <li key={index} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                    <span className="text-red-500 mt-1">●</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* 技能分析 */}
      {result.skillAnalysis && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary-500" />
            技能要求
          </h3>
          <div className="flex flex-wrap gap-2">
            {result.skillAnalysis.technicalSkills?.map((skill, index) => (
              <span key={index} className="px-3 py-1.5 bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-lg text-sm font-medium">
                {skill}
              </span>
            ))}
          </div>
          {result.skillAnalysis.recommendedSkills && result.skillAnalysis.recommendedSkills.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">推荐补充</h4>
              <ul className="space-y-1">
                {result.skillAnalysis.recommendedSkills.map((item, index) => (
                  <li key={index} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                    <span className="text-blue-500 mt-1">◈</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* 面试准备 */}
      {result.interviewPreparation && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            💡 面试准备建议
          </h3>
          {result.interviewPreparation.possibleQuestions && result.interviewPreparation.possibleQuestions.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">可能的问题</h4>
              <ul className="space-y-2">
                {result.interviewPreparation.possibleQuestions.map((item, index) => (
                  <li key={index} className="text-sm text-slate-600 dark:text-slate-400 p-2 bg-yellow-50 dark:bg-yellow-900/10 rounded-lg">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
