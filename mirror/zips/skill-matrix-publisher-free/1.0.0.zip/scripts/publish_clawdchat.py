#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虾聊(ClawdChat)发布脚本
使用Playwright模拟浏览器上传
"""

import asyncio
import os
import sys
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("❌ 请先安装playwright: pip install playwright")
    print("然后运行: playwright install chromium")
    sys.exit(1)

async def publish_to_clawdchat(file_path, title, description="", tags=""):
    """
    发布文件到虾聊
    
    Args:
        file_path: ZIP文件路径
        title: 发布标题
        description: 发布描述
        tags: 标签（逗号分隔）
    """
    
    print(f"🦞 发布到虾聊...")
    print(f"📦 文件: {file_path}")
    print(f"📝 标题: {title}")
    
    async with async_playwright() as p:
        # 启动浏览器（显示模式，便于调试）
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(viewport={"width": 1280, "height": 800})
        page = await context.new_page()
        
        try:
            # 1. 访问虾聊
            print("🌐 打开虾聊...")
            await page.goto("https://clawdchat.cn/my", wait_until="networkidle")
            await page.wait_for_timeout(3000)
            
            # 2. 检查登录状态
            current_url = page.url
            if "login" in current_url or "signin" in current_url:
                print("⚠️ 请先登录虾聊")
                print("请在浏览器中完成登录，然后按回车继续...")
                input()
            
            # 3. 点击"New"按钮
            print("🖱️ 点击发布按钮...")
            try:
                new_button = await page.wait_for_selector('button:has-text("New")', timeout=5000)
                await new_button.click()
            except:
                try:
                    new_button = await page.wait_for_selector('text=New', timeout=5000)
                    await new_button.click()
                except:
                    print("⚠️ 找不到New按钮，请手动点击")
                    input("点击后按回车继续...")
            
            await page.wait_for_timeout(2000)
            
            # 4. 选择文件
            print("📤 选择文件...")
            file_input = await page.wait_for_selector('input[type="file"]', timeout=10000)
            await file_input.set_input_files(file_path)
            await page.wait_for_timeout(3000)
            
            # 5. 填写标题
            print("📝 填写标题...")
            try:
                title_input = await page.wait_for_selector('input[placeholder*="标题"], input[name="title"], textarea[placeholder*="标题"]', timeout=5000)
                await title_input.fill(title)
            except:
                print("⚠️ 找不到标题输入框，请手动填写")
            
            await page.wait_for_timeout(1000)
            
            # 6. 填写描述（如果有）
            if description:
                print("📝 填写描述...")
                try:
                    desc_input = await page.wait_for_selector('textarea[placeholder*="描述"], textarea[placeholder*="内容"]', timeout=5000)
                    await desc_input.fill(description)
                except:
                    pass
            
            await page.wait_for_timeout(1000)
            
            # 7. 点击发布
            print("🚀 点击发布...")
            try:
                publish_button = await page.wait_for_selector('button:has-text("发布"), button:has-text("Post"), button:has-text("Submit")', timeout=5000)
                await publish_button.click()
            except:
                print("⚠️ 找不到发布按钮，请手动点击")
                input("点击发布后按回车继续...")
            
            # 8. 等待发布完成
            print("⏳ 等待发布完成...")
            await page.wait_for_timeout(5000)
            
            # 获取当前URL
            final_url = page.url
            print(f"\n✅ 虾聊发布完成！")
            print(f"🔗 链接: {final_url}")
            
            await browser.close()
            return final_url
            
        except Exception as e:
            print(f"❌ 发布失败: {str(e)}")
            await browser.close()
            return None

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python publish_clawdchat.py <file_path> <title> [description] [tags]")
        sys.exit(1)
    
    file_path = sys.argv[1]
    title = sys.argv[2]
    description = sys.argv[3] if len(sys.argv) > 3 else ""
    tags = sys.argv[4] if len(sys.argv) > 4 else ""
    
    result = asyncio.run(publish_to_clawdchat(file_path, title, description, tags))
    
    if result:
        print(f"\n🎉 发布成功: {result}")
    else:
        print("\n❌ 发布失败")
        sys.exit(1)
