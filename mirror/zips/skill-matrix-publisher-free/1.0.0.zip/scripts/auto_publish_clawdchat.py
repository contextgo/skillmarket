#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虾聊自动发布脚本 - 后台运行版
不阻塞主流程，通过文件通信
"""

import asyncio
import os
import sys
import json
import time
from pathlib import Path

# 状态文件
STATUS_FILE = Path(__file__).parent.parent / "config" / "publish_status.json"

def save_status(status, data=None):
    """保存状态到文件"""
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATUS_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            "status": status,
            "data": data or {},
            "timestamp": time.time()
        }, f, indent=2, ensure_ascii=False)

def load_status():
    """加载状态"""
    if STATUS_FILE.exists():
        with open(STATUS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"status": "idle", "data": {}}

try:
    from playwright.async_api import async_playwright
except ImportError:
    save_status("error", {"message": "playwright未安装"})
    sys.exit(1)

async def auto_publish(skill_path, title=None, description=None):
    """
    自动发布到虾聊
    """
    skill_path = Path(skill_path)
    skill_name = skill_path.name
    
    if not title:
        title = skill_name
    
    save_status("packing", {"skill": skill_name})
    
    # 打包ZIP
    import zipfile
    zip_path = skill_path.parent / f"{skill_name}_SKILL.zip"
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(skill_path):
            dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', '.workbuddy']]
            for file in files:
                if file.endswith(('.pyc', '.tmp')):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, skill_path)
                zf.write(file_path, arcname)
    
    save_status("packed", {"zip": str(zip_path), "size": f"{zip_path.stat().st_size / 1024:.1f}KB"})
    
    # 读取描述
    if not description:
        skill_md = skill_path / "SKILL.md"
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
                for line in content.split('\n'):
                    if 'description' in line.lower() or '一句话介绍' in line:
                        description = line.split(':')[-1].strip()
                        break
    
    save_status("browser_starting", {"title": title})
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(viewport={"width": 1280, "height": 800})
        page = await context.new_page()
        
        try:
            # 访问虾聊（增加超时时间）
            try:
                await page.goto("https://clawdchat.cn/my", wait_until="domcontentloaded", timeout=60000)
            except:
                await page.goto("https://clawdchat.cn/my", timeout=60000)
            await page.wait_for_timeout(5000)
            
            # 检查登录状态
            current_url = page.url
            if "login" in current_url or "signin" in current_url:
                save_status("waiting_login", {
                    "url": "https://clawdchat.cn/my",
                    "message": "请在浏览器中登录虾聊，登录完成后回复: 已登录"
                })
                # 等待用户登录（通过文件检测）
                while True:
                    await asyncio.sleep(1)
                    status = load_status()
                    if status.get("status") == "login_completed":
                        break
                # 刷新页面
                await page.reload()
                await page.wait_for_timeout(3000)
            
            save_status("publishing", {"step": "寻找发布入口"})
            
            # 尝试多种方式找到发布按钮
            # 方式1: 找New按钮
            try:
                new_button = await page.wait_for_selector('button:has-text("New")', timeout=3000)
                await new_button.click()
                save_status("publishing", {"step": "已点击New按钮"})
            except:
                # 方式2: 找+按钮
                try:
                    plus_button = await page.wait_for_selector('button:has-text("+")', timeout=3000)
                    await plus_button.click()
                    save_status("publishing", {"step": "已点击+按钮"})
                except:
                    # 方式3: 找发布/Post按钮
                    try:
                        post_button = await page.wait_for_selector('button:has-text("Post"), button:has-text("发布")', timeout=3000)
                        await post_button.click()
                        save_status("publishing", {"step": "已点击发布按钮"})
                    except:
                        # 方式4: 直接访问发布页面
                        try:
                            await page.goto("https://clawdchat.cn/post/new", timeout=10000)
                            save_status("publishing", {"step": "已跳转到发布页面"})
                        except:
                            save_status("waiting_click", {"element": "发布按钮", "message": "请手动点击发布按钮（New/+号/发布）"})
                            while True:
                                await asyncio.sleep(1)
                                status = load_status()
                                if status.get("status") == "click_completed":
                                    break
            
            await page.wait_for_timeout(2000)
            
            save_status("publishing", {"step": "上传文件"})
            
            # 上传文件
            file_input = await page.wait_for_selector('input[type="file"]', timeout=10000)
            await file_input.set_input_files(str(zip_path))
            await page.wait_for_timeout(3000)
            
            save_status("publishing", {"step": "填写标题"})
            
            # 填写标题
            try:
                title_input = await page.wait_for_selector('input[placeholder*="title" i], input[name="title"]', timeout=5000)
                await title_input.fill(title)
            except:
                pass
            
            await page.wait_for_timeout(1000)
            
            # 填写描述
            if description:
                try:
                    desc_input = await page.wait_for_selector('textarea[placeholder*="description" i]', timeout=5000)
                    await desc_input.fill(description)
                except:
                    pass
            
            await page.wait_for_timeout(1000)
            
            save_status("waiting_publish", {
                "message": "请手动点击发布按钮，发布后按回车",
                "title": title
            })
            
            # 等待用户点击发布
            while True:
                await asyncio.sleep(1)
                status = load_status()
                if status.get("status") == "publish_clicked":
                    break
            
            await page.wait_for_timeout(5000)
            
            # 获取链接
            final_url = page.url
            
            if "post" in final_url:
                save_status("completed", {
                    "share_link": final_url,
                    "message": "发布成功！"
                })
            else:
                save_status("waiting_link", {
                    "current_url": final_url,
                    "message": "请手动复制分享链接"
                })
            
            await browser.close()
            
            # 清理
            if zip_path.exists():
                zip_path.unlink()
            
        except Exception as e:
            save_status("error", {"message": str(e)})
            await browser.close()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python auto_publish_clawdchat.py <skill_path>")
        sys.exit(1)
    
    skill_path = sys.argv[1]
    asyncio.run(auto_publish(skill_path))
