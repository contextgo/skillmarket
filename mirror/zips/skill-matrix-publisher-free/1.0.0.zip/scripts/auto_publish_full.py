#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虾聊全自动发布脚本 - 完全自动化版
登录后无需人工介入，自动完成所有步骤
"""

import asyncio
import os
import sys
import json
import time
from pathlib import Path

# 状态文件
STATUS_FILE = Path(__file__).parent.parent / "config" / "publish_status.json"

def save_status(status, data=None):
    """保存状态到文件"""
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATUS_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            "status": status,
            "data": data or {},
            "timestamp": time.time()
        }, f, indent=2, ensure_ascii=False)

try:
    from playwright.async_api import async_playwright
except ImportError:
    save_status("error", {"message": "playwright未安装"})
    sys.exit(1)

async def auto_publish(skill_path, title=None, description=None):
    """
    全自动发布到虾聊
    """
    skill_path = Path(skill_path)
    skill_name = skill_path.name
    
    if not title:
        title = skill_name
    
    save_status("packing", {"skill": skill_name})
    
    # 打包ZIP
    import zipfile
    zip_path = skill_path.parent / f"{skill_name}_SKILL.zip"
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(skill_path):
            dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', '.workbuddy']]
            for file in files:
                if file.endswith(('.pyc', '.tmp')):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, skill_path)
                zf.write(file_path, arcname)
    
    save_status("packed", {"zip": str(zip_path), "size": f"{zip_path.stat().st_size / 1024:.1f}KB"})
    
    # 读取描述
    if not description:
        skill_md = skill_path / "SKILL.md"
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
                for line in content.split('\n'):
                    if 'description' in line.lower() or '一句话介绍' in line:
                        description = line.split(':')[-1].strip()
                        break
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(viewport={"width": 1280, "height": 800})
        page = await context.new_page()
        
        try:
            # 1. 访问虾聊
            save_status("opening", {"url": "https://clawdchat.cn/my"})
            await page.goto("https://clawdchat.cn/my", wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_timeout(5000)
            
            # 2. 检查是否在登录页
            current_url = page.url
            if "login" in current_url or "signin" in current_url:
                save_status("waiting_login", {
                    "message": "请在浏览器中完成登录，登录成功后会自动继续"
                })
                # 等待跳转到个人主页（表示登录成功）
                while True:
                    await asyncio.sleep(2)
                    current_url = page.url
                    if "my" in current_url and "login" not in current_url:
                        break
                    # 检查是否还在登录页超过2分钟
                    status = load_status()
                    if time.time() - status.get("timestamp", 0) > 120:
                        save_status("error", {"message": "登录超时"})
                        return
                
                save_status("login_success", {"message": "登录成功，继续发布"})
                await page.wait_for_timeout(3000)
            
            # 3. 自动点击发布按钮（尝试多种方式）
            save_status("finding_publish", {"message": "寻找发布按钮"})
            
            # 方式1: 找New按钮
            try:
                new_button = await page.wait_for_selector('button:has-text("New")', timeout=5000)
                await new_button.click()
                save_status("clicked_new", {"message": "已点击New按钮"})
            except:
                # 方式2: 找+按钮
                try:
                    plus_button = await page.wait_for_selector('button svg[class*="plus"]', timeout=3000)
                    await plus_button.click()
                    save_status("clicked_plus", {"message": "已点击+按钮"})
                except:
                    # 方式3: 直接访问发布页面
                    await page.goto("https://clawdchat.cn/post/new", timeout=15000)
                    save_status("navigated", {"message": "已跳转到发布页面"})
            
            await page.wait_for_timeout(3000)
            
            # 4. 自动上传文件
            save_status("uploading", {"message": "正在上传文件"})
            try:
                file_input = await page.wait_for_selector('input[type="file"]', timeout=10000)
                await file_input.set_input_files(str(zip_path))
                save_status("file_selected", {"message": "文件已选择"})
            except Exception as e:
                save_status("error", {"message": f"上传文件失败: {str(e)}"})
                return
            
            await page.wait_for_timeout(3000)
            
            # 5. 自动填写标题
            save_status("filling_title", {"message": "正在填写标题"})
            try:
                # 尝试多种标题输入框
                selectors = [
                    'input[placeholder*="title" i]',
                    'input[name="title"]',
                    'textarea[placeholder*="title" i]',
                    'input[placeholder*="标题" i]',
                    'input[type="text"]'
                ]
                for selector in selectors:
                    try:
                        title_input = await page.wait_for_selector(selector, timeout=2000)
                        await title_input.fill(title)
                        save_status("title_filled", {"title": title})
                        break
                    except:
                        continue
            except:
                pass
            
            await page.wait_for_timeout(1000)
            
            # 6. 自动填写描述
            if description:
                save_status("filling_desc", {"message": "正在填写描述"})
                try:
                    desc_selectors = [
                        'textarea[placeholder*="description" i]',
                        'textarea[placeholder*="content" i]',
                        'textarea[placeholder*="描述" i]'
                    ]
                    for selector in desc_selectors:
                        try:
                            desc_input = await page.wait_for_selector(selector, timeout=2000)
                            await desc_input.fill(description)
                            break
                        except:
                            continue
                except:
                    pass
            
            await page.wait_for_timeout(1000)
            
            # 7. 自动点击发布
            save_status("publishing", {"message": "正在点击发布"})
            try:
                publish_selectors = [
                    'button:has-text("Post")',
                    'button:has-text("发布")',
                    'button[type="submit"]',
                    'button:has-text("Submit")'
                ]
                for selector in publish_selectors:
                    try:
                        publish_button = await page.wait_for_selector(selector, timeout=3000)
                        await publish_button.click()
                        save_status("publish_clicked", {"message": "已点击发布"})
                        break
                    except:
                        continue
            except Exception as e:
                save_status("error", {"message": f"点击发布失败: {str(e)}"})
                return
            
            # 8. 等待发布完成
            save_status("waiting_complete", {"message": "等待发布完成"})
            await page.wait_for_timeout(8000)
            
            # 9. 获取分享链接
            final_url = page.url
            
            if "post" in final_url:
                share_link = final_url
                save_status("completed", {
                    "share_link": share_link,
                    "message": "发布成功！",
                    "skill": skill_name
                })
                
                # 保存链接到文件
                output_file = skill_path.parent / f"{skill_name}_share_link.txt"
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(f"虾聊分享链接: {share_link}\n")
                    f.write(f"Skill: {skill_name}\n")
                    f.write(f"发布时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                
                print(f"\n{'='*60}")
                print(f"🎉 虾聊发布成功！")
                print(f"{'='*60}")
                print(f"📦 Skill: {skill_name}")
                print(f"🔗 分享链接: {share_link}")
                print(f"💾 链接已保存: {output_file}")
                print(f"{'='*60}")
                
            else:
                save_status("waiting_link", {
                    "current_url": final_url,
                    "message": "请检查发布状态"
                })
            
            await browser.close()
            
            # 清理临时文件
            if zip_path.exists():
                zip_path.unlink()
                
        except Exception as e:
            save_status("error", {"message": str(e)})
            await browser.close()

def load_status():
    """加载状态"""
    if STATUS_FILE.exists():
        with open(STATUS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"status": "idle", "data": {}}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python auto_publish_full.py <skill_path>")
        sys.exit(1)
    
    skill_path = sys.argv[1]
    asyncio.run(auto_publish(skill_path))
