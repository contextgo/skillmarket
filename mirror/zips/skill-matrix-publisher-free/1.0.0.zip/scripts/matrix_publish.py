#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Skill矩阵分发助手 - 主脚本
一键分发到虾聊、GitHub、虾友SkillHub、ClawHub
"""

import os
import sys
import json
import subprocess
from pathlib import Path

# 配置存储路径
CONFIG_FILE = Path(__file__).parent.parent / "config" / "publisher_config.json"

def load_config():
    """加载配置"""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_config(config):
    """保存配置"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

def publish_to_github(skill_path, config):
    """发布到GitHub"""
    print("\n📦 发布到GitHub...")
    
    github_config = config.get('github', {})
    token = github_config.get('token')
    owner = github_config.get('owner')
    repo = github_config.get('repo')
    
    if not all([token, owner, repo]):
        print("❌ GitHub配置不完整")
        return False
    
    script_path = Path(__file__).parent / "publish_github.py"
    cmd = [
        "python", str(script_path),
        skill_path,
        token,
        owner,
        repo
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)
    
    return result.returncode == 0

def publish_to_clawdchat(skill_path, config):
    """发布到虾聊（使用API Key方案）"""
    print("\n🦞 发布到虾聊...")
    
    # 检查是否有API Key配置
    clawdchat_config = config.get('clawdchat', {})
    api_key = clawdchat_config.get('api_key')
    
    if api_key:
        # 使用API Key直接上传
        print("💡 使用API Key直接上传")
        script_path = Path(__file__).parent / "publish_clawdchat_api.py"
        cmd = [
            "python", str(script_path),
            skill_path,
            api_key
        ]
        result = subprocess.run(cmd)
        return result.returncode == 0
    else:
        # 使用分享链接方案（需要用户手动操作）
        print("💡 使用虾聊分享链接方案")
        print("⚠️  未配置API Key，将使用手动方式")
        
        script_path = Path(__file__).parent / "publish_clawdchat_share.py"
        cmd = [
            "python", str(script_path),
            skill_path
        ]
        result = subprocess.run(cmd)
        return result.returncode == 0

def publish_to_clawhub(skill_path, config):
    """发布到ClawHub"""
    print("\n🔱 发布到ClawHub...")
    
    clawhub_config = config.get('clawhub', {})
    token = clawhub_config.get('token')
    
    if not token:
        print("❌ ClawHub配置不完整")
        return False
    
    # 使用clawhub CLI
    skill_name = Path(skill_path).name
    
    # 先登录
    login_cmd = ["clawhub", "login", "--token", token]
    subprocess.run(login_cmd, capture_output=True)
    
    # 发布
    publish_cmd = [
        "clawhub", "publish", skill_path,
        "--slug", skill_name.replace('_', '-').lower(),
        "--name", skill_name,
        "--version", "1.0.0"
    ]
    
    result = subprocess.run(publish_cmd)
    return result.returncode == 0

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("🚀 Skill矩阵分发助手（免费版）")
        print("=" * 60)
        print("一键将免费Skill分发到多个平台")
        print("=" * 60)
        print("\n📋 支持的平台:")
        print("  🦞 虾聊       - 生成分享链接（推荐）")
        print("  📦 GitHub     - 自动上传到仓库")
        print("  🔱 ClawHub    - CLI发布到官方市场")
        print("\n💡 虾聊创始人推荐方案:")
        print("  免费版Skill最佳实践：使用虾聊原生分享功能")
        print("  只需复制分享链接，发给Agent即可自动安装")
        print("\n用法:")
        print("  python matrix_publish.py <skill_path> [platforms]")
        print("\n示例:")
        print("  python matrix_publish.py D:/skills/my-skill")
        print("  python matrix_publish.py D:/skills/my-skill github")
        print("  python matrix_publish.py D:/skills/my-skill clawdchat")
        print("  python matrix_publish.py D:/skills/my-skill github,clawdchat")
        print("\n支持的平台参数: github, clawdchat, clawhub, all")
        sys.exit(1)
    
    skill_path = sys.argv[1]
    platforms = sys.argv[2] if len(sys.argv) > 2 else "all"
    
    if not os.path.exists(skill_path):
        print(f"❌ Skill路径不存在: {skill_path}")
        sys.exit(1)
    
    # 加载配置
    config = load_config()
    
    print("=" * 50)
    print("🚀 Skill矩阵分发助手")
    print("=" * 50)
    print(f"📁 Skill: {Path(skill_path).name}")
    print(f"🎯 平台: {platforms}")
    print("=" * 50)
    
    results = {}
    
    # 发布到各平台
    if platforms in ["all", "github"]:
        results['github'] = publish_to_github(skill_path, config)
    
    if platforms in ["all", "clawdchat"]:
        results['clawdchat'] = publish_to_clawdchat(skill_path, config)
    
    if platforms in ["all", "clawhub"]:
        results['clawhub'] = publish_to_clawhub(skill_path, config)
    
    # 打印结果
    print("\n" + "=" * 50)
    print("📊 发布结果")
    print("=" * 50)
    for platform, success in results.items():
        status = "✅ 成功" if success else "❌ 失败"
        print(f"{platform:12} {status}")
    print("=" * 50)

if __name__ == "__main__":
    main()
