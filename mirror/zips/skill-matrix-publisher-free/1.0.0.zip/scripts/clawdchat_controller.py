#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虾聊发布控制器
用于控制自动发布流程，可在聊天中随时交互
"""

import os
import sys
import json
import subprocess
import time
from pathlib import Path

STATUS_FILE = Path(__file__).parent.parent / "config" / "publish_status.json"

def load_status():
    """加载状态"""
    if STATUS_FILE.exists():
        with open(STATUS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"status": "idle", "data": {}}

def save_status(status, data=None):
    """保存状态"""
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATUS_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            "status": status,
            "data": data or {},
            "timestamp": time.time()
        }, f, indent=2, ensure_ascii=False)

def start_publish(skill_path):
    """开始发布流程"""
    script_path = Path(__file__).parent / "auto_publish_clawdchat.py"
    
    # 在后台启动发布脚本
    if sys.platform == "win32":
        subprocess.Popen(
            ["python", str(script_path), skill_path],
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )
    else:
        subprocess.Popen(
            ["python", str(script_path), skill_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    
    print(f"[START] 发布流程已启动")
    print(f"[INFO] Skill: {skill_path}")
    print(f"[INFO] 请查看新打开的窗口")

def check_status():
    """检查当前状态"""
    status = load_status()
    
    print(f"\n[STATUS] 当前状态: {status.get('status', 'unknown')}")
    
    data = status.get('data', {})
    
    if status['status'] == "waiting_login":
        print(f"[ACTION] 请在浏览器中登录虾聊")
        print(f"[ACTION] 登录完成后，在这里回复: 已登录")
        
    elif status['status'] == "waiting_click":
        print(f"[ACTION] 请手动点击: {data.get('element', '按钮')}")
        print(f"[ACTION] 点击后，在这里回复: 已点击")
        
    elif status['status'] == "waiting_publish":
        print(f"[ACTION] 请手动点击发布按钮")
        print(f"[INFO] 标题: {data.get('title', '')}")
        print(f"[ACTION] 发布后，在这里回复: 已发布")
        
    elif status['status'] == "completed":
        print(f"[OK] 发布成功！")
        print(f"[LINK] 分享链接: {data.get('share_link', '')}")
        return data.get('share_link')
        
    elif status['status'] == "error":
        print(f"[ERROR] {data.get('message', '未知错误')}")
        
    else:
        print(f"[INFO] {data.get('message', '处理中...')}")
    
    return None

def send_command(command):
    """发送命令"""
    status = load_status()
    
    if command == "已登录":
        if status['status'] == "waiting_login":
            save_status("login_completed")
            print("[OK] 已通知发布脚本继续")
        else:
            print("[WARN] 当前状态不是等待登录")
    
    elif command == "已点击":
        if status['status'] == "waiting_click":
            save_status("click_completed")
            print("[OK] 已通知发布脚本继续")
        else:
            print("[WARN] 当前状态不是等待点击")
    
    elif command == "已发布":
        if status['status'] == "waiting_publish":
            save_status("publish_clicked")
            print("[OK] 已通知发布脚本继续")
        else:
            print("[WARN] 当前状态不是等待发布")
    
    else:
        print(f"[WARN] 未知命令: {command}")
        print("[INFO] 可用命令: 已登录, 已点击, 已发布")

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("虾聊发布控制器")
        print("\n用法:")
        print("  1. 启动发布: python clawdchat_controller.py start <skill_path>")
        print("  2. 检查状态: python clawdchat_controller.py status")
        print("  3. 发送命令: python clawdchat_controller.py cmd <命令>")
        print("\n示例:")
        print("  python clawdchat_controller.py start D:/skills/my-skill")
        print("  python clawdchat_controller.py status")
        print("  python clawdchat_controller.py cmd 已登录")
        sys.exit(1)
    
    action = sys.argv[1]
    
    if action == "start" and len(sys.argv) > 2:
        start_publish(sys.argv[2])
    
    elif action == "status":
        check_status()
    
    elif action == "cmd" and len(sys.argv) > 2:
        send_command(sys.argv[2])
    
    else:
        print("[ERROR] 参数错误")

if __name__ == "__main__":
    main()
