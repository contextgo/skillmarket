#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虾聊(ClawdChat)分享链接生成脚本
使用Playwright模拟浏览器发布并获取分享链接

虾聊创始人推荐方案：
免费版Skill最佳实践 - 使用虾聊原生分享功能
只需复制分享链接，发给Agent即可自动上传
"""

import asyncio
import os
import sys
import json
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("[ERROR] 请先安装playwright:")
    print("   pip install playwright")
    print("   playwright install chromium")
    sys.exit(1)

async def publish_and_get_share_link(skill_path, title=None, description=None):
    """
    发布Skill到虾聊并获取分享链接
    
    Args:
        skill_path: Skill文件夹路径
        title: 发布标题（可选，默认使用文件夹名）
        description: 发布描述（可选）
    
    Returns:
        share_link: 分享链接（格式：https://clawdchat.cn/post/{uuid}）
    """
    
    skill_path = Path(skill_path)
    skill_name = skill_path.name
    
    if not title:
        title = skill_name
    
    # 先打包ZIP
    import zipfile
    zip_path = skill_path.parent / f"{skill_name}_SKILL.zip"
    
    print(f"[PACK] 打包Skill: {skill_name}")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(skill_path):
            # 排除不需要的文件
            dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', '.workbuddy']]
            for file in files:
                if file.endswith(('.pyc', '.tmp')):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, skill_path)
                zf.write(file_path, arcname)
    
    print(f"[OK] 打包完成: {zip_path}")
    
    # 读取SKILL.md获取描述
    if not description:
        skill_md = skill_path / "SKILL.md"
        if skill_md.exists():
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
                # 提取描述
                for line in content.split('\n'):
                    if 'description' in line.lower() or '一句话介绍' in line:
                        description = line.split(':')[-1].strip()
                        break
    
    print(f"\n[CLAWDCHAT] 开始发布到虾聊...")
    print(f"[TITLE] 标题: {title}")
    
    async with async_playwright() as p:
        # 启动浏览器（显示模式）
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(viewport={"width": 1280, "height": 800})
        page = await context.new_page()
        
        share_link = None
        
        try:
            # 1. 访问虾聊
            print("[BROWSER] 打开虾聊...")
            await page.goto("https://clawdchat.cn/my", wait_until="networkidle")
            await page.wait_for_timeout(3000)
            
            # 2. 检查登录状态
            current_url = page.url
            if "login" in current_url or "signin" in current_url:
                print("\n[WARN] 请先登录虾聊")
                print("请在浏览器中完成登录，然后按回车继续...")
                input()
            
            # 3. 点击"New"按钮
            print("[CLICK] 点击发布按钮...")
            try:
                new_button = await page.wait_for_selector('button:has-text("New")', timeout=5000)
                await new_button.click()
            except:
                try:
                    new_button = await page.wait_for_selector('text=New', timeout=5000)
                    await new_button.click()
                except:
                    print("[WARN] 找不到New按钮，请手动点击")
                    input("点击后按回车继续...")
            
            await page.wait_for_timeout(2000)
            
            # 4. 选择文件
            print("[UPLOAD] 选择文件...")
            file_input = await page.wait_for_selector('input[type="file"]', timeout=10000)
            await file_input.set_input_files(str(zip_path))
            await page.wait_for_timeout(3000)
            
            # 5. 填写标题
            print("[INPUT] 填写标题...")
            try:
                title_input = await page.wait_for_selector('input[placeholder*="title" i], input[name="title"], textarea[placeholder*="title" i]', timeout=5000)
                await title_input.fill(title)
            except:
                print("[WARN] 找不到标题输入框，请手动填写")
            
            await page.wait_for_timeout(1000)
            
            # 6. 填写描述
            if description:
                print("[INPUT] 填写描述...")
                try:
                    desc_input = await page.wait_for_selector('textarea[placeholder*="description" i], textarea[placeholder*="content" i]', timeout=5000)
                    await desc_input.fill(description)
                except:
                    pass
            
            await page.wait_for_timeout(1000)
            
            # 7. 点击发布
            print("[PUBLISH] 点击发布...")
            try:
                publish_button = await page.wait_for_selector('button:has-text("Post"), button:has-text("Submit")', timeout=5000)
                await publish_button.click()
            except:
                print("[WARN] 找不到发布按钮，请手动点击")
                input("点击发布后按回车继续...")
            
            # 8. 等待发布完成
            print("[WAIT] 等待发布完成...")
            await page.wait_for_timeout(5000)
            
            # 获取当前URL
            final_url = page.url
            
            if "post" in final_url:
                share_link = final_url
                print(f"\n[OK] 虾聊发布成功！")
                print(f"[LINK] 分享链接: {share_link}")
                print(f"\n[INFO] 使用方式:")
                print(f"   将此链接发给Agent（WorkBuddy/QClaw）")
                print(f"   Agent会自动识别并安装Skill")
            else:
                print(f"\n[WARN] 请确认发布成功，当前URL: {final_url}")
                share_link = input("请手动复制分享链接: ")
            
            await browser.close()
            
            # 清理临时ZIP文件
            if zip_path.exists():
                zip_path.unlink()
                print(f"\n[CLEAN] 已清理临时文件")
            
            return share_link
            
        except Exception as e:
            print(f"\n[ERROR] 发布失败: {str(e)}")
            await browser.close()
            return None

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("[INFO] 虾聊分享链接生成工具")
        print("\n用法:")
        print("  python publish_clawdchat_share.py <skill_path> [title] [description]")
        print("\n示例:")
        print("  python publish_clawdchat_share.py D:/skills/my-skill")
        print("  python publish_clawdchat_share.py D:/skills/my-skill \"我的Skill\" \"这是描述\"")
        print("\n提示:")
        print("  此工具会打开浏览器，请在浏览器中完成登录和发布")
        print("  发布成功后会自动获取分享链接")
        sys.exit(1)
    
    skill_path = sys.argv[1]
    title = sys.argv[2] if len(sys.argv) > 2 else None
    description = sys.argv[3] if len(sys.argv) > 3 else None
    
    if not os.path.exists(skill_path):
        print(f"[ERROR] Skill路径不存在: {skill_path}")
        sys.exit(1)
    
    result = asyncio.run(publish_and_get_share_link(skill_path, title, description))
    
    if result:
        print(f"\n[OK] 分享链接: {result}")
        
        # 保存到文件
        output_file = Path(skill_path).parent / f"{Path(skill_path).name}_share_link.txt"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"虾聊分享链接: {result}\n")
            f.write(f"\n使用方法:\n")
            f.write(f"将此链接发给Agent（WorkBuddy/QClaw）即可自动安装\n")
        
        print(f"[SAVE] 链接已保存到: {output_file}")
    else:
        print("\n[ERROR] 获取分享链接失败")
        sys.exit(1)

if __name__ == "__main__":
    main()
