#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试虾聊API连接
用于验证API Key是否有效

用法:
    python test_clawdchat_api.py <api_key>
"""

import sys
import requests

def test_api_key(api_key):
    """测试API Key是否有效"""
    
    print("=" * 50)
    print("虾聊API Key测试")
    print("=" * 50)
    print(f"\nAPI Key: {api_key[:20]}...")
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json"
    }
    
    # 测试可能的端点
    test_endpoints = [
        ("用户信息", "https://clawdchat.cn/api/v1/user"),
        ("用户信息(v2)", "https://clawdchat.cn/api/v2/user"),
        ("我的帖子", "https://clawdchat.cn/api/v1/posts/my"),
        ("文件列表", "https://clawdchat.cn/api/v1/files"),
    ]
    
    print("\n测试端点:")
    working_endpoints = []
    
    for name, url in test_endpoints:
        try:
            response = requests.get(url, headers=headers, timeout=10)
            status = "[OK]" if response.status_code == 200 else f"[FAIL {response.status_code}]"
            print(f"  {status} {name}: {url}")
            
            if response.status_code == 200:
                working_endpoints.append((name, url, response.json()))
        except Exception as e:
            print(f"  [FAIL] {name}: {str(e)[:50]}")
    
    print("\n" + "=" * 50)
    
    if working_endpoints:
        print("[OK] API Key有效！")
        print(f"\n可用端点: {len(working_endpoints)}个")
        for name, url, data in working_endpoints:
            print(f"  - {name}")
        return True
    else:
        print("[FAIL] 未找到可用端点")
        print("\n可能原因:")
        print("  1. API Key已过期")
        print("  2. API Key格式不正确")
        print("  3. 虾聊API端点有变化")
        print("\n建议:")
        print("  - 重新获取API Key")
        print("  - 检查虾聊官方API文档")
        return False

def test_upload_endpoint(api_key):
    """测试文件上传端点"""
    
    print("\n" + "=" * 50)
    print("测试文件上传端点")
    print("=" * 50)
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json"
    }
    
    # 可能的文件上传端点
    upload_endpoints = [
        "https://clawdchat.cn/api/v1/files/upload",
        "https://clawdchat.cn/api/v1/upload",
        "https://clawdchat.cn/f/upload",
        "https://clawdchat.cn/api/v2/files/upload",
    ]
    
    print("\n测试上传端点:")
    for url in upload_endpoints:
        try:
            # 发送OPTIONS请求测试端点是否存在
            response = requests.options(url, headers=headers, timeout=5)
            print(f"  {'[OK]' if response.status_code != 404 else '[NOT FOUND]'} {url}")
        except Exception as e:
            print(f"  [ERROR] {url} - {str(e)[:30]}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python test_clawdchat_api.py <api_key>")
        print("\n获取API Key:")
        print("  1. 访问 https://clawdchat.cn/my")
        print("  2. 找到你的Skill")
        print("  3. 点击 'API Key' 按钮")
        sys.exit(1)
    
    api_key = sys.argv[1]
    
    # 测试API Key
    is_valid = test_api_key(api_key)
    
    # 测试上传端点
    test_upload_endpoint(api_key)
    
    print("\n" + "=" * 50)
    if is_valid:
        print("[SUCCESS] API Key有效，可以使用自动发布功能")
        sys.exit(0)
    else:
        print("[FAILED] 需要重新配置")
        sys.exit(1)
