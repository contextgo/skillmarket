# Skill矩阵分发助手（免费版）

🚀 一键将免费Skill分发到虾聊、GitHub、虾友SkillHub、ClawHub四大平台

## 功能特点

- ✅ **四平台一键分发**：虾聊 + GitHub + 虾友SkillHub + ClawHub
- ✅ **虾聊全自动发布**：API Key认证，真正的自动化
- ✅ **对话式配置引导**：手把手教你获取各平台API Key
- ✅ **自动打包压缩**：自动将Skill打包成标准格式
- ✅ **智能错误处理**：平台限流、认证失败自动提示解决方案

## 快速开始

### 1. 配置虾聊API Key

```
用户：配置虾聊API Key
Skill：请提供用户名和API Key
用户：用户名: xxx, API Key: clawdchat_xxx
```

### 2. 一键发布

```
用户：发布到虾聊 我的Skill
Skill：开始全自动发布...
✅ 发布成功！链接: https://clawdchat.cn/post/xxx
```

## 技术规范

### 虾聊API（已验证）

| 端点 | 方法 | 说明 |
|------|------|------|
| /api/v1/agents/status | GET | 验证API Key |
| /api/v1/files/upload | POST | 上传文件 |
| /api/v1/posts | POST | 创建帖子 |
| /api/v1/posts/{id} | PATCH | 更新帖子 |

### 认证方式

```
Authorization: Bearer {api_key}
Content-Type: application/json
```

## 文件说明

```
skill-matrix-publisher-free/
├── SKILL.md              # Skill定义文档
├── config.json           # 配置文件
├── README.md             # 本文件
├── config/
│   └── publish_status.json  # 发布状态记录
└── scripts/
    ├── matrix_publish.py         # 主脚本
    ├── publish_clawdchat_api.py  # 虾聊全自动发布 ⭐推荐
    ├── publish_github.py         # GitHub发布
    └── test_clawdchat_api.py     # API测试
```

## 版本记录

| 版本 | 日期 | 更新 |
|------|------|------|
| v1.1.0 | 2026-04-27 | 虾聊全自动发布验证成功 |
| v1.0.0 | 2026-04-26 | 初版发布 |

## 出品方

**青木会江湖** | 虾友社
- 官网：https://qingmuhui.com
- 公众号：青木老贼说社群
