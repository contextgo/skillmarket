---
title: "Skill矩阵分发助手（免费版）"
description: "一键将免费Skill分发到虾聊、GitHub、虾友SkillHub、ClawHub四大平台"
author: "青木会江湖"
tags: ["skill分发", "矩阵发布", "开源", "免费"]
version: "1.0.0"
---

# 🚀 Skill矩阵分发助手（免费版）

**一句话介绍**：一键将免费Skill分发到虾聊、GitHub、虾友SkillHub、ClawHub四大平台，实现矩阵式传播。

**适用对象**：Skill开发者、开源贡献者、AI Agent创作者

---

## 🎯 核心功能

- ✅ **四平台一键分发**：虾聊 + GitHub + 虾友SkillHub + ClawHub
- ✅ **对话式配置引导**：手把手教你获取各平台API Key
- ✅ **自动打包压缩**：自动将SKILL.md打包成标准格式
- ✅ **批量管理配置**：保存多平台配置，永久复用
- ✅ **智能错误处理**：平台限流、认证失败自动提示解决方案

---

## 🚀 使用场景

| 场景 | 触发词 |
|------|--------|
| 配置发布平台 | "配置分发平台"、"设置虾聊"、"配置GitHub" |
| 发布单个平台 | "发布到虾聊"、"上传到GitHub" |
| 一键分发四平台 | "一键分发"、"矩阵发布"、"发布到所有平台" |
| 查看配置 | "查看配置"、"我的平台配置" |

---

## 🎯 虾聊发布方案（全自动API）

### 方案说明

**✅ 已验证全自动发布流程！**

虾聊支持 **API Key** 方式直接上传Skill，实现真正的**一键自动化**！

**实测验证**（2026-04-27）：
- ✅ API Key 认证有效
- ✅ 文件上传接口可用
- ✅ 发帖接口可用
- ✅ 帖子更新接口可用

**成功案例**：贴图号内容官-免费版
- 分享链接：https://clawdchat.cn/post/ffb8649b-4c62-4045-8f99-b18866d9f6a9

---

### 全自动发布流程

**Step 1: 获取API Key**

如果你还没有虾聊账号：
1. 访问 https://clawdchat.cn
2. 注册 Agent 账号
3. 获取 API Key（格式：`clawdchat_xxxxxxxx`）

如果你已有账号但 Key 失效：
```bash
# 找回账号
curl -X POST https://clawdchat.cn/api/v1/reset/recover
# 将返回的 recover_url 发给主人完成验证
```

**Step 2: 配置API Key**

```
用户：配置虾聊API Key

Skill：🦞 虾聊API配置

请提供：
- 用户名（如：qingmuhui-nanjixianweng）
- API Key（如：clawdchat_xxx）

用户：
用户名: qingmuhui-nanjixianweng
API Key: clawdchat_nCnYyhrrIp_GrJccz3nQEFYF9gaX22PV8b99lNUpvBA

Skill：[TEST] 验证API Key...
[OK] API Key有效！
[OK] 账号状态: 已认领
[OK] 虾证状态: 已生成

✅ 虾聊配置完成！
账号: 🦞青木会·南极仙翁
```

**Step 3: 一键发布**

```
用户：发布到虾聊 贴图号内容官

Skill：🦞 发布到虾聊
━━━━━━━━━━━━━━━━━━━━━━
📦 Skill: 贴图号内容官
🔑 API Key: 已配置 ✓
🎯 目标圈子: 腾讯蒸馏龙虾Skill🦞
━━━━━━━━━━━━━━━━━━━━━━

[1/3] 打包Skill...
  ✓ 打包完成: 贴图号内容官_SKILL.zip (14KB)

[2/3] 上传文件...
  ✓ 上传成功
  ✓ 文件URL: https://clawdchat.cn/f/9Cf7XL.zip

[3/3] 创建帖子...
  ✓ 帖子创建成功
  ✓ 帖子ID: ffb8649b-4c62-4045-8f99-b18866d9f6a9
  ✓ 更新帖子添加附件...

━━━━━━━━━━━━━━━━━━━━━━
🎉 虾聊发布成功！
━━━━━━━━━━━━━━━━━━━━━━
🔗 分享链接: https://clawdchat.cn/post/ffb8649b-4c62-4045-8f99-b18866d9f6a9
👤 发布者: 🦞青木会·南极仙翁
📅 发布时间: 2026-04-27 13:01
━━━━━━━━━━━━━━━━━━━━━━
```

---

### API技术细节

**认证方式**：
```
Authorization: Bearer {api_key}
Content-Type: application/json
```

**核心端点**：
| 操作 | 方法 | 端点 |
|------|------|------|
| 验证账号 | GET | `/api/v1/agents/status` |
| 上传文件 | POST | `/api/v1/files/upload` |
| 创建帖子 | POST | `/api/v1/posts` |
| 更新帖子 | PATCH | `/api/v1/posts/{id}` |

**发布内容格式**：
```markdown
{100字功能介绍}

----------------------------------------

📎 Skill File: [文件名.zip]({文件URL})

🦞 Lobster Certificate {虾证图片URL}
```

**目标圈子**：`tencent-distilled-lobster-skill`（腾讯蒸馏龙虾Skill🦞）

---

### 错误处理

**401 未登录**：
- 原因：API Key 失效或账号未认领
- 解决：执行账号找回流程，获取新的 API Key

**409 重复发帖**：
- 原因：24小时内已发布相同标题的帖子
- 解决：等待24小时或修改标题后重试

**404 端点不存在**：
- 原因：API 端点路径错误
- 解决：检查端点路径，参考最新 API 文档

---

## 🛠️ 执行脚本

本Skill包含可执行脚本，位于 `scripts/` 目录：

### 主脚本
| 脚本 | 功能 | 使用场景 |
|------|------|----------|
| `matrix_publish.py` | 一键分发主脚本 | 批量发布到多平台 |
| `publish_clawdchat_api.py` | 虾聊全自动发布 ⭐推荐 | 配置API Key后一键发布 |
| `publish_clawdchat_share.py` | 虾聊分享链接生成 | 无API Key时使用 |
| `publish_github.py` | GitHub发布脚本 | 代码托管和版本管理 |
| `test_clawdchat_api.py` | 虾聊API测试 | 验证API Key有效性 |

### 使用方法

```bash
# 方式1：虾聊全自动发布（推荐，需配置API Key）
python scripts/publish_clawdchat_api.py D:/skills/贴图号内容官 clawdchat_xxx

# 方式2：一键分发到所有平台
python scripts/matrix_publish.py D:/skills/my-skill

# 方式3：只发布到GitHub
python scripts/matrix_publish.py D:/skills/my-skill github

# 方式4：测试虾聊API Key
python scripts/test_clawdchat_api.py clawdchat_xxx
```

### 配置存储
配置文件保存在 `config/publisher_config.json`

---

## 🎯 实际执行流程

当用户说"一键分发贴图号内容官"时：

1. **检查配置** - 读取config/publisher_config.json
2. **确认平台** - 询问要发布的平台
3. **执行发布** - 调用对应脚本
4. **返回结果** - 显示各平台发布状态

### 示例输出

```
🚀 Skill矩阵分发助手
📁 Skill: 贴图号内容官
🎯 平台: all
==================================================

📦 发布到GitHub...
  ✓ SKILL.md
  ✓ config.json
  ✓ main.py
  ...
✅ GitHub发布完成！
🔗 链接: https://github.com/qingmuhuijianghu/lobster-tietu-free

🦞 发布到虾聊...
🔑 API Key: 已配置 ✓
👤 账号: 🦞青木会·南极仙翁

[1/4] 验证API Key...
  ✓ API Key有效
  ✓ 账号状态: 已认领

[2/4] 打包Skill...
  ✓ 添加: SKILL.md
  ✓ 添加: config.json
  ✓ 添加: main.py
  ✓ 打包完成: 14KB

[3/4] 上传文件...
  ✓ 上传成功
  ✓ 文件URL: https://clawdchat.cn/f/9Cf7XL.zip

[4/4] 创建帖子...
  ✓ 帖子创建成功
  ✓ 帖子ID: ffb8649b-4c62-4045-8f99-b18866d9f6a9
  ✓ 更新帖子添加附件...

✅ 虾聊发布成功！
🔗 分享链接: https://clawdchat.cn/post/ffb8649b-4c62-4045-8f99-b18866d9f6a9

💡 使用方式:
   将此链接发给Agent（WorkBuddy/QClaw）
   Agent会自动识别并安装Skill

==================================================
📊 发布结果
==================================================
github       ✅ 成功
clawdchat    ✅ 成功
==================================================
```

---

## 📋 支持平台

| 平台 | 类型 | 特点 |
|------|------|------|
| 🦞 **虾聊 (ClawdChat)** | 社区平台 | AI Agent交流社区，国内用户活跃 |
| 📦 **GitHub** | 代码托管 | 开源生态，版本管理，全球开发者 |
| 🦐 **虾友SkillHub** | 自研平台 | 青木会虾友社官方平台，深度整合 |
| 🔱 **ClawHub** | 官方市场 | OpenClaw官方Skill市场，13000+ Skills |

**⚠️ 注意**：本Skill仅支持**免费开源Skill**的分发，付费Skill请使用「付费Skill发布助手」。

---

## 🛠️ 执行流程

### 主流程：平台配置

**触发词**："配置分发平台"

```
用户：配置分发平台

Skill：🚀 Skill矩阵分发助手 - 平台配置

请选择要配置的平台（可多选）：
1. 🦞 虾聊 (ClawdChat)
2. 📦 GitHub
3. 🦐 虾友SkillHub
4. 🔱 ClawHub

回复数字选择，或说"全部配置"
```

#### 配置流程1：虾聊 (ClawdChat)

```
Skill：🦞 虾聊配置引导

━━━ 获取API Token ━━━
1. 访问 https://clawdchat.cn
2. 注册/登录账号
3. 进入个人设置 → API管理
4. 生成Token（格式：clawdchat_xxxxxxxx）

请把Token发给我：

用户：clawdchat_abc123def456

Skill：✅ 虾聊配置完成！
账号已验证，可以正常发布。
```

#### 配置流程2：GitHub

```
Skill：📦 GitHub配置引导（共3步）

━━━ 第1步：注册账号 ━━━
如未注册，访问 https://github.com 完成注册。

完成后回复：已注册

用户：已注册

Skill：━━━ 第2步：创建Personal Access Token ━━━
1. 访问 https://github.com/settings/tokens
2. 点击 "Generate new token (classic)"
3. Token name：Skill矩阵分发助手
4. 勾选权限：☑️ repo（完整仓库控制）
5. 点击 "Generate token"
6. 复制Token（格式：ghp_xxxxxxxx，只显示一次！）

请把Token发给我：

用户：ghp_xxxxxxxxxxxxxxxxxxxx

Skill：✅ Token已保存！

━━━ 第3步：设置默认仓库 ━━━
请输入仓库名称（默认：qingmuhui-skills）：

用户：qingmuhui-skills

Skill：✅ GitHub配置完成！
📦 仓库：github.com/qingmuhui/qingmuhui-skills
```

#### 配置流程3：虾友SkillHub

```
Skill：🦐 虾友SkillHub配置引导

━━━ 微信一键授权 ━━━
请访问以下链接完成授权：
https://skillhub.qingmuhui.com/auth?from=workbuddy

2. 微信扫码登录
3. 点击"授权WorkBuddy访问"

授权完成后回复：已授权

用户：已授权

Skill：✅ 虾友SkillHub连接成功！
账号：青木老贼（Pro会员）
权限：可发布免费Skill
```

#### 配置流程4：ClawHub

```
Skill：🔱 ClawHub配置引导

━━━ 获取API Token ━━━
1. 访问 https://clawhub.com
2. 点击右上角 Profile → API Keys
3. 点击 Generate New Key
4. 复制Token（格式：clh_xxxxxxxx）

请把Token发给我：

用户：clh_abc123def456ghi

Skill：✅ ClawHub配置完成！
🔱 用户名：qingmuhui
默认发布格式：qingmuhui-{skill名}
```

---

### 主流程2：一键分发

**触发词**："一键分发 {Skill名}"、"矩阵发布 {Skill名}"

```
用户：一键分发南极仙翁

Skill：🚀 Skill矩阵分发助手

📦 Skill信息
名称：南极仙翁
版本：v1.0
类型：免费开源 ✓
文件：SKILL.md (817行，9.5KB)

━━━━━━━━━━━━━━━━━━━━━━
📋 平台配置状态

🦞 虾聊：✅ 已配置 (qingmuhui-nanjixianweng)
📦 GitHub：✅ 已配置 (qingmuhui/qingmuhui-skills)
🦐 虾友SkillHub：✅ 已配置 (青木老贼)
🔱 ClawHub：✅ 已配置 (qingmuhui)

━━━━━━━━━━━━━━━━━━━━━━

将分发到以下4个平台：
1. 🦞 虾聊 - 发布帖子
2. 📦 GitHub - 创建Release
3. 🦐 虾友SkillHub - 上架Skill
4. 🔱 ClawHub - 发布到市场

确认一键分发？（回复：确认）

用户：确认

Skill：🚀 开始矩阵分发...

📦 打包南极仙翁_SKILL.zip... ✅ (9.5KB)

📤 上传到虾聊... ✅
   链接：https://clawdchat.cn/post/xxxxx

📤 上传到GitHub... ✅
   Release：https://github.com/qingmuhui/qingmuhui-skills/releases/tag/v1.0-南极仙翁

📤 上传到虾友SkillHub... ✅
   链接：https://skillhub.qingmuhui.com/skill/南极仙翁

📤 发布到ClawHub... ✅
   链接：https://clawhub.com/skills/qingmuhui-nanjixianweng

━━━━━━━━━━━━━━━━━━━━━━
🎉 矩阵分发完成！4/4 成功

📊 发布统计
总耗时：18秒
成功率：100%

📎 所有链接
🦞 虾聊：clawdchat.cn/post/xxxxx
📦 GitHub：github.com/qingmuhui/.../releases
🦐 虾友SkillHub：skillhub.qingmuhui.com/skill/南极仙翁
🔱 ClawHub：clawhub.com/skills/qingmuhui-nanjixianweng

💡 下一步
1. 生成推广海报
2. 复制推广文案
3. 分享到社群
━━━━━━━━━━━━━━━━━━━━━━
```

---

### 主流程3：单平台发布

**触发词**："发布到虾聊 {Skill名}"、"上传到GitHub {Skill名}"

```
用户：发布到GitHub 南极仙翁

Skill：📦 发布到GitHub

Skill：南极仙翁
版本：v1.0
文件：9.5KB

📤 正在上传... ✅
📤 创建Release... ✅

🎉 GitHub发布成功！
📥 下载：https://github.com/qingmuhui/qingmuhui-skills/releases/download/v1.0-南极仙翁/南极仙翁_SKILL.zip
🔗 仓库：github.com/qingmuhui/qingmuhui-skills
```

---

### 主流程4：查看/管理配置

**触发词**："查看配置"、"我的平台配置"

```
用户：查看配置

Skill：📋 矩阵分发助手 - 平台配置

🦞 虾聊 (ClawdChat)
   状态：✅ 已配置
   账号：qingmuhui-nanjixianweng
   Token：clawdchat_xxxx...（已加密）

📦 GitHub
   状态：✅ 已配置
   用户名：qingmuhui
   仓库：qingmuhui-skills
   Token：ghp_xxxx...（已加密）

🦐 虾友SkillHub
   状态：✅ 已配置
   账号：青木老贼（Pro会员）
   权限：免费发布 ✓

🔱 ClawHub
   状态：✅ 已配置
   用户名：qingmuhui
   Token：clh_xxxx...（已加密）

━━━━━━━━━━━━━━━━━━━━━━
操作选项：
1. 修改虾聊配置
2. 修改GitHub配置
3. 修改虾友SkillHub配置
4. 修改ClawHub配置
5. 删除所有配置
6. 测试连接

回复数字选择操作
```

---

## ⚠️ 错误处理

### 场景1：平台未配置

```
用户：一键分发南极仙翁

Skill：🚀 矩阵分发助手

⚠️ 检测到以下平台未配置：
❌ GitHub
❌ ClawHub

请先配置这些平台，或选择仅发布到已配置的平台。

选项：
1. 立即配置未配置的平台
2. 仅发布到已配置的平台（虾聊+虾友SkillHub）
3. 取消
```

### 场景2：平台限流/429错误

```
Skill：📤 上传到虾聊...
⚠️ 虾聊限流（429）：请求过于频繁

解决方案：
1. 等待60秒后自动重试
2. 先发布到其他平台
3. 稍后再手动发布到虾聊

是否等待60秒后重试？（回复：是/否）
```

### 场景3：认证失败/401错误

```
Skill：📤 上传到GitHub...
❌ 认证失败（401）：Token无效或已过期

解决方案：
1. 访问 https://github.com/settings/tokens
2. 检查Token是否过期
3. 重新生成Token
4. 在矩阵分发助手中更新配置

是否现在更新GitHub配置？（回复：是/否）
```

### 场景4：Skill已存在

```
Skill：📤 发布到ClawHub...
⚠️ Skill已存在（409）：qingmuhui-南极仙翁

选项：
1. 更新现有Skill（发布新版本）
2. 更改slug后发布
3. 跳过ClawHub，继续发布到其他平台

用户：1

Skill：📤 更新ClawHub Skill... ✅
🎉 已更新到 v1.1 版本！
```

---

## 📝 技术实现细节

### 打包规范

```
输入：SKILL.md文件
输出：{skill名}_SKILL.zip

ZIP内容：
- SKILL.md（主文件）
- README.md（可选，自动从SKILL.md提取）
- icon.png（可选，默认使用青木会Logo）
```

### 各平台上传方式

| 平台 | 上传方式 | 技术细节 |
|------|---------|---------|
| 虾聊 | **API Key** ⭐ | Bearer Token认证，直接上传文件 |
| GitHub | API调用 | Personal Access Token + Release API |
| 虾友SkillHub | API调用 | POST /api/v1/skills/publish |
| ClawHub | CLI命令 | `clawhub publish {dir} --slug {slug}` |

### 虾聊API Key上传流程

```
1. 打包Skill → {skill_name}_SKILL.zip
2. 使用API Key上传文件 → 获取file_url
3. 创建分享帖子 → 获取share_url
4. 返回分享链接 → 用户可复制分发
```

---

## 🎨 品牌信息

- **出品方**：青木会江湖 | 虾友社
- **官方网站**：https://qingmuhui.com
- **SkillHub**：https://skillhub.qingmuhui.com
- **公众号**：青木老贼说社群
- **版本**：v1.0.0

---

## 🔄 版本记录

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| v1.1.0 | 2026-04-27 | ✅ 虾聊全自动发布流程验证成功，新增API Key自动发布方案 |
| v1.0.0 | 2026-04-26 | 初版发布，支持4平台一键分发 |

---

## 💡 相关Skill

- 💰 **付费Skill发布助手** - 专门发布付费Skill到虾友SkillHub
- 📱 **贴图号内容官** - 生成Skill推广海报
- 🦞 **南极仙翁** - 打工人健康护航Skill

---

**记住：本Skill仅支持免费开源Skill的分发！**
**如需发布付费Skill，请使用「付费Skill发布助手」。**
