#!/usr/bin/env python3
"""
构造 CreateUK8SClusterV2 请求 JSON，写入 /tmp/create_uk8s.json
用法：python3 build-create-uk8s.py [参数...]

密码传明文，脚本自动 Base64 编码后写入 JSON。
"""

import base64
import json
import os
import sys
import argparse


def parse_args():
    p = argparse.ArgumentParser(description="构造 CreateUK8SClusterV2 请求 JSON")
    p.add_argument("--region",       default=os.environ.get("UCLOUD_REGION", "cn-bj2"))
    p.add_argument("--zone",         default=os.environ.get("UCLOUD_ZONE", ""))
    p.add_argument("--project-id",   default=os.environ.get("UCLOUD_PROJECT_ID", ""))

    # 集群基础参数
    p.add_argument("--name",         default=os.environ.get("UK8S_NAME", "uk8s"))
    p.add_argument("--k8s-version",  default=os.environ.get("UK8S_VERSION", ""))
    p.add_argument("--vpc-id",       default=os.environ.get("UK8S_VPC_ID", ""))
    p.add_argument("--subnet-id",    default=os.environ.get("UK8S_SUBNET_ID", ""))
    p.add_argument("--image-id",     default=os.environ.get("UK8S_IMAGE_ID", ""))
    p.add_argument("--password",     default=os.environ.get("UK8S_PASSWORD", ""),
                   help="明文密码，脚本自动 Base64 编码")
    p.add_argument("--service-cidr", default=os.environ.get("UK8S_SERVICE_CIDR", "192.168.0.0/16"))
    p.add_argument("--charge-type",  default=os.environ.get("UK8S_CHARGE_TYPE", "Dynamic"))
    p.add_argument("--external-api", default=os.environ.get("UK8S_EXTERNAL_API", "Yes"))

    # Master 节点
    p.add_argument("--master-count",     type=int,   default=3)
    p.add_argument("--master-cpu",       type=int,   default=2)
    p.add_argument("--master-mem",       type=int,   default=4096)
    p.add_argument("--master-type",      default="O")
    p.add_argument("--master-boot-disk", default="CLOUD_RSSD")
    p.add_argument("--master-boot-size", type=int,   default=40)
    p.add_argument("--master-data-disk", default="CLOUD_RSSD")
    p.add_argument("--master-data-size", type=int,   default=20)

    # Node 节点
    p.add_argument("--node-count",     type=int,   default=2)
    p.add_argument("--node-cpu",       type=int,   default=4)
    p.add_argument("--node-mem",       type=int,   default=8192)
    p.add_argument("--node-type",      default="O")
    p.add_argument("--node-max-pods",  type=int,   default=110)
    p.add_argument("--node-boot-disk", default="CLOUD_RSSD")
    p.add_argument("--node-data-disk", default="CLOUD_RSSD")
    p.add_argument("--node-data-size", type=int,   default=20)

    # 网络
    p.add_argument("--kube-proxy",   default="iptables")

    p.add_argument("--output",       default="/tmp/create_uk8s.json")
    return p.parse_args()


def validate(args):
    errors = []
    if not args.vpc_id:
        errors.append("--vpc-id 不能为空")
    if not args.subnet_id:
        errors.append("--subnet-id 不能为空")
    if not args.k8s_version:
        errors.append("--k8s-version 不能为空")
    if not args.image_id:
        errors.append("--image-id 不能为空")
    if not args.password:
        errors.append("--password 不能为空")
    if not args.zone:
        errors.append("--zone 不能为空")
    if errors:
        for e in errors:
            print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)


def build_payload(args):
    pwd_b64 = base64.b64encode(args.password.encode()).decode()

    masters = [
        {
            f"Master.{i}.Zone":         args.zone,
            f"Master.{i}.MachineType":  args.master_type,
            f"Master.{i}.CPU":          args.master_cpu,
            f"Master.{i}.Mem":          args.master_mem,
            f"Master.{i}.BootDiskType": args.master_boot_disk,
            f"Master.{i}.BootDiskSize": args.master_boot_size,
            f"Master.{i}.DataDiskType": args.master_data_disk,
            f"Master.{i}.DataDiskSize": args.master_data_size,
        }
        for i in range(args.master_count)
    ]

    nodes = [
        {
            f"Nodes.{i}.Zone":         args.zone,
            f"Nodes.{i}.MachineType":  args.node_type,
            f"Nodes.{i}.CPU":          args.node_cpu,
            f"Nodes.{i}.Mem":          args.node_mem,
            f"Nodes.{i}.MaxPods":      args.node_max_pods,
            f"Nodes.{i}.BootDiskType": args.node_boot_disk,
            f"Nodes.{i}.DataDiskType": args.node_data_disk,
            f"Nodes.{i}.DataDiskSize": args.node_data_size,
            f"Nodes.{i}.Count":        1,
        }
        for i in range(args.node_count)
    ]

    payload = {
        "Action":            "CreateUK8SClusterV2",
        "Region":            args.region,
        "ProjectId":         args.project_id,
        "ClusterName":       args.name,
        "K8sVersion":        args.k8s_version,
        "VPCId":             args.vpc_id,
        "SubnetId":          args.subnet_id,
        "ServiceCIDR":       args.service_cidr,
        "Password":          pwd_b64,
        "ImageId":           args.image_id,
        "ChargeType":        args.charge_type,
        "ExternalApiServer": args.external_api,
        "KubeProxy.Mode":    args.kube_proxy,
        "MasterCPU":         args.master_cpu,
        "MasterMem":         args.master_mem,
        "MasterMachineType": args.master_type,
    }

    for master in masters:
        payload.update(master)
    for node in nodes:
        payload.update(node)

    return payload


def main():
    args = parse_args()
    validate(args)
    payload = build_payload(args)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    print(f"[OK] 请求 JSON 已写入 {args.output}")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
