---
name: uk8s-create
description: 创建 UCloud UK8S Kubernetes 集群。Use when user asks to "创建 UK8S 集群", "create UK8S cluster", "新建 Kubernetes 集群".
argument-hint: "[cluster-name]"
allowed-tools: Bash(ucloud *), Bash(openssl *), Bash(base64 *), Bash(python3 *), Bash(which *), Read, AskUserQuestion
---

# 创建 UK8S Kubernetes 集群

引导用户通过 `ucloud-cli` 创建 UK8S 集群。
流程：环境检查 → 资源选择 → 参数收集 → 构造请求 → 执行创建 → 结果展示。

- 集群名称来自 `$ARGUMENTS`，默认 `uk8s`

---

## Step 1：检查 ucloud-cli 环境

按 [`references/check-ucloud-cli.md`](references/check-ucloud-cli.md) 执行环境检查。

---

## Step 2：选择 K8s 版本

```bash
ucloud api --Action GetUK8SVersions --Region <Region> --ProjectId <ProjectId> --Kind Dedicated
```

将版本列表展示给用户选择（详见 [`references/GetUK8SVersions.md`](references/GetUK8SVersions.md)）：

```
可用 K8s 版本：
  [1] 1.32.8
  [2] 1.30.10
  [3] 1.28.15

请选择版本编号：
```

记录 `K8sVersion`（完整三段式，如 `1.32.8`）。

---

## Step 3：选择 VPC 和 Subnet

```bash
ucloud api --Action DescribeVPC --Region <Region> --ProjectId <ProjectId>
```

将 VPC 列表展示给用户选择（详见 [`references/DescribeVPC.md`](references/DescribeVPC.md)）：

```
可用 VPC：
  [1] uvnet-xxx  Default  (10.23.0.0/16)
  [2] uvnet-yyy  my-vpc   (192.168.0.0/16)

请选择 VPC 编号：
```

用户选定后查询该 VPC 下的 Subnet：

```bash
ucloud api --Action DescribeSubnet --Region <Region> --ProjectId <ProjectId> --VPCId <VPCId>
```

展示 Subnet 列表供用户选择：

```
VPC uvnet-xxx 下的子网：
  [1] subnet-aaa  Default   (10.23.0.0/16)  cn-sh2-01
  [2] subnet-bbb  my-subnet (10.23.1.0/24)  cn-sh2-02

请选择 Subnet 编号：
```

记录 `VPCId` 和 `SubnetId`。

---

## Step 4：选择节点镜像

```bash
ucloud api --Action DescribeUK8SImage --Region <Region> --Zone <Zone> --ProjectId <ProjectId>
```

按 [`references/defaults.md`](references/defaults.md) 中的镜像选择规则自动匹配，无需用户手动选择。若自动匹配失败则展示列表询问用户（详见 [`references/DescribeUK8SImage.md`](references/DescribeUK8SImage.md)）。

记录 `ImageId`。

---

## Step 5：收集集群核心参数

用 `AskUserQuestion` 收集以下参数，默认值见 [`references/defaults.md`](references/defaults.md)：

- 集群名称（`ClusterName`，优先使用 `$ARGUMENTS`）
- Master 节点数（固定 3，无需询问）
- Node 节点数（`node-count`，默认 2）
- Node CPU / 内存（默认 4C/8G）
- 是否开启外网 ApiServer（`ExternalApiServer`，默认 Yes）

---

## Step 5.5：生成节点登录密码

用 `AskUserQuestion` 询问用户：

```
节点登录密码：
  [1] 随机生成（推荐）
  [2] 自定义输入
```

**若选随机生成：**

```bash
PLAIN_PWD=$(openssl rand -base64 12 | tr -dc 'A-Za-z0-9' | head -c 16)
```

**若选自定义输入：** 收集用户输入，赋值给 `$PLAIN_PWD`。

`$PLAIN_PWD` 明文仅在 Step 10 结果中展示一次，请用户立即保存。

---

## Step 6：读取 API 参数定义和默认值

使用 Read 工具读取以下文件：

- `references/CreateUK8SCluster.md` — 字段定义和必填项
- `references/defaults.md` — 未填写参数的默认值

按字段定义构造请求；未填写的参数使用默认值。

---

## Step 7：构造请求 JSON

调用脚本生成请求文件：

```bash
python3 scripts/build-create-uk8s.py \
  --region       <Region> \
  --zone         <Zone> \
  --project-id   <ProjectId> \
  --name         <ClusterName> \
  --k8s-version  <K8sVersion> \
  --vpc-id       <VPCId> \
  --subnet-id    <SubnetId> \
  --image-id     <ImageId> \
  --password     "$PLAIN_PWD" \
  --node-count   <NodeCount> \
  --node-cpu     <NodeCPU> \
  --node-mem     <NodeMem> \
  --external-api <ExternalApiServer>
```

> 脚本自动 Base64 编码密码，输出 JSON 并写入 `/tmp/create_uk8s.json`，若有报错立即中止。

---

## Step 8：创建前确认

读取 [`references/confirm-template.md`](references/confirm-template.md)，将收集到的参数填入模板后展示给用户，等待确认。

---

## Step 9：执行创建

```bash
ucloud api --local-file /tmp/create_uk8s.json
```

| RetCode | 处理 |
|---------|------|
| 0 | 解析 `ClusterId`，进入 Step 10 |
| 非 0 | 输出完整 RetCode + Message，给出修复建议（见 [`references/CreateUK8SCluster.md`](references/CreateUK8SCluster.md)） |

---

## Step 10：结果输出

读取 [`references/result-template.md`](references/result-template.md)，将创建结果填入模板后展示给用户。

---

## 错误处理原则

- 不允许吞错误，必须输出 RetCode + Message
- 用户输入无效时，重新询问而非猜测
- 所有 required 字段必须有值，不允许留空或使用占位符直接提交
