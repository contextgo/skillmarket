# 创建前确认摘要模板

```
即将创建 UK8S 集群：

集群名称:    <ClusterName>
Region/Zone: <Region> / <Zone>
VPC/Subnet:  <VPCId> / <SubnetId>
K8s 版本:    <K8sVersion>
镜像:        <ImageId> (Ubuntu 24.04)
计费:        Dynamic (按需)

Master:  3 × O型 (2C/4G) · CLOUD_RSSD 40GB
Node:    2 × O型 (4C/8G) · CLOUD_RSSD · MaxPods 110

登录密码: <PLAIN_PWD>（仅展示一次，请立即保存）

是否立即创建？(y/n)
```
