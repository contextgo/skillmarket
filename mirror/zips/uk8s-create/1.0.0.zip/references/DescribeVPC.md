# 获取VPC信息-DescribeVPC

获取VPC信息

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|地域。 参见 [地域和可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|**Yes**|
|ProjectId|string|项目ID。不填写为默认项目，子帐号必须填写。 请参考[GetProjectList接口](https://docs.ucloud.cn/api/summary/get_project_list)|**Yes**|
|VPCIds.n|string|VPCId|No|
|Tag|string|业务组名称|No|
|Offset|int|数据偏移量，默认为0|No|
|Limit|int|数据分页值|No|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|
|DataSet|array|vpc信息，具体结构见下方VPCInfo|No|
|TotalCount|int||No|

## VPCInfo
|Parameter name|Type|Description|Required|
|---|---|---|---|
|NetworkInfo|array|vpc地址空间信息，详见VPCNetworkInfo|**Yes**|
|SubnetCount|int|子网数|**Yes**|
|CreateTime|int|创建时间|**Yes**|
|UpdateTime|int|更新时间|**Yes**|
|Tag|string|业务组|**Yes**|
|Name|string|VPC名称|**Yes**|
|VPCType|string|DefaultVPC 默认VPC，DefinedVPC，自定义VPC     |No|
|VPCId|string|VPC资源ID|No|
|Network|array|VPC网段|No|
|IPv6Network|string|VPC关联的IPv6网段|No|
|OperatorName|string|VPC关联的IPv6网段所属运营商|No|
|IPv6NetworkInfos|array|VPC关联的IPv6网段信息|No|

## VPCNetworkInfo
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Network|string|vpc地址空间|No|
|SubnetCount|int|地址空间中子网数量|No|

## IPv6NetworkInfo
|Parameter name|Type|Description|Required|
|---|---|---|---|
|IPv6Network|string|IPv6网段|No|
|OperatorName|string|类型|No|
|IPv6SubnetCount|int|IPv6子网数量|No|

# Request Example
```
https://api.ucloud.cn/?Action=DescribeVPC
&ProjectId=org-xxx
&Region=cn-sh2
&VPCIds.0=uvnet-xxx
&Offset=9
&Limit=9
```

# Response Example
```
{
    "Action": "DescribeVPCResponse", 
    "TotalCount": 9, 
    "RetCode": 0, 
    "DataSet": [
        {
            "UpdateTime": 1514313728, 
            "VPCId": "uvnet-xxx", 
            "Network": [
                "10.44.x.0/16"
            ], 
            "NetworkInfo": [
                {
                    "Network": "10.44.x.0/16", 
                    "SubnetCount": 1
                }
            ], 
            "Tag": "Default", 
            "SubnetCount": 1, 
            "CreateTime": 1514313728, 
            "Name": "DefaultVPC"
        }, 
        {
            "Remark": "", 
            "VPCId": "uvnet-xxxxx", 
            "Network": [
                "192.168.x.0/16", 
                "10.0.0.0/8"
            ], 
            "NetworkInfo": [
                {
                    "Network": "192.168.x.0/16", 
                    "SubnetCount": 1
                }, 
                {
                    "Network": "10.0.0.0/8", 
                    "SubnetCount": 1
                }
            ], 
            "UpdateTime": 1533891438, 
            "Tag": "Default", 
            "SubnetCount": 2, 
            "CreateTime": 1533891436, 
            "Name": "testabc"
        }
    ]
}
```