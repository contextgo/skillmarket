# 获取可用镜像-DescribeUK8SImage

获取UK8S支持的Node节点操作系统，可基于该操作系统制定自定义镜像

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|地域。 参见 [地域和可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|**Yes**|
|Zone|string|可用区。参见 [可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|No|
|ProjectId|string|项目ID。不填写为默认项目，子帐号必须填写。 请参考[GetProjectList接口](https://docs.ucloud.cn/api/summary/get_project_list)|No|
|ProductType|string|产品类型，可选值uhost、uphost，不填则返回所有|No|
|MachineType|string|适用机型，如O、G、OPRO等，默认为O|No|
|GPUType|string|适用GPU类型，如1080Ti、4090、V100、A800等，MachineType为G时必须提供|No|
|K8sVersion|string|k8s集群版本，如1.28.15|No|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|
|Message|string|返回错误消息，当 RetCode 非 0 时提供详细的描述信息。|**Yes**|
|ImageSet|array|虚拟机可用镜像集合, 详见ImageInfo 数组|No|
|PHostImageSet|array|裸金属可用镜像集合, 详见ImageInfo 数组|No|
|CustomImageSet|array|虚拟机自制可用镜像集合, 详见ImageInfo 数组|No|
|CustomPHostImageSet|array|裸金属自制可用镜像集合, 详见ImageInfo 数组|No|

## ImageInfo
|Parameter name|Type|Description|Required|
|---|---|---|---|
|ZoneId|int|可用区 Id|**Yes**|
|ImageId|string|镜像 Id|**Yes**|
|ImageName|string|镜像名称|**Yes**|
|NotSupportGPU|bool|该镜像是否支持GPU机型，枚举值[true:不支持，false:支持]。|**Yes**|
|OsType|string|OS 类型|**Yes**|
|OsName|string|OS 名称|**Yes**|
|Features|array|镜像支持的特性|**Yes**|
|ImageSize|int|镜像大小|No|
|IntegratedSoftware|string|集成软件名称, 如NV驱动版本、cuda版本|No|
|SupportedGPUTypes|array|支持的GPU机型|No|

# Request Example
```
https://api.ucloud.cn/?Action=DescribeUK8SImage
&Region=cn-zj
&Zone=cn-zj-01
&ProjectId=sUDxutjf
&ProductType=TzadjShf
&MachineType=HfHJuJRC
&GPUType=QDBWdeSh
&K8SVersion=VYTIrewq
```

# Response Example
```
{
    "ImageSet": [
        {
            "NotSupportGPU": false, 
            "ImageName": "hIscEgwy", 
            "ImageId": "SOqcWTEJ", 
            "ZoneId": 5
        }
    ], 
    "RetCode": 0, 
    "PHostImageSet": [
        {
            "NotSupportGPU": true, 
            "ImageName": "OlgivCjk", 
            "ImageId": "yFeQPFUL", 
            "ZoneId": 9
        }
    ], 
    "PHostCustomIImageSet": [
        "jABaDaml"
    ], 
    "ImageSetnew": [
        {
            "NotSupportGPU": true, 
            "ImageName": "itWRmsMy", 
            "ImageId": "KeQfHnUL", 
            "ZoneId": 5
        }
    ], 
    "Action": "DescribeUK8SImageResponse", 
    "Message": "RcXlEGbn", 
    "CustomIImageSet": [
        "vcSXSoOo"
    ]
}
```