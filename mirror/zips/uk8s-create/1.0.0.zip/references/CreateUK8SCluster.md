# 创建 UK8S 集群-CreateUK8SClusterV2

参数结构来自 UCloud Go SDK：
```
https://raw.githubusercontent.com/ucloud/ucloud-sdk-go/master/services/uk8s/apis.go
```

# 需要读取的 Struct

| Struct | 用途 |
|--------|------|
| `CreateUK8SClusterV2Request` | 顶层请求参数 |
| `CreateUK8SClusterV2ParamMaster` | `Master.N.*` 数组元素 |
| `CreateUK8SClusterV2ParamNodes` | `Nodes.N.*` 数组元素 |
| `CreateUK8SClusterV2ParamKubeProxy` | `KubeProxy.*` 结构体 |

# 参数映射规则

| 字段位置 | JSON key 格式 | 示例 |
|----------|--------------|------|
| `CreateUK8SClusterV2Request` | 顶层字段名 | `"MasterCPU": 2` |
| `Master []ParamMaster` | `Master.N.字段名`，N 从 0 | `"Master.0.Zone": "cn-sh2-01"` |
| `Nodes []ParamNodes` | `Nodes.N.字段名`，N 从 0 | `"Nodes.0.CPU": 4` |
| `KubeProxy *ParamKubeProxy` | `KubeProxy.字段名` | `"KubeProxy.Mode": "iptables"` |

# Request Parameters

| Parameter name | Type | Description | Required |
|----------------|------|-------------|----------|
| Region | string | 地域 | **Yes** |
| ProjectId | string | 项目 ID | **Yes** |
| ClusterName | string | 集群名称 | **Yes** |
| K8sVersion | string | k8s 版本，如 `1.32.8` | **Yes** |
| VPCId | string | VPC ID | **Yes** |
| SubnetId | string | 子网 ID | **Yes** |
| ServiceCIDR | string | Service 网段 | **Yes** |
| Password | string | 节点登录密码（Base64 编码） | **Yes** |
| ImageId | string | 节点镜像 ID | **Yes** |
| ChargeType | string | 计费类型，Dynamic/Month/Year | No |
| ExternalApiServer | string | 是否开启外网 ApiServer，Yes/No | No |
| MasterCPU | int | Master CPU 核数（顶层，与 Master.N.CPU 一致） | **Yes** |
| MasterMem | int | Master 内存 MB（顶层，与 Master.N.Mem 一致） | **Yes** |
| MasterMachineType | string | Master 机型，如 O（顶层） | **Yes** |
| Master.N.* | - | Master 节点配置，见 ParamMaster | **Yes** |
| Nodes.N.* | - | Node 节点配置，见 ParamNodes | **Yes** |
| KubeProxy.Mode | string | kube-proxy 模式，iptables/ipvs | No |

# Response Elements

| Parameter name | Type | Description | Required |
|----------------|------|-------------|----------|
| RetCode | int | 返回码 | **Yes** |
| Action | string | 操作名称 | **Yes** |
| ClusterId | string | 集群 ID | No |
| Message | string | 错误信息 | No |

# 常见错误

| 错误现象 | 可能原因 | 修复 |
|----------|----------|------|
| `BalanceInsufficiency` | 账户余额不足 | 充值后重试 |
| `PermissionDenied` | 权限错误 | 确认 ProjectId 和 API 密钥匹配 |
| 参数错误 | 字段名或结构不对 | 检查拼写、数组索引从 0、Master 规格是否误放入数组 |
