# 创建集群时获取UK8S集群版本、Containerd版本-GetUK8SVersions

创建集群时获取UK8S集群版本、Containerd版本

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|地域。 参见 [地域和可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|**Yes**|
|Zone|string|可用区。参见 [可用区列表](https://docs.ucloud.cn/api/summary/regionlist)|No|
|ProjectId|string|项目ID。不填写为默认项目，子帐号必须填写。 请参考[GetProjectList接口](https://docs.ucloud.cn/api/summary/get_project_list)|No|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|
|K8sVersion|string|UK8S 的版本号。|No|
|ContainerdVersion|string|Containerd 的版本号。|No|
|Data|object|UK8S 版本信息列表。|No|

# Request Example
```
https://api.ucloud.cn/?Action=GetUK8SVersions
&Region=cn-zj
&Zone=cn-zj-01
&ProjectId=HpWKrCAn
```

# Response Example
```
{
    "Action": "GetUK8SVersionsResponse", 
    "ContainerdVersion": "piaBRUsB", 
    "Data": {}, 
    "RetCode": 0, 
    "K8sVersion": "LgmQLmzB"
}
```