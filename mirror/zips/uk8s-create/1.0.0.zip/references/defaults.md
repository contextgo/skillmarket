# UK8S 创建默认值

## 集群基础参数

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `ClusterName` | `$ARGUMENTS` 或 `uk8s` | 集群名称 |
| `ServiceCIDR` | `192.168.0.0/16` | Service 网段 |
| `ChargeType` | `Dynamic` | 计费类型（按需） |
| `ExternalApiServer` | `Yes` | 是否开启外网 ApiServer |

## Master 节点

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `MachineType` | `O` | 机型 |
| `CPU` | `2` | CPU 核数 |
| `Mem` | `4096` | 内存（MB） |
| 数量 | `3` | Master 节点数（固定） |
| `BootDiskType` | `CLOUD_RSSD` | 系统盘类型 |
| `BootDiskSize` | `40` | 系统盘大小（GB） |
| `DataDiskType` | `CLOUD_RSSD` | 数据盘类型 |
| `DataDiskSize` | `20` | 数据盘大小（GB） |

## Node 节点

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `MachineType` | `O` | 机型 |
| `CPU` | `4` | CPU 核数 |
| `Mem` | `8192` | 内存（MB） |
| 数量 | `2` | Node 节点数 |
| `MaxPods` | `110` | 单节点最大 Pod 数 |
| `BootDiskType` | `CLOUD_RSSD` | 系统盘类型 |
| `DataDiskType` | `CLOUD_RSSD` | 数据盘类型 |
| `DataDiskSize` | `20` | 数据盘大小（GB） |

## 网络

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `KubeProxy.Mode` | `iptables` | kube-proxy 模式 |

## 镜像选择规则

优先选取 `ImageName` 含 `Ubuntu 24.04` 且 Zone 匹配的镜像；找不到则取最新 Ubuntu；仍失败则 `AskUserQuestion`。
