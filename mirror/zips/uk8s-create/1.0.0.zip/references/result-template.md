# 创建成功结果模板

```
UK8S 集群创建成功！

集群名称:     <ClusterName>
集群 ID:      <ClusterId>
Region/Zone:  <Region> / <Zone>
VPC/Subnet:   <VPCId> / <SubnetId>

Master:       3 × O型 (2C/4G)
Node:         2 × O型 (4C/8G)

K8s 版本:     <K8sVersion>
Service CIDR: 192.168.0.0/16

登录密码:     <PLAIN_PWD>
（仅展示一次，请立即保存）

集群创建中，预计 5-10 分钟完成。
查看状态：
ucloud api --Action DescribeUK8SCluster \
  --Region <Region> \
  --ProjectId <ProjectId> \
  --ClusterId <ClusterId>
```
