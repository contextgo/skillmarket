# 审查数据结构 Schema

`scripts/generate_review_report.js` 中的 `reviewData` 变量需要按以下结构填充：

```javascript
const reviewData = {
  // 项目基本信息
  projectInfo: {
    name: '（项目简称）',  // 简称
    fullName: '（项目全称）水土保持方案报告书',
    reviewDate: '2026年1月1日',  // 或用 new Date() 动态生成
  },

  // 总体审查结论
  overallConclusion: '本报告章节体系完整...',
  overallStatus: 'warn',  // 'good' | 'warn' | 'bad'

  // 逐章审查数据（8章）
  chapters: [
    {
      title: '第1章 综合说明',
      description: '本章审查项目背景、编制依据、方案主要结论及水土保持方案特性表等内容。',
      status: 'good',  // 该章总体结论：'good' | 'warn' | 'bad'
      items: [
        {
          name: '项目简介（1.1节）',
          requirement: 'B1规范要求：简述项目概况、建设必要性等',
          actual: '（报告实际内容摘要）',
          opinion: '符合',
          status: '符合',  // 同 opinion 保持一致
        },
        // ... 更多子项
      ],
    },
    // ... 第2-8章
  ],

  // 主要问题汇总
  majorIssues: [
    {
      id: 1,
      location: '（问题位置）',
      problem: '（问题描述）',
      suggestion: '（修改建议）',
    },
    // ... 更多问题
  ],

  // 综合审查结论
  finalConclusion: '本报告书总体质量良好...',
  finalStatus: 'warn',  // 'good' | 'warn' | 'bad'
};
```

## 字段说明

### projectInfo

| 字段         | 类型     | 必填 | 说明   |
| ---------- | ------ | -- | ---- |
| name       | string | 是  | 项目简称 |
| fullName   | string | 是  | 报告全称 |
| reviewDate | string | 是  | 审查日期 |

### chapters\[].items\[]

| 字段          | 类型     | 必填 | 说明                   |
| ----------- | ------ | -- | -------------------- |
| name        | string | 是  | 审查子项名称（如"1.1节 项目简介"） |
| requirement | string | 是  | B1规范对该项的要求           |
| actual      | string | 是  | 报告实际内容摘要             |
| opinion     | string | 是  | 审查意见（符合/基本符合/不符合）    |
| status      | string | 是  | 与 opinion 一致，用于颜色标记  |

### majorIssues\[]

| 字段         | 类型     | 必填 | 说明        |
| ---------- | ------ | -- | --------- |
| id         | number | 是  | 序号        |
| location   | string | 是  | 问题在报告中的位置 |
| problem    | string | 是  | 问题描述      |
| suggestion | string | 是  | 修改建议      |

### status 取值

- `good`：绿色，表示符合
- `warn`：橙色，表示基本符合
- `bad`：红色，表示不符合

