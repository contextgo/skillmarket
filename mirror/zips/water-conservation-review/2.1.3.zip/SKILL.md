---
name: water-conservation-review
description: "水土保持方案报告书审查技能。当用户需要对生产建设项目水土保持方案报告书进行审查评审时使用。依据B1规范和GB50433-2018技术标准，逐章逐项审查并生成docx格式审查报告。支持综合审查报告和4份专项审查报告（B1规范结构审查、逐章标准审查、数据一致性审查、错别字审查）。"
---

# 水土保持方案报告书审查技能

依据《水土保持方案报告书内容及章节编排（B1）》和《生产建设项目水土保持技术标准》（GB50433-2018），对水土保持方案报告书（送审稿）进行全面审查，输出结构化审查报告。

## 快速开始

### 1. 完整自动化审查（推荐）

一次性生成4份专项审查报告：

```bash
# 使用自动化脚本
node scripts/auto_review.js --input <报告PDF路径> --output-dir <输出目录>

# 示例
node scripts/auto_review.js \
  --input "/path/to/报告书-送审稿.pdf" \
  --output-dir "/path/to/output/"
```

输出5份报告（1份总报告 + 4份专项报告）：
0. `审查报告-综合审查总报告.docx`（汇总4份专项审查结论）
1. `审查报告1-B1规范章节编排结构审查.docx`
2. `审查报告2-逐章对照B1及GB50433标准审查.docx`
3. `审查报告3-前后数据一致性审查.docx`
4. `审查报告4-错别字及格式审查.docx`

### 2. 生成单份综合审查报告

```bash
# 1. 准备审查数据（AI根据PDF内容填充）
# 编辑 scripts/generate_review_report.js 中的 reviewData 变量

# 2. 运行生成脚本
node scripts/generate_review_report.js --output <输出路径>

# 示例
node scripts/generate_review_report.js --output "审查报告.docx"
```

### 3. 仅提取PDF内容

```bash
node scripts/extract_pdf.js --input <PDF路径> --output <文本路径>
```

## 审查内容

### 综合审查报告结构

1. **封面**：项目名称、审查日期
2. **一、总体审查结论**：整体评价（三色结论）
3. **二、逐章审查意见**：8章 × 逐项审查表
4. **三、主要问题汇总**：问题位置、描述、建议
5. **四、综合审查结论**：最终结论与建议

### 5份审查报告（1+4）

| 报告 | 类型 | 审查内容 | 审查要素 |
|------|------|---------|---------|
| 总报告 | 综合汇总 | 汇总4份专项审查结论 | 全部问题汇总 |
| 报告1 | 专项 | B1规范章节编排结构 | 51项结构要素 |
| 报告2 | 专项 | 逐章对照B1+GB50433 | 8章逐项到三级标题 |
| 报告3 | 专项 | 前后数据一致性 | 28+项关键数据 |
| 报告4 | 专项 | 错别字及格式 | 文字错误+格式问题 |

## 审查标准（三色体系）

| 结论 | 颜色 | 含义 | 后续要求 |
|------|------|------|---------|
| 符合 | 🟢 绿 | 内容完整，符合规范 | 无需修改 |
| 基本符合 | 🟠 橙 | 整体符合，个别问题 | 针对性修改后通过 |
| 不符合 | 🔴 红 | 重大缺失或错误 | 需重新编制 |

## B1规范8章结构

| 章节 | 核心审查要点 |
|------|-------------|
| 第1章 综合说明 | 项目背景、编制依据、结论、特性表数据完整性 |
| 第2章 项目概况 | 工程特性、施工组织、土石方平衡数据详实性 |
| 第3章 水土保持评价 | 主体工程评价、弃土场评价、扰动土地面积 |
| 第4章 水土流失分析与预测 | 预测范围/时段/方法/结果合理性 |
| 第5章 水土保持措施 | 分区措施体系完整性、工程量准确性 |
| 第6章 监测 | 监测范围/时段/点位/方法/频次 |
| 第7章 投资估算 | 费用构成、取费标准、预备费 |
| 第8章 管理 | 组织制度、监理验收安排 |

## 关键数据项审查

依据 `references/GB50433-2018-生产建设项目水土保持技术标准-重要数据项.csv` 审查：

- 项目基本数据（总投资、建设期、占地面积）
- 土石方平衡（挖方、填方、借方、弃方）
- 水土保持投资（工程措施、植物措施、临时措施、独立费用）
- 六项防治指标（水土流失治理度、土壤流失控制比、渣土防护率、表土保护率、林草植被恢复率、林草覆盖率）
- 土壤侵蚀模数（背景值、扰动后、目标值）

## 技术实现

### 依赖安装

```bash
# 进入脚本目录
cd scripts

# 安装Node.js依赖
npm install

# 或单独安装
cd /tmp && npm install docx pdfplumber-js
```

### Python依赖（PDF提取）

```bash
pip3 install pdfplumber --break-system-packages
```

### 工具使用

#### 提取PDF内容
```python
import pdfplumber
with pdfplumber.open('报告.pdf') as pdf:
    for page in pdf.pages:
        text = page.extract_text()
```

#### 读取标准规范（推荐高效格式）

**Markdown格式（人工阅读）**
```bash
# 已预转换，直接使用
references/B1规范.md
references/GB50433-2018标准.md
```

**JSON结构化数据（程序处理）**
```javascript
// B1章节结构和审查要点
const b1Structure = require('./references/B1规范-结构化.json');

// GB50433关键数据项和校验规则
const gb50433Data = require('./references/GB50433-关键数据项.json');
```

**原始docx（如需重新转换）**
```bash
/opt/homebrew/bin/pandoc 'B1水土保持方案报告书内容及章节编排.docx' -t markdown -o B1规范.md
/opt/homebrew/bin/pandoc 'GB50433-2018-生产建设项目水土保持技术标准.docx' -t markdown -o GB50433-2018标准.md
```

#### 生成审查报告
```bash
# 综合报告
node scripts/generate_review_report.js --output 审查报告.docx

# 4份专项报告
node scripts/generate_specialized_reviews.js --output-dir ./output/
```

### 审查报告数据格式

脚本中的 `reviewData` 需按 `references/review-data-schema.md` 定义的 Schema 填充。核心结构：

```javascript
reviewData = {
  projectInfo: { name, fullName, reviewDate },
  overallConclusion, overallStatus,
  chapters: [{ title, description, status, items: [{ name, requirement, actual, opinion, status }] }],
  majorIssues: [{ id, location, problem, suggestion }],
  finalConclusion, finalStatus,
}
```

## 文件结构

```
water-conservation-review/
├── SKILL.md                          # 本文件
├── references/
│   ├── B1规范.md                     # B1规范Markdown版本
│   ├── B1规范-结构化.json            # B1章节结构（JSON结构化）
│   ├── GB50433-2018标准.md           # GB50433标准Markdown版本
│   ├── GB50433-关键数据项.json       # 关键数据项（JSON结构化）
│   ├── GB50433-2018-生产建设项目水土保持技术标准-重要数据项.csv  # 关键数据项CSV格式
│   ├── workflow.md                   # 详细工作流程
│   └── review-data-schema.md         # 审查数据结构定义
└── scripts/
    ├── package.json                  # Node.js依赖
    ├── extract_pdf.js                # PDF内容提取脚本
    ├── generate_review_report.js     # 综合审查报告生成
    ├── generate_specialized_reviews.js  # 4份专项报告生成
    └── auto_review.js                # 自动化完整审查（调用以上脚本）
```

## 参考资料

### 原始文档（docx）
- `references/B1水土保持方案报告书内容及章节编排.docx` — B1章节编排规范（原始文档）
- `references/GB50433-2018-生产建设项目水土保持技术标准.docx` — 技术标准全文（原始文档）

### Markdown格式（便于阅读）
- `references/B1规范.md` — B1规范Markdown版本（398行，易读易检索）
- `references/GB50433-2018标准.md` — GB50433标准Markdown版本（2238行）

### JSON结构化数据（便于程序处理）
- `references/B1规范-结构化.json` — B1章节结构、审查要点、特性表字段（结构化数据）
- `references/GB50433-关键数据项.json` — 50项关键数据项，按类别分组（含校验规则）

### 其他参考
- `references/GB50433-2018-生产建设项目水土保持技术标准-重要数据项.csv` — 关键数据项CSV格式
- `references/workflow.md` — 详细工作流程
- `references/review-data-schema.md` — 审查数据结构定义

## 注意事项

1. **PDF扫描件**：无法提取文字（chars=0），需要OCR或人工输入
2. **字符串引号**：JS脚本中字符串含中文引号时，用单引号 `'` 作为外层定界符
3. **数据一致性**：重点关注特性表数据与正文对应、投资估算前后一致
4. **责任页**：如为扫描件，建议在审查意见中提示确认签字盖章完整性
5. **pandoc路径**：macOS使用 `/opt/homebrew/bin/pandoc`，Linux使用系统默认路径

## 版本历史

- v1.0.0 - 初始版本，支持综合审查报告生成
- v2.0.0 - 新增4份专项审查报告，自动化审查流程
- v2.1.0 - 标准文档格式优化，转换为Markdown和JSON
- v2.1.1 - 移除docx原始文档，优化发布包

---

## 版权信息

**作者**：黄军雷  
**公司**：天津创锐丰科技有限公司  
**官网**：[www.crf.net.cn](http://www.crf.net.cn)  
**许可**：MIT License
