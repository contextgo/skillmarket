# 水土保持方案报告书审查脚本

## 脚本说明

本目录包含水土保持方案报告书审查的自动化脚本工具集。

**作者**：黄军雷  
**公司**：天津创锐丰科技有限公司  
**官网**：[www.crf.net.cn](http://www.crf.net.cn)

## 文件列表

| 文件 | 功能 | 使用场景 |
|------|------|---------|
| `extract_pdf.js` | 提取PDF文本内容 | 需要分析PDF报告时 |
| `generate_review_report.js` | 生成综合审查报告 | 需要单份完整报告时 |
| `generate_specialized_reviews.js` | 生成5份审查报告（1总+4专项） | 需要完整审查报告集时 |
| `auto_review.js` | 自动化完整审查流程 | 一键生成所有报告 |
| `example_review_data.json` | 审查数据示例 | 参考数据格式 |

## 快速开始

### 1. 安装依赖

```bash
cd scripts
npm install
```

### 2. 运行自动化审查

```bash
node auto_review.js --input <PDF路径> --output-dir <输出目录>
```

### 3. 让AI填充审查数据

AI会读取提取的文本，分析后填充审查数据到 `review_data.json`。

### 4. 生成报告

```bash
node generate_specialized_reviews.js --output-dir <输出目录> --data <review_data.json路径>
```

## 命令详解

### extract_pdf.js

提取PDF文本内容。

```bash
node extract_pdf.js --input report.pdf --output report.txt
node extract_pdf.js --input report.pdf --pages 1-50
```

### generate_review_report.js

生成单份综合审查报告。

```bash
# 先编辑脚本中的 reviewData 变量
node generate_review_report.js --output 审查报告.docx
```

### generate_specialized_reviews.js

生成4份专项审查报告。

```bash
node generate_specialized_reviews.js --output-dir ./output/ --data review_data.json
```

输出文件（5份）：
- `审查报告-综合审查总报告.docx`（汇总4份专项审查）
- `审查报告1-B1规范章节编排结构审查.docx`
- `审查报告2-逐章对照B1及GB50433标准审查.docx`
- `审查报告3-前后数据一致性审查.docx`
- `审查报告4-错别字及格式审查.docx`

### auto_review.js

自动化完整审查流程。

```bash
# 完整流程（提取+生成模板）
node auto_review.js --input report.pdf --output-dir ./output/

# 仅生成报告（已有审查数据）
node auto_review.js --review-data review_data.json --output-dir ./output/
```

## 数据格式

审查数据使用JSON格式，详见 `example_review_data.json`。

核心结构：

```json
{
  "report1": { /* B1规范结构审查数据 */ },
  "report2": { /* 逐章标准审查数据 */ },
  "report3": { /* 数据一致性审查数据 */ },
  "report4": { /* 错别字审查数据 */ }
}
```

## 工作流程

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  输入PDF    │ --> │  提取文本   │ --> │  AI分析填充 │ --> │  生成报告   │
│  报告书     │     │  extract_   │     │  审查数据   │     │  4份docx    │
│             │     │  pdf.js     │     │             │     │             │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                               │
                                               v
                                        ┌─────────────┐
                                        │ review_data │
                                        │   .json     │
                                        └─────────────┘
```

## 注意事项

1. PDF扫描件无法提取文字，需要OCR或人工输入
2. 确保已安装Python pdfplumber模块：`pip3 install pdfplumber`
3. 审查数据需要AI根据实际报告内容填充
4. 生成的报告使用宋体/黑体，确保系统有这些字体

## 依赖

- Node.js >= 18.0.0
- npm包：docx
- Python：pdfplumber
- 系统工具：pandoc（可选，用于转换docx规范文件）

---

**版权所有** © 2026 天津创锐丰科技有限公司  
**许可**：MIT License
