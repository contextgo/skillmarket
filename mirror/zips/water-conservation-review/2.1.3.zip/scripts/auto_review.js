/**
 * 水土保持方案报告书自动化审查脚本
 *
 * 作者：黄军雷
 * 公司：天津创锐丰科技有限公司
 * 官网：http://www.crf.net.cn
 *
 * 使用方法：
 *   node auto_review.js --input <报告PDF路径> --output-dir <输出目录>
 *
 * 功能：
 *   1. 提取PDF内容
 *   2. 分析报告结构和数据
 *   3. 生成审查数据（JSON）
 *   4. 生成4份专项审查报告（docx）
 *
 * 示例：
 *   node auto_review.js \
 *     --input "/path/to/报告书-送审稿.pdf" \
 *     --output-dir "/path/to/output/"
 *
 * 版权所有 © 2026 天津创锐丰科技有限公司
 * 许可：MIT License
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ============================================================
// 解析命令行参数
// ============================================================
function parseArgs() {
  const args = process.argv.slice(2);
  const result = { input: '', outputDir: '', reviewDataFile: '' };
  
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input' && args[i + 1]) result.input = args[++i];
    if (args[i] === '--output-dir' && args[i + 1]) result.outputDir = args[++i];
    if (args[i] === '--review-data' && args[i + 1]) result.reviewDataFile = args[++i];
  }
  
  return result;
}

// ============================================================
// 步骤1：提取PDF内容
// ============================================================
function extractPDF(inputPath, outputDir) {
  console.log('\n[步骤1/4] 提取PDF内容...');
  
  const extractScript = path.join(__dirname, 'extract_pdf.js');
  const outputTextPath = path.join(outputDir, 'extracted_content.txt');
  
  try {
    execSync(`node "${extractScript}" --input "${inputPath}" --output "${outputTextPath}"`, {
      stdio: 'inherit'
    });
    console.log('✓ PDF内容提取完成');
    return outputTextPath;
  } catch (error) {
    console.error('✗ PDF提取失败');
    throw error;
  }
}

// ============================================================
// 步骤2：生成审查数据（AI分析后填充）
// ============================================================
function generateReviewData(inputPath, outputDir, extractedTextPath) {
  console.log('\n[步骤2/4] 生成审查数据模板...');
  
  const projectName = path.basename(inputPath, path.extname(inputPath)).replace(/水土保持方案报告书.*$/, '').replace(/-送审稿/, '');
  const reviewDate = new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
  
  // 创建审查数据模板
  const reviewData = {
    report1: {
      projectName,
      reviewDate,
      totalItems: 51,
      passCount: 48,
      warnCount: 3,
      failCount: 0,
      overallStatus: 'warn',
      items: [], // AI需要填充
      issues: [], // AI需要填充
      conclusion: '' // AI需要填充
    },
    report2: {
      projectName,
      reviewDate,
      chapters: [], // AI需要填充8章审查数据
      issues: [], // AI需要填充
      conclusion: '', // AI需要填充
      overallStatus: 'warn'
    },
    report3: {
      projectName,
      reviewDate,
      totalItems: 28,
      consistentCount: 27,
      inconsistentCount: 1,
      doubtCount: 0,
      overallStatus: 'warn',
      items: [], // AI需要填充
      validations: [], // AI需要填充
      issues: [], // AI需要填充
      conclusion: '' // AI需要填充
    },
    report4: {
      projectName,
      reviewDate,
      totalIssues: 11,
      textErrors: 8,
      formatIssues: 3,
      otherIssues: 0,
      overallStatus: 'warn',
      typoIssues: [], // AI需要填充
      formatIssuesList: [], // AI需要填充
      conclusion: '' // AI需要填充
    }
  };
  
  const dataFilePath = path.join(outputDir, 'review_data_template.json');
  fs.writeFileSync(dataFilePath, JSON.stringify(reviewData, null, 2), 'utf-8');
  
  console.log(`✓ 审查数据模板已生成: ${dataFilePath}`);
  console.log('\n⚠️  重要：请让AI读取提取的文本内容，填充审查数据后保存为 review_data.json');
  
  return dataFilePath;
}

// ============================================================
// 步骤3：等待AI填充数据（提示用户）
// ============================================================
function waitForReviewData(outputDir) {
  console.log('\n[步骤3/4] 等待审查数据...');
  
  const dataFilePath = path.join(outputDir, 'review_data.json');
  
  console.log(`\n请让AI完成以下工作：`);
  console.log(`1. 读取提取的文本文件: ${path.join(outputDir, 'extracted_content.txt')}`);
  console.log(`2. 参考审查数据模板: ${path.join(outputDir, 'review_data_template.json')}`);
  console.log(`3. 根据实际审查结果填充数据`);
  console.log(`4. 保存为: ${dataFilePath}`);
  
  return dataFilePath;
}

// ============================================================
// 步骤4：生成审查报告
// ============================================================
function generateReports(outputDir, reviewDataFile) {
  console.log('\n[步骤4/4] 生成审查报告...');
  
  const genScript = path.join(__dirname, 'generate_specialized_reviews.js');
  
  try {
    execSync(`node "${genScript}" --output-dir "${outputDir}" --data "${reviewDataFile}"`, {
      stdio: 'inherit'
    });
    console.log('✓ 审查报告生成完成');
  } catch (error) {
    console.error('✗ 报告生成失败');
    throw error;
  }
}

// ============================================================
// 主函数
// ============================================================
async function main() {
  const args = parseArgs();
  
  // 验证参数
  if (!args.input && !args.reviewDataFile) {
    console.error('用法：node auto_review.js --input <PDF路径> --output-dir <输出目录>');
    console.error('   或：node auto_review.js --review-data <JSON路径> --output-dir <输出目录>');
    process.exit(1);
  }
  
  if (args.input && !fs.existsSync(args.input)) {
    console.error(`错误：文件不存在: ${args.input}`);
    process.exit(1);
  }
  
  // 确保输出目录存在
  if (!fs.existsSync(args.outputDir)) {
    fs.mkdirSync(args.outputDir, { recursive: true });
  }
  
  // 如果直接提供了审查数据文件，跳过提取和分析步骤
  if (args.reviewDataFile) {
    generateReports(args.outputDir, args.reviewDataFile);
    console.log(`\n✓ 全部完成！报告已保存到: ${args.outputDir}`);
    return;
  }
  
  // 完整流程
  try {
    // 步骤1：提取PDF
    const extractedTextPath = extractPDF(args.input, args.outputDir);
    
    // 步骤2：生成审查数据模板
    const templatePath = generateReviewData(args.input, args.outputDir, extractedTextPath);
    
    // 步骤3：提示AI填充数据
    const dataFilePath = waitForReviewData(args.outputDir);
    
    console.log('\n' + '='.repeat(60));
    console.log('请完成数据填充后，运行以下命令生成报告：');
    console.log('='.repeat(60));
    console.log(`\nnode ${__filename} --review-data "${dataFilePath}" --output-dir "${args.outputDir}"`);
    console.log('\n或让AI直接调用 generate_specialized_reviews.js：');
    console.log(`node ${path.join(__dirname, 'generate_specialized_reviews.js')} --output-dir "${args.outputDir}" --data "${dataFilePath}"`);
    console.log('='.repeat(60));
    
  } catch (error) {
    console.error('\n✗ 自动化审查失败:', error.message);
    process.exit(1);
  }
}

main();
