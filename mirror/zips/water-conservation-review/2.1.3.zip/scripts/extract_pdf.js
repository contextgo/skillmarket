/**
 * PDF内容提取脚本
 *
 * 作者：黄军雷
 * 公司：天津创锐丰科技有限公司
 * 官网：http://www.crf.net.cn
 *
 * 使用方法：
 *   node extract_pdf.js --input <PDF路径> [--output <输出路径>] [--pages <页码范围>]
 *
 * 示例：
 *   node extract_pdf.js --input report.pdf --output report.txt
 *   node extract_pdf.js --input report.pdf --pages 1-50
 *
 * 依赖：Python pdfplumber 模块
 *   pip3 install pdfplumber
 *
 * 版权所有 © 2026 天津创锐丰科技有限公司
 * 许可：MIT License
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// 解析命令行参数
function parseArgs() {
  const args = process.argv.slice(2);
  const result = { input: '', output: '', pages: '' };
  
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input' && args[i + 1]) result.input = args[++i];
    if (args[i] === '--output' && args[i + 1]) result.output = args[++i];
    if (args[i] === '--pages' && args[i + 1]) result.pages = args[++i];
  }
  
  return result;
}

// 使用Python pdfplumber提取PDF内容
function extractWithPdfplumber(inputPath, outputPath, pages) {
  const pythonScript = `
import pdfplumber
import sys

pdf_path = '${inputPath.replace(/'/g, "\\'")}'
output_path = '${outputPath.replace(/'/g, "\\'")}'
pages_range = '${pages}'

try:
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        print(f"PDF总页数: {total_pages}", file=sys.stderr)
        
        # 解析页码范围
        start_page = 0
        end_page = total_pages
        
        if pages_range:
            if '-' in pages_range:
                parts = pages_range.split('-')
                start_page = int(parts[0]) - 1 if parts[0] else 0
                end_page = int(parts[1]) if parts[1] else total_pages
            else:
                start_page = int(pages_range) - 1
                end_page = start_page + 1
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for i in range(start_page, min(end_page, total_pages)):
                page = pdf.pages[i]
                text = page.extract_text()
                
                if text:
                    f.write(f"=== Page {i + 1} ===\\n")
                    f.write(text)
                    f.write("\\n\\n")
                else:
                    f.write(f"=== Page {i + 1} ===\\n")
                    f.write("[本页为扫描件或图片，无法提取文字]\\n\\n")
                    
        print(f"提取完成，已保存到: {output_path}", file=sys.stderr)
        
except Exception as e:
    print(f"错误: {e}", file=sys.stderr)
    sys.exit(1)
`;

  const tempScript = `/tmp/extract_pdf_${Date.now()}.py`;
  fs.writeFileSync(tempScript, pythonScript);
  
  try {
    const result = execSync(`python3 "${tempScript}"`, { encoding: 'utf-8', stdio: 'pipe' });
    console.log(result);
  } catch (error) {
    console.error('提取失败:', error.stderr || error.message);
    throw error;
  } finally {
    fs.unlinkSync(tempScript);
  }
}

// 主函数
async function main() {
  const args = parseArgs();
  
  if (!args.input) {
    console.error('错误：请使用 --input <PDF路径> 指定输入文件');
    console.error('用法：node extract_pdf.js --input <PDF路径> [--output <输出路径>] [--pages <页码范围>]');
    process.exit(1);
  }
  
  if (!fs.existsSync(args.input)) {
    console.error(`错误：文件不存在: ${args.input}`);
    process.exit(1);
  }
  
  // 默认输出路径
  if (!args.output) {
    const basename = path.basename(args.input, path.extname(args.input));
    args.output = path.join(path.dirname(args.input), `${basename}_extracted.txt`);
  }
  
  console.log(`正在提取: ${args.input}`);
  if (args.pages) {
    console.log(`页码范围: ${args.pages}`);
  }
  console.log(`输出路径: ${args.output}`);
  
  try {
    extractWithPdfplumber(args.input, args.output, args.pages);
    console.log(`\n✓ 提取完成: ${args.output}`);
  } catch (error) {
    console.error('\n✗ 提取失败');
    process.exit(1);
  }
}

main();
