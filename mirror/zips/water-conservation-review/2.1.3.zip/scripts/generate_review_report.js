/**
 * 水土保持方案报告书审查报告生成脚本
 *
 * 作者：黄军雷
 * 公司：天津创锐丰科技有限公司
 * 官网：http://www.crf.net.cn
 *
 * 使用方法：
 *   node generate_review_report.js --input <待审查PDF路径> --output <输出docx路径>
 *
 * 前置条件：
 *   npm install docx
 *
 * 说明：
 *   脚本会在运行时要求 AI 填充审查数据（reviewData 变量），
 *   因此本脚本是一个模板，需要根据实际审查结果修改 reviewData 后再运行。
 *
 * 版权所有 © 2026 天津创锐丰科技有限公司
 * 许可：MIT License
 */

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, Table, TableRow, TableCell,
  TextRun, WidthType, AlignmentType, HeadingLevel, Header, Footer,
  PageNumber, NumberFormat, BorderStyle, ShadingType, convertInchesToTwip
} = require('docx');

// ============================================================
// 解析命令行参数
// ============================================================
function parseArgs() {
  const args = process.argv.slice(2);
  let inputPath = '';
  let outputPath = '';
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input' && args[i + 1]) inputPath = args[++i];
    if (args[i] === '--output' && args[i + 1]) outputPath = args[++i];
  }
  return { inputPath, outputPath };
}

const { inputPath, outputPath } = parseArgs();

// ============================================================
// 审查数据（由 AI 根据审查结果填充）
// ============================================================
// TODO: 根据实际审查结果填充以下数据结构
const reviewData = {
  projectInfo: {
    name: '（项目名称）',
    fullName: '（项目全称）水土保持方案报告书（送审稿）',
    reviewDate: new Date().toISOString().split('T')[0].replace(/-/g, '年').replace(/年/, '年').replace(/年/, '月') + '日',
  },

  // 1. 总体审查结论
  overallConclusion: '（总体评价文字）',
  overallStatus: 'warn', // 'good' | 'warn' | 'bad'

  // 2. 逐章审查数据
  // 每章包含: { title, status, conclusion, items: [{name, requirement, actual, opinion, status}] }
  chapters: [
    // TODO: 按实际审查结果填充各章数据
    // 示例格式见下方 references/review-data-schema.md
  ],

  // 3. 主要问题汇总
  majorIssues: [
    // TODO: { id, location, problem, suggestion }
  ],

  // 4. 综合审查结论
  finalConclusion: '（综合审查结论文字）',
  finalStatus: 'warn',
};

// ============================================================
// 颜色与样式常量
// ============================================================
const COLOR_TITLE = '1F4E79';
const COLOR_PASS = '2E7D32';
const COLOR_WARN = 'E65100';
const COLOR_FAIL = 'C62828';
const COLOR_BG_PASS = 'E8F5E9';
const COLOR_BG_WARN = 'FFF3E0';
const COLOR_BG_FAIL = 'FFEBEE';
const COLOR_HEADER_BG = '1F4E79';
const COLOR_HEADER_FG = 'FFFFFF';
const COLOR_ALT_ROW = 'F5F5F5';

const FONT_TITLE = 'SimHei';
const FONT_BODY = 'SimSun';
const FONT_EN = 'Times New Roman';

// ============================================================
// 工具函数
// ============================================================
function para(text, bold = false) {
  return new Paragraph({
    spacing: { after: 120, line: 360 },
    children: [new TextRun({ text, size: 24, font: FONT_BODY, bold })],
  });
}

function bulletPara(text) {
  return new Paragraph({
    spacing: { after: 80, line: 360 },
    indent: { left: 420, hanging: 420 },
    children: [new TextRun({ text: '• ', size: 24, font: FONT_BODY }), new TextRun({ text, size: 24, font: FONT_BODY })],
  });
}

function noticePara(text, type = 'warn') {
  const bgColor = type === 'good' ? COLOR_BG_PASS : type === 'bad' ? COLOR_BG_FAIL : COLOR_BG_WARN;
  const fgColor = type === 'good' ? COLOR_PASS : type === 'bad' ? COLOR_FAIL : COLOR_WARN;
  return new Paragraph({
    spacing: { before: 120, after: 120 },
    shading: { fill: bgColor, type: ShadingType.CLEAR },
    children: [new TextRun({ text, size: 24, font: FONT_BODY, color: fgColor, bold: true })],
  });
}

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, size: 32, bold: true, font: FONT_TITLE, color: COLOR_TITLE })],
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, size: 28, bold: true, font: FONT_TITLE, color: '2E75B6' })],
  });
}

function heading3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 100 },
    children: [new TextRun({ text, size: 26, bold: true, font: FONT_TITLE })],
  });
}

function hCell(text, width) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
    verticalAlign: 'center',
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, size: 22, bold: true, color: COLOR_HEADER_FG, font: FONT_BODY })] })],
  });
}

function dCell(text, width, align = null, bold = false) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    verticalAlign: 'center',
    children: [new Paragraph({
      alignment: align || AlignmentType.LEFT,
      spacing: { before: 40, after: 40 },
      children: [new TextRun({ text, size: 21, font: FONT_BODY, bold })],
    })],
  });
}

function statusCell(status, displayText, width) {
  const shade = status === '符合' ? COLOR_BG_PASS : status === '基本符合' ? COLOR_BG_WARN : COLOR_BG_FAIL;
  const color = status === '符合' ? COLOR_PASS : status === '基本符合' ? COLOR_WARN : COLOR_FAIL;
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { fill: shade, type: ShadingType.CLEAR },
    verticalAlign: 'center',
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: displayText, size: 22, bold: true, color, font: FONT_BODY })] })],
  });
}

// ============================================================
// 构建文档
// ============================================================
function buildDocument(data) {
  const children = [];

  // --- 封面 ---
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '审  查  报  告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: data.projectInfo.name, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: '项目水土保持方案报告书', size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${data.projectInfo.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // --- 一、总体审查结论 ---
  children.push(
    heading1('一、总体审查结论'),
    para(data.overallConclusion),
    noticePara(`总体结论：${data.overallStatus === 'good' ? '符合规范要求' : data.overallStatus === 'warn' ? '基本符合规范要求，需修改完善' : '不符合规范要求，需重大修改'}`, data.overallStatus),
  );

  // --- 二、逐章审查意见 ---
  children.push(
    heading1('二、逐章审查意见'),
    para('以下按照《水土保持方案报告书内容及章节编排（B1）》规定的8章结构，逐章逐项给出审查意见。审查标准为：符合（绿色）、基本符合（橙色）、不符合（红色）。'),
  );

  // 审查标准说明表
  children.push(
    new Table({
      width: { size: 9026, type: WidthType.DXA },
      rows: [
        new TableRow({ children: [hCell('审查结论', 1600), hCell('含义', 4200), hCell('后续要求', 3226)] }),
        new TableRow({ children: [statusCell('符合', '符合', 1600), dCell('内容完整、符合B1规范及GB50433技术标准要求', 4200), dCell('无需修改', 3226)] }),
        new TableRow({ children: [statusCell('基本符合', '基本符合', 1600), dCell('整体符合要求，但存在个别问题需要补充或修正', 4200), dCell('针对性修改后可通过', 3226)] }),
        new TableRow({ children: [statusCell('不符合', '不符合', 1600), dCell('存在重大缺失或错误，不符合规范要求', 4200), dCell('需重新编制或重大修改', 3226)] }),
      ],
    }),
    new Paragraph({ spacing: { after: 200 }, children: [] }),
  );

  // 逐章生成审查表格
  (data.chapters || []).forEach((chapter) => {
    children.push(heading2(chapter.title));
    children.push(para(chapter.description || ''));

    const rows = [
      new TableRow({ children: [hCell('审查子项', 1600), hCell('B1规范要求', 2600), hCell('报告内容摘要', 2600), hCell('审查意见', 2226)] }),
    ];

    (chapter.items || []).forEach((item, idx) => {
      rows.push(new TableRow({
        children: [
          dCell(item.name, 1600),
          dCell(item.requirement, 2600),
          dCell(item.actual, 2600),
          statusCell(item.status, item.opinion, 2226),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));
    children.push(noticePara(`结论：${chapter.status}`, chapter.status));
  });

  // --- 三、主要问题汇总 ---
  children.push(
    heading1('三、主要问题汇总'),
    para('经审查发现的主要问题汇总如下：'),
  );

  const issueRows = [
    new TableRow({ children: [hCell('序号', 400), hCell('问题位置', 1800), hCell('问题描述', 3000), hCell('修改建议', 3826)] }),
  ];
  (data.majorIssues || []).forEach((issue) => {
    issueRows.push(new TableRow({
      children: [
        dCell(String(issue.id), 400, AlignmentType.CENTER, true),
        dCell(issue.location, 1800),
        dCell(issue.problem, 3000),
        dCell(issue.suggestion, 3826),
      ],
    }));
  });

  children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows: issueRows }));

  // --- 四、综合审查结论 ---
  children.push(
    heading1('四、综合审查结论'),
    para(data.finalConclusion),
    noticePara(`综合审查结论：${data.finalStatus === 'good' ? '符合规范要求，可作为报批件提交审批。' : data.finalStatus === 'warn' ? '基本符合规范要求，在按照上述修改意见修改完善后，可作为正式报批件提交审批。' : '不符合规范要求，建议重新编制后重新报审。'}`, data.finalStatus),
  );

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: '水土保持方案报告书审查报告',
    description: '基于B1规范和GB50433技术标准的审查报告',
    styles: {
      default: {
        document: { run: { font: FONT_BODY, size: 24 } },
        heading1: { run: { font: FONT_TITLE, size: 32, bold: true, color: COLOR_TITLE } },
        heading2: { run: { font: FONT_TITLE, size: 28, bold: true, color: '2E75B6' } },
        heading3: { run: { font: FONT_TITLE, size: 26, bold: true } },
      },
    },
    sections: [{
      properties: {
        page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: '水土保持方案报告书审查报告', size: 18, color: '808080', font: FONT_BODY })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: '第 ', size: 18, font: FONT_BODY }),
              new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }),
              new TextRun({ text: ' 页', size: 18, font: FONT_BODY }),
            ],
          })],
        }),
      },
      children,
    }],
  });
}

// ============================================================
// 主函数
// ============================================================
async function main() {
  if (!outputPath) {
    console.error('错误：请使用 --output <输出路径> 指定输出文件');
    console.error('用法：node generate_review_report.js --input <待审查PDF> --output <输出docx>');
    process.exit(1);
  }

  const doc = buildDocument(reviewData);
  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputPath, buffer);
  console.log(`审查报告已生成：${outputPath}`);
}

main().catch((err) => {
  console.error('生成失败：', err);
  process.exit(1);
});
