/**
 * 5份审查报告生成脚本（1份总报告 + 4份专项报告）
 *
 * 作者：黄军雷
 * 公司：天津创锐丰科技有限公司
 * 官网：http://www.crf.net.cn
 *
 * 使用方法：
 *   node generate_specialized_reviews.js --output-dir <输出目录> [--data <JSON数据文件>]
 *
 * 说明：
 *   生成5份审查报告：
 *   0. 审查报告-综合审查总报告.docx（汇总4份专项审查结论）
 *   1. 审查报告1-B1规范章节编排结构审查.docx
 *   2. 审查报告2-逐章对照B1及GB50433标准审查.docx
 *   3. 审查报告3-前后数据一致性审查.docx
 *   4. 审查报告4-错别字及格式审查.docx
 *
 * 前置条件：
 *   npm install docx
 *
 * 版权所有 © 2026 天津创锐丰科技有限公司
 * 许可：MIT License
 */

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, Table, TableRow, TableCell,
  TextRun, WidthType, AlignmentType, HeadingLevel, Header, Footer,
  PageNumber, ShadingType
} = require('docx');

// ============================================================
// 颜色与样式常量
// ============================================================
const COLOR_TITLE = '1F4E79';
const COLOR_PASS = '2E7D32';
const COLOR_WARN = 'E65100';
const COLOR_FAIL = 'C62828';
const COLOR_BG_PASS = 'E8F5E9';
const COLOR_BG_WARN = 'FFF3E0';
const COLOR_BG_FAIL = 'FFEBEE';
const COLOR_HEADER_BG = '1F4E79';
const COLOR_HEADER_FG = 'FFFFFF';

const FONT_TITLE = 'SimHei';
const FONT_BODY = 'SimSun';

// ============================================================
// 工具函数
// ============================================================
function para(text, bold = false, options = {}) {
  return new Paragraph({
    spacing: { after: 120, line: 360, ...options.spacing },
    children: [new TextRun({ text, size: 24, font: FONT_BODY, bold })],
  });
}

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, size: 32, bold: true, font: FONT_TITLE, color: COLOR_TITLE })],
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, size: 28, bold: true, font: FONT_TITLE, color: '2E75B6' })],
  });
}

function hCell(text, width) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
    verticalAlign: 'center',
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, size: 22, bold: true, color: COLOR_HEADER_FG, font: FONT_BODY })] })],
  });
}

function dCell(text, width, align = null, bold = false) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    verticalAlign: 'center',
    children: [new Paragraph({
      alignment: align || AlignmentType.LEFT,
      spacing: { before: 40, after: 40 },
      children: [new TextRun({ text: String(text), size: 21, font: FONT_BODY, bold })],
    })],
  });
}

function statusCell(status, displayText, width) {
  const shade = status === '符合' || status === '一致' ? COLOR_BG_PASS : 
                status === '基本符合' || status === '基本' ? COLOR_BG_WARN : COLOR_BG_FAIL;
  const color = status === '符合' || status === '一致' ? COLOR_PASS : 
                status === '基本符合' || status === '基本' ? COLOR_WARN : COLOR_FAIL;
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { fill: shade, type: ShadingType.CLEAR },
    verticalAlign: 'center',
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: displayText, size: 22, bold: true, color, font: FONT_BODY })] })],
  });
}

function noticePara(text, type = 'warn') {
  const bgColor = type === 'good' ? COLOR_BG_PASS : type === 'bad' ? COLOR_BG_FAIL : COLOR_BG_WARN;
  const fgColor = type === 'good' ? COLOR_PASS : type === 'bad' ? COLOR_FAIL : COLOR_WARN;
  return new Paragraph({
    spacing: { before: 120, after: 120 },
    shading: { fill: bgColor, type: ShadingType.CLEAR },
    children: [new TextRun({ text, size: 24, font: FONT_BODY, color: fgColor, bold: true })],
  });
}

// ============================================================
// 报告1：B1规范章节编排结构审查
// ============================================================
function buildReport1(data) {
  const children = [];
  const d = data.report1;

  // 封面
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书审查报告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '（专项审查一）', size: 32, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: 'B1规范章节编排结构审查', size: 36, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      children: [new TextRun({ text: d.projectName, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${d.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // 审查说明
  children.push(
    heading1('一、审查说明'),
    para('本报告依据《水土保持方案报告书内容及章节编排（B1）》对报告书的章节编排结构进行专项审查。'),
    para('审查内容包括：8章结构完整性、各章必备要素、附件附图要求等。'),
  );

  // 审查结果汇总
  children.push(
    heading1('二、审查结果汇总'),
    para(`共审查 ${d.totalItems} 项结构要素，其中：`),
    noticePara(`符合 ${d.passCount} 项 | 基本符合 ${d.warnCount} 项 | 不符合 ${d.failCount} 项`, d.overallStatus),
  );

  // 详细审查表
  children.push(heading1('三、详细审查表'));

  const rows = [
    new TableRow({ children: [hCell('序号', 600), hCell('审查要素', 3000), hCell('B1规范要求', 3500), hCell('审查结果', 1926)] }),
  ];

  d.items.forEach((item, idx) => {
    rows.push(new TableRow({
      children: [
        dCell(idx + 1, 600, AlignmentType.CENTER),
        dCell(item.element, 3000),
        dCell(item.requirement, 3500),
        statusCell(item.status, item.status, 1926),
      ],
    }));
  });

  children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));

  // 主要问题
  if (d.issues && d.issues.length > 0) {
    children.push(heading1('四、主要问题'));
    d.issues.forEach((issue, idx) => {
      children.push(para(`${idx + 1}. ${issue.location}：${issue.problem}`));
      children.push(para(`   建议：${issue.suggestion}`, false, { spacing: { after: 200 } }));
    });
  }

  // 审查结论
  children.push(
    heading1('五、审查结论'),
    para(d.conclusion),
    noticePara(`总体结论：${d.overallStatus === 'good' ? '符合B1规范要求' : d.overallStatus === 'warn' ? '基本符合B1规范要求，需修改完善' : '不符合B1规范要求'}`, d.overallStatus),
  );

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: 'B1规范章节编排结构审查报告',
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'B1规范章节编排结构审查报告', size: 18, color: '808080', font: FONT_BODY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '第 ', size: 18, font: FONT_BODY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }), new TextRun({ text: ' 页', size: 18, font: FONT_BODY })] })] }) },
      children,
    }],
  });
}

// ============================================================
// 报告2：逐章对照B1及GB50433标准审查
// ============================================================
function buildReport2(data) {
  const children = [];
  const d = data.report2;

  // 封面
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书审查报告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '（专项审查二）', size: 32, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: '逐章对照B1及GB50433标准审查', size: 36, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      children: [new TextRun({ text: d.projectName, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${d.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // 审查说明
  children.push(
    heading1('一、审查说明'),
    para('本报告依据《水土保持方案报告书内容及章节编排（B1）》和《生产建设项目水土保持技术标准》（GB50433-2018），对报告书进行逐章逐项审查。'),
    para('审查深度：到三级标题，覆盖所有必备要素。'),
  );

  // 逐章审查
  children.push(heading1('二、逐章审查意见'));

  d.chapters.forEach((chapter) => {
    children.push(heading2(chapter.title));
    children.push(para(chapter.description || ''));

    const rows = [
      new TableRow({ children: [hCell('审查子项', 1600), hCell('规范要求', 2600), hCell('报告内容', 2600), hCell('审查意见', 2226)] }),
    ];

    chapter.items.forEach((item) => {
      rows.push(new TableRow({
        children: [
          dCell(item.name, 1600),
          dCell(item.requirement, 2600),
          dCell(item.actual, 2600),
          statusCell(item.status, item.opinion, 2226),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));
    children.push(noticePara(`本章结论：${chapter.status}`, chapter.status));
  });

  // 主要问题汇总
  if (d.issues && d.issues.length > 0) {
    children.push(heading1('三、主要问题汇总'));

    const issueRows = [
      new TableRow({ children: [hCell('序号', 400), hCell('问题位置', 1800), hCell('问题描述', 3000), hCell('修改建议', 3826)] }),
    ];

    d.issues.forEach((issue) => {
      issueRows.push(new TableRow({
        children: [
          dCell(String(issue.id), 400, AlignmentType.CENTER, true),
          dCell(issue.location, 1800),
          dCell(issue.problem, 3000),
          dCell(issue.suggestion, 3826),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows: issueRows }));
  }

  // 审查结论
  children.push(
    heading1('四、审查结论'),
    para(d.conclusion),
    noticePara(`总体结论：${d.overallStatus === 'good' ? '符合规范要求' : d.overallStatus === 'warn' ? '基本符合规范要求，需修改完善' : '不符合规范要求'}`, d.overallStatus),
  );

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: '逐章对照B1及GB50433标准审查报告',
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '逐章对照B1及GB50433标准审查报告', size: 18, color: '808080', font: FONT_BODY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '第 ', size: 18, font: FONT_BODY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }), new TextRun({ text: ' 页', size: 18, font: FONT_BODY })] })] }) },
      children,
    }],
  });
}

// ============================================================
// 报告3：前后数据一致性审查
// ============================================================
function buildReport3(data) {
  const children = [];
  const d = data.report3;

  // 封面
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书审查报告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '（专项审查三）', size: 32, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: '前后数据一致性审查', size: 36, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      children: [new TextRun({ text: d.projectName, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${d.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // 审查说明
  children.push(
    heading1('一、审查说明'),
    para('本报告依据《生产建设项目水土保持技术标准》（GB50433-2018）重要数据项要求，对报告书前后数据一致性进行专项审查。'),
    para('审查范围包括：项目基本数据、土石方平衡、水土保持投资、六项防治指标等关键数据。'),
  );

  // 审查结果汇总
  children.push(
    heading1('二、审查结果汇总'),
    para(`共审查 ${d.totalItems} 项关键数据，其中：`),
    noticePara(`一致 ${d.consistentCount} 项 | 不一致 ${d.inconsistentCount} 项 | 存疑 ${d.doubtCount} 项`, d.overallStatus),
  );

  // 详细审查表
  children.push(heading1('三、数据一致性审查表'));

  const rows = [
    new TableRow({ children: [hCell('序号', 500), hCell('数据项', 2000), hCell('首次出现位置/数值', 2500), hCell('后续出现位置/数值', 2500), hCell('一致性', 1526)] }),
  ];

  d.items.forEach((item, idx) => {
    rows.push(new TableRow({
      children: [
        dCell(idx + 1, 500, AlignmentType.CENTER),
        dCell(item.name, 2000),
        dCell(`${item.firstLocation}\n${item.firstValue}`, 2500),
        dCell(`${item.secondLocation}\n${item.secondValue}`, 2500),
        statusCell(item.consistency, item.consistency, 1526),
      ],
    }));
  });

  children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));

  // 数据校验
  if (d.validations && d.validations.length > 0) {
    children.push(heading1('四、数据逻辑校验'));

    d.validations.forEach((v) => {
      children.push(heading2(v.name));
      children.push(para(`校验公式：${v.formula}`));
      children.push(para(`校验结果：${v.result}`));
      children.push(noticePara(`结论：${v.status}`, v.status === '通过' ? 'good' : 'bad'));
    });
  }

  // 不一致问题
  if (d.issues && d.issues.length > 0) {
    children.push(heading1('五、数据不一致问题'));

    const issueRows = [
      new TableRow({ children: [hCell('序号', 400), hCell('数据项', 1500), hCell('问题描述', 3500), hCell('修改建议', 3626)] }),
    ];

    d.issues.forEach((issue, idx) => {
      issueRows.push(new TableRow({
        children: [
          dCell(String(idx + 1), 400, AlignmentType.CENTER, true),
          dCell(issue.dataItem, 1500),
          dCell(issue.problem, 3500),
          dCell(issue.suggestion, 3626),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows: issueRows }));
  }

  // 审查结论
  children.push(
    heading1('六、审查结论'),
    para(d.conclusion),
    noticePara(`总体结论：${d.overallStatus === 'good' ? '数据一致性良好' : d.overallStatus === 'warn' ? '存在数据不一致，需核实修正' : '数据存在重大问题'}`, d.overallStatus),
  );

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: '前后数据一致性审查报告',
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '前后数据一致性审查报告', size: 18, color: '808080', font: FONT_BODY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '第 ', size: 18, font: FONT_BODY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }), new TextRun({ text: ' 页', size: 18, font: FONT_BODY })] })] }) },
      children,
    }],
  });
}

// ============================================================
// 报告4：错别字及格式审查
// ============================================================
function buildReport4(data) {
  const children = [];
  const d = data.report4;

  // 封面
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书审查报告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '（专项审查四）', size: 32, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new TextRun({ text: '错别字及格式审查', size: 36, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      children: [new TextRun({ text: d.projectName, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${d.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // 审查说明
  children.push(
    heading1('一、审查说明'),
    para('本报告对报告书的文字错误、格式规范进行专项审查。'),
    para('审查范围包括：错别字、文字重复、标点符号、编号格式、图表格式等。'),
  );

  // 审查结果汇总
  children.push(
    heading1('二、审查结果汇总'),
    para(`共发现 ${d.totalIssues} 处问题，其中：`),
    noticePara(`文字错误 ${d.textErrors} 处 | 格式问题 ${d.formatIssues} 处 | 其他 ${d.otherIssues} 处`, d.overallStatus),
  );

  // 错别字问题
  if (d.typoIssues && d.typoIssues.length > 0) {
    children.push(heading1('三、错别字问题'));

    const rows = [
      new TableRow({ children: [hCell('序号', 400), hCell('位置', 1500), hCell('错误内容', 2000), hCell('正确内容', 2000), hCell('错误类型', 1526), hCell('严重程度', 1600)] }),
    ];

    d.typoIssues.forEach((issue, idx) => {
      rows.push(new TableRow({
        children: [
          dCell(idx + 1, 400, AlignmentType.CENTER),
          dCell(issue.location, 1500),
          dCell(issue.error, 2000),
          dCell(issue.correct, 2000),
          dCell(issue.type, 1526),
          statusCell(issue.severity, issue.severity, 1600),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));
  }

  // 格式问题
  if (d.formatIssuesList && d.formatIssuesList.length > 0) {
    children.push(heading1('四、格式规范问题'));

    const rows = [
      new TableRow({ children: [hCell('序号', 400), hCell('位置', 1500), hCell('问题描述', 3500), hCell('规范要求', 3626)] }),
    ];

    d.formatIssuesList.forEach((issue, idx) => {
      rows.push(new TableRow({
        children: [
          dCell(idx + 1, 400, AlignmentType.CENTER),
          dCell(issue.location, 1500),
          dCell(issue.problem, 3500),
          dCell(issue.standard, 3626),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows }));
  }

  // 审查结论
  children.push(
    heading1('五、审查结论'),
    para(d.conclusion),
    noticePara(`总体结论：${d.overallStatus === 'good' ? '文字质量良好，无明显错误' : d.overallStatus === 'warn' ? '存在少量文字/格式问题，需修改' : '文字/格式问题较多，需全面校对'}`, d.overallStatus),
  );

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: '错别字及格式审查报告',
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '错别字及格式审查报告', size: 18, color: '808080', font: FONT_BODY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '第 ', size: 18, font: FONT_BODY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }), new TextRun({ text: ' 页', size: 18, font: FONT_BODY })] })] }) },
      children,
    }],
  });
}

// ============================================================
// 报告0：综合审查总报告（汇总4份专项审查）
// ============================================================
function buildReport0(data) {
  const children = [];
  const d = data.report0;
  const r1 = data.report1;
  const r2 = data.report2;
  const r3 = data.report3;
  const r4 = data.report4;

  // 封面
  children.push(
    new Paragraph({ spacing: { before: 2400 }, children: [] }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [new TextRun({ text: '水土保持方案报告书', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [new TextRun({ text: '综 合 审 查 报 告', size: 52, bold: true, color: COLOR_TITLE, font: FONT_TITLE })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      children: [new TextRun({ text: d.projectName, size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 200 },
      children: [new TextRun({ text: '项目水土保持方案报告书（送审稿）', size: 28, color: '404040', font: FONT_BODY })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 800 },
      children: [new TextRun({ text: `审查日期：${d.reviewDate}`, size: 24, color: '606060', font: FONT_BODY })],
    }),
    new Paragraph({ pageBreakBefore: true, children: [] }),
  );

  // 一、审查概况
  children.push(
    heading1('一、审查概况'),
    para('本报告依据《水土保持方案报告书内容及章节编排（B1）》和《生产建设项目水土保持技术标准》（GB50433-2018），对项目水土保持方案报告书（送审稿）进行了全面审查。'),
    para('审查分为4个专项：'),
    para('1. B1规范章节编排结构审查'),
    para('2. 逐章对照B1及GB50433标准审查'),
    para('3. 前后数据一致性审查'),
    para('4. 错别字及格式审查'),
  );

  // 二、各专项审查结论汇总
  children.push(heading1('二、各专项审查结论汇总'));

  const summaryRows = [
    new TableRow({ children: [hCell('专项审查', 2500), hCell('审查要素', 2000), hCell('审查结果', 2500), hCell('结论', 2026)] }),
  ];

  summaryRows.push(new TableRow({
    children: [
      dCell('1. B1规范章节编排结构审查', 2500),
      dCell(`${r1.totalItems}项结构要素`, 2000),
      dCell(`符合${r1.passCount}/基本符合${r1.warnCount}/不符合${r1.failCount}`, 2500),
      statusCell(r1.overallStatus === 'good' ? '符合' : r1.overallStatus === 'warn' ? '基本符合' : '不符合', 
                 r1.overallStatus === 'good' ? '符合' : r1.overallStatus === 'warn' ? '基本符合' : '不符合', 2026),
    ],
  }));

  summaryRows.push(new TableRow({
    children: [
      dCell('2. 逐章对照B1及GB50433标准审查', 2500),
      dCell('8章逐项审查', 2000),
      dCell(`${r2.chapters.filter(c => c.status === 'good').length}章符合/${r2.chapters.filter(c => c.status === 'warn').length}章基本符合`, 2500),
      statusCell(r2.overallStatus === 'good' ? '符合' : r2.overallStatus === 'warn' ? '基本符合' : '不符合',
                 r2.overallStatus === 'good' ? '符合' : r2.overallStatus === 'warn' ? '基本符合' : '不符合', 2026),
    ],
  }));

  summaryRows.push(new TableRow({
    children: [
      dCell('3. 前后数据一致性审查', 2500),
      dCell(`${r3.totalItems}项关键数据`, 2000),
      dCell(`一致${r3.consistentCount}/不一致${r3.inconsistentCount}`, 2500),
      statusCell(r3.overallStatus === 'good' ? '符合' : r3.overallStatus === 'warn' ? '基本符合' : '不符合',
                 r3.overallStatus === 'good' ? '符合' : r3.overallStatus === 'warn' ? '基本符合' : '不符合', 2026),
    ],
  }));

  summaryRows.push(new TableRow({
    children: [
      dCell('4. 错别字及格式审查', 2500),
      dCell(`${r4.totalIssues}处问题`, 2000),
      dCell(`文字错误${r4.textErrors}/格式问题${r4.formatIssues}`, 2500),
      statusCell(r4.overallStatus === 'good' ? '符合' : r4.overallStatus === 'warn' ? '基本符合' : '不符合',
                 r4.overallStatus === 'good' ? '符合' : r4.overallStatus === 'warn' ? '基本符合' : '不符合', 2026),
    ],
  }));

  children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows: summaryRows }));

  // 三、主要问题汇总
  children.push(heading1('三、主要问题汇总'));
  children.push(para('经4项专项审查发现的主要问题汇总如下：'));

  const allIssues = [
    ...(r1.issues || []).map(i => ({ ...i, source: '报告1-B1结构审查' })),
    ...(r2.issues || []).map(i => ({ ...i, source: '报告2-逐章标准审查' })),
    ...(r3.issues || []).map(i => ({ ...i, source: '报告3-数据一致性审查', location: i.dataItem || i.location })),
    ...(r4.typoIssues || []).map(i => ({ ...i, source: '报告4-错别字审查', problem: `${i.type}：${i.error}` })),
    ...(r4.formatIssuesList || []).map(i => ({ ...i, source: '报告4-格式审查', problem: i.problem })),
  ];

  if (allIssues.length > 0) {
    const issueRows = [
      new TableRow({ children: [hCell('序号', 400), hCell('来源', 1800), hCell('位置/数据项', 2000), hCell('问题描述', 2826), hCell('修改建议', 2000)] }),
    ];

    allIssues.forEach((issue, idx) => {
      issueRows.push(new TableRow({
        children: [
          dCell(String(idx + 1), 400, AlignmentType.CENTER, true),
          dCell(issue.source, 1800),
          dCell(issue.location, 2000),
          dCell(issue.problem, 2826),
          dCell(issue.suggestion, 2000),
        ],
      }));
    });

    children.push(new Table({ width: { size: 9026, type: WidthType.DXA }, rows: issueRows }));
  } else {
    children.push(para('未发现重大问题。'));
  }

  // 四、分项审查摘要
  children.push(heading1('四、分项审查摘要'));

  // 报告1摘要
  children.push(heading2('4.1 B1规范章节编排结构审查'));
  children.push(para(r1.conclusion));
  if (r1.issues && r1.issues.length > 0) {
    children.push(para('主要问题：'));
    r1.issues.forEach((issue, idx) => {
      children.push(para(`${idx + 1}. ${issue.location}：${issue.problem}`));
    });
  }

  // 报告2摘要
  children.push(heading2('4.2 逐章对照B1及GB50433标准审查'));
  children.push(para(r2.conclusion));
  if (r2.issues && r2.issues.length > 0) {
    children.push(para('主要问题：'));
    r2.issues.slice(0, 5).forEach((issue, idx) => {
      children.push(para(`${idx + 1}. ${issue.location}：${issue.problem}`));
    });
  }

  // 报告3摘要
  children.push(heading2('4.3 前后数据一致性审查'));
  children.push(para(r3.conclusion));
  if (r3.issues && r3.issues.length > 0) {
    children.push(para('数据不一致问题：'));
    r3.issues.forEach((issue, idx) => {
      children.push(para(`${idx + 1}. ${issue.dataItem}：${issue.problem}`));
    });
  }

  // 报告4摘要
  children.push(heading2('4.4 错别字及格式审查'));
  children.push(para(r4.conclusion));
  if (r4.typoIssues && r4.typoIssues.length > 0) {
    children.push(para(`发现${r4.typoIssues.length}处文字错误，${r4.formatIssuesList ? r4.formatIssuesList.length : 0}处格式问题。`));
  }

  // 五、综合审查结论
  children.push(heading1('五、综合审查结论'));
  children.push(para(d.conclusion));

  // 统计各专项结论
  const statusCounts = { good: 0, warn: 0, bad: 0 };
  [r1.overallStatus, r2.overallStatus, r3.overallStatus, r4.overallStatus].forEach(s => {
    statusCounts[s] = (statusCounts[s] || 0) + 1;
  });

  let finalStatusText = '';
  let finalStatusType = 'good';

  if (statusCounts.bad > 0) {
    finalStatusText = '不符合规范要求，需重大修改后重新报审。';
    finalStatusType = 'bad';
  } else if (statusCounts.warn > 0) {
    finalStatusText = '基本符合规范要求，在按照上述修改意见修改完善后，可作为正式报批件提交审批。';
    finalStatusType = 'warn';
  } else {
    finalStatusText = '符合规范要求，可作为报批件提交审批。';
    finalStatusType = 'good';
  }

  children.push(noticePara(`综合审查结论：${finalStatusText}`, finalStatusType));

  // 附件清单
  children.push(heading1('附件：专项审查报告清单'));
  children.push(para('本综合审查报告包含以下专项审查报告：'));
  children.push(para('附件1：审查报告1-B1规范章节编排结构审查.docx'));
  children.push(para('附件2：审查报告2-逐章对照B1及GB50433标准审查.docx'));
  children.push(para('附件3：审查报告3-前后数据一致性审查.docx'));
  children.push(para('附件4：审查报告4-错别字及格式审查.docx'));

  return new Document({
    creator: 'Water Conservation Review Skill',
    title: '水土保持方案报告书综合审查报告',
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '水土保持方案报告书综合审查报告', size: 18, color: '808080', font: FONT_BODY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '第 ', size: 18, font: FONT_BODY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT_BODY }), new TextRun({ text: ' 页', size: 18, font: FONT_BODY })] })] }) },
      children,
    }],
  });
}

// ============================================================
// 主函数
// ============================================================
async function main() {
  const args = process.argv.slice(2);
  let outputDir = './';
  let dataFile = null;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--output-dir' && args[i + 1]) outputDir = args[++i];
    if (args[i] === '--data' && args[i + 1]) dataFile = args[++i];
  }

  // 确保输出目录存在
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  // 加载审查数据
  let reviewData;
  if (dataFile && fs.existsSync(dataFile)) {
    reviewData = JSON.parse(fs.readFileSync(dataFile, 'utf-8'));
  } else {
    console.error('错误：请提供审查数据文件 (--data <JSON文件>)');
    console.error('或使用 auto_review.js 进行完整自动化审查');
    process.exit(1);
  }

  console.log('正在生成5份审查报告（1份总报告 + 4份专项报告）...');

  // 生成5份报告（报告0为总报告，报告1-4为专项报告）
  const reports = [
    { name: '审查报告-综合审查总报告.docx', builder: buildReport0 },
    { name: '审查报告1-B1规范章节编排结构审查.docx', builder: buildReport1 },
    { name: '审查报告2-逐章对照B1及GB50433标准审查.docx', builder: buildReport2 },
    { name: '审查报告3-前后数据一致性审查.docx', builder: buildReport3 },
    { name: '审查报告4-错别字及格式审查.docx', builder: buildReport4 },
  ];

  for (const report of reports) {
    const doc = report.builder(reviewData);
    const buffer = await Packer.toBuffer(doc);
    const outputPath = path.join(outputDir, report.name);
    fs.writeFileSync(outputPath, buffer);
    console.log(`✓ ${report.name}`);
  }

  console.log(`\n全部报告已生成到: ${outputDir}`);
}

main().catch((err) => {
  console.error('生成失败：', err);
  process.exit(1);
});
