# Feishu Send Image Message

## Overview

Upload a local image file to Feishu and send it into the active Feishu conversation as an image message.

## Use this skill when

- a user wants to send a local image into Feishu
- a user wants to upload an existing image file into the current chat
- a local image must be delivered as a Feishu image message

## Requirements

- `curl`
- `jq`
- Feishu app credentials in `~/.openclaw/openclaw.json`
- Feishu permission: `im:resource`

## Flow

1. Read `appId` and `appSecret` from OpenClaw Feishu config
2. Get `tenant_access_token`
3. Upload the image to Feishu and receive `image_key`
4. Send the image message to the current chat

## Notes

- The upload endpoint requires `image_type=message`
- The message payload must use `msg_type=image`
- The `content` field must be a JSON string containing `image_key`
- Keep the image file available until the upload completes

## Safety

- Only upload files that the user explicitly asked to send
- Do not modify the image contents unless the user requested editing
- If the file path is ambiguous, confirm the exact local file before uploading
