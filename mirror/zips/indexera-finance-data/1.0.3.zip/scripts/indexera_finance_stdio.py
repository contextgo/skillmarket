#!/usr/bin/env python3

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

TOKEN_FILE = Path(__file__).resolve().parents[1] / '.token.local.env'
DEFAULT_PROTOCOL_VERSION = '2025-03-26'
DEFAULT_CLIENT_NAME = 'indexera-finance-cli'
DEFAULT_CLIENT_VERSION = '0.1.0'


class McpClientError(Exception):
    def __init__(self, code, message, details=None):
        super(McpClientError, self).__init__(message)
        self.code = code
        self.message = message
        self.details = details


def parse_request(argv):
    # type: (List[str]) -> Dict[str, Any]
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument('--input-json')
    parser.add_argument('--input-file')
    args = parser.parse_args(argv)

    if args.input_json and args.input_file:
        raise McpClientError('INVALID_REQUEST', 'use only one of --input-json or --input-file')

    if args.input_json:
        raw = args.input_json
    elif args.input_file:
        raw = Path(args.input_file).read_text(encoding='utf-8')
    else:
        raw = sys.stdin.read()

    raw = raw.strip()
    if not raw:
        raise McpClientError('INVALID_REQUEST', 'empty request body')

    try:
        request = json.loads(raw)
    except ValueError as exc:
        raise McpClientError('INVALID_JSON', 'invalid JSON: {0}'.format(exc))

    if not isinstance(request, dict):
        raise McpClientError('INVALID_REQUEST', 'request must be a JSON object')
    return request


def load_secret_env():
    # type: () -> Dict[str, str]
    if not TOKEN_FILE.exists():
        raise McpClientError('TOKEN_FILE_MISSING', 'missing token file: {0}'.format(TOKEN_FILE))
    env = {}  # type: Dict[str, str]
    for raw in TOKEN_FILE.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        env[key] = value
    required = ['INDEXERA_FINANCE_MCP_ENDPOINT', 'INDEXERA_FINANCE_TOKEN']
    missing = [key for key in required if not env.get(key)]
    if missing:
        raise McpClientError('TOKEN_FILE_INVALID', 'missing required keys: {0}'.format(', '.join(missing)))
    return env


def build_tool_call_request(request):
    # type: (Dict[str, Any]) -> Tuple[str, Dict[str, Any]]
    action = request.get('action')
    if not action or not isinstance(action, str):
        raise McpClientError('INVALID_REQUEST', 'missing action')

    if action == 'resolve_instrument':
        query = request.get('query')
        if not query:
            raise McpClientError('INVALID_REQUEST', 'resolve_instrument requires query')
        return 'resolve_instrument', {'query': query}

    if action == 'search_table':
        query = request.get('query')
        question = request.get('question')
        limit = request.get('limit')
        tool_args = {}  # type: Dict[str, Any]
        if query:
            tool_args['query'] = query
        if question:
            tool_args['question'] = question
        if limit is not None:
            tool_args['limit'] = limit
        if not tool_args:
            raise McpClientError('INVALID_REQUEST', 'search_table requires query or question')
        return 'search_table', tool_args

    if action == 'query_data':
        required = ['schema_name', 'table_name', 'select']
        missing = [name for name in required if request.get(name) in (None, '')]
        if missing:
            raise McpClientError('INVALID_REQUEST', 'query_data missing required fields: {0}'.format(', '.join(missing)))
        tool_args = {
            'schema_name': request['schema_name'],
            'table_name': request['table_name'],
            'select': request['select'],
        }
        for optional in ['filters', 'order_by', 'sort', 'limit']:
            if optional in request and request[optional] is not None:
                tool_args[optional] = request[optional]
        return 'query_data', tool_args

    if action == 'tools_list':
        return 'tools_list', {}

    raise McpClientError('UNSUPPORTED_ACTION', 'unsupported action: {0}'.format(action))


def normalize_tool_result(result):
    # type: (Dict[str, Any]) -> Dict[str, Any]
    if 'structuredContent' in result and result['structuredContent'] is not None:
        return {'ok': True, 'data': result['structuredContent']}
    content = result.get('content') or []
    if len(content) == 1 and isinstance(content[0], dict) and content[0].get('type') == 'text':
        text = content[0].get('text', '')
        try:
            parsed = json.loads(text)
        except ValueError:
            parsed = text
        return {'ok': True, 'data': parsed}
    return {'ok': True, 'data': result}


def error_result(code, message, details=None):
    # type: (str, str, Optional[Any]) -> Dict[str, Any]
    payload = {'ok': False, 'error_code': code, 'message': message}
    if details is not None:
        payload['details'] = details
    return payload


class HttpResponse(object):
    def __init__(self, status_code, headers, body_text):
        # type: (int, Dict[str, str], str) -> None
        self.status_code = status_code
        self.headers = headers
        self.text = body_text

    def json(self):
        # type: () -> Dict[str, Any]
        return json.loads(self.text)


class IndexeraFinanceMcpClient(object):
    def __init__(self, endpoint, token, timeout=30):
        # type: (str, str, int) -> None
        self.endpoint = endpoint
        self.timeout = timeout
        self.headers = {
            'Authorization': 'Bearer {0}'.format(token),
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/event-stream',
        }
        self.session_id = None  # type: Optional[str]
        self.request_id = 1

    def ensure_initialized(self):
        # type: () -> None
        if self.session_id:
            return
        payload = {
            'jsonrpc': '2.0',
            'id': self.next_id(),
            'method': 'initialize',
            'params': {
                'protocolVersion': DEFAULT_PROTOCOL_VERSION,
                'capabilities': {},
                'clientInfo': {'name': DEFAULT_CLIENT_NAME, 'version': DEFAULT_CLIENT_VERSION},
            },
        }
        response = self.post(payload)
        self.session_id = response.headers.get('Mcp-Session-Id')
        if not self.session_id:
            raise McpClientError('MCP_INIT_FAILED', 'missing Mcp-Session-Id in initialize response')
        self.headers['Mcp-Session-Id'] = self.session_id
        self.post({'jsonrpc': '2.0', 'method': 'notifications/initialized'})

    def call_tool(self, tool_name, arguments):
        # type: (str, Dict[str, Any]) -> Dict[str, Any]
        self.ensure_initialized()
        if tool_name == 'tools_list':
            payload = {
                'jsonrpc': '2.0',
                'id': self.next_id(),
                'method': 'tools/list',
                'params': {},
            }
        else:
            payload = {
                'jsonrpc': '2.0',
                'id': self.next_id(),
                'method': 'tools/call',
                'params': {'name': tool_name, 'arguments': arguments},
            }
        response = self.post(payload)
        body = response.json()
        if 'error' in body:
            error = body['error']
            raise McpClientError('MCP_TOOL_ERROR', error.get('message', 'tool call failed'), error)
        result = body.get('result')
        if not isinstance(result, dict):
            raise McpClientError('MCP_PROTOCOL_ERROR', 'missing result object in tool response', body)
        return result

    def post(self, payload):
        # type: (Dict[str, Any]) -> HttpResponse
        body = json.dumps(payload).encode('utf-8')
        request = Request(self.endpoint, data=body)
        for key, value in self.headers.items():
            request.add_header(key, value)
        try:
            response = urlopen(request, timeout=self.timeout)
            raw = response.read()
            text = raw.decode('utf-8', errors='replace')
            return HttpResponse(response.getcode(), dict(response.info().items()), text)
        except HTTPError as exc:
            text = exc.read().decode('utf-8', errors='replace')
            raise McpClientError('MCP_HTTP_ERROR', 'HTTP {0}'.format(exc.code), text[:2000])
        except URLError as exc:
            raise McpClientError('MCP_HTTP_ERROR', str(exc))
        except Exception as exc:
            raise McpClientError('MCP_HTTP_ERROR', str(exc))

    def next_id(self):
        # type: () -> int
        current = self.request_id
        self.request_id += 1
        return current


def dispatch(request):
    # type: (Dict[str, Any]) -> Dict[str, Any]
    env = load_secret_env()
    tool_name, tool_args = build_tool_call_request(request)
    client = IndexeraFinanceMcpClient(
        endpoint=env['INDEXERA_FINANCE_MCP_ENDPOINT'],
        token=env['INDEXERA_FINANCE_TOKEN'],
    )
    result = client.call_tool(tool_name, tool_args)
    return normalize_tool_result(result)


def main(argv=None):
    # type: (Optional[List[str]]) -> int
    try:
        request = parse_request(argv if argv is not None else sys.argv[1:])
        result = dispatch(request)
    except McpClientError as exc:
        result = error_result(exc.code, exc.message, exc.details)
    except Exception as exc:
        result = error_result('UNEXPECTED_ERROR', str(exc))
    json.dump(result, sys.stdout, ensure_ascii=False)
    sys.stdout.write('\n')
    return 0 if result.get('ok') else 1


if __name__ == '__main__':
    raise SystemExit(main())
