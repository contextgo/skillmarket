---
name: indexera_finance_data
description: Use the Indexera MCP service to answer finance data questions through resolve_instrument, search_table, and query_data.
version: 0.1.0
---

# Indexera Finance Data

Use this skill when the user asks for **financial data lookup**, especially around securities, funds, indices,行情,财务指标、估值、持仓、分红、公告期数据、时间序列查询。

## Goal

Turn a natural-language finance question into a safe MCP workflow:

1. normalize the instrument with `resolve_instrument`
2. discover the right dataset with `search_table`
3. fetch only the necessary fields with `query_data`
4. answer in plain Chinese with the selected instrument, table, fields, and scope made explicit

## Bootstrap

Before the first real MCP request, check whether the local token file exists.
Resolve paths relative to the current skill root, not a hard-coded install location:

- `.token.local.env`

If the file does not exist, the agent must proactively ask the user to provide a token, then write it locally in this format:

- `INDEXERA_FINANCE_MCP_BASE_URL=https://mcp.indexera.cn`
- `INDEXERA_FINANCE_MCP_ENDPOINT=https://mcp.indexera.cn/mcp`
- `INDEXERA_FINANCE_TOKEN`

Every MCP request must send `Authorization: Bearer <token>` from that file.

Treat that file as a local secret. Do not print the full token or commit the env file.

## Hard Rules

### 1. Always resolve the instrument first

Even if the user provides something that *looks* like an exact code, still call `resolve_instrument` first.

Reason: user-entered code formats vary; the skill must normalize to the system `canonical_code` before table search and data query.

### 2. Prefer minimal, verifiable queries

- query only the columns needed to answer the question
- use the narrowest viable date/time window
- set a reasonable `limit`
- do not fetch wide tables unless needed

### 3. Let metadata drive decisions

`search_table` is now a **pure metadata search** over rebuilt `metadata_table.search_text`.
That search text is generated inside MCP from table fields + column names + column comments + `name_alias`.
Do not assume any runtime synonym expansion happens at query time.

`search_table` returns table description, column matrix, and sample rows. Use those to decide:

- whether the table really matches the user question
- which columns are likely valid in `select`
- which fields look like instrument code / trade date / report date / metric columns

### 4. Explain assumptions

If the skill auto-picks one candidate instrument or one table among several possibilities, say so briefly in the final answer.

### 5. Prefer fixed CLI over generated Python

When integrating this skill into OpenClaw or another agent runtime, prefer the fixed stdin/stdout runner under the current skill root:

- `scripts/indexera_finance_stdio.py`

Do **not** generate one-off Python code for each MCP request if the fixed runner is available.

Primary contract:

- input: one JSON object from stdin
- output: one JSON object to stdout
- success shape: `{\"ok\": true, \"data\": ...}`
- failure shape: `{\"ok\": false, \"error_code\": ..., \"message\": ...}`

## Available MCP Tools

### `resolve_instrument`

Input:

- `query` — name, alias, code fragment, ticker-like text, etc.

Output:

- `instruments[]`
  - `instrument_type`
  - `display_name`
  - `canonical_code`
  - `exchange`
  - `market`

Use it to normalize every security/fund/index/entity reference before any downstream step.

### `search_table`

Input:

- `question` or `query`
- optional `limit`

Output:

- `tables[]`
  - `schema_name`
  - `table_name`
  - `table_title`
  - `table_desc`
  - `columns`
  - `sample_rows`

Use it to find the best table for the requested metric, frequency, and time range.

### `query_data`

Input:

- `schema_name`
- `table_name`
- `select` (required)
- `filters` (optional)
- `order_by` (optional)
- `limit` (optional)

Use it only after the table has been selected from metadata evidence.

## Execution Workflow

### Step 1: parse the user question

Extract five things from the request:

1. **instrument hint**
   - e.g. 贵州茅台, 600519, 沪深300, 纳指ETF
2. **data theme**
   - 行情 / 估值 / 财报 / 指数 / 基金持仓 / 分红 / 复权 / K线 / 资金流
3. **metrics**
   - 收盘价 / 成交额 / PE / 营收 / 净利润 / 仓位 / 持仓市值
4. **time scope**
   - 最新 / 最近N天 / 某个季度 / 某个年份 / 时间序列
5. **result shape**
   - 单点值 / 时间序列 / 排名 / 对比

### Step 2: resolve the instrument

Always call `resolve_instrument`.

Selection preference when multiple candidates exist:

1. exact code match after normalization
2. exact display-name match
3. exchange/market consistent with user wording
4. most obvious mainstream listing / benchmark candidate

If ambiguity remains material, ask the user; otherwise continue with the best candidate and say which one was chosen.

### Step 3: search the table

Build a compact search phrase combining:

- normalized instrument or instrument type
- data theme
- requested metrics
- time/frequency cues

Good examples:

- `A股 日线 收盘价 成交额`
- `股票 财务 营收 净利润 季度`
- `基金 持仓 季报`
- `指数 成分 权重`

Run `search_table` with a modest limit first.

### Step 4: rank table candidates

Prefer tables whose metadata best matches all of the following:

1. title/description clearly matches the requested domain
2. columns include the expected instrument key and requested metrics
3. sample rows show the right grain (daily / quarterly / annual / holdings / constituent rows)
4. schema is appropriate (typically `tushare` for current phase)
5. access looks usable for the current use case

### Step 5: construct the query

When building `query_data`:

- include only essential `select` columns
- prefer canonical instrument code as the main identifier filter
- add date/report filters when the question implies a period
- sort newest-first for “latest” queries
- use a small `limit` unless the user explicitly asks for a long series

Common `select` shape:

- identifier column
- date/report column
- requested metric columns

Common `order_by` shape:

- report/trade date descending

### Step 6: answer the user

Return:

- what instrument was resolved
- which table was used
- the result itself
- any limitation or assumption

For short answers, keep the explanation tight.
For analytical questions, summarize the data before listing rows.

## Query Construction Heuristics

### Latest single-value request

Example: “茅台最新收盘价”

- resolve instrument
- search daily price table
- query `trade_date`, code, close
- sort by trade_date desc
- `limit=1`

### Time series request

Example: “宁德时代近20个交易日收盘价和成交额”

- resolve instrument
- search daily market table
- query date + requested metrics
- filter instrument code
- sort by trade_date desc or asc as needed
- `limit=20`

### Financial statement request

Example: “比亚迪2024年净利润和营收”

- resolve instrument
- search income/profit statement tables
- prefer report-period fields in sample rows
- query report date / end date + revenue + net profit
- filter company code and year

### Holdings / constituent request

Example: “某基金最新前十大持仓”

- resolve instrument
- search holdings/portfolio table
- query holding name, code, weight/value, report date
- sort by report date desc and weight desc if allowed

## Failure Handling

### If `resolve_instrument` returns no candidates

- tell the user the instrument could not be resolved
- ask for a clearer name, market, or ticker format

### If `search_table` returns multiple plausible tables

Pick the one whose metadata best matches the requested metric and grain.
If still ambiguous, briefly mention the chosen table and why.

### If `query_data` fails validation

Retry once with a more conservative request:

- reduce `select`
- remove speculative filters
- remove speculative sorts
- keep only obvious identifier/date constraints

Do not loop repeatedly.

### If the data is unavailable

Say whether the failure came from:

- unresolved instrument
- no suitable table found
- query validation mismatch
- empty data returned for the requested period

## Response Style

- Default to Chinese.
- Be factual and concise.
- Do not expose secrets.
- When useful, cite the resolved `canonical_code`, table name, and date scope.

## Quick Examples

For CLI usage and OpenClaw integration examples, also see:

- `references/cli.md`

For a larger scenario library, also see:

- `references/examples.md`

### Example 1
User: `贵州茅台最近5个交易日收盘价`

High-level tool plan:
1. `resolve_instrument(query="贵州茅台")`
2. `search_table(query="A股 日线 收盘价")`
3. `query_data(...)` using canonical code, `trade_date`, `close`, `limit=5`

### Example 2
User: `600519 近四个季度营收和净利润`

High-level tool plan:
1. `resolve_instrument(query="600519")`
2. `search_table(query="股票 财务 营收 净利润 季度")`
3. `query_data(...)` using canonical code and quarterly/report columns

### Example 3
User: `沪深300有哪些可查询表`

High-level tool plan:
1. `resolve_instrument(query="沪深300")`
2. `search_table(query="指数 成分 权重 行情")`
3. summarize matching tables without forcing a data query
