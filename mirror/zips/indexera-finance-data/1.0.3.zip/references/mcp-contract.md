# Indexera Finance MCP Contract Notes

This reference captures the current MCP contract for the Indexera MCP service.

## Actual tool names

- `resolve_instrument`
- `search_table`
- `query_data`

Note: product wording may mention `resolve_instruments`, but the current code exposes **`resolve_instrument`**.

## `resolve_instrument`

### Request

```json
{
  "query": "贵州茅台"
}
```

### Response shape

```json
{
  "instruments": [
    {
      "instrument_type": "stock",
      "display_name": "贵州茅台",
      "canonical_code": "600519.SH",
      "exchange": "SSE",
      "market": "CN"
    }
  ]
}
```

## `search_table`

Current matching behavior:

- backend only searches `meta.metadata_table.search_text`
- `search_text` is rebuilt in MCP from table metadata + column metadata + `metadata_column.name_alias`
- no runtime synonym expansion is expected on the query path

### Request

```json
{
  "query": "A股 日线 收盘价 成交额",
  "limit": 5
}
```

### Response shape

```json
{
  "tables": [
    {
      "schema_name": "tushare",
      "table_name": "daily",
      "table_title": "日线行情",
      "table_desc": "按交易日的证券行情数据",
      "columns": {
        "header": ["name", "comment", "data_type"],
        "rows": [
          ["ts_code", "TS代码", "text"],
          ["trade_date", "交易日期", "date"],
          ["close", "收盘价", "numeric"]
        ]
      },
      "sample_rows": [
        {
          "ts_code": "600519.SH",
          "trade_date": "20260418",
          "close": 1234.56
        }
      ]
    }
  ]
}
```

## `query_data`

### Request skeleton

```json
{
  "schema_name": "tushare",
  "table_name": "daily",
  "select": ["ts_code", "trade_date", "close"],
  "filters": [
    {"column": "ts_code", "op": "=", "value": "600519.SH"}
  ],
  "order_by": [
    {"column": "trade_date", "direction": "desc"}
  ],
  "limit": 5
}
```

### Supported filter operators

- `=`
- `!=`
- `<`
- `>`
- `<=`
- `>=`
- `in`
- `between`
- `like`

### Important constraints

- `select` is mandatory
- `schema_name` and `table_name` are mandatory
- all selected columns must exist in metadata
- filter columns must be both valid columns and listed in table `filter_fields`
- sort columns must be both valid columns and listed in table `sort_fields`
- query limit is capped by the backend

## Skill strategy implications

1. Always normalize the user instrument via `resolve_instrument`.
2. Use `search_table` to discover the table instead of hard-coding names whenever possible.
3. Build the narrowest possible `query_data` payload.
4. If validation fails, retry once with fewer columns and fewer speculative constraints.
