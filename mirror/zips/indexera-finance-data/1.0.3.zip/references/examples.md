# Indexera Finance Example Library

This file provides realistic query patterns for the `indexera_finance_data` skill.

## Usage pattern

Note: `search_table` now depends on rebuilt metadata aliases/search text inside MCP. Use compact domain phrases; do not rely on the client skill layer to inject runtime synonyms.

Every example follows the same sequence:

1. `resolve_instrument`
2. `search_table`
3. `query_data` (only if the user is asking for actual data)

Even code-looking inputs still go through `resolve_instrument` first.

---

## 1. A股日线行情

### User question

`贵州茅台最近10个交易日收盘价、成交额、换手率`

### Tool plan

1. `resolve_instrument(query="贵州茅台")`
2. `search_table(query="A股 日线 收盘价 成交额 换手率")`
3. `query_data(...)`

### Likely query shape

```json
{
  "schema_name": "tushare",
  "table_name": "daily",
  "select": ["ts_code", "trade_date", "close", "amount", "turnover_rate"],
  "filters": [
    {"column": "ts_code", "op": "=", "value": "<canonical_code>"}
  ],
  "order_by": [
    {"column": "trade_date", "direction": "desc"}
  ],
  "limit": 10
}
```

---

## 2. 最新单点行情

### User question

`600519 最新收盘价`

### Tool plan

1. `resolve_instrument(query="600519")`
2. `search_table(query="A股 日线 收盘价 最新")`
3. `query_data(...)`

### Likely query shape

```json
{
  "schema_name": "tushare",
  "table_name": "daily",
  "select": ["ts_code", "trade_date", "close"],
  "filters": [
    {"column": "ts_code", "op": "=", "value": "<canonical_code>"}
  ],
  "order_by": [
    {"column": "trade_date", "direction": "desc"}
  ],
  "limit": 1
}
```

---

## 3. 财务报表：营收与净利润

### User question

`比亚迪 2024 年各季度营收和净利润`

### Tool plan

1. `resolve_instrument(query="比亚迪")`
2. `search_table(query="A股 财务 季度 营收 净利润")`
3. choose the statement table whose columns and sample rows show report-period grain
4. `query_data(...)`

### Likely query strategy

- include the company code column
- include report/end date
- include revenue and net profit fields
- sort newest report first
- limit to a small quarterly result set

---

## 4. 估值查询

### User question

`宁德时代最新 PE 和 PB`

### Tool plan

1. `resolve_instrument(query="宁德时代")`
2. `search_table(query="A股 估值 PE PB 最新")`
3. `query_data(...)`

### Selection notes

Prefer a table whose metadata/sample rows clearly contain valuation fields such as PE/PB and a date field.

---

## 5. 基金持仓

### User question

`易方达蓝筹精选最新前十大持仓`

### Tool plan

1. `resolve_instrument(query="易方达蓝筹精选")`
2. `search_table(query="基金 持仓 前十大 季报")`
3. choose the holdings table with security-name / security-code / weight / report-date style columns
4. `query_data(...)`

### Likely result fields

- fund code
- report date
- holding security name
- holding security code
- holding weight / market value

---

## 6. 指数成分或权重

### User question

`沪深300 最新成分股权重`

### Tool plan

1. `resolve_instrument(query="沪深300")`
2. `search_table(query="指数 成分 权重 最新")`
3. `query_data(...)`

### Selection notes

Prefer a table whose sample rows show constituent-level grain rather than index-level daily price rows.

---

## 7. 指数时间序列

### User question

`沪深300 最近一个月收盘点位`

### Tool plan

1. `resolve_instrument(query="沪深300")`
2. `search_table(query="指数 日线 收盘点位 最近一个月")`
3. `query_data(...)`

### Query notes

- select code/date/close-like fields only
- use descending date sort
- use a modest limit matching the requested horizon

---

## 8. 公告或分红类问题

### User question

`中国平安近三年的分红记录`

### Tool plan

1. `resolve_instrument(query="中国平安")`
2. `search_table(query="A股 分红 派息 股权登记日 除权除息")`
3. `query_data(...)`

### Selection notes

Prefer tables whose columns contain dividend event dates and payout-related metrics.

---

## 9. “有什么表可查”类问题

### User question

`中证红利相关有哪些表可以查？`

### Tool plan

1. `resolve_instrument(query="中证红利")`
2. `search_table(query="指数 成分 权重 行情 估值")`
3. summarize the most relevant tables
4. do **not** force `query_data` unless the user asks for actual values

---

## 10. Ambiguous input handling

### User question

`平安银行和中国平安最近表现`

### Tool plan

1. call `resolve_instrument` separately for each instrument hint
2. if multiple candidate matches remain, ask the user to confirm which resolved instruments to compare
3. only then search tables and query data

---

## Conservative retry pattern

If `query_data` fails because of validation mismatch:

1. keep the chosen table
2. shrink `select` to only identifier/date/requested core metric fields
3. drop speculative filters
4. drop speculative sort clauses
5. retry once

Do not retry repeatedly.
