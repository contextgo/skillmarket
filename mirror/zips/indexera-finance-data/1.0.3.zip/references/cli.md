# Indexera Finance CLI (stdin/stdout JSON)

This skill includes a fixed MCP runner for OpenClaw and other agent systems.

## Path

Resolve the runner relative to the current skill root:

- `scripts/indexera_finance_stdio.py`

If your runtime cannot accept wrapper files, call the Python runner directly.
Do not assume the skill is installed under a fixed absolute path.

## Request format

All requests are JSON objects.

### `resolve_instrument`

```json
{
  "action": "resolve_instrument",
  "query": "贵州茅台"
}
```

### `search_table`

```json
{
  "action": "search_table",
  "query": "A股 日线 收盘价",
  "limit": 5
}
```

### `query_data`

```json
{
  "action": "query_data",
  "schema_name": "tushare",
  "table_name": "daily",
  "select": ["ts_code", "trade_date", "close"],
  "filters": [
    {"column": "ts_code", "op": "=", "value": "600519.SH"}
  ],
  "order_by": [
    {"column": "trade_date", "direction": "desc"}
  ],
  "limit": 5
}
```

### `tools_list`

```json
{
  "action": "tools_list"
}
```

## Response format

Success:

```json
{
  "ok": true,
  "data": {...}
}
```

Failure:

```json
{
  "ok": false,
  "error_code": "MCP_TOOL_ERROR",
  "message": "Internal error",
  "details": {...}
}
```

## Preferred OpenClaw integration

### Best default

Use the fixed runner directly, not generated Python code.

Primary mode:

- send one JSON object to stdin
- read one JSON object from stdout

Linux/macOS example:

```bash
printf '%s' '{"action":"resolve_instrument","query":"贵州茅台"}' \
  | python3 ./scripts/indexera_finance_stdio.py
```

Alternative argument form:

```bash
python3 ./scripts/indexera_finance_stdio.py \
  --input-json '{"action":"resolve_instrument","query":"贵州茅台"}'
```

This is the preferred OpenClaw path because it avoids code generation and keeps the I/O contract stable.

## Windows usage

### PowerShell

PowerShell can call the Python runner directly.

Simple pipe:

```powershell
'{"action":"resolve_instrument","query":"贵州茅台"}' |
  python .\scripts\indexera_finance_stdio.py
```

Here-string for larger payloads:

```powershell
@'
{"action":"query_data","schema_name":"tushare","table_name":"daily","select":["ts_code","trade_date","close"],"limit":5}
'@ |
  python .\scripts\indexera_finance_stdio.py
```

### cmd.exe

For cmd, prefer one of these two patterns.

#### Preferred: `--input-file`

```cmd
python .\scripts\indexera_finance_stdio.py --input-file request.json
```

#### Acceptable: `--input-json`

```cmd
python .\scripts\indexera_finance_stdio.py --input-json "{\"action\":\"resolve_instrument\",\"query\":\"贵州茅台\"}"
```

#### Not recommended: raw `echo ... | python ...`

This may work for very small payloads, but escaping rules are brittle in cmd, especially with quotes and non-ASCII text.

## Operational notes

- The runner reads secrets from `.token.local.env`
- It initializes an MCP session automatically
- It sends `notifications/initialized`
- It then performs `tools/list` or `tools/call`
- stdout is always structured JSON
- exit code is `0` on success and `1` on structured failure
