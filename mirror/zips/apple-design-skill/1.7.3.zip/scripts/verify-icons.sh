#!/bin/bash
# verify-icons.sh — Audit every Remix Icon class in an HTML file against the real Remix Icon 4.2.0 CSS
#
# Usage:
#   bash verify-icons.sh path/to/index.html
#
# Exit code:
#   0 — all icons verified
#   1 — one or more icons do NOT exist (listed to stderr)
#
# Why this exists:
#   Remix Icon is inconsistent — many names have only `-line` variants, some common
#   semantic names (hiking, mountain, backpack, campfire) don't exist at all.
#   A missing icon renders as a tofu / blank square and silently ruins the design.
#   This script is the mechanical safety net: run it after writing HTML, before shipping.

set -e

HTML_FILE="${1:?Usage: $0 <html-file>}"
CSS_URL="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
CSS_CACHE="/tmp/remixicon-4.2.0.css"

if [ ! -f "$CSS_CACHE" ] || [ "$(find "$CSS_CACHE" -mmin +60 2>/dev/null)" ]; then
  echo "→ Fetching Remix Icon 4.2.0 CSS..."
  curl -sf "$CSS_URL" -o "$CSS_CACHE" || { echo "❌ Failed to fetch $CSS_URL"; exit 2; }
fi

USED=$(grep -oE 'ri-[a-z0-9-]+' "$HTML_FILE" | sort -u)
TOTAL=0
MISSING=0

echo ""
echo "=== Icon audit: $HTML_FILE ==="
for name in $USED; do
  TOTAL=$((TOTAL + 1))
  if grep -q "\.${name}:before" "$CSS_CACHE"; then
    echo "✅ $name"
  else
    echo "❌ $name  — DOES NOT EXIST" >&2
    MISSING=$((MISSING + 1))
  fi
done

echo ""
echo "Summary: $((TOTAL - MISSING))/$TOTAL verified"

if [ "$MISSING" -gt 0 ]; then
  echo ""
  echo "⚠️  $MISSING icon(s) will render as blank squares." >&2
  echo "   Replace each missing class with a verified semantic alternative," >&2
  echo "   or try the -line variant (line coverage is broader than fill)." >&2
  exit 1
fi

exit 0
