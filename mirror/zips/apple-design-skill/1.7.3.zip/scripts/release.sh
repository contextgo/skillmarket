#!/bin/bash
# release.sh — Proper release workflow for apple-design skill family
#
# Pipeline (per Dayvi's 2026-04 agreement):
#   1. rsync apple-design-local/  →  apple-design-skill/  (clean fork)
#   2. rewrite name: apple-design-local  →  apple-design  (market-name)
#   3. optionally auto-bump version (patch by default)
#   4. build zip  →  ~/.workbuddy/releases/apple-design/apple-design-v<version>-<sha8>.zip
#   5. generate .sha256 sidecar + append RELEASES.md
#   6. open -R Finder (cursor lands on the zip)
#
# Usage:
#   bash scripts/release.sh                   # auto-bump patch (1.7.1 → 1.7.2)
#   bash scripts/release.sh patch             # same as above
#   bash scripts/release.sh minor             # bump minor  (1.7.1 → 1.8.0)
#   bash scripts/release.sh major             # bump major  (1.7.1 → 2.0.0)
#   bash scripts/release.sh 1.9.0             # set explicit version
#   bash scripts/release.sh patch path.html   # also smoke-test a reference page
#
# The script modifies BOTH SKILL.md files:
#   - apple-design-local/SKILL.md: version bumped only
#   - apple-design-skill/SKILL.md: full content synced from local, then
#     frontmatter rewritten (name: apple-design, version bumped)

set -e

LOCAL_DIR="${HOME}/.workbuddy/skills/apple-design-local"
SKILL_DIR="${HOME}/.workbuddy/skills/apple-design-skill"
RELEASE_DIR="${HOME}/.workbuddy/releases/apple-design"
MARKET_NAME="apple-design"

if [ ! -d "$LOCAL_DIR" ]; then
  echo "❌ Source not found: $LOCAL_DIR" >&2
  exit 1
fi
if [ ! -d "$SKILL_DIR" ]; then
  echo "❌ Market fork not found: $SKILL_DIR" >&2
  echo "   Create it first: cp -r $LOCAL_DIR $SKILL_DIR" >&2
  exit 1
fi

# ---- 1. Determine next version ----
CURRENT_VERSION=$(grep -E "^version:" "${LOCAL_DIR}/SKILL.md" | head -1 | awk '{print $2}' | tr -d '"' | tr -d "'")
if [ -z "$CURRENT_VERSION" ]; then
  echo "❌ Could not read version from ${LOCAL_DIR}/SKILL.md" >&2
  exit 1
fi

BUMP_KIND="patch"
EXPLICIT_VERSION=""
REFERENCE_HTML=""

for arg in "$@"; do
  case "$arg" in
    patch|minor|major) BUMP_KIND="$arg" ;;
    [0-9]*.[0-9]*.[0-9]*) EXPLICIT_VERSION="$arg" ;;
    *.html|*.htm) REFERENCE_HTML="$arg" ;;
  esac
done

if [ -n "$EXPLICIT_VERSION" ]; then
  NEW_VERSION="$EXPLICIT_VERSION"
else
  IFS='.' read -r MAJ MIN PAT <<< "$CURRENT_VERSION"
  case "$BUMP_KIND" in
    patch) PAT=$((PAT + 1)) ;;
    minor) MIN=$((MIN + 1)); PAT=0 ;;
    major) MAJ=$((MAJ + 1)); MIN=0; PAT=0 ;;
  esac
  NEW_VERSION="${MAJ}.${MIN}.${PAT}"
fi

echo "→ Version: ${CURRENT_VERSION}  →  ${NEW_VERSION} (${BUMP_KIND})"

# ---- 2. Preflight on LOCAL source ----
echo ""
echo "=== Preflight (on apple-design-local) ==="
FAIL=0

for field in name version allowed-tools description; do
  grep -qE "^${field}:" "${LOCAL_DIR}/SKILL.md" \
    && echo "✅ frontmatter: $field" \
    || { echo "❌ missing frontmatter: $field" >&2; FAIL=1; }
done

grep -E "^allowed-tools:" "${LOCAL_DIR}/SKILL.md" | grep -q "AskUserQuestion" \
  && echo "✅ AskUserQuestion in allowed-tools" \
  || { echo "❌ allowed-tools missing AskUserQuestion" >&2; FAIL=1; }

HARDCODED=$(grep -nE "(/Users/[a-z]+/|C:\\\\[A-Za-z])" "${LOCAL_DIR}/SKILL.md" "${LOCAL_DIR}/scripts/"*.sh 2>/dev/null || true)
if [ -n "$HARDCODED" ]; then
  echo "❌ hardcoded absolute paths detected:" >&2
  echo "$HARDCODED" >&2
  FAIL=1
else
  echo "✅ no hardcoded absolute paths"
fi

for sh in "${LOCAL_DIR}/scripts/"*.sh; do
  [ -f "$sh" ] || continue
  [ -x "$sh" ] || chmod +x "$sh"
done
echo "✅ scripts executable"

if [ -n "$REFERENCE_HTML" ] && [ -f "$REFERENCE_HTML" ]; then
  bash "${LOCAL_DIR}/scripts/verify-icons.sh" "$REFERENCE_HTML" > /dev/null 2>&1 \
    && echo "✅ reference HTML icons verified" \
    || { echo "❌ reference HTML has missing icons" >&2; FAIL=1; }
fi

# Extension whitelist — skillhub rejects files without recognised extensions (e.g. bare "LICENSE")
BAD_FILES=$(find "$LOCAL_DIR" -type f \
  -not -path "*/.git/*" \
  -not -path "*/node_modules/*" \
  -not -name ".DS_Store" \
  -not -name ".gitignore" \
  ! -name "*.md" \
  ! -name "*.sh" \
  ! -name "*.txt" \
  ! -name "*.json" \
  ! -name "*.yml" \
  ! -name "*.yaml" \
  ! -name "*.html" \
  ! -name "*.css" \
  ! -name "*.js" \
  ! -name "*.svg" \
  ! -name "*.png" \
  ! -name "*.jpg" \
  ! -name "*.jpeg" \
  ! -name "*.webp" \
  2>/dev/null)
if [ -n "$BAD_FILES" ]; then
  echo "❌ Files without recognised extensions — skillhub will reject:" >&2
  echo "$BAD_FILES" >&2
  echo "   Rename them (e.g. LICENSE → LICENSE.md) before release." >&2
  FAIL=1
else
  echo "✅ all files have recognised extensions"
fi

[ "$FAIL" -eq 0 ] || { echo "❌ preflight failed — aborting" >&2; exit 1; }

# ---- 3. Bump version in apple-design-local/SKILL.md ----
echo ""
echo "=== Bumping version in apple-design-local ==="
sed -i '' "s/^version: ${CURRENT_VERSION}/version: ${NEW_VERSION}/" "${LOCAL_DIR}/SKILL.md"
echo "✅ apple-design-local/SKILL.md now at ${NEW_VERSION}"

# ---- 4. rsync local → skill, skip local-only files ----
echo ""
echo "=== Syncing apple-design-local → apple-design-skill ==="
rsync -a --delete \
  --exclude '.git/' \
  --exclude 'node_modules/' \
  --exclude '.DS_Store' \
  --exclude '.gitignore' \
  "${LOCAL_DIR}/" "${SKILL_DIR}/"
echo "✅ rsync done"

# ---- 5. Rewrite name + version in skill (market) frontmatter ----
sed -i '' "s/^name: apple-design-local/name: ${MARKET_NAME}/" "${SKILL_DIR}/SKILL.md"
# version was already set above via sync, but be explicit in case of drift
sed -i '' "s/^version: ${CURRENT_VERSION}/version: ${NEW_VERSION}/" "${SKILL_DIR}/SKILL.md"

NEW_NAME_CHECK=$(grep -E "^name:" "${SKILL_DIR}/SKILL.md" | head -1 | awk '{print $2}')
NEW_VER_CHECK=$(grep -E "^version:" "${SKILL_DIR}/SKILL.md" | head -1 | awk '{print $2}')
echo "✅ market fork: name=${NEW_NAME_CHECK}  version=${NEW_VER_CHECK}"

# ---- 6. Build zip ----
mkdir -p "$RELEASE_DIR"

# Short hash of SKILL.md for traceability
CONTENT_SHA=$(shasum -a 256 "${SKILL_DIR}/SKILL.md" | cut -c1-8)
ZIP_NAME="${MARKET_NAME}-v${NEW_VERSION}-${CONTENT_SHA}.zip"
ZIP_PATH="${RELEASE_DIR}/${ZIP_NAME}"

echo ""
echo "=== Building ${ZIP_NAME} ==="
rm -f "$ZIP_PATH"

PARENT="$(dirname "$SKILL_DIR")"
BASENAME="$(basename "$SKILL_DIR")"

# zip with the market name as the archive root (rename on the fly)
TMP_STAGE=$(mktemp -d)
trap "rm -rf $TMP_STAGE" EXIT
cp -R "$SKILL_DIR" "${TMP_STAGE}/${MARKET_NAME}"

(cd "$TMP_STAGE" && zip -rq "$ZIP_PATH" "$MARKET_NAME" \
    -x "${MARKET_NAME}/.git/*" \
       "${MARKET_NAME}/node_modules/*" \
       "${MARKET_NAME}/.DS_Store" \
       "*/.DS_Store" \
       "${MARKET_NAME}/.gitignore")

SIZE=$(ls -lh "$ZIP_PATH" | awk '{print $5}')
ZIP_SHA=$(shasum -a 256 "$ZIP_PATH" | awk '{print $1}')
echo "✅ Built: ${ZIP_PATH} (${SIZE})"
echo "✅ SHA256: ${ZIP_SHA}"

# ---- 7. Write .sha256 sidecar + RELEASES.md ----
shasum -a 256 "$ZIP_PATH" > "${ZIP_PATH}.sha256"

RELEASES_MD="${RELEASE_DIR}/RELEASES.md"
if [ ! -f "$RELEASES_MD" ]; then
  cat > "$RELEASES_MD" <<EOF
# ${MARKET_NAME} Releases

按时间倒序。最新版本在顶部。每条记录对应一次 \`scripts/release.sh\` 打包。

---

EOF
fi

if ! grep -q "^## v${NEW_VERSION} " "$RELEASES_MD"; then
  TMP=$(mktemp)
  {
    head -5 "$RELEASES_MD"
    echo ""
    echo "## v${NEW_VERSION} — $(date +%Y-%m-%d)"
    echo ""
    echo "**Artifact**: \`${ZIP_NAME}\` (${SIZE})"
    echo "**SHA256**: \`${ZIP_SHA}\`"
    echo "**Bump**: ${CURRENT_VERSION} → ${NEW_VERSION} (${BUMP_KIND})"
    echo ""
    echo "### Changes"
    echo "- (fill in manually)"
    echo ""
    echo "---"
    echo ""
    tail -n +6 "$RELEASES_MD"
  } > "$TMP"
  mv "$TMP" "$RELEASES_MD"
  echo "✅ RELEASES.md entry appended"
fi

# ---- 8. Reveal in Finder ----
if command -v open > /dev/null 2>&1; then
  open -R "$ZIP_PATH"
  echo "✅ Finder revealed: ${ZIP_PATH}"
fi

echo ""
echo "🎉 Release ready"
echo "   Upload this file to skillhub:"
echo "   ${ZIP_PATH}"
