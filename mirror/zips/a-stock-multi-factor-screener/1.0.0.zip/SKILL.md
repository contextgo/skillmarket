---
name: a-stock-multi-factor-screener
version: 1.0.0
description: A股多因子条件选股，12种条件自由组合，全市场5100+股票实时扫描，按综合评分排序返回。触发词：选股、条件选股、筛选股票、多因子选股、全市场扫描、找股票、选股器、stock screener、选股条件
---

# A股多因子条件选股

## 概述

全市场5100+只A股实时扫描，支持12种量化选股条件自由组合，按综合评分排序返回最匹配的个股。小白也能用专业量化方法选股。

## 12种选股条件

| 编号 | 条件ID | 名称 | 说明 | 图标 |
|------|--------|------|------|------|
| 1 | td_buy | 九转买入 | 下跌九转计数>=7（买入信号） | 🔢 |
| 2 | td_sell | 九转卖出 | 上涨九转计数>=7（卖出信号） | 🔢 |
| 3 | main_inflow | 主力流入 | 主力资金净流入超1000万 | 💰 |
| 4 | main_outflow | 主力流出 | 主力资金净流出超1000万 | 💸 |
| 5 | macd_golden | MACD金叉 | DIF上穿DEA | 📈 |
| 6 | macd_death | MACD死叉 | DIF下穿DEA | 📉 |
| 7 | kdj_oversold | KDJ超卖 | K/D/J值低于20 | 🟢 |
| 8 | kdj_overbought | KDJ超买 | K/D/J值高于80 | 🔴 |
| 9 | chip_breakout | 筹码突破 | 价格突破筹码密集区 | 🧩 |
| 10 | volume_surge | 放量上涨 | 量比>2且涨幅>2% | 📊 |
| 11 | price_new_high | 创新高 | 20日内收盘价新高 | 🔺 |
| 12 | price_new_low | 创新低 | 20日内收盘价新低 | 🔻 |

## API使用

### 获取可选条件

```
GET /api/screener/conditions
```

返回12种条件的详细列表，前端可渲染为勾选框。

### 执行选股

```
GET /api/screener?conditions=td_buy,macd_golden,main_inflow&limit=20
```

- conditions：条件ID，逗号分隔（AND逻辑，需同时满足）
- limit：返回数量，默认20

### 返回数据结构

```json
{
  "success": true,
  "conditions": ["td_buy", "macd_golden", "main_inflow"],
  "results": [
    {
      "symbol": "000001.SZ",
      "name": "平安银行",
      "price": 12.50,
      "change_pct": 2.35,
      "matched_conditions": ["td_buy", "macd_golden", "main_inflow"],
      "score": 85,
      "details": {
        "td_count": 8,
        "macd_signal": "金叉",
        "main_net_inflow": 3500
      }
    }
  ],
  "total_scanned": 5106,
  "total_matched": 15,
  "scan_time": "2026-04-24 19:00:00"
}
```

## 信号看板（全市场扫描）

除了条件选股，还有策略信号看板，一键扫描全市场买卖信号：

```
GET /api/signals?type=all
```

- type：all/buy/sell/anomaly
- 返回分三组：buy_signals（买入）、sell_signals（卖出）、anomaly_signals（异动）

## 使用场景

### 场景1：经典多头组合

用户说："找几只即将反弹的股票"

推荐组合：`td_buy,macd_golden,main_inflow`
- 九转买入（技术面见底）+ MACD金叉（趋势转多）+ 主力流入（资金面配合）
- 三重确认，胜率最高

### 场景2：超跌反弹组合

用户说："找超跌的股票"

推荐组合：`kdj_oversold,td_buy`
- KDJ超卖（短期超跌）+ 九转买入（序列见底）
- 适合短线反弹

### 场景3：强势突破组合

用户说："找放量突破的股票"

推荐组合：`chip_breakout,volume_surge,macd_golden`
- 筹码突破（突破套牢区）+ 放量上涨（量价配合）+ MACD金叉（趋势确认）
- 适合追涨

### 场景4：风险预警组合

用户说："哪些股票该卖了"

推荐组合：`td_sell,macd_death,main_outflow`
- 九转卖出（序列见顶）+ MACD死叉（趋势转空）+ 主力流出（资金撤退）
- 三重卖出信号

## 注意事项

- 全市场扫描需10-30秒（5100+只股票逐只计算），请耐心等待
- 多条件组合时，匹配数量会大幅减少，属于正常现象
- 选股结果仅供参考，不构成投资建议
- 建议选中个股后，再用买卖点预测接口（/api/predict/{symbol}）进一步确认
- 非交易时段的选股基于最新收盘价数据

## 免责声明

本Skill提供的量化分析结果仅供参考学习，不构成任何投资建议。投资有风险，入市需谨慎。
