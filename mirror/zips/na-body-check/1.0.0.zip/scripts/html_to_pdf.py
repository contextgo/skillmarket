#!/usr/bin/env python3
"""
将体态分析 HTML 报告转换为 PDF 文件。
用法: python html_to_pdf.py <input.html> [output.pdf]
"""
import sys
import os
import asyncio
from pathlib import Path

async def convert_html_to_pdf(html_path: str, pdf_path: str = None):
    """使用 Playwright 将 HTML 文件转换为 PDF。"""
    from playwright.async_api import async_playwright

    html_file = Path(html_path).resolve()
    if not html_file.exists():
        print(f"Error: HTML file not found: {html_file}", file=sys.stderr)
        sys.exit(1)

    if pdf_path is None:
        pdf_path = html_file.with_suffix(".pdf")
    else:
        pdf_path = Path(pdf_path).resolve()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # 加载本地 HTML 文件
        await page.goto(f"file://{html_file}", wait_until="networkidle")

        # 等待字体和样式渲染完成
        await page.wait_for_timeout(1000)

        # 生成 PDF
        await page.pdf(
            path=str(pdf_path),
            format="A4",
            margin={"top": "20mm", "right": "15mm", "bottom": "20mm", "left": "15mm"},
            print_background=True,
            display_header_footer=True,
            header_template='<div style="font-size:9px; color:#999; width:100%; text-align:center; padding-top:5px;">体态分析报告</div>',
            footer_template='<div style="font-size:9px; color:#999; width:100%; text-align:center; padding-bottom:5px;"><span class="pageNumber"></span> / <span class="totalPages"></span></div>',
        )

        await browser.close()

    print(f"PDF generated: {pdf_path}")
    return str(pdf_path)


def main():
    if len(sys.argv) < 2:
        print("Usage: python html_to_pdf.py <input.html> [output.pdf]", file=sys.stderr)
        sys.exit(1)

    html_path = sys.argv[1]
    pdf_path = sys.argv[2] if len(sys.argv) > 2 else None

    asyncio.run(convert_html_to_pdf(html_path, pdf_path))


if __name__ == "__main__":
    main()
