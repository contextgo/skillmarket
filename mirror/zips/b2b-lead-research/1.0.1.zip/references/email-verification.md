# 邮箱验证方法完全指南

## 验证流程图

```
开始验证
    ↓
是否有公司域名？
    ├─ 是 → Hunter.io 域名搜索
    │         ↓
    │     找到邮箱？
    │     ├─ 是 → RocketReach 交叉验证 → 验证成功
    │     └─ 否 → LinkedIn 搜索决策人
    │               ↓
    │           找到决策人？
    │           ├─ 是 → 推导邮箱格式 → 验证成功
    │           └─ 否 → 尝试其他方法
    │
    └─ 否 → LinkedIn 搜索公司
              ↓
          找到公司？
          ├─ 是 → 找决策人 → 获取姓名 → 推导邮箱
          └─ 否 → 官网搜索
                    ↓
                找到官网？
                ├─ 是 → Contact页面查找
                └─ 否 → 搜索新闻稿/PR
```

---

## 方法1: Hunter.io（首选）

### 基础搜索

**域名搜索**（最准确）：
```
https://hunter.io/domain-search
```
输入公司域名，获取所有员工邮箱

**邮箱查找器**：
```
https://hunter.io/email-finder
```
输入姓名+域名，验证特定邮箱

### API调用

```bash
# 域名搜索
curl "https://api.hunter.io/v2/domain-search?domain=company.com&api_key=YOUR_KEY"

# 邮箱查找
curl "https://api.hunter.io/v2/email-finder?first_name=John&last_name=Smith&company=company.com&api_key=YOUR_KEY"
```

### 验证状态解读

| 状态 | 含义 | 可信度 |
|------|------|--------|
| verified | 多源确认 | ★★★★★ |
| accept_all | 域名接受所有邮箱 | ★★★☆☆ |
| unavailable | 未找到 | ★☆☆☆☆ |

---

## 方法2: LinkedIn Sales Navigator

### 搜索策略

**Step 1: 找到公司页面**
```
site:linkedin.com/company "公司名称"
```

**Step 2: 找决策人**
```
site:linkedin.com/in "Founder" OR "Owner" OR "President" "公司名称"
```

**Step 3: 获取姓名**
- 在公司About页面找管理团队
- 在员工列表中筛选职位

**Step 4: 推导邮箱**
```python
# 常见格式
patterns = [
    "{first}.{last}@{domain}",
    "{first}{last}@{domain}",
    "{first}@{domain}",
    "{first[0]}{last}@{domain}",
]
```

### LinkedIn Sales Navigator URL

```
https://www.linkedin.com/sales/search?company=[公司名]
https://www.linkedin.com/sales/search?title=[职位]&company=[公司名]
```

---

## 方法3: RocketReach

### 功能特点
- 7.5亿+专业人士数据
- 支持公司+姓名组合搜索
- 邮箱验证+手机号获取

### 搜索格式

```
https://rocketreach.co/search?keyword=[姓名/公司]
```

### API（付费）
```python
import requests

url = "https://rocketreach.co/api/v2/person"
params = {
    "name": "John Smith",
    "company": "Company Name",
    "api_key": "YOUR_KEY"
}
```

---

## 方法4: 官网Contact页面

### 查找优先级

1. `/contact-us` - 最常见
2. `/contact` - 短路径
3. `/about-us` - 团队介绍
4. `/team` - 管理层列表
5. `/get-in-touch` - 互动页面
6. `/enquiry` - 询价表单
7. `/sales` - 销售联系

### 常见邮箱格式

| 类型 | 格式 | 使用场景 |
|------|------|----------|
| 通用 | `info@company.com` | 初次联系 |
| 销售 | `sales@company.com` | 商业咨询 |
| 联系 | `contact@company.com` | 一般询问 |
| 采购 | `procurement@company.com` | 供应商联系 |
| 创始人 | `founder@company.com` | 创业公司 |

### 邮箱格式推导规则

```python
def generate_email_candidates(first, last, domain):
    first_lower = first.lower().replace(" ", "")
    last_lower = last.lower().replace(" ", "")
    domain_lower = domain.lower()

    return [
        f"{first_lower}.{last_lower}@{domain_lower}",
        f"{first_lower}{last_lower}@{domain_lower}",
        f"{first_lower[0]}{last_lower}@{domain_lower}",
        f"{first_lower}@{domain_lower}",
        f"{last_lower}@{domain_lower}",
    ]
```

---

## 方法5: BBB (Better Business Bureau)

### 适用场景
- 美国本土公司
- 查找公司注册信息
- 获取联系信息

### 搜索语法

```
site:bbb.org "公司名称" "城市"
```

### 提取信息
- 公司注册地址
- 联系电话
- 成立时间
- 业务类型
- 客户评价

---

## 方法6: PR Newswire / 新闻稿

### 适用场景
- CEO/创始人新闻
- 融资公告
- 重大发布

### 搜索语法

```
site:prnewswire.com "CEO" "公司名"
site:businesswire.com "Founder" "公司名"
site:prnewswire.com "company" "receives" "investment"
```

### 提取信息
- 高管姓名和职位
- 公司发展战略
- 联系方式（有时包含）

---

## 方法7: 公司数据库（扩展）

### Crunchbase
```
site:crunchbase.com "公司名"
```
获取：融资信息、团队成员、成立时间

### ZoomInfo
```
site:zoominfo.com "公司名"
```
获取：员工规模、联系方式、收入

### Clearbit
```python
# API调用
curl "https://company.clearbit.com/v2/companies/find?domain=company.com"
```

### AnyMail Finder
```
https://anymailfinder.com/
```
批量邮箱验证

---

## 验证决策流程

```
邮箱验证优先级矩阵

                    ├─ 有公司域名
                    │     ├─ Hunter.io → 找到 → 验证成功
                    │     └─ Hunter.io → 未找到
                    │           └─ LinkedIn → 推导邮箱
                    │
                    └─ 无公司域名
                          ├─ 有公司名
                          │     └─ LinkedIn → 公司页面 → 决策人
                          │                    └─ 推导邮箱
                          └─ 只有网站
                                └─ 浏览官网 → Contact页面
```

---

## 邮箱质量评估

### 评分标准

| 评分 | 来源 | 说明 |
|------|------|------|
| A | Hunter verified + LinkedIn确认 | 高质量，直接可用 |
| B | Hunter verified 或 LinkedIn确认 | 较高质量 |
| C | 官网Contact 或 格式推导 | 中等质量，谨慎使用 |
| D | 通用邮箱(info/sales) | 低质量，仅备用 |
| F | 未验证 | 不可使用 |

### 验证状态枚举

```markdown
| 状态 | 说明 |
|------|------|
| Verified | 多源确认，100%可信 |
| Probable | 格式正确+域名匹配 |
| Unverified | 仅搜索到，未验证 |
| Invalid | 已确认无效 |
| Catch-all | 域名接受所有邮箱，无法确认 |
```

---

## 常见问题处理

### Q1: 公司域名找不到
- 尝试访问官网，提取域名
- 使用WHOIS查询：`whois company.com`
- LinkedIn公司页面通常有官网链接

### Q2: LinkedIn找不到决策人
- 搜索 `site:linkedin.com "company" "employees"`
- 查看公司员工列表
- 尝试不同职位关键词

### Q3: 邮箱被退回
- 检查域名拼写
- 尝试不同格式
- 使用通用邮箱(info@)作为备选

### Q4: 公司太小没有信息
- 放宽搜索条件
- 关注社交媒体(Facebook/Instagram)
- 查找行业协会成员名单

---

## 验证工具清单

| 工具 | 类型 | 费用 | 推荐度 |
|------|------|------|--------|
| Hunter.io | 域名搜索 | 免费额度/付费 | ★★★★★ |
| RocketReach | 综合查询 | 付费 | ★★★★☆ |
| LinkedIn | 社交数据 | 免费/付费 | ★★★★☆ |
| Snov.io | 邮箱查找 | 免费/付费 | ★★★★☆ |
| Clearbit | 公司数据 | 付费API | ★★★☆☆ |
| AnyMail Finder | 验证工具 | 免费试用 | ★★★☆☆ |
| Findymail | 邮箱验证 | 付费 | ★★★☆☆ |
