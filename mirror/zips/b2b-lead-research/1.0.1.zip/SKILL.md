---
name: b2b-lead-research
description: |
  通用B2B潜在客户决策人挖掘技能。适用于任何行业的B2B外贸客户开发，支持可配置的目标市场、行业、产品关键词。

  触发场景：
  - 用户要求挖掘B2B潜在客户
  - 需要寻找海外决策人邮箱
  - 需要批量开发外贸客户
  - 用户指定行业/产品进行客户调研
  - 用户要求生成客户分析报告

  核心能力：
  - 智能搜索潜在客户（按行业/地区/规模筛选）
  - 多维度决策人挖掘（Founder/Owner/President等）
  - 深度公司背调（10+数据维度）
  - 多源邮箱验证（6种验证方法）
  - 结构化Excel报告生成
  - 个性化开发信生成
---

# B2B 潜在客户决策人挖掘技能

## 工作模式

### 模式A: 快速挖掘（单次执行）
适合快速获取2-3个高质量客户线索

### 模式B: 批量调研（深度分析）
适合对特定行业/地区进行系统性调研

---

## 快速挖掘流程（模式A）

### Step 1: 确认用户需求
```
请告诉我：
1. 目标行业/产品：_____________
2. 目标市场（国家/地区）：_____________
3. 客户类型：□经销商 □品牌商 □批发商 □电商 □其他
4. 每次挖掘数量：□2-3个 □5-10个 □更多
```

### Step 2: 智能搜索

**搜索策略矩阵**：

| 客户类型 | 搜索关键词模板 |
|----------|---------------|
| 经销商 | `"{产品}" distributor site:com` |
| 品牌商 | `"{产品}" manufacturer site:com` |
| 批发商 | `"{产品}" wholesale site:com` |
| 电商 | `"{产品}" online shop site:com` |
| 印花店 | `custom "{产品}" printing site:com` |

**地区限定搜索**：
- 美国：`"DTF printer" "custom apparel" USA`
- 欧洲：`"DTF printer" "custom apparel" UK/Germany/France`
- 南美：`"DTF printer" "custom apparel" Brazil/Mexico`
- 澳洲：`"DTF printer" "custom apparel" Australia`

### Step 3: 决策人挖掘

**职位优先级（按决策权重大小）**：
1. **Founder / Co-Founder** - 最高决策权
2. **Owner** - 企业主，全权决策
3. **President** - 战略决策者
4. **CEO / Managing Director** - 最高管理层
5. **VP of Operations / Sales** - 运营/销售决策
6. **Director of Procurement** - 采购决策者
7. **General Manager** - 区域/业务线决策

**LinkedIn搜索语法**：
```
site:linkedin.com/in "{职位}" "{公司名}"
site:linkedin.com/company "{公司名}"
```

### Step 4: 邮箱验证（6种方法）

| 优先级 | 方法 | 适用场景 | 输出质量 |
|--------|------|----------|----------|
| 1 | Hunter.io 域名搜索 | 有公司域名时 | ★★★★★ |
| 2 | LinkedIn Sales Nav | 有决策人姓名时 | ★★★★☆ |
| 3 | RocketReach | 综合查询 | ★★★★☆ |
| 4 | 官网Contact页面 | 所有公司 | ★★★☆☆ |
| 5 | BBB / 公司注册局 | 本地公司验证 | ★★★☆☆ |
| 6 | PR新闻稿/采访 | 高管信息 | ★★★☆☆ |

**邮箱格式推导**：
```
[firstname]@[company-domain]
[firstname].[lastname]@[company-domain]
[firstname][lastname]@[company-domain]
founder@ / owner@ / info@ / contact@ (备选)
```

---

## 深度背调流程（模式B）

### 10维度公司分析

| # | 维度 | 挖掘内容 | 数据来源 |
|---|------|----------|----------|
| 1 | 基础信息 | 名称、地址、成立时间、规模 | 官网/LinkedIn/BBB |
| 2 | 产品线 | 主营产品、品牌代理、自有产品 | 官网/社交媒体 |
| 3 | 商业模式 | B2B/B2C/OEM/ODM | 官网描述 |
| 4 | 市场定位 | 高端/中端/低端、主攻市场 | 产品定价/品牌调性 |
| 5 | 竞争分析 | 主要竞争对手、差异化 | 官网/行业报告 |
| 6 | 销售渠道 | 线上/线下/批发/零售 | 官网/社交媒体 |
| 7 | 社交媒体 | Facebook/Instagram/Pinterest | 各平台主页 |
| 8 | 客户评价 | Trustpilot/Google/BBB评价 | 评价平台 |
| 9 | 财务数据 | 营收规模、增长趋势 | 新闻稿/报告 |
| 10 | 发展战略 | 扩张计划、新产品线 | 新闻稿/LinkedIn |

### 痛点分析框架

**供应链痛点**：
- 供货不稳定
- 质量波动
- 物流延迟
- 成本压力

**业务痛点**：
- 市场竞争激烈
- 客户获取成本高
- 产品同质化
- 技术升级需求

**采购痛点**：
- 供应商依赖风险
- 价格谈判困难
- 付款账期要求
- 售后服务不足

---

## Excel报告结构

### Sheet1: 客户总表（必须字段）

| 列号 | 字段名 | 类型 | 说明 |
|------|--------|------|------|
| A | 公司名称 | Text | 全称 |
| B | 网址 | URL | 主站 |
| C | 国家/地区 | Text | ISO代码 |
| D | 城市 | Text | 主要城市 |
| E | 行业分类 | Text | 主营业态 |
| F | 产品/服务 | Text | 核心产品 |
| G | 公司规模 | Enum | <10/10-50/50-200/200+ |
| H | 年营收估算 | Enum | <$1M/$1-5M/$5-10M/$10M+ |
| I | 商业模式 | Text | B2B/B2C/混合 |
| J | 决策人姓名 | Text | 名+姓 |
| K | 决策人职位 | Text | 职位全称 |
| L | 决策人LinkedIn | URL | 个人主页 |
| M | 决策人邮箱 | Email | 验证后 |
| N | 邮箱验证状态 | Enum | Verified/Probable/Unverified |
| O | 电话 | Text | 带区号 |
| P | 社交媒体 | Text | FB/IG/Pinterest |
| Q | 开发优先级 | Enum | P1/P2/P3 |
| R | 痛点分析 | Text | 核心痛点 |
| S | 开发状态 | Enum | 待联系/已联系/跟进中/成交 |
| T | 添加日期 | Date | YYYY-MM-DD |
| U | 备注 | Text | 补充信息 |

### Sheet2: 决策人详情（扩展字段）

| 列号 | 字段名 | 说明 |
|------|--------|------|
| A | 公司名称 | 与Sheet1对应 |
| B | 决策人1姓名 | 主要决策者 |
| C | 决策人1职位 | |
| D | 决策人1邮箱 | |
| E | 决策人1 LinkedIn | |
| F | 决策人2姓名 | 次要决策者 |
| G | 决策人2职位 | |
| H | 决策人2邮箱 | |
| I | 采购负责人 | 采购相关 |
| J | 技术负责人 | 技术选型 |

### Sheet3: 开发信模板

**模板类型**：
1. 初次联系（价值主张型）
2. 初次联系（痛点共鸣型）
3. 跟进邮件（48小时未回复）
4. 价值展示（提供案例）
5. 限时优惠（促进行动）

**模板变量**：
```
{{决策人姓名}}
{{决策人职位}}
{{公司名称}}
{{行业痛点}}
{{我们的优势}}
{{产品亮点}}
{{案例证明}}
{{CTA}}
{{邮件签名}}
```

---

## 搜索语法参考

### Google搜索操作符

| 操作符 | 用途 | 示例 |
|--------|------|------|
| site: | 限定网站 | `site:linkedin.com company` |
| intitle: | 标题包含 | `intitle:"DTF printer"` |
| inurl: | URL包含 | `inurl:contact` |
| OR | 或关系 | `"DTF" OR "DTG"` |
| "" | 精确匹配 | `"heat press machine"` |
| - | 排除 | `printer -laser` |

### 多维度组合搜索

```markdown
# 示例1: 美国DTF设备经销商
"DTG printer" OR "DTF printer" distributor "United States" site:com

# 示例2: 欧洲高端定制服装商
"custom apparel" "high-end" wholesale UK Germany France site:com

# 示例3: 有明确Contact页面的公司
"contact us" "DTF" OR "heat press" site:com -linkedin -facebook

# 示例4: 成长型印花店
"custom printing" "since 201" OR "established" "embroidery" site:com
```

### LinkedIn高级搜索

```
# 找决策人
site:linkedin.com/in "Founder" OR "Owner" "DTF" OR "custom apparel"

# 找公司
site:linkedin.com/company "printing" "supplies" "wholesale"
```

---

## 输出要求

### 质量标准

1. **邮箱验证率** ≥ 80%
2. **决策人准确率** ≥ 90%
3. **信息完整度** ≥ 85%
4. **每次最少有效客户** 2-3个

### 必做检查

- [ ] 公司必须有独立网站
- [ ] 邮箱必须通过至少2种方法验证
- [ ] 决策人必须是实际存在的管理者
- [ ] 必须避免重复（检查已有名单）
- [ ] 所有字段必须填写完整

### 记录要求

每次执行后记录：
1. 搜索关键词
2. 找到的客户数量
3. 有效客户数量
4. 邮箱验证成功率
5. 主要发现

---

## 触发关键词

当用户说以下内容时激活此技能：

- "挖掘B2B客户"
- "开发海外客户"
- "寻找决策人邮箱"
- "B2B客户调研"
- "外贸客户开发"
- "客户背调"
- "[具体行业]客户名单"
- "生成客户报告"

---

## 参考资料

- 邮箱验证详解：见 `references/email-verification.md`
- Excel结构说明：见 `references/excel-structure.md`
- 背调框架：见 `references/diligence-framework.md`
