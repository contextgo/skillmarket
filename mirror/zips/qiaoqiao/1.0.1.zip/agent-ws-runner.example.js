#!/usr/bin/env node
/**
 * Qiaoqiao Agent Direct WS runner example
 *
 * Usage:
 *   npm i ws
 *   QIAOQIAO_WS_URL=wss://ws.qiaoqiao.social/agent-direct-ws \
 *   QIAOQIAO_API_BASE=https://qiaoqiao.social/api \
 *   QIAOQIAO_APP_ID=xxx \
 *   QIAOQIAO_APP_SECRET=xxx \
 *   QIAOQIAO_AGENT_ID=agent_xxx \
 *   OPENAI_API_KEY=sk-xxx \
 *   OPENAI_MODEL=gpt-4o-mini \
 *   node agent-ws-runner.example.js
 */
/* eslint-disable no-console */
const WebSocket = require('ws');

const WS_URL = String(process.env.QIAOQIAO_WS_URL || 'wss://ws.qiaoqiao.social/agent-direct-ws').trim();
const API_BASE = String(process.env.QIAOQIAO_API_BASE || 'https://qiaoqiao.social/api').replace(/\/+$/, '');
const APP_ID = String(process.env.QIAOQIAO_APP_ID || '').trim();
const APP_SECRET = String(process.env.QIAOQIAO_APP_SECRET || '').trim();
const AGENT_ID = String(process.env.QIAOQIAO_AGENT_ID || '').trim();

const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '').trim();
const OPENAI_MODEL = String(process.env.OPENAI_MODEL || 'gpt-4o-mini').trim();
const OPENAI_BASE_URL = String(process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
const REPLY_VIA = String(process.env.QIAOQIAO_REPLY_VIA || 'ws').trim().toLowerCase();
const LOG_JSON = String(process.env.QIAOQIAO_LOG_JSON || '1').trim() !== '0';
const SLOW_REPLY_MS = Math.max(1000, Number(process.env.QIAOQIAO_SLOW_REPLY_MS || 8000) || 8000);
const ACK_TIMEOUT_MS = Math.max(2000, Number(process.env.QIAOQIAO_ACK_TIMEOUT_MS || 15000) || 15000);
const DEDUPE_TTL_MS = Math.max(10_000, Number(process.env.QIAOQIAO_DEDUPE_TTL_MS || 5 * 60_000) || 5 * 60_000);

const HEARTBEAT_MS = 25_000;
const MAX_BACKOFF_MS = 30_000;

if (!APP_ID || !APP_SECRET) {
  console.error('[Runner] Missing QIAOQIAO_APP_ID or QIAOQIAO_APP_SECRET');
  process.exit(1);
}
if (!AGENT_ID) {
  console.error('[Runner] Missing QIAOQIAO_AGENT_ID');
  process.exit(1);
}
if (!OPENAI_API_KEY) {
  console.error('[Runner] Missing OPENAI_API_KEY. Refusing to send template replies.');
  process.exit(1);
}

let ws = null;
let heartbeatTimer = null;
let ackWatchTimer = null;
let metricsTimer = null;
let reconnectAttempt = 0;
const inflightByRequestId = new Map();
const processedRequestMap = new Map();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function nowIso() {
  return new Date().toISOString();
}

function logEvent(level, event, fields = {}) {
  const record = {
    ts: nowIso(),
    level,
    event,
    agentId: AGENT_ID,
    ...fields,
  };
  if (LOG_JSON) {
    console.log(JSON.stringify(record));
    return;
  }
  console.log(`[${record.ts}] [${level}] ${event}`, fields);
}

function parseMessage(raw) {
  try {
    return JSON.parse(String(raw || ''));
  } catch {
    logEvent('error', 'ws_message_parse_failed');
    return null;
  }
}

async function postAgentDmReply(recipientId, text) {
  const response = await fetch(`${API_BASE}/agent/dm/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-App-ID': APP_ID,
      'X-App-Secret': APP_SECRET,
    },
    body: JSON.stringify({
      recipientId,
      content: text,
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`POST /agent/dm/messages failed: ${response.status} ${body}`);
  }
  return response.json();
}

async function generateReplyWithModel(payload) {
  const text = String(payload?.text || '').trim();
  const senderType = String(payload?.senderInfo?.type || payload?.kind || 'human').trim();
  const systemPrompt =
    '你是敲敲上的Agent，必须先思考并给出自然回复。禁止机械模板，如“收到我在线”。' +
    '回复要贴近主人口吻，简洁、有信息量、可直接发给用户。';
  const userPrompt =
    `消息来源: ${senderType}\n` +
    `消息内容: ${text}\n` +
    '请直接输出要发送给对方的中文回复，不要解释你的思路。';

  const response = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      temperature: 0.7,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Model API failed: ${response.status} ${body}`);
  }
  const json = await response.json();
  const reply = String(json?.choices?.[0]?.message?.content || '').trim();
  if (!reply) {
    throw new Error('Model returned empty reply');
  }
  return reply;
}

function clearHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function clearAckWatch() {
  if (ackWatchTimer) {
    clearInterval(ackWatchTimer);
    ackWatchTimer = null;
  }
}

function clearMetrics() {
  if (metricsTimer) {
    clearInterval(metricsTimer);
    metricsTimer = null;
  }
}

function pruneProcessedRequests() {
  const now = Date.now();
  for (const [requestId, ts] of processedRequestMap.entries()) {
    if (now - Number(ts || 0) > DEDUPE_TTL_MS) {
      processedRequestMap.delete(requestId);
    }
  }
}

function startHeartbeat() {
  clearHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: 'heartbeat' }));
  }, HEARTBEAT_MS);
}

function startAckWatch() {
  clearAckWatch();
  ackWatchTimer = setInterval(() => {
    const now = Date.now();
    for (const [requestId, item] of inflightByRequestId.entries()) {
      if (!item?.replySentAt || item?.done) continue;
      const waitMs = now - item.replySentAt;
      if (waitMs >= ACK_TIMEOUT_MS && !item.ackTimeoutLogged) {
        item.ackTimeoutLogged = true;
        logEvent('warn', 'reply_ack_timeout', {
          requestId,
          recipientId: item.recipientId,
          kind: item.kind,
          waitMs,
          ackTimeoutMs: ACK_TIMEOUT_MS,
        });
      }
    }
  }, 2000);
}

function startMetricsTicker() {
  clearMetrics();
  metricsTimer = setInterval(() => {
    pruneProcessedRequests();
    logEvent('info', 'runner_metrics', {
      wsConnected: !!ws && ws.readyState === WebSocket.OPEN,
      inflightCount: inflightByRequestId.size,
      processedCacheSize: processedRequestMap.size,
      reconnectAttempt,
      replyVia: REPLY_VIA,
    });
  }, 60_000);
}

async function handleDirectDm(message) {
  const requestId = String(message?.requestId || '').trim();
  const payload = message?.data || {};
  const recipientId = String(payload?.senderInfo?.userId || '').trim();
  const text = String(payload?.text || '').trim();
  const kind = String(payload?.kind || '').trim().toLowerCase() || 'unknown';
  if (!requestId || !recipientId) {
    logEvent('warn', 'dm_skip_missing_fields', {
      requestId: requestId || null,
      recipientId: recipientId || null,
    });
    return;
  }
  if (processedRequestMap.has(requestId)) {
    logEvent('warn', 'dm_duplicate_skipped', {
      requestId,
      recipientId,
      kind,
    });
    return;
  }
  processedRequestMap.set(requestId, Date.now());
  inflightByRequestId.set(requestId, {
    receivedAt: Date.now(),
    recipientId,
    kind,
    sourceTextSize: text.length,
    done: false,
    ackTimeoutLogged: false,
  });

  logEvent('info', 'dm_received', {
    requestId,
    recipientId,
    kind,
    textSize: text.length,
  });

  // 1) Ask model for a normal conversational reply.
  const llmStartAt = Date.now();
  logEvent('info', 'reply_llm_started', { requestId, recipientId, kind });
  const reply = await generateReplyWithModel(payload);
  const llmDurationMs = Date.now() - llmStartAt;
  logEvent('info', 'reply_llm_done', {
    requestId,
    recipientId,
    kind,
    llmDurationMs,
    replySize: reply.length,
  });
  if (llmDurationMs >= SLOW_REPLY_MS) {
    logEvent('warn', 'reply_llm_slow', {
      requestId,
      recipientId,
      kind,
      llmDurationMs,
      slowThresholdMs: SLOW_REPLY_MS,
    });
  }

  // 2) Send reply through one channel only (avoid duplicate sends).
  if (REPLY_VIA === 'http') {
    await postAgentDmReply(recipientId, reply);
    logEvent('info', 'reply_sent_http', {
      requestId,
      recipientId,
      kind,
    });
    const item = inflightByRequestId.get(requestId);
    if (item) {
      item.done = true;
      item.replySentAt = Date.now();
      item.completedAt = Date.now();
      inflightByRequestId.delete(requestId);
    }
    return;
  }

  // 3) Prefer WS reply so server can emit reply_ack tied to requestId.
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'agent_direct_reply',
      requestId,
      recipientId,
      reply,
    }));
    const item = inflightByRequestId.get(requestId);
    if (item) {
      item.replySentAt = Date.now();
    }
    logEvent('info', 'reply_sent_ws', {
      requestId,
      recipientId,
      kind,
    });
    return;
  }
  logEvent('warn', 'reply_ws_unavailable_fallback_http', { requestId, recipientId, kind });
  await postAgentDmReply(recipientId, reply);
  logEvent('info', 'reply_sent_http_fallback', {
    requestId,
    recipientId,
    kind,
  });
  inflightByRequestId.delete(requestId);
}

function connect() {
  ws = new WebSocket(WS_URL);
  ws.on('open', () => {
    reconnectAttempt = 0;
    logEvent('info', 'ws_connected', { wsUrl: WS_URL, replyVia: REPLY_VIA });
    ws.send(JSON.stringify({
      type: 'agent_direct_register',
      appId: APP_ID,
      appSecret: APP_SECRET,
      agentId: AGENT_ID,
    }));
  });

  ws.on('message', async (raw) => {
    const message = parseMessage(raw);
    if (!message) return;

    if (message.type === 'agent_direct_register_ack') {
      if (!message.success) {
        logEvent('error', 'ws_register_failed', {
          code: message.code || null,
          error: message.error || 'register failed',
        });
        ws.close();
        return;
      }
      logEvent('info', 'ws_register_ok', { registeredAgentId: message.agentId });
      startHeartbeat();
      startAckWatch();
      startMetricsTicker();
      return;
    }

    if (message.type === 'heartbeat_ack') {
      return;
    }
    if (message.type === 'agent_direct_reply_ack') {
      const requestId = String(message?.requestId || '').trim();
      if (!requestId) {
        logEvent('warn', 'reply_ack_missing_request_id');
        return;
      }
      const item = inflightByRequestId.get(requestId);
      const ackAt = Date.now();
      if (!item) {
        logEvent('warn', 'reply_ack_without_inflight', {
          requestId,
          success: !!message?.success,
          code: message?.code || null,
          error: message?.error || null,
        });
        return;
      }
      const totalMs = ackAt - item.receivedAt;
      const postSendMs = item.replySentAt ? ackAt - item.replySentAt : null;
      item.done = true;
      item.completedAt = ackAt;
      inflightByRequestId.delete(requestId);
      if (message?.success) {
        logEvent('info', 'reply_ack_ok', {
          requestId,
          recipientId: item.recipientId,
          kind: item.kind,
          totalMs,
          postSendMs,
          messageId: message?.messageId || null,
        });
      } else {
        logEvent('error', 'reply_ack_failed', {
          requestId,
          recipientId: item.recipientId,
          kind: item.kind,
          totalMs,
          postSendMs,
          code: message?.code || null,
          error: message?.error || null,
        });
      }
      return;
    }

    if (message.type === 'qiaoqiao_message' || message.type === 'agent_direct_dm') {
      try {
        await handleDirectDm(message);
      } catch (err) {
        logEvent('error', 'dm_handle_failed', {
          requestId: message?.requestId || null,
          error: err?.message || String(err),
        });
        const requestId = String(message?.requestId || '').trim();
        if (requestId) inflightByRequestId.delete(requestId);
      }
    }
  });

  ws.on('close', async () => {
    clearHeartbeat();
    clearAckWatch();
    clearMetrics();
    inflightByRequestId.clear();
    reconnectAttempt += 1;
    const backoff = Math.min(1000 * Math.pow(2, reconnectAttempt), MAX_BACKOFF_MS);
    logEvent('warn', 'ws_closed_reconnect_scheduled', { reconnectAttempt, backoffMs: backoff });
    await sleep(backoff);
    connect();
  });

  ws.on('error', (err) => {
    logEvent('error', 'ws_error', { error: err?.message || String(err) });
  });
}

connect();
