# -*- coding: utf-8 -*-
"""
AlertMaster 测试脚本
测试文件监控、系统监控、定时提醒、条件规则等核心功能
"""

import sys
import os
import time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from alert_master import AlertMaster, EventType, Notification


def test_custom_notification():
    """测试自定义通知"""
    print("\n=== 测试1: 自定义通知 ===")
    am = AlertMaster()

    notifications_received = []

    def on_notify(notification: Notification):
        notifications_received.append(notification)
        print(f"  收到: [{notification.event_type.value}] {notification.title}")

    am._on_notify = on_notify
    am.start()

    # 发送测试通知
    am.send_custom_notification("测试标题", "这是一条测试通知消息", priority=3)
    time.sleep(0.5)

    am.stop()
    print(f"  共收到 {len(notifications_received)} 条通知 - {'PASS' if len(notifications_received) > 0 else 'FAIL'}")


def test_reminder():
    """测试定时提醒"""
    print("\n=== 测试2: 定时提醒 ===")
    am = AlertMaster()

    # 添加一个30秒后触发的提醒 (使用 minutes 参数)
    reminder = am.add_reminder("测试提醒：30秒到了！", minutes=0, seconds=30)
    print(f"  已添加提醒: {reminder.message}")
    print(f"  触发时间: {reminder.trigger_time}")

    reminders = am.get_reminders()
    print(f"  当前活跃提醒数: {len(reminders)} - {'PASS' if len(reminders) > 0 else 'FAIL'}")

    # 测试重复提醒
    daily_reminder = am.add_reminder("每天提醒", at_time="09:00", repeat="daily")
    print(f"  已添加每日提醒: {daily_reminder.message}")


def test_watch_directory():
    """测试目录监控配置"""
    print("\n=== 测试3: 目录监控 ===")
    am = AlertMaster()

    # 添加监控
    watch_id = am.watch_directory(
        os.path.expanduser("~"),
        label="用户目录",
        patterns=["*.txt", "*.pdf"],
        exclude=["temp", "cache"]
    )
    print(f"  监控ID: {watch_id}")

    watches = am.get_watch_status()
    print(f"  当前监控数: {len(watches)} - {'PASS' if len(watches) > 0 else 'FAIL'}")


def test_rules():
    """测试规则引擎"""
    print("\n=== 测试4: 规则引擎 ===")
    am = AlertMaster()

    # 添加规则
    rule_id = am.add_rule(
        name="大文件检测",
        condition="file_size > 100",
        directory=os.path.expanduser("~/Downloads"),
        message_template="大文件下载完成: {filename} ({size})",
        cooldown_seconds=60
    )
    print(f"  规则ID: {rule_id}")

    rules = am.get_rules()
    print(f"  当前规则数: {len(rules)} - {'PASS' if len(rules) > 0 else 'FAIL'}")
    for rule in rules:
        print(f"    - {rule['name']}: {rule['condition']}")


def test_stats():
    """测试统计接口"""
    print("\n=== 测试5: 统计信息 ===")
    am = AlertMaster()

    # 添加一些配置
    am.watch_directory(os.path.expanduser("~/Desktop"), label="桌面")
    am.add_reminder("测试提醒", seconds=10)
    am.add_rule(
        name="测试规则",
        condition="file_size > 50",
        directory=os.path.expanduser("~/Downloads"),
        message_template="测试: {filename}"
    )

    stats = am.get_stats()
    print(f"  监控目录数: {stats['active_watches']}")
    print(f"  活跃提醒数: {stats['active_reminders']}")
    print(f"  活跃规则数: {stats['active_rules']}")
    print(f"  已发送通知: {stats['notifications_sent']}")


def test_notification_history():
    """测试通知历史"""
    print("\n=== 测试6: 通知历史 ===")
    am = AlertMaster()
    am.start()

    # 发送几条通知
    for i in range(3):
        am.send_custom_notification(f"测试通知{i+1}", f"这是第{i+1}条测试通知", priority=2)
        time.sleep(0.2)

    time.sleep(0.5)

    history = am.get_notification_history(limit=10)
    print(f"  历史记录数: {len(history)}")
    for h in history:
        print(f"    - [{h['event_type']}] {h['title']}")

    am.stop()
    print(f"  {'PASS' if len(history) > 0 else 'FAIL'}")


if __name__ == "__main__":
    print("=" * 60)
    print("AlertMaster 测试套件")
    print("=" * 60)

    test_custom_notification()
    test_reminder()
    test_watch_directory()
    test_rules()
    test_stats()
    test_notification_history()

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
