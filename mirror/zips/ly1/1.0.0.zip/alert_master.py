# -*- coding: utf-8 -*-
"""
AlertMaster — 主动通知指挥官
玲瑶主动通知系统精华版，商城化独立运行版本

核心功能：
1. 文件监控 — 监控目录变化，支持大小过滤/排除模式
2. 系统监控 — 磁盘/内存/CPU告警
3. 定时提醒 — 单次/每小时/每天/每周
4. 规则引擎 — 条件表达式触发（file_size > 500, ext == .exe）
5. Windows Toast + 语音双通道通知

来源：E:\AI_dugujianhu\app\tools\proactive_notifier.py
版本：商城化优化版 v1.0
"""

import os
import sys
import io
import json
import time
import re
import hashlib
import threading
import queue
import subprocess
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


# ============================================================
# 数据目录
# ============================================================

def _get_data_dir() -> Path:
    """获取数据存储目录"""
    data_dir = Path.home() / ".alert_master_data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir

REMINDERS_FILE = _get_data_dir() / "reminders.json"
WATCHES_FILE = _get_data_dir() / "watches.json"
RULES_FILE = _get_data_dir() / "rules.json"
NOTIFICATION_LOG = _get_data_dir() / "notification_log.json"


# ============================================================
# 数据结构
# ============================================================

class EventType(Enum):
    FILE_CREATED = "file_created"
    FILE_MODIFIED = "file_modified"
    FILE_DELETED = "file_deleted"
    DISK_WARNING = "disk_warning"
    MEMORY_WARNING = "memory_warning"
    CPU_WARNING = "cpu_warning"
    REMINDER = "reminder"
    RULE_TRIGGERED = "rule_triggered"
    CUSTOM = "custom"


@dataclass
class Notification:
    notify_id: str = ""
    event_type: EventType = EventType.CUSTOM
    title: str = ""
    message: str = ""
    source: str = "custom"
    priority: int = 2
    timestamp: str = ""
    dismissed: bool = False
    metadata: Dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> Dict:
        return {
            "notify_id": self.notify_id,
            "event_type": self.event_type.value,
            "title": self.title,
            "message": self.message,
            "source": self.source,
            "priority": self.priority,
            "timestamp": self.timestamp,
            "dismissed": self.dismissed,
            "metadata": self.metadata,
        }


@dataclass
class WatchConfig:
    watch_id: str = ""
    directory: str = ""
    label: str = ""
    patterns: List[str] = field(default_factory=lambda: ["*"])
    recursive: bool = True
    enabled: bool = True
    notify_created: bool = True
    notify_modified: bool = False
    notify_deleted: bool = True
    min_size_mb: float = 0
    max_size_mb: float = 0
    exclude_patterns: List[str] = field(default_factory=list)
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.label:
            self.label = Path(self.directory).name


@dataclass
class Reminder:
    reminder_id: str = ""
    message: str = ""
    trigger_time: str = ""
    repeat: str = ""
    enabled: bool = True
    triggered_count: int = 0
    last_triggered: str = ""
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class NotifyRule:
    rule_id: str = ""
    name: str = ""
    condition: str = ""
    directory: str = ""
    message_template: str = ""
    cooldown_seconds: int = 300
    last_triggered: str = ""
    enabled: bool = True
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


# ============================================================
# 文件系统监控器（原生实现，无外部依赖）
# ============================================================

class FileSystemWatcher:
    """原生文件系统监控器，定期扫描目录变化"""

    def __init__(self, scan_interval: float = 2.0):
        self.scan_interval = scan_interval
        self._watch_configs: Dict[str, WatchConfig] = {}
        self._file_snapshots: Dict[str, Dict[str, float]] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable[[Notification], None]] = None

    def add_watch(self, config: WatchConfig):
        self._watch_configs[config.watch_id] = config
        self._take_snapshot(config)

    def remove_watch(self, watch_id: str):
        self._watch_configs.pop(watch_id, None)
        self._file_snapshots.pop(watch_id, None)

    def _take_snapshot(self, config: WatchConfig):
        snapshot = {}
        directory = Path(config.directory)
        if not directory.exists():
            return
        patterns = config.patterns or ["*"]
        for pattern in patterns:
            files = directory.rglob(pattern) if config.recursive else directory.glob(pattern)
            for f in files:
                if f.is_file():
                    try:
                        snapshot[str(f)] = f.stat().st_mtime
                    except (OSError, PermissionError):
                        continue
        self._file_snapshots[config.watch_id] = snapshot

    def _scan_changes(self) -> List[Notification]:
        notifications = []
        for watch_id, config in self._watch_configs.items():
            if not config.enabled:
                continue
            old_snapshot = self._file_snapshots.get(watch_id, {})
            new_snapshot = {}
            directory = Path(config.directory)
            if not directory.exists():
                continue
            patterns = config.patterns or ["*"]
            for pattern in patterns:
                files = directory.rglob(pattern) if config.recursive else directory.glob(pattern)
                for f in files:
                    if not f.is_file():
                        continue
                    fpath = str(f)
                    # 排除检查
                    if any(exc in f.name for exc in config.exclude_patterns):
                        continue
                    try:
                        stat = f.stat()
                        mtime = stat.st_mtime
                        size_mb = stat.st_size / (1024 * 1024)
                        if config.min_size_mb > 0 and size_mb < config.min_size_mb:
                            continue
                        if config.max_size_mb > 0 and size_mb > config.max_size_mb:
                            continue
                        new_snapshot[fpath] = mtime
                        if fpath not in old_snapshot and config.notify_created:
                            notifications.append(Notification(
                                notify_id=f"fcreate_{hashlib.md5(fpath.encode()).hexdigest()[:8]}",
                                event_type=EventType.FILE_CREATED,
                                title=f"新文件: {config.label}",
                                message=f"{f.name} ({size_mb:.1f}MB)",
                                source="filesystem",
                                priority=3 if size_mb > 100 else 2,
                                metadata={"path": fpath, "size_mb": round(size_mb, 2), "label": config.label}
                            ))
                        elif old_snapshot[fpath] != mtime and config.notify_modified:
                            notifications.append(Notification(
                                notify_id=f"fmod_{hashlib.md5(fpath.encode()).hexdigest()[:8]}",
                                event_type=EventType.FILE_MODIFIED,
                                title=f"文件修改: {f.name}",
                                message=f"{config.label}/{f.name}",
                                source="filesystem",
                                priority=1,
                                metadata={"path": fpath, "label": config.label}
                            ))
                    except (OSError, PermissionError):
                        continue
            # 检查删除
            for fpath in old_snapshot:
                if fpath not in new_snapshot and config.notify_deleted:
                    fname = Path(fpath).name
                    notifications.append(Notification(
                        notify_id=f"fdel_{hashlib.md5(fpath.encode()).hexdigest()[:8]}",
                        event_type=EventType.FILE_DELETED,
                        title=f"文件删除: {fname}",
                        message=f"{config.label}/{fname}",
                        source="filesystem",
                        priority=2,
                        metadata={"path": fpath, "label": config.label}
                    ))
            self._file_snapshots[watch_id] = new_snapshot
        return notifications

    def start(self, callback: Callable[[Notification], None]):
        self._callback = callback
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="fs-watcher")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self):
        while self._running:
            try:
                for n in self._scan_changes():
                    if self._callback:
                        self._callback(n)
            except Exception:
                pass
            time.sleep(self.scan_interval)


# ============================================================
# 系统监控器
# ============================================================

class SystemMonitor:
    """系统资源监控器"""

    def __init__(self, check_interval: float = 60.0):
        self.check_interval = check_interval
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable[[Notification], None]] = None
        self.disk_warning_threshold = 10
        self.memory_warning_threshold = 90
        self.cpu_warning_threshold = 95
        self._last_alerts: Dict[str, str] = {}
        self._alert_cooldown = 3600

    def start(self, callback: Callable[[Notification], None]):
        self._callback = callback
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="sys-monitor")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self):
        while self._running:
            try:
                self._check_disk()
                self._check_memory()
                self._check_cpu()
            except Exception:
                pass
            time.sleep(self.check_interval)

    def _check_disk(self):
        for drive in ["C:\\", "D:\\", "E:\\"]:
            try:
                if not os.path.exists(drive):
                    continue
                usage = shutil.disk_usage(drive)
                free_gb = usage.free / (1024**3)
                percent_free = (usage.free / usage.total) * 100
                if percent_free < self.disk_warning_threshold and self._can_alert(f"disk_{drive}"):
                    self._callback(Notification(
                        notify_id=f"disk_{drive.strip(':\\\\')}",
                        event_type=EventType.DISK_WARNING,
                        title=f"磁盘空间不足: {drive}",
                        message=f"剩余 {free_gb:.1f}GB ({percent_free:.1f}%)",
                        source="system",
                        priority=4,
                        metadata={"drive": drive, "free_gb": round(free_gb, 1), "percent": round(percent_free, 1)}
                    ))
            except Exception:
                pass

    def _check_memory(self):
        try:
            import psutil
            mem = psutil.virtual_memory()
            if mem.percent > self.memory_warning_threshold and self._can_alert("memory"):
                self._callback(Notification(
                    notify_id="memory_warning",
                    event_type=EventType.MEMORY_WARNING,
                    title=f"内存使用过高: {mem.percent:.1f}%",
                    message=f"已用 {mem.used//(1024**3)}GB / 总共 {mem.total//(1024**3)}GB",
                    source="system",
                    priority=4,
                    metadata={"percent": round(mem.percent, 1)}
                ))
        except ImportError:
            pass
        except Exception:
            pass

    def _check_cpu(self):
        try:
            import psutil
            percent = psutil.cpu_percent(interval=2)
            if percent > self.cpu_warning_threshold and self._can_alert("cpu"):
                self._callback(Notification(
                    notify_id="cpu_warning",
                    event_type=EventType.CPU_WARNING,
                    title=f"CPU使用过高: {percent:.1f}%",
                    message="持续高负载，可能影响系统响应速度",
                    source="system",
                    priority=3,
                    metadata={"percent": round(percent, 1)}
                ))
        except ImportError:
            pass
        except Exception:
            pass

    def _can_alert(self, key: str) -> bool:
        now = datetime.now()
        last = self._last_alerts.get(key, "")
        if last:
            try:
                if (now - datetime.fromisoformat(last)).total_seconds() < self._alert_cooldown:
                    return False
            except Exception:
                pass
        self._last_alerts[key] = now.isoformat()
        return True


# ============================================================
# 提醒管理器
# ============================================================

class ReminderManager:
    """定时提醒管理器"""

    def __init__(self):
        self._reminders: Dict[str, Reminder] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable[[Notification], None]] = None
        self._load()

    def add_reminder(self, message: str, minutes: int = 0, hours: int = 0,
                     seconds: int = 0, at_time: str = None, repeat: str = "") -> Reminder:
        reminder_id = f"rem_{hashlib.md5(message.encode()).hexdigest()[:8]}"
        if at_time:
            today = datetime.now()
            h, m = map(int, at_time.split(":"))
            trigger = today.replace(hour=h, minute=m, second=0)
            if trigger <= today:
                trigger += timedelta(days=1)
            trigger_time = trigger.isoformat()
        else:
            total_seconds = hours * 3600 + minutes * 60 + seconds
            trigger_time = (datetime.now() + timedelta(seconds=total_seconds)).isoformat()
        reminder = Reminder(
            reminder_id=reminder_id,
            message=message,
            trigger_time=trigger_time,
            repeat=repeat,
        )
        self._reminders[reminder_id] = reminder
        self._save()
        return reminder

    def remove_reminder(self, reminder_id: str):
        self._reminders.pop(reminder_id, None)
        self._save()

    def list_reminders(self) -> List[Dict]:
        now = datetime.now().isoformat()
        return [
            {
                "id": r.reminder_id,
                "message": r.message,
                "trigger_time": r.trigger_time,
                "is_past": r.trigger_time < now,
                "repeat": r.repeat,
                "triggered_count": r.triggered_count,
            }
            for r in self._reminders.values() if r.enabled
        ]

    def start(self, callback: Callable[[Notification], None]):
        self._callback = callback
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="reminders")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self):
        while self._running:
            now = datetime.now()
            for reminder in list(self._reminders.values()):
                if not reminder.enabled:
                    continue
                try:
                    trigger = datetime.fromisoformat(reminder.trigger_time)
                    if now >= trigger:
                        self._callback(Notification(
                            notify_id=reminder.reminder_id,
                            event_type=EventType.REMINDER,
                            title="提醒",
                            message=reminder.message,
                            source="reminder",
                            priority=2,
                        ))
                        reminder.triggered_count += 1
                        reminder.last_triggered = now.isoformat()
                        if reminder.repeat == "hourly":
                            reminder.trigger_time = (trigger + timedelta(hours=1)).isoformat()
                        elif reminder.repeat == "daily":
                            reminder.trigger_time = (trigger + timedelta(days=1)).isoformat()
                        elif reminder.repeat == "weekly":
                            reminder.trigger_time = (trigger + timedelta(weeks=1)).isoformat()
                        else:
                            reminder.enabled = False
                        self._save()
                except Exception:
                    pass
            time.sleep(10)

    def _save(self):
        try:
            data = [
                {
                    "reminder_id": r.reminder_id, "message": r.message,
                    "trigger_time": r.trigger_time, "repeat": r.repeat,
                    "enabled": r.enabled, "triggered_count": r.triggered_count,
                    "last_triggered": r.last_triggered, "created_at": r.created_at,
                }
                for r in self._reminders.values()
            ]
            with open(REMINDERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load(self):
        if REMINDERS_FILE.exists():
            try:
                with open(REMINDERS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for d in data:
                    r = Reminder(**{k: v for k, v in d.items() if k in Reminder.__dataclass_fields__})
                    if r.enabled and not r.repeat:
                        try:
                            if datetime.fromisoformat(r.trigger_time) < datetime.now():
                                continue
                        except Exception:
                            pass
                    self._reminders[r.reminder_id] = r
            except Exception:
                pass


# ============================================================
# 通知发送器
# ============================================================

class NotificationSender:
    """通知发送器，支持Toast和回调"""

    def __init__(self, voice_callback: Callable[[str], None] = None):
        self.voice_callback = voice_callback
        self._history: List[Dict] = []
        self._load_history()

    def send(self, notification: Notification):
        self._send_toast(notification)
        if self.voice_callback and notification.priority >= 2:
            try:
                self.voice_callback(f"{notification.title}。{notification.message}")
            except Exception:
                pass
        self._log(notification)

    def _send_toast(self, notification: Notification):
        try:
            # 安全处理：限制长度并移除危险字符
            title = notification.title.replace('"', "'").replace('\n', ' ')[:100]
            message = notification.message.replace('"', "'").replace('\n', ' ')[:200]
            
            # 使用 -EncodedCommand 防止注入攻击
            import base64
            ps_template = '''
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent(0)
$text = $template.GetElementsByTagName('text')
$text.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$text.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('AlertMaster').Show($toast)
'''
            ps_script = ps_template.format(title=title, message=message)
            encoded_cmd = base64.b64encode(ps_script.encode('utf-16-le')).decode('ascii')
            
            subprocess.Popen(
                ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded_cmd],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except Exception:
            pass

    def _log(self, notification: Notification):
        self._history.append(notification.to_dict())
        if len(self._history) > 200:
            self._history = self._history[-200:]
        try:
            with open(NOTIFICATION_LOG, 'w', encoding='utf-8') as f:
                json.dump(self._history, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_history(self):
        if NOTIFICATION_LOG.exists():
            try:
                with open(NOTIFICATION_LOG, 'r', encoding='utf-8') as f:
                    self._history = json.load(f)
            except Exception:
                self._history = []

    def get_history(self, limit: int = 20, source: str = None) -> List[Dict]:
        history = self._history
        if source:
            history = [h for h in history if h.get("source") == source]
        return history[-limit:]


# ============================================================
# 规则引擎
# ============================================================

class RuleEngine:
    """条件触发规则引擎"""

    def __init__(self):
        self._rules: Dict[str, NotifyRule] = {}
        self._load()

    def add_rule(self, rule: NotifyRule):
        self._rules[rule.rule_id] = rule
        self._save()

    def remove_rule(self, rule_id: str):
        self._rules.pop(rule_id, None)
        self._save()

    def evaluate(self, notification: Notification) -> Optional[Notification]:
        if notification.event_type not in (
            EventType.FILE_CREATED, EventType.FILE_MODIFIED, EventType.FILE_DELETED,
        ):
            return None
        for rule in self._rules.values():
            if not rule.enabled:
                continue
            if rule.last_triggered:
                try:
                    if (datetime.now() - datetime.fromisoformat(rule.last_triggered)).total_seconds() < rule.cooldown_seconds:
                        continue
                except Exception:
                    pass
            if rule.directory:
                if not notification.metadata.get("path", "").startswith(rule.directory):
                    continue
            if self._evaluate_condition(rule.condition, notification):
                rule.last_triggered = datetime.now().isoformat()
                self._save()
                return Notification(
                    notify_id=f"rule_{rule.rule_id}",
                    event_type=EventType.RULE_TRIGGERED,
                    title=f"规则触发: {rule.name}",
                    message=self._fill_template(rule.message_template, notification),
                    source="rule",
                    priority=3,
                    metadata={"rule_name": rule.name, "original": notification.to_dict()}
                )
        return None

    def _evaluate_condition(self, condition: str, notification: Notification) -> bool:
        size_mb = notification.metadata.get("size_mb", 0)
        filename = Path(notification.metadata.get("path", "")).name
        try:
            size_match = re.match(r'file_size\s*([><=!]+)\s*([\d.]+)', condition)
            if size_match:
                return self._compare(size_mb, size_match.group(1), float(size_match.group(2)))
            ext_match = re.match(r'ext\s*([=!]=?)\s*(\S+)', condition)
            if ext_match:
                actual_ext = Path(filename).suffix.lower()
                return actual_ext == ext_match.group(2).lower()
            name_match = re.match(r'name\s+contains\s+(.+)', condition)
            if name_match:
                return name_match.group(1).strip().lower() in filename.lower()
        except Exception:
            pass
        return False

    def _compare(self, a, op, b) -> bool:
        if op == ">": return a > b
        if op == ">=": return a >= b
        if op == "<": return a < b
        if op == "<=": return a <= b
        if op in ("==", "="): return a == b
        if op == "!=": return a != b
        return False

    def _fill_template(self, template: str, notification: Notification) -> str:
        m = notification.metadata
        filename = Path(m.get("path", "")).name
        size_mb = m.get("size_mb", 0)
        replacements = {
            "{filename}": filename, "{name}": filename,
            "{path}": m.get("path", ""), "{size}": f"{size_mb:.1f}MB",
            "{size_mb}": str(round(size_mb, 1)), "{ext}": Path(filename).suffix,
            "{label}": m.get("label", ""), "{time}": datetime.now().strftime("%H:%M:%S"),
        }
        result = template
        for k, v in replacements.items():
            result = result.replace(k, str(v))
        return result

    def list_rules(self) -> List[Dict]:
        return [
            {"id": r.rule_id, "name": r.name, "condition": r.condition,
             "directory": r.directory, "enabled": r.enabled, "last_triggered": r.last_triggered}
            for r in self._rules.values()
        ]

    def _save(self):
        try:
            data = [
                {"rule_id": r.rule_id, "name": r.name, "condition": r.condition,
                 "directory": r.directory, "message_template": r.message_template,
                 "cooldown_seconds": r.cooldown_seconds, "last_triggered": r.last_triggered,
                 "enabled": r.enabled, "created_at": r.created_at}
                for r in self._rules.values()
            ]
            with open(RULES_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load(self):
        if RULES_FILE.exists():
            try:
                with open(RULES_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for d in data:
                    r = NotifyRule(**{k: v for k, v in d.items() if k in NotifyRule.__dataclass_fields__})
                    self._rules[r.rule_id] = r
            except Exception:
                pass


# ============================================================
# AlertMaster 核心类
# ============================================================

class AlertMaster:
    """
    主动通知指挥官 — 商城版主类

    用法:
        from alert_master import AlertMaster

        am = AlertMaster()

        # 添加目录监控
        am.watch_directory(r"C:\\Users\\Admin\\Downloads", label="下载")

        # 添加定时提醒
        am.add_reminder("起来活动一下", minutes=30)

        # 添加条件规则
        am.add_rule(
            name="大文件检测",
            condition="file_size > 500",
            directory=r"C:\\Users\\Admin\\Downloads",
            message_template="大文件下载完成: {filename} ({size})"
        )

        # 启动
        am.start()
    """

    def __init__(self, on_notify: Callable[[Notification], None] = None,
                 voice_callback: Callable[[str], None] = None):
        self.fs_watcher = FileSystemWatcher(scan_interval=3.0)
        self.sys_monitor = SystemMonitor(check_interval=120.0)
        self.reminder_mgr = ReminderManager()
        self.rule_engine = RuleEngine()
        self.sender = NotificationSender(voice_callback=voice_callback)
        self._on_notify = on_notify
        self._notify_queue: queue.Queue = queue.Queue()
        self._running = False

    def watch_directory(self, directory: str, label: str = "",
                        patterns: List[str] = None, recursive: bool = True,
                        exclude: List[str] = None) -> str:
        """添加目录监控"""
        watch_id = f"w_{hashlib.md5(directory.encode()).hexdigest()[:8]}"
        config = WatchConfig(
            watch_id=watch_id, directory=directory, label=label,
            patterns=patterns or ["*"], recursive=recursive,
            exclude_patterns=exclude or [],
        )
        self.fs_watcher.add_watch(config)
        return watch_id

    def unwatch_directory(self, watch_id: str):
        """移除目录监控"""
        self.fs_watcher.remove_watch(watch_id)

    def add_reminder(self, message: str, minutes: int = 0, hours: int = 0,
                     seconds: int = 0, at_time: str = None, repeat: str = "") -> Reminder:
        """添加定时提醒"""
        return self.reminder_mgr.add_reminder(message, minutes=minutes, hours=hours,
                                              seconds=seconds, at_time=at_time, repeat=repeat)

    def add_rule(self, name: str, condition: str, directory: str,
                 message_template: str, cooldown_seconds: int = 300) -> str:
        """添加通知规则"""
        rule_id = f"rule_{hashlib.md5(name.encode()).hexdigest()[:8]}"
        rule = NotifyRule(
            rule_id=rule_id, name=name, condition=condition,
            directory=directory, message_template=message_template,
            cooldown_seconds=cooldown_seconds,
        )
        self.rule_engine.add_rule(rule)
        return rule_id

    def send_custom_notification(self, title: str, message: str,
                                 priority: int = 2, source: str = "custom"):
        """发送自定义通知"""
        notification = Notification(
            notify_id=f"custom_{hashlib.md5(message.encode()).hexdigest()[:8]}",
            event_type=EventType.CUSTOM, title=title, message=message,
            source=source, priority=priority,
        )
        self._notify_queue.put(notification)

    def start(self):
        """启动所有子系统"""
        if self._running:
            return
        self._running = True
        self.fs_watcher.start(callback=self._on_fs_event)
        self.sys_monitor.start(callback=self._dispatch)
        self.reminder_mgr.start(callback=self._dispatch)
        threading.Thread(target=self._process_queue, daemon=True, name="notify-dispatch").start()

    def stop(self):
        """停止所有子系统"""
        self._running = False
        self.fs_watcher.stop()
        self.sys_monitor.stop()
        self.reminder_mgr.stop()

    def _on_fs_event(self, notification: Notification):
        rule_n = self.rule_engine.evaluate(notification)
        if rule_n:
            self._dispatch(rule_n)
        elif notification.priority >= 2:
            self._dispatch(notification)

    def _dispatch(self, notification: Notification):
        self._notify_queue.put(notification)

    def _process_queue(self):
        while self._running:
            try:
                notification = self._notify_queue.get(timeout=1)
                self.sender.send(notification)
                if self._on_notify:
                    try:
                        self._on_notify(notification)
                    except Exception:
                        pass
            except queue.Empty:
                continue
            except Exception:
                pass

    def get_watch_status(self) -> List[Dict]:
        return [
            {"id": w.watch_id, "directory": w.directory, "label": w.label,
             "patterns": w.patterns, "recursive": w.recursive, "enabled": w.enabled}
            for w in self.fs_watcher._watch_configs.values()
        ]

    def get_reminders(self) -> List[Dict]:
        return self.reminder_mgr.list_reminders()

    def get_rules(self) -> List[Dict]:
        return self.rule_engine.list_rules()

    def get_notification_history(self, limit: int = 20) -> List[Dict]:
        return self.sender.get_history(limit)

    def get_stats(self) -> Dict:
        return {
            "active_watches": len(self.fs_watcher._watch_configs),
            "active_reminders": len(self.reminder_mgr._reminders),
            "active_rules": len(self.rule_engine._rules),
            "notifications_sent": len(self.sender._history),
            "running": self._running,
        }


# ============================================================
# 快速使用
# ============================================================

def quick_alert(title: str, message: str):
    """发送快速通知"""
    am = AlertMaster()
    am.send_custom_notification(title, message)
    am.sender.send(Notification(
        notify_id=f"quick_{hashlib.md5(message.encode()).hexdigest()[:8]}",
        title=title, message=message, source="quick",
    ))
