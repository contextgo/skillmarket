---
name: alert-master
version: 1.0.0
author: 玲瑶
description: |
  主动通知指挥官：让 AI 从被动响应进化到主动感知 + 通知。
  
  触发词：文件监控、目录监控、系统监控、主动提醒、定时提醒、
  CPU告警、内存告警、磁盘告警、规则引擎、条件触发、Toast通知、
  监控磁盘、监控文件、文件变化通知、自动提醒、文件告警、系统告警、
  主动通知、proactive notify、watch directory、file watch、
  监控目录、添加提醒、设置定时任务
  
  使用场景：
  - 下载监控：新文件出现时通知 AI 自动处理
  - 系统告警：磁盘/内存/CPU 超阈值时触发提醒
  - 定时提醒：喝水/吃药/会议提醒
  - 自动化流水线：代码编译完成、任务结束时触发后续动作
---

# AlertMaster 主动通知指挥官

## 能做什么

AlertMaster 是一个多源事件感知系统，让 AI 不再只是被动等待，而是主动感知环境变化并触发通知。

### 4 大感知能力

1. **文件监控** — 监控指定目录的文件新增/修改/删除/移动
2. **系统监控** — 磁盘空间、CPU/内存超阈值告警
3. **定时提醒** — 支持单次/每小时/每天/每周循环
4. **规则引擎** — 基于条件表达式触发（`file_size > 500MB`、`ext == .exe`）

### 2 种通知渠道

- **Windows Toast** — 系统原生弹窗通知
- **回调函数** — 自定义处理逻辑（集成到 AI 流水线）

## 快速使用

```python
from alert_master import AlertMaster

def my_handler(event):
    print(f"[通知] {event.message}")

alert = AlertMaster(on_notify=my_handler)

# 1. 监控下载目录
alert.watch_directory(r"C:\Users\你\Downloads", label="下载目录")

# 2. 30 分钟后提醒喝水
alert.add_reminder("喝水提醒", minutes=30)

# 3. 添加规则：大文件出现时告警
alert.add_rule(
    name="大文件检测",
    condition="file_size > 100",  # MB
    directory=r"C:\Users\你\Downloads",
    message="检测到大文件: {filename} ({size}MB)"
)

# 4. 启动（后台线程）
alert.start()

# 5. 停止
alert.stop()
```

## 规则条件语法

| 条件 | 说明 |
|------|------|
| `file_size > 100` | 文件大于 100MB |
| `ext == .exe` | 后缀为 .exe |
| `name contains 重要` | 文件名含关键词 |
| `cpu > 90` | CPU 占用超 90% |
| `disk < 10` | 磁盘剩余不足 10GB |

## 依赖

- Python 3.8+
- `psutil`（系统监控）— `pip install psutil`
- `watchdog`（文件监控，可选）— `pip install watchdog`
- Windows 系统（Toast通知）
