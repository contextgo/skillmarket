# AlertMaster 主动通知指挥官

> 让AI从被动响应进化到主动感知 + 即时通知

## 核心功能

### 1. 文件监控
- 监控指定目录的文件变化（新增/修改/删除）
- 支持大小过滤：`min_size_mb` / `max_size_mb`
- 排除模式：过滤临时文件、缓存文件
- 递归/非递归子目录监控

### 2. 系统监控
- 磁盘空间告警（剩余 < 10% 时提醒）
- 内存使用告警（使用 > 90% 时提醒）
- CPU使用告警（持续高负载时提醒）
- 1小时冷却，防止重复告警

### 3. 定时提醒
- 单次提醒：X分钟后/X小时后/指定时间
- 循环提醒：每小时/每天/每周
- 持久化存储，重启不丢失
- 触发次数统计

### 4. 规则引擎
- 条件表达式触发：
  - `file_size > 500` — 大文件检测
  - `ext == .exe` — 可执行文件检测
  - `name contains 关键词` — 关键字匹配
- 消息模板变量：`{filename}`、`{size}`、`{path}`、`{time}`
- 冷却时间控制

### 5. 双通道通知
- Windows Toast 原生通知
- 语音播报回调（可集成TTS）

## 安装

```bash
pip install psutil  # 可选，用于系统监控
pip install -r requirements.txt
```

## 快速使用

```python
from alert_master import AlertMaster

# 初始化
am = AlertMaster()

# 添加目录监控
am.watch_directory(
    r"C:\Users\Admin\Downloads",
    label="下载目录",
    patterns=["*.exe", "*.zip"],
    exclude=["temp"]
)

# 添加定时提醒
am.add_reminder("起来活动一下", minutes=30)
am.add_reminder("每天提醒", at_time="09:00", repeat="daily")

# 添加规则
am.add_rule(
    name="大文件检测",
    condition="file_size > 500",
    directory=r"C:\Users\Admin\Downloads",
    message_template="大文件下载完成: {filename} ({size})",
    cooldown_seconds=600
)

# 发送自定义通知
am.send_custom_notification("标题", "内容", priority=3)

# 启动监控
am.start()

# 查询状态
stats = am.get_stats()
print(f"监控数: {stats['active_watches']}, 提醒数: {stats['active_reminders']}")

# 停止
am.stop()
```

## 预设规则示例

```python
from alert_master import setup_presets, ProactiveNotifier

notifier = ProactiveNotifier()
setup_presets(notifier)
notifier.start()
```

## 适用场景

- 下载完成提醒
- 文件变化监控
- 系统资源告警
- 定时任务提醒
- 自动化工作流触发
- 服务器监控告警

## 与其他方案的区别

| 功能 | 单一监控工具 | AlertMaster |
|------|------------|-------------|
| 文件监控 | 仅支持 | 多模式+规则引擎 |
| 系统监控 | 无 | 磁盘/内存/CPU |
| 定时提醒 | 仅支持 | 多周期+持久化 |
| 条件触发 | 无 | 完整规则引擎 |
| 通知渠道 | 单一 | Toast+语音双通道 |

## API 参考

### AlertMaster

| 方法 | 说明 |
|------|------|
| `watch_directory()` | 添加目录监控 |
| `add_reminder()` | 添加定时提醒 |
| `add_rule()` | 添加通知规则 |
| `send_custom_notification()` | 发送自定义通知 |
| `get_stats()` | 获取统计信息 |
| `get_notification_history()` | 获取通知历史 |

### Notification 对象

```python
@dataclass
class Notification:
    notify_id: str
    event_type: EventType
    title: str
    message: str
    source: str       # filesystem/system/reminder/rule/custom
    priority: int     # 1=低 2=正常 3=高 4=紧急
    timestamp: str
    metadata: Dict    # 额外数据
```

## 技术细节

- 依赖：Python 3.8+，psutil（可选）
- 原生实现，无需外部服务
- 线程安全，支持多实例
- 数据持久化：JSON文件

## License

MIT License
