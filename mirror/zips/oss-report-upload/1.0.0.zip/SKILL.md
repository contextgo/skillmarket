---
name: oss-report-upload
description: 电商日报自动上传OSS。触发场景：用户说「处理数据并上传OSS」「上传拼多多/抖音/京东/天猫数据」「处理拼多多/抖音/京东/天猫数据」。支持四个平台：拼多多(pdd)、抖音(dy)、京东(jd)、天猫(tm)。
---

# 电商日报OSS上传技能

自动化处理拼多多、抖音、京东、天猫四个平台的日报文件上传到阿里云OSS。

## 快速使用

```bash
# 单平台
python scripts/upload_reports.py pdd
python scripts/upload_reports.py dy
python scripts/upload_reports.py jd
python scripts/upload_reports.py tm

# 全部平台（并行推荐）
python scripts/upload_reports.py all
```

## 四平台流程规则

### 拼多多 (pdd)

**触发词**: 「处理拼多多数据」「上传拼多多」「处理数据」

1. **检查文件日期**
   - 扫描 `Desktop\拼多多日报下载文件` 下所有 xlsx/xls
   - 若所有文件修改日期 = 今天 → 继续
   - 若有文件不是今天 → **微信通知用户更新**，终止

2. **上传OSS**
   - 路径：`oss://for-e-commerce/拼多多源数据/{昨天日期}/`
   - 保留子目录层级（单品/、品类/、店铺/）
   - 不转格式，直接上传
   - 覆盖同名文件

### 抖音 (dy)

**触发词**: 「处理抖音数据」「上传抖音」

1. **检查文件日期**
   - 扫描 `Desktop\抖音日报下载文件` 下所有文件
   - 规则同拼多多

2. **上传OSS**
   - 路径：`oss://for-e-commerce/抖音源数据/{昨天日期}/`
   - 保留子目录层级（全店铺/、快手/、直营/）
   - 不转格式（快手是.xls，其他.xlsx）

### 京东 (jd)

**触发词**: 「处理京东数据」「上传京东」

**特殊规则**：不检查日期，直接处理

1. **ZIP解压**
   - 扫描 `Desktop\京东日报下载文件` 下所有 ZIP
   - 解压为 XLSX，**保留ZIP内部原始文件名**
   - **已存在同名XLSX → 直接覆盖**
   - 解压后删除 ZIP
   - 已存在 XLSX（无对应ZIP）→ 直接用

2. **上传OSS**
   - 路径：`oss://for-e-commerce/京东源数据/{昨天日期}/`
   - 保留子目录层级（品类/、店铺/、财务/）

### 天猫 (tm)

**触发词**: 「处理天猫数据」「上传天猫」

1. **检查文件日期**
   - 扫描 `Desktop\天猫日报下载文件` 下所有 xls/xlsx
   - 规则同拼多多

2. **上传OSS**
   - 路径：`oss://for-e-commerce/天猫源数据/{昨天日期}/`
   - 保留子目录层级（单品/天猫/、单品/猫超/、单品/阿里/、品类/、店铺/天猫/、店铺/猫超/、店铺/阿里/）
   - **不转格式**：单品/天猫/是.xls，其他按原格式

## 技术要点

### Windows路径问题（必读）

Windows 上 `os.path.relpath()` 返回反斜杠路径（如 `单品\天猫`），OSS无法识别。

**必须替换**：
```python
rel_dir = os.path.relpath(root, LOCAL_BASE).replace('\\', '/')
```

### OSS凭据

凭据保存在：`~/.qclaw/workspace-agent-ef84ca41/OSS_CREDENTIALS.py`

脚本自动加载，无需手动输入。

### 日期计算

所有平台使用 **昨天的日期**：
```python
yesterday = (datetime.date.today() - datetime.timedelta(days=1)).isoformat()
```

## 用户偏好

- 输出结构：**结论 → 原因 → bullet points**
- 不说正确的废话
- 简洁直接
