"""
AIB2B 助手 - 自动验证与记忆保存

每轮对话后自动执行：
1. 提取关键信息
2. 联网搜索验证
3. 检查冲突
4. 保存记忆
5. 生成纠偏建议
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

# 记忆目录
MEMORY_DIR = Path.home() / ".qclaw" / "workspace" / "memory"

def ensure_memory_dirs():
    """确保记忆目录存在"""
    dirs = ["business", "leads", "proposals", "communications", "insights"]
    for d in dirs:
        (MEMORY_DIR / d).mkdir(parents=True, exist_ok=True)

def save_memory(category: str, topic: str, content: dict):
    """保存记忆"""
    ensure_memory_dirs()
    
    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"{topic.replace('/', '-')}.md"
    filepath = MEMORY_DIR / category / filename
    
    # 生成markdown内容
    md_content = f"""# {topic}

日期: {date_str}

"""
    for key, value in content.items():
        if isinstance(value, list):
            md_content += f"\n## {key}\n"
            for item in value:
                md_content += f"- {item}\n"
        else:
            md_content += f"\n## {key}\n{value}\n"
    
    filepath.write_text(md_content, encoding="utf-8")
    return str(filepath)

def load_memory(category: str, topic: str = None):
    """加载记忆"""
    ensure_memory_dirs()
    
    dir_path = MEMORY_DIR / category
    
    if topic:
        filename = f"{topic.replace('/', '-')}.md"
        filepath = dir_path / filename
        if filepath.exists():
            return filepath.read_text(encoding="utf-8")
        return None
    
    # 返回该类别所有记忆
    memories = {}
    for filepath in dir_path.glob("*.md"):
        memories[filepath.stem] = filepath.read_text(encoding="utf-8")
    return memories

def search_and_validate(keywords: list):
    """
    联网搜索验证
    返回搜索结果供AI分析
    """
    import urllib.request
    import urllib.parse
    
    results = []
    for keyword in keywords:
        try:
            # 调用本地搜索服务
            url = f"http://127.0.0.1:19000/proxy/prosearch/search"
            data = json.dumps({"keyword": keyword}).encode()
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            resp = urllib.request.urlopen(req, timeout=10)
            result = json.loads(resp.read().decode())
            results.append({"keyword": keyword, "result": result})
        except Exception as e:
            results.append({"keyword": keyword, "error": str(e)})
    
    return results

def check_conflicts(new_info: dict, category: str):
    """
    检查新信息与记忆的冲突
    """
    existing = load_memory(category)
    conflicts = []
    
    if existing:
        for topic, content in existing.items():
            # 简单的关键词冲突检测
            # 实际应用中可以用更复杂的逻辑
            pass
    
    return conflicts

def generate_alerts(search_results: list, conflicts: list):
    """
    生成提醒和纠偏建议
    """
    alerts = []
    
    for result in search_results:
        if "result" in result and result["result"].get("docs"):
            # 有搜索结果，可以生成提醒
            docs = result["result"]["docs"][:3]
            for doc in docs:
                alerts.append({
                    "type": "new_info",
                    "keyword": result["keyword"],
                    "title": doc.get("title"),
                    "url": doc.get("url"),
                    "message": f"关于'{result['keyword']}'，我查到：{doc.get('title')}"
                })
    
    for conflict in conflicts:
        alerts.append({
            "type": "conflict",
            "message": f"发现冲突：{conflict}"
        })
    
    return alerts

def main():
    """主函数 - 用于测试"""
    ensure_memory_dirs()
    print(f"记忆目录: {MEMORY_DIR}")
    print(f"子目录: business, leads, proposals, communications, insights")

if __name__ == "__main__":
    main()
