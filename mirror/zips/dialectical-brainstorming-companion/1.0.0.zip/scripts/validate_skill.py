#!/usr/bin/env python3
"""Local validator for the dialectical-brainstorming-companion skill package."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


REQUIRED_DIRS = [
    "references",
    "templates",
    "examples",
    "tests",
    "agent_profiles",
    "scripts",
]

REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "references/thinking_modes.md",
    "references/critical_thinking_checklist.md",
    "references/argument_diagnostics.md",
    "references/education_music_perspectives.md",
    "references/socratic_questions.md",
    "references/devil_advocate_mode.md",
    "references/writing_reconstruction.md",
    "templates/quick_response_template.md",
    "templates/standard_analysis_template.md",
    "templates/deep_analysis_template.md",
    "templates/dialogue_mode_template.md",
    "templates/argument_map_template.md",
    "templates/expression_rewrite_template.md",
    "examples/example_music_education_insight.md",
    "examples/example_ai_education_argument.md",
    "examples/example_public_expression_review.md",
    "examples/example_socratic_dialogue.md",
    "tests/sample_inputs.md",
    "tests/expected_output_checklist.md",
    "agent_profiles/qclaw_wechat_thinking_companion.md",
    "agent_profiles/workbuddy_yuanbao_writing_companion.md",
    "scripts/validate_skill.py",
    "scripts/package_skill.py",
]

FRONTMATTER_KEY_RE = re.compile(r"^[a-z][a-z0-9_-]*:\s*.+$")
KEBAB_CASE_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
DANGEROUS_CONTENT_PATTERNS = {
    "api_key_assignment": re.compile(r"api[_ -]?key\s*[:=]\s*['\"][^'\"]+['\"]", re.IGNORECASE),
    "secret_assignment": re.compile(r"(secret|client_secret)\s*[:=]\s*['\"][^'\"]+['\"]", re.IGNORECASE),
    "token_assignment": re.compile(r"(access_token|refresh_token|auth_token|token)\s*[:=]\s*['\"][^'\"]+['\"]", re.IGNORECASE),
    "cookie_assignment": re.compile(r"cookie\s*[:=]\s*['\"][^'\"]+['\"]", re.IGNORECASE),
    "base_url_assignment": re.compile(r"base_url\s*[:=]\s*['\"][^'\"]+['\"]", re.IGNORECASE),
    "bearer_token": re.compile(r"bearer\s+[a-z0-9._-]{16,}", re.IGNORECASE),
    "sk_token": re.compile(r"sk-[a-z0-9]{16,}", re.IGNORECASE),
}
REMOTE_DOWNLOAD_PATTERNS = {
    "curl_remote": re.compile(r"\bcurl\b.+https?://", re.IGNORECASE),
    "wget_remote": re.compile(r"\bwget\b.+https?://", re.IGNORECASE),
    "requests_remote": re.compile(r"requests\.(get|post)\(['\"]https?://", re.IGNORECASE),
    "urllib_remote": re.compile(r"urllib\.(request|parse).+https?://", re.IGNORECASE),
}
SHELL_INJECTION_PATTERNS = {
    "shell_true": re.compile(r"shell\s*=\s*True"),
    "os_system": re.compile(r"\bos\.system\s*\("),
    "subprocess_shell_true": re.compile(r"subprocess\.(run|Popen|call|check_call|check_output)\([^)]*shell\s*=\s*True"),
    "eval_call": re.compile(r"\beval\s*\("),
    "exec_call": re.compile(r"\bexec\s*\("),
}
TEXT_SUFFIXES = {
    ".md",
    ".py",
    ".txt",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
}


def parse_frontmatter(skill_file: Path) -> tuple[dict[str, str], list[str]]:
    errors: list[str] = []
    lines = skill_file.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        return {}, ["SKILL.md is missing YAML frontmatter."]

    closing_index = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            closing_index = index
            break
    if closing_index is None:
        return {}, ["SKILL.md frontmatter is not closed with '---'."]

    frontmatter_lines = lines[1:closing_index]
    if not frontmatter_lines:
        return {}, ["SKILL.md frontmatter is empty."]

    data: dict[str, str] = {}
    for line in frontmatter_lines:
        if not FRONTMATTER_KEY_RE.match(line):
            errors.append(f"Invalid frontmatter line: {line}")
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()

    allowed_keys = {"name", "description"}
    actual_keys = set(data)
    missing = allowed_keys - actual_keys
    extra = actual_keys - allowed_keys
    if missing:
        errors.append(f"Frontmatter missing required keys: {', '.join(sorted(missing))}")
    if extra:
        errors.append(f"Frontmatter contains unsupported keys: {', '.join(sorted(extra))}")
    return data, errors


def iter_text_files(root: Path):
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if path.name.startswith(".") and path.name != ".skill":
            continue
        if path.suffix.lower() in TEXT_SUFFIXES or path.name == "SKILL.md" or path.name == "README.md":
            yield path


def validate_skill_root(root: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not root.exists():
        return [f"Skill root does not exist: {root}"], warnings
    if not root.is_dir():
        return [f"Skill root is not a directory: {root}"], warnings

    for required_dir in REQUIRED_DIRS:
        path = root / required_dir
        if not path.is_dir():
            errors.append(f"Missing required directory: {required_dir}")

    for required_file in REQUIRED_FILES:
        path = root / required_file
        if not path.is_file():
            errors.append(f"Missing required file: {required_file}")

    skill_file = root / "SKILL.md"
    if skill_file.is_file():
        frontmatter, frontmatter_errors = parse_frontmatter(skill_file)
        errors.extend(frontmatter_errors)
        if frontmatter:
            name = frontmatter.get("name", "")
            if name and not KEBAB_CASE_RE.fullmatch(name):
                errors.append("Frontmatter name is not valid kebab-case.")
            if name and name != "dialectical-brainstorming-companion":
                warnings.append("Frontmatter name differs from the requested canonical skill name.")
            description = frontmatter.get("description", "")
            if not description:
                errors.append("Frontmatter description is empty.")

    for path in root.rglob("*"):
        if path.is_symlink():
            errors.append(f"Symlink is not allowed: {path.relative_to(root)}")

    for text_file in iter_text_files(root):
        content = text_file.read_text(encoding="utf-8", errors="ignore")
        relative = text_file.relative_to(root)
        for label, pattern in DANGEROUS_CONTENT_PATTERNS.items():
            if pattern.search(content):
                errors.append(f"Suspicious credential-like content ({label}) found in {relative}")
        for label, pattern in REMOTE_DOWNLOAD_PATTERNS.items():
            if pattern.search(content):
                errors.append(f"Remote download pattern ({label}) found in {relative}")

    for script_path in (root / "scripts").glob("*.py"):
        content = script_path.read_text(encoding="utf-8", errors="ignore")
        relative = script_path.relative_to(root)
        for label, pattern in SHELL_INJECTION_PATTERNS.items():
            if pattern.search(content):
                errors.append(f"Shell injection risk ({label}) found in {relative}")

    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a local skill package.")
    parser.add_argument(
        "path",
        nargs="?",
        default=Path(__file__).resolve().parents[1],
        type=Path,
        help="Path to the skill root. Defaults to the parent folder of this script.",
    )
    args = parser.parse_args()
    root = args.path.resolve()

    errors, warnings = validate_skill_root(root)
    print(f"Validating: {root}")
    if not errors:
        print("[OK] No blocking issues found.")
    else:
        print("[FAIL] Blocking issues found:")
        for item in errors:
            print(f"  - {item}")

    if warnings:
        print("[WARN] Non-blocking notes:")
        for item in warnings:
            print(f"  - {item}")

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
