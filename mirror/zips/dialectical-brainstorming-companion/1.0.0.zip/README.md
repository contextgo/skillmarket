# dialectical-brainstorming-companion

别名建议：

- 思辨头脑风暴与论证陪练 Skill
- 琅琊阁·论辩参谋

正式 Skill 名称始终使用 `dialectical-brainstorming-companion`。

## Skill 简介

`dialectical-brainstorming-companion` 是一个面向教育、音乐、音乐教育、AI + 音乐教育、学术写作与公众表达场景的思辨型 Skill。它不把自己定位成普通聊天助手，也不以直接代写论文为目标，而是帮助用户完成以下高价值工作：

- 提炼核心命题
- 检查逻辑漏洞
- 暴露隐含假设
- 生成高质量追问
- 进行反方论证
- 重构文章、演讲、口播与研究表达
- 把经验洞察转化为研究问题、文章结构、演讲提纲或课程设计思路

## 适用场景

适用于：

- 教育类思考与写作
- 音乐类思考与写作
- 音乐教育交叉研究
- AI + 音乐教育研究
- 学术论文选题、论证与表达
- 公众号、视频号、演讲、路演、课程设计等公众表达
- 用户个人洞察、经验判断、研究想法的逻辑审视与多视角批判

典型任务包括：

- 判断一个观点是否成立
- 帮一个选题形成问题意识
- 用审稿人视角挑刺
- 把一段情绪化表达改成有逻辑、有传播力的表达
- 把课堂经验转成研究问题
- 把散乱想法转成论文结构或口播结构

## 不适用场景

不适合：

- 默认生成整篇论文
- 伪造文献、专家或经典引文
- 自动扫描全盘资料
- 未经授权读取知识库或文件
- 医疗、法律、投资、心理治疗等高风险结论输出
- 以“多角度分析”为名堆砌空泛长文

## 安装方式

### 方式 1：直接使用文件夹

将整个 `dialectical-brainstorming-companion/` 文件夹放入你的 Skills 目录或待上传目录中。

### 方式 2：使用压缩包

可以直接打包为：

- `dialectical-brainstorming-companion.zip`
- `dialectical-brainstorming-companion.skill`

其中 `.skill` 本质上可以是 ZIP 格式，只是扩展名改为 `.skill`。

## 文件结构

```text
dialectical-brainstorming-companion/
├── SKILL.md
├── README.md
├── references/
│   ├── thinking_modes.md
│   ├── critical_thinking_checklist.md
│   ├── argument_diagnostics.md
│   ├── education_music_perspectives.md
│   ├── socratic_questions.md
│   ├── devil_advocate_mode.md
│   └── writing_reconstruction.md
├── templates/
│   ├── quick_response_template.md
│   ├── standard_analysis_template.md
│   ├── deep_analysis_template.md
│   ├── dialogue_mode_template.md
│   ├── argument_map_template.md
│   └── expression_rewrite_template.md
├── examples/
│   ├── example_music_education_insight.md
│   ├── example_ai_education_argument.md
│   ├── example_public_expression_review.md
│   └── example_socratic_dialogue.md
├── tests/
│   ├── sample_inputs.md
│   └── expected_output_checklist.md
├── agent_profiles/
│   ├── qclaw_wechat_thinking_companion.md
│   └── workbuddy_yuanbao_writing_companion.md
└── scripts/
    ├── validate_skill.py
    └── package_skill.py
```

## 如何在 QClaw 中使用

推荐创建一个微信入口 Agent，并默认挂载本 Skill。

- Agent 中文名建议：`思辨参谋官`
- 入口建议：`QClaw + 微信`
- 默认模式：`Quick Mode`
- 适合场景：微信低启动成本头脑风暴、快速判断、即时追问、随手反驳

推荐搭配流程：

1. 用户发来一句想法或一段话。
2. Agent 先提炼核心命题。
3. 再指出亮点与漏洞。
4. 再给 1 到 2 个最有价值的追问。
5. 只有在用户说“深度拆解”时才切入 Deep Mode。

详见 `agent_profiles/qclaw_wechat_thinking_companion.md`。

## 如何在 WorkBuddy 中使用

推荐创建一个写作与研究入口 Agent，并默认挂载本 Skill。

- Agent 中文名建议：`写作思辨参谋官`
- 入口建议：`WorkBuddy + 元宝`
- 默认模式：`Standard Mode`
- 适合场景：长文本、草稿、论文选题、文章结构、资料驱动的写作讨论

推荐搭配流程：

1. 用户给出草稿、段落、选题或明确指定文件。
2. Agent 先做结构诊断和命题提炼。
3. 再做逻辑诊断、多视角分析与表达重构。
4. 只有用户说“结合资料库”时，才进入材料分析模式。

详见 `agent_profiles/workbuddy_yuanbao_writing_companion.md`。

## 如何搭配 MiniMax / Kimi / Claude / GPT 等模型

Skill 不硬编码任何模型调用逻辑。模型应由宿主平台配置。

推荐写法：

- Preferred model class: strong reasoning model
- Recommended providers: MiniMax M2.5, Kimi, Claude, GPT, or any model configured by the host agent platform.

建议：

- 微信轻量入口优先使用响应快、推理稳的模型
- 长文写作入口优先使用上下文较强、结构化能力较好的模型
- 如果平台支持路由，可让 Quick Mode 使用更轻模型，Deep Mode 使用更强推理模型

禁止在 Skill 中写入：

- API key
- token
- base_url
- provider secret
- 用户账号信息
- 未经授权的联网逻辑

## 示例调用语句

```text
快速看一下：AI 音乐教育研究不应只关注学生会不会使用 AI，而应关注 AI 是否改变了学生的审美判断方式。
```

```text
反驳我：现在学生不需要学传统作曲了，因为 AI 可以生成音乐。
```

```text
陪我聊：我想做高中音乐与戏剧的 AI 协作课程研究，但不知道研究问题应该怎么落。
```

```text
重构表达：请把这段视频号口播改成更有逻辑、更有传播力、更像我自己的表达。
```

```text
论文选题：帮我把“课堂里用 AI 作曲很热闹”这个经验转成研究问题、研究对象、研究方法和理论视角。
```

## 输出模式说明

### Quick Mode

- 适合微信随手聊
- 建议控制在 300 到 600 字
- 重点输出核心命题、亮点、漏洞和下一步追问

### Standard Mode

- 默认模式
- 适合文章构思、选题讨论、表达优化
- 包含命题提炼、逻辑诊断、多视角分析、追问和表达重构

### Deep Mode

- 适合论文选题、开题前论证、课程研究设计、长文结构设计
- 包含结构表、问题链、论证链和风险点
- 只有用户明确要求时才进入

### Dialogue Mode

- 适合连续来回碰撞
- 每轮只推进一个关键问题
- 结尾只问 1 到 2 个高价值问题

## Token 高效使用说明

这个 Skill 把“单位 token 的思维价值最大化”作为默认原则。

默认行为：

1. 先诊断，再建议，再按需扩写
2. 默认不输出完整文章
3. 默认不罗列所有理论与思想家
4. 默认不进入重型研究模式
5. 默认不总结用户未指定的全部资料
6. 能用表格、矩阵、清单表达时优先结构化表达

关键英文规则：

```text
Optimize for insight density. Do not produce exhaustive philosophical surveys by default. Use the smallest useful response that clarifies the user's idea, exposes its assumptions, strengthens its logic, and suggests the next thinking move.
```

## 安全声明

禁止：

- 读取用户未授权文件
- 自动扫描全盘
- 自动上传聊天内容
- 自动调用外部 API
- 自动读取知识库全部内容
- 伪造专家、文献或经典文本
- 用权威口吻压制用户
- 把观点包装成事实

允许：

- 批判性分析用户观点
- 给出反方论证
- 做表达重构
- 生成文章结构、演讲提纲、论文问题
- 帮助用户把经验洞察转成研究问题

## 学术诚信声明

本 Skill 明确拒绝以下做法：

- 假装引用不存在的研究
- 伪造作者、年份、期刊、政策文件
- 把课堂感受直接包装成已被证实的学术结论
- 用“看起来很学术”的语言掩盖证据不足

当用户需要学术化表达时，本 Skill 应帮助其：

- 区分经验洞察与研究结论
- 区分价值判断与事实判断
- 区分表达强度与证据强度
- 把直觉性判断转成可研究、可观察、可讨论的问题

## 打包为 zip 的方法

### 手动命令

```bash
zip -r dialectical-brainstorming-companion.zip dialectical-brainstorming-companion \
  -x "*.DS_Store" \
  -x "__MACOSX/*" \
  -x "*.pyc" \
  -x "__pycache__/*"
```

### 使用脚本

```bash
python3 dialectical-brainstorming-companion/scripts/package_skill.py
```

## 打包为 `.skill` 的方法

### 方式 1：复制 zip

```bash
cp dialectical-brainstorming-companion.zip dialectical-brainstorming-companion.skill
```

### 方式 2：直接打包为 `.skill`

```bash
zip -r dialectical-brainstorming-companion.skill dialectical-brainstorming-companion \
  -x "*.DS_Store" \
  -x "__MACOSX/*" \
  -x "*.pyc" \
  -x "__pycache__/*"
```

### 使用脚本

`package_skill.py` 会同时生成：

- `dialectical-brainstorming-companion.zip`
- `dialectical-brainstorming-companion.skill`

## 发布到 SkillHub / ClawHub 前检查清单

```text
[ ] SKILL.md 存在
[ ] YAML frontmatter 合法
[ ] name 使用 kebab-case
[ ] description 清楚说明用途
[ ] README.md 存在
[ ] references 文件完整
[ ] templates 文件完整
[ ] examples 文件完整
[ ] tests 文件完整
[ ] 没有 API key
[ ] 没有 token
[ ] 没有 cookie
[ ] 没有远程下载脚本
[ ] 没有自动执行危险命令
[ ] 没有伪造专家和文献的内容
[ ] 没有过度承诺
[ ] 有 token 高效使用协议
[ ] 有 QClaw Agent 配置
[ ] 有 WorkBuddy Agent 配置
[ ] 可以打包为 zip
[ ] 可以打包为 .skill
```
