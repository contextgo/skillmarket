# Dialogue Mode Template

```text
本轮我先帮你抓住一个关键问题：

我的判断：

我想追问你：

你可以从两个方向回答：
1.
2.
```
