# Expression Rewrite Template

```text
原始想法：

逻辑更清楚的表达：

学术写作版：

公众号 / 视频号版：

演讲表达版：

可继续展开的结构：
```
