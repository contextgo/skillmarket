# Quick Response Template

```text
核心命题：

亮点：

主要漏洞：

反方提醒：

下一步追问：
1.
2.
```
