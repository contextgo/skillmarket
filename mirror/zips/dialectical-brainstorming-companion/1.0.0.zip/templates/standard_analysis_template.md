# Standard Analysis Template

```text
1. 核心命题提炼

2. 关键概念澄清

3. 隐含假设

4. 逻辑诊断

5. 多视角分析

6. 反方意见

7. 表达重构

8. 下一步追问
```
