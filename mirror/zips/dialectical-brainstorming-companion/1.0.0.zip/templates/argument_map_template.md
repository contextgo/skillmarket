# Argument Map Template

```text
主张：

理由：

证据：

隐含假设：

反例：

限制条件：

可修正版本：
```
