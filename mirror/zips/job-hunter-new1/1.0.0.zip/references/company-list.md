---

# name: company-list

# description: 智能简历求职匹配助手当前覆盖的公司范围
本文档整理当前主流AI相关企业（全量覆盖），按互联网大厂、AI独角兽、央国企、国际AI企业分类，新增AI细分领域重点企业，包含企业招聘官网及搜索建议，适配技能匹配与岗位检索场景，可直接用于OpenClaw skill.md文件。
---

# 一、互联网大厂（AI布局完善，岗位丰富）

|公司|招聘官网|搜索建议|
|-|-|-|
|华为|career.huawei.com|社会招聘→关键词搜索，AI岗集中在2012实验室、云与计算，重点搜“盘古大模型、AI解决方案、AI开发”|
|字节跳动|job.bytedance.com|搜索“大模型、多模态、AI产品、解决方案经理、AI Agent”，AI岗位占比高，更新频繁|
|阿里巴巴|talent.alibaba.com|搜索“通义千问、大模型训练、AI解决方案、政企AI、AI产品经理”|
|百度|talent.baidu.com|搜索“文心一言、大模型算法、自动驾驶、AI平台、解决方案经理”|
|腾讯|careers.tencent.com|搜索“混元大模型、AI Agent、游戏AI、智能云解决方案、AI产品”|
|小米|hr.xiaomi.com|搜索“小爱同学、大模型、智能硬件AI、自动驾驶、AI解决方案”|
|美团|zhaopin.meituan.com|搜索“本地生活AI、大模型应用、无人配送、AI产品、解决方案”|
|京东|campus.jd.com/home|搜索“供应链AI、大模型、智能零售、算法研究、AI解决方案”|
|网易|hr.163.com|搜索“大模型、AI游戏、AI内容生成、AI语音、解决方案经理”|
|快手|zhaopin.kuaishou.com|搜索“多模态AI、短视频AI、大模型应用、AI推荐、解决方案”|
|拼多多|careers.pinduoduo.com|搜索“供应链AI、推荐算法、大模型、AI风控、解决方案”|
|哔哩哔哩|jobs.bilibili.com|搜索“AI内容审核、多模态、大模型应用、AI推荐、解决方案经理”|
|阿里健康|talent.alihealth.com|搜索“医疗AI、大模型应用、AI诊断、健康管理AI、解决方案经理”|
|腾讯健康|careers.tencent.com/search.html?keyword=%E8%85%BE%E8%AE%AF%E5%81%A5%E5%BA%B7|搜索“医疗AI、AI问诊、大模型、健康数据AI、解决方案”|
|滴滴出行|job.didiglobal.com|搜索“自动驾驶AI、路径规划、多模态感知、AI调度、解决方案”|
|饿了么|zhaopin.ele.me|搜索“本地生活AI、无人配送、AI调度、大模型应用、解决方案”|

# 二、AI独角兽（聚焦AI核心领域，创新型岗位多）

注：以下为AI领域重点独角兽企业，涵盖计算机视觉、AI芯片、企业级AI等多个细分赛道，岗位创新性强。

|公司|招聘官网|搜索建议|
|-|-|-|
|科大讯飞|campus.iflytek.com / iflytek.com/careers|搜索“认知大模型、语音AI、教育AI、政企解决方案、解决方案经理”|
|商汤科技|career.sensetime.com|搜索“计算机视觉、大模型、AI基础设施、智慧城市、解决方案”|
|第四范式|www.4paradigm.com/careers|搜索“企业级AI、决策大模型、AutoML、金融AI、解决方案经理”|
|旷视科技|career.megvii.com|搜索“计算机视觉、大模型、AIoT、智慧城市、解决方案设计”|
|云从科技|career.cloudwalk.cn|搜索“计算机视觉、大模型、智能政务、行业解决方案、售前方案”|
|依图科技|www.yitutech.com/careers|搜索“计算机视觉、医疗AI、大模型、行业解决方案、技术方案经理”|
|后摩智能|houmo.jobs.feishu.cn/career|搜索“存算一体、AI芯片、大算力芯片、智能驾驶AI、解决方案”|
|清微智能|tsingmicro.zhiye.com/campus、jobs.tsingmicro.com|搜索“可重构计算、AI芯片、边缘计算、解决方案工程师、AI工具链”|
|地平线|career.horizon.ai|搜索“自动驾驶AI、边缘AI芯片、大模型推理、解决方案经理”|
|壁仞科技|career.biren-tech.com|搜索“AI芯片、大算力计算、GPU、AI基础设施、解决方案”|
|沐曦集成电路|career.muxi-ai.com|搜索“AI训练芯片、大模型算力、软硬件协同、解决方案设计”|
|深兰科技|hr.deepblueai.com|搜索“计算机视觉、自动驾驶、AI零售、智慧城市、解决方案经理”|
|思必驰|career.aispeech.com|搜索“语音AI、大模型、智能座舱、政企解决方案、售前方案”|
|云知声|www.unisound.com/careers|搜索“语音识别、认知AI、医疗AI、政企解决方案、解决方案经理”|
|墨芯人工智能|www.moffettai.com/careers|搜索“AI计算芯片、稀疏化算法、大算力芯片、芯片架构、解决方案”|
|深睿医疗|www.deepwise.com/join|搜索“医疗AI、AI诊断、医学影像AI、大模型应用、解决方案经理”|
|优必选|www.ubtech.com.cn/careers|搜索“人形机器人、运动控制、视觉AI、具身智能、解决方案”|
|云鲸智能|careers.narwal.com/jobs|搜索“具身智能、感知算法、SLAM、路径规划、AI解决方案”|
|石头科技|global.roborock.com/careers|搜索“SLAM、路径规划、传感器算法、嵌入式AI、解决方案”|
|九号公司|www.ninebot.com/careers|搜索“运动控制、服务机器人、割草机器人、AI算法、解决方案”|
|深度求索（DeepSeek）|app.mokahr.com/social-recruitment/high-flyer/140576#/|搜索“大模型、多模态、AI算法、模型训练、解决方案经理”|
|智谱AI|www.zhipuai.cn/careers|搜索“智谱大模型、多模态、AI算法、模型训练、解决方案工程师”|
|Minimax|www.minimaxir.com/careers|搜索“大模型研发、多模态交互、AI Agent、解决方案、算法工程师”|
|阶跃星辰|www.jieyuxingchen.com/careers|搜索“大模型训练、AI推理优化、多模态技术、解决方案经理”|
|面壁智能|www.mianbi.com/careers|搜索“大模型、AI安全、多模态、模型精调、解决方案设计”|

# 三、央国企（AI+政企/行业，稳定性强）

|公司|招聘官网|搜索建议|
|-|-|-|
|中国电子科技集团（CETC）|zhaopin.cetc.com.cn|搜索“AI算法、智能感知、政企解决方案、AI安全、解决方案经理”，重点关注下属研究所|
|中国电信|zhaopin.chinatelecom.com.cn|搜索“天翼云AI、大模型应用、政企AI解决方案、数字化转型方案”|
|中国移动|zhaopin.10086.cn|搜索“移动云AI、大模型、智慧政企、AI解决方案、售前方案顾问”|
|中国联通|chinaunicom2025.zhaopin.com|搜索“联通云AI、行业解决方案、AI原生应用、政企数字化方案”|
|中国航天科技集团|zhaopin.casc.cn|搜索“AI导航、智能控制、航天AI解决方案、算法研发”|
|中国电科太极股份|www.taiji.com.cn/careers|搜索“政务AI解决方案、数字化转型、大模型应用、解决方案经理”|
|国家能源集团|zhaopin.chnenergy.com.cn|搜索“擎源大模型、能源AI、智能运维、AI解决方案、解决方案经理”|
|中国石油|zhaopin.cnpc.com.cn|搜索“昆仑大模型、石油AI、智能勘探、AI解决方案、技术方案”|
|中国建材集团|zhaopin.cnbm.com.cn|搜索“晓妙产业大模型、建材AI、智能制造、解决方案经理”|
|中国铁路集团|rczp.china-railway.com.cn|搜索“铁路AI、智能调度、AI安防、解决方案、售前技术支持”|
|中国航空工业集团|zhaopin.avic.com|搜索“航空AI、智能制造、AI检测、解决方案设计、技术方案经理”|
|中国电子信息产业集团（CEC）|zhaopin.cec.com.cn|搜索“政企AI、AI安全、数字化解决方案、解决方案经理、售前支持”|
|海康威视|talent.hikvision.com|搜索“计算机视觉、AI安防、智慧城市、大模型应用、解决方案经理”|
|宇视科技|talent.uniview.com|搜索“AI安防、计算机视觉、智能监控、解决方案、售前技术支持”|
|徐工集团|www.xcmg.com/careers|搜索“无人工程机械、智能驾驶、AI运维、解决方案、算法研发”|

# 四、国际AI企业（技术领先，全球化岗位）

|公司|招聘官网|搜索建议|
|-|-|-|
|谷歌|careers.google.cn|搜索“Google Research、DeepMind、大模型、多模态、AI解决方案”|
|微软|careers.microsoft.com/zh-cn|搜索“Azure OpenAI、Copilot、大模型、AI工程、解决方案顾问”|
|英伟达|nvidia.cn/careers|搜索“CUDA、大模型训练、AI芯片、推理优化、AI基础设施方案”|
|英特尔|jobs.intel.com/cn|搜索“AI加速、边缘计算、大模型推理、软硬件协同、解决方案”|
|Meta|careers.meta.com/cn|搜索“大模型、多模态、AI研究、元宇宙AI、解决方案”|
|亚马逊|amazon.jobs/zh|搜索“Amazon AI、AWS AI、大模型、AI应用、解决方案顾问”|
|IBM|www.ibm.com/careers/cn/zh|搜索“企业级AI、大模型、AI安全、行业解决方案、解决方案经理”|
|AMD|jobs.amd.com/zh-cn|搜索“AI芯片、大算力计算、GPU、AI推理、解决方案”|
|高通|qualcomm.cn/careers|搜索“移动AI、边缘AI、AI芯片、智能座舱、解决方案”|
|OpenAI|openai.com/careers|搜索“大模型、多模态、AI研究、AI安全、解决方案工程师”|
|Anthropic|anthropic.com/careers|搜索“大模型、Claude、AI安全、多模态、解决方案”|
|特斯拉|tesla.cn/careers|搜索“自动驾驶AI、AI芯片、大模型应用、智能座舱、解决方案”|

# 五、AI细分领域重点企业（覆盖全场景，精准匹配岗位）

|公司|招聘官网|搜索建议|
|-|-|-|
|猿辅导|hr.yuanfudao.com|搜索“教育AI、大模型应用、AI题库、个性化学习、解决方案经理”|
|作业帮|zhaopin.zuoyebang.com|搜索“教育AI、AI答疑、大模型、智能题库、解决方案”|
|新石器|www.neolix.com/careers|搜索“无人配送车、L4自动驾驶、感知算法、AI调度、解决方案”|
|仙途智能|www.autowise.ai/careers|搜索“无人环卫车、自动驾驶、感知规划、AI测试、解决方案”|
|智元机器人|www.zhiyuan-robot.com/careers|搜索“人形机器人、具身大模型、VLA、操作与导航、解决方案”|
|星动纪元|www.star1.com/careers|搜索“高动态人形机器人、运动控制、灵巧手、系统集成、AI算法”|
|银河通用机器人|www.galbot.com/careers|搜索“具身大模型、商超/工厂操作机器人、AI控制、解决方案”|
|科沃斯|www.ecovacs.com/global/careers|搜索“家用服务机器人、SLAM、路径规划、AI算法、解决方案”|


