---
name: douyin-downloader
description: "Download Douyin (抖音) videos and image notes. Trigger on: 抖音下载、下载抖音、抖音视频、抖音图文、douyin download、抖音保存. Use when user shares a Douyin link or asks to download Douyin content."
license: MIT
allowed-tools:
  - execute_command
  - deliver_attachments
  - read_file
  - write_to_file
---

# 抖音下载器 / Douyin Downloader

使用 Playwright 浏览器自动化下载抖音视频和图文笔记。

## 项目简介

本 Skill 用于从抖音（Douyin）下载内容，支持两种类型：

- **视频**（`/video/` 链接）→ 下载为 MP4 文件
- **图文笔记**（`/note/` 链接）→ 下载图片 + 提取文字内容保存为 `content.md`

**为什么不用 yt-dlp？** 在 Windows 上，yt-dlp 的 `--cookies-from-browser` 因 DPAPI 解密问题无法使用。本 Skill 使用 Playwright 方案，稳定可靠。

## 使用方法

用户提供抖音链接后，按以下流程自动处理：

```
用户提供抖音链接
  │
  ├─ 是短链接（v.douyin.com）？
  │   └─ 是 → 先用 requests.head 解析为完整 URL
  │
  ├─ 解析后的 URL 包含 /video/？
  │   └─ 是 → 执行「视频下载流程」
  │
  ├─ 解析后的 URL 包含 /note/？
  │   └─ 是 → 执行「图文笔记下载流程」
  │
  └─ 都不是？
      └─ 告知用户不支持该内容类型
```

### 视频下载

1. 从 URL 中提取视频 ID（如 `/video/7623288507930682865` → `7623288507930682865`）
2. 运行下载脚本：

```bash
python <skill_dir>/scripts/download_video.py <video_id>
```

可选参数：`--output OUTPUT_DIR` 指定输出目录（默认 `./downloads`）

3. 验证输出：视频时长应在 15s-5min，文件大小 5-100MB

**关键规则：**
- **禁止拦截网络请求**来捕获视频 URL——抖音页面会自动加载无关视频导致误捕获
- **必须直接提取 `<video>` 元素的 `src`** 属性获取目标视频地址
- video 元素初始 `duration=0`，页面加载后需等待 5 秒再提取

### 图文笔记下载

1. 从 URL 中提取笔记 ID（如 `/note/7575845541729944969` → `7575845541729944969`）
2. 运行下载脚本：

```bash
python <skill_dir>/scripts/download_note.py <note_id>
```

可选参数：`--output OUTPUT_DIR` 指定输出目录（默认 `./downloads`）

3. 图片质量：每张 5-200KB，自动跳过 < 5KB 的小文件
4. **文字内容**自动提取并保存为 `content.md`（Markdown 格式）：
   - 标题：第一句话（以 。！？!? 结尾）→ `# 标题`
   - 正文：剩余文字作为段落
   - 话题标签：提取后单独列出
   - 无文字时写入 `<!-- No text content extracted -->`
5. **不要主动推送文件给用户**，除非用户明确要求

**文字提取原理：** 通过 `noteSideBarContainer`（语义化 class，稳定不变）定位右侧面板，在其兄弟元素中提取笔记正文。抖音的 class 名是混淆随机串（如 `YklhOzZK`），不可依赖。

**图片过滤规则：**

保留（内容图片 URL 模式）：
- `p*-pc-sign.douyinpic.com/...tplv-dy-aweme-images...`（Swiper 正文图片）
- `p*-pc-sign.douyinpic.com/...image-cut-tos-priv...`（笔记内容图片）
- `p*-pc-sign.douyinpic.com/...image-cut-tos/...`（笔记内容图片）
- `p*-pc-sign.douyinpic.com/...noop.jpeg`（高清封面）

跳过（UI 元素）：
- `p*-pc-weboff.byteimg.com/...tos-cn-i-9r5gewecjs/...`（官方图标）
- `p3-pc.douyinpic.com/aweme/100x100/...`（小头像）
- `twemoji/`（表情图片）
- `data:image/...`（内联 base64 图片）
- 小于 5KB 的文件

## 输出结构

所有文件默认保存到 `./downloads/` 目录：

```
downloads/
├── douyin_video_<id>.mp4              # 视频下载
└── douyin_note_<id>/                  # 图文笔记下载
    ├── content.md                     # 文字内容（Markdown：标题 + 正文 + 话题标签）
    ├── img_01.webp
    ├── img_02.jpeg
    └── ...
```

## 依赖与安装

脚本首次运行时自动检测并安装依赖，通常无需手动操作。

### 自动安装逻辑

1. **playwright 包** — 缺失时尝试：
   - 默认 PyPI → 回退到清华镜像（`https://pypi.tuna.tsinghua.edu.cn/simple`）

2. **Chromium 浏览器** — 缺失时尝试：
   - 默认 Playwright CDN → 回退到 npmmirror（`https://registry.npmmirror.com/-/binary/playwright`）

3. **自动安装失败时** — 脚本会打印手动安装命令：

```bash
# 安装 Python 依赖
pip install playwright requests -i https://pypi.tuna.tsinghua.edu.cn/simple

# 安装 Chromium 浏览器（Windows）
set PLAYWRIGHT_DOWNLOAD_HOST=https://registry.npmmirror.com/-/binary/playwright
playwright install chromium

# 安装 Chromium 浏览器（macOS/Linux）
export PLAYWRIGHT_DOWNLOAD_HOST=https://registry.npmmirror.com/-/binary/playwright
playwright install chromium
```

### 系统要求

- Python 3.10+
- 网络连接（自动安装处理其余依赖）

## 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| Playwright 超时 | 网络慢 | 增大超时到 60000ms |
| 视频 src 为空 | 页面未完全加载 | 导航后等待 5 秒 |
| 下载了错误视频 | 使用了网络拦截 | 改用 `<video>` 元素 src 提取 |
| 图片模糊/小 | 抖音 PC 端压缩 | 已是可获取的最高画质 |
| 笔记需要登录 | 内容需登录可见 | 告知用户，建议手动截图 |
| 笔记文字未提取 | DOM 结构变化 | 文字通过 `noteSideBarContainer` 兄弟定位；混淆 class 名可能变化 |
| UnicodeEncodeError | Windows GBK 控制台 | 设置 `PYTHONIOENCODING=utf-8` |
| pip 安装失败 | 网络/防火墙 | 使用清华镜像：`pip install -i https://pypi.tuna.tsinghua.edu.cn/simple` |
| Chromium 安装失败 | 国内 CDN 受限 | 设置 `PLAYWRIGHT_DOWNLOAD_HOST=https://registry.npmmirror.com/-/binary/playwright` |
