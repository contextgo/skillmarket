#!/usr/bin/env python3
"""Download images from Douyin note (image post) using Playwright browser automation.

Usage:
    python download_note.py <note_id> [--output OUTPUT_DIR]

Example:
    python download_note.py 7575845541729944969
    python download_note.py 7575845541729944969 --output ~/Downloads
"""

import argparse
import asyncio
import json
import os
import re
import sys
import urllib.parse

# Add scripts directory to path for deps import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from deps import ensure_dependencies

import requests


# URL patterns for content images (keep these)
CONTENT_PATTERNS = [
    "tplv-dy-aweme-images",
    "image-cut-tos-priv",
    "image-cut-tos/",
    "noop.jpeg",
    "tos-cn-i-0813c001",
    "tos-cn-i-0813/",
]

# URL patterns to skip (UI elements)
SKIP_PATTERNS = [
    "tos-cn-i-9r5gewecjs",  # Official icons
    "/aweme/100x100/",       # Tiny avatars
    "twemoji/",              # Emoji
    "aweme-avatar",          # Avatars
    "emblem.png",            # Logo
]


def is_content_image(url: str) -> bool:
    """Check if a URL is a content image (not a UI element)."""
    if url.startswith("data:"):
        return False
    for pattern in SKIP_PATTERNS:
        if pattern in url:
            return False
    for pattern in CONTENT_PATTERNS:
        if pattern in url:
            return True
    if "douyinpic.com" in url and "aweme-avatar" not in url:
        return True
    return False


def deduplicate_urls(urls: list) -> list:
    """Remove duplicate URLs (based on path without query params)."""
    seen = set()
    result = []
    for url in urls:
        base = url.split("?")[0]
        if base not in seen:
            seen.add(base)
            result.append(url)
    return result


async def download_note(note_id: str, output_dir: str) -> str | None:
    """Download images from a Douyin note. Returns the output directory or None."""
    from playwright.async_api import async_playwright

    note_dir = os.path.join(output_dir, f"douyin_note_{note_id}")
    os.makedirs(note_dir, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1920, "height": 1080},
        )
        page = await context.new_page()

        # Step 1: 预热会话 — 获取匿名 cookies（ttwid 等），降低后续反爬拦截
        print("[1/3] Warming up session...")
        await page.goto(
            "https://www.douyin.com/",
            wait_until="domcontentloaded",
            timeout=30000,
        )
        await asyncio.sleep(2)

        # Step 2: Navigate to note page
        note_url = f"https://www.douyin.com/note/{note_id}"
        print(f"[2/3] Navigating to note page: {note_url}")
        try:
            await page.goto(
                note_url, wait_until="domcontentloaded", timeout=30000
            )
            await asyncio.sleep(5)
        except Exception as e:
            print(f"  Warning: page load issue: {e}")

        # Step 3: Extract note text content
        print("[3/4] Extracting text content...")
        note_text = await page.evaluate("""
            () => {
                // Strategy: find the note text in the right-side panel.
                // The panel has a semantic class "noteSideBarContainer" for
                // the comment/recommendation area. The note text is in a
                // sibling div before it.
                const sidebar = document.querySelector('[class*="noteSideBarContainer"]');
                if (!sidebar) return '';
                const panel = sidebar.parentElement;
                if (!panel) return '';

                // Search sibling divs (before sidebar) for note text
                let best = '';
                for (const child of panel.children) {
                    if (child === sidebar) continue;
                    // Skip the author info (small text, < 50 chars of Chinese)
                    const text = child.textContent.trim();
                    const chineseLen = (text.match(/[\\u4e00-\\u9fff]/g) || []).length;
                    if (chineseLen > 10 && text.length > best.length) {
                        best = text;
                    }
                }
                // Also try: find the leaf span with the longest Chinese text
                // within the non-sidebar children
                if (!best) {
                    const spans = panel.querySelectorAll('span');
                    for (const span of spans) {
                        // Skip spans inside sidebar
                        if (sidebar.contains(span)) continue;
                        const t = span.textContent.trim();
                        const cLen = (t.match(/[\\u4e00-\\u9fff]/g) || []).length;
                        if (cLen > 10 && t.length < 500 && t.length > best.length) {
                            best = t;
                        }
                    }
                }
                return best;
            }
        """)
        if note_text:
            # Clean up: remove trailing UI text like "展开", "收起", publish time
            note_text = re.sub(r'展开$', '', note_text)
            note_text = re.sub(r'收起$', '', note_text)
            note_text = re.sub(r'展开?发布时间[：:].+$', '', note_text)
            note_text = re.sub(r'发布时间[：:].+$', '', note_text)
            note_text = note_text.strip()
            if note_text:
                print(f"  Text content: {note_text[:80]}...")
            else:
                print("  Text content emptied after cleanup.")
        else:
            print("  No text content found.")

        # Step 4: Extract image URLs — only from the note content Swiper
        print("[4/4] Extracting and downloading images...")

        image_urls = []

        # Method 1 (primary): Extract from Swiper container — these ARE the note content
        swiper_images = await page.evaluate("""
            () => {
                // Douyin note images live inside a Swiper component.
                // The swiper slides have class containing "dySwiperSlide" or "swiper-slide".
                // We only want images whose URL contains content patterns
                // (tplv-dy-aweme-images, image-cut-tos, etc.)
                const contentPatterns = [
                    'tplv-dy-aweme-images',
                    'image-cut-tos-priv',
                    'image-cut-tos/',
                    'noop.jpeg',
                    'tos-cn-i-0813c001',
                    'tos-cn-i-0813/',
                ];
                const skipPatterns = [
                    'tos-cn-i-9r5gewecjs',
                    '/aweme/100x100/',
                    'twemoji/',
                    'aweme-avatar',
                    'emblem.png',
                ];
                const selectors = [
                    '.swiper-slide img',
                    '[class*="dySwiperSlide"] img',
                    'xg-swiper-item img',
                ];
                const seen = new Set();
                const results = [];
                for (const sel of selectors) {
                    const imgs = document.querySelectorAll(sel);
                    imgs.forEach(img => {
                        const src = img.src || img.dataset.src || '';
                        if (!src || src.startsWith('data:') || seen.has(src)) return;
                        // Check skip
                        if (skipPatterns.some(p => src.includes(p))) return;
                        // Check content (must match at least one content pattern)
                        if (contentPatterns.some(p => src.includes(p))) {
                            seen.add(src);
                            results.push(src);
                        }
                    });
                }
                return results;
            }
        """)

        image_urls.extend(swiper_images)
        print(f"  Swiper content images: {len(image_urls)}")

        # Method 2 (fallback): If Swiper yielded nothing, try RENDER_DATA
        if not image_urls:
            print("  No Swiper images found, trying RENDER_DATA fallback...")
            render_data_raw = await page.evaluate("""
                () => {
                    const el = document.getElementById('RENDER_DATA');
                    return el ? el.textContent : null;
                }
            """)

            if render_data_raw:
                try:
                    decoded = urllib.parse.unquote(render_data_raw)
                    data = json.loads(decoded)
                    data_str = json.dumps(data)

                    url_pattern = (
                        r'"url_list"\s*:\s*\["(https?://[^"]+'
                        r'(?:douyinpic|byteimg|tiktokcdn)[^"]*)"'
                    )
                    url_matches = re.findall(url_pattern, data_str)

                    for u in url_matches:
                        clean = u.replace("\\u002F", "/").replace("\\/", "/")
                        if is_content_image(clean):
                            image_urls.append(clean)
                except Exception as e:
                    print(f"  RENDER_DATA parse error: {e}")

        await browser.close()

    # Deduplicate
    image_urls = deduplicate_urls(image_urls)
    print(f"  Found {len(image_urls)} content image URLs")

    # Download images
    downloaded = 0
    for i, img_url in enumerate(image_urls):
        if not img_url.startswith("http"):
            continue
        try:
            resp = requests.get(
                img_url,
                headers={
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36"
                    ),
                    "Referer": "https://www.douyin.com/",
                },
                timeout=30,
            )

            if resp.status_code != 200 or len(resp.content) < 5000:
                continue

            # Determine extension
            content_type = resp.headers.get("content-type", "")
            if "png" in content_type:
                ext = "png"
            elif "webp" in content_type:
                ext = "webp"
            elif "jpeg" in content_type or "jpg" in content_type:
                ext = "jpeg"
            elif ".png" in img_url:
                ext = "png"
            elif ".webp" in img_url:
                ext = "webp"
            else:
                ext = "jpeg"

            filename = f"img_{downloaded + 1:02d}.{ext}"
            filepath = os.path.join(note_dir, filename)
            with open(filepath, "wb") as f:
                f.write(resp.content)

            size_kb = len(resp.content) / 1024
            downloaded += 1
            print(f"  [{downloaded}] {filename} ({size_kb:.0f} KB)")

        except Exception as e:
            print(f"  Skip (error): {e}")

    # Save text content as content.md (always create for notes)
    md_path = os.path.join(note_dir, "content.md")
    if note_text:
        # Split into title and body
        # Douyin note format: "标题。正文内容#话题1 #话题2"
        # Extract hashtags first (all #xxx at the end, space-separated)
        hashtag_pattern = r'((?:#[^\s#]+\s*)+)$'
        hashtags_match = re.search(hashtag_pattern, note_text)
        hashtags = hashtags_match.group(1).strip() if hashtags_match else ""
        text_without_hashtags = note_text[:hashtags_match.start()].strip() if hashtags_match else note_text

        # Title: first sentence (up to first 。！？!?)
        title_pattern = r'^.*?[。！？!?]'
        title_match = re.match(title_pattern, text_without_hashtags)
        if title_match:
            title = title_match.group(0)
            body = text_without_hashtags[title_match.end():].strip()
            # Remove any remaining hashtags from body (shouldn't be, but just in case)
            body = re.sub(r'(?:#[^\s#]+\s*)+$', '', body).strip()
        else:
            # No sentence-ending punctuation — treat whole text as title
            title = text_without_hashtags
            body = ""

        # Build markdown
        lines = [f"# {title}"]
        if body:
            lines.append("")
            lines.append(body)
        if hashtags:
            lines.append("")
            lines.append(hashtags)
        lines.append("")

        with open(md_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"  Saved content.md (title: {title[:40]}...)")
    else:
        # No text extracted, still create file with placeholder
        with open(md_path, "w", encoding="utf-8") as f:
            f.write("<!-- No text content extracted -->\n")
        print("  Saved content.md (no text found)")

    if downloaded > 0:
        print(f"\n  Downloaded {downloaded} images to: {note_dir}")
        return note_dir
    else:
        print("\n  No images downloaded.")
        return None


def main():
    parser = argparse.ArgumentParser(description="Download Douyin note images")
    parser.add_argument("note_id", help="Douyin note ID (numeric)")
    parser.add_argument(
        "--output",
        "-o",
        default=os.path.join(os.getcwd(), "downloads"),
        help="Output directory (default: ./downloads)",
    )
    args = parser.parse_args()

    # Ensure dependencies before running
    ensure_dependencies()

    result = asyncio.run(download_note(args.note_id, args.output))
    if result:
        print(f"\nSuccess: {result}")
    else:
        print("\nFailed to download note images.")
        sys.exit(1)


if __name__ == "__main__":
    main()
