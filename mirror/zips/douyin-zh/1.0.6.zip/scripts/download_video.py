#!/usr/bin/env python3
"""Download Douyin video using Playwright browser automation.

Usage:
    python download_video.py <video_id> [--output OUTPUT_DIR]

Example:
    python download_video.py 7623288507930682865
    python download_video.py 7623288507930682865 --output ~/Downloads
"""

import argparse
import asyncio
import os
import sys

# Add scripts directory to path for deps import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from deps import ensure_dependencies

import requests


async def download_video(video_id: str, output_dir: str) -> str | None:
    """Download a Douyin video by its ID. Returns the output file path or None."""
    from playwright.async_api import async_playwright

    os.makedirs(output_dir, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1920, "height": 1080},
        )
        page = await context.new_page()

        # Step 1: 预热会话 — 获取匿名 cookies（ttwid 等），降低后续反爬拦截
        print("[1/4] Warming up session...")
        await page.goto(
            "https://www.douyin.com/",
            wait_until="domcontentloaded",
            timeout=30000,
        )
        await asyncio.sleep(2)

        # Step 2: Navigate to video page
        video_url = f"https://www.douyin.com/video/{video_id}"
        print(f"[2/4] Navigating to video page: {video_url}")
        try:
            await page.goto(
                video_url, wait_until="domcontentloaded", timeout=30000
            )
            await asyncio.sleep(5)
        except Exception as e:
            print(f"  Warning: page load issue: {e}")

        # Step 3: Extract video element src
        print("[3/4] Extracting video URL from <video> element...")
        video_src = await page.evaluate("""
            () => {
                const video = document.querySelector('video');
                return video ? (video.src || video.currentSrc || '') : '';
            }
        """)

        await browser.close()

    if not video_src or not video_src.startswith("http"):
        print("ERROR: Could not find video source URL.")
        return None

    print(f"  Found video URL: {video_src[:120]}...")

    # Step 4: Download the video
    print("[4/4] Downloading video...")
    try:
        resp = requests.get(
            video_src,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36"
                ),
                "Referer": "https://www.douyin.com/",
            },
            stream=True,
            timeout=120,
        )

        if resp.status_code != 200:
            print(f"ERROR: Download failed with status {resp.status_code}")
            return None

        output_path = os.path.join(output_dir, f"douyin_video_{video_id}.mp4")

        with open(output_path, "wb") as f:
            downloaded = 0
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)

        size_mb = os.path.getsize(output_path) / 1024 / 1024
        print(f"  Downloaded: {output_path}")
        print(f"  Size: {size_mb:.1f} MB")

        # Sanity check
        if size_mb < 0.5:
            print("  WARNING: File is very small, might not be the correct video.")
        elif size_mb > 200:
            print("  WARNING: File is very large, might not be a short video.")

        return output_path

    except Exception as e:
        print(f"ERROR: Download failed: {e}")
        return None


def main():
    parser = argparse.ArgumentParser(description="Download Douyin video")
    parser.add_argument("video_id", help="Douyin video ID (numeric)")
    parser.add_argument(
        "--output",
        "-o",
        default=os.path.join(os.getcwd(), "downloads"),
        help="Output directory (default: ./downloads)",
    )
    args = parser.parse_args()

    # Ensure dependencies before running
    ensure_dependencies()

    result = asyncio.run(download_video(args.video_id, args.output))
    if result:
        print(f"\nSuccess: {result}")
    else:
        print("\nFailed to download video.")
        sys.exit(1)


if __name__ == "__main__":
    main()
