#!/usr/bin/env python3
"""Dependency checker and auto-installer for douyin-downloader.

Handles:
- playwright package installation (with Tsinghua PyPI mirror fallback)
- Chromium browser installation (with npmmirror fallback)

Usage:
    from deps import ensure_dependencies
    ensure_dependencies()
"""

import importlib
import os
import subprocess
import sys

# Tsinghua PyPI mirror for Chinese users
PIP_MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"

# npmmirror for Playwright browser binaries
PLAYWRIGHT_DOWNLOAD_HOST = "https://registry.npmmirror.com/-/binary/playwright"


def _run_pip_install(package: str, use_mirror: bool = False) -> bool:
    """Install a pip package. Returns True on success."""
    cmd = [sys.executable, "-m", "pip", "install", package]
    if use_mirror:
        cmd += ["-i", PIP_MIRROR, "--trusted-host", "pypi.tuna.tsinghua.edu.cn"]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def _install_chromium(use_mirror: bool = False) -> bool:
    """Install Chromium browser for Playwright. Returns True on success."""
    cmd = [sys.executable, "-m", "playwright", "install", "chromium"]
    env = os.environ.copy()
    if use_mirror:
        env["PLAYWRIGHT_DOWNLOAD_HOST"] = PLAYWRIGHT_DOWNLOAD_HOST

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, env=env)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def _check_chromium_installed() -> bool:
    """Check if Chromium browser is already installed for Playwright."""
    try:
        from playwright._impl._driver import compute_driver_executable
        driver = compute_driver_executable()
        if not driver.exists():
            return False
    except Exception:
        pass

    # Alternative check: try launching chromium
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "--dry-run", "chromium"],
            capture_output=True, text=True, timeout=30,
        )
        # If dry-run succeeds, chromium is already installed
        return result.returncode == 0
    except Exception:
        pass

    # Last resort: assume installed if playwright package exists
    # (the actual check will happen when we try to use it)
    return True


def ensure_dependencies() -> None:
    """Check and install all dependencies. Exits with error if unable to install."""
    errors = []

    # --- Check playwright package ---
    try:
        importlib.import_module("playwright")
        print("[deps] playwright package: OK")
    except ImportError:
        print("[deps] playwright package: NOT FOUND, installing...")

        # Try default PyPI first, fallback to Tsinghua mirror
        print("[deps]   Trying default PyPI...")
        if _run_pip_install("playwright>=1.40.0", use_mirror=False):
            print("[deps]   Installed from default PyPI")
        else:
            print("[deps]   Default PyPI failed, trying Tsinghua mirror...")
            if _run_pip_install("playwright>=1.40.0", use_mirror=True):
                print("[deps]   Installed from Tsinghua mirror")
            else:
                errors.append(
                    "Failed to install playwright. Try manually:\n"
                    f"  pip install playwright>=1.40.0 -i {PIP_MIRROR}"
                )

    # --- Check requests package ---
    try:
        importlib.import_module("requests")
        print("[deps] requests package: OK")
    except ImportError:
        print("[deps] requests package: NOT FOUND, installing...")

        if _run_pip_install("requests>=2.28.0", use_mirror=False):
            print("[deps]   Installed from default PyPI")
        elif _run_pip_install("requests>=2.28.0", use_mirror=True):
            print("[deps]   Installed from Tsinghua mirror")
        else:
            errors.append(
                "Failed to install requests. Try manually:\n"
                f"  pip install requests>=2.28.0 -i {PIP_MIRROR}"
            )

    # --- Check Chromium browser ---
    print("[deps] Checking Chromium browser...")
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            # Try to find chromium - this will raise if not installed
            browser_path = p.chromium.executable_path
            if browser_path and os.path.exists(browser_path):
                print("[deps] Chromium browser: OK")
            else:
                raise RuntimeError("Chromium not found")
    except Exception:
        print("[deps] Chromium browser: NOT FOUND, installing...")

        # Try default CDN first, fallback to npmmirror
        print("[deps]   Trying default CDN...")
        if _install_chromium(use_mirror=False):
            print("[deps]   Installed from default CDN")
        else:
            print("[deps]   Default CDN failed, trying npmmirror...")
            if _install_chromium(use_mirror=True):
                print("[deps]   Installed from npmmirror")
            else:
                errors.append(
                    "Failed to install Chromium. Try manually:\n"
                    f"  set PLAYWRIGHT_DOWNLOAD_HOST={PLAYWRIGHT_DOWNLOAD_HOST}\n"
                    "  playwright install chromium"
                )

    # --- Report errors ---
    if errors:
        print("\n[deps] ERROR: Could not install all dependencies:")
        for e in errors:
            print(f"  - {e}")
        print("\nManual installation commands:")
        print(f"  pip install playwright requests -i {PIP_MIRROR}")
        print(f"  set PLAYWRIGHT_DOWNLOAD_HOST={PLAYWRIGHT_DOWNLOAD_HOST}")
        print("  playwright install chromium")
        sys.exit(1)

    print("[deps] All dependencies ready!\n")
