---
name: douyin-downloader
description: "Download Douyin (抖音) videos and image notes. Trigger on: 抖音下载、下载抖音、抖音视频、抖音图文、douyin download、抖音保存. Use when user shares a Douyin link or asks to download Douyin content."
license: MIT
allowed-tools:
  - execute_command
  - deliver_attachments
  - read_file
  - write_to_file
---

# 抖音下载器

丢一个链接，视频和图文笔记自动保存到本地。

## 为什么选这个？

市面上大多数抖音下载工具要么要你登录、要么要充会员、要么要关注公众号获取 API Key，要么就是网页版塞满广告。

**这个不需要。**

- ✅ **免登录** — 不登抖音账号就能下
- ✅ **零配置** — 不需要注册任何 API、不需要申请密钥、不需要扫码
- ✅ **开箱即用** — 首次运行自动装好依赖，没有手动操作
- ✅ **纯本地运行** — 数据不过第三方服务器
- ✅ **国内优化** — 依赖安装自动走清华镜像和 npmmirror，国内网络友好

## 能下什么？

| 内容 | 输出 |
|------|------|
| 短视频 | `douyin_video_{id}.mp4` |
| 图文笔记 | 图片文件 + `content.md`（标题、正文、话题标签自动整理） |

链接直接丢过来就行，短链接（v.douyin.com）自动解析。

## 使用方式

丢一个抖音链接：
> 下载抖音 https://v.douyin.com/xxxxx/

然后等着，文件保存到 `downloads/` 目录。

```
downloads/
├── douyin_video_7623373826093961314.mp4
├── douyin_note_7631874075779078554/
│   ├── content.md        ← 标题 + 正文 + 话题标签，Markdown 格式
│   ├── img_01.webp
│   └── img_02.webp
└── ...
```

图文笔记的文字会智能提取：
- **第一句话**自动作为标题（`# 标题`）
- **正文段落**完整保留
- **话题标签**（#xxx）单独列出
- 没文字也不报错，文件照样创建

## 需要什么环境？

Python 3.10+ 就行。首次运行会自动搞定一切——检测缺失、安装依赖、下载 Chromium 浏览器，全程不用你动手。

如果自动安装失败（极少见），手动跑两行命令即可：

```bash
pip install playwright requests -i https://pypi.tuna.tsinghua.edu.cn/simple
set PLAYWRIGHT_DOWNLOAD_HOST=https://registry.npmmirror.com/-/binary/playwright
playwright install chromium
```

## 常见问题

| 问题 | 为什么 | 怎么解决 |
|------|--------|----------|
| 图片不够高清 | 抖音 PC 端本身就压缩了 | 已是能拿到的最高画质 |
| 笔记提示需要登录 | 作者设置了仅粉丝可见 | 老铁，这个谁都下不了 |
| 下载龟速 | 抖音 CDN 限速 | 耐心等，别急 |
| 依赖装不上 | 网络抽风 | 用上面手动安装命令，走国内镜像 |
