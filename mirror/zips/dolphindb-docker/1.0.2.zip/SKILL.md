# DolphinDB Docker 部署技能 v1.0.3

## ⚠️ 前置依赖

**本技能依赖 `dolphindb-basic` 技能，请先安装：**
```bash
clawhub install dolphindb-basic
```

**如需要 Python SDK 集成测试，请先检测并加载 Python 环境，详细方法可参见 dolphindb-skills 技能。**

```bash
# 加载环境检测器（相对路径，技能安装后自动可用）
source ../dolphindb-skills/scripts/load_dolphindb_env.sh

# 查看环境信息
dolphin_env_info

# 验证 SDK 已安装
dolphin_python -c "import dolphindb; print('SDK 版本:', dolphindb.__version__)"
```

**统一调用接口：**
```bash
dolphin_python script.py    # 运行 Python 脚本
dolphin_pip install pkg     # 安装包
```

---

## 描述
提供基于 Docker 的 DolphinDB 数据库快速部署方案，包括 Docker 安装检查、镜像拉取、容器配置、端口映射、Python SDK 集成等完整流程。

## 触发条件
当用户提到以下关键词时触发此技能：
- "DolphinDB Docker"、"Docker 安装 DolphinDB"
- "容器化部署"、"docker-compose"
- "快速部署"、"一键安装"
- "Docker Hub"、"镜像拉取"
- "端口 8848"、"DolphinDB 配置"
- "Python SDK"、"dolphindb 连接"

## 能力范围

### 1. Docker 环境检查
- 检查 Docker 是否安装
- 检查 Docker 服务状态
- 检查 Docker 版本兼容性

### 2. Docker 安装（如未安装）
- macOS: Docker Desktop
- Linux: Docker CE
- Windows: Docker Desktop

### 3. DolphinDB 镜像管理
- 搜索官方镜像
- 拉取最新稳定版镜像
- 镜像版本管理

### 4. 容器部署
- 单机部署
- 端口映射（8848）
- 数据持久化
- 配置文件挂载

### 5. Python SDK 集成
- SDK 安装方法
- 连接测试
- 数据库操作

### 6. 高级配置
- Dockerfile 自定义
- docker-compose 编排
- 集群部署

---

## 使用示例

### 一、Docker 环境检查

```bash
# 1. 检查 Docker 是否安装
docker --version

# 2. 检查 Docker 服务状态
docker info

# 3. 检查 Docker Compose
docker-compose --version
# 或
docker compose version
```

**预期输出**:
```
Docker version 28.5.2, build ecc6942
Client:
 Version:    28.5.2
 Context:    desktop-linux
...
```

---

### 二、安装 Docker（如未安装）

#### macOS 安装

```bash
# 方法 1: 使用 Homebrew 安装
brew install --cask docker

# 方法 2: 下载安装
# 访问：https://www.docker.com/products/docker-desktop/
# 下载 Docker Desktop for Mac
```

#### Linux 安装（Ubuntu/Debian）

```bash
# 1. 更新包索引
sudo apt-get update

# 2. 安装依赖
sudo apt-get install -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

# 3. 添加 Docker 官方 GPG 密钥
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# 4. 设置稳定版仓库
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 5. 安装 Docker Engine
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io

# 6. 验证安装
sudo docker --version
sudo docker run hello-world
```

---

### 三、搜索并拉取 DolphinDB 镜像

```bash
# 1. 搜索官方镜像
docker search dolphindb

# 2. 查看可用标签
curl -s "https://hub.docker.com/v2/repositories/dolphindb/dolphindb/tags" | \
    python3 -c "import sys,json; data=json.load(sys.stdin); \
    print('\n'.join([t['name'] for t in data.get('results',[])]))"

# 3. 拉取最新镜像
docker pull dolphindb/dolphindb:latest

# 或指定版本
docker pull dolphindb/dolphindb:v2.00.5
docker pull dolphindb/dolphindb:v3.0.0
```

**可用镜像**:
- `dolphindb/dolphindb:latest` - 最新版
- `dolphindb/dolphindb:v2.00.5` - v2.00.5（稳定版）
- `dolphindb/dolphindb:v3.0.0` - v3.0.0
- `dolphindb/dolphindb-arm64` - ARM 架构

---

### 四、运行 DolphinDB 容器（含端口测试）

#### 方法 1: 基础运行（最简单）

```bash
docker run -d \
    --name dolphindb \
    -p 8848:8848 \
    -p 8081:8081 \
    dolphindb/dolphindb:v2.00.5
```

**端口说明**:
- `8848`: DolphinDB 默认端口（必须）
- `8081`: Web 管理器端口（可选）

---

#### 方法 2: 数据持久化（推荐）

```bash
docker run -d \
    --name dolphindb \
    -p 8848:8848 \
    -p 8081:8081 \
    -v dolphindb-data:/data \
    -v dolphindb-logs:/var/log/dolphindb \
    -e DB_USER=admin \
    -e DB_PASSWORD=123456 \
    dolphindb/dolphindb:v2.00.5
```

**卷说明**:
- `dolphindb-data:/data` - 数据持久化
- `dolphindb-logs:/var/log/dolphindb` - 日志持久化

---

#### 方法 3: 挂载配置文件

```bash
# 1. 创建配置目录
mkdir -p ~/dolphindb/config

# 2. 创建配置文件
cat > ~/dolphindb/config/dolphindb.cfg << EOF
localSite=localhost:8848:local8848
siteDir=~/data
webDir=~/web
persistenceDir=~/persistence
EOF

# 3. 运行容器（挂载配置）
docker run -d \
    --name dolphindb \
    -p 8848:8848 \
    -p 8081:8081 \
    -v ~/dolphindb/config:/opt/dolphindb/config \
    -v ~/dolphindb/data:/data \
    dolphindb/dolphindb:v2.00.5
```

---

### 五、启动验证与端口测试（重要！）

#### 步骤 1: 检查 Docker 服务状态

```bash
# 检查 Docker 是否运行
docker info

# 如果 Docker 未启动，启动它
# macOS: 打开 Docker Desktop 应用
# Linux:
sudo systemctl start docker
sudo systemctl enable docker  # 设置开机自启

# 验证 Docker 运行状态
docker ps | grep dolphindb
```

**预期输出**:
```
CONTAINER ID   IMAGE                    STATUS          PORTS
abc123456789   dolphindb/dolphindb      Up 2 minutes    0.0.0.0:8848->8848/tcp
```

---

#### 步骤 2: 验证端口映射

```bash
# 检查端口是否监听
# macOS/Linux:
lsof -i :8848
lsof -i :8081

# 或使用 netstat
netstat -tlnp | grep 8848
netstat -tlnp | grep 8081

# 或使用 ss（推荐）
ss -tlnp | grep 8848
ss -tlnp | grep 8081
```

**预期输出**:
```
LISTEN  0  128  *:8848  *:*  users:(("docker-desktop",pid=1234,fd=56))
```

---

#### 步骤 3: 测试端口连通性

```bash
# 方法 1: 使用 curl 测试 Web 端口
curl -I http://localhost:8081

# 预期输出：HTTP/1.1 200 OK

# 方法 2: 使用 nc (netcat) 测试
nc -zv localhost 8848
nc -zv localhost 8081

# 预期输出：Connection to localhost port 8848 [tcp/*] succeeded!

# 方法 3: 使用 bash 内置 TCP 测试
echo > /dev/tcp/localhost/8848 && echo "Port 8848 is OPEN" || echo "Port 8848 is CLOSED"
```

---

#### 步骤 4: 访问 Web 管理器

```bash
# 在浏览器中打开
# http://localhost:8081

# 或使用命令行打开（macOS）
open http://localhost:8081

# Linux (需要 xdg-utils)
xdg-open http://localhost:8081

# 默认登录凭据
# 用户名：admin
# 密码：123456
```

---

#### 步骤 5: Python SDK 连接测试

**方法 A: 使用官方 Python API 客户端**

```bash
# 1. 安装 Python SDK
# 从 DolphinDB 容器复制 Python 客户端
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindb.py .
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindbSession.py .

# 或使用 pip 安装（如可用）
pip install dolphindb --break-system-packages

# 2. 连接测试
python3 << 'EOF'
import dolphindb as ddb

try:
    # 创建会话
    s = ddb.session()
    
    # 连接到 DolphinDB
    s.connect(host="localhost", port=8848, userid="admin", password="123456")
    
    # 执行测试查询
    result = s.run("select now() as currentTime, 1+1 as test")
    print("✅ 连接成功！")
    print(f"当前时间：{result['currentTime'][0]}")
    print(f"测试结果：{result['test'][0]}")
    
    # 关闭会话
    s.close()
    
except Exception as e:
    print(f"❌ 连接失败：{e}")
EOF
```

**方法 B: 使用 HTTP API（无需安装 SDK）**

```bash
# 使用 curl 测试
curl -u admin:123456 \
    -d "select now()" \
    http://localhost:8848/

# 或使用 Python requests
python3 << 'EOF'
import requests

# 连接测试
response = requests.get(
    "http://localhost:8848/",
    auth=("admin", "123456"),
    params={"query": "select now()"},
    timeout=10
)

if response.status_code == 200:
    print("✅ HTTP API 连接成功！")
    print(f"响应：{response.text}")
else:
    print(f"❌ 连接失败：HTTP {response.status_code}")
EOF
```

**预期输出**:
```
✅ 连接成功！
当前时间：2024.03.24T23:40:00.000
测试结果：2
```

---

#### 步骤 6: 查看容器日志

```bash
# 实时查看日志
docker logs -f dolphindb

# 查看最近 100 行日志
docker logs --tail 100 dolphindb

# 查看日志并带时间戳
docker logs -f --timestamps dolphindb

# 预期看到类似输出：
# DolphinDB Server started on port 8848
# Database initialized successfully
```

---

#### 完整测试脚本（一键验证）

```bash
#!/bin/bash
# dolphindb-test.sh - DolphinDB Docker 连接测试脚本

set -e

echo "🔍 DolphinDB Docker 连接测试"
echo "=============================="

# 1. 检查 Docker
echo -e "\n1️⃣ 检查 Docker 状态..."
if docker info > /dev/null 2>&1; then
    echo "✅ Docker 运行正常"
else
    echo "❌ Docker 未运行，请先启动 Docker"
    exit 1
fi

# 2. 检查容器
echo -e "\n2️⃣ 检查 DolphinDB 容器..."
if docker ps | grep -q dolphindb; then
    echo "✅ 容器运行中"
    docker ps --filter "name=dolphindb" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
else
    echo "❌ 容器未运行"
    exit 1
fi

# 3. 测试端口
echo -e "\n3️⃣ 测试端口连通性..."
if nc -zv localhost 8848 2>/dev/null; then
    echo "✅ 端口 8848 (数据库) 已开放"
else
    echo "❌ 端口 8848 无法连接"
    exit 1
fi

if nc -zv localhost 8081 2>/dev/null; then
    echo "✅ 端口 8081 (Web) 已开放"
else
    echo "⚠️  Web 端口 8081 未开放（可能未映射）"
fi

# 4. Web 测试
echo -e "\n4️⃣ 测试 Web 管理器..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost:8081 | grep -q "200"; then
    echo "✅ Web 管理器响应正常 (HTTP 200)"
else
    echo "⚠️  Web 管理器响应异常或不可用"
fi

# 5. Python 连接测试
echo -e "\n5️⃣ Python 连接测试..."
python3 << 'PYEOF'
import sys
try:
    import requests
    response = requests.get(
        "http://localhost:8848/",
        auth=("admin", "123456"),
        timeout=5
    )
    if response.status_code == 200:
        print(f"✅ HTTP API 连接成功 - HTTP {response.status_code}")
    else:
        print(f"⚠️  HTTP API 响应异常：{response.status_code}")
except Exception as e:
    print(f"⚠️  Python 连接测试跳过：{e}")
PYEOF

echo -e "\n=============================="
echo "🎉 所有测试完成！"
echo "📱 Web 界面：http://localhost:8081"
echo "🔌 数据库连接：localhost:8848"
echo "👤 默认账号：admin / 123456"
```

**使用方法**:
```bash
# 保存脚本
chmod +x dolphindb-test.sh

# 运行测试
./dolphindb-test.sh
```

---

### 六、使用 Docker Compose 编排

```yaml
# docker-compose.yml
version: '3.8'

services:
  dolphindb:
    image: dolphindb/dolphindb:v2.00.5
    container_name: dolphindb
    restart: unless-stopped
    ports:
      - "8848:8848"
      - "8081:8081"
    volumes:
      - dolphindb-data:/data
      - dolphindb-logs:/var/log/dolphindb
      - ./config:/opt/dolphindb/config
    environment:
      - DB_USER=admin
      - DB_PASSWORD=123456
      - TZ=Asia/Shanghai
    networks:
      - dolphindb-net
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8848/"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  dolphindb-data:
    driver: local
  dolphindb-logs:
    driver: local

networks:
  dolphindb-net:
    driver: bridge
```

**启动服务**:
```bash
# 启动所有服务
docker-compose up -d

# 查看状态
docker-compose ps

# 查看日志
docker-compose logs -f dolphindb

# 停止服务
docker-compose down

# 停止并删除数据（谨慎使用）
docker-compose down -v
```

---

### 七、使用 Dockerfile 自定义镜像

```dockerfile
# Dockerfile for DolphinDB
FROM dolphindb/dolphindb:v2.00.5

# 设置工作目录
WORKDIR /opt/dolphindb

# 复制自定义配置文件
COPY dolphindb.cfg /opt/dolphindb/config/dolphindb.cfg

# 复制初始化脚本
COPY init.dos /opt/dolphindb/scripts/init.dos

# 暴露端口
EXPOSE 8848 8081

# 设置环境变量
ENV DB_USER=admin
ENV DB_PASSWORD=123456
ENV TZ=Asia/Shanghai

# 健康检查
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD curl -f http://localhost:8848/ || exit 1

# 启动命令
CMD ["/opt/dolphindb/dolphindb"]
```

**构建并运行**:
```bash
# 构建镜像
docker build -t my-dolphindb:1.0 .

# 运行容器
docker run -d \
    --name my-dolphindb \
    -p 8848:8848 \
    -p 8081:8081 \
    -v ~/dolphindb-data:/data \
    my-dolphindb:1.0
```

---

### 八、容器管理命令

```bash
# 查看运行状态
docker ps | grep dolphindb

# 查看容器日志
docker logs -f dolphindb

# 进入容器
docker exec -it dolphindb bash

# 重启容器
docker restart dolphindb

# 停止容器
docker stop dolphindb

# 启动容器
docker start dolphindb

# 删除容器
docker rm -f dolphindb

# 查看资源使用
docker stats dolphindb

# 导出容器数据
docker export dolphindb > dolphindb-backup.tar

# 导入容器数据
docker import dolphindb-backup.tar my-dolphindb:backup
```

---

### 九、连接测试

```bash
# 1. 使用 Web 界面
# 访问：http://localhost:8081
# 登录：admin / 123456

# 2. 使用 Python 客户端
# 从容器复制 Python SDK
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindb.py .
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindbSession.py .

python3 << EOF
import dolphindb as ddb
s = ddb.session()
s.connect(host="localhost", port=8848, userid="admin", password="123456")
print(s.run("select now()"))
s.close()
EOF

# 3. 使用 GUI 客户端
# 下载：https://www.dolphindb.cn/downloads.html
# 连接：localhost:8848
```

---

### 十、故障排查

#### 问题 1: 容器无法启动

```bash
# 查看详细日志
docker logs dolphindb

# 检查端口占用
lsof -i :8848
# 或
netstat -tlnp | grep 8848

# 使用其他端口
docker run -d \
    --name dolphindb \
    -p 9999:8848 \
    dolphindb/dolphindb:v2.00.5
```

#### 问题 2: 数据丢失

```bash
# 确保使用持久化卷
docker run -d \
    --name dolphindb \
    -v ~/dolphindb-data:/data \
    dolphindb/dolphindb:v2.00.5

# 检查卷是否存在
docker volume ls | grep dolphindb
```

#### 问题 3: 内存不足

```bash
# 限制容器内存
docker run -d \
    --name dolphindb \
    -m 4g \
    --memory-swap 4g \
    -p 8848:8848 \
    dolphindb/dolphindb:v2.00.5
```

#### 问题 4: Python SDK 无法安装

```bash
# 方法 1: 从容器复制 SDK
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindb.py .
docker cp dolphindb:/opt/dolphindb/tools/python/dolphindbSession.py .

# 方法 2: 使用 HTTP API（无需 SDK）
import requests
response = requests.get(
    "http://localhost:8848/",
    auth=("admin", "123456"),
    params={"query": "select now()"}
)
print(response.text)
```

---

## 配置参考

### dolphindb.cfg 配置示例

```ini
# 网络配置
localSite=localhost:8848:local8848
siteDir=/data

# Web 管理器
webDir=/opt/dolphindb/web
webPort=8081

# 数据持久化
persistenceDir=/data/persistence
persistenceCacheSize=1024

# 内存配置
maxMemSize=4096
maxMemShare=0.8

# 日志配置
logDir=/var/log/dolphindb
logLevel=INFO

# 安全配置
enableACL=true
sessionTimeout=3600
```

---

## 参考文档

- **Docker 官网**: https://www.docker.com/
- **Docker Hub**: https://hub.docker.com/r/dolphindb/dolphindb
- **DolphinDB 官网**: https://www.dolphindb.cn/
- **DolphinDB 文档中心**: https://docs.dolphindb.cn/zh/
- **Docker 部署指南**: https://docs.dolphindb.cn/zh/deploy/docker/docker_deployment.html
- **Python API 文档**: https://docs.dolphindb.cn/zh/pydoc/py.html

---

## 相关技能

- **dolphindb-skills**: 技能套件索引（含环境检测）
- **dolphindb-basic**: DolphinDB 基础 CRUD 操作
- **dolphindb-quant-finance**: 量化金融场景
- **dolphindb-streaming**: 流式计算
