#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自由河蟹 · 快速内容检查脚本 v2.0.0
基于AI智能分析，不依赖固定规则库。

用法: python review.py --ai
      python review.py --standards
      python review.py --help

说明: v2.0.0 采用AI理解式分析，让AI理解审核标准后自主判断。
      实际内容检查由AI根据正向价值观导向自主分析。
"""

import json
import sys
from pathlib import Path

# ──────────────────────────────────────────────
# 路径配置
# ──────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent
RULES_DIR = SCRIPT_DIR.parent / "rules"


def load_version():
    """加载版本信息"""
    version_file = RULES_DIR / "version.json"
    with open(version_file, "r", encoding="utf-8") as f:
        return json.load(f)


def load_standards():
    """加载各维度审核标准"""
    dimensions = ["d", "e", "f", "g", "h"]
    standards = {}
    dim_names = {"d": "政治导向", "e": "行为导向", "f": "吉祥导向", "g": "诚信导向", "h": "文明导向"}

    for dim in dimensions:
        file_path = RULES_DIR / f"dimension_{dim}.json"
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                standards[f"D{dim.upper()}"] = {
                    "name": data.get("dimension_name", dim_names.get(dim, dim)),
                    "description": data.get("description", ""),
                    "principles": data.get("audit_principles", []),
                    "guidelines": data.get("judgment_guidelines", {})
                }
    return standards


def print_standards(standards: dict, version_info: dict):
    """打印审核标准"""
    print()
    print("=" * 60)
    print("【自由河蟹 · 检查标准参考】")
    print("=" * 60)
    print(f"技能版本: v{version_info['skill_version']}")
    print(f"架构: AI智能分析")
    print()
    print("五大检查维度：")
    print("-" * 60)

    for dim_code, data in standards.items():
        print(f"\n{dim_code} {data['name']}")
        print(f"  说明: {data['description']}")
        print(f"  检查要点:")
        for p in data["principles"]:
            print(f"    - {p}")

    print()
    print("-" * 60)
    print("使用说明：")
    print("  本脚本提供检查标准参考。实际内容分析由AI自主判断。")
    print()
    print("  如需AI分析文本，请通过主技能触发：")
    print("  '帮我检查这段内容' 或 '看看有没有需要优化的地方'")
    print("=" * 60)
    print()


def print_banner():
    """打印技能信息"""
    print()
    print("  ╔══════════════════════════════════════╗")
    print("  ║       自由河蟹 · 内容检查           ║")
    print("  ║       AI智能分析 v2.0.0             ║")
    print("  ╚══════════════════════════════════════╝")
    print()


def main():
    print_banner()

    version_info = load_version()
    standards = load_standards()

    if len(sys.argv) < 2:
        print("用法:")
        print("  python review.py --ai          查看AI分析说明")
        print("  python review.py --standards   查看检查标准")
        print("  python review.py --help        显示帮助")
        print()
        print("提示: 如需检查文本内容，请通过主技能触发。")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd in ["--standards", "-s"]:
        print_standards(standards, version_info)

    elif cmd in ["--ai", "-a"]:
        print()
        print("【AI智能分析说明】")
        print("=" * 60)
        print()
        print("自由河蟹 v2.0.0 采用AI智能分析机制：")
        print()
        print("1. 不依赖固定规则库匹配")
        print("2. 让AI理解正向价值观导向的内涵")
        print("3. AI根据审核标准自主判断内容质量")
        print("4. 结合语境，智能分析避免误判")
        print()
        print("检查维度：")
        print("  D1 政治导向 - 政治立场正确，符合国家政策")
        print("  D2 行为导向 - 鼓励正向行为，不引导不良行为")
        print("  D3 吉祥导向 - 符合中国人传统美好愿景")
        print("  D4 诚信导向 - 传递诚实守信的正向价值观")
        print("  D5 文明导向 - 语言文明得体")
        print()
        print("触发检查：'帮我检查这段内容' / '看看有没有问题'")
        print("=" * 60)
        print()

    elif cmd in ["--help", "-h"]:
        print_standards(standards, version_info)

    else:
        print(f"未知命令: {cmd}")
        print("用法: python review.py --help")
        sys.exit(1)


if __name__ == "__main__":
    main()
