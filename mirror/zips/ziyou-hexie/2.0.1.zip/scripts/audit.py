#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自由河蟹 · 完整报告生成器 v2.0.0
基于AI智能分析，生成结构化报告。

用法: python audit.py <文本文件>
      python audit.py --template

说明: v2.0.0 采用AI智能分析，由AI根据审核标准自主判断。
"""

import json
import sys
from pathlib import Path
from datetime import datetime

# ──────────────────────────────────────────────
# 路径配置
# ──────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent
RULES_DIR = SCRIPT_DIR.parent / "rules"


def load_version():
    """加载版本信息"""
    version_file = RULES_DIR / "version.json"
    with open(version_file, "r", encoding="utf-8") as f:
        return json.load(f)


def load_standards():
    """加载审核标准"""
    dimensions = ["d", "e", "f", "g", "h"]
    standards = {}

    for dim in dimensions:
        file_path = RULES_DIR / f"dimension_{dim}.json"
        if file_path.exists():
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                standards[f"D{len(dimensions)}"] = data

    return standards


def generate_template_report():
    """生成报告模板"""
    version_info = load_version()

    template = f"""# 自由河蟹 · 内容检查报告

**报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**技能版本**: v{version_info['skill_version']}
**分析架构**: AI智能分析

---

## 一、检查维度说明

| 维度 | 名称 | 说明 |
|:---|:---|:---|
| D1 | 政治导向 | 政治立场正确，符合国家政策 |
| D2 | 行为导向 | 鼓励正向行为，不引导不良行为 |
| D3 | 吉祥导向 | 符合中国人传统美好愿景 |
| D4 | 诚信导向 | 传递诚实守信的正向价值观 |
| D5 | 文明导向 | 语言文明得体 |

## 二、检查标准

### D1 政治导向
- 是否维护国家形象和民族尊严
- 是否符合国家法律法规和政策导向
- 是否存在分裂国家的倾向

### D2 行为导向
- 内容是否在鼓励正向行为
- 是否存在引导不良行为的倾向

### D3 吉祥导向
- 是否涉及消极负面的暗示
- 是否符合积极向上的表达习惯

### D4 诚信导向
- 是否存在欺骗性质的内容描述
- 是否存在推卸责任、回避担当的倾向

### D5 文明导向
- 语言是否文明得体
- 是否存在不当用语

## 三、检查结果

<!-- 由AI根据上述标准进行分析 -->

### 3.1 总体评估

<!-- AI填写：总体评分和维度通过情况 -->

### 3.2 问题清单

<!-- AI填写：发现的问题和修改建议 -->

| 序号 | 维度 | 位置 | 问题描述 | 修改建议 |
|:---|:---|:---|:---|:---|
| 1 | D3 | 第X段 | ... | ... |
| 2 | D2 | 第X句 | ... | ... |

---

**报告说明**: 本报告由AI根据正向价值观导向自主分析生成。
如需实际检查，请通过主技能输入待审文本。
"""
    return template


def main():
    print("自由河蟹 · 报告生成器 v2.0.0")
    print()

    version_info = load_version()
    print(f"技能版本: v{version_info['skill_version']}")
    print(f"分析架构: {version_info['architecture']}")
    print()

    if len(sys.argv) < 2:
        print("用法:")
        print("  python audit.py --template   生成报告模板")
        print("  python audit.py <文件>       读取文件生成报告")
        print()
        template = generate_template_report()
        print("=" * 60)
        print("【报告模板预览】")
        print("=" * 60)
        print(template)
        return

    if sys.argv[1] == "--template":
        template = generate_template_report()
        output_file = RULES_DIR.parent / "docs" / "AUDIT_TEMPLATE.md"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(template)
        print(f"报告模板已生成: {output_file}")
        return

    # 读取文件
    filepath = sys.argv[1]
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        print(f"已读取文件: {filepath}")
        print(f"   字符数: {len(content)}")
        print()
        print("=" * 60)
        print("【分析说明】")
        print("=" * 60)
        print()
        print("v2.0.0 版本采用AI智能分析：")
        print("- 不依赖固定规则库匹配")
        print("- 根据审核标准自主判断")
        print("- 结合语境综合分析")
        print()
        print("如需完整分析，请将文本内容发送给主技能。")
        print()
        print("检查维度：")
        standards = load_standards()
        for key, data in standards.items():
            print(f"  {key.upper()}: {data.get('dimension_name', '未知')}")
        print()
        print("=" * 60)

    except FileNotFoundError:
        print(f"文件不存在: {filepath}")
        sys.exit(1)
    except Exception as e:
        print(f"读取文件出错: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
