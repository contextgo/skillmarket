# 推荐语音列表

## 中文普通话

| 语音 | 性别 | 风格 |
|------|------|------|
| zh-CN-XiaoxiaoNeural | 女 | 温暖自然，新闻/小说 |
| zh-CN-YunxiNeural | 男 | 阳光活泼， Novel |
| zh-CN-YunyangNeural | 男 | 新闻播音，专业可靠 |
| zh-CN-XiaoyiNeural | 女 | 动画/小说，可爱 |
| zh-CN-YunjianNeural | 男 | 体育/小说，激情 |
| zh-CN-YunxiaNeural | 男 | 动画/小说，童声 |
| zh-CN-liaoning-XiaobeiNeural | 女 | 东北话方言，幽默 |
| zh-CN-shaanxi-XiaoniNeural | 女 | 陕西话方言，明快 |

## 粤语

| 语音 | 性别 | 风格 |
|------|------|------|
| zh-HK-HiuGaaiNeural | 女 | 友好，自然 |
| zh-HK-HiuMaanNeural | 女 | 友好，自然 |
| zh-HK-WanLungNeural | 男 | 友好，自然 |

## 英文

| 语音 | 性别 | 风格 |
|------|------|------|
| en-US-AriaNeural | 女 | 新闻/小说，自信 |
| en-US-EmmaNeural | 女 | 对话，活泼清晰 |
| en-US-GuyNeural | 男 | 新闻，激情 |
| en-US-JennyNeural | 女 | 友好，关怀 |
| en-AU-NatashaNeural | 女 | 澳大利亚女声 |
| en-GB-LibbyNeural | 女 | 英式，友好 |

## 日语

| 语音 | 性别 | 风格 |
|------|------|------|
| ja-JP-NanamiNeural | 女 | 自然 |
| ja-JP-KeitaNeural | 男 | 自然 |

---

使用 `--list` 参数可查看完整 300+ 语音列表。
