---
name: edge-tts
description: Edge TTS 语音合成工具。当用户要求文字转语音、用 Edge TTS 说话、播放音频、配置 TTS、安装语音合成、或提到"读出来"、“语音回答”时触发。
---

# Edge TTS

微软 Edge 在线语音合成，无需 API Key，完全免费。

## 依赖

- `edge-tts` — 文本转 MP3
- `pyglet` — 无头音频播放

## 脚本

| 脚本 | 作用 |
|------|------|
| `scripts/tts_edge.py` | 文字转 MP3（Edge TTS）|
| `scripts/tts_play.py` | MP3 无头播放（pyglet）|

## 运行方式

```bash
# 核心用法（合成 + 播放）
uv run --with edge-tts --with pyglet python <skill>/scripts/tts_edge.py "文本" --play

# 只合成，不播放
uv run --with edge-tts python <skill>/scripts/tts_edge.py "文本"

# 播放已有音频
uv run --with pyglet python <skill>/scripts/tts_play.py audio.mp3

# 列出所有可用语音
uv run --with edge-tts python <skill>/scripts/tts_edge.py --list
```

## 参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--voice, -v` | 语音名称 | zh-CN-XiaoxiaoNeural |
| `--rate, -r` | 语速，如 `+10%`、`-5%` | +0% |
| `--pitch, -p` | 音调，如 `+5Hz`、`-10Hz` | +0Hz |
| `--volume` | 音量，如 `+10%`、`-5%` | +0% |
| `--output, -o` | 输出文件路径 | 自动生成 |
| `--play` | 合成后自动播放 | 关闭 |
| `--list` | 列出所有语音并退出 | 关闭 |

## 推荐中文语音

| 语音 | 性别 | 风格 |
|------|------|------|
| zh-CN-XiaoxiaoNeural | 女 | 温暖（默认）|
| zh-CN-YunxiNeural | 男 | 阳光、活泼 |
| zh-CN-YunyangNeural | 男 | 新闻播音，专业 |
| zh-CN-XiaoyiNeural | 女 | 可爱，动画腔 |
| zh-HK-HiuGaaiNeural | 女 | 粤语 |

完整语音列表见 `references/voices.md`。

## 完整示例

```bash
# 中文女声，温暖语气
uv run --with edge-tts --with pyglet python <skill>/scripts/tts_edge.py "好的，我来帮你处理" --voice zh-CN-XiaoxiaoNeural --play

# 男声，加快语速
uv run --with edge-tts --with pyglet python <skill>/scripts/tts_edge.py "快点说完了" -v zh-CN-YunxiNeural -r +20% --play

# 播客新闻腔
uv run --with edge-tts --with pyglet python <skill>/scripts/tts_edge.py "今日新闻播报" -v zh-CN-YunyangNeural --play
```

## 安装依赖（如未安装）

```bash
uv pip install --system edge-tts
uv pip install --system pyglet
```

Windows 上如遇 "externally managed" 报错，改用：
```bash
uv pip install --python python edge-tts
uv pip install --python python pyglet
```
