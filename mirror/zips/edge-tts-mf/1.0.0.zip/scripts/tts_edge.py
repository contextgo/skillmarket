#!/usr/bin/env python3
"""
Edge TTS 语音合成脚本
用法:
  uv run python scripts/tts_edge.py "要说话的文本"
  uv run python scripts/tts_edge.py "文本" --voice zh-CN-XiaoxiaoNeural
  uv run python scripts/tts_edge.py "文本" --rate +10% --pitch +5Hz
  uv run python scripts/tts_edge.py "文本" --output output.mp3
"""

import argparse
import asyncio
import os
import sys
from pathlib import Path

try:
    import edge_tts
except ImportError:
    print("Error: edge-tts not installed")
    print("Run: uv pip install --system edge-tts  (or uv run --with edge-tts python ...)")
    sys.exit(1)


def parse_args():
    parser = argparse.ArgumentParser(description="Edge TTS voice synthesis")
    parser.add_argument("text", help="Text to synthesize")
    parser.add_argument("--voice", "-v", default="zh-CN-XiaoxiaoNeural",
                        help="语音名称 (默认: zh-CN-XiaoxiaoNeural)")
    parser.add_argument("--rate", "-r", default="+0%",
                        help="语速变化，如 +10%% 或 -5%% (默认: +0%%)")
    parser.add_argument("--pitch", "-p", default="+0Hz",
                        help="音调变化，如 +5Hz 或 -10Hz (默认: +0Hz)")
    parser.add_argument("--volume", default="+0%",
                        help="音量变化，如 +10%% 或 -5%% (默认: +0%%)")
    parser.add_argument("--output", "-o", default=None,
                        help="输出文件路径 (默认: auto-generated)")
    parser.add_argument("--format", "-f", choices=["audio-16khz-32kbitrate-mono-mp3",
                                                    "audio-24khz-48kbitrate-mono-mp3",
                                                    "audio-24khz-96kbitrate-mono-mp3",
                                                    "webm-24khz-16bit-mono-opus",
                                                    "webm-24khz-16bit-mono-trimmed-opus"],
                        default="audio-24khz-48kbitrate-mono-mp3",
                        help="输出格式 (默认: mp3 48kbps)")
    parser.add_argument("--list", action="store_true",
                        help="列出所有可用语音并退出")
    parser.add_argument("--play", action="store_true",
                        help="Play audio after synthesis (headless mode)")
    return parser.parse_args()


async def list_voices():
    voices = await edge_tts.list_voices()
    voices.sort(key=lambda v: v["Locale"])
    current_locale = None
    for v in voices:
        if v["Locale"] != current_locale:
            print(f"\n=== {v['Locale']} ===")
            current_locale = v["Locale"]
        print(f"  {v['Name']:45s} {v['Gender']:6s}  {', '.join(v['FriendlyName'])}")


async def synthesize(text, voice, rate, pitch, volume, output, format_, play=False):
    communicate = edge_tts.Communicate(
        text,
        voice=voice,
        rate=rate,
        pitch=pitch,
        volume=volume
    )

    if output is None:
        # 自动生成文件名
        safe_text = text[:20].replace(" ", "_").replace("\n", "_")
        safe_text = "".join(c for c in safe_text if c.isalnum() or c in "_-")
        output = f"tts_output_{safe_text}.mp3"

    await communicate.save(output)
    size = os.path.getsize(output)
    print(f"[OK] Saved: {output} ({size:,} bytes)")
    print(f"     Voice: {voice}  Rate: {rate}  Pitch: {pitch}  Volume: {volume}")
    print(f"     Format: {format_}")

    if play:
        # 调用播放器（无头模式）
        import subprocess, sys
        result = subprocess.run(
            [sys.executable,
             str(Path(__file__).parent / "tts_play.py"),
             output],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print(f"[OK] Played successfully")
        else:
            print(f"[WARN] Playback: {result.stderr.strip()}")

    return output


async def main():
    args = parse_args()

    if args.list:
        await list_voices()
        return

    if not args.text.strip():
        print("Error: text cannot be empty")
        sys.exit(1)

    await synthesize(
        text=args.text,
        voice=args.voice,
        rate=args.rate,
        pitch=args.pitch,
        volume=args.volume,
        output=args.output,
        format_=args.format,
        play=args.play
    )


if __name__ == "__main__":
    asyncio.run(main())
