#!/usr/bin/env python3
"""
Speech-to-Text Pipeline
Download audio from URL + transcribe to text using Faster-Whisper
Supports: YouTube, Xiaoyuzhoufm, and any yt-dlp supported site
"""
import sys, os, argparse, subprocess, json, tempfile

if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")


def _check_ffmpeg():
    paths = [
        "ffmpeg",
        r"D:\soft\ffmpeg\ffmpeg-8.1-full_build\bin\ffmpeg.exe",
        r"D:\soft\ffmpeg\bin\ffmpeg.exe",
    ]
    for p in paths:
        try:
            subprocess.run([p, "-version"], capture_output=True, check=True)
            return p
        except Exception:
            continue
    return None


def _ensure_deps():
    deps = [
        ("faster-whisper", "faster_whisper"),
        ("yt-dlp", "yt_dlp"),
    ]
    for pkg, imp in deps:
        try:
            __import__(imp)
        except ImportError:
            print(f"Installing {pkg}...", file=sys.stderr)
            subprocess.run([sys.executable, "-m", "pip", "install", pkg, "-q"], check=True)


def get_audio_url(url):
    """Extract direct audio URL from page via yt-dlp."""
    result = subprocess.run(
        ["python", "-m", "yt_dlp", "--dump-json", "--no-download", url],
        capture_output=True, text=True
    )
    for line in result.stdout.splitlines():
        if line.startswith("{"):
            info = json.loads(line)
            direct_url = info.get("url")
            if direct_url:
                return direct_url, info.get("ext", "m4a")
    return None, None


def download_audio(url, output_dir=None):
    """Download audio from URL. Returns local file path."""
    _ensure_deps()
    if output_dir is None:
        output_dir = tempfile.gettempdir()
    os.makedirs(output_dir, exist_ok=True)

    direct_url, ext = get_audio_url(url)

    if direct_url:
        out_path = os.path.join(output_dir, f"audio_source.{ext}")
        print(f"Downloading to {out_path}...", file=sys.stderr)
        subprocess.run(
            ["python", "-m", "yt_dlp", "-o", out_path, "--", direct_url],
            check=True, capture_output=True
        )
        return out_path
    else:
        out_template = os.path.join(output_dir, "audio_source.%(ext)s")
        subprocess.run(
            ["python", "-m", "yt_dlp", "-o", out_template,
             "--extract-audio", "--audio-format", "m4a", url],
            check=True
        )
        for f in os.listdir(output_dir):
            if f.startswith("audio_source"):
                return os.path.join(output_dir, f)

    raise RuntimeError("Failed to download audio")


def transcribe(audio_path, model_size="base", language="zh", quantization="int8"):
    """Transcribe audio to text using Faster-Whisper."""
    _ensure_deps()
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "faster-whisper", "-q"],
            check=True
        )
        from faster_whisper import WhisperModel

    try:
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        device = "cpu"

    compute_type = quantization if device == "cpu" else "float16"
    os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    os.environ["HF_HUB_OFFLINE"] = "1"  # Use local cache only, no network

    # Reuse existing model cache from fast-whisper skill
    skill_cache = r"C:\Users\36390\.openclaw-autoclaw\skills\fast-whisper-1.0.0\models"
    cache_dir = skill_cache if os.path.exists(skill_cache) else os.path.join(os.path.dirname(__file__), ".models")
    os.makedirs(cache_dir, exist_ok=True)

    print(f"Loading model {model_size} on {device}...", file=sys.stderr)
    model = WhisperModel(
        model_size, device=device,
        compute_type=compute_type,
        download_root=cache_dir
    )

    ffmpeg = _check_ffmpeg()
    wav_path = audio_path + ".wav"
    if ffmpeg:
        subprocess.run([
            ffmpeg, "-i", audio_path,
            "-ar", "16000", "-ac", "1",
            "-hide_banner", "-loglevel", "error", wav_path
        ], check=True)
        transcribe_path = wav_path
    else:
        transcribe_path = audio_path

    segments, info = model.transcribe(
        transcribe_path,
        language=language if language != "auto" else None,
        beam_size=5,
        vad_filter=True
    )

    texts = [seg.text.strip() for seg in segments]
    result = "".join(texts)

    if wav_path != transcribe_path and os.path.exists(wav_path):
        try:
            os.remove(wav_path)
        except Exception:
            pass

    return result


def pipeline(url, output_dir=None, model_size="base",
             language="zh", quantization="int8",
             download_only=False):
    """Full pipeline: download audio + transcribe."""
    audio_path = download_audio(url, output_dir)
    print(f"Audio: {audio_path}", file=sys.stderr)

    if download_only:
        return audio_path

    return transcribe(audio_path, model_size, language, quantization)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Speech-to-Text Pipeline")
    parser.add_argument("url", help="Audio/video URL")
    parser.add_argument("--output", "-o", default=None,
                       help="Output directory for downloaded audio")
    parser.add_argument("--model", "-m", default="base",
                        choices=["tiny", "base", "small", "medium", "large"],
                        help="Whisper model size (default: base)")
    parser.add_argument("--language", "-l", default="zh",
                        help="Language code (default: zh)")
    parser.add_argument("--quantization", "-q", default="int8",
                        choices=["int8", "float16", "float32"],
                        help="Quantization (default: int8)")
    parser.add_argument("--download-only", action="store_true",
                        help="Only download, skip transcription")

    args = parser.parse_args()
    result = pipeline(
        url=args.url,
        output_dir=args.output,
        model_size=args.model,
        language=args.language,
        quantization=args.quantization,
        download_only=args.download_only
    )
    print(result)
