# 离线安装指南

本技能需要网络下载 Whisper 模型。如果你处于网络阻断环境，按以下步骤操作。

---

## 步骤 1：确认网络通畅时预下载模型

在**有网络畅通的环境**（或挂代理），在一台能访问 HuggingFace 的电脑上运行：

```bash
# 安装依赖
pip install faster-whisper yt-dlp

# 预下载所有模型（选择你需要的）
python -c "
from faster_whisper import WhisperModel
for size in ['tiny', 'base', 'small', 'medium']:
    print(f'Downloading {size}...')
    WhisperModel(size, download_root='./whisper_models')
"
```

这会把模型下载到 `./whisper_models/` 目录。

---

## 步骤 2：复制模型到正确位置

将上一步生成的 `whisper_models/` 整个文件夹复制到目标机器的技能目录下：

```
C:\Users\<你的用户名>\.openclaw-autoclaw\skills\speech-to-text\scripts\.models\
```

最终结构应类似：

```
speech-to-text/
└── scripts/
    ├── transcribe.py
    └── .models/
        └── models--Systran--faster-whisper-base/
            └── ...
```

---

## 步骤 3：验证模型可用

```bash
python scripts/transcribe.py --help
python scripts/transcribe.py "https://www.xiaoyuzhoufm.com/episode/69e875e51e94ae6921dfe28e" --download-only
```

如果报 `LocalEntryNotFoundError`，说明模型文件不完整，需要重新执行步骤 1。

---

## 快速检查：模型是否完整

每个模型的 `.models/` 目录里，`snapshots/<hash>/` 下应该有：

```
config.json        （> 0 bytes）
model.bin          （> 10 MB）← 最关键
tokenizer.json     （> 0 bytes）
vocabulary.txt     （> 0 bytes）
```

如果 `model.bin` 是 0 bytes 或缺失，说明下载中途断了，需要重新下载。

---

## 依赖清单

| 依赖 | 用途 | 离线处理 |
|------|------|----------|
| `faster-whisper` | 转录引擎 | pip install 一次即可 |
| `yt-dlp` | 下载音频 | pip install 一次即可 |
| `ffmpeg` | 音频格式转换 | 需要找 Windows 二进制 |
| Whisper 模型 | 转录核心 | 步骤 1-2 的核心 |

### FFmpeg 离线处理

如果没有 ffmpeg，脚本会自动跳过音频预处理，直接用原始文件转录（可能略微影响质量）。如果需要 ffmpeg：

1. 从 https://ffmpeg.org/download.html 下载 Windows 版本
2. 解压到 `D:\soft\ffmpeg\` 或任意目录
3. 确保 `ffmpeg.exe` 在脚本能找到的路径上

---

## 一键安装包（如果有网络）

```bash
pip install faster-whisper yt-dlp
```
