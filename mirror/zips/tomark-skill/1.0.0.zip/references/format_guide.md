# Mammoth 输出格式参考

## Mammoth 转换行为

Mammoth 将 Word 文档转换为 Markdown 时遵循以下规则：

### 标题层级

Word 中的样式映射为 Markdown 标题：

| Word 样式 | Markdown 输出 |
|-----------|---------------|
| Heading 1 | `# 标题` |
| Heading 2 | `## 标题` |
| Heading 3 | `### 标题` |
| Heading 4 | `#### 标题` |
| Heading 5 | `##### 标题` |
| Heading 6 | `###### 标题` |

**注意：** Mammoth 使用内置样式映射，中文文档中的 "标题 1"、"标题 2" 等样式通常能被正确识别。

### 文本格式

| Word 格式 | Markdown 输出 |
|-----------|---------------|
| 粗体 (Bold) | `**文本**` |
| 斜体 (Italic) | `*文本*` |
| 下划线 | 通常忽略（Markdown 无标准下划线语法） |
| 删除线 | `~~文本~~`（部分版本支持） |

### 列表

| Word 列表 | Markdown 输出 |
|-----------|---------------|
| 无序列表 (Bullet) | `- 项目` 或 `* 项目` |
| 有序列表 (Numbered) | `1. 项目` |
| 多级列表 | 缩进 2-4 空格 |

### 其他元素

| Word 元素 | Markdown 输出 |
|-----------|---------------|
| 段落 | 普通文本 + 空行分隔 |
| 表格 | Markdown 表格语法（`| 列1 | 列2 |`） |
| 超链接 | `[文本](URL)` |
| 图片 | `![描述](图片路径)`（图片需单独提取） |
| 页眉/页脚 | 通常忽略 |
| 脚注 | 部分支持 |

---

## 后处理建议

脚本中的 `clean_markdown()` 函数执行以下清理：

1. **合并多余空行**：`\n{3,}` → `\n\n`
2. **去除行尾空白**：每行末尾的空格和制表符

如需额外处理，可在 `clean_markdown()` 中添加：

```python
# 修复中文标点间距（可选）
text = re.sub(r'([\u4e00-\u9fff])\s+([\u4e00-\u9fff])', r'\1\2', text)

# 统一列表符号（可选）
text = re.sub(r'^\* ', '- ', text, flags=re.MULTILINE)
```

---

## 常见问题

### 1. 表格格式错乱

Mammoth 对复杂表格（合并单元格）支持有限。复杂表格可能需要手动调整。

### 2. 图片丢失

Mammoth 默认不提取图片。如需图片：
- 使用 `mammoth.convert_to_markdown(f, convert_image=mammoth.images.img_element)`
- 或先用 Word/WPS 将文档另存为 HTML，再提取图片

### 3. 特殊符号转义

Markdown 特殊字符（`*`, `_`, `#` 等）在原文中出现时会被自动转义为 `\*`, `\_`, `\#`。

---

## 参考链接

- Mammoth GitHub: https://github.com/mwilliamson/python-mammoth
- Mammoth 文档: https://github.com/mwilliamson/python-mammoth#readme
