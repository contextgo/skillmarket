# -*- coding: utf-8 -*-
"""
批量将 .doc/.docx/.wps 转换为 Markdown 格式

策略：
  1. .docx 文件：直接用 mammoth 转换
  2. .doc/.wps 文件：先用 WPS COM 接口转成 .docx，再用 mammoth 转 Markdown

输出目录：原目录下的 markdown_output 文件夹，保留子目录结构

Usage:
    python -X utf8 convert_to_markdown.py

Prerequisites:
    pip install mammoth pywin32
    WPS Office installed (for .doc/.wps files)
"""

import os
import sys
import re
import time
import shutil
import tempfile
import traceback
from pathlib import Path

# ─── 配置 ────────────────────────────────────────────────────────────────────
# 修改这里指向您的源文件夹
SRC_DIR = Path(r"D:\\documents\\source")
OUT_DIR = SRC_DIR / "markdown_output"
TEMP_DIR = Path(__file__).parent / ".." / "temp"
EXTENSIONS = {'.doc', '.docx', '.wps'}

# ─── 强制 UTF-8 输出 ─────────────────────────────────────────────────────────
if hasattr(sys.stdout, 'buffer'):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# ─── 全局 WPS 应用实例（复用，避免频繁启动）────────────────────────────────
_wps_app = None

def get_wps_app():
    global _wps_app
    if _wps_app is None:
        try:
            import pythoncom
            import win32com.client
            pythoncom.CoInitialize()
            _wps_app = win32com.client.Dispatch("KWps.Application")
            _wps_app.Visible = False
        except Exception as e:
            raise RuntimeError(f"无法启动 WPS COM 接口: {e}") from e
    return _wps_app

def quit_wps():
    global _wps_app
    if _wps_app is not None:
        try:
            _wps_app.Quit()
        except Exception:
            pass
        _wps_app = None

# ─── WPS COM 转换 .doc/.wps → .docx ─────────────────────────────────────────
WdSaveFormat_docx = 12  # wdFormatDocumentDefault

def convert_to_docx_via_wps(src_path: Path, out_docx: Path) -> bool:
    """用 WPS COM 把 .doc/.wps 另存为 .docx，成功返回 True"""
    app = get_wps_app()
    doc = None
    try:
        doc = app.Documents.Open(str(src_path), ReadOnly=True)
        doc.SaveAs(str(out_docx), FileFormat=WdSaveFormat_docx)
        doc.Close(SaveChanges=False)
        return True
    except Exception as e:
        if doc:
            try:
                doc.Close(SaveChanges=False)
            except Exception:
                pass
        raise RuntimeError(f"WPS COM 转换失败: {e}") from e

# ─── mammoth .docx → Markdown ────────────────────────────────────────────────
def docx_to_markdown(docx_path: Path) -> str:
    """用 mammoth 把 .docx 转为 Markdown"""
    import mammoth
    with open(docx_path, "rb") as f:
        result = mammoth.convert_to_markdown(f)
    return result.value

# ─── 后处理：清理多余空行、修复标点 ─────────────────────────────────────────
def clean_markdown(text: str) -> str:
    # 去除超过两个连续空行
    text = re.sub(r'\n{3,}', '\n\n', text)
    # 去除行尾空白
    text = '\n'.join(line.rstrip() for line in text.splitlines())
    return text.strip()

# ─── 主转换函数 ──────────────────────────────────────────────────────────────
def convert_file(src: Path, out_md: Path, temp_dir: Path = None) -> tuple[bool, str]:
    """
    转换单个文件，返回 (成功, 信息)
    
    Args:
        src: 源文件路径 (.doc, .docx, .wps)
        out_md: 输出 Markdown 文件路径
        temp_dir: 临时目录（用于 .doc/.wps 转 .docx），可选
    
    Returns:
        (bool, str) — (是否成功, 信息/错误原因)
    """
    ext = src.suffix.lower()
    out_md.parent.mkdir(parents=True, exist_ok=True)

    try:
        if ext == '.docx':
            # 直接 mammoth 转换
            md_text = docx_to_markdown(src)
        elif ext in ('.doc', '.wps'):
            # 先通过 WPS COM 转为 .docx
            if temp_dir is None:
                temp_dir = TEMP_DIR
            temp_dir.mkdir(parents=True, exist_ok=True)
            tmp_docx = temp_dir / (src.stem + '_tmp.docx')
            try:
                convert_to_docx_via_wps(src, tmp_docx)
                md_text = docx_to_markdown(tmp_docx)
            finally:
                if tmp_docx.exists():
                    tmp_docx.unlink()
        else:
            return False, f"不支持的格式: {ext}"

        md_text = clean_markdown(md_text)

        if not md_text.strip():
            return False, "转换结果为空"

        out_md.write_text(md_text, encoding='utf-8')
        return True, f"成功 ({len(md_text)} 字符)"

    except Exception as e:
        return False, str(e)

# ─── 批量转换主程序 ──────────────────────────────────────────────────────────
def main():
    # 收集所有需要转换的文件
    all_files = [
        p for p in SRC_DIR.rglob('*')
        if p.suffix.lower() in EXTENSIONS
        and 'markdown_output' not in str(p)
    ]
    total = len(all_files)
    
    if total == 0:
        print(f"在 {SRC_DIR} 下未找到 .doc/.docx/.wps 文件")
        return
    
    print(f"共发现 {total} 个文件需要转换\n")

    results = {'success': [], 'failed': []}

    for idx, src in enumerate(all_files, 1):
        rel = src.relative_to(SRC_DIR)
        out_md = OUT_DIR / rel.with_suffix('.md')

        print(f"[{idx:3d}/{total}] {rel} ...", end=' ', flush=True)
        ok, msg = convert_file(src, out_md)

        if ok:
            results['success'].append((rel, msg))
            print(f"✓ {msg}")
        else:
            results['failed'].append((rel, msg))
            print(f"✗ {msg}")

    # 关闭 WPS
    quit_wps()

    # 生成报告
    report_lines = [
        "# 批量转换报告",
        "",
        f"- 总文件数：{total}",
        f"- 成功：{len(results['success'])}",
        f"- 失败：{len(results['failed'])}",
        "",
        "## 成功文件",
        "",
    ]
    for rel, msg in results['success']:
        report_lines.append(f"- {rel}  — {msg}")

    if results['failed']:
        report_lines += ["", "## 失败文件", ""]
        for rel, msg in results['failed']:
            report_lines.append(f"- {rel}  — {msg}")

    report_path = OUT_DIR / "转换报告.md"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    report_path.write_text('\n'.join(report_lines), encoding='utf-8')

    print(f"\n{'='*60}")
    print(f"完成！成功 {len(results['success'])} 个，失败 {len(results['failed'])} 个")
    print(f"输出目录：{OUT_DIR}")
    print(f"报告：{report_path}")


if __name__ == '__main__':
    main()
