# Yunshi — All-in-One Chinese Astrology Skill

> BaZi · ZiWei DouShu · QiMen DunJia · I Ching · Feng Shui · Marriage Compatibility — with daily fortune push. No API required.

[![clawhub](https://img.shields.io/badge/clawhub-yunshi-blue)](https://clawhub.ai/skills/yunshi)
[![version](https://img.shields.io/badge/version-1.2.0-green)](https://clawhub.ai/skills/yunshi)
[![openclaw](https://img.shields.io/badge/openclaw-skill-orange)](https://openclaw.ai)

## What it does

Yunshi is the most comprehensive Chinese astrology skill on clawhub — covering all major traditional divination systems in one install. Built-in algorithms for BaZi and ZiWei DouShu calculations; no external API or subscription needed.

**BaZi (八字)** — Four Pillars birth chart, year/month/day/hour pillars, Da Yun major cycles  
**ZiWei DouShu (紫微斗数)** — Purple Star Astrology full chart with palace interpretations  
**QiMen DunJia (奇门遁甲)** — strategic divination for decision-making  
**I Ching (易经)** — 64 hexagram readings with changing lines  
**Feng Shui (风水)** — home/office layout analysis and recommendations  
**Marriage compatibility (合婚)** — BaZi compatibility analysis for couples  
**Daily fortune push** — daily luck ratings across career, wealth, love, health

## Installation

```bash
openclaw install yunshi
```

## Usage

```bash
# Daily fortune
openclaw run yunshi daily --birth "1990-05-15 08:30" --gender male

# BaZi full chart
openclaw run yunshi bazi --birth "1990-05-15 08:30"

# ZiWei DouShu
openclaw run yunshi ziwei --birth "1990-05-15 08:30" --gender male

# Marriage compatibility
openclaw run yunshi marriage --birth1 "1990-05-15" --birth2 "1992-08-22"

# I Ching divination
openclaw run yunshi meihua

# Feng shui advice
openclaw run yunshi fengshui
```

## Keywords

Chinese astrology · BaZi · Four Pillars · ZiWei DouShu · Purple Star Astrology · QiMen DunJia · I Ching · feng shui · fortune telling · daily horoscope · marriage compatibility · Chinese zodiac · 算命 · 八字 · 紫微斗数 · 奇门遁甲 · 今日运势 · 每日运程 · 合婚 · 风水 · 命理 · 占卜

---

Built for [OpenClaw](https://openclaw.ai) · Published on [clawhub.ai](https://clawhub.ai/skills/yunshi)
