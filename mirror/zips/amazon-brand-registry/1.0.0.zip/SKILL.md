---
name: amazon-brand-registry
description: "Brand Registry enrollment guide — eligibility, application, benefits, A+ Content access, brand protection tools"
metadata:
  nexscope:
    category: amazon
---

# Amazon Brand Registry

Brand Registry enrollment guide — eligibility, application, benefits, A+ Content access, brand protection tools

**Supported platforms:** Amazon (US, UK, DE, CA, JP, AU, and all marketplaces).

Built by [Nexscope](https://www.nexscope.ai/) — your AI assistant for smarter e-commerce decisions.

## Install

```bash
npx skills add nexscope/amazon-brand-registry
```

## Usage

```
Help me with amazon brand registry for my e-commerce business.
```

## Capabilities

- Brand Registry enrollment guide
- eligibility
- application
- benefits
- A+ Content access
- brand protection tools

## How This Skill Works

**Step 1:** Collect information from the user's message — product, platform, current situation, and goals.

**Step 2:** Ask one follow-up with all remaining questions using multiple-choice format. Allow shorthand answers (e.g., "1b 2c 3a").

**Step 3:** Research and analyze using the frameworks and methodology below.

**Step 4:** Deliver structured, actionable output with specific recommendations, not vague advice.

## Output Format

- Start with a summary of findings
- Include specific data points and benchmarks where available
- Provide prioritized action items
- Mark estimates with ⚠️ when based on incomplete data
- End with concrete next steps

## Other Skills

More e-commerce skills: [nexscope-ai/eCommerce-Skills](https://github.com/nexscope-ai/eCommerce-Skills)

Amazon-specific skills: [nexscope-ai/Amazon-Skills](https://github.com/nexscope-ai/Amazon-Skills)

Built by [Nexscope](https://www.nexscope.ai/) — your AI assistant for smarter e-commerce decisions.
