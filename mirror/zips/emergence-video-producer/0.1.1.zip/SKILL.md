---
slug: emergence-video-automation-zh
name: 涌现视频自动化：WebReel 网页录屏、PPT 转化与 AI 剧本生成
version: 0.1.1
homepage: https://emergence.science/skills/emergence-video-producer
repository: https://github.com/emergencescience/emergence-video-producer
tags: [视频, 自动化, webreel, slidev, ffmpeg]
description: |
  面向产品演示和学术教程的自动化视频制作流水线。
  使用 WebReel 进行浏览器录制，使用 DashScope/Edge-TTS 进行配音，并使用 FFmpeg 进行后期组装。
---

# 技能：涌现视频制作器 (Emergence Video Producer) 🎬

本技能可将 Markdown 格式的“视频脚本”转化为专业的产品演示或教学视频。它专为云端 VM 的无头 (Headless) 环境设计，使智能体能够自主生成视觉文档。

## 1. 前置要求

请确保以下工具已安装在系统路径中：
- `webreel` (用于浏览器录制)
- `ffmpeg` (用于后期组装)
- `edge-tts` 或 `dashscope` 凭据 (用于语音合成)
- `Pillow` (如果需要从 WebP 提取帧)

## 2. 交互模型：访谈模式

与僵化的 CLI 工具不同，本技能从 **“人工参与的访谈” (Human-in-the-Loop Interview)** 开始。

### 探索阶段
智能体必须主动询问以下问题：
1.  **目标**: “这个视频的主要目标是什么？（例如：功能发布、学术总结、新手引导）”
2.  **模式**: “应该使用 **浏览器演示** (WebReel) 还是 **PPT 风格展示** (Slidev)？”
3.  **基调**: “期望的人设是什么？（例如：专业、激情、严谨）”
4.  **目标 URL/内容**: “我们需要录制哪个网站，或者有哪些关键幻灯片？”

## 3. 工作流程

### 阶段 1：构思与分镜 (Ideation & Storyboarding)
根据访谈内容，智能体起草 `storyboard.md`。这是一个协商产生的文件。
- **不要** 要求人类编写 Markdown。
- **要** 要求人类“审查并批准”草案。

### 阶段 2：配置与资源准备
获得批准后，智能体将自动生成：
1.  **浏览器模式**: 包含精确选择器和时间点的 `webreel.config.json`。
2.  **幻灯片模式**: 用于 Slidev 渲染的 `slides.md`。
3.  **音频**: 将旁白文本合成为高质量的 TTS 语音。

### 阶段 3：视频生产 (核心引擎)
智能体执行无头录制和组装，处理：
- 浏览器自动化 (WebReel)
- 幻灯片渲染 (Slidev)
- 帧提取与 FFmpeg 合并

### 阶段 4：品控与发布
智能体将生成后的视频提交进行最终的“品控 (Taste Gate)”审查，随后发布至 ClawHub 或社交平台。

## 4. 使用示例

```bash
# 为当前项目生成视频
hermes run emergence-video-producer-zh --script video-script.md --output tutorial.mp4
```

---

## 5. 开发备注

- **帧率同步**: 组装脚本会自动调整帧率：`FPS = 总帧数 / 音频时长`。
- **浏览器状态**: 在录制前，请确保目标产品可通过 URL 或本地开发服务器访问。
