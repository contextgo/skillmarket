# Geriatric Care - Ni Haixia's Approach to Elderly Health

## Fundamental Principles

### Physiological Changes in Aging

Master Ni taught that aging involves **natural decline of Qi, Blood, Yin, and Yang**, but this process can be managed and slowed through proper care:

**Key Physiological Changes**:
1. **Kidney Essence Depletion (肾精亏虚)**: Gradual decline of congenital foundation
2. **Spleen Function Weakening (脾气虚弱)**: Reduced digestive and transformative capacity
3. **Qi and Blood Deficiency (气血亏虚)**: Diminished production and circulation
4. **Yin-Yang Imbalance (阴阳失调)**: Loss of harmonious balance
5. **Channel Obstruction (经络阻滞)**: Accumulation of stagnation over time

**Master Ni's Perspective**:
> "Aging is natural, but decrepitude is not. With proper care, the elderly can maintain vitality and quality of life. The goal is not to reverse aging, but to age with grace and health."

### The Three Pillars of Elderly Care

Master Ni emphasized three fundamental aspects of geriatric health:

**1. Protect the Kidney (护肾)**
- Kidney stores essence and governs aging
- Support Kidney to maintain foundation
- Avoid over-taxing Kidney Qi

**2. Strengthen the Spleen (健脾)**
- Spleen is the source of post-natal Qi
- Maintain digestive function for nourishment
- Foundation for all other treatments

**3. Move the Channels (通络)**
- Prevent stagnation from accumulating
- Maintain circulation of Qi and Blood
- Prevent "obstruction leads to pain"

---

## Common Geriatric Conditions

### 1. Cardiovascular Health (老年心血管病)

**Hypertension (高血压)**

**TCM Understanding**:
Not simply "high blood pressure" but **imbalance of Liver and Kidney**:
- Liver Yang rising (肝阳上亢)
- Kidney Yin deficiency unable to anchor Liver Yang
- Phlegm-dampness obstruction
- Blood stasis in channels

**Pattern Differentiation**:

**Liver Yang Rising (肝阳上亢)**:
- **Symptoms**: Headache, dizziness, red face, irritability, wiry pulse
- **Treatment**: Subdue Liver Yang, nourish Kidney Yin
- **Formula**: **Tian Ma Gou Teng Yin** (Gastrodia and Uncaria Decoction)
  - Tian Ma (Gastrodia) 9g
  - Gou Teng (Uncaria) 12g (add at end)
  - Shi Jue Ming (Abalone Shell) 18g
  - Zhi Zi (Gardenia) 9g
  - Huang Qin (Scutellaria) 9g
  - Du Zhong (Eucommia) 9g
  - Sang Ji Sheng (Loranthus) 9g
  - Ye Jiao Teng (Polygonum) 15g

**Kidney Yin Deficiency (肾阴亏虚)**:
- **Symptoms**: Dizziness, tinnitus, sore lower back, five-center heat
- **Treatment**: Nourish Kidney Yin
- **Formula**: **Liu Wei Di Huang Wan** (Six-Ingredient Pill with Rehmannia)

**Phlegm-Dampness Obstruction (痰湿中阻)**:
- **Symptoms**: Heavy head, chest oppression, nausea, greasy tongue coating
- **Treatment**: Transform phlegm, drain dampness
- **Formula**: **Ban Xia Bai Zhu Tian Ma Tang** (Pinellia, Atractylodes, and Gastrodia Decoction)

**Master Ni's Approach**:
> "Hypertension in the elderly is often Liver Yang rising due to Kidney deficiency. You cannot simply suppress the Yang - you must nourish the Yin to anchor it. Treat the root (Kidney), not just the branch (blood pressure)."

---

**Coronary Heart Disease (冠心病)**

**TCM Understanding**: Chest Bi Syndrome (胸痹) - obstruction of chest Yang

**Patterns**:

**Qi and Yin Deficiency with Blood Stasis (气阴两虚血瘀)**:
- **Symptoms**: Chest tightness, fatigue, palpitations, shortness of breath
- **Treatment**: Tonify Qi and Yin, activate Blood
- **Formula**: **Sheng Mai San** (Generate the Pulse Powder) + **Dan Shen** (Salvia)

**Cold Phlegm Obstructing Chest (寒痰闭阻)**:
- **Symptoms**: Chest pain, cold sensation, pale tongue, deep pulse
- **Treatment**: Warm Yang, transform phlegm, open orifices
- **Formula**: **Gua Lou Xie Bai Bai Jiu Tang** (Trichosanthes, Chinese Garlic, and Wine Decoction)

**Blood Stasis in Heart Channel (心脉瘀阻)**:
- **Symptoms**: Fixed chest pain, purple tongue, choppy pulse
- **Treatment**: Activate Blood, transform stasis
- **Formula**: **Xue Fu Zhu Yu Tang** (Drive Out Stasis from the Mansion of Blood) - modified

**Important Notes**:
- Coordinate with conventional cardiac care
- Never discontinue cardiac medications without medical supervision
- Seek emergency care for acute chest pain

---

### 2. Metabolic Disorders (老年代谢病)

**Diabetes (糖尿病) - Xiao Ke (消渴)**

**TCM Understanding**: Thirsting and Wasting disorder due to Yin deficiency with heat

**Three Types**:

**Upper Xiao (上消) - Lung Heat**:
- **Symptoms**: Excessive thirst, dry mouth, frequent urination
- **Treatment**: Clear Lung heat, generate fluids
- **Formula**: **Xiao Ke Fang** (Thirst-Relieving Formula) or **Bai Hu Tang** modifications

**Middle Xiao (中消) - Stomach Heat**:
- **Symptoms**: Excessive hunger, weight loss, constipation
- **Treatment**: Clear Stomach heat, nourish Yin
- **Formula**: **Yu Nu Jian** (Jade Woman Decoction)

**Lower Xiao (下消) - Kidney Deficiency**:
- **Symptoms**: Frequent urination, especially at night, sore back, fatigue
- **Treatment**: Tonify Kidney, consolidate essence
- **Formula**: **Liu Wei Di Huang Wan** (for Yin deficiency) or **Jin Gui Shen Qi Wan** (for Yang deficiency)

**Master Ni's Integrated Approach**:

**Phase 1: Clear Heat and Generate Fluids** (2-4 weeks)
- Address excessive thirst and hunger
- Formula: Modified Bai Hu Tang + Sheng Mai San

**Phase 2: Nourish Yin and Tonify Kidney** (ongoing)
- Address root deficiency
- Formula: Liu Wei Di Huang Wan + Huang Qi (Astragalus)

**Phase 3: Maintain and Prevent Complications** (long-term)
- Support Spleen and Kidney
- Formula: Gui Pi Tang + Liu Wei Di Huang Wan

**Dietary Management**:
- Avoid simple sugars and refined carbohydrates
- Emphasize bitter melon, Chinese yam, oats
- Regular meal timing
- Moderate portions

---

**Hyperlipidemia (高脂血症)**

**TCM Understanding**: Phlegm-dampness accumulation due to Spleen deficiency

**Treatment Principles**:
1. **Strengthen Spleen** - transform dampness at the source
2. **Transform phlegm** - reduce lipid accumulation
3. **Activate Blood** - improve circulation
4. **Clear heat** - address inflammation

**Formula**: **Jiang Zhi Tang** (Reduce Fat Decoction) - Master Ni's modification
- Shan Zha (Crataegus) 15g - reduces lipids, digests accumulation
- Jue Ming Zi (Cassia Seed) 12g - clears Liver, moistens intestines
- Ze Xie (Alisma) 12g - drains dampness
- He Ye (Lotus Leaf) 9g - raises clear Yang
- Chen Pi (Tangerine Peel) 9g - moves Qi, transforms phlegm
- Da Huang (Rhubarb) 6g - drains heat, moves bowels (use with caution in elderly)

**Lifestyle Recommendations**:
- Regular moderate exercise (walking, Tai Chi)
- Weight management
- Stress reduction
- Adequate sleep

---

### 3. Degenerative Conditions (老年退行性病)

**Osteoarthritis (骨关节炎)**

**TCM Understanding**: Bi Syndrome (痹证) due to channel obstruction

**Patterns**:

**Wind-Cold-Damp Bi (风寒湿痹)**:
- **Symptoms**: Joint pain that moves, worse with cold, better with warmth
- **Treatment**: Expel wind, scatter cold, drain dampness
- **Formula**: **Guan Jian Yan Fang** (Arthritis Formula)
  - Du Huo (Angelica Pubescens) 9g
  - Fang Feng (Saposhnikovia) 9g
  - Qin Jiao (Gentiana Macrophylla) 9g
  - Sang Ji Sheng (Loranthus) 12g
  - Rou Gui (Cinnamon Bark) 3g
  - Chuan Xiong (Ligusticum) 6g

**Damp-Heat Bi (湿热痹)**:
- **Symptoms**: Swollen, hot, red joints
- **Treatment**: Clear heat, drain dampness
- **Formula**: **Si Miao Wan** (Four Marvel Pill) + modifications

**Blood Stasis Bi (血瘀痹)**:
- **Symptoms**: Fixed, stabbing pain, worse at night
- **Treatment**: Activate Blood, transform stasis
- **Formula**: **Shen Tong Zhu Yu Tang** (Drive Out Blood Stasis from a Painful Body Decoction)

**Kidney Deficiency Bi (肾虚痹)**:
- **Symptoms**: Chronic pain, weakness, worse with exertion
- **Treatment**: Tonify Kidney, strengthen bones
- **Formula**: **Du Huo Ji Sheng Tang** (Angelica Pubescens and Sangjisheng Decoction)

**External Treatment**:
- Herbal soaks and poultices
- Acupuncture and moxibustion
- Gentle massage
- Topical herbal preparations

---

**Osteoporosis (骨质疏松)**

**TCM Understanding**: Bone Bi due to Kidney essence deficiency

**Treatment Principles**:
1. **Tonify Kidney essence** - strengthen bone foundation
2. **Nourish Blood** - Blood nourishes bones
3. **Strengthen Spleen** - support nutrient absorption
4. **Move channels** - promote circulation to bones

**Formula**: **Gu Bi Tang** (Bone Strengthening Decoction)
- Shu Di (Rehmannia) 12g - nourish Kidney Yin
- Shan Zhu Yu (Cornus) 12g - tonify Liver and Kidney
- Shan Yao (Chinese Yam) 15g - tonify Spleen and Kidney
- Gu Sui Bu (Drynaria) 15g - strengthen bones
- Bu Gu Zhi (Psoralea) 12g - tonify Kidney Yang
- Du Zhong (Eucommia) 12g - strengthen lower back and bones
- Dang Gui (Angelica) 9g - nourish Blood
- Huang Qi (Astragalus) 15g - tonify Qi

**Dietary Recommendations**:
- Bone broth soups
- Sesame seeds and black beans
- Leafy green vegetables
- Adequate protein
- Vitamin D from sunlight

**Exercise**:
- Weight-bearing exercise (walking, light weights)
- Balance training to prevent falls
- Tai Chi for strength and balance
- Avoid high-impact activities

---

### 4. Cognitive Health (老年认知健康)

**Mild Cognitive Impairment and Dementia (认知障碍与痴呆)**

**TCM Understanding**: Brain marrow (髓海) deficiency due to Kidney essence depletion

**Patterns**:

**Kidney Essence Deficiency (肾精亏虚)**:
- **Symptoms**: Memory loss, confusion, poor concentration, fatigue
- **Treatment**: Tonify Kidney, replenish essence
- **Formula**: **He Che Da Zao Wan** (Placenta Great Creation Pill) or **Di Huang Yin Zi** (Rehmannia Decoction)

**Phlegm Obstructing Orifices (痰浊阻窍)**:
- **Symptoms**: Confusion, heavy head, greasy tongue coating
- **Treatment**: Transform phlegm, open orifices
- **Formula**: **Di Tan Tang** (Scour Phlegm Decoction)

**Blood Stasis Obstructing Brain (瘀血阻脑)**:
- **Symptoms**: Memory loss, headache, purple tongue
- **Treatment**: Activate Blood, transform stasis
- **Formula**: **Tong Qiao Huo Xue Tang** (Unblock the Orifices and Invigorate the Blood Decoction)

**Master Ni's Prevention and Support Protocol**:

**Dietary**:
- Walnuts (he tonifies Kidney)
- Fish (omega-3 fatty acids)
- Leafy greens (folate)
- Berries (antioxidants)

**Mental Exercise**:
- Reading and learning
- Social engagement
- Memory games
- New skill acquisition

**Physical Exercise**:
- Regular walking
- Tai Chi
- Coordination exercises

**Herbal Support**:
- Long-term gentle tonification
- Yuan Zhi (Polygala) - open orifices
- Shi Chang Pu (Acorus) - transform phlegm, open orifices
- Ren Shen (Ginseng) - tonify Qi, benefit intellect

---

### 5. Digestive Health (老年脾胃病)

**Chronic Constipation (老年便秘)**

**Common in elderly due to**:
- Spleen Qi deficiency (weak propulsion)
- Blood deficiency (intestinal dryness)
- Yin deficiency (fluid insufficiency)
- Yang deficiency (cold stagnation)

**Pattern Differentiation**:

**Qi Deficiency Constipation (气虚便秘)**:
- **Symptoms**: Difficult defecation with weak effort, fatigue, pale tongue
- **Treatment**: Tonify Qi, moisten intestines
- **Formula**: **Huang Qi Tang** (Astragalus Decoction) + **Ma Zi Ren Wan** (Hemp Seed Pill)

**Blood Deficiency Constipation (血虚便秘)**:
- **Symptoms**: Dry stools, pale complexion, dizziness
- **Treatment**: Nourish Blood, moisten intestines
- **Formula**: **Run Chang Wan** (Moisten the Intestines Pill)

**Yin Deficiency Constipation (阴虚便秘)**:
- **Symptoms**: Dry, hard stools, thirst, five-center heat
- **Treatment**: Nourish Yin, generate fluids
- **Formula**: **Zeng Ye Tang** (Increase the Fluids Decoction)

**Yang Deficiency Constipation (阳虚便秘)**:
- **Symptoms**: Difficult defecation, cold limbs, clear urine
- **Treatment**: Warm Yang, move bowels
- **Formula**: **Ji Chuan Jian** (Benefit the River Decoction)

**Non-Pharmacological Approaches**:
- Adequate hydration
- Fiber-rich foods
- Regular bowel habits
- Abdominal massage
- Appropriate exercise

---

## Geriatric Dosage Guidelines

### General Principles

**Start Low, Go Slow**:
- Begin with lower doses
- Increase gradually based on tolerance
- Monitor closely for side effects

**Consider Reduced Organ Function**:
- Kidney function decline - reduce nephrotoxic herbs
- Liver function decline - reduce hepatotoxic herbs
- Digestive weakness - use gentle herbs, smaller doses

**Common Adjustments**:
- Reduce standard adult dose by 25-50%
- Use milder herbs when possible
- Avoid strong purgatives
- Be cautious with toxic herbs

### Specific Considerations

**Herbs Requiring Caution**:
- Strong diuretics (may affect electrolytes)
- Blood thinners (interaction with anticoagulants)
- Cardiac herbs (interaction with cardiac medications)
- Strong sedatives (fall risk)

**Herbs Generally Well-Tolerated**:
- Food-grade tonics (Huang Qi, Dang Shen, Shan Yao)
- Gentle Qi tonics
- Mild Blood movers
- Digestive herbs

---

## Lifestyle Recommendations for the Elderly

### Daily Routine

**Morning**:
- Wake naturally when possible
- Gentle stretching or Tai Chi
- Warm breakfast
- Morning bowel routine

**Daytime**:
- Regular light meals
- Moderate activity (walking, gardening)
- Social interaction
- Mental stimulation

**Evening**:
- Light dinner, early
- Gentle walk
- Relaxation activities
- Early to bed

### Seasonal Adjustments

**Spring**: Support Liver, gentle movement
**Summer**: Protect heart, avoid overheating
**Autumn**: Moisten Lung, prepare for winter
**Winter**: Nourish Kidney, store energy

### Exercise Guidelines

**Appropriate Activities**:
- Walking (daily, moderate pace)
- Tai Chi or Qigong
- Gentle swimming
- Light resistance training
- Balance exercises

**Cautions**:
- Avoid high-impact activities
- Prevent falls
- Don't overexert
- Exercise with companion when possible

---

## Master Ni's Key Teachings on Geriatrics

**On Aging**:
> "Aging is natural, but suffering is not. With proper care, the elderly can maintain dignity, vitality, and quality of life. Our role is to support this process."

**On Treatment**:
> "Treat the elderly gently. Their Qi is precious and should not be wasted. Use mild herbs, smaller doses, and longer courses. Patience is essential."

**On Prevention**:
> "Prevention in the elderly means maintaining function, preventing falls, supporting digestion, and keeping the spirit engaged. Start these supports early."

**On Attitude**:
> "The elderly have wisdom and value. Do not dismiss their concerns. Listen carefully, treat respectfully, and honor their life experience."

**On Integration**:
> "The elderly often take multiple medications. Coordinate care with their physicians. Chinese medicine can support and reduce side effects, but safety comes first."

---

*"The twilight years can be the most peaceful and meaningful time of life. Our role as healers is to ensure that our elderly patients can enjoy this time with health and dignity."* — Master Ni Haixia
