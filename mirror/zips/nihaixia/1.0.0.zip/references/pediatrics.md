# Pediatric Care - Ni Haixia's Approach to Children's Health

## Fundamental Principles

### Children's Physiology

Master Ni taught that children have **distinct physiological characteristics** that require modified approaches:

**Vital Characteristics (生理特点)**:
1. **Delicate Yin and Yang (稚阴稚阳)**: Organs are immature, both Yin and Yang are insufficient
2. **Pure Yang Constitution (纯阳之体)**: Children have vigorous growth and development energy
3. **Rapid Transformation (易虚易实)**: Conditions change quickly - can become deficient or excessive rapidly
4. **Clear Organs (脏腑清灵)**: Respond quickly to treatment when correctly diagnosed

**Pathological Characteristics (病理特点)**:
1. **Rapid Onset (发病容易)**: Susceptible to external pathogens due to immature defenses
2. **Rapid Changes (传变迅速)**: Disease progresses quickly; can worsen or improve rapidly
3. **Tendency to Excess (易趋康复)**: Recover quickly with proper treatment
4. **Spleen Vulnerability (脾常不足)**: Digestive system is particularly vulnerable

### The Three Weaknesses (三不足)

Master Ni identified three organ systems as particularly vulnerable in children:

**1. Spleen Deficiency (脾常不足)**
- **Manifestations**: Poor appetite, digestive issues, food accumulation
- **Cause**: Immature digestive capacity, improper feeding
- **Approach**: Always protect Spleen function; gentle tonification

**2. Lung Deficiency (肺常不足)**
- **Manifestations**: Frequent colds, coughs, respiratory infections
- **Cause**: Immature immune defense (Wei Qi)
- **Approach**: Strengthen Lung Qi, protect from external pathogens

**3. Kidney Deficiency (肾常虚)**
- **Manifestations**: Developmental issues, bone/teeth problems
- **Cause**: Congenital foundation still developing
- **Approach**: Support but do not over-tonify; allow natural development

---

## Common Pediatric Conditions

### 1. Common Cold and Fever (小儿感冒发热)

**Understanding Pediatric Fever**:
Master Ni emphasized that **fever in children is not always dangerous** and often represents the body's healthy response:
- Fever indicates the body is fighting pathogens
- Children's "Pure Yang" constitution produces higher fevers
- The key is distinguishing **exterior** vs **interior** patterns

**Exterior Patterns (Taiyang)**:

**Wind-Cold (风寒)**:
- **Symptoms**: Fever, aversion to cold, no sweating, runny nose with clear discharge, cough
- **Tongue**: Pale, thin white coating
- **Treatment**: Release exterior, scatter cold
- **Formula**: **Ma Huang Tang** (Ephedra Decoction) - reduced dosage
  - Ma Huang 3-6g (child dosage)
  - Gui Zhi 3-6g
  - Xing Ren 6g
  - Gan Cao 3g

**Wind-Heat (风热)**:
- **Symptoms**: Fever, slight aversion to wind, sweating, sore throat, yellow nasal discharge
- **Tongue**: Red tip, thin yellow coating
- **Treatment**: Release exterior, clear heat
- **Formula**: **Yin Qiao San** (Honeysuckle and Forsythia Powder) - modified
  - Jin Yin Hua 6g
  - Lian Qiao 6g
  - Jie Geng 3g
  - Niu Bang Zi 6g
  - Bo He 3g (add at end)

**Master Ni's Key Teaching**:
> "Children's fever is like a pot of boiling water. Western medicine puts a lid on it (antipyretics) - the boiling stops but the heat remains. Chinese medicine removes the firewood (releases the exterior) - the boiling stops naturally."

**Important Cautions**:
- Never use strong sweating methods on weak children
- Stop treatment when sweating occurs - do not over-sweat
- Monitor for signs of dehydration
- High fever with altered consciousness requires immediate medical attention

---

### 2. Pediatric Digestive Disorders (小儿脾胃病)

**Food Accumulation (食积)**

**Causes**:
- Overfeeding
- Improper food choices (too rich, too sweet, too cold)
- Eating when emotionally upset
- Irregular meal times

**Symptoms**:
- Poor appetite or excessive hunger
- Abdominal distension
- Foul-smelling stools or constipation
- Bad breath
- Restless sleep
- Irritability

**Treatment Principles**:
1. **Digest accumulated food** (消食)
2. **Move Qi and transform stagnation** (理气导滞)
3. **Strengthen Spleen** (健脾) - after clearing accumulation

**Formula**: **Bao He Wan** (Preserve Harmony Pill) - modified for children
- Shan Zha (Crataegus) 9g - digest meat/fat accumulation
- Shen Qu (Medicated Leaven) 9g - digest grain/starch accumulation
- Lai Fu Zi (Raphanus) 6g - move Qi, reduce distension
- Chen Pi (Tangerine Peel) 6g - move Qi, harmonize Stomach
- Ban Xia (Pinellia) 6g - transform phlegm, descend Stomach Qi
- Fu Ling (Poria) 9g - strengthen Spleen, drain dampness

**Dietary Management**:
- Reduce food intake temporarily
- Simple, warm, easily digestible foods
- Avoid cold drinks and raw foods
- Smaller, more frequent meals

**Master Ni's Teaching**:
> "Most pediatric problems come from the Spleen. Parents overfeed their children with love. 'Eat more, eat more' - this damages the Spleen. A slightly hungry child is healthier than an overfed child."

---

### 3. Pediatric Respiratory Conditions (小儿肺病)

**Chronic Cough and Asthma (小儿咳嗽哮喘)**

**Pattern Differentiation**:

**Acute Phase - External Pathogen**:
- **Wind-Cold**: White phlegm, clear nasal discharge
  - Formula: **Zhi Sou San** (Stop Cough Powder)
- **Wind-Heat**: Yellow phlegm, sore throat
  - Formula: **Sang Ju Yin** (Mulberry Leaf and Chrysanthemum Drink)

**Chronic Phase - Internal Patterns**:

**Phlegm-Heat in Lung (痰热)**:
- **Symptoms**: Cough with yellow thick phlegm, wheezing, rapid breathing
- **Formula**: **Qing Qi Hua Tan Wan** (Clear Qi and Transform Phlegm Pill) - reduced

**Lung and Spleen Deficiency (肺脾两虚)**:
- **Symptoms**: Chronic weak cough, white thin phlegm, poor appetite, fatigue
- **Formula**: **Liu Jun Zi Tang** (Six Gentlemen Decoction) + Xing Su San

**Kidney Failure to Grasp Qi (肾不纳气)**:
- **Symptoms**: Wheezing worse with exertion, cold limbs, frequent urination
- **Formula**: **Jin Gui Shen Qi Wan** (Kidney Qi Pill from Golden Cabinet) - modified

**Master Ni's Asthma Protocol**:

**Acute Attack**:
1. **Relieve wheezing and transform phlegm**
2. **Formula**: Ding Chuan Tang (Arrest Wheezing Decoction)
   - Ma Huang 3g
   - Bai Guo (Ginkgo) 6g
   - Ku Xing Ren (Bitter Apricot) 9g
   - Sang Bai Pi (Mulberry Bark) 9g
   - Huang Qin (Scutellaria) 6g
   - Ban Xia (Pinellia) 9g
   - Kuan Dong Hua (Coltsfoot) 9g

**Chronic Management**:
1. **Tonify Lung and Spleen during remission**
2. **Formula**: Yu Ping Feng San (Jade Screen Powder) + Liu Jun Zi Tang
3. **Duration**: 3-6 months of treatment during remission

**Important Notes**:
- Avoid exposure to cold air during acute phase
- Identify and avoid trigger factors
- Strengthen constitution during remission, not during attacks
- Consider food allergies (common triggers: dairy, wheat, eggs)

---

### 4. Developmental Issues (小儿发育迟缓)

**Delayed Development (五迟五软)**

**Five Delays (五迟)**:
1. Delayed standing
2. Delayed walking
3. Delayed teeth eruption
4. Delayed speech
5. Delayed hair growth

**Five Softnesses (五软)**:
1. Soft head (fontanel not closing)
2. Soft neck (cannot hold head up)
3. Soft hands
4. Soft feet
5. Soft muscles

**Root Cause**: Kidney essence deficiency (先天不足)

**Treatment Principles**:
1. **Tonify Kidney and replenish essence** (补肾填精)
2. **Strengthen Spleen to support Kidney** (健脾益肾)
3. **Gentle, long-term treatment**

**Formula**: **Liu Wei Di Huang Wan** (Six-Ingredient Pill with Rehmannia) + modifications
- Shu Di (Rehmannia) 9g
- Shan Zhu Yu (Cornus) 9g
- Shan Yao (Chinese Yam) 9g
- Ze Xie (Alisma) 6g
- Fu Ling (Poria) 9g
- Mu Dan Pi (Moutan) 6g
- **Add**: Tu Si Zi (Cuscuta) 9g, Du Zhong (Eucommia) 9g

**Supporting Measures**:
- Appropriate stimulation and exercise
- Nutritional support
- Patience - development takes time
- Regular monitoring

---

### 5. Pediatric Emotional and Behavioral Issues (小儿情志病)

**Attention and Hyperactivity (小儿多动症)**

**TCM Understanding**:
Not viewed as "disorder" but as **imbalance of Heart and Liver**:
- Heart governs spirit and consciousness
- Liver governs planning and decision-making
- Imbalance leads to restlessness, poor focus

**Patterns**:

**Heart and Liver Fire (心肝火旺)**:
- **Symptoms**: Hyperactive, restless, easily angered, poor sleep
- **Treatment**: Clear Heart and Liver fire, calm spirit
- **Formula**: **Huang Lian Wen Dan Tang** (Coptis Warm the Gallbladder Decoction)

**Heart and Spleen Deficiency (心脾两虚)**:
- **Symptoms**: Poor concentration, easily tired, pale complexion, poor appetite
- **Treatment**: Tonify Heart and Spleen, nourish Blood
- **Formula**: **Gui Pi Tang** (Restore the Spleen Decoction)

**Phlegm-Heat Disturbing Heart (痰热扰心)**:
- **Symptoms**: Fidgety, heavy head, poor memory, greasy tongue coating
- **Treatment**: Transform phlegm, clear heat, calm spirit
- **Formula**: **Gan Mai Da Zao Tang** (Licorice, Wheat, and Jujube Decoction) + Wen Dan Tang

**Non-Medical Approaches**:
- Regular routine and structure
- Limited sugar and stimulants
- Adequate physical activity
- Reduced screen time
- Parental patience and understanding

**Master Ni's Perspective**:
> "Children are not small adults. Their spirit is pure but easily disturbed. Do not suppress their natural energy - guide it. Many 'hyperactive' children simply need appropriate outlets for their Yang energy."

---

## Pediatric Dosage Guidelines

### Age-Based Dosage Calculation

Master Ni provided practical dosage guidelines for children:

| Age | Adult Dosage Percentage | Calculation Method |
|-----|------------------------|-------------------|
| Newborn - 1 year | 1/14 - 1/7 | Very small doses, gentle herbs only |
| 1 - 2 years | 1/7 - 1/5 | Increased gradually |
| 2 - 4 years | 1/5 - 1/4 | Monitor response carefully |
| 4 - 6 years | 1/4 - 1/3 | Can use most formulas |
| 6 - 12 years | 1/3 - 1/2 | Approaching adult physiology |
| 12+ years | 1/2 - 2/3 | Near adult doses |

### Practical Application

**Example**: Adult dose of Gui Zhi is 9g
- For 6-year-old: 9g × 1/3 = 3g
- For 10-year-old: 9g × 1/2 = 4.5g

### Special Considerations

**Reduce Dosage For**:
- Weak or premature children
- Chronic illness
- Strong or toxic herbs
- First-time herbal treatment

**Can Increase Dosage For**:
- Strong, healthy children
- Acute conditions
- Gentle herbs (food-grade)
- When well-tolerated

---

## Pediatric Herbal Administration

### Making Herbs Palatable

**Challenges**: Children often resist bitter herbs

**Solutions**:
1. **Add natural sweeteners**: Honey (for children over 1 year), jujube dates
2. **Concentrated decoctions**: Smaller volume, stronger taste but less to drink
3. **Frequent small doses**: 3-4 small doses instead of 2 large ones
4. **Positive framing**: "Medicine to make you strong"
5. **Reward system**: Follow with something pleasant

### Administration Methods

**Infants (under 1 year)**:
- Use dropper or syringe
- Small amounts frequently
- Mix with breast milk or formula if needed

**Toddlers (1-3 years)**:
- Small cup or spoon
- May use straw
- Offer choices (which cup, which chair)

**Children (3+ years)**:
- Can usually take small cups
- Explain purpose simply
- Involve them in the process

---

## Dietary Therapy for Children

### General Principles

**Master Ni's Pediatric Dietary Advice**:

**DO**:
- Warm, cooked foods
- Simple, natural ingredients
- Regular meal times
- Age-appropriate textures
- Variety of grains, vegetables, proteins

**DON'T**:
- Cold drinks and foods (especially ice cream, cold milk)
- Excessive sweets and processed foods
- Overfeeding
- Irregular eating schedule
- Forcing children to "clean their plate"

### Foods by Condition

**For Weak Digestion**:
- Rice congee (zhou)
- Steamed vegetables
- Small amounts of protein
- Warm ginger tea

**For Cough and Phlegm**:
- Pear (steamed)
- White radish
- Avoid dairy and bananas

**For Poor Appetite**:
- Hawthorn (Shan Zha) tea
- Small, frequent meals
- Pleasant eating environment
- No pressure or coercion

**For Constipation**:
- Steamed sweet potato
- Pear
- Warm water
- Avoid heat-producing foods

---

## Prevention and Health Maintenance

### Strengthening Immunity

**Formula for Prevention**: **Yu Ping Feng San** (Jade Screen Powder)
- Huang Qi (Astragalus) - tonify Qi, strengthen exterior
- Bai Zhu (Atractylodes) - strengthen Spleen
- Fang Feng (Saposhnikovia) - guard against wind

**Usage**: During cold/flu season or when other children are sick

### Seasonal Care

**Spring**: Support Liver, guard against wind
**Summer**: Clear heat, protect fluids
**Late Summer**: Strengthen Spleen, drain dampness
**Autumn**: Moisten Lung, guard against dryness
**Winter**: Nourish Kidney, store essence

### Daily Health Practices

**Sleep**: Ensure adequate sleep for age
**Activity**: Appropriate physical play
**Emotions**: Protect from excessive stress
**Clothing**: Dress appropriately for weather
**Bathing**: Warm baths, not too frequent

---

## Master Ni's Key Teachings on Pediatrics

**On Feeding**:
> "The Spleen is the foundation of the child. Overfeeding damages the Spleen. A child with a slightly empty stomach is healthier than a child with a full stomach. Let them feel hungry before meals."

**On Fever**:
> "Do not fear fever in children. Fear the wrong treatment of fever. Support the body's natural response; do not suppress it."

**On Development**:
> "Each child develops at their own pace. Do not compare. Support their natural development with proper nutrition and care."

**On Treatment**:
> "Children respond quickly to correct treatment. If you do not see improvement in 2-3 days, reconsider your diagnosis."

**On Prevention**:
> "The best medicine for children is proper diet, adequate sleep, and loving care. Herbs treat illness; lifestyle prevents it."

---

*"Children are not small adults. They have their own physiology and pathology. Treat them with gentleness, understanding, and respect for their natural development."* — Master Ni Haixia
