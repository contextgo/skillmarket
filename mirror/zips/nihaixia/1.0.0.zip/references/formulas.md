# Classical Formulas - Ni Haixia's Prescription Guide

## Overview of Jing Fang (Classical Prescriptions)

Master Ni emphasized that classical formulas from the Han Dynasty represent the **highest level of Chinese medical development**. These formulas are:
- Logically constructed based on Six Divisions theory
- Clinically tested over 1800+ years
- Precisely indicated for specific patterns
- Capable of treating both acute and chronic conditions

### Formula Study Method
Master Ni taught students to understand formulas through:
1. **Pattern identification** (Bian Zheng) - matching symptoms to formula indications
2. **Ingredient analysis** - understanding why each herb is included
3. **Modification principles** - adapting formulas to individual cases
4. **Clinical application** - seeing results in practice

---

## Shang Han Lun (Treatise on Cold Damage) Formulas

### Taiyang (Greater Yang) Formulas

#### Gui Zhi Tang (Cinnamon Twig Decoction) 桂枝汤
**Classification**: Taiyang Wind-Stroke (Taiyang Zhong Feng)

**Ingredients**:
- Gui Zhi (Cinnamon Twig) 9g
- Shao Yao (Peony) 9g
- Sheng Jiang (Fresh Ginger) 9g
- Da Zao (Jujube) 12 pieces
- Zhi Gan Cao (Honey-fried Licorice) 6g

**Indications**:
- Floating pulse, aversion to wind, sweating, fever
- Exterior deficiency with sweating
- Harmonizes Ying and Wei Qi

**Mechanism**: Releases exterior, harmonizes Ying and Wei, tonifies deficiency

**Modifications**:
- **Gui Zhi Jia Ge Gen Tang**: Add Ge Gen (Pueraria) for stiff neck and back
- **Gui Zhi Jia Hou Po Xing Zi Tang**: Add Hou Po (Magnolia) and Xing Ren (Apricot) for cough and asthma
- **Gui Zhi Jia Fu Zi Tang**: Add Fu Zi (Aconite) for Yang deficiency with sweating

**Master Ni's Notes**: "This is the foundation of all harmonizing formulas. When Ying and Wei are harmonious, disease cannot enter."

---

#### Ma Huang Tang (Ephedra Decoction) 麻黄汤
**Classification**: Taiyang Cold Damage (Taiyang Shang Han)

**Ingredients**:
- Ma Huang (Ephedra) 9g
- Gui Zhi (Cinnamon Twig) 6g
- Xing Ren (Apricot Kernel) 9g
- Zhi Gan Cao (Honey-fried Licorice) 3g

**Indications**:
- Floating and tight pulse, aversion to cold, no sweating
- Headache, body pain, wheezing
- Exterior excess without sweating

**Mechanism**: Induces sweating, releases exterior, arrests wheezing

**Contraindications**: 
- Do NOT use with sweating (exterior deficiency)
- Do NOT use with weak constitution
- Do NOT use with Yin deficiency

**Master Ni's Notes**: "This is for strong patients with exterior excess. If the patient is weak, this formula will damage Yang. Be careful!"

---

#### Xiao Qing Long Tang (Minor Bluegreen Dragon Decoction) 小青龙汤
**Classification**: Taiyang with Internal Cold-Phlegm

**Ingredients**:
- Ma Huang (Ephedra) 9g
- Shao Yao (Peony) 9g
- Xi Xin (Asarum) 9g
- Gan Jiang (Dried Ginger) 9g
- Gan Cao (Licorice) 9g
- Gui Zhi (Cinnamon Twig) 9g
- Wu Wei Zi (Schisandra) 9g
- Ban Xia (Pinellia) 9g

**Indications**:
- Exterior cold with internal phlegm-cold
- Wheezing, cough with copious white thin phlegm
- Fever, aversion to cold, no sweating
- Floating pulse

**Mechanism**: Releases exterior, transforms phlegm, warms the Lung

**Master Ni's Notes**: "The king of formulas for cold-phlegm asthma. When you see white, watery phlegm and exterior signs, think Xiao Qing Long."

---

### Yangming (Bright Yang) Formulas

#### Bai Hu Tang (White Tiger Decoction) 白虎汤
**Classification**: Yangming Channel Heat (Yangming Jing Zheng)

**Ingredients**:
- Shi Gao (Gypsum) 50g
- Zhi Mu (Anemarrhena) 18g
- Geng Mi (Rice) 18g
- Zhi Gan Cao (Honey-fried Licorice) 6g

**Indications**:
- High fever, profuse sweating, intense thirst
- Flooding pulse (Hong Mai)
- Yangming channel heat pattern

**Mechanism**: Clears intense heat, drains fire, generates fluids

**Modifications**:
- **Bai Hu Jia Ren Shen Tang**: Add Ren Shen (Ginseng) for Qi deficiency with heat
- **Bai Hu Jia Gui Zhi Tang**: Add Gui Zhi for heat with painful joints

**Master Ni's Notes**: "This is for Yangming channel heat - the four bigs: big fever, big sweat, big thirst, big pulse. Not for weak patients!"

---

#### Cheng Qi Tang (Qi-Infusing Decoction) Family 承气汤类

**Da Cheng Qi Tang (Major Qi-Infusing) 大承气汤**
- Da Huang (Rhubarb) 12g
- Hou Po (Magnolia) 15g
- Zhi Shi (Bitter Orange) 12g
- Mang Xiao (Mirabilite) 9g

**Indications**: Severe Yangming organ heat - constipation, abdominal fullness and pain, fever, delirium

**Xiao Cheng Qi Tang (Minor Qi-Infusing) 小承气汤**
- Da Huang (Rhubarb) 12g
- Hou Po (Magnolia) 6g
- Zhi Shi (Bitter Orange) 9g

**Indications**: Moderate Yangming organ heat - constipation, fullness, fever

**Tiao Wei Cheng Qi Tang (Stomach-Regulating Qi-Infusing) 调胃承气汤**
- Da Huang (Rhubarb) 12g
- Mang Xiao (Mirabilite) 9g
- Zhi Gan Cao (Honey-fried Licorice) 6g

**Indications**: Yangming heat with mild constipation

**Master Ni's Notes**: "These formulas drain heat through the bowels. Da Cheng Qi is the strongest - only for severe cases with delirium."

---

### Shaoyang (Lesser Yang) Formulas

#### Xiao Chai Hu Tang (Minor Bupleurum Decoction) 小柴胡汤
**Classification**: Shaoyang Half-Exterior, Half-Interior

**Ingredients**:
- Chai Hu (Bupleurum) 24g
- Huang Qin (Scutellaria) 9g
- Ren Shen (Ginseng) 9g
- Ban Xia (Pinellia) 9g
- Zhi Gan Cao (Honey-fried Licorice) 9g
- Sheng Jiang (Fresh Ginger) 9g
- Da Zao (Jujube) 12 pieces

**Indications**:
- Alternating fever and chills
- Chest and hypochondriac fullness
- Bitter taste, dry throat, dizziness
- Loss of appetite, nausea
- Wiry pulse

**Mechanism**: Harmonizes Shaoyang, releases half-exterior, drains half-interior

**Modifications**:
- **Xiao Chai Hu Jia Mang Xiao Tang**: Add Mang Xiao for heat with constipation
- **Chai Hu Jia Long Gu Mu Li Tang**: Add Long Gu and Mu Li for spirit disturbance

**Master Ni's Notes**: "This is the pivot formula. It can treat hundreds of conditions when the Shaoyang mechanism is disturbed. The most versatile formula in the Shang Han Lun!"

---

### Taiyin (Greater Yin) Formulas

#### Li Zhong Tang (Regulate the Middle Decoction) 理中汤
**Classification**: Taiyin Cold with Spleen Yang Deficiency

**Ingredients**:
- Ren Shen (Ginseng) 9g
- Gan Jiang (Dried Ginger) 9g
- Bai Zhu (Atractylodes) 9g
- Zhi Gan Cao (Honey-fried Licorice) 9g

**Indications**:
- Diarrhea with clear stools, no thirst
- Abdominal pain relieved by warmth
- Vomiting, lack of appetite
- Pale tongue, weak pulse

**Mechanism**: Warms the middle, strengthens Spleen, stops diarrhea

**Modifications**:
- **Fu Zi Li Zhong Tang**: Add Fu Zi (Aconite) for severe Yang deficiency
- **Li Zhong Wan**: Same formula as pills for chronic conditions

**Master Ni's Notes**: "The foundation for all middle-jiao Yang deficiency. When Spleen is cold, everything fails. Warm the middle first!"

---

### Shaoyin (Lesser Yin) Formulas

#### Si Ni Tang (Frigid Extremities Decoction) 四逆汤
**Classification**: Shaoyin Cold with Yang Collapse

**Ingredients**:
- Fu Zi (Aconite) 15g
- Gan Jiang (Dried Ginger) 9g
- Zhi Gan Cao (Honey-fried Licorice) 6g

**Indications**:
- Cold extremities, aversion to cold
- Diarrhea with clear, undigested food
- Lethargy, desire to sleep
- Pale tongue, deep weak pulse
- Yang collapse pattern

**Mechanism**: Rescues devastated Yang, warms the channels, stops diarrhea

**Master Ni's Notes**: "Emergency formula for Yang collapse. When hands and feet are cold and pulse is about to disappear, use this immediately!"

---

#### Huang Lian E Jiao Tang (Coptis and Ass Hide Glue Decoction) 黄连阿胶汤
**Classification**: Shaoyin Heat with Yin Deficiency

**Ingredients**:
- Huang Lian (Coptis) 12g
- Huang Qin (Scutellaria) 6g
- E Jiao (Ass Hide Glue) 9g
- Shao Yao (Peony) 6g
- Ji Zi Huang (Egg Yolk) 2 pieces

**Indications**:
- Insomnia, restlessness, anxiety
- Feverish sensation, night sweats
- Dry mouth and throat
- Red tongue, thin rapid pulse
- Heart-Kidney disharmony

**Mechanism**: Clears Heart fire, nourishes Kidney Yin, calms the spirit

**Master Ni's Notes**: "For Yin deficiency with fire disturbing the Heart. The egg yolk is essential - it enters the Heart to nourish Yin and calm spirit."

---

### Jueyin (Terminal Yin) Formulas

#### Wu Mei Wan (Mume Pill) 乌梅丸
**Classification**: Jueyin Complex Pattern (Mixed Heat and Cold)

**Ingredients**:
- Wu Mei (Mume) 300g
- Xi Xin (Asarum) 18g
- Gan Jiang (Dried Ginger) 30g
- Huang Lian (Coptis) 48g
- Dang Gui (Angelica) 12g
- Fu Zi (Aconite) 18g
- Shu Jiao (Zanthoxylum) 12g
- Gui Zhi (Cinnamon Twig) 18g
- Ren Shen (Ginseng) 18g
- Huang Bai (Phellodendron) 18g

**Indications**:
- Thirst with desire to drink
- Qi rushing upward to heart
- Pain and heat in heart
- Hunger without desire to eat
- Vomiting roundworms (historical use)
- Chronic conditions with mixed patterns

**Mechanism**: Warms the middle, drains heat, calms roundworms, tonifies deficiency

**Master Ni's Notes**: "This is for complex Jueyin patterns - heat above, cold below. Also excellent for chronic digestive disorders with mixed patterns."

---

## Jin Gui Yao Lue (Essential Prescriptions) Formulas

### Blood Stasis Formulas

#### Xue Fu Zhu Yu Tang (Drive Out Stasis from the Mansion of Blood) 血府逐瘀汤
**Classification**: Blood Stasis in the Chest

**Ingredients**:
- Tao Ren (Peach Kernel) 12g
- Hong Hua (Safflower) 9g
- Dang Gui (Angelica) 9g
- Sheng Di (Rehmannia) 9g
- Chuan Xiong (Ligusticum) 6g
- Chi Shao (Red Peony) 6g
- Niu Xi (Achyranthes) 9g
- Jie Geng (Platycodon) 6g
- Chai Hu (Bupleurum) 3g
- Zhi Ke (Bitter Orange) 6g
- Gan Cao (Licorice) 6g

**Indications**:
- Fixed stabbing pain in chest
- Chronic headache with fixed location
- Insomnia, restlessness
- Palpitations
- Purple tongue, choppy pulse

**Mechanism**: Activates Blood circulation, eliminates stasis, moves Qi, stops pain

**Master Ni's Notes**: "For Blood stasis in the chest. When you see fixed pain, purple tongue, think Blood stasis. This formula opens the chest and moves Blood."

---

#### Ge Xia Zhu Yu Tang (Drive Out Stasis Below the Diaphragm) 膈下逐瘀汤
**Classification**: Blood Stasis Below the Diaphragm

**Ingredients**:
- Wu Ling Zhi (Flying Squirrel Feces) 9g
- Dang Gui (Angelica) 9g
- Chuan Xiong (Ligusticum) 6g
- Tao Ren (Peach Kernel) 9g
- Dan Pi (Moutan) 6g
- Chi Shao (Red Peony) 6g
- Wu Yao (Lindera) 6g
- Yan Hu Suo (Corydalis) 6g
- Gan Cao (Licorice) 9g
- Hong Hua (Safflower) 9g
- Xiang Fu (Cyperus) 6g
- Zhi Ke (Bitter Orange) 6g

**Indications**:
- Abdominal masses or pain
- Menstrual disorders with clots
- Fixed abdominal pain
- History of trauma

**Mechanism**: Activates Blood, eliminates stasis, regulates Qi, stops pain

---

### Phlegm-Dampness Formulas

#### Ling Gui Zhu Gan Tang (Poria, Cinnamon, Atractylodes, and Licorice Decoction) 苓桂术甘汤
**Classification**: Phlegm-Dampness Obstructing the Middle

**Ingredients**:
- Fu Ling (Poria) 12g
- Gui Zhi (Cinnamon Twig) 9g
- Bai Zhu (Atractylodes) 6g
- Zhi Gan Cao (Honey-fried Licorice) 6g

**Indications**:
- Fullness in chest and hypochondrium
- Dizziness, vertigo
- Palpitations, shortness of breath
- Cough with white watery phlegm
- Pale swollen tongue, white greasy coating

**Mechanism**: Warms and transforms phlegm-dampness, strengthens Spleen, promotes urination

**Master Ni's Notes**: "The foundation for treating phlegm-dampness. When Spleen fails to transform fluids, phlegm forms. This formula warms and drains."

---

#### Wen Dan Tang (Warm the Gallbladder Decoction) 温胆汤
**Classification**: Gallbladder Heat with Phlegm

**Ingredients**:
- Ban Xia (Pinellia) 9g
- Zhu Ru (Bamboo Shavings) 9g
- Zhi Shi (Bitter Orange) 9g
- Chen Pi (Tangerine Peel) 9g
- Fu Ling (Poria) 9g
- Zhi Gan Cao (Honey-fried Licorice) 6g
- Sheng Jiang (Fresh Ginger) 3g
- Da Zao (Jujube) 2 pieces

**Indications**:
- Nausea, vomiting, acid reflux
- Dizziness, vertigo
- Anxiety, insomnia with vivid dreams
- Bitter taste, sticky mouth
- Greasy yellow tongue coating, wiry slippery pulse

**Mechanism**: Clears Gallbladder heat, transforms phlegm, harmonizes Stomach

**Master Ni's Notes**: "For phlegm-heat disturbing the Heart and Spirit. When patients have anxiety, insomnia, and greasy coating, use Wen Dan Tang."

---

### Women's Health Formulas

#### Jiao Ai Tang (Ass Hide Glue and Mugwort Decoction) 胶艾汤
**Classification**: Chong and Ren Channel Disharmony with Blood Deficiency

**Ingredients**:
- E Jiao (Ass Hide Glue) 6g
- Ai Ye (Mugwort) 9g
- Dang Gui (Angelica) 9g
- Chuan Xiong (Ligusticum) 6g
- Shao Yao (Peony) 12g
- Sheng Di (Rehmannia) 9g
- Gan Cao (Licorice) 6g

**Indications**:
- Uterine bleeding, prolonged menstruation
- Threatened miscarriage
- Abdominal pain during pregnancy
- Blood deficiency patterns

**Mechanism**: Nourishes Blood, stops bleeding, calms the fetus, regulates Chong and Ren

---

#### Dang Gui Shao Yao San (Tangkuei and Peony Powder) 当归芍药散
**Classification**: Blood Deficiency with Water Retention

**Ingredients**:
- Dang Gui (Angelica) 9g
- Shao Yao (Peony) 48g
- Chuan Xiong (Ligusticum) 24g
- Fu Ling (Poria) 12g
- Bai Zhu (Atractylodes) 12g
- Ze Xie (Alisma) 24g

**Indications**:
- Abdominal pain during pregnancy
- Edema, heaviness in limbs
- Blood deficiency with dampness
- Menstrual irregularities

**Mechanism**: Nourishes Blood, harmonizes Liver, strengthens Spleen, drains dampness

**Master Ni's Notes**: "Excellent for pregnancy disorders. Nourishes Blood while draining excess water. Very safe for pregnant women."

---

## Formula Modification Principles

### Adding Herbs (Jia 加)

**For Excess Heat**: Add Shi Gao (Gypsum), Zhi Mu (Anemarrhena), Huang Qin
**For Deficiency Heat**: Add Di Gu Pi (Lycium Bark), Qing Hao (Artemisia)
**For Cold**: Add Gan Jiang (Dried Ginger), Fu Zi (Aconite), Rou Gui (Cinnamon Bark)
**For Phlegm**: Add Ban Xia (Pinellia), Chen Pi (Tangerine Peel), Gua Lou (Trichosanthes)
**For Blood Stasis**: Add Tao Ren (Peach Kernel), Hong Hua (Safflower), Dan Shen
**For Qi Deficiency**: Add Huang Qi (Astragalus), Ren Shen (Ginseng)
**for Blood Deficiency**: Add Dang Gui (Angelica), Shu Di (Rehmannia)

### Subtracting Herbs (Jian 减)

**Remove warming herbs** for heat patterns
**Remove draining herbs** for deficient patients
**Remove moving herbs** for weak or pregnant patients
**Remove drying herbs** for Yin deficiency

### Dosage Adjustments

**Increase dosage** for:
- Severe conditions
- Strong patients
- Acute cases
- Chief herbs in formula

**Decrease dosage** for:
- Mild conditions
- Weak patients
- Chronic cases
- Assistant herbs

---

## Classical Formula Combinations

Master Ni often combined formulas for complex patterns:

**Gui Zhi Tang + Ma Huang Tang**: For exterior conditions with mixed deficiency/excess
**Xiao Chai Hu Tang + Bai Hu Tang**: For Shaoyang with heat
**Li Zhong Tang + Si Ni Tang**: For severe Spleen and Kidney Yang deficiency
**Xue Fu Zhu Yu Tang + Wen Dan Tang**: For Blood stasis with phlegm-heat

---

*"The classical formulas are perfect. Our job is not to change them, but to understand them deeply and apply them correctly."* — Master Ni Haixia
