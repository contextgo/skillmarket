# Miscellaneous Topics - Additional Ni Haixia Teachings

## Women's Health

### Menstrual Disorders

**The Menstrual Cycle in TCM**

Master Ni taught that the menstrual cycle reflects the **harmony of Kidney, Liver, and Spleen**:
- **Kidney**: Stores essence, governs reproduction
- **Liver**: Stores blood, ensures smooth flow
- **Spleen**: Generates blood, holds blood in vessels

**Phases of the Menstrual Cycle**:

**Phase 1: Menstruation (Days 1-5)**
- **Physiology**: Shedding of endometrium
- **Treatment Principle**: Regulate flow, neither too much nor too little
- **Formula**: **Si Wu Tang** (Four Substances Decoction) as base

**Phase 2: Post-Menstrual (Days 6-14)**
- **Physiology**: Follicular development, Yin building
- **Treatment Principle**: Nourish Blood and Yin
- **Formula**: **Ba Zhen Tang** (Eight Treasures Decoction)

**Phase 3: Ovulation (Days 14-16)**
- **Physiology**: Yin peaks, Yang begins to rise
- **Treatment Principle**: Support the transition
- **Formula**: **Nu Jian Yun Yu Tang** (Women's Fertility Decoction)

**Phase 4: Pre-Menstrual (Days 17-28)**
- **Physiology**: Yang warming, Qi movement
- **Treatment Principle**: Move Qi and Blood
- **Formula**: **Xiao Yao San** (Free and Easy Wanderer)

**Common Patterns**:

**Early Periods (月经先期)**:
- **Heat Pattern**: Heavy, bright red flow
  - Treatment: Clear heat, cool blood
  - Formula: **Qing Jing San** (Clear the Menses Powder)
- **Qi Deficiency**: Light, pale flow, fatigue
  - Treatment: Tonify Qi, hold blood
  - Formula: **Bu Zhong Yi Qi Tang** (Tonify the Middle and Augment the Qi)

**Late Periods (月经后期)**:
- **Blood Deficiency**: Scanty, pale flow
  - Treatment: Nourish blood
  - Formula: **Ren Shen Yang Ying Tang** (Ginseng Decoction to Nourish the Nutritive Qi)
- **Cold Pattern**: Dark flow with clots, pain
  - Treatment: Warm channels, scatter cold
  - Formula: **Wen Jing Tang** (Warm the Menses Decoction)

**Irregular Periods (月经先后不定期)**:
- **Liver Qi Stagnation**: Variable timing, emotional component
  - Treatment: Soothe Liver, regulate Qi
  - Formula: **Xiao Yao San** (Free and Easy Wanderer)

**Painful Periods (痛经)**:
- **Qi and Blood Stagnation**: Sharp pain, clots, relief after passing clots
  - Treatment: Move Qi and Blood, relieve pain
  - Formula: **Ge Xia Zhu Yu Tang** (Drive Out Stasis Below the Diaphragm)
- **Cold in Uterus**: Cold pain, better with warmth
  - Treatment: Warm uterus, scatter cold
  - Formula: **Wen Jing Tang** (Warm the Menses Decoction)

---

### Menopausal Syndrome

**Understanding Menopause in TCM**:
- Natural decline of Kidney essence
- Transition from reproductive to wisdom years
- Can be smooth or challenging depending on constitution

**Common Patterns**:

**Kidney Yin Deficiency (肾阴虚)**:
- **Symptoms**: Hot flashes, night sweats, insomnia, irritability, dry mouth
- **Treatment**: Nourish Kidney Yin, clear deficiency fire
- **Formula**: **Liu Wei Di Huang Wan** (Six-Ingredient Pill with Rehmannia) + **Zhi Bai Di Huang Wan** (Anemarrhena, Phellodendron, and Rehmannia)

**Kidney Yang Deficiency (肾阳虚)**:
- **Symptoms**: Cold limbs, fatigue, frequent urination, low libido
- **Treatment**: Warm and tonify Kidney Yang
- **Formula**: **Jin Gui Shen Qi Wan** (Kidney Qi Pill from Golden Cabinet)

**Heart and Kidney Non-Communication (心肾不交)**:
- **Symptoms**: Insomnia, palpitations, anxiety, hot flashes
- **Treatment**: Harmonize Heart and Kidney
- **Formula**: **Tian Wang Bu Xin Dan** (Emperor of Heaven's Special Pill to Tonify the Heart)

**Liver Yang Rising (肝阳上亢)**:
- **Symptoms**: Headache, irritability, dizziness, high blood pressure
- **Treatment**: Subdue Liver Yang, nourish Kidney Yin
- **Formula**: **Qi Ju Di Huang Wan** (Lycium Fruit, Chrysanthemum, and Rehmannia)

**Master Ni's Menopause Support**:

**Dietary**:
- Black sesame seeds (nourish Kidney)
- Soy products (plant estrogens)
- Leafy greens (Blood nourishment)
- Avoid spicy, heating foods

**Lifestyle**:
- Regular exercise (not excessive)
- Stress management
- Adequate sleep
- Social support

**Herbal Support**:
- Long-term gentle tonification
- Adjust as symptoms change
- Support Spleen to aid absorption

---

### Fertility Support

**TCM Understanding of Infertility**:
- Disharmony of Chong and Ren channels
- Kidney deficiency (congenital factor)
- Blood deficiency (nourishment factor)
- Qi stagnation (movement factor)
- Phlegm obstruction (physical blockage)

**Patterns and Treatment**:

**Kidney Deficiency (肾虚)**:
- **Treatment**: Tonify Kidney, nourish essence
- **Formula**: **You Gui Wan** (Restore the Right Kidney Pill) for Yang deficiency
- **Formula**: **Zuo Gui Wan** (Restore the Left Kidney Pill) for Yin deficiency

**Blood Deficiency (血虚)**:
- **Treatment**: Nourish Blood, regulate menses
- **Formula**: **Yang Jing Zhong Yu Tang** (Nourish Essence and Plant Jade Decoction)

**Qi Stagnation and Blood Stasis (气滞血瘀)**:
- **Treatment**: Move Qi, activate Blood
- **Formula**: **Shao Fu Zhu Yu Tang** (Drive Out Stasis in the Lower Abdomen)

**Phlegm-Dampness (痰湿)**:
- **Treatment**: Transform phlegm, drain dampness
- **Formula**: **Qi Gong Wan** (Aroused Uterus Pill) + **Er Chen Tang** (Two-Cured Decoction)

**Master Ni's Fertility Protocol**:

**For Women**:
- Regulate menstrual cycle first
- Support three months before conception attempt
- Continue support through first trimester
- Address both partners when possible

**For Men**:
- Support Kidney essence
- Reduce heat (avoid hot baths, tight clothing)
- Manage stress
- Formula: **Wu Zi Yan Zong Wan** (Five-Seed Progeny Pill)

---

## Pain Management

### Acute Pain

**Headache (头痛)**

**Location-Based Differentiation**:
- **Taiyang (back of head)**: **Qiang Huo Sheng Shi Tang** (Notopterygium Dispel Dampness Decoction)
- **Yangming (forehead)**: **Bai Hu Tang** (White Tiger Decoction) or **Tiao Wei Cheng Qi Tang**
- **Shaoyang (temples)**: **Xiao Chai Hu Tang** (Minor Bupleurum Decoction)
- **Jueyin (top of head)**: **Wu Zhu Yu Tang** (Evodia Decoction)

**Acute Back Pain (急性腰痛)**

**Cold-Damp Pattern**:
- **Formula**: **Gan Jiang Ling Zhu Tang** (Licorice, Ginger, Poria, and Atractylodes Decoction)

**Blood Stasis Pattern**:
- **Formula**: **Shen Tong Zhu Yu Tang** (Drive Out Blood Stasis from a Painful Body Decoction)

**Kidney Deficiency Pattern**:
- **Formula**: **Du Huo Ji Sheng Tang** (Angelica Pubescens and Sangjisheng Decoction)

---

### Chronic Pain

**Fibromyalgia (纤维肌痛)**

**TCM Understanding**: Muscle Bi syndrome with underlying deficiency

**Treatment Approach**:
1. **Address pain**: Move Qi and Blood, relieve pain
2. **Support constitution**: Tonify Qi and Blood
3. **Regulate emotions**: Soothe Liver, calm spirit

**Formula**: **Shi Quan Da Bu Tang** (All-Inclusive Great Tonifying Decoction) + pain-relieving herbs

**Chronic Fatigue Syndrome (慢性疲劳综合征)**

**TCM Understanding**: Multiple system deficiency, often Spleen and Kidney

**Treatment**:
- **Phase 1**: Support Spleen, clear dampness
- **Phase 2**: Tonify Kidney, replenish essence
- **Phase 3**: Regulate Liver, move Qi

**Formula progression**: **Xiang Sha Liu Jun Zi Tang** → **You Gui Wan** → **Xiao Yao San**

---

## Autoimmune Conditions

### Rheumatoid Arthritis (类风湿关节炎)

**TCM Understanding**: Bi Syndrome with underlying deficiency and invasion of pathogenic factors

**Acute Phase (Excess)**:
- **Heat Bi**: **Xuan Bi Tang** (Disband Painful Obstruction Decoction)
- **Cold Bi**: **Wu Tou Tang** (Aconite Decoction)

**Chronic Phase (Deficiency with Excess)**:
- **Formula**: **Du Huo Ji Sheng Tang** (Angelica Pubescens and Sangjisheng Decoction)

**Master Ni's Approach**:
- Address acute attacks first
- Then tonify underlying deficiency
- Long-term management essential
- Integrate with conventional care

---

### Systemic Lupus Erythematosus (系统性红斑狼疮)

**TCM Understanding**: Heat toxin in blood level with underlying Yin deficiency

**Treatment**:
- **Clear heat toxin**: **Xi Jiao Di Huang Tang** (Rhinoceros Horn and Rehmannia Decoction) - modified
- **Nourish Yin**: **Qing Hao Bie Jia Tang** (Artemisia Annua and Soft-Shelled Turtle Shell Decoction)
- **Support long-term**: **Liu Wei Di Huang Wan**

**Important**: Coordinate closely with rheumatologist; do not discontinue conventional medications

---

## Allergies and Immune Conditions

### Allergic Rhinitis (过敏性鼻炎)

**Patterns**:

**Lung Qi Deficiency (肺气虚)**:
- **Symptoms**: Clear nasal discharge, sneezing, worse with cold
- **Treatment**: Tonify Lung Qi, consolidate exterior
- **Formula**: **Yu Ping Feng San** (Jade Screen Powder) + **Cang Er Zi San** (Xanthium Powder)

**Lung Heat (肺热)**:
- **Symptoms**: Yellow nasal discharge, sinus pain
- **Treatment**: Clear Lung heat
- **Formula**: **Xin Yi Qing Fei Yin** (Magnolia Flower Drink to Clear the Lungs)

**Master Ni's Prevention**:
- Strengthen Lung Qi before allergy season
- Avoid cold drinks and raw foods
- Regular Yu Ping Feng San during vulnerable times

---

### Asthma (哮喘)

**Acute Phase**:
- **Cold asthma**: **She Gan Ma Huang Tang** (Belamcanda and Ephedra Decoction)
- **Heat asthma**: **Ding Chuan Tang** (Arrest Wheezing Decoction)

**Chronic/Remission Phase**:
- **Tonify Lung and Kidney**: **Jin Gui Shen Qi Wan** + **Yu Ping Feng San**
- **Transform phlegm**: **San Zi Yang Qin Tang** (Three-Seed Decoction to Nourish One's Parents)

**Master Ni's Key Teaching**:
> "Treat the acute attack to relieve symptoms; treat the remission to prevent recurrence. The real treatment happens when the patient feels well."

---

## Skin Conditions

### Eczema and Dermatitis (湿疹皮炎)

**Acute Phase (Damp-Heat)**:
- **Formula**: **Bi Xie Shen Shi Tang** (Tokoro Decoction to Drain Dampness)
- **External**: **Huang Lian Gao** (Coptis Ointment)

**Chronic Phase (Blood Deficiency with Wind)**:
- **Formula**: **Dang Gui Yin Zi** (Tangkuei Decoction)
- **Nourish blood, moisten dryness, stop itching**

**Dietary Management**:
- Avoid common triggers: shellfish, spicy foods, alcohol
- Support Spleen function
- Identify individual food sensitivities

---

### Acne (痤疮)

**Lung and Stomach Heat (肺胃热盛)**:
- **Formula**: **Pi Pa Qing Fei Yin** (Loquat Leaf Drink to Clear the Lungs)

**Damp-Heat (湿热)**:
- **Formula**: **Yin Chen Hao Tang** (Artemisia Yinchenhao Decoction)

**Blood Stasis (血瘀)**:
- **Formula**: **Tao Hong Si Wu Tang** (Four-Substance Decoction with Safflower and Peach Pit)

---

## Emotional and Mental Health

### Anxiety (焦虑症)

**Heart and Gallbladder Qi Deficiency (心胆气虚)**:
- **Formula**: **An Shen Ding Zhi Wan** (Calm the Spirit and Settle the Will Pill)

**Heart and Kidney Non-Communication (心肾不交)**:
- **Formula**: **Huang Lian E Jiao Tang** (Coptis and Ass Hide Glue Decoction)

**Phlegm-Heat Disturbing Heart (痰热扰心)**:
- **Formula**: **Wen Dan Tang** (Warm the Gallbladder Decoction)

---

### Depression (抑郁症)

**Liver Qi Stagnation (肝气郁结)**:
- **Formula**: **Xiao Yao San** (Free and Easy Wanderer)

**Heart and Spleen Deficiency (心脾两虚)**:
- **Formula**: **Gui Pi Tang** (Restore the Spleen Decoction)

**Phlegm Obstructing Orifices (痰蒙清窍)**:
- **Formula**: **Shi Wei Wen Dan Tang** (Ten-Ingredient Warm the Gallbladder Decoction)

**Master Ni's Holistic Approach**:
- Herbal treatment
- Acupuncture
- Exercise (especially walking)
- Social connection
- Purpose and meaning

---

## Dietary Therapy

### The Five Flavors and Organ Nourishment

**Sour (酸) - Enters Liver**:
- Functions: Astringes, consolidates
- Foods: Lemon, vinegar, plum, tomato
- Use for: Sweating, diarrhea, seminal emission

**Bitter (苦) - Enters Heart**:
- Functions: Drains, dries, hardens
- Foods: Bitter melon, coffee, tea
- Use for: Heat conditions, dampness

**Sweet (甘) - Enters Spleen**:
- Functions: Tonifies, harmonizes, moistens
- Foods: Rice, sweet potato, honey
- Use for: Deficiency, harmonizing formulas

**Pungent/Spicy (辛) - Enters Lung**:
- Functions: Disperses, moves Qi, opens surface
- Foods: Ginger, garlic, onion, pepper
- Use for: Exterior conditions, Qi stagnation

**Salty (咸) - Enters Kidney**:
- Functions: Softens hardness, moistens intestines
- Foods: Seaweed, seafood, salt
- Use for: Constipation, masses

---

### Seasonal Eating

**Spring**: Support Liver - green foods, sour flavors
**Summer**: Support Heart - bitter foods, cooling foods
**Late Summer**: Support Spleen - sweet foods, yellow foods
**Autumn**: Support Lung - pungent foods, white foods
**Winter**: Support Kidney - salty foods, black foods

---

## Lifestyle Recommendations

### Daily Routine (Yang Sheng 养生)

**Rising with the Sun**: Align with natural cycles
**Morning Exercise**: Gentle movement to awaken Yang
**Regular Meals**: Support digestive rhythm
**Evening Wind-Down**: Prepare for restorative sleep
**Sleeping by 11 PM**: Support Liver blood regeneration

### Exercise Principles

**Appropriate for Constitution**:
- Deficient conditions: Gentle exercise (Tai Chi, walking)
- Excess conditions: More vigorous exercise
- Qi stagnation: Movement that promotes flow

**Timing**:
- Morning: Yang-raising exercises
- Evening: Gentle, calming activities

---

## Integration with Modern Medicine

### When to Refer to Western Medicine

**Emergency Conditions**:
- Chest pain, difficulty breathing
- Severe abdominal pain
- Altered consciousness
- High fever with stiff neck
- Severe bleeding

**Conditions Requiring Integrated Care**:
- Cancer
- Diabetes
- Cardiovascular disease
- Autoimmune conditions
- Severe infections

**Master Ni's Approach to Integration**:
> "Use Western medicine for diagnosis and emergency. Use Chinese medicine for chronic conditions, prevention, and quality of life. They can work together when we respect each system's strengths."

---

## Final Wisdom

### Master Ni's Universal Principles

**On Health**:
> "Health is not the absence of disease. It is the harmonious functioning of body, mind, and spirit."

**On Treatment**:
> "Treat the person, not the disease. Each patient is unique, even with the same diagnosis."

**On Prevention**:
> "Prevention is the highest form of medicine. Daily habits determine long-term health."

**On Learning**:
> "Study the classics deeply, practice clinically, and never stop learning. The medicine is vast."

**On Healing**:
> "The physician treats, but nature heals. Our role is to remove obstacles and support the body's innate wisdom."

---

*"The principles of Chinese medicine are simple but profound. Understand Yin and Yang, grasp the Five Elements, master the Six Divisions, and you can treat any condition. But simplicity requires deep study. Do not mistake simple for easy."* — Master Ni Haixia
