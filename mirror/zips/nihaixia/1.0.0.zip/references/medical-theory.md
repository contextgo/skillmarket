# Core Medical Theory - Ni Haixia's Framework

## The Foundation: Classical Prescription (Jing Fang 经方)

### Definition and Scope
Classical Prescription refers to the medical system established by **Zhang Zhongjing** (张仲景) during the Han Dynasty, primarily documented in:
- **Shang Han Lun** (Treatise on Cold Damage, c. 200 CE)
- **Jin Gui Yao Lue** (Essential Prescriptions from the Golden Cabinet)

Master Ni emphasized that Jing Fang is not merely "old formulas" but a complete medical system based on:
1. **Six Divisions (Liu Jing 六经)** - spatial-temporal framework
2. **Yin-Yang differentiation** - fundamental diagnostic principle
3. **Pattern identification (Bian Zheng 辨证)** - matching patterns to formulas
4. **Classical formulas** - time-tested prescriptions with precise indications

### Why Jing Fang Matters
Master Ni taught that Jing Fang represents the **pinnacle of Chinese medical development**:
- Developed during the Han Dynasty when Chinese medicine reached its classical peak
- Based on centuries of clinical observation and refinement
- Logically consistent and clinically verifiable
- Addresses root causes, not just symptoms
- Effective for both acute and chronic conditions

### The Six Divisions (Liu Jing 六经)

#### Taiyang (太阳) - Greater Yang
**Location**: Exterior, surface of the body
**Characteristics**: 
- Most exterior level of pathology
- Defensive (Wei) Qi level
- Governs the surface, skin, muscles

**Key Patterns**:
- **Taiyang Wind-Stroke (中风)**: Floating pulse, aversion to wind, sweating, fever
  - Formula: **Gui Zhi Tang** (Cinnamon Twig Decoction)
- **Taiyang Cold Damage (伤寒)**: Floating and tight pulse, aversion to cold, no sweating, headache, body pain
  - Formula: **Ma Huang Tang** (Ephedra Decoction)

**Clinical Significance**: All external pathologies begin at Taiyang. Proper treatment here prevents deeper penetration.

#### Yangming (阳明) - Bright Yang
**Location**: Interior, gastrointestinal system
**Characteristics**:
- Fullness and excess patterns
- Heat patterns
- Governs the digestive tract

**Key Patterns**:
- **Yangming Channel (经证)**: High fever, profuse sweating, intense thirst, flooding pulse
  - Formula: **Bai Hu Tang** (White Tiger Decoction)
- **Yangming Organ (腑证)**: Constipation, abdominal fullness and pain, fever, delirium
  - Formula: **Cheng Qi Tang** family (Qi-Infusing Decoctions)

**Clinical Significance**: Yangming represents the body's attempt to contain pathology through the digestive system.

#### Shaoyang (少阳) - Lesser Yang
**Location**: Half-exterior, half-interior
**Characteristics**:
- Alternating patterns
- Pivot mechanism between interior and exterior
- Governs the Triple Burner and Gallbladder

**Key Pattern**:
- Alternating fever and chills, chest and hypochondriac fullness, bitter taste, dry throat, dizziness
  - Formula: **Xiao Chai Hu Tang** (Minor Bupleurum Decoction)

**Clinical Significance**: Shaoyang is the "pivot" - treatment here can redirect pathology outward or prevent deeper penetration.

#### Taiyin (太阴) - Greater Yin
**Location**: Spleen and Lung systems
**Characteristics**:
- Cold and deficiency patterns
- Dampness accumulation
- Governs transformation and transportation

**Key Pattern**:
- Abdominal fullness and pain, vomiting, diarrhea, no thirst, pale tongue
  - Formula: **Li Zhong Tang** (Regulate the Middle Decoction)

**Clinical Significance**: Taiyin pathology represents failure of the digestive transformation function.

#### Shaoyin (少阴) - Lesser Yin
**Location**: Heart and Kidney systems
**Characteristics**:
- Deep level pathology
- Affects the root of life (Ming Men)
- Can manifest as cold or heat patterns

**Key Patterns**:
- **Shaoyin Cold**: Aversion to cold, diarrhea with clear stools, lethargy, desire to sleep
  - Formula: **Si Ni Tang** (Frigid Extremities Decoction)
- **Shaoyin Heat**: Fever, irritability, insomnia, dry mouth and throat
  - Formula: **Huang Lian E Jiao Tang** (Coptis and Ass Hide Glue Decoction)

**Clinical Significance**: Shaoyin represents pathology at the deepest organic level - Heart and Kidney, Fire and Water.

#### Jueyin (厥阴) - Terminal Yin
**Location**: Liver and Pericardium systems
**Characteristics**:
- Complex, mixed patterns
- Extreme heat and cold simultaneously
- End-stage pathology

**Key Pattern**:
- Thirst with desire to drink, qi rushing upward to the heart, pain and heat in the heart, hunger without desire to eat
  - Formula: **Wu Mei Wan** (Mume Pill)

**Clinical Significance**: Jueyin represents the body's last defense mechanism - complex patterns requiring sophisticated treatment.

### The Six Division Progression
Master Ni emphasized understanding the **natural progression** of disease through the Six Divisions:

```
Exterior → Interior
Taiyang → Yangming → Shaoyang
   ↓
Taiyin ← Shaoyin ← Jueyin
```

Pathology can:
1. **Progress outward to inward**: Taiyang → Yangming → Shaoyang → Taiyin → Shaoyin → Jueyin
2. **Skip divisions**: Depending on constitution and factors
3. **Reverse**: With proper treatment, pathology can move back toward the exterior

## Yin-Yang Differentiation

### Fundamental Principle
Master Ni taught that **all diagnosis ultimately reduces to Yin-Yang differentiation**:
- **Yang**: Hot, excess, exterior, upward, active, functional
- **Yin**: Cold, deficiency, interior, downward, passive, substantial

### Clinical Application
Every symptom and sign must be classified:

| Yang Signs | Yin Signs |
|------------|-----------|
| Loud voice | Weak, quiet voice |
| Restlessness | Lethargy |
| Thirst with desire for cold drinks | No thirst or desire for warm drinks |
| Constipation | Diarrhea |
| Red face | Pale face |
| Rapid pulse | Slow pulse |
| Fullness that resists pressure | Fullness that likes pressure |

### The Eight Principles (Ba Gang 八纲)
Building on Yin-Yang, Master Ni used the Eight Principles for comprehensive diagnosis:

1. **Yin-Yang** (阴阳): The overarching framework
2. **Exterior-Interior** (表里): Location of pathology
3. **Cold-Heat** (寒热): Nature of the condition
4. **Deficiency-Excess** (虚实): State of Qi and substances

## The Six Health Standards (Liu Da Jian Kang Biao Zhun 六大健康标准)

Master Ni developed this practical framework for assessing patient health:

### 1. Sleep (睡眠)
**Normal**: Falls asleep easily, sleeps through the night, wakes refreshed
**Abnormal**: 
- Difficulty falling asleep (Heart-Kidney disharmony)
- Frequent waking (Liver Qi stagnation, Gallbladder disturbance)
- Early morning waking (Lung deficiency)
- Excessive sleep (Spleen deficiency, Yang deficiency)

### 2. Appetite (食欲)
**Normal**: Regular hunger at mealtimes, enjoys food, stops when full
**Abnormal**:
- No appetite (Spleen deficiency, dampness)
- Excessive hunger (Stomach heat)
- Hunger without desire to eat (Stomach Yin deficiency)
- Cravings for specific flavors (organ imbalances)

### 3. Bowel Movements (大便)
**Normal**: Daily or twice daily, well-formed, easy to pass
**Abnormal**:
- Constipation (heat, dryness, Qi stagnation)
- Diarrhea (cold, dampness, Spleen deficiency)
- Alternating constipation and diarrhea (Liver-Spleen disharmony)
- Undigested food (Spleen Yang deficiency)

### 4. Urination (小便)
**Normal**: 5-7 times daily, pale yellow, sufficient volume
**Abnormal**:
- Scanty, dark urine (heat, dehydration)
- Excessive, clear urine (Kidney Yang deficiency)
- Frequent urination (Kidney Qi deficiency)
- Painful urination (damp-heat in Lower Burner)

### 5. Thirst (口渴)
**Normal**: Mild thirst satisfied by normal drinking
**Abnormal**:
- Excessive thirst (heat, Yin deficiency)
- Thirst without desire to drink (dampness, phlegm)
- Desire for cold drinks (excess heat)
- Desire for hot drinks (cold patterns)

### 6. Body Temperature (体温)
**Normal**: Warm hands and feet, comfortable body temperature
**Abnormal**:
- Heat in palms and soles (Yin deficiency)
- Cold hands and feet (Yang deficiency, Qi stagnation)
- Generalized heat (excess heat, Yin deficiency)
- Generalized cold (Yang deficiency)
- Fever and chills (exterior conditions)

### Clinical Application
Master Ni emphasized that **treatment success should be measured by improvement in these six standards**, not just symptom relief.

## Physical Medicine (Wang Zhen 望诊)

### The Primacy of Observation
Master Ni taught that **visual diagnosis is the highest form of medicine**:
- "The superior physician sees what others cannot see"
- Observation reveals constitution, pathology, and prognosis
- Can diagnose before taking pulse or asking questions

### Key Observation Areas

#### Facial Diagnosis
- **Five Colors**: Blue (Liver), Red (Heart), Yellow (Spleen), White (Lung), Black (Kidney)
- **Complexion**: Luster indicates Qi and Blood sufficiency
- **Specific Areas**: Different face regions correspond to different organs

#### Tongue Diagnosis
- **Body Color**: Pale (deficiency, cold), Red (heat), Purple (stagnation)
- **Coating**: White (cold), Yellow (heat), Greasy (dampness), Peeled (Yin deficiency)
- **Shape**: Swollen (dampness), Thin (Yin deficiency), Deviated (Wind)

#### Eye Diagnosis
- **Sclera**: Yellow (damp-heat), Red (heat)
- **Iris**: Changes indicate organ conditions
- **Canthus**: Inner (Heart), Outer (Gallbladder)

#### Body Structure
- **Build**: Robust (excess), Thin (deficiency)
- **Posture**: Hunched (Kidney deficiency), Stiff (Liver stagnation)
- **Movement**: Agitated (heat, Yang excess), Lethargic (cold, Yin excess)

## The Five Elements (Wu Xing 五行)

### The Generating Cycle (Sheng 生)
```
Wood → Fire → Earth → Metal → Water → Wood
```
- Wood generates Fire (fuel)
- Fire generates Earth (ash)
- Earth generates Metal (minerals)
- Metal generates Water (condensation)
- Water generates Wood (nourishment)

### The Controlling Cycle (Ke 克)
```
Wood controls Earth (roots)
Earth controls Water (dams)
Water controls Fire (extinguishes)
Fire controls Metal (melts)
Metal controls Wood (cuts)
```

### Clinical Application
Master Ni used Five Element theory to:
- Understand organ relationships
- Predict disease progression
- Determine treatment strategies
- Guide preventive care

## Qi, Blood, and Body Fluids

### Qi (气)
**Functions**:
- **Promoting**: Growth, development, organ function
- **Warming**: Body temperature maintenance
- **Defending**: Immune protection
- **Consolidating**: Holding organs and substances in place
- **Transforming**: Metabolic processes

**Types**:
- **Yuan Qi** (Original Qi): From Kidney, foundation of life
- **Zong Qi** (Gathering Qi): From Lungs and diet, powers circulation
- **Ying Qi** (Nutritive Qi): Circulates in blood vessels, nourishes
- **Wei Qi** (Defensive Qi): Circulates exterior, protects

### Blood (血)
**Functions**: Nourishment, moisture, foundation of mental activity
**Relationship with Qi**: 
- "Qi is the commander of Blood"
- "Blood is the mother of Qi"
- Qi moves Blood; Blood nourishes Qi

### Body Fluids (津液)
**Functions**: Moisture, lubrication, component of Blood
**Types**: 
- **Jin** (thin fluids): Sweat, tears, saliva
- **Ye** (thick fluids): Synovial fluid, marrow, brain fluid

## Pathogenic Factors (Bing Yin 病因)

### External Pathogens (Six Excesses)
1. **Wind (风)**: Sudden onset, moving symptoms, aversion to wind
2. **Cold (寒)**: Contraction, pain, clear discharges
3. **Summerheat (暑)**: Seasonal, with dampness, exhaustion
4. **Dampness (湿)**: Heavy, lingering, greasy coating
5. **Dryness (燥)**: Dry symptoms, thirst, scanty fluids
6. **Fire/Heat (火/热)**: Redness, inflammation, rapid pulse

### Internal Pathogens
- **Seven Emotions**: Joy, Anger, Worry, Pensiveness, Sadness, Fear, Shock
- **Diet**: Irregular eating, improper food, overeating
- **Overwork**: Physical, mental, sexual

## Treatment Principles

### Fundamental Approach
1. **Treat the Root (Ben 本)**: Address underlying pattern
2. **Treat the Branch (Biao 标)**: Manage urgent symptoms
3. **When Root and Branch are clear, treat the Root**
4. **When Branch is urgent, treat Branch first**

### Specific Principles
- **Tonify deficiency** (虚则补之)
- **Drain excess** (实则泻之)
- **Warm cold** (寒者热之)
- **Cool heat** (热者寒之)
- **Lift what has sunk** (下者举之)
- **Lower what has risen** (高者抑之)

---

*"Theory without clinical application is empty. Clinical practice without theoretical foundation is blind."* — Master Ni Haixia
