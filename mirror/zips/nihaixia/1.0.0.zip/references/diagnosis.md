# Diagnostic Methods - Ni Haixia's Approach

## The Four Diagnostic Methods (Si Zhen 四诊)

Master Ni taught that comprehensive diagnosis requires all four methods:
1. **Inspection (Wang Zhen 望诊)** - Visual observation
2. **Auscultation and Olfaction (Wen Zhen 闻诊)** - Listening and smelling
3. **Inquiry (Wen Zhen 问诊)** - Asking questions
4. **Palpation (Qie Zhen 切诊)** - Touch, including pulse diagnosis

**Priority**: Master Ni emphasized **Inspection first** - the superior physician sees what others cannot.

---

## 1. Inspection (Wang Zhen 望诊) - Physical Medicine

### The Primacy of Visual Diagnosis
Master Ni was renowned for his diagnostic accuracy through observation alone. He taught:
- "The body never lies"
- "What you see is more reliable than what the patient tells you"
- "Train your eyes to see the invisible"

### Facial Diagnosis (Mian Zhen 面诊)

#### Five Colors and Their Meanings

**Blue/Green (青) - Liver**
- **Normal**: Healthy glow in spring
- **Pathological**: Liver disorders, Wind, Cold, pain, stagnation
- **Location**: Around eyes, temples, sides of face
- **Significance**: Indicates Liver Qi stagnation or Liver Wind

**Red (赤) - Heart**
- **Normal**: Healthy glow in summer
- **Pathological**: Heat, Heart fire, Yin deficiency with fire
- **Location**: Tip of nose, cheeks, forehead
- **Significance**: Excess = Heart fire; Malar flush = Yin deficiency fire

**Yellow (黄) - Spleen**
- **Normal**: Healthy glow in late summer
- **Pathological**: Dampness, Spleen deficiency, jaundice
- **Location**: Center of face, around mouth
- **Significance**: Pale yellow = Spleen deficiency; Bright yellow = damp-heat

**White (白) - Lung**
- **Normal**: Healthy glow in autumn
- **Pathological**: Cold, deficiency, Qi deficiency, Blood deficiency
- **Location**: Forehead, around nose
- **Significance**: Indicates Lung Qi deficiency or Yang deficiency

**Black/Dark (黑) - Kidney**
- **Normal**: Healthy glow in winter
- **Pathological**: Kidney deficiency, Cold, Water retention, Blood stagnation
- **Location**: Under eyes, around mouth
- **Significance**: Dark circles = Kidney deficiency or Blood stagnation

#### Facial Regions and Organ Correspondence

```
        Forehead (Heart)
            ↓
    Left Eye ← → Right Eye (Liver)
    (Liver)     (Liver)
            ↓
        Nose (Spleen)
            ↓
        Mouth (Spleen/Kidney)
            ↓
        Chin (Kidney)
```

### Tongue Diagnosis (She Zhen 舌诊)

Master Ni considered tongue diagnosis second only to facial observation:

#### Tongue Body (She Ti 舌体)

**Color**:
- **Pale**: Qi deficiency, Yang deficiency, Blood deficiency
- **Red**: Heat, Yin deficiency
- **Deep Red**: Severe heat, heat in Ying/Nutritive level
- **Purple**: Blood stagnation, cold stagnation
- **Blue**: Severe cold, Blood stagnation

**Shape**:
- **Swollen**: Dampness, Spleen deficiency, fluid retention
- **Thin**: Blood deficiency, Yin deficiency
- **Cracked**: Yin deficiency (deep cracks), Qi deficiency (shallow cracks)
- **Deviated**: Wind stroke, Liver Wind
- **Tooth-marked**: Spleen deficiency with dampness

**Movement**:
- **Trembling**: Wind, Qi deficiency
- **Stiff**: Heat in Ying level, wind stroke
- **Protruding**: Heat in Heart/Spleen
- **Limp**: Qi deficiency

#### Tongue Coating (She Tai 舌苔)

**Color**:
- **White**: Normal, cold patterns, exterior conditions
- **Yellow**: Heat patterns
- **Gray**: Severe cold or severe heat
- **Black**: Extreme cold (moist) or extreme heat (dry)

**Thickness**:
- **Thin**: Normal or exterior condition
- **Thick**: Interior condition, dampness, food stagnation

**Moisture**:
- **Moist**: Normal or cold/damp patterns
- **Dry**: Heat, Yin deficiency, fluid damage
- **Wet/Slippery**: Cold, dampness

**Quality**:
- **Greasy**: Dampness, phlegm, food stagnation
- **Rooted**: Coating firmly attached (condition has substance)
- **Unrooted**: Coating easily scraped off (deficiency, stomach Qi collapse)

### Eye Diagnosis (Mu Zhen 目诊)

#### Sclera (Bai Ren 白仁)
- **Yellow**: Damp-heat, jaundice
- **Red**: Heat, wind-heat
- **Blue/Purplish**: Liver Wind, convulsions
- **Pale**: Blood deficiency

#### Iris and Pupil
- **Pupil constriction**: Heat, organ damage
- **Pupil dilation**: Cold, collapse, wind stroke
- **Unequal pupils**: Serious condition, stroke

#### Canthus (Inner Corner)
- **Red**: Heart fire
- **Pale**: Blood deficiency
- **Yellow**: Damp-heat

### Body Structure and Posture

#### General Build
- **Robust, muscular**: Excess constitution, Yang type
- **Thin, delicate**: Deficiency constitution, Yin type
- **Obese**: Phlegm-dampness constitution
- **Emaciated**: Severe deficiency, chronic illness

#### Posture Observations
- **Hunched back**: Kidney deficiency
- **Stiff neck**: Taiyang condition, wind invasion
- **Favors one side**: Pain, stagnation on opposite side
- **Cannot lie flat**: Lung congestion, heart failure
- **Restless movement**: Heat, Yang excess
- **Motionless**: Cold, Yin excess, severe deficiency

### Skin Examination

**Color Changes**:
- **Red rashes**: Heat, wind-heat, blood heat
- **White patches**: Blood deficiency, wind
- **Dark patches**: Blood stagnation
- **Yellowing**: Damp-heat, jaundice

**Texture**:
- **Dry, rough**: Blood deficiency, Yin deficiency
- **Oily**: Dampness, phlegm
- **Swollen**: Water retention, dampness

---

## 2. Auscultation and Olfaction (Wen Zhen 闻诊)

### Voice and Speech

**Voice Quality**:
- **Loud, strong**: Excess, Yang condition
- **Weak, quiet**: Deficiency, Yin condition
- **Hoarse**: Lung involvement, Yin deficiency
- **Harsh, rough**: Cold, stagnation

**Speech Patterns**:
- **Incessant talking**: Heat, excess
- **Reluctance to speak**: Cold, deficiency
- **Incoherent**: Heat in Heart, spirit disturbance
- **Delirious**: Heat in Ying level, severe condition

### Breathing

**Respiration**:
- **Loud, coarse**: Excess, heat, asthma
- **Weak, shallow**: Deficiency, Lung Qi deficiency
- **Rapid**: Heat, Qi deficiency
- **Slow**: Cold, stagnation

**Sounds**:
- **Wheezing**: Phlegm, asthma
- **Rattling**: Phlegm in Lungs
- **Sighing**: Liver Qi stagnation
- **Shortness of breath**: Qi deficiency, Lung/Kidney deficiency

### Olfaction

**Body Odor**:
- **Strong, sour**: Heat, damp-heat
- **Foul**: Toxic heat, infection
- **Fishy**: Cold, dampness
- **Sweet/fruity**: Diabetes (wasting-thirst)

**Breath Odor**:
- **Foul**: Stomach heat, food stagnation
- **Sweet**: Spleen damp-heat
- **Fishy**: Lung abscess
- **Urinary**: Kidney failure

**Excretions**:
- **Feces**: Foul = heat; Odorless = cold
- **Urine**: Strong = heat; Weak = cold
- **Sputum**: Foul = heat, infection

---

## 3. Inquiry (Wen Zhen 问诊)

### The Ten Questions (Shi Wen 十问)

Master Ni used a systematic approach to questioning:

#### 1. Chills and Fever (寒热)
- **Aversion to cold + fever**: Exterior condition
- **Fever without aversion to cold**: Interior heat
- **Aversion to cold without fever**: Interior cold, Yang deficiency
- **Alternating fever and chills**: Shaoyang condition

#### 2. Sweating (汗)
- **Spontaneous sweating**: Yang deficiency, Qi deficiency
- **Night sweats**: Yin deficiency
- **Profuse sweating**: Heat, Yang collapse
- **Absence of sweating**: Exterior cold, fluid deficiency

#### 3. Head and Body (头身)
- **Headache location**: 
  - Front = Yangming
  - Sides = Shaoyang
  - Back = Taiyang
  - Top = Liver, Jueyin
- **Body pain**: Exterior condition, Qi stagnation, Blood stagnation
- **Heavy limbs**: Dampness

#### 4. Bowel Movements (便)
- **Constipation**: Heat, dryness, Qi stagnation, Blood deficiency
- **Diarrhea**: Cold, dampness, Spleen deficiency
- **Characteristics**: Color, odor, consistency, presence of mucus or blood

#### 5. Urination (溺)
- **Frequency**: Excessive = Qi deficiency; Scanty = heat, fluid damage
- **Color**: Clear = cold; Yellow = heat; Red = blood, severe heat
- **Volume**: Polyuria = Kidney deficiency; Oliguria = heat, fluid retention

#### 6. Food and Drink (饮食)
- **Appetite**: Present or absent, timing
- **Thirst**: Present or absent, preference for hot/cold
- **Taste preferences**: Cravings indicate organ imbalances
- **Digestion**: Bloating, reflux, nausea

#### 7. Chest and Abdomen (胸腹)
- **Chest**: Fullness, pain, palpitations
- **Epigastrium**: Pain, fullness, reflux
- **Abdomen**: Pain location, quality, radiation
- **Hypochondrium**: Distension, pain (Liver/Gallbladder)

#### 8. Hearing and Vision (耳目)
- **Tinnitus**: High pitch = Kidney Yin deficiency; Low pitch = Kidney Yang deficiency
- **Hearing loss**: Gradual = deficiency; Sudden = excess
- **Vision**: Blurry = Blood/Liver deficiency; Red/painful = heat

#### 9. Sleep (睡)
- **Difficulty falling asleep**: Heart-Kidney disharmony
- **Frequent waking**: Liver Qi stagnation, Gallbladder disturbance
- **Early morning waking**: Lung deficiency
- **Excessive sleep**: Spleen/Yang deficiency

#### 10. Medical History (病史)
- Previous illnesses
- Family history
- Lifestyle factors
- Emotional history

### The Six Health Standards - Inquiry Focus

Master Ni emphasized these six areas in every patient interview:

1. **Sleep quality and patterns**
2. **Appetite and food preferences**
3. **Bowel movement regularity and quality**
4. **Urination frequency, volume, and color**
5. **Thirst levels and fluid preferences**
6. **Body temperature distribution (hands, feet, trunk)**

---

## 4. Palpation (Qie Zhen 切诊)

### Pulse Diagnosis (Mai Zhen 脉诊)

Master Ni was a master pulse diagnostician. He taught that pulse reveals the body's deepest secrets.

#### The Three Positions (San Bu 三部)

Each wrist has three positions:

**Left Wrist**:
- **Cun (寸) - Distal**: Heart
- **Guan (关) - Middle**: Liver
- **Chi (尺) - Proximal**: Kidney (Yin)

**Right Wrist**:
- **Cun (寸) - Distal**: Lung
- **Guan (关) - Middle**: Spleen/Stomach
- **Chi (尺) - Proximal**: Kidney (Yang), Ming Men

#### The 28 Pulse Qualities

Master Ni focused on the most clinically significant:

**Floating (Fu 浮)**
- **Feeling**: Felt lightly at surface, weaker with pressure
- **Significance**: Exterior condition, Yang floating upward
- **Clinical**: Common cold, fever, early stage illness

**Sinking (Chen 沉)**
- **Feeling**: Felt only with deep pressure
- **Significance**: Interior condition, Yin excess
- **Clinical**: Chronic illness, organ pathology

**Slow (Chi 迟)**
- **Feeling**: Less than 4 beats per breath
- **Significance**: Cold patterns
- **Clinical**: Yang deficiency, cold conditions

**Rapid (Shu 数)**
- **Feeling**: More than 5 beats per breath
- **Significance**: Heat patterns
- **Clinical**: Fever, infection, Yin deficiency fire

**Full/Excess (Shi 实)**
- **Feeling**: Strong, forceful, rebounds against finger
- **Significance**: Excess condition
- **Clinical**: Acute illness, excess heat, stagnation

**Empty/Deficient (Xu 虚)**
- **Feeling**: Weak, soft, yields to pressure
- **Significance**: Deficiency condition
- **Clinical**: Chronic illness, Qi/Blood/Yang/Yin deficiency

**Slippery (Hua 滑)**
- **Feeling**: Smooth, flows easily, like pearls on a plate
- **Significance**: Phlegm, dampness, food stagnation, pregnancy
- **Clinical**: Phlegm disorders, digestive issues

**Choppy (Se 涩)**
- **Feeling**: Rough, uneven, difficult flow
- **Significance**: Blood stagnation, fluid deficiency
- **Clinical**: Pain, masses, chronic illness

**Wiry (Xian 弦)**
- **Feeling**: Taut, like a guitar string
- **Significance**: Liver Qi stagnation, pain, phlegm
- **Clinical**: Stress, emotional disorders, Liver patterns

**Tight (Jin 紧)**
- **Feeling**: Tense, like a twisted rope
- **Significance**: Cold, pain, exterior cold
- **Clinical**: Acute pain, cold conditions

**Soggy (Ru 濡)**
- **Feeling**: Floating, thin, soft
- **Significance**: Dampness, Spleen deficiency
- **Clinical**: Damp conditions, Qi deficiency

**Weak (Ruo 弱)**
- **Feeling**: Sinking, thin, soft
- **Significance**: Qi and Blood deficiency
- **Clinical**: Severe deficiency, chronic illness

### Abdominal Palpation (Fu Zhen 腹诊)

Master Ni taught the importance of abdominal examination:

**Temperature**:
- **Cold abdomen**: Yang deficiency, cold patterns
- **Hot abdomen**: Heat, excess patterns
- **Cold lower abdomen**: Kidney Yang deficiency
- **Cold epigastrium**: Spleen Yang deficiency

**Tenderness**:
- **Pain with pressure**: Excess condition
- **Pain relieved by pressure**: Deficiency condition
- **Right lower quadrant**: Intestinal issues
- **Left lower quadrant**: Colon issues
- **Epigastrium**: Stomach disorders

**Palpation Findings**:
- **Masses**: Blood stagnation, phlegm nodules
- **Tension**: Liver Qi stagnation
- **Fluid sounds**: Fluid retention, dampness

### Channel Palpation (Jing Mai Qie 经脉切)

**Ashi Points**:
- Tender points along channels indicate pathology
- Press to find reactive points
- Use for both diagnosis and treatment location

**Channel Temperature**:
- Cold channels indicate deficiency
- Hot channels indicate excess

---

## Diagnostic Synthesis

### The Diagnostic Process

Master Ni taught a systematic approach:

1. **Observe First**: Face, tongue, body - what do you see?
2. **Listen and Smell**: Voice, breath, odors - what do you detect?
3. **Ask Systematically**: The ten questions, focusing on Six Health Standards
4. **Palpate Last**: Pulse, abdomen, channels - confirm your impressions

### Pattern Differentiation (Bian Zheng 辨证)

**Six Divisions (Liu Jing)**:
- Determine which division is primarily affected
- Note if multiple divisions are involved
- Assess progression or regression

**Eight Principles (Ba Gang)**:
- Yin or Yang?
- Exterior or Interior?
- Cold or Heat?
- Deficiency or Excess?

**Organ Patterns (Zang Fu)**:
- Which organs are involved?
- What is the relationship between affected organs?
- Is there organ deficiency or excess?

### Formulating the Diagnosis

Master Ni emphasized:
- **Be specific**: Not just "Liver Qi stagnation" but "Liver Qi stagnation transforming to fire with Spleen deficiency"
- **Identify root and branch**: What is primary? What is secondary?
- **Determine prognosis**: Is this improving or worsening?
- **Guide treatment**: Diagnosis must directly inform formula selection

---

*"The four diagnostic methods are like four legs of a table - remove one and the table falls. Use them all, but trust your eyes first."* — Master Ni Haixia
