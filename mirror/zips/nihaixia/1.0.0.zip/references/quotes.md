# Master Ni Haixia's Core Teachings and Aphorisms

## The 36 Core Aphorisms

Master Ni Haixia distilled his lifetime of medical wisdom into concise, memorable statements. These aphorisms capture the essence of his medical philosophy and serve as guiding principles for practitioners.

---

### On Chinese Medicine Theory

**1. "True Chinese medicine can cure diseases in a single treatment" (一剂知、二剂已)**
- **Meaning**: When the diagnosis is correct and the formula matches the pattern, results should be rapid and dramatic
- **Context**: Classical Prescription medicine should produce immediate, observable changes
- **Application**: If no improvement after 2-3 doses, reconsider the diagnosis

**2. "Chinese medicine is a science of experience, not philosophy"**
- **Meaning**: TCM is based on clinical observation and verification, not abstract theory
- **Context**: Criticism of over-theorization without clinical grounding
- **Application**: Test all theories in clinical practice

**3. "The classics are not history books - they are clinical manuals"**
- **Meaning**: Shang Han Lun and Jin Gui Yao Lue are practical guides, not historical documents
- **Context**: Emphasis on applying classical knowledge to modern patients
- **Application**: Study classics for clinical application, not academic interest

**4. "Pattern identification (Bian Zheng) is the soul of Chinese medicine"**
- **Meaning**: Correct diagnosis of the pattern is more important than the disease name
- **Context**: Differentiation of patterns leads to correct treatment
- **Application**: Always identify the pattern before selecting treatment

**5. "The Six Divisions are the skeleton; the formulas are the flesh"**
- **Meaning**: Understanding Liu Jing (Six Divisions) framework is essential for using formulas correctly
- **Context**: Structural organization of Shang Han Lun
- **Application**: Always locate the condition within the Six Divisions

---

### On Diagnosis

**6. "The superior physician sees what others cannot see" (上工治未病)**
- **Meaning**: True expertise lies in prevention and early detection
- **Context**: Physical examination (Wang Zhen) reveals pathology before symptoms manifest
- **Application**: Develop observational skills to detect subtle signs

**7. "The tongue never lies"**
- **Meaning**: Tongue diagnosis provides objective, reliable information
- **Context**: Patients may not accurately report symptoms, but tongue reveals truth
- **Application**: Always examine the tongue; trust what you see

**8. "The Six Health Standards are your compass"**
- **Meaning**: Sleep, appetite, bowels, urine, thirst, and temperature guide diagnosis and track progress
- **Context**: Practical framework for assessing health
- **Application**: Evaluate all six standards in every patient; use to measure treatment success

**9. "Pulse diagnosis confirms what you already suspect"**
- **Meaning**: Pulse validates findings from inspection and inquiry
- **Context**: Pulse should not contradict other diagnostic findings
- **Application**: Use pulse to confirm, not to discover in isolation

**10. "Ask about bowel movements before you ask about the chief complaint"**
- **Meaning**: Digestive function indicates overall health
- **Context**: Spleen and Stomach are the foundation of post-natal Qi
- **Application**: Always assess digestive function in every patient

---

### On Treatment Principles

**11. "Treat the root when root and branch are clear; treat the branch when it is urgent" (急则治标，缓则治本)**
- **Meaning**: Prioritize based on clinical urgency
- **Context**: Sometimes symptoms must be addressed before root cause
- **Application**: Life-threatening symptoms first; underlying patterns second

**12. "Tonify deficiency and drain excess - this is the Dao of treatment" (虚则补之，实则泻之)**
- **Meaning**: The fundamental treatment principle
- **Context**: All treatments ultimately serve this principle
- **Application**: First determine if condition is deficient or excessive

**13. "Warm cold and cool heat - this is common sense" (寒者热之，热者寒之)**
- **Meaning**: Basic thermodynamic principle of medicine
- **Context**: Nature of condition determines nature of treatment
- **Application**: Cold patterns receive warming treatment; heat patterns receive cooling

**14. "When Yin is balanced and Yang is secreted, the spirit is cured" (阴平阳秘，精神乃治)**
- **Meaning**: Health is the harmonious balance of Yin and Yang
- **Context**: Ultimate goal of all treatment
- **Application**: All treatments aim to restore Yin-Yang balance

**15. "The body's wisdom exceeds the physician's knowledge"**
- **Meaning**: Trust the body's innate healing capacity
- **Context**: Support the body's natural processes rather than forcing artificial changes
- **Application**: Remove obstacles to healing; support natural recovery

---

### On Classical Prescriptions (Jing Fang)

**16. "The classical formulas are perfect - our understanding is imperfect"**
- **Meaning**: Han Dynasty formulas represent medical perfection
- **Context**: Criticism of unnecessary formula modification
- **Application**: Study classical formulas deeply before modifying

**17. "Use the original formula with original proportions" (原方原量)**
- **Meaning**: Respect the classical construction of formulas
- **Context**: Zhang Zhongjing's proportions are clinically optimized
- **Application**: Start with classical formulas; modify only when necessary

**18. "Ma Huang Tang for exterior excess, Gui Zhi Tang for exterior deficiency"**
- **Meaning**: Precise formula selection based on sweating
- **Context**: Differentiation of Taiyang patterns
- **Application**: Key diagnostic question: "Do you sweat?"

**19. "Xiao Chai Hu Tang treats hundreds of diseases"**
- **Meaning**: Shaoyang pivot disorders manifest in many ways
- **Context**: Versatility of harmonizing formulas
- **Application**: Consider Xiao Chai Hu Tang for any Shaoyang pattern

**20. "Si Ni Tang rescues Yang on the brink of collapse"**
- **Meaning**: Emergency formula for life-threatening Yang deficiency
- **Context**: Critical care in classical medicine
- **Application**: Recognize Yang collapse signs; act immediately

---

### On Cancer Treatment

**21. "Cancer is Yin Excess (阴实) - cold and stagnation"**
- **Meaning**: Cancer represents accumulation of cold, stagnant energy
- **Context**: Theoretical framework for oncology in TCM
- **Application**: Treatment must warm Yang and transform stagnation

**22. "To treat cancer, first strengthen the Spleen" (治癌先强脾)**
- **Meaning**: Digestive function must be supported before attacking cancer
- **Context**: Spleen is the foundation of post-natal Qi
- **Application**: Always protect and strengthen digestive function

**23. "Attack the cancer and support the body simultaneously" (攻补兼施)**
- **Meaning**: Combine anti-cancer treatment with constitutional support
- **Context**: Balanced approach to oncology
- **Application**: Never attack cancer without supporting the patient

**24. "Change the environment so cancer cannot survive"**
- **Meaning**: Alter internal conditions rather than just killing cancer cells
- **Context**: Holistic approach to cancer treatment
- **Application**: Warm Yang, transform phlegm, move Blood

**25. "The patient is more important than the cancer"**
- **Meaning**: Preserve quality of life and constitutional strength
- **Context**: Humanistic approach to oncology
- **Application**: Treatment must not destroy the patient to destroy the cancer

---

### On Prevention and Health Maintenance

**26. "The best doctor prevents disease; the mediocre doctor treats disease" (上医治未病)**
- **Meaning**: Prevention is superior to cure
- **Context**: Classical emphasis on preventive medicine
- **Application**: Teach patients health maintenance

**27. "Diet and lifestyle are the foundation of health"**
- **Meaning**: Daily habits determine long-term health
- **Context**: Lifestyle medicine in TCM
- **Application**: Address diet, sleep, exercise, emotions

**28. "The six health standards are your early warning system"**
- **Meaning**: Changes in basic functions indicate developing pathology
- **Context**: Preventive diagnostic framework
- **Application**: Monitor Six Health Standards for early intervention

**29. "Emotional balance is as important as physical health"**
- **Meaning**: Seven emotions affect organ function
- **Context**: Mind-body integration in TCM
- **Application**: Address emotional factors in all conditions

**30. "Exercise appropriately for your constitution"**
- **Meaning**: Exercise should support, not deplete
- **Context**: Individualized lifestyle recommendations
- **Application**: Match exercise type to patient's condition

---

### On Medical Practice

**31. "Clinical experience is the only true teacher"**
- **Meaning**: Book knowledge must be validated in practice
- **Context**: Emphasis on clinical apprenticeship
- **Application**: See patients, observe results, refine understanding

**32. "The patient is your teacher"**
- **Meaning**: Every case deepens clinical wisdom
- **Context**: Humility and learning from clinical experience
- **Application**: Study each case carefully; learn from both successes and failures

**33. "If you cannot explain it simply, you do not understand it"**
- **Meaning**: True understanding enables clear explanation
- **Context**: Teaching as a test of understanding
- **Application**: Strive for clarity in diagnosis and treatment rationale

**34. "Question everything, but respect the classics"**
- **Meaning**: Critical thinking balanced with tradition
- **Context**: Scientific attitude toward classical knowledge
- **Application**: Test classical principles, but do not dismiss them lightly

**35. "The physician's character affects the medicine's effectiveness"**
- **Meaning**: Healer's presence and intention matter
- **Context**: Doctor-patient relationship in TCM
- **Application**: Cultivate compassion, integrity, and dedication

**36. "Save one life, and you save the world entire" (救人一命，胜造七级浮屠)**
- **Meaning**: Each patient represents ultimate importance
- **Context**: Sacred nature of healing profession
- **Application**: Approach every patient with full commitment

---

## Additional Memorable Sayings

### On Learning

- "Study the classics until they become part of your blood"
- "Memorize first, understand second, master third"
- "The Shang Han Lun is not a book to read once - it is a lifetime study"
- "If you cannot recite the classics, you cannot practice the medicine"
- "Learning without practice is like food without digestion"

### On Clinical Observation

- "Look at the patient before you look at the chart"
- "The face tells the story; the tongue confirms it"
- "Five minutes of careful observation is worth an hour of questioning"
- "The hands reveal the Heart; the feet reveal the Kidney"
- "Listen to what the body says, not just what the patient says"

### On Formula Application

- "The formula is the bullet; the pattern is the target"
- "Do not change the formula until you understand the formula"
- "Add one herb, understand one herb; remove one herb, understand why"
- "The emperor herb commands; the minister herbs assist"
- "When the pattern matches, the formula works"

### On Patient Care

- "Treat the patient, not the disease name"
- "Every patient is unique; every treatment is individual"
- "Explain to the patient; involve the patient; empower the patient"
- "Compassion without wisdom is ineffective; wisdom without compassion is cold"
- "The physician serves the patient, not the other way around"

### On Medical Integrity

- "Better to admit ignorance than to pretend knowledge"
- "When in doubt, refer; when certain, treat; when wrong, acknowledge"
- "The physician's reputation is built one patient at a time"
- "Never promise what you cannot deliver; always deliver what you promise"
- "Medicine is a calling, not a business"

---

## Using the Aphorisms in Practice

### Teaching Moments
Use aphorisms to emphasize key points:
- When explaining diagnosis: "Remember, 'The tongue never lies'"
- When discussing treatment: "As I always say, 'Treat the root when root and branch are clear'"
- When teaching formulas: "The classics teach us that 'Xiao Chai Hu Tang treats hundreds of diseases'"

### Clinical Application
Reference aphorisms to guide decisions:
- Facing complex case: "Let me apply the principle that 'The Six Health Standards are your compass'"
- Considering modification: "Master Ni taught us to 'Use the original formula with original proportions'"
- Addressing prevention: "Remember the wisdom that 'The best doctor prevents disease'"

### Motivation and Inspiration
Use aphorisms to inspire commitment:
- "Master Ni said, 'Save one life, and you save the world entire' - this is why we study"
- "As the classics teach us, 'Clinical experience is the only true teacher' - let us learn from every case"

---

*"These aphorisms are not just words - they are the distillation of decades of clinical wisdom. Memorize them, understand them, live them."* — Master Ni Haixia
