#!/usr/bin/env python3
"""
照片比例转换模块
支持将任意比例的照片转换为 9:16 比例（手机照片优化）
"""

from PIL import Image
from typing import Tuple, Optional


def detect_aspect_ratio(image: Image.Image) -> float:
    """检测图片比例"""
    width, height = image.size
    return width / height


def is_mobile_ratio(image: Image.Image, tolerance: float = 0.15) -> bool:
    """判断是否为 9:16 比例"""
    ratio = detect_aspect_ratio(image)
    target = 9/16
    return abs(ratio - target) < tolerance


def is_4_3_ratio(image: Image.Image, tolerance: float = 0.1) -> bool:
    """判断是否为 4:3 比例"""
    ratio = detect_aspect_ratio(image)
    target = 4/3
    return abs(ratio - target) < tolerance


def crop_to_9_16(
    image: Image.Image,
    focus_point: Optional[Tuple[int, int]] = None,
    method: str = 'smart'
) -> Image.Image:
    """
    将照片裁剪为 9:16 比例
    
    参数:
        image: 输入图片
        focus_point: 焦点坐标 (x, y)，用于智能裁剪
        method: 裁剪方法
            - 'center': 中心裁剪
            - 'smart': 智能裁剪（保留重要区域）
            - 'top': 优先保留上方
            - 'bottom': 优先保留下方
    
    返回:
        裁剪后的 9:16 比例图片
    """
    width, height = image.size
    target_ratio = 9/16
    
    # 如果已经是 9:16，直接返回
    if is_mobile_ratio(image):
        return image
    
    # 计算目标尺寸
    if width / height > target_ratio:
        # 原图更宽，需要裁剪宽度
        new_width = int(height * target_ratio)
        new_height = height
        
        # 确定裁剪起始位置
        if method == 'center' or focus_point is None:
            left = (width - new_width) // 2
        elif method == 'top':
            left = 0
        elif method == 'bottom':
            left = width - new_width
        elif method == 'smart' and focus_point:
            # 智能裁剪：以焦点为中心
            fx, fy = focus_point
            left = max(0, min(fx - new_width//2, width - new_width))
        else:
            left = (width - new_width) // 2
            
    else:
        # 原图更高，需要裁剪高度
        new_height = int(width / target_ratio)
        new_width = width
        
        # 确定裁剪起始位置
        if method == 'center' or focus_point is None:
            top = (height - new_height) // 2
        elif method == 'top':
            top = 0
        elif method == 'bottom':
            top = height - new_height
        elif method == 'smart' and focus_point:
            # 智能裁剪：以焦点为中心
            fx, fy = focus_point
            top = max(0, min(fy - new_height//2, height - new_height))
        else:
            top = (height - new_height) // 2
    
    # 执行裁剪
    if width / height > target_ratio:
        # 裁剪宽度
        box = (left, 0, left + new_width, new_height)
    else:
        # 裁剪高度
        box = (0, top, new_width, top + new_height)
    
    cropped = image.crop(box)
    
    # 确保尺寸精确匹配 9:16
    final_width = min(cropped.width, 540)  # 限制最大宽度
    final_height = int(final_width / target_ratio)
    
    if cropped.size != (final_width, final_height):
        cropped = cropped.resize((final_width, final_height), Image.Resampling.LANCZOS)
    
    return cropped


def resize_to_9_16(
    image: Image.Image,
    fill_color: Tuple[int, int, int] = (255, 255, 255),
    method: str = 'fit'
) -> Image.Image:
    """
    将照片调整为 9:16 比例（不裁剪，使用填充或裁剪）
    
    参数:
        image: 输入图片
        fill_color: 填充颜色（RGB）
        method: 调整方法
            - 'fit': 适应模式（添加白边）
            - 'crop': 裁剪模式
            - 'stretch': 拉伸模式（不推荐）
    
    返回:
        9:16 比例图片
    """
    width, height = image.size
    target_ratio = 9/16
    
    # 如果已经是 9:16，直接返回
    if is_mobile_ratio(image, tolerance=0.05):
        return image
    
    if method == 'fit':
        # 适应模式：保持完整内容，添加边框
        if width / height < target_ratio:
            # 原图更窄，左右加边
            new_height = height
            new_width = int(height * target_ratio)
            
            result = Image.new('RGB', (new_width, new_height), fill_color)
            paste_x = (new_width - width) // 2
            result.paste(image, (paste_x, 0))
        else:
            # 原图更宽，上下加边
            new_width = width
            new_height = int(width / target_ratio)
            
            result = Image.new('RGB', (new_width, new_height), fill_color)
            paste_y = (new_height - height) // 2
            result.paste(image, (0, paste_y))
        
        return result
    
    elif method == 'crop':
        # 裁剪模式
        return crop_to_9_16(image, method='smart')
    
    elif method == 'stretch':
        # 拉伸模式（会变形，不推荐）
        target_width = 540
        target_height = 960
        return image.resize((target_width, target_height), Image.Resampling.LANCZOS)
    
    else:
        raise ValueError(f"未知的调整方法：{method}")


def convert_to_mobile(
    image_path: str,
    output_path: str,
    method: str = 'smart_crop',
    quality: int = 95
) -> dict:
    """
    将照片转换为手机友好的 9:16 比例
    
    参数:
        image_path: 输入图片路径
        output_path: 输出图片路径
        method: 转换方法
            - 'smart_crop': 智能裁剪（推荐）
            - 'center_crop': 中心裁剪
            - 'fit': 适应填充
            - 'auto': 自动选择
        quality: 输出质量
    
    返回:
        转换信息字典
    """
    result = {
        'success': False,
        'original_size': None,
        'output_size': None,
        'original_ratio': None,
        'output_ratio': None,
        'method_used': None,
        'message': ''
    }
    
    try:
        with Image.open(image_path) as img:
            # 转换为 RGB（处理 PNG 等透明图片）
            if img.mode in ('RGBA', 'P'):
                img = img.convert('RGB')
            
            width, height = img.size
            result['original_size'] = f"{width}x{height}"
            result['original_ratio'] = f"{width/height:.3f}"
            
            # 检查是否已经是 9:16
            if is_mobile_ratio(img, tolerance=0.1):
                result['message'] = "已是 9:16 比例，无需转换"
                result['output_size'] = result['original_size']
                result['output_ratio'] = result['original_ratio']
                result['method_used'] = 'none'
                result['success'] = True
                
                # 直接保存
                img.save(output_path, quality=quality)
                return result
            
            # 执行转换
            if method == 'auto':
                # 自动选择：人像照用智能裁剪，风景照用适应填充
                if height > width:
                    method = 'smart_crop'
                else:
                    method = 'fit'
            
            if method == 'smart_crop':
                # 尝试检测人脸作为焦点
                try:
                    from scripts.skin_retouch import detect_faces
                    faces = detect_faces(img)
                    if faces:
                        # 使用最大的人脸作为焦点
                        largest_face = max(faces, key=lambda f: f[2] * f[3])
                        fx = largest_face[0] + largest_face[2] // 2
                        fy = largest_face[1] + largest_face[3] // 2
                        converted = crop_to_9_16(img, focus_point=(fx, fy), method='smart')
                    else:
                        converted = crop_to_9_16(img, method='center')
                except ImportError:
                    converted = crop_to_9_16(img, method='center')
                
                result['method_used'] = 'smart_crop'
            
            elif method == 'center_crop':
                converted = crop_to_9_16(img, method='center')
                result['method_used'] = 'center_crop'
            
            elif method == 'fit':
                converted = resize_to_9_16(img, method='fit')
                result['method_used'] = 'fit'
            
            else:
                raise ValueError(f"未知的转换方法：{method}")
            
            # 保存结果
            result['output_size'] = f"{converted.width}x{converted.height}"
            result['output_ratio'] = f"{converted.width/converted.height:.3f}"
            result['success'] = True
            
            converted.save(output_path, quality=quality)
            
            result['message'] = f"成功转换为 9:16 比例 ({result['method_used']})"
            
    except Exception as e:
        result['message'] = f"转换失败：{str(e)}"
        result['success'] = False
    
    return result


# 命令行工具
if __name__ == '__main__':
    import sys
    import argparse
    
    parser = argparse.ArgumentParser(description='将照片转换为 9:16 比例')
    parser.add_argument('input', help='输入图片路径')
    parser.add_argument('output', help='输出图片路径')
    parser.add_argument('--method', '-m', default='smart_crop',
                       choices=['smart_crop', 'center_crop', 'fit', 'auto'],
                       help='转换方法（默认：smart_crop）')
    parser.add_argument('--quality', '-q', type=int, default=95,
                       help='输出质量（默认：95）')
    
    args = parser.parse_args()
    
    print(f"正在转换：{args.input}")
    result = convert_to_mobile(args.input, args.output, method=args.method)
    
    if result['success']:
        print(f"✅ 转换成功!")
        print(f"   原始尺寸：{result['original_size']} ({result['original_ratio']})")
        print(f"   输出尺寸：{result['output_size']} ({result['output_ratio']})")
        print(f"   使用方法：{result['method_used']}")
        print(f"   输出文件：{args.output}")
    else:
        print(f"❌ 转换失败：{result['message']}")
        sys.exit(1)
