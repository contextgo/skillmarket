#!/usr/bin/env python3
"""
照片水印添加器
为照片添加文字或图片水印，支持自定义位置和样式。
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Optional, Tuple
import glob

# 尝试导入PIL，如果不可用则提供有用的错误提示
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("错误：未找到PIL/Pillow库。")
    print("请使用以下命令安装：pip install Pillow")
    sys.exit(1)

# 可选导入磨皮模块
try:
    from skin_retouch import auto_retouch
    SKIN_RETOUCH_AVAILABLE = True
except ImportError:
    SKIN_RETOUCH_AVAILABLE = False

# 可选导入比例转换模块
try:
    from aspect_converter import convert_to_mobile, is_mobile_ratio
    ASPECT_CONVERTER_AVAILABLE = True
except ImportError:
    ASPECT_CONVERTER_AVAILABLE = False


def is_safe_path(path: str, allow_pattern: bool = False) -> bool:
    """检查路径是否安全，防止路径遍历攻击。"""
    # 检查路径遍历尝试
    if '..' in path:
        return False
    
    # 检查绝对路径是否在系统敏感目录
    try:
        resolved = Path(path).resolve()
        sensitive_patterns = [
            '/etc', '/private/etc',  # 配置目录
            '/bin', '/usr/bin',      # 二进制文件
            '/sbin', '/usr/sbin',    # 系统管理工具
            '/System',               # macOS 系统文件
            '/Library',              # macOS 库文件（但允许用户库）
            '/var',                  # 变量数据
            '/root',                 # root 用户主目录
            '/boot',                 # 引导文件
            '/dev',                  # 设备文件
            '/proc',                 # 进程信息
        ]
        resolved_str = str(resolved)
        
        # 如果是绝对路径，检查是否在敏感目录
        if path.startswith('/') or len(str(resolved)) > 3:
            for pattern in sensitive_patterns:
                if resolved_str.startswith(pattern + '/') or resolved_str == pattern:
                    # 但允许以下位置
                    allowed = [
                        resolved_str.startswith('/tmp'),
                        resolved_str.startswith('/private/tmp'),
                        resolved_str.startswith(str(Path.home())),  # 用户主目录
                        resolved_str.startswith('/Users'),  # macOS 用户目录
                    ]
                    if not any(allowed):
                        return False
    except:
        pass
    
    return True


def get_chinese_font(font_size: int) -> ImageFont.FreeTypeFont:
    """获取支持中文的字体。"""
    # 按优先级排列的中文字体路径
    chinese_fonts = [
        # macOS 中文字体
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        # Linux 中文字体
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        # Windows 中文字体
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
        "C:/Windows/Fonts/arial.ttf",
    ]
    
    for font_path in chinese_fonts:
        try:
            if os.path.exists(font_path):
                return ImageFont.truetype(font_path, font_size)
        except (OSError, IOError):
            continue
    
    # 如果找不到中文字体，返回默认字体（可能不支持中文）
    return ImageFont.load_default()


def add_text_watermark(
    image: Image.Image,
    text: str,
    position: str = "bottom-right",
    opacity: float = 0.7,
    font_size: int = 40,
    color: str = "#FFFFFF",
    rotate: float = 0
) -> Image.Image:
    """为图片添加文字水印。"""
    
    # 创建水印图层
    watermark = Image.new('RGBA', image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(watermark)
    
    # 加载支持中文的字体
    font = get_chinese_font(font_size)
    
    # 获取文字尺寸
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    # 计算位置
    positions = {
        'top-left': (20, 20),
        'top-center': ((image.width - text_width) // 2, 20),
        'top-right': (image.width - text_width - 20, 20),
        'center-left': (20, (image.height - text_height) // 2),
        'center': ((image.width - text_width) // 2, (image.height - text_height) // 2),
        'center-right': (image.width - text_width - 20, (image.height - text_height) // 2),
        'bottom-left': (20, image.height - text_height - 20),
        'bottom-center': ((image.width - text_width) // 2, image.height - text_height - 20),
        'bottom-right': (image.width - text_width - 20, image.height - text_height - 20),
    }
    
    x, y = positions.get(position, positions['bottom-right'])
    
    # 将十六进制颜色转换为RGB
    if color.startswith('#'):
        color = color[1:]
    rgb_color = tuple(int(color[i:i+2], 16) for i in (0, 2, 4))
    
    # 绘制文字
    draw.text((x, y), text, font=font, fill=(*rgb_color, int(255 * opacity)))
    
    # 如果需要则旋转
    if rotate != 0:
        watermark = watermark.rotate(rotate, expand=True)
    
    # 合成图片
    return Image.alpha_composite(image.convert('RGBA'), watermark)


def add_image_watermark(
    image: Image.Image,
    watermark_path: str,
    position: str = "bottom-right",
    opacity: float = 0.7,
    scale: float = 0.2,
    rotate: float = 0
) -> Image.Image:
    """为图片添加图片水印。"""
    
    # 加载水印图片
    watermark_img = Image.open(watermark_path).convert('RGBA')
    
    # 缩放水印
    new_width = int(image.width * scale)
    aspect_ratio = watermark_img.height / watermark_img.width
    new_height = int(new_width * aspect_ratio)
    watermark_img = watermark_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    # 应用透明度
    if opacity < 1.0:
        alpha = watermark_img.split()[-1]
        alpha = alpha.point(lambda p: p * opacity)
        watermark_img.putalpha(alpha)
    
    # 如果需要则旋转
    if rotate != 0:
        watermark_img = watermark_img.rotate(rotate, expand=True)
    
    # 计算位置
    positions = {
        'top-left': (20, 20),
        'top-center': ((image.width - watermark_img.width) // 2, 20),
        'top-right': (image.width - watermark_img.width - 20, 20),
        'center-left': (20, (image.height - watermark_img.height) // 2),
        'center': ((image.width - watermark_img.width) // 2, (image.height - watermark_img.height) // 2),
        'center-right': (image.width - watermark_img.width - 20, (image.height - watermark_img.height) // 2),
        'bottom-left': (20, image.height - watermark_img.height - 20),
        'bottom-center': ((image.width - watermark_img.width) // 2, image.height - watermark_img.height - 20),
        'bottom-right': (image.width - watermark_img.width - 20, image.height - watermark_img.height - 20),
    }
    
    x, y = positions.get(position, positions['bottom-right'])
    
    # 将水印粘贴到图片上
    result = image.copy()
    result.paste(watermark_img, (x, y), watermark_img)
    
    return result


def detect_mobile_photo(image_path: str) -> bool:
    """检测是否为手机照片（9:16 比例）。"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            aspect_ratio = width / height
            # 9:16 = 0.5625，允许±0.15 的误差
            target_ratio = 9/16
            return abs(aspect_ratio - target_ratio) < 0.15
    except:
        return False


def auto_adjust_font_size(image_path: str, base_font_size: int = 80) -> int:
    """根据图片尺寸自动调整字体大小。"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            # 基于图片高度计算字体大小
            # 对于高图，字体应该更大
            calculated_size = int(height * 0.08)  # 字体占高度的 8%
            return max(calculated_size, base_font_size)
    except:
        return base_font_size


def process_image(
    input_path: str,
    output_path: str,
    text: Optional[str] = None,
    watermark_path: Optional[str] = None,
    auto_detect: bool = True,
    retouch: bool = False,
    retouch_strength: float = 0.6,
    **kwargs
) -> bool:
    """处理单张图片并添加水印。"""
    try:
        # 打开图片
        with Image.open(input_path) as img:
            # 如果是手机照片且启用自动检测，调整默认参数
            if auto_detect and detect_mobile_photo(input_path):
                print(f"✓ 检测到 9:16 比例手机照片，已自动调整水印参数")
                # 自动使用居中位置
                if 'position' not in kwargs or kwargs.get('position') == 'bottom-right':
                    kwargs['position'] = 'center'
                # 自动调大字体
                if 'font_size' not in kwargs:
                    kwargs['font_size'] = auto_adjust_font_size(input_path)
                # 设置为半透明
                if 'opacity' not in kwargs:
                    kwargs['opacity'] = 0.5
            # 如果需要则转换为RGBA模式
            if img.mode != 'RGBA':
                img = img.convert('RGBA')
            
            # 应用水印
            if text:
                result = add_text_watermark(img, text, **kwargs)
            elif watermark_path:
                result = add_image_watermark(img, watermark_path, **kwargs)
            else:
                result = img
            
            # 保存结果
            output_path_obj = Path(output_path)
            output_path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # 为JPEG输出转换回原始模式
            if result.mode == 'RGBA' and output_path.lower().endswith(('.jpg', '.jpeg')):
                # 将RGBA转换为RGB以保存为JPEG
                rgb_result = Image.new('RGB', result.size, (255, 255, 255))
                rgb_result.paste(result, mask=result.split()[-1])
                rgb_result.save(output_path, quality=95)
            else:
                result.save(output_path, quality=95)
        
        return True
    except Exception as e:
        print(f"处理 {input_path} 时出错：{e}")
        return False


def main():
    parser = argparse.ArgumentParser(description='为照片添加水印')
    parser.add_argument('--input', '-i', required=True, help='输入图片文件或匹配模式')
    parser.add_argument('--output', '-o', help='输出目录或文件路径')
    parser.add_argument('--text', '-t', help='文字水印内容')
    parser.add_argument('--watermark', '-w', help='水印图片文件路径')
    parser.add_argument('--position', '-p', default='center',
                       choices=['top-left', 'top-center', 'top-right',
                               'center-left', 'center', 'center-right',
                               'bottom-left', 'bottom-center', 'bottom-right'],
                       help='水印位置（默认居中）')
    parser.add_argument('--opacity', type=float, default=0.5,
                       help='水印透明度 (0.0-1.0)，默认 0.5 半透明')
    parser.add_argument('--font-size', type=int, default=80,
                       help='文字水印的字体大小，默认 80（自动检测手机照片时会调整）')
    parser.add_argument('--color', default='#FFFFFF',
                       help='文字颜色，十六进制格式')
    parser.add_argument('--scale', type=float, default=0.2,
                       help='图片水印的缩放因子')
    parser.add_argument('--rotate', type=float, default=0,
                       help='旋转角度（度）')
    parser.add_argument('--no-auto-detect', action='store_true',
                       help='禁用自动检测手机照片功能')
    parser.add_argument('--retouch', action='store_true',
                       help='启用人像智能磨皮美化（需要安装 opencv-python）')
    parser.add_argument('--retouch-strength', type=float, default=0.6,
                       help='磨皮强度 (0.0-1.0)，默认 0.6')
    parser.add_argument('--convert-to-9-16', action='store_true',
                       help='自动将非 9:16 照片转换为 9:16 比例（如 4:3 转 9:16）')
    parser.add_argument('--crop-method', default='smart',
                       choices=['smart', 'center', 'fit'],
                       help='裁剪方法：smart=智能，center=中心，fit=适应填充')
    
    args = parser.parse_args()
    
    # 验证输入参数
    if not args.text and not args.watermark:
        print("错误：必须指定 --text 或 --watermark 参数之一")
        sys.exit(1)
    
    if args.text and args.watermark:
        print("错误：不能同时指定 --text 和 --watermark 参数")
        sys.exit(1)
    
    # 安全检查：防止路径遍历攻击
    if not is_safe_path(args.input):
        print("错误：输入路径包含不安全字符（..）或指向系统敏感目录")
        sys.exit(1)
    
    if args.output and not is_safe_path(args.output):
        print("错误：输出路径包含不安全字符（..）或指向系统敏感目录")
        sys.exit(1)
    
    # 查找输入文件
    input_files = []
    if '*' in args.input or '?' in args.input:
        # 安全检查 glob 模式
        if '..' in args.input:
            print("错误：glob 模式不能包含路径遍历字符（..）")
            sys.exit(1)
        input_files = glob.glob(args.input)
    else:
        input_files = [args.input]
    
    if not input_files:
        print(f"未找到匹配的文件：{args.input}")
        sys.exit(1)
    
    # 处理文件
    success_count = 0
    total_files = len(input_files)
    
    print(f"正在处理 {total_files} 个文件...")
    
    for input_file in input_files:
        if not os.path.exists(input_file):
            print(f"警告：文件不存在：{input_file}")
            continue
        
        # 确定输出路径
        if args.output:
            if os.path.isdir(args.output):
                # 输出是目录
                filename = os.path.basename(input_file)
                name, ext = os.path.splitext(filename)
                output_file = os.path.join(args.output, f"{name}_watermarked{ext}")
            else:
                # 输出是文件路径
                output_file = args.output
        else:
            # 默认：添加 _watermarked 后缀
            name, ext = os.path.splitext(input_file)
            output_file = f"{name}_watermarked{ext}"
        
        # 如果需要转换为 9:16 比例
        temp_file = None
        if args.convert_to_9_16 and ASPECT_CONVERTER_AVAILABLE:
            try:
                from PIL import Image
                with Image.open(input_file) as img:
                    if not is_mobile_ratio(img, tolerance=0.1):
                        print(f"ℹ 检测到非 9:16 比例照片，正在转换...")
                        # 创建临时文件
                        import tempfile
                        temp_fd, temp_file = tempfile.mkstemp(suffix='.jpg')
                        os.close(temp_fd)
                        
                        # 映射参数
                        method_map = {
                            'smart': 'smart_crop',
                            'center': 'center_crop',
                            'fit': 'fit'
                        }
                        convert_method = method_map.get(args.crop_method, 'smart_crop')
                        
                        result = convert_to_mobile(
                            input_file, 
                            temp_file, 
                            method=convert_method
                        )
                        
                        if result['success']:
                            print(f"✓ 已转换：{result['original_size']} → {result['output_size']}")
                            input_file = temp_file  # 使用转换后的文件
                        else:
                            print(f"⚠ 转换失败：{result['message']}，使用原图")
            except Exception as e:
                print(f"⚠ 比例转换出错：{e}，使用原图")
                if temp_file and os.path.exists(temp_file):
                    os.remove(temp_file)
                temp_file = None
        
        # 根据水印类型准备参数
        kwargs = {
            'position': args.position,
            'opacity': args.opacity,
            'rotate': args.rotate,
            'auto_detect': not args.no_auto_detect,  # 默认启用自动检测
            'retouch': args.retouch,  # 磨皮功能
            'retouch_strength': args.retouch_strength
        }
        
        if args.text:
            kwargs.update({
                'font_size': args.font_size,
                'color': args.color
            })
        elif args.watermark:
            kwargs.update({
                'scale': args.scale
            })
        
        # 处理图片
        if process_image(
            input_file, output_file,
            text=args.text,
            watermark_path=args.watermark,
            **kwargs
        ):
            print(f"✓ 已处理：{input_file} -> {output_file}")
            success_count += 1
        else:
            print(f"✗ 失败：{input_file}")
        
        # 清理临时文件
        if temp_file and os.path.exists(temp_file):
            os.remove(temp_file)
    
    print(f"\n完成：成功处理 {success_count}/{total_files} 个文件")


if __name__ == '__main__':
    main()