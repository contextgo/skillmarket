"""
照片水印技能配置
"""

# 默认设置
DEFAULT_OPACITY = 0.5  # 半透明
DEFAULT_FONT_SIZE = 80  # 大字体
DEFAULT_COLOR = "#FFFFFF"
DEFAULT_POSITION = "center"  # 居中
DEFAULT_SCALE = 0.2

# 手机照片优化设置 (9:16 比例)
MOBILE_ASPECT_RATIO = 9/16  # 约 0.56
ASPECT_RATIO_TOLERANCE = 0.1  # 容差范围

# 支持的图片格式
SUPPORTED_FORMATS = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff']

# 位置映射
POSITIONS = {
    'top-left': (20, 20),
    'top-center': 'center_top',
    'top-right': 'right_top',
    'center-left': 'left_center',
    'center': 'center',
    'center-right': 'right_center',
    'bottom-left': 'left_bottom',
    'bottom-center': 'center_bottom',
    'bottom-right': 'right_bottom'
}

# 常用水印预设
PRESETS = {
    'mobile': {
        'text': '© 版权所有',
        'position': 'center',
        'opacity': 0.5,
        'font_size': 80,
        'auto_detect': True  # 自动检测照片比例
    },
    'copyright': {
        'text': '© {year} {name}',
        'position': 'bottom-right',
        'opacity': 0.6,
        'font_size': 30
    },
    'draft': {
        'text': '草稿',
        'position': 'center',
        'opacity': 0.3,
        'font_size': 80,
        'rotate': 30
    },
    'sample': {
        'text': '样例',
        'position': 'center',
        'opacity': 0.4,
        'font_size': 60,
        'rotate': -20
    }
}