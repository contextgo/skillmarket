#!/usr/bin/env python3
"""
人像磨皮模块 - 高低频分解算法
Skin Retouching Module - Frequency Separation Algorithm
"""

import numpy as np
from PIL import Image
from typing import Tuple, Optional


def detect_faces(image: Image.Image) -> list:
    """
    检测图片中的人脸位置
    
    返回：人脸边界框列表 [(x1, y1, x2, y2), ...]
    """
    try:
        import cv2
        
        # 转换为 OpenCV 格式
        img_array = np.array(image.convert('RGB'))
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        # 加载人脸检测模型
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        
        # 检测人脸
        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )
        
        return [tuple(face) for face in faces]
    
    except ImportError:
        print("提示：未安装 opencv-python，跳过人脸检测")
        return []
    except Exception as e:
        print(f"人脸检测失败：{e}")
        return []


def gaussian_blur(image: np.ndarray, sigma: float) -> np.ndarray:
    """
    高斯模糊
    
    参数:
        image: 图像数组 (H, W, C)
        sigma: 高斯分布标准差
    
    返回：模糊后的图像
    """
    from scipy.ndimage import gaussian_filter
    
    # 对每个颜色通道应用高斯模糊
    if len(image.shape) == 3:
        blurred = np.zeros_like(image)
        for i in range(image.shape[2]):
            blurred[:, :, i] = gaussian_filter(image[:, :, i], sigma=sigma)
        return blurred
    else:
        return gaussian_filter(image, sigma=sigma)


def frequency_separation(
    image: Image.Image,
    blur_radius: float = 5.0,
    preserve_details: bool = True
) -> Tuple[np.ndarray, np.ndarray]:
    """
    频率分离算法
    
    将图像分解为低频（颜色/光影）和高频（细节/纹理）两部分
    
    参数:
        image: 输入图像
        blur_radius: 模糊半径，控制磨皮强度
        preserve_details: 是否保留更多细节
    
    返回：
        (low_freq, high_freq) 元组
        - low_freq: 低频层（颜色和光影）
        - high_freq: 高频层（细节和纹理）
    """
    # 转换为 numpy 数组
    img_array = np.array(image.convert('RGB'), dtype=np.float32) / 255.0
    
    # 计算高斯模糊的标准差
    sigma = blur_radius / 6.0
    
    # 生成低频层（模糊后的图像）
    low_freq = gaussian_blur(img_array, sigma)
    
    # 生成高频层（原始图像 - 低频层）
    high_freq = img_array - low_freq
    
    # 如果需要保留更多细节，增强高频
    if preserve_details:
        high_freq *= 1.2
    
    return low_freq, high_freq


def skin_smoothing(
    image: Image.Image,
    face_rect: Optional[Tuple[int, int, int, int]] = None,
    smooth_strength: float = 0.7,
    blur_radius: float = 5.0,
    blend_alpha: float = 0.8
) -> Image.Image:
    """
    皮肤平滑处理
    
    参数:
        image: 输入图像
        face_rect: 人脸区域 (x, y, width, height)，None 则处理全图
        smooth_strength: 磨皮强度 (0.0-1.0)
        blur_radius: 模糊半径
        blend_alpha: 混合比例 (0.0-1.0)
    
    返回：处理后的图像
    """
    # 频率分离
    low_freq, high_freq = frequency_separation(image, blur_radius)
    
    # 如果有指定人脸区域，只处理该区域
    if face_rect is not None:
        x, y, w, h = face_rect
        
        # 扩展区域以包含更多皮肤
        margin = int(min(w, h) * 0.3)
        x1 = max(0, x - margin)
        y1 = max(0, y - margin)
        x2 = min(image.width, x + w + margin)
        y2 = min(image.height, y + h + margin)
        
        # 创建掩膜
        mask = np.zeros((image.height, image.width), dtype=np.float32)
        mask[y1:y2, x1:x2] = 1.0
        
        # 羽化掩膜边缘
        mask = feather_mask(mask, feather_radius=margin)
    else:
        # 全图处理
        mask = np.ones((image.height, image.width), dtype=np.float32)
    
    # 应用磨皮强度
    low_freq_smoothed = low_freq.copy()
    if smooth_strength < 1.0:
        # 部分保留原始低频
        original_low = gaussian_blur(np.array(image.convert('RGB'), dtype=np.float32) / 255.0, 
                                      blur_radius / 6.0)
        low_freq_smoothed = original_low * (1 - smooth_strength) + low_freq * smooth_strength
    
    # 重建图像
    reconstructed = low_freq_smoothed + high_freq
    reconstructed = np.clip(reconstructed, 0, 1)
    
    # 与原始图像混合
    original_array = np.array(image.convert('RGB'), dtype=np.float32) / 255.0
    
    # 根据掩膜混合
    if len(mask.shape) == 2:
        mask_3d = np.repeat(mask[:, :, np.newaxis], 3, axis=2)
    else:
        mask_3d = mask
    
    result = original_array * (1 - mask_3d * blend_alpha) + reconstructed * (mask_3d * blend_alpha)
    result = np.clip(result, 0, 1)
    
    # 转换回 PIL Image
    result_uint8 = (result * 255).astype(np.uint8)
    return Image.fromarray(result_uint8)


def feather_mask(mask: np.ndarray, feather_radius: int = 20) -> np.ndarray:
    """
    羽化掩膜边缘，使过渡更自然
    
    参数:
        mask: 二值掩膜
        feather_radius: 羽化半径
    
    返回：羽化后的掩膜
    """
    from scipy.ndimage import gaussian_filter
    
    # 使用高斯模糊实现羽化效果
    return gaussian_filter(mask, sigma=feather_radius / 3.0)


def auto_retouch(
    image: Image.Image,
    detect_faces_flag: bool = True,
    smooth_strength: float = 0.6,
    blur_radius: float = 6.0
) -> Image.Image:
    """
    自动人像修饰
    
    参数:
        image: 输入图像
        detect_faces_flag: 是否启用人脸检测
        smooth_strength: 磨皮强度
        blur_radius: 模糊半径
    
    返回：修饰后的图像
    """
    if detect_faces_flag:
        # 尝试检测人脸
        faces = detect_faces(image)
        
        if len(faces) > 0:
            print(f"✓ 检测到 {len(faces)} 张人脸，正在进行智能磨皮...")
            
            # 如果有多张人脸，使用最大的那张
            largest_face = max(faces, key=lambda f: f[2] * f[3])
            
            # 应用磨皮
            result = skin_smoothing(
                image,
                face_rect=largest_face,
                smooth_strength=smooth_strength,
                blur_radius=blur_radius,
                blend_alpha=0.75
            )
            return result
    
    # 未检测到人脸或禁用检测，进行全图轻度磨皮
    if detect_faces_flag and len(faces) == 0:
        print("ℹ 未检测到清晰人脸，进行全图轻度美化...")
    
    result = skin_smoothing(
        image,
        face_rect=None,
        smooth_strength=min(smooth_strength, 0.4),  # 全图处理时使用较低强度
        blur_radius=blur_radius,
        blend_alpha=0.6
    )
    return result


# 测试代码
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        input_path = sys.argv[1]
        output_path = sys.argv[2] if len(sys.argv) > 2 else 'retouched.jpg'
        
        print(f"正在处理：{input_path}")
        img = Image.open(input_path)
        
        result = auto_retouch(img)
        result.save(output_path, quality=95)
        
        print(f"✓ 处理完成：{output_path}")
    else:
        print("用法：python skin_retouch.py <input_image> [output_image]")
