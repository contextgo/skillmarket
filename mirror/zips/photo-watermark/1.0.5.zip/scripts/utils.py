"""
照片水印处理工具函数
"""

import os
from pathlib import Path
from typing import List, Optional
from PIL import Image


def get_image_files(directory: str, recursive: bool = False) -> List[str]:
    """从目录中获取所有图片文件。"""
    supported_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff'}
    image_files = []
    
    path = Path(directory)
    if not path.exists():
        return image_files
    
    if path.is_file():
        if path.suffix.lower() in supported_extensions:
            return [str(path)]
        return []
    
    pattern = '**/*' if recursive else '*'
    for file_path in path.glob(pattern):
        if file_path.is_file() and file_path.suffix.lower() in supported_extensions:
            image_files.append(str(file_path))
    
    return sorted(image_files)


def validate_image_file(file_path: str) -> bool:
    """验证文件是否为可读取的图片。"""
    try:
        with Image.open(file_path) as img:
            img.verify()
        return True
    except (FileNotFoundError, PermissionError, Image.UnidentifiedImageError, OSError):
        return False


def create_output_directory(output_path: str) -> bool:
    """如果输出目录不存在则创建它。"""
    try:
        Path(output_path).mkdir(parents=True, exist_ok=True)
        return True
    except (PermissionError, OSError):
        return False


def get_file_info(file_path: str) -> dict:
    """获取图片文件信息。"""
    try:
        with Image.open(file_path) as img:
            return {
                'width': img.width,
                'height': img.height,
                'mode': img.mode,
                'format': img.format,
                'size': os.path.getsize(file_path)
            }
    except (FileNotFoundError, PermissionError, Image.UnidentifiedImageError, OSError) as e:
        return {'error': str(e)}


def format_file_size(size_bytes: int) -> str:
    """将文件大小格式化为人类可读的格式。"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def sanitize_filename(filename: str) -> str:
    """清理文件名以确保安全的文件操作。"""
    # 移除无效字符
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # 限制长度
    if len(filename) > 255:
        name, ext = os.path.splitext(filename)
        filename = name[:255-len(ext)] + ext
    
    return filename