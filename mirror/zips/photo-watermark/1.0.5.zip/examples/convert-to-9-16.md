# 4:3 转 9:16 照片比例转换指南

## 📱 功能概述

自动将非 9:16 比例的照片（如 4:3、16:9、1:1 等）转换为手机友好的 9:16 比例，并添加水印。

### 支持的转换

| 原始比例 | 典型尺寸 | 转换方法 | 效果 |
|---------|---------|---------|------|
| **4:3** | 800×600, 1024×768 | 智能裁剪 | ✅ 完美适配 |
| **3:2** | 1500×1000 | 智能裁剪 | ✅ 完美适配 |
| **16:9** | 1920×1080 | 适应填充 | ✅ 保留完整 |
| **1:1** | 1000×1000 | 智能裁剪 | ✅ 居中裁剪 |
| **其他** | 任意尺寸 | 自动选择 | ✅ 智能处理 |

---

## 🚀 快速使用

### 基础用法

```bash
# 将 4:3 照片转为 9:16 并添加水印
python scripts/add_watermark.py --input photo.jpg --text "版权所有" --convert-to-9-16
```

### 批量转换

```bash
# 批量处理所有 4:3 照片
python scripts/add_watermark.py --input "photos/*.jpg" --text "© 2026" --convert-to-9-16
```

### 指定裁剪方法

```bash
# 智能裁剪（推荐，默认）
python scripts/add_watermark.py --input photo.jpg --text "水印" --convert-to-9-16 --crop-method smart

# 中心裁剪
python scripts/add_watermark.py --input photo.jpg --text "水印" --convert-to-9-16 --crop-method center

# 适应填充（保留完整画面，添加白边）
python scripts/add_watermark.py --input photo.jpg --text "水印" --convert-to-9-16 --crop-method fit
```

---

## ⚙️ 裁剪方法详解

### 1. smart（智能裁剪）⭐ 推荐

**原理**: 尝试检测人脸，以人脸为中心进行裁剪

**适用场景**:
- ✅ 人像照片
- ✅ 有明确主体的照片
- ✅ 朋友圈自拍

**示例**:
```bash
python scripts/add_watermark.py --input portrait.jpg \
  --text "© 摄影工作室" \
  --convert-to-9-16 \
  --crop-method smart
```

**效果**: 
- 自动检测人脸位置
- 优先保留人脸区域
- 自然过渡，不突兀

---

### 2. center（中心裁剪）

**原理**: 以图片中心为基准，对称裁剪

**适用场景**:
- ✅ 风景照
- ✅ 建筑照
- ✅ 主体在中间的照片

**示例**:
```bash
python scripts/add_watermark.py --input landscape.jpg \
  --text "风景摄影" \
  --convert-to-9-16 \
  --crop-method center
```

**效果**:
- 保持画面平衡
- 简单直接
- 适合对称构图

---

### 3. fit（适应填充）

**原理**: 保持完整画面，两侧或上下填充白边

**适用场景**:
- ✅ 需要保留完整画面
- ✅ 证件照翻拍
- ✅ 重要内容在边缘的照片

**示例**:
```bash
python scripts/add_watermark.py --input group.jpg \
  --text "大合照" \
  --convert-to-9-16 \
  --crop-method fit
```

**效果**:
- 不损失任何画面内容
- 可能有白边
- 最安全的转换方式

---

## 📊 转换示例对比

### 4:3 → 9:16

**原始图片**: 800×600 (4:3 = 1.333)

```bash
python scripts/add_watermark.py --input input_800x600.jpg \
  --text "测试" \
  --convert-to-9-16
```

**输出**: 337×599 (9:16 = 0.563)

```
转换前: ████████████████████ (800px)
        ██████████████       (600px)
        比例：1.333 (4:3)

转换后: ████                 (337px)
        ████████████████████ (599px)
        比例：0.563 (9:16)
```

---

### 16:9 → 9:16

**原始图片**: 1920×1080 (16:9 = 1.778)

```bash
# 使用 fit 模式保留完整画面
python scripts/add_watermark.py --input video_frame.jpg \
  --text "视频截图" \
  --convert-to-9-16 \
  --crop-method fit
```

**输出**: 1080×1920 (9:16 = 0.563)

```
转换前: ████████████████████████████████████ (1920px)
        ███████████                          (1080px)
        
转换后: ███████████ (加白边)                  (1080px)
        ███████████                          (1080px)
        ███████████                          (1080px)
        ███████████                          (1080px)
        ███████████ (加白边)                  (1080px)
        总高度：1920px
```

---

## 💡 最佳实践

### 1. 人像照片
```bash
# 推荐配置
python scripts/add_watermark.py --input selfie.jpg \
  --text "@我的微信" \
  --convert-to-9-16 \
  --crop-method smart \
  --retouch \
  --opacity 0.6
```

### 2. 风景照片
```bash
# 推荐配置
python scripts/add_watermark.py --input landscape.jpg \
  --text "风景摄影" \
  --convert-to-9-16 \
  --crop-method center \
  --position bottom-center
```

### 3. 产品照片
```bash
# 推荐配置（保留完整产品）
python scripts/add_watermark.py --input product.jpg \
  --text "产品展示" \
  --convert-to-9-16 \
  --crop-method fit \
  --opacity 0.4
```

### 4. 朋友圈九宫格
```bash
# 批量统一处理
python scripts/add_watermark.py --input "wechat/*.jpg" \
  --text "@我的微信" \
  --convert-to-9-16 \
  --crop-method smart \
  --output watermarked/
```

---

## 🔧 高级技巧

### 组合使用磨皮功能

```bash
# 4:3 人像照 → 9:16 + 磨皮 + 水印
python scripts/add_watermark.py --input portrait.jpg \
  --text "© 2026" \
  --convert-to-9-16 \
  --crop-method smart \
  --retouch \
  --retouch-strength 0.6
```

### 保持原始质量

```bash
# 高质量输出
python scripts/add_watermark.py --input raw_photo.jpg \
  --text "高质量水印" \
  --convert-to-9-16 \
  --crop-method smart
# 默认 quality=95，几乎无损
```

### 自定义填充颜色

对于 `fit` 模式的填充颜色，可以修改 `aspect_converter.py`:

```python
resize_to_9_16(image, fill_color=(0, 0, 0))  # 黑色填充
resize_to_9_16(image, fill_color=(255, 255, 255))  # 白色填充
```

---

## ⚠️ 注意事项

### 1. 画质损失
- 裁剪会损失部分画面内容
- 建议保留原始文件备份

### 2. 构图变化
- 4:3 → 9:16 会裁剪掉约 58% 的画面
- 重要内容可能被裁掉

### 3. 人脸检测失败
- 光线太暗可能检测不到人脸
- 会自动降级到中心裁剪

### 4. 不适合的照片类型
- ❌ 宽幅风景照（建议用 fit 模式）
- ❌ 多人合照（边缘人物可能被裁）
- ❌ 文字在边缘的截图

---

## 📈 转换前后尺寸对照表

| 原始尺寸 | 原始比例 | 转换方法 | 输出尺寸 | 输出比例 | 画面保留率 |
|---------|---------|---------|---------|---------|-----------|
| 800×600 | 4:3 | smart | 337×599 | 9:16 | ~42% |
| 1024×768 | 4:3 | smart | 433×770 | 9:16 | ~42% |
| 1500×1000 | 3:2 | smart | 540×960 | 9:16 | ~36% |
| 1920×1080 | 16:9 | fit | 1080×1920 | 9:16 | 100%* |
| 1000×1000 | 1:1 | smart | 500×889 | 9:16 | ~56% |

\* fit 模式保留 100% 画面，但有白边

---

## 🐛 故障排除

### 问题：转换后比例不对
**解决**:
```bash
# 检查输出文件
python3 -c "
from PIL import Image
with Image.open('output.jpg') as img:
    print(f'{img.width}x{img.height}')
    print(f'比例：{img.width/img.height:.4f}')
"
```

### 问题：重要内容被裁掉了
**解决**: 改用 `fit` 模式
```bash
python scripts/add_watermark.py --input photo.jpg \
  --text "水印" \
  --convert-to-9-16 \
  --crop-method fit
```

### 问题：人脸没检测到
**解决**: 手动指定 crop method
```bash
# 使用中心裁剪
python scripts/add_watermark.py --input photo.jpg \
  --text "水印" \
  --convert-to-9-16 \
  --crop-method center
```

---

## 📞 相关文档

- [手机照片优化指南](mobile-photo-guide.md)
- [水印使用示例](watermark-examples.md)
- [人像磨皮指南](skin-retouch-guide.md)

---

**更新时间**: 2026-03-25  
**版本**: v2.2.0 (新增 4:3 转 9:16)
