# 人像磨皮美颜功能指南

## 🌟 功能概述

照片水印技能现在支持智能人像磨皮美化功能，使用先进的高低频分解算法：

- **低频层处理**：平滑皮肤颜色和光影
- **高频层保留**：保持皮肤纹理细节
- **智能人脸检测**：自动定位人脸位置
- **自然过渡**：羽化边缘，无痕迹处理

## 📦 安装依赖

首次使用前需要安装额外依赖：

```bash
# 安装磨皮功能所需库
pip install -r requirements.txt

# 或手动安装
pip install opencv-python-headless numpy scipy
```

**依赖说明**：
- `opencv-python-headless`: 人脸检测（无 GUI 版本，适合服务器）
- `numpy`: 图像数组处理
- `scipy`: 高斯模糊算法

## 🚀 快速使用

### 基础用法

```bash
# 添加水印并启用人像磨皮
python scripts/add_watermark.py --input portrait.jpg --text "版权所有" --retouch

# 调整磨皮强度（0.0-1.0）
python scripts/add_watermark.py --input portrait.jpg --text "水印" --retouch --retouch-strength 0.8
```

### 批量处理人像照片

```bash
# 批量处理所有人像照片
python scripts/add_watermark.py --input "portraits/*.jpg" --text "© 摄影工作室" --retouch

# 输出到独立目录
python scripts/add_watermark.py --input "photos/*.jpg" --text "水印" --retouch --output retouched/
```

## ⚙️ 参数详解

### --retouch
启用智能人像磨皮功能

- 类型：布尔标志
- 默认：不启用
- 说明：检测到人脸时自动应用磨皮算法

### --retouch-strength
控制磨皮强度

- 类型：浮点数
- 范围：0.0 - 1.0
- 默认：0.6
- 说明：
  - `0.3-0.5`: 轻度磨皮，自然效果
  - `0.6-0.7`: 中度磨皮，推荐值
  - `0.8-1.0`: 重度磨皮，网红效果

## 🎨 使用场景

### 1. 人像摄影作品
```bash
python scripts/add_watermark.py --input model.jpg \
  --text "© 摄影师名字" \
  --retouch \
  --retouch-strength 0.6 \
  --position bottom-right
```

### 2.  selfie 朋友圈照片
```bash
python scripts/add_watermark.py --input selfie.jpg \
  --text "@我的微信" \
  --retouch \
  --retouch-strength 0.7 \
  --opacity 0.5
```

### 3. 商业形象照
```bash
python scripts/add_watermark.py --input business.jpg \
  --text "公司 Logo" \
  --watermark logo.png \
  --retouch \
  --retouch-strength 0.5 \
  --opacity 0.4
```

### 4. 婚纱写真
```bash
python scripts/add_watermark.py --input wedding/*.jpg \
  --text "© 婚纱摄影" \
  --retouch \
  --retouch-strength 0.65 \
  --font-size 60
```

## 📊 磨皮强度对比

| 强度值 | 效果描述 | 适用场景 |
|--------|---------|---------|
| 0.3 | 极轻微 | 证件照、正式场合 |
| 0.5 | 轻度 | 商务形象、自然美 |
| 0.6 | 中度 | 日常照片、推荐默认 |
| 0.7 | 中高度 | 艺术写真、网红风 |
| 0.8+ | 高度 | 特殊风格、杂志封面 |

## 🔬 技术原理

### 高低频分解算法

1. **频率分离**
   ```
   原始图像 = 低频层 + 高频层
   - 低频层：颜色、光影、渐变
   - 高频层：细节、纹理、边缘
   ```

2. **选择性平滑**
   - 对低频层应用高斯模糊
   - 保留高频层细节
   - 智能混合重建

3. **人脸定位**（可选）
   - 使用 OpenCV Haar 级联分类器
   - 自动检测人脸位置
   - 局部增强处理

4. **边缘羽化**
   - 高斯模糊掩膜
   - 自然过渡
   - 无人工痕迹

## 💡 最佳实践

### 1. 光线良好的照片
- 磨皮效果在光线充足的照片上最佳
- 避免在过暗或过曝照片上使用

### 2. 适度原则
- 建议强度不超过 0.8
- 保留一定皮肤质感更自然

### 3. 批量处理前测试
```bash
# 先用单张照片测试效果
python scripts/add_watermark.py --input test.jpg --text "测试" --retouch

# 满意后再批量处理
python scripts/add_watermark.py --input "photos/*.jpg" --text "水印" --retouch
```

### 4. 结合手机照片优化
```bash
# 自动检测 9:16 比例 + 自动磨皮
python scripts/add_watermark.py --input IMG_1234.jpg \
  --text "版权所有" \
  --retouch \
  --retouch-strength 0.6
# 无需额外参数，自动优化！
```

## ⚠️ 注意事项

### 性能考虑
- 磨皮会增加处理时间（约 2-5 秒/张）
- 大批量处理建议使用多进程

### 依赖要求
- 必须安装 `opencv-python-headless`
- 首次运行会下载人脸检测模型

### 兼容性
- 支持所有常见图片格式
- 处理后保持原始尺寸和比例
- EXIF 信息可能被清除

## 🐛 故障排除

### 问题：提示"磨皮功能不可用"
**解决**：
```bash
pip install -r requirements.txt
# 或
pip install opencv-python-headless numpy scipy
```

### 问题：处理速度很慢
**解决**：
- 降低图片分辨率后再处理
- 减少磨皮强度
- 禁用不必要的人脸检测

### 问题：磨皮效果不自然
**解决**：
- 降低 `--retouch-strength` 值
- 使用 0.5-0.6 的中等强度
- 确保原图质量良好

## 📈 效果对比

| 原图 | 轻度磨皮 (0.5) | 中度磨皮 (0.7) |
|-----|--------------|--------------|
| 皮肤瑕疵明显 | 轻微改善 | 明显改善 |
| 毛孔可见 | 部分柔化 | 显著柔化 |
| 肤色不均 | 有所改善 | 均匀自然 |

## 🎯 与其他功能配合

### + 手机照片优化
```bash
# 完美组合：自动检测 + 自动磨皮 + 自动水印
python scripts/add_watermark.py --input selfie.jpg \
  --text "© 2026" \
  --retouch
```

### + 自定义位置
```bash
# 磨皮后水印放在右下角
python scripts/add_watermark.py --input photo.jpg \
  --text "水印" \
  --retouch \
  --position bottom-right
```

### + 旋转水印
```bash
# 艺术效果
python scripts/add_watermark.py --input portrait.jpg \
  --text "样片" \
  --retouch \
  --rotate 30 \
  --opacity 0.3
```

---

**更新时间**: 2026-03-25  
**版本**: v2.1.0 (新增磨皮功能)