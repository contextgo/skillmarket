# 手机照片水印快速指南

## 📱 处理手机照片（9:16 比例）

### 最简单用法
```bash
# 自动检测手机照片，居中显示，大字体，半透明
python scripts/add_watermark.py --input IMG_1234.jpg --text "版权所有 © 2026"
```

### 批量处理朋友圈/Instagram 照片
```bash
# 一次性处理所有手机照片
python scripts/add_watermark.py --input "photos/*.jpg" --text "© 我的作品集"

# 输出到独立目录
python scripts/add_watermark.py --input "photos/*.jpg" --text "禁止转载" --output watermarked/
```

## ⚙️ 自定义设置

### 调整透明度
```bash
# 更透明（30%）
python scripts/add_watermark.py --input photo.jpg --text "水印" --opacity 0.3

# 更明显（70%）
python scripts/add_watermark.py --input photo.jpg --text "水印" --opacity 0.7
```

### 更改位置
```bash
# 右下角（传统位置）
python scripts/add_watermark.py --input photo.jpg --text "水印" --position bottom-right

# 左下角
python scripts/add_watermark.py --input photo.jpg --text "水印" --position bottom-left
```

### 调整字体大小
```bash
# 更大的字体（120px）
python scripts/add_watermark.py --input photo.jpg --text "大水印" --font-size 120

# 较小的字体（50px）
python scripts/add_watermark.py --input photo.jpg --text "小水印" --font-size 50
```

### 旋转水印
```bash
# 倾斜 30 度
python scripts/add_watermark.py --input photo.jpg --text "草稿" --rotate 30 --opacity 0.3
```

## 🎨 常见场景

### 摄影师作品保护
```bash
python scripts/add_watermark.py --input photo.jpg \
  --text "© 张三摄影工作室" \
  --position bottom-center \
  --opacity 0.6 \
  --font-size 60
```

### 设计稿预览
```bash
python scripts/add_watermark.py --input design.jpg \
  --text "样稿预览" \
  --position center \
  --opacity 0.3 \
  --font-size 100 \
  --rotate -20
```

### 朋友圈九宫格
```bash
# 统一添加个人标识
python scripts/add_watermark.py --input "wechat/*.jpg" \
  --text "@我的微信" \
  --position bottom-right \
  --opacity 0.5 \
  --font-size 40
```

## 📊 默认设置对比

| 场景 | 位置 | 字体大小 | 透明度 |
|------|------|----------|--------|
| 手机照片（自动） | 居中 | 自动 (80+) | 50% |
| 普通照片（默认） | 右下 | 80px | 50% |
| 版权保护 | 底部居中 | 60px | 60% |
| 草稿/预览 | 居中 | 100px | 30% |

## 💡 小贴士

1. **保持原比例**：水印处理不会改变照片的原始尺寸和比例
2. **中文支持**：完全支持中文、英文、数字和特殊字符
3. **批量处理**：建议使用 glob 模式（`*.jpg`）一次处理多张
4. **质量保护**：输出质量设置为 95%，几乎无损
5. **安全路径**：不支持 `..` 路径遍历，确保文件安全

## 🔧 禁用自动优化

如果想完全控制水印参数，可以禁用自动检测：

```bash
python scripts/add_watermark.py --input photo.jpg \
  --text "自定义水印" \
  --no-auto-detect \
  --position top-left \
  --opacity 0.8 \
  --font-size 50
```

## 📸 支持的图片比例

- **9:16** (0.5625) - iPhone/Android 手机竖拍照片 ✅ 自动优化
- **3:4** (0.75) - 微单/单反竖拍
- **4:3** (1.33) - 传统数码相机
- **16:9** (1.78) - 横拍视频截图
- **1:1** (1.0) - 正方形头像/封面

其他比例的照片会正常使用默认或自定义参数。