# 水印使用示例

## 基础文字水印

### 简单版权水印
```bash
python scripts/add_watermark.py --input photo.jpg --text "© 2026 您的名字"
```

### 自定义位置和透明度
```bash
python scripts/add_watermark.py --input photo.jpg --text "机密" --position top-left --opacity 0.5
```

### 大型居中水印
```bash
python scripts/add_watermark.py --input photo.jpg --text "草稿" --position center --font-size 80 --opacity 0.3
```

## 图片水印

### Logo水印
```bash
python scripts/add_watermark.py --input photo.jpg --watermark logo.png --scale 0.15
```

### 半透明Logo
```bash
python scripts/add_watermark.py --input photo.jpg --watermark logo.png --opacity 0.6 --position bottom-right
```

## 批量处理

### 处理所有JPG文件
```bash
python scripts/add_watermark.py --input "*.jpg" --text "样例" --output watermarked/
```

### 处理子目录中的图片
```bash
python scripts/add_watermark.py --input "photos/**/*.jpg" --text "© 作品集" --recursive
```

### 不同设置处理多张照片
```bash
# 处理风景照片
python scripts/add_watermark.py --input "landscape/*.jpg" --text "自然摄影" --position bottom-right

# 处理人像照片  
python scripts/add_watermark.py --input "portraits/*.jpg" --text "人像工作室" --position top-left
```

## 高级示例

### 旋转水印
```bash
python scripts/add_watermark.py --input photo.jpg --text "水印" --rotate 45 --position center
```

### 自定义颜色水印
```bash
python scripts/add_watermark.py --input photo.jpg --text "品牌" --color "#FF0000" --font-size 50
```

### 多步骤处理
```bash
# 首先添加版权说明
python scripts/add_watermark.py --input raw/*.jpg --text "© 2026 摄影师" --position bottom-right --output step1/

# 然后添加客户Logo
python scripts/add_watermark.py --input step1/*.jpg --watermark client-logo.png --scale 0.1 --position top-left --output final/
```

## 预设示例

使用config.py中预定义的预设：

```bash
# 使用版权预设（需要在主脚本中加载预设功能）
python scripts/add_watermark.py --input photo.jpg --preset copyright --name "张三"

# 使用草稿预设
python scripts/add_watermark.py --input photo.jpg --preset draft
```

## 输出处理

### 指定输出目录
```bash
python scripts/add_watermark.py --input photo.jpg --text "已处理" --output ./output/
```

### 指定精确输出文件名
```bash
python scripts/add_watermark.py --input input.jpg --text "已添加水印" --output result.jpg
```

### 保留原始目录结构
```bash
python scripts/add_watermark.py --input "source/**/*.jpg" --text "品牌" --output "watermarked/"
```

## 质量控制

### 高质量输出
```bash
python scripts/add_watermark.py --input photo.jpg --text "高清" --output high-quality.jpg
# 脚本自动使用 quality=95 进行JPEG输出
```

### 处理前检查文件信息
```bash
python -c "
from scripts.utils import get_file_info, format_file_size
info = get_file_info('photo.jpg')
print(f'尺寸：{info[\"width\"]}x{info[\"height\"]}')
print(f'格式：{info[\"format\"]}')
print(f'文件大小：{format_file_size(info[\"size\"])}')
"
```