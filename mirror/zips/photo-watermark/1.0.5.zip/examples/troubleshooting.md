# 故障排除指南

## 常见问题及解决方案

### 1. 文件未找到错误

**问题：** `错误：文件未找到：image.jpg`
**解决方案：** 
- 检查文件路径是否正确
- 如果相对路径不起作用，请使用绝对路径
- 验证文件权限

```bash
# 检查文件是否存在
ls -la image.jpg

# 使用绝对路径
python scripts/add_watermark.py --input /完整/路径/到/image.jpg --text "测试"
```

### 2. 不支持的图片格式

**问题：** `无法识别图片文件`
**解决方案：**
- 转换为支持的格式（JPG、PNG、GIF、BMP、TIFF）
- 安装额外的格式支持

```bash
# 使用ImageMagick转换不支持的格式
convert image.webp image.jpg

# 或使用在线转换工具
```

### 3. 大图片内存错误

**问题：** `MemoryError` 或系统无响应
**解决方案：**
- 分批次处理图片
- 临时降低图片质量
- 使用内存更大的系统

```bash
# 一次处理一张图片
for file in *.jpg; do
    python scripts/add_watermark.py --input "$file" --text "水印"
done
```

### 4. 字体问题

**问题：** `OSError: 无法打开资源` 字体错误
**解决方案：**
- 系统会自动回退到默认字体
- 安装Arial字体或指定替代字体路径

```bash
# 在macOS上，Arial通常可用
# 在Linux上，安装字体：
sudo apt-get install fonts-liberation

# 指定自定义字体（修改脚本以接受字体路径参数）
```

### 5. 透明度问题

**问题：** 水印显示为纯色而非透明
**解决方案：**
- 确保输入图片支持透明度（PNG）
- 调整透明度值（0.0-1.0范围）
- 检查输出格式是否支持透明度

```bash
# 对于JPEG输出，透明度会变成白色背景
# 使用PNG以获得真正的透明度
python scripts/add_watermark.py --input photo.png --text "透明" --output result.png
```

### 6. 定位问题

**问题：** 水印出现在错误位置
**解决方案：**
- 使用标准位置名称：top-left、center、bottom-right等
- 检查图片尺寸是否符合预期
- 对于旋转的水印，位置是在旋转前计算的

```bash
# 调试定位
python -c "
from PIL import Image
img = Image.open('test.jpg')
print(f'图片尺寸：{img.width}x{img.height}')
"
```

### 7. 权限被拒绝

**问题：** `PermissionError: [Errno 13] 权限被拒绝`
**解决方案：**
- 检查输出目录的写入权限
- 使用适当的权限运行
- 更改输出目录

```bash
# 检查权限
ls -la output/

# 方法 1：更改目录权限（推荐）
chmod 755 output/

# 方法 2：更改文件所有权（谨慎使用 sudo）
# 注意：sudo 需要管理员权限，请确保您了解其影响
chown $USER output/  # (需要管理员权限)
```

> **安全提示**: 使用 `sudo` 命令前请确保您了解其影响。建议优先尝试更改输出目录到用户有权限的位置（如主目录）。

### 8. 批量处理失败

**问题：** 部分文件处理成功，其他失败
**解决方案：**
- 检查单个文件的有效性
- 单独处理有问题的文件
- 使用详细日志记录

```bash
# 首先验证文件
python -c "
from scripts.utils import validate_image_file
import glob
files = glob.glob('*.jpg')
for f in files:
    if not validate_image_file(f):
        print(f'无效文件：{f}')
"

# 仅处理有效文件
valid_files = [f for f in glob.glob('*.jpg') if validate_image_file(f)]
```

## 调试命令

### 检查Python环境
```bash
python --version
pip list | grep -E "(Pillow|PIL)"
```

### 测试基本功能
```bash
# 创建测试图片
python -c "
from PIL import Image
img = Image.new('RGB', (800, 600), color='white')
img.save('test.jpg')
"

# 测试水印
python scripts/add_watermark.py --input test.jpg --text "测试" --output test_watermarked.jpg

# 检查结果
ls -la test*
```

### 详细处理
添加调试输出以查看发生了什么：

```python
# 添加到 add_watermark.py 进行调试
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 性能优化

> **注意**: 以下是高级用法示例，适用于熟悉命令行的高级用户。

> **提示**: 这些命令用于优化大量图片的处理性能。对于普通使用场景，直接使用主脚本的 glob 模式即可。

## 平台特定问题

### macOS
- 字体通常位于 `/System/Library/Fonts/`
- 使用预览应用验证结果

### Linux
- 安装所需包：`sudo apt-get install python3-pil`
- 字体位置：`/usr/share/fonts/`

### Windows
- 路径中使用正斜杠或转义反斜杠
- 字体在 `C:\Windows\Fonts\`

## 获取帮助

如果问题仍然存在：
1. 仔细检查错误消息
2. 首先尝试使用简单的测试图片
3. 验证所有依赖项是否已安装
4. 使用最少参数进行测试
5. 检查文件权限和路径

```bash
# 最小化测试
python scripts/add_watermark.py --input test.jpg --text "最小化"
```