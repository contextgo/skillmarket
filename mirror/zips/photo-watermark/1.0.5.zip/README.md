# 照片水印技能

一个用于为照片和图片添加专业水印的Qoder技能。

## 功能特性

- **文字水印**：添加可自定义文本、字体大小、颜色和透明度的文字叠加层
- **图片水印**：将Logo图片或其他图形作为水印叠加
- **批量处理**：使用一致的设置一次处理多张图片
- **灵活定位**：9种预设位置加上自定义放置选项
- **透明度控制**：可调节的透明度级别，从微妙到显著的水印效果
- **多种格式**：支持JPG、PNG、GIF、BMP和TIFF文件

## 安装

### 方法一：手动安装
1. 将技能目录复制到 `~/.qoder/skills/photo-watermark/`
2. 安装依赖项：
```bash
pip install Pillow
# 或者
pip install -r requirements.txt
```

### 方法二：一键安装脚本（可选）

> **注意**: 以下是示例脚本，实际使用时请替换为真实的安装脚本 URL。
> 从网络下载并执行脚本前，请务必检查脚本内容以确保安全。

```bash
# 下载并查看安装脚本（推荐先审查）
curl -O https://example.com/install-watermark.sh
cat install-watermark.sh  # 先审查脚本内容

# 确认安全后再执行
chmod +x install-watermark.sh
./install-watermark.sh
```

### 系统要求
- Python 3.6 或更高版本
- 支持的操作系统：macOS、Linux、Windows
- 至少50MB可用磁盘空间

### 字体支持
技能会自动检测系统中的中文字体。如遇字体问题：
- **macOS**: 系统自带中文字体，无需额外安装
- **Linux**: 安装中文字体包：
  ```bash
  apt-get install fonts-wqy-zenhei  # Ubuntu/Debian (需要管理员权限)
  yum install wqy-zenhei-fonts      # CentOS/RHEL (需要管理员权限)
  ```
- **Windows**: 系统自带中文字体支持

## 快速使用

### 添加文字水印
```bash
python scripts/add_watermark.py --input photo.jpg --text "© 2026 您的名字"
```

### 添加图片水印
```bash
python scripts/add_watermark.py --input photo.jpg --watermark logo.png
```

### 批量处理多张图片
```bash
python scripts/add_watermark.py --input "photos/*.jpg" --text "样例" --output watermarked/
```

## 配置

技能包含合理的默认设置，但您可以自定义：

- **透明度**：0.0（透明）到 1.0（不透明）
- **位置**：top-left（左上）、top-center（上中）、top-right（右上）、center-left（左中）、center（居中）、center-right（右中）、bottom-left（左下）、bottom-center（下中）、bottom-right（右下）
- **字体大小**：文字水印使用
- **颜色**：文字的十六进制颜色代码
- **缩放**：图片水印的大小调整
- **旋转**：水印的旋转角度

## 目录结构

```
photo-watermark/
├── SKILL.md                    # 主技能定义
├── scripts/
│   ├── add_watermark.py       # 主处理脚本
│   ├── config.py             # 配置设置
│   └── utils.py              # 工具函数
└── examples/
    ├── watermark-examples.md  # 使用示例
    └── troubleshooting.md     # 问题排查指南
```

## 与OpenClaw集成

此技能在以下情况自动激活：
- 在OpenClaw中处理图片文件
- 用户提到添加水印或保护图片
- 检测到批量处理照片

当检测到图片处理任务时，会建议使用此技能，使添加水印到您的工作流程变得无缝。

## 示例

查看 [examples/watermark-examples.md](examples/watermark-examples.md) 获取全面的使用示例。

## 故障排除

查看 [examples/troubleshooting.md](examples/troubleshooting.md) 获取常见问题和解决方案。

## 许可证

本技能按原样提供，可用于个人和商业用途。

## 🧖 人像智能磨皮（新增）

技能支持专业级的人像磨皮美化功能，使用高低频分解算法：

- **自动人脸检测**：智能定位人脸位置
- **高低频分离**：平滑皮肤同时保留纹理细节
- **可调节强度**：0.0-1.0 自由控制
- **自然过渡**：羽化边缘，无人工痕迹

```bash
# 启用磨皮功能
python scripts/add_watermark.py --input portrait.jpg --text "水印" --retouch

# 调整磨皮强度
python scripts/add_watermark.py --input photo.jpg --text "水印" --retouch --retouch-strength 0.7
```

**注意**：首次使用前需要安装依赖：
```bash
pip install -r requirements.txt
```

详细使用指南请查看 [examples/skin-retouch-guide.md](examples/skin-retouch-guide.md)
