#!/usr/bin/env python3
"""
照片水印技能 - 全平台兼容性测试脚本
不使用 subprocess，纯 Python 实现
"""

import sys
import os
from pathlib import Path


def test_import():
    """测试导入"""
    print("测试 1: 检查依赖导入...", end=' ')
    try:
        from PIL import Image
        import scripts.add_watermark as aw
        print("✅")
        return True
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_chinese_font():
    """测试中文字体"""
    print("测试 2: 检查中文字体...", end=' ')
    try:
        from scripts.add_watermark import get_chinese_font
        font = get_chinese_font(40)
        if font:
            print("✅")
            return True
        else:
            print("⚠️ (使用默认字体)")
            return True
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_mobile_detection():
    """测试手机照片检测"""
    print("测试 3: 9:16 比例检测...", end=' ')
    try:
        from scripts.add_watermark import detect_mobile_photo
        
        # 创建测试图片
        test_cases = [
            ((540, 960), True, "标准 9:16"),
            ((1080, 1920), True, "全高清 9:16"),
            ((800, 600), False, "4:3"),
            ((1920, 1080), False, "16:9"),
        ]
        
        all_passed = True
        for size, expected, desc in test_cases:
            from PIL import Image
            img = Image.new('RGB', size)
            test_file = f'test_{size[0]}x{size[1]}.jpg'
            img.save(test_file)
            
            result = detect_mobile_photo(test_file)
            os.remove(test_file)
            
            if result != expected:
                all_passed = False
                print(f"❌ ({desc} 失败)")
                break
        
        if all_passed:
            print("✅")
            return True
        else:
            return False
            
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_path_security():
    """测试路径安全"""
    print("测试 4: 路径安全检查...", end=' ')
    try:
        from scripts.add_watermark import is_safe_path
        
        test_cases = [
            ("photo.jpg", True),
            ("../etc/passwd", False),
            ("/etc/passwd", False),
            ("./photos/test.jpg", True),
        ]
        
        all_passed = True
        for path, expected in test_cases:
            result = is_safe_path(path)
            if result != expected:
                all_passed = False
                print(f"❌ ({path} 判断错误)")
                break
        
        if all_passed:
            print("✅")
            return True
        else:
            return False
            
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_watermark_basic():
    """测试基础水印功能"""
    print("测试 5: 基础水印功能...", end=' ')
    try:
        from PIL import Image
        from scripts.add_watermark import process_image
        
        # 创建测试图片
        img = Image.new('RGB', (200, 200), color='white')
        img.save('test_input.jpg')
        
        # 直接调用处理函数
        result = process_image(
            'test_input.jpg',
            'test_output.jpg',
            text='测试',
            auto_detect=False
        )
        
        # 清理
        if os.path.exists('test_input.jpg'):
            os.remove('test_input.jpg')
        if os.path.exists('test_output.jpg'):
            os.remove('test_output.jpg')
        
        if result:
            print("✅")
            return True
        else:
            print("❌ (处理失败)")
            return False
            
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_mobile_optimization():
    """测试手机照片优化"""
    print("测试 6: 手机照片自动优化...", end=' ')
    try:
        from PIL import Image
        from scripts.add_watermark import process_image, detect_mobile_photo
        
        # 创建 9:16 测试图片
        img = Image.new('RGB', (540, 960), color='lightblue')
        img.save('test_mobile.jpg')
        
        # 验证是 9:16
        is_mobile = detect_mobile_photo('test_mobile.jpg')
        
        # 处理图片
        result = process_image(
            'test_mobile.jpg',
            'test_mobile_out.jpg',
            text='手机测试',
            auto_detect=True
        )
        
        # 验证输出
        success = False
        if result and os.path.exists('test_mobile_out.jpg'):
            with Image.open('test_mobile_out.jpg') as out_img:
                ratio = out_img.width / out_img.height
                if abs(ratio - 9/16) < 0.1:
                    success = True
        
        # 清理
        if os.path.exists('test_mobile.jpg'):
            os.remove('test_mobile.jpg')
        if os.path.exists('test_mobile_out.jpg'):
            os.remove('test_mobile_out.jpg')
        
        if success and is_mobile:
            print("✅")
            return True
        else:
            print("❌")
            return False
            
    except Exception as e:
        print(f"❌ ({e})")
        return False


def test_batch_processing():
    """测试批量处理"""
    print("测试 7: 批量处理功能...", end=' ')
    try:
        from PIL import Image
        from scripts.add_watermark import process_image
        import glob
        
        # 创建多个测试图片
        test_files = []
        for i in range(3):
            img = Image.new('RGB', (100, 100), color='white')
            filename = f'test_batch_{i}.jpg'
            img.save(filename)
            test_files.append(filename)
        
        # 批量处理
        all_success = True
        output_files = []
        for test_file in test_files:
            name, ext = os.path.splitext(test_file)
            output_file = f'{name}_watermarked{ext}'
            result = process_image(
                test_file,
                output_file,
                text='批量',
                auto_detect=False
            )
            if result and os.path.exists(output_file):
                output_files.append(output_file)
            else:
                all_success = False
        
        # 清理
        for f in test_files + output_files:
            if os.path.exists(f):
                os.remove(f)
        
        if all_success:
            print("✅")
            return True
        else:
            print("❌")
            return False
            
    except Exception as e:
        print(f"❌ ({e})")
        return False


def main():
    """运行所有测试"""
    print("\n" + "="*60)
    print("  照片水印技能 - 全平台兼容性测试")
    print("  平台:", sys.platform)
    print("  Python:", sys.version.split()[0])
    print("="*60 + "\n")
    
    tests = [
        test_import,
        test_chinese_font,
        test_mobile_detection,
        test_path_security,
        test_watermark_basic,
        test_mobile_optimization,
        test_batch_processing,
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print("\n" + "="*60)
    print(f"  测试结果：{sum(results)}/{len(results)} 通过")
    print("="*60)
    
    if all(results):
        print("\n✅ 所有测试通过！可以发布到 ClawHub\n")
        return 0
    else:
        print(f"\n❌ {len(results) - sum(results)} 个测试失败\n")
        return 1


if __name__ == '__main__':
    sys.exit(main())
