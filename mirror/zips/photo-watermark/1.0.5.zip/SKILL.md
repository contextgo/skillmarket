---
name: photo-watermark
description: 为照片添加可自定义的文字或图片水印。在处理图片、添加水印或批量处理照片时使用。支持JPG、PNG和其他常见图片格式。
---

# 照片水印添加器

## 概述

本技能使用文字或图片叠加层为照片添加专业水印。非常适合保护您的图片、品牌照片或添加版权信息。

## 快速开始

### 文字水印
```bash
# 为单张图片添加文字水印
python scripts/add_watermark.py --input photo.jpg --text "© 2026 您的名字" --position bottom-right

# 为多张图片添加文字水印
python scripts/add_watermark.py --input "*.jpg" --text "样例" --opacity 0.5
```

### 图片水印
```bash
# 添加Logo水印
python scripts/add_watermark.py --input photo.jpg --watermark logo.png --scale 0.2 --position center
```

## 使用选项

### 位置选项
- `top-left`（左上）, `top-center`（上中）, `top-right`（右上）
- `center-left`（左中）, `center`（居中）, `center-right`（右中）  
- `bottom-left`（左下）, `bottom-center`（下中）, `bottom-right`（右下）

### 自定义参数
- `--opacity`: 水印透明度 (0.0-1.0)
- `--scale`: 图片水印的大小缩放因子
- `--font-size`: 文字水印的字体大小
- `--color`: 文字颜色，十六进制格式 (#RRGGBB)
- `--rotate`: 旋转角度（度）

## 批量处理

一次处理多张图片：
```bash
python scripts/add_watermark.py --input "photos/*.jpg" --text "草稿" --output "watermarked/"
```

## 示例

查看 [examples/watermark-examples.md](examples/watermark-examples.md) 获取详细的使用示例和示例输出。

## 故障排除

常见问题：
- **文件未找到**：检查输入文件路径
- **不支持的格式**：使用JPG、PNG或GIF文件
- **内存错误**：分批次处理图片

详细故障排除指南请参见 [examples/troubleshooting.md](examples/troubleshooting.md)。

## 脚本参考

主脚本：`scripts/add_watermark.py`
工具函数：`scripts/utils.py`
配置文件：`scripts/config.py`