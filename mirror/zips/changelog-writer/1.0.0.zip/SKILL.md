---
name: Changelog Writer
description: >-
  CHANGELOG生成器。变更日志、版本发布、语义化版本、差异对比、模板。Changelog writer with release notes, semver, diff, templates. CHANGELOG、版本管理。
---
# Changelog Writer

CHANGELOG生成器。变更日志、版本发布、语义化版本、差异对比、模板。Changelog writer with release notes, semver, diff, templates. CHANGELOG、版本管理。

## 与手动操作对比

| | 手动 | 使用本工具 |
|---|---|---|
| 时间 | 数小时 | 几分钟 |
| 专业度 | 取决于经验 | 专业级输出 |
| 一致性 | 易遗漏 | 标准化模板 |

## 可用命令

- **generate** — generate
- **format** — format
- **release** — release
- **semver** — semver
- **diff** — diff
- **template** — template


---
*Changelog Writer by BytesAgain*
