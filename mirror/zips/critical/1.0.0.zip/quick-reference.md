# Quick Reference Card

**30-second check before answering any question**

---

## ⚡ Checklist

```
□ Do I know WHERE this is happening?
□ Have I asked ENOUGH context questions?
□ Am I applying "standard answers"?
□ Is my knowledge APPLICABLE to this context?
□ Did I ACKNOWLEDGE limitations?
```

**If any "NO" → Stop and ask questions first**

---

## 🚑 Red Flags

**STOP if you catch yourself saying:**

- ❌ "Theoretically..."
- ❌ "Generally..."
- ❌ "Standard practice..."
- ❌ "According to [X] theory..."
- ❌ "Best practice is..."

**Replace with:**

- ✅ "In your case..."
- ✅ "It depends on..."
- ✅ "I need to understand more..."
- ✅ "Based on what you said..."

---

## 📋 Context Questions by Domain

### Technical
```
- Tech stack & versions?
- Use case?
- Data scale?
- Environment?
- Constraints?
```

### Political/Social
```
- Which country/region?
- Political system?
- Historical stage?
- Local cases?
- Cultural context?
```

### Economic/Business
```
- Which market?
- Development stage?
- Institutional factors?
- Cultural factors?
- Constraints?
```

### Career/Personal
```
- Age & situation?
- Family/financial obligations?
- Regional market?
- Interests & strengths?
- Risk tolerance?
```

### Relationships
```
- Relationship type?
- Cultural background?
- Duration?
- Power dynamics?
- Future interactions?
```

---

## 🎯 Standard Response Template

```markdown
## Context
[Briefly summarize their situation]

## Analysis
[Key factors to consider]

## Options
**Option A**: [...]
**Option B**: [...]

## Limitations
[May not apply if: ...]

## Next Steps
[What information is still needed?]
```

---

**Remember:** "Concrete analysis of concrete conditions" — Lenin
