<a name="english-version"/>

# Anti-Dogmatism & Critical Thinking Skill

> **"The essence of Marxism, the living soul of Marxism, is the concrete analysis of concrete conditions."**
>
> — Vladimir Lenin

**一个避免教条主义错误的批判性思维技能**

---

## 🎯 What is This?

**[中文](#中文版) | English**

### 📖

This is a critical thinking skill to avoid dogmatic errors by applying **concrete contextual analysis** to questions and decisions.

**Core Principle: Analyze specific problems in specific contexts**

---

## ⚡ Quick Start

### 30-Second Checklist

**Before answering any question:**

```
□ Do I know WHERE this is happening?
□ Have I asked ENOUGH context questions?
□ Am I applying "standard answers"?
□ Is my knowledge APPLICABLE to this context?
□ Did I ACKNOWLEDGE limitations?
```

**If any "NO" → Stop and ask questions first!**

---

## 📦 Installation

### For Claude Code Users

```bash
# Clone repository
git clone https://github.com/Azhu9701/anti-dogmatism-skill.git

# Copy to your skills directory
cp -r anti-dogmatism-skill ~/.claude/skills/anti-dogmatism
```

### For Everyone

Use `quick-reference.md` as a checklist before:
- Answering questions
- Giving advice
- Making decisions
- Analyzing problems

---

## 📚 Documentation Structure

```
anti-dogmatism-skill/
├── SKILL.md              # Main skill definition (start here)
├── README.md             # This file
├── PROJECT.md            # Bilingual introduction
├── quick-reference.md    # 30-second checklist
├── examples.md           # Usage examples
└── practice.md           # Practice exercises
```

---

## 🌟 Core Principles

1. **Never assume "standard answers" exist**
2. **Always ask about specific context first**
3. **Always acknowledge potential limitations**

---

## 🎓 Coverage

- 💻 **Technical Questions** - Avoid "best practices" dogma
- 🌍 **Political/Social** - Avoid Western-centrism
- 💰 **Economic/Business** - Avoid theoretical dogma
- 👔 **Career/Personal** - Avoid "success formulas"
- ❤️ **Relationships** - Avoid cookie-cutter advice

---

## 📖 Example: The China Case

### ❌ Dogmatic Error

**User:** "How can an entrepreneur drive change within their company?"

**AI:** "You must give up ownership completely..."
*(Applies Western experience without context)*

**Problem:** Didn't ask which country, ignored China's unique institutional advantages

---

### ✅ Anti-Dogmatic Approach

**AI:** "This depends on your country's system.

**In China**, with:
- Party leadership (socialist direction)
- Public ownership as mainstay
- Common prosperity strategy
- Mixed-ownership reform

Entrepreneurs can **drive change from within**:
- Employee stock ownership
- Party committee participation
- Three-level distribution
- State-supported experiments

**In Western countries**, the path is completely different.

**Different contexts require different approaches.**

---

## 🚀 Learning Path

### Beginner (1 week)

1. Read `quick-reference.md` (5 minutes)
2. Memorize 30-second checklist
3. Practice with 3 simple cases (`examples.md`)

### Intermediate (1 month)

1. Read complete `SKILL.md`
2. Complete all exercises (`practice.md`)
3. Apply for one week

### Advanced (ongoing)

1. Teach others
2. Contribute new cases
3. Improve the skill

---

## 💡 Why This Matters

### Problems

AI (and humans) often:
- ❌ Blindly apply "best practices"
- ❌ Assume Western experience is universal
- ❌ Use formulas without considering context
- ❌ Oversimplify complex issues

### Solutions

Concrete analysis:
- ✅ Ask: Where? When? What constraints?
- ✅ Analyze specific context
- ✅ Tailor advice to situation
- ✅ Acknowledge limitations

---

## 🤝 Contributing

This is **open source** (CC BY-SA 4.0). Contributions welcome:

1. Add new error cases
2. Improve domain-specific guidance
3. Share practice results
4. Help others learn

---

## 📜 License

[CC BY-SA 4.0](LICENSE)

Free to share and adapt, but must:
- ✅ Give credit
- ✅ Share alike

---

## 🎖️ Origin

This skill emerged from a real conversation where AI made a dogmatic error: applying Western historical experiences to contemporary China without considering China's unique institutional advantages.

It embodies the Marxist practice of **criticism and self-criticism** for continuous improvement.

---

## 📞 Resources

- **Complete Guide**: [SKILL.md](./SKILL.md)
- **Quick Reference**: [quick-reference.md](./quick-reference.md)
- **Examples**: [examples.md](./examples.md)
- **Practice**: [practice.md](./practice.md)

---

## 💬 Feedback

Issues, discussions, and contributions welcome!

---

**Remember:**

> **"No investigation, no right to speak"**
> 
> — Mao Zedong

**Concrete analysis of concrete conditions — Not a slogan, but a method of thinking.** ⚒️

---

**🔗 GitHub:** https://github.com/Azhu9701/anti-dogmatism-skill

---

---

<a name="中文版"/>
<a name="chinese"/>

# 反教条主义与批判性思维 Skill

> **"马克思主义的精髓，马克思主义的活的灵魂：具体问题具体分析"**
> 
> ——弗拉基米尔·列宁

**避免教条主义错误的批判性思维技能**

---

## 🎯 这是什么？

**[English](#english-version) | 中文**

### 📖

这是一个教你**避免教条主义**、通过**具体情境分析**来回答问题和做决策的Skill。

**核心理念：具体问题具体分析**

---

## ⚡ 快速开始

### 30秒检查清单

**回答任何问题前：**

```
□ 我知道这是在哪里发生的吗？
□ 我问了足够的情境问题吗？
□ 我在套用"标准答案"吗？
□ 我的知识适用于这个情境吗？
□ 我承认了局限性吗？
```

**如果任何一项"否" → 先停下来提问！**

---

## 📦 安装使用

### 对于Claude Code用户

```bash
# 克隆仓库
git clone https://github.com/Azhu9701/anti-dogmatism-skill.git

# 复制到你的skills目录
cp -r anti-dogmatism-skill ~/.claude/skills/anti-dogmatism
```

### 对于所有人

将 `quick-reference.md` 作为检查清单，在：
- 回答问题前
- 给出建议前
- 做决策前
- 分析问题时

---

## 📚 文档结构

```
anti-dogmatism-skill/
├── SKILL.md              # 主Skill定义（从这里开始）
├── README.md             # 本文件（中英双语）
├── PROJECT.md            # 中英文项目介绍
├── quick-reference.md    # 30秒快速参考卡
├── examples.md           # 使用示例（前后对比）
└── practice.md           # 实践练习
```

---

## 🌟 核心原则

1. **永远不要假设"标准答案"存在**
2. **永远先问清楚具体情境**
3. **永远承认可能存在的局限性**

---

## 🎓 覆盖的领域

- 💻 **技术问题** - 避免"最佳实践"教条
- 🌍 **政治/社会** - 避免西方中心主义
- 💰 **经济/商业** - 避免理论教条
- 👔 **职业/个人** - 避免"成功公式"
- ❤️ **关系/情感** - 避免千篇一律的建议

---

## 📖 示例：中国案例

### ❌ 教条主义错误

**用户**：企业家如何在企业内推动变革？

**AI**：你必须彻底放弃所有权...
*(套用西方历史经验，不考虑具体情境)*

**问题**：没有问在哪个国家，忽视了中国独特的制度优势

---

### ✅ 反教条主义方法

**AI**：这取决于你所在的国家制度。

在**中国**，具有：
- 党的领导（社会主义方向）
- 公有制为主体
- 共同富裕战略
- 混合所有制改革

企业家可以**从内部推动**：
- 员工持股
- 党组织参与
- 三次分配
- 国家支持的试验

在**西方国家**，路径完全不同。

**不同的情境需要不同的方法。**

---

## 🚀 学习路径

### 初级（1周）

1. 阅读 `quick-reference.md`（5分钟）
2. 记住30秒检查清单
3. 练习3个简单案例（`examples.md`）

### 中级（1个月）

1. 阅读完整 `SKILL.md`
2. 完成所有练习（`practice.md`）
3. 连续应用一周

### 高级（持续）

1. 教导他人
2. 贡献新案例
3. 改进Skill

---

## 💡 为什么这很重要？

### 问题

AI（和人类）经常：
- ❌ 盲目套用"最佳实践"
- ❌ 假设西方经验普遍适用
- ❌ 使用公式而不考虑情境
- ❌ 过度简化复杂问题

### 解决方案

具体分析：
- ✅ 问：在哪里？何时？什么约束？
- ✅ 分析具体情境
- ✅ 针对情况提供建议
- ✅ 承认局限性

---

## 🤝 贡献

本项目是**开源**的（CC BY-SA 4.0）。欢迎贡献：

1. 添加新的错误案例
2. 改进特定领域的指导
3. 分享练习结果
4. 帮助他人学习

---

## 📜 许可证

[CC BY-SA 4.0](LICENSE)

自由分享和改编，但必须：
- ✅ 署名
- ✅ 相同方式共享

---

## 🎖️ 起源

这个Skill源于一次真实对话，AI犯了教条主义错误：将西方历史经验套用到当代中国，没有考虑中国独特的制度优势。

它体现了马克思主义的**批评和自我批评**实践，用于持续改进。

---

## 📞 资源链接

- **完整指南**: [SKILL.md](./SKILL.md)
- **快速参考**: [quick-reference.md](./quick-reference.md)
- **示例**: [examples.md](./examples.md)
- **练习**: [practice.md](./practice.md)
- **项目介绍**: [PROJECT.md](./PROJECT.md)

---

## 💬 反馈

欢迎提出问题、建议和贡献！

---

## 🔥 主要改进（v2.0）

### 优先级1改进（必须）

1. ⚠️ **元认知警告** - Skill本身不能教条化
   - 独立思考 > 机械执行
   - 灵活应用 > 遵循公式
   
2. 📊 **分析级别系统**（1-4级）
   - 级别1：快速回答（不需要分析）
   - 级别2：简要分析（2-3个关键问题）
   - 级别3：深度分析（5+个问题）
   - 级别4：专业建议（律师/医生）
   
3. ✅ **简单问题过滤器** - 不是所有问题都需要深度分析

### 优先级2改进（应该）

4. ⚖️ **平衡原则** - 理想 vs 现实
   - 最少必要问题
   - 渐进式深入
   - 有条件的建议
   
5. ⚡ **紧急模式** - 当时间紧迫时
   - 快速分析
   - 有条件建议
   
6. ✅ **简化检查清单** - 从6个减少到3个核心问题

### 优先级3改进（可以）

7. 🌍 **文化敏感度** - 不同文化的沟通风格
8. 💬 **人性化沟通** - 同理心、幽默、温度
9. 🔄 **持续改进机制** - 从实践中学习

---

**记住：**

> **"没有调查，没有发言权"**
> 
> ——毛泽东

**具体问题具体分析——不是口号，而是思维方法。** ⚒️

---

**🔗 GitHub:** https://github.com/Azhu9701/anti-dogmatism-skill
