#!/usr/bin/env python3
"""
不安全示例启动文件
"""

from app import app

if __name__ == '__main__':
    app.run()
