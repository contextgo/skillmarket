#!/usr/bin/env python3
"""
公共执行器模块 - 封装 OCR 脚本的通用执行逻辑
"""
import sys
import argparse
from typing import Callable, Optional

from .ocr_client import OCRResult, CredentialManager, QuarkOCRClient
from .scene_configs import get_scene_config, list_scenes


# 结果处理器类型
ResultHandler = Callable[[OCRResult], OCRResult]
ResultHandlerWithConfig = Callable[[OCRResult, dict], OCRResult]


def run_ocr(result_handler: Optional[ResultHandler] = None,
            result_handler_with_config: Optional[ResultHandlerWithConfig] = None) -> None:
    """
    通用 OCR 执行器
    
    Args:
        result_handler: 结果处理函数，签名为 (OCRResult) -> OCRResult
        result_handler_with_config: 需要配置的结果处理函数，签名为 (OCRResult, config) -> OCRResult
    
    使用示例:
        # OCR类（不保存文件）
        run_ocr()
        
        # 图片增强类（保存图片）
        run_ocr(result_handler=save_image_from_result)
        
        # 文档转换类（保存文档，需要config判断word/excel）
        run_ocr(result_handler_with_config=save_document_from_result)
    """
    parser = argparse.ArgumentParser(
        description="Quark OCR - 支持图片 URL、本地路径、BASE64 字符串",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
可用场景（--scene 参数值）:
  {', '.join(list_scenes())}

示例:
  python3 scripts/scan.py --scene general-ocr --url "https://example.com/image.jpg"
  python3 scripts/scan.py --scene idcard-ocr --path "/path/to/idcard.jpg"
        """
    )
    
    # 场景参数（必填）
    parser.add_argument("--scene", "-s", required=True, help="场景名称（如 general-ocr, idcard-ocr 等）")
    
    # 图片输入参数（三选一）
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", "-u", help="图片 URL")
    group.add_argument("--path", "-p", help="本地图片文件路径")
    group.add_argument("--base64", "-b", help="BASE64 字符串")
    
    args = parser.parse_args()
    
    # 获取场景配置
    try:
        config = get_scene_config(args.scene)
        config["scene"] = args.scene  # 添加 scene 名称供 result_handler 使用
    except ValueError as e:
        print(OCRResult(code="INVALID_SCENE", message=str(e), data=None).to_json())
        sys.exit(1)
    
    try:
        api_key = CredentialManager.load()
        with QuarkOCRClient(
            api_key=api_key,
            scene=args.scene,
            data_type=config["data_type"]
        ) as client:
            if args.base64:
                result = client.recognize(base64_data=args.base64)
            elif args.url:
                result = client.recognize(image_url=args.url)
            else:
                result = client.recognize(image_path=args.path)
        
        # 应用结果处理器
        if result_handler_with_config:
            result = result_handler_with_config(result, config)
        elif result_handler:
            result = result_handler(result)
        
        print(result.to_json())
        
    except ValueError as e:
        print(OCRResult(code="A0100", message=str(e), data=None).to_json())
        sys.exit(1)
    except Exception as e:
        print(OCRResult(code="UNKNOWN_ERROR", message=f"Unexpected error: {str(e)}", data=None).to_json())
        sys.exit(1)
