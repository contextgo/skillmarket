#!/usr/bin/env python3
"""
添加爷爷的新叮嘱到记忆库
用法: python add_message.py "消息内容" --category 叮嘱 --tags 健康,饮食
"""

import json
import os
import sys
from datetime import datetime

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(SKILL_DIR, "data", "grandfather_messages.json")

def load_data():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_message(content, category="叮嘱", tags=None, context=""):
    data = load_data()

    new_id = max([m["id"] for m in data["messages"]], default=0) + 1

    message = {
        "id": new_id,
        "category": category,
        "tags": tags or [],
        "content": content,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "context": context
    }

    data["messages"].append(message)
    data["last_updated"] = datetime.now().strftime("%Y-%m-%d")

    save_data(data)
    print(f"✓ 已添加爷爷的新叮嘱 (ID: {new_id})")
    print(f"  内容: {content[:50]}...")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python add_message.py \"消息内容\" [--category 分类] [--tags 标签1,标签2]")
        sys.exit(1)

    content = sys.argv[1]
    category = "叮嘱"
    tags = []
    context = ""

    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--category" and i + 1 < len(sys.argv):
            category = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--tags" and i + 1 < len(sys.argv):
            tags = sys.argv[i + 1].split(",")
            i += 2
        elif sys.argv[i] == "--context" and i + 1 < len(sys.argv):
            context = sys.argv[i + 1]
            i += 2
        else:
            i += 1

    add_message(content, category, tags, context)
