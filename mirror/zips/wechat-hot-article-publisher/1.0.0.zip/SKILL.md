---
name: wechat-hot-article-publisher
description: Use when the user asks to write, assemble, publish, or push a WeChat public account article, especially when they mention WeChat article, public account, draft box, hot topics, hot search, wenyan, topic shortlist, or image matching, or want a complete workflow from topic discovery through final publication. Also use when the user wants the same article-publishing workflow reused across conversations.
metadata:
  short-description: Fixed workflow from hot-topic research to WeChat draft publication
---

# WeChat Hot Article Publisher

## Overview

Use this skill when the user wants a full WeChat public account article workflow, not just a draft.

The workflow always includes:

1. Search current hot topics from Baidu and Toutiao
2. Present 10 topic options first
3. Wait for the user to choose one topic
4. Research the chosen topic with current sources
5. Write a structured first draft
6. Run a separate humanizer refinement pass on the draft
7. Choose 3 to 5 highly relevant news photos from reporting pages, then localize them if needed
8. Format the article as Wenyan-compatible Markdown
9. Publish to the WeChat draft box with `wenyan`

Do not skip the humanizer pass. Do not skip the 10-topic selection step unless the user explicitly gives a final topic and says to proceed directly.

## When To Use

Use this skill when the user says or implies any of these:

- "Write a WeChat public account article"
- "Publish this to the WeChat draft box"
- "Research hot topics first, then write"
- "Match images and publish it"
- "Use wenyan to publish"
- "Use the same WeChat workflow as before"

Do not use this skill for:

- Generic blog posts with no WeChat publishing request
- Pure copy editing with no topic research or publication step
- WeChat replies, chat messages, or customer-service copy

## Fixed Workflow

### 1. Hot topic discovery

Always browse the web for up-to-date topics. Use current Baidu hot search and Toutiao hot topics or reliable hot-topic aggregators that reflect them.

Your output to the user at this stage is always 10 topic options.

For each option, include:

- Topic name
- Why it is hot
- Suitable article angle
- Whether it is steady, risky, light, or strong for WeChat publishing

Do not start writing the article before the user picks a topic, unless the user explicitly overrides this rule.

### 2. Source verification

After the user selects a topic, verify the core facts with current primary or high-credibility sources.

Prefer:

- Official releases
- Major mainstream reporting
- Original interviews, speeches, reports, or data pages

Always confirm dates and the actual event context before writing. If a quote or stat is central to the article, verify it first.

### 3. Drafting

Write a full first draft before polishing. The first draft should already have a clean WeChat structure:

- Strong title
- Hooked opening
- Clear subheads
- Main analysis
- Closing section
- Source list

The article should read like a mature public-account piece, not a report or memo.

### 4. Required humanizer pass

After the first draft is complete, run a separate humanizer refinement pass.

This is mandatory. Treat it as an explicit second phase, not a vague intention during drafting.

During the humanizer pass:

- Remove stiff AI-summary phrasing
- Cut inflated abstract nouns and empty macro language
- Break overly symmetrical sentence patterns
- Vary rhythm between short and long sentences
- Keep a clear human point of view
- Preserve clarity and credibility

The goal is not to make the text casual. The goal is to make it read like a real writer with judgment.

If helpful, keep both files:

- `*_draft.md` for the initial version
- final `*.md` for the humanized version

## Image Rules

### 5. Image sourcing

Images must be strongly related to the article, not generic filler.

Prefer images from the reporting pages or official pages used in the research phase. Good sources include:

- Official news or government pages
- Mainstream news pages covering the event
- Official company or institution pages tied to the story

Avoid random stock-style images when event photos exist.

### 6. Image localization for stability

Remote image hotlinks can fail during `wenyan publish`.

Preferred workflow:

1. Select relevant images from reporting pages
2. Download them to a local article image folder
3. Reference them with local relative paths in Markdown
4. Let `wenyan` upload them during publication

Use 3 to 5 images. Add a caption for each image with source attribution.

## Publication Format

### 7. Wenyan Markdown

Prepare the article as a Wenyan-compatible Markdown file with frontmatter:

```yaml
---
title: Article title
cover: ./relative/path/to/cover.png
---
```

The body should include:

- Headline
- Structured sections
- Embedded images
- Captions
- References

### 8. Publishing

Publish with the local Wenyan CLI if available, typically:

```powershell
.\node_modules\.bin\wenyan.cmd publish -f 'article.md' -t lapis -h solarized-light
```

If publishing requires WeChat credentials, use the configured local environment values or the local credential setup already present on the machine.

Default publication target is the WeChat draft box.

## Response Pattern

Unless the user already gave a final topic, the first substantial response after research should be the 10-topic shortlist.

After topic selection, the execution pattern is:

1. Research
2. Draft
3. Humanizer pass
4. Image localization
5. Final Markdown assembly
6. Wenyan publish
7. Return the file path and Media ID

## Quality Bar

Before claiming completion, verify:

- The article topic came from current hot-topic research
- The user was given 10 topic options first
- The final article was refined in a separate humanizer pass
- The images are related to the actual news event
- The Markdown is publishable by Wenyan
- The article was published to the WeChat draft box, or a concrete blocker was reported

If publishing fails because of remote image instability, switch to local copies and retry.
