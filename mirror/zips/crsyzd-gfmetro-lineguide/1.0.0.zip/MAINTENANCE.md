# 广州地铁线路推荐 Skill 维护指南

## 目录结构

```
skill_gz-metro-route/
├── SKILL.md              # 技能说明文档
├── MAINTENANCE.md        # 本维护指南
├── entry.py              # 入口文件，对外调用接口
├── data/
│   ├── lines.json        # 线路数据（手动维护）
│   └── stations.json     # 站点数据（自动生成，勿手动修改）
└── scripts/
    ├── main.py           # 命令行主程序
    ├── route_finder.py   # 路径搜索算法核心
    ├── formatter.py      # 输出格式化
    ├── generate_stations.py  # 站点数据生成器
    └── line_manager.py   # 线路数据维护脚本（可选使用）
```

## 文件关系说明

### 1. entry.py - 入口文件
**作用**：提供统一的调用接口，供外部程序或命令行使用。

**主要函数**：
- `query(start, end)` - 查询路线，返回格式化文本
- `search_station(keyword)` - 搜索站点

**依赖**：route_finder.py, formatter.py

**调用示例**：
```python
from entry import query, search_station

# 查询路线
result = query("体育西路", "广州火车站")

# 搜索站点
stations = search_station("公园")
```

### 2. route_finder.py - 路径搜索算法
**作用**：核心算法模块，实现三种路径搜索策略。

**主要类和方法**：
- `MetroRouteFinder` - 地铁路径搜索器
  - `find_all_routes(start, end)` - 返回三种策略的路线
  - `find_least_stops(start, end)` - 站数最少（BFS算法）
  - `find_fastest(start, end)` - 时间最短（Dijkstra算法）
  - `find_least_transfer(start, end)` - 换乘最少（Dijkstra变种）
  - `search_station(keyword)` - 站点模糊搜索

**数据依赖**：lines.json, stations.json

### 3. formatter.py - 输出格式化
**作用**：将路径搜索结果格式化为可读文本。

**主要函数**：
- `format_route(start, end, results)` - 格式化完整路线
- `format_simple(start, end, route)` - 简化格式

### 4. generate_stations.py - 站点数据生成器
**作用**：从lines.json生成stations.json，自动识别换乘站。

**执行方式**：
```bash
cd scripts
python3 generate_stations.py
```

**生成逻辑**：
1. 遍历所有线路的站点
2. 识别换乘站（同一站点出现在多条线路）
3. 为换乘站估算换乘时间
4. 输出stations.json

### 5. main.py - 命令行主程序
**作用**：提供命令行交互界面。

**使用方式**：
```bash
python3 main.py
# 按提示输入起点和终点
```

## 数据维护流程

### 方式一：手动编辑（适合小改动）

**步骤1**：编辑 `data/lines.json`

```json
{
  "metadata": {
    "version": "2026.04",
    "update_time": "2026-04-16",
    "source": "数据来源说明"
  },
  "lines": {
    "线路名": {
      "name": "线路名",
      "color": "#颜色代码",
      "stations": ["站点1", "站点2", ...],
      "open": true,
      "note": "备注（可选）",
      "travel_time": {
        "avg_speed_kmh": 40,      // 平均时速
        "avg_interval_min": 5,    // 平均发车间隔
        "avg_station_distance_km": 1.5  // 平均站间距
      }
    }
  }
}
```

**步骤2**：重新生成站点数据
```bash
cd scripts
python3 generate_stations.py
```

**步骤3**：测试验证
```bash
python3 ../entry.py "测试起点" "测试终点"
```

### 方式二：使用维护脚本（推荐）

执行维护脚本：
```bash
cd scripts
python3 line_manager.py
```

脚本提供以下功能：
1. 查看所有线路
2. 添加新线路
3. 修改现有线路
4. 删除线路
5. 查看线路详情
6. 搜索站点所在线路

### 数据字段说明

#### lines.json 字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | 是 | 线路名称 |
| color | string | 否 | 线路颜色（十六进制） |
| stations | array | 是 | 站点列表，按顺序排列 |
| open | boolean | 是 | 是否已开通 |
| note | string | 否 | 备注信息（如环线、跨城等） |
| travel_time.avg_speed_kmh | number | 是 | 平均时速（公里/小时） |
| travel_time.avg_interval_min | number | 是 | 平均发车间隔（分钟） |
| travel_time.avg_station_distance_km | number | 是 | 平均站间距（公里） |

#### 时间参数参考值

| 线路类型 | avg_speed_kmh | avg_interval_min | avg_station_distance_km |
|----------|---------------|------------------|-------------------------|
| 普通市区线 | 35-40 | 3-4 | 1.0-1.5 |
| 快线/郊区线 | 50-60 | 5-8 | 2.0-3.0 |
| 市域快线（18/22号线） | 80-100 | 6-8 | 4.0-6.0 |

## 常见维护场景

### 场景1：添加新开通线路

1. 获取新线路站点列表和运营参数
2. 编辑lines.json，添加新线路对象
3. 运行generate_stations.py
4. 测试新线路的站点查询

### 场景2：线路站点调整

1. 在lines.json中找到对应线路
2. 修改stations数组（增删改站点）
3. 运行generate_stations.py
4. 验证换乘站是否正确识别

### 场景3：更新运营参数

1. 在lines.json中修改travel_time字段
2. 无需运行generate_stations.py
3. 直接测试时间估算是否合理

### 场景4：添加跨城线路

1. 按普通线路格式添加
2. 在note字段标注"跨城线路"
3. 确保与现有线路的换乘站名称一致
4. 运行generate_stations.py

## 注意事项

### 站点命名规范
- 使用官方站点名称
- 换乘站在各线路中必须名称一致
- 避免使用别名或简称

### 数据更新时机
- 新线路开通前：提前准备数据
- 线路调整：及时更新站点列表
- 参数变化：根据官方公告更新

### 换乘站识别
generate_stations.py 通过站点名称匹配识别换乘站。
- 同名站点自动识别为换乘站
- 不同线路同一站点名必须完全一致

## 数据版本管理

建议在metadata中记录版本信息：
```json
{
  "metadata": {
    "version": "2026.05",
    "update_time": "2026-05-01",
    "source": "广州地铁官网",
    "changes": "新增XX线路"
  }
}
```

## 测试清单

数据更新后建议测试：
- [ ] 新增线路的站点查询
- [ ] 新增线路与其他线路的换乘查询
- [ ] 原有线路查询是否正常
- [ ] 时间估算是否合理
- [ ] 换乘站识别是否正确


## 更新记录

### 2026-04-16 更新
1. **10号线开通状态**：标记为未开通（计划2026年6月开通）
2. **经典路线推荐**：新增"经典路线"策略，确保广佛线相关路线能够推荐从珠江新城转3号线的传统路线
3. **路线搜索优化**：
   - 新增 `_find_route_via_station` 方法，支持查找经过指定站点的路线
   - 新增 `_find_simple_path_avoid_line` 方法，支持避开指定线路搜索
   - 改进备选路线搜索算法，使用优先队列提高效率