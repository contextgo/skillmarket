#!/usr/bin/env python3
"""
测试站点匹配修复
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scripts.route_finder import MetroRouteFinder

def test_station_matching():
    finder = MetroRouteFinder()
    
    # 测试"镇龙"的匹配
    print("测试'镇龙'的模糊搜索:")
    matches = finder.search_station("镇龙")
    print(f"匹配结果: {matches}")
    
    # 模拟原来的逻辑
    if matches:
        original_result = matches[0]
        print(f"原逻辑选择: {original_result}")
    
    # 模拟新的逻辑
    if matches:
        exact_match = None
        for match in matches:
            if match == "镇龙":
                exact_match = match
                break
        new_result = exact_match if exact_match else matches[0]
        print(f"新逻辑选择: {new_result}")
    
    print("\n" + "="*50)
    
    # 测试"三溪"的匹配
    print("测试'三溪'的模糊搜索:")
    matches = finder.search_station("三溪")
    print(f"匹配结果: {matches}")
    
    if matches:
        original_result = matches[0]
        print(f"原逻辑选择: {original_result}")
        
        exact_match = None
        for match in matches:
            if match == "三溪":
                exact_match = match
                break
        new_result = exact_match if exact_match else matches[0]
        print(f"新逻辑选择: {new_result}")

if __name__ == '__main__':
    test_station_matching()