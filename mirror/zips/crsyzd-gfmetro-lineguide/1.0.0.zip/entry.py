#!/usr/bin/env python3
"""
广州地铁线路推荐 Skill 入口
可直接调用，也可被其他模块导入使用
"""

import sys
import os

# 获取技能目录
SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SKILL_DIR, 'scripts'))

from route_finder import MetroRouteFinder
from formatter import format_route


def query(start: str, end: str, show_detail: bool = False) -> str:
    """
    查询广州地铁路线
    
    Args:
        start: 起点站名称（支持模糊搜索）
        end: 终点站名称（支持模糊搜索）
        show_detail: 是否显示详细路径（所有站点）
    
    Returns:
        格式化的路线推荐文本
    """
    # 加载数据
    data_dir = os.path.join(SKILL_DIR, 'data')
    finder = MetroRouteFinder(
        lines_path=os.path.join(data_dir, 'lines.json'),
        stations_path=os.path.join(data_dir, 'stations.json')
    )
    
    # 站点模糊搜索，优先精确匹配
    start_matches = finder.search_station(start)
    end_matches = finder.search_station(end)
    
    if start_matches:
        # 优先精确匹配，否则取第一个
        if start in start_matches:
            start = start
        else:
            start = start_matches[0]
    if end_matches:
        if end in end_matches:
            end = end
        else:
            end = end_matches[0]
    
    # 查询路线
    results = finder.find_all_routes(start, end)
    
    return format_route(start, end, results, show_detail=show_detail)


def search_station(keyword: str) -> list:
    """
    搜索站点
    
    Args:
        keyword: 搜索关键词
    
    Returns:
        匹配的站点名称列表
    """
    data_dir = os.path.join(SKILL_DIR, 'data')
    finder = MetroRouteFinder(
        lines_path=os.path.join(data_dir, 'lines.json'),
        stations_path=os.path.join(data_dir, 'stations.json')
    )
    return finder.search_station(keyword)


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("用法: python entry.py <起点站> <终点站> [详情/-d]")
        print("示例: python entry.py 体育西路 广州火车站")
        print("      python entry.py 体育西路 广州火车站 详情")
        sys.exit(1)
    
    start = sys.argv[1]
    end = sys.argv[2]
    show_detail = len(sys.argv) > 3 and sys.argv[3] in ['详情', '-d', 'detail']
    
    print(query(start, end, show_detail=show_detail))
