#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
合并两个 schedules 文件：
- 保留 schedules.json 的站点名称和顺序
- 使用 schedules_ali.json 中对应站点的首班发车时间
"""

import json

def merge_schedules():
    # 读取两个文件
    with open('d:/my-gitte/crs_skills/gfMetroLineGuide/data/schedules.json', 'r', encoding='utf-8') as f:
        schedules_original = json.load(f)
    
    with open('d:/my-gitte/crs_skills/gfMetroLineGuide/data/schedules_ali.json', 'r', encoding='utf-8') as f:
        schedules_ali = json.load(f)
    
    # 创建新的 schedules 数据结构
    merged_schedules = {
        "metadata": schedules_ali["metadata"],  # 使用 ali 的元数据（更新的版本信息）
        "schedules": {}
    }
    
    # 遍历原始 schedules.json 中的每条线路
    for line_key, line_data in schedules_original["schedules"].items():
        if line_key in schedules_ali["schedules"]:
            # 获取 ali 文件中该线路的时间数据
            ali_line_data = schedules_ali["schedules"][line_key]
            ali_times = ali_line_data.get("first_train_times", {})
            
            # 创建新的线路数据，保留原始站点顺序
            new_line_data = {
                "name": line_data["name"],
                "first_train_times": {}
            }
            
            # 遍历原始文件中的每个站点，从 ali 文件中获取对应的时间
            for station_name in line_data["first_train_times"].keys():
                if station_name in ali_times:
                    # 如果 ali 文件中有该站点的时间，使用它
                    new_line_data["first_train_times"][station_name] = ali_times[station_name]
                else:
                    # 如果 ali 文件中没有该站点，保留原始时间
                    new_line_data["first_train_times"][station_name] = line_data["first_train_times"][station_name]
                    print(f"警告: 线路 '{line_key}' 的站点 '{station_name}' 在 schedules_ali.json 中未找到，保留原始时间")
            
            merged_schedules["schedules"][line_key] = new_line_data
        else:
            # 如果 ali 文件中没有这条线路，保留原始数据
            print(f"警告: 线路 '{line_key}' 在 schedules_ali.json 中未找到，保留原始数据")
            merged_schedules["schedules"][line_key] = line_data
    
    # 写入合并后的文件
    with open('d:/my-gitte/crs_skills/gfMetroLineGuide/data/schedules.json', 'w', encoding='utf-8') as f:
        json.dump(merged_schedules, f, ensure_ascii=False, indent=2)
    
    print("合并完成！")
    print(f"共处理 {len(merged_schedules['schedules'])} 条线路")

if __name__ == "__main__":
    merge_schedules()
