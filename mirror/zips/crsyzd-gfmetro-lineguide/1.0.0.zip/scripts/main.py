#!/usr/bin/env python3
"""
广州地铁线路推荐 - 主入口
"""

import sys
import os

# 添加脚本目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from route_finder import MetroRouteFinder
from formatter import format_route


def query_route(start: str, end: str) -> str:
    """
    查询地铁路线
    
    Args:
        start: 起点站名称
        end: 终点站名称
    
    Returns:
        格式化的路线推荐文本
    """
    finder = MetroRouteFinder()
    
    # 模糊搜索站点
    start_matches = finder.search_station(start)
    end_matches = finder.search_station(end)
    
    # 站点名称校正 - 优先选择完全匹配的站点
    if start_matches:
        # 查找完全匹配的站点
        exact_match = None
        for match in start_matches:
            if match == start:
                exact_match = match
                break
        # 如果没有完全匹配，使用第一个模糊匹配
        start = exact_match if exact_match else start_matches[0]
    
    if end_matches:
        # 查找完全匹配的站点
        exact_match = None
        for match in end_matches:
            if match == end:
                exact_match = match
                break
        # 如果没有完全匹配，使用第一个模糊匹配
        end = exact_match if exact_match else end_matches[0]
    
    # 查询路线
    results = finder.find_all_routes(start, end)
    
    # 格式化输出
    return format_route(start, end, results)


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("用法: python main.py <起点站> <终点站>")
        print("示例: python main.py 体育西路 广州火车站")
        sys.exit(1)
    
    start = sys.argv[1]
    end = sys.argv[2]
    
    print(query_route(start, end))


if __name__ == '__main__':
    main()
