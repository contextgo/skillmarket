#!/usr/bin/env python3
"""
广州地铁路线格式化输出
"""

from typing import Dict, List, Optional


def format_route(start: str, end: str, results: Dict[str, Dict], 
                 include_time: bool = True, show_detail: bool = False) -> str:
    """
    格式化路线结果为可读文本
    
    Args:
        start: 起点站
        end: 终点站
        results: find_all_routes 的返回结果
        include_time: 是否包含时间估算
        show_detail: 是否显示详细路径（所有站点）
    
    Returns:
        格式化后的文本
    """
    if not results:
        return f"未找到从【{start}】到【{end}】的路线"
    
    # 获取推荐和备选路线
    recommended = results.get('recommended', {})
    alternatives = results.get('alternatives', [])
    
    if not recommended:
        return f"未找到从【{start}】到【{end}】的路线"
    
    lines = []
    lines.append(f"🚇 从【{start}】到【{end}】的推荐路线\n")
    
    # 去重：基于换乘站序列
    unique_routes = _deduplicate_routes(recommended)
    
    # 显示推荐路线
    lines.append("📌 推荐线路")
    lines.append("─" * 40)
    for i, route in enumerate(unique_routes, 1):
        lines.append(_format_single_route(i, route, include_time, show_detail))
    
    # 显示备选路线
    if alternatives:
        lines.append("\n📋 备选线路")
        lines.append("─" * 40)
        for i, route in enumerate(alternatives, 1):
            lines.append(_format_single_route(i, route, include_time, show_detail))
    
    # 添加特殊线路提示
    all_routes = list(recommended.values()) + alternatives
    lines.append(_get_special_notes({'r'+str(i): r for i, r in enumerate(all_routes)}))
    
    # 提示用户可以查看详情
    if not show_detail:
        lines.append("\n💡 输入「详情」可查看完整站点列表")
    
    return '\n'.join(lines)


def _format_single_route(index: int, route: Dict, include_time: bool, show_detail: bool = False) -> str:
    """格式化单条路线"""
    lines = []
    
    # 标题
    strategy = route.get('strategy', '推荐')
    lines.append(f"━━━━ 方案{index}：{strategy} ━━━━")
    
    # 摘要信息
    summary_parts = []
    if include_time and 'estimated_time' in route:
        summary_parts.append(f"⏱ 约{route['estimated_time']}分钟")
    if 'stops' in route:
        summary_parts.append(f"🚇 {route['stops']}站")
    if 'transfers' in route:
        summary_parts.append(f"🔄 换乘{route['transfers']}次")
    
    if summary_parts:
        lines.append(' | '.join(summary_parts))
    
    lines.append("")  # 空行
    
    # 简洁格式：起点--线路-->换乘站--线路-->终点
    stations = route.get('stations', [])
    segments = route.get('segments', [])
    
    if stations and segments:
        # 构建换乘站列表和线路信息
        transfer_info = []  # [(换乘站, 上一条线路, 下一条线路)]
        current_line = None
        for seg in segments:
            if not seg.get('transfer'):
                current_line = seg.get('line', '')
            elif seg.get('transfer'):
                # 找下一条线路
                next_line = None
                for s in segments[segments.index(seg)+1:]:
                    if not s.get('transfer'):
                        next_line = s.get('line', '')
                        break
                transfer_info.append({
                    'station': seg.get('from', ''),
                    'from_line': current_line,
                    'to_line': next_line
                })
        
        # 构建简洁路线描述
        simple_path = [stations[0]]  # 起点
        current_line = None
        for seg in segments:
            if not seg.get('transfer'):
                current_line = seg.get('line', '')
        
        # 重新构建：遍历segments找线路
        line_sequence = []
        for seg in segments:
            if not seg.get('transfer'):
                line_sequence.append(seg.get('line', ''))
        
        # 找换乘站
        transfer_stations = []
        for seg in segments:
            if seg.get('transfer'):
                transfer_stations.append(seg.get('from', ''))
        
        # 构建简洁格式
        simple_parts = [stations[0]]
        line_idx = 0
        for i, station in enumerate(stations[1:], 1):
            if station in transfer_stations:
                # 这是换乘站
                if line_idx < len(line_sequence):
                    simple_parts.append(f"--{line_sequence[line_idx]}-->")
                    simple_parts.append(station)
                    line_idx += 1
            elif station == stations[-1]:
                # 终点站
                if line_idx < len(line_sequence):
                    simple_parts.append(f"--{line_sequence[line_idx]}-->")
                    simple_parts.append(station)
        
        simple_route = ''.join(simple_parts)
        lines.append(f"    {simple_route}")
        
        # 如果需要显示详情，展示完整站点列表
        if show_detail:
            lines.append("")  # 空行
            lines.append("    📍 完整路径：")
            
            # 找出每段的线路名称
            segment_lines = []
            for seg in segments:
                if not seg.get('transfer'):
                    segment_lines.append(seg.get('line', ''))
            
            # 按路段输出
            segment_start = 0
            line_idx = 0
            for i, station in enumerate(stations):
                if station in transfer_stations:
                    # 输出当前段（不包含换乘站）
                    segment = stations[segment_start:i]
                    if len(segment) > 0 and line_idx < len(segment_lines):
                        lines.append(f"    🚇 {segment_lines[line_idx]}：{' → '.join(segment)}")
                        line_idx += 1
                    lines.append(f"    🔄 {station} 换乘")
                    segment_start = i + 1
            
            # 输出最后一段
            if segment_start < len(stations) and line_idx < len(segment_lines):
                segment = stations[segment_start:]
                if len(segment) > 0:
                    lines.append(f"    🚇 {segment_lines[line_idx]}：{' → '.join(segment)}")
    
    lines.append("")  # 空行
    return '\n'.join(lines)


def _deduplicate_routes(results: Dict[str, Dict]) -> List[Dict]:
    """去重，返回唯一路线列表"""
    unique = []
    seen = set()
    
    # 按优先级排序
    priority = ['fastest', 'least_stops', 'least_transfer']
    
    for key in priority:
        if key not in results:
            continue
        
        route = results[key]
        
        # 用路段的线路序列作为唯一标识
        segments = route.get('segments', [])
        path_key = tuple(seg.get('line', '') for seg in segments if not seg.get('transfer'))
        
        if path_key not in seen:
            seen.add(path_key)
            unique.append(route)
    
    return unique


def _get_special_notes(results: Dict[str, Dict]) -> str:
    """获取特殊线路提示"""
    notes = []
    seen_lines = set()  # 去重
    special_lines = {
        'APM线': 'APM线为独立票制，需另外购票',
        '广佛线': '广佛线为跨城线路',
        '18号线': '18号线为市域快线，速度较快',
        '22号线': '22号线为市域快线，速度较快',
        '佛山2号线': '佛山2号线为跨城线路',
        '佛山3号线': '佛山3号线为跨城线路',
    }
    
    for route in results.values():
        for seg in route.get('segments', []):
            line = seg.get('line', '')
            if line in special_lines and line not in seen_lines:
                notes.append(f"💡 {line}：{special_lines[line]}")
                seen_lines.add(line)
    
    if notes:
        return '\n' + '\n'.join(notes)
    return ''


def format_simple(start: str, end: str, route: Dict) -> str:
    """简化格式，只显示关键信息"""
    if not route:
        return f"未找到从【{start}】到【{end}】的路线"
    
    segments = route.get('segments', [])
    transfers = route.get('transfers', 0)
    time = route.get('estimated_time', 0)
    
    lines = []
    lines.append(f"从【{start}】到【{end}】")
    lines.append(f"约{time}分钟，换乘{transfers}次")
    
    for seg in segments:
        if not seg.get('transfer'):
            lines.append(f"  {seg['line']}：{seg['from']} → {seg['to']}（{seg['stops']}站）")
    
    return '\n'.join(lines)


# 测试
if __name__ == '__main__':
    # 模拟测试数据
    test_results = {
        'fastest': {
            'strategy': '时间最短',
            'estimated_time': 18,
            'stops': 5,
            'transfers': 1,
            'segments': [
                {'from': '体育西路', 'to': '公园前', 'line': '1号线', 'stops': 2, 'transfer': False},
                {'from': '公园前', 'to': '公园前', 'line': '换乘', 'stops': 0, 'transfer': True},
                {'from': '公园前', 'to': '广州火车站', 'line': '2号线', 'stops': 3, 'transfer': False},
            ]
        },
        'least_stops': {
            'strategy': '站数最少',
            'estimated_time': 18,
            'stops': 5,
            'transfers': 1,
            'segments': [
                {'from': '体育西路', 'to': '公园前', 'line': '1号线', 'stops': 2, 'transfer': False},
                {'from': '公园前', 'to': '公园前', 'line': '换乘', 'stops': 0, 'transfer': True},
                {'from': '公园前', 'to': '广州火车站', 'line': '2号线', 'stops': 3, 'transfer': False},
            ]
        },
        'least_transfer': {
            'strategy': '换乘最少',
            'estimated_time': 25,
            'stops': 8,
            'transfers': 1,
            'segments': [
                {'from': '体育西路', 'to': '珠江新城', 'line': '3号线', 'stops': 1, 'transfer': False},
                {'from': '珠江新城', 'to': '珠江新城', 'line': '换乘', 'stops': 0, 'transfer': True},
                {'from': '珠江新城', 'to': '广州火车站', 'line': '5号线', 'stops': 7, 'transfer': False},
            ]
        }
    }
    
    print(format_route('体育西路', '广州火车站', test_results))
