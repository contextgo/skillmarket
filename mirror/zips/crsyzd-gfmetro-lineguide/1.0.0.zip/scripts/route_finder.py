#!/usr/bin/env python3
"""
广州地铁路径搜索算法
支持三种策略：站数最少、时间最短、换乘最少
"""

import json
import heapq
from collections import deque, defaultdict
from typing import List, Dict, Tuple, Optional, Any


class MetroRouteFinder:
    """地铁路径搜索器"""
    
    def __init__(self, lines_path: str = '../data/lines.json', 
                 stations_path: str = '../data/stations.json'):
        """初始化，加载数据"""
        with open(lines_path, 'r', encoding='utf-8') as f:
            self.lines_data = json.load(f)['lines']
        
        with open(stations_path, 'r', encoding='utf-8') as f:
            self.stations_data = json.load(f)['stations']
        
        # 构建邻接表
        self.adjacency = self._build_adjacency()
    
    def _build_adjacency(self) -> Dict[str, List[Tuple[str, str]]]:
        """
        构建邻接表
        返回: {站点: [(相邻站点, 线路名), ...]}
        支持分段开通的线路
        """
        adjacency = defaultdict(list)
        
        for line_name, line_info in self.lines_data.items():
            # 检查线路是否开通
            if not line_info.get('open', True):
                continue
            
            stations = line_info.get('stations', [])
            open_segments = line_info.get('open_segments', [])
            closed_stations = line_info.get('closed_stations', [])
            
            # 处理不同的站点数据结构
            if isinstance(stations, dict):
                # 分段开通的线路（如12号线）
                for segment_name, segment_stations in stations.items():
                    # 只处理已开通的段
                    if segment_name not in open_segments and open_segments:
                        continue
                    
                    for i in range(len(segment_stations) - 1):
                        s1, s2 = segment_stations[i], segment_stations[i + 1]
                        if s1 not in closed_stations and s2 not in closed_stations:
                            adjacency[s1].append((s2, line_name))
                            adjacency[s2].append((s1, line_name))
            
            elif isinstance(stations, list):
                # 普通线路
                for i in range(len(stations) - 1):
                    s1, s2 = stations[i], stations[i + 1]
                    if s1 not in closed_stations and s2 not in closed_stations:
                        adjacency[s1].append((s2, line_name))
                        adjacency[s2].append((s1, line_name))
                
                # 处理环线（11号线）
                if line_info.get('note') == '环线':
                    if stations[0] not in closed_stations and stations[-1] not in closed_stations:
                        adjacency[stations[0]].append((stations[-1], line_name))
                        adjacency[stations[-1]].append((stations[0], line_name))
        
        return dict(adjacency)
    
    def _get_travel_time(self, station_a: str, station_b: str, line: str) -> float:
        """计算两站之间的乘车时间（分钟）"""
        line_info = self.lines_data[line]
        travel_time = line_info.get('travel_time', {})
        
        avg_speed = travel_time.get('avg_speed_kmh', 35)
        avg_distance = travel_time.get('avg_station_distance_km', 1.2)
        
        # 时间 = 距离 / 速度 * 60
        time_min = (avg_distance / avg_speed) * 60
        return time_min
    
    def _get_wait_time(self, line: str) -> float:
        """获取线路的平均等待时间（分钟）"""
        line_info = self.lines_data[line]
        travel_time = line_info.get('travel_time', {})
        interval = travel_time.get('avg_interval_min', 3)
        return interval / 2  # 平均等待时间为发车间隔的一半
    
    def _get_transfer_time(self, station: str) -> float:
        """获取换乘站的平均换乘时间（分钟）"""
        station_info = self.stations_data.get(station, {})
        return station_info.get('avg_transfer_min', 3)
    
    def find_least_stops(self, start: str, end: str) -> Optional[Dict]:
        """
        BFS找最少站数路径
        在站数相同的情况下，优先选择换乘少的
        
        返回: {
            'stops': 站数,
            'transfers': 换乘次数,
            'segments': [{'from': str, 'to': str, 'line': str, 'stops': int}, ...],
            'estimated_time': 分钟
        }
        """
        if start not in self.adjacency or end not in self.adjacency:
            return None
        
        # 改进的BFS：记录每个站点的最小站数，但允许相同站数的不同路径
        queue = deque([(start, None, [start], 0)])  # (站点, 当前线路, 完整路径, 换乘次数)
        min_stops = {}  # 站点 -> 到达该站的最小站数
        best_result = None
        
        while queue:
            station, current_line, path, transfers = queue.popleft()
            stops = len(path) - 1
            
            # 如果已经找到更好的结果，跳过
            if best_result and stops > best_result['stops']:
                continue
            
            # 如果当前站数超过已知最小站数+2，跳过（剪枝）
            if station in min_stops and stops > min_stops[station] + 1:
                continue
            
            # 更新该站点的最小站数
            if station not in min_stops or stops < min_stops[station]:
                min_stops[station] = stops
            
            if station == end:
                segments = self._parse_path_to_segments(path)
                actual_transfers = sum(1 for seg in segments if seg['transfer'])
                estimated_time = self._estimate_path_time(path)
                
                result = {
                    'stops': stops,
                    'transfers': actual_transfers,
                    'segments': segments,
                    'stations': path,  # 完整站点列表
                    'estimated_time': estimated_time,
                    'strategy': '站数最少'
                }
                
                # 更新最优结果
                if best_result is None:
                    best_result = result
                elif stops < best_result['stops']:
                    best_result = result
                elif stops == best_result['stops'] and actual_transfers < best_result['transfers']:
                    best_result = result
                continue
            
            # 扩展到相邻站点
            for next_station, next_line in self.adjacency.get(station, []):
                if next_station not in path:  # 避免回路
                    new_transfers = transfers
                    if current_line is not None and current_line != next_line:
                        new_transfers += 1
                    queue.append((next_station, next_line, path + [next_station], new_transfers))
        
        return best_result
    
    def find_fastest(self, start: str, end: str) -> Optional[Dict]:
        """
        Dijkstra找时间最短路径
        权重 = 乘车时间 + 等待时间 + 换乘时间
        """
        if start not in self.adjacency or end not in self.adjacency:
            return None
        
        # (总时间, 站点, 当前线路, 路径)
        pq = [(0, start, None, [start])]
        visited = {}  # (站点, 线路) -> 最小时间
        
        while pq:
            time, station, line, path = heapq.heappop(pq)
            
            if station == end:
                segments = self._parse_path_to_segments(path)
                transfers = sum(1 for seg in segments if seg['transfer'])
                
                return {
                    'estimated_time': round(time),
                    'stops': len(path) - 1,
                    'transfers': transfers,
                    'segments': segments,
                    'stations': path,  # 完整站点列表
                    'strategy': '时间最短'
                }
            
            state = (station, line)
            if state in visited and visited[state] <= time:
                continue
            visited[state] = time
            
            for next_station, next_line in self.adjacency.get(station, []):
                # 计算时间
                travel_time = self._get_travel_time(station, next_station, next_line)
                wait_time = self._get_wait_time(next_line) if line != next_line else 0
                
                # 换乘时间
                transfer_time = 0
                if line is not None and line != next_line:
                    transfer_time = self._get_transfer_time(station)
                
                new_time = time + travel_time + wait_time + transfer_time
                
                state_next = (next_station, next_line)
                if state_next not in visited or visited[state_next] > new_time:
                    heapq.heappush(pq, (new_time, next_station, next_line, path + [next_station]))
        
        return None
    
    def find_least_transfer(self, start: str, end: str) -> Optional[Dict]:
        """
        Dijkstra找换乘最少路径
        换乘惩罚设为较大值，但返回实际估算时间
        """
        if start not in self.adjacency or end not in self.adjacency:
            return None
        
        TRANSFER_PENALTY = 20  # 换乘惩罚（用于优先级计算）
        
        # (优先级, 实际时间, 惩罚后时间, 换乘次数, 站点, 当前线路, 路径)
        pq = [(0, 0, 0, 0, start, None, [start])]
        visited = {}
        
        while pq:
            priority, real_time, penalized_time, transfers, station, line, path = heapq.heappop(pq)
            
            if station == end:
                segments = self._parse_path_to_segments(path)
                actual_transfers = sum(1 for seg in segments if seg['transfer'])
                
                return {
                    'transfers': actual_transfers,
                    'estimated_time': round(real_time),  # 返回实际时间
                    'stops': len(path) - 1,
                    'segments': segments,
                    'stations': path,  # 完整站点列表
                    'strategy': '换乘最少'
                }
            
            state = (station, line)
            if state in visited:
                continue
            visited[state] = priority
            
            for next_station, next_line in self.adjacency.get(station, []):
                travel_time = self._get_travel_time(station, next_station, next_line)
                wait_time = self._get_wait_time(next_line) if line != next_line else 0
                transfer_time = 0
                
                new_transfers = transfers
                new_real_time = real_time + travel_time + wait_time
                new_penalized_time = penalized_time + travel_time + wait_time
                
                if line is not None and line != next_line:
                    new_transfers += 1
                    transfer_time = self._get_transfer_time(station)
                    new_real_time += transfer_time
                    new_penalized_time += TRANSFER_PENALTY
                
                new_priority = new_transfers * 100 + new_penalized_time
                state_next = (next_station, next_line)
                
                if state_next not in visited:
                    heapq.heappush(pq, (new_priority, new_real_time, new_penalized_time, 
                                       new_transfers, next_station, next_line, path + [next_station]))
        
        return None
    
    def find_all_routes(self, start: str, end: str) -> Dict[str, Dict]:
        """
        找到所有策略的路径
        
        返回: {
            'recommended': {'fastest': {...}, 'least_stops': {...}, 'least_transfer': {...}},
            'alternatives': [{...}, {...}, ...]
        }
        """
        recommended = {}
        
        # 站数最少
        result = self.find_least_stops(start, end)
        if result:
            recommended['least_stops'] = result
        
        # 时间最短
        result = self.find_fastest(start, end)
        if result:
            recommended['fastest'] = result
        
        # 换乘最少
        result = self.find_least_transfer(start, end)
        if result:
            recommended['least_transfer'] = result
        
        # 查找备选路线
        alternatives = self._find_alternatives(start, end, recommended)
        
        # 额外检查：是否有从珠江新城转3号线经沥滘的经典路线
        # 广佛线相关路线，确保有经典的珠江新城转3号线路线
        guangfo_stations = ['普君北路', '朝安', '桂城', '南桂路', '礌岗', '千灯湖', '金融高新区', 
                           '龙溪', '菊树', '西塱', '鹤洞', '沙涌', '沙园', '燕岗', '石溪', '南洲', '沥滘']
        
        if end in guangfo_stations:
            # 检查是否已有从珠江新城转3号线的经典路线
            has_classic_route = False
            for result in list(recommended.values()) + alternatives:
                stations = result.get('stations', [])
                if '珠江新城' in stations and '沥滘' in stations:
                    # 检查是否是珠江新城转3号线
                    zjxc_idx = stations.index('珠江新城')
                    if zjxc_idx + 1 < len(stations):
                        next_station = stations[zjxc_idx + 1]
                        if next_station in ['广州塔', '体育西路']:  # 3号线站点
                            has_classic_route = True
                            break
            
            if not has_classic_route:
                # 搜索经典路线
                classic_route = self._find_route_via_station(start, end, '沥滘')
                if classic_route and classic_route.get('strategy') == '经典路线':
                    alternatives.insert(0, classic_route)  # 放在备选第一位
        
        return {
            'recommended': recommended,
            'alternatives': alternatives
        }
    
    def _find_alternatives(self, start: str, end: str, recommended: Dict) -> List[Dict]:
        """查找备选路线（排除已推荐的路线）"""
        alternatives = []
        
        # 收集已推荐的路径（用站点序列作为key去重）
        seen_paths = set()
        max_transfers = 0
        min_time = float('inf')
        for result in recommended.values():
            stations = tuple(result.get('stations', []))
            if stations:
                seen_paths.add(stations)
            transfers = result.get('transfers', 0)
            if transfers > max_transfers:
                max_transfers = transfers
            time = result.get('estimated_time', float('inf'))
            if time < min_time:
                min_time = time
        
        # 备选线路换乘上限 = 推荐线路最大换乘 + 1
        transfer_limit = max_transfers + 1
        # 备选线路时间上限 = 最快时间 + 15分钟
        time_limit = min_time + 15
        
        # 使用改进的BFS收集多条路径
        # 优先队列：(优先级, 站点, 当前线路, 路径, 换乘次数, 时间)
        import heapq
        pq = [(0, start, None, [start], 0, 0)]
        visited = {}  # (站点, 线路) -> 最小时间，但允许稍慢的路径通过
        
        max_alternatives = 5
        found_paths = []
        
        while pq and len(found_paths) < max_alternatives * 3:  # 多搜索一些，再筛选
            priority, station, current_line, path, transfers, time = heapq.heappop(pq)
            
            # 剪枝
            if transfers > transfer_limit or time > time_limit:
                continue
            if len(path) > 30:
                continue
            
            if station == end:
                path_key = tuple(path)
                if path_key not in seen_paths:
                    seen_paths.add(path_key)
                    segments = self._parse_path_to_segments(path)
                    actual_transfers = sum(1 for seg in segments if seg['transfer'])
                    if actual_transfers <= transfer_limit:
                        found_paths.append({
                            'stops': len(path) - 1,
                            'transfers': actual_transfers,
                            'segments': segments,
                            'stations': path,
                            'estimated_time': round(time),
                            'strategy': '备选'
                        })
                continue
            
            # 允许多次访问同一站点（通过不同线路），但限制时间
            state = (station, current_line)
            if state in visited and visited[state] < time - 5:  # 允许5分钟的冗余
                continue
            visited[state] = time
            
            for next_station, next_line in self.adjacency.get(station, []):
                if next_station not in path:
                    new_transfers = transfers
                    new_time = time + self._get_travel_time(station, next_station, next_line)
                    
                    if current_line is not None and current_line != next_line:
                        new_transfers += 1
                        new_time += self._get_transfer_time(station)
                    
                    # 优先级：换乘次数优先，其次时间
                    new_priority = new_transfers * 100 + new_time
                    heapq.heappush(pq, (new_priority, next_station, next_line, path + [next_station], new_transfers, new_time))
        
        # 去重并排序：按换乘次数、时间排序
        unique_paths = []
        seen_stations = set()
        for p in found_paths:
            key = tuple(p['stations'])
            if key not in seen_stations:
                seen_stations.add(key)
                unique_paths.append(p)
        
        # 按换乘次数和时间排序，取前5条
        unique_paths.sort(key=lambda x: (x['transfers'], x['estimated_time']))
        alternatives = unique_paths[:max_alternatives]
        
        return alternatives
    
    def _find_route_via_station(self, start: str, end: str, via_station: str) -> Optional[Dict]:
        """
        找到经过指定站点的路线
        对于广佛线相关路线，尝试找经过珠江新城转3号线的经典路线
        """
        # 判断是否涉及广佛线（佛山方向）
        guangfo_stations = ['普君北路', '朝安', '桂城', '南桂路', '礌岗', '千灯湖', '金融高新区', 
                           '龙溪', '菊树', '西塱', '鹤洞', '沙涌', '沙园', '燕岗', '石溪', '南洲', '沥滘']
        
        # 如果终点在广佛线且经过沥滘，尝试找经过珠江新城的经典路线
        if via_station == '沥滘' and end in guangfo_stations:
            # 尝试找：start -> 珠江新城 -> 沥滘 -> end
            path1 = self._find_simple_path_avoid_line(start, '珠江新城', '11号线')
            if path1:
                path2 = self._find_simple_path('珠江新城', '沥滘')
                if path2:
                    path3 = self._find_simple_path('沥滘', end)
                    if path3:
                        # 拼接路径
                        full_path = path1 + path2[1:] + path3[1:]
                        
                        segments = self._parse_path_to_segments(full_path)
                        transfers = sum(1 for seg in segments if seg['transfer'])
                        estimated_time = self._estimate_path_time(full_path)
                        
                        return {
                            'stops': len(full_path) - 1,
                            'transfers': transfers,
                            'segments': segments,
                            'stations': full_path,
                            'estimated_time': estimated_time,
                            'strategy': '经典路线'
                        }
        
        # 默认分治法
        path1 = self._find_simple_path(start, via_station)
        if not path1:
            return None
        
        path2 = self._find_simple_path(via_station, end)
        if not path2:
            return None
        
        full_path = path1 + path2[1:]
        
        segments = self._parse_path_to_segments(full_path)
        transfers = sum(1 for seg in segments if seg['transfer'])
        estimated_time = self._estimate_path_time(full_path)
        
        return {
            'stops': len(full_path) - 1,
            'transfers': transfers,
            'segments': segments,
            'stations': full_path,
            'estimated_time': estimated_time,
            'strategy': '备选'
        }
    
    def _find_simple_path_avoid_line(self, start: str, end: str, avoid_line: str) -> Optional[List[str]]:
        """
        使用Dijkstra找一条简单路径，避开指定线路
        """
        if start not in self.adjacency or end not in self.adjacency:
            return None
        
        pq = [(0, start, None, [start])]
        visited = {}
        
        while pq:
            time, station, line, path = heapq.heappop(pq)
            
            if station == end:
                return path
            
            state = (station, line)
            if state in visited and visited[state] <= time:
                continue
            visited[state] = time
            
            for next_station, next_line in self.adjacency.get(station, []):
                # 跳过要避免的线路
                if next_line == avoid_line:
                    continue
                if next_station not in path:
                    travel_time = self._get_travel_time(station, next_station, next_line)
                    wait_time = self._get_wait_time(next_line) if line != next_line else 0
                    transfer_time = self._get_transfer_time(station) if (line is not None and line != next_line) else 0
                    
                    new_time = time + travel_time + wait_time + transfer_time
                    state_next = (next_station, next_line)
                    
                    if state_next not in visited or visited[state_next] > new_time:
                        heapq.heappush(pq, (new_time, next_station, next_line, path + [next_station]))
        
        return None
    
    def _find_simple_path(self, start: str, end: str) -> Optional[List[str]]:
        """
        使用Dijkstra找一条简单路径（时间最短）
        """
        if start not in self.adjacency or end not in self.adjacency:
            return None
        
        pq = [(0, start, None, [start])]
        visited = {}
        
        while pq:
            time, station, line, path = heapq.heappop(pq)
            
            if station == end:
                return path
            
            state = (station, line)
            if state in visited and visited[state] <= time:
                continue
            visited[state] = time
            
            for next_station, next_line in self.adjacency.get(station, []):
                if next_station not in path:
                    travel_time = self._get_travel_time(station, next_station, next_line)
                    wait_time = self._get_wait_time(next_line) if line != next_line else 0
                    transfer_time = self._get_transfer_time(station) if (line is not None and line != next_line) else 0
                    
                    new_time = time + travel_time + wait_time + transfer_time
                    state_next = (next_station, next_line)
                    
                    if state_next not in visited or visited[state_next] > new_time:
                        heapq.heappush(pq, (new_time, next_station, next_line, path + [next_station]))
        
        return None
    
    def _parse_path_to_segments(self, path: List[str]) -> List[Dict]:
        """
        将站点列表解析为路段
        
        返回: [
            {'from': str, 'to': str, 'line': str, 'stops': int, 'transfer': bool},
            ...
        ]
        """
        if len(path) < 2:
            return []
        
        segments = []
        current_line = None
        segment_start = path[0]
        segment_stops = 0
        
        for i in range(len(path) - 1):
            current = path[i]
            next_station = path[i + 1]
            
            # 找到连接这两站的线路
            connecting_line = None
            # 优先选择与当前线路相同的线路，避免不必要的换乘
            all_lines = []
            for neighbor, line in self.adjacency.get(current, []):
                if neighbor == next_station:
                    all_lines.append(line)
                    if current_line == line:
                        connecting_line = line
                        break
            
            # 如果没有匹配当前线路，选择第一个
            if connecting_line is None and all_lines:
                connecting_line = all_lines[0]
            
            if connecting_line is None:
                continue
            
            # 换乘检测
            if current_line is not None and current_line != connecting_line:
                # 结束上一段
                segments.append({
                    'from': segment_start,
                    'to': current,
                    'line': current_line,
                    'stops': segment_stops,
                    'transfer': False
                })
                # 换乘标记
                segments.append({
                    'from': current,
                    'to': current,
                    'line': '换乘',
                    'stops': 0,
                    'transfer': True
                })
                # 开始新段
                segment_start = current
                segment_stops = 0
            
            current_line = connecting_line
            segment_stops += 1
        
        # 最后一段
        if segment_stops > 0:
            segments.append({
                'from': segment_start,
                'to': path[-1],
                'line': current_line,
                'stops': segment_stops,
                'transfer': False
            })
        
        return segments
    
    def _estimate_path_time(self, path: List[str]) -> float:
        """估算路径总时间"""
        if len(path) < 2:
            return 0
        
        total_time = 0
        current_line = None
        
        for i in range(len(path) - 1):
            current = path[i]
            next_station = path[i + 1]
            
            # 找连接线路
            connecting_line = None
            for neighbor, line in self.adjacency.get(current, []):
                if neighbor == next_station:
                    connecting_line = line
                    break
            
            if connecting_line is None:
                continue
            
            # 乘车时间
            total_time += self._get_travel_time(current, next_station, connecting_line)
            
            # 等待时间（首次上车或换乘）
            if current_line is None or current_line != connecting_line:
                total_time += self._get_wait_time(connecting_line)
            
            # 换乘时间
            if current_line is not None and current_line != connecting_line:
                total_time += self._get_transfer_time(current)
            
            current_line = connecting_line
        
        return round(total_time)
    
    def search_station(self, keyword: str) -> List[str]:
        """模糊搜索站点"""
        keyword = keyword.lower()
        matches = []
        
        for station in self.stations_data.keys():
            if keyword in station.lower():
                matches.append(station)
        
        return matches[:10]  # 最多返回10个


# 测试代码
if __name__ == '__main__':
    finder = MetroRouteFinder()
    
    # 测试
    test_cases = [
        ('体育西路', '广州火车站'),
        ('西塱', '广州东站'),
        ('番禺广场', '嘉禾望岗'),
    ]
    
    for start, end in test_cases:
        print(f"\n{'='*50}")
        print(f"从【{start}】到【{end}】")
        print('='*50)
        
        results = finder.find_all_routes(start, end)
        
        for key, result in results.items():
            print(f"\n--- {result['strategy']} ---")
            print(f"站数: {result['stops']}, 换乘: {result['transfers']}, 时间: {result['estimated_time']}分钟")
            for seg in result['segments']:
                if seg['transfer']:
                    print(f"  🔄 换乘")
                else:
                    print(f"  {seg['from']} → {seg['line']} ({seg['stops']}站) → {seg['to']}")
