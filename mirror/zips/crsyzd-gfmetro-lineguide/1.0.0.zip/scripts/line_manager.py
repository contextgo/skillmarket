#!/usr/bin/env python3
"""
广州地铁线路数据维护工具
提供交互式的线路数据管理功能
"""

import json
import os
import sys

# 获取数据文件路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')
LINES_FILE = os.path.join(DATA_DIR, 'lines.json')


def load_lines():
    """加载线路数据"""
    with open(LINES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_lines(data):
    """保存线路数据"""
    with open(LINES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print("✓ 数据已保存")


def list_all_lines():
    """列出所有线路"""
    data = load_lines()
    print("\n=== 所有线路 ===")
    for line_name, line_info in data['lines'].items():
        status = "已开通" if line_info.get('open', True) else "未开通"
        station_count = len(line_info.get('stations', []))
        note = line_info.get('note', '')
        print(f"  {line_name}: {station_count}站, {status}" + (f" ({note})" if note else ""))
    print(f"\n共 {len(data['lines'])} 条线路")


def show_line_detail():
    """显示线路详情"""
    data = load_lines()
    line_name = input("请输入线路名称: ").strip()
    
    if line_name not in data['lines']:
        print(f"✗ 未找到线路: {line_name}")
        return
    
    line = data['lines'][line_name]
    print(f"\n=== {line_name} 详情 ===")
    print(f"状态: {'已开通' if line.get('open', True) else '未开通'}")
    print(f"颜色: {line.get('color', '未设置')}")
    print(f"备注: {line.get('note', '无')}")
    
    travel_time = line.get('travel_time', {})
    print(f"\n运营参数:")
    print(f"  平均时速: {travel_time.get('avg_speed_kmh', '未设置')} km/h")
    print(f"  发车间隔: {travel_time.get('avg_interval_min', '未设置')} 分钟")
    print(f"  平均站距: {travel_time.get('avg_station_distance_km', '未设置')} km")
    
    print(f"\n站点列表 ({len(line.get('stations', []))}站):")
    stations = line.get('stations', [])
    for i, station in enumerate(stations, 1):
        print(f"  {i}. {station}")


def add_line():
    """添加新线路"""
    data = load_lines()
    
    print("\n=== 添加新线路 ===")
    line_name = input("线路名称: ").strip()
    
    if line_name in data['lines']:
        print(f"✗ 线路已存在: {line_name}")
        return
    
    print("请输入站点列表，用逗号分隔（如: 站点1, 站点2, 站点3）:")
    stations_str = input("站点: ").strip()
    stations = [s.strip() for s in stations_str.split(',') if s.strip()]
    
    if not stations:
        print("✗ 站点列表不能为空")
        return
    
    print("\n请输入运营参数（直接回车使用默认值）:")
    try:
        avg_speed = input("平均时速 km/h [默认40]: ").strip()
        avg_speed = float(avg_speed) if avg_speed else 40
        
        avg_interval = input("发车间隔 分钟 [默认5]: ").strip()
        avg_interval = float(avg_interval) if avg_interval else 5
        
        avg_distance = input("平均站距 km [默认1.5]: ").strip()
        avg_distance = float(avg_distance) if avg_distance else 1.5
    except ValueError:
        print("✗ 数值格式错误")
        return
    
    note = input("备注（可选）: ").strip()
    
    # 构建线路数据
    new_line = {
        'name': line_name,
        'color': '#888888',
        'stations': stations,
        'open': True,
        'travel_time': {
            'avg_speed_kmh': avg_speed,
            'avg_interval_min': avg_interval,
            'avg_station_distance_km': avg_distance
        }
    }
    
    if note:
        new_line['note'] = note
    
    data['lines'][line_name] = new_line
    
    # 更新元数据
    data['metadata']['total_lines'] = len(data['lines'])
    data['metadata']['update_time'] = '2026-' + '-'.join(['04', '16'])  # 可改为动态获取
    
    save_lines(data)
    print(f"\n✓ 已添加线路: {line_name} ({len(stations)}站)")
    print("请运行 python3 generate_stations.py 重新生成站点数据")


def modify_line():
    """修改线路"""
    data = load_lines()
    
    print("\n=== 修改线路 ===")
    line_name = input("请输入线路名称: ").strip()
    
    if line_name not in data['lines']:
        print(f"✗ 未找到线路: {line_name}")
        return
    
    line = data['lines'][line_name]
    
    while True:
        print(f"\n当前线路: {line_name}")
        print("1. 修改站点列表")
        print("2. 修改运营参数")
        print("3. 修改备注")
        print("4. 切换开通状态")
        print("0. 完成")
        
        choice = input("选择: ").strip()
        
        if choice == '1':
            print(f"当前站点: {', '.join(line['stations'])}")
            print("请输入新站点列表（用逗号分隔）:")
            stations_str = input("站点: ").strip()
            stations = [s.strip() for s in stations_str.split(',') if s.strip()]
            if stations:
                line['stations'] = stations
                print(f"✓ 已更新站点列表 ({len(stations)}站)")
        
        elif choice == '2':
            print(f"当前参数:")
            tt = line.get('travel_time', {})
            print(f"  时速: {tt.get('avg_speed_kmh', 40)} km/h")
            print(f"  间隔: {tt.get('avg_interval_min', 5)} 分钟")
            print(f"  站距: {tt.get('avg_station_distance_km', 1.5)} km")
            
            try:
                avg_speed = input(f"平均时速 km/h [当前{tt.get('avg_speed_kmh', 40)}]: ").strip()
                if avg_speed:
                    line['travel_time']['avg_speed_kmh'] = float(avg_speed)
                
                avg_interval = input(f"发车间隔 分钟 [当前{tt.get('avg_interval_min', 5)}]: ").strip()
                if avg_interval:
                    line['travel_time']['avg_interval_min'] = float(avg_interval)
                
                avg_distance = input(f"平均站距 km [当前{tt.get('avg_station_distance_km', 1.5)}]: ").strip()
                if avg_distance:
                    line['travel_time']['avg_station_distance_km'] = float(avg_distance)
                
                print("✓ 已更新运营参数")
            except ValueError:
                print("✗ 数值格式错误")
        
        elif choice == '3':
            print(f"当前备注: {line.get('note', '无')}")
            note = input("新备注（留空清除）: ").strip()
            if note:
                line['note'] = note
            elif 'note' in line:
                del line['note']
            print("✓ 已更新备注")
        
        elif choice == '4':
            current = line.get('open', True)
            line['open'] = not current
            print(f"✓ 已切换为: {'已开通' if line['open'] else '未开通'}")
        
        elif choice == '0':
            break
    
    data['lines'][line_name] = line
    save_lines(data)
    print("\n请运行 python3 generate_stations.py 重新生成站点数据")


def delete_line():
    """删除线路"""
    data = load_lines()
    
    print("\n=== 删除线路 ===")
    line_name = input("请输入线路名称: ").strip()
    
    if line_name not in data['lines']:
        print(f"✗ 未找到线路: {line_name}")
        return
    
    line = data['lines'][line_name]
    print(f"确认删除 {line_name} ({len(line['stations'])}站)?")
    confirm = input("输入 'yes' 确认: ").strip()
    
    if confirm.lower() == 'yes':
        del data['lines'][line_name]
        data['metadata']['total_lines'] = len(data['lines'])
        save_lines(data)
        print(f"✓ 已删除线路: {line_name}")
        print("请运行 python3 generate_stations.py 重新生成站点数据")
    else:
        print("已取消")


def search_station():
    """搜索站点所在线路"""
    data = load_lines()
    
    print("\n=== 搜索站点 ===")
    keyword = input("请输入站点名称（支持模糊搜索）: ").strip().lower()
    
    if not keyword:
        print("✗ 请输入关键词")
        return
    
    results = []
    for line_name, line_info in data['lines'].items():
        for station in line_info.get('stations', []):
            if keyword in station.lower():
                results.append((station, line_name))
    
    if results:
        print(f"\n找到 {len(results)} 个匹配:")
        for station, line_name in results:
            print(f"  {station} - {line_name}")
    else:
        print("未找到匹配的站点")


def regenerate_stations():
    """重新生成站点数据"""
    print("\n正在生成站点数据...")
    
    # 导入并执行generate_stations
    import generate_stations
    # 该脚本执行后会自动输出结果
    print("✓ 站点数据已更新")


def main():
    """主菜单"""
    while True:
        print("\n" + "="*50)
        print("广州地铁线路数据维护工具")
        print("="*50)
        print("1. 查看所有线路")
        print("2. 查看线路详情")
        print("3. 添加新线路")
        print("4. 修改现有线路")
        print("5. 删除线路")
        print("6. 搜索站点")
        print("7. 重新生成站点数据")
        print("0. 退出")
        print("-"*50)
        
        choice = input("请选择: ").strip()
        
        if choice == '1':
            list_all_lines()
        elif choice == '2':
            show_line_detail()
        elif choice == '3':
            add_line()
        elif choice == '4':
            modify_line()
        elif choice == '5':
            delete_line()
        elif choice == '6':
            search_station()
        elif choice == '7':
            regenerate_stations()
        elif choice == '0':
            print("再见!")
            break
        else:
            print("无效选择，请重试")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n已取消")
    except Exception as e:
        print(f"错误: {e}")
