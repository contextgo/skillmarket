#!/usr/bin/env python3
"""
从 lines.json 生成 stations.json
自动识别换乘站，添加换乘时间估算
支持分段开通的线路
"""

import json
from collections import defaultdict

def generate_stations():
    # 读取线路数据
    with open('../data/lines.json', 'r', encoding='utf-8') as f:
        lines_data = json.load(f)
    
    # 统计每个站点属于哪些线路
    station_lines = defaultdict(list)
    
    for line_name, line_info in lines_data['lines'].items():
        # 检查线路是否开通
        if not line_info.get('open', True):
            continue
        
        stations = line_info.get('stations', [])
        open_segments = line_info.get('open_segments', [])
        closed_stations = line_info.get('closed_stations', [])
        
        # 处理不同的站点数据结构
        if isinstance(stations, dict):
            # 分段开通的线路（如12号线）
            for segment_name, segment_stations in stations.items():
                # 只处理已开通的段
                if segment_name in open_segments or not open_segments:
                    for station in segment_stations:
                        if station not in closed_stations:
                            if line_name not in station_lines[station]:
                                station_lines[station].append(line_name)
        elif isinstance(stations, list):
            # 普通线路
            for station in stations:
                if station not in closed_stations:
                    if line_name not in station_lines[station]:
                        station_lines[station].append(line_name)
        
        # 处理支线
        if 'branches' in line_info:
            for branch_name, branch_stations in line_info['branches'].items():
                for station in branch_stations:
                    if station not in closed_stations:
                        if line_name not in station_lines[station]:
                            station_lines[station].append(line_name)
    
    # 构建站点数据
    stations = {}
    for station, lines in station_lines.items():
        is_transfer = len(lines) > 1
        
        station_data = {
            "lines": lines,
            "is_transfer": is_transfer
        }
        
        # 为换乘站添加换乘时间估算
        if is_transfer:
            # 根据换乘线路数量估算平均换乘时间
            # 默认：2条线换乘 2.5分钟，3条线 3分钟，4条及以上 3.5分钟
            if len(lines) == 2:
                avg_transfer_min = 2.5
            elif len(lines) == 3:
                avg_transfer_min = 3.0
            else:
                avg_transfer_min = 3.5
            
            station_data["avg_transfer_min"] = avg_transfer_min
        
        stations[station] = station_data
    
    # 统计信息
    total_stations = len(stations)
    transfer_stations = sum(1 for s in stations.values() if s['is_transfer'])
    
    # 输出结果
    output = {
        "metadata": {
            "version": "2026.04",
            "update_time": "2026-04-16",
            "total_stations": total_stations,
            "transfer_stations": transfer_stations,
            "note": "换乘时间为估算值，实际换乘时间可能因站点结构不同而有差异"
        },
        "stations": stations
    }
    
    # 写入文件
    with open('../data/stations.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    
    print(f"生成完成！")
    print(f"总站点数: {total_stations}")
    print(f"换乘站数: {transfer_stations}")

if __name__ == '__main__':
    generate_stations()
