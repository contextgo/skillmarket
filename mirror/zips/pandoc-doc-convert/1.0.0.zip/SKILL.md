---
name: pandoc-doc-convert
description: 使用 Pandoc 将 Markdown 转换为 DOCX，并支持模板化输出与批量转换。适用于用户提到 markdown 转 word/doc/docx、文档格式转换、套用公司模板等场景。采用可扩展流程，可平滑增加 pdf/html 等目标格式。
license: Proprietary
compatibility: Pandoc 3.x+
metadata:
  version: "1.0.0"
  domain: document-conversion
---

# Pandoc 文档格式转换（默认 Markdown -> DOCX）

当用户需要把 Markdown 转为 Word 文档时，优先使用本技能。该技能基于社区高口碑实践（Pandoc）实现，先保证稳定可用，再兼顾模板化和批量化。

## 何时使用

- 用户提到：`markdown 转 docx`、`md 转 word`、`导出 doc`、`文档转换`。
- 用户要求保留样式、套用公司模板、批量处理多个 Markdown 文件。
- 用户后续希望扩展到 `pdf`、`html` 等其他输出格式。

## 默认策略（高分实践）

1. 优先使用 Pandoc 官方推荐命令，不自造转换链路。
2. 默认目标格式为 `docx`，输入默认是 `markdown`。
3. 若用户提供模板，使用 `--reference-doc` 保持企业样式一致。
4. 若用户未指定输出文件名，按输入文件同名生成输出文件。

## 执行流程

1. 参数标准化
   - 必填：输入文件路径。
   - 选填：输出格式（默认 `docx`）、输出路径、模板路径、是否批量转换。
2. 环境检查
   - 先执行 `pandoc --version`，若不可用则提示安装：
   - Windows: `winget install --id JohnMacFarlane.Pandoc -e`
3. 构造命令
   - 单文件（默认）：
     - `pandoc "input.md" -o "output.docx"`
   - 指定 Markdown 输入类型（可选）：
     - `pandoc -f markdown "input.md" -o "output.docx"`
   - 模板化输出（推荐企业文档）：
     - `pandoc "input.md" -o "output.docx" --reference-doc="template.docx"`
4. 执行与校验
   - 执行转换命令。
   - 检查输出文件是否生成且非空。
5. 结果反馈
   - 返回输出路径、是否使用模板、是否有警告。

## 可扩展格式路由

将“目标格式”作为第一层分支，保持命令骨架一致：

- `docx`（当前主路径）：
  - `pandoc "input.md" -o "output.docx"`
- `pdf`（扩展路径）：
  - `pandoc "input.md" -o "output.pdf"`
  - 若缺少 PDF 引擎，补充 `--pdf-engine=xelatex` 或按环境安装引擎。
- `html`（扩展路径）：
  - `pandoc "input.md" -o "output.html"`

扩展规则：新增格式时仅增加“格式分支 + 最小必要参数”，不要改动默认 `docx` 主流程。

## 批量转换规范

当用户要求批量转换时：

1. 先确认输入目录与输出目录。
2. 遍历目录下 `.md` 文件，为每个文件生成同名输出。
3. 每个文件独立执行转换并记录成功/失败。
4. 最终汇总：总数、成功数、失败数、失败文件及原因。

## 异常处理

- 未安装 Pandoc：明确安装命令，不继续假执行。
- 输入文件不存在：直接报错并返回缺失路径。
- 模板文件不存在：回退为无模板转换，并提示用户。
- 输出格式不支持：提示当前支持格式并建议可扩展项。

## 输出模板

按以下结构返回给用户：

```markdown
转换完成。
- 输入: <input>
- 输出: <output>
- 目标格式: <format>
- 模板: <template or 未使用>
- 执行命令: <command>
- 结果: 成功/失败
- 备注: <warning or 无>
```
