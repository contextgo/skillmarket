#!/bin/bash
# === Start headful Chrome + VNC + noVNC environment ===
# Usage: bash start.sh [password] [novnc_port] [cdp_port] [resolution]
#        bash start.sh --dangerously-no-password [novnc_port] [cdp_port] [resolution]
#
# Password is MANDATORY. A random 14-char password is generated if not provided.
# The only way to skip password is --dangerously-no-password (NOT recommended).

generate_password() {
  cat /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 14
}

NO_PASSWORD=false

# Parse first arg
if [ "$1" = "--dangerously-no-password" ]; then
  NO_PASSWORD=true
  echo "⚠️  WARNING: Running WITHOUT VNC password. This is insecure!"
  shift
  VNC_PASS=""
  NOVNC_PORT="${1:-6080}"
  CDP_PORT="${2:-9222}"
  RESOLUTION="${3:-1920x1080x24}"
elif [ -n "$1" ]; then
  VNC_PASS="$1"
  NOVNC_PORT="${2:-6080}"
  CDP_PORT="${3:-9222}"
  RESOLUTION="${4:-1920x1080x24}"
else
  VNC_PASS="$(generate_password)"
  NOVNC_PORT="${2:-6080}"
  CDP_PORT="${3:-9222}"
  RESOLUTION="${4:-1920x1080x24}"
fi

VNC_PORT=5900
DISPLAY_NUM=99

echo "=== Stopping existing processes ==="
pkill -9 -f "Xvfb :$DISPLAY_NUM" 2>/dev/null
pkill -9 -f x11vnc 2>/dev/null
pkill -9 -f websockify 2>/dev/null
pkill -9 -f fluxbox 2>/dev/null
pkill -9 -f "chrome.*remote-debugging" 2>/dev/null
sleep 2

# Clean stale lock files
rm -f "/tmp/.X${DISPLAY_NUM}-lock" "/tmp/.X11-unix/X${DISPLAY_NUM}" 2>/dev/null

# === SSL cert (self-signed, reuse if exists) ===
mkdir -p /root/.vnc
if [ ! -f /root/.vnc/combined.pem ]; then
  echo "Generating self-signed SSL certificate..."
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /root/.vnc/key.pem -out /root/.vnc/cert.pem \
    -subj "/CN=openclaw-vnc" 2>/dev/null
  cat /root/.vnc/key.pem /root/.vnc/cert.pem > /root/.vnc/combined.pem
fi

# === VNC password file ===
if [ "$NO_PASSWORD" = false ]; then
  x11vnc -storepasswd "$VNC_PASS" /root/.vnc/passwd 2>/dev/null
fi

# === Xvfb (virtual display) ===
echo "Starting Xvfb..."
Xvfb :$DISPLAY_NUM -screen 0 $RESOLUTION &
sleep 1
export DISPLAY=:$DISPLAY_NUM

# === Window manager ===
fluxbox &>/dev/null &
sleep 1

# === Chrome policy: block file:// access ===
mkdir -p /etc/opt/chrome/policies/managed
cat > /etc/opt/chrome/policies/managed/security.json << 'POLICY'
{
  "URLBlocklist": ["file://*", "javascript://*", "data:text/html*"],
  "DeveloperToolsAvailability": 0,
  "ExtensionInstallBlocklist": ["*"],
  "BrowserAddPersonEnabled": false
}
POLICY

# === Chrome headful with anti-detection ===
echo "Starting Chrome (CDP port $CDP_PORT)..."
google-chrome-stable \
  --no-sandbox \
  --disable-gpu \
  --disable-dev-shm-usage \
  --disable-blink-features=AutomationControlled \
  --user-data-dir=/root/.chrome-profile \
  --remote-debugging-port=$CDP_PORT \
  --remote-debugging-address=127.0.0.1 \
  --remote-allow-origins=* \
  --display=:$DISPLAY_NUM \
  --window-size=$(echo $RESOLUTION | cut -dx -f1),$(echo $RESOLUTION | cut -dx -f2) \
  --start-maximized \
  &>/dev/null &
sleep 3

# === x11vnc (password protected, shared) ===
echo "Starting x11vnc..."
if [ "$NO_PASSWORD" = true ]; then
  x11vnc -display :$DISPLAY_NUM -forever -shared -noshm \
    -rfbport $VNC_PORT \
    -bg -o /tmp/x11vnc.log
else
  x11vnc -display :$DISPLAY_NUM -forever -shared -noshm \
    -rfbauth /root/.vnc/passwd \
    -rfbport $VNC_PORT \
    -bg -o /tmp/x11vnc.log
fi
sleep 1

# === noVNC with SSL ===
echo "Starting noVNC (port $NOVNC_PORT)..."
websockify --web=/usr/share/novnc --cert=/root/.vnc/combined.pem \
  $NOVNC_PORT localhost:$VNC_PORT &>/tmp/novnc.log &
sleep 1

# === Verify ===
FAIL=0
pgrep -f "Xvfb :$DISPLAY_NUM" > /dev/null || { echo "ERROR: Xvfb failed"; FAIL=1; }
pgrep -f "x11vnc" | grep -v defunct > /dev/null || { echo "ERROR: x11vnc failed"; cat /tmp/x11vnc.log; FAIL=1; }
pgrep -f "websockify.*$NOVNC_PORT" > /dev/null || { echo "ERROR: websockify failed"; FAIL=1; }
pgrep -f "chrome.*$CDP_PORT" > /dev/null || { echo "ERROR: Chrome failed"; FAIL=1; }

if [ $FAIL -eq 0 ]; then
  echo ""
  echo "=========================================="
  echo "  VNC Browser Environment Ready!"
  echo "=========================================="
  if [ "$NO_PASSWORD" = true ]; then
    echo "  noVNC:    https://<YOUR_IP>:${NOVNC_PORT}/vnc.html?autoconnect=true&resize=scale"
    echo "  Password: NONE (--dangerously-no-password)"
  else
    echo "  noVNC:    https://<YOUR_IP>:${NOVNC_PORT}/vnc.html?password=${VNC_PASS}&autoconnect=true&resize=scale"
    echo "  Password: ${VNC_PASS}"
  fi
  echo "  CDP:      http://127.0.0.1:${CDP_PORT}/json/version"
  echo "=========================================="

  # === Install healthcheck cron (auto-recovery) ===
  SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
  HC_SRC="$SCRIPT_DIR/healthcheck.sh"
  HC_DST="/root/healthcheck.sh"
  if [ -f "$HC_SRC" ]; then
    cp "$HC_SRC" "$HC_DST"
    chmod +x "$HC_DST"
  fi
  if [ -f "$HC_DST" ]; then
    CRON_CMD="*/2 * * * * bash $HC_DST $DISPLAY_NUM $VNC_PORT $NOVNC_PORT $CDP_PORT >> /tmp/anemone-healthcheck.log 2>&1"
    # Add cron only if not already present
    (crontab -l 2>/dev/null | grep -v "healthcheck.sh"; echo "$CRON_CMD") | crontab -
    echo "  Healthcheck: cron installed (every 2 min)"
  fi
else
  echo "Some services failed to start. Check logs above."
  exit 1
fi
