---
name: securities-news
description: '检索A股相关证券资讯，支持官方媒体、自媒体、精准搜索及全媒体聚合，可按时间、关键词、标签过滤。当用户想查找政策新闻、公告、行业资讯或财经要闻时触发。Use when: "新能源最新重要新闻", "监管层对XX行业最新表态", "今天有哪些财经要闻". Calls tools: officialSecuNews, weMediaSecuNews, queryAllMediaSecuNews, querySecuritiesNews.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 证券资讯

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

提供多渠道证券资讯检索：
- **官方媒体**：新华社、人民日报、证监会、交易所等权威来源
- **自媒体**：财经博主、研究机构公众号等自媒体资讯
- **精准搜索**：按要闻/快讯/研报切片等栏目精细过滤
- **全媒体聚合**：同时搜索官媒 + 自媒体，一次获取全面资讯

## 触发场景

- "最近有什么关于新能源的重要新闻？"
- "监管层对 XX 行业有什么最新表态？"
- "帮我找找关于 XX 公司的最新公告"
- "今天有哪些值得关注的财经要闻？"

## 执行步骤

### 场景 A：官方媒体资讯

```json
调用工具: officialSecuNews
参数: {
  "query": "<用户问题或关键词>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5",
  "relevance": "0.66"
}
```

### 场景 B：自媒体资讯

```json
调用工具: weMediaSecuNews
参数: {
  "query": "<用户问题或关键词>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5",
  "relevance": "0.5"
}
```

### 场景 C：全媒体聚合搜索（推荐默认方案）

```json
调用工具: queryAllMediaSecuNews
参数: {
  "query": "<自然语言查询内容>",
  "keyword": "<精确关键词>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "10",
  "relevance": "0.6"
}
```

### 场景 D：精准分栏目搜索

```json
调用工具: querySecuritiesNews
参数: {
  "query": "<查询内容>",
  "newsColumn": "要闻",
  "sliceColumn": "研报切片-个股研报,资讯切片-行业资讯",
  "source": "<媒体来源>",
  "title": "<标题关键词>",
  "tags": "<标签文本>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "maxCnt": "5"
}
```

#### 可用切片栏目（sliceColumn）

| 栏目类型 | 可选值 |
|---|---|
| 资讯切片 | 资讯切片-其他宏观、资讯切片-宏观数据、资讯切片-宏观政策、资讯切片-行业资讯、资讯切片-板块资讯 |
| 研报切片 | 研报切片-个股研报、研报切片-资讯提取、研报切片-行业研报、研报切片-基金研报、研报切片-宏观研报 |

## 使用策略

| 需求 | 推荐工具 |
|---|---|
| 政策、监管、宏观要闻 | `officialSecuNews` |
| 市场情绪、热门话题 | `weMediaSecuNews` |
| 一次性全面搜索 | `queryAllMediaSecuNews` |
| 按研报/要闻等栏目精筛 | `querySecuritiesNews` |

## 注意事项

- `startDate` 和 `endDate` 均不填时默认为今天，建议指定范围以获得更精准结果。
- `relevance` 越高筛选越严格，若结果过少可适当降低阈值。
