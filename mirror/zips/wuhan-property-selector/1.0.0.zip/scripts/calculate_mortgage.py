#!/usr/bin/env python3
"""
房贷计算器
计算月供、总利息、还款计划等
"""

import sys
import json


def calculate_monthly_payment(principal, annual_rate, years):
    """
    计算等额本息月供
    
    Args:
        principal: 贷款本金（万元）
        annual_rate: 年利率（%）
        years: 贷款年限
    
    Returns:
        月供（元）
    """
    principal_yuan = principal * 10000
    monthly_rate = annual_rate / 100 / 12
    months = years * 12
    
    if monthly_rate == 0:
        return principal_yuan / months
    
    monthly_payment = principal_yuan * monthly_rate * (1 + monthly_rate) ** months / \
                      ((1 + monthly_rate) ** months - 1)
    
    return round(monthly_payment, 2)


def calculate_loan_schedule(total_price, down_payment_ratio, annual_rate, years, fund_loan=0, fund_rate=2.85):
    """
    计算完整贷款方案
    
    Args:
        total_price: 房屋总价（万元）
        down_payment_ratio: 首付比例（%）
        annual_rate: 商贷年利率（%）
        years: 贷款年限
        fund_loan: 公积金贷款金额（万元），默认0
        fund_rate: 公积金贷款利率（%），默认2.85%
    
    Returns:
        贷款方案详情
    """
    down_payment = total_price * down_payment_ratio / 100
    loan_amount = total_price - down_payment
    
    # 如果有公积金贷款
    if fund_loan > 0:
        commercial_loan = loan_amount - fund_loan
        commercial_monthly = calculate_monthly_payment(commercial_loan, annual_rate, years)
        fund_monthly = calculate_monthly_payment(fund_loan, fund_rate, years)
        monthly_payment = commercial_monthly + fund_monthly
        
        commercial_total = commercial_monthly * years * 12
        fund_total = fund_monthly * years * 12
        total_payment = commercial_total + fund_total
        total_interest = total_payment - (loan_amount * 10000)
        
        return {
            "total_price": total_price,
            "down_payment": round(down_payment, 2),
            "down_payment_ratio": down_payment_ratio,
            "loan_amount": round(loan_amount, 2),
            "commercial_loan": round(commercial_loan, 2),
            "fund_loan": round(fund_loan, 2),
            "monthly_payment": round(monthly_payment, 2),
            "commercial_monthly": round(commercial_monthly, 2),
            "fund_monthly": round(fund_monthly, 2),
            "total_payment": round(total_payment / 10000, 2),
            "total_interest": round(total_interest / 10000, 2),
            "years": years,
            "months": years * 12
        }
    else:
        # 纯商贷
        monthly_payment = calculate_monthly_payment(loan_amount, annual_rate, years)
        total_payment = monthly_payment * years * 12
        total_interest = total_payment - (loan_amount * 10000)
        
        return {
            "total_price": total_price,
            "down_payment": round(down_payment, 2),
            "down_payment_ratio": down_payment_ratio,
            "loan_amount": round(loan_amount, 2),
            "monthly_payment": round(monthly_payment, 2),
            "total_payment": round(total_payment / 10000, 2),
            "total_interest": round(total_interest / 10000, 2),
            "years": years,
            "months": years * 12
        }


def calculate_rental_yield(monthly_rent, total_price):
    """
    计算租金回报率
    
    Args:
        monthly_rent: 月租金（元）
        total_price: 房屋总价（万元）
    
    Returns:
        年租金回报率（%）
    """
    annual_rent = monthly_rent * 12
    total_price_yuan = total_price * 10000
    yield_rate = (annual_rent / total_price_yuan) * 100
    return round(yield_rate, 2)


def calculate_pressure_index(monthly_payment, monthly_income):
    """
    计算还贷压力指数
    
    Args:
        monthly_payment: 月供（元）
        monthly_income: 月收入（元）
    
    Returns:
        压力指数（月供占收入比例%）
    """
    if monthly_income == 0:
        return 100
    pressure = (monthly_payment / monthly_income) * 100
    return round(pressure, 1)


def get_pressure_level(pressure_index):
    """
    根据压力指数返回压力等级
    """
    if pressure_index < 30:
        return "轻松", "green"
    elif pressure_index < 40:
        return "适中", "yellow"
    elif pressure_index < 50:
        return "偏紧", "orange"
    else:
        return "压力过大", "red"


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python calculate_mortgage.py <command> [args...]")
        print("Commands:")
        print("  loan <总价> <首付比例> <利率> <年限> [公积金] [公积金利率]")
        print("  rent <月租> <总价>")
        print("  pressure <月供> <月收入>")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "loan":
        if len(sys.argv) < 6:
            print("Usage: loan <总价(万)> <首付比例(%))> <利率(%))> <年限> [公积金(万)] [公积金利率(%)]")
            sys.exit(1)
        
        total_price = float(sys.argv[2])
        down_payment_ratio = float(sys.argv[3])
        annual_rate = float(sys.argv[4])
        years = int(sys.argv[5])
        fund_loan = float(sys.argv[6]) if len(sys.argv) > 6 else 0
        fund_rate = float(sys.argv[7]) if len(sys.argv) > 7 else 2.85
        
        result = calculate_loan_schedule(total_price, down_payment_ratio, annual_rate, years, fund_loan, fund_rate)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "rent":
        if len(sys.argv) < 4:
            print("Usage: rent <月租(元)> <总价(万)>")
            sys.exit(1)
        
        monthly_rent = float(sys.argv[2])
        total_price = float(sys.argv[3])
        
        yield_rate = calculate_rental_yield(monthly_rent, total_price)
        print(json.dumps({"rental_yield": yield_rate}, ensure_ascii=False))
    
    elif command == "pressure":
        if len(sys.argv) < 4:
            print("Usage: pressure <月供(元)> <月收入(元)>")
            sys.exit(1)
        
        monthly_payment = float(sys.argv[2])
        monthly_income = float(sys.argv[3])
        
        pressure_index = calculate_pressure_index(monthly_payment, monthly_income)
        level, color = get_pressure_level(pressure_index)
        print(json.dumps({
            "pressure_index": pressure_index,
            "level": level,
            "color": color
        }, ensure_ascii=False))
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
