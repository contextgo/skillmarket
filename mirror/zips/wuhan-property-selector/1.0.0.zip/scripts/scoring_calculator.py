#!/usr/bin/env python3
"""
房产综合评分计算器
整合各维度评分，计算综合得分
"""

import sys
import json


# 默认权重配置
DEFAULT_WEIGHTS = {
    "fengshui": 0.15,
    "layout": 0.20,
    "traffic": 0.20,
    "school": 0.15,
    "facility": 0.15,
    "finance": 0.15
}

# 针对不同需求的权重调整
WEIGHT_PRESETS = {
    "balanced": DEFAULT_WEIGHTS,  # 均衡型
    "school_focused": {  # 学区优先
        "fengshui": 0.10,
        "layout": 0.15,
        "traffic": 0.15,
        "school": 0.30,
        "facility": 0.15,
        "finance": 0.15
    },
    "investment": {  # 投资优先
        "fengshui": 0.10,
        "layout": 0.15,
        "traffic": 0.20,
        "school": 0.10,
        "facility": 0.15,
        "finance": 0.30
    },
    "living": {  # 自住舒适优先
        "fengshui": 0.20,
        "layout": 0.25,
        "traffic": 0.15,
        "school": 0.15,
        "facility": 0.15,
        "finance": 0.10
    }
}


def calculate_dimension_score(dimension_data, dimension_name):
    """
    计算单个维度的得分
    
    Args:
        dimension_data: 维度数据字典
        dimension_name: 维度名称
    
    Returns:
        维度得分（0-10）
    """
    if dimension_name == "traffic":
        return calculate_traffic_score(dimension_data)
    elif dimension_name == "school":
        return calculate_school_score(dimension_data)
    elif dimension_name == "facility":
        return calculate_facility_score(dimension_data)
    elif dimension_name == "finance":
        return calculate_finance_score(dimension_data)
    else:
        # 风水和户型直接返回已有分数
        return dimension_data.get("score", 5)


def calculate_traffic_score(data):
    """
    计算交通评分
    """
    score = 0
    
    # 地铁距离评分（4分）
    subway_distance = data.get("subway_distance", 9999)
    if subway_distance < 500:
        score += 4
    elif subway_distance < 1000:
        score += 3
    elif subway_distance < 2000:
        score += 2
    elif subway_distance < 3000:
        score += 1
    else:
        score += 0
    
    # 公交覆盖（2分）
    bus_lines = data.get("bus_lines", 0)
    if bus_lines >= 5:
        score += 2
    elif bus_lines >= 3:
        score += 1.5
    elif bus_lines >= 1:
        score += 1
    else:
        score += 0
    
    # 自驾便利（2分）
    road_access = data.get("road_access", "一般")
    road_scores = {"优秀": 2, "良好": 1.5, "一般": 1, "较差": 0.5}
    score += road_scores.get(road_access, 1)
    
    # 停车条件（2分）
    parking_ratio = data.get("parking_ratio", 0.8)
    if parking_ratio >= 1.2:
        score += 2
    elif parking_ratio >= 1.0:
        score += 1.5
    elif parking_ratio >= 0.8:
        score += 1
    else:
        score += 0.5
    
    return round(score, 1)


def calculate_school_score(data):
    """
    计算学区评分
    """
    score = 0
    
    # 学校质量（5分）
    school_rank = data.get("school_rank", "普通")
    rank_scores = {
        "省重点": 5,
        "市重点": 4,
        "区重点": 3.5,
        "普通": 2.5,
        "村小": 1
    }
    score += rank_scores.get(school_rank, 2.5)
    
    # 距离评分（3分）
    school_distance = data.get("school_distance", 2000)
    if school_distance < 500:
        score += 3
    elif school_distance < 1000:
        score += 2.5
    elif school_distance < 2000:
        score += 2
    else:
        score += 1
    
    # 教育资源丰富度（2分）
    edu_resources = data.get("edu_resources", [])
    if len(edu_resources) >= 5:
        score += 2
    elif len(edu_resources) >= 3:
        score += 1.5
    elif len(edu_resources) >= 1:
        score += 1
    else:
        score += 0.5
    
    return round(score, 1)


def calculate_facility_score(data):
    """
    计算配套评分
    """
    score = 0
    
    # 商业配套（3分）
    commercial = data.get("commercial", [])
    if len(commercial) >= 3:
        score += 3
    elif len(commercial) >= 2:
        score += 2.5
    elif len(commercial) >= 1:
        score += 2
    else:
        score += 1
    
    # 医疗配套（3分）
    hospital_level = data.get("hospital_level", "社区医院")
    hospital_scores = {
        "三甲": 3,
        "三乙": 2.5,
        "二甲": 2,
        "二乙": 1.5,
        "社区医院": 1
    }
    score += hospital_scores.get(hospital_level, 1)
    
    # 公园绿地（2分）
    park_distance = data.get("park_distance", 3000)
    if park_distance < 500:
        score += 2
    elif park_distance < 1000:
        score += 1.5
    elif park_distance < 2000:
        score += 1
    else:
        score += 0.5
    
    # 生活便利（2分）
    convenience = data.get("convenience", [])
    if len(convenience) >= 5:
        score += 2
    elif len(convenience) >= 3:
        score += 1.5
    elif len(convenience) >= 1:
        score += 1
    else:
        score += 0.5
    
    return round(score, 1)


def calculate_finance_score(data):
    """
    计算财务评分
    """
    score = 0
    
    # 首付压力（3分）
    down_payment_ratio = data.get("down_payment_ratio", 30)
    if down_payment_ratio <= 20:
        score += 3
    elif down_payment_ratio <= 30:
        score += 2.5
    elif down_payment_ratio <= 40:
        score += 2
    elif down_payment_ratio <= 50:
        score += 1.5
    else:
        score += 1
    
    # 月供压力（3分）
    monthly_pressure = data.get("monthly_pressure", 50)
    if monthly_pressure < 30:
        score += 3
    elif monthly_pressure < 40:
        score += 2.5
    elif monthly_pressure < 50:
        score += 2
    elif monthly_pressure < 60:
        score += 1
    else:
        score += 0.5
    
    # 租金回报（2分）
    rental_yield = data.get("rental_yield", 0)
    if rental_yield >= 3:
        score += 2
    elif rental_yield >= 2:
        score += 1.5
    elif rental_yield >= 1.5:
        score += 1
    else:
        score += 0.5
    
    # 增值潜力（2分）
    appreciation = data.get("appreciation", "一般")
    app_scores = {"高": 2, "较高": 1.5, "一般": 1, "较低": 0.5, "低": 0}
    score += app_scores.get(appreciation, 1)
    
    return round(score, 1)


def calculate_comprehensive_score(scores, weights=None):
    """
    计算综合得分
    
    Args:
        scores: 各维度得分字典
        weights: 权重字典，None使用默认权重
    
    Returns:
        综合评分结果
    """
    if weights is None:
        weights = DEFAULT_WEIGHTS
    
    # 计算加权总分
    total_score = 0
    weighted_scores = {}
    
    for dimension, score in scores.items():
        weight = weights.get(dimension, 0.15)
        weighted_score = score * weight
        weighted_scores[dimension] = {
            "raw_score": score,
            "weight": weight,
            "weighted_score": round(weighted_score, 2)
        }
        total_score += weighted_score
    
    # 评级
    if total_score >= 8:
        grade = "A"
        recommendation = "强烈推荐"
    elif total_score >= 7:
        grade = "B+"
        recommendation = "推荐"
    elif total_score >= 6:
        grade = "B"
        recommendation = "可以考虑"
    elif total_score >= 5:
        grade = "C"
        recommendation = "谨慎考虑"
    else:
        grade = "D"
        recommendation = "不推荐"
    
    return {
        "total_score": round(total_score, 2),
        "grade": grade,
        "recommendation": recommendation,
        "dimension_scores": weighted_scores
    }


def compare_properties(properties_data):
    """
    对比多个房源
    
    Args:
        properties_data: 多个房源的数据列表
    
    Returns:
        对比结果
    """
    results = []
    
    for prop in properties_data:
        name = prop.get("name", "未知房源")
        scores = prop.get("scores", {})
        weights = prop.get("weights", None)
        
        result = calculate_comprehensive_score(scores, weights)
        result["name"] = name
        result["price"] = prop.get("price", 0)
        result["area"] = prop.get("area", 0)
        results.append(result)
    
    # 排序
    sorted_results = sorted(results, key=lambda x: x["total_score"], reverse=True)
    
    return {
        "ranking": sorted_results,
        "count": len(results)
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scoring_calculator.py <command> [args...]")
        print("Commands:")
        print("  score <json_scores> [preset_name]")
        print("  compare <json_properties>")
        print("Presets: balanced, school_focused, investment, living")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "score":
        if len(sys.argv) < 3:
            print("Usage: score <json_scores> [preset_name]")
            sys.exit(1)
        
        try:
            scores = json.loads(sys.argv[2])
            preset = sys.argv[3] if len(sys.argv) > 3 else "balanced"
            weights = WEIGHT_PRESETS.get(preset, DEFAULT_WEIGHTS)
            
            result = calculate_comprehensive_score(scores, weights)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"错误: {e}")
            sys.exit(1)
    
    elif command == "compare":
        if len(sys.argv) < 3:
            print("Usage: compare <json_properties>")
            sys.exit(1)
        
        try:
            properties = json.loads(sys.argv[2])
            result = compare_properties(properties)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"错误: {e}")
            sys.exit(1)
    
    else:
        print(f"未知命令: {command}")
        sys.exit(1)
