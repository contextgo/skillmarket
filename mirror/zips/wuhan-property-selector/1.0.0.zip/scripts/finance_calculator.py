#!/usr/bin/env python3
"""
武汉光谷房产财务计算器
支持月供计算、租金收益估算、投资回报率计算
"""

import argparse
import json
from typing import Dict, Optional


def calculate_monthly_payment(
    loan_amount: float,
    annual_rate: float,
    years: int,
    payment_type: str = "equal_interest"
) -> Dict:
    """
    计算月供
    
    Args:
        loan_amount: 贷款金额（万元）
        annual_rate: 年利率（%）
        years: 贷款年限
        payment_type: 还款方式 - "equal_interest"(等额本息) / "equal_principal"(等额本金)
    
    Returns:
        包含月供详情的字典
    """
    # 转换为元
    principal = loan_amount * 10000
    monthly_rate = annual_rate / 100 / 12
    months = years * 12
    
    if payment_type == "equal_interest":
        # 等额本息
        if monthly_rate == 0:
            monthly_payment = principal / months
        else:
            monthly_payment = principal * (monthly_rate * (1 + monthly_rate) ** months) / \
                            ((1 + monthly_rate) ** months - 1)
        
        total_payment = monthly_payment * months
        total_interest = total_payment - principal
        
        # 首月和末月相同
        first_month = last_month = monthly_payment
        
    else:
        # 等额本金
        monthly_principal = principal / months
        first_month = monthly_principal + principal * monthly_rate
        
        # 每月递减额
        monthly_decrease = monthly_principal * monthly_rate
        
        # 末月还款
        last_month_principal = monthly_principal
        last_month_interest = monthly_principal * monthly_rate
        last_month = last_month_principal + last_month_interest
        
        # 总利息 = (首月利息 + 末月利息) * 月数 / 2
        first_month_interest = principal * monthly_rate
        total_interest = (first_month_interest + last_month_interest) * months / 2
        total_payment = principal + total_interest
        monthly_payment = total_payment / months  # 平均月供
    
    return {
        "monthly_payment": round(monthly_payment, 2),
        "first_month": round(first_month, 2),
        "last_month": round(last_month, 2),
        "total_payment": round(total_payment, 2),
        "total_interest": round(total_interest, 2),
        "principal": principal,
        "payment_type": "等额本息" if payment_type == "equal_interest" else "等额本金"
    }


def calculate_purchase_cost(
    total_price: float,
    down_payment_ratio: float,
    is_first_home: bool = True,
    is_new_home: bool = False,
    area: float = 100
) -> Dict:
    """
    计算购房总成本
    
    Args:
        total_price: 房屋总价（万元）
        down_payment_ratio: 首付比例（%）
        is_first_home: 是否首套房
        is_new_home: 是否新房
        area: 建筑面积（㎡）
    
    Returns:
        购房成本明细
    """
    # 首付
    down_payment = total_price * down_payment_ratio / 100
    
    # 贷款金额
    loan_amount = total_price - down_payment
    
    # 契税
    if is_first_home:
        if area <= 90:
            deed_tax_rate = 0.01
        else:
            deed_tax_rate = 0.015
    else:
        deed_tax_rate = 0.02
    
    deed_tax = total_price * deed_tax_rate
    
    # 中介费（二手房）
    agency_fee = total_price * 0.02 if not is_new_home else 0
    
    # 其他费用（评估费、登记费等）
    other_fees = 0.5 if not is_new_home else 0.3
    
    # 维修基金（新房）
    maintenance_fund = area * 0.0075 if is_new_home else 0  # 约75元/㎡
    
    total_upfront = down_payment + deed_tax + agency_fee + other_fees + maintenance_fund
    
    return {
        "down_payment": round(down_payment, 2),
        "loan_amount": round(loan_amount, 2),
        "deed_tax": round(deed_tax, 2),
        "deed_tax_rate": f"{deed_tax_rate * 100}%",
        "agency_fee": round(agency_fee, 2),
        "other_fees": round(other_fees, 2),
        "maintenance_fund": round(maintenance_fund, 2),
        "total_upfront": round(total_upfront, 2)
    }


def calculate_rental_yield(
    total_price: float,
    monthly_rent: float,
    vacancy_months: float = 1,
    annual_expenses: float = 0.5
) -> Dict:
    """
    计算租金收益率
    
    Args:
        total_price: 房屋总价（万元）
        monthly_rent: 月租金（元）
        vacancy_months: 年空置月数
        annual_expenses: 年维护费用（万元）
    
    Returns:
        租金收益分析
    """
    # 年租金收入
    annual_rent = monthly_rent * (12 - vacancy_months)
    
    # 净收益
    net_annual_income = annual_rent - annual_expenses * 10000
    
    # 毛租金收益率
    gross_yield = (annual_rent / (total_price * 10000)) * 100
    
    # 净租金收益率
    net_yield = (net_annual_income / (total_price * 10000)) * 100
    
    # 回本年限
    payback_years = total_price * 10000 / net_annual_income if net_annual_income > 0 else float('inf')
    
    return {
        "monthly_rent": monthly_rent,
        "annual_rent": round(annual_rent, 2),
        "net_annual_income": round(net_annual_income, 2),
        "gross_yield": round(gross_yield, 2),
        "net_yield": round(net_yield, 2),
        "payback_years": round(payback_years, 1) if payback_years != float('inf') else "无法回本"
    }


def calculate_affordability(
    monthly_income: float,
    monthly_payment: float,
    other_debts: float = 0
) -> Dict:
    """
    计算购房负担能力
    
    Args:
        monthly_income: 家庭月收入（元）
        monthly_payment: 月供（元）
        other_debts: 其他月债务（元）
    
    Returns:
        负担能力评估
    """
    total_debt = monthly_payment + other_debts
    debt_to_income = (total_debt / monthly_income) * 100
    
    if debt_to_income < 30:
        risk_level = "安全"
        advice = "财务状况良好，可以承担"
    elif debt_to_income < 40:
        risk_level = "适中"
        advice = "在可控范围内，但需留意其他支出"
    elif debt_to_income < 50:
        risk_level = "偏高"
        advice = "建议降低贷款额度或增加首付"
    else:
        risk_level = "危险"
        advice = "不建议购买，财务压力过大"
    
    return {
        "debt_to_income_ratio": round(debt_to_income, 1),
        "risk_level": risk_level,
        "advice": advice,
        "remaining_income": round(monthly_income - total_debt, 2)
    }


def generate_report(
    total_price: float,
    down_payment_ratio: float,
    loan_years: int,
    annual_rate: float,
    monthly_income: float,
    area: float = 100,
    is_first_home: bool = True,
    is_new_home: bool = False,
    monthly_rent: Optional[float] = None,
    payment_type: str = "equal_interest"
) -> str:
    """
    生成完整财务报告
    """
    # 购房成本
    purchase_cost = calculate_purchase_cost(
        total_price, down_payment_ratio, is_first_home, is_new_home, area
    )
    
    # 月供计算
    loan_info = calculate_monthly_payment(
        purchase_cost["loan_amount"],
        annual_rate,
        loan_years,
        payment_type
    )
    
    # 负担能力
    affordability = calculate_affordability(monthly_income, loan_info["monthly_payment"])
    
    # 租金收益（如提供）
    rental_info = None
    if monthly_rent:
        rental_info = calculate_rental_yield(total_price, monthly_rent)
    
    report = f"""
╔══════════════════════════════════════════════════════════════╗
║              武汉光谷房产财务分析报告                        ║
╚══════════════════════════════════════════════════════════════╝

【房屋信息】
  房屋总价: {total_price} 万元
  建筑面积: {area} ㎡
  单价: {total_price * 10000 / area:.0f} 元/㎡
  房屋类型: {'新房' if is_new_home else '二手房'}
  购房套数: {'首套' if is_first_home else '二套'}

【首付及税费】
  首付金额 ({down_payment_ratio}%): {purchase_cost['down_payment']:.2f} 万元
  贷款金额: {purchase_cost['loan_amount']:.2f} 万元
  契税 ({purchase_cost['deed_tax_rate']}): {purchase_cost['deed_tax']:.2f} 万元
  {'维修基金: %.2f 万元' % purchase_cost['maintenance_fund'] if is_new_home else '中介费 (2%%): %.2f 万元' % purchase_cost['agency_fee']}
  其他费用: {purchase_cost['other_fees']:.2f} 万元
  ─────────────────────────────
   upfront 总成本: {purchase_cost['total_upfront']:.2f} 万元

【贷款方案】
  贷款金额: {purchase_cost['loan_amount']:.2f} 万元
  贷款年限: {loan_years} 年
  年利率: {annual_rate}%
  还款方式: {loan_info['payment_type']}
  
  月供: {loan_info['monthly_payment']:.2f} 元/月
  {'首月还款: %.2f 元' % loan_info['first_month'] if payment_type == 'equal_principal' else ''}
  还款总额: {loan_info['total_payment']:.2f} 元
  利息总额: {loan_info['total_interest']:.2f} 元
  利息占比: {(loan_info['total_interest'] / loan_info['total_payment'] * 100):.1f}%

【负担能力评估】
  家庭月收入: {monthly_income:.2f} 元
  月供金额: {loan_info['monthly_payment']:.2f} 元
  月供收入比: {affordability['debt_to_income_ratio']:.1f}%
  风险等级: {affordability['risk_level']}
  建议: {affordability['advice']}
  剩余可支配收入: {affordability['remaining_income']:.2f} 元/月
"""
    
    if rental_info:
        report += f"""
【租金收益分析】
  预期月租金: {rental_info['monthly_rent']:.0f} 元
  年租金收入: {rental_info['annual_rent']:.2f} 元
  净年收益: {rental_info['net_annual_income']:.2f} 元
  毛租金收益率: {rental_info['gross_yield']:.2f}%
  净租金收益率: {rental_info['net_yield']:.2f}%
  静态回本年限: {rental_info['payback_years']} 年
  
  租金覆盖月供比例: {(rental_info['monthly_rent'] / loan_info['monthly_payment'] * 100):.1f}%
"""
    
    report += """
═══════════════════════════════════════════════════════════════
注：以上计算仅供参考，实际金额以银行审批和交易为准。
═══════════════════════════════════════════════════════════════
"""
    
    return report


def main():
    parser = argparse.ArgumentParser(description='武汉光谷房产财务计算器')
    parser.add_argument('--price', type=float, required=True, help='房屋总价（万元）')
    parser.add_argument('--down', type=float, default=30, help='首付比例（%），默认30%')
    parser.add_argument('--years', type=int, default=30, help='贷款年限，默认30年')
    parser.add_argument('--rate', type=float, default=3.85, help='年利率（%），默认3.85%')
    parser.add_argument('--income', type=float, required=True, help='家庭月收入（元）')
    parser.add_argument('--area', type=float, default=100, help='建筑面积（㎡），默认100')
    parser.add_argument('--first-home', action='store_true', help='是否首套房')
    parser.add_argument('--new-home', action='store_true', help='是否新房')
    parser.add_argument('--rent', type=float, help='预期月租金（元）')
    parser.add_argument('--payment-type', choices=['equal_interest', 'equal_principal'], 
                        default='equal_interest', help='还款方式')
    parser.add_argument('--json', action='store_true', help='以JSON格式输出')
    
    args = parser.parse_args()
    
    report = generate_report(
        total_price=args.price,
        down_payment_ratio=args.down,
        loan_years=args.years,
        annual_rate=args.rate,
        monthly_income=args.income,
        area=args.area,
        is_first_home=args.first_home,
        is_new_home=args.new_home,
        monthly_rent=args.rent,
        payment_type=args.payment_type
    )
    
    if args.json:
        # 生成JSON格式的详细数据
        purchase_cost = calculate_purchase_cost(
            args.price, args.down, args.first_home, args.new_home, args.area
        )
        loan_info = calculate_monthly_payment(
            purchase_cost["loan_amount"], args.rate, args.years, args.payment_type
        )
        affordability = calculate_affordability(args.income, loan_info["monthly_payment"])
        
        result = {
            "purchase_cost": purchase_cost,
            "loan_info": loan_info,
            "affordability": affordability
        }
        
        if args.rent:
            result["rental_yield"] = calculate_rental_yield(args.price, args.rent)
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(report)


if __name__ == "__main__":
    main()
