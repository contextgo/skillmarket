#!/usr/bin/env python3
"""
风水分析器
基于传统风水学理论分析房屋风水
"""

import sys
import json
import math


def analyze_orientation(direction, sub_direction=""):
    """
    分析朝向风水
    
    Args:
        direction: 主朝向（南、北、东、西、东南、西南、东北、西北）
        sub_direction: 偏向（偏东、偏西）
    
    Returns:
        朝向评分和分析
    """
    # 朝向评分表
    orientation_scores = {
        "南": 10,
        "东南": 9,
        "西南": 8,
        "东": 7,
        "西": 5,
        "东北": 4,
        "西北": 3,
        "北": 2
    }
    
    score = orientation_scores.get(direction, 5)
    
    # 调整评分
    if direction == "南":
        if sub_direction == "偏东":
            score = 10  # 最佳
            comment = "坐北朝南偏东，紫气东来，大吉"
        elif sub_direction == "偏西":
            score = 9
            comment = "坐北朝南偏西，采光充足"
        else:
            comment = "坐北朝南，正房正位，采光通风俱佳"
    elif direction == "北":
        comment = "坐南朝北，采光较差，冬季阴冷"
    elif direction == "东":
        comment = "坐西朝东，紫气东来，但下午无阳光"
    elif direction == "西":
        comment = "坐东朝西，西晒严重，夏季炎热"
    elif direction == "东南":
        comment = "坐西北朝东南，东南风入户，财运亨通"
    elif direction == "西南":
        comment = "坐东北朝西南，下午阳光充足"
    elif direction == "东北":
        comment = "坐西南朝东北，采光一般"
    elif direction == "西北":
        comment = "坐东南朝西北，冬季寒风直入"
    else:
        comment = "朝向一般"
    
    return {
        "score": score,
        "direction": direction,
        "comment": comment
    }


def analyze_layout(bedroom_south, living_south, layout_regular, north_south_through):
    """
    分析户型风水
    
    Args:
        bedroom_south: 主卧是否朝南
        living_south: 客厅是否朝南
        layout_regular: 户型是否方正
        north_south_through: 是否南北通透
    
    Returns:
        户型风水评分
    """
    score = 5  # 基础分
    comments = []
    
    if bedroom_south:
        score += 2
        comments.append("主卧朝南，利于健康和休息")
    else:
        comments.append("主卧不朝南，建议调整床位")
    
    if living_south:
        score += 1.5
        comments.append("客厅朝南，采光充足，家运兴旺")
    else:
        comments.append("客厅采光不足")
    
    if layout_regular:
        score += 1
        comments.append("户型方正，气场稳定")
    else:
        comments.append("户型不方正，有缺角，需注意化解")
    
    if north_south_through:
        score += 0.5
        comments.append("南北通透，空气流通")
    
    return {
        "score": round(score, 1),
        "comments": comments
    }


def analyze_surroundings(near_railway, near_hospital, near_temple, near_high_voltage, 
                         has_water, has_mountain, road_shape):
    """
    分析外部环境风水
    
    Args:
        near_railway: 是否近铁路
        near_hospital: 是否近医院
        near_temple: 是否近寺庙
        near_high_voltage: 是否近高压线
        has_water: 是否有水景（河、湖）
        has_mountain: 是否有山/高地
        road_shape: 道路形状（正常、反弓、剪刀、直冲）
    
    Returns:
        外部环境评分
    """
    score = 5  # 基础分
    comments = []
    warnings = []
    
    # 不利因素检查
    if near_railway:
        score -= 1.5
        warnings.append("⚠️ 近铁路：噪音大，气场不稳，影响休息")
    
    if near_hospital:
        score -= 1
        warnings.append("⚠️ 近医院：阴气重，易有晦气")
    
    if near_temple:
        score -= 0.5
        warnings.append("近寺庙：宗教场所，气场特殊")
    
    if near_high_voltage:
        score -= 1
        warnings.append("⚠️ 近高压线：电磁辐射，不利健康")
    
    # 有利因素
    if has_water:
        score += 1
        comments.append("✓ 有水景：水为财，利财运")
    
    if has_mountain:
        score += 0.5
        comments.append("✓ 有靠山：背后有靠，事业稳固")
    
    # 道路形状
    if road_shape == "正常":
        score += 0.5
        comments.append("✓ 道路平顺")
    elif road_shape == "反弓":
        score -= 1.5
        warnings.append("⚠️ 反弓路：像弓箭直射，易有意外")
    elif road_shape == "剪刀":
        score -= 1
        warnings.append("⚠️ 剪刀路：两路交叉如剪刀，易有口舌是非")
    elif road_shape == "直冲":
        score -= 1
        warnings.append("⚠️ 路冲：道路直冲大门，气场不稳")
    
    return {
        "score": max(0, round(score, 1)),
        "comments": comments,
        "warnings": warnings
    }


def calculate_bazi_compatibility(birth_years, house_direction):
    """
    简单计算八字与房屋朝向的匹配度
    
    Args:
        birth_years: 家庭成员出生年份列表
        house_direction: 房屋朝向
    
    Returns:
        匹配度分析
    """
    # 生肖与方位对应
    zodiac_directions = {
        "鼠": "北", "牛": "东北", "虎": "东北", "兔": "东",
        "龙": "东南", "蛇": "东南", "马": "南", "羊": "西南",
        "猴": "西南", "鸡": "西", "狗": "西北", "猪": "西北"
    }
    
    zodiac_list = ["猴", "鸡", "狗", "猪", "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊"]
    
    results = []
    favorable_count = 0
    
    for year in birth_years:
        zodiac = zodiac_list[year % 12]
        favorable_dir = zodiac_directions[zodiac]
        
        # 判断是否匹配
        is_favorable = (favorable_dir in house_direction) or (house_direction in favorable_dir)
        if is_favorable:
            favorable_count += 1
        
        results.append({
            "year": year,
            "zodiac": zodiac,
            "favorable_direction": favorable_dir,
            "match": is_favorable
        })
    
    match_rate = favorable_count / len(birth_years) if birth_years else 0
    
    return {
        "members": results,
        "match_rate": round(match_rate * 100, 1),
        "overall": "吉" if match_rate >= 0.5 else "一般"
    }


def comprehensive_fengshui_analysis(data):
    """
    综合风水分析
    
    Args:
        data: 包含所有风水相关信息的字典
    
    Returns:
        完整风水分析报告
    """
    # 朝向分析
    orientation = analyze_orientation(
        data.get("direction", "南"),
        data.get("sub_direction", "")
    )
    
    # 户型分析
    layout = analyze_layout(
        data.get("bedroom_south", True),
        data.get("living_south", True),
        data.get("layout_regular", True),
        data.get("north_south_through", True)
    )
    
    # 外部环境分析
    surroundings = analyze_surroundings(
        data.get("near_railway", False),
        data.get("near_hospital", False),
        data.get("near_temple", False),
        data.get("near_high_voltage", False),
        data.get("has_water", False),
        data.get("has_mountain", False),
        data.get("road_shape", "正常")
    )
    
    # 八字匹配（如有提供）
    bazi_match = None
    if "birth_years" in data:
        bazi_match = calculate_bazi_compatibility(
            data["birth_years"],
            data.get("direction", "南")
        )
    
    # 计算总分
    total_score = (
        orientation["score"] * 0.25 +
        layout["score"] * 0.35 +
        surroundings["score"] * 0.40
    )
    
    # 评级
    if total_score >= 8:
        grade = "上吉"
        grade_comment = "风水极佳，宜购置"
    elif total_score >= 6:
        grade = "中吉"
        grade_comment = "风水良好，可考虑"
    elif total_score >= 4:
        grade = "平平"
        grade_comment = "风水一般，需谨慎"
    else:
        grade = "不吉"
        grade_comment = "风水较差，不建议"
    
    return {
        "total_score": round(total_score, 1),
        "grade": grade,
        "grade_comment": grade_comment,
        "orientation": orientation,
        "layout": layout,
        "surroundings": surroundings,
        "bazi_match": bazi_match
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python fengshui_analyzer.py <json_data>")
        print("Example: python fengshui_analyzer.py '{\"direction\":\"南\",\"bedroom_south\":true}'")
        sys.exit(1)
    
    try:
        data = json.loads(sys.argv[1])
        result = comprehensive_fengshui_analysis(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except json.JSONDecodeError as e:
        print(f"JSON解析错误: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"分析错误: {e}")
        sys.exit(1)
