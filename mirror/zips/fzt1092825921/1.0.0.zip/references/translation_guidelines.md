# Translation Guidelines for PPTX Translator

## Translation Style Detection

### Business/Corporate Style
- **Trigger**: PPT contains revenue data, market analysis, strategy slides, org charts, KPI dashboards
- **Tone**: Formal, concise, action-oriented
- **Examples**:
  - "年度营收报告" → "Annual Revenue Report"
  - "市场份额" → "Market Share"
  - "战略规划" → "Strategic Planning"

### Academic/Research Style
- **Trigger**: PPT contains research methodology, literature review, hypotheses, data analysis, citations
- **Tone**: Precise, objective, scholarly
- **Examples**:
  - "研究方法" → "Research Methodology"
  - "文献综述" → "Literature Review"
  - "实证分析" → "Empirical Analysis"

### Technical/Engineering Style
- **Trigger**: PPT contains architecture diagrams, system specs, code, engineering processes
- **Tone**: Direct, technical, specification-oriented
- **Examples**:
  - "系统架构" → "System Architecture"
  - "性能优化" → "Performance Optimization"
  - "接口规范" → "API Specification"

## Glossary Building Rules

### Proper Nouns
- Company names: Keep original English name if one exists (e.g., "华为" → "Huawei", "腾讯" → "Tencent")
- Product names: Use official English product name (e.g., "微信" → "WeChat")
- Person names: Use pinyin with proper capitalization (e.g., "张伟" → "Zhang Wei")
- Place names: Use standard English names (e.g., "北京" → "Beijing", "上海" → "Shanghai")

### Technical Terms
- Use industry-standard English translations
- Be consistent across all slides — once a term is translated a certain way, use it throughout
- If a term has a widely accepted English equivalent, use it (e.g., "人工智能" → "Artificial Intelligence" or "AI")
- For terms with multiple translations, choose the most common one and stick with it

### Numbers and Units
- Preserve all numbers exactly as they appear
- Convert Chinese units to international standards where appropriate:
  - "万" → add correct magnitude (e.g., "100万" → "1 million" or "1,000,000")
  - "亿" → add correct magnitude (e.g., "10亿" → "1 billion")
- Percentage format: Keep as percentage (e.g., "增长率15%" → "Growth Rate: 15%")

### Abbreviations
- Where Chinese uses abbreviations, use the standard English abbreviation:
  - "国内生产总值" → "GDP" (not "Gross Domestic Product" in slide context)
  - "投资回报率" → "ROI"
  - "关键绩效指标" → "KPI"
- If no standard English abbreviation exists, spell out on first use, then abbreviate

## Multi-Run Text Handling

### Problem
Chinese text in PPTX is often split across multiple runs within a paragraph, even when it appears as a single phrase. This happens because:
- Different formatting was applied to parts of the text
- The PPTX editor split the text internally
- Copy-paste operations created fragmented runs

### Solution
1. **Merge adjacent runs** that form a single Chinese phrase before translating
2. **Translate the merged text** as a complete unit
3. **Place the full translation** in the first run
4. **Clear remaining runs** (set text to empty string)
5. **Preserve formatting**: Each run retains its original formatting properties

### Example
Original runs: ["公司"] ["年度"] ["报告"]
Merged text: "公司年度报告"
Translation: "Annual Company Report"
Result: Run 0 = "Annual Company Report", Run 1 = "", Run 2 = ""

## Image Text Translation

### Coordinate System
- All coordinates are expressed as **percentages** of the image dimensions
- `x_pct`: Distance from left edge (0% = leftmost, 100% = rightmost)
- `y_pct`: Distance from top edge (0% = top, 100% = bottom)
- `width_pct`: Width of the text area as percentage of image width
- `height_pct`: Height of the text area as percentage of image height

### Font Size Guidelines
- If the original Chinese font size can be estimated, use a similar or slightly smaller size for English
- English text typically needs 10-20% smaller font than equivalent Chinese to fit in the same space
- Minimum readable font size: 10px
- If no font size can be determined, calculate based on overlay area height: `font_size = height_pct * image_height / 100 * 0.7`

### Overlay Visual Quality
- White rectangle background should extend 2-3 pixels beyond the text area (padding)
- Match the background color of the surrounding area if it's not white (use bg_color field)
- For dark backgrounds, use light text color and match the background
- Ensure the overlay rectangle fully covers the original Chinese text with no residual characters visible

## Common Translation Patterns

| Chinese | English | Notes |
|---------|---------|-------|
| 概述 / 简介 | Overview | Not "Introduction" unless it's truly an intro |
| 总结 / 小结 | Summary | Not "Conclusion" unless it draws conclusions |
| 目录 | Table of Contents | Or "Agenda" for meeting presentations |
| 背景介绍 | Background | Keep concise |
| 核心优势 | Key Advantages | Not "Core Superiority" |
| 未来展望 | Future Outlook | Or "Looking Ahead" |
| Q&A / 问答 | Q&A | Keep as Q&A |
| 谢谢 | Thank You | Capitalize both words |
| 第X页 | Page X | Or remove page numbers if not in original |
| 附录 | Appendix | Standard formal term |

## Quality Checklist

Before finalizing translations, verify:
- [ ] All slides are translated (no missed slides)
- [ ] Terminology is consistent across all slides
- [ ] Numbers and dates are preserved exactly
- [ ] Proper nouns use correct English forms
- [ ] Text fits within original layout bounds (no overflow)
- [ ] Image text overlays are properly positioned
- [ ] Table cells are fully translated
- [ ] Chart labels and legends are translated
- [ ] Header/footer text is translated
- [ ] Speaker notes are translated (if present)
