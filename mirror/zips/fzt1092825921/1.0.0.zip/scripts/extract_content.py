#!/usr/bin/env python3
"""
PPTX Content Extractor - Extract all text and images from a PPTX file.

Usage:
    python extract_content.py <input.pptx> [--output-dir <dir>]

Output:
    - content.json: Structured JSON with all text content and metadata
    - images/: Directory containing all extracted images

JSON Structure:
    {
        "file": "input.pptx",
        "slides": [
            {
                "slide_index": 0,
                "shapes": [
                    {
                        "shape_index": 0,
                        "shape_type": "text_box",
                        "name": "Title 1",
                        "left": 100, "top": 50, "width": 800, "height": 60,
                        "paragraphs": [
                            {
                                "paragraph_index": 0,
                                "alignment": "CENTER",
                                "runs": [
                                    {
                                        "run_index": 0,
                                        "text": "Hello World",
                                        "font_name": "Microsoft YaHei",
                                        "font_size": 28.0,
                                        "bold": false,
                                        "italic": false,
                                        "color": "#000000"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ],
        "images": [
            {
                "image_index": 0,
                "slide_index": 0,
                "shape_index": 2,
                "filename": "slide_0_shape_2.png",
                "width": 800,
                "height": 600,
                "content_type": "image/png"
            }
        ]
    }
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt, Emu
    from pptx.enum.text import PP_ALIGN
except ImportError:
    print("ERROR: python-pptx is required. Install with: pip install python-pptx")
    sys.exit(1)


def emu_to_pt(emu_val):
    """Convert EMU (English Metric Units) to points. Returns None if invalid."""
    if emu_val is None:
        return None
    try:
        return round(emu_val / 12700, 1)  # 1 pt = 12700 EMU
    except (TypeError, ValueError):
        return None


def emu_to_px(emu_val, dpi=96):
    """Convert EMU to pixels. Returns None if invalid."""
    if emu_val is None:
        return None
    try:
        return round(emu_val / 914400 * dpi, 0)  # 1 inch = 914400 EMU
    except (TypeError, ValueError):
        return None


def get_alignment_name(alignment):
    """Convert PP_ALIGN enum to string name."""
    if alignment is None:
        return "LEFT"  # default
    mapping = {
        PP_ALIGN.LEFT: "LEFT",
        PP_ALIGN.CENTER: "CENTER",
        PP_ALIGN.RIGHT: "RIGHT",
        PP_ALIGN.JUSTIFY: "JUSTIFY",
    }
    return mapping.get(alignment, str(alignment))


def get_color_hex(font):
    """Extract color from a font object as hex string. Returns None if no color."""
    try:
        color_rgb = font.color.rgb
        if color_rgb:
            return f"#{color_rgb}"
    except Exception:
        pass
    return None


def extract_run_info(run):
    """Extract text and formatting info from a single run."""
    run_info = {
        "run_index": -1,  # will be set by caller
        "text": run.text or "",
    }

    font = run.font
    if font:
        run_info["font_name"] = font.name
        run_info["font_size"] = emu_to_pt(font.size) if font.size else None
        run_info["bold"] = font.bold
        run_info["italic"] = font.italic
        run_info["underline"] = font.underline
        run_info["color"] = get_color_hex(font)

    return run_info


def extract_paragraph_info(para, para_index):
    """Extract paragraph-level info and all runs within it."""
    para_info = {
        "paragraph_index": para_index,
        "alignment": get_alignment_name(para.alignment),
        "runs": [],
    }

    # Collect all runs
    all_text = ""
    for run_idx, run in enumerate(para.runs):
        run_info = extract_run_info(run)
        run_info["run_index"] = run_idx
        para_info["runs"].append(run_info)
        all_text += run.text or ""

    # Store combined paragraph text for convenience
    para_info["full_text"] = all_text

    return para_info


def extract_text_content(shape):
    """Extract all text content from a shape that has a text_frame."""
    if not shape.has_text_frame:
        return None

    paragraphs = []
    for para_idx, para in enumerate(shape.text_frame.paragraphs):
        para_info = extract_paragraph_info(para, para_idx)
        paragraphs.append(para_info)

    return paragraphs


def extract_table_content(shape):
    """Extract text content from a table shape."""
    if not shape.has_table:
        return None

    table = shape.table
    rows_info = []

    for row_idx, row in enumerate(table.rows):
        cells_info = []
        for col_idx, cell in enumerate(row.cells):
            cell_paragraphs = []
            for para_idx, para in enumerate(cell.text_frame.paragraphs):
                para_info = extract_paragraph_info(para, para_idx)
                cell_paragraphs.append(para_info)

            cells_info.append({
                "row": row_idx,
                "col": col_idx,
                "paragraphs": cell_paragraphs,
                "full_text": cell.text,
            })
        rows_info.append(cells_info)

    return rows_info


def extract_image(shape, slide_index, shape_index, output_dir):
    """Extract image from a shape and save to output directory. Returns image info dict."""
    image = shape.image
    content_type = image.content_type
    ext = content_type.split("/")[-1] if "/" in content_type else "png"

    # Normalize extension
    ext_map = {"jpeg": "jpg", "x-emf": "emf", "x-wmf": "wmf"}
    ext = ext_map.get(ext, ext)

    filename = f"slide_{slide_index}_shape_{shape_index}.{ext}"
    filepath = os.path.join(output_dir, filename)

    # Save image
    with open(filepath, "wb") as f:
        f.write(image.blob)

    # Get image dimensions if possible
    width_px = None
    height_px = None
    try:
        from PIL import Image
        with Image.open(filepath) as img:
            width_px, height_px = img.size
    except Exception:
        # For unsupported formats (emf, wmf), use shape dimensions
        width_px = emu_to_px(shape.width)
        height_px = emu_to_px(shape.height)

    return {
        "image_index": -1,  # will be set later
        "slide_index": slide_index,
        "shape_index": shape_index,
        "filename": filename,
        "width": width_px,
        "height": height_px,
        "content_type": content_type,
        "shape_left": shape.left,
        "shape_top": shape.top,
        "shape_width": shape.width,
        "shape_height": shape.height,
    }


def extract_pptx(input_path, output_dir=None):
    """Main extraction function. Returns the structured content dict."""
    input_path = Path(input_path).resolve()
    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}")
        sys.exit(1)

    # Set up output directory
    if output_dir is None:
        output_dir = input_path.parent / f".pptx_extract_{input_path.stem}"
    else:
        output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    images_dir = output_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    # Load presentation
    prs = Presentation(str(input_path))

    content = {
        "file": str(input_path),
        "slide_width": prs.slide_width,
        "slide_height": prs.slide_height,
        "slide_width_in": round(prs.slide_width / 914400, 2),
        "slide_height_in": round(prs.slide_height / 914400, 2),
        "slides": [],
        "images": [],
    }

    image_counter = 0

    for slide_idx, slide in enumerate(prs.slides):
        slide_info = {
            "slide_index": slide_idx,
            "shapes": [],
        }

        for shape_idx, shape in enumerate(slide.shapes):
            shape_info = {
                "shape_index": shape_idx,
                "shape_type": str(shape.shape_type),
                "name": shape.name,
                "left": shape.left,
                "top": shape.top,
                "width": shape.width,
                "height": shape.height,
            }

            # Extract text content
            if shape.has_text_frame:
                shape_info["content_type"] = "text"
                shape_info["paragraphs"] = extract_text_content(shape)

            # Extract table content
            elif shape.has_table:
                shape_info["content_type"] = "table"
                shape_info["table"] = extract_table_content(shape)

            # Extract image
            elif hasattr(shape, "image") and shape.image is not None:
                try:
                    img_info = extract_image(shape, slide_idx, shape_idx, str(images_dir))
                    img_info["image_index"] = image_counter
                    image_counter += 1
                    shape_info["content_type"] = "image"
                    shape_info["image_ref"] = img_info["image_index"]
                    content["images"].append(img_info)
                except Exception as e:
                    shape_info["content_type"] = "image_error"
                    shape_info["error"] = str(e)

            # Group shape - recurse into children
            elif shape.shape_type == "GROUP":
                shape_info["content_type"] = "group"
                # Group shapes are handled at the top level by python-pptx

            else:
                shape_info["content_type"] = "other"

            slide_info["shapes"].append(shape_info)

        content["slides"].append(slide_info)

    # Save content JSON
    json_path = output_dir / "content.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(content, f, ensure_ascii=False, indent=2)

    print(f"Extraction complete!")
    print(f"  Content JSON: {json_path}")
    print(f"  Images directory: {images_dir}")
    print(f"  Total slides: {len(content['slides'])}")
    print(f"  Total images: {len(content['images'])}")
    print(f"  Total shapes with text: {sum(1 for s in content['slides'] for sh in s['shapes'] if sh.get('content_type') == 'text')}")

    return content


def main():
    parser = argparse.ArgumentParser(description="Extract text and images from a PPTX file")
    parser.add_argument("input", help="Path to the input PPTX file")
    parser.add_argument("--output-dir", help="Output directory for extracted content (default: .pptx_extract_<name>/)")
    args = parser.parse_args()

    extract_pptx(args.input, args.output_dir)


if __name__ == "__main__":
    main()
