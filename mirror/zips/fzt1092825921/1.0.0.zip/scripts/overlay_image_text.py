#!/usr/bin/env python3
"""
PPTX Image Text Overlay - Overlay Chinese text in images with English translations.

Usage:
    python overlay_image_text.py <input.pptx> <overlays.json> [--output <output.pptx>]

Overlays JSON format:
    {
        "overlays": [
            {
                "slide_index": 0,
                "shape_index": 2,
                "image_filename": "slide_0_shape_2.png",
                "text_overlays": [
                    {
                        "x_pct": 10.0,       # X position as percentage of image width (0-100)
                        "y_pct": 20.0,       # Y position as percentage of image height (0-100)
                        "width_pct": 30.0,   # Width of overlay area as percentage
                        "height_pct": 8.0,   # Height of overlay area as percentage
                        "original_text": "销售额",
                        "translated_text": "Revenue",
                        "font_size": 16,     # Font size in pixels (optional, auto-calculated if omitted)
                        "bg_color": "#FFFFFF",  # Background color (default: white)
                        "text_color": "#000000"  # Text color (default: black)
                    }
                ]
            }
        ]
    }

How it works:
    1. For each image with overlays, extract the image from the PPTX
    2. Use Pillow to draw white rectangles over the Chinese text areas
    3. Draw the English translation text on top of the white rectangles
    4. Replace the image in the PPTX with the modified version
"""

import argparse
import json
import os
import sys
import tempfile
from io import BytesIO
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Emu
except ImportError:
    print("ERROR: python-pptx is required. Install with: pip install python-pptx")
    sys.exit(1)

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("ERROR: Pillow is required. Install with: pip install Pillow")
    sys.exit(1)


# Default padding around overlay rectangles (in pixels)
OVERLAY_PADDING = 3

# Default font for overlay text (will try to find a suitable system font)
DEFAULT_FONT_NAMES = [
    "arial.ttf",
    "Arial.ttf",
    "msyh.ttc",       # Microsoft YaHei
    "simhei.ttf",     # SimHei
    "DejaVuSans.ttf",
    "Helvetica.ttf",
]


def find_font(size=16):
    """Find a suitable system font for drawing text on images."""
    # Try common font paths
    font_paths = []
    if sys.platform == "win32":
        font_dir = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts")
        font_paths = [
            os.path.join(font_dir, "arial.ttf"),
            os.path.join(font_dir, "msyh.ttc"),
            os.path.join(font_dir, "simhei.ttf"),
        ]
    elif sys.platform == "darwin":
        font_paths = [
            "/System/Library/Fonts/Helvetica.ttc",
            "/System/Library/Fonts/PingFang.ttc",
            "/Library/Fonts/Arial.ttf",
        ]
    else:  # Linux
        font_paths = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        ]

    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                return ImageFont.truetype(font_path, size)
            except Exception:
                continue

    # Fallback to default font
    print("WARNING: No suitable font found, using default Pillow font")
    try:
        return ImageFont.truetype("arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


def apply_overlays_to_image(image_path, text_overlays):
    """
    Apply all text overlays to a single image.
    
    Args:
        image_path: Path to the image file
        text_overlays: List of overlay specifications
        
    Returns:
        PIL Image with overlays applied
    """
    img = Image.open(image_path)
    
    # Convert to RGBA if not already (for proper text rendering)
    if img.mode != "RGBA":
        img = img.convert("RGBA")
    
    # Create a transparent overlay for drawing
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    
    img_width, img_height = img.size

    for ol in text_overlays:
        x_pct = ol.get("x_pct", 0)
        y_pct = ol.get("y_pct", 0)
        width_pct = ol.get("width_pct", 20)
        height_pct = ol.get("height_pct", 5)
        translated_text = ol.get("translated_text", "")
        font_size = ol.get("font_size")
        bg_color = ol.get("bg_color", "#FFFFFF")
        text_color = ol.get("text_color", "#000000")
        
        if not translated_text:
            continue

        # Calculate pixel coordinates
        x = int(img_width * x_pct / 100)
        y = int(img_height * y_pct / 100)
        w = int(img_width * width_pct / 100)
        h = int(img_height * height_pct / 100)

        # Auto-calculate font size if not specified
        if not font_size:
            # Base font size on the height of the overlay area
            font_size = max(10, int(h * 0.7))

        # Draw white background rectangle with padding
        bg_x1 = max(0, x - OVERLAY_PADDING)
        bg_y1 = max(0, y - OVERLAY_PADDING)
        bg_x2 = min(img_width, x + w + OVERLAY_PADDING)
        bg_y2 = min(img_height, y + h + OVERLAY_PADDING)

        # Parse background color
        bg_rgb = _parse_color(bg_color, (255, 255, 255))
        text_rgb = _parse_color(text_color, (0, 0, 0))

        # Draw white rectangle
        draw.rectangle(
            [bg_x1, bg_y1, bg_x2, bg_y2],
            fill=bg_rgb + (255,)  # Fully opaque
        )

        # Get font and draw text
        font = find_font(font_size)
        
        # Center text within the overlay area
        text_x = x + OVERLAY_PADDING
        text_y = y + (h - font_size) // 2
        
        draw.text(
            (text_x, text_y),
            translated_text,
            fill=text_rgb + (255,),
            font=font,
        )

    # Composite overlay onto original image
    result = Image.alpha_composite(img, overlay)
    
    # Convert back to RGB if the original was RGB
    if result.mode == "RGBA":
        # Check if there's actual transparency needed
        result = result.convert("RGB")

    return result


def _parse_color(color_str, default):
    """Parse a color string (#RRGGBB or named) to RGB tuple."""
    if not color_str:
        return default
    try:
        if color_str.startswith("#") and len(color_str) == 7:
            r = int(color_str[1:3], 16)
            g = int(color_str[3:5], 16)
            b = int(color_str[5:7], 16)
            return (r, g, b)
    except (ValueError, TypeError):
        pass
    return default


def replace_image_in_pptx(prs, slide_index, shape_index, new_image_path):
    """
    Replace an image in the PPTX with a new image file.
    
    Uses the approach of replacing the image blob directly to preserve
    the shape's position, size, and formatting.
    """
    slide = prs.slides[slide_index]
    shape = slide.shapes[shape_index]
    
    # Read the new image
    with open(new_image_path, "rb") as f:
        new_image_data = f.read()
    
    # Replace the image by modifying the shape's image part
    # This preserves the shape's position, size, and other properties
    if hasattr(shape, "image"):
        image_part = shape.image
        # Get the relationship and replace the blob
        rel = shape._element.find(
            ".//{http://schemas.openxmlformats.org/drawingml/2006/main}blipFill/"
            "{http://schemas.openxmlformats.org/drawingml/2006/main}blip"
        )
        
        # Alternative approach: replace via the part's blob
        try:
            # Access the image part through the shape's relationships
            from pptx.opc.constants import RELATIONSHIP_TYPE as RT
            blip = shape._element.find(
                ".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip"
            )
            if blip is not None:
                rId = blip.get(
                    "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
                )
                if rId:
                    image_part = slide.part.related_parts[rId]
                    image_part._blob = new_image_data
                    return True
        except Exception as e:
            print(f"WARNING: Could not replace image via relationship: {e}")
    
    return False


def overlay_image_text(input_path, overlays_path, output_path=None):
    """
    Main function: Apply image text overlays to a PPTX file.
    
    Args:
        input_path: Path to the PPTX file (typically after text translation)
        overlays_path: Path to the overlays JSON file
        output_path: Path for output PPTX
    """
    input_path = Path(input_path).resolve()
    overlays_path = Path(overlays_path).resolve()

    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}")
        sys.exit(1)

    if not overlays_path.exists():
        print(f"ERROR: Overlays file not found: {overlays_path}")
        sys.exit(1)

    if output_path is None:
        output_path = input_path.parent / f"{input_path.stem}_with_overlays.pptx"
    else:
        output_path = Path(output_path).resolve()

    # Load overlays
    with open(overlays_path, "r", encoding="utf-8") as f:
        overlays_data = json.load(f)

    overlays = overlays_data.get("overlays", [])
    if not overlays:
        print("No overlays to apply.")
        # Just copy the file as-is
        import shutil
        shutil.copy2(str(input_path), str(output_path))
        print(f"Output: {output_path}")
        return str(output_path)

    # Load presentation
    prs = Presentation(str(input_path))

    # Create temp directory for modified images
    with tempfile.TemporaryDirectory() as tmpdir:
        for overlay_item in overlays:
            slide_idx = overlay_item["slide_index"]
            shape_idx = overlay_item["shape_index"]
            image_filename = overlay_item.get("image_filename", "")
            text_overlays = overlay_item.get("text_overlays", [])

            if not text_overlays:
                continue

            # Extract the image from the PPTX
            slide = prs.slides[slide_idx]
            shape = slide.shapes[shape_idx]

            if not hasattr(shape, "image"):
                print(f"WARNING: Shape {shape_idx} on slide {slide_idx} is not an image, skipping")
                continue

            # Save original image to temp file
            original_img_path = os.path.join(tmpdir, f"original_{slide_idx}_{shape_idx}")
            with open(original_img_path, "wb") as f:
                f.write(shape.image.blob)

            # Determine the actual extension
            content_type = shape.image.content_type
            ext = content_type.split("/")[-1] if "/" in content_type else "png"
            ext_map = {"jpeg": "jpg", "x-emf": "emf", "x-wmf": "wmf"}
            ext = ext_map.get(ext, ext)
            
            original_with_ext = original_img_path + f".{ext}"
            os.rename(original_img_path, original_with_ext)

            # Apply overlays
            try:
                modified_img = apply_overlays_to_image(original_with_ext, text_overlays)
                modified_img_path = os.path.join(tmpdir, f"modified_{slide_idx}_{shape_idx}.png")
                modified_img.save(modified_img_path, "PNG")

                # Replace image in PPTX
                success = replace_image_in_pptx(prs, slide_idx, shape_idx, modified_img_path)
                if success:
                    print(f"  Replaced image on slide {slide_idx}, shape {shape_idx}")
                else:
                    print(f"  WARNING: Could not replace image on slide {slide_idx}, shape {shape_idx}")

            except Exception as e:
                print(f"  ERROR processing image on slide {slide_idx}, shape {shape_idx}: {e}")
                continue

    # Save modified presentation
    prs.save(str(output_path))
    print(f"\nImage overlays applied successfully!")
    print(f"  Output: {output_path}")

    return str(output_path)


def main():
    parser = argparse.ArgumentParser(description="Overlay translated text on images in a PPTX file")
    parser.add_argument("input", help="Path to the input PPTX file")
    parser.add_argument("overlays", help="Path to the overlays JSON file")
    parser.add_argument("--output", help="Path for the output PPTX file")
    args = parser.parse_args()

    overlay_image_text(args.input, args.overlays, args.output)


if __name__ == "__main__":
    main()
