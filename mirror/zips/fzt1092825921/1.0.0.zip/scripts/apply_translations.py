#!/usr/bin/env python3
"""
PPTX Translation Applier - Apply text translations back to a PPTX file while preserving formatting.

Usage:
    python apply_translations.py <input.pptx> <translations.json> [--output <output.pptx>]

Translations JSON format:
    {
        "translations": [
            {
                "slide_index": 0,
                "shape_index": 0,
                "paragraph_index": 0,
                "run_translations": [
                    {
                        "run_index": 0,
                        "translated_text": "Hello World"
                    }
                ]
            }
        ],
        "table_translations": [
            {
                "slide_index": 1,
                "shape_index": 3,
                "row": 0,
                "col": 0,
                "paragraph_index": 0,
                "run_translations": [
                    {
                        "run_index": 0,
                        "translated_text": "Revenue"
                    }
                ]
            }
        ]
    }

Key behaviors:
    - Preserves all original formatting (font size, color, bold, italic, etc.)
    - For multi-run Chinese text: merges adjacent runs, puts translation in first run, clears others
    - Auto-expands text box width if English text overflows
    - Handles both text frames and table cells
"""

import argparse
import json
import sys
from pathlib import Path
from copy import deepcopy

try:
    from pptx import Presentation
    from pptx.util import Pt, Emu
except ImportError:
    print("ERROR: python-pptx is required. Install with: pip install python-pptx")
    sys.exit(1)


# English text is typically 20-40% wider than Chinese for the same content
# We use a conservative expansion factor
WIDTH_EXPANSION_FACTOR = 1.3


def apply_run_translations(paragraph, run_translations):
    """
    Apply translations to runs within a paragraph.
    
    Strategy for multi-run Chinese text:
    - Collect all runs and their translations
    - Put the full translated text into the first run
    - Clear text in remaining runs (to avoid duplication)
    - This preserves each run's formatting independently
    
    Args:
        paragraph: python-pptx Paragraph object
        run_translations: list of {run_index, translated_text}
    """
    runs = list(paragraph.runs)
    if not runs:
        return

    # Build a map of run_index -> translated_text
    translation_map = {}
    for rt in run_translations:
        idx = rt["run_index"]
        text = rt.get("translated_text", "")
        translation_map[idx] = text

    # Check if we have consecutive runs that need merging
    # (common when Chinese text is split across multiple runs)
    if len(translation_map) > 1:
        # Collect all translated text
        full_translation = ""
        for idx in sorted(translation_map.keys()):
            full_translation += translation_map[idx]
        
        # Put full translation in first run, clear the rest
        first_run_idx = min(translation_map.keys())
        for i, run in enumerate(runs):
            if i == first_run_idx:
                run.text = full_translation
            elif i in translation_map:
                run.text = ""
    else:
        # Single run translation - straightforward
        for idx, text in translation_map.items():
            if idx < len(runs):
                runs[idx].text = text


def apply_text_translations(prs, translations):
    """Apply translations to all text frame shapes."""
    for item in translations.get("translations", []):
        slide_idx = item["slide_index"]
        shape_idx = item["shape_index"]
        para_idx = item["paragraph_index"]

        if slide_idx >= len(prs.slides):
            print(f"WARNING: Slide index {slide_idx} out of range, skipping")
            continue

        slide = prs.slides[slide_idx]
        if shape_idx >= len(slide.shapes):
            print(f"WARNING: Shape index {shape_idx} out of range on slide {slide_idx}, skipping")
            continue

        shape = slide.shapes[shape_idx]
        if not shape.has_text_frame:
            print(f"WARNING: Shape {shape_idx} on slide {slide_idx} has no text frame, skipping")
            continue

        paragraphs = list(shape.text_frame.paragraphs)
        if para_idx >= len(paragraphs):
            print(f"WARNING: Paragraph index {para_idx} out of range, skipping")
            continue

        paragraph = paragraphs[para_idx]
        run_translations = item.get("run_translations", [])
        apply_run_translations(paragraph, run_translations)

        # Auto-expand text box width if needed
        _expand_textbox_if_needed(shape, paragraph)


def apply_table_translations(prs, translations):
    """Apply translations to table cells."""
    for item in translations.get("table_translations", []):
        slide_idx = item["slide_index"]
        shape_idx = item["shape_index"]
        row_idx = item["row"]
        col_idx = item["col"]
        para_idx = item["paragraph_index"]

        if slide_idx >= len(prs.slides):
            continue

        slide = prs.slides[slide_idx]
        if shape_idx >= len(slide.shapes):
            continue

        shape = slide.shapes[shape_idx]
        if not shape.has_table:
            continue

        table = shape.table
        if row_idx >= len(table.rows) or col_idx >= len(table.columns):
            continue

        cell = table.cell(row_idx, col_idx)
        paragraphs = list(cell.text_frame.paragraphs)
        if para_idx >= len(paragraphs):
            continue

        paragraph = paragraphs[para_idx]
        run_translations = item.get("run_translations", [])
        apply_run_translations(paragraph, run_translations)


def _expand_textbox_if_needed(shape, paragraph):
    """
    Auto-expand text box width if the translated English text is likely to overflow.
    
    Uses a simple heuristic: compare original text length with translated text length.
    If expansion seems needed, increase the text box width by WIDTH_EXPANSION_FACTOR.
    """
    try:
        # Calculate total text length in the paragraph
        original_text = ""
        translated_text = ""
        for run in paragraph.runs:
            original_text += run.text or ""
        
        # Only expand if there's substantial text (not just a few characters)
        # and the text is likely CJK (Chinese/Japanese/Korean)
        has_cjk = any('\u4e00' <= c <= '\u9fff' for c in original_text)
        
        # We can't easily check the original text at this point since it's already
        # been replaced. Instead, check if the current text seems longer than
        # what the box can hold.
        if len(translated_text) > 0 or len(original_text) > 5:
            # Simple heuristic: if text box seems narrow relative to text, expand it
            current_width = shape.width
            if current_width and current_width > 0:
                # Estimate if text might overflow based on font size and text length
                font_size = None
                for run in paragraph.runs:
                    if run.font.size:
                        font_size = run.font.size
                        break
                
                if font_size and font_size > 0:
                    # Rough estimate: each character takes about font_size * 0.6 width for English
                    # and font_size * 1.0 for CJK
                    est_width = int(len(original_text) * font_size * 0.7)
                    if est_width > current_width:
                        new_width = int(current_width * WIDTH_EXPANSION_FACTOR)
                        shape.width = new_width
    except Exception:
        # Don't let expansion errors break the translation process
        pass


def apply_translations(input_path, translations_path, output_path=None):
    """
    Main function: Load PPTX and translations, apply all translations, save result.
    
    Args:
        input_path: Path to original PPTX file
        translations_path: Path to translations JSON file
        output_path: Path for output PPTX (default: <input>_translated.pptx)
    """
    input_path = Path(input_path).resolve()
    translations_path = Path(translations_path).resolve()

    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}")
        sys.exit(1)

    if not translations_path.exists():
        print(f"ERROR: Translations file not found: {translations_path}")
        sys.exit(1)

    # Set default output path
    if output_path is None:
        output_path = input_path.parent / f"{input_path.stem}_translated.pptx"
    else:
        output_path = Path(output_path).resolve()

    # Load translations
    with open(translations_path, "r", encoding="utf-8") as f:
        translations = json.load(f)

    # Load presentation
    prs = Presentation(str(input_path))

    # Apply text translations
    text_count = len(translations.get("translations", []))
    table_count = len(translations.get("table_translations", []))
    
    print(f"Applying {text_count} text translations and {table_count} table translations...")

    apply_text_translations(prs, translations)
    apply_table_translations(prs, translations)

    # Save
    prs.save(str(output_path))
    print(f"Translation applied successfully!")
    print(f"  Output: {output_path}")

    return str(output_path)


def main():
    parser = argparse.ArgumentParser(description="Apply text translations to a PPTX file")
    parser.add_argument("input", help="Path to the input PPTX file")
    parser.add_argument("translations", help="Path to the translations JSON file")
    parser.add_argument("--output", help="Path for the output PPTX file (default: <input>_translated.pptx)")
    args = parser.parse_args()

    apply_translations(args.input, args.translations, args.output)


if __name__ == "__main__":
    main()
