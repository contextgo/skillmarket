# -*- coding: utf-8 -*-
"""
推算基金今日涨跌幅脚本

用法:
  python estimate_fund.py --stocks "长飞光纤:sh601869:9.28,中天科技:sh600522:8.92,..." 

参数:
  --stocks  逗号分隔的持仓股列表，格式: 股票名:代码:持仓占比
  --json    可选，输出JSON格式结果

示例:
  python estimate_fund.py --stocks "长飞光纤:sh601869:9.28,中天科技:sh600522:8.92,亨通光电:sh600487:8.68"
"""

import urllib.request
import json
import argparse
import sys


def fetch_realtime_quotes(codes):
    """从新浪获取实时行情"""
    codes_str = ','.join(codes)
    url = f'https://hq.sinajs.cn/list={codes_str}'
    req = urllib.request.Request(url)
    req.add_header('Referer', 'https://finance.sina.com.cn')
    
    try:
        resp = urllib.request.urlopen(req, timeout=10)
        data = resp.read().decode('gbk')
    except Exception as e:
        print(f"获取行情失败: {e}", file=sys.stderr)
        return {}
    
    result = {}
    for line in data.strip().split('\n'):
        line = line.strip()
        if not line or '="' not in line:
            continue
        code_part = line.split('=')[0].split('_')[-1]
        value_part = line.split('="')[1].rstrip('";')
        if not value_part:
            continue
        fields = value_part.split(',')
        if len(fields) < 4:
            continue
        
        name = fields[0]
        try:
            prev_close = float(fields[2])  # 昨收
            current = float(fields[3])      # 当前价
        except (ValueError, IndexError):
            continue
        
        if prev_close > 0:
            change_pct = (current - prev_close) / prev_close * 100
        else:
            change_pct = 0.0
        
        result[code_part] = {
            'name': name,
            'prev_close': prev_close,
            'current': current,
            'change_pct': round(change_pct, 2)
        }
    
    return result


def estimate_fund(stocks_input):
    """
    推算基金涨幅
    stocks_input: [(名称, 代码, 持仓占比), ...]
    """
    codes = [s[1] for s in stocks_input]
    quotes = fetch_realtime_quotes(codes)
    
    results = []
    total_contribution = 0.0
    total_weight = 0.0
    
    for name, code, weight in stocks_input:
        quote = quotes.get(code, {})
        change_pct = quote.get('change_pct', 0.0)
        prev_close = quote.get('prev_close', 0.0)
        current = quote.get('current', 0.0)
        
        contribution = change_pct * weight / 100
        total_contribution += contribution
        total_weight += weight
        
        results.append({
            'name': name,
            'code': code,
            'weight': weight,
            'prev_close': prev_close,
            'current': current,
            'change_pct': change_pct,
            'contribution': round(contribution, 4)
        })
    
    # 保守估算：剩余仓位不涨不跌
    conservative = round(total_contribution, 2)
    # 等比例估算：剩余仓位与前十同涨跌
    proportional = round(total_contribution / total_weight * 100, 2) if total_weight > 0 else 0.0
    
    return {
        'stocks': results,
        'total_weight': round(total_weight, 2),
        'total_contribution': round(total_contribution, 4),
        'conservative_estimate': conservative,
        'proportional_estimate': proportional
    }


def main():
    parser = argparse.ArgumentParser(description='推算基金今日涨跌幅')
    parser.add_argument('--stocks', required=True, 
                        help='持仓股列表，格式: 股票名:代码:持仓占比，逗号分隔')
    parser.add_argument('--json', action='store_true', help='输出JSON格式')
    args = parser.parse_args()
    
    stocks_input = []
    for item in args.stocks.split(','):
        parts = item.strip().split(':')
        if len(parts) == 3:
            stocks_input.append((parts[0], parts[1], float(parts[2])))
    
    if not stocks_input:
        print("未解析到有效持仓数据", file=sys.stderr)
        sys.exit(1)
    
    result = estimate_fund(stocks_input)
    
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # 表格输出
        print(f"\n{'股票':<8} {'持仓占比':>6} {'昨收':>10} {'现价':>10} {'涨跌幅':>8} {'贡献度':>8}")
        print('-' * 60)
        
        for s in result['stocks']:
            print(f"{s['name']:<8} {s['weight']:>5.2f}% {s['prev_close']:>10.2f} "
                  f"{s['current']:>10.2f} {s['change_pct']:>+7.2f}% {s['contribution']:>+7.4f}%")
        
        print('-' * 60)
        print(f"前十持仓合计: {result['total_weight']:.2f}%")
        print(f"\n=== 推算结果 ===")
        print(f"保守估算（剩余仓位不涨不跌）: {result['conservative_estimate']:+.2f}%")
        print(f"等比例估算（剩余仓位同涨跌）: {result['proportional_estimate']:+.2f}%")
        print(f"\n[!] 基金净值T+1公布，此为盘中估算，实际净值可能有0.1-0.3%偏差")


if __name__ == '__main__':
    main()
