---
name: claude-coder
description: 'Delegate coding tasks to Claude Code CLI with sensible defaults. Use when: (1) building/creating new features or apps, (2) refactoring code, (3) debugging, (4) writing tests, (5) code review, (6) any programming task that benefits from Claude Code capabilities. Automatically uses --print --permission-mode bypassPermissions for smooth non-interactive execution.'
---

# Claude Coder

One-shot coding agent using Claude Code CLI. Clean, simple, no interactive prompts.

## Quick Start

```bash
# Basic usage
claude --permission-mode bypassPermissions --print "Your task here"
```

**Required parameters:**
- `--permission-mode bypassPermissions` — skips confirmation dialogs
- `--print` — non-interactive mode, full tool access, outputs result

## Usage Pattern

### One-Shot Task (Foreground)

```bash
# In a project directory
cd /path/to/project && claude --permission-mode bypassPermissions --print "Add error handling to the API calls"
```

### Background Task

For longer tasks, run in background:

```bash
bash workdir:/path/to/project background:true command:"claude --permission-mode bypassPermissions --print 'Build a REST API for todos'"
```

Monitor with:
```bash
process action:list
process action:log sessionId:XXX
process action:poll sessionId:XXX
```

## Project Directory

**Default behavior:** Run in the current working directory or specify via `workdir`:

```bash
# Specify project directory
bash workdir:~/my-project command:"claude --permission-mode bypassPermissions --print 'Your task'"

# Or cd first
cd ~/my-project && claude --permission-mode bypassPermissions --print "Your task"
```

## Common Tasks

### Building New Features

```bash
claude --permission-mode bypassPermissions --print "Add a dark mode toggle to the navbar component"
```

### Refactoring

```bash
claude --permission-mode bypassPermissions --print "Refactor the auth module to use dependency injection"
```

### Debugging

```bash
claude --permission-mode bypassPermissions --print "Debug why the login form isn't submitting. Check network requests and form validation."
```

### Writing Tests

```bash
claude --permission-mode bypassPermissions --print "Write unit tests for the UserService class with 80% coverage"
```

### Code Review

```bash
claude --permission-mode bypassPermissions --print "Review the changes in src/api/ and suggest improvements"
```

## Auto-Notify on Completion

For background tasks, add a wake trigger:

```bash
bash workdir:~/project background:true command:"claude --permission-mode bypassPermissions --print 'Build feature X.

When done, run: openclaw system event --text \"Done: Feature X built\" --mode now'"
```

## Key Differences from Other Agents

| Agent        | PTY Required | Flags                          |
|--------------|--------------|--------------------------------|
| Claude Code  | ❌ No        | `--print --permission-mode bypassPermissions` |
| Codex/Pi     | ✅ Yes       | `pty:true`                     |

## Rules

1. **Always use `--print --permission-mode bypassPermissions`** — ensures smooth execution
2. **Never use PTY for Claude Code** — it breaks the flow
3. **Set workdir** — keeps agent focused on the right project
4. **Be specific in prompts** — Claude Code works best with clear instructions
5. **Monitor background tasks** — use `process action:log` to check progress
