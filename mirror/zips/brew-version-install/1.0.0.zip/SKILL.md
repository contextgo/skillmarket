---
name: brew-version-install
description: |
  This skill should be used when the user wants to install a specific version of a Homebrew package
  that is not the current stable version. It provides step-by-step instructions for finding and
  installing historical formula (.rb) files from the Homebrew core repository. Trigger phrases
  include "install specific version with brew", "brew install old version", "brew 历史版本",
  "brew 指定版本安装", etc.
---

# Homebrew 特定版本安装

本 Skill 指导如何通过 Homebrew 安装任意历史版本的软件包。

## 核心原理

Homebrew 的 formula 文件存储在 GitHub 的 [homebrew-core](https://github.com/Homebrew/homebrew-core) 仓库中。每个软件的 formula 历史版本都可以在仓库的 history 页面找到。

## 操作流程

### Step 0: 前置检查（必须在所有步骤之前执行）

#### 0.1 检查 Homebrew 是否已安装

执行以下命令检查 Homebrew 是否可用：

```bash
which brew && brew --version
```

- **如果命令成功**（输出 Homebrew 版本号），继续下一步。
- **如果命令失败**（`brew: command not found`），需要先安装 Homebrew：

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

安装完成后，根据终端输出的提示将 brew 添加到 PATH（通常需要执行输出中 "Next steps" 部分的命令）。然后再次验证安装：

```bash
brew --version
```

#### 0.2 检查目标软件包是否已安装

执行以下命令检查目标软件包的安装状态：

```bash
brew list --versions <package-name>
```

根据输出判断：

- **未安装任何版本**（无输出）：直接继续后续安装步骤。
- **已安装且版本与目标版本相同**：输出提示"目标版本已安装，无需操作"，**直接结束，不再执行后续步骤**。
- **已安装但版本与目标版本不同**：需要先卸载当前版本，再继续安装目标版本：

```bash
brew uninstall <package-name>
```

如果卸载时提示有其他软件包依赖该包，使用 `--ignore-dependencies` 强制卸载（需提醒用户注意依赖影响）：

```bash
brew uninstall --ignore-dependencies <package-name>
```

确认卸载完成后，继续后续安装步骤。

### Step 1: 查看软件信息

```bash
brew info <package-name>
```

输出示例（以 qt 为例）：
```
brew info qt
==> qt: stable 6.11.0 (bottled)
...
From: https://github.com/Homebrew/homebrew-core/blob/HEAD/Formula/q/qt.rb
```

记下 `From:` 后面的路径，即 `Formula/<initial>/<package-name>.rb`

### Step 2: 访问 GitHub History

1. 打开 `https://github.com/Homebrew/homebrew-core/blob/HEAD/Formula/<initial>/<package-name>.rb`
   - 将 `<initial>` 替换为软件名首字母（如 qt → q）
   - 将 `<package-name>` 替换为软件名（如 qt）

2. 点击文件名上方的 **History** 按钮进入历史页面

### Step 3: 选择历史版本

在 history 页面中：
- 找到需要的版本对应的 commit
- 点击 commit 右侧的 **<> (Browse code)** 按钮
- 复制该版本的原始文件 URL，格式为：
  ```
  https://raw.githubusercontent.com/Homebrew/homebrew-core/<commit-hash>/Formula/<initial>/<package-name>.rb
  ```

### Step 4: 安装

#### 方式一：下载后本地安装

```bash
# 下载 rb 文件
wget https://raw.githubusercontent.com/Homebrew/homebrew-core/<commit-hash>/Formula/<initial>/<package-name>.rb

# 本地安装
brew install ./<package-name>.rb
```

#### 方式二：直接使用 URL 安装

```bash
brew install https://raw.githubusercontent.com/Homebrew/homebrew-core/<commit-hash>/Formula/<initial>/<package-name>.rb
```

## 完整示例

安装 qt 6.8.2 版本：

```bash
# 1. 查看 qt 信息
brew info qt

# 2. 访问 https://github.com/Homebrew/homebrew-core/blob/HEAD/Formula/q/qt.rb
#    进入 History 页面

# 3. 找到 6.8.2 版本对应的 commit，复制文件 URL
#    假设得到的 URL 为：
#    https://raw.githubusercontent.com/Homebrew/homebrew-core/ec5bed9bbcaee87f26208ddb39da93c15722ffad/Formula/q/qt.rb

# 4. 安装
brew install https://raw.githubusercontent.com/Homebrew/homebrew-core/ec5bed9bbcaee87f26208ddb39da93c15722ffad/Formula/q/qt.rb
```

## 注意事项

1. **版本号查找**: History 页面按时间排序，找到对应版本可能需要滚动查找
2. **依赖**: 某些旧版本可能有特殊依赖需求，按提示处理
3. **卸载**: 如需卸载，使用 `brew uninstall <package-name>` 即可
4. **多版本共存**: 同一软件包不能同时安装多个版本

## 常见问题

**Q: 如何查看已安装的版本？**
```bash
brew list --versions <package-name>
```

**Q: 找不到历史版本？**
部分软件包可能已从仓库中移除，此时无法通过此方法安装。

**Q: 安装失败提示权限错误？**
```bash
sudo brew install ...
```
