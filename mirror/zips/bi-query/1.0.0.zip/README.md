# BI Query - 智能问数 Skill

通过自然语言连接 MySQL 数据库，执行智能查询。

## 快速开始

### 1. 安装依赖

```bash
pip install pymysql
```

### 2. 配置数据库连接

编辑 `config.json`，填入你的 MySQL 信息：

```json
{
  "host": "127.0.0.1",
  "port": 3306,
  "user": "root",
  "password": "你的密码",
  "database": "目标数据库名",
  "default_limit": 1000,
  "query_timeout": 30
}
```

### 3. 生成表结构缓存（首次使用）

```bash
# 拉取表索引（轻量，必需）
python scripts/get_schema.py --mode index --output references/schema.md

# 拉取详细字段（按需，首次问答前建议跑一次）
python scripts/get_schema.py --mode detail --tables 表1,表2,表3
```

### 4. 开始问答

直接用自然语言提问，例如：
- "一共有多少用户？"
- "上个月销售额是多少？"
- "哪个商品卖得最好？"

AI 会自动生成 SQL → 执行 → 返回自然语言回答。

## 文件结构

```
bi-query/
├── SKILL.md              # AI 使用说明
├── config.json           # 数据库配置
├── scripts/
│   ├── get_schema.py     # 拉取表结构
│   └── query_mysql.py    # 执行 SQL 查询
└── references/
    └── schema.md         # 表结构缓存（自动生成）
```

## 安全特性

- ✅ 只允许 SELECT/SHOW/DESCRIBE/EXPLAIN 查询
- ❌ 禁止 INSERT/UPDATE/DELETE/DROP 等写操作
- ❌ 禁止多语句执行
- ⏱️ 默认 30 秒超时
- 📊 默认 LIMIT 1000 行

## 适用 AI 工具

- OpenClaw / QClaw
- Cursor / Claude Code / Codex
- Coze / Dify 工作流
- 任何可调用 Python 脚本的 AI 系统
