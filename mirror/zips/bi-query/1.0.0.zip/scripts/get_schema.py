#!/usr/bin/env python3
"""Extract MySQL database schema for AI context.

Modes:
  index   — list all tables with comments (lightweight, always load this)
  detail  — full column info for specified tables (load on demand)
"""

import sys
import os
import json
import argparse

# 强制 UTF-8 输出，避免 Windows 终端中文乱码
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

try:
    import pymysql
except ImportError:
    print(json.dumps({"ok": False, "error": "pymysql not installed. Run: pip install pymysql"}, ensure_ascii=False))
    sys.exit(1)


def load_config(config_path: str | None) -> dict:
    if config_path and os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    skill_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    default_cfg = os.path.join(skill_root, "config.json")
    if os.path.isfile(default_cfg):
        with open(default_cfg, "r", encoding="utf-8") as f:
            return json.load(f)
    print(json.dumps({"ok": False, "error": "config.json not found"}, ensure_ascii=False))
    sys.exit(1)


def get_connection(config: dict):
    return pymysql.connect(
        host=config.get("host", "127.0.0.1"),
        port=int(config.get("port", 3306)),
        user=config.get("user", "root"),
        password=config.get("password", ""),
        database=config.get("database", ""),
        charset="utf8mb4",
        connect_timeout=10,
        cursorclass=pymysql.cursors.Cursor,
    )


def schema_index(conn) -> list[dict]:
    """Get table names + comments."""
    with conn.cursor() as cur:
        cur.execute("""
            SELECT TABLE_NAME, TABLE_COMMENT, TABLE_ROWS
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
            ORDER BY TABLE_NAME
        """)
        return [
            {"table": row[0], "comment": row[1] or "", "rows": int(row[2] or 0)}
            for row in cur.fetchall()
        ]


def schema_detail(conn, tables: list[str] | None = None) -> list[dict]:
    """Get column details for specified tables (or all)."""
    with conn.cursor() as cur:
        if tables:
            placeholders = ",".join(["%s"] * len(tables))
            cur.execute(f"""
                SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE,
                       COLUMN_KEY, COLUMN_DEFAULT, EXTRA, COLUMN_COMMENT
                FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({placeholders})
                ORDER BY TABLE_NAME, ORDINAL_POSITION
            """, tables)
        else:
            cur.execute("""
                SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE,
                       COLUMN_KEY, COLUMN_DEFAULT, EXTRA, COLUMN_COMMENT
                FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                ORDER BY TABLE_NAME, ORDINAL_POSITION
            """)
        result = {}
        for row in cur.fetchall():
            tbl = row[0]
            if tbl not in result:
                result[tbl] = []
            result[tbl].append({
                "column": row[1],
                "type": row[2],
                "nullable": row[3] == "YES",
                "key": row[4],
                "default": row[5],
                "extra": row[6],
                "comment": row[7] or "",
            })
        return result


def generate_schema_md(index: list[dict], detail: dict | None = None) -> str:
    """Generate markdown documentation."""
    lines = []
    lines.append("# Database Schema")
    lines.append(f"Tables: {len(index)}")
    lines.append("")

    # Index section
    lines.append("## Table Index")
    lines.append("")
    lines.append("| Table | Comment | Est. Rows |")
    lines.append("|-------|---------|-----------|")
    for t in index:
        rows_str = f"{t['rows']:,}" if t['rows'] > 0 else "-"
        lines.append(f"| `{t['table']}` | {t['comment']} | {rows_str} |")
    lines.append("")

    # Detail section (if available)
    if detail:
        lines.append("---")
        lines.append("")
        for tbl, cols in detail.items():
            tbl_comment = next((t["comment"] for t in index if t["table"] == tbl), "")
            lines.append(f"## `{tbl}`")
            if tbl_comment:
                lines.append(f"> {tbl_comment}")
            lines.append("")
            lines.append("| Column | Type | Nullable | Key | Default | Comment |")
            lines.append("|--------|------|----------|-----|---------|---------|")
            for c in cols:
                key_str = c["key"] if c["key"] else ""
                default_str = str(c["default"]) if c["default"] is not None else ""
                lines.append(f"| `{c['column']}` | {c['type']} | {'YES' if c['nullable'] else 'NO'} | {key_str} | {default_str} | {c['comment']} |")
            lines.append("")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Extract MySQL schema for AI context")
    parser.add_argument("--mode", choices=["index", "detail"], default="index")
    parser.add_argument("--tables", default=None, help="Comma-separated table names (detail mode)")
    parser.add_argument("--config", default=None, help="Path to config.json")
    parser.add_argument("--output", default=None, help="Output file path (default: stdout)")
    args = parser.parse_args()

    config = load_config(args.config)
    conn = get_connection(config)

    try:
        index = schema_index(conn)
        detail = None
        if args.mode == "detail":
            tables = [t.strip() for t in args.tables.split(",")] if args.tables else None
            detail = schema_detail(conn, tables)

        md = generate_schema_md(index, detail)

        if args.output:
            os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(md)
            print(json.dumps({"ok": True, "output": args.output, "tables": len(index)}, ensure_ascii=False))
        else:
            print(md)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
