#!/usr/bin/env python3
"""MySQL query executor with safety guards.
Reads config from a JSON file in the same directory as this script's parent,
or from --config path.
"""

import argparse
import json
import sys
import os
import time
from decimal import Decimal

# 强制 UTF-8 输出，避免 Windows 终端中文乱码
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

try:
    import pymysql
except ImportError:
    print(json.dumps({"ok": False, "error": "pymysql not installed. Run: pip install pymysql"}, ensure_ascii=False))
    sys.exit(1)

# ---------------------------------------------------------------------------
# SQL safety: only allow read-only statements
# ---------------------------------------------------------------------------
ALLOWED_PREFIXES = ("SELECT", "SHOW", "DESCRIBE", "DESC", "EXPLAIN")
BLOCKED_TOKENS = ("INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE",
                   "REPLACE", "CREATE", "GRANT", "REVOKE", "LOCK", "UNLOCK",
                   "CALL", "EXEC", "LOAD_FILE", "INTO OUTFILE", "INTO DUMPFILE")

def validate_sql(sql: str) -> str | None:
    """Return error string if unsafe, else None."""
    cleaned = sql.strip().rstrip(";").strip()
    upper = cleaned.upper()
    if not any(upper.startswith(p) for p in ALLOWED_PREFIXES):
        return f"Only read-only queries allowed (SELECT/SHOW/DESCRIBE/EXPLAIN). Got: {upper[:60]}"
    # Block dangerous keywords anywhere in the query
    for tok in BLOCKED_TOKENS:
        if tok in upper:
            return f"Dangerous keyword detected: {tok}"
    # Block multiple statements
    if ";" in cleaned:
        return "Multiple statements not allowed"
    return None


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------
def load_config(config_path: str | None) -> dict:
    if config_path and os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    skill_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    default_cfg = os.path.join(skill_root, "config.json")
    if os.path.isfile(default_cfg):
        with open(default_cfg, "r", encoding="utf-8") as f:
            return json.load(f)
    print(json.dumps({"ok": False, "error": f"config.json not found. Place it at: {default_cfg}"}, ensure_ascii=False))
    sys.exit(1)


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def execute(config: dict, sql: str, limit: int | None = None, timeout: int = 30) -> dict:
    safety_err = validate_sql(sql)
    if safety_err:
        return {"ok": False, "error": safety_err}

    sql_upper = sql.upper().strip().rstrip(";").strip()
    if sql_upper.startswith("SELECT") and "LIMIT" not in sql_upper:
        effective_limit = limit or config.get("default_limit", 1000)
        sql = f"{sql.rstrip(';')} LIMIT {effective_limit}"

    try:
        conn = pymysql.connect(
            host=config.get("host", "127.0.0.1"),
            port=int(config.get("port", 3306)),
            user=config.get("user", "root"),
            password=config.get("password", ""),
            database=config.get("database", ""),
            charset="utf8mb4",
            connect_timeout=10,
            read_timeout=timeout,
            write_timeout=timeout,
            cursorclass=pymysql.cursors.Cursor,
            autocommit=True,
        )
    except Exception as e:
        return {"ok": False, "error": f"Connection failed: {e}"}

    try:
        with conn.cursor() as cur:
            start = time.time()
            cur.execute(sql)
            elapsed = round(time.time() - start, 3)

            if cur.description is None:
                conn.commit()
                return {"ok": True, "message": "Query executed (no result set)", "elapsed": elapsed}

            columns = [desc[0] for desc in cur.description]
            rows = cur.fetchall()

            clean_rows = []
            for row in rows:
                clean_row = []
                for val in row:
                    if hasattr(val, "isoformat"):
                        clean_row.append(val.isoformat())
                    elif isinstance(val, bytes):
                        clean_row.append(val.decode("utf-8", errors="replace"))
                    elif isinstance(val, Decimal):
                        clean_row.append(str(val))
                    else:
                        clean_row.append(val)
                clean_rows.append(clean_row)

            return {
                "ok": True,
                "columns": columns,
                "rows": clean_rows,
                "row_count": len(clean_rows),
                "elapsed": elapsed,
                "sql": sql,
            }
    except pymysql.err.OperationalError as e:
        return {"ok": False, "error": f"Query timeout or connection lost: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"Query error: {e}"}
    finally:
        conn.close()


def main():
    parser = argparse.ArgumentParser(description="Safe MySQL query executor")
    parser.add_argument("--sql", required=True, help="SQL query to execute")
    parser.add_argument("--config", default=None, help="Path to config.json")
    parser.add_argument("--limit", type=int, default=None, help="Max rows (default from config)")
    parser.add_argument("--timeout", type=int, default=None, help="Query timeout in seconds")
    args = parser.parse_args()

    config = load_config(args.config)
    timeout = args.timeout or config.get("query_timeout", 30)
    result = execute(config, args.sql, args.limit, timeout)
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
