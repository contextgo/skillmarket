---
version: 1.0.0
name: feedship-github-trending
description: "Analyze weekly GitHub trending repositories with strategic insights. Use when user wants GitHub trending analysis, 开源趋势分析, 每周开源热点, GitHub 周报, or 开发者趋势洞察. Extracts GitHub trending data via feedship fetch, generates First Principles analysis via LLM, and replaces citation placeholders. Requires feedship skill."
metadata:
  openclaw:
    requires:
      bins:
        - uv
    cron:
      syntax: cron([minute,] [hour,] [day-of-month,] [month,] [day-of-week])
      default: "0 9 * * 1"  # Every Monday at 9 AM
      description: "Generate weekly GitHub trending analysis every Monday at 9 AM"
---

# GitHub Trending 周报 (Feedship GitHub Trending)

**Version:** 1.0.0
**For:** OpenClaw compatible agents
**Description:** Analyze weekly GitHub trending repositories with strategic First Principles thinking

## 为什么需要引用替换（Step 3.5）

LLM 生成的引用有两大幻觉风险：
1. **编号幻觉**：引用列表中不存在的编号（如 `${99}` for a 10-item list）
2. **展开幻觉**：在引用中直接输出标题/链接时捏造内容

**解决方案：** LLM 只输出 `${N}` 占位符，标题和链接由 `replace_refs.py` 脚本从权威 JSON 中注入。

---

## 1. Setup

This skill requires feedship v1.8.0+. Use the local project version:

```bash
cd /Users/y3/feedship && uv run feedship --version
```

Verify `fetch` command is available:

```bash
cd /Users/y3/feedship && uv run feedship fetch --help
```

## 2. Usage

### On-Demand (Manual)

User triggers:
`"GitHub trending"`, `"开源趋势"`, `"每周开源热点"`, `"GitHub 周报"`, `"开发者趋势洞察"`, `"github trending analysis"`

The agent will activate this skill and run the **Generate Trending Report** flow (see section 3).

### Automatic (Cron)

Schedule weekly reports every Monday at 9 AM Beijing time:

```bash
openclaw cron add \
  --name "feedship-github-trending" \
  --agent feedship-github-trending \
  --cron "0 9 * * 1" \
  --tz Asia/Shanghai \
  --session isolated \
  --announce \
  --channel <your-channel> \
  --to <your-destination> \
  --timeout-seconds 600 \
  --message "使用 feedship-github-trending skill 生成本周开源趋势分析。" \
  --thinking xhigh
```

---

## 3. Generate Trending Report

### Step 1. 提取 GitHub Trending 数据

```bash
# 提取 GitHub trending 数据
cd /Users/y3/feedship && uv run feedship fetch \
  --url "https://github.com/trending?since=weekly" \
  --json > /tmp/github_trending.json

# 验证数据
python3 -c "
import json
data = json.load(open('/tmp/github_trending.json'))
articles = data.get('articles', [])
print(f'获取到 {len(articles)} 个 trending 仓库')
for i, a in enumerate(articles[:5]):
    stars = a.get('meta', {}).get('stars', 0)
    print(f'{i}. [{stars}★] {a.get(\"title\", \"\")[:80]}')
"
```

**输出示例:**
```
获取到 25 个 trending 仓库
0. [110927★] microsoft/markitdown: Python tool for converting files...
1. [95748★] NousResearch/hermes-agent: The agent that grows with you
2. [53271★] forrestchang/andrej-karpathy-skills: A single CLAUDE.md file...
```

### Step 2. 拼接提示词

从 `references/prompt.md` 读取提示词模板：

```bash
# 读取提示词模板
PROMPT=$(cat skills/feedship-github-trending/references/prompt.md)

# 将仓库数据格式化为简洁的标题列表
python3 -c "
import json
data = json.load(open('/tmp/github_trending.json'))
articles = data.get('articles', [])
for i, a in enumerate(articles[:10]):  # 取前 10 个
    stars = a.get('meta', {}).get('stars', 0)
    lang = a.get('meta', {}).get('language', '')
    title = a.get('title', '').split(']', 1)[-1].strip() if ']' in a.get('title', '') else a.get('title', '')
    desc = a.get('description', '')[:100]
    print(f'{i}. [{stars}★] {lang} - {title}')
    print(f'   {desc}')
"
```

### Step 3. 发送至 LLM

将 `$FULL_PROMPT` 发送给 LLM（MiniMax-M2.7 或同类模型）生成分析。

**⚠️ 重要提示给 LLM：** 在回复中，严格只使用 `${N}` 格式引用仓库，禁止展开标题或链接。最多引用 10 个仓库（${0} 到 ${9}）。

### Step 3.5. 替换引用占位符

```bash
# 准备 JSON 数据
GITHUB_TRENDING_JSON=$(cat /tmp/github_trending.json | python3 -c "
import json, sys
data = json.load(sys.stdin)
# 简化：只保留前 10 个
data['articles'] = data.get('articles', [])[:10]
print(json.dumps(data))
")

# 替换引用
cat LLM_OUTPUT.txt | GITHUB_TRENDING_JSON="$GITHUB_TRENDING_JSON" \
  python3 skills/feedship-github-trending/scripts/replace_refs.py > /tmp/trending_final.md
```

**脚本功能：**
- `${N}` → `[owner/repo (stars★)](link)`
- `${3,7}` → 展开为两个独立链接（逗号分隔）
- 无效编号 → `[无效引用 #N]`

### Step 4. 输出最终报告

读取 `/tmp/trending_final.md` 输出给用户。

---

## 4. Prompt 模板参考

完整的提示词模板位于 `references/prompt.md`，包含：

- **Role**: Principal Tech Strategist & Open-Source Trend Forecaster
- **Citation Rules**: 防幻觉核心规则——LLM 只输出 `${N}`，禁止展开标题/链接
- **Execution Steps**: 4个步骤（分类解构 → 根本原因 → 暗线发现 → 价值翻译）
- **Output Rules**: 语言、结构、约束条件

---

## 5. Troubleshooting

| Problem | Solution |
|---------|----------|
| `feedship: command not found` | 使用 `cd /Users/y3/feedship && uv run feedship` |
| `fetch: Error fetching URL` | GitHub 可能限制了请求，检查网络或添加延时 |
| Empty article list | GitHub trending 页面结构可能变化，需更新解析逻辑 |
| 大量 `[无效引用 #N]` | LLM 引用了不存在的编号（只应引用 ${0}-${9}），检查 prompt.md 中的 Citation Rules |
| LLM 直接展开标题/链接 | 在 Step 3 发送时强调：禁止展开链接，只输出 `${N}` |

---

## 6. Change Log

- **v1.0.0**: 初始版本，基于 feedship-ai-daily 最佳实践
