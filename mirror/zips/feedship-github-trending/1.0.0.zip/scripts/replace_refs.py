#!/usr/bin/env python3
"""
Replace citation placeholders ${N} with actual GitHub repo links.
Works with feedship-github-trending skill JSON format (articles array).

Usage:
    cat report.md | GITHUB_TRENDING_JSON="$JSON_DATA" python3 scripts/replace_refs.py
"""
import sys, json, re, os

def main():
    json_str = os.environ.get('GITHUB_TRENDING_JSON', '{}')
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        print("[replace_refs] Error: Invalid JSON in GITHUB_TRENDING_JSON", file=sys.stderr)
        sys.exit(1)

    articles = data.get('articles', [])
    text = sys.stdin.read()
    replaced_count = 0

    def replace_ref(m):
        nonlocal replaced_count
        idx = int(m.group(1))
        try:
            item = articles[idx]
            stars = item.get('meta', {}).get('stars', 0)
            title = item.get('title', '').split(']', 1)[-1].strip() if ']' in item.get('title', '') else item.get('title', '')
            link = item.get('link', '')
            repo_name = link.replace('https://github.com/', '') if link else 'unknown'
            replaced_count += 1
            return f'[{repo_name} ({stars}★)]({link})'
        except (IndexError, KeyError):
            return f'[无效引用 #{idx}]'

    def replace_refs_multi(m):
        """Handle comma-separated refs like ${1,3,5}"""
        nonlocal replaced_count
        indices = [int(x.strip()) for x in m.group(1).split(',')]
        results = []
        for idx in indices:
            try:
                item = articles[idx]
                stars = item.get('meta', {}).get('stars', 0)
                link = item.get('link', '')
                repo_name = link.replace('https://github.com/', '') if link else 'unknown'
                results.append(f'[{repo_name} ({stars}★)]({link})')
                replaced_count += 1
            except (IndexError, KeyError):
                results.append(f'[无效引用 #{idx}]')
        return ', '.join(results)

    # Handle comma-separated refs first: ${1,3,5}
    text = re.sub(r'\$\{([0-9, ]+)\}', replace_refs_multi, text)
    # Handle single refs: ${N}
    text = re.sub(r'\$\{(\d+)\}', replace_ref, text)

    print(text)
    print(f'\n[replace_refs] {replaced_count} 处引用已替换', file=sys.stderr)

if __name__ == '__main__':
    main()
