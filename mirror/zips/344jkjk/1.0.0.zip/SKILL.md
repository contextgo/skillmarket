# 资产信息查询

## 技能描述
查询资产列表、资产信息，支持序列号、资产类型、状态、公司、项目类型、地区、管理员、时间等筛选。

## 调用方式
API接口调用

## 接口地址
POST http://111.34.85.148:9019/gateway/appstoreOss/asset/queryAssetInfo

## 请求头
Content-Type: application/json

## 请求体
{
    "pageNo": 1,
    "pageSize": 10,
    "serialno": "",
    "type": "",
    "deliverState": "",
    "state": "",
    "companyName": "",
    "cn": "",
    "projectType": "",
    "provinceId": "",
    "cityId": "",
    "countyId": "",
    "activeState": "",
    "assetAdmin": "",
    "date": [
        "",
        ""
    ],
    "startTime": "",
    "endTime": ""
}

## 输入参数
序列号、资产类型、交付状态、公司名称、项目类型、省份、城市、区县、激活状态、资产管理员、时间范围

## 技能使用示例
帮我查询资产列表
查询资产序列号为XXX的信息
帮我查山东省的资产
查询资产管理员是XXX的资产



# 采购合同信息查询

## 技能描述
查询采购合同列表，支持采购单号、供应商、省份、状态筛选。

## 调用方式
API接口调用

## 接口地址
POST http://111.34.85.148:9019/gateway/appstoreOss/procurement/contract/getProcurementContractPageList

## 请求头
Content-Type: application/json

## 请求体
{
    "pageNo": 1,
    "pageSize": 10,
    "procurementNo": "",
    "supplier": "",
    "province": "",
    "status": ""
}

## 输入参数
采购单号、供应商、省份、状态

## 技能使用示例
帮我查询采购合同列表
查询采购单号XXX
查询山东省的采购合同
查询已完成的采购合同



# 验收信息查询

## 技能描述
查询验收列表、设备验收信息，支持采购单号、设备名称、SN、设备类型、归属、省份筛选。

## 调用方式
API接口调用

## 接口地址
POST http://111.34.85.148:9019/gateway/appstoreOss/procurement/acceptance/getProcurementAcceptancePageList

## 请求头
Content-Type: application/json

## 请求体
{
    "pageNo": 1,
    "pageSize": 10,
    "procurementNo": "",
    "deviceName": "",
    "sn": "",
    "deviceType": "",
    "deviceBelong": "",
    "province": ""
}

## 输入参数
采购单号、设备名称、SN、设备类型、设备归属、省份

## 技能使用示例
帮我查询验收列表
查询采购单号XXX的验收信息
查询设备SN为XXX的验收记录
查询山东省的设备验收信息



# 应用管理查询

## 技能描述
查询应用管理列表、应用信息，支持应用名称、类型、审核状态、状态、开发者、上线状态筛选。

## 调用方式
API接口调用

## 接口地址
POST http://111.34.85.148:9019/gateway/appstoreOss/appManage/getManageAppPageList

## 请求头
Content-Type: application/json

## 请求体
{
    "pageNo": 1,
    "pageSize": 10,
    "name": "",
    "type": "",
    "verifyState": "",
    "state": "",
    "developerId": "",
    "onlineStatus": ""
}

## 输入参数
应用名称、类型、审核状态、状态、开发者ID、上线状态

## 技能使用示例
帮我查询应用列表
查询已上线的应用
查询名称为XXX的应用
查询开发者XXX的应用



# 应用使用日志查询

## 技能描述
查询应用使用日志，支持按时间范围筛选。

## 调用方式
API接口调用

## 接口地址
POST http://111.34.85.148:9019/gateway/appstoreOss/appUselog/getAppUseLogPageList

## 请求头
Content-Type: application/json

## 请求体
{
    "pageNo": 1,
    "pageSize": 10,
    "startTime": "",
    "endTime": ""
}

## 输入参数
开始时间、结束时间

## 技能使用示例
帮我查询应用使用日志
查询今天的应用使用记录
查询近7天的应用使用日志