---
name: superconducting-quantum-computing
description: |
  超导量子计算专家技能。基于金贻荣老师直播课件知识库蒸馏，涵盖从人造原子到量子算法的完整超导量子计算知识体系。
  当用户询问超导量子计算、量子比特、量子纠错、量子算法等相关问题时触发。
  支持直接检索 IMA 知识库获取详细课件内容。
metadata:
  openclaw:
    emoji: '🔬'
    primaryEnv: 'IMA_OPENAPI_CLIENTID'
---

# 超导量子计算技能

本技能基于 IMA 知识库"金贻荣老师的直播课件"蒸馏而成，包含完整的超导量子计算知识体系。

## 知识库结构

知识库包含 **16 个主题文件夹**，按课程时间顺序排列：

### 基础物理
| 文件夹 | 主题 |
|--------|------|
| 1月3 | 超导计算机研发会议 |
| 1月10日：人造原子 | 人造原子（Artificial Atoms）|
| 12月28 | 参量放大器（Parametric Amplifier）|
| 1月17 | 迪文森佐准则（DiVincenzo Criteria）|

### 量子比特与体系
| 文件夹 | 主题 |
|--------|------|
| 量子比特体系2 | 超导量子比特体系 |
| 量子比特体系的研讨 | 量子比特体系深度研讨 |
| 给学生的科普 | 量子计算入门科普 |

### 量子纠错
| 文件夹 | 主题 |
|--------|------|
| 2月28日 | 量子纠错基础 |
| 3月7日 | 表面码（Surface Code）纠错 |

### 硬件工程
| 文件夹 | 主题 |
|--------|------|
| 3月14日 | 超导量子计算机测控线路与降噪原理 |
| 3月21日 | 量子芯片 |
| 3月28日 | 量子测量 |

### 量子算法
| 文件夹 | 主题 |
|--------|------|
| 1月24日 | Shor 算法 |
| 1月31日 | Grover 算法 |
| 2月14日 | 量子化学（VQE）|

### 补充资料
- 量子工程学.pdf
- 量子工程学_构建与控制.pdf

## 核心知识框架

### 1. 超导量子比特基础

**约瑟夫森结 (Josephson Junction)**
- 超导量子比特的核心器件
- 基于超导约瑟夫森效应的非线性电感
- 创造非谐势阱，形成离散的能级结构
- 最常见的 qubit 形式：Transmon

**Transmon qubit**
- Transmission-line shunted plasma oscillation qubit
- 设计用于抑制电荷噪声敏感性
- 典型频率：4-8 GHz（对应冷却到 ~100 mK）
- 相干时间：T1 ~ 100 μs, T2 ~ 50 μs（当前最佳可达 300+ μs）

**谐振腔 (Resonator)**
- 用于 qubit 读取和耦合
- 典型品质因子 Q > 10^6
- 读取方式：色散读取（dispersive readout）

### 2. 量子门操作

**单比特门**
- 微波脉冲驱动 qubit 在能级间跃迁
- 典型门操作时间：10-50 ns
- 门保真度：> 99.9%（已实现）

**两比特门**
- 典型：iSWAP、CZ、CR
- 通过 qubit-resonator-qubit 耦合实现
- 典型门操作时间：20-200 ns
- 门保真度：> 99%（当前最佳 > 99.9%）

### 3. 量子测量

**读取谐振器**
- 约瑟夫森参量放大器 (JPA) 用于低噪声放大
- 量子非破坏性测量 (QND)
- 测量保真度：> 99%

### 4. 量子纠错

**为什么需要纠错？**
- 物理 qubit 错误率：10^-3 ~ 10^-4
- 逻辑 qubit 需要错误率 < 10^-10
- 需要大量冗余编码

**表面码 (Surface Code)**
- 当前最流行的量子纠错方案
- 需要 49 个物理 qubit 编码 1 个逻辑 qubit（阈值 1%）
- 纠错阈值：~1%
- 实际需要：1000+ 物理 qubit 实现有意义的计算

### 5. 量子算法

**Shor 算法**
- 大数质因数分解
- 对 RSA 加密构成威胁
- 需要 ~4000 逻辑 qubit（考虑纠错）

**Grover 算法**
- 无结构数据库搜索
- 平方加速：O(√N)
- 实际优势有限，更多展示量子计算潜力

**VQE (Variational Quantum Eigensolver)**
- 量子-经典混合算法
- 应用于量子化学模拟
- 当前 NISQ 时代的热门方向

### 6. 迪文森佐准则 (DiVincenzo's Criteria)

实现量子计算的 5 个必要条件：
1. **可扩展性**：能够增加 qubit 数量
2. **初始化**：可靠地制备初始量子态
3. **相干性**：保持量子相干时间足够长
4. **普适门**：实现通用的量子门集合
5. **测量**：高保真度读取最终量子态

### 7. 测控线路与降噪

**测控系统**
- 室温控制：任意波形发生器 (AWG)
- 低温部分：同轴电缆、滤波器和衰减器
- 典型线缆延迟：~100 ns/100m

**噪声来源**
- 1/f 电荷噪声
- 热噪声
- 宇宙射线

**降噪技术**
- 滤波与屏蔽
- 脉冲技术（DD、CPMG）
- 量子纠错码

## 检索知识库原文

当用户需要获取知识库中**具体的课件详细内容**时，使用 IMA API 检索：

### 凭证获取（必需）

IMA 凭证脚本路径：
```bash
IMA_SCRIPT="/Users/avalok/Library/Application Support/QClaw/openclaw/config/skills/ima/get-token.sh"
```

### 搜索知识库内容

```bash
CREDS=$(bash "$IMA_SCRIPT") && \
curl -s -X POST "https://ima.qq.com/openapi/wiki/v1/search_knowledge" \
  -H "ima-openapi-clientid: $(echo "$CREDS" | jq -r .client_id)" \
  -H "ima-openapi-apikey: $(echo "$CREDS" | jq -r .api_key)" \
  -H "Content-Type: application/json" \
  -d '{"query": "<搜索关键词>", "knowledge_base_id": "WlN-9iwxGpbmDUPhShjBcHYAoe_h2xLRvV0fyMiIGEk=", "cursor": ""}'
```

### 浏览指定文件夹

```bash
CREDS=$(bash "$IMA_SCRIPT") && \
curl -s -X POST "https://ima.qq.com/openapi/wiki/v1/get_knowledge_list" \
  -H "ima-openapi-clientid: $(echo "$CREDS" | jq -r .client_id)" \
  -H "ima-openapi-apikey: $(echo "$CREDS" | jq -r .api_key)" \
  -H "Content-Type: application/json" \
  -d '{"knowledge_base_id": "WlN-9iwxGpbmDUPhShjBcHYAoe_h2xLRvV0fyMiIGEk=", "folder_id": "<folder_id>", "cursor": "", "limit": 50}'
```

**常用 folder_id:**
- `folder_7438581148686180` - 超导量子计算机测控线路与降噪原理
- `folder_7436044232294577` - 表面码纠错
- `folder_7433504346358380` - 量子纠错
- `folder_7441119184970879` - 量子芯片
- `folder_7423372052948827` - Shor算法
- `folder_7423371348304619` - Grover算法

## 常见问题速查

| 问题 | 答案 |
|------|------|
| 超导量子计算机工作温度？ | ~15 mK（毫开尔文），接近绝对零度 |
| 超导 qubit 频率？ | 4-8 GHz |
| 当前最大量子比特数？ | IBM 超过 1000+（2024）|
| 纠错阈值？ | ~1%（表面码）|
| 为什么需要极低温？ | 热噪声会破坏量子态，相干时间随温度指数下降 |
| Transmon 的优势？ | 对电荷噪声不敏感，易于加工和缩放 |

## 知识库原文检索示例

当用户问"表面码纠错的原理是什么？"时：

1. 先用本技能提供基础解释
2. 如需获取知识库原文：
```bash
# 搜索表面码相关内容
CREDS=$(bash "$IMA_SCRIPT") && \
curl -s -X POST "https://ima.qq.com/openapi/wiki/v1/search_knowledge" \
  -H "ima-openapi-clientid: $(echo "$CREDS" | jq -r .client_id)" \
  -H "ima-openapi-apikey: $(echo "$CREDS" | jq -r .api_key)" \
  -H "Content-Type: application/json" \
  -d '{"query": "表面码", "knowledge_base_id": "WlN-9iwxGpbmDUPhShjBcHYAoe_h2xLRvV0fyMiIGEk=", "cursor": ""}'
```

---

## 参考资料

- 金贻荣老师直播课件知识库（IMA）
- 量子工程学.pdf / 量子工程学_构建与控制.pdf
- IBM Quantum Experience
- Google Quantum AI
