# 超导量子计算技能安装说明书

## 技能概述

- **技能名称**: superconducting-quantum-computing
- **功能**: 超导量子计算专家技能，基于金贻荣老师直播课件知识库蒸馏
- **触发关键词**: 超导量子、量子计算、量子比特、量子纠错、Shor算法、Grover算法等
- **依赖**: IMA API（用于检索知识库原文）

## 自动安装

技能已自动安装到 QClaw，路径：
```
~/Library/Application Support/QClaw/openclaw/config/skills/superconducting-quantum-computing/
```

## 手动安装（如果需要重新安装）

### 步骤 1：创建技能目录

```bash
mkdir -p ~/Library/Application\ Support/QClaw/openclaw/config/skills/superconducting-quantum-computing
```

### 步骤 2：复制技能文件

将以下文件复制到上述目录：
- `SKILL.md` - 主技能文件（必需）

### 步骤 3：重启 QClaw Gateway

```bash
openclaw gateway restart
```

## 使用方法

### 基本使用

当用户询问超导量子计算相关问题时，技能会自动触发：

- 量子比特原理与类型
- 量子门操作
- 量子纠错与表面码
- 量子算法（Shor、Grover、VQE）
- 超导量子计算机硬件
- 测控系统与降噪

### 检索知识库原文

技能支持检索 IMA 知识库中的原始课件内容：

**注意**：首次使用知识库检索功能前，需要确保 IMA 已授权。

```bash
# 测试 IMA 连接
cd ~/Library/Application\ Support/QClaw/openclaw/config/skills/ima
bash get-token.sh
```

如提示未授权，请在 QClaw 集成面板中完成 IMA 授权。

## 技能结构

```
superconducting-quantum-computing/
└── SKILL.md          # 主技能文件
    ├── 知识库结构       # IMA 知识库目录
    ├── 核心知识框架     # 超导量子计算知识点
    ├── 检索知识库原文   # API 调用示例
    └── 常见问题速查    # FAQ
```

## 故障排除

### 技能未触发

检查触发关键词是否包含在问题中，或手动指定使用本技能。

### 知识库检索失败

1. 检查 IMA 授权状态：
```bash
cd ~/Library/Application\ Support/QClaw/openclaw/config/skills/ima
bash get-token.sh
```

2. 如显示 ERROR，按提示完成 IMA 授权

### 需要更新知识库

IMA 知识库是云端的，如需更新技能中的知识库结构信息，请从 IMA 重新导出并更新 SKILL.md。

---

**技能版本**: 1.0  
**创建日期**: 2026-04-22  
**知识库来源**: IMA - 金贻荣老师的直播课件
