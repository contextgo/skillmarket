#!/usr/bin/env node

/**
 * 抖音无水印视频下载和文案提取工具 (Node.js 版本)
 * 
 * 功能:
 * 1. 从抖音分享链接获取无水印视频下载链接
 * 2. 下载视频并提取音频
 * 3. 使用硅基流动 API 从音频中提取文本
 * 4. 使用 MiniMax 模型进行语义分段（可选）
 * 5. 自动保存文案到文件
 * 
 * 环境变量:
 * - SILI_FLOW_API_KEY: 硅基流动 API 密钥 (用于文案提取功能)
 * - MINIMAX_API_KEY: MiniMax API 密钥 (用于语义分段功能)
 * 
 * 使用示例:
 *   node douyin.js info "抖音分享链接"
 *   node douyin.js download "抖音分享链接" -o /tmp/douyin-download
 *   node douyin.js extract "抖音分享链接" -o /tmp/douyin-download
 *   node douyin.js extract "抖音链接" --segment     # 带语义分段
 *   node douyin.js extract "抖音链接" --no-segment  # 不分段
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const https = require('https');
const http = require('http');
const { URL } = require('url');

// 配置
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) EdgiOS/121.0.2277.107 Version/17.0 Mobile/15E148 Safari/604.1',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9',
};

const SILI_FLOW_BASE_URL = 'https://api.siliconflow.cn/v1/audio/transcriptions';
const SILI_FLOW_MODEL = 'FunAudioLLM/SenseVoiceSmall';
const LARK_BASE_URL = 'https://open.feishu.cn/open-apis';
const DEFAULT_DOWNLOAD_PATH = '/tmp/douyin-download/';

// 飞书多维表配置
const LARK_APP_ID = process.env.LARK_APP_ID;
const LARK_APP_SECRET = process.env.LARK_APP_SECRET;
const LARK_APP_TOKEN = process.env.LARK_APP_TOKEN;
const LARK_TABLE_ID = process.env.LARK_TABLE_ID;

// 工具函数：Promise 版本的 http 请求
function httpRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    
    const opts = {
      method: options.method || 'GET',
      headers: { ...HEADERS, ...options.headers }
    };
    
    const req = client.request(url, opts, (res) => {
      // 处理重定向
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        httpRequest(res.headers.location, options)
          .then(resolve)
          .catch(reject);
        return;
      }
      
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ 
          statusCode: res.statusCode, 
          headers: res.headers,
          body: data,
          url: url 
        });
      });
    });
    
    req.on('error', reject);
    req.setTimeout(30000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

// 工具函数：下载文件
async function downloadFile(url, filepath, showProgress = true) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    
    const req = client.get(url, { headers: HEADERS }, (res) => {
      // 处理重定向
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        downloadFile(res.headers.location, filepath, showProgress)
          .then(resolve)
          .catch(reject);
        return;
      }
      
      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode}`));
        return;
      }
      
      const totalSize = parseInt(res.headers['content-length'] || '0', 10);
      let downloaded = 0;
      
      const writer = fs.createWriteStream(filepath);
      
      res.on('data', (chunk) => {
        downloaded += chunk.length;
        if (showProgress && totalSize > 0) {
          const progress = (downloaded / totalSize * 100).toFixed(1);
          process.stdout.write(`\r下载进度: ${progress}%`);
        }
      });
      
      res.pipe(writer);
      
      writer.on('finish', () => {
        if (showProgress) console.log(`\n文件已保存: ${filepath}`);
        resolve(filepath);
      });
      
      writer.on('error', reject);
    });
    
    req.on('error', reject);
    req.setTimeout(120000, () => {
      req.destroy();
      reject(new Error('Download timeout'));
    });
  });
}

// 工具函数：运行 ffmpeg
const FFMPEG_CMD = process.env.FFMPEG_PATH ||
  '/Users/Zhuanz/WorkBuddy/20260421110229/venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1';

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(FFMPEG_CMD, args);
    
    let stderr = '';
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    proc.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`ffmpeg exited with code ${code}: ${stderr.slice(-500)}`));
      }
    });
    
    proc.on('error', reject);
  });
}

// 解析抖音分享链接或 modal_id
async function parseShareUrl(shareText) {
  // 首先检查是否是 modal_id（16+位数字或 modal_id=xxx 格式）
  const modalIdMatch = shareText.match(/(?:modal_id[=:])?(\d{16,})/);
  if (modalIdMatch) {
    const modalId = modalIdMatch[1];
    return await getVideoInfoByModalId(modalId);
  }
  
  // 提取 URL
  const urlMatch = shareText.match(/https?:\/\/[^\s]+/);
  if (!urlMatch) {
    throw new Error('未找到有效的分享链接');
  }
  
  const shareUrl = urlMatch[0];
  
  // 第一步：访问分享链接，获取重定向后的 URL 和 video_id
  const response1 = await httpRequest(shareUrl);
  const finalUrl = response1.url;
  
  // 从 URL 中提取 video_id
  const videoIdMatch = finalUrl.match(/\/video\/(\d+)/);
  if (!videoIdMatch) {
    throw new Error('无法从URL中提取视频ID');
  }
  const videoId = videoIdMatch[1];
  
  return await getVideoInfoByModalId(videoId);
}

// 通过 modal_id 获取视频信息
async function getVideoInfoByModalId(modalId) {
  // 访问 iesdouyin.com 页面
  const pageUrl = `https://www.iesdouyin.com/share/video/${modalId}/`;
  const response = await httpRequest(pageUrl);
  
  // 从 HTML 中提取 window._ROUTER_DATA
  const match = response.body.match(/window\._ROUTER_DATA\s*=\s*(.*?)<\/script>/);
  if (!match || !match[1]) {
    throw new Error('从HTML中解析视频信息失败');
  }
  
  // 解析 JSON
  const jsonData = JSON.parse(match[1].trim());
  const loaderData = jsonData.loaderData || jsonData;
  
  let videoData;
  if (loaderData['video_(id)/page']) {
    videoData = loaderData['video_(id)/page'].videoInfoRes?.item_list?.[0];
  } else if (loaderData['note_(id)/page']) {
    videoData = loaderData['note_(id)/page'].videoInfoRes?.item_list?.[0];
  }
  
  if (!videoData) {
    throw new Error('无法从JSON中解析视频信息');
  }
  
  const videoUrl = videoData.video?.play_addr?.url_list?.[0]?.replace('playwm', 'play') ||
                   videoData.video?.download_addr?.url_list?.[0];
  const desc = videoData.desc || `douyin_${modalId}`;
  
  return {
    url: videoUrl,
    title: desc.replace(/[\\/:*?"<>|]/g, '_'),
    video_id: modalId
  };
}

// 下载视频
async function downloadVideo(videoInfo, outputDir, showProgress = true) {
  const outputPath = path.join(outputDir, `${videoInfo.video_id}.mp4`);
  
  if (showProgress) {
    console.log(`正在下载视频: ${videoInfo.title}`);
  }
  
  await downloadFile(videoInfo.url, outputPath, showProgress);
  
  return outputPath;
}

// 提取音频
async function extractAudio(videoPath, showProgress = true) {
  const audioPath = videoPath.replace(/\.mp4$/, '.mp3');
  
  if (showProgress) {
    console.log('正在提取音频...');
  }
  
  await runFfmpeg([
    '-i', videoPath,
    '-vn',
    '-acodec', 'libmp3lame',
    '-q:a', '0',
    '-y',
    audioPath
  ]);
  
  if (showProgress) {
    console.log(`音频已保存: ${audioPath}`);
  }
  
  return audioPath;
}

// 语音转文字 - 使用 curl
async function transcribeAudio(audioPath, apiKey, showProgress = true) {
  if (showProgress) {
    console.log('正在识别语音...');
  }
  
  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const proc = spawn('curl', [
      '-X', 'POST',
      SILI_FLOW_BASE_URL,
      '-H', `Authorization: Bearer ${apiKey}`,
      '-F', `file=@${audioPath}`,
      '-F', `model=${SILI_FLOW_MODEL}`
    ]);
    
    let stdout = '';
    let stderr = '';
    
    proc.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    proc.on('close', (code) => {
      if (code === 0) {
        try {
          const json = JSON.parse(stdout);
          resolve(json.text || JSON.stringify(json));
        } catch {
          resolve(stdout);
        }
      } else {
        reject(new Error(`curl failed: ${stderr}`));
      }
    });
    
    proc.on('error', reject);
  });
}

// 获取飞书 tenant_access_token
async function getLarkToken(showProgress = true) {
  if (!LARK_APP_ID || !LARK_APP_SECRET) {
    if (showProgress) {
      console.log('Warning: 飞书凭证未配置（LARK_APP_ID/LARK_APP_SECRET），跳过写入飞书');
    }
    return null;
  }

  if (showProgress) {
    console.log('正在获取飞书凭证...');
  }

  const response = await httpRequest(`${LARK_BASE_URL}/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: LARK_APP_ID, app_secret: LARK_APP_SECRET })
  });

  const data = JSON.parse(response.body);
  if (data.code !== 0) {
    throw new Error(`获取飞书Token失败: ${data.msg}`);
  }

  return data.tenant_access_token;
}

// 解析品类字符串，返回飞书API需要的格式
function parseCategory(categoryStr) {
  if (!categoryStr) return { cat1: null, cat2: null, cat3: null };
  const parts = categoryStr.split('>').map(p => p.trim()).filter(p => p);
  return {
    cat1: parts[0] ? { name: parts[0] } : null,
    cat2: parts[1] ? { name: parts[1] } : null,
    cat3: parts[2] ? { name: parts[2] } : null
  };
}

// 写入飞书多维表
async function writeToLarkBitable(videoInfo, originalText, segmentedText, viralLogic, category, token, showProgress = true) {
  if (!token || !LARK_APP_TOKEN || !LARK_TABLE_ID) {
    return false;
  }

  if (showProgress) {
    console.log('正在写入飞书多维表...');
  }

  // 品类合并为字符串：一级 > 二级 > 三级
  const categoryStr = category ? category.replace(/[>`"#*]/g, '').trim() : '';

  const fields = {
    '视频名称': videoInfo.title,
    '视频链接': {
      'text': '点击打开',
      'link': `https://v.douyin.com/${videoInfo.video_id}/`
    },
    '品类': categoryStr,
    '原始文案': originalText,
    '语义分段': segmentedText,
    '爆款逻辑解析': viralLogic || ''
  };

  const response = await httpRequest(`${LARK_BASE_URL}/bitable/v1/apps/${LARK_APP_TOKEN}/tables/${LARK_TABLE_ID}/records`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ fields })
  });

  const data = JSON.parse(response.body);
  if (data.code !== 0) {
    console.log(`写入飞书失败: ${JSON.stringify(data)}`);
    return false;
  }

  if (showProgress) {
    console.log('✓ 已写入飞书多维表');
  }
  return true;
}

// ========== 品类分类 ==========
const DOUYIN_CATEGORIES = `你是一个专业的抖音电商品类分类助手。根据用户提供的视频标题和标签，从以下抖音官方类目体系中，匹配最准确的一级类目+二级类目+三级类目。

## 抖音电商类目体系：
1. 美妆日化 > 美容护肤：水乳面霜、精华、面膜、防晒、洁面、身体护理、眼部护理
1. 美妆日化 > 彩妆香水：口红、底妆、眼妆、香水、美甲、美妆工具
1. 美妆日化 > 个护清洁：洗护发、口腔护理、卫生巾、家居清洁、香薰、洗衣清洁
1. 美妆日化 > 美容仪器：家用美容仪、脱毛仪、洁面仪、刮痧仪
2. 服饰鞋包 > 女装：上衣、裤装、裙装、大码女装、国风服饰、通勤、休闲穿搭
2. 服饰鞋包 > 男装：商务男装、休闲潮牌、卫衣夹克、内衣打底
2. 服饰鞋包 > 童装亲子：婴童装、亲子装、孕妇服饰
2. 服饰鞋包 > 鞋靴：女鞋、男鞋、运动鞋、休闲鞋、靴子、帆布鞋
2. 服饰鞋包 > 箱包：双肩包、手提包、斜挎包、钱包、旅行箱
2. 服饰鞋包 > 内衣裤袜：文胸、内裤、袜子、保暖内衣、家居服
2. 服饰鞋包 > 时尚配饰：项链、耳饰、围巾、帽子、皮带、眼镜、发饰
3. 食品酒水生鲜 > 休闲零食：坚果、糖果、卤味、膨化食品、速食、饼干、辣条
3. 食品酒水生鲜 > 粮油干货：米面油、酱油醋、调味品、杂粮、干货
3. 食品酒水生鲜 > 生鲜果蔬：新鲜水果、蔬菜、海鲜水产、肉禽蛋
3. 食品酒水生鲜 > 酒水：白酒、红酒、啤酒、黄酒
3. 食品酒水生鲜 > 茶叶冲饮：茶叶、咖啡、冲饮、养生茶
3. 食品酒水生鲜 > 滋补养生：燕窝、人参、阿胶、枸杞、药食同源滋补品
4. 母婴玩具 > 婴儿用品：纸尿裤、婴童洗护、婴儿床、出行推车
4. 母婴玩具 > 童装童鞋：婴童服饰、童鞋
4. 母婴玩具 > 奶粉辅食：奶粉、辅食营养品
4. 母婴玩具 > 孕产妇用品：孕期用品、产后护理
4. 母婴玩具 > 婴童玩具：早教玩具、益智玩具
5. 家居百货 > 居家收纳：收纳箱、置物架、收纳盒、收纳袋
5. 家居百货 > 厨房用品：锅碗瓢盆、厨房小件、餐具
5. 家居百货 > 家纺床品：四件套、被子、枕头、床垫
5. 家居百货 > 家居摆件：装饰摆件、香薰蜡烛、家居饰品
5. 家居百货 > 清洁日用：清洁工具、一次性日用品、湿巾、纸品
6. 家用电器 > 大家电：冰箱、洗衣机、空调、电视
6. 家用电器 > 生活小家电：空气炸锅、电饭煲、吹风机、取暖器、加湿器
6. 家用电器 > 厨卫电器：油烟机、燃气灶、热水器、净水器
7. 3C 数码电子 > 手机电脑：手机、平板、笔记本
7. 3C 数码电子 > 数码配件：耳机、充电器、数据线、手机壳、充电宝
7. 3C 数码电子 > 智能穿戴：智能手表、手环
7. 3C 数码电子 > 办公设备：打印机、办公耗材
7. 3C 数码电子 > 存储硬件：U盘、移动硬盘、固态硬盘SSD
7. 3C 数码电子 > 车载电子：车载用品、行车记录仪、车载充电器
8. 运动户外 > 运动健身：健身器材、运动服饰、瑜伽用品
8. 运动户外 > 露营户外：帐篷、户外装备、睡袋
8. 运动户外 > 骑行装备：自行车配件、骑行服
8. 运动户外 > 渔具：垂钓用品
9. 珠宝文玩奢品 > 黄金首饰：足金饰品、K金饰品
9. 珠宝文玩奢品 > 彩宝玉石：翡翠、珍珠、蜜蜡、钻石
9. 珠宝文玩奢品 > 文玩收藏：紫砂、木雕、钱币书画
9. 珠宝文玩奢品 > 二手奢侈品：二手箱包、二手腕表
10. 宠物用品 > 宠物食品：猫粮、狗粮
10. 宠物用品 > 宠物用品：宠物窝笼、宠物玩具
10. 宠物用品 > 宠物洗护：宠物洗护用品
11. 图书文创乐器 > 图书绘本：书籍、教辅教材、期刊
11. 图书文创乐器 > 文具文创：手账文具、文创周边
11. 图书文创乐器 > 乐器影音：乐器、音响影音
12. 汽车摩托汽配 > 汽车内饰：车品装饰、车载支架
12. 汽车摩托汽配 > 养护耗材：轮胎、电瓶、保养配件
12. 汽车摩托汽配 > 摩托配件：摩托改装件、摩托车配件
13. 家装建材五金 > 灯具照明：家居灯具、灯泡灯带
13. 家装建材五金 > 五金工具：手动工具、电动工具
13. 家装建材五金 > 家具卫浴：成品家具、卫浴洁具
14. 本地生活 > 餐饮团购、酒店旅游、休闲娱乐、汽车服务
15. 虚拟知识服务 > 线上课程、充值会员、数字服务
16. 二手闲置 > 二手数码、二手家电、闲置服饰家具

## 输出格式要求：
只返回一行，格式为：一级类目 > 二级类目 > 三级类目
不要添加任何解释，不要加引号或符号。
`;

async function classifyCategory(title, apiKey, showProgress = true) {
  if (!apiKey) apiKey = process.env.SILI_FLOW_API_KEY;
  if (!apiKey) return null;
  if (showProgress) console.log('正在识别商品品类...');

  const prompt = `${DOUYIN_CATEGORIES}\n\n## 待分类商品信息：\n标题/标签：${title}`;

  const url = 'https://api.siliconflow.cn/v1/chat/completions';
  const data = {
    model: "Qwen/Qwen2.5-7B-Instruct",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 128,
    temperature: 0.1,
    stream: false
  };

  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const proc = spawn('curl', [
      '-X', 'POST', url,
      '-H', `Authorization: Bearer ${apiKey}`,
      '-H', 'Content-Type: application/json',
      '-d', JSON.stringify(data)
    ]);
    let stdout = '', stderr = '';
    proc.stdout.on('data', (c) => { stdout += c.toString(); });
    proc.stderr.on('data', (c) => { stderr += c.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        try {
          const json = JSON.parse(stdout);
          const content = json.choices?.[0]?.message?.content?.trim();
          if (content && content.includes('>')) {
            resolve(content.replace(/[`"#*]/g, '').trim());
          } else {
            resolve(null);
          }
        } catch { resolve(null); }
      } else {
        resolve(null);
      }
    });
    proc.on('error', () => resolve(null));
  });
}

// ========== 爆款逻辑分析 ==========
async function analyzeViralLogic(originalText, segmentedText, apiKey, showProgress = true) {
  if (!apiKey) {
    apiKey = process.env.SILI_FLOW_API_KEY;
  }
  if (!apiKey) {
    if (showProgress) console.log('Warning: SILI_FLOW_API_KEY 未设置，跳过爆款逻辑分析');
    return null;
  }
  if (showProgress) console.log('正在分析爆款逻辑（9维度深度拆解）...');
  const prompt = `# 角色定位
你是专业电商带货短视频爆款拆解编导Agent，精通抖音千川原生内容逻辑、短视频流量底层、完播逻辑、带货脚本结构、口语化文案、钩子设计、卖点转化。
你的唯一任务：**用户粘贴任意短视频口播全文，你全自动专业拆解这条视频能成为爆款的全部原因**，全程按照固定专业维度分析，不发散、不废话、结构统一、编导视角专业复盘。

# 拆解固定7大维度（每次必须完整输出，缺一不可）
## 1、3秒开篇钩子分析
分析开头属于哪种钩子类型：痛点吐槽型/好奇反差型/场景共鸣型/网感口语型
判断留人能力：是否3秒抓眼球、是否避免划走、网感开场白运用、是否符合短视频流量规律。

## 2、用户痛点挖掘分析
提炼文案击中的用户真实痛点、高频刚需烦恼、人群共鸣点；
判断受众广度：是不是大众普遍会遇到的问题，共情力强弱。

## 3、痛点→产品承接流畅度
分析情绪过渡是否丝滑：痛点吐槽结束后，产品出场是否自然不生硬；
有无硬广感，用户心理接受度如何。

## 4、产品卖点转化拆解
区分原始参数 & 口播人话转化；
分析编导如何把冰冷产品参数，翻译成用户听得懂的利益、好处、体验；
卖点排布顺序、卖点密集度、有无冗余堆砌。

## 5、原生口语&网感风格分析
文案语气、生活化程度、抖音热词口头禅、素人分享感；
是否属于千川原生共情素材，而非商家硬广叫卖；情绪曲线完整度。

## 6、视频节奏&语句结构分析
整体时长节奏、句子长短、信息密度、完播友好度；
有无废话、空窗、长难句；是否每2-3秒输出新信息留住用户。

## 7、结尾转化引导话术分析
收尾目的、下单引导方式、温和种草还是高压逼单、行动指令清晰度、转化逻辑。

# 最终额外输出2项总结
## 8、本条视频爆款核心本质总结
一句话概括这条视频爆的底层原因。

## 9、可复用编导方法论（后续仿写脚本通用模板）
提炼通用可复制结构，以后写同类产品脚本直接套用。

输入内容为 【原始文案】`;

  const url = 'https://api.siliconflow.cn/v1/chat/completions';
  const data = {
    model: "Qwen/Qwen2.5-7B-Instruct",
    messages: [
      { role: "user", content: `${prompt}\n\n【原始文案】：\n${originalText}\n\n【语义分段版】：\n${segmentedText}` }
    ],
    max_tokens: 8192,
    temperature: 0.3,
    stream: false
  };

  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const proc = spawn('curl', [
      '-X', 'POST', url,
      '-H', `Authorization: Bearer ${apiKey}`,
      '-H', 'Content-Type: application/json',
      '-d', JSON.stringify(data)
    ]);
    let stdout = '', stderr = '';
    proc.stdout.on('data', (c) => { stdout += c.toString(); });
    proc.stderr.on('data', (c) => { stderr += c.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        try {
          const json = JSON.parse(stdout);
          const content = json.choices?.[0]?.message?.content;
          if (content) {
            resolve(content);
          } else {
            console.error('分析失败:', stdout.slice(0, 200));
            resolve(null);
          }
        } catch (e) {
          console.error('分析解析失败:', stdout.slice(0, 200));
          resolve(null);
        }
      } else {
        reject(new Error(`curl failed: ${stderr}`));
      }
    });
    proc.on('error', reject);
  });
}

// 语义分段 - 使用硅基流动 API
async function semanticSegment(text, apiKey, showProgress = true) {
  if (!apiKey) {
    apiKey = process.env.SILI_FLOW_API_KEY;
  }
  
  if (!apiKey) {
    if (showProgress) {
      console.log('Warning: XUNFEI_API_KEY 未设置，跳过语义分段');
    }
    return text;
  }
  
  if (showProgress) {
    console.log('正在语义分段（硅基流动）...');
  }
  
  const url = 'https://api.siliconflow.cn/v1/chat/completions';
  
  const prompt = `你是专业语音转写文本分段助手。
请对下面这段语音转写文本进行**自然语义分段**。

要求：
1. 根据语义完整性和内容逻辑进行分段
2. 每段应该是内容相对完整的句子或论述
3. 保持原文内容不变，只添加合理的段落分隔
4. 保留原文的语气词和表达特点
5. 适当添加##小标题概括每段主旨（如果内容足够长）

请直接返回分段后的文本，用markdown格式，小标题用##开头。不要添加其他说明。`;

  const data = {
    model: "Qwen/Qwen2.5-7B-Instruct",
    messages: [
      { role: "user", content: `${prompt}\n\n待分段文本：\n${text}` }
    ],
    max_tokens: 4096,
    temperature: 0.3,
    stream: false
  };

  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const proc = spawn('curl', [
      '-X', 'POST',
      url,
      '-H', `Authorization: Bearer ${apiKey}`,
      '-H', 'Content-Type: application/json',
      '-d', JSON.stringify(data)
    ]);

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    proc.stderr.on('data', (chunk) => { stderr += chunk.toString(); });

    proc.on('close', (code) => {
      if (code === 0) {
        try {
          const json = JSON.parse(stdout);
          if (json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content) {
            resolve(json.choices[0].message.content);
          } else {
            console.error('分段失败:', stdout.slice(0, 300));
            resolve(text);
          }
        } catch (e) {
          console.error('分段解析失败:', stdout.slice(0, 300));
          resolve(text);
        }
      } else {
        reject(new Error(`curl failed: ${stderr}`));
      }
    });
    proc.on('error', reject);
  });
}

// 提取文案主函数
async function extractText(shareLink, apiKey, outputDir, saveVideo = false, showProgress = true, doSegment = true, writeToFeishu = false) {
  if (!apiKey) {
    apiKey = process.env.SILI_FLOW_API_KEY;
  }
  
  if (!apiKey) {
    throw new Error('未设置 API 密钥，请设置 SILI_FLOW_API_KEY 环境变量');
  }
  
  if (showProgress) {
    console.log('正在解析抖音分享链接...');
  }
  
  const videoInfo = await parseShareUrl(shareLink);
  
  if (showProgress) {
    console.log('正在下载视频...');
  }
  
  const videoPath = await downloadVideo(videoInfo, outputDir, showProgress);
  
  if (showProgress) {
    console.log('正在提取音频...');
  }
  
  const audioPath = await extractAudio(videoPath, showProgress);
  
  if (showProgress) {
    console.log('正在从音频中提取文本...');
  }
  
  let textContent = await transcribeAudio(audioPath, apiKey, showProgress);
  const originalText = textContent; // 保存原始文案
  
  // 语义分段
  if (doSegment) {
    textContent = await semanticSegment(textContent, null, showProgress);
  }

  // 爆款逻辑分析（硅基流动）
  let viralLogic = null;
  try {
    viralLogic = await analyzeViralLogic(originalText, textContent, null, showProgress);
  } catch (err) {
    if (showProgress) console.log('爆款逻辑分析失败:', err.message);
  }

  // 品类分类（硅基流动）
  let category = null;
  if (writeToFeishu) {
    try {
      category = await classifyCategory(videoInfo.title, null, showProgress);
    } catch (err) {
      if (showProgress) console.log('品类识别失败:', err.message);
    }
  }

  // 保存文案
  const outputPath = path.join(outputDir, videoInfo.video_id, 'transcript.md');
  const outputFolder = path.dirname(outputPath);
  
  fs.mkdirSync(outputFolder, { recursive: true });
  
  const markdown = `# ${videoInfo.title}

| 属性 | 值 |
|------|-----|
| 视频ID | \`${videoInfo.video_id}\` |
| 提取时间 | ${new Date().toLocaleString('zh-CN')} |
| ${doSegment ? '分段模型 | 讯飞星火 4.0Ultra |' : ''}
| 下载链接 | [点击下载](${videoInfo.url}) |

---

## 原始文案（整段）

${originalText}

${doSegment ? `---

## 语义分段版

${textContent.replace(/^```markdown\s*/g, '').replace(/^```\s*$/gm, '').trim()}
` : ''}

${category ? `
| 属性 | 值 |
|------|-----|
| 品类 | ${category} |
` : ''}

${viralLogic ? `---

## 爆款逻辑解析（9维度深度拆解）

${viralLogic}
` : ''}
`;
  
  fs.writeFileSync(outputPath, markdown, 'utf-8');
  
  if (showProgress) {
    console.log(`文案已保存到: ${outputPath}`);
  }
  
  // 清理临时文件
  if (!saveVideo) {
    try { fs.unlinkSync(videoPath); } catch {}
  }
  try { fs.unlinkSync(audioPath); } catch {}
  
  // 写入飞书多维表
  if (writeToFeishu) {
    try {
      const larkToken = await getLarkToken(showProgress);
      if (larkToken) {
        const cleanSegmented = textContent.replace(/^```markdown\s*/g, '').replace(/^```\s*$/gm, '').trim();
        await writeToLarkBitable(videoInfo, originalText, cleanSegmented, viralLogic, category, larkToken, showProgress);
      }
    } catch (err) {
      if (showProgress) {
        console.log(`写入飞书失败: ${err.message}`);
      }
    }
  }

  return {
    video_info: videoInfo,
    text: textContent,
    viral_logic: viralLogic,
    category: category,
    output_path: outputPath
  };
}

// 主入口
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const shareLink = args[1];
  
  if (!command || !shareLink) {
    console.log(`
抖音无水印视频下载和文案提取工具

用法:
  node douyin.js info <分享链接|modal_id>              - 获取视频信息
  node douyin.js download <链接|modal_id> -o <目录>     - 下载视频
  node douyin.js extract <链接|modal_id> -o <目录>      - 提取文案
  node douyin.js extract <链接> --no-segment           - 提取文案（不语义分段）
  node douyin.js extract <链接> --feishu                - 提取文案并写入飞书多维表

支持输入:
  - 抖音分享链接: https://v.douyin.com/xxxxx
  - modal_id: 7597329042169220398
  - modal_id=xxx 格式

环境变量:
  SILI_FLOW_API_KEY   - 硅基流动 API（文案提取）
  XUNFEI_API_KEY      - 讯飞星火 API（语义分段）
  LARK_APP_ID         - 飞书应用 App ID（写入多维表）
  LARK_APP_SECRET     - 飞书应用 App Secret
  LARK_APP_TOKEN      - 多维表 App Token
  LARK_TABLE_ID       - 多维表 Table ID

`);
    process.exit(1);
  }
  
  // 解析参数
  let outputDir = DEFAULT_DOWNLOAD_PATH;
  let saveVideo = false;
  let doSegment = true;
  let writeToFeishu = false;
  
  for (let i = 2; i < args.length; i++) {
    if (args[i] === '-o' && args[i + 1]) {
      outputDir = args[i + 1];
      i++;
    } else if (args[i] === '-v' || args[i] === '--save-video') {
      saveVideo = true;
    } else if (args[i] === '--segment') {
      doSegment = true;
    } else if (args[i] === '--no-segment') {
      doSegment = false;
    } else if (args[i] === '--feishu') {
      writeToFeishu = true;
    }
  }
  
  try {
    if (command === 'info') {
      const info = await parseShareUrl(shareLink);
      console.log('\n' + '='.repeat(50));
      console.log('视频信息:');
      console.log('='.repeat(50));
      console.log(`视频ID: ${info.video_id}`);
      console.log(`标题: ${info.title}`);
      console.log(`下载链接: ${info.url}`);
      console.log('='.repeat(50));
      
    } else if (command === 'download') {
      const videoInfo = await parseShareUrl(shareLink);
      const videoPath = await downloadVideo(videoInfo, outputDir);
      console.log(`\n视频已保存到: ${videoPath}`);
      
    } else if (command === 'extract') {
      const result = await extractText(shareLink, null, outputDir, saveVideo, true, doSegment, writeToFeishu);
      console.log('\n' + '='.repeat(50));
      console.log('提取完成!');
      console.log('='.repeat(50));
      console.log(`视频ID: ${result.video_info.video_id}`);
      console.log(`标题: ${result.video_info.title}`);
      console.log(`保存位置: ${result.output_path}`);
      console.log('='.repeat(50));
      console.log('\n文案内容:\n');
      console.log(result.text.slice(0, 500) + '...');
      if (result.category) {
        const parts = result.category.split('>').map(p => p.trim());
        console.log('\n品类：' + result.category);
        console.log(`  一级: ${parts[0] || '-'}  二级: ${parts[1] || '-'}  三级: ${parts[2] || '-'}`);
      }
      if (result.viral_logic) {
        console.log('\n' + '='.repeat(50));
        console.log('爆款逻辑解析（9维度）：\n');
        console.log(result.viral_logic.slice(0, 800) + (result.viral_logic.length > 800 ? '...' : ''));
      }
      console.log('\n' + '='.repeat(50));
    }

  } catch (error) {
    console.error(`错误: ${error.message}`);
    process.exit(1);
  }
}

main();
