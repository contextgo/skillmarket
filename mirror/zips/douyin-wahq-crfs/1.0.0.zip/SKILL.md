---
name: 抖音文案获取_存入飞书
description: 抖音视频文案提取工具，支持从抖音视频/图文链接中提取语音文案、进行语义分段，并自动写入飞书多维表。 触发词：抖音文案、抖音链接、提取文案、douyin、抖音视频、v.douyin.com、www.douyin.com、 爆款视频分析、视频脚本提取、写入飞书、存入多维表、分析视频
  抖音视频文案提取工具，支持从抖音视频/图文链接中提取语音文案、进行语义分段，并自动写入飞书多维表。
  触发词：抖音文案、抖音链接、提取文案、douyin、抖音视频、v.douyin.com、www.douyin.com、
  爆款视频分析、视频脚本提取、写入飞书、存入多维表、分析视频
metadata:
  openclaw:
    emoji: "🎬"
    requires:
      env: [SILI_FLOW_API_KEY, LARK_APP_ID, LARK_APP_SECRET, LARK_APP_TOKEN, LARK_TABLE_ID]
allowed-tools: 
disable: false
---

# 抖音文案获取_存入飞书 Skill

从抖音视频中自动提取语音文案、进行语义分段，并写入飞书多维表。

## 功能

- 🔗 支持抖音短链接（`v.douyin.com`）、完整链接（`www.douyin.com/video/`）、图文笔记（`/note/`）
- 🎙️ 语音转写（硅基流动 SenseVoiceSmall）
- ✂️ 语义分段（硅基流动 Qwen/Qwen2.5-7B-Instruct）
- 🏷️ **品类自动识别**（AI 根据标题匹配抖音官方三级类目）
- 🏆 **爆款逻辑分析（9维度深度拆解）**（硅基流动 Qwen）
- 📊 自动写入飞书多维表

## 环境变量

| 变量 | 说明 |
|------|------|
| `SILI_FLOW_API_KEY` | 硅基流动 API（语音转写 + 语义分段，复用同一个 key） |
| `LARK_APP_ID` | 飞书应用 App ID |
| `LARK_APP_SECRET` | 飞书应用 App Secret |
| `LARK_APP_TOKEN` | 多维表 App Token |
| `LARK_TABLE_ID` | 多维表 Table ID |

> ✅ 以上环境变量已持久化到 `~/.zshrc`，无需每次手动传入。

## 使用方法

### 标准用法（提取文案 + 语义分段 + 写入飞书）

```bash
node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_存入飞书/douyin.js extract "抖音链接" --feishu
```

### 只提取文案（不写飞书）

```bash
node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_存入飞书/douyin.js extract "抖音链接"
```

### 跳过语义分段

```bash
node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_存入飞书/douyin.js extract "抖音链接" --no-segment
```

### 获取视频基本信息

```bash
node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_存入飞书/douyin.js info "抖音链接"
```

## AI 调用指引

当用户发来含有抖音链接的消息时，直接执行：

```bash
source ~/.zshrc && node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_存入飞书/douyin.js extract "<链接>" --feishu
```

- 从用户消息中提取抖音链接（支持 `v.douyin.com`、`www.douyin.com/video/`、`www.douyin.com/note/` 格式）
- 默认总是加 `--feishu` 写入飞书多维表
- 若链接是图文笔记（`/note/`），用 `info` 命令获取文字内容后手动写入飞书
- 执行流程：下载视频 → 提取音频 → 语音转文字 → 语义分段 → **品类AI识别** → **爆款逻辑9维度分析** → 写入飞书

## 飞书多维表字段结构（6个字段）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 视频名称 | 文本（主字段） | 视频标题 |
| 视频链接 | 超链接 | 抖音视频链接，格式为 `{text: "点击打开", link: "https://v.douyin.com/xxx"}` |
| 品类 | 文本 | AI 自动识别，格式为 `一级 > 二级 > 三级` |
| 原始文案 | 长文本 | 语音转写原文 |
| 语义分段 | 长文本 | 分段后的结构化文案 |
| 爆款逻辑解析 | 长文本 | 9维度深度拆解（钩子/痛点/卖点/节奏/话术等） |

## 技术细节

- **FFmpeg 路径**：`/Users/Zhuanz/WorkBuddy/20260421110229/venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1`（已硬编码）
- **飞书 API 端点**：`/bitable/v1/apps/{app_token}/tables/{table_id}/records`（注意是 `/bitable/v1/apps/` 不是 `/base/v3/bases/`）
- **视频链接格式**：必须是对象 `{text: "点击打开", link: "https://v.douyin.com/xxx"}`，纯文本会报错
- 语义分段使用 `SILI_FLOW_API_KEY` + `Qwen/Qwen2.5-7B-Instruct`
- 爆款逻辑分析使用 `SILI_FLOW_API_KEY` + `Qwen/Qwen2.5-7B-Instruct`（max_tokens=8192）
- 品类分类使用 `SILI_FLOW_API_KEY` + `Qwen/Qwen2.5-7B-Instruct`（max_tokens=128，temperature=0.1）
