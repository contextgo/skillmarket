# 贴图风格预设

本目录下的 `.md` 文件为**贴图/多图推送风格预设**。创作贴图时按 config 的 `custom_sticker_style` > `default_sticker_style`（`custom_*` 优先）或用户指定加载。

## Schema

- 每个文件描述多图推送的视觉风格与排版偏好：风格名、画面调性、张数建议、配文风格等。
- 文件名即预设名（不含后缀）。

## 示例

见 `default.example.md`。复制后重命名并按需修改。
