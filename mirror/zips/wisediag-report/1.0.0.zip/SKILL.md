---
name: wisediag-report
description: "Medical Report Interpretation — Interpret medical report images and highlight abnormal indicators via WiseDiag AI. Usage: Provide a report image URL and say Use WiseDiag Report to interpret this."
registry:
  homepage: https://github.com/wisediag/WiseDiag-Report
  author: wisediag
  credentials:
    required: true
    env_vars:
      - WISEDIAG_API_KEY
---

# ⚠️ Privacy Notice

**Please read before installing:**

This tool transmits image URLs **to WiseDiag cloud servers** for AI analysis.

**Do not upload images containing sensitive or private content** unless:
- You trust WiseDiag's data handling policy
- You accept that the image content will be transmitted to and processed remotely

**The output of this tool is for reference only and does not constitute medical diagnosis. Please consult a qualified healthcare professional for any health concerns.**

---

# WiseDiag Medical Report Interpretation (OpenClaw Skill)

Upload photos of physical medical reports (blood tests, urine tests, imaging reports, etc.) and let WiseDiag AI automatically recognize the text, parse key indicators, highlight abnormal values, and provide health advice.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- Upload up to 5 report images per request (JPG, JPEG, PNG)
- AI automatically recognizes test items, result values, reference ranges, and abnormal indicators
- Results are automatically saved as a Markdown file

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Configuration (Required)

**Get your API Key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
# Temporary (current terminal session only)
export WISEDIAG_API_KEY=your_api_key_here

# Permanent (add to ~/.zshrc or ~/.bashrc)
echo 'export WISEDIAG_API_KEY=your_api_key_here' >> ~/.zshrc
source ~/.zshrc
```

## Usage (Step-by-Step)

**Do not call any API or HTTP endpoints directly — use only the script below.**

Step 1: Set your API Key (if not already set):

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

Step 2: Run the script with a report image URL:

```bash
cd scripts

# Basic usage: single report image
python3 report.py --image "https://example.com/report.jpg"

# Ask a specific question
python3 report.py --image "https://example.com/report.jpg" --question "请解读报告中的异常指标"

# Multiple images (e.g. multi-page report, max 5)
python3 report.py --image "https://example.com/report_p1.jpg" --image "https://example.com/report_p2.jpg"

# Specify output filename
python3 report.py --image "https://example.com/report.jpg" -n "bloodtest_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Report/{name}.md` — no manual saving needed.

## Parameters

| Parameter | Description |
|-----------|-------------|
| `--image` | Public URL of the report image (required; repeat up to 5 times) |
| `--question` | Question to ask (default: interpret abnormal indicators and provide advice) |
| `-n, --name` | Output filename (without extension) |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseDiag-Report) |

## FAQ

**"WISEDIAG_API_KEY is not set" error:**
Verify the environment variable is set correctly by running `echo $WISEDIAG_API_KEY`.

**"Authentication failed" error:**
Your API Key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to check or regenerate it.

**Image not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format. Photos should be clear and well-lit for best results.

## Data Privacy

Image URLs are transmitted to WiseDiag cloud servers for processing. Image content is not permanently stored. Results are returned directly to you.

## ⚠️ Disclaimer

The output of this tool is for reference only and does not constitute medical diagnosis or treatment advice. Always consult a qualified healthcare professional for medical decisions.

## License

MIT
