#!/usr/bin/env python3
"""
WiseDiag Report CLI — Interpret medical report images via WiseDiag AI

Usage:
    export WISEDIAG_API_KEY=your_api_key
    python3 report.py --image "https://example.com/report.jpg"
    python3 report.py --image "https://example.com/report.jpg" --question "请解读报告中的异常指标"
    python3 report.py --image "https://example.com/r1.jpg" --image "https://example.com/r2.jpg"

Get API key: https://console.wisediag.com/apiKeyManage
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_SERVICE_URL = "https://openapi.wisediag.com"
REQUEST_TIMEOUT     = 180   # seconds — reports can be long


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_api_key() -> str:
    key = os.environ.get("WISEDIAG_API_KEY", "")
    if not key:
        print("""
[!] Error: WISEDIAG_API_KEY is not set.

    export WISEDIAG_API_KEY=your_api_key

Get a key at: https://console.wisediag.com/apiKeyManage
""")
        raise SystemExit(1)
    return key


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------

def interpret_report(
    image_urls: list[str],
    question:   str        = "请帮我解读这份报告单，重点说明异常指标及建议。",
    output_dir: str | None = None,
    name:       str | None = None,
) -> bool:
    """Call WiseDiag photo_read API and stream results to stdout."""

    key = _get_api_key()

    url     = f"{DEFAULT_SERVICE_URL}/v1/medicine/photo_read"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type":  "application/json",
    }

    ts = int(time.time() * 1000)

    payload: dict = {
        "image_list":        image_urls,
        "messages":          [{"role": "user", "content": question}],
        "topic_id":          f"report_{ts}",
        "request_id":        str(ts),
        "use_thinking":      1,
        "use_health_record": 0,
    }

    print(f"[*] Images    : {', '.join(image_urls)}")
    print(f"[*] Question  : {question}")
    print()

    content_text    = ""
    reasoning_text  = ""
    vl_result       = None
    in_thinking     = False

    try:
        with requests.post(
            url, headers=headers, json=payload,
            stream=True, timeout=REQUEST_TIMEOUT,
        ) as resp:

            if resp.status_code == 401:
                print("[!] Authentication failed. Check your API key.")
                return False

            if resp.status_code != 200:
                print(f"[!] Request failed: HTTP {resp.status_code}")
                print(resp.text[:300])
                return False

            for line in resp.iter_lines():
                if not line:
                    continue
                decoded = line.decode("utf-8")
                raw     = decoded.split("data:")[-1].strip()

                if raw == "[DONE]":
                    break

                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                t = data.get("type", "")

                if t == "reasoning_content":
                    chunk = data.get("content") or ""
                    if chunk:
                        if not in_thinking:
                            print("[Thinking] ", end="", flush=True)
                            in_thinking = True
                        print(chunk, end="", flush=True)
                        reasoning_text += chunk

                elif t == "content":
                    if in_thinking:
                        print()  # close thinking line
                        print()
                        in_thinking = False
                    chunk = data.get("content") or ""
                    print(chunk, end="", flush=True)
                    content_text += chunk

                elif t == "vl_complete":
                    vl_result = data.get("data")

    except requests.Timeout:
        print("\n[!] Request timed out.")
        return False

    except requests.ConnectionError as e:
        print(f"\n[!] Connection error: {e}")
        return False

    print()  # newline after streaming output

    # -----------------------------------------------------------------------
    # Save result to Markdown
    # -----------------------------------------------------------------------
    if output_dir is None:
        out_dir = Path.home() / ".openclaw" / "workspace" / "WiseDiag-Report"
    else:
        out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    stem     = name or f"report_{int(time.time())}"
    out_path = out_dir / f"{stem}.md"

    md  = f"# Medical Report Interpretation\n\n"
    for i, url_item in enumerate(image_urls, 1):
        md += f"**Image {i}:** {url_item}\n\n"
    md += f"**Question:** {question}\n\n"

    if reasoning_text:
        md += f"## Thinking Process\n\n{reasoning_text}\n\n"

    md += f"## Interpretation\n\n{content_text}\n"

    if vl_result:
        md += (
            f"\n## OCR / Detection Details\n\n"
            f"```json\n{json.dumps(vl_result, ensure_ascii=False, indent=2)}\n```\n"
        )

    out_path.write_text(md, encoding="utf-8")
    print(f"\n[+] Result saved: {out_path}")
    return True


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="WiseDiag Report CLI — Interpret medical report images via WiseDiag AI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 report.py --image "https://example.com/report.jpg"
  python3 report.py --image "https://example.com/report.jpg" --question "请解读异常指标"
  python3 report.py --image "https://example.com/r1.jpg" --image "https://example.com/r2.jpg"
  python3 report.py --image "https://example.com/report.jpg" -n "bloodtest_20260324"
        """,
    )

    parser.add_argument(
        "--image", required=True, metavar="URL", action="append", dest="images",
        help="Public URL of the report image (required; repeat for multiple images, max 5)",
    )
    parser.add_argument(
        "--question", default="请帮我解读这份报告单，重点说明异常指标及建议。",
        help="Question to ask about the report",
    )
    parser.add_argument(
        "-o", "--output",
        help="Output directory (default: ~/.openclaw/workspace/WiseDiag-Report)",
    )
    parser.add_argument(
        "-n", "--name",
        help="Output filename stem (without extension)",
    )

    args = parser.parse_args()

    if len(args.images) > 5:
        print("[!] Error: maximum 5 images per request.")
        sys.exit(1)

    success = interpret_report(
        image_urls = args.images,
        question   = args.question,
        output_dir = args.output,
        name       = args.name,
    )
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
