# WiseDiag Medical Report Interpretation

Upload photos of medical reports and let WiseDiag AI interpret them — identifying test items, result values, reference ranges, abnormal indicators, and providing health advice.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- Upload up to 5 report images per request (blood tests, urine tests, imaging reports, etc.)
- AI automatically recognizes test items, result values, and abnormal indicators
- Streaming output — results appear in real time
- Results saved as Markdown files automatically

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Setup (Required)

**Get your API key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
# Temporary (current terminal session)
export WISEDIAG_API_KEY=your_api_key_here

# Permanent (add to ~/.zshrc or ~/.bashrc)
echo 'export WISEDIAG_API_KEY=your_api_key_here' >> ~/.zshrc
source ~/.zshrc
```

## Quick Start

```bash
cd scripts

# Interpret a single report image
python3 report.py --image "https://example.com/blood_test.jpg"

# Ask a specific question about the report
python3 report.py --image "https://example.com/report.jpg" --question "Which indicators are abnormal? What should I pay attention to?"

# Interpret a multi-page report (up to 5 images)
python3 report.py \
  --image "https://example.com/report_p1.jpg" \
  --image "https://example.com/report_p2.jpg"

# Save result with a custom filename
python3 report.py --image "https://example.com/report.jpg" -n "checkup_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Report/{name}.md`.

## Parameters

| Parameter | Description |
|-----------|-------------|
| `--image` | Public URL of the report image (required; repeat up to 5 times for multi-page reports) |
| `--question` | Question to ask about the report (default: interpret abnormal indicators and provide advice) |
| `-n, --name` | Output filename stem (without `.md` extension) |
| `-o, --output` | Output directory (default: `~/.openclaw/workspace/WiseDiag-Report`) |

## Troubleshooting

**"WISEDIAG_API_KEY is not set" error:**
Make sure you've set the environment variable correctly. Run `echo $WISEDIAG_API_KEY` to check.

**"Authentication failed" error:**
Your API key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to check or regenerate your key.

**Image not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format. Photos should be clear and well-lit for best results.

## ⚠️ Disclaimer

The output of this tool is for reference only and does not constitute medical diagnosis or treatment advice. Always consult a qualified healthcare professional for medical decisions.

## Data Privacy

Image URLs are transmitted to WiseDiag cloud servers for processing. Image content is not permanently stored. See WiseDiag's privacy policy for details.

## License

MIT
