---
description: Toggle features instantly without deploying code. A/B test variants, gradual rollouts from 1% to 100%, and emergency kill switches for AI agents.
keywords: feature flag, feature toggle, A/B testing, gradual rollout, canary release, kill switch, percentage rollout, remote config
name: feature-flag-manager
triggers: toggle feature, enable feature, disable feature, A/B test, rollout percentage, kill switch, feature flag
---

# feature-flag-manager

> Deploy features safely. Toggle on/off instantly, run A/B tests, and roll out gradually from 1% to 100% — no code redeployment needed.

## What It Does

Control feature visibility in real-time without pushing new code:

- **Instant toggle** — Enable/disable features with one command
- **Gradual rollout** — Start with 1% of users, increase slowly
- **A/B testing** — Test variants against each other with automatic traffic splitting
- **Kill switch** — Emergency off button for buggy features
- **User targeting** — Show features to specific users or groups

---

## Quick Start

```bash
# 1. Create a feature flag
node flag.js create dark-mode --description "Dark theme UI"

# 2. Enable for 10% of users
node flag.js update dark-mode --percentage 10

# 3. Check if enabled for current user
node flag.js enabled dark-mode --user-id alice
# → true (or false based on percentage)

# 4. Gradually increase to 100%
node flag.js update dark-mode --percentage 50
node flag.js update dark-mode --percentage 100
```

---

## Common Use Cases

### 🚀 Safe Feature Releases
```bash
# Instead of: deploy → pray → rollback
# Do this: deploy (disabled) → enable 5% → monitor → 25% → 100%

node flag.js create new-checkout-flow
node flag.js update new-checkout-flow --percentage 5
# Monitor error rates...
node flag.js update new-checkout-flow --percentage 100
```

### 🧪 A/B Test Pricing Pages
```bash
# Test 3 variants: 50% see current, 25% see v1, 25% see v2
node flag.js create pricing-test --variants control,v1,v2 --weights 50,25,25

# In your code, get variant for each user
node flag.js variant pricing-test --user-id user123
# → "v1"
```

### 🚨 Emergency Kill Switch
```bash
# New feature causing errors? Disable instantly without redeploying
node flag.js toggle broken-feature --off
# Fixed? Re-enable
node flag.js toggle broken-feature --on
```

---

## All Commands

| Command | Purpose |
|---------|---------|
| `create <name>` | Create a new flag |
| `toggle <name>` | Enable/disable instantly |
| `update <name> --percentage N` | Set rollout percentage (0-100) |
| `enabled <name>` | Check if enabled for user |
| `variant <name>` | Get A/B variant for user |
| `list` | Show all flags and status |
| `history <name>` | See change history |
| `export` | Export config for backup |

---

## Configuration

Flags stored in `.featureflags/config.json`:

```json
{
  "flags": {
    "dark-mode": {
      "enabled": true,
      "percentage": 25,
      "description": "Dark theme support"
    },
    "pricing-test": {
      "enabled": true,
      "percentage": 100,
      "variants": ["control", "v1", "v2"],
      "weights": [50, 25, 25]
    }
  }
}
```

---

## Integration Example

```javascript
const flag = require('./flag.js');

async function renderDashboard(userId) {
  // Check if new dashboard is enabled for this user
  if (await flag.enabled('new-dashboard', { userId })) {
    return renderNewDashboard();
  }
  return renderLegacyDashboard();
}
```
