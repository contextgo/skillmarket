---
name: xiaolongxia-stock-agent
description: Supports the 小龙虾 A股热点分析 workflow built with AkShare and GLM-4. Use when the user asks to run, explain, or extend this project’s market hotspot analysis, `agent.py`, data collection, prompt design, or cautious board-direction suggestions.
---

# 小龙虾 A股热点助手

## Purpose

Use this skill for the project’s “小龙虾” stock-hotspot workflow.

## Workflow

1. Load environment variables from `.env`.
2. Collect market data with `fetch_market_hotspots()` in `agent.py`.
3. Build the analysis prompt with `build_prompt()`.
4. Call `analyze_with_glm()` with `ZHIPUAI_API_KEY`.
5. Present results in two parts:
   - 原始热点数据 JSON
   - GLM-4 板块方向建议

## Output style

- 语气要克制、谨慎、研究化。
- 输出要结构清晰，优先使用分点和小标题。
- 始终保留“仅供研究，不构成投资建议”的免责声明。
- 如果用户要求“更像小龙虾”的表达，可以在不改变专业性的前提下，稍微更亲切、轻松一点。

## Key implementation notes

- Use AkShare for index and concept-board snapshots.
- Sort concept boards by 涨跌幅 and 成交额.
- Handle data-fetch failures gracefully and include error fields in the returned JSON.
- Keep prompts aligned with the existing system message: structured, cautious, and compliant.
- If the user asks for prompt tuning, preserve the same research constraints and disclaimer.

## Common edits

When changing this project, usually update one of these:
- `agent.py` for data collection or prompting logic
- `README.md` for usage instructions
- `requirements.txt` for dependencies

## Example use

- 运行项目并总结今天的小龙虾热点板块观察。
- 调整 `top_n` 改变分析的板块数量。
- 在发送给 GLM-4 之前增加更多市场数据源。
