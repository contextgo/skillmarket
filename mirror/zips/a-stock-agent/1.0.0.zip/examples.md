# examples

## Example 1: Run the full 小龙虾 analysis workflow

User asks:

> 帮我跑一下这个小龙虾项目，看看今天热点板块有哪些。

Assistant should:

1. Use `agent.py` as the entry point.
2. Load `.env` and verify `ZHIPUAI_API_KEY` exists.
3. Fetch market data with `fetch_market_hotspots()`.
4. Call `analyze_with_glm()`.
5. Return output in two sections:
   - 原始热点数据 JSON
   - GLM-4 板块方向建议
6. Keep the tone cautious and include the research-only disclaimer.

Expected behavior:
- Do not invent market data.
- If an API call fails, mention the error field from the returned JSON.
- Keep recommendations limited to 3 board directions.

---

## Example 2: Explain how the project works

User asks:

> 这个小龙虾项目是怎么分析热点板块的？

Assistant should explain the workflow in this order:

1. `ak.stock_zh_index_spot_em()` gets the main index snapshot.
2. `ak.stock_board_concept_name_em()` gets concept-board data.
3. Boards are sorted by `涨跌幅` and `成交额`.
4. A prompt is built with `build_prompt()`.
5. GLM-4 produces a structured suggestion.

Expected behavior:
- Mention the data is used for research only.
- Emphasize the output is cautious and not a trading signal.

---

## Example 3: Update the prompt without changing the safety rules

User asks:

> 帮我把提示词改得更像“小龙虾”一点，但还是要稳一点。

Assistant should:

1. Keep the same safety constraints.
2. Preserve these requirements:
   - 大盘情绪简短判断
   - 3 个板块方向
   - 每个方向包含理由、风险点、交易风格
   - 今日不建议追高的情形 2 条
   - 免责声明
3. Adjust wording to be a little more approachable, but still professional.

Expected behavior:
- Do not remove the disclaimer.
- Do not make the model sound overly bullish.
- Avoid slang that weakens research credibility.

---

## Example 4: Change the number of tracked boards

User asks:

> 我想把板块分析从 10 个改成 20 个。

Assistant should:

1. Update the `top_n` default or call site in `agent.py`.
2. Confirm that the sorting rule stays the same:
   - first by `涨跌幅`
   - then by `成交额`
3. Keep downstream prompt structure unchanged.

Expected behavior:
- Do not change the data schema unless explicitly requested.
- Note that more boards may increase noise in the analysis.

---

## Example 5: Handle missing API key

User asks:

> 我运行报错了，说找不到 ZHIPUAI_API_KEY。

Assistant should:

1. Explain that `.env` must contain `ZHIPUAI_API_KEY`.
2. Remind the user to copy `.env.example` to `.env`.
3. Mention that `main()` raises a clear error when the key is missing.

Expected behavior:
- Keep the explanation short and actionable.
- Suggest verifying the environment file before changing code.

---

## Example 6: Add more data sources

User asks:

> 我想在这个项目里再加行业板块或资金流向数据。

Assistant should:

1. Extend `fetch_market_hotspots()`.
2. Add the new data into the returned JSON.
3. Update `build_prompt()` so GLM-4 knows how to use the new fields.
4. Preserve error handling and the research disclaimer.

Expected behavior:
- Keep the output JSON structured.
- Mention any new fields explicitly in the prompt.
- Avoid making the prompt too long or noisy.

---

## Example 7: Summarize results in a stable format

When the user asks for a final summary, use this structure:

1. **大盘情绪**：一句话判断
2. **重点板块**：3 条，每条包含
   - 推荐理由
   - 风险点
   - 交易风格
3. **不建议追高的情形**：2 条
4. **免责声明**：仅供研究，不构成投资建议

Expected behavior:
- Keep the format consistent across runs.
- Prefer short paragraphs and bullet points.
- Do not introduce extra investment terminology unless needed.
