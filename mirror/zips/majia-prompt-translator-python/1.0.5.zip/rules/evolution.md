# 自主进化规则（平台版伪代码模式）

马甲系统自主进化引擎。本模块仅在主流程 Step 7.5 触发（置信度门卫 PASS 后、输出结果前），不影响正常生成流程。

---

## 核心定位

SKILL版没有本地存储，进化靠**对话约定**实现：
- 用户通过固定句式"告诉"系统新偏好
- 系统通过上下文**推测**用户习惯
- 用伪代码流程呈现，不依赖代码执行

---

## 能力边界

平台版可用：上下文记忆读写（若平台支持）、对话历史读取
平台版不可用：本地文件、数据库、代码执行
进化效果：有进化≈75%，无进化≈60%

---

## 进化数据读取（每次对话开始时）

```
// ========== 伪代码1：读取用户偏好 ==========
PROCEDURE load_user_profile():
    
    // 尝试从平台记忆读取
    IF platform_has_memory("majia_profile"):
        profile ← platform_read("majia_profile")
        PRINT "检测到历史偏好，融入本次生成"
        RETURN profile
    
    // 无记忆时，从对话历史推测
    ELSE IF conversation_has_history():
        profile ← infer_from_history(conversation_history)
        IF profile NOT_EMPTY:
            PRINT "从历史推测偏好：" + profile.summary
        RETURN profile
    
    RETURN empty_profile()
```

**融入方式**：
- 风格偏好 → 自动填入生成字段
- 避免词 → 加入负向约束
- 常用领域 → M1调研时默认推荐

---

## 进化信号捕获（Step 7.5）

```
// ========== 伪代码2：捕获进化信号 ==========
PROCEDURE capture_signal(user_input, conversation_context):

    // 显式正向：用户明确表达满意
    IF match_any(user_input, [
        "记住", "保存", "收藏", "很好", "完美", 
        "就是这个", "就这个", "用这个", "出吧"
    ]):
        PRINT "→ 触发：存储偏好 + 存储案例"
        RETURN STORE_PREFERENCES + STORE_CASE

    // 显式负向：用户明确要求修改
    IF match_any(user_input, [
        "不对", "不是", "完全不是", "重来", 
        "改掉", "删掉", "不要这个"
    ]):
        PRINT "→ 触发：主动遗忘冲突偏好"
        RETURN REMOVE_CONFLICT

    // 隐式正向：用户沉默接受（未提修改+有肯定词）
    IF user_accepted_without_modification(conversation_context):
        IF match_any(user_input, ["谢谢", "好", "可以", "行", "发出去了"]):
            PRINT "→ 触发：存储成功案例"
            RETURN STORE_CASE
    
    // 无信号
    RETURN NO_SIGNAL
```

---

## 进化动作执行（输出进化标记）

```
// ========== 伪代码3：执行进化动作 ==========
PROCEDURE execute_evolution(signal, generation_context):

    SWITCH signal:

        CASE STORE_PREFERENCES:
            prefs ← extract_preferences(generation_context)
            PRINT ""
            PRINT "已记住你的偏好"
            PRINT ""
            RETURN  // 无需输出标记，用户可见即可

        CASE STORE_CASE:
            pattern ← extract_success_pattern(generation_context)
            PRINT ""
            PRINT "成功案例已收录，越用越懂你"
            PRINT ""
            RETURN  // 平台版仅展示，不写文件

        CASE REMOVE_CONFLICT:
            conflict ← extract_conflict(generation_context)
            PRINT ""
            PRINT "已记录，下次避免"
            PRINT ""
            RETURN  // 用户驱动式遗忘

        DEFAULT:
            RETURN  // 无信号，静默跳过
```

**平台版不输出内部标记**（用户可见则影响体验）。进化效果通过后续对话自然体现。

---

## 用户对话约定（替代文件操作）

用户可通过以下方式"提交"进化数据：

```
约定1：提交新偏好
    句式：「偏好：[描述]」「记住：[内容]」
    示例：「偏好：简洁专业，少用感叹号」
    示例：「记住我喜欢这个表达方式」

约定2：提交成功案例
    句式：「这个很好，记住」
    系统自动捕获上下文作为案例

约定3：主动遗忘
    句式：「忘掉XX偏好」「不要XX风格」
    示例：「忘掉上次的口语风格」「不要这种写法」
```

---

## M1调研中的进化融入

```
// ========== 伪代码4：调研时体现进化 ==========
PROCEDURE research_with_evolution(user_input):

    profile ← load_user_profile()
    
    // 优先推荐常用领域
    IF profile.has_frequent_domain():
        suggestions ← prepend_frequent_domain(
            get_default_suggestions(), 
            profile.frequent_domain
        )
    ELSE:
        suggestions ← get_default_suggestions()
    
    // 融入已知偏好作为选项
    IF profile.has_preferred_style():
        suggestions ← mark_as_recommended(
            suggestions, 
            profile.preferred_style
        )
    
    RETURN present_suggestions(suggestions)
```

---

## 进化效果体现

经过 3-5 轮对话后，用户应能感受到：

- **更少返工**：系统自动融入已知偏好，首次输出更贴合
- **更准调研**：M1调研会优先推荐用户常用的领域和风格
- **越说越懂**：无需重复描述相同偏好，系统自动记住

**效果上限**：平台版有进化≈75%，无进化≈60%。差距不大，但体验明显。

---

## 降级处理

本模块任何步骤失败，均**静默降级**，不影响主任务。

```
TRY:
    execute_evolution(signal, context)
CATCH:
    PRINT ""  // 静默
    CONTINUE main_flow
```

---

## 与本地版的差异

平台版与本地版的核心差异：

存储介质：
  平台版：平台记忆/对话上下文
  本地版：本地cache/数据库

数据持久性：
  平台版：依赖平台
  本地版：永久本地

RAG入库：
  平台版：不可用
  本地版：可用

进化标记：
  平台版：不输出（用户可见）
  本地版：输出（供外层解析）

效果上限：
  平台版：≈75%
  本地版：≈95%

本质：进化算法在SKILL.md，进化数据在平台记忆/对话历史。平台版是轻量闭环。
