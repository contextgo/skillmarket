"""
马甲系统 Python 版本
用户生活语言 ↔ AI专业执行语言的认知中间件
"""

import json
import yaml
import os
import uuid
import re
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple


class MajiaSystem:
    """马甲系统核心类"""

    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.base_path = Path(self.config.get("storage", {}).get("base_path", "./storage"))
        self.domains_path = Path(self.config.get("storage", {}).get("domains_path", "./domains"))
        self._ensure_directories()
        self.questions_log = self._load_json("questions.json", [])
        self.preferences = self._load_json("preferences.json", {})
        self.sessions = self._load_json("sessions.json", [])

    def _load_config(self, config_path: str) -> Dict:
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            print(f"配置文件 {config_path} 不存在，使用默认配置")
            return {}

    def _load_json(self, filename: str, default: Any) -> Any:
        filepath = self.base_path / filename
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return default

    def _save_json(self, filename: str, data: Any) -> None:
        filepath = self.base_path / filename
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _ensure_directories(self) -> None:
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.domains_path.mkdir(parents=True, exist_ok=True)

    def process(self, user_input: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        处理用户输入 - 缓存决策流程

        决策树：
        1. 是否为老用户？（有本地缓存记录）
        2. 是否为同领域请求？
        3. 老用户+同领域 → 快车道流程
        4. 新用户 或 切换领域 → 完整流程
        """
        # 第一步：安全预检（代码层，不消耗Token）
        safe, reason = self._safety_check(user_input)
        if not safe:
            return {"status": "rejected", "reason": reason}

        # 第二步：会话管理（代码层）
        if not session_id:
            session_id = str(uuid.uuid4())
        session = self._get_or_create_session(session_id)
        self._log_question(user_input, session)

        # 第三步：意图分类（代码层，不消耗Token）
        domain, confidence = self._classify_domain(user_input)

        # 第四步：缓存决策（代码层，核心逻辑）
        is_warm = self._is_warm_user()
        is_same_domain = self._is_same_domain(session, domain)

        if is_warm and is_same_domain:
            # 快车道：老用户 + 同领域
            result = self._fast_lane_process(user_input, domain, session_id)
            result["cache_mode"] = "fast_lane"
            return result
        else:
            # 完整流程：新用户 或 切换领域
            result = self._full_process(user_input, domain, session_id)
            result["cache_mode"] = "full_process"
            return result

    def _is_warm_user(self) -> bool:
        """
        判断是否为老用户
        标准：是否进行过本地缓存（手动启动/自动写入）
        检查项：
        1. preferences.json 中是否有偏好记录
        2. domains/ 目录中是否有规则文件
        3. questions.json 中是否有问答记录
        """
        # 检查偏好记录
        if self.preferences.get("preferred_domains"):
            return True
        # 检查规则文件
        if list(self.domains_path.glob("*.yaml")):
            return True
        # 检查问答记录
        if self.questions_log:
            return True
        return False

    def _is_same_domain(self, session: Dict, domain: str) -> bool:
        """
        判断是否为同领域请求
        """
        current = session.get("current_domain", "通用")
        return current == domain and domain != "通用"

    def _fast_lane_process(self, user_input: str, domain: str, session_id: str) -> Dict[str, Any]:
        """
        快车道流程（热启动）
        只注入极短的个性化偏好词，Token消耗约 50-100
        """
        # 1. 构建偏好包
        preference_pack = self._build_preference_pack(domain)

        # 2. 组装最小化上下文
        context = self._build_fast_context(user_input, domain, preference_pack)

        # 3. 调用模型
        response = self._call_api(context)

        # 4. 快速核验（安全底座已固化）

        # 5. 更新会话
        session = self._get_or_create_session(session_id)
        session["current_domain"] = domain
        session["last_activity"] = datetime.now().isoformat()
        self._update_session(session)

        return {
            "status": "success",
            "session_id": session_id,
            "domain": domain,
            "confidence": 0.95,
            "response": response,
            "rules_loaded": 0,
            "token_mode": "fast_lane"
        }

    def _full_process(self, user_input: str, domain: str, session_id: str) -> Dict[str, Any]:
        """
        完整流程（冷启动/领域切换）
        消耗约 500-1000 Token
        """
        # 1. RAG检索
        rules = self._rag_search(user_input, domain)

        # 2. 组装上下文
        context = self._build_context(user_input, domain, rules)

        # 3. 调用模型
        response = self._call_api(context)

        # 4. 更新会话和偏好
        session = self._get_or_create_session(session_id)
        session["current_domain"] = domain
        session["last_activity"] = datetime.now().isoformat()
        self._update_session(session)
        self._update_preferences(domain)

        return {
            "status": "success",
            "session_id": session_id,
            "domain": domain,
            "confidence": 0.8,
            "response": response,
            "rules_loaded": len(rules),
            "token_mode": "full"
        }

    def _build_preference_pack(self, domain: str) -> str:
        """
        构建领域偏好包
        只包含极短的关键偏好词，不超过100字符
        """
        pack_parts = []

        # 领域偏好
        preferred = self.preferences.get("preferred_domains", [])
        if domain in preferred:
            pack_parts.append(f"常用领域：{domain}")

        # 用户风格偏好（如果有）
        style = self.preferences.get("style_preferences", {})
        if style.get(domain):
            pack_parts.append(f"风格：{style[domain]}")

        # 术语偏好（如果有）
        terms = self.preferences.get("terminology_preferences", {})
        if terms.get(domain):
            pack_parts.append(f"术语：{terms[domain]}")

        if not pack_parts:
            return f"领域：{domain}（首次使用）"

        return " | ".join(pack_parts)

    def _build_fast_context(self, user_input: str, domain: str, preference_pack: str) -> str:
        """
        构建快车道上下文
        只传必要内容，Token消耗极低
        """
        lines = []
        lines.append(f"用户输入：{user_input}")
        lines.append(f"偏好包：{preference_pack}")
        lines.append("请直接输出结果，简洁为主。")
        return "\n".join(lines)

    def _safety_check(self, text: str) -> Tuple[bool, str]:
        """
        代码层安全预检，直接拒绝违规内容，不进入模型
        """
        forbidden = [
            "国家领导人", "国旗", "国徽", "色情", "赌博",
            "毒品", "武器", "邪教", "分裂", "恐怖", "诈骗",
            "政变", "暴乱", "台独", "港独"
        ]
        for keyword in forbidden:
            if keyword in text:
                return False, f"内容包含违规关键词，无法处理"
        return True, ""

    def _classify_domain(self, text: str) -> Tuple[str, float]:
        """
        代码层意图分类，基于已存储的领域规则文件进行匹配
        如果没有匹配的领域规则，返回"通用"
        不在代码中硬编码任何具体领域
        """
        # 从已存储的领域规则文件中动态加载关键词
        domain_scores: Dict[str, int] = {}

        for domain_file in self.domains_path.glob("*.yaml"):
            try:
                with open(domain_file, 'r', encoding='utf-8') as f:
                    content = yaml.safe_load(f)
                    if not content:
                        continue
                    # 从规则文件中读取关键词列表
                    keywords = content.get("keywords", [])
                    score = sum(1 for kw in keywords if kw in text)
                    if score > 0:
                        domain_name = content.get("name", domain_file.stem)
                        domain_scores[domain_name] = score
            except Exception:
                continue

        if domain_scores:
            best = max(domain_scores, key=domain_scores.get)
            total = sum(domain_scores.values())
            return best, domain_scores[best] / total

        return "通用", 0.5

    def _rag_search(self, query: str, domain: str) -> List[Dict]:
        """
        RAG检索，只返回与当前输入相关的规则片段
        不加载全部文档，只加载必要内容，减少后续Token消耗
        """
        rag_config = self.config.get("rag", {})
        if not rag_config.get("enable", True):
            return []

        top_k = rag_config.get("top_k", 3)
        min_score = rag_config.get("min_score", 0.4)
        results = []

        for domain_file in self.domains_path.glob("*.yaml"):
            try:
                with open(domain_file, 'r', encoding='utf-8') as f:
                    content = yaml.safe_load(f)
                    if not content:
                        continue
                    score = self._calculate_relevance(query, content)
                    if score >= min_score:
                        results.append({
                            "file": domain_file.name,
                            "content": content,
                            "score": score
                        })
            except Exception:
                continue

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def _calculate_relevance(self, query: str, content: Dict) -> float:
        query_lower = query.lower()
        score = 0.0

        keywords = content.get("keywords", [])
        for kw in keywords:
            if kw in query_lower:
                score += 0.3

        terms = content.get("terminology", {})
        for user_term in terms:
            if user_term in query_lower:
                score += 0.2

        return min(score, 1.0)

    def _build_context(self, user_input: str, domain: str, rules: List[Dict]) -> str:
        """
        组装最小化上下文，只传必要内容给模型，最大程度减少Token
        """
        lines = []
        lines.append("你是马甲系统，一个专业的意图翻译专家。")
        lines.append(f"用户输入：{user_input}")
        lines.append(f"识别领域：{domain}")

        if rules:
            lines.append("相关规则（仅供参考）：")
            for rule in rules[:2]:  # 最多传2条，控制Token
                c = rule["content"]
                terms = c.get("terminology", {})
                if terms:
                    lines.append(f"术语对照：{json.dumps(terms, ensure_ascii=False)}")
                questions = c.get("questions", {}).get("must_have", [])
                if questions:
                    lines.append(f"建议追问：{', '.join(questions[:3])}")

        lines.append("请直接回应用户需求，输出专业提示词或可行性建议。不使用表格格式。")
        return "\n".join(lines)

    def _call_api(self, context: str) -> str:
        """
        调用模型API。
        如果config中配置了API则使用，否则返回结构化提示。
        """
        api_config = self.config.get("api", {})
        if not api_config.get("enabled", False):
            # 未配置API时，返回结构化上下文，供用户自行粘贴到模型
            return f"[未配置API，请将以下内容复制到你的AI助手]\n\n{context}"

        provider = api_config.get("provider", "openai")
        base_url = api_config.get("base_url", "").rstrip("/")
        api_key = api_config.get("api_key", "")
        model = api_config.get("model", "gpt-4")

        # 支持多个provider，统一走OpenAI兼容接口
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": context}],
            "temperature": 0.7,
            "max_tokens": 1024
        }

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                f"{base_url}/chat/completions",
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}"
                },
                method="POST"
            )
            timeout = api_config.get("timeout", 60)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            return f"API调用失败（HTTP {e.code}）：{e.reason}"
        except Exception as e:
            return f"API调用失败：{str(e)}"

    def _log_question(self, question: str, session: Dict) -> None:
        entry = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "question": question,
            "session_id": session["id"],
            "domain": session.get("current_domain", "未知")
        }
        self.questions_log.append(entry)
        self._save_json("questions.json", self.questions_log)

    def _get_or_create_session(self, session_id: str) -> Dict:
        for session in self.sessions:
            if session["id"] == session_id:
                return session
        new_session = {
            "id": session_id,
            "created_at": datetime.now().isoformat(),
            "current_domain": "通用",
            "previous_domains": [],
            "last_activity": datetime.now().isoformat()
        }
        self.sessions.append(new_session)
        self._save_json("sessions.json", self.sessions)
        return new_session

    def _update_session(self, session: Dict) -> None:
        for i, s in enumerate(self.sessions):
            if s["id"] == session["id"]:
                if s["current_domain"] != session["current_domain"]:
                    s["previous_domains"].append(s["current_domain"])
                s.update(session)
                self._save_json("sessions.json", self.sessions)
                return

    def _update_preferences(self, domain: str) -> None:
        if "preferred_domains" not in self.preferences:
            self.preferences["preferred_domains"] = []
        if domain not in self.preferences["preferred_domains"]:
            self.preferences["preferred_domains"].append(domain)
        self.preferences["updated_at"] = datetime.now().isoformat()
        self._save_json("preferences.json", self.preferences)

    def search(self, keyword: str) -> List[Dict]:
        """关键词检索领域规则"""
        results = []
        for domain_file in self.domains_path.glob("*.yaml"):
            try:
                with open(domain_file, 'r', encoding='utf-8') as f:
                    content = yaml.safe_load(f)
                    if keyword.lower() in str(content).lower():
                        results.append({
                            "file": domain_file.name,
                            "content": content
                        })
            except Exception:
                continue
        return results

    def add_domain(self, name: str, content: Dict) -> bool:
        """添加领域规则文件"""
        filepath = self.domains_path / f"{name}.yaml"
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(content, f, allow_unicode=True, default_flow_style=False)
            return True
        except Exception:
            return False

    def get_status(self) -> Dict:
        domain_count = len(list(self.domains_path.glob("*.yaml")))
        return {
            "domains_count": domain_count,
            "questions_count": len(self.questions_log),
            "sessions_count": len(self.sessions),
            "preferred_domains": self.preferences.get("preferred_domains", []),
            "api_enabled": self.config.get("api", {}).get("enabled", False)
        }


def main():
    """命令行入口"""
    majia = MajiaSystem()

    import sys
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == "search" and len(sys.argv) > 2:
            keyword = sys.argv[2]
            results = majia.search(keyword)
            print(json.dumps(results, ensure_ascii=False, indent=2))
        elif command == "status":
            status = majia.get_status()
            print(json.dumps(status, ensure_ascii=False, indent=2))
        else:
            print("用法：python majia.py [search <keyword>|status]")
    else:
        print("马甲系统 Python 版本")
        print("输入 'quit' 退出，输入 'status' 查看状态")
        session_id = str(uuid.uuid4())

        while True:
            user_input = input("\n> ").strip()
            if not user_input:
                continue
            if user_input.lower() == 'quit':
                break
            if user_input.lower() == 'status':
                print(json.dumps(majia.get_status(), ensure_ascii=False, indent=2))
                continue
            result = majia.process(user_input, session_id)
            if result["status"] == "rejected":
                print(f"\n[拒绝] {result['reason']}")
            else:
                print(f"\n[领域：{result['domain']} | 置信度：{result['confidence']:.0%} | 规则：{result['rules_loaded']}条]")
                print(f"\n{result['response']}")


if __name__ == "__main__":
    main()
