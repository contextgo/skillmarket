"""马甲系统 Python 本地版"""
import json, os, re, uuid, urllib.request, urllib.error
from datetime import datetime
from pathlib import Path

class Majia:
    def __init__(self, sp=None):
        self.sp = Path(sp or self._find_path())
        for d in ["rules", "sessions", "preferences", "history"]:
            (self.sp / d).mkdir(parents=True, exist_ok=True)
        self._load()

    def _find_path(self):
        for f in ["SKILL.md", "../SKILL.md"]:
            if os.path.exists(f):
                m = re.search(r"(?m)^storage_path:\s*(.+)$", open(f, encoding="utf-8").read())
                if m: return m.group(1).strip()
        return "./storage"

    def _load(self):
        try:
            self.prefs = json.load(open(self.sp / "preferences/preferences.json", encoding="utf-8"))
        except:
            self.prefs = {"domain_history": [], "updated": "", "last_session": ""}
        try:
            self.cfg = json.load(open(self.sp / "config.json", encoding="utf-8"))
        except:
            self.cfg = {"api": {"enabled": False}}

    def _safety(self, t):
        # 安全预检：内容必须符合相关法律法规
        # 不在代码中硬编码敏感词列表，由模型根据法律判断
        return True, ""

    def _classify(self, text):
        import yaml
        scores = {}
        for f in self.sp.glob("rules/*.yaml"):
            try:
                c = yaml.safe_load(open(f, encoding="utf-8"))
                if c:
                    s = sum(1 for k in c.get("keywords", []) if k in text)
                    if s > 0: scores[c.get("name", f.stem)] = s
            except: pass
        if scores:
            best = max(scores, key=scores.get)
            return best, scores[best] / sum(scores.values())
        return "通用", 0.5

    def _rag(self, query, domain):
        import yaml
        results = []
        for f in self.sp.glob("rules/*.yaml"):
            try:
                c = yaml.safe_load(open(f, encoding="utf-8"))
                if c:
                    score = min(sum(.3 for k in c.get("keywords", []) if k in query) + sum(.2 for t in c.get("terminology", {}).keys() if t in query), 1.0)
                    if score >= .3: results.append({"file": f.name, "content": c, "score": score})
            except: pass
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:3]

    def _ctx(self, inp, domain, rules):
        lines = [f"你是马甲系统，用户输入：{inp}", f"识别领域：{domain}"]
        if rules:
            lines.append("相关规则：")
            for r in rules[:2]:
                c = r["content"]
                if c.get("terminology"): lines.append(f"术语：{json.dumps(c['terminology'], ensure_ascii=False)}")
                qs = c.get("questions", {}).get("must_have", [])
                if qs: lines.append(f"追问：{', '.join(qs[:3])}")
        lines.append("直接回应，不使用表格。")
        return "\n".join(lines)

    def _api(self, ctx):
        a = self.cfg.get("api", {})
        if not a.get("enabled", False): return f"[未配置API]\n\n{ctx}"
        payload = {"model": a.get("model", "gpt-4"), "messages": [{"role": "user", "content": ctx}], "temperature": 0.7, "max_tokens": 1024}
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(f"{a['base_url']}/chat/completions", data=data,
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {a['api_key']}"}, method="POST")
            with urllib.request.urlopen(req, timeout=a.get("timeout", 60)) as resp:
                return json.loads(resp.read().decode("utf-8"))["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e: return f"HTTP错误 {e.code}：{e.reason}"
        except Exception as e: return f"API错误：{e}"

    def _save_prefs(self, domain, sid):
        if domain not in self.prefs.get("domain_history", []): self.prefs.setdefault("domain_history", []).append(domain)
        self.prefs["updated"] = datetime.now().isoformat()
        self.prefs["last_session"] = sid
        open(self.sp / "preferences/preferences.json", "w", encoding="utf-8").write(json.dumps(self.prefs, ensure_ascii=False, indent=2))

    def process(self, inp):
        ok, reason = self._safety(inp)
        if not ok: return {"status": "rejected", "reason": f"违规：{reason}"}
        domain, confidence = self._classify(inp)
        rules = self._rag(inp, domain)
        response = self._api(self._ctx(inp, domain, rules))
        sid = str(uuid.uuid4())
        self._save_prefs(domain, sid)
        return {"status": "success", "session_id": sid, "domain": domain, "confidence": confidence, "response": response, "rules": len(rules)}

    def parse(self, text):
        sid = datetime.now().strftime("%Y%m%d-%H%M%S")
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        u, a, cr, cc = [], [], None, []
        for ln in lines:
            if re.match(r"^(用户|User|我)[:：]", ln):
                if cr == "u" and cc: u.append("\n".join(cc))
                elif cr == "a" and cc: a.append("\n".join(cc))
                cr, cc = "u", [re.sub(r"^(用户|User|我)[:：]\s*", "", ln)]
            elif re.match(r"^(AI|助手|Assistant|马甲)[:：]", ln):
                if cr == "u" and cc: u.append("\n".join(cc))
                elif cr == "a" and cc: a.append("\n".join(cc))
                cr, cc = "a", [re.sub(r"^(AI|助手|Assistant|马甲)[:：]\s*", "", ln)]
            elif cr: cc.append(ln)
        if cr == "u" and cc: u.append("\n".join(cc))
        elif cr == "a" and cc: a.append("\n".join(cc))
        blocks = re.findall(r"```[\w]*\n([\s\S]*?)```", text)
        blocks = [b.strip() for b in blocks if len(b.strip()) > 20]
        data = {"id": sid, "timestamp": datetime.now().isoformat(), "user_turns": len(u), "ai_turns": len(a),
                "user_last": u[-1] if u else "", "ai_last": a[-1] if a else "", "full_text": text}
        open(self.sp / f"history/{sid}.json", "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, indent=2))
        for i, b in enumerate(blocks):
            open(self.sp / f"rules/rule-{sid}-{i}.md", "w", encoding="utf-8").write(b)
        return {"session_id": sid, "user_turns": len(u), "ai_turns": len(a), "rules_extracted": len(blocks)}

    def get_prefs(self): return self.prefs

    def interactive(self):
        print("=" * 40)
        print("  马甲系统 Python 本地版")
        print("=" * 40)
        print(f"存储路径：{self.sp}")
        print(f"偏好领域：{', '.join(self.prefs.get('domain_history', [])) or '无'}")
        print("输入 quit 退出，输入 prefs 查看偏好")
        print()
        while True:
            inp = input("> ").strip()
            if not inp: continue
            if inp.lower() == "quit": break
            if inp.lower() == "prefs":
                print(json.dumps(self.get_prefs(), ensure_ascii=False, indent=2)); continue
            result = self.process(inp)
            if result["status"] == "rejected": print(f"[拒绝] {result['reason']}")
            else:
                print(f"[领域：{result['domain']} | 置信度：{result['confidence']:.0%} | 规则：{result['rules']}条]")
                print(result["response"])

if __name__ == "__main__":
    import sys
    m = Majia()
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "parse":
            text = open(sys.argv[2], encoding="utf-8").read() if len(sys.argv) > 2 else input("请粘贴对话内容后回车：")
            r = m.parse(text)
            print(f"解析完成：{r['user_turns']}轮对话，提取{r['rules_extracted']}条规则")
        elif cmd == "prefs":
            print(json.dumps(m.get_prefs(), ensure_ascii=False, indent=2))
        elif cmd == "status":
            prefs = m.get_prefs()
            print(f"偏好领域：{', '.join(prefs.get('domain_history', [])) or '无'}")
            print(f"上次更新：{prefs.get('updated', '无')}")
        else:
            print(json.dumps(m.process(" ".join(sys.argv[1:])), ensure_ascii=False, indent=2))
    else:
        m.interactive()
