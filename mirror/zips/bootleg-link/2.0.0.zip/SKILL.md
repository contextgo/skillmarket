---
name: bootleg-link
version: 2.0.0
description: Daemon-style YouTube music downloader with task queue, progress tracking, and concurrent download support.
metadata:
  openclaw:
    emoji: "🎵"
    os: ["linux", "darwin", "win32"]
    requires:
      bins: ["yt-dlp", "ffmpeg"]
---

# Bootleg-Link Skill

Daemon-style YouTube music downloader with task queue, progress tracking, and concurrent download support.

## Features

- **Task Queue**: Submit downloads and track by task ID
- **Progress Tracking**: Real-time progress via file-based state
- **Concurrent Downloads**: CPU-aware parallel downloads
- **Cross-Platform**: Linux, macOS, Windows
- **Resume Support**: Restart from where you left off

## Architecture

```
User → Skill Script → State File → yt-dlp processes
                     ↓
              Progress File (JSON)
```

## Usage

### Start Daemon Mode
```bash
# Start in daemon mode (background)
bootleg-link-daemon.sh start

# Check status
bootleg-link-daemon.sh status

# Stop daemon
bootleg-link-daemon.sh stop
```

### Submit Download Task
```bash
# Single URL
bootleg-link submit "https://www.youtube.com/@Channel"

# Batch from file
bootleg-link batch /path/to/urls.txt

# With custom output
bootleg-link submit "https://www.youtube.com/@Channel" -o /path/to/output
```

### Query Progress
```bash
# Query specific task
bootleg-link query <task-id>

# List all tasks
bootleg-link list

# Watch real-time progress
bootleg-link watch
```

### Control Tasks
```bash
# Cancel a task
bootleg-link cancel <task-id>

# Pause all downloads
bootleg-link pause

# Resume downloads
bootleg-link resume
```

## Scripts

| Script | Purpose |
|--------|---------|
| `bootleg-link-daemon.sh` | Start/stop/status daemon |
| `bootleg-link-submit.sh` | Submit download task |
| `bootleg-link-query.sh` | Query task progress |
| `bootleg-link-batch.sh` | Batch download from file |

## State Files

| File | Description |
|------|-------------|
| `~/.bootleg-link/state.json` | Task queue state |
| `~/.bootleg-link/progress/<task-id>.json` | Per-task progress |
| `~/.bootleg-link/pids/` | Active download PIDs |

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BOOTLEG_OUTPUT_DIR` | `~/Downloads/bootleg-link` | Output directory |
| `BOOTLEG_QUALITY` | `320` | MP3 quality (128/192/256/320) |
| `BOOTLEG_CONCURRENCY` | `4` | Max concurrent downloads |
| `BOOTLEG_STATE_DIR` | `~/.bootleg-link` | State directory |
| `BOOTLEG_ARCHIVE` | `download-archive.txt` | Skip downloaded videos |

### Platform Paths

| OS | Default Output |
|----|----------------|
| Linux | `~/Downloads/bootleg-link` |
| macOS | `~/Downloads/bootleg-link` |
| Windows | `%USERPROFILE%\Downloads\bootleg-link` |

## Task States

| State | Description |
|-------|-------------|
| `pending` | Task queued, waiting |
| `downloading` | Currently downloading |
| `completed` | Successfully finished |
| `failed` | Error occurred |
| `paused` | User paused |
| `cancelled` | User cancelled |

## Dependencies

- `yt-dlp` - YouTube downloader
- `ffmpeg` - Audio conversion

```bash
# Install dependencies
pip install yt-dlp

# or
brew install yt-dlp ffmpeg  # macOS
sudo apt install yt-dlp ffmpeg  # Linux
```

## Example Workflow

```bash
# 1. Start daemon
bootleg-link-daemon.sh start

# 2. Submit a channel
bootleg-link submit "https://www.youtube.com/@VeryHouseMusic"

# 3. Check progress
bootleg-link query task_123456

# 4. Watch live
bootleg-link watch

# 5. Stop when done
bootleg-link-daemon.sh stop
```

## Notes

- Tasks persist across restarts (file-based state)
- Uses `--download-archive` to skip already downloaded
- Progress updates every 5 seconds
- Logs written to `~/.bootleg-link/logs/`