# Changelog — skillhub-publish

## [1.2.0] - 2026-05-04

### Fixed
- 审计新增「非发布物检测」P1 检查：隐藏文件、占位文件（`.gitkeep`/`.empty`）、无扩展名文件
- 副本创建阶段新增 `.gitkeep` 自动清理（rsync exclude + cp fallback 双保险）
- 原因：little-writer 发布时 SkillHub 因 `.gitkeep` 文件类型不合规拒绝提交

## [1.1.0] - 2026-05-02

### Added
- **初始发布：** 一键将 WorkBuddy skill 准备好发布到 SkillHub
- 六维审计：文件结构 / Frontmatter / 内容质量 / 版本一致性 / 安全 / 外部依赖
- P0/P1/P2 分级审计报告，P0 不可跳过
- 先议后行：展示报告后与用户讨论确认，确认后才执行修改
- 副本优先：修复在桌面副本上执行，原始文件可选同步
- 自动修复：补文件、改描述、对齐版本，每步确认后执行
- 物料生成：自动生成 README.md + SkillHub 描述文本 + 版本更新说明
- 零发现路由：审计无问题时跳过修复流程，直接生成物料
- 干净打包：创建副本时自动排除 `.git`/`__pycache__`/`.DS_Store` 等垃圾文件
- 纯指令式实现，零外部依赖，不依赖其他 skill
