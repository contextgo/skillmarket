# SPEC · skillhub-publish

> 版本：v1.1.0
> 日期：2026-05-02
> 状态：已发布

## 概述

一键检查 + 修复 + 生成发布物料，将任一 WorkBuddy skill 准备好发布到 SkillHub。六维审计、讨论确认、自动修复、生成 README + 描述 + 版本说明，最后打包交付。

## 触发词

- publish, skillhub, skillhub发布, 发布技能, 技能上架, 发布到skillhub

## 输入

| 输入 | 来源 | 说明 |
|------|------|------|
| 目标 skill 名称 | 用户指定 | `~/.workbuddy/skills/<名称>/` |
| 版本号 | 可选，用户指定 | 不指定则用 SKILL.md 当前版本 |

## 处理流程（5+1 Phase）

### Phase 1: 六维审计（只读）

| 维度 | 检查项 | 最高等级 |
|------|--------|---------|
| 1. 文件结构 | SKILL.md / CHANGELOG.md / DESIGN.md / SPEC.md / README.md / scripts/ | P0 |
| 2. Frontmatter | name / version / description / triggers / token_budget / 拼写 | P0 |
| 3. 内容质量 | 占位符 / 边界声明 / 中英触发词 / 用语规范 / CHANGELOG内容 | P1 |
| 4. 版本一致性 | SKILL ↔ CHANGELOG ↔ SPEC ↔ DESIGN + 正文版本号 + 附属文件 | P1 |
| 5. 安全 | rm/sudo / 硬编码密钥 / 写操作声明 / 错误处理 / shebang | P0 |
| 6. 外部依赖 | Skill调用 / 非标准库 / 系统命令 / 跨skill路径 / 网络请求 | P0 |

审计结果路由：零发现 → 跳至 Phase 4；有发现 → Phase 2。

### Phase 2: 讨论确认
- 展示 P0/P1/P2 审计报告（P0 无 checkbox，不可跳过）
- 用户确认修复清单 + 版本号（含 semver 建议） + README 定位 + 是否同步原始文件

### Phase 2.5: 创建发布副本
- 用 rsync 或 cp + 清理，排除 `.git`/`__pycache__`/`.DS_Store`/`node_modules`/`*.pyc`
- 后续 Phase 3/4 均在副本上操作

### Phase 3: 在副本上执行修复
- 更新 Frontmatter（version / description / triggers / token_budget / 正文版本号）
- 创建缺失文档文件（DESIGN.md / SPEC.md 模板）
- 对齐版本号（CHANGELOG.md + SPEC.md + DESIGN.md + 附属文件）
- 每步修前展示 diff，确认后执行
- 如用户选择同步，同时对原始文件执行相同修改

### Phase 4: 生成发布物料
- README.md：写入发布副本，含用途/核心能力/使用方式/技术架构/安全声明
- SkillHub 描述文本：80-200 字，直接输出给用户复制
- 版本更新说明：条目式变更记录，直接输出给用户复制

### Phase 5: 最终交付
- 输出两段文本供用户复制
- 输出完成报告：发布包位置 + 变更摘要 + 原始文件同步状态

## 输出

### 成功标准
1. 发布副本目录文件结构完整（无 P0 缺陷，已排除垃圾文件）
2. README.md 写入发布副本
3. 两段描述文本输出供复制
4. 原始文件同步状态告知用户

### 交付物格式

**SkillHub 描述文本：**
```
{名称} v{版本}

{一句话定位。核心能力简要列举。适用场景。}

{限制声明。}
{许可证声明。}
```

**版本更新说明：**
```
v{版本} - {日期}

新增：
- {功能}
- {功能}

改进：
- {改进}

修复：
- {修复}
```

## 降级策略

| 场景 | 行为 |
|------|------|
| 目标 skill 不存在 | 报错终止 |
| 用户跳过所有 P1/P2 | 只修 P0，跳过 Phase 3 的对应项 |
| 用户中途终止 | 已修改的内容保留，提供回退建议 |
| automation_update 不可用 | 跳过（本 skill 不依赖 automation） |

## 依赖

- 无外部 Python 包依赖
- 无其他 skill 依赖
- 仅依赖 WorkBuddy 内置工具（Read/Write/Edit/Bash/find）
