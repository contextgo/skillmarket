---
name: skillhub-publish
version: "1.1.0"
description: >
  一键检查 + 修复 + 生成发布物料，将任一 WorkBuddy skill 准备好发布到
  SkillHub。六维审计（文件结构/Frontmatter/内容质量/版本一致性/安全/
  外部依赖），讨论确认后自动修复，生成 README.md + SkillHub 描述 +
  版本更新说明，最后打包交付。
triggers:
  - publish
  - skillhub
  - skillhub发布
  - 发布技能
  - 技能上架
  - 发布到skillhub
token_budget:
  L0_trigger: 150
  L1_core: 3000
  L2_deep: 6000
  hard_cap: 10000
---

# SkillHub Publish

一键将 WorkBuddy skill 准备好发布到 SkillHub。五阶段流程：审计 → 讨论确认 → 创建副本 → 修复 → 生成物料 → 交付。

> **先议后行：** 所有写操作前都经用户确认，且在发布副本上执行，不意外修改原始文件。

---

## 使用方式

```
发布 skillhub-publish 到 skillhub
或：发布技能 xxx
或：把 xxx 准备好发布
```

## 输入

当前运行此 skill 时，用户需指定：
- **目标 skill 名称**（必填）：`~/.workbuddy/skills/<目标名称>/` 下的现有 skill
- **版本号**（可选）：如不指定，使用 SKILL.md 中的当前版本

---

## Phase 1: 六维审计（只读，不动手）

### 步骤 1.1：定位目标 skill

确认 `~/.workbuddy/skills/<用户指定的名称>/` 目录存在。不存在则报错终止。

### 步骤 1.2：文件结构审计

对以下文件逐项检查存在性：

| 文件 | 等级 | 判定 |
|------|------|------|
| SKILL.md | P0 | 不存在则无法发布 |
| CHANGELOG.md | P0 | 不存在则无法追溯版本 |
| DESIGN.md | P1 | 推荐必备 |
| SPEC.md | P1 | 推荐必备 |
| README.md 或 INTRO.md | P1 | 面向用户的说明 |
| scripts/（如 SKILL.md 中声明） | P1 | 声明了脚本但目录不存在 |
| 空文件检测 | P2 | 存在但为空（0 字节） |

### 步骤 1.3：Frontmatter 审计

读取 `SKILL.md` 的 frontmatter（--- 之间的 YAML），检查：

| 字段 | 等级 | 要求 |
|------|------|------|
| name | P0 | 存在且非空 |
| version | P0 | 存在且符合 semver（x.y.z） |
| description | P0 | 存在且非空 |
| description 长度 | P1 | 80-200 字为佳 |
| triggers | P0 | 存在且非空列表 |
| triggers 数量 | P1 | 至少 3 个 |
| token_budget | P1 | 推荐配置三级加载 |
| 字段拼写正确 | P1 | 如 desription→description |

### 步骤 1.4：内容质量审计

| 检查项 | 等级 | 说明 |
|--------|------|------|
| description 通顺完整 | P1 | 无"待补充""TODO"等占位符 |
| description 含限制声明 | P2 | 如"仅限 WorkBuddy"等边界说明 |
| triggers 覆盖中英文 | P1 | 建议中英文触发词都有 |
| 文本中"我的""本技能"等 | P2 | 建议统一为"此技能"等正式用语 |
| CHANGELOG.md 内容充实 | P1 | 不只写"initial release"，有实质性变更记录 |

### 步骤 1.5：版本一致性审计

| 检查项 | 等级 | 说明 |
|--------|------|------|
| SKILL.md version = CHANGELOG 最新版 | P1 | 不匹配需对齐 |
| SPEC.md version 同 SKILL.md | P1 | 如有 SPEC.md |
| DESIGN.md version 同 SKILL.md | P1 | 如有 DESIGN.md |
| SKILL.md 正文中版本号一致 | P2 | 扫描正文 `vX.Y.Z` 模式，与 frontmatter 对比 |
| 附属 .md 文件版本号一致 | P2 | 如 PHILOSOPHY.md 中声明的版本与 frontmatter 一致 |

### 步骤 1.6：安全检查

| 检查项 | 等级 | 说明 |
|--------|------|------|
| 脚本含 rm -rf / sudo 等 | P0 | 严重安全红线 |
| 脚本含硬编码 API key / token | P0 | 敏感信息泄露 |
| 文件写操作未声明范围 | P1 | 需要说明写什么路径 |
| 缺少 try-except 错误处理 | P2 | 可能导致脚本中断 |
| Python 脚本的 shebang 行 | P2 | 建议 #!/usr/bin/env python3 |

### 步骤 1.7：外部依赖审计

| 检查项 | 等级 | 说明 |
|--------|------|------|
| Skill 工具调用其他 skill 名 | P0 | 如 `Skill("xxx")`，其他人没有 |
| import 非标准库 | P1 | 需要声明 pip 依赖 |
| 调用系统命令非标准 | P1 | 如 curl, jq, docker 等 |
| 路径硬编码到其他 skill 目录 | P1 | 不会自动存在 |
| 发起外部网络请求 | P1 | 需要声明 API 调用 |

### 步骤 1.8：生成审计报告

将以上所有发现的问题按 P0→P1→P2 分组，用以下格式展示：

```
📋 审计报告：{目标 skill 名称} v{版本}

🔴 P0 — 必须修复（不可跳过）
  - 问题描述

🟡 P1 — 推荐修复
  [{ }] 问题描述

🟢 P2 — 锦上添花
  [{ }] 问题描述
```

P1/P2 默认勾选。P0 直接执行，无 checkbox。

### 步骤 1.9：审计结果路由

- 发现任何问题（P0/P1/P2 任一项存在）→ 进入 Phase 2 讨论确认
- 完全没有发现任何问题 → 直接进入 Phase 4 生成物料（跳过 Phase 2/3/2.5），告知用户：
  "此 skill 已达到发布标准，无需修复。直接生成发布物料。"

---

## Phase 2: 讨论确认

展示审计报告后，向用户确认：

1. **确认修复清单：** P0 不可跳过；P1/P2 逐项确认哪些要修、哪些跳过
2. **确认版本号：** 使用当前版本还是升级。参考规则：
   - 仅文档/描述修改 → patch 升级（x.y.z+1）
   - 功能变更 → minor 升级（x.y+1.0）
   - 破坏性变更 → major 升级（x+1.0.0）
3. **确认 README 内容概要：** 生成 README 前确认定位（目标用户/核心价值点）
4. **确认是否同步到原始文件：** 修复在发布包的副本上执行，是否同时更新原始文件？（默认是）
5. 用户签字确认后才进入 Phase 2.5

---

## Phase 2.5: 创建发布副本

在 Phase 3 修改之前，先将目标 skill 复制到桌面，后续所有修复在副本上操作。

```bash
rsync -a --exclude='.git' --exclude='__pycache__' --exclude='.DS_Store' \
  --exclude='node_modules' --exclude='*.pyc' --exclude='.gitignore' \
  ~/.workbuddy/skills/{名称}/ ~/Desktop/{名称}-v{版本}/
```

若 rsync 不可用，改用 cp + 清理：

```bash
cp -r ~/.workbuddy/skills/{名称} ~/Desktop/{名称}-v{版本}/
find ~/Desktop/{名称}-v{版本} -name '__pycache__' -type d -exec rm -rf {} +
find ~/Desktop/{名称}-v{版本} -name '.DS_Store' -delete
find ~/Desktop/{名称}-v{版本} -name '*.pyc' -delete
rm -rf ~/Desktop/{名称}-v{版本}/.git
```

告知用户发布副本已创建。

---

## Phase 3: 在副本上执行修复

在 `~/Desktop/{名称}-v{版本}/` 上操作。如果用户选择了同步原始文件，对 `~/.workbuddy/skills/{名称}/` 执行相同修改。

按用户确认的清单逐项执行：

### 修复 Frontmatter
- 更新 version
- 补充/优化 description 文字
- 补充 triggers
- 补充 token_budget
- 修正拼写错误
- 同步 SKILL.md 正文标题中的版本号

### 补齐文件
- 创建缺失的 DESIGN.md（使用标准模板）
- 创建缺失的 SPEC.md（使用标准模板）
- 创建/更新 README.md（Phase 4 生成的完整版）

### 对齐版本
- 更新 CHANGELOG.md：追加新版本条目
- 更新 SPEC.md/DESIGN.md 中的版本号
- 更新附属 .md 文件（如 PHILOSOPHY.md）中声明的版本

每次修改前向用户展示 diff（修改内容简述），确认后执行。

完成后告知用户：
- 如已同步到原始文件：⚠️ "原始 skill 文件已更新至 v{版本}，建议用 git 查看 diff 确认变更"
- 如未同步：ℹ️ "原始文件未修改。发布包版本为 v{版本}，如需升级请手动操作"

---

## Phase 4: 生成发布物料

### 4.1 生成 README.md

为目标 skill 生成详细 README.md，写入发布副本（`~/Desktop/{名称}-v{版本}/`）。内容框架：

```
# {skill 名称}

> 一句话定位

## 这是什么（用途）
解决什么问题，适用场景

## 核心能力
逐项说明

## 快速使用
触发词 + 使用方式

## 技术架构（如有）
方案实现简述

## 环境要求
依赖项说明

## 安全与限制
边界声明

## 更新日志
链到 CHANGELOG.md
```

生成后展示给用户确认，可修改后定稿。

### 4.2 生成 SkillHub 描述文本

一段 80-200 字描述。格式示例：

```
{技能名称} v{版本}

一句话定位。{核心能力简要列举}。{适用场景}。

{限制声明}。
{许可证声明}。
```

直接展示给用户，可直接复制。

### 4.3 生成版本更新说明

条目式文本。格式示例：

```
v{版本} - {日期}

新增：
- {功能}
- {功能}

改进：
- {改进}

修复：
- {修复}
```

直接展示给用户，可直接复制。

---

## Phase 5: 最终交付

1. 发布副本已完成（Phase 2.5 已复制到桌面，Phase 3/4 已写入修改）
2. 输出 SkillHub 描述文本（Phase 4.2 产出）直接给用户复制
3. 输出版本更新说明（Phase 4.3 产出）直接给用户复制
4. 输出最终完成报告：发布包位置 + 变更摘要 + 原始文件同步状态

---

## 参考资料

- `DESIGN.md` — 架构决策记录
- `SPEC.md` — 功能规格说明
- `CHANGELOG.md` — 更新日志

## 安全声明

本 skill 仅读取 `~/.workbuddy/skills/` 目录下的文件。文件修改操作仅在用户确认后执行。不依赖其他 skill，不发起外部网络请求。遵循 MIT-0 许可证。
