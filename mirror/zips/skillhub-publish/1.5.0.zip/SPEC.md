# SPEC · skillhub-publish

> 状态：已发布

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| **1.5.0** | **2026-05-06** | **脱敏规则分层+AI自举+反馈闭环** |
| **1.4.0** | **2026-05-06** | **Phase 3.5 内容脱敏：通用基线+技能override+替换报告** |
| **1.3.1** | **2026-05-06** | **删除空目录，小版本修复** |
| **1.3.0** | **2026-05-06** | **发布包清理规则重写** |
| 1.2.0 | 2026-05-04 | 初始版本 |

## 概述

一键检查 + 修复 + 生成发布物料，将任一 WorkBuddy skill 准备好发布到 SkillHub。六维审计、讨论确认、自动修复、生成 README + 描述 + 版本说明，最后打包交付。

## 触发词

- publish, skillhub, skillhub发布, 发布技能, 技能上架, 发布到skillhub
- 文件报警, 危害内容, 敏感词检查, 脱敏规则

## 输入

| 输入 | 来源 | 说明 |
|------|------|------|
| 目标 skill 名称 | 用户指定 | `~/.workbuddy/skills/<名称>/` |
| 版本号 | 可选，用户指定 | 不指定则用 SKILL.md 当前版本 |

## 处理流程（5+2 Phase + 闭环）

### Phase 1: 六维审计（只读）

| 维度 | 检查项 | 最高等级 |
|------|--------|---------|
| 1. 文件结构 | SKILL.md / CHANGELOG.md / DESIGN.md / SPEC.md / README.md / scripts/ | P0 |
| 2. Frontmatter | name / version / description / triggers / token_budget / 拼写 | P0 |
| 3. 内容质量 | 占位符 / 边界声明 / 中英触发词 / 用语规范 / CHANGELOG内容 | P1 |
| 4. 版本一致性 | SKILL ↔ CHANGELOG ↔ SPEC ↔ DESIGN + 正文版本号 + 附属文件 | P1 |
| 5. 安全 | rm/sudo / 硬编码密钥 / 写操作声明 / 错误处理 / shebang | P0 |
| 6. 外部依赖 | Skill调用 / 非标准库 / 系统命令 / 跨skill路径 / 网络请求 | P0 |

审计结果路由：零发现 → 跳至 Phase 4；有发现 → Phase 2。

### Phase 2: 讨论确认
- 展示 P0/P1/P2 审计报告（P0 无 checkbox，不可跳过）
- 用户确认修复清单 + 版本号（含 semver 建议） + README 定位 + 是否同步原始文件

### Phase 2.5: 创建发布副本
- 用 rsync 或 cp + 清理，排除 `.git`/`__pycache__`/`.DS_Store`/`node_modules`/`*.pyc`
- 读取 `.skillignore` 动态排除额外条目
- `data/user-profile.md` 骨架化（保留字段结构，清空个人数据）
- 清理 `data/cache/` 等缓存数据
- 后续 Phase 3/4 均在副本上操作

### Phase 3: 在副本上执行修复
- 更新 Frontmatter（version / description / triggers / token_budget / 正文版本号）
- 创建缺失文档文件（DESIGN.md / SPEC.md 模板）
- 对齐版本号（CHANGELOG.md + SPEC.md + DESIGN.md + 附属文件）
- 清理非发布物（`.skillignore`/`.verify_history`/`tests`/`__pycache__` 等，仅副本，不同步原文）
- 每步修前展示 diff，确认后执行
- 如用户选择同步，同时对原始文件执行相同修改

### Phase 3.5: 发布内容脱敏（仅副本）
- **3.5.0 规则自举（AI Bootstrap）** — 首次运行时私有规则文件不存在，自动用 LLM 扫描发布副本，识别人名/组织/政治触发词等 5 类敏感信息，生成规则草案供用户确认后保存至 `~/.workbuddy/principles/sanitize_rules.yaml`
- **3.5.1 分层加载** — 私有规则优先（`~/.workbuddy/principles/`）→ 内置通用规则兜底
- **3.5.2 执行替换** — `find` + `sed` 对所有 `.md`/`.yaml` 文件逐条替换，`|` 作分隔符
- **3.5.3 生成替换报告** — 规则来源 + 每类匹配数 + 样例
- **3.5.4 展示确认** — 检查是否过度替换或有遗漏
- **反馈闭环** — 上架后用户反馈「XX 文件被报警了」，skill 自动扫描该文件、识别新触发词、对比去重后追加到规则库

### Phase 4: 生成发布物料
- README.md：写入发布副本，含用途/核心能力/使用方式/技术架构/安全声明
- SkillHub 描述文本：80-200 字，直接输出给用户复制
- 版本更新说明：条目式变更记录，直接输出给用户复制

### Phase 5: 最终交付
- **5.0 终检** — 扫描隐藏文件残留、脚本目录、空目录，零残留才通过
- 输出发布包位置 + 变更摘要 + 原始文件同步状态
- 输出 SkillHub 描述文本和版本更新说明供用户复制

## 输出

### 成功标准
1. 发布副本目录文件结构完整（无 P0 缺陷，已排除垃圾文件）
2. README.md 写入发布副本
3. 两段描述文本输出供复制
4. 原始文件同步状态告知用户

### 交付物格式

**SkillHub 描述文本：**
```
{名称} v{版本}

{一句话定位。核心能力简要列举。适用场景。}

{限制声明。}
{许可证声明。}
```

**版本更新说明：**
```
v{版本} - {日期}

新增：
- {功能}
- {功能}

改进：
- {改进}

修复：
- {修复}
```

## 降级策略

| 场景 | 行为 |
|------|------|
| 目标 skill 不存在 | 报错终止 |
| 用户跳过所有 P1/P2 | 只修 P0，跳过 Phase 3 的对应项 |
| 用户中途终止 | 已修改的内容保留，提供回退建议 |
| automation_update 不可用 | 跳过（本 skill 不依赖 automation） |
| 私有规则文件不存在，用户跳过自举 | 使用内置通用规则兜底，若两者皆空则跳过 Phase 3.5 |
| 反馈闭环中文件不存在或无法访问 | 报错，告知用户提供有效路径 |
| 发布 skillhub-publish 自身 | 内置规则仅含通用无害模式（violence_sex_terms + review_imitation），不会触发自举或误伤 |

## 依赖

- 无外部 Python 包依赖
- 无其他 skill 依赖
- 仅依赖 WorkBuddy 内置工具（Read/Write/Edit/Bash/find）
