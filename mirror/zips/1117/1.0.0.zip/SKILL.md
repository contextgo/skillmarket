---
name: ppt-translate
description: >
  将中文PPT翻译为英文PPT，保持原始布局、位置、大小、格式完全不变。
  核心流程：python-pptx提取文本→AI翻译→python-pptx回写，仅替换文本内容。
  This skill should be used when the user needs to translate a Chinese PPT to English,
  or when the user mentions PPT翻译、PPT英化、中文PPT转英文、翻译PPT、PPT中译英、
  PPT translate、convert PPT to English、translate slides、PPT英文版。
---

# PPT 中文翻译英文

## 概述

将中文PPT中的所有文本内容翻译为英文，生成新的PPT文件。翻译后的内容保持在原始PPT中的精确位置，字号、加粗、颜色等格式属性与原文完全一致，方便用户后续微调。

核心策略为**段落级合并翻译**：同一段落内被拆分为多个run的中文文本合并翻译后写入第一个run，其余run清空，避免逐run翻译导致的语义断裂。

## 工作流程

### 第一步：提取文本

使用 `scripts/extract_text.py` 从原始PPT中提取所有文本内容（含正文和备注），输出结构化JSON。

```bash
python scripts/extract_text.py <输入PPTX路径> <输出JSON路径>
```

**示例**：
```bash
python scripts/extract_text.py input.pptx extracted.json
```

**输出JSON结构**：
```json
{
  "source_file": "input.pptx",
  "items": [
    {
      "slide_number": 1,
      "shape_name": "文本框 11",
      "paragraph_index": 0,
      "type": "body",
      "original": "数据智能与建造仿真北京市重点实验室",
      "translated": "",
      "format_info": {
        "sz": 4000,
        "bold": true,
        "alignment": "ctr",
        "latin_font": "Times New Roman",
        "ea_font": "微软雅黑"
      }
    }
  ]
}
```

**字段说明**：
- `type`: "body"（正文）或 "notes"（备注）
- `original`: 段落完整拼接文本（多个run合并后）
- `translated`: 待AI填充的翻译结果
- `format_info`: 保留的格式信息（仅供参考，回写时不修改）

### 第二步：AI翻译

读取JSON，逐条翻译 `original` 字段的内容，将翻译结果填入 `translated` 字段。

**翻译原则**：
1. 专业术语使用标准英译，参考下方术语对照表
2. 保持原文语义完整性，不增减内容
3. 英文表达简洁，避免过长导致溢出文本框
4. 数字、编号、缩写（如BIM+MR）保持不变
5. 备注翻译采用口语化英文，保持演讲风格

**术语对照表**：

| 中文 | 英文 |
|------|------|
| 原位仿真 | In-situ Simulation |
| 数据智能与建造仿真 | Data Intelligence and Construction Simulation |
| 北京市重点实验室 | Beijing Key Laboratory |
| 混合现实 | Mixed Reality (MR) |
| 有限元分析 | Finite Element Analysis (FEA) |
| 数字孪生 | Digital Twin |
| 虚实映射 | Virtual-Real Mapping |
| 原位快速计算代理模型 | In-situ Fast Computation Surrogate Model |
| 结构响应异常智能诊断 | Intelligent Diagnosis of Structural Response Anomalies |
| 多物理场耦合仿真 | Multi-physics Coupled Simulation |
| 卡尔曼滤波 | Kalman Filter |
| 贝叶斯推断 | Bayesian Inference |
| 模型降阶 | Model Order Reduction |
| 施工监测 | Construction Monitoring |
| 穿透式监测 | Penetrating Monitoring |
| 仿真云图 | Simulation Contour Map |
| 原位投射 | In-situ Projection |
| 施工进度 | Construction Progress |
| 偏差分析 | Deviation Analysis |
| 认知增强 | Cognitive Enhancement |
| 构件级 | Component-level |
| 施工工序 | Construction Sequence |
| 遗传算法 | Genetic Algorithm |
| 空间锚点 | Spatial Anchor |
| 机器人建模 | Robot Modeling |
| 运动学模型 | Kinematic Model |
| 装配式建筑 | Prefabricated Building |
| 喷浆 | Shotcrete |
| 沙盘 | Sandbox |
| 声光预警 | Audio-Visual Warning |
| 穹顶结构 | Dome Structure |

### 第三步：回写翻译

使用 `scripts/replace_text.py` 将翻译后的JSON回写到PPT中，生成新的英文PPT。

> **注意**：AI翻译后，需将 `extracted.json` 中所有条目的 `translated` 字段填入翻译结果，保存为 `translated.json`（或任意指定文件名），再进行回写。**不要直接用 `extracted.json`**（其中的 `translated` 字段全部为空）。

```bash
python scripts/replace_text.py <原始PPTX路径> <翻译JSON路径> <输出PPTX路径>
```

**示例**：
```bash
python scripts/replace_text.py input.pptx translated.json output_en.pptx
```

**回写策略**：
- 翻译文本写入段落第一个run，其余run文本清空为空字符串
- 保留第一个run的全部格式属性（字号、加粗、颜色、字体等）
- EA字体（微软雅黑）切换为与Latin字体相同（通常为Times New Roman）
- lang属性从"zh-CN"改为"en-US"
- 绝不修改位置/尺寸属性（`<a:xfrm>`的off/ext）
- `translated`为空时跳过该条目，不替换原始文本

## 依赖

```bash
pip install python-pptx
```

## 注意事项

- 提取脚本会跳过图片元素（`<p:pic>`）和页码占位符（`<a:fld type="slidenum">`）
- 组合形状（Group Shape）内的子文本框会被递归遍历并提取/翻译
- 备注文本同样会被提取和翻译
- 翻译后英文文本可能比中文短，位置不变但文本框内可能有留白，方便用户微调
- 如英文文本比中文长导致溢出，可在PowerPoint中手动调小字号或调整文本框

## 资源文件

### scripts/
- `extract_text.py`: 从PPTX提取文本到JSON
- `replace_text.py`: 从JSON回写翻译到PPTX
