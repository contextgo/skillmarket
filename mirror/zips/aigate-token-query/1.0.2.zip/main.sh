#!/bin/bash
set -e

# 检查jq是否安装
if ! command -v jq &> /dev/null; then
    echo "❌ 请先安装jq：brew install jq 或者 apt install jq"
    exit 1
fi

# 读取配置
API_KEY="${CONFIG_API_KEY}"
API_BASE="${CONFIG_API_BASE}"

if [ -z "$API_KEY" ] || [ -z "$API_BASE" ]; then
    echo "❌ 请先配置AIGate的查询地址和SK：在技能配置中填写API_BASE（查询地址）和API_KEY（SK）"
    exit 1
fi

# 获取当前年月
YEAR=$(date +%Y)
MONTH=$(date +%m)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d 2>/dev/null || true)
# 兼容macOS的date命令
if [ -z "$YESTERDAY" ]; then
    YESTERDAY=$(date -v-1d +%Y-%m-%d)
fi

# 请求余额接口
BALANCE_RESP=$(curl -s -H "Authorization: Bearer $API_KEY" "$API_BASE/user/balance")
if [ $? -ne 0 ] || [ -z "$BALANCE_RESP" ]; then
    echo "❌ 请求余额接口失败，请检查网络和API Key是否正确"
    exit 1
fi

# 请求月度统计接口
MONTHLY_RESP=$(curl -s -H "Authorization: Bearer $API_KEY" "$API_BASE/user/usage/monthly?month=$YEAR-$MONTH")
if [ $? -ne 0 ] || [ -z "$MONTHLY_RESP" ]; then
    echo "❌ 请求月度统计接口失败，请检查网络和API Key是否正确"
    exit 1
fi

# 解析余额数据
NAME=$(echo "$BALANCE_RESP" | jq -r '.data.name')
TOKEN_BALANCE=$(echo "$BALANCE_RESP" | jq -r '.data.token_balance' | awk '{printf "%,d", $0}')
RATE_LIMIT=$(echo "$BALANCE_RESP" | jq -r '.data.rate_limit')

# 解析昨日数据
YESTERDAY_DATA=$(echo "$MONTHLY_RESP" | jq -r '.data.daily[] | select(.date == "'$YESTERDAY'")')
if [ -z "$YESTERDAY_DATA" ] || [ "$YESTERDAY_DATA" = "null" ]; then
    YESTERDAY_REQUESTS=0
    YESTERDAY_PROMPT=0
    YESTERDAY_COMPLETION=0
    YESTERDAY_TOTAL=0
else
    YESTERDAY_REQUESTS=$(echo "$YESTERDAY_DATA" | jq -r '.requests' | awk '{printf "%,d", $0}')
    YESTERDAY_PROMPT=$(echo "$YESTERDAY_DATA" | jq -r '.prompt_tokens' | awk '{printf "%,d", $0}')
    YESTERDAY_COMPLETION=$(echo "$YESTERDAY_DATA" | jq -r '.completion_tokens' | awk '{printf "%,d", $0}')
    YESTERDAY_TOTAL=$(echo "$YESTERDAY_DATA" | jq -r '.total_tokens' | awk '{printf "%,d", $0}')
fi

# 输出结果
echo "### 📊 昨日（$YESTERDAY）Token消耗统计"
echo "| 指标 | 数值 |"
echo "| --- | --- |"
echo "| 请求次数 | $YESTERDAY_REQUESTS次 |"
echo "| 输入Token | $YESTERDAY_PROMPT |"
echo "| 输出Token | $YESTERDAY_COMPLETION |"
echo "| 总消耗Token | $YESTERDAY_TOTAL |"
echo "| 金额消耗 | 0元 |"
echo ""
echo "---"
echo ""
echo "### 💰 当前额度信息"
echo "| 指标 | 数值 |"
echo "| --- | --- |"
echo "| 套餐类型 | $NAME |"
echo "| 通用Token余额 | $TOKEN_BALANCE |"
echo "| 速率限制 | $RATE_LIMIT RPM |"
echo ""
echo "🦞"