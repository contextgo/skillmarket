# AIGate Token用量查询技能
## 功能说明
查询AIGate平台的API Token余额、月度使用统计、昨日消耗等信息。
## 触发关键词
发送任意包含Token的内容即可触发，不区分大小写，包括但不限于：
- Token、token、TOKEN
- Token用量查询
- Token余额查询
- Token消耗统计
- 查Token
- 统计Token
## 配置项
| 配置项 | 类型 | 必填 | 说明 | 默认值 |
| --- | --- | --- | --- | --- |
| API_KEY | string | 是 | AIGate平台的SK（API密钥），格式为sk-ag-xxx | 无 |
| API_BASE | string | 是 | AIGate平台查询地址，例如https://aigate.chudian.site | 无 |
## 使用方法
1. 将本技能目录放到OpenClaw的技能目录（~/.openclaw/skills）下：
```bash
mv skills/aigate-token-query ~/.openclaw/skills/
```
2. 打开OpenClaw的技能配置，找到「AIGate Token用量查询」技能，填写两个必填参数：
   - API_BASE：你的AIGate查询地址（例如https://aigate.chudian.site）
   - API_KEY：你的SK（API密钥，格式sk-ag-xxx）
3. 之后发送任意触发关键词即可自动查询并返回Token统计结果。
## 依赖安装
需要先安装json解析工具jq：
- macOS：`brew install jq`
- Debian/Ubuntu：`apt install jq`
- Windows：`scoop install jq`