#!/usr/bin/env python3
"""
check_single_agent.py — 检测当前 OpenClaw 是否处于单 Agent 模式

Exit codes:
  0 = multi-agent mode (agents.list has entries beyond just main)
  1 = single-agent mode (no agents.list or only main)
  2 = error

Output (stdout):
  SINGLE_AGENT=true  — 单 agent 模式
  SINGLE_AGENT=false — 多 agent 模式
  MODE=type_a        — accounts 非空但 main 无 binding（自动修复后可用）
  MODE=type_b        — accounts 为空（单 bot 部署，无法安全创建）
  MODE=multi         — 已是多 agent 环境

兼容 Type A 和 Type B 两种单 agent 场景。
"""

import json
import os
import sys
import argparse
from pathlib import Path

CONFIG_PATH = Path(os.path.expanduser("~/.openclaw/openclaw.json"))
RESERVED_IDS = {"main", "default", "null", "none", "true", "false"}


def load_config():
    if not CONFIG_PATH.exists():
        print("ERROR: openclaw.json not found")
        sys.exit(2)
    with open(CONFIG_PATH) as f:
        return json.load(f)


def check_single_agent(config):
    """
    返回 (is_single, mode, detail)
    is_single: bool
    mode: "type_a" | "type_b" | "multi"
    detail: str 说明
    """
    agents_list = config.get("agents", {}).get("list", [])
    feishu_channel = config.get("channels", {}).get("feishu", {})
    feishu_accounts = feishu_channel.get("accounts", {})
    bindings = config.get("bindings", [])

    # 过滤出非 main 的真实 agent
    real_agents = [a for a in agents_list if a.get("id") not in RESERVED_IDS]

    # Type B: accounts 为空（单 bot 部署）
    if not feishu_accounts:
        # 综合判断：顶层有 appId/appSecret + dmPolicy=allowlist + 有 allowFrom
        # 符合此模式 = 典型的单用户单 bot 部署（channel 级别配置）
        dm_policy = feishu_channel.get("dmPolicy", "")
        allow_from = feishu_channel.get("allowFrom", [])
        has_top_app = bool(feishu_channel.get("appId")) and bool(feishu_channel.get("appSecret"))
        has_allowlist = dm_policy == "allowlist" and allow_from

        if has_top_app and has_allowlist:
            return True, "type_b", "accounts 为空，channel 级别单 bot 部署（dmPolicy=allowlist）"
        elif has_top_app:
            return True, "type_b", "accounts 为空，channel 级别单 bot 部署"
        else:
            return True, "type_b", "accounts 为空"

    # Type A: accounts 非空，但 main 暂无 binding
    if feishu_accounts:
        main_has_binding = any(
            b.get("agentId") == "main" for b in bindings
        )
        if not main_has_binding:
            return True, "type_a", "accounts 非空但 main 无 binding，自动修复后可继续"

    # Multi-agent: 有超过 main 以外的 agent
    if real_agents:
        return False, "multi", f"已有 {len(real_agents)} 个非 main agent"

    # 单 agent 环境（只有 main，没有其他 agent）
    return True, "type_a", "单 agent 模式（只有 main）"


def main():
    parser = argparse.ArgumentParser(description="检测是否处于单 Agent 模式")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    args = parser.parse_args()

    config = load_config()
    is_single, mode, detail = check_single_agent(config)

    if args.json:
        print(json.dumps({
            "single_agent": is_single,
            "mode": mode,
            "detail": detail,
        }, indent=2))
    else:
        print(f"SINGLE_AGENT={str(is_single).lower()}")
        print(f"MODE={mode}")
        print(f"DETAIL={detail}")

    sys.exit(0 if not is_single else 1)


if __name__ == "__main__":
    main()
