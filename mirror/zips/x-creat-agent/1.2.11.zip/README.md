# x-create-agent

> 规范化创建 OpenClaw Agent 的标准化 Skill。

## 功能

- 自动发现 `OPENCLAW_HOME` 配置目录
- 创建标准化的 agent 工作区文件（SOUL.md / USER.md / AGENTS.md 等）
- 注册 agent 到 `openclaw.json`
- 支持飞书机器人自动配对（AppID + AppSecret）

## 使用方式

当用户说"创建 agent"、"新建 agent"、"添加 agent"时触发本 skill。

### 基本用法

```bash
cd ~/.openclaw/skills/create-agent
python3 scripts/create_agent.py "<agent_id>" "<name>" "<description>" \
  [--user-name <name>] \
  [--feishu-appid <appid>] \
  [--feishu-appsecret <secret>]
```

### 示例

```bash
# 创建普通 agent
python3 scripts/create_agent.py planner "小计" "时间规划和任务管理"

# 创建并配对飞书机器人
python3 scripts/create_agent.py planner "小计" "时间规划" \
  --user-name "李" \
  --feishu-appid "cli_xxxxxxxx" \
  --feishu-appsecret "xxxxxxxx"
```

## 工作区文件说明

| 文件 | 说明 |
|------|------|
| `SOUL.md` | Agent 身份与行为准则 |
| `USER.md` | 服务对象信息（--user-name 参数动态生成） |
| `AGENTS.md` | 工作区规范 |
| `IDENTITY.md` | 身份描述模板 |
| `MEMORY.md` | 长期记忆 |
| `HEARTBEAT.md` | 心跳检查配置 |
| `SESSION-STATE.md` | 会话状态 |
| `TOOLS.md` | 本地工具配置 |

## 文件结构

```
x-create-agent/
├── SKILL.md          # Skill 描述文件
├── README.md         # 本说明
└── scripts/
    └── create_agent.py   # 创建脚本
```

## 注意事项

- 脚本**不写死用户名**，USER.md 通过 `--user-name` 动态生成
- 不在 `openclaw.json` 写入 `enabled` 字段
- agent 的 `workspace` 和 `agentDir` 使用绝对路径
- 飞书配对可选：创建时传入 AppID/AppSecret 自动完成绑定

## 安全特性

- 不在模板或脚本中硬编码任何用户 OpenID /凭证
- 工作区文件由模板动态生成，不泄露创建者信息
