---
# zip-meta: author=少年李迟迟 version=1.2.11
name: create-agent
description: 规范化创建 OpenClaw Agent 的完整工作流。当用户说「创建 agent」、「新建 agent」、「添加 agent」、「new agent」时触发。执行流程：(1) 单 Agent 预检 + 可选迁移向导；(2) 收集 agent 信息；(3) 执行脚本创建工作区和文件；(4) 引导飞书机器人配对。
---
# zip-meta: author=少年李迟迟 version=1.2.11

# create-agent — OpenClaw Agent 标准化创建流程

> 工作区文件（USER.md 等）**不写死任何用户名**，参考模板结合用户信息动态生成。
> 飞书配对**自动化**（脚本直接写入 openclaw.json），无需主 agent 介入。

## 工作流程

### Step 0：预检 — 单 Agent 模式检测

运行 `scripts/check_single_agent.py` 检测当前环境模式：

```bash
cd ~/.openclaw/skills/create-agent
python3 scripts/check_single_agent.py
```

**检测结果分支：**

| 模式 | 输出 | 含义 | 处理 |
|------|------|------|------|
| `type_a` | `SINGLE_AGENT=true` | accounts 非空但 main 无 binding | 自动修复 main binding，继续 Step 1 |
| `type_b` | `SINGLE_AGENT=true` | accounts 为空（单 bot 部署）| 询问迁移，拒绝则终止 |
| `multi` | `SINGLE_AGENT=false` | 已是多 Agent 环境 | 直接继续 Step 1 |

#### Type A：自动修复 main binding

脚本自动补全 main 的路由绑定（逻辑同 `_ensure_main_binding`），无需询问用户。

#### Type B：迁移询问（关键分支）

⚠️ **单 bot 部署（accounts 为空）**，创建新 agent 有风险。询问用户：

> ⚠️ **检测到当前为单 bot 部署**（飞书配置在 channel 顶层而非 accounts 子账号下），直接创建新 agent 可能导致飞书路由混乱。
>
> **重要提醒：此操作不可逆，且当前 main agent 的飞书配对需要重新进行。**
>
> 是否需要先**迁移到多 Agent 模式**？
> - 同意：运行迁移向导，将飞书配置重构为多账号模式，然后再创建新 agent
> - 拒绝：终止本次创建操作
>
> 请回复「同意迁移」或「拒绝」。

**用户同意迁移 → 内联迁移向导（见下方「迁移向导」章节）：**

1. 生成配置 diff，用户确认后写入
2. 强制备份 `openclaw.json` 到 `~/.openclaw/backups/`
3. 验证飞书 bot 连通性，不通则中止并提示重新配对
4. 继续 Step 1

**用户拒绝迁移 → 警告 + 终止：**

```
⚠️ 已取消创建操作。
当前单 bot 部署环境下强行创建新 agent 可能导致飞书消息路由失败。
请先手动完成多 Agent 迁移，或在多 Agent 环境后再试。
```

#### Multi-agent 环境

直接进入 Step 1，无需任何预检操作。

---
# zip-meta: author=少年李迟迟 version=1.2.11

### Step 1：收集信息

向用户收集以下信息（逐项询问，不要一次性问完）：

| 信息 | 说明 | 验证规则 |
|------|------|---------|
| `agent_id` | 唯一标识，英文字母/数字/连字符 | 必须是合法标识符（字母开头） |
| `name` | 中文名称 | 1-20字 |
| `description` | 职能描述 | 一句话说明这个 agent 是做什么的 |
| `feishu_appid` | 飞书 AppID | 格式：`cli_xxxxxxxx` |
| `feishu_appsecret` | 飞书 AppSecret | 非空字符串 |

> ⚠️ 如果用户跳过飞书信息，创建完成后仍需引导填写。

### Step 2：执行创建脚本

**路径确认制**：脚本发现路径后，先展示汇总信息，用户确认（输入 y）后再创建。

```bash
cd ~/.openclaw/skills/create-agent
python3 scripts/create_agent.py "<agent_id>" "<name>" "<description>" \
  [--openclaw-home <path>] \
  [--workspace <path>] \
  [--user-name <name>] \
  [--feishu-appid <appid>] \
  [--feishu-appsecret <secret>]
```

**用户输入非 y**：脚本立即退出，不创建任何文件。

### Step 2.1：飞书配对（可选，命令行直接传入）

创建时直接传入 AppID 和 AppSecret，自动完成飞书机器人配对。

### Step 3：确认完成

创建完成后，报告：
- Agent 目录路径
- 工作区路径
- 飞书绑定状态（如已传入凭证，则自动完成）

---
# zip-meta: author=少年李迟迟 version=1.2.11

## 迁移向导（内联，Step 0 Type B 分支）

> ⚠️ **风险提示（请先阅读）：**
> - **此操作不可逆**，涉及 `openclaw.json` 结构变更
> - **当前 main agent 的飞书配对将失效**，需要在 Control UI 中重新配对
> - **建议在 Control UI 中执行此操作**，而非在飞书对话框中
> - 如果配置写入后飞书断联，请到 Control UI 的「Agent」页面重新配对当前 agent

### 迁移 Step 1：强制备份

在写入任何配置前，先备份：

```bash
mkdir -p ~/.openclaw/backups
cp ~/.openclaw/openclaw.json ~/.openclaw/backups/openclaw.json.backup.$(date +%Y%m%d_%H%M%S)
echo "备份已保存至 ~/.openclaw/backups/"
```

**紧急回滚（如需恢复）：**
```bash
cp ~/.openclaw/backups/openclaw.json.backup.<timestamp> ~/.openclaw/openclaw.json
openclaw gateway restart
```

### 迁移 Step 2：生成配置

- 将现有的 channel 顶层飞书配置（`appId`/`appSecret`）迁移到 `accounts.main` 下
- 为每个新 agent 在 `accounts` 下创建对应条目
- 生成 `agents.list[]`：main + 各新 agent
- 生成 `bindings[]`：每个 agent 绑定到对应飞书账号

### 迁移 Step 3：用户确认

展示生成的配置 diff，用户确认（输入 y）后写入 `openclaw.json`。

### 迁移 Step 4：创建工作区

为每个新 agent 创建 `~/.openclaw/workspace-<agent_id>/` 及标准文件。

### 迁移 Step 5：验证飞书连通性

```bash
curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d '{"app_id":"<appId>","app_secret":"<appSecret>"}'
```

- **验证成功**（HTTP 200）：配置写入完成，提示重启 Gateway
- **验证失败**：提示飞书配对已失效，请在 Control UI 中重新配对当前 agent

### 迁移 Step 6：验证命令

提示运行：
```bash
openclaw agents list --bindings
openclaw gateway restart
```

---
# zip-meta: author=少年李迟迟 version=1.2.11

## 脚本详情

### `scripts/check_single_agent.py`

检测当前 OpenClaw 部署模式：
- **Type A**：accounts 非空但 main 无 binding → 自动修复后可继续
- **Type B**：accounts 为空（channel 级别单 bot 部署）→ 需迁移
- **Multi**：已有超过 main 的多 agent → 直接通过

Exit code: 0 = multi-agent, 1 = single-agent, 2 = error

### `scripts/create_agent.py`

创建标准化 agent 工作区文件，注册到 `openclaw.json`，支持飞书配对。
