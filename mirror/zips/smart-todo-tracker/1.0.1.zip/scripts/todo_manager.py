#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能待办管理器 - 支持全平台的待办事项 CRUD 操作

用法:
    python todo_manager.py add "任务描述" [--due DATE] [--priority high|medium|low] [--tags tag1,tag2]
    python todo_manager.py list [--status pending|completed] [--due-before DATE]
    python todo_manager.py complete 任务ID或关键词
    python todo_manager.py delete 任务ID或关键词
    python todo_manager.py check-due [--hours 24]
"""

import json
import sys
import uuid
import os
import platform
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict
import argparse
import io
import re

# 跨平台编码处理
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


def get_memory_path() -> Path:
    """获取跨平台的 memory 目录路径"""
    # 优先使用环境变量
    if 'OPENCLAW_WORKSPACE' in os.environ:
        return Path(os.environ['OPENCLAW_WORKSPACE']) / 'memory'
    
    # 从脚本位置推断
    script_dir = Path(__file__).resolve().parent
    # skills/smart-todo-tracker/scripts -> workspace
    workspace = script_dir.parent.parent.parent
    
    # 检查是否在正确的目录结构中
    if (workspace / 'memory').exists():
        return workspace / 'memory'
    
    # 回退到用户主目录
    home = Path.home()
    if platform.system() == 'Windows':
        return home / '.openclaw' / 'workspace' / 'memory'
    else:
        return home / '.openclaw' / 'workspace' / 'memory'


TODO_FILE = get_memory_path() / 'todos.json'


def load_todos() -> dict:
    """加载待办，不存在则创建空结构"""
    if not TODO_FILE.exists():
        TODO_FILE.parent.mkdir(parents=True, exist_ok=True)
        return {"todos": [], "version": "1.0", "updated": datetime.now().isoformat()}
    
    try:
        with open(TODO_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        # 备份损坏的文件
        backup = TODO_FILE.with_suffix('.json.bak')
        TODO_FILE.rename(backup)
        return {"todos": [], "version": "1.0", "updated": datetime.now().isoformat()}


def save_todos(data: dict):
    """保存待办到文件"""
    TODO_FILE.parent.mkdir(parents=True, exist_ok=True)
    data["updated"] = datetime.now().isoformat()
    with open(TODO_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def add_todo(
    task: str,
    due: Optional[str] = None,
    priority: str = "medium",
    tags: List[str] = None,
    context: str = ""
) -> dict:
    """添加新待办"""
    data = load_todos()
    
    todo = {
        "id": str(uuid.uuid4())[:8],
        "task": task,
        "due": due,
        "priority": priority,
        "tags": tags or [],
        "status": "pending",
        "created": datetime.now().isoformat(),
        "completed_at": None,
        "context": context
    }
    
    data["todos"].append(todo)
    save_todos(data)
    return todo


def list_todos(
    status: Optional[str] = None,
    due_before: Optional[str] = None,
    tag: Optional[str] = None
) -> List[dict]:
    """列出待办，支持多条件过滤"""
    data = load_todos()
    todos = data["todos"]
    
    if status:
        todos = [t for t in todos if t["status"] == status]
    
    if due_before:
        try:
            due_date = datetime.fromisoformat(due_before.replace('Z', '+00:00'))
            todos = [
                t for t in todos
                if t.get("due") and datetime.fromisoformat(t["due"].replace('Z', '+00:00')) <= due_date
            ]
        except (ValueError, TypeError):
            pass
    
    if tag:
        todos = [t for t in todos if tag.lower() in [tag.lower() for tag in t.get("tags", [])]]
    
    # 按优先级和截止日期排序
    priority_order = {"high": 0, "medium": 1, "low": 2}
    todos.sort(key=lambda t: (
        priority_order.get(t.get("priority", "medium"), 1),
        t.get("due") or "9999-99-99"
    ))
    
    return todos


def find_todo(keyword: str) -> Optional[dict]:
    """查找待办，支持 ID 和模糊匹配"""
    data = load_todos()
    keyword_lower = keyword.lower().strip()
    
    # 先尝试 ID 精确匹配
    for todo in data["todos"]:
        if todo["id"] == keyword_lower:
            return todo
    
    # 模糊匹配任务内容
    for todo in data["todos"]:
        task_lower = todo["task"].lower()
        # 支持中英文部分匹配
        if keyword_lower in task_lower or any(kw in task_lower for kw in keyword_lower.split()):
            return todo
    
    return None


def complete_todo(keyword: str) -> Optional[dict]:
    """标记待办为完成"""
    data = load_todos()
    keyword_lower = keyword.lower().strip()
    
    for todo in data["todos"]:
        task_lower = todo["task"].lower()
        if (todo["id"] == keyword_lower or 
            keyword_lower in task_lower or 
            any(kw in task_lower for kw in keyword_lower.split())):
            todo["status"] = "completed"
            todo["completed_at"] = datetime.now().isoformat()
            save_todos(data)
            return todo
    
    return None


def delete_todo(keyword: str) -> bool:
    """删除待办"""
    data = load_todos()
    keyword_lower = keyword.lower().strip()
    
    for i, todo in enumerate(data["todos"]):
        task_lower = todo["task"].lower()
        if (todo["id"] == keyword_lower or 
            keyword_lower in task_lower or 
            any(kw in task_lower for kw in keyword_lower.split())):
            data["todos"].pop(i)
            save_todos(data)
            return True
    
    return False


def check_due(hours: int = 24) -> List[dict]:
    """检查即将到期的待办"""
    data = load_todos()
    now = datetime.now()
    threshold = now + timedelta(hours=hours)
    
    due_soon = []
    for todo in data["todos"]:
        if todo["status"] != "pending" or not todo.get("due"):
            continue
        
        try:
            due_date = datetime.fromisoformat(todo["due"].replace('Z', '+00:00'))
            if now <= due_date <= threshold:
                due_soon.append(todo)
        except (ValueError, TypeError):
            continue
    
    return due_soon


def format_todo(todo: dict) -> str:
    """格式化单个待办显示"""
    priority_emoji = {"high": "🔴", "medium": "🟡", "low": "🟢"}
    status_emoji = {"pending": "⏳", "completed": "✅"}
    
    emoji = priority_emoji.get(todo.get("priority", "medium"), "⚪")
    status = status_emoji.get(todo.get("status", "pending"), "")
    
    due_str = ""
    if todo.get("due"):
        try:
            due_date = datetime.fromisoformat(todo["due"].replace('Z', '+00:00'))
            # 智能日期显示
            now = datetime.now()
            if due_date.date() == now.date():
                due_str = f" - 今天 {due_date.strftime('%H:%M')}"
            elif due_date.date() == (now + timedelta(days=1)).date():
                due_str = f" - 明天 {due_date.strftime('%H:%M')}"
            else:
                due_str = f" - {due_date.strftime('%m-%d %H:%M')}"
        except (ValueError, TypeError):
            due_str = f" - {todo['due']}"
    
    tags_str = ""
    if todo.get("tags"):
        tags_str = f" [{', '.join(todo['tags'][:3])}]"
    
    return f"{emoji} [{todo.get('priority', 'medium').title()}] {todo['task']}{due_str}{tags_str} {status}"


def main():
    parser = argparse.ArgumentParser(
        description="智能待办管理器",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # add 命令
    add_parser = subparsers.add_parser("add", help="添加新待办")
    add_parser.add_argument("task", help="任务描述")
    add_parser.add_argument("--due", "-d", help="截止时间 (支持自然语言)")
    add_parser.add_argument("--priority", "-p", choices=["high", "medium", "low"], default="medium", help="优先级")
    add_parser.add_argument("--tags", "-t", help="标签 (逗号分隔)")
    add_parser.add_argument("--context", "-c", default="", help="上下文")
    
    # list 命令
    list_parser = subparsers.add_parser("list", help="列出待办")
    list_parser.add_argument("--status", "-s", choices=["pending", "completed"], help="按状态过滤")
    list_parser.add_argument("--due-before", "-b", help="显示此日期前到期的待办")
    list_parser.add_argument("--tag", "-t", help="按标签过滤")
    
    # complete 命令
    complete_parser = subparsers.add_parser("complete", help="标记完成")
    complete_parser.add_argument("keyword", help="任务 ID 或关键词")
    
    # delete 命令
    delete_parser = subparsers.add_parser("delete", help="删除待办")
    delete_parser.add_argument("keyword", help="任务 ID 或关键词")
    
    # check-due 命令
    check_parser = subparsers.add_parser("check-due", help="检查即将到期")
    check_parser.add_argument("--hours", "-H", type=int, default=24, help="检查未来几小时")
    
    # stats 命令
    stats_parser = subparsers.add_parser("stats", help="统计信息")
    
    args = parser.parse_args()
    
    if args.command == "add":
        tags = [t.strip() for t in args.tags.split(",")] if args.tags else []
        todo = add_todo(args.task, args.due, args.priority, tags, args.context)
        print(f"✅ 已添加: {format_todo(todo)}")
    
    elif args.command == "list":
        todos = list_todos(args.status, args.due_before, args.tag)
        if not todos:
            print("📋 暂无待办事项")
        else:
            pending_count = sum(1 for t in todos if t["status"] == "pending")
            completed_count = sum(1 for t in todos if t["status"] == "completed")
            print(f"📋 待办事项 ({pending_count} 个进行中, {completed_count} 个已完成)\n")
            for todo in todos:
                print(f"  [{todo['id']}] {format_todo(todo)}")
    
    elif args.command == "complete":
        todo = complete_todo(args.keyword)
        if todo:
            print(f"✅ 已完成: {todo['task']}")
        else:
            print(f"❌ 未找到待办: {args.keyword}")
    
    elif args.command == "delete":
        if delete_todo(args.keyword):
            print(f"🗑️ 已删除: {args.keyword}")
        else:
            print(f"❌ 未找到待办: {args.keyword}")
    
    elif args.command == "check-due":
        due = check_due(args.hours)
        if not due:
            print(f"📭 未来 {args.hours} 小时内无到期待办")
        else:
            print(f"⏰ 未来 {args.hours} 小时内有 {len(due)} 个待办到期:\n")
            for todo in due:
                print(f"  {format_todo(todo)}")
    
    elif args.command == "stats":
        data = load_todos()
        todos = data["todos"]
        pending = [t for t in todos if t["status"] == "pending"]
        completed = [t for t in todos if t["status"] == "completed"]
        
        print("📊 待办统计\n")
        print(f"  总计: {len(todos)} 个")
        print(f"  进行中: {len(pending)} 个")
        print(f"  已完成: {len(completed)} 个")
        
        if pending:
            high = sum(1 for t in pending if t.get("priority") == "high")
            medium = sum(1 for t in pending if t.get("priority") == "medium")
            low = sum(1 for t in pending if t.get("priority") == "low")
            print(f"\n  进行中优先级: 🔴 {high} | 🟡 {medium} | 🟢 {low}")


if __name__ == "__main__":
    main()
