# 使用示例

## 配置API Key
首先在技能配置中设置你的智谱API Key：
```
# 环境变量方式
export ZHIPU_IMAGE_API_KEY="your_api_key_here"

# 或者在OpenClaw技能配置界面填写
```

## 示例1：生成猫咪图片
```bash
python generate_image.py "一只可爱的橘猫，躺在阳光下的地毯上，毛茸茸的，治愈系风格"
```

返回结果：
```json
{
  "success": true,
  "image_url": "https://sfile.chat.z.ai/xxxx/xxxx.png",
  "created": 1713800000,
  "prompt": "一只可爱的橘猫，躺在阳光下的地毯上，毛茸茸的，治愈系风格",
  "size": "1280x1280"
}
```

## 示例2：生成宽屏风景图
```bash
python generate_image.py "赛博朋克风格的未来城市，高楼林立，霓虹灯闪烁，下雨天，空中飞车" size=1728×960
```

## 示例3：生成竖版手机壁纸
```bash
python generate_image.py "宫崎骏风格的夏日乡村，绿色的稻田，蓝天白云，风车，小溪" size=960×1728
```

## 示例4：关闭水印
```bash
python generate_image.py "水彩风格的牡丹花，鲜艳的红色，背景是浅灰色，国画风格" watermark=false
```

## 示例5：JSON参数调用方式
```bash
python generate_image.py '{"prompt": "未来科技感的人工智能机器人，银白色金属质感，蓝色眼睛，背景是数据中心", "size": "1568×1056", "watermark": true}'
```
