# 发布说明 v1.0.0

## 版本信息
- 版本号：1.0.0
- 发布日期：2026-04-23
- 适配OpenClaw版本：>=4.10.0

## 功能介绍
这是智谱GLM-Image生图技能的首个正式版本，支持：
- 调用智谱GLM-Image模型生成高质量图片
- 支持7种常用图片尺寸，适配不同场景
- 支持水印开关控制
- 完善的错误提示和使用文档
- 零配置使用，仅需填写API Key即可

## 校验信息
- 文件大小：约10KB
- 核心文件校验：
  - skill.json: 1194 bytes
  - SKILL.md: 1016 bytes
  - generate_image.py: 3579 bytes
  - install.py: 667 bytes
  - requirements.txt: 16 bytes

## 使用说明
安装后请在技能配置中填写你的智谱开放平台API Key，获取地址：
https://bigmodel.cn/usercenter/proj-mgmt/apikeys

详细使用方法请查看SKILL.md文档。
