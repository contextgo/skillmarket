#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
技能安装脚本
"""
import subprocess
import sys
import os

def main():
    print("正在安装智谱生图技能依赖...")
    
    # 安装requirements.txt中的依赖
    req_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    
    try:
        subprocess.check_call([
            sys.executable, '-m', 'pip', 'install', '-r', req_path
        ])
        print("✅ 依赖安装成功！")
        print("\n安装完成！请在技能配置中填写你的智谱开放平台API Key。")
        print("API Key获取地址：https://bigmodel.cn/usercenter/proj-mgmt/apikeys")
    except subprocess.CalledProcessError as e:
        print(f"❌ 依赖安装失败：{e}")
        sys.exit(1)

if __name__ == "__main__":
    main()