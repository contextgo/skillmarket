#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智谱GLM-Image生图技能实现
"""
import os
import sys
import json
import requests
from typing import Optional, Dict, Any

def generate_image(
    api_key: str,
    prompt: str,
    size: str = "1280x1280",
    watermark_enabled: bool = True
) -> Dict[str, Any]:
    """
    调用智谱GLM-Image API生成图片
    """
    url = "https://open.bigmodel.cn/api/paas/v4/images/generations"
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    payload = {
        "model": "glm-image",
        "prompt": prompt,
        "size": size,
        "watermark_enabled": watermark_enabled,
        "quality": "hd"  # GLM-Image仅支持hd质量
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        error_msg = f"请求失败: {str(e)}"
        if hasattr(e, 'response') and e.response is not None:
            try:
                error_data = e.response.json()
                if 'error' in error_data:
                    error_msg += f"\n错误详情: {error_data['error']['message']} (code: {error_data['error']['code']})"
            except:
                error_msg += f"\n响应内容: {e.response.text}"
        raise Exception(error_msg)

def main():
    """
    主函数，处理工具调用参数
    """
    try:
        # 从环境变量获取配置
        api_key = os.environ.get("ZHIPU_IMAGE_API_KEY")
        if not api_key:
            print(json.dumps({
                "error": "未配置API Key，请在技能配置中填写你的智谱开放平台API Key"
            }, ensure_ascii=False))
            return
        
        # 解析工具调用参数
        if len(sys.argv) < 2:
            print(json.dumps({
                "error": "缺少参数prompt，请提供生成图片的文本描述"
            }, ensure_ascii=False))
            return
        
        # 支持两种参数传递方式：JSON字符串或者直接参数
        try:
            params = json.loads(sys.argv[1])
            prompt = params.get("prompt")
            size = params.get("size", "1280x1280")
            watermark = params.get("watermark", True)
        except json.JSONDecodeError:
            # 直接传递prompt的情况
            prompt = sys.argv[1]
            size = "1280x1280"
            watermark = True
            # 检查是否有其他参数
            for arg in sys.argv[2:]:
                if arg.startswith("size="):
                    size = arg.split("=", 1)[1]
                elif arg.startswith("watermark="):
                    watermark = arg.split("=", 1)[1].lower() in ("true", "1", "yes")
        
        if not prompt:
            print(json.dumps({
                "error": "prompt不能为空，请提供生成图片的文本描述"
            }, ensure_ascii=False))
            return
        
        # 调用API
        result = generate_image(api_key, prompt, size, watermark)
        
        # 处理返回结果
        if 'data' in result and len(result['data']) > 0:
            image_url = result['data'][0]['url']
            output = {
                "success": True,
                "image_url": image_url,
                "created": result.get('created'),
                "prompt": prompt,
                "size": size
            }
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({
                "error": "生成失败，未返回图片链接",
                "raw_response": result
            }, ensure_ascii=False))
            
    except Exception as e:
        print(json.dumps({
            "error": str(e)
        }, ensure_ascii=False))

if __name__ == "__main__":
    main()