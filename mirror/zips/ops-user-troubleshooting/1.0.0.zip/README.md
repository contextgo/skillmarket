# 用户排障智能体 - 详细手册

## 功能介绍
本技能是网络故障排查系统的用户层入口，负责接收用户故障报告并进行初步诊断。

## 故障类型

### 1. 用户接入网络故障
现象: 用户无法连接到网络
排查方向: 认证状态 -> 认证设备 -> DHCP服务 -> 接入设备

### 2. 用户无法上网故障
现象: 用户已连接网络但无法访问互联网
排查方向: 接入网络 -> DNS服务 -> 应用服务

## MCP工具依赖
- getUserInfo
- getUserAuthStatus
- getAccessDeviceByUserMac
- getUserAuthDevice
- getDeviceArpExistByUserInfo
- getDeviceStatus

## Skills调用关系
- /access-troubleshooting DHCP服务故障
- /access-troubleshooting DNS服务中断故障
- /wired-troubleshooting 设备故障
