---
name: ops.user-troubleshooting
description: |
  用户网络故障排查技能。当用户报告无法上网、无法接入网络时自动触发。
  包含两种故障类型：用户接入网络故障、用户无法上网故障。
  会根据故障现象调用相应的MCP工具获取数据，并可能调用access-troubleshooting
  和wired-troubleshooting进行深入排查。
allowed-tools:
  - getUserInfo
  - getUserAuthStatus
  - getAccessDeviceByUserMac
  - getUserAuthDevice
  - getDeviceArpExistByUserInfo
  - getDeviceStatus
---

# 用户排障智能体

## 概述
本技能用于处理用户无法上网、无法接入网络等故障。通过调用MCP工具获取用户认证状态、设备信息、ARP表项等数据，结合准入排障技能和有线排障技能进行综合故障排查。

重要：请严格按照排查步骤执行。

## 故障场景

### 场景1: 用户接入网络故障
**触发条件**: 用户提问"用户无法上网，用户接入网络是否存在故障"

**参数**: 故障时间、用户名称/MAC/IP（至少一个）、用户接入类型

**步骤**:
1. 使用 `getUserInfo` 获取用户完整信息
2. 使用 `getUserAuthStatus` 获取认证状态
   - 认证成功 → 步骤4
   - 认证失败 → 输出失败原因，结束
3. 使用 `getAccessDeviceByUserMac` 查找用户MAC所在设备
   - 不存在MAC → 步骤5
   - 存在MAC → 使用 `getUserAuthDevice` 查询认证设备
     - 设备不存在 → 输出"认证设备离线"，结束
     - 设备存在 → 步骤4
4. 使用 `getDeviceArpExistByUserInfo` 检查ARP表项
   - 存在ARP → DHCP正常，结束
   - 不存在ARP → 调用 `/access-troubleshooting DHCP服务故障`
5. 调用 `/wired-troubleshooting 设备故障`

### 场景2: 用户无法上网故障
**触发条件**: 用户提问"用户无法上网"

**参数**: 故障时间、用户名称/MAC/IP、应用名称

**步骤**:
1. 调用场景1"用户接入网络故障"排查
2. 如果接入正常，调用 `/access-troubleshooting DNS服务中断故障`
3. 如果DNS正常，输出"联系工程师处理"

## MCP工具使用说明

| 工具名称 | 用途 | 参数 |
|---------|------|------|
| getUserInfo | 根据用户名称/IP/MAC获取用户完整基本信息 | 用户名称/用户IP/用户MAC |
| getUserAuthStatus | 获取用户认证状态信息 | 故障时间、用户信息 |
| getAccessDeviceByUserMac | 查找用户MAC所在的有线接入设备 | 用户MAC地址 |
| getUserAuthDevice | 获取用户认证设备信息 | 用户信息 |
| getDeviceArpExistByUserInfo | 查询设备是否存在用户的ARP表项 | 故障时间、用户IP |
| getDeviceStatus | 查询设备是否存在 | 故障时间、设备信息 |

## 故障排查结果输出格式

每一步骤执行后，输出格式如下：
```
### 步骤X: [步骤名称]
- 执行动作: [调用了哪个MCP工具]
- 执行参数: [传入的参数]
- 执行结果: [工具返回的结果]
- 结论: [基于结果的下一步判断]
```

最终输出故障根因时，采用以下格式：
```
## 故障根因
- 故障类型: [具体故障类型]
- 故障原因: [故障原因描述]
- 建议措施: [处理建议]
```

## 调用其他Skills

- 调用准入排障技能排查DHCP服务: `/access-troubleshooting DHCP服务故障`
- 调用准入排障技能排查DNS服务: `/access-troubleshooting DNS服务中断故障`
- 调用有线排障技能排查设备故障: `/wired-troubleshooting 设备故障`
