#!/bin/bash
#
# resign_ipa.sh — iOS IPA 通用重签名脚本 (修复版)
#
# 用法:
#   ./resign_ipa.sh \
#     --ipa <原IPA路径> \
#     --cert <签名证书名称> \
#     --provision <描述文件路径> \
#     --bundle-id <新BundleID> \
#     --app-name <新App名称> \
#     [--icon <新图标路径>] \
#     [--output <输出IPA路径>] \
#     [--strip-extensions] \
#     [--no-clean] \
#     [--verbose]
#
# 示例:
#   ./resign_ipa.sh \
#     --ipa ~/Downloads/WeChat.ipa \
#     --cert "Apple Distribution: Your Name (TEAMID)" \
#     --provision ~/Desktop/my.mobileprovision \
#     --bundle-id com.example.myapp \
#     --app-name "My App" \
#     --icon ~/Desktop/icon.png \
#     --strip-extensions

set -euo pipefail

# ===================== 全局变量 =====================
IPA_PATH=""
CERT_NAME=""
PROVISION_PATH=""
NEW_BUNDLE_ID=""
NEW_APP_NAME=""
NEW_ICON_PATH=""
OUTPUT_PATH=""
STRIP_EXTENSIONS=true
NO_CLEAN=false
VERBOSE=false

# 配置文件路径
CONFIG_FILE="${HOME}/.config/ipa-resign/config"

# ===================== 帮助信息 =====================
usage() {
    cat <<EOF
iOS IPA 通用重签名脚本 (修复版)

用法:
  $(basename "$0") [选项]

必需参数:
  --ipa          <path>    原 IPA 文件路径
  --cert         <name>    签名证书名称 (如 "Apple Distribution: ...")
  --provision    <path>    .mobileprovision 描述文件路径
  --bundle-id    <id>      新的 Bundle Identifier
  --app-name     <name>    新的 App 显示名称

可选参数:
  --icon         <path>    新图标路径 (不传则保留原图标)
  --output       <path>    输出 IPA 路径 (默认: ~/Desktop/<app-name>_resigned.ipa)
  --strip-extensions  删除 App Extensions (默认开启)
  --keep-extensions   保留并重签 App Extensions
  --no-clean          不清理临时工作目录 (调试用)
  --verbose           显示详细签名信息
  --setup            显示环境检查向导
  -h, --help         显示此帮助信息

配置文件:
  支持从 ~/.config/ipa-resign/config 加载默认参数
  运行脚本会自动生成配置示例文件

示例:
  $(basename "$0") \\
    --ipa ~/Downloads/WeChat.ipa \\
    --cert "Apple Distribution: Your Name (TEAMID)" \\
    --provision ~/Desktop/my.mobileprovision \\
    --bundle-id com.example.myapp \\
    --app-name "My App" \\
    --icon ~/Desktop/icon.png
EOF
    exit 0
}

# ===================== 工具函数 =====================

# 加载配置文件
load_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        [[ "$VERBOSE" == "true" ]] && echo "📄 加载配置文件: $CONFIG_FILE"
        # shellcheck source=/dev/null
        source "$CONFIG_FILE"
    fi
}

# 保存配置示例
save_config_example() {
    local example_file="${HOME}/.config/ipa-resign/config.example"
    mkdir -p "$(dirname "$example_file")"
    cat > "$example_file" << 'EOF'
# IPA Resign 配置文件示例
# 复制此文件为 config 并填入你的信息

# 默认签名证书 (从 Keychain 获取完整名称)
# CERT_NAME="Apple Distribution: Your Name (TEAMID)"

# 默认描述文件路径
# PROVISION_PATH="$HOME/Desktop/my.mobileprovision"

# 默认输出目录
# OUTPUT_DIR="$HOME/Desktop"
EOF
    echo "📝 配置文件示例已保存: $example_file"
}

# 检查前置工具
check_dependencies() {
    local missing=()
    
    # 常规工具 (在 PATH 或 /usr/bin 中)
    for cmd in unzip codesign security zip; do
        if ! command -v "$cmd" &>/dev/null; then
            missing+=("$cmd")
        fi
    done
    
    # PlistBuddy 在 /usr/libexec 中
    if ! [[ -x "/usr/libexec/PlistBuddy" ]]; then
        missing+=("PlistBuddy")
    fi
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        echo "❌ 缺少必要工具: ${missing[*]}"
        echo "   请安装 Xcode Command Line Tools: xcode-select --install"
        exit 1
    fi
    
    # 检查是否为 macOS
    if [[ "$(uname)" != "Darwin" ]]; then
        echo "⚠️ 警告: 此脚本仅支持 macOS"
    fi
}

# 安全设置 Plist 值 (先 Add 再 Set)
plist_set() {
    local key="$1"
    local type="$2"
    local value="$3"
    local plist="$4"
    
    # 先尝试 Set，如果失败则 Add
    if ! /usr/libexec/PlistBuddy -c "Set :$key $value" "$plist" 2>/dev/null; then
        /usr/libexec/PlistBuddy -c "Add :$key $type $value" "$plist"
    fi
}

# 递归签名框架和动态库 (深度优先)
sign_code_recursive() {
    local target="$1"
    local cert="$2"
    local entitlements="$3"
    local verbose="$4"
    
    # 先递归签内嵌的 framework/dylib
    if [[ -d "$target" ]]; then
        # 签内嵌的 frameworks
        for embedded in "$target"/*.framework; do
            [[ -e "$embedded" ]] && sign_code_recursive "$embedded" "$cert" "" "$verbose"
        done
        # 签内嵌的 dylibs
        for embedded in "$target"/*.dylib; do
            [[ -e "$embedded" ]] && sign_code_recursive "$embedded" "$cert" "" "$verbose"
        done
    fi
    
    # 签名当前目标 (framework/dylib 不带 entitlements)
    local sign_args=("-f" "-s" "$cert")
    
    # 只有主 app 或 .app bundle 才带 entitlements
    if [[ -n "$entitlements" && "$target" == *.app ]]; then
        sign_args+=("--entitlements" "$entitlements")
    fi
    
    [[ "$verbose" == "true" ]] && echo "   签名: $target"
    codesign "${sign_args[@]}" "$target"
}

# 清理临时 plist 文件
cleanup_plists() {
    local app_dir="$1"
    rm -f "$app_dir/profile.plist" "$app_dir/entitlements.plist" 2>/dev/null || true
}

# 环境检查向导
setup_wizard() {
    echo "🔧 IPA Resign 环境检查向导"
    echo ""
    
    echo "📋 可用签名证书:"
    security find-identity -v -p codesigning 2>/dev/null | grep -E '^\s+\d+\)' | sed 's/^/  /' || echo "  (未找到证书，请安装 Xcode 并登录 Apple Developer)"
    echo ""
    
    echo "📋 配置文件位置: ~/.config/ipa-resign/config"
    if [[ -f "$CONFIG_FILE" ]]; then
        echo "  ✅ 配置文件已存在"
        echo "  内容预览:"
        grep -v '^#' "$CONFIG_FILE" | grep -v '^$' | sed 's/^/    /'
    else
        echo "  ❌ 配置文件不存在"
        echo "  首次运行脚本会自动生成示例配置"
    fi
    echo ""
    
    echo "📋 快速开始:"
    echo "  1. 从上面选择你的证书名称"
    echo "  2. 准备 .mobileprovision 描述文件"
    echo "  3. 运行: ./resign_ipa.sh --ipa xxx.ipa --cert '证书名' --provision xxx.mobileprovision --bundle-id com.example.app --app-name 'App名称'"
    
    exit 0
}

# ===================== 参数解析 =====================

# 生成配置示例 (首次运行，在参数解析前)
if [[ ! -f "$CONFIG_FILE" ]]; then
    mkdir -p "$(dirname "$CONFIG_FILE")"
    save_config_example
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        --setup)
            setup_wizard ;;
        --ipa)
            IPA_PATH="$2"; shift 2 ;;
        --cert)
            CERT_NAME="$2"; shift 2 ;;
        --provision)
            PROVISION_PATH="$2"; shift 2 ;;
        --bundle-id)
            NEW_BUNDLE_ID="$2"; shift 2 ;;
        --app-name)
            NEW_APP_NAME="$2"; shift 2 ;;
        --icon)
            NEW_ICON_PATH="$2"; shift 2 ;;
        --output)
            OUTPUT_PATH="$2"; shift 2 ;;
        --strip-extensions)
            STRIP_EXTENSIONS=true; shift ;;
        --keep-extensions)
            STRIP_EXTENSIONS=false; shift ;;
        --no-clean)
            NO_CLEAN=true; shift ;;
        --verbose)
            VERBOSE=true; shift ;;
        -h|--help)
            usage ;;
        *)
            echo "❌ 未知参数: $1"
            usage
            ;;
    esac
done

# ===================== 参数校验 =====================
MISSING=()
[[ -z "$IPA_PATH" ]]       && MISSING+=("--ipa")
[[ -z "$CERT_NAME" ]]      && MISSING+=("--cert")
[[ -z "$PROVISION_PATH" ]] && MISSING+=("--provision")
[[ -z "$NEW_BUNDLE_ID" ]]  && MISSING+=("--bundle-id")
[[ -z "$NEW_APP_NAME" ]]   && MISSING+=("--app-name")

if [[ ${#MISSING[@]} -gt 0 ]]; then
    echo "❌ 缺少必需参数: ${MISSING[*]}"
    echo "   运行 $(basename "$0") --help 查看用法"
    exit 1
fi

if [[ ! -f "$IPA_PATH" ]]; then
    echo "❌ IPA 文件不存在: $IPA_PATH"
    exit 1
fi

if [[ ! -f "$PROVISION_PATH" ]]; then
    echo "❌ 描述文件不存在: $PROVISION_PATH"
    exit 1
fi

if [[ -n "$NEW_ICON_PATH" && ! -f "$NEW_ICON_PATH" ]]; then
    echo "❌ 图标文件不存在: $NEW_ICON_PATH"
    exit 1
fi

# 验证证书是否存在
if ! security find-identity -v -p codesigning | grep -q "$CERT_NAME"; then
    echo "⚠️ 警告: 证书 '$CERT_NAME' 未找到"
    echo "   可用证书:"
    security find-identity -v -p codesigning | sed 's/^/     /'
fi

# 默认输出路径
if [[ -z "$OUTPUT_PATH" ]]; then
    OUTPUT_PATH="$HOME/Desktop/${NEW_APP_NAME}_resigned.ipa"
fi

# ===================== 开始处理 =====================

# 加载配置文件 (如果存在)
load_config

check_dependencies

WORK_DIR=$(mktemp -d "${TMPDIR:-/tmp}/ipa_resign.XXXXXX")

echo "🔧 开始重签名..."
echo "   IPA:       $IPA_PATH"
echo "   证书:      $CERT_NAME"
echo "   描述文件:  $PROVISION_PATH"
echo "   Bundle ID: $NEW_BUNDLE_ID"
echo "   App 名称:  $NEW_APP_NAME"
[[ -n "$NEW_ICON_PATH" ]] && echo "   图标:      $NEW_ICON_PATH"
echo "   Extension: $([ "$STRIP_EXTENSIONS" == "true" ] && echo "删除" || echo "保留")"
echo "   输出:      $OUTPUT_PATH"
echo ""

# 解压 IPA
echo "📦 解压 IPA..."
unzip -q "$IPA_PATH" -d "$WORK_DIR"
cd "$WORK_DIR/Payload"/*.app || { echo "❌ 未找到 .app 目录"; exit 1; }
APP_DIR="$(pwd)"

# 处理 Extension
if [[ "$STRIP_EXTENSIONS" == "true" ]]; then
    echo "🗑️  删除 PlugIns / Watch / _CodeSignature..."
    rm -rf _CodeSignature PlugIns Watch
else
    echo "📝 保留 Extensions (将重签)..."
    rm -rf _CodeSignature
fi

# 清理可能残留的旧签名
rm -rf _CodeSignature 2>/dev/null || true

# 替换描述文件
echo "🔑 替换描述文件..."
cp "$PROVISION_PATH" embedded.mobileprovision

# 提取 entitlements
echo "📋 提取 entitlements..."
security cms -D -i embedded.mobileprovision > profile.plist
/usr/libexec/PlistBuddy -x -c "Print:Entitlements" profile.plist > entitlements.plist

# 修改 Bundle ID 和 App 名称 (安全的 Set/Add 方式)
echo "📝 修改 Bundle ID: $NEW_BUNDLE_ID"
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $NEW_BUNDLE_ID" Info.plist 2>/dev/null || \
    /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string $NEW_BUNDLE_ID" Info.plist

echo "📝 修改 App 名称: $NEW_APP_NAME"
/usr/libexec/PlistBuddy -c "Set :CFBundleName $NEW_APP_NAME" Info.plist 2>/dev/null || \
    /usr/libexec/PlistBuddy -c "Add :CFBundleName string $NEW_APP_NAME" Info.plist

# CFBundleDisplayName 可能不存在
if /usr/libexec/PlistBuddy -c "Print :CFBundleDisplayName" Info.plist &>/dev/null; then
    /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName $NEW_APP_NAME" Info.plist
else
    /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string $NEW_APP_NAME" Info.plist
fi

# 删除多语言名称配置 (只删可能影响显示的)
echo "📝 清除多语言名称配置..."
for lang in zh_CN.lproj zh_TW.lproj en.lproj; do
    if [[ -d "$lang" ]]; then
        rm -f "$lang/InfoPlist.strings" 2>/dev/null || true
    fi
done

# 替换图标 (可选)
if [[ -n "$NEW_ICON_PATH" ]]; then
    echo "🖼️  替换图标..."
    while IFS= read -r icon; do
        [[ -n "$icon" ]] && cp "$NEW_ICON_PATH" "$icon"
        [[ "$VERBOSE" == "true" ]] && echo "   替换: $icon"
    done < <(find . -name "AppIcon*.png" -o -name "Icon*.png" 2>/dev/null)
    
    # DisplayIcon (主屏显示用)
    [[ -f "DisplayIcon@2x.png" ]] && cp "$NEW_ICON_PATH" "DisplayIcon@2x.png"
    [[ -f "DisplayIcon@3x.png" ]] && cp "$NEW_ICON_PATH" "DisplayIcon@3x.png"
fi

# ===================== 签名 =====================

# 签名 Frameworks (不带 entitlements, 递归处理内嵌)
echo "✍️  签名 Frameworks (深度优先)..."
if [[ -d Frameworks ]]; then
    for fw in Frameworks/*.framework; do
        [[ -e "$fw" ]] && sign_code_recursive "$fw" "$CERT_NAME" "" "$VERBOSE"
    done
    for dylib in Frameworks/*.dylib; do
        [[ -e "$dylib" ]] && sign_code_recursive "$dylib" "$CERT_NAME" "" "$VERBOSE"
    done
fi

# 签名 App Extensions (可选)
if [[ -d PlugIns ]]; then
    echo "✍️  签名 App Extensions..."
    for ext in PlugIns/*.appex; do
        [[ -e "$ext" ]] && sign_code_recursive "$ext" "$CERT_NAME" "entitlements.plist" "$VERBOSE"
    done
fi

# 签名主 App (带 entitlements)
echo "✍️  签名主 App..."
if [[ "$VERBOSE" == "true" ]]; then
    codesign -dv --entitlements entitlements.plist "$APP_DIR"
fi
codesign -f -s "$CERT_NAME" --entitlements entitlements.plist "$APP_DIR"

# 验证签名
echo "✅ 验证签名..."
if codesign --verify --verbose=2 "$APP_DIR" 2>&1 | grep -q "valid"; then
    echo "   签名验证通过"
else
    echo "⚠️ 签名验证: $(codesign --verify --verbose=1 "$APP_DIR" 2>&1 | head -1)"
fi

# 清理临时 plist 文件
cleanup_plists "$APP_DIR"

# 打包 IPA
echo "📦 打包 IPA..."
cd "$WORK_DIR"
zip -qyr9 resigned.ipa Payload

# 移动到输出路径
mkdir -p "$(dirname "$OUTPUT_PATH")"
mv "$WORK_DIR/resigned.ipa" "$OUTPUT_PATH"

# 清理
if [[ "$NO_CLEAN" == "false" ]]; then
    echo "🧹 清理临时文件..."
    rm -rf "$WORK_DIR"
else
    echo "📁 临时目录保留: $WORK_DIR"
fi

echo ""
echo "✅ 重签名完成！"
echo "   输出文件: $OUTPUT_PATH"
echo "   App 名称: $NEW_APP_NAME"
echo "   Bundle ID: $NEW_BUNDLE_ID"
[[ -n "$NEW_ICON_PATH" ]] && echo "   图标已替换"
