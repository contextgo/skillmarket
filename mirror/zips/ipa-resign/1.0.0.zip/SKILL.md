---
name: ipa-resign
description: |
  iOS IPA 重签名工具。对 IPA 文件进行重签名，支持修改 Bundle ID、App 名称、应用图标。
  适用于企业分发、内测、TestFlight 签名等场景。

  触发场景:
  - "重签名"、"resign"、"重签IPA"
  - "iOS IPA 签名"、"iOS 重签"
  - "企业签名"、"自签IPA"
  - "修改 Bundle ID"、"改 App 名称"
  - "帮我签一下这个 IPA"
---

# iOS IPA 重签名

## 快速开始

### 环境检查（推荐首次运行）

```bash
./resign_ipa.sh --setup
```

这会显示：
- 可用的签名证书列表
- 配置文件状态
- 快速开始指引

### 方式一：命令行参数（适合临时使用）

```bash
cd ~/.qclaw/skills/ipa-resign/scripts
./resign_ipa.sh \
  --ipa ~/Downloads/xxx.ipa \
  --cert "Apple Distribution: Your Name (TEAMID)" \
  --provision ~/Desktop/my.mobileprovision \
  --bundle-id com.example.myapp \
  --app-name "My App"
```

### 方式二：配置文件（适合常用设置）

1. **创建配置目录和文件**:
   ```bash
   mkdir -p ~/.config/ipa-resign
   cat > ~/.config/ipa-resign/config << 'EOF'
   CERT_NAME="Apple Distribution: Your Name (TEAMID)"
   PROVISION_PATH="$HOME/Desktop/my.mobileprovision"
   EOF
   ```

2. **简化命令**:
   ```bash
   ./resign_ipa.sh \
     --ipa ~/Downloads/xxx.ipa \
     --bundle-id com.example.myapp \
     --app-name "My App"
   ```

## 参数说明

| 参数 | 必需 | 说明 |
|------|------|------|
| `--ipa` | ✅ | 原 IPA 文件路径 |
| `--cert` | ✅* | 签名证书名称 (完整名称, *可从配置文件读取) |
| `--provision` | ✅* | .mobileprovision 描述文件路径 (*可从配置文件读取) |
| `--bundle-id` | ✅ | 新的 Bundle Identifier |
| `--app-name` | ✅ | 新的 App 显示名称 |
| `--icon` | ❌ | 新图标路径 (PNG, 不传保留原图标) |
| `--output` | ❌ | 输出 IPA 路径 (默认 ~/Desktop/<app-name>_resigned.ipa) |
| `--strip-extensions` | ❌ | 删除 App Extensions (默认开启) |
| `--keep-extensions` | ❌ | 保留并重签 App Extensions |
| `--no-clean` | ❌ | 调试模式，保留临时工作目录 |
| `--verbose` | ❌ | 显示详细签名信息 |
| `--setup` | ❌ | 显示环境检查向导 |
| `-h, --help` | ❌ | 显示帮助信息 |

## 签名类型

- **AdHoc**: 内测分发，需要 AdHoc 描述文件
- **Enterprise**: 企业签名，需要 Enterprise 描述文件
- **App Store**: 上架签名，需要 App Store 描述文件
- **Development**: 开发调试，需要 Development 描述文件

## 常见问题

### 1. 证书找不到
运行 `security find-identity -v -p codesigning` 确认证书名称完整匹配。

### 2. 描述文件类型不匹配
确保描述文件的 `ProvisionedDevices` 或 `TeamIdentifier` 与证书匹配。

### 3. 安装后闪退
- 检查 entitlements 是否正确
- 尝试 `--keep-extensions` 保留 Extension
- 确认 Bundle ID 与描述文件匹配

### 4. 图标未生效
部分 App 图标在 Assets.car 中编译，PNG 替换无效。此时需要用其他工具修改 Assets.car。

## 输出

成功后会生成新的 IPA 文件，可通过以下方式安装:
- Xcode → Window → Devices → Drag & Drop
- `idevicedeploy` 命令行工具
- 爱思助手等第三方工具
