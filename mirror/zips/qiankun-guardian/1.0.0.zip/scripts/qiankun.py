#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
乾坤大挪移·安全卫士 - 主脚本 v1.0.0
全场景责任边界管理工具

功能模块：
1. 场景诊断 (scenario_diagnosis)
2. 话术生成 (script_generation)
3. 权力动态分析 (power_dynamics_analysis)
4. 证据作战计划 (evidence_plan)
5. 升级路径规划 (escalation_path)
6. 时间线还原 (timeline_analysis)
7. 预判与应对 (prediction_and_response)
"""

import json
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field
from pathlib import Path
from datetime import datetime


@dataclass
class ScenarioDiagnosis:
    """场景诊断结果"""
    scene_type: str  # 场景大类
    sub_type: str    # 场景子类
    boundary_status: str  # 边界状态：A/B/C/D类
    responsibility_chain: List[Dict]  # 责任链条分析
    risk_level: str  # 风险等级
    diagnosis_summary: str  # 诊断总结


@dataclass
class ScriptResponse:
    """话术生成结果"""
    style: str  # 风格
    script: Dict[str, str]  # 话术各部分
    usage_tips: List[str]  # 使用提示
    alternatives: List[str]  # 备选话术


@dataclass
class PowerDynamicsResult:
    """权力动态分析结果"""
    your_power_score: float  # 你的筹码总分
    opponent_power_score: float  # 对方筹码总分
    power_balance: str  # 权力对比
    strengths: List[str]  # 你的优势
    weaknesses: List[str]  # 你的劣势
    strategies: List[Dict]  # 推荐策略
    warnings: List[str]  # 风险预警


@dataclass
class EvidencePlanResult:
    """证据作战计划结果"""
    evidence_needed: List[Dict]  # 需要收集的证据
    evidence_status: Dict[str, str]  # 证据收集状态
    chain_analysis: List[Dict]  # 证据链条分析
    usage_strategy: str  # 使用策略建议
    collection_plan: List[str]  # 收集计划


@dataclass
class EscalationPathResult:
    """升级路径结果"""
    current_level: int  # 当前路径级别
    next_level: int  # 下一步级别
    escalation_path: List[Dict]  # 完整升级路径
    timing_check: List[str]  # 时机判断
    next_script: Dict[str, str]  # 下一步话术
    warnings: List[str]  # 注意事项


@dataclass
class TimelineResult:
    """时间线还原结果"""
    key_events: List[Dict]  # 关键事件
    responsibility_nodes: List[Dict]  # 责任节点
    causal_chain: List[str]  # 因果链条
    conclusion: str  # 结论
    timeline_text: str  # 可视化时间线


@dataclass
class PredictionResult:
    """预判与应对结果"""
    possible_responses: List[Dict]  # 对方可能的反应
    recommended_responses: List[Dict]  # 推荐应对
   博弈_tree: str  # 博弈树可视化


class QiankunGuardian:
    """乾坤大挪移·安全卫士主类"""
    
    def __init__(self, data_path: str = None):
        """初始化，加载数据文件"""
        if data_path is None:
            data_path = Path(__file__).parent.parent / "data"
        else:
            data_path = Path(data_path)
        
        self.data_path = data_path
        self.scenarios = self._load_json("common_scenarios.json")
        self.templates = self._load_json("response_templates.json")
        self.power_data = self._load_json("power_dynamics.json")
        self.evidence_tactics = self._load_json("evidence_tactics.json")
        self.escalation_paths = self._load_json("escalation_paths.json")
        
        # 场景类型映射
        self.scene_keywords = {
            "职场": ["领导", "上司", "老板", "同事", "工作", "项目", "方案", "报告", "开会", "晋升", "绩效", "公司", "同事", "上级"],
            "家庭": ["父母", "家人", "亲戚", "兄弟姐妹", "结婚", "买房", "分家", "过年", "红包", "妈妈", "爸爸", "妈", "爸"],
            "社交": ["朋友", "闺蜜", "兄弟", "聚会", "借钱", "随礼", "帮忙", "朋友"],
            "消费": ["商家", "网购", "退货", "退款", "投诉", "客服", "保修", "质量", "买", "购物", "订单"],
            "邻里": ["邻居", "物业", "漏水", "噪音", "装修", "公共区域", "楼上下"]
        }
        
        # 边界状态关键词
        self.boundary_keywords = {
            "A类-清晰边界": ["明确分工", "各司其职", "岗位职责", "合同规定", "约定好了"],
            "B类-模糊边界": ["灰色地带", "职责交叉", "没说清楚", "需要协商", "分不清"],
            "C类-错位边界": ["甩锅", "推卸", "归咎", "赖我", "怪我", "背锅", "都是你的错", "责任在我"],
            "D类-入侵边界": ["越界", "干涉", "管太多", "多管闲事", "凭什么", "瞎操心"]
        }
        
        # 风险等级评估关键词
        self.risk_keywords = {
            "高风险": ["法律", "赔偿", "开除", "损失", "大额", "严重", "追究", "报警", "法院", "仲裁"],
            "中风险": ["影响", "绩效", "关系", "名声", "声誉", "可能", "担心"],
            "低风险": ["小事", "无所谓", "没影响", "轻微", "无关紧要"]
        }

    def _load_json(self, filename: str) -> Dict:
        """加载JSON数据文件"""
        try:
            filepath = self.data_path / filename
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"加载{filename}失败: {e}")
        return {}
    
    def diagnose(self, situation: str) -> ScenarioDiagnosis:
        """场景诊断：分析情况，判断责任边界"""
        # 1. 识别场景类型
        scene_type = self._identify_scene(situation)
        
        # 2. 判断边界状态
        boundary_status = self._identify_boundary(situation)
        
        # 3. 分析责任链条
        responsibility_chain = self._analyze_responsibility(situation)
        
        # 4. 评估风险等级
        risk_level = self._assess_risk(situation)
        
        # 5. 生成诊断总结
        summary = self._generate_diagnosis_summary(
            scene_type, boundary_status, responsibility_chain, risk_level
        )
        
        return ScenarioDiagnosis(
            scene_type=scene_type,
            sub_type=self._identify_sub_type(situation, scene_type),
            boundary_status=boundary_status,
            responsibility_chain=responsibility_chain,
            risk_level=risk_level,
            diagnosis_summary=summary
        )
    
    def _identify_scene(self, situation: str) -> str:
        """识别场景类型"""
        situation_lower = situation.lower()
        scores = {}
        
        for scene, keywords in self.scene_keywords.items():
            score = sum(1 for kw in keywords if kw in situation_lower)
            if score > 0:
                scores[scene] = score
        
        if scores:
            return max(scores, key=scores.get)
        return "通用"
    
    def _identify_sub_type(self, situation: str, scene_type: str) -> str:
        """识别场景子类"""
        situation_lower = situation.lower()
        
        sub_type_mapping = {
            "职场": {
                "上级甩锅": ["甩锅", "领导说", "上司", "老板怪", "被追责"],
                "同事推诿": ["同事", "推诿", "不配合", "扯皮", "踢皮球"],
                "跨部门纠纷": ["跨部门", "其他部门", "配合"],
                "绩效考核": ["绩效", "考核", "评分", "评级"]
            },
            "家庭": {
                "经济请求": ["借钱", "给钱", "资助", "买房", "买车"],
                "隐私干涉": ["管", "干涉", "催婚", "催生", "问"],
                "家务分配": ["家务", "做饭", "打扫", "照顾"]
            },
            "消费": {
                "售后推诿": ["售后", "退货", "退款", "换货", "维修"],
                "虚假宣传": ["虚假", "骗", "宣传", "广告"],
                "质量问题": ["坏了", "质量", "瑕疵", "问题"]
            }
        }
        
        if scene_type in sub_type_mapping:
            for sub_type, keywords in sub_type_mapping[scene_type].items():
                if any(kw in situation_lower for kw in keywords):
                    return sub_type
        
        return "一般情况"
    
    def _identify_boundary(self, situation: str) -> str:
        """判断边界状态"""
        situation_lower = situation.lower()
        
        for boundary_type, keywords in self.boundary_keywords.items():
            if any(kw in situation_lower for kw in keywords):
                return boundary_type
        
        return "B类-模糊边界"
    
    def _analyze_responsibility(self, situation: str) -> List[Dict]:
        """分析责任链条"""
        chain = []
        roles = self._extract_roles(situation)
        
        for i, role in enumerate(roles):
            chain.append({
                "index": i + 1,
                "role": role["name"],
                "role_type": role["type"],
                "responsibility": self._assess_role_responsibility(role, situation),
                "evidence_needed": self._get_evidence_hints(role, situation)
            })
        
        return chain
    
    def _extract_roles(self, situation: str) -> List[Dict]:
        """提取角色信息"""
        roles = []
        
        role_patterns = {
            "上级": ["领导", "上司", "老板", "经理", "主管"],
            "同事": ["同事", "小王", "小李", "小张"],
            "下属": ["下属", "员工", "团队成员"],
            "家人": ["父母", "爸爸", "妈妈", "老公", "老婆", "亲戚", "表哥", "表姐"],
            "朋友": ["朋友", "闺蜜", "兄弟"],
            "商家": ["商家", "卖家", "客服", "店家"],
            "第三方": ["客户", "甲方", "乙方", "第三方"]
        }
        
        found_roles = set()
        for role_type, keywords in role_patterns.items():
            for kw in keywords:
                if kw in situation:
                    if kw not in found_roles:
                        roles.append({
                            "name": kw,
                            "type": role_type
                        })
                        found_roles.add(kw)
                    break
        
        if not roles:
            roles.append({"name": "相关方", "type": "未知"})
        
        return roles
    
    def _assess_role_responsibility(self, role: Dict, situation: str) -> str:
        """评估角色责任"""
        situation_lower = situation.lower()
        role_lower = role["name"].lower()
        
        responsible_keywords = ["负责", "承担", "主导", "决策", "执行"]
        blame_keywords = ["怪", "甩锅", "归咎", "赖", "怪罪", "指责", "都是"]
        
        if role_lower in situation_lower:
            if any(kw in situation_lower for kw in blame_keywords):
                return "被追责方（可能是责任错位）"
            if role["type"] == "上级":
                return "决策/监督责任"
            elif role["type"] == "同事":
                return "执行/配合责任"
            elif role["type"] == "商家":
                return "产品/服务责任"
        
        return "需进一步分析"
    
    def _get_evidence_hints(self, role: Dict, situation: str) -> List[str]:
        """获取需要的证据提示"""
        hints = []
        
        if role["type"] in ["上级", "同事"]:
            hints.extend(["书面分工记录", "邮件沟通记录", "聊天记录截图", "会议纪要"])
        elif role["type"] == "商家":
            hints.extend(["购买凭证", "聊天记录", "产品照片", "鉴定报告"])
        elif role["type"] == "家人":
            hints.extend(["通话录音", "聊天记录", "转账记录"])
        
        return hints[:3]
    
    def _assess_risk(self, situation: str) -> str:
        """评估风险等级"""
        situation_lower = situation.lower()
        
        for risk_level, keywords in self.risk_keywords.items():
            if any(kw in situation_lower for kw in keywords):
                return risk_level
        
        return "中风险"
    
    def _generate_diagnosis_summary(
        self, 
        scene_type: str, 
        boundary_status: str, 
        chain: List[Dict],
        risk_level: str
    ) -> str:
        """生成诊断总结"""
        summary_parts = []
        
        summary_parts.append(f"📌 场景类型：{scene_type}")
        
        boundary_emoji = {
            "A类-清晰边界": "✅",
            "B类-模糊边界": "⚠️",
            "C类-错位边界": "❌",
            "D类-入侵边界": "🚫"
        }
        emoji = boundary_emoji.get(boundary_status, "❓")
        summary_parts.append(f"{emoji} 边界状态：{boundary_status}")
        
        summary_parts.append("📊 责任链分析：")
        for item in chain:
            summary_parts.append(f"   {item['index']}. {item['role']}（{item['role_type']}）- {item['responsibility']}")
        
        risk_emoji = {"高风险": "🔴", "中风险": "🟡", "低风险": "🟢"}
        summary_parts.append(f"{risk_emoji.get(risk_level, '⚪')} 风险等级：{risk_level}")
        
        if boundary_status == "C类-错位边界":
            summary_parts.append("\n💡 核心判断：存在明显的责任错位，需要还原事实、明确责任归属。")
        elif boundary_status == "D类-入侵边界":
            summary_parts.append("\n💡 核心判断：边界被入侵，需要温和但坚定地设立边界。")
        elif boundary_status == "B类-模糊边界":
            summary_parts.append("\n💡 核心判断：责任边界模糊，建议通过沟通明确各方的责任范围。")
        
        return "\n".join(summary_parts)
    
    def generate_script(
        self, 
        situation: str, 
        style: str = "professional",
        diagnosis: ScenarioDiagnosis = None
    ) -> ScriptResponse:
        """生成回应话术"""
        
        if diagnosis is None:
            diagnosis = self.diagnose(situation)
        
        script_parts = self._build_script(situation, diagnosis, style)
        tips = self._generate_usage_tips(diagnosis, style)
        alternatives = self._generate_alternatives(situation, diagnosis, style)
        
        return ScriptResponse(
            style=style,
            script=script_parts,
            usage_tips=tips,
            alternatives=alternatives
        )
    
    def _build_script(
        self, 
        situation: str, 
        diagnosis: ScenarioDiagnosis,
        style: str
    ) -> Dict[str, str]:
        """构建话术各部分"""
        
        style_configs = {
            "gentle": {
                "opening_patterns": [
                    "我理解你的想法/感受，",
                    "你说的这个问题，我也有注意到，",
                    "其实我也一直在考虑这件事，"
                ],
                "statement_intro": "不过我想补充一个情况",
                "boundary_intro": "关于责任的划分，我觉得需要说明一下",
                "solution_intro": "要不我们这样来处理",
                "action_intro": "具体我们可以"
            },
            "professional": {
                "opening_patterns": [
                    "关于这个情况，",
                    "针对刚才提到的问题，",
                    "根据目前的客观事实，"
                ],
                "statement_intro": "需要澄清的是",
                "boundary_intro": "关于责任归属，建议基于事实进行判断",
                "solution_intro": "我的建议是",
                "action_intro": "建议下一步"
            },
            "firm": {
                "opening_patterns": [
                    "关于这件事，",
                    "我需要明确说明，",
                    "这里有一个重要的事实需要澄清，"
                ],
                "statement_intro": "事实是",
                "boundary_intro": "这部分责任不应该由我承担",
                "solution_intro": "合理的解决方案应该是",
                "action_intro": "我将"
            },
            "humorous": {
                "opening_patterns": [
                    "哎呀，这个问题有意思，",
                    "让我想想怎么说，",
                    "怎么说呢，这个问题有点绕，"
                ],
                "statement_intro": "不过真相是",
                "boundary_intro": "这锅我可不背哈",
                "solution_intro": "不如我们这样",
                "action_intro": "干脆"
            }
        }
        
        config = style_configs.get(style, style_configs["professional"])
        
        opening = self._select_opening(situation, config["opening_patterns"], style)
        statement = self._build_statement(situation, diagnosis, config["statement_intro"])
        boundary = self._build_boundary(diagnosis, config["boundary_intro"])
        solution = self._build_solution(diagnosis, config["solution_intro"])
        action = self._build_action(diagnosis, config["action_intro"])
        
        return {
            "opening": opening,
            "statement": statement,
            "boundary": boundary,
            "solution": solution,
            "action": action,
            "full_script": f"{opening}\n\n{statement}\n\n{boundary}\n\n{solution}\n\n{action}"
        }
    
    def _select_opening(self, situation: str, patterns: List[str], style: str) -> str:
        """选择开场白"""
        import random
        pattern = random.choice(patterns)
        
        if "领导" in situation or "上司" in situation:
            return f"{pattern}关于这次的工作情况，"
        elif "父母" in situation or "家人" in situation:
            return f"{pattern}关于这件事，"
        elif "商家" in situation or "客服" in situation:
            return f"{pattern}关于这次购物体验，"
        elif "朋友" in situation:
            return f"{pattern}关于咱俩的事，"
        
        return f"{pattern}我想说一下我的看法，"
    
    def _build_statement(
        self, 
        situation: str, 
        diagnosis: ScenarioDiagnosis,
        intro: str
    ) -> str:
        """构建事实陈述"""
        facts = []
        
        for role_info in diagnosis.responsibility_chain:
            if role_info["responsibility"] and "不是" not in role_info["responsibility"]:
                facts.append(f"{role_info['role']}在{role_info['responsibility']}")
        
        if facts:
            fact_text = "；".join(facts[:2])
            return f"{intro}：{fact_text}。"
        
        return f"{intro}当时的情况是这样的：[请根据实际情况填写具体事实]"
    
    def _build_boundary(self, diagnosis: ScenarioDiagnosis, intro: str) -> str:
        """构建边界声明"""
        if diagnosis.boundary_status == "C类-错位边界":
            return f"{intro}。根据实际情况，这部分工作的决策/指导责任应该在{diagnosis.responsibility_chain[0]['role'] if diagnosis.responsibility_chain else '相关方'}，执行层面的问题不能完全归咎于我。"
        elif diagnosis.boundary_status == "D类-入侵边界":
            return f"{intro}。这是我的私人事务/决定范围，希望能够尊重我的选择。"
        elif diagnosis.boundary_status == "B类-模糊边界":
            return f"{intro}。建议我们重新明确一下各自的职责范围，避免类似的情况再次发生。"
        else:
            return f"{intro}。从现有情况看，各方的责任是清晰的。"
    
    def _build_solution(self, diagnosis: ScenarioDiagnosis, intro: str) -> str:
        """构建解决方案"""
        if diagnosis.risk_level == "高风险":
            return f"{intro}：1) 保留所有相关证据；2) 建议通过正式渠道（如HR/法务/消费者协会）处理；3) 在问题解决前保持冷静，避免冲动表态。"
        elif diagnosis.risk_level == "中风险":
            return f"{intro}：1) 先私下沟通还原事实；2) 协商调整责任划分；3) 必要时请第三方协调。"
        else:
            return f"{intro}：通过友好沟通，明确各自的责任边界，避免影响关系。"
    
    def _build_action(self, diagnosis: ScenarioDiagnosis, intro: str) -> str:
        """构建行动指引"""
        actions = []
        
        all_evidence = []
        for role_info in diagnosis.responsibility_chain:
            all_evidence.extend(role_info.get("evidence_needed", []))
        
        if all_evidence:
            unique_evidence = list(set(all_evidence))[:3]
            actions.append(f"立即：整理并保存{unique_evidence[0]}等证据")
        
        actions.append("近期：与相关方进行坦诚沟通")
        actions.append("长期：建立边界意识，预防类似问题")
        
        return f"{intro}：\n" + "\n".join([f"{i+1}. {a}" for i, a in enumerate(actions)])
    
    def _generate_usage_tips(self, diagnosis: ScenarioDiagnosis, style: str) -> List[str]:
        """生成使用提示"""
        tips = []
        
        if diagnosis.risk_level == "高风险":
            tips.append("⚠️ 此场景风险较高，建议谨慎处理")
        
        if diagnosis.boundary_status == "C类-错位边界":
            tips.append("重点：还原事实链条，明确责任归属")
        
        if style == "firm":
            tips.append("注意：坚定风格可能引发冲突，请确保有充分证据支持")
        
        tips.append("建议：先私下沟通，再决定是否需要升级")
        
        return tips
    
    def _generate_alternatives(self, situation: str, diagnosis: ScenarioDiagnosis, style: str) -> List[str]:
        """生成备选话术"""
        alternatives = []
        
        for alt_style in ["gentle", "professional", "firm"]:
            if alt_style != style:
                alt_script = self._build_script(situation, diagnosis, alt_style)
                alternatives.append(f"【{alt_style}风格】\n{alt_script['full_script'][:200]}...")
        
        return alternatives
    
    # ==================== 新增功能模块 ====================
    
    def analyze_power_dynamics(self, situation: str, opponent: str = None) -> PowerDynamicsResult:
        """
        权力动态分析
        分析双方权力关系、筹码分布
        """
        diagnosis = self.diagnose(situation)
        
        # 识别对方角色
        roles = self._extract_roles(situation)
        opponent_role = opponent or (roles[0]["type"] if roles else "未知")
        
        # 基础分数（可根据实际情况调整）
        your_scores = {
            "position_power": 2.0,
            "information_power": 3.0,
            "relationship_power": 2.5,
            "expertise_power": 3.0
        }
        
        opponent_scores = {
            "position_power": 4.0 if opponent_role in ["上级", "商家"] else 2.0,
            "information_power": 3.0,
            "relationship_power": 2.0,
            "expertise_power": 2.5
        }
        
        # 权重
        weights = {
            "position_power": 0.30,
            "information_power": 0.25,
            "relationship_power": 0.25,
            "expertise_power": 0.20
        }
        
        # 计算总分
        your_total = sum(your_scores[k] * weights[k] for k in weights)
        opponent_total = sum(opponent_scores[k] * weights[k] for k in weights)
        
        # 判断权力对比
        if your_total > opponent_total + 0.5:
            balance = "你占优势"
        elif opponent_total > your_total + 0.5:
            balance = "对方占优势"
        else:
            balance = "势均力敌"
        
        # 优势劣势分析
        strengths = []
        weaknesses = []
        for k in weights:
            if your_scores[k] > opponent_scores[k]:
                strengths.append(f"{self._get_power_name(k)}：你的优势")
            elif your_scores[k] < opponent_scores[k]:
                weaknesses.append(f"{self._get_power_name(k)}：对方优势")
        
        # 推荐策略
        strategies = self._get_recommended_strategies(your_total, opponent_total, diagnosis)
        
        # 风险预警
        warnings = self._get_power_warnings(diagnosis)
        
        return PowerDynamicsResult(
            your_power_score=round(your_total, 2),
            opponent_power_score=round(opponent_total, 2),
            power_balance=balance,
            strengths=strengths,
            weaknesses=weaknesses,
            strategies=strategies,
            warnings=warnings
        )
    
    def _get_power_name(self, key: str) -> str:
        """获取权力维度名称"""
        names = {
            "position_power": "职位权力",
            "information_power": "信息权力",
            "relationship_power": "关系权力",
            "expertise_power": "专业权力"
        }
        return names.get(key, key)
    
    def _get_recommended_strategies(self, your_power: float, opponent_power: float, diagnosis: ScenarioDiagnosis) -> List[Dict]:
        """获取推荐策略"""
        strategies = []
        
        if opponent_power > your_power + 0.5:
            strategies.append({
                "name": "借势法",
                "description": "借用规则、流程、第三方权威来背书",
                "examples": ["公司规定...", "根据合同第X条...", "HR部门说..."]
            })
            strategies.append({
                "name": "证据法",
                "description": "用证据说话，让事实支撑你",
                "examples": ["我查一下记录...", "有邮件可以证明..."]
            })
            strategies.append({
                "name": "联盟法",
                "description": "引入第三方，打破一对一僵局",
                "examples": ["我觉得应该听听XX的意见...", "这事是不是该汇报给领导..."]
            })
        
        if diagnosis.risk_level == "高风险":
            strategies.append({
                "name": "谨慎策略",
                "description": "高风险场景，建议谨慎行动",
                "examples": ["先收集证据", "不要当场表态", "寻求专业建议"]
            })
        
        return strategies
    
    def _get_power_warnings(self, diagnosis: ScenarioDiagnosis) -> List[str]:
        """获取风险预警"""
        warnings = []
        
        if diagnosis.boundary_status == "C类-错位边界":
            warnings.append("⚠️ 对方可能在进行责任转嫁，小心被甩锅")
        
        if diagnosis.risk_level == "高风险":
            warnings.append("⚠️ 高风险场景，证据是关键")
        
        return warnings
    
    def generate_evidence_plan(self, situation: str) -> EvidencePlanResult:
        """
        证据作战计划
        系统性的证据收集、整理、使用策略
        """
        diagnosis = self.diagnose(situation)
        
        # 根据场景确定需要的证据
        evidence_needed = []
        
        scene_evidences = {
            "职场": [
                {"type": "分工记录", "description": "邮件/纪要中的任务分工", "priority": "高"},
                {"type": "决策记录", "description": "谁做的决定、什么时候做的", "priority": "高"},
                {"type": "沟通记录", "description": "与相关方的沟通截图", "priority": "中"},
                {"type": "进度报告", "description": "工作周报、进度更新", "priority": "中"}
            ],
            "消费": [
                {"type": "购买凭证", "description": "发票、订单截图", "priority": "高"},
                {"type": "沟通记录", "description": "与客服的聊天记录", "priority": "高"},
                {"type": "产品证据", "description": "问题照片/视频", "priority": "高"},
                {"type": "鉴定报告", "description": "第三方鉴定（如需要）", "priority": "中"}
            ],
            "家庭": [
                {"type": "转账记录", "description": "银行/支付宝转账凭证", "priority": "高"},
                {"type": "借条/协议", "description": "书面约定", "priority": "高"},
                {"type": "聊天记录", "description": "相关沟通截图", "priority": "中"}
            ]
        }
        
        scene_evidences.get(diagnosis.scene_type, [
            {"type": "沟通记录", "description": "相关沟通截图", "priority": "高"},
            {"type": "时间线", "description": "事件经过记录", "priority": "中"}
        ])
        
        for e in scene_evidences.get(diagnosis.scene_type, []):
            evidence_needed.append(e)
        
        # 证据收集状态
        evidence_status = {
            "已收集": [],
            "收集中": [],
            "待收集": [e["type"] for e in evidence_needed]
        }
        
        # 证据链条分析
        chain_analysis = []
        for i, role in enumerate(diagnosis.responsibility_chain):
            chain_analysis.append({
                "step": i + 1,
                "fact": f"{role['role']}的{role['responsibility']}",
                "evidence_needed": role.get("evidence_needed", []),
                "current_status": "待收集"
            })
        
        # 使用策略
        if diagnosis.risk_level == "高风险":
            usage_strategy = "建议先收集完整证据链，再视情况使用"
        else:
            usage_strategy = "可以边收集边使用，关键证据要保管好"
        
        # 收集计划
        collection_plan = [
            "1. 整理现有证据，分类编号",
            "2. 补充缺失证据，明确时间节点",
            "3. 多重备份，防止丢失",
            "4. 必要时进行公证"
        ]
        
        return EvidencePlanResult(
            evidence_needed=evidence_needed,
            evidence_status=evidence_status,
            chain_analysis=chain_analysis,
            usage_strategy=usage_strategy,
            collection_plan=collection_plan
        )
    
    def predict_opponent_response(self, situation: str, your_script: str) -> PredictionResult:
        """
        预判对方反应
        预测对方可能的回应及应对
        """
        diagnosis = self.diagnose(situation)
        
        # 可能的反应类型
        possible_responses = [
            {
                "type": "认可",
                "description": "对方承认事实，同意你的观点",
                "probability": "中等" if diagnosis.boundary_status == "C类-错位边界" else "较高",
                "your_action": "友好收尾，巩固成果",
                "script": "好的，那我们就按这个方案来处理"
            },
            {
                "type": "否认/狡辩",
                "description": "对方否认你的说法，继续推卸",
                "probability": "高" if diagnosis.boundary_status == "C类-错位边界" else "中等",
                "your_action": "出示证据，继续施压",
                "script": "我这里有当时的记录，您可以看一下..."
            },
            {
                "type": "情绪爆发",
                "description": "对方情绪激动，可能发火",
                "probability": "中等",
                "your_action": "先安抚情绪，再谈事",
                "script": "我能感受到您很着急，我们先冷静一下..."
            },
            {
                "type": "转移话题",
                "description": "对方试图转移焦点",
                "probability": "中等",
                "your_action": "把话题拉回来",
                "script": "这个我们先放一放，回到刚才的话题..."
            }
        ]
        
        # 推荐应对
        recommended_responses = []
        for resp in possible_responses:
            recommended_responses.append({
                "if": f"对方{resp['type']}",
                "then": resp['your_action'],
                "say": resp['script']
            })
        
        # 博弈树
        tree = """
        ┌─────────────────────────────────────┐
        │         你的回应                     │
        └──────────────┬──────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
    ┌──────┐     ┌──────┐      ┌──────┐
    │认可  │     │否认  │      │情绪爆发│
    │✓结束 │     │  ↓   │      │  ↓   │
    └──────┘     │出示证据│      │安抚情绪│
                 │继续施压│      │再谈事  │
                 └───────┘      └───────┘
        """
        
        return PredictionResult(
            possible_responses=possible_responses,
            recommended_responses=recommended_responses,
            博弈_tree=tree
        )
    
    def generate_escalation_path(self, situation: str) -> EscalationPathResult:
        """
        升级路径规划
        如果沟通失败，下一步怎么办
        """
        diagnosis = self.diagnose(situation)
        
        # 根据场景选择升级路径
        scene_paths = {
            "职场": self.escalation_paths.get("workplace", {}),
            "消费": self.escalation_paths.get("consumer", {}),
            "家庭": self.escalation_paths.get("family", {}),
            "邻里": self.escalation_paths.get("neighbor", {})
        }
        
        path_data = scene_paths.get(diagnosis.scene_type, {})
        paths = path_data.get("path", [])
        
        if not paths:
            # 默认路径
            paths = [
                {"level": 1, "name": "私下沟通", "description": "双方直接沟通"},
                {"level": 2, "name": "第三方介入", "description": "请中立第三方帮助"},
                {"level": 3, "name": "正式投诉", "description": "向相关部门投诉"},
                {"level": 4, "name": "法律途径", "description": "通过法律手段维权"}
            ]
        
        # 时机判断
        timing_check = self.escalation_paths.get("general_principles", {}).get("升级时机判断", {})
        
        # 升级话术
        next_script = {
            "open": "关于[具体事情]，我想正式向您反馈...",
            "fact": "[简述情况]",
            "request": "[说明诉求]",
            "deadline": "请在[X]日内给予回复"
        }
        
        # 注意事项
        warnings = [
            "升级前确保有充分证据",
            "保持专业，不带情绪",
            "书面沟通优于口头",
            "评估关系成本"
        ]
        
        return EscalationPathResult(
            current_level=1,
            next_level=2,
            escalation_path=paths,
            timing_check=timing_check.get("可以升级", []),
            next_script=next_script,
            warnings=warnings
        )
    
    def analyze_timeline(self, situation: str) -> TimelineResult:
        """
        时间线分析
        还原事件全貌，找出关键节点
        """
        diagnosis = self.diagnose(situation)
        
        # 关键事件（需要用户补充具体时间）
        key_events = [
            {
                "time": "[请填写]",
                "event": "事件开始/问题出现",
                "person": "[相关方]",
                "evidence": "需要收集的证据"
            }
        ]
        
        # 责任节点
        responsibility_nodes = []
        for i, role in enumerate(diagnosis.responsibility_chain):
            responsibility_nodes.append({
                "index": i + 1,
                "role": role["role"],
                "responsibility": role["responsibility"],
                "key_question": f"{role['role']}在哪个节点做了不同选择会导致不同结果？"
            })
        
        # 因果链条
        causal_chain = [
            "[第一阶段] 事件起因",
            "    ↓",
            "[第二阶段] 关键决策/行动",
            "    ↓",
            "[第三阶段] 问题出现",
            "    ↓",
            "[第四阶段] 当前状态"
        ]
        
        # 结论
        conclusion = "通过时间线分析，关键问题出现在[节点]，该节点的责任方是[角色]"
        
        # 可视化时间线
        timeline_text = """
┌─────────────────────────────────────────────────────────────────┐
│                       ⏱️ 时间线还原                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   节点1 ───→ 节点2 ───→ 节点3 ───→ 节点4 ───→ 现在           │
│     ↓          ↓          ↓          ↓                         │
│   [事件]    [决策]     [变化]     [问题]                        │
│                                                                 │
│   ★ = 关键节点（责任归属点）                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
        """
        
        return TimelineResult(
            key_events=key_events,
            responsibility_nodes=responsibility_nodes,
            causal_chain=causal_chain,
            conclusion=conclusion,
            timeline_text=timeline_text
        )
    
    # ==================== 快捷方法 ====================
    
    def full_analysis(self, situation: str) -> Dict:
        """
        完整分析
        一次调用返回所有分析结果
        """
        diagnosis = self.diagnose(situation)
        script_pro = self.generate_script(situation, "professional", diagnosis)
        script_gentle = self.generate_script(situation, "gentle", diagnosis)
        power_analysis = self.analyze_power_dynamics(situation)
        evidence_plan = self.generate_evidence_plan(situation)
        escalation = self.generate_escalation_path(situation)
        timeline = self.analyze_timeline(situation)
        prediction = self.predict_opponent_response(situation, script_pro.full_script)
        
        return {
            "diagnosis": asdict(diagnosis),
            "scripts": {
                "professional": script_pro.script,
                "gentle": script_gentle.script
            },
            "power_analysis": asdict(power_analysis),
            "evidence_plan": asdict(evidence_plan),
            "escalation_path": asdict(escalation),
            "timeline": asdict(timeline),
            "prediction": {
                "possible_responses": prediction.possible_responses,
                "recommended_responses": prediction.recommended_responses
            }
        }


# 快捷函数
def quick_analyze(situation: str) -> Dict:
    """快速分析"""
    guardian = QiankunGuardian()
    return guardian.full_analysis(situation)


def quick_script(situation: str, style: str = "professional") -> str:
    """快速生成话术"""
    guardian = QiankunGuardian()
    response = guardian.generate_script(situation, style)
    return response.script["full_script"]


if __name__ == "__main__":
    # 示例用法
    guardian = QiankunGuardian()
    
    test_situation = "领导在会议上说项目延期是我的责任，但实际上是因为其他部门配合不及时导致的"
    
    print("=== 场景诊断 ===")
    diagnosis = guardian.diagnose(test_situation)
    print(diagnosis.diagnosis_summary)
    
    print("\n=== 专业版话术 ===")
    script = guardian.generate_script(test_situation, "professional")
    print(script.script["full_script"])
    
    print("\n=== 权力分析 ===")
    power = guardian.analyze_power_dynamics(test_situation)
    print(f"你的筹码: {power.your_power_score}")
    print(f"对方筹码: {power.opponent_power_score}")
    print(f"权力对比: {power.power_balance}")
