# CLI 使用技巧：`--json-out` 落盘 + Node.js 精准查询

> **AI 助手（本 Skill）**：凡需结构化数据，一律使用 **`--json-out <路径>`**（**目录** 或 **`*.json` 具体文件**）将 JSON 写入磁盘（并更新 **`cli-manifest.json`**，与 `google-analysis` 的 `manifest.json`、`report …` 的 `report-manifest.json` 并存于各自目录），再用 **脚本读文件**（`fs.readFileSync` / `require`）做筛选与聚合；**不要**依赖对话里粘贴的 stdout 整包 JSON。命令成功时 **stdout 仅一行摘要 JSON**（体积小），其中 **`outlineFile`** 指向与当次 `*.json` **同 stem** 的 **`*.outline.txt`**（纯文本单行，接近 **TypeScript 类型字面量**：`{ a: number; b: string }`、`(T | U)[]` 等；数组由**前 8 项**去重推断并集；环 / 同对象再出现为 `any`）。完整数据仍以落盘 `*.json` 为准，类型扫一眼读 outline 文件即可。
>
> 人类/一次性调试仍可在终端使用 **`--json`**（与 **`--json-out` 互斥**）；Skill 正文与 Agent 编排**只写 `--json-out`**。

**Google `google-analysis` 与 Meta/TikTok/Bing `report …` 账户分析拉数（本 Skill 推荐口径）**：统一 **`--json-out <目录>`** 落盘（分析子命令以目录为主；通用业务命令另支持 **`--json-out ./foo.json` 单文件**）；**用脚本读目录内 JSON + 数据处理库算指标，再由代码写出交付文件**（HTML / Excel / PDF / PPT / Markdown 等任选），勿用 `Read` 代替程序读数、勿在聊天里直接贴完整交付稿；脚本里勿写业务数据常量。详见 `references/account-analytics.md`「Google 分析快照工作流」及清单文件说明。

---

## 已有 JSON 时（不必先重跑 CLI）

用户已保存输出或只问「怎么从一大坨 JSON 里筛字段」时：直接用 **本地文件** 喂给 `node -e` 即可，不必为示例再执行 `list-accounts` 等业务命令（字段路径以实际响应为准；列表类命令多为 `items[]` 外层分页结构）。

---

## 基础模式：`--json-out` + 读文件 + `node -e`

约定示例目录 **`./snap-cli`**（可换任意空目录）。**文件名**以当次命令生成的 **`cli-manifest.json` → `artifacts[].file`** 为准；常见读命令经规范化后形如 `list-accounts-google.json`、`balance-google.json` 等（**全小写**）。同目录另有 **`list-accounts-google.outline.txt`**（与 `stdout` 摘要里的 `outlineFile` 一致）：TS 式类型单行，按需 `fs.readFileSync` 读取即可。

### 过滤特定字段（Google 账户列表）

`list-accounts` 的 `items[]` 元素多为 `{ ma: { mediaCustomerId, mediaCustomerName, ... } }` 结构：

```bash
mkdir -p ./snap-cli
siluzan-tso list-accounts -m Google --json-out ./snap-cli
node -e "
const path = require('path');
const snap = './snap-cli';
const d = require(path.join(snap, 'list-accounts-google.json'));
const rows = Array.isArray(d.items) ? d.items.map((x) => x.ma ?? x) : [];
rows.forEach((ma) => console.log(ma.mediaCustomerId, ma.mediaCustomerName));
"
```

Windows PowerShell（避免管道传 JSON）：

```powershell
$SNAP = ".\snap-cli"; New-Item -ItemType Directory -Force -Path $SNAP | Out-Null
siluzan-tso list-accounts -m Google --json-out $SNAP
node -e "const d=require('./snap-cli/list-accounts-google.json'); const rows=(d.items||[]).map(x=>x.ma||x); rows.forEach(ma=>console.log(ma.mediaCustomerId, ma.mediaCustomerName));"
```

---

## 常用场景示例

以下均假设 `mkdir -p ./snap-cli` 已执行，且在同一工作目录下。

### 1. 从账户列表提取特定账户的 ID

```bash
siluzan-tso list-accounts -m Google --json-out ./snap-cli
node -e "
const d = require('./snap-cli/list-accounts-google.json');
const rows = (d.items || []).map((x) => x.ma || x);
const target = rows.find((ma) => String(ma.mediaCustomerName || '').includes('Brand A'));
console.log(target ? target.mediaCustomerId : 'not found');
"
```

### 2. 余额低于阈值的账户告警

`balance` 列表在 `items[]` 中，常用字段含 `remainingAccountBudget`、`name`、`currencyCode`：

```bash
siluzan-tso balance -m Google --json-out ./snap-cli
node -e "
const d = require('./snap-cli/balance-google.json');
const rows = d.items || [];
const low = rows.filter((a) => Number(a.remainingAccountBudget) < 100);
if (low.length === 0) { console.log('所有账户余额充足'); process.exit(0); }
console.log('余额不足账户：');
low.forEach((a) => console.log(' ', a.mediaCustomerId, a.name, '余额:', a.remainingAccountBudget, a.currencyCode));
"
```

### 3. 汇总消耗数据

`stats` 的 `AccountOverviewItem` 使用 **`spend`**（非 `cost`）：

```bash
siluzan-tso stats -m Google --days 7 --json-out ./snap-cli
node -e "
const d = require('./snap-cli/stats-google.json');
const list = d.items || [];
const total = list.reduce((s, a) => s + Number(a.spend ?? 0), 0);
const clicks = list.reduce((s, a) => s + Number(a.clicks ?? 0), 0);
console.log('总消耗:', total.toFixed(2), '  总点击:', clicks);
list
  .slice()
  .sort((a, b) => Number(b.spend) - Number(a.spend))
  .slice(0, 5)
  .forEach((a) => console.log(' ', a.mediaCustomerId, a.mediaCustomerName, a.spend));
"
```

### 4. 从广告系列列表提取 ID

```bash
siluzan-tso ad campaigns -a <mediaCustomerId> --json-out ./snap-cli
node -e "
const d = require('./snap-cli/ad-campaigns-<mediaCustomerId>.json');
const list = d.items || [];
list.filter((c) => c.status === 'ENABLED').forEach((c) => console.log(c.id, c.name));
"
```

（将文件名中的 `<mediaCustomerId>` 换成实际数字 ID；若不确定文件名，先看 `./snap-cli/cli-manifest.json` 的 `artifacts`。）

### 5. 检查预警规则是否已存在

```bash
siluzan-tso forewarning list -m Google --json-out ./snap-cli
node -e "
const d = require('./snap-cli/forewarning-list-google.json');
const rules = d.items || [];
const name = '日消耗预警';
const exists = rules.some((r) => (r.data && r.data.name) === name);
console.log(exists ? '已存在，跳过创建' : '不存在，可以创建');
"
```

### 6. 关键字推荐结果

```bash
siluzan-tso keyword -k "running shoes" --json-out ./snap-cli
node -e "
const d = require('./snap-cli/keyword-suggest.json');
const items = d.items || [];
const top = items
  .slice()
  .sort((a, b) => (b.montlySearch ?? 0) - (a.montlySearch ?? 0))
  .slice(0, 15)
  .map((k) => k.keyword);
console.log(top.join(','));
"
```

### 7. 根据地区预算比例（需先有 AIGC / 分析 JSON 文件）

若上游步骤已生成包含 `budgetProportions` 的快照 JSON（例如自建脚本或历史 `google-analysis` 落盘），直接读该文件：

```bash
node -e "
const data = require('./snap-cli/my-budget-proportions.json');
const totalBudget = 200;
const currency = data.account?.currencyCode ?? 'USD';
console.log('地区预算分配（总预算', totalBudget, currency + '）：');
(data.budgetProportions || []).forEach((bp) => {
  const budget = (totalBudget * bp.budgetProportion).toFixed(2);
  console.log(' ', bp.areaCode, budget, currency);
});
"
```

### 8. 查找 entityId（解绑/分享前）

```bash
siluzan-tso list-accounts -m Google --json-out ./snap-cli
node -e "
const d = require('./snap-cli/list-accounts-google.json');
const rows = (d.items || []).map((x) => x.ma || x);
const keyword = 'Brand A';
rows
  .filter((ma) => String(ma.mediaCustomerName || '').includes(keyword))
  .forEach((ma) => {
    console.log('mediaCustomerName:', ma.mediaCustomerName);
    console.log('mediaCustomerId:  ', ma.mediaCustomerId);
    console.log('entityId:         ', ma.entityId ?? ma.id);
    console.log('---');
  });
"
```

---

## 多命令串联（中间结果一律落盘）

```bash
SNAP=./snap-cli
mkdir -p "$SNAP"

siluzan-tso list-accounts -m Google --json-out "$SNAP"
ACCOUNT_ID=$(node -e "
const d = require('./snap-cli/list-accounts-google.json');
const rows = (d.items||[]).map(x=>x.ma||x);
const t = rows.find(ma => String(ma.mediaCustomerName||'').includes('Brand A'));
process.stdout.write(t ? String(t.mediaCustomerId) : '');
")

siluzan-tso ad campaigns -a "$ACCOUNT_ID" --json-out "$SNAP"
CAMPAIGN_ID=$(node -e "
const fs = require('fs');
const path = require('path');
const dir = './snap-cli';
const man = JSON.parse(fs.readFileSync(path.join(dir,'cli-manifest.json'),'utf8'));
const art = (man.artifacts||[]).find(a => String(a.section||'').startsWith('ad-campaigns-'));
if (!art) process.exit(1);
const d = require(path.join(dir, art.file));
const list = d.items || [];
const c = list.find(x => x.status === 'ENABLED');
process.stdout.write(c ? String(c.id) : '');
")

echo "Account: $ACCOUNT_ID  Campaign: $CAMPAIGN_ID"
```

Windows 可两步分别 `siluzan-tso ... --json-out .\snap-cli` 后，用 `node -e` 读 `cli-manifest.json` 找到最新 `ad-campaigns-*.json` 文件名（与 bash 示例同理）。

---

## 调试技巧

### 查看原始 API 响应结构（`--verbose`）

`--verbose` 会把请求 URL 和原始响应打到 **stderr**；结构化数据仍以 **`--json-out`** 落盘为准：

```bash
siluzan-tso list-accounts -m Google --json-out ./snap-cli --verbose 2> ./snap-cli/verbose.log
```

### 验证快照 JSON

```bash
siluzan-tso list-accounts -m Google --json-out ./snap-cli
node -e "
const d = require('./snap-cli/list-accounts-google.json');
console.log('keys:', Object.keys(d));
console.log('itemCount:', d.itemCount, 'sample:', d.items && d.items[0] && Object.keys(d.items[0]));
"
```

### 查看 `ad batch list` 字段

```bash
siluzan-tso ad batch list --json-out ./snap-cli
node -e "
const d = require('./snap-cli/ad-batch-list.json');
const first = (d.items || [])[0];
console.log('可用字段：', first && Object.keys(first));
"
```

---

## 通用分页与查询建议

- 绝大多数列表类命令默认每页 20 条记录，数据量较大时建议显式指定分页参数。
- 建议在拉取大批量数据时使用命令自带的 `--page-size`（如设置为 `100`）与 `--page` 组合翻页，确认无更多数据后再停止，避免遗漏。

---

## AI Agent 使用规范

- **优先用 `--json-out` 与清单文件**：同一运行目录多次拉数会合并 `cli-manifest.json` 中的 `artifacts[]`；读具体数据请打开对应 `*.json`。
- **中间结果一律落盘**：跨步骤数据不要靠对话记忆，写到工作目录或临时目录并在后续脚本中 `require` / `readFile`。
- **Windows 上避免直接管道 JSON**：PowerShell 管道可能改变编码；优先 `--json-out` + `node -e` 读文件。
- **用 `process.stdout.write` 而不是 `console.log` 提取单个值**：前者不带换行符，方便直接赋给 shell 变量。
- **节点代码复杂时拆分写法**：不要写超过 10 行的 `node -e` 单行，改用 `node -e "$(cat <<'EOF'\n...\nEOF\n)"` 或多行 `.mjs` 脚本文件。
